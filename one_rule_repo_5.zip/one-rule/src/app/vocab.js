// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/vocab.js — the fixed vocabularies of the content model (02 §1, 04 §6, 05 §4). Codes and UI words only; no statement lives here.

/** the mathematician's kinds, in the order mathematics mode sorts by (04_LABELLING.md §6) */
export const KIND_ORDER = ['definition', 'construction', 'lemma', 'theorem', 'range', 'classification', 'invariant', 'example', 'counterexample', 'computation', 'reduction', 'reading', 'conjecture', 'question', 'dead-end', 'pointer', 'meta'];
/** the physicist's stages (02 §1) */
export const STAGE_ORDER = ['A', 'K', 'F', 'D', 'O', 'M'];
export const STAGE_NAMES = { A: 'Algebra', K: 'Kinematics', F: 'Fields', D: 'Dynamics', O: 'Observation', M: 'Method' };
/** the mathematician's fields (02 §1) */
export const FIELD_ORDER = ['algebra', 'geometry', 'topology', 'category', 'combinatorics', 'analysis'];
export const FIELD_NAMES = { algebra: 'Algebra', geometry: 'Geometry', topology: 'Topology', category: 'Category theory', combinatorics: 'Combinatorics', analysis: 'Analysis' };

/** the 29 notions of the labelling scheme, in mask order; the square is +1 (the rule supplies it), −1 (imported), 0 (an input) */
export const NOTIONS = ['lbl', 'sgn', 'sq', 'grd', 'qf', 'clk', 'mir', 'nul', 'tns', 'mod', 'biv', 'cnx', 'var', 'sol', 'lat', 'fin', 'div', 'dyn', 's-alg', 's-geo', 's-phy', 's-cat', 'src', 'i-chart', 'i-time', 'i-J', 'i-act', 'i-tab', 'i-meta'];
export const notionSquare = n => (n.startsWith('i-') ? 0 : n.startsWith('s-') || n === 'src' ? -1 : 1);

/** lens kinds as the picker groups them (lenses.json `kind`) */
export const LENS_KIND_ORDER = ['branch', 'language', 'shape', 'researcher', 'labels', 'convention'];
export const LENS_KIND_NAMES = { branch: 'Branches of mathematics', language: 'Languages of physics', shape: 'Shapes', researcher: 'Researchers', labels: 'Labels', convention: 'Conventions' };

/** the five badges (05 §4): kind → words at the two levels. The research word of an input badge carries its kind, from the status table. */
export const BADGE_KINDS = ['open', 'cited', 'ours', 'input', 'new'];
export const BADGE_WORDS = {
  open: { research: 'open', learner: 'not finished' },
  cited: { research: 'not yet proved here', learner: 'not yet proved here' },
  ours: { research: 'our reading', learner: 'our idea' },
  input: { research: 'needs an input', learner: 'we had to choose this' },
  new: { research: 'new', learner: 'new' },
};
const STATUS_TO_KIND = { open: 'open', cited: 'cited', ours: 'ours', input: 'input' };

/** the badge kind of a status record or of a (status, badge word) pair; null when the statement carries no badge */
export function badgeKind(status, badge) {
  if (!badge) return null;
  if (badge === 'open') return 'open';
  if (badge === 'not yet proved here') return 'cited';
  if (badge === 'our reading') return 'ours';
  if (badge.startsWith('needs an input')) return 'input';
  if (badge === 'new') return 'new';
  return STATUS_TO_KIND[status] || null;
}

/** the status of a statement that carries no badge, in words (the search palette): "checked" and "standard" as content/persona_rules.md names them */
export const STATUS_PLAIN = {
  'proved-by-atlas': { research: 'checked', learner: 'checked' },
  standard: { research: 'standard', learner: 'textbook' },
  meta: { research: 'about the Atlas', learner: 'about the Atlas' },
};

/** the drawer tabs, in order (05 §4) */
export const DRAWER_TABS = ['evidence', 'needs', 'depends', 'readings', 'numbers', 'address'];
export const DRAWER_TAB_NAMES = { evidence: 'Evidence', needs: 'Needs', depends: 'Rests on / leads to', readings: 'Readings', numbers: 'Numbers', address: 'Address' };

export const rankIn = (order, v) => { const i = order.indexOf(v); return i < 0 ? order.length : i; };

// ---------------------------------------------------------------- the story round (docs/STORY_PLAN.md §1.3, §2; BUILD_CONTRACTS interfaces 26–29)
/** the roles of a shownOn entry: lead (one per section, first), caption (the reading of the section's figure, under it), result (statements:
 *  the first N are the key results), detail ("More statements"), learner (shown at learner level only), next (one per page, above the link to
 *  the next page), evidence (the drawer's Numbers) */
export const ROLES = ['lead', 'caption', 'result', 'detail', 'learner', 'next', 'evidence'];
/** the reserved section of a page that holds its intro: the page's lead, its next line, its "at a glance" rows, the hero figure's captions */
export const INTRO_SECTION = 'intro';
/** the reserved parts of a page: "open" holds the sections drawn inside the open fold (perspectives, questions, notes), each a group;
 *  "drawer" the sections kept out of the reading, each a closed fold after the open items */
export const OPEN_PART = 'open';
export const DRAWER_PART = 'drawer';
/** the sections whose rows are the page's inputs ("What this page takes from outside") */
export const INPUT_SECTIONS = ['needs'];
/** key results per section before "More statements (n)" (A54); a section's `key` overrides */
export const KEY_RESULTS = { research: 5, learner: 3 };
/** the connective words of the page template (headings and fold labels; no statement) */
export const STORY_WORDS = {
  glance: 'At a glance',
  more: 'More statements',
  inputs: 'What this page takes from outside',
  behind: 'The statement behind the question',
};
/** the claim words of test T2 (docs/STORY_PLAN.md §1.4): a title holding one is a sentence, not a name (tests/story/composition.test.mjs) */
export const CLAIM_WORDS = ['prove', 'proves', 'proved', 'proof', 'theorem', 'lemma', 'equals', 'equivalent', 'iff', 'implies', 'unique', 'uniquely',
  'exactly', 'always', 'never', 'isomorphic', 'reduces to', 'is given by', 'holds', 'fails', 'vanishes', 'commutes', 'anticommutes', 'squares to', 'must', 'cannot'];
