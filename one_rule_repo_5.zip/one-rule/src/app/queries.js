// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/queries.js — pages as queries over the rows (02 §7, 06): which rows a section shows, in which order, what goes to the drawer
// and to the open fold; titles from pages.json and steps.json; the cards of the cells page and the step index. Pure functions of the tables.
// The story round (docs/STORY_PLAN.md §2, BUILD_CONTRACTS interfaces 26–29) composes a page by role: an intro (the page's lead, "at a glance",
// the next line), parts over sections, and per section lead → figure → captions → key results → "More statements (n)"; see buildPageModel.
import { textFor, statusOf } from './content.js';
import {
  peekTable, rowsByPage, rowsById, pagesByRoute, stepsByRoute, lensesByKey, figuresById, lensTextIndex, lensReadingsIndex, rowsByCell,
} from './store.js';
import {
  KIND_ORDER, STAGE_ORDER, FIELD_ORDER, STAGE_NAMES, DRAWER_TABS, rankIn, INTRO_SECTION, OPEN_PART, DRAWER_PART, INPUT_SECTIONS, KEY_RESULTS, STORY_WORDS,
} from './vocab.js';
import { cellRoute } from './router.js';
import { clockOf } from './cellmath.js';

// ---------------------------------------------------------------- titles
const isAllCaps = t => { const up = (t.match(/[A-Z]/g) || []).length, lo = (t.match(/[a-z]/g) || []).length; return up >= 6 && up >= 4 * lo; };
const capFirst = t => (t ? t.charAt(0).toUpperCase() + t.slice(1) : t);

export function pageTitle(route, s) {
  const p = pagesByRoute()?.get(route);
  if (!p) return route;
  const t = p.title || {};
  return (s.level === 'learner' ? t.learner : null) || t[s.mode] || t.phys || route;
}
export const stepOf = route => stepsByRoute()?.get(route) || null;
const isStep = st => st && st.group !== 'shapes';
const stepNav = (st, s) => (s.level === 'learner' ? st.navLearner || st.nav : st.nav);

/**
 * { eyebrow, title, deck, parent } for a page header; numbers come from steps.json. A sub-page (pages.json `parent` and `tab`, interface 29)
 * reads "<parent> · <tab>" in its eyebrow ("Calibration 2 · Her papers"): the parent's title up to its colon, and the tab's title (`tab` as a
 * string or { phys, math, learner }, else the page's own title); `parent` = { route, label } lets the header link the parent's part of it.
 */
export function pageHeading(route, s) {
  const st = stepOf(route);
  let title = pageTitle(route, s), deck = null, eyebrow = null, parent = null;
  if (isStep(st)) {
    eyebrow = `Step ${st.no} of ${st.total}` + (STAGE_NAMES[st.stage] ? ` · ${STAGE_NAMES[st.stage]}` : '');
    title = capFirst(title.replace(/^Step \d+:\s*/i, ''));
    if (isAllCaps(title)) { deck = title; title = stepNav(st, s); }
  }
  const def = pagesByRoute()?.get(route);
  if (def && def.parent && pagesByRoute()?.has(def.parent)) {
    const label = parentLabel(def.parent, s), tab = titleIn(def.tab, s) || title;
    parent = { route: def.parent, label, tab };
    eyebrow = `${label} · ${tab}`;
  }
  return { eyebrow, title, deck, parent };
}
/** the short name of a parent page in a sub-page's eyebrow: its title up to the first colon ("Calibration 2: matter (Furey)" → "Calibration 2") */
export function parentLabel(route, s) {
  const t = pageLabel(route, s);
  const i = t.indexOf(':');
  return i > 0 ? t.slice(0, i).trim() : t;
}
/** the sub-pages of a page (pages.json entries whose `parent` is it), in the order of pages.json */
export function subPagesOf(route) {
  return (peekTable('pages') || []).filter(p => p.parent === route).map(p => p.route);
}
/** a short label for a link to a page (needs chips, prev/next, contents) */
export function pageLabel(route, s) {
  const st = stepOf(route);
  if (isStep(st)) return `Step ${st.no}: ${stepNav(st, s)}`;
  const t = pageTitle(route, s);
  return isAllCaps(t) ? capFirst(t.toLowerCase()) : t;
}

const SLUG_PREFIX = ['eq', 'ns', 'ln', 'nl', 'sh', 'cat', 'bz', 'sc'];
const SLUG_WORDS = { res: 'results', persp: 'perspectives', deadends: 'dead ends', twozeros: 'two zeros', label0: 'label 0' };
/**
 * A section title from pages.json; anchor-like slugs ("eq-grav2", "cat-w-label0") are turned into words: a slug that names a step
 * takes the step's name from steps.json, or "Results" on that step's own page (where the name is the page title).
 */
export function sectionLabel(title, id, s, route) {
  const t = title || id || '';
  if (!/^[a-z0-9-]+$/.test(t)) return t;
  let parts = t.split('-');
  let figure = false;
  if (parts.length > 1 && SLUG_PREFIX.includes(parts[0])) parts = parts.slice(1);
  if (parts.length > 1 && parts[0] === 'w') { figure = true; parts = parts.slice(1); }
  const key = parts.join('-');
  const st = (peekTable('steps') || []).find(x => x.id === key);
  let words;
  if (st && route && st.route === route) words = 'Results';
  else if (st) words = stepNav(st, s);
  else words = parts.map(w => SLUG_WORDS[w] || w).join(' ');
  return capFirst(words) + (figure ? ' (figure)' : '');
}

// ---------------------------------------------------------------- order
export const visibleIn = (row, mode) => !Array.isArray(row.visibleTo) || !row.visibleTo.length || row.visibleTo.includes(mode);

/** sort shownOn entries: physics by shownOn.order, mathematics by kind rank then field; a lens with its own ordering wins */
export function sortEntries(entries, s) {
  const lens = s.lens ? lensesByKey()?.get(s.lens) : null;
  const ord = lens ? lens.ordering : null;
  const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
  const kind = e => rankIn(KIND_ORDER, e.row.kind);
  const field = e => rankIn(FIELD_ORDER, (e.row.fields || [])[0]);
  const stage = e => rankIn(STAGE_ORDER, e.row.stage);
  const grade = e => { const g = statusOf(e.row.id); return g && typeof g.grade === 'number' ? g.grade : 99; };
  let cmp;
  if (ord === 'kind') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else if (ord === 'stage') cmp = (a, b) => stage(a) - stage(b) || byOrder(a, b);
  else if (ord === 'grade') cmp = (a, b) => grade(a) - grade(b) || byOrder(a, b);
  else if (s.mode === 'math') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else cmp = byOrder;
  return entries.map((e, i) => ({ e, i })).sort((x, y) => cmp(x.e, y.e) || x.i - y.i).map(x => x.e);
}

// ---------------------------------------------------------------- the page model
const hasText = (id, s) => textFor(id, s) != null;
const isSlug = t => typeof t === 'string' && /^[a-z0-9-]+$/.test(t);
const isName = t => typeof t === 'string' && t.trim() !== '' && !isSlug(t);
const roleOf = e => e.so.role || 'result';
const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
const isOpenRow = id => (statusOf(id) || {}).status === 'open';
/** a figure field of pages.json (a section's `figure`, a hero's): an id or a list of ids → [ids] */
export const figureList = f => (Array.isArray(f) ? f : f ? [f] : []).filter(x => typeof x === 'string' && x);

/**
 * A title of pages.json in the words of the settings: a string, or { phys, math, learner } (learner level takes `learner`, then the mode's);
 * anchor slugs ("bz-top") are not names. → the name, or null when the title gives none.
 */
export function titleIn(t, s) {
  if (t == null || t === false) return null;
  if (typeof t === 'string') return isName(t) ? t.trim() : null;
  if (s.level === 'learner' && isName(t.learner)) return t.learner.trim();
  if (isName(t[s.mode])) return t[s.mode].trim();
  return isName(t.phys) ? t.phys.trim() : null;
}
/** the heading of a section: the overlay's title (A53), else sectionLabel of its slug; `title: false` is a section with no heading (v15's top) */
function sectionHeading(sec, s, route) {
  const t = sec.title;
  const fallback = () => sectionLabel(t && typeof t === 'object' ? t[s.mode] || t.phys : null, sec.id, s, route);
  if (t === false) return { heading: null, label: fallback() };
  const own = titleIn(t, s);
  const label = own || fallback();
  return { heading: label, label };
}

let assignedMemo = null;
/**
 * The figures some page assigns (a hero's `figure`, a section's `figure`, in every entry of pages.json): such a figure is drawn where it is
 * assigned and is never placed by its caption row (interface 28); the caption-row rule stays for the figures no page assigns.
 */
export function assignedFigures() {
  const pages = peekTable('pages');
  if (!pages) return new Set();
  if (assignedMemo && assignedMemo.pages === pages) return assignedMemo.set;
  const set = new Set();
  for (const p of pages) {
    for (const f of figureList(p.hero && p.hero.figure)) set.add(f);
    for (const sec of p.sections || []) for (const f of figureList(sec && sec.figure)) set.add(f);
  }
  assignedMemo = { pages, set };
  return set;
}

/** the figure a page assigns to its hero: hero.figure, else the figure of its reserved section `intro` (the story overlay's way of saying it) */
const heroFigureOf = def => (def.hero && def.hero.figure) || figureList(((def.sections || []).find(x => x && x.id === INTRO_SECTION) || {}).figure)[0] || null;

/** the figure of a hero: the page's (an id missing from figures.json draws nothing), else the first figure no page assigns whose caption row is the hero row */
export function heroFigure(def, s) {
  const figs = peekTable('figures') || [];
  const id = heroFigureOf(def);
  let f = id ? figuresById()?.get(id) || null : null;
  if (!id && def.hero && def.hero.row) {
    const taken = assignedFigures();
    f = figs.find(x => x.captionRow === def.hero.row && !taken.has(x.id) && (s.level !== 'learner' || x.learner)) || null;
  }
  if (f && s.level === 'learner' && !f.learner) return null;
  return f ? f.id : null;
}

/** how many key results a section shows at this level: { n, list } — `key` a number, { research, learner }, or a list of row ids (A54) */
function keyOf(sec, s) {
  const lv = s.level === 'learner' ? 'learner' : 'research';
  const k = sec.key;
  if (typeof k === 'number' && k >= 0) return { n: k, list: null };
  if (Array.isArray(k)) return { n: lv === 'learner' ? KEY_RESULTS.learner : null, list: k };
  if (k && typeof k === 'object') return { n: typeof k[lv] === 'number' ? k[lv] : KEY_RESULTS[lv], list: Array.isArray(k.rows) ? k.rows : null };
  return { n: KEY_RESULTS[lv], list: null };
}

/** the sections of a page in display order: pages.json's order, each part's sections drawn together where its first one stands */
function orderedSections(def) {
  const secs = (def.sections || []).filter(x => x && x.id);
  const parts = Array.isArray(def.parts) ? def.parts.filter(p => p && p.id) : [];
  if (!parts.length) return secs;
  const byId = new Map(secs.map(x => [x.id, x]));
  const members = new Map(parts.map(p => [p.id, [...(p.sections || []).filter(id => byId.has(id))]]));
  for (const x of secs) if (x.part && members.has(x.part) && !members.get(x.part).includes(x.id) && ![...members.values()].some(l => l.includes(x.id))) members.get(x.part).push(x.id);
  const partOf = new Map();
  for (const p of parts) for (const id of members.get(p.id)) if (!partOf.has(id)) partOf.set(id, p.id);
  const out = [], done = new Set();
  for (const x of secs) {
    if (done.has(x.id)) continue;
    const pid = partOf.get(x.id);
    const run = pid ? members.get(pid).filter(id => partOf.get(id) === pid) : [x.id];
    for (const id of run) if (!done.has(id)) { done.add(id); out.push(byId.get(id)); }
  }
  return out;
}

/** a section of the open part with `pairs: "splitFrom"`: each statement with the rows split from it (v15's questions), in their order */
function pairsOf(ids) {
  const set = new Set(ids), used = new Set(), out = [];
  for (const id of ids) {
    if (used.has(id)) continue;
    const r = rowsById()?.get(id);
    const from = r && r.splitFrom && set.has(r.splitFrom) ? r.splitFrom : null;
    const head = from || id;
    if (used.has(head)) { used.add(id); continue; }
    const questions = ids.filter(x => x !== head && (rowsById()?.get(x) || {}).splitFrom === head);
    used.add(head); questions.forEach(q => used.add(q));
    out.push({ statement: head, questions });
  }
  return out;
}

/**
 * Model of a page for the current settings (interface 27; docs/STORY_PLAN.md §2.1–2.3, §2.9). Every field the pages read before the story round is
 * kept with its meaning; the composition is added beside it.
 *
 * buildPageModel(route, settings, opts = { custom: [section ids rendered by the page itself] }) →
 * {
 *   def, route,
 *   hero: { id, register, figure, captions: [row ids] } | null,     the hero row; its figure; the caption rows of the intro, drawn under the figure
 *   intro: { lead, next, glance, more, learnerRows },               the reserved section `intro`: the page's lead (one paragraph under the header),
 *                                                                  the next line (above the link to the next page), "at a glance" (its result rows,
 *                                                                  the page strip, A57), its details and captions without a figure ("More statements"),
 *                                                                  its learner-only rows (learner level)
 *   parts: [{ id, title, sections: [ids] }],                        the parts of the body in display order (a chapter's h2 headings); [] without parts
 *   sections: [{
 *     id, label, heading, part, placement, connective, figure, figures, lead, captions, key, more, learnerRows,
 *     body, details, numbers, drawerRows, all, tabs, show
 *   }],
 *   open: [{ id, label, rows, lead?, sub?, pairs? }], openRows,      the open fold, grouped by part (by section on a page without parts); the open part's
 *                                                                  sections each a group (with its lead; `sub` for grouped sections; `pairs` per statement)
 *   reference: [section],                                          the sections of the reserved part `drawer`, each drawn as a closed fold after the open items
 *   inputs: { rows, lead, learnerRows } | null,                     "What this page takes from outside (n)": the rows of the needs sections
 *   rowSection, place, results, learnerShort
 * }
 * Per section: `lead` the one `lead` row (section.lead when it is placed there), `figure` the first of `figures` (section.figure explicit — an id of
 * figures.json, or a list — then the figures no page assigns whose caption row the section holds), `captions` its `caption` rows in order (a section
 * without a drawn figure folds them into `more`), `key` the first N results sorted per mode (N = section.key, else 5 research and 3 learner; a list
 * names the key rows), at learner level after the section's `learner` rows; `more` the other results, then the `detail` rows, then the folded captions.
 * Leads, captions and the next line are placed by role and never sorted. `body` (the results with a text at this level, open rows apart), `details`
 * (detail rows, research level), `numbers` (evidence rows, research level) keep their meaning for the step and stage counts and for the pages that
 * render a section themselves (custom). `placement`: body | open | reference | inputs. `place` maps a row to { where, sid } for deep links (at=).
 */
export function buildPageModel(route, s, opts = {}) {
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const learner = s.level === 'learner';
  const custom = new Set(opts.custom || []);
  const has = id => hasText(id, s);
  const all = (rowsByPage()?.get(route) || []).filter(e => visibleIn(e.row, s.mode));
  const heroId = def.hero && def.hero.row && rowsById()?.get(def.hero.row) && visibleIn(rowsById().get(def.hero.row), s.mode) ? def.hero.row : null;

  // parts: membership by parts[].sections or section.part; the reserved parts open (the open fold) and drawer (closed folds)
  const parts = Array.isArray(def.parts) ? def.parts.filter(p => p && p.id) : [];
  const partOf = new Map();
  for (const p of parts) for (const id of p.sections || []) if (!partOf.has(id)) partOf.set(id, p);
  for (const sec of def.sections || []) if (sec && sec.part && !partOf.has(sec.id)) { const p = parts.find(x => x.id === sec.part); if (p) partOf.set(sec.id, p); }
  const placementOf = sec => {
    const p = partOf.get(sec.id);
    if (p && p.id === OPEN_PART) return 'open';
    if (p && p.id === DRAWER_PART) return 'reference';
    return INPUT_SECTIONS.includes(sec.id) || sec.inputs === true ? 'inputs' : 'body';
  };

  // sections: the declared ones (by their query) in display order, then any section the rows name that pages.json does not declare; the intro apart
  const introEntries = all.filter(e => e.so.section === INTRO_SECTION);
  const groups = [];
  const claimed = new Set(introEntries);
  for (const sec of orderedSections(def)) {
    if (sec.id === INTRO_SECTION) continue;
    const key = (sec.query && sec.query['shownOn.section']) || sec.id;
    const entries = all.filter(e => !claimed.has(e) && (e.so.section === key || e.so.section === sec.id));
    entries.forEach(e => claimed.add(e));
    groups.push({ sec, id: sec.id, entries });
  }
  const extra = new Map();
  for (const e of all) if (!claimed.has(e)) { if (!extra.has(e.so.section)) extra.set(e.so.section, []); extra.get(e.so.section).push(e); }
  for (const [sid, entries] of extra) groups.push({ sec: { id: sid, title: { phys: sid, math: sid }, drawer: DRAWER_TABS }, id: sid, entries });

  let heroReg = null;
  if (heroId) heroReg = hasText(heroId, { ...s, register: 'short' }) ? 'short' : has(heroId) ? 'full' : null;
  const hero = heroId && heroReg ? { id: heroId, register: heroReg, figure: heroFigure(def, s), captions: [] } : null;

  const rowSection = new Map(), place = new Map();
  const put = (id, where, sid) => { if (!place.has(id)) place.set(id, { where, sid }); };
  if (hero) { rowSection.set(hero.id, '__hero'); put(hero.id, 'hero', '__hero'); }

  // the intro: lead, next, at a glance, the hero's captions, details, learner rows (placed by role)
  const io = [...introEntries].filter(e => e.row.id !== heroId).sort(byOrder);
  const firstOf = (list, role) => { const e = list.find(x => roleOf(x) === role && has(x.row.id)); return e ? e.row.id : null; };
  const intro = { lead: null, next: null, glance: [], more: [], learnerRows: [] };
  const named = k => { const id = def.intro && def.intro[k]; const r = id ? rowsById()?.get(id) : null; return r && visibleIn(r, s.mode) && has(id) ? id : null; };
  intro.lead = named('lead') || firstOf(io, 'lead');
  intro.learnerRows = learner ? io.filter(e => roleOf(e) === 'learner' && has(e.row.id)).map(e => e.row.id) : [];
  const introCaptions = io.filter(e => roleOf(e) === 'caption' && has(e.row.id)).map(e => e.row.id);
  if (hero && hero.figure) hero.captions = introCaptions;
  const glanceAll = sortEntries(io.filter(e => roleOf(e) === 'result' && has(e.row.id)), s).map(e => e.row.id);
  intro.glance = glanceAll.filter(id => !isOpenRow(id));
  intro.more = [...sortEntries(io.filter(e => roleOf(e) === 'detail' && has(e.row.id)), s).map(e => e.row.id), ...(hero && hero.figure ? [] : introCaptions)];
  if (intro.lead) put(intro.lead, 'intro', '__intro');
  intro.learnerRows.forEach(id => put(id, 'intro', '__intro'));
  hero && hero.captions.forEach(id => { rowSection.set(id, '__hero'); put(id, 'caption', '__hero'); });
  intro.glance.forEach(id => { rowSection.set(id, '__intro'); put(id, 'glance', '__intro'); });
  intro.more.forEach(id => { rowSection.set(id, '__intro'); put(id, 'intro-more', '__intro'); });

  const assigned = assignedFigures();
  const figs = peekTable('figures') || [];
  const drawable = f => !!f && (!learner || !!f.learner);
  const usedFigures = new Set(hero && hero.figure ? [hero.figure] : []);
  const sections = [], open = [], openRows = [], reference = [];
  const inputs = { rows: [], lead: null, learnerRows: [] };
  const openByPart = new Map();
  let lastPartGroup = null;
  const nextCandidates = io.filter(e => roleOf(e) === 'next');
  let results = 0;
  const pushOpen = id => { openRows.push(id); rowSection.set(id, '__open'); put(id, 'open', '__open'); };
  if (glanceAll.length > intro.glance.length) {
    const rows = glanceAll.filter(isOpenRow);
    open.push({ id: INTRO_SECTION, label: STORY_WORDS.glance, rows });
    rows.forEach(pushOpen);
  }

  for (const g of groups) {
    const sec = g.sec, sid = g.id, isCustom = custom.has(sid), placement = placementOf(sec);
    const part = partOf.get(sid) || null;
    const { heading, label } = sectionHeading(sec, s, route);
    const entries = g.entries.filter(e => e.row.id !== heroId);
    const inOrder = [...entries].sort(byOrder);
    const sorted = sortEntries(entries, s);
    nextCandidates.push(...inOrder.filter(e => roleOf(e) === 'next'));
    const lead = sec.lead && inOrder.some(e => e.row.id === sec.lead) && has(sec.lead) ? sec.lead : firstOf(inOrder, 'lead');
    const captionsAll = inOrder.filter(e => roleOf(e) === 'caption' && has(e.row.id)).map(e => e.row.id);
    const learnerRows = learner ? inOrder.filter(e => roleOf(e) === 'learner' && has(e.row.id)).map(e => e.row.id) : [];
    const body = [], details = [], numbers = [], detailsHere = [], openHere = [];
    for (const e of sorted) {
      const id = e.row.id, role = roleOf(e);
      if (role === 'lead' || role === 'caption' || role === 'learner' || role === 'next') continue;
      if (role === 'evidence') { if (!learner && has(id)) numbers.push(id); continue; }
      if (!has(id)) continue;
      if (role === 'detail') { if (!learner) details.push(id); if (isOpenRow(id) && !isCustom && placement === 'body') openHere.push(id); else detailsHere.push(id); continue; }
      if (isOpenRow(id) && !isCustom && placement === 'body') openHere.push(id); else body.push(id);
    }
    const ids = new Set(g.entries.map(e => e.row.id));
    const allIds = [...ids].filter(has);
    const connectiveDef = def.connective ? def.connective[sid] : null;
    const connective = typeof connectiveDef === 'string' ? connectiveDef : connectiveDef && typeof connectiveDef === 'object' ? connectiveDef[s.level] || null : null;
    const base = {
      id: sid, label, heading, part: part && part.id !== OPEN_PART && part.id !== DRAWER_PART ? part.id : null, placement, connective,
      figure: null, figures: [], lead: null, captions: [], key: [], more: [], learnerRows: [],
      body, details, numbers, drawerRows: [], all: allIds, tabs: sec.drawer || DRAWER_TABS, show: false,
    };

    if (placement === 'inputs') {
      // "What this page takes from outside (n)": every row of the section with a text at this level, its lead and learner rows above them
      const rowsHere = sorted.filter(e => !['lead', 'caption', 'learner', 'next', 'evidence'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id);
      inputs.rows.push(...rowsHere);
      if (lead && !inputs.lead) inputs.lead = lead;
      inputs.learnerRows.push(...learnerRows);
      rowsHere.forEach(id => { rowSection.set(id, '__inputs'); put(id, 'inputs', '__inputs'); });
      [lead, ...learnerRows].filter(Boolean).forEach(id => put(id, 'inputs', '__inputs'));
      sections.push({ ...base, lead, learnerRows, drawerRows: rowsHere });
      continue;
    }
    if (placement === 'open') {
      // a section of the open part is a group of the open fold: its lead, then every row with a text (v15's perspectives, questions, notes)
      const rowsHere = [...learnerRows, ...sorted.filter(e => ['result', 'detail', 'caption'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id)];
      const pairIds = sec.pairs === 'splitFrom' ? [...learnerRows, ...inOrder.filter(e => ['result', 'detail', 'caption'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id)] : null;
      const grp = { id: sid, label, lead, rows: pairIds || rowsHere, part: OPEN_PART, pairs: pairIds ? pairsOf(pairIds) : null, group: sec.group || null };
      const gp = sec.group ? (part.groups || []).find(x => x.id === sec.group) : null;
      if (sec.group && lastPartGroup && lastPartGroup.groupId === sec.group) { lastPartGroup.sub.push(grp); lastPartGroup.rows.push(...grp.rows); }
      else if (sec.group) { lastPartGroup = { id: `group-${sec.group}`, groupId: sec.group, label: titleIn(gp && gp.title, s) || label, rows: [...grp.rows], sub: [grp] }; open.push(lastPartGroup); }
      else if (grp.rows.length || lead) { lastPartGroup = null; open.push(grp); }
      grp.rows.forEach(id => { rowSection.set(id, '__open'); put(id, 'open', '__open'); if (isOpenRow(id)) openRows.push(id); });
      if (lead) put(lead, 'open', '__open');
      sections.push({ ...base, lead, learnerRows, body: grp.rows.filter(id => !isOpenRow(id)), drawerRows: grp.rows });
      continue;
    }

    // body (and reference) sections: figure, captions, key results, More statements
    const explicit = placement === 'body'
      ? figureList(sec.figure).filter(f => !usedFigures.has(f)).map(f => figuresById()?.get(f)).filter(drawable).map(f => f.id) : [];
    const byCaption = placement === 'body'
      ? figs.filter(f => f.captionRow && ids.has(f.captionRow) && !assigned.has(f.id) && !usedFigures.has(f.id) && !explicit.includes(f.id) && drawable(f)).map(f => f.id) : [];
    const figures = [...explicit, ...byCaption];
    figures.forEach(f => usedFigures.add(f));
    const captions = figures.length ? captionsAll : [];
    const orphanCaptions = figures.length ? [] : captionsAll;
    const k = keyOf(sec, s);
    const inList = k.list ? new Set(k.list) : null;
    const keyPool = inList ? body.filter(id => inList.has(id)) : body;
    const restPool = inList ? body.filter(id => !inList.has(id)) : [];
    const pool = [...learnerRows, ...keyPool, ...restPool];
    const n = placement === 'reference' ? 0 : learner ? (k.n ?? KEY_RESULTS.learner) : k.n == null ? keyPool.length : k.n;
    const key = isCustom ? body : pool.slice(0, n);
    const more = isCustom ? [] : [...pool.slice(n), ...detailsHere, ...orphanCaptions];
    const shownRows = [...(lead ? [lead] : []), ...captions, ...key, ...more];
    let show = learner ? shownRows.length > 0 : shownRows.length > 0 || figures.length > 0 || numbers.length > 0;
    if (isCustom) show = show || allIds.length > 0;
    const drawerRows = [...captions, ...key, ...more, ...numbers];
    drawerRows.forEach(id => rowSection.set(id, sid));
    if (lead) put(lead, 'lead', sid);
    captions.forEach(id => put(id, 'caption', sid));
    key.forEach(id => put(id, 'key', sid));
    more.forEach(id => put(id, placement === 'reference' ? 'reference' : 'more', sid));
    numbers.forEach(id => put(id, 'drawer', sid));
    const model = { ...base, figure: figures[0] || null, figures, lead, captions, key, more, learnerRows, drawerRows, show };
    if (placement === 'reference') { reference.push({ ...model, show: show && (key.length + more.length > 0) }); sections.push({ ...model, show: false }); continue; }
    sections.push(model);
    results += body.length + learnerRows.length;
    if (openHere.length) {
      if (part && parts.length) {
        let grp = openByPart.get(part.id);
        if (!grp) { grp = { id: part.id, label: titleIn(part.title, s) || label, rows: [] }; openByPart.set(part.id, grp); open.push(grp); }
        grp.rows.push(...openHere);
      } else open.push({ id: sid, label, rows: openHere });
      openHere.forEach(pushOpen);
    }
  }
  // the open groups of the body come first (in page order), then the groups of the open part (in its order)
  const isPartGroup = gr => gr.part === OPEN_PART || !!gr.groupId;
  const openOrdered = [...open.filter(gr => !isPartGroup(gr)), ...open.filter(isPartGroup)];
  const nx = [...nextCandidates].sort(byOrder).find(e => has(e.row.id));
  intro.next = named('next') || (nx ? nx.row.id : null);
  if (intro.next) put(intro.next, 'next', '__next');
  const bodyParts = [];
  for (const sec of sections) {
    if (!sec.show || sec.placement !== 'body' || !sec.part) continue;
    const last = bodyParts[bodyParts.length - 1];
    if (last && last.id === sec.part) last.sections.push(sec.id);
    else { const p = parts.find(x => x.id === sec.part); bodyParts.push({ id: sec.part, title: titleIn(p && p.title, s), sections: [sec.id] }); }
  }
  const hasInputs = inputs.rows.length > 0 || inputs.learnerRows.length > 0;
  return {
    def, route, hero, intro, parts: bodyParts, sections, open: openOrdered, openRows, reference,
    inputs: hasInputs ? inputs : null, rowSection, place, results, learnerShort: learner && results < 3,
  };
}

/**
 * The lead of a page for a card elsewhere (interface 27; the home's "The Atlas, chapter by chapter", docs/STORY_PLAN.md §2.7). STABLE SIGNATURE:
 *   pageLead(route, settings = { mode, level, lens }) → { id, register, route } | null
 * `id` is the page's lead: pages.json `intro.lead`, else the row of role `lead` in its reserved section `intro`, visible in the mode;
 * `register` is 'short' when the row has a short text at this level, else 'full' (textFor never falls back across levels: at learner level the
 * row needs a learner text). null when the page has no lead with a text at this level. Render it with Statement (id, register), never as free text.
 */
export function pageLead(route, settings) {
  const s = { mode: 'phys', level: 'research', lens: null, ...(settings || {}) };
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const entries = (rowsByPage()?.get(route) || []).filter(e => e.so.section === INTRO_SECTION && roleOf(e) === 'lead' && visibleIn(e.row, s.mode)).sort(byOrder);
  const named = def.intro && def.intro.lead && rowsById()?.get(def.intro.lead);
  const ids = [...(named && visibleIn(named, s.mode) ? [named.id] : []), ...entries.map(e => e.row.id)];
  for (const id of ids) {
    if (hasText(id, { ...s, register: 'short' })) return { id, register: 'short', route };
    if (hasText(id, { ...s, register: 'full' })) return { id, register: 'full', route };
  }
  return null;
}

/** the rows a route shows, for the lens picker's counts */
export function rowsOfMatch(match) {
  if (!match) return [];
  if (match.name === 'cell') {
    const key = cellKeyOf(match.key);
    return key ? (rowsByCell()?.get(key) || []) : [];
  }
  if (match.page == null || match.name === 'lens' || match.name === 'glossary') return [];
  return [...new Set((rowsByPage()?.get(match.page) || []).map(e => e.row.id))];
}
/** lens key → number of the given rows that have a text in that lens at this level */
export function lensCounts(rowIds, level) {
  const idx = lensTextIndex();
  const rd = lensReadingsIndex();
  const out = new Map();
  if (!idx && !rd) return out;
  const lenses = new Set([...(idx ? idx.keys() : []), ...(rd ? rd.keys() : [])]);
  for (const lens of lenses) {
    const set = idx && idx.get(lens) ? idx.get(lens).get(level) : null;
    const byRow = rd ? rd.get(lens) : null;
    // a row counts when it has a text in the lens at this level, or a reading in the lens (readings with a formula are hidden at learner level)
    const hasReading = id => { const rs = byRow && byRow.get(id); if (!rs || !rs.length) return false; return level === 'learner' ? rs.some(r => !/[$\\^_=]/.test(String(r.term || ''))) : true; };
    out.set(lens, rowIds.filter(id => (set && set.has(id)) || hasReading(id)).length);
  }
  return out;
}

// ---------------------------------------------------------------- links to rows
const QUESTION_RE = /^Q[A-Z]?\d+[a-z]?$/;
/** where a row (or a theorem / question id) lives: { path, at } */
export function rowHome(id) {
  if (/^T\d+$/.test(id)) return { path: 'logbook/theorems', at: id };
  if (/^CAND-/.test(id)) return { path: 'logbook/candidates', at: id };
  const r = rowsById()?.get(id) || rowsById()?.get(id.replace(/[a-z]$/, ''));
  if (r && r.shownOn && r.shownOn.length) {
    const so = [...r.shownOn].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
    return { path: so.page, at: r.id };
  }
  if (QUESTION_RE.test(id) || (peekTable('questions') || []).some(q => q.id === id)) return { path: 'logbook/questions', at: id };
  return { path: 'logbook/register', at: id };
}

// ---------------------------------------------------------------- cells
/** "1,3" → "(1,3,0)"; "1,n-1,0" → "(1,n-1,0)"; "all n" → "all n"; "row 8" → "row 8" */
export function cellKeyOf(key) {
  if (!key) return null;
  const k = key.trim();
  const m = /^(\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?$/.exec(k);
  if (m) return `(${m[1]},${m[2]},${m[3] || 0})`;
  if (/^[\w+\- ]+(,[\w+\- ]+)+$/.test(k)) return `(${k})`;
  return k;
}

const CELL_RE = /Cl\((\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?\)/;
/** the 25 cards of the cells page: one per first line of an ATL row, with its further lines; title = the text up to the cell name */
export function cellCards(s) {
  const entries = (rowsByPage()?.get('cells') || []).filter(e => e.so.section === 'cards' && visibleIn(e.row, s.mode));
  entries.sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0));
  const cards = [], byPrimary = new Map();
  for (const e of entries) {
    const pid = e.row.splitFrom || e.row.id;
    if (!byPrimary.has(pid)) { const c = { primary: pid, lines: [] }; byPrimary.set(pid, c); cards.push(c); }
    byPrimary.get(pid).lines.push(e.row.id);
  }
  const out = [];
  for (const c of cards) {
    const text = textFor(c.primary, s);
    if (!text) continue;
    const row = rowsById().get(c.primary);
    const m = CELL_RE.exec(text);
    let title, sig = null, route = null, cellLabel = null;
    if (m && m.index < 160) {
      let end = m.index + m[0].length;
      const iso = /^(?:[≅=][^\s,;]+)+/.exec(text.slice(end));
      if (iso) end += iso[0].length;
      title = text.slice(0, end).replace(/[.,;:]+$/, '');
      sig = [+m[1], +m[2], +(m[3] || 0)];
      route = `cells/${sig[0]},${sig[1]}${sig[2] ? ',' + sig[2] : ''}`;
    } else {
      const cut = /[,.:;]/.exec(text);
      title = cut && cut.index > 0 && cut.index < 90 ? text.slice(0, cut.index) : text.slice(0, 80).replace(/\s+\S*$/, '') + '…';
      cellLabel = (row && row.cells && row.cells[0]) || null;
      route = cellLabel ? cellRoute(cellLabel) : null;
      // a card whose text names no Cl(p,q) but whose row names one cell "(p,q,r)" is that cell's card
      const m2 = cellLabel ? /^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$/.exec(cellLabel) : null;
      if (m2) { sig = [+m2[1], +m2[2], +m2[3]]; cellLabel = null; }
    }
    out.push({ ...c, title, sig, route, cellLabel, more: c.lines.length - 1 });
  }
  return out;
}

/** the clock of a signature, c = p − q mod 8 (null bits weigh 0), as the kernel's Gauss sum gives it (cellmath.js) */
const clockOfSig = sig => (sig ? clockOf(sig[0], sig[1], sig[2]) : null);

/**
 * The cards laid out as the lattice: one column per n = p + q + r (0 … the largest n of a card, at least 8), and in a column the cards
 * ordered by their clock c, then by p (larger first), then as the page orders them. Cards that name no single cell (a family "(1,n-1,0)",
 * "all n") are `loose`. → { columns, placed: [{ card, n, c, col, row }], loose: [card] }; col and row count from 1.
 */
export function latticeLayout(cards) {
  const placed = [], loose = [];
  cards.forEach((card, i) => {
    if (!card.sig) { loose.push(card); return; }
    const [p, q, r] = card.sig;
    placed.push({ card, n: p + q + r, c: clockOfSig(card.sig), p, i });
  });
  const columns = Math.max(9, ...placed.map(x => x.n + 1));
  placed.sort((a, b) => a.n - b.n || a.c - b.c || b.p - a.p || a.i - b.i);
  const depth = new Map();
  for (const x of placed) { const k = (depth.get(x.n) || 0) + 1; depth.set(x.n, k); x.col = x.n + 1; x.row = k; }
  return { columns, placed: placed.map(({ card, n, c, col, row }) => ({ card, n, c, col, row })), loose };
}

// ---------------------------------------------------------------- the learner's "How do we know?" line under a hero
const plural2 = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const scriptName = e => String(e.script || e.check || '').split('/').pop();
/**
 * One connective line from a row's evidence and status (numbers from rows.json, no law stated): the scripts that ran (named once each),
 * those only read, the inputs it uses; "checked by" only when the status is proved by the Atlas or standard.
 * e.g. "Checked by 6 scripts that ran; 1 input needed."  → string, or null for a row that is not in the tables.
 */
export function howWeKnow(rowId) {
  const r = rowsById()?.get(rowId);
  if (!r) return null;
  const ran = new Set(), read = new Set();
  for (const e of r.evidence || []) { const k = scriptName(e); if (!k) continue; if (e.mode === 'ran') ran.add(k); else if (e.mode === 'read') read.add(k); }
  for (const k of ran) read.delete(k);
  const inputs = new Set((r.depends || []).filter(d => d.rel === 'uses-input').map(d => d.id));
  const st = (statusOf(rowId) || {}).status;
  const parts = [];
  if (ran.size) parts.push(st === 'proved-by-atlas' || st === 'standard' ? `Checked by ${plural2(ran.size, 'script')} that ran` : `${plural2(ran.size, 'script')} ran on it`);
  if (read.size) parts.push(ran.size ? `${read.size} more read, not run here` : `Read in ${plural2(read.size, 'script')}, not run here`);
  if (!ran.size && !read.size) parts.push('No script is recorded for it');
  if (inputs.size) parts.push(`${plural2(inputs.size, 'input')} needed`);
  return parts.join('; ') + '.';
}

// ---------------------------------------------------------------- the map of the steps
let graphMemo = null;
/**
 * The steps as a graph (06 /steps): the twenty steps of steps.json that have a page, and an edge B → A when a row shown on step A derives
 * from a row shown on step B (rows.json `depends`, rel "derives"); `links` counts the pairs of rows behind an edge.
 * → { nodes: [step records by number], edges: [{ from, to, links }] } or null while the tables load.
 */
export function stepGraph() {
  const rows = peekTable('rows'), steps = peekTable('steps'), pages = pagesByRoute();
  if (!rows || !steps || !pages) return null;
  if (graphMemo && graphMemo.rows === rows && graphMemo.steps === steps && graphMemo.pages === pages) return graphMemo.value;
  const nodes = steps.filter(st => isStep(st) && pages.has(st.route)).sort((a, b) => a.no - b.no);
  const routes = new Set(nodes.map(n => n.route));
  const pagesOf = new Map(rows.map(r => [r.id, new Set((r.shownOn || []).map(so => so.page))]));
  const pairs = new Map();
  for (const r of rows) {
    for (const so of r.shownOn || []) {
      if (!routes.has(so.page)) continue;
      for (const d of r.depends || []) {
        if (d.rel !== 'derives') continue;
        for (const from of pagesOf.get(d.id) || []) {
          if (from === so.page || !routes.has(from)) continue;
          const k = `${from}\u0001${so.page}`;
          if (!pairs.has(k)) pairs.set(k, new Set());
          pairs.get(k).add(`${r.id}\u0001${d.id}`);
        }
      }
    }
  }
  const no = new Map(nodes.map(n => [n.route, n.no]));
  const edges = [...pairs].map(([k, set]) => { const [from, to] = k.split('\u0001'); return { from, to, links: set.size }; })
    .sort((a, b) => no.get(a.to) - no.get(b.to) || no.get(a.from) - no.get(b.from));
  const value = { nodes, edges };
  graphMemo = { rows, steps, pages, value };
  return value;
}

// ---------------------------------------------------------------- steps
function dominantField(route) {
  const n = new Map();
  for (const e of rowsByPage()?.get(route) || []) for (const f of e.row.fields || []) n.set(f, (n.get(f) || 0) + 1);
  let best = null, bc = -1;
  for (const f of FIELD_ORDER) if ((n.get(f) || 0) > bc) { best = f; bc = n.get(f) || 0; }
  return bc > 0 ? best : null;
}
/** one card per step page (steps.json, without the shape chapters), with counts from the page model at these settings */
export function stepCards(s) {
  const steps = (peekTable('steps') || []).filter(st => isStep(st) && pagesByRoute()?.has(st.route));
  return steps.map(st => {
    const m = buildPageModel(st.route, s);
    const body = m.sections.flatMap(sec => sec.body);
    const provedAtlas = body.filter(id => (statusOf(id) || {}).status === 'proved-by-atlas').length;
    return { step: st, route: st.route, hero: m.hero, results: m.results, open: m.openRows.length, provedAtlas, stage: st.stage, field: dominantField(st.route) };
  });
}
