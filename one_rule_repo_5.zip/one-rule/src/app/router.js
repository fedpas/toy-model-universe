// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/router.js — hash routes (#/, #/atlas, #/rule, #/cells, #/cells/p,q, #/clock, #/light, #/steps, #/steps/<id>, #/shapes, #/matter,
// #/lenses, #/lenses/<key>, #/logbook[/<tab>], #/ask, #/glossary, #/explore[/<slug>]) and links that carry the current settings.
// The landing (content/story/landing.json; decision A50, STORY_PLAN §2.7, interface 30): `#/` shows the page landing.json names as its home
// (the Explore home), the start page of the full Atlas moves to the address its `routes` give it (`#/atlas`, titled by its `titles`), and
// `#/explore` keeps working. applyLanding() applies landing.json to the loaded tables at run time — the route renames on pages.json and on
// every shownOn entry, the page titles — as tools/merge_story.mjs applies the renames on disk: once the merge has run there is nothing left
// to rename, and only the titles are applied here.
import { useMemo, useSyncExternalStore } from 'react';
import { getHash, parseHash, pushHash, subscribeLocation } from './location.js';
import { settingsQuery } from './settings.js';
import { pagesByRoute, peekTable, primeTable } from './store.js';
import LANDING from '../../content/story/landing.json';

// ---------------------------------------------------------------- the landing (content/story/landing.json)
const L = LANDING && typeof LANDING === 'object' && !Array.isArray(LANDING) ? LANDING : {};
const str = x => typeof x === 'string';
/** route in the tables → its address: the start page '' → 'atlas' */
const RENAMES = new Map(Object.entries(L.routes && typeof L.routes === 'object' ? L.routes : {}).filter(([a, b]) => str(b) && b !== a));
/** the titles landing.json gives a page, by its address: { phys, math, learner } */
const TITLES = new Map(Object.entries(L.titles && typeof L.titles === 'object' ? L.titles : {}).filter(([, t]) => t && typeof t === 'object'));
/** the address of the start page of the full Atlas ("The Atlas"): '' unless landing.json moves it */
export const ATLAS_ROUTE = RENAMES.has('') ? RENAMES.get('') : '';
/** the page `#/` shows: landing.json's home (the Explore home) once the start page has moved away from '', else none */
const HOME = ATLAS_ROUTE && str(L.home) && L.home && L.home !== ATLAS_ROUTE ? L.home : null;

/** the main pages for the home's chapter cards, in landing.json's order (v15's): the routes the tables have */
export function landingChapters() {
  const pages = pagesByRoute();
  return (Array.isArray(L.chapters) ? L.chapters : []).filter(r => str(r) && (!pages || pages.has(r)));
}

const sameTitle = (a, b) => !!a && Object.entries(b).every(([k, v]) => a[k] === v);
let landed = null;
/**
 * landing.json on the loaded tables (plan §3.3, done at run time while tools/merge_story.mjs has not renamed on disk): a page whose route
 * it renames, when no page holds the new route yet, takes the new route, and every shownOn entry that names the old route follows it (also
 * when the merge renamed the page and left a placement behind); a page it gives a title takes that title. New arrays replace the cached
 * tables (the indexes follow their identity); idempotent, cheap once applied. Returns true when it changed a table.
 */
export function applyLanding() {
  const pages = peekTable('pages'), rows = peekTable('rows');
  if (!Array.isArray(pages) || !Array.isArray(rows)) return false;
  if (landed && landed.pages === pages && landed.rows === rows) return false;
  const have = new Set(pages.map(p => p && p.route));
  const ren = new Map([...RENAMES].filter(([from, to]) => have.has(from) && !have.has(to)));
  let pagesOut = pages, rowsOut = rows;
  const renamed = pages.map(p => {
    if (!p || typeof p !== 'object') return p;
    let q = ren.has(p.route) ? { ...p, route: ren.get(p.route) } : p;
    const t = TITLES.get(q.route);
    if (t && !sameTitle(q.title, t)) q = { ...q, title: { ...(q.title || {}), ...t } };
    return q;
  });
  if (renamed.some((p, i) => p !== pages[i])) pagesOut = renamed;
  // a placement follows its page: it names a route no page holds any more, and a page holds the new one (renamed here, or by the merge)
  const after = new Set(renamed.map(p => p && p.route));
  const moves = new Map([...RENAMES].filter(([from, to]) => !after.has(from) && after.has(to)));
  if (moves.size) {
    const moved = rows.map(r => {
      const so = r && Array.isArray(r.shownOn) ? r.shownOn : null;
      if (!so || !so.some(e => e && moves.has(e.page))) return r;
      return { ...r, shownOn: so.map(e => (e && moves.has(e.page) ? { ...e, page: moves.get(e.page) } : e)) };
    });
    if (moved.some((r, i) => r !== rows[i])) rowsOut = moved;
  }
  if (pagesOut !== pages) primeTable('pages', pagesOut);
  if (rowsOut !== rows) primeTable('rows', rowsOut);
  landed = { pages: pagesOut, rows: rowsOut };
  return pagesOut !== pages || rowsOut !== rows;
}

/** the route in the tables of the start page of the full Atlas: its address once landing.json is applied, '' before */
export function atlasPage() {
  const pages = pagesByRoute();
  return pages && !pages.has(ATLAS_ROUTE) && pages.has('') ? '' : ATLAS_ROUTE;
}

// ---------------------------------------------------------------- routes
/** path → what to render */
export function matchRoute(path) {
  const segs = String(path || '').split('/').filter(Boolean);
  const pages = pagesByRoute();
  if (!segs.length) {
    // the landing: the home of landing.json (the Explore home) when the tables have it (or are still loading); else the start page
    if (HOME && (!pages || pages.has(HOME))) return { ...matchRoute(HOME), landing: true };
    return { name: 'zero', page: atlasPage() };
  }
  const route = segs.join('/');
  if (ATLAS_ROUTE && route === ATLAS_ROUTE) return { name: 'zero', page: atlasPage() };
  const [a, b] = segs;
  if (a === 'cells') return b ? { name: 'cell', key: segs.slice(1).join('/') } : { name: 'cells', page: 'cells' };
  if (a === 'steps' && !b) return { name: 'steps', page: 'steps' };
  if (a === 'lenses') return b ? { name: 'lens', key: b, page: 'lenses' } : { name: 'lenses', page: 'lenses' };
  if (a === 'logbook') return { name: 'logbook', page: 'logbook', tab: b || null };
  if (a === 'ask' && !b) return { name: 'ask', page: 'ask' };
  if (a === 'glossary' && !b) return { name: 'glossary', page: 'glossary' };
  if (a === 'explore') return b ? { name: 'leaf', page: route } : { name: 'explore', page: 'explore' };
  if (pages && pages.has(route)) return { name: 'page', page: route };
  return { name: 'notfound', path };
}

/** is an address a page of Explore: #/explore, #/explore/<slug>, and #/ while it shows the Explore home */
export function inExplore(path) {
  const p = String(matchRoute(path).page ?? '');
  return p === 'explore' || p.startsWith('explore/');
}

export function parseRoute(hash) {
  const { path, query } = parseHash(hash);
  return { path, query, at: query.get('at'), match: matchRoute(path) };
}

/** React hook: the current route { path, query, at, match } — matched again once pages.json is loaded (generic routes come from it) */
export function useRoute() {
  const hash = useSyncExternalStore(subscribeLocation, getHash, getHash);
  const pages = peekTable('pages');
  return useMemo(() => parseRoute(hash), [hash, pages]);
}

/** the address of a route under the given settings, with optional extra parameters (e.g. { at: 'GRV-012' }) */
export function buildHref(path, settings, extra) {
  const q = settingsQuery(settings || {});
  if (extra) for (const [k, v] of Object.entries(extra)) if (v != null && v !== '') q.set(k, String(v));
  const qs = q.toString();
  const p = String(path || '').replace(/^\/+/, '');
  return '#/' + p.split('/').map(s => encodeURIComponent(s).replace(/%2C/gi, ',')).join('/') + (qs ? '?' + qs : '');
}

export function navigate(path, settings, extra) { pushHash(buildHref(path, settings, extra)); }

/** route of a cell page from a cells entry: "(1,3,0)" → "cells/1,3"; "(1,n-1,0)" → "cells/1,n-1,0"; "all n" → "cells/all n" */
export function cellRoute(cell) {
  const m = /^\((\d+),(\d+),(\d+)\)$/.exec(cell);
  if (m) return `cells/${m[1]},${m[2]}${m[3] !== '0' ? ',' + m[3] : ''}`;
  return 'cells/' + cell.replace(/^\(|\)$/g, '');
}
