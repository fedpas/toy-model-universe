// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/PageView.jsx — the frame every page shares (06; docs/STORY_PLAN.md §2.1–2.3): it renders a page model (src/app/queries.js) as
//   header → intro (the page's lead story row, one paragraph; at learner level its learner words) → hero (statement, figure, the figure's captions;
//   the learner's "How do we know?") → at a glance (the intro's result rows, v15's page strip, A57) → parts (h2) over sections (h3), or sections
//   one after another → open items (grouped by part) → the sections kept in the drawer part, folded → "What this page takes from outside (n)" →
//   the next line above the links to the previous and next page.
// Learner level: the same frame with each part's learner words; `learner` rows only there; no formula anywhere (D5). Research level: everything,
// folded where long. The drawers, the open fold, the "More statements" folds and the inputs fold open from the statements' "›" and from a deep link.
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useSettings } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { glossaryFor } from '../app/glossary.js';
import { rowsById } from '../app/store.js';
import { STORY_WORDS } from '../app/vocab.js';
import { PageContext } from '../components/PageContext.js';
import PageHeader from '../components/PageHeader.jsx';
import Hero from '../components/Hero.jsx';
import Section, { drawerRowsOf } from '../components/Section.jsx';
import Part from '../components/Part.jsx';
import Lead from '../components/Lead.jsx';
import MoreFold from '../components/MoreFold.jsx';
import InputsFold from '../components/InputsFold.jsx';
import OpenFold from '../components/OpenFold.jsx';
import PrevNext from '../components/PrevNext.jsx';
import Statement from '../components/Statement.jsx';
import Drawer from '../components/Drawer.jsx';
import '../styles/story.css';

export function LearnerNotice() {
  const s = useSettings();
  return (
    <div className="notice" role="note">
      <p className="notice__text">This page has no plain-words version yet.</p>
      <button type="button" className="btn" onClick={() => s.set({ level: 'research' })}>Show the research version</button>
    </div>
  );
}

const NO_INTRO = { lead: null, next: null, glance: [], more: [], learnerRows: [] };
/** a part's first section named as the part is not titled again under it ("Seven papers" once) */
const sameName = (a, b) => !!a && !!b && a.trim().toLowerCase() === b.trim().toLowerCase();
const INTRO_MORE = 'more-__intro';

/** the rows of the page in reading order, the visible ones first (the glossary underlines a term in the first statement that holds it) */
function readingRows(model, shown, custom) {
  const intro = model.intro || NO_INTRO, ids = [];
  ids.push(model.hero && model.hero.id, intro.lead, ...intro.learnerRows, ...((model.hero && model.hero.captions) || []), ...intro.glance);
  for (const sec of shown) {
    if (custom && custom[sec.id]) continue;
    if (Array.isArray(sec.key)) ids.push(sec.lead, ...(sec.captions || []), ...sec.key); else ids.push(...sec.body);
  }
  for (const sec of shown) if (Array.isArray(sec.more) && !(custom && custom[sec.id])) ids.push(...sec.more);
  ids.push(...intro.more);
  for (const g of model.open) { ids.push(g.lead, ...g.rows); for (const x of g.sub || []) ids.push(x.lead); }
  for (const sec of model.reference || []) ids.push(...(sec.key || []), ...(sec.more || []));
  if (model.inputs) ids.push(model.inputs.lead, ...model.inputs.learnerRows, ...model.inputs.rows);
  return [...new Set(ids.filter(Boolean))];
}

export default function PageView({ model, heading, needs, headerExtra, heroAside, afterHero, afterSections, custom, drawers = true, prevNext, learnerNotice = true }) {
  const s = useSettings();
  const route = useRoute();
  const [openSet, setOpenSet] = useState(() => new Set());
  const [focus, setFocus] = useState({ sid: null, row: null, nonce: 0 });
  const [foldOpen, setFoldOpen] = useState(false);
  const [folds, setFolds] = useState(() => new Set());

  const intro = model.intro || NO_INTRO;
  const shown = model.sections.filter(sec => sec.show && (!sec.placement || sec.placement === 'body'));
  const order = useMemo(() => readingRows(model, shown, custom), [model]); // eslint-disable-line react-hooks/exhaustive-deps
  const gloss = useMemo(() => glossaryFor(order, s), [order, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps

  const setDrawerOpen = useCallback((sid, open) => {
    setOpenSet(prev => { const n = new Set(prev); if (open) n.add(sid); else n.delete(sid); return n; });
  }, []);
  const setFold = useCallback((id, open) => {
    setFolds(prev => { if (prev.has(id) === !!open) return prev; const n = new Set(prev); if (open) n.add(id); else n.delete(id); return n; });
  }, []);
  const openEvidence = useCallback(rowId => {
    const sid = model.rowSection.get(rowId);
    if (!sid) return;
    if (sid === '__open') setFoldOpen(true);
    if (sid === '__inputs') setFold('__inputs', true);
    setOpenSet(prev => new Set(prev).add(sid));
    setFocus(f => ({ sid, row: rowId, nonce: f.nonce + 1 }));
  }, [model, setFold]);
  // at learner level a drawer ("How do we know?") exists only where a script checks the row; a story row cites nothing and has no drawer line
  const learnerLevel = s.level === 'learner';
  const hasDrawer = useCallback(rowId => {
    if (!drawers || !model.rowSection.has(rowId)) return false;
    const r = rowsById() && rowsById().get(rowId);
    if (r && r.kind === 'story') return false;
    if (!learnerLevel) return true;
    return !!(r && (r.evidence || []).length);
  }, [model, drawers, learnerLevel]);
  const ctx = useMemo(() => ({ openEvidence: drawers ? openEvidence : null, hasDrawer, gloss }), [openEvidence, hasDrawer, gloss, drawers]);

  // a deep link with at=<row|section> brings that place into view, opening the fold or the drawer that holds it
  useEffect(() => {
    const at = route.at;
    if (!at || typeof document === 'undefined') return undefined;
    const where = model.place ? model.place.get(at) : null;
    const sid = model.rowSection.get(at);
    if (where) {
      if (where.where === 'more') setFold(`more-${where.sid}`, true);
      else if (where.where === 'reference') setFold(`ref-${where.sid}`, true);
      else if (where.where === 'intro-more') setFold(INTRO_MORE, true);
      else if (where.where === 'open') setFoldOpen(true);
      else if (where.where === 'inputs') setFold('__inputs', true);
      else if (where.where === 'drawer' && drawers) openEvidence(at);
    } else {
      const inBody = shown.some(sec => sec.body.includes(at)) || (model.hero && model.hero.id === at);
      if (sid === '__open') setFoldOpen(true);
      else if (sid && !inBody && drawers) openEvidence(at);
    }
    const t = setTimeout(() => {
      const el = document.getElementById(`row-${at}`) || document.getElementById(`sec-${at}`);
      if (!el) return;
      for (let p = el.parentElement; p; p = p.parentElement) if (p.tagName === 'DETAILS' && !p.open) p.open = true; // a fold inside a fold (a question's statement)
      el.scrollIntoView({ block: 'start' });
    }, 30);
    return () => clearTimeout(t);
  }, [route.at, model]); // eslint-disable-line react-hooks/exhaustive-deps

  const drawerFor = sid => ({ open: openSet.has(sid), focus: focus.sid === sid ? focus : null });
  const foldProps = id => ({ open: folds.has(id), onToggle: o => setFold(id, o) });

  // the body: consecutive sections of one part under its heading (h2, sections h3); sections without a part follow one another (h2)
  const titles = new Map((model.parts || []).map(p => [p.id, p.title]));
  const blocks = [];
  for (const sec of shown) {
    const pid = sec.part || null, last = blocks[blocks.length - 1];
    if (pid && last && last.pid === pid) last.secs.push(sec); else blocks.push({ pid, secs: [sec] });
  }
  const renderSection = (sec, level) => (
    <Section
      key={sec.id} sec={sec} level={level} drawers={drawers} drawer={drawerFor(sec.id)} onDrawer={setDrawerOpen}
      custom={custom && custom[sec.id]} moreOpen={folds.has(`more-${sec.id}`)} onMore={o => setFold(`more-${sec.id}`, o)}
    />
  );
  const introDrawerRows = drawerRowsOf([...intro.glance, ...intro.more]);
  const introDrawer = drawers && introDrawerRows.length ? (
    <Drawer sid="__intro" rows={introDrawerRows} open={drawerFor('__intro').open} focus={drawerFor('__intro').focus} onToggle={o => setDrawerOpen('__intro', o)} />
  ) : null;
  const hasIntro = !!(intro.lead || intro.learnerRows.length || intro.more.length);

  return (
    <PageContext.Provider value={ctx}>
      <article className="page" data-route={model.route}>
        <PageHeader route={model.route} heading={heading} needs={needs}>{headerExtra}</PageHeader>
        {model.learnerShort && learnerNotice ? <LearnerNotice /> : null}
        {hasIntro ? (
          <div className="intro" id="sec-intro" data-section="intro">
            {intro.lead ? <Lead id={intro.lead} variant="intro" /> : null}
            {intro.learnerRows.map(id => <Lead key={id} id={id} variant="intro-more" />)}
            <MoreFold rows={intro.more} id={INTRO_MORE} {...foldProps(INTRO_MORE)} />
            {intro.glance.length ? null : introDrawer}
          </div>
        ) : null}
        <Hero hero={model.hero} aside={heroAside} />
        {!model.hero && heroAside ? <div className="hero-aside">{heroAside}</div> : null}
        {drawers && model.hero ? (
          <div className="hero__drawer">
            <Drawer sid="__hero" rows={drawerRowsOf([model.hero.id, ...(model.hero.captions || [])])} open={openSet.has('__hero')} focus={focus.sid === '__hero' ? focus : null} onToggle={o => setDrawerOpen('__hero', o)} />
          </div>
        ) : null}
        {intro.glance.length ? (
          <section className="glance" id="sec-glance" aria-labelledby="h-glance" data-outline={STORY_WORDS.glance}>
            <h2 className="glance__title" id="h-glance">{STORY_WORDS.glance}</h2>
            <div className="glance__rows">{intro.glance.map(id => <Statement key={id} id={id} />)}</div>
            {introDrawer}
          </section>
        ) : null}
        {afterHero}
        {blocks.map((b, i) => (b.pid
          ? <Part key={`part-${b.pid}-${i}`} id={b.pid} title={titles.get(b.pid)}>{b.secs.map((sec, k) => renderSection(k === 0 && sameName(sec.heading, titles.get(b.pid)) ? { ...sec, heading: null } : sec, 3))}</Part>
          : b.secs.map(sec => renderSection(sec, 2))))}
        {afterSections}
        <OpenFold groups={model.open} open={foldOpen} onToggle={setFoldOpen} drawers={drawers} drawer={drawerFor('__open')} onDrawer={setDrawerOpen} />
        {(model.reference || []).filter(sec => sec.show).map(sec => (
          <MoreFold key={sec.id} kind="reference" id={`ref-${sec.id}`} label={sec.heading || sec.label} rows={[...sec.key, ...sec.more]} {...foldProps(`ref-${sec.id}`)}>
            {drawers ? <Drawer sid={sec.id} rows={drawerRowsOf([...sec.key, ...sec.more])} numbers={sec.numbers} tabs={sec.tabs} open={drawerFor(sec.id).open} focus={drawerFor(sec.id).focus} onToggle={o => setDrawerOpen(sec.id, o)} /> : null}
          </MoreFold>
        ))}
        <InputsFold inputs={model.inputs} {...foldProps('__inputs')} drawers={drawers} drawer={drawerFor('__inputs')} onDrawer={setDrawerOpen} />
        {prevNext !== null ? <PrevNext route={prevNext || model.route} next={intro.next} /> : null}
      </article>
    </PageContext.Provider>
  );
}
