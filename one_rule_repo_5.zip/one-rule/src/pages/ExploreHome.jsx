// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/ExploreHome.jsx — `#/` (the landing, A50) and `#/explore`: the home of Explore (EXPLORE_PLAN §2.1, STORY_PLAN §2.7), its pages.json
// entry (kind explore-home) in the frame every page shares: the hero row with the clock's live picture, first and wide; then the path of eight
// leaves (always eight cards, in reading order; a leaf without a page is a quiet card with its name and no link), the shelf (only the leaves
// that have a page, each with the path leaf it hangs under), the lens explorers that have a page, "The Atlas, chapter by chapter" (one card per
// main page of content/story/landing.json, in v15's order: the page's title as the link, and under it the page's lead story row, from pageLead
// of src/app/queries.js), and the door to the full Atlas (#/atlas). A card's headline is a row (Statement); the words of this file are names
// and directions. No drawers and no "no plain-words version" notice, as on the Atlas page.
import { useMemo } from 'react';
import { useSettings, textFor } from '../app/content.js';
import { buildPageModel, heroFigure, pageTitle, pageLead, visibleIn } from '../app/queries.js';
import { ATLAS_ROUTE, landingChapters } from '../app/router.js';
import { pagesByRoute, rowsById } from '../app/store.js';
import PageView from './PageView.jsx';
import NotFound from './NotFound.jsx';
import Link from '../components/Link.jsx';
import Statement from '../components/Statement.jsx';
import FigureFrame from '../components/FigureFrame.jsx';
import LeafCard from '../components/LeafCard.jsx';
import { exploreMap, EXPLORE } from '../components/LeafPath.jsx';
import '../styles/explore.css';

function Part({ id, title, line, children }) {
  return (
    <section className="sec xh" id={`sec-${id}`} aria-labelledby={`h-${id}`} data-outline={title}>
      <h2 className="sec__title" id={`h-${id}`}>{title}</h2>
      {line ? <p className="sec__connective" data-connective="section">{line}</p> : null}
      {children}
    </section>
  );
}

// ---------------------------------------------------------------- The Atlas, chapter by chapter
const hasText = (id, s, register) => textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register }) != null;
/**
 * The row a chapter card shows, its register and where it comes from: the page's lead story row, from pageLead(route, settings) (interface
 * 27: { id, register } — the short register where the row has one at this level). A page without a lead — while the story rows are not
 * merged, or where v15 gave the page no intro, or no text of it at this level — shows its hero row instead, in the same registers; a hero
 * row the mode does not show, or without a text at this level, leaves the card with its title alone.
 */
export function chapterRow(route, s) {
  const lead = pageLead(route, s);
  if (lead && lead.id) return { id: lead.id, register: lead.register || 'full', source: 'lead' };
  const def = pagesByRoute()?.get(route);
  const id = def && def.hero ? def.hero.row : null;
  const row = id ? rowsById()?.get(id) : null;
  if (!row || !visibleIn(row, s.mode)) return null;
  const register = hasText(id, s, 'short') ? 'short' : 'full';
  return hasText(id, s, register) ? { id, register, source: 'hero' } : null;
}

function ChapterCard({ route }) {
  const s = useSettings();
  const row = chapterRow(route, s);
  return (
    <li className="leaf-card leaf-card--chapter" data-chapter={route} data-source={row ? row.source : undefined}>
      <h3 className="leaf-card__title"><Link to={route} className="leaf-card__link">{pageTitle(route, s)}</Link></h3>
      {row ? <Statement id={row.id} register={row.register} variant="card" evidence={false} /> : null}
    </li>
  );
}

function HomeMap() {
  const map = exploreMap();
  const heroRow = map.home && map.home.hero ? map.home.hero.row : null;
  const shelf = map.shelf.filter(e => e.page);
  const lenses = map.lenses.filter(e => e.page);
  const chapters = landingChapters();
  return (
    <>
      {map.path.length ? (
        <Part id="path" title={map.path.length === 8 ? 'Eight leaves' : 'The path'} line="Read them in order, or open any.">
          <ol className="leaf-grid leaf-grid--path">
            {map.path.map(e => <LeafCard key={e.slug} entry={e} kind="path" skipRow={heroRow} />)}
          </ol>
        </Part>
      ) : null}
      {shelf.length ? (
        <Part id="shelf" title="On the shelf" line="Each loose leaf hangs under the leaf it needs.">
          <ul className="leaf-grid">
            {shelf.map(e => <LeafCard key={e.slug} entry={e} kind="shelf" />)}
          </ul>
        </Part>
      ) : null}
      {lenses.length ? (
        <Part id="explorers" title="Lens explorers">
          <ul className="leaf-grid">
            {lenses.map(e => <LeafCard key={e.slug} entry={e} kind="lens" />)}
          </ul>
        </Part>
      ) : null}
      {chapters.length ? (
        <Part id="chapters" title="The Atlas, chapter by chapter" line="Each card opens a page of the full Atlas.">
          <ol className="leaf-grid leaf-grid--chapters">
            {chapters.map(r => <ChapterCard key={r} route={r} />)}
          </ol>
        </Part>
      ) : null}
      <nav className="xh-door" aria-label="The full Atlas">
        <Link to={ATLAS_ROUTE} className="btn">Connect to the full Atlas</Link>
      </nav>
    </>
  );
}

export default function ExploreHome() {
  const s = useSettings();
  const model = useMemo(() => buildPageModel(EXPLORE, s), [s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!model) return <NotFound />;
  const title = pageTitle(EXPLORE, s);
  const heading = { eyebrow: title === 'Explore' ? null : 'Explore', title, deck: null };
  // a hero row without a text at this level leaves the hero out; the home keeps its picture (the frame shows it alone)
  const lone = !model.hero ? heroFigure(model.def, s) : null;
  return (
    <div className="xp xp--home">
      <PageView model={model} heading={heading} drawers={false} learnerNotice={false} prevNext={null}
        heroAside={lone ? <FigureFrame id={lone} /> : null} afterSections={<HomeMap />} />
    </div>
  );
}
