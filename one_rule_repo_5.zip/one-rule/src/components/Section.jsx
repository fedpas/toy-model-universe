// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Section.jsx — a section of a page (docs/STORY_PLAN.md §2.2, the section of the page model of src/app/queries.js):
//   title      a name (the overlay's, A53; sectionLabel of the slug for a section without one; none for a section titled false) — h2, or h3 in a part
//   lead       the section's one `lead` story row (Lead)
//   figure     the section's figure (explicit, else placed by its caption row), then its `caption` rows under it and the try line (the section's
//              connective, which names the figure's controls); a wide seed takes the column width (D31); further figures after them
//   key        the first N results (a hairline between them, no cards); a tally row (EQN-006 … EQN-020) drawn by TallyLine (P11's hook)
//   More       "More statements (n)", closed: the other results, then the detail rows (MoreFold)
//   drawer     "Evidence and more", one per section: the statements of the section (story rows have no evidence of their own)
// In the markup the figure comes before the key results (the reading order on a phone); from 960 px a small figure stands in the right column.
// A section the page draws itself (`custom`: the cells' cards, a leaf's notes) and a section of a model built elsewhere (a cell's page) keep the
// frame they had: title, connective, body and figures side by side, the drawer.
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';
import Drawer from './Drawer.jsx';
import Lead, { Caption } from './Lead.jsx';
import MoreFold from './MoreFold.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';
import { rowsById } from '../app/store.js';

const row = id => (isTallyRow(id) ? <TallyLine key={id} id={id} /> : <Statement key={id} id={id} />);
/** the rows a section's drawer lists: its statements, story rows apart (they cite nothing) */
export const drawerRowsOf = ids => ids.filter(id => (rowsById()?.get(id) || {}).kind !== 'story');

function ClassicSection({ sec, H, drawers, drawer, onDrawer, custom }) {
  const hasFigs = sec.figures && sec.figures.length > 0;
  const label = sec.heading === undefined ? sec.label : sec.heading;
  return (
    <section className="sec" id={`sec-${sec.id}`} aria-labelledby={label ? `h-${sec.id}` : undefined} data-outline={label || undefined}>
      {label ? <H className="sec__title" id={`h-${sec.id}`}>{label}</H> : null}
      {sec.lead ? <Lead id={sec.lead} /> : null}
      {sec.connective ? <p className="sec__connective" data-connective="section">{sec.connective}</p> : null}
      <div className={`sec__grid${hasFigs ? ' sec__grid--fig' : ''}`}>
        <div className={`sec__body${custom ? ' sec__body--wide' : ''}`}>
          {custom ? custom(sec) : sec.body.map(row)}
        </div>
        {hasFigs ? <div className="sec__figs">{sec.figures.map(f => <FigureFrame key={f} id={f} />)}</div> : null}
      </div>
      {drawers ? (
        <Drawer
          sid={sec.id}
          rows={sec.body}
          details={sec.details}
          numbers={sec.numbers}
          tabs={sec.tabs}
          open={drawer && drawer.open}
          focus={drawer && drawer.focus}
          onToggle={o => onDrawer && onDrawer(sec.id, o)}
        />
      ) : null}
    </section>
  );
}

export default function Section({ sec, level = 2, drawers = true, drawer, onDrawer, custom, moreOpen = false, onMore }) {
  const H = level === 3 ? 'h3' : 'h2';
  if (custom || !Array.isArray(sec.key)) return <ClassicSection sec={sec} H={H} drawers={drawers} drawer={drawer} onDrawer={onDrawer} custom={custom} />;
  const figs = sec.figures || [];
  const caps = figs.length ? sec.captions || [] : [];
  const more = figs.length ? sec.more || [] : [...(sec.more || []), ...(sec.captions || [])];
  const key = sec.key;
  const body = key.length ? <div className="sec__body">{key.map(row)}</div> : null;
  const tryLine = sec.connective ? <p className="sec__connective" data-connective="section">{sec.connective}</p> : null;
  return (
    <section
      className="sec sec--composed" id={`sec-${sec.id}`} data-section={sec.id}
      aria-labelledby={sec.heading ? `h-${sec.id}` : undefined} aria-label={sec.heading ? undefined : sec.label}
      data-outline={sec.heading || undefined}
    >
      {sec.heading ? <H className="sec__title" id={`h-${sec.id}`}>{sec.heading}</H> : null}
      {sec.lead ? <Lead id={sec.lead} /> : null}
      {figs.length ? (
        <div className={`sec__grid sec__grid--fig${body ? '' : ' sec__grid--solo'}`}>
          <div className="sec__figs">
            <FigureFrame id={figs[0]} />
            {caps.length ? <div className="sec__caps" data-captions={figs[0]}>{caps.map(id => <Caption key={id} id={id} />)}</div> : null}
            {tryLine}
            {figs.slice(1).map(f => <FigureFrame key={f} id={f} />)}
          </div>
          {body}
        </div>
      ) : <>{tryLine}{body}</>}
      <MoreFold rows={more} id={`more-${sec.id}`} open={moreOpen} onToggle={onMore} />
      {drawers ? (
        <Drawer
          sid={sec.id}
          rows={drawerRowsOf([...caps, ...key, ...more])}
          numbers={sec.numbers}
          tabs={sec.tabs}
          open={drawer && drawer.open}
          focus={drawer && drawer.focus}
          onToggle={o => onDrawer && onDrawer(sec.id, o)}
        />
      ) : null}
    </section>
  );
}
