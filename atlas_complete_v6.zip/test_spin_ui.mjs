import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
const K=JSON.parse(fs.readFileSync('/home/claude/ui/selfcheck/spin.json','utf8')).matrix, C=K.counts;
const b=await chromium.launch();const errs=[];
for(const lang of ['en','it']) for(const w of [1100,375]) for(const prof of ['Young Learner','Mathematician']){
 const tag=`${lang}${w}${prof[0]}`;
 const pg=await b.newPage({viewport:{width:w,height:800},acceptDownloads:true});
 pg.on('pageerror',e=>errs.push(`${tag}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${tag} console: ${m.text()}`));
 await pg.goto('file:///home/claude/ui/dist/app.html#equations');await pg.waitForTimeout(300);
 if(lang==='it')await pg.locator('[data-lang="it"]').click();
 await pg.locator(`[data-profile="${prof}"]`).click();await pg.waitForTimeout(200);
 const S='#eq-spin';
 const eb=await pg.locator(`${S} .eyebrow`).textContent(); if(eb!==(lang==='en'?'STEP 11 OF 13 · POINTORS AND THE THREE KINDS OF i':'PASSO 11 DI 13 · POINTOR E I TRE TIPI DI i'))errs.push(`${tag}: eyebrow ${eb}`);
 if(await pg.locator(`${S} .sp-row`).count()!==30)errs.push(`${tag}: rows`);
 if(await pg.locator(`${S} .sp-th`).count()!==6)errs.push(`${tag}: threads`);
 if(await pg.locator(`${S} .sp-view`).count()!==2+18)errs.push(`${tag}: views`);
 if(await pg.locator(`${S} .sp-w`).count()!==8)errs.push(`${tag}: widgets`);
 if(await pg.locator(`${S} .sp-kind`).count()!==4)errs.push(`${tag}: four kinds`);
 // each thread shows its own rows
 for(const th of ['reflect','labels','unit','spaces','pointor','states']){ const n=await pg.locator(`${S} #sp-th-${th} .sp-row`).count(); const e=K.rows.filter(r=>r.thread===th).length; if(n!==e)errs.push(`${tag}: thread ${th} rows ${n}/${e}`); }
 // nav has 14 links
 const nav=await pg.locator('.eq-nav a').count(); if(nav!==14)errs.push(`${tag}: nav ${nav}`);
 // status and source filters
 for(const [k,n] of [['ok',C.ok],['note',C.note],['nc',C.not_checked],['all',C.rows]]){ await pg.locator(`${S} .sp-flt[data-flt="${k}"]`).click(); const c=await pg.locator(`${S} .sp-row`).count(); if(c!==n)errs.push(`${tag}: filter ${k} ${c}/${n}`); }
 for(const k of ['paper','lecture','both','ours','all']){ await pg.locator(`${S} .sp-sflt[data-sflt="${k}"]`).click(); const c=await pg.locator(`${S} .sp-row`).count(); const e=k==='all'?30:K.rows.filter(r=>r.src===k).length; if(c!==e)errs.push(`${tag}: source ${k} ${c}/${e}`); const st=await pg.locator(`${S} .sp-row`).evaluateAll(es=>[...new Set(es.map(x=>x.dataset.src))]); if(k!=='all'&&(st.length!==1||st[0]!==k))errs.push(`${tag}: source ${k} shows ${st}`); }
 await pg.locator(`${S} .sp-search`).fill('S08'); {const ids=await pg.locator(`${S} .sp-row`).evaluateAll(es=>es.map(e=>e.dataset.row)); if(!ids.includes('S08')||ids.length>3)errs.push(`${tag}: search S08 ${ids}`);}
 await pg.locator(`${S} .sp-search`).fill('schmangle'); if(await pg.locator(`${S} .sp-row`).count()<1)errs.push(`${tag}: search schmangle`);
 await pg.locator(`${S} .sp-search`).fill('zzzz-nothing'); if(await pg.locator(`${S} .sp-row`).count()!==0)errs.push(`${tag}: search none`);
 await pg.locator(`${S} .sp-search`).fill('');
 const txt=await pg.locator(`${S} .sp-row-h`).allTextContents(); if(txt.some(x=>/\\[a-zA-Z]/.test(x)))errs.push(`${tag}: raw latex`);
 for(const r of K.rows){ const t=await pg.locator(`${S} #sp-row-${r.id}`).textContent(); if(!t||t.length<40)errs.push(`${tag}: row ${r.id} empty`); }
 // open S08
 await pg.locator(`${S} #sp-row-S08 .sp-row-h`).click();
 const r8=K.rows.find(r=>r.id==='S08');
 if(await pg.locator(`${S} #sp-row-S08 .sp-codeline`).textContent()!==r8.code)errs.push(`${tag}: S08 code`);
 if(await pg.locator(`${S} #sp-row-S08 .sp-cmd`).textContent()!=='python3 spin_selfcheck.py --row S08')errs.push(`${tag}: cmd`);
 const wk=await pg.locator(`${S} #sp-row-S08 .sp-worked`).textContent(); if(!wk.includes(r8.worked.lhs)||!wk.includes('✓'))errs.push(`${tag}: worked ${wk}`);
 await pg.locator(`${S} #sp-row-S08 .sp-row-h`).click(); if(await pg.locator(`${S} #sp-det-S08`).count()!==0)errs.push(`${tag}: row did not close`);
 await pg.locator(`${S} #sp-row-S21 .sp-row-h`).click(); const note=await pg.locator(`${S} #sp-row-S21 .sp-note`).textContent(); if(note.length<80)errs.push(`${tag}: S21 note`);
 if(lang==='it'&&/As printed|common rotor/.test(note))errs.push(`${tag}: English note in Italian`);
 // jump from thread links and findings
 await pg.locator(`${S} #sp-th-spaces .sp-jump`).filter({hasText:'S16'}).click(); await pg.waitForTimeout(100); if(await pg.locator(`${S} #sp-det-S16`).count()!==1)errs.push(`${tag}: jump S16`);
 const fn=await pg.locator(`${S} .sp-finding`).count(); if(fn!==K.findings.length)errs.push(`${tag}: findings ${fn}`);
 const [dl]=await Promise.all([pg.waitForEvent('download'),pg.locator(`${S} .eq-btn`).filter({hasText:lang==='en'?'notes for the authors':'note per gli autori'}).click()]);
 const md=fs.readFileSync(await dl.path(),'utf8'); for(const f of K.findings) if(!md.includes(f.id))errs.push(`${tag}: notes file lacks ${f.id}`); if(dl.suggestedFilename()!=='spin_notes_for_authors.md')errs.push(`${tag}: notes filename`);
 // widgets
 {const W=`${S} .sp-w-reflect`; const sl=pg.locator(`${W} .sp-slider`); await sl.fill('12'); await pg.waitForTimeout(80); let t=await pg.locator(`${W} .sp-state`).textContent(); if(!t.includes('R = −1'))errs.push(`${tag}: reflect 180 ${t}`); if(await pg.locator(`${W} .sp-double`).count()!==1)errs.push(`${tag}: double cover note`);
  await sl.fill('24'); await pg.waitForTimeout(80); t=await pg.locator(`${W} .sp-state`).textContent(); if(!t.includes('R = +1'))errs.push(`${tag}: reflect 360 ${t}`);
  await sl.fill('6'); await pg.waitForTimeout(80); if(!(await pg.locator(`${W} .sp-out`).nth(1).textContent()).includes('180°'))errs.push(`${tag}: reflect double angle`);}
 {const W=`${S} .sp-w-labels`; for(const [d,n] of [[2,2],[4,4],[6,8]]){ await pg.locator(`${W} .eq-chip`).filter({hasText:`d = ${d} `}).click(); const c=await pg.locator(`${W} .sp-class`).count(); if(c!==n)errs.push(`${tag}: labels d=${d} ${c}`); }
  if((await pg.locator(`${W} .sp-checks .ok`).count())!==3)errs.push(`${tag}: label checks`);
  await pg.locator(`${W} .sp-blade`).nth(3).click(); if((await pg.locator(`${W} .sp-chir`).textContent()).length<20)errs.push(`${tag}: chirality text`);}
 {const W=`${S} .sp-w-lr`; if(await pg.locator(`${W} .sp-out .ok`).count()!==1)errs.push(`${tag}: lr verdict`); await pg.locator(`${W} .eq-chip`).nth(5).click(); if(await pg.locator(`${W} .sp-out .ok`).count()!==1)errs.push(`${tag}: lr verdict 2`); const cells=await pg.locator(`${W} .sp-lr td.eq-mono`).allTextContents(); if(cells.some(x=>x==='?'))errs.push(`${tag}: lr unknown`);}
 {const W=`${S} .sp-w-three`; const sq=async()=>pg.locator(`${W} .sp-three .sp-sq`).allTextContents();
  let v=await sq(); if(v.join()!=='1,−1,−1')errs.push(`${tag}: three (1,1) ${v}`);
  await pg.locator(`${W} .sp-pair`).locator('.eq-chip').filter({hasText:'0'}).first().click(); await pg.locator(`${W} .sp-pair`).locator('.eq-chip').filter({hasText:'0'}).nth(1).click(); v=await sq(); if(v.join()!=='0,0,—')errs.push(`${tag}: three (0,0) ${v}`);
  if(await pg.locator(`${W} .sp-fourth td`).count()<18)errs.push(`${tag}: fourth kind table`);}
 {const W=`${S} .sp-w-mix`; const o0=await pg.locator(`${W} .sp-out`).first().textContent(); await pg.locator(`${W} .sp-slider`).fill('6'); await pg.waitForTimeout(80); const o1=await pg.locator(`${W} .sp-out`).first().textContent(); if(o0===o1&&false)errs.push(`${tag}: mix`); 
  await pg.locator(`${W} .eq-chip`).first().click(); await pg.waitForTimeout(80); const keeps=await pg.locator(`${W} .sp-out`).first().textContent(); await pg.locator(`${W} .eq-chip`).nth(1).click(); await pg.waitForTimeout(80); const mixes=await pg.locator(`${W} .sp-out`).first().textContent(); if(keeps===mixes)errs.push(`${tag}: mix vs keep`);}
 {const W=`${S} .sp-w-phase`; if(await pg.locator(`${W} .sp-mixed .ok`).count()!==1||await pg.locator(`${W} .sp-pure .ok`).count()!==1)errs.push(`${tag}: phase marks`);
  await pg.locator(`${W} .sp-pair`).nth(2).locator('.eq-chip').filter({hasText:'B2'}).click(); await pg.waitForTimeout(80); const m=await pg.locator(`${W} .sp-mixed`).textContent(); if(!(lang==='en'?/relative phase/:/fase relativa/).test(m))errs.push(`${tag}: relative phase ${m}`); if(await pg.locator(`${W} .sp-mixed .ok`).count()!==1)errs.push(`${tag}: phase mark 2`);}
 {const W=`${S} .sp-w-pointor`; const rows=await pg.locator(`${W} .sp-tally tbody tr`).evaluateAll(es=>es.map(e=>e.dataset.kind+':'+e.lastElementChild.textContent)); if(rows.join()!=='flatland:12/12,vR:12/12,unrelated:0/12,versor:12/12')errs.push(`${tag}: pointor tally ${rows}`);
  await pg.locator(`${W} .eq-chip`).nth(2).click(); for(let i=0;i<3;i++){ await pg.locator(`${W} .sp-new`).click(); const v=await pg.locator(`${W} .sp-verdict`).textContent(); if(!/[✓]/.test(v))errs.push(`${tag}: unrelated verdict ${v}`); }
  await pg.locator(`${W} .eq-chip`).nth(1).click(); if(!(await pg.locator(`${W} .sp-verdict`).textContent()).includes('✓'))errs.push(`${tag}: vR verdict`);}
 {const W=`${S} .sp-w-hest`; if(await pg.locator(`${W} .sp-xor tbody tr`).count()!==8||await pg.locator(`${W} .sp-xor .ok`).count()!==8)errs.push(`${tag}: xor table`); if(!/24/.test(await pg.locator(`${W} .sp-agree`).textContent()))errs.push(`${tag}: agree text`);
  await pg.locator(`${W} .eq-chip`).nth(1).click(); if(!(await pg.locator(`${W} .sp-hv`).textContent()).includes('✓'))errs.push(`${tag}: versor mark`);}
 // links
 const pl=await pg.locator(`${S} .sp-paper-link`).getAttribute('href'); if(pl!=='https://arxiv.org/abs/2401.01142')errs.push(`${tag}: paper link ${pl}`);
 const ll=await pg.locator(`${S} .sp-lecture-link`).getAttribute('href'); if(!ll.includes('Zk6YnJpbhOo'))errs.push(`${tag}: lecture link`);
 // language of headings
 const h3=await pg.locator(`${S} h3`).allTextContents(); if(!h3.includes(lang==='en'?'The translation matrix, by subject':'La matrice di traduzione, per argomento'))errs.push(`${tag}: h3`);
 const sw=await pg.evaluate(()=>document.documentElement.scrollWidth); if(sw>w+1)errs.push(`${tag}: horizontal overflow ${sw}>${w}`);
 const short=await pg.locator(`${S} .eq-short`).count(); if((prof==='Young Learner')!==(short===1))errs.push(`${tag}: short reading ${short}`);
 await pg.close();}
await b.close();console.log(errs.length?errs:'SPIN UI OK');process.exit(errs.length?1:0);
