import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import fs from 'fs';
// Step 13 (a rigid body, from the segment to the tesseract) in the browser: structure, rows, filters, search, every widget, downloads, EN/IT, 1100 and 375 px.
// The numbers pinned here are the ones in selfcheck/pgadyn.json (56 rows, 110 claims) and the ones the page's own scripts print; nothing is compared with itself.
const K = JSON.parse(fs.readFileSync('/home/claude/ui/selfcheck/pgadyn.json', 'utf8'));
const PY = fs.readFileSync('/home/claude/ui/selfcheck/pgadyn_selfcheck.py', 'utf8');
const b = await chromium.launch(); const errs = [];
const THREADS = ['segment', 'square', 'cube', 'hang', 'frame', 'top', 'orbits'];
const THR = { segment: 5, square: 3, cube: 17, hang: 11, frame: 6, top: 5, orbits: 9 };
const CONTROLS = ['A5', 'B4', 'E2', 'E5', 'E11', 'E12', 'N1', 'N3', 'N4', 'T2'];
const near = (x, y, tol) => Math.abs(x - y) <= tol;
const num = s => parseFloat(String(s).replace(',', '.'));
if (K.summary.rows !== 56 || K.summary.ok !== 110 || K.summary.checks !== 110) errs.push('data: pgadyn.json is not 56 rows / 110 claims');
for (const lang of ['en', 'it']) for (const w of [1100, 375]) for (const prof of ['Young Learner', 'Mathematician']) {
  const tag = `${lang}${w}${prof[0]}`, heavy = w === 1100 && ((lang === 'en' && prof === 'Mathematician') || (lang === 'it' && prof === 'Young Learner'));
  const ctx = await b.newContext({ viewport: { width: w, height: 800 }, acceptDownloads: true, permissions: ['clipboard-read', 'clipboard-write'] });
  const pg = await ctx.newPage();
  pg.on('pageerror', e => errs.push(`${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${tag} console: ${m.text()}`));
  await pg.goto('file:///home/claude/ui/dist/app.html#equations'); await pg.waitForTimeout(300);
  if (lang === 'it') await pg.locator('[data-lang="it"]').click();
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(200);
  const S = '#eq-rigid', T = async s => (await pg.locator(`${S} ${s}`).textContent());
  const eb = await pg.locator(`${S} .eyebrow`).textContent();
  if (eb !== (lang === 'en' ? 'STEP 13 OF 13 · A RIGID BODY: FROM THE SEGMENT TO THE TESSERACT' : 'PASSO 13 DI 13 · UN CORPO RIGIDO: DAL SEGMENTO AL TESSERATTO')) errs.push(`${tag}: eyebrow ${eb}`);
  if (await pg.locator('.eq-nav a').count() !== 14) errs.push(`${tag}: nav`);
  if (await pg.locator(`${S} .rg-th`).count() !== 7) errs.push(`${tag}: threads`);
  if (await pg.locator(`${S} .rg-views > .rg-view`).count() !== 21) errs.push(`${tag}: views`);
  if (await pg.locator(`${S} .sp-w`).count() !== 7) errs.push(`${tag}: widgets`);
  if (await pg.locator(`${S} .rg-lens`).count() !== 7) errs.push(`${tag}: ladder`);
  if (await pg.locator(`${S} .rg-jumpchip`).count() !== 7) errs.push(`${tag}: jump chips`);
  if (await pg.locator(`${S} .rg-row`).count() !== 56) errs.push(`${tag}: rows`);
  for (const th of THREADS) { const n = await pg.locator(`${S} #rg-th-${th} .rg-jump`).count(); if (n !== THR[th]) errs.push(`${tag}: thread ${th} rows ${n}`); }
  // the three lenses in every thread carry text
  for (const th of THREADS) for (const v of ['mech', 'cube', 'alg']) { const t = await pg.locator(`${S} #rg-th-${th} .rg-view.${v} p`).textContent(); if (t.length < 40) errs.push(`${tag}: view ${th}/${v} is empty`); }
  // tags: statuses of rows come from the script; ten controls; the six reference rows are marked as such
  if (await pg.locator(`${S} .rg-ctrl`).count() !== 10) errs.push(`${tag}: control tags`);
  for (const id of CONTROLS) if (await pg.locator(`${S} #rg-row-${id} .rg-ctrl`).count() !== 1) errs.push(`${tag}: control tag ${id}`);
  { const st = await pg.locator(`${S} .rg-row`).evaluateAll(es => es.map(e => [e.dataset.row, e.dataset.status]));
    const non = st.filter(x => x[1] !== 'ok').map(x => x.join(':')).sort().join(',');
    if (non !== 'N9:plaus,R1:ref,R2:ref,R3:ref,R4:ref,R5:ref,R6:ref,R7:ref,R8:obs,R9:ref') errs.push(`${tag}: statuses ${non}`);
    const ids = st.map(x => x[0]).sort().join(','); if (ids !== K.rows.map(r => r.id).sort().join(',')) errs.push(`${tag}: row ids differ from pgadyn.json`); }
  // filters and search
  for (const th of THREADS) { await pg.locator(`${S} .rg-flt[data-flt="${th}"]`).click(); const c = await pg.locator(`${S} .rg-row`).count(); if (c !== THR[th]) errs.push(`${tag}: filter ${th} ${c}`); }
  await pg.locator(`${S} .rg-flt[data-flt="all"]`).click();
  await pg.locator(`${S} .rg-search`).fill('N9'); { const ids = await pg.locator(`${S} .rg-row`).evaluateAll(es => es.map(e => e.dataset.row)); if (!ids.includes('N9') || ids.length > 3) errs.push(`${tag}: search N9 ${ids}`); }
  await pg.locator(`${S} .rg-search`).fill('zzzz'); if (await pg.locator(`${S} .rg-row`).count() !== 0) errs.push(`${tag}: search none`);
  await pg.locator(`${S} .rg-search`).fill('');
  if (await pg.locator(`${S} .rg-row`).count() !== 56) errs.push(`${tag}: search cleared`);
  // rows open, command, copy, close
  await pg.locator(`${S} #rg-row-T2 .rg-row-h`).click();
  if (await pg.locator(`${S} #rg-row-T2 .rg-cmd`).textContent() !== 'python3 pgadyn_selfcheck.py --row T2') errs.push(`${tag}: cmd`);
  if ((await pg.locator(`${S} #rg-row-T2 .rg-inst`).textContent()).length < 10) errs.push(`${tag}: inst`);
  await pg.locator(`${S} #rg-row-T2 .rg-copy`).click(); await pg.waitForTimeout(100);
  { const cb = await pg.evaluate(() => navigator.clipboard.readText().catch(() => null)); if (cb !== null && cb !== 'python3 pgadyn_selfcheck.py --row T2') errs.push(`${tag}: clipboard ${cb}`); }
  await pg.locator(`${S} #rg-row-T2 .rg-row-h`).click(); if (await pg.locator(`${S} #rg-det-T2`).count() !== 0) errs.push(`${tag}: did not close`);
  await pg.locator(`${S} #rg-th-top .rg-jump`).filter({ hasText: 'T3' }).click(); await pg.waitForTimeout(100); if (await pg.locator(`${S} #rg-det-T3`).count() !== 1) errs.push(`${tag}: jump T3`);
  // the plausibility row says so, in the row itself
  await pg.locator(`${S} #rg-row-N9 .rg-row-h`).click(); { const t = await pg.locator(`${S} #rg-row-N9`).textContent(); if (!/JPL/.test(t) || !/(0\.2|0,2) ?%/.test(t)) errs.push(`${tag}: N9 does not state the plausibility limit`); }
  // honest limits are on the page: open list, benchmark sentence, map link
  { const t = await pg.locator(S).textContent();
    if (!/(JPL)/.test(t)) errs.push(`${tag}: no JPL caveat`);
    if (!/(timed|misurat)/i.test(t)) errs.push(`${tag}: no benchmark wording`);
    if (!/(action principle|principio d’azione)/.test(t)) errs.push(`${tag}: action principle is not listed as open`);
    if (/\b(six planets|sei pianeti)\b/.test(t)) errs.push(`${tag}: says six planets`); }
  // layout: no horizontal overflow of the page; every widget svg fits its card
  { const o = await pg.evaluate(() => document.documentElement.scrollWidth - window.innerWidth); if (o > 1) errs.push(`${tag}: page overflows by ${o}px`);
    const bad = await pg.evaluate(() => [...document.querySelectorAll('#eq-rigid .sp-w svg')].filter(s => s.getBoundingClientRect().right > window.innerWidth + 1).length); if (bad) errs.push(`${tag}: ${bad} widget drawings overflow`); }

  // ---- widgets (the whole run on two of the eight combinations; the rest see the structure)
  if (heavy) {
    // segment: x(t) = x0 + b t, the first checkmark, and gravity bends it
    { const W = `${S} .rg-w-seg`; await pg.locator(`${W} .rg-t`).fill('50'); await pg.waitForTimeout(80);
      const t1 = await T('.rg-w-seg .rg-val'); if (!t1.includes('✓')) errs.push(`${tag}: segment closed form ${t1}`);
      const c0 = await pg.locator(`${W} .rg-mass`).getAttribute('cy'); await pg.locator(`${W} .rg-g`).fill('30'); await pg.waitForTimeout(80); const c1 = await pg.locator(`${W} .rg-mass`).getAttribute('cy');
      if (c0 === c1) errs.push(`${tag}: segment mass did not move with g`);
      if (!(await T('.rg-w-seg .rg-val')).includes('✓')) errs.push(`${tag}: segment with g`); }
    // square: free spin, the constant and the rate (the velocity rotates at −b12)
    { const W = `${S} .rg-w-sq`; await pg.locator(`${W} .rg-vx`).fill('10'); await pg.locator(`${W} .rg-w`).fill('20'); await pg.locator(`${W} .rg-t`).fill('60'); await pg.waitForTimeout(100);
      const a = await T('.rg-w-sq .rg-const'), r = await T('.rg-w-sq .rg-rate'); if (!a.includes('✓') || !r.includes('✓')) errs.push(`${tag}: square ${a} / ${r}`); }
    // labelled body: select vertex 5, the mirror, the frame count, contact and outline, timing
    { const W = `${S} .rg-w-lab`; await pg.locator(`${W} .rg-vtx[data-v="5"]`).click(); await pg.waitForTimeout(80);
      const sel = await T('.rg-w-lab .rg-sel'); if (!/101/.test(sel)) errs.push(`${tag}: lab vertex 5 label ${sel}`);
      if (!(await T('.rg-w-lab .rg-mirror')).includes('✓')) errs.push(`${tag}: lab mirror`);
      await pg.locator(`${W} .eq-chip`).filter({ hasText: /Tess/ }).first().click(); await pg.waitForTimeout(80);
      if (await pg.locator(`${W} .rg-vtx`).count() !== 16) errs.push(`${tag}: tesseract has ${await pg.locator(`${W} .rg-vtx`).count()} vertices`);
      const tabs = await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').allTextContents(); if (tabs.length !== 5) errs.push(`${tag}: lab tabs ${tabs}`);
      await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').nth(1).click(); await pg.waitForTimeout(80);
      const fc = await T('.rg-w-lab .rg-count'); if (!/16/.test(fc) || !/5/.test(fc) || !/15/.test(fc)) errs.push(`${tag}: frame count ${fc}`);
      if (!(await T('.rg-w-lab .rg-ferr')).includes('✓')) errs.push(`${tag}: frame vertices differ from direct sandwiches`);
      await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').nth(2).click(); await pg.waitForTimeout(80);
      if (!(await T('.rg-w-lab .rg-deep')).includes('✓')) errs.push(`${tag}: sign bits disagree with the scan`);
      for (const a of [0, 90, 180, 270]) { await pg.locator(`${W} .rg-th`).fill(String(a)); await pg.waitForTimeout(40); if (!(await T('.rg-w-lab .rg-deep')).includes('✓')) errs.push(`${tag}: sign bits disagree with the scan at ${a}°`); }
      await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').nth(3).click(); await pg.waitForTimeout(80);
      const ol = await T('.rg-w-lab .rg-outl'); if (!ol.includes('✓') || !/8/.test(ol)) errs.push(`${tag}: outline ${ol}`);
      if (!(await T('.rg-w-lab .rg-flip')).includes('✓')) errs.push(`${tag}: each bit flips twice`);
      await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').nth(4).click(); await pg.waitForTimeout(80);
      if (await pg.locator(`${W} .rg-bench-mine tbody tr`).count() < 3) errs.push(`${tag}: stored benchmark rows`);
      if (await pg.locator(`${W} .rg-bench-here`).count() !== 0) errs.push(`${tag}: a benchmark of this machine shown before it was run`);
      await pg.locator(`${W} .rg-bench`).click(); await pg.waitForFunction(s => document.querySelectorAll(s + ' .rg-bench-here tbody tr').length >= 3, S + ' .rg-w-lab', { timeout: 60000 }).catch(() => errs.push(`${tag}: the timing button gave no rows`)); }
    // frame table: n = 5 says the versor condition is one equation short
    { const W = `${S} .rg-w-table`; if (await pg.locator(`${W} .rg-frame-tab tbody tr`).count() < 5) errs.push(`${tag}: frame table rows`);
      if (await pg.locator(`${W} .rg-short`).count() < 1) errs.push(`${tag}: n = 5 is not marked short`);
      const cells = await pg.locator(`${W} .rg-frame-tab tr[data-row="vertices"] td`).allTextContents(); if (cells.slice(1).join(',') !== '2,4,8,16,32,64' && cells.slice(1).join(',') !== '2,4,8,16,32') errs.push(`${tag}: vertices row ${cells}`); }
    // hang it: drop, energy and the group stay exact, tilt 0 is the rest
    { const W = `${S} .rg-w-hang`; await pg.locator(`${W} .rg-play`).click(); await pg.waitForTimeout(1500); await pg.locator(`${W} .rg-play`).click();
      if (!(await T('.rg-w-hang .rg-drift')).includes('✓')) errs.push(`${tag}: hang energy drift`); if (!(await T('.rg-w-hang .rg-norm')).includes('✓')) errs.push(`${tag}: hang M M~`);
      await pg.locator(`${W} .rg-tilt`).fill('0'); await pg.locator(`${W} .rg-reset`).click(); await pg.waitForTimeout(80);
      for (let i = 0; i < 6; i++) await pg.locator(`${W} .rg-step`).click();
      const rest = await T('.rg-w-hang .rg-rest'); if (!rest.includes('✓')) errs.push(`${tag}: hang at tilt 0 moved: ${rest}`);
      await pg.locator(`${W} .eq-chip`).filter({ hasText: /Tess/ }).first().click(); await pg.locator(`${W} .eq-chip`).filter({ hasText: /3/ }).first().click(); await pg.waitForTimeout(80);
      for (let i = 0; i < 4; i++) await pg.locator(`${W} .rg-step`).click();
      if (!(await T('.rg-w-hang .rg-rest')).includes('✓')) errs.push(`${tag}: 4D chain at tilt 0 moved`);
      await pg.locator(`${W} .rg-tilt`).fill('35'); await pg.locator(`${W} .rg-reset`).click(); for (let i = 0; i < 6; i++) await pg.locator(`${W} .rg-step`).click();
      if (!(await T('.rg-w-hang .rg-drift')).includes('✓') || !(await T('.rg-w-hang .rg-norm')).includes('✓')) errs.push(`${tag}: 4D chain conservation`);
      await pg.locator(`${W} .rg-al`).fill('10'); await pg.waitForTimeout(60); if (await pg.locator(`${W} .rg-drift .sp-mark`).count() !== 0) errs.push(`${tag}: damped hang still claims constant energy`); }
    // free top: the three presets; a spin about the middle axis flips, the others do not; |L| and E stay
    { const W = `${S} .rg-w-top`; await pg.locator(`${W} .rg-eps`).fill('20'); for (let i = 0; i < 40; i++) await pg.locator(`${W} .rg-step`).click();
      if (!(await T('.rg-w-top .rg-cons')).includes('✓')) errs.push(`${tag}: top conservation`);
      const fl = await T('.rg-w-top .rg-flips'); const nf = parseInt((fl.match(/(\d+)\s*$/) || [0, -1])[1], 10); if (!(nf >= 2)) errs.push(`${tag}: the middle axis did not flip: ${fl}`);
      for (const [ci, nm] of [[1, 'smallest'], [0, 'largest']]) {
        await pg.locator(`${W} .eq-chips`).nth(1).locator('.eq-chip').nth(ci).click(); await pg.waitForTimeout(80);
        for (let i = 0; i < 40; i++) await pg.locator(`${W} .rg-step`).click();
        const f2 = await T('.rg-w-top .rg-flips'); const n2 = parseInt((f2.match(/(\d+)\s*$/) || [0, -1])[1], 10); if (n2 !== 0) errs.push(`${tag}: the ${nm} axis flipped: ${f2}`);
        if (!(await T('.rg-w-top .rg-cons')).includes('✓')) errs.push(`${tag}: top conservation on the ${nm} axis`); } }
    // orbits: the Moon (8 turns, 27.32 days), Euler breaks the conservation, the planets table
    { const W = `${S} .rg-w-orb`; for (let i = 0; i < 40; i++) await pg.locator(`${W} .rg-step`).click();
      const rev = await T('.rg-w-orb .rg-moon-rev'); if (!/\b8\b/.test(rev) || !/27[.,]3/.test(rev)) errs.push(`${tag}: moon revolutions ${rev}`);
      if (!(await T('.rg-w-orb .rg-orb-cons')).includes('✓')) errs.push(`${tag}: moon conservation with RK4`);
      await pg.locator(`${W} .eq-chip`).filter({ hasText: /Euler/ }).click(); await pg.locator(`${W} .rg-reset`).click(); for (let i = 0; i < 40; i++) await pg.locator(`${W} .rg-step`).click();
      if (!(await T('.rg-w-orb .rg-orb-cons')).includes('✗')) errs.push(`${tag}: Euler is not shown to fail`);
      await pg.locator(`${W} .eq-chip`).filter({ hasText: /Runge/ }).click(); await pg.locator(`${W} .eq-chip`).filter({ hasText: /Giove|Jupiter/ }).click(); await pg.locator(`${W} .rg-reset`).click(); await pg.waitForTimeout(60);
      for (let i = 0; i < 20; i++) await pg.locator(`${W} .rg-step`).click();
      const pm = await T('.rg-w-orb .rg-pl-mom'); if (!/0[.,]10/.test(pm)) errs.push(`${tag}: planets momentum fraction ${pm}`);
      if (!(await T('.rg-w-orb .rg-orb-cons')).includes('✓')) errs.push(`${tag}: planets conservation`); }
    // map link, downloads
    if (prof === 'Mathematician') {
      for (const [i, name] of [[0, 'pgadyn_selfcheck.py'], [1, 'pgadyn.json'], [2, 'ganja_fixture.json']]) {
        const [d] = await Promise.all([pg.waitForEvent('download', { timeout: 5000 }).catch(() => null), pg.locator(`${S} .eq-btn`).filter({ hasText: /\.py|python|script|JSON|json|fixture|riferimento|verifica/i }).nth(i).click().catch(() => null)]);
        if (!d) { errs.push(`${tag}: download ${name} did not start`); continue; }
        if (d.suggestedFilename() !== name) errs.push(`${tag}: download name ${d.suggestedFilename()} (wanted ${name})`);
        const p = await d.path(); const txt = fs.readFileSync(p, 'utf8');
        if (name.endsWith('.py') && txt !== PY) errs.push(`${tag}: the downloaded script is not selfcheck/pgadyn_selfcheck.py`);
        if (name === 'pgadyn.json' && JSON.parse(txt).summary.ok !== 110) errs.push(`${tag}: downloaded json`);
        if (name === 'ganja_fixture.json' && !JSON.parse(txt)) errs.push(`${tag}: downloaded fixture`);
      }
    }
    await pg.locator(`${S} .rg-maplink`).click(); await pg.waitForTimeout(300);
    if (!(await pg.evaluate(() => location.hash)).includes('map') || await pg.locator('#map-next, .map-nextlist').count() < 1) errs.push(`${tag}: map link`);
  }
  await ctx.close();
}
await b.close();
console.log(errs.length ? errs.slice(0, 40).map(e => '  ' + e).join('\n') : 'PGADYN UI OK');
process.exit(errs.length ? 1 : 0);
