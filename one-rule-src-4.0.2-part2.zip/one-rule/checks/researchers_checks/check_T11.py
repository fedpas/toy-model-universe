# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T11: quadric counts (W1-W3) and the Peres-Mermin square from the bit rule. Own code.
Asserts:
 1. For every Cl(p,q), p+q <= 8: the number of totally singular k-subspaces of Q = [e_a^2 = -1] (enumerated) equals
    the closed formula N(k) of T11.md for the nondegenerate classes; and 2^w = (#simple factors) x N (W1), using the
    standard type table by c = p - q mod 8, for all p+q <= 9.
 2. Cl(4,0): 5 points, 0 lines. Cl(6,0): 27 points, 45 lines, 0 planes (elliptic Q-(5,2), NOT the Klein quadric).
    Cl(3,3), Cl(4,2), Cl(0,6): 35 points, 105 lines, 30 planes (Klein quadric Q+(5,2)).
    Cl(8,0): 135 points, 1575 lines, 2025 planes, 270 solids, in two families of 135 (dim(U ∩ U') even <=> same family).
 3. Lambda^2 F_2^4 with the Pfaffian: Q+ class, its 35 singular nonzero vectors = the 35 decomposable bivectors.
 4. Cl(2,2): 9 points, 6 lines forming a 3x3 grid; the product of the six line products is -1 (invariant under re-signing);
    no assignment of +-1 to the nine operators satisfies the six line constraints (all 512 tried).
 4b. For every Cl(p,q) with p, q >= 2 and p+q <= 10: the nine blades of that grid on the generators 1, 2, p+1, p+2
    square to +1, its lines commute, its six line signs are those of Cl(2,2) (product -1); no +-1 assignment
    (512 tried).
 4c. For every Cl(p,q) with 1 <= p+q <= 8, a search through the 3x3 grids of nonzero labels with lines a, b, a^b,
    stopped at the first grid of square-+1 blades with commuting lines and line-sign product -1: one exists exactly
    in the cells other than p+q <= 3, (4,0), (1,3), (0,4), (5,0), (1,4); no grid found admits a +-1 assignment
    (512 tried).
 4d. In those cells without a grid, the equations v(a) v(b) v(a^b) = (the sign of e_a e_b e_(a^b)), one for every
    commuting triple of square-+1 blades, have a solution (F2 elimination, checked against every equation); in the
    other cells with 1 <= p+q <= 8 they have none.
 5. The blades over one solid of Cl(8,0) commute and square to +1; that they span R^16 follows and is not computed.
"""
import sys, itertools
from f2lib import pc, q_clifford, polar, form_invariants

ok = 0


def check(c, m):
    global ok
    if not c:
        print("FAIL:", m)
        sys.exit(1)
    ok += 1


def ts_subspaces(q, n):
    """All totally singular subspaces (as frozensets of vectors), by dimension."""
    N = 1 << n
    sing = [v for v in range(1, N) if q[v] == 0]
    levels = [{frozenset([0])}]
    while True:
        nxt = set()
        for U in levels[-1]:
            for v in sing:
                if v in U:
                    continue
                if all(polar(q, v, u) == 0 for u in U):
                    W = frozenset(list(U) + [u ^ v for u in U])
                    nxt.add(W)
        if not nxt:
            break
        levels.append(nxt)
    return levels


def N_formula(m, eps, k):
    num = 1
    den = 1
    for j in range(k):
        num *= 2 ** j * (2 ** (m - j) - eps) * (2 ** (m - j - 1) + eps)
        den *= 2 ** k - 2 ** j
    assert num % den == 0
    return num // den


def type_size(p, qn):
    """(#simple factors) x N for Cl(p,q) from the standard table by c = p - q mod 8 (Lawson-Michelsohn I.4)."""
    n = p + qn
    c = (p - qn) % 8
    if c in (0, 2):
        return 2 ** (n // 2)
    if c == 1:
        return 2 * 2 ** ((n - 1) // 2)
    if c in (3, 7):
        return 2 ** ((n - 1) // 2)
    if c in (4, 6):
        return 2 ** ((n - 2) // 2)
    if c == 5:
        return 2 * 2 ** ((n - 3) // 2)


counts = {}
for n in range(1, 10):
    for p in range(n + 1):
        q = q_clifford(p, n - p)
        lev = ts_subspaces(q, n)
        w = len(lev) - 1
        check(2 ** w == type_size(p, n - p), f"W1 Cl({p},{n-p}): 2^w = {2**w}")
        inv_ = form_invariants(q, n)
        if inv_[1] == 0 and n <= 8:
            m = n // 2
            eps = 1 if inv_[3] > 0 else -1
            for k in range(1, w + 1):
                check(len(lev[k]) == N_formula(m, eps, k), f"N_k Cl({p},{n-p}) k={k}")
            check(w == (m if eps == 1 else m - 1), "Witt index")
        counts[(p, n - p)] = [len(L) for L in lev[1:]]
print("1 ok: W1 for all Cl(p,q), p+q <= 9; subspace counts = formula for all nondegenerate classes n <= 8")
check(counts[(4, 0)] == [5], "Cl(4,0)")
check(counts[(6, 0)] == [27, 45], f"Cl(6,0) {counts[(6,0)]}")
for pq in ((3, 3), (4, 2), (0, 6)):
    check(counts[pq] == [35, 105, 30], f"Klein {pq} {counts[pq]}")
check(counts[(8, 0)] == [135, 1575, 2025, 270], f"Cl(8,0) {counts[(8,0)]}")
check(counts[(2, 2)] == [9, 6], "Cl(2,2)")
print("2 counts:", {k: v for k, v in counts.items() if k in [(4, 0), (6, 0), (3, 3), (8, 0), (2, 2)]})

# two families of solids in Cl(8,0) and of planes in Cl(3,3)
for (p, qn, m) in ((8, 0, 4), (3, 3, 3)):
    q = q_clifford(p, qn)
    tops = list(ts_subspaces(q, p + qn)[-1])
    same = lambda U, V: ((len(U & V).bit_length() - 1) % 2) == (m % 2)
    fam = [0] * len(tops)
    for i in range(1, len(tops)):
        fam[i] = 0 if same(tops[0], tops[i]) else 1
    for i in range(len(tops)):
        for j in range(len(tops)):
            check(same(tops[i], tops[j]) == (fam[i] == fam[j]), "family relation is an equivalence with 2 classes")
    check(fam.count(0) == fam.count(1) == len(tops) // 2, "two equal families")
    # incidence: each point lies in the same number of maximal subspaces of each family
    pts = [v for v in range(1, 1 << (p + qn)) if q[v] == 0]
    inc = {(sum(1 for i, U in enumerate(tops) if v in U and fam[i] == f)) for v in pts for f in (0, 1)}
    check(len(inc) == 1, "flag-transitivity shadow: constant incidence")
    print(f"3 ok: Cl({p},{qn}): {len(tops)} maximal totally singular subspaces = {fam.count(0)} + {fam.count(1)}; "
          f"each point in {inc.pop()} of each family")

# Klein: Lambda^2 F_2^4, coordinates p01,p02,p03,p12,p13,p23 ; Pfaffian q = p01 p23 + p02 p13 + p03 p12
pairs = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
def pf(x):
    b = [x >> i & 1 for i in range(6)]
    return (b[0] * b[5] + b[1] * b[4] + b[2] * b[3]) & 1
qk = [pf(x) for x in range(64)]
check(form_invariants(qk, 6) == form_invariants(q_clifford(3, 3), 6), "Pfaffian form = class R (Q+) = Cl(3,3)")
dec = set()
for u in range(1, 16):
    for v in range(1, 16):
        w = 0
        for t, (i, j) in enumerate(pairs):
            if ((u >> i & 1) * (v >> j & 1) + (u >> j & 1) * (v >> i & 1)) & 1:
                w |= 1 << t
        if w:
            dec.add(w)
check(dec == {x for x in range(1, 64) if qk[x] == 0} and len(dec) == 35, "35 decomposable = 35 singular")
print("3b ok: Klein quadric: Pfaffian on Lambda^2 F_2^4 is of + type; singular nonzero vectors = 35 decomposable bivectors")


# Peres-Mermin from the bit rule in Cl(2,2)
def sgn(a, b, eps):
    s = 0
    for i in range(len(eps)):
        if a >> i & 1:
            s += pc(b & ((1 << i) - 1))
    v = -1 if s % 2 else 1
    for i in range(len(eps)):
        if a >> i & 1 and b >> i & 1:
            v *= eps[i]
    return v


eps = (1, 1, -1, -1)
q22 = q_clifford(2, 2)
pts = [a for a in range(1, 16) if q22[a] == 0]
lines = [U for U in ts_subspaces(q22, 4)[2]]
check(len(pts) == 9 and len(lines) == 6, "9 points 6 lines")
for a in pts:
    check(sgn(a, a, eps) == 1, "square +1")
inc = {a: sum(1 for L in lines if a in L) for a in pts}
check(set(inc.values()) == {2}, "each operator in exactly two lines")
# split lines into two parallel classes (rows / columns): disjoint lines (projectively) are in the same class
L = [sorted(x for x in U if x) for U in lines]
rows = [L[0]] + [l for l in L[1:] if not set(l) & set(L[0])]
cols = [l for l in L if l not in rows]
check(len(rows) == 3 and len(cols) == 3 and all(len(set(r) & set(c)) == 1 for r in rows for c in cols), "3x3 grid")


def line_sign(l):
    a, b, c = l
    s1 = sgn(a, b, eps)            # e_a e_b = s1 e_{a^b}, a^b = c
    return s1 * sgn(c, c, eps) if (a ^ b) == c else None


sig = [line_sign(l) for l in L]
check(all(s in (1, -1) for s in sig), "line products are scalars")
prod = 1
for s in sig:
    prod *= s
check(prod == -1, f"product of the six line signs = {prod}")
# re-signing invariance and the Kochen-Specker parity argument (brute force)
idx = {a: i for i, a in enumerate(pts)}
sols = 0
for vals in itertools.product((1, -1), repeat=9):
    good = True
    for l, s in zip(L, sig):
        if vals[idx[l[0]]] * vals[idx[l[1]]] * vals[idx[l[2]]] != s:
            good = False
            break
    sols += good
check(sols == 0, "no non-contextual assignment")
for flips in itertools.product((1, -1), repeat=9):
    pr = 1
    for l, s in zip(L, sig):
        pr *= s * flips[idx[l[0]]] * flips[idx[l[1]]] * flips[idx[l[2]]]
    check(pr == -1, "invariance of the parity under e_a -> -e_a")
names = {a: "e" + "".join(str(i + 1) for i in range(4) if a >> i & 1) for a in pts}
print("4 ok: Peres-Mermin square in Cl(2,2) (e1,e2 square +1; e3,e4 square -1):")
for r in rows:
    print("   row", [names[a] for a in r], "product", line_sign(r))
for c in cols:
    print("   col", [names[a] for a in c], "product", line_sign(c))
print("   product of the six line signs = -1; no +-1 assignment exists (512 tried)")


# 4b-4d: Peres-Mermin squares of blades over the cells Cl(p,q)
def pm_lines(a, b, d, e):
    """the six lines of the 3x3 grid with first row a, b, a^b and first column a, d, a^d"""
    c, f = a ^ b, d ^ e
    g, h, i = a ^ d, b ^ e, c ^ f
    return [(a, b, c), (d, e, f), (g, h, i), (a, d, g), (b, e, h), (c, f, i)]


def pm_signs(lines, eps):
    """the sign of e_a e_b e_c on each line (a, b, c = a^b); None unless the nine labels are distinct and nonzero,
    their blades square to +1 and the blades of each line commute (all by the bit rule)"""
    labels = {x for l in lines for x in l}
    if len(labels) != 9 or 0 in labels or any(sgn(x, x, eps) != 1 for x in labels):
        return None
    if any(a ^ b != c for a, b, c in lines):
        return None
    if any(sgn(x, y, eps) != sgn(y, x, eps) for l in lines for x in l for y in l):
        return None
    return [sgn(a, b, eps) * sgn(c, c, eps) for a, b, c in lines]


def assignments(lines, sig):
    """the number of +-1 assignments to the nine labels that satisfy the six line constraints (all 512 tried)"""
    labels = sorted({x for l in lines for x in l})
    ix = {a: i for i, a in enumerate(labels)}
    return sum(all(v[ix[a]] * v[ix[b]] * v[ix[c]] == s for (a, b, c), s in zip(lines, sig))
               for v in itertools.product((1, -1), repeat=9))


def pm_search(p, qn):
    """the first 3x3 grid of square-+1 blades with commuting lines and line-sign product -1 in Cl(p,q);
    None when there is none (the search then has gone through every a, b, d, e)"""
    n = p + qn
    epsc = (1,) * p + (-1,) * qn
    qc = q_clifford(p, qn)
    P = [a for a in range(1, 1 << n) if qc[a] == 0]
    for a in P:
        for b in P:
            if b == a or polar(qc, a, b):
                continue
            for d in P:
                if d in (a, b, a ^ b) or polar(qc, a, d):
                    continue
                for e in P:
                    if polar(qc, b, e) or polar(qc, d, e):
                        continue
                    lines = pm_lines(a, b, d, e)
                    s = pm_signs(lines, epsc)
                    if s is not None and s.count(-1) % 2 == 1:
                        return lines, s
    return None


def parity_system(p, qn):
    """one equation v(a) v(b) v(c) = (the sign of e_a e_b e_c) for every commuting triple a, b, c = a^b of
    square-+1 blades of Cl(p,q); returns (equations, a solution or None), the solution by F2 elimination"""
    n = p + qn
    epsc = (1,) * p + (-1,) * qn
    qc = q_clifford(p, qn)
    P = [a for a in range(1, 1 << n) if qc[a] == 0]
    ix = {a: i for i, a in enumerate(P)}
    m = len(P)
    mask = (1 << m) - 1
    eqs = []
    for a in P:
        for b in P:
            c = a ^ b
            if a < b < c and not polar(qc, a, b):
                if c not in ix:
                    return eqs, None
                eqs.append(((a, b, c), sgn(a, b, epsc) * sgn(c, c, epsc)))
    piv = {}
    for (a, b, c), s in eqs:
        r = (1 << ix[a]) | (1 << ix[b]) | (1 << ix[c]) | ((1 if s == -1 else 0) << m)
        while r & mask:
            top = (r & mask).bit_length() - 1
            if top not in piv:
                piv[top] = r
                break
            r ^= piv[top]
        else:
            if r:
                return eqs, None
    x = [0] * m
    for top in sorted(piv):
        r = piv[top]
        val = r >> m & 1
        for j in range(top):
            if r >> j & 1:
                val ^= x[j]
        x[top] = val
    return eqs, {a: (-1 if x[ix[a]] else 1) for a in P}


# 4b: the grid above, on the generators 1, 2, p+1, p+2 of every Cl(p,q) with p, q >= 2 and p+q <= 10
emb_cells = [(p, n - p) for n in range(4, 11) for p in range(2, n - 1)]
for (p, qn) in emb_cells:
    epsc = (1,) * p + (-1,) * qn
    emb = lambda x: (x & 3) | ((x >> 2 & 1) << p) | ((x >> 3 & 1) << (p + 1))
    Le = [tuple(emb(x) for x in l) for l in L]
    se = pm_signs(Le, epsc)
    check(se == sig, f"4b Cl({p},{qn}): the embedded grid has the six line signs of Cl(2,2)")
    check(assignments(Le, se) == 0, f"4b Cl({p},{qn}): no +-1 assignment")
print(f"4b ok: the grid of item 4 on the generators 1, 2, p+1, p+2 in each of the {len(emb_cells)} cells with p, q >= 2, "
      "p+q <= 10: its blades square to +1, its lines commute, the six line signs are those of Cl(2,2) "
      "(product -1), no +-1 assignment (512 tried each)")

# 4c: a complete search in every cell with 1 <= p+q <= 8
NO_GRID = {(p, n - p) for n in range(1, 4) for p in range(n + 1)} | {(4, 0), (1, 3), (0, 4), (5, 0), (1, 4)}
cells = [(p, n - p) for n in range(1, 9) for p in range(n + 1)]
found = {}
for (p, qn) in cells:
    res = pm_search(p, qn)
    found[(p, qn)] = res is not None
    if res is not None:
        check(assignments(*res) == 0, f"4c Cl({p},{qn}): the grid found admits no +-1 assignment")
for (p, qn) in cells:
    check(found[(p, qn)] == ((p, qn) not in NO_GRID), f"4c Cl({p},{qn}): grid found = {found[(p, qn)]}")
print(f"4c ok: a 3x3 grid of square-+1 blades (lines a, b, a^b) with commuting lines and line-sign product -1 exists "
      f"in {sum(found.values())} of the {len(cells)} cells with 1 <= p+q <= 8, in none of the other "
      f"{len(cells) - sum(found.values())}: p+q <= 3, (4,0), (1,3), (0,4), (5,0), (1,4) (search through every grid); "
      "no +-1 assignment for any grid found (512 tried each)")

# 4d: in the cells without a grid, the commuting square-+1 blades admit a consistent +-1 assignment
for (p, qn) in cells:
    eqs, sol = parity_system(p, qn)
    check((sol is not None) == ((p, qn) in NO_GRID),
          f"4d Cl({p},{qn}): the parity equations solvable = {sol is not None}")
    if sol is not None:
        check(all(sol[a] * sol[b] * sol[c] == s for (a, b, c), s in eqs),
              f"4d Cl({p},{qn}): the solution satisfies every equation")
print(f"4d ok: in the {len(NO_GRID)} cells without a grid, the equations v(a) v(b) v(a^b) = "
      "(the sign of e_a e_b e_(a^b)) over all commuting triples of square-+1 blades have a solution "
      "(F2 elimination, the solution checked against every equation); "
      f"in the other {len(cells) - len(NO_GRID)} cells they have none")

# 5: the blades over one solid of Cl(8,0)
q8 = q_clifford(8, 0)
eps8 = (1,) * 8
solid = sorted(next(iter(ts_subspaces(q8, 8)[-1])))
gens = []
span = {0}
for v in solid:
    if v not in span:
        gens.append(v)
        span |= {s ^ v for s in span}
check(len(gens) == 4, "solid has dim 4")
# commuting and squares +1
for a in solid:
    for b in solid:
        check(sgn(a, b, eps8) == sgn(b, a, eps8), "commute")
    check(sgn(a, a, eps8) == 1, "square +1")
print("5 ok: the blades over one solid of Cl(8,0) commute and square to +1; "
      "that they span R^16 follows and is not computed")
print(f"ALL {ok} CHECKS PASSED")
