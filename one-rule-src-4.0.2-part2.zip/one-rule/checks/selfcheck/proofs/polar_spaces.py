#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""polar_spaces.py: the Pauli group as a symplectic polar space, untwisting by the volume element, the double centraliser over R, the Witt
decomposition, the low-dimensional spin isomorphisms at the Lie-algebra level, and the two families of solids with triality.
     python3 polar_spaces.py [--fault DOT|ODD|SIGN|QUAD|ODDQ|NEGDELTA|NONCENTRAL|NOTSIMPLE|SAMESIGN|RAD|MISMATCH|SINGREFL|NONSING]

P (polar.P1..P6).  For Cl(n,n), n = 1..4: the commutation sign of two blades is (-1)^(|a||b| - |a & b|), so the commutation form is
   beta(a,b) = pi(a) pi(b) + a.b mod 2 (pi the parity); it is alternating and non-degenerate on F2^(2n) (its Gram matrix J + I over F2 has
   determinant N + 1 mod 2 for N generators); the label quadric Q(a) = [e_a^2 = -1] has polar form beta (Q is a quadratic refinement of beta;
   equivalently w = pi + 2Q has w(a+b) - w(a) - w(b) = 2 a.b mod 4).  The totally isotropic k-subspaces of beta, enumerated over all
   k-subspaces of F2^(2n) in reduced echelon form, number prod_(i<k) (2^(2n-i) - 2^i)/(2^k - 2^i); the Lagrangians prod_(k=1..n) (2^k + 1)
   = 3, 15, 135, 2295.  On a Lagrangian with basis a_1..a_n the elements g_k = i^Q(a_k) e_(a_k) commute and square to 1; for each of the 2^n
   sign vectors P = prod (1 + s_k g_k)/2 is idempotent with scalar part 2^-n (trace 1 in Cl(n,n) (x) C = M_(2^n)(C), because every non-scalar
   blade anticommutes with some blade and is traceless) and support the Lagrangian, so the 2^n prod (2^k + 1) = 6, 60, 1080, 36720
   projectors are distinct.  The transvections x -> x + beta(x,w) w preserve beta and generate a group of order |Sp(2n,2)| = 6, 720,
   1451520, 47377612800 (P4; P6 the same order for H, S, CNOT).  The order compared with is f2lib.order_Sp, the closed formula
   2^(n^2) prod_(i=1..n) (4^i - 1); that it is the order of Sp(2n,2) is the order LAB-037 proves by its induction (wg.CLASS, which recalls
   no order formula), so P4 and P6 show generation without a recalled formula.
   [bit]  BR(eps) of researchers_checks/bitrule_A.py (signs, squares, commutation), f2lib.q_clifford, f2lib.transvection, f2lib.f2_group
          (Schreier-Sims), f2lib.order_Sp; Gaussian integers as exponents of i and integer pairs.
   [std]  numpy Pauli strings (I, X, Y, Z tensor products), no bit rule and no sign formula: commutation by matrix products, closed commuting
          sets enumerated level by level, stabiliser projectors as matrices (trace, square, numerical rank), distinct projectors counted; the
          gates H, S, CNOT permute the 4^n - 1 Pauli strings and their permutation group (permgroup.BSGS of selfcheck/steps15_17) has order
          |Sp(2n,2)|; the 4^n Pauli strings have rank 4^n, so only scalars commute with all of them (the action has kernel Paulis x phases).
U (polar.U1..U3).  For q non-degenerate of even dimension 2m (signs +-1) and q' arbitrary (signs +1, -1, 0), every splitting with
   p + q + r <= 6: z'_j = e_F z_j commutes with the generators of q, z'_j z'_k + z'_k z'_j = 2 delta eps'_j [j = k] with delta = e_F^2, the
   map e_A (x) f_B -> e_A z'_B is multiplicative on all 4^n basis pairs of the ungraded product Cl(q) (x) Cl(delta q') and its 2^n images
   have exact rank 2^n.  With q' = r null generators: Cl(p,q,r) = Cl(p,q) (x) Lambda(R^r) for p + q even.
   [bit]  BR products, exact rank.   [std]  numpy matrices (Z strings with sigma_x, the real rotation, sigma_minus) for both sides.
C (polar.C1..C4).  B central simple in End(V): Cl(1,1) = M_2(R) and Cl(0,2) = H on themselves (R^4), Cl(0,4) = M_2(H) on a minimal left
   ideal R^8; the commutant C is central simple, C(C) = B, B (x) C -> End(V) is bijective, and B, C have the same Brauer class (sign of the
   trace-form signature: + for the class of R, - for H).  Centre C: Cl(0,1) = C on R^2 (image 2 of 4), Cl(3,0) = M_2(C) on R^8 (image 32 of
   64); centre R^2: Cl(0,3) = H + H on R^8 (C(C(B)) = B, image 32 of 64).  The fibre: Cl(0,k), the first k of eight anticommuting gamma of
   Cl(0,8) acting on a minimal left ideal R^16 built from BR and a solid of commuting blades: dim B = 2^k, dim C = 2^(8-k), dim C(C) = 2^k;
   B (x) C -> End(R^16) is bijective for k even and has image 128 for k odd (kernel exhibited as the image of z (x) 1 - 1 (x) z).
   [bit]  exact Fractions (small V); for R^16 the monomial-orbit commutant (exact), and ranks modulo the prime 2^31 - 1 as lower bounds,
          closed by the inclusion B in C(C) and by the exhibited kernel.   [std]  numpy matrices from quaternion units, Pauli matrices,
          block sums and a searched set of eight anticommuting real 16 x 16 matrices; SVD null spaces and ranks.
W (polar.W1..W3).  Every (p,q,r) with p + q + r <= 8: u = e_i + e_j, v = (e_i - e_j)/2 for m = min(p,q) pairs of generators of square +1 and
   -1, the remaining |p - q| generators and the r null ones: the Gram matrix of this basis is diag(H^m, +-1, 0) exactly (H = [[0,1],[1,0]]);
   span(u) is totally isotropic, each u is paired (B(u,v) = 1), each null generator is orthogonal to every vector.  The bound dim W <=
   min(p,q) + r for a totally isotropic W, Witt's theorem and Sylvester's law are recalled.
   [bit]  BR products of vectors.   [std]  numpy eigenvalue signs and exact LDL inertia of S^T diag(eps) S, S random unimodular.
L (polar.L1..L3).  The bivector algebras of Cl(3,0), Cl(1,2), Cl(1,3), Cl(2,2), Cl(3,3), Cl(2,4), Cl(1,5): dimensions 3, 3, 6, 6, 15, 15, 15
   and Killing signatures (pq, p(p-1)/2 + q(q-1)/2); the even parts Cl^0(p,q) = Cl(p,q-1) have the types H, M_2(R), M_2(C), M_2(R)+M_2(R),
   M_4(R)+M_4(R), M_4(C), M_2(H)+M_2(H) (SL(4,R) and SL(2,H) sit in one simple factor); su(2), sl(2,R), sl(2,C), sl(2,R)^2, sl(4,R), su(2,2), sl(2,H) have the same dimensions and Killing signatures.
   Isomorphisms exhibited (bracket tables): so(3) -> su(2), so(1,2) -> sl(2,R), so(1,3) -> sl(2,C); the other four are matched invariants.
   [bit]  BR commutators, exact Killing form and LDL inertia.   [std]  numpy matrix Lie algebras, Killing form tr(ad X ad Y), eigenvalue signs.
F (polar.F1..F6).  Cl(8,0) label quadric over F2: 135 singular points, 270 solids in two families of 135 (same family iff dim of the
   intersection even); each of the 120 transvections t_w (Q(w) = 1) maps every solid to a solid of the other family, t_w0 t_w keeps each;
   |<t_w>| = |O+(8,2)| = 348364800 and |<t_w0 t_w>| = 174182400 (the stabiliser of a family, index 2); the three incidence graphs (points and
   family 1 by inclusion, points and family 2, family 1 and family 2 by meeting in a plane) have degrees 15 and the same common-neighbour
   counts, and a permutation of the 405 objects mapping points -> family 1 -> family 2 -> points and keeping all incidences is found and
   verified; a power of it has order 3, and with a transvection it gives S3 on the three sets of 135.  Over R: the 24 weights of D4 (vector +-e_i, half-spin (+-1/2)^4 with an even and an odd number of minus signs) are three
   16-cells permuted by an order-3 orthogonal matrix; Cl(4,4) on Lambda(R^4): the maximal isotropic subspaces sampled each annihilate one
   line of spinors in one half-spin space, a reflection moves it to the other, a Spin element keeps it, dim(W ∩ W') is even iff the same half;
   on the 8-dimensional half-spin spaces the Spin-invariant form has signature (4,4), null spinors are pure (annihilator of dimension 4) and
   non-null ones are not (dimension 0).
   [bit]  f2lib (q_clifford, transvection, f2_group, order_O_formula), exhaustive enumeration, backtracking search verified edge by edge.
   [std]  exact Fractions for the weights; numpy and scipy.linalg.expm for the spinors (Jordan-Wigner matrices, no bit rule).
Controls ([ctl], each with a --fault that puts the wrong version in the main lines, which must then FAIL):
   DOT the dot product a.b in place of beta (not alternating: other counts); ODD 2n+1 generators (beta degenerate: radical {0, all ones});
   SIGN one sign choice dropped (half the states); QUAD the quadric in place of beta (2, 6, 30, 270 totally singular, not 3, 15, 135, 2295);
   ODDQ q of odd dimension (z'_j anticommutes with q; relations of -delta q'); NEGDELTA -delta in place of delta;
   NONCENTRAL C (centre C) taken as central simple; NOTSIMPLE H + H taken as simple (B (x) C -> End(V) not bijective);
   SAMESIGN a pair of generators of the same sign (Gram +-2 on the diagonal); RAD a declared radical of the wrong size;
   MISMATCH so(2,2) paired with sl(2,C) ((4,2) against (3,3)); SINGREFL a transvection by a singular vector (not an isometry of Q);
   NONSING a non-singular vector put into a solid (not totally singular).
Scope: n <= 4 for the Pauli counts, p + q + r <= 6 for untwisting, p + q + r <= 8 for the Witt decomposition, the algebras listed for the
double centraliser and the spin table, Cl(8,0) and Cl(4,4) for the families.  Witt's theorem, Sylvester's law, the double centraliser
theorem, Br(R) = Z2 and the representation types of Lambda(R^r) are recalled, not proved here.  The gravity engine's Forms, Lie and Grav are
not used, so its eight engine faults are not seen by this script; its controls are the faults above.
Command: python3 polar_spaces.py   (from this folder, or python3 selfcheck/proofs/polar_spaces.py from the package root; standard library,
numpy, scipy)."""
import os, sys, itertools, random, math
from fractions import Fraction as Fr
from collections import Counter
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
_steps = os.path.join(_selfcheck, 'steps15_17')
for _p, _f in ((_researchers, 'bitrule_A.py'), (_researchers, 'f2lib.py'), (_steps, 'permgroup.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
from bitrule_A import BR, anticomm, comm
import f2lib
import permgroup
from scipy.linalg import expm

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('DOT', 'ODD', 'SIGN', 'QUAD', 'ODDQ', 'NEGDELTA', 'NONCENTRAL', 'NOTSIMPLE', 'SAMESIGN', 'RAD', 'MISMATCH', 'SINGREFL', 'NONSING')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')
PR = 2 ** 31 - 1                                                           # prime for modular ranks (lower bounds of rational ranks)

# ================================================================================================ small exact tools
def span_f2(rows):
    out = [0]
    for r in rows: out = out + [x ^ r for x in out]
    return out

def subspaces_rref(N, k):
    """every k-dimensional subspace of F2^N once, as the tuple of its reduced echelon rows (pivot = lowest set bit)"""
    for piv in itertools.combinations(range(N), k):
        pset = set(piv); choices = []
        for c in piv:
            free = [f for f in range(c + 1, N) if f not in pset]
            rows = []
            for m in range(1 << len(free)):
                r = 1 << c
                for t, f in enumerate(free):
                    if (m >> t) & 1: r |= 1 << f
                rows.append(r)
            choices.append(rows)
        for rows in itertools.product(*choices): yield rows

def gauss_binom2(N, k):
    num = den = 1
    for i in range(k): num *= 2 ** (N - i) - 1; den *= 2 ** (i + 1) - 1
    return num // den

def f2_rank(vecs):
    basis = []
    for v in vecs:
        for b in basis: v = min(v, v ^ b)
        if v: basis.append(v)
    return len(basis)

def rref_sparse(rows):
    """exact reduced row echelon form over Q of sparse rows (dicts col -> value): {pivot col: row}"""
    piv = {}
    for r in rows:
        r = {c: Fr(v) for c, v in r.items() if v}
        while True:
            cs = [c for c in r if c in piv]
            if not cs: break
            c = cs[0]; f = r[c]
            for cc, vv in piv[c].items():
                nv = r.get(cc, 0) - f * vv
                if nv: r[cc] = nv
                else: r.pop(cc, None)
        if r:
            c0 = min(r); inv = 1 / r[c0]; r = {c: v * inv for c, v in r.items()}
            for c, pr in piv.items():
                if c0 in pr:
                    f = pr[c0]
                    for cc, vv in r.items():
                        nv = pr.get(cc, 0) - f * vv
                        if nv: pr[cc] = nv
                        else: pr.pop(cc, None)
            piv[c0] = r
    return piv
def dense_to_sparse(v): return {i: x for i, x in enumerate(v) if x}
def nullspace_fr(rows, ncols):
    """exact basis of {x : rows x = 0} over Q (rows: dense lists)"""
    piv = rref_sparse(dense_to_sparse(r) for r in rows); out = []
    for f in (c for c in range(ncols) if c not in piv):
        x = [Fr(0)] * ncols; x[f] = Fr(1)
        for c, pr in piv.items(): x[c] = -pr.get(f, 0)
        out.append(x)
    return out
def rank_q(vecs, ncols=None): return len(rref_sparse(dense_to_sparse(v) for v in vecs))

def rank_modp(M):
    """rank of an integer matrix modulo PR (a lower bound of its rank over Q)"""
    A = np.array(M, dtype=np.int64) % PR
    if A.size == 0: return 0
    nr, nc = A.shape; r = 0
    for c in range(nc):
        if r == nr: break
        nz = np.nonzero(A[r:, c])[0]
        if nz.size == 0: continue
        p = r + nz[0]
        if p != r: A[[r, p]] = A[[p, r]]
        inv = pow(int(A[r, c]), PR - 2, PR)
        A[r] = (A[r] * inv) % PR
        rows = np.nonzero(A[:, c])[0]; rows = rows[rows != r]
        if rows.size: A[rows] = (A[rows] - (A[rows, c][:, None] * A[r][None, :]) % PR) % PR
        r += 1
    return r

def inertia_fr(G):
    """exact (positive, negative, zero) of a symmetric rational matrix by congruence (LDL with pivoting)"""
    A = [[Fr(x) for x in row] for row in G]; n = len(A); pos = neg = 0; k = 0
    while k < n:
        i = next((i for i in range(k, n) if A[i][i] != 0), None)
        if i is None:
            pair = next(((i, j) for i in range(k, n) for j in range(k, n) if i != j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair
            for t in range(n): A[i][t] += A[j][t]
            for t in range(n): A[t][i] += A[t][j]
        A[k], A[i] = A[i], A[k]
        for row in A: row[k], row[i] = row[i], row[k]
        d = A[k][k]; pos += d > 0; neg += d < 0
        for r in range(k + 1, n):
            if A[r][k] != 0:
                f = A[r][k] / d
                for t in range(k, n): A[r][t] -= f * A[k][t]
        for r in range(k + 1, n): A[k][r] = A[r][k] = Fr(0)
        k += 1
    return pos, neg, n - pos - neg

def mat_mul(X, Y): return [[sum(a * b for a, b in zip(r, c)) for c in zip(*Y)] for r in X]
def mat_eq(X, Y): return all(a == b for r, s in zip(X, Y) for a, b in zip(r, s))
def flat(X): return [v for r in X for v in r]
def unflat(v, d): return [list(v[i * d:(i + 1) * d]) for i in range(d)]
def tr(X): return sum(X[i][i] for i in range(len(X)))

# ================================================================================================ P. the Pauli group as a symplectic polar space
head('P. Cl(n,n), n = 1..4: the commutation form, the label quadric, Lagrangians, stabiliser states, Sp(2n,2) (polar.P1..P6)')
UNIT = ((1, 0), (0, 1), (-1, 0), (0, -1))                                  # i^t as integer pairs
def sp_count(n, k):
    num = den = 1
    for i in range(k): num *= 2 ** (2 * n - i) - 2 ** i; den *= 2 ** k - 2 ** i
    return num // den
def os_count(m, k):                                                       # totally singular k-subspaces of the hyperbolic quadric of dimension 2m
    num = den = 1
    for j in range(k): num *= 2 ** j * (2 ** (m - j) - 1) * (2 ** (m - j - 1) + 1); den *= 2 ** k - 2 ** j
    return num // den
LAG = {}; RES_P = {}
ok_form = ok_closed = ok_alt = ok_nondeg = ok_bil = ok_polar = ok_z4 = ok_sigind = ok_consist = True
ok_counts = ok_lag = ok_group = ok_idem = ok_scal = ok_states = ok_presv = ok_sp = True
for n in range(1, 5):
    N = 2 * n + (1 if FAULT == 'ODD' else 0)
    eps = (1,) * (N - n) + (-1,) * n
    A = BR(eps); M = 1 << N
    Bt = [[0 if A.s(a, b) == A.s(b, a) else 1 for b in range(M)] for a in range(M)]
    ok_closed &= all(Bt[a][b] == ((pc(a) * pc(b) + pc(a & b)) & 1) for a in range(M) for b in range(M))
    ok_alt &= all(Bt[a][a] == 0 for a in range(M)) and all(Bt[a][b] == Bt[b][a] for a in range(M) for b in range(M))
    ok_bil &= all(Bt[a][c] == (sum(Bt[1 << i][c] for i in range(N) if (a >> i) & 1) & 1) for a in range(M) for c in range(M))
    gram_rows = [sum(Bt[1 << i][1 << j] << j for j in range(N)) for i in range(N)]
    rk = f2_rank(gram_rows); rad = [x for x in range(M) if all(Bt[x][1 << j] == 0 for j in range(N))]
    ok_nondeg &= rk == N and rad == [0]
    Q = f2lib.q_clifford(N - n, n)
    ok_consist &= all(Q[a] == (1 if A.s(a, a) == -1 else 0) for a in range(M))
    ok_polar &= all(f2lib.polar(Q, a, b) == Bt[a][b] for a in range(M) for b in range(M))
    w4 = [(pc(a) & 1) + 2 * Q[a] for a in range(M)]
    ok_z4 &= all((w4[a ^ b] - w4[a] - w4[b] - 2 * pc(a & b)) % 4 == 0 for a in range(M) for b in range(M))
    qtabs = [f2lib.q_clifford(p, N - p) for p in range(N + 1)]
    ok_sigind &= all(f2lib.polar(qt, a, b) == Bt[a][b] for qt in qtabs for a in range(M) for b in range(0, M, 3))
    if FAULT == 'DOT': form = lambda a, b: pc(a & b) & 1
    else: form = lambda a, b: Bt[a][b]
    def iso(rows):
        if FAULT == 'QUAD' and any(Q[r] for r in rows): return False
        return all(form(rows[i], rows[j]) == 0 for i in range(len(rows)) for j in range(i, len(rows)))
    counts = []; lag = []
    if FAULT == 'ODD' and n == 4:
        RES_P[n] = ([0] * n, 0, 0, 0, 0); ok_lag = False; continue
    for k in range(1, n + 1):
        sel = [rows for rows in subspaces_rref(N, k) if iso(rows)]
        counts.append(len(sel))
        if k == n: lag = sel
    ok_counts &= counts[:-1] == [sp_count(n, k) for k in range(1, n)]
    ok_lag &= len(lag) == math.prod(2 ** k + 1 for k in range(1, n + 1))
    LAG[n] = lag
    keys = set(); nsig = 1 << (n - 1 if FAULT == 'SIGN' else n)
    for li, L in enumerate(lag):
        g = [(Q[a], a) for a in L]
        ok_group &= all((2 * t + (0 if A.s(a, a) == 1 else 2)) % 4 == 0 for t, a in g)
        ok_group &= all(A.s(g[x][1], g[y][1]) == A.s(g[y][1], g[x][1]) for x in range(n) for y in range(x + 1, n))
        el = {0: (0, 0)}
        for J in range(1, 1 << n):
            low = (J & -J).bit_length() - 1; t0, l0 = g[low]; t1, l1 = el[J & ~(1 << low)]
            el[J] = ((t0 + t1 + (0 if A.s(l0, l1) == 1 else 2)) % 4, l0 ^ l1)
        ok_group &= len({l for t, l in el.values()}) == 1 << n and set(l for t, l in el.values()) == set(span_f2(L))
        for sg in range(nsig):
            X = {el[J][1]: (el[J][0] + 2 * (pc(J & sg) & 1)) % 4 for J in range(1 << n)}
            keys.add(frozenset(X.items()))
            ok_scal &= X[0] == 0
            if n <= 3 or (li * nsig + sg) % 10 == 0:
                sq = {}
                for l1, t1 in X.items():
                    for l2, t2 in X.items():
                        re, im = UNIT[(t1 + t2 + (0 if A.s(l1, l2) == 1 else 2)) % 4]
                        o = sq.get(l1 ^ l2, (0, 0)); sq[l1 ^ l2] = (o[0] + re, o[1] + im)
                sq = {l: v for l, v in sq.items() if v != (0, 0)}
                ok_idem &= sq == {l: ((1 << n) * UNIT[t][0], (1 << n) * UNIT[t][1]) for l, t in X.items()}
    nst = len(keys); ok_states &= nst == 2 ** n * math.prod(2 ** k + 1 for k in range(1, n + 1))
    gens = [f2lib.transvection(Q, N, w) for w in range(1, M)]
    ok_presv &= all(Bt[f2lib.apply(t, 1 << i)][f2lib.apply(t, 1 << j)] == Bt[1 << i][1 << j] for t in gens for i in range(N) for j in range(N))
    order = f2lib.f2_group(gens, N).order(); ok_sp &= order == f2lib.order_Sp(n)
    RES_P[n] = (counts, len(lag), nst, order, len(gens))
chk('bit', ok_closed and ok_alt and ok_bil, 'polar.P1: in Cl(n,n), n = 1..4, e_a e_b = (-1)^(|a||b| - |a & b|) e_b e_a for every blade pair (BR): the commutation form beta(a,b) = pi(a)pi(b) + a.b mod 2 is symmetric, bilinear and alternating (beta(a,a) = 0)')
chk('bit', ok_nondeg, 'polar.P1: beta is non-degenerate on F2^(2n): Gram rank 2n over F2 and radical {0}, n = 1..4 (J + I has determinant N + 1 mod 2)')
chk('bit', ok_consist and ok_polar and ok_z4 and ok_sigind, 'polar.P1: the label quadric Q(a) = [e_a^2 = -1] (f2lib.q_clifford, equal to the BR squares) is a quadratic refinement of beta: Q(a+b) + Q(a) + Q(b) = beta(a,b) for all pairs; the same beta for every signature p + q = 2n; w = pi + 2Q has w(a+b) - w(a) - w(b) = 2 a.b mod 4 (core.B1)')
chk('bit', ok_counts, 'polar.P2: totally isotropic k-subspaces of beta, k < n, enumerated over all k-subspaces in echelon form: ' + '; '.join('n=%d: %s' % (n, RES_P[n][0][:-1]) for n in range(2, 5)) + ' = prod (2^(2n-i) - 2^i)/(2^k - 2^i)')
chk('bit', ok_lag, 'polar.P2: Lagrangians (maximal totally isotropic subspaces): ' + ', '.join(str(RES_P[n][1]) for n in range(1, 5)) + ' for n = 1..4 = prod_(k=1..n) (2^k + 1) = 3, 15, 135, 2295 (out of ' + ', '.join(str(gauss_binom2(2 * n, n)) for n in range(1, 5)) + ' n-subspaces)')
chk('bit', ok_group and ok_scal and ok_idem, 'polar.P3: on each Lagrangian the g_k = i^Q(a_k) e_(a_k) (BR) square to 1 and commute, their 2^n products have the 2^n labels of the Lagrangian; P = prod (1 + s_k g_k)/2 has scalar part 2^-n and P^2 = P (exact Gaussian integers; every state for n <= 3, every tenth for n = 4, the group law for all)')
chk('bit', ok_states, 'polar.P3: distinct stabiliser projectors (support and coefficients): ' + ', '.join(str(RES_P[n][2]) for n in range(1, 5)) + ' = 2^n prod (2^k + 1) = 6, 60, 1080, 36720')
chk('bit', ok_presv and ok_sp, 'polar.P4: the transvections x -> x + beta(x,w) w preserve beta; the group they generate (Schreier-Sims, f2lib; all 2^(2n) - 1 = ' + ', '.join(str(RES_P[n][4]) for n in range(1, 5)) + ' of them) has order ' + ', '.join(str(RES_P[n][3]) for n in range(1, 5)) + ' = |Sp(2n,2)| = 2^(n^2) prod (4^i - 1)')
# ---- the controls of P, computed whatever the fault
ctl_dot = []
for n in range(1, 4):
    N = 2 * n; best = 0; cnt = 0
    for k in range(1, n + 1):
        c = sum(1 for rows in subspaces_rref(N, k) if all((pc(rows[i] & rows[j]) & 1) == 0 for i in range(k) for j in range(i, k)))
        if c: best, cnt = k, c
    ctl_dot.append((n, best, cnt))
chk('ctl', all(cnt != math.prod(2 ** k + 1 for k in range(1, n + 1)) for n, best, cnt in ctl_dot), 'polar.P2: the dot product a.b (symmetric, not alternating) in place of beta: maximal totally isotropic subspaces (dimension, number) ' + ', '.join('n=%d: (%d, %d)' % t for t in ctl_dot) + ', not (n, prod (2^k + 1))')
ok_odd = True
for n in range(1, 4):
    N = 2 * n + 1; A = BR((1,) * (n + 1) + (-1,) * n); M = 1 << N
    rows = [sum((0 if A.s(1 << i, 1 << j) == A.s(1 << j, 1 << i) else 1) << j for j in range(N)) for i in range(N)]
    rad = [x for x in range(M) if all(A.s(x, 1 << j) == A.s(1 << j, x) for j in range(N))]
    ok_odd &= f2_rank(rows) == 2 * n and rad == [0, M - 1]
chk('ctl', ok_odd, 'polar.P1: with an odd number 2n+1 of generators (Cl(n+1,n), n = 1..3) the commutation form has rank 2n and radical {0, all ones} (the volume element is central): degenerate')
half = [2 ** (n - 1) * math.prod(2 ** k + 1 for k in range(1, n + 1)) for n in range(1, 5)]
chk('ctl', all(h != 2 ** n * math.prod(2 ** k + 1 for k in range(1, n + 1)) for n, h in zip(range(1, 5), half)), 'polar.P3: one sign choice dropped gives 2^(n-1) per Lagrangian: ' + ', '.join(map(str, half)) + ', not the stabiliser count (the --fault SIGN run puts this into the main lines)')
quad = []
for n in range(1, 5):
    Q = f2lib.q_clifford(n, n); N = 2 * n
    quad.append(sum(1 for rows in subspaces_rref(N, n) if all(Q[r] == 0 for r in rows) and all(f2lib.polar(Q, rows[i], rows[j]) == 0 for i in range(n) for j in range(i + 1, n))))
chk('ctl', quad == [os_count(n, n) for n in range(1, 5)] and all(quad[n - 1] != math.prod(2 ** k + 1 for k in range(1, n + 1)) for n in range(1, 5)), 'polar.P2: the quadric Q in place of beta: totally singular n-subspaces ' + ', '.join(map(str, quad)) + ' = prod_(i<n) (2^i + 1) (hyperbolic), not 3, 15, 135, 2295 (n = 4: 270 against 2295)')

# ---- [std] numpy Pauli strings
SX = np.array([[0, 1], [1, 0]], dtype=complex); SZ = np.diag([1, -1]).astype(complex); SY = np.array([[0, -1j], [1j, 0]]); I2 = np.eye(2, dtype=complex)
def pauli_mats(n):
    single = {(0, 0): I2, (1, 0): SX, (0, 1): SZ, (1, 1): SY}; out = []
    for v in range(4 ** n):
        x, z = v & ((1 << n) - 1), v >> n; Mt = np.ones((1, 1), dtype=complex)
        for k in range(n): Mt = np.kron(Mt, single[((x >> k) & 1, (z >> k) & 1)])
        out.append(Mt)
    return np.array(out)
def ikey(Mt, scale=1):
    fl = Mt.ravel(); j = int(np.argmax(np.abs(fl) > 1e-9)); Mn = Mt / fl[j] if scale == 1 else Mt * scale
    return np.concatenate([np.rint(Mn.real), np.rint(Mn.imag)]).astype(np.int16).tobytes(), (fl[j] if scale == 1 else 1)
def gate(n, U, q):                                                        # one-qubit gate U on qubit q
    Mt = np.ones((1, 1), dtype=complex)
    for k in range(n): Mt = np.kron(Mt, U if k == q else I2)
    return Mt
def cnot(n, c, t):
    d = 2 ** n; Mt = np.zeros((d, d), dtype=complex)
    for x in range(d):
        bits = [(x >> (n - 1 - k)) & 1 for k in range(n)]
        if bits[c]: bits[t] ^= 1
        y = sum(b << (n - 1 - k) for k, b in enumerate(bits)); Mt[y, x] = 1
    return Mt
RES_S = {}; ok_s_counts = ok_s_states = ok_s_proj = ok_s_neg = ok_s_cliff = ok_s_rank = True
for n in range(1, 5):
    P = pauli_mats(n); D = 4 ** n; d = 2 ** n
    kid = {}
    for v in range(D): kid[ikey(P[v])[0]] = v
    commt = np.zeros((D, D), dtype=bool); prod = np.zeros((D, D), dtype=np.int64)
    for u in range(D):
        L = P[u] @ P; R = P @ P[u]
        commt[u] = np.all(np.abs(L - R) < 1e-9, axis=(1, 2))
        for v in range(D): prod[u, v] = kid[ikey(L[v])[0]]
    levels = [{frozenset([0])}]
    while True:
        nxt = set()
        for S in levels[-1]:
            Sl = sorted(S); cand = np.nonzero(np.all(commt[Sl], axis=0))[0]
            for v in cand:
                if v in S: continue
                nxt.add(frozenset(list(S) + [int(prod[v, s]) for s in Sl]))
        if not nxt: break
        levels.append(nxt)
    cnts = [len(l) for l in levels[1:]]
    ok_s_counts &= len(levels) - 1 == n and cnts == [sp_count(n, k) for k in range(1, n + 1)]
    keys = set(); Id = np.eye(d)
    for S in levels[-1]:
        gens = []; spanS = {0}
        for v in sorted(S):
            if v not in spanS: gens.append(v); spanS |= {int(prod[v, s]) for s in spanS}
        prods = {}
        for J in range(1 << n):
            Mt = np.eye(d, dtype=complex)
            for k in range(n):
                if (J >> k) & 1: Mt = Mt @ P[gens[k]]
            prods[J] = Mt
        ok_s_neg &= all(not np.allclose(prods[J], -Id) for J in range(1, 1 << n)) and len({ikey(prods[J], 1)[0] for J in range(1 << n)}) == 1 << n
        for sg in range(1 << n):
            Pr = np.eye(d, dtype=complex)
            for k in range(n): Pr = Pr @ (Id + (-1) ** ((sg >> k) & 1) * P[gens[k]]) / 2
            ok_s_proj &= abs(np.trace(Pr) - 1) < 1e-9 and np.allclose(Pr @ Pr, Pr) and np.linalg.matrix_rank(Pr, tol=1e-9) == 1
            keys.add(ikey(Pr, d)[0])
    ok_s_states &= len(keys) == 2 ** n * math.prod(2 ** k + 1 for k in range(1, n + 1))
    ok_s_rank &= np.linalg.matrix_rank(P.reshape(D, -1)) == D
    Hd = np.array([[1, 1], [1, -1]], dtype=complex) / np.sqrt(2); Sg = np.diag([1, 1j])
    gl = [gate(n, Hd, q) for q in range(n)] + [gate(n, Sg, q) for q in range(n)] + [cnot(n, c, t) for c in range(n) for t in range(n) if c != t]
    perms = []
    for G in gl:
        pm = []
        for v in range(1, D):
            Rm = G @ P[v] @ G.conj().T; k_, c_ = ikey(Rm); w_ = kid[k_]
            j_ = int(np.argmax(np.abs(P[w_].ravel()) > 1e-9)); ph = Rm.ravel()[j_] / P[w_].ravel()[j_]
            ok_s_cliff &= abs(abs(ph) - 1) < 1e-9 and abs(ph.imag) < 1e-9 and np.allclose(Rm, ph * P[w_])
            pm.append(w_ - 1)
        perms.append(tuple(pm))
    order = permgroup.BSGS(perms, D - 1).order()
    ok_s_cliff &= order == f2lib.order_Sp(n)
    RES_S[n] = (cnts, len(levels[-1]), len(keys), order)
chk('std', ok_s_counts, 'polar.P5: numpy Pauli strings: closed commuting sets of 2^k strings (mod phases), enumerated level by level: ' + '; '.join('n=%d: %s' % (n, RES_S[n][0]) for n in range(1, 5)) + '; the maximal ones are the Lagrangians')
chk('std', ok_s_neg and ok_s_proj and ok_s_states, 'polar.P5: on each maximal set n independent strings generate 2^n distinct signed products, none equal to -1; the projectors prod (1 + s_i g_i)/2 have trace 1, P^2 = P and rank 1; distinct projectors: ' + ', '.join(str(RES_S[n][2]) for n in range(1, 5)))
chk('std', ok_s_cliff and ok_s_rank, 'polar.P6: H, S and CNOT conjugate Pauli strings to +- Pauli strings; the permutation group they generate on the 4^n - 1 strings has order ' + ', '.join(str(RES_S[n][3]) for n in range(1, 5)) + ' (permgroup.BSGS) = |Sp(2n,2)|; the 4^n strings have rank 4^n, so the kernel of the action is the Paulis times phases')
chk('bit==std', all(RES_P[n][1] == RES_S[n][1] and RES_P[n][2] == RES_S[n][2] and RES_P[n][3] == RES_S[n][3] and RES_P[n][0][:-1] == RES_S[n][0][:-1] for n in range(1, 5)), 'polar.P5: subspace counts, Lagrangians, stabiliser states and |Sp(2n,2)| agree between the bit rule and the Pauli matrices for n = 1..4')

# ================================================================================================ U. untwisting by the volume element
head('U. Cl(q + q\') = Cl(q) (x) Cl(delta q\') for q non-degenerate of even dimension, every splitting with p + q + r <= 6 (polar.U1..U3)')
def word_blade(A, J):                                                     # ordered product of generators in J as (sign, label)
    s, l = 1, 0
    for j in sorted(J): s *= A.s(l, 1 << j); l ^= 1 << j
    return s, l
def untwist_case(eq, eqp, use_delta_sign=1):
    d = len(eq); k = len(eqp); n = d + k; A = BR(tuple(eq) + tuple(eqp))
    eF = (1 << d) - 1; delta = A.s(eF, eF)
    zp = [(A.s(eF, 1 << (d + j)), eF | (1 << (d + j))) for j in range(k)]
    commute = all(A.s(1 << i, l) == A.s(l, 1 << i) for i in range(d) for s, l in zp)
    rel = True
    for j in range(k):
        for jj in range(k):
            x = A.mul({zp[j][1]: zp[j][0]}, {zp[jj][1]: zp[jj][0]}); y = A.mul({zp[jj][1]: zp[jj][0]}, {zp[j][1]: zp[j][0]})
            ac = A.add(x, y); want = {0: 2 * use_delta_sign * delta * eqp[j]} if j == jj and eqp[j] != 0 else {}
            rel &= ac == want
    Aq = BR(tuple(eq)); Ad = BR(tuple(use_delta_sign * delta * e for e in eqp))
    phi = {}
    for a in range(1 << d):
        sa, la = word_blade(A, [i for i in range(d) if (a >> i) & 1])
        for b in range(1 << k):
            s, l = sa, la
            for j in range(k):
                if (b >> j) & 1: s = s * zp[j][0] * A.s(l, zp[j][1]); l ^= zp[j][1]
            phi[(a, b)] = (s, l)
    mult = True
    for (a1, b1), (s1, l1) in phi.items():
        for (a2, b2), (s2, l2) in phi.items():
            lhs = s1 * s2 * A.s(l1, l2); s3, l3 = phi[(a1 ^ a2, b1 ^ b2)]
            rhs = Aq.s(a1, a2) * Ad.s(b1, b2) * s3
            if lhs != rhs or (l1 ^ l2) != l3: mult = False; break
        if not mult: break
    labels = {l for s, l in phi.values()}
    rk = len(labels) if len(labels) == 1 << n else rank_q([[1 if c == l else 0 for c in range(1 << n)] for s, l in phi.values()], 1 << n)
    return commute, rel, mult, rk == 1 << n, delta
dims_q = (1, 3, 5) if FAULT == 'ODDQ' else (2, 4, 6)
ncase = 0; okc = okr = okm = okk = True; deltas = Counter()
for dq in dims_q:
    for p1 in range(dq + 1):
        eq = (1,) * p1 + (-1,) * (dq - p1)
        for k in range(0, 7 - dq):
            for p2 in range(k + 1):
                for q2 in range(k - p2 + 1):
                    eqp = (1,) * p2 + (-1,) * q2 + (0,) * (k - p2 - q2)
                    c_, r_, m_, k_, dl = untwist_case(eq, eqp, -1 if FAULT == 'NEGDELTA' else 1)
                    okc &= c_; okr &= r_; okm &= m_; okk &= k_; ncase += 1; deltas[(p1, dq - p1, dl)] += 1
chk('bit', okc, 'polar.U1: z\'_j = e_F z_j commutes with every generator of q (BR), %d splittings (q of dimension 2, 4, 6 with every signature, q\' with signs +1, -1, 0, total n <= 6)' % ncase)
chk('bit', okr, 'polar.U1: z\'_j z\'_k + z\'_k z\'_j = 2 delta eps\'_j [j = k], delta = e_F^2 = ' + ', '.join('%+d for (%d,%d)' % (dl, p, q) for (p, q, dl) in sorted({(p, q, dl) for (p, q, dl) in deltas})) + ' (null z_j stay null)')
chk('bit', okm and okk, 'polar.U2: e_A (x) f_B -> e_A z\'_B is multiplicative on all 4^n basis pairs of the ungraded product Cl(q) (x) Cl(delta q\') and the 2^n images are a basis (exact rank 2^n): Cl(q + q\') = Cl(q) (x) Cl(delta q\'); with q\' = r null generators Cl(p,q,r) = Cl(p,q) (x) Lambda(R^r), p + q even')
c1, r1, m1, k1, dl1 = untwist_case((1, -1, 1), (1, -1, 0))
c2, r2, m2, k2, dl2 = untwist_case((1, 1, -1, -1), (1, -1, 0), -1)
chk('ctl', (not c1) and (not m1) and (not r1) and (not r2), 'polar.U3: q of odd dimension (signs (+1,-1,+1)): z\'_j anticommutes with q\'s generators and the map is not multiplicative; delta replaced by -delta (q = Cl(2,2), q\' = (+1,-1,0)): the relations fail on the non-null z_j')
# ---- [std] numpy matrices
XM = {1: np.array([[0., 1.], [1., 0.]]), -1: np.array([[0., -1.], [1., 0.]]), 0: np.array([[0., 0.], [1., 0.]])}
ZM = np.diag([1., -1.]); IM = np.eye(2)
def jw_gens(eps):
    n = len(eps); out = []
    for i, e in enumerate(eps):
        Mt = np.ones((1, 1))
        for k in range(n): Mt = np.kron(Mt, ZM if k < i else (XM[e] if k == i else IM))
        out.append(Mt)
    return out
def rel_table(G):
    tab = []
    for i in range(len(G)):
        for j in range(len(G)):
            c = 1 if np.allclose(G[i] @ G[j], G[j] @ G[i]) else (-1 if np.allclose(G[i] @ G[j], -G[j] @ G[i]) else 0)
            tab.append(c)
        sq = G[i] @ G[i]; tab.append(int(round(sq[0, 0])) if np.allclose(sq, sq[0, 0] * np.eye(len(sq))) else 9)
    return tab
def prod_rank(G):
    mats = []
    for J in range(1 << len(G)):
        Mt = np.eye(len(G[0]))
        for i in range(len(G)):
            if (J >> i) & 1: Mt = Mt @ G[i]
        mats.append(Mt.ravel())
    return np.linalg.matrix_rank(np.array(mats))
ok_std = True; nstd = 0
for dq in (2, 4):
    for p1 in range(dq + 1):
        eq = (1,) * p1 + (-1,) * (dq - p1)
        for eqp in ((1,), (-1,), (0,), (1, -1), (0, 0), (1, 0)):
            if dq + len(eqp) > 6: continue
            G = jw_gens(eq + eqp); d = len(eq); GF = np.eye(len(G[0]))
            for i in range(d): GF = GF @ G[i]
            delta = int(round((GF @ GF)[0, 0]))
            Zp = [GF @ G[d + j] for j in range(len(eqp))]
            lhs = G[:d] + Zp
            Gq = jw_gens(eq); Gd = jw_gens(tuple(delta * e for e in eqp))
            rhs = [np.kron(g, np.eye(len(Gd[0]))) for g in Gq] + [np.kron(np.eye(len(Gq[0])), g) for g in Gd]
            ok_std &= rel_table(lhs) == rel_table(rhs) and prod_rank(lhs) == 2 ** len(lhs) == prod_rank(rhs)
            ok_std &= all(np.allclose(z @ g, g @ z) for z in Zp for g in G[:d])
            nstd += 1
chk('std', ok_std, 'polar.U2: numpy (Z strings, sigma_x, the real rotation, sigma_minus): for %d splittings the generators e_i, e_F z_j of Cl(q + q\') and e_i (x) 1, 1 (x) z_j of Cl(q) (x) Cl(delta q\') have the same relation table and 2^n linearly independent products' % nstd)
chk('bit==std', okm and ok_std, 'polar.U2: both routes give Cl(q + q\') = Cl(q) (x) Cl(delta q\') ungraded on the cases they share')

# ================================================================================================ C. the double centraliser over R
head('C. the double centraliser over R: central simple B in End(V), the non-injective cases, the fibre Cl(0,k) in End(R^16) (polar.C1..C4)')
def regular_mats(A, side='L'):
    N = A.M; out = []
    for a in range(N):
        Mt = [[0] * N for _ in range(N)]
        for b in range(N):
            s = A.s(a, b) if side == 'L' else A.s(b, a)
            if s: Mt[a ^ b][b] = s
        out.append(Mt)
    return out
def ideal_module(A, U):
    """left action of the blades on the left ideal Cl P, P = prod (1 + e_u)/2 over a basis U of commuting blades of square +1"""
    P = A.one()
    for u in U: P = A.mul(P, {0: Fr(1, 2), u: Fr(1, 2)})
    Us = span_f2(U); reps = sorted({min(t ^ u for u in Us) for t in range(A.M)}); idx = {r: i for i, r in enumerate(reps)}
    basis = [A.mul(A.blade(t), P) for t in reps]; d = len(reps); mats = []
    for a in range(A.M):
        Mt = [[0] * d for _ in range(d)]
        for j in range(d):
            y = A.mul(A.blade(a), basis[j]); lab = min(y); i = idx[min(lab ^ u for u in Us)]
            c = y[lab] / basis[i][lab]; assert y == {l: c * v for l, v in basis[i].items()}
            Mt[i][j] = int(c)
        mats.append(Mt)
    return mats
def commutant(mats, d):
    rows = []
    for Mt in mats:
        for i in range(d):
            for j in range(d):
                r = [0] * (d * d)
                for k in range(d):
                    r[i * d + k] += Mt[k][j]; r[k * d + j] -= Mt[i][k]
                rows.append(r)
    return [unflat(v, d) for v in nullspace_fr(rows, d * d)]
def alg_generated(gens, d):
    """basis of the algebra generated by gens (exact): closure of the identity under left multiplication by the generators"""
    I_ = [[int(i == j) for j in range(d)] for i in range(d)]; rows = []; basis = []; queue = [I_]
    while queue:
        X = queue.pop()
        if len(rref_sparse(rows + [dense_to_sparse(flat(X))])) > len(basis):
            rows.append(dense_to_sparse(flat(X))); basis.append(X); queue.extend(mat_mul(g, X) for g in gens)
    return basis
def brauer_sign(basis):
    G = [[tr(mat_mul(x, y)) for y in basis] for x in basis]; p, n_, z = inertia_fr(G)
    return ('R' if p > n_ else 'H' if p < n_ else 'C'), (p, n_, z)
def dc_case(name, Bgens, d, seed=3):
    B = alg_generated(Bgens, d); C = commutant(Bgens, d)
    rng = random.Random(seed); S = []
    for _ in range(2):
        co = [rng.randint(-2, 2) for c in C]; S.append([[sum(a * c[i][j] for a, c in zip(co, C)) for j in range(d)] for i in range(d)])
    CS = commutant(S, d)                                                   # C(C) is inside C(S); B is inside C(C)
    BinCS = all(mat_eq(mat_mul(b, s), mat_mul(s, b)) for b in B for s in S)
    zdim = len(B) + len(C) - rank_q([flat(x) for x in B] + [flat(x) for x in C])      # B cap C(B) = centre of B (= centre of C when C(C) = B)
    img = rank_q([flat(mat_mul(b, c)) for b in B for c in C])
    return dict(name=name, d=d, dB=len(B), dC=len(C), dCC=len(CS), CCeqB=BinCS and len(CS) == len(B), zB=zdim, img=img,
                brB=brauer_sign(B), brC=brauer_sign(C) if len(C) <= 16 else None)
CASES = {}
A11 = BR((1, -1)); A02 = BR((-1, -1)); A04 = BR((-1, -1, -1, -1)); A01 = BR((-1,)); A30 = BR((1, 1, 1)); A03 = BR((-1, -1, -1))
CASES['M_2(R) = Cl(1,1) on R^4'] = dc_case('M2R', regular_mats(A11)[1:3], 4)
CASES['H = Cl(0,2) on R^4'] = dc_case('H', regular_mats(A02)[1:3], 4)
I8 = ideal_module(A04, [15])
CASES['M_2(H) = Cl(0,4) on R^8'] = dc_case('M2H', [I8[1], I8[2], I8[4], I8[8]], 8)
CASES['C = Cl(0,1) on R^2'] = dc_case('C', regular_mats(A01)[1:2], 2)
CASES['M_2(C) = Cl(3,0) on R^8'] = dc_case('M2C', [regular_mats(A30)[x] for x in (1, 2, 4)], 8)
CASES['H + H = Cl(0,3) on R^8'] = dc_case('HH', [regular_mats(A03)[x] for x in (1, 2, 4)], 8)
cs = ['M_2(R) = Cl(1,1) on R^4', 'H = Cl(0,2) on R^4', 'M_2(H) = Cl(0,4) on R^8']; nc = ['C = Cl(0,1) on R^2', 'M_2(C) = Cl(3,0) on R^8', 'H + H = Cl(0,3) on R^8']
if FAULT == 'NONCENTRAL': cs = cs + ['C = Cl(0,1) on R^2']
if FAULT == 'NOTSIMPLE': cs = cs + ['H + H = Cl(0,3) on R^8']
def line(c): v = CASES[c]; return '%s: dim B %d, C %d, C(C) %d, centre %d, image %d of %d' % (c, v['dB'], v['dC'], v['dCC'], v['zB'], v['img'], v['dB'] * v['dC'])
ok_cs = all(CASES[c]['zB'] == 1 and CASES[c]['CCeqB'] and CASES[c]['img'] == CASES[c]['dB'] * CASES[c]['dC'] == CASES[c]['d'] ** 2 and CASES[c]['brC'] is not None and CASES[c]['brC'][1][2] == 0 for c in cs)
chk('bit', ok_cs, 'polar.C1: central simple B (exact): ' + '; '.join(line(c) for c in cs[:3]) + ': centre of C = C cap C(C) = C cap B of dimension 1, trace form of C non-degenerate (C central simple), C(C) = B (C(C) inside the commutant of two elements of C, of the dimension of B), B (x) C -> End(V) bijective')
ok_br = all(CASES[c]['brC'] is not None and CASES[c]['brB'][0] == CASES[c]['brC'][0] for c in cs[:3])
chk('bit', ok_br, 'polar.C1: Brauer classes by the sign of the trace-form signature (p, n, 0): ' + '; '.join('%s: B %s %s, C %s %s' % (c.split(' =')[0], CASES[c]['brB'][0], CASES[c]['brB'][1][:2], CASES[c]['brC'][0], CASES[c]['brC'][1][:2]) for c in cs[:3]) + ': [C] = [B] = [B]^-1 (every class of Br(R) = Z2 has order <= 2, recalled)')
ok_nc = all(CASES[c]['zB'] == 2 and CASES[c]['CCeqB'] and CASES[c]['img'] * 2 == CASES[c]['dB'] * CASES[c]['dC'] for c in nc)
chk('bit', ok_nc, 'polar.C2: centre C or R^2 (exact): ' + '; '.join(line(c) for c in nc) + ': C(C) = B still, the map B (x) C(B) -> End(V) is not injective (kernel of half the dimension)')
# ---- the fibre: Cl(0,8) on a minimal left ideal R^16
A08 = BR((-1,) * 8); Q08 = f2lib.q_clifford(0, 8)
solid = []
for a in range(1, 256):
    if Q08[a] == 0 and all(A08.s(a, b) == A08.s(b, a) for b in solid) and a not in span_f2(solid): solid.append(a)
    if len(solid) == 4: break
M16 = ideal_module(A08, solid); GAM = [M16[1 << i] for i in range(8)]
def sperm(Mt):
    d = len(Mt); perm = [0] * d; sign = [0] * d
    for c in range(d):
        r = next(r for r in range(d) if Mt[r][c] != 0); perm[c] = r; sign[c] = Mt[r][c]
    return perm, sign
def orbit_commutant(gens, d):
    parent = list(range(d * d)); par = [0] * (d * d); bad = set()
    def find(x):
        p = 0
        while parent[x] != x: p ^= par[x]; x = parent[x]
        return x, p
    for Mt in gens:
        perm, sign = sperm(Mt)
        for r in range(d):
            for c in range(d):
                x, y, s = r * d + c, perm[r] * d + perm[c], 0 if sign[r] * sign[c] == 1 else 1
                (rx, px), (ry, py) = find(x), find(y)
                if rx == ry:
                    if px ^ py ^ s: bad.add(rx)
                else: parent[ry] = rx; par[ry] = px ^ py ^ s
    groups = {}
    for x in range(d * d):
        rx, px = find(x); groups.setdefault(rx, []).append((x, px))
    bad = {find(b)[0] for b in bad}; out = []
    for rx, mem in groups.items():
        if rx in bad: continue
        Mt = [[0] * d for _ in range(d)]
        for x, px in mem: Mt[x // d][x % d] = -1 if px else 1
        out.append(Mt)
    return out
def npm(Mt): return np.array(Mt, dtype=np.int64)
FIB = []; ok_fib = True
for k in range(0, 9):
    Bb = []
    for J in range(1 << k):
        Mt = np.eye(16, dtype=np.int64)
        for i in range(k):
            if (J >> i) & 1: Mt = Mt @ npm(GAM[i])
        Bb.append(Mt)
    Cb = [npm(x) for x in orbit_commutant(GAM[:k], 16)] if k else [npm([[1 if (r * 16 + c) == x else 0 for c in range(16)] for r in range(16)]) for x in range(256)]
    commutes = all((npm(g) @ c == c @ npm(g)).all() for g in GAM[:k] for c in Cb)
    rng = random.Random(100 + k); T = [sum(rng.randint(-3, 3) * c for c in Cb) for _ in range(6)]
    K = np.vstack([np.kron(np.eye(16, dtype=np.int64), t.T) - np.kron(t, np.eye(16, dtype=np.int64)) for t in T])
    dCC_upper = 256 - rank_modp(K)
    img_lower = rank_modp(np.array([(b @ c).ravel() for b in Bb for c in Cb]))
    if k % 2 == 1:
        z = Bb[-1]
        Rz = np.zeros((len(Bb), len(Bb)), dtype=np.int64)
        lab = {b.tobytes(): i for i, b in enumerate(Bb)}; labn = {(-b).tobytes(): i for i, b in enumerate(Bb)}
        for i, b in enumerate(Bb):
            y = b @ z
            if y.tobytes() in lab: Rz[lab[y.tobytes()], i] = 1
            else: Rz[labn[y.tobytes()], i] = -1
        pos = [next((r, c) for r in range(16) for c in range(16) if cb[r, c] != 0) for cb in Cb]
        Lz = np.array([[(z @ Cb[j])[pos[i]] * Cb[i][pos[i]] for j in range(len(Cb))] for i in range(len(Cb))], dtype=np.int64)
        recon = all((sum(Lz[i, j] * Cb[i] for i in range(len(Cb))) == z @ Cb[j]).all() for j in range(len(Cb)))
        Tz = np.kron(Rz, np.eye(len(Cb), dtype=np.int64)) - np.kron(np.eye(len(Bb), dtype=np.int64), Lz)
        img_upper = len(Bb) * len(Cb) - rank_modp(Tz)
        ok_fib &= recon
    else:
        img_upper = len(Bb) * len(Cb)
    FIB.append((k, len(Bb), len(Cb), dCC_upper, img_lower, img_upper, commutes))
ok_g3c = all(dB == 2 ** k and dC == 2 ** (8 - k) and dCC == 2 ** k and com for k, dB, dC, dCC, il, iu, com in FIB)
chk('bit', ok_g3c, 'polar.C3: the fibre (eight gamma of Cl(0,8) on a minimal left ideal R^16 of BR, solid ' + str(solid) + '): dim B = 2^k, dim C(B) = 2^(8-k) (exact monomial orbits), dim C(C) = 2^k (rank mod p with B in C(C)), k = 0..8: ' + ', '.join('%d/%d/%d' % (dB, dC, dCC) for k, dB, dC, dCC, il, iu, com in FIB) + ' (fibre.G3c)')
ok_img = ok_fib and all((il == iu == 256) if k % 2 == 0 else (il == iu == 128) for k, dB, dC, dCC, il, iu, com in FIB)
if FAULT == 'NONCENTRAL': ok_img &= all(il == 256 for k, dB, dC, dCC, il, iu, com in FIB if k == 1)
chk('bit', ok_img, 'polar.C3: B (x) C(B) -> End(R^16): image ' + ', '.join('%d' % il for k, dB, dC, dCC, il, iu, com in FIB) + ' for k = 0..8: bijective for k even (R, H, M_2(H), M_8(R), M_16(R): central simple), image 128 of 256 for k odd (centre C for k = 1, 5; R^2 for k = 3, 7; kernel exhibited as the image of z (x) 1 - 1 (x) z, z the product of the k gamma)')
chk('ctl', CASES['C = Cl(0,1) on R^2']['img'] < 4 and CASES['H + H = Cl(0,3) on R^8']['img'] == 32 and CASES['H + H = Cl(0,3) on R^8']['dCC'] == 8, 'polar.C2: a non-central B (C on R^2: image %d of 4) and a non-simple B (H + H on R^8: C(C(B)) = B of dimension 8, image 32 of 64) fail the bijectivity that the central simple cases have' % CASES['C = Cl(0,1) on R^2']['img'])
# ---- [std] numpy
def np_commutant(mats, d):
    G = np.zeros((d * d, d * d))
    for Mt in mats:
        K = np.kron(np.eye(d), Mt.T) - np.kron(Mt, np.eye(d)); G += K.T @ K
    w, v = np.linalg.eigh(G); return [v[:, i].reshape(d, d) for i in range(d * d) if w[i] < 1e-9]
def np_span(mats): return np.linalg.matrix_rank(np.array([m.ravel() for m in mats]), tol=1e-8) if mats else 0
def np_case(gens, d):
    r = np_case_(gens, d); return tuple(int(x) for x in r)
def np_case_(gens, d):
    alg = [np.eye(d)]
    for _ in range(4):
        alg = alg + [g @ a for g in gens for a in alg]
        U, s, Vt = np.linalg.svd(np.array([a.ravel() for a in alg]), full_matrices=False); alg = [Vt[i].reshape(d, d) for i in range(int((s > 1e-8).sum()))]
    C = np_commutant(gens, d); CC = np_commutant(C, d)
    img = np_span([b @ c for b in alg for c in C])
    return len(alg), len(C), len(CC), img
qi = np.array([[0, -1, 0, 0], [1, 0, 0, 0], [0, 0, 0, -1], [0, 0, 1, 0]], float)
qj = np.array([[0, 0, -1, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, -1, 0, 0]], float)
assert np.allclose(qi @ qi, -np.eye(4)) and np.allclose(qi @ qj, -(qj @ qi))
J2 = np.array([[0., -1.], [1., 0.]])
def realify(Mc): return np.block([[Mc.real, -Mc.imag], [Mc.imag, Mc.real]])
E = lambda i, j: np.array([[1. if (r, c) == (i, j) else 0. for c in range(2)] for r in range(2)])
STD = {}
STD['M_2(R) = Cl(1,1) on R^4'] = np_case([np.kron(E(0, 1), np.eye(2)), np.kron(E(1, 0), np.eye(2))], 4)
STD['H = Cl(0,2) on R^4'] = np_case([qi, qj], 4)
STD['M_2(H) = Cl(0,4) on R^8'] = np_case([np.kron(E(0, 1), np.eye(4)), np.kron(E(1, 0), np.eye(4)), np.kron(np.eye(2), qi), np.kron(np.eye(2), qj)], 8)
STD['C = Cl(0,1) on R^2'] = np_case([J2], 2)
STD['M_2(C) = Cl(3,0) on R^8'] = np_case([realify(np.kron(s, np.eye(2))) for s in (SX, SY, SZ)], 8)
Z4_ = np.zeros((4, 4))
STD['H + H = Cl(0,3) on R^8'] = np_case([np.block([[qi, Z4_], [Z4_, qi]]), np.block([[qj, Z4_], [Z4_, qj]]), np.block([[qi @ qj, Z4_], [Z4_, -(qi @ qj)]])], 8)
chk('std', all(STD[c] == (CASES[c]['dB'], CASES[c]['dC'], CASES[c]['dCC'], CASES[c]['img']) for c in CASES), 'polar.C4: numpy from quaternion units, Pauli matrices and block sums (SVD null spaces): (dim B, dim C, dim C(C), image) ' + '; '.join('%s %s' % (c.split(' =')[0], STD[c]) for c in CASES) + ' = the exact values')
mats3 = [np.kron(np.kron(a, b), c) for a in (IM, XM[1], ZM, XM[-1]) for b in (IM, XM[1], ZM, XM[-1]) for c in (IM, XM[1], ZM, XM[-1])]
anti = [m for m in mats3 if np.allclose(m.T, -m)]
def search7(chosen, start):
    if len(chosen) == 7: return chosen
    for i in range(start, len(anti)):
        if all(np.allclose(anti[i] @ c, -(c @ anti[i])) for c in chosen):
            r = search7(chosen + [anti[i]], i + 1)
            if r: return r
    return None
L7 = search7([], 0)
G16 = [np.block([[np.zeros((8, 8)), l], [l, np.zeros((8, 8))]]) for l in L7] + [np.block([[np.zeros((8, 8)), -np.eye(8)], [np.eye(8), np.zeros((8, 8))]])]
ok_g16 = all(np.allclose(g @ g, -np.eye(16)) for g in G16) and all(np.allclose(G16[i] @ G16[j], -(G16[j] @ G16[i])) for i in range(8) for j in range(i))
STDF = []
for k in (1, 2, 3, 4):
    STDF.append(np_case(G16[:k], 16))
chk('std', ok_g16 and all(STDF[k - 1] == (FIB[k][1], FIB[k][2], FIB[k][3], FIB[k][4]) for k in (1, 2, 3, 4)), 'polar.C4: numpy, eight anticommuting real 16 x 16 matrices of square -1 (Kronecker products, searched): (dim B, dim C, dim C(C), image) for k = 1..4: ' + ', '.join(str(x) for x in STDF) + ' = the exact values')

# ================================================================================================ W. the Witt decomposition
head('W. the Witt decomposition of every real quadratic space with p + q + r <= 8 (polar.W1..W3)')
def vec_form(A, x, y):
    s = A.add(A.mul(x, y), A.mul(y, x)); return Fr(s.get(0, 0), 2)
okW = okI = okP = okR = True; ntrip = 0
for n in range(0, 9):
    for p in range(n + 1):
        for q in range(n + 1 - p):
            r = n - p - q; eps = (1,) * p + (-1,) * q + (0,) * r; A = BR(eps); m = min(p, q); ntrip += 1
            gen = lambda i, c=1: {1 << i: Fr(c)}
            basis = []; blocks = []
            for t in range(m):
                i, j = t, p + t
                if FAULT == 'SAMESIGN' and p >= 2: i, j = 0, 1
                basis.append(A.add(gen(i), gen(j))); basis.append(A.add(gen(i, Fr(1, 2)), gen(j, Fr(1, 2)), -1)); blocks.append('H')
            rest = list(range(m, p)) + list(range(p + m, p + q))
            for i in rest: basis.append(gen(i)); blocks.append('+' if eps[i] == 1 else '-')
            for i in range(p + q, n): basis.append(gen(i)); blocks.append('0')
            G = [[vec_form(A, x, y) for y in basis] for x in basis]
            want = [[Fr(0)] * n for _ in range(n)]; pos_ = 0
            for b in blocks:
                if b == 'H': want[pos_][pos_ + 1] = want[pos_ + 1][pos_] = Fr(1); pos_ += 2
                else: want[pos_][pos_] = Fr({'+': 1, '-': -1, '0': 0}[b]); pos_ += 1
            okW &= G == want and rank_q([[x.get(1 << c, 0) for c in range(n)] for x in basis], n) == n
            us = basis[0:2 * m:2]
            okI &= all(A.add(A.mul(x, y), A.mul(y, x)) == {} for x in us for y in us)
            okP &= all(vec_form(A, basis[2 * t], basis[2 * t + 1]) == 1 for t in range(m))
            okR &= all(vec_form(A, gen(i), gen(c)) == 0 for i in range(p + q, n) for c in range(n))
            declared_r = r + (1 if FAULT == 'RAD' else 0)
            okR &= sum(1 for row in G if all(v == 0 for v in row)) == declared_r
chk('bit', okW, 'polar.W1: for all %d triples (p,q,r) with p + q + r <= 8 the basis u_t = e_i + e_j, v_t = (e_i - e_j)/2 (e_i^2 = +1, e_j^2 = -1, t < min(p,q)), the other |p - q| generators and the r null ones has Gram matrix diag(H, ..., H, +-1, ..., 0, ...) exactly (BR), H = [[0,1],[1,0]]: V = H^m + V_an + rad, m = min(p,q), dim V_an = |p - q|, dim rad = r' % ntrip)
chk('bit', okI and okP and okR, 'polar.W2: span(u_1..u_m) is totally isotropic (u_s u_t + u_t u_s = 0 by BR), every u_t is paired (B(u_t, v_t) = 1: paired null), every null generator is orthogonal to every generator (radical null), and the Gram matrix has exactly r zero rows; the Witt index is m = min(p,q) (m + r with the radical); no larger totally isotropic subspace by the signature bound (recalled)')
rngW = random.Random(55); okS = okL = True; nS = 0
for (p, q, r) in [(p, q, n - p - q) for n in range(1, 9) for p in range(n + 1) for q in range(n + 1 - p)]:
    n = p + q + r; eps = [1] * p + [-1] * q + [0] * r
    S = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    for _ in range(3 * n):
        i, j = rngW.sample(range(n), 2) if n > 1 else (0, 0)
        if i != j:
            c = rngW.randint(-2, 2)
            for t in range(n): S[t][i] += c * S[t][j]
    G = [[sum(S[t][a] * eps[t] * S[t][b] for t in range(n)) for b in range(n)] for a in range(n)]
    ev = np.linalg.eigvalsh(np.array(G, float)); tol = 1e-9 * max(1, np.abs(ev).max())
    okS &= (int((ev > tol).sum()), int((ev < -tol).sum()), int((np.abs(ev) <= tol).sum())) == (p, q, r)
    okL &= inertia_fr(G) == (p, q, r); nS += 1
chk('std', okS and okL, 'polar.W3: %d congruent Gram matrices S^T diag(eps) S (S random unimodular, fixed seed): numpy eigenvalue signs and exact LDL inertia both give (p, q, r), hence m = min(p,q), |p - q|, r (Sylvester\'s law, recalled)' % nS)
A22 = BR((1, 1, -1)); u_bad = {1: 1, 2: 1}
chk('ctl', vec_form(A22, u_bad, u_bad) == 2, 'polar.W3: e_1 + e_2 with e_1^2 = e_2^2 = +1 has B(u,u) = %s: two generators of the same sign do not give a hyperbolic pair' % vec_form(A22, u_bad, u_bad))
G101 = [[vec_form(BR((1, -1, 0)), {1 << a: 1}, {1 << b: 1}) for b in range(3)] for a in range(3)]
chk('ctl', sum(1 for row in G101 if all(v == 0 for v in row)) != 2, 'polar.W3: a Gram matrix declared with radical 2 for Cl(1,1,1) has %d zero rows: the wrong radical size is detected' % sum(1 for row in G101 if all(v == 0 for v in row)))

# ================================================================================================ L. the spin table at the Lie-algebra level
head('L. low-dimensional spin isomorphisms: bivector algebras, Killing signatures, even-part types (polar.L1..L3)')
def bivector_killing(p, q):
    A = BR((1,) * p + (-1,) * q); n = p + q; biv = [a for a in range(1 << n) if pc(a) == 2]; ix = {a: i for i, a in enumerate(biv)}
    ad = []
    for a in biv:
        Mt = [[0] * len(biv) for _ in biv]
        for b in biv:
            c = comm(A, {a: 1}, {b: 1})
            for l, v in c.items(): Mt[ix[l]][ix[b]] += v
        ad.append(Mt)
    K = [[tr(mat_mul(x, y)) for y in ad] for x in ad]
    return len(biv), inertia_fr(K)
def cl_type(eps):
    A = BR(eps); n = len(eps); N = 1 << n
    sq = [A.s(a, a) for a in range(N)]; cen = [a for a in range(N) if all(A.s(a, 1 << i) == A.s(1 << i, a) for i in range(n))]
    plus = sq.count(1); minus = N - plus
    if len(cen) == 1:
        D = 'R' if plus > minus else 'H'; k = math.isqrt(N // (1 if D == 'R' else 4)); return 'M_%d(%s)' % (k, D) if k > 1 else D
    if sq[cen[1]] == -1: return 'M_%d(C)' % math.isqrt(N // 2) if N > 2 else 'C'
    D = 'R' if plus > minus else 'H'; k = math.isqrt(N // 2 // (1 if D == 'R' else 4))
    return ('M_%d(%s)+M_%d(%s)' % (k, D, k, D)) if k > 1 else ('%s+%s' % (D, D))
def even_part(p, q):
    """Cl^0(p,q) = Cl(p,q-1) by f_i = e_i e_t (t the last generator of square -1): relations checked by BR"""
    A = BR((1,) * p + (-1,) * q); n = p + q; t = n - 1
    f = [A.mul({1 << i: 1}, {1 << t: 1}) for i in range(n - 1)]
    sqs = tuple(A.mul(x, x)[0] for x in f)
    okr = all(anticomm(A, f[i], f[j]) == {} for i in range(n - 1) for j in range(i))
    return sqs, okr
TABLE = [((3, 0), 'su(2)', 'H'), ((1, 2), 'sl(2,R)', 'M_2(R)'), ((1, 3), 'sl(2,C)', 'M_2(C)'), ((2, 2), 'sl(2,R)+sl(2,R)', 'M_2(R)+M_2(R)'),
         ((3, 3), 'sl(4,R)', 'M_4(R)+M_4(R)'), ((2, 4), 'su(2,2)', 'M_4(C)'), ((1, 5), 'sl(2,H)', 'M_2(H)+M_2(H)')]
KB = {}; okK = okE = True; ev_types = {}
for (p, q), name, etype in TABLE:
    dim_, (kp, kn, kz) = bivector_killing(p, q); KB[(p, q)] = (dim_, kp, kn)
    okK &= dim_ == (p + q) * (p + q - 1) // 2 and (kp, kn, kz) == (p * q, p * (p - 1) // 2 + q * (q - 1) // 2, 0)
    sqs, okr = even_part(p, q); ty = cl_type(sqs); ev_types[(p, q)] = ty
    okE &= okr and ty == etype
chk('bit', okK, 'polar.L1: bivector algebras of Cl(p,q) (BR commutators, exact Killing form and inertia): ' + ', '.join('Cl(%d,%d): dim %d, (%d,%d)' % (p, q, *KB[(p, q)]) for (p, q), _, _ in TABLE) + ' = (pq, p(p-1)/2 + q(q-1)/2)')
chk('bit', okE, 'polar.L1: even parts Cl^0(p,q) = Cl(p,q-1) (f_i = e_i e_t, relations by BR) of types ' + ', '.join('%s' % ev_types[pq] for pq, _, _ in TABLE) + ' (computed: centre, square of the volume element, trace-form sign; cat.C1): SU(2), SL(2,R), SL(2,C), SL(2,R)^2, SU(2,2) sit in these algebras, SL(4,R) and SL(2,H) in one of the two simple factors (a half-spin representation)')
def lie_sig(basis, cplx=False):
    V = np.array([np.concatenate([b.real.ravel(), b.imag.ravel()]) for b in basis]).T
    def coords(X): return np.linalg.lstsq(V, np.concatenate([X.real.ravel(), X.imag.ravel()]), rcond=None)
    ad = []
    for a in basis:
        cols = []
        for b in basis:
            c, res, rk, sv = coords(a @ b - b @ a); cols.append(c)
        ad.append(np.array(cols).T)
    K = np.array([[np.trace(x @ y) for y in ad] for x in ad]); ev = np.linalg.eigvalsh((K + K.T) / 2)
    tol = 1e-8 * max(1, np.abs(ev).max()); return len(basis), int((ev > tol).sum()), int((ev < -tol).sum())
def null_basis(constraints, dimc, shape):
    U, s, Vt = np.linalg.svd(constraints); r = int((s > 1e-10).sum())
    out = []
    for v in Vt[r:]:
        X = (v[:dimc // 2] + 1j * v[dimc // 2:]).reshape(shape); out.append(X)
    return out
def su22():
    eta = np.diag([1, 1, -1, -1]).astype(complex); rows = []
    for t in range(32):
        v = np.zeros(32); v[t] = 1; X = (v[:16] + 1j * v[16:]).reshape(4, 4)
        Y = X.conj().T @ eta + eta @ X; rows.append(np.concatenate([Y.real.ravel(), Y.imag.ravel(), [np.trace(X).real, np.trace(X).imag]]))
    return null_basis(np.array(rows).T, 32, (4, 4))
def slH():
    Jq = np.block([[np.zeros((2, 2)), -np.eye(2)], [np.eye(2), np.zeros((2, 2))]]).astype(complex); rows = []
    for t in range(32):
        v = np.zeros(32); v[t] = 1; X = (v[:16] + 1j * v[16:]).reshape(4, 4)
        Y = X @ Jq - Jq @ X.conj(); rows.append(np.concatenate([Y.real.ravel(), Y.imag.ravel(), [np.trace(X).real, np.trace(X).imag]]))
    return null_basis(np.array(rows).T, 32, (4, 4))
Hs, Es, Fs = np.diag([1., -1.]).astype(complex), np.array([[0, 1], [0, 0]], complex), np.array([[0, 0], [1, 0]], complex)
def blk(a, b): return np.block([[a, np.zeros((2, 2))], [np.zeros((2, 2)), b]])
def E4(i, j): X = np.zeros((4, 4), complex); X[i, j] = 1; return X
MAT = {'su(2)': [1j * SX, 1j * SY, 1j * SZ], 'sl(2,R)': [Hs, Es, Fs], 'sl(2,C)': [Hs, Es, Fs, 1j * Hs, 1j * Es, 1j * Fs],
       'sl(2,R)+sl(2,R)': [blk(x, 0 * x) for x in (Hs, Es, Fs)] + [blk(0 * x, x) for x in (Hs, Es, Fs)],
       'sl(4,R)': [E4(i, j) for i in range(4) for j in range(4) if i != j] + [E4(i, i) - E4(i + 1, i + 1) for i in range(3)],
       'su(2,2)': su22(), 'sl(2,H)': slH()}
SIGS = {nm: lie_sig(b) for nm, b in MAT.items()}
pairs = [((p, q), name) for (p, q), name, _ in TABLE]
if FAULT == 'MISMATCH': pairs[3] = ((2, 2), 'sl(2,C)')
chk('std', all(SIGS[nm] == KB[pq] for pq, nm in pairs), 'polar.L2: numpy matrix Lie algebras, (dimension, Killing +, Killing -): ' + ', '.join('%s %s' % (nm, SIGS[nm]) for _, nm, _ in TABLE) + ' = the bivector algebras row by row')
chk('ctl', SIGS['sl(2,C)'] != KB[(2, 2)], 'polar.L2: a mismatched pair, so(2,2) %s against sl(2,C) as a real algebra %s: different Killing signatures' % (KB[(2, 2)][1:], SIGS['sl(2,C)'][1:]))
def iso_check(p, q, images):
    A = BR((1,) * p + (-1,) * q); biv = [a for a in range(1 << (p + q)) if pc(a) == 2]; ok = True
    for a in biv:
        for b in biv:
            c = comm(A, {a: 1}, {b: 1}); lhs = sum((v * images[l] for l, v in c.items()), np.zeros_like(images[biv[0]]))
            ok &= np.allclose(lhs, images[a] @ images[b] - images[b] @ images[a])
    rk = np.linalg.matrix_rank(np.array([np.concatenate([images[a].real.ravel(), images[a].imag.ravel()]) for a in biv]))
    return ok and rk == len(biv)
im3 = {0b011: SX @ SY, 0b101: SX @ SZ, 0b110: SY @ SZ}
im12 = {0b011: XM[1] @ XM[-1] + 0j, 0b101: XM[1] + 0j, 0b110: XM[-1] + 0j}
im13 = {0b0011: -SX, 0b0101: -SY, 0b1001: -SZ, 0b0110: -(SX @ SY), 0b1010: -(SX @ SZ), 0b1100: -(SY @ SZ)}
ok_iso = iso_check(3, 0, im3) and iso_check(1, 2, im12) and iso_check(1, 3, im13)
ok_iso &= all(abs(np.trace(x)) < 1e-12 and np.allclose(x.conj().T, -x) for x in im3.values()) and all(np.allclose(x.imag, 0) and abs(np.trace(x)) < 1e-12 for x in im12.values()) and all(abs(np.trace(x)) < 1e-12 for x in im13.values())
chk('bit==std', ok_iso, 'polar.L3: isomorphisms exhibited: e_12, e_13, e_23 -> s1 s2, s1 s3, s2 s3 (so(3) onto su(2): traceless anti-hermitian), e_12, e_13, e_23 -> X J, X, J (so(1,2) onto sl(2,R): traceless real, from Cl^0(1,2) = M_2(R)), e_0i -> -s_i, e_ij -> -s_i s_j (so(1,3) onto sl(2,C), from Cl^0(1,3) = Cl(3,0)): every BR bracket maps to the matrix bracket and the images are independent; the other four rows are matched invariants (the isomorphisms are recalled)')

# ================================================================================================ F. the two families of solids and triality
head('F. Cl(8,0) over F2: points, the two families of solids, transvections, the index-2 stabiliser, triality; D4 weights and pure spinors (polar.F1..F6)')
Q8 = f2lib.q_clifford(8, 0); pts8 = [v for v in range(1, 256) if Q8[v] == 0]
solids = [frozenset(span_f2(rows)) for rows in subspaces_rref(8, 4) if all(Q8[r] == 0 for r in rows) and all(f2lib.polar(Q8, rows[i], rows[j]) == 0 for i in range(4) for j in range(i + 1, 4))]
if FAULT == 'NONSING': solids = solids[:-1] + [frozenset(span_f2([1, 2, 4, 8]))]
same = lambda U, V: ((len(U & V).bit_length() - 1) % 2) == 0
fam = [0 if same(solids[0], U) else 1 for U in solids]
ok_eq = all(same(solids[i], solids[j]) == (fam[i] == fam[j]) for i in range(len(solids)) for j in range(len(solids)))
ok_ts = all(all(Q8[x] == 0 for x in U) and all(f2lib.polar(Q8, x, y) == 0 for x in U for y in U) for U in solids)
chk('bit', len(pts8) == 135 and len(solids) == 270 and fam.count(0) == fam.count(1) == 135 and ok_eq and ok_ts, 'polar.F1: Cl(8,0): %d singular points, %d totally singular solids (enumerated over all 200787 4-subspaces), two families of %d and %d; dim(U ∩ U\') even is an equivalence with these two classes (T11, cat.W2-W3)' % (len(pts8), len(solids), fam.count(0), fam.count(1)))
sidx = {U: i for i, U in enumerate(solids)}
nonsing = [w for w in range(1, 256) if Q8[w] == 1]; sing_w = pts8[0]
refl = [f2lib.transvection(Q8, 8, w) for w in ([sing_w] + nonsing[1:] if FAULT == 'SINGREFL' else nonsing)]
def img(t, U): return frozenset(f2lib.apply(t, x) for x in U)
ok_swap = True
for t in refl:
    for i, U in enumerate(solids):
        V = img(t, U)
        if V not in sidx or fam[sidx[V]] == fam[i]: ok_swap = False; break
    if not ok_swap: break
t0 = refl[0]; ok_keep = True
for t in refl[1:]:
    tt = f2lib.mul(t0, t)
    for i, U in enumerate(solids):
        V = img(tt, U)
        if V not in sidx or fam[sidx[V]] != fam[i]: ok_keep = False; break
chk('bit', ok_swap and ok_keep, 'polar.F2: each of the %d transvections t_w (Q(w) = 1) maps every one of the 270 solids to a solid of the other family; t_w0 t_w keeps every solid in its family (reflections exchange the families, products of two keep them)' % len(refl))
oO = f2lib.f2_group(refl, 8).order(); oE = f2lib.f2_group([f2lib.mul(t0, t) for t in refl[1:]], 8).order()
oF = f2lib.order_O_formula(f2lib.form_invariants(Q8, 8))
chk('bit', oO == oF == 348364800 and 2 * oE == oO, 'polar.F2: Schreier-Sims: |<t_w>| = %d = |O+(8,2)| (formula %d), |<t_w0 t_w>| = %d = |O+(8,2)|/2; it keeps each family and t_w0 does not, so it is the stabiliser of a family, of index 2' % (oO, oF, oE))
tsing = f2lib.transvection(Q8, 8, sing_w)
chk('ctl', any(Q8[f2lib.apply(tsing, x)] != Q8[x] for x in range(256)), 'polar.F2: a transvection by a singular vector is not an isometry of Q (it moves some vector of Q = 0 to Q = 1)')
chk('ctl', not all(Q8[x] == 0 for x in span_f2([1, 2, 4, 8])), 'polar.F1: the span of the labels e_1..e_4 contains e_12 with Q = 1 (a non-singular vector): not totally singular, so not a solid')
chk('ctl', all(fam[i] != fam[j] for i in range(0, 270, 9) for j in range(270) if (len(solids[i] & solids[j]).bit_length() - 1) % 2 == 1), 'polar.F1: two solids with an odd-dimensional intersection are always in different families')
# ---- incidence graphs and triality
F1 = [U for U, f in zip(solids, fam) if f == 0]; F2 = [U for U, f in zip(solids, fam) if f == 1]
NV = 405; part = [0] * 135 + [1] * 135 + [2] * 135; nb = [set() for _ in range(NV)]
for i, p_ in enumerate(pts8):
    for j, U in enumerate(F1):
        if p_ in U: nb[i].add(135 + j); nb[135 + j].add(i)
    for j, U in enumerate(F2):
        if p_ in U: nb[i].add(270 + j); nb[270 + j].add(i)
for i, U in enumerate(F1):
    for j, V in enumerate(F2):
        if len(U & V) == 8: nb[135 + i].add(270 + j); nb[270 + j].add(135 + i)
def bip_inv(a, b):
    deg = Counter(len([x for x in nb[v] if part[x] == b]) for v in range(NV) if part[v] == a)
    cn = Counter(len({x for x in nb[u] if part[x] == b} & {x for x in nb[v] if part[x] == b}) for u in range(NV) if part[u] == a for v in range(u + 1, NV) if part[v] == a)
    return dict(deg), dict(cn)
INV = [bip_inv(0, 1), bip_inv(1, 0), bip_inv(0, 2), bip_inv(2, 0), bip_inv(1, 2), bip_inv(2, 1)]
chk('bit', all(x == INV[0] for x in INV), 'polar.F3: the three incidence graphs (points/family 1 by inclusion, points/family 2 by inclusion, family 1/family 2 by meeting in a plane), read from both sides: degrees %s, common-neighbour counts %s, identical for all six (fibre.G7d has the 15/15)' % (INV[0][0], INV[0][1]))
sys.setrecursionlimit(5000)
tau = {}; NODES = [0]
dom0 = {v: {x for x in range(NV) if part[x] == (part[v] + 1) % 3} for v in range(NV)}
def extend(dom):
    if len(tau) == NV: return True
    NODES[0] += 1
    if NODES[0] > 200000: return False
    v = min((u for u in range(NV) if u not in tau), key=lambda u: (len(dom[u]), u))
    for c in sorted(dom[v]):
        nd = {}; ok = True
        for u in range(NV):
            if u in tau or u == v: continue
            du = dom[u] & nb[c] if u in nb[v] else dom[u] - nb[c] - {c}
            if not du: ok = False; break
            nd[u] = du
        if not ok: continue
        tau[v] = c
        if extend(nd): return True
        del tau[v]
    return False
found = extend(dom0)
ok_tau = found and len(tau) == NV and len(set(tau.values())) == NV and all(part[tau[v]] == (part[v] + 1) % 3 for v in range(NV)) and all((u in nb[v]) == (tau[u] in nb[tau[v]]) for v in range(NV) for u in range(NV))
o3 = None
if ok_tau:
    o3 = 1; seen_c = set()
    for v in range(NV):
        if v in seen_c: continue
        L_, x = 0, v
        while x not in seen_c: seen_c.add(x); x = tau[x]; L_ += 1
        o3 = o3 * L_ // math.gcd(o3, L_)
tau3 = {}
if ok_tau:
    t2 = {v: tau[tau[v]] for v in range(NV)}; t4 = {v: t2[t2[v]] for v in range(NV)}
    tau3 = t4 if o3 % 3 == 0 and o3 % 2 == 0 else tau
ok_t3 = bool(tau3) and all(tau3[tau3[tau3[v]]] == v for v in range(NV)) and all(part[tau3[v]] == (part[v] + 1) % 3 for v in range(NV)) and all((u in nb[v]) == (tau3[u] in nb[tau3[v]]) for v in range(NV) for u in nb[v]) and sum(len(nb[v]) for v in range(NV)) == sum(1 for v in range(NV) for u in nb[v] if tau3[u] in nb[tau3[v]])
chk('bit', ok_tau, 'polar.F4: a permutation tau of the 135 + 135 + 135 objects with tau(points) = family 1, tau(family 1) = family 2, tau(family 2) = points, keeping inclusion and meeting in a plane (verified on all 405^2 pairs), found by backtracking with forward checking (%d nodes); its order is %s: a triality of the quadric of Cl(8,0)' % (NODES[0], o3))
chk('bit', ok_t3, 'polar.F4: %s has order 3, maps points -> family 1 -> family 2 -> points and keeps all incidences; with a transvection t_w (points to points, family 1 <-> family 2, polar.F2) it generates S3 on the three sets of 135: the triality of O+(8,2) over F2' % ('tau^4' if tau3 is not tau else 'tau'))
# ---- D4 weights (exact)
VW = [tuple(Fr(s) if i == j else Fr(0) for j in range(4)) for i in range(4) for s in (1, -1)]
SP_ = [tuple(Fr(s, 2) for s in sg) for sg in itertools.product((1, -1), repeat=4) if sg.count(-1) % 2 == 0]
SM_ = [tuple(Fr(s, 2) for s in sg) for sg in itertools.product((1, -1), repeat=4) if sg.count(-1) % 2 == 1]
def apply4(R, v): return tuple(sum(R[i][j] * v[j] for j in range(4)) for i in range(4))
def mm4(R, S): return [[sum(R[i][k] * S[k][j] for k in range(4)) for j in range(4)] for i in range(4)]
dot4 = lambda a, b: sum(x * y for x, y in zip(a, b))
Rfound = None
for cols in itertools.permutations(SP_, 4):
    if any(dot4(cols[a], cols[b]) != 0 for a in range(4) for b in range(a)): continue
    R = [[cols[j][i] for j in range(4)] for i in range(4)]
    if set(apply4(R, v) for v in SP_) == set(SM_) and set(apply4(R, v) for v in SM_) == set(VW):
        R3 = mm4(R, mm4(R, R))
        if R3 == [[Fr(int(i == j)) for j in range(4)] for i in range(4)]: Rfound = R; break
cells = all(len(S) == 8 and all(dot4(v, v) == 1 for v in S) and all(tuple(-x for x in v) in S for v in S) and sum(1 for v in S for w in S if dot4(v, w) == 0) == 8 * 6 for S in (VW, SP_, SM_))
chk('std', Rfound is not None and cells, 'polar.F5: the 24 weights of D4 (vector +-e_i, half-spin (+-1/2)^4 with an even and an odd number of minus signs) are three 16-cells (8 unit vectors, +- 4 orthonormal ones) and the orthogonal matrix with columns %s (exact) maps vector -> even half-spin -> odd half-spin -> vector, R^3 = 1' % ([tuple(str(Rfound[i][j]) for i in range(4)) for j in range(4)] if Rfound else None))
# ---- pure spinors over R: Cl(4,4) on Lambda(R^4)
def cre(i, k=4):
    Mt = np.zeros((2 ** k, 2 ** k))
    for S in range(2 ** k):
        if not (S >> i) & 1: Mt[S | (1 << i), S] = (-1) ** pc(S & ((1 << i) - 1))
    return Mt
Cr = [cre(i) for i in range(4)]; An = [c.T for c in Cr]; GG = [c + a for c, a in zip(Cr, An)] + [c - a for c, a in zip(Cr, An)]
PAR = np.diag([(-1) ** pc(S) for S in range(16)])
def vec(x): return sum(x[a] * GG[a] for a in range(8))
def coords8(Mt):
    V = np.array([g.ravel() for g in GG]).T; c, res, rk, sv = np.linalg.lstsq(V, Mt.ravel(), rcond=None)
    return c, np.linalg.norm(V @ c - Mt.ravel())
def joint_kernel(W): Mt = np.vstack([vec(w) for w in W]); U, s, Vt = np.linalg.svd(Mt); return Vt[int((s > 1e-9).sum()):]
def chir(phi): return int(round(phi @ PAR @ phi / (phi @ phi)))
WS = []
for S in range(16):
    W = []
    for i in range(4):
        x = np.zeros(8)
        if (S >> i) & 1: x[i] = 0.5; x[4 + i] = 0.5
        else: x[i] = 0.5; x[4 + i] = -0.5
        W.append(x)
    WS.append(np.array(W))
rngs = np.random.default_rng(64); samples = []; ok_pure = True
for S in range(16):
    K_ = joint_kernel(WS[S]); ok_pure &= len(K_) == 1 and abs(abs(K_[0][S]) - 1) < 1e-9
    samples.append((WS[S], chir(K_[0]) if len(K_) == 1 else 0, (-1) ** pc(S)))
ok_rot = ok_refl = True
for trial in range(12):
    Bv = sum(rngs.normal() * 0.2 * GG[a] @ GG[b] for a in range(8) for b in range(a + 1, 8)); g = expm(Bv); gi = np.linalg.inv(g)
    S = int(rngs.integers(16)); Wn = []
    for x in WS[S]:
        c, res = coords8(g @ vec(x) @ gi); ok_rot &= res < 1e-8 * max(1, np.linalg.norm(c)); Wn.append(c / np.linalg.norm(c))
    Wn = np.array(Wn); K_ = joint_kernel(Wn); ok_rot &= len(K_) == 1 and chir(K_[0]) == (-1) ** pc(S)
    samples.append((Wn, chir(K_[0]) if len(K_) == 1 else 0, (-1) ** pc(S)))
    u = rngs.normal(size=8); uq = sum(u[:4] ** 2) - sum(u[4:] ** 2); uu = vec(u); ui = uu / uq
    Wr = []
    for x in Wn:
        c, res = coords8(uu @ vec(x) @ ui); ok_refl &= res < 1e-8 * max(1, np.linalg.norm(c)); Wr.append(c / np.linalg.norm(c))
    Wr = np.array(Wr); K_ = joint_kernel(Wr); ok_refl &= len(K_) == 1 and chir(K_[0]) == -(-1) ** pc(S)
    samples.append((Wr, chir(K_[0]) if len(K_) == 1 else 0, -(-1) ** pc(S)))
etaV = np.diag([1, 1, 1, 1, -1, -1, -1, -1.])
ok_iso_W = all(np.allclose(W @ etaV @ W.T, 0) and np.linalg.matrix_rank(W) == 4 for W, c, e in samples)
ok_par = all(((4 + 4 - np.linalg.matrix_rank(np.vstack([W1, W2]), tol=1e-8)) % 2 == 0) == (c1 == c2) for (W1, c1, e1) in samples for (W2, c2, e2) in samples)
chk('std', ok_pure and ok_rot and ok_refl and ok_iso_W and all(c == e for W, c, e in samples), 'polar.F6: Cl(4,4) on Lambda(R^4) (numpy Jordan-Wigner, scipy expm): the 16 coordinate maximal isotropic subspaces and 12 Spin-rotated ones each annihilate exactly one line of spinors, of the chirality of the start; a reflection by a non-null vector moves it to the other chirality')
chk('std', ok_par, 'polar.F6: for all %d^2 pairs of these %d maximal isotropic subspaces dim(W ∩ W\') is even iff their pure spinors have the same chirality: the two families are the two half-spin spaces' % (len(samples), len(samples)))
best = None
for epsC in (1, -1):
    rows = []
    for g in GG:
        rows.append(np.kron(np.eye(16), g.T) - epsC * np.kron(g.T, np.eye(16)))
    Kc = np.vstack(rows); U, s, Vt = np.linalg.svd(Kc); nul = Vt[int((s > 1e-9).sum()):]
    for v in nul:
        Cm = v.reshape(16, 16); ev_ix = [S for S in range(16) if pc(S) % 2 == 0]; Cp = Cm[np.ix_(ev_ix, ev_ix)]
        if np.allclose(Cp, Cp.T) and np.linalg.matrix_rank(Cp) == 8: best = (epsC, Cm, Cp, ev_ix)
ok_form = best is not None
if ok_form:
    epsC, Cm, Cp, ev_ix = best; evs = np.linalg.eigvalsh(Cp); sigC = (int((evs > 1e-9).sum()), int((evs < -1e-9).sum()))
    inv_ok = all(np.allclose((expm(0.3 * GG[a] @ GG[b]).T @ Cm @ expm(0.3 * GG[a] @ GG[b])), Cm) for a in range(8) for b in range(a + 1, 8))
    coord_null = all(abs(Cp[i, i]) < 1e-9 for i in range(8))
    def annih(phi16): Mt = np.array([(g @ phi16) for g in GG]).T; return 8 - np.linalg.matrix_rank(Mt, tol=1e-8)
    ok_null = ok_non = True
    for trial in range(20):
        while True:
            a1, a2 = rngs.normal(size=8), rngs.normal(size=8); q1, q2, q12 = a1 @ Cp @ a1, a2 @ Cp @ a2, a1 @ Cp @ a2
            if q1 * q2 < 0: break
        tt = (-q12 + np.sqrt(q12 ** 2 - q1 * q2)) / q2; phi = a1 + tt * a2
        full = np.zeros(16); full[ev_ix] = phi; ok_null &= abs(phi @ Cp @ phi) < 1e-9 * (phi @ phi) and annih(full) == 4
        full2 = np.zeros(16); full2[ev_ix] = a1; ok_non &= annih(full2) == 0
    chk('std', sigC == (4, 4) and inv_ok and coord_null and ok_null and ok_non, 'polar.F6: the Spin-invariant form C (C g = %+d g^T C for the 8 generators) restricted to the 8-dimensional even half-spin space is symmetric of signature %s; the coordinate pure spinors are null; 20 sampled null spinors have an annihilator of dimension 4 (pure), 20 non-null ones of dimension 0: the pure spinors are the null quadric of the half-spin form (Cartan, dimension 8, recalled for the general statement)' % (epsC, sigC))
else:
    chk('std', False, 'polar.F6: no symmetric non-degenerate Spin-invariant form found on the even half-spin space')

finish('POLAR' + ('-' + FAULT if FAULT else ''))
