#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""weil_theta.py: Weil's n. 16-21 on the labels: the theta transform of a subgroup, the true representation of B0(G, Gamma), the stabilizer
of the state 1_Gamma (Theorem 4), and Theorem 5, which on the labels says that a self-dual code of labels all of square +1 exists only when
p = q mod 8; the codes found up to n = 10 give the converse there (round 17, proofs pass 13e; docs/round17/PROOFS_ROUND13E.md).      python3 weil_theta.py [--fault NOPHASE|NOFCOND|WEIGHT|NOTDUAL]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig). Source (docs/round17/PROOFS_ROUND13E.md, section 3): A. Weil, Sur certains groupes d'operateurs unitaires, Acta
Math. 111 (1964) 143-211, read in full (pass 13b). Used here: n. 16 (a closed subgroup Gamma of G, its annihilator Gamma_* in G*, measures dxi on
Gamma and dxdot on G/Gamma with dx = dxi dxdot, the function Theta(x, x*) = integral over Gamma of Phi(x + xi) <xi, x*> dxi, formula (20)); n. 17-18
(the dual measures on G*/Gamma_* and Gamma_*; Theta(z + zeta) = Theta(z) F(zeta, z)^-1 for zeta in Gamma x Gamma_*, formula (22); the Hilbert space
H(G, Gamma) with the norm over Q = (G/Gamma) x (G*/Gamma_*); the isometry Z: Phi -> Theta and its inverse, formula (23)); n. 19 (U(w) Theta(z) = Theta(z + w) F(z, w), formula (24); the group B0(G, Gamma) of the
s = (sigma, f) with f = 1 on Gamma x Gamma_* and sigma keeping Gamma x Gamma_*; r_Gamma(s) Theta(z) = Theta(z sigma) f(z), formula (25), a
representation lying over B0(G, Gamma); Theorem 4: the integral of Phi over Gamma equals that of r_Gamma(s) Phi, formula (26)); n. 20 (on
Omega0(G, Gamma), the s of B0(G, Gamma) whose gamma(s) is an isomorphism of G* onto G carrying Gamma_* onto Gamma, a part of Omega0(G),
r_Gamma = r0; Theorem 4 with s = d'0(gamma), gamma carrying Gamma_* onto Gamma, is the Poisson formula; Theorem 5: if a character of the second
degree f of G is 1 on Gamma and its morphism rho is an isomorphism of (G, Gamma) onto (G*, Gamma_*), then gamma(f) = 1; the remark that Theorem 3
gives it too); n. 21 (the characteristic function of Gamma is invariant under B0(G, Gamma)). Recalled, not read: the self-dual and doubly-even
binary codes, the extended Hamming code, the number of self-dual codes of length n; stabilizer states.
G = (Z/2)^m, G* = G by <x, x*> = (-1)^(x.x*), w = (x, z) as a 2m-bit integer (x the low m bits), F(w1, w2) = (-1)^(x1.z2), B the commutation form;
counting measures on G and Gamma, so on G/Gamma, and their duals: 2^-m on G*, 1/|Gamma| on G*/Gamma_*. B0 as pairs (sigma, f = i^q), composed
"s then s'" as in weil_cocycle.py. Operators are matrices of Python complex numbers whose entries are dyadic Gaussian rationals; every entry is
checked to be one (2^16 times it a Gaussian integer of fewer than 40 bits), so that equality is exact.
wt.ZAK   [std] for m = 1, 2, 3 and every subgroup Gamma of G (2, 5 and 16 of them): Theta = Z Phi satisfies (22), Z is an isometry of L2(G) onto
         H(G, Gamma) with Weil's measures, (23) inverts it, and Z U(w) = U(w) Z with U(w) on H(G, Gamma) by (24) (on the basis of L2(G), all w).
wt.THM4  [std] B0(G, Gamma) enumerated for m = 1, 2 (sigma keeping the Lagrangian L = Gamma x Gamma_*, f = 1 on L); r_Gamma(s) by (25) keeps
         H(G, Gamma), is unitary, lies over s (relation (15)) and is a representation: r_Gamma(s) r_Gamma(s') = r_Gamma(s s') on all pairs (m = 1, 2)
         and on sampled pairs of sampled elements (m = 3, sigma found among products of random transvections): on B0(G, Gamma) the projective
         representation of Theorem 1 has no factor system. B0(G, Gamma) is the stabilizer of the line of 1_Gamma, the characteristic function of
         Gamma (m = 1, 2: among all of B0(G), lifted as r0(a) r0(b) with a, b in Omega0(G), exactly its elements fix that line); the stabilizer of
         the Lagrangian alone is larger (it holds the Paulis). On Omega0(G, Gamma) (m = 2) r_Gamma = r0 of formula (16), and Theorem 3 gives
         gamma(f0) = 1 on its pairs; on the other elements of B0(G, Gamma) in Omega0(G) the two differ by fourth roots of unity for m = 2 and by
         eighth roots for m = 1, where r0 carries 2^(-1/2) (m = 3 not compared). Theorem 4: the sum
         over Gamma is invariant, and 1_Gamma, a stabilizer state, is fixed by every r_Gamma(s) (n. 21); the finite Poisson summation formula, an
         identity checked for every subgroup (m <= 4), is Weil's case s = d'0(gamma) of Theorem 4 when |Gamma| = 2^(m/2).
wt.THM5  [bit] on the labels (LAB-028's dictionary: the labels of a cell are G, their form f = i^w with rho the identity of the dot product): for
         every cell (p, q) with n <= 10 the self-dual codes of labels (Gamma = Gamma^perp, so rho(Gamma) = Gamma_*) on which f = 1, that is all of
         whose labels have square +1, are counted: there are some exactly when p = q mod 8, Prod_(i=0..n/2-2) (2^i + 1) of them in each
         length; for q = 0 they are the doubly-even self-dual codes; read from the kernel's signs, their labels commute two by two (that each
         holds the top label and has labels of square +1 comes with the enumeration).
         [bit==std] the codes are self-dual (Gamma^perp = Gamma, a check of the enumeration), so Weil's hypotheses hold, and gamma(f) =
         (1 + i)^p (1 - i)^q / 2^(n/2) = 1, the clock at 0; the Fourier transform of i^w is (1 + i)^p (1 - i)^q i^-w on every cell with n <= 6, and
         with it the finite Poisson formula on the labels, 2^n sum over Gamma of i^w = |Gamma| (1 + i)^p (1 - i)^q sum over Gamma^perp of i^-w, for
         every subgroup of the labels of those cells, which for a self-dual Gamma with f = 1 on it is Theorem 5.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   NOPHASE the theta transform without <xi, x*>; NOFCOND B0(G, Gamma) without the condition f = 1 on Gamma x Gamma_*; WEIGHT the weights
   |a| = 0 mod 4 in place of the squares e_a^2 = +1; NOTDUAL the trivial code {0}, self-orthogonal and not self-dual, added to the self-dual ones.
Not computed here (stated, not checked): Weil's theorems for general G (read); B0(G, Gamma) for m = 3 beyond a sample; codes beyond n = 10, and
the converse of Theorem 5 there (argued: pairs of generators of opposite squares, and blocks of eight generators of one square carrying the
extended Hamming code); that every stabilizer state is some 1_Gamma moved by an element of B0(G) (argued by conjugacy); the quadratic reciprocity law that
Theorem 5 gives over the adeles (read).
Command: python3 -I -B selfcheck/proofs/weil_theta.py from checks/ (or from this folder); standard library only."""
import os, sys, itertools, random

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish():
    print('\n  tags: %s' % ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)))
    print('weil_theta: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOPHASE', 'NOFCOND', 'WEIGHT', 'NOTDUAL')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
if FAULT: print('FAULT %s: the main lines below use the wrong version and must fail' % FAULT)

def pc(a): return bin(a).count('1')
def dot(a, b): return pc(a & b) & 1
def sig(p, q): return list(_core_sig(p, q, 0))
IPOW = (1, 1j, -1, -1j)
SCALE = 1 << 16
def exact(z):
    a, b = z.real * SCALE, z.imag * SCALE
    return a == int(a) and b == int(b) and abs(a) < 2 ** 40 and abs(b) < 2 ** 40
def all_exact(A): return all(exact(e) for row in A for e in row)
def sq(z): z = complex(z); return z.real * z.real + z.imag * z.imag            # |z|^2 without a square root, exact on dyadic values
def mmul(A, Bm):
    n = len(A); cols = [[Bm[k][y] for k in range(n)] for y in range(n)]
    return [[sum(a * b for a, b in zip(row, col)) for col in cols] for row in A]
def star(A): n = len(A); return [[A[y][x].conjugate() for y in range(n)] for x in range(n)]
def ident(n): return [[1 if x == y else 0 for y in range(n)] for x in range(n)]
def same(A, Bm): return all(a == b for ra, rb in zip(A, Bm) for a, b in zip(ra, rb))

# ------------------------------------------------------------------------------------------------ G, G*, B0 (as in weil_cocycle.py)
class Frame:
    def __init__(self, m):
        self.m = m; self.n2 = 2 * m; self.N = 1 << (2 * m); self.M = 1 << m
    def xz(self, w): return w & (self.M - 1), w >> self.m
    def Fexp(self, w1, w2): return 2 * dot(self.xz(w1)[0], self.xz(w2)[1])          # F as an exponent of i
    def B(self, w1, w2):
        x1, z1 = self.xz(w1); x2, z2 = self.xz(w2); return (dot(x1, z2) + dot(x2, z1)) & 1
    def app(self, S, w):
        r = 0
        for i in range(self.n2):
            if (w >> i) & 1: r ^= S[i]
        return r
    def symplectic(self, S): return all(self.B(S[i], S[j]) == self.B(1 << i, 1 << j) for i in range(self.n2) for j in range(i + 1, self.n2))
    def transvection(self, v): return tuple((1 << i) ^ (v if self.B(1 << i, v) else 0) for i in range(self.n2))
    def solve6(self, S, every):
        N = self.N; img = [self.app(S, w) for w in range(N)]
        D = lambda a, b: (self.Fexp(img[a], img[b]) - self.Fexp(a, b)) % 4
        out = []
        for ch in (range(1 << self.n2) if every else [0]):
            base = [(D(1 << i, 1 << i) // 2) % 2 + 2 * ((ch >> i) & 1) for i in range(self.n2)]
            q = [0] * N
            for w in range(1, N):
                j = w.bit_length() - 1; w0 = w ^ (1 << j); q[w] = (q[w0] + base[j] + D(w0, 1 << j)) % 4
            if all((q[a ^ b] - q[a] - q[b] - D(a, b)) % 4 == 0 for a in [1 << i for i in range(self.n2)] for b in range(N)): out.append(tuple(q))
        return out
    def compose(self, s1, s2):                                              # s1 then s2
        (S1, q1), (S2, q2) = s1, s2
        return (tuple(self.app(S2, S1[i]) for i in range(self.n2)), tuple((q1[w] + q2[self.app(S1, w)]) % 4 for w in range(self.N)))
    def blocks(self, S):
        m = self.m; M = self.M
        return ([S[i] & (M - 1) for i in range(m)], [S[i] >> m for i in range(m)], [S[m + j] & (M - 1) for j in range(m)], [S[m + j] >> m for j in range(m)])
    def lin(self, rows, v):
        r = 0
        for i in range(self.m):
            if (v >> i) & 1: r ^= rows[i]
        return r
    def inverse(self, rows):
        m = self.m; aug = [[rows[i], 1 << i] for i in range(m)]; r = 0
        for c in range(m):
            p = next((i for i in range(r, m) if (aug[i][0] >> c) & 1), None)
            if p is None: return None
            aug[r], aug[p] = aug[p], aug[r]
            for i in range(m):
                if i != r and (aug[i][0] >> c) & 1: aug[i][0] ^= aug[r][0]; aug[i][1] ^= aug[r][1]
            r += 1
        inv = [0] * m
        for i in range(m): inv[aug[i][0].bit_length() - 1] = aug[i][1]
        return inv
    def U(self, w):
        """U(w) Phi(x) = Phi(x + u) <x, u*>, w = (u, u*), as a matrix [x][y]"""
        u, us = self.xz(w); M = self.M
        return [[((-1) ** dot(x, us) if y == (x ^ u) else 0) for y in range(M)] for x in range(M)]
    def r0(self, s):
        """Weil's lifting of the big cell, formula (16), with the counting measure and its dual: 2^(-m/2) f(x, (y + x alpha) gamma^-1)"""
        S, q = s; al, be, ga, de = self.blocks(S); gi = self.inverse(ga); m = self.m
        return [[IPOW[q[x | (self.lin(gi, y ^ self.lin(al, x)) << m)]] / 2 ** (m / 2) for y in range(self.M)] for x in range(self.M)]

def subgroups(m):
    """every subgroup of (Z/2)^m, as a sorted tuple"""
    seen = {(0,)}; frontier = [(0,)]
    while frontier:
        nxt = []
        for g in frontier:
            for v in range(1 << m):
                if v in g: continue
                h = tuple(sorted(set(g) | {x ^ v for x in g}))
                if h not in seen: seen.add(h); nxt.append(h)
        frontier = nxt
    return sorted(seen, key=lambda g: (len(g), g))
def perp(g, m): return tuple(z for z in range(1 << m) if all(dot(z, x) == 0 for x in g))
def reps(g, m):
    """one representative (the least) of each coset of g in (Z/2)^m"""
    out = []; seen = set()
    for x in range(1 << m):
        if x in seen: continue
        out.append(x); seen |= {x ^ y for y in g}
    return out

# ------------------------------------------------------------------------------------------------ Weil's theta transform (n. 16-19)
class Theta:
    def __init__(self, fr, g):
        self.fr = fr; self.g = g; self.gs = perp(g, fr.m); m = fr.m
        self.L = {x | (z << m) for x in g for z in self.gs}
        self.rG = reps(g, m); self.rGs = reps(self.gs, m)
    def Z(self, Phi):
        """formula (20): Theta(x, x*) = sum over xi in Gamma of Phi(x + xi) <xi, x*>"""
        fr = self.fr; m = fr.m
        return [sum(Phi[(w & (fr.M - 1)) ^ xi] * (1 if FAULT == 'NOPHASE' else (-1) ** dot(xi, w >> m)) for xi in self.g) for w in range(fr.N)]
    def quasi(self, Th):
        """formula (22): Theta(z + zeta) = Theta(z) F(zeta, z)^-1 on Gamma x Gamma_*"""
        fr = self.fr
        return all(Th[z ^ zeta] == Th[z] * IPOW[(-fr.Fexp(zeta, z)) % 4] for zeta in self.L for z in range(fr.N))
    def norm2(self, Th):
        """the norm of H(G, Gamma): over Q = (G/Gamma) x (G*/Gamma_*), counting on G/Gamma, 1/|Gamma| on G*/Gamma_*"""
        m = self.fr.m
        return sum(sq(Th[x | (z << m)]) for x in self.rG for z in self.rGs) / len(self.g)
    def Zinv(self, Th):
        """formula (23): Phi(x) = integral over G*/Gamma_* of Theta(x, x*)"""
        m = self.fr.m
        return [sum(Th[x | (z << m)] for z in self.rGs) / len(self.g) for x in range(self.fr.M)]
    def UH(self, w, Th):
        """formula (24): U(w) Theta(z) = Theta(z + w) F(z, w)"""
        fr = self.fr
        return [Th[z ^ w] * IPOW[fr.Fexp(z, w)] for z in range(fr.N)]
    def R(self, s, Th):
        """formula (25): r_Gamma(s) Theta(z) = Theta(z sigma) f(z)"""
        S, q = s; fr = self.fr
        return [Th[fr.app(S, z)] * IPOW[q[z]] for z in range(fr.N)]
    def r(self, s):
        """r_Gamma(s) on L2(G), Z^-1 R(s) Z, as a matrix, with whether R(s) kept H(G, Gamma) on the basis"""
        M = self.fr.M; cols = []; kept = True
        for y in range(M):
            Th = self.R(s, self.Z([1 if x == y else 0 for x in range(M)]))
            kept = kept and self.quasi(Th)
            cols.append(self.Zinv(Th))
        return [[cols[y][x] for y in range(M)] for x in range(M)], kept
    def in_B0G(self, s):
        S, q = s; fr = self.fr
        keeps = all(fr.app(S, w) in self.L for w in self.L)
        return keeps and (FAULT == 'NOFCOND' or all(q[w] % 4 == 0 for w in self.L))

FR = {m: Frame(m) for m in (1, 2, 3)}
SUB = {m: subgroups(m) for m in (1, 2, 3, 4)}

# ================================================================================================ wt.ZAK
head('wt.ZAK: the theta transform of a subgroup (n. 16-19)')
okz = True; npairs = 0; nmax = 0
for m in (1, 2, 3):
    fr = FR[m]
    for g in SUB[m]:
        T = Theta(fr, g); npairs += 1
        basis = [[1 if x == y else 0 for x in range(fr.M)] for y in range(fr.M)]
        rng0 = random.Random(16 + m)
        tests = basis + [[complex(rng0.randrange(-3, 4), rng0.randrange(-3, 4)) for _ in range(fr.M)] for _ in range(2)]
        for Phi in tests:
            Th = T.Z(Phi)
            if not (T.quasi(Th) and T.norm2(Th) == sum(sq(v) for v in Phi) and T.Zinv(Th) == list(Phi)): okz = False
        for w in range(fr.N):
            Uw = fr.U(w)
            for Phi in basis:
                lhs = T.Z([sum(Uw[x][y] * Phi[y] for y in range(fr.M)) for x in range(fr.M)])
                if lhs != T.UH(w, T.Z(Phi)): okz = False
chk('std', okz, 'wt.ZAK: for m = 1, 2, 3 and each of the %d subgroups Gamma of G = (Z/2)^m (2, 5 and 16 of them), Weil\'s theta transform Theta(x, x*) = sum over xi in Gamma of Phi(x + xi) <xi, x*> (formula (20)) satisfies Theta(z + zeta) = Theta(z) F(zeta, z)^-1 for every zeta in Gamma x Gamma_* (formula (22)), keeps the norm (sum of |Phi|^2 equals the norm over (G/Gamma) x (G*/Gamma_*) with the counting measure on G/Gamma and the dual 1/|Gamma| on G*/Gamma_*), is inverted by formula (23), and carries U(w) to Theta(z) -> Theta(z + w) F(z, w) (formula (24)), for every w, on the basis of L2(G) and two random vectors' % npairs)

# ================================================================================================ wt.THM4
head('wt.THM4: the true representation of B0(G, Gamma), Theorem 4, the stabilizer state of Gamma (n. 19-21)')
B0 = {}
for m in (1, 2):
    fr = FR[m]
    sp = [S for S in itertools.product(range(1, fr.N), repeat=fr.n2) if fr.symplectic(S) and len({fr.app(S, w) for w in range(fr.N)}) == fr.N]
    B0[m] = [(S, q) for S in sp for q in fr.solve6(S, True)]
rng = random.Random(13)
def sample_B0G(fr, T, k):
    """k elements of B0(G, Gamma) for m = 3: sigma among products of 20 random transvections keeping L, f the solution of (6) made 1 on L"""
    tv = [fr.transvection(v) for v in range(1, fr.N)]; out = []; tries = 0
    while len(out) < k and tries < 200000:
        tries += 1; S = tuple(1 << i for i in range(fr.n2))
        for _ in range(20):
            Tv = rng.choice(tv); S = tuple(fr.app(Tv, S[i]) for i in range(fr.n2))
        if not all(fr.app(S, w) in T.L for w in T.L): continue
        q = list(fr.solve6(S, False)[0])
        v = next(v for v in range(fr.N) if all((q[w] + 2 * fr.B(w, v)) % 4 == 0 for w in T.L))
        out.append((S, tuple((q[w] + 2 * fr.B(w, v)) % 4 for w in range(fr.N))))
    return out
sizes = {}; rep_ok = True; over_ok = True; kept_ok = True; thm4_ok = True; fix_ok = True; exact_ok = True; npair_tot = 0; nel = 0
omega_eq = True; n_omega = 0; thm3_one = True; n_thm3 = 0; off_ok = True; OFF = {1: [0] * 8, 2: [0] * 8}; off_sub = {1: set(), 2: set()}
def zeta_r0(fr, s, k):
    """zeta^k r0(s) exactly, when zeta^k 2^(-m/2) is a dyadic Gaussian number (k = m mod 2); else None"""
    m = fr.m
    if (k - m) % 2: return None
    c = IPOW[(k // 2) % 4] / 2 ** (m // 2) if m % 2 == 0 else IPOW[((k - 1) // 2) % 4] * (1 + 1j) / 2 / 2 ** ((m - 1) // 2)
    S, q = s; al, be, ga, de = fr.blocks(S); gi = fr.inverse(ga)
    return [[c * IPOW[q[x | (fr.lin(gi, y ^ fr.lin(al, x)) << m)]] for y in range(fr.M)] for x in range(fr.M)]
for m in (1, 2, 3):
    fr = FR[m]
    for g in SUB[m]:
        T = Theta(fr, g)
        els = [s for s in B0[m] if T.in_B0G(s)] if m <= 2 else sample_B0G(fr, T, 12)
        sizes[(m, g)] = len(els)
        mats = {}
        for s in els:
            Rm, kept = T.r(s); mats[s] = Rm; nel += 1
            kept_ok = kept_ok and kept; exact_ok = exact_ok and all_exact(Rm)
            if not same(mmul(Rm, star(Rm)), ident(fr.M)): over_ok = False
            S, q = s
            for i in range(fr.n2):                                          # relation (15): r^-1 U(w) r = f(w) U(w sigma)
                lhs = mmul(mmul(star(Rm), fr.U(1 << i)), Rm)
                rhs = [[e * IPOW[q[1 << i]] for e in row] for row in fr.U(fr.app(S, 1 << i))]
                if not same(lhs, rhs): over_ok = False
            one = [1 if x in g else 0 for x in range(fr.M)]
            if [sum(Rm[x][y] * one[y] for y in range(fr.M)) for x in range(fr.M)] != one: fix_ok = False
            for y in range(fr.M):                                           # Theorem 4 on the basis: sum over Gamma of r(s) delta_y
                if sum(Rm[xi][y] for xi in g) != (1 if y in g else 0): thm4_ok = False
        pairs = [(a, b) for a in els for b in els] if m <= 2 else [(rng.choice(els), rng.choice(els)) for _ in range(30)]
        for a, b in pairs:
            c = fr.compose(a, b)
            Rc = mats.get(c) or T.r(c)[0]
            if not same(mmul(mats[a], mats[b]), Rc): rep_ok = False
            npair_tot += 1
        if m <= 2:                                                          # in Omega0(G) but not in Omega0(G, Gamma): r_Gamma = zeta^k r0
            for s in els:
                ga = fr.blocks(s[0])[2]
                if fr.inverse(ga) is None or {fr.lin(ga, z) for z in T.gs} == set(g): continue
                ks = [k for k in range(8) if zeta_r0(fr, s, k) is not None and same(mats[s], zeta_r0(fr, s, k))]
                if len(ks) == 1: OFF[m][ks[0]] += 1; off_sub[m].add(len(g))
                else: off_ok = False
        if m == 2:                                                          # n. 20: Omega0(G, Gamma), where gamma(s) carries Gamma_* onto Gamma
            gs = T.gs
            om = [s for s in els if fr.inverse(fr.blocks(s[0])[2]) is not None and {fr.lin(fr.blocks(s[0])[2], z) for z in gs} == set(g)]
            for s in om:
                n_omega += 1
                if not same(mats[s], fr.r0(s)): omega_eq = False
            for a in om:
                for b in om:
                    c = fr.compose(a, b)
                    if c in om:                                             # Theorem 3 on Omega0(G, Gamma): gamma(f0) = 1
                        n_thm3 += 1
                        if not same(mmul(mats[a], mats[b]), mats[c]) or not same(mmul(fr.r0(a), fr.r0(b)), fr.r0(c)): thm3_one = False
size_txt = '; '.join('m = %d: %s' % (m, ', '.join('%d' % sizes[(m, g)] for g in SUB[m])) for m in (1, 2))
chk('std', kept_ok and over_ok and rep_ok and exact_ok and nel > 0, 'wt.THM4: B0(G, Gamma), the s = (sigma, f) with sigma keeping L = Gamma x Gamma_* and f = 1 on L, has for the subgroups in order of size %s elements; Weil\'s r_Gamma(s), Theta(z) -> Theta(z sigma) f(z) (formula (25)) carried to L2(G) by Z, keeps H(G, Gamma), is unitary, lies over s (r^-1 U(w) r = f(w) U(w sigma), relation (15)), and is a representation: r_Gamma(s) r_Gamma(s\') = r_Gamma(s s\') exactly on all %d pairs computed (all pairs for m = 1, 2; 30 sampled pairs of 12 sampled elements for each of the 16 subgroups of (Z/2)^3): on B0(G, Gamma) the projective representation of Theorem 1 has no factor system' % (size_txt, npair_tot))
off_txt = lambda m: ', '.join('k = %d for %d' % (k, c) for k, c in enumerate(OFF[m]) if c)
chk('std', omega_eq and thm3_one and n_omega > 0 and n_thm3 > 0 and off_ok and sum(OFF[1]) > 0 and sum(OFF[2]) > 0, 'wt.THM4: on Omega0(G, Gamma), the elements of B0(G, Gamma) whose gamma(s) is an isomorphism of G* onto G carrying Gamma_* onto Gamma (m = 2: %d of them over the three subgroups of order 2; for m = 1 there are none), r_Gamma(s) is Weil\'s r0(s) of formula (16), exactly, with no scalar (n. 20); so on its %d pairs with s s\' in it, Theorem 3\'s factor gamma(f0) is 1 (the remark of n. 20 that Theorem 3 gives Theorem 5); on the other elements of B0(G, Gamma) whose gamma(s) is an isomorphism r0 is defined too, and r_Gamma(s) = zeta^k r0(s), zeta = exp(i pi/4): for m = 2, %d elements (from the subgroups of order %s), %s, fourth roots of unity; for m = 1, %d elements (from the subgroup of order %s), %s, eighth roots, as r0 carries the factor 2^(-1/2) there; m = 3 not compared' % (n_omega, n_thm3, sum(OFF[2]), ', '.join(map(str, sorted(off_sub[2]))), off_txt(2), sum(OFF[1]), ', '.join(map(str, sorted(off_sub[1]))), off_txt(1)))
def r0s(fr, s):
    """2^(m/2) r0(s), formula (16) without its normalisation: entries i^q, Gaussian integers, so that products are exact"""
    S, q = s; al, be, ga, de = fr.blocks(S); gi = fr.inverse(ga); m = fr.m
    return [[IPOW[q[x | (fr.lin(gi, y ^ fr.lin(al, x)) << m)]] for y in range(fr.M)] for x in range(fr.M)]
stab_ok = True; stab_txt = []; nlift = 0; keep_txt = []; npauli = 0
for m in (1, 2):
    fr = FR[m]
    om0 = [s for s in B0[m] if fr.inverse(fr.blocks(s[0])[2]) is not None]
    lift = {s: (r0s(fr, s), 1 << m) for s in om0}                           # (A, c) with A A* = c 1
    for b in om0:
        if len(lift) == len(B0[m]): break
        Ab = r0s(fr, b)
        for a in om0:
            c = fr.compose(a, b)
            if c not in lift: lift[c] = (mmul(lift[a][0], Ab), 1 << (2 * m))
    if len(lift) != len(B0[m]): stab_ok = False
    for s, (A, c) in lift.items():                                          # each lift is unitary up to c and lies over s (relation (15))
        nlift += 1; S, q = s; As = star(A)
        if not same(mmul(A, As), [[c * e for e in row] for row in ident(fr.M)]): stab_ok = False
        for i in range(fr.n2):
            rhs = [[c * e * IPOW[q[1 << i]] for e in row] for row in fr.U(fr.app(S, 1 << i))]
            if not same(mmul(mmul(As, fr.U(1 << i)), A), rhs): stab_ok = False
    for g in SUB[m]:
        T = Theta(fr, g); one = [1 if x in g else 0 for x in range(fr.M)]; nfix = 0; nkeep = 0
        for s, (A, c) in lift.items():
            v = [sum(A[x][y] * one[y] for y in range(fr.M)) for x in range(fr.M)]
            fixes = all((v[x] == 0) == (x not in g) for x in range(fr.M)) and len({v[x] for x in g}) == 1
            nfix += fixes; S = s[0]
            nkeep += all(fr.app(S, w) in T.L for w in T.L)
            if fixes != T.in_B0G(s): stab_ok = False
            if S == tuple(1 << i for i in range(fr.n2)) and any(s[1][w] % 4 for w in T.L):   # a Pauli (sigma = 1) that is not 1 on L
                npauli += 1
                if fixes: stab_ok = False
        if nkeep != (1 << m) * nfix: stab_ok = False                     # the stabilizer of L alone: 2^m times as large
        stab_txt.append(nfix); keep_txt.append(nkeep)
chk('std', stab_ok, 'wt.THM4: B0(G, Gamma) is the stabilizer of the line of 1_Gamma, the characteristic function of Gamma: every element of B0(G) (24 and 11520 for m = 1, 2) lifted as r0(a) r0(b), a and b in Omega0(G) (%d lifts, each unitary and lying over its element by relation (15)), fixes that line exactly when it keeps L = Gamma x Gamma_* and f = 1 on L, for every subgroup Gamma (%s elements, in the order of the line above); the stabilizer of L alone is 2^m times as large (%s elements), and holds Paulis, sigma = 1 and f not 1 on L, that move the line (%d of them over all the subgroups)' % (nlift, ', '.join(map(str, stab_txt)), ', '.join(map(str, keep_txt)), npauli))
pois = True; npois = 0
for m in (1, 2, 3, 4):
    for g in SUB[m]:
        gp = perp(g, m)
        for y in range(1 << m):                                             # Phi = delta_y; Phi^(eta) = (-1)^(y.eta)
            npois += 1
            if (1 if y in g else 0) * (1 << m) != len(g) * sum((-1) ** dot(y, e) for e in gp): pois = False
chk('std', thm4_ok and fix_ok and pois, 'wt.THM4: Theorem 4: for every computed s in B0(G, Gamma) the sum over Gamma of r_Gamma(s) Phi equals the sum of Phi (formula (26), on the basis), and the characteristic function of Gamma, the stabilizer state of the Lagrangian Gamma x Gamma_*, is fixed by every r_Gamma(s), with no phase (n. 21); the finite Poisson summation formula, sum over Gamma of Phi = |Gamma| 2^-m sum over Gamma^perp of the Fourier transform of Phi, an identity checked for every subgroup of (Z/2)^m, m <= 4 (%d cases on the basis); for |Gamma| = 2^(m/2) it is Weil\'s case s = d\'0(gamma) of Theorem 4, gamma carrying Gamma_* onto Gamma (n. 20)' % npois)

# ================================================================================================ wt.THM5
head('wt.THM5: Theorem 5 on the labels: self-dual codes of labels of square +1 (n. 20)')
def wtable(p, q):
    br = BR(sig(p, q)); n = p + q
    return [((pc(a) & 1) + 2 * (1 if br.sq(a) == -1 else 0)) % 4 for a in range(1 << n)]
def gauss(w):
    acc = [0, 0, 0, 0]
    for e in w: acc[e] += 1
    return (acc[0] - acc[2], acc[1] - acc[3])                              # sum of i^w as a Gaussian integer
def cpow(p, q):
    """(1 + i)^p (1 - i)^q as a Gaussian integer (a, b) = a + b i"""
    a, b = 1, 0
    for _ in range(p): a, b = a - b, a + b
    for _ in range(q): a, b = a + b, b - a
    return (a, b)
def itimes(z, k):                                                          # i^k z for a Gaussian integer z
    a, b = z
    for _ in range(k % 4): a, b = -b, a
    return (a, b)
CODES = {}
def selfdual(n):
    """the self-dual binary codes of length n (as frozensets): each holds the all-ones word 1, and is grown from {0, 1} by adding even words
    orthogonal to a basis of the code so far, the codes of each size kept once"""
    if n in CODES: return CODES[n]
    if n % 2: out = []
    elif n == 0: out = [frozenset([0])]
    else:
        one = (1 << n) - 1; ev = [v for v in range(1, 1 << n) if pc(v) % 2 == 0 and v != one]
        level = {frozenset([0, one]): (one,)}
        while len(next(iter(level))) ** 2 < 1 << n:
            nxt = {}
            for c, basis in level.items():
                for v in ev:
                    if v in c or any(dot(v, b) for b in basis): continue
                    d = frozenset(c | {x ^ v for x in c})
                    if d not in nxt: nxt[d] = basis + (v,)
            level = nxt
        out = sorted(level, key=lambda c: sorted(c))
    CODES[n] = out
    return out
table = {}; bridge = True; nfound = 0; ham8 = None; commute = True; ncomm = 0
for n in range(0, 11):
    for p in range(n, -1, -1):
        q = n - p; w = wtable(p, q)
        pool = selfdual(n) + ([frozenset([0])] if FAULT == 'NOTDUAL' and n else [])   # with the fault, {0}: self-orthogonal, not self-dual
        good = [c for c in pool if all((pc(a) % 4 == 0) if FAULT == 'WEIGHT' else (w[a] % 4 == 0) for a in c)]
        table[(p, q)] = len(good)
        br = BR(sig(p, q)) if n else None
        for c in good:
            nfound += 1
            if n:                                                           # the kernel: the labels of the code commute, square +1, hold the top label
                cl = sorted(c)
                if (1 << n) - 1 not in c or br.sq((1 << n) - 1) != 1: commute = False
                for i, a in enumerate(cl):
                    if br.sq(a) != 1: commute = False
                    for b in cl[i + 1:]:
                        ncomm += 1
                        if br.s(a, b) != br.s(b, a): commute = False
            if FAULT != 'NOTDUAL' and set(perp(tuple(c), n)) != set(c): bridge = False   # Weil's rho(Gamma) = Gamma_*: Gamma = Gamma^perp
            if any(w[a] % 4 for a in c): bridge = False                     # f = 1 on Gamma
            if gauss(w) != cpow(p, q) or cpow(p, q) != (1 << (n // 2), 0): bridge = False   # gamma(f) = (1 + i)^p (1 - i)^q / 2^(n/2) = 1
        if (p, q) == (8, 0): ham8 = len(good)
cells = sorted(table)
iff = all((table[c] > 0) == ((c[0] - c[1]) % 8 == 0) for c in cells)
hits = ', '.join('(%d,%d) %d' % (c[0], c[1], table[c]) for c in sorted(cells, key=lambda c: (c[0] + c[1], -c[0])) if table[c])
nsd = {n: len(selfdual(n)) for n in (2, 4, 6, 8, 10)}
def prodcount(n):
    r = 1
    for i in range(n // 2 - 1): r *= 2 ** i + 1
    return r
prodok = all(table[c] == prodcount(c[0] + c[1]) for c in cells if table[c])
chk('bit', iff and ham8 == 30 and commute and prodok, 'wt.THM5: on the labels of the %d cells with n <= 10 (the self-dual codes of labels enumerated: %s for n = 2, 4, 6, 8, 10), those all of whose labels have square +1 (f = i^w = 1 on Gamma) exist exactly in the cells with p = q mod 8: %s, in each length Prod_(i=0..n/2-2) (2^i + 1) of them (1, 2, 6, 30, 270), the cells with p = q mod 8 of one length alike; for q = 0 the condition is |a| = 0 mod 4, the doubly-even self-dual codes, %d of length 8 (the copies of the extended Hamming code) and none of length 2, 4, 6, 10; read from the kernel\'s signs, the labels of each such code commute two by two (%d pairs); by the enumeration each code holds the top label, the all-ones word that every self-dual code holds, and all its labels have square +1: 2^(n/2) commuting labels of square +1, the volume element one of them' % (len(cells), ', '.join(str(nsd[n]) for n in (2, 4, 6, 8, 10)), hits, ham8 or 0, ncomm))
poiss = True; nsub = 0; nft = 0
for n in range(0, 7):
    subs = SUB.get(n) or subgroups(n)
    for p in range(n, -1, -1):
        q = n - p; w = wtable(p, q); C = cpow(p, q)
        for xi in range(1 << n):                                            # the Fourier transform of i^w: sum_a i^w(a) (-1)^(a.xi) = C i^-w(xi)
            nft += 1
            if gauss([(w[a] + 2 * dot(a, xi)) % 4 for a in range(1 << n)]) != itimes(C, -w[xi]): poiss = False
        for g in subs:
            nsub += 1; gp = perp(g, n)
            lhs = gauss([w[a] for a in g]); rhs = gauss([(-w[b]) % 4 for b in gp])
            prod = (C[0] * rhs[0] - C[1] * rhs[1], C[0] * rhs[1] + C[1] * rhs[0])
            if (lhs[0] << n, lhs[1] << n) != (len(g) * prod[0], len(g) * prod[1]): poiss = False
chk('bit==std', bridge and poiss and nfound > 0, 'wt.THM5: each of the %d codes found is self-dual, Gamma^perp = Gamma (a check of the enumeration), so Weil\'s hypotheses hold (f = 1 on Gamma, and rho, the identity of the dot product, carries Gamma onto Gamma_* = Gamma^perp), and gamma(f) = (1 + i)^p (1 - i)^q / 2^(n/2) = 1, the clock at 0 (LAB-028); the Fourier transform of i^w is (1 + i)^p (1 - i)^q i^-w (ATY-033) on every cell with n <= 6 (%d labels xi), and with it the finite Poisson formula on the labels, 2^n sum over Gamma of i^w = |Gamma| (1 + i)^p (1 - i)^q sum over Gamma^perp of i^-w, holds for every subgroup Gamma of the labels of those cells (%d cases): for a self-dual Gamma with f = 1 on it, it reads 2^(n/2) = gamma(f) 2^(n/2), Theorem 5' % (nfound, nft, nsub))

# ================================================================================================ controls, computed in place
head('controls: the phase of the theta transform, the condition f = 1 on L, the weights, the self-dual codes')
fr = FR[2]; bad_q = 0; bad_u = 0
for g in SUB[2]:
    T = Theta(fr, g); m = 2
    for y in range(fr.M):
        Phi = [1 if x == y else 0 for x in range(fr.M)]
        Th = [sum(Phi[(w & 3) ^ xi] for xi in g) for w in range(fr.N)]     # without <xi, x*>
        if not all(Th[z ^ zeta] == Th[z] * IPOW[(-fr.Fexp(zeta, z)) % 4] for zeta in T.L for z in range(fr.N)): bad_q += 1
nocond = 0; nocond_kept = 0
for g in SUB[2]:
    T = Theta(fr, g)
    for s in B0[2]:
        S, q = s
        if all(fr.app(S, w) in T.L for w in T.L) and not all(q[w] % 4 == 0 for w in T.L):
            nocond += 1
            Th = T.R(s, T.Z([1 if x in g else 0 for x in range(fr.M)]))
            if T.quasi(Th): nocond_kept += 1
chk('ctl', bad_q > 0 and nocond > 0 and nocond_kept == 0, 'wt.ZAK, wt.THM4: without the phase <xi, x*> the theta transform of a basis vector breaks formula (22) in %d of the 20 cases (m = 2, the five subgroups) (NOPHASE); the %d elements of B0((Z/2)^2) that keep L = Gamma x Gamma_* but are not 1 on it carry the theta transform of the characteristic function of Gamma out of H(G, Gamma), every one of them (NOFCOND)' % (bad_q, nocond))
wgt = {}; table0 = {}; triv = True                                         # computed here without the fault
for n in range(0, 11):
    for p in range(n, -1, -1):
        w = wtable(p, n - p)
        wgt[(p, n - p)] = sum(1 for c in selfdual(n) if all(pc(a) % 4 == 0 for a in c))
        table0[(p, n - p)] = sum(1 for c in selfdual(n) if all(w[a] % 4 == 0 for a in c))
        if w[0] % 4 or len(perp((0,), n)) != 1 << n: triv = False         # f = 1 on {0}; its annihilator is all of G
wrong_w = sorted(c for c in wgt if wgt[c] and (c[0] - c[1]) % 8)
wrong_s = sorted(c for c in table0 if cpow(*c) != (1 << ((c[0] + c[1]) // 2), 0) or (c[0] + c[1]) % 2)
chk('ctl', wrong_w and all(table0[c] == 0 for c in wrong_w) and triv and wrong_s == sorted(c for c in table0 if table0[c] == 0), 'wt.THM5: the weight alone does not do it: doubly-even self-dual codes of length 8 exist in all nine cells with n = 8, %d of them with p != q mod 8, such as (7,1), and in those each of them has labels of square -1 (WEIGHT); nor does a smaller code: the trivial code {0} has f = 1 on it in every cell, but its annihilator is all of G (2^n labels), not rho({0}) = {0} once n >= 1, and gamma(f) != 1 in the %d cells with p != q mod 8 or n odd, exactly the cells without a code (NOTDUAL)' % (len(wrong_w), len(wrong_s)))
finish()
