#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_gravity.py -- the shifted Dirac theory of Atiyah and Moore ("A shifted view of fundamental physics", section 2, read) in a general weak
gravitational field: the source of h_mu.nu, from the action on the perturbed frame, against the symmetric (Belinfante) tensor T_B of ATY-044.

Read and built on.  ATY-037 puts the shift on a frame: S = int e psi-bar (i D - m + i kappa exp(-tau D)) psi with D = gamma^a e_a^mu nabla_mu, the
Dirac operator of the frame with its spin connection, so that the shift follows proper time.  ATY-039 coupled a uniform potential only
(bD -> (1 + Phi) bD): the coupling is the Noether energy.  ATY-042 built the canonical tensor with its bilocal term, ATY-044 the Belinfante tensor
T_B with the bilocal spin current, and left the coupling of T_B to a field not computed.  This file computes that coupling for all ten h_mu.nu.
Conventions (the std route of shifted_tensor.py): Dirac representation, gamma_a = GM[a] (gamma_0^2 = 1), gamma^mu = (gamma_0, -gamma_1, -gamma_2,
-gamma_3), signature (+,-,-,-); a wave c e^{i b.x} with b.x = b_mu x^mu (b covariant), D -> i bslash, bslash = b_mu gamma^mu; psi-bar = psi^dagger gamma_0
(the Dirac conjugate: the Q of the labels, which solves the adjoint on the modes); hbar = c = 1, mu = kappa tau.  On a quantized shell
E tau = (n + 1/2) pi, E = m + (-1)^n kappa, every wave is an ordinary solution of mass E (bslash c = -E c, both signs of the frequency).
The perturbation, to first order.  e_a^mu = delta_a^mu - (1/2) h_a^mu(x), h = s + w (s symmetric: the metric g = eta + s; w antisymmetric: a local
Lorentz rotation of the frame), volume e = 1 + (1/2) h^mu_mu, and with omega_mu^a_b = e^a_nu (d_mu e_b^nu + Gamma^nu_mu.lam e_b^lam),
Gamma_mu = (1/4) omega_mu.ab gamma^a gamma^b:
    delta D = -(1/2) h_a^mu gamma^a d_mu + (1/4)(d_b s - d^a s_ab) gamma^b + (1/8) gamma^mu gamma^a gamma^b d_mu w_ab,
    delta exp(-tau D) = -int_0^tau ds exp(-(tau - s) D) delta D exp(-s D)            (Duhamel; on a solution the volume term multiplies O psi = 0),
    delta S = int psi-bar (i delta D + i kappa delta exp(-tau D)) psi = -(1/2) int h_mu.nu T_H^{mu nu}.
The sign: -(1/2) in this signature is the +(1/2) int h T of the mostly-plus convention; it is the one fixed by the two known results below
(gr.ORD and gr.039); with +(1/2) every T_H would be -T_B and the energy negative.  For h = eps e^{i q.x} on a field of plane waves the x-integral
picks the pair (row j, column l) with q = b_j - b_l, i.e. the Fourier component of T at K = b_l - b_j = -q.

Statements (each line of the run is one check).
(0) [gr.VB] The first-order delta D above (frame term and spin connection, eps random and not symmetric) is the g-derivative of the vierbein
    formula for e_a^mu = delta - (g/2) eps_a^mu cos(q.x).  [gr.037] For a static h_00 = -2 Phi(x) it is the first-order term of ATY-037's
    N^{-1/2} D' N^{1/2}, N = sqrt(1 - 2 Phi).  [gr.SOL] Every wave used solves the shifted equation, and its Dirac conjugate the adjoint.
    [gr.ORD] kappa = 0: T_H = T_B = the textbook (i/4) psi-bar (gamma^mu <->d^nu + gamma^nu <->d^mu) psi on shell, at every cross frequency; not the
    canonical T; with the opposite sign of the spin connection T_H != T_B.  [gr.039] A uniform h_00 = -2 Phi: dS/dPhi is the Noether energy
    T^0_0 = rho E (1 - (-1)^n mu i), rho = psi-bar psi, on rest modes of both sectors (ATY-039).
(1) [gr.CONST] Constant h_mu.nu, all ten components, on quantized rest and moving waves (and the constant part of two-wave fields):
    delta S = -(1/2) h_mu.nu T^{mu nu}_const, T the canonical tensor of ATY-042 with its bilocal term (= T_B there, ATY-044), and component by
    component T_H^{mu nu} = (1 - (-1)^n mu i) T_Dirac,E^{mu nu}: the factor of ATY-039 on every component, i playing the part of the labels' J.
(2) [gr.GRAD] h = eps e^{i q.x}, q the difference of the two wave vectors of a two-wave field (the spin connection and the Duhamel term both
    enter): on one shell (four settings, both cross frequencies) delta S = -(1/2) eps_mu.nu T_B^{mu nu}(-q) for the ten symmetric eps.  [gr.SYM]
    T_H is symmetric (the six antisymmetric eps, a local Lorentz rotation, give zero, the Duhamel term included) and conserved, K_mu T_H^{mu nu} = 0.
    [gr.FAC] On one shell T_H = (1 - (-1)^n mu i) times the textbook tensor of mass E.  [gr.CAN] It is not the canonical T where the two differ;
    the frame term alone (spin connection set to zero) couples exactly to the canonical T, so the spin connection supplies exactly d_lam G^lam.
    [gr.TWO] Two shells at one shift: at the cross-shell q delta S = 0 exactly, as T_B and T are; without the Duhamel term it is not zero.
    [gr.BEAT] ATY-039's density for a uniform Phi beats at E_1 - E_2, but the source at that frequency (Phi oscillating at it) is zero.
Routes.
[ex]    exact in Q(i)[pi] (Gaussian rationals times polynomials in pi; pi is transcendental): numpy object arrays, exp(-s bslash) = sum_+- Pi_+- e^{-+i s E}
        with the projectors Pi_+- = (1 +- bslash/E)/2 on rational shells, the Duhamel and bilocal s-integrals in closed form (exact at quarter turns).
[std]   numpy and scipy: scipy expm; the Duhamel and the bilocal s-integrals by quad_vec (epsabs 1e-13, epsrel 1e-12); the Duhamel integral also
        by Van Loan's block exponential expm(tau [[A, 0], [V, B]]); tolerance 1e-9 relative to the largest component of the field's tensor.
[vb]    numpy: the vierbein formula (Christoffel symbols, omega, Gamma_mu) and ATY-037's N^{-1/2} D' N^{1/2}, five-point differences (step 1e-3),
        the g-derivative by Richardson (g = 1e-3); tolerance 1e-7.
[atlas] the std-route definitions of shifted_tensor.py (cquadm, cmat, bar_rows, ColTensor, ColSpin, col_belinfante) read with ast, only the
        definitions executed (that file runs its checks at import): its T_B and T at a point (quad_vec, five-point differences) against the
        Fourier sums here; tolerance 1e-8.
[ctl]   --fault NAME puts a wrong version into the main lines (the run must then end with FAILS and exit 1):
        NODUHAMEL  the shift built with the unperturbed D (delta exp(-tau D) dropped);   NOCONN  the spin connection dropped from delta D;
        CANONICAL  delta S compared with the canonical T of ATY-042 instead of T_B.
Scope.  First order in h; plane waves on rational shells with E tau on the quarter turns; single waves and two-wave fields (one shell; two shells
        at one shift); h with one Fourier mode; the classical field, no quantization; no claim about experiments.
Run:    python3 shifted_gravity.py [--fault NODUHAMEL|NOCONN|CANONICAL]   (also under -I -B)"""
import os, sys, time, math, random, ast
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad_vec
import warnings
from scipy.integrate import IntegrationWarning
warnings.filterwarnings('ignore', category=IntegrationWarning)
_here = os.path.dirname(os.path.abspath(__file__))

# ------------------------------------------------------------------------------------------------ check lines and faults
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('%s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('NODUHAMEL', 'NOCONN', 'CANONICAL')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact numbers: Q(i)[pi]
class QI:
    """sum_k (a_k + b_k i) pi^k with rational a_k, b_k"""
    __slots__ = ('c',)
    def __init__(self, c=None): self.c = c if c else {}
    @staticmethod
    def of(x):
        if isinstance(x, QI): return x
        if isinstance(x, (int, Fr)): return QI({0: (Fr(x), Fr(0))}) if x else QI()
        return None
    def __add__(self, o):
        o = QI.of(o)
        if o is None: return NotImplemented
        if not o.c: return self
        if not self.c: return o
        d = dict(self.c)
        for k, (a, b) in o.c.items():
            if k in d:
                a1, b1 = d[k][0] + a, d[k][1] + b
                if a1 or b1: d[k] = (a1, b1)
                else: del d[k]
            else: d[k] = (a, b)
        return QI(d)
    __radd__ = __add__
    def __neg__(self): return QI({k: (-a, -b) for k, (a, b) in self.c.items()})
    def __sub__(self, o):
        o = QI.of(o); return NotImplemented if o is None else self + (-o)
    def __rsub__(self, o):
        o = QI.of(o); return NotImplemented if o is None else o + (-self)
    def __mul__(self, o):
        o = QI.of(o)
        if o is None: return NotImplemented
        d = {}
        for k1, (a1, b1) in self.c.items():
            for k2, (a2, b2) in o.c.items():
                k = k1 + k2; re, im = a1 * a2 - b1 * b2, a1 * b2 + b1 * a2
                if k in d: re, im = re + d[k][0], im + d[k][1]
                d[k] = (re, im)
        return QI({k: v for k, v in d.items() if v[0] or v[1]})
    __rmul__ = __mul__
    def __truediv__(self, o):
        if not isinstance(o, (int, Fr)) or not o: return NotImplemented
        o = Fr(o); return QI({k: (a / o, b / o) for k, (a, b) in self.c.items()})
    def conj(self): return QI({k: (a, -b) for k, (a, b) in self.c.items()})
    def __bool__(self): return bool(self.c)
    def __eq__(self, o):
        o = QI.of(o); return o is not None and self.c == o.c
    __hash__ = None
    def __complex__(self): return sum((complex(float(a), float(b)) * math.pi ** k for k, (a, b) in self.c.items()), 0j)
    def __repr__(self):
        if not self.c: return '0'
        out = []
        for k in sorted(self.c):
            a, b = self.c[k]; pk = '' if k == 0 else (' pi' if k == 1 else ' pi^%d' % k)
            if a: out.append('%s%s' % (a, pk))
            if b: out.append('%s%s i' % (b, pk))
        return ' + '.join(out).replace('+ -', '- ')
def gi(a, b=0): return QI({0: (Fr(a), Fr(b))}) if (a or b) else QI()
IQ = gi(0, 1)
def fsqrt(q):
    q = Fr(q)
    if q <= 0: return None
    a, b = math.isqrt(q.numerator), math.isqrt(q.denominator)
    return Fr(a, b) if a * a == q.numerator and b * b == q.denominator else None
def Qf(b): return b[0] * b[0] - b[1] * b[1] - b[2] * b[2] - b[3] * b[3]
def isz(x): return not x if not isinstance(x, (complex, float, np.complexfloating, np.floating)) else x == 0
def cval(x): return complex(x)

# ------------------------------------------------------------------------------------------------ Dirac matrices (as in shifted_tensor.py's std route)
S1 = np.array([[0, 1], [1, 0]], complex); S2 = np.array([[0, -1j], [1j, 0]]); S3 = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
GM = [np.block([[I2, 0 * I2], [0 * I2, -I2]]).astype(complex)] + [np.block([[0 * I2, s_], [-s_, 0 * I2]]) for s_ in (S1, S2, S3)]
GU = [GM[0], -GM[1], -GM[2], -GM[3]]; I4 = np.eye(4, dtype=complex)
ETA = (1, -1, -1, -1); PAIRS_B = [(r, s) for r in range(4) for s in range(r + 1, 4)]
BLM = {}
for m_ in range(16):
    Mx = np.eye(4, dtype=complex)
    for i_ in range(4):
        if m_ >> i_ & 1: Mx = Mx @ GM[i_]
    BLM[m_] = Mx
def xq(z):
    re, im = int(round(z.real)), int(round(z.imag)); assert abs(complex(z) - complex(re, im)) < 1e-12; return gi(re, im)
def xmat(M): return np.array([[xq(z) for z in row] for row in np.asarray(M, complex)], dtype=object)
def xconj(v): return np.array([x.conj() for x in v], dtype=object)
def tofl(A): return np.array([complex(x) for x in np.ravel(A)], complex).reshape(np.shape(A))

class ExactBE:
    """exact route: exp(-s bslash) by the spectral projectors, the s-integrals in closed form"""
    tag = 'ex'
    def __init__(self):
        self.i = IQ; self.GM = [xmat(M) for M in GM]; self.GU = [xmat(M) for M in GU]; self.I4 = xmat(I4)
        self.BL = {p: self.GM[p[0]] @ self.GM[p[1]] for p in PAIRS_B}
        self.GGG = {(a, b, c): self.GU[a] @ self.GU[b] @ self.GU[c] for a in range(4) for b in range(4) for c in range(4)}
        self._c = {}; self._p = {}
    F = staticmethod(Fr)
    def zeros(self): return np.full((4, 4), QI(), dtype=object)
    def cmat(self, b):
        b = tuple(Fr(x) for x in b)
        if b not in self._c:
            out = self.zeros()
            for mu in range(4):
                if b[mu]: out = out + self.GU[mu] * b[mu]
            self._c[b] = out
        return self._c[b]
    def mass(self, b):
        E = fsqrt(Qf(b))
        if not E: raise ValueError('%r is not on a rational timelike shell' % (b,))
        return E
    def proj(self, b, sg):
        key = (tuple(Fr(x) for x in b), sg)
        if key not in self._p: self._p[key] = (self.I4 + self.cmat(b) * (Fr(sg) / self.mass(b))) * Fr(1, 2)
        return self._p[key]
    @staticmethod
    def phase(t):
        """e^{i pi t}, exact for 2t an integer"""
        t = Fr(t)
        if (2 * t).denominator != 1: raise ValueError('inexact phase e^{i pi %s}' % t)
        return [gi(1), IQ, gi(-1), gi(0, -1)][int(2 * t) % 4]
    def Iint(self, w, tf):
        """int_0^tau e^{i s w} ds with tau = tf pi: tau, or (e^{i w tau} - 1)/(i w)"""
        if w == 0: return QI({1: (Fr(tf), Fr(0))})
        return (self.phase(Fr(w) * tf) - 1) * gi(0, -1) / Fr(w)
    def O0(self, b, m, kap, tf):
        out = self.cmat(b) * Fr(-1) - self.I4 * Fr(m)
        if kap:
            E = self.mass(b)
            for sg in (1, -1): out = out + self.proj(b, sg) * (IQ * Fr(kap) * self.phase(-sg * E * Fr(tf)))
        return out
    def sint(self, r, bj, Xs, bl, c, tf):
        """r [int_0^tau ds exp(-i s bj-slash) X exp(-i (tau - s) bl-slash)] c: the bilocal integrand of ATY-042/044 (row exp(s D<-), column shifted)"""
        Ej, El = self.mass(bj), self.mass(bl); out = [QI() for _ in Xs]
        for sg in (1, -1):
            rP = r @ self.proj(bj, sg)
            if not any(rP): continue
            for sg2 in (1, -1):
                Pc = self.proj(bl, sg2) @ c
                if not any(Pc): continue
                fac = self.phase(-sg2 * El * Fr(tf)) * self.Iint(sg2 * El - sg * Ej, tf)
                for k, X in enumerate(Xs): out[k] = out[k] + (rP @ X @ Pc) * fac
        return out
    def duh(self, r, bo, Vs, bi, c, tf):
        """r [int_0^tau ds exp(-i (tau - s) bo-slash) V exp(-i s bi-slash)] c: the Duhamel integral (inner momentum bi, outer bo = bi + q)"""
        Eo, Ei = self.mass(bo), self.mass(bi); out = [QI() for _ in Vs]
        for sg in (1, -1):
            rP = r @ self.proj(bo, sg)
            if not any(rP): continue
            for sg2 in (1, -1):
                Pc = self.proj(bi, sg2) @ c
                if not any(Pc): continue
                fac = self.phase(-sg * Eo * Fr(tf)) * self.Iint(sg * Eo - sg2 * Ei, tf)
                for k, V in enumerate(Vs): out[k] = out[k] + (rP @ V @ Pc) * fac
        return out

class FloatBE:
    """standard route: scipy expm, quad_vec for the s-integrals, Van Loan's block exponential for the Duhamel integral"""
    tag = 'std'
    def __init__(self):
        self.i = 1j; self.GM = GM; self.GU = GU; self.I4 = I4
        self.BL = {p: GM[p[0]] @ GM[p[1]] for p in PAIRS_B}
        self.GGG = {(a, b, c): GU[a] @ GU[b] @ GU[c] for a in range(4) for b in range(4) for c in range(4)}
        self.vl_dev = 0.0; self.nquad = 0
    F = staticmethod(float)
    def zeros(self): return np.zeros((4, 4), complex)
    def cmat(self, b): return sum(float(b[mu]) * GU[mu] for mu in range(4))
    def O0(self, b, m, kap, tf):
        B = self.cmat(b); return -B - float(m) * I4 + 1j * float(kap) * expm(-1j * float(tf) * math.pi * B)
    def sint(self, r, bj, Xs, bl, c, tf):
        tau = float(tf) * math.pi; Bj, Bl = self.cmat(bj), self.cmat(bl); Xa = np.array(Xs); n = len(Xs)
        def f(s):
            z = np.einsum('i,kij,j->k', r @ expm(-1j * s * Bj), Xa, expm(-1j * (tau - s) * Bl) @ c)
            return np.concatenate([z.real, z.imag])
        res = quad_vec(f, 0.0, tau, epsabs=1e-13, epsrel=1e-12)[0]; self.nquad += 1
        return list(res[:n] + 1j * res[n:])
    def duh(self, r, bo, Vs, bi, c, tf):
        tau = float(tf) * math.pi; Bo, Bi = self.cmat(bo), self.cmat(bi); Va = np.array(Vs)
        def f(s):
            M = expm(-1j * (tau - s) * Bo) @ Va @ expm(-1j * s * Bi)
            return np.concatenate([M.real.ravel(), M.imag.ravel()])
        res = quad_vec(f, 0.0, tau, epsabs=1e-13, epsrel=1e-12)[0]; self.nquad += 1
        n = res.size // 2; Mi = (res[:n] + 1j * res[n:]).reshape(Va.shape); sc = np.abs(Mi).max()
        for k in range(len(Vs)):                                                   # Van Loan: expm(tau [[A, 0], [V, B]]) has int_0^tau e^{(tau-s)B} V e^{sA} ds below
            big = np.zeros((8, 8), complex); big[:4, :4] = -1j * Bi; big[4:, :4] = Va[k]; big[4:, 4:] = -1j * Bo
            if sc > 0: self.vl_dev = max(self.vl_dev, np.abs(expm(tau * big)[4:, :4] - Mi[k]).max() / sc)
        return [r @ Mi[k] @ c for k in range(len(Vs))]
EX = ExactBE(); FL = FloatBE()

# ------------------------------------------------------------------------------------------------ the first-order operator, the tensors, the coupling
CONN = [1]                                                                         # the sign of the spin-connection terms (gr.ORD flips it once)
def V_of(be, eps, q, b):
    """the symbol of delta D for h_{a mu} = eps_{a mu} e^{i q.x} (first index the frame's) on the column c e^{i b.x}: delta D (c e^{i b.x}) = e^{i (b+q).x} V c"""
    F = be.F; e = [[F(eps[x][y]) for y in range(4)] for x in range(4)]; qq = [F(v) for v in q]; bb = [F(v) for v in b]
    h2, h4, h8 = F(Fr(1, 2)), F(Fr(1, 4)), F(Fr(1, 8))
    out = be.zeros()
    for a in range(4):                                                             # -(1/2) h_a^mu gamma^a d_mu, h_a^mu = eta^{mu mu} eps_{a mu}
        for mu in range(4):
            if e[a][mu] and bb[mu]: out = out + be.GU[a] * (-h2 * e[a][mu] * ETA[mu] * bb[mu])
    if not fault('NOCONN'):
        s = [[(e[x][y] + e[y][x]) * h2 for y in range(4)] for x in range(4)]; w = [[(e[x][y] - e[y][x]) * h2 for y in range(4)] for x in range(4)]
        trs = sum(ETA[mu] * s[mu][mu] for mu in range(4)); cn = be.zeros()
        for b_ in range(4):                                                        # (1/4)(d_b s - d^a s_ab) gamma^b
            coef = qq[b_] * trs - sum(ETA[a] * qq[a] * s[a][b_] for a in range(4))
            if coef: cn = cn + be.GU[b_] * (coef * h4)
        for mu in range(4):                                                        # (1/8) gamma^mu gamma^a gamma^b d_mu w_ab
            if qq[mu]:
                for a in range(4):
                    for b_ in range(4):
                        if w[a][b_]: cn = cn + be.GGG[(mu, a, b_)] * (qq[mu] * w[a][b_] * h8)
        out = out + cn * F(CONN[0])
    return out * be.i
def pair_tensors(be, r, bj, c, bl, m, kap, tf):
    """for the row r e^{-i bj.x} and the column c e^{i bl.x} (frequency K = bl - bj): the canonical T^{mu nu} of ATY-042 (bilocal term included),
    the Belinfante T_B^{mu nu} of ATY-044 (T + d_lam G^lam with the bilocal spin current, d -> i K), and L"""
    F = be.F; i = be.i; K = [F(bl[mu]) - F(bj[mu]) for mu in range(4)]; h2 = F(Fr(1, 2))
    order = [(p, lam) for p in PAIRS_B for lam in range(4)]
    Xs = [be.GU[mu] for mu in range(4)] + [be.GU[lam] @ be.BL[p] for p, lam in order]
    loc = [r @ X @ c for X in Xs]
    bil = be.sint(r, bj, Xs, bl, c, tf) if kap else [0] * len(Xs)
    ik = i * F(kap); W = [loc[k] * i - bil[k] * ik for k in range(len(Xs))]     # W^mu (X = gamma^mu) and 2 S^lam[B] (X = gamma^lam B)
    L = r @ be.O0(bl, m, kap, tf) @ c
    T = [[W[mu] * (i * F(bl[nu])) - (L if mu == nu else 0) for nu in range(4)] for mu in range(4)]          # T^mu_nu
    S = {(lam,) + p: W[4 + n_] * h2 for n_, (p, lam) in enumerate(order)}
    def Sd(l, a, b):
        if a == b: return 0
        return S[(l, a, b)] * ETA[l] if a < b else S[(l, b, a)] * (-ETA[l])
    G = [[[(Sd(l, a, b) - Sd(a, l, b) - Sd(b, l, a)) * h2 for b in range(4)] for a in range(4)] for l in range(4)]
    TBl = [[T[a][b] * ETA[a] + sum(G[l][a][b] * (i * K[l]) * ETA[l] for l in range(4)) for b in range(4)] for a in range(4)]
    return ([[T[mu][nu] * ETA[nu] for nu in range(4)] for mu in range(4)], [[TBl[mu][nu] * (ETA[mu] * ETA[nu]) for nu in range(4)] for mu in range(4)], L)
def pair_coupling(be, r, bj, c, bl, m, kap, tf, q, epss, duhamel=True):
    """the coefficient of e^{i (bl + q - bj).x} in the first-order change of e psi-bar O_g psi for h = eps e^{i q.x}, one value per eps"""
    F = be.F; i = be.i; bo = tuple(bl[mu] + q[mu] for mu in range(4))
    L0 = r @ be.O0(bl, m, kap, tf) @ c; Vs = [V_of(be, e, q, bl) for e in epss]
    Ds = be.duh(r, bo, Vs, bl, c, tf) if (kap and duhamel and not fault('NODUHAMEL')) else [0] * len(Vs)
    ik = i * F(kap); out = []
    for e, V, d in zip(epss, Vs, Ds):
        trs = sum(ETA[mu] * F(e[mu][mu]) for mu in range(4))                      # e = 1 + h/2: the volume term (zero on a solution)
        out.append(L0 * (trs * F(Fr(1, 2))) + (r @ V @ c) * i - d * ik)
    return out
def textbook(be, r, bj, c, bl, E):
    """(i/4) psi-bar (gamma^mu <->d^nu + gamma^nu <->d^mu) psi - eta^{mu nu} psi-bar (i D - E) psi for the pair (<->d^nu -> i (bl + bj)^nu)"""
    F = be.F; J = [r @ be.GU[mu] @ c for mu in range(4)]; P = [F(ETA[nu]) * (F(bl[nu]) + F(bj[nu])) for nu in range(4)]
    LE = r @ (be.cmat(bl) * F(-1) - be.I4 * F(E)) @ c; q4 = F(Fr(-1, 4))
    return [[(J[mu] * P[nu] + J[nu] * P[mu]) * q4 - (LE * ETA[mu] if mu == nu else 0) for nu in range(4)] for mu in range(4)]
UNITS = [[[1 if (x, y) == (a, mu) else 0 for y in range(4)] for x in range(4)] for a in range(4) for mu in range(4)]   # eps = E^{a mu}, index 4a + mu
def field_data(be, waves, m, kap, tf, Etext=None, diag_only=False):
    """{K: data} summed over the pairs with K = b_l - b_j: dS (the 16 vierbein responses), T, TB, TT (textbook), rho"""
    rows = []
    for c, b, E in waves:
        cc = c if be.tag == 'ex' else tofl(c)
        rows.append(((xconj(cc) if be.tag == 'ex' else cc.conj()) @ be.GM[0], cc, b))
    out = {}
    def add(x, y): return y if isinstance(x, int) and x == 0 else x + y
    for j, (rj, cj, bj) in enumerate(rows):
        for l, (rl, cl, bl) in enumerate(rows):
            if diag_only and j != l: continue
            K = tuple(bl[mu] - bj[mu] for mu in range(4)); q = tuple(-x for x in K)
            Tup, TBup, L = pair_tensors(be, rj, bj, cl, bl, m, kap, tf)
            dS = pair_coupling(be, rj, bj, cl, bl, m, kap, tf, q, UNITS)
            TT = textbook(be, rj, bj, cl, bl, Etext) if Etext is not None else [[0] * 4 for _ in range(4)]
            d = out.setdefault(K, {'dS': [0] * 16, 'T': [[0] * 4 for _ in range(4)], 'TB': [[0] * 4 for _ in range(4)], 'TT': [[0] * 4 for _ in range(4)], 'rho': 0, 'pairs': []})
            d['dS'] = [add(x, y) for x, y in zip(d['dS'], dS)]
            for key, M in (('T', Tup), ('TB', TBup), ('TT', TT)): d[key] = [[add(d[key][a][b], M[a][b]) for b in range(4)] for a in range(4)]
            if j == l: d['rho'] = add(d['rho'], rj @ cl)
            d['pairs'].append((j, l))
    return out
# residuals of one frequency component (exact: zero means zero; floats: compared with a tolerance)
def TH(d):
    """the source T_H^{mu nu} from the ten symmetric responses: delta S(eps) = -(1/2) eps_mu.nu T_H^{mu nu}"""
    dS = d['dS']; return [[(dS[4 * a + b] + dS[4 * b + a]) * (-1) if a != b else dS[5 * a] * (-2) for b in range(4)] for a in range(4)]
def sym_resid(d, key):
    """delta S(eps) + (1/2) eps_mu.nu T^{mu nu} for the ten symmetric eps (T = T_B, or the canonical T)"""
    dS = d['dS']; T = d[key]; h2 = Fr(1, 2)
    return [dS[5 * a] + T[a][a] * h2 if a == b else dS[4 * a + b] + dS[4 * b + a] + (T[a][b] + T[b][a]) * h2 for a in range(4) for b in range(a, 4)]
def anti_resid(d): return [d['dS'][4 * a + b] - d['dS'][4 * b + a] for a in range(4) for b in range(a + 1, 4)]
def div4(M, K, F): return [sum(M[mu][nu] * F(K[mu]) for mu in range(4)) for nu in range(4)]
def cons_resid(d, K, F): return div4(TH(d), K, F)
def text_resid(d, fac):
    H = TH(d); return [H[a][b] - d['TT'][a][b] * fac for a in range(4) for b in range(a, 4)]
def allz(xs): return all(isz(x) for x in xs)
def nnz(xs): return sum(1 for x in xs if not isz(x))
def mx(xs): return max([abs(cval(x)) for x in xs] + [0.0])
def scale(data): return max(max(abs(cval(x)) for row in d['TB'] for x in row) for d in data.values())
TGT = 'T' if fault('CANONICAL') else 'TB'

# ------------------------------------------------------------------------------------------------ the fields
def kvec(k, s): return tuple(Fr(s) * Fr(k[0]) if mu == 0 else -Fr(s) * Fr(k[mu]) for mu in range(4))
def make_wave(k, s, E, rg):
    """an ordinary solution of mass E (bslash c = -E c) with a random Gaussian-integer seed, exact"""
    b = kvec(k, s); assert fsqrt(Qf(b)) == E, (k, E)
    while True:
        u = np.array([gi(rg.randint(-3, 3), rg.randint(-3, 3)) for _ in range(4)], dtype=object); c = EX.proj(b, -1) @ u
        if any(c): return (c, b, Fr(E))
def factor(kap, tf, n): return QI({0: (Fr(1), Fr(0)), 1: (Fr(0), -(-1) ** n * Fr(kap) * Fr(tf))}) if kap else gi(1)   # 1 - (-1)^n mu i
def quant(m, kap, tf, E, n):
    assert E == m + (-1) ** n * kap and Fr(E) * Fr(tf) == n + Fr(1, 2), (m, kap, tf, E, n)
SET = {'a': (3, 2, Fr(1, 10)), 'b': (3, 2, Fr(3, 2)), 'c': (4, 1, Fr(1, 2)), 'd': (2, 1, Fr(3, 2))}         # tau = tf pi
def sname(st): m, kap, tf = SET[st]; return '(%d, %d, %s)' % (m, kap, ('pi/%d' % tf.denominator) if tf.numerator == 1 else '%d pi/%d' % (tf.numerator, tf.denominator))
CONST = [('a', 5, 0, [((5, 0, 0, 0), -1), ((5, 0, 0, 0), 1), ((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)]),
         ('b', 1, 1, [((1, 0, 0, 0), -1), ((1, 0, 0, 0), 1), ((Fr(5, 4), Fr(3, 4), 0, 0), -1), ((Fr(5, 3), 0, Fr(4, 3), 0), 1)]),
         ('c', 5, 2, [((5, 0, 0, 0), -1), ((5, 0, 0, 0), 1), ((13, 0, 0, 12), -1), ((Fr(25, 4), 0, 0, Fr(15, 4)), -1)]),
         ('c', 3, 1, [((3, 0, 0, 0), -1), ((3, 0, 0, 0), 1), ((5, 4, 0, 0), -1), ((7, 6, 2, 0), 1)])]
ONE = [('A', 'a', 5, 0, [((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)]),
       ('B', 'c', 3, 1, [((5, 4, 0, 0), -1), ((7, 6, 2, 0), -1)]),
       ('C', 'c', 5, 2, [((13, 0, 0, 12), -1), ((5, 0, 0, 0), 1)]),
       ('D', 'b', 1, 1, [((Fr(5, 4), Fr(3, 4), 0, 0), -1), ((Fr(5, 3), 0, Fr(4, 3), 0), 1)])]
TWO = [('E', 'c', [((13, 12, 0, 0), -1, 5, 2), ((5, 0, 0, 4), -1, 3, 1)]),
       ('F', 'c', [((5, 0, 0, 0), -1, 5, 2), ((3, 0, 0, 0), -1, 3, 1)]),
       ('G', 'd', [((5, 4, 0, 0), -1, 3, 4), ((Fr(5, 3), 0, 0, Fr(4, 3)), -1, 1, 1)])]
ORD = [('H', 5, [((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)]), ('I', 3, [((5, 0, 0, 4), -1), ((3, 0, 0, 0), 1)])]   # kappa = 0, mass M
rg = random.Random(20261021)
FIELDS = {}                                                                         # name -> (waves, m, kap, tf, Etext, n)
for st, E, n, ws in CONST:
    m, kap, tf = SET[st]; quant(m, kap, tf, E, n)
    for idx, (k, s) in enumerate(ws): FIELDS['w%s%d.%d' % (st, E, idx)] = ([make_wave(k, s, E, rg)], m, kap, tf, E, n)
for name, st, E, n, ws in ONE:
    m, kap, tf = SET[st]; quant(m, kap, tf, E, n); FIELDS[name] = ([make_wave(k, s, E, rg) for k, s in ws], m, kap, tf, E, n)
for name, st, ws in TWO:
    m, kap, tf = SET[st]
    for k, s, E, n in ws: quant(m, kap, tf, E, n)
    FIELDS[name] = ([make_wave(k, s, E, rg) for k, s, E, n in ws], m, kap, tf, None, None)
for name, M, ws in ORD: FIELDS[name] = ([make_wave(k, s, M, rg) for k, s in ws], M, 0, Fr(1, 2), M, 0)
DATA = {}
for name, (waves, m, kap, tf, Et, n) in FIELDS.items():
    DATA[name] = {be.tag: field_data(be, waves, m, kap, tf, Etext=Et) for be in (EX, FL)}
print('fields built: %d (%d plane waves), %d frequency components, exact and float (%d quad_vec calls) [%.1f s]' % (len(FIELDS), sum(len(f[0]) for f in FIELDS.values()), sum(len(D['ex']) for D in DATA.values()), FL.nquad, time.time() - T0), flush=True)
def cross(name): return [K for K in DATA[name]['ex'] if any(K)]

# ================================================================================================ (0) conventions, by known results
head('(0) [gr.VB, gr.037, gr.SOL, gr.ORD, gr.039] the first-order operator and the sign conventions, fixed by known results')
def d5(f, y, mu, hh=1e-3):
    e = np.zeros(4); e[mu] = hh; return (-f(y + 2 * e) + 8 * f(y + e) - 8 * f(y - e) + f(y - 2 * e)) / (12 * hh)
def rich(Dg, x, g=1e-3): return (8 * (Dg(x, g) - Dg(x, -g)) - (Dg(x, 2 * g) - Dg(x, -2 * g))) / (12 * g)
nrg = np.random.default_rng(37); EPSR = nrg.normal(size=(4, 4)); QV = np.array([0.7, -0.4, 0.3, 0.9]); BV = np.array([-1.3, 0.4, -0.2, 0.8])
CV = nrg.normal(size=4) + 1j * nrg.normal(size=4)
XPTS = [np.array([0.3, -0.2, 0.5, 0.1]), np.array([-0.7, 0.4, -0.1, 0.9]), np.array([1.1, 0.6, -0.8, -0.3])]
def psi(y): return CV * np.exp(1j * (BV @ y))
def vierbein_D(x, g):
    """D_g psi at x by the vierbein formula: e_a^mu = delta - (g/2) eta^{mu mu} eps_{a mu} cos(q.x) (Einv[mu, a]), coframe, metric, Christoffel, omega, Gamma_mu"""
    Ei = lambda y: np.eye(4) - 0.5 * g * math.cos(QV @ y) * (np.diag(ETA) @ EPSR.T)
    Ea = lambda y: np.linalg.inv(Ei(y)); met = lambda y: Ea(y).T @ np.diag(ETA) @ Ea(y)
    gi_ = np.linalg.inv(met(x)); dg = [d5(met, x, mu) for mu in range(4)]; dEi = [d5(Ei, x, mu) for mu in range(4)]
    Gam = np.array([[[0.5 * sum(gi_[l, r] * (dg[mu][r, nu] + dg[nu][r, mu] - dg[r][mu, nu]) for r in range(4)) for nu in range(4)] for mu in range(4)] for l in range(4)])
    E_a, E_i = Ea(x), Ei(x); p = psi(x); out = np.zeros(4, complex)
    for mu in range(4):
        om = np.array([[sum(E_a[a, nu] * (dEi[mu][nu, b] + sum(Gam[nu, mu, l] * E_i[l, b] for l in range(4))) for nu in range(4)) for b in range(4)] for a in range(4)])
        Gs = 0.25 * sum(ETA[a] * om[a, b] * GU[a] @ GU[b] for a in range(4) for b in range(4))
        for a in range(4): out += E_i[mu, a] * (GU[a] @ (1j * BV[mu] * p + Gs @ p))
    return out
dev_vb = 0.0
for x in XPTS:
    num = rich(vierbein_D, x)
    ana = 0.5 * (V_of(FL, EPSR, QV, BV) @ CV * np.exp(1j * ((BV + QV) @ x)) + V_of(FL, EPSR, -QV, BV) @ CV * np.exp(1j * ((BV - QV) @ x)))
    dev_vb = max(dev_vb, np.abs(num - ana).max() / np.abs(ana).max())
chk('vb', dev_vb < 1e-7, 'gr.VB: delta D = -(1/2) h_a^mu gamma^a d_mu + (1/4)(d_b s - d^a s_ab) gamma^b + (1/8) gamma^mu gamma^a gamma^b d_mu w_ab (h = s + w, eps random and not symmetric, q = (0.7, -0.4, 0.3, 0.9)) equals the g-derivative of the vierbein formula D_g = gamma^a e_a^mu (d_mu + (1/4) omega_mu.ab gamma^a gamma^b), omega_mu^a_b = e^a_nu (d_mu e_b^nu + Gamma^nu_mu.lam e_b^lam), for e_a^mu = delta - (g/2) h_a^mu, h = eps cos(q.x), on a test wave at three points (five-point differences, Richardson in g; max relative deviation %.1e)' % dev_vb)
PHI = 0.8; Q37 = np.array([0.0, 0.6, -0.5, 0.8])
def frame037(x, g):
    """ATY-037's operator N^{-1/2} D' N^{1/2}, D' = N^{-1} gamma^0 d_t + gamma^i d_i, N = sqrt(1 - 2 g Phi cos(q.x)) (static: q_0 = 0)"""
    N = lambda y: math.sqrt(1 - 2 * g * PHI * math.cos(Q37 @ y)); f = lambda y: math.sqrt(N(y)) * psi(y)
    df = [d5(f, x, mu) for mu in range(4)]
    return N(x) ** -0.5 * (GU[0] @ df[0] / N(x) + sum(GU[i] @ df[i] for i in (1, 2, 3)))
E00 = [[-2 * PHI if (a, b) == (0, 0) else 0 for b in range(4)] for a in range(4)]
dev37 = 0.0
for x in XPTS:
    num = rich(frame037, x); ana = 0.5 * (V_of(FL, E00, Q37, BV) @ CV * np.exp(1j * ((BV + Q37) @ x)) + V_of(FL, E00, -Q37, BV) @ CV * np.exp(1j * ((BV - Q37) @ x)))
    dev37 = max(dev37, np.abs(num - ana).max() / np.abs(ana).max())
chk('vb', dev37 < 1e-7, 'gr.037: for a static h_00 = -2 Phi(x) (Phi = 0.8 cos(q.x), q = (0, 0.6, -0.5, 0.8)) the same delta D is the first-order term of ATY-037\'s N^{-1/2} D\' N^{1/2}, N = sqrt(1 - 2 Phi): the frame factor Phi gamma^0 d_0 and the connection -(1/2) gamma^i d_i Phi (max relative deviation %.1e)' % dev37)
ok_sol = True; nsol = 0
for name, (waves, m, kap, tf, Et, n) in FIELDS.items():
    for c, b, E in waves:
        O0 = EX.O0(b, m, kap, tf); r = xconj(c) @ EX.GM[0]; nsol += 1
        ok_sol &= not any(O0 @ c) and not any(r @ O0) and not any(EX.proj(b, 1) @ c)
chk('ex', ok_sol, 'gr.SOL: the %d plane waves used (rest and moving, both signs of the frequency; four settings (m, kappa, tau), and kappa = 0) are ordinary solutions of mass E, solve the shifted equation (-bslash - m + i kappa exp(-i tau bslash)) c = 0 exactly, and their Dirac conjugates psi-bar = psi^dagger gamma_0 solve the adjoint, r (...) = 0: delta S on them is int psi-bar delta O psi, the fields held fixed' % nsol)
ok_ord = True; ok_ordc = True; ok_flip = True; nord = 0
for name in ('H', 'I'):
    for K in cross(name):
        d = DATA[name]['ex'][K]; nord += 1
        ok_ord &= allz(sym_resid(d, TGT)) and allz(anti_resid(d)) and allz(text_resid(d, gi(1))) and nnz([x for row in d['TB'] for x in row]) > 0
        ok_ordc &= not allz(sym_resid(d, 'T'))
    waves, m, kap, tf, Et, n = FIELDS[name]; CONN[0] = -1
    flipped = field_data(EX, waves, m, kap, tf, Etext=Et); CONN[0] = 1
    ok_flip &= any(not allz(sym_resid(flipped[K], 'TB')) for K in flipped if any(K))
chk('ex', ok_ord and ok_ordc and ok_flip, 'gr.ORD: kappa = 0 (the Dirac field of mass M = 5 and 3, two moving or rest waves, both signs of the frequency), at the %d cross frequencies, exactly: delta S(eps) = -(1/2) eps_mu.nu T_B^{mu nu} for the ten symmetric eps, the six antisymmetric ones give 0, and T_H = (i/4) psi-bar (gamma^mu <->d^nu + gamma^nu <->d^mu) psi, the textbook symmetric tensor; it is not the canonical T; with the opposite sign of the spin connection T_H != T_B: the sign of Gamma_mu and the sign delta S = -(1/2) int h T (T^00 > 0) are fixed here' % nord)
ok_039 = True; d039 = []
for st, E, n, ws in CONST:
    m, kap, tf = SET[st]
    for idx, (k, s) in enumerate(ws):
        if any(k[1:]): continue
        d = DATA['w%s%d.%d' % (st, E, idx)]['ex'][(0, 0, 0, 0)]
        dSdPhi = d['dS'][0] * (-2)                                                    # h_00 = -2 Phi: delta S = -2 Phi delta S(E^00)
        ok_039 &= dSdPhi == d['T'][0][0] and dSdPhi == d['rho'] * Fr(E) * factor(kap, tf, n) and bool(d['rho'])
    d039.append('E = %d at %s: %r' % (E, sname(st), QI.of(Fr(E)) * factor(kap, tf, n)))
chk('ex', ok_039, 'gr.039: a uniform potential, h_00 = -2 Phi (all other h zero): on the rest modes of both sectors at four quantized shells dS/dPhi equals the Noether energy T^0_0 of ATY-038/042 (bilocal term included) and rho E (1 - (-1)^n mu i), rho = psi-bar psi, exactly: per unit rho %s (ATY-039, with i for J)' % '; '.join(d039))

# ================================================================================================ (1) constant h_mu.nu: all ten components
head('(1) [gr.CONST] a constant h_mu.nu, all ten components: the coupling is -(1/2) h_mu.nu T^{mu nu}_const with the factor (1 - (-1)^n mu i) on every component')
ok_c = True; ok_cf = True; ok_ctb = True; cdesc = []; ncomp = 0; nw = 0; dev_c = 0.0
for name, (waves, m, kap, tf, Et, n) in FIELDS.items():
    if kap == 0: continue
    d = DATA[name]['ex'][(0, 0, 0, 0)]; df = DATA[name]['std'][(0, 0, 0, 0)]; nw += name.startswith('w')
    ok_c &= allz(sym_resid(d, 'T')) and allz(sym_resid(d, TGT))
    ok_ctb &= all(d['T'][a][b] == d['TB'][a][b] for a in range(4) for b in range(4))
    dev_c = max(dev_c, mx(sym_resid(df, TGT)) / scale(DATA[name]['std']))
    if Et is not None:
        F_ = factor(kap, tf, n); ok_cf &= allz(text_resid(d, F_))
        nz = nnz([TH(d)[a][b] for a in range(4) for b in range(a, 4)])
        if name.startswith('w'): ncomp += nz
        if name in ('wa5.3', 'wc3.2'): cdesc.append('k = %s at E = %s: %d of 10 components nonzero' % ('(7,2,4,2)' if name == 'wa5.3' else '(5,4,0,0)', Et, nz))
chk('ex', ok_c and ok_cf and ok_ctb, 'gr.CONST: for a constant h_mu.nu (the ten basis tensors), exactly in Q(i)[pi], on %d single quantized waves (rest in both sectors, moving at k = (13,12,0,0), (7,2,4,2), (5/4,3/4,0,0), (5/3,0,4/3,0), (13,0,0,12), (25/4,0,0,15/4), (5,4,0,0), (7,6,2,0); four settings) and on the constant parts of the two-wave fields of (2): delta S = -(1/2) h_mu.nu T^{mu nu}_const with T the canonical tensor of ATY-042 (its bilocal term included), which equals T_B there; on one shell T_H^{mu nu} = (1 - (-1)^n mu i) T_Dirac,E^{mu nu} component by component (%d nonzero components checked on the single waves; %s): the factor of ATY-039 on every component, the Duhamel term giving it' % (nw, ncomp, '; '.join(cdesc)))
chk('std', dev_c < 1e-9, 'gr.CONST: Dirac matrices with scipy expm and quad_vec (the Duhamel integral at q = 0 and the bilocal terms), the same fields: max |delta S + (1/2) h.T| %.1e relative to the largest component' % dev_c)

# ================================================================================================ (2) h with a gradient
head('(2) [gr.GRAD, gr.SYM, gr.FAC, gr.CAN, gr.TWO, gr.BEAT] h = eps e^{i q.x}, q the difference of the two wave vectors: spin connection and Duhamel term')
ok_g = True; ng = 0; nzc = 0; gdesc = []
for name, st, E, n, ws in ONE:
    for K in cross(name):
        d = DATA[name]['ex'][K]; ok_g &= allz(sym_resid(d, TGT)); ng += 1; nzc += nnz([d['TB'][a][b] for a in range(4) for b in range(a, 4)])
    gdesc.append('%s E = %d' % (sname(st), E))
chk('ex', ok_g, 'gr.GRAD: on two waves of one quantized shell (%s; moving waves, both signs of the frequency), at both cross frequencies (q = +-(b_1 - b_2): %d Fourier components, %d nonzero entries of T_B among their ten each), exactly: the Fourier component of delta S, with the spin connection and the Duhamel term, is -(1/2) eps_mu.nu T_B^{mu nu}(-q) for each of the ten symmetric eps, T_B the Belinfante tensor of ATY-044 built with the bilocal spin current: the source of a weak gravitational field is T_B' % ('; '.join(gdesc), ng, nzc))
ok_sym = True; ok_cons = True; ok_tbs = True; nsc = 0
for name in [f[0] for f in ONE] + [f[0] for f in TWO] + [f[0] for f in ORD]:
    for K, d in DATA[name]['ex'].items():
        ok_sym &= allz(anti_resid(d)); ok_cons &= allz(cons_resid(d, K, Fr)); nsc += 1
        ok_tbs &= all(d['TB'][a][b] == d['TB'][b][a] for a in range(4) for b in range(4)) and allz(div4(d['TB'], K, Fr))
chk('ex', ok_sym and ok_cons and ok_tbs, 'gr.SYM: on all two-wave fields (one shell, two shells, kappa = 0) and all %d frequency components, exactly: the response to the six antisymmetric frame perturbations (a local Lorentz rotation, with its spin connection (1/8) gamma^mu gamma^a gamma^b d_mu w_ab and its Duhamel term) is zero, so the vierbein source T_H^{a mu} is symmetric; and it is conserved, K_mu T_H^{mu nu} = 0 for nu = 0 ... 3 (as T_B is, symmetric and conserved)' % nsc)
ok_fac = True; fdesc = []
for name, st, E, n, ws in ONE:
    m, kap, tf = SET[st]; F_ = factor(kap, tf, n)
    for K in cross(name): ok_fac &= allz(text_resid(DATA[name]['ex'][K], F_))
    fdesc.append('E = %d at %s: %r' % (E, sname(st), F_))
chk('ex', ok_fac, 'gr.FAC: on one shell, at the cross frequencies, T_H^{mu nu} = (1 - (-1)^n mu i) (i/4) psi-bar (gamma^mu <->d^nu + gamma^nu <->d^mu) psi, the textbook tensor of the free Dirac field of mass E, exactly in all ten components (%s): the Duhamel integral has the s-independent integrand exp(i E tau) on one shell, so the coupling is the ordinary one times the factor' % '; '.join(fdesc))
can_min = 1e300; ok_can = True; asym_min = 1e300
for name, st, E, n, ws in ONE:
    for K in cross(name):
        d = DATA[name]['ex'][K]; sc_ = mx([x for row in d['TB'] for x in row])
        can_min = min(can_min, mx(sym_resid(d, 'T')) / sc_); asym_min = min(asym_min, mx([d['T'][a][b] - d['T'][b][a] for a in range(4) for b in range(4)]) / sc_)
CONN[0] = 0; ok_frame = True; nfr = 0                                              # the frame term alone (with its Duhamel term): no spin connection
for name in [f[0] for f in ONE] + [f[0] for f in ORD]:
    waves, m, kap, tf, Et, n = FIELDS[name]; D0 = field_data(EX, waves, m, kap, tf)
    for K in cross(name): ok_frame &= allz(sym_resid(D0[K], 'T')); nfr += 1
CONN[0] = 1
chk('ctl', can_min > 1e-2 and asym_min > 1e-2 and ok_frame, 'gr.CAN: the same coupling is not the canonical T of ATY-042 where the two differ: at every one-shell cross frequency max |delta S(eps) + (1/2) eps.T_can| >= %.2f relative to |T_B|, and T_can is not symmetric there (>= %.2f); the frame term alone (spin connection set to zero, Duhamel term kept) gives exactly -(1/2) eps_mu.nu T_can^{mu nu} at all %d cross frequencies (one shell and kappa = 0): the frame term couples to the canonical tensor with its bilocal term, and the spin connection adds exactly the improvement d_lam G^lam of ATY-044' % (can_min, asym_min, nfr))
ok_two = True; ok_nd = True; nd_min = 1e300; tdesc = []
for name, st, ws in TWO:
    m, kap, tf = SET[st]; waves = FIELDS[name][0]
    for K in cross(name):
        d = DATA[name]['ex'][K]
        ok_two &= allz(d['dS']) and allz([x for row in d['TB'] for x in row]) and allz([x for row in d['T'] for x in row]) and allz(sym_resid(d, TGT))
        (j, l), = d['pairs']; c_j, b_j, _ = waves[j]; c_l, b_l, _ = waves[l]; r_j = xconj(c_j) @ EX.GM[0]
        nd = pair_coupling(EX, r_j, b_j, c_l, b_l, m, kap, tf, tuple(b_j[mu] - b_l[mu] for mu in range(4)), UNITS, duhamel=False)
        ok_nd &= not allz(nd); nd_min = min(nd_min, mx(nd) / scale(DATA[name]['ex']))
    tdesc.append('%s with E = %s, %s' % (sname(st), ' and '.join(str(w[2]) for w in ws), 'moving' if any(any(w[0][1:]) for w in ws) else 'at rest'))
chk('ex', ok_two and ok_nd, 'gr.TWO: two waves on two shells at one shift (%s; sector -1), at the cross-shell q = +-(b_1 - b_2): delta S = 0 exactly for all sixteen eps, and T_B = T = 0 there (ATY-042: the bilocal cross terms are minus the local ones): the coupling equals -(1/2) eps.T_B trivially, there is no gravitational source at the beat; the Duhamel term is what makes it vanish (the factor 1 - kappa e^{i E_1 tau} (e^{i (E_2 - E_1) tau} - 1)/(i (E_2 - E_1)) = 1 - (-1)^{n_1} = 0): without it the coupling there is not zero, exactly (at least %.1e of the largest |T_B| component of the field)' % ('; '.join(tdesc), nd_min))
# ATY-039 sharpened: the uniform-Phi density beats; the source at the beat frequency is zero
waves, m, kap, tf, Et, n = FIELDS['F']; (c1, b1, E1), (c2, b2, E2) = waves; r1 = xconj(c1) @ EX.GM[0]
dens = pair_coupling(EX, r1, b1, c2, b2, m, kap, tf, (0, 0, 0, 0), [UNITS[0]])[0] * (-2)          # uniform Phi: q = 0, the pair (1, 2) at K = b_2 - b_1
Kb = tuple(b2[mu] - b1[mu] for mu in range(4)); src = DATA['F']['ex'][Kb]['dS'][0] * (-2); d0 = DATA['F']['ex'][(0, 0, 0, 0)]
ok_beat = bool(dens) and not src and d0['dS'][0] * (-2) == d0['T'][0][0] and dens == (r1 @ c2) * Fr(E2) * factor(kap, tf, 1)
chk('ex', ok_beat, 'gr.BEAT: two rest modes at (4, 1, pi/2) with E = 5 and 3 (sector -1, amplitudes not orthogonal): the density of the coupling to a uniform Phi (ATY-039) has the term (%.4f %+.4fi) e^{i 2 t} = (psi-bar_1 psi_2) 3 (1 + pi i/2) e^{i (E_1 - E_2) t}, exactly, and its constant part is the Noether energy; but the coupling to a Phi that oscillates at the beat, h_00 = -2 Phi e^{i (E_2 - E_1) t}, is exactly 0: the beat of the uniform-Phi density is not a source; the source is T_B, which has no cross-shell part' % (complex(dens).real, complex(dens).imag))
dev_s = 0.0; dev_a = 0.0; dev_k = 0.0
for name in [f[0] for f in ONE] + [f[0] for f in TWO] + [f[0] for f in ORD]:
    sc_ = scale(DATA[name]['std'])
    for K, d in DATA[name]['std'].items():
        dev_s = max(dev_s, mx(sym_resid(d, TGT)) / sc_); dev_a = max(dev_a, mx(anti_resid(d)) / sc_)
        dev_k = max(dev_k, mx(cons_resid(d, K, float)) / (sc_ * max([1.0] + [abs(float(v)) for v in K])))
chk('std', dev_s < 1e-9 and dev_a < 1e-9 and dev_k < 1e-9 and FL.vl_dev < 1e-10, 'gr.STD: Dirac matrices, scipy expm, the Duhamel integral int_0^tau exp(-(tau - s) D) delta D exp(-s D) ds and the bilocal integrals by quad_vec, on the same nine two-wave fields and all their frequency components: |delta S + (1/2) eps.T_B| <= %.1e, antisymmetric responses <= %.1e, |K.T_H| <= %.1e (relative); the Duhamel integral by quad_vec equals Van Loan\'s block exponential to %.1e' % (dev_s, dev_a, dev_k, FL.vl_dev))
dev_xs = 0.0
for name in DATA:
    sc_ = scale(DATA[name]['std'])
    for K, d in DATA[name]['ex'].items():
        f_ = DATA[name]['std'][K]
        dev_xs = max(dev_xs, mx([cval(x) - y for x, y in zip(d['dS'], f_['dS'])]) / sc_, mx([cval(d['TB'][a][b]) - f_['TB'][a][b] for a in range(4) for b in range(4)]) / sc_)
chk('ex==std', dev_xs < 1e-10, 'gr.STD: the exact values (projectors, closed-form s-integrals) equal the float ones (expm, quad_vec) for delta S (sixteen eps) and T_B on all %d fields and frequency components (max deviation %.1e relative)' % (len(DATA), dev_xs))

# ------------------------------------------------------------------------------------------------ T_B as shifted_tensor.py computes it (read with ast)
def load_atlas():
    cands = [os.path.join(os.path.abspath(a_), 'proofs', 'shifted_tensor.py') for i_a, a_ in enumerate(sys.argv[1:], 1) if not a_.startswith('--') and sys.argv[i_a - 1] != '--fault'] + [os.path.join(_here, 'shifted_tensor.py'), os.path.normpath(os.path.join(_here, '..', '..', '..', 'v4', 'one-rule', 'checks', 'selfcheck', 'proofs', 'shifted_tensor.py'))]
    path = next((p for p in cands if os.path.isfile(p)), None)
    if path is None: return None, None
    with open(path, encoding='utf-8') as fh: tree = ast.parse(fh.read(), path)
    want = ('cquadm', 'cmat', 'bar_rows', 'ColTensor', 'ColSpin', 'col_belinfante')
    nodes = [nd for nd in tree.body if isinstance(nd, (ast.FunctionDef, ast.ClassDef)) and nd.name in want]
    if sorted(nd.name for nd in nodes) != sorted(want): return path, None
    ns = dict(np=np, expm=expm, quad_vec=quad_vec, I4=I4, GM=GM, GU=GU, BLM=BLM, ETA=ETA, PAIRS_B=PAIRS_B, fault=lambda name: False, colwaves=lambda P: P)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), path, 'exec'), ns)
    return path, ns
apath, ans = load_atlas(); dev_at = 1e300; adesc = 'shifted_tensor.py not found or its definitions missing'
if ans is not None:
    dev_at = 0.0; x = XPTS[0]
    for name in ('A', 'E'):
        waves, m, kap, tf, Et, n = FIELDS[name]
        cols = [(tofl(c), np.array([float(v) for v in b])) for c, b, E in waves]
        TLa, TBa = ans['col_belinfante'](cols, float(m), float(kap), float(tf) * math.pi, x)
        mine_B = np.zeros((4, 4), complex); mine_L = np.zeros((4, 4), complex)
        for K, d in DATA[name]['std'].items():
            ph = np.exp(1j * (np.array([float(v) for v in K]) @ x))
            mine_B += ph * np.array([[d['TB'][a][b] * ETA[a] * ETA[b] for b in range(4)] for a in range(4)])
            mine_L += ph * np.array([[d['T'][a][b] * ETA[a] * ETA[b] for b in range(4)] for a in range(4)])
        dev_at = max(dev_at, np.abs(mine_B - TBa).max() / np.abs(TBa).max(), np.abs(mine_L - TLa).max() / np.abs(TLa).max())
    adesc = 'read from %s' % os.path.relpath(apath, _here)
chk('atlas', dev_at < 1e-8, 'gr.GRAD: T_B and T here are those of ATY-044/042: shifted_tensor.py\'s own std-route definitions (ColTensor, ColSpin, col_belinfante; %s by ast, only the definitions executed) give, on the one-shell field A and the two-shell field E at x = (0.3, -0.2, 0.5, 0.1) (quad_vec, G differentiated by five-point differences), the same sixteen components of T_B and of the canonical T as the Fourier sums here (max deviation %.1e relative)' % (adesc, dev_at))

print('\n  [time] %.1f s' % (time.time() - T0), flush=True)
finish('SHIFTED-GRAVITY')
