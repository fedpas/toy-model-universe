#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""SHIFTED-REVIEW.  What the page "Calibration 3: the shifted view" left as "not computed" by choice, computed.   python3 shifted_review.py [--fault NAME]

(V) The variants at a null frequency (ATY-058): with Dirac matrices (gamma_0^2 = +1, K = gamma^mu k_mu, K^2 = k^2) the symbols of i D_x - m are
    D+  K - m + i kappa e^{i tau K};   D-  K - m - i kappa e^{-i tau K};   Ds  K - m + kappa sin(tau K);
    Dc (uniform, D + kappa cosh)  K - m + i kappa cos(tau K);   Dc (printed, D + i kappa cosh)  K - m - kappa cos(tau K)
    (scipy expm; the rest values reproduce ATY-007's E = m - kappa sin E tau for Ds and E = m + kappa cos E tau for Dc as printed).  On three null
    frequencies and five (m, kappa, tau), kappa tau = 1 among them: D- has a plane wave only at m = kappa = 0, like D+ (ATY-005); Ds at m = 0 keeps
    the massless solutions; Dc has none at m = 0 in either reading.
(C) Chirality: at m = 0 the symbol of Ds anticommutes with gamma_5 = i gamma_0 gamma_1 gamma_2 gamma_3 for timelike, spacelike and null K (sin is
    odd), so P_{L,R} = (1 -+ gamma_5)/2 map its solutions to solutions and its massless kernel splits into one left and one right state; the
    symbols of D+, D-, Dc (both readings) have a part even in K and do not anticommute.
(N) The paper's magnitudes from their inputs, as the sources state them: the lightest neutrino below 0.45 eV (KATRIN, 90 % CL); the equivalence-
    principle bound 1e-13 (the paper's figure); Lambda = 3 Omega_L H0^2 / c^2 with Planck 2018 (H0 = 67.36 km/s/Mpc, Omega_L = 0.6847,
    Omega_m = 0.3153, age 13.787 Gyr): (2.8) r >= lambda_C/4 of the lightest neutrino; (2.15) k/hbar <= 1e-13 / r; (3.7)-(3.8) k/hbar =
    sqrt(Lambda); (3.9) mu = k r / hbar; (5.1)-(5.4) the same numbers; the time scale hbar/kc of (4.4) = 1/(c sqrt(Lambda)).
(A) The age of the universe: in flat Lambda-CDM t0 = 2/(3 H0 sqrt(Omega_L)) arsinh(sqrt(Omega_L/Omega_m)), and c sqrt(Lambda) = sqrt(3 Omega_L) H0, so
    t0 / (hbar/kc) = (2/sqrt 3) arsinh(sqrt(Omega_L/Omega_m)): the paper's coincidence is the ratio Omega_L/Omega_m today (1.36 with Planck 2018).
(O) The odd-integer test: with one shift r, E_f r/(hbar c) = (n_f + 1/2) pi for every stable fermion, so E_f = (2 n_f + 1) u with u = pi hbar c/(2r)
    <= the lightest neutrino's mass; m_p/m_e = 1836.15267343(11) (CODATA 2018) must then be a ratio of odd integers with 2 n_e + 1 = m_e/u >= m_e/0.45 eV.
    Counted over 100 000 consecutive odd denominators from that bound: the fraction of them for which an odd numerator matches m_p/m_e within one
    standard uncertainty, and the relative precision on u that would fix n_e.
Controls (--fault puts each into its check, exit 1): DMINUS (the claim that D- keeps massless solutions at m = 0, as Ds does), CHIRAL (Ds built
with cos in place of sin), AGE (the age formula without the arsinh), ODD (the claim that the measured ratio alone fixes the integers: fraction < 0.01)."""
import sys, math, numpy as np
from scipy.linalg import expm
FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
if FAULT not in (None, 'DMINUS', 'CHIRAL', 'AGE', 'ODD'): print('unknown fault', FAULT); sys.exit(1)
ok = []
def chk(name, cond, msg): ok.append(bool(cond)); print(('ok  ' if cond else 'FAIL') + f' {name}: {msg}', flush=True)

# Dirac matrices, Cl(1,3): gamma_0^2 = +1, gamma_k^2 = -1
s1 = np.array([[0, 1], [1, 0]]); s2 = np.array([[0, -1j], [1j, 0]]); s3 = np.diag([1, -1]); Z2 = np.zeros((2, 2)); I4 = np.eye(4)
g = [np.diag([1, 1, -1, -1]).astype(complex)] + [np.block([[Z2, s], [-s, Z2]]).astype(complex) for s in (s1, s2, s3)]
g5 = 1j * g[0] @ g[1] @ g[2] @ g[3]
assert np.allclose(g5 @ g5, I4)
def Kof(k): return k[0] * g[0] - k[1] * g[1] - k[2] * g[2] - k[3] * g[3]
def fn(M, f):
    """f(M) for the matrix M via expm (f in exp, sin, cos)"""
    if f == 'exp': return expm(M)
    if f == 'sin': return (expm(1j * M) - expm(-1j * M)) / 2j
    if f == 'cos': return (expm(1j * M) + expm(-1j * M)) / 2
def symbol(var, K, m, ka, tau):
    if var == 'D+': return K - m * I4 + 1j * ka * fn(1j * tau * K, 'exp')
    if var == 'D-': return K - m * I4 - 1j * ka * fn(-1j * tau * K, 'exp')
    if var == 'Ds': return K - m * I4 + ka * fn(tau * K, 'cos' if FAULT == 'CHIRAL' else 'sin')
    if var == 'Dc-u': return K - m * I4 + 1j * ka * fn(tau * K, 'cos')
    if var == 'Dc-p': return K - m * I4 - ka * fn(tau * K, 'cos')
def kerdim(S, tol=1e-9): sv = np.linalg.svd(S, compute_uv=False); return int(sum(sv < tol * max(1, sv[0])))

# (V0) the symbols at rest reproduce ATY-005 / ATY-007
rest = []
for var, m, ka, tau, E in [('D+', 3, 2, math.pi / 10, 5), ('Ds', 4, 1, math.pi / 2, 4), ('Dc-p', 3, 1, math.pi / 2, 3), ('Dc-u', 3, 1, math.pi / 2, 3)]:
    rest.append(kerdim(symbol(var, Kof([E, 0, 0, 0]), m, ka, tau)) == 2)
chk('V0', all(rest), 'at rest the symbols have a two-dimensional kernel where ATY-005/ATY-007 put the solutions: D+ (3, 2, pi/10) at E = 5; Ds (4, 1, pi/2) '
    'at E = 4 = m - kappa sin(2 pi); Dc as printed (3, 1, pi/2) at E = 3 = m + kappa cos(3 pi/2); Dc read uniformly at E = m = 3, cos E tau = 0')
NULL = [(1, 1, 0, 0), (5, 3, 4, 0), (13, 5, 12, 0)]
SETS = [(3, 2, math.pi / 10), (1, 1, 1.0), (2, 0.5, 2.0), (0, 2, 0.5), (0, 0, 1.0)]
tab = {}
for var in ('D+', 'D-', 'Ds', 'Dc-u', 'Dc-p'):
    for (m, ka, tau) in SETS:
        tab[(var, m, ka, tau)] = [kerdim(symbol(var, Kof(k), m, ka, tau)) for k in NULL]
nz = lambda var: [(m, ka, round(tau, 4)) for (m, ka, tau) in SETS if any(tab[(var, m, ka, tau)])]
chk('V1', (nz('D-') == [(0, 0, 1.0)] if FAULT != 'DMINUS' else (0, 2, 0.5) in nz('D-')) and nz('D+') == [(0, 0, 1.0)],
    'at the null frequencies (1,1,0,0), (5,3,4,0), (13,5,12,0) D- has a plane wave only at m = kappa = 0, like D+ (sets (m, kappa, tau) = (3, 2, pi/10), '
    '(1, 1, 1), (2, 1/2, 2) with kappa tau = 1, (0, 2, 1/2), (0, 0, 1)); kernel dimensions with a solution: D- %s, D+ %s' % (nz('D-'), nz('D+')))
chk('V2', tab[('Ds', 0, 2, 0.5)] == [2, 2, 2] and not any(tab[('Dc-u', 0, 2, 0.5)]) and not any(tab[('Dc-p', 0, 2, 0.5)]),
    'at m = 0 (kappa = 2, tau = 1/2) Ds keeps the massless solutions (kernel 2 at each null frequency: its symbol there is (1 + kappa tau) K), '
    'Dc has none in either reading (kernels %s, %s)' % (tab[('Dc-u', 0, 2, 0.5)], tab[('Dc-p', 0, 2, 0.5)]))
# (C) chirality
rng = np.random.default_rng(11)
Ks = [Kof(k) for k in ([5, 3, 4, 0], [2, 1, 0, 0], [1, 2, 2, 0], [3, 1, 1, 1])] + [Kof(rng.integers(-5, 6, 4)) for _ in range(6)]
anti = {var: max(np.abs(g5 @ symbol(var, K, 0, 2, 0.7) + symbol(var, K, 0, 2, 0.7) @ g5).max() for K in Ks) for var in ('D+', 'D-', 'Ds', 'Dc-u', 'Dc-p')}
chk('C1', anti['Ds'] < 1e-10 and min(anti[v] for v in ('D+', 'D-', 'Dc-u', 'Dc-p')) > 1,
    'at m = 0 the symbol of Ds anticommutes with gamma_5 on timelike, null, spacelike and random K (largest |{g5, S}| %.1e); D+, D-, Dc (both readings) '
    'do not (smallest %.2f): only Ds keeps the two chiralities apart' % (anti['Ds'], min(anti[v] for v in ('D+', 'D-', 'Dc-u', 'Dc-p'))))
PL, PR = (I4 - g5) / 2, (I4 + g5) / 2
splits = []
for k in NULL:
    S = symbol('Ds', Kof(k), 0, 2, 0.5)
    U, sv, Vh = np.linalg.svd(S); ker = Vh.conj().T[:, sv < 1e-9]
    splits.append((np.linalg.matrix_rank(PL @ ker, 1e-9), np.linalg.matrix_rank(PR @ ker, 1e-9), np.allclose(S @ (PL @ ker), 0), np.allclose(S @ (PR @ ker), 0)))
chk('C2', all(s == (1, 1, True, True) for s in splits), 'the massless kernel of Ds at each null frequency splits into one left-handed and one right-handed '
    'solution, each solving Ds by itself')

# (N) magnitudes
hc_eVcm = 1.239841984e-4; c_cms = 2.99792458e10; yr = 3.15576e7; Mpc_cm = 3.0856775814913673e24
m_nu = 0.45; eta_EP = 1e-13; H0 = 67.36e5 / Mpc_cm; OL, Om = 0.6847, 0.3153; t0_Gyr = 13.787
r_min = hc_eVcm / (4 * m_nu)                                   # (2.8): r >= lambda_C/4 of the lightest neutrino
k_EP = eta_EP / r_min                                           # (2.15): |mu| = (k/hbar) r <= 1e-13
Lam = 3 * OL * H0 ** 2 / c_cms ** 2                             # (3.7)
k_L = math.sqrt(Lam)                                            # (3.8): Lambda = (k/hbar)^2
mu_min = k_L * r_min                                            # (3.9), (5.4)
T = 1 / (c_cms * k_L)                                           # hbar/kc of (4.4)
print('     (2.8)  r >= %.2e cm;  (2.15) k/hbar <= %.1e cm^-1;  (3.7) Lambda = %.3e cm^-2;  (3.8) k/hbar = %.3e cm^-1;  (3.9) mu >= %.1e;  hbar/kc = %.3e s = %.3e yr'
      % (r_min, k_EP, Lam, k_L, mu_min, T, T / yr))
chk('N1', abs(r_min - 6.89e-5) < 0.01e-5 and abs(Lam - 1.089e-56) < 0.005e-56 and abs(k_L - 1.044e-28) < 0.005e-28 and abs(mu_min - 7.19e-33) < 0.05e-33
    and k_EP > 100 * k_L, 'the paper\'s orders of magnitude hold with the inputs: r >= 6.9e-5 cm (paper: 1e-5 at 1 eV), k/hbar = 1.04e-28 cm^-1 from Lambda '
    '(paper: 1e-28), mu >= 7.2e-33 (paper: 1e-33), and k/hbar sits %.0e times below the equivalence-principle bound %.1e cm^-1' % (k_EP / k_L, k_EP))
# (A) the age
ratio_formula = (2 / math.sqrt(3)) * (math.log(math.sqrt(OL / Om) + math.sqrt(1 + OL / Om)) if FAULT != 'AGE' else math.sqrt(OL / Om))
t0_formula = ratio_formula * T / yr / 1e9
chk('A1', abs(t0_formula - t0_Gyr) < 0.05 and abs(ratio_formula - 1.3626) < 1e-3,
    'hbar/kc = 1/(c sqrt Lambda) = %.2f Gyr and, in flat Lambda-CDM, t0 = (2/sqrt 3) arsinh(sqrt(Omega_L/Omega_m)) hbar/kc = %.2f Gyr against Planck 2018\'s '
    '13.787 Gyr: the ratio %.3f is fixed by Omega_L/Omega_m alone' % (T / yr / 1e9, t0_formula, ratio_formula))
# (O) the odd-integer test
R, sR = 1836.15267343, 0.00000011
d0 = int(510998.95 / m_nu); d0 += (d0 + 1) % 2                   # odd 2 n_e + 1 >= m_e / u
par = 1
hits = 0; Nd = 100000
for j in range(Nd):
    d = d0 + 2 * j
    num = round(R * d); cands = [x for x in (num - 2, num - 1, num, num + 1, num + 2) if x % 2 == par]
    if any(abs(x / d - R) <= sR for x in cands): hits += 1
frac = hits / Nd; pred = sR * (d0 + Nd - 1)                        # odd numerators are spaced 2/d apart: 2 sR d / 2 at the mean d
chk('O1', abs(frac - pred) < 0.01 and (frac > 0.05 if FAULT != 'ODD' else frac < 0.01), 'from 2 n_e + 1 = %d up (m_e over 0.45 eV) a fraction %.3f of 100 000 consecutive odd denominators admits an odd '
    'numerator matching m_p/m_e within one standard uncertainty (expected %.3f): the test has no content while only an upper bound on the lightest '
    'mass is known; fixing n_e needs u to a relative precision of about %.0e' % (d0, frac, pred, 1 / d0))
print(f'{sum(ok)} of {len(ok)} checks hold'); print('FAILS (SHIFTED-REVIEW): ' + ('none' if all(ok) else 'some'))
sys.exit(0 if all(ok) else 1)
