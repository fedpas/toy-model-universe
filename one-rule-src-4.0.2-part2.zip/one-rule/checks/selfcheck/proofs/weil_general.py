#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""weil_general.py: the open points of passes 13d and 13f on the labels, for every number of qubits, every genus and every n: the class of
Weil's projective representation of B0((Z/2)^m) has order 4 for every m >= 2; his relation (40) has a solution exactly when 4 | n (m >= 2);
the vectors fixed by Weil's operators of genus g and the orthogonal transvections form a line, and the finite Siegel-Weil formula holds, for
every g and every cell with p = q mod 8 (round 17, proofs pass 13g; docs/round17/PROOFS_ROUND13G.md).
python3 weil_general.py [--fault NOS|ONEQ|SAMEPB|NOH|NOTV]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig). Labels in LAB-028's dictionary: the labels of a cell with n generators are G = (Z/2)^n, their form f = i^w,
w(a) = |a| mod 2 + 2 [e_a^2 = -1] read from the kernel (the bit side), w(a) = |a & P| - |a & Q| mod 4 written without it (the std side), the
dot product its morphism; 1 the top label (all ones); V0 the labels of even weight. Sources (docs/round17/PROOFS_ROUND13G.md, section 3):
A. Weil, Sur certains groupes d'operateurs unitaires, Acta Math. 111 (1964) 143-211, read in full (pass 13b): n. 15 (Theorem 3), n. 42-43
(Lemma 6, a lemma of group theory whose hypothesis, U^-1, Ua, Ub, Uc meeting for all a, b, c, he checks for analytic groups over local
fields; relation (40), phi(s'') = gamma(f0)^-n phi(s) phi(s'), for a character equal to t^n on T; n = 2 over a local field of
characteristic other than 2, and in characteristic 2, for X of even dimension, on Mp+(X) over Ps+(X), gamma(f) being +-1 there, n. 25),
n. 52 (pass 13f). K. Mastel, The Clifford theory of the n-qubit
Clifford group (arXiv:2307.05810v2, 2025; read in full): Theorem III.6 (the Clifford group modulo the Paulis and the phases is Sp(2n, 2)),
Lemma IV.1 (Sp(2n, 2) transitive on the non-zero vectors). G. Nebe, E. M. Rains, N. J. A. Sloane, Codes and invariant theory
(arXiv:math/0311046, 2003; read in full): Theorem 3.5 (weight enumerators of self-dual codes and the invariants of the Clifford-Weil group),
Theorem 4.2 with its remark (the scalars of the Clifford-Weil group, cyclic of order the least length of a code of the Type), Theorem 5.2.
Recalled, not read: the Cauchy binomial theorem; the form of the stabilizer states (Dehaene and De Moor) and their number.
Matrices: m qubits, qubit 0 the leftmost tensor factor (the highest bit of a basis index); exact entries in Z[1/2, i], Gaussian integers over
a power of two; zeta H = ((1 + i)/2) (1 1; 1 -1), S = diag(1, i), CNOT_ct (control c, target t). A vector of F2^(2m) is an integer, x the low
m bits and z the high m bits (qubit j at bit j), <v, v'> = x.z' + z.x'; the image of a Clifford unitary U is read from U^-1 X_j U and
U^-1 Z_j U (Weil's relation (15)); U lies over the big cell Omega0 when the x-parts of the images of Z_1..Z_m are independent (the block gamma
invertible). The genus side: D_g, Weil's operators on functions on (labels)^g: T_j, the translation of coordinate j by 1; X_j, its character
(-1)^(xi_j . 1); F_j, the multiplication by f(xi_j); H_j, the Fourier transform 2^(-n/2) (-1)^(xi_j . eta); for i != j the cross term
(-1)^(xi_i . xi_j) and the shear xi_i -> xi_i + xi_j. E_g, the sum of the orbit of delta_0; A_g, the average over the genus (the self-dual
codes all of whose labels have f = 1: even weight and square +1) of the theta functional of genus g; Theta_g, the function equal to
c_r = Prod_(i=1..r) (1 + 2^(k-i))^-1, k = (n - 2)/2, on the g-tuples of labels with f = 1, mutually orthogonal, whose span with 1 has
dimension r + 1, and 0 elsewhere (a label of odd weight and square +1 has f = i and lies outside). Vectors
exact: integer arrays (numpy) over a power of two; Z[zeta][1/2] in integer coordinates for one generator; fixed spaces over Q in fractions.
wg.CLASS [std] three lines: (1) i 1 = a b a^-1 b^-1 in the group of zeta H, S, CNOT on two qubits, b = zeta H (x) S, a a monomial unitary
         (a word in the gates), exact; with 1 on a third qubit too: every group of unitaries lying over all of B0((Z/2)^m), m >= 2, holds i 1.
         (2) that group lies over all of B0((Z/2)^m): the images of the gates read from the matrices are the closed forms (m <= 3); m = 1, 2:
         6 = |Sp(2, 2)| and 720 = |Sp(4, 2)| elements (the symplectic matrices counted); m = 1..8: the images move x_0 to all 4^m - 1 non-zero
         vectors, and HSH on qubit 0, the CNOTs from qubit k to qubit 0 and the gates of the other qubits fix x_0 and move z_0 to all
         2^(2m-1) vectors f with <x_0, f> = 1: the induction step; S^2 = Z, (zeta H) Z (zeta H)^-1 = X. (3) the elements of modulus 1 of
         Z[1/2, i] are the fourth roots (x^2 + y^2 = 4^k only for (+-2^k, 0), (0, +-2^k), k <= 12), (zeta H)^2 = i 1: the class has order 4.
wg.REL40 [std] two lines: (1) the certificate: P, B, X, words in the gates, with P B P^-1 B^-1 = -i 1 and P, B, X, BX, PX, PBX over the big
         cell, for m = 2 and, with P (x) y.., B (x) y.., X (x) z.. (y = zeta H, z = S zeta H), for m = 3, 4, 5: a solution of (40) gives
         (-i)^n = 1. (2) the hypothesis of Weil's Lemma 6 fails: x lies in U a (U = Omega0) when the Lagrangian of x is transversal to that
         of a; the triples of Lagrangians with no common transversal that is also transversal to L* counted for m = 1, 2; for every m the
         three Lagrangians l + L' (l a line of qubit 0, L' the z's of the other qubits) have no common transversal (m <= 3 by enumeration).
wg.TRANS [bit] the transvections x -> x + (x.v) v (v of even weight, f(v) = -1, read from the kernel) with T: one orbit on the ordered r-tuples
         of independent mutually orthogonal labels with f = 1 (independent modulo 1), r <= k for n <= 8 and r <= 2 for n = 10, of the size
         2^r Prod_(i<r) 2^i (2^(k-i) - 1)(2^(k-i-1) + 1); the sum of (-1)^(w/2) over the even labels is 2^(n/2) cos(pi (p - q)/4) (every
         cell, n <= 12).
wg.LINE  [std] two lines: (1) the fixed space of D_g and the transvections computed directly (the support of the diagonal operators, the orbits
         of T, the shears and the transvections on it, the Fourier equations), exact over Q, every cell with n <= 12 (g = 1), n <= 10 (g = 2),
         n <= 6 (g = 3): a line spanned by Theta_g when p = q mod 8, its live orbits the ranks 0..min(g, k), and 0 otherwise. (2) (F H)^3 =
         exp(i pi (p - q)/4) 1 as operators (every basis vector, every cell with n <= 8): a scalar of D_g, not 1 unless p = q mod 8.
wg.SW    [bit==std] the formula: the kernel's form is the standard one (n <= 12); A_g from the genus = Theta_g = E_g / E_g(delta_0), g = 2 for
         the 6 cells with n = 8, 10 and the 3 with n <= 6, g = 3 for (1,1), (2,2), (3,3); E_g through one generator (Weil's operators factor
         over the generators: the gate on those of square +1, its conjugate on the others), and on all of (labels)^g for g = 2, n <= 8 and
         g = 3, n <= 4, the same sums; E_g(delta_0) = Prod_(i<g) (1 + 2^(2+i-n/2)) = |orbit| / |A_g|^2; for (8,0) the genus-2 enumerator of
         the extended Hamming code, computed from a generator matrix. [std] the orbit's lines (g = 1, 2, 3): 2^g Prod (2^i + 1), those meeting delta_0 with support of dimension
         r number [g r]_2 2^(r(r+3)/2); the Cauchy binomial identity behind the constant (g <= 12, n <= 40).
Controls ([ctl], computed without the fault) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   NOS the gates without S; ONEQ b = zeta H (x) 1 in place of zeta H (x) S; SAMEPB the certificate with B = P; NOH Weil's operators without
   the Fourier transform; NOTV the transvections left out (in the cells with at most 256 points of (labels)^g, where the larger space stays
   small).
Argued, not computed (docs/round17/pass13g/RESULT.md, section 2, has the proofs): the class and relation (40) for the m beyond those computed;
the line and the formula for the g and n beyond those computed; the transitivity of the transvections beyond n = 10; the constant E_g(delta_0)
for g >= 4 (from the recalled form of the stabilizer states).
Command: python3 -I -B selfcheck/proofs/weil_general.py from checks/ (or from this folder); the standard library and numpy."""
import os, sys, itertools
from math import gcd, isqrt
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish():
    print('\n  tags: %s' % ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)))
    print('weil_general: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOS', 'ONEQ', 'SAMEPB', 'NOH', 'NOTV')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
if FAULT: print('FAULT %s: the main lines below use the wrong version and must fail' % FAULT)

def pc(a): return bin(a).count('1')

# ================================================================================================ exact matrices over Z[1/2, i]
def gred(e, M):
    """the matrix M / 2^e, M rows of Gaussian integers (a, b); the common powers of two divided out"""
    g = 0
    for row in M:
        for a, b in row:
            if a: g = gcd(g, a)
            if b: g = gcd(g, b)
    if g == 0: e = 0
    while e > 0 and g % 2 == 0:
        M = [[(a // 2, b // 2) for a, b in row] for row in M]; g //= 2; e -= 1
    return (e, tuple(tuple(r) for r in M))
def geye(d): return gred(0, [[(1 if i == j else 0, 0) for j in range(d)] for i in range(d)])
def gmul(A, B):
    ea, Ma = A; eb, Mb = B; K = len(Mb); cols = len(Mb[0]); out = []
    for Ai in Ma:
        nzk = [(k, Ai[k]) for k in range(K) if Ai[k] != (0, 0)]; row = []
        for j in range(cols):
            re = im = 0
            for k, (a, b) in nzk:
                c, d = Mb[k][j]
                if c or d: re += a * c - b * d; im += a * d + b * c
            row.append((re, im))
        out.append(row)
    return gred(ea + eb, out)
def gprod(*As):
    r = As[0]
    for A in As[1:]: r = gmul(r, A)
    return r
def gkron(A, B):
    ea, Ma = A; eb, Mb = B
    return gred(ea + eb, [[(a * c - b * d, a * d + b * c) for (a, b) in ra for (c, d) in rb] for ra in Ma for rb in Mb])
def gdag(A):
    e, M = A
    return (e, tuple(tuple((M[j][i][0], -M[j][i][1]) for j in range(len(M))) for i in range(len(M[0]))))
def gscalar(A):
    """lambda with A = lambda 1 (as (e, (a, b)): (a + i b) / 2^e), or None"""
    e, M = A; s = M[0][0]
    if any(M[i][j] != (s if i == j else (0, 0)) for i in range(len(M)) for j in range(len(M))): return None
    return (e, s)
def tens(*As):
    r = As[0]
    for A in As[1:]: r = gkron(r, A)
    return r
ZH = gred(1, [[(1, 1), (1, 1)], [(1, 1), (-1, -1)]])
S1 = gred(0, [[(1, 0), (0, 0)], [(0, 0), (0, 1)]])
I1 = geye(2)
XP = gred(0, [[(0, 0), (1, 0)], [(1, 0), (0, 0)]])
ZP = gred(0, [[(1, 0), (0, 0)], [(0, 0), (-1, 0)]])
SW = I1 if FAULT == 'NOS' else S1                                          # the S of the words
def on(m, j, g1): return tens(*[g1 if k == j else I1 for k in range(m)])
def cnot(m, c, t):
    d = 1 << m; M = [[(0, 0)] * d for _ in range(d)]
    for b in range(d): M[b ^ (((b >> (m - 1 - c)) & 1) << (m - 1 - t))][b] = (1, 0)
    return gred(0, M)
def pauli_vec(A, m):
    """v (x low m bits, z high m bits, qubit j at bit j) with A = lambda X^x Z^z, else None"""
    e, M = A; d = 1 << m
    nz0 = [c for c in range(d) if M[0][c] != (0, 0)]
    if len(nz0) != 1: return None
    x = nz0[0]; ref = M[x][0]; neg = (-ref[0], -ref[1]); z = 0
    for j in range(m):
        c = 1 << (m - 1 - j)
        if M[c ^ x][c] == neg: z |= c
    for c in range(d):
        want = neg if pc(z & c) & 1 else ref
        for r in range(d):
            if M[r][c] != (want if r == c ^ x else (0, 0)): return None
    sx = sum(((x >> (m - 1 - j)) & 1) << j for j in range(m)); sz = sum(((z >> (m - 1 - j)) & 1) << j for j in range(m))
    return sx | (sz << m)
def images(U, m):
    """the images of x_0..x_(m-1), z_0..z_(m-1) under U^-1 . U"""
    Ud = gdag(U)
    return [pauli_vec(gprod(Ud, on(m, j, XP), U), m) for j in range(m)] + [pauli_vec(gprod(Ud, on(m, j, ZP), U), m) for j in range(m)]
def rank2(vs):
    vs = [v for v in vs]; r = 0; basis = []
    for v in vs:
        for b in basis: v = min(v, v ^ b)
        if v: basis.append(v); basis.sort(reverse=True)
    return len(basis)
def big(U, m):
    im = [pauli_vec(gprod(gdag(U), on(m, j, ZP), U), m) for j in range(m)]
    return None not in im and rank2([v & ((1 << m) - 1) for v in im]) == m

# ---------------------------------------------------------------- the images in Sp(2m, 2) in closed form
def sp_gens(m, use_s=True):
    out = []
    for j in range(m):
        out.append(('H', j, lambda v, j=j: v ^ ((((v >> j) ^ (v >> (m + j))) & 1) * ((1 << j) | (1 << (m + j))))))
        if use_s: out.append(('S', j, lambda v, j=j: v ^ (((v >> j) & 1) << (m + j))))
    for c in range(m):
        for t in range(m):
            if c != t: out.append(('CNOT', (c, t), lambda v, c=c, t=t: v ^ (((v >> c) & 1) << t) ^ (((v >> (m + t)) & 1) << (m + c))))
    return out
def sform(u, v, m):
    k = (1 << m) - 1
    return (pc((u & k) & (v >> m)) + pc((u >> m) & (v & k))) & 1
def orbit(start, fs):
    seen = {start}; fr = [start]
    while fr:
        nx = []
        for v in fr:
            for f in fs:
                u = f(v)
                if u not in seen: seen.add(u); nx.append(u)
        fr = nx
    return seen
def apply_cols(t, v):
    r = 0; i = 0
    while v:
        if v & 1: r ^= t[i]
        v >>= 1; i += 1
    return r

# ================================================================================================ wg.CLASS
head('wg.CLASS: the class of Weil\'s projective representation of B0((Z/2)^m), for every m >= 2')
A_ = gprod(cnot(2, 1, 0), on(2, 1, ZH), cnot(2, 0, 1), on(2, 1, SW), on(2, 1, SW), on(2, 1, ZH))
B_ = gmul(on(2, 0, ZH), on(2, 1, SW)) if FAULT != 'ONEQ' else on(2, 0, ZH)
comm2 = gscalar(gprod(A_, B_, gdag(A_), gdag(B_)))
A3 = gkron(A_, I1); B3 = gkron(B_, I1); comm3 = gscalar(gprod(A3, B3, gdag(A3), gdag(B3)))
mono = all(sum(1 for x in row if x != (0, 0)) == 1 and all(x in ((0, 0), (0, 1), (0, -1)) for x in row) for row in A_[1]) and A_[0] == 0
chk('std', comm2 == (0, (0, 1)) and comm3 == (0, (0, 1)) and mono, 'wg.CLASS: i 1 is a single commutator: in the group of zeta H = ((1 + i)/2) (1 1; 1 -1), S = diag(1, i) and CNOT on two qubits, a = CNOT_10 (1 (x) zeta H) CNOT_01 (1 (x) S)^2 (1 (x) zeta H), a monomial unitary with entries +-i, and b = zeta H (x) S give a b a^-1 b^-1 = i 1, exactly over Z[1/2, i]; with 1 on a third qubit, (a (x) 1)(b (x) 1)(a (x) 1)^-1(b (x) 1)^-1 = i 1: for every m >= 2, every group of unitaries lying over all of B0((Z/2)^m) holds i 1, since the commutator of its elements over the images of a and b is the same (commutators do not see scalars)')

match = True
for m in (1, 2, 3):
    mats = [('H', j, on(m, j, ZH)) for j in range(m)] + [('S', j, on(m, j, SW)) for j in range(m)]
    mats += [('CNOT', (c, t), cnot(m, c, t)) for c in range(m) for t in range(m) if c != t]
    cf = {(nm, j): f for nm, j, f in sp_gens(m, FAULT != 'NOS')}
    for nm, j, U in mats:
        if (nm, j) not in cf: continue
        img = images(U, m)
        if img != [cf[(nm, j)](1 << i) for i in range(2 * m)]: match = False
G1 = sp_gens(1, FAULT != 'NOS'); grp = {(1, 2)}; fr = [(1, 2)]
while fr:
    nx = []
    for t in fr:
        for _, _, f in G1:
            u = tuple(f(x) for x in t)
            if u not in grp: grp.add(u); nx.append(u)
    fr = nx
sp2 = sum(1 for a in range(1, 4) for b in range(4) if sform(a, b, 1) == 1)
G2 = sp_gens(2, FAULT != 'NOS'); basis2 = (1, 2, 4, 8); grp2 = {basis2}; fr = [basis2]
while fr:
    nx = []
    for t in fr:
        for _, _, f in G2:
            u = tuple(f(x) for x in t)
            if u not in grp2: grp2.add(u); nx.append(u)
    fr = nx
sp4 = sum(1 for t in itertools.product(range(16), repeat=4) if all(sform(t[i], t[j], 2) == sform(basis2[i], basis2[j], 2) for i in range(4) for j in range(i + 1, 4)))
ind = True; rep = []
for m in range(1, 9):
    G = sp_gens(m, FAULT != 'NOS'); x0 = 1; z0 = 1 << m
    o = orbit(x0, [f for _, _, f in G])
    fH = {j: f for nm, j, f in G if nm == 'H'}; fS = {j: f for nm, j, f in G if nm == 'S'}
    moves = [f for nm, j, f in G if (nm in ('H', 'S') and j != 0) or (nm == 'CNOT' and j[1] == 0)]
    if 0 in fS: moves.append(lambda v: fH[0](fS[0](fH[0](v))))
    fixes = all(f(x0) == x0 for f in moves)
    o2 = orbit(z0, moves); want2 = {v for v in range(1 << (2 * m)) if sform(x0, v, m) == 1}
    if len(o) != 4 ** m - 1 or not fixes or o2 != want2: ind = False
    rep.append('m = %d: %d and %d' % (m, len(o), len(o2)))
paulis = gmul(S1, S1) == ZP and gprod(ZH, ZP, gdag(ZH)) == XP
chk('std', match and len(grp) == 6 == sp2 and len(grp2) == 720 == sp4 and ind and paulis, 'wg.CLASS: the group of zeta H, S and CNOT lies over all of B0((Z/2)^m): the images of the gates in Sp(2m, 2), read from the matrices as U^-1 X_j U and U^-1 Z_j U, are the closed forms (H swaps x_j and z_j, S adds x_j to z_j, CNOT_ct adds x_c to x_t and z_t to z_c; m <= 3); for m = 1 they generate %d elements, all of Sp(2, 2) (%d), for m = 2 %d, all of Sp(4, 2) (%d symplectic matrices among the 65536); for m = 1..8 they move x_0 to all 4^m - 1 non-zero vectors, and HSH on qubit 0, the CNOTs from qubit k to qubit 0 and the gates of the other qubits fix x_0 and move z_0 to all 2^(2m-1) vectors f with <x_0, f> = 1 (%s): the step of the induction, |image| >= (4^m - 1) 2^(2m-1) |Sp(2m - 2, 2)| >= |Sp(2m, 2)|, the group of the other m - 1 qubits fixing x_0 and z_0; S^2 = Z and (zeta H) Z (zeta H)^-1 = X give the Pauli group' % (len(grp), sp2, len(grp2), sp4, '; '.join(rep)))

desc = True
for k in range(13):
    sols = [(x, y) for x in range(-(1 << k), (1 << k) + 1) for y2 in [4 ** k - x * x] if y2 >= 0 and isqrt(y2) ** 2 == y2 for y in {isqrt(y2), -isqrt(y2)}]
    if sorted(sols) != sorted([(1 << k, 0), (-(1 << k), 0), (0, 1 << k), (0, -(1 << k))]): desc = False
zh2 = gscalar(gmul(ZH, ZH)) == (0, (0, 1))
chk('std', desc and zh2 and comm2 == (0, (0, 1)) and ind, 'wg.CLASS: the scalars: the elements of modulus 1 of Z[1/2, i] are the fourth roots ((x + i y)/2^k with x^2 + y^2 = 4^k: only (+-2^k, 0) and (0, +-2^k), k <= 12, and by descent for every k, x and y being even when 4 divides x^2 + y^2), so the group of zeta H, S and CNOT, whose entries lie in Z[1/2, i], holds no scalar but the fourth roots, and (zeta H)^2 = i 1 gives them all; a section of B0 into it has its factor system in the fourth roots, while a class of order 2 would give a group over all of B0 with the scalars +-1, which i 1 excludes: the class of Weil\'s projective representation of B0((Z/2)^m) has order 4 for every m >= 2 (computed: the step of the induction for m <= 8, the commutator for m = 2, 3, the descent for k <= 12; every m by the proof)')

# ================================================================================================ wg.REL40
head('wg.REL40: Weil\'s relation (40) for m >= 2: a solution exactly when 4 | n')
P_ = gprod(on(2, 0, ZH), on(2, 1, ZH), on(2, 0, SW), on(2, 0, ZH))
B2 = gprod(on(2, 0, ZH), cnot(2, 0, 1), on(2, 0, ZH), cnot(2, 1, 0), on(2, 0, SW), on(2, 0, SW)) if FAULT != 'SAMEPB' else P_
X_ = gprod(on(2, 0, ZH), on(2, 1, SW), on(2, 1, ZH))
Y1 = ZH; Z1 = gmul(SW, ZH)
one = all(big(U, 1) for U in (Y1, Z1, gmul(Y1, Z1), gprod(Y1, Y1, Z1)))
cert = True; reps = []
for m in (2, 3, 4, 5):
    k = m - 2
    Pm = tens(P_, *[Y1] * k); Bm = tens(B2, *[Y1] * k); Xm = tens(X_, *[Z1] * k)
    cm = gscalar(gprod(Pm, Bm, gdag(Pm), gdag(Bm)))
    BX = gmul(Bm, Xm); PX = gmul(Pm, Xm); PBX = gmul(Pm, BX); BPX = gmul(Bm, PX)
    cells = [big(U, m) for U in (Pm, Bm, Xm, BX, PX, PBX)]
    swap = PBX == gred(BPX[0], [[(b, -a) for a, b in row] for row in BPX[1]])        # PBX = -i BPX
    if cm != (0, (0, -1)) or not all(cells) or not swap: cert = False
    reps.append('m = %d: [P, B] = %s' % (m, {(0, (0, -1)): '-i 1', (0, (1, 0)): '1'}.get(cm, str(cm))))
ruled = [n for n in range(1, 9) if cert and n % 4 != 0]
chk('std', cert and one, 'wg.REL40: the certificate: P = (zeta H (x) 1)(1 (x) zeta H)(S (x) 1)(zeta H (x) 1), B = (zeta H (x) 1) CNOT_01 (zeta H (x) 1) CNOT_10 (S (x) 1)^2, X = (zeta H (x) 1)(1 (x) S)(1 (x) zeta H) satisfy P B P^-1 B^-1 = -i 1, and P, B, X, BX, PX, PBX lie over the big cell Omega0 (the x-parts of the images of Z_1..Z_m independent), for m = 2 and, with P (x) y.., B (x) y.., X (x) z.. (y = zeta H, z = S zeta H; on one qubit y, z, yz and y^2 z lie over Omega0), for m = 3, 4, 5 (%s): if phi solves (40), chi(t r0(s)) = t^n phi(s) is multiplicative on the lifts of Omega0 whose product lies over it, and the relations (B, X), (P, BX), (P, X), (B, PX) give chi(PBX) = chi(P) chi(B) chi(X) = (-i)^n chi(PBX), so (-i)^n = 1: no solution for n = %s; for every m >= 2 the same, the big cell of a tensor product holding the products of the big cells (the block gamma is block-diagonal); with n = 4 the character t g -> t^4 of the group of all lifts, the scalars times the group of zeta H, S and CNOT (whose scalars are the fourth roots, wg.CLASS), gives phi = (-1)^m (LAB-032, computed for m <= 3; for every m Weil\'s formula (16) makes the entries of r0(s) 2^(-m/2) times fourth roots, so zeta^m r0(s), with entries in Z[1/2, i] and lying over s, is a fourth root times an element of the group): (40) has a solution exactly when 4 | n' % ('; '.join(reps), ', '.join(map(str, ruled))))

def lagrangians(m):
    """the Lagrangian subspaces of F2^(2m) for <v, v'> = x.z' + z.x', each the frozenset of its 2^m vectors"""
    N = 1 << (2 * m); level = {frozenset([0])}
    for _ in range(m):
        nxt = set()
        for S in level:
            for v in range(1, N):
                if v not in S and all(sform(v, s, m) == 0 for s in S): nxt.add(frozenset(S | {s ^ v for s in S}))
        level = nxt
    return sorted(level, key=lambda S: sorted(S))
def transversal(L, M): return len(L & M) == 1
lem6 = True; l6rep = []; nlag = []
for m in (1, 2, 3):
    LG = lagrangians(m); nlag.append(len(LG))
    Lstar = frozenset(v for v in range(1 << (2 * m)) if v & ((1 << m) - 1) == 0)          # L*: the z's (x = 0)
    Lp = [v for v in Lstar if not (v >> m) & 1]                                            # L': the z's of qubits 1..m-1
    trio = [frozenset(l ^ u for l in (0, lv) for u in Lp) for lv in (1, 1 << m, 1 | (1 << m))]   # l + L', l = <x_0>, <z_0>, <x_0 + z_0>
    if Lstar not in LG or not all(T in LG for T in trio) or any(all(transversal(M, T) for T in trio) for M in LG): lem6 = False
    if m <= 2:
        cand = [M for M in LG if transversal(M, Lstar)]
        TV = [{j for j, M in enumerate(cand) if transversal(M, L)} for L in LG]
        bad = sum(1 for i, j, k in itertools.product(range(len(LG)), repeat=3) if not (TV[i] & TV[j] & TV[k]))
        l6rep.append('%d of the %d triples when m = %d' % (bad, len(LG) ** 3, m))
        if bad == 0: lem6 = False
chk('std', lem6, 'wg.REL40: the hypothesis of Weil\'s Lemma 6 fails on these finite groups: with U = Omega0 (closed under inversion; a condition on the images in Sp(2m, 2)), x lies in U a exactly when the Lagrangian of x (the image of L* = <z_1..z_m>, read from the side of the action) is transversal to that of a, so U^-1, Ua, Ub, Uc meet for all a, b, c only if every three Lagrangians have a common transversal that is also transversal to L*; none exists for %s; for every m the three Lagrangians l + L\' (l a line of the plane of qubit 0, L\' = <z_1..z_(m-1)>) have no common transversal (none among the %s Lagrangians for m = 1, 2, 3), since every Lagrangian meets the (m + 1)-dimensional space (plane of qubit 0) + L\', which is their union: Lemma 6 does not reach these groups, and line 1 with wg.CLASS settles (40) without it' % ('; '.join(l6rep), ', '.join(map(str, nlag))))

# ================================================================================================ the genus side (numpy, exact)
def sig(p, q): return list(_core_sig(p, q, 0))
def wtable(p, q):
    """the labels' form from the kernel: w(a) = |a| mod 2 + 2 [e_a^2 = -1] (the bit side)"""
    br = BR(sig(p, q))
    return np.array([((pc(a) & 1) + 2 * (1 if br.sq(a) == -1 else 0)) % 4 for a in range(1 << (p + q))], dtype=np.int64)
def wstd(p, q):
    """the same form written without the kernel: |a & P| - |a & Q| mod 4, P the p generators of square +1 (the low bits)"""
    n = p + q; P = (1 << p) - 1; Q = ((1 << n) - 1) ^ P
    return np.array([(pc(a & P) - pc(a & Q)) % 4 for a in range(1 << n)], dtype=np.int64)
PARITY = {}
def parity(n):
    if n not in PARITY: PARITY[n] = np.array([pc(a) & 1 for a in range(1 << n)], dtype=np.int64)
    return PARITY[n]
def tvecs(w, n):
    par = parity(n); return [v for v in range(1, 1 << n) if par[v] == 0 and w[v] == 2]
def support(w, n, g):
    """the g-tuples of labels with w = 0 (f = 1: even weight and square +1), mutually orthogonal, encoded sum xi_j << (n j), sorted"""
    par = parity(n); sing = [a for a in range(1 << n) if w[a] == 0]; out = []
    def rec(prefix):
        if len(prefix) == g: out.append(sum(x << (n * j) for j, x in enumerate(prefix))); return
        for a in sing:
            if all(not par[a & b] for b in prefix): rec(prefix + [a])
    rec([])
    return np.array(sorted(out), dtype=np.int64)
def orbits(w, n, g, S, use_tv=True, use_T=True, use_shear=True):
    """the orbits of the transvections, T_j and the shears on the support S; dead: the labels of the orbits that leave S"""
    N = 1 << n; one = N - 1; par = parity(n)
    co = [(S >> (n * j)) & (N - 1) for j in range(g)]
    def enc(cs): return sum(c.astype(np.int64) << (n * j) for j, c in enumerate(cs))
    gens = []
    if use_tv:
        for v in tvecs(w, n): gens.append(enc([np.where(par[c & v] == 1, c ^ v, c) for c in co]))
    if use_T:
        for j in range(g): gens.append(enc([c ^ one if k == j else c for k, c in enumerate(co)]))
    if use_shear:
        for i in range(g):
            for j in range(g):
                if i != j: gens.append(enc([c ^ co[j] if k == i else c for k, c in enumerate(co)]))
    s = len(S); lab = np.arange(s); dead = np.zeros(s, dtype=bool); P = []
    for img in gens:
        pos = np.minimum(np.searchsorted(S, img), s - 1); ok = S[pos] == img
        dead |= ~ok; P.append(np.where(ok, pos, np.arange(s)))
    while True:
        old = lab.copy()
        for pi in P: lab = np.minimum(lab, lab[pi])
        lab = lab[lab]
        if np.array_equal(lab, old): break
    return lab, set(np.unique(lab[dead]).tolist())
def rank_mod1(cs, n):
    basis = [(1 << n) - 1]
    for v in cs:
        for b in basis: v = min(v, v ^ b)
        if v: basis.append(v); basis.sort(reverse=True)
    return len(basis) - 1
def walsh_axis(arr, axis):
    a = np.moveaxis(arr, axis, -1).copy(); sh = a.shape; L = sh[-1]; h = 1
    while h < L:
        a = a.reshape(sh[:-1] + (L // (2 * h), 2, h))
        x = a[..., 0, :].copy(); y = a[..., 1, :].copy(); a[..., 0, :] = x + y; a[..., 1, :] = x - y
        a = a.reshape(sh); h *= 2
    return np.moveaxis(a, -1, axis)
def nullspace(rows, m):
    rows = [[Fr(int(x)) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(m):
        pr = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if pr is None: continue
        rows[rk], rows[pr] = rows[pr], rows[rk]; iv = 1 / rows[rk][c]; rows[rk] = [x * iv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [x - f * y for x, y in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    basis = []
    for fc in [c for c in range(m) if c not in piv]:
        v = [Fr(0)] * m; v[fc] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][fc]
        basis.append(v)
    return basis
def ccoef(n, g):
    k = (n - 2) // 2; c = [Fr(1)]
    for r in range(1, min(g, k) + 1): c.append(c[-1] / (1 + Fr(2) ** (k - r)))
    return c
def fixed_space(p, q, g, w, use_tv=True, use_h=True):
    """the functions on (labels)^g fixed by D_g (and the transvections when use_tv): (dimension, live orbits, ranks, the vector or None)"""
    n = p + q; N = 1 << n; D = N ** g
    S = support(w, n, g)
    if len(S) == 0: return 0, 0, [], None
    lab, dead = orbits(w, n, g, S, use_tv=use_tv)
    alive = sorted(set(np.unique(lab).tolist()) - dead)
    if not alive: return 0, 0, [], None
    reps = [int(S[np.argmax(lab == L)]) for L in alive]
    rk = [rank_mod1([(x >> (n * j)) & (N - 1) for j in range(g)], n) for x in reps]
    if not use_h: return len(alive), len(alive), rk, None
    if n % 2: raise SystemExit('a live orbit for odd n: the Fourier equations would need 2^(n/2)')
    h = 2 ** (n // 2); vecs = []
    for L in alive:
        v = np.zeros(D, dtype=np.int64); v[S[lab == L]] = 1; vecs.append(v)
    blocks = []
    for j in range(g):
        cols = [walsh_axis(v.reshape((N,) * g), g - 1 - j).reshape(D) - h * v for v in vecs]
        blocks.append(np.unique(np.stack(cols, axis=1), axis=0))
    R = np.unique(np.concatenate(blocks), axis=0)
    ns = nullspace(R.tolist(), len(alive))
    if len(ns) != 1: return len(ns), len(alive), rk, None
    v = ns[0]
    if 0 not in rk: return 1, len(alive), rk, None
    v0 = v[rk.index(0)]
    return 1, len(alive), rk, ([x / v0 for x in v] if v0 != 0 else None)

# ================================================================================================ wg.TRANS
head('wg.TRANS: the orthogonal transvections are transitive on the ordered bases of totally singular subspaces (modulo 1)')
trans = True; trep = []
for n in (2, 4, 6, 8, 10):
    for p in range(n, -1, -1):
        q = n - p
        if (p - q) % 8: continue
        w = wtable(p, q); k = (n - 2) // 2
        for r in range(1, min(k, 3 if n <= 8 else 2) + 1):
            S = support(w, n, r)
            lab, dead = orbits(w, n, r, S, use_tv=(FAULT != 'NOTV'), use_T=True, use_shear=False)
            rk = np.array([rank_mod1([(int(x) >> (n * j)) & ((1 << n) - 1) for j in range(r)], n) for x in S])
            labs = set(lab[rk == r].tolist())
            want_n = 2 ** r
            for i in range(r): want_n *= 2 ** i * (2 ** (k - i) - 1) * (2 ** (k - i - 1) + 1)
            if len(labs) != 1 or int((rk == r).sum()) != want_n: trans = False
            if p >= q: trep.append('(%d,%d) r = %d: %d' % (p, q, r, int((rk == r).sum())))
gauss = True; ngs = 0
for n in range(2, 13, 2):
    for p in range(n + 1):
        q = n - p; w = wtable(p, q); ngs += 1
        s = int(sum((-1) ** (int(w[a]) // 2) for a in range(1 << n) if parity(n)[a] == 0))
        want = {0: 1, 4: -1}.get((p - q) % 8, 0) * 2 ** (n // 2)
        if s != want: gauss = False
chk('bit', trans and gauss, 'wg.TRANS: with the labels\' form read from the kernel, the orthogonal transvections x -> x + (x.v) v (v of even weight and square -1) and the translation by the top label act with one orbit on the ordered r-tuples of labels with f = 1 (even weight and square +1), mutually orthogonal and independent modulo 1, for each cell with p = q mod 8: r <= k = (n - 2)/2 for n <= 8, r <= 2 for n = 10 (%s tuples, each count 2^r Prod_(i<r) 2^i (2^(k-i) - 1)(2^(k-i-1) + 1), 2^r times the number of ordered bases of the totally singular r-subspaces of W = V0/<1>, hyperbolic of dimension 2k): the transitivity that reduces a fixed vector to a function of the rank; the sum of (-1)^(w/2) over the labels of even weight is 2^(n/2) cos(pi (p - q)/4) in all %d cells with n even, n <= 12: + 2^(n/2) exactly when p = q mod 8, where W, of dimension 2k with the form w/2, has the Gauss sum + 2^k (hyperbolic), and - 2^(n/2) when p - q = 4 mod 8' % (', '.join(trep), ngs))

# ================================================================================================ wg.LINE
head('wg.LINE: the vectors fixed by Weil\'s operators and the transvections, in every genus')
line = True; nl = 0; lrep = []; skipped = 0
for g, nmax in ((1, 12), (2, 10), (3, 6)):
    for n in range(1, nmax + 1):
        for p in range(n, -1, -1):
            q = n - p; D = (1 << n) ** g
            if FAULT == 'NOTV' and D > 256: skipped += 1; continue
            dim, nlive, rk, v = fixed_space(p, q, g, wstd(p, q), use_tv=(FAULT != 'NOTV'), use_h=(FAULT != 'NOH'))
            nl += 1
            if (p - q) % 8 == 0 and n >= 2:
                k = (n - 2) // 2; c = ccoef(n, g)
                ok = dim == 1 and v is not None and sorted(rk) == list(range(min(g, k) + 1)) and all(v[i] == c[rk[i]] for i in range(len(rk)))
                if g >= 2 and n >= 8 or g == 3 and n >= 4: lrep.append('(%d,%d) g = %d: Theta = %s' % (p, q, g, ', '.join(str(c[r]) for r in range(len(c)))))
            else:
                ok = dim == 0
            if not ok: line = False
chk('std', line, 'wg.LINE: the functions on (labels)^g fixed by Weil\'s operators D_g and the orthogonal transvections, computed without the theory: an invariant vanishes where a diagonal operator (F_j, X_j, the cross terms) is not 1, so on the g-tuples of labels with f = 1 (even weight and square +1), mutually orthogonal; it is constant on the orbits of T_j, the shears and the transvections there, and 0 on an orbit that leaves that support; the Fourier equations H_j v = v, exact over Q, then leave a line spanned by Theta_g when p = q mod 8, whose live orbits are the ranks r = 0..min(g, k), k = (n - 2)/2, with the values c_r = Prod_(i=1..r) (1 + 2^(k-i))^-1 (%s), and 0 otherwise, in all %d (cell, genus) cases: n <= 12 for g = 1, n <= 10 for g = 2, n <= 6 for g = 3%s' % ('; '.join(lrep), nl, '' if not skipped else ' (%d larger cells left out under the fault)' % skipped))

scal = True; ncell = 0
for n in range(1, 9):
    N = 1 << n; Wm = np.array([[(-1) ** pc(a & b) for b in range(N)] for a in range(N)], dtype=np.int64)
    for p in range(n + 1):
        q = n - p; w = wstd(p, q); ncell += 1
        fr_ = np.array([1, 0, -1, 0])[w]; fi_ = np.array([0, 1, 0, -1])[w]
        Mr = fr_[:, None] * Wm; Mi = fi_[:, None] * Wm                 # F W
        Rr, Ri = Mr.copy(), Mi.copy()
        for _ in range(2): Rr, Ri = Rr @ Mr - Ri @ Mi, Rr @ Mi + Ri @ Mr
        d = p - q
        if n % 2 == 0: u = [(1, 0), (0, 1), (-1, 0), (0, -1)][(d // 2) % 4]; scale = 2 ** (3 * n // 2)
        else: u0 = [(1, 0), (0, 1), (-1, 0), (0, -1)][((d - 1) // 2) % 4]; u = (u0[0] - u0[1], u0[0] + u0[1]); scale = 2 ** ((3 * n - 1) // 2)
        if not (np.array_equal(Rr, u[0] * scale * np.eye(N, dtype=np.int64)) and np.array_equal(Ri, u[1] * scale * np.eye(N, dtype=np.int64))): scal = False
chk('std', scal, 'wg.LINE: (F H)^3 = exp(i pi (p - q)/4) 1 as operators on the functions of one coordinate, on every basis vector of the %d cells with n <= 8 (exact: (F W)^3 = 2^(3n/2) exp(i pi (p - q)/4) 1 with W the matrix (-1)^(a.b)); for every n it is the product over the generators of (S H)^3 = zeta and its conjugate (LAB-028): the scalar exp(i pi (p - q)/4) lies in D_g in every genus, so no non-zero function is fixed by D_g when p is not q mod 8' % ncell)

# ================================================================================================ wg.SW
head('wg.SW: the finite Siegel-Weil formula in every genus')
# ---- Z[zeta][1/2], zeta = exp(i pi/4): (a0, a1, a2, a3, e) = (sum a_k zeta^k) / 2^e
def zc(a, e):
    a = list(a)
    if not any(a): return (0, 0, 0, 0, 0)
    while e > 0 and all(x % 2 == 0 for x in a): a = [x // 2 for x in a]; e -= 1
    return tuple(a) + (e,)
def zadd(x, y):
    e = max(x[4], y[4]); return zc([x[k] * 2 ** (e - x[4]) + y[k] * 2 ** (e - y[4]) for k in range(4)], e)
def zmul(x, y):
    c = [0] * 8
    for i in range(4):
        if x[i]:
            for j in range(4): c[i + j] += x[i] * y[j]
    return zc([c[k] - c[k + 4] for k in range(4)], x[4] + y[4])
def zneg(x): return zc([-v for v in x[:4]], x[4])
ZERO = (0, 0, 0, 0, 0); ONE = (1, 0, 0, 0, 0); IU = (0, 0, 1, 0, 0); RT2INV = (0, 1, 0, -1, 1); RT2 = (0, 1, 0, -1, 0)
ZPOW = [zc([(1 if j < 4 else -1) if k == j % 4 else 0 for k in range(4)], 0) for j in range(8)]
def site_gens(g, use_h=True):
    """Weil's operators on one generator of square +1: T_j -> X_j, its character -> Z_j, F_j -> S_j, H_j -> H_j, cross -> CZ, shear -> CNOT"""
    d = 1 << g; out = []
    for j in range(g):
        out.append(('perm', [b ^ (1 << j) for b in range(d)]))
        out.append(('diag', [zneg(ONE) if (b >> j) & 1 else ONE for b in range(d)]))
        out.append(('diag', [IU if (b >> j) & 1 else ONE for b in range(d)]))
        if use_h: out.append(('had', j))
    for i in range(g):
        for j in range(g):
            if i < j: out.append(('diag', [zneg(ONE) if (b >> i) & (b >> j) & 1 else ONE for b in range(d)]))
            if i != j: out.append(('perm', [b ^ (((b >> j) & 1) << i) for b in range(d)]))
    return out
def site_apply(op, u):
    kind, data = op
    if kind == 'perm': return tuple(u[data[b]] for b in range(len(u)))
    if kind == 'diag': return tuple(zmul(u[b], data[b]) for b in range(len(u)))
    j = data; out = []
    for b in range(len(u)):
        b0 = b & ~(1 << j); b1 = b | (1 << j)
        out.append(zmul(zadd(u[b0], zneg(u[b1]) if (b >> j) & 1 else u[b1]), RT2INV))
    return tuple(out)
def site_orbit(g, use_h=True):
    gens = site_gens(g, use_h); s0 = tuple([ONE] + [ZERO] * ((1 << g) - 1)); seen = {s0}; fr = [s0]
    while fr:
        nx = []
        for u in fr:
            for op in gens:
                v = site_apply(op, u)
                if v not in seen: seen.add(v); nx.append(v)
        fr = nx
    return seen
def split(u):
    """a vector of the orbit as (support mask, phase exponents mod 8, r): each non-zero entry is zeta^j 2^(-r/2)"""
    nz = [b for b in range(len(u)) if u[b] != ZERO]; r = len(nz).bit_length() - 1
    if 1 << r != len(nz): raise SystemExit('an orbit vector whose support is not a power of two')
    sr = ONE
    for _ in range(r): sr = zmul(sr, RT2)
    m = np.zeros(len(u), dtype=bool); j = np.zeros(len(u), dtype=np.int64)
    for b in nz:
        x = zmul(u[b], sr)
        if x not in ZPOW: raise SystemExit('an orbit vector with an entry that is not zeta^j 2^(-r/2)')
        m[b] = True; j[b] = ZPOW.index(x)
    return m, j, r
def lines_of(orb):
    out = {}
    for u in orb:
        m, j, r = split(u); b0 = int(np.argmax(m))
        out.setdefault((tuple(m.tolist()), tuple(np.where(m, (j - j[b0]) % 8, 0).tolist())), (m, j, r))
    return list(out.values())
def E_site(p, q, g, lines):
    """E_g on (labels)^g from the orbit of one generator: 2^e E_g as integer coefficients of 1, zeta, zeta^2, zeta^3"""
    n = p + q; N = 1 << n; D = N ** g; idx = np.arange(D, dtype=np.int64)
    co = [(idx >> (n * j)) & (N - 1) for j in range(g)]
    cols = [sum(((co[j] >> t) & 1) << j for j in range(g)) for t in range(n)]
    rmax = max(r for _, _, r in lines); acc = np.zeros((8, D), dtype=np.int64)
    for m, j, r in lines:
        mask = np.ones(D, dtype=bool); J = np.zeros(D, dtype=np.int64)
        for t in range(n):
            mask &= m[cols[t]]; J += j[cols[t]] if t < p else -j[cols[t]]
        np.add.at(acc, ((J % 8)[mask], np.nonzero(mask)[0]), 2 ** ((rmax - r) * n // 2) if n % 2 == 0 else 0)
    E = np.zeros((4, D), dtype=np.int64)
    for k in range(8): E[k % 4] += acc[k] if k < 4 else -acc[k]
    return E, rmax * n // 2
def E_full(p, q, g, use_h=True):
    """E_g from the orbit of delta_0 on all of (labels)^g: exact integer vectors over 2^e"""
    n = p + q; N = 1 << n; D = N ** g; w = wstd(p, q); one = N - 1; idx = np.arange(D, dtype=np.int64); par = parity(n)
    co = [(idx >> (n * j)) & (N - 1) for j in range(g)]
    def enc(cs): return sum(c << (n * j) for j, c in enumerate(cs))
    ops = []
    for j in range(g):
        ops.append(('perm', enc([c ^ one if k == j else c for k, c in enumerate(co)])))
        ops.append(('sign', 1 - 2 * par[co[j]])); ops.append(('phase', w[co[j]]))
        if use_h: ops.append(('had', j))
    for i in range(g):
        for j in range(g):
            if i < j: ops.append(('sign', 1 - 2 * par[co[i] & co[j]]))
            if i != j: ops.append(('perm', enc([c ^ co[j] if k == i else c for k, c in enumerate(co)])))
    def canon(e, re, im):
        nz = int(np.bitwise_or.reduce(np.abs(np.concatenate([re, im]))))
        while e > 0 and nz and nz % 2 == 0: re = re // 2; im = im // 2; nz //= 2; e -= 1
        return e, re, im
    def apply(op, v):
        e, re, im = v; kind, d = op
        if kind == 'perm': return canon(e, re[d], im[d])
        if kind == 'sign': return canon(e, re * d, im * d)
        if kind == 'phase':
            return canon(e, np.where(d == 0, re, np.where(d == 1, -im, np.where(d == 2, -re, im))), np.where(d == 0, im, np.where(d == 1, re, np.where(d == 2, -im, -re))))
        sh = (N,) * g
        return canon(e + n // 2, walsh_axis(re.reshape(sh), g - 1 - d).reshape(D), walsh_axis(im.reshape(sh), g - 1 - d).reshape(D))
    re0 = np.zeros(D, dtype=np.int64); re0[0] = 1; v0 = (0, re0, np.zeros(D, dtype=np.int64))
    key = lambda v: (v[0], v[1].tobytes(), v[2].tobytes())
    seen = {key(v0): v0}; fr = [v0]
    while fr:
        nx = []
        for v in fr:
            for op in ops:
                u = apply(op, v); kk = key(u)
                if kk not in seen: seen[kk] = u; nx.append(u)
        fr = nx
    emax = max(v[0] for v in seen.values()); Er = np.zeros(D, dtype=np.int64); Ei = np.zeros(D, dtype=np.int64)
    for e, re, im in seen.values(): Er += re * 2 ** (emax - e); Ei += im * 2 ** (emax - e)
    return Er, Ei, emax, len(seen)
CODES = {}
def selfdual(n):
    """the self-dual binary codes of length n, grown from {0, 1} in the even words (as in weil_siegel.py)"""
    if n in CODES: return CODES[n]
    one = (1 << n) - 1; ev = [v for v in range(1, 1 << n) if pc(v) % 2 == 0 and v != one]
    level = {frozenset([0, one]): (one,)}
    while len(next(iter(level))) ** 2 < 1 << n:
        nxt = {}
        for c, basis in level.items():
            for v in ev:
                if v in c or any(pc(v & b) & 1 for b in basis): continue
                d = frozenset(c | {x ^ v for x in c})
                if d not in nxt: nxt[d] = basis + (v,)
        level = nxt
    CODES[n] = sorted(level, key=sorted); return CODES[n]
def genus_count(p, q, g):
    """the number of codes of the genus (form from the kernel) holding each g-tuple, and the number of codes"""
    n = p + q; w = wtable(p, q)
    C = [c for c in selfdual(n) if all(w[a] == 0 for a in c)]
    cnt = np.zeros((1 << n) ** g, dtype=np.int64)
    for c in C:
        cl = np.array(sorted(c), dtype=np.int64); I = np.zeros(1, dtype=np.int64)
        for j in range(g): I = (I[:, None] + (cl[None, :] << (n * j))).reshape(-1)
        cnt[I] += 1
    return cnt, len(C)
def rank_array(p, q, g):
    """for each point of (labels)^g its rank r on the support of Theta_g (the std form), -1 elsewhere; and the count of each rank"""
    n = p + q; N = 1 << n; S = support(wstd(p, q), n, g); R = np.full(N ** g, -1, dtype=np.int64)
    for x in S.tolist(): R[x] = rank_mod1([(x >> (n * j)) & (N - 1) for j in range(g)], n)
    return R
def agrees(vals, den_all, R, c):
    """vals / den_all == Theta_g (values c_r on rank r, 0 off the support), exactly"""
    if np.any(vals[R < 0] != 0): return False
    for r in range(len(c)):
        msk = R == r
        if np.any(vals[msk] * c[r].denominator != den_all * c[r].numerator): return False
    return not np.any(R >= len(c))

same_form = all(np.array_equal(wtable(p, n - p), wstd(p, n - p)) for n in range(1, 13) for p in range(n + 1))
ORBS = {g: site_orbit(g, FAULT != 'NOH') for g in (1, 2, 3)}
LINES = {g: lines_of(ORBS[g]) for g in (1, 2, 3)}
sw = True; srep = []; fullrep = []; ham = None
for (p, q, g, full) in [(1, 1, 2, True), (2, 2, 2, True), (3, 3, 2, True), (8, 0, 2, True), (4, 4, 2, True), (0, 8, 2, True),
                        (9, 1, 2, False), (5, 5, 2, False), (1, 9, 2, False), (1, 1, 3, True), (2, 2, 3, True), (3, 3, 3, False)]:
    n = p + q; E, ex = E_site(p, q, g, LINES[g]); R = rank_array(p, q, g); c = ccoef(n, g)
    real = not E[1].any() and not E[2].any() and not E[3].any()
    e0 = Fr(int(E[0][0]), 2 ** ex)
    prod_ = Fr(1)
    for i in range(g): prod_ *= 1 + Fr(2) ** (2 + i) / Fr(2) ** (n // 2)
    cnt, nc = genus_count(p, q, g)
    norm2 = Fr(int((cnt.astype(object) ** 2).sum()), nc ** 2)
    ok = real and e0 != 0 and agrees(E[0], int(E[0][0]), R, c) and agrees(cnt, nc, R, c) and e0 == prod_ and e0 == Fr(len(LINES[g])) / norm2
    if full:
        Er, Ei, emax, no = E_full(p, q, g, FAULT != 'NOH')
        ok = ok and not Ei.any() and np.array_equal(Er * 2 ** ex, E[0] * 2 ** emax) and no == len(LINES[g])
        fullrep.append('(%d,%d) g = %d' % (p, q, g))
    if not ok: sw = False
    srep.append('(%d,%d) g = %d: %d code%s, E(delta_0) = %s' % (p, q, g, nc, '' if nc == 1 else 's', e0))
    if (p, q, g) == (8, 0, 2):
        mon = {}
        for x in np.nonzero(cnt)[0].tolist():
            xi1, xi2 = x & 255, x >> 8; ex4 = [0, 0, 0, 0]
            for t in range(8): ex4[((xi1 >> t) & 1) * 2 + ((xi2 >> t) & 1)] += 1
            mon[tuple(ex4)] = mon.get(tuple(ex4), 0) + int(cnt[x])
        ham = sorted(((v // nc if v % nc == 0 else Fr(v, nc), k) for k, v in mon.items()), key=lambda t: tuple(-x for x in t[1]))
def monomial(cf, e4):
    names = ('x00', 'x01', 'x10', 'x11')
    s = ' '.join('%s^%d' % (names[i], e4[i]) for i in range(4) if e4[i])
    return ('%s ' % cf if cf != 1 else '') + s
hamtxt = ' + '.join(monomial(cf, e4) for cf, e4 in ham) if ham else 'none'
GHAM = (0b11110000, 0b00111100, 0b00001111, 0b01010101)                       # a generator matrix of the extended Hamming code [8, 4, 4]
HCODE = sorted({apply_cols(GHAM, c) for c in range(16)})
hmon = {}
for c1 in HCODE:
    for c2 in HCODE:
        ex4 = [0, 0, 0, 0]
        for t in range(8): ex4[((c1 >> t) & 1) * 2 + ((c2 >> t) & 1)] += 1
        hmon[tuple(ex4)] = hmon.get(tuple(ex4), 0) + 1
hcheck = len(HCODE) == 16 and all(pc(c) % 4 == 0 for c in HCODE) and all(pc(a & b) % 2 == 0 for a in HCODE for b in HCODE)
hamok = ham is not None and hcheck and {k: v for v, k in ham} == hmon
chk('bit==std', same_form and sw and hamok, 'wg.SW: the finite Siegel-Weil formula in genus 2 and 3: the kernel\'s form is the standard one on every label of the cells with n <= 12; the average A_g over the genus (the codes on which the kernel\'s form is 1) equals Theta_g and equals the sum E_g of the orbit of delta_0 divided by its value at delta_0, exactly, as functions on (labels)^g, for g = 2 in the 9 cells with p = q mod 8 and n <= 10 and g = 3 in (1,1), (2,2), (3,3) (%s); E_g computed through one generator (Weil\'s operators factor over the n generators: the gate on those of square +1, its conjugate on the others; the orbit of one generator exact in Z[zeta][1/2]) and, the same sum and orbit size, on all of (labels)^g for %s; E_g(delta_0) = Prod_(i<g) (1 + 2^(2+i-n/2)) = |orbit| / |A_g|^2 (the orbit has %d lines for g = 2, %d for g = 3, one vector on each where computed on all of (labels)^g); for (8,0) the average of genus 2 is %s, the genus-2 complete weight enumerator, computed term by term, of the extended Hamming code given by the generator matrix 11110000, 00111100, 00001111, 01010101 (16 words, doubly even, self-dual)' % ('; '.join(srep), ', '.join(fullrep), len(LINES[2]), len(LINES[3]), hamtxt))

def gbin(g, r):
    num = 1; den = 1
    for i in range(r): num *= 2 ** (g - i) - 1; den *= 2 ** (i + 1) - 1
    return num // den
stab = True; strep = []
for g in (1, 2, 3):
    L = LINES[g]; byr = {}
    for m, j, r in L:
        if m[0]: byr[r] = byr.get(r, 0) + 1
    want = {r: gbin(g, r) * 2 ** (r * (r + 3) // 2) for r in range(g + 1)}
    tot = 2 ** g
    for i in range(1, g + 1): tot *= 2 ** i + 1
    if byr != want or len(L) != tot: stab = False
    strep.append('g = %d: %d lines, %s' % (g, len(L), ', '.join('%d of dimension %d' % (byr.get(r, 0), r) for r in range(g + 1))))
cauchy = all(sum(Fr(gbin(g, r) * 2 ** (r * (r + 3) // 2), 2 ** (r * n // 2)) for r in range(g + 1)) == np.prod([1 + Fr(2 ** (2 + i), 2 ** (n // 2)) for i in range(g)])
             for g in range(1, 13) for n in range(2, 41, 2))
chk('std', stab and cauchy, 'wg.SW: the constant: the orbit of delta_0 has one line for each stabilizer state of g qubits, 2^g Prod_(i=1..g) (2^i + 1) of them, and those meeting delta_0 with a support of dimension r number [g r]_2 2^(r(r+3)/2) (%s), each worth 2^(-rn/2) at delta_0; Sum_r [g r]_2 2^(r(r+3)/2) 2^(-rn/2) = Prod_(i<g) (1 + 2^(2+i-n/2)), the Cauchy binomial theorem with t = 2^(2-n/2), exact for g <= 12 and n <= 40: the constant E_g(delta_0) in every genus, the form of the stabilizer states recalled' % '; '.join(strep))

# ================================================================================================ controls, computed in place without the fault
head('controls: S, the second qubit of b, the commutator of the certificate, the Fourier transform, the transvections')
noS = []; noS_form = True
for m in (2, 3, 4):
    o = orbit(1, [f for _, _, f in sp_gens(m, False)]); noS.append(len(o))
    if o != {v for v in range(1, 1 << (2 * m)) if pc((v & ((1 << m) - 1)) & (v >> m)) % 2 == 0}: noS_form = False
b1 = on(2, 0, ZH); A0 = gprod(cnot(2, 1, 0), on(2, 1, ZH), cnot(2, 0, 1), on(2, 1, S1), on(2, 1, S1), on(2, 1, ZH))
c1 = gscalar(gprod(A0, b1, gdag(A0), gdag(b1)))
chk('ctl', noS == [9, 35, 135] and noS_form and c1 is None, 'wg.CLASS: without S the images of zeta H and CNOT move x_0 to %s of the 15, 63, 255 non-zero vectors (m = 2, 3, 4), exactly those with x.z = 0, the form the real Clifford group keeps, so they do not lie over B0 (NOS); with b = zeta H (x) 1 the commutator a b a^-1 b^-1 is not a scalar (ONEQ)' % ', '.join(map(str, noS)))
P0 = gprod(on(2, 0, ZH), on(2, 1, ZH), on(2, 0, S1), on(2, 0, ZH))
cPP = gscalar(gprod(P0, P0, gdag(P0), gdag(P0)))
chk('ctl', cPP == (0, (1, 0)), 'wg.REL40: with B = P the commutator is 1, and the four relations give chi(PPX) = chi(P)^2 chi(X) both ways: no condition on n (SAMEPB)')
w44 = wstd(4, 4)
d_noh, l_noh, _, _ = fixed_space(4, 4, 1, w44, use_tv=True, use_h=False)
d_notv, l_notv, _, _ = fixed_space(4, 4, 1, w44, use_tv=False, use_h=True)
d_notv2, _, _, _ = fixed_space(2, 2, 2, wstd(2, 2), use_tv=False, use_h=True)
chk('ctl', d_noh > 1 and d_notv > 1 and d_notv2 > 1, 'wg.LINE: without the Fourier transform the functions fixed in (4,4), g = 1, are those constant on the %d live orbits, a space of dimension %d (NOH); without the transvections the functions fixed by D_1 alone in (4,4) form a space of dimension %d, and by D_2 alone in (2,2) one of dimension %d: Weil\'s operators alone fix more than a line, the transvections cut it down (NOTV)' % (l_noh, d_noh, d_notv, d_notv2))
finish()
