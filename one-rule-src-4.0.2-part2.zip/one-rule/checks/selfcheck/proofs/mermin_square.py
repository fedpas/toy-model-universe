#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""MERMIN-SQUARE.  The Peres-Mermin square of Cl(2,2) (CAND-144, LNC-059) as Mermin's two-qubit operators.   python3 mermin_square.py [--fault GEN|SIGN]
 With the real 4 x 4 representation e1 = X(x)1, e2 = Z(x)1 (square +1), e3 = iY(x)X, e4 = iY(x)Z (square -1), qubit 0 the left tensor factor:
 B1 the nine blades of square +1 are, up to sign, Mermin's nine operators XI, IX, XX, IZ, ZI, ZZ, XZ, ZX, YY;
 B2 the six commuting lines of blades (triples a, b, a^b) are Mermin's three rows and three columns;
 B3 the product of the six line products is -1 (the obstruction of (6.1)).
 The blade products follow the sign rule (e_a e_c = s e_(a^c), s from reordering and the squares); the representation is checked to satisfy
 Cl(2,2) before use (B0).
 Controls (--fault puts each into its check, exit 1): GEN e3 = X(x)X, which squares to +1 (not Cl(2,2)); SIGN the claim that the six line
 products multiply to +1."""
import sys, itertools, numpy as np
FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
ok = []
def chk(name, cond, msg):
    ok.append(cond); print(('ok  ' if cond else 'FAIL') + f' {name}: {msg}')
# blades: label a = bitmask over n generators; e_i^2 = +1 for i < p, -1 for i >= p
def mul(a, c, p, n):
    """e_a e_c = s e_(a^c)"""
    s = 1
    for i in range(n):                                   # move each generator of c leftwards past the higher generators of a
        if c >> i & 1:
            s *= (-1) ** bin(a >> (i + 1)).count('1')
    for i in range(n):
        if (a & c) >> i & 1: s *= 1 if i < p else -1
    return s, a ^ c
def sq(a, p, n): return mul(a, a, p, n)[0]

# B. Peres-Mermin
X = np.array([[0, 1], [1, 0]]); Z = np.diag([1, -1]); I2 = np.eye(2); iY = np.array([[0, 1], [-1, 0]]); Y = np.array([[0, -1j], [1j, 0]])
gen = [np.kron(X, I2), np.kron(Z, I2), np.kron(X, X) if FAULT == 'GEN' else np.kron(iY, X), np.kron(iY, Z)]          # Cl(2,2): e1, e2 square +1; e3, e4 square -1; real 4x4
chk('B0', all(np.allclose(A @ B + B @ A, 2 * (i == j) * (1 if i < 2 else -1) * np.eye(4)) for i, A in enumerate(gen) for j, B in enumerate(gen)),
    'the four real 4 x 4 matrices satisfy e_i e_j + e_j e_i = 2 eta_ij with eta = (+1, +1, -1, -1): a representation of Cl(2,2)')
def rho(a):
    M = np.eye(4)
    for i in range(4):
        if a >> i & 1: M = M @ gen[i]
    return M
pauli = {'I': I2, 'X': X, 'Y': Y, 'Z': Z}
strings = {s + t: np.kron(pauli[s], pauli[t]) for s in 'IXYZ' for t in 'IXYZ'}
nine = [a for a in range(1, 16) if sq(a, 2, 4) == 1]
name = {}
for a in nine:
    hit = [(k, sgn) for k, P in strings.items() for sgn in (1, -1) if np.allclose(rho(a), sgn * P)]
    name[a] = hit[0] if len(hit) == 1 else None
lab = lambda a: 'e' + ''.join(str(i + 1) for i in range(4) if a >> i & 1)
if all(name[a] for a in nine): print('     the nine blades:', ', '.join(f'{lab(a)} = {"-" if name[a][1] < 0 else ""}{name[a][0]}' for a in nine))
mermin = ['XI', 'IX', 'XX', 'IZ', 'ZI', 'ZZ', 'XZ', 'ZX', 'YY']
chk('B1', all(name[a] for a in nine) and sorted(name[a][0] for a in nine) == sorted(mermin), "the nine blades are, up to sign, Mermin's nine two-qubit operators")
lines = [t for t in itertools.combinations(nine, 3) if t[0] ^ t[1] ^ t[2] == 0 and all(mul(x, y, 2, 4)[0] == mul(y, x, 2, 4)[0] for x, y in itertools.combinations(t, 2))]
mlines = [{'XI', 'IX', 'XX'}, {'IZ', 'ZI', 'ZZ'}, {'XZ', 'ZX', 'YY'}, {'XI', 'IZ', 'XZ'}, {'IX', 'ZI', 'ZX'}, {'XX', 'ZZ', 'YY'}]
got = [{name[a][0] for a in t} for t in lines] if all(name[a] for a in nine) else []
chk('B2', len(lines) == 6 and all(l in got for l in mlines), "the six commuting lines of blades are Mermin's three rows and three columns")
signs = []
for l in (mlines if all(name[a] for a in nine) else []):
    a, b, c = [next(x for x in nine if name[x][0] == s) for s in l]
    P = rho(a) @ rho(b) @ rho(c); signs.append(int(round(P[0, 0])) if np.allclose(P, P[0, 0] * np.eye(4)) else None)
chk('B3', len(signs) == 6 and None not in signs and np.prod(signs) == (1 if FAULT == 'SIGN' else -1), f'line products of the blades {signs}: their product is -1, as in (6.1)')

print(f'{sum(ok)} of {len(ok)} checks hold')
raise SystemExit(0 if all(ok) else 1)
