#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""twistor_flat.py: flat twistor theory on the labels, read with M. Atiyah, M. Dunajski, L. J. Mason, Twistor theory at fifty: from contour
integrals to twistor strings (Proc. R. Soc. A 473 (2017) 20170530, a review; read in full): twistor space as the spinor module of the
conformal cell (4,2) and the Klein correspondence; the incidence relation, the light rays and the Robinson congruence; Penrose's integral
formulae for the massless fields; the Lax pairs of the anti-self-dual Yang-Mills and Nahm equations (round 18, pass 14a;
docs/round18/PROOFS_ROUND14A.md).
python3 twistor_flat.py [--fault CELL|NOI|NULLW|DEG|EUC|SDLAX|NAHM]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators of
square +1 first (core_check.sig); core_check.signature_of diagonalises a symmetric rational matrix exactly. Source (the review, by section and
page): section 2 (p. 4-6): the incidence relation (2.5), (Z0, Z1) = (i/sqrt2) [[ct + z, x + iy], [x - iy, ct - z]] (Z2, Z3); two points on
one twistor are joined by a null line; the Hermitian form Sigma(Z, Zbar) = Z0 Z2bar + Z1 Z3bar + Z2 Z0bar + Z3 Z1bar of signature (++--), kept
by SU(2,2), locally SO(4,2); PN = {Sigma = 0}, the light rays; the Robinson congruence of a non-null twistor; the elementary state
(P.Z)^-1 (Q.Z)^-1, a fundamental solution of the wave equation, with lam = Z3/Z2 as in Bateman's formula (1.1); the self-dual 2-forms
Lambda^2_+ = S'* (.) S'* (2.1)-(2.3); section 5 (p. 12-13): the anti-self-dual Yang-Mills equations *F = -F (5.1) and the Lax pair (5.3),
L = D_z~ - lam D_w, M = D_w~ - lam D_z, [L, M] = F_z~w~ - lam (F_ww~ - F_zz~) + lam^2 F_wz, in coordinates with g = 2(dz dz~ - dw dw~), the
orientation vol = dw dw~ dz dz~ and the Euclidean reality z~ = zbar, w~ = -wbar; section 6 (p. 16): Nahm's equations Phi1' = [Phi2, Phi3] and cyclic, B(lam) = (Phi1 + i Phi2) +
2 Phi3 lam - (Phi1 - i Phi2) lam^2, B' = [B, C], C = -i Phi3 + i(Phi1 - i Phi2) lam. Rows of the Atlas: ATL-014 (Cl(4,2), the conformal
cell), CAND-025 (so(4,2) = su(2,2), eta = diag(1, 1, -1, -1)), ATY-030 (the Klein correspondence over F2 in Cl(3,3)), CAND-124 (the BPST
instanton, self-dual, F = -4 eta rho^2/(x^2 + rho^2)^2 with the 't Hooft symbols of gravity/ym_solutions.py), CAND-139 (the conformal
invariance of the massless equations). Recalled, not read: Cauchy's residue theorem; the Plucker relation (a bivector of C^4 is
decomposable exactly when b ^ b = 0); the Klein quadric as complexified compactified Minkowski space.
Conventions: Gaussian rationals exact; a jet c0 + c1 e + c2 e^2 (e^3 = 0) gives exact first and second derivatives of a rational function at
a rational point; the factor 1/sqrt2 of (2.5) is scaled away (Z = (i X pi, pi)), which changes neither the lines nor the zeros of Sigma; on
a line pi = (1, lam); Penrose's formula phi_{A'..B'}(X) = Res pi_{A'}..pi_{B'} f(i X pi, pi) for f = (A.Z)^-1 (B.Z)^-(n+1), the residue at
the root of A.Z, X = X^{AA'} any complex 2 x 2 matrix (complexified Minkowski space; the row index unprimed).
tf.SPIN  [bit] twistor space from the labels of the cell (4,2): the volume element Omega has Omega^2 = -1 and is central in the even part;
         P = (1 + e1e5)(1 + e2e6)/4 is an idempotent and the left ideal of the even part through P has real dimension 8, a complex 4-space
         with J = Omega on which the even part acts as all of End_C(C^4) (rank 32); the 15 bivectors act on it faithfully, commuting with J,
         with complex trace 0; the real symmetric forms compatible with J and kept by them form one line, of signature (4, 4): a Hermitian
         form of signature (2, 2), so the bivectors fill su(2,2); the intertwiners from Lambda^2 of the ideal (over C) to the
         vector of so(4,2) (the bivectors acting on the six generators) form one line, invertible, carrying the quadratic form of the six
         generators to a non-zero multiple of the wedge pairing (its value depends on the normalisation of the intertwiner): decomposable bivectors (lines of PT) are null vectors, the Klein correspondence.
         [bit==std] the review's Sigma and CAND-025's eta have signature (2, 2) too.
tf.INC   [std] the incidence relation (2.5), exact over Q(i): the lines of two complex points meet exactly when their separation is null
         (300 pairs: the 150 null ones meet, the 150 others are skew); a twistor with pi != 0 is met by a real point exactly when it is null (a Hermitian X with X pi = -i omega
         needs pi-dagger omega imaginary, built when it is), and then by the light ray x + s k, k from u u-dagger with u-dagger pi = 0.
         [std] the Robinson congruence of a non-null twistor W: through every real point x passes exactly one light ray Z with Sigma(Z, W) = 0
         (the condition on pi is linear and vanishes identically at no real point, since that needs Sigma(W, W) = 0), so no two rays meet;
         Sigma(Z1, Z2) != 0 for every pair of the 24 rays computed (3 twistors W, 8 points each).
tf.PEN   [std] Penrose's integral formulae as exact residues: the elementary state 1/((A.Z)(B.Z)) gives 1/(det[[A0, A1], [B0, B1]] det(X - X0))
         for the point X0 whose line is A.Z = B.Z = 0, a solution of the wave equation; for n = 0..4 the fields of f = (A.Z)^-1 (B.Z)^-(n+1) are the same on the two
         charts of the line (pi = (1, lam), pi.dpi = dlam; pi = (mu, 1), pi.dpi = -dmu), and for n >= 1 they solve the zero-rest-mass
         equations eps^{A'C'} d phi_{A'B'..}/dX^{AC'} = 0 at random complex points (on one chart the equations hold for any integrand, since
         d/dX^{AA'} acts as i pi_{A'} d/domega^A; for homogeneity d the two charts differ by the factor lam0^-(n+d+2), lam0 the root of A.Z,
         so the homogeneity -n-2 makes the field independent of the chart). [bit==std] for n = 2 the
         2-form F = phi_{A'B'} eps_{AB} is closed and an eigenform of the star, *F = i F with the star of the epsilon tensor; the star by the
         bit rule of Cl(1,3) (the bivector times the pseudoscalar of the kernel) equals that star on all six basis 2-forms.
tf.LAX   [std] the review's Lax pair: with its reality z~ = zbar, w~ = -wbar and the Atlas's choice z = x1 + i x2, w = x3 + i x4, the three
         coefficients of [L, M] vanish on the anti-self-dual 't Hooft
         tensors eta-bar and form a non-singular matrix on the self-dual eta, the review's orientation dw dw~ dz dz~ being 4 d^4x: their
         common zeros are the anti-self-dual 2-forms (CAND-124's instanton is self-dual, its mirror image, the anti-instanton, a solution: an
         instanton in the review's sense, anti-self-dual);
         Nahm's Lax pair: with Phi_i' from Nahm's equations, B' = [B, C] identically in lam for random matrices (sizes 2, 3, 4, exact
         Gaussian integers).
Controls ([ctl], computed without the fault) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   CELL the cell (3,3) in place of (4,2); NOI the incidence without the factor i; NULLW the congruence of a null twistor; DEG the elementary
   state of homogeneity -3; EUC the star with the indices raised by the identity; SDLAX the Lax test on the self-dual tensors; NAHM a sign of
   B(lam) changed.
Not computed here: the nonlinear graviton (Theorems 3.1-3.3), the Ward correspondence for bundles (Theorem 5.1) beyond the Lax pair, the
integrable reductions other than Nahm's, the twistor strings and the amplitudes, the Newtonian limit.
Command: python3 -I -B selfcheck/proofs/twistor_flat.py from checks/ (or from this folder); standard library only."""
import os, sys, itertools, random
from math import comb
from fractions import Fraction as Fr

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here); _checks = os.path.dirname(_selfcheck); _researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import sig as _core_sig, signature_of

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish():
    print('\n  tags: %s' % ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)))
    print('twistor_flat: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('CELL', 'NOI', 'NULLW', 'DEG', 'EUC', 'SDLAX', 'NAHM')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
if FAULT: print('FAULT %s: the main lines below use the wrong version and must fail' % FAULT)

# ================================================================================================ exact numbers: Gaussian rationals and jets
class Q:
    """a + b i, a and b rational"""
    __slots__ = ('a', 'b')
    def __init__(s, a=0, b=0): s.a = Fr(a); s.b = Fr(b)
    def __add__(s, o):
        if isinstance(o, Jet): return NotImplemented
        o = o if isinstance(o, Q) else Q(o); return Q(s.a + o.a, s.b + o.b)
    __radd__ = __add__
    def __sub__(s, o):
        if isinstance(o, Jet): return NotImplemented
        o = o if isinstance(o, Q) else Q(o); return Q(s.a - o.a, s.b - o.b)
    def __rsub__(s, o): return Q(o) - s
    def __mul__(s, o):
        if isinstance(o, Jet): return NotImplemented
        o = o if isinstance(o, Q) else Q(o); return Q(s.a * o.a - s.b * o.b, s.a * o.b + s.b * o.a)
    __rmul__ = __mul__
    def __neg__(s): return Q(-s.a, -s.b)
    def conj(s): return Q(s.a, -s.b)
    def __truediv__(s, o):
        if isinstance(o, Jet): return NotImplemented
        o = o if isinstance(o, Q) else Q(o); d = o.a * o.a + o.b * o.b
        return Q((s.a * o.a + s.b * o.b) / d, (s.b * o.a - s.a * o.b) / d)
    def __rtruediv__(s, o): return Q(o) / s
    def __eq__(s, o):
        if isinstance(o, Jet): return NotImplemented
        o = o if isinstance(o, Q) else Q(o); return s.a == o.a and s.b == o.b
    def __hash__(s): return hash((s.a, s.b))
    def iszero(s): return s.a == 0 and s.b == 0
I = Q(0, 1); ZERO = Q(0); ONE = Q(1)
class Jet:
    """c0 + c1 e + c2 e^2 with e^3 = 0: a rational function's value and first two derivatives along one direction"""
    N = 2
    def __init__(s, c): s.c = (list(c) + [ZERO] * (Jet.N + 1))[:Jet.N + 1]
    @staticmethod
    def lift(v): return v if isinstance(v, Jet) else Jet([v if isinstance(v, Q) else Q(v)])
    def __add__(s, o): o = Jet.lift(o); return Jet([a + b for a, b in zip(s.c, o.c)])
    __radd__ = __add__
    def __sub__(s, o): o = Jet.lift(o); return Jet([a - b for a, b in zip(s.c, o.c)])
    def __rsub__(s, o): return Jet.lift(o) - s
    def __neg__(s): return Jet([-a for a in s.c])
    def __mul__(s, o):
        o = Jet.lift(o); r = [ZERO] * (Jet.N + 1)
        for i, a in enumerate(s.c):
            if a.iszero(): continue
            for j in range(Jet.N + 1 - i): r[i + j] = r[i + j] + a * o.c[j]
        return Jet(r)
    __rmul__ = __mul__
    def inv(s):
        a0 = s.c[0]; r = [ONE / a0]
        for k in range(1, Jet.N + 1):
            acc = ZERO
            for j in range(1, k + 1): acc = acc + s.c[j] * r[k - j]
            r.append(-acc / a0)
        return Jet(r)
    def __truediv__(s, o): return s * Jet.lift(o).inv()
    def __rtruediv__(s, o): return Jet.lift(o) * s.inv()
def pw(v, e):
    r = ONE
    for _ in range(e): r = v * r
    return r
def residue(num, pole, m, others):
    """the residue at the root of the linear pole p0 + p1 lam (order m) of num(lam) / (p0 + p1 lam)^m / prod (q0 + q1 lam)^k, exact"""
    p0, p1 = pole; l0 = -p0 / p1
    g = [ZERO] * m                                                         # num(l0 + u) to order m - 1
    for k, ck in enumerate(num):
        for j in range(min(k, m - 1) + 1): g[j] = g[j] + ck * comb(k, j) * pw(l0, k - j)
    for (q0, q1), k in others:
        c0 = q0 + q1 * l0; inv = [ONE / c0]                                 # 1/(c0 + q1 u)
        for j in range(1, m): inv.append(-(q1 * inv[-1]) / c0)
        for _ in range(k):
            g = [sum((g[j] * inv[i - j] for j in range(i + 1)), ZERO) for i in range(m)]
    return g[m - 1] / pw(p1, m)
def rrefQ(rows, ncol):
    """reduced row echelon form over Q(i) (entries Q); returns (rows, pivots)"""
    M = [list(r) for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p = next((i for i in range(rk, len(M)) if not M[i][c].iszero()), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; iv = ONE / M[rk][c]; M[rk] = [x * iv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and not M[i][c].iszero():
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    return M[:rk], piv
def nullspaceQ(rows, ncol):
    R, pv = rrefQ(rows, ncol); out = []
    for fc in [c for c in range(ncol) if c not in pv]:
        u = [ZERO] * ncol; u[fc] = ONE
        for i, c in enumerate(pv): u[c] = -R[i][fc]
        out.append(u)
    return out
rnd = random.Random(20261020)
def rq(k=4): return Fr(rnd.randint(-k, k), rnd.randint(1, 3))
def rc(): return Q(rq(), rq())

# ================================================================================================ tf.SPIN
head('tf.SPIN: twistor space from the labels of the conformal cell (4,2)')
CELL = (3, 3) if FAULT == 'CELL' else (4, 2)
A6 = BR(list(_core_sig(CELL[0], CELL[1], 0))); NG = 6
def pc(x): return bin(x).count('1')
EVEN = [m for m in range(1 << NG) if pc(m) % 2 == 0]
OM = {(1 << NG) - 1: 1}
om2 = A6.mul(OM, OM)
central = all(A6.mul(OM, {m: 1}) == A6.mul({m: 1}, OM) for m in EVEN)
a_ = {(1 << 0) | (1 << 4): 1}; b_ = {(1 << 1) | (1 << 5): 1}
PI = A6.scal(A6.mul(A6.add({0: 1}, a_), A6.add({0: 1}, b_)), Fr(1, 4))
idem = A6.mul(PI, PI) == PI
def rref(rows, ncol):
    """exact reduced row echelon form of rational rows; returns (basis rows, pivot columns)"""
    M = [list(r) for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; iv = 1 / M[rk][c]; M[rk] = [x * iv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    return M[:rk], piv
def tovec(x): return [Fr(x.get(m, 0)) for m in range(1 << NG)]
BASIS, PIV = rref([tovec(A6.mul({c: 1}, PI)) for c in EVEN], 1 << NG)
DIM = len(BASIS)
def coords(v):
    """the coordinates of a vector of the ideal in BASIS (reduced echelon: read at the pivots), checked"""
    co = [v[c] for c in PIV]
    back = [sum((co[i] * BASIS[i][k] for i in range(DIM)), Fr(0)) for k in range(1 << NG)]
    if back != v: raise SystemExit('a vector outside the ideal')
    return co
def act(x):
    """the matrix (columns: images of the basis) of left multiplication by x on the ideal"""
    cols = []
    for v in BASIS:
        y = {m: v[m] for m in range(1 << NG) if v[m] != 0}
        cols.append(coords(tovec(A6.mul(x, y))))
    return [[cols[j][i] for j in range(DIM)] for i in range(DIM)]
def mm(Am, Bm): return [[sum((Am[i][k] * Bm[k][j] for k in range(len(Bm))), Fr(0)) for j in range(len(Bm[0]))] for i in range(len(Am))]
def tr(Am): return [list(r) for r in zip(*Am)]
def mat_add(Am, Bm, c=1): return [[a + c * b for a, b in zip(r1, r2)] for r1, r2 in zip(Am, Bm)]
J = act(OM)
BIV = [{(1 << i) | (1 << j): 1} for i, j in itertools.combinations(range(NG), 2)]
G = [act(x) for x in BIV]
commJ = all(mm(g, J) == mm(J, g) for g in G)
faithful = len(rref([[x for row in g for x in row] for g in G], DIM * DIM)[0]) == 15
even_rank = len(rref([[x for row in act({m: 1}) for x in row] for m in EVEN], DIM * DIM)[0])   # 32: the even part acts as all of End_C(C^4)
# the invariant J-compatible real symmetric forms: S symmetric, S g + g^T S = 0 (all bivectors), J^T S J = S
IDX = [(i, j) for i in range(DIM) for j in range(i, DIM)]
def symm(u):
    S = [[Fr(0)] * DIM for _ in range(DIM)]
    for k, (i, j) in enumerate(IDX): S[i][j] = S[j][i] = u[k]
    return S
BS = [symm([Fr(1) if k == t else Fr(0) for k in range(len(IDX))]) for t in range(len(IDX))]
eqs = []
for g in G:
    cols = [[x for row in mat_add(mm(Sk, g), mm(tr(g), Sk)) for x in row] for Sk in BS]
    eqs += [list(r) for r in zip(*cols)]
cols = [[x for row in mat_add(mm(mm(tr(J), Sk), J), Sk, -1) for x in row] for Sk in BS]
eqs += [list(r) for r in zip(*cols)]
R_, pv_ = rref(eqs, len(IDX))
forms = []
for fc in [c for c in range(len(IDX)) if c not in pv_]:
    u = [Fr(0)] * len(IDX); u[fc] = Fr(1)
    for i, c in enumerate(pv_): u[c] = -R_[i][fc]
    forms.append(symm(u))
sgn_bit = signature_of(forms[0]) if len(forms) == 1 else None
complex_ok = om2 == {0: -1} and DIM == 8 and commJ                          # J a complex structure commuting with the bivectors
# the complex structure: a complex basis v_1..v_4 of the ideal (v_k, J v_k independent over R)
def Jv(e): return [sum((J[i][k] * e[k] for k in range(DIM)), Fr(0)) for i in range(DIM)]
cb = []; real_span = []
for k in range(DIM if complex_ok else 0):
    e = [Fr(1) if i == k else Fr(0) for i in range(DIM)]
    if len(rref(real_span + [e, Jv(e)], DIM)[0]) == len(real_span) + 2:
        real_span += [e, Jv(e)]; cb.append(e)
    if len(cb) == DIM // 2: break
CBM = [list(r) for r in zip(*[x for e in cb for x in (e, Jv(e))])]           # columns v_1, J v_1, v_2, J v_2, ...
def solve(Mc, b):
    n = len(Mc); R2, pv2 = rref([list(Mc[i]) + [b[i]] for i in range(n)], n + 1)
    x = [Fr(0)] * n
    for i, c in enumerate(pv2):
        if c == n: raise SystemExit('no solution')
        x[c] = R2[i][n]
    return x
def to_complex(g):
    """g on the complex basis: g v_k = sum (a + i b) v_j where (a, b) are the real coordinates of g v_k in (v_j, J v_j)"""
    out = [[ZERO] * (DIM // 2) for _ in range(DIM // 2)]
    for k, e in enumerate(cb):
        sol = solve(CBM, [sum((g[i][t] * e[t] for t in range(DIM)), Fr(0)) for i in range(DIM)])
        for j in range(DIM // 2): out[j][k] = Q(sol[2 * j], sol[2 * j + 1])
    return out
PAIRS = list(itertools.combinations(range(DIM // 2), 2))
def wedge2(Mc):
    """the action of Mc on Lambda^2 C^4 in the basis e_i ^ e_j (i < j): M(e_k ^ e_l) = M e_k ^ e_l + e_k ^ M e_l"""
    n = len(PAIRS); out = [[ZERO] * n for _ in range(n)]
    for col, (k, l) in enumerate(PAIRS):
        for row, (i, j) in enumerate(PAIRS):
            v = ZERO
            if j == l: v = v + Mc[i][k]
            if i == l: v = v - Mc[j][k]
            if i == k: v = v + Mc[j][l]
            if j == k: v = v - Mc[i][l]
            out[row][col] = v
    return out
def vec_rep(x):
    """the bivector x acting on the six generators by the commutator, a rational 6 x 6 matrix"""
    out = [[ZERO] * NG for _ in range(NG)]
    for k in range(NG):
        c = A6.add(A6.mul(x, {1 << k: 1}), A6.mul({1 << k: 1}, x), -1)
        for m, v in c.items(): out[m.bit_length() - 1][k] = Q(v)
    return out
GC = [to_complex(g) for g in G] if complex_ok else []
tracefree = bool(GC) and all(sum((gc[i][i] for i in range(DIM // 2)), ZERO).iszero() for gc in GC)
W2 = [wedge2(gc) for gc in GC]; VR = [vec_rep(x) for x in BIV]
# intertwiners T: T W2(x) = VR(x) T for the 15 bivectors; unknown T[a][b] at position 6a + b
eqT = [[ONE] + [ZERO] * 35] if not complex_ok else []
for Wm, Vm in zip(W2, VR):
    for r, c in itertools.product(range(6), repeat=2):
        row = [ZERO] * 36
        for k in range(6):
            row[6 * r + k] = row[6 * r + k] + Wm[k][c]
            row[6 * k + c] = row[6 * k + c] - Vm[r][k]
        eqT.append(row)
NT = nullspaceQ(eqT, 36) if complex_ok else []
klein_ok = False; klein_c = None
if len(NT) == 1:
    T = [[NT[0][6 * a + b] for b in range(6)] for a in range(6)]
    invertible = len(rrefQ(T, 6)[0]) == 6
    ETA6 = [Q(s) for s in _core_sig(4, 2, 0)]
    TtT = [[sum((T[k][i] * ETA6[k] * T[k][j] for k in range(6)), ZERO) for j in range(6)] for i in range(6)]
    PLU = [[ZERO] * 6 for _ in range(6)]                                        # b ^ b' = PLU(b, b') e1234
    for (p1, s1), (p2, s2) in itertools.product(enumerate(PAIRS), repeat=2):
        if len(set(s1) | set(s2)) == 4:
            perm = list(s1) + list(s2); sg = 1
            for i in range(4):
                for j in range(i + 1, 4):
                    if perm[i] > perm[j]: sg = -sg
            PLU[p1][p2] = Q(sg)
    nz = [(i, j) for i in range(6) for j in range(6) if not PLU[i][j].iszero()]
    klein_c = TtT[nz[0][0]][nz[0][1]] / PLU[nz[0][0]][nz[0][1]]
    klein_ok = invertible and not klein_c.iszero() and all(TtT[i][j] == klein_c * PLU[i][j] for i in range(6) for j in range(6))
chk('bit', complex_ok and central and idem and faithful and even_rank == 32 and tracefree and len(forms) == 1 and sgn_bit == (4, 4, 0) and klein_ok,
    'tf.SPIN: twistor space from the labels of the cell %s (%s): the volume element Omega = e1..e6 has Omega^2 = %s and commutes with the 32 even labels; P = (1 + e1e5)(1 + e2e6)/4 is an idempotent, and the left ideal of the even part through P has real dimension %d, a complex 4-space with J = Omega, on which the 32 even labels act with rank %d, all of End_C(C^4) = M_4(C), so the ideal is the simple module of the even part; the 15 bivectors act on it faithfully (rank 15), commute with J and have complex trace 0; the real symmetric forms compatible with J and kept by every bivector form %d line, of signature %s: a Hermitian form of signature (2, 2) kept by so(4,2) (CAND-025: su(2,2)); the intertwiners from Lambda^2 of the ideal over C to the vector of so(4,2) (the bivectors acting on the six generators by the commutator) form %d line over Q(i), invertible, and carry the quadratic form of the generators (+1 x 4, -1 x 2) to a non-zero multiple of the wedge pairing of Lambda^2 C^4 (%s for the intertwiner computed: T -> sT multiplies it by s^2, a change of basis A of C^4 by det A): decomposable bivectors, the lines of PT, are null vectors, the Klein correspondence (ATY-030 over F2)' % ('(%d,%d)' % CELL, 'ATL-014: four generators of square +1, two of square -1' if CELL == (4, 2) else 'under the fault: three generators of square +1, three of square -1', '-1' if om2 == {0: -1} else om2, DIM, even_rank, len(forms), sgn_bit, len(NT), ('%s' % klein_c.a if klein_c.b == 0 else '(%s + %si)' % (klein_c.a, klein_c.b)) if klein_c is not None else 'no multiple'))
SIGMA = [[0, 0, 1, 0], [0, 0, 0, 1], [1, 0, 0, 0], [0, 1, 0, 0]]          # Sigma(Z, Zbar) = Z0 Z2bar + Z1 Z3bar + Z2 Z0bar + Z3 Z1bar, real symmetric
ETA25 = [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, -1, 0], [0, 0, 0, -1]]
chk('bit==std', sgn_bit == (4, 4, 0) and signature_of(SIGMA) == (2, 2, 0) and signature_of(ETA25) == (2, 2, 0),
    'tf.SPIN: the review\'s Sigma (p. 4-5) and CAND-025\'s eta = diag(1, 1, -1, -1) have signature (2, 2), as the form the labels give (real signature %s, each complex direction counted twice)' % (sgn_bit,))

# ================================================================================================ tf.INC
head('tf.INC: the incidence relation (2.5), the light rays and the Robinson congruence, exact over Q(i)')
IFAC = ONE if FAULT == 'NOI' else I
def Xm(x):
    t, x1, y, z = x
    return [[t + z, x1 + I * y], [x1 - I * y, t - z]]
def det2(M): return M[0][0] * M[1][1] - M[0][1] * M[1][0]
def interval(x): t, x1, y, z = x; return t * t - x1 * x1 - y * y - z * z
def mv(M, v): return [M[0][0] * v[0] + M[0][1] * v[1], M[1][0] * v[0] + M[1][1] * v[1]]
def twistor(x, pi, fac=None): return [(IFAC if fac is None else fac) * c for c in mv(Xm(x), pi)] + list(pi)
def Sig(Z, W): return Z[0] * W[2].conj() + Z[1] * W[3].conj() + Z[2] * W[0].conj() + Z[3] * W[1].conj()
def from_matrix(K):
    t = (K[0][0] + K[1][1]) / 2; z = (K[0][0] - K[1][1]) / 2; x1 = (K[0][1] + K[1][0]) / 2; y = (K[0][1] - K[1][0]) / (2 * I)
    return [t, x1, y, z]
def isreal(x): return all(c.b == 0 for c in x)
def hermitian_solution(u, y):
    """a Hermitian 2 x 2 matrix X with X u = y (u != 0), or None: it exists exactly when u-dagger y is real"""
    uy = u[0].conj() * y[0] + u[1].conj() * y[1]
    if uy.b != 0: return None
    n = u[0].conj() * u[0] + u[1].conj() * u[1]
    return [[(y[r] * u[c].conj() + u[r] * y[c].conj()) / n - uy * u[r] * u[c].conj() / (n * n) for c in range(2)] for r in range(2)]
meet_ok = True; nmeet = 0; nskew = 0; npairs = 0
for trial in range(300):
    x = [rc() for _ in range(4)]
    if trial % 2 == 0:
        p, q, r, s = rc(), rc(), rc(), rc()
        y_ = [a + b for a, b in zip(x, from_matrix([[p * r, p * s], [q * r, q * s]]))]
    else:
        y_ = [rc() for _ in range(4)]
    npairs += 1
    D = [[a - b for a, b in zip(r1, r2)] for r1, r2 in zip(Xm(x), Xm(y_))]
    if not det2(D) == interval([a - b for a, b in zip(x, y_)]): meet_ok = False
    if det2(D).iszero():
        nmeet += 1
        pi = [D[0][1], -D[0][0]] if not (D[0][0].iszero() and D[0][1].iszero()) else [D[1][1], -D[1][0]]
        if twistor(x, pi) != twistor(y_, pi): meet_ok = False
    else:                                                                    # skew: the two planes of the lines span C^4
        nskew += 1
        if len(rrefQ([twistor(x, [ONE, ZERO]), twistor(x, [ZERO, ONE]), twistor(y_, [ONE, ZERO]), twistor(y_, [ZERO, ONE])], 4)[0]) != 4: meet_ok = False
real_ok = True
for _ in range(100):
    x = [Q(rq()) for _ in range(4)]
    for _ in range(4):
        Z = twistor(x, [rc(), rc()])
        if not Sig(Z, Z).iszero(): real_ok = False
null_ok = True; nnull = nnon = 0
for trial in range(200):
    if trial % 2 == 0:
        Z = twistor([Q(rq()) for _ in range(4)], [rc(), rc()]); nnull += 1      # null: on the line of a real point
    else:
        Z = [rc() for _ in range(4)]
        if Sig(Z, Z).iszero(): continue
        nnon += 1
    pi = Z[2:]; Xs = hermitian_solution(pi, [c / IFAC for c in Z[:2]])
    if Sig(Z, Z).iszero():
        if Xs is None: null_ok = False; continue
        xr = from_matrix(Xs)
        if not isreal(xr) or twistor(xr, pi) != Z: null_ok = False
        u = [-pi[1].conj(), pi[0].conj()]                                     # u-dagger pi = 0
        k = from_matrix([[u[0] * u[0].conj(), u[0] * u[1].conj()], [u[1] * u[0].conj(), u[1] * u[1].conj()]])
        s_ = Q(rq())
        if not isreal(k) or not interval(k).iszero() or twistor([a + s_ * b for a, b in zip(xr, k)], pi) != Z: null_ok = False
    elif Xs is not None: null_ok = False
chk('std', meet_ok and real_ok and null_ok and nmeet == 150 and nskew == 150,
    'tf.INC: the incidence relation (2.5), omega = i X pi (the review\'s 1/sqrt2 scaled away), exact over Q(i): det(X - Y) is the interval of x - y, and the lines of two complex points meet exactly when it is 0 (%d pairs: the %d null ones meet at the twistor of the kernel of X - Y, the %d others are skew, their two planes spanning C^4; lines that meet give (X - Y) pi = 0); the line of a real point lies in PN (Sigma = 0, 400 twistors); a twistor with pi != 0 is met by a real point exactly when it is null: a Hermitian X with X pi = -i omega exists exactly when pi-dagger omega is imaginary, i.e. Sigma(Z, Z) = 2 Re(pi-dagger omega) = 0, built for %d null twistors and absent for %d non-null ones; the real points meeting a null twistor form the light ray x + s k, k the null vector of u u-dagger, u-dagger pi = 0' % (npairs, nmeet, nskew, nnull, nnon))
def congruence_ray(W, x, fac=None):
    """the ray of the congruence of W through the real point x: Sigma((f X pi, pi), W) = pi^T v, v = f X^T conj(w'') + conj(w'); None if v = 0"""
    f = IFAC if fac is None else fac; Xx = Xm(x)
    v = [f * (Xx[0][r] * W[2].conj() + Xx[1][r] * W[3].conj()) + W[r].conj() for r in range(2)]
    if v[0].iszero() and v[1].iszero(): return None
    return twistor(x, [v[1], -v[0]], f)
def robinson(W, npts, fac=None):
    """the rays of the congruence of W through npts random real points, and the real point (if any) where the condition on pi vanishes"""
    f = IFAC if fac is None else fac
    Xbad = hermitian_solution(W[2:], [-c / f.conj() for c in W[:2]])           # v = 0 at x: X w'' = -w'/conj(f)
    rays = [congruence_ray(W, [Q(rq()) for _ in range(4)], fac) for _ in range(npts)]
    return rays, (from_matrix(Xbad) if Xbad is not None else None)
rob_ok = True; nr = 0
for _ in range(3):
    if FAULT == 'NULLW': W = twistor([Q(rq()) for _ in range(4)], [rc(), rc()])
    else:
        W = [rc() for _ in range(4)]
        while Sig(W, W).iszero(): W = [rc() for _ in range(4)]
    rays, bad = robinson(W, 8)
    if bad is not None or any(Z is None for Z in rays): rob_ok = False; continue
    nr += len(rays)
    for Z in rays:
        if not Sig(Z, Z).iszero() or not Sig(Z, W).iszero(): rob_ok = False
    for Z1, Z2 in itertools.combinations(rays, 2):
        if Sig(Z1, Z2).iszero(): rob_ok = False
chk('std', rob_ok and nr == 24,
    'tf.INC: the Robinson congruence of a non-null twistor W (3 of them): through every real point x passes exactly one light ray Z with Sigma(Z, W) = 0, since Sigma((i X pi, pi), W) = pi^T v is linear in pi and v vanishes at a real point only for a Hermitian X with X w\'\' = -i w\', which needs Sigma(W, W) = 0 (no such point for these W); the %d rays through random rational points are null, lie in W-perp, and have Sigma(Z1, Z2) != 0 for every pair, so no two meet, as no two rays of the congruence can (two meeting at a point would be two through it): the family of the review\'s figure 2, its twisting not computed here' % nr)

# ================================================================================================ tf.PEN
head('tf.PEN: Penrose\'s integral formulae as exact residues')
def line_forms(M, Av, fac=None):
    """A.Z on the line of X in the chart pi = (1, lam): a0 + a1 lam (in the chart pi = (mu, 1) it is a1 + a0 mu)"""
    f = IFAC if fac is None else fac
    return (Av[0] * f * M[0][0] + Av[1] * f * M[1][0] + Av[2], Av[0] * f * M[0][1] + Av[1] * f * M[1][1] + Av[3])
def components(M, Av, Bv, n, k=None, chart='lam', fac=None):
    """phi_j = Res pi_0'^(n-j) pi_1'^j f pi.dpi, j = 0..n, for f = (A.Z)^-1 (B.Z)^-k (k = n + 1: homogeneity -n-2), at the root of A.Z:
    chart lam: pi = (1, lam), pi.dpi = dlam; chart mu: pi = (mu, 1), pi.dpi = -dmu"""
    k = n + 1 if k is None else k
    a0, a1 = line_forms(M, Av, fac); b0, b1 = line_forms(M, Bv, fac)
    if chart == 'lam': return [residue([ZERO] * j + [ONE], (a0, a1), 1, [((b0, b1), k)]) for j in range(n + 1)]
    return [-residue([ZERO] * (n - j) + [ONE], (a1, a0), 1, [((b1, b0), k)]) for j in range(n + 1)]
def phi_state(M, Av, Bv, k=None, chart='lam', fac=None):
    """the scalar of the elementary state 1/((A.Z)(B.Z)) (with k = 2 under the fault DEG: homogeneity -3)"""
    return components(M, Av, Bv, 0, (2 if FAULT == 'DEG' else 1) if k is None else k, chart, fac)[0]
def wave_at(fn, M0):
    """d00 d11 - d01 d10 in the entries X^{AA'} (the wave operator over 4), by second jets"""
    def second(e1, e2):
        vals = []
        for cmb in (e1 + e2, e1, e2):
            M = [[Jet([M0[r][s], Q(cmb.count((r, s)))]) for s in range(2)] for r in range(2)]
            vals.append(fn(M).c[2] * 2)
        return (vals[0] - vals[1] - vals[2]) / 2
    return second([(0, 0)], [(1, 1)]) - second([(0, 1)], [(1, 0)])
wave_ok = True; quad_ok = True
for _ in range(12):
    Av = [rc() for _ in range(4)]; Bv = [rc() for _ in range(4)]; M0 = [[rc(), rc()], [rc(), rc()]]
    if not wave_at(lambda M: phi_state(M, Av, Bv), M0).iszero(): wave_ok = False
    Mom = [[Av[0], Av[1]], [Bv[0], Bv[1]]]; Mpi = [[Av[2], Av[3]], [Bv[2], Bv[3]]]     # i Mom X0 + Mpi = 0: the line of X0 is A.Z = B.Z = 0
    dt_ = det2(Mom); inv = [[Mom[1][1] / dt_, -Mom[0][1] / dt_], [-Mom[1][0] / dt_, Mom[0][0] / dt_]]
    X0 = [[-(inv[r][0] * Mpi[0][c] + inv[r][1] * Mpi[1][c]) / IFAC for c in range(2)] for r in range(2)]
    vals = []
    for _ in range(3):
        M = [[rc(), rc()], [rc(), rc()]]
        vals.append(phi_state(M, Av, Bv) * det2([[M[r][c] - X0[r][c] for c in range(2)] for r in range(2)]) * dt_ * (-IFAC * IFAC))
    if not all(v == ONE for v in vals): quad_ok = False                       # a1 b0 - a0 b1 = -i^2 det Mom det(X - X0)
def field(M, Av, Bv, n): return components(M, Av, Bv, n)
chart_ok = True; zrm_ok = True
for n in (0, 1, 2, 3, 4):
    for _ in range(4):
        Av = [rc() for _ in range(4)]; Bv = [rc() for _ in range(4)]; M0 = [[rc(), rc()], [rc(), rc()]]
        if n == 0:
            if phi_state(M0, Av, Bv) != phi_state(M0, Av, Bv, chart='mu'): chart_ok = False
            continue
        if components(M0, Av, Bv, n) != components(M0, Av, Bv, n, chart='mu'): chart_ok = False
        D = {}
        for (a, c) in itertools.product(range(2), range(2)):
            M = [[Jet([M0[r][s], ONE if (r, s) == (a, c) else ZERO]) for s in range(2)] for r in range(2)]
            D[(a, c)] = [v.c[1] for v in field(M, Av, Bv, n)]
        for a in range(2):
            for k in range(n):
                if not (D[(a, 1)][k] - D[(a, 0)][k + 1]).iszero(): zrm_ok = False
chk('std', wave_ok and quad_ok and chart_ok and zrm_ok,
    'tf.PEN: Penrose\'s integral formulae as exact residues (Cauchy\'s theorem recalled): the elementary state 1/((A.Z)(B.Z)) (the review, p. 6) gives phi = 1/(a1 b0 - a0 b1) with a1 b0 - a0 b1 = det[[A0, A1], [B0, B1]] det(X - X0) exactly, X0 the point whose line is A.Z = B.Z = 0 (12 random states, three points each), a solution of the wave equation (second jets in the four complex entries of X); for n = 0, 1, 2, 3, 4 and f = (A.Z)^-1 (B.Z)^-(n+1), of homogeneity -n-2, the fields phi_{A\'..B\'} = Res pi_{A\'}..pi_{B\'} f pi.dpi are the same on the two charts of the line, pi = (1, lam) with pi.dpi = dlam and pi = (mu, 1) with pi.dpi = -dmu (4 states each), and for n >= 1 they solve the zero-rest-mass equations eps^{A\'C\'} d phi_{A\'B\'..}/dX^{AC\'} = 0 at random complex points; the equations hold on one chart for any integrand, since d/dX^{AA\'} acts on f(i X pi, pi) as i pi_{A\'} d/domega^A and eps^{A\'C\'} pi_{A\'} pi_{C\'} = 0, while for homogeneity d the mu-chart field is lam0^-(n+d+2) times the lam-chart one (lam0 the root of A.Z on the line, argued): the homogeneity -n-2 is what makes the field independent of the chart')
SM = [[[ONE, ZERO], [ZERO, ONE]], [[ZERO, ONE], [ONE, ZERO]], [[ZERO, I], [-I, ZERO]], [[ONE, ZERO], [ZERO, -ONE]]]   # X = t + x s1 + y s2 + z s3, (2.5)
EPS2 = [[ZERO, ONE], [-ONE, ZERO]]
def Mof(x): return [[sum((SM[m][r][c] * x[m] for m in range(4)), ZERO) for c in range(2)] for r in range(2)]
def Fmn(x, Av, Bv, fac=None):
    ph = components(Mof(x), Av, Bv, 2, fac=fac)
    return [[sum((SM[m][a][ap] * SM[nn][b][bp] * EPS2[a][b] * ph[ap + bp] for a, ap, b, bp in itertools.product(range(2), repeat=4)), ZERO) for nn in range(4)] for m in range(4)]
ETA = [1, -1, -1, -1]
def perm_sign(p):
    s = 1
    for i in range(len(p)):
        for j in range(i + 1, len(p)):
            if p[i] > p[j]: s = -s
    return s
def star_eps(F, metric=None):
    """(*F)_mn = 1/2 eps_mnrs F^rs, eps_0123 = 1, indices raised with eta = diag(1, -1, -1, -1) (with the identity under the fault EUC)"""
    g = ([1, 1, 1, 1] if FAULT == 'EUC' else ETA) if metric is None else metric
    return [[sum((Q(Fr(perm_sign((m, nn, r, s)), 2) * g[r] * g[s]) * F[r][s] for r, s in itertools.product(range(4), repeat=2) if len({m, nn, r, s}) == 4), ZERO) for nn in range(4)] for m in range(4)]
A4 = BR(list(_core_sig(1, 3, 0))); PS = {15: 1}
def star_bit(F):
    """the 2-form F as the bivector sum_{m<n} F^{mn} e_m e_n of Cl(1,3), times the pseudoscalar e0e1e2e3 by the bit rule, read back with lower indices"""
    out = [[ZERO] * 4 for _ in range(4)]
    for m, nn in itertools.combinations(range(4), 2):
        (k, c), = A4.mul({(1 << m) | (1 << nn): 1}, PS).items()
        r, s = [i for i in range(4) if (k >> i) & 1]
        coef = Q(c * ETA[m] * ETA[nn] * ETA[r] * ETA[s])
        out[r][s] = out[r][s] + coef * F[m][nn]; out[s][r] = out[s][r] - coef * F[m][nn]
    return out
rel = set()
for m, nn in itertools.combinations(range(4), 2):
    E = [[ZERO] * 4 for _ in range(4)]; E[m][nn] = ONE; E[nn][m] = -ONE
    se, sb = star_eps(E), star_bit(E)
    rel.add('+1' if sb == se else '-1' if sb == [[-v for v in r] for r in se] else '?')
sd_ok = True; closed_ok = True; svals = set()
for _ in range(4):
    Av = [rc() for _ in range(4)]; Bv = [rc() for _ in range(4)]; x = [rc() for _ in range(4)]
    F = Fmn(x, Av, Bv); se = star_eps(F)
    if all(se[m][nn] == I * F[m][nn] for m in range(4) for nn in range(4)): svals.add('i')
    elif all(se[m][nn] == -I * F[m][nn] for m in range(4) for nn in range(4)): svals.add('-i')
    else: sd_ok = False
    dF = {}
    for l in range(4):
        F_l = Fmn([Jet([c, ONE if k == l else ZERO]) for k, c in enumerate(x)], Av, Bv)
        dF[l] = [[F_l[m][nn].c[1] for nn in range(4)] for m in range(4)]
    for l, m, nn in itertools.combinations(range(4), 3):
        if not (dF[l][m][nn] + dF[m][nn][l] + dF[nn][l][m]).iszero(): closed_ok = False
chk('bit==std', sd_ok and closed_ok and svals == {'i'} and len(rel) == 1 and '?' not in rel,
    'tf.PEN: for n = 2 the 2-form F = phi_{A\'B\'} eps_{AB} (the sigma matrices of (2.5), 4 random states and points) is closed (dF = 0 by jets) and an eigenform of the star, *F = %s F with the star of the epsilon tensor (eta = diag(1, -1, -1, -1), eps_0123 = 1): a primed field, the review\'s Lambda^2_+ = S\'* (.) S\'*, so *F = %s F and dF = 0 give Maxwell\'s equations for F in vacuum; the star by the bit rule of Cl(1,3), the bivector times the pseudoscalar e0e1e2e3 of the kernel, %s the star of the epsilon tensor on all six basis 2-forms' % ('/'.join(sorted(svals)) or 'neither +i nor -i', '/'.join(sorted(svals)) or '?', {'+1': 'equals', '-1': 'is minus'}.get('/'.join(sorted(rel)), 'is not a multiple of')))

# ================================================================================================ tf.LAX
head('tf.LAX: the Lax pairs of the review for the anti-self-dual Yang-Mills and Nahm equations')
def thooft(bar):
    """eta^a_mn as in gravity/ym_solutions.py: eta^a_ij = eps_aij, eta^a_i4 = delta_ai (eta-bar: -delta_ai), slot 3 = x^4"""
    out = []
    for a in range(3):
        E = [[Fr(0)] * 4 for _ in range(4)]
        for m, nn in itertools.product(range(3), repeat=2):
            if len({a, m, nn}) == 3: E[m][nn] = Fr(perm_sign((a, m, nn)))
        E[a][3] = Fr(-1 if bar else 1); E[3][a] = Fr(1 if bar else -1)
        out.append(E)
    return out
half = Fr(1, 2)
DZ = [Q(half), Q(0, -half), ZERO, ZERO]; DZT = [Q(half), Q(0, half), ZERO, ZERO]           # z = x1 + i x2, z~ = zbar
DW = [ZERO, ZERO, Q(half), Q(0, -half)]; DWT = [ZERO, ZERO, Q(-half), Q(0, -half)]         # w = x3 + i x4, w~ = -wbar
def comp(E, u, v): return sum((u[m] * Q(E[m][nn]) * v[nn] for m in range(4) for nn in range(4)), ZERO)
def lax_coeffs(E): return [comp(E, DZT, DWT), comp(E, DW, DWT) - comp(E, DZ, DZT), comp(E, DW, DZ)]
def is_sd(E, sgn):
    for m, nn in itertools.product(range(4), repeat=2):
        v = sum((Fr(perm_sign((m, nn, r, s)), 2) * E[r][s] for r, s in itertools.product(range(4), repeat=2) if len({m, nn, r, s}) == 4), Fr(0))
        if v != sgn * E[m][nn]: return False
    return True
asd_t = thooft(True); sd_t = thooft(False)
test = sd_t if FAULT == 'SDLAX' else asd_t
lax_asd = all(all(c.iszero() for c in lax_coeffs(E)) for E in test)
lax_sd_nonzero = all(not all(c.iszero() for c in lax_coeffs(E)) for E in sd_t)
LAXSD = [lax_coeffs(E) for E in sd_t]                                         # the three conditions on the three self-dual tensors
lax_det = (LAXSD[0][0] * (LAXSD[1][1] * LAXSD[2][2] - LAXSD[1][2] * LAXSD[2][1]) - LAXSD[0][1] * (LAXSD[1][0] * LAXSD[2][2] - LAXSD[1][2] * LAXSD[2][0])
           + LAXSD[0][2] * (LAXSD[1][0] * LAXSD[2][1] - LAXSD[1][1] * LAXSD[2][0]))
chir = all(is_sd(E, -1) for E in asd_t) and all(is_sd(E, 1) for E in sd_t)
def wedge4(vs):
    """the coefficient of dx1 dx2 dx3 dx4 in the wedge of four 1-forms given by their components"""
    tot = ZERO
    for p in itertools.permutations(range(4)):
        term = Q(perm_sign(p))
        for k in range(4): term = term * vs[k][p[k]]
        tot = tot + term
    return tot
VOL = wedge4([[ZERO, ZERO, ONE, I], [ZERO, ZERO, -ONE, I], [ONE, I, ZERO, ZERO], [ONE, -I, ZERO, ZERO]])   # dw, dw~ = -dwbar, dz, dz~ = dzbar
metric_ok = all(sum((u[m] * v[m] for m in range(4)), ZERO) == want for u, v, want in
                ((DZ, DZT, Q(half)), (DW, DWT, Q(-half)), (DZ, DZ, ZERO), (DW, DW, ZERO), (DZ, DW, ZERO), (DZ, DWT, ZERO), (DZT, DW, ZERO)))
def mmq(Am, Bm): return [[sum((Am[i][k] * Bm[k][j] for k in range(len(Bm))), ZERO) for j in range(len(Bm[0]))] for i in range(len(Am))]
def addq(Am, Bm, c=ONE): return [[a + c * b for a, b in zip(r1, r2)] for r1, r2 in zip(Am, Bm)]
def brq(Am, Bm): return addq(mmq(Am, Bm), mmq(Bm, Am), -ONE)
def scq(Am, c): return [[c * a for a in r] for r in Am]
def nahm_holds(P1, P2, P3, sgn):
    """B' - [B, C] = 0 coefficient by coefficient in lam, with Phi_i' = [Phi_j, Phi_k] (cyclic); sgn = -1 changes the sign of the lam^2 term of B"""
    size = len(P1); D1, D2, D3 = brq(P2, P3), brq(P3, P1), brq(P1, P2)
    Bc = [addq(P1, P2, I), scq(P3, Q(2)), scq(addq(P1, P2, -I), Q(-sgn))]
    Bd = [addq(D1, D2, I), scq(D3, Q(2)), scq(addq(D1, D2, -I), Q(-sgn))]
    Cc = [scq(P3, -I), scq(addq(P1, P2, -I), I)]
    Z0 = [[ZERO] * size for _ in range(size)]; BC = [Z0] * 4
    for i, b in enumerate(Bc):
        for j, c in enumerate(Cc): BC[i + j] = addq(BC[i + j], brq(b, c))
    return all(all(x.iszero() for row in addq(l, r, -ONE) for x in row) for l, r in zip(Bd + [Z0], BC))
def rmat(size): return [[Q(rnd.randint(-4, 4), rnd.randint(-4, 4)) for _ in range(size)] for _ in range(size)]
nahm_ok = all(nahm_holds(rmat(size), rmat(size), rmat(size), -1 if FAULT == 'NAHM' else 1) for size in (2, 3, 4) for _ in range(3))
chk('std', lax_asd and lax_sd_nonzero and not lax_det.iszero() and chir and metric_ok and VOL == Q(4) and nahm_ok,
    'tf.LAX: the review\'s Lax pair (5.3) on Euclidean R^4, with its reality z~ = zbar, w~ = -wbar and the Atlas\'s choice z = x1 + i x2, w = x3 + i x4 (the review does not fix it; w = x3 - i x4 would reverse the orientation): the vector fields d_z, d_z~, d_w, d_w~ have the Euclidean products d_z.d_z~ = 1/2, d_w.d_w~ = -1/2 and 0 otherwise, so the review\'s g = 2(dz dz~ - dw dw~) is twice the Euclidean metric, and its orientation vol = dw dw~ dz dz~ is %s dx1 dx2 dx3 dx4 (checked): the three coefficients of [L, M], F_z~w~, F_ww~ - F_zz~ and F_wz, vanish on the three anti-self-dual \'t Hooft tensors eta-bar (*eta-bar = -eta-bar, eps_1234 = 1) and on the three self-dual eta form a non-singular 3 x 3 matrix (determinant %s): their common zeros are exactly the anti-self-dual 2-forms of that orientation, the review\'s (5.1) *F = -F; CAND-124\'s BPST instanton has F = -4 eta rho^2/(x^2 + rho^2)^2 (computed by ym_solutions.py, not here), self-dual: in these coordinates it is not a solution, and its mirror image, the anti-instanton (eta-bar), is, an instanton in the review\'s sense (anti-self-dual, its section 5(c)); Nahm\'s equations (p. 16): with Phi1\' = [Phi2, Phi3] and cyclic, B\' = [B, C] for B = (Phi1 + i Phi2) + 2 Phi3 lam - (Phi1 - i Phi2) lam^2 and C = -i Phi3 + i(Phi1 - i Phi2) lam, coefficient by coefficient in lam, for random Gaussian-integer matrices of sizes 2, 3, 4 (three each)' % (VOL.a if VOL.b == 0 else 'complex', '%s + %si' % (lax_det.a, lax_det.b) if lax_det.b else lax_det.a))

# ================================================================================================ controls, computed in place without the fault
head('controls: the cell (3,3), the factor i, a null twistor, the homogeneity, the Euclidean star, the chirality, a sign of Nahm\'s B')
A33 = BR(list(_core_sig(3, 3, 0)))
xr = [Q(rq()) for _ in range(4)]; Zr = twistor(xr, [rc(), rc()], ONE)       # without the factor i
chk('ctl', A33.mul(OM, OM) == {0: 1} and not Sig(Zr, Zr).iszero(),
    'tf.SPIN, tf.INC: in the cell (3,3) the volume element has square +1, so it is no complex structure there (CELL: the split real form); without the factor i of (2.5) the line of a real point leaves PN, Sigma != 0 (NOI)')
xw = [Q(rq()) for _ in range(4)]; Wn = twistor(xw, [rc(), rc()], I)
_, bad_n = robinson(Wn, 2, I)
Av = [rc() for _ in range(4)]; Bv = [rc() for _ in range(4)]; M0 = [[rc(), rc()], [rc(), rc()]]
deg_differs = phi_state(M0, Av, Bv, 2, 'lam', I) != phi_state(M0, Av, Bv, 2, 'mu', I)
deg_wave = wave_at(lambda M: phi_state(M, Av, Bv, 2, 'lam', I), M0).iszero()          # on one chart every integrand solves it
chk('ctl', bad_n is not None and isreal(bad_n) and congruence_ray(Wn, bad_n, I) is None and deg_differs and deg_wave,
    'tf.INC, tf.PEN: for a null twistor W, the twistor of a real point, the condition on pi vanishes at a real point of its ray, through which every light ray lies in W-perp: no congruence (NULLW); the state 1/((A.Z)(B.Z)^2), of homogeneity -3, solves the wave equation on one chart, as every integrand does, but gives different values on the two charts (DEG)')
E01 = [[ZERO] * 4 for _ in range(4)]; E01[0][1] = ONE; E01[1][0] = -ONE
Ftest = Fmn([rc() for _ in range(4)], [rc() for _ in range(4)], [rc() for _ in range(4)], I)
seu = star_eps(Ftest, [1, 1, 1, 1])
euc_fails = not any(all(seu[m][nn] == c * Ftest[m][nn] for m in range(4) for nn in range(4)) for c in (I, -I))
chk('ctl', euc_fails and lax_sd_nonzero and not nahm_holds(rmat(2), rmat(2), rmat(2), -1),
    'tf.PEN, tf.LAX: with the indices raised by the identity instead of eta, F is no eigenform of the star (EUC); the self-dual tensors eta leave the Lax coefficients non-zero (SDLAX); with the sign of the lam^2 term of B changed, B\' != [B, C] (NAHM)')
finish()
