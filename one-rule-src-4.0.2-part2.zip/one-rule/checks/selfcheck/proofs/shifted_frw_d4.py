#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_frw_d4.py -- ATY-053 carried to order four on actual solutions: Atiyah and Moore's restriction of their shifted Einstein equations (3.5)
to the 1-forms that solve the wave equation (3.10), on the FRW frame e^a = eta^2 dx^a (not Einstein) and on de Sitter e^a = -dx^a/(H eta).

Read.  (3.2) on 1-forms D^2 + nabla^2 = Ricci; (3.5) the shifted Einstein equations as series sum_j c_j D^2j; (3.10) the restriction to the
1-forms with -nabla^2 phi = 0, "unfortunately" not preserved since Delta need not commute with the Ricci operator.  The Atlas (shifted_einstein.py,
se.WAVE) has D^2 = box - Ric on the labels and [box, Ric] != 0 on the FRW frame, and ATY-053 read the order of the failure (mu^3) from the series.
Here the solutions of (3.10) are built exactly and D is applied to them four (and six) times.
Conventions.  Those of shifted_einstein.py, whose functions are taken by ast, unchanged (it runs its checks at import, so it is not imported):
frame algebra Cl(1,3), sq = (+1, -1, -1, -1); omega the closed form; D X = gamma^a nabla_a X on the full algebra, nabla X = d X + (1/2) omega^A [B_A, X];
box = eta^ab nabla_a nabla_b (the paper's -nabla^2); Ric^b_d = eta^bb R_bd, R_bd = R^a_bad.  Their own fault switches are off (FAULT = None in their
namespace).  The chart: x^0 = eta, x^1..3; fields are Laurent polynomials in eta and polynomials in x.  Exponents and coefficients lie in Q, in Q[t]
(t a symbol: the exponent left free) or in Q[t]/(m(t)) with m the indicial polynomial, irreducible over Q: there t is a root, the quotient is the
field Q(sqrt disc m), and every identity proved in it holds for both conjugate roots.  mu = kappa tau; kappa = 1 in the series lines (D^2 in units
of kappa^2).
Statements.
(1) [frw.FRAME] e^a = eta^2 dx^a exactly in the chart: torsion-free; R_ab = 6 eta^-6 delta_ab, so Ric = diag(6, -6, -6, -6) eta^-6 is not a
    multiple of the identity (not Einstein); G_ab = 12 eta^-6 delta_a0 delta_b0, pressureless dust (a = eta^2, a ~ t^(2/3)); D^2 = box - Ric on
    random polynomial 1-forms and on eta^t gamma_a with t free.
(2) [frw.SOL] The solutions of (3.10).  box(eta^t gamma_0) = (t^2 + 3t - 12) eta^(t-6) gamma_0 and box(eta^t gamma_i) = (t - 1)(t + 4) eta^(t-6)
    gamma_i, exactly as polynomials in t: the homogeneous solutions are eta gamma_i and eta^-4 gamma_i (Laurent, integer exponents) and eta^t gamma_0
    with t^2 + 3t - 12 = 0, t = (-3 +- sqrt 57)/2 (exact in Q(sqrt 57)).  The family: box keeps the weight (eta-exponent + x-degree) up to the shift
    -6 and its x-degree-preserving part acts on eta^p x^m gamma_a as the indicial polynomial, so the top x-degree part of a solution has a root as
    its eta-exponent; the null space of box in each weight class (x-degree <= 2) is computed: 3 C(k+2, 2) Laurent solutions with top part eta^1 or
    eta^-4 times an x-monomial of degree k times gamma_i (60 in all, none at other weights), and C(k+2, 2) in Q(sqrt 57) with top part eta^t x^m
    gamma_0 (10).
(3) [frw.D4] On every one of these solutions: D^2 X = -Ric X (an endomorphism applied to X); D^4 X (D applied four times) = Ric^2 X - box(Ric X);
    X -> box(Ric X) has full rank on both families, so D^4 X != Ric^2 X on every non-zero solution of them (on the homogeneous ones D^4 = 2 Ric^2,
    12 Ric^2 and (2t - 2) Ric^2); and D^4 is not tensorial on the solutions: Y = eta gamma_1 - eta^-4 gamma_1 vanishes on eta = 1, so does D^2 Y,
    but D^4 Y = -360 gamma_1 there.
(4) [frw.SER] The series of shifted_einstein.py (se.SER) to D^12: c_j kappa^(2j-2) = C_j(mu) has the mu-orders 2j - 1 and 2j only (2j - 1 only for
    D_+ D_-), so the order mu^k term of Ricci_xx - Ricci is C_j^(k) D^2j with j = ceil(k/2): orders 1, 2 are the D^2 terms, 3, 4 the D^4 term, whose
    mu^3 coefficient is -1/3, -1/3, +1/3.  On the FRW solutions the residual by order R^(k) X = sum_j C_j^(k) D^2j X is E^(k) X with E^(k) = C_0^(k) -
    C_1^(k) Ric for k = 0, 1, 2 (all solutions, three operators), and at k = 3 it is C_2^(3) (Ric^2 X - box(Ric X)), non-zero on Y at eta = 1 where
    Y = 0: the restriction fails at order mu^3, the D^4 term, on actual solutions.
(5) [frw.STD] Coordinate index calculus written here, no label (g = A^2 diag(1,-1,-1,-1), Christoffel symbols, Ricci, the rough Laplacian, d and the
    codifferential by the divergence formula with sqrt|g|, the Hodge Laplacian Delta_g twice), exact in the same number rings: the two indicial
    polynomials with t free, and on every solution box X = nabla^2 phi = 0, Ric X = Ric(phi), D^2 X = -Delta_g phi, D^4 X = Delta_g^2 phi and
    box(Ric X) = nabla^2 Ric(phi), through X^a = eta_aa phi_a / A.  Numpy, floats, no exact arithmetic (the Atlas's Std of se.STD: finite
    differences on the closed-form frame, the irrational exponents as floats, both roots): box X = 0, D^2 X = -Ric X, D^2 of the exact D^2 X = the
    exact D^4 X and box of the exact Ric X = the exact box(Ric X), at eta = 1.3 on six solutions (two of them x-dependent).
(6) [ds.CTL] De Sitter (H = 1, Lambda = 3) by the same computation: indicial polynomials t^2 - 3t - 3 (gamma_0) and t^2 - 3t - 1 (gamma_i) with t
    free; homogeneous solutions and the families of x-degree <= 2 in Q(sqrt 21) and Q(sqrt 13) (box keeps the weight); on all of them D^2 X = Lambda X,
    D^4 X = Lambda^2 X = Ric^2 X, D^6 X = Lambda^3 X, box(Ric X) = 0, and the residual of each operator at every order computed (mu^0 ... mu^6) is a
    number times X: since D^2 X = Lambda X is again a solution, D^2j X = Lambda^j X and the restriction is consistent to every order; the std route
    agrees.
[ctl]  Wrong versions in the main run (they must fail) and --fault options (the run must end with FAILS and exit 1):
       D4RIC2  the claim D^4 X = Ric^2 X on the FRW solutions;   NONSOL  a non-solution of (3.10) (eta^2 gamma_1, eta^(t+1) gamma_0) added to every
       1-form where a solution is required.
Scope.  Exact identities in the chart of two conformally flat frames (FRW a = eta^2, de Sitter a = -1/eta with H = 1), on the solutions of (3.10)
       that are Laurent in eta and polynomial of degree <= 2 in x (exponents in Q, Q(sqrt 57), Q(sqrt 21), Q(sqrt 13)); the series to D^12 (mu^12),
       the residual by order through mu^4 on FRW and mu^6 on de Sitter.  What the operator equations (3.5) mean, and the pair (g, phi) of (3.11),
       stay open.  No claim about nature.
Run:   python3 shifted_frw_d4.py [--fault NAME]   (beside shifted_einstein.py, or from v4_work/shifted_view/checks/ of the work tree; under -I -B)"""
import os, sys, time, ast, hashlib, itertools, random, math
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
T0 = time.time()

_here = os.path.dirname(os.path.abspath(__file__))
_cands = [os.path.join(os.path.abspath(a_), 'proofs', 'shifted_einstein.py') for i_a, a_ in enumerate(sys.argv[1:], 1) if not a_.startswith('--') and sys.argv[i_a - 1] != '--fault'] + [os.path.join(_here, 'shifted_einstein.py'),
          os.path.normpath(os.path.join(_here, '..', '..', '..', 'v4', 'one-rule', 'checks', 'selfcheck', 'proofs', 'shifted_einstein.py'))]
SE = next((p for p in _cands if os.path.isfile(p)), None)
if SE is None: raise SystemExit('shifted_einstein.py not found beside this file or at ../../../v4/one-rule/checks/selfcheck/proofs/')
_grav = os.path.join(os.path.dirname(os.path.dirname(SE)), 'gravity')
if not os.path.isfile(os.path.join(_grav, 'b1lib.py')): raise SystemExit('gravity/b1lib.py not found beside the folder of shifted_einstein.py')
if _grav not in sys.path: sys.path.insert(0, _grav)
import b1lib as bl                                                          # the engine (gravity_selfcheck.py) and the closed-form connection
from b1lib import padd, bmul, Lie, Grav, Forms, trunc, pm, at0, scale

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('%s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg.split(':')[0]))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('  (total %.1f s)' % (time.time() - T0), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('D4RIC2', 'NONSOL')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name

# ================================================================================================ the Atlas's functions, taken by ast (unchanged)
TAKE = ('clean', 'mvp_add', 'rpol', 'D_full', 'contract', 'nabla', 'dirac', 'second_cov', 'box_of', 'mono', 'exact_setup', 'form2_eval',
        'ricci_exact', 'sum_polys', 'D_exact', 'box_exact', 'ric_on', 'fault', 'kt_add', 'kt_mul', 's_mul', 's_lin', 's_exp', 'closed_c',
        'stencil', 'Std')                                                   # the last two: its numpy route (se.STD), finite differences
_src = open(SE, 'rb').read(); _tree = ast.parse(_src.decode('utf-8'))
SEN = dict(bl=bl, padd=padd, bmul=bmul, Lie=Lie, Grav=Grav, Forms=Forms, trunc=trunc, pm=pm, at0=at0, scale=scale, Fr=Fr, itertools=itertools,
           math=math, np=np, FAULT=None, NS=12)                             # FAULT = None: the Atlas's own faults (NOCONN, ...) stay off
_got = []
for _node in _tree.body:
    if isinstance(_node, (ast.FunctionDef, ast.ClassDef)) and _node.name in TAKE:
        exec(compile(ast.Module([_node], type_ignores=[]), SE, 'exec'), SEN); _got.append(_node.name)
if sorted(_got) != sorted(TAKE): raise SystemExit('shifted_einstein.py: functions not found: %s' % sorted(set(TAKE) - set(_got)))
mvp_add, rpol, mono, exact_setup, sum_polys = SEN['mvp_add'], SEN['rpol'], SEN['mono'], SEN['exact_setup'], SEN['sum_polys']
D_exact, box_exact, ric_on = SEN['D_exact'], SEN['box_exact'], SEN['ric_on']
print('taken by ast from %s (sha256 %s...): %d functions, unchanged: %s' % (os.path.relpath(SE, _here), hashlib.sha256(_src).hexdigest()[:16], len(_got), ', '.join(_got)), flush=True)

# ================================================================================================ exact numbers: Q[t] and Q[t]/(m(t))
class QR:
    """an element of Q[t] (m = None) or of Q[t]/(m), m monic (coefficients ascending); stored reduced; a constant equals and hashes as its Fraction"""
    __slots__ = ('c', 'm')
    def __init__(s, c, m=None):
        c = [Fr(x) for x in c]
        if m is not None:
            k = len(m) - 1
            while len(c) > k:
                top = c.pop()
                if top:
                    for i in range(k): c[len(c) - k + i] -= top * m[i]
        while c and c[-1] == 0: c.pop()
        s.c = tuple(c); s.m = m
    def _co(s, o):
        if isinstance(o, QR):
            if o.m != s.m and len(o.c) > 1 and len(s.c) > 1: raise ValueError('QR: two different rings')
            return o
        if isinstance(o, (int, Fr)): return QR([o], s.m)
        return NotImplemented
    def _mod(s, o): return s.m if s.m is not None else o.m
    def __add__(s, o):
        o = s._co(o)
        if o is NotImplemented: return o
        n = max(len(s.c), len(o.c)); z = Fr(0)
        return QR([(s.c[i] if i < len(s.c) else z) + (o.c[i] if i < len(o.c) else z) for i in range(n)], s._mod(o))
    __radd__ = __add__
    def __neg__(s): return QR([-x for x in s.c], s.m)
    def __sub__(s, o):
        o = s._co(o)
        return o if o is NotImplemented else s + (-o)
    def __rsub__(s, o): return (-s) + o
    def __mul__(s, o):
        o = s._co(o)
        if o is NotImplemented: return o
        r = [Fr(0)] * max(0, len(s.c) + len(o.c) - 1)
        for i, a in enumerate(s.c):
            for j, b in enumerate(o.c): r[i + j] += a * b
        return QR(r, s._mod(o))
    __rmul__ = __mul__
    def inv(s):
        if not s.c: raise ZeroDivisionError('QR')
        if len(s.c) == 1: return QR([1 / s.c[0]], s.m)
        assert s.m is not None and len(s.m) == 3, 'inverse only in a quadratic field'
        q, p = s.m[0], s.m[1]; a, b = s.c[0], s.c[1]; N = a * a - a * b * p + b * b * q
        return QR([(a - b * p) / N, -b / N], s.m)                          # (a + b t)^-1 = ((a - b p) - b t)/N, t^2 + p t + q = 0
    def __truediv__(s, o): return s * (o.inv() if isinstance(o, QR) else QR([1 / Fr(o)], s.m))
    def __rtruediv__(s, o): return QR([o], s.m) * s.inv()
    def __eq__(s, o):
        if isinstance(o, (int, Fr)): o = QR([o], s.m)
        if not isinstance(o, QR): return NotImplemented
        return s.c == o.c and (len(s.c) <= 1 or s.m == o.m)
    def __hash__(s): return hash(Fr(0)) if not s.c else (hash(s.c[0]) if len(s.c) == 1 else hash((s.c, s.m)))
    def __bool__(s): return bool(s.c)
    def __repr__(s):
        if not s.c: return '0'
        out = []
        for i, v in enumerate(s.c):
            if v: out.append(('%s' % v) + ('' if i == 0 else (' t' if i == 1 else ' t^%d' % i)))
        return ' + '.join(out).replace('+ -', '- ')
def ring(m): return QR([0, 1], tuple(Fr(x) for x in m) if m is not None else None)
TS = ring(None)                                                             # the exponent left free
T57 = ring((-12, 3, 1))                                                     # FRW gamma_0: t^2 + 3t - 12 = 0, t = (-3 +- sqrt 57)/2
T21 = ring((-3, -3, 1))                                                     # de Sitter gamma_0: t^2 - 3t - 3 = 0, t = (3 +- sqrt 21)/2
T13 = ring((-1, -3, 1))                                                     # de Sitter gamma_i: t^2 - 3t - 1 = 0, t = (3 +- sqrt 13)/2

# ================================================================================================ helpers on multivector fields (labels)
SIG = [1, -1, -1, -1]
def lin(*terms):
    acc = {}
    for c, X in terms: acc = mvp_add(acc, X, c)
    return acc
def same(X, Y): return mvp_add(X, Y, -1) == {}
def hom(p, a, c=1): return {1 << a: {(p, 0, 0, 0): Fr(c)}}
def flat(Y): return {(S,) + tuple(ex): v for S, p in Y.items() for ex, v in p.items()}
def at_eta1(Y):
    """the field on the hypersurface eta = 1 (every eta^p is 1 there), as polynomials in x"""
    out = {}
    for S, p in Y.items():
        q = {}
        for ex, v in p.items():
            k = tuple(ex[1:]); x = q.get(k, 0) + v
            if x == 0: q.pop(k, None)
            else: q[k] = x
        if q: out[S] = q
    return out
def kernel(cols):
    """exact null space of the columns (sparse vectors with entries in a field: Fractions or QR in Q(sqrt d)); returns (basis, rank)"""
    keys = sorted({k for c in cols for k in c}, key=repr); idx = {k: i for i, k in enumerate(keys)}; nc = len(cols)
    M = [[Fr(0)] * nc for _ in keys]
    for j, c in enumerate(cols):
        for k, v in c.items(): M[idx[k]][j] = v
    piv = []; r = 0
    for cc in range(nc):
        p = next((i for i in range(r, len(M)) if M[i][cc] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][cc]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][cc] != 0:
                f = M[i][cc]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        piv.append(cc); r += 1
    basis = []
    for fcol in (c for c in range(nc) if c not in piv):
        v = [Fr(0)] * nc; v[fcol] = Fr(1)
        for i, pc in enumerate(piv): v[pc] = -M[i][fcol]
        basis.append(v)
    return basis, r
def solutions(d, weights, K=2):
    """[bit] the solutions of box X = 0 in each weight class w: X = sum c eta^(w - |m|) x^m gamma_a, |m| <= K (the null space of box)"""
    out = {}
    for w in weights:
        ans = [(a, (w - sum(xm),) + xm) for a in range(4) for xm in itertools.product(range(K + 1), repeat=3) if sum(xm) <= K]
        cols = [flat(box_exact(d, {1 << a: {ex: Fr(1)}})) for a, ex in ans]
        ker, _ = kernel(cols)
        if ker:
            sols = []
            for v in ker:
                X = {}
                for c, (a, ex) in zip(v, ans):
                    if c != 0: X = mvp_add(X, {1 << a: {ex: c}})
                sols.append(X)
            out[w] = sols
    return out
def rank_of(vecs): return kernel([flat(Y) for Y in vecs])[1]

# ================================================================================================ [std] coordinate index calculus (no label)
def P_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items():
        x = r.get(k, 0) + c * v
        if x == 0: r.pop(k, None)
        else: r[k] = x
    return r
def P_mul(a, b):
    r = {}
    for k1, v1 in a.items():
        for k2, v2 in b.items():
            k = tuple(x + y for x, y in zip(k1, k2)); x = r.get(k, 0) + v1 * v2
            if x == 0: r.pop(k, None)
            else: r[k] = x
    return r
def P_der(a, i):
    r = {}
    for k, v in a.items():
        if k[i]:
            kk = list(k); kk[i] = kk[i] - 1; kk = tuple(kk); x = r.get(kk, 0) + v * k[i]
            if x == 0: r.pop(kk, None)
            else: r[kk] = x
    return r
def P_scale(a, c): return {k: v * c for k, v in a.items()} if c != 0 else {}
class Conf:
    """[std] g = A(eta)^2 diag(1,-1,-1,-1) in the chart (x^0 = eta), A a Laurent monomial; 1-forms phi_mu as Laurent polynomials; textbook formulas"""
    def __init__(s, A):
        (ex, c), = A.items(); s.A = dict(A); s.Ai = {tuple(-x for x in ex): 1 / Fr(c)}
        A2 = P_mul(s.A, s.A); Ai2 = P_mul(s.Ai, s.Ai)
        s.g = [P_scale(A2, SIG[m]) for m in range(4)]; s.gi = [P_scale(Ai2, SIG[m]) for m in range(4)]       # diagonal
        s.sg = P_mul(A2, A2); s.sgi = P_mul(Ai2, Ai2)                                                       # sqrt|g| = A^4 and its inverse
        G = {}
        for l in range(4):                                                  # Gamma^l_mv = (1/2) g^ll (d_m g_lv + d_v g_lm - d_l g_mv)
            for m in range(4):
                for v in range(4):
                    t = {}
                    if l == v: t = P_add(t, P_der(s.g[l], m))
                    if l == m: t = P_add(t, P_der(s.g[l], v))
                    if m == v: t = P_add(t, P_der(s.g[m], l), -1)
                    t = P_scale(P_mul(s.gi[l], t), Fr(1, 2))
                    if t: G[(l, m, v)] = t
        s.G = G; Gm = lambda *k: G.get(k, {})
        s.Ric = [[{} for _ in range(4)] for _ in range(4)]                  # R_sn = R^r_srn, R^r_smn = d_m G^r_ns - d_n G^r_ms + G^r_ml G^l_ns - G^r_nl G^l_ms
        for sx in range(4):
            for n in range(4):
                t = {}
                for r in range(4):
                    t = P_add(t, P_der(Gm(r, n, sx), r)); t = P_add(t, P_der(Gm(r, r, sx), n), -1)
                    for l in range(4):
                        t = P_add(t, P_mul(Gm(r, r, l), Gm(l, n, sx))); t = P_add(t, P_mul(Gm(r, n, l), Gm(l, r, sx)), -1)
                s.Ric[sx][n] = t
    def ric(s, ph): return [sum_P([P_mul(P_mul(s.Ric[v][m], s.gi[m]), ph[m]) for m in range(4)]) for v in range(4)]
    def nab(s, ph): return [[P_add(P_der(ph[v], m), sum_P([P_mul(s.G.get((l, m, v), {}), ph[l]) for l in range(4)]), -1) for v in range(4)] for m in range(4)]
    def rough(s, ph):
        T = s.nab(ph); out = []
        for rho in range(4):
            acc = {}
            for m in range(4):                                              # g^mm (d_m T_m rho - G^l_mm T_l rho - G^l_m rho T_m l)
                t = P_der(T[m][rho], m)
                for l in range(4):
                    t = P_add(t, P_mul(s.G.get((l, m, m), {}), T[l][rho]), -1); t = P_add(t, P_mul(s.G.get((l, m, rho), {}), T[m][l]), -1)
                acc = P_add(acc, P_mul(s.gi[m], t))
            out.append(acc)
        return out
    def delta1(s, ph): return P_scale(P_mul(s.sgi, sum_P([P_der(P_mul(P_mul(s.sg, s.gi[m]), ph[m]), m) for m in range(4)])), -1)
    def hodge(s, ph):
        """Delta_g phi = d delta_g phi + delta_g d phi, (delta_g F)_v = -g_vv (1/sqrt|g|) d_k (sqrt|g| g^kk g^vv F_kv)"""
        dl = s.delta1(ph); F = [[P_add(P_der(ph[v], m), P_der(ph[m], v), -1) for v in range(4)] for m in range(4)]
        out = []
        for v in range(4):
            dF = sum_P([P_der(P_mul(P_mul(P_mul(s.sg, s.gi[k]), s.gi[v]), F[k][v]), k) for k in range(4)])
            out.append(P_add(P_der(dl, v), P_mul(P_mul(s.g[v], s.sgi), dF), -1))
        return out
    def to_phi(s, X): return [P_scale(P_mul(s.A, X.get(1 << m, {})), SIG[m]) for m in range(4)]         # phi_mu = eta_mumu A X^mu
    def to_X(s, ph): return {1 << a: P_scale(P_mul(s.Ai, ph[a]), SIG[a]) for a in range(4) if ph[a]}    # X^a = eta_aa phi_a / A
def sum_P(ps):
    acc = {}
    for p in ps: acc = P_add(acc, p)
    return acc
def neg_P(ph): return [P_scale(p, -1) for p in ph]

# ================================================================================================ (1) the FRW frame
head('(1) [frw.FRAME] the FRW frame e^a = eta^2 dx^a on the labels, exactly in the chart (Laurent polynomials in eta)')
FRW = exact_setup([mono(4, (2, 0, 0, 0), 1)] * 4, 4, SIG)
DS = exact_setup([mono(4, (-1, 0, 0, 0), -1)] * 4, 4, SIG)                    # de Sitter, H = 1
e6 = lambda c, k=-6: {(k, 0, 0, 0): Fr(c)} if c else {}
ok_r = FRW['torsion_free'] and all(FRW['ric'][(a, b)] == e6(6 if a == b else 0) for a in range(4) for b in range(4))
endo = [scale(FRW['ric'][(b, b)], SIG[b]) for b in range(4)]
not_ein = endo[0] != endo[1]                                                 # Ric^b_d = sq_b R_bd = diag(6, -6, -6, -6) eta^-6
Rs = sum_polys(endo)
Gab = {(a, b): padd(FRW['ric'][(a, b)], scale(Rs, Fr(-1, 2) * SIG[a])) if a == b else FRW['ric'][(a, b)] for a in range(4) for b in range(4)}
dust = Rs == e6(-12) and all(Gab[(a, b)] == e6(12 if a == b == 0 else 0) for a in range(4) for b in range(4))
rng = random.Random(4053); ok_wz = True
for k in range(2):
    X = {1 << a: rpol(rng, 4, 2) for a in range(4)}
    ok_wz &= same(D_exact(FRW, D_exact(FRW, X)), lin((1, box_exact(FRW, X)), (-1, ric_on(FRW, X))))
for a in range(4):
    X = hom(TS, a); ok_wz &= same(D_exact(FRW, D_exact(FRW, X)), lin((1, box_exact(FRW, X)), (-1, ric_on(FRW, X))))
chk('bit', ok_r and not_ein and dust, 'frw.FRAME: e^a = eta^2 dx^a is torsion-free with R_ab = 6 eta^-6 delta_ab exactly in the chart: the Ricci endomorphism Ric^b_d = eta^bb R_bd = diag(6, -6, -6, -6) eta^-6 is not a multiple of the identity (not Einstein); R = -12 eta^-6 and G_ab = 12 eta^-6 delta_a0 delta_b0, pressureless dust (a = eta^2, a ~ t^(2/3))')
chk('bit', ok_wz, 'frw.FRAME: the Weitzenboeck formula D^2 X = box X - Ric X on the FRW frame exactly, on two random polynomial 1-forms (degree 2, all components) and on eta^t gamma_a (a = 0..3) with the exponent t free (coefficients in Q[t])')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (2) the solutions of (3.10)
head('(2) [frw.SOL] the solutions of the wave equation (3.10), box X = 0, on the FRW frame')
IND_FRW = {0: QR([-12, 3, 1]), 1: QR([-4, 3, 1])}
ok_ind = all(box_exact(FRW, hom(TS, a)) == {1 << a: {(TS - 6, 0, 0, 0): IND_FRW[min(a, 1)]}} for a in range(4))
chk('bit', ok_ind, 'frw.SOL: box(eta^t gamma_0) = (t^2 + 3t - 12) eta^(t-6) gamma_0 and box(eta^t gamma_i) = (t^2 + 3t - 4) eta^(t-6) gamma_i = (t - 1)(t + 4) eta^(t-6) gamma_i (i = 1, 2, 3), exactly as polynomials in the free exponent t: the homogeneous solutions are eta gamma_i, eta^-4 gamma_i (Laurent) and eta^t gamma_0 with t^2 + 3t - 12 = 0, t = (-3 +- sqrt 57)/2 (irrational)')
NON = {None: hom(2, 1), T57.m: hom(T57 + 1, 0), T21.m: hom(T21 + 1, 0), T13.m: hom(T13 + 1, 1)}   # non-solutions in each ring (box != 0)
def use(X, ring_m):
    """the 1-form handed to a line that requires a solution of (3.10); NONSOL adds a non-solution"""
    return mvp_add(X, NON[ring_m]) if fault('NONSOL') else X
HOMF = [('eta gamma_%d' % i, hom(1, i), None) for i in (1, 2, 3)] + [('eta^-4 gamma_%d' % i, hom(-4, i), None) for i in (1, 2, 3)] + [('eta^t gamma_0', hom(T57, 0), T57.m)]
famL = solutions(FRW, range(-8, 9))                                          # integer weights
famQ = solutions(FRW, [T57 + k for k in range(-3, 6)])                       # weights t + k in Q(sqrt 57)
dimsL = {w: len(v) for w, v in famL.items()}; dimsQ = {(w - T57).c[0] if (w - T57).c else 0: len(v) for w, v in famQ.items()}
FAML = [X for w in sorted(famL) for X in famL[w]]; FAMQ = [X for w in famQ for X in famQ[w]]
print('    null space of box by weight (eta-exponent + x-degree), x-degree <= 2: Laurent %s; Q(sqrt 57), weight t + k: %s' % (dimsL, {int(k): v for k, v in dimsQ.items()}), flush=True)
ok_dims = dimsL == {-4: 3, -3: 9, -2: 18, 1: 3, 2: 9, 3: 18} and dimsQ == {0: 1, 1: 3, 2: 6}
ALLF = [(l, X, m) for l, X, m in HOMF] + [('Laurent family', X, None) for X in FAML] + [('Q(sqrt 57) family', X, T57.m) for X in FAMQ]
ok_sol = all(box_exact(FRW, use(X, m)) == {} for l, X, m in ALLF)
chk('bit', ok_dims and ok_sol, 'frw.SOL: box X = 0 exactly on the 7 homogeneous solutions and on the families of x-degree <= 2: the null space of box in each weight class (computed for the integer weights -8..8 and the weights t + k, k = -3..5) is 3 C(k+2, 2) Laurent solutions with top part eta^1 or eta^-4 times an x-monomial of degree k times gamma_i (60 in all) and C(k+2, 2) in Q(sqrt 57) with top part eta^t x^m gamma_0 (10), none at other weights; %d solutions in all' % len(ALLF))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (3) D^2 and D^4 on the solutions
head('(3) [frw.D4] D^2 X, D^4 X (D applied four times) and box(Ric X) on the solutions, exactly')
RES = []                                                                     # (label, X, ring, D2X, D4X, RicX, Ric2X, boxRicX)
for l, X0, m in ALLF:
    X = use(X0, m); D2 = D_exact(FRW, D_exact(FRW, X)); D4 = D_exact(FRW, D_exact(FRW, D2))
    RX = ric_on(FRW, X); RES.append((l, X, m, D2, D4, RX, ric_on(FRW, RX), box_exact(FRW, RX)))
ok_d2 = all(same(D2, lin((-1, RX))) for l, X, m, D2, D4, RX, R2, BR in RES)
chk('bit', ok_d2, 'frw.D4: D^2 X = -Ric X exactly on all %d solutions (Weitzenboeck with box X = 0): on the solutions of (3.10) the D^2 terms act by the endomorphism -Ric, tensorial' % len(RES))
pred = lambda R2, BR: R2 if fault('D4RIC2') else lin((1, R2), (-1, BR))
ok_d4 = all(same(D4, pred(R2, BR)) for l, X, m, D2, D4, RX, R2, BR in RES)
chk('bit', ok_d4, 'frw.D4: D^4 X = Ric^2 X - box(Ric X) exactly on all %d solutions, D applied four times on the labels%s' % (len(RES), ' [fault D4RIC2: claimed D^4 X = Ric^2 X]' if fault('D4RIC2') else ''))
def mono_ratio(A, B):
    """A = r B for two single-monomial fields with the same monomial: r; otherwise None"""
    if len(A) != 1 or len(B) != 1: return None
    (S, p), = A.items(); (S2, q), = B.items()
    if S != S2 or len(p) != 1 or len(q) != 1: return None
    (k, v), = p.items(); (k2, w), = q.items()
    return v / w if k == k2 else None
ratios = [(l, mono_ratio(D4, R2)) for l, X, m, D2, D4, RX, R2, BR in RES[:7]]
rk_L = rank_of([BR for l, X, m, D2, D4, RX, R2, BR in RES if l == 'Laurent family']); rk_Q = rank_of([BR for l, X, m, D2, D4, RX, R2, BR in RES if l == 'Q(sqrt 57) family'])
hom_nz = all(BR != {} for l, X, m, D2, D4, RX, R2, BR in RES[:7])
print('    on the homogeneous solutions D^4 X = r Ric^2 X with r = ' + '; '.join('%s: %s' % (l, r) for l, r in ratios), flush=True)
ok_ratio = [r for l, r in ratios] == [2, 2, 2, 12, 12, 12, QR([-2, 2], T57.m)]
chk('bit', hom_nz and rk_L == len(FAML) and rk_Q == len(FAMQ) and ok_ratio, 'frw.D4: box(Ric X) != 0: X -> box(Ric X) has rank %d on the %d-dimensional Laurent family and %d on the %d-dimensional Q(sqrt 57) family, so D^4 X != Ric^2 X on every non-zero solution of them; on the homogeneous ones D^4 X = 2 Ric^2 X (eta gamma_i), 12 Ric^2 X (eta^-4 gamma_i), (2t - 2) Ric^2 X = (-5 +- sqrt 57) Ric^2 X (eta^t gamma_0)' % (rk_L, len(FAML), rk_Q, len(FAMQ)))
Y = use(lin((1, hom(1, 1)), (-1, hom(-4, 1))), None)
D2Y = D_exact(FRW, D_exact(FRW, Y)); D4Y = D_exact(FRW, D_exact(FRW, D2Y))
ok_loc = at_eta1(Y) == {} and at_eta1(D2Y) == {} and at_eta1(D4Y) == {2: {(0, 0, 0): Fr(-360)}}
chk('bit', ok_loc and box_exact(FRW, Y) == {}, 'frw.D4: D^4 is not tensorial on the solutions: Y = eta gamma_1 - eta^-4 gamma_1 solves (3.10) and vanishes on the hypersurface eta = 1, D^2 Y = -Ric Y vanishes there too, but D^4 Y = -360 gamma_1 there: no endomorphism field E has D^4 X = E X on the solutions (D^4 X has the factor 72 eta^-12 on eta gamma_1 and 432 eta^-12 on eta^-4 gamma_1)')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (4) the orders in mu
head('(4) [frw.SER] the series of shifted_einstein.py (se.SER) and the residual by order in mu on the FRW solutions')
NS = SEN['NS']; s_mul, s_lin, s_exp, closed_c = SEN['s_mul'], SEN['s_lin'], SEN['s_exp'], SEN['closed_c']
KAP = {(1, 0): Fr(1)}; ONE = {(0, 0): Fr(1)}                                # the six lines that assemble the series in shifted_einstein.py, restated
Dser = [{}, dict(ONE)] + [{} for _ in range(NS - 1)]
em, ep = s_exp(-1), s_exp(1); sinh_ = s_lin((Fr(1, 2), ep), (Fr(-1, 2), em))
Dp = s_lin((1, Dser), (KAP, em)); Dm = s_lin((1, Dser), ({(1, 0): Fr(-1)}, ep)); Ds = s_lin((1, Dser), (KAP, sinh_))
Fa = [x if j % 2 == 0 else {} for j, x in enumerate(s_mul(Dp, Dp))]; Fb = s_mul(Dp, Dm); Fc = s_mul(Ds, Ds); D2s = s_mul(Dser, Dser)
G = {'a': s_lin((1, Fa), (-1, D2s)), 'b': s_lin((1, Fb), (-1, D2s)), 'c': s_lin((1, Fc), (-1, D2s))}       # Ricci_xx - Ricci = sum_j c_j D^2j
ok_cl = all(G[x][2 * j] == closed_c(x, j) for x in 'abc' for j in range(NS // 2 + 1)) and all(not G[x][2 * j + 1] for x in 'abc' for j in range(NS // 2))
def C(x, j, k):
    """the mu^k coefficient of C_j(mu) = c_j kappa^(2j-2) (homogeneity: kappa^i tau^k with i + 2j - 2 = k)"""
    for (i, kk), v in G[x][2 * j].items(): assert i + 2 * j - 2 == kk
    return G[x][2 * j].get((k + 2 - 2 * j, k), Fr(0))
orders = {(x, j): sorted(kk for (i, kk) in G[x][2 * j]) for x in 'abc' for j in range(1, NS // 2 + 1)}
ok_ord = all(orders[(x, j)] == ([2 * j - 1] if x == 'b' else [2 * j - 1, 2 * j]) for x in 'abc' for j in range(1, NS // 2 + 1))
mu3 = [C(x, 2, 3) for x in 'abc']
chk('bit', ok_cl and ok_ord and mu3 == [Fr(-1, 3), Fr(-1, 3), Fr(1, 3)], 'frw.SER: the three operators Ricci_xx - Ricci = sum_j c_j D^2j (se.SER, to D^%d, equal to its closed forms): C_j(mu) = c_j kappa^(2j-2) has the mu-orders 2j - 1 and 2j only (2j - 1 only for D_+ D_-), j = 1..%d, so the order mu^k term is C_j^(k) D^2j with j = ceil(k/2): orders mu^1, mu^2 are the D^2 terms and mu^3, mu^4 the D^4 term, whose mu^3 coefficient is -1/3, -1/3, +1/3 (c(D_+^2), D_+ D_-, D_s^2)' % (NS, NS // 2))
KMAX = 4
def residual(x, k, Xs):
    """R^(k) X = sum_j C_j^(k) D^2j X (kappa = 1), from Xs = [X, D^2 X, D^4 X, ...]"""
    return lin(*[(C(x, j, k), Xs[j]) for j in range(len(Xs)) if C(x, j, k)])
ok_ten = True; ok_k3 = True
for l, X, m, D2, D4, RX, R2, BR in RES:
    for x in 'abc':
        assert all(C(x, j, k) == 0 for k in range(KMAX + 1) for j in range(3, NS // 2 + 1))   # j >= 3 enters from mu^5
        for k in range(3):
            ok_ten &= same(residual(x, k, [X, D2, D4]), lin((C(x, 0, k), X), (-C(x, 1, k), RX)))
        ok_k3 &= same(residual(x, 3, [X, D2, D4]), lin((C(x, 2, 3), pred(R2, BR))))
cert = {x: [at_eta1(residual(x, k, [Y, D2Y, D4Y])) for k in range(KMAX + 1)] for x in 'abc'}
ok_cert = all(cert[x][k] == {} for x in 'abc' for k in range(3)) and [cert[x][3] for x in 'abc'] == [{2: {(0, 0, 0): Fr(120)}}, {2: {(0, 0, 0): Fr(120)}}, {2: {(0, 0, 0): Fr(-120)}}]
print('    the residual of the order-mu^k term on Y (zero on eta = 1), at eta = 1, k = 0..4: ' + '; '.join('Ricci_%s: %s' % ({'a': '++', 'b': '+-', 'c': 'ss'}[x], ', '.join(str(c.get(2, {}).get((0, 0, 0), 0)) for c in cert[x])) for x in 'abc'), flush=True)
chk('bit', ok_ten and ok_k3 and ok_cert, 'frw.SER: on all %d FRW solutions and for the three operators, the residual by order R^(k) X = sum_j C_j^(k) D^2j X is the endomorphism (C_0^(k) - C_1^(k) Ric) applied to X for k = 0, 1, 2 (the D^2 terms: tensorial through order mu^2), and at k = 3 it is C_2^(3) (Ric^2 X - box(Ric X)): on Y, zero on eta = 1, R^(3) Y = +-120 gamma_1 there: the restriction to (3.10) fails at the D^4 term, order mu^3, on actual solutions of (3.10)' % len(RES))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (5) the standard route
head('(5) [frw.STD] coordinate index calculus, no label: Christoffel symbols, Ricci, rough Laplacian, Hodge Laplacian (divergence formula), exact')
SF = Conf(mono(4, (2, 0, 0, 0), 1)); SD = Conf(mono(4, (-1, 0, 0, 0), -1))
def ind_std(S, a):
    ph = S.to_phi(hom(TS, a)); return S.to_X(S.rough(ph))
ok_ind_std = all(ind_std(SF, a) == {1 << a: {(TS - 6, 0, 0, 0): IND_FRW[min(a, 1)]}} for a in range(4))
chk('std', ok_ind_std, 'frw.STD: the rough Laplacian g^mn nabla_m nabla_n phi of the coordinate 1-form phi = eta_aa eta^2 eta^t dx^a (index calculus on g = eta^4 diag(1,-1,-1,-1), t free) gives the same indicial polynomials t^2 + 3t - 12 (gamma_0) and (t - 1)(t + 4) (gamma_i)')
def std_vs_bit(S, rows):
    ok = True; nb = 0
    for l, X, m, D2, D4, RX, R2, BR in rows:
        ph = S.to_phi(X); lap = S.hodge(ph); rph = S.ric(ph)
        ok &= S.rough(ph) == [{}] * 4                                            # nabla^2 phi = 0
        ok &= same(S.to_X(rph), RX) and same(S.to_X(neg_P(lap)), D2)            # Ric(phi), D^2 X = -Delta_g phi
        ok &= same(S.to_X(S.hodge(lap)), D4) and same(S.to_X(S.rough(rph)), BR)  # D^4 X = Delta_g^2 phi, box(Ric X) = nabla^2 Ric(phi)
        ok &= same(S.to_X(lap), RX)                                              # Delta_g phi = Ric(phi) on a solution
        nb += 1
    return ok, nb
ok_sb, nsb = std_vs_bit(SF, RES)
chk('bit==std', ok_sb, 'frw.STD: on all %d FRW solutions the index route gives nabla^2 phi = 0, Delta_g phi = Ric(phi), and the label values agree exactly: Ric X = Ric(phi), D^2 X = -Delta_g phi, D^4 X = Delta_g(Delta_g phi), box(Ric X) = nabla^2 Ric(phi) (X^a = eta_aa phi_a / A, A = eta^2)' % nsb)
# numpy, floats, no exact arithmetic: the Atlas's Std (finite differences, 4-point stencils) at a point, the exponents as floating-point numbers
Std = SEN['Std']
def num(v, tv): return sum(float(c) * tv ** i for i, c in enumerate(v.c)) if isinstance(v, QR) else float(v)
def num_field(X, tv, pt):
    terms = [(S.bit_length() - 1, num(v, tv), [num(e, tv) for e in ex]) for S, p in X.items() for ex, v in p.items()]
    def f(dx):
        x = pt + dx; out = np.zeros(4)
        for a, c, ex in terms: out[a] += c * np.prod([x[i] ** ex[i] for i in range(4)])
        return out
    return f
def np_route(row, tv, pt):
    """box X, D^2 X + Ric X, D^2(D^2 X) - D^4 X and box(Ric X) - (exact), at the point, by finite differences on the closed-form FRW frame"""
    l, X, m, D2, D4, RX, R2, BR = row; x0 = np.zeros(4); ef = lambda dx: (pt[0] + dx[0]) ** 2 * np.eye(4)
    s = Std(ef, SIG, num_field(X, tv, pt)); s2 = Std(ef, SIG, num_field(D2, tv, pt)); s3 = Std(ef, SIG, num_field(RX, tv, pt))
    ric_ = s.frame_vec(x0, s.ricci(x0) @ np.linalg.inv(s.g(x0)) @ s.phi(x0))
    vals = [s.frame_vec(x0, s.rough(x0)), s.frame_vec(x0, -s.hodge(x0)) + ric_, s2.frame_vec(x0, -s2.hodge(x0)) - num_field(D4, tv, pt)(x0),
            s3.frame_vec(x0, s3.rough(x0)) - num_field(BR, tv, pt)(x0)]
    sc = max(1.0, float(np.max(np.abs(num_field(D4, tv, pt)(x0)))))
    return max(float(np.max(np.abs(v))) for v in vals) / sc, float(np.max(np.abs(num_field(BR, tv, pt)(x0)))) / sc
NPROWS = [(RES[6], tv, np.array([1.3, 0.0, 0.0, 0.0])) for tv in ((-3 + math.sqrt(57)) / 2, (-3 - math.sqrt(57)) / 2)] + \
         [(RES[i], 0.0, np.array([1.3, 0.0, 0.0, 0.0])) for i in (0, 3)] + \
         [(next(r for r in RES if r[0] == 'Laurent family' and any(sum(ex[1:]) == 2 for p in r[1].values() for ex in p)), 0.0, np.array([1.3, 0.2, -0.3, 0.5])),
          (next(r for r in RES if r[0] == 'Q(sqrt 57) family' and any(sum(ex[1:]) == 2 for p in r[1].values() for ex in p)), (-3 + math.sqrt(57)) / 2, np.array([1.3, 0.2, -0.3, 0.5]))]
npres = [np_route(*a) for a in NPROWS]; dev_np = max(r[0] for r in npres); size_br = min(r[1] for r in npres)
chk('std', dev_np < 1e-6 and size_br > 1e-2, 'frw.STD: numpy, floats (the Atlas\'s Std, 4-point stencils, h = 1e-3) on the closed-form frame eta^2 at eta = 1.3: on eta^t gamma_0 with t = (-3 + sqrt 57)/2 and (-3 - sqrt 57)/2 as floats, eta gamma_1, eta^-4 gamma_1 and two x-dependent family members (x-degree 2, at x = (0.2, -0.3, 0.5)): box X = 0, D^2 X = -Ric X, D^2 of the exact D^2 X equals the exact D^4 X, box of the exact Ric X equals the exact box(Ric X), to %.1e (relative), while |box(Ric X)| / |D^4 X| >= %.2f' % (dev_np, size_br))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (6) de Sitter, the control
head('(6) [ds.CTL] de Sitter e^a = -dx^a/eta (H = 1, Lambda = 3), the same computation')
LAM = 3
IND_DS = {0: QR([-3, -3, 1]), 1: QR([-1, -3, 1])}
ok_ind_ds = all(box_exact(DS, hom(TS, a)) == {1 << a: {(TS, 0, 0, 0): IND_DS[min(a, 1)]}} for a in range(4)) and all(ind_std(SD, a) == {1 << a: {(TS, 0, 0, 0): IND_DS[min(a, 1)]}} for a in range(4))
fam21 = solutions(DS, [T21 + k for k in range(-3, 6)]); fam13 = solutions(DS, [T13 + k for k in range(-3, 6)])
d21 = {int((w - T21).c[0]) if (w - T21).c else 0: len(v) for w, v in fam21.items()}; d13 = {int((w - T13).c[0]) if (w - T13).c else 0: len(v) for w, v in fam13.items()}
print('    null space of box by weight t + k, x-degree <= 2: Q(sqrt 21) %s; Q(sqrt 13) %s' % (d21, d13), flush=True)
HOMD = [('eta^t gamma_0', hom(T21, 0), T21.m)] + [('eta^t gamma_%d' % i, hom(T13, i), T13.m) for i in (1, 2, 3)]
ALLD = HOMD + [('Q(sqrt 21) family', X, T21.m) for w in fam21 for X in fam21[w]] + [('Q(sqrt 13) family', X, T13.m) for w in fam13 for X in fam13[w]]
RESD = []
for l, X0, m in ALLD:
    X = use(X0, m); D2 = D_exact(DS, D_exact(DS, X)); D4 = D_exact(DS, D_exact(DS, D2)); D6 = D_exact(DS, D_exact(DS, D4))
    RX = ric_on(DS, X); RESD.append((l, X, m, D2, D4, D6, RX, ric_on(DS, RX), box_exact(DS, RX), box_exact(DS, X)))
ok_dsol = d21 == {0: 1, 1: 3, 2: 6} and d13 == {0: 3, 1: 9, 2: 18} and all(bX == {} for *_, bX in RESD)
chk('bit', ok_ind_ds and ok_dsol, 'ds.CTL: box(eta^t gamma_0) = (t^2 - 3t - 3) eta^t gamma_0, box(eta^t gamma_i) = (t^2 - 3t - 1) eta^t gamma_i with t free (labels and index route): the solutions of (3.10) are eta^t gamma_0 in Q(sqrt 21), eta^t gamma_i in Q(sqrt 13), and their families of x-degree <= 2 (box keeps the weight): C(k+2, 2) and 3 C(k+2, 2) at weight t + k, k = 0, 1, 2 (10 and 30); box X = 0 exactly on all %d' % len(RESD))
ok_dd = all(same(D2, lin((LAM, X))) and same(D4, lin((LAM ** 2, X))) and same(D4, R2) and same(D6, lin((LAM ** 3, X))) and BR == {} for l, X, m, D2, D4, D6, RX, R2, BR, bX in RESD)
chk('bit', ok_dd, 'ds.CTL: on all %d de Sitter solutions D^2 X = Lambda X, D^4 X = Lambda^2 X = Ric^2 X, D^6 X = Lambda^3 X and box(Ric X) = 0 exactly (D applied two, four and six times): D^2 X is again a solution, so D^2j X = Lambda^j X for every j' % len(RESD))
ok_dser = True
for l, X, m, D2, D4, D6, RX, R2, BR, bX in RESD:
    for x in 'abc':
        for k in range(7):
            num = sum((C(x, j, k) * LAM ** j for j in range(4)), Fr(0))
            ok_dser &= all(C(x, j, k) == 0 for j in range(4, NS // 2 + 1)) and same(residual(x, k, [X, D2, D4, D6]), lin((num, X)))
ok_sbd, nsbd = std_vs_bit(SD, [(l, X, m, D2, D4, RX, R2, BR) for l, X, m, D2, D4, D6, RX, R2, BR, bX in RESD])
chk('bit', ok_dser, 'ds.CTL: the residual of each of the three operators at every order computed, mu^0 ... mu^6 (D^2, D^4, D^6), is a number times X on every de Sitter solution: the restriction to (3.10) is consistent order by order, as ATY-053 says')
chk('bit==std', ok_sbd, 'ds.CTL: the index route on g = eta^-2 diag(1,-1,-1,-1) agrees exactly on all %d: nabla^2 phi = 0, Delta_g phi = Ric(phi) = -Lambda phi, D^2 X = -Delta_g phi, D^4 X = Delta_g^2 phi, box(Ric X) = nabla^2 Ric(phi) = 0' % nsbd)
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ controls
if FAULT is None:
    head('[ctl] wrong versions that must fail')
    chk('ctl', all(not same(D4, R2) for l, X, m, D2, D4, RX, R2, BR in RES), 'frw.D4: control: the claim D^4 X = Ric^2 X (the commuting reading carried to the FRW frame) fails on every one of the %d FRW solutions' % len(RES))
    bad = []
    for N, d, S in ((NON[None], FRW, SF), (NON[T57.m], FRW, SF), (NON[T21.m], DS, SD), (NON[T13.m], DS, SD)):
        bN = box_exact(d, N); D2N = D_exact(d, D_exact(d, N)); bad.append(bN != {} and not same(D2N, lin((-1, ric_on(d, N)))) and same(lin((1, D2N), (1, ric_on(d, N))), bN))
    chk('ctl', all(bad), 'frw.SOL: control: the non-solutions eta^2 gamma_1, eta^(t+1) gamma_0 (FRW) and eta^(t+1) gamma_0, eta^(t+1) gamma_1 (de Sitter) have box X != 0, and D^2 X + Ric X = box X != 0: the tensorial D^2 needs (3.10)')
finish('SHIFTED-FRW4')
