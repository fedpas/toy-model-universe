#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_gradient2.py -- ATY-046 (the shifted Dirac equation of Atiyah and Moore in a potential with a gradient) from first to second order in g.

Statement.  O_g[P] = bD_g(P) J - m P + kappa exp(-tau bD_g)(P) J, bD_g = bD + g V_1 + g^2 V_2, in the conventions of shifted_tensor.py (labels of
Cl(1,3), J = gamma_2 gamma_1, fields at rest sum_d x_3^d W_d e^{J b0 t}, bD = gamma_0 (d_t .) gamma_0 + gamma^3 (d_3 .) gamma_0).  For A_0 = g x_3 (charge 1:
V_1 = x_3 gamma_0 (.) J gamma_0, V_2 = 0) and for Phi = g x_3 (the frame of shifted_tensor.py's matrix route, N^{-1/2} (N^{-1} G^0 d_t + G^3 d_3) N^{1/2},
N = sqrt(1 - 2 g x_3), the frame of ATY-037 with its connection term: V_1 = x_3 G^0 d_t - G^3/2, V_2 = (3/2) x_3^2 G^0 d_t - x_3 G^3), on a quantized rest
mode P_0 = Z e^{sigma J E t} (E tau = (n + 1/2) pi, E = m + (-1)^n kappa; Z in the half of mass E; the settings of st.SOL, sigma = -1 and +1):
 (a) the second-order solution P_0 + g P_1 + g^2 P_2 of the ordinary equation bD_g(P) J = E P with the same coupled operator (degrees 3 and 6 in x_3, by
     exact rational elimination) solves the shifted equation at second order exactly in Q[pi]: O_0[P_2] + O_1[P_1] + O_2[P_0] = 0, where
     O_2 = V_2 J + kappa U_2(tau) J and U_2 is the second-order Dyson term of exp(-s bD_g), double integral included:
       U_2(s) = -int_0^s du e^{-(s-u) bD} V_2 e^{-u bD} + int_0^s du int_0^u dv e^{-(s-u) bD} V_1 e^{-(u-v) bD} V_1 e^{-v bD};
 (b) the reason, run to second order: sum_{i+j=k} U_i[P_j](s) = P_k e^{J E s} (k = 0, 1, 2) as functions of s, so O_g[P] = P f_J(E) + O(g^3) with
     f_J(E) = E - m + kappa J e^{J E tau}, zero at the quantized E;
 (c) the mixing.  With P_1, P_2 normalized to have no part in the mode's half at degrees 0 and 1 (this fixes the free solutions, all of degree <= 1)
     and B = gamma^3 Z gamma_0 (in the other half):
       A_0: P_1 = -sigma [(E/3) x_3^3 Z + (1/2) x_3^2 B J],          P_2 = (E^2 x_3^6/45 - x_3^4/8) Z + (E/15) x_3^5 B J;
       Phi: P_1 = -(E^2/3) x_3^3 Z - (E x_3^2/2 + 1/(4E)) B J,      P_2 = (E^4 x_3^6/45 - 11 E^2 x_3^4/24 + x_3^2/4) Z + (E^3 x_3^5/15 - 7 E x_3^3/12 - x_3/(8E)) B J;
     the B J terms are the parts in the other half (the advanced half for P_0 = Z e^{-J E t}, Z in P_+): ATY-046's (1/2) x_3^2 B J at first order, and at
     second order (E/15) x_3^5 B J for A_0, a polynomial of degree 5 for Phi; the same for the shifted equation, whose solution this is.
Routes.
 [bit]  Exact Q[pi] on the labels.  exp(-s bD) on fields at rest of any degree: bD^2 = -E^2 + L with L = -d_3^2 nilpotent, so
        exp(-s bD) = sum_j L^j (c_j(s) - d_j(s) bD) with c = cos(s w), d = sin(s w)/w, w = sqrt(E^2 - L) expanded in L (quasi-polynomials z s^p e^{J w s},
        shifted_tensor.py's degree <= 3 formula is j <= 1); the Duhamel convolutions int_0^s A(s-u) B(u) du of quasi-polynomials in closed form; values at
        s = tau exact on the quarter turns.  Validated against shifted_tensor.py's pexp and duhamel (degree <= 3, first order) and, independently of the
        Dyson formula, by the differentiated equations U_k' = -bD U_k - V_1 U_{k-1} - V_2 U_{k-2}, U_k(0) = delta_k0, exactly as functions of s on degree-7
        fields.  The ordinary P_1, P_2 by exact elimination over Q (the constrained system has nullity 0: the normalized solutions are unique).
 [std]  numpy and scipy, never the labels: complex 4 x 4 Dirac matrices on x_3-polynomials of degree <= 10 times a plane wave (shifted_tensor.py's Dmat,
        Omat: A_0 exactly, the frame through truncated binomial series), scipy expm of the whole operator, five-point differences in g (h = 5e-4) for the
        first and second g-derivatives, numpy lstsq for the ordinary psi_1, psi_2: rest waves at the four settings, both signs, and three moving waves.
 [bit==std] the exact O_0[P_2], O_1[P_1], O_2[P_0] equal the matrix ones on the same fields, through the dictionary Z -> M(Z) u0 (J -> i).
Controls.  Each wrong version is a --fault option that puts it into the main exact lines (the run must then end with FAILS and exit 1); the [ctl] line
        runs all of them on every case:
        FREESHIFT  the shift built with the free bD (no g inside the shift);   NODYSON2  the second-order Dyson term U_2 dropped;
        NODOUBLE   only its double integral dropped (for A_0 the same);        NOCOMM    x_3 treated as a constant inside the shift (no d_3 there).
Scope.  Second order in g; static linear potentials A_0 = g x_3 and Phi = g x_3 (the frame to second order in its vierbein form); fields at rest of one
        quantized frequency, polynomials in x_3 (the solutions of degree <= 6; the Dyson identities on degree <= 7); the four settings of st.SOL at quarter-
        turn shifts, both signs of the frequency; formal power series in g (the polynomial solutions grow in x_3, as for the ordinary equation).  The
        solutions run are the ordinary ones; whether the shifted equation in a field has others is not settled.  No time-dependent field, no Fock space,
        no claim about nature.
Definitions.  shifted_tensor.py runs its checks at import, so its definitions (the names in WANT) are taken from its syntax tree with ast and executed
        alone, with every one of its faults switched off; coupling_selfcheck.py is imported (its checks run only under __main__).  Read only.
Run:    python3 shifted_gradient2.py [--fault FREESHIFT|NODYSON2|NODOUBLE|NOCOMM]
        (next to shifted_tensor.py in selfcheck/proofs/, or from v4_work/shifted_view/checks/; also under -I -B)"""
import os, sys, time, math, random, ast
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm

T0 = time.time()
# ------------------------------------------------------------------------------------------------ check lines and faults
FAULTS = ('FREESHIFT', 'NODYSON2', 'NODOUBLE', 'NOCOMM')
FAULT = None
if '--fault' in sys.argv:
    i_ = sys.argv.index('--fault'); FAULT = sys.argv[i_ + 1] if i_ + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT, flush=True)
FAILS = []; NCHK = [0]
def chk(tag, cond, msg):
    cond = bool(cond); NCHK[0] += 1; print('%s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append(tag + ': ' + msg[:60])
    return cond

# ------------------------------------------------------------------------------------------------ the Atlas's definitions, taken by ast
# shifted_tensor.py runs its checks at import; its definitions (Q[pi], the labels, the polynomial fields at rest, the first-order Duhamel term,
# the exact elimination, the Dirac-matrix operators) are taken from its syntax tree and executed alone, with every fault switched off.
_here = os.path.dirname(os.path.abspath(__file__))
_cands = [os.path.join(os.path.abspath(a_), 'proofs', 'shifted_tensor.py') for i_a, a_ in enumerate(sys.argv[1:], 1) if not a_.startswith('--') and sys.argv[i_a - 1] != '--fault'] + [os.path.join(_here, 'shifted_tensor.py'),
          os.path.normpath(os.path.join(_here, '..', '..', '..', 'v4', 'one-rule', 'checks', 'selfcheck', 'proofs', 'shifted_tensor.py'))]
ST_PATH = next((p_ for p_ in _cands if os.path.isfile(p_)), None)
if ST_PATH is None: raise SystemExit('shifted_tensor.py not found (looked in %s)' % ', '.join(_cands))
_selfcheck = os.path.dirname(os.path.dirname(ST_PATH))
if not os.path.isfile(os.path.join(_selfcheck, 'coupling_selfcheck.py')): raise SystemExit('coupling_selfcheck.py not found in ' + _selfcheck)
if _selfcheck not in sys.path: sys.path.insert(0, _selfcheck)
import coupling_selfcheck as cs
WANT = ('QP PI ZERO UNIT SQ pc mmul mlin mrev blade ONE GAM G0 _Jm _Js J GUP G0J EVEN scal zre zim zc phase fmt_q fmt_z rand_mv PPLUS PMINUS '
        'pf_add pf_map pD pL px3 prm trig pexp sf_mul sf_trig sf_int _qpow sf_scale sf_add duhamel V_el V_gr O1_sh O0_sh O0_ord O1_ord solve_q '
        'halves GRADS S1 S2 S3 I2 GM I4 GU BLM U0 Mof cmat kvec binom_series pmul_mat Dmat Omat').split()
def _take(path):
    tree = ast.parse(open(path, encoding='utf-8').read(), path); body = []; want = set(WANT)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.ClassDef)):
            if node.name in want: body.append(node)
        elif isinstance(node, ast.Assign):
            names = {x.id for t_ in node.targets for x in ast.walk(t_) if isinstance(x, ast.Name)}
            if names and names <= want: body.append(node)
        elif isinstance(node, ast.For):
            if any(isinstance(x, ast.Subscript) and isinstance(x.ctx, ast.Store) and isinstance(x.value, ast.Name) and x.value.id == 'BLM' for x in ast.walk(node)):
                body.append(node)
    ns = {'__builtins__': __builtins__, 'os': os, 'sys': sys, 'math': math, 'random': random, 'Fr': Fr, 'np': np, 'expm': expm, 'cs': cs,
          'fault': lambda name: False}
    exec(compile(ast.Module(body=body, type_ignores=[]), path, 'exec'), ns)
    miss = [k for k in WANT if k not in ns]
    if miss: raise SystemExit('not found in %s: %s' % (path, ', '.join(miss)))
    return ns
ST = _take(ST_PATH)
globals().update({k: ST[k] for k in WANT})

# ------------------------------------------------------------------------------------------------ J-complex rationals and quasi-polynomials in s
# a J-complex rational is a pair (a, b) = a + b J; a quasi-polynomial is {(w, p): z} = sum z s^p e^{J w s} (w, z rational)
def cz(a, b=0): return (Fr(a), Fr(b))
def cmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def csc(x, c): return (x[0] * c, x[1] * c)
def qacc(out, key, z):
    a, b = out.get(key, (Fr(0), Fr(0))); v = (a + z[0], b + z[1])
    if v[0] or v[1]: out[key] = v
    else: out.pop(key, None)
def gbin(a, k):
    r = Fr(1)
    for i in range(k): r = r * (Fr(a) - i) / (i + 1)
    return r
def qint(n, v):
    """int_0^s u^n e^{J v u} du as a quasi-polynomial in s: s^{n+1}/(n+1) for v = 0, else
    e^{J v s} sum_k (-1)^k n!/(n-k)! s^{n-k} (J v)^{-k-1} - (-1)^n n! (J v)^{-n-1}"""
    if v == 0: return {(0, n + 1): cz(Fr(1, n + 1))}
    inv = (Fr(0), Fr(-1) / v); out = {}; fac = Fr(1); ip = inv
    for k in range(n + 1):
        if k: fac *= n - k + 1; ip = cmul(ip, inv)
        qacc(out, (v, n - k), csc(ip, fac * (-1) ** k))
    qacc(out, (0, 0), csc(ip, -fac * (-1) ** n))
    return out
_QC = {}
def qconv(A, B):
    """(A * B)(s) = int_0^s A(s - u) B(u) du for quasi-polynomials A, B"""
    out = {}
    for (a, p), za in A.items():
        for (b, q), zb in B.items():
            z = cmul(za, zb)
            for r in range(p + 1):
                c = gbin(p, r) * (-1) ** r
                for (v, k), zi in qint(r + q, b - a).items(): qacc(out, (v + a, k + p - r), csc(cmul(z, zi), c))
    return out
def qval(w, p, t):
    """t^p e^{J w t} exactly (a J-complex number in Q[pi] on the labels)"""
    return mlin((_qpow(t, p), phase(w, t)))
_EC = {}
def exp_coeffs(E, jmax=5):
    """c_j, d_j with exp(-s bD) = sum_j L^j (c_j(s) - d_j(s) bD) on fields at rest of frequency +-E (bD^2 = -E^2 + L, L = -d_3^2 nilpotent):
    c(s; L) = cos(s w), d(s; L) = sin(s w)/w with w = sqrt(E^2 - L), expanded in L: e^{+-J s w} = e^{+-J E s} exp(+-J s (w - E))"""
    E = Fr(E)
    if (E, jmax) in _EC: return _EC[(E, jmax)]
    dl = {k: E * gbin(Fr(1, 2), k) * (Fr(-1) / (E * E)) ** k for k in range(1, jmax + 1)}           # w - E
    om = {k: gbin(Fr(-1, 2), k) * (Fr(-1) / (E * E)) ** k / E for k in range(jmax + 1)}              # 1/w
    def X(sg):                                                                                   # exp(sg J s (w - E)): {j: {p: z}}
        out = {j: {} for j in range(jmax + 1)}; out[0][0] = cz(1); term = {0: {0: cz(1)}}
        for n in range(1, jmax + 1):
            new = {}
            for j, P in term.items():
                for k, dk in dl.items():
                    if j + k > jmax: continue
                    for p, z in P.items(): qacc(new.setdefault(j + k, {}), p + 1, cmul(z, (Fr(0), sg * dk / n)))
            term = new
            for j, P in term.items():
                for p, z in P.items(): qacc(out[j], p, z)
        return out
    Xp, Xm = X(1), X(-1); c = {}; sr = {}
    for j in range(jmax + 1):
        c[j] = {}; sr[j] = {}
        for p, z in Xp[j].items(): qacc(c[j], (E, p), csc(z, Fr(1, 2))); qacc(sr[j], (E, p), cmul(z, (Fr(0), Fr(-1, 2))))
        for p, z in Xm[j].items(): qacc(c[j], (-E, p), csc(z, Fr(1, 2))); qacc(sr[j], (-E, p), cmul(z, (Fr(0), Fr(1, 2))))
    d = {}
    for j in range(jmax + 1):
        d[j] = {}
        for k in range(j + 1):
            for key, z in sr[j - k].items(): qacc(d[j], key, csc(z, om[k]))
    _EC[(E, jmax)] = (c, d); return c, d

# ------------------------------------------------------------------------------------------------ field-valued quasi-polynomials: {(w, p): F}, F a field at rest
def fq_acc(out, key, F, z=None):
    """out[key] += F z (z a rational J-complex pair, on the right)"""
    G = prm(F, zc(z[0], z[1])) if z is not None else F
    H = pf_add((1, out.get(key, {})), (1, G))
    if H: out[key] = H
    else: out.pop(key, None)
def fq_add(*terms):
    out = {}
    for c, G in terms:
        for k, F in G.items(): fq_acc(out, k, pf_add((c, F)))
    return out
def fq_map(G, f): return {k: H for k, F in G.items() for H in [f(F)] if H}
def fq_at(G, t):
    """the value at s = t, exactly in Q[pi]"""
    out = {}
    for (w, p), F in G.items(): out = pf_add((1, out), (1, prm(F, qval(w, p, t))))
    return out
def fq_deriv(G):
    out = {}
    for (w, p), F in G.items():
        if p: fq_acc(out, (w, p - 1), pf_add((p, F)))
        if w: fq_acc(out, (w, p), prm(F, mlin((w, J))))
    return out
def fq_exp(F, b0, wN=True):
    """s -> exp(-s bD) F exactly, any degree; wN False: x_3 treated as a constant inside the shift (no d_3 in bD, L = 0)"""
    c, d = exp_coeffs(abs(Fr(b0))); out = {}; LF = F
    for j in range(len(c)):
        if j: LF = pL(LF, wN)
        if not LF: break
        DLF = pD(LF, b0, wN)
        for key, z in c[j].items(): fq_acc(out, key, LF, z)
        for key, z in d[j].items(): fq_acc(out, key, DLF, csc(z, -1))
    assert not pL(LF, wN) or j < len(c) - 1, 'degree too high for the L-expansion'
    return out
def conv_exp(G, b0, wN=True):
    """s -> int_0^s exp(-(s - u) bD) G(u) du (the Duhamel convolution), exactly"""
    E = abs(Fr(b0)); c, d = exp_coeffs(E); out = {}
    for (w, p), H in G.items():
        LH = H
        for j in range(len(c)):
            if j: LH = pL(LH, wN)
            if not LH: break
            DLH = pD(LH, b0, wN)
            kc = (E, j, w, p, 'c'); kd = (E, j, w, p, 'd')
            if kc not in _QC: _QC[kc] = qconv(c[j], {(w, p): cz(1)}); _QC[kd] = qconv(d[j], {(w, p): cz(1)})
            for key, z in _QC[kc].items(): fq_acc(out, key, LH, z)
            for key, z in _QC[kd].items(): fq_acc(out, key, DLH, csc(z, -1))
    return out

# ------------------------------------------------------------------------------------------------ the coupled operator to second order
# bD_g = bD + g V_1 + g^2 V_2.  A_0 = g x_3: V_1 = V_el of shifted_tensor.py (x_3 gamma_0 (.) J gamma_0), V_2 = 0 (exact).
# Phi = g x_3: the frame of shifted_tensor.py's matrix route, D_g = N^{-1/2} (N^{-1} G^0 d_t + G^3 d_3) N^{1/2}, N = sqrt(1 - 2 g x_3), is
#   (1 - 2 g x_3)^{-1/2} G^0 d_t + G^3 d_3 - (g/2) (1 - 2 g x_3)^{-1} G^3:
# V_1 = V_gr of shifted_tensor.py (x_3 G^0 d_t - G^3/2), V_2 = (3/2) x_3^2 G^0 d_t - x_3 G^3, on the labels G^0 d_t -> gamma_0 (d_t .) gamma_0, G^3 -> gamma^3 (.) gamma_0.
def V2_gr(F, b0):
    return pf_add((Fr(3, 2), px3(px3(pf_map(F, lambda W: mmul(mmul(G0, mlin((b0, mmul(W, J)))), G0))))), (-1, px3(pf_map(F, lambda W: mmul(mmul(GUP[3], W), G0)))))
def V2_el(F, b0): return {}
POT = {'A_0': (V_el, V2_el), 'Phi': (V_gr, V2_gr)}
def shift_series(F, b0, pot, wrong=None):
    """U_0, U_1, U_2 (functions of s): the coefficients of g^0, g^1, g^2 in exp(-s bD_g) F, by the Dyson series
       U_1(s) = -int_0^s exp(-(s-u) bD) V_1 U_0(u) du,
       U_2(s) = -int_0^s exp(-(s-u) bD) V_2 U_0(u) du + int_0^s du int_0^u dv exp(-(s-u) bD) V_1 exp(-(u-v) bD) V_1 exp(-v bD) F.
    wrong: FREESHIFT (exp(-s bD) with the free bD: U_1 = U_2 = 0), NODYSON2 (U_2 = 0), NODOUBLE (the double integral dropped), NOCOMM"""
    V1, V2 = POT[pot]; wN = wrong != 'NOCOMM'
    U0 = fq_exp(F, b0, wN)
    if wrong == 'FREESHIFT': return U0, {}, {}
    U1 = fq_add((-1, conv_exp(fq_map(U0, lambda H: V1(H, b0)), b0, wN)))
    if wrong == 'NODYSON2': return U0, U1, {}
    single = conv_exp(fq_map(U0, lambda H: V2(H, b0)), b0, wN)
    double = conv_exp(fq_map(conv_exp(fq_map(U0, lambda H: V1(H, b0)), b0, wN), lambda H: V1(H, b0)), b0, wN)
    return U0, U1, fq_add((-1, single), (0 if wrong == 'NODOUBLE' else 1, double))
def Vk(k, F, b0, pot):
    if k == 0: return pD(F, b0)
    return POT[pot][k - 1](F, b0)
def O_ord_k(k, F, b0, pot, E):
    """the g^k part of the ordinary operator bD_g(P) J - E P"""
    out = prm(Vk(k, F, b0, pot), J)
    return pf_add((1, out), (-E, F)) if k == 0 else out
def O_sh_k(k, F, b0, pot, m_, kap, tau, wrong=None, U=None):
    """the g^k part of the shifted operator bD_g(P) J - m P + kappa exp(-tau bD_g)(P) J"""
    U = U or shift_series(F, b0, pot, wrong)
    out = pf_add((1, prm(Vk(k, F, b0, pot), J)), (QP.of(kap), prm(fq_at(U[k], tau), J)))
    return pf_add((1, out), (-m_, F)) if k == 0 else out
def solve_ord(rhs, b0, E, mode_plus, dmax):
    """the solution P (degree <= dmax) of O_ord_0[P] = rhs with no part in the mode's half at degrees 0 and 1 (which fixes the free solutions,
    all of degree <= 1), by exact rational elimination; returns (P, nullity of the constrained system) or (None, nullity)"""
    basis = [(d, e_) for d in range(dmax + 1) for e_ in EVEN]; mb = set(PPLUS if mode_plus else PMINUS); cols = []
    for d, e_ in basis:
        img = O_ord_k(0, {d: blade(e_)}, b0, 'A_0', E); col = {}
        for dd, W in img.items():
            for mm, v in W.items():
                assert v.rational(); col[(dd, mm)] = v.c.get(0, Fr(0))
        if d <= 1 and e_ in mb: col[(-1 - d, e_)] = Fr(1)
        cols.append(col)
    keys = sorted({k for c_ in cols for k in c_} | {(dd, mm) for dd, W in rhs.items() for mm in W})
    assert all(v.rational() for W in rhs.values() for v in W.values())
    def rv(k): return rhs.get(k[0], {}).get(k[1], ZERO).c.get(0, Fr(0)) if k[0] >= 0 else Fr(0)
    M = [[c_.get(k, Fr(0)) for c_ in cols] + [rv(k)] for k in keys]
    n = len(cols); piv = []; r = 0
    for j in range(n):
        pr = next((i for i in range(r, len(M)) if M[i][j] != 0), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]; inv = 1 / M[r][j]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][j] != 0: f_ = M[i][j]; M[i] = [x - f_ * y for x, y in zip(M[i], M[r])]
        piv.append(j); r += 1
    if any(M[i][n] != 0 for i in range(r, len(M))): return None, n - r
    sol = {}
    for i, j in enumerate(piv):
        if M[i][n] != 0: d, e_ = basis[j]; sol = pf_add((1, sol), (M[i][n], {d: blade(e_)}))
    return sol, n - r
def zfac(W, B):
    """the J-complex z with W = B z (B~ B a non-zero scalar), else None"""
    Bt = mrev(B); nb = mmul(Bt, B)
    assert set(nb) <= {0} and nb
    z = {k: v / nb[0] for k, v in mmul(Bt, W).items()}
    if not set(z) <= {0, _Jm} or mmul(B, z) != W: return None
    return z

# ================================================================================================ the checks
print('SHIFTED-GRAD2: ATY-046 from first to second order in g (definitions of shifted_tensor.py taken by ast from %s)' % os.path.relpath(ST_PATH, _here), flush=True)
SETDESC = '(m, kappa, tau) = (3, 2, pi/10) at E = 5, (4, 1, pi/2) at E = 3 and 5, (3, 2, 3 pi/2) at E = 1'
def mode_Z(rg, inplus):
    Z = halves({0: rand_mv(rg)}, True)[0 if inplus else 1].get(0)
    return Z or blade(PPLUS[1] if inplus else PMINUS[1])
POTS = ('A_0', 'Phi')

# ------------------------------------------------------------------------------------------------ [bit] regression against shifted_tensor.py at first order
rg = random.Random(46001); ok_exp = True; ok_d1 = True; ok_st = True; nst = 0
for (m_, kap, tau), E_, n in GRADS:
    for sec in (-1, 1):
        b0 = Fr(sec * E_); inplus = sec == -1
        F = {d: rand_mv(rg) for d in range(4)}
        ok_exp &= fq_at(fq_exp(F, b0, FAULT != 'NOCOMM'), tau) == pexp(F, tau, b0)
        for pot in POTS:
            F0 = {0: rand_mv(rg)}
            ok_d1 &= not pf_add((1, fq_at(shift_series(F0, b0, pot, FAULT)[1], tau)), (1, duhamel(F0, b0, tau, POT[pot][0])))
            P0 = {0: mode_Z(rg, inplus)}; P1, nul = solve_ord(pf_add((-1, O_ord_k(1, P0, b0, pot, E_))), b0, E_, inplus, 5)
            ok_st &= P1 is not None and max(P1) <= 3 and not pf_add((1, O0_sh(P1, b0, m_, kap, tau)), (1, O1_sh(P0, b0, m_, kap, tau, POT[pot][0])))
            nst += 1
chk('bit', ok_exp and ok_d1 and ok_st, 'REG: the general exp(-s bD) (any degree, its L-expansion) at s = tau equals shifted_tensor.py\'s pexp on random fields of degree <= 3, and the first Dyson term U_1(tau) equals minus its duhamel on random degree-0 fields for both potentials (V_el, V_gr), exactly in Q[pi], at the four settings %s, both signs; shifted_tensor.py\'s own O0_sh + O1_sh annihilate the normalized first-order solution on the %d cases of st.SOL' % (SETDESC, nst))

# ------------------------------------------------------------------------------------------------ [bit] the Dyson terms as exact functions of s
rg = random.Random(46002); ok_ode = True; nkeys = 0; nfq = 0
for pot in POTS:
    for b0 in (Fr(-5), Fr(1)):
        F = {d: rand_mv(rg) for d in range(8)}; U = shift_series(F, b0, pot, FAULT)
        V = [lambda H, b0=b0: pD(H, b0)] + [lambda H, f=f, b0=b0: f(H, b0) for f in POT[pot]]
        for k in range(3):
            res = fq_add((1, fq_deriv(U[k])), *[(1, fq_map(U[k - i], V[i])) for i in range(k + 1)])
            ok_ode &= not res and fq_at(U[k], 0) == (F if k == 0 else {}) and bool(U[k])
        nkeys = max(nkeys, len(U[2])); nfq += 1
chk('bit', ok_ode, 'DYSON: on %d random fields of degree 7 (A_0 and Phi, frequencies -5 and +1), exactly as functions of s: U_0\' = -bD U_0, U_1\' = -bD U_1 - V_1 U_0, U_2\' = -bD U_2 - V_1 U_1 - V_2 U_0, U_0(0) = F, U_1(0) = U_2(0) = 0, so the Dyson terms (U_2 with its double integral; %d terms s^p e^{J w s}) are the coefficients of g and g^2 in exp(-s bD_g) F, independently of the Dyson formula' % (nfq, nkeys))

# ------------------------------------------------------------------------------------------------ [bit] the second-order solutions solve the shifted equation
CASES = []; ok_main = {p_: True for p_ in POTS}; ok_ord = True; ok_why = True; degs = set(); nul = set(); pidesc = []
for (m_, kap, tau), E_, n in GRADS:
    rg = random.Random(46100 + 10 * E_ + n)
    for sec in (-1, 1):
        b0 = Fr(sec * E_); inplus = sec == -1; Z = mode_Z(rg, inplus); P0 = {0: Z}
        for pot in POTS:
            P1, n1 = solve_ord(pf_add((-1, O_ord_k(1, P0, b0, pot, E_))), b0, E_, inplus, 5)
            P2, n2 = solve_ord(pf_add((-1, O_ord_k(1, P1, b0, pot, E_)), (-1, O_ord_k(2, P0, b0, pot, E_))), b0, E_, inplus, 8)
            nul |= {n1, n2}
            if P1 is None or P2 is None: ok_main[pot] = False; continue
            degs.add((max(P1), max(P2)))
            ok_ord &= not pf_add((1, O_ord_k(0, P2, b0, pot, E_)), (1, O_ord_k(1, P1, b0, pot, E_)), (1, O_ord_k(2, P0, b0, pot, E_)))
            U = [shift_series(P_, b0, pot, FAULT) for P_ in (P0, P1, P2)]
            sh = lambda k, P_, j: O_sh_k(k, P_, b0, pot, m_, kap, tau, U=U[j])
            r1 = pf_add((1, sh(0, P1, 1)), (1, sh(1, P0, 0)))
            r2 = pf_add((1, sh(0, P2, 2)), (1, sh(1, P1, 1)), (1, sh(2, P0, 0)))
            ok_main[pot] &= not r1 and not r2 and bool(sh(2, P0, 0)) and bool(sh(1, P1, 1))
            if E_ == 5 and n == 0 and sec == -1:
                o2 = sh(2, P0, 0); pidesc.append('%s: O_2[P_0] has powers of pi up to pi^%d' % (pot, max((k for W in o2.values() for v in W.values() for k in v.c), default=0)))
            for k in range(3):                                                    # the reason: the shift is the right factor e^{J E s} through g^2
                ok_why &= fq_add(*[(1, U[j][k - j]) for j in range(k + 1)]) == {(Fr(E_), 0): (P0, P1, P2)[k]}
            CASES.append(((m_, kap, tau), E_, n, sec, pot, Z, P0, P1, P2))
for pot in POTS:
    chk('bit', ok_main[pot] and ok_ord and nul == {0}, 'SOL2 %s: on the 8 cases (%s; both signs of the frequency) the second-order solution P_0 + g P_1 + g^2 P_2 of the ordinary equation of mass E with the same coupled operator, %s (P_1 of degree 3, P_2 of degree 6 in x_3; exact elimination over Q, the normalized system of nullity 0) solves the shifted equation at first and at second order exactly in Q[pi]: O_0[P_1] + O_1[P_0] = 0 and O_0[P_2] + O_1[P_1] + O_2[P_0] = 0, O_2 = %skappa U_2(tau) J with the second-order Dyson term, double integral included (degrees %s; %s)' % (pot, SETDESC, 'bD_g = bD + g x_3 gamma_0 (.) J gamma_0' if pot == 'A_0' else 'bD_g = bD + g V_1 + g^2 V_2 of the frame', 'V_2 J + ' if pot == 'Phi' else '', sorted(degs), '; '.join(d_ for d_ in pidesc if d_.startswith(pot))))
chk('bit', ok_why, 'WHY: on the same 16 second-order solutions, exactly as functions of s, sum_{i+j=k} U_i[P_j](s) = P_k e^{J E s} for k = 0, 1, 2: exp(-s bD_g) acts on the ordinary solution of mass E as the right factor e^{J E s} through g^2 (bD_g = -E (.) J there), so O_g[P] = P f_J(E) + O(g^3) with f_J(E) = E - m + kappa J e^{J E tau} = 0 at the quantized E: the derivation of ATY-046, run at second order')

# ------------------------------------------------------------------------------------------------ [bit] the mixing at second order
def predicted(pot, E, sec, Z):
    B = mmul(mmul(GUP[3], Z), G0); BJ = mmul(B, J); E = Fr(E)
    if pot == 'A_0':
        return ({3: mlin((-sec * E / 3, Z)), 2: mlin((-sec * Fr(1, 2), BJ))},
                {6: mlin((E * E / 45, Z)), 4: mlin((Fr(-1, 8), Z)), 5: mlin((E / 15, BJ))})
    return ({3: mlin((-E * E / 3, Z)), 2: mlin((-E / 2, BJ)), 0: mlin((-1 / (4 * E), BJ))},
            {6: mlin((E ** 4 / 45, Z)), 4: mlin((-11 * E * E / 24, Z)), 2: mlin((Fr(1, 4), Z)), 5: mlin((E ** 3 / 15, BJ)), 3: mlin((-7 * E / 12, BJ)), 1: mlin((-1 / (8 * E), BJ))})
ok_mix = len(CASES) == 16; mixdesc = {}
for (st_, E_, n, sec, pot, Z, P0, P1, P2) in CASES:
    q1, q2 = predicted(pot, E_, sec, Z); ok_mix &= P1 == q1 and P2 == q2
    other = halves(P2, sec == -1)[1]; B = mmul(mmul(GUP[3], Z), G0)
    if sec == -1 and E_ == 5 and n == 0:
        cf = [(d, zfac(W, mmul(B, J))) for d, W in sorted(other.items(), reverse=True)]
        mixdesc[pot] = '(' + ' + '.join('%s x_3%s' % (fmt_z(z), '' if d == 1 else '^%d' % d) for d, z in cf).replace('+ -', '- ') + ') B J'
chk('bit', ok_mix, 'MIX: normalized (no part in the mode\'s half at degrees 0 and 1), B = gamma^3 Z gamma_0, sigma the sign of the frequency, on all 16 cases exactly: A_0: P_1 = -sigma [(E/3) x_3^3 Z + (1/2) x_3^2 B J], P_2 = (E^2 x_3^6/45 - x_3^4/8) Z + (E/15) x_3^5 B J; Phi: P_1 = -(E^2/3) x_3^3 Z - (E x_3^2/2 + 1/(4E)) B J, P_2 = (E^4 x_3^6/45 - 11 E^2 x_3^4/24 + x_3^2/4) Z + (E^3 x_3^5/15 - 7 E x_3^3/12 - x_3/(8E)) B J. The part of P_2 in the advanced half (P_0 = Z e^{-J E t}, Z in P_+) is (E/15) x_3^5 B J for A_0 and (E^3 x_3^5/15 - 7 E x_3^3/12 - x_3/(8E)) B J for Phi (at E = 5: A_0 %s, Phi %s); at first order (1/2) x_3^2 B J for A_0, as ATY-046: the two signs of frequency mix at second order as for the ordinary equation of mass E, the same in the shifted one' % (mixdesc.get('A_0'), mixdesc.get('Phi')))

# ------------------------------------------------------------------------------------------------ [std] Dirac matrices, scipy expm, finite differences in g
DM2 = 10; HG = 5e-4
ST['DM'] = DM2; ST['IP'] = np.eye(DM2 + 1); ST['X3'] = pmul_mat([0.0, 1.0], DM2); _DER = np.zeros((DM2 + 1, DM2 + 1))
for d in range(1, DM2 + 1): _DER[d - 1, d] = d
ST['DER'] = _DER
def gderivs(f, h=HG):
    """f(0), f'(0) and f''(0)/2 by five-point differences"""
    fm2, fm1, f0, fp1, fp2 = (f(k * h) for k in (-2, -1, 0, 1, 2))
    return f0, (-fp2 + 8 * fp1 - 8 * fm1 + fm2) / (12 * h), (-fp2 + 16 * fp1 - 30 * f0 + 16 * fm1 - fm2) / (24 * h * h)
def std_case(beta, u, E_, m_, kap, tf, kind):
    A0o, O1o, O2o = gderivs(lambda g: Omat(beta, g, kind, m_, kap, tf, M=E_)); A0s, O1s, O2s = gderivs(lambda g: Omat(beta, g, kind, m_, kap, tf))
    psi0 = np.zeros(4 * (DM2 + 1), complex); psi0[:4] = u
    psi1 = np.linalg.lstsq(A0o, -O1o @ psi0, rcond=None)[0]; psi2 = np.linalg.lstsq(A0o, -O1o @ psi1 - O2o @ psi0, rcond=None)[0]
    ro = np.abs(A0o @ psi2 + O1o @ psi1 + O2o @ psi0).max() / np.abs(O1o @ psi1 + O2o @ psi0).max()
    parts = (A0s @ psi2, O1s @ psi1, O2s @ psi0); sc = max(np.abs(x).max() for x in parts)
    rs = np.abs(sum(parts)).max() / sc; r1only = np.abs(parts[1] + parts[2]).max() / sc       # without P_2 the residual is of order one
    return ro, rs, r1only, (A0s, O1s, O2s)
worst_o = 0.0; worst_s = 0.0; least_ctl = 1e300; nstd = 0; MATS = {}
for (m_, kap, tau), E_, n in GRADS:
    tf = float(tau)
    for sec in (-1, 1):
        beta = np.array([float(sec * E_), 0.0, 0.0, 0.0]); u = np.linalg.svd(-cmat(beta) - E_ * I4)[2][-1].conj()
        for kind in ('el', 'gr'):
            ro, rs, rc, mats = std_case(beta, u, E_, m_, kap, tf, kind); MATS[(E_, n, sec, kind)] = mats
            worst_o = max(worst_o, ro); worst_s = max(worst_s, rs); least_ctl = min(least_ctl, rc); nstd += 1
m_, kap, tau, E_ = 3, 2, PI / 10, 5; tf = float(tau)
for k, s in (((13, 0, 0, 12), -1), ((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)):
    beta = np.array([float(x) for x in kvec(k, s)]); u = np.linalg.svd(-cmat(beta) - E_ * I4)[2][-1].conj()
    for kind in ('el', 'gr'):
        ro, rs, rc, _ = std_case(beta, u, E_, m_, kap, tf, kind)
        worst_o = max(worst_o, ro); worst_s = max(worst_s, rs); least_ctl = min(least_ctl, rc); nstd += 1
chk('std', worst_o < 1e-10 and worst_s < 1e-7 and least_ctl > 1e-2, 'STD: Dirac matrices on x_3-polynomials of degree <= %d times a plane wave, %d cases (rest at the four settings, both signs, and the moving waves k = (13,0,0,12), (13,12,0,0), (7,2,4,2) at (3, 2, pi/10); A_0 = g x_3 exactly and Phi = g x_3 by the frame N^{-1/2} D\' N^{1/2}), exp(-tau D_g) by scipy expm of the whole matrix, the g- and g^2-parts by five-point differences (h = %.0e): the second-order solution of the ordinary equation by numpy lstsq (residual %.1e) solves the shifted second-order equation, relative residual %.1e (numerical, limited by the differences); without psi_2 the residual is >= %.2f' % (DM2, nstd, HG, worst_o, worst_s, least_ctl))
def vecof(P_):
    v = np.zeros(4 * (DM2 + 1), complex)
    for d, W in P_.items(): v[4 * d:4 * d + 4] = Mof(W) @ U0
    return v
worst_bs = 0.0; nbs = 0
for ((m_, kap, tau), E_, n, sec, pot, Z, P0, P1, P2) in CASES:
    A0s, O1s, O2s = MATS[(E_, n, sec, 'el' if pot == 'A_0' else 'gr')]; b0 = Fr(sec * E_)
    U = [shift_series(P_, b0, pot, FAULT) for P_ in (P0, P1, P2)]
    for k, Mk, j, P_ in ((0, A0s, 2, P2), (1, O1s, 1, P1), (2, O2s, 0, P0)):
        lab = vecof(O_sh_k(k, P_, b0, pot, m_, kap, tau, U=U[j])); mat = Mk @ vecof(P_)
        worst_bs = max(worst_bs, np.abs(lab - mat).max() / np.abs(mat).max()); nbs += 1
chk('bit==std', worst_bs < 1e-7, 'BITSTD: on the 16 exact second-order solutions at rest, the label pieces O_0[P_2], O_1[P_1] and O_2[P_0] (the Dyson term with its double integral, and for Phi the second-order frame) equal the Dirac-matrix ones through the dictionary Z -> M(Z) u0 (%d comparisons, max deviation %.1e relative, the five-point differences)' % (nbs, worst_bs))

# ------------------------------------------------------------------------------------------------ [ctl] the wrong versions
ctl = {w: [0, 0, 0] for w in FAULTS}                                              # cases with r2 != 0, cases with r1 != 0, cases
for ((m_, kap, tau), E_, n, sec, pot, Z, P0, P1, P2) in CASES:
    b0 = Fr(sec * E_)
    for w in FAULTS:
        U = [shift_series(P_, b0, pot, w) for P_ in (P0, P1, P2)]
        sh = lambda k, P_, j: O_sh_k(k, P_, b0, pot, m_, kap, tau, U=U[j])
        r1 = pf_add((1, sh(0, P1, 1)), (1, sh(1, P0, 0))); r2 = pf_add((1, sh(0, P2, 2)), (1, sh(1, P1, 1)), (1, sh(2, P0, 0)))
        ctl[w][0] += bool(r2); ctl[w][1] += bool(r1); ctl[w][2] += 1
chk('ctl', all(c[0] == c[2] == 16 for c in ctl.values()) and ctl['FREESHIFT'][1] == ctl['NOCOMM'][1] == 16 and ctl['NODYSON2'][1] == ctl['NODOUBLE'][1] == 0, 'CTL: each wrong version leaves O_0[P_2] + O_1[P_1] + O_2[P_0] non-zero on all 16 cases: FREESHIFT (the shift with the free bD) %d/16, NODYSON2 (U_2 dropped) %d/16, NODOUBLE (its double integral dropped) %d/16, NOCOMM (x_3 constant inside the shift) %d/16; FREESHIFT and NOCOMM break the first order as well (%d/16, %d/16), NODYSON2 and NODOUBLE leave it intact (%d/16, %d/16 broken): the double integral is what the second order needs' % (ctl['FREESHIFT'][0], ctl['NODYSON2'][0], ctl['NODOUBLE'][0], ctl['NOCOMM'][0], ctl['FREESHIFT'][1], ctl['NOCOMM'][1], ctl['NODYSON2'][1], ctl['NODOUBLE'][1]))

print('%d checks, %d FAIL; %.1f s' % (NCHK[0], len(FAILS), time.time() - T0), flush=True)
print('FAILS (SHIFTED-GRAD2): %s' % ('none' if not FAILS else '; '.join(FAILS)), flush=True)
sys.exit(1 if FAILS else 0)
