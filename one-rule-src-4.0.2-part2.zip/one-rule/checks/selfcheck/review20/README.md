# checks/selfcheck/review20 — the referees' scripts of round 20 (21 Oct 2026)

Twelve check scripts written by the two referees of docs/round20/review/ (a mathematician and a physicist), each with its own kernel and no Atlas import, and cube_faces.py (ATL-022c), run with `python3 -I -B <script> [--fault NAME]` from this folder; every `--fault` exits 1. `jets.py` is the physicist's exact jet calculus (Fraction coefficients). The logs of the release run are in `logs/`. What each computes is in `content/checks.json` and in the reviews' section D.
