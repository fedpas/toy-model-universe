# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ATY-003 (the Appendix example of Atiyah and Segal, "Twisted K-theory and cohomology"), recomputed with the reviewer's own exterior algebra.
Model: Lambda(x, y, z) (x) R[t]/(t^3), 24-dimensional, degrees |S| + 2k; d x = d y = 0, d z = x y, d t = 0 (Y the Heisenberg nilmanifold,
t the Kahler class of CP^2); twist H = x t (closed 3-form); D = d + H wedge.  Computed exactly over Q:
  - D^2 = 0; the pages of the spectral sequence of the degree filtration (Z_r^p / (Z_{r-1}^{p+1} + D Z_{r-1}^{p-r+1})): dim E_2 = 18 (= H*(M)),
    E_4 = 10, E_6 = E_oo = 8, and the twisted cohomology H(D) of total dimension 8, split (even, odd) = (4, 4);
  - so the printed ranks "18, 14, 10" of the Appendix (as the Atlas reads the page) do not match the model's pages 18, 10, 8; the printed 14 is
    not a page of this filtration (checked: no page has dimension 14), and the rank of twisted K-theory over R, equal to the total twisted
    cohomology by the twisted Chern character (recalled), is 8, not 10.
Controls (--fault, each exits 1): PAGE14 claims E_4 = 14; NOTWIST drops the twist (then H(D) = H*(M) has dimension 18, not 8).
usage: python3 -I -B aty003_atiyah_segal_model.py [--fault PAGE14|NOTWIST]"""
import sys, itertools
from fractions import Fraction as Fr

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

# basis: (S, k), S a 3-bit mask over (x, y, z) = bits 0, 1, 2; k = 0, 1, 2 ; degree |S| + 2k
BASIS = [(S, k) for k in range(3) for S in range(8)]
IDX = {b: i for i, b in enumerate(BASIS)}
NB = len(BASIS)
def deg(b): return bin(b[0]).count('1') + 2 * b[1]

def wedge_mask(a, b):
    """exterior product of monomials e_a e_b (sorted bit order), with sign; 0 if they overlap"""
    if a & b: return 0, 0
    sign = 1; i = 0
    while a >> i:
        if (a >> i) & 1:
            if bin(b & ((1 << i) - 1)).count('1') & 1: sign = -sign
        i += 1
    return sign, a | b

def wedge(u, v):
    """u, v: dict basis-index -> Fr"""
    out = {}
    for i, ci in u.items():
        S1, k1 = BASIS[i]
        for j, cj in v.items():
            S2, k2 = BASIS[j]
            if k1 + k2 > 2: continue
            s, S = wedge_mask(S1, S2)
            if s == 0: continue
            m = IDX[(S, k1 + k2)]; out[m] = out.get(m, 0) + s * ci * cj
    return {m: c for m, c in out.items() if c != 0}

def d_basis(i):
    """d of a basis element: derivation, d z = x y (z = bit 2, x = bit 0, y = bit 1)"""
    S, k = BASIS[i]; out = {}
    if S & 4:   # contains z: write e_S = (sign) z-part ... d acts on the z factor only
        # e_S = e_{S\z} ^ z * sign? use: d(a ^ z) = (-1)^{|a|} a ^ dz for a without z (d a = 0)
        rest = S & 3; sign_az, _ = wedge_mask(rest, 4)   # e_S = sign_az * (e_rest ^ z)
        sgn = (-1) ** bin(rest).count('1')
        # a ^ dz = e_rest ^ (x y)
        s2, m2 = wedge_mask(rest, 3)
        if s2 != 0:
            out[IDX[(m2, k)]] = out.get(IDX[(m2, k)], 0) + sign_az * sgn * s2
    return out

def matrix_of(op):
    M = [[Fr(0)] * NB for _ in range(NB)]
    for j in range(NB):
        for i, c in op(j).items(): M[i][j] += c
    return M

def rank(M):
    M = [list(r) for r in M]; r = 0
    if not M or not M[0]: return 0
    for c in range(len(M[0])):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[r], M[p] = M[p], M[r]; inv = 1 / M[r][c]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        r += 1
    return r

def nullspace(M, ncols):
    """basis of the kernel of M (rows) as vectors of length ncols"""
    A = [list(r) for r in M]; piv = []; r = 0
    for c in range(ncols):
        p = next((i for i in range(r, len(A)) if A[i][c] != 0), None)
        if p is None: continue
        A[r], A[p] = A[p], A[r]; inv = 1 / A[r][c]; A[r] = [x * inv for x in A[r]]
        for i in range(len(A)):
            if i != r and A[i][c] != 0:
                f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[r])]
        piv.append(c); r += 1
    free = [c for c in range(ncols) if c not in piv]
    out = []
    for fcol in free:
        v = [Fr(0)] * ncols; v[fcol] = Fr(1)
        for i, pc in enumerate(piv): v[pc] = -A[i][fcol]
        out.append(v)
    return out

def matvec(M, v): return [sum(M[i][j] * v[j] for j in range(len(v))) for i in range(len(M))]
def transpose(M): return [list(r) for r in zip(*M)]

def main():
    H = {IDX[(1, 1)]: Fr(1)}            # x t
    def D_op(j):
        out = dict(d_basis(j))
        if FAULT != 'NOTWIST':
            for m, c in wedge(H, {j: Fr(1)}).items(): out[m] = out.get(m, 0) + c
        return {m: Fr(c) for m, c in out.items() if c != 0}
    D = matrix_of(D_op)
    D2 = [[sum(D[i][k] * D[k][j] for k in range(NB)) for j in range(NB)] for i in range(NB)]
    ck(all(x == 0 for r in D2 for x in r), 'D = d + H wedge squares to 0 on the 24-dimensional model')
    rD = rank(D); hD = NB - 2 * rD
    ev = [i for i in range(NB) if deg(BASIS[i]) % 2 == 0]; od = [i for i in range(NB) if deg(BASIS[i]) % 2 == 1]
    def sub(rows, cols): return [[D[i][j] for j in cols] for i in rows]
    r_eo = rank(sub(od, ev)); r_oe = rank(sub(ev, od))     # D: even -> odd restricted, D: odd -> even
    h_even = len(ev) - r_eo - r_oe; h_odd = len(od) - r_oe - r_eo
    # spectral sequence pages of the degree filtration F^p = span{deg >= p}
    maxdeg = 7
    def span_deg(p): return [i for i in range(NB) if deg(BASIS[i]) >= p]
    def Zspace(pf, pt):
        """Z(pf, pt) = {a in F^pf : D a in F^pt} as a list of vectors (pf clipped at 0)"""
        pf = max(pf, 0); cols = span_deg(pf); rows_out = [i for i in range(NB) if deg(BASIS[i]) < pt]
        if not cols: return []
        M = [[D[i][j] for j in cols] for i in rows_out] or [[Fr(0)] * len(cols)]
        ker = nullspace(M, len(cols)); out = []
        for v in ker:
            w = [Fr(0)] * NB
            for c, j in enumerate(cols): w[j] = v[c]
            out.append(w)
        return out
    def dim_span(vecs): return rank(vecs) if vecs else 0
    pages = {}
    for r in range(1, 9):
        tot = 0
        for p in range(0, maxdeg + 1):
            Z = Zspace(p, p + r)                       # Z_r^p
            Z1 = Zspace(p + 1, p + r)                  # Z_{r-1}^{p+1}
            B = [matvec(D, v) for v in Zspace(p - r + 1, p)]   # B_{r-1}^p = F^p cap D(F^{p-r+1})
            tot += dim_span(Z) - dim_span(Z1 + B)
        pages[r] = tot
    seq = [pages[r] for r in range(1, 9)]
    want = [24, 18, 18, 10, 10, 8, 8, 8] if FAULT != 'PAGE14' else [24, 18, 18, 14, 14, 10, 10, 10]
    ck(seq == want, 'pages E_1 ... E_8 of the degree filtration: %s (E_2 = 18 = H*(M), E_4 = 10, E_6 = E_oo = 8)' % seq)
    ck(hD == 8 and (h_even, h_odd) == (4, 4), 'twisted cohomology H(D): total %d, (even, odd) = (%d, %d)' % (hD, h_even, h_odd))
    ck(14 not in seq, 'no page has dimension 14: the printed ranks 18, 14, 10 are not the pages of this model')
    print('FAILS: %s' % (FAILS or 'none')); sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
