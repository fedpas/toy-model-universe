# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ATY-024 / ATY-022: the Atiyah-LeBrun self-dual Einstein edge-cone family (5.4)-(5.6) on (CP^2, CP^1), computed with the
reviewer's own exact Christoffel route (jets.py; no Atlas code).

  V = 1/beta + 1/(e^{2a} - 1),  g0 = V (da^2 + sinh^2 a g_{S^2}) + V^{-1} sigma_3^2,  g~ = (4/beta) [(2 - beta) cosh a + beta sinh a]^{-2} g0,
  sigma_3 = (1/2)(d psi + cos th d phi) (unit left-invariant form: sigma_1^2 + sigma_2^2 + sigma_3^2 = unit S^3), g_{S^2} = d th^2 + sin^2 th d phi^2.

Checked exactly (Fractions) at the base point (a0, th0) with e^{a0} and (cos th0, sin th0) rational, for several beta:
  (1) Ric(g~) = lambda g~ with lambda = (3/2) beta^2 (2 - beta), all 16 components (the trace-free Ricci vanishes, the constant is the paper's);
  (2) the Einstein-form reading of the cell (4,0): M(c) = G^b_a - 3c delta^b_a vanishes exactly at c = -lambda/3 and at no other c
      (ATY-024b's identity E_a(c) = 0 <=> M(c) = 0, einstein_riem.py); at beta = 1 c = -1/2 (g~ = 4 g_FS, Ric_FS = 6 g_FS: c = -2 at scale 1).
Controls (--fault NAME, each must exit 1): CONST lambda -> (3/2) beta^2; SIGMA sigma_3 with the Euler normalisation (d psi + cos th d phi),
  which is not Einstein; SIGN the Riemann tensor with the opposite sign (Ric = -lambda g~ claimed).
usage: python3 -I -B aty024_cone_einstein.py [--fault CONST|SIGMA|SIGN]"""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fractions import Fraction as Fr
from jets import Jet, jexp, jsin, jcos, curvature_at0

FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
N, D = 4, 2
FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg)
    if not cond: FAILS.append(msg)

def cone_metric(beta, ea0, c0, s0):
    """coordinate metric g~ as 4x4 jets in (a, th, phi, psi) at the base point with e^{a0} = ea0, (cos th0, sin th0) = (c0, s0)"""
    a = Jet.var(N, D, 0); th = Jet.var(N, D, 1)
    E = jexp(a, ea0)                      # e^a
    E2 = E * E
    sh = (E - E.inv()) * Fr(1, 2); chh = (E + E.inv()) * Fr(1, 2)
    V = Jet.const(N, D, Fr(1) / beta) + (E2 - 1).inv()
    cth = jcos(th, s0, c0); sth = jsin(th, s0, c0)
    half = Fr(1, 2) if FAULT != 'SIGMA' else Fr(1)
    # g0 in coordinates (a, th, phi, psi): V da^2 + V sinh^2 (dth^2 + sin^2 dphi^2) + V^{-1} half^2 (dpsi + cos th dphi)^2
    Vi = V.inv()
    g0 = [[Jet(N, D) for _ in range(N)] for _ in range(N)]
    g0[0][0] = V
    g0[1][1] = V * sh * sh
    g0[2][2] = V * sh * sh * sth * sth + Vi * half * half * cth * cth
    g0[3][3] = Vi * half * half
    g0[2][3] = g0[3][2] = Vi * half * half * cth
    f = chh * (2 - beta) + sh * beta
    conf = (f * f).inv() * (Fr(4) / beta)
    return [[g0[i][j] * conf for j in range(N)] for i in range(N)]

def main():
    t0 = time.time()
    cases = [(Fr(1), Fr(2), Fr(3, 5), Fr(4, 5)), (Fr(1, 2), Fr(3), Fr(5, 13), Fr(12, 13)), (Fr(2, 3), Fr(3, 2), Fr(3, 5), Fr(4, 5)),
             (Fr(3, 2), Fr(5), Fr(8, 17), Fr(15, 17)), (Fr(25, 81), Fr(2), Fr(5, 13), Fr(12, 13)), (Fr(49, 25), Fr(7, 3), Fr(3, 5), Fr(4, 5)),
             (Fr(1), Fr(5, 2), Fr(5, 13), Fr(12, 13))]
    for beta, ea0, c0, s0 in cases:
        g = cone_metric(beta, ea0, c0, s0)
        gi0, Gam, Riem, Ric, Rs = curvature_at0(g)
        if FAULT == 'SIGN':
            Ric = [[-x for x in row] for row in Ric]; Rs = -Rs
        g0 = [[g[i][j].val() for j in range(N)] for i in range(N)]
        lam = Fr(3, 2) * beta * beta * (2 - beta)
        if FAULT == 'CONST': lam = Fr(3, 2) * beta * beta
        einstein = all(Ric[i][j] == lam * g0[i][j] for i in range(N) for j in range(N))
        ck(einstein, 'Ric(g~) = lambda g~ exactly, lambda = %s, at beta = %s, e^a0 = %s, (cos, sin) th0 = (%s, %s)   [Rs = %s = 4 lambda]'
           % (lam, beta, ea0, c0, s0, Rs))
        # mixed Einstein tensor G^b_a = Ric^b_a - (1/2) Rs delta, and the (4,0)-cell reading M(c) = G - 3c delta
        Gm = [[sum(gi0[b][k] * Ric[k][a] for k in range(N)) - (Fr(1, 2) * Rs if a == b else 0) for a in range(N)] for b in range(N)]
        cstar = -lam / 3
        M = lambda c: [[Gm[b][a] - (3 * c if a == b else 0) for a in range(N)] for b in range(N)]
        z = lambda X: all(x == 0 for row in X for x in row)
        ck(z(M(cstar)) and not z(M(cstar + 1)) and not z(M(-cstar)), 'E_a(c) reading: M(c) = G - 3c delta = 0 exactly at c = -lambda/3 = %s, not at c + 1 nor at -c (beta = %s)' % (cstar, beta))
    print('TOTAL %.1f s; FAILS: %s' % (time.time() - t0, FAILS or 'none'))
    sys.exit(1 if FAILS else 0)

if __name__ == '__main__':
    main()
