#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""WEITZ-FORMS.  The Weitzenboeck formula on forms of every degree in a curved frame, and its Clifford form D^2 X - box X on every grade.
   python3 weitzenboeck_forms.py <path of checks/selfcheck> [--n 4|5|6] [--fault ONEFORM|RIEMSIGN]
   --n N runs n = 3 .. N: 5 is the default (n = 3, 4, 5; about 2 min), 4 the first version's run (n = 3, 4; 20 s), 6 adds n = 6 (about 9 min in all).

Conventions (the engine's, the same as gsb_dirac_sq.py part (W)): squares sq, eta = diag(sq); a k-form alpha = sum_I alpha_I dx^I (I increasing), frame
components alpha_I = sum_J alpha_J det(E[J][I]) (g2_hodge); d = the engine's Forms.d; delta = (-1)^(n(p+1)+s) * d * on p-forms (s = number of negative
squares, * = g2_hodge's frame star), i.e. delta alpha = +div alpha = nabla^c alpha_{c...} (= -d^dagger), part (H); nabla from the A3 closed-form omega
(torsion-free), the matrix omega^b_a read from Grav.D_covector (the h table), nabla^c nabla_c = eta^cc nabla_c nabla_c; curvature R^{ab} = d omega^{ab}
+ (1/4)[omega, omega] (Grav.curvature), R_abcd = eta_aa eta_bb R^{ab}(E_c, E_d) (the Lie pair first), Ric_bd = R^a_bad = sum_a eta_bb R^{ab}(E_a, E_d)
(MTW, E1.ricci), R = sum_ab R^{ab}(E_a, E_b), indices raised with eta.  On k-forms:
   Ric(alpha)_{a1..ak}  = sum_i Ric_{a_i}^d alpha_{a1..d..ak}                     (d in slot i)
   Riem(alpha)_{a1..ak} = sum_{i != j} R_{a_i}^d_{a_j}^e alpha_{a1..d..e..ak}      (d in slot i, e in slot j; R_a^d_b^e = eta_aa eta_ee R^{ad}(E_b, E_e))
(F) [bit] For k = 0..n at the origin: n = 3, 4 with Lorentz (+,-,..,-) and Euclidean (+,..,+) squares (those of parts (W) and (H)); n = 5 with the
    Lorentz squares (+,-,-,-,-) = Cl(1,4), the squares (+,-,-,-,+) of Cl(2,3) (the two Kaluza-Klein algebras of shifted_einstein.py se.KK: Cl(1,3) and a
    fifth generator of square -1 or +1) and the Euclidean squares Cl(5,0); n = 6 (--n 6) with Lorentz and Euclidean squares.  The exact fit
    (d delta + delta d) alpha - nabla^c nabla_c alpha = x Ric(alpha) + y Riem(alpha) over all frame components, on two strong draws; verified on a third
    strong draw and on a frame with e(0) != 1 drawn as in part (W) (b1lib.rand_frame, coefficients -2..2; its form by part (W)'s rule, for n >= 5 with
    every constant term non-zero, so that the curvature terms do not vanish at k = n).  Result: k = 0 both operators vanish and so does
    the left side; k = 1 x = -1 (Riem = 0 on 1-forms: (x, y) = (-1, 0), part (W), (1.3)); 2 <= k <= n-1 the unique (x, y) = (-1, +1); k = n
    Ric(alpha) = Riem(alpha) = R alpha and the left side is 0, so the fit fixes x + y = 0 only and (-1, +1) is on that line (no curvature term on top
    forms).  So d delta + delta d = nabla^c nabla_c - Ric + Riem on every degree (the Hodge Laplacian dd^dagger + d^dagger d = nabla^* nabla + Ric - Riem;
    on constant curvature K the term is k(n-k)K).  On the three frames of part (W) the k = 1 code returns (W)'s three vectors exactly.
    Draws (gsb_dirac_sq.py (L)'s rule): frame e = dx + a 1-jet + a 2-jet (gsb_dirac_sq.jets_frame), form alpha with every component a 2-jet, every
    coefficient an integer uniform in -50..50.  Every term at the origin is a polynomial of degree <= 3 in the sampled coefficients (two derivatives at the
    point, alpha linear, e(0) = 1, which a linear change of coordinates reaches); the degree is checked along a random line (fourth finite difference zero),
    so a false identity of this form passes the three strong draws with probability at most (3/101)^3 = 2.6e-5 per (k, n, squares) (Schwartz-Zippel).
(S) [std] Christoffel calculus on g = e^T eta e (exact series, b1lib.std_metric / gsb_dirac_sq.Gam_series / b1lib.std_riemann, no engine): for every k,
    n and squares on the e(0) != 1 frame, d(div alpha) + div(d alpha) with the component d, the rough Laplacian g^{mn} nabla_m nabla_n alpha, Ric(alpha) and
    Riem(alpha) from the coordinate Riemann tensor R^r_smv (MTW), read in the frame at the origin, equal the engine's four terms; the std route alone gives
    (d delta + delta d) = nabla^2 - Ric + Riem; for k = 2 also the textbook 2-form formula Delta_H alpha_ab = -nabla^2 alpha_ab + Ric_a^c alpha_cb +
    Ric_b^c alpha_ac - 2 R_a^c_b^d alpha_cd with Delta_H = d d^dagger + d^dagger d, d^dagger = -div.
(C) [bit] The Clifford form (1.5): X = sum_S X^S gamma_S of grade k with X^S = eta_S alpha_S (gamma_S <-> eta_S e^S); D X = gamma^a nabla_a X and
    box X = eta^ab (nabla^2 X)(E_a, E_b) with nabla X = d X + (1/2) omega^A [B_A, X] (proofs/shifted_einstein.py's D_full, nabla, dirac, second_cov,
    box_of, read from its source: the module runs all its checks on import); for every k: D X has grades k-1, k+1 only, D^2 X has grade k only and equals
    the (d delta + delta d) alpha of (F) (Hodge-star route), box X equals nabla^c nabla_c alpha of (F) (tensor route), so D^2 X - box X = -Ric(X) + Riem(X).
    D = d + delta is (1.4) (shifted_einstein se.DIRAC), so (1.5) at grade k is (F) at degree k; this computes it by the spin-connection route directly.
[bit]  the engine (Grav, Forms.d, D_covector, curvature, bmul), b1lib (A3 closed-form omega, dual frame series), g2_hodge's frame star (each star at the
       x-degree its value at the origin needs), E1's curv_frame / ricci, gsb_dirac_sq's jets_frame and bit_weitz (part (W)), shifted_einstein's
       full-algebra connection.  From n = 6 on the frame components of alpha come from memoized Laplace minors of the dual frame (laplace_comps:
       C(n,j)^2 j jet products per minor size j, once per frame, against C(n,k)^2 k! k per form in the permutation sum of g2_hodge.frame_components,
       which is most of the run time at n = 6), checked equal to g2_hodge.frame_components on the e(0) != 1 frame for every k.
[std]  b1lib.std_metric, std_inverse_metric, std_riemann and gsb_dirac_sq.Gam_series (own polynomial code, no engine), plain index loops.
Controls (--fault puts each into the main checks: the claimed coefficients become the wrong ones and the run exits 1): ONEFORM the 1-form coefficients
(x, y) = (-1, 0) on every degree (the fit without the Riem column); RIEMSIGN the opposite sign y = -1.  In the main run both are also controls that
must fail on every frame for k = 2..n, and the fit without the Riem column is inconsistent for k = 2..n-1.
Scope.  Values at the origin of polynomial 2-jet frames with the torsion-free A3 connection, exact Fractions; finitely many draws (the bound above is
the result for the probabilistic reading, the exact fit holds on the given frames); n = 3, 4 with Lorentz and Euclidean squares, n = 5 with Lorentz
(= Cl(1,4)), Cl(2,3) and Euclidean squares (the default run), n = 6 with Lorentz and Euclidean squares (--n 6); other sign patterns (Cl(2,2), Cl(3,1),
Cl(3,2), ..., Cl(2,4), ...) and n >= 7 are not run.  No claim about global analysis (no integration by parts, no boundary terms)."""
import os, sys, time, random, itertools, ast, types

ARGS = sys.argv[1:]
FAULTS = ('ONEFORM', 'RIEMSIGN')
USAGE = 'usage: python3 weitzenboeck_forms.py <path of checks/selfcheck> [--n 4|5|6] [--fault ONEFORM|RIEMSIGN]'
FAULT = None
if '--fault' in ARGS:
    i_ = ARGS.index('--fault'); FAULT = ARGS[i_ + 1] if i_ + 1 < len(ARGS) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
NMAX = 5                                                                   # the largest dimension run: n = 3 .. NMAX
if '--n' in ARGS:
    i_ = ARGS.index('--n'); v_ = ARGS[i_ + 1] if i_ + 1 < len(ARGS) else ''
    if v_ not in ('4', '5', '6'): raise SystemExit('--n takes the largest dimension: 4, 5 (the default) or 6; ' + USAGE)
    NMAX = int(v_)
for a_ in ARGS:
    if a_.startswith('--') and a_ not in ('--fault', '--n'): raise SystemExit('unknown option %r; %s' % (a_, USAGE))
POS = [a for i, a in enumerate(ARGS) if not a.startswith('--') and not (i > 0 and ARGS[i - 1] in ('--fault', '--n'))]
if not POS: POS = [os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))]   # the checks/selfcheck folder beside this script's folder
SELF = os.path.abspath(POS[0]); GRAVD = os.path.join(SELF, 'gravity'); SE_PATH = os.path.join(SELF, 'proofs', 'shifted_einstein.py')
for f_ in (os.path.join(SELF, 'gravity_selfcheck.py'), os.path.join(GRAVD, 'b1lib.py'), os.path.join(GRAVD, 'gsb_dirac_sq.py'), SE_PATH):
    if not os.path.isfile(f_): raise SystemExit('not found: %s (the argument is the checks/selfcheck folder of the Atlas)' % f_)
for p_ in (SELF, GRAVD):
    if p_ not in sys.path: sys.path.insert(0, p_)
_argv = sys.argv; sys.argv = [_argv[0]]                                   # gsb_dirac_sq reads sys.argv at import (its own --fault names)
try:
    import b1lib as BL
    from b1lib import (F, Lie, Grav, koszul_S, anholonomy, omega_closed_form, E0_of, trunc, pm, at0, padd, scale, lin, const, solve_exact,
                       rand_frame, LORENTZ, std_metric, std_riemann, sp_add, sp_mul, sp_der, gs, bmul, popc)
    import e1_lichnerowicz as E1
    import g2_hodge as GH
    import gsb_dirac_sq as GSB
finally:
    sys.argv = _argv

T0 = time.time(); FAILS = []
def chk(tag, cond, msg):
    cond = bool(cond); print('%s[%s] %s' % ('ok   ' if cond else 'FAIL ', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def info(s): print('     ' + s, flush=True)
def tick(label): info('(%s: %.1f s)' % (label, time.time() - T0))
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

# ------------------------------------------------------------------------------------------------ the full-algebra connection of shifted_einstein.py (definitions only)
SE_FUNCS = ('clean', 'mv_add', 'mvp_add', 'at0_mv', 'grades', 'D_full', 'contract', 'nabla', 'dirac', 'second_cov', 'box_of')
def load_se(path):
    """the function definitions SE_FUNCS of proofs/shifted_einstein.py, executed alone (the module itself runs its checks at import)"""
    with open(path) as fh: tree = ast.parse(fh.read(), path)
    nodes = [nd for nd in tree.body if isinstance(nd, ast.FunctionDef) and nd.name in SE_FUNCS]
    assert sorted(nd.name for nd in nodes) == sorted(SE_FUNCS), 'shifted_einstein.py: definitions missing'
    ns = dict(Fr=F, padd=padd, bmul=bmul, pm=pm, trunc=trunc, at0=at0, scale=scale, itertools=itertools, fault=lambda name: False)
    exec(compile(ast.Module(body=nodes, type_ignores=[]), path, 'exec'), ns)
    return types.SimpleNamespace(**{k: ns[k] for k in SE_FUNCS})
SE = load_se(SE_PATH)

# ------------------------------------------------------------------------------------------------ index helpers
def bits(m): return [i for i in range(m.bit_length()) if m >> i & 1]
def masks(n, k): return [m for m in range(1 << n) if popc(m) == k]
def tsort(tup):
    """e^{t1} ^ ... ^ e^{tk} = sign e^mask: (mask, sign), sign 0 for a repeated index"""
    tup = list(tup)
    if len(set(tup)) < len(tup): return 0, 0
    return sum(1 << t for t in tup), GH.perm_sign(tup)
def eta_of(S, sq):
    s = 1
    for i in bits(S): s *= sq[i]
    return s
def minor(E0, rows, cols):
    k = len(rows); t = F(0)
    for perm in itertools.permutations(range(k)):
        v = F(GH.perm_sign(perm))
        for i in range(k):
            v *= E0[rows[i]][cols[perm[i]]]
            if not v: break
        t += v
    return t
def frame_vals(X, E0, n, k):
    """coordinate components at the origin {J: number} -> frame components {I: number}, X_I = sum_J X_J det(E0[J][I])"""
    return {I: sum((v * minor(E0, bits(J), bits(I)) for J, v in X.items() if v), F(0)) for I in masks(n, k)}
def jets_form(rng, n, k, lo=-50, hi=50):
    """a k-form: every component present, every monomial of degree <= 2 with an integer coefficient uniform in lo..hi (gsb_dirac_sq.jets_spinor's rule)"""
    mons = [ex for ex in itertools.product(range(3), repeat=n) if sum(ex) <= 2]; out = {}
    for M in masks(n, k):
        p = {}
        for ex in mons:
            c = rng.randint(lo, hi)
            if c: p[ex] = F(c)
        if p: out[M] = p
    return out
def small_form(rng, n, k, c0=False):
    """part (W)'s rule for alpha: random polynomials of degree 2 (gs.rpoly, density .7, coefficients -3..3); c0 (used for n >= 5): a missing constant
    term is set to 1, no extra draw (at n = 5, k = 5 the rule gives alpha(0) = 0 for the Lorentz and Cl(2,3) seeds, and every curvature term vanishes)"""
    out = {}
    for M in masks(n, k):
        p = E1.nz_poly(gs.rpoly(rng, n, 2, .7)) or {(0,) * n: F(1)}
        if c0 and not p.get((0,) * n): p[(0,) * n] = F(1)
        out[M] = p
    return out

# ------------------------------------------------------------------------------------------------ [bit] the engine on a frame
def engine_setup(e, n, sq):
    """A3 closed-form omega (1-jet), dual frame series (1- and 2-jets), curvature at the origin, frame Ricci; omega^b_a from Grav.D_covector"""
    sq = list(sq); Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = koszul_S(n, sq, Lie_)
    Dp = anholonomy(Gv, e, n, 1); om = omega_closed_form(Gv, e, S, n, 1, Dpre=Dp)[0]
    E2 = anholonomy(Gv, e, n, 2)[1]; e0, E0, det = E0_of(e, n, n)
    with trunc(n, xdeg=1): T = Gv.torsion(om, e)
    tf = all(not p for t in T for p in t.values())
    with trunc(n, xdeg=0): R = Gv.curvature(om)
    Rf = E1.curv_frame(Gv, R, E0, n); ric = E1.ricci(Rf, n, sq); Rs = E1.scalar_R(Rf, n)
    W = [[None] * n for _ in range(n)]                                    # W[a][b] = omega^b_a: (D u)_a = d u_a - omega^c_a u_c on the unit covector u = e_b
    for b in range(n):
        out = Gv.D_covector(om, [({0: const(n, 1)} if c == b else {}) for c in range(n)])
        for a in range(n): W[a][b] = Gv.Fm.scale(out[a], -1)
    J = {t: ([{m: q for m, q in ((m, cut(p, n, t)) for m, p in f.items()) if q} for f in e], [[cut(p, n, t) for p in row] for row in E2]) for t in (0, 1, 2)}
    return dict(Gv=Gv, e=e, E=Dp[1], E2=E2, E0=E0, om=om, Rf=Rf, ric=ric, Rs=Rs, W=W, tf=tf, n=n, sq=sq, J=J)
def cut(p, n, t):
    """the part of x-degree <= t of a polynomial (a product truncated at x-degree t needs its factors only to x-degree t: exact)"""
    return {m: v for m, v in p.items() if sum(m[:n]) <= t}
def hodge_lap(d, al, k, afr=None):
    """(d delta + delta d) alpha with the engine's d and the frame star (g2_hodge's hodge_form: frame_components, star_comps, form_from_frame),
    delta = (-1)^(n(p+1)+s) * d * on p-forms; coordinate form (exact at x-degree 0).  Each star is taken at the x-degree its value at the origin needs
    (* alpha: 2; * d * alpha and * d alpha: 1; * d * d alpha: 0), on the frame and dual-frame jets cut to that degree (d['J']); afr = the frame
    components of alpha at x-degree 2 when already known (the first step of * alpha)"""
    n, sq, Gv = d['n'], d['sq'], d['Gv']; Fm = Gv.Fm; s_neg = sum(1 for x in sq if x < 0)
    sg = lambda p: (-1) ** (n * (p + 1) + s_neg)
    def star(X, t, comps=None):
        e_t, E_t = d['J'][t]
        with trunc(n, xdeg=t):
            return GH.form_from_frame(GH.star_comps(GH.frame_components(X, E_t, n) if comps is None else comps, sq, 'bit'), e_t, Fm, n)
    out = {}
    if k > 0: out = Fm.add(out, Fm.d(Fm.scale(star(Fm.d(star(al, 2, afr)), 1), sg(k))))
    if k < n: out = Fm.add(out, Fm.scale(star(Fm.d(star(Fm.d(al), 1)), 0), sg(k + 1)))
    return out
LAPLACE_N = 6                                                              # from this n on, the frame components of alpha come from laplace_comps
def laplace_comps(d, al, k):
    """the frame components X_I = sum_J X_J det(E[J][I]) of a k-form at x-degree 2 (g2_hodge.frame_components' result), the minors of the dual-frame
    2-jet E2 by Laplace expansion along the first row, every size <= k, memoized in d (once per frame for all degrees): C(n,j)^2 j jet products for
    size j in place of the C(n,k)^2 k! k of the permutation sum, which is the run time at n = 6"""
    n, E2 = d['n'], d['E2']; M = d.setdefault('minors', {(0, 0): const(n, 1)})
    with trunc(n, xdeg=2):
        for j in range(d.get('minor_size', 0) + 1, k + 1):
            for J in masks(n, j):
                r = bits(J)[0]
                for I in masks(n, j):
                    tot = {}
                    for i, c in enumerate(bits(I)):
                        sub = M.get((J ^ (1 << r), I ^ (1 << c)))
                        if sub and E2[r][c]: tot = padd(tot, pm(E2[r][c], sub), (-1) ** i)
                    if tot: M[(J, I)] = tot
            d['minor_size'] = j
        out = {}
        for J, p in al.items():
            for I in masks(n, k):
                if p and M.get((J, I)): out[I] = padd(out.get(I, {}), pm(p, M[(J, I)]))
    return {I: q for I, q in out.items() if q}
def cov_D(Fm, W, T, k, n):
    """(D T)_I = d T_I - sum_i omega^b_{a_i} T_{I(a_i -> b)} on antisymmetric frame components {increasing mask: polynomial}"""
    out = {}
    for I in masks(n, k):
        a = bits(I); f = Fm.d({0: T[I]}) if T.get(I) else {}
        for i in range(k):
            for b in range(n):
                M, s = tsort(a[:i] + [b] + a[i + 1:])
                if s and T.get(M) and W[a[i]][b]: f = Fm.add(f, Fm.wedge(W[a[i]][b], {0: T[M]}), -s)
        out[I] = f
    return out
def curv_terms(d, a0, k):
    """Ric(alpha) and Riem(alpha) at the origin (frame components) from the engine's R^{ab}(E_c, E_d) and Ric_bd"""
    n, sq, Rf, ric = d['n'], d['sq'], d['Rf'], d['ric']; RicT, RiemT = {}, {}
    for I in masks(n, k):
        a = bits(I); r1 = r2 = F(0)
        for i in range(k):
            for dd in range(n):
                M, s = tsort(a[:i] + [dd] + a[i + 1:])
                if s: r1 += s * ric[(a[i], dd)] * sq[dd] * a0.get(M, 0)
        for i in range(k):
            for j in range(k):
                if i == j: continue
                for dd in range(n):
                    for ee in range(n):
                        tup = list(a); tup[i] = dd; tup[j] = ee; M, s = tsort(tup)
                        if s: r2 += s * sq[a[i]] * sq[ee] * Rf.get((a[i], dd, a[j], ee), 0) * a0.get(M, 0)
        RicT[I] = r1; RiemT[I] = r2
    return RicT, RiemT
def bit_terms(d, al, k):
    """[bit] frame components at the origin of (d delta + delta d) alpha, nabla^c nabla_c alpha, Ric(alpha), Riem(alpha)"""
    n, sq, Gv, E, E2, E0, W = d['n'], d['sq'], d['Gv'], d['E'], d['E2'], d['E0'], d['W']; Fm = Gv.Fm
    if n >= LAPLACE_N: afr = laplace_comps(d, al, k)
    else:
        with trunc(n, xdeg=2): afr = GH.frame_components(al, E2, n)
    Delta = frame_vals({J: at0(p, n) for J, p in hodge_lap(d, al, k, afr).items()}, E0, n, k)
    with trunc(n, xdeg=1):
        Da = cov_D(Fm, W, afr, k, n)
        Y = {(c, I): lin(*[(F(1), pm(Da[I].get(1 << mu, {}), E[mu][c])) for mu in range(n)]) for c in range(n) for I in masks(n, k)}
    Box = {}
    with trunc(n, xdeg=0):
        for I in masks(n, k):
            a = bits(I); tot = F(0)
            for c in range(n):                                            # (D Y)_{cI} = d Y_cI - omega^b_c Y_bI - sum_i omega^b_{a_i} Y_{c I(a_i -> b)}
                f = Fm.d({0: Y[(c, I)]}) if Y[(c, I)] else {}
                for b in range(n):
                    if Y[(b, I)] and W[c][b]: f = Fm.add(f, Fm.wedge(W[c][b], {0: Y[(b, I)]}), -1)
                for i in range(k):
                    for b in range(n):
                        M, s = tsort(a[:i] + [b] + a[i + 1:])
                        if s and Y[(c, M)] and W[a[i]][b]: f = Fm.add(f, Fm.wedge(W[a[i]][b], {0: Y[(c, M)]}), -s)
                tot += sq[c] * sum((at0(f.get(1 << mu, {}), n) * E0[mu][c] for mu in range(n)), F(0))
            Box[I] = tot
    a0 = {I: at0(p, n) for I, p in afr.items()}
    RicT, RiemT = curv_terms(d, a0, k)
    return dict(Delta=Delta, Box=Box, RicT=RicT, RiemT=RiemT, afr=afr, a0=a0, k=k)
def residual(t): return {I: t['Delta'][I] - t['Box'][I] for I in t['Delta']}
def holds(t, x, y): return all(t['Delta'][I] - t['Box'][I] == x * t['RicT'][I] + y * t['RiemT'][I] for I in t['Delta'])

# ------------------------------------------------------------------------------------------------ [bit] the Clifford form (1.5), shifted_einstein's connection on the full algebra
def clifford_terms(d, t):
    """X^S = eta_S alpha_S (2-jets of the frame components); D X (grades at 0), D^2 X and box X at the origin"""
    n, sq, Gv, om, E, E0 = d['n'], d['sq'], d['Gv'], d['om'], d['E'], d['E0']
    X = {S: scale(p, eta_of(S, sq)) for S, p in t['afr'].items() if p}
    nab1 = SE.nabla(Gv, om, E, X, n, 1); Phi = SE.dirac(nab1, n, sq)
    D2 = SE.at0_mv(SE.dirac(SE.nabla(Gv, om, E, Phi, n, 0), n, sq), n)
    E0c = [[({(0,) * n: E0[mu][a]} if E0[mu][a] else {}) for a in range(n)] for mu in range(n)]
    Lap = SE.at0_mv(SE.box_of(SE.second_cov(Gv, om, E0c, nab1, n, 0), n, sq), n)
    return SE.grades(SE.at0_mv(Phi, n)), D2, Lap

# ------------------------------------------------------------------------------------------------ [std] Christoffel calculus on g = e^T eta e, every degree
def std_terms(e, al, k, n, sq, E0):
    """[std] coordinate route at the origin, read in the frame: d(div alpha) + div(d alpha), g^{mr} nabla_m nabla_r alpha, Ric(alpha), Riem(alpha),
    and for k = 2 the textbook 2-form term Ric_a^c alpha_cb + Ric_b^c alpha_ac - 2 R_a^c_b^d alpha_cd (coordinate components)"""
    g = std_metric(e, n, sq, n, 2); Gam, gi, g0, g0i = GSB.Gam_series(g, n, n); G0 = {key: at0(v, n) for key, v in Gam.items()}
    Rm, _, _ = std_riemann(g, n, n, 1)
    A0 = {I: at0(p, n) for I, p in al.items()}
    def Av(tup): M, s = tsort(tup); return s * A0.get(M, 0) if s else 0
    Na = {}                                                                # nabla_r alpha_I, 1-jets
    for r in range(n):
        for I in masks(n, k):
            a = bits(I); t = sp_der(al.get(I, {}), r)
            for i in range(k):
                for q in range(n):
                    M, s = tsort(a[:i] + [q] + a[i + 1:])
                    if s and al.get(M) and Gam[(q, r, a[i])]: t = sp_add(t, sp_mul(Gam[(q, r, a[i])], al[M], 1, n), -s)
            Na[(r, I)] = t
    Na0 = {key: at0(p, n) for key, p in Na.items()}
    def Nv(r, tup): M, s = tsort(tup); return s * Na0.get((r, M), 0) if s else 0
    SD = {I: F(0) for I in masks(n, k)}
    if k > 0:                                                              # d (div alpha), div on the first slot
        dl = {}
        for J in masks(n, k - 1):
            t = {}
            for m in range(n):
                M, s = tsort([m] + bits(J))
                if not s: continue
                for r in range(n):
                    if gi[(m, r)] and Na[(r, M)]: t = sp_add(t, sp_mul(gi[(m, r)], Na[(r, M)], 1, n), s)
            dl[J] = t
        for I in masks(n, k):
            a = bits(I); SD[I] += sum((F((-1) ** i) * at0(sp_der(dl[I ^ (1 << a[i])], a[i]), n) for i in range(k)), F(0))
    if k < n:                                                              # div (d alpha), the component d
        beta = {}
        for K in masks(n, k + 1):
            b = bits(K); t = {}
            for i in range(k + 1): t = sp_add(t, sp_der(al.get(K ^ (1 << b[i]), {}), b[i]), (-1) ** i)
            beta[K] = t
        B0 = {K: at0(p, n) for K, p in beta.items()}
        def Bv(tup): M, s = tsort(tup); return s * B0.get(M, 0) if s else 0
        for I in masks(n, k):
            a = bits(I); v = F(0)
            for m in range(n):
                M, s = tsort([m] + a)
                for r in range(n):
                    if not g0i[m][r]: continue
                    w = s * at0(sp_der(beta.get(M, {}), r), n) if s else F(0)
                    for q in range(n):
                        w -= G0[(q, r, m)] * Bv([q] + a)
                        for i in range(k): w -= G0[(q, r, a[i])] * Bv([m] + a[:i] + [q] + a[i + 1:])
                    v += g0i[m][r] * w
            SD[I] += v
    SB = {}
    for I in masks(n, k):                                                  # the rough Laplacian
        a = bits(I); v = F(0)
        for m in range(n):
            for r in range(n):
                if not g0i[m][r]: continue
                w = at0(sp_der(Na[(r, I)], m), n)
                for q in range(n):
                    w -= G0[(q, m, r)] * Na0[(q, I)]
                    for i in range(k): w -= G0[(q, m, a[i])] * Nv(r, a[:i] + [q] + a[i + 1:])
                v += g0i[m][r] * w
        SB[I] = v
    ric = [[sum(Rm[(r, s, r, v)] for r in range(n)) for v in range(n)] for s in range(n)]           # R_sv = R^r_srv
    ricup = [[sum(ric[s][t] * g0i[t][m] for t in range(n)) for m in range(n)] for s in range(n)]    # Ric_s^m
    Rl = {(p, s, m, v): sum(g0[p][r] * Rm[(r, s, m, v)] for r in range(n)) for p in range(n) for s in range(n) for m in range(n) for v in range(n)}
    Rmix = {(p, dd, q, ee): sum(Rl[(p, d1, q, e1)] * g0i[d1][dd] * g0i[e1][ee] for d1 in range(n) for e1 in range(n))
            for p in range(n) for dd in range(n) for q in range(n) for ee in range(n)}                # R_p^d_q^e
    SRic, SRiem, T2 = {}, {}, {}
    for I in masks(n, k):
        a = bits(I)
        SRic[I] = sum((ricup[a[i]][dd] * Av(a[:i] + [dd] + a[i + 1:]) for i in range(k) for dd in range(n)), F(0))
        v = F(0)
        for i in range(k):
            for j in range(k):
                if i == j: continue
                for dd in range(n):
                    for ee in range(n):
                        tup = list(a); tup[i] = dd; tup[j] = ee; v += Rmix[(a[i], dd, a[j], ee)] * Av(tup)
        SRiem[I] = v
        if k == 2:
            p, q = a
            T2[I] = (sum((ricup[p][c] * Av([c, q]) + ricup[q][c] * Av([p, c]) for c in range(n)), F(0))
                     - 2 * sum((Rmix[(p, c, q, dd)] * Av([c, dd]) for c in range(n) for dd in range(n)), F(0)))
    fr = lambda X: frame_vals(X, E0, n, k)
    return dict(SD=fr(SD), SB=fr(SB), SRic=fr(SRic), SRiem=fr(SRiem), coordD=SD, coordB=SB, T2=T2)

# ------------------------------------------------------------------------------------------------ the claimed coefficients and the cases
CLAIM = {None: (F(-1), F(1)), 'ONEFORM': (F(-1), F(0)), 'RIEMSIGN': (F(-1), F(-1))}[FAULT]
RANK = lambda k, n: 0 if k == 0 else (1 if k in (1, n) else 2)
TABLE = {}
def fit_rows(ts, use_riem=True):
    rows, rhs = [], []
    for t in ts:
        for I in sorted(t['Delta']):
            rows.append([t['RicT'][I], t['RiemT'][I]] if use_riem else [t['RicT'][I]]); rhs.append(t['Delta'][I] - t['Box'][I])
    return rows, rhs
def describe(k, n, w, rank, cons):
    if not cons: return 'inconsistent'
    if k == 0: return 'both operators 0, residual 0'
    if k == 1: return '(x, y) = (%s, %s), Riem = 0 on 1-forms' % (w[0], w[1] if len(w) > 1 else 0)
    if k == n: return 'Ric = Riem = R alpha, residual 0: x + y = 0'
    return '(x, y) = (%s, %s)' % tuple(w) if rank == 2 else 'rank %d: %s' % (rank, w)

KK = ' (Cl(1,3) and a fifth generator of square %s: the Kaluza-Klein algebra %s of proofs/shifted_einstein.py, se.KK)'
def cases(n):
    """(name, squares, seed offset, note) for dimension n: Lorentz and Euclidean squares at every n; at n = 5 the Lorentz squares are Cl(1,4), and
    Cl(2,3) is added (the two Kaluza-Klein algebras of shifted_einstein.py: Cl(1,3) and a fifth generator of square -1 or +1)"""
    out = [('Lorentz', LORENTZ(n), 0, KK % ('-1', 'Cl(1,4)') if n == 5 else ''), ('Euclidean', [1] * n, 1, '')]
    if n == 5: out.append(('Cl(2,3)', [1, -1, -1, -1, 1], 2, KK % ('+1', 'Cl(2,3)')))
    return out

def run_case(n, sq, sname, seed, note=''):
    head('(F) n = %d, %s squares %s%s: (d delta + delta d) alpha - nabla^c nabla_c alpha = x Ric(alpha) + y Riem(alpha), k = 0..%d' % (n, sname, sq, note, n))
    rng = random.Random(seed); frames = [GSB.jets_frame(rng, n) for _ in range(3)] + [rand_frame(random.Random(seed + 50), n, deg=2, coef=2, density=.5)]
    ds = [engine_setup(e, n, sq) for e in frames]
    chk('bit', all(d['tf'] for d in ds) and all(d['Rs'] != 0 for d in ds) and all(d['ric'][(0, 1)] != 0 for d in ds),
        'n=%d %s: three strong draws (e = dx + 1-jet + 2-jet, integers -50..50) and one frame with e(0) != 1 (b1lib.rand_frame, part (W)\'s rule): the A3 omega is torsion-free as a 1-jet, R != 0, Ric_01 != 0 on all four (R = %s on the first)' % (n, sname, ds[0]['Rs']))
    ctl1, ctl2, ctl3 = True, True, True; std_ok = True; std_alone = True; t2_ok = True; cl_ok = True; cl_grade = True; t2_seen = False; lap_ok = True
    allt = {}
    for k in range(n + 1):
        forms = [jets_form(rng, n, k) for _ in range(3)] + [small_form(random.Random(seed + 60 + k), n, k, c0=n >= 5)]
        ts = [bit_terms(d, al, k) for d, al in zip(ds, forms)]; allt[k] = (ts, forms)
        rows, rhs = fit_rows(ts[:2], use_riem=not (FAULT == 'ONEFORM' and k >= 2))
        w, rank, nvar, cons = solve_exact(rows, rhs)
        x, y = CLAIM; ver = all(holds(t, x, y) for t in ts)
        nontriv = any(any(v != 0 for v in t['Delta'].values()) for t in ts)
        if k == 0: ok = cons and rank == 0 and all(not any(t['RicT'].values()) and not any(t['RiemT'].values()) and not any(residual(t).values()) for t in ts)
        elif k == 1: ok = cons and rank == 1 and w[0] == -1 and all(not any(t['RiemT'].values()) for t in ts) and any(any(t['RicT'].values()) for t in ts)
        elif k == n: ok = cons and rank == 1 and all(not any(residual(t).values()) and t['RicT'] == t['RiemT'] == {I: d['Rs'] * t['a0'].get(I, 0) for I in t['Delta']} for t, d in zip(ts, ds)) and all(any(t['RicT'].values()) for t in ts)
        else: ok = cons and rank == nvar == 2 and w == [x, y] and all(any(t['RiemT'].values()) for t in ts)
        TABLE[(k, n, sname)] = describe(k, n, w, rank, cons) if FAULT is None else None
        chk('bit', ok and ver and nontriv, 'n=%d %s k=%d: exact fit on two strong draws (%d equations, rank %d): %s; the claim (x, y) = (%s, %s) holds on all four frames (fit, a third strong draw, e(0) != 1)' % (n, sname, k, len(rows), rank, describe(k, n, w, rank, cons), x, y))
        if k >= 2:
            ctl1 &= all(not holds(t, F(-1), F(0)) for t in ts); ctl2 &= all(not holds(t, F(-1), F(-1)) for t in ts)
            if k < n: ctl3 &= not solve_exact(*fit_rows(ts[:2], use_riem=False))[3]
        # [std] on the frame with e(0) != 1
        st = std_terms(frames[3], forms[3], k, n, sq, ds[3]['E0']); t = ts[3]
        std_ok &= st['SD'] == t['Delta'] and st['SB'] == t['Box'] and st['SRic'] == t['RicT'] and st['SRiem'] == t['RiemT']
        std_alone &= all(st['SD'][I] == st['SB'][I] + x * st['SRic'][I] + y * st['SRiem'][I] for I in st['SD'])
        if k == 2:
            t2_seen = True; t2_ok &= all(-st['coordD'][I] == -st['coordB'][I] + st['T2'][I] for I in st['T2']) and any(st['T2'].values())
        # (C) the Clifford form on a strong draw and on the e(0) != 1 frame
        for j in (0, 3):
            gPhi, D2, Lap = clifford_terms(ds[j], ts[j]); tj = ts[j]; ev = lambda I: eta_of(I, sq)
            cl_grade &= set(gPhi) <= {k - 1, k + 1} and set(SE.grades(D2)) <= {k}
            cl_ok &= all(D2.get(I, 0) == ev(I) * tj['Delta'][I] and Lap.get(I, 0) == ev(I) * tj['Box'][I] and D2.get(I, 0) - Lap.get(I, 0) == ev(I) * (x * tj['RicT'][I] + y * tj['RiemT'][I]) for I in tj['Delta'])
            cl_ok &= set(D2) <= set(tj['Delta']) and set(Lap) <= set(tj['Delta'])
        if n >= LAPLACE_N:                                                 # the Laplace-minor frame components against g2_hodge's permutation sum
            with trunc(n, xdeg=2): lap_ok &= GH.frame_components(forms[3], ds[3]['E2'], n) == ts[3]['afr'] and bool(ts[3]['afr'])
    if n >= LAPLACE_N:
        chk('bit', lap_ok, 'n=%d %s: the frame components of alpha at x-degree 2 from the memoized Laplace minors of the dual frame (used from n = %d on) equal g2_hodge.frame_components (the permutation sum, used for n <= %d) on the e(0) != 1 frame, k = 0..%d' % (n, sname, LAPLACE_N, LAPLACE_N - 1, n))
    chk('ctl', ctl1 and ctl3, 'n=%d %s: the 1-form coefficients (x, y) = (-1, 0) fail on every frame for k = 2..%d, and without the Riem column no x fits for k = %s (fit inconsistent)' % (n, sname, n, '2' if n == 3 else '2..%d' % (n - 1)))
    chk('ctl', ctl2, 'n=%d %s: the opposite sign (x, y) = (-1, -1) fails on every frame for k = 2..%d' % (n, sname, n))
    chk('bit==std', std_ok, 'n=%d %s: [std] Christoffel calculus on g = e^T eta e (exact series) on the e(0) != 1 frame, k = 0..%d: d(div alpha) + div(d alpha), g^{mr} nabla_m nabla_r alpha, Ric(alpha) and Riem(alpha) (coordinate R^r_smv, MTW) read in the frame equal the engine\'s four terms' % (n, sname, n))
    chk('std', std_alone and (t2_ok or not t2_seen), 'n=%d %s: [std] alone: d(div alpha) + div(d alpha) = nabla^2 alpha + (%s) Ric(alpha) + (%s) Riem(alpha) for k = 0..%d%s' % (n, sname, x, y, n, '; k = 2, textbook (coordinate components): Delta_H alpha_ab = -nabla^2 alpha_ab + Ric_a^c alpha_cb + Ric_b^c alpha_ac - 2 R_a^c_b^d alpha_cd, Delta_H = d d^dagger + d^dagger d, d^dagger = -div' if t2_seen else ''))
    chk('bit', cl_ok and cl_grade, 'n=%d %s: (1.5) on the full algebra (shifted_einstein\'s connection), X^S = eta_S alpha_S of grade k = 0..%d, a strong draw and the e(0) != 1 frame: D X has grades k-1, k+1 only, D^2 X has grade k only and equals (d delta + delta d) alpha, box X equals nabla^c nabla_c alpha, so D^2 X - box X = (%s) Ric(X) + (%s) Riem(X)' % (n, sname, n, x, y))
    tick('n=%d %s' % (n, sname))
    # the degree in the sampled coefficients along a random line (frames and forms), every k
    rl = random.Random(seed + 70); eb = GSB.jets_frame(rl, n); ea = GSB.jets_frame(rl, n, ident=False)
    fb = {k: jets_form(rl, n, k) for k in range(n + 1)}; fa = {k: jets_form(rl, n, k) for k in range(n + 1)}; vals = {k: [] for k in range(n + 1)}
    for tt in range(5):
        et = [{m: padd(eb[a].get(m, {}), ea[a].get(m, {}), tt) for m in set(eb[a]) | set(ea[a])} for a in range(n)]
        dt = engine_setup(et, n, sq)
        for k in range(n + 1):
            alt = {M: padd(fb[k].get(M, {}), fa[k].get(M, {}), tt) for M in set(fb[k]) | set(fa[k])}
            vals[k].append(bit_terms(dt, alt, k))
    degs = []; le3 = True
    for k in range(n + 1):
        def diff(order, key, I):
            return sum((vals[k][tt][key][I] * (-1) ** (order - tt) * GSB.comb(order, tt) for tt in range(order + 1)), F(0))
        keys = ('Delta', 'Box', 'RicT', 'RiemT'); Is = list(vals[k][0]['Delta'])
        le3 &= all(diff(4, key, I) == 0 for key in keys for I in Is)
        degs.append(max([o for o in range(4) for key in keys for I in Is if diff(o, key, I) != 0] or [0]))
    chk('bit', le3 and max(degs) == 3, 'n=%d %s: along a random line in the sampled coefficients (frame jets and forms) the four terms have degree <= 3 for every k (fourth finite difference zero); degree reached for k = 0..%d: %s; a false identity of this form passes the three strong draws with probability <= (3/101)^3 = 2.6e-5 per k (Schwartz-Zippel)' % (n, sname, n, degs))
    tick('n=%d %s line' % (n, sname))

def part_W1():
    head('(W1) k = 1 against part (W) of gsb_dirac_sq.py: its three frames and 1-forms, its bit_weitz vectors')
    for n in (3, 4):
        sq = LORENTZ(n); ok = True; nz = True
        for j in range(3):
            Delta, Box, Ra, e, al, dW = GSB.bit_weitz(n, sq, 9500 + 10 * n + j)
            t = bit_terms(engine_setup(e, n, sq), al, 1)
            ok &= all(t['Delta'][1 << b] == Delta[b] and t['Box'][1 << b] == Box[b] and t['RicT'][1 << b] == Ra[b] for b in range(n)) and not any(t['RiemT'].values())
            nz &= any(x != 0 for x in Ra)
        chk('bit', ok and nz, 'n=%d Lorentz: on part (W)\'s three frames (seeds 9500 + 10n + j) the general-degree code at k = 1 returns (W)\'s (d delta + delta d) alpha, nabla^c nabla_c alpha and Ric alpha exactly (Riem = 0 on 1-forms): the (x, y) = (-1, 0) of (W), (1.3)' % n)
    tick('W1')

def main():
    dims = list(range(3, NMAX + 1))
    title = 'WEITZ-FORMS: the Weitzenboeck formula on k-forms, k = 0..n, n = 3, 4, Lorentz and Euclidean squares, and its Clifford form'
    if NMAX >= 5: title += '; n = 5: Lorentz (= Cl(1,4)), Cl(2,3) and Euclidean squares'
    if NMAX >= 6: title += '; n = 6: Lorentz and Euclidean squares'
    head(title + (' [fault %s]' % FAULT if FAULT else ''))
    for n in dims:
        for sname, sq, s, note in cases(n):
            run_case(n, sq, sname, 24000 + 100 * n + 10 * s, note)
    part_W1()
    if FAULT is None:
        head('Table: the fit of (d delta + delta d) alpha - nabla^c nabla_c alpha = x Ric(alpha) + y Riem(alpha)')
        for n in dims:
            for sname, *_ in cases(n):
                info('n=%d %-9s ' % (n, sname) + '; '.join('k=%d: %s' % (k, TABLE[(k, n, sname)]) for k in range(n + 1)))
    info('total %.1f s' % (time.time() - T0))
    finish('WEITZ-FORMS')

if __name__ == '__main__': main()
