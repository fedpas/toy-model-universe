#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""EINSTEIN-RIEM.  The reading of l3_cartan_weyl.py / A4 of the engine's Einstein form, E_a(c) = -M^h_a Theta_h with M = G - 3c delta, in the
Riemannian cell (4,0): squares (+1,+1,+1,+1), Lie((1,1,1,1)) and its Koszul table.  Exact Fractions at the origin of exact rational 2-jet frames.
   python3 einstein_riem.py [<folder of the gravity checks>] [--fault 2C|SIGN]   (default folder: the script's own; engine modules read only)
 [bit]  omega = A3 closed form (1-jet), R = d omega + 1/4 [omega, omega], E_a(c) = Grav.einstein(None, e, R, c) (l3_cartan_weyl.engine_F), read as
        M^b_a = mixed_from_components(E(c), e0, det) exactly as l3 reads it.
 [std]  an own exact Christoffel route on g = e^T delta e (Taylor coefficients of the jets, Gamma, d Gamma, Riemann MTW sign, Ricci, G^b_a in the
        frame); cross-checked against g2_weyl.std_frame_riemann (b1lib.std_riemann) with squares (+,+,+,+).
 Frames: 6 strong draws e = dx + 1-jet + 2-jet (every coefficient uniform in -50..50, the gsb_dirac_sq.py rule), 2 rand_frame draws with e(0) != 1;
        Einstein: round S^4 and CP^2 Fubini-Study (aty_matter_models.s4_frame / cp2_frame, 3 points each), own g = delta/(1 + K|x|^2/4)^2, K = -1, 1/3.
 Controls (--fault puts each into the main checks, exit 1): 2C the reading G - 2c delta; SIGN the reading G + 3c delta.
 Also as controls: 2c in place of 3c, -3c in place of 3c, the sign s = +1 of the reading, the Lorentzian metric e^T eta e in the std route, c* -> -c*, 3c*/2."""
import sys, os, time, random, itertools
from math import comb
FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
POS = [a for i, a in enumerate(sys.argv[1:], 1) if not a.startswith('--') and sys.argv[i - 1] != '--fault']
GRAV = os.path.abspath(POS[0]) if POS else os.path.dirname(os.path.abspath(__file__))
KF = {None: 3, '2C': 2, 'SIGN': -3}[FAULT]
sys.path.insert(0, GRAV)                                                       # the engine modules (read only)
ARGV = sys.argv; sys.argv = sys.argv[:1]     # aty_matter_models reads --fault at import and knows only its own names: it sees no options
from b1lib import (F, Lie, Grav, koszul_S, trunc, torsion_zero_at0, mixed_from_components, solve_exact, det_inv, rand_frame, padd,
                   lin, const, var, scale, sp_mul)
from g2_weyl import std_frame_riemann, weyl_parts
import l3_cartan_weyl as L3
import aty_matter_models as AM
sys.argv = ARGV

SQ = [1, 1, 1, 1]; ETA = [1, -1, -1, -1]; N = 4; R4 = range(4)
T0 = time.time(); FAILS = []
def ck(cond, msg):
    print(('ok   ' if cond else 'FAIL ') + msg, flush=True)
    if not cond: FAILS.append(msg)
def info(s): print('     ' + s, flush=True)
def dl(a, b): return F(1) if a == b else F(0)

# ------------------------------------------------------------------------------------------------ [bit] the engine in the cell (4,0)
GV = Grav(N, Lie(list(SQ))); SK = koszul_S(N, list(SQ), GV.L)
def engine(e, cs):
    """E_a(c) components and M(c) = mixed_from_components (l3's reading, s = -1) for c in cs; torsion at the point"""
    d = L3.engine_F(GV, e, SK, cs)
    with trunc(N, xdeg=0): tz = torsion_zero_at0(GV, d['om'], e, N)
    M = {c: mixed_from_components(d['E'][c], d['e0'], d['det'], N) for c in cs}
    Mp = {c: mixed_from_components(d['E'][c], d['e0'], d['det'], N, s=1) for c in cs}
    return dict(E=d['E'], M=M, Mp=Mp, tz=tz, e0=d['e0'], E0=d['E0'], det=d['det'])

# ------------------------------------------------------------------------------------------------ [std] own exact Christoffel route on g = e^T diag(sq) e
def taylor(e):
    z = (0,) * N; u = [tuple(int(i == k) for i in R4) for k in R4]; u2 = lambda k, l: tuple(int(i == k) + int(i == l) for i in R4)
    P = lambda a, m: e[a].get(1 << m, {})
    e0 = [[P(a, m).get(z, F(0)) for m in R4] for a in R4]
    e1 = [[[P(a, m).get(u[k], F(0)) for k in R4] for m in R4] for a in R4]
    e2 = [[[[P(a, m).get(u2(k, l), F(0)) * (2 if k == l else 1) for l in R4] for k in R4] for m in R4] for a in R4]
    return e0, e1, e2
def std_G(e, sq=SQ):
    """G^b_a (frame, mixed), Ric^b_a, Rs at the origin; MTW sign R^r_{smv} = d_m G^r_{vs} - d_v G^r_{ms} + G^r_{ml} G^l_{vs} - G^r_{vl} G^l_{ms}"""
    e0, e1, e2 = taylor(e)
    g = [[sum(sq[a] * e0[a][m] * e0[a][n] for a in R4) for n in R4] for m in R4]
    dg = [[[sum(sq[a] * (e1[a][m][k] * e0[a][n] + e0[a][m] * e1[a][n][k]) for a in R4) for n in R4] for m in R4] for k in R4]
    ddg = [[[[sum(sq[a] * (e2[a][m][k][l] * e0[a][n] + e1[a][m][k] * e1[a][n][l] + e1[a][m][l] * e1[a][n][k] + e0[a][m] * e2[a][n][k][l]) for a in R4)
              for n in R4] for m in R4] for l in R4] for k in R4]
    gi = det_inv(g)[1]
    dgi = [[[-sum(gi[i][p] * dg[k][p][q] * gi[q][j] for p in R4 for q in R4) for j in R4] for i in R4] for k in R4]
    B = [[[dg[m][s][n] + dg[n][s][m] - dg[s][m][n] for n in R4] for m in R4] for s in R4]
    Gam = [[[sum(gi[l][s] * B[s][m][n] for s in R4) / 2 for n in R4] for m in R4] for l in R4]
    dGam = [[[[sum(dgi[k][l][s] * B[s][m][n] + gi[l][s] * (ddg[k][m][s][n] + ddg[k][n][s][m] - ddg[k][s][m][n]) for s in R4) / 2
               for n in R4] for m in R4] for l in R4] for k in R4]
    Rm = lambda r, s, m, v: (dGam[m][r][v][s] - dGam[v][r][m][s] + sum(Gam[r][m][l] * Gam[l][v][s] - Gam[r][v][l] * Gam[l][m][s] for l in R4))
    Ric = [[sum(Rm(r, s, r, v) for r in R4) for v in R4] for s in R4]
    Rs = sum(gi[s][v] * Ric[s][v] for s in R4 for v in R4)
    Rmix = [[sum(gi[m][s] * Ric[s][v] for s in R4) for v in R4] for m in R4]
    E0 = det_inv(e0)[1]; fr = lambda X: [[sum(e0[b][m] * X[m][v] * E0[v][a] for m in R4 for v in R4) for a in R4] for b in R4]
    Ricf = fr(Rmix); G = [[Ricf[b][a] - Rs / 2 * dl(a, b) for a in R4] for b in R4]
    return dict(G=G, Ric=Ricf, Rs=Rs, tf=[[Ricf[b][a] - Rs / 4 * dl(a, b) for a in R4] for b in R4])
def pred(G, c, k=None):
    k = KF if k is None else k
    return [[G[b][a] - k * c * dl(a, b) for a in R4] for b in R4]
def is0(M): return all(x == 0 for row in M for x in row)
def ric_g2(e):
    """[std] the frame Ricci tensor of g2_weyl.std_frame_riemann (b1lib.std_riemann) with squares (+,+,+,+): Ric_bd = sum_a R_abad"""
    _, Ric, Rs, _ = weyl_parts(std_frame_riemann(e, N, list(SQ), N), list(SQ)); return [[Ric[(b, a)] for a in R4] for b in R4], Rs

# ------------------------------------------------------------------------------------------------ frames
def strong_frame(rng, ident=True, lo=-50, hi=50):
    """e^a_mu = delta^a_mu + every monomial of degree 1 and 2 with an integer coefficient uniform in lo..hi (gsb_dirac_sq.jets_frame)"""
    mons = [ex for ex in itertools.product(range(3), repeat=N) if 1 <= sum(ex) <= 2]; e = []
    for a in R4:
        form = {}
        for mu in R4:
            p = {(0,) * N: F(1)} if (ident and a == mu) else {}
            for ex in mons:
                c = rng.randint(lo, hi)
                if c: p[ex] = F(c)
            if p: form[1 << mu] = p
        e.append(form)
    return e
def cc_frame(p, K):
    """e^a = f dx^a, f = 1/(1 + K|x|^2/4) as an exact 2-jet at the point p: constant sectional curvature K, Ric = 3K delta"""
    p = [F(x) for x in p]; K = F(K); u0 = 1 + K * sum(x * x for x in p) / 4
    v = lin(*[(K * p[i] / (2 * u0), var(N, i)) for i in R4], *[(K / (4 * u0), sp_mul(var(N, i), var(N, i), 2, N)) for i in R4])
    f = scale(lin((F(1), const(N, 1)), (F(-1), v), (F(1), sp_mul(v, v, 2, N))), 1 / u0)
    return [{1 << a: f} for a in R4]

# ------------------------------------------------------------------------------------------------ checks
CS = [F(0), F(1, 3), F(-2, 7)]
def analyse(name, e, cs):
    en = engine(e, cs); st = std_G(e); Rg, Rsg = ric_g2(e)
    affine = all(en['E'][c][k] == en['E'][cs[0]][k] + (c - cs[0]) / (cs[1] - cs[0]) * (en['E'][cs[1]][k] - en['E'][cs[0]][k]) for c in cs for k in en['E'][c])
    eq = all(en['M'][c] == pred(st['G'], c) for c in cs)
    K_ = {k: en['E'][cs[1]][k] - en['E'][cs[0]][k] for k in en['E'][cs[0]]}; keys = sorted(K_)
    w, rank, _, _ = solve_exact([[K_[k] / (cs[1] - cs[0])] for k in keys], [-(en['E'][cs[0]][k] - cs[0] * K_[k] / (cs[1] - cs[0])) for k in keys])
    ctl = dict(two=all(en['M'][c] != pred(st['G'], c, 2) for c in cs if c != 0), sign=all(en['M'][c] != pred(st['G'], -c) for c in cs if c != 0),
               s1=all(en['Mp'][c] != pred(st['G'], c) for c in cs))
    return dict(name=name, en=en, st=st, tz=en['tz'], affine=affine, eq=eq, sol=(w[0] if w else None), rank=rank, ctl=ctl,
                g2=(Rg == st['Ric'] and Rsg == st['Rs']), e=e)

def main():
    print('EINSTEIN-RIEM: E_a(c) read as M = G - 3c delta in the cell (4,0), squares %s; n = 4, exact 2-jets at the origin' % (tuple(SQ),), flush=True)
    rng = random.Random(40400)
    gen = [analyse('strong draw %d' % i, strong_frame(rng), CS) for i in range(6)]
    gen += [analyse('rand_frame seed %d (e(0) != 1)' % s, rand_frame(random.Random(s), N, 2, 3), CS) for s in (5, 6)]
    info('generic frames done (%.1f s)' % (time.time() - T0))
    ck(all(r['tz'] for r in gen), 'precondition: torsion T = 0 at the point (A3 omega, Lie((1,1,1,1)) and its Koszul table) on all %d generic frames' % len(gen))
    ck(all(r['g2'] for r in gen), '[std] the own Christoffel route = g2_weyl.std_frame_riemann (b1lib.std_riemann, squares (+,+,+,+)): same frame Ricci and Rs, %d frames' % len(gen))
    ck(all(r['affine'] for r in gen), '[bit] the engine E_a(c) is affine in c (E(-2/7) on the line through E(0), E(1/3)), all 16 components: equality at two c is equality for c symbolic')
    ck(all(r['eq'] for r in gen), '[bit==std] 1. M(c) read from the engine E_a(c) (l3/A4: mixed_from_components, s = -1) = G - 3c delta of the Christoffel route on '
       'g = e^T delta e, all 16 frame components exactly, c in {0, 1/3, -2/7} (so for c symbolic), on 6 strong draws + 2 rand_frame draws')
    nz = [sum(1 for row in r['st']['tf'] for x in row if x != 0) for r in gen]
    ck(all(n > 0 for n in nz) and all(r['sol'] is None and r['rank'] == 1 for r in gen), '[bit] 2a. generic frames: trace-free Ricci != 0 (%s nonzero of 16) and '
       'E_a(c) = 0 (16 equations, affine in c, rank 1) has NO solution c on all %d frames, c = -Rs/12 included' % ('/'.join(map(str, nz)), len(gen)))
    # the degree of the identity in the sampled coefficients, along a random line b + t a (e(0) part fixed to 1)
    eb = strong_frame(rng); ea = strong_frame(rng, ident=False); vals = []
    for t in range(4):
        et = [{m: padd(eb[a].get(m, {}), ea[a].get(m, {}), t) for m in set(eb[a]) | set(ea[a])} for a in R4]
        en = engine(et, [F(1, 3)]); st = std_G(et); vals.append((en['E'][F(1, 3)], st['G']))
    dE = lambda o: {k: sum((-1) ** (o - t) * comb(o, t) * vals[t][0][k] for t in range(o + 1)) for k in vals[0][0]}
    dG = lambda o: [[sum((-1) ** (o - t) * comb(o, t) * vals[t][1][b][a] for t in range(o + 1)) for a in R4] for b in R4]
    degok = all(v == 0 for v in dE(3).values()) and is0(dG(3)) and any(v != 0 for v in dE(2).values()) and not is0(dG(2))
    ck(degok, '[bit] degree: with e(0) = 1 (a linear change of coordinates reaches it) the engine E_a(c) and the std G are polynomials of degree <= 2 in the 224 '
       'sampled jet coefficients (omega(0) linear, d omega(0) and [omega, omega](0) quadratic; c enters as c x const); along a random line the third finite '
       'difference is 0 and the second is not: degree 2 reached.  Schwartz-Zippel: a false identity (nonzero residual of degree <= 2) passes one draw with '
       'coefficients uniform in -50..50 with probability <= 2/101, all 6 strong draws with probability <= (2/101)^6 = %.1e' % (F(2, 101) ** 6))
    ck(all(r['ctl']['two'] for r in gen), '[ctl] 3a. 2c in place of 3c: M(c) != G - 2c delta at every c != 0 on every generic frame (ok)')
    ck(all(r['ctl']['sign'] for r in gen), '[ctl] 3b. the wrong sign of c: M(c) != G + 3c delta at every c != 0 on every generic frame (ok)')
    ck(all(r['ctl']['s1'] for r in gen), '[ctl] 3c. the reading with the sign s = +1 (E_a = +M Theta): != G - 3c delta at every c on every generic frame (ok)')
    lor = [std_G(r['e'], ETA)['G'] for r in gen]
    ck(all(r['en']['M'][c] != pred(Gl, c) for r, Gl in zip(gen, lor) for c in CS), '[ctl] 3d. the Lorentzian metric e^T eta e (eta = diag(1,-1,-1,-1)) in the '
       'Christoffel route on the same jets: G_eta - 3c delta != the engine reading of the cell (4,0), every frame and c (ok: the squares are seen)')
    # Einstein frames
    ein = [('S^4 p = (%s)' % ', '.join(map(str, p)), AM.s4_frame(p), F(3)) for p in AM.S4_PTS]
    ein += [('CP^2 FS p = (%s)' % ', '.join(map(str, p)), AM.cp2_frame(p), F(6)) for p in AM.CP2_PTS]
    ein += [('K = %s p = (%s)' % (K, ', '.join(map(str, p))), cc_frame(p, K), 3 * F(K)) for (K, p) in
            ((F(-1), (F(1, 2), 0, F(1, 3), -1)), (F(-1), (F(-1, 5), F(3, 4), 1, F(1, 2))), (F(1, 3), (2, -1, F(1, 2), 3)))]
    eres = []
    for name, e, lam in ein:
        cstar = -lam / 3; r = analyse(name, e, CS + [cstar, -cstar, 3 * cstar / 2]); eres.append((r, lam, cstar))
        E = r['en']['E']; zero = lambda c: all(v == 0 for v in E[c].values())
        r['ok'] = (r['tz'] and r['g2'] and r['affine'] and r['eq'] and r['st']['Ric'] == [[lam * dl(a, b) for a in R4] for b in R4] and r['rank'] == 1
                   and r['sol'] == cstar == -r['st']['Rs'] / 12 and zero(cstar) and not any(zero(c) for c in CS if c != cstar))
        r['ctl_ok'] = not zero(-cstar) and not zero(3 * cstar / 2)
    info('Einstein frames done (%.1f s)' % (time.time() - T0))
    ck(all(r['ok'] for r, _, _ in eres), '[bit==std] 2b. Einstein frames (%d): T = 0, M(c) = G - 3c delta exactly (c in {0, 1/3, -2/7, c*, -c*, 3c*/2}), Ric = lambda delta '
       '(std), and E_a(c) = 0 has exactly one solution c = c* = -lambda/3 = -Rs/12 (rank 1): %s' % (len(eres), '; '.join('%s: lambda = %s, c* = %s' % (r['name'], lam, cs)
                                                                                                            for r, lam, cs in eres)))
    ck(all(r['ctl_ok'] for r, _, _ in eres), '[ctl] 3e. Einstein frames: c = -c* (the wrong sign of c) and c = 3c*/2 (G = 2c delta, the 2c reading) give E_a(c) != 0 (ok)')
    print('\nTOTAL %.1f s; FAILS: %s' % (time.time() - T0, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

if __name__ == '__main__': main()
