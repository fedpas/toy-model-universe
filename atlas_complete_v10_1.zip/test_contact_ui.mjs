// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The contact form in the browser, against a faked /api/contact: the footer link opens the dialog (EN and IT, 1100 px and 375 px), the puzzle, a wrong and a right answer, every error
// sentence, a route that is not configured, keyboard (focus in, Tab trapped, Escape closes, focus back), labels and focus rings, and no overflow or page error down to 320 px.
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import { CONTACT, CONTACT_LIMITS as LIM } from './contactCopy.js';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const b = await chromium.launch(); const errs = [];
const DIST = process.env.ATLAS_DIST || PKG_DIST;
const srv = http.createServer((q, r) => { const f = path.join(DIST, q.url.split('?')[0].replace(/^\/+/, '') || 'app.html'); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' }); r.end(d); }); });
await new Promise(r => srv.listen(0, r)); const ORIGIN = `http://localhost:${srv.address().port}`, PAGE = `${ORIGIN}/app.html#rule`;
const fmt = (s, v) => s.replace(/\{(\w+)\}/g, (_, k) => v[k]);
const PAIRS = [[9, 5], [6, 3], [12, 10], [7, 2], [13, 8], [11, 4], [14, 1], [15, 6]];
// the page opens with the Young Learner (the default audience), who asks for ?aud=yl and gets plain-word puzzles (re-test T1-8); a Physicist pass at the end checks the usual ones
const QUESTION = (lang, [a, c], aud = 'yl') => aud === 'yl' ? (lang === 'it' ? `Domanda di prova: quanto fa ${a} XOR ${c}?` : `Test question: what is ${a} XOR ${c}?`) : lang === 'it' ? `Domanda di prova: l’elemento n. ${a} per l’elemento n. ${c} dà più o meno l’elemento n. c. Quanto vale c?` : `Test question: basis element no. ${a} times basis element no. ${c} is plus or minus basis element no. c. What is c?`;
const TECH = /e_|·|basis|element|grade|generator|index|binary|algebra|carry|elemento|grado|generator|indice|binario|riporto/i;
const ANSWER = ([a, c]) => String(a ^ c);

// a fake /api/contact for one page: it numbers its puzzles, remembers every request, and answers a POST as `S.post` says
function fake(pg, S) {
  S.gets = []; S.posts = []; S.get = 'ok'; S.post = 'ok'; S.delay = 0;
  const cur = () => PAIRS[(S.gets.length - 1) % PAIRS.length];
  return pg.route(/\/api\/contact(\?.*)?$/, async route => {
    const req = route.request(), json = (status, body, headers = {}) => route.fulfill({ status, contentType: 'application/json', headers, body: JSON.stringify(body) });
    if (req.method() === 'GET') {
      S.gets.push(req.url()); if (S.getDelay) await new Promise(r => setTimeout(r, S.getDelay)); if (S.get === '503') return json(503, { error: 'not_configured' }); if (S.get === 'abort') return route.abort('failed'); if (S.get === 'junk') return route.fulfill({ status: 200, contentType: 'text/html', body: '<html>' });
      const u = new URL(req.url()), lang = u.searchParams.get('lang'), aud = u.searchParams.get('aud') === 'yl' ? 'yl' : null; return json(200, { token: 'tok-' + S.gets.length, question: QUESTION(lang, cur(), aud), hint: aud ? CONTACT[lang].hintPlain : CONTACT[lang].hint, expiresIn: 600 });
    }
    const body = req.postDataJSON(); S.posts.push(body); if (S.delay) await new Promise(r => setTimeout(r, S.delay));
    if (S.post === 'abort') return route.abort('failed');
    if (S.post === 'ok') return body.token === 'tok-' + S.gets.length && body.answer === ANSWER(cur()) ? json(200, { ok: true }) : json(400, { error: 'wrong_answer' });
    if (S.post === 'rate') return json(429, { error: 'rate_limited' }, { 'retry-after': '125' });
    if (S.post === 'unknown') return json(400, { error: 'something_new' });
    return json(Number(S.status) || 400, { error: S.post });
  });
}

for (const lang of ['en', 'it']) for (const w of [1100, 375]) {
  const tag = `${lang}${w}`, t = CONTACT[lang], pg = await b.newPage({ viewport: { width: w, height: 800 } }), S = {}, reqs = [];
  pg.on('pageerror', e => errs.push(`${tag}: page error ${e.message}`)); pg.on('console', m => m.type() === 'error' && !/^Failed to load resource/.test(m.text()) && errs.push(`${tag}: console error ${m.text()}`));
  pg.on('request', r => { if (!r.url().startsWith(ORIGIN) && !r.url().startsWith('data:')) reqs.push(r.url()); });
  try {
  await fake(pg, S); await pg.goto(PAGE); await pg.waitForTimeout(300); if (lang === 'it') await setLang(pg, 'it');
  const dlg = pg.locator('[role=dialog]'), link = pg.locator('footer .contact-link');
  const active = () => pg.evaluate(() => { const a = document.activeElement; return a ? (a.id || a.getAttribute('name') || a.tagName) + '|' + (a.closest('[role=dialog]') ? 'in' : 'out') : 'none'; });
  const open = async (ready = true) => { await link.click(); await dlg.waitFor(); if (ready) await pg.locator('#cf-answer:not([disabled])').waitFor({ timeout: 4000 }).catch(() => errs.push(`${tag}: no puzzle after opening`)); };
  const close = async () => { await pg.keyboard.press('Escape'); const gone = await dlg.waitFor({ state: 'detached', timeout: 2500 }).then(() => true, () => false); if (!gone) { errs.push(`${tag}: Escape did not close the dialog`); await pg.locator('.cf-x').click(); await dlg.waitFor({ state: 'detached' }); } };
  const fill = async (m, n, r, a) => { await pg.fill('#cf-message', m); await pg.fill('#cf-name', n); await pg.fill('#cf-reply', r); if (a !== undefined) await pg.fill('#cf-answer', a); };
  const alertText = async () => ((await pg.locator('[role=alert]').first().textContent({ timeout: 4000 }).catch(() => null)) || '').trim();
  const MSG = 'Hello authors, a real question about the XOR rule.';

  // the footer: the link is there, the rest of the footer is unchanged
  { const ft = await pg.locator('footer').innerText(); if (await link.count() !== 1 || (await link.textContent()) !== (lang === 'en' ? 'Contact' : 'Contatti')) errs.push(`${tag}: footer link label "${await link.textContent().catch(() => '?')}"`);
    if (await link.getAttribute('type') !== 'button') errs.push(`${tag}: footer link is not type=button`);
    if (!ft.includes(lang === 'en' ? 'Built with Claude' : 'Costruito con Claude') || !ft.includes(lang === 'en' ? 'Lenses' : 'Lenti') || await pg.locator('footer .made-with a').count() !== 1) errs.push(`${tag}: the rest of the footer changed: ${ft}`);
    if (await dlg.count() !== 0) errs.push(`${tag}: the dialog is open before anyone asked`); if (S.gets.length) errs.push(`${tag}: a puzzle was fetched before the dialog was opened`); }

  // open: dialog semantics, puzzle, labels, honeypot
  await open();
  { if (await dlg.count() !== 1) errs.push(`${tag}: no dialog`);
    if (await dlg.getAttribute('aria-modal') !== 'true') errs.push(`${tag}: aria-modal`);
    const labelId = await dlg.getAttribute('aria-labelledby'), title = await pg.locator('#' + labelId).textContent(); if (title !== t.title) errs.push(`${tag}: the dialog is labelled "${title}", expected "${t.title}"`);
    if (!(await dlg.innerText()).includes(t.intro)) errs.push(`${tag}: intro sentence missing`);
    if (S.gets.length !== 1 || !S.gets[0].endsWith('/api/contact?lang=' + lang + '&aud=yl')) errs.push(`${tag}: one GET with ?lang=${lang}&aud=yl expected (Young Learner), got ${S.gets}`);
    const q = await pg.locator('label[for=cf-answer]').textContent(); if (q !== QUESTION(lang, PAIRS[0])) errs.push(`${tag}: the question shown is "${q}"`);
    if (await pg.locator('#cf-answer').getAttribute('inputmode') !== 'numeric') errs.push(`${tag}: answer input is not inputmode=numeric`);
    if (!(await pg.locator('#cf-hint').textContent()).includes(t.hintPlain)) errs.push(`${tag}: plain hint missing (Young Learner)`);
    { const txt = await dlg.innerText(); if (TECH.test(txt)) errs.push(`${tag}: technical words in the Young Learner's dialog: ${txt.match(TECH)[0]}`); }
    for (const [id, text] of [['cf-message', t.fields.message], ['cf-name', t.fields.name], ['cf-reply', t.fields.reply], ['cf-answer', QUESTION(lang, PAIRS[0])]]) { const l = await pg.locator(`label[for=${id}]`).textContent().catch(() => null); if (l !== text) errs.push(`${tag}: label of #${id} is "${l}"`); if (!(await pg.getByLabel(text, { exact: true }).count())) errs.push(`${tag}: no control found by the label "${text}"`); }
    const hp = await pg.evaluate(() => { const i = document.querySelector('[name=website]'), r = i.getBoundingClientRect(), c = (i.closest('.cf-hp') || i).getBoundingClientRect(); return { name: i.name, tab: i.tabIndex, ac: i.autocomplete, hidden: !!i.closest('[aria-hidden=true]'), w: Math.max(r.width, c.width), h: Math.max(r.height, c.height), type: i.type }; });
    if (hp.tab !== -1 || hp.ac !== 'off' || !hp.hidden || hp.w > 2 || hp.h > 2 || hp.type !== 'text') errs.push(`${tag}: honeypot is not hidden from sight, tabbing and screen readers: ${JSON.stringify(hp)}`);
    if (!/^cf-message\|in$/.test(await active())) errs.push(`${tag}: focus did not move into the dialog onto the message field: ${await active()}`);
    if (await pg.locator('[role=alert]').count() !== 0) errs.push(`${tag}: an alert is shown before anything went wrong`);
    if (await pg.locator('[aria-live=polite]').count() < 1) errs.push(`${tag}: no polite live region`);
    if (await pg.evaluate(() => document.body.style.overflow) !== 'hidden') errs.push(`${tag}: the page behind can still scroll`); }

  // keyboard: Tab and Shift+Tab never leave the dialog and never reach the honeypot; visible focus rings
  { const seen = new Set(); let leaked = null;
    for (const key of ['Tab', 'Shift+Tab']) for (let i = 0; i < 16; i++) { await pg.keyboard.press(key); const a = await active(); seen.add(a); if (!a.endsWith('|in') || a.startsWith('website') || a.startsWith('DIV')) leaked = leaked || `${key} #${i}: ${a}`; }
    if (leaked) errs.push(`${tag}: focus escaped or hit a hidden field: ${leaked}`);
    for (const need of ['cf-message|in', 'cf-name|in', 'cf-reply|in', 'cf-answer|in']) if (!seen.has(need)) errs.push(`${tag}: Tab never reached ${need}: ${[...seen]}`);
    await pg.locator('#cf-message').focus(); await pg.keyboard.press('Tab'); const ring = await pg.evaluate(() => { const s = getComputedStyle(document.activeElement); return s.outlineStyle + ' ' + s.outlineWidth; }); if (!/solid 2px/.test(ring)) errs.push(`${tag}: no visible focus ring on a field reached by keyboard: ${ring}`);
    await pg.locator('.cf-send').focus(); await pg.keyboard.press('Shift+Tab'); await pg.keyboard.press('Tab'); const ring2 = await pg.evaluate(() => { const s = getComputedStyle(document.activeElement); return document.activeElement.className + ' ' + s.outlineStyle + ' ' + s.outlineWidth; }); if (!/cf-send solid 2px/.test(ring2)) errs.push(`${tag}: no visible focus ring on the Send button: ${ring2}`); }

  // Escape closes, and the focus goes back to the footer link
  await close(); { const a = await pg.evaluate(() => document.activeElement?.getAttribute('data-contact-open') !== null && document.activeElement.tagName === 'BUTTON'); if (!a) errs.push(`${tag}: after Escape the focus is on ${await active()}, not on the footer link`); if (await pg.evaluate(() => document.body.style.overflow) === 'hidden') errs.push(`${tag}: the page stays locked after closing`); }

  // client-side checks: nothing is sent
  S.posts.length = 0; await open(); await fill('short', '', '', '12');
  { await pg.locator('.cf-send').click(); const a = await alertText(); if (a !== fmt(t.errors.invalid_message, { min: LIM.min, max: LIM.max })) errs.push(`${tag}: short message: "${a}"`); if (!/^cf-message\|in$/.test(await active())) errs.push(`${tag}: focus after a short message: ${await active()}`);
    await fill(MSG, '', 'nope', '12'); await pg.locator('.cf-send').click(); const a2 = await alertText(); if (a2 !== t.errors.invalid_reply) errs.push(`${tag}: bad address: "${a2}"`);
    await fill(MSG, '', '', 'abc'); await pg.locator('.cf-send').click(); const a3 = await alertText(); if (a3 !== t.errors.answer_digits) errs.push(`${tag}: non-numeric answer: "${a3}"`);
    if (S.posts.length) errs.push(`${tag}: ${S.posts.length} POST(s) were sent although the form was not valid`);
    await pg.fill('#cf-message', 'hello'); if ((await pg.locator('#cf-message-count').textContent()) !== fmt(t.fields.counter, { n: 5, max: LIM.max })) errs.push(`${tag}: counter shows "${await pg.locator('#cf-message-count').textContent()}"`);
    // re-test T1-9: emoji count once, as on the route: typing 1500 of them (3000 UTF-16 units) is not cut at 2000 units by the box
    if (w === 1100) { await pg.locator('#cf-message').fill(''); await pg.locator('#cf-message').focus(); await pg.keyboard.insertText('😀'.repeat(1500)); const v = await pg.inputValue('#cf-message'); if ([...v].length !== 1500) errs.push(`${tag}: the message box cut 1500 emoji to ${[...v].length}`); if ((await pg.locator('#cf-message-count').textContent()) !== fmt(t.fields.counter, { n: 1500, max: LIM.max })) errs.push(`${tag}: the counter of 1500 emoji shows "${await pg.locator('#cf-message-count').textContent()}"`); } }

  // a draft survives closing the dialog by accident; the last question, answer and thanks do not come back (every DOM change is recorded while it opens again)
  await fill(MSG, 'Ada', 'ada@example.com', '3'); const prevQ = await pg.locator('label[for=cf-answer]').textContent(); await close();
  await pg.evaluate(() => { window.__seen = []; window.__mo = new MutationObserver(() => { const l = document.querySelector('label[for=cf-answer]'), a = document.getElementById('cf-answer'); window.__seen.push({ label: l ? l.textContent : null, value: a ? a.value : null, thanks: !!document.querySelector('.cf-thanks'), alert: !!document.querySelector('[role=alert]') }); }); window.__mo.observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true }); });
  S.getDelay = 400; await link.click(); await dlg.waitFor(); await pg.waitForTimeout(150);
  { const seen = await pg.evaluate(() => { window.__mo.disconnect(); return window.__seen; }), stale = seen.filter(x => (x.label !== null && x.label === prevQ) || x.value === '3' || x.thanks || x.alert);
    if (stale.length) errs.push(`${tag}: when the dialog opens again, something of the last visit shows: ${JSON.stringify(stale[0])}`);
    if (!seen.some(x => x.label === t.puzzleLoading)) errs.push(`${tag}: no "${t.puzzleLoading}" while the new question loads`); }
  S.getDelay = 0; await pg.locator('#cf-answer:not([disabled])').waitFor({ timeout: 4000 }).catch(() => errs.push(`${tag}: no puzzle after reopening`));
  if (await pg.inputValue('#cf-message') !== MSG || await pg.inputValue('#cf-name') !== 'Ada' || await pg.inputValue('#cf-reply') !== 'ada@example.com') errs.push(`${tag}: the draft was lost by closing the dialog`);
  if (S.gets.length < 3) errs.push(`${tag}: reopening did not fetch a fresh puzzle (${S.gets.length} GETs)`);

  // a wrong answer: the sentence, a new puzzle, the answer cleared and focused, the message kept
  { const before = S.gets.length; await pg.fill('#cf-answer', '7'); await pg.locator('.cf-send').click(); const a = await alertText();
    if (a !== t.errors.wrong_answer) errs.push(`${tag}: wrong answer: "${a}"`);
    await pg.locator('#cf-answer:not([disabled])').waitFor({ timeout: 4000 }).catch(() => errs.push(`${tag}: no new puzzle after a wrong answer`));
    if (S.gets.length !== before + 1) errs.push(`${tag}: wrong answer did not load a new puzzle (${S.gets.length - before} GETs)`);
    if (await pg.locator('label[for=cf-answer]').textContent() !== QUESTION(lang, PAIRS[(S.gets.length - 1) % PAIRS.length])) errs.push(`${tag}: the new question is not shown`);
    if (await pg.inputValue('#cf-answer') !== '' || await pg.inputValue('#cf-message') !== MSG) errs.push(`${tag}: after a wrong answer the answer is not cleared or the message was lost`);
    if (!/^cf-answer\|in$/.test(await active())) errs.push(`${tag}: after a wrong answer the focus is on ${await active()}`);
    if (S.posts.length !== 1 || S.posts[0].answer !== '7') errs.push(`${tag}: first POST ${JSON.stringify(S.posts[0])}`); }

  // the right answer: what is sent, and the thanks
  S.posts.length = 0;
  { const ans = ANSWER(PAIRS[(S.gets.length - 1) % PAIRS.length]); await pg.fill('#cf-answer', ' ' + ans + ' '); await pg.locator('.cf-send').click();
    let thanked = true; await pg.locator('.cf-thanks').waitFor({ timeout: 4000 }).catch(() => { thanked = false; }); if (!thanked) errs.push(`${tag}: no thanks after a right answer; alert: "${await alertText()}"`);
    const sent = S.posts[0]; if (!sent || JSON.stringify(Object.keys(sent).sort()) !== JSON.stringify(['answer', 'lang', 'message', 'name', 'reply', 'token', 'website'])) errs.push(`${tag}: the POST body has the fields ${sent && Object.keys(sent)}`);
    else if (sent.token !== 'tok-' + S.gets.length || sent.answer !== ans || sent.message !== MSG || sent.name !== 'Ada' || sent.reply !== 'ada@example.com' || sent.website !== '' || sent.lang !== lang) errs.push(`${tag}: the POST body is ${JSON.stringify(sent)}`);
    if ((await pg.locator('.cf-thanks h3').textContent()) !== t.thanksTitle || !(await pg.locator('.cf-thanks').innerText()).includes(t.thanks)) errs.push(`${tag}: the thanks text`);
    if (!(await pg.evaluate(() => document.activeElement?.id === 'cf-thanks'))) errs.push(`${tag}: focus did not move to the thanks heading: ${await active()}`);
    if (await pg.locator('[role=alert]').count() !== 0) errs.push(`${tag}: an alert is still shown after success`);
    await pg.locator('.cf-thanks .cf-send').click(); await dlg.waitFor({ state: 'detached' }); if (!(await pg.evaluate(() => document.activeElement?.hasAttribute('data-contact-open')))) errs.push(`${tag}: after the thanks the focus is on ${await active()}`);
    await open(); if (await pg.inputValue('#cf-message') !== '' || await pg.inputValue('#cf-name') !== '' || await pg.inputValue('#cf-answer') !== '') errs.push(`${tag}: the form was not emptied after a successful send`); await close(); }
  if (reqs.length) errs.push(`${tag}: requests to other sites: ${reqs}`);
  if (await pg.evaluate(() => document.scripts.length) !== 1 || await pg.evaluate(() => document.cookie) !== '') errs.push(`${tag}: extra scripts or a cookie`);
  { const keys = await pg.evaluate(() => Object.keys(localStorage).concat(Object.keys(sessionStorage))); if (keys.some(k => k !== 'atlas.lang')) errs.push(`${tag}: the form stored something: ${keys}`); }

  // every other answer of the route, one sentence each
  if (w === 1100 || lang === 'it') {
    const CASES = [['too_fast', 400, t.errors.too_fast, 0], ['expired', 400, t.errors.expired, 1], ['bad_token', 400, t.errors.bad_token, 1], ['replayed', 400, t.errors.replayed, 1], ['rate', 429, fmt(t.errors.rate_limited_in, { m: 3 }), 0], ['not_configured', 503, t.errors.not_configured, 0], ['delivery_failed', 502, t.errors.delivery_failed, 1], ['rejected', 400, t.errors.rejected, 1], ['invalid_message', 400, fmt(t.errors.invalid_message, { min: LIM.min, max: LIM.max }), 0], ['invalid_name', 400, fmt(t.errors.invalid_name, { nameMax: LIM.name }), 0], ['invalid_reply', 400, t.errors.invalid_reply, 0], ['unknown', 400, t.errors.generic, 0], ['forbidden', 403, t.errors.generic, 0], ['abort', 0, t.errors.network, 0]];
    for (const [mode, status, sentence, newPuzzle] of CASES) {
      S.post = mode; S.status = status; await open(); await fill(MSG, '', '', ANSWER(PAIRS[(S.gets.length - 1) % PAIRS.length])); const before = S.gets.length;
      await pg.locator('.cf-send').click(); const a = await alertText(); if (a !== sentence) errs.push(`${tag}: ${mode}: the alert reads "${a}", expected "${sentence}"`);
      await pg.waitForTimeout(150); if (S.gets.length - before !== newPuzzle) errs.push(`${tag}: ${mode}: ${S.gets.length - before} new puzzle(s) fetched, expected ${newPuzzle}`);
      if (newPuzzle) await pg.locator('#cf-answer:not([disabled])').waitFor({ timeout: 4000 }).catch(() => errs.push(`${tag}: ${mode}: no new puzzle`));
      if (newPuzzle && await pg.inputValue('#cf-answer') !== '') errs.push(`${tag}: ${mode}: the spent answer was not cleared`); if (!newPuzzle && await pg.inputValue('#cf-answer') === '') errs.push(`${tag}: ${mode}: the answer was cleared although the puzzle is still good`);
      if (await pg.inputValue('#cf-message') !== MSG) errs.push(`${tag}: ${mode}: the message was lost`);
      await close(); }
    S.post = 'ok';
  }

  // sending: the button says so, a second click does nothing, Escape does not close the dialog until the answer has come
  if (w === 1100) {
    S.post = 'ok'; S.delay = 700; await open(); await fill(MSG, '', '', ANSWER(PAIRS[(S.gets.length - 1) % PAIRS.length])); S.posts.length = 0;
    await pg.locator('.cf-send').click(); await pg.waitForTimeout(100);
    const during = await pg.evaluate(() => ({ label: document.querySelector('.cf-send').textContent, disabled: document.querySelector('.cf-send').getAttribute('aria-disabled'), busy: document.querySelector('form').getAttribute('aria-busy'), focus: document.activeElement.className }));
    if (during.label !== t.sending || during.disabled !== 'true' || during.busy !== 'true') errs.push(`${tag}: while sending: ${JSON.stringify(during)}`);
    await pg.locator('.cf-send').click({ force: true }); await pg.keyboard.press('Escape'); await pg.waitForTimeout(100); if (await dlg.count() !== 1) errs.push(`${tag}: Escape closed the dialog while the message was being sent`);
    await pg.locator('.cf-thanks').waitFor({ timeout: 4000 }); if (S.posts.length !== 1) errs.push(`${tag}: ${S.posts.length} POSTs for one click (and one click while sending)`); S.delay = 0; await pg.keyboard.press('Escape'); await dlg.waitFor({ state: 'detached' });
  }

  // the puzzle route is down or not configured
  { S.get = '503'; await open(false); const a = await alertText(); if (a !== t.errors.not_configured) errs.push(`${tag}: GET 503 shows "${a}"`); if (await pg.locator('.cf-send').getAttribute('aria-disabled') !== 'true') errs.push(`${tag}: Send is not marked unavailable without a puzzle`); if (await pg.getByRole('button', { name: t.retry }).count()) errs.push(`${tag}: a retry button is offered for a form that is not set up`); await close();
    for (const mode of ['abort', 'junk']) { S.get = mode; await open(false); const a2 = await alertText(); if (a2 !== t.errors.puzzle_failed) errs.push(`${tag}: GET ${mode} shows "${a2}"`);
      S.get = 'ok'; await pg.getByRole('button', { name: t.retry }).click(); await pg.waitForFunction(() => document.getElementById('cf-answer') && !document.getElementById('cf-answer').disabled, null, { timeout: 4000 }).catch(() => errs.push(`${tag}: retry did not bring a question`)); if (await pg.locator('[role=alert]').count() !== 0) errs.push(`${tag}: the error stays after a good retry`); await close(); } }
  { // asking for another question
    await open(); const g = S.gets.length; await pg.getByRole('button', { name: t.newQuestion }).click(); await pg.waitForTimeout(250); if (S.gets.length !== g + 1) errs.push(`${tag}: "${t.newQuestion}" did not fetch a question`); await close(); }
  if (reqs.length) errs.push(`${tag}: requests to other sites: ${reqs}`);
  } catch (e) { errs.push(`${tag}: stopped by an exception: ${String(e.message).split('\n')[0]}`); } finally { await pg.close().catch(() => {}); }
}

// 320 px: nothing sticks out, with the longest text on screen, and the Send button can be reached on a short screen
for (const lang of ['en', 'it']) for (const [w, h] of [[320, 640], [320, 420]]) {
  const tag = `${lang}${w}x${h}`, t = CONTACT[lang], pg = await b.newPage({ viewport: { width: w, height: h } }), S = {};
  pg.on('pageerror', e => errs.push(`${tag}: page error ${e.message}`)); pg.on('console', m => m.type() === 'error' && !/^Failed to load resource/.test(m.text()) && errs.push(`${tag}: console error ${m.text()}`));
  try {
  await fake(pg, S); await pg.goto(PAGE); await pg.waitForTimeout(300); if (lang === 'it') await setLang(pg, 'it');
  const closedWidth = await pg.evaluate(() => document.documentElement.scrollWidth);
  await pg.locator('footer .contact-link').click(); await pg.locator('[role=dialog]').waitFor(); await pg.waitForTimeout(250);
  S.post = 'rate'; await pg.fill('#cf-message', 'Hello authors, a real question about the XOR rule. '.repeat(30)); await pg.fill('#cf-name', 'W'.repeat(100)); await pg.fill('#cf-reply', 'someone.with.a.long.address@subdomain.example.com'); await pg.fill('#cf-answer', '12');
  await pg.locator('.cf-send').click(); await pg.locator('[role=alert]').waitFor({ timeout: 4000 }).catch(() => errs.push(`${tag}: no alert for the rate-limit answer`));
  const m = await pg.evaluate(() => {
    const d = document.querySelector('[role=dialog]'), o = d.parentElement, r = d.getBoundingClientRect(); const wide = [];
    for (const e of d.querySelectorAll('*')) { const b = e.getBoundingClientRect(); if (b.width && (b.right > r.right + 0.5 || b.left < r.left - 0.5) && !e.closest('.cf-hp')) wide.push(e.tagName + '.' + e.className + ' ' + Math.round(b.left) + '..' + Math.round(b.right)); }
    return { docW: document.documentElement.scrollWidth, innerW: innerWidth, left: r.left, right: r.right, overlayScroll: o.scrollWidth - o.clientWidth, wide, dialogScroll: d.scrollWidth - d.clientWidth };
  });
  if (m.docW > Math.max(closedWidth, m.innerW) + 1) errs.push(`${tag}: opening the dialog widened the page: ${closedWidth} -> ${m.docW}`);
  if (m.left < 0 || m.right > m.innerW + 0.5) errs.push(`${tag}: the dialog (${Math.round(m.left)}..${Math.round(m.right)}) sticks out of a ${m.innerW} px screen`);
  if (m.overlayScroll > 0 || m.dialogScroll > 0) errs.push(`${tag}: horizontal scroll inside the dialog (${m.overlayScroll}, ${m.dialogScroll})`);
  if (m.wide.length) errs.push(`${tag}: ${m.wide.length} element(s) stick out of the dialog: ${m.wide.slice(0, 4)}`);
  await pg.locator('.cf-send').scrollIntoViewIfNeeded(); { const bb = await pg.locator('.cf-send').boundingBox(); if (!bb || bb.y < 0 || bb.y + bb.height > h + 1 || bb.x < 0 || bb.x + bb.width > w + 1) errs.push(`${tag}: the Send button cannot be brought into view: ${JSON.stringify(bb)}`); }
  await pg.keyboard.press('Escape'); await pg.locator('[role=dialog]').waitFor({ state: 'detached', timeout: 3000 }).catch(() => errs.push(`${tag}: Escape did not close the dialog`));
  } catch (e) { errs.push(`${tag}: stopped by an exception: ${String(e.message).split('\n')[0]}`); } finally { await pg.close().catch(() => {}); }
}
// the Physicist (and the Mathematician) get the usual puzzles and hint: no ?aud
for (const lang of ['en', 'it']) { const tag = `${lang}/Physicist`, t = CONTACT[lang], pg = await b.newPage({ viewport: { width: 1100, height: 800 } }), S = {};
  pg.on('pageerror', e => errs.push(`${tag}: page error ${e.message}`));
  try { await fake(pg, S); await pg.goto(PAGE); await pg.waitForTimeout(300); if (lang === 'it') await setLang(pg, 'it'); await pg.locator('[data-profile="Physicist"]').click(); await pg.waitForTimeout(150);
    await pg.locator('footer .contact-link').click(); await pg.locator('#cf-answer:not([disabled])').waitFor({ timeout: 4000 });
    if (S.gets.length !== 1 || !S.gets[0].endsWith('/api/contact?lang=' + lang)) errs.push(`${tag}: one GET with ?lang=${lang} and no aud expected, got ${S.gets}`);
    if ((await pg.locator('label[for=cf-answer]').textContent()) !== QUESTION(lang, PAIRS[0], null)) errs.push(`${tag}: the usual question is not shown`);
    const h = await pg.locator('#cf-hint').textContent(); if (!h.includes(t.hint) || h.includes(t.hintPlain)) errs.push(`${tag}: the usual hint is not shown: ${h}`);
  } catch (e) { errs.push(`${tag}: stopped by an exception: ${String(e.message).split('\n')[0]}`); } finally { await pg.close().catch(() => {}); } }
await b.close(); srv.close(); console.log(errs.length ? errs.join('\n') + '\n' + errs.length + ' FAILURES' : 'ALL CONTACT UI CHECKS PASS'); process.exit(errs.length ? 1 : 0);
