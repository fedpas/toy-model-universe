// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The live pictures of Steps 15-17. Each one is computed in the browser by labelsEngine.js from the bit rule; nothing here is a stored image.
import React, { useEffect, useMemo, useState } from 'react';
import * as E from './labelsEngine.js';
import { COPY } from './labelsCopy.js';
import { Tx, SvgTx } from './MathText.jsx';
import { Formal } from './Formal.jsx';

export const TYPE_COL = { R: '#60a5fa', R2: '#22d3ee', C: '#34d399', H: '#fbbf24', H2: '#fb923c' };
const CLS_COL = { '-1': '#22d3ee', '0': '#34d399', '1': '#f87171' };
const TYPE_TXT = { R: 'R', R2: 'R²', C: 'C', H: 'H', H2: 'H²' };
const fmtN = (n, lang) => n.toLocaleString(lang === 'it' ? 'it' : 'en');
const reduced = () => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };
const Slider = ({ label, min, max, step, value, onChange, fmt }) => <label className="ls-sl"><span><Tx>{label}</Tx></span><input type="range" min={min} max={max} step={step} value={value} onChange={e => onChange(+e.target.value)} /><output>{fmt ? fmt(value) : value}</output></label>;
const Chips = ({ items, value, onPick, fmt = x => x, label }) => <div className="ls-chips" role="group" aria-label={label}>{items.map(i => <button key={String(i)} className={'ls-chip' + (i === value ? ' on' : '')} aria-pressed={i === value} onClick={() => onPick(i)}><Tx>{fmt(i)}</Tx></button>)}</div>;
const Card = ({ title, children, id }) => <section className="ls-card" id={id}><h3><Tx>{title}</Tx></h3>{children}</section>;
const Cap = ({ children }) => <p className="ls-cap"><Tx>{children}</Tx></p>;
const live = lang => <span className="ls-live"><Tx>{COPY[lang].live}</Tx></span>;
const keyAct = f => e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); f(); } };

// ================================================================ 1. the cells and the clock
export function CellLattice({ lang, yl }) {
  const t = COPY[lang].lattice, [sel, setSel] = useState([0, 2]);
  const [p, q] = sel, n = p + q, w = E.wedderburn(p, q), gs = useMemo(() => E.gaussSum(p, q), [p, q]), em = useMemo(() => E.embedCheck(p, q), [p, q]);
  const dx = 34, dy = 27, cw = 29, ch = 22;
  const cells = []; for (let nn = 0; nn <= 8; nn++) for (let qq = 0; qq <= nn; qq++) cells.push([nn - qq, qq]);
  const typeTxt = yl ? t.typesY[w.type] : `M_{${w.k}}(${w.type === 'C' ? 'C' : w.type === 'H' || w.type === 'H2' ? 'H' : 'R'})` + (w.copies > 1 ? ` ⊕ M_{${w.k}}(${w.type === 'H2' ? 'H' : 'R'})` : '');
  const rows = yl ? t.rowsY : t.rows;
  const rotor = p === 0 ? (yl ? (t.rotorY[n] || t.rotorY.any) : (t.rotor[n] || t.rotor.any(n))) : (yl ? t.rotorY.none : t.rotor.none);
  const R = 62, cx = 80, cy = 80, ang = Math.atan2(gs.im, gs.re);
  return <Card title={yl ? t.titleY : t.title} id="ls-lattice"><div className="ls-row">
    <div className="ls-col"><svg className="ls-svg" viewBox="0 0 342 262" role="group" aria-label={yl ? t.titleY : t.title}>
      {cells.map(([pp, qq]) => { const nn = pp + qq, ty = E.typeOf(pp, qq), x = 171 + (qq - nn / 2) * dx - cw / 2, y = 6 + nn * dy, on = pp === p && qq === q;
        return <g key={pp + '-' + qq} role="button" tabIndex={0} aria-pressed={on} aria-label={yl ? t.pmW(pp, qq) : `Cl(${pp},${qq})`} className="ls-cell" onClick={() => setSel([pp, qq])} onKeyDown={keyAct(() => setSel([pp, qq]))}>
          <rect x={x} y={y} width={cw} height={ch} rx="5" fill={TYPE_COL[ty]} fillOpacity={on ? 1 : .55} stroke={on ? 'currentColor' : 'none'} strokeWidth="2.5" />
          {!yl && <text x={x + cw / 2} y={y + 15} textAnchor="middle" fontSize="11" fill="#0b1020" fontWeight="600">{TYPE_TXT[ty]}</text>}<title>{yl ? t.pmW(pp, qq) : `Cl(${pp},${qq}): c = ${E.clockOf(pp, qq)}`}</title></g>; })}
      {Array.from({ length: 9 }, (_, nn) => <text key={nn} x="4" y={6 + nn * dy + 15} fontSize="10" fill="currentColor" opacity=".7">{nn}</text>)}
    </svg><div className="ls-legend">{Object.keys(TYPE_COL).map(k => <span key={k}><i style={{ background: TYPE_COL[k] }} />{yl ? t.typesY[k] : <><Tx>{k === 'R2' ? 'R²' : k === 'H2' ? 'H²' : k}</Tx>: <Tx>{t.types[k]}</Tx></>}</span>)}</div></div>
    <div className="ls-col"><table className="ls-tab"><tbody>
      <tr><th>{rows.cell}</th><td><Tx>{yl ? t.pmDot(p, q) : `Cl(${p},${q})`}</Tx></td></tr>
      <tr><th>{rows.n}</th><td>{n}</td></tr>
      <tr><th><Tx>{rows.clock}</Tx></th><td>{w.c}</td></tr>
      <tr><th>{rows.type}</th><td><Tx>{typeTxt}</Tx></td></tr>
      {!yl && <tr><th>{rows.k}</th><td>{w.k}</td></tr>}
      <tr><th>{rows.dim}</th><td><Tx>{yl ? `${2 ** n}` : t.dimTxt(2 ** n, w.k, w.copies, E.FIELD_DIM[w.type])}</Tx></td></tr>
      <tr><th><Tx>{rows.gauss}</Tx></th><td><Tx>{yl ? '↗' : t.gaussTxt(gs.re, gs.im, gs.norm2, n, gs.c)}</Tx></td></tr>
      <tr><th><Tx>{rows.embed}</Tx></th><td>{em.ok ? <span className="ls-ok">✓ <Tx>{yl ? t.yesW : t.embedOk}</Tx></span> : <span className="ls-bad">✗</span>}</td></tr>
      <tr><th>{rows.rotor}</th><td><Tx>{rotor}</Tx></td></tr></tbody></table>
      <svg className="ls-svg ls-wheel" viewBox="0 0 160 160" role="img" aria-label={yl ? t.wheelY : t.wheel}>
        <circle cx={cx} cy={cy} r={R} fill="none" stroke="currentColor" strokeOpacity=".3" />
        {Array.from({ length: 8 }, (_, c) => { const a = c * Math.PI / 4, ty = E.TYPES[c], x = cx + R * Math.cos(a), y = cy - R * Math.sin(a), lx = cx + (R + 13) * Math.cos(a), ly = cy - (R + 13) * Math.sin(a);
          return <g key={c}><line x1={cx} y1={cy} x2={x} y2={y} stroke="currentColor" strokeOpacity=".25" /><circle cx={x} cy={y} r="8" fill={TYPE_COL[ty]} fillOpacity={c === w.c ? 1 : .5} stroke={c === w.c ? 'currentColor' : 'none'} strokeWidth="2" /><text x={x} y={y + 3.5} textAnchor="middle" fontSize="9" fill="#0b1020" fontWeight="600">{c}</text>
            {!yl && <text x={lx} y={ly + 3} textAnchor="middle" fontSize="8" fill="currentColor" opacity=".8">{TYPE_TXT[ty]}</text>}</g>; })}
        <line x1={cx} y1={cy} x2={cx + (R - 12) * Math.cos(ang)} y2={cy - (R - 12) * Math.sin(ang)} stroke="currentColor" strokeWidth="2.5" markerEnd="url(#ls-arrow)" />
        <defs><marker id="ls-arrow" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="currentColor" /></marker></defs>
      </svg><Cap>{yl ? t.wheelY : t.wheel}</Cap></div></div>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 2. the trinity
let GRID = null; const grid = () => GRID || (GRID = E.gridCounts(6));
export function Trinity({ lang, yl }) {
  const t = COPY[lang].trinity, [k, setK] = useState(1), [g, setG] = useState(E.springX(1)), [ph, setPh] = useState(0), [run, setRun] = useState(!reduced());
  const [a, b, c] = g, s = E.traceless(a, b, c), cls = E.trinityClass(s, 1e-9), M = E.matrixOf(a, b, c);
  useEffect(() => { if (!run) return undefined; const id = setInterval(() => setPh(x => (x + 0.007) % 1), 50); return () => clearInterval(id); }, [run]);
  const setSpring = v => { setK(v); setG(E.springX(v)); };
  const S = 40, O = 120, sc = v => [O + v[0] * S, O - v[1] * S];
  const orbit = v0 => {
    const Mv = [M[0][0] * v0[0] + M[0][1] * v0[1], M[1][0] * v0[0] + M[1][1] * v0[1]], nMv = Math.hypot(Mv[0], Mv[1]); let T0, T1;
    if (cls < 0) { const w = Math.sqrt(-s); T0 = 0; T1 = 2 * Math.PI / w; } else if (cls > 0) { const w = Math.sqrt(s); T0 = -2.6 / w; T1 = 2.6 / w; } else { if (nMv < 1e-9) return null; T0 = -4 / nMv; T1 = 4 / nMv; }
    let d = '', pen = false; for (let i = 0; i <= 140; i++) { const tt = T0 + (T1 - T0) * i / 140, v = E.apply(E.expTX(a, b, c, tt), v0); if (Math.abs(v[0]) > 3.1 || Math.abs(v[1]) > 3.1) { pen = false; continue; } const [x, y] = sc(v); d += (pen ? 'L' : 'M') + x.toFixed(1) + ' ' + y.toFixed(1); pen = true; }
    return d;
  };
  const starts = []; for (const r of [.7, 1.5, 2.3]) for (let i = 0; i < 6; i++) { const an = i * Math.PI / 3 + (r > 1 ? Math.PI / 6 : 0); starts.push([r * Math.cos(an), r * Math.sin(an)]); }
  const mv0 = [1.5, 0]; let tm; if (cls < 0) tm = ph * 2 * Math.PI / Math.sqrt(-s); else if (cls > 0) tm = (ph < .5 ? ph * 2 - .5 : 1.5 - ph * 2) * 2 * 2.6 / Math.sqrt(s) - 0; else tm = (ph < .5 ? ph * 2 - .5 : 1.5 - ph * 2) * 8 / Math.max(1e-9, Math.hypot(M[0][0] * mv0[0], M[1][0] * mv0[0]));
  const mpos = sc(E.apply(E.expTX(a, b, c, tm), mv0)); const rho = Math.hypot(a, b), cx0 = 30, sx = 62, cy0 = 120, sy = 38;
  const gc = useMemo(grid, []);
  return <Card title={yl ? t.titleY : t.title} id="ls-trinity">
    <div className="ls-row"><div className="ls-col">
      <Slider label={yl ? t.kY : t.k} min={-2} max={2} step={0.1} value={k} onChange={setSpring} fmt={v => v.toFixed(1)} />
      <p className="ls-state" style={{ color: CLS_COL[cls] }}><b><Tx>{(yl ? t.namesY : t.names)[cls]}</Tx></b></p>
      <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><p className="ls-mono"><Tx>{t.read(s, cls)}</Tx></p>
        <details className="ls-hand"><summary><Tx>{t.hand}</Tx></summary>
          <Slider label="a" min={-3} max={3} step={0.1} value={a} onChange={v => setG([v, b, c])} fmt={v => v.toFixed(1)} />
          <Slider label="b" min={-3} max={3} step={0.1} value={b} onChange={v => setG([a, v, c])} fmt={v => v.toFixed(1)} />
          <Slider label="c" min={-3} max={3} step={0.1} value={c} onChange={v => setG([a, b, v])} fmt={v => v.toFixed(1)} /></details></Formal>
      <button className="ls-btn" onClick={() => setRun(r => !r)}>{run ? t.pause : t.play}</button>
      <svg className="ls-svg ls-cone" viewBox="0 0 240 240" role="img" aria-label={yl ? t.coneY : t.cone}>
        <polygon points={`${cx0},${cy0} ${cx0 + 3 * sx},${cy0 - 3 * sy} ${cx0},${cy0 - 3 * sy}`} fill={CLS_COL['-1']} fillOpacity=".18" />
        <polygon points={`${cx0},${cy0} ${cx0 + 3 * sx},${cy0 + 3 * sy} ${cx0},${cy0 + 3 * sy}`} fill={CLS_COL['-1']} fillOpacity=".18" />
        <polygon points={`${cx0},${cy0} ${cx0 + 3 * sx},${cy0 - 3 * sy} ${cx0 + 3 * sx},${cy0 + 3 * sy}`} fill={CLS_COL['1']} fillOpacity=".15" />
        <line x1={cx0} y1={cy0} x2={cx0 + 3 * sx} y2={cy0 - 3 * sy} stroke={CLS_COL['0']} strokeWidth="2" /><line x1={cx0} y1={cy0} x2={cx0 + 3 * sx} y2={cy0 + 3 * sy} stroke={CLS_COL['0']} strokeWidth="2" />
        <line x1={cx0} y1="6" x2={cx0} y2="234" stroke="currentColor" strokeOpacity=".4" /><line x1={cx0} y1={cy0} x2="226" y2={cy0} stroke="currentColor" strokeOpacity=".4" />
        {!yl && <><text x="204" y={cy0 - 5} fontSize="11" fill="currentColor">ρ</text><text x={cx0 + 5} y="14" fontSize="11" fill="currentColor">c</text></>}
        <circle cx={cx0 + Math.min(3, rho) * sx} cy={cy0 - Math.max(-3, Math.min(3, c)) * sy} r="6" fill={CLS_COL[cls]} stroke="currentColor" strokeWidth="1.5" /></svg>
      <Cap>{yl ? t.coneY : t.cone}</Cap></div>
    <div className="ls-col"><svg className="ls-svg" viewBox="0 0 240 240" role="img" aria-label={yl ? t.phaseY : t.phase}>
      <rect x="0" y="0" width="240" height="240" fill="none" stroke="currentColor" strokeOpacity=".2" /><line x1="0" y1="120" x2="240" y2="120" stroke="currentColor" strokeOpacity=".3" /><line x1="120" y1="0" x2="120" y2="240" stroke="currentColor" strokeOpacity=".3" />
      {starts.map((v, i) => { const d = orbit(v); return d ? <path key={i} d={d} fill="none" stroke={CLS_COL[cls]} strokeOpacity=".55" strokeWidth="1.3" /> : <circle key={i} cx={sc(v)[0]} cy={sc(v)[1]} r="1.8" fill={CLS_COL[cls]} />; })}
      <circle cx={mpos[0]} cy={mpos[1]} r="5" fill="currentColor" /></svg><Cap>{yl ? t.phaseY : t.phase}</Cap></div></div>
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><Cap>{t.note}</Cap></Formal>
    <Cap>{(yl ? t.countsY : t.counts)(gc, gc)}</Cap>{live(lang)}</Card>;
}

// ================================================================ 3. bivectors at n = 4
let MC = null; const mcAll = () => MC || (MC = E.SIGS4.map(([p, q]) => ({ p, q, ...E.sampleBivectors(p, q, 400) })));
export function BivectorLab({ lang, yl }) {
  const t = COPY[lang].biv, [si, setSi] = useState(2), [co, setCo] = useState([1, 1, 0, 0, 1, 0]);
  const [p, q] = E.SIGS4[si], v = useMemo(() => E.bivector4(p, q, co), [p, q, co]);
  const PRESETS = { rot: [1, 0, 0, 0, 0, 0], two: [1, 0, 0, 0, 0, 1], nul: [1, 0, 0, 0, -1, 0], cplx: [1, 1, 0, 0, 1, 0] };
  const mc = useMemo(mcAll, []), N = 400;
  const R = Math.max(6, Math.abs(v.S), Math.abs(v.W)) * 1.15, X = u => 100 + u / R * 90, Y = u => 100 - u / R * 90;
  const lam = v.lam.map(([re, im]) => im ? `${re.toFixed(2)} ${im > 0 ? '+' : '−'} ${Math.abs(im).toFixed(2)} i` : re.toFixed(2)).join(',  ');
  return <Card title={yl ? t.titleY : t.title} id="ls-biv">
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><div className="ls-row"><div className="ls-col">
      <Chips label={t.sig} items={E.SIGS4.map((_, i) => i)} value={si} onPick={setSi} fmt={i => `Cl(${E.SIGS4[i][0]},${E.SIGS4[i][1]})`} />
      <div className="ls-chips">{Object.keys(PRESETS).map(k => <button key={k} className="ls-chip" onClick={() => setCo(PRESETS[k])}><Tx>{t.presets[k]}</Tx></button>)}</div>
      {E.BIV_NAMES.map((nm, i) => <Slider key={nm} label={`b_{${nm.slice(1)}}`} min={-3} max={3} step={1} value={co[i]} onChange={x => setCo(co.map((y, j) => (j === i ? x : y)))} />)}</div>
      <div className="ls-col"><table className="ls-tab"><tbody>
        <tr><th><Tx>{t.read.S}</Tx></th><td>{v.S}</td></tr><tr><th><Tx>{t.read.W}</Tx></th><td>{v.W}</td></tr><tr><th><Tx>{t.read.I2}</Tx></th><td>{v.I2 > 0 ? '+1' : '−1'}</td></tr>
        <tr><th><Tx>{t.read.D}</Tx></th><td>{v.disc}</td></tr><tr><th><Tx>{t.read.lam}</Tx></th><td>{lam}</td></tr></tbody></table>
        <p className="ls-state" style={{ color: v.label === 'complex' ? '#fbbf24' : 'inherit' }}><b><Tx>{t.verdict[v.label]}</Tx></b></p>
        <svg className="ls-svg ls-sw" viewBox="0 0 200 200" role="img" aria-label="S and W plane">
          {v.I2 > 0 && <><polygon points={`100,100 ${X(R)},${Y(R)} ${X(-R)},${Y(R)}`} fill="#fbbf24" fillOpacity=".22" /><polygon points={`100,100 ${X(R)},${Y(-R)} ${X(-R)},${Y(-R)}`} fill="#fbbf24" fillOpacity=".22" /></>}
          <line x1="5" y1="100" x2="195" y2="100" stroke="currentColor" strokeOpacity=".4" /><line x1="100" y1="5" x2="100" y2="195" stroke="currentColor" strokeOpacity=".4" />
          <text x="186" y="94" fontSize="10" fill="currentColor">S</text><text x="106" y="12" fontSize="10" fill="currentColor">W</text><circle cx={X(v.S)} cy={Y(v.W)} r="5" fill={v.label === 'complex' ? '#fbbf24' : '#60a5fa'} stroke="currentColor" /></svg></div></div></Formal>
    <h4 className="ls-h4"><Tx>{yl ? t.mcTY : t.mcT}</Tx></h4>
    <div className="ls-bars" role="list">{mc.map(m => { const f = m.complex / Math.max(1, m.real + m.complex); return <div key={m.p + '' + m.q} role="listitem" className="ls-barrow"><span className="ls-bl"><Tx>{yl ? COPY[lang].lattice.pmDot(m.p, m.q) : `Cl(${m.p},${m.q})`}</Tx></span>
      <span className="ls-bt"><i style={{ width: (f * 100).toFixed(1) + '%', background: f > 0 ? '#fbbf24' : 'transparent' }} /></span><span className="ls-bv">{(f * 100).toFixed(0)}%</span></div>; })}</div>
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><Cap>{t.mc({ N, skipped: mc[2].skipped, real: mc[2].real, complex: mc[2].complex })}</Cap></Formal>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 4. the horizon
export function Horizon({ lang, yl }) {
  const t = COPY[lang].pg, [rho, setRho] = useState(0.6), [rev, setRev] = useState(false);
  const sg = rev ? -1 : 1, g = E.pgG(rho, 0.5), s = E.pgSquare(g), cls = E.pgClass(g, 1e-9);
  const px = r => 20 + r * 100, py = tt => 300 - tt * 95, h = 0.2, clampX = x => Math.max(2, Math.min(338, x));
  const cone = (r, tt, big) => { const gg = E.pgG(r, 0.5), ray = E.pgRays(gg, sg), cl = E.pgClass(gg, 1e-9), hh = big ? 0.34 : h; const o = [px(r), py(tt)], A = [clampX(px(r + ray.out * hh)), py(tt + hh)], B = [clampX(px(r + ray.inn * hh)), py(tt + hh)];
    return <g key={r + (big ? 'p' : '')}><polygon points={`${o} ${A} ${B}`} fill={CLS_COL[cl]} fillOpacity={big ? .35 : .22} stroke={CLS_COL[cl]} strokeWidth={big ? 2 : 1.2} />{big && <circle cx={o[0]} cy={o[1]} r="4" fill="currentColor" />}</g>; };
  const r0 = 2.2, rain = []; for (let r = r0; r >= 0.03; r -= 0.02) { const tt = (r0 ** 1.5 - r ** 1.5) / 1.5; rain.push([rev ? px(r) : px(r), rev ? py((r ** 1.5 - 0.03 ** 1.5) / 1.5) : py(tt)]); }
  const stops = [0.2, 0.35, 0.5, 0.65, 0.8, 0.95, 1.1, 1.3, 1.6, 2, 2.5, 3];
  return <Card title={yl ? t.titleY : t.title} id="ls-horizon"><div className="ls-row"><div className="ls-col ls-wide">
    <svg className="ls-svg ls-hz" viewBox="0 0 340 320" role="img" aria-label={yl ? t.capY : t.title}>
      <rect x={px(0)} y="6" width={px(1) - px(0)} height="294" fill="#f87171" fillOpacity=".07" /><line x1={px(1)} y1="6" x2={px(1)} y2="300" stroke="#34d399" strokeDasharray="5 4" strokeWidth="1.5" />
      <line x1="20" y1="300" x2="330" y2="300" stroke="currentColor" strokeOpacity=".4" />
      <text x={px(1) + 4} y="18" fontSize="10" fill="#34d399">{yl ? t.horizonY : t.horizon}</text>
      {stops.map(r => cone(r, 0.35, false))}{cone(rho, 1.5, true)}
      <polyline points={rain.map(x => x.join(',')).join(' ')} fill="none" stroke="#60a5fa" strokeWidth="2" /><text x={px(r0) - 6} y="296" fontSize="10" fill="#60a5fa" textAnchor="end">{t.rain}</text></svg></div>
    <div className="ls-col"><Slider label={yl ? t.rY : t.r} min={0.3} max={3} step={0.01} value={rho} onChange={setRho} fmt={v => v.toFixed(2)} />
      <label className="ls-chk"><input type="checkbox" checked={rev} onChange={e => setRev(e.target.checked)} /> <Tx>{yl ? t.revY : t.rev}</Tx></label>
      <p className="ls-state" style={{ color: CLS_COL[cls] }}><b><Tx>{(yl ? t.namesY : t.names)[cls]}</Tx></b></p>
      <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><p className="ls-mono"><Tx>{t.read(g, s)}</Tx></p><Cap>{t.shear}</Cap></Formal></div></div>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 5. curvature
export function Curvature({ lang, yl }) {
  const t = COPY[lang].curv, [n, setN] = useState(4), ns = [2, 3, 4, 5, 6, 7, 8], rows = ns.map(E.curvature), mx = rows[rows.length - 1].riemann, cur = E.curvature(n);
  return <Card title={yl ? t.titleY : t.title} id="ls-curv">
    <Chips label="n" items={ns} value={n} onPick={setN} fmt={x => `n = ${x}`} />
    <svg className="ls-svg ls-cv" viewBox="0 0 420 230" role="img" aria-label={t.title}>
      {rows.map((r, i) => { const y = 8 + i * 30, sc = 230 / mx, wr = Math.max(2, (r.n === 2 ? 1 : r.ricci) * sc), ww = r.weyl * sc, on = r.n === n;
        return <g key={r.n} opacity={on ? 1 : .75}>{on && <rect x="0" y={y - 4} width="420" height="28" fill="currentColor" fillOpacity=".07" />}<text x="6" y={y + 15} fontSize="12" fill="currentColor">{yl ? r.n : `n = ${r.n}`}</text>
          <rect x="50" y={y} width={wr} height="20" fill="#60a5fa" /><rect x={50 + wr} y={y} width={ww} height="20" fill="#fbbf24" /><text x={50 + wr + ww + 6} y={y + 15} fontSize="11" fill="currentColor">{r.n === 2 ? '1' : `${r.riemann}${yl ? '' : ` = ${r.ricci} + ${r.weyl}`}`}</text></g>; })}
      <line x1="40" y1={8 + 2 * 30 - 5} x2="415" y2={8 + 2 * 30 - 5} stroke="#fbbf24" strokeDasharray="4 3" /></svg>
    <div className="ls-legend"><span><i style={{ background: '#60a5fa' }} />{yl ? t.ricciY : t.ricci}</span><span><i style={{ background: '#fbbf24' }} />{yl ? t.weylY : t.weyl}</span><span>{yl ? t.riemY : t.riem}</span></div>
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><p className="ls-mono"><Tx>{cur.n === 2 ? 'n = 2: Riemann 1, Ricci 3 (all fixed by one scalar), Weyl 0' : `n = ${cur.n}: Riemann ${cur.riemann} = Ricci ${cur.ricci} + Weyl ${cur.weyl};  B^{2}: ${cur.scalarOnly ? t.bsqS : t.bsq4}`}</Tx></p>{n === 4 && <p className="ls-mono"><Tx>{t.at4}</Tx></p>}</Formal>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 7. the two rails
export function Rails({ lang, yl }) {
  const t = COPY[lang].rails, [n, setN] = useState(8), ns = [2, 3, 4, 5, 6, 7, 8], e = E.RAILS.E[n], a = E.RAILS.A[n];
  const bits = x => Math.log2(x), sc = 175 / bits(348364800), cx = 210;
  return <Card title={yl ? t.titleY : t.title} id="ls-rails">
    <Chips label="n" items={ns} value={n} onPick={setN} fmt={x => `n = ${x}`} />
    <svg className="ls-svg ls-rl" viewBox="0 0 420 240" role="img" aria-label={t.title}>
      <text x="8" y="12" fontSize="10" fill="currentColor" opacity=".8">{yl ? t.leftY : <SvgTx>{t.left}</SvgTx>}</text><text x="412" y="12" fontSize="10" textAnchor="end" fill="currentColor" opacity=".8">{yl ? t.rightY : <SvgTx>{t.right}</SvgTx>}</text>
      {ns.map((m, i) => { const y = 22 + i * 30, A = E.RAILS.A[m], Eb = E.RAILS.E[m], on = m === n; return <g key={m} opacity={on ? 1 : .8}>
        {on && <rect x="0" y={y - 3} width="420" height="26" fill="currentColor" fillOpacity=".07" />}
        {A && <><rect x={cx - 18 - bits(A[2]) * sc} y={y} width={bits(A[2]) * sc} height="20" fill="none" stroke={TYPE_COL[A[0]]} strokeWidth="1.5" /><rect x={cx - 18 - bits(A[1]) * sc} y={y} width={bits(A[1]) * sc} height="20" fill={TYPE_COL[A[0]]} fillOpacity=".75" />{!yl && <text x={cx - 22} y={y + 14} textAnchor="end" fontSize="10" fill="#0b1020" fontWeight="600">S{m + 1}</text>}</>}
        <text x={cx} y={y + 14} textAnchor="middle" fontSize="12" fill="currentColor">{m}</text>
        {Eb && <><rect x={cx + 18} y={y} width={bits(Eb[3]) * sc} height="20" fill="none" stroke={TYPE_COL[Eb[1]]} strokeWidth="1.5" /><rect x={cx + 18} y={y} width={bits(Eb[3]) * sc} height="20" fill={TYPE_COL[Eb[1]]} fillOpacity=".75" />{!yl && <text x={cx + 22} y={y + 14} fontSize="10" fill="#0b1020" fontWeight="600">{Eb[0]}</text>}</>}</g>; })}</svg>
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}>{e && <p className="ls-mono"><Tx>{t.row.E(n, e, 0)}</Tx></p>}{a && <p className="ls-mono"><Tx>{t.row.A(n, a, a[2] / a[1])}</Tx></p>}{!e && !a && <p>{t.none}</p>}<Cap>{t.pin}</Cap></Formal>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 8. Golay
let GOL = null; const gol = () => GOL || (GOL = E.golay());
export function GolayCard({ lang, yl }) {
  const t = COPY[lang].golay, G = useMemo(gol, []), [pick, setPick] = useState([]), [demo, setDemo] = useState(0);
  const mask = pick.reduce((m, i) => m | (1 << i), 0), through = pick.length ? G.octads.filter(o => (o & mask) === mask) : G.octads, one = pick.length >= 1 && through.length === 1 ? through[0] : 0;
  const toggle = i => setPick(p => (p.includes(i) ? p.filter(x => x !== i) : p.length >= 5 ? [...p.slice(1), i] : [...p, i]));
  const ws = [0, 8, 12, 16, 24], mx = Math.max(...ws.map(w => G.hist[w])), Rr = 98, C = 120;
  const showOctad = () => { const o = G.octads[(demo * 37) % G.octads.length], bits = []; for (let i = 0; i < 24; i++) if (o >> i & 1) bits.push(i); setPick(bits.slice(0, 5)); setDemo(demo + 1); };
  return <Card title={yl ? t.titleY : t.title} id="ls-golay"><div className="ls-row"><div className="ls-col">
    <svg className="ls-svg" viewBox="0 0 250 170" role="img" aria-label={t.weights}>{ws.map((w, i) => { const hgt = G.hist[w] / mx * 110, x = 14 + i * 46; return <g key={w}><rect x={x} y={130 - hgt} width="34" height={Math.max(2, hgt)} fill="#60a5fa" /><text x={x + 17} y="146" textAnchor="middle" fontSize="11" fill="currentColor">{w}</text><text x={x + 17} y={124 - hgt} textAnchor="middle" fontSize="10" fill="currentColor">{G.hist[w]}</text></g>; })}<text x="125" y="164" textAnchor="middle" fontSize="10" fill="currentColor" opacity=".8">{t.weights}</text></svg></div>
    <div className="ls-col"><svg className="ls-svg" viewBox="0 0 240 240" role="group" aria-label={t.title}>
      {Array.from({ length: 24 }, (_, i) => { const a = 2 * Math.PI * i / 24 - Math.PI / 2, x = C + Rr * Math.cos(a), y = C + Rr * Math.sin(a), on = pick.includes(i), inO = one && (one >> i & 1);
        return <g key={i} role="button" tabIndex={0} aria-pressed={on} aria-label={`point ${i}`} className="ls-cell" onClick={() => toggle(i)} onKeyDown={keyAct(() => toggle(i))}><circle cx={x} cy={y} r="9" fill={inO ? '#fbbf24' : on ? '#60a5fa' : 'none'} stroke={on || inO ? 'currentColor' : 'currentColor'} strokeOpacity={on || inO ? 1 : .5} strokeWidth="1.5" /><text x={x} y={y + 3.5} textAnchor="middle" fontSize="9" fill={on || inO ? '#0b1020' : 'currentColor'}>{i}</text></g>; })}
      <text x={C} y={C - 4} textAnchor="middle" fontSize="13" fill="currentColor">{(yl ? t.countY : t.count)(pick.length)}</text><text x={C} y={C + 14} textAnchor="middle" fontSize="12" fill="currentColor">{through.length === 1 ? (yl ? t.uniqueY : t.unique) : (yl ? t.throughY : t.through)(through.length)}</text></svg>
      <button className="ls-btn" onClick={() => setPick([])}>{t.clear}</button><button className="ls-btn" onClick={showOctad}>{t.demo}</button></div></div>
    <Formal profile={yl ? 'Young Learner' : 'Physicist'} lang={lang} plain={null} fold={false}><Cap>{t.link}</Cap></Formal><Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}

// ================================================================ 9. primes
export function Primes({ lang, yl }) {
  const t = COPY[lang].primes, [n, setN] = useState(11), now = useMemo(() => E.newPrimes(n), [n]);
  const mp = useMemo(() => E.MONSTER_PRIMES.slice(1).map(p => [p, E.ordTwo(p)]).sort((x, y) => x[1] - y[1]), []), px = m => 14 + m * 9.4;
  return <Card title={yl ? t.titleY : t.title} id="ls-primes">
    <Slider label={t.n} min={2} max={36} step={1} value={n} onChange={setN} />
    <p className="ls-state"><b><Tx>{t.enters(n)}</Tx></b>: {now.length ? now.map(p => <span key={p} className={'ls-prime' + (E.MONSTER_PRIMES.includes(p) ? ' m' : '')} title={E.MONSTER_PRIMES.includes(p) ? t.monster : ''}>{p}</span>) : <Tx>{t.none}</Tx>}</p>
    <svg className="ls-svg ls-pr" viewBox="0 0 590 110" role="img" aria-label={t.title}>
      <line x1="10" y1="60" x2="580" y2="60" stroke="currentColor" strokeOpacity=".4" />
      {Array.from({ length: 13 }, (_, i) => i * 5).map(m => <g key={m}><line x1={px(m)} y1="56" x2={px(m)} y2="64" stroke="currentColor" strokeOpacity=".5" /><text x={px(m)} y="76" textAnchor="middle" fontSize="9" fill="currentColor" opacity=".7">{m}</text></g>)}
      <line x1={px(n)} y1="14" x2={px(n)} y2="96" stroke="#60a5fa" strokeWidth="1.5" />
      {mp.map(([p, m], i) => <g key={p}><circle cx={px(m)} cy="60" r="4.5" fill="#fbbf24" /><text x={px(m)} y={i % 2 ? 44 : 30} textAnchor="middle" fontSize="10" fill="currentColor">{p}</text><line x1={px(m)} y1={i % 2 ? 47 : 33} x2={px(m)} y2="55" stroke="#fbbf24" strokeOpacity=".5" /></g>)}</svg>
    <Cap>{yl ? t.capY : t.cap}</Cap>{live(lang)}</Card>;
}
