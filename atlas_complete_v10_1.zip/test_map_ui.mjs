// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML } from './paths.mjs';
import { SCRIPTS } from './mapData.js';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import {TREE,flat,RESEARCH,MTHREADS,LENSES} from './mapData.js';
const nodes=flat(), b=await chromium.launch(), errs=[];
for(const lang of ['en','it']) for(const w of [1100,375]) for(const prof of ['Young Learner','Mathematician']){
 const tag=`${lang}${w}${prof[0]}`, pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${tag}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${tag} console: ${m.text()}`));
 await pg.goto(APP_HTML + '#map');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator(`[data-profile="${prof}"]`).click();await pg.waitForTimeout(200);
 const M='.map';
 if(await pg.locator('.story-nav > button').count()!==9)errs.push(`${tag}: nav buttons`);
 if(await pg.locator('.story-nav > button.active').textContent()!==(lang==='en'?'8 · Map':'8 · Mappa'))errs.push(`${tag}: active nav ${await pg.locator('.story-nav > button.active').textContent()}`);
 const eb=await pg.locator('.page-intro .eyebrow').textContent(); if(eb!==(lang==='en'?'PAGE 8 OF 9':'PAGINA 8 DI 9'))errs.push(`${tag}: page eyebrow ${eb}`);
 if(await pg.locator(`${M} .stat`).count()!==4)errs.push(`${tag}: stats`);
 {const st=await pg.locator(`${M} .stat b`).allTextContents(); if(st[0]!=='9'||st[1]!==`${SCRIPTS.stdlib.length} + ${SCRIPTS.numpy.length}`||st[2]!=='604 · 60 · 110')errs.push(`${tag}: stat numbers ${st}`);}
 if(await pg.locator(`${M} .map-since li`).count()!==8)errs.push(`${tag}: since list`);
 // tree
 if(await pg.locator(`${M} details[data-node]`).count()!==nodes.length)errs.push(`${tag}: tree nodes ${await pg.locator(`${M} details[data-node]`).count()}/${nodes.length}`);
 if(await pg.locator(`${M} .map-chip`).count()!==LENSES.length+MTHREADS.length)errs.push(`${tag}: chips`);
 for(const k of ['lens:spinor','lens:flow','th:i','th:spring']){ await pg.locator(`${M} .map-chip[data-f="${k}"]`).click(); const [kind,key]=k.split(':'); const exp=nodes.filter(n=>(kind==='lens'?n.lens:n.th).includes(key)).length; const hit=await pg.locator(`${M} details.hit`).count(); if(hit!==exp)errs.push(`${tag}: filter ${k} ${hit}/${exp}`); const dim=await pg.locator(`${M} details.dim`).count(); if(dim<1)errs.push(`${tag}: nothing fades for ${k}`);
   if(!(await pg.locator(`${M} .map-shown`).textContent()).includes(String(exp)))errs.push(`${tag}: shown count ${k}`);
   await pg.locator(`${M} .map-chip[data-f="${k}"]`).click(); if(await pg.locator(`${M} details.hit`).count()!==0)errs.push(`${tag}: second click clears ${k}`); }
 await pg.locator(`${M} .map-chip[data-f="th:three"]`).click(); await pg.locator(`${M} .map-clear`).click(); if(await pg.locator(`${M} details.dim`).count()!==0)errs.push(`${tag}: clear`);
 // every branch: open everything, check each body, and follow each link
 const openAll=async()=>{await pg.evaluate(()=>document.querySelectorAll('.map details').forEach(d=>{d.open=true;}));await pg.waitForTimeout(60);};
 const back=async()=>{await pg.locator('.story-nav > button').nth(7).click();await pg.waitForTimeout(120);await openAll();};
 await openAll(); let followed=0;
 for(const n of nodes){
  const d=pg.locator(`${M} details[data-node="${n.id}"]`);
  const body=await d.locator('> .map-body').first().innerText(); const scr=lang==='it'&&n.script==='one script per step'?'uno script per ogni passo':n.script; /* v9: the one script entry that is a phrase is shown in Italian */ if(body.length<60||!body.includes(scr.split(',')[0].trim().slice(0,8)))errs.push(`${tag}: body of ${n.id}`);
  const go=d.locator('> .map-body .map-go').first(); const target=await go.getAttribute('data-go'); const [page,anchor]=n.go; if(target!==page+(anchor?'#'+anchor:''))errs.push(`${tag}: go attr ${n.id} ${target}`);
  await go.click(); await pg.waitForTimeout(150);
  const hash=await pg.evaluate(()=>location.hash); if(hash.split('/')[0]!=='#'+page)errs.push(`${tag}: ${n.id} went to ${hash}`);
  if(anchor&&await pg.locator(`#${anchor}`).count()<1)errs.push(`${tag}: ${n.id} anchor #${anchor} not on the page`); else followed++;
  if(page!=='map')await back();
 }
 if(followed!==nodes.length)errs.push(`${tag}: followed ${followed}/${nodes.length}`);
 // researchers, spring, next, credit
 if(await pg.locator(`${M} .map-rtab tbody tr`).count()!==RESEARCH.length)errs.push(`${tag}: research rows`);
 if(await pg.locator(`${M} .map-chart [data-mult]`).count()!==13)errs.push(`${tag}: chart marks`);
 if(await pg.locator(`${M} .map-nextlist li`).count()!==3)errs.push(`${tag}: next list`);
 await pg.locator(`${M} .map-gospring`).click(); await pg.waitForTimeout(150); if(await pg.locator('#eq-spring').count()!==1||!(await pg.evaluate(()=>location.hash)).includes('equations'))errs.push(`${tag}: spring button`);
 await back();
 {const cr=await pg.locator(`${M} .map-credit`).innerText(); if(!/Claude/.test(cr)||!/Anthropic/.test(cr)||!/(can still be wrong|può ancora sbagliare)/.test(cr))errs.push(`${tag}: credit text`);
  if(await pg.locator(`${M} .map-credit svg.cube-mark`).count()!==1)errs.push(`${tag}: credit mark`);}
 // footer credit on every page links to the credit
 for(const pgi of [0,3,5,8]){ await pg.locator('.story-nav > button').nth(pgi).click(); await pg.waitForTimeout(80); const f=await pg.locator('footer .made-with').textContent(); if(!f.includes(lang==='en'?'Built with Claude':'Costruito con Claude'))errs.push(`${tag}: footer on page ${pgi}`); }
 await pg.locator('footer .made-with a').click(); await pg.waitForTimeout(200); if(!(await pg.evaluate(()=>location.hash)).includes('map')||await pg.locator('#map-credit').count()!==1)errs.push(`${tag}: footer link`);
 {const txt=await pg.locator('.map').innerText(); if(/\\[a-zA-Z]{3,}|undefined|NaN|\[object/.test(txt))errs.push(`${tag}: raw markup in text`);
  const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-innerWidth); if(ov>1)errs.push(`${tag}: horizontal overflow ${ov}`);}
 // the intro on the page and the pager
 if(!(await pg.locator('.story-pager').textContent()).includes(lang==='en'?'Ask':'Chiedi'))errs.push(`${tag}: pager`);
 await pg.close();
}
await b.close();
console.log(errs.length?errs.join('\n')+`\n${errs.length} FAILURES`:'ALL MAP UI TESTS PASS');process.exit(errs.length?1:0);
