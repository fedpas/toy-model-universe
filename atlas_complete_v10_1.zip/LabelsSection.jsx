// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { COPY } from './labelsCopy.js';
import { CellLattice, Trinity, BivectorLab, Horizon, Curvature, Rails, GolayCard, Primes } from './LabelsWidgets.jsx';
import { TabBar, TabPanel, useSub, storyFor } from './StoryShell.jsx';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';

// Steps 15-17 on one page with three tabs: the clock and the trinity (labels), gauge gravity, finite groups.
// Every picture is a live widget (LabelsWidgets.jsx) computed from the bit rule by labelsEngine.js; the Young Learner reads plain words and sees the pictures, the formulas are folded away.
const STYLE = `
.ls{max-width:1000px;margin:18px auto;padding:0 16px}.ls .eyebrow{margin:0 0 .3em}.ls .lede{margin:.5em 0}
.ls-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:12px 14px;margin:14px 0}.ls-card h3{margin:.1em 0 .5em;font-size:1.05em}
.ls-row{display:flex;flex-wrap:wrap;gap:14px}.ls-col{flex:1 1 280px;min-width:0}.ls-wide{flex:2 1 340px}
.ls-svg{width:100%;max-width:420px;display:block;margin:6px auto;height:auto}.ls-hz{max-width:520px}.ls-wheel{max-width:200px}.ls-cone{max-width:240px}.ls-sw{max-width:200px}.ls-pr{max-width:100%}
.ls-cell{cursor:pointer;outline:none}.ls-cell:focus-visible rect,.ls-cell:focus-visible circle{stroke:#4aa8ff;stroke-width:3}
.ls-legend{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:.78em;margin:4px 0}.ls-legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px}
.ls-tab{border-collapse:collapse;width:100%;font-size:.84em}.ls-tab th{text-align:left;font-weight:500;opacity:.75;padding:3px 8px 3px 0;vertical-align:top;width:42%}.ls-tab td{padding:3px 0;overflow-wrap:anywhere}
.ls-cap{font-size:.8em;opacity:.8;margin:.4em 0}.ls-mono{font-family:ui-monospace,monospace;font-size:.82em;overflow-wrap:anywhere;margin:.4em 0}.ls-state{margin:.5em 0}
.ls-sl{display:grid;grid-template-columns:minmax(70px,1.2fr) 3fr 4ch;gap:8px;align-items:center;font-size:.85em;margin:4px 0}.ls-sl input{width:100%;min-width:0}
.ls-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.ls-chip{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.ls-chip.on{background:rgba(80,170,255,.22);border-color:#4aa8ff}
.ls-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:5px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em;margin:4px 8px 4px 0}
.ls-chip:focus-visible,.ls-btn:focus-visible,.ls-hand summary:focus-visible,.ls-sl input:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.ls-live{display:inline-block;font-size:.72em;opacity:.65;border:1px dashed rgba(128,128,128,.5);border-radius:6px;padding:0 6px;margin-top:2px}
.ls-ok{color:#34d399}.ls-bad{color:#f87171}.ls-h4{margin:.9em 0 .3em;font-size:.95em}.ls-hand summary{cursor:pointer;font-size:.85em;margin:6px 0}.ls-chk{display:block;font-size:.85em;margin:6px 0}
.ls-barrow{display:grid;grid-template-columns:minmax(80px,130px) 1fr 4ch;gap:8px;align-items:center;font-size:.82em;margin:3px 0}.ls-bt{height:12px;border:1px solid rgba(128,128,128,.4);border-radius:3px;display:block;overflow:hidden}.ls-bt i{display:block;height:100%}
.ls-prime{display:inline-block;margin:0 4px;padding:0 7px;border:1px solid rgba(128,128,128,.5);border-radius:999px}.ls-prime.m{border-color:#fbbf24;color:#fbbf24}
.ls-glance{max-width:1000px;margin:10px auto 0;padding:8px 16px;border-left:3px solid rgba(80,170,255,.55);font-size:.85em}.ls-glance p{margin:.2em 0}.ls-glance .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}
.ls-glance .tag{white-space:normal;display:inline-block;max-width:100%;overflow-wrap:anywhere}
`;

export default function LabelsSection({ lang, profile, go }) {
  const L = lang === 'it' ? 'it' : 'en', yl = profile === 'Young Learner', [sub, setSub] = useSub('labels'), s = storyFor(L, profile), c = COPY[L].tabs[sub];
  const W = { lang: L, yl };
  return <><style>{STYLE}</style><TabBar lang={L} page="labels" active={sub} onPick={setSub} profile={profile} />
    <TabPanel lang={L} page="labels" id={sub} onPick={setSub} goMap={go} profile={profile}>
      {!yl && <aside className="ls-glance" aria-label={s.glance}><p><span className="gl-k"><Tx>{s.glance.toUpperCase()}</Tx></span>{c.glance.tags.map(([k, txt]) => <span key={txt} className={'tag ' + k} title={s.tagHelp[k]}><Tx>{s.tags[k]}</Tx> · <Tx>{txt}</Tx></span>)}</p>
        <p><span className="gl-k"><Tx>{s.checkedBy.toUpperCase()}</Tx></span><code>{c.glance.script}</code></p><p><Tx>{c.glance.est}</Tx></p></aside>}
      <section className="ls"><p className="eyebrow"><Tx>{stepEyebrow(L, 'labels', sub)}</Tx></p>
        {(yl ? c.ledeY : profile === 'Mathematician' ? [...c.ledeM, ...c.lede.slice(1)] : c.lede).map((p, i) => <p key={i} className="lede"><Tx>{p}</Tx></p>)}
        {sub === 'clock' && <><CellLattice {...W} /><Trinity {...W} /><BivectorLab {...W} /></>}
        {sub === 'gauge' && <><Horizon {...W} /><Curvature {...W} /></>}
        {sub === 'groups' && <><Rails {...W} /><GolayCard {...W} /><Primes {...W} /></>}
        <p className="ls-cap"><Tx>{COPY[L].checkedNote}</Tx></p></section></TabPanel></>;
}
