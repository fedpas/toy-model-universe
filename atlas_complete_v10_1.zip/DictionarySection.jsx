// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useMemo, useRef, useState } from 'react';
import DICT from './dictionaryData';
import { SELFCHECK_PY } from './selfcheckSource';
import { cliffordCell } from './genesis_audit_v3';
import { BLOCK_COLORS } from './findingsData';
import { Intro } from './Fold.jsx';
import { Tx, SvgTx } from './MathText.jsx';
import { Formal, isLearner } from './Formal.jsx';
import { stepAudience } from './steps.js';
import { picYL } from './audienceCopy.js';
const YLPIC = () => stepAudience() === 'Young Learner';   // T4-11: plain picture labels for the Young Learner (audienceCopy.js PIC_YL)

/* ---------- constants ---------- */
const CH = { 0: '#8b93a8', 1: '#4cc9f0', 2: '#ffd166', 3: '#ff5d8f', 8: '#4fd18b', 9: '#a78bfa', 10: '#ffa06f', 11: '#61dff0' };
const FANO_POS = { 3: [60, 250], 8: [300, 250], 9: [180, 50], 2: [180, 183], 11: [180, 250], 1: [240, 150], 10: [120, 150] };
const FANO_LINES = DICT.channels.fano_lines;
const VERTS = ['o', 'O1', 'O2', 'O3', 'H1', 'H2', 'c', 'r'];
const VBLOCK = { o: 0, O1: 1, O2: 1, O3: 1, H1: 2, H2: 2, c: 3, r: 4 };
const isPrime = n => { if (n < 2) return false; for (let d = 2; d * d <= n; d++) if (n % d === 0) return false; return true; };
const fstr = n => { if (n < 2) return String(n); const f = []; let m = n; for (let d = 2; d * d <= m; d++) { let e = 0; while (m % d === 0) { m /= d; e++; } if (e) f.push(e > 1 ? `${d}^${e}` : `${d}`); } if (m > 1) f.push(`${m}`); return f.join('·'); };
const fracStr = s => s.replace('-', '−');
const vpos = (i, R, cx, cy, off = -Math.PI / 2) => [cx + R * Math.cos(off + i * 2 * Math.PI / 8), cy + R * Math.sin(off + i * 2 * Math.PI / 8)];

/* ---------- text ---------- */
const UI = {
  en: {
    eyebrow: 'DICTIONARY', title: 'One generation, six notations',
    lede: 'Every Standard Model particle and gauge generator of Furey’s model, written in six notations: Furey (audited), Simplex, Clifford, Cube, Prime, and the cross-view that holds them together. We build from 0 up, so the symmetries appear as the structure grows.',
    ladderH: 'Build-up: from 0 to 8, and what repeats after', stage: 'Stage n (bits)',
    views: { alg: 'Real algebra idea', sim: 'Simplex', cub: 'Cube', pri: 'Prime' },
    dictH: 'The dictionary', pick: 'Pick a particle or gauge generator',
    groups: { matter: 'Quarks and leptons (one generation)', gauge: 'Gauge bosons', cartan: 'Diagonal generators', replica: 'Replica edges (open)' },
    cols: { furey: 'Furey (audited)', sim: 'Simplex', cli: 'Clifford', cub: 'Cube', pri: 'Prime', crs: 'Cross-view' },
    fanoH: 'The seven channels are a Fano plane', cartH: 'The diagonal generators on the faces', dlH: 'Check it yourself',
    dlText: 'The script rebuilds the 16-dimensional model from octonions, recomputes every row of this dictionary and the ladder, and asserts them. Run it with python3 and numpy.',
    dlPy: 'Download self-check (Python)', dlJson: 'Download dictionary data (JSON)', dlCmd: 'python3 dictionary_selfcheck.py --compare dictionary.json',
    antiNote: 'Antiparticles are the reversed edges. They touch the same faces, so the face map alone cannot tell a particle from its antiparticle.',
    open: 'Open: Higgs and the replica edges are not placed by this model; one generation only.',
    why8H: 'Why no new type appears after 8', rec: 'Real:', imag: 'ω-partner:'
  },
  it: {
    eyebrow: 'DIZIONARIO', title: 'Una generazione, sei notazioni',
    lede: 'Ogni particella del Modello Standard e ogni generatore di gauge del modello di Furey, scritti in sei notazioni: Furey (verificato), Simplesso, Clifford, Cubo, Primi e la vista incrociata che li tiene insieme. Costruiamo da 0 in su, così le simmetrie compaiono man mano che la struttura cresce.',
    ladderH: 'Costruzione: da 0 a 8, e che cosa si ripete dopo', stage: 'Stadio n (bit)',
    views: { alg: 'Idea di algebra reale', sim: 'Simplesso', cub: 'Cubo', pri: 'Primi' },
    dictH: 'Il dizionario', pick: 'Scegli una particella o un generatore di gauge',
    groups: { matter: 'Quark e leptoni (una generazione)', gauge: 'Bosoni di gauge', cartan: 'Generatori diagonali', replica: 'Lati di replica (aperto)' },
    cols: { furey: 'Furey (verificato)', sim: 'Simplesso', cli: 'Clifford', cub: 'Cubo', pri: 'Primi', crs: 'Vista incrociata' },
    fanoH: 'I sette canali sono un piano di Fano', cartH: 'I generatori diagonali sulle facce', dlH: 'Verificalo tu',
    dlText: 'Lo script ricostruisce il modello a 16 dimensioni dagli ottonioni, ricalcola ogni riga di questo dizionario e la scala, e le verifica. Si esegue con python3 e numpy.',
    dlPy: 'Scarica l’auto-verifica (Python)', dlJson: 'Scarica i dati del dizionario (JSON)', dlCmd: 'python3 dictionary_selfcheck.py --compare dictionary.json',
    antiNote: 'Le antiparticelle sono i lati invertiti. Toccano le stesse facce, quindi la sola mappa sulle facce non distingue una particella dalla sua antiparticella.',
    open: 'Aperto: il modello non colloca il bosone di Higgs né i lati di replica; solo una generazione.',
    why8H: 'Perché dopo 8 non compare nessun tipo nuovo', rec: 'Reale:', imag: 'partner ω:'
  }
};
// stage 8 for the Young Learner: the size of the grid and of the code are read from the data (cliffordCell, dictionaryData), not typed (V4-5)
const G8 = cliffordCell(0, 8).N, CODE_N = DICT.code.faces.length;
const STAGE = {
  en: [
    ['A single tile. Nothing to switch yet.', 'ℝ: one element, one face (the empty, scalar face), one cube vertex, the integer 1, nothing to factor.'],
    ['One ghost switch: it has no sign and no partner.', 'A null seed n²=0: Cl(0,0,1). One simplex vertex, a cube edge, labels 0 and 1, grade counts 1,1.'],
    ['Two ghost switches hold hands and wake a plus and a minus lamp.', 'Polarization {n₁,n₂}=1 gives Cl(1,1)=M₂(ℝ): the first real matrix algebra. Simplex: an edge. Cube: a square.'],
    ['Three switches: the seven lit corners of a little cube meet in triples.', 'Cl(0,3)=ℍ⊕ℍ. The 7 nonzero vertices of the 3-cube are the points of the Fano plane. First odd prime in the grade counts: 3.'],
    ['Four switches: numbers with four parts show up inside grids.', 'Cl(2,2)=M₄(ℝ) and Cl(0,4)=M₂(ℍ). Grade counts 1,4,6,4,1.'],
    ['Five switches: a new counting number, 5, appears.', 'Cl(0,5)=M₄(ℂ). Grade count 10=2·5.'],
    ['Six switches: a hidden turning key appears, a quarter-turn: turn it twice and every sign flips. It comes back below and in the next tabs as the special key.', 'Cl(0,6)=M₈(ℝ)=End_ℝ(𝕆): the first real matrix algebra from the negative edge, with volume element ω²=−1, a complex structure (Furey’s ω=L_{e₇}).'],
    ['Seven switches: the grid splits into two matching halves.', 'Cl(0,7)=M₈(ℝ)⊕M₈(ℝ): central volume element, I²=+1. 7 divides every grade count C(7,k), 0<k<7.'],
    [`Eight switches: the grid is a plain ${G8} by ${G8} grid of numbers, and ${CODE_N} corners of the cube form a famous error-correcting code. After this no new kind of grid appears.`, 'Cl(0,8)=M₁₆(ℝ): the first real matrix algebra whose volume element squares to +1. The 16 diagonal blades form the extended Hamming code. 8=7+1: 7 divides C(8,k) for k=2…6, 3 divides none.']
  ],
  it: [
    ['Una sola piastrella. Ancora niente da accendere.', 'ℝ: un elemento, una faccia (quella vuota, scalare), un vertice del cubo, l’intero 1, nulla da fattorizzare.'],
    ['Un interruttore fantasma: nessun segno e nessun compagno.', 'Un seme nullo n²=0: Cl(0,0,1). Un vertice del simplesso, uno spigolo del cubo, etichette 0 e 1, conteggi di grado 1,1.'],
    ['Due fantasmi si danno la mano e accendono una lampada più e una meno.', 'La polarizzazione {n₁,n₂}=1 dà Cl(1,1)=M₂(ℝ): la prima algebra di matrici reale. Simplesso: uno spigolo. Cubo: un quadrato.'],
    ['Tre interruttori: i sette angoli accesi di un cubetto si incontrano a tre a tre.', 'Cl(0,3)=ℍ⊕ℍ. I 7 vertici non nulli del 3-cubo sono i punti del piano di Fano. Primo primo dispari nei conteggi di grado: 3.'],
    ['Quattro interruttori: numeri a quattro parti compaiono nelle griglie.', 'Cl(2,2)=M₄(ℝ) e Cl(0,4)=M₂(ℍ). Conteggi di grado 1,4,6,4,1.'],
    ['Cinque interruttori: compare un nuovo numero, il 5.', 'Cl(0,5)=M₄(ℂ). Conteggio di grado 10=2·5.'],
    ['Sei interruttori: compare una chiave nascosta, un quarto di giro: girala due volte e ogni segno si capovolge. Torna più sotto e nelle prossime schede come chiave speciale.', 'Cl(0,6)=M₈(ℝ)=End_ℝ(𝕆): la prima algebra di matrici reale dal bordo negativo, con elemento di volume ω²=−1, una struttura complessa (ω=L_{e₇} di Furey).'],
    ['Sette interruttori: la griglia si divide in due metà uguali.', 'Cl(0,7)=M₈(ℝ)⊕M₈(ℝ): elemento di volume centrale, I²=+1. 7 divide ogni conteggio C(7,k), 0<k<7.'],
    [`Otto interruttori: la griglia è una semplice griglia di numeri ${G8} per ${G8}, e ${CODE_N} vertici del cubo formano un famoso codice che corregge gli errori. Dopo questo non compare nessun tipo nuovo di griglia.`, 'Cl(0,8)=M₁₆(ℝ): la prima algebra di matrici reale il cui elemento di volume ha quadrato +1. I 16 blade diagonali formano il codice di Hamming esteso. 8=7+1: 7 divide C(8,k) per k=2…6, 3 non ne divide nessuno.']
  ]
};
// eight more switches: the same kinds of grid, each WIDE times as wide and as tall (read from cliffordCell, not typed; the box has WIDE × WIDE times as many pieces)
const WIDE = cliffordCell(0, 8).N / cliffordCell(0, 0).N;
const TAIL = {
  en: [`More switches bring no new kind: every eight more switches give the same kinds of grid again, each ${WIDE} times as wide and ${WIDE} times as tall.`, 'n = 9…16: Cl(0,n)=Cl(0,n−8)⊗M₁₆(ℝ). Same type, 16 times the matrix size. Nothing new in type.'],
  it: [`Altri interruttori non portano nessun tipo nuovo: ogni otto interruttori in più tornano gli stessi tipi di griglia, ciascuna ${WIDE} volte più larga e ${WIDE} volte più alta.`, 'n = 9…16: Cl(0,n)=Cl(0,n−8)⊗M₁₆(ℝ). Stesso tipo, dimensione di matrice 16 volte maggiore. Nulla di nuovo nel tipo.']
};
const WHY8 = {
  en: ['The type sequence along Cl(0,n) repeats with minimal period 8 (the standard type table, not computed here: the script reads it for n = 0…16 and asserts that no shorter period fits).',
    'n=6 is the first real split algebra, with I²=−1 (a complex structure). n=8 is the first with I²=+1.',
    'Doubly-even self-dual binary codes of length n (the way to build a diagonal torus from grade 0, 4, 8 blades) do not exist for n<8; exhaustive count at n=8: 30. This concerns that kind of torus, not every torus.',
    'Beyond 8 the rule Cl(0,n)=Cl(0,n−8)⊗M₁₆(ℝ) only multiplies the matrix size by 16.'],
  it: ['La sequenza dei tipi lungo Cl(0,n) si ripete con periodo minimo 8 (la tabella standard dei tipi, non calcolata qui: lo script la legge per n = 0…16 e verifica che nessun periodo più corto vada bene).',
    'n=6 è la prima algebra reale scissa, con I²=−1 (struttura complessa). n=8 è la prima con I²=+1.',
    'I codici binari autoduali doppiamente pari di lunghezza n (il modo di costruire un toro diagonale con blade di grado 0, 4, 8) non esistono per n<8; conteggio esaustivo a n=8: 30. Riguarda questo tipo di toro, non ogni toro.',
    'Oltre 8 la regola Cl(0,n)=Cl(0,n−8)⊗M₁₆(ℝ) moltiplica solo per 16 la dimensione della matrice.']
};
const CARTAN_INFO = {
  Y0: { w: { o: -3 / 8, O: 1 / 3 - 3 / 8, H1: 1 / 2 - 3 / 8, H2: 1 / 2 - 3 / 8, c: 1 - 3 / 8, r: -3 / 8 }, en: 'hypercharge: Y=⅓P_{𝕆₂}+½P_ℍ+P_ℂ, minus 3/8', it: 'ipercarica: Y=⅓P_{𝕆₂}+½P_ℍ+P_ℂ, meno 3/8' },
  Q0: { w: { o: -3 / 8, O: 1 / 3 - 3 / 8, H1: -3 / 8, H2: 1 - 3 / 8, c: 1 - 3 / 8, r: -3 / 8 }, en: 'electric charge: Q=⅓P_{𝕆₂}+P_{ℍ₂}+P_ℂ, minus 3/8 (photon direction is an interpretation)', it: 'carica elettrica: Q=⅓P_{𝕆₂}+P_{ℍ₂}+P_ℂ, meno 3/8 (la direzione del fotone è un’interpretazione)' },
  T3: { w: { H1: -1 / 2, H2: 1 / 2 }, en: 'su(2) Cartan: ½(P_{ℍ₂}−P_{ℍ₁})', it: 'Cartan di su(2): ½(P_{ℍ₂}−P_{ℍ₁})' },
  l3: { w: { O1: 1, O2: -1 }, en: 'su(3) Cartan λ₃', it: 'Cartan di su(3) λ₃' },
  l8: { w: { O1: 1, O2: 1, O3: -2 }, en: 'su(3) Cartan λ₈ (unnormalised)', it: 'Cartan di su(3) λ₈ (non normalizzato)' }
};
// the Young Learner reads the dictionary in plain words: 8 boxes, links between them, corners of the cube, numbers; the formal cards are in the fold.
// Every sentence is true of dictionaryData.js (8 + 8 corners per link, 7 + 7 for the two shifted charges, 28 links in 7 groups of 4).
const YL_NAME = {
  en: { uL: 'up quark, left-handed', dL: 'down quark, left-handed', uR: 'up quark, right-handed', dR: 'down quark, right-handed', nuL: 'neutrino, left-handed', eL: 'electron, left-handed', eR: 'electron, right-handed', nuR: 'neutrino, right-handed', colour: c => `, colour ${c}`, gluon: (a, b) => `gluon from ${a} to ${b}`, Wp: 'W plus, from H1 to H2', Wm: 'W minus, from H2 to H1', rep: (a, b) => `spare link from ${a} to ${b}`, Y0: 'hypercharge minus 3/8', Q0: 'electric charge minus 3/8', T3: 'weak charge', l3: 'first colour charge', l8: 'second colour charge' },
  it: { uL: 'quark up, sinistrorso', dL: 'quark down, sinistrorso', uR: 'quark up, destrorso', dR: 'quark down, destrorso', nuL: 'neutrino, sinistrorso', eL: 'elettrone, sinistrorso', eR: 'elettrone, destrorso', nuR: 'neutrino, destrorso', colour: c => `, colore ${c}`, gluon: (a, b) => `gluone da ${a} a ${b}`, Wp: 'W più, da H1 a H2', Wm: 'W meno, da H2 a H1', rep: (a, b) => `legame di scorta da ${a} a ${b}`, Y0: 'ipercarica meno 3/8', Q0: 'carica elettrica meno 3/8', T3: 'carica debole', l3: 'prima carica di colore', l8: 'seconda carica di colore' }
};
const ylName = (e, lang) => { const N = YL_NAME[lang] || YL_NAME.en, m = /^(uL|dL|uR|dR)(\d)$/.exec(e.id);
  if (m) return N[m[1]] + N.colour(m[2]);
  if (N[e.id] && typeof N[e.id] === 'string') return N[e.id];
  if (e.kind === 'gauge') return N.gluon(e.from, e.to);
  if (e.kind === 'replica') return N.rep(e.from, e.to);
  return e.label; };
const YL = {
  en: {
    title: 'One family of particles, six ways of writing it',
    ladderH: 'Building up: from 0 to 8 switches, and what repeats after', stage: 'Switches',
    views: { alg: 'Counting', sim: 'Dots and lines', cub: 'Cube', pri: 'Numbers' },
    gradeCap: 'How many corners have 0, 1, 2, … switches on.',
    simCap: n => n === 0 ? 'No dots yet: there is one way to pick nothing.' : `${n} ${n === 1 ? 'dot' : 'dots, every pair joined'} · ${2 ** n} ways to pick some of them (picking none counts too)`,
    cubCap: n => `${2 ** n} ${n === 0 ? 'corner' : 'corners'} · ${n * 2 ** Math.max(n - 1, 0)} edges · ${DICT.ladder[n].cube.all_faces} ${n === 0 ? 'face (the corner itself)' : 'faces of all sizes, from single corners to the whole cube'}`,
    priCap: (p, top) => `${p} prime numbers among the labels 0 to ${top}`,
    noDots: 'no dots yet',
    boxesIntro: 'The model has 8 boxes, named o, O1, O2, O3, H1, H2, c and r. Each particle is a link from one box to another; a charge puts numbers on the boxes. The model also has a special key, a quarter-turn: turn it twice and every sign flips.',
    pick: 'Pick a particle, a force carrier or a charge',
    groups: { matter: 'Matter particles (one family)', gauge: 'Force carriers', cartan: 'Charges', replica: 'Spare links (open)' },
    kind: { matter: 'matter', gauge: 'force carrier', replica: 'spare', cartan: 'charge' }, group: 'group',
    edge: (name, a, b, ch) => `${name}: the link from box ${a} to box ${b} (group ${ch}).`,
    diag: name => `${name}: not a link. It puts numbers on the boxes (the numbers in the picture); a box without a number gets zero.`,
    lights: k => `On the cube of 8 switches it lights ${k} corners (blue) and their ${k} partners under the special key (pink).`,
    bitsH: 'The corners as switches (1 = on)', numsH: 'The same corners as numbers',
    boxes: 'The 8 boxes: your pick is the bright link', cube8: 'The 256 corners of the cube: blue and pink are your pick', prime8: 'The numbers 0 to 255: gold are prime numbers, blue and pink are your pick',
    anti: 'Each antiparticle is the same link the other way round. It lights the same corners, so the corners alone cannot tell a particle from its antiparticle.',
    open: 'Open: this model does not place the Higgs particle or the spare links, and it holds one family only.',
    cartH: 'Five charges',
    cart: 'Five of the labels are charges: hypercharge, electric charge, the weak charge and two colour charges. Every particle has a value for each of them (it can be zero). Together they use only 7 corners of the cube and their 7 partners under the special key; the fold shows which.',
    fanoH: 'Seven groups of links',
    fano: ['The 8 boxes can be joined in 28 ways. These 28 links fall into 7 groups of 4, and each group uses every box exactly once. Each dot of the picture is one group.', 'Any two dots lie on exactly one line of three dots; the dashed circle counts as a line too. Click a dot to see a particle from that group.']
  },
  it: {
    title: 'Una famiglia di particelle, sei modi di scriverla',
    ladderH: 'Costruzione: da 0 a 8 interruttori, e che cosa si ripete dopo', stage: 'Interruttori',
    views: { alg: 'Conteggi', sim: 'Punti e linee', cub: 'Cubo', pri: 'Numeri' },
    gradeCap: 'Quanti vertici hanno 0, 1, 2, … interruttori accesi.',
    simCap: n => n === 0 ? 'Ancora nessun punto: c’è un solo modo di non scegliere niente.' : `${n} ${n === 1 ? 'punto' : 'punti, ogni coppia unita'} · ${2 ** n} modi di sceglierne alcuni (anche nessuno vale)`,
    cubCap: n => `${2 ** n} ${n === 0 ? 'vertice' : 'vertici'} · ${n * 2 ** Math.max(n - 1, 0)} ${n === 1 ? 'spigolo' : 'spigoli'} · ${DICT.ladder[n].cube.all_faces} ${n === 0 ? 'faccia (il vertice stesso)' : 'facce di ogni misura, dai singoli vertici al cubo intero'}`,
    priCap: (p, top) => `${p} numeri primi tra le etichette da 0 a ${top}`,
    noDots: 'ancora nessun punto',
    boxesIntro: 'Il modello ha 8 scatole, chiamate o, O1, O2, O3, H1, H2, c e r. Ogni particella è un legame da una scatola a un’altra; una carica mette dei numeri sulle scatole. Il modello ha anche una chiave speciale, un quarto di giro: girala due volte e ogni segno si capovolge.',
    pick: 'Scegli una particella, un portatore di forza o una carica',
    groups: { matter: 'Particelle di materia (una famiglia)', gauge: 'Portatori di forza', cartan: 'Cariche', replica: 'Legami di scorta (aperto)' },
    kind: { matter: 'materia', gauge: 'portatore di forza', replica: 'scorta', cartan: 'carica' }, group: 'gruppo',
    edge: (name, a, b, ch) => `${name}: il legame dalla scatola ${a} alla scatola ${b} (gruppo ${ch}).`,
    diag: name => `${name}: non è un legame. Mette dei numeri sulle scatole (i numeri nel disegno); una scatola senza numero vale zero.`,
    lights: k => `Sul cubo degli 8 interruttori accende ${k} vertici (blu) e i loro ${k} compagni secondo la chiave speciale (rosa).`,
    bitsH: 'I vertici come interruttori (1 = acceso)', numsH: 'Gli stessi vertici come numeri',
    boxes: 'Le 8 scatole: la tua scelta è il legame in evidenza', cube8: 'I 256 vertici del cubo: blu e rosa sono la tua scelta', prime8: 'I numeri da 0 a 255: in oro i numeri primi, blu e rosa sono la tua scelta',
    anti: 'Ogni antiparticella è lo stesso legame percorso al contrario. Accende gli stessi vertici, quindi i vertici da soli non distinguono una particella dalla sua antiparticella.',
    open: 'Aperto: questo modello non colloca la particella di Higgs né i legami di scorta, e contiene una sola famiglia.',
    cartH: 'Cinque cariche',
    cart: 'Cinque etichette sono cariche: l’ipercarica, la carica elettrica, la carica debole e due cariche di colore. Ogni particella ha un valore per ciascuna (può essere zero). Insieme usano solo 7 vertici del cubo e i loro 7 compagni secondo la chiave speciale; la parte chiusa mostra quali.',
    fanoH: 'Sette gruppi di legami',
    fano: ['Le 8 scatole si possono unire in 28 modi. Questi 28 legami cadono in 7 gruppi da 4, e ogni gruppo usa ogni scatola esattamente una volta. Ogni punto del disegno è un gruppo.', 'Due punti qualsiasi stanno su una sola retta di tre punti; anche il cerchio tratteggiato conta come retta. Clicca un punto per vedere una particella di quel gruppo.']
  }
};
export const DICTIONARY_YL = YL, DICTIONARY_YL_NAMES = YL_NAME;
// the Young Learner's sentence for each stage of the ladder (0 to 8, then 9–16), for test_dictionary.mjs
export const DICTIONARY_STAGE_YL = { en: [...STAGE.en.map(x => x[0]), TAIL.en[0]], it: [...STAGE.it.map(x => x[0]), TAIL.it[0]] };
const REP = { uL: '(3,2,+1/6)', dL: '(3,2,+1/6)', uR: '(3,1,+2/3)', dR: '(3,1,−1/3)', nuL: '(1,2,−1/2)', eL: '(1,2,−1/2)', eR: '(1,1,−1)', nuR: '(1,1,0)' };
const KIND_EN = { matter: 'matter', gauge: 'gauge root', replica: 'replica', cartan: 'diagonal' };
const KIND_IT = { matter: 'materia', gauge: 'radice di gauge', replica: 'replica', cartan: 'diagonale' };

/* ---------- data helpers ---------- */
const OMEGA_N = DICT.omega.N;
const CODE = DICT.code.faces;                         // 16 integers
const REPS = (() => {                                 // coset representative per class
  const m = {}; DICT.states.forEach(s => { [...s.faces, ...s.phase_faces].forEach(f => { if (!(f.class in m)) m[f.class] = f.N; }); });
  DICT.cartan.forEach(c => { [...c.faces, ...c.phase_faces].forEach(f => { if (!(f.class in m)) m[f.class] = f.N; }); });
  return m;
})();
const CLASSES = Array.from({ length: 16 }, (_, i) => i);
const classRep = c => { if (REPS[c] !== undefined) return REPS[c]; return null; };
function allClassReps() {
  // build reps for all 16 classes from the footprint data not shipped: derive by xor with the omega class partner
  const r = { ...REPS }; return r;
}
const ORBIT = (() => { const o = {}; Object.entries(DICT.channels.by_channel).forEach(([c, v]) => v.classes.forEach(k => { o[k] = +c; })); o[0] = 0; o[7] = 0; return o; })();
function normalise(entry, group) {
  if (group === 'cartan') return { ...entry, kind: 'cartan', classes: [0, entry.phase_class], channel: 0, grade_parity: 0, grades: [...new Set([...entry.faces, ...entry.phase_faces].map(f => f.grade))].sort((a, b) => a - b) };
  return entry;
}
const ENTRIES = [
  ...DICT.states.map(s => ({ ...s, group: s.kind === 'matter' ? 'matter' : s.kind === 'gauge' ? 'gauge' : 'replica' })),
  ...DICT.cartan.map(c => ({ ...normalise(c, 'cartan'), group: 'cartan' }))
];
const lbl = (e, lang) => lang === 'en' ? e.label : e.label.replace('colour', 'colore').replace('gluon root', 'radice di gluone').replace('weak', 'debole').replace('colour', 'colore').replace('hypercharge', 'ipercarica').replace('electric charge', 'carica elettrica');
const faceSet = e => new Set([...(e.faces || []).map(f => f.N)]);
const phaseSet = e => new Set([...(e.phase_faces || []).map(f => f.N)]);

/* ---------- pictures ---------- */
function cubePositions(n, size) {
  const vs = []; const a = Array.from({ length: n }, (_, i) => [Math.cos(Math.PI * i / Math.max(n, 1) + 0.3), Math.sin(Math.PI * i / Math.max(n, 1) + 0.3)]);
  let minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9;
  for (let v = 0; v < 2 ** n; v++) { let x = 0, y = 0; for (let i = 0; i < n; i++) if (v >> i & 1) { x += a[i][0]; y += a[i][1]; } vs.push([x, y]); minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
  const m = n <= 4 ? 34 : 12, s = (size - 2 * m) / Math.max(maxx - minx, maxy - miny, 1e-9);
  return vs.map(([x, y]) => [m + (x - minx) * s + (size - 2 * m - (maxx - minx) * s) / 2, m + (y - miny) * s + (size - 2 * m - (maxy - miny) * s) / 2]);
}
function Cube({ n, hl = new Set(), hl2 = new Set(), size = 220, labels = false }) {
  const P = useMemo(() => cubePositions(n, size), [n, size]);
  const lines = []; for (let v = 0; v < 2 ** n; v++) for (let i = 0; i < n; i++) if (!(v >> i & 1)) lines.push([v, v | (1 << i)]);
  const dot = n >= 7 ? 1.6 : n >= 5 ? 2.4 : 4;
  return <svg viewBox={`0 0 ${size} ${size}`} role="img" aria-label={`${n}-cube`}>
    {lines.map(([a, b], i) => <line key={i} x1={P[a][0]} y1={P[a][1]} x2={P[b][0]} y2={P[b][1]} stroke="currentColor" strokeOpacity={n >= 7 ? .12 : .3} strokeWidth=".6" />)}
    {P.map(([x, y], v) => { const h1 = hl.has(v), h2 = hl2.has(v); return <circle key={v} cx={x} cy={y} r={h1 || h2 ? dot * 1.9 : dot} fill={h1 ? '#4cc9f0' : h2 ? '#ff5d8f' : 'currentColor'} fillOpacity={h1 || h2 ? 1 : .55} stroke={h1 || h2 ? '#fff' : 'none'} strokeWidth=".6" />; })}
    {labels && n <= 4 && P.map(([x, y], v) => <text key={'t' + v} x={x + 6} y={y - 5} fontSize="9" fill="currentColor">{v.toString(2).padStart(n, '0')}</text>)}
  </svg>;
}
function Simplex({ n, size = 220, lang = 'en', plain = false }) {
  if (n === 0) return <svg viewBox={`0 0 ${size} ${size}`}><circle cx={size / 2} cy={size / 2} r="6" fill="none" stroke="currentColor" strokeDasharray="3 3" /><text x={size / 2} y={size / 2 + 26} textAnchor="middle" fontSize="11" fill="currentColor">{plain ? (YL[lang] || YL.en).noDots : lang === 'en' ? '∅ (scalar face)' : '∅ (faccia scalare)'}</text></svg>;
  const P = Array.from({ length: n }, (_, i) => n === 1 ? [size / 2, size / 2] : [size / 2 + (size / 2 - 22) * Math.cos(-Math.PI / 2 + i * 2 * Math.PI / n), size / 2 + (size / 2 - 22) * Math.sin(-Math.PI / 2 + i * 2 * Math.PI / n)]);
  return <svg viewBox={`0 0 ${size} ${size}`} role="img" aria-label={`${n - 1}-simplex`}>
    {P.flatMap((a, i) => P.slice(i + 1).map((b, j) => <line key={i + '-' + j} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke="currentColor" strokeOpacity=".35" strokeWidth=".8" />))}
    {P.map(([x, y], i) => <circle key={i} cx={x} cy={y} r="4.5" fill="#4cc9f0" stroke="#0008" />)}
  </svg>;
}
function PrimeGrid({ n, hl = new Set(), hl2 = new Set(), size = 220, numbers = false }) {
  const cols = n >= 8 ? 16 : Math.ceil(Math.sqrt(2 ** n)), rows = Math.ceil(2 ** n / cols), c = (size - 4) / cols;
  const cells = []; for (let v = 0; v < 2 ** n; v++) {
    const x = 2 + (v % cols) * c, y = 2 + Math.floor(v / cols) * c, p = isPrime(v), h1 = hl.has(v), h2 = hl2.has(v);
    cells.push(<g key={v}><rect x={x} y={y} width={c - .6} height={c - .6} fill={h1 ? '#4cc9f0' : h2 ? '#ff5d8f' : p ? '#ffd166' : 'currentColor'} fillOpacity={h1 || h2 ? .95 : p ? .55 : .08} />
      {numbers && <text x={x + c / 2} y={y + c / 2 + 3} fontSize={Math.min(11, c / 2.2)} textAnchor="middle" fill="currentColor">{v}</text>}</g>);
  }
  return <svg viewBox={`0 0 ${size} ${Math.max(size * rows / cols, 30)}`} role="img" aria-label="integer grid with primes"><Tx>{cells}</Tx></svg>;
}
function GradeBars({ row, size = 220, plain = false }) {
  const mx = Math.max(...row.grades.map(g => g.count)), w = (size - 10) / row.grades.length;
  return <svg viewBox={`0 0 ${size} 150`} role="img" aria-label="grade counts">
    {row.grades.map((g, i) => { const h = 90 * g.count / mx; return <g key={i}><rect x={5 + i * w + 2} y={105 - h} width={w - 4} height={h} fill="#4cc9f0" fillOpacity=".8" /><text x={5 + i * w + w / 2} y={118} fontSize="9" textAnchor="middle" fill="currentColor">{g.count}</text>{!plain && <text x={5 + i * w + w / 2} y={130} fontSize="7.5" textAnchor="middle" fill="currentColor" fillOpacity=".7"><SvgTx>{g.factors}</SvgTx></text>}<text x={5 + i * w + w / 2} y={144} fontSize="8" textAnchor="middle" fill="currentColor" fillOpacity=".6">{plain ? g.g : 'g' + g.g}</text></g>; })}
  </svg>;
}
function PeirceGraph({ entry, size = 260, lang = 'en' }) {
  const P = {}; VERTS.forEach((v, i) => { P[v] = vpos(i, size / 2 - 34, size / 2, size / 2 + 4); });
  const from = entry.from, to = entry.to, chan = entry.channel;
  const chanEdges = chan ? DICT.channels.by_channel[chan].edges : [];
  const isSel = e => (e.edge[0] === from && e.edge[1] === to) || (e.edge[0] === to && e.edge[1] === from);
  return <svg viewBox={`0 0 ${size} ${size + 8}`} role="img" aria-label={YLPIC() ? picYL(lang).dictBoxes : 'Peirce simplex'}>
    {DICT.channels.edges28.map((e, i) => { const [a, b] = e.edge.map(v => P[v]); const sel = isSel(e), mate = chan && e.channel === chan;
      return <line key={i} x1={a[0]} y1={a[1]} x2={b[0]} y2={b[1]} stroke={CH[e.channel]} strokeOpacity={sel ? 1 : mate ? .75 : .16} strokeWidth={sel ? 3.4 : mate ? 1.8 : .8} strokeDasharray={e.kind === 'replica' ? '4 3' : undefined} />; })}
    {from && to && (() => { const a = P[from], b = P[to], dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), ux = dx / L, uy = dy / L, tx = b[0] - ux * 14, ty = b[1] - uy * 14;
      return <polygon points={`${b[0] - ux * 9},${b[1] - uy * 9} ${tx - uy * 5},${ty + ux * 5} ${tx + uy * 5},${ty - ux * 5}`} fill="#fff" />; })()}
    {VERTS.map(v => { const [x, y] = P[v], hot = v === from || v === to; return <g key={v}><circle cx={x} cy={y} r={hot ? 14 : 11} fill={BLOCK_COLORS[VBLOCK[v]]} stroke={hot ? '#fff' : '#0008'} strokeWidth={hot ? 2 : 1} /><text x={x} y={y + 3.5} textAnchor="middle" fontSize="10" fontWeight="700" fill="#111">{v}</text></g>; })}
    {entry.kind === 'cartan' && CARTAN_INFO[entry.id] && VERTS.map(v => { const w = CARTAN_INFO[entry.id].w[v[0] === 'O' ? 'O' : v] ?? CARTAN_INFO[entry.id].w[v]; if (w === undefined) return null; const [x, y] = P[v]; return <text key={'w' + v} x={x} y={y - 17} textAnchor="middle" fontSize="8.5" fill="currentColor">{w === Math.round(w) ? w : w.toFixed(3)}</text>; })}
  </svg>;
}
function CosetGrid({ entry, size = 260 }) {
  // rows: 16 classes ordered by channel; columns: 16 code words. cell = rep_class XOR code_word
  const order = [0, 7, 1, 6, 2, 5, 3, 4, 8, 15, 9, 14, 10, 13, 11, 12];
  const real = faceSet(entry), ph = phaseSet(entry);
  const reps = useMemo(() => {                       // class reps from data: any face gives its class; others via the omega partner
    const m = {}; ENTRIES.forEach(e => [...e.faces, ...e.phase_faces].forEach(f => { m[f.class] = m[f.class] ?? f.N; }));
    Object.keys(m).forEach(c => { const p = ORBIT[c] === 0 ? null : null; });
    return m;
  }, []);
  const known = order.filter(c => reps[c] !== undefined);
  const c = (size - 30) / 16;
  return <svg viewBox={`0 0 ${size} ${size}`} role="img" aria-label="coset grid">
    {order.map((cl, r) => reps[cl] === undefined ? null : CODE.map((cw, j) => { const N = reps[cl] ^ cw, h1 = real.has(N), h2 = ph.has(N); return <rect key={r + '-' + j} x={28 + j * c} y={4 + r * c} width={c - .8} height={c - .8} fill={h1 ? '#4cc9f0' : h2 ? '#ff5d8f' : CH[ORBIT[cl]] ?? '#888'} fillOpacity={h1 || h2 ? 1 : .22} />; }))}
    {order.map((cl, r) => reps[cl] === undefined ? null : <text key={'l' + r} x="24" y={4 + r * c + c * .72} fontSize="8" textAnchor="end" fill="currentColor"><SvgTx>{cl}</SvgTx></text>)}
  </svg>;
}
function Fano({ pick, setPick, entry }) {
  const members = ch => DICT.channels.by_channel[ch].edges.filter(e => e.kind !== 'replica').map(e => e.edge.join('–'));
  const even = DICT.channels.even_channels;
  return <svg viewBox="0 0 360 310" role="img" aria-label="Fano plane of channels">
    {[[3, 8], [8, 9], [9, 3]].map(([a, b], i) => <line key={i} x1={FANO_POS[a][0]} y1={FANO_POS[a][1]} x2={FANO_POS[b][0]} y2={FANO_POS[b][1]} stroke="currentColor" strokeOpacity=".45" />)}
    {[[3, 1], [8, 10], [9, 11]].map(([a, b], i) => <line key={'m' + i} x1={FANO_POS[a][0]} y1={FANO_POS[a][1]} x2={FANO_POS[b][0]} y2={FANO_POS[b][1]} stroke="currentColor" strokeOpacity=".45" />)}
    <circle cx="180" cy="183" r="67" fill="none" stroke="#4cc9f0" strokeOpacity=".7" strokeWidth="2" strokeDasharray="5 3" />
    {Object.entries(FANO_POS).map(([ch, [x, y]]) => { const c = +ch, on = entry && entry.channel === c;
      return <g key={ch} onClick={() => setPick && setPick(c)} style={{ cursor: 'pointer' }}><circle cx={x} cy={y} r={on ? 19 : 16} fill={CH[c]} stroke={on ? '#fff' : '#0008'} strokeWidth={on ? 3 : 1} /><text x={x} y={y + 4} textAnchor="middle" fontSize="12" fontWeight="700" fill="#111">{c}</text></g>; })}
  </svg>;
}

/* ---------- main ---------- */
const STYLE = `
.dict{margin:28px auto;max-width:1000px;padding:0 1rem}
.dict h2{margin:.2rem 0 .6rem}.dict h3{margin:1.4rem 0 .5rem}
.dict .d-card{border:1px solid rgba(160,170,200,.28);border-radius:14px;padding:1rem 1.1rem;background:rgba(120,130,170,.07)}
.dict .d-row{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:.8rem}
.dict .d-row2{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:.8rem;margin-top:.8rem}
.dict .d-cap{font-size:.74rem;opacity:.72;margin:.2rem 0 0}.dict svg{width:100%;height:auto;display:block}
.dict .d-chips{display:flex;flex-wrap:wrap;gap:.35rem}.dict button.d-chip{font:inherit;font-size:.82rem;border:1px solid rgba(160,170,200,.4);background:transparent;color:inherit;border-radius:99px;padding:.2rem .7rem;cursor:pointer}
.dict button.d-chip.on{background:#4cc9f0;color:#06222b;border-color:#4cc9f0}
.dict .d-head{display:flex;gap:.6rem;align-items:baseline;flex-wrap:wrap}.dict .d-badge{font-size:.72rem;border:1px solid;border-radius:99px;padding:.1rem .6rem}
.dict .d-mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.76rem;word-break:break-all}.dict .d-card h4{margin:.1rem 0 .35rem;font-size:.9rem}
.dict .d-card p{margin:.25rem 0;font-size:.86rem}
.dict .d-stages{display:flex;gap:.3rem;flex-wrap:wrap;margin:.5rem 0}
@media(max-width:900px){.dict .d-row{grid-template-columns:repeat(2,minmax(0,1fr))}.dict .d-row2{grid-template-columns:1fr}}`;

function download(name, text, type) { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } }

function Ladder({ lang, profile }) {
  const [n, setN] = useState(8);
  const t = UI[lang], y = YL[lang] || YL.en; const learner = isLearner(profile);
  const row = DICT.ladder[Math.min(n, 16)], m8 = Math.min(n, 8);
  const cell = cliffordCell(0, Math.min(n, 16)), neutral = n % 2 === 0 ? cliffordCell(n / 2, n / 2) : null;
  const txt = n <= 8 ? STAGE[lang][n] : TAIL[lang];
  const k = row.k, r = row.r, genesis = `Cl(${k},${k}${r ? ',1' : ''})`;
  // the ten stages are tabs (as the page's own tab bar): role=tab, aria-selected, one tab in the Tab order, arrow keys / Home / End move between them
  const sel = n > 8 ? 9 : n, bar = useRef(null);
  const key = (e, i) => { const to = e.key === 'ArrowRight' ? (i + 1) % 10 : e.key === 'ArrowLeft' ? (i + 9) % 10 : e.key === 'Home' ? 0 : e.key === 'End' ? 9 : -1; if (to < 0) return; e.preventDefault(); setN(to); setTimeout(() => bar.current?.querySelector(`[data-stage="${to}"]`)?.focus(), 0); };
  return <div>
    <div className="d-stages" role="tablist" aria-label={t.stage} ref={bar}>{Array.from({ length: 10 }, (_, i) => <button key={i} role="tab" id={'d-stage-tab-' + i} data-stage={i} aria-selected={i === sel} aria-controls="d-stage-panel" tabIndex={i === sel ? 0 : -1} className={'d-chip' + (i === sel ? ' on' : '')} onClick={() => setN(i)} onKeyDown={e => key(e, i)}><Tx>{i === 9 ? '9–16' : i}</Tx></button>)}</div>
    <div role="tabpanel" id="d-stage-panel" aria-labelledby={'d-stage-tab-' + sel}>
    <p style={{ fontSize: '.95rem' }}><b><Tx>{learner ? y.stage : t.stage}</Tx>: <Tx>{n > 8 ? '9–16' : n}</Tx></b> — <Tx>{learner ? txt[0] : txt[1]}</Tx></p>
    {learner ? <div className="d-row">
      <div className="d-card"><h4><Tx>{y.views.alg}</Tx></h4><GradeBars row={row} plain /><p className="d-cap"><Tx>{y.gradeCap}</Tx></p></div>
      <div className="d-card"><h4><Tx>{y.views.sim}</Tx></h4><Simplex n={m8} lang={lang} plain /><p className="d-cap"><Tx>{y.simCap(m8)}</Tx></p></div>
      <div className="d-card"><h4><Tx>{y.views.cub}</Tx></h4><Cube n={m8} labels /><p className="d-cap"><Tx>{y.cubCap(m8)}</Tx></p></div>
      <div className="d-card"><h4><Tx>{y.views.pri}</Tx></h4><PrimeGrid n={m8} numbers={n <= 4} /><p className="d-cap"><Tx>{y.priCap(DICT.ladder[m8].primes_in_labels, 2 ** m8 - 1)}</Tx></p></div>
    </div> : <div className="d-row">
      <div className="d-card"><h4><Tx>{t.views.alg}</Tx></h4>{n <= 8 && <p className="d-mono"><Tx>{lang === 'en' ? 'Genesis cell' : 'Cella Genesi'}</Tx> <Tx>{genesis}</Tx><Tx>{learner ? '' : ` · dim ${row.dim}`}</Tx></p>}<p className="d-mono">Cl(0,<Tx>{n}</Tx>) = <Tx>{cell.algebra}</Tx></p>{!learner && neutral && <p className="d-mono">Cl(<Tx>{n / 2}</Tx>,<Tx>{n / 2}</Tx>) = <Tx>{neutral.algebra}</Tx></p>}{!learner && <p className="d-mono">I² = <Tx>{cell.omega2 > 0 ? '+1' : '−1'}</Tx></p>}<GradeBars row={row} /></div>
      <div className="d-card"><h4><Tx>{t.views.sim}</Tx></h4><Simplex n={Math.min(n, 8)} lang={lang} /><p className="d-cap"><Tx>{n === 0 ? (lang === 'en' ? '0-simplex: ∅' : '0-simplesso: ∅') : lang === 'en' ? `${Math.min(n, 8)} vertices = ${Math.min(n, 8) - 1}-simplex · ${2 ** Math.min(n, 8)} faces incl. ∅` : `${Math.min(n, 8)} ${n === 1 ? 'vertice' : 'vertici'} = ${Math.min(n, 8) - 1}-simplesso · ${2 ** Math.min(n, 8)} facce, ∅ compresa`}</Tx></p></div>
      <div className="d-card"><h4><Tx>{t.views.cub}</Tx></h4><Cube n={Math.min(n, 8)} labels /><p className="d-cap"><Tx>{2 ** Math.min(n, 8)}</Tx> <Tx>{lang === 'en' ? 'vertices' : n === 0 ? 'vertice' : 'vertici'}</Tx> · <Tx>{Math.min(n, 8) * 2 ** Math.max(Math.min(n, 8) - 1, 0)}</Tx> <Tx>{lang === 'en' ? 'edges' : n === 1 ? 'spigolo' : 'spigoli'}</Tx> · <Tx>{3 ** Math.min(n, 8)}</Tx> <Tx>{lang === 'en' ? (n === 0 ? 'face' : 'faces of all dimensions') : n === 0 ? 'faccia' : 'facce di ogni dimensione'}</Tx></p></div>
      <div className="d-card"><h4><Tx>{t.views.pri}</Tx></h4><PrimeGrid n={Math.min(n, 8)} numbers={n <= 4} /><p className="d-cap"><Tx>{DICT.ladder[Math.min(n, 8)].primes_in_labels}</Tx> <Tx>{lang === 'en' ? 'primes among labels' : 'primi tra le etichette'}</Tx> 0…<Tx>{2 ** Math.min(n, 8) - 1}</Tx><Tx>{!learner && row.odd_primes_in_grade_counts.length ? ` · ${lang === 'en' ? 'odd primes in' : 'primi dispari in'} C(${n > 8 ? 'n' : n},k): ${row.odd_primes_in_grade_counts.join(', ')}` : ''}</Tx></p></div>
    </div>}
    <Formal profile={profile} lang={lang}>{learner && <div className="d-card" style={{ marginTop: '.8rem' }}><h4><Tx>{t.views.alg}</Tx></h4>{n <= 8 && <p className="d-mono"><Tx>{lang === 'en' ? 'Genesis cell' : 'Cella Genesi'}</Tx> <Tx>{genesis}</Tx></p>}<p className="d-mono">Cl(0,<Tx>{n}</Tx>) = <Tx>{cell.algebra}</Tx></p></div>}
    {n >= 8 && <div className="d-card" style={{ marginTop: '.8rem' }}><h4><Tx>{t.why8H}</Tx></h4><ul style={{ margin: 0, paddingLeft: '1.1rem' }}>{WHY8[lang].map((x, i) => <li key={i} style={{ fontSize: '.86rem' }}><Tx>{x}</Tx></li>)}</ul></div>}</Formal>
    </div>
  </div>;
}

function Detail({ e, lang, profile }) {
  const t = UI[lang], learner = profile === 'Young Learner';
  const real = [...faceSet(e)], ph = [...phaseSet(e)];
  const isEdge = e.kind !== 'cartan', ch = e.channel;
  const KI = lang === 'en' ? KIND_EN : KIND_IT;
  const furey = isEdge
    ? `${e.blocks[0].replace('C3_O', 'ℂ³_𝕆').replace('C2_H', 'ℂ²_ℍ').replace('C_C', 'ℂ_ℂ').replace('C_O', 'ℂ_𝕆').replace('C_last', 'ℂ_last')} ← ${e.blocks[1].replace('C3_O', 'ℂ³_𝕆').replace('C2_H', 'ℂ²_ℍ').replace('C_C', 'ℂ_ℂ').replace('C_O', 'ℂ_𝕆').replace('C_last', 'ℂ_last')} · Y=${fracStr(e.Y)} · Q=${fracStr(e.Q)}${REP[e.id.replace(/\d$/, '')] ? ' · ' + REP[e.id.replace(/\d$/, '')] : ''}`
    : CARTAN_INFO[e.id][lang];
  const simplex = isEdge
    ? `${lang === 'en' ? 'Peirce simplex edge' : 'Lato del simplesso di Peirce'} ${e.from}→${e.to} · ${lang === 'en' ? 'channel' : 'canale'} ${ch}${lang === 'en' ? ': a perfect matching of the 8 vertices with' : ': accoppiamento perfetto degli 8 vertici con'} ${DICT.channels.by_channel[ch].edges.map(x => x.edge.join('–')).join(', ')}`
    : (lang === 'en' ? 'weights on the 8 vertices of the Peirce simplex (numbers on the picture)' : 'pesi sugli 8 vertici del simplesso di Peirce (numeri nel disegno)');
  const foot = ch ? DICT.channels.blade_simplex_footprint[ch] : DICT.channels.blade_simplex_footprint[0];
  const gradeDims = e.grades.map(g => g - 1).join(', ');
  const clifford = isEdge
    ? `${lang === 'en' ? 'Real part: 8 blades of grade' : 'Parte reale: 8 blade di grado'} ${[...new Set(e.faces.map(f => f.grade))].join(', ')} ${lang === 'en' ? 'in coset' : 'nel laterale'} ${e.faces[0].class}${learner ? '' : ` (coefficients ${[...new Set(e.faces.map(f => fracStr(f.coef)))].join(', ')})`}; ${lang === 'en' ? 'ω-partner in coset' : 'partner ω nel laterale'} ${e.phase_faces[0].class}. ${lang === 'en' ? 'Blade-simplex faces of dimension' : 'Facce del simplesso dei blade di dimensione'} ${gradeDims}.`
    : `${lang === 'en' ? 'Diagonal: blades of grade' : 'Diagonale: blade di grado'} ${[...new Set(e.faces.map(f => f.grade))].join(', ')} (${lang === 'en' ? 'code faces' : 'facce del codice'}); ${lang === 'en' ? 'phase form ω·X in coset' : 'forma di fase ω·X nel laterale'} ${e.phase_class}.`;
  const cube = `${[...real.map(n => n.toString(2).padStart(8, '0')), ...ph.map(n => n.toString(2).padStart(8, '0'))].join(' ')}`;
  const primeList = [...real, ...ph].sort((a, b) => a - b).map(n => `${n}${learner ? '' : ` (${fstr(n)})`}`).join(', ');
  const cross = isEdge
    ? (lang === 'en'
      ? `${lbl(e, lang)}: edge ${e.from}→${e.to} of the Peirce simplex, channel ${ch} (${e.grade_parity ? 'odd' : 'even'} grades). In Clifford it is 8+8 blades ${e.grade_parity ? 'of odd grade (the two copies are exchanged by g₈)' : 'of even grade (inside one octonion copy)'}; in the 8-cube it is two 8-vertex pieces of two cosets, one the ω-translate (XOR ${OMEGA_N.toString(2).padStart(8, '0')}) of the other; as integers: ${[...real].sort((a, b) => a - b).join(', ')}.`
      : `${lbl(e, lang)}: lato ${e.from}→${e.to} del simplesso di Peirce, canale ${ch} (gradi ${e.grade_parity ? 'dispari' : 'pari'}). In Clifford sono 8+8 blade ${e.grade_parity ? 'di grado dispari (le due copie sono scambiate da g₈)' : 'di grado pari (dentro una copia ottonionica)'}; nell’8-cubo sono due pezzi da 8 vertici di due laterali, uno traslato di ω (XOR ${OMEGA_N.toString(2).padStart(8, '0')}) dell’altro; come interi: ${[...real].sort((a, b) => a - b).join(', ')}.`)
    : (lang === 'en' ? `${lbl(e, lang)}: a combination of the 16 code blades (the Witt torus) on the Peirce vertices; its phase form lives in the ω-coset.` : `${lbl(e, lang)}: combinazione dei 16 blade del codice (toro di Witt) sui vertici di Peirce; la sua forma di fase vive nel laterale di ω.`);
  const cards = [[t.cols.furey, furey], [t.cols.sim, simplex + (isEdge ? ` · ${lang === 'en' ? 'footprint in the blade 7-simplex' : 'impronta nel 7-simplesso dei blade'}: ${foot.vertices.length ? foot.vertices.length + (lang === 'en' ? ' vertices, ' : ' vertici, ') : ''}${foot.edges.length ? foot.edges.length + (lang === 'en' ? ' edges, ' : ' spigoli, ') : ''}${Object.entries(foot.faces_by_grade).map(([g, c]) => `${c}×dim ${g - 1}`).join(', ')}` : '')], [t.cols.cli, clifford], [t.cols.cub, cube], [t.cols.pri, primeList + (learner ? '' : (lang === 'en' ? ` · each digit is 1 in exactly 4 of the 8 real faces (integers sum to 1020 = 4·255)` : ` · ogni cifra vale 1 in esattamente 4 degli 8 blade reali (somma degli interi 1020 = 4·255)`))], [t.cols.crs, cross]];
  if (learner) {
    const y = YL[lang] || YL.en, name = ylName(e, lang), formal = cards.filter(([h]) => h !== t.cols.cub && h !== t.cols.pri);
    return <div className="d-card" style={{ marginTop: '.8rem' }}>
      <div className="d-head"><h3 style={{ margin: 0 }}><Tx>{name}</Tx></h3><span className="d-badge" style={{ color: ch ? CH[ch] : '#8b93a8', borderColor: ch ? CH[ch] : '#8b93a8' }}><Tx>{y.kind[e.kind]}</Tx><Tx>{ch ? ` · ${y.group} ${ch}` : ''}</Tx></span></div>
      <p><Tx>{isEdge ? y.edge(name, e.from, e.to, ch) : y.diag(name)}</Tx> <Tx>{y.lights(real.length)}</Tx></p>
      <div className="d-row2" style={{ gridTemplateColumns: 'repeat(auto-fit,minmax(14rem,1fr))' }}><div className="d-card"><h4><Tx>{y.bitsH}</Tx></h4><p className="d-mono"><Tx>{cube}</Tx></p></div><div className="d-card"><h4><Tx>{y.numsH}</Tx></h4><p className="d-mono"><Tx>{primeList}</Tx></p></div></div>
      <div className="d-row" style={{ marginTop: '.8rem' }}>
        <div><PeirceGraph entry={e} lang={lang} /><p className="d-cap"><Tx>{y.boxes}</Tx></p></div>
        <div><Cube n={8} hl={faceSet(e)} hl2={phaseSet(e)} size={260} /><p className="d-cap"><Tx>{y.cube8}</Tx></p></div>
        <div><PrimeGrid n={8} hl={faceSet(e)} hl2={phaseSet(e)} size={260} /><p className="d-cap"><Tx>{y.prime8}</Tx></p></div>
      </div>
      <Formal profile={profile} lang={lang}><h4><Tx>{lbl(e, lang)}</Tx></h4><div className="d-row2">{formal.map(([h, b]) => <div className="d-card" key={h}><h4><Tx>{h}</Tx></h4><p><Tx>{b}</Tx></p></div>)}</div>
        <div className="d-row" style={{ marginTop: '.8rem' }}><div><CosetGrid entry={e} /><p className="d-cap"><Tx>{t.cols.cli}</Tx>: 16 <Tx>{lang === 'en' ? 'cosets × 16 code words' : 'laterali × 16 parole del codice'}</Tx></p></div></div></Formal>
    </div>;
  }
  return <div className="d-card" style={{ marginTop: '.8rem' }}>
    <div className="d-head"><h3 style={{ margin: 0 }}><Tx>{lbl(e, lang)}</Tx></h3><span className="d-badge" style={{ color: ch ? CH[ch] : '#8b93a8', borderColor: ch ? CH[ch] : '#8b93a8' }}><Tx>{KI[e.kind]}</Tx><Tx>{ch ? ` · ${lang === 'en' ? 'channel' : 'canale'} ${ch}` : ''}</Tx></span></div>
    <div className="d-row2">{cards.map(([h, b]) => <div className="d-card" key={h}><h4><Tx>{h}</Tx></h4><p className={h === t.cols.cub || h === t.cols.pri ? 'd-mono' : ''}><Tx>{b}</Tx></p></div>)}</div>
    <div className="d-row" style={{ marginTop: '.8rem' }}>
      <div><PeirceGraph entry={e} /><p className="d-cap"><Tx>{t.cols.sim}</Tx></p></div>
      <div><CosetGrid entry={e} /><p className="d-cap"><Tx>{t.cols.cli}</Tx>: 16 <Tx>{lang === 'en' ? 'cosets × 16 code words' : 'laterali × 16 parole del codice'}</Tx></p></div>
      <div><Cube n={8} hl={faceSet(e)} hl2={phaseSet(e)} size={260} /><p className="d-cap"><Tx>{t.cols.cub}</Tx>: 256 <Tx>{lang === 'en' ? 'vertices; blue real part, pink ω-partner' : 'vertici; blu parte reale, rosa partner ω'}</Tx></p></div>
      <div><PrimeGrid n={8} hl={faceSet(e)} hl2={phaseSet(e)} size={260} /><p className="d-cap"><Tx>{t.cols.pri}</Tx>: 0…255 <Tx>{lang === 'en' ? '(gold = prime numbers)' : '(oro = numeri primi)'}</Tx></p></div>
    </div>
  </div>;
}

function CartanLedger({ lang }) {
  const L = DICT.cartan_ledger, en = lang === 'en', ids = ['Y0', 'Q0', 'T3', 'l3', 'l8'];
  const nm = { Y0: 'Y₀ = Y − 3/8', Q0: 'Q₀ = Q − 3/8', T3: 'T₃', l3: 'λ₃', l8: 'λ₈' };
  const gr = g => Object.entries(g).map(([k, v]) => v + '×' + (k === '2' ? (en ? 'bivector' : 'bivettore') : k === '6' ? (en ? 'hexavector' : 'esavettore') : 'g' + k)).join(' + ');
  const sg = (pos, n) => pos === 0 ? (en ? 'all −' : 'tutti −') : pos === n ? (en ? 'all +' : 'tutti +') : pos + '+ / ' + (n - pos) + '−';
  return <div className="d-card">
    <p>{en ? <>The five diagonal generators are signed combinations of only <b><Tx>{L.distinct_code_faces.length}</Tx></b> code faces and their <b><Tx>{L.distinct_phase_faces.length}</Tx></b> ω-translates (XOR with ω = N <Tx>{L.omega_mask}</Tx> = <span className="d-mono"><Tx>{L.omega_bits}</Tx></span>, a single grade-6 face). All 14 are ℂ-linear. The empty face is absent for every operator: all five are traceless. Y₀ and Q₀ are the traceless parts of hypercharge and charge (<Tx>{'Tr_ℂ Y'}</Tx> = 3 over dimension 8).</> : <>I cinque generatori diagonali sono combinazioni con segno di sole <b><Tx>{L.distinct_code_faces.length}</Tx></b> facce del codice e delle loro <b><Tx>{L.distinct_phase_faces.length}</Tx></b> traslate per ω (XOR con ω = N <Tx>{L.omega_mask}</Tx> = <span className="d-mono"><Tx>{L.omega_bits}</Tx></span>, una sola faccia di grado 6). Tutte e 14 sono ℂ-lineari. La faccia vuota è assente in ogni operatore: tutti e cinque sono a traccia nulla. Y₀ e Q₀ sono le parti a traccia nulla di ipercarica e carica (<Tx>{'Tr_ℂ Y'}</Tx> = 3 su dimensione 8).</>}</p>
    <div style={{ overflowX: 'auto' }}><table className="d-mono" style={{ borderCollapse: 'collapse', fontSize: '.8rem', width: '100%' }}>
      <thead><tr>{[en ? 'operator' : 'operatore', en ? 'code faces' : 'facce codice', en ? 'phase faces (grades)' : 'facce di fase (gradi)', en ? 'signs code' : 'segni codice', en ? 'signs phase' : 'segni fase', en ? '|coef| code' : '|coef| codice'].map(h => <th key={h} style={{ textAlign: 'left', padding: '2px 8px', borderBottom: '1px solid currentColor' }}><Tx>{h}</Tx></th>)}</tr></thead>
      <tbody>{ids.map(i => { const r = L.per_operator[i]; return <tr key={i}><td style={{ padding: '2px 8px' }}><Tx>{nm[i]}</Tx></td><td style={{ padding: '2px 8px' }}><Tx>{r.code_faces}</Tx></td><td style={{ padding: '2px 8px' }}><Tx>{r.phase_faces}</Tx> = <Tx>{gr(r.phase_grades)}</Tx></td><td style={{ padding: '2px 8px' }}><Tx>{sg(r.code_pos, r.code_faces)}</Tx></td><td style={{ padding: '2px 8px' }}><Tx>{sg(r.phase_pos, r.phase_faces)}</Tx></td><td style={{ padding: '2px 8px' }}><Tx>{r.code_abs.join(', ')}</Tx></td></tr>; })}</tbody></table></div>
    <p><Tx>{en ? 'Y₀ and Q₀ share one code set: 3 Fano-line tetrahedra {0,1,2,7}, {2,4,5,7}, {2,3,6,7}, their 3 complements {3,4,5,6}, {0,1,3,6}, {0,1,4,5}, and the top face (all 8 vertices). The operators overlap heavily (face {0,1,4,5} is used by all five), so the counts are per operator and do not partition anything; 9 of the 16 code faces are unused.' : 'Y₀ e Q₀ condividono lo stesso insieme di facce: 3 tetraedri di retta di Fano {0,1,2,7}, {2,4,5,7}, {2,3,6,7}, i 3 complementari {3,4,5,6}, {0,1,3,6}, {0,1,4,5} e la faccia superiore (tutti e 8 i vertici). Gli operatori si sovrappongono molto (la faccia {0,1,4,5} è usata da tutti e cinque), quindi i conteggi sono per operatore e non partizionano nulla; 9 delle 16 facce del codice restano inutilizzate.'}</Tx></p>
    <p className="d-cap"><Tx>{en ? 'Coefficient sums depend on the normalisation and are not structure; counts, grades and the XOR rule are. Face integers and their prime factors change with vertex order.' : 'Le somme dei coefficienti dipendono dalla normalizzazione e non sono struttura; lo sono i conteggi, i gradi e la regola XOR. Gli interi delle facce e i loro fattori primi cambiano con l’ordine dei vertici.'}</Tx></p>
  </div>;
}

export default function DictionarySection({ lang = 'en', profile = 'Young Learner' }) {
  const t = UI[lang] || UI.en, y = YL[lang] || YL.en, learner = isLearner(profile), dl = <DictionaryDownload t={t} />;
  const [sel, setSel] = useState('uL1');
  const e = ENTRIES.find(x => x.id === sel) || ENTRIES[0];
  const groups = ['matter', 'gauge', 'cartan', 'replica'];
  return <section className="dict" id="dictionary" aria-labelledby="dict-h">
    <style>{STYLE}</style>
    <p className="eyebrow"><Tx>{t.eyebrow}</Tx></p><h2 id="dict-h"><Tx>{learner ? y.title : t.title}</Tx></h2><Intro lang={lang} profile={profile} id="dictionary" lede={t.lede} />
    <h3><Tx>{learner ? y.ladderH : t.ladderH}</Tx></h3><Ladder lang={lang} profile={profile} />
    <h3><Tx>{t.dictH}</Tx></h3>{learner && <p><Tx>{y.boxesIntro}</Tx></p>}<p className="d-cap" style={{ fontSize: '.85rem' }}><Tx>{learner ? y.pick : t.pick}</Tx></p>
    {groups.map(g => <div key={g} style={{ margin: '.5rem 0' }}><div className="d-cap" style={{ marginBottom: '.2rem' }}><Tx>{(learner ? y : t).groups[g]}</Tx></div><div className="d-chips">{ENTRIES.filter(x => x.group === g).map(x => <button key={x.id} className={'d-chip' + (x.id === sel ? ' on' : '')} onClick={() => setSel(x.id)} aria-pressed={x.id === sel}><Tx>{learner ? ylName(x, lang) : lbl(x, lang)}</Tx></button>)}</div></div>)}
    <Detail e={e} lang={lang} profile={profile} />
    <p className="d-cap" style={{ fontSize: '.82rem' }}><Tx>{learner ? y.anti : t.antiNote}</Tx> <Tx>{learner ? y.open : t.open}</Tx></p>
    <h3><Tx>{learner ? y.cartH : t.cartH}</Tx></h3><Formal profile={profile} lang={lang} plain={<p><Tx>{y.cart}</Tx></p>}><CartanLedger lang={lang} /></Formal>
    <h3><Tx>{learner ? y.fanoH : t.fanoH}</Tx></h3>
    <div className="d-row2"><div className="d-card"><Fano pick={e.channel} setPick={c => { const x = ENTRIES.find(z => z.channel === c && z.kind === 'matter') || ENTRIES.find(z => z.channel === c); if (x) setSel(x.id); }} entry={e} /></div>
      <div className="d-card" style={{ gridColumn: 'span 2' }}><Formal profile={profile} lang={lang} plain={y.fano.map((x, i) => <p key={i}><Tx>{x}</Tx></p>)}><p><Tx>{lang === 'en' ? 'The 28 edges of the Peirce simplex fall into 7 parallel classes (channels); any two channels lie on exactly one of 7 lines of three: a Fano plane.' : 'I 28 lati del simplesso di Peirce cadono in 7 classi parallele (canali); due canali qualsiasi stanno su una sola delle 7 rette da tre: un piano di Fano.'}</Tx></p>
        <p><Tx>{lang === 'en' ? 'The dashed circle is a line: channels 1, 10, 11 hold the even-grade blades (gauge roots, i.e. the three gluon pairs and W±, plus the leptons e_R, ν_L, e_L, and some replica edges). The other four channels form the quadrangle of odd-grade blades (all quark edges and ν_R, plus replica edges). Grade parity is whether the edge joins the two octonion copies.' : 'Il cerchio tratteggiato è una retta: i canali 1, 10, 11 contengono i blade di grado pari (radici di gauge, cioè le tre coppie di gluoni e W±, più i leptoni e_R, ν_L, e_L e alcuni lati di replica). Gli altri quattro canali formano il quadrangolo dei blade di grado dispari (tutti i lati dei quark e ν_R, più lati di replica). La parità del grado dice se il lato unisce le due copie ottonioniche.'}</Tx></p>
        <p><Tx>{lang === 'en' ? 'In the blade 7-simplex, each odd channel owns a pair of vertices ({0,1}, {2,7}, {3,6}, {4,5}); each even channel owns 8 edges; the 4 vertex pairs are the edges of the diagonal channel.' : 'Nel 7-simplesso dei blade, ogni canale dispari possiede una coppia di vertici ({0,1}, {2,7}, {3,6}, {4,5}); ogni canale pari possiede 8 spigoli; le 4 coppie di vertici sono gli spigoli del canale diagonale.'}</Tx></p>
        {!learner && <p className="d-cap"><Tx>{lang === 'en' ? 'Not checked: whether this Fano plane equals the octonion multiplication plane.' : 'Non verificato: se questo piano di Fano coincida con il piano di moltiplicazione degli ottonioni.'}</Tx></p>}{learner && dl}</Formal></div></div>
    {!learner && dl}
  </section>;
}
function DictionaryDownload({ t }) {
  return <><h3><Tx>{t.dlH}</Tx></h3>
    <div className="d-card"><p><Tx>{t.dlText}</Tx></p>
      <div className="d-chips"><button className="d-chip on" onClick={() => download('dictionary_selfcheck.py', SELFCHECK_PY, 'text/x-python')}><Tx>{t.dlPy}</Tx></button><button className="d-chip" onClick={() => download('dictionary.json', JSON.stringify(DICT, null, 1), 'application/json')}><Tx>{t.dlJson}</Tx></button></div>
      <p className="d-mono" style={{ marginTop: '.5rem' }}><Tx>{t.dlCmd}</Tx></p></div></>;
}
