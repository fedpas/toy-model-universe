// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import G from './gossetData.js';

// Copy for step 3 of the shapes page (English and Italian). Kept apart from the component so the tests can read it.
const R = G.rank, P = G.polytopes, X = G.coordinates, B = G.branching, W = G.weyl_orders;
const fmt = x => String(x).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const NAMES = { en: { 3: 'A₂ × A₁', 4: 'A₄', 5: 'D₅', 6: 'E6', 7: 'E7', 8: 'E8', 9: 'E8 affine (E9)', 10: 'E10, hyperbolic' }, it: { 3: 'A₂ × A₁', 4: 'A₄', 5: 'D₅', 6: 'E6', 7: 'E7', 8: 'E8', 9: 'E8 affine (E9)', 10: 'E10, iperbolico' } };
const POLY = { 5: '1₂₁ = 5-demicube', 6: '2₂₁', 7: '3₂₁', 8: '4₂₁' }, POLY_IT = { ...POLY, 5: '1₂₁ = 5-demicubo' };
const inertia = n => { const [p, q, z] = R[n].inertia; return `${p} + ${q} + ${z}`; };
const roots = (n, inf) => R[n].roots == null ? inf : R[n].roots;
const COPY = {
  en: {
    title: 'The Gosset series: E6, E7, E8 and where it stops',
    lede: 'The orthoplex and the demicube meet in one place. The 8-orthoplex has 112 edges and the 8-demicube has 128 corners, and together they are the 240 roots of E8. E6 and E7 sit inside it. This step rebuilds the whole family from its Cartan matrices with exact arithmetic, then asks what it gives back to the views we already have.',
    tableH: 'The series, rebuilt from the Cartan matrices', pick: 'Rank n',
    cols: ['n', 'diagram', 'arms', '1/p + 1/q + 1/r', 'det', 'signs + − 0', 'roots', 'Gosset polytope'], names: NAMES.en, poly: POLY, infinite: 'infinitely many',
    tableNote: 'Each row is an exact determinant, an inertia count or a root count: the roots are found by closing the simple roots under reflections, and E9 and E10 pass 1000 without closing. The determinant is 9 − n in every row.',
    detail: n => n <= 5 ? `E${n} is ${NAMES.en[n]}: the small cases of the same family, positive definite with determinant ${R[n].det} and ${R[n].roots} roots.`
      : n <= 8 ? `E${n} is positive definite with determinant ${R[n].det}. It has ${R[n].roots} roots. Its Gosset polytope is the orbit of one fundamental weight: ${P[n].vertices} vertices, ${fmt(P[n].edges)} edges, ${P[n].degree} edges at every vertex. The Weyl group has ${fmt(W[n])} elements.`
      : n === 9 ? `E9 is the affine E8. The determinant is 0 and the signs are 8 + 0 + 1: positive semidefinite, with one null direction. Its integer null vector is ${G.rank[9].null_vector.join(' ')}, the marks of the affine node. Adding it to a root gives another root, so the roots never run out.`
      : 'E10 has determinant −1 and signs 9 + 1 + 0: one negative direction, so the form is indefinite and the root system is hyperbolic.',
    armsH: 'Why the list stops: three fractions',
    arms: `E_n is a fork with arms of 2, 3 and n − 3 nodes, centre included. It is positive definite exactly when 1/2 + 1/3 + 1/(n − 3) is larger than 1. The sum is 31/30 at n = 8 and exactly 1 at n = 9. The determinant is p·q·r·(1/p + 1/q + 1/r − 1) = 9 − n. This is the classification of finite diagrams and it is checked here for every row. Notice what it does not use: nothing about Clifford algebras.`,
    nestH: 'The polytopes nest',
    nest: 'The Gosset polytope of E_n is the orbit of the fundamental weight at the end of the long arm. The 16 neighbours of a vertex of the 27-vertex polytope form a 5-demicube; the 27 neighbours of a vertex of the 56-vertex polytope form the 27-vertex polytope; the 56 neighbours of a vertex of the 240-vertex polytope form the 56-vertex one. The first member is the 5-demicube itself, so step 2 is the first rung. Orbit and stabiliser give the Weyl orders: each is the previous one times the number of vertices.',
    nestRow: ['vertices', 'edges', 'at each vertex', 'vertex figure', 'Weyl group'], figs: { 5: 'rectified 4-simplex (10)', 6: '5-demicube (16)', 7: 'the 27-vertex polytope', 8: 'the 56-vertex polytope' },
    inH: 'E8 in the shapes we already have', inPick: 'Choose the series member', inCap: n => `The 2D trick once more, now the Coxeter plane: a turn of 1/${G.coxeter[n].h} (the Coxeter number) carries the ${R[n].roots} roots onto ${n} rings of ${G.coxeter[n].h}. In general roots = rank × Coxeter number: 72 = 6 × 12, 126 = 7 × 18, 240 = 8 × 30. Blue = edges of the orthoplex (squared length 2). Amber = corners of the demicube (squared length 2 at n = 8).`,
    split: { 8: `E8 in the coordinates of 8 axes: ${X['8'].orthoplex_edges} edges of the 8-orthoplex (±eᵢ ± eⱼ) and ${X['8'].demicube_vertices} corners of the 8-demicube (½(±1, …, ±1) with an even number of minus signs). Together 240.`,
      7: `E7 is the part perpendicular to the highest root: ${X['7'].orthoplex_edges_inside_first_6_axes} edges of the 6-orthoplex, ${X['7'].other_orthoplex_edges} further edges and ${X['7'].demicube_vertices} corners of the 8-demicube. 126 in all. The 64 are 32 sign patterns on six axes, each twice, with the last two signs opposite; 64 = 2⁶ is the number of facets of the 6-orthoplex, but this is a match of counts only.`,
      6: `E6 is smaller again: ${X['6'].orthoplex_edges_inside_first_5_axes} edges of the 5-orthoplex and ${X['6'].demicube_vertices} corners, which are exactly the 2⁵ sign patterns on five axes, one for each facet of the 5-orthoplex. 72 in all.` },
    glueH: 'Why 8: the length of the corners',
    glue: 'The 112 edges have squared length 2. The demicube corners ½(±1, …, ±1) have squared length n/4, so they are roots only when n = 8. The lattice made of the edges and the corners has whole-number inner products when 4 divides n, and only even norms when 8 divides n.',
    glueCols: ['n', 'corner length²', 'whole inner products', 'all norms even', 'shortest vectors'], yes: 'yes', no: 'no',
    glueNote: ['n = 4: length 1. The corners are the three-16-cells triality of step 1: the same 8 seen three ways.', 'n = 8: length 2. The corners become roots: E8, the even unimodular lattice of rank 8.', 'n = 12: length 3. Odd lattice.', 'n = 16: length 4. Even, but the corners add no roots; rank 16 has E8 ⊕ E8 (E8 twice) and D₁₆⁺ (edges only).'],
    glueTail: 'Even unimodular lattices exist only in ranks divisible by 8. That is standard.',
    brH: 'E8 contains E6 × A2: where a 3 appears', br: `Inside E8 the roots of E6 have a partner A2. Sorting the 240 roots by their A2 weight gives ${B.E6_roots} + ${B.A2_roots} + ${B.classes_of_27} × 27: the roots of E6, the roots of A2, and six classes of 27 roots, three of one kind (27) and three of the other (27̄). The number of copies of the 27 is the dimension of the smallest representation of A2. Seen from one vertex, a 27 is 1 + 16 + 10, and the 16 neighbours form a 5-demicube (step 2). All of this is checked as counts. Whether this 3 is the three generations of the model is open: the family test found no 3 in the places we looked (the Witt torus and the Z₂ parallel), and nothing here selects this A2.`,
    gbH: 'What E8 gives back to the other views',
    gb: [
      [['checked'], 'Demicube view. The 8-demicube is the 128-corner half of E8, and n = 8 is the only n where the corners are roots. The demicube of step 2 is also the first Gosset polytope.'],
      [['standard', 'checked'], 'Orthoplex and Fock view. The 112 edges are the roots of so(16): 112 + 8 = 120 = C(16, 2) bivectors of the 16 null generators of Genesis node 16, where Cl(8,8) = M₂₅₆(ℝ). The 128 corners are one half of the 256-dimensional spinor space. So 248 = 120 + 128. The arithmetic is checked; reading the roots as Genesis is ours.'],
      [['checked', 'open'], 'Furey view. The 3 above is a branching fact of E8, like the three 16-cells at n = 4 (Q₈ of index 3): a 3 inside a shape. Neither has been tied to the model, and the model has not been shown to contain this A2.'],
      [['open'], 'Maxwell view. Nothing comes back. F is a bivector of four generators and E8 needs sixteen.']
    ],
    bdH: 'The finite budget: what is checked and what is a resemblance',
    bd: 'Your three checks hold as arithmetic: E3 to E8 are positive definite with determinants 6, 5, 4, 3, 2, 1; E9 is singular and affine; E10 is indefinite. The budget in our frame is a different statement. Period 8 of the Clifford cells is read from the standard type table (not derived from the axioms), and Cl(n+4,n+4) = Cl(n,n) ⊗ M₁₆(ℝ) repeats the cells rather than stopping them. The Gosset list stops for a reason that does not mention Clifford algebras, and what comes after E8 is not a wall either: E9 is E8 as a loop algebra and E10 is hyperbolic. Two things are common to both: the number 8, reached by mechanisms that look different, and the length n/4 of the corners, which makes a lattice even exactly when 8 divides n. Whether that mod-8 and the Clifford mod-8 are one fact is open. As of now it is a resemblance.',
    limits: 'The match between 8 and 8 is not a derivation. The 112 + 128 split is a statement about coordinates; reading it as the orthoplex and the demicube of our frame is ours.',
    dlH: 'Check it yourself', dlText: 'One self-contained Python file (standard library only). It rebuilds the Cartan determinants and signs, the roots by reflection, the Gosset polytopes by orbit, the vertex figures by graph isomorphism, the coordinates of E8, the E6 × A2 classes and the Coxeter plane, and compares them with the data on this page.', dlPy: 'Download gosset_selfcheck.py', dlJson: 'Download gosset.json', dlCmd: 'python3 gosset_selfcheck.py --compare gosset.json'
  },
  it: {
    title: 'La serie di Gosset: E6, E7, E8 e dove si ferma',
    lede: 'L’ortoplesso e il demicubo si incontrano in un punto. L’8-ortoplesso ha 112 spigoli e l’8-demicubo ha 128 vertici, e insieme sono le 240 radici di E8. E6 ed E7 stanno dentro. Questo passo ricostruisce tutta la famiglia dalle matrici di Cartan con aritmetica esatta, poi chiede che cosa restituisce alle viste che abbiamo già.',
    tableH: 'La serie, ricostruita dalle matrici di Cartan', pick: 'Rango n',
    cols: ['n', 'diagramma', 'bracci', '1/p + 1/q + 1/r', 'det', 'segni + − 0', 'radici', 'Politopo di Gosset'], names: NAMES.it, poly: POLY_IT, infinite: 'infinite',
    tableNote: 'Ogni riga è un determinante esatto, un conteggio di inerzia o un conteggio di radici: le radici si trovano chiudendo le radici semplici sotto le riflessioni, e E9 ed E10 superano 1000 senza chiudere. Il determinante è 9 − n in ogni riga.',
    detail: n => n <= 5 ? `E${n} è ${NAMES.it[n]}: i casi piccoli della stessa famiglia, definita positiva con determinante ${R[n].det} e ${R[n].roots} radici.`
      : n <= 8 ? `E${n} è definita positiva con determinante ${R[n].det}. Ha ${R[n].roots} radici. Il suo politopo di Gosset è l’orbita di un peso fondamentale: ${P[n].vertices} vertici, ${fmt(P[n].edges)} spigoli, ${P[n].degree} spigoli per vertice. Il gruppo di Weyl ha ${fmt(W[n])} elementi.`
      : n === 9 ? `E9 è l’E8 affine. Il determinante è 0 e i segni sono 8 + 0 + 1: semidefinita positiva, con una direzione nulla. Il suo vettore nullo intero è ${G.rank[9].null_vector.join(' ')}, i segni del nodo affine. Sommarlo a una radice dà un’altra radice, quindi le radici non finiscono mai.`
      : 'E10 ha determinante −1 e segni 9 + 1 + 0: una direzione negativa, quindi la forma è indefinita e il sistema di radici è iperbolico.',
    armsH: 'Perché l’elenco si ferma: tre frazioni',
    arms: `E_n è una forcella con bracci di 2, 3 e n − 3 nodi, centro compreso. È definita positiva esattamente quando 1/2 + 1/3 + 1/(n − 3) è maggiore di 1. La somma è 31/30 a n = 8 ed esattamente 1 a n = 9. Il determinante è p·q·r·(1/p + 1/q + 1/r − 1) = 9 − n. È la classificazione dei diagrammi finiti e qui è verificata per ogni riga. Si noti che cosa non usa: niente sulle algebre di Clifford.`,
    nestH: 'I politopi si annidano',
    nest: 'Il politopo di Gosset di E_n è l’orbita del peso fondamentale in fondo al braccio lungo. I 16 vicini di un vertice del politopo con 27 vertici formano un 5-demicubo; i 27 vicini di un vertice di quello con 56 vertici formano il politopo con 27 vertici; i 56 vicini di un vertice di quello con 240 vertici formano quello con 56. Il primo membro è il 5-demicubo stesso, quindi il passo 2 è il primo gradino. Orbita e stabilizzatore danno gli ordini di Weyl: ciascuno è il precedente per il numero di vertici.',
    nestRow: ['vertici', 'spigoli', 'per vertice', 'figura al vertice', 'gruppo di Weyl'], figs: { 5: '4-simplesso rettificato (10)', 6: '5-demicubo (16)', 7: 'il politopo con 27 vertici', 8: 'il politopo con 56 vertici' },
    inH: 'E8 nelle forme che abbiamo già', inPick: 'Scegli il membro della serie', inCap: n => `Ancora il trucco 2D, ora il piano di Coxeter: una rotazione di 1/${G.coxeter[n].h} (il numero di Coxeter) porta le ${R[n].roots} radici su ${n} anelli di ${G.coxeter[n].h}. In generale radici = rango × numero di Coxeter: 72 = 6 × 12, 126 = 7 × 18, 240 = 8 × 30. Blu = spigoli dell’ortoplesso (lunghezza al quadrato 2). Ambra = vertici del demicubo (lunghezza al quadrato 2 a n = 8).`,
    split: { 8: `E8 nelle coordinate di 8 assi: ${X['8'].orthoplex_edges} spigoli dell’8-ortoplesso (±eᵢ ± eⱼ) e ${X['8'].demicube_vertices} vertici dell’8-demicubo (½(±1, …, ±1) con un numero pari di segni meno). In tutto 240.`,
      7: `E7 è la parte perpendicolare alla radice più alta: ${X['7'].orthoplex_edges_inside_first_6_axes} spigoli del 6-ortoplesso, ${X['7'].other_orthoplex_edges} spigoli in più e ${X['7'].demicube_vertices} vertici dell’8-demicubo. 126 in tutto. I 64 sono 32 schemi di segni su sei assi, ciascuno due volte, con gli ultimi due segni opposti; 64 = 2⁶ è il numero di sfaccettature del 6-ortoplesso, ma è solo una corrispondenza di conteggi.`,
      6: `E6 è ancora più piccola: ${X['6'].orthoplex_edges_inside_first_5_axes} spigoli del 5-ortoplesso e ${X['6'].demicube_vertices} vertici, che sono esattamente i 2⁵ schemi di segni su cinque assi, uno per ogni sfaccettatura del 5-ortoplesso. 72 in tutto.` },
    glueH: 'Perché 8: la lunghezza dei vertici',
    glue: 'I 112 spigoli hanno lunghezza al quadrato 2. I vertici del demicubo ½(±1, …, ±1) hanno lunghezza al quadrato n/4, quindi sono radici solo per n = 8. Il reticolo fatto di spigoli e vertici ha prodotti scalari interi quando 4 divide n, e solo norme pari quando 8 divide n.',
    glueCols: ['n', 'lunghezza² dei vertici', 'prodotti scalari interi', 'tutte le norme pari', 'vettori più corti'], yes: 'sì', no: 'no',
    glueNote: ['n = 4: lunghezza 1. I vertici sono la triality delle tre 16-celle del passo 1: lo stesso 8 visto in tre modi.', 'n = 8: lunghezza 2. I vertici diventano radici: E8, il reticolo pari unimodulare di rango 8.', 'n = 12: lunghezza 3. Reticolo dispari.', 'n = 16: lunghezza 4. Pari, ma i vertici non aggiungono radici; il rango 16 ha E8 ⊕ E8 (E8 due volte) e D₁₆⁺ (solo spigoli).'],
    glueTail: 'I reticoli pari unimodulari esistono solo in ranghi divisibili per 8. È un fatto standard.',
    brH: 'E8 contiene E6 × A2: dove compare un 3', br: `Dentro E8 le radici di E6 hanno un partner A2. Ordinando le 240 radici per il loro peso A2 si ottiene ${B.E6_roots} + ${B.A2_roots} + ${B.classes_of_27} × 27: le radici di E6, le radici di A2, e sei classi di 27 radici, tre di un tipo (27) e tre dell’altro (27̄). Il numero di copie del 27 è la dimensione della rappresentazione più piccola di A2. Visto da un vertice, un 27 è 1 + 16 + 10, e i 16 vicini formano un 5-demicubo (passo 2). Tutto questo è verificato come conteggi. Se questo 3 sia le tre generazioni del modello è aperto: il test delle famiglie non ha trovato alcun 3 dove abbiamo guardato (il toro di Witt e il parallelo Z₂), e niente qui sceglie questo A2.`,
    gbH: 'Che cosa E8 restituisce alle altre viste',
    gb: [
      [['checked'], 'Vista demicubo. L’8-demicubo è la metà di E8 con 128 vertici, e n = 8 è l’unico n in cui i vertici sono radici. Il demicubo del passo 2 è anche il primo politopo di Gosset.'],
      [['standard', 'checked'], 'Vista ortoplesso e Fock. I 112 spigoli sono le radici di so(16): 112 + 8 = 120 = C(16, 2) bivettori dei 16 generatori nulli del nodo 16 di Genesis, dove Cl(8,8) = M₂₅₆(ℝ). I 128 vertici sono una metà dello spazio spinoriale di dimensione 256. Quindi 248 = 120 + 128. L’aritmetica è verificata; leggere le radici come Genesis è nostro.'],
      [['checked', 'open'], 'Vista Furey. Il 3 qui sopra è un fatto di ramificazione di E8, come le tre 16-celle a n = 4 (Q₈ di indice 3): un 3 dentro una forma. Nessuno dei due è stato legato al modello, e non è stato mostrato che il modello contenga questo A2.'],
      [['open'], 'Vista Maxwell. Non torna nulla. F è un bivettore di quattro generatori ed E8 ne richiede sedici.']
    ],
    bdH: 'Il budget finito: che cosa è verificato e che cosa è una somiglianza',
    bd: 'I tuoi tre controlli valgono come aritmetica: da E3 a E8 sono definite positive con determinanti 6, 5, 4, 3, 2, 1; E9 è singolare e affine; E10 è indefinita. Il budget nel nostro quadro è un’altra affermazione. Il periodo 8 delle celle di Clifford si legge dalla tabella standard dei tipi (non è derivato dagli assiomi), e Cl(n+4,n+4) = Cl(n,n) ⊗ M₁₆(ℝ) ripete le celle invece di fermarle. L’elenco di Gosset si ferma per una ragione che non nomina le algebre di Clifford, e ciò che viene dopo E8 non è un muro: E9 è E8 come algebra dei loop ed E10 è iperbolica. Due cose sono comuni: il numero 8, raggiunto con meccanismi che sembrano diversi, e la lunghezza n/4 dei vertici, che rende un reticolo pari esattamente quando 8 divide n. Se quel mod 8 e il mod 8 di Clifford siano un solo fatto è aperto. Per ora è una somiglianza.',
    limits: 'La corrispondenza fra 8 e 8 non è una derivazione. La divisione 112 + 128 è un’affermazione sulle coordinate; leggerla come ortoplesso e demicubo del nostro quadro è nostro.',
    dlH: 'Verificalo tu', dlText: 'Un file Python autonomo (solo libreria standard). Ricostruisce determinanti e segni di Cartan, le radici per riflessione, i politopi di Gosset per orbita, le figure al vertice per isomorfismo di grafi, le coordinate di E8, le classi E6 × A2 e il piano di Coxeter, e li confronta con i dati di questa pagina.', dlPy: 'Scarica gosset_selfcheck.py', dlJson: 'Scarica gosset.json', dlCmd: 'python3 gosset_selfcheck.py --compare gosset.json'
  }
};
// The Young Learner reads step 3 in plain words: a family of shapes, its arrows (the roots), the fork with three arms, the inside-out cube and the half cube
// of steps 1 and 2. The formal tables, names and notes are in the fold "for older readers". Every number is read from gossetData.js.
const arrows = n => R[n].roots == null ? null : R[n].roots;
// the three fractions of the fork of member n, from its arms in the data: "1/2 + 1/3 + 1/5" (digits only, no letters)
const frac = n => R[n].arms.map(a => `1/${a}`).join(' + ');
COPY.en.yl = {
  title: 'A famous family of shapes: E6, E7, E8, and where it stops',
  intro: 'Each member of the family is a set of arrows from the centre, all of the same length, and each comes with its own shape. For E8 the tips of the 240 arrows are exactly the 240 corners of its shape.',
  tableH: 'The family, member by member', pick: 'Pick a member', cols: ['n', 'arms of the fork', 'arrows', 'corners of its shape'], infinite: 'never run out',
  detail: n => n <= 5 ? `E${n} is one of the small members of the family, with ${arrows(n)} arrows.`
    : n <= 8 ? `E${n} has ${arrows(n)} arrows. Its shape has ${P[n].vertices} corners and ${fmt(P[n].edges)} edges, with ${P[n].degree} edges at every corner.`
    : n === 9 ? 'E9 is E8 made endless: there is one special direction that you can add to any arrow to get another arrow, so the arrows never run out.'
    : 'E10 has one direction of the opposite sign, and its arrows never run out either.',
  armsH: 'Why the list stops: three fractions',
  arms: `Each member is drawn as a fork of dots with three arms, the centre counted in each arm: ${R[8].arms[0]} dots, ${R[8].arms[1]} dots, and a third arm that is 3 dots shorter than the number of directions. Add one over the length of each arm. While the sum is bigger than 1, the arrows are finite: with 8 directions the third arm has ${R[8].arms[2]} dots, and ${frac(8)} = ${R[8].arm_sum}. With 9 directions it has ${R[9].arms[2]} dots and the sum is exactly ${R[9].arm_sum} (${frac(9)}), and from there on the arrows never run out. This is checked for every row, and it uses nothing about our algebra.`,
  nestH: 'The shapes nest inside each other',
  nest: 'Stand on one corner of the 27-corner shape: its 16 neighbours form the half cube in 5 directions (step 2). Stand on a corner of the 56-corner shape: its 27 neighbours form the 27-corner shape. On the 240-corner shape, the 56 neighbours of a corner form the 56-corner shape. So step 2 is the first rung of this ladder.',
  inH: 'E8 in the shapes we already have', inPick: 'Choose the member',
  inCap: n => `The ${R[n].roots} arrows of E${n} drawn flat, on ${n} rings of ${G.coxeter[n].h}: ${R[n].roots} = ${n} × ${G.coxeter[n].h}. Blue: edges of the inside-out cube (step 1). Amber: corners of the half cube (step 2).`,
  split: { 8: `E8: ${X['8'].orthoplex_edges} blue + ${X['8'].demicube_vertices} amber = 240.`, 7: `E7: ${X['7'].orthoplex_edges_inside_first_6_axes + X['7'].other_orthoplex_edges} blue + ${X['7'].demicube_vertices} amber = 126.`, 6: `E6: ${X['6'].orthoplex_edges_inside_first_5_axes} blue + ${X['6'].demicube_vertices} amber = 72.` },
  glueH: 'Why 8?',
  glue: 'The arrows from step 1 all have the same length. The corners of the half cube have a length that grows with the number of directions, and it equals the arrows’ length only in 8 directions. That is why the two shapes join only there.',
  brH: 'A 3 inside E8',
  br: `Inside E8 the 240 arrows sort into ${B.E6_roots} + ${B.A2_roots} + ${B.classes_of_27} × 27: the arrows of E6, ${B.A2_roots} more, and six groups of 27, three of one kind and three of the other. So a 3 appears. Is this 3 the three families of particles? That is open: the family test found no 3 where we looked, and nothing here picks out this 3.`,
  gbH: 'What E8 gives back to the other views',
  gb: [
    [['checked'], 'Half cube: the 128 corners of the half cube in 8 directions are half of E8, and 8 is the only number of directions where they are arrows. The half cube of step 2 is also the first shape of this family.'],
    [['standard', 'checked'], 'Inside-out cube: its 112 edges and 8 more make 120, the number of ways to pick 2 of 16 directions; 120 + 128 = 248, the size of E8. The arithmetic is checked; reading it in our frame is an idea we try, not a result.'],
    [['checked', 'open'], 'Particles: the 3 above is a fact about E8, like the three copies in 4 directions in step 1: a 3 inside a shape. Neither has been tied to the particle model.'],
    [['open'], 'Maxwell: nothing comes back. The field lives in 4 directions, and E8 needs 16.']
  ],
  bdH: 'The number 8, twice',
  bd: 'The number 8 shows up twice: the kinds of number grid repeat every 8 steps (the same kinds again, only bigger), and the list of finite members of this family ends at E8 (after it, the arrows never run out). Is that one fact, or two? That is open. For now it is a resemblance, not a result.',
  limits: 'The match between 8 and 8 is not a proof. Splitting 240 into 112 + 128 is a fact about coordinates; reading it as the two shapes of steps 1 and 2 is an idea we try.'
};
COPY.it.yl = {
  title: 'Una famosa famiglia di forme: E6, E7, E8, e dove si ferma',
  intro: 'Ogni membro della famiglia è un insieme di frecce che partono dal centro, tutte della stessa lunghezza, e ciascuno ha la sua forma. Per E8 le punte delle 240 frecce sono esattamente i 240 vertici della sua forma.',
  tableH: 'La famiglia, un membro alla volta', pick: 'Scegli un membro', cols: ['n', 'bracci della forcella', 'frecce', 'vertici della sua forma'], infinite: 'non finiscono mai',
  detail: n => n <= 5 ? `E${n} è uno dei membri piccoli della famiglia, con ${arrows(n)} frecce.`
    : n <= 8 ? `E${n} ha ${arrows(n)} frecce. La sua forma ha ${P[n].vertices} vertici e ${fmt(P[n].edges)} spigoli, con ${P[n].degree} spigoli in ogni vertice.`
    : n === 9 ? 'E9 è E8 reso senza fine: c’è una direzione speciale che puoi sommare a ogni freccia per avere un’altra freccia, quindi le frecce non finiscono mai.'
    : 'E10 ha una direzione di segno opposto, e anche le sue frecce non finiscono mai.',
  armsH: 'Perché l’elenco si ferma: tre frazioni',
  arms: `Ogni membro si disegna come una forcella di punti con tre bracci, contando il centro in ogni braccio: ${R[8].arms[0]} punti, ${R[8].arms[1]} punti, e un terzo braccio che ha 3 punti in meno del numero di direzioni. Somma uno diviso la lunghezza di ogni braccio. Finché la somma è più di 1, le frecce sono finite: con 8 direzioni il terzo braccio ha ${R[8].arms[2]} punti, e ${frac(8)} = ${R[8].arm_sum}. Con 9 direzioni ne ha ${R[9].arms[2]} e la somma è esattamente ${R[9].arm_sum} (${frac(9)}), e da lì in poi le frecce non finiscono mai. È verificato per ogni riga, e non usa niente della nostra algebra.`,
  nestH: 'Le forme stanno una dentro l’altra',
  nest: 'Mettiti su un vertice della forma con 27 vertici: i suoi 16 vicini formano il mezzo cubo in 5 direzioni (passo 2). Mettiti su un vertice della forma con 56 vertici: i suoi 27 vicini formano la forma con 27 vertici. Nella forma con 240 vertici, i 56 vicini di un vertice formano la forma con 56. Quindi il passo 2 è il primo gradino di questa scala.',
  inH: 'E8 nelle forme che abbiamo già', inPick: 'Scegli il membro',
  inCap: n => `Le ${R[n].roots} frecce di E${n} disegnate in piano, su ${n} anelli da ${G.coxeter[n].h}: ${R[n].roots} = ${n} × ${G.coxeter[n].h}. Blu: spigoli del cubo rovesciato (passo 1). Ambra: vertici del mezzo cubo (passo 2).`,
  split: { 8: `E8: ${X['8'].orthoplex_edges} blu + ${X['8'].demicube_vertices} ambra = 240.`, 7: `E7: ${X['7'].orthoplex_edges_inside_first_6_axes + X['7'].other_orthoplex_edges} blu + ${X['7'].demicube_vertices} ambra = 126.`, 6: `E6: ${X['6'].orthoplex_edges_inside_first_5_axes} blu + ${X['6'].demicube_vertices} ambra = 72.` },
  glueH: 'Perché 8?',
  glue: 'Le frecce del passo 1 hanno tutte la stessa lunghezza. I vertici del mezzo cubo hanno una lunghezza che cresce con il numero di direzioni, e diventa uguale a quella delle frecce solo in 8 direzioni. Ecco perché le due forme si uniscono solo lì.',
  brH: 'Un 3 dentro E8',
  br: `Dentro E8 le 240 frecce si dividono in ${B.E6_roots} + ${B.A2_roots} + ${B.classes_of_27} × 27: le frecce di E6, altre ${B.A2_roots}, e sei gruppi da 27, tre di un tipo e tre dell’altro. Così compare un 3. Questo 3 sono le tre famiglie di particelle? È aperto: la prova di famiglia non ha trovato nessun 3 dove abbiamo guardato, e niente qui sceglie questo 3.`,
  gbH: 'Che cosa E8 restituisce alle altre viste',
  gb: [
    [['checked'], 'Mezzo cubo: i 128 vertici del mezzo cubo in 8 direzioni sono metà di E8, e 8 è l’unico numero di direzioni in cui sono frecce. Il mezzo cubo del passo 2 è anche la prima forma di questa famiglia.'],
    [['standard', 'checked'], 'Cubo rovesciato: i suoi 112 spigoli più altri 8 fanno 120, il numero di modi di scegliere 2 direzioni su 16; 120 + 128 = 248, la grandezza di E8. L’aritmetica è verificata; leggerla nel nostro quadro è un’idea che proviamo, non un risultato.'],
    [['checked', 'open'], 'Particelle: il 3 qui sopra è un fatto di E8, come le tre copie in 4 direzioni del passo 1: un 3 dentro una forma. Nessuno dei due è stato legato al modello delle particelle.'],
    [['open'], 'Maxwell: non torna nulla. Il campo vive in 4 direzioni, ed E8 ne richiede 16.']
  ],
  bdH: 'Il numero 8, due volte',
  bd: 'Il numero 8 compare due volte: i tipi di griglia di numeri si ripetono ogni 8 passi (gli stessi tipi di nuovo, solo più grandi), e l’elenco dei membri finiti di questa famiglia termina con E8 (dopo, le frecce non finiscono mai). È un fatto solo, o due? È aperto. Per ora è una somiglianza, non un risultato.',
  limits: 'La corrispondenza fra 8 e 8 non è una dimostrazione. Dividere 240 in 112 + 128 è un fatto sulle coordinate; leggerlo come le due forme dei passi 1 e 2 è un’idea che proviamo.'
};
export { fmt, inertia, roots };
export default COPY;
