# Building and testing the package

This package is an **update over your own repository**. It is the whole app tree (pages, data, check scripts, tests, the two chat routes and the contact route, the speed test), but it does not contain what your repository already has (the host files below).

## Applying it, in this order
1. **Extract the archive into an empty folder next to your repository** (the archive is a flat tree with no top folder), not over it: a flat extraction would replace your `package.json`, and every other file with the same name, before you could compare them.
2. **Compare first the files your repository may hold its own version of**: `package.json` (do not replace it: merge `license`, `scripts` and the dependency lists into yours), `build.sh` (this one bundles `harness/harness_app.jsx` for the tests; keep your own build script if you have one, under its own name), `LICENSE` and `NOTICE` (the licence of this package), and the folders `api/` and `lib/` (the routes and their helpers: copying adds and replaces files in them, so keep any route or helper of yours that the package does not have).
3. **Then copy the rest over your repository** (everything but `package.json`), and build and test from the repository folder (below).
4. **Do not commit what the build and the tests make**: add `dist/`, `dist_real/` and `test_logs/` to your `.gitignore` (made by `sh build.sh`, `sh build.sh --real` and `sh run_tests.sh`).

## Host files (yours, not shipped)
`App.jsx` imports two components, `SimplexCanvas.jsx` and `GenesisCanvas.jsx`, which draw the rule and atlas pictures with `three`; they import `canvasFacts.js`. The page also uses your **global stylesheet** (the pages are styled by it plus the small style blocks inside the components) and your own entry file. None of these is in the package. `sh build.sh` stops with a message naming the ones that are missing; `test_package.mjs` checks that these are the only imports that leave the package.
In the build used for the tests the entry is `harness/harness_app.jsx` (it mounts `<App/>`); in your repository your own entry replaces it.

## Dependencies
Tested with exactly: `react` 19.2.8, `react-dom` 19.2.8, `katex` 0.16.47 (dependencies); `esbuild` 0.28.2, `playwright` 1.56.0 (development); Node >= 20 (the contact route needs Node 19 or later, or an edge runtime); python3 for the check scripts (standard library; a few use numpy and say so); `three` in `node_modules` for the two canvases (the version of your repository; here a git checkout was used).
`react-katex`, `streamdown` and `@streamdown/math` render the chat answers. They are **peer dependencies with no version**: your repository provides them, and **they could not be installed where this package was made** (the npm registry refused). The browser tests therefore ran against the stand-ins in `harness/stubs` (they print the TeX source and the Markdown as text). Pin the versions you use, and run `node test_real_renderers_ui.mjs` once they are installed (see below). If your repository already has a `package.json`, do not overwrite it: merge `license`, `scripts` and the dependency lists into it (step 2 above).

## Build and test
    npm install            # or your own way of getting node_modules; playwright also needs its browser: npx playwright install chromium
    sh build.sh            # dist/app.js and dist/app.html (stand-ins for react-katex, streamdown, @streamdown/math)
    sh run_tests.sh        # every test, one line each; --data or --browser for one group; exit 1 if anything fails
`sh build.sh --real` builds without the stand-ins into `dist_real/` (needs the three packages); `ATLAS_DIST=<folder>` points the browser tests at another build. Tests are found by name (`test_*.mjs`, `layout_check.mjs`), logs go to `test_logs/`; a test that runs longer than `TEST_TIMEOUT` seconds (default 1500) is reported as `FAIL ... timeout after <N>s`.
**Run the tests from the package folder** (`sh run_tests.sh` moves there itself, from wherever it is started). Each test also moves to the package folder before it reads a file, so `node <package>/test_spring.mjs` works from another folder too; the check scripts in `selfcheck/` and the `regen_*.sh` scripts find their files themselves.

Which tests need what (derived by running them without `node_modules`; this replaces the older sentences that said two or five suites needed more than node):
- **Only node** (plus python3 for `test_null`, `test_pgadyn`, `test_spring` and `test_regen`, which run the check scripts, and `sh` for `test_regen`): the other data tests, among them `test_routes`, `test_persona`, `test_contact`, `test_contact_mutation`, `test_license`, `test_package`, `test_product`.
- **node and `esbuild`**: `test_dictionary`, `test_maxwell`, `test_threegen` (they bundle a section's `.jsx` to read its plain-language copy).
- **node and `katex`**: `test_findings`, `test_forque`, `test_spin` (they compile the page's LaTeX).
- **A browser (`playwright`) and the build in `dist/`**: all `test_*_ui.mjs`, `layout_check.mjs`, `test_i18n_audit.mjs`, `test_canvas_ui.mjs`; `test_label_bench.mjs` needs playwright but builds its own page.
- `test_real_renderers_ui.mjs` needs the three real packages and exits 77 (skipped) without them. `test_canvas_ui.mjs` exits 77 only if the browser cannot create a WebGL context.

## What the tests do not cover
- **The real chat renderer** (react-katex, streamdown, @streamdown/math) has not been run: no test here saw a formula typeset by the real package or a link blocked by the real `harden` setting. `test_real_renderers_ui.mjs` is written for it and has only been run in its skip path and in its plumbing mode (`RR_MECHANICS=1`); expect to adjust an assertion to what your installed version does.
- **Your global stylesheet and your entry file**: the layout tests ran on a build without your stylesheet.
- **The two serverless routes against the real model services and the real form service**: they are tested against fakes. See `README_update_routes.md` and `README_update_contact.md` for what to set (environment variables) and what to check by hand.
- **Timings** are machine-dependent; `sh selfcheck/regen_bench.sh` re-times them on your machine and regenerates everything that quotes them.

## Scripts that run on their own
- `selfcheck/*.py`, `run_all.py` (with `model.py`), `family_test.py`, `peirce_test.py`, `witt_test.py`, `z2_test.py`: the exact check scripts of the Furey and dictionary pages; `python3 run_all.py` runs the asserting construction check; the page-specific scripts have `--write` and `--compare` (see their first lines).
- `orthoplex/orthoplex_check.py` (standard library only), `orthoplex/ladder_check.py`, `orthoplex/equations_check.py` (these two need numpy; the three write their json files beside them; run them inside `orthoplex/`: `orthoplex_check.py` and `equations_check.py` use paths relative to that folder) and `orthoplex/draw.py`, `draw_high.py`, `draw_ladder.py` (drawings, matplotlib): the orthoplex checks of the shapes page.
- `selfcheck/regen_null.sh`, `regen_spin.sh`, `regen_spring.sh`, `regen_pgadyn.sh`, `regen_matrixrep.sh`, `regen_bench.sh`: rebuild a check's json and the data modules the app reads from it; each stops at the first error, writes only inside the package, and leaves the stored json as it was when its check fails (`test_regen.mjs` breaks `null_selfcheck.py` in a copy to check this for `regen_null.sh`).
- `build_label_bench.mjs` builds `label_bench.html` from `label_bench_src/` (the page is deterministic; its kernel fingerprint is checked by `test_label_bench.mjs`).

## Licence
PolyForm Noncommercial 1.0.0: `LICENSE` and `NOTICE`. Every source file and script carries the three-line header; the three kernel files of the speed test do not, on purpose (see `NOTICE`).
