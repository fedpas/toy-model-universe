// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The package says what it holds, in the present tense: no list of errata, no corrected or withdrawn sentence, no "as first written", no note of an earlier version or round, in any text a reader sees or a script prints.
// Four scopes are scanned, all by the same list of forbidden phrases (P1 to P9 below):
//   A  every English and Italian text leaf of the app: the exports of every module of the package folder and of lib/ (copy, data, claims, matrix, notes, the persona's prompt), every line of the components (*.jsx), the text fields of claimsLocators*.json,
//      and the markers of a retired section (class names, anchors, ids) in the app's sources
//   B  the six shipped reports: visible text and the title, aria-label, alt and data-tip attributes of reports/html/*.html (script and style bodies left out), and the text fields of reports/translation_matrix.json
//   C  the shipped scripts and documents: every line of the check scripts (selfcheck/**, researchers_checks/**, replication/**, reports/** builders, content modules and report scripts), of the READMEs, of NOTICE and of the notes of the release
//      (the analyses of reports/analyses/, its markdown sources and pages, are the one documented exemption: generated reports are shipped as generated)
//   D  the comments of the app's sources (js, jsx, api, lib): the narrow list P1 to P3, the three strongest phrases of P4, and the words of a version (v7 to v10, audit round, a release number as a time word; they ship inside the package; they are not shown in the app)
// P8 is the working of the package told (lane, session, relabelled, reworded, "now proved", a Versions heading); P9 is a release number or a date used as a time word ("up to 1.2.0", "new in 1.1.0", a bold release number that opens a list item, an ISO date, a date of 2026 other than the date of issue). A licence number, a pinned dependency, a section number of a paper, a machine stamp of a stored run (K16) and the date of a cited source are not history.
// Left out on purpose: test_*.mjs, test_*.py, mutate_*.py and layout_check.mjs. A test may quote an old wrong sentence in a FORBIDDEN list: that is how it pins the right one.
// The test also checks itself: one planted phrase per group must be caught, text that only says what is legitimately kept (a negative control, a numeric error bound, a user-facing error message) must pass, every entry of the
// allow-list must clear at least one leaf that a forbidden phrase flags (an entry that clears nothing fails: the list cannot rot), and no scope may be empty (a moved folder cannot silently leave it).
// Run: node test_no_history.mjs   [--list] prints every flagged leaf   [--root <folder>] scans another copy of the package   [--sample "<text>"] says what the scan makes of one text   [--json] prints every flagged leaf (file, place, phrase, text) as JSON
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
import { PKG } from './paths.mjs';
const argv = process.argv.slice(2), flag = f => argv.includes(f), opt = f => { const i = argv.indexOf(f); return i >= 0 ? argv[i + 1] : null; };
const ROOT = opt('--root') ? path.resolve(opt('--root')) : PKG;
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };

// ---------------------------------------------------------------- the forbidden phrases (case-insensitive, English; the Italian slots hold English too, and P7 adds the Italian forms)
const P = {
  P1: [/\berrat(a|um)\b/i, /\bE-\d{3}\b/, /\bfinding E-/i],                                                      // erratum ids
  P2: [/\bcorrected (on|in|after|before|by|6|5)\b/i, /\bcorrections? (of|applied|block|section)\b/i, /\bnow corrected\b/i, /\bwas corrected\b/i, /\bcorrected after a check\b/i, /\bcorrigend/i, /\bthe correction of F\d+/i, /\bsee the corrections\b/i],   // a correction of ours
  P3: [/\bwithdrawn\b/i, /\bretract(ed|ion)\b/i, /\bretired\b/i, /\bstruck( through| out)?\b/i, /\bsuperseded\b/i, /\bobsolete\b/i, /\bstale\b/i, /\bdiscarded wording\b/i],        // retired, struck
  P4: [/\b(was|were|is|are) (wrong|too strong|too weak|a mistake|mistaken)\b(?! (for|in|when|if|only|here|on)\b)/i, /\b(was|were|is|are) false\b(?! (for|in|when|if|only|here|on)\b)/, /\bas first (written|stated|printed|said)\b/i, /\bfirst (guess|draft|version|reading|explanation|wording)\b/i,
       /\bour (own )?(first|earlier|previous|old) (guess|reading|explanation|claim|sentence|wording|version|statement)\b/i, /\b(earlier|previous|former|old) (draft|version|wording|claim|statement|sentence|reading|analysis|release|report)s?\b/i,
       /\b(we|it) (once|previously|used to|had) (said|thought|claimed|believed|written|read)\b/i, /\bused to (say|read|claim|be called)\b/i, /\bformerly\b/i, /\bpreviously\b/i, /\bno longer (said|claimed|true|a mistake|stated)\b/i, /\bto say what we said\b/i],   // "was wrong", "first written"
  P5: [/\boverstate[sd]?\b/i, /\boverclaim/i, /\btoo strong\b/i, /\bwe (had )?misread\b/i, /\bwas (misread|misstated)\b/i, /\bour (own )?(error|errors|slip|slips|mistake|mistakes)\b/i, /\bmisinterpret/i],      // over- and under-statement narrative
  P6: [/\bv(7|8|9)(\.\d+)?\b/i, /\bv10(\.[01])?\b/i, /\bv1\.[01]\b/i, /\baudit round( [12])?\b/i, /\bround (1|2|two|one)\b/i, /\bsecond (round|pass)\b/i, /\b(?!7 October 2026\b)(?:[1-9]|[12]\d|3[01]) October 2026\b/i, /\bchangelog\b/i, /\bsince the last (report|release|version)\b/i],   // version, date, round
  P8: [/\bREADME_update_/i, /\blane [A-D]\b/i, /\brelabell?ed from\b/i, /\boriginal (label|wording|sentence|text|claim|name)\b/i, /\bfirst assumed\b/i, /\bre-?worded\b/i, /\bwe (have |had )?(replaced|renamed|rewrote|reworded)\b/i, /\bhad been\b/i,
       /\bhad to be (pulled|taken|split|set|separated|fixed|changed|replaced|rewritten)\b/i, /\bfound (it |them |this )?late\b/i, /\bmet on the way\b/i, /\bnow (proved|proven|exists?|stands?|holds?|states|covers|includes?|carries|stated|written|shown|listed|given|a theorem|T\d+)\b/i, /\band now\b/i,
       /\(corrections?\b/i, /\bafter an? (noted |small |one-line |written-down )?correction\b/i, /\ba correction we (wrote|noted|made)\b/i, /\bthe new (widget|report|reports|script|scripts|tab|tabs|chapter|chapters)\b/i, /\b(older|previously known as|formerly called) (word|wording|term|name|text|sentence|label)\b/i,
       /\bin (this|that|the|a) (working )?session\b/i, /\b(this|the) (line|page|sentence|paragraph|text|README|brief|row) (said|called|read|claimed|stated|gave)\b/i, /\bfound by an independent\b/i, /\((first|second|third|fourth|fifth|sixth|seventh) note\b/i,
       /\b(of|saw|see|under|uses?|used) version [1-9]\b(?![.\d])|\bversion [1-9] (of|gave|fixes)\b|\(version [1-9]:/i, /^#{1,6}\s*(versions?|changelog|history|what changed)\s*$/i],   // the working of the package, told: lane, session, relabelled, reworded, "now proved", "Versions"
  P9: [/\b(up to|until|since|predates?|before|prior to|new in|added in|introduced in|fixed in|changed in|(?:as )?it did in|unchanged from) v?\d+\.\d+\.\d+\b/i, /^\s*[*-]\s*\*\*\d+\.\d+\.\d+\*\*/, /\bv1\.\d+/i, /\bv1[12345]\.\d+/i, /\b(in|since|new in|added in|changed in|of|for|after|before|from|than) v1[12345]\b/i,
       /\b20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b(?<!2026-10-07)/, /\b(?!7 October 2026\b)(?:[1-9]|[12]\d|3[01]) (January|February|March|April|May|June|July|August|September|October|November|December) 2026\b/i, /\b(January|February|March|April|May|June|July|August|September|October|November|December) (?:[1-9]|[12]\d|3[01]),? 2026\b/i],   // a release number as a time word ("up to 1.2.0", "new in 1.1.0", "**1.2.2** (fingerprint"), an ISO date, a date of 2026 other than the date of issue
  P7: [/\berrata corrige\b/i, /\bcorrezion[ei] (del|di|applicat)/i, /\bprime (stesure|versioni|bozze)\b/i, /\bbozze? precedent\w*/i, /\bsbagliat[aeio]\b(?! per\b)/i, /\britirat[aeio]\b/i, /\bbarrat[aeio]\b/i, /\bin passato\b/i, /(^|[.;:!?]\s+|,\s+)un tempo\b(?! così)/i, /\bavevamo (detto|pensato)\b/i, /\brietichettat[aeio]\b/i, /\betichetta originale\b/i, /\briformulat[aeio]\b/i, /\bcome supposto\b/i, /\bdopo una correzione\b/i, /\bora (dimostrat[aeio]|esiste)\b/i],   // Italian
};
// P6 lets one date stand: 7 October 2026, the date of issue of the package (the reports and the release notes carry it); the date of a fix is what it forbids.
// P1 to P3 (without "stale" and "obsolete", which a comment on a design may use) and the three strongest forms of P4 are the narrow list for comments (scope D)
const NARROW = [...P.P1, ...P.P2, ...P.P3.filter(re => !/stale|obsolete/.test(re.source)), ...P.P4.slice(0, 3),
  /\bv(7|8|9|10)(\.\d+)?\b/i, /\baudit round( [12])?\b/i, /\bREADME_update_/i, /\blane [A-D]\b/i, P.P9[0], P.P9[1], /\b[A-Za-z]+ \(\d+\.\d+\.\d+\)/];   // and the version words, which a comment of the sources must not carry either
// markers of the retired sections: class names, anchors and ids (scopes A and B, raw source)
const MARKERS = [/\brs-wrong\b/, /\.?cat-corr\b/, /\.?bz-corr\b/, /\.?sc-corr\b/, /\bcat-corrections\b/, /\bbz-corrections\b/, /#researchers\/errata\b/, /\bid=["']corr2?["']/, /\bhref=["']#corr2?["']/, /<(s|del)[\s>]/i, /\bsortErrata\b/, /\bexport const ERRATA\b/];

// ---------------------------------------------------------------- the allow-list: what a forbidden phrase legitimately says. Each entry clears a leaf whose text matches `re` (and, when given, whose "file|path" matches `where`).
// Every entry must clear at least one flagged leaf, or the test fails and names it.
const ALLOW = [
  { id: 'K1 negative control', re: /\bwrong (version|sign|gamma|equation|network|signature|square|factor|ε|J|g)|\b(without|missing)\b[^.'"]{0,50}\bis wrong\b/i, why: 'a deliberately wrong variant that the check must reject ("three wrong versions fail")' },
  { id: 'K1 negative control (Italian)', re: /(?<=\b(versioni|versione|rete|equazion[ei]|segn[oi]|segnatura|quadrato|metrica|formula|potenza|schema)( [\wàèéìòù’']+){0,5} )sbagliat[aeio]\b/i, why: 'the same, in the Italian slots ("tre versioni sbagliate falliscono")' },
  { id: 'K7 our reading of a source', re: /\bmay be (a typo|our (error|mistakes?)|an error of ours)|\bany of these may be our error|\bwe suspect (that )?(we|a)\b[^.]{0,30}misread|\bthe mistake may be ours|\b(probably|which are) our slips\b/i, why: 'a present caveat: a printed line that differs from our exact check may be our reading' },
  { id: 'K7 printed line of a source (Italian)', re: /forma stampata[^.]{0,80}sbagliat[aeio]/i, why: 'a present remark on a printed line of a paper' },
  { id: 'K9 version of a cited paper', re: /Invariant Decomposition to Spinors[”"»]?\)?,? \(?v1\.1|\(v1\.1, 19 pag(es|ine)\)|2401\.01142 v1\.1/i, why: 'the arXiv version of the paper that the page checks' },
  { id: 'K9 slide of a cited lecture', re: /struck out in the second version|barrato nella seconda versione/i, why: 'what a slide of the lecture shows' },
  { id: 'K4 technical wording', re: /\bis corrected on load with replaceState\b/, where: /StoryShell\.jsx/, why: 'the address bar is normalised on load: a navigation rule, not a correction of ours' },
  { id: 'K10 assistant rule', re: /say plainly that an earlier claim \(including your own\) was wrong/i, where: /chatPersona|chatCore|persona/i, why: 'the rule the assistant follows when a reader shows a claim wrong' },
  { id: 'K12 conditional', re: /\b(would|will|could|can)\b[^\n]{0,260}\b(FAIL|fail)\b[^\n]{0,260}\b(were|was|is|are) (wrong|false)\b|\b(FAIL|fail)s? if\b[^\n]{0,260}\b(were|was|is|are) (wrong|false)\b/i, why: '"would fail if the step were wrong": what a check is for, not a history' },
  { id: 'K12 assertion message', re: /\bassert\b[^\n]{0,200}\b(is|are) false\b/, where: /\.py\|/, why: 'the message of a failed assertion' },
  { id: 'K16 stamp of a stored run', re: /\bnode v\d+\.\d+\.\d+[^;)]{0,60}?\b20\d\d-\d\d-\d\d\b|\b\d+ cores[^;)]{0,60}?\b20\d\d-\d\d-\d\d\b/, why: 'the machine stamp of a stored benchmark run (processor, node version, date)' },
  { id: 'K16 stamp of a stored run (data)', re: /^20\d\d-\d\d-\d\d$/, where: /^benchData\.js\|default\.machine\.date$/, why: 'the date field of the machine stamp of the stored benchmark run' },
  { id: 'K17 date of a cited arXiv version', re: /\barXiv:\d{4}\.\d{4,5}(<\/a>)? ?v\d[^;<]{0,40}\d{1,2} (January|February|March|April|May|June|July|August|September|October|November|December) 2026\b/, why: 'the date of the arXiv version of a cited paper (a fact of the source)' },
  { id: 'K18 name of the release', re: /\bv15\b/i, where: /^RELEASE_NOTES_v15\.md\|/, why: 'the notes of the release carry the release name' },
  { id: 'K20 dates of the ephemeris data', re: /\bdays from 2018-01-16 to 2026-10-09 by datetime\b/, where: /^selfcheck\/gravity\/g3_horizons_compare\.py\|/, why: 'the epoch of the page table (16 Jan 2018) and the first row of the Horizons tables (9 Oct 2026) in a check line of the G3 comparison: dates of the data, not of the package' },
  { id: 'K14 physical condition', re: /\bThe pull is too strong for this start\b/, where: /ChargesWidget\.jsx\|/, why: 'the message of the Charges widget when the run starts with a pull above what a steady orbit allows (ratio 1 or more): a condition of the run, not a remark on a wording' },
  { id: 'K19 MathML variant', re: /'double-struck'/, where: /^reports\/analyses\/make_analyses\.mjs\|/, why: 'the MathML name of the blackboard-bold letters (mathvariant="double-struck"), a key of the table of letters of the analyses generator, not a struck sentence' },
  { id: 'K15 Italian "un tempo"', re: /\bdue generatori, un tempo e uno spazio\b/, where: /MaxwellSection\.jsx\|/, why: '"un tempo" is the noun "a time": the starting point has two generators, one of time and one of space (not "once upon a time")' },
];

// ---------------------------------------------------------------- the leaves
const leaves = { A: [], B: [], C: [], D: [] };
const add = (scope, file, p, text, lang = '') => { if (typeof text === 'string' && text.trim()) leaves[scope].push({ scope, file, p, text, lang }); };
const rel = f => path.relative(ROOT, f).split(path.sep).join('/');
const walkDir = (d, skip) => !fs.existsSync(d) ? [] : fs.readdirSync(d, { withFileTypes: true }).flatMap(e => skip(e.name, path.join(d, e.name)) ? [] : e.isDirectory() ? walkDir(path.join(d, e.name), skip) : [path.join(d, e.name)]);
const SKIPDIR = n => ['node_modules', 'dist', 'dist_real', '.git', 'test_logs', '__pycache__', 'zips'].includes(n);
const isTest = f => /(^|\/)(test_[^/]*\.(mjs|py)|mutate_[^/]*\.py|layout_check\.mjs)$/.test(f);
const allFiles = walkDir(ROOT, SKIPDIR).map(rel);

// scope A: the exports of every module of the folder and of lib/ (string leaves of objects, arrays; the language is the nearest en/it key)
function walkValue(v, p, lang, file, seen) {
  if (v == null || typeof v === 'function') return;
  if (typeof v === 'string') { add('A', file, p, v, lang); return; }
  if (typeof v !== 'object' || seen.has(v)) return; seen.add(v);
  if (Array.isArray(v)) { v.forEach((x, i) => walkValue(x, p + '[' + i + ']', lang, file, seen)); return; }
  for (const k of Object.keys(v)) walkValue(v[k], p ? p + '.' + k : k, k === 'en' || k === 'EN' ? 'en' : k === 'it' || k === 'IT' ? 'it' : lang, file, seen);
}
const moduleFiles = allFiles.filter(f => /^(lib\/)?[^/]+\.js$/.test(f) && !/SelfcheckSource\.js$/.test(f) && !isTest(f));
const importErrors = [];
for (const f of moduleFiles) {
  let mod; try { mod = await import(pathToFileURL(path.join(ROOT, f)).href); } catch (e) { importErrors.push(f + ': ' + String(e.message).split('\n')[0]); continue; }
  const seen = new Set(); for (const k of Object.keys(mod)) walkValue(mod[k], k, '', f, seen);
}
// the persona's prompt is built by a function: the fixed core, and the tail of every reader
{ const f = 'lib/chatPersona.js';
  if (moduleFiles.includes(f)) { const M = await import(pathToFileURL(path.join(ROOT, f)).href); const lines = new Set();
    for (const l of M.buildSystemCore().split('\n')) lines.add(l);
    for (const spokenLang of M.LANGUAGES) for (const userProfile of M.PROFILES) for (const metricMode of M.METRICS) for (const isMatchMode of [false, true]) for (const l of M.buildSystemTail({ spokenLang, userProfile, metricMode, isMatchMode }).split('\n')) lines.add(l);
    [...lines].forEach((l, i) => add('A', f, 'prompt[' + i + ']', l, 'en')); } }
// the text fields of the claims locators
for (const f of allFiles.filter(f => /^claimsLocators[^/]*\.json$/.test(f))) {
  const J = JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  const go = (v, p) => { if (Array.isArray(v)) v.forEach((x, i) => go(x, p + '[' + i + ']')); else if (v && typeof v === 'object') for (const k of Object.keys(v)) { if (['standardRef', 'note', 'frozenText', 'checkedBy'].includes(k) && typeof v[k] === 'string') add('A', f, p + '.' + k, v[k]); else go(v[k], p + '.' + k); } };
  go(J, '');
}
// scope A, raw source: the markers of a retired section
const appSources = allFiles.filter(f => /\.(js|jsx|css|html)$/.test(f) && !isTest(f) && !/^(reports|replication|selfcheck|researchers_checks)\//.test(f) && !/SelfcheckSource\.js$/.test(f) && f !== 'claimsData.js');
const markerHits = [];
for (const f of appSources) { const t = fs.readFileSync(path.join(ROOT, f), 'utf8').split('\n'); t.forEach((l, i) => { for (const re of MARKERS) if (re.test(l)) markerHits.push({ scope: 'A', file: f, p: 'line ' + (i + 1), text: l.trim().slice(0, 160), marker: re.source }); }); }

// scope A, JSX text: the strings a component writes itself (messages, labels, Italian slots kept in a component) are read line by line; comment lines belong to scope D
for (const f of appSources.filter(f => /\.jsx$/.test(f))) fs.readFileSync(path.join(ROOT, f), 'utf8').split('\n').forEach((l, i) => { if (!/^\s*(\/\/|\/\*|\*)/.test(l)) add('A', f, 'line ' + (i + 1), l.trim()); });

// scope B: the shipped reports
const decode = s => s.replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/&#(\d+);/g, (_, d) => String.fromCodePoint(+d)).replace(/&amp;/g, '&');
function htmlLeaves(html) {
  const out = [];
  for (const m of html.matchAll(/\s(data-tip|title|aria-label|alt)=(?:"([^"]*)"|'([^']*)')/gi)) out.push(['@' + m[1].toLowerCase(), decode(m[2] ?? m[3])]);
  const body = html.replace(/<script\b[\s\S]*?<\/script>/gi, ' ').replace(/<style\b[\s\S]*?<\/style>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<\/?(?:br|p|li|div|h[1-6]|tr|td|th|section|ul|ol|table|figcaption|caption|blockquote|details|summary|pre|dd|dt|header|footer|nav|article|aside|figure|title)\b[^>]*>/gi, '\n').replace(/<[^>]+>/g, '');
  decode(body).split('\n').map(s => s.replace(/\s+/g, ' ').trim()).filter(Boolean).forEach((s, i) => out.push(['text[' + i + ']', s]));
  return out;
}
const htmlFiles = allFiles.filter(f => /^reports\/html\/[^/]+\.html$/.test(f));
const htmlMarkerHits = [];
for (const f of htmlFiles) {
  const html = fs.readFileSync(path.join(ROOT, f), 'utf8');
  for (const [p, t] of htmlLeaves(html)) add('B', f, p, t);
  html.split('\n').forEach((l, i) => { for (const re of MARKERS) if (re.test(l)) htmlMarkerHits.push({ scope: 'B', file: f, p: 'line ' + (i + 1), text: l.trim().slice(0, 160), marker: re.source }); });
}
if (allFiles.includes('reports/translation_matrix.json')) {
  const go = (v, p) => { if (typeof v === 'string') add('B', 'reports/translation_matrix.json', p, v); else if (Array.isArray(v)) v.forEach((x, i) => go(x, p + '[' + i + ']')); else if (v && typeof v === 'object') for (const k of Object.keys(v)) go(v[k], p ? p + '.' + k : k); };
  go(JSON.parse(fs.readFileSync(path.join(ROOT, 'reports/translation_matrix.json'), 'utf8')), '');
}

// scope C: shipped scripts and documents, line by line
// The one documented exemption: the analyses of reports/analyses/ (the markdown sources in src/ and the pages made from them) are not scanned, because generated reports
// are shipped as generated (reports/analyses/README.md); the list is read from reports/analyses/index.json, and check 1 holds it to exactly that registry's pages and sources.
// Their README, generator, style sheet and registry are scanned like every other file.
const AN_REG = path.join(ROOT, 'reports', 'analyses', 'index.json');
const AN_LIST = fs.existsSync(AN_REG) ? JSON.parse(fs.readFileSync(AN_REG, 'utf8')).analyses.flatMap(a => [a.html, ...a.source.map(s => s.file)]).map(f => 'reports/analyses/' + f) : [];
const EXEMPT = new Set(AN_LIST);
const C_EXT = /(\.(py|sh|md|mjs|cjs|txt)|(^|\/)NOTICE)$/;
const cFiles = allFiles.filter(f => C_EXT.test(f) && !isTest(f) && !EXEMPT.has(f) && !/^(replication\/runs|node_modules|harness\/stubs)\//.test(f) && !/(^|\/)(MANIFEST\.json)$/.test(f) && !/^reports\/(category|baez|schuller|hestenes|furey|pumplun)\/(digests|logs|txt)\//.test(f));
for (const f of cFiles) fs.readFileSync(path.join(ROOT, f), 'utf8').split('\n').forEach((l, i) => add('C', f, 'line ' + (i + 1), l));

// scope D: comments of the app's sources (js, jsx, api, lib): a line comment or the text of a block comment
const dFiles = allFiles.filter(f => /\.(js|jsx)$/.test(f) && !isTest(f) && !/^(reports|replication|selfcheck|researchers_checks)\//.test(f) && !/SelfcheckSource\.js$/.test(f) && !/^(claimsData|translationMatrixData)\.js$/.test(f));
for (const f of dFiles) { let inBlock = false;
  fs.readFileSync(path.join(ROOT, f), 'utf8').split('\n').forEach((l, i) => {
    let c = null;
    if (inBlock) { c = l; if (/\*\//.test(l)) inBlock = false; }
    else if (/^\s*\/\//.test(l)) c = l.replace(/^\s*\/\/+\s?/, '');
    else if (/^\s*\/\*/.test(l)) { c = l; if (!/\*\//.test(l)) inBlock = true; }
    else { const m = /(?:^|[;,)}\]\s])\/\/\s(.*)$/.exec(l); if (m && !/['"`][^'"`]*\/\/[^'"`]*['"`]/.test(l)) c = m[1]; }
    if (c != null) add('D', f, 'line ' + (i + 1), c);
  }); }

// ---------------------------------------------------------------- the scan
const spansOf = (text, re) => [...text.matchAll(new RegExp(re.source, re.flags.replace('g', '') + 'g'))].map(m => [m.index, m.index + m[0].length]);
const hitOf = (text, lists = Object.values(P).flat()) => { for (const re of lists) if (re.test(text)) return re; return null; };
// an allow-list entry clears a forbidden phrase only where its own match touches that phrase, one occurrence at a time (a leaf that says "may be our error" and also "erratum E-012" is still flagged)
const allowFor = (l, span) => ALLOW.find(a => (!a.where || a.where.test(l.file + '|' + l.p)) && spansOf(l.text, a.re).some(([x, y]) => x <= span[1] && span[0] <= y));
function judge(l, lists = Object.values(P).flat()) {                      // null: clean; { allow }: every forbidden phrase is cleared; { hit }: the first one that is not
  let first = null; const names = [];
  for (const re of lists) for (const span of spansOf(l.text, re)) { const a = allowFor(l, span); if (a) names.push(a.id); else if (!first) first = re; }
  return first ? { hit: first, allows: names } : names.length ? { allow: names[0], allows: names } : null;
}
function scan(list, lists) { const flagged = [], allowed = []; for (const l of list) { const j = judge(l, lists); if (!j) continue; if (j.hit) flagged.push({ ...l, hit: j.hit.source, allows: j.allows }); else allowed.push({ ...l, allow: j.allow, allows: j.allows }); } return { flagged, allowed }; }
const R = { A: scan(leaves.A), B: scan(leaves.B), C: scan(leaves.C), D: scan(leaves.D, NARROW) };
for (const l of [...R.A.flagged, ...R.B.flagged, ...R.C.flagged, ...R.D.flagged]) { const re = [...Object.values(P).flat(), ...NARROW].find(r => r.source === l.hit); l.m = re ? (l.text.match(re) || [''])[0] : ''; }
const flaggedAll = [...R.A.flagged, ...R.B.flagged, ...R.C.flagged, ...R.D.flagged, ...markerHits.map(m => ({ ...m, hit: 'marker ' + m.marker })), ...htmlMarkerHits.map(m => ({ ...m, hit: 'marker ' + m.marker }))];
const allowedAll = [...R.A.allowed, ...R.B.allowed, ...R.C.allowed, ...R.D.allowed];
const usedAllows = new Set([...R.A.flagged, ...R.B.flagged, ...R.C.flagged, ...R.D.flagged, ...allowedAll].flatMap(l => l.allows || []));      // an entry counts as live when it cleared a phrase anywhere

if (flag('--allowed')) { for (const l of allowedAll) console.log(`  ${l.scope} ${[...new Set(l.allows)].join('+')} | ${l.file} ${l.p} | ${Object.values(P).flat().filter(re => re.test(l.text)).map(re => '«' + l.text.match(re)[0] + '»').join('')} | ${l.text.replace(/\s+/g, ' ').slice(0, 100)}`); process.exit(0); }
if (flag('--json')) { console.log(JSON.stringify(flaggedAll.map(l => ({ scope: l.scope, file: l.file, p: l.p, hit: l.hit, m: l.m || '', text: l.text.replace(/\s+/g, ' ').slice(0, 220) })), null, 1)); process.exit(0); }
if (opt('--sample') != null) { const j = judge({ text: opt('--sample'), file: '', p: '' }); console.log(!j ? 'clean' : j.hit ? 'flagged by ' + j.hit.source : 'allowed by ' + j.allows.join(', ')); process.exit(0); }

// ---------------------------------------------------------------- the checks
// 1. the scopes are not empty (a folder that moved cannot silently leave the scan)
ok(importErrors.length === 0, 'every module of the folder and of lib/ imports in node: ' + importErrors.join(' | '));
ok(moduleFiles.length > 100 && leaves.A.length > 30000, `scope A reads the whole app: ${moduleFiles.length} modules, ${leaves.A.length} text leaves`);
ok(leaves.A.some(l => l.file === 'claimsData.js') && leaves.A.some(l => l.file === 'researchersData.js') && leaves.A.some(l => l.file === 'storyCopy.js') && leaves.A.some(l => l.file === 'lib/chatPersona.js' && /^prompt/.test(l.p)) && leaves.A.some(l => /^claimsLocators/.test(l.file)), 'scope A holds the claims, the researchers data, the story copy, the persona prompt and the claims locators');
ok(leaves.A.some(l => /^ChargesWidget\.jsx$/.test(l.file)) && leaves.A.some(l => /^MaxwellSection\.jsx$/.test(l.file)), 'scope A holds the lines of the components (*.jsx)');
ok(htmlFiles.length >= 3 && leaves.B.length > 1000, `scope B reads the shipped reports: ${htmlFiles.length} html pages, ${leaves.B.length} text leaves`);
ok(cFiles.some(f => /^selfcheck\/reports\/.+\.py$/.test(f)) && cFiles.some(f => /^researchers_checks\/check_T1\.py$/.test(f)) && cFiles.includes('README.md') && cFiles.includes('RELEASE_NOTES_v15.md') && cFiles.includes('BUILDING.md') && leaves.C.length > 20000, `scope C reads the scripts and documents: ${cFiles.length} files, ${leaves.C.length} lines`);
ok(dFiles.length > 100 && leaves.D.length > 1000, `scope D reads the comments of the sources: ${dFiles.length} files, ${leaves.D.length} comment lines`);
// the exemption is exactly the pages and markdown sources of reports/analyses/index.json: each is a file of the package, a page reports/analyses/<name>.html or a source
// reports/analyses/src/<name>.md; no file of any scope is left out for another reason; the rest of that folder (README, generator, style sheet) is scanned
{ const anFiles = allFiles.filter(f => f.startsWith('reports/analyses/')), scanned = new Set([...cFiles, ...htmlFiles, ...appSources, ...dFiles]);
  ok(AN_LIST.length >= 2 && AN_LIST.every(f => allFiles.includes(f) && /^reports\/analyses\/([a-z0-9_]+\.html|src\/[^/]+\.md)$/.test(f)) && EXEMPT.size === AN_LIST.length, `the exemption list is exactly the ${AN_LIST.length} pages and markdown sources that reports/analyses/index.json names, each a file of the package (generated reports are shipped as generated)`);
  ok(anFiles.filter(f => /\.(md|html)$/.test(f) && !scanned.has(f)).every(f => EXEMPT.has(f)) && [...EXEMPT].every(f => !scanned.has(f)) && ['reports/analyses/README.md', 'reports/analyses/make_analyses.mjs'].every(f => cFiles.includes(f)), 'what the scan leaves out of reports/analyses/ is exactly that list; its README and its generator are scanned'); }

// 2. the allow-list cannot rot: every entry clears at least one flagged leaf
for (const a of ALLOW) ok(usedAllows.has(a.id), `allow-list entry "${a.id}" clears no forbidden phrase: remove it (${a.why})`);
{ const dead = ALLOW.filter(a => !usedAllows.has(a.id)); if (dead.length) console.log('NOTE  dead allow-list entries: ' + dead.map(a => a.id).join('; ')); }

// 3. the planted phrases and the kept ones (the scan checks itself)
const PLANT = [['P1', 'Erratum E-012: the sentence in the first table was changed.'], ['P2', 'This statement was corrected on 6 October after a check.'], ['P3', 'That reading is withdrawn and the sentence is struck through.'],
  ['P4', 'The first version of this sentence was wrong.'], ['P5', 'The earlier wording overstated what the script shows.'], ['P6', 'Since v10.2 the page has a theme switch (audit round 2).'], ['P7', 'Errata corrige: la prima stesura era sbagliata.']];
for (const [g, t] of PLANT) ok(!!hitOf(t) && P[g].some(re => re.test(t)), `the planted phrase of ${g} is caught: ${t}`);
// the leftover kinds that the verifiers found in the package, each with a sentence they quoted: caught, by the group named
const PLANT2 = [
  ['P8', 'Everything in the pictures is recomputed in your browser; the Python scripts in the package are the reference (README_update_v10.md).'], ['P8', 'Lane A verifier: cocycle proof correct for all n; an independent word-reduction engine agrees.'],
  ['P8', 'Cl(4,2) ≅ M₈(ℝ): Relabelled from Cl(5,1) (= M₄(ℍ), at [6,+4]) to match the coordinate [6,+2].'], ['P8', 'The original label Cl(4,1) matched [5,+3], not [5,−1].'], ['P7', 'Rietichettata da Cl(5,1) (= M₄(ℍ), in [6,+4]) per coincidere con la coordinata [6,+2].'], ['P7', "L'etichetta originale Cl(4,1) corrispondeva a [5,+3], non a [5,−1]."],
  ['P8', 'X = h₂(ℂ) 18, so(3) + so(6), not 36 as first assumed'], ['P8', 'An unsymmetrised cubic Casimir cannot tell 3 from 3̄; we replaced it by highest weights (J2).'], ['P8', 'An extra direction and the mass shell (finding F12, reworded)'], ['P7', 'Un’altra direzione e il guscio di massa (il risultato F12, riformulato)'],
  ['P8', 'the rows of the three reports now stand in one translation matrix'], ['P8', 'every picture is computed by the report scripts and the new widget scripts'], ['P8', 'Category language has three zeros, and one symbol had been used for more than one of them.'],
  ['P8', 'whose sign pattern is now proved (T11)'], ['P8', 'where a statement is now proved for every n, the proof is a theorem of the report'], ['P8', 'The combined matrix now exists (131 rows from the three reports).'], ['P8', 'SOURCES: Lundholm (now T3 for every signature)'], ['P8', 'the closest published relative we know of, found late, listed here'],
  ['P8', 'the demicube and the orthoplex, and now the spring network.'], ['P8', 'Where a chapter keeps an older word it adds the gloss at first use.'], ['P8', 'Dead ends met on the way'], ['P8', 'the three had to be pulled apart (L0, answer card)'],
  ['P8', 'Standard facts used without a fetch in this session (recalled): Wall’s theorem'], ['P8', 'recorded by hand in the session'], ['P8', '27 of their 41 lines came out exactly as printed, 9 came out right after a correction we wrote down'], ['P8', '(22 agree, 9 after a noted correction, 5 not checked)'], ['P7', '9 dopo una correzione annotata'],
  ['P8', '(Correction, 2026-10-05: this line said that batches of at least 20 ms make a coarse timer irrelevant; found by an independent re-test, T5-5.)'], ['P8', '## Versions'], ['P8', 'Version 1 of the brief gave M(2,H) as a format example'], ['P8', 'the bit-order ambiguity of version 1'], ['P8', 'both models in runs/ saw version 1'], ['P8', 'the format example of version 1)'],
  ['P9', 'Up to 1.2.0 the page tagged the frame'], ['P9', '| **Product** (new in 1.1.0) |'], ['P9', '(on the log scale since 1.2.1)'], ['P9', 'also fails while the stored run predates 1.2.1'], ['P9', 'fixes the kernel (as it did in 1.2.1)'], ['P9', '  it did in 1.2.1), and a header would change it with no change to that code.'], ['P9', 'the stored run lacks the rows added in 1.2.1'], ['P9', 'bench_labels.json was timed before 1.2.1'],
  ['P9', '* **1.2.2** (kernel fingerprint **c261bead202f**, unchanged from 1.2.1: no kernel changed)'], ['P9', 'Stored on 2026-10-05 after a re-test.'], ['P9', 'In v11 the new and changed text is English in the Italian slots too.'], ['P9', 'the text of v11 is English in the Italian slots'], ['P9', 'In v12 the new and changed text is English in the Italian slots too.'], ['P9', 'the text of v12 is English in the Italian slots'], ['P9', 'v1.2 of the page'], ['P9', 'checked again on 4 October 2026'], ['P9', 'notes of October 5, 2026'],
  ['P6', 'Notes to the researcher (v10.1 add-on)'], ['P6', 'Category-theory pass over the bit rule (fourth note, 5 October 2026).'], ['P8', 'Category-theory pass over the bit rule (fourth note), later.']];
for (const [g, t] of PLANT2) ok(P[g].some(re => re.test(t)), `a leftover that a verifier quoted is caught by ${g}: ${t.slice(0, 90)}`);
// and the comments of the sources (scope D): the version words that a comment must not carry
for (const t of ['"Notes to the researcher" (v10.1 add-on)', 'The lines of the active atlas card (v10.2): a theorem line', 'the page is stable (v10.2, audit round 2)', 'Verdict on the log scale (1.2.1), so that a k-fold win', '(Up to 1.2.0 it was |ratio - 1| < tol)', 'checksum: that of the second pair (as before 1.2.1)', 'Allocation (1.2.1): as written', 'lane C helpers']) ok(NARROW.some(re => re.test(t)), `a version word in a comment is caught: ${t}`);
ok(MARKERS.some(re => re.test('<span class="rs-wrong">')) && MARKERS.some(re => re.test('<section id="corr">')) && MARKERS.some(re => re.test('<s>an old sentence</s>')) && MARKERS.some(re => re.test('href="#researchers/errata"')), 'the markers of the retired sections are caught (rs-wrong, id="corr", <s>, #researchers/errata)');
const KEEP = ['Three wrong versions fail the check, as they should.', 'The largest error is 0 in exact arithmetic; error > 1e-3 fails.', 'A mirror that flips the wrong sign is rejected.', 'Something went wrong. Please try again later.',
  'Claude can still be wrong, and the checks are the reference.', 'Each assert would fail if the statement were false.', 'The correction terms of the Hamiltonian are small.', 'An error-correcting code of length 8.'];
for (const t of KEEP) ok(!judge({ text: t, file: 'x.js', p: 'x.en' })?.hit, `text that only says what is kept passes: ${t}`);
// three phrases of the app that say something present and are kept: a physical condition (Charges widget), the Italian noun "un tempo" (a time, Maxwell page), and the negative control of the second program (equations page)
ok(!judge({ text: 'falls: r => `The pull is too strong for this start (ratio ${r}, 1 or more): no steady orbit, the charge falls onto the centre.`', file: 'ChargesWidget.jsx', p: 'line 166' })?.hit
  && !judge({ text: 'Punto di partenza: due generatori, un tempo e uno spazio. Un pezzo di campo E e due equazioni.', file: 'MaxwellSection.jsx', p: 'line 219' })?.hit
  && !judge({ text: 'coincidono in tutte le 12 prove a caso, e due versioni sbagliate apposta falliscono.', file: 'equationsCopy.js', p: 'default.it.d.yl.points[0][1]' })?.hit, 'the kept phrases of the Charges widget, the Maxwell page and the equations page pass');
ok(!!judge({ text: 'The pull is too strong for this start.', file: 'x.js', p: 'x.en' })?.hit && !!judge({ text: 'Il testo di un tempo, un tempo diverso.', file: 'MaxwellSection.jsx', p: 'line 1' })?.hit, 'the same phrases elsewhere are still flagged (an entry clears its own file only)');
ok(!!judge({ text: 'The largest error is 0, and erratum E-012 changed the table.', file: 'x.js', p: 'x.en' })?.hit, 'a kept phrase does not clear a forbidden one in the same leaf');
{ const withDead = [...ALLOW, { id: 'dead', re: /this phrase is nowhere/, why: 'planted' }]; ok(withDead.some(a => !usedAllows.has(a.id)), 'a planted allow-list entry that clears nothing is found'); }
// what looks like a version number or a date and is not one: a licence, a pinned dependency, a section number of a paper, the date of issue, the date of a cited source; and the plain words "next", "now", "version"
for (const t of ['PolyForm Noncommercial 1.0.0 (LICENSE, NOTICE): free for noncommercial use.', 'Tested with exactly: react 19.2.8, react-dom 19.2.8, katex 0.16.9.', 'ganja.js 1.0.189 as the reference', 'Hurwitz theorem (Sect. 8.3.1) and Sect. 2.1, 6.6.3, 7.1', 'the quantity in 1.2.1, eq (1.1), p.9', 'quell’osservazione in 1.3.2 potrebbe appartenere',
  'Release notes (7 October 2026)', 'D. Lundholm, L. Svensson, KTH lecture notes, rev. 7 June 2016', 'Y. Tian, arXiv:1309.6049 v1, 24 September 2013, 51 pages', 'notes by S. Rea, updated 25 October 2017', 'def Qform(vec): # v11 = -sum; returns the area', 'Kepler paper, eq. (12), as we read version 5', 'the text of version 2.6 of the source',
  'a failing check leaves the stored files as they were', 'Some things need two full turns, not one, to come back as they were.', 'Now press the button and see the picture.', 'The page runs now in your browser.', 'The next step builds on the earlier steps of the story.', 'Step 3 has a version of this picture for the plane.', 'A new window opens.', 'Stored run: node v22.22.0, Intel(R) Xeon(R) Processor @ 2.10GHz, 2 cores, 2026-10-04; batches of at least 60 ms',
  'Zoran Majkić · arXiv:2403.19689 v2 [math.GM], 22 March 2026']) ok(!judge({ text: t, file: 'x.md', p: 'line 1' })?.hit, `a number or a date that is not history passes: ${t}`);
ok(!judge({ text: 'New and changed text of v15 is written in English.', file: 'RELEASE_NOTES_v15.md', p: 'line 28' })?.hit && !!judge({ text: 'New and changed text of v15 is written in English.', file: 'README.md', p: 'line 28' })?.hit, 'the release name stands in the release notes only');
ok(!judge({ text: '2026-10-04', file: 'benchData.js', p: 'default.machine.date' })?.hit && !!judge({ text: '2026-10-04', file: 'x.js', p: 'default.note' })?.hit, 'the date of the machine stamp of the stored run stands, a date anywhere else does not');
for (const t of ['The framework is not a theory of nature.', 'Cl(1,3) and its mirror Cl(3,1).', 'The next step builds on the earlier steps of the story.']) ok(!judge({ text: t, file: 'x', p: 'y' })?.hit, `ordinary text passes: ${t}`);

// 4. the verdict: nothing flagged
const perScope = s => `${s}: ${R[s].flagged.length} flagged, ${R[s].allowed.length} cleared by the allow-list, ${leaves[s].length} scanned`;
console.log([perScope('A'), perScope('B'), perScope('C'), perScope('D'), `markers: ${markerHits.length + htmlMarkerHits.length}`].join('   '));
const byFile = {}; for (const l of flaggedAll) byFile[l.file] = (byFile[l.file] || 0) + 1;
if (flaggedAll.length) {
  const show = flag('--list') ? flaggedAll : flaggedAll.slice(0, 30);
  for (const l of show) console.log(`  ${l.scope} ${l.file} ${l.p} [${l.hit}] ${l.text.replace(/\s+/g, ' ').slice(0, 150)}`);
  if (!flag('--list') && flaggedAll.length > show.length) console.log(`  ... ${flaggedAll.length - show.length} more (node test_no_history.mjs --list)`);
  console.log('  by file: ' + Object.entries(byFile).sort((a, b) => b[1] - a[1]).slice(0, 25).map(([f, c]) => f + ' ' + c).join(', '));
}
ok(flaggedAll.length === 0, `no history in the package: ${flaggedAll.length} flagged leaves (${Object.keys(byFile).length} files)`);
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'NO HISTORY TESTS PASS'); process.exitCode = bad ? 1 : 0;
