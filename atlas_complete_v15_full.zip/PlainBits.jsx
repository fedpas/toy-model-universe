// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { STORY } from './storyCopy.js';
import { Tx } from './MathText.jsx';
import { Tags } from './StatusBadge.jsx';

// Small pieces shared by the Young Learner view of steps 5, 11 and 13 to 16 and the tally: a plain story (a few short paragraphs) and the closing list
// "what we checked, what is an idea, what is open", each line with its status tag. The words come from plainStepsCopy.js.

export const PlainStory = ({ paras }) => <div className="yl-story">{paras.map((x, i) => <p key={i}><Tx>{x}</Tx></p>)}</div>;
export const PlainTry = ({ h, text, children }) => <><h3><Tx>{h}</Tx></h3><div className="eq-card yl-try"><p className="eq-cap"><Tx>{text}</Tx></p>{children}</div></>;
export const PlainHedges = ({ lang, title, items }) => <div className="yl-hedges"><h3><Tx>{title}</Tx></h3>{items.map(([k, txt], i) => <div key={i} className="eq-pt yl-pt" data-kind={k}><div style={{ minWidth: 92 }}><Tags kinds={[k]} lang={lang} /></div><p><Tx>{txt}</Tx></p></div>)}</div>;
