// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Shared helper of the browser tests of steps 5, 11 and 13 to 16 and the tally, for the Young Learner: the page carries a plain story, a picture
// with plain labels and the four statuses (checked, standard, ours, open), and the formal page sits in one closed fold "For older readers".
// openForLearner checks that layout, then opens every fold of the section, so that the formal checks of a test can run on it as before.
import { FOLD } from './audienceCopy.js';
export async function openForLearner(pg, S, lang, pic) {
  const errs = [], older = (FOLD[lang] || FOLD.en).older;
  const r = await pg.evaluate(([S, older, pic]) => {
    const sec = document.querySelector(S); if (!sec) return { none: true };
    const folds = [...sec.children].filter(e => e.matches('details.eq-fold') && e.querySelector(':scope > summary')?.textContent.trim() === older);
    const p = pic ? sec.querySelector(pic) : null;
    return { story: sec.querySelectorAll('.yl-story p').length, kinds: [...sec.querySelectorAll('.yl-pt')].map(e => e.dataset.kind).join(), folds: folds.length, open: folds.some(f => f.open),
      pic: pic ? (p ? !p.closest('details:not([open])') : null) : true };
  }, [S, older, pic]);
  if (r.none) return [`no section ${S}`];
  if (r.story < 2) errs.push(`plain story has ${r.story} paragraphs`);
  if (r.kinds !== 'checked,standard,ours,open') errs.push(`plain statuses "${r.kinds}"`);
  if (r.folds !== 1 || r.open) errs.push(`fold for older readers: ${r.folds}, open ${r.open}`);
  if (r.pic !== true) errs.push(`the picture ${pic} is ${r.pic === null ? 'missing' : 'folded'}`);
  await pg.evaluate(S => document.querySelectorAll(S + ' details.eq-fold').forEach(d => { d.open = true; }), S); await pg.waitForTimeout(80);
  return errs;
}
