// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_needs.mjs: the data of the "needs and inputs" strips (inputsData.js; v11, gatherC C-013), without a browser.
//   1. the keys of NEEDS are tabs of the router (SUBS in StoryShell.jsx; the three Maxwell tabs as maxwell/<tab>); every tab has a strip except the ones named here;
//   2. every input has a kind of KINDS, a text ending in a full stop (40 to 230 characters, or, for the twelve gravity lines that carry what was checked about their input, a longer text with a lead of 40 to 230 characters that the strip shows), and says "derived" only to say it is not derived (three phrases of the gravity lines named); the counts of the kinds are pinned;
//   3. every tab has a plain line for the Young Learner (not empty, at most 190 characters, no SYMBOLS and no JARGON, both read from test_yl_ui.mjs);
//   4. every need is a tab, a page or one of the two plain-text fallbacks; no need points forward in the order of the pages;
//   5. the INP rows of the claims table are the inputs of this file, in order (text, page, anchor, flag);
//   6. INPUT_FLAGS is ['input']; no entry has a flag of its own (a line is tagged input, never standard, never checked).      Run: node test_needs.mjs
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
import { STEP_GROUPS } from './steps.js';
import { PAGES } from './storyCopy.js';
import { NEEDS, KINDS, NEEDS_COPY, INPUT_FLAGS, needLabel } from './inputsData.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');

// ---- the tabs of every page, from the source of the router, in the order of the pages
const subsSrc = rd('StoryShell.jsx').match(/export const SUBS = (\{[^\n]*\});/)[1];
const SUBS = new Function('STEP_GROUPS', 'return ' + subsSrc)(STEP_GROUPS);
const TABS = []; for (const p of PAGES) for (const t of SUBS[p] || []) TABS.push({ page: p, id: t, key: p === 'maxwell' ? 'maxwell/' + t : t });
ok(TABS.length >= 30 && new Set(TABS.map(t => t.id)).size === TABS.length, `${TABS.length} tabs, every tab id on one page only (a need names a tab by its id alone)`);
const WITHOUT = ['conventions', 'tally'];   // tabs that take nothing from outside and carry no strip (conventions: the page of the conventions; tally: the wrap-up)
const keys = Object.keys(NEEDS);
ok(keys.every(k => TABS.some(t => t.key === k)), 'every key of NEEDS is a tab of the router: ' + keys.filter(k => !TABS.some(t => t.key === k)).join(' '));
ok(TABS.every(t => (WITHOUT.includes(t.id) ? !NEEDS[t.key] : !!NEEDS[t.key])), 'every tab has a strip except ' + WITHOUT.join(', ') + ': ' + TABS.filter(t => !!NEEDS[t.key] === WITHOUT.includes(t.id)).map(t => t.key).join(' '));
ok(keys.length === 31, `31 strips (${keys.length})`);
ok(keys.every(k => !k.includes('/') || /^maxwell\/(views|charges|ladders)$/.test(k)), 'the only keys with a slash are the three Maxwell tabs');
ok(keys.every(k => Object.keys(NEEDS[k]).every(f => ['needs', 'inputs', 'yl', 'none'].includes(f)) && Array.isArray(NEEDS[k].needs) && Array.isArray(NEEDS[k].inputs) && typeof NEEDS[k].yl === 'string'), 'an entry has needs, inputs and yl (and none), nothing else');

// ---- the inputs
const INPUTS = []; for (const k of keys) NEEDS[k].inputs.forEach(([kind, text, lead], idx) => INPUTS.push({ key: k, idx, kind, text, lead }));
ok(INPUTS.length === 94, `94 input lines (${INPUTS.length})`);
ok(INPUTS.every(i => KINDS[i.kind]), 'every input has a kind of KINDS: ' + INPUTS.filter(i => !KINDS[i.kind]).map(i => i.key + ':' + i.kind).join(' '));
ok(Object.keys(KINDS).length === 11 && Object.values(KINDS).every(v => typeof v === 'string' && v.length > 3) && KINDS.action === 'the action', 'KINDS: eleven names, one of them the action');
ok(Object.keys(KINDS).every(k => INPUTS.some(i => i.kind === k)), 'every kind of KINDS is used by at least one input line: ' + Object.keys(KINDS).filter(k => !INPUTS.some(i => i.kind === k)).join(' '));
const count = {}; INPUTS.forEach(i => { count[i.kind] = (count[i.kind] || 0) + 1; });
const WANT = { action: 7, postulate: 9, chart: 12, grade: 6, representation: 1, convention: 14, data: 23, time: 7, complex: 7, involution: 5, solution: 3 };
ok(JSON.stringify(Object.fromEntries(Object.keys(WANT).map(k => [k, count[k] || 0]))) === JSON.stringify(WANT), 'kind counts ' + JSON.stringify(count) + ' (pinned: ' + JSON.stringify(WANT) + ')');
// what the strip shows of an input line: its text, up to 230 characters; a longer text has a lead (the third element) that the strip shows, with a button for the whole text
const SHOWN = i => i.lead || i.text, LEADS = 'grav1:0 grav1:1 grav2:0 grav2:1 grav2:2 gauge:0 gauge:1 gauge:2 nullsurf:0 nullsurf:2 rigid:0 rigid:1';
ok(INPUTS.every(i => typeof i.text === 'string' && i.text.length >= 40 && /\.$/.test(i.text) && (i.lead ? (i.text.length > 230 && i.text.length <= 2400) : i.text.length <= 230)), 'every input text ends in a full stop and is 40 to 230 characters, or longer (to 2 400) with a lead: ' + INPUTS.filter(i => !(typeof i.text === 'string' && i.text.length >= 40 && /\.$/.test(i.text) && (i.lead ? (i.text.length > 230 && i.text.length <= 2400) : i.text.length <= 230))).map(i => i.key + ' (' + i.text.length + ')').join(' '));
ok(INPUTS.every(i => i.lead === undefined || (typeof i.lead === 'string' && i.lead.length >= 40 && i.lead.length <= 230 && /\.$/.test(i.lead) && i.lead !== i.text)), 'what the strip shows of every input line is 40 to 230 characters and ends in a full stop: ' + INPUTS.filter(i => i.lead !== undefined && !(typeof i.lead === 'string' && i.lead.length >= 40 && i.lead.length <= 230 && /\.$/.test(i.lead) && i.lead !== i.text)).map(i => i.key + ':' + i.idx + ' (' + (i.lead && i.lead.length) + ')').join(' '));
ok(INPUTS.filter(i => i.lead !== undefined).map(i => i.key + ':' + i.idx).join(' ') === LEADS, 'the input lines with a lead are the twelve of the gravity steps (page, gravity I and II, gauge, null surfaces, rigid): ' + INPUTS.filter(i => i.lead !== undefined).map(i => i.key + ':' + i.idx).join(' '));
const FORMULA = /[0-9=_^{}\[\]\u2080-\u209f\u2070-\u209f\u00b2\u00b3\u00bc\u2153-\u215e\u0300-\u036f\u0394-\u03c9\u00b7]/;   // a word with a digit, an equals sign, an index, a bracket inside, a Greek letter or a middle dot: a formula or a number
const loose = i => i.lead ? i.lead.split(/\s+/).map(w => w.replace(/^[(\[“]+|[)\].,;:”]+$/g, '')).filter(w => FORMULA.test(w) && !i.text.includes(w)) : [];
ok(INPUTS.every(i => loose(i).length === 0), 'every formula and number of a lead stands in the text it leads: ' + INPUTS.filter(i => loose(i).length).map(i => i.key + ':' + i.idx + ' ' + loose(i).join(' ')).join(' | '));
const SAYS_NOT = /\b(does not derive|do not derive|not derived)\b/gi;
// three statements of the gravity lines say "derived" about something that is not the input: a lemma chain for the Bianchi identities, the field equation solved inside one class of frames, the same for the point mass
const DERIVED_OK = /\(derived for all n by a plain-text lemma chain;|are derived in this class, not borrowed|where Schwarzschild is derived/g;
const derived = t => /\bderiv(e|es|ed|ing)\b/i.test(t.replace(DERIVED_OK, '').replace(SAYS_NOT, ''));
ok(INPUTS.every(i => !derived(i.text) && !derived(i.lead || '')), 'an input says "derived" only to say it is not (or in one of the three gravity phrases): ' + INPUTS.filter(i => derived(i.text) || derived(i.lead || '')).map(i => i.key).join(' '));
ok(keys.filter(k => NEEDS[k].none).join() === 'comm' && keys.every(k => !!NEEDS[k].none === (NEEDS[k].inputs.length === 0)), 'the only tab with "none" is comm, and exactly the tabs without an input line: ' + keys.filter(k => !!NEEDS[k].none !== (NEEDS[k].inputs.length === 0)).join(' '));
ok(keys.every(k => { const t = NEEDS[k].inputs.map(x => x[1]); return new Set(t).size === t.length; }), 'no tab says one input twice');

// ---- the plain line of the Young Learner (SYMBOLS and JARGON are the ones of test_yl_ui.mjs)
const ylSrc = rd('test_yl_ui.mjs'), lit = n => { const m = ylSrc.match(new RegExp('^const ' + n + ' = (\\/.*\\/[a-z]*);\\s*$', 'm')); return m ? new Function('return ' + m[1])() : null; };
const SYMBOLS = lit('SYMBOLS'), JARGON = lit('JARGON');
ok(SYMBOLS instanceof RegExp && JARGON instanceof RegExp, 'SYMBOLS and JARGON were read from test_yl_ui.mjs');
const yl = keys.map(k => [k, NEEDS[k].yl]);
ok(yl.every(([, y]) => y && y.length >= 20 && y.length <= 190), 'every plain line is 20 to 190 characters: ' + yl.filter(([, y]) => !(y && y.length >= 20 && y.length <= 190)).map(([k, y]) => k + ' (' + (y && y.length) + ')').join(' '));
ok(yl.every(([, y]) => !SYMBOLS.test(y)), 'no plain line holds a symbol: ' + yl.filter(([, y]) => SYMBOLS.test(y)).map(([k]) => k).join(' '));
ok(yl.every(([, y]) => !JARGON.test(y)), 'no plain line holds a word of the jargon list: ' + yl.filter(([, y]) => JARGON.test(y)).map(([k, y]) => k + ' "' + (y.match(JARGON) || [])[0] + '"').join(' '));
ok(yl.every(([, y]) => /[.!?]$/.test(y)), 'every plain line ends in a full stop');
const ylCopy = [NEEDS_COPY.yl.aria, NEEDS_COPY.yl.script, NEEDS_COPY.yl.needs, NEEDS_COPY.yl.help, ...Object.values(NEEDS_COPY.yl.words), ...Object.values(NEEDS_COPY.yl.pages)];
ok(ylCopy.every(y => typeof y === 'string' && y && !SYMBOLS.test(y) && !JARGON.test(y)), 'the plain words of the strip (title, labels, help, page words) hold no symbol and no jargon');

// ---- the needs
const WORDS = Object.keys(NEEDS_COPY.words);   // a page word with a fallback in plain text: 'conventions' (no such page yet) and 'maxwell' (a page)
ok(WORDS.join() === 'conventions,maxwell' && WORDS.every(w => NEEDS_COPY.yl.words[w]), 'the plain-text words of a need are conventions and maxwell, both in the plain reading too');
const tabIds = new Set(TABS.map(t => t.id)), resolves = w => tabIds.has(w) || PAGES.includes(w) || WORDS.includes(w);
const unresolved = []; for (const k of keys) for (const w of NEEDS[k].needs) if (!resolves(w)) unresolved.push(k + '>' + w);
ok(unresolved.length === 0, 'every need is a tab, a page or a plain-text word: ' + unresolved.join(' '));
ok(keys.every(k => NEEDS[k].needs.every(w => w !== k.replace('maxwell/', '')) && new Set(NEEDS[k].needs).size === NEEDS[k].needs.length && NEEDS[k].needs.length <= 4), 'a strip names at most four distinct needs, never itself');
const noPage = [...new Set(keys.flatMap(k => NEEDS[k].needs).filter(w => !tabIds.has(w) && !PAGES.includes(w)))];
const HAS_CONV = tabIds.has('conventions') || PAGES.includes('conventions');   // the Conventions tab (or page) of the story builder: until it exists, a need for it is plain text
ok(noPage.join() === (HAS_CONV ? '' : 'conventions'), 'the needs that name no tab and no page are plain text: ' + noPage.join(' ') + ' (a need for the conventions is a link once the Conventions tab or page exists, plain text before)');
// the needs that point forward in the order of the pages (a tab named by a tab that comes before it): none. The page order is the dependency order:
// the Conventions page (the conventions and the clock) comes before Maxwell, the equations in the order of their needs, and Furey after the equations it uses.
const at = {}; TABS.forEach((t, i) => { at[t.id] = i; });
const forward = []; for (const k of keys) { const me = at[k.replace('maxwell/', '')]; for (const w of NEEDS[k].needs) if (w in at && at[w] > me) forward.push(k + '>' + w); }
ok(forward.length === 0, `no need points forward in the order of the pages (${keys.length} strips): ${forward.join(' ') || 'none'}`);

// the label of a link to a tab names its page first (the step numbers repeat from page to page: 2 is the demicube on the shapes page and the commutators on the equations page)
const PAGE_WORDS = ['conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses'];
ok(JSON.stringify(Object.keys(NEEDS_COPY.pages)) === JSON.stringify(PAGE_WORDS) && JSON.stringify(Object.keys(NEEDS_COPY.yl.pages)) === JSON.stringify(PAGE_WORDS), 'the strip has a page word, in the reading of the Physicist and of the Young Learner, for every page that holds a tab: ' + PAGE_WORDS.join(' '));
ok(TABS.every(t => PAGE_WORDS.includes(t.page)), 'every tab is on a page that has a page word');
const L = (t, w, yl = false) => needLabel(t, w, yl ? NEEDS_COPY.yl.pages : NEEDS_COPY.pages);
ok(L({ page: 'shapes', sub: 'demi', label: '2 · The demicube' }, 'demi') === 'Shapes · 2 · The demicube' && L({ page: 'equations', sub: 'comm', label: '2 · Commutators' }, 'comm') === 'Equations · 2 · Commutators', 'the links to the demicube and to the commutators name their page');
ok(L({ page: 'conventions', sub: 'clock', label: '1 · Clock · trinity' }, 'clock') === 'Conventions · 1 · Clock · trinity' && L({ page: 'furey', sub: 'dictionary', label: 'The dictionary' }, 'dictionary') === 'Furey · The dictionary', 'the clock and the dictionary name their page');
ok(L({ page: 'conventions', sub: 'conventions', label: 'Conventions' }, 'conventions') === 'Conventions' && L({ page: 'conventions', sub: 'conventions', label: 'Our words' }, 'conventions', true) === 'Our words', 'a tab that carries the word of its page is not named twice');
ok(L({ page: 'maxwell', sub: 'views', label: 'Calibration 1 · Maxwell' }, 'maxwell') === 'Calibration 1 · Maxwell', 'a need that is a page keeps the name of the page');
ok(L({ page: 'shapes', sub: 'orth', label: '1 · Two poles on every line' }, 'orth', true) === 'Shapes · 1 · Two poles on every line', 'the Young Learner reads the plain page word too');

// ---- what the strips say, line by line (each pin is a present statement of the page it belongs to)
const text = k => NEEDS[k].inputs.map(i => i[1]).join(' ');
ok(!/Schuller/.test(text('spin')) && /Eelbode’s lecture/.test(text('spin')), 'the spin strip names Eelbode’s lecture and not Schuller’s');
ok(/hyperbolic wave operator \(T18\)/.test(text('maxwell/ladders')) && !/is physics/.test(text('maxwell/ladders')), 'the ladders strip says that a Lorentzian split gives a hyperbolic wave operator');
ok(NEEDS.gauge.inputs.every(i => i[0] !== 'involution') && !/Kerr(?!–Schild)|Hsu/.test(text('gauge')) && /Schwarzschild metric \(a point mass\)/.test(text('gauge')) && /Schwarzschild and Schwarzschild–\(anti-\)de Sitter are derived in this class, not borrowed/.test(text('gauge')), 'the gauge strip names the Schwarzschild point mass only (Kerr only as the class of Kerr–Schild frames) and takes no involution');
ok(['grav1', 'gauge', 'clock', 'dirac', 'grav2'].every(k => NEEDS[k].inputs.some(i => i[0] === 'convention')), 'the strips of the clock, the Dirac step, gravity I and II and gauge gravity each carry a sign-convention line');
ok(NEEDS.spring.needs.includes('spin') && NEEDS.rigid.needs.includes('spring') && NEEDS.threegen.needs.join() === 'dictionary,findings', 'the needs of spring (spin), rigid (spring) and three generations (dictionary, findings) name the pages their text leans on');
ok(NEEDS.matter.inputs.filter(i => i[0] === 'representation').length === 1 && NEEDS.matter.inputs.every(i => i[0] !== 'grade' || !/representation is a choice/.test(i[1])), 'the choice of representation is a line of its own kind in the matter strip, not a grade');
ok(['coupling', 'matter', 'spin', 'mirrors'].every(k => NEEDS[k].inputs.some(i => i[0] === 'time')) && ['coupling', 'matter', 'findings'].every(k => NEEDS[k].inputs.some(i => i[0] === 'complex')) && NEEDS['maxwell/charges'].inputs.some(i => i[0] === 'solution'), 'the strips of the coupling, matter, spin and mirrors steps list the time direction, coupling and matter list the complex structure, the charges tab lists its given fields');
ok(NEEDS.demi.inputs.length === 1 && !NEEDS.demi.none && /Furey box/.test(text('demi')) && NEEDS.orth.inputs.some(i => i[0] === 'data' && /Baez, Bokor and Boyle/.test(i[1])), 'the demicube strip lists the Furey box, the orthoplex strip the charge formulas of Baez, Bokor and Boyle');
ok(NEEDS.earlier.inputs.length === 1 && NEEDS.help.inputs.length === 1 && NEEDS.earlier.needs.join() === 'dictionary' && NEEDS.help.needs.join() === 'threegen', 'her papers and what may help carry a strip of their own');
ok(NEEDS.category.inputs.some(i => i[0] === 'involution' && /dagger/.test(i[1])) && NEEDS.category.inputs.some(i => i[0] === 'data' && /T4, T6 and T8/.test(i[1])) && NEEDS.baez.inputs.some(i => /Madelung/.test(i[1])) && /simplicity of the large groups/.test(text('groups')) && /2\^\{1\+24\}/.test(text('groups')), 'category (dagger, recalled theorems), Baez (Madelung order) and groups (four quoted items) are complete');
// the action: one input that stands for the field equations of the field-theory steps, named in every line it covers; the other kinds of input stay what they are
{ const ACT = ['maxwell/views', 'dirac', 'coupling', 'ym', 'matter', 'grav1', 'grav2'], act = k => NEEDS[k].inputs.filter(i => i[0] === 'action');
  ok(keys.filter(k => act(k).length > 0).join() === ACT.join() && ACT.every(k => act(k).length === 1 && /^The action of this step: /.test(act(k)[0][1]) && /stationarity|varied in/.test(act(k)[0][1])), 'the seven field-theory strips (Maxwell, Dirac, coupling, Yang–Mills, matter, gravity I and II) each take one action, named as the action of the step, and no other strip does');
  ok(/bd·phy·18/.test(act('dirac')[0][1]) && /bd·phy·18, bd·phy·19/.test(act('coupling')[0][1]) && /A·⟨X⟩₁, so no projection is chosen by hand \(bd·phy·11\)/.test(act('coupling')[0][1]) && /bd·phy·19/.test(act('maxwell/views')[0][1]), 'the Dirac–Maxwell actions cite the checks that compute their Euler–Lagrange equations (bd·phy·18, bd·phy·19) and the coupling term (bd·phy·11)');
  ok(['ym', 'matter'].every(k => /\(pointer, source unread\)/.test(act(k)[0][1]) && /Checked: /.test(act(k)[0][1])), 'the Yang–Mills and matter actions are pointers with the source unread, and each keeps the checks of its page');
  ok(['grav1', 'grav2'].every(k => /\(its published form read in three papers; the first variation is checked here as an exact identity/.test(act(k)[0][1]) && !/source unread|pointer/.test(act(k)[0][1]) && /Checked: /.test(act(k)[0][1])), 'the two gravity actions give their published form as read in three papers, with the first variation checked as an exact identity (no pointer with the source unread), and each keeps the checks of its page');
  ok(NEEDS.ym.inputs.some(i => i[0] === 'postulate' && /^so\(m\) as the gauge algebra is one choice/.test(i[1])) && NEEDS['maxwell/charges'].inputs.some(i => i[0] === 'postulate' && /Lorentz force/.test(i[1])) && ['forque', 'spin', 'spring', 'rigid'].every(k => NEEDS[k].inputs[0][0] === 'postulate'), 'the gauge algebra, the Lorentz force and the laws of the mechanics steps stay postulates');
  ok(NEEDS['maxwell/views'].inputs.some(i => i[0] === 'postulate' && /^The constitutive relation: in vacuum H = ⋆F, the Hodge dual of F; in a medium H = χ\(F\) with 36 components \(20 principal, 15 skewon, 1 axion; bd·sol·14\)\.$/.test(i[1])) && NEEDS['maxwell/views'].inputs.some(i => i[0] === 'convention' && /^Units with c = ε₀ = μ₀ = 1/.test(i[1])), 'the Maxwell strip lists the constitutive relation (36 components) and the units');
  ok(/no time-domain realisation/.test(text('maxwell/ladders')) && /bd·sol·16/.test(text('maxwell/ladders')) && /\(2,2\) or z-time Lorentzian dispersion \(bd·sol·15\)/.test(text('maxwell/ladders')), 'the ladders strip says where extra time generators live (fixed frequency, indefinite media)');
  ok(['coupling', 'matter', 'spin'].every(k => NEEDS[k].inputs.every(i => i[0] !== 'involution') && NEEDS[k].inputs.filter(i => i[0] === 'time').length === 1 && /^The time orientation of the Dirac step/.test(NEEDS[k].inputs.find(i => i[0] === 'time')[1])) && NEEDS.dirac.inputs.every(i => i[0] !== 'involution') && /^A time orientation \(one orbit of the even versors, two of the rotors; bd·tor·1\)\. γ₀ and J on the right are a reference, observers act on the left \(bd·geo·11\)/.test(NEEDS.dirac.inputs.find(i => i[0] === 'time')[1]), 'Dirac, coupling, matter and spin take one input for the time direction and the involution: a time orientation, γ₀ and J a reference of the right action');
  ok(['dirac', 'coupling', 'matter', 'spin'].every(k => /γ₀ψ̃γ₀/.test(NEEDS[k].inputs.find(i => i[0] === 'time')[1]) && /bd·phy·9/.test(NEEDS[k].inputs.find(i => i[0] === 'time')[1])) && NEEDS.mirrors.inputs.some(i => i[0] === 'involution') && /^A time orientation, given by the unit vector e_t/.test(NEEDS.mirrors.inputs.find(i => i[0] === 'time')[1]), 'the positive involution γ₀ψ̃γ₀ is part of the time input (bd·phy·9); the mirrors strip keeps its involution line and states the time input in the same words');
  ok(!keys.some(k => /observer’s time direction/.test(text(k) + ' ' + NEEDS[k].yl)), 'no strip calls γ₀ the observer’s time direction');
  ok(NEEDS.clock.inputs.length === 1 && NEEDS.category.inputs.length === 2 && !/null bit|null generator \(square 0\)|weight 0/.test(text('clock') + text('category')) && !/rule we chose|switch nothing/.test(NEEDS.clock.yl + NEEDS.category.yl), 'the weight of a null bit is not an input: the clock strip keeps one line, the category strip two');
  ok(/^The coupling constant e: its size is a free constant/.test(NEEDS.coupling.inputs.find(i => i[0] === 'data')[1]) && ['coupling', 'matter', 'grav2'].every(k => !/sign of the source/.test(text(k))), 'the coupling constants stay free data and no strip lists the sign of the source as an input');
  ok(ACT.every(k => /one recipe taken from books/.test(NEEDS[k].yl)), 'the plain line of each of the seven strips says that the equations follow from one recipe taken from books'); }
// gauge or datum: every input line that chooses a structure inside the algebra says how many orbits the group of the algebra has on the choices, with its check (bd·tor·1 to bd·tor·7) and its range
{ const line = (k, kind, i = 0) => NEEDS[k].inputs.filter(x => x[0] === kind)[i][1], tor = (t, n) => new RegExp('bd·tor·' + n + '\\b').test(t);
  ok(['maxwell/charges', 'mirrors', 'dirac', 'coupling', 'matter', 'spin'].every(k => tor(line(k, 'time'), 1)) && /Only a time orientation is chosen: one orbit of the even versors, two of the rotors \(bd·tor·1, n ≤ 6\)/.test(line('maxwell/charges', 'time')), 'the time direction: only a time orientation is chosen (one orbit of the even versors, two of the rotors; bd·tor·1)');
  ok(['dirac', 'coupling', 'matter', 'spin'].every(k => tor(line(k, 'complex'), 2)) && /For n ≥ 4 it is gauge, one rotor orbit; at n = 3 J and −J differ \(bd·tor·2, n ≤ 6\)/.test(line('dirac', 'complex')), 'the complex structure J: gauge for n ≥ 4, a datum at n = 3 (bd·tor·2)');
  ok(/gauge under Pin\(k,k\); under Spin one bit remains, the family of the Lagrangian \(bd·tor·3, k ≤ 4\)/.test(line('orth', 'complex')), 'the Witt split: gauge under Pin, one bit under Spin (bd·tor·3)');
  ok(tor(line('maxwell/views', 'chart'), 6) && tor(line('grav1', 'chart'), 6) && tor(line('gauge', 'chart'), 6) && /four values when p, q ≥ 1 \(bd·tor·6, n ≤ 5\)/.test(line('maxwell/views', 'chart')), 'the frame: gauge under Pin up to orientation and time orientation (bd·tor·6)');
  ok(/gauge in Cl\(1,3\) \(e_i ↦ e_iI\), and in general only for n ≡ 0 mod 4, indefinite \(bd·tor·7, n ≤ 8\)/.test(line('mirrors', 'involution')) && ['spring', 'category'].every(k => /a datum/.test(line(k, 'involution')) && tor(line(k, 'involution'), 7)) && ['dirac', 'coupling', 'matter', 'spin'].every(k => tor(line(k, 'time'), 7)), 'the involution: reversion against Clifford conjugation is a gauge in Cl(1,3), the dagger a datum when q ≥ 1 (bd·tor·7)');
  ok(tor(line('dictionary', 'complex'), 5) && tor(line('findings', 'complex'), 5) && /the bases of one Lagrangian, a gauge; given it and ω, the partition is a datum, 11 orbits \(bd·tor·5\)/.test(line('findings', 'data')), 'Furey: ω and the torus are gauge, the block partition is a datum with 11 values (bd·tor·5)');
  ok(/Some pages bring in one recipe from which the equations of motion follow; we take the recipe from books and check what follows from it\.$/.test(NEEDS_COPY.yl.help), 'the plain help of the strip says what the action is, in plain words');
  ok(['forque', 'rigid'].every(k => !/bd·tor/.test(line(k, 'involution'))), 'the lines of a cell with a null generator (forque, rigid) carry no orbit count: the range is r = 0'); }

// ---- the INP rows of the claims table are these inputs, in order
const CLAIMS = (await import('./claimsData.js')).CLAIMS, INP = CLAIMS.filter(c => c.group === 'INP');
ok(INP.length === INPUTS.length && INP.every((c, i) => c.id === 'INP-' + String(i + 1).padStart(3, '0')), `${INP.length} INP rows, numbered in order, one for each input line`);
const bad5 = INP.map((c, i) => [c, INPUTS[i]]).filter(([c, i]) => !i || c.en.length !== 1 || c.en[0].text !== i.text || c.it.length !== 1 || c.it[0].text !== i.text || c.anchor !== 'ns-' + i.key.replace(/\//g, '-') || c.page !== TABS.find(t => t.key === i.key).page || c.flags.join() !== INPUT_FLAGS.join() || c.known !== false);
ok(bad5.length === 0, 'each INP row has the text, the page, the anchor and the flag of its input line (English in both slots): ' + bad5.slice(0, 3).map(([c]) => c.id).join(' '));
ok(CLAIMS.filter(c => c.group !== 'INP').every(c => !/^ns-/.test(c.anchor || '')), 'no other claim points at a strip');

// ---- the flag
ok(Array.isArray(INPUT_FLAGS) && INPUT_FLAGS.length === 1 && INPUT_FLAGS[0] === 'input', "INPUT_FLAGS is ['input']");
ok(INPUTS.every(i => Array.isArray([i.kind, i.text]) && !('flags' in NEEDS[i.key])), 'no entry has a flag of its own: a line of the strip is input, never standard, never checked');
const src = rd('NeedsStrip.jsx');
ok(/StatusBadge flag="input"/.test(src) && !/flag="(standard|checked|ours|open)"/.test(src), 'NeedsStrip.jsx draws one badge, flag="input"');
ok(/\.needs-strip/.test(rd('readerFilter.js')), 'the reader filter leaves the strip alone (readerFilter.js NEVER)');

console.log(bad ? `${bad} FAILURES of ${checks}` : `NEEDS DATA OK (${checks} checks)`);
process.exit(bad ? 1 : 0);
