// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import katex from 'katex';
import {FINDINGS,FINDINGS_UI,EDGES,REAL_BLOCKS,COMPLEX_BLOCKS,BLOCK_NAMES,NUMBERS} from './findingsData.js';
import {peirceDecomposition} from './genesis_audit_v3.js';
import * as E from './fureyPapersEngine.js';
import {FC} from './fureyCopy.js';
const J=JSON.parse(fs.readFileSync('./furey_results.json','utf8'));
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
ok(eq(REAL_BLOCKS,J.real_blocks),'real blocks');ok(eq(COMPLEX_BLOCKS,J.complex_blocks),'complex blocks');
ok(NUMBERS.realDiag===J.real_diag&&NUMBERS.realOff===J.real_off&&NUMBERS.cxDiag===J.complex_diag&&NUMBERS.cxOff===J.complex_off,'peirce numbers');
ok(NUMBERS.deltaSM===J.delta_SM_real_dim&&NUMBERS.generation===J.sm_generation_dim&&NUMBERS.replicas===J.extras_dim&&NUMBERS.maxEdge===J.maxEdge.capacity_C,'sm numbers');
ok(NUMBERS.quadruples===J.witt.independent_commuting_grade4_quadruples&&NUMBERS.diagonalising===J.witt.diagonalising_all_block_projectors&&NUMBERS.fanoLines===J.witt.fano_lines,'witt numbers');
const idx={'C_O(1)':0,'C3_O(3)':1,'C2_H(2)':2,'C_C(1)':3,'C_last(1)':4};
ok(J.edges.length===EDGES.length,'edge count');
for(const e of J.edges){const a=idx[e.a],b=idx[e.b];const m=EDGES.find(x=>(x[0]===a&&x[1]===b)||(x[0]===b&&x[1]===a));ok(!!m&&m[2]===e.capacity_C,`edge ${e.a}-${e.b} capacity`);
 // block sizes consistent with capacity
 ok(e.capacity_C===2*COMPLEX_BLOCKS[a]*COMPLEX_BLOCKS[b],`2nn ${e.a}-${e.b}`)}
const smSet=EDGES.filter(x=>x[4]==='sm'),rep=EDGES.filter(x=>x[4]==='rep');
const smOne=smSet.reduce((t,x)=>t+(x[2]===12?6:x[2]/2),0),repOne=rep.reduce((t,x)=>t+x[2]/2,0);
ok(smOne===16&&repOne===8,'one-way SM 16 / replicas 8: '+smOne+'/'+repOne);
const pd=peirceDecomposition();ok(pd.edgeTotalC===48&&pd.smContent.generationC===16&&pd.smContent.replicaC===8,'audit module agrees');
ok(J.witt.cayley_dickson_flag_affine.every(Boolean)&&J.witt.block_is_affine.O2===false,'affine flag');
ok(eq(J.omega_prime_over_omega_minus_axes,[0,3,8,11])&&/0,3,8,11/.test(FINDINGS.find(f=>f.id==='z2').en.Physicist[1]),'z2 axes');
// text coverage + no stale claims
for(const f of FINDINGS)for(const L of['en','it'])for(const P of['Young Learner','Physicist','Mathematician']){const t=f[L]?.[P];ok(Array.isArray(t)&&t.length===2&&t[0]&&t[1],`${f.id}.${L}.${P}`)}
for(const f of FINDINGS)for(const L of['en','it'])for(const P in f[L])ok(!/withdrawn|retract|ritirat|ritrattaz|two generations|due generazioni|rejected|respint|corrected/i.test(f[L][P][1]+f[L][P][0]),`no history claims ${f.id}.${L}.${P}`);
// v10.2 (audit round 2): the tags of each card are from the five, in order, and a card tagged ours never says derived; the edge listing says it
// carries gauge quantum numbers only, and its sum of Y³ (recomputed here from the listing the card prints) is the −4/9 it quotes
{ const ORDER = ['standard', 'checked', 'ours', 'open', 'input'];
  for (const f of FINDINGS) { ok(Array.isArray(f.flags) && f.flags.join() === ORDER.filter(k => f.flags.includes(k)).join(), `${f.id}: tags from the five, in order (${f.flags})`);
    if (f.flags.includes('ours')) for (const L of ['en', 'it']) for (const P of ['Physicist', 'Mathematician']) ok(!/deriv/i.test(f[L][P].join(' ')), `${f.id}.${L}.${P}: a card tagged ours never says derived`); }
  ok(FINDINGS.find(f => f.id === 'edges').flags.join() === 'checked,open,input' && FINDINGS.find(f => f.id === 'open').flags.join() === 'ours,open', 'one generation fits by gauge quantum numbers (checked, open; the handedness comes from her labels, an input); the open questions are ours and open');
  // the inputs of the model: the complex structure (blocks), her labels (edges), the partition of V into blocks (witt); the Z2 parallel is not an input
  ok(['blocks', 'edges', 'witt'].every(id => FINDINGS.find(f => f.id === id).flags.includes('input')) && !FINDINGS.find(f => f.id === 'z2').flags.includes('input') && FINDINGS.find(f => f.id === 'z2').flags.join() === 'checked,open', 'FUR-001, FUR-002 and FUR-003 carry input; FUR-004 does not');
  // the ten edges and what they hold: the card quotes each irrep with the number of times the engine finds it in the ten edges (Fig. 1 of the 2026 paper, one direction)
  const cnt = E.setsByType(false), W = { en: { 1: 'once', 2: 'twice', 3: 'three times' }, it: { 1: 'una volta', 2: 'due volte', 3: 'tre volte' } }, irr = t => E.fmtShow(E.SM[t]);
  for (const L of ['en', 'it']) { const ph = FINDINGS.find(f => f.id === 'edges')[L].Physicist[1], w = k => W[L][cnt[k]];
    ok(ph.includes(`Q_L ${irr('Q_L')} ${w('Q_L')}`) && ph.includes(`u_R ${w('u_R')}`) && ph.includes(`(1,2,∓1/2) ${w('L')}`) && ph.includes(`${irr('d_R')} ${w('d_R')}`) && ph.includes(`${irr('e_R')} ${w('e_R')}`) && ph.includes(`${irr('nu_R')} ${w('nu_R')}`), `the edge card (${L}) lists the irreps with the multiplicities of the engine: ${JSON.stringify(cnt)}`);
    ok(ph.includes('24ℂ') && ph.includes('16ℂ') && ph.includes('8ℂ') && 24 === Object.values(cnt).reduce((a, k, n) => a + k * E.SM_DIM[Object.keys(cnt)[n]], 0) && E.surplusDim() === 8, `the edge card (${L}): 24ℂ = one complete set 16ℂ + 8ℂ`);
    ok(/colour, isospin and hypercharge|colore, isospin e ipercarica/.test(ph), `the edge card (${L}) says what the edges carry`); }
}
const plainFindings = L => { const c = FC[L].findings; return { titleY: c.titleY, short: c.short[0], ylw: c.ylw, secs: Object.fromEntries(Object.entries(c.secs).map(([k, x]) => [k, { hy: x.hy, yl: x.yl }])), cards: Object.fromEntries(Object.entries(c.cards).map(([k, x]) => [k, { t: x.t[0], yl: x.yl }])) }; };
const YL_COPY = [['findings cards', FINDINGS.map(f => f.en['Young Learner']), FINDINGS.map(f => f.it['Young Learner'])], ['findings plain copy', plainFindings('en'), plainFindings('it')]];
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    // status keys are the same in both; v11 writes new text in English and uses it in the Italian slots too: the plain strings that are so are listed here
    const EN_IN_IT = ['We do not yet have a rule that says which box of the atlas’s own table holds which particle, so the heaviest quark has no box there.'];
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open|input)$/.test(s) || EN_IN_IT.some(x => s.startsWith(x)), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));
  }
}
console.log(bad?bad+' FAILURES':'ALL FINDINGS TESTS PASS');process.exit(bad?1:0)
