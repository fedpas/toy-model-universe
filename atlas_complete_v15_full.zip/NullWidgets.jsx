// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useState } from 'react';
import K from './nullData.js';
import { Tx } from './MathText.jsx';
import * as E from './nullEngine.js';

// The five live figures of step 13 (null surfaces). Each one is drawn from formulas in nullEngine.js that test_null.mjs recomputes against
// selfcheck/null.json, and each redraws when a slider moves or the lens changes: the same state, seen through another lens.
const BLUE = '#60a5fa', AMBER = '#fbbf24', GREEN = '#34d399', PURPLE = '#c084fc', RED = '#f87171', GREY = '#8b93a7';
const tone = T => (Math.abs(T) < 1e-12 ? PURPLE : T > 0 ? BLUE : AMBER);
const f3 = (v, d = 3) => { if (v === null || v === undefined || Number.isNaN(v)) return '—'; if (Math.abs(v) < 5 * 10 ** -(d + 1)) return '0'; if (Math.abs(v) >= 1e5) return v.toExponential(2).replace('e+', '·10^'); return String(+v.toFixed(d)); };
const sci = v => { if (v === 0) return '0'; const e = Math.floor(Math.log10(Math.abs(v))); const m = v / 10 ** e; return `${+m.toFixed(2)}·10^${e}`; };

export const LensChips = ({ lenses, value, onPick, t }) => <div className="eq-chips nl-lens" role="group" aria-label={t.lensH}>{lenses.map(l => <button key={l} data-lens={l} className={'eq-chip' + (l === value ? ' on' : '')} aria-pressed={l === value} onClick={() => onPick(l)}><Tx>{t.lens[l]}</Tx></button>)}</div>;
const Chips = ({ items, value, onPick, label, attr }) => <div className="eq-chips" role="group" aria-label={label}>{items.map(([id, text]) => <button key={id} {...{ [attr]: id }} className={'eq-chip' + (id === value ? ' on' : '')} aria-pressed={id === value} onClick={() => onPick(id)}><Tx>{text}</Tx></button>)}</div>;
// the label is typeset on screen; the name read aloud is `aria` when the label holds script markup (x_h, r_S), in plain words
const Slider = ({ label, aria, min, max, step, value, onChange, attr, extra }) => <label className="nl-slider"><span><Tx>{label}</Tx></span><input type="range" className="nl-range" {...{ [attr]: '1' }} min={min} max={max} step={step} value={value} aria-label={aria || label} onChange={e => onChange(+e.target.value)} />{extra}</label>;
// a power inside SVG text: HTML sub/superscripts do not exist there, so the exponent is a smaller, raised tspan (dy works in every browser) and the baseline is restored after it
const Pow = ({ b, e }) => <><tspan>{b}</tspan><tspan dy="-0.45em" fontSize="72%">{String(e).replace('-', '−')}</tspan><tspan dy="0.45em">{'\u200b'}</tspan></>;
const Line = ({ children, ...p }) => <p className="eq-mono nl-line" {...p}><Tx>{children}</Tx></p>;

// =============================================================== 1. the cone, the normal and the photon that stands still
// plain = the Young Learner's words (plainStepsCopy.js): plain case names and labels, one lens, a plain sentence for the readout
export function ConeWidget({ t, plain = null }) {
  const c = plain ? { ...t.cone, ...plain.cone } : t.cone, [ci, setCi] = useState(0), [d, setD] = useState(0), [lens0, setLens] = useState('clifford'), lens = plain ? 'clifford' : lens0;
  const h = E.HORIZONS[ci], x = h.xh + d, T = h.T(x), tm = E.tMax(h), kap = E.kappaNum(h), kind = E.surfaceKind(T), col = tone(T);
  const W = 560, H = 330, y0 = h.xh - E.PROBE - 0.05, y1 = h.xh + E.PROBE + 0.05, Y = v => 300 - (v - y0) / (y1 - y0) * 270, tl = tm * 1.15, TX = v => 22 + (v + tl) / (2 * tl) * 130;
  const curve = Array.from({ length: 61 }, (_, i) => { const v = y0 + (y1 - y0) * i / 60; return `${TX(h.T(v)).toFixed(1)},${Y(v).toFixed(1)}`; }).join(' ');
  const cx = 372, py = Y(x);
  const cone = (px, qy, Tc, L, color, key, strong) => {
    const s = -Tc / tm, nn = Math.hypot(1, s), ux = 1 / nn, uy = s / nn, pts = a => a.map(p => p.map(v => v.toFixed(1)).join(',')).join(' ');
    return <g key={key} className={'nl-cone' + (strong ? ' nl-probe' : '')} data-T={f3(Tc, 4)}>
      <polygon points={pts([[px, qy], [px, qy - L], [px + L * ux, qy - L * uy]])} fill={color} opacity={strong ? .3 : .16} />
      <polygon points={pts([[px, qy], [px, qy + L], [px - L * ux, qy + L * uy]])} fill={color} opacity={strong ? .3 : .16} />
      <line x1={px} y1={qy - L} x2={px} y2={qy + L} stroke={color} strokeWidth={strong ? 2 : 1} opacity={strong ? 1 : .6} />
      <line x1={px - L * ux} y1={qy + L * uy} x2={px + L * ux} y2={qy - L * uy} stroke={color} strokeWidth={strong ? 2 : 1} opacity={strong ? 1 : .6} /></g>;
  };
  const tb = E.tube(T);
  const P3 = m => [330 + 78 * (m & 1) + 40 * (m >> 2 & 1), 270 - 78 * (m >> 1 & 1) - 30 * (m >> 2 & 1)];
  const w = [0.4, 0.8], img = E.mirrorImage(w, T), MX = 52, mox = cx, moy = 200;
  const clip = (a, b) => { const lim = 3, k = Math.max(Math.abs(b[0]) / lim, Math.abs(b[1]) / 2.2, 1); return k > 1 ? [b[0] / k, b[1] / k, true] : [b[0], b[1], false]; };
  const im = img ? clip(w, img) : null;
  return <div className="eq-card nl-card" data-widget="cone">
    <Chips items={E.HORIZONS.map(hh => [hh.id, c.cases[hh.id]])} value={h.id} onPick={id => setCi(E.HORIZONS.findIndex(q => q.id === id))} label={c.caseH} attr="data-case" />
    <Slider label={c.probe} aria={c.probeAria} min={-E.PROBE} max={E.PROBE} step={0.01} value={d} onChange={setD} attr="data-probe" extra={<button className="eq-btn nl-zero" onClick={() => setD(0)}><Tx>{c.onSurf}</Tx></button>} />
    {!plain && <LensChips lenses={['clifford', 'cube', 'mirror']} value={lens} onPick={setLens} t={t} />}
    <svg className="eq-svg nl-svg" style={{ maxWidth: 600 }} viewBox={`0 0 ${W} ${H}`} role="img" aria-label={c.aria} data-lens={lens} data-T={f3(T, 5)} data-kind={kind} data-case={h.id}>
      <g className="nl-inset"><line x1={TX(0)} y1={30} x2={TX(0)} y2={300} stroke="currentColor" opacity=".35" /><polyline points={curve} fill="none" stroke={GREY} strokeWidth="2" />
        <line x1={14} y1={py} x2={160} y2={py} stroke={col} strokeDasharray="4 3" /><circle className="nl-pt" cx={TX(T)} cy={py} r="5" fill={col} />
        {!plain && <><text x={TX(0)} y={22} fontSize="11" textAnchor="middle" fill="currentColor">T(x)</text><text x={18} y={316} fontSize="10" fill="currentColor" opacity=".7">x</text>
        <text x={TX(0) + 4} y={Y(h.xh) - 4} fontSize="10" fill="currentColor" opacity=".7">x = {h.xh}</text></>}</g>
      {lens === 'clifford' && <g className="nl-clifford">
        {[-.5, -.25, 0, .25, .5].map(di => cone(cx, Y(h.xh + di), h.T(h.xh + di), 30, GREY, 'f' + di, false))}
        <line x1={cx - 100} y1={py} x2={cx + 100} y2={py} stroke={col} strokeWidth="2.5" className="nl-surface" />
        {cone(cx, py, T, 46, col, 'p', true)}
        <line x1={cx + 100} y1={py} x2={cx + 100} y2={py} stroke={col} />
        <path d={`M${cx + 56},${py} l34,0 m-7,-4 l7,4 l-7,4`} fill="none" stroke={col} strokeWidth="1.5" /><text x={cx + 56} y={py + 15} fontSize="11" fill="currentColor">{c.lab.xi}</text>
        <path d={`M${cx - 70},${py} l0,-34 m-4,7 l4,-7 l4,7`} fill="none" stroke={col} strokeWidth="1.5" /><text x={cx - 66} y={py - 30} fontSize="11" fill="currentColor">{c.lab.n}</text>
        <text x={cx - 96} y={py + 14} fontSize="11" fill={col}>{c.lab.surface}</text>
        {!plain && <text x={cx + 8} y={26} fontSize="11" fill="currentColor" opacity=".75">{c.lab.axes}</text>}</g>}
      {lens === 'cube' && <g className="nl-cubelens">
        {[0, 1, 2, 3, 4, 5, 6, 7].flatMap(m => [0, 1, 2].map(b => (m >> b & 1) ? null : [m, m | 1 << b])).filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} stroke="currentColor" opacity=".25" />)}
        {[[3, 5], [3, 6], [5, 6]].map(([a, b]) => <line key={'k' + a + b} className={'nl-br' + (a === 3 && b === 5 ? ' nl-k1k2' : '')} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} stroke={a === 3 && b === 5 ? col : GREEN} strokeWidth={a === 3 && b === 5 ? 3 : 1.6} opacity={a === 3 && b === 5 ? (Math.abs(T) < 1e-12 ? .35 : 1) : .85} strokeDasharray={a === 3 && b === 5 && Math.abs(T) < 1e-12 ? '4 3' : undefined} />)}
        {[0, 1, 2, 3, 4, 5, 6, 7].map(m => { const [px, qy] = P3(m), even = E.popc(m) % 2 === 0, tcol = m === 1 || m === 3 || m === 5 ? col : (m === 6 ? GREEN : GREY); return <g key={m} className="nl-cv" data-m={m}><circle cx={px} cy={qy} r={even && m ? 9 : 7} fill={even && m ? tcol : 'none'} stroke={tcol} strokeWidth="2" opacity={m === 0 || m === 7 ? .55 : 1} /><text x={px + 12} y={qy - 8} fontSize="11" fill="currentColor">{m}</text></g>; })}
        <text x={P3(1)[0] + 6} y={P3(1)[1] + 26} fontSize="10.5" fill="currentColor">{c.lab.tbit}</text>
        <text x={P3(3)[0] - 4} y={P3(3)[1] - 14} fontSize="10.5" fill={col}>K1</text><text x={P3(5)[0] + 4} y={P3(5)[1] + 22} fontSize="10.5" fill={col}>K2</text><text x={P3(6)[0] - 20} y={P3(6)[1] - 10} fontSize="10.5" fill={GREEN}>J</text>
        <text x={cx - 50} y={30} fontSize="11" fill="currentColor" opacity=".75">{c.lab.cube}</text></g>}
      {lens === 'mirror' && <g className="nl-mirrorlens">
        <line x1={mox - 3 * MX} y1={moy} x2={mox + 3 * MX} y2={moy} stroke={col} strokeWidth="2.5" /><text x={mox - 3 * MX} y={moy - 6} fontSize="11" fill={col}>{c.lab.surface}</text>
        <line x1={mox} y1={moy - 2.4 * MX} x2={mox} y2={moy + 2.4 * MX} stroke="currentColor" opacity=".25" />
        <path d={`M${mox},${moy} L${mox + w[0] * MX},${moy - w[1] * MX}`} stroke={BLUE} strokeWidth="2.5" fill="none" /><circle cx={mox + w[0] * MX} cy={moy - w[1] * MX} r="4" fill={BLUE} /><text x={mox + w[0] * MX + 6} y={moy - w[1] * MX - 4} fontSize="11" fill={BLUE}>{c.lab.w}</text>
        {im ? <g className="nl-image" data-clipped={im[2] ? 1 : 0}><line x1={mox + w[0] * MX} y1={moy - w[1] * MX} x2={mox + im[0] * MX} y2={moy - im[1] * MX} stroke="currentColor" strokeDasharray="4 3" opacity=".6" />
          <path d={`M${mox},${moy} L${mox + im[0] * MX},${moy - im[1] * MX}`} stroke={AMBER} strokeWidth="2.5" fill="none" /><circle cx={mox + im[0] * MX} cy={moy - im[1] * MX} r="4" fill={AMBER} />
          <text x={Math.min(mox + im[0] * MX + 6, mox + 3 * MX - 70)} y={moy - im[1] * MX + 16} fontSize="11" fill={AMBER}>{im[2] ? c.lab.off : c.lab.img}</text></g>
          : <g className="nl-image" data-none="1"><line x1={mox + w[0] * MX} y1={moy - w[1] * MX} x2={mox + 3 * MX} y2={moy - w[1] * MX * -1} stroke="currentColor" strokeDasharray="4 3" opacity=".0" /><text x={mox + 20} y={moy + 40} fontSize="12" fill={PURPLE}>{c.lab.none}</text></g>}
        <text x={mox + 3 * MX - 4} y={moy + 14} fontSize="10.5" textAnchor="end" fill="currentColor" opacity=".7">v</text><text x={mox + 6} y={moy - 2.4 * MX + 10} fontSize="10.5" fill="currentColor" opacity=".7">x</text></g>}
    </svg>
    {plain ? <div className="nl-readouts" data-lens={lens}><p className="sp-out nl-plain" data-kind={kind}><Tx>{`${c.surface} ${c.kinds[kind]}.`}</Tx></p><p className="eq-cap"><Tx>{c.cap}</Tx></p></div> : <div className="nl-readouts" data-lens={lens}>
      <Line data-r="T">{`T = g_tt = ${f3(T)}   ·   ${c.read.surface}: ${c.kinds[kind]}   ·   κ_H = ½ dT/dx = ${E.frac(K.portal.kappa[ci].kappa) === 0 ? '0' : K.portal.kappa[ci].kappa} (${f3(kap, 4)})`}</Line>
      {lens === 'clifford' && <><Line data-r="n">{`n·n = −T = ${f3(-T)}   ·   ξ·ξ = T = ${f3(T)}   (n = dx, ξ = ∂_v)`}</Line><Line data-r="gram">{`${c.read.gram}: ${c.read.tort} −T² = ${f3(E.gramTortoise(T).det, 5)}   ·   ${c.read.ef} −1`}</Line></>}
      {lens === 'cube' && <><Line data-r="sq">{`K1² = K2² = T = ${f3(tb.sq.K1)}   ·   J² = ${tb.sq.J}`}</Line><Line data-r="br">{`[J, K1] = ${tb.JK1.c} K2   ·   [J, K2] = ${tb.JK2.c} K1   ·   [K1, K2] = ${f3(tb.K1K2.c)} J  (= −2T J)`}</Line><Line data-r="alg" data-kind={tb.kind}>{`${c.alg[tb.kind]}`}</Line></>}
      {lens === 'mirror' && <Line data-r="mir" data-none={img ? 0 : 1}>{img ? `w = (${w[0]}, ${w[1]})  →  w′ = (${f3(img[0], 2)}, ${f3(img[1], 2)})   ·   w′^v = w^v + 2 w^x / T` : c.lab.none}</Line>}
      <p className="eq-cap"><Tx>{c.caps[lens]}</Tx></p>
    </div>}</div>;
}

// =============================================================== 2. horizon or throat: T decides
const U = 38, CY = 190, CXK = 188, CXE = 572;
const ROWCOL = { static: GREY, interior: GREY, photon: GREEN, surface: BLUE };
const MIR = [{ sx: 1, sy: 1 }, { sx: -1, sy: 1 }, { sx: 1, sy: -1 }];
export function NeckWidget({ t }) {
  const n = t.neck, [lens, setLens] = useState('clifford'), [r, setR] = useState(1.3);
  const Ts = E.schwT(r), iS = E.invariants.schw(r), iE = E.invariants.ellis(r);
  const px = (c0, v) => c0 + (v - 1) * 300, py = (v, top, hh) => top + hh - v * hh;       // panels for the curves: r from 1 to 2
  const PAN = [{ c0: 40, name: n.schw }, { c0: 420, name: n.ellis }];
  const curve = (f, c0, top, hh, vmax) => Array.from({ length: 41 }, (_, i) => { const rr = 1 + i / 40; return `${px(c0, rr).toFixed(1)},${py(f(rr) / vmax, top, hh).toFixed(1)}`; }).join(' ');
  const frame = (c0, top, hh, vmax, ylab) => <g><rect x={c0} y={top} width="300" height={hh} fill="none" stroke="currentColor" opacity=".3" /><text x={c0} y={top + hh + 14} fontSize="10.5" fill="currentColor" opacity=".7">r = 1</text><text x={c0 + 300} y={top + hh + 14} fontSize="10.5" textAnchor="end" fill="currentColor" opacity=".7">r = 2</text><text x={c0 - 4} y={top + 8} fontSize="10.5" textAnchor="end" fill="currentColor" opacity=".7">{f3(vmax, 2)}</text><text x={c0 - 4} y={top + hh} fontSize="10.5" textAnchor="end" fill="currentColor" opacity=".7">0</text><text x={c0 + 150} y={top - 8} fontSize="12" textAnchor="middle" fill="currentColor" fontWeight="600">{ylab}</text></g>;
  const kr = Array.from({ length: 31 }, (_, i) => { const T = -3 + i * .2; return [E.kruskalX(r, T), T]; });
  const lk = sgn => kr.map(([X, T]) => `${(CXK + U * sgn * X).toFixed(1)},${(CY - U * T).toFixed(1)}`).join(' ');
  const Le = E.ellisL(r);
  return <div className="eq-card nl-card" data-widget="neck">
    <Slider label={n.r} aria={n.rAria} min={1.02} max={2} step={0.01} value={r} onChange={setR} attr="data-r" extra={<b className="eq-mono nl-val">r = {f3(r, 2)}</b>} />
    <LensChips lenses={['clifford', 'null', 'flow']} value={lens} onPick={setLens} t={t} />
    <svg className="eq-svg nl-svg" style={{ maxWidth: 760 }} viewBox="0 0 760 360" role="img" aria-label={n.aria} data-lens={lens} data-r={f3(r, 3)}>
      {lens === 'clifford' && <g className="nl-neck-cl">
        {PAN.map((p, i) => <g key={i}>{frame(p.c0, 50, 230, 1, p.name)}</g>)}
        <polyline className="nl-c-n2" data-s="schw" points={curve(rr => E.invariants.schw(rr).n2, 40, 50, 230, 1)} fill="none" stroke={BLUE} strokeWidth="3" />
        <polyline className="nl-c-grr" data-s="schw" points={curve(rr => E.invariants.schw(rr).grr, 40, 50, 230, 1)} fill="none" stroke={AMBER} strokeWidth="1.8" strokeDasharray="5 4" />
        <polyline className="nl-c-n2" data-s="ellis" points={curve(rr => E.invariants.ellis(rr).n2, 420, 50, 230, 1)} fill="none" stroke={BLUE} strokeWidth="3" />
        <polyline className="nl-c-grr" data-s="ellis" points={curve(rr => E.invariants.ellis(rr).grr, 420, 50, 230, 1)} fill="none" stroke={AMBER} strokeWidth="2.4" strokeDasharray="5 4" />
        <g className="nl-marks"><circle cx={px(40, r)} cy={py(iS.n2, 50, 230)} r="5" fill={BLUE} /><circle cx={px(420, r)} cy={py(iE.n2, 50, 230)} r="5" fill={BLUE} /><circle cx={px(420, r)} cy={py(iE.grr, 50, 230)} r="5" fill={AMBER} /></g>
        <g><line x1="40" y1="318" x2="62" y2="318" stroke={BLUE} strokeWidth="3" /><text x="68" y="322" fontSize="11.5" fill="currentColor">{n.lab.n2}</text><line x1="40" y1="338" x2="62" y2="338" stroke={AMBER} strokeWidth="2" strokeDasharray="5 4" /><text x="68" y="342" fontSize="11.5" fill="currentColor">{n.lab.grr}</text></g></g>}
      {lens === 'null' && <g className="nl-neck-null">
        {['k', 'e'].map(pp => <g key={pp}><rect x={(pp === 'k' ? CXK : CXE) - 152} y={CY - 114} width="304" height="228" fill="none" stroke="currentColor" opacity=".25" /><line x1={(pp === 'k' ? CXK : CXE) - 152} y1={CY} x2={(pp === 'k' ? CXK : CXE) + 152} y2={CY} stroke="currentColor" opacity=".25" /><line x1={pp === 'k' ? CXK : CXE} y1={CY - 114} x2={pp === 'k' ? CXK : CXE} y2={CY + 114} stroke="currentColor" opacity=".25" /></g>)}
        <text x="36" y="62" fontSize="13" fontWeight="600" fill="currentColor">{n.kruskal}</text><text x="420" y="62" fontSize="13" fontWeight="600" fill="currentColor">{n.ellisChart}</text>
        <text x={CXK + 148} y={CY - 4} fontSize="11" textAnchor="end" fill="currentColor" opacity=".7">X</text><text x={CXK + 4} y={CY - 104} fontSize="11" fill="currentColor" opacity=".7">T</text><text x={CXE + 148} y={CY - 4} fontSize="11" textAnchor="end" fill="currentColor" opacity=".7">ℓ</text><text x={CXE + 4} y={CY - 104} fontSize="11" fill="currentColor" opacity=".7">t</text>
        {K.figs.f1.map((q, i) => MIR.map(m => ((m.sx < 0 && q.mx !== 1) || (m.sy < 0 && q.my !== 1) || q.kind === 'neck') ? null : <line key={i + '-' + m.sx + m.sy} className={'nl-row nl-row-' + q.kind} x1={(q.p === 'k' ? CXK : CXE) + U * m.sx * q.a1} y1={CY - U * m.sy * q.b1} x2={(q.p === 'k' ? CXK : CXE) + U * m.sx * q.a2} y2={CY - U * m.sy * q.b2} stroke={ROWCOL[q.kind]} strokeWidth={q.kind === 'surface' ? 3 : q.kind === 'photon' ? 2.2 : 1.2} strokeDasharray={q.kind === 'interior' ? '4 3' : undefined} opacity={q.kind === 'static' ? .45 : 1} strokeLinecap="round" />))}
        {K.figs.f1.filter(q => q.kind === 'neck').map(q => <circle key={q.p} cx={q.p === 'k' ? CXK : CXE} cy={CY} r="4.5" fill="currentColor" />)}
        <polyline className="nl-live-k" points={lk(1)} fill="none" stroke={AMBER} strokeWidth="2.6" /><polyline className="nl-live-k" points={lk(-1)} fill="none" stroke={AMBER} strokeWidth="2.6" />
        {[-1, 1].map(s => <line key={s} className="nl-live-e" x1={CXE + U * s * Le} y1={CY - 114} x2={CXE + U * s * Le} y2={CY + 114} stroke={AMBER} strokeWidth="2.6" />)}
        <g><line x1="36" y1="326" x2="54" y2="326" stroke={BLUE} strokeWidth="3" /><text x="60" y="330" fontSize="11.5" fill="currentColor">{n.lab.null}</text><line x1="36" y1="344" x2="54" y2="344" stroke={GREEN} strokeWidth="2.2" /><text x="60" y="348" fontSize="11.5" fill="currentColor">{n.lab.photon}</text><line x1="420" y1="326" x2="438" y2="326" stroke={AMBER} strokeWidth="2.6" /><text x="444" y="330" fontSize="11.5" fill="currentColor">{n.lab.live}</text></g></g>}
      {lens === 'flow' && <g className="nl-neck-flow">
        {PAN.map((p, i) => <g key={i}>{frame(p.c0, 50, 230, 0.55, p.name)}</g>)}
        <polyline className="nl-f-dr" data-s="schw" points={curve(E.rates.schw.dr, 40, 50, 230, 0.55)} fill="none" stroke={BLUE} strokeWidth="3" /><polyline className="nl-f-dl" data-s="schw" points={curve(E.rates.schw.dl, 40, 50, 230, 0.55)} fill="none" stroke={AMBER} strokeWidth="2.4" strokeDasharray="5 4" />
        <polyline className="nl-f-dr" data-s="ellis" points={curve(E.rates.ellis.dr, 420, 50, 230, 0.55)} fill="none" stroke={BLUE} strokeWidth="3" /><polyline className="nl-f-dl" data-s="ellis" points={curve(E.rates.ellis.dl, 420, 50, 230, 0.55)} fill="none" stroke={AMBER} strokeWidth="2.4" strokeDasharray="5 4" />
        <g className="nl-marks"><circle cx={px(40, r)} cy={py(E.rates.schw.dr(r) / .55, 50, 230)} r="5" fill={BLUE} /><circle cx={px(40, r)} cy={py(E.rates.schw.dl(r) / .55, 50, 230)} r="5" fill={AMBER} /><circle cx={px(420, r)} cy={py(E.rates.ellis.dr(r) / .55, 50, 230)} r="5" fill={BLUE} /><circle cx={px(420, r)} cy={py(E.rates.ellis.dl(r) / .55, 50, 230)} r="5" fill={AMBER} /></g>
        <g><line x1="40" y1="318" x2="62" y2="318" stroke={BLUE} strokeWidth="3" /><text x="68" y="322" fontSize="11.5" fill="currentColor">{n.lab.dr}</text><line x1="40" y1="338" x2="62" y2="338" stroke={AMBER} strokeWidth="2" strokeDasharray="5 4" /><text x="68" y="342" fontSize="11.5" fill="currentColor">{n.lab.dl}</text></g></g>}
    </svg>
    <div className="nl-readouts" data-lens={lens}>
      <Line data-r="schw">{`${n.schw}: T = ${f3(Ts, 4)}   ·   n·n = −T = ${f3(-iS.n2, 4)}   ·   g^rr = ${f3(-iS.grr, 4)}`}</Line>
      <Line data-r="ellis">{`${n.ellis}: T = 1   ·   n·n = −1   ·   g^rr = ${f3(-iE.grr, 4)}`}</Line>
      {lens === 'flow' && <Line data-r="rates">{`dr/dv = ${f3(E.rates.schw.dr(r), 4)}, dℓ/dv = ${f3(E.rates.schw.dl(r), 4)} (${n.schw})   ·   dr/dv = ${f3(E.rates.ellis.dr(r), 4)}, dℓ/dv = ${f3(E.rates.ellis.dl(r), 4)} (${n.ellis})`}</Line>}
      <p className="eq-cap"><Tx>{n.caps[lens]}</Tx></p>
    </div></div>;
}

// =============================================================== 3. is g_tt = 0 the criterion? Eq. (1) on three null surfaces, and Kerr
const LOGX = v => Math.log10(v);
export function CriterionWidget({ t }) {
  const q = t.crit, [id, setId] = useState('simple'), [lx, setLx] = useState(-2);
  const cs = E.EQ1.find(c => c.id === id), x = 10 ** lx, T = cs.T(x), dT = cs.dT(x), e1 = cs.eq1(x), F = E.Ffac(cs, x);
  const PX = v => 60 + (LOGX(v) + 3) * 150, PY = m => 300 - (LOGX(m) + 12) * 18;
  const names = { simple: 'simple zero', extremal: 'extremal', eq18: 'Eq. (18)' }, colr = { simple: BLUE, extremal: GREEN, eq18: AMBER };
  return <div className="eq-card nl-card" data-widget="crit">
    <Chips items={E.EQ1.map(c => [c.id, q.cases[c.id]])} value={id} onPick={setId} label={q.caseH} attr="data-eq" />
    <Slider label={q.probe} min={-3} max={-0.3} step={0.05} value={lx} onChange={setLx} attr="data-x" extra={<b className="eq-mono nl-val"><Tx>{`x = ${sci(x)}`}</Tx></b>} />
    <svg className="eq-svg nl-svg" style={{ maxWidth: 600 }} viewBox="0 0 560 340" role="img" aria-label={q.aria} data-case={id} data-eq1={e1}>
      {[-12, -9, -6, -3, 0, 3].map(m => <g key={m}><line x1="60" y1={PY(10 ** m)} x2="510" y2={PY(10 ** m)} stroke="currentColor" opacity=".13" /><text x="54" y={PY(10 ** m) + 4} fontSize="10" textAnchor="end" fill="currentColor" opacity=".7"><Pow b="10" e={m} /></text></g>)}
      {[-3, -2, -1, 0].map(m => <g key={m}><line x1={PX(10 ** m)} y1="30" x2={PX(10 ** m)} y2="300" stroke="currentColor" opacity=".13" /><text x={PX(10 ** m)} y="316" fontSize="10" textAnchor="middle" fill="currentColor" opacity=".7"><Pow b="10" e={m} /></text></g>)}
      {E.EQ1.map(c => <polyline key={c.id} className="nl-eq1" data-id={c.id} points={K.figs.f3.filter(r => r.c === names[c.id]).map(r => `${PX(r.x1).toFixed(1)},${PY(r.m1).toFixed(1)} ${PX(r.x2).toFixed(1)},${PY(r.m2).toFixed(1)}`).join(' ')} fill="none" stroke={colr[c.id]} strokeWidth={c.id === id ? 3.4 : 1.6} opacity={c.id === id ? 1 : .4} />)}
      <line x1={PX(x)} y1="30" x2={PX(x)} y2="300" stroke={colr[id]} strokeDasharray="4 3" /><circle className="nl-pt" cx={PX(x)} cy={PY(e1)} r="5" fill={colr[id]} />
      <text x="300" y="334" fontSize="11" textAnchor="middle" fill="currentColor">{q.lab.x}</text><text x="12" y="20" fontSize="11" fill="currentColor">{q.lab.y}</text></svg>
    <div className="nl-readouts">
      <Line data-r="T">{`T = ${sci(T)}   ·   dT/dx = ${sci(dT)}   ·   |Eq. (1)| = T (dT/dx)² = ${sci(e1)}`}</Line>
      <Line data-r="F">{`F = −(dT/dx)²/2 = ${sci(F)}   ·   n·n = −T = ${sci(-T)} → 0`}</Line>
      <p className="eq-cap"><Tx>{q.caps[id]}</Tx></p></div></div>;
}

export function KerrWidget({ t }) {
  const q = t.kerr, [deg, setDeg] = useState(60), th = deg * Math.PI / 180, w = Math.cos(th) ** 2, rE = E.kerrErgo(w), nn = E.kerrNN(w);
  const u = 14, cx = 250, cy = 165, P = ([a, b], sx, sy) => [cx + u * sx * a, cy - u * sy * b];
  const path = r => Array.from({ length: 61 }, (_, i) => { const a = Math.PI * i / 60, p = E.kerrXZ(typeof r === 'function' ? r(Math.cos(a) ** 2) : r, a); return p; });
  const pol = (pts, sx) => pts.map(p => P(p, sx, 1).map(v => v.toFixed(1)).join(',')).join(' ');
  const hz = path(E.KERR.rh), eg = path(r => E.kerrErgo(r));
  const mk = E.kerrXZ(rE, th), pole = Math.abs(w - 1) < 1e-9;
  return <div className="eq-card nl-card" data-widget="kerr">
    <Slider label={q.theta} min={0} max={90} step={1} value={deg} onChange={setDeg} attr="data-theta" extra={<b className="eq-mono nl-val">θ = {deg}°</b>} />
    <svg className="eq-svg nl-svg" style={{ maxWidth: 560 }} viewBox="0 0 500 330" role="img" aria-label={q.aria} data-theta={deg} data-nn={nn}>
      <line x1="250" y1="14" x2="250" y2="316" stroke="currentColor" opacity=".2" strokeDasharray="3 3" /><line x1="60" y1="165" x2="440" y2="165" stroke="currentColor" opacity=".15" />
      {[1, -1].map(s => <g key={s}><polyline className="nl-horizon" points={pol(hz, s)} fill="none" stroke={BLUE} strokeWidth="2.6" /><polyline className="nl-ergo" points={pol(eg, s)} fill="none" stroke={AMBER} strokeWidth="2.6" /></g>)}
      {[[1, 1], [-1, 1], [1, -1], [-1, -1]].map(([sx, sy], i) => { const p = P(mk, sx, sy); return <circle key={i} className={i === 0 ? 'nl-mark' : ''} cx={p[0]} cy={p[1]} r={i === 0 ? 6 : 3.5} fill={nn < 0 ? AMBER : PURPLE} opacity={i === 0 ? 1 : .55} />; })}
      <text x="250" y="10" fontSize="10.5" textAnchor="middle" fill="currentColor" opacity=".7">{q.lab.axis}</text>
      <g><line x1="20" y1="296" x2="40" y2="296" stroke={BLUE} strokeWidth="2.6" /><text x="46" y="300" fontSize="11.5" fill="currentColor">{q.lab.horizon}</text><line x1="20" y1="314" x2="40" y2="314" stroke={AMBER} strokeWidth="2.6" /><text x="46" y="318" fontSize="11.5" fill="currentColor">{q.lab.ergo}</text></g></svg>
    <div className="nl-readouts">
      <Line data-r="rE">{`cos²θ = ${f3(w, 4)}   ·   r_E = ${f3(rE, 4)}   ·   g_tt(r_E) = ${f3(E.kerrGtt(rE, w), 6)}`}</Line>
      <Line data-r="nn" data-pole={pole ? 1 : 0}>{`${q.nnOf} g_tt = const: ${sci(nn)}   →   ${pole ? q.pole : q.timelike}`}</Line>
      <p className="eq-cap"><Tx>{q.cap}</Tx></p></div></div>;
}

// =============================================================== 4. the horizon's algebra in four lenses
export function LadderWidget({ t }) {
  const L = t.ladder, [n, setN] = useState(4), [lens, setLens] = useState('clifford'), [sel, setSel] = useState(null);
  const row = K.portal.ladder.find(r => r.n === n), m = n - 1, N = 1 << m;
  const cols = Array.from({ length: m + 1 }, () => []); for (let S = 0; S < N; S++) cols[E.popc(S)].push(S);
  const mx = Math.max(...cols.map(c => c.length)), CW = 480 / (m + 1), RH = Math.min(30, 250 / mx);
  const vpos = S => { const k = E.popc(S), j = cols[k].indexOf(S); return [50 + CW * k, 160 + RH * (j - (cols[k].length - 1) / 2)]; };
  const S0 = sel === null || sel >= N ? null : sel;
  const poly = Array.from({ length: m }, (_, i) => { const a = (2 * Math.PI * i) / Math.max(m, 3) - Math.PI / 2 + (m === 2 ? Math.PI / 4 : 0); return m === 1 ? [280, 160] : m === 2 ? [280 + (i ? 70 : -70), 160] : [280 + 100 * Math.cos(a), 165 + 100 * Math.sin(a)]; });
  const gen = i => (i === 0 ? 'ℓ' : 'e' + i);        // simplex generators: vertex 0 is the null generator, 1 .. n-2 are the sphere
  const cl = ((k, x, y, w, h, fill, tx, cls = '') => <g key={k} className={'nl-box ' + cls}><rect x={x} y={y} width={w} height={h} rx="5" fill={fill} fillOpacity=".25" stroke={fill} strokeWidth="1.6" /><text x={x + w / 2} y={y + h / 2 + 4} fontSize="12" textAnchor="middle" fill="currentColor">{tx}</text></g>);
  const nq = E.QUOT[n];
  return <div className="eq-card nl-card" data-widget="ladder">
    <Chips items={E.NS.map(k => [String(k), 'n = ' + k])} value={String(n)} onPick={v => { setN(+v); setSel(null); }} label={L.nH} attr="data-n" />
    <LensChips lenses={['clifford', 'cube', 'simplex', 'prime']} value={lens} onPick={setLens} t={t} />
    <svg className="eq-svg nl-svg" style={{ maxWidth: 600 }} viewBox="0 0 560 320" role={lens === 'cube' ? 'group' : 'img'} aria-label={L.aria} data-n={n} data-lens={lens} data-dim={row.dim} data-j={row.J}>
      {lens === 'clifford' && <g className="nl-lad-cl">
        <text x="20" y="26" fontSize="12" fontWeight="600" fill="currentColor">{L.lab.cell}: {E.CELL[n]}</text>
        {[0, 1, 2, 3].map(i => cl('c' + i, 20 + 112 * (i % 2), 46 + 100 * (i >> 1), 106, 92, GREY, nq, 'nl-q'))}
        <text x="20" y="266" fontSize="11" fill="currentColor" opacity=".8">{L.lab.matrices(nq)}</text>
        <text x="310" y="26" fontSize="12" fontWeight="600" fill="currentColor">{L.lab.horizon}: Cl(0,{n - 2},1)</text>
        {cl('J', 310, 46, 100, 192, AMBER, `J · J = 0`, 'nl-J')}{cl('Q', 420, 46, 100, 192, GREEN, `${L.lab.quot}: ${nq}`, 'nl-Q')}
        <text x="310" y="262" fontSize="11" fill="currentColor">dim = <Pow b="2" e={n - 1} /> = {row.dim}</text><text x="310" y="280" fontSize="11" fill={AMBER}>dim J = <Pow b="2" e={n - 2} /> = {row.J}</text><text x="420" y="280" fontSize="11" fill={GREEN}><Pow b="2" e={n - 2} /> = {row.dim - row.J}</text></g>}
      {lens === 'cube' && <g className="nl-lad-cube">
        {Array.from({ length: N }, (_, S) => Array.from({ length: m }, (_, b) => (S >> b & 1) ? null : [S, S | 1 << b])).flat().filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={vpos(a)[0]} y1={vpos(a)[1]} x2={vpos(b)[0]} y2={vpos(b)[1]} stroke="currentColor" opacity=".18" />)}
        {Array.from({ length: N }, (_, S) => { const [px, qy] = vpos(S), J = E.inJ(n, S); return <g key={S} style={{ cursor: 'pointer' }} role="button" tabIndex={0} aria-pressed={S === S0} aria-label={`${E.blade(n, S)} (${S.toString(2).padStart(m, '0')})${J ? ' · J' : ''}`} onClick={() => setSel(S)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSel(S); } }}><circle className={'nl-lv' + (J ? ' nl-j' : ' nl-qv') + (S === S0 ? ' on' : '')} data-s={S} data-j={J ? 1 : 0} cx={px} cy={qy} r={S === S0 ? 9 : 7} fill={J ? AMBER : GREEN} stroke={S === S0 ? 'currentColor' : 'none'} strokeWidth="2" /></g>; })}
        {cols.map((c, k) => <text key={k} x={50 + CW * k} y="22" fontSize="11" textAnchor="middle" fill="currentColor" opacity=".7">{k}</text>)}
        <text x="20" y="310" fontSize="11" fill="currentColor" opacity=".75">{L.lab.cols}</text></g>}
      {lens === 'simplex' && <g className="nl-lad-simplex">
        {poly.flatMap((a, i) => poly.map((b, j) => (j > i ? [i, j] : null)).filter(Boolean)).map(([i, j]) => <line key={i + '-' + j} className={'nl-se' + (i === 0 ? ' nl-star' : '')} x1={poly[i][0]} y1={poly[i][1]} x2={poly[j][0]} y2={poly[j][1]} stroke={i === 0 ? AMBER : 'currentColor'} strokeWidth={i === 0 ? 3 : 1.4} opacity={i === 0 ? 1 : .45} />)}
        {poly.map((p, i) => <g key={i}><circle className={'nl-sv' + (i === 0 ? ' nl-sv0' : '')} data-i={i} cx={p[0]} cy={p[1]} r={i === 0 ? 10 : 7} fill={i === 0 ? AMBER : GREEN} /><text x={p[0] + (p[0] >= 280 ? 14 : -14)} y={p[1] + (p[1] >= 165 ? 18 : -10)} fontSize="12" textAnchor={p[0] >= 280 ? 'start' : 'end'} fill="currentColor">{gen(i)}</text></g>)}
        <text x="20" y="26" fontSize="12" fill="currentColor">{L.lab.simplex(m)}</text>
        <text x="20" y="300" fontSize="11" fill="currentColor" opacity=".85">{L.lab.starCount(Array.from({ length: m }, (_, k) => E.choose(m - 1, k)))}</text></g>}
      {lens === 'prime' && <g className="nl-lad-prime">
        {[[n, row.dim * 2, L.lab.pCell], [n - 1, row.dim, L.lab.pHor], [n - 2, row.J, L.lab.pJ]].map(([k, val, name], i) => <g key={i} className="nl-pr" data-val={val}><text x="20" y={60 + 80 * i} fontSize="12" fill="currentColor">{name} = {val} = <Pow b="2" e={k} /></text>
          {Array.from({ length: k }, (_, j) => <g key={j}><circle cx={30 + 30 * j} cy={78 + 80 * i} r="11" fill={[BLUE, AMBER, GREEN][i]} fillOpacity=".25" stroke={[BLUE, AMBER, GREEN][i]} strokeWidth="1.6" /><text x={30 + 30 * j} y={82 + 80 * i} fontSize="12" textAnchor="middle" fill="currentColor">2</text></g>)}</g>)}
        <text x="20" y="300" fontSize="11" fill="currentColor" opacity=".85">{L.lab.odd}</text></g>}
    </svg>
    <div className="nl-readouts" data-lens={lens}>
      {lens === 'clifford' && <Line data-r="cl" data-dim={row.dim} data-j={row.J}>{`n = ${n}:  ${E.CELL[n]}  ·  Cl(0,${n - 2},1): dim ${row.dim}, dim J = ${row.J}, ${L.lab.quot} Cl(0,${n - 2}) = ${nq}${n >= 5 ? ' (' + L.lab.std + ')' : ''}`}</Line>}
      {lens === 'cube' && <Line data-r="cube" data-count={E.inJ ? Array.from({ length: N }, (_, S) => S).filter(S => E.inJ(n, S)).length : 0}>{S0 === null ? L.lab.pick(row.J, N) : L.lab.vertex(E.blade(n, S0), S0.toString(2).padStart(m, '0'), E.inJ(n, S0))}</Line>}
      {lens === 'simplex' && <Line data-r="simplex" data-count={row.J}>{L.lab.faces(row.J, m)}</Line>}
      {lens === 'prime' && <Line data-r="prime" data-pow2={[row.dim * 2, row.dim, row.J].every(E.isPow2) ? 1 : 0}>{L.lab.allPow2}</Line>}
      <p className="eq-cap"><Tx>{L.caps[lens]}</Tx></p>
    </div></div>;
}
