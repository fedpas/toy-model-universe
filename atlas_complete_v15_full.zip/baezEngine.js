// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The engine of the Baez widgets (step 19 of the lenses page, BaezWidgets.jsx): pure functions, no React. Everything is exact (integers and fractions;
// the E8 roots in doubled integer coordinates), computed in the browser from the bit rule (labelsEngine.bladeMul) and from plain counting.
// The reference is selfcheck/reports/lens_baez_check.py (checks bzw.P1-P5); its JSON (baezWidgetData.js) is the "stored" side, and
// test_lens_baez_widgets.mjs checks every number below against it. The only floating-point function is keplerOrbit (a picture of a textbook conic).
import { bladeMul } from './labelsEngine.js';

// ---------------------------------------------------------------- exact fractions (numerator / denominator, small integers, always reduced)
const gcd = (a, b) => { a = Math.abs(a); b = Math.abs(b); while (b) [a, b] = [b, a % b]; return a || 1; };
export const fr = (n, d = 1) => { if (d === 0) throw new Error('zero denominator'); const g = gcd(n, d) * (d < 0 ? -1 : 1); return { n: n / g, d: d / g }; };
export const fadd = (x, y) => fr(x.n * y.d + y.n * x.d, x.d * y.d);
export const fsub = (x, y) => fr(x.n * y.d - y.n * x.d, x.d * y.d);
export const fmul = (x, y) => fr(x.n * y.n, x.d * y.d);
export const fdiv = (x, y) => fr(x.n * y.d, x.d * y.n);
export const fneg = x => fr(-x.n, x.d);
export const feq = (x, y) => x.n === y.n && x.d === y.d;
export const fsign = x => Math.sign(x.n);
export const fstr = x => (x.d === 1 ? String(x.n) : `${x.n}/${x.d}`);          // the text Python's str(Fraction) gives: '0', '1', '-2/3', '1/6'
export const ZERO = fr(0), ONE = fr(1);
const fsum = xs => xs.reduce(fadd, ZERO);
export const pc = x => { let c = 0; while (x) { c += x & 1; x >>>= 1; } return c; };

// ================================================================ BW1: five bits, one generation (bzw.P1; baez.H1a-H2d)
// bits 0 and 1 are the two weak switches, bits 2, 3, 4 the three colour switches
export const weakOf = x => pc(x & 3);
export const colourOf = x => pc(x >> 2);
export const hyper = x => fsub(fr(weakOf(x), 2), fr(colourOf(x), 3));          // Y = a/2 - b/3
export const charge = x => fsub(fr(x & 1), fr(colourOf(x), 3));                // Q = (first weak bit) - b/3
export const isospin = x => fr((x & 1) - ((x >> 1) & 1), 2);                   // T3 = (first - second weak bit)/2
export const peirce = (x, s) => fsub(ONE, fr(pc(x ^ s), 4));                   // 1 - d(x, S)/4, d = Hamming distance
export const S_WEAK = 0b00011;
export const flipAll = x => x ^ 31;
// the six pieces of the paper's eqs. (69), (76): Peirce pair (vacuum, weak pair) -> name and hypercharge (data from the paper, not computed)
export const PAPER_PIECES = { '1/2|1': ['e-bar_R', '1'], '1|1/2': ['nu-bar_R', '0'], '1/2|1/2': ['q_L', '1/6'], '0|1/2': ['d-bar_R', '1/3'], '1/2|0': ['u-bar_R', '-2/3'], '0|0': ['l_L', '-1/2'] };
export function labelInfo(x) {
  const even = pc(x) % 2 === 0, l1 = even ? peirce(x, 0) : null, l2 = even ? peirce(x, S_WEAK) : null;
  return { x, a: weakOf(x), b: colourOf(x), N: pc(x), even, Y: fstr(hyper(x)), Q: fstr(charge(x)), T3: fstr(isospin(x)), l1: l1 && fstr(l1), l2: l2 && fstr(l2), piece: even ? (PAPER_PIECES[fstr(l1) + '|' + fstr(l2)] || [null])[0] : null };
}
export const LABELS = Array.from({ length: 32 }, (_, x) => x);
export const EVEN = LABELS.filter(x => pc(x) % 2 === 0);
export const grading = () => [0, 1, 2, 3, 4, 5].map(k => LABELS.filter(x => pc(x) === k).length);
// the family on show: the 16 even labels, or after "flip all five" their complements (the 16 odd labels)
export const family = flipped => (flipped ? EVEN.map(flipAll) : EVEN.slice()).sort((u, v) => u - v);
// classes of a family by (weak bits a, colour bits b), in (a, b) order
export function classesOf(xs) {
  const m = new Map(); for (const x of xs) { const k = weakOf(x) * 10 + colourOf(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
  return [...m.keys()].sort((u, v) => u - v).map(k => { const ls = m.get(k), i = labelInfo(ls[0]);
    return { a: i.a, b: i.b, n: ls.length, labels: ls, Y: i.Y, Q: [...new Set(ls.map(x => fstr(charge(x))))].sort((u, v) => { const p = u.split('/'), q = v.split('/'); return (+p[0] / (+p[1] || 1)) - (+q[0] / (+q[1] || 1)); }), l1: i.l1, l2: i.l2, piece: i.piece }; });
}
// the anomaly sums over a family: sum Y, sum Q, sum Y^3, sum of Y over weak doublets (a = 1), sum of Y over colour (anti)triplets (b = 1 or 2)
export function anomalySums(xs) {
  const Y = xs.map(hyper);
  return { Y: fstr(fsum(Y)), Q: fstr(fsum(xs.map(charge))), Y3: fstr(fsum(Y.map(y => fmul(fmul(y, y), y)))),
    Y_doublets: fstr(fsum(xs.filter(x => weakOf(x) === 1).map(hyper))), Y_triplets: fstr(fsum(xs.filter(x => colourOf(x) === 1 || colourOf(x) === 2).map(hyper))) };
}
export const chargeSum = xs => fstr(fsum(xs.map(charge)));
// the five-mode Fock operators on the labels (Jordan-Wigner sign): how many raise, keep or lower the number of set bits by 2 (bzw.P1b)
function fockOp(seq) {                                                         // seq of ['c' | 'a', i], applied right to left; returns Map x -> [y, sign]
  const out = new Map();
  for (const x of LABELS) { let y = x, s = 1;
    for (let k = seq.length - 1; k >= 0; k--) { const [kind, i] = seq[k]; if (((y >> i) & 1) === (kind === 'c' ? 1 : 0)) { s = 0; break; } s *= pc(y & ((1 << i) - 1)) % 2 ? -1 : 1; y ^= 1 << i; }
    if (s) out.set(x, [y, s]); }
  return out;
}
export function adNDegrees() {
  const ops = []; for (let i = 0; i < 5; i++) for (let j = i + 1; j < 5; j++) ops.push([2, fockOp([['c', i], ['c', j]])]);
  for (let i = 0; i < 5; i++) for (let j = 0; j < 5; j++) ops.push([0, fockOp([['c', i], ['a', j]])]);
  for (let i = 0; i < 5; i++) for (let j = i + 1; j < 5; j++) ops.push([-2, fockOp([['a', i], ['a', j]])]);
  const ok = ops.every(([d, m]) => m.size > 0 && [...m].every(([x, [y]]) => pc(y) - pc(x) === d));
  const c = { 2: 0, 0: 0, '-2': 0 }; for (const [d] of ops) c[d]++;
  return { ok, counts: { 2: c[2], 0: c[0], '-2': c['-2'] } };
}

// ================================================================ E8 in doubled integer coordinates (bzw.P3, P5; baez.E1a-c, T1b)
export const SIMPLE = [[1, -1, -1, -1, -1, -1, -1, 1], [2, 2, 0, 0, 0, 0, 0, 0], [-2, 2, 0, 0, 0, 0, 0, 0], [0, -2, 2, 0, 0, 0, 0, 0], [0, 0, -2, 2, 0, 0, 0, 0],
  [0, 0, 0, -2, 2, 0, 0, 0], [0, 0, 0, 0, -2, 2, 0, 0], [0, 0, 0, 0, 0, -2, 2, 0]];                       // Bourbaki simple roots alpha_1 .. alpha_8, coordinates doubled
export const ip = (u, v) => { let s = 0; for (let i = 0; i < 8; i++) s += u[i] * v[i]; return s / 4; };
const lexDesc = (u, v) => { for (let i = 0; i < 8; i++) if (u[i] !== v[i]) return v[i] - u[i]; return 0; };
let ROOTS = null, COEF = null;
export function e8Roots() {
  if (ROOTS) return ROOTS;
  const rs = [];
  for (let i = 0; i < 8; i++) for (let j = i + 1; j < 8; j++) for (const si of [2, -2]) for (const sj of [2, -2]) { const v = Array(8).fill(0); v[i] = si; v[j] = sj; rs.push(v); }
  for (let m = 0; m < 256; m++) if (pc(m) % 2 === 0) rs.push(Array.from({ length: 8 }, (_, t) => ((m >> (7 - t)) & 1 ? -1 : 1)));
  ROOTS = rs.sort(lexDesc); return ROOTS;
}
export const cartan = () => SIMPLE.map(u => SIMPLE.map(v => ip(u, v)));
export function inverseExact(M) {                                             // Gauss-Jordan over the fractions
  const n = M.length, A = M.map((r, i) => [...r.map(v => fr(v)), ...Array.from({ length: n }, (_, j) => fr(i === j ? 1 : 0))]);
  for (let c = 0; c < n; c++) { let p = c; while (A[p][c].n === 0) p++; [A[c], A[p]] = [A[p], A[c]]; const piv = A[c][c]; A[c] = A[c].map(v => fdiv(v, piv));
    for (let i = 0; i < n; i++) if (i !== c && A[i][c].n !== 0) { const f = A[i][c]; A[i] = A[i].map((v, k) => fsub(v, fmul(f, A[c][k]))); } }
  return A.map(r => r.slice(n));
}
export function coefficients() {                                              // every root as an integer combination of the simple roots
  if (COEF) return COEF;
  const Ci = inverseExact(cartan()); COEF = new Map();
  for (const r of e8Roots()) { const d = SIMPLE.map(a => ip(r, a)); const c = Ci.map(row => fsum(row.map((x, j) => fmul(x, fr(d[j])))));
    if (!c.every(x => x.d === 1)) throw new Error('non-integer coefficient'); COEF.set(r, c.map(x => x.n)); }
  return COEF;
}
export const levi = n => { const C = coefficients(); return e8Roots().filter(r => C.get(r).every((c, m) => m < n || c === 0)); };
export const gradeOne = n => { const C = coefficients(); return levi(n).filter(r => C.get(r)[n - 1] === 1); };
export function ladder() {
  const C = coefficients(), ns = [8, 7, 6, 5, 4, 3], sizes = ns.map(n => levi(n).length);
  const grades = n => { const g = {}; for (const r of levi(n)) { const c = C.get(r)[n - 1]; g[c] = (g[c] || 0) + 1; } return g; };
  const g8 = grades(8);
  return { roots: e8Roots().length, sizes, dims: ns.map((n, i) => n + sizes[i]), g1: [8, 7, 6, 5, 4].map(n => gradeOne(n).length),
    graded: [8, 7, 6, 5, 4].map(n => Object.keys(grades(n)).length), grades8: Object.fromEntries(Object.keys(g8).map(Number).sort((u, v) => u - v).map(k => [String(k), g8[k]])) };
}
// a chain of mutually adjacent roots (inner product 1): the sizes of the common neighbourhoods (the vertex-figure ladder, fibre.G8b)
export function linkChain() {
  const rs = e8Roots(); let level = rs.slice(); const sizes = [level.length];
  while (level.length > 3) { const r = level.slice().sort(lexDesc)[0]; level = level.filter(s => ip(r, s) === 1); sizes.push(level.length); }
  return sizes;
}
// the shadows of the 126 roots of E7 on the plane of alpha_6, alpha_7 (the generation sl3 of the E7 paper): a w6 + b w7, ring N = a^2 + ab + b^2
export function shadows() {
  const pts = new Map(), by = {};
  for (const r of levi(7)) { const a = ip(r, SIMPLE[5]), b = ip(r, SIMPLE[6]), k = a + ',' + b, N = a * a + a * b + b * b; pts.set(k, (pts.get(k) || 0) + 1); by[N] = (by[N] || 0) + 1; }
  const points = [...pts].map(([k, n]) => { const [a, b] = k.split(',').map(Number); return { a, b, n }; }).sort((u, v) => u.a - v.a || u.b - v.b);
  return { points, byRing: by };
}
// Eisenstein rings: the number of lattice points x + y w with x^2 - xy + y^2 = N
export const eisensteinRings = (top = 7) => Array.from({ length: top + 1 }, (_, N) => { let c = 0; for (let x = -12; x <= 12; x++) for (let y = -12; y <= 12; y++) if (x * x - x * y + y * y === N) c++; return c; });
export const eisensteinPoints = (top = 7) => { const out = []; for (let x = -6; x <= 6; x++) for (let y = -6; y <= 6; y++) { const N = x * x - x * y + y * y; if (N <= top) out.push({ x, y, N }); } return out; };

// ================================================================ BW4: Kepler, the fourth square (bzw.P4; baez.K1b, K1c, K2b)
const mvMul = (x, y, sq) => { const o = new Map(); for (const [a, u] of x) for (const [b, v] of y) { const [c, s] = bladeMul(a, b, sq); if (s) o.set(c, fadd(o.get(c) || ZERO, fmul(fr(s), fmul(u, v)))); } for (const [k, v] of o) if (v.n === 0) o.delete(k); return o; };
const mvAdd = (x, y, f = ONE) => { const o = new Map(x); for (const [k, v] of y) o.set(k, fadd(o.get(k) || ZERO, fmul(f, v))); for (const [k, v] of o) if (v.n === 0) o.delete(k); return o; };
const mvEq = (x, y) => x.size === y.size && [...x].every(([k, v]) => y.has(k) && feq(v, y.get(k)));
const comm = (x, y, sq) => mvAdd(mvMul(x, y, sq), mvMul(y, x, sq), fr(-1));
const scale = (x, f) => mvAdd(new Map(), x, f);
export const MOVES = [0b0011, 0b0101, 0b0110, 0b1001, 0b1010, 0b1100];         // e1e2, e1e3, e2e3, e1e4, e2e4, e3e4
export const moveSquare = (m, eps) => bladeMul(m, m, [1, 1, 1, eps])[1] + 0;    // -1 turn, 0 slide, +1 stretch (+ 0 turns a -0 into 0)
export function charpoly(M) {                                                 // Faddeev-LeVerrier over the fractions: c[k] = coefficient of t^k in det(t - M)
  const n = M.length, I = (i, j) => fr(i === j ? 1 : 0), mm = (A, B) => A.map((r, i) => B[0].map((_, j) => fsum(r.map((x, k) => fmul(x, B[k][j])))));
  const c = Array(n + 1).fill(ZERO); c[n] = ONE; let Mk = M.map(r => r.map(() => ZERO));
  for (let k = 1; k <= n; k++) { Mk = mm(M, Mk).map((r, i) => r.map((x, j) => fadd(x, fmul(c[n - k + 1], I(i, j))))); const P = mm(M, Mk); c[n - k] = fneg(fdiv(fsum(P.map((r, i) => r[i])), fr(k))); }
  return c;
}
export function inertia(M) {                                                  // (positive, negative, zero) of a real symmetric matrix: Descartes' rule on its real-rooted charpoly
  const c = charpoly(M.map(r => r.map(v => (typeof v === 'number' ? fr(v) : v)))), n = M.length; let z = 0; while (z < n && c[z].n === 0) z++;
  const changes = s => { let k = 0; for (let i = 1; i < s.length; i++) if (s[i - 1] * s[i] < 0) k++; return k; };
  const pos = changes(c.slice(z).map(fsign).filter(Boolean)), neg = changes(c.map((x, k) => fsign(x) * (k % 2 ? -1 : 1)).slice(z).filter(Boolean));
  return [pos, neg, z];
}
export function kepler(eps) {
  const sq = [1, 1, 1, eps], h = fr(1, 2), mh = fr(-1, 2);
  const L = [new Map([[0b0110, mh]]), new Map([[0b0101, h]]), new Map([[0b0011, mh]])], M = [new Map([[0b1001, mh]]), new Map([[0b1010, mh]]), new Map([[0b1100, mh]])];
  let brackets = true;
  for (const [j, k] of [[0, 1], [1, 2], [2, 0]]) { const l = 3 - j - k; brackets = brackets && mvEq(comm(L[j], L[k], sq), L[l]) && mvEq(comm(L[j], M[k], sq), M[l]) && mvEq(comm(M[j], M[k], sq), scale(L[l], fr(eps))); }
  const basis = [...L, ...M], co = x => basis.map(b => { const [[m, v]] = [...b]; return fdiv(x.get(m) || ZERO, v); });
  const ad = basis.map(x => { const cols = basis.map(y => co(comm(x, y, sq))); return cols[0].map((_, i) => cols.map(col => col[i])); });   // ad[a][i][b]
  const kill = basis.map((_, a) => basis.map((__, b) => fsum(ad[a].map((row, i) => fsum(row.map((x, k) => fmul(x, ad[b][k][i])))))));
  const squares = MOVES.map(m => moveSquare(m, eps));
  let halves = null;
  if (eps === 1) { const A = [0, 1, 2].map(i => scale(mvAdd(L[i], M[i]), h)), B = [0, 1, 2].map(i => scale(mvAdd(L[i], M[i], fr(-1)), h));
    halves = [[0, 1], [1, 2], [2, 0]].every(([j, k]) => mvEq(comm(A[j], A[k], sq), A[3 - j - k]) && mvEq(comm(B[j], B[k], sq), B[3 - j - k])) && A.every(a => B.every(b => comm(a, b, sq).size === 0)); }
  return { eps, brackets, killing: inertia(kill), squares, turn: squares.filter(s => s === -1).length, slide: squares.filter(s => s === 0).length, stretch: squares.filter(s => s === 1).length, halves };
}
export const epsOfEnergy = E => (E < 0 ? 1 : E > 0 ? -1 : 0);                 // M = e / sqrt(-2E): eps = -sign(E)
export const shells = (top = 7) => Array.from({ length: top }, (_, i) => { const n = i + 1; let s = 0; for (let l = 0; l < n; l++) s += 2 * l + 1; return s; });
export const shellsSpin = (top = 7) => Array.from({ length: top }, (_, i) => { const n = i + 1; return n * (n + 1) + n * (n - 1); });
// the picture only (floating point): the Kepler conic r = p / (1 + e cos t) with L = 1 (p = 1) and e = sqrt(1 + 2 E), E >= -1/2; points in the orbit plane
export function keplerOrbit(E, steps = 240, rMax = 9) {
  const e = Math.sqrt(Math.max(0, 1 + 2 * E)), pts = [];
  for (let i = 0; i <= steps; i++) { const t = -Math.PI + (2 * Math.PI * i) / steps, den = 1 + e * Math.cos(t); if (den <= 1e-9) continue; const r = 1 / den; if (r > rMax) continue; pts.push([r * Math.cos(t), r * Math.sin(t)]); }
  return { e, pts };
}

// ================================================================ BW7: the Madelung order (bzw.P5; baez.K3)
export function madelung() {
  const sub = []; for (let n = 1; n <= 8; n++) for (let l = 0; l < n; l++) sub.push([n + l, n, l]);
  sub.sort((u, v) => u[0] - v[0] || u[1] - v[1]); const s19 = sub.slice(0, 19), cum = []; let t = 0;
  for (const [, , l] of s19) { t += 2 * (2 * l + 1); cum.push(t); }
  const closings = cum.filter((c, i) => (i + 1 < s19.length ? s19[i + 1][2] === 0 : true)), periods = closings.map((c, i) => c - (i ? closings[i - 1] : 0));
  return { sub: s19.map(([, n, l]) => [n, l]), cum, closings, periods };
}
export const SUBSHELL = l => 'spdfghi'[l];
// where electron number N (1..118) sits: the subshell being filled, how many it holds so far, the row and where that row closes
export function fillTo(N) {
  const m = madelung(); let i = 0; while (m.cum[i] < N) i++;
  const [n, l] = m.sub[i], before = i ? m.cum[i - 1] : 0, row = m.closings.findIndex(c => c >= N);
  return { index: i, n, l, name: n + SUBSHELL(l), inSub: N - before, cap: 2 * (2 * l + 1), row: row + 1, closesAt: m.closings[row], closed: m.closings.includes(N) };
}

// ================================================================ BW5: the seven papers and the eight lines of Fig. 1 of the report (stored: read from the papers, not computed)
export const PAPERS = ['gauge', 'jordan', 'e7', 'geo', 'kepler', 'tri', 'cospan'];
export const CLUSTER = ['gauge', 'jordan', 'e7', 'geo'];
// kind: cites (a citation found by arXiv number in the text, R1), computed (a link through a shared object that a script computes), ours (our reading), open (an open question)
export const EDGES = [
  { id: 'a', from: 'geo', to: 'gauge', kind: 'cites', checks: ['baez·O1c', 'baez·O3a'] },
  { id: 'b', from: 'jordan', to: 'gauge', kind: 'cites', checks: ['baez·S2'] },
  { id: 'c', from: 'e7', to: 'jordan', kind: 'cites', checks: ['baez·E1b', 'baez·E2d', 'baez·S1'] },
  { id: 'd', from: 'geo', to: 'e7', kind: 'ours', checks: ['baez·E1b', 'baez·E2d'] },
  { id: 'e', from: 'jordan', to: 'kepler', kind: 'computed', checks: ['baez·K4'] },
  { id: 'f', from: 'e7', to: 'kepler', kind: 'ours', checks: ['baez·H3a', 'baez·H3b', 'baez·E3e'] },
  { id: 'g', from: 'e7', to: 'tri', kind: 'computed', checks: ['baez·T1a', 'baez·T1b'] },
  { id: 'h', from: 'gauge', to: 'tri', kind: 'open', checks: ['baez·O3i', 'baez·T3', 'baez·T4'] },
];
export const edgeCounts = () => EDGES.reduce((c, e) => ({ ...c, [e.kind]: (c[e.kind] || 0) + 1 }), {});
