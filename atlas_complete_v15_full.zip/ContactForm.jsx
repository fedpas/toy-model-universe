// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { CONTACT, CONTACT_LIMITS as LIM } from './contactCopy.js';

// The contact form: a modal dialog opened from the footer. It fetches a small puzzle (GET /api/contact), sends one message (POST /api/contact) and shows what the route answered.
// Kept deliberately plain: no cookies, no storage, no script or font from another site; the draft lives in memory only, and is kept if the dialog is closed by accident.
// Keyboard: the focus moves into the dialog, Tab and Shift+Tab stay inside it, Escape closes it, and the focus goes back to the button that opened it.
// The message box has no maxLength: HTML counts UTF-16 units there, while the counter, the check before sending and the route count characters (an emoji is one), re-test T1-9.
export const CONTACT_LINK_STYLE = { background: 'none', border: 0, padding: 0, margin: 0, font: 'inherit', color: '#7fb2ff', textDecoration: 'underline', cursor: 'pointer' };
const STYLE = `
.contact-link:focus-visible,.cf-dialog button:focus-visible,.cf-dialog input:focus-visible,.cf-dialog textarea:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.contact-slot{margin-left:.75em}
.cf-overlay{position:fixed;inset:0;z-index:100;display:flex;justify-content:center;align-items:flex-start;overflow-y:auto;overflow-x:hidden;padding:16px;box-sizing:border-box;background:rgba(5,8,18,.75)}
.cf-dialog{position:relative;box-sizing:border-box;width:100%;max-width:520px;margin:auto;padding:16px 18px;background:var(--bg,#0b1020);color:inherit;border:1px solid rgba(128,128,128,.45);border-radius:12px;box-shadow:0 8px 24px rgba(0,0,0,.35);overflow-wrap:anywhere}
.cf-dialog:focus{outline:none}
.cf-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.cf-head h2{margin:0;font-size:1.25em}
.cf-x{flex:0 0 auto;background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;color:inherit;cursor:pointer;font:inherit;line-height:1;padding:6px 10px;min-width:36px;min-height:36px}
.cf-intro{margin:.6em 0 1em;font-size:.92em;opacity:.85}
.cf-row{display:block;margin:0 0 12px}.cf-row>label,.cf-puzzle label.cf-q{display:block;font-weight:600;margin:0 0 4px}
.cf-row small,.cf-puzzle small{display:block;margin-top:4px;font-size:.82em;opacity:.75}
.cf-dialog input[type=text],.cf-dialog input[type=email],.cf-dialog textarea{display:block;width:100%;min-width:0;box-sizing:border-box;padding:8px 10px;background:transparent;color:inherit;font:inherit;border:1px solid rgba(128,128,128,.55);border-radius:8px}
.cf-dialog textarea{resize:vertical;min-height:7em;max-width:100%}
.cf-count{text-align:right;font-variant-numeric:tabular-nums}
.cf-puzzle{min-width:0;margin:0 0 12px;padding:10px 12px;border:1px solid rgba(128,128,128,.4);border-radius:10px}.cf-puzzle legend{padding:0 6px;font-size:.85em;opacity:.85}
.cf-hp{position:absolute;width:1px;height:1px;margin:-1px;padding:0;border:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap}
.cf-dialog .cf-hp input[type=text]{width:1px;height:1px;min-height:0;padding:0;border:0;margin:0;opacity:0}
.cf-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:6px}
.cf-send,.cf-plain{background:none;border:1px solid rgba(128,128,128,.55);border-radius:8px;color:inherit;cursor:pointer;font:inherit;padding:8px 14px}
.cf-send{background:rgba(80,170,255,.2);border-color:#4aa8ff}.cf-send[aria-disabled=true]{opacity:.6;cursor:default}
.cf-link{background:none;border:0;padding:2px 0;font:inherit;font-size:.85em;color:#7fb2ff;text-decoration:underline;cursor:pointer}
.cf-error{margin:0 0 10px;padding:8px 10px;border:1px solid #f87171;border-left-width:4px;border-radius:8px;color:#f87171}
.cf-thanks h3{margin:.2em 0;color:#34d399;font-size:1.1em}.cf-thanks h3:focus{outline:none}
.cf-sr{position:absolute;width:1px;height:1px;margin:-1px;padding:0;overflow:hidden;clip:rect(0 0 0 0);clip-path:inset(50%);white-space:nowrap;border:0}
@media(max-width:480px){.cf-overlay{padding:8px}.cf-dialog{padding:14px}}
`;
const fmt = (s, v) => String(s).replace(/\{(\w+)\}/g, (_, k) => (k in v ? v[k] : ''));
const chars = s => [...s].length;
const NEW_PUZZLE = new Set(['wrong_answer', 'expired', 'bad_token', 'replayed', 'delivery_failed', 'rejected']);      // the puzzle is spent: ask for another
const FOCUS_ON = { wrong_answer: 'answer', expired: 'answer', bad_token: 'answer', replayed: 'answer', answer_digits: 'answer', too_fast: 'answer', invalid_message: 'message', invalid_name: 'name', invalid_reply: 'reply' };
const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]):not([tabindex="-1"]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';

export default function ContactForm({ lang, open, onClose, audience }) {
  const L = CONTACT[lang] ? lang : 'en', t = CONTACT[L];
  const plain = audience === 'Young Learner';                // the Young Learner gets puzzles and a hint in plain words (?aud=yl; re-test T1-8)
  const [message, setMessage] = useState(''), [name, setName] = useState(''), [reply, setReply] = useState(''), [answer, setAnswer] = useState(''), [website, setWebsite] = useState('');
  const [puzzle, setPuzzle] = useState(null);              // { token, question }
  const [phase, setPhase] = useState('idle');              // idle | loading | ready | failed | sending | sent
  const [err, setErr] = useState(null);                    // { code, retryAfter }: an error code, turned into a sentence when it is drawn, so it follows the language
  const [status, setStatus] = useState('');                // spoken politely by screen readers; not drawn
  const dialogRef = useRef(null), refs = { message: useRef(null), name: useRef(null), reply: useRef(null), answer: useRef(null) }, thanksRef = useRef(null);
  const opener = useRef(null), loadSeq = useRef(0), focusLater = useRef(null);
  const live = useRef({}); live.current = { phase, onClose };

  const requestClose = useCallback(() => { if (live.current.phase !== 'sending') live.current.onClose(); }, []);
  const fail = (code, retryAfter = 0) => setErr({ code, retryAfter });

  // a new puzzle; an error already on the screen stays until the visitor acts
  const loadPuzzle = useCallback(async announce => {
    const seq = ++loadSeq.current;
    setPhase('loading'); setPuzzle(null); setAnswer('');
    try {
      const r = await fetch('/api/contact?lang=' + L + (plain ? '&aud=yl' : ''), { headers: { accept: 'application/json' }, cache: 'no-store', credentials: 'omit' });
      const d = await r.json().catch(() => null);
      if (seq !== loadSeq.current) return;
      if (!r.ok || !d || typeof d.token !== 'string' || typeof d.question !== 'string') { fail(d && d.error === 'not_configured' ? 'not_configured' : 'puzzle_failed'); setPhase('failed'); return; }
      setPuzzle({ token: d.token, question: d.question }); setPhase('ready'); if (announce) setStatus(CONTACT[L].puzzleNew);
    } catch { if (seq === loadSeq.current) { fail('puzzle_failed'); setPhase('failed'); } }
  }, [L, plain]);

  // opening: remember who opened it, lock the page scroll, fetch a puzzle; closing: give the focus back
  useEffect(() => {
    if (!open) return undefined;
    const a = document.activeElement; opener.current = a && a !== document.body ? a : document.querySelector('[data-contact-open]');
    const overflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    setErr(null); setStatus(''); loadPuzzle(false);
    const id = requestAnimationFrame(() => (refs.message.current || dialogRef.current)?.focus());
    return () => { cancelAnimationFrame(id); loadSeq.current++; document.body.style.overflow = overflow; setPuzzle(null); setPhase('idle'); setAnswer(''); setErr(null); setStatus('');      // nothing of the last visit shows when it opens again
      const o = opener.current; if (o && o.isConnected && o.focus) o.focus(); };
  }, [open, L, loadPuzzle]);                                                           // eslint-disable-line react-hooks/exhaustive-deps

  // Escape and Tab are handled on the document, so they work even when the focus has fallen to the page; a focus that lands outside is brought back
  useEffect(() => {
    if (!open) return undefined;
    const inside = () => (dialogRef.current ? [...dialogRef.current.querySelectorAll(FOCUSABLE)].filter(e => e.getClientRects().length) : []);
    const onKey = e => {
      if (e.key === 'Escape') { e.preventDefault(); requestClose(); return; }
      if (e.key !== 'Tab' || !dialogRef.current) return;
      const list = inside(); if (!list.length) { e.preventDefault(); return; }
      const first = list[0], last = list[list.length - 1], a = document.activeElement, here = dialogRef.current.contains(a) && a !== dialogRef.current;
      if (e.shiftKey && (!here || a === first)) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && (!here || a === last)) { e.preventDefault(); first.focus(); }
    };
    const onFocusIn = e => { if (dialogRef.current && !dialogRef.current.contains(e.target)) (inside()[0] || dialogRef.current).focus(); };
    document.addEventListener('keydown', onKey); document.addEventListener('focusin', onFocusIn);
    return () => { document.removeEventListener('keydown', onKey); document.removeEventListener('focusin', onFocusIn); };
  }, [open, requestClose]);

  // focus follows what just happened: the thanks heading, or the field an error is about
  useEffect(() => { if (phase === 'sent') thanksRef.current?.focus(); }, [phase]);
  useEffect(() => {
    const want = focusLater.current; if (!want || phase === 'loading' || phase === 'sending') return;
    focusLater.current = null; const el = refs[want]?.current; if (el) el.focus();
  }, [phase, err]);                                                                    // eslint-disable-line react-hooks/exhaustive-deps

  async function submit(e) {
    e.preventDefault();
    if (phase === 'sending' || phase === 'loading') return;
    setErr(null);
    if (!puzzle) { fail('puzzle_failed'); return; }
    const text = message.replace(/\r\n?/g, '\n').trim();
    if (chars(text) < LIM.min || chars(text) > LIM.max) { focusLater.current = 'message'; fail('invalid_message'); setPhase('ready'); return; }
    if (reply.trim() && !/^\S+@\S+\.\S{2,}$/.test(reply.trim())) { focusLater.current = 'reply'; fail('invalid_reply'); setPhase('ready'); return; }
    if (!/^\s*\d{1,6}\s*$/.test(answer)) { focusLater.current = 'answer'; fail('answer_digits'); setPhase('ready'); return; }
    setPhase('sending'); setStatus(t.sending);
    try {
      const r = await fetch('/api/contact', { method: 'POST', credentials: 'omit', headers: { 'content-type': 'application/json', accept: 'application/json' }, body: JSON.stringify({ token: puzzle.token, answer: answer.trim(), message, name, reply, website, lang: L }) });
      const d = await r.json().catch(() => null);
      if (r.ok && d && d.ok === true) { setMessage(''); setName(''); setReply(''); setAnswer(''); setPuzzle(null); setStatus(''); setPhase('sent'); return; }
      const code = d && typeof d.error === 'string' && d.error in t.errors ? d.error : 'generic';
      setStatus(''); fail(code, Number(r.headers.get('retry-after')) || 0);
      if (FOCUS_ON[code]) focusLater.current = FOCUS_ON[code];
      if (NEW_PUZZLE.has(code)) await loadPuzzle(true); else setPhase('ready');
    } catch { setStatus(''); fail('network'); setPhase('ready'); }
  }

  if (!open) return <style>{STYLE}</style>;
  const sentenceOf = ({ code, retryAfter }) => fmt(code === 'rate_limited' && retryAfter > 0 ? t.errors.rate_limited_in : t.errors[code] || t.errors.generic, { min: LIM.min, max: LIM.max, nameMax: LIM.name, m: Math.max(1, Math.ceil(retryAfter / 60)) });
  const busy = phase === 'sending';
  return <>
    <style>{STYLE}</style>
    <div className="cf-overlay" onMouseDown={e => { if (e.target === e.currentTarget) requestClose(); }}>
      <div className="cf-dialog" role="dialog" aria-modal="true" aria-labelledby="cf-title" aria-describedby="cf-intro" ref={dialogRef} tabIndex={-1} lang={L}>
        <div className="cf-head"><h2 id="cf-title">{t.title}</h2><button type="button" className="cf-x" aria-label={t.close} onClick={requestClose}><span aria-hidden="true">×</span></button></div>
        <p className="cf-intro" id="cf-intro">{t.intro}</p>
        {phase === 'sent' ? <div className="cf-thanks">
          <h3 id="cf-thanks" tabIndex={-1} ref={thanksRef}>{t.thanksTitle}</h3><p>{t.thanks}</p>
          <div className="cf-actions"><button type="button" className="cf-send" onClick={requestClose}>{t.close}</button></div>
        </div> : <form noValidate onSubmit={submit} aria-busy={busy}>
          <div className="cf-row"><label htmlFor="cf-message">{t.fields.message}</label>
            <textarea id="cf-message" name="message" ref={refs.message} rows={6} required aria-required="true" aria-describedby="cf-message-help cf-message-count" value={message} onChange={e => setMessage(e.target.value)} />
            <small id="cf-message-help">{fmt(t.fields.messageHelp, { min: LIM.min, max: LIM.max })}</small><small className="cf-count" id="cf-message-count">{fmt(t.fields.counter, { n: chars(message.trim()), max: LIM.max })}</small></div>
          <div className="cf-row"><label htmlFor="cf-name">{t.fields.name}</label>
            <input type="text" id="cf-name" name="name" ref={refs.name} maxLength={LIM.name} autoComplete="name" value={name} onChange={e => setName(e.target.value)} /></div>
          <div className="cf-row"><label htmlFor="cf-reply">{t.fields.reply}</label>
            <input type="email" id="cf-reply" name="reply" ref={refs.reply} maxLength={LIM.reply} autoComplete="email" inputMode="email" value={reply} onChange={e => setReply(e.target.value)} /></div>
          <div className="cf-hp" aria-hidden="true"><label>Website<input type="text" name="website" tabIndex={-1} autoComplete="off" value={website} onChange={e => setWebsite(e.target.value)} /></label></div>
          <fieldset className="cf-puzzle"><legend>{t.puzzleTitle}</legend>
            <label className="cf-q" htmlFor="cf-answer">{puzzle ? puzzle.question : t.puzzleLoading}</label>
            <input type="text" id="cf-answer" name="answer" ref={refs.answer} inputMode="numeric" pattern="[0-9]*" maxLength={6} autoComplete="off" required aria-required="true" aria-describedby="cf-hint" disabled={!puzzle} value={answer} onChange={e => setAnswer(e.target.value)} />
            <small id="cf-hint">{plain ? t.hintPlain : t.hint} {t.answerHelp}</small>
            {puzzle && !busy && <button type="button" className="cf-link" onClick={() => { setErr(null); loadPuzzle(true); }}>{t.newQuestion}</button>}
          </fieldset>
          {err && <div role="alert" className="cf-error">{sentenceOf(err)}</div>}
          <div className="cf-actions">
            <button type="submit" className="cf-send" aria-disabled={busy || !puzzle}>{busy ? t.sending : t.send}</button>
            {phase === 'failed' && err && err.code !== 'not_configured' && <button type="button" className="cf-plain" onClick={() => { setErr(null); loadPuzzle(false); }}>{t.retry}</button>}
          </div>
        </form>}
        <p className="cf-sr" role="status" aria-live="polite">{status}</p>
      </div>
    </div>
  </>;
}
