// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Tx, SvgTx } from './MathText.jsx';
import { isLearner } from './Formal.jsx';
import { fc, PAPERS } from './fureyCopy.js';
import D from './fureyPapersData.js';
import * as E from './fureyPapersEngine.js';
import { REAL_BLOCKS, COMPLEX_BLOCKS, BLOCK_COLORS } from './findingsData.js';

// The widgets of the Furey page that belong to "Her papers" and "Her 2026 model": the paper timeline, the five checkpoints, the two ladders of reflections, the
// spectra of one generation, the three spaces of the triality paper, the Peirce boards, the charges of the eight lanes, the ten edges, the sixteen axes.
// Every number is read from fureyPapersData.js (the stored output of selfcheck/furey_papers_check.py) or computed by fureyPapersEngine.js (exact integers).
// Each widget takes {lang, profile}; the Young Learner gets plain labels (no formulas, no technical words) on the same picture.
export const FW_STYLE = `
.fw-sec{margin-top:28px;scroll-margin-top:72px}.fw-sec>h3:focus{outline:none}
.fw-w{min-width:0}.fw-w h4{margin:.1em 0 .4em}
.fw-svg{width:100%;height:auto;display:block;max-width:640px;margin:6px auto}
.fw-svg [data-pick],.fw-svg [role=button]{cursor:pointer}.fw-svg [role=button]:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.fw-key{display:flex;flex-wrap:wrap;gap:4px 14px;font-size:.82em;margin:6px 0}.fw-key i{display:inline-block;width:11px;height:11px;border-radius:3px;margin-right:5px;vertical-align:-1px}
.fw-detail{border-top:1px solid rgba(128,128,128,.3);margin-top:8px;padding-top:6px;font-size:.9em}.fw-detail p{margin:.3em 0;overflow-wrap:anywhere}
.fw-sub{font-size:.85em;opacity:.8}.fw-two{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:14px;align-items:start}
.fw-q{margin:.5em 0}.fw-ok{color:#34d399}.fw-no{color:#f87171}
.fw-sel{display:flex;flex-wrap:wrap;gap:10px;align-items:center;font-size:.88em;margin:6px 0}.fw-sel select{font:inherit;color:inherit;background:transparent;border:1px solid rgba(128,128,128,.5);border-radius:6px;padding:2px 6px}
.fw-chk{white-space:normal;overflow-wrap:anywhere;font-size:.82em;background:transparent;padding:0}
@media(max-width:640px){.fw-two{grid-template-columns:1fr}}`;
const INK = '#0b1020';

// ---- shared bits
// a display name written with underscores (ν_e, b_R) drawn with real subscripts, in HTML or in SVG
export function Sc({ s, svg = false }) {
  const parts = []; let last = 0, m; const re = /_([A-Za-zμτ0-9′]+)/g;
  while ((m = re.exec(s))) { if (m.index > last) parts.push(s.slice(last, m.index)); parts.push({ sub: m[1] }); last = m.index + m[0].length; }
  if (last < s.length) parts.push(s.slice(last));
  return <>{parts.map((p, i) => (typeof p === 'string' ? <React.Fragment key={i}>{p}</React.Fragment> : svg
    ? <React.Fragment key={i}><tspan dy="0.347em" fontSize="72%">{p.sub}</tspan><tspan dy="-0.25em">{'​'}</tspan></React.Fragment> : <sub key={i}>{p.sub}</sub>))}</>;
}
export const Chips = ({ items, value, onPick, label }) => <div className="ln-chips" role="group" aria-label={label}>{items.map(([id, txt]) => <button key={id} type="button" className={'ln-chip' + (value === id ? ' on' : '')} aria-pressed={value === id} data-pick={String(id)} onClick={() => onPick(id)}>{typeof txt === 'string' ? <Tx>{txt}</Tx> : txt}</button>)}</div>;
const key = onAct => ({ role: 'button', tabIndex: 0, onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onAct(); } } });
const six = k => { const [n, d = '1'] = String(k).split('/'); return Math.round((6 * +n) / +d); };   // '-2/3' -> -4 (sixths)
const nf = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
const shortName = (nm, lang) => { const r = (nm.includes('=') ? nm.split('=')[1].trim() : nm).replace(/ \(->O\)$/, '').replace(/\+/g, '⊕').replace('Pati-Salam', 'Pati–Salam').replace('Left-Right', lang === 'it' ? 'Sinistra–Destra' : 'Left–Right'); return lang === 'it' ? r.replace('Standard Model', 'Modello Standard') : r; };

// ================================================================================================================================ the six papers
export function Timeline({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.earlier.ylw : C.earlier.w, P = C.earlier.papers, [sel, setSel] = React.useState('nest');
  const i = PAPERS.findIndex(x => x.id === sel), paper = PAPERS[i], cur = P[sel], xs = PAPERS.map((_, k) => 55 + k * 98);
  return <div className="ln-card fw-w" data-fw="timeline"><h4><Tx>{w.timelineH}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 600 112" role="img" aria-label={yl ? 'The six papers on a line, from December 2023 to July 2026' : 'Timeline of the six papers, December 2023 to July 2026'}>
      <line x1="20" y1="46" x2="580" y2="46" stroke="currentColor" strokeOpacity=".4" />
      {PAPERS.map((q, k) => <g key={q.id} data-pick={q.id} aria-label={yl ? w.short[k] : P[q.id].n} {...key(() => setSel(q.id))} onClick={() => setSel(q.id)}>
        <circle cx={xs[k]} cy="46" r={q.id === sel ? 14 : 9} fill={BLOCK_COLORS[k % 5]} stroke={q.id === sel ? 'currentColor' : INK} strokeWidth={q.id === sel ? 2 : 1} />
        <text x={xs[k]} y="50" textAnchor="middle" fontSize="11" fontWeight="700" fill={INK}>{k + 1}</text>
        <text x={xs[k]} y="22" textAnchor="middle" fontSize="11" fill="currentColor">{yl ? w.short[k] : P[q.id].n}</text>
        <text x={xs[k]} y="82" textAnchor="middle" fontSize="10" fill="currentColor" opacity=".8">{q.date[lang === 'it' ? 'it' : 'en']}</text>
        <rect x={xs[k] - 44} y="4" width="88" height="90" fill="transparent" /></g>)}
    </svg>
    <div className="fw-detail" data-paper={sel}>
      <p><b><Tx>{yl ? paper.ty : cur.n}</Tx></b>{yl ? null : <> · <Tx>{cur.t}</Tx></>} · <span>{paper.date[lang === 'it' ? 'it' : 'en']}</span> · {yl ? <span>{paper.ref.replace(':', ' ')}</span> : <code className="ln-id">{paper.ref}</code>}</p>
      {yl ? null : <p className="fw-sub"><Tx>{cur.who}</Tx></p>}
      <p><span className="ln-k"><Tx>{w.builds}</Tx></span> <Tx>{yl ? cur.yb : cur.builds}</Tx></p>
      <p><span className="ln-k"><Tx>{w.repro}</Tx></span> <Tx>{yl ? cur.yr : cur.repro}</Tx></p>
    </div></div>;
}

// ================================================================================================================================ the five checkpoints
const wrap = (t, n) => { const out = []; let line = ''; for (const wd of t.split(' ')) { if ((line + ' ' + wd).trim().length > n && line) { out.push(line); line = wd; } else line = (line + ' ' + wd).trim(); } if (line) out.push(line); return out; };
export function Checkpoints({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.earlier.ylw.cp : C.earlier.w.cp, det = yl ? C.earlier.cpDetailY : C.earlier.cpDetail, [sel, setSel] = React.useState(4);
  const STAT = ['not', 'ok', 'ok', 'ok', 'open'], COL = { not: '#9aa3b8', ok: '#4fd18b', open: '#ffd166' };
  const names = w.name, cur = det[sel];
  return <div className="ln-card fw-w" data-fw="checkpoints"><h4><Tx>{w.h}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 600 140" role="img" aria-label={yl ? 'Five round badges, one for each test' : 'The five checkpoints of Roadmap II'}>
      {names.map((nm, k) => { const x = 60 + k * 120, st = STAT[k];
        return <g key={k} data-pick={k} aria-label={nm} {...key(() => setSel(k))} onClick={() => setSel(k)}>
          <circle cx={x} cy="40" r={k === sel ? 28 : 22} fill={COL[st]} fillOpacity=".9" stroke={k === sel ? 'currentColor' : INK} strokeWidth={k === sel ? 2.5 : 1} strokeDasharray={st === 'not' ? '4 3' : undefined} />
          <text x={x} y="46" textAnchor="middle" fontSize="17" fontWeight="700" fill={INK}>{k + 1}</text>
          <text x={x} y="86" textAnchor="middle" fontSize="10.5" fill="currentColor">{wrap(nm, 19).map((ln, q) => <tspan key={q} x={x} dy={q ? 12 : 0}>{ln}</tspan>)}</text></g>; })}
    </svg>
    <div className="fw-key"><span><i style={{ background: COL.ok }} /><Tx>{w.ok}</Tx></span><span><i style={{ background: COL.not }} /><Tx>{w.not}</Tx></span><span><i style={{ background: COL.open }} /><Tx>{w.notyet}</Tx></span></div>
    <div className="fw-detail" data-checkpoint={sel + 1}>
      <p><span className="ln-k"><Tx>{w.req}</Tx> {sel + 1}</span> <Tx>{cur.she}</Tx></p>
      <p><span className="ln-k"><Tx>{sel < 4 ? w.passes : w.notyet}</Tx></span></p>
      <p><span className="ln-k"><Tx>{w.ours}</Tx></span> <Tx>{cur.ours}</Tx></p></div></div>;
}

// ================================================================================================================================ the two ladders of reflections
export function Cascade({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.earlier.ylw.cascade : C.earlier.w.cascade, [k, setK] = React.useState(0);
  const A = D.roadmap.spin10_line, B = D.roadmap.su5_line, sh = D.roadmap.intersections;
  const SHORT = [sh.vector_spinor, sh.three_way_O, sh.four_way_no_O, sh.five_way_O_H_C];
  const rows = [[w.line1, A, 45, 22], [w.line2, B, 24, 150]];
  const bar = (list, max, y0, kk) => list.map((s, j) => { const x = 40 + j * 108, h = 70 * s.dim / max, on = j === kk;
    return <g key={j}><rect x={x} y={y0 + 70 - h} width="70" height={h} rx="4" fill={BLOCK_COLORS[j % 5]} fillOpacity={on ? 0.95 : 0.35} stroke={on ? 'currentColor' : 'none'} strokeWidth="2" />
      <text x={x + 35} y={Math.min(y0 + 62, y0 + 70 - h + 14)} textAnchor="middle" fontSize="12" fontWeight="700" fill={on ? INK : 'currentColor'} opacity={on ? 1 : 0.75}>{s.dim}</text>
      <text x={x + 35} y={y0 + 86} textAnchor="middle" fontSize="9.5" fill="currentColor" opacity={on ? 1 : 0.7}>{yl ? String(j) : <SvgTx>{shortName(s.name, lang)}</SvgTx>}</text></g>; });
  const refl = (list, kk) => list[kk].reflections.map(r => w.refl ? w.refl[r] : r).join(', ') || (yl ? '—' : '—');
  return <div className="ln-card fw-w" data-fw="cascade"><h4><Tx>{w.h}</Tx></h4>
    <label className="ln-sl"><span><Tx>{w.steps}</Tx></span><input type="range" min="0" max="4" value={k} aria-label={w.steps} onChange={e => setK(+e.target.value)} /><b>{k}</b></label>
    <svg className="fw-svg" viewBox="0 0 580 270" role="img" aria-label={yl ? 'Two ladders of bars: the number of turns left after each mirror is switched on' : 'Dimensions of the two ladders of subalgebras'}>
      {rows.map(([name, list, max, y0], r) => <g key={r}><text x="4" y={y0 - 8} fontSize="11" fill="currentColor" opacity=".85"><SvgTx>{name}</SvgTx></text>{bar(list, max, y0, Math.min(k, list.length - 1))}</g>)}
    </svg>
    <p className="ln-cap">{yl ? <><Tx>{w.dim}</Tx>: <b>{A[k].dim}</b> · <b>{B[Math.min(k, 3)].dim}</b></> : <><Tx>{w.steps}</Tx> (<Tx>{w.line1}</Tx>): <Tx>{refl(A, k)}</Tx> · (<Tx>{w.line2}</Tx>): <Tx>{refl(B, Math.min(k, 3))}</Tx> · <Tx>{w.dim}</Tx> <b>{A[k].dim}</b>, <b>{B[Math.min(k, 3)].dim}</b></>}</p>
    <h4 style={{ marginTop: 12 }}><Tx>{w.short}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 580 120" role="img" aria-label={yl ? 'Four bars: the turns left by the shortcuts of the third paper' : 'Dimensions of the intersections of Roadmap III'}>
      {SHORT.map((d, j) => { const x = 40 + j * 130, h = 62 * d / 24;
        return <g key={j}><rect x={x} y={70 - h} width="80" height={h} rx="4" fill={BLOCK_COLORS[(j + 1) % 5]} fillOpacity=".9" /><text x={x + 40} y={70 - h + 14} textAnchor="middle" fontSize="12" fontWeight="700" fill={INK}>{d}</text>
          <text x={x + 40} y="88" textAnchor="middle" fontSize="9.5" fill="currentColor"><SvgTx>{w.shortNames[j]}</SvgTx></text></g>; })}
    </svg></div>;
}

// ================================================================================================================================ one generation as numbers
const SPEC_KEYS = { Y: 'Y', Q: 'Q', BL: 'B-L' };
const YNAMES = { '1/6': 'Q_L', '-2/3': 'u^c', '1/3': 'd^c', '-1/2': 'L', '1': 'e^c', '0': 'ν^c' };
export function Spectra({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.earlier.ylw.spectra : C.earlier.w.spectra, [which, setWhich] = React.useState('Y');
  const sp = D.roadmap.spectra_on_PsiL[SPEC_KEYS[which]], keys = Object.keys(sp).sort((a, b) => six(a) - six(b)), max = Math.max(...Object.values(sp));
  const tot = Object.values(sp).reduce((a, b) => a + b, 0), s6 = keys.reduce((a, k) => a + sp[k] * six(k), 0), c216 = keys.reduce((a, k) => a + sp[k] * six(k) ** 3, 0);
  const bw = Math.min(64, 520 / keys.length - 8), X = i => 30 + (i + 0.5) * (540 / keys.length);
  return <div className="ln-card fw-w" data-fw="spectra"><h4><Tx>{w.h}</Tx></h4>
    <Chips label={w.which} value={which} onPick={setWhich} items={[['Y', w.Y], ['Q', w.Q], ['BL', w.BL]]} />
    <svg className="fw-svg" viewBox="0 0 600 190" role="img" aria-label={yl ? 'Bars: how many of the 16 members of a family carry each value of the chosen charge' : 'Spectrum of the chosen charge on the 16 states of one left-handed generation'}>
      <line x1="20" y1="140" x2="580" y2="140" stroke="currentColor" strokeOpacity=".4" />
      {keys.map((k, i) => { const h = 100 * sp[k] / max;
        return <g key={k}><rect x={X(i) - bw / 2} y={140 - h} width={bw} height={h} rx="4" fill={BLOCK_COLORS[i % 5]} fillOpacity=".9" /><text x={X(i)} y={140 - h + 15} textAnchor="middle" fontSize="13" fontWeight="700" fill={INK}>{sp[k]}</text>
          <text x={X(i)} y="158" textAnchor="middle" fontSize="11" fill="currentColor">{E.fmtY(six(k))}</text>
          {which === 'Y' && !yl ? <text x={X(i)} y="174" textAnchor="middle" fontSize="10" fill="currentColor" opacity=".8"><SvgTx>{YNAMES[k] || ''}</SvgTx></text> : null}</g>; })}
    </svg>
    <p className="ln-cap"><Tx>{w.total}</Tx>: <b>{tot}</b> · <Tx>{w.sum}</Tx>: <b data-sum={s6}>{s6 === 0 ? '0' : s6 + '/6'}</b> · <Tx>{w.cubes}</Tx>: <b data-cubes={c216}>{c216 === 0 ? '0' : c216 + '/216'}</b></p></div>;
}

// ================================================================================================================================ the three spaces of Trialities
export function Triality({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.earlier.ylw.tri : C.earlier.w.tri, [sel, setSel] = React.useState('+');
  const T = D.trialities, sp = T.spectra[sel].y, keys = Object.keys(sp).sort((a, b) => six(a) - six(b)), max = 12, id = ['+', '-', 'V'], lab = yl ? w.pick : ['Ψ⁺', 'Ψ⁻', 'V'];
  const tot = Object.values(sp).reduce((a, b) => a + b, 0), X = i => 30 + (i + 0.5) * (540 / keys.length), bw = Math.min(60, 520 / keys.length - 8);
  const e7 = T.tri_dims.H + T.tri_dims.O + 3 * 4 * 8, e8 = 2 * T.tri_dims.O + 3 * 8 * 8, t39 = T.tri_dims.C + T.tri_dims.H + T.tri_dims.O;
  return <div className="ln-card fw-w" data-fw="triality"><h4><Tx>{w.h}</Tx></h4>
    <Chips label={w.h} value={sel} onPick={setSel} items={id.map((x, i) => [x, lab[i]])} />
    <svg className="fw-svg" viewBox="0 0 600 170" role="img" aria-label={yl ? 'Bars: how many places of the chosen box carry each charge size' : 'Hypercharge spectrum of the chosen space of the triality triple'}>
      <line x1="20" y1="130" x2="580" y2="130" stroke="currentColor" strokeOpacity=".4" />
      {keys.map((k, i) => { const h = 100 * sp[k] / max;
        return <g key={k}><rect x={X(i) - bw / 2} y={130 - h} width={bw} height={h} rx="4" fill={BLOCK_COLORS[i % 5]} fillOpacity=".9" /><text x={X(i)} y={130 - h + 14} textAnchor="middle" fontSize="12" fontWeight="700" fill={INK}>{sp[k]}</text>
          <text x={X(i)} y="148" textAnchor="middle" fontSize="11" fill="currentColor">{E.fmtY(six(k))}</text></g>; })}
    </svg>
    <p className="ln-cap"><Tx>{w.real}</Tx>: <b>{tot}</b>{yl ? null : <> · <Tx>{w.rank}</Tx> <b>{T.rank_su3}</b> · <Tx>{w.rank2}</Tx> <b>{T.rank_su2[sel]}</b></>}</p>
    <h4 style={{ marginTop: 10 }}><Tx>{w.dims}</Tx></h4>
    <p className="ln-mono" data-dims="1">{yl ? <>{T.tri_dims.H} + {T.tri_dims.O} + {3 * 4 * 8} = <b>{e7}</b> · {T.tri_dims.O} + {T.tri_dims.O} + {3 * 8 * 8} = <b>{e8}</b></> : <><Tx>{C.earlier.w.tri.tri}</Tx> = {T.tri_dims.C} + {T.tri_dims.H} + {T.tri_dims.O} = <b>{t39}</b> · e₇: {T.tri_dims.H} + {T.tri_dims.O} + 3·(4·8) = <b>{e7}</b> · e₈: {T.tri_dims.O} + {T.tri_dims.O} + 3·(8·8) = <b>{e8}</b></>}</p>
    <p className="ln-cap" data-ok={e7 === T.e7 && e8 === T.e8 ? '1' : '0'}>{e7 === T.e7 && e8 === T.e8 ? <span className="fw-ok">✓</span> : <span className="fw-no">✗</span>} {T.e7} · {T.e8}</p></div>;
}

// ================================================================================================================================ the Peirce boards
const COLS_REAL = [0, 1, 2, 3, 4, 4];
export function Peirce({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.findings.ylw.peirce : C.findings.w.peirce, [mode, setMode] = React.useState('real'), [sel, setSel] = React.useState([1, 1]);
  const blocks = mode === 'real' ? REAL_BLOCKS : COMPLEX_BLOCKS, N = blocks.reduce((a, b) => a + b, 0), S = 250, c = S / N, off = []; let o = 0;
  blocks.forEach(n => { off.push(o); o += n; });
  const diag = blocks.reduce((a, n) => a + n * n, 0), [si, sj] = sel[0] < blocks.length && sel[1] < blocks.length ? sel : [0, 0];
  const col = i => BLOCK_COLORS[mode === 'real' ? COLS_REAL[i] : i];
  const B = mode === 'cx' ? E.BLOCKS : null;
  const detail = () => {
    if (si === sj) {
      const n = blocks[si];
      if (mode === 'cx') { const b = B[si]; return yl ? <p><Tx>{w.block}</Tx> <b>{si + 1}</b> · <Tx>{w.size}</Tx> <b>{n}</b></p>
        : <><p><Tx>{w.block}</Tx> <b>{si + 1}</b> <code className="ln-id"><Tx>{b.name}</Tx></code> · <Tx>{w.size}</Tx> {n} · <Tx>{w.irrep}</Tx> {E.fmtShow(E.blockIrrep(b))}</p><p><Tx>{w.charge}</Tx>: {b.q.map((q, i) => <span key={i}>{i ? ', ' : ''}{E.fmtQ(q)}</span>)}</p></>; }
      return <p><Tx>{w.block}</Tx> <b>{si + 1}</b> · <Tx>{w.size}</Tx> <b>{n}</b> · {n} × {n} = {n * n}</p>;
    }
    const a = blocks[si], b = blocks[sj];
    if (mode === 'cx' && !yl) { const x = E.cell(si, sj); return <p><Tx>{w.block}</Tx> {si + 1} → {sj + 1}: {a} × {b} = {a * b} · {E.fmtShow(x)}, {E.dimOf(x)}ℂ</p>; }
    return <p><Tx>{w.block}</Tx> {yl ? <>{si + 1}, {sj + 1}</> : <>{si + 1} → {sj + 1}</>}: {a} × {b} = {a * b}</p>;
  };
  return <div className="ln-card fw-w" data-fw="peirce"><h4><Tx>{w.h}</Tx></h4>
    <Chips label={w.h} value={mode} onPick={m => { setMode(m); setSel([1, 1]); }} items={[['real', w.real], ['cx', w.cx]]} />
    <div className="fw-two"><div>
      <svg className="fw-svg" viewBox={`-4 -4 ${S + 8} ${S + 8}`} style={{ maxWidth: 300 }} role="img" aria-label={yl ? 'A square board cut into coloured squares along the diagonal' : 'Peirce blocks of the board'} data-mode={mode}>
        {blocks.flatMap((ni, i) => blocks.map((nj, j) => <rect key={i + '-' + j} x={off[j] * c} y={off[i] * c} width={nj * c} height={ni * c} fill={i === j ? col(i) : 'currentColor'} fillOpacity={i === j ? 0.9 : 0.1} stroke="currentColor" strokeOpacity=".5" strokeWidth={i === si && j === sj ? 3 : 0.8} data-pick={i + ',' + j} aria-label={`${i + 1}, ${j + 1}`} {...key(() => setSel([i, j]))} onClick={() => setSel([i, j])} />))}
        {blocks.map((n, i) => <text key={'t' + i} x={(off[i] + n / 2) * c} y={(off[i] + n / 2) * c + 5} textAnchor="middle" fontSize={n > 1 ? 16 : 11} fontWeight="700" fill={INK} pointerEvents="none">{n}</text>)}
      </svg>
    </div><div>
      <p className="ln-cap"><Tx>{mode === 'real' ? w.real2 : w.cx2}</Tx></p>
      <table className="ln-tab"><tbody><tr><th scope="row"><Tx>{w.diag}</Tx></th><td data-diag={diag}>{diag}</td></tr><tr><th scope="row"><Tx>{w.off}</Tx></th><td data-off={N * N - diag}>{N * N - diag}{mode === 'cx' && !yl ? 'ℂ' : ''}</td></tr></tbody></table>
      <div className="fw-detail" data-block={si + ',' + sj}>{detail()}</div>
      {mode === 'cx' ? <p className="ln-cap"><Tx>{w.glue}</Tx></p> : null}
    </div></div></div>;
}

// ================================================================================================================================ Y and Q on the eight lanes
export function Charges({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.findings.ylw.charges : C.findings.w.charges, [which, setWhich] = React.useState('Y'), [shift, setShift] = React.useState(false);
  // eight states, each value in 24ths: Y comes in sixths (x4), Q in thirds (x8); the shift 3/8 is 9/24
  const vals = E.BLOCKS.flatMap(b => (which === 'Y' ? Array(b.n).fill(b.y * 4) : b.q.map(q => q * 8))), blk = E.BLOCKS.flatMap((b, k) => Array(b.n).fill(k)), sh = shift ? 9 : 0, tot = vals.reduce((a, b) => a + b - sh, 0);
  const Z = 150;   // 5 px per 24th: the tallest bar (Y = 1, 24/24) is 120 px
  const fmt24 = v => { if (v === 0) return '0'; const g = (a, b) => (b ? g(b, a % b) : Math.abs(a)), k = g(v, 24); return (v < 0 ? '−' : '') + Math.abs(v / k) + (24 / k === 1 ? '' : '/' + 24 / k); };
  return <div className="ln-card fw-w" data-fw="charges"><h4><Tx>{w.h}</Tx></h4>
    <Chips label={w.which} value={which} onPick={setWhich} items={[['Y', yl ? w.Y : 'Y'], ['Q', yl ? w.Q : 'Q']]} />
    <label className="ln-chip" style={{ display: 'inline-flex', gap: 6, alignItems: 'center', cursor: 'pointer' }}><input type="checkbox" checked={shift} onChange={e => setShift(e.target.checked)} data-shift="1" /> <Tx>{w.shift}</Tx></label>
    <svg className="fw-svg" viewBox="0 0 600 220" role="img" aria-label={yl ? 'Eight bars, one for each lane, showing its charge' : 'Y or Q on each of the eight complex dimensions'}>
      <line x1="20" y1={Z} x2="580" y2={Z} stroke="currentColor" strokeOpacity=".5" />
      {vals.map((v, i) => { const x = 40 + i * 68, d = v - sh, h = Math.abs(d) * 5, y = d >= 0 ? Z - h : Z;
        return <g key={i}><rect x={x} y={y} width="48" height={Math.max(h, 1)} rx="3" fill={BLOCK_COLORS[blk[i]]} fillOpacity=".9" />
          <text x={x + 24} y={d >= 0 ? y - 5 : y + h + 13} textAnchor="middle" fontSize="11" fill="currentColor">{fmt24(d)}</text><text x={x + 24} y="212" textAnchor="middle" fontSize="10" fill="currentColor" opacity=".7">{i + 1}</text></g>; })}
    </svg>
    <p className="ln-cap"><Tx>{w.trace}</Tx>: <b data-trace={tot}>{fmt24(tot)}</b>{!shift && !yl ? <> · <Tx>{w.mean}</Tx></> : null}</p></div>;
}

// ================================================================================================================================ the ten edges
export function Edges({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.findings.ylw.edges : C.findings.w.edges, T = C.threegen, [sel, setSel] = React.useState('1,2');
  const R = 105, cx = 190, cy = 150, pts = E.BLOCKS.map((_, i) => { const a = -Math.PI / 2 + i * 2 * Math.PI / 5; return [cx + R * Math.cos(a), cy + R * Math.sin(a)]; });
  const edges = []; for (let a = 0; a < 5; a++) for (let b = a + 1; b < 5; b++) edges.push([a, b]);
  const [ea, eb] = sel.split(',').map(Number), x = E.cell(ea, eb), t = E.typeOfCell(ea, eb), first = E.isFirstSetCell(ea, eb), lab = (r, c) => E.FIG1[r + ',' + c];
  const tn = tt => tt.replace('nu_', 'ν_'), nameOf = tt => (yl ? <Tx>{T.typeName[tt]}</Tx> : <Sc s={tn(tt)} />);
  return <div className="ln-card fw-w" data-fw="edges"><h4><Tx>{w.h}</Tx></h4>
    <div className="fw-two"><div>
      <svg className="fw-svg" viewBox="0 0 380 300" style={{ maxWidth: 380 }} role="img" aria-label={yl ? 'Five circles joined by ten links; the colour of a link tells which kind of particle it matches' : 'Five Peirce blocks joined by the ten edges, coloured by Standard Model type'}>
        {edges.map(([a, b]) => { const k = a + ',' + b, on = k === sel, ty = E.typeOfCell(a, b), f = E.isFirstSetCell(a, b), cap = E.capacity(a, b);
          return <g key={k} data-pick={k} aria-label={yl ? `${w.pick} ${a + 1} ${b + 1}` : `edge ${a + 1}–${b + 1}`} {...key(() => setSel(k))} onClick={() => setSel(k)}>
            <line x1={pts[a][0]} y1={pts[a][1]} x2={pts[b][0]} y2={pts[b][1]} stroke={E.TYPE_COLOUR[ty]} strokeWidth={(on ? 3 : 0) + 1.5 + cap / 3} strokeOpacity={f ? 0.95 : 0.55} strokeDasharray={f ? undefined : '6 4'} />
            <line x1={pts[a][0]} y1={pts[a][1]} x2={pts[b][0]} y2={pts[b][1]} stroke="transparent" strokeWidth="16" /></g>; })}
        {pts.map(([px, py], i) => <g key={i}><circle cx={px} cy={py} r={13 + 3 * E.BLOCKS[i].n} fill={BLOCK_COLORS[i]} stroke={INK} /><text x={px} y={py + 4} textAnchor="middle" fontSize="13" fontWeight="700" fill={INK}>{E.BLOCKS[i].n}</text>
          <text x={px} y={py + (py < cy ? -26 - 3 * E.BLOCKS[i].n + 3 : 34 + 3 * E.BLOCKS[i].n - 3)} textAnchor="middle" fontSize="10" fill="currentColor">{yl ? i + 1 : <SvgTx>{E.BLOCKS[i].name}</SvgTx>}</text></g>)}
      </svg>
      <div className="fw-key">{E.TYPES.map(tt => <span key={tt}><i style={{ background: E.TYPE_COLOUR[tt] }} />{yl ? <Tx>{T.typeName[tt]}</Tx> : <Sc s={tn(tt)} />}</span>)}</div>
      <p className="ln-cap"><span className="fw-sub">{'━'} <Tx>{w.first}</Tx> · {'┅'} <Tx>{w.extra}</Tx></span></p>
    </div><div className="fw-detail" style={{ borderTop: 0, marginTop: 0 }} data-edge={sel}>
      <p><b>{yl ? w.pick : w.edge} {ea + 1}–{eb + 1}</b> · <Tx>{w.cap}</Tx> <b>{E.capacity(ea, eb)}</b>{yl ? null : <> <span className="fw-sub">(<Tx>{w.capUnit}</Tx>)</span></>}</p>
      <p><Tx>{w.type}</Tx>: <b>{nameOf(t)}</b> · <span className={first ? 'fw-ok' : ''}><Tx>{first ? w.first : w.extra}</Tx></span></p>
      {yl ? null : <><p><Tx>{w.irrep}</Tx>: {E.fmtShow(x)} · <Tx>{w.conj}</Tx>: {E.fmtShow(E.dual(x))}</p>
        <p><Tx>{w.label}</Tx>: {lab(ea, eb).map((l, i) => <span key={i}>{i ? ', ' : ''}<Sc s={E.labelText(l)} /></span>)} · {lab(eb, ea).map((l, i) => <span key={i}>{i ? ', ' : ''}<Sc s={E.labelText(l)} /></span>)}</p>
        <p><Tx>{w.charges}</Tx>: {E.cellCharges(ea, eb).map((q, i) => <span key={i}>{i ? ', ' : ''}{E.fmtQ(q.q)}{q.n > 1 ? ' ×' + q.n : ''}</span>)}</p></>}
    </div></div></div>;
}

// ================================================================================================================================ the sixteen axes
export function Axes({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.findings.ylw.axes : C.findings.w.axes, seq = [];
  REAL_BLOCKS.forEach((n, i) => { for (let k = 0; k < n; k++) seq.push(i); });
  return <div className="ln-card fw-w" data-fw="axes"><h4><Tx>{w.h}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 400 100" role="img" aria-label={yl ? 'Sixteen lanes drawn side by side, coloured in groups' : 'The 16 coordinate axes, coloured by block'}>
      {seq.map((b, i) => <g key={i}><rect x={8 + i * 24} y="14" width="20" height="40" rx="4" fill={BLOCK_COLORS[COLS_REAL[b]]} fillOpacity=".9" stroke={INK} /><text x={18 + i * 24} y="70" textAnchor="middle" fontSize="9" fill="currentColor">{i}</text></g>)}
      <text x="200" y="92" textAnchor="middle" fontSize="10" fill="currentColor">{w.sum}</text>
    </svg></div>;
}

export { INK, nf, six };
