// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The filter the chat page applies to a model's answer before rendering it (lib/answerFilter.js, audit L6-013 / re-test T1-1): no image from anywhere,
// a live link only to https://, code, math and tables left as typed; safe on every prefix of a streaming answer; a fixed point; fast on hostile input;
// and wired into App.jsx (ChatResponse and the live region) without the renderer props that streamdown does not read. No network, no browser.
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
import { filterAnswer as f } from './lib/answerFilter.js';
const errs = []; let n = 0; const ok = (c, m) => { n++; if (!c) errs.push(m); };
const eq = (inp, want, why) => { const got = f(inp); ok(got === want, `${why}: ${JSON.stringify(inp)} -> ${JSON.stringify(got)}, expected ${JSON.stringify(want)}`); };

// ---- images: every form becomes its alt text (or nothing)
eq('![alt](https://evil.invalid/x.png)', 'alt', 'inline image, https');
eq('a ![](data:image/png;base64,AAAA) b', 'a  b', 'data image, empty alt');
eq('![a cat](http://evil.invalid/c.png "title")', 'a cat', 'image with a title');
eq('![alt][r]\n\n[r]: https://evil.invalid/x.png', 'alt\n\n[r]: https://evil.invalid/x.png', 'full reference image (the https definition stays, it defines a link at most)');
eq('![alt][] and ![alt2]', 'alt and alt2', 'collapsed and shortcut reference images');
eq('![*bold* alt](https://evil.invalid/x.png)', '*bold* alt', 'alt keeps its own Markdown');
eq('![a ![b](https://e.invalid/b.png) c](https://e.invalid/a.png)', 'a b c', 'nested images');
eq('<img src="https://evil.invalid/x.png" alt="a cat"> end', 'a cat end', 'raw <img> with alt');
eq('<IMG SRC=x onerror=alert(1)>', '', 'raw <IMG>, upper case, no alt');
eq("<img alt='q' src='https://e.invalid/q.png'/>", 'q', 'raw self-closing <img/>');
eq('[![img](https://evil.invalid/i.png)](https://ok.example/x)', '[img](https://ok.example/x)', 'an image inside an https link: the image goes, the link stays');
eq('[foo]![](https://e.invalid/x)(javascript:z)', 'foo', 'removing an empty image must not create a new link (fixed point)');

// ---- links: only https:// stays live
for (const [t, why] of [['javascript:alert(1)', 'javascript:'], ['JaVaScRiPt:alert(1)', 'mixed-case javascript:'], ['data:text/html,<b>x</b>', 'data:'], ['http://x.example/', 'http:'],
  ['/relative/page', 'relative'], ['//evil.invalid/x', 'protocol-relative'], ['#frag', 'fragment'], ['mailto:someone@example.com', 'mailto:'], ['  javascript:x ', 'spaces around'], ['<javascript:x>', 'angle brackets'],
  ['', 'empty'], ['https:evil.invalid', 'https: without //'], ['vbscript:x', 'vbscript:'], ['http://x.example "https://y"', 'http with an https title']])
  eq(`see [the text](${t}) now`, 'see the text now', `link target ${why}`);
eq('[t](https://ok.example/x "title")', '[t](https://ok.example/x "title")', 'https link with a title stays');
eq('[t](HTTPS://OK.EXAMPLE)', '[t](HTTPS://OK.EXAMPLE)', 'HTTPS in capitals stays');
eq('[t](<https://ok.example/a b>)', '[t](<https://ok.example/a b>)', 'https in angle brackets stays');
eq('[w](https://en.wikipedia.org/wiki/Foo_(bar)) after', '[w](https://en.wikipedia.org/wiki/Foo_(bar)) after', 'balanced parentheses in an https target');
eq('[a [b](javascript:c) d](https://ok.example)', '[a b d](https://ok.example)', 'a bad link inside an https link');
eq('[x](https://ok.example/a "t\nu")', 'x', 'a kept link never spans two lines: one that does is shown as text');
eq('[t](https://ok.example/ <b>)', '[t](https://ok.example/ \\<b>)', 'not a link target (unquoted title): the brackets stay text');
eq('<https://ok.example/a>, <http://x.example>, <javascript:alert(1)>, <someone@example.com>', '<https://ok.example/a>, http&#58;//x.example, javascript&#58;alert(1), someone&#64;example.com', 'autolinks: only https keeps its brackets; the others cannot be autolinked again (V1-4)');
eq('[r]: javascript:x\n[s]: https://ok.example\n[^1]: a note\n[u]:\n  http://x.example', '\\[r]: javascript:x\n[s]: https://ok.example\n[^1]: a note\n\\[u]:\n  http&#58;//x.example', 'reference definitions: non-https escaped, https and footnotes kept');
eq('see [the docs][d]\n\n[d]: http://x.example', 'see [the docs][d]\n\n\\[d]: http&#58;//x.example', 'a reference link to an http definition is left without a target');

// ---- raw tags
eq('<a href="javascript:x">t</a> <a href="https://ok.example">u</a>', '\\<a href="javascript:x">t\\</a> \\<a href="https://ok.example">u\\</a>', 'raw <a>: every raw tag is shown as text (V1-1, V1-2)');
eq('<iframe src="https://e.invalid"></iframe>', '\\<iframe src="https://e.invalid">\\</iframe>', '<iframe> escaped');
eq('<script>window.__pwn = 1</script>', '\\<script>window.__pwn = 1\\</script>', '<script> escaped');
eq('<div style="background:url(https://e.invalid/x)">d</div>', '\\<div style="background:url(https://e.invalid/x)">d\\</div>', 'a tag with style escaped');
eq('<span onclick="x()">s</span>', '\\<span onclick="x()">s\\</span>', 'a tag with an event handler escaped');
eq('<video poster="https://e.invalid/p.png">', '\\<video poster="https://e.invalid/p.png">', '<video> escaped');
eq('<b>bold</b>, <sub>2</sub>, <br>, <!-- note -->', '\\<b>bold\\</b>, \\<sub>2\\</sub>, \\<br>, \\<!-- note -->', 'even harmless tags and comments are shown as text (no raw HTML reaches the renderer)');
eq('a < b and c > d, 5 < 6', 'a < b and c > d, 5 < 6', 'comparison signs stay');

// ---- re-test V1-1..V1-4, V1-6, V1-7: a tag across a line ending, repeated attributes, a definition label across a line ending, definitions in lists and quotes,
// half-typed and complete tags of every kind, and addresses the filter shows as text (GFM autolink literals must not re-link them)
eq('<a\nhref="http://evil.invalid/x">t</a>', '\\<a\nhref="http&#58;//evil.invalid/x">t\\</a>', 'V1-1: a tag whose attributes span a line ending is text');
eq('<table\nbackground="https://evil.invalid/x.png">', '\\<table\nbackground="https://evil.invalid/x.png">', 'V1-1: a loading attribute on the next line is text');
eq('<a href="http://evil.invalid/x" href="https://ok.example">t</a>', '\\<a href="http&#58;//evil.invalid/x" href="https://ok.example">t\\</a>', 'V1-2: repeated attributes: the tag is text');
eq('<img alt="first" alt="second" src="https://e.invalid/i.png">', 'first', 'V1-2: <img> with two alts: the first, as HTML keeps it');
eq('<img\nsrc="https://e.invalid/i.png">', '\\<img\nsrc="https://e.invalid/i.png">', 'an <img> across a line ending is text');
eq('[a\nb]: http://evil.invalid/x\n\n[a b]', '\\[a\nb]: http&#58;//evil.invalid/x\n\n[a b]', 'V1-3: a definition whose label spans a line ending defines nothing');
eq('[a\nb]: javascript:alert(1)\n\n[here][a\nb]', '\\[a\nb]: javascript:alert(1)\n\n[here][a\nb]', 'V1-3: the same with javascript:');
eq('- [r]: http://evil.invalid/x\n\n[r]', '- \\[r]: http&#58;//evil.invalid/x\n\n[r]', 'V1-6: a definition in a list item is escaped');
eq('> [r]: http://evil.invalid/x\n\n[r]', '> \\[r]: http&#58;//evil.invalid/x\n\n[r]', 'V1-6: a definition in a block quote is escaped');
eq('1. [r]: <javascript:x>\n\n[r]', '1. \\[r]: javascript&#58;x\n\n[r]', 'V1-6: a definition in an ordered list item is escaped');
eq('see <iframe src="https://e.invalid/f', 'see \\<iframe src="https://e.invalid/f', 'V1-7: a half-typed <iframe is escaped');
eq('<script', '\\<script', 'V1-7: a half-typed <script is escaped');
eq('<meta http-equiv="refresh" content="0;url=https://e.invalid">', '\\<meta http-equiv="refresh" content="0;url=https://e.invalid">', 'V1-7: <meta> is text');
eq('<base href="https://e.invalid/">', '\\<base href="https://e.invalid/">', 'V1-7: <base> is text');
eq('</a><!--x--><?php ?><!DOCTYPE html>', '\\</a>\\<!--x-->\\<?php ?>\\<!DOCTYPE html>', 'closing tags, comments, processing instructions, declarations: text');
eq('see http://x.example/a, www.x.example and someone@example.com, but https://ok.example/b', 'see http&#58;//x.example/a, www&#46;x.example and someone&#64;example.com, but https://ok.example/b', 'V1-4: bare addresses that GFM would autolink are written so it does not; https stays');
eq('HTTP://X.EXAMPLE and mailto:a and ftp://f.example', 'HTTP&#58;//X.EXAMPLE and mailto&#58;a and ftp&#58;//f.example', 'V1-4: other schemes and capitals');
eq('`http://x.example` and $a@b$', '`http://x.example` and $a@b$', 'code and math are left as typed');
eq('https://www.ok.example/a', 'https://www.ok.example/a', 'an https address keeps its www');

// ---- code, math, tables, escapes: left as typed
eq('`![x](y)` and ![z](https://e.invalid/z.png)', '`![x](y)` and z', 'inline code keeps an image as typed');
eq('``a ` [x](javascript:y) b``', '``a ` [x](javascript:y) b``', 'double-backtick code span');
eq('```\n![x](y)\n<img src=z>\n```\n![z](https://e.invalid/z.png)', '```\n![x](y)\n<img src=z>\n```\nz', 'fenced code kept, text after it filtered');
eq('~~~md\n[a](javascript:b)\n~~~', '~~~md\n[a](javascript:b)\n~~~', 'tilde fence');
eq('> ```\n> ![x](y)\n> ```', '> ```\n> ![x](y)\n> ```', 'fence inside a quote');
eq('- item\n  ```\n  ![x](y)\n  ```\n- next ![i](https://e.invalid/i.png)', '- item\n  ```\n  ![x](y)\n  ```\n- next i', 'fence inside a list item');
eq('- item\n  ```\n  code\n- next ![i](https://e.invalid/i.png)', '- item\n  ```\n  code\n- next i', 'an unclosed fence ends with its list item');
eq('```js\nconst a = "![x](y)";', '```js\nconst a = "![x](y)";', 'unclosed fence at the end (streaming): the rest is code');
eq('``` a ` b\n![i](https://e.invalid/i.png)', '``` a ` b\ni', 'a backtick in the info string: not a fence');
eq('$\\mathbb{E}[X](t)$ and $$ C[0,1](\\mathbb{R}) $$', '$\\mathbb{E}[X](t)$ and $$ C[0,1](\\mathbb{R}) $$', 'inline math with link-like brackets');
eq('$$\n[a](b)\n![c](d)\n$$\n[e](f)', '$$\n[a](b)\n![c](d)\n$$\ne', '$$ block kept, text after it filtered');
eq('\\[ x^2 + [0,1] \\] and \\( \\frac{a}{b} \\)', '\\[ x^2 + [0,1] \\] and \\( \\frac{a}{b} \\)', '\\[ \\] and \\( \\) untouched');
eq('$e^{i\\pi}+1=0$ and\n\n$$\\int_0^1 x^2\\,dx=\\tfrac13$$', '$e^{i\\pi}+1=0$ and\n\n$$\\int_0^1 x^2\\,dx=\\tfrac13$$', 'the formulas of the renderer test');
eq('$n!$ and $k![a](b)$', '$n!$ and $k![a](b)$', 'factorials in math');
eq('| a | b |\n|---|:-:|\n| [x](javascript:y) | ![i](https://e.invalid/i.png) |\n| `a\\|b` | [k](https://ok.example) |', '| a | b |\n|---|:-:|\n| x | i |\n| `a\\|b` | [k](https://ok.example) |', 'table: cell by cell, pipes kept');
eq('| a | b |\n|---|---|\n| [x](javascript:a|b) | c |', '| a | b |\n|---|---|\n| [x](javascript:a|b) | c |', 'table: a pipe splits the cell first, as GFM does (no link, nothing removed)');
eq('| a |\n|---|---|\n| [x](javascript:y) |', '| a |\n|---|---|\n| x |', 'not a table (cell counts differ): read as text');
eq('\\![x](https://ok.example) \\[x](javascript:y) \\<img src=x>', '\\![x](https://ok.example) \\[x](javascript:y) \\<img src=x>', 'escaped characters');
eq('[foo`](javascript:x)`', '[foo`](javascript:x)`', 'a code span binds tighter than the brackets');
eq('[a [b](https://ok.example) c](javascript:y)', '[a [b](https://ok.example) c](javascript:y)', 'links do not contain links: the outer brackets stay text, as CommonMark reads them');
eq('a `b\n![i](https://e.invalid/i.png) `c', 'a `b\ni `c', 'what is kept as code never spans two lines (the renderer may read the lines differently)');
eq('[foo`]`](javascript:x)', 'foo`]`', 'a bracket inside a code span does not close the link text');
eq('[a<b c="](javascript:x)">', 'a\\<b c="">', 'a raw tag is text, so its quotes do not hide a link target');
eq("x''=-Lx, 5 XOR 3 = 6, 2 x 2 x 2 = 8, (a)(b) [c] {d}", "x''=-Lx, 5 XOR 3 = 6, 2 x 2 x 2 = 8, (a)(b) [c] {d}", 'plain text untouched');
eq('# Title\n\n- one\n- two\n\n> quote\n\n**bold** _it_ ~~del~~\n\n1. a\n2. b', '# Title\n\n- one\n- two\n\n> quote\n\n**bold** _it_ ~~del~~\n\n1. a\n2. b', 'ordinary Markdown untouched');

// ---- streaming: half-typed constructs
eq('![alt](https://evil.invalid/x.pn', 'alt', 'half-typed image target');
eq('see ![alt][r', 'see alt', 'half-typed reference image');
eq('<img src="https://evil.invalid/x.png', '\\<img src="https://evil.invalid/x.png', 'half-typed <img is escaped');
eq('[t](javascript:al', 't', 'half-typed bad link');
eq('[t](https://ok.example/pa', 't', 'half-typed https link: text until it closes');
eq('p1 [x](http://abc\n\np2', 'p1 [x](http&#58;//abc\n\np2', 'an unclosed target before the end is not a target (no text lost)');
ok(f(undefined) === '' && f(null) === '' && f(42) === '' && f('') === '', 'non-strings and the empty string give the empty string');

// independent checks of an output, written without the filter's parser: outside fenced code and inline code, no image syntax, no raw <img,
// no inline link whose target is not https://, no unescaped autolink that is not https://
function strip(s) { return s.replace(/^(`{3,}|~{3,})[^\n]*\n[\s\S]*?(\n\1[^\n]*|$)/gm, '').replace(/^\$\$[^\n$]*\n[\s\S]*?(\n\$\$[^\n]*|$)/gm, '').replace(/(`+)[^`\n]*?\1/g, '').replace(/\$\$[^$\n]*\$\$|\$[^$\n]*\$/g, ''); }
function unsafe(out) {
  const t = strip(out), why = [];
  if (/(^|[^\\])!\[[^\]\n]*\]\s*[([]/.test(t)) why.push('image syntax');
  if (/(^|[^\\])<img\b/i.test(t)) why.push('raw <img');
  const m = t.match(/(^|[^\\!])\[[^\]\n]*\]\(\s*<?(?!https:\/\/)[^)\s]*/i); if (m) why.push('non-https link ' + m[0]);
  if (/(^|[^\\])<(?!https:)[a-z][a-z0-9+.-]+:[^\s<>]*>/i.test(t)) why.push('non-https autolink');
  if (/(^|[^\\])<[A-Za-z/!?]/.test(t.replace(/<https:\/\/[^\s<>]*>/gi, ''))) why.push('raw tag');
  if (/(^|[^A-Za-z0-9/.])(http|ftp|mailto|xmpp):|(^|[^A-Za-z0-9/.])www\.|@/i.test(t.replace(/\[[^\]\n]*\]\(https:\/\/[^)\s]*\)/g, ''))) why.push('an address GFM would autolink');
  return why;
}
const STREAMS = [
  'Here is a picture: ![a cat](https://evil.invalid/cat.png "cat") and a link [docs](https://docs.example/x).\n\n| x | y |\n|---|---|\n| ![i](data:image/png;base64,AAAA) | [h](http://plain.example) |\n\nCode: `![kept](as typed)` and\n\n```md\n![kept too](https://code.example/x.png)\n```\n\nMath $f[a](b)$ and <img src="https://evil.invalid/raw.png" alt="raw"> then [js](javascript:alert(1)) end.',
  '[![badge](https://evil.invalid/b.svg)](https://ok.example/repo) <a href="javascript:x">y</a> <iframe src="https://evil.invalid/f"></iframe>\n[r]: javascript:x\n![ref][r] <javascript:alert(1)>',
  'Nested [a [b](http://c.example) d](https://e.example) and ![x ![y](https://evil.invalid/y.png) z](https://evil.invalid/x.png) and\n$$\n![m](https://evil.invalid/m.png)\n$$\nafter ![q](https://evil.invalid/q.png)',
];
for (const [k, S] of STREAMS.entries()) {
  let bad = 0, notFixed = 0, crash = 0;
  for (let i = 0; i <= S.length; i++) {
    let out; try { out = f(S.slice(0, i)); } catch (e) { crash++; continue; }
    if (unsafe(out).length) { if (!bad) errs.push(`stream ${k}, prefix ${i}: ${unsafe(out).join(', ')} in ${JSON.stringify(out.slice(-160))}`); bad++; }
    if (f(out) !== out) { if (!notFixed) errs.push(`stream ${k}, prefix ${i}: not a fixed point: ${JSON.stringify(out.slice(-120))}`); notFixed++; }
  }
  ok(crash === 0, `stream ${k}: no prefix throws (${crash} threw)`); ok(bad === 0, `stream ${k}: every one of ${S.length + 1} prefixes is safe (${bad} were not)`); ok(notFixed === 0, `stream ${k}: every prefix's output is a fixed point (${notFixed} were not)`);
  ok(!/evil\.invalid\/[a-z]+\.(png|svg)/.test(strip(f(S))), `stream ${k}: the finished answer shows no image address of the other host outside code: ${JSON.stringify(f(S))}`);
}
ok(f(STREAMS[0]).includes('`![kept](as typed)`') && f(STREAMS[0]).includes('```md\n![kept too](https://code.example/x.png)\n```') && f(STREAMS[0]).includes('$f[a](b)$') && f(STREAMS[0]).includes('[docs](https://docs.example/x)') && f(STREAMS[0]).includes('| i | h |') && f(STREAMS[0]).includes(' raw then js end.'), 'stream 0 finished: code, math, the https link and the table cells are as expected: ' + JSON.stringify(f(STREAMS[0])));

// ---- hostile sizes: linear enough to run on every streamed prefix
for (const [name, s] of [['20000 [', '['.repeat(20000)], ['10000 nested ![', '!['.repeat(5000) + 'x' + ']'.repeat(5000)], ['20000 `', '`a'.repeat(10000)], ['5000 <a', '<a '.repeat(5000)], ['5000 links', '[t](javascript:x) '.repeat(5000)], ['long tag', '<img ' + 'a=b '.repeat(3000)]]) {
  const t0 = Date.now(); let out; try { out = f(s); } catch (e) { out = null; } const ms = Date.now() - t0;
  ok(out !== null && ms < 1500, `${name}: filtered in ${ms} ms (limit 1500)`); ok(out === null || !unsafe(out).length, `${name}: output safe`);
}

// ---- wired into the page: App.jsx filters before Streamdown and in the live region, and no longer passes props streamdown ignores
const app = fs.readFileSync(path.join(PKG, 'App.jsx'), 'utf8');
const line = app.split('\n').find(l => /const ChatResponse\s*=/.test(l)) || '';
ok(/import \{ filterAnswer \} from '\.\/lib\/answerFilter\.js'/.test(app), 'App.jsx imports filterAnswer from lib/answerFilter.js');
ok(/filterAnswer\(content\)/.test(line) && /<Streamdown[^>]*>\{safe\}<\/Streamdown>|<Streamdown[^>]*>\{filterAnswer\(content\)\}<\/Streamdown>/.test(line), 'ChatResponse hands Streamdown the filtered text: ' + line.slice(0, 200));
ok(!/allowedImagePrefixes|allowedLinkPrefixes|allowDataImages/.test(app), 'App.jsx carries none of the three props <Streamdown> does not read');
ok(/constspoken=s=>\[s\.text&&filterAnswer\(s\.text\)/.test(app.replace(/ /g, '')), 'the live region announces the filtered text');

console.log(errs.length ? errs.join('\n') + `\n${errs.length} FAILURES of ${n}` : `ALL ${n} CHAT FILTER CHECKS PASS`); process.exit(errs.length ? 1 : 0);
