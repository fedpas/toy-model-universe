// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useMemo, useState } from 'react';
import { MATRIX_ROWS, MATRIX_COLUMNS } from './translationMatrixData.js';
import { Tx } from './MathText.jsx';
import { RS } from './researchersCopy.js';

// The translation matrix of one report as a picture: every row of the report (an object in the researcher's papers) against the 22 columns of the atlas, each
// cell E (exact: computed in a script), S (structural: the same structure in another generality, or a standard fact) or A (analogy: our reading, nothing
// computes it); an empty cell is a gap. The same 131 rows, with their notes, are on the For researchers page (#researchers/matrix): a row opens there.
// Row titles and notes are in English (they are quoted from the reports); a line says so for the Italian reader. The grades are not the four tags, so no
// element here carries a "tag" class (the reader filter must not read a grade as a status).
const C = {
  en: { h: 'The translation matrix of this chapter', rows: 'rows', cells: 'cells', exact: 'exact', structural: 'structural', analogy: 'analogy', gaps: 'rows with no cell (a gap)', col: 'Column', allCols: 'All columns', grade: 'Grade', open: 'Open this row in For researchers', close: 'Close', enNote: 'Row titles and notes are quoted from the report and are in English.', legend: 'E exact (computed in a script) · S structural (same structure, or a standard fact) · A analogy (our reading, nothing computes it) · empty: a gap', shown: (n, N) => `${n} of ${N} rows`, table: 'translation matrix of this chapter', cellLbl: (c, g) => `${c}: ${g}` },
  it: { h: 'La matrice di traduzione di questo capitolo', rows: 'righe', cells: 'celle', exact: 'esatte', structural: 'strutturali', analogy: 'analogie', gaps: 'righe senza celle (una lacuna)', col: 'Colonna', allCols: 'Tutte le colonne', grade: 'Grado', open: 'Apri questa riga in Per i ricercatori', close: 'Chiudi', enNote: 'I titoli delle righe e le note sono citati dal rapporto e sono in inglese.', legend: 'E esatta (calcolata in uno script) · S strutturale (stessa struttura, o un fatto standard) · A analogia (nostra lettura, nulla la calcola) · vuota: una lacuna', shown: (n, N) => `${n} righe su ${N}`, table: 'matrice di traduzione di questo capitolo', cellLbl: (c, g) => `${c}: ${g}` },
};
const STYLE = `
.lm-wrap{overflow-x:auto;max-width:100%;border:1px solid rgba(128,128,128,.3);border-radius:8px}.lm{border-collapse:collapse;font-size:.8em;width:100%}
.lm th,.lm td{border-bottom:1px solid rgba(128,128,128,.16)}.lm thead th{position:sticky;top:0;background:var(--bg,#0b1020);font-weight:400;font-size:.75em;padding:2px 0;vertical-align:bottom}
.lm th[scope=row]{text-align:left;font-weight:400;padding:2px 8px 2px 6px;white-space:nowrap;position:sticky;left:0;background:var(--bg,#0b1020);border-right:1px solid rgba(128,128,128,.35);max-width:15em;overflow:hidden;text-overflow:ellipsis}
.lm td.c{width:22px;min-width:22px;height:20px;text-align:center;padding:0;border-left:1px solid rgba(128,128,128,.1);font-size:.78em}.lm td.gE{color:#34d399;background:rgba(52,211,153,.22)}.lm td.gS{color:#60a5fa;background:rgba(96,165,250,.14)}.lm td.gA{color:#fbbf24;outline:1px dashed rgba(251,191,36,.7);outline-offset:-3px}.lm td.dim{opacity:.2}
.lm-rt{display:inline-block;margin-left:6px;opacity:.8;overflow:hidden;text-overflow:ellipsis;vertical-align:bottom;max-width:11em}.lm button.lm-id{background:none;border:0;color:inherit;cursor:pointer;font:inherit;font-family:ui-monospace,monospace;padding:0;text-decoration:underline dotted}
.lm tr.on th,.lm tr.on td{box-shadow:inset 0 0 0 9999px rgba(128,128,128,.1)}
.lm-panel{border:1px solid rgba(128,128,128,.35);border-radius:8px;padding:8px 12px;margin:8px 0;font-size:.88em}.lm-panel ul{margin:.3em 0;padding-left:1.1em}.lm-panel li{margin:.25em 0}
.lm-cnt{font-size:.8em;opacity:.85;margin:.3em 0}.lm-g{font-family:ui-monospace,monospace;font-weight:700;margin-right:5px}.lm-g.gE{color:#34d399}.lm-g.gS{color:#60a5fa}.lm-g.gA{color:#fbbf24}
@media(max-width:560px){.lm-rt{display:none}}`;
export default function LensMatrix({ lang = 'en', source }) {
  const L = lang === 'it' ? 'it' : 'en', t = C[L], rows = useMemo(() => MATRIX_ROWS.filter(r => r.src === source), [source]);
  const [col, setCol] = useState(''), [grades, setGrades] = useState([]), [sel, setSel] = useState(null);
  const colShort = c => (L === 'it' && RS.it.matrix.cols[c.key]?.[0]) || c.short, colLong = c => (L === 'it' && RS.it.matrix.cols[c.key]?.[1]) || c.long;
  const cnt = g => rows.reduce((a, r) => a + Object.values(r.cells).filter(x => x.grade === g).length, 0), gaps = rows.filter(r => !Object.keys(r.cells).length).length;
  const shown = rows.filter(r => (!col || r.cells[col]) && (!grades.length || Object.values(r.cells).some(x => grades.includes(x.grade))));
  const row = sel && rows.find(r => r.uid === sel), tg = g => setGrades(x => (x.includes(g) ? x.filter(y => y !== g) : [...x, g]));
  const openRow = uid => { try { location.hash = '#researchers/matrix-' + uid; window.scrollTo(0, 0); } catch { /* ignore */ } };
  return <section className="lm-sec" id={'lm-' + source} aria-label={t.h} data-source={source}><style>{STYLE}</style><h3><Tx>{t.h}</Tx></h3>
    <p className="ln-cap" data-lm-counts={`${rows.length},${cnt('E')},${cnt('S')},${cnt('A')},${gaps}`}><Tx>{`${rows.length} ${t.rows} × ${MATRIX_COLUMNS.length} · E ${cnt('E')} ${t.exact} · S ${cnt('S')} ${t.structural} · A ${cnt('A')} ${t.analogy} · ${gaps} ${t.gaps}`}</Tx></p>
    <p className="ln-cap"><Tx>{t.legend}</Tx></p>{L === 'it' ? <p className="ln-cap lang-note"><Tx>{t.enNote}</Tx></p> : null}
    <div className="ln-chips"><label><span className="ln-k">{t.col}</span> <select value={col} data-lm-col onChange={e => setCol(e.target.value)}><option value="">{t.allCols}</option>{MATRIX_COLUMNS.map(c => <option key={c.key} value={c.key}>{colLong(c)}</option>)}</select></label>
      {['E', 'S', 'A'].map(g => <button key={g} type="button" className="ln-chip" data-grade={g} aria-pressed={grades.includes(g)} onClick={() => tg(g)}>{g}</button>)}</div>
    <p className="lm-cnt" aria-live="polite" data-shown={shown.length}>{t.shown(shown.length, rows.length)}</p>
    {row && <div className="lm-panel" data-panel={row.uid} role="region" aria-label={row.id}><p><code className="ln-id">{row.id}</code> <b lang="en">{row.title}</b> <button type="button" className="ln-btn" onClick={() => setSel(null)}>{t.close}</button> <button type="button" className="ln-btn" data-open-row={row.uid} onClick={() => openRow(row.uid)}>{t.open}</button></p>
      <ul>{MATRIX_COLUMNS.filter(c => row.cells[c.key]).map(c => <li key={c.key} data-col={c.key}><span className={'lm-g g' + row.cells[c.key].grade}>{row.cells[c.key].grade}</span> <b>{colLong(c)}</b> <span lang="en">{row.cells[c.key].note}</span></li>)}</ul></div>}
    <div className="lm-wrap" tabIndex={0} role="region" aria-label={t.table}><table className="lm"><thead><tr><th scope="col" />{MATRIX_COLUMNS.map(c => <th key={c.key} scope="col" title={colLong(c)}>{colShort(c).replace(/^\d+ /, '')}</th>)}</tr></thead>
      <tbody>{shown.map(r => <tr key={r.uid} data-uid={r.uid} className={sel === r.uid ? 'on' : undefined}><th scope="row"><button type="button" className="lm-id" aria-pressed={sel === r.uid} onClick={() => setSel(sel === r.uid ? null : r.uid)}>{r.id}</button><span className="lm-rt" lang="en" title={r.title}>{r.title}</span></th>
        {MATRIX_COLUMNS.map(c => { const x = r.cells[c.key], dim = x && grades.length && !grades.includes(x.grade); return <td key={c.key} className={'c ' + (x ? 'g' + x.grade : '') + (dim ? ' dim' : '')} data-g={x ? x.grade : ''} aria-label={t.cellLbl(colLong(c), x ? x.grade : '–')}>{x ? x.grade : ''}</td>; })}</tr>)}</tbody></table></div></section>;
}
