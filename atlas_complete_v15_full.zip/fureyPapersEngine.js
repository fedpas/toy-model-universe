// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The live engine of the Furey page: exact integer arithmetic, no floating point. Hypercharge is kept in sixths (y6 = 6 Y) and electric charge in thirds (q3 = 3 Q).
// It rebuilds, in the browser, what selfcheck/furey_papers_check.py computes in parts F, C and P: the irrep of every Peirce edge, the electric charges of its
// components, the labels of Fig. 1 against those irreps, the count of complete sets, and the tensor products of irreps. Nothing here is a model of physics: it is
// the gauge quantum numbers (colour, weak isospin, hypercharge) of the cells of the 8 x 8 complex matrices, as the page of the atlas defines them.
// test_furey_papers.mjs compares every function with fureyPapersData.js (the stored output of the Python script).
// irrep: { c: '1' | '3' | '3b' | '6' | '6b' | '8', i: 1 | 2 | 3, y: integer sixths }
const DUALC = { 1: '1', 3: '3b', '3b': '3', 6: '6b', '6b': '6', 8: '8' };
const CDIM = { 1: 1, 3: 3, '3b': 3, 6: 6, '6b': 6, 8: 8 };
export const dual = r => ({ c: DUALC[r.c], i: r.i, y: r.y === 0 ? 0 : -r.y });
export const dimOf = r => CDIM[r.c] * r.i;
export const same = (a, b) => a.c === b.c && a.i === b.i && a.y === b.y;
const cprod = (a, b) => {
  if (a === '1') return [b]; if (b === '1') return [a];
  const t = { '3,3': ['6', '3b'], '3b,3b': ['6b', '3'], '3,3b': ['1', '8'], '3b,3': ['1', '8'] }[a + ',' + b];
  if (!t) throw new Error('colour product not needed here: ' + a + ' x ' + b); return t;
};
const iprod = (a, b) => { if (a === 1) return [b]; if (b === 1) return [a]; if (a === 2 && b === 2) return [1, 3]; throw new Error('isospin product not needed here'); };
export const tensor = (x, y) => cprod(x.c, y.c).flatMap(c => iprod(x.i, y.i).map(i => ({ c, i, y: x.y + y.y })));
const frac = (n, d) => { const g = (a, b) => (b ? g(b, a % b) : a), k = g(Math.abs(n), d); return d / k === 1 ? String(Math.abs(n) / k) : Math.abs(n) / k + '/' + d / k; };
export const fmtY = (y6, sign = true) => (y6 === 0 ? '0' : (y6 > 0 ? (sign ? '+' : '') : '−') + frac(y6, 6));
export const fmtQ = q3 => (q3 === 0 ? '0' : (q3 > 0 ? '+' : '−') + frac(q3, 3));
// "(3,2,+1/6)" in the notation of the check scripts (3b for the conjugate triplet); the page shows 3̄ via fmtShow
export const fmt = r => `(${r.c},${r.i},${r.y === 0 ? '0' : (r.y > 0 ? '+' : '') + (r.y < 0 ? '-' : '') + frac(r.y, 6)})`;
export const fmtShow = r => `(${r.c === '3b' ? '3̄' : r.c === '6b' ? '6̄' : r.c},${r.i},${fmtY(r.y)})`;
// the block of a name, as a string of the data files: "(3,2,+1/6)" -> irrep
export const parse = s => { const m = /^\((3b|6b|1|3|6|8),(\d),([+-]?\d+(?:\/\d+)?|0)\)$/.exec(s); if (!m) throw new Error('bad irrep ' + s); const [n, d = '1'] = m[3].split('/'); return { c: m[1], i: +m[2], y: Math.round((+n * 6) / +d) }; };

// ---- the five complex blocks of the page (sizes 1, 3, 2, 1, 1), hypercharges 0, 1/3, 1/2, 1, 0; SU(3) acts as 3-bar on the 3-block
export const BLOCKS = [
  { id: 0, name: 'ℂ_𝕆', c: '1', i: 1, y: 0, n: 1, q: [0] },
  { id: 1, name: 'ℂ³_𝕆', c: '3b', i: 1, y: 2, n: 3, q: [1, 1, 1] },
  { id: 2, name: 'ℂ²_ℍ', c: '1', i: 2, y: 3, n: 2, q: [0, 3] },
  { id: 3, name: 'ℂ_ℂ', c: '1', i: 1, y: 6, n: 1, q: [3] },
  { id: 4, name: 'ℂ_last', c: '1', i: 1, y: 0, n: 1, q: [0] },
];
export const blockIrrep = b => ({ c: b.c, i: b.i, y: b.y });
// the operator from block `row` to block `col` (a cell of Fig. 1: row = source, column = target) is col (x) conjugate(row); its charge is y_col - y_row
export const cell = (row, col) => {
  if (row === col) throw new Error('diagonal cells are the gauge bosons, not matter');
  const out = tensor(blockIrrep(BLOCKS[col]), dual(blockIrrep(BLOCKS[row]))); if (out.length !== 1) throw new Error('expected one irrep'); return out[0];
};
export const cellCharges = (row, col) => { const m = {}; for (const qt of BLOCKS[col].q) for (const qs of BLOCKS[row].q) { const k = qt - qs; m[k] = (m[k] || 0) + 1; } return Object.entries(m).map(([q, n]) => ({ q: +q, n })).sort((a, b) => b.q - a.q); };
export const capacity = (a, b) => 2 * BLOCKS[a].n * BLOCKS[b].n;           // both directions, in complex dimensions
export const traceY = () => BLOCKS.reduce((s, b) => s + b.y * b.n, 0);   // in sixths: 18 = 3 over 6
export const traceQ = () => BLOCKS.reduce((s, b) => s + b.q.reduce((x, y) => x + y, 0), 0);   // in thirds: 9 = 3 over 3
export const dimV = () => BLOCKS.reduce((s, b) => s + b.n, 0);

// ---- the six Standard Model types, one left-handed set (a field as the page writes it: right-handed fields are particles, not conjugated)
export const SM = {
  Q_L: { c: '3', i: 2, y: 1 }, u_R: { c: '3', i: 1, y: 4 }, d_R: { c: '3', i: 1, y: -2 },
  L: { c: '1', i: 2, y: -3 }, e_R: { c: '1', i: 1, y: -6 }, nu_R: { c: '1', i: 1, y: 0 },
};
export const TYPES = Object.keys(SM);
export const SM_DIM = Object.fromEntries(TYPES.map(t => [t, dimOf(SM[t])]));
export const kindOf = r => { for (const t of TYPES) { if (same(r, SM[t])) return { type: t, conj: false }; if (same(r, dual(SM[t]))) return { type: t, conj: true }; } return null; };

// ---- Fig. 1 of the nested-embeddings paper: the labels of the 20 off-diagonal cells (row, column), top to bottom; dagger = conjugate
// base name -> [display text, the irrep it names]
const N = (c, i, y) => ({ c, i, y });
export const NAMES = {
  b_R: ['b_R', N('3', 1, -2)], '(nu_e,e)_L': ['(ν_e, e)_L', N('1', 2, -3)], '(nu_mu,mu)_L': ['(ν_μ, μ)_L', N('1', 2, -3)], '(u,d)_L': ['(u, d)_L', N('3', 2, 1)], '(c,s)_L': ['(c, s)_L', N('3', 2, 1)],
  e_R: ['e_R', N('1', 1, -6)], mu_R: ['μ_R', N('1', 1, -6)], nu_eR: ['ν_eR', N('1', 1, 0)], nu_muR: ['ν_μR', N('1', 1, 0)], u_R: ['u_R', N('3', 1, 4)], c_R: ['c_R', N('3', 1, 4)],
  d_R: ['d_R', N('3', 1, -2)], s_R: ['s_R', N('3', 1, -2)], h: ['h', N('1', 2, 3)], '(nu_tau,tau)_L': ['(ν_τ, τ)_L', N('1', 2, -3)], tau_R: ['τ_R', N('1', 1, -6)],
};
export const FIG1 = {
  '0,1': ['b_R+', 'b_R+'], '0,2': ['(nu_e,e)_L+', '(nu_mu,mu)_L+'], '0,3': ['e_R+', 'mu_R+'], '0,4': ['nu_eR+', 'nu_muR+'],
  '1,0': ['b_R', 'b_R'], '1,2': ['(u,d)_L', '(c,s)_L'], '1,3': ['u_R', 'c_R'], '1,4': ['d_R', 's_R'],
  '2,0': ['(nu_e,e)_L', '(nu_mu,mu)_L'], '2,1': ['(u,d)_L+', '(c,s)_L+'], '2,3': ['h', 'h'], '2,4': ['(nu_tau,tau)_L', '(nu_tau,tau)_L'],
  '3,0': ['e_R', 'mu_R'], '3,1': ['u_R+', 'c_R+'], '3,2': ['h+', 'h+'], '3,4': ['tau_R', 'tau_R'],
  '4,0': ['nu_eR', 'nu_muR'], '4,1': ['d_R+', 's_R+'], '4,2': ['(nu_tau,tau)_L+', '(nu_tau,tau)_L+'], '4,3': ['tau_R+', 'tau_R+'],
};
export const cellKeys = () => Object.keys(FIG1).map(k => k.split(',').map(Number));
export const labelText = lb => NAMES[lb.replace(/\+$/, '')][0] + (lb.endsWith('+') ? '†' : '');
export const labelIrrep = lb => { const r = NAMES[lb.replace(/\+$/, '')][1]; return lb.endsWith('+') ? dual(r) : r; };
// does every label of the cell name exactly the irrep of the edge?
export const cellMatches = (row, col) => FIG1[row + ',' + col].every(lb => same(labelIrrep(lb), cell(row, col)));
export const matchCount = () => { let n = 0; for (const [r, c] of cellKeys()) if (cellMatches(r, c)) n++; return n; };
export const SETS_FIRST = ['1,2', '1,3', '1,4', '0,2', '0,3', '0,4'];   // the six cells of Fig. 1 whose first labels are the first-generation fields (u,d)_L, u_R, d_R, (ν_e,e)_L, e_R, ν_eR
const inFirst = (r, c) => SETS_FIRST.includes(r + ',' + c) || SETS_FIRST.includes(c + ',' + r);

// ---- counting. On-shell: one label per cell; doubled: every cell twice (the hermitian 16 x 16 form of Fig. 1).
// A cell of type T counts for T whether it holds the field or its conjugate; a complete set is one cell and its transpose.
export function cellsByType() {
  const m = Object.fromEntries(TYPES.map(t => [t, 0]));
  for (const [r, c] of cellKeys()) { const k = kindOf(cell(r, c)); if (!k) throw new Error('cell of no Standard Model type'); m[k.type]++; }
  return m;
}
export const setsByType = (doubled = false) => Object.fromEntries(Object.entries(cellsByType()).map(([t, n]) => [t, (n / 2) * (doubled ? 2 : 1)]));
export const completeSets = (doubled = false) => Math.min(...Object.values(setsByType(doubled)));
export const surplus = (doubled = false) => { const s = setsByType(doubled), m = Math.min(...Object.values(s)); return Object.fromEntries(TYPES.map(t => [t, s[t] - m])); };
export const missingFor = (k, doubled = false) => { const s = setsByType(doubled); return Object.fromEntries(TYPES.filter(t => s[t] < k).map(t => [t, k - s[t]])); };
export const surplusDim = () => { const s = surplus(false); return TYPES.reduce((a, t) => a + SM_DIM[t] * s[t], 0); };

// ---- tensor products of the irreps that occur in the cells (the page's "irreps lack a third copy" check)
export const CELL_IRREPS = (() => { const seen = []; for (const [r, c] of cellKeys()) { const x = cell(r, c); if (!seen.some(s => same(s, x))) seen.push(x); } return seen.sort((a, b) => (b.i - a.i) || (a.c < b.c ? -1 : 1) || (b.y - a.y)); })();
export const product = (a, b) => tensor(a, b);
export const MISSING_TARGETS = ['Q_L', 'u_R', 'nu_R'];
export const containsType = (list, t) => list.some(x => same(x, SM[t]));
export const PRESETS = [
  { a: N('3', 1, -2), b: N('1', 2, 3), target: 'Q_L', names: ['b_R', 'h'] },
  { a: N('3', 1, -2), b: dual(N('1', 1, -6)), target: 'u_R', names: ['b_R', 'τ_R†'] },
  { a: N('1', 2, 3), b: N('1', 2, -3), target: 'nu_R', names: ['h', '(ν_τ, τ)_L'] },
];

// the legend colour of a cell: its Standard Model type
export const TYPE_COLOUR = { Q_L: '#4fd18b', u_R: '#ffd166', d_R: '#ffa06f', L: '#61dff0', e_R: '#a78bfa', nu_R: '#9aa3b8' };
export const typeOfCell = (r, c) => kindOf(cell(r, c)).type;
export const isFirstSetCell = inFirst;
