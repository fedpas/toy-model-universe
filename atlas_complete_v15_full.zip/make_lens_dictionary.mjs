// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Generates lensDictionaryData.js (the lens dictionary that the chat persona reads) from the hand-maintained source reports/lens_dictionary.json.
//   node make_lens_dictionary.mjs [reports/lens_dictionary.json]            writes lensDictionaryData.js next to this script
//   node make_lens_dictionary.mjs [reports/lens_dictionary.json] --check    writes nothing; exit 1 if lensDictionaryData.js is not what the json gives
// The json has { about, lenses: [{key, short, long, field, matrix?, page?}], rows: [{id, atlas, where, terms, match, flags, checks?, scope?, matrix?}] }.
// A row names one atlas object (atlas, where) in the words of other fields (terms: lens key -> one term), says how far the names agree (match) and carries the tags of
// the translation (flags): checked only with a cited check id (checks), standard only for a source read at statement level. matrix lists the uids of the rows of the
// translation matrix (translationMatrixData.js) that cover the same object in the atlas's own lenses; their titles are copied into the data module, so the persona
// reaches the older lenses by pointer without a second copy of the matrix.
// Every `where` id must be an id the package holds: a statement of claimsData.js, a theorem or question of researchersData.js, a core row of coreData.js, a bridge
// check id (bd·<family>·<n>), a step or tab of steps.js, a page of storyCopy.js or a report of reportsData.js. Every check id is bd·<family>·<n> or core·B<n>.
// The order of the rows in the json is their priority: the compact form prints them in that order, and under a size cap it prints the longest run of rows from the
// first that fits and says how many of them it prints (the module keeps every row and every term).
// The output is deterministic (no date): the same json gives the same bytes. Stops with a message on anything malformed.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const HERE = path.dirname(fileURLToPath(import.meta.url)), OUT = path.join(HERE, 'lensDictionaryData.js');
const args = process.argv.slice(2), check = args.includes('--check');
const src = args.find(a => !a.startsWith('--')) || path.join(HERE, 'reports', 'lens_dictionary.json');
const die = m => { console.error('make_lens_dictionary: ' + m); process.exit(1); };
const imp = f => import(pathToFileURL(path.join(HERE, f)).href);
const [{ CLAIMS }, { THEOREMS, QUESTIONS }, CORE, { NAV_NAMES, STEP_GROUPS }, { PAGES }, { REPORTS }, { MATRIX_ROWS }] = await Promise.all(
  ['claimsData.js', 'researchersData.js', 'coreData.js', 'steps.js', 'storyCopy.js', 'reportsData.js', 'translationMatrixData.js'].map(imp));

const FLAGS = ['standard', 'checked', 'ours', 'open', 'input'];
const MATCH = ['exact', 'partial', 'none', 'new'];
const CHECK_RE = /^(bd·(phy|str|sol|xph|mat|geo|alg|cat|xck|hh|fk|rev|tor|en|fur|kep|mjc|mja|mjg|mjp)·\d+|core·B\d+[a-z]?)$/;
const TERM_MAX = 160, NAME_MAX = 60, SCOPE_MAX = 60;
const KNOWN = {
  claim: new Set(CLAIMS.map(c => c.id)), theorem: new Set(THEOREMS.map(t => t.id)), question: new Set(QUESTIONS.map(q => q.id)), core: new Set(CORE.default.rows.map(r => r.id)),
  step: new Set([...Object.keys(NAV_NAMES.en), ...Object.values(STEP_GROUPS).flat()]), page: new Set(PAGES), report: new Set(REPORTS.map(r => r.id)),
};
// the kind of a `where` id, or null when the package holds no such id
const whereKind = id => (KNOWN.claim.has(id) ? 'claim' : KNOWN.theorem.has(id) ? 'theorem' : KNOWN.question.has(id) ? 'question' : KNOWN.core.has(id) ? 'core'
  : /^bd·/.test(id) && CHECK_RE.test(id) ? 'bridge' : KNOWN.step.has(id) ? 'step' : KNOWN.page.has(id) ? 'page' : KNOWN.report.has(id) ? 'report' : null);
// plain text only: no TeX, no markup, no address of a person
const BAD_TEXT = [[/\\[a-zA-Z]|\$/, 'TeX'], [/<\/?[a-z][^>]*>/i, 'markup'], [/[\w.+-]+@[\w-]+\.[\w.]+|mailto:/i, 'an e-mail address'], [/https?:\/\//i, 'a link']];
const plain = (s, what) => { if (typeof s !== 'string' || !s.trim() || s !== s.trim()) die(what + ' is empty or has outer spaces: ' + JSON.stringify(s)); for (const [re, w] of BAD_TEXT) if (re.test(s)) die(what + ' holds ' + w + ': ' + s); return s; };

const J = JSON.parse(fs.readFileSync(path.resolve(src), 'utf8'));
if (!Array.isArray(J.lenses) || !Array.isArray(J.rows) || typeof J.about !== 'string') die('the json needs "about" (a string), "lenses" and "rows" (lists)');
const matrixSources = new Set(MATRIX_ROWS.map(r => r.src)), matrixUid = new Map(MATRIX_ROWS.map(r => [r.uid, r]));
const lenses = J.lenses.map(l => {
  for (const k of ['key', 'short', 'long', 'field']) plain(l[k], 'lens ' + (l.key || '?') + ' ' + k);
  if (!/^[a-z]{2,4}$/.test(l.key)) die('lens key ' + l.key + ' is not 2 to 4 lower-case letters');
  for (const k of Object.keys(l)) if (!['key', 'short', 'long', 'field', 'matrix', 'page'].includes(k)) die('lens ' + l.key + ': unknown field ' + k);
  if (l.matrix !== undefined && !matrixSources.has(l.matrix)) die('lens ' + l.key + ': no matrix source ' + l.matrix + ' in translationMatrixData.js');
  if (l.page !== undefined && !KNOWN.report.has(l.page) && !KNOWN.page.has(l.page)) die('lens ' + l.key + ': no page or report ' + l.page);
  return Object.fromEntries(['key', 'short', 'long', 'field', 'matrix', 'page'].filter(k => l[k] !== undefined).map(k => [k, l[k]]));
});
const lensKeys = new Set(lenses.map(l => l.key)); if (lensKeys.size !== lenses.length) die('two lenses have the same key');
const seen = new Set();
const rows = J.rows.map((r, i) => {
  const at = 'row ' + (r.id || '#' + (i + 1));
  if (typeof r.id !== 'string' || !/^D\d{2,3}$/.test(r.id)) die(at + ': the id must be D followed by two or three digits');
  if (seen.has(r.id)) die('duplicate row id ' + r.id); seen.add(r.id);
  for (const k of Object.keys(r)) if (!['id', 'atlas', 'where', 'terms', 'match', 'flags', 'checks', 'scope', 'matrix'].includes(k)) die(at + ': unknown field ' + k);
  plain(r.atlas, at + ' atlas'); if (r.atlas.length > NAME_MAX) die(at + ': the atlas name is longer than ' + NAME_MAX + ' characters');
  if (!Array.isArray(r.where) || !r.where.length) die(at + ': where needs at least one id');
  for (const w of r.where) if (!whereKind(w)) die(at + ': where id ' + w + ' is neither a claims id, a theorem or question id, a core or bridge check id, nor a step, page or report id');
  if (new Set(r.where).size !== r.where.length) die(at + ': a where id repeats');
  if (!r.terms || typeof r.terms !== 'object' || !Object.keys(r.terms).length) die(at + ': no term');
  for (const [k, t] of Object.entries(r.terms)) { if (!lensKeys.has(k)) die(at + ': unknown lens key ' + k); plain(t, at + ' term ' + k); if (t.length > TERM_MAX) die(at + ' term ' + k + ' is longer than ' + TERM_MAX + ' characters'); }
  if (!MATCH.includes(r.match)) die(at + ': match ' + r.match + ' is not one of ' + MATCH.join(', '));
  if (!Array.isArray(r.flags) || !r.flags.length) die(at + ': flags needs at least one tag');
  for (const f of r.flags) if (!FLAGS.includes(f)) die(at + ': unknown flag ' + f);
  if (new Set(r.flags).size !== r.flags.length) die(at + ': a flag repeats');
  const checks = r.checks || [];
  if (!Array.isArray(checks)) die(at + ': checks must be a list');
  for (const c of checks) if (!CHECK_RE.test(c)) die(at + ': check id ' + c + ' is neither bd·<family>·<n> nor core·B<n>');
  if (new Set(checks).size !== checks.length) die(at + ': a check id repeats');
  if (r.flags.includes('checked') && !checks.length) die(at + ': flag checked without a check id');
  if (checks.length && !r.flags.includes('checked')) die(at + ': check ids without the flag checked');
  if (r.scope !== undefined) { plain(r.scope, at + ' scope'); if (r.scope.length > SCOPE_MAX) die(at + ': the scope is longer than ' + SCOPE_MAX + ' characters'); }
  const matrix = r.matrix || [];
  if (!Array.isArray(matrix)) die(at + ': matrix must be a list');
  for (const u of matrix) if (!matrixUid.has(u)) die(at + ': matrix uid ' + u + ' is not a row of translationMatrixData.js');
  if (new Set(matrix).size !== matrix.length) die(at + ': a matrix uid repeats');
  const terms = Object.fromEntries(lenses.filter(l => r.terms[l.key] !== undefined).map(l => [l.key, r.terms[l.key]]));   // lens order of the header
  return { id: r.id, atlas: r.atlas, where: r.where, terms, match: r.match, flags: FLAGS.filter(f => r.flags.includes(f)), checks, ...(r.scope ? { scope: r.scope } : {}), matrix };
});
const named = [...new Set(rows.flatMap(r => r.matrix))].sort((a, b) => MATRIX_ROWS.findIndex(x => x.uid === a) - MATRIX_ROWS.findIndex(x => x.uid === b));
// the short title the persona prints: the matrix title up to its first colon, semicolon, comma, bracket or equals sign, without a leading article, at most three words, without a trailing small word
const STOP = new Set(['a', 'an', 'the', 'of', 'from', 'as', 'to', 'in', 'with', 'and', 'on', 'is', 'are', 'by', 'for']);
const shortTitle = t => { const w = t.split(/[:;,(]| = | − /)[0].trim().split(/\s+/).filter((x, i) => i || !/^(the|a|an)$/i.test(x)).slice(0, 3); while (w.length > 1 && STOP.has(w.at(-1).toLowerCase())) w.pop(); return w.join(' '); };
const matrixTitles = named.map(u => { const m = matrixUid.get(u); return { uid: u, src: m.src, title: m.title, short: shortTitle(m.title) }; });
const count = (f) => rows.reduce((c, r) => { for (const k of f(r)) c[k] = (c[k] || 0) + 1; return c; }, {});
const meta = { source: 'reports/lens_dictionary.json', rows: rows.length, lenses: lenses.length, terms: rows.reduce((s, r) => s + Object.keys(r.terms).length, 0),
  match: count(r => [r.match]), flags: count(r => r.flags), byLens: count(r => Object.keys(r.terms)), checks: [...new Set(rows.flatMap(r => r.checks))].length, matrixRows: matrixTitles.length };

// the compact form the persona reads: written here as code, so the data module carries the data and the one function that prints it
const COMPACT = `// ---- the compact form that the chat persona puts in its fixed core: one line per row, a function of the data above only.
// A term's short name is its text up to the first semicolon outside brackets; the full term stays in LENS_ROWS.
export const TAG_LETTER = { standard: 'S', checked: 'C', ours: 'R', open: 'O', input: 'I' };
export const shortName = t => { let d = 0; for (let i = 0; i < t.length; i++) { const c = t[i]; if ('([{'.includes(c)) d++; else if (')]}'.includes(c)) d--; else if (c === ';' && d === 0) return t.slice(0, i).trim(); } return t; };
export const compactLine = r => r.id + ' ' + r.atlas + (r.match === 'exact' ? '' : ' (' + r.match + ')') + ': ' + Object.entries(r.terms).map(([k, t]) => k + ' ' + shortName(t)).join('|')
  + ' [' + [r.flags.map(f => TAG_LETTER[f]).join(''), r.scope].filter(Boolean).join('; ') + (r.matrix.length ? ' x ' + r.matrix.join(' ') : '') + ']';
// The priority rule: the rows are printed in their order, which is their priority. lensDictionaryForm prints the first k rows (its first line says how many when they
// are not all, its matrix line names the matrix rows of the printed rows only); with a cap (a number of characters) the compact form is the form with the largest k
// that keeps it within the cap.
export const compactRowsShown = (rows = LENS_ROWS, lenses = LENSES, matrixTitles = LENS_MATRIX, cap = Infinity) => {
  let k = rows.length; while (k > 0 && lensDictionaryForm(rows, k, lenses, matrixTitles).length > cap) k--; return k; };
export function lensDictionaryForm(rows = LENS_ROWS, k = rows.length, lenses = LENSES, matrixTitles = LENS_MATRIX) {
  const keys = lenses.filter(l => !l.matrix && !l.page), shown = rows.slice(0, k), used = new Set(shown.flatMap(r => r.matrix));
  return ['LENS DICTIONARY (' + rows.length + ' rows' + (k < rows.length ? '; the first ' + k + ', by priority, are printed here' : '') + '): atlas objects named in ' + keys.map(l => l.key + ' ' + l.short).join(', ') + '.',
    'Row: id atlas name: key name|… [tags; scope x matrix rows]. Tags ' + Object.entries(TAG_LETTER).map(([w, l]) => l + ' ' + w).join(', ') + '; (partial), (none), (new): not an exact match.',
    ...shown.map(compactLine),
    'Matrix rows: ' + matrixTitles.filter(m => used.has(m.uid)).map(m => m.uid + ' ' + m.short).join(' · ')].join('\\n');
}
export function lensDictionaryCompact(rows = LENS_ROWS, lenses = LENSES, matrixTitles = LENS_MATRIX, cap = Infinity) {
  return lensDictionaryForm(rows, compactRowsShown(rows, lenses, matrixTitles, cap), lenses, matrixTitles);
}
`;
const head = fs.readFileSync(fileURLToPath(import.meta.url), 'utf8').split('\n').slice(0, 3).join('\n');
const body = [head,
  '// GENERATED by make_lens_dictionary.mjs from reports/lens_dictionary.json (do not edit by hand; rerun the script on the json).',
  '// Match: exact, partial, none, or new (the field\'s object is an addition of the atlas). Flags: the tags of the translation (checked only with a check id, standard only with a source read).',
  'export const LENS_META = ' + JSON.stringify(meta) + ';',
  'export const LENSES = ' + JSON.stringify(lenses).replace(/\},\{/g, '},\n{') + ';',
  'export const LENS_ROWS = [',
  rows.map(r => JSON.stringify(r)).join(',\n'),
  '];',
  'export const LENS_MATRIX = ' + JSON.stringify(matrixTitles).replace(/\},\{/g, '},\n{') + ';',
  COMPACT].join('\n');
if (check) {
  const now = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8') : '';
  if (now !== body) die('lensDictionaryData.js differs from what ' + path.relative(HERE, path.resolve(src)) + ' gives (run without --check to rewrite it)');
  console.log(`lensDictionaryData.js is up to date: ${meta.rows} rows, ${meta.terms} terms in ${Object.keys(meta.byLens).length} lenses, ${meta.checks} check ids, ${meta.matrixRows} matrix rows named`);
  process.exit(0);
}
fs.writeFileSync(OUT, body);
console.log(`wrote lensDictionaryData.js: ${meta.rows} rows, ${meta.terms} terms (${Object.entries(meta.byLens).map(([k, v]) => k + ' ' + v).join(', ')}), match ${Object.entries(meta.match).map(([k, v]) => k + ' ' + v).join(', ')}, ${meta.checks} check ids, ${meta.matrixRows} matrix rows named`);
