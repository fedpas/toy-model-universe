// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The category chapter (step 18 of the lenses page, "What is label 0?") as data, without a browser: categoryCopy.js, categoryIntegration.js, categorySelfcheckSource.js,
// claimsLocators_lnc.json and CategorySection.jsx. English and Italian have the same structure, tags and check ids; only the four tags; known ground is standard and
// checked and neither ours nor open; every checked statement names checks, and every check id the chapter prints exists in a shipped script (cat·, bridge·), in the
// widgets' script (catw·, once selfcheck/reports/lens_cat_check.py is in the package) or as a theorem with its script (Thm T#, researchers_checks/); none of the retired
// wordings of DECISIONS.md §1 and X10 is back; the Young Learner's strings carry no formula and no technical word; the mirror is the script byte for byte; the numbers
// the text quotes are the ones cat_check.py stores (cat_results.json) and the matrix data give; the Map nodes point at anchors of the section; the claims rows resolve;
// the persona stays under 1 800 characters; no e-mail address.   Run: node test_lens_category.mjs   (the widgets' script check: see the "catw" lines of the output)
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
process.chdir(PKG);   // every file below is named relative to the package folder
import { COPY, THM, THM_WORDS } from './categoryCopy.js';
import { MAP_NODES, MAP_TEXT, PERSONA } from './categoryIntegration.js';
import { CAT_CHECK_PY } from './categorySelfcheckSource.js';
import { buildClaims } from './make_claims_data.mjs';
const FOUR = ['standard', 'checked', 'ours', 'open'];   // the category chapter uses the four flags; the fifth, input, is not used on its lines
import { THEOREMS } from './researchersData.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { LENSES, MTHREADS } from './mapData.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const info = m => console.log('  ' + m);
const rd = f => fs.readFileSync(f, 'utf8');
const SECTION = rd('CategorySection.jsx');

// ---- 0. walk a copy tree: every string with its path; every statement item {k, t}
const strings = (o, p = []) => typeof o === 'string' ? [[p.join('.'), o]] : Array.isArray(o) ? o.flatMap((x, i) => strings(x, [...p, i])) : o && typeof o === 'object' ? Object.entries(o).flatMap(([k, v]) => strings(v, [...p, k])) : [];
const items = (o, p = []) => Array.isArray(o) ? o.flatMap((x, i) => items(x, [...p, i])) : o && typeof o === 'object' ? [...(typeof o.k === 'string' && typeof (o.t ?? o.text) === 'string' ? [[p.join('.'), o]] : []), ...Object.entries(o).flatMap(([k, v]) => items(v, [...p, k]))] : [];
// the shape of a copy tree: every string is 's', except the fields of a statement or an entry that must be equal in both languages (tags, check ids, ids, anchors, flags)
const isEntry = o => ['t', 'text', 'pts', 'wrong'].some(k => k in o);
const shape = o => typeof o === 'string' ? 's' : typeof o === 'boolean' ? 'b:' + o : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, isEntry(o) && ['k', 'c', 'id', 'm', 'go', 'fid', 'isNew', 'fold'].includes(k) ? o[k] : shape(o[k])])) : typeof o;
const formal = { en: COPY.en, it: COPY.it }, plain = { en: COPY.yl.en, it: COPY.yl.it };

// ---- 1. English and Italian: the same structure, tags, check ids, flags m, anchors (only the words differ)
ok(JSON.stringify(shape(COPY.en)) === JSON.stringify(shape(COPY.it)), 'formal voice: English and Italian have the same structure, tags, check ids and anchors');
ok(JSON.stringify(shape(COPY.yl.en)) === JSON.stringify(shape(COPY.yl.it)), 'plain voice: English and Italian have the same structure and tags');
ok(THM.every(t => t.en.length === 2 && t.it.length === 2 && t.it.every(Boolean)) && Object.keys(THM_WORDS.en).join() === Object.keys(THM_WORDS.it).join(), 'theorem labels and status words in both languages');
// New text of v11 is English in the Italian slots (the author's decision of 7 October 2026); these leaves of this chapter are the named exceptions of the next check, and each one must really be the English text
const EN_IN_IT = ['first.stm.7.t', 'top.pts.3.t', 'questions.items.5.t', 'questions.items.5.chk', 'questions.items.5.not', 'questions.items.10.t', 'questions.items.10.chk', 'questions.items.10.not', 'deadends.pts.1.t', 'deadends.pts.2.t', 'deadends.pts.3.t', 'persp.items.4.pts.0.t', 'refine.h', 'questions.items.8.chk', 'questions.items.9.t', 'questions.items.9.chk', 'questions.items.9.not', 'honest.pts.6.t', 'honest.pts.9.t',
  'first.stm.2.t', 'first.stm.4.t', 'label0.pts.4.t', 'frobenius.pts.1.t', 'frobenius.pts.2.t', 'frobenius.pts.4.t', 'moves.pts.6.t', 'more.items.0.title', 'more.items.0.text', 'persp.items.2.pts.0.t', 'persp.items.2.pts.1.t', 'persp.items.5.pts.1.t', 'persp.items.5.pts.2.t', 'questions.items.4.t', 'questions.items.4.chk', 'questions.items.4.not', 'honest.pts.1.t', 'questions.items.0.t', 'questions.items.0.chk',
  // the reading of Majkić’s arrows on the labels (arXiv:2403.19689, both versions): the papers card, the dead end, P6, Majkić’s zero, the occupation reading, the five definitions and the section Arrows as vectors
  'papers.items.3.h', 'papers.items.3.t', 'deadends.pts.5.t', 'persp.items.5.pts.0.t', 'zero.pts.3.t', 'cube.pts.2.t', 'menu.arrows', 'arrows.h', 'arrows.intro',
  ...[11, 12, 13, 14, 15].flatMap(i => [`defs.items.${i}.0`, `defs.items.${i}.1`]), ...Array.from({ length: 10 }, (_, i) => `arrows.pts.${i}.t`)];
ok(EN_IN_IT.every(p => { const g = o => p.split('.').reduce((a, k) => a?.[k], o); return typeof g(COPY.en) === 'string' && g(COPY.en) === g(COPY.it); }), 'every named English-in-Italian leaf is the English text (the list cannot go stale)');
const same = []; for (const l of ['en']) for (const [p, s] of strings(formal[l])) { const t = p.split('.').reduce((a, k) => a?.[k], formal.it); if (/\.(k|id|fid|go|c\.\d+)$/.test(p) || EN_IN_IT.includes(p)) continue; if (t === s && /[a-z]{4,} [a-z]{4,} [a-z]{3,}/i.test(s) && !/^(D\. Lundholm|J\. C\. Baez|Y\. Tian|Z\. Majkić)/.test(s)) same.push(p); }
ok(same.length === 0, 'no English sentence is left untranslated in the Italian copy: ' + same.slice(0, 5).join(', '));
for (const l of ['en', 'it']) { const a = strings(MAP_TEXT[l]).length, b = strings(MAP_TEXT.yl[l]).length; ok(a === MAP_NODES.length * 2 && b === MAP_NODES.length * 2, `${l}: every Map node has a title and a text in the formal and the plain voice`); }

// ---- 2. four flags only; every statement tagged; known ground computed from the flags
const all = [...items(COPY.en, ['en']), ...items(COPY.it, ['it']), ...items(COPY.yl.en, ['yl', 'en']), ...items(COPY.yl.it, ['yl', 'it'])];
ok(all.length > 200, `the copy holds ${all.length} tagged statements`);
for (const [p, x] of all) { const f = x.k.split(/\s+/).filter(Boolean); ok(f.length > 0 && f.every(k => FOUR.includes(k)) && new Set(f).size === f.length, `${p}: four flags only, at least one, no repeat ("${x.k}")`); }
// X12: a line partly textbook (standard) and partly ours would be split; the copy never tags a line both standard and ours
ok(all.every(([, x]) => !(/\bstandard\b/.test(x.k) && /\bours\b/.test(x.k))), 'no line is tagged both standard and ours (such a line is split in two)');

// ---- 3. check ids: every formal checked statement names its checks; every id the chapter prints exists
const CAT = rd('selfcheck/reports/cat_check.py'), BRIDGE = rd('selfcheck/reports/bridge_check.py'), LENS = 'selfcheck/reports/lens_cat_check.py';
const catIds = new Set([...CAT.matchAll(/^chk\('([A-Z]\d+[a-z]?)'/gm)].map(m => m[1])), bridgeIds = new Set([...BRIDGE.matchAll(/chk\('([A-Z]\d+[a-z]?)'/g)].map(m => m[1]));
ok(catIds.size === 52 && ['S1', 'L0', 'L1a', 'R1', 'R4', 'G1', 'G2', 'F1', 'F5', 'K1a', 'K5c', 'T4', 'M1', 'M2', 'W1', 'Q1', 'Q5', 'E1', 'J3', 'B1', 'C1', 'C3'].every(i => catIds.has(i)), `cat_check.py has its 52 check ids (${catIds.size})`);
ok(bridgeIds.has('A5') && bridgeIds.has('A6'), 'bridge_check.py has A5 and A6 (the complement and the Hodge star)');
const lensThere = fs.existsSync(LENS), lensText = lensThere ? rd(LENS) : '';
const thmIds = new Set(THEOREMS.map(t => t.id));
const everyText = [...strings(COPY), ...strings(MAP_TEXT), ['PERSONA', PERSONA]].map(x => x[1]).join('\n');
const cited = new Set(), catwCited = new Set();
for (const m of everyText.matchAll(/\b(cat|bridge|catw)·([A-Z]\d+[a-z]?)(?:–([A-Z]?\d+[a-z]?))?/g)) {
  const [, ns, id, end] = m, endId = end ? (/^[A-Z]/.test(end) ? end : id.replace(/\d+[a-z]?$/, '') + end) : null;
  for (const x of [id, endId].filter(Boolean)) (ns === 'catw' ? catwCited : cited).add(ns + '·' + x);
}
for (const m of everyText.matchAll(/\bThm (T\d+)/g)) cited.add('Thm ' + m[1]);
for (const c of cited) {
  if (c.startsWith('cat·')) ok(catIds.has(c.slice(4)), `${c} is a check of cat_check.py`);
  else if (c.startsWith('bridge·')) ok(bridgeIds.has(c.slice(7)), `${c} is a check of bridge_check.py`);
  else { const t = c.slice(4); ok(thmIds.has(t) && fs.existsSync(`researchers_checks/check_${t}.py`), `${c} is a theorem of researchersData.js with its script researchers_checks/check_${t}.py`); }
}
ok(!/\bcat·A[56]\b/.test(everyText), 'the complement checks are bridge·A5 and bridge·A6 (cat_check.py has no A block; DECISIONS.md wrote cat·A5, cat·A6)');
if (lensThere) for (const c of catwCited) ok(new RegExp(`['"]${c.slice(5)}['"]`).test(lensText), `${c} is a check of lens_cat_check.py`);
else info(`catw: ${LENS} is the widgets agent's script and is not in this package yet; ${catwCited.size} ids cited (${[...catwCited].sort().join(', ')}), checked once it is in`);
ok([...catwCited].every(c => /^catw·P[1-6]$/.test(c)), 'the chapter cites only the catw ids of the DECISIONS table (P1 to P6)');
// the checks of selfcheck/bridges/ (bd·<family>·n, the script of the family prefix): each cited id is a check of that folder once it is in the package
const BD_RE = /\bbd·(phy|str|sol|xph|fk|mat|geo|alg|cat|xck|hh|rev|tor|en|fur|kep|mjc|mja|mjg|mjp)·(\d+)(?:–(\d+))?/g;
const bdIn = s => [...String(s).matchAll(BD_RE)].flatMap(m => { const a = +m[2], b = m[3] ? +m[3] : a; return Array.from({ length: b - a + 1 }, (_, i) => `bd·${m[1]}·${a + i}`); });
const BRIDGES = 'selfcheck/bridges', bridgesThere = fs.existsSync(BRIDGES), bdCited = new Set([...bdIn(everyText), ...strings(COPY).flatMap(([, s]) => bdIn(s))]);
const bdText = bridgesThere ? fs.readdirSync(BRIDGES).filter(f => /\.py$/.test(f)).map(f => [f, rd(path.join(BRIDGES, f))]) : [];
if (bridgesThere) for (const id of bdCited) { const fam = id.split('·')[1]; ok(bdText.some(([f, t]) => f.startsWith(fam + '_') && new RegExp(id + '(?!\\d)').test(t)), `${id} is a check of a script ${BRIDGES}/${fam}_*.py`); }
else info(`bd: ${BRIDGES} is not in this package yet; ${bdCited.size} ids cited (${[...bdCited].sort().join(', ')}), checked once it is in`);
ok(bdCited.size >= 15 && ['bd·cat·4', 'bd·geo·5', 'bd·xck·3', 'bd·cat·5', 'bd·cat·8', 'bd·cat·16', 'bd·cat·17', 'bd·hh·3', 'bd·cat·11'].every(x => bdCited.has(x)), 'the chapter cites the bridge checks of the degenerate clock, the super-Frobenius forms, the functor, the Hochschild groups and the Morita monoid');
// a formal statement tagged checked names at least one check that already exists (a catw id alone is not enough before the merge)
const formalItems = [...items(COPY.en, ['en']), ...items(COPY.it, ['it'])];
for (const [p, x] of formalItems) if (/\bchecked\b/.test(x.k)) { const c = x.c || []; ok(c.length > 0 && c.some(i => !i.startsWith('catw·')), `${p}: a checked statement names a check of a shipped script or a theorem (${c.join(', ')})`); }
// a statement that is not tagged checked names no check as its proof (questions say what was checked in their own field)
for (const [p, x] of formalItems) if (!/\bchecked\b/.test(x.k) && x.c && x.c.length) ok(/\bours\b/.test(x.k), `${p}: a line not tagged checked cites checks only beside an ours reading (${x.c.join(', ')})`);
// the theorems' status words are the ones researchersData.js gives
for (const t of THM) { const T = THEOREMS.find(x => x.id === t.id); ok(T && T.status === t.st && T.verifier === t.v, `Thm ${t.id}: status ${t.st}/${t.v} as researchersData.js says (${T && T.status}/${T && T.verifier})`); }
// the chapter states each result as it stands: no corrections block, no erratum id, and the present statements that the dead ends and the refinements carry
ok(!('corr' in COPY.en) && !('corr' in COPY.it) && !('corr' in COPY.yl.en) && !('corr' in COPY.yl.it), 'the chapter has no corrections block');
ok(!/\bE-\d{3}\b/.test(JSON.stringify(COPY)), 'no erratum id in the chapter copy');
ok(!/\bE-\d{3}\b|erratum|errata/i.test(JSON.stringify(MAP_TEXT) + PERSONA), 'no erratum id in the Map text or the persona of the chapter');
for (const l of ['en', 'it']) { const R = COPY[l].script.report; ok(R && R.file === 'reports/html/category_atlas_report.html' && fs.existsSync(R.file) && !COPY.yl[l].script, `${l}: the chapter ends with a link to its full report (the file ships in reports/html/); the Young Learner's page has no script section of its own`); }
for (const l of ['en', 'it']) { const R = COPY[l].refine; ok(R.h === 'Two refinements' && R.pts.length === 2 && !('now' in R) && !('struck' in R) && !('struck' in COPY[l].lbl), `${l}: two refinements, no struck sentence, no struck label`); }
for (const l of ['en', 'it']) { const D = COPY[l].deadends.pts.map(x => x.t).join('\n');
  ok(/top-blade form is symmetric only for n odd/.test(D) && /every state vanishes on J/.test(D) && /λ\(1\) = 0/.test(D) && /the scalar part stays the state/.test(D) && /λ\(u·\) with u any unit, and only the symmetric ones are a torsor under the central units/.test(D), `${l}: the dead ends state the symmetric top-blade form (n odd), the states vanishing on J and the Frobenius forms λ(u·) as present facts`); }
{ const N9 = COPY.en.more.items.find(x => x.id === 'N9'); ok(/elliptic quadric Q⁻\(5,2\)/.test(N9.text) && /graded tensor product/.test(N9.text) && N9.c.includes('cat·W2') && N9.c.includes('Thm T11'), 'N9 states that Cl(6,0) gives the elliptic quadric Q⁻(5,2) and that the ladder product is the graded tensor product (cat·W2, Thm T11)'); }
ok(/^Two refinements/.test(COPY.en.persp.items[4].pts[0].t) && !/withdrawn|struck/.test(COPY.en.persp.items[4].pts[0].t), 'P5 names the two refinements');
// the clock of a degenerate cell, the super-Frobenius forms and the functor are stated as they are (bridge checks bd·…)
for (const l of ['en', 'it']) { const C = COPY[l], N2 = C.more.items.find(x => x.id === 'N2');
  ok(/the Gauss sum of the quotient Cl\(p,q\) = Cl\(p,q,r\)\/J/.test(N2.text) && /the Gauss sum of the mother cell Cl\(p\+r,q\+r\)/.test(N2.text) && /forced, not a convention/.test(N2.text) && /graded Azumaya/.test(N2.text) && /r is the base ring/.test(N2.text) && /ℤ₈ × ℕ/.test(N2.text) && /pointer, source unread/.test(N2.text) && ['bd·cat·4', 'bd·geo·5', 'bd·hh·1–4', 'bd·cat·11'].every(x => N2.c.includes(x)) && !/this page’s convention|blind to r/.test(N2.text), `${l}: N2 states the clock of a degenerate cell as that of its quotient and of its mother cell (forced), r as the base ring and the Morita monoid`);
  for (const x of [C.first.stm[4], C.label0.pts[4]]) ok(/forced, not a convention/.test(x.t) && /mother cell Cl\(p\+r,q\+r\)/.test(x.t) && x.c.includes('bd·geo·5') && x.c.includes('bd·xck·3') && !/blind to r|does not see r|the convention of cat·K4a/.test(x.t), `${l}: ${x.id || 'the label-0 card'} states the clock of Cl(p,q,r) as forced (bd·geo·5, bd·xck·3)`);
  ok(/In super vector spaces λ is super-symmetric for every \(p,q,r\)/.test(C.first.stm[2].t) && /the Nakayama twist is the Koszul sign/.test(C.first.stm[2].t) && C.first.stm[2].c.includes('bd·cat·5') && C.first.stm[2].c.includes('bd·cat·8'), `${l}: A.3 adds the super-symmetric statement (bd·cat·5, bd·cat·8)`);
  ok(/In super vector spaces it is a theorem/.test(C.deadends.pts[3].t) && C.deadends.pts[3].c.includes('bd·cat·8'), `${l}: the torsor dead end is ungraded; in super vector spaces it is a theorem (bd·cat·8)`);
  ok(/^Cl is a functor/.test(C.moves.pts[6].t) && C.moves.pts[6].c.includes('bd·cat·16') && C.moves.pts[6].c.includes('bd·cat·17'), `${l}: the moves are Cl applied to maps of quadratic spaces, halving a natural isomorphism (bd·cat·16, bd·cat·17)`);
  { const Q6 = C.questions.items.find(x => x.id === 'QT6'), A8 = C.first.stm.find(x => x.id === 'A.8'), T3 = C.top.pts.find(x => /carries the label form of Cl\(n,0\) for every n ≥ 3/.test(x.t));
    ok(Q6.k === 'checked ours' && /for every n = 3…20/.test(Q6.t) && /the kernel is the centre of W\(E_\{n\}\)/.test(Q6.t) && /orthogonal transvections of q; that argument is ours/.test(Q6.t) && ['bd·en·1', 'bd·en·2', 'bd·en·3', 'bd·en·4', 'bd·en·5'].every(x => Q6.c.includes(x) && Q6.chk.includes(x)) && /^For n > 20, that the transvection group is O\(q\): Dieudonné’s theorem .*pointers, sources unread\.$/.test(Q6.not), `${l}: QT6 gives the image of W(E_n) mod 2 as O(q) for n = 3…20, the kernel as the centre for n ≤ 8, the transvection argument for every n (bd·en·1–5), and Dieudonné’s theorem as a pointer`);
    ok(/onto for n = 3…20/.test(A8.t) && /is the centre of W\(E_\{n\}\)/.test(A8.t) && ['bd·en·2', 'bd·en·3'].every(x => A8.c.includes(x) && T3.c.includes(x)) && /onto for every n = 3…20/.test(T3.t) && !/9…12/.test(JSON.stringify(C)), `${l}: A.8 and the top of the ladder state W(E_n) → O(q) onto for n = 3…20 with the kernel the centre (bd·en·2, bd·en·3); no statement stops at n = 9…12`); }
  const Q = C.questions.items.find(x => x.id === 'QC3'); ok(Q.k === 'standard open' && /Kitaev’s periodic table, arXiv:0901\.2686; standard/.test(Q.t) && /needs T² and C² as input/.test(Q.t), `${l}: QC3 states Kitaev's correspondence as standard and the class assignment as needing T² and C²`); }

// ---- 4. retired wording (DECISIONS §1 "Retired wording" and X10): absent from every string of the chapter (the list below is the list of what must not be said)
const live = [...strings(COPY), ...strings(MAP_TEXT).map(([p, s]) => ['map.' + p, s]), ['persona', PERSONA]];
const sentences = s => s.split(/(?<=[.!?;:])\s+/);
const NEVER = [
  [/Born rule is the Frobenius form|regola di Born è la forma di Frobenius/i, 'the Born rule is the Frobenius form'],
  [/\bexplain(s|ed)?\b|\bspieg/i, '"explains"'],
  [/antiparticle|antiparticella/i, 'particle to antiparticle'],
  [/entangled (two-qubit )?states|quadric of entangled|stati entangled/i, 'Cl(2,2) as the quadric of entangled states'],
  [/\binert\b|ramified|ramificat|\binerte\b/i, 'inert / ramified / split (numerology)'],
  [/Golay|three 8s|tre 8|24 = 3 ?× ?8|\bquark/i, 'numerology (Golay, three 8s, 24 = 3 × 8, quarks)'],
  [/135 points|270 solids|27 points|45 lines|135 punti|270 solidi|27 punti|45 rette/i, 'quadric counts (numerology)'],
  [/Hodge star (is|=) XOR|stella di Hodge è (lo )?XOR/i, '"Hodge star = XOR with 1…1"'],
  [/our reading only|solo una nostra lettura|reason for the ten|ragione del dieci/i, 'the ten classes as our reading only / the reason for the ten'],
  [/fails with only null generators|fallisce con soli generatori nulli/i, 'halving fails with only null generators (it fails for r ≥ 3)'],
  [/radical is a face|radicale è una faccia/i, 'the radical is a face (only for r = 1)'],
  [/label 0 is the boundary|etichetta 0 è il confine/i, 'label 0 is the boundary between the definite and the Lorentzian rungs'],
  [/horizon (is|as) (a )?(dynamical|global)|global horizon (is|has)/i, 'horizon speculation'],
];
for (const [re, what] of NEVER) { const hits = live.filter(([, s]) => re.test(s)); ok(hits.length === 0, `retired wording "${what}" is gone: ${hits.map(h => h[0]).slice(0, 4).join(', ')}`); }
// "conserved" only to say that nothing is conserved here (no Hamiltonian); "functor" only to say these are maps, not functors; "derived" never in an ours line
for (const [p, s] of live) for (const sen of sentences(s)) {
  if (/\bconserv(ed|ation)\b|\bconservat[oaie]\b|\bsi conserva\b/i.test(sen)) ok(/nothing is conserved|non si conserva|“conserved” needs|“conservato” richiede/i.test(sen), `${p}: "conserved" only where nothing is conserved: ${sen.slice(0, 90)}`);
  if (/functor|funtor/i.test(sen)) ok(/^Cl is a functor: restrict, quotient and mother are Cl applied to maps of quadratic spaces/.test(s) && /bd·cat·17/.test(s) && /bd·cat·16/.test(s) && /natural isomorphism/.test(s) && /Frobenius structure of each one/.test(s), `${p}: "functor" only where the chapter states that Cl is a functor, with its checks bd·cat·16 and bd·cat·17: ${sen.slice(0, 90)}`);
  if (/maps, not functors|mappe, non funtori|no category is named|nessuna categoria è nominata/i.test(sen)) ok(false, `${p}: the moves are Cl applied to maps of quadratic spaces, not "maps, not functors": ${sen.slice(0, 90)}`);
  if (/\bHodge\b/.test(sen)) ok(/r = 0|not a Hodge|non una stella di Hodge|only when no generator is null|solo quando nessun generatore è nullo|invertible top blade|lama massima invertibile|“Hodge”/.test(sen), `${p}: a Hodge star only for r = 0: ${sen.slice(0, 100)}`);
  if (/(?<!Koszul |simplicial )\b(boundary|border)\b|\bconfine\b/i.test(sen)) ok(/\bours\b|our (idea|way of reading|readings?)|\bnostr[aoie]\b|“[^”]*(boundary|border|confine)[^”]*” is ours|è nostro/i.test(s), `${p}: "boundary" or "border" only as our reading: ${sen.slice(0, 100)}`);
  if (/first appears in the category|compare per la prima volta nella categoria/i.test(sen)) ok(/\bours\b|nostra/.test(s), `${p}: "label 0 first appears in the category at n = 3" only as our reading`);
}
for (const [p, x] of all) if (/\bours\b/.test(x.k)) ok(!/\bderiv(ed|ation)\b|\bderivat[oaie]\b/i.test(x.t ?? x.text), `${p}: an ours line says nothing like "derived"`);
{ const MJ_AT = ['papers.items.3.h', 'deadends.pts.5.t', 'persp.items.5.pts.0.t', 'zero.pts.3.t', 'arrows.intro', 'arrows.pts.0.t', 'arrows.pts.4.t', 'arrows.pts.7.t', 'arrows.pts.8.t', 'arrows.pts.9.t'];
  const at = live.filter(([, s]) => /Majki/.test(s)).map(([p]) => p).sort(), want = [...['en', 'it'].flatMap(l => MJ_AT.map(p => `${l}.${p}`)), 'map.en.category.1', 'map.it.category.1'].sort();
  ok(JSON.stringify(at) === JSON.stringify(want), 'Majkić appears in the papers card, the dead end, "what not to add", Majkić’s zero, the section Arrows as vectors and the Map text, and nowhere else: ' + at.filter(p => !want.includes(p)).concat(want.filter(p => !at.includes(p))).join(', '));
  // the two versions of arXiv:2403.19689 are named where they differ: version 2 in the dead end and P6, both in the papers card; version 3 defines the norm as a crossing time
  for (const l of ['en', 'it']) { const C = COPY[l], P = C.papers.items[3], D = C.deadends.pts[5], P6 = C.persp.items[5].pts[0];
    ok(/arXiv:2403\.19689 v3, 17 July 2026 \(v2, 22 March 2026\)$/.test(P.h) && /^Version 2, as written, is not a Clifford algebra of a vector space/.test(P.t) && /Version 3 defines the norm as a positive additive weight, the time to cross a path at speed 1/.test(P.t) && /subalgebra of Cl\(2,0\)/.test(P.t) && /no associative extension/.test(P.t) && ['cat·J1', 'cat·J2', 'bd·mjc·1', 'bd·mjc·2', 'bd·mja·16', 'bd·mja·18'].every(x => P.c.includes(x)), `${l}: the papers card names both versions, what version 3 defines and its reading on the labels (bd·mjc·1, 2, bd·mja·16, 18)`);
    ok(/construction in version 2, as a Clifford algebra/.test(D.t) && /Version 3 defines the norm as a crossing time/.test(D.t) && D.c.join() === 'cat·J1,cat·J2', `${l}: the dead end is the construction of version 2 (cat·J1, cat·J2); version 3 defines the norm as a crossing time`);
    ok(P6.k === 'ours' && /^Majkić’s version 2 construction and Tian’s DG category stay in the report/.test(P6.t) && /the labels’ own, the disjoint sum and the popcount/.test(P6.t) && !/fails as written/.test(P6.t), `${l}: P6 keeps version 2 in the report and places the partial sum and weight of version 3 on the labels`); } }
// Arrows as vectors: Majkić’s partial sum and weight read on the labels, each point with the bridge checks that compute it (families mjc, mja, mjg, mjp of selfcheck/bridges/)
for (const l of ['en', 'it']) { const A = COPY[l].arrows, P = A.pts, has = (i, ids) => ids.every(x => P[i].c.includes(x));
  ok(A.h === 'Arrows as vectors: the labels as a category' && P.length === 10 && P.map(x => x.k).join('|') === 'checked|checked|checked|checked|standard checked|checked|checked|checked|checked|checked ours' && P.map(x => !!x.m).join() === 'false,false,false,false,false,true,true,true,false,true', `${l}: the section Arrows as vectors has its ten points, tags and Mathematician-only points`);
  ok(/partial commutative monoid with an additive norm/.test(P[0].t) && /strong form: whenever one side is defined, so is the other/.test(P[0].t) && /2ⁿ objects, 3ⁿ arrows, 4ⁿ composable pairs, \(k \+ 2\)ⁿ k-simplices/.test(P[0].t) && has(0, ['bd·mjc·1', 'bd·mjc·2', 'bd·mjc·3', 'bd·mja·21', 'bd·mjp·33']), `${l}: the labels with ⊕ and the popcount satisfy (8), (9) and Def. 4; their category is Bₙ with its counts`);
  ok(/label monoid of the null cell Cl\(0,0,n\)/.test(P[1].t) && /4\^\{p\+q\}·3\^\{r\} pairs/.test(P[1].t) && /exactly when p \+ q = 0/.test(P[1].t) && /hard-core bosons/.test(P[1].t) && has(1, ['bd·mjc·6', 'bd·mjc·33', 'bd·mjp·34']), `${l}: ⊕ is the label monoid of the null cell (bd·mjc·6, 33, bd·mjp·34)`);
  ok(/^Partiality is not non-associativity/.test(P[2].t) && /6859 triples/.test(P[2].t) && /Cayley–Dickson sign/.test(P[2].t) && has(2, ['bd·mja·29', 'bd·mja·30', 'cat·S1']), `${l}: partiality is not non-associativity (bd·mja·29, 30, cat·S1)`);
  ok(/no endomorphism but identities and no isomorphism between distinct objects/.test(P[3].t) && /dimension 2ⁿ − 1/.test(P[3].t) && /exactly U/.test(P[3].t) && has(3, ['bd·mjc·12', 'bd·mjc·16', 'bd·mjp·9', 'bd·mjp·10']), `${l}: positive additive weights exist exactly on the acyclic categories; on Bₙ they are potential differences and charges`);
  ok(/Lawvere metric \(Lawvere 1973\)/.test(P[4].t) && /Hamming distance/.test(P[4].t) && /d = ∞ where f does not factor through g/.test(P[4].t) && has(4, ['bd·mjc·17', 'bd·mjc·18', 'bd·mjg·32']), `${l}: |T∖S| is a Lawvere metric (standard, read) and Majkić’s distance is of the same kind`);
  ok(/sphere S\^\{n−2\}/.test(P[5].t) && /Möbius number/.test(P[5].t) && /∂² = 0/.test(P[5].t) && /carries no cohomology class/.test(P[6].t) && /3ⁿ − 2ⁿ⁺¹ \+ 1 independent cycles/.test(P[6].t) && has(5, ['bd·mjg·22', 'bd·mjg·23', 'bd·mjg·24']) && has(6, ['bd·mjc·21', 'bd·mjc·22', 'bd·mjc·23', 'bd·mjg·25']), `${l}: the nerve, the sphere, the cube complex and the planar cochains`);
  ok(/sheaf of algebras only for the null cell/.test(P[7].t) && /\(𝔽₂ⁿ, xor, and\)/.test(P[7].t) && has(7, ['bd·mjc·25', 'bd·mjc·26', 'bd·mjc·27', 'bd·mjc·28', 'bd·mjc·37']), `${l}: the cell as a sheaf on the Alexandrov space of Bₙ, of algebras only for the null cell`);
  ok(/unique cone of least total leg weight/.test(P[8].t) && /need not be a limit/.test(P[8].t) && /n! for hard-core bosons and 0 for fermions/.test(P[8].t) && !/unit is the identity|displaces no object/.test(P[8].t) && has(8, ['bd·mjp·16', 'bd·mjp·17', 'bd·mjp·18', 'bd·mjp·19', 'bd·mjp·21']), `${l}: limits and least weight (bd·mjp·16–19, 21); the unit of Δ ⊣ ∧, which the script only prints, is not claimed`);
  ok(/C_\{k\+1\} = Fun\(B_\{k\}, C\): ours/.test(P[9].t) && /2, 3, 6, 20, 168 objects/.test(P[9].t) && /7581 arrows/.test(P[9].t) && /pullback along the projection/.test(P[9].t) && has(9, ['bd·mjc·30', 'bd·mjc·31', 'bd·mjc·32']), `${l}: the comma levels as categories of commutative cubes (ours; bd·mjc·30–32)`);
  const Z = COPY[l].zero.pts[3], Q = COPY[l].cube.pts[2];
  ok(Z.k === 'checked' && /^Majkić’s zero\./.test(Z.t) && /not the empty label, the unit/.test(Z.t) && /sum of all identities/.test(Z.t) && Z.c.join() === 'bd·mja·31,bd·mjg·12' && !/\blabel 0 is the unit/i.test(Z.t), `${l}: Majkić’s zero is the element 0, not a null generator, not e₃, not the empty label (bd·mja·31, bd·mjg·12)`);
  ok(Q.k === 'checked' && /category of creation processes/.test(Q.t) && /\[N, A\] = \|T∖S\| A/.test(Q.t) && /3ⁿ against 2ⁿ⁻¹\(2ⁿ \+ 1\)/.test(Q.t) && /flux −1/.test(Q.t) && ['bd·mjp·4', 'bd·mjp·5', 'bd·mjp·6', 'bd·mjp·7', 'bd·mjp·8', 'bd·mjc·8'].every(x => Q.c.includes(x)), `${l}: the occupation reading of the cube category (bd·mjp·3–8, bd·mjc·8, bd·mja·9)`);
  ok(!/Borel/.test(JSON.stringify(COPY[l])), `${l}: the incidence algebra of Bₙ is called triangular, never a Borel subalgebra`); }
ok(/<Sec id="cat-arrows" h=\{t\.arrows\.h\}>/.test(SECTION) && /\['cat-arrows', t\.menu\.arrows\]/.test(SECTION), 'CategorySection.jsx draws the section Arrows as vectors and the menu scrolls to it');
// the trio −1, 0, +1 appears only as ours, beside the chapter's own check
for (const [p, x] of all) if (/\btrio\b/i.test(x.t ?? '') && !/\bsquares −1, 0, \+1|quadrati −1, 0, \+1/.test(x.t)) ok(/\bours\b/.test(x.k), `${p}: the trio is tagged ours`);
// the three values of a generator's square, and the three-way sorting of elements in the other chapters: one ours line; the null part as a monoid with zero; the Carroll pointer
for (const l of ['en', 'it']) { const H = COPY[l].honest.pts.find(x => /three values of a generator’s square/.test(x.t)), Q = id => COPY[l].questions.items.find(x => x.id === id);
  ok(H && H.k === 'ours' && /squares of elements and of bivectors/.test(H.t) && !/\btrio\b/i.test(H.t), `${l}: the sorting by the square is an ours line about generators here and elements and bivectors elsewhere`);
  ok(/monoid with zero/.test(Q('QB2').t) && /twisted contracted monoid algebra of M/.test(Q('QB2').t) && /core·B8/.test(Q('QB2').chk) && /core·B7b/.test(Q('QB2').chk) && /we do not know the right framework/.test(Q('QB2').not), `${l}: QB2 says the labels form a monoid with zero and names core·B7, B7b and B8`);
  ok(/core·B9/.test(Q('QA3').chk) && /Smith normal form/.test(Q('QA3').chk), `${l}: QA3 names core·B9 (the universal grading group)`);
  const C = COPY[l].persp.items.flatMap(x => x.pts || []).concat(COPY[l].honest.pts).find(x => /Carroll-type structure/.test(x.t));
  ok(C && C.k === 'ours open' && /arXiv:1903\.09654/.test(C.t) && /arXiv:1402\.0657/.test(C.t), `${l}: the Carroll question stays ours and open and carries its two pointers`); }

// ---- 5. the Young Learner: no formula, no technical word (the lists of test_yl_ui.mjs, plus DECISIONS X0)
const SYMBOLS = /[∇∂∫∑∏⊗⊕⊙≅≈≠≤≥∈∉∀∃⟨⟩†ℝℂℍ𝕆𝔹𝕊𝕍ℤℕ→↔⇒⇔√∞∧∨⊂⊃∪∩⊥ωψφθΩλμνρσκτΣΔΓΛΠΦΨΘαβγδεζηιξπχ]|[₀-₉⁰¹⁴-⁹]|\^|[A-Za-z0-9)\]}]_[A-Za-z0-9{(]|\bCl\(|\bM\d*\(|\bso\(|\bsu\(|\bSU\(|\bSO\(|\bU\(\d|\\[a-zA-Z]+|\bdet\b|\bTr\b|\bP[₀-₉]|\be[₀-₉]|\be\d{2,}\b|\[\s*\d+\s*,\s*[+−-]?\d+\s*\]|[²³ⁿ±½⅓¼¾ℏ]|\b[a-zA-Z]\s*=\s*[−+-]?[a-zA-Z0-9]|\b[b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]\s?[−±]\s?\d|\d\s?\/\s?\(/u;
const JARGON = /isomorph|idempotent|pseudoscalar|bivector|trivector|multivector|\bPeirce\b|\bWitt\b|involution|semisimple|eigen(value|vector)|Lagrangian|Hamiltonian|manifold|holonomy|cohomolog|automorphism|Casimir|Lie algebra|radical ideal|zero divisor|tensor|commutator|anticommut|orthoplex|demicube|polytope|\bincidence|Clifford algebra|matrix ring|\bPGA\b|metric signature|quadratic form|Killing|geodesic|Schwarzschild|Kerr\b|covariant|gauge|Hodge|spinor|pointor|rotor|versor|motor\b|forque|axiom|assiom|quaternion/i;
const X0 = /algebra|radical|radicale|Frobenius|Jordan|Nakayama|Loewy|Clifford|nilpot|matri[xc]|functor|funtor|Euler|\bTits\b|\bKac\b|Cartan|Dynkin|Majki|\bTian\b|Hilbert|\blabel 0\b(?!”)|etichetta 0(?!”)|signature|segnatura|\bnull\b|\bnullo\b|\bcell\b|\bcella\b|\bE\d/i;
const ylStrings = [...strings(COPY.yl).map(([p, s]) => ['yl.' + p, s]), ...strings(MAP_TEXT.yl).map(([p, s]) => ['map.yl.' + p, s])];
for (const [p, s] of ylStrings) { const m1 = SYMBOLS.exec(s), m2 = JARGON.exec(s), m3 = X0.exec(s); ok(!m1 && !m2 && !m3, `${p}: the Young Learner reads no formula and no technical word (${(m1 || m2 || m3 || [''])[0]}): ${s.slice(0, 80)}`); }
ok(COPY.yl.en.title === 'The zero switch: the one switch with no way back' && COPY.yl.en.sentence === 'A plus or minus switch squared gives 1 back, a zero switch squared gives nothing; your browser recomputes this, a script checks it, and what it means in nature we do not claim.', 'the Young Learner\'s title and first sentence are the decided ones (DECISIONS §1)');
for (const l of ['en', 'it']) ok(['checked', 'standard', 'ours', 'open'].every(k => COPY.yl[l].honest.pts.some(x => x.k.split(' ').includes(k))), `${l}: the plain honest list carries the four statuses`);
// X1: label 0 is defined at first use in every voice, and the empty label is the unit
for (const l of ['en', 'it']) { const f = COPY[l].first, def = l === 'en' ? /^Label 0 is a generator with square 0[^.]*; the empty label is the unit\./ : /^L’etichetta 0 è un generatore di quadrato 0[^.]*; l’etichetta vuota è l’unità\./;
  ok(def.test(f.ledeP) && def.test(f.ledeM), `${l}: the Physicist's and the Mathematician's first sentence define label 0 and the empty label`);
  ok((l === 'en' ? /“label 0”/ : /“etichetta 0”/).test(COPY.yl[l].define) && (l === 'en' ? /the number 1/ : /il numero 1/).test(COPY.yl[l].define), `${l}: the Young Learner reads what "label 0" is and that the empty corner is the number 1`); }

// ---- 6. the numbers the text quotes are the stored ones (cat_check.py, cat_results.json) and the matrix data
const R = JSON.parse(rd('selfcheck/reports/cat_results.json'));
ok(R.nok === 52 && R.nbad === 0 && /^52 exact checks/.test(COPY.en.script.note) && /^52 verifiche esatte/.test(COPY.it.script.note), 'the script box says 52 checks, as cat_results.json stores (52 ok, 0 failed)');
const euler = [0, 1, 2, 3, 4, 5].map(n => '(' + R.res.E[n].join(',') + ')');
ok(COPY.en.more.items.find(x => x.id === 'N7').text.includes(euler.join(', ')) && COPY.it.more.items.find(x => x.id === 'N7').text.includes(euler.join(', ')), 'N7 quotes the Euler signatures n = 0…5 that cat·E1 stores: ' + euler.join(' '));
for (const l of ['en', 'it']) ok(COPY[l].bottom.rows.every((r, n) => r[2] === euler[n]) && COPY[l].bottom.pts[0].t.includes('(' + R.res.E[5].join(',') + ')'), `${l}: the bottom-up table quotes the stored Euler signatures`);
const sigE = n => '(' + R.sig_E[n].join(',') + ')';
ok(sigE(8) === '(8,0,0)' && sigE(9) === '(8,0,1)' && sigE(10) === '(9,1,0)' && sigE(11) === '(10,1,0)', 'cat·Q2 stores E8 (8,0,0), E9 (8,0,1), E10 (9,1,0), E11 (10,1,0)');
for (const l of ['en', 'it']) ok(COPY[l].persp.items[3].pts[0].t.includes(`${sigE(9)}, ${sigE(10)}, ${sigE(11)}`), `${l}: P4 quotes the stored signatures of E9, E10, E11`);
const q1 = [3, 4, 5, 6, 7, 8].map(n => R.res.LAD[n].q1);
for (const l of ['en', 'it']) ok(COPY[l].top.pts[3].t.includes(q1.join(', ')), `${l}: the mod-2 counts ${q1.join(', ')} are the ones cat·Q5 stores`);
ok(R.marks.reduce((a, b) => a + b, 0) === 30 && [3, 2, 4, 6, 5, 4, 3, 2, 1].reduce((a, b) => a + b, 0) === 30, 'the marks of the null root of E9 sum to 30 (cat·Q1 stores its own order of the marks)');
const r301 = R.res.R['3,0,1'];
ok(r301.rad === 8 && r301.layers.join() === '8' && r301.sc === 2, 'Cl(3,0,1): radical 8, one layer (Loewy length 2), super-centre 2, as cat·R1–R3 store');
for (const l of ['en', 'it']) ok(/8, \D+ 2, \D+ 2/.test(COPY[l].bottom.rows[4][4]), `${l}: the bottom-up row n = 4 quotes them`);
const r002 = R.res.R['0,0,2'];
ok(r002.rad === 3 && COPY.en.twozeros.pts[0].t.includes('radical of dimension 3') && COPY.it.twozeros.pts[0].t.includes('radicale di dimensione 3'), 'two unpaired nulls: radical of dimension 3 (cat·R1 stores it for Cl(0,0,2))');
// every signature with up to five generators is stored (56), as the range line says
ok(Object.keys(R.res.R).length === 56 && /56 signatures/.test(COPY.en.label0.pts[9].t) && /56 segnature/.test(COPY.it.label0.pts[9].t), 'the range line: 56 signatures with up to five generators, as stored');
// the honesty bar counts and the matrix size come from the data: 40 category rows, best grades 27 / 6 / 2 / 5 (matrix row W5, the clock cell, is S)
{ const c = { E: 0, S: 0, A: 0, none: 0 }, rows = MATRIX_ROWS.filter(r => r.src === 'category');
  for (const r of rows) { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : 'none']++; }
  ok(rows.length === 40 && c.E === 27 && c.S === 6 && c.A === 2 && c.none === 5, `the category rows of the matrix: 40, best grades 27 / 6 / 2 / 5 (${rows.length}: ${JSON.stringify(c)})`);
  ok(!/27 of 40|27 su 40/.test(everyText), 'no headline "27 of 40 exact" (E is one identity, pointwise, in one chart)'); }

// ---- 7. the mirror is the script; the regeneration script exists and names both files
ok(CAT_CHECK_PY === CAT, 'categorySelfcheckSource.js holds selfcheck/reports/cat_check.py byte for byte (run sh selfcheck/regen_lens_category.sh after a change)');
{ const sh = rd('selfcheck/regen_lens_category.sh'); ok(/cat_check\.py/.test(sh) && /categorySelfcheckSource\.js/.test(sh) && /^set -e$/m.test(sh), 'selfcheck/regen_lens_category.sh rebuilds the mirror and stops at the first error'); }
ok(/^export const CAT_CHECK_PY = ".*";$/s.test(rd('categorySelfcheckSource.js').trim()) && rd('categorySelfcheckSource.js').trim().split('\n').length === 1, 'the mirror module is one export on one line (the shape test_license.mjs reads)');

// ---- 8. the Map: nodes, anchors, scripts, lenses, threads, texts; the persona
ok(MAP_NODES[0].id === 'category' && MAP_NODES[0].go.join() === 'lenses,ln-category', 'the chapter node comes first and opens the tab');
ok(['cat-label0', 'cat-frobenius', 'cat-moves', 'cat-top'].every(a => MAP_NODES.some(n => n.go[1] === a)) && MAP_NODES.length === 5, 'one leaf for each page the user asked for: the label-0 card, the complement mask, the four moves, the top of the ladder');
for (const n of MAP_NODES) {
  ok(SECTION.includes(`id="${n.go[1]}"`), `${n.id}: the anchor ${n.go[1]} is an id="..." of CategorySection.jsx`);
  ok(n.script.split(', ').every(s => fs.existsSync('selfcheck/' + s)), `${n.id}: every script it names exists (${n.script})`);
  ok(n.lens.every(x => LENSES.includes(x)) && n.th.every(x => MTHREADS.includes(x)) && n.tags.length && n.tags.every(t => FOUR.includes(t)), `${n.id}: lenses, threads and tags are the Map's own`);
  for (const l of ['en', 'it']) ok(MAP_TEXT[l][n.id]?.[0] && MAP_TEXT[l][n.id][1].length > 20 && MAP_TEXT.yl[l][n.id]?.[0] && MAP_TEXT.yl[l][n.id][1].length > 20, `${n.id} ${l}: a title and a text in both voices`);
}
for (const [p, s] of strings(MAP_TEXT)) for (const sen of sentences(s)) if (/\b(wall|muro)\b/i.test(sen)) ok(/\b(never|mai)\b[^.;]*\b(wall|muro)\b/i.test(sen), `${p}: period 8 is never a wall (hard rule 5): ${sen}`);
ok(PERSONA.length > 400 && PERSONA.length <= 1800, `the persona paragraph has ${PERSONA.length} characters (at most 1 800)`);
ok(/Checked/.test(PERSONA) && /Ours/.test(PERSONA) && /Open/.test(PERSONA) && /standard/.test(PERSONA) && /cat_check\.py/.test(PERSONA), 'the persona tags its facts (checked, standard, ours, open) and names the script');
// every section anchor the menu scrolls to is in the section, in both voices
for (const id of ['cat-first', 'cat-zero', 'cat-defs', 'cat-label0', 'cat-twozeros', 'cat-frobenius', 'cat-moves', 'cat-top', 'cat-bottom', 'cat-arrows', 'cat-more', 'cat-papers', 'cat-deadends', 'cat-refine', 'cat-persp', 'cat-questions', 'cat-honest', 'cat-bar', 'cat-script', 'cat-older', 'cat-w-label0', 'cat-w-twozeros', 'cat-w-frobenius', 'cat-w-moves', 'cat-w-top', 'cat-w-script', 'cat-cube', 'cat-w-cube'])
  ok(SECTION.includes(`id="${id}"`), `CategorySection.jsx has the anchor ${id}`);
ok(!/cat-corrections|cat-corr\b|<del>/.test(SECTION), 'CategorySection.jsx has no corrections section and draws no struck-through sentence');
ok(SECTION.includes('id="ln-category"') && (SECTION.match(/<section className="ln" id="ln-category"/g) || []).length === 2, 'the root is <section className="ln" id="ln-category"> in both branches (plain and formal)');
ok(['CW1', 'CW2', 'CW3', 'CW4', 'CW5', 'CW6', 'CategoryWidgetsScript'].every(w => new RegExp(`\\b${w}\\b`).test(SECTION)), 'the section places the five widgets, the optional sixth and the widgets\' script box');

// ---- 9. the claims rows of the chapter resolve, in English and Italian, with the four flags and the known-ground rule
// scope (verifier ver_cat, after the merge): claimsData.js now also holds the widget rows LNC-101…136 (claimsLocators_lncw.json). The row count and the
// namespaced form of checkedBy are about the A rows LNC-001…099 of claimsLocators_lnc.json (the widget rows write checkedBy in the B form 'cat_check.py M2 (ran)');
// every other check below still runs on every LNC row
// the A rows are the rows of claimsLocators_lnc.json: LNC-001 to LNC-100, then LNC-137 on, after the widget rows LNC-101 to LNC-136 of claimsLocators_lncw.json
const LOC = JSON.parse(rd('claimsLocators_lnc.json')), LOCW = JSON.parse(rd('claimsLocators_lncw.json')), aIds = new Set(LOC.map(r => r.id)), claimsAll = (await buildClaims()).filter(c => c.group === 'LNC'), isA = c => aIds.has(c.id), claims = claimsAll.filter(isA);
ok(LOC.length === claims.length && LOC.length === 109 && claimsAll.length === LOC.length + LOCW.length, `claimsLocators_lnc.json: ${LOC.length} rows, every one in the claims table, and the widget rows of claimsLocators_lncw.json besides`);
ok(LOC.every((r, i) => r.id === 'LNC-' + String(i < 100 ? i + 1 : i + 37).padStart(3, '0') && r.groupName === 'Category lens (step 18)' && r.shown_on.page === 'lenses' && r.shown_on.tab === 'category') && LOCW.every((r, i) => r.id === 'LNC-' + String(i + 101)) && LOCW.length === 36, 'rows LNC-001…100 and LNC-137… in order (the widget rows are LNC-101…136), group name, page lenses, tab category');
for (const r of LOC) ok(SECTION.includes(`id="${r.shown_on.anchor}"`) || /^cat-p[1-6]$/.test(r.shown_on.anchor), `${r.id}: its anchor ${r.shown_on.anchor} is in the section`);
for (const c of claimsAll) {
  ok(c.en.length >= 1 && c.it && c.it.length === c.en.length, `${c.id}: English and Italian lines`);
  ok(c.flags.join() === c.flagsSpec.join(), `${c.id}: the flags of its lines are the row's flags`);
  ok(c.en.every(l => ['line', 'theorem', 'reading'].includes(l.label)) && c.known === (c.flags.includes('standard') && c.flags.includes('checked') && !c.flags.includes('ours') && !c.flags.includes('open')), `${c.id}: line labels the page for researchers knows, and its known ground read from the row's flags agrees with its lines' (a plain twin carries the tags of its formal line)`);
  ok(c.known === (c.en.every(x => x.flags.includes('standard') && x.flags.includes('checked') && !x.flags.includes('ours') && !x.flags.includes('open'))), `${c.id}: known ground is standard and checked, neither ours nor open`);
  if (isA(c)) for (const id of String(c.checkedBy).split(/,\s*/).filter(x => x && x !== '—')) ok(/^(cat|bridge|catw)·[A-Z]\d+[a-z]?$|^Thm T\d+$|^bd·[a-z]+·\d+$|^selfcheck\/bridges\/[a-z]+_[A-Za-z0-9_]+\.py$/.test(id), `${c.id}: checkedBy names a namespaced check or a script of selfcheck/bridges/ (${id})`);
  // a bridge check in checkedBy comes after the script of its family that holds it (selfcheck/bridges/<family>_*.py), as EDIT_COMMON writes it
  { const toks = String(c.checkedBy).split(/[,;]\s*/); let fam = null; for (const t of toks) { const m = /^selfcheck\/bridges\/([a-z]+)_/.exec(t) || /\bselfcheck\/bridges\/([a-z]+)_/.exec(t); if (m) fam = m[1]; const b = /^bd·([a-z]+)·\d+$/.exec(t.trim()); if (b) ok(fam === b[1], `${c.id}: ${t.trim()} follows the script of its family in checkedBy (${c.checkedBy.slice(0, 80)})`); } }
  if (c.flags.includes('checked')) ok(c.checkedBy !== '—', `${c.id}: a checked statement names its checks`);
}
ok(claims.some(c => c.en.some(x => x.audience?.includes('Young Learner'))) && claims.filter(c => c.visibleTo.includes('Young Learner')).length >= 20, 'the Young Learner\'s plain lines are in the claims rows (as the plain twin of a formal line)');
{ const plainUsed = new Set(LOC.flatMap(r => r.lines.filter(l => (l.audience || []).includes('Young Learner')).map(l => l.en.text_loc.path.join('.'))));
  const plainAll = strings(COPY.yl.en).filter(([p]) => /\.t$/.test(p) && /pts/.test(p)).map(([p]) => 'COPY.yl.en.' + p);
  ok(plainAll.every(p => plainUsed.has(p)), 'every tagged plain line has its claims row: ' + plainAll.filter(p => !plainUsed.has(p)).join(', ')); }

// ---- 10. licence header on every file of the chapter, no e-mail address anywhere in them
const OWN = ['CategorySection.jsx', 'CategoryWidgets.jsx', 'categoryCopy.js', 'categoryIntegration.js', 'categorySelfcheckSource.js', 'selfcheck/regen_lens_category.sh', 'claimsLocators_lnc.json', 'test_lens_category.mjs', 'test_lens_category_ui.mjs'];
const MAIL = new RegExp('[\\w.+-]+' + '@' + '[\\w-]+\\.[A-Za-z]{2,}|mail' + 'to:', 'i');   // built from pieces, so that this file holds no address pattern itself
const SPDX = 'SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', NOTICE = 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors';
for (const f of OWN) { ok(fs.existsSync(f), `${f} is in the package`); if (!fs.existsSync(f)) continue; const t = rd(f);
  if (!/\.json$/.test(f)) ok(t.split('\n').slice(0, 6).join('\n').includes(SPDX) && t.includes(NOTICE), `${f}: the three-line licence header`);
  ok(!MAIL.test(t), `${f}: no e-mail address`); }
console.log(`${checks} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL CATEGORY CHAPTER TESTS PASS'); process.exit(bad ? 1 : 0);
