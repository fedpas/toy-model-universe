// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useState } from 'react';
import E from './equationsData.js';
import { EQ_PY, DIRAC_PY } from './equationsSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY from './equationsCopy.js';
import CouplingSection from './CouplingSection.jsx';
import YangMillsSection from './YangMillsSection.jsx';
import MatterSection from './MatterSection.jsx';
import { Fold, Intro, level } from './Fold.jsx';
import { GravityOneSection, GravityTwoSection } from './GravitySection.jsx';
import MirrorsSection from './MirrorsSection.jsx';
import ProjectiveSection from './ProjectiveSection.jsx';
import { stepEyebrow, navLabel, eqNavIds } from './steps.js';
import ForqueSection from './ForqueSection.jsx';
import SpinSection from './SpinSection.jsx';
import SpringSection from './SpringSection.jsx';
import RigidSection from './RigidSection.jsx';
import NullSection from './NullSection.jsx';
import TallySection from './TallySection.jsx';   // the tally: table, plain list for the Young Learner, downloads
// steps 2 and 4 import Formal under their own names, so that another block of this file may import it too without a clash
import { Formal as FormalY, isLearner as learnerY } from './Formal.jsx';
import { stepAudience } from './steps.js';
import { picYL } from './audienceCopy.js';
const YLPIC = () => stepAudience() === 'Young Learner';   // T4-11: plain picture labels for the Young Learner (audienceCopy.js PIC_YL)
import { Tx } from './MathText.jsx';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';
import { Tags } from './StatusBadge.jsx';
import { GaugeTab, LABELS_STYLE } from './LabelsTabs.jsx';   // gauge gravity: one of the three steps of the labels, drawn by LabelsTabs.jsx

// "More equations": step 2 the commutators of bivectors, step 4 the Dirac equation in the even subalgebra, step 6 coupling, step 7 Yang–Mills, step 8 charged matter, then the tally.
// Every number comes from selfcheck/equations_selfcheck.py (standard library) and selfcheck/dirac_matrix_check.py (numpy), and is rebuilt by test_equations.mjs.
const pc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
const AX = ['t', 'x', 'y', 'z'];
const nm = m => AX.filter((_, i) => m >> i & 1).join('') || '1';
const RC = { E: '#fbbf24', B: '#60a5fa', T: '#c084fc' };
const KC = { dt: '#fbbf24', dx: '#34d399', dy: '#60a5fa', dz: '#c084fc' };
const STYLE = `/* keyboard focus on the pictures that react to a click (vertices, generators, blades, edges) and on clickable table rows */
.eq-svg [role=button]{outline:none}.eq-svg [role=button]:focus-visible circle{stroke:#4aa8ff;stroke-width:3}.eq-svg .gv-edge-hit:focus-visible{stroke:rgba(74,168,255,.55)}.eq tr[tabindex]{outline:none}.eq tr[tabindex]:focus-visible{outline:2px solid #4aa8ff;outline-offset:-2px}
.eq{max-width:1000px;margin:28px auto;padding:0 16px}.eq h3{margin:1.2em 0 .4em}.eq-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:12px 14px;margin:10px 0}
.eq table{border-collapse:collapse;width:100%;min-width:520px;font-size:.85em}.eq th,.eq td{text-align:left;padding:3px 8px;border-bottom:1px solid rgba(128,128,128,.25)}.eq tr.on td{background:rgba(80,170,255,.14)}
.eq-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.eq-chip{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.eq-chip.on{background:rgba(80,170,255,.22);border-color:#4aa8ff}
.eq-status{list-style:none;margin:0;padding:0}.eq-status li{margin:2px 0}.eq-cap{font-size:.82em;opacity:.8}.eq-mono{font-family:ui-monospace,monospace}.eq-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:6px 12px;color:inherit;cursor:pointer;font:inherit;margin:4px 8px 4px 0}
.eq-pt{display:flex;gap:10px;margin:8px 0}.eq-pt p{margin:0}.eq-svg{width:100%;max-width:520px;display:block;margin:6px auto}.eq-xr{border-left:3px solid rgba(128,128,128,.5);padding:2px 0 2px 12px;margin:14px 0}.eq-fold{margin:12px 0}.eq-fold>summary{cursor:pointer;font-weight:600;font-size:1.1em;padding:6px 0}.eq-fold-in{margin:8px 0 0}.eq-fold-in>summary{font-size:1em}.eq-short{font-size:1.05em}.eq-nav{display:flex;gap:10px;flex-wrap:wrap;max-width:1000px;margin:10px auto 0;padding:0 16px}.eq-nav a{color:inherit;border:1px solid rgba(128,128,128,.4);border-radius:8px;padding:4px 12px;text-decoration:none;font-size:.9em}`;
function download(name, text, type) { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } }

const Chips = ({ items, value, onPick }) => <div className="eq-chips" role="group">{items.map(i => <button key={i} className={'eq-chip' + (i === value ? ' on' : '')} aria-pressed={i === value} onClick={() => onPick(i)}><Tx>{i}</Tx></button>)}</div>;

// ---- the 6 bivectors of 4 generators as an octahedron: complementary pairs opposite, joined unless complementary
const OCT = [[3, 90], [5, 150], [6, 210], [12, 270], [10, 330], [9, 30]];
function Octa({ p, y, lang = 'en' }) {
  const role = m => { const t = pc(m & ((1 << p) - 1)); return t === 1 ? 'E' : t === 0 ? 'B' : 'T'; };
  const pos = Object.fromEntries(OCT.map(([m, a]) => [m, [150 + 105 * Math.cos(a * Math.PI / 180), 150 - 105 * Math.sin(a * Math.PI / 180), a]]));
  const edges = []; for (let i = 0; i < 6; i++) for (let j = i + 1; j < 6; j++) { const a = OCT[i][0], b = OCT[j][0]; if (pc(a & b) === 1) edges.push([a, b, role(a ^ b)]); }
  return <svg className="eq-svg" viewBox="0 0 300 300" role="img" aria-label={YLPIC() ? picYL(lang).comm : 'The six bivectors of four generators and their commutators'}>
    {edges.map(([a, b, r]) => <line key={a + '-' + b} x1={pos[a][0]} y1={pos[a][1]} x2={pos[b][0]} y2={pos[b][1]} stroke={RC[r]} strokeWidth="1.3" opacity=".75"><title>{y ? y.edge(nm(a), nm(b), nm(a ^ b)) : `[${nm(a)}, ${nm(b)}] = ±2 ${nm(a ^ b)}`}</title></line>)}
    {OCT.map(([m, a]) => <g key={m}><circle cx={pos[m][0]} cy={pos[m][1]} r="7" fill={RC[role(m)]} /><text x={150 + 132 * Math.cos(a * Math.PI / 180)} y={150 - 132 * Math.sin(a * Math.PI / 180) + 4} textAnchor="middle" fontSize="12" fill="currentColor">{nm(m)}</text></g>)}</svg>;
}

// ---- the Dirac incidences: 8 even blades on the left, 8 odd blades (the equations) on the right
function DiracPic({ t, lang = 'en' }) {
  const [hot, setHot] = useState(null), D = E.eq.dirac, L = D.even_blades.map(b => b.mask), R = D.odd_blades.map(b => b.mask).sort((x, y) => pc(x) - pc(y) || x - y), rh = 34, H = 8 * rh + 24, X0 = 105, X1 = 335;
  const yl = new Map(L.map((m, i) => [m, 18 + rh * (i + .5)])), yr = new Map(R.map((m, i) => [m, 18 + rh * (i + .5)]));
  const used = hot == null ? [] : D.incidences.filter(e => e.to === hot);
  return <div style={{ overflowX: 'auto' }}><svg className="eq-svg" style={{ maxWidth: 560, minWidth: 440 }} viewBox={`0 0 440 ${H}`} role="group" aria-label={YLPIC() ? picYL(lang).dirac : 'Incidences of the Dirac equation between even and odd blades'}>
    {D.incidences.map((e, j) => { const on = hot == null || e.to === hot, mass = e.kind === 'm'; return <line key={j} x1={X0} y1={yl.get(e.from)} x2={X1} y2={yr.get(e.to)} stroke={mass ? 'currentColor' : KC[e.kind]} strokeDasharray={mass ? '4 3' : undefined} strokeWidth={on && hot != null ? 1.8 : mass ? 1.1 : .8} opacity={hot == null ? (mass ? .55 : .42) : on ? .95 : .05}>{!YLPIC() && <title>{`${t.kinds[e.kind]}: ${nm(e.from)} → ${nm(e.to)} (${t.sign} ${e.sign > 0 ? '+' : '−'})`}</title>}</line>; })}
    {L.map(m => <g key={m}><circle cx={X0} cy={yl.get(m)} r="5" fill={pc(m) === 2 ? '#34d399' : '#fbbf24'} /><text x={X0 - 10} y={yl.get(m) + 4} textAnchor="end" fontSize="12" fill="currentColor">{nm(m)}</text></g>)}
    {R.map(m => <g key={m} className="eq-hot" style={{ cursor: 'pointer' }} onClick={() => setHot(hot === m ? null : m)} role="button" tabIndex={0} aria-pressed={hot === m} aria-label={nm(m)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setHot(hot === m ? null : m); } }}><circle cx={X1} cy={yr.get(m)} r="5" fill={pc(m) === 1 ? '#8b93a7' : 'none'} stroke="#8b93a7" strokeWidth="1.3" /><text x={X1 + 10} y={yr.get(m) + 4} fontSize="12" fill="currentColor" fontWeight={hot === m ? 700 : 400}>{nm(m)}</text></g>)}
  </svg>{hot != null && <p className="eq-cap"><Tx>{nm(hot)}</Tx>: <Tx>{t.terms(used.length)}</Tx> — <Tx>{used.map(e => t.kinds[e.kind]).join(', ')}</Tx></p>}</div>;
}

// ---- steps 2 and 4 as tabs. The Young Learner reads plain captions (t.c.yl, t.d.yl) beside the same pictures; the tables and the formal notes
// move into the closed "For older readers" fold. The Physicist and the Mathematician see exactly what they saw before.
const Pts = ({ items, lang }) => <div>{items.map(([ks, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={ks} lang={lang} /></div><p><Tx>{txt}</Tx></p></div>)}</div>;
function CommTab({ l, t, profile, lv, p, setP }) {
  const C = E.eq.commutators, yl = learnerY(profile), y = t.c.yl, c = yl ? y : t.c, roleRows = Object.entries(C.roles[`${p},${4 - p}`] || {});
  const table = <Fold title={t.c.tableH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table><thead><tr>{t.c.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
    {Object.entries(C.by_n).map(([n, r]) => <tr key={n} className={n === '4' ? 'on' : ''}><td><Tx>{n}</Tx></td><td><Tx>{r.bivectors}</Tx></td><td><Tx>{r.edges}</Tx></td><td><Tx>{r.commuting_pairs}</Tx></td><td><Tx>{r.triangles}</Tx></td></tr>)}</tbody></table><p className="eq-cap"><Tags kinds={['checked']} lang={l} /> <Tx>{t.c.note}</Tx></p></div></Fold>;
  const roles = <><h4><Tx>{t.c.roleH}</Tx></h4><div style={{ overflowX: 'auto' }}><table><thead><tr>{t.c.roleCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{roleRows.map(([k, v]) => { const [pair, sh] = k.split(' via '); return <tr key={k}><td><Tx>{pair.replace('+', ' · ')}</Tx></td><td><Tx>{t.c.via[sh]}</Tx></td><td><Tx>{v.result}</Tx></td><td><Tx>{v.edges}</Tx></td></tr>; })}</tbody></table></div></>;
  const pts = <Pts items={t.c.points} lang={l} />;
  return <section className="eq" id="eq-comm" aria-labelledby="eq-c-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'comm', yl ? y.name : undefined)}</Tx></p><h2 id="eq-c-h"><Tx>{c.title}</Tx></h2><Intro lang={l} profile={profile} id="comm" lede={t.c.lede} />
    {!yl && table}
    <h3><Tx>{c.picH}</Tx></h3><div className="eq-card"><p className="eq-cap"><Tx>{c.pick}</Tx></p><Chips items={[0, 1, 2, 3, 4]} value={p} onPick={setP} /><Octa p={p} y={yl ? y : null} lang={l} /><p className="eq-cap"><Tx>{c.cap(p)}</Tx></p>
      <p className="eq-cap"><Tx>{c.legend}</Tx> {Object.entries(c.roles).map(([k, v]) => <span key={k} style={{ marginRight: 12 }}><span style={{ display: 'inline-block', width: 9, height: 9, borderRadius: 5, background: RC[k], marginRight: 4 }} /><Tx>{v}</Tx></span>)}</p>
      {!yl && roles}
      {p === 1 && <p><Tx>{c.lorentz}</Tx></p>}</div>
    {yl ? <><FormalY profile={profile} lang={l}>{table}{roles}{pts}</FormalY><Pts items={y.points} lang={l} /></> : pts}</section>;
}
function DiracTab({ l, t, profile, lv }) {
  const yl = learnerY(profile), y = t.d.yl, d = yl ? y : t.d;
  const xref = <Fold title={t.d.xrefH} open={lv >= 1}>
    {[['cube', ['checked', 'ours']], ['maxwell', ['checked']], ['comm', ['checked']], ['disp', ['checked']], ['mat', ['checked', 'standard']]].map(([k, ks]) => <div key={k} className="eq-xr"><h4><Tx>{t.d[k].h}</Tx> <Tags kinds={ks} lang={l} /></h4><p><Tx>{t.d[k].t}</Tx></p></div>)}</Fold>;
  return <section className="eq" id="eq-dirac" aria-labelledby="eq-d-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'dirac', yl ? y.name : undefined)}</Tx></p><h2 id="eq-d-h"><Tx>{d.title}</Tx></h2><Intro lang={l} profile={profile} id="dirac" lede={t.d.lede} />
    <div><Tags kinds={['checked']} lang={l} /> <span className="eq-cap"><Tx>{d.numbers}</Tx></span></div>
    <h3><Tx>{d.picH}</Tx></h3><div className="eq-card"><DiracPic t={d} lang={l} /><p className="eq-cap"><Tx>{d.cap}</Tx> {Object.entries(KC).map(([k, c]) => <span key={k} style={{ marginRight: 8, color: c }}><Tx>{d.kinds[k]}</Tx></span>)}</p></div>
    {yl ? <><FormalY profile={profile} lang={l}>{xref}</FormalY><Pts items={y.points} lang={l} /></> : xref}
    <p className="eq-cap"><Tags kinds={['open']} lang={l} /> <Tx>{d.limits}</Tx></p></section>;
}

export default function EquationsSection({ lang = 'en', profile = 'Young Learner', go }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l], C = E.eq.commutators, D = E.eq.dirac, M = E.matrix, [p, setP] = useState(1);
  const [sub, setSub] = useSub('equations');
  return <><style>{STYLE}</style><style>{LABELS_STYLE}</style><TabBar lang={l} page="equations" active={sub} onPick={setSub} /><TabPanel lang={l} page="equations" id={sub} onPick={setSub} goMap={go} ownGlance={sub === 'gauge'}>
    {sub === 'comm' && <CommTab l={l} t={t} profile={profile} lv={lv} p={p} setP={setP} />}
    {sub === 'mirrors' && <MirrorsSection lang={l} profile={profile} />}
    {sub === 'dirac' && <DiracTab l={l} t={t} profile={profile} lv={lv} />}
    {sub === 'spin' && <SpinSection lang={l} profile={profile} />}
    {sub === 'coupling' && <CouplingSection lang={l} profile={profile} />}
    {sub === 'ym' && <YangMillsSection lang={l} profile={profile} />}
    {sub === 'matter' && <MatterSection lang={l} profile={profile} />}
    {sub === 'grav1' && <GravityOneSection lang={l} profile={profile} />}
    {sub === 'grav2' && <GravityTwoSection lang={l} profile={profile} />}
    {sub === 'projective' && <ProjectiveSection lang={l} profile={profile} />}
    {sub === 'gauge' && <GaugeTab lang={l} profile={profile} go={go} />}
    {sub === 'nullsurf' && <NullSection lang={l} profile={profile} />}
    {sub === 'forque' && <ForqueSection lang={l} profile={profile} />}
    {sub === 'spring' && <SpringSection lang={l} profile={profile} />}
    {sub === 'rigid' && <RigidSection lang={l} profile={profile} />}
    {sub === 'tally' && <TallySection lang={l} profile={profile} />}</TabPanel></>;
}
