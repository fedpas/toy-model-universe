// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// What kind of content each cell of the matrix column "The rule" holds (matrix uid -> kind). The column mixes three kinds of content, and the grade (E, S, A) does not say which:
//   labels   the group (ℤ/2)ⁿ, subsets, counting, weights: no sign of the product is used; an E here means that the group law or the count agrees, not that the product agrees
//   product  the sign cocycle, the squares, the Koszul rule, forms (including readings that use the product)
//   module   the algebra acting on the labels as a representation or a Fock space
// The grades are not changed; the kind is an overlay kept here because the matrix itself is generated from the reports (reports/, hash-manifested). test_researchers.mjs pins that
// every one of the cells of the rule column is assigned exactly once.
export const RULE_KINDS = {
  L1: 'labels', L2: 'labels', L6: 'labels', 'K.6': 'labels', 'J.1': 'labels', 'J.4': 'labels', 'J.5': 'labels', 'J.10': 'labels', 'E.1': 'labels', 'E.2': 'labels', 'E.4': 'labels', 'E.6': 'labels', 'G.8': 'labels',
  L9: 'product', 'M1-schuller': 'product', M4: 'product', M5: 'product', 'G.1': 'product', 'D.1': 'product', 'D.2': 'product', 'D.3': 'product', 'K.1': 'product', 'K.2': 'product', 'C.1': 'product', 'C.2': 'product',
  K1: 'product', K2: 'product', K4: 'product', K8: 'product', K10: 'product', 'C1-cat': 'product', 'C2-cat': 'product', 'C3-cat': 'product', 'C4-cat': 'product', 'C6-cat': 'product', T1: 'product', T3: 'product', W3: 'product', 'M2-cat': 'product',
  'K.5': 'module', K7: 'module', T2: 'module', 'J.2': 'module',
};
export const RULE_KIND_LIST = ['labels', 'product', 'module'];
export const RULE_COL_LONG = 'The rule: bit labels, XOR, signs (labels · product · module)';
