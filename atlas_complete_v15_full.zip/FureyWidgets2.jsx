// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Tx, SvgTx } from './MathText.jsx';
import { isLearner } from './Formal.jsx';
import { Fold } from './Fold.jsx';
import { fc, checkText } from './fureyCopy.js';
import D from './fureyPapersData.js';
import T256 from './threegenData.js';
import * as E from './fureyPapersEngine.js';
import { BLOCK_COLORS } from './findingsData.js';
import { Chips, Sc, INK, nf, six } from './FureyWidgets.jsx';
import { download } from './LensKit.jsx';

// The widgets of the Furey page that belong to "Three generations" and "What may help": the board of Fig. 1, the ledger of complete sets, the products of irreps,
// the room needed for complete sets, the split of the 128 complex dimensions, the scoreboard of the 30 checks and the table of the 20 cells with its downloads.
// Same rules as FureyWidgets.jsx: numbers from fureyPapersData.js / fureyPapersEngine.js (exact integers), plain labels for the Young Learner.
const key = onAct => ({ role: 'button', tabIndex: 0, onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onAct(); } } });
const tn = t => t.replace('nu_', 'ν_');
const joinC = (list, f) => list.map((x, i) => <span key={i}>{i ? ', ' : ''}{f(x)}</span>);

// ================================================================================================================================ the board of Fig. 1
export function Board({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), T = C.threegen, w = yl ? T.ylw.board : T.w.board, [doubled, setDoubled] = React.useState(false), [view, setView] = React.useState('type'), [sel, setSel] = React.useState([1, 2]);
  const CW = 100, CH = 62, X0 = 46, Y0 = 34, N = 5;
  const first = lb => E.FIG1[lb];
  const ylName = (r, c) => { const lb = first(r + ',' + c)[0], base = lb.replace(/\+$/, ''), ex = T.extraShort[base], nm = ex || T.typeShort[E.typeOfCell(r, c)]; return lb.endsWith('+') ? [T.anti + ' ' + nm[0], nm[1]] : nm; };
  const [sr, sc] = sel, sdiag = sr === sc, counts = E.cellsByType(), x = sdiag ? null : E.cell(sr, sc);
  const tally = E.TYPES.map(t => [t, counts[t] * (doubled ? 2 : 1)]);
  const fillOf = (r, c) => { const t = E.typeOfCell(r, c); return view === 'type' ? E.TYPE_COLOUR[t] : (E.isFirstSetCell(r, c) ? E.TYPE_COLOUR[t] : '#9aa3b8'); };
  const blk = i => (yl ? String(i + 1) : <SvgTx>{w.blocks[i]}</SvgTx>);
  return <div className="ln-card fw-w" data-fw="board"><h4><Tx>{w.h}</Tx></h4>
    <div className="fw-sel"><span className="ln-k"><Tx>{w.mode}</Tx></span><Chips label={w.mode} value={doubled ? 'd' : 'o'} onPick={v => setDoubled(v === 'd')} items={[['o', w.onshell], ['d', w.doubled]]} />
      <span className="ln-k"><Tx>{w.view}</Tx></span><Chips label={w.view} value={view} onPick={setView} items={[['type', w.byType], ['first', w.byFirst]]} /></div>
    <svg className="fw-svg" viewBox={`0 0 ${X0 + N * CW + 6} ${Y0 + N * CH + 6}`} role="img" aria-label={yl ? 'A board of five by five boxes; each box is coloured by the kind of particle it holds' : 'Fig. 1: the 5 × 5 board of cells, coloured by Standard Model type'} data-doubled={doubled ? 1 : 0}>
      {[0, 1, 2, 3, 4].map(i => <g key={'h' + i}><text x={X0 + i * CW + CW / 2} y={Y0 - 10} textAnchor="middle" fontSize="11" fill="currentColor">{blk(i)}</text><text x={X0 - 8} y={Y0 + i * CH + CH / 2 + 4} textAnchor="end" fontSize="11" fill="currentColor">{blk(i)}</text></g>)}
      {[0, 1, 2, 3, 4].flatMap(r => [0, 1, 2, 3, 4].map(c => {
        const px = X0 + c * CW, py = Y0 + r * CH, on = r === sr && c === sc, partner = r === sc && c === sr && !sdiag;
        if (r === c) return <g key={r + ',' + c} data-pick={r + ',' + c} aria-label={yl ? w.gauge : 'gauge'} {...key(() => setSel([r, c]))} onClick={() => setSel([r, c])}><rect x={px + 2} y={py + 2} width={CW - 4} height={CH - 4} rx="6" fill="currentColor" fillOpacity=".1" stroke="currentColor" strokeOpacity={on ? 1 : 0.3} strokeWidth={on ? 3 : 1} /><text x={px + CW / 2} y={py + CH / 2 + 4} textAnchor="middle" fontSize="10" fill="currentColor" opacity=".7">{w.gauge}</text></g>;
        const lb = first(r + ',' + c), nm = yl ? ylName(r, c) : null;
        return <g key={r + ',' + c} data-pick={r + ',' + c} aria-label={yl ? `${w.row} ${r + 1} ${w.col} ${c + 1}: ${nm[0]} ${nm[1]}` : `${r + 1}→${c + 1}: ${spoken(E.labelText(lb[0]), lang)}`} {...key(() => setSel([r, c]))} onClick={() => setSel([r, c])}>
          <rect x={px + 2} y={py + 2} width={CW - 4} height={CH - 4} rx="6" fill={fillOf(r, c)} fillOpacity={view === 'first' && !E.isFirstSetCell(r, c) ? 0.35 : 0.88} stroke="currentColor" strokeOpacity={on || partner ? 1 : 0.25} strokeWidth={on ? 3 : partner ? 2 : 1} strokeDasharray={partner ? '5 3' : undefined} />
          {yl ? <><text x={px + CW / 2} y={py + CH / 2 - 2} textAnchor="middle" fontSize="10" fontWeight="600" fill={INK}>{nm[0]}</text><text x={px + CW / 2} y={py + CH / 2 + 11} textAnchor="middle" fontSize="9.5" fill={INK}>{nm[1]}</text>{doubled ? <g><circle cx={px + CW / 2 - 5} cy={py + CH - 9} r="3" fill={INK} /><circle cx={px + CW / 2 + 5} cy={py + CH - 9} r="3" fill={INK} /></g> : null}</>
            : <><text x={px + CW / 2} y={py + (doubled ? CH / 2 - 3 : CH / 2 + 4)} textAnchor="middle" fontSize="12" fontWeight="600" fill={INK}><Sc svg s={E.labelText(lb[0])} /></text>{doubled ? <text x={px + CW / 2} y={py + CH / 2 + 14} textAnchor="middle" fontSize="11" fill={INK}><Sc svg s={E.labelText(lb[1])} /></text> : null}</>}</g>;
      }))}
    </svg>
    <div className="fw-key">{tally.map(([t, n]) => <span key={t} data-type={t} data-n={n}><i style={{ background: E.TYPE_COLOUR[t] }} />{yl ? <Tx>{T.typeName[t]}</Tx> : <Sc s={tn(t)} />}: <b>{n}</b></span>)}</div>
    <p className="ln-cap" data-complete={E.completeSets(doubled)}><Tx>{w.cells}</Tx> · <Tx>{yl ? T.ylw.ledger.have : T.w.ledger.have}</Tx> <Tx>{yl ? T.ylw.ledger.ok : T.w.ledger.ok}</Tx>: <b>{E.completeSets(doubled)}</b> {yl ? <Tx>{T.ylw.room.sets}</Tx> : <Tx>{T.w.room.sets}</Tx>}</p>
    <div className="fw-detail" data-cell={sr + ',' + sc}>{sdiag ? <p><Tx>{w.gauge}</Tx> · {yl ? sr + 1 : <><Sc s={w.blocks[sr]} /> <code className="ln-mono">{D.fig1.diagonal[sr]}</code></>}</p>
      : yl ? <><p><b>{ylName(sr, sc)[0]} {ylName(sr, sc)[1]}</b> · <Tx>{w.row}</Tx> {sr + 1} <Tx>{w.col}</Tx> {sc + 1}</p><p><Tx>{w.partner}</Tx>: <Tx>{w.row}</Tx> {sc + 1} <Tx>{w.col}</Tx> {sr + 1}</p><p className={E.cellMatches(sr, sc) ? 'fw-ok' : 'fw-no'}>{E.cellMatches(sr, sc) ? '✓ ' : '✗ '}<Tx>{w.matches}</Tx></p></>
      : <><p><Tx>{w.row}</Tx> <b>{sr}</b> <Tx>{w.col}</Tx> <b>{sc}</b> · <Tx>{w.irrep}</Tx>: {E.fmtShow(x)}, {E.dimOf(x)}ℂ · <Tx>{w.type}</Tx>: <b><Sc s={tn(E.typeOfCell(sr, sc))} /></b></p>
        <p><Tx>{w.labels}</Tx>: {joinC(first(sr + ',' + sc), lb => <>{<Sc s={E.labelText(lb)} />} {E.fmtShow(E.labelIrrep(lb))}</>)}</p>
        <p><Tx>{w.charges}</Tx>: {joinC(E.cellCharges(sr, sc), q => <>{E.fmtQ(q.q)}{q.n > 1 ? ' ×' + q.n : ''}</>)} · <Tx>{w.partner}</Tx>: ({sc}, {sr})</p>
        <p className={E.cellMatches(sr, sc) ? 'fw-ok' : 'fw-no'}>{E.cellMatches(sr, sc) ? '✓ ' : '✗ '}<Tx>{w.matches}</Tx></p></>}</div></div>;
}

// ================================================================================================================================ the ledger of complete sets
export function Ledger({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), T = C.threegen, w = yl ? T.ylw.ledger : T.w.ledger, [k, setK] = React.useState(3), [doubled, setDoubled] = React.useState(true);
  const sets = E.setsByType(doubled), miss = E.missingFor(k, doubled), sur = E.surplus(doubled), surDim = E.TYPES.reduce((a, t) => a + E.SM_DIM[t] * sur[t], 0), U = 38, X0 = 225;
  const name = t => (yl ? <Tx>{T.typeName[t]}</Tx> : <Sc s={tn(t)} />);
  return <div className="ln-card fw-w" data-fw="ledger"><h4><Tx>{w.h}</Tx></h4>
    <div className="fw-sel"><span className="ln-k"><Tx>{w.want}</Tx></span><Chips label={w.want} value={k} onPick={setK} items={[[1, '1'], [2, '2'], [3, '3']]} />
      <span className="ln-k"><Tx>{w.mode}</Tx></span><Chips label={w.mode} value={doubled ? 'd' : 'o'} onPick={v => setDoubled(v === 'd')} items={[['o', w.onshell], ['d', w.doubled]]} /></div>
    <svg className="fw-svg" viewBox="0 0 600 250" role="img" aria-label={yl ? 'Six bars, one for each kind of piece: how many complete families it can fill, against the number wanted' : 'Complete sets of each Standard Model type against the number wanted'} data-k={k} data-doubled={doubled ? 1 : 0}>
      {E.TYPES.map((t, i) => { const y = 14 + i * 38, have = sets[t], short = Math.max(0, k - have);
        return <g key={t} data-type={t}><text x="4" y={y + 17} fontSize="10.5" fill="currentColor">{yl ? T.typeName[t] : <SvgTx>{tn(t)}</SvgTx>}</text>
          <rect x={X0} y={y} width={have * U} height="26" rx="4" fill={E.TYPE_COLOUR[t]} fillOpacity=".9" /><text x={X0 + 8} y={y + 18} fontSize="12" fontWeight="700" fill={INK}>{have}</text>
          {short > 0 ? <rect x={X0 + have * U} y={y} width={short * U} height="26" rx="4" fill="none" stroke="#f87171" strokeWidth="2" strokeDasharray="5 3" /> : null}</g>; })}
      <line x1={X0 + k * U} y1="6" x2={X0 + k * U} y2="240" stroke="currentColor" strokeDasharray="3 3" strokeOpacity=".8" /><text x={X0 + k * U + 4} y="12" fontSize="10" fill="currentColor">{w.need} {k}</text>
    </svg>
    <p className="fw-detail" data-missing={Object.keys(miss).join(',')}>{Object.keys(miss).length ? <><b><Tx>{w.missing}</Tx>:</b> {joinC(Object.entries(miss), ([t, n]) => <>{name(t)} {n}</>)}</> : <span className="fw-ok"><Tx>{w.nothing}</Tx></span>}</p>
    <p className="ln-cap"><Tx>{w.surplus}</Tx>: {joinC(Object.entries(sur).filter(([, n]) => n > 0), ([t, n]) => <>{name(t)} {n}</>)} · {surDim}{yl ? '' : 'ℂ'}</p></div>;
}

// ================================================================================================================================ products of irreps
export function Composites({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), T = C.threegen, w = yl ? T.ylw.comp : T.w.comp, [sel, setSel] = React.useState(0), [ia, setIa] = React.useState(0), [ib, setIb] = React.useState(1);
  const P = E.PRESETS, free = sel === 'free';
  const a = free ? E.CELL_IRREPS[ia] : P[sel].a, b = free ? E.CELL_IRREPS[ib] : P[sel].b, prod = E.product(a, b), target = free ? null : P[sel].target, found = target ? E.containsType(prod, target) : null;
  const colA = r => { const k = E.kindOf(r); return k ? E.TYPE_COLOUR[k.type] : '#9aa3b8'; };
  const nameIr = r => { const k = E.kindOf(r); return `${E.fmtShow(r)}${k ? ' = ' + tn(k.type) + (k.conj ? '†' : '') : ''}`; };
  return <div className="ln-card fw-w" data-fw="composites"><h4><Tx>{w.h}</Tx></h4>
    <Chips label={w.pick} value={sel} onPick={setSel} items={[...P.map((p, i) => [i, yl ? T.compYl[i][0] : <>{p.names.map((n, j) => <React.Fragment key={j}>{j ? ' ⊗ ' : ''}<Sc s={n} /></React.Fragment>)}</>]), ...(yl ? [] : [['free', w.free]])]} />
    {free && !yl ? <div className="fw-sel"><label><Tx>{w.a}</Tx> <select value={ia} onChange={e => setIa(+e.target.value)} data-sel="a">{E.CELL_IRREPS.map((r, i) => <option key={i} value={i}>{nameIr(r)}</option>)}</select></label>
      <label><Tx>{w.b}</Tx> <select value={ib} onChange={e => setIb(+e.target.value)} data-sel="b">{E.CELL_IRREPS.map((r, i) => <option key={i} value={i}>{nameIr(r)}</option>)}</select></label></div> : null}
    <svg className="fw-svg" viewBox="0 0 600 120" role="img" aria-label={yl ? 'Two pieces are multiplied and the result is a piece of the missing kind' : 'Two irreps of the cells, their tensor product, and the target'} data-found={found === null ? '' : found ? 1 : 0}>
      {yl ? <><rect x="20" y="20" width="200" height="60" rx="8" fill="#9aa3b8" fillOpacity=".7" /><text x="120" y="55" textAnchor="middle" fontSize="12" fill={INK}>{T.compYl[free ? 0 : sel][0]}</text>
        <path d="M 240 58 L 278 58 M 268 48 L 280 58 L 268 68" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        <rect x="300" y="20" width="270" height="60" rx="8" fill={E.TYPE_COLOUR[target]} fillOpacity=".9" /><text x="435" y="55" textAnchor="middle" fontSize="12" fill={INK}>{T.compYl[sel][1]}</text></>
        : <><rect x="10" y="20" width="120" height="50" rx="8" fill={colA(a)} fillOpacity=".85" /><text x="70" y="50" textAnchor="middle" fontSize="12" fill={INK}>{E.fmtShow(a)}</text>
          <text x="148" y="52" textAnchor="middle" fontSize="20" fill="currentColor">⊗</text>
          <rect x="166" y="20" width="120" height="50" rx="8" fill={colA(b)} fillOpacity=".85" /><text x="226" y="50" textAnchor="middle" fontSize="12" fill={INK}>{E.fmtShow(b)}</text>
          <text x="304" y="52" textAnchor="middle" fontSize="20" fill="currentColor">=</text>
          {prod.map((r, i) => <g key={i}><rect x={322 + i * 140} y="20" width="132" height="50" rx="8" fill={colA(r)} fillOpacity=".85" stroke={target && E.same(r, E.SM[target]) ? 'currentColor' : 'none'} strokeWidth="3" /><text x={388 + i * 140} y="50" textAnchor="middle" fontSize="12" fill={INK}>{E.fmtShow(r)}</text></g>)}</>}
    </svg>
    <p className={'fw-detail ' + (found ? 'fw-ok' : '')} data-target={target || ''}>{target ? <>{found ? '✓ ' : '✗ '}<Tx>{yl ? w.found : w.found}</Tx>{yl ? null : <>: <Sc s={tn(target)} /> {E.fmtShow(E.SM[target])}</>}</> : <>{prod.map((r, i) => <span key={i}>{i ? ' ⊕ ' : ''}{nameIr(r)}</span>)}</>}</p>
    <p className="ln-cap"><Tx>{w.note}</Tx></p></div>;
}

// ================================================================================================================================ room for complete sets
export function Room({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), T = C.threegen, w = yl ? T.ylw.room : T.w.room, [n, setN] = React.useState(8), R = D.room.by_dimension[String(n)];
  const hist = Object.entries(R.histogram_of_S).map(([s, c]) => [+s / 2, c]).sort((a, b) => a[0] - b[0]), maxc = Math.max(...hist.map(h => h[1])), best = R.max_S / 2, ex = R.example_with_max.map(E.parse), exDim = ex.reduce((a, r) => a + E.dimOf(r), 0);
  return <div className="ln-card fw-w" data-fw="room"><h4><Tx>{w.h}</Tx></h4>
    <label className="ln-sl"><span><Tx>{w.dim}</Tx></span><input type="range" min="8" max="14" value={n} aria-label={w.dim} onChange={e => setN(+e.target.value)} /><b>{n}</b></label>
    <svg className="fw-svg" viewBox="0 0 600 190" role="img" aria-label={yl ? 'Bars: how many layouts hold each number of complete families' : 'Histogram of the structures by the number of complete sets they hold'} data-n={n} data-best={best}>
      <line x1="30" y1="120" x2="580" y2="120" stroke="currentColor" strokeOpacity=".4" />
      {hist.map(([s, c], i) => { const h = 90 * Math.log10(c + 1) / Math.log10(maxc + 1), x = 70 + i * 100;
        return <g key={s}><rect x={x} y={120 - h} width="64" height={h} rx="4" fill={s === best ? '#4fd18b' : '#9aa3b8'} fillOpacity=".9" /><text x={x + 32} y={120 - h - 5} textAnchor="middle" fontSize="11" fill="currentColor">{nf(c)}</text><text x={x + 32} y="138" textAnchor="middle" fontSize="12" fontWeight="700" fill="currentColor">{s}</text></g>; })}
      <text x="305" y="160" textAnchor="middle" fontSize="10.5" fill="currentColor" opacity=".8">{w.sets}</text>
      <g transform="translate(40,168)">{ex.map((r, i) => { const wd = Math.max(26, 520 * E.dimOf(r) / exDim - 3), x0 = ex.slice(0, i).reduce((a, q) => a + Math.max(26, 520 * E.dimOf(q) / exDim), 0);
        return <rect key={i} x={x0} y="0" width={wd} height="14" rx="3" fill={BLOCK_COLORS[i % 5]} fillOpacity=".85" />; })}</g>
    </svg>
    <p className="ln-cap"><Tx>{w.structs}{yl ? '' : ''}</Tx>: <b>{nf(Object.values(R.histogram_of_S).reduce((a, b) => a + b, 0))}</b> · <Tx>{w.best}</Tx>: <b data-best-n={best}>{best}</b> · <Tx>{w.hers}</Tx>: <b>{D.room.her_frame.sets}</b> ({D.room.her_frame.dimension}) · <Tx>{w.first3}</Tx> <b>{D.room.first_dimension_with_three_sets}</b></p>
    {yl ? null : <p className="ln-cap"><Tx>{w.example}</Tx>: {joinC(ex, r => E.fmtShow(r))}</p>}</div>;
}

// ================================================================================================================================ the 128 complex dimensions
export function Whole({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), T = C.threegen, w = yl ? T.ylw.whole : T.w.whole;
  const parts = [T256.dimensions.diagonal_complex, T256.dimensions.linear_off_diagonal_complex, T256.dimensions.antilinear_complex - T256.exotic.antilinear, T256.exotic.antilinear], tot = parts.reduce((a, b) => a + b, 0), COL = ['#9aa3b8', '#4fd18b', '#61dff0', '#f87171'];
  let x = 0;
  return <div className="ln-card fw-w" data-fw="whole"><h4><Tx>{w.h}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 600 70" role="img" aria-label={yl ? 'One long bar split into four parts of the 128 places' : 'The 128 complex dimensions of End(V) split into four sectors'} data-parts={parts.join(',')}>
      {parts.map((n, i) => { const wd = n / tot * 592, x0 = x; x += wd; return <g key={i}><rect x={4 + x0} y="10" width={wd - 3} height="34" rx="5" fill={COL[i]} fillOpacity=".85" /><text x={4 + x0 + (wd - 3) / 2} y="32" textAnchor="middle" fontSize="13" fontWeight="700" fill={INK}>{n}</text></g>; })}
      <text x="4" y="64" fontSize="10" fill="currentColor" opacity=".7">0</text><text x="596" y="64" textAnchor="end" fontSize="10" fill="currentColor" opacity=".7">{tot} {yl ? '' : 'ℂ'}</text>
    </svg>
    <div className="fw-key">{w.parts.map((p, i) => <span key={i}><i style={{ background: COL[i] }} /><Tx>{p}</Tx> <b>{parts[i]}</b></span>)}</div></div>;
}

// a label for a screen reader: b_R† is read "b R dagger", no underscore
export const spoken = (t, lang) => t.replace(/_([A-Za-zμτ0-9′]+)/g, ' $1').replace(/†/g, lang === 'it' ? ' dago' : ' dagger');

// ================================================================================================================================ scoreboard of the 30 checks
export function Scoreboard({ lang, profile }) {
  const C = fc(lang), yl = isLearner(profile), w = yl ? C.help.ylw.score : C.help.w.score, ch = D.checks;
  const grp = id => (/^[AR]/.test(id) ? 0 : /^T/.test(id) ? 1 : /^F/.test(id) ? 2 : 3), n = [0, 0, 0, 0]; ch.forEach(([id]) => { n[grp(id)]++; });
  return <div className="ln-card fw-w" data-fw="score"><h4><Tx>{w.h}</Tx></h4>
    <svg className="fw-svg" viewBox="0 0 600 170" role="img" aria-label={yl ? 'Four bars: how many of the thirty checks belong to each group' : 'Number of the 30 checks in each group'} data-counts={n.join(',')}>
      {w.groups.map((g, i) => <g key={i}><text x="4" y={30 + i * 38} fontSize="11" fill="currentColor">{g}</text><rect x="210" y={14 + i * 38} width={n[i] * 21} height="24" rx="4" fill={BLOCK_COLORS[i]} fillOpacity=".9" /><text x={210 + n[i] * 21 + 8} y={31 + i * 38} fontSize="12" fontWeight="700" fill="currentColor">{n[i]}</text></g>)}
    </svg>
    <p className="ln-cap"><b>{ch.length}</b> <Tx>{w.of}</Tx></p>
    {yl ? null : <Fold title={C.help.w.score.list} open={false}><div className="ln-wrap"><table className="ln-tab" data-checks={ch.length}><tbody>{ch.map(([id, t]) => <tr key={id}><th scope="row"><code className="ln-id">{id}</code></th><td><code className="fw-chk">{checkText(lang, id, t)}</code></td></tr>)}</tbody></table></div></Fold>}</div>;
}

// ================================================================================================================================ the table of the 20 cells and the downloads
export const cellsCsv = () => {
  const q = v => (/[",\n]/.test(String(v)) ? '"' + String(v).replace(/"/g, '""') + '"' : String(v));
  return ['row,col,row_block,col_block,irrep,dim,charges,label_1,label_2'].concat(E.cellKeys().map(([r, c]) => {
    const x = E.cell(r, c), lb = E.FIG1[r + ',' + c], ch = E.cellCharges(r, c).map(z => E.fmtQ(z.q).replace('−', '-') + 'x' + z.n).join(' ');
    return [r, c, D.fig1.blocks[r].name, D.fig1.blocks[c].name, E.fmt(x), E.dimOf(x), ch, lb[0], lb[1]].map(q).join(',');
  })).join('\n') + '\n';
};
export function CellTable({ lang }) {
  const C = fc(lang), w = C.help.w.dl, cells = E.cellKeys();
  return <div className="ln-card fw-w" data-fw="cells"><h4><Tx>{w.head}</Tx></h4>
    <div className="ln-wrap"><table className="ln-tab" data-cells={cells.length}><thead><tr>{['from', 'to', 'irrep', 'dim', 'Q', 'labels'].map(h => <th key={h} scope="col">{lang === 'it' ? { from: 'da', to: 'a', irrep: 'irrep', dim: 'dim', Q: 'Q', labels: 'etichette' }[h] : h}</th>)}</tr></thead>
      <tbody>{cells.map(([r, c]) => { const x = E.cell(r, c), lb = E.FIG1[r + ',' + c];
        return <tr key={r + ',' + c} data-row={r + ',' + c}><td>{D.fig1.blocks[r].name}</td><td>{D.fig1.blocks[c].name}</td><td>{E.fmtShow(x)}</td><td>{E.dimOf(x)}</td><td>{joinC(E.cellCharges(r, c), z => <>{E.fmtQ(z.q)}{z.n > 1 ? '×' + z.n : ''}</>)}</td><td>{joinC(lb, l => <Sc s={E.labelText(l)} />)}</td></tr>; })}</tbody></table></div>
    <button type="button" className="ln-btn" data-download="furey_fig1_cells.csv" onClick={() => download('furey_fig1_cells.csv', cellsCsv(), 'text/csv')}>{w.csv}</button>
    <button type="button" className="ln-btn" data-download="furey_papers.json" onClick={() => download('furey_papers.json', JSON.stringify(D, null, 1), 'application/json')}>{w.json}</button></div>;
}
