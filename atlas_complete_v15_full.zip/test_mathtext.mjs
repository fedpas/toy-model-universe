// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { parseMath, visibleText } from './mathTextCore.js';
import { GRAVITY_CONV } from './conventionsCopy.js';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
// Unit tests of the typesetter rules (formulas inside sentences become sub/superscripts; file names and words stay as they are).
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };
const runs = s => parseMath(s).filter(n => n.k === 'run').map(n => n.raw);
const rest = s => parseMath(s).map(n => (n.k === 'text' ? n.s : '\u0000')).join('');
ok(JSON.stringify(runs('D^μF_{μν} = J_ν')) === JSON.stringify(['D^μF_{μν} = J_ν']), 'the Maxwell equation is one formula');
{ const r = parseMath('D^μF_{μν} = J_ν')[0].parts; ok(r.length === 4 && r[0].base === 'D' && r[0].sup === 'μ' && r[0].sub === '' && r[1].base === 'F' && r[1].sub === 'μν' && r[3].base === 'J' && r[3].sub === 'ν', 'D^μ F_{μν} = J_ν reads D (up μ) F (down μν) = J (down ν)'); }
ok(JSON.stringify(runs('in D^μF_{μν} = κj_ν. There is')) === JSON.stringify(['D^μF_{μν} = κj_ν']) && rest('in D^μF_{μν} = κj_ν. There is') === 'in \u0000. There is', 'sentence text and the full stop stay outside');
ok(runs('gravity_selfcheck.py').length === 0 && runs('snake_case_name').length === 0 && runs('pgadyn_selfcheck.py and matrix_check.py').length === 0, 'file names and snake_case words are not formulas');
ok(runs('x_maxima and my_variable').length === 0, 'a script that is a longer word is not read');
ok(JSON.stringify(runs('(−1)^k V x V⁻¹')) === JSON.stringify(['(−1)^k']) && rest('(−1)^k V x V⁻¹') === '\u0000 V x V⁻¹', 'a bracket group takes its power');
ok(JSON.stringify(runs('2^{n−1} vertices and 2^n')) === JSON.stringify(['2^{n−1}', '2^n']), 'powers of numbers');
ok(JSON.stringify(runs('B_an, B_bn and B_ab')) === JSON.stringify(['B_an, B_bn', 'B_ab']), 'a comma list is one formula, a word ends it');
ok(JSON.stringify(runs('u_R, d_R, Q_L')) === JSON.stringify(['u_R, d_R, Q_L']), 'particle labels');
{ const p = parseMath('F^a_{μν}')[0].parts[0]; ok(p.sup === 'a' && p.sub === 'μν', 'both scripts on one symbol'); }
ok(JSON.stringify(runs('[D_μ, D_ν]Ψ = gF_{μν}Ψ.')) === JSON.stringify(['[D_μ, D_ν]Ψ = gF_{μν}Ψ']), 'neighbouring brackets and letters stay with the formula');
ok(runs('the term(D_μ) and wordx_1 here').join('|') === '(D_μ)', 'a letter inside a longer word is not a base');
ok(runs('e^{θB}').length === 1 && runs('Σ_{b<c} R^{bc}').length === 2, 'braces with operators');
ok(runs('plain text with no formulas at all.').length === 0 && parseMath('plain')[0].s === 'plain', 'plain text is returned as it is');
for (const s of ['D^μF_{μν} = J_ν', 'e^{θB}', 'B_an, B_bn', '(−1)^k', '2^{n−1}']) ok(parseMath(s).map(n => n.raw || n.s).join('') === s, 'the source text of ' + s + ' is kept (data-raw)');
// v9: parenthesised groups ^(…) _(…), letters outside the BMP (𝔹 = two UTF-16 units), combining marks, ℝ/ℂ/𝕆 as scripts, word scripts
const sym = s => parseMath(s).flatMap(n => (n.k === 'run' ? n.parts.filter(p => p.k === 'sym') : []));
// what a reader sees: no caret or underscore anywhere, also inside the scripts (they are typeset again by MathText)
const raw = s => parseMath(s).some(n => (n.k === 'text' ? /[_^]/.test(n.s) : n.parts.some(p => (p.k === 'sym' ? /[_^]/.test(p.base) || [p.sub, p.sup].some(t => t && raw(t)) : /[_^]/.test(p.s)))));
{ const p = sym('2ᵏ orientations, 2^(k−1) with sign ±'); ok(p.length === 1 && p[0]?.base === '2' && p[0]?.sup === 'k−1', '2^(k−1) is 2 with the superscript k−1 (the brackets group, they are not drawn)'); }
{ const p = sym('M=M₀e^(−𝔹_b t/2): Ṁ=−½ M𝔹_b'); ok(p.length === 2 && p[0]?.base === 'e' && p[0]?.sup === '−𝔹_b t/2' && p[1]?.base === '𝔹' && p[1]?.sub === 'b', 'e^(−𝔹_b t/2) and M𝔹_b: a letter outside the BMP is a base'); }
{ const p = sym('−𝔹_b t/2'); ok(p.length === 1 && p[0]?.base === '𝔹' && p[0]?.sub === 'b', 'the superscript −𝔹_b t/2 is typeset in turn'); }
{ const p = sym('𝔹_b=𝐁₀+M̃_(B₀)(ε𝐯₀)M_(B₀)'); ok(p.length === 3 && p[1]?.base === 'M̃' && p[1]?.sub === 'B₀' && p[2]?.base === 'M' && p[2]?.sub === 'B₀', 'a combining mark stays on its base: M̃_(B₀)'); }
{ const p = sym('𝔹̇_b=−ε(𝐯_b·𝐁_b)'); ok(p[0]?.base === '𝔹̇' && p[0]?.sub === 'b', '𝔹 with a dot above'); }
{ const p = sym('η_(s⃗)=∏ⱼw₋ⱼ^((1−sⱼ)/2)⊞'); ok(p.length === 2 && p[0]?.sub === 's⃗' && p[1]?.base === 'w₋ⱼ' && p[1]?.sup === '(1−sⱼ)/2', 'nested brackets inside ^(…); Unicode subscripts stay on the base'); }
{ const p = sym('=∏ᵢ₌₁^(d)vᵢ=∏ⱼ₌₁^(k)bⱼ'); ok(p.length === 2 && p[0]?.base === '∏ᵢ₌₁' && p[0]?.sup === 'd' && p[1]?.sup === 'k', '∏ᵢ₌₁^(d) is a product with an upper limit'); }
{ const p = sym('RvR^(~)=v cos2t+u sin2t'); ok(p.length === 1 && p[0]?.base === 'R' && p[0]?.sup === '~', 'RvR^(~): the last R takes the reverse mark'); }
{ const p = sym('With Y_phys = y_target − y_source, six edges'); ok(p.map(x => x.sub).join() === 'phys,target,source', 'word subscripts phys, target, source'); }
{ const p = sym('End_ℝ(𝕍) ≅ M₁₆(ℝ) and Tr_ℂ Y, P_ℍ, ℂ³_𝕆 ← ℂ²_ℍ'); ok(p.map(x => x.base + '|' + x.sub).join() === 'End|ℝ,Tr|ℂ,P|ℍ,ℂ³|𝕆,ℂ²|ℍ', 'ℝ ℂ ℍ 𝕆 as subscripts'); }
{ const p = sym('dim_(ℂ)𝕊^±=2^(k−1), c_±=ρ_± e^(iθ_±), m_∅², ψ = ρ^½'); ok(p.map(x => x.sub + x.sup).join() === 'ℂ,±,k−1,±,±,iθ_±,∅,½', 'single symbols ± ∅ ½ as scripts'); }
{ const p = sym('with γ = (−1)^|x∧m| (checked for all blades'); ok(p.length === 1 && p[0]?.base === '(−1)' && p[0]?.sup === '|x∧m|', 'a power between bars: (−1)^|x∧m|'); }
{ const p = sym('O O=Q Q=pseudoscalar_E²'); ok(p.length === 1 && p[0]?.base === 'pseudoscalar' && p[0]?.named && p[0]?.sub === 'E', 'an upright name takes a script'); }
{ const p = sym('(M̃ e₀₂ M)^(−*) = 2(m₀m₆ + m₄m₅)'); ok(p.length === 1 && p[0]?.base === '(M̃ e₀₂ M)' && p[0]?.sup === '−*', 'a bracket takes ^(−*)'); }
for (const s of ['O=∏ₐBₐ=e^(π/2(B₁+⋯+Bₖ)), R O R̃=O', 'dim_(ℝ) Cl Φ_(+⋯+)=2^(k+1)', 'grows like e^(0.53 t); one growth time 1.88', 'dim J = 2^(n−2) = 1, 2, 4', 'b eₓ b⁻¹=(−1)^(|x∧m|)eₓ', '𝖨_b[𝔹_b]≡M̃ 𝖨_w[M𝔹_bM̃] M', 'j 𝖨_±⁻¹[N]', "recombining b'_R, h', τ'_R.", 'Ḃ_(b1)=', 'star(m)=±e_(m̄), T n T̃ = n − (q·n) e_(bit 0)'])
  ok(!raw(s), 'no raw ^ or _ left in what a reader sees: ' + s);
for (const s of ['M=M₀e^(−𝔹_b t/2): Ṁ=−½ M𝔹_b, 𝔹_b=−2M̃Ṁ; 𝔹_w=M𝔹_bM̃', 'End_ℝ(𝕍) ≅ M₁₆(ℝ)', 'a 𝐯𝐯𝐯𝐯𝐯𝐯𝐯xM_b and', 'M_b+𝐯𝐯𝐯𝐯𝐯𝐯𝐯 end']) ok(parseMath(s).every(n => !/^[\uDC00-\uDFFF]/.test(n.k === 'text' ? n.s : n.raw) && !/[\uD800-\uDBFF]$/.test(n.k === 'text' ? n.s : n.raw)), 'a letter outside the BMP is never cut in two: ' + s);
ok(runs('gravity_selfcheck.py and x_maxima and my_variable and snake_case_name').length === 0, 'file names and snake_case words are still not formulas after the v9 rules');
// v15: three notations of the gravity lines of the conventions page: the word script grav (L_grav(c)), the four index letters abcd (ε_abcd) and a bracket whose formula holds a script ((Dξ^a)_b)
{ const p = sym('an action L_grav(c) − κL_m with δL_m'); ok(p.map(x => x.base + '|' + x.sub).join() === 'L|grav,L|m,L|m', 'L_grav(c) − κL_m: grav is a word script, the second and third L keep their m'); }
{ const p = sym('σ_abc = ½ε_abcd s^d with ε₀₁₂₃ = +1'); ok(p.map(x => x.base + '|' + x.sub + '|' + x.sup).join() === 'σ|abc|,ε|abcd|,s||d', 'ε_abcd: the four index letters are read whole, next to σ_abc and s^d'); }
{ const r = parseMath('∇_bξ_a = η_aa(Dξ^a)_b read from ω'), rn = r.filter(n => n.k === 'run'), p = rn[0].parts.filter(x => x.k === 'sym');
  ok(rn.length === 1 && p.map(x => x.base + '|' + x.sub + '|' + x.sup).join() === '∇|b|,ξ|a|,η|aa|,ξ||a,)|b|' && r[r.length - 1].s === ' read from ω', '(Dξ^a)_b: the formula inside is typeset on its own and the script sits on the closing bracket'); }
ok(runs('x_abcde and x_abcdef and L_gravity and x_maxima').length === 0 && sym('x_abcde and L_gravity').length === 0, 'a longer index string or a longer word is still not a script (abcde, abcdef, gravity, maxima)');
ok(sym('(a_1 + b)_2 and (x^2)^3').map(x => x.base + '|' + x.sub + '|' + x.sup).join() === 'a|1|,)|2|,x||2,)||3', 'brackets that hold a script take a following script, as ) with the script, for _ and for ^');
ok(sym('(a + b) and (a + b)_c and (a_b)').map(x => x.base + '|' + x.sub).join() === '(a + b)|c,a|b', 'a bracket without a script inside keeps its old reading (the whole group is the base), and a bracket that is not followed by a script stays a bracket');
for (const lang of ['en', 'it']) GRAVITY_CONV[lang].lines.forEach((l, i) => ok(!raw(l[1]), 'no raw ^ or _ left in line ' + i + ' of the gravity block of the conventions page (' + lang + ')'));
// every sentence of the claims table, in both slots, is typeset without raw script markup: the Atlas rows of the pages print these sentences through the typesetter. File names keep their underscores and are
// removed first (as in test_mathtext_ui.mjs). A notation the typesetter does not read (a script on a word, as in a caret after Cotton, or a name with an underscore, as in jup365 merged) is caught here, not only by the browser test
{ const FILE = /[\w./-]*\w\.(?:py|json|jsx?|mjs|cjs|md|sh|txt|html|csv|zip)\b/g, rows = (await import('./claimsData.js')).CLAIMS; let n = 0;
  // the fragments where a caret or an underscore is left raw (in a text run, on a base, or inside a script)
  const left = s => { const out = []; for (const x of parseMath(s)) { if (x.k === 'text') { const k = x.s.search(/[_^]/); if (k >= 0) out.push(x.s.slice(Math.max(0, k - 25), k + 25)); }
    else for (const p of x.parts) { if (p.k === 'sym') { if (/[_^]/.test(p.base)) out.push(p.base); for (const t of [p.sub, p.sup]) if (t) out.push(...left(t)); } else if (/[_^]/.test(p.s)) out.push(p.s); } } return out; };
  for (const r of rows) for (const lang of ['en', 'it']) for (const [i, l] of (r[lang] || []).entries()) { n++; const t = l.text.replace(FILE, '');
    if (/[_^]/.test(t)) { const f = left(t); ok(f.length === 0 && !raw(t), `no raw ^ or _ left in line ${i} of ${r.id} (${lang}): ${f.slice(0, 2).join(' | ')}`); } }
  ok(n >= 2046, 'the loop reached all 2,046 lines of the claims table: ' + n); }
console.log(bad ? bad + ' FAILURES' : 'ALL MATHTEXT TESTS PASS'); process.exit(bad ? 1 : 0);
