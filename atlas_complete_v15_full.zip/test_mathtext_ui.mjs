// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
// Formulas inside sentences are typeset on every page: no raw script markup (a caret ^ or an underscore _) is left in the visible text,
// on every page and every tab, in English and Italian, for all three audiences. Searched: every text node of the page, the text inside
// typeset runs (.mt), SVG labels (<text>, <tspan>, <title>), with every fold and every expandable table row opened. Allowed: code and pre blocks, form fields, and file names (gravity_selfcheck.py,
// forque_matrix.json, ...). The Maxwell coupling equation is also checked to be drawn with real sub/superscripts.
// Also searched (v9 fix round, T2-6): the aria-label and title attributes of every element (the names a screen reader reads, the tooltips), for _ ^ and \.
// Run: node test_mathtext_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST;
const APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); const errs = []; const left = {};
const PAGES = ['rule', 'atlas', 'conventions', 'maxwell', 'shapes', 'equations', 'furey', 'map', 'ask'];
const PROFS = ['Young Learner', 'Physicist', 'Mathematician'];
// file names are the only words that may keep an underscore; they are removed before the search
const FILE = /[\w./-]*\w\.(?:py|json|jsx?|mjs|cjs|md|sh|txt|html|csv|zip)\b/g;
let runs = 0, views = 0, chips = 0;
// the search, defined in the page: every rendered text node (SVG labels included) for _ and ^; the aria-label and title attributes for _ ^ and \
const SCANNER = () => { window.__mtScan = src => {
  const FILE = new RegExp(src, 'g'), out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const p = n.parentElement; if (!p || p.closest('code,pre,style,script,textarea,input,select')) continue;
    if (!p.closest('svg') && !p.getClientRects().length) continue;                       // not rendered (display:none)
    const t = n.nodeValue.replace(FILE, ''); const i = t.search(/[_^]/);
    if (i >= 0) { const where = p.closest('svg') ? 'svg ' + p.tagName : p.closest('.mt') ? '.mt' : p.tagName.toLowerCase(); out.push(`[${where}] ` + t.slice(Math.max(0, i - 25), i + 35).replace(/\s+/g, ' ')); }
  }
  // the names read aloud and the tooltips: aria-label and title attributes (sliders and SVG groups included) hold plain words, no _ ^ or \ markup (T2-6)
  for (const e of document.body.querySelectorAll('[aria-label],[title]')) {
    if (e.closest('code,pre,style,script')) continue;
    for (const a of ['aria-label', 'title']) { const v = e.getAttribute(a); if (!v) continue; const t = v.replace(FILE, ''), i = t.search(/[_^\\]/);
      if (i >= 0) out.push(`[@${a} ${e.tagName.toLowerCase()}] ` + t.slice(Math.max(0, i - 25), i + 35).replace(/\s+/g, ' ')); }
  }
  return out;
}; };
async function scan(lang, prof) {
  const ctx = await b.newContext({ viewport: { width: 1000, height: 900 } }); const pg = await ctx.newPage();
  await ctx.addInitScript(([l, p]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', p); } catch { /* ignore */ } }, [lang, prof]);
  await ctx.addInitScript(SCANNER);
  const tag = `${lang}/${prof}`;
  pg.on('pageerror', e => errs.push(`${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${tag} console: ${m.text()}`));
  for (const page of PAGES) {
    await pg.goto(APP + '#' + page); await pg.waitForTimeout(250);
    // the language and the audience are settings: make sure both are the ones asked for (Settings > language; control bar > audience)
    if ((await pg.locator('.story-nav .settings [data-lang].active').getAttribute('data-lang')) !== lang) errs.push(`${tag}/${page}: language setting not applied`);
    if (!(await pg.locator(`[data-profile="${prof}"]`).getAttribute('class') || '').includes('active')) await pg.locator(`[data-profile="${prof}"]`).click();
    const ids = await pg.locator('.tabbar [data-tab]').evaluateAll(els => els.map(e => e.getAttribute('data-tab')));
    for (const id of ids.length ? ids : [null]) {
      if (id) { await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(100); }
      // every fold and every expandable row (the forque, spin, spring and rigid tables) is opened, so that the text behind them is searched too
      await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(100);
      await pg.evaluate(() => document.querySelectorAll('main button[aria-expanded="false"]').forEach(x => { if (!x.closest('.story-nav')) x.click(); })); await pg.waitForTimeout(150);
      await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
      views++; runs += await pg.locator('.mt').count();
      const hits = await pg.evaluate(src => window.__mtScan(src), FILE.source);
      // then every chip button of the view is pressed once, in page order, and the page is searched again after each press: views that only a chip
      // opens (the spring's pluck view with its named corners, the lenses of the null-surface figures, ...) are searched too (T2-6)
      const after = await pg.evaluate(async src => { const all = () => [...document.querySelectorAll('main .eq-chips button')], out = new Set(); let k = 0;
        for (let i = 0; i < all().length && k < 400; i++, k++) { all()[i].click(); await new Promise(r => setTimeout(r, 0)); for (const h of window.__mtScan(src)) out.add('(after a chip) ' + h); }
        return { hits: [...out], clicks: k }; }, FILE.source);
      chips += after.clicks;
      if (hits.length || after.hits.length) left[`${tag}/${page}${id ? '/' + id : ''}`] = [...hits, ...after.hits].slice(0, 8);
    }
    if (page === 'equations' && lang === 'en' && prof === 'Physicist') {
      await pg.locator('.tabbar [data-tab="matter"]').click(); await pg.waitForTimeout(150); await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
      const el = pg.locator('.mt[data-raw="D^μF_{μν} = κj_ν"]').first();
      if (!(await el.count())) errs.push('the coupling equation is not typeset');
      else { const h = await el.innerHTML(); if (!/<sup>.*μ.*<\/sup>/.test(h) || !/<sub>.*μν.*<\/sub>/.test(h) || /[_^]/.test(await el.textContent())) errs.push('D^μF_{μν} is not drawn with scripts: ' + h.slice(0, 200)); }
    }
  }
  await ctx.close();
}
const jobs = []; for (const lang of ['en', 'it']) for (const prof of PROFS) jobs.push([lang, prof]);
for (let i = 0; i < jobs.length; i += 3) await Promise.all(jobs.slice(i, i + 3).map(([l, p]) => scan(l, p)));
if (views < 6 * 28) errs.push('only ' + views + ' views scanned');
if (runs < 1800) errs.push('only ' + runs + ' formula runs over the pages');
if (chips < 1200) errs.push('only ' + chips + ' chip presses over the pages');
for (const [k, v] of Object.entries(left)) errs.push(`raw script markup left on ${k}: ${v.join(' || ')}`);
console.log(errs.length ? errs.join('\n') : 'MATHTEXT UI OK (' + views + ' views, ' + runs + ' formula runs, ' + chips + ' chip presses)');
await b.close(); process.exit(errs.length ? 1 : 0);
