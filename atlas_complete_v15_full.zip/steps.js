// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// One list per group of steps, and every "STEP k OF N" label is derived from it, so adding a step can never leave a stale number or total.
// Groups: the shapes page (3 steps, numbered on their own), the Conventions page (1 step: the clock, the first step of the story), the equations page
// (15 steps, numbered 2 to 16; the tally is the wrap-up and has no number) and the lenses page (4 steps, numbered 17 to 20: the finite groups, then the category, Baez and Schuller chapters).
export const STEP_GROUPS = {
  shapes: ['orth', 'demi', 'gosset'],
  core: ['clock'],
  eq: ['comm', 'mirrors', 'dirac', 'spin', 'coupling', 'ym', 'matter', 'grav1', 'grav2', 'projective', 'gauge', 'nullsurf', 'forque', 'spring', 'rigid'],
  lens: ['groups', 'category', 'baez', 'schuller'],
};
// The numbering of the story continues from one page to the next in the order of the pages: the Conventions page holds Step 1, the equations page Steps 2 to 16,
// the lenses page Steps 17 to 20, and every one of them reads "of 20" (the length of the story). A group without an entry here starts at 1 and counts its own steps (the shapes page).
export const STEP_OFFSET = { eq: STEP_GROUPS.core.length, lens: STEP_GROUPS.core.length + STEP_GROUPS.eq.length };
export const WORDS = {
  en: { step: 'STEP', of: 'OF', page: 'PAGE', Step: 'Step', steps: 'steps' },
  it: { step: 'PASSO', of: 'DI', page: 'PAGINA', Step: 'Passo', steps: 'passi' },
};
export const STEP_NAMES = {
  en: { category: 'THE CATEGORY LENS: WHAT IS LABEL 0?', baez: 'BAEZ: SEVEN PAPERS AND THE ATLAS', schuller: 'SCHULLER: FROM THE ALGEBRA TO THE DYNAMICS, FIBRE AND BASE', clock: 'THE CLOCK AND THE TRINITY', gauge: 'GAUGE GRAVITY: THE HORIZON, WHERE THE RADIAL GRADIENT IS NULL', groups: 'FINITE GROUPS: THE LENS THAT COUNTS', orth: 'THE ORTHOPLEX', demi: 'THE DEMICUBE', gosset: 'THE GOSSET SERIES', comm: 'COMMUTATORS', dirac: 'THE DIRAC EQUATION', coupling: 'MAXWELL MEETS DIRAC', ym: 'YANG–MILLS', matter: 'MATTER CHARGED UNDER so(m)', grav1: 'GRAVITY I: CONNECTION, CURVATURE, TORSION', grav2: 'GRAVITY II: THE EINSTEIN FORM', mirrors: 'MIRRORS: VERSORS, CARTAN–DIEUDONNÉ, THE CUBE AS A GROUP', projective: 'ONE MORE GENERATOR, AND A NULL PAIR', forque: 'FORQUE: FORCE AND TORQUE AS ONE LINE', spin: 'POINTORS AND THE THREE KINDS OF i', spring: 'A SPRING ON THE CUBE: VERTICES, EDGES, FACES', rigid: 'A RIGID BODY: FROM THE SEGMENT TO THE TESSERACT', nullsurf: 'NULL SURFACES: THE GENERATOR OF A HORIZON IS A NULL GEODESIC' },
  it: { category: 'LA LENTE CATEGORIALE: CHE COS’È L’ETICHETTA 0?', baez: 'BAEZ: SETTE ARTICOLI E L’ATLANTE', schuller: 'SCHULLER: DALL’ALGEBRA ALLA DINAMICA, FIBRA E BASE', clock: 'L’OROLOGIO E LA TRINITÀ', gauge: 'GAUGE GRAVITY: THE HORIZON, WHERE THE RADIAL GRADIENT IS NULL', groups: 'GRUPPI FINITI: LA LENTE CHE CONTA', orth: 'L’ORTOPLESSO', demi: 'IL DEMICUBO', gosset: 'LA SERIE DI GOSSET', comm: 'COMMUTATORI', dirac: 'L’EQUAZIONE DI DIRAC', coupling: 'MAXWELL INCONTRA DIRAC', ym: 'YANG–MILLS', matter: 'MATERIA CARICA SOTTO so(m)', grav1: 'GRAVITÀ I: CONNESSIONE, CURVATURA, TORSIONE', grav2: 'GRAVITÀ II: LA FORMA DI EINSTEIN', mirrors: 'SPECCHI: VERSORI, CARTAN–DIEUDONNÉ, IL CUBO COME GRUPPO', projective: 'UN GENERATORE IN PIÙ, E UNA COPPIA NULLA', forque: 'FORQUE: FORZA E COPPIA COME UNA SOLA RIGA', spin: 'POINTOR E I TRE TIPI DI i', spring: 'UNA MOLLA SUL CUBO: VERTICI, SPIGOLI, FACCE', rigid: 'UN CORPO RIGIDO: DAL SEGMENTO AL TESSERATTO', nullsurf: 'NULL SURFACES: THE GENERATOR OF A HORIZON IS A NULL GEODESIC' },
};
// short names for the in-page navigation of the equations page (the tally is last and has no step number)
export const NAV_NAMES = {
  en: { category: 'Category lens', baez: 'Baez papers', schuller: 'Schuller lectures', clock: 'Clock · trinity', gauge: 'Gauge gravity', groups: 'Finite groups', conventions: 'Conventions', views: 'The algebra and three notations', charges: 'Charges in the fields', ladders: 'Ladders · check it', orth: 'The orthoplex', demi: 'The demicube', gosset: 'Gosset series', comm: 'Commutators', dirac: 'Dirac', coupling: 'Coupling', ym: 'Yang–Mills', matter: 'Charged matter', grav1: 'Gravity I', grav2: 'Gravity II', mirrors: 'Mirrors', projective: 'One more generator', forque: 'Forque dynamics', spin: 'Pointors and spin', spring: 'A spring on the cube', rigid: 'A rigid body', nullsurf: 'Null surfaces', tally: 'Tally' },
  it: { category: 'Lente categoriale', baez: 'Articoli di Baez', schuller: 'Lezioni di Schuller', clock: 'Orologio · trinità', gauge: 'Gravità di gauge', groups: 'Gruppi finiti', conventions: 'Convenzioni', views: 'The algebra and three notations', charges: 'Cariche nei campi', ladders: 'Scale · verificalo', orth: 'L’ortoplesso', demi: 'Il demicubo', gosset: 'Serie di Gosset', comm: 'Commutatori', dirac: 'Dirac', coupling: 'Accoppiamento', ym: 'Yang–Mills', matter: 'Materia carica', grav1: 'Gravità I', grav2: 'Gravità II', mirrors: 'Specchi', projective: 'Un generatore in più', forque: 'Dinamica del forque', spin: 'Pointor e spin', spring: 'Una molla sul cubo', rigid: 'Un corpo rigido', nullsurf: 'Superfici nulle', tally: 'Bilancio' },
};
// The Young Learner reads plain names (no formulas, no technical words): the same steps, the same numbers, other words.
export const STEP_NAMES_YL = {
  en: { category: 'THE ZERO SWITCH, SEEN FROM BELOW AND FROM ABOVE', baez: 'SEVEN PAPERS AND THE SWITCH RULE', schuller: 'FROM THE SWITCH RULE TO HOW THINGS MOVE', clock: 'ONE CLOCK, THREE KINDS OF MOVE', gauge: 'FALLING SPACE AND THE EDGE OF A BLACK HOLE', groups: 'COUNTING THE WAYS TO SHUFFLE', orth: 'TWO POLES ON EVERY LINE', demi: 'HALF OF THE CUBE', gosset: 'THE BIG SHAPE IN EIGHT DIMENSIONS', comm: 'WHEN THE ORDER MATTERS', dirac: 'THE ELECTRON’S RULE', coupling: 'LIGHT MEETS THE ELECTRON', ym: 'FORCES WITH MANY CHARGES', matter: 'MATTER THAT FEELS THOSE FORCES', grav1: 'GRAVITY, PART 1: HOW SPACE BENDS', grav2: 'GRAVITY, PART 2: EINSTEIN’S EQUATION', mirrors: 'MIRRORS: TWO MIRRORS MAKE A TURN', projective: 'ONE MORE DIRECTION', forque: 'PUSH AND SPIN AS ONE LINE', spin: 'THINGS THAT TURN TWICE', spring: 'A SPRING ON THE CUBE: CORNERS, EDGES, FACES', rigid: 'A SOLID BODY: FROM A STICK TO A 4D CUBE', nullsurf: 'SURFACES OF LIGHT THAT STAND STILL' },
  it: { category: 'L’INTERRUTTORE ZERO, VISTO DAL BASSO E DALL’ALTO', baez: 'SETTE ARTICOLI E LA REGOLA DEGLI INTERRUTTORI', schuller: 'DALLA REGOLA DEGLI INTERRUTTORI A COME SI MUOVONO LE COSE', clock: 'UN OROLOGIO, TRE TIPI DI MOSSA', gauge: 'LO SPAZIO CHE CADE E IL BORDO DI UN BUCO NERO', groups: 'CONTARE I MODI DI RIMESCOLARE', orth: 'DUE POLI SU OGNI LINEA', demi: 'METÀ DEL CUBO', gosset: 'LA GRANDE FORMA A OTTO DIMENSIONI', comm: 'QUANDO L’ORDINE CONTA', dirac: 'LA REGOLA DELL’ELETTRONE', coupling: 'LA LUCE INCONTRA L’ELETTRONE', ym: 'FORZE CON TANTE CARICHE', matter: 'LA MATERIA CHE SENTE QUELLE FORZE', grav1: 'GRAVITÀ, PARTE 1: COME SI PIEGA LO SPAZIO', grav2: 'GRAVITÀ, PARTE 2: L’EQUAZIONE DI EINSTEIN', mirrors: 'SPECCHI: DUE SPECCHI FANNO UN GIRO', projective: 'UNA DIREZIONE IN PIÙ', forque: 'SPINTA E ROTAZIONE IN UNA SOLA RIGA', spin: 'COSE CHE GIRANO DUE VOLTE', spring: 'UNA MOLLA SUL CUBO: VERTICI, SPIGOLI, FACCE', rigid: 'UN CORPO SOLIDO: DA UN BASTONCINO A UN CUBO 4D', nullsurf: 'SUPERFICI DI LUCE FERME' },
};
export const NAV_NAMES_YL = {
  en: { category: 'The zero switch', baez: 'Seven papers', schuller: 'From rule to motion', clock: 'The clock and three moves', gauge: 'Falling space', groups: 'Ways to shuffle', conventions: 'Our words', views: 'One picture, three ways of writing it', charges: 'A charge on the move', ladders: 'Ladders · check it yourself', orth: 'Two poles on every line', demi: 'Half of the cube', gosset: 'The big shape in 8D', comm: 'When the order matters', dirac: 'The electron’s rule', coupling: 'Light meets the electron', ym: 'Forces with many charges', matter: 'Charged matter', grav1: 'Gravity, part 1', grav2: 'Gravity, part 2', mirrors: 'Mirrors', projective: 'One more direction', forque: 'Push and spin', spin: 'Things that turn twice', spring: 'A spring on the cube', rigid: 'A solid body', nullsurf: 'Surfaces of light', tally: 'Tally' },
  it: { category: 'L’interruttore zero', baez: 'Sette articoli', schuller: 'Dalla regola al moto', clock: 'L’orologio e tre mosse', gauge: 'Lo spazio che cade', groups: 'Modi di rimescolare', conventions: 'Le nostre parole', views: 'One picture, three ways of writing it', charges: 'Una carica in movimento', ladders: 'Scale · controllalo tu', orth: 'Due poli su ogni linea', demi: 'Metà del cubo', gosset: 'La grande forma in 8D', comm: 'Quando l’ordine conta', dirac: 'La regola dell’elettrone', coupling: 'La luce incontra l’elettrone', ym: 'Forze con tante cariche', matter: 'Materia carica', grav1: 'Gravità, parte 1', grav2: 'Gravità, parte 2', mirrors: 'Specchi', projective: 'Una direzione in più', forque: 'Spinta e rotazione', spin: 'Cose che girano due volte', spring: 'Una molla sul cubo', rigid: 'Un corpo solido', nullsurf: 'Superfici di luce', tally: 'Bilancio' },
};
// The audience of the page, set by App on every render (before any section renders), so that the step labels a section prints
// (stepEyebrow, navLabel, the tab bar) are the plain ones for the Young Learner without every section passing it on. Default: the formal names.
let AUDIENCE = 'Physicist';
export const setStepAudience = a => { AUDIENCE = a; };
export const stepAudience = () => AUDIENCE;
const learner = () => AUDIENCE === 'Young Learner';
export const navNames = (lang, profile = AUDIENCE) => ((profile === 'Young Learner' ? NAV_NAMES_YL : NAV_NAMES)[lang] || (profile === 'Young Learner' ? NAV_NAMES_YL : NAV_NAMES).en);
export const stepCount = group => STEP_GROUPS[group].length;
// the N of "STEP k OF N": the length of the story (20) for every step of it (core, eq, lens); a group that is not part of the story keeps its own count (shapes: 3)
export const stepTotal = group => (['core', 'eq', 'lens'].includes(group) ? STEP_OFFSET.lens + stepCount('lens') : stepCount(group));
export const stepNo = (group, id) => { const k = STEP_GROUPS[group].indexOf(id); if (k < 0) throw new Error(`unknown step ${group}/${id}`); return (STEP_OFFSET[group] || 0) + k + 1; };
const W = lang => WORDS[lang] || WORDS.en, N = lang => (learner() ? STEP_NAMES_YL[lang] || STEP_NAMES_YL.en : STEP_NAMES[lang] || STEP_NAMES.en);
// "STEP 7 OF 10 · YANG–MILLS"; a section may pass its own name, otherwise the shared one is used
export const stepEyebrow = (lang, group, id, name) => `${W(lang).step} ${stepNo(group, id)} ${W(lang).of} ${stepTotal(group)} · ${name || N(lang)[id]}`;
// "Step 7 · Yang–Mills" for the navigation chips
export const navLabel = (lang, group, id) => (STEP_GROUPS[group].includes(id) ? `${W(lang).Step} ${stepNo(group, id)} · ` : '') + navNames(lang)[id];
export const lensIds = () => [...STEP_GROUPS.lens];
// the group a step id belongs to ('clock' is in core, 'gauge' in eq, 'groups' in lens), or null for a tab that is not a numbered step
export const groupOfStep = id => Object.keys(STEP_GROUPS).find(g => STEP_GROUPS[g].includes(id)) || null;
export const eqNavIds = () => [...STEP_GROUPS.eq, 'tally'];
// "PAGE 6 OF 11" for the story pages (the word "step" is kept for the numbered steps inside a page)
export const pageEyebrow = (lang, i, total) => `${W(lang).page} ${i} ${W(lang).of} ${total}`;

// number words, so that prose such as "ten steps" is written from the lists above and cannot go stale
export const NUMW = {
  en: ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen', 'twenty'],
  it: ['zero', 'uno', 'due', 'tre', 'quattro', 'cinque', 'sei', 'sette', 'otto', 'nove', 'dieci', 'undici', 'dodici', 'tredici', 'quattordici', 'quindici', 'sedici', 'diciassette', 'diciotto', 'diciannove', 'venti'],
};
export const numWord = (lang, n) => (NUMW[lang] || NUMW.en)[n];
export const capital = w => w.charAt(0).toUpperCase() + w.slice(1);
