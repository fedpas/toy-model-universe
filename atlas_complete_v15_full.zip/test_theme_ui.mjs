// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The theme switch in the browser (v10.2): the Theme group of Settings (Auto, Light, Dark; aria-pressed; EN and IT), data-theme on <html> set before React
// draws, the choice kept across a reload, auto following an emulated prefers-color-scheme live, ?theme= beating storage, blocked storage; in light mode the
// sticky page bar, the Settings menu, the contact dialog and the researcher note stay where they belong (a filter on the root must not move fixed boxes);
// the four status tags (and the badges drawn like them) measured on screenshots at 4.5:1 or more on the light page and on the card surfaces; the two
// three.js pictures still drawn; the DARK page pixel for pixel unchanged: with the theme and filter rules removed from this build (always), and against
// the v10.1 build when ATLAS_BASE_DIST=<its dist folder> is set (otherwise that part is skipped and says so; it is meaningful only for a build that has v10.1's TEXT: v10.2 changes
// the audited wording and tags, so against a v10.1 build the pages differ exactly where the text differs, and 18 of 18 views then differ). Light screenshots of rule, atlas,
// equations and labels at 375 and 1100 px are written to <ATLAS_SHOTS>/theme for a person to look at. The icon of every status badge measures its own size (13 to 16 px, never more than 24 px)
// on the Maxwell, atlas, spin and Furey pages, dark and light, at 375 and 1100 px, for the Physicist and the Young Learner.   Run: node test_theme_ui.mjs
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { APP_HTML, SHOTS } from './paths.mjs';
import { setLang } from './ui_helpers.mjs';
const BASE = process.env.ATLAS_BASE_DIST ? pathToFileURL(path.join(path.resolve(process.env.ATLAS_BASE_DIST), 'app.html')).href : null;
const OUT = path.join(SHOTS, 'theme'); fs.mkdirSync(OUT, { recursive: true });
const b = await chromium.launch(); let checks = 0, bad = 0;
const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const info = m => console.log('  ' + m);
// a console error fails the test, except the contact form's own request, which a file:// page cannot make (test_contact_ui.mjs serves it; here only the dialog's box is measured)
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => { if (m.type() === 'error' && !/file:\/\/\/api\/contact/.test(m.text())) ok(false, `${tag}: console error ${m.text()}`); }); };
const url = (q, hash) => APP_HTML + (q ? '?' + q : '') + '#' + hash;
const theme = pg => pg.evaluate(() => document.documentElement.getAttribute('data-theme'));
const stored = pg => pg.evaluate(() => { try { return localStorage.getItem('atlas.theme'); } catch { return 'blocked'; } });
const openSettings = async pg => { if (!(await pg.locator('.story-nav .settings').evaluate(e => e.open))) { await pg.locator('.story-nav .settings > summary').click(); await pg.waitForTimeout(80); } };
const pick = async (pg, v) => { await openSettings(pg); await pg.locator(`.story-nav .settings [data-theme-choice="${v}"]`).click(); await pg.waitForTimeout(120); };
const groups = pg => pg.evaluate(() => [...document.querySelectorAll('.story-nav .settings-pop [role=group]')].map(g => [g.getAttribute('aria-label'), [...g.querySelectorAll('button')].map(x => [x.textContent, x.getAttribute('aria-pressed')])]));

// ---- 1. the control, the attribute, storage, reload, Italian
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'control');
  await pg.goto(url('', 'rule')); await pg.waitForTimeout(300);
  ok(await theme(pg) === 'dark' && await stored(pg) === null, 'a first visit is dark and stores nothing: ' + await theme(pg));
  await openSettings(pg); const g = await groups(pg);
  ok(g.length >= 2 && g[0][0] === 'Language' && g[1][0] === 'Theme' && JSON.stringify(g[1][1]) === JSON.stringify([['Auto', 'false'], ['Light', 'false'], ['Dark', 'true']]), 'Settings has a Theme group beside Language: Auto, Light, Dark, Dark pressed: ' + JSON.stringify(g.slice(0, 2)));
  await pick(pg, 'light');
  ok(await theme(pg) === 'light' && await stored(pg) === 'light' && (await groups(pg))[1][1][1][1] === 'true', 'Light: <html data-theme="light">, stored under atlas.theme, the button pressed');
  ok(await pg.locator('.story-nav .settings').evaluate(e => e.open), 'the menu stays open after a theme is chosen (the language closes it, as before)');
  ok(await pg.evaluate(() => getComputedStyle(document.documentElement).filter) === 'invert(1) hue-rotate(180deg)', 'light mode is the inversion filter on <html>');
  await pg.reload(); await pg.waitForTimeout(300);
  ok(await theme(pg) === 'light', 'the light theme survives a reload');
  await setLang(pg, 'it'); await openSettings(pg); const gi = await groups(pg);
  ok(gi[1] && gi[1][0] === 'Tema' && JSON.stringify(gi[1][1].map(x => x[0])) === JSON.stringify(['Auto', 'Chiaro', 'Scuro']), 'Italian: Tema, Auto, Chiaro, Scuro: ' + JSON.stringify(gi[1]));
  await pick(pg, 'dark'); ok(await theme(pg) === 'dark' && await stored(pg) === 'dark' && await pg.evaluate(() => getComputedStyle(document.documentElement).filter) === 'none', 'Scuro: back to dark, no filter');
  await setLang(pg, 'en'); await ctx.close(); }

// ---- 2. auto follows prefers-color-scheme, live
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 }, colorScheme: 'light' }), pg = await ctx.newPage(); onErr(pg, 'auto');
  await pg.goto(url('', 'equations')); await pg.waitForTimeout(300);
  ok(await theme(pg) === 'dark', 'the default is dark even when the system prefers light (auto is a choice, not the default)');
  await pick(pg, 'auto'); ok(await theme(pg) === 'light' && await stored(pg) === 'auto', 'Auto with a light system: light');
  await pg.emulateMedia({ colorScheme: 'dark' }); await pg.waitForTimeout(150); ok(await theme(pg) === 'dark', 'Auto: the system turns dark, the page follows without a reload');
  await pg.emulateMedia({ colorScheme: 'light' }); await pg.waitForTimeout(150); ok(await theme(pg) === 'light', 'Auto: and back to light');
  await pick(pg, 'dark'); await pg.emulateMedia({ colorScheme: 'light' }); await pg.waitForTimeout(150); ok(await theme(pg) === 'dark', 'Dark chosen: a light system does not change it');
  await ctx.close(); }

// ---- 3. the address beats storage (and is not stored); a wrong value is ignored; no flash: data-theme is set before React draws
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } });
  await ctx.addInitScript(() => { try { if (!sessionStorage.getItem('seeded')) { localStorage.setItem('atlas.theme', 'dark'); sessionStorage.setItem('seeded', '1'); } } catch { /* ignore */ }
    // record the order: the theme attribute and the theme rules against the first element React puts into #r
    window.__order = []; new MutationObserver(ms => { for (const m of ms) { if (m.type === 'attributes' && m.attributeName === 'data-theme' && !window.__order.includes('theme')) window.__order.push('theme');
      if (m.type === 'childList') { if ([...m.addedNodes].some(n => n.id === 'atlas-theme') && !window.__order.includes('rules')) window.__order.push('rules'); const r = document.getElementById('r'); if (r && r.firstChild && !window.__order.includes('react')) window.__order.push('react'); } } })
      .observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ['data-theme'] }); });
  const pg = await ctx.newPage(); onErr(pg, 'url');
  await pg.goto(url('theme=light', 'atlas')); await pg.waitForTimeout(300);
  ok(await theme(pg) === 'light' && await stored(pg) === 'dark', '?theme=light beats the stored dark, and is not stored');
  const order = await pg.evaluate(() => window.__order);
  ok(order.indexOf('theme') >= 0 && order.indexOf('rules') >= 0 && order.indexOf('theme') < order.indexOf('react') && order.indexOf('rules') < order.indexOf('react'), 'the theme attribute and its rules are in place before React draws anything (no flash): ' + order.join(' < '));
  await pg.goto(url('theme=sepia', 'atlas')); await pg.waitForTimeout(250); ok(await theme(pg) === 'dark', '?theme=sepia is ignored (the stored dark is used)');
  await ctx.close(); }

// ---- 4. blocked storage: the page works, the choice lasts for the session, the address still works
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } });
  await ctx.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('storage blocked'); } }); });
  const pg = await ctx.newPage(); onErr(pg, 'blocked');
  await pg.goto(url('', 'rule')); await pg.waitForTimeout(300);
  ok(await theme(pg) === 'dark', 'blocked storage: dark, no error');
  await pick(pg, 'light'); await pg.locator('.story-nav > button').nth(5).click(); await pg.waitForTimeout(200);
  ok(await theme(pg) === 'light' && (await pg.evaluate(() => location.hash)).startsWith('#equations'), 'blocked storage: the choice holds while the reader moves between pages');
  await pg.goto(url('theme=light', 'map')); await pg.waitForTimeout(250); ok(await theme(pg) === 'light', 'blocked storage: ?theme=light makes it stick');
  await ctx.close(); }

// ---- 5. light mode: sticky and fixed boxes stay where they belong (a filter on the root element must not become their containing block)
for (const w of [1100, 375]) {
  const tag = `fixed ${w}`, ctx = await b.newContext({ viewport: { width: w, height: 700 } }), pg = await ctx.newPage(); onErr(pg, tag);
  const measure = async q => {
    await pg.goto(url(q, 'equations/coupling')); await pg.waitForTimeout(300); await pg.evaluate(() => window.scrollTo(0, 2500)); await pg.waitForTimeout(150);
    const nav = await pg.evaluate(() => { const r = document.querySelector('.story-nav').getBoundingClientRect(); return [Math.round(r.top), Math.round(r.height)]; });
    await openSettings(pg); await pg.waitForTimeout(200); const pop = await pg.evaluate(() => { const r = document.querySelector('.settings-pop').getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom), innerHeight]; });
    await pg.keyboard.press('Escape');
    await pg.locator('footer .contact-link').click(); await pg.locator('[role=dialog]').first().waitFor(); await pg.evaluate(() => window.scrollTo(0, 400)); await pg.waitForTimeout(150);
    const dlg = await pg.evaluate(() => { const r = document.querySelector('.cf-overlay').getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)]; });
    await pg.keyboard.press('Escape'); await pg.waitForTimeout(100);
    await pg.goto(url((q ? q + '&' : '') + 'for=furey', 'equations')); await pg.waitForTimeout(300); await pg.evaluate(() => window.scrollTo(0, 1500)); await pg.waitForTimeout(100);
    const note = await pg.evaluate(() => { const r = document.querySelector('.rn-overlay')?.getBoundingClientRect(); return r ? [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)] : null; });
    return { nav, pop, dlg, note };
  };
  const d = await measure(''), l = await measure('theme=light'), vw = await pg.evaluate(() => [innerWidth, innerHeight]);
  ok(l.nav[0] === 0 && JSON.stringify(l.nav) === JSON.stringify(d.nav), `${tag}: the page bar sticks at the top after scrolling, in light as in dark (${l.nav} / ${d.nav})`);
  ok(JSON.stringify(l.pop.slice(0, 3)) === JSON.stringify(d.pop.slice(0, 3)) && l.pop[0] >= 0 && l.pop[2] <= vw[0] && l.pop[1] > 0 && l.pop[1] < 120 && l.pop[3] <= l.pop[4] && d.pop[3] <= d.pop[4], `${tag}: the Settings menu opens in view below the page bar, at the same place in both themes (left, top, right, bottom, window height: ${l.pop} / ${d.pop})`);
  ok(JSON.stringify(l.dlg) === JSON.stringify([0, 0, vw[0], vw[1]]) && JSON.stringify(d.dlg) === JSON.stringify(l.dlg), `${tag}: the contact dialog covers the window after scrolling, in both themes (${l.dlg} / ${d.dlg})`);
  ok(l.note && JSON.stringify(l.note) === JSON.stringify([0, 0, vw[0], vw[1]]) && JSON.stringify(d.note) === JSON.stringify(l.note), `${tag}: the researcher note covers the window, in both themes (${l.note} / ${d.note})`);
  await ctx.close();
}

// ---- 6. contrast of the status tags on screenshots (light; the dark numbers are printed for comparison)
// the clip of one element at device scale 2: its background = the most frequent colour, its ink = the pixel with the highest contrast against it (antialiasing
// only lowers the contrast of a pixel, so this is a lower bound of the contrast of the text and the border, which are drawn in the tag's colour)
const ANALYSE = async (pg, buf) => pg.evaluate(async b64 => {
  const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + b64)).blob()); const c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height;
  const x = c.getContext('2d'); x.drawImage(bm, 0, 0); const d = x.getImageData(0, 0, c.width, c.height).data, n = new Map();
  for (let i = 0; i < d.length; i += 4) { const k = (d[i] << 16) | (d[i + 1] << 8) | d[i + 2]; n.set(k, (n.get(k) || 0) + 1); }
  const bg = [...n.entries()].sort((a, b2) => b2[1] - a[1])[0][0], rgb = k => [(k >> 16) & 255, (k >> 8) & 255, k & 255];
  const lin = v => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }, L = c2 => 0.2126 * lin(c2[0]) + 0.7152 * lin(c2[1]) + 0.0722 * lin(c2[2]);
  const cr = (a, b2) => { const p = L(a), q = L(b2); return (Math.max(p, q) + 0.05) / (Math.min(p, q) + 0.05); };
  let best = 1, ink = bg; for (const k of n.keys()) { const v = cr(rgb(k), rgb(bg)); if (v > best) { best = v; ink = k; } }
  const hx = k => '#' + rgb(k).map(v => v.toString(16).padStart(2, '0')).join('');
  return { bg: hx(bg), ink: hx(ink), cr: best };
}, buf.toString('base64'));
const KINDS = ['checked', 'standard', 'ours', 'open', 'input'];
const SAMPLE = [   // [address, what to open first, selectors]: tags on the page, in the legend (85 % opacity), in captions (80 %), in cards and strips, ledgers, badges
  ['equations/coupling', 'details', '.page-tags > .tag, .page-tags details .tag, .glance .tag, .needs-strip .tag, .eq-pt .tag, .eq-xr .tag, .eq-card .tag, .eq-cap .tag'],
  ['equations/spin', 'rows', '.sp-row .tag, .sp-finding .tag'],
  ['equations/tally', 'details', '#eq-tally .tag'],
  ['shapes/gosset', 'details', '.gs-cap .tag, .gs-pt .tag, .gs-xr .tag'],
  ['equations/gauge', '', '.ls-glance .tag'],
  ['atlas', 'details', '.audit-line .tag, .proof-status'],
  ['furey/earlier', '', '.eq-pt .tag'],
  ['furey/threegen', '', '.eq-pt .tag, .fw-w .tag'],
  ['furey/help', '', '.eq-pt .tag'],
  ['furey/findings', '', '.f-badge'],
  ['map', 'details', '.map-tree .tag'],
  ['equations', 'note', '.rn-tag'],
];
const worst = {};
for (const [q, label] of [['theme=light', 'light'], ['', 'dark']]) {
  const ctx = await b.newContext({ viewport: { width: 1100, height: 900 }, deviceScaleFactor: 2 });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.audience', 'Physicist'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(); onErr(pg, 'contrast ' + label);
  for (const [link, open, sel] of SAMPLE) {
    await pg.goto(url(open === 'note' ? (q ? q + '&' : '') + 'for=furey' : q, link)); await pg.waitForTimeout(400);
    if (open === 'details') await pg.evaluate(() => document.querySelectorAll('main details').forEach(d => { d.open = true; }));
    if (open === 'rows') await pg.evaluate(() => document.querySelectorAll('main button[aria-expanded="false"]').forEach(x => x.click()));
    await pg.waitForTimeout(150);
    const els = await pg.locator(sel).all(); const seen = new Set(); let n = 0;
    for (const e of els) {
      const key = await e.evaluate(x => { const k = ['checked', 'standard', 'ours', 'open', 'input'].find(c => x.classList.contains(c)) || (x.getAttribute('style') || '').replace(/.*?color: ([^;]+);.*/, '$1'); let p = x.parentElement, sig = ''; for (let i = 0; i < 3 && p; i++, p = p.parentElement) sig += '<' + (p.className && typeof p.className === 'string' ? p.className.split(' ')[0] : p.tagName); return x.className.split(' ')[0] + '.' + k + sig; });
      if (seen.has(key)) continue; seen.add(key);
      await e.evaluate(x => x.scrollIntoView({ block: 'center' })); await pg.waitForTimeout(40);
      const bb = await e.boundingBox(); if (!bb || bb.width < 8 || bb.height < 8) continue;
      const r = await ANALYSE(pg, await pg.screenshot({ clip: { x: bb.x, y: bb.y, width: Math.min(bb.width, 600), height: bb.height } })); n++;
      const k = `${label} ${key.split('<')[0]}`; if (!worst[k] || r.cr < worst[k].cr) worst[k] = { ...r, where: link + ' ' + key };
      if (label === 'light') ok(r.cr >= 4.5, `light ${link}: ${key} has ${r.cr.toFixed(2)}:1 (ink ${r.ink} on ${r.bg})`);
    }
    ok(n > 0, `${label} ${link}: some of "${sel}" were measured`);
  }
  await ctx.close();
}
for (const [k, v] of Object.entries(worst).sort()) info(`lowest ${k}: ${v.cr.toFixed(2)}:1 (ink ${v.ink} on ${v.bg}) at ${v.where}`);
ok(KINDS.every(k => worst['light tag.' + k]), 'all five kinds of tag were measured in light mode: ' + Object.keys(worst).filter(k => k.startsWith('light')).join(', '));

// ---- 7. the three.js pictures are still drawn in light mode (pixels and colours besides the ground, as test_canvas_ui.mjs counts them)
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } }), pg = await ctx.newPage(); onErr(pg, 'canvas');
  for (const link of ['rule', 'atlas']) {
    await pg.goto(url('theme=light', link)); await pg.waitForTimeout(900);
    const c = pg.locator('main canvas').first();
    if (!(await c.count())) { ok(false, `light #${link}: no canvas`); continue; }
    await c.evaluate(x => x.scrollIntoView({ block: 'center' })); await pg.waitForTimeout(500);
    const r = await pg.evaluate(async b64 => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + b64)).blob()); const cv = document.createElement('canvas'); cv.width = bm.width; cv.height = bm.height; const x = cv.getContext('2d'); x.drawImage(bm, 0, 0);
      const d = x.getImageData(2, 2, cv.width - 4, cv.height - 4).data, key = i => (d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | d[i + 2] >> 4, bg = key(0), h = new Map(); let px = 0;
      for (let i = 0; i < d.length; i += 4) { const k = key(i); h.set(k, (h.get(k) || 0) + 1); if (k !== bg) px++; } return { px, extra: [...h.entries()].filter(([k, v]) => k !== bg && v >= 10).length, bg: [d[0], d[1], d[2]] }; },
      (await c.screenshot({ style: ':has(> canvas) > :not(canvas) { visibility: hidden !important; }' })).toString('base64'));
    ok(r.px >= 200 && r.extra >= 2 && r.bg[0] > 180, `light #${link}: the picture is drawn on a light ground (${r.px} pixels besides the ground ${r.bg}, ${r.extra} colours)`);
  }
  await ctx.close(); }

// ---- 7b. the icon of a status badge keeps its size: no stylesheet of a page (such as a rule svg { width: 100% } of a picture container) may blow it up. On the Maxwell page the icon of the
// "script" row of the at-a-glance strip once measured 965 px; every drawn badge icon (svg.sb-ic) must measure its own width and height attribute (13 to 16 px) and never more than 24 px.
{ const seen = { n: 0, big: 0, off: 0, max: 0 };
  for (const w of [375, 1100]) for (const [q, label] of [['', 'dark'], ['theme=light', 'light']]) for (const prof of ['Physicist', 'Young Learner']) {
    const ctx = await b.newContext({ viewport: { width: w, height: 800 } });
    await ctx.addInitScript(a => { try { localStorage.setItem('atlas.audience', a); localStorage.setItem('atlas.lang', 'en'); } catch { /* ignore */ } }, prof);
    const pg = await ctx.newPage(); onErr(pg, `badge size ${w} ${label} ${prof}`);
    for (const link of ['maxwell/views', 'maxwell/charges', 'maxwell/ladders', 'atlas', 'equations/spin', 'furey/dictionary']) {
      await pg.goto(url(q, link)); await pg.waitForTimeout(450);
      const r = await pg.evaluate(() => { const out = []; for (const e of document.querySelectorAll('svg.sb-ic')) { if (!e.getClientRects().length) continue; const bb = e.getBoundingClientRect(); out.push([bb.width, bb.height, +e.getAttribute('width'), +e.getAttribute('height')]); } return out; });
      const tag = `badge size ${w} ${label} ${prof} #${link}`;
      ok(r.length > 0, `${tag}: some badge icons are drawn (${r.length})`);
      const big = r.filter(x => x[0] > 24 || x[1] > 24), off = r.filter(x => Math.abs(x[0] - x[2]) > 1 || Math.abs(x[1] - x[3]) > 1);
      ok(!big.length, `${tag}: no badge icon is larger than 24 px (largest ${Math.max(0, ...r.map(x => Math.max(x[0], x[1]))).toFixed(0)} px${big.length ? '; ' + JSON.stringify(big.slice(0, 3)) : ''})`);
      ok(!off.length, `${tag}: every badge icon measures its own width and height attribute${off.length ? ': ' + JSON.stringify(off.slice(0, 3)) : ''}`);
      seen.n += r.length; seen.big += big.length; seen.off += off.length; seen.max = Math.max(seen.max, ...r.map(x => Math.max(x[0], x[1])));
    }
    await ctx.close();
  }
  info(`badge icons measured: ${seen.n}, largest ${seen.max.toFixed(1)} px, ${seen.big} above 24 px, ${seen.off} off their attribute`); }

// ---- 8. the dark page, pixel for pixel. Screens at the top, a third, two thirds and the bottom of the page; the WebGL pictures turn by themselves, so
// they are masked (the same box in both); CSS animations are stopped.
const POS = [0, 1 / 3, 2 / 3, 1];
const screens = async (pg, prep) => { if (prep) await pg.evaluate(prep); await pg.waitForTimeout(120); const H = await pg.evaluate(() => document.documentElement.scrollHeight - innerHeight), out = [];
  for (const p of POS) { await pg.evaluate(y => window.scrollTo(0, y), Math.round(H * p)); await pg.waitForTimeout(80); out.push(await pg.screenshot({ animations: 'disabled', mask: [pg.locator('canvas')], maskColor: '#ff00ff' })); } return { H, out }; };
const same = (a, b2) => a.out.length === b2.out.length && a.H === b2.H && a.out.every((x, i) => x.equals(b2.out[i]));
const diffPx = async (pg, a, b2) => { let n = 0; for (let i = 0; i < a.out.length; i++) if (!a.out[i].equals(b2.out[i])) n += await pg.evaluate(async ([x, y]) => { const load = async s => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + s)).blob()); const c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height; const g = c.getContext('2d'); g.drawImage(bm, 0, 0); return g.getImageData(0, 0, c.width, c.height).data; }; const p = await load(x), q = await load(y); let k = 0; for (let j = 0; j < Math.min(p.length, q.length); j += 4) if (p[j] !== q[j] || p[j + 1] !== q[j + 1] || p[j + 2] !== q[j + 2]) k++; return k + Math.abs(p.length - q.length) / 4; }, [a.out[i].toString('base64'), b2.out[i].toString('base64')]); return n; };
// the page-1 clean-up of v10.2 removed two things on purpose: the "Presentation matrix" title and the disclosure printed in the hero (it stays in the footer)
const V101_REMOVED = '.controls .control-title > span:first-child, .atlas-hero > .disclosure { display: none !important; }';
const STRIP = () => { document.getElementById('atlas-theme')?.remove(); document.getElementById('atlas-reader-filter')?.remove(); document.documentElement.removeAttribute('data-theme'); document.querySelector('main')?.removeAttribute('data-rf'); };
let darkViews = 0, baseViews = 0;
for (const w of [375, 1100]) for (const prof of ['Young Learner', 'Physicist', 'Mathematician']) {
  const ctx = await b.newContext({ viewport: { width: w, height: 800 } });
  await ctx.addInitScript(a => { try { localStorage.setItem('atlas.audience', a); localStorage.setItem('atlas.lang', 'en'); } catch { /* ignore */ } }, prof);
  const pg = await ctx.newPage(); onErr(pg, `dark ${w} ${prof}`);
  for (const link of ['rule', 'atlas', 'equations']) {
    const tag = `dark ${w} ${prof} #${link}`;
    await pg.goto('about:blank'); await pg.goto(url('', link)); await pg.waitForTimeout(500);   // a new document each time (a change of the hash alone would keep the stripped page)
    ok(await theme(pg) === 'dark', `${tag}: data-theme is dark`);
    const mine = await screens(pg);
    if (!darkViews) { await pg.goto(url('theme=light', link)); await pg.waitForTimeout(500); const lit = await screens(pg); ok(!same(mine, lit), `${tag}: the comparison does see a difference where there is one (the same page in light mode differs)`); await pg.goto('about:blank'); await pg.goto(url('', link)); await pg.waitForTimeout(500); }
    const stripped = await screens(pg, STRIP);
    ok(same(mine, stripped), `${tag}: the page with the theme and filter rules is pixel-identical to the page without them (${same(mine, stripped) ? 'identical' : await diffPx(pg, mine, stripped) + ' pixels differ'})`); darkViews++;
    if (BASE) {
      const bp = await ctx.newPage(); await bp.goto(BASE + '#' + link); await bp.waitForTimeout(500); await bp.addStyleTag({ content: V101_REMOVED });
      const base = await screens(bp); await bp.close();
      const eq = same(mine, base);
      ok(eq, `${tag}: pixel-identical to the v10.1 build (${eq ? 'identical' : await diffPx(pg, mine, base) + ' pixels differ; heights ' + mine.H + ' / ' + base.H})`); baseViews++;
    }
  }
  await ctx.close();
}
info(`dark identity: ${darkViews} views against this build without the new rules` + (BASE ? `, ${baseViews} views against the v10.1 build ${process.env.ATLAS_BASE_DIST}` : '; SKIPPED against v10.1 (set ATLAS_BASE_DIST=<the v10.1 dist folder> to run it)'));

// ---- 9. light screenshots for a person to look at (whole pages), and the dark ones beside them
for (const w of [375, 1100]) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.audience', 'Physicist'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(); onErr(pg, `shots ${w}`);
  for (const link of ['rule', 'atlas', 'equations', 'conventions']) for (const [q, label] of [['theme=light', 'light'], ['', 'dark']]) {
    await pg.goto(url(q, link)); await pg.waitForTimeout(700);
    await pg.screenshot({ path: path.join(OUT, `${link}_${w}_${label}.png`), fullPage: true, animations: 'disabled' });
  }
  await ctx.close();
}
info('screenshots: ' + OUT);
await b.close();
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL THEME UI TESTS PASS'); process.exit(bad ? 1 : 0);
