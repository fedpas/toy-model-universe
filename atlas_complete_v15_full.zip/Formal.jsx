// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Fold } from './Fold.jsx';
import { FOLD } from './audienceCopy.js';

// The Young Learner pages carry no formulas, tables of symbols or technical vocabulary, except very easy arithmetic (a small sum such as 5 XOR 3 = 6,
// a count such as "four pairs"). Whatever is formal on a page is wrapped in <Formal>: the Physicist and the Mathematician see it as before; the
// Young Learner sees `plain` (a sentence or two in plain words, or nothing) and, unless fold={false}, a closed fold "For older readers" that holds
// the formal content, so nothing is taken away and a curious reader can open it. test_yl_ui.mjs checks every page, tab and language.
//   <Formal profile={profile} lang={lang} plain={<p>…</p>}> …formulas, tables, derivations… </Formal>
export const isLearner = profile => profile === 'Young Learner';
export function Formal({ profile, lang, plain = null, fold = true, title, children }) {
  if (!isLearner(profile)) return <>{children}</>;
  return <>{plain}{fold ? <Fold title={title || (FOLD[lang] || FOLD.en).older} open={false}>{children}</Fold> : null}</>;
}
// a plain-words alternative that only the Young Learner sees (a heading, a caption, a label); everyone else gets `formal`
export const Plain = ({ profile, plain, formal }) => (isLearner(profile) ? plain : formal);
