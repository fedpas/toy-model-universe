// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { fc } from './fureyCopy.js';
import { Tx } from './MathText.jsx';
import { isLearner } from './Formal.jsx';
import { Pts, ScriptBox } from './LensKit.jsx';
import { Head, Sec, Older, statements, isM } from './FureyKit.jsx';
import { Scoreboard, CellTable } from './FureyWidgets2.jsx';
import { FUREY_PAPERS_PY } from './fureyPapersSelfcheckSource.js';
import { THREEGEN_PY } from './threegenSelfcheckSource.js';

// Tab "What may help": what the page can give back to Furey and to anyone who checks her work. The five results in the form most likely to help, the questions our numbers
// leave to her, the scoreboard of the 30 checks, and everything to take away: the table of the 20 cells of Fig. 1 (CSV), the data (JSON) and the two check scripts.
// Words: fureyCopy.js (help.*); numbers: fureyPapersData.js.
export default function FureyHelp({ lang = 'en', profile = 'Young Learner' }) {
  const L = lang === 'it' ? 'it' : 'en', c = fc(L).help, W = { lang: L, profile }, yl = isLearner(profile), M = isM(profile), s = c.secs;
  const take = <><CellTable lang={L} />
    <div className="fy-box"><ScriptBox lang={L} file={c.w.dl.file} text={FUREY_PAPERS_PY} /><p className="fy-mono">{c.w.dl.cmd}</p></div>
    <div className="fy-box"><ScriptBox lang={L} file={c.w.dl.file2} text={THREEGEN_PY} /><p className="fy-mono">{c.w.dl.cmd2}</p></div></>;
  return <section className="ln fy" id="help" aria-labelledby="help-h" data-tab="help"><Head lang={L} profile={profile} id="help" c={c} hid="help-h" />
    <Sec lang={L} profile={profile} id="fy-results" s={s.results} />
    <div className="fw-sec" id="fy-questions" data-sec="fy-questions"><h3><Tx>{yl ? s.questions.hy : s.questions.h}</Tx></h3>
      {yl ? <><div className="fy-yl">{s.questions.yl.map((t, i) => <p key={i}><Tx>{t}</Tx></p>)}</div><ol className="fy-q" data-questions={c.qy.length}>{c.qy.map(q => <li key={q}><Tx>{q}</Tx></li>)}</ol></>
        : <Pts items={statements(s.questions, M)} lang={L} />}</div>
    <Sec lang={L} profile={profile} id="fy-score" s={s.score}><Scoreboard {...W} /></Sec>
    <Sec lang={L} profile={profile} id="fy-take" s={s.take}>{yl ? null : take}</Sec>
    <Older lang={L} profile={profile} secs={[['results', s.results], ['questions', s.questions], ['score', s.score], ['take', s.take]]} extra={take} />
  </section>;
}
