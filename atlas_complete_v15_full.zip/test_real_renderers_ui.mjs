// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Every other browser test runs on stand-ins for react-katex, streamdown and @streamdown/math (harness/stubs): they print the TeX source and the Markdown as plain text (audit G40). This test builds the app WITHOUT
// the stand-ins (sh build.sh --real, into dist_real/) and asks the Ask page, with the chat route faked, for an answer that holds a formula, a display formula, a table, links to
// another host (https, http, javascript:), images (remote, data:, raw <img>) and a script tag. What it asserts is the page's policy (lib/answerFilter.js, App.jsx ChatResponse):
//   the formulas are typeset by KaTeX (.katex), the table is a table; no image is rendered or requested; nothing of the other host is requested; the javascript: and the http:
//   links are not live <a href> (their words show as text); the https link MAY be live (it is allowed; this test does not require either form); the script tag does nothing.
// It needs react-katex, streamdown and @streamdown/math in node_modules (the packages of your repository). Exit 77 (skipped, with what is missing) when they are not there.
// NOT YET RUN AGAINST THE REAL PACKAGES: they could not be installed where this package was made (see BUILDING.md). Only the mechanics mode below has run. The policy is enforced
// on the text before the renderer (so it holds with the stand-ins too); what only the real path can show is the typesetting and the table, and that the renderer adds no link or image of its own.
// RR_MECHANICS=1 runs only the plumbing (build skipped, the stand-in build in dist/, the renderer assertions off) to check the test itself.   Run: node test_real_renderers_ui.mjs
import { createRequire } from 'node:module'; import { execFileSync } from 'node:child_process'; import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { PKG, PKG_DIST } from './paths.mjs';
const MECH = !!process.env.RR_MECHANICS, req = createRequire(path.join(PKG, 'package.json'));
const missing = ['react-katex', 'streamdown', '@streamdown/math'].filter(p => { try { req.resolve(p + '/package.json'); return false; } catch (e) { try { req.resolve(p); return false; } catch { return true; } } });
if (missing.length && !MECH) { console.log('SKIPPED: not installed here: ' + missing.join(', ') + ' (npm install them in your repository, then: node test_real_renderers_ui.mjs)'); process.exit(77); }
let DIST = PKG_DIST;
if (!MECH) { try { execFileSync('sh', [path.join(PKG, 'build.sh'), '--real'], { cwd: PKG, stdio: 'pipe' }); } catch (e) { console.log('FAIL: build.sh --real failed\n' + String(e.stderr || e.message).slice(0, 600)); process.exit(1); } DIST = path.join(PKG, 'dist_real'); }
const ANSWER = 'Euler: $e^{i\\pi}+1=0$ and\n\n$$\\int_0^1 x^2\\,dx=\\tfrac13$$\n\n| col a | col b |\n|---|---|\n| cell 1 | cell 2 |\n\n[a link](https://other-host.invalid/x) [plain words](http://other-host.invalid/h) [run words](javascript:window.__pwn=2) ![an image](https://other-host.invalid/i.png) ![a data image](data:image/png;base64,iVBORw0KGgo=) <img src="https://other-host.invalid/raw.png" alt="raw words">\n\n<script>window.__pwn = 1</script>\n\nEnd of answer.';
const seen = [], srv = http.createServer((q, r) => { const f = path.join(DIST, q.url.split('?')[0].replace(/^\/+/, '') || 'app.html');
  fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : f.endsWith('.css') ? 'text/css' : 'text/html' }); r.end(d); }); });
await new Promise(r => srv.listen(0, r));
const b = await chromium.launch(), errs = []; let n = 0; const ok = (c, m) => { n++; if (!c) errs.push(m); };
const pg = await b.newPage({ viewport: { width: 1100, height: 900 } });
pg.on('pageerror', e => errs.push('page error: ' + e.message)); pg.on('request', q => { if (/other-host\.invalid/.test(q.url())) seen.push(q.url()); });
await pg.route('**/api/chat', r => r.fulfill({ status: 200, contentType: 'text/event-stream', body: [{ type: 'content_block_delta', delta: { text: ANSWER } }].map(p => `data: ${JSON.stringify(p)}\n\n`).join('') }));
await pg.route(/other-host\.invalid/, r => r.abort());
await pg.goto(`http://localhost:${srv.address().port}/app.html#ask`); await pg.waitForTimeout(400);
await pg.locator('.chat-composer textarea').fill('Show me a formula and a table.'); await pg.locator('.ask-button').click();
await pg.waitForFunction(() => /End of answer/.test(document.querySelector('article.answer')?.textContent || ''), null, { timeout: 15000 }).catch(() => {});
await pg.waitForTimeout(500);
const r = await pg.evaluate(() => { const a = document.querySelector('article.answer'); return { text: a ? a.textContent : '', katex: a ? a.querySelectorAll('.katex').length : 0, display: a ? a.querySelectorAll('.katex-display').length : 0, tables: a ? a.querySelectorAll('table').length : 0,
  cells: a ? [...a.querySelectorAll('td')].map(x => x.textContent.trim()) : [], links: a ? [...a.querySelectorAll('a[href]')].map(x => x.getAttribute('href')) : [], imgs: a ? [...a.querySelectorAll('img[src]')].map(x => x.getAttribute('src')) : [], scripts: a ? a.querySelectorAll('script').length : 0, pwn: window.__pwn }; });
ok(/End of answer/.test(r.text) && /Euler/.test(r.text), 'the answer arrived and is shown');
ok(r.pwn === undefined && r.scripts === 0, 'a <script> in the answer does nothing and is not in the page');
ok(seen.length === 0, 'nothing of the other host is requested: ' + seen.join(' '));
ok(r.imgs.length === 0, 'no image is rendered (remote, data: or raw <img>): ' + JSON.stringify(r.imgs));
ok(!r.links.some(h => /^\s*(javascript|data|vbscript):/i.test(h) || /^\s*http:/i.test(h)), 'no javascript:, data: or http: link is live: ' + JSON.stringify(r.links));
ok(r.links.every(h => /^https:\/\//i.test(h) || /^#/.test(h)), 'every live link goes to https:// (an https link may be live): ' + JSON.stringify(r.links));
ok(/plain words/.test(r.text) && /run words/.test(r.text) && /an image/.test(r.text) && /raw words/.test(r.text), 'the words of the refused links and images show as text');
ok(!/javascript:|http:\/\/other-host|i\.png|raw\.png|data:image/.test(r.text), 'no refused address shows in the answer text (the filter ran): ' + JSON.stringify(r.text.slice(0, 400)));
if (!MECH) {
  ok(r.katex >= 2, `KaTeX typesets the inline and the display formula (.katex found ${r.katex})`); ok(r.display >= 1, `the $$ formula is a display formula (.katex-display found ${r.display})`);
  ok(!/e\^\{i\\pi\}/.test(r.text.replace(/\s/g, '')) || r.katex >= 2, 'the TeX source is not left as plain text');
  ok(r.tables === 1 && r.cells.join('|') === 'cell 1|cell 2', `the table renders as a table with its cells (tables ${r.tables}: ${r.cells.join('|')})`);
}
await b.close(); srv.close();
console.log(errs.length ? 'FAIL\n' + errs.join('\n') : `REAL RENDERERS UI OK${MECH ? ' (mechanics only)' : ''} (${n} checks)`); process.exit(errs.length ? 1 : 0);
