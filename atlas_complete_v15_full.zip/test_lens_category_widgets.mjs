// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The widgets of the category lens (step 18), without a browser: the engine (categoryEngine.js) against the stored output of their exact script
// (selfcheck/reports/lens_cat_check.py, checks catw·P1 ... catw·P6, via categoryWidgetData.js) for every number the widgets show; the script itself runs and
// passes and its stored data is current; the download mirror is the script byte for byte; the copy (categoryWidgetsCopy.js) is the same in English and Italian,
// the Young Learner's words carry no formula and no jargon, every tag is one of the four, no retired wording, every cited check id exists in a shipped script;
// the claims rows (claimsLocators_lncw.json, LNC-101 ...) point at exactly the tagged lines. selfcheck/regen_lens_category_widgets.sh rebuilds the data.
// Run: node test_lens_category_widgets.mjs   (needs python3 for the script)
import fs from 'node:fs'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
import * as E from './categoryEngine.js';
import STORED from './categoryWidgetData.js';
import { CWC, CHECK_IDS } from './categoryWidgetsCopy.js';
import { LENS_CAT_PY } from './categoryWidgetsSelfcheckSource.js';
let n = 0, bad = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8'), J = JSON.stringify, SCRIPT = 'selfcheck/reports/lens_cat_check.py', FIX = 'selfcheck/reports/lens_cat_check.json';

// ---- 1. the script runs, passes, and its stored data is the data the widgets embed
{ const r = spawnSync('python3', [SCRIPT, '--compare', FIX], { cwd: PKG, encoding: 'utf8', timeout: 100000 });
  ok(r.status === 0 && /checks: 6 ok, 0 failed/.test(r.stdout) && /stored data == rebuilt data/.test(r.stdout), 'lens_cat_check.py passes (6 checks) and the stored json is what it rebuilds: ' + (r.stdout || '').slice(-200) + (r.stderr || '').slice(-200));
  ok(['P1', 'P2', 'P3', 'P4', 'P5', 'P6'].every(id => new RegExp('^ok   ' + id + ':', 'm').test(r.stdout)), 'each id P1 ... P6 prints its own ok line');
  ok(J(JSON.parse(rd(FIX))) === J(STORED), 'categoryWidgetData.js holds exactly selfcheck/reports/lens_cat_check.json');
  ok(LENS_CAT_PY === rd(SCRIPT), 'categoryWidgetsSelfcheckSource.js is the script, byte for byte');
  const regen = rd('selfcheck/regen_lens_category_widgets.sh');
  ok(/lens_cat_check\.py --write/.test(regen) && /lens_cat_check\.py --compare/.test(regen) && /categoryWidgetData\.js/.test(regen) && /categoryWidgetsSelfcheckSource\.js/.test(regen), 'regen_lens_category_widgets.sh writes, compares and regenerates both modules');
  ok(rd(SCRIPT).split('\n').length <= 500 && !/^\s*(import|from)\s+(numpy|scipy|sympy)/m.test(rd(SCRIPT)), 'the script is at most 500 lines and needs the standard library only'); }

// ---- 2. the engine against the stored data: every number the widgets show
{ let cnt = 0;
  for (const [k, v] of Object.entries(STORED.P3)) { const [p, q, r] = k.split(',').map(Number), c = E.labelCard(E.sigOf(p, q, r)); cnt++;
    ok(c.n === v.n && c.dim === v.dim && c.J === v.J && J(c.layers) === J(v.layers) && c.loewy === v.loewy && c.sc === v.sc && c.centre === v.centre && J(c.quotient) === J(v.quotient) && c.type === v.type && c.clock === v.clock, `CW1 card ${k}: live ${J([c.J, c.layers, c.loewy, c.sc, c.centre, c.type])} = stored ${J([v.J, v.layers, v.loewy, v.sc, v.centre, v.type])}`);
    ok(c.J === c.t2.J && J(c.layers) === J(c.t2.layers) && c.loewy === c.t2.loewy && c.sc === c.t2.sc, `CW1 card ${k}: live = what T2 says`); }
  ok(cnt === 84, 'the stored label-0 cards cover the 84 signatures with n <= 6: ' + cnt);
  for (const nn of [7, 8]) for (const [p, q, r] of E.triples(nn)) { const c = E.labelCard(E.sigOf(p, q, r)); ok(c.J === c.t2.J && J(c.layers) === J(c.t2.layers) && c.loewy === c.t2.loewy && c.sc === c.t2.sc, `CW1 beyond the stored range, (${p},${q},${r}): live = T2`); }
  for (const [k, v] of Object.entries(STORED.P4)) { const [p, q, r] = k.split(',').map(Number), f = E.frobenius(E.sigOf(p, q, r)), m = p + q + r;
    ok(f.supp && f.rankLam === v.rank_lam && f.rank0 === v.rank_0 && f.rankEF === v.rank_ef && f.omega2 === v.omega2 && f.reach === v.reach && J(f.conj) === J(v.conj) && f.conjInJ === v.conj_in_J && f.fair === v.fair && f.cert === v.cert, `CW2 ${k}: live ${J([f.rankLam, f.rank0, f.rankEF, f.omega2, f.reach, f.conj, f.cert])} = stored`);
    ok(f.anti === STORED.P4_anti[m] && f.nak === STORED.P4_nakayama[m], `CW2 ${k}: antidiagonal and Nakayama signs = stored for n = ${m}`);
    ok(f.fair === (m % 2 === 1 || r === 0), `CW2 ${k}: fair both ways iff n odd or r = 0`); }
  ok(J(STORED.P4['3,0,1'].conj) === J([8, 15]) && STORED.P4['3,0,1'].conj_in_J && !STORED.P4['3,0,1'].fair, 'Cl(3,0,1): the conjugators of the grade involution are e4 and e1234, both in J; no symmetric form');
  for (const row of STORED.P2) { const eps = E.sigOf(row.p, row.q, row.r), h = E.halve(eps);
    ok(h.ok === row.halves, `CW3 halve (${row.p},${row.q},${row.r}): ${h.ok} = stored ${row.halves}`);
    for (const [kind, tg] of Object.entries(row.via)) { const hv = kind === 'null' ? h : E.halveVia(eps, kind === 'plus' ? 0 : row.p); ok(hv.ok && J([hv.pqr.p, hv.pqr.q, hv.pqr.r]) === J(tg), `CW3 halve via ${kind}, (${row.p},${row.q},${row.r}): ${J(hv.pqr)} = stored ${J(tg)}`); }
    if (row.lam_even) ok(J(E.lamEven(row.r)) === J(row.lam_even), `CW3 the even part of the exterior algebra on ${row.r} generators = stored`); }
  ok(STORED.P2.filter(x => !x.halves).map(x => `${x.p},${x.q},${x.r}`).join(' ') === '0,0,3 0,0,4 0,0,5', 'halving fails exactly at (0,0,3), (0,0,4), (0,0,5) in the stored range');
  const s = E.restrictSurvey(4); ok(s.pairs === STORED.P1.pairs && s.homs === STORED.P1.homs && s.agree === STORED.P1.agree && s.agree === s.pairs, `CW3 restrict to a face, every choice with n <= 4: ${J(s)} = stored ${J(STORED.P1)}`);
  for (const row of STORED.P5) { const l = E.ladderRung(row.n); ok(['det', 'type', 'q1', 'q0', 'rad', 'cl_q1', 'cl_q0', 'cl_rad'].every(k => l[k] === row[k]) && J(l.inertia) === J(row.inertia), `CW4 E_${row.n}: live ${J([l.det, l.inertia, l.type, l.q1, l.cl_q1])} = stored ${J([row.det, row.inertia, row.type, row.q1, row.cl_q1])}`); }
  ok(STORED.P5.length === 18 && STORED.P5[0].n === 3 && STORED.P5.at(-1).n === 20, 'the stored ladder covers n = 3 ... 20');
  ok(J(E.ladderRung(9).marks) === J(STORED.marks9) && J(STORED.marks9) === J([3, 2, 4, 6, 5, 4, 3, 2, 1]), 'CW4 the null root of E9: marks (3; 2,4,6,5,4,3,2,1) live = stored');
  const e9 = E.e9mod2(); ok(J(e9.marks_mod2) === J(STORED.P6.marks_mod2) && J(e9.radical) === J(STORED.P6.radical) && J(e9.cl_radical) === J(STORED.P6.cl_radical) && e9.q === 0 && e9.Q === 0, 'CW4 the E9 null root mod 2 and the two radicals = stored (catw P6)');
  const pz = E.pairedZero(); ok(J(pz.uu) === '{}' && J(pz.vv) === '{}' && J(pz.uv) === J({ 0: 2, 3: -2 }) && J(pz.vu) === J({ 0: 2, 3: 2 }) && J(pz.sum) === J({ 0: 4 }), 'CW5 paired zero: u² = v² = 0, uv = 2 − 2e12, vu = 2 + 2e12, uv + vu = 4');
  let mixOK = true; for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) { const v = E.mixSquare(a, b)[0] || 0; if (v !== a * a - b * b) mixOK = false; } ok(mixOK, 'CW5 the mix a e1 + b e2 squares to a² − b² for every a, b in −3 ... 3');
  ok(E.loneZero([1, -1, 0]).every(x => J(x.sum) === '{}'), 'CW5 the lone zero z of Cl(1,1,1): z e_i + e_i z = 0 for every generator');
  ok(STORED.P3['1,1,0'].J === 0 && STORED.P3['0,0,2'].J === 3 && STORED.P3['1,1,1'].J === 4, 'CW5 radicals 0, 3, 4 (stored)');
  for (const eps of [[1, 1, 0], [0, 0, 1], [1, -1, 0, 0], [0, 0, 0], [1, 0, 0, 0, 0]]) { const r = E.pqrOf(eps).r, z = E.trayAllZero(eps, r + 1); ok(z.tried > 0 && z.zero === z.tried, `CW1 tray: every choice of ${r + 1} corners with a zero switch multiplies to nothing (${J(eps)}: ${z.zero}/${z.tried})`); }
  ok(E.trayProduct([1, 2], [1, 1]).join() === '3,1' && E.trayProduct([4, 5], [1, 1, 0])[1] === 0, 'CW1 tray products: e1 e2 = e12, e3 e13 = 0 with e3 null');
  for (const [e1, e2] of [[[1, -1], [0]], [[0, 0], [1, -1]], [[1], [-1, 0, 1]]]) { const j = E.join(e1, e2); ok(j.koszul && j.clock === j.clockSum && j.pairs === (1 << e1.length) ** 2 * (1 << e2.length) ** 2, `CW3 double ${J(e1)} with ${J(e2)}: Koszul sign on every label pair, clocks add`); }
  for (let m = 0; m <= 6; m++) ok(E.complementReverses(m), `CW3 complement reverses inclusion, n = ${m}`);
  ok(J(E.halve(E.sigOf(1, 3, 0), 1).pqr) === J({ p: 1, q: 2, r: 0 }) && J(E.halve(E.sigOf(1, 3, 0), 0).pqr) === J({ p: 3, q: 0, r: 0 }), 'CW3 halve Cl(1,3): via a generator of square −1 Cl(1,2), via the one of square +1 Cl(3,0)');
  const f13 = E.restrict(E.sigOf(1, 0, 2), 0b001); ok(f13.iota && f13.pi && f13.outsideNull && f13.quotient, 'CW3 restrict Cl(1,0,2) to its non-null generator: a homomorphism onto Cl/J');
  const cc = E.countAnticommuting(); ok(cc.odd === 128 && cc.total === 4096, `CW6 sign the cube: ${cc.odd} of ${cc.total} sign assignments make every square anticommute (cat K1d: 128)`);
  const RS = E.ruleSigns(); ok(E.squaresOdd(RS).every(Boolean) && JSON.stringify(E.gaugeOf(RS)) === '[]', 'CW6 the bit-rule signs: every square anticommutes, no corner flipped');
  ok(JSON.stringify(E.gaugeOf(E.flipCorner(E.flipCorner(RS, 3), 6))) === '[3,6]', 'CW6 the gauge recovers the flipped corners 011 and 110');
  { const one = { ...RS }; one[E.edgeKey(0, 0)] *= -1; ok(E.squaresOdd(one).filter(Boolean).length === 4 && E.gaugeOf(one) === null, 'CW6 one edge flipped: four squares still anticommute, no gauge'); }
  ok(E.cubeEdges().every(([a, i]) => RS[E.edgeKey(a, i)] === E.bladeMulSign(1 << i, a)), 'CW6 the edge sign is the bit-rule sign of e_i e_a in Cl(3,0) (cat K1b)');
  const f2 = E.restrict(E.sigOf(1, 1, 0), 0b01); ok(f2.iota && !f2.pi && !f2.outsideNull, 'CW3 restrict Cl(1,1) to e1: iota is a homomorphism, pi is not (e2 is not null)'); }

// ---- 3. the copy: English = Italian in shape; the Young Learner's words; tags; retired wording; check ids
const SAMPLE = [2, 4, 3, 1, 0];
const strings = (o, out = [], p = []) => { if (typeof o === 'string') out.push([p.join('.'), o]); else if (typeof o === 'function') { for (const args of [SAMPLE, [1, 8, 2, 0], [0, 0, 0, 1], [-1, 3, 1, 2], [9, 8, 1, 0], [3, 1, 3, 0]]) out.push([p.join('.') + '()', String(o(...args))]); } else if (Array.isArray(o)) o.forEach((x, i) => strings(x, out, [...p, i])); else if (o && typeof o === 'object') for (const k of Object.keys(o)) strings(o[k], out, [...p, k]); return out; };
const shape = o => (typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o);
ok(J(shape(CWC.en)) === J(shape(CWC.it)), 'the English and the Italian copy have the same keys, lists and functions');
for (const w of ['cw1', 'cw2', 'cw3', 'cw4', 'cw5']) for (const v of ['yl', 'pm']) for (const part of ['caps', 'uses']) { const a = CWC.en[w][v][part], b = CWC.it[w][v][part]; if (!a) continue; ok(a.every(([f], i) => f === b[i][0]), `${w}.${v}.${part}: the Italian lines carry the same tags as the English ones`); }
const FOUR = ['standard', 'checked', 'ours', 'open'], tagged = [];
for (const L of ['en', 'it']) for (const w of ['cw1', 'cw2', 'cw3', 'cw4', 'cw5']) for (const v of ['yl', 'pm']) for (const part of ['caps', 'uses']) for (const [f, txt] of CWC[L][w][v][part] || []) tagged.push({ L, w, v, part, flags: f.split(' '), txt });
const tagged6 = []; for (const L of ['en', 'it']) for (const [v, part] of [['yl', 'caps'], ['pm', 'caps'], ['pm', 'capsM']]) for (const [f, txt] of CWC[L].cw6[v][part]) tagged6.push({ L, w: 'cw6', v, part, flags: f.split(' '), txt });
ok([...tagged, ...tagged6].every(x => x.flags.length && x.flags.every(f => FOUR.includes(f)) && new Set(x.flags).size === x.flags.length), 'every tagged line carries only the four tags, each once');
ok(['caps', 'capsM'].every(part => ['yl', 'pm'].every(v => !CWC.en.cw6[v][part] || CWC.en.cw6[v][part].every(([f], i) => f === CWC.it.cw6[v][part][i][0]))), 'cw6: the Italian lines carry the same tags as the English ones');
ok(tagged.filter(x => x.flags.includes('ours')).every(x => !/\bderiv|deriva/i.test(x.txt)), 'a line tagged ours never says derived');
ok(tagged.length === 72, 'thirty-six tagged lines in each language: ' + tagged.length);
// the Young Learner: the formula and jargon lists of test_yl_ui.mjs, and the words the chapter's rules (DECISIONS X0) keep out of the plain voice
const Y = rd('test_yl_ui.mjs'), SYM = new RegExp(/^const SYMBOLS = \/(.+)\/;$/m.exec(Y)[1], 'u'), JAR = new RegExp(/^const JARGON = \/(.+)\/i;$/m.exec(Y)[1], 'i');
const PLAIN_NO = /algebra|radical|radicale|Frobenius|Jordan|Nakayama|Loewy|Cartan|Dynkin|Kac\b|Lorentz|hyperbol|iperbol|affine|nilpot|quotient|quozient|homomorph|omomorf|isomorf|signature|segnatura|generator|generatore|functor|funtore|catw|\bcat·|Thm\b|label 0|etichetta 0|E_|Cl\(/i;
const clean = t => t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' ');
for (const L of ['en', 'it']) { const P = [...strings(CWC[L].sw, [], ['sw']), ...strings(CWC[L].badge, [], ['badge']), ...strings(CWC[L].badgeY, [], ['badgeY']), ...['cw1', 'cw2', 'cw3', 'cw4', 'cw5', 'cw6'].flatMap(w => strings(CWC[L][w].yl, [], [w, 'yl']))];
  const hits = P.filter(([, s]) => SYM.test(clean(s)) || JAR.test(clean(s)) || PLAIN_NO.test(s));
  ok(P.length > 100 && hits.length === 0, `${L}: the Young Learner's ${P.length} strings carry no formula, no jargon and no technical word: ` + hits.slice(0, 4).map(([p, s]) => p + ': ' + s.slice(0, 70)).join(' | '));
  const y = CWC[L].badgeY; ok(y && ['live', 'stored', 'match', 'differ', 'liveTip', 'storedTip', 'beyond'].every(k => typeof y[k] === 'string' && y[k].trim()) && !/live|stored|\.py|selfcheck|=|≠/.test(Object.values(y).join(' | ')) && Object.values(y).join() === Object.values(CWC.en.badgeY).join(), `${L}: the badge words and tips of the Young Learner are plain words, no file name: ${JSON.stringify(y).slice(0, 120)}`); }
// retired wording (DECISIONS §1, X10), in the copy and in the widgets file
const ALL = [...strings(CWC.en), ...strings(CWC.it)].map(([, s]) => s), JSX = rd('CategoryWidgets.jsx');
const RETIRED = [/\bconserved\b|\bconservat[ao]\b/i, /\bexplains?\b|\bspiega\b/i, /Born rule is the Frobenius form/i, /antiparticle|antiparticella/i, /radical is a face|il radicale è una faccia/i, /with only null generators|con soli generatori nulli/i, /three functors|tre funtori/i, /Hodge star = XOR|XOR with 1…1/i, /ten classes|dieci classi|\binert\b|\bramified\b|ramificat|Golay|Three 8s/i, /particle to/i, /\bderived\b/i];
for (const re of RETIRED) ok(!ALL.some(s => re.test(s)) && !re.test(JSX), 'no retired wording ' + re);
ok(ALL.filter(s => /Hodge/.test(s)).every(s => /only without null generators|solo senza generatori nulli/.test(s)), 'Hodge appears only as "a metric Hodge star only without null generators"');
ok(tagged.filter(x => /boundary|confine|border\b/i.test(x.txt)).every(x => x.flags.join() === 'ours'), '"boundary" / "border" only on a line tagged ours');
ok(ALL.filter(s => /label 0|etichetta 0/.test(s)).every(s => /label 0 = a generator with square 0|etichetta 0 = un generatore di quadrato 0|label-0 card|dell’etichetta 0/.test(s)), '"label 0" is always the generator with square 0, glossed at first use');
// every check id the widgets cite exists in a shipped script (and Thm T# in researchers_checks)
const SRC = { cat: rd('selfcheck/reports/cat_check.py'), bridge: rd('selfcheck/reports/bridge_check.py'), catw: rd(SCRIPT) };
const ids = new Set(); const expand = (ns, a, b) => { const m1 = /^([A-Z])(\d+)([a-z]?)$/.exec(a), m2 = /^([A-Z]?)(\d+)([a-z]?)$/.exec(b); if (!m1 || !m2) return [a]; if (m1[3] || m2[3]) { const out = []; for (let c = m1[3].charCodeAt(0); c <= m2[3].charCodeAt(0); c++) out.push(m1[1] + m1[2] + String.fromCharCode(c)); return out; } const o = []; for (let k = +m1[2]; k <= +m2[2]; k++) o.push(m1[1] + k); return o; };
for (const s of [...ALL, ...Object.values(CHECK_IDS).flat()]) for (const m of s.matchAll(/\b(cat|bridge|catw)·([A-Z]\d+[a-z]?)(?:[–-]([A-Z]?\d+[a-z]?))?/g)) for (const id of (m[3] ? expand(m[1], m[2], m[3]) : [m[2]])) ids.add(m[1] + '·' + id);
for (const id of ids) { const [ns, x] = id.split('·'); ok(new RegExp(`chk\\('${x}'`).test(SRC[ns]), `check id ${id} is a check of the shipped ${ns === 'catw' ? 'lens_cat_check.py' : ns + '_check.py'}`); }
ok(ids.size >= 20, 'the widgets cite ' + ids.size + ' namespaced check ids: ' + [...ids].join(' '));
for (const s of [...ALL, ...Object.values(CHECK_IDS).flat()]) for (const m of s.matchAll(/Thm T(\d+)/g)) ok(fs.existsSync(path.join(PKG, 'researchers_checks', `check_T${m[1]}.py`)), `Thm T${m[1]} has its check script`);

// ---- 4. the claims rows: one per tagged line, English and Italian, pointing at the copy
{ const rows = JSON.parse(rd('claimsLocators_lncw.json'));
  const en = [...tagged.filter(x => x.L === 'en'), ...(rows.length > 36 ? tagged6.filter(x => x.L === 'en') : [])];
  ok((rows.length === 36 || rows.length === en.length) && rows.every((r, i) => r.id === 'LNC-' + (101 + i)), `claimsLocators_lncw.json: rows LNC-101 ... in order (36, or ${36 + tagged6.length / 2} with CW6): ${rows.length}`);
  ok(rows.every((r, i) => { const t = en[i], l = r.lines[0], P = l.en.text_loc.path; return r.lines.length === 1 && P[2] === t.w && P[3] === t.v && P[4] === t.part && J(l.flags) === J(t.flags) && J(r.flagsSpec) === J(t.flags) && J(l.it.text_loc.path) === J(['CWC', 'it', ...P.slice(2)]); }), 'each row points at its tagged line (EN and IT), with the same flags');
  ok(rows.every(r => r.group === 'LNC' && r.groupName === 'Category lens (step 18)' && r.shown_on.page === 'lenses' && r.shown_on.tab === 'category' && J(r.visible_to) === J(r.lines[0].en.text_loc.path[3] === 'yl' ? ['Young Learner'] : r.lines[0].en.text_loc.path[4] === 'capsM' ? ['Mathematician'] : ['Physicist', 'Mathematician'])), 'group, page, tab and audience of every row');
  const known = JSON.parse(rd('claimsLocators.json')), LENS = new Set(known.flatMap(r => r.lens || []));
  ok(rows.every(r => r.lens.every(x => LENS.has(x))), 'only lens codes already used in claimsLocators.json'); }

// ---- 5. files: header, no e-mail address (the address pattern of test_license.mjs; the link scheme is spelled in two pieces so that this file does not hold it)
const MAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/, MAILTO = 'mail' + 'to:';
for (const f of ['CategoryWidgets.jsx', 'categoryEngine.js', 'categoryWidgetsCopy.js', 'categoryWidgetData.js', SCRIPT, 'selfcheck/regen_lens_category_widgets.sh', 'test_lens_category_widgets.mjs', 'test_lens_category_widgets_ui.mjs']) {
  const t = rd(f); ok(t.split('\n').slice(0, 6).join('\n').includes('SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0'), f + ': SPDX header');
  ok(!MAIL.test(t) && !t.includes(MAILTO), f + ': no e-mail address'); }
for (const f of ['claimsLocators_lncw.json', 'categoryWidgetsSelfcheckSource.js', FIX]) ok(!MAIL.test(rd(f)) && !rd(f).includes(MAILTO), f + ': no e-mail address');
console.log(`${n} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL CATEGORY WIDGET TESTS PASS'); process.exit(bad ? 1 : 0);
