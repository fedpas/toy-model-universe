// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { fc } from './fureyCopy.js';
import { Head, Sec, Older } from './FureyKit.jsx';
import { Board } from './FureyWidgets2.jsx';
import { Ledger, Composites, Room, Whole } from './FureyWidgets2.jsx';

// Tab "Three generations": Fig. 1 of the 2026 paper as a board you can click (every label against the gauge numbers of its cell), the count of complete Standard Model sets
// with one label per cell and with every cell doubled, the missing irreps as products of the extras, the room that three complete sets need, and where the 128 complex
// dimensions go. The words are fureyCopy.js (threegen.secs); the numbers are fureyPapersData.js (furey_papers_check.py) and threegenData.js (threegen_selfcheck.py).
const ORDER = [['board', Board], ['count', Ledger], ['composite', Composites], ['room', Room], ['whole', Whole]];
export default function ThreeGenSection({ lang = 'en', profile = 'Young Learner' }) {
  const L = lang === 'it' ? 'it' : 'en', c = fc(L).threegen, W = { lang: L, profile };
  return <section className="ln fy" id="threegen" aria-labelledby="tg-h" data-tab="threegen"><Head lang={L} profile={profile} id="threegen" c={c} hid="tg-h" />
    {ORDER.map(([k, Wd]) => <Sec key={k} lang={L} profile={profile} id={'fy-' + k} s={c.secs[k]}><Wd {...W} /></Sec>)}
    <Older lang={L} profile={profile} secs={ORDER.map(([k]) => [k, c.secs[k]])} />
  </section>;
}
