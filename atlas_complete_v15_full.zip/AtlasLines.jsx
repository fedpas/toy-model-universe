// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { ATLAS_LINES, LINE_FLAGS } from './atlasLines.js';
import { STORY } from './storyCopy.js';
import { Tx } from './MathText.jsx';
import { StatusBadge } from './StatusBadge.jsx';

// The lines of the active atlas card: a theorem line (standard / checked) and a reading line (ours / open), each with its own tags,
// drawn like the claim lines of the other pages (.eq-pt rows with the shared .tag classes, so the reader filter of the page treats them alike).
// The Young Learner never sees them: the plain card of ylAtlas.js stays in their place (App.jsx). Data: atlasLines.js.
const CSS = `.atlas-lines{margin:.6em 0}.atlas-lines .atlas-line{display:flex;gap:10px;margin:8px 0;align-items:baseline}
.atlas-lines .atlas-line-tags{flex:0 0 11em;max-width:40%}.atlas-lines .atlas-line>p{margin:0;flex:1 1 auto;min-width:0;overflow-wrap:anywhere}
@media(max-width:520px){.atlas-lines .atlas-line{flex-direction:column;gap:2px}.atlas-lines .atlas-line-tags{flex:0 0 auto;max-width:none}}`;

export default function AtlasLines({ sector, lang, profile }) {
  if (profile === 'Young Learner') return null;
  const entry = ATLAS_LINES[sector];
  if (!entry) return null;
  const L = lang === 'it' ? 'it' : 'en', S = STORY[L] || STORY.en;
  return <div className="atlas-lines" data-sector={sector}><style>{CSS}</style>
    {entry.lines.map((x, i) => <div key={i} className="eq-pt atlas-line" data-line={x.kind}>
      <div className="atlas-line-tags">{LINE_FLAGS.filter(k => x.flags.includes(k)).map(k => <StatusBadge key={k} flag={k} lang={L} strings={S} />)}</div>
      <p><Tx>{x[L]}</Tx></p>
    </div>)}
  </div>;
}
