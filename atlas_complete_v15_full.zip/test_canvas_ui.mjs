// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The two canvases (SimplexCanvas on the atlas page and the rule page, GenesisCanvas) are the owner's own components, bundled into the build; every other browser test passed with both replaced by an
// empty placeholder (audit G41). This one looks at the pixels: each page has a canvas that is not blank (pixels and colours besides its background), and the picture CHANGES when the reader changes what it
// shows (a stage on the rule page, a cell and a lens on the atlas page) by much more than it changes on its own (the scene may turn). It uses the build's canvases, so it needs the owner's host files.
// On the atlas page it also reads the name of the picture, which the package's wrapper CanvasLabel.jsx sets for the Young Learner and gives back to the owner's canvas for the others.
// Exit 77 (skipped, with the reason) only when this browser cannot create a WebGL context at all, or when Chromium cannot be started (ui_helpers.mjs); a page without a canvas, or with a blank one, FAILS (that is the placeholder case).   Run: node test_canvas_ui.mjs   (ATLAS_DIST=<dist folder>)
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { APP_HTML } from './paths.mjs';
import { YL_VIEW_NAMES, ylPictureLabel } from './ylAtlas.js';
const b = await chromium.launch(), errs = [];
// What is measured is the canvas's own drawing: the legend the components lay over it (a <div> next to the <canvas>) is hidden while the screenshot is taken, and a 2-pixel frame is left out
// (the screenshot of an element at a fractional position takes in a row of its neighbour, e.g. the stage buttons above the rule picture). Colour histogram with 4 bits a channel.
// The thresholds count PIXELS, not shares of the canvas, so they separate an empty canvas from a picture without depending on how large the owner's picture happens to be (re-test T6-10:
// the old shares, 3 colours and 0.3 % drawn, sat at the real #atlas picture, 3 colours and 0.6 %, and a legitimately smaller picture, the camera twice as far, failed them):
//   px      pixels that differ from the background colour (the colour at the inner top-left corner). Need 200 (a 14 x 14 patch). Measured here: a blank canvas 0; the real pictures 3,000 (#atlas,
//           3rd cell) to 26,000; the #atlas picture with the camera twice as far 750, three times as far 345 (both pass).
//   extra   colours other than the background that cover at least 10 pixels each. Need 2. A blank canvas has 0 and one flat shape 1; lines, balls and their shading give more (real: 8 to 60).
//   The real numbers are far above both floors, so a restyling (thinner lines, smaller balls, another default cell) does not trip them; only an empty or flat canvas does.
//   change  how many pixels changed colour between two pictures (half the L1 distance of the histograms), against the same count when nothing was touched (the scene may turn).
//           Need 200 and three times the untouched count (real: 7,600 against 700 on #rule, 25,800 against 70 on #atlas; a frozen picture: about 1 to 1).
const HIDE = ':has(> canvas) > :not(canvas) { visibility: hidden !important; }', INSET = 2;
const HIST = async (pg, buf) => pg.evaluate(async ([b64, m]) => { const bm = await createImageBitmap(await (await fetch('data:image/png;base64,' + b64)).blob()); const c = document.createElement('canvas'); c.width = bm.width; c.height = bm.height;
  const x = c.getContext('2d'); x.drawImage(bm, 0, 0); const W = c.width - 2 * m, H = c.height - 2 * m, d = x.getImageData(m, m, W, H).data, h = new Float64Array(4096), N = d.length / 4, bg = (d[0] >> 4) << 8 | (d[1] >> 4) << 4 | d[2] >> 4;
  for (let i = 0; i < d.length; i += 4) h[(d[i] >> 4) << 8 | (d[i + 1] >> 4) << 4 | d[i + 2] >> 4]++;
  let extra = 0; for (let i = 0; i < 4096; i++) if (i !== bg && h[i] >= 10) extra++;
  return { h: Array.from(h), N, extra, px: N - h[bg], drawn: 1 - h[bg] / N }; }, [buf.toString('base64'), INSET]);
const dist = (a, b2) => a.h.reduce((s, v, i) => s + Math.abs(v - b2.h[i]), 0) / 2;   // pixels that changed colour (the two screenshots are of one element, so of one size)
const shot = async (pg, c) => { await pg.waitForTimeout(700); return HIST(pg, await c.screenshot({ style: HIDE })); };
const PAGES = [
  ['rule', async pg => { const stages = pg.locator('main button').filter({ hasText: /^0[0-8]$/ }); return [async () => { await stages.nth(0).click(); }, async () => { await stages.nth(5).click(); }, 'the stage (00 -> 05)']; }],
  ['atlas', async pg => { const cells = pg.locator('main button').filter({ hasText: /plus · \d minus/ }), lens = pg.locator('main button').filter({ hasText: /^(Switches|Doubling|Triangles|Cube)$/ });
    return [async () => { await cells.nth(2).click(); await lens.nth(0).click(); }, async () => { await cells.nth(20).click(); await lens.nth(3).click(); }, 'the cell and the lens (3rd cell / Switches -> 21st cell / Cube)']; }],
];
let checks = 0, skipped = '';
const ok = (c, m) => { checks++; if (!c) errs.push(m); };
for (const [page, ctl] of PAGES) {
  const pg = await b.newPage({ viewport: { width: 1100, height: 900 } }); pg.on('pageerror', e => errs.push(page + ': ' + e.message));
  await pg.goto(APP_HTML + '#' + page); await pg.waitForTimeout(1200);
  const gl = await pg.evaluate(() => { try { const c = document.createElement('canvas'); return !!(c.getContext('webgl2') || c.getContext('webgl')); } catch { return false; } });
  if (!gl) { skipped = 'this browser cannot create a WebGL context, so the canvases cannot draw here'; await pg.close(); break; }
  const n = await pg.locator('main canvas').count(); ok(n >= 1, `#${page}: the page has a <canvas> (found ${n}); a placeholder component draws none`);
  if (!n) { await pg.close(); continue; }
  const c = pg.locator('main canvas').first(); await c.scrollIntoViewIfNeeded();
  const [setA, setB, what] = await ctl(pg); await setA(); const a1 = await shot(pg, c), a2 = await shot(pg, c); await setB(); const bb = await shot(pg, c); await setA(); const a3 = await shot(pg, c);
  const noise = Math.max(dist(a1, a2), dist(a1, a3)), change = dist(a1, bb);
  for (const [nm, v] of [['first', a1], ['second', bb]]) { ok(v.extra >= 2, `#${page}: the ${nm} picture is not blank: ${v.extra} colours besides the background (need 2 or more, 10 pixels each; a blank canvas has 0)`);
    ok(v.px >= 200, `#${page}: the ${nm} picture has something drawn: ${v.px} pixels (${(100 * v.drawn).toFixed(2)} %) differ from its background (need 200 or more; a blank canvas has 0)`); }
  ok(change >= 200 && change > 3 * noise, `#${page}: the picture changes with ${what}: ${change} pixels changed colour, against ${noise} when nothing was touched (need 200 or more and three times that)`);
  console.log(`#${page}: ${a1.N} pixels; ${a1.extra} colours besides the background, ${a1.px} pixels drawn (${(100 * a1.drawn).toFixed(2)} %); second picture ${bb.extra} colours, ${bb.px} pixels; change ${change} pixels vs ${noise} untouched`);
  if (page === 'atlas') {
    // the name of the picture (the package's wrapper CanvasLabel.jsx around the owner's SimplexCanvas, which needs no edit): the Physicist reads the owner's own name; the
    // Young Learner reads the plain name of the view (ylAtlas.js ylPictureLabel), view by view; back with the Physicist, the owner's own name stands again
    const name = () => pg.evaluate(() => { const w = document.querySelector('main .canvas-label'), e = w && (w.querySelector('[aria-label]') || w.firstElementChild); return e ? e.getAttribute('aria-label') : null; });
    const state = () => pg.evaluate(() => [document.querySelector('main .view-picker [data-view][aria-pressed="true"]')?.dataset.view || null, document.querySelector('.audience-group .active')?.dataset.profile || null]);
    const PLAIN = Object.keys(YL_VIEW_NAMES.en).flatMap(v => [ylPictureLabel(v, 'en'), ylPictureLabel(v, 'it')]);
    await pg.locator('.audience-group [data-profile="Physicist"]').click(); await pg.waitForTimeout(400);   // the page opens for the Young Learner: start from the Physicist
    const [view0, prof] = await state(), own = await name();
    ok(prof && prof !== 'Young Learner' && typeof own === 'string' && own.length > 0 && !PLAIN.includes(own), `#atlas (${prof}): the picture carries the owner's own name ("${own}"), not a plain name of the Young Learner`);
    await pg.locator('.audience-group [data-profile="Young Learner"]').click(); await pg.waitForTimeout(400);
    const [view1] = await state(), yl = await name();
    ok(view1 && yl === ylPictureLabel(view1, 'en'), `#atlas (Young Learner): the picture is named with the plain name of the view ${view1}: "${yl}" (want "${view1 && ylPictureLabel(view1, 'en')}")`);
    await pg.locator('main .view-picker [data-view="Cube"]').click(); await pg.waitForTimeout(300);
    ok(await name() === ylPictureLabel('Cube', 'en'), `#atlas (Young Learner): another view, another plain name: "${await name()}"`);
    await pg.locator('main .view-picker [data-view="' + (view0 || 'Clifford') + '"]').click(); await pg.locator(`.audience-group [data-profile="${prof}"]`).click(); await pg.waitForTimeout(400);
    ok(await name() === own, `#atlas (${prof} again): the owner's own name stands again: "${await name()}" (want "${own}")`);
  }
  await pg.close();
}
await b.close();
if (skipped && !errs.length) { console.log('SKIPPED: ' + skipped); process.exit(77); }
console.log(errs.length ? 'FAIL\n' + errs.join('\n') : `CANVAS UI OK (${checks} checks)`); process.exit(errs.length ? 1 : 0);
