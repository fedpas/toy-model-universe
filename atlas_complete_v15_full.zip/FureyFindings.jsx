// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { FINDINGS, FINDINGS_UI } from './findingsData.js';
import { fc } from './fureyCopy.js';
import { Tx } from './MathText.jsx';
import { StatusBadge, StatusIcon } from './StatusBadge.jsx';
import { isLearner } from './Formal.jsx';
import { storyFor } from './StoryShell.jsx';
import { Head, Sec, Older } from './FureyKit.jsx';
import { Peirce, Charges, Edges, Axes } from './FureyWidgets.jsx';

// Tab "Her 2026 model": the model of the nested-embeddings paper built explicitly (V of real dimension 16, ω = L_{e7}), as five cards (claims FUR-001 to FUR-005, whose text
// is findingsData.js, built from fureyCopy.js findings.cards) laid out in sections around the widgets: the two boards, the charges of the eight lanes, the ten edges,
// the sixteen axes, and what stays open.
const BADGE = { verified: '#4fd18b', open: '#ffd166' };
const SECS = [['blocks', Peirce, ['blocks']], ['charges', Charges, []], ['edges', Edges, ['edges']], ['axes', Axes, ['witt', 'z2']], ['open', null, ['open']]];

function Card({ f, lang, profile, ui, S }) {
  const [title, body] = (f[lang] || f.en)[profile] || f.en.Physicist;
  return <article className="f-card" data-finding={f.id}>
    <span className="f-badge" role="img" aria-label={ui.status[f.status]} title={ui.status[f.status]} style={{ color: BADGE[f.status], borderColor: BADGE[f.status], display: 'inline-flex', padding: '.15rem .4rem' }}><StatusIcon flag={f.status === 'verified' ? 'checked' : 'open'} size={14} /></span>
    {f.flags.length > 0 && <span className="f-tags">{f.flags.map(k => <StatusBadge key={k} flag={k} lang={lang} strings={S} />)}</span>}
    <h4><Tx>{title}</Tx></h4><p><Tx>{body}</Tx></p></article>;
}

export default function FureyFindings({ lang = 'en', profile = 'Young Learner' }) {
  const L = lang === 'it' ? 'it' : 'en', c = fc(L).findings, ui = FINDINGS_UI[L], S = storyFor(L, profile), W = { lang: L, profile }, yl = isLearner(profile), byId = Object.fromEntries(FINDINGS.map(f => [f.id, f]));
  const sec = k => c.secs[k], note = <p className="fy-note"><Tx>{ui.repro}</Tx></p>;
  return <section className="ln fy findings" id="findings" aria-labelledby="findings-h" data-tab="findings"><Head lang={L} profile={profile} id="findings" c={c} hid="findings-h" />
    {SECS.map(([k, Wd, cards]) => (k === 'charges'
      ? <Sec key={k} lang={L} profile={profile} id={'fy-' + k} s={sec(k)}>{Wd ? <Wd {...W} /> : null}</Sec>
      : <div className="fw-sec" id={'fy-' + k} key={k} data-sec={'fy-' + k}><h3><Tx>{yl ? sec(k).hy : sec(k).h}</Tx></h3>{Wd ? <Wd {...W} /> : null}
        {cards.map(id => <Card key={id} f={byId[id]} lang={L} profile={profile} ui={ui} S={S} />)}</div>))}
    {yl ? <Older lang={L} profile={profile} secs={[['charges', sec('charges')]]} extra={<>{FINDINGS.map(f => <div key={f.id}><h4><Tx>{f[L].Mathematician[0]}</Tx></h4><p><Tx>{f[L].Mathematician[1]}</Tx></p></div>)}{note}</>} /> : note}
  </section>;
}
