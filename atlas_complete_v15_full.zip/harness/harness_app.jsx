// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Entry of the test build: mounts <App/> in #r. The real entry of your own repository replaces this file; nothing else in the package depends on it.
import React from 'react'; import {createRoot} from 'react-dom/client';
import App from '../App.jsx';
createRoot(document.getElementById('r')).render(<div style={{background:'#0b1020',color:'#e6e9f5',font:'15px system-ui'}}><App/></div>);
