// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useEffect, useRef, useState } from 'react';

// One story, five pages. Every page says what the previous page showed, what it does, and what it hands on.
// Status vocabulary used everywhere: checked (exact arithmetic or script), standard (textbook mathematics),
// ours (the reading we propose), open (not established), input (a choice or datum taken from outside the algebra).
import { PAGES, STORY, STORY_YL } from './storyCopy.js';
import { Intro } from './Fold.jsx';
import { pageEyebrow, STEP_GROUPS, navNames, stepNo, stepAudience, groupOfStep } from './steps.js';
import { TREE, flat } from './mapData.js';
import { NODES, NODES_YL } from './mapCopy.js';
import { Tx } from './MathText.jsx';
import { THEMES, THEME_KEY, THEME_COPY, getTheme, setTheme, subscribeTheme } from './theme.js';
import { getFilter, setFilter, subscribeFilter, watchHidden, watchSection, hiddenUnder, supported as filterSupported, FILTER_COPY } from './readerFilter.js';
import { Tags, StatusIcon, Legend } from './StatusBadge.jsx';
import NeedsStrip, { stripId } from './NeedsStrip.jsx';
import { NEEDS, NEEDS_COPY } from './inputsData.js';
export { PAGES, STORY, STORY_YL };
const YL = 'Young Learner';
// the frame copy a reader sees: the Young Learner reads the plain keys of STORY_YL where they exist
const storyFor = (lang, profile) => { const s = STORY[lang] || STORY.en; if (profile !== YL) return s; const y = STORY_YL[lang] || STORY_YL.en; return { ...s, tagHelp: y.tagHelp, note: y.note, metric: y.metric, pages: Object.fromEntries(Object.keys(s.pages).map(k => [k, { ...s.pages[k], ...y.pages[k] }])) }; };
export { storyFor };
const nodesFor = (lang, profile) => (profile === YL ? NODES_YL[lang] || NODES_YL.en : NODES[lang] || NODES.en);

const STYLE = `
.story-nav{position:sticky;top:0;z-index:20;display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:8px 16px;background:var(--bg,#0b1020);border-bottom:1px solid rgba(128,128,128,.3)}
.story-nav .brand{margin-right:12px;font-weight:600;text-decoration:none;color:inherit}
.story-nav button{background:none;border:1px solid rgba(128,128,128,.4);border-radius:999px;padding:4px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}
.story-nav button.active{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.story-nav .settings{margin-left:auto;position:relative}.settings>summary{cursor:pointer;list-style:none;opacity:.75;font-size:.85em;padding:4px 10px;border:1px solid rgba(128,128,128,.4);border-radius:999px}.settings>summary::-webkit-details-marker{display:none}
.settings[open]>summary{opacity:1;border-color:#4aa8ff}.settings .settings-pop{position:absolute;right:0;top:calc(100% + 8px);z-index:30;min-width:260px;padding:12px;background:var(--bg,#0b1020);border:1px solid rgba(128,128,128,.45);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.35)}
.settings .settings-pop p{margin:0 0 6px;font-size:.8em;letter-spacing:.06em;opacity:.75}.settings .settings-pop small{display:block;margin-top:8px;opacity:.65}.settings .settings-pop button{margin-right:6px}
.settings .settings-pop>div+div{margin-top:12px;padding-top:10px;border-top:1px solid rgba(128,128,128,.3)}.settings .sp-filter button{display:block;width:100%;margin:6px 0 0;border-radius:8px;text-align:left}
.rf-notice,.rf-secnote{margin:10px 0 0;padding:6px 10px;border-left:3px solid rgba(80,170,255,.55);font-size:.85em}.rf-notice button,.rf-secnote button{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:2px 10px;margin-left:6px;color:inherit;cursor:pointer;font:inherit}
.view-picker{max-width:1000px;margin:12px auto;padding:0 16px;display:flex;flex-wrap:wrap;gap:6px;align-items:center}.tabbar{max-width:1000px;margin:12px auto 0;padding:0 16px;scroll-margin-top:var(--nav-h,60px)}
.tabbar [role=tablist]{display:flex;flex-wrap:wrap;gap:6px;padding:2px 0 8px}
@media(max-width:700px){.tabbar [role=tablist]{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}}
.tabbar .tab{flex:0 0 auto;white-space:nowrap;background:none;border:1px solid rgba(128,128,128,.4);border-radius:8px;padding:6px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}
.tabbar .tab.on{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.needs-strip{max-width:1000px;margin:10px auto 0;padding:8px 16px;border-left:3px solid rgba(196,181,253,.6);font-size:.85em}.needs-strip p{margin:.2em 0}.needs-strip .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}.needs-strip .ns-need{display:inline-block;margin:0 10px 0 0;color:inherit;font-weight:600;text-decoration:underline;overflow-wrap:anywhere}.needs-strip .ns-need.ns-plain{text-decoration:none}.needs-strip .ns-list{margin:.3em 0 0;padding:0;list-style:none}.needs-strip li{margin:.25em 0;overflow-wrap:anywhere}.needs-strip .ns-kind{margin-right:6px}.needs-strip .ns-more{margin-left:2px;padding:0 2px;border:0;background:none;color:inherit;font:inherit;font-weight:600;text-decoration:underline;cursor:pointer}.needs-strip .ns-more:focus-visible{outline:2px solid rgba(80,170,255,.9);outline-offset:2px}.needs-strip .tag{white-space:normal}.needs-strip a:focus-visible{outline:2px solid rgba(80,170,255,.9);outline-offset:2px}
.glance{max-width:1000px;margin:10px auto 0;padding:8px 16px;border-left:3px solid rgba(80,170,255,.55);font-size:.85em}.glance p{margin:.2em 0}.glance .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}.glance code{font-size:.95em}.glance .gl-plain{font-size:.95em}
.stepnav{max-width:1000px;margin:20px auto 0;padding:12px 16px;display:flex;justify-content:space-between;gap:12px;border-top:1px solid rgba(128,128,128,.3)}
.stepnav>div{flex:1 1 0;min-width:0;display:flex}.stepnav>div:nth-child(2){justify-content:center}.stepnav>div:last-child{justify-content:flex-end}
.stepnav button{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:8px 14px;color:inherit;cursor:pointer;font:inherit;text-align:left;max-width:100%;overflow-wrap:anywhere}.stepnav .gl-map{opacity:.8;font-size:.85em}
.view-picker p{margin:0 8px 0 0;font-size:.8em;letter-spacing:.06em;opacity:.75}
.view-picker button{background:none;border:1px solid rgba(128,128,128,.4);border-radius:999px;padding:4px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.view-picker button.active{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.page-intro{max-width:1000px;margin:24px auto 8px;padding:0 16px}
.page-intro h2{margin:.2em 0}
.page-intro .before{opacity:.7;font-size:.9em;margin:.2em 0}
.tag{display:inline-block;margin:2px 6px 2px 0;padding:1px 8px;border-radius:6px;border:1px solid;font-size:.78em;white-space:nowrap}
.tag.checked{color:#34d399}.tag.standard{color:#60a5fa}.tag.ours{color:#fbbf24}.tag.open{color:#f87171}.tag.input{color:#c4b5fd}.tag.sb{padding:2px;line-height:0;vertical-align:-3px;white-space:nowrap}.sb-ic{flex:none;max-width:24px;max-height:24px}.tag.sb .sb-ic{display:block}.tag.kind{color:inherit;border-color:rgba(128,128,128,.6);opacity:.88}.sb-leg{margin:4px 0}.sb-leg .tag.sb{vertical-align:-4px}.pt-ic{display:inline-block;margin-right:5px;vertical-align:-3px;line-height:0}
.page-tags .tag{white-space:normal;display:block;max-width:100%;overflow-wrap:anywhere}.page-tags .tag.sb,.audit-line .tag.sb{display:inline-block;width:auto;max-width:none}
.audit-line .tag{white-space:normal;max-width:100%;overflow-wrap:anywhere}
.page-tags{margin:8px 0}
.page-tags details{font-size:.8em;opacity:.85}
.eq-fold{margin:12px 0}.eq-fold>summary{cursor:pointer;font-weight:600;padding:6px 0}.eq-short{font-size:1.05em}.page-intro .lede{font-size:1em;margin:.4em 0}.page-intro .eq-fold>summary{cursor:pointer;font-weight:600}
.story-pager{display:flex;justify-content:space-between;gap:16px;max-width:1000px;margin:32px auto;padding:16px;border-top:1px solid rgba(128,128,128,.3)}
.story-pager>div{flex:1 1 0;min-width:0;display:flex}.story-pager>div:last-child{justify-content:flex-end}
.story-pager button{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:8px 14px;color:inherit;cursor:pointer;font:inherit;text-align:left;max-width:100%;overflow-wrap:anywhere}
.story-pager small{display:block;opacity:.75;margin-top:4px}
/* the arrows of Back / Next are decoration (drawn by CSS, not text), so a reader or a copy never meets a formula arrow there */
.story-pager .pg-prev::before,.stepnav .sn-prev::before{content:'\\2190\\00a0'}.story-pager .pg-to::after,.stepnav .sn-next::after{content:'\\00a0\\2192'}
/* phones: previous / next stack in one column instead of running off the right edge */
@media(max-width:520px){.stepnav,.story-pager{flex-direction:column;gap:8px}.stepnav>div,.story-pager>div{justify-content:stretch!important}.stepnav>div:empty,.story-pager>div:empty{display:none}.stepnav button,.story-pager button{width:100%}}
/* phones: the page bar is one row that scrolls sideways (about 40 px high instead of four wrapped rows); Settings stays at its right end */
@media(max-width:700px){.story-nav{flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;gap:4px;padding:6px 8px;scrollbar-width:none}.story-nav::-webkit-scrollbar{display:none}
.story-nav .brand{flex:0 0 auto;margin-right:4px;font-size:.85em;white-space:nowrap}.story-nav>button{flex:0 0 auto;white-space:nowrap;padding:4px 10px}
.story-nav .settings{position:sticky;right:0;flex:0 0 auto;padding-left:6px;background:var(--bg,#0b1020)}.story-nav .settings .sn-txt{display:none}.settings .settings-pop{position:fixed;top:var(--sn-pop-top,48px);right:8px;max-height:calc(100vh - var(--sn-pop-top,48px) - 8px);overflow-y:auto;box-sizing:border-box}}
.story-nav button:focus-visible,.story-nav summary:focus-visible,.tabbar .tab:focus-visible,.stepnav button:focus-visible,.rf-notice button:focus-visible,.rf-secnote button:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
`;

// The language is chosen once, in Settings, and remembered in this browser; it is not a control that scrolls with the page.
const LANG_KEY = 'atlas.lang';
export const readLang = () => {
  try { const v = localStorage.getItem(LANG_KEY); if (v === 'en' || v === 'it') return v; } catch { /* storage can be blocked */ }
  try { if (String(navigator.language || '').toLowerCase().startsWith('it')) return 'it'; } catch { /* ignore */ }
  return 'en';
};
export const saveLang = l => { try { localStorage.setItem(LANG_KEY, l); } catch { /* ignore */ } };
// The audience is a set-once setting too: remembered in this browser under atlas.audience; a stored value that is not one of the three is ignored.
export const AUDIENCES = ['Young Learner', 'Physicist', 'Mathematician'];
const AUD_KEY = 'atlas.audience';
export const readAudience = () => { try { const v = localStorage.getItem(AUD_KEY); if (AUDIENCES.includes(v)) return v; } catch { /* storage can be blocked */ } return 'Young Learner'; };
export const saveAudience = a => { if (!AUDIENCES.includes(a)) return; try { localStorage.setItem(AUD_KEY, a); } catch { /* ignore */ } };
// The theme is a set-once setting too: auto | light | dark, default dark, remembered under atlas.theme (THEME_KEY). theme.js reads it, and ?theme= in the
// address, as soon as the page loads, before React draws (no flash); a stored value that is not one of the three is ignored. The reader filter: readerFilter.js (atlas.filter).
export { THEMES, THEME_KEY };
export const readTheme = getTheme, saveTheme = setTheme;
// the theme choice, the reader filter and the count of hidden lines, as React state (the stores live in theme.js and readerFilter.js, outside React)
export function useTheme() { const [t, setT] = useState(getTheme); useEffect(() => { setT(getTheme()); return subscribeTheme(setT); }, []); return [t, setTheme]; }
export function useReaderFilter() { const [f, setF] = useState(getFilter); useEffect(() => { setF(getFilter()); return subscribeFilter(setF); }, []); return [f, setFilter]; }
// {known, plain, knownOnly}: the lines of <main> each setting hides (read-only scan); null while not active
export function useHiddenCount(active = true) { const [c, setC] = useState(null); useEffect(() => { if (!active) { setC(null); return undefined; } return watchHidden(setC); }, [active]); return c; }

// A page may have tabs: the address is #page or #page/tab (for example #equations/rigid), so that every tab can be linked to.
// Every page or tab the reader opens is a history entry (pushState), so the browser's Back and Forward move between them; an address that names
// no page or no tab is corrected on load with replaceState (no extra entry). popstate and hashchange both re-read the address.
export const SUBS = { conventions: ['conventions', ...STEP_GROUPS.core], maxwell: ['views', 'charges', 'ladders'], shapes: STEP_GROUPS.shapes, equations: [...STEP_GROUPS.eq, 'tally'], furey: ['dictionary', 'earlier', 'findings', 'threegen', 'help'], lenses: STEP_GROUPS.lens };
// the lenses page: 'ln-<tab>' is the tab itself; an anchor inside a tab starts with that chapter's prefix (cat-, bz-, sc-), so a link to it opens the right tab first
const LENS_PREFIX = { 'cat-': 'category', 'bz-': 'baez', 'sc-': 'schuller' };
const LENS_ANCHOR = a => (/^ln-/.test(a) ? a.replace(/^ln-/, '') : (LENS_PREFIX[Object.keys(LENS_PREFIX).find(k => a.startsWith(k))] || null));
// the pictures of the clock, gauge-gravity and finite-groups steps (ls-<picture>) sit in the tab named here, whatever page holds that tab
const LS_ANCHOR = { 'ls-lattice': 'clock', 'ls-arrow': 'clock', 'ls-trinity': 'clock', 'ls-biv': 'clock', 'ls-horizon': 'gauge', 'ls-curv': 'gauge', 'ls-rails': 'groups', 'ls-golay': 'groups', 'ls-primes': 'groups' };
const FUREY_ANCHOR = { dictionary: 'dictionary', earlier: 'earlier', findings: 'findings', 'tg-h': 'threegen', help: 'help' };
// the tab that holds an anchor of the Map ("Go there"), or null
export const anchorSub = (page, a) => {
  if (!a || !SUBS[page]) return null;
  const nk = a.startsWith('ns-') ? Object.keys(NEEDS).find(k => stripId(k) === a) : null;   // a needs strip (ns-<tab>, ns-maxwell-<tab>): its tab
  const id = nk ? nk.replace(/^maxwell\//, '') : page === 'conventions' ? (/^cv-/.test(a) ? (a === 'cv-clock' ? 'clock' : 'conventions') : LS_ANCHOR[a]) : page === 'equations' ? (LS_ANCHOR[a] || a.replace(/^eq-/, '')) : page === 'shapes' ? a.replace(/^sh-/, '') : page === 'maxwell' ? a.replace(/^mx-/, '') : page === 'lenses' ? (LS_ANCHOR[a] || LENS_ANCHOR(a)) : FUREY_ANCHOR[a];
  return SUBS[page].includes(id) ? id : null;
};
// An address of the story is #page or #page/tab. The address of a saved bookmark (#labels, #labels/clock, #labels/gauge, #labels/groups, #labels/conventions)
// is read as the tab that holds the content, and the address bar is rewritten on load (replaceState: no extra history entry).
const LEGACY = { clock: ['conventions', 'clock'], conventions: ['conventions', 'conventions'], gauge: ['equations', 'gauge'], groups: ['lenses', 'groups'] };
const rawHash = () => (typeof location !== 'undefined' ? location.hash : '');
const hashParts = () => { const r = rawHash().replace('#', '').split('/'); return r[0] === 'labels' ? (LEGACY[r[1]] || LEGACY.clock) : r; };
const fixLegacy = () => { const raw = rawHash(); if (/^#labels(\/|$)/.test(raw)) { try { history.replaceState(null, '', '#' + hashParts().join('/')); } catch { /* ignore */ } } };
export function usePage() {
  const read = () => { const h = hashParts()[0]; return PAGES.includes(h) ? h : 'rule'; };
  const [page, setPageState] = useState(read);
  useEffect(() => {
    fixLegacy(); const h = hashParts()[0]; if (h && !PAGES.includes(h)) { try { history.replaceState(null, '', '#' + read()); } catch { /* ignore */ } }
    const f = () => { fixLegacy(); setPageState(read()); }; window.addEventListener('hashchange', f); window.addEventListener('popstate', f);
    return () => { window.removeEventListener('hashchange', f); window.removeEventListener('popstate', f); };
  }, []);
  // the button of the page already shown, with no tab named, only scrolls to the top: the address keeps the tab on screen (#equations/spin stays), no new entry
  const setPage = (p, sub) => { if (p === page && !sub) { if (typeof window !== 'undefined') window.scrollTo?.(0, 0); return; } const h = '#' + p + (sub ? '/' + sub : ''); try { if (location.hash !== h) history.pushState(null, '', h); } catch { /* ignore */ } setPageState(p); if (typeof window !== 'undefined') window.scrollTo?.(0, 0); };
  return [page, setPage];
}
export function useSub(page) {
  const ids = SUBS[page];
  const read = () => { const [h, s] = hashParts(); return h === page && ids.includes(s) ? s : ids[0]; };
  const [sub, setSubState] = useState(read);
  useEffect(() => {
    const [h, t] = hashParts(); if (h === page && t && !ids.includes(t)) { try { history.replaceState(null, '', '#' + page + '/' + ids[0]); } catch { /* ignore */ } }
    const f = () => setSubState(read()); window.addEventListener('hashchange', f); window.addEventListener('popstate', f);
    return () => { window.removeEventListener('hashchange', f); window.removeEventListener('popstate', f); };
  }, [page]);
  const setSub = id => { const h = '#' + page + '/' + id; try { if (location.hash !== h) history.pushState(null, '', h); } catch { /* ignore */ } setSubState(id); };
  return [sub, setSub];
}
export const tabLabel = (lang, page, id, profile = stepAudience()) => {
  const n = navNames(lang, profile)[id];
  if (page === 'furey') return nodesFor(lang, profile)[id][0];
  const group = groupOfStep(id);   // the clock is a step of the Conventions page (group core), gauge gravity of the equations page, the finite groups of the lenses page
  return group ? stepNo(group, id) + ' · ' + n : n;
};

// height of the sticky page bar (0 when it does not stick), so that nothing is scrolled under it
export const navHeight = () => { try { const n = document.querySelector('.story-nav'); return n && /sticky|fixed/.test(getComputedStyle(n).position) ? n.getBoundingClientRect().height : 0; } catch { return 0; } };
// bring the tab bar of a page to the top of the window, just below the page bar; with force=false only when it is hidden (under the bar or above the window)
export function showTabs(page, force = true) {
  if (typeof document === 'undefined') return;
  const el = document.getElementById('tabs-' + page); if (!el || !window.scrollTo) return;
  const h = navHeight(), top = el.getBoundingClientRect().top;
  if (!force && top >= h && top < window.innerHeight - 40) return;
  let reduce = false; try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { /* ignore */ }
  window.scrollTo({ top: Math.max(0, window.scrollY + top - h - 4), behavior: reduce ? 'auto' : 'smooth' });
}
// bring an element (the target of a Map "Go there" button) to the top of the window, just below the sticky page bar (scrollIntoView would put it under the bar)
export function scrollToAnchor(id) {
  if (typeof document === 'undefined') return;
  const el = document.getElementById(id); if (!el || !window.scrollTo) return;
  let reduce = false; try { reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { /* ignore */ }
  window.scrollTo({ top: Math.max(0, window.scrollY + el.getBoundingClientRect().top - navHeight() - 4), behavior: reduce ? 'auto' : 'smooth' });
}
// on a phone the tab list scrolls sideways: keep the chosen tab in view inside it (sideways only, the page does not move)
const centerTab = bar => { const on = bar && bar.querySelector('.tab.on'), list = on && on.parentElement; if (!list || list.scrollWidth <= list.clientWidth) return; list.scrollLeft += on.getBoundingClientRect().left - list.getBoundingClientRect().left - (list.clientWidth - on.offsetWidth) / 2; };
// the tab bar of a page; arrow keys (and Home/End) move between tabs
export function TabBar({ lang, page, active, onPick, profile = stepAudience() }) {
  const s = STORY[lang] || STORY.en, ids = SUBS[page], ref = useRef(null);
  useEffect(() => { centerTab(ref.current); }, [active]);
  const pick = id => { onPick(id); setTimeout(() => showTabs(page), 0); };
  const key = (e, i) => { const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0, to = e.key === 'Home' ? 0 : e.key === 'End' ? ids.length - 1 : d ? (i + d + ids.length) % ids.length : -1; if (to < 0) return; e.preventDefault(); const id = ids[to]; onPick(id); setTimeout(() => { ref.current?.querySelector(`[data-tab="${id}"]`)?.focus({ preventScroll: true }); showTabs(page, false); }, 0); };
  return <div className="tabbar" id={'tabs-' + page} ref={ref}><div role="tablist" aria-label={s.tabsLbl[page]}>{ids.map((id, i) => <button key={id} role="tab" id={'tab-' + page + '-' + id} data-tab={id} aria-selected={id === active} aria-controls={'panel-' + page} tabIndex={id === active ? 0 : -1} className={'tab' + (id === active ? ' on' : '')} onClick={() => pick(id)} onKeyDown={e => key(e, i)}><Tx>{tabLabel(lang, page, id, profile)}</Tx></button>)}</div></div>;
}

// what the Young Learner reads in the "check" row of the at-a-glance strip, in place of the names of the script files (the tick is the checked badge)
const YL_CHECK = { en: 'A script recomputes everything that carries a tick.', it: 'A script recomputes everything that carries a tick.' };
// the frame every tab shares: an at-a-glance strip (status, script, what is established), the tab's content, then previous / next and the Map
export function TabPanel({ lang, page, id, onPick, children, goMap, profile = stepAudience(), ownGlance = false }) {   // ownGlance: the page draws its own at-a-glance strip for this tab (the Conventions page)
  const s = storyFor(lang, profile), ids = SUBS[page], i = ids.indexOf(id), prev = ids[i - 1], next = ids[i + 1];
  const node = ownGlance ? null : flat(TREE).find(x => x.id === id && x.go[0] === page), txt = node && nodesFor(lang, profile)[id];
  const step = to => { onPick(to); setTimeout(() => { document.getElementById('tab-' + page + '-' + to)?.focus({ preventScroll: true }); showTabs(page); }, 0); };
  // a need of the strip is a tab id (found in SUBS, whatever page holds it now) or a page word; no such tab or page, no link
  const needTarget = w => { const p = Object.keys(SUBS).find(k => SUBS[k].includes(w)); if (p) return { page: p, sub: w, label: tabLabel(lang, p, w, profile) }; return PAGES.includes(w) ? { page: w, sub: (SUBS[w] || [])[0] || null, label: s.nav[w] } : null; };
  const panelRef = useRef(null);
  return <div role="tabpanel" id={'panel-' + page} aria-labelledby={'tab-' + page + '-' + id} data-sub={id} ref={panelRef}>
    {node && <aside className="glance" aria-label={s.glance}><p><span className="gl-k"><Tx>{s.glance.toUpperCase()}</Tx></span><Tags kinds={node.tags} lang={lang} strings={s} /></p>
      <p><span className="gl-k"><StatusIcon flag="checked" size={13} /> <Tx>{(profile === YL ? NEEDS_COPY.yl.script : NEEDS_COPY.script).toUpperCase()}</Tx></span>{profile === YL ? <span className="gl-plain"><Tx>{YL_CHECK[lang] || YL_CHECK.en}</Tx></span> : <code><Tx>{node.script}</Tx></code>}</p>{txt && <p><Tx>{txt[1]}</Tx></p>}</aside>}
    <NeedsStrip lang={lang} profile={profile} page={page} id={id} strings={s} resolve={needTarget} />
    <SectionNotice lang={lang} rootRef={panelRef} />
    {children}
    <nav className="stepnav" aria-label={s.tabsLbl[page]}><div>{prev && <button className="sn-prev" onClick={() => step(prev)}><Tx>{s.prevStep}</Tx>: <Tx>{tabLabel(lang, page, prev, profile)}</Tx></button>}</div>
      <div>{goMap && <button className="gl-map" onClick={() => goMap('map', 'map-top')}><Tx>{s.onMap}</Tx></button>}</div>
      <div>{next && <button className="sn-next" onClick={() => step(next)}><Tx>{s.nextStep}</Tx>: <Tx>{tabLabel(lang, page, next, profile)}</Tx></button>}</div></nav></div>;
}

// Settings: language (the menu closes after a pick), theme and reader filter (the menu stays open, so the effect and the count can be seen); one group each
export function Settings({ lang, setLang }) {
  const s = STORY[lang] || STORY.en, ref = useRef(null), th = THEME_COPY[lang] || THEME_COPY.en, rf = FILTER_COPY[lang] || FILTER_COPY.en;
  const [open, setOpen] = useState(false), [theme, pickTheme] = useTheme(), [filter, pickFilter] = useReaderFilter(), count = useHiddenCount(open), [canFilter] = useState(filterSupported);
  const pick = l => { setLang(l); saveLang(l); if (ref.current) ref.current.open = false; };
  const place = () => { const d = ref.current, n = d && d.closest('.story-nav'); setOpen(!!(d && d.open)); if (d && d.open && n) d.style.setProperty('--sn-pop-top', Math.round(n.getBoundingClientRect().bottom + 6) + 'px'); };
  const esc = e => { if (e.key === 'Escape' && ref.current?.open) { e.preventDefault(); ref.current.open = false; ref.current.querySelector('summary')?.focus(); } };   // Escape closes the menu
  return <details className="settings" ref={ref} onToggle={place} onKeyDown={esc}><summary aria-label={s.settings}>⚙<span className="sn-txt"> <Tx>{s.settings}</Tx></span></summary>
    <div className="settings-pop"><div role="group" aria-label={s.langLabel}><p><Tx>{s.langLabel.toUpperCase()}</Tx></p>
      <button className={lang === 'en' ? 'active' : ''} data-lang="en" aria-pressed={lang === 'en'} onClick={() => pick('en')}>English</button>
      <button className={lang === 'it' ? 'active' : ''} data-lang="it" aria-pressed={lang === 'it'} onClick={() => pick('it')}>Italiano</button><small><Tx>{s.langNote}</Tx></small></div>
      <div role="group" aria-label={th.label} className="sp-theme"><p><Tx>{th.label.toUpperCase()}</Tx></p>{THEMES.map(v => <button key={v} className={theme === v ? 'active' : ''} data-theme-choice={v} aria-pressed={theme === v} onClick={() => pickTheme(v)}><Tx>{th[v]}</Tx></button>)}<small><Tx>{th.note}</Tx></small></div>
      {canFilter && <div role="group" aria-label={rf.label} className="sp-filter"><p><Tx>{rf.label.toUpperCase()}</Tx></p>
        <button className={filter === 'off' ? 'active' : ''} data-rf-choice="off" aria-pressed={filter === 'off'} onClick={() => pickFilter('off')}><Tx>{rf.off}</Tx></button>
        <button className={filter !== 'off' ? 'active' : ''} data-rf-choice="known" aria-pressed={filter !== 'off'} onClick={() => pickFilter('known')}><Tx>{rf.known}</Tx></button>
        <button className={filter === 'known+std' ? 'active' : ''} data-rf-choice="known+std" aria-pressed={filter === 'known+std'} onClick={() => pickFilter(filter === 'known+std' ? 'known' : 'known+std')}><Tx>{rf.plain}</Tx></button>
        {count && <small className="rf-count" data-known={count.knownOnly} data-plain={count.plain}><Tx>{rf.count(count.knownOnly, count.plain)}</Tx></small>}<small><Tx>{rf.note}</Tx></small></div>}</div></details>;
}

// the one notice of a page while the reader filter hides something on it (drawn by PageIntro, under the tag strip); its button shows everything again
export function FilterNotice({ lang }) {
  const [filter, pickFilter] = useReaderFilter(), count = useHiddenCount(filter !== 'off'), t = FILTER_COPY[lang] || FILTER_COPY.en, h = hiddenUnder(filter, count), n = h.known + h.plain;
  if (filter === 'off' || !n) return null;
  return <p className="rf-notice" role="status" data-rf-hidden={n}><Tx>{t.notice(h.known, h.plain, filter === 'known+std')}</Tx><button type="button" className="rf-show" onClick={() => pickFilter('off')}><Tx>{t.show}</Tx></button></p>;
}

// the same notice at the top of a tab, with the count of the lines hidden in that tab alone (the page notice stays and counts the whole page)
export function SectionNotice({ lang, rootRef }) {
  const [filter, pickFilter] = useReaderFilter(), [count, setCount] = useState(null), t = FILTER_COPY[lang] || FILTER_COPY.en;
  useEffect(() => { if (filter === 'off') { setCount(null); return undefined; } return watchSection(rootRef.current, setCount); }, [filter, rootRef]);
  const h = hiddenUnder(filter, count), n = h.known + h.plain;
  if (filter === 'off' || !n) return null;
  return <p className="rf-secnote" role="status" data-rf-section={n}><Tx>{t.noticeSection(h.known, h.plain, filter === 'known+std')}</Tx><button type="button" className="rf-show" onClick={() => pickFilter('off')}><Tx>{t.show}</Tx></button></p>;
}

export function StoryNav({ lang, setLang, page, setPage }) {
  const s = STORY[lang] || STORY.en, ref = useRef(null);
  useEffect(() => { const n = ref.current, b = n && n.querySelector(':scope > button.active'); if (!n || !b || n.scrollWidth <= n.clientWidth) return; n.scrollLeft = Math.max(0, b.offsetLeft - (n.clientWidth - b.offsetWidth) / 2); }, [page]);
  return <><style>{STYLE}</style><nav className="story-nav" ref={ref} aria-label={s.navLbl}><a className="brand" href="#rule" onClick={e => { e.preventDefault(); setPage('rule'); }}><span>01</span> CASCADE ATLAS</a>
    {PAGES.map((p, i) => <button key={p} className={p === page ? 'active' : ''} aria-current={p === page ? 'page' : undefined} onClick={() => setPage(p)}><Tx>{i + 1}</Tx> · <Tx>{s.nav[p]}</Tx></button>)}
    {setLang && <Settings lang={lang} setLang={setLang} />}</nav></>;
}

// the kinds of a strip entry [kinds, text]: one kind ('checked'), or several ('standard checked', or ['standard', 'checked']) for a line that carries two flags
const kindsOf = k => (Array.isArray(k) ? k : String(k).split(/\s+/)).filter(Boolean);
export function PageIntro({ lang, page, profile = 'Mathematician', title = true }) {
  const s = storyFor(lang, profile), p = s.pages[page], i = PAGES.indexOf(page);
  return <section className="page-intro"><p className="eyebrow"><Tx>{pageEyebrow(lang in STORY ? lang : 'en', i + 1, PAGES.length)}</Tx></p>{title && <h2><Tx>{p.h}</Tx></h2>}
    {p.before && <p className="before"><b><Tx>{s.before}</Tx>:</b> <Tx>{p.before}</Tx></p>}
    <Intro lang={lang} profile={profile} id={'page_' + page} lede={p.does} />
    <div className="page-tags">{p.tags.map(([k, txt]) => { const ks = kindsOf(k); return <span key={txt} className={'tag ' + ks.join(' ')} title={ks.map(x => s.tagHelp[x]).join(' · ') || undefined}>{ks.map(x => <span key={x} className="pt-ic" role="img" aria-label={s.tags[x]}><StatusIcon flag={x} /></span>)}<Tx>{txt}</Tx></span>; })}
      <details><summary><Tx>{s.legend}</Tx></summary><Legend lang={lang} flags={Object.keys(s.tags)} strings={s} />{SUBS[page] && <p className="sb-leg sb-strip"><Tx>{profile === YL ? NEEDS_COPY.yl.help : NEEDS_COPY.help}</Tx></p>}</details></div><FilterNotice lang={lang} /></section>;
}

export function StoryPager({ lang, page, setPage, profile = stepAudience() }) {
  const s = storyFor(lang, profile), i = PAGES.indexOf(page), prev = PAGES[i - 1], next = PAGES[i + 1];
  return <div className="story-pager"><div>{prev && <button className="pg-prev" onClick={() => setPage(prev)}><Tx>{s.prev}</Tx>: <Tx>{s.nav[prev]}</Tx></button>}</div>
    <div>{next && <button className="pg-next" onClick={() => setPage(next)}><span className="pg-to"><Tx>{s.next}</Tx>: <Tx>{s.nav[next]}</Tx></span><small><Tx>{s.pages[page].after}</Tx></small></button>}</div></div>;
}
