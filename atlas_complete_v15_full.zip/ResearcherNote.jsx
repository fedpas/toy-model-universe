// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useEffect, useRef, useState } from 'react';
import { NOTE_TEXT as T, noteOf, slugOf } from './researcherNotes.js';
import { StatusIcon } from './StatusBadge.jsx';

// "Note to the researcher": a pop-up opened by the address  <atlas>/?for=<name>  (for example ?for=furey). It sits over whatever page is showing and touches nothing under it:
// the page, the tabs and the hash routes work as before, and closing the note removes ?for= from the address and leaves the reader where they are. A link inside the note is an ordinary hash link.
// Keyboard: the focus moves into the note, Tab stays inside it, Escape closes it. English only (the notes are written for the researchers whose work the atlas rebuilds).
const STYLE = `
.rn-overlay{position:fixed;inset:0;z-index:110;display:flex;justify-content:center;align-items:flex-start;overflow-y:auto;overflow-x:hidden;padding:16px;box-sizing:border-box;background:rgba(5,8,18,.72)}
.rn-dialog{position:relative;box-sizing:border-box;width:100%;max-width:780px;margin:auto;padding:18px 22px 22px;background:var(--bg,#0b1020);color:inherit;border:1px solid rgba(128,128,128,.45);border-radius:14px;box-shadow:0 12px 40px rgba(0,0,0,.45);overflow-wrap:anywhere}
.rn-dialog:focus{outline:none}
.rn-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}.rn-head h2{margin:0;font-size:1.3em}
.rn-x{flex:0 0 auto;background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;color:inherit;cursor:pointer;font:inherit;line-height:1;padding:6px 10px;min-width:36px;min-height:36px}
.rn-dialog p{margin:.6em 0;line-height:1.5}.rn-who,.rn-scope{font-size:.88em;opacity:.85}.rn-lead{font-size:1.02em}
.rn-dialog h3{margin:1.3em 0 .4em;font-size:1.02em;letter-spacing:.02em}
.rn-dialog ol,.rn-dialog ul{margin:.3em 0;padding-left:1.3em}.rn-dialog li{margin:.55em 0;line-height:1.45}
.rn-tag{display:inline-flex;align-items:center;justify-content:center;margin-right:7px;padding:1px 6px;border-radius:999px;border:1px solid;line-height:1;vertical-align:-.2em;white-space:nowrap}
.rn-tag svg{display:block}
.rn-tag.checked{color:#34d399}.rn-tag.standard{color:#60a5fa}.rn-tag.ours{color:#fbbf24}.rn-tag.open{color:#f87171}.rn-tag.input{color:#c4b5fd}
.rn-dialog a.rn-go{color:#7fb2ff;text-decoration:underline;cursor:pointer;font-weight:600}
.rn-dialog a:focus-visible,.rn-dialog button:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.rn-actions{display:flex;flex-wrap:wrap;gap:10px;align-items:center;margin-top:1.2em}
.rn-btn{background:none;border:1px solid rgba(128,128,128,.55);border-radius:8px;color:inherit;cursor:pointer;font:inherit;padding:8px 14px}.rn-btn.main{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.rn-mini{font-size:.82em;opacity:.8}
@media(max-width:480px){.rn-overlay{padding:8px}.rn-dialog{padding:14px 14px 18px}}
`;

const read = () => { try { return slugOf(new URLSearchParams(window.location.search).get('for')); } catch { return null; } };
const hrefOf = go => '#' + go;
const joinNames = names => (names.length <= 1 ? names.join('') : names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1]);
// the status of a line is a badge (icon), never a word: the word is the accessible name and the hover text
const Tag = ({ k }) => <span className={'rn-tag ' + k} data-flag={k} role="img" aria-label={k} title={k + ': ' + T.tagHelp[k]}><StatusIcon flag={k} size={13} /></span>;

export default function ResearcherNote({ lang, onContact }) {
  const [slug, setSlug] = useState(read), ref = useRef(null);
  useEffect(() => { const f = () => setSlug(read()); window.addEventListener('popstate', f); return () => window.removeEventListener('popstate', f); }, []);
  useEffect(() => { if (slug && ref.current) ref.current.focus(); }, [slug]);
  const entry = slug ? noteOf(slug) : null;
  if (!entry) return null;
  const close = after => {
    try { history.replaceState(null, '', window.location.pathname + window.location.hash); } catch { /* ignore */ }
    setSlug(null);
    if (after) after();
  };
  const toTop = () => setTimeout(() => { try { window.scrollTo(0, 0); } catch { /* ignore */ } }, 30);
  const keys = e => {
    if (e.key === 'Escape') { e.stopPropagation(); close(); return; }
    if (e.key !== 'Tab' || !ref.current) return;
    const els = [...ref.current.querySelectorAll('a[href],button')].filter(x => !x.disabled);
    if (!els.length) return;
    const first = els[0], last = els[els.length - 1], cur = document.activeElement;
    if (e.shiftKey && (cur === first || cur === ref.current)) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && cur === last) { e.preventDefault(); first.focus(); }
  };
  const n = entry.note, names = entry.people.filter(p => p.role !== 'cc').map(p => p.name), link = (go, text) => <a className="rn-go" href={hrefOf(go)} onClick={() => close(toTop)}>{text}</a>;
  return <div className="rn-overlay" data-researcher={entry.slug} onKeyDown={keys} onMouseDown={e => { if (e.target === e.currentTarget) close(); }}><style>{STYLE}</style>
    <div className="rn-dialog" role="dialog" aria-modal="true" aria-labelledby="rn-title" tabIndex={-1} ref={ref}>
      <div className="rn-head"><h2 id="rn-title">{T.title(joinNames(names))}</h2><button className="rn-x" aria-label="Close" onClick={() => close()}>×</button></div>
      <p className="rn-who">{T.who}</p><p className="rn-scope">{T.scope}</p>
      <p className="rn-lead">{n.lead}</p>
      <h3>{T.first}</h3>
      <ul>{entry.hooks.map((h, i) => <li key={i}><Tag k={h.tag} />{h.text} {link(h.go, T.openIn + ' →')}</li>)}</ul>
      <h3>{T.path}</h3>
      <ol>{n.path.map((p, i) => <li key={i}>{link(p.go, p.title)} {(p.parts || [p]).map((x, j) => <React.Fragment key={j}>{j > 0 && ' '}{(x.tags || []).map(k => <Tag key={k} k={k} />)}{x.text || x.what}</React.Fragment>)}</li>)}</ol>
      <h3>{T.standard}</h3><p>{n.standard}</p>
      <h3>{T.check}</h3><ul>{n.check.map((c, i) => <li key={i}>{c}</li>)}</ul>
      <h3>{T.unread}</h3><p>{n.unread}</p>
      <div className="rn-actions">
        <button className="rn-btn main" onClick={() => close(() => { if (onContact) onContact(); })}>{T.write}</button>
        <button className="rn-btn" onClick={() => close(toTop)}>{T.close}</button>
        {lang === 'it' && <span className="rn-mini">English only.</span>}
      </div>
    </div></div>;
}

