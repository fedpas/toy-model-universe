// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Can the browser tests start their browser here? Starts Chromium exactly as the tests do (ui_helpers.mjs tryLaunch: playwright's defaults), opens a blank page and closes it.
// Prints "browser ok: Chromium <version>" and exits 0, or prints one line with the reason and exits 1; it gives up after 20 s. run_tests.sh --ci runs it before the browser group.
// ATLAS_BROWSER_FAIL=<reason> fails with that reason and starts nothing.   Run: node browser_probe.mjs
const timer = setTimeout(() => { console.log('Chromium did not start within 20 s'); process.exit(1); }, 20000);
let H;
try { H = await import('./ui_helpers.mjs'); } catch (e) { console.log('playwright cannot be loaded (' + String((e && e.message) || e).split('\n')[0].slice(0, 200) + '); npm install brings it'); process.exit(1); }
const r = await H.tryLaunch();
if (!r.browser) { console.log(r.reason); process.exit(1); }
try { const pg = await r.browser.newPage(); await pg.close(); console.log('browser ok: Chromium ' + r.browser.version()); await r.browser.close(); }
catch (e) { console.log(H.launchReason(e)); process.exit(1); }
clearTimeout(timer); process.exit(0);
