// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The files a module reaches through its relative imports (static, dynamic and re-exports), found by reading the sources: what the build bundles is what this returns.
// reachable('App.jsx') -> { files: Set of package-relative paths, missing: [[importer, specifier]], external: Set of bare specifiers, outside: [[importer, specifier]] (a relative import that
// leaves the package folder: not followed), absolute: [[importer, specifier]] (an import by absolute path or file: URL: not followed) }. Used by test_package.mjs.
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
const EXT = ['', '.js', '.jsx', '.mjs', '.cjs', '.json'];
const SPEC = /(?:import|export)\s+(?:[^'"()]*?\s+from\s+)?['"]([^'"]+)['"]|import\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
export const ABSOLUTE_SPEC = /^(\/|[A-Za-z]:[\\/]|file:|~)/;
const resolve = (from, spec) => { const base = path.resolve(path.dirname(from), spec); for (const e of EXT) { const p = base + e; if (fs.existsSync(p) && fs.statSync(p).isFile()) return p; } return null; };
const inside = p => { const r = path.relative(PKG, p); return r !== '' && !r.startsWith('..') && !path.isAbsolute(r); };
export function reachable(entry) {
  const files = new Set(), missing = [], external = new Set(), outside = [], absolute = [], todo = [path.resolve(PKG, entry)];
  while (todo.length) { const f = todo.pop(), rel = path.relative(PKG, f); if (files.has(rel)) continue; files.add(rel);
    if (!/\.(js|jsx|mjs|cjs)$/.test(f)) continue;
    const src = fs.readFileSync(f, 'utf8').replace(/\/\*[\s\S]*?\*\//g, '').replace(/(^|[^:'"`])\/\/[^\n]*/g, '$1');
    for (const m of src.matchAll(SPEC)) { const spec = m[1] || m[2]; if (ABSOLUTE_SPEC.test(spec)) { absolute.push([rel, spec]); continue; } if (!spec.startsWith('.')) { external.add(spec); continue; }
      if (!inside(path.resolve(path.dirname(f), spec))) { outside.push([rel, spec]); continue; }
      const r = resolve(f, spec); if (r) todo.push(r); else missing.push([rel, spec]); } }
  return { files, missing, external, outside, absolute, has: x => files.has(x) };
}
