// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Data test of the mathematics bridge scripts, selfcheck/bridges/{mat,geo,alg,cat,xck,hh,rev,tor,en,fur,kep,mjc,mja,mjg}_*.py. No browser.
// Run: node test_bridges_math.mjs   (about 8 minutes on one idle core: every script runs once, then one sabotaged copy of each script of the families
//                                    mat to kep, then every script of the families mjc, mja, mjg with --sabotage)
//      node test_bridges_math.mjs --citations   only the parts that read files (2, 3, 5): the ids, the scripts' sources and the citations, in a few seconds
// 1. a fresh run of every script, from a folder outside the package: it exits 0, prints one `ok   <id>  <text>` line per check and its verdict line,
//    and its rows (id, script, text, ok) and info lines equal selfcheck/bridges/bridges_math.json (the seconds are not compared)
// 2. the ids: exactly the pinned set for the fourteen families, unique, each in its own family; every id of the README section "Mathematics" is a row or
//    an info line, every row and info line is in the README
// 3. the scripts: the three-line header, the allowed imports (standard library; numpy and scipy only where listed, and used there), no file, process or
//    network access, no forbidden word (in the scripts, the README section and the printed texts; the families mjc, mja, mjg and their README lines
//    also pass a stricter list)
// 4. sabotage: one documented one-line change per script of the families mat to kep breaks what one check computes; the copy must exit 1 with FAIL for
//    that id; every script of the families mjc, mja, mjg runs with --sabotage (each check on a broken input) and must exit 0 with one CAUGHT line per
//    check row of the json and no MISSED line
// 5. citations: every bd·<family>·n id that a file of the package cites (a range a–b: every number in it) is a row (or an info line) of the json; a checkedBy
//    or checks field of a JSON file (claims locators, lens dictionary, ...) cites rows only (never an info line) and names the script that prints the id;
//    the scan is tested on a planted bad citation of each kind first
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs'; process.chdir(PKG);
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const DIR = 'selfcheck/bridges', JSON_FILE = path.join(DIR, 'bridges_math.json'), README = path.join(DIR, 'README.md'), REGEN = 'selfcheck/regen_bridges_math.sh';
const OLD = ['mat', 'geo', 'alg', 'cat', 'xck', 'hh', 'rev', 'tor', 'en', 'fur', 'kep'], NEW = ['mjc', 'mja', 'mjg'], FAMILIES = [...OLD, ...NEW], ALL = FAMILIES;
const ID_RE = new RegExp(`bd·(${ALL.join('|')})·(\\d+)`, 'g');
const CITE_SRC = `bd·(${ALL.join('|')})·(\\d+)(?:\\s*[–-]\\s*(\\d+)(?![\\d·]))?`;   // a single id or a range a–b (every number in it is cited)
const expand = (fam, a, b) => b === undefined ? [`bd·${fam}·${a}`] : [...Array(Math.max(0, +b - +a + 1))].map((_, i) => `bd·${fam}·${+a + i}`);
const py = (args, cwd) => spawnSync('python3', ['-I', ...args], { cwd, encoding: 'utf8', timeout: 600000 });
const scripts = ALL.flatMap(p => fs.readdirSync(DIR).filter(f => f.startsWith(p + '_') && f.endsWith('.py')).sort());
const J = JSON.parse(fs.readFileSync(JSON_FILE, 'utf8')), CITATIONS_ONLY = process.argv.includes('--citations');

// ---- 1. a fresh run equals the stored log
const LINE = /^(ok  |FAIL) (bd·[a-z]+·\d+)  (.*)$/, INFO = /^info (bd·[a-z]+·\d+)  (.*)$/, VERDICT = /^(\d+)\/(\d+) bridge checks hold\.  ALL BRIDGE CHECKS PASS$/;
const fresh = [], freshInfo = [], outside = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-run-'));
if (!CITATIONS_ONLY) try {
  for (const f of scripts) {
    const r = py([path.join(PKG, DIR, f)], outside), out = (r.stdout || '').split('\n');
    ok(r.status === 0, `${f} exits 0 when run from a folder outside the package (exit ${r.status}) ${(r.stderr || '').slice(-300)}`);
    const mine = [];
    for (const l of out) { let m = LINE.exec(l); if (m) { mine.push({ id: m[2], script: f, text: m[3], ok: m[1] === 'ok  ' }); continue; } m = INFO.exec(l); if (m) freshInfo.push({ id: m[1], script: f, text: m[2] }); }
    const last = out.filter(l => l.trim()).pop() || '', v = VERDICT.exec(last);
    ok(v && +v[1] === mine.length && +v[2] === mine.length && mine.length > 0, `${f} prints its verdict line, counting its ${mine.length} rows: ${last.slice(0, 120)}`);
    ok(mine.every(x => x.ok), `${f}: every check passes: ${mine.filter(x => !x.ok).map(x => x.id).join(', ')}`);
    fresh.push(...mine);
  }
} finally { fs.rmSync(outside, { recursive: true, force: true }); }
else fs.rmSync(outside, { recursive: true, force: true });
const strip = rows => JSON.stringify(rows.map(({ id, script, text, ok }) => ({ id, script, text, ok })));
ok(scripts.length === 47 && J.summary.scripts.map(s => s.script).join(',') === scripts.join(','), `the json lists the ${scripts.length} scripts in the order of the regen script`);
if (!CITATIONS_ONLY) ok(strip(J.rows) === strip(fresh), 'the rows of bridges_math.json (id, script, text, ok) equal a fresh run' + (strip(J.rows) === strip(fresh) ? '' : ': first difference at ' + (J.rows.findIndex((r, i) => strip([r]) !== strip([fresh[i] || {}]))) ));
if (!CITATIONS_ONLY) ok(JSON.stringify(J.summary.info) === JSON.stringify(freshInfo), 'the info lines of the json equal a fresh run');
ok(J.summary.rows === J.rows.length && J.summary.ok === J.rows.length && J.rows.every(r => r.ok === true && typeof r.seconds === 'number' && r.text.length > 40), 'the summary counts the rows, all pass, each has its seconds and says what it computes');
ok(fs.existsSync(REGEN) && /bridges_math\.json/.test(fs.readFileSync(REGEN, 'utf8')) && /set -e/.test(fs.readFileSync(REGEN, 'utf8')), 'selfcheck/regen_bridges_math.sh exists, writes bridges_math.json and stops at the first error');

// ---- 2. the ids
const ids = J.rows.map(r => r.id), infoIds = J.summary.info.map(i => i.id), known = new Set([...ids, ...infoIds]);
const PINNED = { mat: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 16, 17, 18, 19], geo: [...Array(17)].map((_, i) => i + 1), alg: [...Array(24)].map((_, i) => i + 1), cat: [...Array(23)].map((_, i) => i + 1),
  xck: [...Array(8)].map((_, i) => i + 1), hh: [...Array(6)].map((_, i) => i + 1), rev: [...Array(6)].map((_, i) => i + 1),
  tor: [...Array(7)].map((_, i) => i + 1), en: [...Array(6)].map((_, i) => i + 1), fur: [...Array(5)].map((_, i) => i + 1), kep: [...Array(6)].map((_, i) => i + 1),
  mjc: [...Array(37)].map((_, i) => i + 1).filter(k => k !== 14), mja: [...Array(37)].map((_, i) => i + 1).filter(k => k !== 34),
  mjg: [...Array(33)].map((_, i) => i + 1).filter(k => ![8, 15, 21, 31].includes(k)) };
const want = Object.entries(PINNED).flatMap(([p, ns]) => ns.map(k => `bd·${p}·${k}`)).sort(), have = ids.filter(i => FAMILIES.some(p => i.startsWith(`bd·${p}·`))).sort();
ok(JSON.stringify(have) === JSON.stringify(want) && want.length === 227 && have.filter(i => NEW.some(p => i.startsWith(`bd·${p}·`))).length === 101, `the rows of the fourteen families are exactly the pinned ${want.length} ids (101 of them in mjc, mja, mjg): missing ${want.filter(i => !have.includes(i)).join(' ')}; extra ${have.filter(i => !want.includes(i)).join(' ')}`);
ok(JSON.stringify(infoIds) === JSON.stringify(['bd·mat·14', 'bd·mjc·38', 'bd·mjc·14', 'bd·mja·34', 'bd·mjg·21', 'bd·mjg·15', 'bd·mjg·31', 'bd·mjg·8']),
   'the info lines are exactly bd·mat·14 (a read-off of the signature formulas) and the seven read-offs, definitions and readings of the families mjc, mja, mjg: ' + infoIds.join(' '));
ok(new Set([...ids, ...infoIds]).size === ids.length + infoIds.length, 'no id is printed twice');
ok([...J.rows, ...J.summary.info].every(r => r.id.startsWith('bd·' + r.script.split('_')[0] + '·')), 'every id belongs to the family of the script that prints it');
const RD = fs.readFileSync(README, 'utf8'), start = RD.indexOf('## Mathematics'), next = RD.indexOf('\n## ', start + 5), SEC = start < 0 ? '' : RD.slice(start, next < 0 ? undefined : next);
ok(start >= 0, 'selfcheck/bridges/README.md has the section "## Mathematics"');
const readmeIds = new Set([...SEC.matchAll(ID_RE)].map(m => m[0]).filter(i => !/·n$/.test(i)));
const tableIds = new Set([...SEC.matchAll(/^\| `(bd·[a-z]+·\d+)` \| `([a-zA-Z0-9_]+\.py)` \|/gm)].map(m => m[1] + '@' + m[2]));
ok([...readmeIds].every(i => known.has(i)), 'every id the README section names is a row or an info line: ' + [...readmeIds].filter(i => !known.has(i)).join(' '));
ok(J.rows.every(r => tableIds.has(r.id + '@' + r.script)), 'every row has its line in the README table, with its script: ' + J.rows.filter(r => !tableIds.has(r.id + '@' + r.script)).map(r => r.id).join(' '));
ok(tableIds.size === J.rows.length, `the README table has one line per row (${tableIds.size} lines, ${J.rows.length} rows)`);
ok(infoIds.every(i => new RegExp('^- `' + i + '`', 'm').test(SEC)), 'every info line is listed under "Info lines" in the README section');

// ---- 3. the scripts
const SPDX = ['# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', '# Required Notice: Copyright (c) 2026 the Cascade Atlas authors', '# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)'];
const STD = new Set(['sys', 'itertools', 'fractions', 'math', 'random', 'functools', 'collections', 'array']), SCIPY = new Set(['mjc_sum.py', 'mjc_weight.py']);
const NUMPY = new Set(['alg_finite_fields.py', 'alg_octonion.py', 'geo_cartan.py', 'mjc_labels.py', 'mja_catalg.py', 'mja_incidence.py', 'mja_semiring.py',
  'mjg_frames.py', 'mjg_positions.py', 'mjg_topology.py', 'mjg_vectors.py']);
const FORBIDDEN = [/rv·/, /disc·/, /P_all/, /P_str/, /P_ss/, /M_all/, /M_geo/, /M_alg/, /M_cat/, /\breview(s|ed|er|ers)?\b/i, /\bspecialists?\b/i, /\blanes?\b/i, /\bmerg(e|ed|es|ing)\b/i, /\bearlier\b/i, /\bpreviously\b/i, /\bcorrected\b/i, /\bwithdrawn\b/i,
  // the process words: lane ids, a seed of a brief, history words (round as a word, not the function round(); fixed and new only in their history sense)
  /\b(MC|MA|MG|MP|MERGE)\b/, /\bseeds? S\d/i, /\bno longer\b/i, /\bnow\b/i, /\bround\b(?!\s*\()(?!\s+spheres?\b)/i, /\b(was|were|been|got) fixed\b/i,
  /\b(the|a|is|are) new (check|script|id|line|clause|version|wording|reading|sabotage|statement|row|test)s?\b|\bnew in\b/i];
const forbiddenIn = t => FORBIDDEN.filter(re => re.test(t)).map(re => re.source);
// the families mjc, mja, mjg (scripts, printed texts, their README lines) pass a stricter list: new and now in any sense, round as a word, the word inventory
const STRICT = [/\bnew\b/i, /\bnow\b/i, /\bround\b(?!\s*\()/i, /\binventory\b/i];
const strictIn = t => [...forbiddenIn(t), ...STRICT.filter(re => re.test(t)).map(re => re.source)];
const isNew = f => NEW.some(p => f.startsWith(p + '_'));
for (const f of scripts) {
  const src = fs.readFileSync(path.join(DIR, f), 'utf8'), head = src.split('\n').slice(0, 6).join('\n');
  ok(SPDX.every(l => head.includes(l)), `${f} carries the three-line header`);
  const imports = [...src.matchAll(/^\s*import\s+([\w., ]+)$/gm)].flatMap(m => m[1].split(',').map(x => x.trim().split(/\s+/)[0].split('.')[0])).concat([...src.matchAll(/^\s*from\s+([\w.]+)\s+import\b/gm)].map(m => m[1].split('.')[0]));
  const allowed = x => STD.has(x) || (x === 'numpy' && NUMPY.has(f)) || (x === 'scipy' && SCIPY.has(f));
  ok(imports.length > 0 && imports.every(allowed), `${f} imports only ${NUMPY.has(f) ? 'the standard library and numpy' : SCIPY.has(f) ? 'the standard library and scipy' : 'the standard library'}: ${[...new Set(imports)].join(', ')}`);
  ok((!NUMPY.has(f) || imports.includes('numpy')) && (!SCIPY.has(f) || imports.includes('scipy')), `${f}: the module the list allows it is the module it imports (numpy, scipy): ${[...new Set(imports)].join(', ')}`);
  ok(!/\bopen\(|\bsubprocess\b|\bsocket\b|\burllib\b|\bshutil\b|\bpathlib\b|\bos\.|\bjson\.dump|\.write\(/.test(src), `${f} reads and writes no file, starts no process and opens no connection`);
  ok(!/(^|[^\w.])random\.(random|randint|choice|choices|shuffle|sample|uniform|seed|getrandbits)\(|np\.random\.(rand|randint|normal|random)\(/m.test(src) && (!/\bimport random\b|\bimport [\w, ]*\brandom\b/.test(src) || /random\.Random\(/.test(src)) && (!/\bnumpy\b/.test(src) || !/np\.random\./.test(src) || /default_rng\(\d/.test(src)), `${f}: randomness only from generators with fixed seeds (no call of the module-level generator)`);
  ok(forbiddenIn(src).length === 0, `${f} has no forbidden word: ${forbiddenIn(src).join(' ')}`);
  if (isNew(f)) ok(strictIn(src).length === 0, `${f} passes the stricter word list: ${strictIn(src).join(' ')}`);
}
ok(NUMPY.size === 11 && SCIPY.size === 2 && [...NUMPY, ...SCIPY].every(f => scripts.includes(f)), 'the numpy list (11 scripts) and the scipy list (mjc_sum.py, mjc_weight.py) name scripts of the folder');
{ const mine = SEC.split('\n').filter(l => /bd·mj[cag]·|mj[cag]_/.test(l)), bad = mine.filter(l => strictIn(l).length);
  ok(mine.length >= 101 + 7 && bad.length === 0, `the README lines of the families mjc, mja, mjg (${mine.length}) pass the stricter word list: ` + bad.map(l => l.slice(0, 60)).join(' | ')); }
ok([...J.rows, ...J.summary.info].filter(r => isNew(r.script)).every(r => strictIn(r.text).length === 0), 'no printed text of the families mjc, mja, mjg has a word of the stricter list: ' + [...J.rows, ...J.summary.info].filter(r => isNew(r.script) && strictIn(r.text).length).map(r => r.id).join(' '));
ok(forbiddenIn(SEC).length === 0, 'the README section has no forbidden word: ' + forbiddenIn(SEC).join(' '));
ok([...J.rows, ...J.summary.info].every(r => forbiddenIn(r.text).length === 0), 'no printed text has a forbidden word: ' + [...J.rows, ...J.summary.info].filter(r => forbiddenIn(r.text).length).map(r => r.id).join(' '));
ok(forbiddenIn('the rv·M_all·3 check, merged by a reviewer, as corrected earlier').length >= 5 && forbiddenIn('xck_merge.py on the totally null plane').length === 0, 'the forbidden-word scan catches a planted sentence and passes the script name xck_merge.py and the word "plane"');
ok(forbiddenIn('the MC part of seed S2, no longer the new check; now it is fixed after the round').length >= 5 && forbiddenIn('round(x, 1) on the round sphere; generators with fixed seeds; the point fixed by the rotor; a new basis vector').length === 0
   && strictIn('a new basis vector, now').length >= 2 && strictIn('new_rows = round(x, 1)').length === 0, 'the process words are caught (lane ids, a seed of a brief, no longer, now, round as a word, fixed and new in their history sense) and their mathematical uses pass; the stricter list catches new and now');

// ---- 4. sabotage: one documented one-line change per script; the copy must stop with FAIL for the targeted id
const SABOTAGE = [
  ['mat_cell_classification.py', 'the norm of Z^n in place of the norm of I_{p,q}', 'xx = sum(e[i] for i in range(n) if a >> i & 1)', 'xx = sum(1 for i in range(n) if a >> i & 1)', 'bd·mat·7'],
  ['mat_degenerate_cell.py', 'the coset of the labels carrying every null bit in place of the quotient labels', 'S_pat = gsum([w4(a, e) for a in range(1 << n) if a & N == 0])', 'S_pat = gsum([w4(a, e) for a in range(1 << n) if a & N == N])', 'bd·mat·3'],
  ['mat_null_part.py', 'the ungraded operators e_a x e_b (no Koszul sign)', 'M[(a ^ x ^ b) * Nn + x] = s1 * s2 * (-1) ** (pc(b) * pc(x))', 'M[(a ^ x ^ b) * Nn + x] = s1 * s2', 'bd·mat·10'],
  ['mat_En_in_Cl1n.py', 'k = (1; -1^n) in place of (3; -1^n)', 'G = gram_I1n(n); k = [3] + [-1] * n', 'G = gram_I1n(n); k = [1] + [-1] * n', 'bd·mat·17'],
  ['mat_En_trio.py', 'vectors of norm -1 in place of the roots', 'target_sq = x0 * x0 + 2; target_sum = -3 * x0', 'target_sq = x0 * x0 + 1; target_sum = -3 * x0', 'bd·mat·13'],
  ['mat_codes_misc.py', 'the binary Q in place of the Z_4 form w', 'dw, Ww = max_isotropic_dim(n, lambda a: w4(a, e) == 0)', 'dw, Ww = max_isotropic_dim(n, lambda a: Q(a, e) == 0)', 'bd·mat·15'],
  ['geo_pin.py', 'the Gauss sum of 2Q, without the parity term of w', 'k = phase8(gsum([w4(a, e) for a in range(1 << n)]), n)', 'k = phase8(gsum([(2 * Q(a, e)) % 4 for a in range(1 << n)]), n)', 'bd·geo·2'],
  ['geo_lorentz.py', 'a change of the right reference without the compensating psi -> psi L~', 'psir = st.mul(psi, rev(L))', 'psir = psi', 'bd·geo·11'],
  ['geo_cartan.py', 'the extra generator with the opposite square', 'cl = Cl(eps + [s]); nn = d', 'cl = Cl(eps + [-s]); nn = d', 'bd·geo·13'],
  ['geo_kepler.py', 'a wrong p0 for the bound orbit', 'p0 = (k / L) * Fr(4, 5)', 'p0 = (k / L) * Fr(3, 5)', 'bd·geo·17'],
  ['alg_core_bw.py', 'the right action without the grade twist', 'Rs = [(1 << i, [sgn(a, 1 << i, e) * (-1) ** pc(a) for a in range(N)]) for i in range(n)]', 'Rs = [(1 << i, [sgn(a, 1 << i, e) for a in range(N)]) for i in range(n)]', 'bd·alg·9'],
  ['alg_finite_fields.py', '"trivial" read as "the volume element squares to +1" in place of "to a square of F_l"', 'trivial = is_square(z2, l)', 'trivial = (z2 == 1)', 'bd·alg·19'],
  ['alg_groups.py', 'the blade group without its sign cocycle', 'def mul(x, y): return (x[0] * y[0] * sgn(x[1], y[1], e), x[1] ^ y[1])', 'def mul(x, y): return (x[0] * y[0], x[1] ^ y[1])', 'bd·alg·10'],
  ['alg_octonion.py', 'the split octonions in place of the octonions', 'S = sign_table(table_from([-1, -1, -1]))\n    if S is None: ok = False', 'S = sign_table(table_from([-1, -1, 1]))\n    if S is None: ok = False', 'bd·alg·14'],
  ['cat_cell.py', 'a wrong mother cell Cl(p+2r, q)', 'Smother = gsum([wD(a, sig(p + r, q + r)) for a in range(1 << (n + r))])', 'Smother = gsum([wD(a, sig(p + 2 * r, q)) for a in range(1 << (n + r))])', 'bd·cat·4'],
  ['cat_cohomology.py', 'a coboundary without its term beta(a xor b)', 'if ((x == t) + (y == t) + ((x ^ y) == t)) % 2: rw ^= 1 << idx[(x, y)]', 'if ((x == t) + (y == t)) % 2: rw ^= 1 << idx[(x, y)]', 'bd·cat·19'],
  ['cat_frobenius.py', 'lambda(e_b e_a) replaced by lambda(e_a e_b) (a symmetric, not super-symmetric, test)', 'lab, lba = sgn(a, b, e), sgn(b, a, e)', 'lab, lba = sgn(a, b, e), sgn(a, b, e)', 'bd·cat·5'],
  ['cat_functor.py', 'the mother map z -> f+ (not f+ - f-)', '[{1 << (m + j): 1, 1 << (m + r + j): -1} for j in range(r)]', '[{1 << (m + j): 1} for j in range(r)]', 'bd·cat·17'],
  ['cat_modular.py', 'theta = i^(2Q), without the parity term of w', 'def w(a, e): return (pc(a) % 2 + 2 * Q(a, e)) % 4', 'def w(a, e): return (2 * Q(a, e)) % 4', 'bd·cat·12'],
  ['cat_morita.py', 'the trace-form invariant without the reversion split', 'if pc(a) % 2 == par and (-1) ** (pc(a) * (pc(a) - 1) // 2) == rs]', 'if pc(a) % 2 == par and 1 == rs]', 'bd·cat·10'],
  ['xck_merge.py', 'a wrong mother cell Cl(p+2r, q)', 'mother = gsum([w4(a, sig(p + r, q + r)) for a in range(1 << (n + r))])', 'mother = gsum([w4(a, sig(p + 2 * r, q)) for a in range(1 << (n + r))])', 'bd·xck·3'],
  ['hh_graded.py', 'a fibre with a null generator, not separable (its groups do not vanish)', '\n        epsA = sig(p, q); epsM = sig(p, q, r)\n', '\n        epsA = sig(p, q)[:-1] + [0]; epsM = epsA + [0] * r\n', 'bd·hh·3'],
  ['rev_reversion.py', 'the dagger in place of the reversion in the classification', 'complete, cf, eqf, eqt, lines = decide(name)', "complete, cf, eqf, eqt, lines = decide('dag')", 'bd·rev·3'],
  ['tor_orbits.py', 'two time directions, Cl(2,n-2) in place of Cl(1,n-1)', 'eps = [1] + [-1] * (n - 1) if not sab else [1, 1] + [-1] * (n - 2)', 'eps = [1, 1] + [-1] * (n - 2)', 'bd·tor·1'],
  ['en_weyl.py', 'the image of the reflections without s_0 (the branch node) in place of W(E_n)', '        else:\n            d = image_data(n)\n', '        else:\n            d = image_data(n, drop=0)\n', 'bd·en·2'],
  ['fur_commutant.py', 'the gauge algebra without the hypercharge generator', "def check2(sab=False):\n    su3, su2, u1, Y = gauge_algebra('drop_Y' if sab else None)", "def check2(sab=False):\n    su3, su2, u1, Y = gauge_algebra('drop_Y')", 'bd·fur·2'],
  ['kep_fock.py', 'the extra square s = eps in place of s = -eps', 's_of = {eps: -eps for eps in (1, 0, -1)} if not sab else {eps: eps for eps in (1, 0, -1)}', 's_of = {eps: eps for eps in (1, 0, -1)}', 'bd·kep·5'],
];
ok(OLD.every(p => scripts.filter(f => f.startsWith(p + '_')).every(f => SABOTAGE.some(s => s[0] === f))), 'every script of the eleven families mat to kep has a one-line sabotage: ' + scripts.filter(f => OLD.some(p => f.startsWith(p + '_')) && !SABOTAGE.some(s => s[0] === f)).join(', '));
// the families mjc, mja, mjg: python3 -I <script> --sabotage runs every check on a broken input and prints CAUGHT <id> (or MISSED <id>) per check; [script, number of checks]
const SAB_MODE = [['mjc_comma.py', 3], ['mjc_labels.py', 8], ['mjc_ladder.py', 4], ['mjc_nerve.py', 5], ['mjc_sheaf.py', 6], ['mjc_sum.py', 5], ['mjc_weight.py', 5],
  ['mja_catalg.py', 6], ['mja_exterior.py', 9], ['mja_incidence.py', 7], ['mja_ladder.py', 3], ['mja_norms.py', 5], ['mja_semiring.py', 3], ['mja_zero.py', 3],
  ['mjg_cube.py', 4], ['mjg_frames.py', 4], ['mjg_ladder.py', 2], ['mjg_positions.py', 8], ['mjg_topology.py', 7], ['mjg_vectors.py', 4]];
ok(JSON.stringify(SAB_MODE.map(x => x[0]).sort()) === JSON.stringify(scripts.filter(isNew).sort()) && SAB_MODE.reduce((a, x) => a + x[1], 0) === 101
   && SAB_MODE.every(([f, k]) => J.rows.filter(r => r.script === f).length === k), 'every script of the families mjc, mja, mjg is in the --sabotage table, with its number of check rows (101 in all): '
   + SAB_MODE.filter(([f, k]) => J.rows.filter(r => r.script === f).length !== k).map(x => x[0]).join(', '));
if (!CITATIONS_ONLY) { const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-sab-')); try {
    for (const [f, label, from, to, id] of SABOTAGE) {
      const src = fs.readFileSync(path.join(DIR, f), 'utf8');
      ok(src.split(from).length === 2, `${f}: the line to break (${label}) is in the script exactly once`);
      const mut = path.join(tmp, 'mut_' + f); fs.writeFileSync(mut, src.replace(from, () => to));
      const r = py([mut], tmp), out = (r.stdout || '') + (r.stderr || '');
      ok(r.status === 1 && out.includes('FAIL ' + id + '  ') && /SOME BRIDGE CHECK FAILED/.test(out), `${f} with ${label}: exits 1 and ${id} fails (exit ${r.status})`);
      ok(fs.readFileSync(path.join(DIR, f), 'utf8') === src, `${f}: the package script was not touched`);
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  const tmp2 = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-sabmode-')); try {
    for (const [f, k] of SAB_MODE) {
      const r = py([path.join(PKG, DIR, f), '--sabotage'], tmp2), out = r.stdout || '', last = out.trim().split('\n').pop() || '';
      const caught = [...out.matchAll(/^CAUGHT (bd·[a-z]+·\d+)(?=\s|$)/gm)].map(m => m[1]), rowsOf = J.rows.filter(x => x.script === f).map(x => x.id);
      ok(r.status === 0 && !/^MISSED /m.test(out) && /^ALL (SABOTAGES )?CAUGHT$/.test(last) && caught.length === k && JSON.stringify([...caught].sort()) === JSON.stringify([...rowsOf].sort()),
         `${f} --sabotage: exit 0, one CAUGHT line for each of its ${k} checks and no MISSED (exit ${r.status}, ${caught.length} caught, last line: ${last.slice(0, 60)})`);
    }
  } finally { fs.rmSync(tmp2, { recursive: true, force: true }); } }

// ---- 5. citations: every bd·<family>·n that a file of the package cites exists; checkedBy cites rows of the script it names
const SKIP_DIRS = new Set(['node_modules', 'dist', 'dist_real', '.git', 'test_logs', '__pycache__']);
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => SKIP_DIRS.has(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const scriptOf = new Map([...J.rows, ...J.summary.info].map(r => [r.id, r.script])), rowIds = new Set(ids);
function citations(root) {
  const problems = [];
  for (const f of walk(root).filter(f => /\.(js|jsx|mjs|cjs|json|md|py|sh|html|txt)$/.test(f) && !/(^|\/)test_[^/]*\.mjs$/.test(path.relative(root, f)))) {
    const rel = path.relative(root, f), t = fs.readFileSync(f, 'utf8');
    for (const m of t.matchAll(new RegExp(CITE_SRC, 'g'))) for (const id of expand(m[1], m[2], m[3])) if (!known.has(id)) problems.push(`${id} cited in ${rel}${m[3] === undefined ? '' : ' (in the range ' + m[0] + ')'} is not a row`);
    if (/\.json$/.test(rel) && !/^selfcheck\/bridges\/bridges_[a-z]+\.json$/.test(rel)) {   // the checkedBy and checks fields of every JSON file (claims locators, lens dictionary, ...)
      const go = v => { if (Array.isArray(v)) v.forEach(go); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) { if ((k === 'checkedBy' || k === 'checks') && typeof x === 'string') check(x); else if ((k === 'checkedBy' || k === 'checks') && Array.isArray(x) && x.every(y => typeof y === 'string')) x.forEach(check); else go(x); } };
      const check = s => { let named = null; for (const m of s.matchAll(new RegExp(`selfcheck/bridges/([A-Za-z0-9_]+\\.py)|${CITE_SRC}`, 'g'))) {
          if (m[1]) { named = m[1]; continue; }
          for (const id of expand(m[2], m[3], m[4])) {
            if (known.has(id) && !rowIds.has(id)) problems.push(`${id} is an info line, cited as a check in a checkedBy of ${rel}`);
            if (named && known.has(id) && scriptOf.get(id) !== named) problems.push(`${id} is printed by ${scriptOf.get(id)}, the checkedBy of ${rel} names ${named}`); } } };
      let parsed = null; try { parsed = JSON.parse(t); } catch { problems.push(`${rel} is not valid JSON`); }
      if (parsed) go(parsed);
    }
  }
  return problems;
}
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-cite-')); try {   // the scan sees a planted bad citation of each kind
    fs.writeFileSync(path.join(tmp, 'claimsLocators_planted.json'), JSON.stringify({ rows: [{ id: 'X-1', checkedBy: 'selfcheck/bridges/geo_pin.py, bd·geo·2, bd·mat·7' }, { id: 'X-2', checkedBy: 'selfcheck/bridges/mat_En_trio.py, bd·mat·14' }] }));
    fs.writeFileSync(path.join(tmp, 'lens_planted.json'), JSON.stringify({ entries: [{ id: 'D1', checks: ['bd·geo·13', 'bd·mat·14'] }] }));
    fs.writeFileSync(path.join(tmp, 'plantedCopy.js'), "export default { en: { tag: 'checked: selfcheck/bridges/cat_cell.py, bd·cat·99 and bd·kep·99, bd·kep·5–7' } };\n");
    fs.writeFileSync(path.join(tmp, 'test_planted.mjs'), "// bd·mat·999 in a test is not a citation\n");
    const p = citations(tmp);
    ok(p.some(x => /bd·mat·7 is printed by mat_cell_classification\.py, the checkedBy of claimsLocators_planted\.json names geo_pin\.py/.test(x)) && p.some(x => /bd·mat·14 is an info line, cited as a check in a checkedBy of claimsLocators_planted\.json/.test(x)) && p.some(x => /bd·mat·14 is an info line, cited as a check in a checkedBy of lens_planted\.json/.test(x))
       && p.some(x => /bd·cat·99 cited in plantedCopy\.js/.test(x)) && p.some(x => /bd·kep·99 cited in plantedCopy\.js/.test(x)) && p.some(x => /bd·kep·7 cited in plantedCopy\.js \(in the range bd·kep·5–7\)/.test(x)) && !p.some(x => /bd·mat·999/.test(x)) && !p.some(x => /bd·geo·2|bd·geo·13/.test(x)) && p.length === 6,
       'the citation scan flags a planted wrong script, an info line as a check (in a checkedBy string and in a checks list), two unknown ids and the missing end of a range, and nothing else: ' + p.join(' | '));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-cite-mj-')); try {   // the same scan on planted citations of the families mjc, mja, mjg
    fs.writeFileSync(path.join(tmp, 'claimsLocators_planted.json'), JSON.stringify({ rows: [{ id: 'X-3', checkedBy: 'selfcheck/bridges/mjg_cube.py, bd·mjg·9' }, { id: 'X-5', checkedBy: 'selfcheck/bridges/mjc_sum.py, bd·mjc·14' }, { id: 'X-4', checkedBy: 'selfcheck/bridges/mjc_labels.py, bd·mjc·1–8' }] }));
    fs.writeFileSync(path.join(tmp, 'plantedCopy.js'), "export default { en: { tag: 'checked: selfcheck/bridges/mja_zero.py, bd·mja·99; bd·mjc·30–39; bd·mjg·33' } };\n");
    const p = citations(tmp);
    ok(p.some(x => /bd·mjg·9 is printed by mjg_vectors\.py, the checkedBy of claimsLocators_planted\.json names mjg_cube\.py/.test(x)) && p.some(x => /bd·mjc·14 is an info line, cited as a check in a checkedBy of claimsLocators_planted\.json/.test(x))
       && p.some(x => /bd·mja·99 cited in plantedCopy\.js/.test(x)) && p.some(x => /bd·mjc·39 cited in plantedCopy\.js \(in the range bd·mjc·30–39\)/.test(x)) && !p.some(x => /bd·mjc·[1-8] |bd·mjg·33|bd·mjc·3[0-8] /.test(x)) && p.length === 4,
       'the citation scan reads the families mjc, mja, mjg: a wrong script, an info line as a check, an unknown id and the missing end of a range are flagged, and nothing else: ' + p.join(' | '));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
{ const p = citations('.'); ok(p.length === 0, 'every bd·<family>·n id cited in the package is a row of bridges_math.json and every checkedBy names its script: ' + p.slice(0, 12).join(' | ') + (p.length > 12 ? ` ... (${p.length})` : '')); }

console.log(`${n} checks` + (CITATIONS_ONLY ? ' (--citations: the fresh run and the sabotage are not part of this run)' : '')); console.log(bad ? bad + ' FAILURES' : 'ALL BRIDGE (MATHEMATICS) TESTS PASS'); process.exit(bad ? 1 : 0);
