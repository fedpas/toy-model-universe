// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Generates label_bench.html: ONE standalone file (no external request) that times the label claims in the visitor's browser.
//   node build_label_bench.mjs
// The kernels in the page are the real source of pgaEngine.js, benchKernels.js and productKernels.js: only the `import` line and the `export` keywords are removed (mechanically, below), nothing else is touched.
// The variants that the page times (VARIANTS, CTX_BUILD) are not retyped either: they are cut out of runBench in benchKernels.js, so the page cannot drift from the kernels the app uses.
// The build is deterministic (no date, no random): the same sources give the same bytes.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const SRC = path.join(here, 'label_bench_src');
const VERSION = '1.2.2';
const rd = f => fs.readFileSync(f, 'utf8');

// ---- 1. the kernels, verbatim except for import/export
function strip(src, name) {
  const out = src.split('\n').filter(l => !/^import\s/.test(l)).map(l => l.replace(/^export\s+(?=(const|let|function|class)\b)/, '')).join('\n');
  if (/^\s*(import|export)\b/m.test(out)) throw new Error(name + ': an import or export is left after stripping');
  if (/<\/script|<!--/i.test(out)) throw new Error(name + ': contains </script or <!-- and cannot be inlined in a script element');
  return out.replace(/\s+$/, '') + '\n';
}
const engineSrc = rd(path.join(here, 'pgaEngine.js')), kernelSrc = rd(path.join(here, 'benchKernels.js'));
const productSrc = rd(path.join(here, 'productKernels.js'));
const engine = strip(engineSrc, 'pgaEngine.js'), kernels = strip(kernelSrc, 'benchKernels.js'), product = strip(productSrc, 'productKernels.js');
const kernelHash = crypto.createHash('sha256').update(engine).update('\0').update(kernels).update('\0').update(product).digest('hex').slice(0, 12);

// ---- 2. the variants, cut out of runBench
const allLines = kernelSrc.split('\n'), rbAt = allLines.findIndex(l => /^export function runBench\b/.test(l));
if (rbAt < 0) throw new Error('benchKernels.js: runBench was not found');
const lines = allLines.slice(rbAt);                                                       // everything below is cut out of runBench only (checkAll has a similar line of its own)
const tLine = lines.find(l => /^\s*const T = \(fn\) =>/.test(l));
if (!tLine || !/timeIt\(fn, now, minMs, reps\)/.test(tLine) || !/med: r\.med \* 1e6, min: r\.min \* 1e6, max: r\.max \* 1e6/.test(tLine)) throw new Error('benchKernels.js: the T wrapper (ms -> ns) is not what the page expects');
if (!/export function timeIt\(fn, now, minMs = 60, reps = 7\)/.test(kernelSrc)) throw new Error('benchKernels.js: timeIt has another signature');
const VAR_RE = /^\s*(\w+): (n >= 2 \? )?T\((.+)\)( : null)?,\s*$/;
const variants = [];
for (const l of lines) { const m = VAR_RE.exec(l); if (m) variants.push({ name: m[1], min2: !!m[2], fn: m[3], nullTail: !!m[4] }); }
if (variants.length !== 14) throw new Error('expected 14 variants in runBench, found ' + variants.length);
for (const v of variants) if (v.min2 !== v.nullTail) throw new Error('variant ' + v.name + ': guard and null branch do not match');
const ctxLine = lines.find(l => /^\s*const \{ A, s, M, normals \} = setup\(n\),/.test(l));
if (!ctxLine) throw new Error('benchKernels.js: the context line of runBench was not found');
const decl = ctxLine.trim().replace(/^const /, '').replace(/;$/, '');
const parts = []; { let depth = 0, cur = ''; for (const ch of decl) { if ('([{'.includes(ch)) depth++; if (')]}'.includes(ch)) depth--; if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur = ''; } else cur += ch; } parts.push(cur.trim()); }
if (!/^\{ A, s, M, normals \} = setup\(n\)$/.test(parts[0])) throw new Error('unexpected first declarator: ' + parts[0]);
const ctxDecls = parts.slice(1).map(p => { const i = p.indexOf(' = '); return { name: p.slice(0, i), expr: p.slice(i + 3) }; });
const NAMES = '{ n, A, s, M, normals, fr, V, P, g }';
const generated = [
  '// generated from runBench in benchKernels.js by build_label_bench.mjs: the variants, and what each needs (the names are those of runBench)',
  'const VARIANTS = {',
  ...variants.map(v => `  ${v.name}: { min2: ${v.min2}, mk: (${NAMES}) => (${v.fn}) },`),
  '};',
  `const CTX_ORDER = ${JSON.stringify(ctxDecls.map(d => d.name))};`,
  'const CTX_BUILD = {',
  ...ctxDecls.map(d => `  ${d.name}: (${NAMES}) => ${d.expr},`),
  '};',
].join('\n');

// ---- 3. the core: kernels + runners, in one function scope (strict, as the modules are); the same text runs on the main thread and, as a Blob, in a Worker
const runners = rd(path.join(SRC, 'runners.js')).replace('/*__GENERATED__*/', () => generated);
const core = [
  'const LBCORE = (function () {',
  "'use strict';",
  '// ======== pgaEngine.js (source, import/export keywords removed) ========',
  engine,
  '// ======== benchKernels.js (source, import/export keywords removed) ========',
  kernels,
  '// ======== productKernels.js (source, import/export keywords removed) ========',
  product,
  runners,
  'return { runJob, unitsFor, variantsFor, timerStep, checkDetail, productVariantsFor, productCounts, PRODUCT_NS, KERNEL_SCENARIOS, BODY_VARIANTS, ALLOC_SIZES, WARM_TARGETS, VARIANT_KEYS: Object.keys(VARIANTS), sinkValue: () => sinkValue() + SINK2 };',
  '})();',
].join('\n');
if (/<\/script|<!--/i.test(core)) throw new Error('the core contains </script or <!--');

// ---- 4. the page
const ref = JSON.parse(rd(path.join(here, 'selfcheck', 'bench_labels.json')));
const refJson = JSON.stringify(ref).replace(/</g, '\\u003c');
const sub = (s, token, text) => s.split(token).join(text);
let html = rd(path.join(SRC, 'template.html'));
html = html.replace('/*@STYLE@*/', () => rd(path.join(SRC, 'style.css')));
html = html.replace('/*@REFRUN@*/', () => refJson);
html = html.replace('/*@CORE@*/', () => core);
html = html.replace('/*@PAGE@*/', () => rd(path.join(SRC, 'page.js')));
html = sub(sub(html, '@@VERSION@@', VERSION), '@@HASH@@', kernelHash);
if (/@@[A-Z]+@@|\/\*@[A-Z]+@\*\//.test(html)) throw new Error('a placeholder is left in the page');
if (/<script[^>]+\bsrc=|<link[^>]+href=|@import|url\(\s*['"]?https?:/i.test(html)) throw new Error('the page would make an external request');
const out = path.join(here, 'label_bench.html');
fs.writeFileSync(out, html);
console.log(`wrote ${out}: ${(Buffer.byteLength(html) / 1024).toFixed(1)} KB, version ${VERSION}, kernel fingerprint ${kernelHash}, ${variants.length} variants cut from runBench`);
