// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { buildSystemParts, PROFILES as profiles, LANGUAGES as languages, METRICS as metrics } from '../lib/chatPersona.js';
import { gate, relay, watchAnthropic, sse, reply, upstreamFailure } from '../lib/chatGuard.js';
export const config = { runtime: 'edge' };

// Claude route. The guard (lib/chatGuard.js) refuses junk before it costs anything, accepts exactly one user turn, and admits a valid request only when the
// rate limits, the cap on streams in flight and the daily budget allow; the same guard serves chat-openai.js.
// The system prompt goes up in two blocks: the fixed core (the same for every reader) is marked for prompt caching, the short tail carries language,
// audience, metric and compare mode.
export default async function handler(request) {
  const g = await gate(request, 'anthropic', process.env.toy_model_key, { languages, profiles, metrics, parts: buildSystemParts });
  if (g.response) return g.response;
  const { ctx, parts, ticket } = g; let handedOff = false;
  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: ticket.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.toy_model_key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({
        model: 'claude-opus-4-6', max_tokens: ticket.maxTokens, stream: true, temperature: 0.15,
        system: [{ type: 'text', text: parts.core, cache_control: { type: 'ephemeral' } }, { type: 'text', text: parts.tail }],
        messages: ctx.messages,
      }),
    });
    if (!upstream.ok || !upstream.body) { upstream.body?.cancel().catch(() => {}); ticket.end('refused'); return upstreamFailure('anthropic', upstream.status); }
    const response = sse(relay(upstream.body, ticket, watchAnthropic)); handedOff = true; return response;
  } catch (error) {
    console.error('Anthropic gateway failure:', error?.name || 'error');
    return reply(502, 'The model service is unavailable.');
  } finally { if (!handedOff) ticket.end(); }
}
