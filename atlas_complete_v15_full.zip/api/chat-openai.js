// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
export const config = { runtime: 'edge' };
import { buildSystemPrompt, PROFILES as profiles, LANGUAGES as languages, METRICS as metrics, buildSystemParts } from '../lib/chatPersona.js';
import { gate, deferredRelay, watchOpenAI, sse, sseEvent, reply } from '../lib/chatGuard.js';

// OpenAI route. Same guard as chat.js. The first event is a status code ({type:'status', code:'reasoning'}) that the page shows in the reader's language
// while o3 reasons; upstream failures after that are reported as error events. The final chunk carries the usage (stream_options.include_usage), which
// settles the daily budget; finish_reason 'length' (the token cap, reasoning included) becomes a {type:'truncated'} event.
export default async function handler(request) {
  const g = await gate(request, 'openai', process.env.ToyModelKeyOpenAi, { languages, profiles, metrics, parts: buildSystemParts });
  if (g.response) return g.response;
  const { ctx, ticket } = g;
  try {
    const system = buildSystemPrompt({ spokenLang: ctx.spokenLang, userProfile: ctx.userProfile, metricMode: ctx.metricMode, isMatchMode: ctx.isMatchMode });
    return sse(deferredRelay(ticket, {
      route: 'OpenAI', first: sseEvent({ type: 'status', code: 'reasoning' }), watch: watchOpenAI, failText: 'The OpenAI model service is unavailable.',
      open: () => fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST', signal: ticket.signal,
        headers: { 'content-type': 'application/json', 'authorization': `Bearer ${process.env.ToyModelKeyOpenAi}` },
        body: JSON.stringify({ model: 'o3', stream: true, stream_options: { include_usage: true }, max_completion_tokens: ticket.maxTokens, messages: [{ role: 'system', content: system }, ...ctx.messages] }),
      }),
    }));
  } catch (error) {
    ticket.end();
    console.error('OpenAI gateway failure:', error?.name || 'error');
    return reply(502, 'The model service is unavailable.');
  }
}
