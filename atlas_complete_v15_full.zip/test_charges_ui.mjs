// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML } from './paths.mjs';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { setLang, tab } from './ui_helpers.mjs';
// The charge-in-field widget on the Maxwell page: six situations, play, step, reset; a field slider acts on the running motion; a start slider begins a new run and keeps the play state;
// paused, a slider never starts the motion; the closed-form checks appear when they apply and are hidden when the field was changed in flight; both languages and the three audiences; no overflow.
const b = await chromium.launch(); const errs = [];
const num = s => parseFloat(String(s).replace(',', '.').replace(/[^0-9.\-]/g, ''));
for (const [lang, w, prof] of [['en', 1100, 'Mathematician'], ['it', 1100, 'Physicist'], ['en', 375, 'Young Learner']]) {
  const tag = `${lang}${w}${prof[0]}`, pg = await b.newPage({ viewport: { width: w, height: 900 } });
  pg.on('pageerror', e => errs.push(`${tag}: pageerror ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${tag}: console ${m.text()}`));
  await pg.goto(APP_HTML + '#maxwell'); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(150);
  // the three tabs of the page
  if ((await pg.locator('.tabbar [role=tab]').count()) !== 3) errs.push(`${tag}: maxwell tabs`);
  await tab(pg, 'views'); if ((await pg.locator('#mx-views .mx-grid svg').count()) < 4) errs.push(`${tag}: the four views are missing`);
  await tab(pg, 'ladders'); if ((await pg.locator('#mx-ladders table').count()) !== 2) errs.push(`${tag}: ladders`); if ((await pg.locator('#mx-ladders .mx-chip', { hasText: /maxwell_selfcheck|Python|\.py/i }).count()) < 1) errs.push(`${tag}: download buttons`);
  await tab(pg, 'charges');
  const S = '#mx-charges', C = pg.locator(S);
  if ((await C.count()) !== 1) { errs.push(`${tag}: no charges section`); await pg.close(); continue; }
  const expert = prof !== 'Young Learner';
  if ((await pg.locator(`${S} .cg-list li`).count()) !== (expert ? 14 : 0)) errs.push(`${tag}: list of checks ${await pg.locator(`${S} .cg-list li`).count()}`);
  if (expert) { const ex = await pg.locator(`${S} .cg-kind.exact`).count(), nu = await pg.locator(`${S} .cg-kind.numeric`).count(); if (ex !== 9 || nu !== 5) errs.push(`${tag}: kinds ${ex}/${nu}`); }
  if ((await pg.locator(`${S} [data-preset]`).count()) !== 6) errs.push(`${tag}: presets`);
  const time = async () => num(await pg.locator(`${S} .cg-time`).textContent()), pressed = async () => (await pg.locator(`${S} .cg-play`).getAttribute('aria-pressed')) === 'true';
  const set = async (cls, v) => { await pg.locator(`${S} .cg-p-${cls}`).fill(String(v)); };
  const u2 = async () => (await pg.locator(`${S} .cg-u2`).textContent()).replace(/[^0-9e.\-−+·x]/g, '').replace(/^.*?(?=[0-9])/, '');
  const checkTxt = async () => (await pg.locator(`${S} .cg-check`).count()) ? await pg.locator(`${S} .cg-check`).textContent() : '';
  const step = async k => { for (let i = 0; i < k; i++) await pg.locator(`${S} .cg-step`).click(); };
  // ---- every situation: it runs, the speed stays below c, and its closed-form check passes when it applies
  for (const id of ['circle', 'hyper', 'crossed', 'spiral', 'orbit', 'wave']) {
    await pg.locator(`${S} [data-preset="${id}"]`).click(); await pg.waitForTimeout(80);
    if ((await time()) !== 0) errs.push(`${tag} ${id}: starts at t = 0`);
    if ((await pg.locator(`${S} .cg-top`).count()) !== 1) errs.push(`${tag} ${id}: top view`);
    const side = id === 'spiral' || id === 'wave'; if ((await pg.locator(`${S} .cg-side`).count()) !== (side ? 1 : 0) || (await pg.locator(`${S} .cg-chart`).count()) !== (side ? 0 : 1)) errs.push(`${tag} ${id}: second panel`);
    if ((await pg.locator(`${S} .cg-vertex`).count()) !== (['circle', 'hyper', 'crossed'].includes(id) ? 3 : 4)) errs.push(`${tag} ${id}: simplex vertices`);
    await step(id === 'orbit' ? 90 : 60);
    const sp = num(await pg.locator(`${S} .cg-speed`).textContent().then(x => x.replace(/^[^0-9]*/, ''))); if (!(sp > 0 && sp < 1)) errs.push(`${tag} ${id}: speed ${sp}`);
    if (!(await pg.locator(`${S} .cg-u2`).textContent()).match(/0\s*$|e/)) errs.push(`${tag} ${id}: u.u line`);
    const ck = await checkTxt(); const bad = await pg.locator(`${S} .cg-mark.bad`).count(); if (bad) errs.push(`${tag} ${id}: a check failed: ${ck}`);
    if (['circle', 'hyper', 'spiral'].includes(id) && !(await pg.locator(`${S} .cg-mark.ok`).count())) errs.push(`${tag} ${id}: no passing check after the run: ${ck}`);
    if (id === 'crossed' || id === 'orbit' || id === 'wave') { if (!ck) errs.push(`${tag} ${id}: no check text`); }
    const o = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth); if (o > 2) errs.push(`${tag} ${id}: overflow ${o}`);
  }
  // ---- play, tweak a field slider while it plays: it goes on with the new field; paused, a slider changes nothing
  await pg.locator(`${S} [data-preset="circle"]`).click(); await pg.waitForTimeout(80);
  await set('B', 2); await pg.waitForTimeout(250); if (await pressed()) errs.push(`${tag}: a slider started the motion`); if ((await time()) !== 0) errs.push(`${tag}: time moved while paused at the start`);
  await pg.locator(`${S} .cg-play`).click(); await pg.waitForTimeout(700); const t1 = await time(); if (!(t1 > 0.3)) errs.push(`${tag}: not playing (t=${t1})`);
  const dotX = async () => num(await pg.locator(`${S} .cg-dot`).getAttribute('cx'));
  await set('B', 0.5); await pg.waitForTimeout(80);
  if (!(await pressed())) errs.push(`${tag}: moving B stopped the motion`); const t2 = await time(); if (!(t2 >= t1)) errs.push(`${tag}: moving B restarted the clock (${t1} -> ${t2})`);
  await pg.waitForTimeout(500); const t3 = await time(); if (!(t3 > t2)) errs.push(`${tag}: the clock did not go on after the change (${t2} -> ${t3})`);
  if (!/(changed the field|cambiato il campo)/.test(await checkTxt())) errs.push(`${tag}: the closed-form check should be hidden after a change in flight: ${await checkTxt()}`);
  if (!(await pg.locator(`${S} .cg-u2`).textContent()).match(/0\s*$|e/)) errs.push(`${tag}: u.u after a live change`);
  await set('qm', -1); await pg.waitForTimeout(60); if (!(await pressed())) errs.push(`${tag}: changing the charge stopped the motion`);
  // a start slider begins a new run and keeps playing
  await set('v0', 0.5); await pg.waitForTimeout(60); if (!(await pressed())) errs.push(`${tag}: a new start stopped the motion`); const tn = await time(); if (!(tn < t3)) errs.push(`${tag}: a new start did not begin a new run (${t3} -> ${tn})`);
  await pg.waitForTimeout(400); if (!((await time()) > tn)) errs.push(`${tag}: the new run did not play`);
  // pause: a field slider moves the picture of the field but not the charge
  await pg.locator(`${S} .cg-play`).click(); const tp = await time(), x0 = await dotX(); await set('B', 1.5); await pg.waitForTimeout(400);
  if (await pressed()) errs.push(`${tag}: a slider restarted a paused run`); if ((await time()) !== tp || (await dotX()) !== x0) errs.push(`${tag}: the charge moved while paused after a slider`);
  await pg.locator(`${S} .cg-play`).click(); await pg.waitForTimeout(300); if (!((await time()) > tp)) errs.push(`${tag}: play after a pause does not go on`);
  // a preset change keeps the play state, reset stops
  await pg.locator(`${S} [data-preset="wave"]`).click(); await pg.waitForTimeout(80); if (!(await pressed())) errs.push(`${tag}: a new situation stopped the motion`);
  await pg.waitForTimeout(500); if (!((await time()) > 0)) errs.push(`${tag}: the new situation did not play`);
  await pg.locator(`${S} .cg-reset`).click(); await pg.waitForTimeout(80); if ((await time()) !== 0 || (await pressed())) errs.push(`${tag}: reset`);
  // the wave: the frame toggle, the drift check after a full cycle, and the figure of eight in the average frame
  await pg.locator(`${S} [data-frame="avg"]`).click(); await pg.waitForTimeout(80); await step(40);
  if (!(await pg.locator(`${S} .cg-side`).count())) errs.push(`${tag}: side view in the average frame`);
  await pg.locator(`${S} [data-frame="lab"]`).click();
  // the text has no raw markup and the tabs link
  const txt = await C.innerText(); if (/undefined|NaN|\[object|\\[a-zA-Z]{3,}/.test(txt)) errs.push(`${tag}: raw text in the widget`);
  // the speed chart and the simplex show numbers
  const ov = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth); if (ov > 2) errs.push(`${tag}: overflow ${ov}`);
  if (w === 1100 && lang === 'en') { await pg.locator(`${S} [data-preset="orbit"]`).click(); await pg.locator(`${S} .cg-play`).click(); await step(0); await pg.waitForTimeout(100); await pg.locator(`${S} .cg-play`).click(); }
  await pg.close();
}
console.log(errs.length ? errs.join('\n') + `\n${errs.length} FAILURES` : 'CHARGES UI OK'); await b.close(); process.exit(errs.length ? 1 : 0);
