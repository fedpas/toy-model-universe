// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The package on a machine without a browser or without numpy (a build server). Starts no browser: every launch below fails on purpose (ATLAS_BROWSER_FAIL, or playwright pointed
// at an empty folder of browsers), and the report runs leave their browser parts out.
//  1. run_tests.sh --ci, copied into a temporary folder with made-up tests, the real browser_probe.mjs and ui_helpers.mjs: when Chromium cannot be started it runs the data tests,
//     prints  SKIP browser group: Chromium cannot be launched (<reason>)  instead of running the browser tests, counts them as skipped and exits 0 (1 when a data test FAILED);
//     ATLAS_REQUIRE_BROWSER=1 makes that line a FAIL; when the probe succeeds the browser tests run.
//  2. without --ci, a browser test whose Chromium cannot start skips itself (exit 77, SKIP with the reason, ui_helpers.mjs), and ATLAS_REQUIRE_BROWSER=1 makes it a FAIL.
//  3. reports/run_report_tests.sh, copied with reports/requirements.txt into a temporary folder of stand-in scripts, with REPORT_WITHOUT="numpy scipy networkx": the parts that
//     requirements.txt names are skipped, one line each, "SKIP <part>: needs <modules>", the others run, exit 0; a stand-in that imports a missing module its line does not name
//     FAILS; when python's playwright cannot start Chromium the browser parts are left out with one SKIP line (a FAIL with ATLAS_REQUIRE_BROWSER=1); without python3 the runner exits 77.
//  4. test_reports.mjs on the real reports with REPORT_WITHOUT="numpy scipy networkx" (about 30 s): exactly the runs that requirements.txt names are skipped, everything else runs
//     and passes (so the table of requirements.txt is what the scripts need), exit 0.
// Run: node test_ci_mode.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-ci-'));
const run = (cmd, args, cwd, env = {}) => { const r = spawnSync(cmd, args, { cwd, encoding: 'utf8', env: { ...process.env, ATLAS_REQUIRE_BROWSER: '', ATLAS_BROWSER_FAIL: '', REPORT_WITHOUT: '', ...env }, timeout: 300000, maxBuffer: 64 << 20 }); return { rc: r.status, out: (r.stdout || '') + (r.stderr || '') }; };
const show = out => JSON.stringify(out.trim().split('\n').slice(-8));
try {
  // ---- 1 and 2: the test runner
  const T = path.join(tmp, 'pkg'); fs.mkdirSync(path.join(T, 'dist'), { recursive: true }); fs.writeFileSync(path.join(T, 'dist', 'app.html'), '<!doctype html>\n');
  for (const f of ['run_tests.sh', 'browser_probe.mjs', 'ui_helpers.mjs']) fs.copyFileSync(f, path.join(T, f));
  fs.symlinkSync(path.join(PKG, 'node_modules'), path.join(T, 'node_modules'), 'dir');
  fs.writeFileSync(path.join(T, 'test_a_data.mjs'), "console.log('data fine'); process.exit(0);\n");
  // a browser test: it starts Chromium through the helper, as every browser test of the package does (CI_FAKE_RAN=1: it does not start it, it only says it ran)
  fs.writeFileSync(path.join(T, 'test_b_ui.mjs'), "import { chromium } from './ui_helpers.mjs';\nif (!process.env.CI_FAKE_RAN) { const b = await chromium.launch(); await b.close(); }\nconsole.log('browser test ran'); process.exit(0);\n");
  const sh = (args, env) => run('sh', [path.join(T, 'run_tests.sh'), ...args], os.tmpdir(), env);
  const NOPE = 'no display here (test)';
  let r = sh(['--ci'], { ATLAS_BROWSER_FAIL: NOPE });
  ok(r.rc === 0 && /^PASS test_a_data \(\d+s\): data fine$/m.test(r.out) && r.out.includes(`\nSKIP browser group: Chromium cannot be launched (${NOPE})\n`) && !/test_b_ui|browser test ran/.test(r.out) && /^run_tests\.sh: 1 passed, 0 failed, 1 skipped$/m.test(r.out),
     '--ci without a browser: the data tests run, one line "SKIP browser group: Chromium cannot be launched (<reason>)", the browser test is not run but counted as skipped, exit 0: ' + show(r.out));
  // the same with playwright pointed at an empty folder of browsers: a real failure of the launch, with playwright's own reason (nothing is started)
  fs.mkdirSync(path.join(tmp, 'no-browsers'));
  r = sh(['--ci'], { PLAYWRIGHT_BROWSERS_PATH: path.join(tmp, 'no-browsers') });
  const real = (r.out.match(/^SKIP browser group: Chromium cannot be launched \((.+)\)$/m) || [])[1] || '';
  ok(r.rc === 0 && real.length > 10 && /exist|playwright/i.test(real) && /^run_tests\.sh: 1 passed, 0 failed, 1 skipped$/m.test(r.out), '--ci when playwright finds no browser: the SKIP line gives playwright\'s reason ("' + real + '"), exit 0: ' + show(r.out));
  r = sh(['--ci'], { ATLAS_BROWSER_FAIL: NOPE, ATLAS_REQUIRE_BROWSER: '1' });
  ok(r.rc === 1 && r.out.includes(`\nFAIL browser group: Chromium cannot be launched (${NOPE})\n`) && /^run_tests\.sh: 1 passed, 1 failed, 0 skipped$/m.test(r.out), '--ci with ATLAS_REQUIRE_BROWSER=1: the same line is a FAIL, exit 1: ' + show(r.out));
  fs.writeFileSync(path.join(T, 'test_c_data.mjs'), "console.log('the reason'); process.exit(1);\n");
  r = sh(['--ci'], { ATLAS_BROWSER_FAIL: NOPE });
  ok(r.rc === 1 && /^FAIL test_c_data \(\d+s\): the reason$/m.test(r.out) && /^run_tests\.sh: 1 passed, 1 failed, 1 skipped$/m.test(r.out), '--ci: a data test that FAILS still fails the run (exit 1): ' + show(r.out));
  fs.rmSync(path.join(T, 'test_c_data.mjs'));
  fs.renameSync(path.join(T, 'browser_probe.mjs'), path.join(T, 'browser_probe.real'));
  fs.writeFileSync(path.join(T, 'browser_probe.mjs'), "console.log('browser ok: stand-in'); process.exit(0);\n");
  r = sh(['--ci'], { CI_FAKE_RAN: '1' });
  ok(r.rc === 0 && /^PASS test_b_ui \(\d+s\): browser test ran$/m.test(r.out) && !/browser group/.test(r.out) && /^run_tests\.sh: 2 passed, 0 failed, 0 skipped$/m.test(r.out), '--ci when the probe starts Chromium: the browser tests run: ' + show(r.out));
  fs.renameSync(path.join(T, 'browser_probe.real'), path.join(T, 'browser_probe.mjs'));
  r = sh(['--browser'], { ATLAS_BROWSER_FAIL: NOPE });
  ok(r.rc === 0 && new RegExp(`^SKIP test_b_ui \\(\\d+s\\): SKIP: Chromium cannot be launched \\(${NOPE.replace(/[()]/g, '\\$&')}\\)$`, 'm').test(r.out) && /^run_tests\.sh: 0 passed, 0 failed, 1 skipped$/m.test(r.out),
     'without --ci: a browser test whose Chromium cannot start skips itself (exit 77) and gives the reason, the run exits 0: ' + show(r.out));
  r = sh(['--browser'], { ATLAS_BROWSER_FAIL: NOPE, ATLAS_REQUIRE_BROWSER: '1' });
  ok(r.rc === 1 && new RegExp(`^FAIL test_b_ui \\(\\d+s\\): FAIL: Chromium cannot be launched \\(${NOPE.replace(/[()]/g, '\\$&')}\\)$`, 'm').test(r.out), 'without --ci, ATLAS_REQUIRE_BROWSER=1: the same test FAILS: ' + show(r.out));
  r = run('node', ['browser_probe.mjs'], T, { ATLAS_BROWSER_FAIL: NOPE });
  ok(r.rc === 1 && r.out.trim() === NOPE, 'browser_probe.mjs prints the reason and exits 1 when Chromium cannot be started: ' + show(r.out));
  // the package's own runner and tests: --ci is an option of run_tests.sh, and every browser test starts Chromium through the helper (none imports playwright itself)
  const runner = fs.readFileSync('run_tests.sh', 'utf8'), tests = fs.readdirSync('.').filter(f => /^(test_\w+|layout_check)\.mjs$/.test(f) && f !== 'test_ci_mode.mjs');   // this test only writes made-up tests
  const direct = tests.filter(f => /^\s*import\s[^;]*from\s+['"]playwright['"]/m.test(fs.readFileSync(f, 'utf8'))), viaHelper = tests.filter(f => /^import \{ chromium(, [\w, ]+)? \} from '\.\/ui_helpers\.mjs';/m.test(fs.readFileSync(f, 'utf8')));
  const launching = tests.filter(f => /\bchromium\.launch\(/.test(fs.readFileSync(f, 'utf8')));
  ok(/--ci\) CI=1;;/.test(runner) && /node browser_probe\.mjs/.test(runner) && direct.length === 0 && launching.length >= 39 && launching.every(f => viaHelper.includes(f)),
     `every browser test (${launching.length}) starts Chromium through ui_helpers.mjs, none imports playwright itself, and run_tests.sh has --ci with the probe: ` + [...direct, ...launching.filter(f => !viaHelper.includes(f))].join(', '));
  const BROWSER_RE = new RegExp((/^BROWSER_RE='([^']*)'$/m.exec(runner) || [])[1] || '^$');
  ok(launching.every(f => BROWSER_RE.test(f.replace(/\.mjs$/, ''))), 'every test that starts a browser belongs to the browser group of run_tests.sh (the data group starts none): ' + launching.filter(f => !BROWSER_RE.test(f.replace(/\.mjs$/, ''))).join(', '));

  // ---- 3: the report runner, on stand-in scripts
  const RQ = path.join(tmp, 'rpkg', 'reports'); fs.mkdirSync(RQ, { recursive: true });
  fs.copyFileSync(path.join('reports', 'run_report_tests.sh'), path.join(RQ, 'run_report_tests.sh')); fs.copyFileSync(path.join('reports', 'requirements.txt'), path.join(RQ, 'requirements.txt'));
  const put = (f, t) => { fs.mkdirSync(path.dirname(path.join(RQ, f)), { recursive: true }); fs.writeFileSync(path.join(RQ, f), t); };
  // a stand-in imports what requirements.txt says the real part needs, so that a hidden module stops it as it would stop the real one
  const REQ = fs.readFileSync(path.join('reports', 'requirements.txt'), 'utf8').split('\n').map(l => /^([A-Za-z][\w-]*)\s*(?:#\s*(.*))?$/.exec(l)).filter(Boolean), NEEDS = {};
  for (const [, m, parts] of REQ) for (const p of (parts || '').split(/\s+/).filter(Boolean)) (NEEDS[p] ||= []).push(m);
  const imp = p => (NEEDS[p] || []).map(m => `import ${m}\n`).join('');
  const CHECKS = [['category/cat_check.py', 'category/logs/cat_check.log'], ['baez/baez_check.py', 'baez/logs/baez_check.log'], ['schuller/fibre_check.py', 'schuller/logs/fibre_check_final.log'],
    ['schuller/bridge_check.py', 'schuller/logs/bridge_check_final.log'], ['schuller/bridge_check_qm.py', 'schuller/logs/bridge_check_qm_final.log'], ['hestenes/hest_check.py', 'hestenes/logs/hest_check.log'],
    ['furey/furey_papers_check.py', 'furey/logs/furey_papers_check.log'], ['furey/furey_construction_check.py', 'furey/logs/furey_construction_check.log'], ['pumplun/pumplun_checks.py', 'pumplun/logs/pumplun_checks.log']];
  for (const [s, l] of CHECKS) { put(s, imp(s) + "print('ok   X1: stand-in')\n"); put(l, 'ok   X1: stand-in\n'); }
  put('hestenes/gtg_check.py', imp('hestenes/gtg_check.py') + "print('ALL GTG/RDK CHECKS PASS')\n");
  for (const s of ['category/test_report_cat.py', 'baez/test_report_baez.py', 'schuller/test_report.py', 'hestenes/test_report_hestenes.py', 'furey/test_report_furey.py', 'pumplun/test_report_pumplun.py']) put(s, imp(s) + "print('stand-in suite: 1 ok, 0 failed')\n");
  put('pumplun/build/test_engine.js', "console.log('ALL OK');\n"); put('pumplun/test_page_pumplun.mjs', "console.log('not run without a browser'); process.exit(1);\n");
  for (const g of ['make_matrix_json.py', 'make_check_table.py', 'make_package.py']) put(g, "print('up to date')\n");
  const rsh = env => run('sh', [path.join(RQ, 'run_report_tests.sh')], os.tmpdir(), { REPORT_NO_BROWSER: '1', ...env });
  r = rsh({});
  ok(r.rc === 0 && /^run_report_tests\.sh: 20 passed, 0 failed, 3 skipped$/m.test(r.out) && !/needs (numpy|scipy|networkx)/.test(r.out), 'the report runner with every module: every part runs (20 passed; the --long, --mutation and browser parts skipped): ' + show(r.out));
  r = rsh({ REPORT_WITHOUT: 'numpy scipy networkx' });
  const skippedParts = [...r.out.matchAll(/^SKIP (\S+): needs ([a-z ]+) \(pip install -r reports\/requirements\.txt\)$/gm)].map(m => [m[1], m[2]]);
  const want = Object.keys(NEEDS).filter(p => !/mutate_/.test(p)).sort();
  ok(r.rc === 0 && JSON.stringify(skippedParts.map(x => x[0]).sort()) === JSON.stringify(want) && skippedParts.every(([p, ms]) => ms === NEEDS[p].join(' ')) && /^PASS pumplun\/pumplun_checks\.py: /m.test(r.out) && /^PASS baez\/test_report_baez\.py: /m.test(r.out)
     && /^PASS make_package\.py: up to date$/m.test(r.out) && /^run_report_tests\.sh: \d+ passed, 0 failed, \d+ skipped \(python modules missing here: numpy scipy networkx\)$/m.test(r.out),
     `REPORT_WITHOUT="numpy scipy networkx": exactly the ${want.length} parts that requirements.txt names are skipped, each with its modules ("SKIP <part>: needs <modules>"), the others run, exit 0: ` + show(r.out));
  // the browser parts of the report suites: python's playwright with a Chromium that cannot start leaves them out with one SKIP line (FAIL with ATLAS_REQUIRE_BROWSER=1)
  const pyPw = spawnSync('python3', ['-c', 'import playwright'], { encoding: 'utf8' }).status === 0;
  r = rsh({ REPORT_NO_BROWSER: '', ATLAS_BROWSER_FAIL: NOPE });
  const nbWhy = pyPw ? `Chromium cannot be launched from python (${NOPE})` : "python's playwright is not installed";
  ok(r.rc === 0 && r.out.includes(`SKIP pumplun/test_page_pumplun.mjs: the browser part is left out (${nbWhy})`) && (!pyPw || r.out.includes(`SKIP browser parts of the report suites: ${nbWhy}`)) && /^PASS category\/test_report_cat\.py: /m.test(r.out),
     'the report runner when Chromium cannot start: the browser parts are left out with the reason, the suites run without them, exit 0: ' + show(r.out));
  if (pyPw) { r = rsh({ REPORT_NO_BROWSER: '', ATLAS_BROWSER_FAIL: NOPE, ATLAS_REQUIRE_BROWSER: '1' }); ok(r.rc === 1 && r.out.includes(`FAIL browser parts of the report suites: ${nbWhy}`), 'and with ATLAS_REQUIRE_BROWSER=1 that is a FAIL: ' + show(r.out)); }
  put('pumplun/pumplun_checks.py', "import numpy\nprint('ok   X1: stand-in')\n");
  r = rsh({ REPORT_WITHOUT: 'numpy' });
  ok(r.rc === 1 && /^FAIL pumplun\/pumplun_checks\.py: stops on the missing module numpy, which its line in requirements\.txt does not name$/m.test(r.out), 'a part that imports a missing module its line in requirements.txt does not name FAILS and says so: ' + show(r.out));
  const bin = path.join(tmp, 'bin'); fs.mkdirSync(bin);
  const where = c => spawnSync('sh', ['-c', 'command -v ' + c], { encoding: 'utf8' }).stdout.trim(), dn = where('dirname'); if (dn) fs.symlinkSync(dn, path.join(bin, 'dirname'));
  r = run(where('sh'), [path.join(RQ, 'run_report_tests.sh')], os.tmpdir(), { PATH: bin });   // a PATH with dirname only: no python3
  ok(r.rc === 77 && /python3 is needed/.test(r.out), 'without python3 nothing can run: exit 77 with the reason: ' + show(r.out));

  // ---- 4: test_reports.mjs on the real reports, with the three modules hidden
  r = run('node', ['test_reports.mjs'], PKG, { REPORT_WITHOUT: 'numpy scipy networkx' });
  const sk = [...r.out.matchAll(/^SKIP (\S+): needs ([a-z ]+) \(pip install -r reports\/requirements\.txt\)$/gm)].map(m => m[1]).sort();
  const wantT = ['category/test_report_cat.py', 'hestenes/test_report_hestenes.py', 'furey/test_report_furey.py', 'category/cat_check.py', 'baez/baez_check.py', 'schuller/fibre_check.py', 'schuller/bridge_check.py', 'schuller/bridge_check_qm.py', 'hestenes/hest_check.py', 'furey/furey_papers_check.py', 'furey/furey_construction_check.py'].sort();
  ok(r.rc === 0 && JSON.stringify(sk) === JSON.stringify(wantT) && /^ALL REPORT TESTS PASS \(11 runs skipped: they need numpy, scipy, networkx, missing here\)$/m.test(r.out),
     'test_reports.mjs without numpy, scipy and networkx: the 11 runs that need them are skipped and named, the data checks and the other runs pass (the table of requirements.txt holds), exit 0: ' + show(r.out));
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL CI MODE TESTS PASS'); process.exit(bad ? 1 : 0);
