// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useState } from 'react';
import { Fold, Intro, level } from './Fold.jsx';
import { Formal, isLearner } from './Formal.jsx';
import { stepAudience } from './steps.js';
import { picYL } from './audienceCopy.js';
const YLPIC = () => stepAudience() === 'Young Learner';   // T4-11: plain picture labels for the Young Learner (audienceCopy.js PIC_YL)
import K from './couplingData.js';
import { CP_PY, CPM_PY } from './couplingSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY, { axname, ringNodes } from './couplingCopy.js';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';
import { Tags } from './StatusBadge.jsx';

// Step 6 of the equations page: Maxwell meets Dirac, one dimension at a time (n = 1 ... 8), every view at each n.
// Numbers come from selfcheck/coupling_selfcheck.py (exact) and selfcheck/coupling_matrix_check.py (numpy); test_coupling.mjs recomputes the structure independently.
const PAL = ['#fbbf24', '#34d399', '#60a5fa', '#c084fc', '#f87171', '#2dd4bf', '#fb923c', '#a3e635'];
const download = (name, text, type) => { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } };

function Ring({ n, lang = 'en' }) {
  const nodes = ringNodes(n), c = 170, R1 = 62, R2 = 118, ang = k => (-90 + 360 * k / n) * Math.PI / 180, fs = n > 6 ? 8 : 10;
  const P = (k, r) => [c + r * Math.cos(ang(k)), c + r * Math.sin(ang(k))], L = (k, r) => [c + (r + (n > 6 ? 17 : 14)) * Math.cos(ang(k)), c + (r + (n > 6 ? 17 : 14)) * Math.sin(ang(k)) + 3];
  return <svg className="eq-svg" style={{ maxWidth: 380 }} viewBox="0 0 340 340" role="img" aria-label={YLPIC() ? picYL(lang).coupling(n) : `The equation at the blade t for n = ${n}: inner ring coupling terms, outer ring derivative terms`} data-n={n}>
    {nodes.map(({ k }) => <g key={k}><line className="cp-in" x1={c} y1={c} x2={P(k, R1)[0]} y2={P(k, R1)[1]} stroke={PAL[k]} strokeWidth="1.6" /><line className="cp-out" x1={P(k, R1)[0]} y1={P(k, R1)[1]} x2={P(k, R2)[0]} y2={P(k, R2)[1]} stroke={PAL[k]} strokeWidth="1" strokeDasharray="3 2" opacity=".8" /></g>)}
    {nodes.map(({ k, inner, outer }) => <g key={'n' + k}>
      <circle cx={P(k, R1)[0]} cy={P(k, R1)[1]} r={k === 0 ? 6.5 : 5} fill={PAL[k]} stroke={k === 0 ? 'currentColor' : 'none'} strokeWidth="1.5">{!YLPIC() && <title>{`${axname(inner)} · A${axname(1 << k)}ψ${k === 0 ? (lang === 'it' ? ' · e il termine di massa' : ' · and the mass term') : ''}`}</title>}</circle>
      <circle cx={P(k, R2)[0]} cy={P(k, R2)[1]} r="4" fill="none" stroke={PAL[k]} strokeWidth="1.4">{!YLPIC() && <title>{`${axname(outer)} · ∂${axname(1 << k)}ψ`}</title>}</circle>
      <text x={L(k, R2)[0]} y={L(k, R2)[1]} textAnchor="middle" fontSize={fs} fill="currentColor" className="cp-lab">{axname(outer)}</text>
      <text x={P(k, R1)[0] + (P(k, R1)[0] > c + 2 ? 8 : P(k, R1)[0] < c - 2 ? -8 : 0)} y={P(k, R1)[1] + (Math.abs(P(k, R1)[0] - c) <= 2 ? (P(k, R1)[1] < c ? -9 : 15) : 3)} textAnchor={P(k, R1)[0] > c + 2 ? 'start' : P(k, R1)[0] < c - 2 ? 'end' : 'middle'} fontSize={fs - 1} fill="currentColor" opacity=".8" className="cp-lab">{axname(inner)}</text></g>)}
    <circle cx={c} cy={c} r="9" fill="#8b93a7" /><text x={c} y={c + 3.5} textAnchor="middle" fontSize="10" fill="#111">t</text></svg>;
}

export default function CouplingSection({ lang = 'en', profile = 'Young Learner' }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l], Lad = K.coupling.ladder, [n, setN] = useState(4), r = Lad[n], ID = K.coupling.identities, views = t.views(r);
  // the Young Learner reads plain captions (t.yl) beside the same picture; the tables, the views and the formal notes go into the closed "For older readers" fold
  const yl = isLearner(profile), y = yl ? { ...t, ...t.yl } : t;
  const table = <Fold title={t.tableH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="cp-table"><thead><tr>{t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {Object.values(Lad).map(x => { const j = x.J_exists; return <tr key={x.n} className={x.n === n ? 'on' : ''} onClick={() => setN(x.n)} style={{ cursor: 'pointer' }}><td><Tx>{x.n}</Tx></td><td><Tx>{x.algebra}</Tx></td><td><Tx>{x.psi_components}</Tx></td><td><Tx>{j ? x.dirac_real_dim : '—'}</Tx></td><td><Tx>{j ? x.psi_over_dirac : '—'}</Tx></td><td><Tx>{j ? `${axname(6)} (${x.J_count})` : t.noJ}</Tx></td><td><Tx>{x.current_grades.join(' + ')}</Tx></td><td><Tx>{t.terms(x.n)}</Tx></td></tr>; })}</tbody></table></div></Fold>;
  const viewFold = <Fold nested title={t.viewsH(n)} open={lv >= 1}><div className="cp-views">{views.map(v => <div key={v.h} className="eq-xr cp-view"><h4><Tx>{v.h}</Tx> <Tags kinds={v.tags} lang={l} /></h4><p><Tx>{v.t}</Tx></p></div>)}</div></Fold>;
  const checks = <><Fold title={t.idH} open={lv >= 1}><div className="eq-card" style={{ overflowX: 'auto' }}><table><thead><tr>{t.idCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{Object.entries(ID).map(([k, v]) => <tr key={k}><td><Tx>{k}</Tx></td><td><Tx>{v.conservation_identity ? '✓' : '✗'}</Tx></td><td><Tx>{v.gauge_first_order ? '✓' : '✗'}</Tx></td><td><Tx>{v.maxwell_forces_div_J_zero ? '✓' : '✗'}</Tx></td><td><Tx>{v.algebraic_facts ? '✓' : '✗'}</Tx></td></tr>)}</tbody></table><p className="eq-cap"><Tags kinds={['checked']} lang={l} /> <Tx>{t.idNote}</Tx></p></div></Fold>
    <Fold title={t.xrH} open={lv >= 2}>{t.xr.map(([k, txt], i) => <div key={i} className="eq-xr"><p><Tags kinds={[].concat(k)} lang={l} /> <Tx>{txt}</Tx></p></div>)}</Fold>
    <Fold title={t.matH} open={lv >= 2}><div className="eq-card"><p><Tags kinds={['checked', 'standard']} lang={l} /> <Tx>{t.mat}</Tx></p><p className="eq-cap"><Tx>{t.numbers}</Tx></p></div></Fold></>;
  const pts = items => <div>{items.map(([k, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={[].concat(k)} lang={l} /></div><p><Tx>{txt}</Tx></p></div>)}</div>;
  const dl = <Fold title={t.dl.h} open={lv >= 2}><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('coupling_selfcheck.py', CP_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('coupling_matrix_check.py', CPM_PY, 'text/x-python')}><Tx>{t.dl.py2}</Tx></button><button className="eq-btn" onClick={() => download('coupling.json', JSON.stringify(K.coupling, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p></Fold>;
  return <section className="eq" id="eq-coupling" aria-labelledby="eq-k-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'coupling', yl ? y.name : undefined)}</Tx></p><h2 id="eq-k-h"><Tx>{y.title}</Tx></h2><Intro lang={l} profile={profile} id="coupling" lede={t.lede} />
    <div><Tags kinds={['checked']} lang={l} /></div>
    {!yl && table}
    <h3><Tx>{y.pickH}</Tx></h3><div className="eq-card"><p className="eq-cap"><Tx>{y.pick}</Tx></p>
      <div className="eq-chips" role="group">{Object.keys(Lad).map(k => <button key={k} className={'eq-chip cp-chip' + (+k === n ? ' on' : '')} aria-pressed={+k === n} onClick={() => setN(+k)}><Tx>{k}</Tx></button>)}</div>
      <h4><Tx>{t.ringH}</Tx></h4>{r.J_exists ? <><Ring n={n} lang={lang} /><p className="eq-cap cp-ringcap"><Tx>{y.ringCap(n)}</Tx></p></> : <p className="eq-cap cp-ringcap"><Tx>{y.ringNone(n)}</Tx></p>}
      {!yl && viewFold}</div>
    {yl ? <><Formal profile={profile} lang={l}>{table}{viewFold}{checks}{pts(t.open)}{dl}</Formal>{pts(y.points)}</> : <>{checks}{pts(t.open)}{dl}</>}</section>;
}
