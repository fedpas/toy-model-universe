// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Light / dark / auto. The dark theme is the page as it always was. The light theme is that same page turned over by one CSS filter on <html>:
// invert(1) then hue-rotate(180deg), so the dark ground becomes a light one and every hue stays what it was (green stays green, red stays red), plus a few
// overrides for the colours the plain inversion leaves below 4.5:1 (the five status tags and the status badges). Every rule of LIGHT_CSS starts with
// html[data-theme="light"]: with data-theme absent or "dark" no rule of this file applies, and the dark page is pixel for pixel what it was (test_theme_ui.mjs).
// The overrides are written as the colour BEFORE the filter: the filter maps it to the colour the reader sees (lightTarget below names that colour; test_theme.mjs
// recomputes it). The choice is auto | light | dark, default dark. Precedence: ?theme= in the address (not stored: for screenshots and tests, and to make
// the choice stick where storage is blocked), then localStorage atlas.theme (only the three values are accepted), then dark. auto follows
// prefers-color-scheme while the page is open. data-theme on <html> holds the RESOLVED value (light or dark); it is set when this module is imported,
// before React renders, so the page never flashes the other theme. Storage that throws is ignored: the choice then lasts as long as the page (memory).
export const THEMES = ['auto', 'light', 'dark'];
export const THEME_KEY = 'atlas.theme';
export const DEFAULT_THEME = 'dark';
export const validTheme = v => (THEMES.includes(v) ? v : null);

// which choice wins: the address (a query string such as "?theme=light"), then a storage object with getItem (it may throw), then the default
export function pickTheme(search, storage) {
  let u = null; try { u = validTheme(new URLSearchParams(search || '').get('theme')); } catch { /* not a query string */ }
  if (u) return { choice: u, from: 'url' };
  let s = null; try { s = storage ? validTheme(storage.getItem(THEME_KEY)) : null; } catch { /* storage can be blocked */ }
  if (s) return { choice: s, from: 'storage' };
  return { choice: DEFAULT_THEME, from: 'default' };
}
// the theme drawn for a choice: auto follows the system (prefersLight = matchMedia('(prefers-color-scheme: light)').matches)
export const resolveTheme = (choice, prefersLight) => (choice === 'auto' ? (prefersLight ? 'light' : 'dark') : choice === 'light' ? 'light' : 'dark');

// The filter, and what it does to a colour (sRGB, as Chromium applies the CSS filter functions): invert, then the hue-rotate(180deg) matrix of the
// Filter Effects spec. That matrix is its own inverse, so the colour to write for a wanted on-screen colour T is 1 - M·T (lightSource).
export const LIGHT_FILTER = 'invert(1) hue-rotate(180deg)';
const M = [[-0.574, 1.43, 0.144], [0.426, 0.43, 0.144], [0.426, 1.43, -0.856]];
const hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
const toHex = c => '#' + c.map(v => Math.round(Math.min(1, Math.max(0, v)) * 255).toString(16).padStart(2, '0')).join('');
const mul = v => M.map(r => r[0] * v[0] + r[1] * v[1] + r[2] * v[2]);
export const lightTarget = h => toHex(mul(hex(h).map(v => 1 - v)));   // what the reader sees in light mode for a colour h of the page
export const lightSource = h => toHex(mul(hex(h)).map(v => 1 - v));   // the colour to write so that the reader sees h
// WCAG relative luminance and contrast ratio of two #rrggbb colours
const lin = v => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4);
export const luminance = h => { const c = hex(h); return 0.2126 * lin(c[0]) + 0.7152 * lin(c[1]) + 0.0722 * lin(c[2]); };
export const contrast = (a, b) => { const x = luminance(a), y = luminance(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
// The plain inversion keeps every hue but lowers the contrast of saturated colours: the open red falls from 6.8:1 (dark) to 3.4:1 (light), the checked
// green and the standard blue to about 4.7:1, and lower again where a caption is drawn at 80 % opacity. deepen(h) is the colour the light theme writes
// instead of h: the inverted colour, made darker in the same hue until it has LIGHT_MIN on the light page (8:1, which keeps 4.5:1 where a legend or a
// caption is drawn at 78 % opacity, and on the card surfaces; test_theme.mjs recomputes it, test_theme_ui.mjs measures the tags on screenshots).
export const LIGHT_MIN = 8;
export function deepen(h, min = LIGHT_MIN) {
  const bg = lightTarget(DARK_BG), t = hex(lightTarget(h));
  for (let k = 100; k >= 0; k--) { const src = lightSource(toHex(t.map(v => v * k / 100))); if (contrast(lightTarget(src), bg) >= min) return src; }
  return toHex([1, 1, 1]);
}
const rgb = h => 'rgb(' + hex(h).map(v => Math.round(v * 255)).join(', ') + ')';   // how the browser writes a colour in a style attribute (React sets style.color)
const L = 'html[data-theme="light"]';

// ==== LIGHT OVERRIDE BLOCK: the only place of this file (and of readerFilter.js and the theme code of StoryShell.jsx) that names a colour ====
const DARK_BG = '#0b1020';   // the dark theme's ground (var(--bg) and the page); turned over it is the light page, #eaefff
// the five status tags: StoryShell.jsx .tag.* (and every .tag of the sections), ResearcherNote.jsx .rn-tag.*, the proof badge of the atlas page (App.jsx, inline)
const TAGS = { checked: '#34d399', standard: '#60a5fa', ours: '#fbbf24', open: '#f87171', input: '#c4b5fd' };
// accent colours written as a text colour in a class rule of a section (ContactForm, LabelsSection, RigidSection, SpinSection, SpringSection, ChargesWidget, MapSection)
const CLASSES = {
  '#f87171': '.cf-error,.ls-bad,.rg-short,.sp-mark.bad,.spr-face.nz', '#34d399': '.cf-thanks h3,.ls-ok,.sp-mark.ok,.spr-face.z',
  '#4fd18b': '.cg .cg-mark.ok,.cg .cg-kind.exact', '#ff5d8f': '.cg .cg-mark.bad', '#ffa06f': '.cg .cg-kind.numeric', '#4aa8ff': '.map-tree details.hit>summary .map-t',
};
// accent colours written in an inline style="color: ..." (legends, badges, state lines of the widgets; the three-generations tags, the Furey findings badges),
// or as the fill of an SVG label
const INLINE = ['#34d399', '#60a5fa', '#fbbf24', '#f87171', '#4aa8ff', '#4cc9f0', '#ff5d8f', '#4fd18b', '#c084fc', '#7fb2ff', '#fb923c', '#f472b6', '#a78bfa', '#2dd4bf', '#22d3ee', '#2ec4b6', '#ffa06f', '#8b93a7', '#8b93a8', '#9ca3af'];
// The rules of the light theme, every selector under html[data-theme="light"] (test_theme.mjs checks it, and that no hex colour sits outside this block):
// <html> gets the filter and the ground it turns over (var(--bg) as the dark theme paints it), so that the result does not depend on what the host paints
// behind it; body gets color-scheme dark, so that the browser's own controls (buttons without a style, sliders, check boxes, scroll bars of inner boxes,
// default links) are drawn dark and come out light; then the colours above, deepened (inline styles need !important).
const inlineColor = h => `:is([style^="color: ${rgb(h)}"],[style*="; color: ${rgb(h)}"])`;
export const LIGHT_CSS = [
  `${L}{filter:${LIGHT_FILTER};background:var(--bg,${DARK_BG})}`,
  `${L} body{color-scheme:dark}`,
  ...Object.entries(TAGS).map(([k, h]) => `${L} :is(.tag,.rn-tag).${k}{color:${deepen(h)}}`),
  ...Object.entries(CLASSES).map(([h, sel]) => `${L} :is(${sel}){color:${deepen(h)}}`),
  ...INLINE.map(h => `${L} ${inlineColor(h)}{color:${deepen(h)}!important}`),
  ...INLINE.map(h => `${L} :is(.proof-status,.f-badge):is([style*="solid ${rgb(h)}"],[style*="border-color: ${rgb(h)}"]){border-color:${deepen(h)}!important}`),
  ...INLINE.map(h => `${L} svg :is(text,tspan)[fill="${h}" i]{fill:${deepen(h)}}`),   // labels of the pictures written in an accent colour (the shapes and lines keep theirs)
].join('\n');
// ==== END OF THE LIGHT OVERRIDE BLOCK ====

// ---- state: the reader's choice, the system preference, the attribute on <html>
const hasDoc = typeof document !== 'undefined' && !!document.documentElement;
const store = () => { try { return typeof localStorage !== 'undefined' ? localStorage : null; } catch { return null; } };
let mq = null; try { mq = typeof window !== 'undefined' && window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null; } catch { mq = null; }
let choice = pickTheme(typeof location !== 'undefined' ? location.search : '', store()).choice;
const subs = new Set();
export const getTheme = () => choice;                                            // auto | light | dark
export const getResolvedTheme = () => resolveTheme(choice, !!(mq && mq.matches));  // light | dark
function apply() { if (hasDoc) document.documentElement.setAttribute('data-theme', getResolvedTheme()); subs.forEach(f => { try { f(choice); } catch { /* a subscriber's error is its own */ } }); }
export function setTheme(v) {
  if (!validTheme(v)) return;
  choice = v;
  try { const s = store(); if (s) s.setItem(THEME_KEY, v); } catch { /* storage can be blocked: the choice lasts as long as the page */ }
  apply();
}
export const subscribeTheme = f => { subs.add(f); return () => subs.delete(f); };
if (hasDoc) {
  if (!document.getElementById('atlas-theme')) { const st = document.createElement('style'); st.id = 'atlas-theme'; st.textContent = LIGHT_CSS; (document.head || document.documentElement).appendChild(st); }
  apply();
  const onSystem = () => { if (choice === 'auto') apply(); };
  try { if (mq) { if (mq.addEventListener) mq.addEventListener('change', onSystem); else if (mq.addListener) mq.addListener(onSystem); } } catch { /* ignore */ }
}

// the words of the Settings control, EN and IT
export const THEME_COPY = {
  en: { label: 'Theme', auto: 'Auto', light: 'Light', dark: 'Dark', note: 'Auto follows the setting of your device.' },
  it: { label: 'Tema', auto: 'Auto', light: 'Chiaro', dark: 'Scuro', note: 'Auto segue l’impostazione del dispositivo.' },
};
