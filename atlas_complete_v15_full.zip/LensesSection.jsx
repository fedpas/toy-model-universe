// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';
import CategorySection from './CategorySection.jsx';
import BaezSection from './BaezSection.jsx';
import SchullerSection from './SchullerSection.jsx';
import { GroupsTab, LABELS_STYLE } from './LabelsTabs.jsx';   // the finite groups: step 17, the first step of the lenses page

// Steps 17-20 on one page with four tabs: the finite groups (step 17, the finite shadow of the labels, which the Baez chapter uses), the category lens (what is label 0?), the bridge to Baez's seven papers, the bridge
// to Schuller's lectures. The tab bar, the Previous / Next buttons and the at-a-glance strip (status, script, what is established) are the shared ones: the strip is
// the chapter's node on the Map (its tags, its script, its text in mapCopy.js), so the chapter itself draws only its body. Each chapter owns its files
// (<name>Section.jsx, <name>Copy.js, <name>Widgets.jsx, <name>Engine.js, <name>Data.js, <name>Integration.js, ...); this file only chooses which one is on.
export default function LensesSection({ lang, profile, go }) {
  const L = lang === 'it' ? 'it' : 'en', [sub, setSub] = useSub('lenses'), P = { lang: L, profile, go };
  return <><style>{LABELS_STYLE}</style><TabBar lang={L} page="lenses" active={sub} onPick={setSub} profile={profile} />
    <TabPanel lang={L} page="lenses" id={sub} onPick={setSub} goMap={go} profile={profile} ownGlance={sub === 'groups'}>
      {sub === 'groups' && <GroupsTab {...P} />}
      {sub === 'category' && <CategorySection {...P} />}
      {sub === 'baez' && <BaezSection {...P} />}
      {sub === 'schuller' && <SchullerSection {...P} />}
    </TabPanel></>;
}
