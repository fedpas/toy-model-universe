// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The widgets of the Schuller chapter (step 20 of the lenses page): SW1 ... SW7 and the script box. Each takes { lang, profile }, has a root
// <div class="ln-card" data-widget="SWn">, computes what it shows in the browser with schullerEngine.js (live) and shows it beside the exact output of
// selfcheck/reports/lens_sch_check.py (stored, schullerWidgetData.js), with a badge that says which (live = stored ✓ when both agree). Captions are
// tagged points (LensKit Pts), so the reader filter and the claims table (LNS-101...) see their tags. The Young Learner gets plain words and no formulas;
// the Physicist and the Mathematician get the formulas, the check ids, a provenance line and the twin table of the numbers the picture shows.
// The chapter (SchullerSection.jsx) places each widget at its own anchor and decides who sees it (DECISIONS.md §3).
import React, { useMemo, useState } from 'react';
import { Tx } from './MathText.jsx';
import { stepAudience } from './steps.js';
import { Pts, ScriptBox } from './LensKit.jsx';
import * as E from './schullerEngine.js';
import { SWC } from './schullerWidgetsCopy.js';
import DATA from './schullerWidgetData.js';
import { LENS_SCH_PY } from './schullerWidgetsSelfcheckSource.js';

const STYLE = `
.scw .scw-stones{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0}.scw .scw-stone{flex:1 1 112px;min-width:0;background:none;color:inherit;font:inherit;font-size:.82em;text-align:left;cursor:pointer;border-radius:10px;padding:6px 8px;border:2px solid rgba(128,128,128,.6)}
.scw .scw-stone.gE{border:4px double #34d399}.scw .scw-stone.gS{border:2px solid #60a5fa}.scw .scw-stone.gA{border:2px dashed #fbbf24}.scw .scw-stone[aria-pressed=true]{background:rgba(80,170,255,.16)}
.scw .scw-stone:focus-visible,.scw .scw-grid button:focus-visible,.scw .scw-seat:focus-visible,.scw input:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.scw .scw-g{font-family:ui-monospace,monospace;font-weight:700;margin-right:4px}.scw .scw-panel{border-left:3px solid rgba(128,128,128,.4);padding:2px 10px;margin:6px 0}
.scw .scw-grid{border-collapse:collapse;font-size:.72em;margin:6px 0}.scw .scw-grid td,.scw .scw-grid th{width:22px;min-width:22px;height:20px;text-align:center;padding:0;border:1px solid rgba(128,128,128,.2);font-weight:400}
.scw .scw-grid .kH{background:rgba(52,211,153,.32)}.scw .scw-grid .ke{background:rgba(96,165,250,.13)}.scw .scw-grid .ku{background:rgba(248,113,113,.16)}.scw .scw-grid .on{outline:2px solid currentColor;outline-offset:-2px}
.scw .scw-grid button{all:unset;display:block;width:100%;height:100%;cursor:pointer;text-align:center}
.scw .scw-pt{border-collapse:collapse;font-size:.78em}.scw .scw-pt td,.scw .scw-pt th{padding:2px 5px;border:1px solid rgba(128,128,128,.2);text-align:center;white-space:nowrap;font-weight:400}.scw .scw-pt .z{opacity:.35}.scw .scw-pt .neg{color:#f87171}.scw .scw-pt b{font-weight:700}
.scw .scw-out{font-size:.9em;margin:.4em 0;overflow-wrap:anywhere}.scw .scw-big{font-family:ui-monospace,monospace;font-size:.8em;overflow-wrap:anywhere}
.scw .scw-inl{display:flex;flex-wrap:wrap;gap:8px;align-items:center;font-size:.85em;margin:4px 0}.scw .scw-inl label{display:inline-flex;gap:4px;align-items:center}
.scw input[type=number]{width:4.2em;background:transparent;color:inherit;border:1px solid rgba(128,128,128,.5);border-radius:6px;padding:2px 4px;font:inherit}
.scw .scw-seats{display:flex;gap:10px;flex-wrap:wrap;margin:8px 0}.scw .scw-seat{width:76px;height:76px;border-radius:50%;border:2px solid rgba(128,128,128,.6);background:none;color:inherit;font:inherit;font-size:.8em;cursor:pointer}
.scw .scw-seat[aria-pressed=true]{background:rgba(52,211,153,.25);border-color:#34d399}.scw .scw-layers span{display:inline-block;font-family:ui-monospace,monospace;font-size:.8em;padding:1px 6px;margin:2px;border:1px solid rgba(128,128,128,.35);border-radius:6px}
.scw .scw-layers span.on{border-color:#34d399;background:rgba(52,211,153,.2)}.scw .scw-mats{display:flex;gap:14px;flex-wrap:wrap}.scw .scw-mats svg{width:132px;height:auto}
.scw .ln-chips{align-items:center}.scw .scw-lab{font-size:.8em;opacity:.8;margin-right:4px}
.scw [data-twin="sw3"] td,.scw [data-twin="sw3"] th{white-space:nowrap;overflow-wrap:normal}
@media (prefers-reduced-motion: reduce){.scw *{transition:none!important;animation:none!important}}`;
if (typeof document !== 'undefined' && !document.getElementById('scw-style')) { const st = document.createElement('style'); st.id = 'scw-style'; st.textContent = STYLE; document.head.appendChild(st); }

const lg = lang => (lang === 'it' ? 'it' : 'en');
const isYl = profile => profile === 'Young Learner';
const neg = s => String(s).replace(/-/g, '−');
const fmtF = (x, lang, d = 4) => neg((Math.abs(x) < 0.5 * 10 ** -d ? 0 : x).toFixed(d)).replace('.', lang === 'it' ? ',' : '.');
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const Card = ({ id, title, children }) => <div className="ln-card scw" data-widget={id}><h4><Tx>{title}</Tx></h4>{children}</div>;
const Badge = ({ kind, T, extra }) => <span className="ln-live" data-badge={kind}><Tx>{((isYl(stepAudience()) && T.badgeY[kind]) || T.badge[kind]) + (extra ? ' · ' + extra : '')}</Tx></span>;   // the Young Learner reads the plain words of badgeY
const Chips = ({ items, value, onPick, label, fmt, name }) => <div className="ln-chips" role="group" aria-label={label} data-chips={name}>{label ? <span className="scw-lab"><Tx>{label}</Tx></span> : null}{items.map(x => { const on = same(x, value); return <button type="button" key={JSON.stringify(x)} className={'ln-chip' + (on ? ' on' : '')} aria-pressed={on} data-v={typeof x === 'object' ? JSON.stringify(x) : String(x)} onClick={() => onPick(x)}><Tx>{fmt ? fmt(x) : String(x)}</Tx></button>; })}</div>;
const Slider = ({ label, min, max, step, value, onChange, out, name }) => <label className="ln-sl"><span><Tx>{label}</Tx></span><input type="range" min={min} max={max} step={step} value={value} aria-label={label} data-sl={name} onChange={e => onChange(+e.target.value)} /><output>{out ?? value}</output></label>;
const Ids = ({ T, ids }) => <p className="ln-chk"><span className="ln-k">{T.checks}</span> {ids.map(c => <code key={c} className="ln-id">{c}</code>)}</p>;
const Prov = ({ T, text }) => <p className="ln-cap" data-prov><span className="ln-k">{T.prov}</span> <Tx>{text}</Tx></p>;
const Twin = ({ T, head, rows, name }) => <div className="ln-wrap"><table className="ln-tab scw-twin" data-twin={name}><caption className="ln-cap" style={{ textAlign: 'left' }}><Tx>{T.twin}</Tx></caption><thead><tr>{head.map((h, i) => <th key={i} scope="col"><Tx>{h}</Tx></th>)}</tr></thead>
  <tbody>{rows.map((r, i) => <tr key={i} data-row={i}>{r.map((c, j) => (j === 0 ? <th key={j} scope="row"><Tx>{String(c)}</Tx></th> : <td key={j}><Tx>{String(c)}</Tx></td>))}</tr>)}</tbody></table></div>;

// the live map of cells is computed once (about 0.2 s: every h in {-1,0,1}^n against every non-Lorentzian cell up to n = 9)
let MAP = null; const liveMap = () => MAP || (MAP = E.hypMap(2, 9));
const kindLetter = k => (k === 'hyperbolic' ? 'H' : k === 'elliptic' ? 'e' : 'u');
function CellGrid({ y, t, cells, nMin = 2, nMax = 9, pick, sel, pickMax = 0 }) {
  const ks = [...Array(nMax + 1).keys()];
  return <div className="ln-wrap"><table className="scw-grid" data-grid aria-label={t.grid}><caption className="ln-cap" style={{ textAlign: 'left' }}><Tx>{t.grid}</Tx></caption>
    <thead><tr><th scope="col">{y ? '' : 'd\\k'}</th>{ks.map(k => <th key={k} scope="col">{k}</th>)}</tr></thead>
    <tbody>{ks.map(d => <tr key={d}><th scope="row">{d}</th>{ks.map(k => {
      const n = k + d; if (n < nMin || n > nMax) return <td key={k} />;
      const kind = cells[`${k},${d}`] || E.waveKind(k, d), ok = kind === 'hyperbolic', lab = y ? t.gridCell(k, d, ok) : t.gridCell(k, d, t.kinds[kind]), txt = y ? (ok ? '✓' : '·') : kindLetter(kind);
      const on = sel && sel[0] === k && sel[1] === d, cls = 'k' + kindLetter(kind) + (on ? ' on' : '');
      return <td key={k} className={cls} data-cell={`${k},${d}`} data-kind={kind}>{pick && n <= pickMax ? <button type="button" aria-label={lab} aria-pressed={!!on} onClick={() => pick([k, d])}>{txt}</button> : <span aria-label={lab} title={lab}>{txt}</span>}</td>;
    })}</tr>)}</tbody></table></div>;
}

// ================================================================ SW1 His chain, our trail
export function SW1({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw1.yl : T.sw1.pm;
  const [sel, setSel] = useState(null), [grid, setGrid] = useState(false);
  const map = useMemo(liveMap, []), match = map.ok && same(map.cells, DATA.p1.cells);
  const st = sel ? E.STONES[sel - 1] : null;
  const byN = cells => [...Array(8).keys()].map(i => i + 2).map(n => [n, Object.entries(cells).filter(([key, v]) => v === 'hyperbolic' && key.split(',').reduce((a, b) => a + +b, 0) === n).map(([key]) => `Cl(${key})`).join(' ')]);
  return <Card id="SW1" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <div className="scw-stones" role="group" aria-label={t.h}>{E.STONES.map((s, i) => <button key={s.id} type="button" className={'scw-stone g' + s.grade} aria-pressed={sel === s.id} data-stone={s.id} data-grade={s.grade} onClick={() => { setSel(sel === s.id ? null : s.id); }}>
      <span className="scw-g">{s.id}</span>{y ? null : <span className="scw-g">{s.grade}</span>} <Tx>{t.names[i]}</Tx></button>)}</div>
    <p className="ln-cap"><Tx>{t.legend}</Tx></p>
    <p className="scw-out" aria-live="polite" data-out="sw1"><Tx>{st ? t.readout(st.id, t.names[st.id - 1], t.grades[st.grade]) : ''}</Tx></p>
    {st && <div className="scw-panel" data-panel={st.id}><p><Tx>{t.says[st.id - 1]}</Tx></p>
      {!y && <p className="ln-chk"><span className="ln-k">{T.checks}</span> {st.checks.length ? st.checks.map(c => <code key={c} className="ln-id">{c}</code>) : <span><Tx>{t.none}</Tx></span>} <span className="ln-k">{t.rows}</span> {st.rows.map(r => <code key={r} className="ln-id">{r}</code>)}</p>}
      {st.id === 3 && <button type="button" className="ln-btn" data-open-grid aria-expanded={grid} onClick={() => setGrid(g => !g)}><Tx>{grid ? t.close : t.open}</Tx></button>}</div>}
    {grid && sel === 3 && <CellGrid y={y} t={t} cells={map.cells} />}
    <p><Badge kind="fig" T={T} /> <Badge kind={match ? 'match' : 'differ'} T={T} /></p>
    <Pts items={t.caps} lang={L} />
    {!y && <><Ids T={T} ids={['scw·P1', 'bridge·B1', 'bridge·B2', 'bridge·B3', 'bridge·B4', 'bridge·B5', 'bridge·C1', 'bridge·C6', 'Thm T16', 'Thm T18']} /><Prov T={T} text={t.prov} />
      <Twin T={T} name="sw1" head={t.twinHead} rows={byN(map.cells).map(([n, live], i) => [n, live, byN(DATA.p1.cells)[i][1]])} /></>}
  </Card>;
}

// ================================================================ SW2 One table, three squares
export function SW2({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw2.yl : T.sw2.pm;
  const [sq, setSq] = useState([0, 0]), n = sq.length, N = 1 << n, F = N - 1;
  const tab = useMemo(() => E.productTable(sq), [sq]), stats = useMemo(() => E.tableStats(sq), [sq]), stored = DATA.p1c[sq.join(',')];
  const p = sq.filter(s => s === 1).length, q = sq.filter(s => s === -1).length, r = n - p - q;
  const name = a => (y ? E.bitString(a, n) : E.bladeLabel(a, n).replace(/^e(\d+)$/, (m, d) => 'e_{' + d + '}'));
  const setN = k => setSq(s => (k > s.length ? [...s, 0] : s.slice(0, k)));
  const preset = k => setSq(Array(n).fill(k === 'zero' ? 0 : k === 'plus' ? 1 : -1));
  const o = { p, q, r, N, N2: N * N, zeros: stats.zeros, minus: stats.minus, eF: neg(stats.eF_sq), reach: stats.eF_rank, want: 2 ** (p + q), pair: stats.pair };
  return <Card id="SW2" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <Chips name="n" items={[2, 3]} value={n} onPick={setN} label={t.n} />
    {sq.map((s, i) => <Chips key={i} name={'sq' + i} items={[1, -1, 0]} value={s} label={t.sw(i + 1)} fmt={v => t.vals[v]} onPick={v => setSq(a => a.map((x, j) => (j === i ? v : x)))} />)}
    <div className="ln-chips" role="group" aria-label={t.n}>{t.presets.map(([k, lab]) => <button key={k} type="button" className="ln-btn" data-preset={k} onClick={() => preset(k)}><Tx>{lab}</Tx></button>)}</div>
    <p className="ln-cap"><Tx>{t.legend}</Tx></p><div className="ln-wrap"><table className="scw-pt" data-table>
      <thead><tr><th scope="col" />{[...Array(N).keys()].map(b => <th key={b} scope="col"><Tx>{name(b)}</Tx></th>)}</tr></thead>
      <tbody>{tab.map((row, a) => <tr key={a}><th scope="row"><Tx>{name(a)}</Tx></th>{row.map((c, b) => <td key={b} className={c.sign === 0 ? 'z' : c.sign < 0 ? 'neg' : ''} data-ab={`${a},${b}`} data-sign={c.sign}>{c.sign === 0 ? (y ? '–' : '0') : <Tx>{(c.sign < 0 ? '−' : '+') + name(c.label)}</Tx>}</td>)}</tr>)}</tbody></table></div>
    <p className="scw-out" aria-live="polite" data-out="sw2"><Tx>{y ? t.readout(stats.zeros, N * N, stats.minus) : t.readout(o)}</Tx></p>
    {!y && <p className="scw-out"><Tx>{(r === n ? t.wedge + ' ' : '') + (r ? t.hodge.no : t.hodge.yes)}</Tx></p>}
    <p><Badge kind={stored ? (same(stats, stored) ? 'match' : 'differ') : 'live'} T={T} /></p>
    <Pts items={t.caps} lang={L} />
    {!y && <><Ids T={T} ids={['bridge·A1', 'bridge·A2', 'bridge·A3', 'bridge·A6', 'scw·P1c', 'Thm T3']} /><Prov T={T} text={t.prov} />
      <Twin T={T} name="sw2" head={t.twinHead} rows={t.twinRows.map((lab, i) => { const k = ['zeros', 'minus', 'eF_sq', 'eF_rank', 'pair'][i]; return [lab, neg(stats[k]), stored ? neg(stored[k]) : '—']; })} /></>}
  </Card>;
}

// ================================================================ SW3 Outside and inside / left and right
function MatPic({ M, title }) {
  const N = M.length, c = 128 / N;
  return <svg viewBox="0 0 132 132" role="img" aria-label={title}><title>{title}</title><rect x="1" y="1" width="130" height="130" fill="none" stroke="currentColor" strokeOpacity=".3" />
    {M.map(([r, s], j) => (s ? <rect key={j} x={2 + j * c + c * 0.12} y={2 + r * c + c * 0.12} width={c * 0.76} height={c * 0.76} fill={s > 0 ? '#34d399' : 'none'} stroke={s > 0 ? 'none' : '#f87171'} strokeWidth={Math.max(1, c * 0.14)} /> : null))}</svg>;
}
function LeftRight({ L, T, t }) {
  const sigs = []; for (let n = 1; n <= 4; n++) for (let p = n; p >= 0; p--) sigs.push([p, n - p]);
  const [pq, setPq] = useState([1, 3]), [nul, setNul] = useState(false), [gen, setGen] = useState(0);
  const [p, q] = pq, n = p + q, pqr = nul ? (q > 0 ? [p, q - 1, 1] : [p - 1, 0, 1]) : [p, q, 0];
  const lr = useMemo(() => E.leftRight(...pqr), [pqr.join()]), stored = DATA.p3b[pqr.join(',')], i = Math.min(gen, n - 1);
  const live = { rank_LRt: lr.rank_LRt, rank_LR: lr.rank_LR, centre: lr.centre, Rt_eq_L: lr.Rt_eq_L };
  const [ml, mr] = t.lr.mats(i + 1);
  return <div className="scw-panel" data-lr><h4><Tx>{t.lr.h}</Tx></h4>
    <Chips name="lrsig" items={sigs} value={pq} onPick={v => { setPq(v); setGen(0); }} label={t.lr.pick} fmt={v => `Cl(${v[0]},${v[1]})`} />
    <label className="scw-inl"><input type="checkbox" checked={nul} data-null onChange={e => setNul(e.target.checked)} /> <Tx>{t.lr.nullT}</Tx></label>
    <Chips name="lrgen" items={[...Array(n).keys()]} value={i} onPick={setGen} label={t.lr.gen} fmt={v => `e${v + 1}`} />
    <div className="scw-mats"><figure><MatPic M={lr.L[i]} title={ml} /><figcaption className="ln-cap"><Tx>{ml}</Tx></figcaption></figure><figure><MatPic M={lr.Rt[i]} title={mr} /><figcaption className="ln-cap"><Tx>{mr}</Tx></figcaption></figure></div>
    <p className="ln-cap"><Tx>{t.lr.legend}</Tx></p>
    <p className="scw-out" aria-live="polite" data-out="sw3lr"><Tx>{`Cl(${pqr.join(',')}): ` + t.lr.readout({ ...live, rel: lr.rel, N2: 4 ** n, r: pqr[2], same: lr.Rt_eq_L })}</Tx></p>
    <p><Badge kind={stored ? (same(live, stored) && lr.rel ? 'match' : 'differ') : 'live'} T={T} /></p></div>;
}
export function SW3({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw3.yl : T.sw3.pm;
  const [k, setK] = useState(4), live = useMemo(() => E.outsideInside(k), [k]), stored = DATA.p3.rows[k];
  const fields = Object.keys(stored), ok = live.comm && fields.every(f => live[f] === stored[f]);
  const kindY = T.typesYl[E.TYPES[((-k % 8) + 8) % 8]];
  return <Card id="SW3" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <Slider name="k" label={t.slider} min={0} max={8} step={1} value={k} onChange={setK} />
    <svg className="ln-svg" viewBox="0 0 400 74" role="img" aria-label={y ? t.readout(k, live.outside, live.inside, kindY) : t.readout(live)}>
      {[...Array(8).keys()].map(i => { const out = i < k; return <g key={i}><circle cx={30 + i * 46} cy={30} r={15} fill={out ? '#60a5fa' : 'none'} stroke={out ? '#60a5fa' : '#fbbf24'} strokeWidth="3" /><title>{y ? t.sw(i + 1, out) : t.gIn(i + 1, out)}</title></g>; })}
      <line x1={7 + k * 46} y1="6" x2={7 + k * 46} y2="54" stroke="currentColor" strokeDasharray="3 3" />
      <text x="6" y="68" fontSize="12" fill="currentColor">{(y ? t.outside : t.base) + ' ' + live.outside}</text><text x="394" y="68" fontSize="12" fill="currentColor" textAnchor="end">{(y ? t.inside : t.fibre) + ' ' + live.inside}</text></svg>
    <p className="scw-out" aria-live="polite" data-out="sw3"><Tx>{y ? t.readout(k, live.outside, live.inside, kindY) : t.readout(live)}</Tx></p>
    <p><Badge kind={ok ? 'match' : 'differ'} T={T} /></p>
    <Pts items={t.caps.slice(0, 1)} lang={L} />
    {!y && <><p className="ln-cap" data-conv><Tx>{t.conv}</Tx></p>
      <Twin T={T} name="sw3" head={t.twinHead} rows={DATA.p3.rows.map(r => [r.k, r.outside, r.inside, r.k === k ? `${live.fibre_dim} (${r.fibre_dim})` : r.fibre_dim, r.double_dim, r.centre, r.base_type, r.fibre_type])} />
      <LeftRight L={L} T={T} t={t} />
      <Pts items={t.caps.slice(1)} lang={L} />
      <Ids T={T} ids={['fibre·G1', 'fibre·G2', 'fibre·G3', 'scw·P3', 'scw·P3b']} /><Prov T={T} text={t.prov} /></>}
  </Card>;
}

// ================================================================ SW4 Hyperbolicity bench (Physicist and Mathematician)
const DEF_MOM = DATA.default.mom, DEF_M = DATA.default.m;
const polyStr = (k, d) => { const n = k + d; let s = 'm² − ('; for (let i = 0; i < n; i++) s += (i === 0 ? (i < k ? '' : '−') : i < k ? ' + ' : ' − ') + `k${i + 1}²`; return s + ')'; };
export function SW4({ lang = 'en', profile = 'Physicist' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L];
  const [cell, setCell] = useState([1, 3]), [mom, setMom] = useState(DEF_MOM.slice(0, 4)), [m, setM] = useState(DEF_M), [ext, setExt] = useState(null), [mf, setMf] = useState(2), [bim, setBim] = useState(null);
  const [k, d] = cell, n = k + d, S = E.sigOf(k, d);
  const res = useMemo(() => (y ? null : E.symbolDet(S, mom, m)), [y, cell.join(), mom.join(), m]);
  const xg = useMemo(() => (y || ext === null ? null : E.extraGen(S, mom, mf, ext)), [y, cell.join(), mom.join(), mf, ext]);
  const map = useMemo(() => (y ? null : liveMap()), [y]);
  if (y) return <Card id="SW4" title={T.sw4.yl.h}><p><Tx>{T.sw4.yl.note}</Tx></p></Card>;
  const t = T.sw4.pm, st = DATA.p1.det[`${k},${d}`], isDef = same(mom, st.mom) && m === st.m;
  const sqP = E.squareVec(S, mom);
  const kind = E.waveKind(k, d), mapOk = map.ok && same(map.cells, DATA.p1.cells);
  const pick = c => { const nn = c[0] + c[1]; setCell(c); setMom(DEF_MOM.slice(0, nn)); setM(DEF_M); setBim(null); };
  const tot = ext === null ? null : ext === 0 ? `Cl(${k},${d},1)` : ext < 0 ? `Cl(${k},${d + 1})` : `Cl(${k + 1},${d})`;
  const totKind = ext === null ? null : ext === 0 ? (L === 'it' ? 'fuori dal dominio r = 0: m non entra' : 'outside the domain r = 0: m never enters') : t.kinds[ext < 0 ? E.waveKind(k, d + 1) : E.waveKind(k + 1, d)];
  const others = []; for (let dd = 0; dd <= n; dd++) if (dd !== d) others.push([n - dd, dd]);
  const bimRes = bim ? (() => { const H = E.sigOf(...bim), g = E.quadQ(S, mom), h = E.quadQ(H, mom); return t.bimRead(neg(g), neg(h), neg(g * h)); })() : '';
  return <Card id="SW4" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <CellGrid y={false} t={{ ...t, grid: t.map, gridCell: (kk, dd, kd) => `Cl(${kk},${dd}): ${kd}` }} cells={map.cells} nMin={1} nMax={9} pick={pick} sel={cell} pickMax={5} />
    <div className="scw-inl" role="group" aria-label={t.pick}><span className="scw-lab"><Tx>{`Cl(${k},${d})`}</Tx></span>
      {mom.map((v, i) => <label key={i}><Tx>{t.mom(i + 1)}</Tx><input type="number" min={-3} max={3} step={1} value={v} data-mom={i} aria-label={t.mom(i + 1)} onChange={e => { const x = Math.max(-3, Math.min(3, Math.round(+e.target.value || 0))); setMom(a => a.map((u, j) => (j === i ? x : u))); }} /></label>)}
      <label><Tx>{t.mass}</Tx><input type="number" min={0} max={5} step={1} value={m} data-mass aria-label={t.mass} onChange={e => setM(Math.max(0, Math.min(5, Math.round(+e.target.value || 0))))} /></label></div>
    <p className="scw-out" aria-live="polite" data-out="sw4"><Tx>{t.readQ(neg(res.Q), neg(sqP.scalar) + (sqP.rest ? ' + …' : ''))}</Tx><br /><Tx>{t.readDet(res.exp)}</Tx>: <span className="scw-big" data-det>{neg(res.det)}</span> {res.ok ? '✓' : '✗'}<br /><Tx>{t.reduced(polyStr(k, d))}</Tx> · <b data-kind={kind}><Tx>{t.kinds[kind]}</Tx></b></p>
    <Chips name="extra" items={[null, -1, 0, 1]} value={ext} onPick={setExt} label={t.extra} fmt={v => (v === null ? t.extraNone : `f² = ${neg(v)}`)} />
    {ext !== null && <><label className="scw-inl"><Tx>{t.mf}</Tx><input type="number" min={0} max={5} value={mf} data-mf aria-label={t.mf} onChange={e => setMf(Math.max(0, Math.min(5, Math.round(+e.target.value || 0))))} /></label>
      <p className="scw-out" data-out="sw4x"><Tx>{t.readExtra({ square: neg(xg.square), exp: 2 ** n, ok: xg.ok, total: tot, kind: totKind })}</Tx>{k === 1 && d === 3 ? <><br /><Tx>{t.shell(t.shells[String(ext)])}</Tx></> : null}</p></>}
    <Chips name="bim" items={[null, ...others]} value={bim} onPick={setBim} label={t.bim} fmt={v => (v === null ? t.bimNone : `H = Cl(${v[0]},${v[1]})`)} />
    {bim && <p className="scw-out" data-out="sw4b"><Tx>{bimRes}</Tx></p>}
    <p><Badge kind={isDef ? (String(res.det) === st.det && res.Q === st.Q ? 'match' : 'differ') : 'live'} T={T} extra={isDef ? '' : (res.ok ? '(m² − Q)^(2^(n−1)) ✓' : '✗')} /> <Badge kind={mapOk ? 'match' : 'differ'} T={T} extra={L === 'it' ? 'mappa' : 'map'} /></p>
    <Pts items={t.caps} lang={L} />
    <Ids T={T} ids={['scw·P1', 'scw·P1b', 'bridge·B1', 'bridge·B2', 'bridge·B3', 'bridge·B3b', 'bridge·B5', 'fibre·G4a', 'fibre·G4b', 'fibre·G4c', 'fibre·G4d', 'Thm T16', 'Thm T18']} /><Prov T={T} text={t.prov} />
    <Twin T={T} name="sw4" head={t.twinHead} rows={[[t.twinRows[0], neg(res.Q), neg(st.Q)], [t.twinRows[1], neg(res.det), neg(st.det)], [t.twinRows[2], neg(res.want), neg(st.det)], [t.twinRows[3], t.kinds[kind], t.kinds[DATA.p1.cells[`${k},${d}`] || E.waveKind(k, d)]]]} />
    </Card>;
}

// ================================================================ SW5 Floquet bands
const COMB_E = DATA.p2.comb_E;
function Plot({ f, lo, hi, E0, edges, t, y, L }) {
  const W = 520, H = 190, px = e => 30 + (e - lo) / (hi - lo) * (W - 40), py = v => H / 2 - Math.max(-3, Math.min(3, v)) * (H / 2 - 12) / 3;
  const pts = []; for (let i = 0; i <= 400; i++) { const e = lo + (hi - lo) * i / 400; pts.push(`${px(e).toFixed(1)},${py(f(e)).toFixed(1)}`); }
  const bands = []; const bnd = [lo, ...edges.filter(e => e > lo && e < hi), hi]; for (let i = 0; i + 1 < bnd.length; i++) { const mid = (bnd[i] + bnd[i + 1]) / 2; if (Math.abs(f(mid)) <= 1) bands.push([bnd[i], bnd[i + 1]]); }
  const ticks = []; const step = (hi - lo) > 70 ? 20 : 10; for (let e = Math.ceil(lo / step) * step; e <= hi; e += step) ticks.push(e);
  return <svg className="ln-svg" viewBox={`0 0 ${W} ${H + 18}`} role="img" aria-label={t.plot || t.axis.join(', ')} data-plot><title>{t.plot || t.axis.join(', ')}</title>
    {bands.map(([a, b], i) => <rect key={i} x={px(a)} y={8} width={Math.max(1, px(b) - px(a))} height={H - 16} fill="#34d399" fillOpacity=".16" data-band={`${a.toFixed(3)},${b.toFixed(3)}`} />)}
    <rect x={30} y={py(1)} width={W - 40} height={py(-1) - py(1)} fill="#60a5fa" fillOpacity=".1" stroke="#60a5fa" strokeOpacity=".5" strokeDasharray="4 3" />
    <line x1="30" y1={H / 2} x2={W - 10} y2={H / 2} stroke="currentColor" strokeOpacity=".3" />{lo < 0 && hi > 0 ? <line x1={px(0)} y1="8" x2={px(0)} y2={H - 8} stroke="currentColor" strokeOpacity=".25" /> : null}
    <polyline points={pts.join(' ')} fill="none" stroke="#fbbf24" strokeWidth="1.6" />
    {edges.filter(e => e >= lo && e <= hi).map((e, i) => <circle key={i} cx={px(e)} cy={py(f(e))} r="3" fill="currentColor" />)}
    <line x1={px(E0)} y1="6" x2={px(E0)} y2={H - 6} stroke="#f87171" strokeWidth="1.5" /><path d={`M${px(E0) - 5},${H - 2} l5,-8 l5,8 z`} fill="#f87171" />
    {ticks.map(e => <text key={e} x={px(e)} y={H + 14} fontSize="10" textAnchor="middle" fill="currentColor" opacity=".75">{neg(e)}</text>)}
    <text x="4" y={py(1) + 4} fontSize="10" fill="currentColor" opacity=".75">1</text><text x="4" y={py(-1) + 4} fontSize="10" fill="currentColor" opacity=".75">{neg(-1)}</text>
    <text x={W - 10} y="16" fontSize="10" textAnchor="end" fill="currentColor" opacity=".8">{y ? t.axis[0] : t.axis[0] + ' → · ' + t.axis[1]}</text></svg>;
}
export function SW5({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw5.yl : T.sw5.pm;
  const [mode, setMode] = useState('comb'), [g, setG] = useState(2), [l, setL] = useState(1), [En, setEn] = useState(8), [word, setWord] = useState(['T']), [preset, setPreset] = useState('T');
  const md = y ? 'comb' : mode;
  const combEdges = useMemo(() => E.bandEdges(e => E.halfTraceComb(e, g, l), ...COMB_E), [g, l]);
  const g5Edges = useMemo(() => (md === 'g5' ? E.bandEdges(e => E.halfTraceSteps(e, E.G5_CELL), 0.05, 90, 18000) : []), [md]);
  const storedComb = DATA.p2.comb.find(c => c.g === g && c.l === l);
  const near = (a, b) => a.length === b.length && a.every((x, i) => Math.abs(x - b[i]) < 1e-7);
  if (md === 'exact') {
    const M = E.wordMatrix(word), c = E.sl2Class(M), tr = E.traceSeq(M, 6), preset = Object.keys(DATA.p2.presets).find(kk => same(DATA.p2.presets[kk].M, M)) || null, sp = preset ? DATA.p2.presets[preset] : null;
    const ok = sp && sp.class === c.cls && sp.X2 === c.X2 && sp.half_trace === c.half_trace && same(sp.traces, tr);
    return <Card id="SW5" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
      <Chips name="mode" items={['comb', 'g5', 'exact']} value={md} onPick={setMode} fmt={v => t.modes[v]} />
      <Chips name="preset" items={Object.keys(DATA.p2.presets)} value={preset} onPick={v => setWord(PRESET_WORDS[v])} label={t.exact.presets} fmt={v => v.replace('minus', '−')} />
      <div className="ln-chips" role="group" aria-label={t.exact.gens}><span className="scw-lab"><Tx>{t.exact.gens}</Tx></span>{Object.keys(E.SL2_GENS).map(gn => <button key={gn} type="button" className="ln-btn" data-gen={gn} onClick={() => setWord(w => [...w, gn].slice(-12))}><Tx>{gn.replace('i', '⁻¹')}</Tx></button>)}
        <button type="button" className="ln-btn" data-gen="clear" onClick={() => setWord([])}><Tx>{t.exact.clear}</Tx></button></div>
      <p className="ln-cap" data-word><Tx>{t.exact.word + ': ' + (word.length ? word.map(w => w.replace('i', '⁻¹')).join(' · ') : 'I')}</Tx></p>
      <p className="scw-out" aria-live="polite" data-out="sw5" data-cls={c.cls}><Tx>{t.exact.readout({ M: M.map(r => r.map(neg)), det: c.det, half: neg(c.half_trace), X2: neg(c.X2), cls: t.cls[c.cls], tr: tr.map(neg) })}</Tx></p>
      <p><Badge kind={sp ? (ok ? 'match' : 'differ') : 'live'} T={T} /></p>
      <Pts items={t.caps} lang={L} /><Ids T={T} ids={['scw·P2', 'fibre·G5a', 'fibre·G5c', 'fibre·G5d', 'fibre·G5e', 'fibre·G5f', 'Thm T19']} /><Prov T={T} text={t.prov} />
      <Twin T={T} name="sw5" head={t.twinHead} rows={[['½ tr M', neg(c.half_trace), sp ? neg(sp.half_trace) : '—'], ['X²', neg(c.X2), sp ? neg(sp.X2) : '—'], ['tr Mᴺ', tr.map(neg).join(', '), sp ? sp.traces.map(neg).join(', ') : '—']]} /></Card>;
  }
  const isG5 = md === 'g5', f = isG5 ? (e => E.halfTraceSteps(e, E.G5_CELL)) : (e => E.halfTraceComb(e, g, l)), lo = isG5 ? 0.05 : COMB_E[0], hi = isG5 ? 60 : COMB_E[1];
  const Ec = Math.max(lo, Math.min(hi, En)), cc = E.combCell(Ec, g, l), half = isG5 ? f(Ec) : cc.half, x2 = half * half - 1, cls = E.floquetClass(half);
  const edges = isG5 ? g5Edges : combEdges, stored = isG5 ? DATA.p2.g5_edges : storedComb ? storedComb.edges : null, ok = stored && near(edges, stored);
  const flightKey = Ec > 1e-12 ? '-1' : Ec < -1e-12 ? '1' : '0';
  const eStr = fmtF(Ec, L, 2);
  return <Card id="SW5" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    {!y && <Chips name="mode" items={['comb', 'g5', 'exact']} value={md} onPick={setMode} fmt={v => t.modes[v]} />}
    {!isG5 && <><Slider name="g" label={t.kick} min={-4} max={4} step={0.5} value={g} onChange={setG} out={fmtF(g, L, 1)} /><Slider name="l" label={t.spacing} min={0.5} max={2} step={0.25} value={l} onChange={setL} out={fmtF(l, L, 2)} /></>}
    {isG5 && <p className="ln-cap"><Tx>{t.g5}</Tx></p>}
    <Slider name="E" label={t.energy} min={isG5 ? 0 : lo} max={hi} step={0.25} value={Ec} onChange={setEn} out={eStr} />
    <Plot f={f} lo={lo} hi={hi} E0={Ec} edges={edges} t={t} y={y} L={L} />
    <p className="scw-out" aria-live="polite" data-out="sw5" data-cls={cls}><Tx>{y ? t.readout(eStr, t.cls[cls]) : t.readout({ E: eStr, half: fmtF(half, L, 6), closed: isG5 ? '—' : fmtF(cc.closed, L, 6), x2: fmtF(x2, L, 6), cls: t.cls[cls] })}</Tx></p>
    {!y && !isG5 && <p className="scw-out" data-out="sw5p"><Tx>{t.pieces(t.flight[flightKey], g === 0 ? t.kickT.none : t.kickT.null)}</Tx></p>}
    {!y && <p className="ln-cap" data-edges><Tx>{t.edges(edges.length) + ': ' + edges.map(e => fmtF(e, L, 4)).join('; ')}</Tx></p>}
    <p><Badge kind="numerical" T={T} /> <Badge kind={stored ? (ok ? 'match' : 'differ') : 'live'} T={T} /></p>
    <Pts items={t.caps} lang={L} />
    {!y && <><Ids T={T} ids={['scw·P2', 'fibre·G5a', 'fibre·G5b', 'fibre·G5c', 'fibre·G5d', 'fibre·G5e', 'fibre·G5f', 'Thm T19']} /><Prov T={T} text={t.prov} />
      <Twin T={T} name="sw5" head={t.twinHead} rows={[[t.twinEdges, edges.map(e => fmtF(e, L, 6)).join('; '), stored ? stored.map(e => fmtF(e, L, 6)).join('; ') : '—']]} /></>}
  </Card>;
}
// the presets of scw·P2 as words in the generators: cat = T U, −T = S S T⁻¹, −I = S S
const PRESET_WORDS = { T: ['T'], S: ['S'], ST: ['S', 'T'], cat: ['T', 'U'], minusT: ['S', 'S', 'Ti'], I: [], minusI: ['S', 'S'] };

// ================================================================ SW6 Seats and particles
export function SW6({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw6.yl : T.sw6.pm;
  const [a, setA] = useState(1), [last, setLast] = useState(null);
  const bits = x => E.bitString(x, 3), layers = E.byNumber(), F = useMemo(() => (y ? null : E.fockMatrices()), [y]), PT = useMemo(() => (y ? null : E.pauliTable()), [y]);
  const tog = i => { const r = (a >> i & 1) ? E.takeParticle(a, i) : E.putParticle(a, i); setA(r[0]); setLast(null); };
  const add = i => setLast([i, E.putParticle(a, i)]);
  const storedLayers = DATA.p4.by_number, ok = same(layers, storedLayers) && (!last || same(last[1], DATA.p4.put[`${a},${last[0]}`]));
  return <Card id="SW6" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <div className="scw-seats" role="group" aria-label={t.h}>{[0, 1, 2].map(i => { const full = !!(a >> i & 1); return <button key={i} type="button" className="scw-seat" aria-pressed={full} data-seat={i} onClick={() => tog(i)}><Tx>{t.seat(i + 1)}</Tx><br /><Tx>{full ? t.full : t.empty}</Tx></button>; })}</div>
    <div className="ln-chips">{[0, 1, 2].map(i => <button key={i} type="button" className="ln-btn" data-add={i} onClick={() => add(i)}><Tx>{t.add(i + 1)}</Tx></button>)}</div>
    <p className="scw-out" aria-live="polite" data-out="sw6"><Tx>{t.readout(bits(a), E.pc(a)) + (last ? ' ' + (y ? t.addRead(last[0] + 1, last[1] ? bits(last[1][0]) : null) : t.addRead(last[0] + 1, last[1] ? bits(last[1][0]) : null, last[1] ? (last[1][1] < 0 ? '−' : '+') : '')) : '')}</Tx></p>
    <div className="scw-layers" aria-label={t.layers}><p className="ln-cap"><Tx>{t.layers}</Tx></p>{layers.map((c, j) => <div key={j} data-layer={j}><span className="scw-lab">{j}:</span>{[...Array(8).keys()].filter(x => E.pc(x) === j).map(x => <span key={x} className={x === a ? 'on' : ''}>{bits(x)}</span>)} <span className="scw-lab">({c})</span></div>)}</div>
    <p><Badge kind={ok ? 'match' : 'differ'} T={T} /></p>
    <Pts items={t.caps.slice(0, y ? 1 : 2)} lang={L} />
    {!y && <><p className="scw-out" data-out="sw6rel"><Tx>{t.relations({ car: F.car, excl: F.excl, pm: F.plusMinus, num: F.numberOk })}</Tx></p>
      <h4><Tx>{t.pauliH}</Tx></h4><p className="ln-cap"><Tx>{t.pauliLegend}</Tx></p><div className="ln-wrap"><table className="scw-pt" data-pauli>
        <tbody>{[0, 1, 2, 3].map(r => <tr key={r}>{[0, 1, 2, 3].map(c => { const lab = r * 4 + c, x = PT[lab]; return <td key={c} data-blade={lab} data-sq={x.square}>{x.square > 0 ? <b>{x.pauli}</b> : x.pauli}<br /><Tx>{E.bladeLabel(lab, 4)}</Tx> · {x.phase.replace('-', '−')}</td>; })}</tr>)}</tbody></table></div>
      <Pts items={t.caps.slice(2)} lang={L} /><Ids T={T} ids={['qm·Q1', 'qm·Q5', 'qm·Q6', 'qm·Q7', 'scw·P4', 'scw·P4b', 'Thm T20']} /><Prov T={T} text={t.prov} />
      <Twin T={T} name="sw6" head={t.twinHead} rows={[[t.twinRows[0], layers.join(', '), storedLayers.join(', ')], [t.twinRows[1], Object.values(PT).filter(x => x.square > 0).length, Object.values(DATA.p4b).filter(x => x.square > 0).length], [t.twinRows[2], new Set(Object.values(PT).map(x => x.pauli)).size, new Set(Object.values(DATA.p4b).map(x => x.pauli)).size]]} /></>}
  </Card>;
}

// ================================================================ SW7 Three magnets
export function SW7({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), y = isYl(profile), T = SWC[L], t = y ? T.sw7.yl : T.sw7.pm;
  const [dirs, setDirs] = useState(['z', 'x', 'z']), res = useMemo(() => E.magnets(dirs), [dirs.join()]), zx = useMemo(() => E.zxCommute(), []);
  const st = [DATA.p4.pass[`${dirs[0]}>${dirs[1]}`], DATA.p4.pass[`${dirs[1]}>${dirs[2]}`]], ok = same(res.steps, st);
  const pct = x => `${Math.round(x * 1000) / 10}%`.replace('.', L === 'it' ? ',' : '.'), w1 = 14, w2 = w1 * E.probValue(res.steps[0]), w3 = w2 * E.probValue(res.steps[1]);
  const arrow = d => ({ z: 'M0,10 L0,-10 M-5,-4 L0,-10 L5,-4', '-z': 'M0,-10 L0,10 M-5,4 L0,10 L5,4', x: 'M-10,0 L10,0 M4,-5 L10,0 L4,5', '-x': 'M10,0 L-10,0 M-4,-5 L-10,0 L-4,5', y: 'M-7,7 L7,-7 M1,-7 L7,-7 L7,-1', '-y': 'M7,-7 L-7,7 M-1,7 L-7,7 L-7,1' })[d];
  return <Card id="SW7" title={t.h}><p className="ln-cap"><Tx>{t.intro}</Tx></p>
    {[0, 1, 2].map(i => <Chips key={i} name={'mag' + i} items={E.DIRS} value={dirs[i]} label={t.mag(i + 1)} fmt={v => t.dirs[v]} onPick={v => setDirs(a => a.map((x, j) => (j === i ? v : x)))} />)}
    <svg className="ln-svg" viewBox="0 0 520 110" role="img" aria-label={t.readout(t.words[res.steps[0]], t.words[res.steps[1]], pct(res.total))}><title>{t.h}</title>
      <rect x="0" y={55 - w1 / 2} width="80" height={w1} fill="#60a5fa" fillOpacity=".5" /><rect x="140" y={55 - w2 / 2} width="140" height={Math.max(w2, 0.5)} fill="#60a5fa" fillOpacity=".5" /><rect x="340" y={55 - w3 / 2} width="140" height={Math.max(w3, 0.5)} fill="#60a5fa" fillOpacity=".5" />
      {[0, 1, 2].map(i => <g key={i} transform={`translate(${110 + i * 180},55)`}><rect x="-28" y="-38" width="56" height="76" rx="8" fill="none" stroke="currentColor" strokeOpacity=".7" /><path d={arrow(dirs[i])} stroke="#fbbf24" strokeWidth="3" fill="none" /><text y="52" fontSize="11" textAnchor="middle" fill="currentColor">{t.mag(i + 1)}</text></g>)}</svg>
    <p className="scw-out" aria-live="polite" data-out="sw7"><Tx>{t.readout(t.words[res.steps[0]], t.words[res.steps[1]], pct(res.total))}</Tx></p>
    {!y && <p className="scw-out" data-out="sw7o"><Tx>{t.order({ same: zx.same, s31: zx.e3e1[1], s13: zx.e1e3[1] })}</Tx></p>}
    <p><Badge kind={ok ? 'match' : 'differ'} T={T} /></p>
    <Pts items={t.caps} lang={L} />
    {!y && <><Ids T={T} ids={['qm·Q12', 'scw·P4']} /><Prov T={T} text={t.prov} /><Twin T={T} name="sw7" head={t.twinHead} rows={[['1 → 2', res.steps[0], st[0]], ['2 → 3', res.steps[1], st[1]]]} /></>}
  </Card>;
}

// ================================================================ the check script of these widgets
export function SchullerWidgetsScript({ lang = 'en', profile = 'Young Learner' }) {
  const L = lg(lang), T = SWC[L];
  return <div className="ln-card scw" data-widget="SchullerWidgetsScript"><h4><Tx>{T.script.h}</Tx></h4><ScriptBox lang={L} file="selfcheck/reports/lens_sch_check.py" text={LENS_SCH_PY} note={isYl(profile) ? T.script.yl : T.script.note} /></div>;
}
