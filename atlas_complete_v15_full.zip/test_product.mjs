// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The matrix route of the dense product: productKernels.js against the exact Python check (selfcheck/matrixrep.json: integers, standard library) and against itself.
// Nothing here is a timing except the last block, which only checks that the stored timings have the shape the page text reads.   node test_product.mjs
import fs from 'node:fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import * as P from './productKernels.js';
import MR from './matrixrepData.js';
import BENCH from './benchData.js';
import COPY, { PROD_FACTS, PROD_NS } from './rigidCopy.js';
const J = JSON.parse(fs.readFileSync('./selfcheck/matrixrep.json', 'utf8'));
let n_ok = 0; const fails = [];
const ok = (c, m) => { if (c) n_ok++; else { fails.push(m); console.log('FAIL', m); } };
const same = (u, v) => u.length === v.length && Array.from(u).every((q, i) => q === v[i]);

// 1. the Python data: what it claims, read back
ok(J.counts.rep_sizes.join() === '2,4,6,8,10', 'the representation is checked at n = 2, 4, 6, 8, 10');
ok(J.rep.filter(r => r.n <= 8).every(r => r.pairs_exhaustive && r.gram_exhaustive), 'every pair of blades checked up to n = 8');
ok(J.rep.every(r => r.gain === 2 ** r.k && r.dense_terms_bit_rule === 4 ** r.n && r.multiplications_matmul === 8 ** r.k), 'the operation counts are 4^n, 8^k and 2^k');
ok(J.period8.map(r => r.N).join() === '0,1,2,3' && J.period8.every(r => r.relations_hold && r.images_independent && r.random_product_equal && r.cl_n_products_per_product === 4096 && r.operation_ratio === 16 && r.dimension === 2 ** r.n), 'period 8: relations, independence, 4096 products, ratio 16, for N = 0..3');
ok(J.pga.every(r => r.products_in_euclidean_cl_n === 3 && r.random_motor_products_equal === 6 && r.terms_in_those_products * 4 === r.dense_terms_motor_product * 3), 'a motor product is three Euclidean products, three quarters of the terms');
ok(Object.values(J.negative_controls).length === 3 && Object.values(J.negative_controls).every(Boolean), 'the three negative controls fail as they should');
ok(JSON.stringify(MR.counts) === JSON.stringify(J.counts) && !('fixtures' in MR), 'the data module in the app is the json without its fixtures');
ok(J.gain_table.every(g => g.gain === P.productCounts(g.n).gain && g.bit_rule_terms === P.productCounts(g.n).bitTerms && g.matmul_mults === P.productCounts(g.n).matMults), 'the counts in productKernels.js equal the Python table');

// 2. the JS product against the Python integers, for every n of the fixtures
for (const [ns, f] of Object.entries(J.fixtures)) {
  const n = +ns, x = Float64Array.from(f.x), y = Float64Array.from(f.y);
  ok(same(P.productBitRule(x, y, n), f.xy), `n = ${n}: bit rule = Python product`);
  if (P.productHasTable(n)) ok(same(P.productWithTable(x, y, n, P.productSignTable(n)), f.xy), `n = ${n}: sign table = Python product`);
  ok(same(P.productMatrixRoute(P.productRep(n, 0), x, y), f.xy), `n = ${n}: matrix route = Python product`);
  { const rep = P.productRep(n, 0), b = P.productRouteBuffers(rep), r1 = Array.from(P.productMatrixRouteReuse(rep, x, y, b)), r2 = Array.from(P.productMatrixRouteReuse(rep, y, x, b)), r3 = P.productMatrixRouteReuse(rep, x, y, b);
    ok(same(r1, f.xy) && same(r3, f.xy) && same(r2, P.productBitRule(y, x, n)), `n = ${n}: matrix route with buffers allocated once = Python product (===), also after the buffers held another product`); }
  if (P.productHasTable(n)) { const T = P.productSignTable(n), o = new Float64Array(1 << n); P.productWithTable(y, x, n, T, o); ok(same(P.productWithTable(x, y, n, T, o), f.xy), `n = ${n}: sign table with its output allocated once = Python product`); }
  ok(same(P.fromMatrices(P.productRep(n, 0), P.toMatrices(P.productRep(n, 0), x)), x), `n = ${n}: the way in and out loses nothing`);
  if (n >= 10) ok(same(P.productMatrixRoute(P.productRep(n, n - 8), x, y), f.xy), `n = ${n}: 16 x 16 blocks over Cl(${n - 8}) = Python product`);
}

// 3. the variants agree with each other where Python has no fixture (12; 14 only with LB_SLOW=1)
for (const n of [2, 4, 6, 8, 10, 12].concat(process.env.LB_SLOW ? [14] : [])) { const c = P.productCheck(n); ok(c.ok, `productCheck(${n})`); }
// every block size of the period-8 split gives the same product: N = 2 and N = 4 at n = 12 (N = 4: 16 x 16 blocks over Cl(4); N = 0 is the whole matrix route)
{
  const { x, y } = P.productInputs(12, 3), a = P.productMatrixRoute(P.productRep(12, 0), x, y), b = P.productMatrixRoute(P.productRep(12, 4), x, y), c = P.productMatrixRoute(P.productRep(12, 2), x, y);
  ok(same(a, b) && same(a, c), 'n = 12: blocks over Cl(0), Cl(2) and Cl(4) give the same product');
}
// negative controls: a wrong sign table or a wrong chirality must not pass
{
  const n = 6, { x, y } = P.productInputs(n, 5), ref = P.productBitRule(x, y, n), T = P.productSignTable(n), bad = T.slice(); bad[5 * 64 + 9] *= -1;
  ok(!same(P.productWithTable(x, y, n, bad), ref), 'a single wrong sign in the table is caught');
  const rep = P.productRep(n, 0), broken = { ...rep, sg: rep.sg.slice() }; broken.sg[17] *= -1;
  ok(!same(P.productMatrixRoute(broken, x, y), ref), 'a single wrong sign in the representation is caught');
}
// the matrix product has exactly m^3 products over Cl(N): count them with an instrumented base product
{
  const rep = P.productRep(10, 2), A = P.toMatrices(rep, P.productInputs(10, 1).x), B = P.toMatrices(rep, P.productInputs(10, 2).x);
  ok(rep.m === 16 && rep.B === 4 && rep.m ** 3 === 4096, 'n = 10, N = 2: 16 x 16 blocks of 4 numbers: 16^3 = 4096 products in Cl(2)');
  ok(A.length === 1 << 10 && B.length === 1 << 10, 'the matrices over Cl(N) hold as many numbers as the multivector');
}

// the check covers what is timed: the timed inputs (productSetup, seed 1) differ from the second pair (seed 7 + n), and a check that ignored the timed inputs would miss a wrong answer there
for (const n of [2, 4, 6, 8, 10, 12]) { const ctx = P.productSetup(n, false), ref = P.productBitRule(ctx.x, ctx.y, n); let s = 0; for (let i = 0; i < ref.length; i++) s += ref[i] * (1 + (i % 7));
  ok(P.productCheck(n).timedChecksum === s, `n = ${n}: productCheck ran on the timed inputs (its checksum of them equals the bit rule's on productSetup's x, y)`); }
{ const n = 6, ctx = P.productSetup(n), s2 = P.productInputs(n, 7 + n); ok(!same(ctx.x, s2.x), 'the timed inputs (seed 1) are not the second pair (seed 7 + n)');
  const fns = P.productVariants(ctx), mid = (1 << n) >> 1, ref = P.productBitRule(ctx.x, ctx.y, n)[mid];
  ok(['bitRule', 'signTable', 'signTableReuse', 'matrixRoute', 'matrixRouteReuse'].every(k => fns[k]() === ref && fns[k]() === ref), 'every timed product variant returns the exact coefficient of the timed inputs, call after call');
  ok(typeof fns.routeAllocs(3) === 'number' && !('routeAllocs' in P.productCheck(4)), 'the seven allocations alone are a timed variant with no answer to check'); }

// 4. the stored timings have the shape the page text reads (their values are machine dependent and are not tested)
ok(Array.isArray(BENCH.product) && PROD_NS.join() === '2,4,6,8,10,12', 'benchData.js holds the product timings for n = 2..12');
ok(BENCH.product.every(r => r.ns.bitRule && r.ns.matrixRoute && r.ns.matmulGiven && r.ns.signTable && (r.n < 10 || r.ns.period8)), 'every row has its variants');
ok(PROD_FACTS.route.length === 6 && PROD_FACTS.route.every(v => v > 0 && isFinite(v)) && PROD_FACTS.p8.length === 2, 'the ratios the text prints exist');
// 5. the step-16 sentence about the product says what the data say (G32 / L4-001, L4-006): the n from which the measured ratio grows is derived here from benchData.js, not read from rigidCopy.js
{
  const en = COPY.en.s.threads.frame.alg, it = COPY.it.s.threads.frame.alg, R = BENCH.product.map(r => r.ns.signTable.med / r.ns.matrixRoute.med), N = BENCH.product.map(r => r.n);
  let from = null; for (let i = 0; i < R.length - 1; i++) { let up = true; for (let j = i; j < R.length - 1; j++) if (!(R[j + 1] > R[j])) up = false; if (up) { from = N[i]; break; } }
  const wantEn = from == null ? 'not growing steadily with n' : from === N[0] ? 'growing at every step in n' : `and it grew from n = ${from} on`, wantIt = from == null ? 'senza crescere con regolarità' : from === N[0] ? 'crescendo a ogni passo in n' : `ed è cresciuta da n = ${from} in poi`;
  ok(en.includes(wantEn) && it.includes(wantIt), `the copy says where the measured ratio grows, as the data do (${wantEn} | ${wantIt})`);
  ok(!/gains more the larger n is/.test(en.replace('Counting operations, the matrix route gains more the larger n is', '')) && !/guadagna di più quanto più grande è n/.test(it.replace('Contando le operazioni, la via matriciale guadagna di più quanto più grande è n', '')), 'the growth "with n" is claimed only for the operation count, not for the timings');
  ok(!/costs more than it saves|conversion costs|costano più di quanto/.test(en + it), 'no small-n loss is put down to the conversion (no measurement separates it)');
  ok(/allocates seven Float64Array work arrays on every call \(so this measures the route plus that allocation\)/.test(en) && /alloca sette array di lavoro Float64Array \(quindi questo misura la via più quell’allocazione\)/.test(it), 'the copy says that the route as timed includes its allocation, EN and IT');
  const pending = !BENCH.product.every(r => r.ns.matrixRouteReuse && r.ns.signTableReuse && r.ns.routeAllocs);
  if (pending) { ok(en.includes('(regeneration pending)') && it.includes('(rigenerazione in sospeso)') && PROD_FACTS.pending === true, 'stored run timed before 1.2.1: the copy says so (regeneration pending)'); console.log('NOTE  regeneration pending: benchData.js has no reused-buffer product rows yet (sh selfcheck/regen_bench.sh)'); }
  else {
    const reuse = BENCH.product.map(r => r.ns.signTableReuse.med / r.ns.matrixRouteReuse.med), share = BENCH.product.map(r => Math.round(100 * r.ns.routeAllocs.med / r.ns.matrixRoute.med) + ' %');
    const f = (v, l) => (v >= 10 ? v.toFixed(0) : v.toFixed(2)).replace('.', l === 'it' ? ',' : '.') + '×';
    ok(en.includes('(the route itself, against the sign-table rule with its output array also allocated once), it was ' + reuse.map(v => f(v, 'en')).join(', ') + ';') && it.includes('è stata ' + reuse.map(v => f(v, 'it')).join(', ') + ';'), 'the copy quotes the route with buffers allocated once from the data, EN and IT');
    ok(en.includes('the seven allocations alone took ' + share.join(', ') + ' of the time') && it.includes('hanno preso ' + share.join(', ') + ' del tempo'), 'the copy quotes the share of the seven allocations from the data');
  }
  if (process.env.LB_FINAL) ok(!pending && !/regeneration pending|rigenerazione in sospeso/.test(JSON.stringify(COPY)), 'final check: no "regeneration pending" left in the copy');
}
console.log(`PRODUCT TESTS ${fails.length ? 'FAILED' : 'OK'}: ${n_ok} checks`);
process.exit(fails.length ? 1 : 0);
