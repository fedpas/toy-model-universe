// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Copy of the frame of the lenses page (steps 17 to 20: finite groups, the category lens, Baez, Schuller), English and Italian, formal and plain.
// The copy of each chapter lives with the chapter (categoryCopy.js, baezCopy.js, schullerCopy.js); this file is only the page around them.
// Status words: checked, standard, ours, open (see storyCopy.js).
import { stepNo } from './steps.js';

const G = stepNo('lens', 'groups'), CLOCK = stepNo('core', 'clock');   // the step numbers the page names, read from steps.js

export const PAGE = {
  en: {
    h: 'Four lenses: finite groups, the category lens, Baez and Schuller',
    does: 'Four chapters, each one a lens on the same bit rule; the last three bring three research reports into the atlas. Step ' + G + ' turns to finite groups: the same rule over two elements, counting symmetries from the cube up to the Golay code. Step 18, the category lens, asks what label 0 (a generator whose square is 0) is: where it hides in the cube, how every corner gets an opposite, four moves between boxes, and the top of the ladder at rung 9. Step 19 sets the rule beside seven papers by John Baez: one particle family as the 16 even five-bit labels, the E8 ladder, the Kepler trio, and what stays open. Step 20 follows Schuller’s chain from how matter moves to the law of gravity, as far as an algebra can go: one table with three kinds of squares, outside and inside, allowed and forbidden energies. Each chapter ends with its check scripts, an honesty bar and its rows of the translation matrix; the three reports themselves, with their test suites, are in the package.',
    before: 'The second calibration ended with its questions.',
    after: 'Next: the map of everything so far, with the tree of knowledge and the next step.',
    tags: [
      ['checked standard', 'every table, count and picture here is recomputed from the bit rule in your browser and by the report scripts and the widget scripts, except three panels of the Baez chapter that show stored results, each marked as stored; the textbook parts are the classification of Clifford algebras, Frobenius duality, the Peirce and Lie-algebra branchings, root systems and Floquet–Bloch bands'],
      ['standard', 'the seven papers by Baez and Schuller’s lectures are published; where a chapter quotes a result without computing it (Kac–Moody types, Loos’s multiplicities, the Madelung order, the Kaluza–Klein mass) it says so'],
      ['ours', 'the category language, “up and down”, rung 9 as the boundary, the reading of the squares −1, 0, +1 as one three-way sorting across the chapters (the square of a generator, of an element or of a bivector: see step ' + CLOCK + ' and the Conventions page), the reading of a null direction as the radical, and every line from a paper to the atlas that is a link we drew'],
      ['checked open', 'closure equations and an action principle for Schuller’s chain (not rebuilt); groups, chirality, masses and why three generations for the Baez embeddings; whether a lone zero switch belongs among the ten kinds of matter'],
    ],
  },
  it: {
    h: 'Four lenses: finite groups, the category lens, Baez and Schuller',
    does: 'Four chapters, each one a lens on the same bit rule; the last three bring three research reports into the atlas. Step ' + G + ' turns to finite groups: the same rule over two elements, counting symmetries from the cube up to the Golay code. Il passo 18, la lente categoriale, chiede che cos’è l’etichetta 0 (un generatore di quadrato 0): dove si nasconde nel cubo, come ogni angolo ha un opposto, quattro mosse tra scatole e la cima della scala al gradino 9. Il passo 19 mette la regola accanto a sette lavori di John Baez: una famiglia di particelle come le 16 etichette pari a cinque bit, la scala di E8, il trio di Keplero e ciò che resta aperto. Il passo 20 segue la catena di Schuller da come si muove la materia alla legge della gravità, fin dove arriva un’algebra: una tabella con tre tipi di quadrati, fuori e dentro, energie permesse e proibite. Ogni capitolo finisce con i suoi script di controllo, una barra dell’onestà e le sue righe della matrice di traduzione; i tre rapporti, con le loro suite di test, sono nel pacchetto.',
    before: 'The second calibration ended with its questions.',
    after: 'Avanti: la mappa di tutto ciò che c’è finora, con l’albero della conoscenza e il passo successivo.',
    tags: [
      ['checked standard', 'ogni tabella, conteggio e immagine qui è ricalcolato dalla regola dei bit nel tuo browser e dagli script dei rapporti e dei widget, tranne tre pannelli del capitolo di Baez che mostrano risultati memorizzati, ciascuno segnato come memorizzato; le parti da manuale sono la classificazione delle algebre di Clifford, la dualità di Frobenius, le ramificazioni di Peirce e delle algebre di Lie, i sistemi di radici e le bande di Floquet–Bloch'],
      ['standard', 'i sette lavori di Baez e le lezioni di Schuller sono pubblicati; dove un capitolo cita un risultato senza calcolarlo (i tipi di Kac–Moody, le molteplicità di Loos, l’ordine di Madelung, la massa di Kaluza–Klein) lo dice'],
      ['ours', 'the category language, “up and down”, rung 9 as the boundary, the reading of the squares −1, 0, +1 as one three-way sorting across the chapters (the square of a generator, of an element or of a bivector: see step ' + CLOCK + ' and the Conventions page), the reading of a null direction as the radical, and every line from a paper to the atlas that is a link we drew'],
      ['checked open', 'le equazioni di chiusura e un principio d’azione per la catena di Schuller (non ricostruiti); gruppi, chiralità, masse e perché tre generazioni per gli embedding di Baez; se un interruttore zero solitario appartiene ai dieci tipi di materia'],
    ],
  },
};
export const PAGE_YL = {
  en: {
    h: 'Four more discoveries: counting shuffles, the zero switch, one family of particles, and a chain of ideas about gravity',
    does: 'The first story counts the ways to shuffle a pattern made only of 0 and 1, and meets a famous code. The second is about the one switch that cannot be undone: the zero switch. The third sets our switches beside seven papers by a famous physicist, John Baez, and counts one whole family of particles with five switches. The fourth follows a chain of ideas from how matter moves to the law of gravity, and says where our rule stops following it. Every picture here is worked out by your browser while you look, except three in the third story that show numbers stored in the page and say so; a script checks the numbers that are worked out. What it means in nature we do not claim.',
    before: 'Warm-up 2 ended with its questions.',
    after: 'Next: the map of everything so far.',
    tags: [
      ['checked standard', 'your browser recomputes every count and picture on this page from the switches, except three marked as stored, and scripts check the same numbers'],
      ['standard', 'the papers and lectures we set our switches beside are published; the page says where it only quotes them'],
      ['ours', 'the names we give things (“up and down”, “the border”) and every link we drew from a paper to our switches'],
      ['checked open', 'how far a zero switch goes in nature, and the equations of gravity: we did not rebuild them'],
    ],
  },
  it: {
    h: 'Four more discoveries: counting shuffles, the zero switch, one family of particles, and a chain of ideas about gravity',
    does: 'The first story counts the ways to shuffle a pattern made only of 0 and 1, and meets a famous code. La seconda parla dell’unico interruttore che non si può disfare: l’interruttore zero. La terza mette i nostri interruttori accanto a sette lavori di un fisico famoso, John Baez, e conta una famiglia intera di particelle con cinque interruttori. La quarta segue una catena di idee da come si muove la materia alla legge della gravità, e dice dove la nostra regola smette di seguirla. Ogni immagine qui è calcolata dal tuo browser mentre guardi, tranne tre nella terza storia che mostrano numeri memorizzati nella pagina e lo dicono; uno script controlla i numeri calcolati. Che cosa significa in natura non lo affermiamo.',
    before: 'Warm-up 2 ended with its questions.',
    after: 'Avanti: la mappa di tutto ciò che c’è finora.',
    tags: [
      ['checked standard', 'il tuo browser ricalcola ogni conto e immagine di questa pagina dagli interruttori, tranne tre segnati come memorizzati, e gli script controllano gli stessi numeri'],
      ['standard', 'i lavori e le lezioni accanto a cui mettiamo i nostri interruttori sono pubblicati; la pagina dice dove li cita soltanto'],
      ['ours', 'i nomi che diamo alle cose (“su e giù”, “il confine”) e ogni legame che abbiamo disegnato da un lavoro ai nostri interruttori'],
      ['checked open', 'fin dove arriva un interruttore zero in natura, e le equazioni della gravità: non le abbiamo ricostruite'],
    ],
  },
};
// short readings for the Young Learner and the Physicist (audienceCopy.js SHORT.page_lenses)
export const SHORT = {
  en: ['Counting shuffles with only 0 and 1, and a famous code. One switch has no way back: the zero switch. Then one family of particles counted with five switches, and a chain of ideas about gravity that our rule follows for a few steps. Nearly everything is recomputed in your browser; three pictures show stored numbers and say so.', 'Four chapters: finite groups (O(Q) over F_{2}, W(E_{n}) and S_{n+1}, the Golay code, M_{24} and the primes), what label 0 is (radical, Frobenius duality, four moves, the ladder to rung 9), Baez’s seven papers (one generation as 16 even five-bit labels, the E8 ladder, the Kepler trio) and Schuller’s chain up to where dynamics begins. Checked statements name their scripts; our readings and open questions are tagged.'],
  it: ['Counting shuffles with only 0 and 1, and a famous code. One switch has no way back: the zero switch. Then one family of particles counted with five switches, and a chain of ideas about gravity that our rule follows for a few steps. Nearly everything is recomputed in your browser; three pictures show stored numbers and say so.', 'Four chapters: finite groups (O(Q) over F_{2}, W(E_{n}) and S_{n+1}, the Golay code, M_{24} and the primes), what label 0 is (radical, Frobenius duality, four moves, the ladder to rung 9), Baez’s seven papers (one generation as 16 even five-bit labels, the E8 ladder, the Kepler trio) and Schuller’s chain up to where dynamics begins. Checked statements name their scripts; our readings and open questions are tagged.'],
};
export const TABS_LBL = { en: 'Finite groups, the category lens, Baez and Schuller, step by step', it: 'Finite groups, the category lens, Baez and Schuller, step by step' };
