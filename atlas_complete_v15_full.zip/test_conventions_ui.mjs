// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Conventions tab of the Conventions page in a browser (ConventionsSection.jsx; its data, conventionsCopy.js, are tested by test_conventions.mjs): English and Italian, three
// audiences, 1100 and 375 px: the rows, the badges, the ideas, the glossary, no sideways scroll, the Young Learner reads the two sentences outside the fold and the rest inside it,
// the link on page 1 opens the tab.
// Run: node test_conventions_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
import fs from 'node:fs';
import path from 'node:path';
import { PKG, PKG_DIST } from './paths.mjs';
import { chromium, setLang } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { CONV, ROWS, GLOSSARY } from './conventionsCopy.js';
let n = 0, bad = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
// the formula symbols and the technical words of the Young Learner test (test_yl_ui.mjs)
const src = fs.readFileSync(path.join(PKG, 'test_yl_ui.mjs'), 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
const APP = 'file://' + (process.env.ATLAS_DIST || PKG_DIST) + '/app.html';
const b = await chromium.launch();
const txt = (pg, sel) => pg.locator(sel).first().innerText().then(t => t.replace(/\s+/g, ' ').trim());
async function open(w, hash, lang, prof, tag) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce' }), pg = await ctx.newPage();
  pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`));
  await pg.goto(APP + hash); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(200);
  return [ctx, pg];
}
for (const lang of ['en', 'it']) for (const prof of ['Physicist', 'Mathematician']) {
  const [ctx, pg] = await open(1100, '#conventions/conventions', lang, prof, `${lang}-${prof}`);
  const tag = `${lang}/${prof}`;
  ok(await pg.locator('.tabbar [role=tab]').count() === 2 && await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${tag}: a deep link opens the Conventions tab, the first of two`);
  ok(/^CONVENTIONS AND INVARIANTS/.test(await txt(pg, '.ls .eyebrow')), `${tag}: the eyebrow has no step number: ${await txt(pg, '.ls .eyebrow')}`);
  ok(await pg.locator('.cv-row').count() === 18 && await pg.locator('.cv-idea').count() === 11 && await pg.locator('.cv-gloss dt').count() === GLOSSARY.length, `${tag}: 18 rows, 11 ideas, ${GLOSSARY.length} glossary words`);
  ok(await pg.locator('.cv-row').evaluateAll(es => es.every(e => e.querySelectorAll('.audit-line > .tag[data-flag]').length > 0)), `${tag}: every row has a badge line (the badges are direct children of the paragraph)`);
  const flags = await pg.locator('.cv-row').evaluateAll(es => es.map(e => [...e.querySelectorAll('.audit-line > .tag[data-flag]')].map(x => x.getAttribute('data-flag')).join(' ')));
  ok(flags.every((f, i) => f.split(' ').sort().join() === [...ROWS[i].tags].sort().join()), `${tag}: the badges of each row are the flags of the data: ${flags.slice(0, 3).join(' | ')}`);
  ok(await pg.locator('.cv-row .tag[role=img]').evaluateAll(es => es.every(e => (e.getAttribute('aria-label') || '').length > 2)), `${tag}: every badge has an accessible name`);
  ok(await pg.locator('.ls-glance .tag').count() === 5, `${tag}: the glance has the five status lines`);
  ok(/core_check\.py/.test(await txt(pg, '.ls-glance')), `${tag}: the glance names the check script`);
  ok(/Convention S/.test(await txt(pg, '#cv-row-2')) && /Convention T/.test(await txt(pg, '#cv-row-3')), `${tag}: conventions S and T are rows 2 and 3`);
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${tag}: no sideways scroll at 1100 px`);
  await ctx.close();
}
{ const [ctx, pg] = await open(375, '#conventions/conventions', 'en', 'Mathematician', 'en-math-375');
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'Mathematician at 375 px: no sideways scroll');
  ok(await pg.locator('.ls .lede').count() >= 2, 'the Mathematician reads the formal introduction and the second paragraph');
  await ctx.close(); }
for (const [lang, w] of [['en', 375], ['it', 375], ['en', 1100]]) {
  const [ctx, pg] = await open(w, '#conventions/conventions', lang, 'Young Learner', `${lang}-yl-${w}`), tag = `${lang}/Young Learner/${w}`;
  ok(await pg.locator('.ls-glance').count() === 0, `${tag}: no status strip`);
  const lede = await pg.locator('.ls > .lede').allInnerTexts();
  ok(lede.length === 2 && lede.every((t, i) => t.trim() === CONV.en.ledeY[i]), `${tag}: the two sentences are the visible introduction: ${lede.join(' | ').slice(0, 90)}`);
  ok(await pg.locator('.ls > details .cv-row').count() === 18 && await pg.locator('.ls > .cv, .ls > .cv-row').count() === 0, `${tag}: the rows are inside the fold For older readers`);
  // the note under every tab (ls-cap) is read too: the Young Learner's note names no file and no language
  const outside = await pg.evaluate(() => [...document.querySelectorAll('.ls p, .ls h3, .ls dt, .ls dd, .ls .eyebrow')].filter(e => !e.closest('details')).map(e => e.textContent.replace(/\s+/g, ' ').trim()));
  ok(outside.length > 0 && outside.every(t => !SYM.test(t) && !JAR.test(t)), `${tag}: the text outside the fold has no formula and no jargon (${outside.length} blocks): ${outside.filter(t => SYM.test(t) || JAR.test(t)).join(' | ')}`);
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), `${tag}: no sideways scroll`);
  await ctx.close(); }
// the link on page 1 and the link on the other tabs open the tab
for (const prof of ['Physicist', 'Young Learner']) {
  const [ctx, pg] = await open(1100, '#rule', 'en', prof, 'link-' + prof);
  await pg.locator('.words-link button').click(); await pg.waitForTimeout(250);
  ok(/#conventions\/conventions$/.test(await pg.evaluate(() => location.hash)) && await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${prof}: the words link on page 1 opens the Conventions tab`);
  await pg.locator('.tabbar [data-tab="clock"]').click(); await pg.waitForTimeout(200);
  await pg.locator('.ls .ls-cap button').click(); await pg.waitForTimeout(200);
  ok(await pg.locator('.tabbar [data-tab="conventions"][aria-selected="true"]').count() === 1, `${prof}: the words link on the clock tab opens the Conventions tab`);
  await ctx.close(); }
await b.close();
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL CONVENTIONS PAGE TESTS PASS: ${n} checks`);
process.exit(bad ? 1 : 0);
