// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Shared helper of the browser tests: the browser, and the language, which is chosen once in Settings (the gear at the end of the top navigation), not in the control bar.
import { chromium as playwrightChromium } from 'playwright';
// The browser of every browser test: `chromium` here is playwright's chromium, started with playwright's defaults, with one difference. When Chromium cannot be started
// (its download is missing: npx playwright install chromium; a system library is missing; a sandbox refuses it), launch() does not throw: the test prints one line
//   SKIP: Chromium cannot be launched (<playwright's reason>)
// and exits 77, which run_tests.sh reports as SKIP. With ATLAS_REQUIRE_BROWSER=1 the line starts with FAIL and the test exits 1.
// ATLAS_BROWSER_FAIL=<reason> makes every launch fail with that reason and starts nothing (test_ci_mode.mjs uses it). browser_probe.mjs uses tryLaunch, the same start.
export function launchReason(e) {
  const lines = String((e && e.message) || e).split('\n').map(l => l.replace(/[╔╗╚╝║═]/g, '').trim()).filter(Boolean);
  const telling = lines.find(l => /error while loading|doesn't exist|does not exist|missing|sandbox|cannot open|not found|permission denied|no usable|display/i.test(l)) || lines[0] || 'no message';
  const why = telling.replace(/^browserType\.launch:\s*/, '');
  return (why.length > 240 ? why.slice(0, 240) + '…' : why) + (/playwright install/.test(lines.join(' ')) && !/playwright install/.test(why) ? '; npx playwright install chromium downloads it' : '');
}
export async function tryLaunch(options) {
  if (process.env.ATLAS_BROWSER_FAIL) return { reason: process.env.ATLAS_BROWSER_FAIL };
  try { return { browser: await playwrightChromium.launch(options) }; } catch (e) { return { reason: launchReason(e) }; }
}
export async function launchBrowser(options) {
  const r = await tryLaunch(options); if (r.browser) return r.browser;
  const fail = process.env.ATLAS_REQUIRE_BROWSER === '1';
  console.log(`${fail ? 'FAIL' : 'SKIP'}: Chromium cannot be launched (${r.reason})`); process.exit(fail ? 1 : 77);
}
export const chromium = { launch: launchBrowser };
export async function setLang(pg, lang) {
  const sum = pg.locator('.story-nav .settings > summary');
  if (!(await pg.locator('.story-nav .settings').evaluate(e => e.open))) await sum.click();
  await pg.locator(`.story-nav .settings [data-lang="${lang}"]`).click();
  await pg.waitForTimeout(120);
}
// pages with tabs (furey, shapes, equations): open one tab
export async function tab(pg, id) { await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(150); }
// keyboard: focus `from`, then press Tab until the focused element matches `sel` (at most `max` presses); true when it got there
export async function tabTo(pg, from, sel, max = 60) {
  await pg.locator(from).first().focus();
  for (let i = 0; i < max; i++) { await pg.keyboard.press('Tab'); if (await pg.evaluate(s => !!document.activeElement && document.activeElement.matches(s), sel)) return true; }
  return false;
}
// the data-* value (or the attribute) of the focused element
export const focused = (pg, attr) => pg.evaluate(a => document.activeElement ? document.activeElement.getAttribute(a) : null, attr);
