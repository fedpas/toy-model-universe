// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The tutorial "The bit rule and four college courses" (the page reports/html/bit_rule_tutorial.html) is a page beside the reports, not one of them, and it is clean:
//  - it is a page in html/, is not in index.json, in a zip or in reportsData.js; build.sh copies it to dist/reports/html/; make_package.py knows it
//  - it opens as a file: no address, no mail link, no machine path, no external request (a script, style sheet, image or frame); its links go to its own headings, to the Atlas
//    (https://toy-model-v0.vercel.app/#<page>/<tab>, a page and a tab that exist) and to the licence page; the only script is the inline one of the tabs
//  - seven tabs (Part 0, A, B, C, D, E, closing table), each a real tab of a tab list with its own section, one shown; a print rule that shows all sections
//  - Part E (coding with the bit rule): every code block, doctest transcript and log of the part is run again, in the order of the page, in a fresh python, and what it prints is compared with the page:
//    the lines copied from a script or a log of the package are runs of whole lines of that file (data-src), the commands are run (data-cmd), the examples print what the page shows
//  - no history wording (reports/no_history.py), no first person singular, no draft or review label in the visible text
// The page is built outside the package (its builder and its 357 checks are not shipped); this test reads the page. Needs python3 for the history scan (exit 77 without).
// Run: node test_tutorial.mjs
import fs from 'node:fs'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8');
const py = (args, opts = {}) => spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 64 << 20, ...opts });
const pv = py(['-c', 'import sys']);
if (pv.error || pv.status !== 0) { console.log('SKIP: test_tutorial needs python3: ' + (pv.error ? pv.error.message : (pv.stderr || '').trim().split('\n').pop())); process.exit(77); }
const R = 'reports', PAGE = path.join(R, 'html', 'bit_rule_tutorial.html');
ok(fs.existsSync(PAGE), 'the page is in reports/html/');
const H = rd(PAGE);

// ---- beside the reports, not one of them
const idx = JSON.parse(rd(path.join(R, 'html', 'index.json')));
ok(!JSON.stringify(idx).includes('bit_rule_tutorial') && idx.reports.length === 6, 'html/index.json lists the six reports and not the tutorial');
ok(fs.readdirSync(path.join(R, 'zips')).length === 6 && !fs.readdirSync(path.join(R, 'zips')).some(z => /tutorial/i.test(z)), 'the six zips are the six reports; the tutorial has no zip');
ok(!/bit_rule_tutorial/.test(rd('reportsData.js')), 'reportsData.js (the For researchers list) does not list the tutorial');
ok(/reports\/html/.test(rd('build.sh')), 'build.sh copies reports/html/ to dist/reports/html/, where the tutorial is served');
const MP = rd(path.join(R, 'make_package.py'));
ok(MP.includes("bit_rule_tutorial.html") && Object.keys(JSON.parse(rd(path.join(R, 'MANIFEST.json'))).files).includes('html/bit_rule_tutorial.html'), 'make_package.py knows the page and MANIFEST.json lists it');
const link = rd('tutorialLinkCopy.js'); ok(link.includes("'reports/html/bit_rule_tutorial.html'"), 'the link of the first page (tutorialLinkCopy.js) points to this page');

// ---- the page opens as a file and is clean
ok(!/@/.test(H.replace(/@media|@font-face|@import|@keyframes|@supports|@page/g, '')) && !/mailto:/i.test(H), 'no "@" (no address) and no mail link in the page');
ok(!new RegExp(['[A-Za-z]:\\\\', '/tm' + 'p/', '/ho' + 'me/', '/ro' + 'ot/', 'scratch' + 'pad', 'claude' + '-0'].join('|')).test(H), 'no path of a machine in the page');   // the pattern is written in pieces so that this file does not match itself
ok(!/<script[^>]*\ssrc=|<link[^>]*rel=["']?stylesheet|<img[^>]*src=["']?https?:|url\(\s*["']?https?:|@import|<iframe|<object|<embed/i.test(H), 'the page makes no request: no external script, style sheet, image, font or frame');
const scripts = [...H.matchAll(/<script\b[^>]*>/g)].map(m => m[0]); ok(scripts.length === 1 && scripts[0] === '<script>', 'one script, inline (the tabs): ' + scripts.join(' '));
const hrefs = [...H.matchAll(/href="([^"]*)"/g)].map(m => m[1]);
const PAGES = ['rule', 'atlas', 'conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses', 'map', 'researchers', 'ask'];
const atlas = hrefs.filter(h => h.startsWith('https://toy-model-v0.vercel.app/#'));
ok(atlas.length > 10 && atlas.every(h => { const m = /^https:\/\/toy-model-v0\.vercel\.app\/#([a-z]+)(?:\/([a-z0-9]+))?$/.exec(h); return m && PAGES.includes(m[1]); }), `the ${atlas.length} Atlas links name a page of the app: ` + atlas.filter(h => !/^https:\/\/toy-model-v0\.vercel\.app\/#(rule|atlas|conventions|maxwell|shapes|equations|furey|lenses|map|researchers|ask)(\/[a-z0-9]+)?$/.test(h)).join(' '));
ok(hrefs.every(h => h.startsWith('#') || h.startsWith('https://toy-model-v0.vercel.app/#') || h.startsWith('https://polyformproject.org/')), 'the links go to its own headings, to the Atlas and to the licence page: ' + hrefs.filter(h => !(h.startsWith('#') || h.startsWith('https://toy-model-v0.vercel.app/#') || h.startsWith('https://polyformproject.org/'))).join(' '));
ok(/<title>The bit rule and four college courses<\/title>/.test(H) && /name="viewport"/.test(H) && /<h1[\s>]/.test(H) && H.includes('prefers-color-scheme') && H.includes('@media print'), 'title, viewport, heading, dark scheme and print rule');

// ---- seven tabs
const tabs = [...H.matchAll(/role="tab"[^>]*\bid="tab-([A-Za-z0-9]+)"|\bid="tab-([A-Za-z0-9]+)"[^>]*role="tab"/g)].map(m => m[1] || m[2]);
ok(JSON.stringify(tabs) === JSON.stringify(['part0', 'partA', 'partB', 'partC', 'partD', 'partE', 'closing']), 'seven tabs in order: ' + tabs.join(', '));
const secs = [...H.matchAll(/<section class="tp"[^>]*\bid="([A-Za-z0-9]+)"[^>]*>/g)].map(m => m[1]);
ok(JSON.stringify(secs) === JSON.stringify(tabs) && /role="tablist"/.test(H) && !/<section class="tp"[^>]*\bhidden\b/.test(H), 'seven sections with the ids of the tabs and a tab list; without the script all seven are shown (the script hides six)');
ok(/section\.tp\[hidden\]\{display:block!important\}/.test(H), 'the print rule shows the hidden sections');

// ---- history wording, first person, labels
const nh = py(['-I', path.join(R, 'no_history.py'), PAGE]);
ok(nh.status === 0 && (nh.stdout || '').includes(PAGE + ' 0 hits'), 'the page holds none of the patterns of history of reports/no_history.py: ' + (nh.stdout || nh.stderr || '').split('\n').filter(l => /^ +P|[1-9]\d* hits/.test(l)).slice(0, 3).join(' | '));
const vis = H.replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ');
ok(!/(^|[^A-Za-z0-9ℝℤ𝔽_-])I (?=[a-z])(?!p,q)|\bmy [a-z]|\bme\b/.test(vis), 'no first person singular in the visible text (the symbol I p,q is not one)');
ok(!/\b[Dd]raft\b|not published|for review|\(draft\)/.test(vis), 'no draft or review label in the visible text');
// ---- Part E, coding: the blocks are run again (the program is tut_driver.py of the builder, read by python from the standard input)
const DRIVER = String.raw`# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Runs the blocks of Part E of the tutorial page again, in the order of the page, in one namespace and a fresh interpreter, and compares what they print with the page.
   python3 -B -I tut_driver.py <page.html> <package folder>        exit 0: every block agrees with the page; 1: a block differs (one line per difference); the last line gives the totals.
The page keeps for each block its kind (code, out, repl, log) and, where it applies, data-src (the file of the package the lines are copied from), data-cmd (the command
whose output the lines are) and data-optional (a module the block needs; the block is skipped, and counted, when it cannot be imported).
 code  : the block is run; what it prints must be the block (kind out) that follows it, and a block that prints nothing is not followed by one; with data-src the text must be a
         contiguous run of whole lines of that file
 repl  : a transcript in the format of the doctest module; every example must print what the page shows; what it defines stays defined for the blocks after it
 log   : with data-cmd the command is run in the folder selfcheck of the package with python3 -B -I and must print the lines of the page; with data-src the lines must be runs of
         whole lines of that file, in the order of the file, a line holding only the character U+2026 (the ellipsis) standing for the lines left out"""
import contextlib, doctest, html, io, os, re, shlex, subprocess, sys

def main(page, pkg):
    sys.dont_write_bytecode = True
    bad, counts, skipped, examples = [], {'code': 0, 'out': 0, 'repl': 0, 'log': 0}, 0, 0
    h = open(page, encoding='utf-8').read()
    m = re.search(r'<section class="tp"[^>]*\bid="partE"[^>]*>(.*?)(?=<section class="tp"|</main>)', h, re.S)
    if not m:
        print('FAIL the page has no section partE'); return 1
    blocks = [(k, a, html.unescape(b)) for k, a, b in re.findall(r'<pre class="(code|out|repl|log)"([^>]*)><code>(.*?)</code></pre>', m.group(1), re.S)]
    def attr(a, name):
        r = re.search(r'\bdata-' + name + r'="([^"]*)"', a)
        return html.unescape(r.group(1)) if r else None
    def runs_of_the_file(text, rel):
        """the text is made of runs of whole lines of the file, in the order of the file; a line holding only the character U+2026 stands for lines left out"""
        src = '\n' + open(os.path.join(pkg, rel), encoding='utf-8').read() + '\n'
        pos = 0
        for seg in re.split('\n\u2026\n', '\n' + text.strip('\n') + '\n'):
            seg = seg.strip('\n')
            i = src.find('\n' + seg + '\n', pos)
            if not seg or i < 0:
                return False
            pos = i + len(seg) + 1
        return True
    sc = os.path.join(pkg, 'selfcheck')
    sys.path.insert(0, sc)
    ns = {'__name__': '__tutorial__'}
    pending = None                                    # what the last code block printed, to be matched by the out block after it
    for n, (kind, a, body) in enumerate(blocks, 1):
        opt = attr(a, 'optional')
        if opt:
            try: __import__(opt)
            except ImportError:
                skipped += 1; continue
        counts[kind] += 1
        label = f'block {n} ({kind})'
        if kind != 'out' and pending:
            bad.append(f'{label}: the block before it printed output that the page does not show'); pending = None
        if kind == 'code':
            buf = io.StringIO()
            try:
                with contextlib.redirect_stdout(buf):
                    exec(compile(body + '\n', '<page>', 'exec'), ns)
            except Exception as e:
                bad.append(f'{label}: raised {type(e).__name__}: {e}'); continue
            pending = buf.getvalue().rstrip('\n') or None
            src = attr(a, 'src')
            if src and not runs_of_the_file(body, src): bad.append(f'{label}: is not a run of whole lines of {src}')
        elif kind == 'out':
            if pending is None: bad.append(f'{label}: there is no output before it')
            elif pending != body.rstrip('\n'): bad.append(f'{label}: the code printed {pending!r}, the page shows {body.rstrip(chr(10))!r}')
            pending = None
        elif kind == 'repl':
            test = doctest.DocTestParser().get_doctest(body + '\n', ns, f'block{n}', f'block{n}', 0)
            test.globs = ns                           # the one session
            runner = doctest.DocTestRunner(optionflags=0); sink = io.StringIO()
            runner.run(test, out=sink.write, clear_globs=False)
            examples += runner.tries
            if runner.tries == 0 or runner.failures: bad.append(f'{label}: {runner.failures} of {runner.tries} examples differ\n' + sink.getvalue())
        elif kind == 'log':
            cmd, src = attr(a, 'cmd'), attr(a, 'src')
            if cmd:
                argv = shlex.split(cmd)
                if argv[0] != 'python3': bad.append(f'{label}: the command does not start with python3'); continue
                r = subprocess.run([sys.executable, '-B', '-I'] + argv[1:], cwd=sc, capture_output=True, text=True)
                if r.returncode != 0 or r.stdout.rstrip('\n') != body.rstrip('\n'): bad.append(f'{label}: the command {cmd!r} printed other lines than the page (exit {r.returncode})')
            elif src:
                if not runs_of_the_file(body, src): bad.append(f'{label}: the lines are not runs of whole lines of {src}, in order')
            else:
                bad.append(f'{label}: a log block with neither data-cmd nor data-src')
    if pending: bad.append('the last code block printed output that the page does not show')
    if sum(counts.values()) < 9: bad.append(f'only {sum(counts.values())} blocks found in Part E')
    for b in bad: print('FAIL ' + b)
    print(f'tut_driver: {sum(counts.values())} blocks (code {counts["code"]}, out {counts["out"]}, repl {counts["repl"]}, log {counts["log"]}), {examples} examples, {skipped} skipped (module missing), {len(bad)} differences')
    return 1 if bad else 0

if __name__ == '__main__':
    sys.exit(main(sys.argv[1], sys.argv[2]))
`;
const dr = py(['-B', '-I', '-', PAGE, process.cwd()], { input: DRIVER });
const drLast = (dr.stdout || '').trim().split('\n').pop(), dm = /^tut_driver: (\d+) blocks \(code (\d+), out (\d+), repl (\d+), log (\d+)\), (\d+) examples, (\d+) skipped \(module missing\), (\d+) differences$/.exec(drLast);
ok(dr.status === 0 && !!dm && +dm[8] === 0 && +dm[1] === 9 && +dm[7] === 0 && +dm[2] === 4 && +dm[3] === 0 && +dm[4] === 3 && +dm[5] === 2, 'Part E: the 9 blocks (4 code, 3 transcripts, 2 logs) are run again, none skipped, and every one prints what the page shows: ' + (dr.status === 0 ? drLast : (dr.stdout || dr.stderr || '').split('\n').slice(0, 4).join(' | ')));
ok((H.match(/ data-src="/g) || []).length === 3 && (H.match(/ data-cmd="/g) || []).length === 1 && (H.match(/ data-optional="/g) || []).length === 0, 'Part E: three blocks name the file they are copied from, one the command it shows the output of, and no block needs a module outside the standard library');
for (const rel of [...H.matchAll(/ data-src="([^"]+)"/g)].map(m => m[1])) ok(fs.existsSync(rel) && !/[A-Za-z]:\\|^\//.test(rel), 'Part E: the file named in data-src exists in the package and is a relative path: ' + rel);
for (const f of [PAGE]) ok(!/PolyForm Noncommercial 1\.0\.0/.test(H) || /Cascade Atlas authors/.test(H), 'the notice of the pictures is on the page');
console.log(`test_tutorial: ${checks - bad} ok, ${bad} failed`); process.exit(bad ? 1 : 0);
