// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The "For researchers" page (v10.2) in a real browser: it opens by #researchers and by its button in the page bar (10 of 11); every anchor of its
// in-page menu scrolls just below the page bar and stays in the address; the filters of the claims table change the rows shown as the data says
// (flags AND / OR, the known-ground switch, the group, the search); the frozen and the tally rows carry their markers; the translation matrix
// filters by source, column and grade, a row opens its notes (and #researchers/matrix-<id> opens them on load), a column its counts and the rows
// with no cell there; a theorem shows the statements it backs in the table; the Analyses block lists every analysis of analysesData.js with its actions (Open in a new tab,
// Download page, Download source (md), Download code where there is a zip), its kind and its check ids as plain text, no status chip, and the page it opens is the build's own
// self-contained page, which asks for nothing beyond its own file; at 320 and 375 px nothing makes the page wider than the window
// (the wide tables scroll inside their own frame); the Italian page shows the Italian note above every English section; the Young Learner
// reads only the plain pointer, with no formula and no technical word (the lists of test_yl_ui.mjs). Screenshots at 375 and 1100 px are written
// to SHOTS (paths.mjs; ATLAS_SHOTS=<folder>) for a human to look at.   Run: node test_researchers_ui.mjs   (ATLAS_DIST=<folder>, default <package>/dist)
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { APP_HTML, PKG, SHOTS, DIST } from './paths.mjs';
import { CLAIMS } from './claimsData.js';
import { MATRIX_ROWS, MATRIX_COLUMNS } from './translationMatrixData.js';
import { THEOREMS, QUESTIONS, SOURCES } from './researchersData.js';
import { RS } from './researchersCopy.js';
import { isKnown, isPlainCitation, checkText } from './researchersModel.js';
import { ANALYSES } from './analysesData.js';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const count = f => CLAIMS.filter(f).length, known = count(c => isKnown(c.flags));
const ANCHORS = ['status', 'claims', 'matrix', 'theorems', 'questions', 'sources', 'reports', 'analyses', 'run', 'genesis'];
async function open(lang, prof, w, h = 900, hash = '#researchers') {
  const ctx = await b.newContext({ viewport: { width: w, height: h }, reducedMotion: 'reduce' });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, prof]);
  const pg = await ctx.newPage(), tag = `${lang} ${prof} ${w}`;
  pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`));
  await pg.goto(APP_HTML + hash); await pg.waitForTimeout(500);
  return { ctx, pg, tag };
}
const rows = pg => pg.locator('.rs-ct tbody tr').count();
const shownNum = async (pg, sec) => Number(await pg.locator(`#${sec} .rs-count`).first().getAttribute('data-shown'));
const shot = async (pg, name) => { try { await pg.screenshot({ path: path.join(SHOTS, name + '.png') }); } catch (e) { console.log('screenshot ' + name + ': ' + e.message); } };
const toAnchor = (pg, a) => pg.evaluate(a => { const el = document.getElementById(a); window.scrollTo(0, window.scrollY + el.getBoundingClientRect().top - document.querySelector('.story-nav').getBoundingClientRect().height - 4); }, a);

// ---- 1. by the page bar and by the address; the frame says page 10 of 11; every anchor scrolls
{ const { ctx, pg, tag } = await open('en', 'Physicist', 1100, 900, '#map');
  await pg.locator('.story-nav > button').nth(9).click(); await pg.waitForTimeout(400);
  ok(await pg.evaluate(() => location.hash) === '#researchers' && await pg.locator('#researchers-top').count() === 1, `${tag}: the page bar opens the page (button 10)`);
  ok((await pg.locator('.page-intro .eyebrow').textContent()) === 'PAGE 10 OF 11', `${tag}: PAGE 10 OF 11`);
  ok(await rows(pg) === CLAIMS.length && await shownNum(pg, 'claims') === CLAIMS.length, `${tag}: ${CLAIMS.length} rows in the claims table (${await rows(pg)})`);
  const stat = async k => (await pg.locator(`.rs-stat[data-stat="${k}"] b`).textContent()).trim();
  ok(await stat(0) === String(CLAIMS.length) && await stat(1) === String(known) && await stat('ours') === String(count(c => c.flags.includes('ours'))) && await stat('open') === String(count(c => c.flags.includes('open'))), `${tag}: the status counts are the claims' (known ground ${await stat(1)})`);
  { const dp = await pg.locator('#sources .rs-pill.kind').evaluateAll(es => es.map(e => ({ h: e.getBoundingClientRect().height, flag: /\b(standard|checked|ours|open|input)\b/.test(e.className), t: e.textContent }))); ok(dp.length >= 1 && dp.every(d => d.h >= 14 && !d.flag && d.t === 'dead end'), `${tag}: the dead-end mark is a legible neutral kind chip (${JSON.stringify(dp)})`); }
  for (const a of ANCHORS) {
    await pg.evaluate(() => window.scrollTo(0, 0)); await pg.waitForTimeout(60);
    await pg.locator(`.rs-toc a[data-to="${a}"]`).click(); await pg.waitForTimeout(250);
    const r = await pg.evaluate(a => { const el = document.getElementById(a), nav = document.querySelector('.story-nav').getBoundingClientRect().bottom; return { top: el.getBoundingClientRect().top, nav, end: scrollY + innerHeight >= document.documentElement.scrollHeight - 2, hash: location.hash }; }, a);
    ok(r.hash === '#researchers/' + a && ((r.top >= r.nav - 2 && r.top <= r.nav + 30) || (r.end && r.top >= r.nav - 2)), `${tag}: the menu link "${a}" scrolls its section just below the page bar (top ${Math.round(r.top)}, bar ${Math.round(r.nav)}, ${r.hash})`);
  }
  await ctx.close(); }
// a deep link to an anchor, and to a matrix row (its notes open)
{ const { ctx, pg, tag } = await open('en', 'Mathematician', 1100, 900, '#researchers/reports');
  const r = await pg.evaluate(() => document.getElementById('reports').getBoundingClientRect().top - document.querySelector('.story-nav').getBoundingClientRect().bottom);
  ok(r >= -2 && r <= 30, `${tag}: #researchers/reports lands on the reports (${Math.round(r)} px below the bar)`);
  ok(await pg.locator('#reports article').count() === 6 && await pg.locator('#reports article a[href^="reports/html/"]').count() >= 6 && await pg.locator('#errata').count() === 0, `${tag}: the reports block lists the six reports, each linked, and there is no errata section`);
  // the Analyses block: one card per analysis, with its words, its actions and its check ids; no status chip
  await pg.goto(APP_HTML + '#researchers/analyses'); await pg.reload(); await pg.waitForTimeout(600);
  { const r = await pg.evaluate(() => document.getElementById('analyses').getBoundingClientRect().top - document.querySelector('.story-nav').getBoundingClientRect().bottom);
    ok(r >= -2 && r <= 30, `${tag}: #researchers/analyses lands on the analyses (${Math.round(r)} px below the bar)`);
    ok(await pg.locator('#analyses article.rs-an').count() === ANALYSES.length && ANALYSES.length >= 11, `${tag}: the Analyses block lists the ${ANALYSES.length} analyses of analysesData.js (${await pg.locator('#analyses article.rs-an').count()})`);
    const cards = await pg.locator('#analyses article.rs-an').evaluateAll(es => es.map(e => ({ id: e.getAttribute('data-analysis'), h: e.querySelector('h4').textContent, kind: e.querySelector('.rs-kind').textContent, line: e.querySelector('.rs-card-h + p').textContent,
      open: [...e.querySelectorAll('a[data-analysis-link]')].map(x => [x.getAttribute('href'), x.getAttribute('target'), x.textContent]), page: [...e.querySelectorAll('a[data-dl="page"]')].map(x => [x.getAttribute('href'), x.getAttribute('download'), x.textContent]),
      src: [...e.querySelectorAll('a[data-dl="source"]')].map(x => [x.getAttribute('href'), x.getAttribute('download')]), srcLabel: e.querySelector('.rs-dl').textContent, code: [...e.querySelectorAll('a[data-dl="code"]')].map(x => [x.getAttribute('href'), x.getAttribute('download'), x.textContent]),
      ck: e.querySelector('.rs-ck span[lang="en"]').textContent, ckLabel: e.querySelector('.rs-ck .rs-k').textContent, chips: e.querySelectorAll('.tag, .sb, .chip, [role="img"], svg').length, h4lang: e.querySelector('h4').getAttribute('lang') })));
    const base = f => f.split('/').pop(), wrong = [];
    for (const [i, a] of ANALYSES.entries()) { const c = cards[i] || {};
      const good = c.id === a.id && c.h === a.title && c.kind === a.kind && c.line === a.line && c.h4lang === 'en'
        && JSON.stringify(c.open) === JSON.stringify([[a.html, '_blank', 'Open']]) && JSON.stringify(c.page) === JSON.stringify([[a.html, base(a.html), 'Download page']])
        && JSON.stringify(c.src) === JSON.stringify(a.sources.map(f => [f, base(f)])) && c.srcLabel.includes(a.sources.length === 1 ? 'Download source (md)' : 'Download sources (md):')
        && JSON.stringify(c.code) === JSON.stringify(a.code ? [[a.code, base(a.code), 'Download code']] : []) && c.ck === checkText(a.checks) && c.ckLabel === 'Checks it quotes' && c.chips === 0;
      if (!good) wrong.push(a.id + ' ' + JSON.stringify(c).slice(0, 300)); }
    ok(wrong.length === 0, `${tag}: each analysis shows its title, kind and line, Open (a new tab), Download page, Download source (md), Download code where it has a zip, and its check ids as plain text, with no status chip: ` + wrong.join(' | '));
    const missing = ANALYSES.flatMap(a => [a.html, ...a.sources, ...(a.code ? [a.code] : [])]).filter(f => !fs.existsSync(path.join(DIST, f)));
    ok(missing.length === 0, `${tag}: every page, source and zip the block links is in the build: missing ` + missing.join(', '));
    // Open opens the page of the build in a new tab; it is self-contained: the only request is its own file
    const a0 = ANALYSES.find(a => a.code) || ANALYSES[0], reqs = []; ctx.on('request', q => reqs.push(q));
    const [pop] = await Promise.all([ctx.waitForEvent('page'), pg.locator(`#an-${a0.id} a[data-analysis-link]`).click()]);
    await pop.waitForLoadState('load'); await pop.waitForTimeout(200);
    const own = reqs.filter(q => { try { return q.frame().page() === pop; } catch { return false; } }).map(q => q.url());
    ok(pop.url().endsWith('/' + a0.html) && (await pop.title()) === a0.title && await pop.locator('main math').count() > 0 && await pop.locator('main h2[id]').count() > 3 && own.length >= 1 && own.every(u => u === pop.url()),
      `${tag}: Open shows ${a0.html} in a new tab, with its title, its formulas as MathML and its anchored sections, and it asks for nothing beyond its own file (${own.length} request(s): ${[...new Set(own)].map(u => u.split('/').pop()).join(', ')})`);
    await pop.close(); }
  await pg.goto(APP_HTML + '#researchers/claim-MAP-010'); await pg.reload(); await pg.waitForTimeout(600);
  const cr = await pg.evaluate(() => { const el = document.getElementById('claim-MAP-010'), r = el.getBoundingClientRect(), p = el.closest('.rs-wrap').getBoundingClientRect(), h = el.closest('.rs-wrap').querySelector('thead').getBoundingClientRect(), nav = document.querySelector('.story-nav').getBoundingClientRect().bottom; return { row: r.top, head: h.bottom, pane: p.top, nav }; });
  ok(cr.pane >= cr.nav - 2 && cr.row >= cr.head - 2 && cr.row < 900, `${tag}: #researchers/claim-MAP-010 shows that row just below the head of its table, the table below the page bar (${JSON.stringify(cr)})`);
  await pg.goto(APP_HTML + '#researchers/matrix-C6-cat'); await pg.reload(); await pg.waitForTimeout(600);
  const c6 = MATRIX_ROWS.find(x => x.uid === 'C6-cat');
  ok(await pg.locator('#matrix-panel[data-panel="row:C6-cat"]').count() === 1 && await pg.locator('#matrix-panel li').count() === Object.keys(c6.cells).length, `${tag}: #researchers/matrix-C6-cat opens the notes of that row (${await pg.locator('#matrix-panel li').count()} cells)`);
  await pg.goto(APP_HTML + '#researchers/matrix-L1'); await pg.reload(); await pg.waitForTimeout(600);
  ok(await pg.locator('#matrix-panel li[data-col="rule"] .rs-kind[data-kind="labels"]').count() === 1, `${tag}: the notes of row L1 name the kind of its rule cell (labels)`);
  ok((await pg.locator('#matrix-table td[aria-label*="labels"]').count()) >= 1 && (await pg.locator('.rs-colbtn[data-col="rule"]').getAttribute('title')).endsWith('(labels · product · module)'), `${tag}: the rule column says its three kinds in its header and in its cells`);
  await ctx.close(); }

// ---- 2. the claims table: filters, markers, counts
{ const { ctx, pg, tag } = await open('en', 'Physicist', 1100);
  const want = async (w, m) => { await pg.waitForTimeout(80); const r = await rows(pg), s = await shownNum(pg, 'claims'); ok(r === w && s === w, `${tag}: ${m}: ${w} rows (table ${r}, count ${s})`); };
  ok(await pg.locator('.rs-ct tbody tr.frozen .rs-frozen').count() === 9 && await pg.locator('.rs-ct tbody tr.frozen').count() === 9, `${tag}: the nine frozen Genesis rows say "wording frozen"`);
  ok(await pg.locator('.rs-ct tbody tr.tally .rs-tally').count() === 15, `${tag}: the 15 tally rows say "navigation row"`);
  { const t = await pg.locator('.rs-ct').innerText(); ok(!/the owner|not displayed|no flag yet|left unchanged/i.test(t), `${tag}: the claims table shows no process note and no "no flag yet"`); ok(await pg.locator('.rs-ct .rs-noflag').count() === CLAIMS.filter(c => c.en.some(l => !l.flags.length)).reduce((n, c) => n + c.en.filter(l => !l.flags.length).length, 0), `${tag}: a line without a flag says "no flag"`); }
  const split = CLAIMS.find(c => c.en.length > 1);
  ok(await pg.locator(`#claim-${split.id} .rs-line`).count() === split.en.length && (await pg.locator(`#claim-${split.id} .rs-line`).first().getAttribute('data-label')) === 'theorem', `${tag}: a split statement shows its lines, the theorem first (${split.id})`);
  await pg.locator('#claims button[data-flag="ours"]').click(); await want(count(c => c.flags.includes('ours')), 'flag ours');
  await pg.locator('#claims button[data-flag="open"]').click(); await want(count(c => c.flags.includes('ours') && c.flags.includes('open')), 'ours AND open');
  await pg.locator('#claims button[data-mode="any"]').click(); await want(count(c => c.flags.includes('ours') || c.flags.includes('open')), 'ours OR open');
  await pg.locator('#claims [data-clear="claims"]').click(); await want(CLAIMS.length, 'cleared');
  await pg.locator('#claims button[data-ground="known"]').click(); await want(known, 'known ground only');
  ok(await pg.locator('.rs-ct tbody tr[data-known="0"]').count() === 0, `${tag}: known ground only shows no other row`);
  await pg.locator('#claims button[data-ground="hide"]').click(); await want(CLAIMS.length - known + count(c => c.tally && isKnown(c.flags)), 'everything except known ground (tally rows stay)');
  await pg.locator('#claims button[data-ground="hide+std"]').click(); await want(count(c => c.tally || (!isKnown(c.flags) && !isPlainCitation(c.flags))), 'also hide plain citations');
  ok(await pg.locator('.rs-ct tbody tr.tally').count() === 15, `${tag}: the tally rows are never hidden`);
  await pg.locator('#claims button[data-ground="all"]').click();
  await pg.locator('#claims select[data-filter="group"]').selectOption('ATL'); await want(25, 'group ATL');
  await pg.locator('#claims select[data-filter="group"]').selectOption(''); await pg.locator('#claims input[data-filter="q"]').fill('ATL-007'); await want(1, 'search ATL-007');
  ok(await pg.locator('#claim-ATL-007').count() === 1, `${tag}: the row found is ATL-007`);
  await pg.locator('#claims input[data-filter="q"]').fill('zzzz no such words'); await pg.waitForTimeout(80);
  ok(await rows(pg) === 0 && await pg.locator('#claims .rs-empty').count() === 1, `${tag}: a search that finds nothing says so`);
  await pg.locator('#claims [data-clear="claims"]').click(); await want(CLAIMS.length, 'cleared again');
  // the reader filter of the Settings menu (main[data-rf]) moves the switch to its hiding choice, and back
  await pg.evaluate(() => document.querySelector('main').setAttribute('data-rf', 'known')); await pg.waitForTimeout(120);
  ok((await pg.locator('#claims button[data-ground="hide"]').getAttribute('aria-pressed')) === 'true', `${tag}: the reader filter "known" selects "everything except known ground"`);
  await pg.evaluate(() => document.querySelector('main').setAttribute('data-rf', 'off')); await pg.waitForTimeout(120);
  ok((await pg.locator('#claims button[data-ground="all"]').getAttribute('aria-pressed')) === 'true', `${tag}: the reader filter "off" shows all again`);
  // a theorem shows the statements it backs
  const t = THEOREMS.find(x => x.usedFor.length);
  if (t) { await pg.locator(`#thm-${t.id} button[data-claim="${t.usedFor[0]}"]`).click(); await pg.waitForTimeout(300); ok(await rows(pg) === 1 && await pg.locator(`#claim-${t.usedFor[0]}`).count() === 1, `${tag}: ${t.id} shows ${t.usedFor[0]} in the claims table`); }
  // an answered question shows its answer after the question, with the badges of its flags (icons: the word is the accessible name, no word chip); an open question shows none
  { const ans = QUESTIONS.filter(q => q.answer), got = await pg.locator('#questions article.rs-card .rs-ans').count();
    ok(got === ans.length && await pg.locator('#q-QT6 .rs-ans').count() === 1 && await pg.locator('#q-QT9 .rs-ans').count() === 0 && await pg.locator('#q-QT9 .rs-kv').count() === 3, `${tag}: ${ans.length} answered questions show their answer (${got}), QT6 among them; QT9 stays a question`);
    const b = await pg.locator('#q-QD1 .rs-ans .sb').evaluateAll(es => es.map(e => [e.getAttribute('data-flag'), !!e.getAttribute('aria-label'), e.textContent.trim()]));
    ok(JSON.stringify(b.map(x => x[0])) === JSON.stringify(QUESTIONS.find(q => q.id === 'QD1').answerTags) && b.every(x => x[1] && x[2] === ''), `${tag}: QD1 shows the badges ${b.map(x => x[0]).join(', ')}, each an icon with an accessible name`); }
  // a theorem with remarks shows them last in its card, each with the icon badges of its flags; the source S4 shows its reading in the atlas's terms, and the fields that a statement row points at carry their badges
  { const withR = THEOREMS.filter(t => t.remarks), got = [];
    for (const t of withR) got.push([t.id, await pg.locator(`#thm-${t.id} .rs-ans`).evaluateAll(es => es.map(e => [...e.querySelectorAll('.sb')].map(x => x.getAttribute('data-flag') + (x.getAttribute('aria-label') && x.textContent.trim() === '' ? '' : '!')).join(' ')))]);
    ok(withR.length === 6 && got.every(([id, r]) => JSON.stringify(r) === JSON.stringify(THEOREMS.find(t => t.id === id).remarks.map(x => x.tags.join(' ')))) && await pg.locator('#theorems .rs-ans').count() === 6, `${tag}: the remarks of ${withR.map(t => t.id).join(', ')} show their flags as icons (${JSON.stringify(got)})`);
    const s4 = SOURCES.find(s => s.id === 'S4'), kv = await pg.locator('#src-S4 .rs-kv > .k').allTextContents(), sb = await pg.locator('#src-S4 .rs-ans').evaluateAll(es => es.map(e => [...e.querySelectorAll('.sb')].map(x => x.getAttribute('data-flag')).join(' ')));
    ok(JSON.stringify(kv) === JSON.stringify(['What it says', 'What we computed', "In the atlas's terms", 'Verdict']) && JSON.stringify(sb) === JSON.stringify([s4.tags.weComputed, s4.tags.atlasTerms, s4.tags.verdict].map(x => x.join(' '))) && await pg.locator('#src-S4 [data-dead="1"], #src-S4.rs-card[data-dead="1"]').count() === 0 && await pg.locator('#src-S26').count() === 1, `${tag}: S4 shows four fields (${kv.join(' | ')}) with the badges ${JSON.stringify(sb)}, no dead-end mark; S26 is on the list`); }
  await ctx.close(); }

// ---- 3. the translation matrix
{ const { ctx, pg, tag } = await open('en', 'Mathematician', 1100);
  const mrows = () => pg.locator('.rs-mx tbody tr').count();
  ok(await mrows() === 131 && await pg.locator('.rs-mx thead .rs-colbtn').count() === 22, `${tag}: 131 rows x 22 columns`);
  const cellsShown = await pg.locator('.rs-mx td.g:not(.g0)').count(), letters = await pg.locator('.rs-mx td.g:not(.g0)').evaluateAll(es => es.every(e => /^[ESA]$/.test(e.textContent) && e.getAttribute('aria-label')));
  ok(cellsShown === MATRIX_ROWS.reduce((s, r) => s + Object.keys(r.cells).length, 0) && letters, `${tag}: every graded cell shows its letter and has an accessible name (${cellsShown})`);
  // the grade mark: the letter is the mark; its word (exact, structural, analogy) is the hover text, and the accessible name where no word is printed beside it
  ok(await pg.locator('.rs-mx td.g:not(.g0) .rs-g').evaluateAll(es => es.every(e => ({ E: 'exact', S: 'structural', A: 'analogy' })[e.textContent] === e.getAttribute('title'))) && await pg.locator('#matrix button[data-grade] .rs-g').evaluateAll(es => es.length === 3 && es.every(e => e.getAttribute('title') && e.getAttribute('aria-hidden') === 'true')), `${tag}: a grade mark has the word of its grade as hover text`);
  await pg.locator('#matrix button[data-src="baez"]').click(); await pg.waitForTimeout(80);
  ok(await mrows() === 48, `${tag}: source Baez: 48 rows (${await mrows()})`);
  await pg.locator('#matrix select[data-filter="col"]').selectOption('maxwell'); await pg.waitForTimeout(80);
  ok(await mrows() === MATRIX_ROWS.filter(r => r.src === 'baez' && r.cells.maxwell).length, `${tag}: Baez rows with a Maxwell cell (${await mrows()})`);
  await pg.locator('#matrix button[data-src=""]').click(); await pg.locator('#matrix select[data-filter="col"]').selectOption(''); await pg.locator('#matrix button[data-grade="A"]').click(); await pg.waitForTimeout(80);
  ok(await mrows() === MATRIX_ROWS.filter(r => Object.values(r.cells).some(x => x.grade === 'A')).length && await pg.locator('#matrix .rs-count').getAttribute('data-shown') === String(await mrows()), `${tag}: grade A: the rows with an analogy (${await mrows()})`);
  await pg.locator('#matrix button[data-grade="A"]').click(); await pg.waitForTimeout(80);
  const L9 = MATRIX_ROWS.find(r => r.uid === 'L9');
  await pg.locator('.rs-mx button.rs-rowbtn[data-uid="L9"]').click(); await pg.waitForTimeout(250);
  ok(await pg.locator('#matrix-panel[data-panel="row:L9"] li').count() === Object.keys(L9.cells).length && await pg.evaluate(() => location.hash) === '#researchers/matrix-L9', `${tag}: the row L9 opens its ${Object.keys(L9.cells).length} notes and its address`);
  const pTop = await pg.evaluate(() => document.getElementById('matrix-panel').getBoundingClientRect().top);
  ok(pTop >= 0 && pTop < 900, `${tag}: the notes are in view (${Math.round(pTop)})`);
  await shot(pg, 'R1_en_1100_matrix_row');
  await pg.locator('.rs-mx button.rs-colbtn[data-col="furey"]').click(); await pg.waitForTimeout(250);
  const none = MATRIX_ROWS.filter(r => !r.cells.furey).length, has = 131 - none;
  ok(await pg.locator('#matrix-panel[data-panel="col:furey"] .rs-none .rs-idbtn').count() === none && await pg.locator('#matrix-panel[data-panel="col:furey"] > ul > li').count() === has, `${tag}: the Furey column lists ${has} rows with a cell and ${none} with none`);
  const fc = ['E', 'S', 'A'].map(g => MATRIX_ROWS.filter(r => r.cells.furey?.grade === g).length);
  ok((await pg.locator('#matrix-panel p[data-counts="furey"]').textContent()) === RS.en.matrix.colCounts(...fc) && (await pg.locator('.rs-mx tfoot tr[data-count="E"] td').nth(MATRIX_COLUMNS.findIndex(c => c.key === 'furey')).textContent()) === String(fc[0] || '·'), `${tag}: the Furey counts ${fc} in the panel and in the table foot`);
  await shot(pg, 'R1_en_1100_matrix_column');
  await pg.locator('#matrix-panel .rs-x').click(); await pg.waitForTimeout(80); ok(await pg.locator('#matrix-panel').count() === 0, `${tag}: Close closes the panel`);
  await ctx.close(); }

// ---- 4. screenshots, phone widths without page overflow, Italian notes
for (const [lang, prof, w] of [['en', 'Physicist', 1100], ['en', 'Physicist', 375], ['it', 'Mathematician', 1100], ['it', 'Mathematician', 375], ['it', 'Physicist', 320]]) {
  const { ctx, pg, tag } = await open(lang, prof, w, w < 700 ? 740 : 900);
  const ov = await pg.evaluate(() => document.documentElement.scrollWidth - innerWidth);
  ok(ov <= 0, `${tag}: no horizontal page overflow (${ov} px)`);
  if (w < 700) ok(await pg.evaluate(() => [...document.querySelectorAll('.rs-wrap')].every(e => e.scrollWidth > e.clientWidth && getComputedStyle(e).overflowX === 'auto')), `${tag}: the two tables scroll sideways inside their own frame`);
  const notes = await pg.locator('#researchers-top section .lang-note').count(), want = lang === 'it' ? 9 : 0;
  ok(notes === want, `${tag}: ${want} notes "in English" (${notes})`);
  if (lang === 'it') {
    ok((await pg.locator('#researchers-top .lang-note').first().textContent()) === RS.it.claimsNote && await pg.locator('#theorems .lang-note').textContent() === 'Questa sezione è in inglese.', `${tag}: the Italian notes read as written`);
    ok((await pg.locator('#claim-ATL-001 .rs-grpname').textContent()) === RS.it.groups.ATL && (await pg.locator('.story-nav > button.active').textContent()).includes('Per i ricercatori'), `${tag}: Italian group names and page bar`);
    ok(await pg.locator('#claim-ATL-001 p[lang="en"]').count() >= 1, `${tag}: English statement text is marked lang="en"`);
  }
  if (w === 1100 || w === 375) for (const a of ['top', 'status', 'claims', 'matrix', 'theorems', 'reports', 'analyses', 'run']) { if (a !== 'top') await toAnchor(pg, a); else await pg.evaluate(() => window.scrollTo(0, 0)); await pg.waitForTimeout(120); await shot(pg, `R1_${lang}_${prof.replace(' ', '')}_${w}_${a}`); }
  await ctx.close();
}

// ---- 5. the Young Learner: only the plain pointer; no formula and no technical word (the lists of test_yl_ui.mjs)
{ const Y = fs.readFileSync(path.join(PKG, 'test_yl_ui.mjs'), 'utf8');
  const SYM = /^const SYMBOLS = \/(.+)\/;$/m.exec(Y)[1], JAR = /^const JARGON = \/(.+)\/i;$/m.exec(Y)[1];
  for (const lang of ['en', 'it']) for (const w of [1100, 375]) {
    const { ctx, pg, tag } = await open(lang, 'Young Learner', w, 900);
    ok((await pg.locator('#researchers-yl .rs-yl').textContent()) === RS[lang].pointer, `${tag}: the plain pointer`);
    ok(await pg.locator('#claims, #matrix, #theorems, #reports, #analyses, .rs-ct, .rs-mx, .rs-toc').count() === 0, `${tag}: no table and no list for the Young Learner (no reports, no analyses)`);
    const hits = await pg.evaluate(([s, j]) => { const SYMR = new RegExp(s, 'u'), JARR = new RegExp(j, 'i'), out = [], main = document.querySelector('main');
      const vis = el => { try { return el.checkVisibility({ checkVisibilityCSS: true }); } catch { return !!el.getClientRects().length; } }, shut = el => !!el.closest('details:not([open])') && !el.closest('summary');
      const test = t => { const m = SYMR.exec(t) || JARR.exec(t); if (m) out.push(m[0] + ' in "' + t.slice(0, 80) + '"'); };
      const w = document.createTreeWalker(main, NodeFilter.SHOW_TEXT); for (let x = w.nextNode(); x; x = w.nextNode()) { const t = x.nodeValue.replace(/\s+/g, ' ').trim(), el = x.parentElement; if (!t || !el || el.closest('script,style') || !vis(el) || shut(el)) continue; test(t); }
      for (const e of main.querySelectorAll('[aria-label], [title]')) if (vis(e) && !shut(e)) for (const t of [e.getAttribute('aria-label'), e.getAttribute('title')]) if (t) test(t);
      return out; }, [SYM, JAR]);
    ok(!hits.length, `${tag}: no formula and no technical word on the page: ${hits.slice(0, 3).join(' | ')}`);
    if (w === 375) await shot(pg, `R1_${lang}_YoungLearner_375`);
    await ctx.close(); }
}
await b.close();
console.log(bad ? `${bad} FAILURES of ${n}` : `RESEARCHERS UI OK (${n} checks; screenshots in ${SHOTS})`); process.exit(bad ? 1 : 0);
