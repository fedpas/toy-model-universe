// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { eqNavIds } from './steps.js';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import fs from 'fs';
import K from './couplingData.js';
import COPY, { ringNodes } from './couplingCopy.js';
import EQC from './equationsCopy.js';
import { CP_PY, CPM_PY } from './couplingSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import { SHORT } from './audienceCopy.js';
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };
// ---- shipped data and scripts are the files
const J = JSON.parse(fs.readFileSync('./selfcheck/coupling.json', 'utf8')), JM = JSON.parse(fs.readFileSync('./selfcheck/coupling_matrix.json', 'utf8'));
ok(JSON.stringify(J) === JSON.stringify(K.coupling) && JSON.stringify(JM) === JSON.stringify(K.matrix), 'data modules equal the json files');
ok(CP_PY === fs.readFileSync('./selfcheck/coupling_selfcheck.py', 'utf8') && CPM_PY === fs.readFileSync('./selfcheck/coupling_matrix_check.py', 'utf8'), 'embedded scripts equal files');
ok(/--compare/.test(CP_PY) && /ALL COUPLING CHECKS PASS/.test(CP_PY) && /ALL MATRIX CHECKS PASS/.test(CPM_PY), 'script interfaces');
// ---- an independent Clifford product (written here)
const pc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
const bm = (a, b, sq) => { let s = 1; for (let i = 0; i < sq.length; i++) if (b >> i & 1 && pc(a >> (i + 1)) % 2) s = -s; const c = a & b; for (let i = 0; i < sq.length; i++) if (c >> i & 1) s *= sq[i]; return [a ^ b, s]; };
const rv = m => (pc(m) * (pc(m) - 1) / 2) % 2 ? -1 : 1;
const C = (n, k) => { let r = 1; for (let i = 0; i < k; i++) r = r * (n - i) / (i + 1); return Math.round(r); };
const CELL = ['M1(R) + M1(R)', 'M2(R)', 'M2(C)', 'M2(H)', 'M2(H) + M2(H)', 'M4(H)', 'M8(C)', 'M16(R)'];
const EVEN_HALF = ['R', 'M1(R) + M1(R)', 'M2(R)', 'M2(C)', 'M2(H)', 'M2(H) + M2(H)', 'M4(H)', 'M8(C)'];
const Jexp = [false, false, true, true, true, true, true, true];
for (let n = 1; n <= 8; n++) {
  const r = K.coupling.ladder[n], sq = Array.from({ length: n }, (_, i) => (i === 0 ? 1 : -1));
  const even = [...Array(1 << n).keys()].filter(m => pc(m) % 2 === 0), odd = [...Array(1 << n).keys()].filter(m => pc(m) % 2 === 1);
  ok(r.algebra === CELL[n - 1] && r.even_half === EVEN_HALF[n - 1], `n=${n}: Cl(1,${n - 1}) and its even half`);
  ok(r.psi_components === even.length && r.psi_components === 2 ** (n - 1) && r.even_corners === even.length && r.odd_corners === odd.length, `n=${n}: component counts`);
  ok(r.F_components === C(n, 2) && r.maxwell_incidences === n * C(n, 2), `n=${n}: Maxwell counts`);
  ok(r.dirac_real_dim === 2 ** (Math.floor(n / 2) + 1), `n=${n}: real Dirac dimension`);
  ok(r.psi_over_dirac === (({ 1: '1/2', 2: '1/2', 3: '1', 4: '1', 5: '2', 6: '2', 7: '4', 8: '4' })[n]), `n=${n}: ratio psi / Dirac`);
  // complex structure: bivector, squares to -1, commutes with gamma_0 (mask 1)
  const Js = [...Array(1 << n).keys()].filter(m => pc(m) === 2 && bm(m, m, sq)[0] === 0 && bm(m, m, sq)[1] === -1 && bm(m, 1, sq).join() === bm(1, m, sq).join());
  ok(Js.length === r.J_count && (Js.length > 0) === r.J_exists && r.J_exists === Jexp[n - 1], `n=${n}: complex structure J exists = ${Jexp[n - 1]}, count ${Js.length}`);
  ok(!r.J_exists || (r.J_label === 6 && Js.includes(6)), `n=${n}: J label 6`);
  // the current psi gamma_0 psi~ : blade of the product of psi_S, gamma_0, rev(psi_T), with its sign; symmetrised over S <-> T
  const coef = new Map();
  for (const S of even) for (const T of even) { if (S > T) continue; const [a, s1] = bm(S, 1, sq), [b, s2] = bm(a, T, sq); const s = s1 * s2 * rv(T); let tot = s; if (S !== T) { const [a2, t1] = bm(T, 1, sq), [b2, t2] = bm(a2, S, sq); tot += t1 * t2 * rv(S); ok(b2 === b, 'same blade'); } const key = b + '|' + S + '|' + T; if (tot !== 0) coef.set(key, [b, tot, S, T]); }
  const byBlade = {}; for (const [b, tot, S, T] of coef.values()) { (byBlade[b] ||= []).push([tot, S, T]); }
  const grades = [...new Set(Object.keys(byBlade).map(b => pc(+b)))].sort((x, y) => x - y);
  ok(JSON.stringify(grades) === JSON.stringify(r.current_grades) && grades.every(g => g % 4 === 1), `n=${n}: current grades ${grades}`);
  for (const g of grades) ok(Object.keys(byBlade).filter(b => pc(+b) === g).length === r.current_blades[g], `n=${n}: grade ${g} blade count`);
  for (const g of grades) ok([...coef.values()].filter(([b]) => pc(b) === g).length === r.current_monomials[g], `n=${n}: grade ${g} monomial count`);
  // density: coefficient of gamma_0 (mask 1) only from S = T and positive; vector components from corners differing by bits {0,k}
  ok((byBlade[1] || []).every(([t, S, T]) => S === T && t > 0) && (byBlade[1] || []).length === even.length && r.rho_terms === even.length && r.rho_positive_definite, `n=${n}: density is a sum of squares over all corners`);
  for (let k = 1; k < n; k++) { const bl = byBlade[1 << k] || []; ok(bl.length === (n >= 2 ? 2 ** (n - 2) : 0) && bl.every(([t, S, T]) => (S ^ T) === (1 | (1 << k))), `n=${n}: component ${k} uses the demicube edges {0,${k}}`); }
  if (n >= 2) ok(r.demicube_edges_of_type_0k === 2 ** (n - 2), `n=${n}: edge count of type {0,k}`);
  const dist = new Set(); for (const [b, , S, T] of coef.values()) if (pc(b) === 5) dist.add(pc(S ^ T));
  ok(JSON.stringify([...dist].sort()) === JSON.stringify(r.pair_distance['5'] || []), `n=${n}: grade-5 pair distances ${[...dist]}`);
  // minimal coupling and derivative terms, equation by equation
  if (r.J_exists) {
    const Jm = 6, [, sJ] = bm(1 << 2, 1 << 1, sq); ok(bm(1 << 2, 1 << 1, sq)[0] === Jm, 'J = gamma_2 gamma_1 has mask 6');
    const eq = new Map(odd.map(o => [o, { A: [], d: [], m: [] }]));
    for (const S of even) {
      for (let k = 0; k < n; k++) { eq.get(S ^ (1 << k)).A.push(S); const [a] = bm(S, Jm, sq); eq.get(a ^ (1 << k)).d.push(S); }
      eq.get(S ^ 1).m.push(S);
    }
    let all = 0, simplexOk = true;
    for (const [o, v] of eq) { ok(v.A.length === n && v.d.length === n && v.m.length === 1, `n=${n} blade ${o}: n + n + 1 terms`); all += v.A.length + v.d.length + v.m.length;
      for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (pc(v.A[i] ^ v.A[j]) !== 2) simplexOk = false; }
    ok(simplexOk && r.coupling_terms_are_corner_simplex === true, `n=${n}: the n even neighbours are pairwise at distance 2 (a simplex)`);
    ok(all === (2 * n + 1) * 2 ** (n - 1) && r.incidences_total === all && r.coupling_edges === n * 2 ** (n - 1) && r.derivative_edges === n * 2 ** (n - 1) && r.mass_edges === 2 ** (n - 1), `n=${n}: ${all} terms in all`);
    ok(eq.get(1).m.join() === eq.get(1).A.filter(S => S === 0).join(), `n=${n}: the mass neighbour of t is its time-edge neighbour`);
    // ring picture data equals the equation at the blade t
    const R = ringNodes(n); ok(JSON.stringify(R.map(x => x.inner).sort((a, b) => a - b)) === JSON.stringify(eq.get(1).A.slice().sort((a, b) => a - b)) && JSON.stringify(R.map(x => x.outer).sort((a, b) => a - b)) === JSON.stringify(eq.get(1).d.slice().sort((a, b) => a - b)), `n=${n}: ring nodes equal the terms of the equation at t`);
  }
}
// ---- shell dimensions and the extra components
for (let n = 3; n <= 7; n++) { const s = K.coupling.shell[n]; ok(s.kernel_real_dim === 2 ** (n - 2) && s.half_of_psi === 2 ** (n - 2) && s.one_dirac_spinor === 2 ** (Math.floor(n / 2)), `shell n=${n}`); }
for (const n of [3, 4, 5]) { const I = K.coupling.identities[n]; ok(I.conservation_identity && I.gauge_first_order && I.maxwell_forces_div_J_zero && I.algebraic_facts, `identities n=${n}`); }
// ---- the numpy results
const M = K.matrix;
ok(Object.values(M.max_error).every(x => x < 1e-9) && Object.keys(M.max_error).join() === '3,4,5,6,7', 'matrix: tiny errors for n = 3..7');
ok(Object.values(M.rank_real).join() === '4,8,8,16,16', 'matrix: real rank of psi -> psi u');
ok(M.current['5'].psi_with_zero_spinor_but_nonzero_vector_current === true && M.current['3'].ratios_X_over_bilinear.join() === '-1,1' && M.current['4'].ratios_X_over_bilinear.join() === '-1,1', 'matrix: current checks');
ok(Object.keys(M.controls).length === 3 && Object.values(M.controls).every(v => /fails/.test(v)), 'matrix: three negative controls fail');
ok(/range\(40\)/.test(CPM_PY), 'the 200 cases in the copy are 40 per n for n = 3..7');
// ---- copy
const keys = o => Object.keys(o).sort().join();
ok(keys(COPY.en) === keys(COPY.it), 'copy keys'); ok(keys(COPY.en.dl) === keys(COPY.it.dl), 'dl keys');
for (const lang of ['en', 'it']) { const t = COPY[lang];
  for (let n = 1; n <= 8; n++) { const v = t.views(K.coupling.ladder[n]); ok(v.length === 7 && v.map(x => x.h).length === 7, `${lang} n=${n}: 7 views`); for (const x of v) for (const g of x.tags) ok(STORY[lang].tags[g], `${lang} tag ${g}`); ok(t.ringCap(n) && t.ringNone(n) && t.viewsH(n), `${lang} n=${n} captions`); }
  for (const [k] of t.xr) ok([].concat(k).length >= 1 && [].concat(k).every(g => STORY[lang].tags[g]), `${lang} xr tag`); for (const [k] of t.open) ok([].concat(k).length >= 1 && [].concat(k).every(g => STORY[lang].tags[g]), `${lang} open tag`);
  const all = JSON.stringify([t, [1, 2, 3, 4, 5, 6, 7, 8].map(n => t.views(K.coupling.ladder[n]))]); ok(!/undefined|NaN|\[object/.test(all), `${lang} no placeholders`);
  for (const b of [/proves?\b.*generation/i, /explains? why three/i, /predict(s|ed)? (the|a)\b/i, /confirms?\b/i, /GUT\b/, /grand unif/i, /(?<!not a )\bwall\b|\breset/i, /\b1 (blades|components|corners|edges|terms)\b/]) ok(!b.test(all), `${lang} banned ${b}`);
  ok(t.open.length === 5 && t.xr.length === 5, `${lang} open and cross-reference lists`); }
ok(/^The size of e is a free parameter, as in every theory\. The sign of the source relative to the coupling is fixed: with L = ⟨∇ψIγ₃ψ̃⟩₀ − m⟨ψψ̃⟩₀ − e⟨Aψγ₀ψ̃⟩₀ \+ ½⟨FF⟩₀ in Cl\(1,3\) the Euler–Lagrange equations are exactly the two equations of this step with one e \(bd·phy·18, bd·phy·19\)/.test(COPY.en.open[0][1]) && /the sign of the F² term is fixed by the positivity of the field energy, which also fixes the relative sign of source and force \(bd·sol·17\)\.$/.test(COPY.en.open[0][1]) && COPY.it.open[0][1] === COPY.en.open[0][1] && /extra components of ψ/.test(COPY.en.open[2][1]) && !/generation/i.test(JSON.stringify(COPY.en.open)), 'CPL-005: only the size of e is free; the one action fixes the sign of the source (bd·phy·18, bd·phy·19) and positive field energy the relative sign of source and force (bd·sol·17); the other open items are stated');
ok(!/projection is an input|action principle that we have not rebuilt|non abbiamo ricostruito/.test(JSON.stringify(COPY)), 'no line says that the projection of the source is an input or that the action is missing');
ok(/selfcheck\/bridges\/phy_coupled_action\.py, bd·phy·18, bd·phy·19\); the size of e is a free constant$/.test(K.coupling.status.input.join(' ')) && !/sign and size of the source|have not rebuilt/.test(JSON.stringify(K.coupling.status)), 'the status list of the script names the action of the step as an input, with its checks, and the size of e as free');
ok(/ratio 2, 2, 4, 4/.test(COPY.en.xr[2][1]) && /rapporto 2, 2, 4, 4/.test(COPY.it.xr[2][1]), 'doubling ratios in the copy');
// audit round 2 (v10.2): the cross-reference lines carry the audited flags, the spinor count names its convention, the last open item points to steps 7 to 10
// v11: CPL-004 (the Dirac-Maxwell system in Hestenes' form: the equation, the grades and the chart are postulated) and CPL-005 (the coupling constant) also carry the input flag; the projected source (A-51) is an input line
for (const lang of ['en', 'it']) { const fl = k => [].concat(k).join(), X = COPY[lang].xr, O = COPY[lang].open;
  ok(X.slice(0, 3).every(([k]) => fl(k) === 'standard,checked') && fl(X[3][0]) === 'standard,checked,input', `${lang} xr lines are standard + checked; the last one is also an input`);
  ok(fl(O[0][0]) === 'checked,input' && O.slice(1, 3).every(([k]) => fl(k) === 'open') && fl(O[3][0]) === 'checked,open' && fl(O[4][0]) === 'checked', `${lang} open lines: the coupling constant is an input with the sign of the source checked, the vector source is checked, the pointer to Yang–Mills and gravity is checked and open (CPL-008)`);
  ok(/∇F, which only has grades 1 and 3, has no slot for it/.test(X[1][1]) && /The coupling term ⟨Aψγ₀ψ̃⟩₀ = A·⟨X⟩₁ sees only the vector current, so the source of ∇F is e⟨X⟩₁: no projection is chosen by hand \(bd·phy·11\)\.$/.test(O[4][1]), `${lang} grade-5 part has no slot in ∇F; the coupling term sees only the vector current (CPL-009)`);
  const v5 = COPY[lang].views(K.coupling.ladder[5])[5], v4 = COPY[lang].views(K.coupling.ladder[4])[5];
  ok(/no slot in ∇F, which only has grades 1 and 3/.test(v5.t) && /The coupling term ⟨AX⟩₀ = A·⟨X⟩₁ sees only the vector part, so the source of ∇F is e⟨X⟩₁ and no projection is chosen by hand \(bd·phy·11\)\./.test(v5.t) && v5.tags.join() === 'checked' && !/A·⟨X⟩₁/.test(v4.t) && v4.tags.join() === 'checked', `${lang} the Maxwell view at n = 5 says that the coupling term sees only the vector part (bd·phy·11), at n = 4 there is no grade-5 part`);
  const P1 = COPY[lang].yl.points[1]; ok([].concat(P1[0]).join() === 'checked,input' && /^How strong the push is, is a number we put in\./.test(P1[1]) && /one recipe taken from books/.test(P1[1]) && !/[∇ψ=⟨]/.test(P1[1]), `${lang} the Young Learner point: the size of the push is put in, the rest follows from one recipe and is checked`); }
ok(/e l’abbiamo controllata/.test(COPY.it.xr[3][1]), 'CPL-004 Italian reads as a sentence');
// the honest ours line (CPL-010): drawing the terms as edges of the cube and the current as corners and edges of the demicube is a reading, not a result; the Young Learner list carries the same status in plain words
for (const lang of ['en', 'it']) { const X = COPY[lang].xr[4], P = COPY[lang].yl.points[3];
  ok([].concat(X[0]).join() === 'ours' && /^Drawing the derivative, coupling and mass terms as edges of the cube, and the terms of the current as corners and edges of the demicube, is our reading: an idea we try, not a result\.$/.test(X[1]), `${lang} CPL-010: an ours line that says the drawing is a reading`);
  ok([].concat(P[0]).join() === 'ours' && /is our way of showing them: an idea we try, not a result\.$/.test(P[1]) && !/[∇ψ=]|demicube|simplex/.test(P[1]), `${lang} the Young Learner list has the plain ours point, without a formula`); }
ok(/in units of one complex Dirac spinor/.test(COPY.en.xr[2][1]) && /in unità di uno spinore di Dirac complesso/.test(COPY.it.xr[2][1]) && /they are steps 7 to 10/.test(COPY.en.open[3][1]) && (/sono i passi da 7 a 10/.test(COPY.it.open[3][1]) || COPY.it.open[3][1] === COPY.en.open[3][1]) && !/passi da 4 a 7/.test(COPY.it.open[3][1]), 'the spinor convention and the pointer to steps 7 to 10 are stated (English; Italian: its own sentence, or the English text of the ledger until the Italian is written)');
// the lede names the two equations that are joined: Calibration 1 (Maxwell, page 4) and step 4 (Dirac); step 2 is the commutators
for (const l of ['en', 'it']) { const L = COPY[l].lede; ok(l === 'en' ? L.startsWith('Calibration 1 (Maxwell) and step 4 (Dirac) draw two equations apart. Here we join them') && !/^Steps 2 and 4/.test(L) : L.startsWith('La Calibration 1 (Maxwell) e il passo 4 (Dirac) disegnano due equazioni separate. Qui le uniamo') && !/^I passi 2 e 4/.test(L), `${l}: the coupling lede names Calibration 1 (Maxwell) and step 4 (Dirac)`); }
ok(/4, 8, 8, 16, 16/.test(COPY.en.mat) && /4, 8, 8, 16, 16/.test(COPY.it.mat), 'rank list in the copy');
// ---- tally and nav
ok(eqNavIds().at(-1) === 'tally' && EQC.en.t.rows.length === eqNavIds().length && EQC.it.t.rows.length === eqNavIds().length, 'equations nav and tally have the coupling entry');
ok(EQC.en.t.rows[5][3] === '72 + 24 in 4D' && EQC.en.t.rows[5][2] === '8 + 6 + 4 in 4D', 'tally row from the data (row 5: Maxwell, commutators, mirrors, Dirac, spin, coupling)');
ok(/nonlinear/.test(EQC.en.t.note) && /non lineari/.test(EQC.it.t.note), 'tally says the joint systems are nonlinear');
ok(/CouplingSection/.test(fs.readFileSync('./EquationsSection.jsx', 'utf8')) && eqNavIds().includes('coupling'), 'section wired into the page');
for (const l of ['en', 'it']) ok(/Input: the action, whose Euler–Lagrange equations are both equations with one e \(bd·phy·18, bd·phy·19\); only the size of e is free\./.test(SHORT[l].coupling[1]) && !/sign and size of the source|segno e grandezza/.test(SHORT[l].coupling[1]) && /^the action of Yang–Mills \(pointer, not rebuilt; the gravity action and the scalar and Maxwell actions with their coupling to gravity are checked, and one Einstein–scalar cosmology is solved from them as an exact power series about one time\), chiral coupling/.test(STORY[l].pages.equations.tags[3][1]), `${l}: the physicist reading of the coupling and the open strip of the equations page say that the action fixes the sign and only the size of e is free`);
console.log(bad ? bad + ' FAILURES' : 'ALL COUPLING TESTS PASS'); process.exit(bad ? 1 : 0);
