// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Where things are, for every test: relative to this package, never to a machine. ATLAS_DIST=<folder> points the browser tests at another build (default: <package>/dist, made by build.sh).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
export const PKG = path.dirname(fileURLToPath(import.meta.url));
export const PKG_DIST = path.join(PKG, 'dist');
export const DIST = process.env.ATLAS_DIST ? path.resolve(process.env.ATLAS_DIST) : PKG_DIST;
export const APP_HTML = pathToFileURL(path.join(DIST, 'app.html')).href;
// screenshots the browser tests take for a human to look at (not assertions); ATLAS_SHOTS=<folder> to keep them somewhere else
export const SHOTS = process.env.ATLAS_SHOTS || path.join(os.tmpdir(), 'atlas_shots');
fs.mkdirSync(SHOTS, { recursive: true });
