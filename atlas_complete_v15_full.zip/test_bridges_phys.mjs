// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Data test of the physics bridge scripts of selfcheck/bridges/ (phy_, str_, sol_, xph_, fk_, mjp_; ids bd·phy·n, bd·str·n, bd·sol·n, bd·xph·n, bd·fk·n, bd·mjp·n). No browser.
// Run: node test_bridges_phys.mjs   (a few minutes on one core: every script runs once, the six mjp_ scripts once more with python3 -I, then one sabotaged copy per script,
//      then fk_junction.py --sabotage and the --sabotage mode of the six mjp_ scripts)
// 1. the log selfcheck/bridges/bridges_phys.json equals a fresh run, started from another folder: the same rows (id, script, kind, text, ok) in the same order; every script
//    exits 0 and its last line is "<n>/<n> bridge checks hold.  ALL BRIDGE CHECKS PASS" with n its number of check lines; the summary counts the rows; each script stays under
//    60 processor seconds (fk_junction.py: 90, a margin for a loaded machine); the scripts of the json are exactly the physics scripts of the folder (phy_bitrule.py, the engine five phy_ scripts import, holds no check);
//    the ids of each mjp_ script are exactly the pinned ones, and the six mjp_ scripts (numpy and the standard library) print the same lines with python3 -I
// 2. the README of the folder (its physics section) lists exactly the check rows, each with its script, and exactly the info rows (read-offs, not checks)
// 3. imports: the standard library and numpy; scipy only in sol_hubbard_cube.py and fk_junction.py; phy_bitrule only in phy_ scripts; the three standard-library scripts run
//    with python3 -I; the octonion lines of sol_furey_fk.py are lines of model.py
// 4. no forbidden word in the scripts, the README section, the regen script and the json (the words of a process and of a history; the mjp_ scripts and their README lines also
//    without "new" and "fixed", which the older scripts use as a variable name and in "fixed by")
// 5. sabotage: a documented one-line change per script (more for the scripts cited most) makes the copy exit 1 with FAIL for the intended id; fk_junction.py --sabotage catches all five;
//    each mjp_ script run with --sabotage (and python3 -I) exits 0 with one CAUGHT line per check of the script, no MISSED, and ALL CAUGHT
// 6. every bd·phy, bd·str, bd·sol, bd·xph, bd·fk or bd·mjp id that a file of the package cites is a row of the json (a range a–b: every number in it; the scan is tested first on
//    planted citations); no checkedBy or checks field of
//    a JSON file of the package (claimsLocators*.json, the lens dictionary, ...) cites an info id, and a checkedBy names the script of every id of this family that it cites;
//    every selfcheck/bridges/ script of this family that a file names exists
// 7. a failing script never overwrites the log: regen_bridges_phys.sh, run in a temporary copy with one script broken, stops and leaves bridges_phys.json as it was
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: the test runs from any folder
import { spawnSync } from 'node:child_process';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const DIR = 'selfcheck/bridges', JSONF = DIR + '/bridges_phys.json';
const ENV = { ...process.env, OMP_NUM_THREADS: '1', OPENBLAS_NUM_THREADS: '1', MKL_NUM_THREADS: '1', PYTHONDONTWRITEBYTECODE: '1' };
const py = (args, cwd) => spawnSync('python3', args, { cwd, env: ENV, encoding: 'utf8', timeout: 600000, maxBuffer: 1 << 26 });
const LINE = /^(ok   |FAIL |info )(bd·(?:phy|str|sol|xph|fk|mjp)·\d+[a-z]?)  (.+)$/;
const J = JSON.parse(fs.readFileSync(JSONF, 'utf8'));
const src = f => fs.readFileSync(path.join(DIR, f), 'utf8');

// ---- 1. the log equals a fresh run
const FAMILY = fs.readdirSync(DIR).filter(f => /^(phy|str|sol|xph|fk|mjp)_\w+\.py$/.test(f) && f !== 'phy_bitrule.py').sort();
ok(JSON.stringify(J.scripts.map(s => s.script).slice().sort()) === JSON.stringify(FAMILY), 'the json covers exactly the physics scripts of the folder: ' + FAMILY.join(' '));
ok(FAMILY.length === 31 && fs.existsSync(path.join(DIR, 'phy_bitrule.py')) && !/bd·/.test(src('phy_bitrule.py')), '31 scripts, and phy_bitrule.py (the engine) is there and holds no check id');
const fresh = [];
for (const s of J.scripts) {
  const r = py([...(s.isolated ? ['-I'] : []), path.join(PKG, DIR, s.script)], os.tmpdir()), out = (r.stdout || '').split('\n').filter(l => l.trim());
  const rows = out.slice(0, -1).map(l => LINE.exec(l)), last = out[out.length - 1] || '', nchk = rows.filter(m => m && m[1] !== 'info ').length;
  ok(r.status === 0, `${s.script} exits 0 when started from another folder (${r.status}) ${(r.stderr || '').slice(-300)}`);
  ok(rows.every(m => m && m[1] !== 'FAIL '), `${s.script}: every line before the verdict is an ok or info line of a bd id`);
  ok(last === `${nchk}/${nchk} bridge checks hold.  ALL BRIDGE CHECKS PASS` && nchk === s.checks && rows.length - nchk === s.info, `${s.script}: the verdict line counts its ${s.checks} checks (${s.info} info lines): ${last}`);
  for (const m of rows.filter(Boolean)) fresh.push({ id: m[2], script: s.script, kind: m[1] === 'info ' ? 'info' : 'check', text: m[3], ok: m[1] !== 'FAIL ' });
  // the budget is 60 processor seconds on one idle core; fk_junction.py takes 38 to 46 s there and up to 55 s when other processes share the cores, so it gets a margin
  const budget = s.script === 'fk_junction.py' ? 90 : 60;
  ok(typeof s.seconds === 'number' && s.seconds < budget, `${s.script}: ${s.seconds} processor seconds in the stored run, under ${budget}`);
}
const strip = rs => JSON.stringify(rs.map(({ id, script, kind, text, ok: o }) => ({ id, script, kind, text, ok: o })));
ok(strip(J.rows) === strip(fresh), 'the stored rows equal the fresh run (id, script, kind, text, ok; the seconds are left out)' + (strip(J.rows) === strip(fresh) ? '' : ': first difference at ' + JSON.stringify(J.rows.find((r, i) => strip([r]) !== strip([fresh[i] || {}]))).slice(0, 300)));
const CHK = J.rows.filter(r => r.kind === 'check'), INFO = J.rows.filter(r => r.kind === 'info'), IDS = new Set(J.rows.map(r => r.id));
ok(IDS.size === J.rows.length && J.rows.every(r => r.ok === true), 'no id twice, every row passes');
ok(J.summary.scripts === 31 && J.summary.checks === CHK.length && J.summary.info === INFO.length && J.summary.ok === CHK.length, 'the summary counts the scripts, checks and info lines: ' + JSON.stringify(J.summary));
ok(CHK.length === 121 && JSON.stringify(INFO.map(r => r.id)) === JSON.stringify(['bd·phy·15', 'bd·str·3', 'bd·str·4', 'bd·str·22', 'bd·sol·26', 'bd·mjp·39', 'bd·mjp·40']), `121 checks, and the info lines are the seven read-offs bd·phy·15, bd·str·3, bd·str·4, bd·str·22, bd·sol·26, bd·mjp·39, bd·mjp·40: ${CHK.length}; ${INFO.map(r => r.id).join(' ')}`);
{ const num = id => +id.split('·')[2].replace(/[a-z]$/, ''), fam = f => J.rows.filter(r => r.id.split('·')[1] === f).map(r => r.id);
  const span = (f, k) => { const got = new Set(fam(f).map(num)); return got.size === k && [...Array(k)].every((_, i) => got.has(i + 1)); };
  ok(span('phy', 20) && span('str', 27) && span('sol', 31) && span('xph', 4) && span('fk', 5) && span('mjp', 40) && fam('phy').includes('bd·phy·2a') && fam('phy').includes('bd·phy·2b'), 'the numbers of each family run without a gap: phy 1..20 (2 as 2a, 2b), str 1..27, sol 1..31, xph 1..4, fk 1..5, mjp 1..40'); }
// the ids of the mjp_ scripts, pinned: the checks bd·mjp·1..38 and the two info lines bd·mjp·39, bd·mjp·40, each in its script
const MJP = { 'mjp_fock.py': [[1, 8]], 'mjp_charges.py': [[9, 15]], 'mjp_action.py': [[16, 22]], 'mjp_time.py': [[23, 27]], 'mjp_clock.py': [[28, 32]], 'mjp_ladder.py': [[33, 38]] };
const MJP_INFO = { 'mjp_clock.py': ['bd·mjp·39', 'bd·mjp·40'] };
for (const [f, ranges] of Object.entries(MJP)) {
  const want = ranges.flatMap(([a, b]) => [...Array(b - a + 1)].map((_, i) => `bd·mjp·${a + i}`));
  ok(JSON.stringify(CHK.filter(r => r.script === f).map(r => r.id)) === JSON.stringify(want) && JSON.stringify(INFO.filter(r => r.script === f).map(r => r.id)) === JSON.stringify(MJP_INFO[f] || []),
    `${f} prints exactly the checks ${want[0]}..${want[want.length - 1]}${MJP_INFO[f] ? ' and the info lines ' + MJP_INFO[f].join(', ') : ''}, in order`);
}
ok(JSON.stringify(J.scripts.filter(s => s.script.startsWith('mjp_')).map(s => [s.script, s.checks, s.info])) === JSON.stringify([['mjp_fock.py', 8, 0], ['mjp_charges.py', 7, 0], ['mjp_action.py', 7, 0], ['mjp_time.py', 5, 0], ['mjp_clock.py', 5, 2], ['mjp_ladder.py', 6, 0]]), 'the six mjp_ scripts run last, in the order of their ids: 8, 7, 7, 5, 5 (+ 2 info), 6 checks');
{ const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-mjp-')); try {
    for (const s of J.scripts.filter(s => s.script.startsWith('mjp_'))) {
      const r = py(['-I', path.join(PKG, DIR, s.script)], outside), rows = (r.stdout || '').split('\n').map(l => LINE.exec(l)).filter(Boolean).map(m => ({ id: m[2], script: s.script, kind: m[1] === 'info ' ? 'info' : 'check', text: m[3], ok: m[1] !== 'FAIL ' }));
      ok(r.status === 0 && strip(rows) === strip(J.rows.filter(x => x.script === s.script)), `${s.script} prints the same lines with python3 -I from another folder (exit ${r.status}) ${(r.stderr || '').slice(-200)}`);
    }
  } finally { fs.rmSync(outside, { recursive: true, force: true }); } }

// ---- 2. the README section
const README = fs.readFileSync(path.join(DIR, 'README.md'), 'utf8'), SEC = (/^## Physics family[^\n]*\n([\s\S]*?)(?=^## |$(?![\s\S]))/m.exec(README) || [, ''])[1];
const tab = [...SEC.matchAll(/^\| (bd·[a-z]+·\d+[a-z]?) \| ([\w.]+\.py) \| ([^|]+) \| ([^|]+) \| ([\d.]+) \|$/gm)].map(m => [m[1], m[2]]);
ok(SEC.length > 1000 && JSON.stringify(tab) === JSON.stringify(CHK.map(r => [r.id, r.script])), 'the README table lists every check row with its script, in the order of the json: ' + tab.length + ' of ' + CHK.length);
const infoList = [...SEC.matchAll(/^- (bd·[a-z]+·\d+[a-z]?) \(([\w.]+\.py)\)/gm)].map(m => [m[1], m[2]]);
ok(JSON.stringify(infoList) === JSON.stringify(INFO.map(r => [r.id, r.script])), 'the README lists the info rows with their scripts: ' + infoList.map(x => x[0]).join(' '));
ok(/scipy/.test(SEC) && /sol_hubbard_cube\.py/.test(SEC) && /fk_junction\.py --sabotage/.test(SEC) && /phy_bitrule\.py/.test(SEC) && /regen_bridges_phys\.sh/.test(SEC) && /test_bridges_phys\.mjs/.test(SEC), 'the README names the dependencies (scipy where), the engine, the sabotage mode, the regen script and the test');
ok(/^## Physics family \(phy, str, sol, xph, fk, mjp\)$/m.test(README) && /the 31 scripts/.test(SEC) && /\(121 checks, 7 info lines\)/.test(SEC) && /`python3 mjp_<name>\.py --sabotage`/.test(SEC) && /arXiv:2403\.19689 \(v3\)/.test(SEC) && ['mjp_fock.py', 'mjp_charges.py', 'mjp_action.py', 'mjp_time.py', 'mjp_clock.py', 'mjp_ladder.py'].every(f => SEC.includes('`' + f + '`')),
  'the README section names the mjp family, the counts 31 scripts, 121 checks, 7 info lines, the --sabotage mode of the mjp_ scripts and the six scripts with what they compute');

// ---- 3. imports
const STD = new Set(['itertools', 'sys', 'os', 'math', 'fractions', 'functools', 'random', 'collections', 're']), SCIPY = new Set(['sol_hubbard_cube.py', 'fk_junction.py']);
const importsOf = t => [...new Set([...t.matchAll(/^[ \t]*(?:import[ \t]+([\w., \t]+?)[ \t]*(?:#.*)?$|from[ \t]+([\w.]+)[ \t]+import\b)/gm)].flatMap(m => m[1] ? m[1].split(',').map(x => x.trim().split(/\s+/)[0].split('.')[0]) : [m[2].split('.')[0]]))].sort();
for (const s of J.scripts) {
  const imp = importsOf(src(s.script)), allowed = x => STD.has(x) || x === 'numpy' || (x === 'scipy' && SCIPY.has(s.script)) || (x === 'phy_bitrule' && s.script.startsWith('phy_'));
  ok(JSON.stringify(imp) === JSON.stringify(s.imports) && imp.every(allowed), `${s.script} imports ${imp.join(', ')} (the json: ${s.imports.join(', ')})`);
  ok(s.isolated === imp.every(x => STD.has(x)), `${s.script}: run with -I exactly when it imports the standard library only`);
}
ok(JSON.stringify(J.scripts.filter(s => s.isolated).map(s => s.script).sort()) === JSON.stringify(['str_dualities.py', 'str_lattices.py', 'str_null.py']), 'the standard-library scripts are str_dualities.py, str_lattices.py, str_null.py, and they run with python3 -I');
ok([...SCIPY].every(f => importsOf(src(f)).includes('scipy')) && J.scripts.filter(s => s.imports.includes('scipy')).length === 2, 'scipy is used by sol_hubbard_cube.py and fk_junction.py only');
ok(importsOf(src('phy_bitrule.py')).join() === 'numpy,sys' && ['phy_coupled_action.py', 'phy_dirac.py', 'phy_horizon_little_group.py', 'phy_staggered.py', 'phy_trio.py'].every(f => /^sys\.path\.insert\(0, os\.path\.dirname\(os\.path\.abspath\(__file__\)\)\)/m.test(src(f)) && /^from phy_bitrule import /m.test(src(f))), 'the five phy_ scripts import phy_bitrule from their own folder (so they run from any folder and with -I)');
{ const model = new Set(fs.readFileSync('model.py', 'utf8').split('\n')), t = src('sol_furey_fk.py'), block = t.slice(t.indexOf('# ---- the octonion model of model.py')).split('\n\n')[0].split('\n').filter(l => l && !l.startsWith('#'));
  ok(t.includes('# ---- the octonion model of model.py') && block.length === 12 && block.every(l => model.has(l)) && /^def omul\(x,y\):$/m.test(block.join('\n')), `the ${block.length} octonion lines of sol_furey_fk.py are lines of model.py (the script reads no file outside its folder)`);
  ok(!/open\(|\.read\(|model\.py['"]|sys\.path\.insert\(0, ROOT/.test(t.replace(/"""[\s\S]*?"""/, '')), 'sol_furey_fk.py opens no file'); }
for (const s of [...J.scripts.map(s => s.script), 'phy_bitrule.py']) ok(!/\bopen\(|\bjson\.dump|\burllib|\bsocket\b|\brequests\b|\.write\(|\bsavetxt|\bnp\.save/.test(src(s).replace(/"""[\s\S]*?"""/, '')), `${s} writes nothing and uses no network`);

// ---- 4. forbidden words
const FORBIDDEN = [/rv·/, /\brv\./, /P_all/, /P_str/, /P_ss/, /M_all/, /M_geo/, /M_alg/, /M_cat/, /\breviewers?\b/i, /\bspecialists?\b/i, /\blanes?\b/i, /\bmerg(e|ed|es|ing)\b/i, /\bearlier\b/i, /\bpreviously\b/i, /\bcorrected\b/i, /disc·/, /\bdisc_[A-Z]/,
  // the names of a process (the ids of the readings MC, MA, MG, MP; a round; a seed or an item of a brief) and the history words; round( is the Python function
  /\b(MC|MA|MG|MP)\b/, /\bMERGE\b/, /\brounds?\b(?!\()/i, /\bseeds? S\d/i, /\bitems? M\d/i, /\bno longer\b/i, /\bnow\b/i, /\bwithdrawn\b/i];
// the mjp_ scripts and their README lines also carry neither "new" nor "fixed" (the older scripts use them as a variable name and in "fixed by"), nor the author's name in place of the arXiv id
const FORBIDDEN_MJP = [/\bnew\b/i, /\bfixed\b/i, /Majki/i];
const texts = [...J.scripts.map(s => [s.script, src(s.script)]), ['phy_bitrule.py', src('phy_bitrule.py')], ['README.md (physics section)', SEC], ['regen_bridges_phys.sh', fs.readFileSync('selfcheck/regen_bridges_phys.sh', 'utf8')], ['bridges_phys.json', fs.readFileSync(JSONF, 'utf8')]];
for (const [f, t] of texts) { const hit = FORBIDDEN.find(re => re.test(t)); ok(!hit, `${f}: no forbidden word (${hit ? hit + ' in: ' + t.slice(Math.max(0, t.search(hit) - 60), t.search(hit) + 60).replace(/\n/g, ' ') : 'none'})`); }
{ const mjpTexts = [...J.scripts.filter(s => s.script.startsWith('mjp_')).map(s => [s.script, src(s.script)]), ['README.md (the mjp lines)', SEC.split('\n').filter(l => /mjp/.test(l)).join('\n')], ['bridges_phys.json (the mjp rows)', JSON.stringify(J.rows.filter(r => r.script.startsWith('mjp_')))]];
  ok(mjpTexts.length === 8 && mjpTexts[6][1].length > 5000, 'the mjp texts to scan: six scripts, their README lines, their rows');
  for (const [f, t] of mjpTexts) { const hit = FORBIDDEN_MJP.find(re => re.test(t)); ok(!hit, `${f}: neither "new" nor "fixed" nor the author's name (${hit ? hit + ' in: ' + t.slice(Math.max(0, t.search(hit) - 60), t.search(hit) + 60).replace(/\n/g, ' ') : 'none'})`); } }

// ---- 5. sabotage: [script, the line as it is, the broken line, the id that must fail, what the change breaks]
const SABOTAGE = [
  ['phy_cell_vs_signature.py', 'lm5 = check_isometry([1] * 5, [1, -1, -1, -1, -1],', 'lm5 = check_isometry([1] * 5, [1, 1, -1, -1, -1],', 'bd·phy·1', 'the target cell Cl(2,3) in place of Cl(1,4): the images no longer give an isometry'],
  ['phy_cell_vs_signature.py', 'n = len(eps); E = np.diag(eps).astype(float)', 'n = len(eps); E = np.abs(np.diag(eps)).astype(float)', 'bd·phy·3', 'the hyperbolicity test without the signs of eps'],
  ['phy_cell_vs_signature.py', 'if any(min(pq) == 1 for pq in cells) and any(min(pq) != 1 for pq in cells)]', 'if any(min(pq) <= 1 for pq in cells) and any(min(pq) > 1 for pq in cells)]', 'bd·phy·20', 'a definite cell counted as Lorentzian'],
  ['phy_horizon_little_group.py', 'D = Alg([-1, -1, 0])', 'D = Alg([-1, -1, 1])', 'bd·phy·6', 'a generator of square +1 in place of the null one'],
  ['phy_dirac.py', 'rhs = A.mul(A.mul(g0, A.reverse(b)), g0)', 'rhs = A.mul(A.mul(g0, b), g0)', 'bd·phy·9', 'gamma0 psi gamma0 without the reversion'],
  ['phy_trio.py', 'A = Alg([1, -1, -1, -1, s])', 'A = Alg([1, -1, -1, -1, -s])', 'bd·phy·14', 'the extra generator with the opposite square'],
  ['phy_staggered.py', 'return -1 if popcount(x & ((1 << i) - 1)) & 1 else 1', 'return -1 if popcount(x & ((1 << (i + 1)) - 1)) & 1 else 1', 'bd·phy·16', 'a Kogut-Susskind phase that counts the direction itself'],
  ['phy_coupled_action.py', 'dLint = -e * eta * Xc', 'dLint = +e * eta * Xc', 'bd·phy·19', 'the coupling term of the A-equation with the other sign'],
  ['str_clock.py', 'wb = tuple((pc(a) % 2 + 2 * (1 if sgn(a, a, e) == -1 else 0)) % 4 for a in range(1 << n))', 'wb = tuple((2 * (1 if sgn(a, a, e) == -1 else 0)) % 4 for a in range(1 << n))', 'bd·str·1', 'w = 2Q without pi'],
  ['str_clock.py', 'if len(sub) == 1: return [B.shape[1] // sub[0].shape[1]]', 'if len(sub) == 1: return [2 * B.shape[1] // sub[0].shape[1]]', 'bd·str·2', 'a restriction that doubles the multiplicity'],
  ['str_spinors.py', "k, D, N = t; return N * {'R': 1, 'C': 2, 'H': 4}[D]", "k, D, N = t; return N * {'R': 2, 'C': 2, 'H': 4}[D]", 'bd·str·7', 'the real spinor dimension doubled'],
  ['str_dualities.py', 'def amul(a, b): return (a ^ b, sgn(a, b, [eps]))', 'def amul(a, b): return (a ^ b, sgn(a, b, [-eps]))', 'bd·str·14', 'the one-generator cell with the opposite square'],
  ['str_lattices.py', 'K = (-3,) + (-1,) * n                                               # K = -3H', 'K = (-2,) + (-1,) * n                                               # K = -3H', 'bd·str·17', 'a class K that is not the canonical class'],
  ['str_syk.py', "base = 'R' if nu > 0 else ('C' if nu == 0 else 'H')", "base = 'H' if nu > 0 else ('C' if nu == 0 else 'R')", 'bd·str·20', 'the real and quaternionic types exchanged'],
  ['str_null.py', 'm = {k: v / 4 for k, v in addv(et, er, -1).items()}', 'm = {k: v / 2 for k, v in addv(et, er, -1).items()}', 'bd·str·21', 'a partner m that is not paired with l'],
  ['str_extra.py', 'Phi = sum(grp[a] * Lm(a, eps) for a in four)', 'Phi = sum(Lm(a, eps) for a in four)', 'bd·str·24', 'the 4-form without its signs'],
  ['str_extra.py', 'ops.append((Lm(x, eps) @ Rm(y, eps) @ (alpha if pc(y) % 2 else np.eye(N))).ravel())', 'ops.append((Lm(x, eps) @ Rm(y, eps)).ravel())', 'bd·str·23', 'the ungraded map in place of the graded one'],
  ['sol_fk_clock.py', 'U = time_reversal(n, p); T2 = U @ U.conj()', 'U = time_reversal(n, p); T2 = U @ U', 'bd·sol·2', 'T^2 computed as if T were unitary'],
  ['sol_furey_fk.py', 'g = [blk(Z, Lmat(u), Lmat(u), Z) for u in units] + [blk(Z, I8, -I8, Z)]', 'g = [blk(Z, Lmat(u), Lmat(u), Z) for u in units] + [blk(Z, I8, I8, Z)]', 'bd·sol·10', 'an eighth generator of square +1'],
  ['sol_hubbard_cube.py', 'vals.append(-s * (-1) ** between)', 'vals.append(-s)', 'bd·sol·31', 'hopping without the Jordan-Wigner signs'],
  ['sol_kitaev_lieb.py', 'i = (a ^ b).bit_length() - 1; s = sgn(1 << i, a, [1] * n); D[a, b] = D[b, a] = s', 'i = (a ^ b).bit_length() - 1; s = 1; D[a, b] = D[b, a] = s', 'bd·sol·27', 'the plain cube in place of the bit-rule signing'],
  ['sol_lattice_springs.py', 'def eta(x, mu): return (-1) ** (sum(x[:mu]) % 2)', 'def eta(x, mu): return (-1) ** (sum(x[:mu + 1]) % 2)', 'bd·sol·18', 'a staggered phase that counts the direction itself'],
  ['sol_maxwell_media.py', 'divS = sum(B0[i] * cE[i] for i in range(3)) - sum(E0[i] * cB[i] for i in range(3))', 'divS = sum(B0[i] * cE[i] for i in range(3)) + sum(E0[i] * cB[i] for i in range(3))', 'bd·sol·17', 'a wrong divergence of the Poynting vector'],
  ['sol_null_bands.py', 'gens = L + [M.T for M in L]', 'gens = L', 'bd·sol·12', 'the closure without the adjoints'],
  ['sol_point_groups.py', 'Inv = inv_phase * np.kron(I2, P)', 'Inv = np.kron(I2, P)', 'bd·sol·21', 'the inversion without its phase on spinors'],
  ['sol_abs_tenfold.py', 'if a in span or sgn(a, a, eps) != 1: continue', 'if a in span or sgn(a, a, eps) != -1: continue', 'bd·sol·25', 'idempotents from blades of square -1'],
  ['xph_clock_crosscheck.py', 'T2 = U @ U.conj()                          # T^2 = U K U K = U conj(U)', 'T2 = U @ U                          # T^2 = U K U K = U conj(U)', 'bd·xph·1', 'T^2 computed as if T were unitary'],
  ['xph_null_join.py', '                    s *= self.eps[i]\n', '                    s *= 1\n', 'bd·xph·3', 'a dagger that is the reversion alone'],
  ['fk_junction.py', "names.append((f'{tag}a{x}', 'E')); names.append((f'{tag}b{x}', 'O'))", "names.append((f'{tag}a{x}', 'O')); names.append((f'{tag}b{x}', 'E'))", 'bd·fk·1', 'the T-parities of a and b exchanged (run with --only bd·fk·1)'],
  ['mjp_fock.py', '        t = {(i, S): sgn(1 << i, S, [1] * n) for S in range(1 << n) for i in range(n) if not S >> i & 1}', '        t = {(i, S): 1 for S in range(1 << n) for i in range(n) if not S >> i & 1}', 'bd·mjp·7', 'the edge signs of the bit rule replaced by +1 (hard-core bosons): no face has flux -1'],
  ['mjp_charges.py', '    H0 = sum(int(q[i]) * nums[i] for i in range(n))', '    H0 = sum(int(q[i]) * cps[i] for i in range(n))', 'bd·mjp·9', 'creation operators in place of the number operators: the one-body operator is not diagonal'],
  ['mjp_action.py', '    lims = [L for L in cones if all(leq(c, L) for c in cones)]', '    lims = [L for L in cones if all(leq(L, c) for c in cones)]', 'bd·mjp·16', 'the least cone taken for the limit in place of the greatest'],
  ['mjp_time.py', '        B = {e01: Fr(s01)}', '        B = {e01: Fr(-s01)}', 'bd·mjp·26', 'the null bivector with the opposite sign: the motor boosts with -v'],
  ['mjp_clock.py', '            for e in eps: prod = gmul(prod, ((1, 0)[0] + IP[e % 4][0], IP[e % 4][1]))', '            for e in eps: prod = gmul(prod, (1 + IP[e % 4][0], -IP[e % 4][1]))', 'bd·mjp·31', 'the product of the factors 1 + (-i)^eps_i (fugacity -i) in place of 1 + i^eps_i'],
  ['mjp_ladder.py', '    return (pc(a) % 2 + 2 * (1 if sgn(a, a, eps) == -1 else 0)) % 4', '    return (2 * (1 if sgn(a, a, eps) == -1 else 0)) % 4', 'bd·mjp·38', 'the form 2Q without pi: the isometry counts of (V, w) change'],
];
// the --sabotage mode of the mjp_ scripts: [script, its number of checks]; run with python3 -I from another folder, it must exit 0 and print CAUGHT for every check of the script
const SABMODE = [['mjp_fock.py', 8], ['mjp_charges.py', 7], ['mjp_action.py', 7], ['mjp_time.py', 5], ['mjp_clock.py', 5], ['mjp_ladder.py', 6]];
ok(J.scripts.every(s => SABOTAGE.some(x => x[0] === s.script)) && SABOTAGE.every(x => CHK.some(r => r.id === x[3] && r.script === x[0])), 'every script has a sabotage, each aimed at one of its own check rows');
ok(JSON.stringify(SABMODE.map(x => x[0]).sort()) === JSON.stringify(J.scripts.filter(s => s.script.startsWith('mjp_')).map(s => s.script).sort()) && SABMODE.every(([f, k]) => CHK.filter(r => r.script === f).length === k),
  'the --sabotage table lists every mjp_ script with its number of checks: ' + SABMODE.map(x => x.join(' ')).join(', '));
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-')); try {
    for (const [f, from, to, id, label] of SABOTAGE) {
      const t = src(f); ok(t.split(from).length === 2, `${f}: the line to break is there exactly once (${label})`);
      fs.writeFileSync(path.join(tmp, 'phy_bitrule.py'), src('phy_bitrule.py')); fs.writeFileSync(path.join(tmp, f), t.replace(from, () => to));
      const r = py([path.join(tmp, f), ...(f === 'fk_junction.py' ? ['--only', id] : [])], tmp), out = r.stdout || '', last = out.trim().split('\n').pop();
      ok(r.status === 1 && out.includes('FAIL ' + id + '  ') && /^\d+\/\d+ bridge checks hold\.  FAILED: /.test(last) && last.split(': ')[1].split(' ').includes(id), `${f}, ${label}: the copy exits 1 and ${id} fails (exit ${r.status}; ${last})`);
    }
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
{ const r = py([path.join(PKG, DIR, 'fk_junction.py'), '--sabotage'], os.tmpdir()), out = r.stdout || '';
  ok(r.status === 0 && [1, 2, 3, 4, 5].every(k => out.includes(`CAUGHT bd·fk·${k}  `)) && !/^MISSED/m.test(out) && out.trim().split('\n').pop() === 'ALL CAUGHT', 'fk_junction.py --sabotage: every one of bd·fk·1..5 catches its broken input (ALL CAUGHT, exit 0): ' + out.trim().split('\n').pop()); }
for (const [f, k] of SABMODE) {
  const r = py(['-I', path.join(PKG, DIR, f), '--sabotage'], os.tmpdir()), out = r.stdout || '', ids = CHK.filter(x => x.script === f).map(x => x.id);
  const caught = [...out.matchAll(/^CAUGHT (bd·mjp·\d+)  /gm)].map(m => m[1]);
  ok(r.status === 0 && JSON.stringify(caught) === JSON.stringify(ids) && caught.length === k && !/^MISSED/m.test(out) && out.trim().split('\n').pop() === 'ALL CAUGHT',
    `${f} --sabotage: one CAUGHT line for each of its ${k} checks (${caught.length}: ${caught.join(' ')}), no MISSED, ALL CAUGHT, exit ${r.status}`);
}

// ---- 6. the ids the package cites
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => ['node_modules', 'dist', 'dist_real', '.git', 'test_logs', '__pycache__', 'zips'].includes(e.name) ? [] : e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const CITE = /bd·(phy|str|sol|xph|fk|mjp)·(\d+)([a-z]?)(?:\s*[–-]\s*(\d+)(?![\d·]))?/g;
const missing = [], cited = new Set();
const has = (fam, k, suf) => suf ? IDS.has(`bd·${fam}·${k}${suf}`) : IDS.has(`bd·${fam}·${k}`) || [...IDS].some(i => new RegExp(`^bd·${fam}·${k}[a-z]$`).test(i));
const scan = (t, f, out, seen) => { for (const m of t.matchAll(CITE)) { const [all, fam, a, suf, b] = m; seen.add(all);
    if (b !== undefined) { for (let k = +a; k <= +b; k++) if (!has(fam, k, '')) out.push(`bd·${fam}·${k} (in the range ${all}) in ${f}`); }
    else if (!IDS.has(`bd·${fam}·${a}${suf}`)) out.push(`${all} in ${f}`); } };
{ const id = (fam, k) => ['bd', fam, k].join('·'), planted = [];   // the planted ids are built here, so that this file cites none of them
  scan(`see ${id('mjp', 41)}, ${id('mjp', '37–42')}, ${id('fk', 6)} and ${id('mjp', '1–40')}; ${id('mjp', 38)}`, 'a planted text', planted, new Set());
  ok(JSON.stringify(planted) === JSON.stringify([`${id('mjp', 41)} in a planted text`, `${id('mjp', 41)} (in the range ${id('mjp', '37–42')}) in a planted text`, `${id('mjp', 42)} (in the range ${id('mjp', '37–42')}) in a planted text`, `${id('fk', 6)} in a planted text`]),
    'the citation scan flags a planted id that is not a row (mjp 41, fk 6) and every missing number of a planted range (mjp 37–42), and passes the rows: ' + planted.join('; ')); }
for (const f of walk('.').filter(f => /\.(js|jsx|mjs|cjs|json|md|py|sh|html|txt)$/.test(f))) scan(fs.readFileSync(f, 'utf8'), f, missing, cited);
ok(missing.length === 0, 'every bd·phy/str/sol/xph/fk/mjp id that a file of the package cites is a row of bridges_phys.json; missing: ' + [...new Set(missing)].slice(0, 12).join(', '));
{ const noFile = [];
  for (const f of walk('.').filter(f => /\.(js|jsx|mjs|cjs|json|md|py|sh|html|txt)$/.test(f))) for (const m of fs.readFileSync(f, 'utf8').matchAll(/selfcheck\/bridges\/((?:phy|str|sol|xph|fk|mjp)_\w+\.py)/g)) if (!fs.existsSync(path.join(DIR, m[1]))) noFile.push(`${m[1]} in ${f}`);
  ok(noFile.length === 0, 'every selfcheck/bridges/ script of this family that a file of the package names exists: missing ' + [...new Set(noFile)].slice(0, 8).join(', ')); }
{ const problems = [], BD = /bd·(?:phy|str|sol|xph|fk|mjp)·\d+[a-z]?(?![\d·])/g;
  // every JSON file of the package (claimsLocators*.json, the lens dictionary, the reports): a field checkedBy (a string) or checks (a list) is what makes a statement checked
  const look = (v, where, f) => { if (Array.isArray(v)) v.forEach((x, i) => look(x, where + '[' + i + ']', f)); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) {
      if (k === 'checkedBy' && typeof x === 'string') for (const [id] of x.matchAll(BD)) { const r = J.rows.find(y => y.id === id); if (!r) continue;
        if (r.kind === 'info') problems.push(`${f} ${v.id || where}: checkedBy cites ${id}, an info line (a read-off), not a check`);
        if (!x.includes(r.script)) problems.push(`${f} ${v.id || where}: checkedBy cites ${id} without its script ${r.script}`); }
      else if (k === 'checks' && Array.isArray(x)) for (const id of x.filter(y => typeof y === 'string')) { const r = J.rows.find(y => y.id === id); if (r && r.kind === 'info') problems.push(`${f} ${v.id || where}: checks lists ${id}, an info line (a read-off), not a check`); }
      else look(x, where + '.' + k, f); } };
  for (const f of walk('.').filter(f => /\.json$/.test(f) && !f.endsWith('bridges_phys.json'))) { let d; try { d = JSON.parse(fs.readFileSync(f, 'utf8')); } catch { continue; } look(d, '', f); }
  ok(problems.length === 0, 'no checkedBy or checks field of a JSON file of the package cites an info id, and a checkedBy names the script of every bridge id it cites: ' + problems.slice(0, 8).join('; ')); }
console.log(`(${cited.size} distinct citations of this family found in the package)`);

// ---- 7. a failing check never overwrites the log: regen_bridges_phys.sh in a temporary copy of the folder, with phy_dirac.py broken (the third script), stops with a
//         non-zero exit code and leaves bridges_phys.json byte for byte as it was, with no temporary file left
{ const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-bridges-regen-')); try {
    fs.mkdirSync(path.join(tmp, 'selfcheck', 'bridges'), { recursive: true }); fs.copyFileSync('selfcheck/regen_bridges_phys.sh', path.join(tmp, 'selfcheck', 'regen_bridges_phys.sh'));
    for (const f of fs.readdirSync(DIR)) if (fs.statSync(path.join(DIR, f)).isFile()) fs.copyFileSync(path.join(DIR, f), path.join(tmp, DIR, f));
    const target = path.join(tmp, DIR, 'phy_dirac.py'), before = fs.readFileSync(path.join(tmp, JSONF));
    fs.writeFileSync(target, fs.readFileSync(target, 'utf8').replace('rhs = A.mul(A.mul(g0, A.reverse(b)), g0)', 'rhs = A.mul(A.mul(g0, b), g0)'));
    const r = spawnSync('sh', [path.join(tmp, 'selfcheck', 'regen_bridges_phys.sh')], { cwd: os.tmpdir(), env: ENV, encoding: 'utf8', timeout: 600000 });
    ok(r.status !== 0 && /phy_dirac\.py exits 1/.test(r.stderr || '') && Buffer.compare(before, fs.readFileSync(path.join(tmp, JSONF))) === 0 && !fs.existsSync(path.join(tmp, JSONF + '.new')),
      `regen_bridges_phys.sh stops at a failing script (exit ${r.status}: ${(r.stderr || '').split('\n')[0]}) and leaves bridges_phys.json as it was`);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); } }
console.log(`${n} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL BRIDGE PHYS TESTS PASS'); process.exit(bad ? 1 : 0);
