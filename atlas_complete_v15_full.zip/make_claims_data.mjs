// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// make_claims_data.mjs: resolves the locators of claimsLocators.json against the copy modules of this package and writes claimsData.js
// (every statement of the pages with its lines, flags, citations and checks). Run: node make_claims_data.mjs   (writes claimsData.js)
//        node make_claims_data.mjs --check   (exit 1 if claimsData.js is not what the locators give: used by test_claims_sync.mjs)
// A locator is {file, path}: followed from the module namespace, or from its default export when path[0] is not an export; a path element is
// a key, an index, or {find:{k:v}} (the array element whose field k equals v). A text locator with join/count resolves to a row whose first
// <count> cells joined with <join> are the text shown. A flags locator resolves to an array of flag names or to a space-separated string.
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL, fileURLToPath } from 'node:url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
export const FLAG_NAMES = ['standard', 'checked', 'ours', 'open', 'input'];
const PAGE_IDS = ['rule', 'atlas', 'conventions', 'maxwell', 'shapes', 'equations', 'furey', 'lenses', 'map', 'researchers', 'ask'];   // pages of the app: a statement shown elsewhere (the researcher-note popover) names none
const mods = {}; const mod = async f => (mods[f] ??= await import(pathToFileURL(path.join(HERE, f)).href));
const follow = (ns, p) => {
  let o = (typeof p[0] === 'string' && !(p[0] in ns) && ns.default) ? ns.default : ns;
  for (const k of p) { o = (k && typeof k === 'object') ? o.find(x => x && x[Object.keys(k.find)[0]] === Object.values(k.find)[0]) : o?.[k]; if (o === undefined) throw new Error('path not found: ' + JSON.stringify(p)); }
  return o;
};
const flagsOf = v => Array.isArray(v) ? v : typeof v === 'string' ? (v === '' ? [] : v.trim().split(/\s+/)) : null;
const order = fl => FLAG_NAMES.filter(f => fl.includes(f));
// the columns "cited" and "checked" of the claims table are for the reader: a parenthesis that records who ran or read what in the audit is not a statement and is not carried over
const forReader = s => (typeof s === 'string' ? s.replace(/\s*\([^()]*\bthe owner\b[^()]*\)/g, '').trim() : s);
const resolveText = async loc => { let t = follow(await mod(loc.file), loc.path); if (loc.join !== undefined) t = t.slice(0, loc.count).join(loc.join); return String(t); };
export async function buildClaims() {
  // the statements of the pages (claimsLocators.json) and, after them, the input lines of the needs strips (claimsLocators_inp.json) and the statements of each chapter of the lenses page (claimsLocators_ln*.json): same row shape
  const L = ['claimsLocators.json', ...fs.readdirSync(HERE).filter(f => /^claimsLocators_[a-z0-9]+\.json$/.test(f)).sort()].flatMap(f => JSON.parse(fs.readFileSync(path.join(HERE, f), 'utf8')));
  const claims = [];
  for (const r of L) {
    const lines = { en: [], it: r.lines.length && r.lines.every(l => l.it) ? [] : null };
    for (const l of r.lines) {
      for (const lang of ['en', 'it']) {
        const S = l[lang]; if (!S || lines[lang] === null) continue;
        const o = { label: l.label, flags: order(flagsOf(follow(await mod(S.flags_loc.file), S.flags_loc.path)) || []), text: await resolveText(S.text_loc) };
        if (S.heading_loc) o.heading = await resolveText(S.heading_loc);
        if (l.audience) o.audience = l.audience;
        lines[lang].push(o);
      }
    }
    if (!r.frozen && lines.en.length === 0 && r.note) { lines.en.push({ label: 'line', flags: order(r.flagsSpec), text: 'No statement: a list of tags that no page draws.', notShown: true }); lines.it = null; }
    const lineFlags = order([...new Set(lines.en.flatMap(x => x.flags))]);
    const known = f => f.includes('standard') && f.includes('checked') && !f.includes('ours') && !f.includes('open') && !f.includes('input');
    for (const lang of ['en', 'it']) if (lines[lang]) for (const x of lines[lang]) x.known = known(x.flags);
    claims.push({ id: r.id, group: r.group, groupName: r.groupName, flags: r.frozen ? order(r.flagsSpec) : lineFlags, flagsSpec: order(r.flagsSpec),
      known: r.frozen ? false : (lines.en.length > 0 && lines.en.every(x => x.known)), en: r.frozen ? [{ label: 'line', flags: order(r.flagsSpec), text: r.frozenText, known: false }] : lines.en, it: r.frozen ? null : lines.it,
      standardRef: forReader(r.standardRef), checkedBy: forReader(r.checkedBy), links: r.links, lens: r.lens, frozen: r.frozen, tally: r.tally, page: PAGE_IDS.includes(r.shown_on?.page) ? r.shown_on.page : null, anchor: r.shown_on?.anchor ?? null, visibleTo: r.visible_to ?? null });
  }
  return claims;
}
export const HEADER = fs.readFileSync(fileURLToPath(import.meta.url), 'utf8').split('\n').slice(0, 3).join('\n') + '\n';
export async function render() {
  const claims = await buildClaims();
  const meta = { generated: '2026-10-07', source: 'the statements of the pages, resolved from the copy modules by make_claims_data.mjs', total: claims.length, frozen: claims.filter(c => c.frozen).length };
  return HEADER + '// GENERATED by make_claims_data.mjs from claimsLocators.json and claimsLocators_*.json: do not edit by hand\nexport const CLAIMS_META = ' + JSON.stringify(meta) + ';\nexport const CLAIMS = ' + JSON.stringify(claims, null, 0).replace(/\},\{"id":/g, '},\n{"id":') + ';\n';
}
if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) {
  const out = await render(), file = path.join(HERE, 'claimsData.js');
  if (process.argv.includes('--check')) { const cur = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : ''; if (cur !== out) { console.log('claimsData.js is out of date: run node make_claims_data.mjs'); process.exit(1); } console.log('claimsData.js is current'); }
  else { fs.writeFileSync(file, out); console.log('wrote claimsData.js'); }
}
