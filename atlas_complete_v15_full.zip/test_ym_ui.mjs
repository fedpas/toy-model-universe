// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { APP_HTML, SHOTS } from './paths.mjs';
import { eqNavIds, stepCount } from './steps.js';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { setLang, tabTo, focused } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];
const C=m=>m*(m-1)/2, E=m=>m*(m-1)*(m-2)/2;
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${lang}${w}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${lang}${w} console: ${m.text()}`));
 await pg.goto(APP_HTML + '#equations/ym');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 // v9: the formal checks below run for the Physicist (the default audience is the Young Learner, whose page now keeps the tables in the
 // closed "For older readers" fold and reads a plain selection caption); the Young Learner has its own checks at the end of this loop
 await pg.locator('[data-profile="Physicist"]').click();
 await pg.waitForTimeout(200);
 const nav=await pg.locator('.tabbar [role=tab]').count(); if(nav!==eqNavIds().length)errs.push(`${lang}${w}: nav ${nav}`);
 const rows=await pg.locator('#eq-ym .ym-table tbody tr').count(); if(rows!==7)errs.push(`${lang}${w}: ladder rows ${rows}`);
 const st=await pg.locator('#eq-ym .ym-st tbody tr').count(); if(st!==5)errs.push(`${lang}${w}: spacetime rows ${st}`);
 const idr=await pg.locator('#eq-ym .ym-id tbody tr').count(); if(idr!==7)errs.push(`${lang}${w}: identity rows ${idr}`);
 const chips=pg.locator('#eq-ym .ym-chip'); if(await chips.count()!==7)errs.push('chips '+await chips.count());
 for(let m=2;m<=8;m++){
  await chips.nth(m-2).click();
  const nodes=await pg.locator('#eq-ym svg .ym-node').count(), edges=await pg.locator('#eq-ym svg .ym-edge').count();
  if(nodes!==C(m)||edges!==E(m))errs.push(`${lang}${w} m=${m}: ${nodes} nodes ${edges} edges, want ${C(m)}/${E(m)}`);
  // the name read aloud for a generator is the label drawn beside it (T2-7), not its bit mask
  const nm=await pg.locator('#eq-ym svg .ym-node').evaluateAll(es=>es.filter(e=>e.getAttribute('aria-label')!==e.querySelector('text').textContent).map(e=>`${e.getAttribute('aria-label')}≠${e.querySelector('text').textContent}`));
  if(nm.length)errs.push(`${lang}${w} m=${m}: generator names differ from the drawn labels: ${nm.slice(0,4)}`);
  const v=await pg.locator('#eq-ym .ym-view').count(); if(v!==(m===4?7:6))errs.push(`${lang}${w} m=${m}: ${v} views`);
  const on=await pg.locator('#eq-ym .ym-table tbody tr.on td').first().textContent(); if(+on!==m)errs.push(`${lang}${w} m=${m}: row ${on}`);
  const txt=await pg.locator('#eq-ym').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} m=${m}: placeholder`);
  if(m>=3){ await pg.locator('#eq-ym svg .ym-node circle:not(.ym-hit)').first().click();
    const cap=await pg.locator('#eq-ym .ym-selcap').textContent(); if(!/±2/.test(cap))errs.push(`${lang}${w} m=${m}: selection caption "${cap}"`);
    const deg=(cap.match(/±2/g)||[]).length; if(deg!==2*(m-2))errs.push(`${lang}${w} m=${m}: ${deg} neighbours, want ${2*(m-2)}`);
    await pg.locator('#eq-ym svg .ym-node circle:not(.ym-hit)').first().click(); }
 }
 await chips.nth(2).click();
 const tick=await pg.locator('#eq-ym .ym-id td').filter({hasText:'✓'}).count(); if(tick!==21)errs.push('identity ticks '+tick);
 // keyboard (v9): a generator is reached with Tab and chosen with Enter (Enter again clears it); a ladder row is chosen with Enter
 if(!(await tabTo(pg,'#eq-ym .ym-chip','#eq-ym svg .ym-node',80)))errs.push(`${lang}${w}: no generator reachable with Tab`);
 else { await pg.keyboard.press('Enter'); await pg.waitForTimeout(60); const capK=await pg.locator('#eq-ym .ym-selcap').textContent().catch(()=>'');
   if(await pg.locator('#eq-ym svg .ym-node[aria-pressed="true"]').count()!==1||(capK.match(/±2/g)||[]).length!==4)errs.push(`${lang}${w}: Enter did not choose a generator: "${capK}"`);
   await pg.keyboard.press(' '); await pg.waitForTimeout(60); if(await pg.locator('#eq-ym svg .ym-node[aria-pressed="true"]').count()!==0)errs.push(`${lang}${w}: Space did not clear the generator`); }
 await pg.locator('#eq-ym details:has(.ym-table)').evaluate(d=>{d.open=true;});
 if(!(await tabTo(pg,'#eq-ym details:has(.ym-table) > summary','#eq-ym .ym-table tbody tr',10)))errs.push(`${lang}${w}: no ladder row reachable with Tab`);
 else { await pg.keyboard.press('Tab'); await pg.keyboard.press('Tab'); await pg.keyboard.press('Tab'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60);
   const onK=await pg.locator('#eq-ym .ym-table tbody tr.on td').first().textContent(); if(+onK!==5||await pg.locator('#eq-ym svg .ym-node').count()!==C(5))errs.push(`${lang}${w}: Enter on the fourth row chose m=${onK}`); }
 await chips.nth(2).click();
 const ov=await pg.evaluate(()=>document.documentElement.scrollWidth-window.innerWidth);if(ov>2)errs.push(`${lang}${w}: overflow ${ov}`);
 await pg.locator('.tabbar [role=tab][data-tab="ym"]').click(); await pg.waitForTimeout(400);
 if(w===1100&&lang==='en'){ await chips.nth(2).click(); await pg.locator('#eq-ym svg .ym-node circle:not(.ym-hit)').first().click(); await pg.locator('#eq-ym').screenshot({path:SHOTS + '/ym_en_wide.png'}); }
 if(w===375&&lang==='en'){ await pg.locator('#eq-ym').screenshot({path:SHOTS + '/ym_en_mobile.png'}); }
 // v9, Young Learner: the same graph and the same clicks, with a plain caption (no bracket, no ±2), and every table inside one closed "For older readers" fold
 await pg.locator('[data-profile="Young Learner"]').click(); await pg.waitForTimeout(150);
 for(const m of [2,4,5]){ await chips.nth(m-2).click();
  const n=await pg.locator('#eq-ym svg .ym-node').count(), e=await pg.locator('#eq-ym svg .ym-edge').count(); if(n!==C(m)||e!==E(m))errs.push(`${lang}${w} YL m=${m}: ${n} nodes ${e} edges`);
  const gc=await pg.locator('#eq-ym .ym-graphcap').textContent(); if(/±|\[|\bso\(|Cl\(|generator|gauge/i.test(gc)||(m>2&&!gc.includes(String(E(m)))))errs.push(`${lang}${w} YL m=${m}: graph caption "${gc}"`);
  if(m>=3){ await pg.locator('#eq-ym svg .ym-node circle:not(.ym-hit)').first().click(); const cap=await pg.locator('#eq-ym .ym-selcap').textContent();
   const k=(cap.match(lang==='it'?/ danno /g:/ give /g)||[]).length; if(k!==2*(m-2)||/±|\[|=/.test(cap))errs.push(`${lang}${w} YL m=${m}: selection caption "${cap}"`);
   await pg.locator('#eq-ym svg .ym-node circle:not(.ym-hit)').first().click(); } }
 const fold=await pg.evaluate(()=>{ const ds=[...document.querySelectorAll('#eq-ym details')].filter(d=>!d.parentElement.closest('#eq-ym details')&&d.querySelector('.ym-table')); return ds.length===1?[ds[0].open,ds[0].querySelector(':scope > summary').textContent,['.ym-table','.ym-st','.ym-id','.ym-view'].every(s=>ds[0].querySelector(s))]:null; });
 if(!fold||fold[0]||!/older readers|lettori più grandi/.test(fold[1])||!fold[2])errs.push(`${lang}${w} YL: the tables should sit in one closed fold for older readers (${fold})`);
 await pg.close();}
await b.close();console.log(errs.length?errs:'YM UI OK');
process.exit(errs.length?1:0);   // v9: a failure also sets the exit code
