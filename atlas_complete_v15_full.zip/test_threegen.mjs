// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import T from './threegenData.js';
import {THREEGEN_PY} from './threegenSelfcheckSource.js';
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const J=JSON.parse(fs.readFileSync('./selfcheck/threegen.json','utf8')),Fu=JSON.parse(fs.readFileSync('./furey_results.json','utf8'));
ok(JSON.stringify(J)===JSON.stringify(JSON.parse(JSON.stringify(T))),'data equals rebuilt JSON');
ok(THREEGEN_PY===fs.readFileSync('./selfcheck/threegen_selfcheck.py','utf8'),'embedded script equals file');
// parse irreps independently of the python tables: dimension and hypercharge in sixths
const CD={'1':1,'3':3,'3b':3,'6':6,'6b':6,'8':8};
const parse=s=>{const m=/^\((\w+),(\d),([+-]?\d+(?:\/\d+)?)\)$/.exec(s);const [n,d]=m[3].split('/').map(Number);return {dim:CD[m[1]]*Number(m[2]),y6:Math.round(6*n/(d||1))}};
const tot=o=>Object.entries(o).reduce((a,[k,m])=>a+parse(k).dim*m,0);
ok(tot(T.linear_off_diagonal_irreps)===48&&tot(T.antilinear_irreps)===64,'sector dimensions 48 and 64');
// independent hypercharge bookkeeping, state by state: blocks (dim, y in sixths) from the data
const states=[];for(const b of T.blocks){const [n,d]=b.y.split('/').map(Number);for(let i=0;i<b.dim;i++)states.push(Math.round(6*n/(d||1)))}
ok(states.length===8,'eight complex dimensions');
const cnt=(arr)=>{const c={};for(const v of arr)c[v]=(c[v]||0)+1;return JSON.stringify(Object.entries(c).sort((a,b)=>a[0]-b[0]))};
// antilinear sector: charge y_t + y_s over all ordered pairs of states
const antiExp=[];for(const t of states)for(const s of states)antiExp.push(t+s);
const antiGot=[];for(const [k,m] of Object.entries(T.antilinear_irreps)){const p=parse(k);for(let i=0;i<p.dim*m;i++)antiGot.push(p.y6)}
ok(cnt(antiExp)===cnt(antiGot),'antilinear charges state by state');
// linear sector off the diagonal blocks: y_t - y_s over pairs in different blocks
const blockOf=[];T.blocks.forEach((b,i)=>{for(let j=0;j<b.dim;j++)blockOf.push(i)});
const linExp=[];states.forEach((yt,a)=>states.forEach((ys,b)=>{if(blockOf[a]!==blockOf[b])linExp.push(yt-ys)}));
const linGot=[];for(const [k,m] of Object.entries(T.linear_off_diagonal_irreps)){const p=parse(k);for(let i=0;i<p.dim*m;i++)linGot.push(p.y6)}
ok(cnt(linExp)===cnt(linGot),'linear off-diagonal charges state by state');
// agrees with the earlier explicit-model audit (run_all.py)
ok(Fu.complex_off===48&&Fu.sm_generation_dim===16&&Fu.extras_dim===8,'furey_results.json');
ok(T.sm_rows.Q_L.linear===1&&T.sm_rows.u_R.linear===1&&T.sm_rows.d_R.linear===2&&T.sm_rows.L.linear===3&&T.sm_rows.e_R.linear===2,'multiplicities = one generation + replicas');
ok(T.linear_beyond_one_generation.d_R===1&&T.linear_beyond_one_generation.L===2&&T.linear_beyond_one_generation.e_R===1,'replica content d_R, 2 L, e_R');
ok(T.exotic.linear_off_diagonal===0&&T.exotic.antilinear===32,'exotic content');
// the dimension count that makes three generations look possible, and why it does not work
ok(3*2*16*2===192&&192<=256,'three generations of particle and antiparticle would fit in 256 real dimensions');
ok(48===3*16,'48 = 3 x 16 is a numerical coincidence of capacity, not a content statement');
ok(T.search_all.max_generations===2&&!('3' in T.search_all.histogram)&&T.search_all.admissible_W===5582,'no admissible W has three generations');
ok(T.search_peirce_frame.assignments===4000&&!('3' in T.search_peirce_frame.histogram)&&T.search_peirce_frame.histogram['2']===60,'Peirce frame search');
ok(T.search_all.least_exotic_dimension_for_generations['2']>0&&T.search_peirce_frame.least_exotic_dimension_for_generations['2']>0,'two generations always come with exotic content');
ok(Object.values(T.max_copies_of_each_irrep).every(v=>v>=2)&&T.max_copies_of_each_irrep.Q_L===4,'each irrep alone can be repeated, never all six together');
ok(/--compare/.test(THREEGEN_PY)&&/ALL THREE-GENERATION CHECKS PASS/.test(THREEGEN_PY),'script interface');
// the numbers the page quotes about the room search are the data's (the full list is in test_furey_papers.mjs); the plain copy of the page is in fureyCopy.js
import { FC } from './fureyCopy.js';
{ const flat = o => typeof o === 'string' ? [o] : o && typeof o === 'object' ? Object.values(o).flatMap(flat) : [];
  for (const [L, five] of [['en', '5,582'], ['it', '5.582']]) { const t = flat(FC[L].threegen.secs.room).join(' ');
    ok(t.includes(five) && T.search_all.admissible_W === 5582 && T.search_all.max_generations === 2, `${L}: the room search quotes ${five} admissible structures at dimension 8, the data's number`);
    ok(!/at best with Standard Model content|al meglio 1 generazione con contenuto del Modello Standard/.test(t), `${L}: the old wording is gone`); } }
const plain = L => { const c = FC[L].threegen; return { titleY: c.titleY, short: c.short[0], ylw: c.ylw, secs: Object.fromEntries(Object.entries(c.secs).map(([k, x]) => [k, { hy: x.hy, yl: x.yl }])), typeName: c.typeName, typeShort: c.typeShort, extraShort: c.extraShort, anti: c.anti, compYl: c.compYl }; };
const YL_COPY = [['three generations', plain('en'), plain('it')]];
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s) || s.split(/\s+/).length <= 2,   // one word such as neutrino is the same in both
     `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));   // status keys are the same in both
  }
}
console.log(bad?bad+' FAILURES':'ALL THREEGEN TESTS PASS');process.exit(bad?1:0)
