// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useState, useEffect } from 'react';
import { SHORT, FOLD, level } from './audienceCopy.js';
import { Tx } from './MathText.jsx';

// A folded block. The reading level decides whether it starts open; the reader can always toggle it.
export function Fold({ title, open = false, children, nested = false }) {
  const [o, setO] = useState(open);
  useEffect(() => setO(open), [open]);
  return <details className={'eq-fold' + (nested ? ' eq-fold-in' : '')} open={o} onToggle={e => setO(e.currentTarget.open)}><summary className="eq-sum"><Tx>{title}</Tx></summary><Tx>{children}</Tx></details>;
}
// The introduction: the mathematician reads it in full; the other two read a short version, and the full text is one click away.
export function Intro({ lang, profile, id, lede }) {
  const lv = level(profile), sh = (SHORT[lang] || SHORT.en)[id]?.[lv];
  if (lv === 2 || !sh) return <p className="lede"><Tx>{lede}</Tx></p>;
  return <><p className="lede eq-short" data-level={lv}><Tx>{sh}</Tx></p><Fold title={(FOLD[lang] || FOLD.en).full} open={false}><p className="lede"><Tx>{lede}</Tx></p></Fold></>;
}
export { level };
