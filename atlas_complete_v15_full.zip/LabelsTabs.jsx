// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { COPY } from './labelsCopy.js';
import { CONV } from './conventionsCopy.js';
import { CellLattice, Trinity, BivectorLab, Horizon, Curvature, Rails, GolayCard, Primes } from './LabelsWidgets.jsx';
import { storyFor } from './StoryShell.jsx';
import { stepEyebrow, groupOfStep } from './steps.js';
import { Tx } from './MathText.jsx';
import { Fold } from './Fold.jsx';
import { StatusIcon } from './StatusBadge.jsx';
import { FOLD } from './audienceCopy.js';

// The three steps of the labels, each the body of a tab of another page: the clock and the trinity (step 1, the Conventions page), gauge gravity (the equations page) and the finite groups
// (the first step of the lenses page); ConventionsPage.jsx also draws the Conventions tab (not a numbered step) with the same frame: the glance, the eyebrow, the lede.
// Every picture is a live widget (LabelsWidgets.jsx) computed from the bit rule by labelsEngine.js; the Young Learner reads plain words and sees the pictures, the formulas are folded away.
export const LABELS_STYLE = `
.ls{max-width:1000px;margin:18px auto;padding:0 16px}.ls .eyebrow{margin:0 0 .3em}.ls .lede{margin:.5em 0}
.ls-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:12px 14px;margin:14px 0}.ls-card h3{margin:.1em 0 .5em;font-size:1.05em}
.ls-row{display:flex;flex-wrap:wrap;gap:14px}.ls-col{flex:1 1 280px;min-width:0}.ls-wide{flex:2 1 340px}
.ls-svg{width:100%;max-width:420px;display:block;margin:6px auto;height:auto}.ls-hz{max-width:520px}.ls-wheel{max-width:200px}.ls-cone{max-width:240px}.ls-sw{max-width:200px}.ls-pr{max-width:100%}
.ls-cell{cursor:pointer;outline:none}.ls-cell:focus-visible rect,.ls-cell:focus-visible circle{stroke:#4aa8ff;stroke-width:3}
.ls-legend{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:.78em;margin:4px 0}.ls-legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px}
.ls-tab{border-collapse:collapse;width:100%;font-size:.84em}.ls-tab th{text-align:left;font-weight:500;opacity:.75;padding:3px 8px 3px 0;vertical-align:top;width:42%}.ls-tab td{padding:3px 0;overflow-wrap:anywhere}
.ls-cap{font-size:.8em;opacity:.8;margin:.4em 0}.ls-mono{font-family:ui-monospace,monospace;font-size:.82em;overflow-wrap:anywhere;margin:.4em 0}.ls-state{margin:.5em 0}
.ls-sl{display:grid;grid-template-columns:minmax(70px,1.2fr) 3fr 4ch;gap:8px;align-items:center;font-size:.85em;margin:4px 0}.ls-sl input{width:100%;min-width:0}
.ls-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.ls-chip{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.ls-chip.on{background:rgba(80,170,255,.22);border-color:#4aa8ff}
.ls-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:5px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em;margin:4px 8px 4px 0}
.ls-chip:focus-visible,.ls-btn:focus-visible,.ls-hand summary:focus-visible,.ls-sl input:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.ls-live{display:inline-block;font-size:.72em;opacity:.65;border:1px dashed rgba(128,128,128,.5);border-radius:6px;padding:0 6px;margin-top:2px}
.ls-ok{color:#34d399}.ls-bad{color:#f87171}.ls-h4{margin:.9em 0 .3em;font-size:.95em}.ls-hand summary{cursor:pointer;font-size:.85em;margin:6px 0}.ls-chk{display:block;font-size:.85em;margin:6px 0}
.ls-barrow{display:grid;grid-template-columns:minmax(80px,130px) 1fr 4ch;gap:8px;align-items:center;font-size:.82em;margin:3px 0}.ls-bt{height:12px;border:1px solid rgba(128,128,128,.4);border-radius:3px;display:block;overflow:hidden}.ls-bt i{display:block;height:100%}
.ls-prime{display:inline-block;margin:0 4px;padding:0 7px;border:1px solid rgba(128,128,128,.5);border-radius:999px}.ls-prime.m{border-color:#fbbf24;color:#fbbf24}
.ls-glance{max-width:1000px;margin:10px auto 0;padding:8px 16px;border-left:3px solid rgba(80,170,255,.55);font-size:.85em}.ls-glance p{margin:.2em 0}.ls-glance .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}
.ls-glance .tag{white-space:normal;display:inline-block;max-width:100%;overflow-wrap:anywhere}
`;

const WIDGETS = { clock: W => <><CellLattice {...W} /><Trinity {...W} /><BivectorLab {...W} /></>, gauge: W => <><Horizon {...W} /><Curvature {...W} /></>, groups: W => <><Rails {...W} /><GolayCard {...W} /><Primes {...W} /></> };
// the anchor of each tab on the page that holds it (the Map's "Go there", the claims table)
export const LABELS_ANCHOR = { clock: 'cv-clock', gauge: 'eq-gauge', groups: 'ln-groups' };

// The frame of a tab of this family: the at-a-glance strip (not for the Young Learner), the eyebrow, the lede, the pictures (`children`, for every reader), then the content of the Conventions tab
// (`body`, not for the Young Learner, who finds it in the closed fold `fold`), the note on the checks and the link "which words we use" (`words`: its handler, null on the Conventions tab itself).
// `c` is the copy of the tab (labelsCopy.js tabs.<id>, or conventionsCopy.js), `eyebrow` its eyebrow, `id` the id of its section.
export function LabelsFrame({ lang, profile, c, eyebrow, id, words, body, fold, children }) {
  const L = lang === 'it' ? 'it' : 'en', yl = profile === 'Young Learner', s = storyFor(L, profile);
  return <>{!yl && <aside className="ls-glance" aria-label={s.glance}><p><span className="gl-k"><Tx>{s.glance.toUpperCase()}</Tx></span>{c.glance.tags.map(([k, txt]) => { const ks = (Array.isArray(k) ? k : String(k).split(/\s+/)).filter(Boolean); return <span key={txt} className={'tag ' + ks.join(' ')} title={ks.map(x => s.tagHelp[x]).join(' · ') || undefined}>{ks.map(x => <span key={x} className="pt-ic" role="img" aria-label={s.tags[x]}><StatusIcon flag={x} /></span>)}<Tx>{txt}</Tx></span>; })}</p>
        <p><span className="gl-k"><Tx>{s.checkedBy.toUpperCase()}</Tx></span><code>{c.glance.script}</code></p><p><Tx>{c.glance.est}</Tx></p></aside>}
      <section className="ls" id={id}><p className="eyebrow"><Tx>{eyebrow}</Tx></p>
        {(yl ? c.ledeY : profile === 'Mathematician' ? [...c.ledeM, ...c.lede.slice(1)] : c.lede).map((p, i) => <p key={i} className="lede"><Tx>{p}</Tx></p>)}
        {children}
        {!yl && body}
        {yl ? <Fold title={(FOLD[L] || FOLD.en).older} open={false}>{c.lede.map((p, i) => <p key={i} className="lede"><Tx>{p}</Tx></p>)}{fold}</Fold> : null}
        <p className="ls-cap"><Tx>{yl ? COPY[L].checkedNoteY : COPY[L].checkedNote}</Tx></p>
        {words && <p className="ls-cap"><button className="ls-btn" onClick={words}><Tx>{yl ? CONV[L].wordsLinkY : CONV[L].wordsLink}</Tx></button></p>}</section></>;
}

// one numbered step of the family: the clock (Conventions page), gauge gravity (equations page), the finite groups (lenses page); `words` opens the Conventions tab
function LabelsStep({ id, lang, profile, words }) {
  const L = lang === 'it' ? 'it' : 'en', W = { lang: L, yl: profile === 'Young Learner' };
  return <LabelsFrame lang={L} profile={profile} c={COPY[L].tabs[id]} id={LABELS_ANCHOR[id]} eyebrow={stepEyebrow(L, groupOfStep(id), id)} words={words}>{WIDGETS[id](W)}</LabelsFrame>;
}
export const ClockTab = ({ lang, profile, words }) => <LabelsStep id="clock" lang={lang} profile={profile} words={words} />;
export const GaugeTab = ({ lang, profile, go }) => <LabelsStep id="gauge" lang={lang} profile={profile} words={() => go('conventions', 'cv-top')} />;
export const GroupsTab = ({ lang, profile, go }) => <LabelsStep id="groups" lang={lang} profile={profile} words={() => go('conventions', 'cv-top')} />;
