// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The gravity check scripts of selfcheck/gravity/ are shipped whole and run from inside the package. Checks: (a) the folder holds exactly the files of its MANIFEST.sha256, with those
// sums; (b) every script that a checkedBy field of claimsLocators*.json names is in the package; (c) python3 compiles every script of the folder (into a temporary folder, no
// __pycache__ in the package); (d) every script carries the three-line licence header; (e) the README table names every script of the folder and only those; (f) the fast scripts
// (under 12 s in logs/SUMMARY.txt, at most 60 s in all) run again under python3 -I, exit 0 and print the check lines of their shipped logs; (g) no e-mail address and no
// postal address in the folder (the Horizons copies hold the placeholders); (h) no __pycache__ in the folder; (i) the figures the pages quote about the planets example (116.6 km, 41.5 km, 7.8 arcseconds,
// 7.3 degrees, 111 arcseconds, 0.003) are those of the shipped log of g3_vectors_compare.py. Counts pinned: the 66 scripts the claims name, and the exit code, ok, FAIL and s cells of the README
// table and the total of the release notes against logs/SUMMARY.txt.  Run: node test_gravity_scripts.mjs   (about a minute)
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import crypto from 'node:crypto'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs'; process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const GD = path.join(PKG, 'selfcheck', 'gravity'), rel = f => path.relative(GD, f).split(path.sep).join('/');
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const rd = f => fs.readFileSync(path.join(GD, f), 'utf8');
ok(fs.existsSync(GD) && fs.existsSync(path.join(GD, 'MANIFEST.sha256')), 'selfcheck/gravity/ and its MANIFEST.sha256 are there');

// (a) the folder holds exactly the files of MANIFEST.sha256, and their sha256 match (sha256sum -c format: "<hex>  <path>")
const manifest = () => { const m = new Map(); for (const l of rd('MANIFEST.sha256').split('\n')) { const x = /^([0-9a-f]{64}) [ *](.+)$/.exec(l); if (x) m.set(x[2], x[1]); else if (l.trim()) m.set('(bad line) ' + l, ''); } return m; };
const folderState = () => walk(GD).map(rel).filter(f => f !== 'MANIFEST.sha256').sort();
const M = manifest(), files = folderState();
{ const listed = [...M.keys()].sort(), extra = files.filter(f => !M.has(f)), gone = listed.filter(f => !files.includes(f)), wrong = files.filter(f => M.has(f) && M.get(f) !== sha(path.join(GD, f)));
  ok(listed.length > 100 && extra.length === 0 && gone.length === 0, `the folder holds exactly the ${listed.length} files of MANIFEST.sha256: not listed ${extra.join(', ')}; listed but missing ${gone.join(', ')}`);
  ok(wrong.length === 0, 'every file has the sha256 of the manifest: ' + wrong.join(', ')); }

// (b) every script named by a checkedBy field of the claims locators exists in the package: selfcheck/** (gravity/ included), researchers_checks/**, replication/**, or the
// package root; a name with * (the three lens_*_check.py) must match at least one file
{ const have = new Set([...['selfcheck', 'researchers_checks', 'replication'].flatMap(d => fs.existsSync(path.join(PKG, d)) ? walk(path.join(PKG, d)) : []),
    ...fs.readdirSync(PKG, { withFileTypes: true }).filter(e => e.isFile()).map(e => e.name)].map(f => path.basename(f)));
  const named = new Map();
  const go = (v, f) => { if (Array.isArray(v)) v.forEach(x => go(x, f)); else if (v && typeof v === 'object') for (const [k, x] of Object.entries(v)) { if (k === 'checkedBy' && typeof x === 'string') { for (const m of x.matchAll(/(?<![A-Za-z0-9_*])[A-Za-z0-9_*]+\.py\b/g)) { if (!named.has(m[0])) named.set(m[0], f); } } else go(x, f); } };
  const locs = fs.readdirSync(PKG).filter(f => /^claimsLocators[^/]*\.json$/.test(f)); for (const f of locs) go(JSON.parse(fs.readFileSync(path.join(PKG, f), 'utf8')), f);
  const found = n => n.includes('*') ? [...have].some(h => new RegExp('^' + n.replace(/[.]/g, '\\.').replace(/\*/g, '[A-Za-z0-9_]*') + '$').test(h)) : have.has(n);
  const missing = [...named.keys()].filter(n => !found(n));
  ok(locs.length >= 2 && named.size > 50, `the checkedBy fields of ${locs.length} claims locator files name ${named.size} scripts`);
  ok(missing.length === 0, 'every script a checkedBy field names is in the package: missing ' + missing.map(n => n + ' (' + named.get(n) + ')').join(', '));
  const grav = [...named.keys()].filter(n => fs.existsSync(path.join(GD, n)));
  ok(grav.length === 66, `the claims name 66 scripts that are in selfcheck/gravity/ (the number the documents quote): ${grav.length}`);
  console.log(`  (b) ${named.size} scripts named by checkedBy fields, ${grav.length} of them in selfcheck/gravity/`); }

// (c) python3 compiles every .py of the folder, into a temporary folder (py_compile with an explicit cfile: no __pycache__ in the package)
const PY = fs.readdirSync(GD).filter(f => f.endsWith('.py')).sort(), MJS = fs.readdirSync(GD).filter(f => f.endsWith('.mjs')).sort();
{ const code = 'import py_compile, sys, os, tempfile, shutil\nt = tempfile.mkdtemp()\nbad = []\nfor i, f in enumerate(sys.argv[1:]):\n    try: py_compile.compile(f, cfile=os.path.join(t, "%d.pyc" % i), doraise=True)\n    except Exception as e: bad.append(f + ": " + str(e).splitlines()[0])\nshutil.rmtree(t)\nprint("\\n".join(bad) if bad else "compiled %d" % (len(sys.argv) - 1))';
  const r = spawnSync('python3', ['-I', '-B', '-c', code, ...PY.map(f => path.join(GD, f))], { encoding: 'utf8', timeout: 120000 });
  ok(r.status === 0 && (r.stdout || '').trim() === 'compiled ' + PY.length, `python3 compiles all ${PY.length} scripts of the folder: ` + ((r.stdout || '') + (r.stderr || '')).trim().slice(0, 300)); }

// (d) every script of the folder (.py, .mjs, .sh) carries the three-line licence header in its first six lines
{ const H = ['SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors', 'Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)'];
  const scripts = files.filter(f => /\.(py|mjs|sh)$/.test(f)), bare = scripts.filter(f => { const h = rd(f).split('\n').slice(0, 6).join('\n'); return !H.every(x => h.includes(x)); });
  ok(scripts.length === PY.length + MJS.length + 1 && bare.length === 0, `all ${scripts.length} scripts carry the licence header: missing in ${bare.join(', ')}`); }

// (e) the README table names every script of the folder (.py and .mjs), and every script it names is in the folder; the rows of run_all.sh are the rows of the table
const ROWS = [...rd('run_all.sh').matchAll(/^\s*"([a-z0-9_]+)\|([^"]+)"\s*$/gm)].map(m => ({ name: m[1], cmd: m[2].trim().split(/\s+/) }));
{ const readme = rd('README.md'), table = readme.split('\n').filter(l => /^\|/.test(l));
  const inTable = new Set(table.flatMap(l => [...l.matchAll(/`([A-Za-z0-9_]+\.(?:py|mjs))(?:\s[^`]*)?`/g)].map(m => m[1])));
  const scripts = [...PY, ...MJS], notListed = scripts.filter(f => !inTable.has(f)), notThere = [...inTable].filter(f => !scripts.includes(f));
  ok(notListed.length === 0 && notThere.length === 0, `the README table names exactly the ${scripts.length} scripts of the folder: not named ${notListed.join(', ')}; named but absent ${notThere.join(', ')}`);
  const tableCmds = new Set(table.map(l => (/^\|[^|]*\|\s*`([^`]+)`/.exec(l) || [])[1]).filter(Boolean));
  const runCmds = ROWS.map(r => r.cmd.join(' ')), noRow = runCmds.filter(c => !tableCmds.has(c));
  ok(ROWS.length === 69 && new Set(ROWS.map(r => r.name)).size === 69 && noRow.length === 0, `run_all.sh has 69 rows (the 66 scripts the claims name, the import-only helper g1_clkappa and the helper self-test g2_forms_calc, the n = 5 run of A2b), each a row of the README table: ${noRow.join(', ')}`);
  ok(ROWS.every(r => fs.existsSync(path.join(GD, r.cmd[0])) && fs.existsSync(path.join(GD, 'logs', r.name + '.log'))), 'every row of run_all.sh has its script and its shipped log'); }

// (f) the fast subset: rows of logs/SUMMARY.txt under 12 s, in increasing time while the shipped times add up to at most 60 s; each runs again from the folder under
// python3 -I -B, ulimit -v 3000000 and timeout 120, exits 0 and prints exactly the check lines (ok / FAIL) of its shipped log (a time inside a line, "(0.3 s)", is not compared)
{ const SUMMARY = new Map(rd('logs/SUMMARY.txt').split('\n').filter(l => l && !l.startsWith('#') && !l.startsWith('name ')).map(l => l.split(/\s+/)).map(f => [f[0], { rc: f[1], sec: +f[2], ok: f[3], fail: f[4], last: f.slice(5).join(' ') }]));
  ok(SUMMARY.size === 69 && ROWS.every(r => SUMMARY.has(r.name)), `logs/SUMMARY.txt has a line for every row (${SUMMARY.size})`);
  // the README table gives every row the exit code, ok, FAIL and s of SUMMARY (the three import-only helpers say "no output (import only)" where the runner prints "(no output)"), and the release notes quote the total
  { const cells = rd('README.md').split('\n').filter(l => /^\|/.test(l)).map(l => l.replace(/^\||\|$/g, '').split('|').map(c => c.trim())).filter(c => c.length === 9);
    const byCmd = new Map(ROWS.map(r => [r.cmd.join(' '), r.name])), bad = [], seen = new Set();
    for (const c of cells) { const m = /^`([^`]+)`$/.exec(c[1]), name = m && byCmd.get(m[1]); if (!name) continue; seen.add(name); const s = SUMMARY.get(name);
      const first = s.last === '(no output)' ? '0; no output (import only)' : `${s.rc}; \`${s.last}\``;
      if (c[5] !== first || c[6] !== s.ok || c[7] !== s.fail || c[8] !== String(s.sec)) bad.push(`${name}: README ${c.slice(5).join(' | ')} against SUMMARY ${first} | ${s.ok} | ${s.fail} | ${s.sec}`); }
    ok(bad.length === 0 && seen.size === 69, `the README table gives each of the ${seen.size} rows the exit code, ok, FAIL and s of logs/SUMMARY.txt: ` + bad.join(' ; '));
    const total = [...SUMMARY.values()].reduce((a, s) => a + Number(s.ok), 0);
    ok([...SUMMARY.values()].every(s => s.rc === '0' && s.fail === '0'), 'no FAIL line and no non-zero exit code in logs/SUMMARY.txt');
    ok(fs.readFileSync(path.join(PKG, 'RELEASE_NOTES_v15.md'), 'utf8').includes(`runs its 69 rows (${total.toLocaleString('en-US')} checks,`), `the release notes quote the ${total.toLocaleString('en-US')} ok lines of logs/SUMMARY.txt`); }
  const fast = []; let budget = 0;
  for (const r of ROWS.filter(r => SUMMARY.get(r.name) && SUMMARY.get(r.name).sec < 12).sort((a, b) => SUMMARY.get(a.name).sec - SUMMARY.get(b.name).sec)) { if (budget + SUMMARY.get(r.name).sec > 60) break; budget += SUMMARY.get(r.name).sec; fast.push(r); }
  ok(fast.length >= 15, `the fast subset has ${fast.length} scripts (${budget} s by the shipped times)`);
  const checkLines = t => t.split('\n').filter(l => /^\s*(ok|FAIL)\b/.test(l)).map(l => l.replace(/\((\d+\.\d) s\)/g, '(T s)'));
  const hasTimeout = spawnSync('sh', ['-c', 'command -v timeout'], { encoding: 'utf8' }).status === 0, t0 = Date.now(); const ran = [];
  for (const r of fast) {
    if (Date.now() - t0 > 240000) { ok(false, 'the fast subset took more than 240 s: ' + r.name + ' and the rest were not run'); break; }
    const cmd = 'ulimit -v 3000000; exec ' + (hasTimeout ? 'timeout 120 ' : '') + 'python3 -I -B ' + r.cmd.map(a => "'" + a + "'").join(' ');
    const p = spawnSync('sh', ['-c', cmd], { cwd: GD, encoding: 'utf8', timeout: 130000, maxBuffer: 64 << 20 });
    const got = checkLines((p.stdout || '') + '\n' + (p.stderr || '')), want = checkLines(rd('logs/' + r.name + '.log'));
    const same = JSON.stringify(got) === JSON.stringify(want), firstDiff = got.findIndex((l, i) => l !== want[i]);
    ok(p.status === 0 && same, `${r.name}: exit ${p.status}, ${got.length} check lines, the same as the shipped log (${want.length})` + (same ? '' : ': first difference ' + JSON.stringify([got[firstDiff], want[firstDiff]]).slice(0, 300)));
    ran.push(r.name);
  }
  console.log(`  (f) ran ${ran.length} scripts in ${((Date.now() - t0) / 1000).toFixed(1)} s: ${ran.join(' ')}`);
  ok(JSON.stringify(folderState()) === JSON.stringify(files) && files.every(f => M.get(f) === sha(path.join(GD, f))), 'the runs wrote nothing into the folder: same files, same sums'); }

// (g) no e-mail address (the regex of test_license.mjs; reserved example domains allowed) and no postal address in any file of the folder; the Horizons copies hold the placeholders
{ const EMAIL = /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}/g, RESERVED = /@([A-Za-z0-9-]+\.)*(example\.(com|org|net)|[A-Za-z0-9-]+\.invalid|example|invalid|test|localhost)$/i;
  const STREET = /\b\d{1,6}\s+(?:[A-Z][A-Za-z]+\s+){1,3}(?:Street|St|Avenue|Ave|Road|Rd|Drive|Dr|Boulevard|Blvd|Lane|Ln|Way|Place|Pl|Court|Ct)\b/, CITYZIP = /\b[A-Z][A-Za-z]+(?:\s[A-Z][A-Za-z]+)*,\s+[A-Z]{2}\s+\d{5}(?:-\d{4})?\b/, POBOX = /\bP\.?\s?O\.?\s+Box\s+\d+/i;
  const mails = [], posts = [];
  for (const f of files) { const t = fs.readFileSync(path.join(GD, f), 'utf8');
    for (const m of t.matchAll(EMAIL)) if (!RESERVED.test(m[0].slice(m[0].indexOf('@')))) mails.push(f + ': ' + m[0]);
    if (/mailto:/i.test(t)) mails.push(f + ': mail link');
    t.split('\n').forEach((l, i) => { if (STREET.test(l) || CITYZIP.test(l) || POBOX.test(l)) posts.push(f + ':' + (i + 1)); }); }
  ok(mails.length === 0, 'no e-mail address or mail link in the folder: ' + mails.slice(0, 5).join(' | '));
  ok(posts.length === 0, 'no postal address in the folder: ' + posts.slice(0, 5).join(' | '));
  const planted = [['12', 'Example', 'Road,', 'Springfield'].join(' '), ['Springfield,', 'ZZ', '00000'].join(' ')];
  ok(STREET.test(planted[0]) && CITYZIP.test(planted[1]) && !STREET.test('the 12 points of the road') && !CITYZIP.test('Kerr, RN 2-jets'), 'the address patterns catch a planted street line and a planted city line, and pass ordinary text');
  const HZ = ['sun', 'mercury', 'venus'].map(n => 'data/horizons/' + n + '.txt');
  ok(HZ.every(f => files.includes(f)) && HZ.every(f => { const t = rd(f), foot = t.slice(t.indexOf('$$EOE')); return t.includes('$$SOE') && (foot.match(/\[postal address removed in this copy\]/g) || []).length === 2 && (foot.match(/\[e-mail removed in this copy\]/g) || []).length === 1; }),
    'the three Horizons copies hold the table ($$SOE..$$EOE) and, in the footer, the placeholders of the two address lines and of the e-mail line');
  const VZ = files.filter(f => /^data\/horizons_vectors\/vec_(2018|2026)_[a-z_]+\.txt$/.test(f));
  ok(VZ.length === 30 && VZ.every(f => { const t = rd(f), foot = t.slice(t.indexOf('$$EOE')); return t.includes('$$SOE') && (foot.match(/\[postal address removed in this copy\]/g) || []).length === 2 && (foot.match(/\[e-mail removed in this copy\]/g) || []).length === 1; }),
    'the 30 Horizons vector tables hold the table ($$SOE..$$EOE) and, in the footer, the placeholders of the two address lines and of the e-mail line'); }

// (h) no __pycache__ (and no compiled file) anywhere in the folder
{ const dirs = []; const wd = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) if (e.isDirectory()) { if (e.name === '__pycache__') dirs.push(rel(path.join(d, e.name))); wd(path.join(d, e.name)); } }; wd(GD);
  ok(dirs.length === 0 && !files.some(f => /\.py[co]$/.test(f)), 'no __pycache__ and no .pyc in the folder: ' + dirs.join(', ')); }

// (i) the figures the pages quote about the planets example are the figures of the shipped log of g3_vectors_compare.py (checks V2-4, V5-12, V5-13 and logs/g3_vectors_compare.numbers.json): in the text files of the
// package every "common translation of X km", "a further X km" (the Jupiter row), "X arcseconds for Mercury", "up to X degrees", "Jupiter X arcseconds" and "Mercury (comes) to 0.00X" gives X as rounded from the log
{ const J = JSON.parse(rd('logs/g3_vectors_compare.numbers.json')), C = J.checks, v24 = C['V2-4'], q4 = C['V5-12'], q0 = C['V5-13'].M0_dir_max_as, m5 = C['V5-13'].M5_mercury_as;
  ok(Math.abs(v24.T_norm_km - 116.6) < 0.05 && Math.abs(v24.jupiter_after_T_km - 41.5) < 0.05 && Math.abs(J.V2.T_norm_km - v24.T_norm_km) < 1e-9, `the log gives the common translation ${v24.T_norm_km} km and the Jupiter offset ${v24.jupiter_after_T_km} km`);
  const files = [...fs.readdirSync(PKG, { withFileTypes: true }).filter(e => e.isFile() && /\.(js|jsx|mjs|md|py|json)$/.test(e.name) && e.name !== 'test_gravity_scripts.mjs').map(e => e.name),
    ...fs.readdirSync(path.join(PKG, 'lib')).filter(f => f.endsWith('.js')).map(f => 'lib/' + f), 'selfcheck/pgadyn_selfcheck.py', 'selfcheck/gravity/README.md'];
  const specs = [[/(?:common translation of|traslazione comune di) (\d+[.,]\d) km/g, v24.T_norm_km, 1, 'the common translation', 15], [/(?:a further|altri) (\d+[.,]\d) km/g, v24.jupiter_after_T_km, 1, 'the Jupiter offset', 15],
    [/(\d+[.,]\d) arcseconds for Mercury/g, q4.mercury, 1, 'Mercury in M4', 4], [/up to (\d+[.,]\d) degrees/g, q0.mercury / 3600, 1, 'Mercury in M0, degrees', 4],
    [/Jupiter (\d+) arcseconds/g, q0.jupiter, 0, 'Jupiter in M0', 3], [/Mercury (?:comes )?to (0[.,]\d{3})\b/g, m5, 3, 'Mercury with the 1PN term', 4],
    [/(?:the same|degli stessi) (\d+[.,]\d) km/g, v24.T_norm_km, 1, 'the common translation (plain lines)', 5], [/by (\d+[.,]\d) km more/g, v24.jupiter_after_T_km, 1, 'the Jupiter offset (learner line)', 1],
    [/Mars (\d[.,]\d) degrees/g, q0.mars / 3600, 1, 'Mars in M0, degrees', 2], [/(\d+[.,]\d) arcsec for Mercury/g, q4.mercury, 1, 'Mercury in M4 (README)', 1], [/Jupiter (\d+) arcsec\b/g, q0.jupiter, 0, 'Jupiter in M0 (README)', 1]];
  const found = specs.map(() => ({ n: 0, wrong: [] }));
  for (const f of files) { const t = fs.readFileSync(path.join(PKG, f), 'utf8');
    specs.forEach(([re, val, dec], i) => { for (const m of t.matchAll(re)) { found[i].n++; if (m[1].replace(',', '.') !== val.toFixed(dec)) found[i].wrong.push(f + ': ' + m[0]); } }); }
  specs.forEach(([, val, dec, what, least], i) => ok(found[i].n >= least && found[i].wrong.length === 0, `${what}: ${found[i].n} places in the package (at least ${least}) all give ${val.toFixed(dec)}, the log's value rounded: wrong ${found[i].wrong.slice(0, 4).join(' | ')}`)); }

console.log(bad ? `${bad} FAILURES (${checks} checks)` : `ALL GRAVITY SCRIPTS TESTS PASS: ${checks} checks`); process.exit(bad ? 1 : 0);
