// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The page: settings, the worker (or the main-thread fallback), live tables, the chart, export and compare. Nothing here times anything: all timing is in LBCORE (runners.js + the kernels).
(function () {
'use strict';
const CORE = LBCORE, BUILD = { version: '@@VERSION@@', hash: '@@HASH@@' }, SEED = 12345;
const $ = id => document.getElementById(id);
function h(tag, attrs, ...kids) {
  const e = document.createElement(tag);
  if (attrs) for (const k of Object.keys(attrs)) { const v = attrs[k]; if (v == null || v === false) continue; if (k === 'class') e.className = v; else e.setAttribute(k, v === true ? '' : v); }
  for (const c of kids.flat()) if (c != null && c !== false) e.append(c.nodeType ? c : document.createTextNode(String(c)));
  return e;
}

// ---------------------------------------------------------------- numbers
const NBSP = ' ', MINUS = '−';
const unitFor = ns => { const a = Math.abs(ns); return a < 1e3 ? { d: 1, u: 'ns' } : a < 1e6 ? { d: 1e3, u: 'µs' } : a < 1e9 ? { d: 1e6, u: 'ms' } : { d: 1e9, u: 's' }; };
const dig = x => { const a = Math.abs(x); return a >= 100 ? 0 : a >= 10 ? 1 : 2; };
function fmtT(ns) { if (ns == null || !isFinite(ns)) return '-'; const { d, u } = unitFor(ns), v = ns / d; return v.toFixed(dig(v)) + NBSP + u; }
function fmtRange(st) { const { d, u } = unitFor(st.med), g = dig(st.med / d); return (st.min / d).toFixed(g) + '–' + (st.max / d).toFixed(g) + NBSP + u; }
const fmtRatio = r => r.toFixed(r >= 10 ? 1 : 2) + 'x';
const fmtPct = x => (x * 100).toFixed(0) + '%';
function fmtRate(p) { return (p >= 1e6 ? (p / 1e6).toFixed(2) + ' M' : p >= 1e4 ? (p / 1e3).toFixed(0) + ' k' : p >= 1e3 ? (p / 1e3).toFixed(1) + ' k' : p.toFixed(0)) + ' bodies/s'; }
function fmtDur(sec) { return sec < 90 ? Math.round(sec) + ' s' : sec < 5400 ? Math.round(sec / 60) + ' min' : (sec / 3600).toFixed(1) + ' h'; }
const spreadOf = st => st && st.med > 0 ? (st.max - st.min) / st.med : null;
const okStats = st => st && typeof st.med === 'number' && st.med > 0 && typeof st.min === 'number' && typeof st.max === 'number';
const median = a => { const s = a.slice().sort((x, y) => x - y); return s[s.length >> 1]; };
const summ = a => ({ med: median(a), min: Math.min(...a), max: Math.max(...a) });

// ratio = baseline / variant (both medians). Verdict on the log scale, so that a k-fold win and a k-fold loss are judged alike: about equal when |ln ratio| < ln(1 + tol),
// tol = the larger of 5% and the larger of the two spreads, i.e. when 1/(1 + tol) < ratio < 1 + tol; otherwise faster or slower. (A rule |ratio - 1| < tol would let a loss of any size read "about equal".)
// Noisy: a spread above 15%. No verdict (null) when a timing is missing or has a median of 0 (a batch shorter than one timer step): such a pair is shown as "not judged", never dropped.
const VERDICT_FLOOR = 0.05;
function judge(base, cand) {
  if (!okStats(base) || !okStats(cand)) return null;
  const ratio = base.med / cand.med, spread = Math.max(spreadOf(base), spreadOf(cand)), tol = Math.max(VERDICT_FLOOR, spread), lr = Math.log(ratio);
  return { ratio, spread, tol, verdict: Math.abs(lr) < Math.log1p(tol) ? 'equal' : lr > 0 ? 'faster' : 'slower', noisy: spread > 0.15 };
}
const WORD = { faster: 'faster', slower: 'slower', equal: 'about equal within noise' }, GLYPH = { faster: '▲', slower: '▼', equal: '≈' };
const claimText = (name, j) => { const r = fmtRatio(j.ratio); return j.verdict === 'faster' ? name + ' is ' + r + ' faster' : j.verdict === 'slower' ? name + ' is ' + r + ', i.e. slower' : name + ' is ' + r + ', about equal'; };
const chip = v => h('span', { class: 'chip ' + v }, GLYPH[v] + NBSP + WORD[v]);
const noisyTag = () => h('span', { class: 'noisy' }, '⚠ noisy');
// the reference run embedded at build time (selfcheck/bench_labels.json): the figures the page quotes from node come from it, never typed
const REF_RUN = (() => { try { return JSON.parse(document.getElementById('ref-run').textContent); } catch (e) { return null; } })();
function refAllocText() {
  const a = REF_RUN && Array.isArray(REF_RUN.alloc) ? REF_RUN.alloc.find(r => r.doubles === 16) : null, m = REF_RUN && REF_RUN.machine || {};
  if (!a || !okStats(a.ns.plain) || !okStats(a.ns.f64)) return 'The reference run has no allocation rows yet (regeneration pending).';
  return 'In the reference run (node ' + m.node + ', ' + m.date + ', selfcheck/bench_labels.json) a Float64Array of 16 doubles took ' + fmtT(a.ns.f64.med) + ' to allocate and a plain Array ' + fmtT(a.ns.plain.med) + '.';
}

// ---------------------------------------------------------------- what each scenario is
// ROLE: which method is the standard one and which is ours, and which comparison is the key result of the scenario (the one the "At a glance" table reports).
//   candIs: whether the candidate of the key comparison (the method the claim is about) is ours or the standard; the glance table always reads "ours against the standard".
//   "Ours" only where the label's own idea is what is timed: the frame itself (n + 1 sandwiches, then additions) is linearity of the sandwich, a standard fact, so in the vertices job
//   ours is the doubling by the label (one addition a corner) and its standard rival is the matrix route built from the same frame; the frame against one sandwich per corner is shown as
//   a comparison of two standard methods (STD_PAIRS), outside the tally of ours.
const ROLE = {
  vertices: { job: 'Vertices of the cube', doing: 'building the corners of the cube from the frame', std: 'the matrix route built from the same frame (n² multiplications a corner)', stdShort: 'the matrix route from the same frame', ours: 'doubling by the label from the same frame (one addition a corner)', oursShort: 'doubling by the label', head: 'v_matrix', candIs: 'ours',
    alsoStd: 'the frame itself: n + 1 sandwiches, then additions (linearity of the sandwich), against one sandwich per corner (2^n sandwiches)' },
  contact: { job: 'Contact: deepest corner under a plane', doing: 'finding the deepest corner under a plane, building counted', std: 'scan of all 2^n corners', stdShort: 'the scan', ours: 'n sign bits of the frame', oursShort: 'the sign bits', head: 'c_built', candIs: 'ours' },
  outline: { job: 'Outline of the projected cube', doing: 'getting the outline of the projected cube, building counted', std: 'convex hull of the 2^n projected points', stdShort: 'the hull', ours: 'zonogon from the n projected edges', oursShort: 'the zonogon', head: 'o_built', candIs: 'ours' },
  product: { job: 'Product of two dense multivectors', doing: 'the product of two dense multivectors', std: 'the matrix route: Cl(k,k) = M(2^k, R), the textbook way', stdShort: 'the matrix route', ours: 'the bit rule: signs from the labels (XOR), here with a sign table', oursShort: 'the bit rule', head: 'p_best', candIs: 'std' },
  bodies: { job: 'Many bodies, contact step', doing: 'testing every body of a scene against one plane, building counted', std: 'build each body’s table from its frame, then scan', stdShort: 'table and scan', ours: 'build each body’s frame, then n sign bits', oursShort: 'frame and sign bits', head: 'b_built', candIs: 'ours' },
  alloc: { job: 'Allocation', doing: 'allocating one multivector', std: 'Float64Array', stdShort: 'Float64Array', ours: 'plain Array (the engine’s choice)', oursShort: 'plain Array', head: 'al_plain', candIs: 'ours', pick: 'a16' },
};
// comparisons of two standard methods that At a glance shows for context, outside the tally of ours (each names its scenario and comparison; base and cand are the two methods)
const STD_PAIRS = [
  { id: 'vertices', comp: 'v_frame', job: 'Vertices: the frame (both standard)', doing: 'building the corners of the cube', std: 'one sandwich per corner (2^n sandwiches)', stdShort: 'one sandwich per corner', cand: 'the frame: n + 1 sandwiches, then additions (linearity of the sandwich)', candShort: 'the frame' },
];
const OUR_SENTENCE = '';      // optional: a fixed sentence about our best model; shown above the generated summary when it is not empty
const V = (id, short, long) => ({ id, short, long });
const SC = {
  vertices: {
    title: 'Vertices', keyHead: 'n', keyLabel: k => 'n = ' + k, keyShort: k => String(k), keySub: k => Math.pow(2, +k) + ' vs ' + (+k + 1) + ' sandwiches',
    lead: 'Time to produce all 2^n corners of an n-cube from one motor.',
    what: 'Time per call to produce all 2^n world corners of an n-cube from one motor. Direct: one sandwich per corner. Frame: n + 1 sandwiches (the centre and the n edges), then 2^n − 1 additions. Mirror: the odd half taken as mirror images through the centre. Matrix route: the frame, then n² multiplications for every corner. The last two columns time the table step alone, with the frame given.',
    variants: [V('direct', 'direct'), V('frame', 'frame'), V('matrix', 'matrix route'), V('mirror', 'mirror'), V('doubling', 'doubling, frame given'), V('matrixGiven', 'n² a corner, frame given')],
    comps: [
      { id: 'v_frame', base: 'direct', cand: 'frame', name: 'frame', label: 'frame against one sandwich per corner (both standard)', note: 'n + 1 sandwiches and 2^n − 1 additions against 2^n sandwiches: linearity of the sandwich, a standard fact, not the label' },
      { id: 'v_matrix', base: 'matrix', cand: 'frame', name: 'frame with doubling', label: 'frame with doubling against the matrix route from the same frame (ours against standard)', note: 'both build the same frame; then doubling by the label, one addition a corner, against n² multiplications a corner' },
      { id: 'v_mirror', base: 'frame', cand: 'mirror', name: 'mirror', label: 'mirror against frame', note: 'the odd half as mirror images: a symmetry, claimed to save nothing' },
      { id: 'v_table', base: 'matrixGiven', cand: 'doubling', name: 'doubling', label: 'doubling against n² a corner, frame given', note: 'the table step alone' }],
    chart: { title: 'Solid: doubling by the label (ours) against the matrix route from the same frame (standard). Hatched: the frame against one sandwich per corner (both standard). By n; a bar above 1x means the first-named is faster', series: [['v_matrix', 'doubling against the matrix route, same frame'], ['v_frame', 'frame against one sandwich per corner']] },
  },
  contact: {
    title: 'Contact: deepest vertex under a plane', keyHead: 'n', keyLabel: k => 'n = ' + k, keyShort: k => String(k),
    lead: 'Time to find the deepest corner under a plane, 16 plane normals in turn.',
    what: 'Time per query to find the deepest corner under a plane (16 fixed plane normals in turn). Scan: 2^n dot products over a table of corners. Sign bits: n dot products over the frame, one sign each. Given: the table or the frame already exists. Building counted: the cost of building the table (frame, then doubling) or the frame is included.',
    variants: [V('scan', 'scan, table given'), V('bits', 'sign bits, frame given'), V('scanBuilt', 'build table, then scan'), V('bitsBuilt', 'build frame, then sign bits')],
    comps: [
      { id: 'c_given', base: 'scan', cand: 'bits', name: 'sign bits', label: 'sign bits against scan, table and frame given', note: 'the claim in isolation' },
      { id: 'c_built', base: 'scanBuilt', cand: 'bitsBuilt', name: 'sign bits', label: 'sign bits against scan, building counted', note: 'what a page pays when the table or the frame must be built first' }],
    chart: { title: 'Ours (sign bits) against standard (scan), by n: a bar above 1x means ours is faster', series: [['c_given', 'given'], ['c_built', 'building counted']] },
  },
  outline: {
    title: 'Outline', keyHead: 'n', keyLabel: k => 'n = ' + k, keyShort: k => String(k),
    lead: 'Time to get the flat outline of the projected cube (n ≥ 2).',
    what: 'Time per call to get the flat outline of the projected cube. Hull: convex hull of the 2^n projected points. Zonogon: the 2n-corner outline built from the n projected edge vectors. Given: the points or the edges already exist. Building counted: table, projection and hull (or frame, projection and zonogon) are all included. Needs n ≥ 2.',
    variants: [V('hull', 'hull, points given'), V('zono', 'zonogon, edges given'), V('hullBuilt', 'table + project + hull'), V('zonoBuilt', 'frame + project + zonogon')],
    comps: [
      { id: 'o_given', base: 'hull', cand: 'zono', name: 'zonogon', label: 'zonogon against hull, given', note: 'the claim in isolation' },
      { id: 'o_built', base: 'hullBuilt', cand: 'zonoBuilt', name: 'zonogon', label: 'zonogon against hull, building counted', note: 'construction included on both sides' }],
    chart: { title: 'Ours (zonogon) against standard (hull), by n: a bar above 1x means ours is faster', series: [['o_given', 'given'], ['o_built', 'building counted']] },
  },
  product: {
    title: 'Product: bit rule against matrix route', keyHead: 'n', keyLabel: k => 'n = ' + k, keyShort: k => String(k), keySub: k => cnt(Math.pow(4, +k)) + ' terms vs ' + cnt(Math.pow(8, +k / 2)) + ' multiplications',
    lead: 'Time to multiply two dense multivectors of Cl(k,k), n = 2k, in exact integers.',
    what: 'Time per product of two dense multivectors of the neutral algebra Cl(k,k), n = 2k generators. Bit rule: 4^n terms, the sign of each worked out. Sign table: the same terms with the signs read from a table built before the clock starts. Matrix route: Cl(k,k) = M(2^k, R), so a multivector becomes a 2^k × 2^k real matrix (a butterfly on each of the k sites, k·4^k additions), one matrix product (8^k multiplications), and back. Matrix product alone: the matrices already exist. Period 8 blocks (n ≥ 10): Cl(N+8) = M16(Cl(N)) with N = n − 8, so 16³ = 4096 products in Cl(N), each by the bit rule with its sign table, the way in and out counted. Allocation: as written, one call of the matrix route allocates seven Float64Arrays of 2^n doubles and the sign-table product one, so "matrix route, whole" measures the route plus that allocation. "Buffers allocated once" runs the same arithmetic on buffers made before the clock starts (the sign table likewise with its output), so it measures the route itself; "the route’s 7 allocations alone" times those seven allocations and nothing else. Dense inputs with integer coefficients, answers compared exactly before any timing. Multivectors with only a few blades are another case, where the bit rule is the cheaper one.',
    variants: [V('bitRule', 'bit rule'), V('signTable', 'bit rule, sign table'), V('signTableReuse', 'sign table, output allocated once'), V('matmulGiven', 'matrix product alone'), V('matrixRoute', 'matrix route, whole'), V('matrixRouteReuse', 'matrix route, buffers allocated once'), V('routeAllocs', 'the route’s 7 allocations alone'), V('period8', 'period 8 blocks')],
    comps: [
      { id: 'p_best', base: 'signTable', cand: 'matrixRoute', name: 'matrix route', label: 'matrix route against the bit rule with a sign table, as written', note: 'the fairest plain rival: signs read from a table; the conversion and the route’s seven allocations per call are counted on the matrix side, one allocation on the other' },
      { id: 'p_reuse', base: 'signTableReuse', cand: 'matrixRouteReuse', name: 'matrix route, buffers allocated once', label: 'the same two with their buffers allocated once: the route itself', note: 'same arithmetic, no allocation inside the timed call on either side' },
      { id: 'p_alloc', base: 'matrixRoute', cand: 'matrixRouteReuse', name: 'matrix route, buffers allocated once', label: 'matrix route: buffers allocated once against allocated on every call', note: 'what the seven allocations per call cost the route (the row “the route’s 7 allocations alone” times them directly)' },
      { id: 'p_rule', base: 'bitRule', cand: 'matrixRoute', name: 'matrix route', label: 'matrix route against the bit rule with signs worked out', note: 'the plain rule, which also runs at every n' },
      { id: 'p_given', base: 'signTable', cand: 'matmulGiven', name: 'matrix product alone', label: 'matrix product alone against the sign-table bit rule', note: 'the matrices already exist: the 2^(n/2) gain with no conversion (one allocation on each side)' },
      { id: 'p_p8', base: 'signTable', cand: 'period8', name: 'period 8 blocks', label: 'period 8 blocks against the sign-table bit rule', note: '16 times fewer terms at n ≥ 10, the blocks still done by the bit rule' }],
    chart: { title: 'Standard (matrix route, as written) against ours (bit rule), by n: a bar above 1x means the standard is faster', series: [['p_best', 'against the sign table'], ['p_rule', 'against the plain rule']] },
  },
  bodies: {
    title: 'Many bodies', keyHead: 'Scene', keyLabel: () => 'scene', keyShort: () => 'scene', special: 'bodies',
    lead: 'A scene of B bodies: build every body’s corners, then test every body against one plane.',
    what: 'A scene of B bodies, each with its own random motor from a seeded generator (the same seed gives the same scene). One scene step builds the corners of every body, or tests every body against one plane. The motors are held fixed, so the cost of integrating the dynamics is not counted. Contact is timed with tables or frames given and with building counted; the last pair is the whole path: direct corners and scan against frame and sign bits.',
    variants: [V('buildDirect', 'build all corners: direct'), V('buildFrame', 'build all corners: frame'), V('scanGiven', 'contact: scan, tables given'), V('bitsGiven', 'contact: sign bits, frames given'), V('scanBuilt', 'contact: build table, then scan'), V('bitsBuilt', 'contact: build frame, then sign bits'), V('e2eNaive', 'whole path: direct, then scan')],
    comps: [
      { id: 'b_build', base: 'buildDirect', cand: 'buildFrame', name: 'frame', label: 'build all corners: frame against direct', note: 'one scene step' },
      { id: 'b_given', base: 'scanGiven', cand: 'bitsGiven', name: 'sign bits', label: 'contact of every body: sign bits against scan, given', note: 'tables and frames already built' },
      { id: 'b_built', base: 'scanBuilt', cand: 'bitsBuilt', name: 'sign bits', label: 'contact of every body: sign bits against scan, building counted', note: 'table or frame built for each body' },
      { id: 'b_e2e', base: 'e2eNaive', cand: 'bitsBuilt', name: 'frame and sign bits', label: 'whole path: frame and sign bits against direct and scan', note: 'build and query for every body in each step; this mixes the frame’s gain over one sandwich per corner (standard) with the sign bits’ (ours)' }],
  },
  warm: {
    title: 'Warm-up and cold start', special: 'warm',
    lead: 'The first call and the first 10 calls of one function against its steady state: a one-off call in a page is not a hot loop.',
    what: 'The first call and the first 10 calls of one function, against its steady state after warm-up. Each repeat starts a fresh worker, so the code is cold; the set-up (algebra tables, motor, inputs) is done before the clock starts.',
  },
  alloc: {
    title: 'Allocation', keyHead: 'What', keyLabel: k => ALLOC_LABEL[k] || k, keyShort: k => (ALLOC_LABEL[k] || k).replace(' (', ', ').replace(')', ''),
    lead: 'Plain Array against Float64Array: allocating one multivector, and a small sandwich-like loop.',
    what: 'Plain Array (the engine’s choice: new Array(N).fill(0)) against Float64Array, for allocating one multivector of 8 to 64 doubles and for a small sandwich-like loop (two products M X M~ of 16-double even multivectors; the loop allocates its two results; in the last column the Float64Array buffers are reused instead). ' + refAllocText() + ' Whatever this browser gives is shown, including no difference. A ring of 64 live arrays keeps the allocation from being optimised away.',
    variants: [V('plain', 'plain Array'), V('f64', 'Float64Array'), V('f64reuse', 'Float64Array, buffers reused')],
    comps: [
      { id: 'al_plain', base: 'f64', cand: 'plain', name: 'plain Array', label: 'plain Array against Float64Array', note: 'allocation of one multivector, and the loop' },
      { id: 'al_reuse', base: 'plain', cand: 'f64reuse', name: 'Float64Array with reused buffers', label: 'reused Float64Array against plain Array', note: 'the loop only: no allocation inside it', keys: ['loop'] }],
  },
};
const cnt = x => x >= 1e6 ? (x / 1e6).toFixed(x >= 1e7 ? 0 : 1) + ' M' : x >= 1e3 ? (x / 1e3).toFixed(x >= 1e4 ? 0 : 1) + ' k' : String(x);
const ALLOC_LABEL = { a8: 'allocate 8 doubles', a16: 'allocate 16 doubles', a32: 'allocate 32 doubles', a64: 'allocate 64 doubles', loop: 'sandwich-like loop (16 doubles)' };
const ALLOC_ORDER = ['a8', 'a16', 'a32', 'a64', 'loop'];
const SHOW_ORDER = ['vertices', 'contact', 'outline', 'product', 'bodies', 'warm', 'alloc'];
const KERNEL = ['vertices', 'contact', 'outline'];
const PRESETS = { quick: { minMs: '20', reps: '3' }, careful: { minMs: '200', reps: '15' } };

// ---------------------------------------------------------------- state
let S;
function freshState() {
  return { running: false, stopFlag: false, stopped: false, error: null, mode: null, modeNote: '', worker: null, cancel: null, cfg: null, dateISO: null, t0: 0, elapsed: 0,
    timerStepMs: null, timerWhere: null, done: 0, total: 0, checks: {}, cells: {}, sceneCheck: null, warm: { cold: {}, steady: {}, setup: {}, fresh: false, n: null }, other: null, dirty: false };
}
S = freshState();

// ---------------------------------------------------------------- settings
function readSettings() {
  let a = +$('nFrom').value, b = +$('nTo').value; if (a > b) { const t = a; a = b; b = t; }
  const ns = []; for (let n = a; n <= b; n++) ns.push(n);
  const reps = +$('reps').value;
  return { ns, nFrom: a, nTo: b, minMs: +$('minMs').value, reps, scenarios: SHOW_ORDER.filter(id => $('sc-' + id).checked),
    productMax: +$('prodN').value, bodies: { B: +$('bodiesB').value, n: +$('bodiesN').value, seed: SEED }, warm: { n: +$('warmN').value }, coldReps: Math.min(reps, 5) };
}
function estimateSeconds(cfg) {
  let timings = 0;
  for (const scn of KERNEL) if (cfg.scenarios.includes(scn)) for (const n of cfg.ns) timings += CORE.variantsFor(scn, n).length;
  if (cfg.scenarios.includes('product')) for (const n of CORE.PRODUCT_NS) if (n <= cfg.productMax) timings += CORE.productVariantsFor(n).length;
  if (cfg.scenarios.includes('bodies')) timings += 7;
  if (cfg.scenarios.includes('alloc')) timings += 11;
  if (cfg.scenarios.includes('warm')) timings += 6;
  return timings * (cfg.reps + 3) * cfg.minMs / 1000;
}
function syncPresetButtons() {
  const mm = $('minMs').value, rp = $('reps').value;
  for (const k of Object.keys(PRESETS)) $('p-' + k).setAttribute('aria-pressed', String(PRESETS[k].minMs === mm && PRESETS[k].reps === rp));
}
function updateWarnings() {
  const cfg = readSettings(), w = $('warn-n'), msgs = [];
  if (cfg.nTo >= 9 && cfg.scenarios.some(s => KERNEL.includes(s))) msgs.push('n ≥ 9: direct needs 512 or 1024 sandwiches, so one call can take seconds and the range several minutes. If the page falls back to the main thread it freezes meanwhile; Stop acts between two timings.');
  if (cfg.productMax >= 12 && cfg.scenarios.includes('product')) msgs.push(cfg.productMax >= 14 ? 'Product up to n = 14: one bit-rule call is 268 million terms (several seconds, eight or more calls per timing), so this scenario alone can take minutes; the sign table is left out above n = 12 (268 MB).' : 'Product up to n = 12: one bit-rule call is 16.8 million terms (a few hundred ms) and the sign table is 16 MB; this scenario takes about a minute.');
  if (cfg.bodies.B >= 10000 && cfg.scenarios.includes('bodies') && cfg.bodies.n >= 4) msgs.push('10000 bodies at n = 4: one step of direct takes a good fraction of a second, so this is slow.');
  w.hidden = !msgs.length; w.replaceChildren(...msgs.map(m => h('p', null, m)));
  $('est').textContent = cfg.scenarios.length ? 'Rough time: at least ' + fmtDur(estimateSeconds(cfg)) + ' (larger n and larger scenes take longer).' : 'Tick at least one scenario.';
}

// ---------------------------------------------------------------- worker and main-thread fallback
const WORKER_GLUE = [
  'self.onmessage = function (ev) {',
  '  var m = ev.data;',
  "  if (m.type === 'timer') { self.postMessage({ type: 'timer', stepMs: LBCORE.timerStep() }); return; }",
  "  if (m.type !== 'run') return;",
  '  try { for (var _ of LBCORE.runJob(m.job, m.cfg, function (msg) { self.postMessage(msg); })) { } self.postMessage({ type: \'done\' }); }',
  "  catch (e) { self.postMessage({ type: 'error', message: String(e && e.message || e) }); }",
  '};',
  "self.postMessage({ type: 'ready' });",
].join('\n');
let blobUrl = null;
function getBlobUrl() { if (!blobUrl) blobUrl = URL.createObjectURL(new Blob([$('lb-core').textContent + '\n' + WORKER_GLUE], { type: 'text/javascript' })); return blobUrl; }
function spawnWorker() {
  return new Promise((resolve, reject) => {
    let w; try { w = new Worker(getBlobUrl()); } catch (e) { reject(e); return; }
    const timer = setTimeout(() => { try { w.terminate(); } catch (e) { } reject(new Error('it did not start within 5 s')); }, 5000);
    w.onerror = ev => { clearTimeout(timer); try { w.terminate(); } catch (e) { } reject(new Error(ev && ev.message ? ev.message : 'it could not be created')); };
    w.onmessage = ev => { if (ev.data && ev.data.type === 'ready') { clearTimeout(timer); w.onerror = null; w.onmessage = null; resolve(w); } };
  });
}
function askTimer(w) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(null), 3000);
    w.onmessage = ev => { if (ev.data && ev.data.type === 'timer') { clearTimeout(timer); w.onmessage = null; resolve(ev.data.stepMs); } };
    w.postMessage({ type: 'timer' });
  });
}
function runInWorker(w, job, cfg) {
  return new Promise((resolve, reject) => {
    S.worker = w;
    S.cancel = () => { try { w.terminate(); } catch (e) { } resolve('stopped'); };
    w.onmessage = ev => { if (S.worker !== w) return; const m = ev.data; if (m.type === 'done') resolve('done'); else if (m.type === 'error') reject(new Error(m.message)); else handle(m); };
    w.onerror = ev => { if (ev && ev.preventDefault) ev.preventDefault(); reject(new Error(ev && ev.message ? ev.message : 'the worker failed')); };
    w.postMessage({ type: 'run', job, cfg });
  });
}
function runOnMain(job, cfg) {
  return new Promise((resolve, reject) => {
    const gen = CORE.runJob(job, cfg, handle); let over = false;
    S.cancel = () => { if (over) return; over = true; try { gen.return(); } catch (e) { } resolve('stopped'); };
    const step = () => {
      if (over) return;
      if (S.stopFlag) { S.cancel(); return; }
      let r; try { r = gen.next(); } catch (e) { over = true; reject(e); return; }
      if (S.dirty) renderNow();
      if (r.done) { over = true; resolve('done'); } else setTimeout(step, 0);
    };
    setTimeout(step, 0);
  });
}

// ---------------------------------------------------------------- messages from the runners
let lastAnnounce = 0;
function announce(text, force) { const t = performance.now(); if (force || t - lastAnnounce > 4000) { $('status').textContent = text; lastAnnounce = t; } }
function handle(m) {
  switch (m.type) {
    case 'status': $('now').textContent = m.label; announce('Running: ' + Math.round(100 * S.done / Math.max(1, S.total)) + '% done. ' + m.label); break;
    case 'unit': S.done++; $('bar').value = 100 * S.done / Math.max(1, S.total); break;
    case 'check': (S.checks[m.scenario] = S.checks[m.scenario] || {})[m.detail.n] = m.detail; markDirty(); break;
    case 'sceneCheck': S.sceneCheck = m; markDirty(); break;
    case 'cell': { const c = S.cells[m.scenario] = S.cells[m.scenario] || {}; (c[m.key] = c[m.key] || {})[m.variant] = m.stats; markDirty(); break; }
    case 'cold': { const t = m.target; (S.warm.cold[t] = S.warm.cold[t] || []).push(m); markDirty(); break; }
    case 'steady': S.warm.steady[m.target] = m.stats; markDirty(); break;
  }
}
let renderTimer = 0;
function markDirty() { S.dirty = true; if (S.mode === 'worker' && !renderTimer) renderTimer = setTimeout(() => { renderTimer = 0; renderNow(); }, 120); }
function renderNow() { S.dirty = false; render(); }

// ---------------------------------------------------------------- run
function buildJobs(cfg) {
  const jobs = [];
  if (cfg.scenarios.includes('warm')) {
    jobs.push({ kind: 'check', scenario: 'warm', ns: [cfg.warm.n] });
    for (const t of CORE.WARM_TARGETS) for (let r = 1; r <= cfg.coldReps; r++) jobs.push({ kind: 'warm', target: t, rep: r, n: cfg.warm.n, steady: r === 1 });
  }
  for (const scn of KERNEL) if (cfg.scenarios.includes(scn)) jobs.push({ kind: 'kernel', scenario: scn });
  if (cfg.scenarios.includes('product')) jobs.push({ kind: 'product' });
  if (cfg.scenarios.includes('bodies')) jobs.push({ kind: 'bodies' });
  if (cfg.scenarios.includes('alloc')) jobs.push({ kind: 'alloc' });
  return jobs;
}
function syncButtons() {
  $('run').disabled = S.running; $('stop').disabled = !S.running;
  for (const el of $('form').querySelectorAll('select, input[type=checkbox], #p-quick, #p-careful')) el.disabled = S.running;
  const any = hasData(); $('dl-json').disabled = !any; $('dl-csv').disabled = !any; $('cp-text').disabled = !any;
  $('cmp-clear').disabled = !S.other;
}
function setMode() {
  $('mode').textContent = S.mode === 'worker' ? 'Mode: Web Worker (a fresh worker for each job; timing runs off the page’s main thread)'
    : S.mode === 'main' ? 'Mode: main thread, with setTimeout chunking (' + S.modeNote + ')' : 'Mode: not started';
}
async function run() {
  if (S.running) return;
  const cfg = readSettings();
  if (!cfg.scenarios.length) { $('est').textContent = 'Tick at least one scenario.'; return; }
  const other = S.other; S = freshState(); S.other = other;
  S.cfg = cfg; S.running = true; S.dateISO = new Date().toISOString(); S.t0 = performance.now();
  $('bar').value = 0; $('now').textContent = 'Starting…'; announce('Run started.', true); syncButtons(); render();
  let w = null;
  try {
    const forceMain = /(^|[#&,])main\b/.test(location.hash);
    if (forceMain) { S.mode = 'main'; S.modeNote = 'forced by #main in the address'; }
    else if (typeof Worker === 'undefined' || typeof Blob === 'undefined' || !window.URL || !URL.createObjectURL) { S.mode = 'main'; S.modeNote = 'this browser offers no Worker or Blob URL'; }
    else { try { w = await spawnWorker(); S.mode = 'worker'; } catch (e) { S.mode = 'main'; S.modeNote = 'a Worker could not be started from a Blob URL here: ' + e.message; } }
    if (S.stopFlag) throw new Error('__stopped__');
    if (S.mode === 'worker') { S.timerStepMs = await askTimer(w); S.timerWhere = 'worker'; }
    else { S.timerStepMs = CORE.timerStep(); S.timerWhere = 'main thread'; cfg.coldReps = 1; }
    S.warm.fresh = S.mode === 'worker'; S.warm.n = cfg.warm.n;
    setMode(); refreshMachine();
    const jobs = buildJobs(cfg); S.total = jobs.reduce((s, j) => s + CORE.unitsFor(j, cfg), 0);
    for (let i = 0; i < jobs.length && !S.stopFlag; i++) {
      if (S.mode === 'worker') { try { if (!w) w = await spawnWorker(); } catch (e) { S.mode = 'main'; S.modeNote = 'the worker could not be restarted (' + e.message + '); the remaining jobs ran on the main thread'; S.warm.fresh = false; setMode(); } }
      if (S.stopFlag) break;
      if (S.mode === 'worker') { await runInWorker(w, jobs[i], cfg); try { w.terminate(); } catch (e) { } w = null; }
      else await runOnMain(jobs[i], cfg);
    }
    S.stopped = S.stopFlag;
  } catch (e) { if (e.message === '__stopped__') S.stopped = true; else { S.error = e.message; } }
  finally {
    if (w) { try { w.terminate(); } catch (e) { } }
    if (S.worker) { try { S.worker.terminate(); } catch (e) { } S.worker = null; }
    S.cancel = null; S.running = false; S.elapsed = (performance.now() - S.t0) / 1000;
    $('bar').value = S.stopped || S.error ? $('bar').value : 100;
    const msg = S.error ? 'Run aborted: ' + S.error : S.stopped ? 'Stopped after ' + fmtDur(S.elapsed) + '. Partial results are shown.' : 'Finished in ' + fmtDur(S.elapsed) + '.';
    $('now').textContent = msg; announce(msg, true); syncButtons(); renderNow(); refreshMachine();
  }
}
function stop() { if (!S.running) return; S.stopFlag = true; $('now').textContent = S.mode === 'main' ? 'Stopping after the current timing…' : 'Stopping…'; if (S.cancel) S.cancel(); }

// ---------------------------------------------------------------- results: tables
const keysOf = scn => {
  const ks = Object.keys(S.cells[scn] || {});
  return scn === 'alloc' ? ALLOC_ORDER.filter(k => ks.includes(k)) : scn === 'bodies' ? ks : ks.map(Number).sort((a, b) => a - b);
};
const cellOf = (scn, k, v) => ((S.cells[scn] || {})[k] || {})[v];
function applicable(scn, k, v) { return KERNEL.includes(scn) ? CORE.variantsFor(scn, +k).includes(v) : scn === 'product' ? CORE.productVariantsFor(+k).includes(v) : true; }
function spreadLine(st) { const sp = spreadOf(st); return h('span', { class: 'r' }, 'spread ' + fmtPct(sp), sp > 0.15 ? ' ⚠ noisy' : ''); }

function timingsTable(scn) {
  const sc = SC[scn], keys = keysOf(scn); if (!keys.length) return null;
  const pending = S.running && S.cfg && S.cfg.scenarios.includes(scn);
  const vs = sc.variants.filter(v => pending || keys.some(k => cellOf(scn, k, v.id)));
  const thead = h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, h('th', { scope: 'col', role: 'columnheader' }, sc.keyHead), ...vs.map(v => h('th', { scope: 'col', role: 'columnheader', class: 'num' }, v.short))));
  const tbody = h('tbody', { role: 'rowgroup' }, ...keys.map(k => h('tr', { role: 'row' },
    h('th', { scope: 'row', role: 'rowheader' }, sc.keyLabel(k), sc.keySub ? h('span', { class: 'sub' }, sc.keySub(k)) : null),
    ...vs.map(v => {
      const st = cellOf(scn, k, v.id);
      if (!st) return h('td', { class: 'num', role: 'cell', 'data-label': v.short }, !applicable(scn, k, v.id) ? '–' : pending ? '…' : '–');
      return h('td', { class: 'num', role: 'cell', 'data-label': v.short }, h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtT(st.med)), h('span', { class: 'r' }, fmtRange(st)), spreadLine(st)));
    }))));
  return h('table', { class: 'stack', role: 'table' }, h('caption', { class: 'sr' }, sc.title + ': time per call, median and fastest to slowest batch'), thead, tbody);
}
function bodiesTable() {
  const sc = SC.bodies, c = (S.cells.bodies || {}).scene; if (!c) return null;
  const B = S.cfg.bodies.B, rate = ns => B / (ns * 1e-9);
  const rows = sc.variants.filter(v => c[v.id]).map(v => { const st = c[v.id]; return h('tr', { role: 'row' },
    h('th', { scope: 'row', role: 'rowheader' }, v.short),
    h('td', { class: 'num', role: 'cell', 'data-label': 'ms per scene step' }, h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtT(st.med)), h('span', { class: 'r' }, fmtRange(st)))),
    h('td', { class: 'num', role: 'cell', 'data-label': 'bodies per second' }, h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtRate(rate(st.med))), h('span', { class: 'r' }, fmtRate(rate(st.max)).replace(' bodies/s', '') + '–' + fmtRate(rate(st.min))))),
    h('td', { class: 'num', role: 'cell', 'data-label': 'spread' }, h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtPct(spreadOf(st))), spreadOf(st) > 0.15 ? noisyTag() : null))); });
  return h('table', { class: 'stack', role: 'table' }, h('caption', { class: 'sr' }, 'Many bodies: time per scene step of ' + B + ' bodies at n = ' + S.cfg.bodies.n),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, h('th', { scope: 'col', role: 'columnheader' }, 'B = ' + B + ', n = ' + S.cfg.bodies.n), h('th', { scope: 'col', role: 'columnheader', class: 'num' }, 'time per scene step (median, fastest–slowest)'), h('th', { scope: 'col', role: 'columnheader', class: 'num' }, 'bodies per second'), h('th', { scope: 'col', role: 'columnheader', class: 'num' }, 'spread'))),
    h('tbody', { role: 'rowgroup' }, ...rows));
}
function compRows(scn, comp) {
  const out = [];
  for (const k of keysOf(scn)) { if (comp.keys && !comp.keys.includes(k)) continue; const j = judge(cellOf(scn, k, comp.base), cellOf(scn, k, comp.cand)); if (j) out.push({ key: k, j }); }
  return out;
}
// the keys at which both timings of a comparison exist but cannot be judged (a median of 0: a batch shorter than one timer step, as after a calibration interrupted by the system).
// They are shown in the table as "not judged" instead of being left out, so that a comparison never disappears silently; the banner counts them.
function unjudgedKeys(scn, comp) { return keysOf(scn).filter(k => !(comp.keys && !comp.keys.includes(k)) && cellOf(scn, k, comp.base) && cellOf(scn, k, comp.cand) && !judge(cellOf(scn, k, comp.base), cellOf(scn, k, comp.cand))); }
const NOT_JUDGED = 'not judged: a median of 0, i.e. batches shorter than one timer step (the calibration was interrupted); run again';
function cmpTable(scn, comps) {
  const sc = SC[scn]; let any = false;
  const table = h('table', { class: 'cmp', role: 'table' }, h('caption', { class: 'sr' }, sc.title + ': the claimed ratio and its verdict'),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, h('th', { scope: 'col', role: 'columnheader' }, sc.keyHead === 'What' ? 'Case' : sc.keyHead), h('th', { scope: 'col', role: 'columnheader' }, 'Result'), h('th', { scope: 'col', role: 'columnheader' }, 'Verdict'), h('th', { scope: 'col', role: 'columnheader' }, 'Spread'))));
  for (const c of comps) {
    const rows = compRows(scn, c), un = unjudgedKeys(scn, c); if (!rows.length && !un.length) continue; any = true;
    table.append(h('tbody', { role: 'rowgroup' }, h('tr', { class: 'grp', role: 'row' }, h('th', { colspan: 4, scope: 'colgroup', role: 'columnheader' }, c.label, ROLE[scn] && ROLE[scn].head === c.id ? h('span', { class: 'keytag' }, 'key result') : null, h('span', { class: 'sub' }, c.note))),
      ...rows.map(r => h('tr', { role: 'row' }, h('th', { scope: 'row', role: 'rowheader' }, sc.keyShort(r.key)), h('td', { role: 'cell' }, claimText(c.name, r.j)), h('td', { role: 'cell' }, chip(r.j.verdict)), h('td', { role: 'cell' }, fmtPct(r.j.spread), r.j.noisy ? [' ', noisyTag()] : null))),
      ...un.map(k => h('tr', { role: 'row', class: 'unjudged' }, h('th', { scope: 'row', role: 'rowheader' }, sc.keyShort(k)), h('td', { role: 'cell', colspan: 3 }, NOT_JUDGED)))));
  }
  return any ? table : null;
}
// the key comparison of the scenario is shown; the other comparisons fold away
function compTable(scn) {
  const sc = SC[scn], head = ROLE[scn] && ROLE[scn].head, key = sc.comps.filter(c => c.id === head), rest = sc.comps.filter(c => c.id !== head);
  const a = cmpTable(scn, key), b = rest.length ? cmpTable(scn, rest) : null; if (!a && !b) return null;
  return h('div', null, a, b ? h('details', { class: 'fold more' }, h('summary', null, 'More comparisons'), b) : null);
}

// the cold-start table: per target, the median over the cold repeats (and the range), against the steady state.
// A time shorter than the timer step cannot be read: totals below 2 steps give only an upper bound ('bound'), below 10 steps an approximation ('approx').
function quant(totalsMs, cnt, step) {
  const med = median(totalsMs), s = summ(totalsMs.map(t => t / cnt * 1e6));
  return Object.assign(s, { kind: step && med < 2 * step ? 'bound' : step && med < 10 * step ? 'approx' : 'ok', bound: (med + step) / cnt * 1e6, runs: totalsMs.length });
}
function warmData(t) {
  const colds = S.warm.cold[t] || [], st = S.warm.steady[t]; if (!colds.length) return null;
  const step = S.timerStepMs || 0;
  const r = { runs: colds.length, call1: quant(colds.map(c => c.call1), 1, step), first10: quant(colds.map(c => c.call1 + c.t2_10), 10, step), b11: quant(colds.map(c => c.t11_100), 90, step), b101: quant(colds.map(c => c.t101_1000), 900, step), setup: summ(colds.map(c => c.setupMs)), steady: st || null };
  if (st) { r.ratio1 = r.call1.kind === 'bound' ? null : r.call1.med / st.med; r.ratio10 = r.first10.kind === 'bound' ? null : r.first10.med / st.med; }
  return r;
}
const fmtQ = q => q.kind === 'bound' ? '< ' + fmtT(q.bound) : (q.kind === 'approx' ? '~' : '') + fmtT(q.med);
function warmTable() {
  const rows = CORE.WARM_TARGETS.map(t => [t, warmData(t)]).filter(x => x[1]); if (!rows.length) return null;
  const cell = (lab, q) => h('td', { class: 'num', role: 'cell', 'data-label': lab }, h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtQ(q)), h('span', { class: 'r' }, q.kind === 'bound' ? 'below timer resolution' : q.runs === 1 ? '' : fmtRange(q))));
  const sCell = (lab, st) => h('td', { class: 'num', role: 'cell', 'data-label': lab }, st ? h('div', { class: 'cellbody' }, h('span', { class: 'v' }, fmtT(st.med)), h('span', { class: 'r' }, fmtRange(st))) : '…');
  const rCell = (lab, ratio, q) => h('td', { class: 'num', role: 'cell', 'data-label': lab }, ratio != null ? h('div', { class: 'cellbody' }, h('span', { class: 'v' }, (q.kind === 'approx' ? '~' : '') + fmtRatio(ratio))) : q.kind === 'bound' ? 'n/a' : '…');
  const heads = ['target', 'call 1', 'calls 1–10 (mean)', 'calls 11–100 (mean)', 'calls 101–1000 (mean)', 'steady state', 'call 1 ÷ steady', 'first 10 ÷ steady'];
  const label = { direct: 'direct vertices', frame: 'frame vertices', scan: 'scan (table given)', bits: 'sign bits (frame given)', hull: 'hull (points given)', zono: 'zonogon (edges given)' };
  return h('table', { class: 'stack', role: 'table' }, h('caption', { class: 'sr' }, 'Cold start against steady state, n = ' + S.warm.n),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, ...heads.map((t, i) => h('th', { scope: 'col', role: 'columnheader', class: i ? 'num' : null }, t)))),
    h('tbody', { role: 'rowgroup' }, ...rows.map(([t, d]) => h('tr', { role: 'row' }, h('th', { scope: 'row', role: 'rowheader' }, label[t], h('span', { class: 'sub' }, d.runs + ' cold run' + (d.runs > 1 ? 's' : ''))),
      cell(heads[1], d.call1), cell(heads[2], d.first10), cell(heads[3], d.b11), cell(heads[4], d.b101), sCell(heads[5], d.steady), rCell(heads[6], d.ratio1, d.call1), rCell(heads[7], d.ratio10, d.first10)))));
}

// ---------------------------------------------------------------- results: the chart (inline SVG, log scale, bars from the 1x line)
function chartSVG(id, W, cats, series) {
  const NS = 'http://www.w3.org/2000/svg', el = (t, a, ...k) => { const e = document.createElementNS(NS, t); for (const x of Object.keys(a || {})) e.setAttribute(x, a[x]); for (const c of k) if (c != null) e.append(c.nodeType ? c : document.createTextNode(c)); return e; };
  W = Math.max(280, Math.floor(W)); const H = 250, ml = 48, mr = 8, mt = 12, mb = 46, pw = W - ml - mr, ph = H - mt - mb, nC = cats.length, nS = series.length, sw = pw / nC, gap = 2;
  const ratios = series.flatMap(s => s.pts.filter(Boolean).map(p => p.ratio)); if (!ratios.length) return null;
  const bw = Math.max(3, Math.min(24, (sw - 6 - gap * (nS - 1)) / nS)), rot = bw < 30, padPx = rot ? 36 : 20;
  let l0 = Math.log2(Math.min(1, ...ratios)), l1 = Math.log2(Math.max(1, ...ratios)); if (l1 - l0 < 2) { l0 = Math.min(l0, -1); l1 = Math.max(l1, 1); }
  const ppl = (ph - 2 * padPx) / (l1 - l0), yMin = l0 - padPx / ppl, yMax = l1 + padPx / ppl, Y = r => mt + (yMax - Math.log2(r)) / (yMax - yMin) * ph;
  const svg = el('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, role: 'img', 'aria-label': 'Bar chart on a log scale of the claimed ratio against n; the same numbers are in the table below.' });
  svg.append(el('defs', {}, el('pattern', { id: 'hatch-' + id, width: 6, height: 6, patternUnits: 'userSpaceOnUse', patternTransform: 'rotate(45)' }, el('line', { x1: 0, y1: 0, x2: 0, y2: 6, style: 'stroke:var(--bg);stroke-width:2.5' }))));
  let kmin = Math.ceil(yMin), kmax = Math.floor(yMax), step = 1; while ((kmax - kmin) / step > 7) step++;
  for (let k = Math.ceil(kmin / step) * step; k <= kmax; k += step) {
    const y = Y(Math.pow(2, k)), v = Math.pow(2, k);
    if (k !== 0) svg.append(el('line', { class: 'grid', x1: ml, x2: W - mr, y1: y, y2: y }));
    svg.append(el('text', { class: 'tick', x: ml - 6, y: y + 4, 'text-anchor': 'end' }, (v >= 1 ? v : +v.toPrecision(2)) + 'x'));
  }
  svg.append(el('line', { class: 'one', x1: ml, x2: W - mr, y1: Y(1), y2: Y(1) }));
  const rr = 4;
  series.forEach((s, si) => cats.forEach((c, ci) => {
    const p = s.pts[ci]; if (!p) return;
    const x = ml + ci * sw + (sw - (nS * bw + gap * (nS - 1))) / 2 + si * (bw + gap), y1 = Y(1), y2 = Y(p.ratio), up = y2 < y1, tip = up ? Math.min(y2, y1 - 2) : Math.max(y2, y1 + 2), r = Math.min(rr, bw / 2, Math.abs(tip - y1));
    const d = up ? 'M' + x + ',' + y1 + 'V' + (tip + r) + 'Q' + x + ',' + tip + ' ' + (x + r) + ',' + tip + 'H' + (x + bw - r) + 'Q' + (x + bw) + ',' + tip + ' ' + (x + bw) + ',' + (tip + r) + 'V' + y1 + 'Z'
      : 'M' + x + ',' + y1 + 'V' + (tip - r) + 'Q' + x + ',' + tip + ' ' + (x + r) + ',' + tip + 'H' + (x + bw - r) + 'Q' + (x + bw) + ',' + tip + ' ' + (x + bw) + ',' + (tip - r) + 'V' + y1 + 'Z';
    const tt = 'n = ' + c + ', ' + s.name + ': ' + claimText(s.cand, p) + ' (' + WORD[p.verdict] + '), spread ' + fmtPct(p.spread);
    const g = el('g', {}, el('title', {}, tt), el('path', { d, class: 'b-' + p.verdict }));
    if (s.hatch) g.append(el('path', { d, fill: 'url(#hatch-' + id + ')' }));
    const label = fmtRatio(p.ratio) + (p.noisy ? '*' : ''), cx = x + bw / 2;
    g.append(rot ? el('text', { class: 'vl', transform: 'translate(' + (cx + 4) + ',' + (up ? tip - 4 : tip + 4) + ') rotate(-90)', 'text-anchor': up ? 'start' : 'end' }, label)
      : el('text', { class: 'vl', x: cx, y: up ? tip - 4 : tip + 13, 'text-anchor': 'middle' }, label));
    svg.append(g);
  }));
  cats.forEach((c, ci) => svg.append(el('text', { class: 'tick', x: ml + ci * sw + sw / 2, y: H - mb + 16, 'text-anchor': 'middle' }, String(c))));
  svg.append(el('text', { class: 'tick', x: ml + pw / 2, y: H - 6, 'text-anchor': 'middle' }, 'n (dimension of the cube)'));
  svg.append(el('text', { class: 'tick', transform: 'translate(11,' + (mt + ph / 2) + ') rotate(-90)', 'text-anchor': 'middle' }, 'relative speed, log scale'));
  return svg;
}
function drawChart(scn, host, legend) {
  const sc = SC[scn]; host.replaceChildren(); legend.replaceChildren(); if (!sc.chart) return;
  const comps = sc.chart.series.map(([cid, name]) => ({ comp: sc.comps.find(c => c.id === cid), name }));
  const dataCats = [...new Set(comps.flatMap(c => compRows(scn, c.comp).map(r => r.key)))]; if (!dataCats.length) return;
  const planned = S.running && S.cfg ? (scn === 'product' ? CORE.PRODUCT_NS.filter(n => n <= S.cfg.productMax) : S.cfg.ns.filter(n => scn !== 'outline' || n >= 2)) : [];                  // while running, every n of the plan has its slot, so the chart does not jump
  const cats = [...new Set([...planned, ...dataCats])].sort((a, b) => a - b);
  const series = comps.map((c, i) => { const rows = compRows(scn, c.comp); return { name: c.name, cand: c.comp.name, hatch: comps.length > 1 && i === 1, pts: cats.map(k => { const r = rows.find(x => x.key === k); return r ? r.j : null; }) }; });
  const svg = chartSVG(scn, host.clientWidth || 600, cats, series); if (!svg) return;
  host.append(h('div', { class: 'small', style: 'font-weight:600;margin-bottom:2px' }, sc.chart.title), svg);
  const key = (cls, txt) => h('span', null, h('i', { class: 'sw ' + cls }), txt);
  legend.append(key('faster', GLYPH.faster + ' faster'), key('equal', GLYPH.equal + ' about equal within noise'), key('slower', GLYPH.slower + ' slower'));
  if (series.length > 1) legend.append(key('solid', 'solid: ' + series[0].name), key('hatch', 'hatched: ' + series[1].name));
  legend.append(h('span', null, '* spread above 15%: noisy'));
}

// ---------------------------------------------------------------- results: assembly
const SK = {};
function buildSkeleton() {
  for (const id of SHOW_ORDER) {
    const sc = SC[id], role = ROLE[id], p = {};
    p.sec = h('section', { class: 'res', id: 'res-' + id, 'aria-labelledby': 'h-res-' + id, hidden: true });
    p.check = h('div', { class: 'check' }); p.chart = h('div', { class: 'chartbox' }); p.legend = h('div', { class: 'legend' });
    p.t = h('div', { class: 'tablewrap', role: 'region', tabindex: '0', 'aria-label': sc.title + ': timings' }); p.c = h('div', { class: 'tablewrap', role: 'region', tabindex: '0', 'aria-label': sc.title + ': ratios and verdicts' }); p.notes = h('div');
    const open = id === 'bodies' || id === 'warm';                         // here the timings are the result; elsewhere the ratios are, and the timings fold away
    p.tbox = open ? p.t : h('details', { class: 'fold alltimes' }, h('summary', null, 'All timings (median, fastest–slowest, spread)'), p.t);
    p.sec.append(h('h3', { id: 'h-res-' + id }, sc.title), h('p', { class: 'lead' }, sc.lead),
      ...(role ? [h('div', { class: 'rolebox' }, h('div', null, h('span', { class: 'role std' }, 'standard'), role.std), role.alsoStd ? h('div', null, h('span', { class: 'role std' }, 'standard'), role.alsoStd) : null, h('div', null, h('span', { class: 'role ours' }, 'ours'), role.ours))] : []),
      p.check, p.chart, p.legend, p.c, p.tbox, h('details', { class: 'fold method' }, h('summary', null, 'How it is timed'), h('p', { class: 'what' }, sc.what)), p.notes);
    $('res').append(p.sec); SK[id] = p;
  }
}
function checkLine(id) {
  const cm = S.checks[id] || {}, ds = Object.values(cm), want = id === 'warm' ? [S.warm.n || (S.cfg && S.cfg.warm.n)] : id === 'bodies' ? [S.cfg.bodies.n] : id === 'alloc' ? [3] : id === 'product' ? CORE.PRODUCT_NS.filter(n => n <= S.cfg.productMax) : S.cfg.ns;
  const bad = ds.filter(d => !d.ok);
  if (bad.length) return h('div', { class: 'check fail' }, 'Check FAILED at n = ' + bad.map(d => d.n).join(', ') + ': the variants gave different answers, so nothing was timed for them.');
  if (ds.length < want.length) return h('div', { class: 'check' }, S.running ? 'Checking the answers before the timings…' : 'Check not completed.');
  const ns = ds.map(d => d.n).sort((a, b) => a - b), range = ns[0] + (ns.length > 1 ? '–' + ns[ns.length - 1] : '');
  let txt;
  if (id === 'product') txt = 'Checked: the bit rule, the sign table, the matrix route (also with buffers allocated once)' + (ns.some(n => n >= 10) ? ' and the 16 × 16 blocks' : '') + ' gave the same integer coefficients, compared exactly, on the timed inputs and a second pair (n = ' + range + ').';
  else if (id === 'alloc') txt = 'Checked: the three product functions agree with the engine’s product within 1e-12 (largest difference ' + ds[0].maxErr.toExponential(1) + ').';
  else txt = 'Checked: all variants agree within 1e-9 relative (n = ' + range + ')' + (id === 'warm' ? ', in a separate worker so the timed code stays cold' : '') + '.';
  if (id === 'bodies' && S.sceneCheck) txt += ' On the scene: ' + S.sceneCheck.B + ' bodies, largest relative difference ' + S.sceneCheck.maxErr.toExponential(1) + ', every deepest vertex agreed' + (S.sceneCheck.ties ? ' (' + S.sceneCheck.ties + ' exact ties)' : '') + '.';
  return h('div', { class: 'check ok' }, txt);
}
function fill(el, box, node) { el.replaceChildren(...(node ? [node] : [])); box.hidden = !node; }
function render() {
  const cfg = S.cfg, any = hasData() || S.running;
  $('empty').hidden = any; $('howto').hidden = !hasData();
  for (const id of SHOW_ORDER) {
    const p = SK[id], on = cfg && cfg.scenarios.includes(id) && (S.running || S.checks[id] || S.cells[id] || (id === 'warm' && Object.keys(S.warm.cold).length));
    p.sec.hidden = !on; if (!on) continue;
    const cl = checkLine(id); p.check.replaceWith(cl); p.check = cl;
    const sc = SC[id];
    if (sc.special === 'warm') {
      const t = warmTable(); fill(p.t, p.tbox, t); fill(p.c, p.c, null); p.chart.replaceChildren(); p.legend.replaceChildren();
      const notes = [], step = S.timerStepMs || 0;
      if (t) {
        notes.push(h('p', { class: 'small muted' }, 'Time per call: median of the cold runs, fastest–slowest below. Steady state: the median batch of a hot loop. The set-up before the first call took ' + fmtT(Math.max(...CORE.WARM_TARGETS.map(x => (warmData(x) || { setup: { med: 0 } }).setup.med)) * 1e6) + ' at most per run and is not counted.'));
        if (CORE.WARM_TARGETS.some(x => { const d = warmData(x); return d && [d.call1, d.first10, d.b11, d.b101].some(q => q.kind !== 'ok'); })) notes.push(h('p', { class: 'note warn small' }, 'Timer step about ' + fmtT(step * 1e6) + '. A time under 10 steps is marked ~ (indicative); one under 2 steps cannot be read and is shown as an upper bound, “< x”, with n/a for its ratio. The block means (calls 11–100 and 101–1000) are more reliable than call 1.'));
        notes.push(S.warm.fresh ? h('p', { class: 'small muted' }, 'Each run started in a fresh worker, so these are cold starts of this browser’s JavaScript engine; the range shows how much runs vary.')
          : h('p', { class: 'note warn small' }, 'Main-thread mode: the code was already used by the check and by earlier runs, so this is not a cold start and the ratios understate it. Reload in a browser where a Worker starts.'));
      }
      p.notes.replaceChildren(...notes); continue;
    }
    const t = sc.special === 'bodies' ? bodiesTable() : timingsTable(id), c = compTable(id);
    fill(p.t, p.tbox, t); fill(p.c, p.c, c);
    drawChart(id, p.chart, p.legend);
    p.notes.replaceChildren(...(id === 'product' && c ? [h('p', { class: 'small muted' }, 'The bit rule costs 4^n = 16^k terms, the matrix route 8^k multiplications (2^(n/2) times fewer) plus k·4^k additions each way; counting operations only, the route is cheaper from n = 6 and about even at n = 4. As written the route also allocates seven Float64Arrays per call, and at small n that allocation can be most of its time: compare “matrix route, whole” with “buffers allocated once” and with “the route’s 7 allocations alone” before reading a small-n loss as a cost of the conversion. The sign table (4^n entries, 16 MB at n = 12) is slowed by the cache at large n. Sparse multivectors are another case.')] : id === 'alloc' && c ? [h('p', { class: 'small muted' }, 'Allocation cost depends on the engine and its garbage collector; a result that differs from node 22 is a result, not an error.')] : []));
  }
  renderBanner(); renderGlance(); renderCompare(); $('textOut').value = hasData() ? buildText() : ''; syncButtons();
}
function allJudged() {
  const out = [];
  for (const id of SHOW_ORDER) if (SC[id].comps) for (const c of SC[id].comps) for (const r of compRows(id, c)) out.push(r.j);
  return out;
}
// the quantisation of one batch (one timer step against the batch length, at most) said honestly against the floor of the verdict. Rule: below a fifth of the floor
// (1%) it is "small next to" it; from there up to the floor "comparable to" it; at the floor or above "as large as or larger than" it, as with a 1 ms timer and 20 ms batches (5.0%).
const quantWord = q => q < VERDICT_FLOOR / 5 ? 'small next to' : q < VERDICT_FLOOR ? 'comparable to' : 'as large as or larger than';
function renderBanner() {
  const b = [], js = allJudged();
  if (S.error) b.push(h('div', { class: 'note bad', role: 'alert' }, 'Run aborted: ' + S.error));
  if (S.stopped) b.push(h('div', { class: 'note warn' }, 'Stopped early: the tables hold what had been timed by then.'));
  const nz = js.filter(j => j.noisy).length;
  if (nz) b.push(h('div', { class: 'note warn' }, '⚠ Noisy: ' + nz + ' of ' + js.length + ' comparisons have a spread above 15%. Repeat with Careful, close other tabs and plug in; verdicts on noisy rows are weak.'));
  const nu = SHOW_ORDER.reduce((a, id) => a + (SC[id].comps || []).reduce((b, c) => b + unjudgedKeys(id, c).length, 0), 0);
  if (nu) b.push(h('div', { class: 'note warn' }, nu + ' comparison' + (nu > 1 ? 's were' : ' was') + ' not judged: a timing with a median of 0 (its batches were shorter than one timer step, as when the calibration is interrupted). Run again, with Careful if it repeats.'));
  const st = S.timerStepMs, minMs = S.cfg ? S.cfg.minMs : 20;
  if (S.timerWhere && st == null) b.push(h('div', { class: 'note warn' }, 'The timer did not tick within 100 ms in the ' + S.timerWhere + ': it is very coarse. Batches last at least ' + minMs + ' ms, so batch timings are usable but single calls are not.'));
  else if (st != null && st > 0.005) { const q = st / minMs; b.push(h('div', { class: 'note warn' }, 'Coarse timer: performance.now() advances in steps of about ' + fmtT(st * 1e6) + ' (' + S.timerWhere + '). A batch of at least ' + minMs + ' ms is quantised by up to ' + (100 * q).toFixed(1) + '%, ' + quantWord(q) + ' the ' + Math.round(100 * VERDICT_FLOOR) + '% floor of the verdict' + (q >= VERDICT_FLOOR / 5 && minMs < 200 ? ' (Careful, with 200 ms batches, brings it to ' + (100 * st / 200).toFixed(1) + '%)' : '') + '; single-call times in the warm-up are only indicative.')); }
  $('banner').replaceChildren(...b);
}

// ---------------------------------------------------------------- results: at a glance (ours against the standard)
// Seen from "ours": the ratio is the standard's time divided by ours; the verdict is turned around when the claim of the comparison was about the standard (the product).
function oursView(role, j) {
  if (role.candIs === 'ours') return { ratio: j.ratio, verdict: j.verdict };
  return { ratio: 1 / j.ratio, verdict: j.verdict === 'faster' ? 'slower' : j.verdict === 'slower' ? 'faster' : 'equal' };
}
const magnitude = o => o.verdict === 'slower' ? 1 / o.ratio : o.ratio;                      // always >= 1 for faster and slower: "3.3x slower" rather than "0.30x"
function whereText(id, key) {
  if (KERNEL.includes(id) || id === 'product') return 'at n = ' + key;
  if (id === 'bodies') return 'for ' + S.cfg.bodies.B + ' bodies at n = ' + S.cfg.bodies.n;
  return key === 'loop' ? 'in the sandwich-like loop' : /^a\d+$/.test(key) ? 'at ' + key.slice(1) + ' doubles' : String(key);
}
function runsOf(id, seen) {
  if (!(KERNEL.includes(id) || id === 'product') || seen.length < 2) return null;
  const runs = []; for (const r of seen) { const last = runs[runs.length - 1]; if (last && last.v === r.o.verdict) last.to = r.key; else runs.push({ v: r.o.verdict, from: r.key, to: r.key }); }
  return runs;
}
function runsText(runs, word = { faster: 'ours faster', slower: 'standard faster', equal: 'about equal' }) {
  if (!runs) return null;
  const span = r => r.from === r.to ? 'n = ' + r.from : 'n = ' + r.from + '–' + r.to;
  if (runs.length === 1) return word[runs[0].v] + ' at every n timed (' + span(runs[0]).slice(4) + ')';
  if (runs.length > 3) return 'mixed: see the table below';
  return runs.map(r => word[r.v] + ' at ' + span(r)).join('; ');
}
// one row per job (kind 'ours': ours against the standard), and after its job each comparison of two standard methods (kind 'std', from STD_PAIRS), which the tally of ours leaves out
function glanceRows() {
  const out = [];
  for (const id of SHOW_ORDER) {
    const role = ROLE[id]; if (!role) continue;
    const comp = SC[id].comps.find(c => c.id === role.head), rows = comp ? compRows(id, comp) : [];
    if (rows.length) {
      const seen = rows.map(r => ({ key: r.key, j: r.j, o: oursView(role, r.j) }));
      const pick = (role.pick && seen.find(r => r.key === role.pick)) || seen[seen.length - 1];
      out.push({ id, kind: 'ours', role, pick, seen, where: whereText(id, pick.key), runs: runsText(runsOf(id, seen)) });
    }
    for (const sp of STD_PAIRS.filter(p => p.id === id)) {
      const c = SC[id].comps.find(x => x.id === sp.comp), rs = c ? compRows(id, c) : []; if (!rs.length) continue;
      const seen = rs.map(r => ({ key: r.key, j: r.j, o: { ratio: r.j.ratio, verdict: r.j.verdict } })), pick = seen[seen.length - 1];
      out.push({ id, kind: 'std', pair: sp, role: { job: sp.job, doing: sp.doing, std: sp.std, stdShort: sp.stdShort, ours: null, oursShort: sp.candShort }, pick, seen, where: whereText(id, pick.key),
        runs: runsText(runsOf(id, seen), { faster: sp.candShort + ' faster', slower: sp.stdShort + ' faster', equal: 'about equal' }) });
    }
  }
  return out;
}
const stdPairText = r => { const p = r.pair, o = r.pick.o; return (o.verdict === 'equal' ? p.candShort + ' and ' + p.stdShort + ' (both standard) are about equal' : o.verdict === 'faster' ? p.candShort + ' (standard) is ' + fmtRatio(o.ratio) + ' faster than ' + p.stdShort + ' (standard)' : p.stdShort + ' (standard) is ' + fmtRatio(1 / o.ratio) + ' faster than ' + p.candShort + ' (standard)') + ' for ' + p.doing + ', ' + r.where + '.' + (r.pick.j.noisy ? ' ⚠ noisy.' : ''); };
function glanceLines(all) {
  const rows = all.filter(r => r.kind === 'ours'), L = {}, wins = rows.filter(r => r.pick.o.verdict === 'faster'), quiet = wins.filter(r => !r.pick.j.noisy);
  const best = (quiet.length ? quiet : wins).slice().sort((a, b) => b.pick.o.ratio - a.pick.o.ratio)[0];
  L.best = best ? best.role.oursShort + ' (ours) is ' + fmtRatio(best.pick.o.ratio) + ' faster than ' + best.role.stdShort + ' (standard) for ' + best.role.doing + ', ' + best.where + '.' + (best.pick.j.noisy ? ' ⚠ noisy.' : '') : 'No job is clearly faster with ours on this run.';
  const cnt3 = v => rows.filter(r => r.pick.o.verdict === v).length, parts = [['faster', 'faster in'], ['equal', 'about equal in'], ['slower', 'slower in']].filter(([v]) => cnt3(v)).map(([v, w]) => w + ' ' + cnt3(v));
  L.tally = rows.length ? rows.length + ' job' + (rows.length > 1 ? 's' : '') + ' timed, at the size shown: ours is ' + parts.join(', ').replace(/, ([^,]*)$/, ' and $1') + '.' : 'No comparison of ours against the standard has been timed yet.';
  L.loses = rows.filter(r => r.pick.o.verdict === 'slower').map(r => r.role.stdShort + ' (standard) is ' + fmtRatio(magnitude(r.pick.o)) + ' faster than ' + r.role.oursShort + ' (ours) for ' + r.role.doing + ', ' + r.where + '.' + (r.pick.j.noisy ? ' ⚠ noisy.' : ''));
  L.std = all.filter(r => r.kind === 'std').map(stdPairText);
  const ids = Object.keys(S.checks), bad = ids.filter(id => Object.values(S.checks[id]).some(d => !d.ok));
  L.checked = !ids.length ? null : bad.length ? 'Check FAILED in ' + bad.join(', ') + ': nothing was timed for those.' : 'Before any timing, the methods agreed in ' + ids.length + ' of ' + ids.length + ' scenarios checked: within 1e-9 relative (the product kernels exactly).';
  L.warm = null;
  const rs = CORE.WARM_TARGETS.map(t => warmData(t)).filter(d => d && d.ratio1 != null).map(d => d.ratio1);
  if (rs.length) L.warm = 'Cold start (not a comparison): the first call took up to ' + fmtRatio(Math.max(...rs)) + ' its steady-state time.';
  return L;
}
function renderGlance() {
  const rows = hasData() ? glanceRows() : [], box = $('glance'); box.hidden = !rows.length; if (!rows.length) return;
  const L = glanceLines(rows), ps = [];
  if (OUR_SENTENCE) ps.push(h('p', { class: 'position' }, OUR_SENTENCE));
  ps.push(h('p', { class: 'best' }, h('b', null, 'Best result on this run: '), L.best));
  ps.push(h('p', null, L.tally + (S.running ? ' The run is not finished: these are partial results.' : '')));
  for (const t of L.loses) ps.push(h('p', null, h('b', null, 'Where ours loses: '), t));
  for (const t of L.std) ps.push(h('p', { class: 'stdpair' }, h('b', null, 'Not ours, both standard: '), t));
  if (L.checked) ps.push(h('p', { class: 'small muted' }, L.checked + (L.warm ? ' ' + L.warm : '')));
  else if (L.warm) ps.push(h('p', { class: 'small muted' }, L.warm));
  $('glance-sum').replaceChildren(...ps);
  const th = (t, cls) => h('th', { scope: 'col', role: 'columnheader', class: cls || null }, t);
  const table = h('table', { class: 'stack', role: 'table' }, h('caption', { class: 'sr' }, 'Ours against the standard, job by job, at the largest size timed; rows marked both standard compare two standard methods'),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, th('Job'), th('Standard'), th('Ours', 'o'), th('Ours against the standard'), th('By n'))),
    h('tbody', { role: 'rowgroup' }, ...rows.map(r => h('tr', { role: 'row', class: r.kind === 'std' ? 'stdpair' : null },
      h('th', { scope: 'row', role: 'rowheader' }, r.role.job),
      h('td', { role: 'cell', 'data-label': 'Standard' }, r.role.std),
      h('td', { role: 'cell', 'data-label': 'Ours' }, r.kind === 'std' ? 'none: ' + r.pair.cand + ' is standard too' : r.role.ours),
      h('td', { role: 'cell', 'data-label': 'Ours against the standard' }, h('div', { class: 'cellbody' }, h('span', { class: 'v big' }, fmtRatio(magnitude(r.pick.o))), h('span', null, chip(r.pick.o.verdict), r.pick.j.noisy ? [' ', noisyTag()] : null), h('span', { class: 'r' }, (r.kind === 'std' ? r.pair.candShort + ' against ' + r.pair.stdShort + ', ' : '') + r.where))),
      h('td', { role: 'cell', 'data-label': 'By n' }, r.runs || '–')))));
  $('glance-tab').replaceChildren(table);
}
function renderRoles() {
  const th = (t, cls) => h('th', { scope: 'col', role: 'columnheader', class: cls || null }, t), ids = SHOW_ORDER.filter(id => ROLE[id]);
  const tr = (job, std, ours) => h('tr', { role: 'row' }, h('th', { scope: 'row', role: 'rowheader' }, job), h('td', { role: 'cell', 'data-label': 'Standard' }, std), h('td', { role: 'cell', 'data-label': 'Ours' }, ours));
  $('roles').replaceChildren(h('table', { class: 'stack', role: 'table' }, h('caption', { class: 'sr' }, 'The standard method and ours, job by job'),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, th('Job'), th('Standard'), th('Ours', 'o'))),
    h('tbody', { role: 'rowgroup' }, ...ids.flatMap(id => [tr(ROLE[id].job, ROLE[id].std, ROLE[id].ours), ...STD_PAIRS.filter(p => p.id === id).map(p => tr(p.job, p.std + '; ' + p.cand, 'none: no idea of the label is timed here'))]))));
}

// ---------------------------------------------------------------- machine
function machineInfo() {
  const n = navigator, u = n.userAgentData;
  return { userAgent: n.userAgent, platform: n.platform || null, uaPlatform: u && u.platform || null, hardwareConcurrency: n.hardwareConcurrency || null, deviceMemory: n.deviceMemory || null, language: n.language || null, languages: n.languages ? Array.from(n.languages) : null,
    devicePixelRatio: window.devicePixelRatio, crossOriginIsolated: !!window.crossOriginIsolated, timerStepMs: S.timerStepMs, timerWhere: S.timerWhere, date: S.dateISO || new Date().toISOString(), mode: S.mode, pageVersion: BUILD.version };
}
function refreshMachine() {
  const m = machineInfo(), rows = [['Browser (user agent)', m.userAgent], ['Platform', [m.platform, m.uaPlatform].filter(Boolean).join(' / ') || 'not reported'], ['Logical processors', m.hardwareConcurrency == null ? 'not reported' : String(m.hardwareConcurrency)],
    ['Device memory', m.deviceMemory == null ? 'not reported by this browser' : '≥ ' + m.deviceMemory + ' GB (rounded down by the browser)'], ['Language', m.language || 'not reported'], ['Device pixel ratio', String(m.devicePixelRatio)],
    ['Cross-origin isolated', m.crossOriginIsolated ? 'yes (finer timer)' : 'no'], ['Timer step', m.timerStepMs == null ? (S.timerWhere ? 'no tick within 100 ms' : 'measured when a run starts') : fmtT(m.timerStepMs * 1e6) + ' (' + m.timerWhere + ')'],
    ['Date of this run', S.dateISO || 'no run yet'], ['Mode', S.mode === 'worker' ? 'Web Worker' : S.mode === 'main' ? 'main thread: ' + S.modeNote : 'not started'], ['Page version', BUILD.version + ', kernels ' + BUILD.hash]];
  $('machine').replaceChildren(...rows.flatMap(([k, v]) => [h('dt', null, k), h('dd', null, v)]));
}

// ---------------------------------------------------------------- export
function hasData() { return Object.keys(S.cells).length > 0 || Object.keys(S.warm.cold).length > 0; }
function kernelRows() {
  const ns = new Set(); for (const scn of KERNEL) for (const k of keysOf(scn)) ns.add(+k);
  return [...ns].sort((a, b) => a - b).map(n => { const o = {}; for (const scn of KERNEL) { const c = (S.cells[scn] || {})[n]; if (c) Object.assign(o, c); } return { n, sandwichesDirect: Math.pow(2, n), sandwichesFrame: n + 1, additions: Math.pow(2, n) - 1, ns: o }; });
}
function warmExport() {
  const t = {}; for (const id of CORE.WARM_TARGETS) { const d = warmData(id); if (!d) continue; t[id] = { runs: S.warm.cold[id].map(c => ({ rep: c.rep, setupMs: c.setupMs, call1Ms: c.call1, calls2to10Ms: c.t2_10, calls11to100Ms: c.t11_100, calls101to1000Ms: c.t101_1000 })), steadyNs: S.warm.steady[id] || null, call1OverSteady: d.ratio1 == null ? null : d.ratio1, first10OverSteady: d.ratio10 == null ? null : d.ratio10, readable: { call1: d.call1.kind, first10: d.first10.kind, calls11to100: d.b11.kind, calls101to1000: d.b101.kind } }; }
  return { n: S.warm.n, freshWorkerPerRun: S.warm.fresh, targets: t };
}
function glanceExport() {
  const rows = glanceRows(); if (!rows.length) return null;
  const L = glanceLines(rows);
  return { note: 'ours against the standard at the largest size timed; oursRatio = standard time / ours (above 1: ours faster); verdict is from the point of view of ours. Rows of kind standard-vs-standard compare two standard methods (ours is null; ratio = time of the first / time of the candidate)',
    rows: rows.map(r => r.kind === 'std' ? { kind: 'standard-vs-standard', scenario: r.id, job: r.role.job, standard: r.pair.std, ours: null, candidate: r.pair.cand, at: r.pick.key, ratio: r.pick.o.ratio, verdictForCandidate: r.pick.o.verdict, spread: r.pick.j.spread, noisy: r.pick.j.noisy, byN: r.runs }
      : { kind: 'ours-vs-standard', scenario: r.id, job: r.role.job, standard: r.role.std, ours: r.role.ours, at: r.pick.key, oursRatio: r.pick.o.ratio, verdictForOurs: r.pick.o.verdict, spread: r.pick.j.spread, noisy: r.pick.j.noisy, byN: r.runs }),
    summary: { best: L.best, tally: L.tally, loses: L.loses, standardPairs: L.std, checked: L.checked } };
}
function buildExport() {
  const cfg = S.cfg || readSettings();
  return { format: 'label-bench', formatVersion: 1, pageVersion: BUILD.version, kernelFingerprint: BUILD.hash, note: 'Timed, not proved: measurements from one run on one machine; they say nothing about other machines.',
    date: S.dateISO, mode: S.mode, modeNote: S.modeNote, stopped: S.stopped, error: S.error, machine: machineInfo(), settings: cfg, checks: S.checks, sceneCheck: S.sceneCheck,
    rows: kernelRows(), product: S.cells.product ? { ns: S.cells.product, productMax: cfg.productMax } : null, bodies: S.cells.bodies ? { B: cfg.bodies.B, n: cfg.bodies.n, seed: cfg.bodies.seed, ns: S.cells.bodies.scene } : null, warmup: Object.keys(S.warm.cold).length ? warmExport() : null, alloc: S.cells.alloc || null, glance: glanceExport() };
}
const csvq = v => { const s = String(v == null ? '' : v); return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
function buildCSV() {
  const L = [['kind', 'scenario', 'key', 'name', 'median_ns', 'min_ns', 'max_ns', 'spread', 'ratio', 'verdict'].join(',')], row = a => L.push(a.map(csvq).join(','));
  for (const id of SHOW_ORDER) {
    const sc = SC[id]; if (sc.special === 'warm') continue;
    for (const k of keysOf(id)) for (const v of sc.variants) { const st = cellOf(id, k, v.id); if (st) row(['timing', id, id === 'bodies' ? 'B=' + S.cfg.bodies.B + ' n=' + S.cfg.bodies.n : k, v.id, st.med, st.min, st.max, spreadOf(st), '', '']); }
    for (const c of sc.comps) for (const r of compRows(id, c)) row(['ratio', id, id === 'bodies' ? 'B=' + S.cfg.bodies.B + ' n=' + S.cfg.bodies.n : r.key, c.base + '/' + c.cand, '', '', '', r.j.spread, r.j.ratio, r.j.verdict]);
  }
  for (const t of CORE.WARM_TARGETS) { const d = warmData(t); if (!d) continue; for (const [nm, q] of [['call 1', d.call1], ['calls 1-10 mean', d.first10], ['calls 11-100 mean', d.b11], ['calls 101-1000 mean', d.b101]]) row(['cold', 'warm', t + ' n=' + S.warm.n, nm, q.med, q.min, q.max, '', '', q.kind === 'ok' ? '' : q.kind === 'bound' ? 'below timer resolution: upper bound ' + q.bound.toFixed(0) + ' ns' : 'approximate: under 10 timer steps']);
    if (d.steady) { row(['timing', 'warm', t + ' n=' + S.warm.n, 'steady', d.steady.med, d.steady.min, d.steady.max, spreadOf(d.steady), '', '']); row(['ratio', 'warm', t + ' n=' + S.warm.n, 'call 1/steady', '', '', '', '', d.ratio1, d.ratio1 == null ? 'n/a' : '']); row(['ratio', 'warm', t + ' n=' + S.warm.n, 'first 10/steady', '', '', '', '', d.ratio10, d.ratio10 == null ? 'n/a' : '']); } }
  return L.join('\n') + '\n';
}
function buildText() {
  const L = [], cfg = S.cfg || readSettings(), m = machineInfo(), step = S.timerStepMs;
  L.push('Label speed test ' + BUILD.version + ' (kernels ' + BUILD.hash + '): timed, not proved.', 'Date: ' + (S.dateISO || '-') + '   Mode: ' + (S.mode === 'worker' ? 'Web Worker' : S.mode === 'main' ? 'main thread (' + S.modeNote + ')' : '-'));
  L.push('Browser: ' + m.userAgent, 'Platform: ' + (m.platform || '-') + ', processors: ' + (m.hardwareConcurrency || '-') + ', memory: ' + (m.deviceMemory ? '>= ' + m.deviceMemory + ' GB' : 'not reported') + ', timer step: ' + (step == null ? '-' : fmtT(step * 1e6)));
  L.push('Settings: batches >= ' + cfg.minMs + ' ms, ' + cfg.reps + ' repetitions, n = ' + cfg.nFrom + '..' + cfg.nTo + (S.stopped ? '   (STOPPED: partial results)' : '') + (S.error ? '   (ABORTED: ' + S.error + ')' : ''));
  const more = [];
  if (cfg.scenarios.includes('product')) more.push('product: n up to ' + cfg.productMax);
  if (cfg.scenarios.includes('bodies')) more.push('many bodies: B = ' + cfg.bodies.B + ', n = ' + cfg.bodies.n + ', seed ' + cfg.bodies.seed);
  if (cfg.scenarios.includes('warm')) more.push('warm-up: n = ' + cfg.warm.n);
  if (more.length) L.push('Scenario settings: ' + more.join('; ') + '.');
  const gr = glanceRows();
  if (gr.length) {
    const gl = glanceLines(gr);
    L.push('', 'AT A GLANCE (ours against the standard; ratio = standard time / ours; > 1x: ours faster; rows marked "not ours" compare two standard methods)');
    for (const r of gr) L.push(r.kind === 'std' ? '  ' + r.role.job + ': not ours, ' + stdPairText(r).replace(/ ⚠ noisy\.$/, '') + (r.pick.j.noisy ? ' NOISY' : '') + (r.runs ? ' By n: ' + r.runs : '')
      : '  ' + r.role.job + ': ours (' + r.role.ours + ') ' + fmtRatio(magnitude(r.pick.o)) + ' ' + WORD[r.pick.o.verdict] + ' than the standard (' + r.role.std + '), ' + r.where + (r.pick.j.noisy ? ', NOISY' : '') + (r.runs ? '; ' + r.runs : ''));
    L.push('  Best result on this run: ' + gl.best, '  ' + gl.tally); for (const t of gl.loses) L.push('  Where ours loses: ' + t); for (const t of gl.std) L.push('  Not ours, both standard: ' + t); if (gl.checked) L.push('  ' + gl.checked); if (gl.warm) L.push('  ' + gl.warm);
  }
  for (const id of SHOW_ORDER) {
    const sc = SC[id], cm = S.checks[id]; if (!S.cells[id] && !(id === 'warm' && Object.keys(S.warm.cold).length)) continue;
    L.push('', sc.title.toUpperCase() + (id === 'bodies' ? ' (B = ' + cfg.bodies.B + ', n = ' + cfg.bodies.n + ')' : '') + (cm ? '   (correctness check: ' + (Object.values(cm).every(d => d.ok) ? 'passed' : 'FAILED') + ')' : ''));
    if (sc.special === 'warm') {
      for (const t of CORE.WARM_TARGETS) { const d = warmData(t); if (!d) continue; L.push('  ' + t + ' (n = ' + S.warm.n + ', ' + d.runs + ' cold runs): call 1 ' + fmtQ(d.call1) + ', calls 1-10 mean ' + fmtQ(d.first10) + ', calls 11-100 ' + fmtQ(d.b11) + ', calls 101-1000 ' + fmtQ(d.b101) + (d.steady ? ', steady ' + fmtT(d.steady.med) + ' => call 1 is ' + (d.ratio1 == null ? 'n/a' : fmtRatio(d.ratio1)) + ' and the first 10 are ' + (d.ratio10 == null ? 'n/a' : fmtRatio(d.ratio10)) + ' of steady' : '')); }
      L.push('  ' + (S.warm.fresh ? 'each run in a fresh worker' : 'main thread: NOT a cold start')); continue;
    }
    for (const k of keysOf(id)) L.push('  ' + sc.keyLabel(k) + ': ' + sc.variants.filter(v => cellOf(id, k, v.id)).map(v => { const st = cellOf(id, k, v.id); return v.short + ' ' + fmtT(st.med) + ' (' + fmtRange(st) + ')' + (id === 'bodies' ? ' = ' + fmtRate(cfg.bodies.B / (st.med * 1e-9)) : ''); }).join('; '));
    for (const c of sc.comps) for (const r of compRows(id, c)) L.push('  [' + c.label + '] ' + (id === 'bodies' ? '' : sc.keyShort(r.key) + ': ') + claimText(c.name, r.j) + ' -> ' + WORD[r.j.verdict] + ', spread ' + fmtPct(r.j.spread) + (r.j.noisy ? ', NOISY' : ''));
  }
  L.push('', 'Verdict rule: about equal within noise when |ln ratio| < ln(1 + max(5%, spread of the repetitions)), so a k-fold gain and a k-fold loss are judged alike. Everything here is a measurement on one machine, not a proof.');
  return L.join('\n') + '\n';
}
function download(name, mime, text) {
  const url = URL.createObjectURL(new Blob([text], { type: mime })), a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 4000);
}
const stamp = () => (S.dateISO || new Date().toISOString()).replace(/[-:]/g, '').slice(0, 13).replace('T', '-');
async function copyText() {
  const text = buildText(), msg = $('exp-msg');
  try { await navigator.clipboard.writeText(text); msg.textContent = 'Copied the text summary.'; return; } catch (e) { }
  const ta = $('textOut'); ta.value = text; ta.closest('details').open = true; ta.focus(); ta.select();
  let ok = false; try { ok = document.execCommand('copy'); } catch (e) { }
  msg.textContent = ok ? 'Copied the text summary.' : 'Copying was refused by the browser: the text is selected in the box below, press Ctrl+C (or Cmd+C).';
}

// ---------------------------------------------------------------- compare with another run
function describeMachine(o) {
  const m = o.machine || {};
  if (m.node) return 'node ' + m.node + ', ' + (m.cpu || 'cpu ?') + ', ' + m.cores + ' cores' + (m.date ? ', ' + m.date : '');
  if (m.userAgent) return m.userAgent.slice(0, 110) + (m.hardwareConcurrency ? ', ' + m.hardwareConcurrency + ' processors' : '') + (o.date ? ', ' + o.date.slice(0, 10) : '');
  return 'unnamed run';
}
function normalizeRun(o, label) {
  if (!o || !Array.isArray(o.rows)) throw new Error('there is no "rows" list: this is not a run from this page or from bench_labels.mjs');
  const rows = {}; for (const r of o.rows) if (r && typeof r.n === 'number' && r.ns && typeof r.ns === 'object') rows[r.n] = r.ns;
  if (!Object.keys(rows).length) throw new Error('"rows" holds no timings');
  return { label: label || describeMachine(o), rows, minMs: o.machine && o.machine.minMs || (o.settings && o.settings.minMs), reps: o.machine && o.machine.reps || (o.settings && o.settings.reps) };
}
function thisRows() {
  const rows = {}; for (const r of kernelRows()) rows[r.n] = r.ns; return rows;
}
function renderCompare() {
  const out = $('cmp-out'), o = S.other; $('cmp-clear').disabled = !o;
  if (!o) { out.replaceChildren(); return; }
  const mine = thisRows(), ns = [...new Set([...Object.keys(mine), ...Object.keys(o.rows)].map(Number))].sort((a, b) => a - b);
  const side = (rows, n, c) => { const ns_ = rows[n]; return ns_ ? judge(ns_[c.base], ns_[c.cand]) : null; };
  const txt = (j, c) => j ? h('span', null, fmtRatio(j.ratio), ' ', h('span', { class: 'chip ' + j.verdict }, GLYPH[j.verdict] + NBSP + (j.verdict === 'equal' ? 'about equal' : j.verdict)), j.noisy ? [' ', h('span', { class: 'noisy' }, '⚠ noisy')] : null) : '–';
  const table = h('table', { class: 'cmp', role: 'table' }, h('caption', { class: 'sr' }, 'The claimed ratio on this run and on the other run'),
    h('thead', { role: 'rowgroup' }, h('tr', { role: 'row' }, h('th', { scope: 'col', role: 'columnheader' }, 'n'), h('th', { scope: 'col', role: 'columnheader' }, 'This run'), h('th', { scope: 'col', role: 'columnheader' }, 'Other run'), h('th', { scope: 'col', role: 'columnheader' }, 'This ÷ other'))));
  let any = false;
  for (const id of KERNEL) for (const c of SC[id].comps) {
    const rows = ns.map(n => ({ n, a: side(mine, n, c), b: side(o.rows, n, c) })).filter(r => r.a || r.b); if (!rows.length) continue; any = true;
    table.append(h('tbody', { role: 'rowgroup' }, h('tr', { class: 'grp', role: 'row' }, h('th', { colspan: 4, scope: 'colgroup', role: 'columnheader' }, SC[id].title + ': ' + c.label)),
      ...rows.map(r => h('tr', { role: 'row' }, h('th', { scope: 'row', role: 'rowheader' }, String(r.n)), h('td', { role: 'cell' }, txt(r.a, c)), h('td', { role: 'cell' }, txt(r.b, c)), h('td', { role: 'cell' }, r.a && r.b ? (r.a.ratio / r.b.ratio).toFixed(2) : '–')))));
  }
  out.replaceChildren(h('dl', { class: 'info' }, h('dt', null, 'This run'), h('dd', null, hasData() ? describeMachine({ machine: machineInfo(), date: S.dateISO }) + (S.cfg ? '; batches ≥ ' + S.cfg.minMs + ' ms, ' + S.cfg.reps + ' repetitions' : '') : 'no run yet: press Run to fill this side'),
    h('dt', null, 'Other run'), h('dd', null, o.label + (o.minMs ? '; batches ≥ ' + o.minMs + ' ms, ' + o.reps + ' repetitions' : ''))),
    any ? h('div', { class: 'tablewrap', role: 'region', tabindex: '0', 'aria-label': 'Comparison of two runs' }, table) : h('p', { class: 'muted' }, 'The two runs have no comparison in common yet.'),
    h('p', { class: 'small muted' }, 'This ÷ other: the ratio of the two ratios. Above 1: the claimed gain is larger on this machine; below 1: smaller. Verdicts use the same rule as above, per side.'));
}
function loadOther(obj, label) {
  try { S.other = normalizeRun(obj, label); $('cmp-msg').textContent = 'Loaded: ' + S.other.label + '.'; $('cmp-msg').className = 'small'; }
  catch (e) { S.other = null; $('cmp-msg').textContent = 'Could not use this file: ' + e.message + '.'; $('cmp-msg').className = 'small'; }
  renderCompare();
}

// ---------------------------------------------------------------- start
function init() {
  buildSkeleton(); renderRoles();
  for (const id of ['nFrom', 'nTo']) { const s = $(id); for (let n = 1; n <= 10; n++) s.append(h('option', { value: n, selected: n === (id === 'nFrom' ? 1 : 8) }, String(n))); }
  $('ver').textContent = 'version ' + BUILD.version; $('khash').textContent = BUILD.hash;
  for (const id of ['minMs', 'reps', 'nFrom', 'nTo', 'prodN', 'bodiesB', 'bodiesN', 'warmN']) $(id).addEventListener('change', () => { syncPresetButtons(); updateWarnings(); });
  for (const id of SHOW_ORDER) $('sc-' + id).addEventListener('change', updateWarnings);
  for (const k of Object.keys(PRESETS)) $('p-' + k).addEventListener('click', () => { $('minMs').value = PRESETS[k].minMs; $('reps').value = PRESETS[k].reps; syncPresetButtons(); updateWarnings(); });
  $('run').addEventListener('click', run); $('stop').addEventListener('click', stop);
  $('dl-json').addEventListener('click', () => download('label-bench-' + stamp() + '.json', 'application/json', JSON.stringify(buildExport(), null, 1)));
  $('dl-csv').addEventListener('click', () => download('label-bench-' + stamp() + '.csv', 'text/csv', buildCSV()));
  $('cp-text').addEventListener('click', copyText);
  $('cmp-file').addEventListener('change', ev => { const f = ev.target.files && ev.target.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { try { loadOther(JSON.parse(String(r.result)), null); } catch (e) { S.other = null; $('cmp-msg').textContent = 'Could not read this file as JSON: ' + e.message + '.'; renderCompare(); } }; r.onerror = () => { $('cmp-msg').textContent = 'Could not read this file.'; }; r.readAsText(f); });
  $('cmp-ref').addEventListener('click', () => { const ref = JSON.parse($('ref-run').textContent); loadOther(ref, 'reference run on one 2-core VM, node 22 (' + (ref.machine.date || '') + ')'); });
  $('cmp-clear').addEventListener('click', () => { S.other = null; $('cmp-msg').textContent = ''; $('cmp-file').value = ''; renderCompare(); });
  let rt = 0; window.addEventListener('resize', () => { clearTimeout(rt); rt = setTimeout(() => { if (!S.running) for (const id of SHOW_ORDER) if (!SK[id].sec.hidden && SC[id].chart) drawChart(id, SK[id].chart, SK[id].legend); }, 150); });
  window.addEventListener('hashchange', () => { if (!S.running) setModePreview(); });
  syncPresetButtons(); updateWarnings(); refreshMachine(); syncButtons(); setModePreview();
  window.__labelBench = { state: () => S, judge, render: renderNow, buildExport, buildCSV, buildText, version: BUILD.version };
}
function setModePreview() { if (!S.mode) $('mode').textContent = /(^|[#&,])main\b/.test(location.hash) ? 'Mode: main thread (forced by #main in the address)' : 'Mode: Web Worker if the browser allows it, else main thread'; }
init();
})();
