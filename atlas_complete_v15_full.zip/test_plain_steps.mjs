// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Data test of the Young Learner's words on steps 5, 11 and 13 to 16 and the tally (plainStepsCopy.js) and of their short readings (audienceCopy.js SHORT).
//  1. English and Italian have the same shape (same keys, same list lengths, functions where the other has functions)
//  2. no string (and no output of a function, on sample inputs) holds a formula symbol or a technical word: the patterns are read from test_yl_ui.mjs,
//     so a word added there is checked here too; file names are removed first, as there
//  3. every count in the text is the data's (forque, spin, spring, rigid body, null surfaces, tally), and the rigid body's text carries no timing number
//  4. every step closes with the four statuses (checked, standard, ours, open), the last one open, and the "ours" line says it is an idea, not a result
// Run: node test_plain_steps.mjs     (PLAIN_FILE=<module> tests another copy of the file, used for the mutation check)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import FQ from './forqueData.js';
import SPD from './spinData.js';
import SRD from './springData.js';
import PGD from './pgadynData.js';
import NUD from './nullData.js';
import PJ from './projectiveData.js';
import EQC from './equationsCopy.js';
import { SHORT } from './audienceCopy.js';
import { STEP_GROUPS, stepNo } from './steps.js';
const PLAIN = (await import(process.env.PLAIN_FILE || './plainStepsCopy.js')).default;
let bad = 0, checks = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), grab = name => { const m = src.match(new RegExp(`^const ${name} = (/.*/[a-z]*);`, 'm')); return m && new Function(`return ${m[1]}`)(); };
const SYM = grab('SYMBOLS'), JAR = grab('JARGON');
ok(SYM instanceof RegExp && JAR instanceof RegExp, 'the patterns of test_yl_ui.mjs are read');
const clean = s => s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' ').replace(/\barXiv:[\d.]+(v\d+)?/gi, ' ').replace(/https?:\/\/\S+/g, ' ');
// sample inputs for the functions of the copy: the racket result, counts, bit labels, angles
const SAMPLE = { r: { lam: 0.8944, m: 1, measured: 0.8941 }, r0: { lam: 0, m: 0, measured: null } };
const outputs = (f, path) => {
  if (/\.out$/.test(path)) return [...f(SAMPLE.r), ...f(SAMPLE.r0)];
  if (/\.sums$/.test(path)) return f(15, 15, 12, 4, 2, 15).concat(f(15, 14, 12, 4, 2, 14));
  if (/\.(line1|line2)$/.test(path)) return [f(90), f(180)];
  if (/\.modeInfo$/.test(path)) return [f('011', 2, 4, 3), f('001', 1, 2, 1)];
  if (/\.attach$/.test(path)) return [f('101', 'e₀₁₃', '010')];      // the blade name is passed in and must not be shown
  if (/\.(energy|econs)$/.test(path)) return [f('1.5', '2.5', '0.5', '4.5')];
  if (/\.line$/.test(path)) return [f('Flat space', 10, 4)];
  if (/\.where$/.test(path)) return [f('maxwell', 0), f('spin', 11)];
  return [f(1), f(2), f(3), f('space'), f('lorentz')];
};
const shape = x => (typeof x === 'function' ? 'f' : typeof x === 'string' ? 's' : Array.isArray(x) ? x.map(shape) : x && typeof x === 'object' ? Object.fromEntries(Object.keys(x).sort().map(k => [k, shape(x[k])])) : typeof x);
ok(JSON.stringify(shape(PLAIN.en)) === JSON.stringify(shape(PLAIN.it)), 'English and Italian have the same shape');
const texts = {};
const walk = (x, path, lang) => {
  if (typeof x === 'string') (texts[lang] ||= []).push([path, x]);
  else if (typeof x === 'function') outputs(x, path).forEach((s, i) => (texts[lang] ||= []).push([`${path}()#${i}`, String(s)]));
  else if (x && typeof x === 'object') for (const [k, v] of Object.entries(x)) walk(v, `${path}.${k}`, lang);
};
for (const lang of ['en', 'it']) {
  walk(PLAIN[lang], lang, lang);
  for (const id of ['projective', 'forque', 'spin', 'spring', 'rigid', 'nullsurf', 'tally']) (texts[lang] ||= []).push([`SHORT.${lang}.${id}[0]`, SHORT[lang][id][0]]);
  for (const [path, s] of texts[lang]) {
    const t = clean(s), m1 = SYM.exec(t), m2 = JAR.exec(t);
    ok(!m1 && !m2, `${path}: "${(m1 || m2 || [''])[0]}" in "${s.slice(0, 90)}"`);
    ok(!/undefined|NaN|\[object/.test(s), `${path}: a placeholder in "${s.slice(0, 60)}"`);
  }
  // lines written in English in the Italian slot on purpose (new text is English in both slots until the Italian is revised): the tally's line about what is brought in from outside
  const EN_SLOT = /^\d+ rows also say what is brought in from outside\.$/;
  // and whole English sentences added to an Italian text (the spring step: what the bridge checks of the signed cube and of the vector network say); the rest of that text is still tested
  const EN_SENT = [' A second check shows that the signs on the springs are the ones used to put the electron on a grid: on one cube alone they do not give the electron’s equation, on a grid made of many copies of the cube they do.', ' A cube of such springs is not drawn here.'];
  if (lang === 'it') for (const [path, s] of texts.it) { const r = EN_SENT.reduce((x, e) => x.split(e).join(''), s); ok(EN_SLOT.test(s) || !/\b(the|and|with|which|that|this|is|are|has|its|every|of|you|your|from|when|what|how|one|turn)\b/i.test(r.replace(/\bde Sitter\b/g, '')), `${path}: English words in the Italian text "${s.slice(0, 60)}"`); }
  if (lang === 'it') ok(EN_SENT.every(e => texts.it.some(([, s]) => s.includes(e))), 'the English sentences allowed in the Italian slots are used');
}
// 3. the counts are the data's
const FC = FQ.fq.counts, SC = SPD.spm.counts, NU = NUD.portal.summary;
const has = (s, ...ns) => ns.every(n => new RegExp(`(^|[^0-9])${n}([^0-9]|$)`).test(s));
for (const lang of ['en', 'it']) {
  const P = PLAIN[lang];
  ok(has(P.forque.story[1], FC.ok, FC.rows, FC.note, FC.not_checked), `${lang} forque: the story counts are the data's`);
  ok(has(P.forque.hedges[0][1], FC.ok, FC.note) && has(P.forque.hedges[3][1], FC.not_checked), `${lang} forque: the hedge counts`);
  ok(P.forque.story[0].includes(FQ.fq.paper.authors[0]) && P.forque.story[0].includes(FQ.fq.paper.authors[1]), `${lang} forque: the authors are named from the data`);
  ok(has(P.spin.story[1], SC.ok, SC.note, SC.not_checked) && has(P.spin.hedges[0][1], SC.ok + SC.note, SC.rows), `${lang} spin: the counts`);
  ok(SPD.spm.paper.authors.every(a => P.spin.story[1].includes(a)) && P.spin.story[1].includes(SPD.spm.lecture.speaker), `${lang} spin: the authors and the lecturer from the data`);
  ok(has(P.spring.hedges[0][1], SRD.summary.ok), `${lang} spring: the claim count`);
  ok(has(P.rigid.hedges[0][1], PGD.summary.ok) && P.rigid.story[1].includes(lang === 'it' ? PGD.moon.period_days.replace('.', ',') : PGD.moon.period_days), `${lang} rigid: the claim count and the Moon's period`);
  ok(P.rigid.hedges[1][1].includes(String(stepNo('eq', 'forque'))), `${lang} rigid: the paper is the one of the forque step`);
  ok(!/\d\s*(×|ms\b|µs|microsec|millisec)|\bspeed[- ]?up|volte più veloce/i.test(JSON.stringify(P.rigid) + P.rigid.hang.speed()), `${lang} rigid: no timing number in the Young Learner's text`);
  ok(has(P.nullsurf.story[1], NU.passed, NU.computed, NU.readings) && has(P.nullsurf.hedges[0][1], NU.passed, NU.computed), `${lang} null: the counts`);
  // the projective line is fed by the data: the number of moves does not depend on the setting
  ok(['space', 'lorentz'].every(k => [2, 3, 4, 5, 6].every(n => new Set([0, -1, 1].map(s => PJ.pj.ladder[`${k},${n},${s}`].dimension)).size === 1)), 'projective: the move count is the same for the three settings, as the line says');
  ok(Object.keys(P.projective.names).length === 6 && Object.keys(P.projective.sLabel).length === 3 && ['0', '-1', '1'].every(k => P.projective.sLabel[k]), `${lang} projective: six names and three settings`);
  // the tally: one plain name per row, in the order of the rows (Maxwell, then the steps)
  const ids = ['maxwell', ...STEP_GROUPS.eq];
  ok(EQC[lang].t.rows.length === ids.length && ids.every(id => typeof P.tally.names[id] === 'string' && P.tally.names[id].length > 3), `${lang} tally: a plain name for each of the ${EQC[lang].t.rows.length} rows`);
  ok(Object.keys(P.tally.names).length === ids.length, `${lang} tally: no extra names`);
  // 4. the four statuses, the last one open, and the "ours" line is an idea
  for (const id of ['projective', 'forque', 'spin', 'spring', 'rigid', 'nullsurf']) {
    const H = P[id].hedges; ok(H.map(h => h[0]).join() === 'checked,standard,ours,open', `${lang} ${id}: the four statuses in order`);
    ok(lang === 'en' ? /ideas? we try, not (a )?results?/.test(H[2][1]) : /ide[ae] che proviamo, non (un )?risultat/.test(H[2][1]), `${lang} ${id}: the "ours" line says it is an idea, not a result`);
    ok(/check|controll/.test(H[0][1]), `${lang} ${id}: the "checked" line says what was checked`);
  }
  for (const id of ['forque', 'spin']) ok(lang === 'en' ? /authors can (re-run|check)/.test(P[id].hedges[0][1] + P[id].story.join(' ')) : /autori possono/.test(P[id].hedges[0][1] + P[id].story.join(' ')), `${lang} ${id}: the authors can check it too`);
  for (const id of ['forque', 'spin']) ok(lang === 'en' ? /not (been )?checked|could not check|did not check/.test(P[id].story.join(' ') + P[id].hedges[3][1]) : /non (le )?abbiamo|non sono state controllate/.test(P[id].story.join(' ') + P[id].hedges[3][1]), `${lang} ${id}: what was not checked is said`);
}
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL PLAIN-STEPS TESTS PASS'); process.exit(bad ? 1 : 0);
