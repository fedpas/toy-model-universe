// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The note "Division algebraic symmetry breaking and the Atlas" (reports/note/, its page reports/html/symmetry_breaking_note.html) agrees with itself.
// (a) Data: the files of the folder exist and the README names each; the page is a page in html/ and is neither in index.json nor in a zip nor in REPORTS; it opens as a file, holds no
// address, mail link, external request or history wording; every number it states (15 checks, 1 info line, 8 broken variants) is the count of the stored logs; every check id it names exists
// in the logs (M in the note's, A R T F C P N in furey_papers_check.log, B in furey_construction_check.log) and every id of the note's log is named; the sabotage log has eight lines that each
// stop at a named check. (b) Runs: the check script gives its stored log; two of the broken variants stop where the log says; build_note.py rebuilds the page byte for byte.
// Needs python3 and numpy (exit 77 without python3; the runs of (b) are left out with a SKIP line without numpy).   Run: node test_note.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8');
const py = (args, opts = {}) => spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 64 << 20, ...opts });
const pv = py(['-c', 'import sys']);
if (pv.error || pv.status !== 0) { console.log('SKIP: test_note needs python3: ' + (pv.error ? pv.error.message : (pv.stderr || '').trim().split('\n').pop())); process.exit(77); }
const hasNumpy = py(['-c', 'import numpy']).status === 0;

const R = 'reports', N = path.join(R, 'note'), PAGE = path.join(R, 'html', 'symmetry_breaking_note.html');
const FILES = ['symmetry_note_check.py', 'build_note.py', 'README_note.md', 'logs/symmetry_note_check.log', 'logs/symmetry_note_check_sabotage.log'];

// ---- (a1) the files, and the README that names each
ok(FILES.every(f => fs.existsSync(path.join(N, f))) && fs.existsSync(PAGE), 'reports/note/ holds ' + FILES.join(', ') + ' and the page is in reports/html/: ' + FILES.filter(f => !fs.existsSync(path.join(N, f))).join(' '));
const walk = d => fs.readdirSync(d, { withFileTypes: true }).filter(e => e.name !== '__pycache__').flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const inFolder = walk(N).map(f => path.relative(N, f).split(path.sep).join('/')).sort();
ok(JSON.stringify(inFolder) === JSON.stringify([...FILES].sort()), 'reports/note/ holds exactly its five files: ' + inFolder.join(', '));
const README = rd(path.join(N, 'README_note.md'));
ok(FILES.filter(f => f !== 'README_note.md').every(f => README.includes('`' + f + '`')) && README.includes('symmetry_breaking_note.html') && README.includes('test_note.mjs'), 'README_note.md names every file of the folder, the page and its test');

// ---- (a2) the page is beside the reports, not one of them
const idx = JSON.parse(rd(path.join(R, 'html', 'index.json')));
ok(!JSON.stringify(idx).includes('symmetry_breaking_note') && idx.reports.length === 6, 'html/index.json lists the six reports and not the note');
const zips = fs.readdirSync(path.join(R, 'zips'));
ok(zips.length === 6 && !zips.some(z => /note|symmetry/i.test(z)), 'the six zips are the six reports; the note has no zip');
const REPS = rd('reportsData.js');
ok(!/symmetry_breaking_note|symmetry_note/.test(REPS), 'reportsData.js (the For researchers list) does not list the note');
const BUILD = rd('build.sh');
ok(/reports\/html/.test(BUILD), 'build.sh copies reports/html/ to dist/reports/html/, where the note is served');

// ---- (a3) the page: opens as a file, no address, no mail link, no external request, no history wording
const H = rd(PAGE);
ok(!/@/.test(H.replace(/@media|@font-face|@import|@keyframes|@supports|@page/g, '')) && !/mailto:/i.test(H), 'no "@" (no address) and no mail link in the page');
ok(!/<script[^>]*\ssrc=|<link[^>]*rel=["']?stylesheet|<img[^>]*src=["']?https?:|url\(\s*["']?https?:|@import|<iframe|<object|<embed/i.test(H), 'the page makes no request: no external script, style sheet, image, font or frame');
const hrefs = [...H.matchAll(/href="([^"]*)"/g)].map(m => m[1]);
ok(hrefs.every(h => h.startsWith('#') || h.startsWith('https://arxiv.org/abs/') || h === 'furey_report.html'), 'the links of the page go to its own headings, to arXiv abstracts, and to furey_report.html (which sits in the same folder): ' + hrefs.filter(h => !(h.startsWith('#') || h.startsWith('https://arxiv.org/abs/') || h === 'furey_report.html')).join(' '));
ok(fs.existsSync(path.join(R, 'html', 'furey_report.html')), 'furey_report.html, which the note links to, is beside it');
ok(/<title>[^<]+<\/title>/.test(H) && /name="viewport"/.test(H) && /<h1[\s>]/.test(H) && (H.match(/<svg/g) || []).length >= 3 && H.includes('prefers-color-scheme'), 'the page has a title, a viewport, a heading, drawings and a dark scheme');
const nh = py(['-I', path.join(R, 'no_history.py'), PAGE]);
ok(nh.status === 0 && (nh.stdout || '').includes(PAGE + ' 0 hits'), 'the page holds none of the patterns of history of reports/no_history.py: ' + (nh.stdout || nh.stderr || '').split('\n').filter(l => /^ +P|[1-9]\d* hits/.test(l)).slice(0, 3).join(' | '));
for (const f of ['symmetry_note_check.py', 'build_note.py']) ok(rd(path.join(N, f)).startsWith('#!/usr/bin/env python3\n# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n# Required Notice: Copyright (c) 2026 the Cascade Atlas authors\n'), f + ' carries the licence header');
// no address or machine path in any file of the folder
ok(inFolder.every(f => { const t = rd(path.join(N, f)); return !/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/.test(t) && !/mailto:|\/tmp\/|\/home\/|\/root\/|[A-Za-z]:\\/.test(t); }), 'no e-mail address, mail link or path of a machine in any file of reports/note/');

// ---- (a4) the numbers and the ids of the page are those of the logs
const logOf = f => rd(f).split('\n');
const NL = logOf(path.join(N, 'logs', 'symmetry_note_check.log')), SAB = logOf(path.join(N, 'logs', 'symmetry_note_check_sabotage.log')).filter(l => l.startsWith('sabotage'));
const okIds = NL.map(l => /^ok\s+(M\d+)\s/.exec(l)).filter(Boolean).map(m => m[1]), infoN = NL.filter(l => l.startsWith('info')).length;
ok(JSON.stringify(okIds) === JSON.stringify(Array.from({ length: 15 }, (_, i) => 'M' + i)) && infoN === 1 && NL.some(l => l === 'ALL SLIDE CHECKS PASS (14 check functions; M0-M14)') && !NL.some(l => /^FAIL/.test(l)), 'the log holds ok lines M0 to M14, one info line, the PASS line and no FAIL');
ok(SAB.length === 8 && SAB.every((l, i) => l.startsWith('sabotage ' + (i + 1) + ': exit 1, stopped in check_M')), 'the sabotage log holds eight variants, each of which exits 1 at a named check');
const T = H.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<svg[\s\S]*?<\/svg>/g, ' ').replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ');
// two names that look like check ids and are not: the matrix algebra M32(C), and finding F10 of the Schuller report (named so in the text)
const NOT_IDS = ['M32(ℂ)', 'F10 of the Atlas’s Schuller report', 'the F10 picture'];
ok(NOT_IDS.every(x => T.includes(x)), 'the page names the matrix algebra M32(ℂ) and the finding F10 of the Schuller report in those words');
const TI = NOT_IDS.reduce((t, x) => t.split(x).join(' '), T);
ok(/15 of 15 checks pass \(M0.M14\)/.test(T) && /1 info line/.test(T) && /8 of 8 deliberately broken variants/.test(T), 'the page states 15 of 15 checks, 1 info line and 8 of 8 broken variants, as the logs hold them');
const named = new Set([...TI.matchAll(/\bM(\d{1,2})\b/g)].map(m => 'M' + m[1]));
const svgText = [...H.matchAll(/<svg[\s\S]*?<\/svg>/g)].map(m => m[0].replace(/<[^>]+>/g, ' ')).join(' ');
for (const m of svgText.matchAll(/\bM(\d{1,2})\b/g)) named.add('M' + m[1]);
ok([...named].every(i => okIds.includes(i)), 'every M id the page names exists in the log: ' + [...named].filter(i => !okIds.includes(i)).join(' '));
const notNamed = okIds.filter(i => !named.has(i));
ok(notNamed.length === 0, 'every id of the note\'s log is named on the page (the rerun block names the first and last): ' + notNamed.join(' '));
const FA = logOf(path.join(R, 'furey', 'logs', 'furey_papers_check.log')), FB = logOf(path.join(R, 'furey', 'logs', 'furey_construction_check.log'));
const atlasIds = new Set([...FA, ...FB].map(l => /^ok\s+([A-Z]\d+):?\s/.exec(l)).filter(Boolean).map(m => m[1]));
const pageAtlas = new Set([...(TI + ' ' + svgText).matchAll(/\b([ARTFCPNB])(\d{1,2})\b/g)].map(m => m[1] + m[2]).filter(i => !/^M/.test(i)));
const unknown = [...pageAtlas].filter(i => !atlasIds.has(i));
ok(pageAtlas.size >= 15 && unknown.length === 0, `every Atlas check id the page names (${pageAtlas.size}) is an ok line of the Furey report's logs: ` + unknown.join(' '));
// the statements of the Atlas that the figures quote: the dimensions of the Spin(10) line and the SU(5) line, the counts of generations
const R7 = FA.find(l => /^ok\s+R7:?\s/.test(l)) || '', R8 = FA.find(l => /^ok\s+R8:?\s/.test(l)) || '', B12 = FB.find(l => /^ok\s+B12:?\s/.test(l)) || '', N2 = FA.find(l => /^ok\s+N2:?\s/.test(l)) || '';
ok(/45 -> 21/.test(R7) && /-> 15/.test(R7) && /-> 11 \(u\(3\)\+u\(1\)\+u\(1\)\) -> 10/.test(R7), 'R7 of the Furey log gives the Spin(10) line 45, 21, 15, 11, 10');
ok(/24 -> 12 \(su\(3\)\+su\(2\)\+u\(1\)\)/.test(R8) && /-> 10 \(quaternionic\) -> 9 \(complex\)/.test(R8), 'R8 of the Furey log gives the SU(5) line 24, 12, 10, 9');
ok(/5,?582/.test(B12) && /5,?582/.test(T), 'B12 gives the 5,582 block structures, and the page quotes that number');
ok(/at most two/.test(T) && /dimension 14/.test(T) && /\b14\b/.test(N2), 'the page gives "at most two" complete generations (B12) apart from the linear count in which three first appear at dimension 14 (N2)');

if (!hasNumpy) { console.log('SKIP the runs of test_note: needs numpy (pip install -r reports/requirements.txt)'); }
else {
  // ---- (b1) the check script gives its stored log
  const run = py(['-I', path.join(N, 'symmetry_note_check.py')]);
  ok(run.status === 0 && run.stdout === NL.join('\n'), 'symmetry_note_check.py gives the stored log line for line: ' + (run.status !== 0 ? (run.stderr || '').split('\n').slice(-3).join(' | ') : ''));
  // ---- (b2) two of the broken variants stop where the log says
  for (const k of [1, 3]) {
    const r = py(['-I', path.join(N, 'symmetry_note_check.py'), '--sabotage', String(k)]);
    const want = SAB[k - 1] || '', stop = /stopped in (check_M\d+)/.exec(want), last = /last passing id (\S+),/.exec(want);
    const lastOk = (r.stdout.match(/^ok\s+(M\d+)\s/gm) || []).map(l => l.split(/\s+/)[1]).pop() || '-';
    ok(r.status === 1 && /AssertionError/.test(r.stderr) && stop && last && r.stderr.includes(stop[1]) && lastOk === last[1], `variant ${k} stops in ${stop && stop[1]} after ${last && last[1]}, as the sabotage log says (exit ${r.status}, last ok ${lastOk})`);
  }
  // ---- (b3) the builder rebuilds the page byte for byte
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'note-')); process.on('exit', () => fs.rmSync(tmp, { recursive: true, force: true }));
  const out = path.join(tmp, 'page.html'), b = py(['-I', path.join(N, 'build_note.py'), '--out', out]);
  ok(b.status === 0 && fs.existsSync(out) && Buffer.compare(fs.readFileSync(out), fs.readFileSync(PAGE)) === 0, 'build_note.py rebuilds reports/html/symmetry_breaking_note.html byte for byte: ' + (b.stderr || '').split('\n').slice(-3).join(' | '));
}
console.log(`test_note: ${checks - bad}/${checks} checks passed`);
process.exit(bad ? 1 : 0);
