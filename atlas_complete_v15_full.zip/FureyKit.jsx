// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Tx } from './MathText.jsx';
import { Pts, KIT_STYLE } from './LensKit.jsx';
import { Intro, Fold } from './Fold.jsx';
import { isLearner } from './Formal.jsx';
import { FOLD, level } from './audienceCopy.js';
import { FW_STYLE } from './FureyWidgets.jsx';

// The frame the four new tabs of the Furey page share (her papers, her 2026 model, three generations, what may help): a head (eyebrow, title, introduction in
// three voices), sections that each hold a widget and the statements of fureyCopy.js, and, for the Young Learner, one closed fold "For older readers" that holds the
// formal statements of every section. A section is { h, hy, yl: [plain paragraphs], p: [[tags, text]], m: [[tags, text]] }: the Physicist reads p, the Mathematician
// p and m, the Young Learner reads yl (plain words, no formulas) and finds p and m in the fold.
export const FY_STYLE = KIT_STYLE + FW_STYLE + `
.fy{max-width:1000px;margin:28px auto;padding:0 16px}.fy>h2{margin:.2rem 0 .6rem}.fy .fw-sec>h3{margin:0 0 .5em}
.fy .fy-yl p{margin:.5em 0}.fy .f-card{border:1px solid rgba(160,170,200,.28);border-radius:14px;padding:1rem 1.2rem;margin:1rem 0;background:rgba(120,130,170,.07)}
.fy .f-badge{display:inline-block;font-size:.72rem;letter-spacing:.04em;padding:.15rem .6rem;border-radius:99px;border:1px solid;margin:0 .5rem .4rem 0}
.fy .f-card h4{margin:.3em 0 .4em;font-size:1em}.fy .f-card p{margin:.3em 0}.fy .fy-note{font-size:.8rem;opacity:.75}
.fy .fy-q{margin:.4em 0;padding-left:1.1em}.fy .fy-q li{margin:.3em 0}.fy .fy-mono{font-family:ui-monospace,Menlo,monospace;font-size:.82em;overflow-wrap:anywhere}
.fy .fy-box{border:1px solid rgba(128,128,128,.3);border-radius:10px;padding:10px 14px;margin:12px 0}`;

export const statements = (s, M) => [...(s.p || []), ...(M ? (s.m || []) : [])];
export const isM = profile => level(profile) === 2;

export function Head({ lang, profile, id, c, hid }) {
  return <><style>{FY_STYLE}</style><p className="eyebrow"><Tx>{c.eyebrow}</Tx></p><h2 id={hid}><Tx>{isLearner(profile) ? c.titleY : c.title}</Tx></h2><Intro lang={lang} profile={profile} id={id} lede={c.lede} /></>;
}

export function Sec({ lang, profile, id, s, children, after }) {
  const yl = isLearner(profile);
  return <div className="fw-sec" id={id} data-sec={id}><h3><Tx>{yl ? (s.hy || s.h) : s.h}</Tx></h3>{children}
    {yl ? <div className="fy-yl">{(s.yl || []).map((t, i) => <p key={i}><Tx>{t}</Tx></p>)}</div> : (statements(s, isM(profile)).length ? <Pts items={statements(s, isM(profile))} lang={lang} /> : null)}{after}</div>;
}

// the Young Learner's closed fold: the formal statements of the listed sections (and anything else the tab wants in it)
export function Older({ lang, profile, secs, extra = null }) {
  if (!isLearner(profile)) return null;
  return <Fold title={(FOLD[lang] || FOLD.en).older} open={false}>{secs.map(([id, s]) => (statements(s, true).length ? <div key={id}><h4><Tx>{s.h}</Tx></h4><Pts items={statements(s, true)} lang={lang} /></div> : null))}{extra}</Fold>;
}
