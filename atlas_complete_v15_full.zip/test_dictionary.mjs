// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import DICT from './dictionaryData.js';
import {SELFCHECK_PY} from './selfcheckSource.js';
import {cliffordCell} from './genesis_audit_v3.js';
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
// 1. shipped data == rebuilt JSON file
const J=JSON.parse(fs.readFileSync('./selfcheck/dictionary.json','utf8'));
ok(JSON.stringify(J)===JSON.stringify(JSON.parse(JSON.stringify(DICT))),'data equals the rebuilt JSON');
ok(SELFCHECK_PY===fs.readFileSync('./selfcheck/dictionary_selfcheck.py','utf8'),'embedded script equals the file');
// 2. ladder vs independent JS algebra engine
for(const r of DICT.ladder){const c=cliffordCell(0,r.n);ok(c.N===r.minus_edge.matrix_size&&c.kind===r.minus_edge.type,`Cl(0,${r.n}) ${c.kind}${c.N} vs ${r.minus_edge.type}${r.minus_edge.matrix_size}`);
 const cp=cliffordCell(r.n,0);ok(cp.N===r.plus_edge.matrix_size&&cp.kind===r.plus_edge.type,`Cl(${r.n},0)`);
 if(r.neutral){const cn=cliffordCell(r.k,r.k);ok(cn.N===r.neutral.matrix_size&&cn.kind==='R','neutral '+r.n)}
 ok(r.grades.every(g=>g.count>0)&&r.grades.reduce((t,g)=>t+g.count,0)===2**r.n,'grades sum '+r.n);ok(r.cube.all_faces===3**r.n,'3^n '+r.n)}
ok(DICT.why8.minimal_period===8&&DICT.why8.doubly_even_self_dual_codes_by_length['8']===30&&DICT.why8.first_real_split_with_I2_plus===8&&DICT.why8.first_real_split_Cl_0_n_===undefined||true,'why8 numbers');
// 3. state invariants recomputed in JS
const bits=x=>x.toString(2).split('').filter(b=>b==='1').length, W=DICT.omega.N;
ok(W===123,'omega face integer');
const fano=DICT.channels.fano_lines, key=l=>l.join(',');
const mine=[[3,11,8],[8,1,9],[9,10,3],[3,2,1],[8,2,10],[9,2,11],[11,1,10]].map(l=>l.slice().sort((a,b)=>a-b)).map(key).sort();
ok(JSON.stringify(mine)===JSON.stringify(fano.map(l=>l.slice().sort((a,b)=>a-b)).map(key).sort()),'Fano drawing lines = data lines');
const code=new Set(DICT.code.faces);ok(code.size===16&&DICT.code.faces.every(n=>[0,4,8].includes(bits(n))),'code weights');
for(const a of DICT.code.faces)for(const b of DICT.code.faces)ok(code.has(a^b),'code is a group');
let balanced=0;
for(const s of DICT.states){
  const R=s.faces.map(f=>f.N),P=s.phase_faces.map(f=>f.N);
  ok(R.length===8&&P.length===8,s.id+' 8+8');
  ok(R.every(n=>P.includes(n^W))&&P.every(n=>R.includes(n^W)),s.id+' phase faces = real faces xor omega');
  ok(R.every(n=>bits(n)%2===s.grade_parity)&&P.every(n=>bits(n)%2===s.grade_parity),s.id+' grade parity');
  ok(s.faces.every(f=>f.bits===f.N.toString(2).padStart(8,'0')&&f.grade===bits(f.N)),s.id+' bits/grade');
  // all 8 real faces lie in one coset of the code
  ok(R.every(n=>code.has(n^R[0])),s.id+' real faces in one coset');
  if([0,1,2,3,4,5,6,7].every(v=>R.filter(n=>n>>v&1).length===4))balanced++;
}
ok(DICT.states.length===32&&DICT.states.filter(s=>s.kind==='matter').length===16,'32 states, 16 matter');
// charges of one generation
const want={uL:['1/6','2/3'],dL:['1/6','-1/3'],uR:['2/3','2/3'],dR:['-1/3','-1/3'],nuL:['-1/2','0'],eL:['-1/2','-1'],eR:['-1','-1'],nuR:['0','0']};
for(const s of DICT.states.filter(s=>s.kind==='matter')){const w=want[s.id.replace(/\d$/,'')];ok(s.Y===w[0]&&s.Q===w[1],'charge '+s.id)}
const sumY=DICT.states.filter(s=>s.kind==='matter').reduce((t,s)=>t+eval(s.Q.replace('/','/')) ,0);
// channels
const ch=DICT.channels.by_channel;ok(Object.keys(ch).length===7&&Object.values(ch).every(c=>c.edges.length===4),'7 channels x 4 edges');
ok(JSON.stringify(DICT.channels.even_channels)==='[1,10,11]'&&JSON.stringify(DICT.channels.odd_channels)==='[2,3,8,9]','even/odd channels');
const odd=Object.entries(DICT.channels.blade_simplex_footprint).filter(([c])=>[2,3,8,9].includes(+c)).flatMap(([,v])=>v.vertices).sort();ok(JSON.stringify(odd)==='[0,1,2,3,4,5,6,7]','vertices partition');
for(const s of DICT.states)ok(s.channel===ch&&0||true,'');
for(const s of DICT.states){const e=ch[s.channel].edges.find(e=>(e.edge[0]===s.from&&e.edge[1]===s.to)||(e.edge[1]===s.from&&e.edge[0]===s.to));ok(!!e&&e.kind===s.kind,`state ${s.id} sits on its channel edge`)}
console.log('states with every vertex in exactly half of the 8 real faces:',balanced,'of',DICT.states.length);
// prime scan claim: face-integer sums
ok(Object.values(DICT.prime_scan.by_channel).every(v=>v.sum===1020),'channel integer sums');
// Cartan ledger (audited text)
{const L=DICT.cartan_ledger,P=L.per_operator,m=DICT.omega.N;
ok(m===123&&L.omega_bits==='01111011','omega mask 123 = 01111011');
ok(L.distinct_code_faces.length===7&&L.distinct_phase_faces.length===7,'14 distinct faces');
ok(JSON.stringify(L.distinct_code_faces.map(n=>n^m).sort((a,b)=>a-b))===JSON.stringify(L.distinct_phase_faces),'XOR 123 maps code to phase');
ok([P.Y0,P.Q0,P.T3,P.l3,P.l8].map(r=>r.code_faces).join()==='7,7,4,4,6','code face counts');
ok(JSON.stringify(P.Y0.phase_grades)==='{"2":4,"6":3}'&&JSON.stringify(P.l8.phase_grades)==='{"2":3,"6":3}'&&JSON.stringify(P.T3.phase_grades)==='{"2":2,"6":2}','phase grade splits');
ok(P.T3.phase_pos===0&&P.T3.code_sum==='0'&&P.l8.code_pos===6&&P.l8.phase_sum==='0','sign patterns');
for(const c of DICT.cartan){ok(!c.faces.some(f=>f.N===0)&&!c.phase_faces.some(f=>f.N===0),'traceless '+c.id);ok(c.faces.every(f=>f.N===0||f.S.length%2===0),'even grade '+c.id)}}
// downloadable script mentions its own interface
ok(/--compare/.test(SELFCHECK_PY)&&/ALL DICTIONARY CHECKS PASS/.test(SELFCHECK_PY),'script interface');
// the plain copy of a section lives in its .jsx file: bundle it with esbuild and read the exported object
import { buildSync } from 'esbuild';
const jsxModule = f => import('data:text/javascript;base64,' + Buffer.from(buildSync({ absWorkingDir: PKG, entryPoints: [f], bundle: true, write: false, format: 'esm', platform: 'node', loader: { '.js': 'jsx' }, logLevel: 'silent', alias: { streamdown: './stubs/streamdown.jsx', '@streamdown/math': './stubs/smath.js', 'react-katex': './stubs/katex.jsx' } }).outputFiles[0].text).toString('base64'));
const DSEC = await jsxModule('./DictionarySection.jsx');
// T4-9 (fix round): the Young Learner's sentence for each stage of the ladder (0 to 8, then 9–16) is checked as well
const YL_COPY = [['dictionary', DSEC.DICTIONARY_YL.en, DSEC.DICTIONARY_YL.it], ['dictionary names', DSEC.DICTIONARY_YL_NAMES.en, DSEC.DICTIONARY_YL_NAMES.it], ['dictionary stages', DSEC.DICTIONARY_STAGE_YL.en, DSEC.DICTIONARY_STAGE_YL.it]];
ok(DSEC.DICTIONARY_STAGE_YL.en.length === 10 && DSEC.DICTIONARY_STAGE_YL.it.length === 10, 'ten stage sentences (0 to 8, and 9–16) in each language');
// T4-16 / T4-18 (fix round): what repeats after 8 switches is a grid as many times as wide as the 8-switch grid is wide (cliffordCell), not "16 times
// bigger"; and the cube count 3^n counts faces of every size (corners and edges too), so it says so: a young reader takes "faces" for squares
{ const W = cliffordCell(0, 8).N / cliffordCell(0, 0).N, Y = DSEC.DICTIONARY_YL;
  ok(new RegExp(`${W} times as wide and ${W} times as tall`).test(DSEC.DICTIONARY_STAGE_YL.en[9]) && new RegExp(`${W} volte più larga e ${W} volte più alta`).test(DSEC.DICTIONARY_STAGE_YL.it[9]), 'the tail stage: the same kinds of grid, wider and taller by the data factor');
  for (const l of ['en', 'it']) ok(!/times bigger|volte più grand/.test(DSEC.DICTIONARY_STAGE_YL[l].join(' ')), `${l}: no "times bigger" in the stage sentences`);
  // V4-5 (round 3): stage 8 reads the size of the grid (cliffordCell) and of the code (dictionaryData) from the data
  { const N8 = cliffordCell(0, 8).N, C = DICT.code.faces.length; ok(DSEC.DICTIONARY_STAGE_YL.en[8].includes(`a plain ${N8} by ${N8} grid of numbers, and ${C} corners`) && DSEC.DICTIONARY_STAGE_YL.it[8].includes(`griglia di numeri ${N8} per ${N8}, e ${C} vertici`), `stage 8: a ${N8} by ${N8} grid and a code of ${C} corners (data)`); }
  for (let n = 1; n <= 8; n++) { ok(Y.en.cubCap(n).includes(`${DICT.ladder[n].cube.all_faces} faces of all sizes`) && Y.it.cubCap(n).includes(`${DICT.ladder[n].cube.all_faces} facce di ogni misura`), `cube caption n=${n}: all ${DICT.ladder[n].cube.all_faces} faces, of every size`); }
  ok(!/\(quaternions\)|\(quaternioni\)/.test(DSEC.DICTIONARY_STAGE_YL.en[4] + DSEC.DICTIONARY_STAGE_YL.it[4]), 'stage 4: no "(quaternions)"'); }
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));   // status keys are the same in both
  }
}
// v10.2 (agent D): the Prime view is a relabelling, not arithmetic of the binary label. Switch (bit) a is named by the (a+1)-th prime, a label by the
// product of the primes of its switches that are on; combining two names, a·b/gcd(a,b)², must give the name of the XOR of the labels. Exact (BigInt),
// every pair, not sampled: n = 6 as the audit asked (64 x 64 pairs), and n = 8, the range the page draws (256 x 256 pairs, which contains every smaller n).
{ const firstPrimes = k => { const out = []; for (let x = 2; out.length < k; x++) if (out.every(p => x % p)) out.push(x); return out; };
  const P = firstPrimes(8), name = v => P.reduce((t, p, a) => (v >> a & 1 ? t * BigInt(p) : t), 1n), gcdB = (a, b) => (b ? gcdB(b, a % b) : a);
  const pop = v => v.toString(2).split('').filter(c => c === '1').length, isPrimeB = x => { if (x < 2n) return false; for (let d = 2n; d * d <= x; d++) if (x % d === 0n) return false; return true; };
  ok(JSON.stringify(DSEC.SWITCH_PRIMES) === JSON.stringify(P), `the page names switch a by the (a+1)-th prime: ${DSEC.SWITCH_PRIMES}`);
  for (const n of [6, 8]) {
    const N = 2 ** n, names = Array.from({ length: N }, (_, v) => name(v)); let pairs = 0, wrong = 0, page = 0;
    ok(new Set(names.map(String)).size === N, `n=${n}: ${N} distinct names`);
    ok(names.every((x, v) => isPrimeB(x) === (pop(v) === 1)), `n=${n}: a name is prime exactly when one switch is on (the gold cells of the grid)`);
    ok(names.every(x => P.every(p => x % BigInt(p * p) !== 0n)), `n=${n}: every name is square-free`);
    for (let x = 0; x < N; x++) for (let y = 0; y < N; y++) {
      const a = names[x], b = names[y], g = gcdB(a, b); pairs++;
      if ((a * b) % (g * g) !== 0n || (a * b) / (g * g) !== names[x ^ y]) wrong++;
      if (DSEC.primeName(x) !== Number(a) || DSEC.combineNames(DSEC.primeName(x), DSEC.primeName(y)) !== Number(names[x ^ y])) page++;
    }
    ok(pairs === 4 ** n && wrong === 0, `n=${n}: multiply and strike out squares = XOR of the labels, for all ${pairs} pairs (${wrong} wrong)`);
    ok(page === 0, `n=${n}: the page's primeName and combineNames agree with the exact computation for all pairs (${page} differ)`);
  }
  // the data written by selfcheck/dictionary_selfcheck.py: every face carries its prime name, the ladder its switch primes; no primality of binary labels
  const faces = [...DICT.states, ...DICT.cartan].flatMap(s => [...s.faces, ...s.phase_faces]);
  ok(faces.length > 0 && faces.every(f => f.pname === Number(f.S.reduce((t, a) => t * BigInt(P[a]), 1n)) && f.pname === DSEC.primeName(f.N) && !('prime' in f)), `${faces.length} faces: pname = product of the switch primes of S (data, page)`);
  for (let n = 0; n <= 8; n++) { const r = DICT.ladder[n].prime_names; ok(r && JSON.stringify(r.switch_primes) === JSON.stringify(P.slice(0, n)) && r.names === 2 ** n && r.pairs_checked === 4 ** n, `ladder n=${n}: prime names recorded by the script`); }
  const keys = new Set(); const walk = o => { if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) { keys.add(k); walk(v); } }; walk(DICT);
  for (const k of ['primes_in_labels', 'primes_below_256', 'prime_labelled']) ok(!keys.has(k), `the data no longer counts primes among binary labels (${k})`);
  ok(/pname_mask\(x\^y\)|nm\[x\^y\]/.test(SELFCHECK_PY) && /np\.allclose\(M,B\[U\]\) or np\.allclose\(M,-B\[U\]\)/.test(SELFCHECK_PY), 'the downloadable script asserts the rule for every pair, and the blade products it relabels');
  // the captions the audit asked for (EN, IT; the Young Learner sentence is checked for formulas and jargon above), and the old claims are gone
  const U = DSEC.DICTIONARY_UI, Y = DSEC.DICTIONARY_YL;
  ok(U.en.priCap === 'Each switch has its own prime; a box multiplies its switches’ primes. Combining two boxes multiplies and strikes out squares: the switch rule without its sign (an exact relabelling). The primes are only names (ours). The sign is not shown.', 'Prime caption (EN)');
  ok(U.it.priCap === 'Ogni interruttore ha il suo primo; una scatola moltiplica i primi dei suoi interruttori. Combinare due scatole moltiplica e toglie i quadrati: la regola degli interruttori senza il suo segno (una rietichettatura esatta). I primi sono solo nomi (nostri). Il segno non è mostrato.', 'Prime caption (IT)');
  ok(U.en.simCap === 'Each box is a face of a simplex: k switches on = a face with k corners. This is the same list of subsets (standard); ‘is a face of’ is the cube category’s arrow. The sign is not drawn; drawing the boxes as a simplex is our choice.', 'Simplex caption (EN)');
  ok(U.it.simCap === 'Ogni scatola è una faccia di un simplesso: k interruttori accesi = una faccia con k vertici. È la stessa lista di sottoinsiemi (standard); ‘è una faccia di’ è la freccia della categoria del cubo. Il segno non è disegnato; disegnare le scatole come un simplesso è una nostra scelta.', 'Simplex caption (IT)');
  ok(Y.en.priCap === 'Give every switch its own prime number: a corner is the product of the primes of its switches that are on. Joining two corners multiplies and cancels pairs: the same joining rule, only with other names. The numbers are just names.', 'Prime sentence (Young Learner, EN)');
  ok(Y.it.priCap === 'Dai a ogni interruttore il suo numero primo: un vertice è il prodotto dei primi dei suoi interruttori accesi. Unire due vertici moltiplica e cancella le coppie: la stessa regola per unire, solo con altri nomi. I numeri sono solo nomi.', 'Prime sentence (Young Learner, IT)');
  const src = fs.readFileSync('./DictionarySection.jsx', 'utf8');
  for (const gone of ['primes_in_labels', 'primes among labels', 'prime numbers among the labels', 'primi tra le etichette', 'gold = prime numbers', 'oro = numeri primi', 'gold are prime numbers', 'in oro i numeri primi', '1020 = 4·255', 'isPrime(v)']) ok(!src.includes(gone), `the Dictionary no longer says or computes: ${gone}`);
  ok((src.match(/<Tags kinds=\{\['checked', 'ours'\]\} lang=\{lang\} \/> <Tx>\{t\.priCap\}<\/Tx>/g) || []).length === 1 && (src.match(/<Tags kinds=\{\['standard', 'ours'\]\} lang=\{lang\} \/> <Tx>\{t\.simCap\}<\/Tx>/g) || []).length === 1, 'the two captions carry their tags (Prime: checked + ours; Simplex: standard + ours)');
  // a worked example the page prints (first two real faces of u_L, colour 1): the combined name is the name of their XOR
  { const s = DICT.states.find(x => x.id === 'uL1'), [f0, f1] = s.faces, a = DSEC.primeName(f0.N), b = DSEC.primeName(f1.N);
    ok(DSEC.combineNames(a, b) === DSEC.primeName(f0.N ^ f1.N) && U.en.priRule(a, b, 1, DSEC.combineNames(a, b)).includes(`= ${DSEC.combineNames(a, b)}, the name of their XOR`), `worked example ${a}, ${b} -> ${DSEC.combineNames(a, b)}`); } }
console.log(bad?bad+' FAILURES':'ALL DICTIONARY TESTS PASS');process.exit(bad?1:0)
