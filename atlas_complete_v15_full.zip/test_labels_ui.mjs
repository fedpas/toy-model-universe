// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from './ui_helpers.mjs';   // playwright's chromium; a browser that cannot start skips the test (exit 77)
import { setLang } from './ui_helpers.mjs';
// The three tabs of the labels (the clock, step 1, on the Conventions page; gauge gravity, step 12, on the equations page; the finite groups, step 17, on the lenses page) in a real browser: every widget is driven (a click, a slider, a switch) and the result it shows is checked
// against what the claim says (the clock place of a cell; the three classes of the spring and of the horizon; complex roots only in Cl(2,2); Weyl 10 + Ricci 10 at n = 4;
// five points of the Golay ring pick exactly one octad of 8; the primes of a rung). The engine itself is tested by test_labels.mjs; here the widgets are tested.
// Run: node test_labels_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`)); };
const txt = (pg, sel) => pg.locator(sel).first().innerText().then(t => t.replace(/\s+/g, ' ').trim());
const goto = async (pg, h) => { await pg.evaluate(x => { location.hash = x; }, h); await pg.waitForTimeout(250); };   // the page and tab a reader reaches by the address
const slide = async (pg, sel, v) => { await pg.locator(sel).first().fill(String(v)); await pg.waitForTimeout(90); };
async function open(w, hash, lang, prof, tag) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce' }), pg = await ctx.newPage(); onErr(pg, tag);
  await pg.goto(APP + hash); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(200);
  return [ctx, pg];
}

// ---- 1. Physicist, English: the three tabs, on their three pages
{ const [ctx, pg] = await open(1100, '#conventions/clock', 'en', 'Physicist', 'en-phys');
  ok(await pg.locator('.tabbar [role=tab]').count() === 2 && /STEP 1 OF 20/.test(await txt(pg, '.ls .eyebrow')), 'two tabs (the Conventions and the clock step), the clock reads STEP 1 OF 20: ' + await txt(pg, '.ls .eyebrow'));
  ok(await pg.locator('.tabbar [data-tab="conventions"]').count() === 1 && !/STEP/.test(await pg.locator('.tabbar [data-tab="conventions"]').innerText()), 'the Conventions tab is the first tab and has no step number');
  // cell lattice: click Cl(1,3): clock place 6, Gauss phase 6 x 45 degrees
  const cell = pg.locator('#ls-lattice [aria-label="Cl(1,3)"]'); await cell.click(); await pg.waitForTimeout(80);
  ok(await cell.getAttribute('aria-pressed') === 'true', 'a cell is selected by a click');
  const lat = await txt(pg, '#ls-lattice table');
  ok(/Cl\(1,3\)/.test(lat) && /phase 6 × 45°/.test(lat), 'Cl(1,3) sits at 6 on the clock and the Gauss sum has phase 6 × 45°: ' + lat.slice(0, 200));
  await pg.locator('#ls-lattice [aria-label="Cl(3,0)"]').click(); await pg.waitForTimeout(80);
  ok(/phase 3 × 45°/.test(await txt(pg, '#ls-lattice table')), 'Cl(3,0) sits at 3 on the clock');
  // the trinity: spring (rotation), no spring (translation), anti-spring (boost)
  const st = async () => txt(pg, '#ls-trinity .ls-state');
  await slide(pg, '#ls-trinity input[type=range]', 1); const s1 = await st();
  await slide(pg, '#ls-trinity input[type=range]', 0); const s0 = await st();
  await slide(pg, '#ls-trinity input[type=range]', -1); const sm = await st();
  ok(/^rotation/.test(s1) && /^translation/.test(s0) && /^boost/.test(sm), `spring +1 / 0 / -1 give rotation / translation / boost: ${s1.slice(0, 20)} | ${s0.slice(0, 20)} | ${sm.slice(0, 20)}`);
  const d0 = await pg.locator('#ls-trinity svg[role=img] path').count();
  ok(d0 > 0, 'the phase portrait draws orbits (' + d0 + ' paths)');
  // bivector lab: complex in Cl(2,2) only
  const verdict = () => txt(pg, '#ls-biv .ls-state');
  const v22 = await verdict();
  ok(/complex/i.test(v22) && /3/.test(await txt(pg, '#ls-biv table')), 'the preset in Cl(2,2) has complex roots (discriminant -3): ' + v22);
  const rowsOf = async () => pg.locator('#ls-biv .ls-barrow').evaluateAll(es => es.map(e => [e.querySelector('.ls-bl').textContent.trim(), e.querySelector('.ls-bv').textContent.trim()]));
  const bars = await rowsOf();
  ok(bars.length === 5 && bars.every(([k, v]) => (k === 'Cl(2,2)') === (v !== '0%')), 'among 400 bivectors per signature only Cl(2,2) has complex roots: ' + JSON.stringify(bars));
  await pg.locator('#ls-biv .ls-chip', { hasText: 'Cl(4,0)' }).first().click(); await pg.waitForTimeout(80);
  const v40 = await verdict(); ok(!/complex/i.test(v40) || /not|no\b/i.test(v40), 'the same numbers in Cl(4,0) do not give complex roots: ' + v40);
  await pg.locator('#ls-biv .ls-chip', { hasText: 'Cl(2,2)' }).first().click(); await pg.waitForTimeout(80);
  ok(await verdict() === v22, 'back to Cl(2,2): complex again');
  await pg.locator('#ls-biv .ls-chip').nth(6).click().catch(() => {}); // a preset chip: the page must not fail
  // gauge tab
  await goto(pg, '#equations/gauge');
  ok(await pg.locator('.ls-glance').count() === 1 && await pg.locator('aside.glance').count() === 0, 'the gauge-gravity tab shows one status strip, its own (its Map node adds no second one)');
  ok(/STEP 12 OF 20/.test(await txt(pg, '.ls .eyebrow')), 'the gauge tab reads STEP 12 OF 20');
  const hz = () => txt(pg, '#ls-horizon .ls-state');
  await slide(pg, '#ls-horizon input[type=range]', 3); const out = await hz();
  await slide(pg, '#ls-horizon input[type=range]', 1); const hor = await hz();
  await slide(pg, '#ls-horizon input[type=range]', 0.5); const ins = await hz();
  ok(/^outside/.test(out) && /^on the horizon/.test(hor) && /^inside/.test(ins), `the radial gradient is spacelike outside, null on the horizon, timelike inside: ${out.slice(0, 14)} | ${hor.slice(0, 18)} | ${ins.slice(0, 14)}`);
  const rainA = await pg.locator('#ls-horizon polyline').getAttribute('points');
  await pg.locator('#ls-horizon input[type=checkbox]').check(); await pg.waitForTimeout(90);
  const rainB = await pg.locator('#ls-horizon polyline').getAttribute('points');
  ok(rainA && rainB && rainA !== rainB, 'reversing time changes the falling raindrop');
  await pg.locator('#ls-curv .ls-chip', { hasText: 'n = 4' }).click(); await pg.waitForTimeout(80);
  ok(/Riemann 20 = Ricci 10 \+ Weyl 10/.test(await txt(pg, '#ls-curv .ls-mono')), 'n = 4: Riemann 20 = Ricci 10 + Weyl 10: ' + (await txt(pg, '#ls-curv .ls-mono')).slice(0, 80));
  await pg.locator('#ls-curv .ls-chip', { hasText: 'n = 3' }).click(); await pg.waitForTimeout(80);
  ok(/Riemann 6 = Ricci 6 \+ Weyl 0/.test(await txt(pg, '#ls-curv .ls-mono')), 'n = 3: Weyl is zero: ' + (await txt(pg, '#ls-curv .ls-mono')).slice(0, 80));
  // groups tab
  await goto(pg, '#lenses/groups');
  ok(await pg.locator('.ls-glance').count() === 1 && await pg.locator('aside.glance').count() === 0, 'the finite-groups tab shows one status strip, its own (its Map node adds no second one)');
  ok(/STEP 17 OF 20/.test(await txt(pg, '.ls .eyebrow')), 'the groups tab reads STEP 17 OF 20');
  const rails = async k => { await pg.locator('#ls-rails .ls-chip', { hasText: `n = ${k}` }).click(); await pg.waitForTimeout(80); return txt(pg, '#ls-rails'); };
  const r8 = await rails(8), r6 = await rails(6), r2 = await rails(2);
  ok(r8 !== r6 && r6 !== r2 && r8.length > 100, 'the two rails change with n');
  // Golay: four points leave several octads, a fifth leaves exactly one: 8 gold points
  const gold = () => pg.locator('#ls-golay svg[role=group] circle').evaluateAll(cs => cs.filter(c => c.getAttribute('fill') === '#fbbf24').length);
  const pressed = () => pg.locator('#ls-golay [aria-label^="point"][aria-pressed="true"]').count();
  for (const i of [0, 1, 2, 3]) await pg.locator(`#ls-golay [aria-label="point ${i}"]`).click();
  const g4 = [await pressed(), await gold()];
  await pg.locator('#ls-golay [aria-label="point 4"]').click(); await pg.waitForTimeout(80);
  const g5 = [await pressed(), await gold()];
  ok(g4[0] === 4 && g4[1] === 0 && g5[0] === 5 && g5[1] === 8, `Golay ring: 4 points -> no single octad (${g4}); 5 points -> exactly one octad of 8 (${g5})`);
  await pg.locator('#ls-golay .ls-btn').first().click(); await pg.waitForTimeout(80);
  ok(await pressed() === 0 && await gold() === 0, 'Clear empties the ring');
  await pg.locator('#ls-golay .ls-btn').nth(1).click(); await pg.waitForTimeout(80);
  ok(await pressed() === 5 && await gold() === 8, 'the demo button picks five points of an octad and shows it');
  // primes of a rung: 2^11 - 1 = 23 x 89, and 23 is a Monster prime, 89 is not
  await slide(pg, '#ls-primes input[type=range]', 11);
  const pr = await pg.locator('#ls-primes .ls-prime').evaluateAll(es => es.map(e => [e.textContent, e.classList.contains('m')]));
  ok(JSON.stringify(pr) === JSON.stringify([['23', true], ['89', false]]), 'rung 11: 23 (a Monster prime) and 89: ' + JSON.stringify(pr));
  await slide(pg, '#ls-primes input[type=range]', 2);
  ok(JSON.stringify(await pg.locator('#ls-primes .ls-prime').allTextContents()) === '["3"]', 'rung 2: the prime 3');
  await ctx.close(); }

// ---- 2. Mathematician: the formal introduction; Young Learner: plain words, pictures work; Italian: translated labels
{ const [ctx, pg] = await open(1100, '#conventions/clock', 'en', 'Mathematician', 'en-math');
  ok(/Bott/.test(await txt(pg, '.ls .lede')), 'the Mathematician intro is the formal one (Bott periodicity)');
  await ctx.close(); }
{ const [ctx, pg] = await open(375, '#conventions/clock', 'en', 'Young Learner', 'en-yl');
  const c = pg.locator('#ls-lattice [aria-label="1 plus, 3 minus"]'); await c.click(); await pg.waitForTimeout(80);
  ok(/1 plus · 3 minus/.test(await txt(pg, '#ls-lattice table')), 'Young Learner: a box is picked in words (1 plus · 3 minus)');
  ok(await pg.locator('.ls-glance').count() === 0, 'Young Learner: no status strip');
  for (const h of ['#equations/gauge', '#lenses/groups']) { await goto(pg, h); ok(await pg.locator('.ls-glance, aside.glance').count() === 0, `Young Learner: no status strip on ${h}`); }
  ok(await pg.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), 'Young Learner at 375 px: no horizontal scroll');
  await ctx.close(); }
{ const [ctx, pg] = await open(1100, '#conventions/clock', 'it', 'Physicist', 'it-phys');
  ok(/PASSO 1 DI 20/.test(await txt(pg, '.ls .eyebrow')), 'Italian: PASSO 1 DI 20');
  await pg.locator('#ls-lattice [aria-label="Cl(1,3)"]').click(); await pg.waitForTimeout(80);
  ok(/fase 6 × 45°/.test(await txt(pg, '#ls-lattice table')), 'Italian: the Gauss row says "fase", not "phase"');
  await ctx.close(); }
{ const [ctx, pg] = await open(375, '#lenses/groups', 'it', 'Young Learner', 'it-yl');
  ok(await pg.locator('#ls-golay [aria-label="point 0"]').count() === 1, 'a deep link opens the groups tab (Italian, Young Learner)');
  await goto(pg, '#conventions/clock');
  ok(await pg.locator('#ls-lattice [aria-label="1 più, 3 meno"]').count() === 1, 'Italian Young Learner: the boxes are named in Italian');
  await ctx.close(); }

await b.close();
console.log(bad ? `${bad} FAILURES of ${n}` : `LABELS UI OK (${n} checks)`);
process.exit(bad ? 1 : 0);
