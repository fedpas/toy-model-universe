// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { Tx } from './MathText.jsx';
import { TUTORIAL_PAGE, TUTORIAL_LINK, HIDE_FOR } from './tutorialLinkCopy.js';
// One short block at the end of the first page, after the genesis adventure: a line and a link to the tutorial page, which opens in a new tab.
export default function TutorialLink({ lang, profile }) {
  if (HIDE_FOR.includes(profile)) return null;
  const L = TUTORIAL_LINK[lang === 'it' ? 'it' : 'en'];
  return <section className="tutorial-link" data-tutorial-link><p><Tx>{L.lead}</Tx> <a className="link-btn" href={TUTORIAL_PAGE} target="_blank" rel="noopener" data-tutorial-open><Tx>{L.open}</Tx></a></p></section>;
}
