// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The theme switch without a browser (v10.2; theme.js): the three values auto | light | dark and nothing else, default dark; the address (?theme=) beats
// the stored choice (atlas.theme), which beats the default; blocked storage throws nowhere and the choice then lasts in memory; auto follows the system.
// The light theme is one filter on <html> plus overrides: every rule of it sits under html[data-theme="light"] (so the dark page has no new rule), every
// rule of the reader filter under main[data-rf="known"...] (so with the filter off no rule applies), no hex colour sits outside the light override
// block of theme.js, and the shell files have exactly the colours they had in v10.1. The deepened colours: 8:1 or more on the light page, 4.5:1 at
// 78 % opacity, the hue kept. (The browser half, with screenshots: test_theme_ui.mjs.)   Run: node test_theme.mjs
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8');
const T = await import('./theme.js');

// ---- 1. the values and the order of precedence (pure functions)
ok(JSON.stringify(T.THEMES) === '["auto","light","dark"]' && T.DEFAULT_THEME === 'dark' && T.THEME_KEY === 'atlas.theme', 'three values auto | light | dark, default dark, key atlas.theme');
ok(T.THEMES.every(v => T.validTheme(v) === v) && ['', 'Light', 'DARK', 'blue', 'auto ', null, undefined, 1].every(v => T.validTheme(v) === null), 'only the three values are accepted (exact spelling)');
const mem = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = String(v); } });
const blocked = { getItem() { throw new Error('storage blocked'); }, setItem() { throw new Error('storage blocked'); } };
const P = (s, st) => { const r = T.pickTheme(s, st); return r.choice + '/' + r.from; };
ok(P('', null) === 'dark/default' && P('', mem({})) === 'dark/default' && P(undefined, undefined) === 'dark/default', 'nothing chosen: dark (default)');
ok(P('', mem({ 'atlas.theme': 'auto' })) === 'auto/storage' && P('', mem({ 'atlas.theme': 'light' })) === 'light/storage', 'a stored choice beats the default');
ok(P('?theme=light', mem({ 'atlas.theme': 'dark' })) === 'light/url' && P('?for=furey&theme=auto', mem({ 'atlas.theme': 'light' })) === 'auto/url', 'the address beats the stored choice');
ok(P('?theme=purple', mem({ 'atlas.theme': 'light' })) === 'light/storage' && P('?theme=purple', mem({ 'atlas.theme': 'Hacker' })) === 'dark/default', 'a value that is not one of the three is ignored, in the address and in storage');
ok(P('', blocked) === 'dark/default' && P('?theme=light', blocked) === 'light/url', 'storage that throws: no error, the address still works, else dark');
ok(T.resolveTheme('auto', true) === 'light' && T.resolveTheme('auto', false) === 'dark' && T.resolveTheme('light', false) === 'light' && T.resolveTheme('dark', true) === 'dark', 'auto follows the system preference; light and dark do not');

// ---- 2. the module's state, in fresh copies of the module (no document in node: nothing is drawn, the state works)
Object.defineProperty(globalThis, 'localStorage', { configurable: true, get() { throw new Error('storage blocked'); } });
{ const B = await import('./theme.js?blocked');
  ok(B.getTheme() === 'dark', 'blocked storage: the page starts dark');
  B.setTheme('light'); ok(B.getTheme() === 'light' && B.getResolvedTheme() === 'light', 'blocked storage: a choice is kept in memory for the session');
  B.setTheme('sepia'); ok(B.getTheme() === 'light', 'setTheme ignores a value that is not one of the three'); }
const box = { 'atlas.theme': 'light' };
Object.defineProperty(globalThis, 'localStorage', { configurable: true, value: mem(box) });
{ const S = await import('./theme.js?stored');
  ok(S.getTheme() === 'light', 'the stored choice is read when the module loads');
  S.setTheme('auto'); ok(box['atlas.theme'] === 'auto' && S.getTheme() === 'auto', 'a choice is written under atlas.theme');
  const seen = []; const stop = S.subscribeTheme(v => seen.push(v)); S.setTheme('dark'); stop(); S.setTheme('light');
  ok(seen.join() === 'dark', 'subscribers hear each change until they stop listening: ' + seen.join()); }
globalThis.location = { search: '?theme=dark' }; box['atlas.theme'] = 'light';
{ const U = await import('./theme.js?url');
  ok(U.getTheme() === 'dark' && box['atlas.theme'] === 'light', 'the address wins when the module loads, and it is not stored'); }
delete globalThis.location; delete globalThis.localStorage;

// ---- 3. scope of the rules: light rules under html[data-theme="light"], filter rules under main[data-rf="known..."]
// split a style sheet (one rule per line here) into [selector list, body]; the selector list is split at the commas outside parentheses
const topSplit = s => { const out = []; let d = 0, cur = ''; for (const ch of s) { if (ch === '(' || ch === '[') d++; if (ch === ')' || ch === ']') d--; if (ch === ',' && d === 0) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map(x => x.trim()); };
const rules = css => css.split('\n').filter(Boolean).map(r => { const i = r.indexOf('{'); return [topSplit(r.slice(0, i)), r.slice(i)]; });
const light = rules(T.LIGHT_CSS);
ok(light.length > 20 && light.every(([sels, body]) => sels.every(s => s.startsWith('html[data-theme="light"]')) && body.endsWith('}')), 'every selector of the light theme starts with html[data-theme="light"] (' + light.length + ' rules): the dark page has no new rule');
ok(/^html\[data-theme="light"\]\{filter:invert\(1\) hue-rotate\(180deg\);background:var\(--bg,#0b1020\)\}$/m.test(T.LIGHT_CSS), 'the light theme is the inversion filter on <html>, with the ground var(--bg) painted under it');
ok(/^html\[data-theme="light"\] body\{color-scheme:dark\}$/m.test(T.LIGHT_CSS) && (T.LIGHT_CSS.match(/color-scheme/g) || []).length === 1, 'color-scheme is set only in light mode (dark for the controls the browser draws, which the filter turns light)');
const F = await import('./readerFilter.js');
const filt = rules(F.FILTER_CSS);
ok(filt.length === 2 * F.LINES.length && filt.every(([sels]) => sels.every(s => /^main\[data-rf="known(\+std)?"\] /.test(s))), 'every rule of the reader filter sits under main[data-rf="known"] or ["known+std"]: with the filter off (the default) none applies');

// ---- 4. colours in the source: theme.js names colours only inside its light override block; readerFilter.js names none; the shell files as in v10.1
const HEX = /#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?(?:[0-9a-fA-F]{2})?\b/g;
const src = rd('theme.js'), a = src.indexOf('// ==== LIGHT OVERRIDE BLOCK'), z = src.indexOf('// ==== END OF THE LIGHT OVERRIDE BLOCK ====');
ok(a > 0 && z > a, 'theme.js has one light override block');
const outside = (src.slice(0, a) + src.slice(z)).match(HEX) || [];
ok(outside.length === 0, 'theme.js: no hex colour outside the light override block: ' + outside.join(' '));
ok(!(rd('readerFilter.js').match(HEX) || []).length, 'readerFilter.js names no colour');
const tally = f => { const m = {}; for (const h of rd(f).match(HEX) || []) m[h.toLowerCase()] = (m[h.toLowerCase()] || 0) + 1; return JSON.stringify(Object.entries(m).sort()); };
// StoryShell.jsx #0b1020 x3 (var(--bg) fallbacks), #4aa8ff x5 (accent, focus), the five tag colours once (the violet #c4b5fd of the input flag is the fifth); App.jsx the four proof-badge colours once
ok(tally('StoryShell.jsx') === JSON.stringify([['#0b1020', 3], ['#34d399', 1], ['#4aa8ff', 5], ['#60a5fa', 1], ['#c4b5fd', 1], ['#f87171', 1], ['#fbbf24', 1]]), 'StoryShell.jsx has exactly the colours of the shell (the five tag colours; the theme, filter and strip code add none): ' + tally('StoryShell.jsx'));
ok(tally('App.jsx') === JSON.stringify([['#34d399', 1], ['#60a5fa', 1], ['#f87171', 1], ['#fbbf24', 1]]), 'App.jsx has exactly the colours of v10.1: ' + tally('App.jsx'));
ok(/^import \{[^}]*\} from '\.\/theme\.js';$/m.test(rd('StoryShell.jsx')) && /from '\.\/StoryShell'/.test(rd('App.jsx')), 'StoryShell.jsx imports theme.js (App.jsx imports StoryShell): data-theme is set when the bundle loads, before React draws');

// ---- 5. the arithmetic of the light colours
const hexOf = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255);
const hue = h => { const [r, g, b2] = hexOf(h), mx = Math.max(r, g, b2), mn = Math.min(r, g, b2), d = mx - mn; if (!d) return 0; let x = mx === r ? ((g - b2) / d) % 6 : mx === g ? (b2 - r) / d + 2 : (r - g) / d + 4; x *= 60; return x < 0 ? x + 360 : x; };
const dh = (x, y) => { const d = Math.abs(x - y) % 360; return Math.min(d, 360 - d); };
const BG = T.lightTarget('#0b1020');
ok(BG === '#eaefff', 'the dark ground #0b1020 turns into the light page #eaefff: ' + BG);
ok(['#f87171', '#123456', '#eaefff', '#4a6fa5', '#808080'].every(h => { const t = T.lightTarget(T.lightSource(h)); return hexOf(t).every((v, i) => Math.abs(v - hexOf(h)[i]) <= 2 / 255); }), 'lightSource is the inverse of lightTarget (inside the gamut)');
const pairs = [...T.LIGHT_CSS.matchAll(/\{(?:color|fill|border-color):(#[0-9a-f]{6})/g)].map(m => m[1]);
ok(pairs.length > 40, 'the light colours are read from the rules: ' + pairs.length);
const weak = [...new Set(pairs)].filter(src2 => { const seen = T.lightTarget(src2), s = hexOf(seen), g = hexOf(BG), at78 = '#' + s.map((v, i) => Math.round((0.78 * v + 0.22 * g[i]) * 255).toString(16).padStart(2, '0')).join('');
  return T.contrast(seen, BG) < T.LIGHT_MIN - 1e-9 || T.contrast(at78, BG) < 4.5; });
ok(T.LIGHT_MIN === 8 && weak.length === 0, 'every light override has 8:1 on the light page and 4.5:1 at 78 % opacity: ' + weak.join(' '));
const TAG = { checked: '#34d399', standard: '#60a5fa', ours: '#fbbf24', open: '#f87171', input: '#c4b5fd' };
for (const [k, h] of Object.entries(TAG)) {
  const m = T.LIGHT_CSS.match(new RegExp(`:is\\(\\.tag,\\.rn-tag\\)\\.${k}\\{color:(#[0-9a-f]{6})\\}`)), seen = m && T.lightTarget(m[1]);
  ok(m && T.contrast(seen, BG) >= 8 && dh(hue(seen), hue(h)) <= 20, `tag ${k}: written ${m && m[1]}, seen ${seen} (${seen && T.contrast(seen, BG).toFixed(2)}:1 on the light page; hue ${seen && Math.round(hue(seen))}° against ${Math.round(hue(h))}° in the dark theme)`);
  // the override improves a tag whose plain inversion is below 8:1; the violet of input is already at 8.40:1 after the plain inversion, and the override then leaves it as it is
  const plainSeen = T.lightTarget(h), improves = T.contrast(plainSeen, BG) < 8, same = hexOf(plainSeen).every((v, i) => Math.abs(v - hexOf(seen)[i]) <= 2 / 255);
  ok(improves || same, `tag ${k}: the plain inversion alone (${plainSeen}, ${T.contrast(plainSeen, BG).toFixed(2)}:1) is what the override improves, or is already 8:1 and is left as it is`);
}
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL THEME TESTS PASS'); process.exit(bad ? 1 : 0);
