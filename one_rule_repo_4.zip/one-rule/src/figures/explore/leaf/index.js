// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/leaf/index.js — the leaf pictures of Explore (owner X6), registered under the ids of EXPLORE_PLAN §2.3: leaf-<slug> for the ten leaves
// ported in v2.1. Each draws the front of its Octavo leaf from the leaf's logic (engines/explore/leaves/<slug>.logic.js, through LEAF_LOGIC); its seed is
// content/explore/figures.leaf.json, merged into content/figures.json by tools/merge_explore.mjs. A leaf whose logic misses a name it needs draws a labelled
// placeholder that names what is missing (leafKit.jsx).
import './leaf.css';
import LeafClock from './LeafClock.jsx';
import LeafMoves from './LeafMoves.jsx';
import LeafZero from './LeafZero.jsx';
import LeafLight from './LeafLight.jsx';
import LeafFall from './LeafFall.jsx';
import LeafRoots from './LeafRoots.jsx';
import LeafSeats from './LeafSeats.jsx';
import LeafMagnets from './LeafMagnets.jsx';
import LeafSprings from './LeafSprings.jsx';
import LeafCharge from './LeafCharge.jsx';

export const LEAF_FIGURES = {
  'leaf-clock': LeafClock,
  'leaf-moves': LeafMoves,
  'leaf-zero': LeafZero,
  'leaf-light': LeafLight,
  'leaf-fall': LeafFall,
  'leaf-roots': LeafRoots,
  'leaf-seats': LeafSeats,
  'leaf-magnets': LeafMagnets,
  'leaf-springs': LeafSprings,
  'leaf-charge': LeafCharge,
};
