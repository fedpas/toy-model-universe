// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/TranslationMatrix.jsx — the shared table of a translation matrix (BUILD_CONTRACTS D35; written by P6, imported by P9 and P11).
// A translation matrix sets a source's line (a paper's equation, a lecture's slide, a claim) beside the bit rule's. Each line is a row of the Atlas
// (kind "reading"): its research text is "<left> ↔ <right>" and its status is computed from its evidence like every row's.
//
// API (stable):  <TranslationMatrix rows title level lens />  with  rows = [{ id, left, right, badgeRow }]
//   id        the line's own name in the source matrix (S01, F24, A3 …), printed in the first column
//   left      the source's column, right the bit rule's: research-text format (words, with $…$ around each formula, typeset by KaTeX)
//   badgeRow  the row of rows.json the line is; its status (statusOf) gives the badge, its text record (textFor) the words
//   title     the table's name (a name, not a sentence) · level 'research' | 'learner' · lens: accepted, the lines do not change with it
//             (the text record is looked up in the page's mode and lens, as a Statement does; pass mode when the figure has it)
// Optional props: figId and row (the drawing's accessible name: the figure id and the caption row the frame passes); columns = { left, right } (the
//   column heads, default "source" and "bit rule"); statusWords = { key: word } (the stored status of each line, in display order; without it the
//   computed status of badgeRow is used); groups = [{ key, name }] (thread chips, in display order); initial = { status, group, open, badges, folded }
//   (the starting state, from the figure's params; folded: true starts with the list of lines folded under its count, as a native details element
//   that a pick of a chip opens; without it the list starts open).
// Optional fields of a row: ref (a short tag printed small under the id), status (a key of statusWords), group (a key of groups),
//   detail = [[label, value, key?], …] (printed when the line is opened: the worked instance, the page, the dimensions …; a value with $…$ is typeset).
// initial.open is the id of a line whose detail starts open.
// What is printed: when the row's text record exists, the line's words are that record, split at its first " ↔ ", inside an element of class
// "statement" (data-row = badgeRow, .statement__text, the row's LensReading and its one badge), so the coverage test checks it byte for byte
// against textFor like any statement; before the record is merged, left and right are printed as given, without the statement class (the record
// and the props are the same words: each owner's test ties them).
// Controls, research level only, each with data-param (the seed needs an interactive entry for each one the table draws, and the table draws them
// whether or not its rows have loaded): "status" (chips: all and each status present, with counts; v15's filters), "thread" (chips, only when
// groups are given; v15's thread chips), "badges" (the fold of the badge column: folded, each badge shows its shape only; unfolded, shape, word and
// row id; D35). A line with a detail is a native details element whose summary is the line (v15: a row opened its worked instance); it is not a
// control of the seed. Learner level: no table and no formula, the strip and the counts by status in words.
// Also exported: MatrixLines (the lines alone, the same markup, for a figure that shows some lines of a matrix), splitLine, joinLine, JOIN,
// StatusGlyph, computedWord.
// The drawing (both levels): a strip with one mark per line, its shape the line's status (filled square, half square, hollow square, dot, cross),
// grouped by thread when groups are given, and a legend of shape, word and count. Tokens only; status by shape and word, never by colour alone.
import React, { useEffect, useMemo, useState } from 'react';
import { statusOf, textFor } from '../../app/content.js';
import { STATUS_PLAIN, BADGE_WORDS } from '../../app/vocab.js';
import Badge from '../../components/Badge.jsx';
import RichText from '../../components/RichText.jsx';
import LensReading from '../../components/LensReading.jsx';
import { FigSvg, Controls, Chips, Toggle, r1 } from '../kit.jsx';
import './translation.css';

/** the joiner of a line's two columns in its research text (D35) */
export const JOIN = ' ↔ ';
/** a research text "<left> ↔ <right>" split at its first joiner: [left, right] (a text without a joiner is all right column) */
export function splitLine(body) {
  const s = String(body ?? ''), i = s.indexOf(JOIN);
  return i < 0 ? ['', s] : [s.slice(0, i), s.slice(i + JOIN.length)];
}
/** the research text of a line from its two columns */
export const joinLine = (left, right) => `${left ?? ''}${JOIN}${right ?? ''}`;

/** the computed statuses in the order the legend and the chips list them, with their plain words (vocab.js; persona rules' names) */
const COMPUTED = ['proved-by-atlas', 'standard', 'cited', 'ours', 'open', 'input', 'meta', 'candidate'];
const KIND_OF = { cited: 'cited', ours: 'ours', open: 'open', input: 'input' };
export const computedWord = (status, level) => {
  const lv = level === 'learner' ? 'learner' : 'research';
  if (!status) return 'no status yet';
  if (STATUS_PLAIN[status]) return STATUS_PLAIN[status][lv];
  return KIND_OF[status] ? BADGE_WORDS[KIND_OF[status]][lv] : status;
};

/** the marks of the strip and the legend (shape, never colour alone): a stored status takes the shape of its place in statusWords (the first
 *  filled, the second half, the third hollow …); a computed status its own shape */
const SHAPES = ['filled', 'half', 'hollow', 'dot', 'cross', 'ring', 'dash'];
const COMPUTED_SHAPE = { 'proved-by-atlas': 'filled', standard: 'half', ours: 'dot', cited: 'hollow', open: 'cross', input: 'ring', meta: 'dash', candidate: 'dash', '': 'dash' };
export function StatusGlyph({ shape, x, y, s = 9 }) {
  const h = s / 2;
  if (shape === 'filled') return <rect x={r1(x - h)} y={r1(y - h)} width={s} height={s} className="ink" data-shape="filled" />;
  if (shape === 'half') return <g data-shape="half"><rect x={r1(x - h)} y={r1(y - h)} width={s} height={s} className="stroke-ink" style={{ strokeWidth: 1.1 }} /><path d={`M${r1(x - h)} ${r1(y + h)} L${r1(x + h)} ${r1(y - h)} L${r1(x + h)} ${r1(y + h)} Z`} className="ink" /></g>;
  if (shape === 'hollow') return <rect x={r1(x - h + 0.6)} y={r1(y - h + 0.6)} width={r1(s - 1.2)} height={r1(s - 1.2)} className="stroke-ink" style={{ strokeWidth: 1.2 }} data-shape="hollow" />;
  if (shape === 'dot') return <circle cx={r1(x)} cy={r1(y)} r={r1(h * 0.55)} className="ink" data-shape="dot" />;
  if (shape === 'ring') return <circle cx={r1(x)} cy={r1(y)} r={r1(h * 0.8)} className="stroke-ink" style={{ strokeWidth: 1.2 }} data-shape="ring" />;
  if (shape === 'dash') return <path d={`M${r1(x - h)} ${r1(y)} L${r1(x + h)} ${r1(y)}`} className="stroke-ink" style={{ strokeWidth: 1.6 }} data-shape="dash" />;
  return <path d={`M${r1(x - h)} ${r1(y - h)} L${r1(x + h)} ${r1(y + h)} M${r1(x + h)} ${r1(y - h)} L${r1(x - h)} ${r1(y + h)}`} className="stroke-ink" style={{ strokeWidth: 1.3 }} data-shape="cross" />;
}
/** the same mark as a small hidden icon beside a word (the status column, the chips) */
function GlyphIcon({ shape }) {
  return <svg className="tm-icon" viewBox="0 0 12 12" aria-hidden="true"><StatusGlyph shape={shape} x={6} y={6} s={9} /></svg>;
}

/** the line as the Atlas stores it: the text record of its row when there is one (statement), else the two columns given */
function lineOf(r, mode, lens) {
  const body = r.badgeRow ? textFor(r.badgeRow, { mode: mode || 'phys', level: 'research', lens: lens || null }) : null;
  if (body != null) { const [left, right] = splitLine(body); return { left, right, record: true }; }
  return { left: String(r.left ?? ''), right: String(r.right ?? ''), record: false };
}

export default function TranslationMatrix({ rows = [], title = '', level = 'research', lens = null, mode = 'phys', figId = 'translation-matrix', row = null,
  columns = null, statusWords = null, groups = null, initial = {} }) {
  const research = level !== 'learner';
  const cols = { left: 'source', right: 'bit rule', ...(columns || {}) };
  const lines = Array.isArray(rows) ? rows.filter(r => r && r.id != null) : [];
  const S = useStatuses(lines, statusWords, level);
  const groupList = Array.isArray(groups) && groups.length ? groups : null;

  const okStatus = v => v === 'all' || S.present.includes(v), okGroup = v => v === 'all' || (groupList || []).some(g => g.key === v);
  const [flt, setFlt] = useState(okStatus(initial.status) ? initial.status : 'all');
  const [grp, setGrp] = useState(okGroup(initial.group) ? initial.group : 'all');
  const [unfolded, setUnfolded] = useState(initial.badges === true);
  const [listOpen, setListOpen] = useState(initial.folded !== true || initial.open != null);
  useEffect(() => { setFlt(okStatus(initial.status) ? initial.status : 'all'); }, [initial.status, S.present.join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setGrp(okGroup(initial.group) ? initial.group : 'all'); }, [initial.group]);                          // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setUnfolded(initial.badges === true); }, [initial.badges]);
  useEffect(() => { setListOpen(initial.folded !== true || initial.open != null); }, [initial.folded, initial.open]);
  const pickOpen = set => v => { set(v); setListOpen(true); };

  const shown = S.keyed.filter(x => (flt === 'all' || x.key === flt) && (grp === 'all' || x.r.group === grp));
  const sections = groupList ? groupList.map(g => ({ g, items: shown.filter(x => x.r.group === g.key) })).filter(s => s.items.length) : [{ g: null, items: shown }];
  const strip = useMemo(() => stripLayout(S.keyed, groupList, research, S.present.length), [S.keyed.map(x => `${x.r.id}:${x.key}:${x.r.group}`).join('|'), groupList ? groupList.map(g => g.key).join() : '', research, S.present.length]);   // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="fig tm" data-matrix={figId} data-lines={lines.length} data-badges={unfolded ? 'unfolded' : 'folded'}>
      {research && title ? <p className="tm-title">{title}</p> : null}
      <FigSvg id={figId} row={row} viewBox={`0 0 ${strip.W} ${strip.H}`} className="tm-strip">
        {strip.groups.map(g => g.label ? <text key={'g' + g.key} x={4} y={r1(g.y + 3.5)} className="t-mono t-tiny t-muted" data-strip-group={g.key}>{g.label}</text> : null)}
        {strip.marks.map(m => (
          <g key={m.id} data-mark={m.id} data-status={m.key}>
            <title>{`${m.id}: ${S.wordOf(m.key)}`}</title>
            <StatusGlyph shape={S.shapeOf(m.key)} x={m.x} y={m.y} />
          </g>
        ))}
        {S.present.map((k, i) => (
          <g key={'l' + k} data-legend={k} data-count={S.count(k)}>
            <StatusGlyph shape={S.shapeOf(k)} x={strip.legendX(i) + 5} y={strip.legendY(i)} />
            <text x={strip.legendX(i) + 14} y={r1(strip.legendY(i) + 3.5)} className="t-tiny">{`${S.wordOf(k)} ${S.count(k)}`}</text>
          </g>
        ))}
        {!lines.length ? <text x={4} y={18} className="t-tiny t-muted">{'0 lines'}</text> : null}
      </FigSvg>
      {research ? (
        <>
          <Controls label="filter the lines">
            <Chips label="status" items={['all', ...S.present]} value={flt} onPick={pickOpen(setFlt)} param="status"
              render={k => (k === 'all' ? `all · ${lines.length}` : <><GlyphIcon shape={S.shapeOf(k)} />{`${S.wordOf(k)} · ${S.count(k)}`}</>)} />
            {groupList ? <Chips label="thread" items={['all', ...groupList.map(g => g.key)]} value={grp} onPick={pickOpen(setGrp)} param="thread"
              render={k => (k === 'all' ? 'all' : `${groupList.find(g => g.key === k).name} · ${lines.filter(r => r.group === k).length}`)} /> : null}
            <Toggle label={unfolded ? 'badges: shown' : 'badges: folded'} on={unfolded} onChange={setUnfolded} param="badges" />
          </Controls>
          <details className="tm-all" open={listOpen || undefined} onToggle={e => setListOpen(e.currentTarget.open)}>
            <summary className="tm-count" data-shown={shown.length}>{`${shown.length} of ${lines.length} lines`}</summary>
            <div className="tm-head" aria-hidden="true">
              <span>line</span><span>{cols.left}</span><span /><span>{cols.right}</span><span>badge</span><span>status</span>
            </div>
            <div className="tm-body">
              {sections.map(({ g, items }) => (
                <section key={g ? g.key : 'all'} className="tm-sec" data-group={g ? g.key : undefined} aria-label={g ? g.name : title || undefined}>
                  {g ? <p className="tm-group">{g.name}</p> : null}
                  <LineList items={items} S={S} level={level} mode={mode} lens={lens} figId={figId} open={initial.open} />
                </section>
              ))}
              {!shown.length ? <p className="tm-none">no line</p> : null}
            </div>
          </details>
        </>
      ) : (
        <p className="tm-counts" data-counts={S.present.map(k => `${k}:${S.count(k)}`).join(',')}>
          {`${lines.length} lines: ${S.present.map(k => `${S.wordOf(k)} ${S.count(k)}`).join(' · ')}`}
        </p>
      )}
    </div>
  );
}

/** each line's status key (the stored one with statusWords, else the computed status of its row), the statuses present, their shapes, words, counts */
function useStatuses(lines, statusWords, level) {
  const keyed = lines.map(r => { const st = r.badgeRow ? statusOf(r.badgeRow) : null; return { r, st, key: statusWords ? String(r.status ?? '') : (st ? st.status : '') }; });
  const order = statusWords ? Object.keys(statusWords) : [...COMPUTED, ''].filter(k => keyed.some(x => x.key === k));
  for (const x of keyed) if (!order.includes(x.key)) order.push(x.key);
  const present = order.filter(k => keyed.some(x => x.key === k));
  return {
    keyed, order, present,
    shapeOf: k => (statusWords ? SHAPES[Math.max(0, order.indexOf(k)) % SHAPES.length] : COMPUTED_SHAPE[k] || 'dash'),
    wordOf: k => (statusWords && statusWords[k] != null ? statusWords[k] : computedWord(k, level)),
    count: k => keyed.filter(x => x.key === k).length,
  };
}

/**
 * The lines alone, without strip, controls or head (for a figure that shows some lines of a matrix, e.g. the rows that check a line of the
 * dynamics): the same markup as the table's, each line a statement once its row's text record exists. Props: rows (as TranslationMatrix's),
 * level, lens, mode, figId, statusWords (optional), open (the id of a line whose detail starts open).
 */
export function MatrixLines({ rows = [], level = 'research', lens = null, mode = 'phys', figId = 'translation-matrix', statusWords = null, open = null }) {
  const lines = Array.isArray(rows) ? rows.filter(r => r && r.id != null) : [];
  const S = useStatuses(lines, statusWords, level);
  if (level === 'learner' || !lines.length) return null;
  return <div className="tm tm--lines" data-matrix={figId} data-badges="folded"><LineList items={S.keyed} S={S} level={level} mode={mode} lens={lens} figId={figId} open={open} /></div>;
}

function LineList({ items, S, level, mode, lens, figId, open }) {
  return <ol className="tm-lines">{items.map(x => <Line key={x.r.id} x={x} level={level} mode={mode} lens={lens} figId={figId} open={open != null && String(open) === String(x.r.id)} shape={S.shapeOf(x.key)} word={S.wordOf(x.key)} />)}</ol>;
}

/** one line: the id, the two columns joined by ↔ (a statement once its text record exists), the badge, the status; a line with a detail opens it
 *  (a native details element: its summary is the line) */
function Line({ x, level, mode, lens, figId, open, shape, word }) {
  const { r, st, key } = x;
  const L = lineOf(r, mode, lens);
  const detail = Array.isArray(r.detail) ? r.detail.filter(d => Array.isArray(d) && d[1] != null && d[1] !== '') : [];
  const badge = st ? (st.badge ? <Badge status={st.status} badge={st.badge} level={level} /> : <span className="tm-plain">{computedWord(st.status, level)}</span>) : null;
  const words = (
    <p className={L.record ? 'statement__text tm-text' : 'tm-text'}>
      <span className="tm-left" data-col="left">{L.left ? <RichText text={L.left} level={level} /> : null}</span>
      <span className="tm-join">{JOIN}</span>
      <span className="tm-right" data-col="right">{L.right ? <RichText text={L.right} level={level} /> : null}</span>
    </p>
  );
  const meta = <span className="statement__meta tm-badge" data-badge={st ? st.badge || '' : undefined}>{badge}{r.badgeRow ? <code className="tm-rowid">{r.badgeRow}</code> : null}</span>;
  const cells = (
    <>
      <span className="tm-id"><span className="tm-idtxt">{String(r.id)}</span>{r.ref ? <span className="tm-ref">{r.ref}</span> : null}</span>
      {L.record
        ? <div className="statement statement--line tm-st" data-row={r.badgeRow}>{words}<LensReading id={r.badgeRow} />{meta}</div>
        : <div className="tm-st">{words}{meta}</div>}
      <span className="tm-status" data-status={key}><GlyphIcon shape={shape} />{word}</span>
    </>
  );
  const data = { 'data-line': r.id, 'data-status': key, 'data-group': r.group, 'data-badge-row': r.badgeRow, 'data-record': L.record ? 1 : 0 };
  if (!detail.length) return <li className="tm-line" {...data}><div className="tm-sum">{cells}</div></li>;
  return (
    <li className="tm-line tm-line--more" {...data}>
      <details className="tm-d" open={open || undefined} data-detail-of={`${figId}:${r.id}`}>
        <summary className="tm-sum">{cells}</summary>
        <dl className="tm-detail">
          {detail.map(([label, value, k], i) => <div key={i}><dt>{label}</dt><dd data-detail={k || label}>{String(value).includes('$') ? <RichText text={String(value)} level={level} /> : String(value)}</dd></div>)}
        </dl>
      </details>
    </li>
  );
}

/** the strip: one mark per line (rows of a group, or runs of at most 25), a legend underneath (three entries to a row) */
function stripLayout(keyed, groupList, research, nLegend = 1) {
  const W = 440, step = 13, top = 14, rowH = 16, perRow = 25, perLegend = 3, legendH = 14;
  const labelW = groupList && research ? 92 : 8;
  const runs = groupList ? groupList.map(g => ({ key: g.key, label: research ? g.name : '', items: keyed.filter(x => x.r.group === g.key) })) : [{ key: 'all', label: '', items: keyed }];
  const fit = Math.max(1, Math.min(perRow, Math.floor((W - labelW - 8) / step)));
  const marks = [], groups = []; let y = top;
  for (const run of runs) {
    groups.push({ key: run.key, label: run.label, y });
    run.items.forEach((x, i) => { if (i && i % fit === 0) y += rowH; marks.push({ id: String(x.r.id), key: x.key, x: labelW + 8 + (i % fit) * step, y }); });
    y += rowH;
  }
  const y0 = y + 8, H = y0 + Math.max(1, Math.ceil(nLegend / perLegend)) * legendH;
  return { W, H, marks, groups, legendY: i => y0 + Math.floor(i / perLegend) * legendH, legendX: i => 4 + (i % perLegend) * 146 };
}
