// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure charges (calibration: from the field to the motion): a charge moving in the fields, in six situations. The force on the charge is the grade-1 part of F u,
// read from the term table that maxwell_selfcheck.py checks exactly (engines/chargeEngine.js, which reads that table from engines/maxwellData.js), and the motion is
// RK4 in the proper time (floating point). Top: the plane seen from above (x right, y up) with the path, the charge, its velocity (thin arrow), the electric field at it
// (dashed arrow), the magnetic field (⊙ out of the page, ⊗ into it) and the force (heavy arrow). Below: the speed against time with the limit c, or, for the spiral and
// the light wave, the side view (z right, x up; for the wave also in the frame that moves with the mean drift, z stretched four times). The figure opens on a run
// already advanced by four seconds of its animation (longer, until its check can be read), so the path is on the page; Play goes on (paused until pressed), Reset starts again. The readouts: t, τ, γ, v/c,
// u·u − 1, and the check of the situation (the closed form against the run). The controls are v15's: the situation, the sliders of its field and start (research
// level), the frame of the wave, Play / Step / Reset / speed. Port of v15 ChargesWidget.
// The physics of the drawing, by name (owner P4, docs/PHYSICS_AUDIT.md §2.1 MX11–MX15, decision D29): a legend of every mark by shape and word at both levels
// (the charge, its velocity, E dashed, B as ⊙ / ⊗, the force heavy); at research level the invariants E² − B² and E·B (the readout of the engine), the force
// term by term, f_a = Σ ± F u (KaTeX), each term a row of the stored table of maxwell_selfcheck.py for the world of the situation, with its live value, and the
// stored frame; F on the simplex of the world (each edge a component with its value, the velocity and the force at each vertex; at learner level the
// role words only); the 14 checked rows of the script as names and numbers, folded, and at learner level their counts. The rows, the counts, the numeric runs
// and the frame come from content/stored_p4.json (D34); the force table from engines/chargeEngine.js (TERMS, the stored table it bundles). Every printed
// item is tied to maxwell.json and recomputed through the kernel in tests/physics/p4.test.mjs.
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { SPEC, PRESET_IDS, defaults, initRun, advance, readout, TERMS, FIELDS, force } from '../../engines/chargeEngine.js';
import { useKatex, texToHtml } from '../app/math.js';
import { useTable } from '../app/content.js';
import { RoleShape } from './MaxwellEquations.jsx';
import { FigSvg, Controls, Chips, Range, PlayButton, PlayAction, useReducedMotion, r1, f2, arrowHead } from './kit.jsx';
import './physics/p4.css';

const NAME = { circle: ['B only: a circle', 'a circle'], hyper: ['E only: a speed limit', 'a speed limit'], crossed: ['E and B crossed: a drift', 'a drift'], spiral: ['E parallel to B: a spiral', 'a spiral'], orbit: ['a point charge: an orbit', 'an orbit'], wave: ['a light wave: a figure of eight', 'a figure of eight'] };
const PNAME = { B: 'B', E: 'E', rho: 'E / B', qm: 'q/m', v0: 'starting speed', kappa: 'attraction κ', a: 'wave strength a' };
const W = 360, PH = 250;
const f3 = x => { const r = Math.abs(x) < 5e-5 ? 0 : Math.round(x * 1000) / 1000; return String(r).replace('-', '−'); };
const ext = pts => pts.reduce((b, [x, y]) => [Math.min(b[0], x), Math.max(b[1], x), Math.min(b[2], y), Math.max(b[3], y)], [Infinity, -Infinity, Infinity, -Infinity]);
function makeView(run, sp, a, b, H) {
  const cur = [a(run.s), b(run.s)]; let cx, cy, half;
  if (sp.view === 'follow') { cx = cur[0]; cy = cur[1]; half = sp.ext; } else { const pts = run.trail.map(p => [a([0, p[0], p[1], p[2]]), b([0, p[0], p[1], p[2]])]).concat([cur]); const [x0, x1, y0, y1] = ext(pts); cx = (x0 + x1) / 2; cy = (y0 + y1) / 2; half = Math.max(sp.ext, 0.58 * Math.max(x1 - x0, y1 - y0) + 0.15); }
  const s = Math.min(W, H) / (2 * half); return { X: v => W / 2 + (v - cx) * s, Y: v => H / 2 - (v - cy) * s, s, cx, cy };
}
const arr = (v, k = 1) => { const L = Math.hypot(v[0], v[1]); return L < 1e-9 ? [0, 0] : [v[0] / L * (12 + 26 * Math.tanh(L * k)), -v[1] / L * (12 + 26 * Math.tanh(L * k))]; };
function Arrow({ x1, y1, dx, dy, w = 1.6, dash, kind }) {
  if (Math.hypot(dx, dy) < 1.5) return null;
  return <g data-arrow={kind}><line x1={r1(x1)} y1={r1(y1)} x2={r1(x1 + dx)} y2={r1(y1 + dy)} className="stroke-ink" style={{ strokeWidth: w, strokeDasharray: dash }} /><path d={arrowHead(x1, y1, x1 + dx, y1 + dy, 6)} className="ink" /></g>;
}
const Bmark = ({ x, y, Bz }) => (Math.abs(Bz) > 1e-9 ? <g data-b={Bz > 0 ? 'out' : 'in'}><circle cx={r1(x)} cy={r1(y)} r={6} className="stroke-ink" style={{ strokeWidth: 1.3 }} />{Bz > 0 ? <circle cx={r1(x)} cy={r1(y)} r={1.6} className="ink" /> : <path d={`M${r1(x - 4)} ${r1(y - 4)}l8 8M${r1(x + 4)} ${r1(y - 4)}l-8 8`} className="stroke-ink" />}</g> : null);

// ---------------------------------------------------------------- the physics by name (P4: MX11–MX15)
const AXN = ['t', 'x', 'y', 'z', 'w'];
/** the legend: each mark of the drawing with its word (MX11), at both levels; the fixed charge of the orbit only there */
const LEGEND = {
  research: [['charge', 'the charge'], ['velocity', 'its velocity u'], ['E', 'the electric field E at the charge'], ['B', 'the magnetic field B: ⊙ out of the page, ⊗ into it'], ['force', 'the force f'], ['centre', 'the fixed charge']],
  learner: [['charge', 'the charge'], ['velocity', 'its motion'], ['E', 'the electric field'], ['B', 'the magnetic field, out of the page or into it'], ['force', 'the push'], ['centre', 'the charge that stays put']],
};
function LegendIcon({ kind }) {
  const head = (x1, y1, x2, y2) => <path d={arrowHead(x1, y1, x2, y2, 5)} className="ink" />;
  const body = {
    charge: <circle cx={11} cy={5} r={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />,
    velocity: <g><line x1={1} y1={5} x2={20} y2={5} className="stroke-ink" style={{ strokeWidth: 1.2 }} />{head(1, 5, 21, 5)}</g>,
    E: <g><line x1={1} y1={5} x2={19} y2={5} className="stroke-ink" style={{ strokeWidth: 1.4, strokeDasharray: '4 3' }} />{head(1, 5, 21, 5)}</g>,
    B: <g><circle cx={6} cy={5} r={4} className="stroke-ink" style={{ strokeWidth: 1.2 }} /><circle cx={6} cy={5} r={1.2} className="ink" /><circle cx={17} cy={5} r={4} className="stroke-ink" style={{ strokeWidth: 1.2 }} /><path d="M14.3 2.3l5.4 5.4M19.7 2.3l-5.4 5.4" className="stroke-ink" /></g>,
    force: <g><line x1={1} y1={5} x2={17} y2={5} className="stroke-ink" style={{ strokeWidth: 2.8 }} />{head(1, 5, 21, 5)}</g>,
    centre: <circle cx={11} cy={5} r={4.5} className="ink" />,
  }[kind];
  return <svg className="p4-key" viewBox="0 0 22 10" aria-hidden="true">{body}</svg>;
}
function Legend({ research, orbit }) {
  return (
    <ul className="mx-legend cg-legend" aria-label={research ? 'the marks of the drawing' : 'what the marks mean'}>
      {LEGEND[research ? 'research' : 'learner'].filter(([k]) => k !== 'centre' || orbit).map(([k, w]) => <li key={k} data-legend={k}><LegendIcon kind={k} /><span>{w}</span></li>)}
    </ul>
  );
}
function Tex({ tex, text, katex }) {
  const html = katex ? texToHtml(tex) : null;
  return html ? <span className="p4-tex" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span className="p4-tex mx-plain" data-tex={tex}>{text}</span>;
}
const texField = f => { const [h, s] = String(f).split('_'); return s ? `${h}_{${s}}` : h; };
/** the rows of the force in a world (2: the plane, 3: space), from the stored table: f_a = Σ sign · F · u_in (per unit q/m) */
export function forceRows(world, F, u) {
  return Array.from({ length: world + 1 }, (_, a) => {
    const terms = TERMS[world].filter(t => t.out === a).sort((p, q) => p.in - q.in);
    const value = terms.reduce((s, t) => s + t.sign * F[FIELDS.indexOf(t.field)] * u[t.in], 0);
    const tex = `f_{${AXN[a]}} = ` + terms.map((t, i) => (i ? (t.sign > 0 ? ' + ' : ' - ') : t.sign > 0 ? '' : '-') + `${texField(t.field)}\\,u_{${AXN[t.in]}}`).join('');
    const text = `f_${AXN[a]} = ` + terms.map((t, i) => (i ? (t.sign > 0 ? ' + ' : ' − ') : t.sign > 0 ? '' : '−') + `${t.field.replace('_', '')} u_${AXN[t.in]}`).join('');
    return { out: a, terms, value, tex, text };
  });
}
function ForceRows({ world, o, katex, frame }) {
  const rows = forceRows(world, o.F, o.u);
  return (
    <section className="cg-force" data-force-world={world}>
      <h4 className="mx-eqhead">the force, term by term, per unit q/m <span className="mx-tag">input · INP-007</span></h4>
      <ul className="cg-rows">
        {rows.map(r => (
          <li key={r.out} data-row-out={r.out} data-terms={r.terms.map(t => `${t.field}:${t.in}:${t.sign}`).join(' ')} data-value={r.value}>
            <Tex tex={r.tex} text={r.text} katex={katex} /><span className="cg-val">{`= ${f3(r.value)}`}</span>
          </li>
        ))}
      </ul>
      {frame ? <p className="cg-frame" data-frame={frame}>{`frame: ${frame}`}</p> : null}
    </section>
  );
}
/** F on the simplex of the world (MX14): an edge per component of F (the two indices of its terms), its value; at each vertex the velocity and the force */
const SIMPLEX_AT = { 2: [[180, 40], [58, 186], [302, 186]], 3: [[180, 34], [52, 196], [308, 196], [180, 132]] };
function ForceSimplex({ world, o, research, row }) {
  const pos = SIMPLEX_AT[world], f = force(o.F, o.u), seen = new Map();
  for (const t of TERMS[world]) if (!seen.has(t.field)) seen.set(t.field, [Math.min(t.in, t.out), Math.max(t.in, t.out)]);
  const edges = [...seen].map(([field, [a, b]]) => ({ field, a, b, v: o.F[FIELDS.indexOf(field)], role: field[0] === 'E' ? 'E' : 'B' }));
  const mx = Math.max(1e-9, ...edges.map(e => Math.abs(e.v))), cx = 180, cy = world === 2 ? 137 : 142;
  return (
    <div className="fig-panel cg-simplex" data-simplex-world={world}>
      <FigSvg id="charges" row={row} part={research ? 'F on the simplex: where the force comes from' : 'where the push comes from'} viewBox={`0 0 360 ${world === 2 ? 232 : 240}`}>
        {edges.map(e => {
          const [x1, y1] = pos[e.a], [x2, y2] = pos[e.b], mxp = (x1 + x2) / 2, myp = (y1 + y2) / 2, zero = Math.abs(e.v) < 1e-9;
          const L = Math.hypot(x2 - x1, y2 - y1) || 1, nx = -(y2 - y1) / L, ny = (x2 - x1) / L, side = (mxp - cx) * nx + (myp - cy) * ny >= 0 ? 1 : -1, ox = nx * side, oy = ny * side;
          const lx = mxp + ox * 9, ly = myp + oy * 11 + 3.5, anchor = ox > 0.4 ? 'start' : ox < -0.4 ? 'end' : 'middle';
          return (
            <g key={e.field} data-edge-field={e.field} data-edge={`${e.a},${e.b}`} data-role={e.role} {...(research ? { 'data-value': e.v } : {})} style={zero ? { opacity: 0.35 } : undefined}>
              <line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className={e.role === 'E' ? 'cg-edge-e' : 'cg-edge-b'} style={{ strokeWidth: r1(1 + 5 * Math.abs(e.v) / mx) }} />
              <RoleShape role={e.role} x={mxp} y={myp} r={3.6} />
              <text x={r1(lx)} y={r1(ly)} textAnchor={anchor} className={research ? 't-mono t-small' : 't-small'}>{research ? `${e.field.replace('_', '')} = ${f2(e.v)}` : e.role === 'E' ? 'electric' : 'magnetic'}</text>
            </g>
          );
        })}
        {pos.map(([x, y], a) => { const up = y < cy - 20; return (
          <g key={a} data-vertex={a} {...(research ? { 'data-u': o.u[a], 'data-f': f[a] } : {})}>
            <circle cx={x} cy={y} r={12} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} />
            <text x={x} y={y + 4} textAnchor="middle" className="t-mono">{AXN[a]}</text>
            {research ? <text x={x} y={up ? y - 18 : y + 26} textAnchor="middle" className="t-mono t-small">{`u${AXN[a]} = ${f2(o.u[a])}`}</text> : null}
            {research ? <text x={x} y={up ? y + (a === 3 ? 26 : -30) : y + 38} textAnchor="middle" className="t-mono t-small t-bold">{`f${AXN[a]} = ${f2(f[a])}`}</text> : null}
          </g>); })}
      </FigSvg>
      <p className="cg-frame">{research ? 'edges: E solid, B dashed, thicker for a larger value · f per unit q/m' : 'lines: pieces of the field · corners: the motion and the push'}</p>
    </div>
  );
}
const FIELD_NAME = k => k.replace(/_/g, ' ');
const valueText = v => (typeof v === 'boolean' ? (v ? 'yes' : 'no') : Array.isArray(v) ? v.join(', ') : v && typeof v === 'object' ? Object.entries(v).map(([a, b]) => `${a}: ${b}`).join(', ') : String(v));
/** the numeric block of a numeric row (num_cyclotron → numeric.cyclotron …) */
const NUMERIC_OF = { num_cyclotron: 'cyclotron', num_hyperbolic: 'hyperbolic', num_drift: 'drift', num_wave: 'wave', num_orbit: 'relativistic_orbit' };
/** the fields of a stored row as names and numbers (no sentence of ours): its own fields, the drift cases one by one, the numbers of its numeric run */
export function checkFields(r, numeric = {}) {
  const own = Object.entries(r).filter(([k]) => k !== 'id' && k !== 'kind' && k !== 'cases').map(([k, v]) => `${FIELD_NAME(k)} ${valueText(v)}`);
  const cases = (r.cases || []).map(c => `E ${c.E}, B ${c.B}: drift ${c.drift_speed}, γ ${c.gamma}, B′ ${c.B_in_drift_frame}`);
  const run = NUMERIC_OF[r.id] && numeric[NUMERIC_OF[r.id]] ? Object.entries(numeric[NUMERIC_OF[r.id]]).map(([k, v]) => `${FIELD_NAME(k)} ${valueText(v)}`) : [];
  return [...own, ...cases, ...run];
}
function Checks({ charges, research, world }) {
  if (!charges) return null;
  const c = charges.counts;
  if (!research) return <p className="cg-count" data-check-count={`${c.exact},${c.numeric}`}>{`${c.exact} checked exactly, ${c.numeric} numerically`}</p>;
  const worlds = Object.keys(TERMS).sort();
  return (
    <details className="cg-checks" data-fold="checks">
      <summary>{`what is checked: ${c.exact} exact, ${c.numeric} numeric`}</summary>
      <ul>
        {charges.rows.map(r => (
          <li key={r.id} data-check-row={r.id} data-kind={r.kind} data-fields={checkFields(r, charges.numeric).join(' | ')}>
            <span className="cg-kind" data-kind={r.kind}>{r.kind}</span><code>{r.id}</code>{` · ${checkFields(r, charges.numeric).join(' · ')}`}
          </li>
        ))}
      </ul>
      <p className="cg-frame" data-worlds={worlds.map(w => `${w}:${TERMS[w].length}`).join(',')}>{`the force table by space dimension: ${worlds.map(w => `${w}: ${TERMS[w].length} terms${+w === world ? ' (this situation)' : ''}`).join(' · ')}`}</p>
    </details>
  );
}

const OPEN = new Map();
/** the opening run of a situation: advanced by four seconds of its animation (rate × 4 of simulated time), or longer — up to twelve — until its check has a measured value
 *  (half a turn, a turn in the drift frame, two perihelia, a cycle of the wave), with the speed history */
export function openingRun(id, p = defaults(id)) {
  const key = id + JSON.stringify(p);
  if (!OPEN.has(key)) {
    const run = initRun(id, p), hist = [];
    for (let i = 0; i < 360; i++) { advance(run, p, SPEC[id].rate * 4 / 120); const o = readout(run, p); hist.push([run.s[0], o.speed]); if (i >= 119 && (!o.check || o.check.measured !== null)) break; }
    OPEN.set(key, { run, hist });
  }
  const o = OPEN.get(key); return { run: { ...o.run, s: o.run.s.slice(), trail: o.run.trail.map(t => t.slice()), peri: o.run.peri.slice(), cyc: o.run.cyc.map(c => c.slice()), P0: { ...o.run.P0 } }, hist: o.hist.map(h => h.slice()) };
}

export default function Charges({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const pid0 = PRESET_IDS.includes(params.preset) ? params.preset : 'circle';
  const [id, setId] = useState(pid0), [P, setP] = useState(defaults(pid0)), [speed, setSpeed] = useState(1), [frame, setFrame] = useState('lab');
  const [playing, setPlaying] = useState(false), [, setTick] = useState(0), reduced = useReducedMotion();
  const katex = useKatex(research), [stored] = useTable('stored_p4'), charges = stored && stored.maxwell ? stored.maxwell.charges : null;
  useEffect(() => { setId(pid0); setP(defaults(pid0)); }, [pid0]);
  const sim = useRef(null);
  if (!sim.current || sim.current.id !== id) sim.current = { id, ...openingRun(id, defaults(id)) };
  const S = sim.current, run = S.run, sp = SPEC[id];
  const adv = dt => { advance(run, P, dt); const o = readout(run, P); if (!S.hist.length || run.s[0] - S.hist[S.hist.length - 1][0] > 0.05) { S.hist.push([run.s[0], o.speed]); if (S.hist.length > 1500) S.hist.splice(0, 300); } setTick(x => x + 1); };
  useEffect(() => { if (!playing || reduced) return undefined; const k = setInterval(() => adv(sp.rate * speed * 0.033), 33); return () => clearInterval(k); }, [playing, reduced, speed, id, P]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = { playing, reduced, play: () => setPlaying(x => !x), step: () => adv(sp.rate * 0.25) };
  const fresh = (nid, np) => { sim.current = { id: nid, run: initRun(nid, np), hist: [] }; setTick(x => x + 1); };
  const pickPreset = pid => { const np = defaults(pid); setId(pid); setP(np); setPlaying(false); sim.current = { id: pid, ...openingRun(pid, np) }; };
  const onParam = (q, v) => { const np = { ...P, [q.id]: v }; setP(np); if (q.live) { if (run.steps === 0) run.P0 = { ...np }; else run.changed = true; setTick(x => x + 1); } else fresh(id, np); };
  const o = readout(run, P), side = id === 'spiral' || id === 'wave', c = o.check;
  // the top view
  const vt = makeView(run, sp, s => s[1], s => s[2], PH), px = vt.X(run.s[1]), py = vt.Y(run.s[2]);
  const Ev = [o.F[0], o.F[1]], Bz = o.F[5], fo = [o.f[1], o.f[2]], u = [o.u[1], o.u[2]], cen = id === 'orbit' ? [vt.X(0), vt.Y(0)] : null;
  const grid = ['circle', 'hyper', 'crossed', 'spiral'].includes(id) ? [[60, 50], [180, 50], [300, 50], [60, 150], [180, 150], [300, 150], [60, 230], [180, 230], [300, 230]] : [];
  const top = run.trail.map((p, i) => (i ? 'L' : 'M') + r1(vt.X(p[0])) + ' ' + r1(vt.Y(p[1]))).join('');
  // the side view (spiral, wave) or the speed chart
  const SH = 190, avg = frame === 'avg' && id === 'wave', a = Math.max(0.05, run.changed ? P.a : run.P0.a || P.a || 0.05), vd = a * a / (4 + a * a);
  const vs = side ? (avg ? (() => { const sy = SH / (2 * 1.15 * (a + 0.3)); return { X: v => W / 2 + v * sy * 4, Y: v => SH / 2 - (v - a) * sy }; })() : makeView(run, { ...sp, ext: sp.sideExt || sp.ext }, s => s[3], s => s[1], SH)) : null;
  const zOf = p => (avg ? p[2] - vd * p[3] : p[2]);
  const Tm = Math.max(10, S.hist.length ? S.hist[S.hist.length - 1][0] : 0), CX = v => 30 + v / Tm * (W - 44), CY = v => SH - 30 - v * (SH - 60);
  const chk = (() => {
    if (run.changed) return 'the field changed in flight: the closed forms belong to the start';
    if (!c) return null; const k = c.kind;
    if (k === 'circle') return c.measured === null ? `radius from the formula γ m v/(q B): ${f3(c.formula)} (half a turn to measure)` : `radius: path ${f3(c.measured)} · formula γ m v/(q B) ${f3(c.formula)}`;
    if (k === 'hyper') return `x: run ${f3(c.measured)} · formula ${f3(c.formula)} · speed ${f3(c.speed)} c (Newton: ${f2(c.newton)} c)`;
    if (k === 'drift') return c.measured === null ? `drift E/B = ${f3(c.formula)} (one turn to measure)` : `mean velocity over ${c.turns} turn${c.turns === 1 ? '' : 's'}: ${f3(c.measured)} · E/B ${f3(c.formula)}`;
    if (k === 'runaway') return `E/B = ${f2(c.rho)} ≥ 1: no drift frame, the charge runs away along E`;
    if (k === 'spiral') return `u_z: run ${f3(c.measured)} · γ₀ sinh(qEτ/m) ${f3(c.formula)}`;
    if (k === 'orbit') return c.measured === null ? `perihelion advance per turn from the formula: ${f2(c.formula)}° (${c.perihelia} perihelia so far)` : `perihelion advance per turn: ${f2(c.measured)}° measured · ${f2(c.formula)}° formula`;
    if (k === 'repulsive') return 'repulsion: the charge is scattered once';
    if (k === 'falls') return `κ/L = ${f2(c.ratio)} ≥ 1: no stable orbit`;
    if (k === 'wave') return c.measured === null ? `u_t − u_z = ${f3(c.conserved)} · mean drift a²/(4 + a²) = ${f3(c.formula)} (one cycle to measure)` : `u_t − u_z = ${f3(c.conserved)} · mean drift ${f3(c.measured)} · a²/(4 + a²) ${f3(c.formula)}`;
    return null;
  })();
  return (
    <div className="fig fig-charges">
      <div className="fig-stack">
        <FigSvg id="charges" row={row} part="seen from above" viewBox={`0 0 ${W} ${PH + (research ? 34 : 20)}`}>
          <rect x={0.5} y={0.5} width={W - 1} height={PH - 1} rx={6} className="hair-2" />
          <g data-preset={id} data-t={f2(o.t)}>
            {grid.map(([gx, gy], i) => (
              <g key={i} style={{ opacity: 0.45 }}>
                {Math.hypot(Ev[0], Ev[1]) > 1e-9 && <Arrow x1={gx} y1={gy} dx={arr(Ev, 0.6)[0] * 0.8} dy={arr(Ev, 0.6)[1] * 0.8} w={1.2} dash="3 2" kind="E-grid" />}
                <Bmark x={gx + 22} y={gy + 18} Bz={Bz} />
              </g>
            ))}
            {cen && <g data-centre={P.kappa >= 0 ? '+' : '−'}><circle cx={r1(cen[0])} cy={r1(cen[1])} r={7} className="ink" /><text x={r1(cen[0])} y={r1(cen[1] + 3.5)} textAnchor="middle" className="t-tiny t-bold" style={{ fill: 'var(--panel)' }}>{P.kappa >= 0 ? '+' : '−'}</text></g>}
            <path d={top} className="stroke-ink" style={{ strokeWidth: 1.5, strokeOpacity: 0.7 }} data-trail={run.trail.length} />
            <Arrow x1={px} y1={py} dx={arr(u, 1.2)[0]} dy={arr(u, 1.2)[1]} w={1.2} kind="velocity" />
            {Math.hypot(Ev[0], Ev[1]) > 1e-9 && <Arrow x1={px} y1={py} dx={arr(Ev, 0.8)[0] * 0.7} dy={arr(Ev, 0.8)[1] * 0.7} w={1.4} dash="4 3" kind="E" />}
            <Bmark x={px - 14} y={py - 14} Bz={Bz} />
            <Arrow x1={px} y1={py} dx={arr(fo, 1)[0]} dy={arr(fo, 1)[1]} w={2.8} kind="force" />
            <circle cx={r1(px)} cy={r1(py)} r={5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />
            {research && <text x={8} y={16} className="t-tiny t-muted">y ↑ x →</text>}
          </g>
          <text x={4} y={PH + 14} className="t-mono t-tiny" data-speed={o.speed} data-u2={o.u2}>{research ? `t = ${f2(o.t)} · τ = ${f2(o.tau)} · γ = ${f2(o.gamma)} · v/c = ${f3(o.speed)} · u·u − 1 = ${Math.abs(o.u2) < 1e-9 ? '0' : o.u2.toExponential(1)}` : `time ${f2(o.t)} · speed ${f3(o.speed)} of the speed of light`}</text>
          {research && chk && <text x={4} y={PH + 30} className="t-mono t-micro" data-check={c ? c.kind : 'changed'} data-formula={c && Number.isFinite(c.formula) ? c.formula : ''} data-measured={c && Number.isFinite(c.measured) ? c.measured : ''}>{chk}</text>}
        </FigSvg>
        <FigSvg id="charges" row={row} part={side ? 'seen from the side' : 'speed against time'} viewBox={`0 0 ${W} ${SH}`}>
          <rect x={0.5} y={0.5} width={W - 1} height={SH - 1} rx={6} className="hair-2" />
          {side ? (
            <g data-view={avg ? 'drift frame' : 'side'}>
              {id === 'wave' && !avg && Array.from({ length: W / 4 }, (_, i) => { const z = vs.cx + (i * 4 + 2 - W / 2) / vs.s, v = Math.cos(run.s[0] - z); return <rect key={'w' + i} x={i * 4} y={1} width={4} height={SH - 2} className={v > 0 ? 'ink' : 'ink-muted'} style={{ fillOpacity: +(Math.abs(v) * 0.14).toFixed(3) }} />; })}
              <path d={run.trail.map((p, i) => (i ? 'L' : 'M') + r1(vs.X(zOf(p))) + ' ' + r1(vs.Y(p[0]))).join('')} className="stroke-ink" style={{ strokeWidth: 1.5, strokeOpacity: 0.7 }} />
              {(() => { const pz = avg ? run.s[3] - vd * run.s[0] : run.s[3], qx = vs.X(pz), qy = vs.Y(run.s[1]), uu = [o.u[3] - (avg ? vd * o.u[0] : 0), o.u[1]], ff = [o.f[3], o.f[1]]; return (
                <g>
                  <Arrow x1={qx} y1={qy} dx={arr(uu, 1.2)[0]} dy={arr(uu, 1.2)[1]} w={1.2} kind="velocity" />
                  {!avg && <Arrow x1={qx} y1={qy} dx={arr(ff)[0]} dy={arr(ff)[1]} w={2.8} kind="force" />}
                  <circle cx={r1(qx)} cy={r1(qy)} r={5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />
                </g>); })()}
              {research && <text x={8} y={16} className="t-tiny t-muted">{avg ? "x ↑ z′ → (×4)" : 'x ↑ z →'}</text>}
            </g>
          ) : (
            <g data-view="speed" data-points={S.hist.length}>
              <line x1={30} y1={r1(CY(1))} x2={W - 14} y2={r1(CY(1))} className="stroke-ink" style={{ strokeDasharray: '5 4' }} /><text x={34} y={r1(CY(1) - 4)} className="t-small">c</text>
              <line x1={30} y1={r1(CY(0))} x2={W - 14} y2={r1(CY(0))} className="hair" /><line x1={30} y1={r1(CY(0))} x2={30} y2={r1(CY(1))} className="hair" />
              <text x={8} y={r1(CY(0) + 4)} className="t-mono t-micro">0</text><text x={8} y={r1(CY(1) + 4)} className="t-mono t-micro">1</text>
              <path d={S.hist.map(([tt, v], i) => (i ? 'L' : 'M') + r1(CX(tt)) + ' ' + r1(CY(v))).join('')} className="stroke-ink" style={{ strokeWidth: 1.8 }} />
              <text x={W / 2} y={SH - 8} textAnchor="middle" className="t-tiny t-muted">{research ? 'speed v/c against t' : 'speed against time'}</text>
            </g>
          )}
        </FigSvg>
      </div>
      <Legend research={research} orbit={id === 'orbit'} />
      {research ? (
        <dl className="fig-readout cg-inv" data-i1={o.I1} data-i2={o.I2}>
          <div><dt>E² − B²</dt><dd>{f3(o.I1)}</dd></div>
          <div><dt>E·B</dt><dd>{f3(o.I2)}</dd></div>
        </dl>
      ) : null}
      <Controls label="charges">
        <Chips label={research ? 'situation' : 'what'} items={PRESET_IDS} value={id} onPick={pickPreset} render={k => NAME[k][research ? 0 : 1]} param="preset" />
        {research && sp.params.map(q => <Range key={q.id} label={PNAME[q.id] + (q.live ? '' : ' ↻')} value={P[q.id]} min={q.min} max={q.max} step={q.step} onChange={v => onParam(q, v)} display={f2} param={q.id} />)}
        {research && id === 'wave' && <Chips label="frame" items={['lab', 'avg']} value={frame} onPick={setFrame} render={k => (k === 'lab' ? 'lab' : 'drift frame')} param="frame" />}
        <PlayButton player={player} />
        {research && <PlayAction label="Step" onClick={() => adv(sp.rate * 0.25)} />}
        <PlayAction label="Reset" kind="reset" onClick={() => { fresh(id, P); setPlaying(false); }} />
        {research && <span className="fig-group" data-play="speed">{[0.5, 1, 2].map(k => <button key={k} type="button" className="fig-btn fig-btn-sq" data-play="speed" aria-pressed={speed === k} onClick={() => setSpeed(k)}>{`×${k}`}</button>)}</span>}
      </Controls>
      {research ? <ForceRows world={sp.world} o={o} katex={katex} frame={charges ? charges.frame : null} /> : null}
      <ForceSimplex world={sp.world} o={o} research={research} row={row} />
      <Checks charges={charges} research={research} world={sp.world} />
    </div>
  );
}
Charges.meta = { id: 'charges', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Charges.data = (params = {}) => { const id = PRESET_IDS.includes(params.preset) ? params.preset : 'circle', p = defaults(id), { run } = openingRun(id, p), o = readout(run, p); return { preset: id, params: p, t: o.t, tau: o.tau, gamma: o.gamma, speed: o.speed, u2: o.u2, check: o.check, trail: run.trail.length, world: SPEC[id].world, F: o.F, u: o.u, force: force(o.F, o.u), I1: o.I1, I2: o.I2, rows: forceRows(SPEC[id].world, o.F, o.u).map(r => ({ out: r.out, value: r.value, terms: r.terms })) }; };
