// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/ExploreHome.jsx — `#/explore`: the home of Explore (EXPLORE_PLAN §2.1), its pages.json entry (kind explore-home) in the frame
// every page shares: the hero row with the clock's live picture, first and wide; then the path of eight leaves (always eight cards, in
// reading order; a leaf without a page is a quiet card with its name and no link), the shelf (only the leaves that have a page, each with
// the path leaf it hangs under), the lens explorers that have a page, and the way to the full Atlas. A card's headline is its leaf's hero
// row (Statement); the words of this file are names and directions. No drawers and no "no plain-words version" notice, as on the start page.
import { useMemo } from 'react';
import { useSettings } from '../app/content.js';
import { buildPageModel, heroFigure, pageTitle } from '../app/queries.js';
import PageView from './PageView.jsx';
import NotFound from './NotFound.jsx';
import Link from '../components/Link.jsx';
import FigureFrame from '../components/FigureFrame.jsx';
import LeafCard from '../components/LeafCard.jsx';
import { exploreMap, EXPLORE } from '../components/LeafPath.jsx';
import '../styles/explore.css';

function Part({ id, title, line, children }) {
  return (
    <section className="sec xh" id={`sec-${id}`} aria-labelledby={`h-${id}`} data-outline={title}>
      <h2 className="sec__title" id={`h-${id}`}>{title}</h2>
      {line ? <p className="sec__connective" data-connective="section">{line}</p> : null}
      {children}
    </section>
  );
}

function HomeMap() {
  const map = exploreMap();
  const heroRow = map.home && map.home.hero ? map.home.hero.row : null;
  const shelf = map.shelf.filter(e => e.page);
  const lenses = map.lenses.filter(e => e.page);
  return (
    <>
      {map.path.length ? (
        <Part id="path" title={map.path.length === 8 ? 'Eight leaves' : 'The path'} line="Read them in order, or open any.">
          <ol className="leaf-grid leaf-grid--path">
            {map.path.map(e => <LeafCard key={e.slug} entry={e} kind="path" skipRow={heroRow} />)}
          </ol>
        </Part>
      ) : null}
      {shelf.length ? (
        <Part id="shelf" title="On the shelf" line="Each loose leaf hangs under the leaf it needs.">
          <ul className="leaf-grid">
            {shelf.map(e => <LeafCard key={e.slug} entry={e} kind="shelf" />)}
          </ul>
        </Part>
      ) : null}
      {lenses.length ? (
        <Part id="explorers" title="Lens explorers">
          <ul className="leaf-grid">
            {lenses.map(e => <LeafCard key={e.slug} entry={e} kind="lens" />)}
          </ul>
        </Part>
      ) : null}
      <nav className="xh-door" aria-label="The full Atlas">
        <Link to="" className="btn">Connect to the full Atlas</Link>
      </nav>
    </>
  );
}

export default function ExploreHome() {
  const s = useSettings();
  const model = useMemo(() => buildPageModel(EXPLORE, s), [s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!model) return <NotFound />;
  const title = pageTitle(EXPLORE, s);
  const heading = { eyebrow: title === 'Explore' ? null : 'Explore', title, deck: null };
  // a hero row without a text at this level leaves the hero out; the home keeps its picture (the frame shows it alone)
  const lone = !model.hero ? heroFigure(model.def, s) : null;
  return (
    <div className="xp xp--home">
      <PageView model={model} heading={heading} drawers={false} learnerNotice={false} prevNext={null}
        heroAside={lone ? <FigureFrame id={lone} /> : null} afterSections={<HomeMap />} />
    </div>
  );
}
