// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/ExploreLeaf.jsx — `#/explore/<slug>`: a leaf of Explore, or one of its lens explorers (EXPLORE_PLAN §2.2), in the frame every
// page shares: the heading (where the leaf sits, with the eight dots of the path; its name; the leaves it builds on); the leaf's live
// picture first and wide, then its hero row and, at learner level, how we know it; the notes (rows; at learner level the short register
// when a row has one; the try line is the section's connective); the two ways (rows ordered by mode; at research level the chip that
// reads them in the leaf's lens); the open fold; the loose leaves that hang here; the navigation and "Connect to the full Atlas".
// Every sentence on the page is a text record of its row (Statement); the words of this file are names and directions.
import { useMemo } from 'react';
import { useSettings, textFor, statusOf } from '../app/content.js';
import { buildPageModel, heroFigure, pageTitle, sortEntries, visibleIn } from '../app/queries.js';
import { rowsByPage } from '../app/store.js';
import PageView from './PageView.jsx';
import NotFound from './NotFound.jsx';
import Statement from '../components/Statement.jsx';
import FigureFrame from '../components/FigureFrame.jsx';
import LeafNotes, { hasShort } from '../components/LeafNotes.jsx';
import LeafLensChip from '../components/LeafLensChip.jsx';
import LeafNav, { LeafHang } from '../components/LeafNav.jsx';
import { LeafDots, LEAF_KINDS, exploreMap, placeOf } from '../components/LeafPath.jsx';
import '../styles/explore.css';

const NOTES = 'notes';
const TWO_WAYS = 'two-ways';
const OWN = [NOTES, TWO_WAYS];

/**
 * The page model of a leaf or explorer: buildPageModel with the notes and the two ways rendered here, then
 *  (1) at learner level a note row that has only a short learner text joins the notes in its place;
 *  (2) an open row of those two sections goes to the open fold, as on every page (never between results);
 *  (3) no section carries a figure of its own: a leaf has one live picture, its hero's.
 * → the model of buildPageModel, or null when the route is not a leaf or explorer page.
 */
export function leafModel(route, s) {
  const m = buildPageModel(route, s, { custom: OWN });
  if (!m || !LEAF_KINDS.has(m.def.kind)) return null;
  const learner = s.level === 'learner';
  const heroId = (m.def.hero && m.def.hero.row) || null;
  const isOpen = id => (statusOf(id) || {}).status === 'open';
  const entries = (rowsByPage()?.get(route) || []).filter(e => visibleIn(e.row, s.mode));
  const rowSection = new Map(m.rowSection);
  const open = [], openRows = [];
  let results = 0;
  const sections = m.sections.map(sec => {
    const shows = body => body.length > 0 || (!learner && (sec.details.length > 0 || sec.numbers.length > 0));
    if (!OWN.includes(sec.id)) {
      const g = m.open.find(x => x.id === sec.id);
      if (g) { open.push(g); openRows.push(...g.rows); }
      results += sec.body.length;
      return { ...sec, figures: [], show: shows(sec.body) };
    }
    const decl = (m.def.sections || []).find(x => x.id === sec.id) || {};
    const key = (decl.query && decl.query['shownOn.section']) || sec.id;
    const inBody = new Set(sec.body);
    const placed = sortEntries(entries.filter(e => (e.so.section === key || e.so.section === sec.id) && e.so.role !== 'detail' && e.so.role !== 'evidence'), s)
      .map(e => e.row.id).filter(id => id !== heroId);
    const ids = [...new Set(placed)].filter(id => inBody.has(id) || (learner && sec.id === NOTES && textFor(id, s) == null && hasShort(id, s)));
    const body = ids.filter(id => !isOpen(id));
    const openHere = ids.filter(isOpen);
    body.forEach(id => rowSection.set(id, sec.id));
    if (openHere.length) { open.push({ id: sec.id, label: sec.label, rows: openHere }); openHere.forEach(id => { openRows.push(id); rowSection.set(id, '__open'); }); }
    results += body.length;
    return { ...sec, body, drawerRows: [...body, ...sec.details, ...sec.numbers], figures: [], show: shows(body) };
  });
  return { ...m, sections, open, openRows, rowSection, results, learnerShort: learner && results < 3 };
}

/** "Leaf 2 of 8" with the dots of the path; "On the shelf · hangs under Leaf 5"; "Lens explorer" */
function Eyebrow({ place }) {
  const total = exploreMap().path.length;
  if (place.kind === 'path') return <><span className="xp__where">Leaf {place.n}{total ? ` of ${total}` : ''}</span><LeafDots current={place.n} /></>;
  if (place.kind === 'shelf') return <><span className="xp__where">On the shelf{place.under ? ` · hangs under Leaf ${place.under}` : ''}</span><LeafDots under={place.under} /></>;
  return <span className="xp__where">Lens explorer</span>;
}

export default function ExploreLeaf({ route }) {
  const s = useSettings();
  const model = useMemo(() => leafModel(route, s), [route, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!model) return <NotFound />;
  const def = model.def;
  const place = placeOf(def);
  const heading = { eyebrow: <Eyebrow place={place} />, title: pageTitle(route, s), deck: null };
  // the rows the lens chip counts: the page's rows and its hero, as the lens picker counts them
  const rowIds = [...new Set([model.hero && model.hero.id, ...(rowsByPage()?.get(route) || []).map(e => e.row.id)].filter(Boolean))];
  const custom = {
    [NOTES]: sec => <LeafNotes sec={sec} />,
    [TWO_WAYS]: sec => (
      <div className="leaf-ways">
        <LeafLensChip lens={def.explore && def.explore.lens} rowIds={rowIds} />
        {sec.body.map(id => <Statement key={id} id={id} />)}
      </div>
    ),
  };
  // a hero row without a text at this level leaves the hero out; the leaf keeps its picture (the frame shows it alone)
  const lone = !model.hero ? heroFigure(def, s) : null;
  return (
    <div className={`xp xp--${place.kind}`}>
      <PageView model={model} heading={heading} custom={custom} prevNext={null} heroAside={lone ? <FigureFrame id={lone} /> : null} />
      <div className="xp__foot">
        <LeafHang def={def} />
        <LeafNav def={def} />
      </div>
    </div>
  );
}
