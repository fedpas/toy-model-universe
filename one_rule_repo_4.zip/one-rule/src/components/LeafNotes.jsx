// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafNotes.jsx — the notes of a leaf (EXPLORE_PLAN §2.2, interface 15): each note is a row, rendered by Statement in the
// short register of its learner text when it has one and the level is learner, else in the full register; research level is always full.
// Not numbered (05 §8: the notes are not a sequence). At learner level the notes stand side by side, as Octavo's front did.
import { useSettings, textFor } from '../app/content.js';
import Statement from './Statement.jsx';

/** does the row have a learner text in the short register at these settings (mode, lens) */
export const hasShort = (id, s) => s.level === 'learner' && textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register: 'short' }) != null;
/** the register a note (or a leaf card's headline) is shown in: short at learner level when the row has a short text, else full */
export const registerOf = (id, s) => (hasShort(id, s) ? 'short' : 'full');

export default function LeafNotes({ sec }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  return (
    <div className={`leaf-notes${learner ? ' leaf-notes--side' : ''}`}>
      {sec.body.map(id => <Statement key={id} id={id} register={registerOf(id, s)} />)}
    </div>
  );
}
