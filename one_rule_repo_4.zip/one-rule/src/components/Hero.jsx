// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Hero.jsx — the hero: one statement (the short register when the row has one, else the full text) and one figure (a
// figure of figures.json, or the drawing a page passes as `aside`, such as the map of the steps). Always visible, never folded.
// At learner level one connective line under the statement says how we know: the scripts that ran, those only read, the inputs it
// needs (howWeKnow: numbers from the tables, no law stated; counted in the connective budget of tests/coverage.test.mjs).
// D31: when the seed of the hero's figure says size "wide", the hero carries hero--wide (and data-size="wide"): on screens of 1100 px and
// more the figure takes the full content width under the statement, its controls under the drawing (src/styles/components.css, "the wide
// hero"); below 1100 px, and for every other figure, the layout is the narrow right column. An `aside` is never wide.
// A tally row as the hero (EQN-006 on light, EQN-008 on steps/dirac) is drawn by TallyLine, as Section.jsx draws one in a section (docs/PHYSICS_AUDIT.md TL1).
import { useSettings } from '../app/content.js';
import { howWeKnow } from '../app/queries.js';
import { figuresById } from '../app/store.js';
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';

/** true when the figure's seed in figures.json says size "wide" (D31) */
export function isWideFigure(id) {
  const seed = id ? figuresById()?.get(id) : null;
  return !!(seed && seed.size === 'wide');
}

export default function Hero({ hero, aside = null, children }) {
  const s = useSettings();
  if (!hero) return null;
  const how = s.level === 'learner' ? howWeKnow(hero.id) : null;
  const fig = aside || (hero.figure ? <FigureFrame id={hero.figure} /> : null);
  const wide = !aside && isWideFigure(hero.figure);
  return (
    <div className={`hero${fig ? ' hero--fig' : ''}${wide ? ' hero--wide' : ''}`} id="hero" data-size={wide ? 'wide' : undefined}>
      <div className="hero__text">
        {isTallyRow(hero.id) && hero.register === 'full' ? <TallyLine id={hero.id} variant="hero" /> : <Statement id={hero.id} register={hero.register} variant="hero" />}
        {how ? <p className="hero__how" data-connective="how-we-know" data-row={hero.id}>{how}</p> : null}
        {children}
      </div>
      {fig ? <div className="hero__fig">{fig}</div> : null}
    </div>
  );
}
