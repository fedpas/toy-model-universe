// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafPath.jsx — the map of Explore as pages.json gives it (EXPLORE_PLAN §2.1): the registry the home carries
// (explore.map: the path of eight leaves, the shelf, the lens explorers), each entry with its page when it has one, and the eight dots
// that show where a leaf sits on the path (Octavo's frame). A leaf page the registry does not list is added from its own `explore`
// object, so no page is out of reach. Names only: no sentence here states anything.
import { useSettings } from '../app/content.js';
import { peekTable, pagesByRoute } from '../app/store.js';
import { pageTitle } from '../app/queries.js';
import Link from './Link.jsx';

export const EXPLORE = 'explore';
export const LEAF_KINDS = new Set(['leaf', 'explorer']);
const routeOf = slug => `${EXPLORE}/${slug}`;
const slugOf = p => (p.explore && p.explore.slug) || String(p.route).slice(EXPLORE.length + 1);

let memo = null;
/**
 * { home, path: [{ n, slug, name, route, page }], shelf: [{ slug, name, under, route, page }], lenses: [{ slug, name, route, page }] }
 * — `page` is the pages.json entry of the leaf (kind leaf) or explorer (kind explorer), or null when it has none ("not drawn yet").
 */
export function exploreMap() {
  const pages = peekTable('pages');
  if (!pages) return { home: null, path: [], shelf: [], lenses: [] };
  if (memo && memo.pages === pages) return memo.value;
  const byRoute = pagesByRoute();
  const home = byRoute.get(EXPLORE) || null;
  const reg = (home && home.explore && home.explore.map) || {};
  const pageOf = (slug, kind) => { const p = byRoute.get(routeOf(slug)); return p && p.kind === kind ? p : null; };
  const listed = list => new Set(list.map(e => e.slug));
  const leaves = pages.filter(p => p.kind === 'leaf' && p.explore);

  const path = (reg.path || []).map(e => ({ n: e.n, slug: e.slug, name: e.name || null, route: routeOf(e.slug), page: pageOf(e.slug, 'leaf') }));
  const onPath = listed(path);
  for (const p of leaves) if (p.explore.path && !onPath.has(slugOf(p))) path.push({ n: p.explore.path, slug: slugOf(p), name: null, route: p.route, page: p });
  path.sort((a, b) => a.n - b.n);

  const shelf = (reg.shelf || []).map(e => ({ slug: e.slug, name: e.name || null, under: e.under ?? null, route: routeOf(e.slug), page: pageOf(e.slug, 'leaf') }));
  const onShelf = listed(shelf);
  for (const p of leaves) if (!p.explore.path && !onShelf.has(slugOf(p)) && !onPath.has(slugOf(p))) shelf.push({ slug: slugOf(p), name: null, under: p.explore.under ?? null, route: p.route, page: p });

  const lenses = (reg.lenses || []).map(e => ({ slug: e.slug, name: e.name || null, route: routeOf(e.slug), page: pageOf(e.slug, 'explorer') }));
  const onLens = listed(lenses);
  for (const p of pages) if (p.kind === 'explorer' && !onLens.has(slugOf(p))) lenses.push({ slug: slugOf(p), name: null, route: p.route, page: p });

  const value = { home, path, shelf, lenses };
  memo = { pages, value };
  return value;
}

/** the name of an entry: its page's title (by mode and level), else the registry's name */
export const leafName = (e, s) => (e.page ? pageTitle(e.route, s) : e.name || e.slug);

/** where a leaf or explorer page sits: { kind: 'path' | 'shelf' | 'explorer', n, under } */
export function placeOf(def) {
  const x = (def && def.explore) || {};
  if (def && def.kind === 'explorer') return { kind: 'explorer', n: null, under: null };
  if (x.path) return { kind: 'path', n: x.path, under: null };
  return { kind: 'shelf', n: null, under: x.under ?? null };
}

/** the path leaf of number n, or null */
export const pathLeaf = n => exploreMap().path.find(e => e.n === n) || null;

/**
 * The eight dots of the path (a sequence, so numbered by position): the leaf of this page is marked, a shelf leaf marks the leaf it hangs
 * under, a leaf with a page is a link to it, a leaf without one is a hollow dot. Phrasing content only, so it can sit in the eyebrow line.
 */
export function LeafDots({ current = null, under = null }) {
  const s = useSettings();
  const { path } = exploreMap();
  if (!path.length) return null;
  return (
    <span className="leaf-dots" role="group" aria-label="The leaves of the path">
      {path.map(e => {
        const name = `Leaf ${e.n} · ${leafName(e, s)}`;
        const cls = ['leaf-dot', e.n === current ? 'is-here' : '', e.n === under ? 'is-under' : '', e.page ? '' : 'is-quiet'].filter(Boolean).join(' ');
        if (e.page && e.n !== current) return <Link key={e.slug} to={e.route} className={cls} aria-label={e.n === under ? `${name}, where this leaf hangs` : name} title={name}><span className="leaf-dot__mark" /></Link>;
        const label = e.n === current ? `${name}, this leaf` : `${name}, not drawn yet`;
        return <span key={e.slug} className={cls} role="img" aria-label={label} title={label} aria-current={e.n === current ? 'page' : undefined}><span className="leaf-dot__mark" /></span>;
      })}
    </span>
  );
}
