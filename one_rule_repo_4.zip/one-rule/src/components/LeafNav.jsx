// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafNav.jsx — the foot of a leaf page (EXPLORE_PLAN §2.2): the loose leaves that hang under this path leaf (only those
// with a page), and the navigation: the previous path leaf · Connect to the full Atlas · the next path leaf (leaves without a page are
// passed over; before the first, the Explore home; after the last, the shelf). A shelf leaf: the shelf · Connect · the leaf it hangs under.
// A lens explorer: the lens explorers · Connect. "Connect to the full Atlas" leads to the home of the row the leaf rests on (rowHome of
// explore.rests: the page of its lowest shownOn order) with at=<row>, where that page brings the row into view.
import { useSettings } from '../app/content.js';
import { rowHome, pageLabel, pageTitle } from '../app/queries.js';
import { rowsById } from '../app/store.js';
import Link from './Link.jsx';
import { exploreMap, leafName, placeOf, pathLeaf, EXPLORE } from './LeafPath.jsx';

/** the chips to the shelf leaves that hang under this path leaf */
export function LeafHang({ def }) {
  const s = useSettings();
  const place = placeOf(def);
  if (place.kind !== 'path') return null;
  const hang = exploreMap().shelf.filter(e => e.page && e.under === place.n);
  if (!hang.length) return null;
  return (
    <nav className="leaf-hang" aria-labelledby="leaf-hang-label">
      <span className="leaf-hang__label" id="leaf-hang-label">Loose leaves that hang here</span>
      <ul className="chips">
        {hang.map(e => <li key={e.slug}><Link to={e.route} className="chip">{leafName(e, s)}</Link></li>)}
      </ul>
    </nav>
  );
}

function Step({ to, at, dir, title, side }) {
  return (
    <Link to={to} at={at} className={`leaf-nav__link leaf-nav__link--${side}`} rel={side === 'prev' ? 'prev' : 'next'}>
      <span className="leaf-nav__dir">{dir}</span>
      <span className="leaf-nav__title">{title}</span>
    </Link>
  );
}

/** the two neighbours of a page: { prev, next }, each { to, at?, dir, title } or null */
export function neighbours(def, s) {
  const place = placeOf(def);
  const map = exploreMap();
  const home = map.home ? pageTitle(EXPLORE, s) : 'Explore';
  if (place.kind === 'path') {
    const drawn = map.path.filter(e => e.page);
    const i = drawn.findIndex(e => e.n === place.n);
    const p = i > 0 ? drawn[i - 1] : null;
    const n = i >= 0 && i + 1 < drawn.length ? drawn[i + 1] : null;
    return {
      prev: p ? { to: p.route, dir: 'Previous leaf', title: leafName(p, s) } : { to: EXPLORE, dir: 'Back to', title: home },
      next: n ? { to: n.route, dir: 'Next leaf', title: leafName(n, s) } : map.shelf.some(e => e.page) ? { to: EXPLORE, at: 'shelf', dir: 'Next', title: 'On the shelf' } : null,
    };
  }
  if (place.kind === 'shelf') {
    const u = place.under ? pathLeaf(place.under) : null;
    return {
      prev: { to: EXPLORE, at: 'shelf', dir: 'Back to', title: 'The shelf' },
      next: u && u.page ? { to: u.route, dir: `Hangs under leaf ${u.n}`, title: leafName(u, s) } : null,
    };
  }
  return { prev: { to: EXPLORE, at: 'explorers', dir: 'Back to', title: 'The lens explorers' }, next: null };
}

export default function LeafNav({ def }) {
  const s = useSettings();
  const { prev, next } = neighbours(def, s);
  const rests = def.explore && def.explore.rests;
  const home = rests && rowsById()?.has(rests) ? rowHome(rests) : null;
  return (
    <nav className="leaf-nav" aria-label="Leaves and the full Atlas">
      {prev ? <Step side="prev" {...prev} /> : <span className="leaf-nav__gap leaf-nav__gap--prev" />}
      {home ? (
        <Link to={home.path} at={home.at} className="leaf-nav__connect" data-connect={rests}>
          <span className="leaf-nav__dir">Connect to the full Atlas</span>
          <span className="leaf-nav__title">{pageLabel(home.path, s)}</span>
        </Link>
      ) : <span className="leaf-nav__gap leaf-nav__gap--connect" />}
      {next ? <Step side="next" {...next} /> : <span className="leaf-nav__gap leaf-nav__gap--next" />}
    </nav>
  );
}
