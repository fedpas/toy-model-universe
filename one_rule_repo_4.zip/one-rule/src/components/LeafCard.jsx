// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafCard.jsx — a card of the Explore home (EXPLORE_PLAN §2.1): the name of a leaf (or lens explorer) as the link to its
// page, and under it, never inside the link, the leaf's hero row as a compact Statement (short register at learner level when the row has
// one). A path leaf shows its place on the path; a shelf leaf the path leaf it hangs under. A path leaf without a page is a quiet card
// with its name and no link.
import { useSettings } from '../app/content.js';
import Statement from './Statement.jsx';
import Link from './Link.jsx';
import { leafName, pathLeaf } from './LeafPath.jsx';
import { registerOf } from './LeafNotes.jsx';

export default function LeafCard({ entry, kind, skipRow = null }) {
  const s = useSettings();
  const built = !!entry.page;
  const title = leafName(entry, s);
  const row = built && entry.page.hero ? entry.page.hero.row || null : null;
  // the leaf whose hero row is the home's own hero (the clock) does not repeat it: its card says where to begin
  const start = !!row && row === skipRow;
  const hero = start ? null : row;
  const under = kind === 'shelf' && entry.under ? pathLeaf(entry.under) : null;
  return (
    <li className={`leaf-card leaf-card--${kind}${built ? '' : ' is-quiet'}`} data-leaf={entry.slug}>
      {kind === 'path' ? <span className="leaf-card__n" aria-hidden="true">{entry.n}</span> : null}
      <h3 className="leaf-card__title">
        {built ? <Link to={entry.route} className="leaf-card__link">{title}</Link> : <span className="leaf-card__name">{title}</span>}
      </h3>
      {kind === 'path' && !built ? <p className="leaf-card__quiet">not drawn yet</p> : null}
      {start ? <p className="leaf-card__start">Start here</p> : null}
      {under ? (
        <p className="leaf-card__under">
          <span>Hangs under</span>
          <span className="leaf-card__pin" aria-hidden="true">{under.n}</span>
          <span className="vh">leaf {under.n},</span>
          <span>{leafName(under, s)}</span>
        </p>
      ) : null}
      {hero ? <Statement id={hero} register={registerOf(hero, s)} variant="card" evidence={false} /> : null}
    </li>
  );
}
