# The Cascade Atlas

A web app and its evidence: a React application that explores one construction, the **bit rule**, together with the exact check scripts that recompute its statements, the tests of the app and of the scripts, the research reports behind its lens chapters, a speed test and a replication kit. It is delivered as an update over a repository (see `BUILDING.md`).

## What the atlas states

**The bit rule** gives every Clifford algebra a basis of blades that are bit masks. The product of two blades is the blade of the XOR of their labels, up to a sign: e_a e_b = s(a,b) e_{a xor b}, where s is the sign of reordering times the product of the squares ε of the generators the two blades share, and each generator squares to +1, −1 or 0. A cell Cl(p,q,r) is the algebra with p generators of square +1, q of square −1 and r of square 0.

**What it is.** The bit rule is a *labelling*: a choice of orthonormal frame and of labels in which the products of one algebra are easy to read. The atlas states it as a labelling and as a set of primordial ideas, not as a theory of nature. What is solid is what scripts recompute: the structure of the cells (the triple (V,Q,π) of a cell without null generators and (V,Q,π,N) with them, the clock as a Brown invariant, the mirror, the null part, doubling), the results of the lens chapters (category theory, Baez, Schuller, Furey, Hestenes and Lasenby–Doran–Gull, the Pumplün dictionary) and the calibrations on known physics.

**Calibrations.** The two physics tours (Maxwell, and Furey's model) are calibrations: a run on something whose answer is known, to show which inputs the method needs. A calibration is not a test of a new theory. The equations pages state what each equation takes from outside the algebra (a chart, a frame, the grade a field lives in, a time direction, a complex structure, a postulated equation).

**Status words.** Every statement carries one or more of five flags, shown as icons with the word as hover text and accessible name:

| Flag | Meaning |
|---|---|
| *standard* | in a textbook or a paper (with its citation) |
| *checked* | a script recomputes it, and the statement names the check id |
| *ours* | our reading or proposal |
| *open* | unresolved |
| *input* | a choice or datum that the page needs and the algebra does not supply |

*Known ground* is a statement that is standard and checked and neither ours, open nor input. The reader filter in Settings hides it. Each tab of the tabbed pages opens with a strip that says what it needs and what it brings in from outside.

## The parts of the app

The pages are listed in `storyCopy.js` (`PAGES`) and the numbered steps in `steps.js`; every "PAGE k OF N" and "STEP k OF N" label is derived from them. Each page has three audiences (Young Learner, Physicist, Mathematician), English and Italian slots, a dark and a light theme, and works at phone width.

| Part | What it holds |
|---|---|
| **Rule** | the bit rule drawn four ways (Clifford, Simplex, Cube, Prime) and the story of how it is built |
| **Atlas** | the 25 cards of the cells Cl(p,q) with their algebra type (checked) and their role names (readings, *ours*), the Spatial/Temporal toggle, the Genesis story as primordial ideas |
| **Conventions** | the sign and signature conventions, the mirror, a glossary of the words the pages use, and step 1, the clock and the trinity |
| **Maxwell** | Calibration 1: Maxwell's equations in 1 to 4 space and 1 to 4 time dimensions, charges in fields, the ladders |
| **Shapes** | the simplex, cube, orthoplex, demicube and Gosset polytopes |
| **Equations** | the steps (2 to 16) from the commutators to mirrors, Dirac, pointors and spin, coupling, Yang–Mills, matter, gravity, the projective step, gauge gravity, null surfaces, Forque dynamics, springs and rigid bodies, and a tally of every step |
| **Furey** | Calibration 2: her papers rebuilt from the octonion table, her 2026 model, the three generations, what may help |
| **Lenses** | steps 17 to 20: finite groups, and the three chapters (category lens, Baez, Schuller) with live widgets and downloadable check scripts |
| **Map** | the status of every part, a tree of knowledge (each branch names its script and its place in the app), what the atlas holds, the credit |
| **For researchers** | the table of statements with flags, citation and check script, the translation matrix, the theorems T1 to T20 with their verification status, the open questions with their answers, the sources, the reports, the analyses (the readings of the atlas by seven specialists, the two joint reports and the seven discovery runs, each as a page, a markdown source and a code zip), how to run every check |
| **Ask** | a chat guide that answers from the same axioms and the same audit, gives a status to each claim, and translates the same elements of the atlas into the language of a lens (string theory, solid state, fields, algebra, geometry, categories) from one dictionary |

Settings (the gear) holds the language, the audience, the theme (Auto, Light, Dark) and the reader filter. The address takes `?theme=light|dark|auto` and `?filter=known` or `?filter=known+std` without storing anything. An address such as `?for=furey` opens a note to a researcher or group (English only, no address of anyone in it) over the page the address names. The footer holds the contact form and the credit.

## What is in the folders

| Where | What |
|---|---|
| root | the pages (`*Section.jsx`, `*Widgets.jsx`), their copy and data (`*Copy.js`, `*Data.js`, English and Italian side by side), the engines (`*Engine.js`), `claimsData.js` (generated from `claimsLocators*.json` by `make_claims_data.mjs`), the mirrors of the downloadable scripts (`*SelfcheckSource.js`), `test_*.mjs`, `build.sh`, `run_tests.sh` |
| `api/`, `lib/` | the three serverless routes (two chat routes, the contact route) and their helpers: guards, the answer filter, the persona of the Ask guide |
| `selfcheck/` | the exact check scripts of the pages, each with its stored `.json` and a `regen_*.sh` that rebuilds the data module and the mirror; `core_check.py`; `reports/` (the five scripts of the lens reports and the three widget scripts); `steps15_17/` |
| `researchers_checks/` | `check_T1.py` to `check_T20.py`: the theorems of the For researchers page |
| `orthoplex/` | the shapes checks and drawings |
| `reports/` | the research reports as HTML (`reports/html/`), their builders, tests and logs, the translation matrix, the manifest |
| `replication/` | the blind replication kit: a brief, 52 exact answers, a grader and the recorded runs |
| `label_bench_src/`, `label_bench.html` | the standalone speed test of the label claims (`README_label_bench.md`), `README_pgadyn_check.md` for the timing behind the rigid-body step |
| `harness/` | the entry and the stand-ins that `build.sh` bundles for the browser tests |

## Build and test

    sh build.sh            # dist/app.js, dist/app.html and dist/reports/html/
    sh run_tests.sh        # every test, one line each; --data or --browser for one group
    sh run_tests.sh --ci   # for a machine that may have no browser: the data group, then the browser group only if Chromium starts

`BUILDING.md` has the order in which to apply the package to a repository, the host files it needs, the dependencies, what each test needs, what the tests do not cover, and the settings of the three routes. The tests are found by name (`test_*.mjs`); a test that exits 77 has skipped itself and says why.

Three tests guard the whole package: `test_package.mjs` (the import graph is closed and nothing carries a path of a machine), `test_license.mjs` (the licence header of every file) and `test_no_history.mjs` (every text of the app, the reports, the scripts and the READMEs states what is true now and does not narrate an earlier state of the package).

## The checks

A check is a Python script with a stored result. The page-specific scripts print one line per check id and take `--write f.json` and `--compare f.json`; `sh selfcheck/regen_<name>.sh` reruns a script, compares it with its stored data, and only then rewrites the data module the app reads and the mirrored source the page offers for download (it stops at the first error and leaves the stored files as they were when a check fails). A statement tagged *checked* names its check id.

- `selfcheck/core_check.py` (standard library, about 4 s): the 28 checks `core·B1` to `core·B20` behind the core statements: w = π + 2Q is a Z4 quadratic refinement, the clock is its Brown invariant (for r ≥ 1 that of the quotient Cl(p,q)), the mirror Q → Q + π, the type table, the null part, the universal grading group, doubling and the spinor weights, Furey's axes as a Lagrangian, the symmetry group of (V,Q,π), the Gauss–Milgram phase of E_n, the Kepler signs against the projective step, reversion, the classification of the triples to n = 12, the triple against the signature, the cells M₁₆(ℝ) of row 8.
- `selfcheck/bridges/`: the cross-field checks (ids `bd·…`) behind the statements that name them, in two families, physics (121 checks) and mathematics (227 checks), each script with its stored log and a regeneration script; `selfcheck/bridges/README.md` lists every check id with its statement.
- `selfcheck/*_selfcheck.py` and `*_check.py`: one per page (Maxwell, dictionary, three generations, equations steps, mirrors, projective, Forque, spin, spring, rigid bodies, null surfaces, matrix representations, Furey's papers, the shapes). `python3 run_all.py` runs the asserting construction check of the Furey pages.
- `selfcheck/reports/` (`cat·`, `baez·`, `fibre·`, `bridge·`, `qm·`) and the widget scripts (`catw·`, `bzw·`, `scw·`): `selfcheck/reports/README.md` lists every check id with its statement.
- `selfcheck/steps15_17/`: the clock, gauge-gravity and finite-group scripts, with a sabotage harness (`run_mutations.py`).
- `researchers_checks/check_T#.py`: the theorems; `researchers_checks/README.md` says what each asserts.

## The reports

`reports/html/` holds the research reports, each a single self-contained page: the category lens, Baez, Schuller, Hestenes and Lasenby–Doran–Gull, Furey, and the Pumplün dictionary. The build copies them to `dist/reports/html/`; the For researchers page lists them and the Lenses page links to its three. `reports/README.md` says what each report checks and how to run its tests (`sh reports/run_report_tests.sh`; `pip install -r reports/requirements.txt` installs the python modules the checks need).

`reports/analyses/` holds the analyses of the atlas, each shipped as it was generated: its markdown source unchanged, one self-contained page made from it, and the zip of the code it quotes. The For researchers page lists them in its Analyses block, where each opens as a page and downloads as page, source and code; the build copies them to `dist/reports/analyses/`. `reports/analyses/README.md` says how another analysis joins. `reports/lens_dictionary.json` is the dictionary between the atlas and the languages of the lenses (`make_lens_dictionary.mjs` writes `lensDictionaryData.js` and the compact form the Ask guide reads).

## The speed test and the replication kit

`label_bench.html` times in your browser whether the label speed-ups the app mentions give any gain on your machine; it measures and does not prove (`README_label_bench.md`). `replication/` lets another reader, from a brief alone, reach the 52 reference answers (`replication/README.md`).

## The Ask guide and the contact form

The Ask page and the chat routes use a persona (`lib/chatPersona.js`) that knows the pages, the steps and the status of each claim, and a filter (`lib/answerFilter.js`) that removes images and non-`https` links from every answer before it is shown. The contact form asks a short question about the XOR rule as its human check and forwards one message to a form service; the address that receives the messages is set at the service and is in no file of the package. The settings of both routes are in `BUILDING.md`.

## Language

The English text is the reference. The new and changed text is English in the Italian slots too; the Italian audit checks for English prose and English labels are off while that holds (`V11_ENGLISH_IN_ITALIAN` in `test_i18n_audit.mjs`). `RELEASE_NOTES_v13.md` says what v13 holds.

## Licence

PolyForm Noncommercial 1.0.0 (`LICENSE`, `NOTICE`): free for noncommercial use, not for commercial use. Every source file and script carries a three-line header.
