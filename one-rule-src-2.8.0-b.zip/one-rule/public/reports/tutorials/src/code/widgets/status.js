(function (id) {
  // the status rule, as tools/build_content.mjs computes it (statusWithoutFlags and the chain of section 2), rule for rule; each return names its rule
  const QUESTION = ['question', 'conjecture', 'pointer'];
  function withoutFlags(r) {
    const ev = r.ev, ranE = ev.filter(e => e.mode === 'ran');
    if (QUESTION.includes(r.kind) || r.ptype === 'open') return ['open', 'no flags: a question, conjecture or pointer, or ptype open'];
    if (ranE.some(e => e.passed)) return ['proved-by-atlas', 'no flags: a ran item whose script has a recorded run that passed with no failure'];
    if (ranE.length || (ev.length && ev.every(e => e.mode === 'read'))) return ['cited', 'no flags: a ran item without a passing run, or every item read only'];
    if (r.kind === 'reading' || r.ptype === 'reading') return ['ours', 'no flags: a reading'];
    if (r.group === 'INP') return ['input', 'no flags: the group INP'];
    if (r.q > 0 && r.stdRead) return ['standard', 'no flags: a notion of square -1 and a standard source that was read'];
    return ['ours', 'no flags: nothing else applies'];
  }
  function status(r) {
    const flags = new Set(r.flags), ran = r.ev.filter(e => e.mode === 'ran'), ranPassed = ran.some(e => e.passed);
    const readOnly = r.ev.length > 0 && r.ev.every(e => e.mode === 'read');
    if (r.kind === 'story' || r.kind === 'meta' || r.onlyMeta || r.legacyLabel === 'note') return ['meta', 'a story or meta row, the single notion i-meta, or the label note'];
    if (r.id.startsWith('CAND-')) return ran.length && ranPassed ? ['proved-by-atlas', 'a candidate whose ran check has a passing run'] : ['candidate', 'a candidate without a passing ran check'];
    if (!flags.size) return withoutFlags(r);
    if (QUESTION.includes(r.kind) || r.ptype === 'open' || (flags.has('open') && !flags.has('checked') && !flags.has('standard') && !['dead-end', 'counterexample'].includes(r.kind))) return ['open', 'a question kind, ptype open, or the flag open without checked and standard'];
    if (flags.has('checked') && ran.length && ranPassed) return ['proved-by-atlas', 'the flag checked and a ran item whose script has a passing recorded run'];
    if (flags.has('checked') && (readOnly || !ran.length)) return ['cited', 'the flag checked, but no ran item (or every item read only)'];
    if (r.kind === 'reading' || r.ptype === 'reading' || r.legacyLabel === 'reading') return ['ours', 'a reading'];
    if (r.group === 'INP' || (r.rr > 0 && flags.has('input') && !flags.has('checked'))) return ['input', 'the group INP, or a notion of square 0 with the flag input and not checked'];
    if (flags.has('standard')) return ['standard', 'the flag standard'];
    if (flags.has('ours')) return ['ours', 'the flag ours'];
    if (flags.has('open')) return ['open', 'the flag open'];
    return ['ours', 'nothing else applies'];
  }
  const BADGE = { open: 'open', cited: 'not yet proved here', ours: 'our reading', input: 'needs an input' };
  const WORD = { 'proved-by-atlas': 'proved by the Atlas', standard: 'a standard result', ours: 'our reading', open: 'open', input: 'an input', meta: 'about the Atlas', cited: 'not yet proved here', candidate: 'a candidate' };
  // self-test: ten rows of content/rows.json as the rule sees them, with the status of content/derived/status.json (scripts/test_widgets.mjs re-derives them)
  const CASES = [
    [{"id": "ATL-020c", "kind": "reading", "ptype": "reading", "group": "ATL", "legacyLabel": "reading", "onlyMeta": false, "flags": ["ours", "open"], "ev": [], "q": 2, "rr": 1, "stdRead": true}, "open"],
    [{"id": "ATL-025", "kind": "computation", "ptype": "identity", "group": "ATL", "legacyLabel": "line", "onlyMeta": false, "flags": ["checked"], "ev": [{"mode": "ran", "passed": false}, {"mode": "ran", "passed": true}], "q": 0, "rr": 2, "stdRead": true}, "proved-by-atlas"],
    [{"id": "ATL-501", "kind": "story", "ptype": null, "group": "ATL", "legacyLabel": "story", "onlyMeta": true, "flags": [], "ev": [], "q": 0, "rr": 1, "stdRead": false}, "meta"],
    [{"id": "ATY-011", "kind": "reading", "ptype": "reading", "group": "ATY", "legacyLabel": null, "onlyMeta": false, "flags": ["ours"], "ev": [], "q": 2, "rr": 2, "stdRead": true}, "ours"],
    [{"id": "ATY-015", "kind": "reading", "ptype": "reading", "group": "ATY", "legacyLabel": null, "onlyMeta": false, "flags": [], "ev": [], "q": 2, "rr": 0, "stdRead": true}, "ours"],
    [{"id": "CAND-001", "kind": "range", "ptype": "identity", "group": "CAND", "legacyLabel": null, "onlyMeta": false, "flags": ["checked"], "ev": [{"mode": "ran", "passed": true}, {"mode": "ran", "passed": true}, {"mode": "ran", "passed": true}], "q": 3, "rr": 0, "stdRead": true}, "proved-by-atlas"],
    [{"id": "CPL-012", "kind": "computation", "ptype": "identity", "group": "CPL", "legacyLabel": null, "onlyMeta": false, "flags": [], "ev": [{"mode": "ran", "passed": true}, {"mode": "ran", "passed": true}], "q": 1, "rr": 0, "stdRead": true}, "proved-by-atlas"],
    [{"id": "EQN-003", "kind": "reduction", "ptype": "definition", "group": "EQN", "legacyLabel": "line", "onlyMeta": false, "flags": ["standard"], "ev": [{"mode": "ran", "passed": true}, {"mode": "ran", "passed": true}], "q": 2, "rr": 1, "stdRead": true}, "standard"],
    [{"id": "INP-001", "kind": "definition", "ptype": "postulate", "group": "INP", "legacyLabel": "line", "onlyMeta": false, "flags": ["input"], "ev": [{"mode": "unspecified", "passed": false}], "q": 0, "rr": 2, "stdRead": false}, "input"],
    [{"id": "LNB-005b", "kind": "example", "ptype": "calibration", "group": "LNB", "legacyLabel": "line", "onlyMeta": false, "flags": ["ours"], "ev": [{"mode": "ran", "passed": false}, {"mode": "ran", "passed": true}, {"mode": "ran", "passed": true}], "q": 2, "rr": 1, "stdRead": true}, "ours"]];
  const selfTest = CASES.length === 10 && CASES.every(([r, s]) => status(r)[0] === s);
  if (typeof document === 'undefined') return { status, withoutFlags, CASES, selfTest };
  const el = document.getElementById(id); if (!el) return;
  if (!selfTest) { el.textContent = 'self-test failed'; return; }
  const sel = (k, opts, v) => '<select data-k="' + k + '">' + opts.map(o => '<option' + (o === v ? ' selected' : '') + '>' + o + '</option>').join('') + '</select>';
  const box = (k, label, on) => '<label><input type="checkbox" data-k="' + k + '"' + (on ? ' checked' : '') + '> ' + label + '</label>';
  el.innerHTML = '<div><label>kind ' + sel('kind', ['computation', 'theorem', 'reading', 'question', 'dead-end', 'meta', 'story'], 'computation') + '</label> <label>ptype ' + sel('ptype', ['identity', 'open', 'reading'], 'identity') + '</label> ' +
    box('inp', 'group INP') + ' ' + box('cand', 'id CAND-') + '</div>' +
    '<div style="margin-top:6px"><label>flags</label> ' + ['checked', 'standard', 'ours', 'open', 'input'].map(f => '<button type="button" data-f="' + f + '" aria-pressed="' + (f === 'checked') + '">' + f + '</button>').join(' ') + '</div>' +
    '<div style="margin-top:6px">' + [0, 1].map(i => '<label>evidence ' + (i + 1) + ' ' + sel('m' + i, ['none', 'ran', 'read', 'unspecified'], i ? 'none' : 'ran') + '</label> <label>last run ' + sel('p' + i, ['passed', 'failed', 'no run'], 'passed') + '</label>').join('<br>') + '</div>' +
    '<div style="margin-top:6px">' + box('rr', 'a notion of square 0') + ' ' + box('q', 'a notion of square −1') + ' ' + box('std', 'standard source read') + '</div>' +
    '<p class="widget__out st-out" aria-live="polite"></p>';
  const out = el.querySelector('.st-out'), val = k => el.querySelector('[data-k="' + k + '"]');
  function read() {
    const flags = [...el.querySelectorAll('button[data-f]')].filter(b => b.getAttribute('aria-pressed') === 'true').map(b => b.dataset.f);
    const ev = [0, 1].filter(i => val('m' + i).value !== 'none').map(i => ({ mode: val('m' + i).value, passed: val('p' + i).value === 'passed' }));
    return { id: val('cand').checked ? 'CAND-900' : 'ROW-900', kind: val('kind').value, ptype: val('ptype').value, group: val('inp').checked ? 'INP' : 'ROW', legacyLabel: null, onlyMeta: false,
      flags, ev, rr: val('rr').checked ? 1 : 0, q: val('q').checked ? 1 : 0, stdRead: val('std').checked };
  }
  function show() { const [s, why] = status(read()); out.textContent = 'status: ' + s + '  (' + WORD[s] + ')' + (BADGE[s] ? '   badge: ' + BADGE[s] : '') + '\nrule:   ' + why; }
  el.addEventListener('click', ev => { const b = ev.target.closest('button[data-f]'); if (!b) return; b.setAttribute('aria-pressed', b.getAttribute('aria-pressed') === 'true' ? 'false' : 'true'); show(); });
  el.addEventListener('change', show);
  show();
})
