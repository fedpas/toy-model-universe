# Coding with the bit rule: a builder's guide for agents

## E0 · The rule, and what this guide is for

A course on programming asks two things of a program: that it computes what it says, and that a reader can tell when it does not. The Atlas asks the same of every script in its package, and it answers with one function. A blade is a bit pattern, and the product of two blades is the XOR of the patterns with a sign (MAP-001, proved by the Atlas). Everything else (the cells Cl(p,q,r), the clock, the field equations, the curvature of a frame) is built on that function, and every statement that a script decides is printed as one line that can fail.

The rule, in one line. Take $n$ switches; a label $a$ is an $n$-bit integer, and it stands for the blade $e_a$, the product of the generators that are on, in increasing order. Then

$$e_a e_b = s(a,b)\, e_{a \oplus b}, \qquad s(a,b) = (-1)^{N(a,b)} \prod_{i \in a \wedge b} \varepsilon_i ,$$

where $N(a,b)$ counts the pairs ($i$ on in $a$, $j$ on in $b$, $j < i$), the swaps that sort the word $e_a e_b$, and $\varepsilon_i \in \{+1, -1, 0\}$ is the square of the generator $i$. The squares are the only input besides $n$.

The worked example is $n = 2$. The same rule with the squares (+1, +1), (−1, −1) and (0, 0) gives three algebras: the real 2 × 2 matrices M₂(ℝ) = Cl(2,0), the quaternions ℍ = Cl(0,2), and the exterior algebra Λ(ℝ²). In the three tables 0, 0 and 7 of the 16 products vanish and 4, 6 and 1 carry a minus sign, the numbers the Atlas stores for its own check scw·P1c.

![The 16 products e_a e_b of the four blades of n = 2 for the squares (+1,+1), (−1,−1) and (0,0): row a, column b; orange cells carry a minus sign, grey cells vanish. Drawn by figs_code.py from the bit rule of checks/researchers_checks/bitrule_A.py.](figs/n2_tables.svg)

This guide is for an agent that has to check a script of the Atlas, or write one, without reading the whole package first. It teaches the shape and the rules of a check, never a shortcut past them: a script you write after this guide still needs its BEFORE note, its two routes, its controls, its log and its record (E8). Read E1, E4, E5, E6 and E8 to check and write scripts; E2, E3, E7 and E9 show the rule at work on elements, an oscillator and the four physics engines. Every number below comes from a log of the package or from a log of this guide's own scripts (`scripts/logs/`), and the script that printed it is named beside it.

## E1 · The kernel in twelve lines

### E1.1 · The product of two labels

The product needs three things: the label of the result, the sign of the swaps, and the squares of the switches that are on in both factors. The label is `a ^ b`. The swap count is a loop over the switches of `a`: for each switch `i` that is on, count the switches of `b` below `i`. The squares enter only through `a & b`, the switches the two factors share; one shared switch of square 0 makes the product vanish.

The kernel of the site, `engines/bitrule.js`, says it in twelve lines of code (lines 9 to 24 of the file, without their comments), word for word:

```js
export const popcount = x => { let c = 0; while (x) { x &= x - 1; c++; } return c; };
export function nPairs(a, b) {
  let c = 0, i = 0;
  while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; }
  return c;
}
export const reorderSign = (a, b) => (nPairs(a, b) & 1 ? -1 : 1);
export function sign(a, b, eps) {
  let v = reorderSign(a, b); let m = a & b, i = 0;
  while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; }
  return v;
}
```

Its header says that the algorithm is that of `checks/researchers_checks/bitrule_A.py` (`N_pairs`, `s`, `mul`), line for line, and that `tests/kernel.test.mjs` compares the two. The Python twin is the one the check scripts import: `BR(eps).s(a, b)` is the sign, `BR(eps).mul(x, y)` the product of two multivectors stored as dictionaries from labels to coefficients. A third copy, `checks/selfcheck/steps15_17/bitcliff.py`, is the shared engine of the chapter scripts, and the gravity engine `checks/selfcheck/gravity_selfcheck.py` has its own `bmul`. They compute one function; a check names the copy it uses.

![The sign of e₁e₃e₄ · e₂e₃ in Cl(1,3): each arc is one swap, a switch j of b passing a switch i > j of a; three swaps give −1, the shared switch e₃ has square −1, so the sign is +1 and the label is 1101 XOR 0110 = 1011. Drawn by figs_code.py with N_pairs and BR.s of bitrule_A.py.](figs/swaps.svg)

The figure reads the twelve lines on one product. The word is $e_1 e_3 e_4 \cdot e_2 e_3$. To sort it, $e_2$ passes $e_3$ and $e_4$ of the first factor, and $e_3$ of the second factor passes $e_4$: $N = 3$. The shared switch is $e_3$, of square −1. So $s = (-1)^3 \cdot (-1) = +1$ and the product is $+e_1 e_2 e_4$.

![The kernel engines/bitrule.js (left, with its line numbers) and the Python twin researchers_checks/bitrule_A.py (right): popcount, the pair count, the sign of the swaps, the squares of the shared switches; tests/kernel.test.mjs compares the two on a fixture of 121 cells. Drawn by figs_code.py, which reads the line numbers from the two files.](figs/kernel.svg)

#### If you want the proof

Associativity is the theorem T1 of the Atlas (For researchers › Theorems; checked exhaustively for small n by `researchers_checks/check_T1.py`, and stated in MAP-001). Its reason is short: $N(a,b) \bmod 2$ is a bilinear form over $\mathbb{F}_2$ in the bits of $a$ and $b$, and the product of the squares over $a \wedge b$ is a bilinear form too, written multiplicatively. A bilinear form is a 2-cocycle on the group $\mathbb{Z}_2^n$, so the twisted group algebra it defines is associative; with squares $\pm 1$ it is Cl(p,q), and with null squares it is the same algebra with a radical.

### E1.2 · The self-test against stored products

A kernel is tested against numbers it did not compute. `tests/kernel.test.mjs` reads `tests/fixtures/bitrule_reference.json`, written from the Python reference by `tools/gen_kernel_fixture.py`: the full sign table of 121 cells (every choice of squares from {+1, −1, 0} for up to four generators: 1 + 3 + 9 + 27 + 81 cells) and 60 products of random multivectors. It compares every sign, every product, associativity on every triple of blades of every cell up to n = 4, and the statement that on disjoint labels the sign does not see the squares; a run here prints `kernel: 376395 of 376395 checks hold`. The type of each cell, the other stored object the engines lean on, is in `engines/stored/labels_v15.json`: the 45 cells with n ≤ 8, each with its clock value `s` = p − q mod 8, its kind (R, R2, C, H, H2), its matrix size `N` and its algebra (E7.5 checks it).

The widget below copies the four functions of the kernel. Its self-test, at the top of the file, recomputes ten stored products (signs and labels written by `bitrule_A.py`) and writes "self-test failed" into the box when one differs; the test of this guide, `scripts/test_widgets.mjs`, compares its sign with the fixture on all 22621 pairs of labels of the 121 cells and finds no difference.

@@widget product

> **Try it.** Set Cl(1,3) and the labels a = e₁e₂, b = e₁e₂: the product is −1, the square of a rotation bivector. Then press Λ (all squares 0): every label that shares a switch now gives 0, and the sign of e₁ · e₂ against e₂ · e₁ is unchanged, because disjoint labels never read the squares.

### Questions for a specialist (E1)

- **A compiler writer** would ask whether the sign table of one cell, being a bilinear form mod 2 times the squares, can be emitted as straight-line code, one table per cell. MAP-001 is the nearest row (proved by the Atlas); no generator of such code is in the package: open.
- **An algebraist** would ask what the cohomology of the cocycle is once null bits make the labels a monoid with zero. LNC-086 asks exactly that and is open; on the cube category the sign is a coboundary, and every anticommuting sign is a gauge transform of the Jordan–Wigner string for n ≤ 6 (CAND-092, CAND-103, both proved by the Atlas).
- **A performance engineer** would ask how the pair loop compares with a table lookup for n ≤ 8. The package has a label bench (`checks/selfcheck/bench_labels.mjs`), but no row states a speed: open.

## E2 · Elements, two laws and their controls

### E2.1 · An element is a dictionary

A general element is a dictionary from labels to coefficients. The spring script of the Atlas keeps it in a class `MV` beside its own one-line product `bmul`, which counts the swaps with a shift loop instead of `nPairs`; the rule is the same. Word for word, from `checks/selfcheck/spring_selfcheck.py`:

```python
def pc(x): return bin(x).count('1')
def bmul(a, b, sq):
    s = 1; t = a >> 1
    while t:
        if pc(t & b) & 1: s = -s
        t >>= 1
    c = a & b
    for i in range(len(sq)):
        if c >> i & 1: s *= sq[i]
    return s, a ^ b
class MV:
    def __init__(s, sq, d=None): s.sq = sq; s.d = {k: v for k, v in (d or {}).items() if v != 0}
    def __add__(s, o): r = dict(s.d); [r.__setitem__(k, r.get(k, 0) + v) for k, v in o.d.items()]; return MV(s.sq, r)
    def scale(s, c): return MV(s.sq, {k: v * c for k, v in s.d.items()})
    def __mul__(s, o):
        r = {}
        for a, x in s.d.items():
            for b, y in o.d.items():
                sg, m = bmul(a, b, s.sq)
                if sg: r[m] = r.get(m, 0) + sg * x * y
        return MV(s.sq, r)
    def __eq__(s, o): return s.d == o.d
    def get(s, m): return s.d.get(m, 0)
```

The product `MV * MV` multiplies every pair of terms with `bmul` and drops a term whose sign is 0. With these lines a whole algebra of dimension $2^n$ is in memory, with exact integer or `Fraction` coefficients. Work in `checks/selfcheck/` (or put it on `sys.path`) and `from spring_selfcheck import pc, bmul, MV`.

### E2.2 · Two laws, and two wrong products

A check that cannot fail checks nothing, so the scripts of the Atlas run a wrong version beside the right one wherever one can be written, and want it caught. The habit fits in a few lines: associativity on random elements with integer coefficients, anticommutation of distinct generators, in five signatures; then the same two tests on two wrong products. The lines below are written for this guide, in the manner of the spring script:

```python
import random
rng = random.Random(1)
def rand(sq): return MV(sq, {a: rng.randint(-9, 9) for a in range(1 << len(sq))})
def assoc(sq, trials=20):
    return all((x * y) * z == x * (y * z) for x, y, z in ((rand(sq), rand(sq), rand(sq)) for _ in range(trials)))
def anticommute(sq):
    g = [MV(sq, {1 << i: 1}) for i in range(len(sq))]
    return all(g[i] * g[j] == (g[j] * g[i]).scale(-1) for i in range(len(sq)) for j in range(len(sq)) if i != j)
sigs = [[1, 1], [-1, -1], [0, 0], [1, -1, -1, -1], [1, 1, -1, 0]]
```

The first wrong product drops every minus sign (`abs` of the sign), the second takes the OR of the labels instead of their XOR. The figure is the table that `figs_code.py` prints when it runs these tests on `spring_selfcheck.bmul` and on the two wrong versions:

![Associativity and anticommutation (yes or no) for the true product of spring_selfcheck.py and for two wrong products, in the five signatures (+,+), (−,−), (0,0), (+,−,−,−), (+,+,−,0); twenty random triples with coefficients in −9..9, seed 1. Drawn by figs_code.py, which runs the tests on spring_selfcheck's bmul and MV.](figs/controls.svg)

Both laws hold for the true product. Without minus signs the product is still associative, and only anticommutation sees that the generators now commute. With OR for XOR a switch on in both factors no longer squares away, so $(e_2 e_1) e_1 \ne e_2 (e_1 e_1)$ and associativity fails in the four signatures with a square ±1, while distinct generators share no switch and still anticommute. Each law sees what the other misses: that is why a check of the Atlas has more than one control, and why the gravity scripts run eight faults (E4.4).

One wrong product passes both laws and every other test: a gauge transform, $s'(a,b) = s(a,b)\,c(a)c(b)/c(a \oplus b)$ for any signs $c$. It is not wrong. It is the same algebra in another basis ($e_a \mapsto c(a) e_a$), and every anticommuting sign on the cube is of this kind (CAND-103, proved by the Atlas for n ≤ 6). A control must be a version that is wrong for the statement under test, not merely different.

> **Try it.** Break `bmul` your own way: flip the sign when a count is non-zero rather than odd (`if pc(t & b):` for `if pc(t & b) & 1:`). Which of `assoc` and `anticommute` notices, and in which of the five signatures? Put the true product back with `bmul = good` after `good = bmul`.

### Questions for a specialist (E2)

- **A tester** would ask for a mutation score of the kernel itself, the share of small edits of `bmul` that the two laws catch. The package scores its Furey engine this way (`checks/reports/furey/logs/mutate_furey.log`: mutants caught 44 of 44) and its gravity engine (E4.4); no row gives a score for the kernel: open.
- **A statistician** would ask how likely twenty random triples are to miss a non-associative product. The gravity engine states such a bound for its own random fields (the Schwartz–Zippel lemma, recalled, in the docstring of `gravity_selfcheck.py`; CPL-011 is the row of the action it serves, proved by the Atlas); this toy test states none: open.
- **A representation theorist** would ask which wrong signs are equivalent to the right one. The gauge transforms are, and only they keep the anticommutation of distinct generators (CAND-103); a sign with a different class changes the algebra (the octonion cochain of CAND-094 is not a cocycle at all).

## E3 · An oscillator, exactly

### E3.1 · The series of a rotation

The spring page and the row A1 of `spring_selfcheck.py` write the state of an oscillator as $s = x e_1 + q e_2$, position and scaled momentum, and its motion as $s' = \omega B s$ with $B = e_1 e_2$. The solution is the series $s(t) = \sum_k (\omega t)^k B^k s_0 / k!$, and the function below builds it in exact fractions, each term the one before times $B$ and $\omega/k$ (written for this guide, in the manner of `oscillator` of the spring script):

```python
from fractions import Fraction as F
def series(sq, x0, q0, w, N):
    u, v = MV(sq, {1: 1}), MV(sq, {2: 1})
    B = u * v
    terms = [u.scale(x0) + v.scale(q0)]
    for k in range(1, N + 1):
        terms.append((B * terms[-1]).scale(F(w, k)))
    return [t.get(1) for t in terms]
```

Since $B^2 = -\varepsilon_1 \varepsilon_2$, the three pairs of squares (1, 1), (1, −1) and (0, 1) give $B^2 = -1, +1, 0$. For $x(0) = 3$, $q(0) = 5$, $\omega = 2$ the coefficients of $x(t)$ from $t^0$ to $t^6$ are 3, 10, −6, −20/3, 2, 4/3, −4/15 for $B^2 = -1$ (the series of $3\cos 2t + 5 \sin 2t$, the harmonic oscillator); 3, −10, 6, −20/3, 2, −4/3, 4/15 for $B^2 = +1$ ($3\cosh 2t - 5\sinh 2t$, the inverted oscillator); and 3, 10, 0, 0, 0, 0, 0 for $B^2 = 0$ (free motion, $3 + 10t$). The figure draws the series to $t^{14}$ against the closed forms; on $0 \le t \le 1$ the largest gap is 3.5e-08 (relative to the value, or absolute where the value is below 1), which is the truncation of the series, not an error of the rule.

![x(t) for the oscillator s′ = ωBs with ω = 2, x(0) = 3, q(0) = 5: lines are the exact series to t¹⁴ built with spring_selfcheck's MV, dots the closed forms 3 cos 2t + 5 sin 2t, 3 cosh 2t − 5 sinh 2t and 3 + 10t. Drawn by figs_code.py.](figs/oscillator.svg)

### E3.2 · The row A1 of the spring script

The spring script checks the same three series against the closed forms. Run from `checks/selfcheck/`:

```text
$ python3 -I -B spring_selfcheck.py --row A1
ok   A1: harmonic case: B^2 = -1, x'' = -4 x as exact power series and the closed form (cos, cosh, straight line) matches [(a,b)=(1,1)]
ok   A1: inverted case: B^2 = 1, x'' = 4 x as exact power series and the closed form (cos, cosh, straight line) matches [(a,b)=(1,-1)]
ok   A1: free case: B^2 = 0, x'' = 0 x as exact power series and the closed form (cos, cosh, straight line) matches [(a,b)=(0,1)]
3/3 checks hold
```

One bivector, three squares, three kinds of motion: EQN-018 (proved by the Atlas) states it for the spring network on the cube, "the three kinds of i as oscillator, inverted oscillator, free motion", with 60 exact claims in 22 rows of the spring script. The three squares as circle, hyperbola and line, with the oscillator in its three cases and the Walsh spectrum of the cubes, is SPR-002 (standard results, each checked exactly by the spring script).

> **Try it.** Build the 8 × 8 matrix $D$ of the left multiplication by $e_1 + e_2 + e_3$ (for each label `x` and `i` in 0, 1, 2, `bmul(1 << i, x, sq)` is `(s, m)` with `m = x ^ (1 << i)`, and `s` goes to `D[m][x]`); check with `matmul` of the spring script that $D^2 = 3I$ for the squares [1, 1, 1], as the row D1 of the spring script states, and predict $D^2$ for [1, 1, −1].

### Questions for a specialist (E3)

- **A numerical analyst** would compare the exact series with a symplectic integrator at a fixed step. The planets scripts of the gravity folder compare the page's own Runge–Kutta integrator with published ephemerides, but no row compares an integrator with the spring series: open.
- **A geometer** would ask whether the three motions are the three geometries of the plane. SPR-002 states them so (standard, checked); the Atlas checks the series, the closed forms and the spectrum, not the geometric reading.
- **An analyst** would ask for a bound of the remainder for every $t$. The bound is the textbook one for the exponential series (recalled); the spring script checks finitely many orders.

## E4 · The discipline of a check

### E4.1 · Three helpers

Every check script of the Atlas prints one line per check and one last line that sums them up. The gravity folder keeps the three helpers in `checks/selfcheck/gravity/b1lib.py`, word for word:

```python
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
```

`chk` prints the line and remembers a failure, `head` opens a part, `finish` prints the last line and sets the exit code: 0 when every check passed, 1 otherwise. Some scripts, `shifted_dirac.py` among them, and the scripts of this guide add a count line, `checks: 64 ok, 0 FAIL`, before the last line. The check lines are printed, not asserted: an `assert` stops at the first failure and hides the others, while `chk` prints every line and lets the run finish (asserts stay for the inner invariants of a helper).

![The anatomy of a check script: the eight regions of checks/selfcheck/proofs/shifted_dirac.py, 627 lines, from the licence header and the docstring to finish(STEP), with their line numbers; framed are the parts any new check copies. Drawn by figs_code.py, which finds the regions in the file by their first lines.](figs/check_anatomy.svg)

### E4.2 · Four kinds of line

The tag in brackets says which route computed the statement:

- `[bit]`: computed with the bit rule or an engine built on it, in exact arithmetic where the docstring says so;
- `[std]`: computed by a standard route that never touches the labels: index calculus, Christoffel symbols, matrices, numpy and scipy, a textbook formula (`[std2]` is a second, hand-typed standard route);
- `[bit==std]`: the two routes compared, the line that carries the claim;
- `[ctl]`: a control, a wrong version that must fail; the line reads `ok` when it does.

Read the lines of a part as one argument. In the log of `checks/selfcheck/gravity/a4_einstein_tensor.py` (the check A4, that the Einstein form of the engine is the Einstein tensor on frames that are not vacuum), two exact routes and a numerical one agree first (`[std]`), then the engine's curvature is the Riemann tensor of the metric (`[bit==std]`), then a `[bit]` line states that the frames are not vacuum, so that the comparison that follows is not a match of zeros, and a `[ctl]` line shows that a wrong sign `s_n = +1` differs from the engine on 18 of 18 samples. A comparison that could pass because both sides are 0 gets a line that says they are not.

![The anatomy of a log: the first heading of checks/selfcheck/proofs/logs/shifted_dirac.log and one line of each tag, the count of the 64 check lines (36 bit, 10 std, 14 bit==std, 4 ctl), the count line and the last line FAILS (SHIFTED-DIRAC): none. Drawn by figs_code.py from the shipped log.](figs/log_anatomy.svg)

### E4.3 · The faults of a script

A `[ctl]` line runs one wrong version beside the right one. A `--fault NAME` option goes further: it puts the wrong version into the main lines, and the run must then end with FAILS and exit 1. `shifted_dirac.py` has nine (NOI, SINSIGN, FIXEDA, RETONLY, NOW, SHIFTSIGN, KGSIGN, KEEPODD, NULLONE; its docstring names each). Its fault log, `checks/selfcheck/proofs/logs/shifted_dirac.faults.log`, holds the nine runs: seven end with a FAILS line (FIXEDA with 62 ok and 2 FAIL, KEEPODD and KGSIGN with 61 and 3, NOW, RETONLY and SHIFTSIGN with 62 and 2, NULLONE with 63 and 1), and two, NOI and SINSIGN, stop on a numpy exception before their last line. An exception also exits with a code that is not 0, so the fault is seen, as the mutation tables count it (E); but a log without its last line is a log to read to the end before trusting.

Random data are drawn from fixed seeds (`random.Random(1)`), so a run prints the same check lines every time; only timing lines differ, and they are never part of an `ok` or `FAIL` line.

### E4.4 · The engine faults M1 to M8, and the mutation table

The gravity folder tests its checks as well as its engine. A mutation run puts one of eight deliberate faults into the engine, in memory (no file is changed), and runs a script under each: M1 the quadratic term of R doubled; M2 one pair (0, 2) left out of the Einstein form; M3 one sign of the h table flipped; M4 the sign of the exterior derivative; M5 one entry of the h table dropped; M6 the structure constants of the bivector pairs that share the last generator flipped; M7 every h entry flipped; M8 the h entries that act on the time vector flipped (`checks/selfcheck/gravity/README.md`, "Engine faults M1 to M8"; h is the table of a bivector acting on a vector, f the table of two bivectors). A cell of the table is the number of check lines that fail under the fault; 0 means the script does not see it, and that is a finding: the script does not read the quantity the fault changes.

![The mutation table: for each of the 42 gravity scripts with a full table in checks/selfcheck/gravity/mut/, the number of check lines that fail under each engine fault M1–M8 (0: not seen; E: stopped on an exception, counted as seen); the bottom row counts the scripts that see each fault. Drawn by figs_code.py from the TABLE line of each mut log.](figs/mutation.svg)

Read the table by columns and by rows. By columns: M2 is the fault fewest scripts see (7 of 26): a pair missing from the Einstein form can only be seen by a script that reads the Einstein form; M4, M6 and M7 are seen by 17. By rows: `gm_maxwell_stress` sees none of the eight, `gm_double_copy` sees all eight with 6 failing lines each, and `gm_cartan_bianchi`, with 87 ok lines in its run without a fault, loses 54 of them under M1. A silent cell is explained, not hidden: M4 changes $d$ and $\omega$ together, which leaves $R$ and the Einstein form unchanged, so the README has `d_probe.py` read $d$ itself, and `blind_spot_probes.py` checks the reason for three blind spots (the Kretschmann scalar of C2 under M1, the particle at rest of D1 under M3 and M5, the fifth chip of F2 under M6).

### E4.5 · The words of a result

A check states what ran, at the scope that ran. Four words carry the scope, and an agent uses them as the Atlas does:

- **exact**: computed in integers or fractions (or exact Gaussian integers), so equality is equality. A line that says exact must not pass through a float.
- **numerical**: computed in floating point with a stated tolerance or a stated deviation (`max deviation 4.6e-14`); it agrees, it does not prove.
- **recalled**: a textbook fact used without being read in a source of the package, named by its author and title, never with a theorem or equation number that was not read.
- **checked at the scope that ran**: "checked at these points, to these orders, for these n, with these controls". A finite check of an identity on random data is a check with a stated failure bound, not a proof for all n; a proof for all n is a derivation, attached and said to be one.

Two more rules complete the discipline. A negative result is reported as a negative result: a check whose pre-declared wording turns out too wide narrows the wording, never the check. And the statement is written before the script: the BEFORE note holds the statement, the wording on a pass and on a fail, the controls, and which faults each check should see.

@@widget logreader

The log reader counts the check lines by tag and reads the last line. Its self-test parses two runs of `scripts/dirac_rest.py` (the plain run and its fault run) against their stored counts. Run on every log that `content/check_runs.json` names and the package ships, it agrees with the record's ok count, FAIL count and last line for 229 of 255 records (`scripts/test_widgets.mjs`); the 26 others are logs without check lines (a JSON summary, a mutation table, a script that prints `604/604 claims hold` but whose record names another last line) or records that store no counts.

> **Try it.** Load "a fault run" and delete the line `fault: LEFTJ …`: the verdict turns from "the fault is seen" to "fails". Then delete the FAIL lines as well and keep the FAILS line: the reader still says "fails", because the last line lists failures. A verdict reads the whole log, not one line.

### Questions for a specialist (E4)

- **A verification engineer** would ask what a silent row such as `gm_maxwell_stress` reads. Its table is in `mut/gm_maxwell_stress.mut.log`; the reason is the script's own, and the guide does not decide it: open here.
- **A statistician** would ask for the false-pass bound of each random check. The gravity scripts state theirs (the A2 and A2b rows, "the bound is the result; a pass adds no physics", in `gravity_selfcheck.py`); CPL-011 is a row that cites them (proved by the Atlas).
- **A physicist** would ask whether two routes can share a convention and agree for the wrong reason. The sign chain H3 runs both conventions for the squares of space and time (INP-049, an input: the sign of the cosmological term is minus the square of the extra generator), so the convention is a stated input, not a hidden one.

## E5 · The check record and the run record

### E5.1 · The record of a check

A script is entered in `content/checks.json` with one record. The package has 344. A record says what the script decides, how, against what, and where its log is; the figure takes the record of `shifted_dirac.py` field by field.

![The record of checks/selfcheck/proofs/shifted_dirac.py in content/checks.json, field by field: id, family, script, what, method, notes, ids (12 statement ids), independentRoute, controls, deps, storedResult, log, rowsNaming (7 rows), since. Drawn by figs_code.py from the record.](figs/check_record.svg)

The fields an agent reads first are `ids` (the statements the script decides, each with its own statement: `shd·OP`, `shd·ORD`, `shd·RET` and nine more), `independentRoute` and `controls` (both start with yes and say which), and `log`. `rowsNaming` lists the rows that cite the script (ATY-004 to ATY-010 here); `storedResult` names a stored file the script compares with, or null; `since` is the release that added the record.

### E5.2 · The record of a run

A run is entered in `content/check_runs.json`, which has 601 records: the script, the date, who ran it and from which folder, `passed`, a status sentence, the seconds, the ok and FAIL counts, the last line, the log it was read from, and for some runs a mode (plain, compare, mutation).

![The run record of shifted_dirac.py in content/check_runs.json, field by field (passed true, 0.5 s, 64 ok, 0 fail, last line FAILS (SHIFTED-DIRAC): none, source its log), and the rule of tools/build_content.mjs that reads it: the last run of a script by date, passed not false and no FAIL. Drawn by figs_code.py from the record; the date and the name of the runner are left out.](figs/run_record.svg)

The build reads two fields only: `passed` and `fail`. For each script it keeps the record with the latest date (`r.date >= lastRun[k].date`, so of two records with the same date the later one in the file wins), and a run counts as passing when it exists, `passed` is not false, and `fail` is not above 0. The status sentence is for people; the build does not parse it. Some scripts have no passing run by design: a helper such as `b1lib.py`, whose run record says n/a, is imported by the checks and decides no row itself.

### E5.3 · From a row to its status

A row cites its checks in `evidence`, a list of `{check, script, mode}`: `check` is a statement id of `checks.json` (or a script name), `script` the file, `mode` one of `ran`, `read` or `unspecified`. The status is computed, never typed, by `tools/build_content.mjs`, in a fixed order: the first rule that matches decides.

![From the row ATY-004 to its status: the row (kind computation, flag checked, three evidence items of mode ran), its first evidence item (shd·RET, shifted_dirac.py), the check record (12 ids, the log), the last run (passed, 64 ok, 0 fail) and the rule, which gives proved-by-atlas. Drawn by figs_code.py from content/rows.json, checks.json, check_runs.json and derived/status.json.](figs/evidence_path.svg)

The row ATY-004 (proved by the Atlas; the shifted mass terms on the plane waves of the coupling step) carries the legacy flag `checked` and three evidence items of mode `ran`, all on `shifted_dirac.py`, whose last run passed. So it is proved by the Atlas. Change one input and the word changes, and not always as one would guess. If every run of its script failed, the row would not become `cited`: `cited` needs the flag `checked` and no ran item at all (or only read items), so a checked row whose ran checks fail falls through to its other flags (standard, ours, open), and with none of them to our reading. Without the flag `checked`, a row with the flag `ours` stays our reading even with passing runs (LNB-005b is such a row: our reading, with two passing ran items). A row without any flag follows the shorter chain of the rows without flags, where a ran item without a passing run does give `cited`.

![The status rule of tools/build_content.mjs as a flow: the first match wins, top to bottom, first for every row, then for the rows with legacy flags, then for the rows without; below, the built status of the 1758 rows. Drawn by figs_code.py; the counts are those of content/derived/status.json.](figs/status_flow.svg)

The built status of the 1758 rows is proved-by-atlas 926, meta 459, ours 124, open 119, input 93, standard 37; no row is cited and none a candidate. The widget runs the same rule, rule for rule. Its self-test holds ten rows of `content/rows.json` as the rule sees them, one for each rule that fires first in the file, with their built status; `scripts/test_widgets.mjs` maps every row of the package into the widget's input and gets the built status for 1758 of 1758.

@@widget status

> **Try it.** Start from the default (flag checked, one ran item whose run passed: proved-by-atlas). Set the run to "failed": the row falls through to our reading, not to cited. Press standard: now it is a standard result. Set the mode of the evidence to "read": cited, whatever the other flags. Remove every flag and set the mode back to "ran": the chain without flags gives cited for a failed run and proved-by-atlas for a passed one.

### E5.4 · The pipeline, and the export for agents

No status, count or page of the Atlas is typed by hand into the site. The tables of `content/` go through a fixed pipeline: `npm run content` checks the learner texts, merges the tables and runs `tools/build_content.mjs`, which validates them and writes the status; `sh build.sh` builds the site in `dist/`; `npm test` runs the suites of `package.json` (eight under `test:data`, the kernel test first, and ten under `test:ui` in a browser); `sh tools/release.sh` runs the same steps in order, stops at the first that fails and names it, and writes the zip of the release with its sha256.

![The pipeline of the package: the tables of content/ (1758 rows, 344 check records, 601 run records), npm run content with tools/build_content.mjs (the status), sh build.sh (the site and the export), npm test (9 data suites, 11 browser suites), sh tools/release.sh. Drawn by figs_code.py from the tables and package.json.](figs/pipeline.svg)

The same tables are written at every build as a tuning set, `dist/content/tuning/` (by `tools/export_tuning.mjs`; the page `#/agents` explains it, and the tuning guide of the docs, `AI_TUNING.md`, states its loop and its limits). Every statement is one record of `rows.jsonl`, 1758 lines: its words, its label (the notions, the 29-bit mask, the signature, the address), the known law it states, its evidence with the last recorded run, and its status. A model predicting a status is graded against `evidence[].lastRun`. The export says its own limits: a check that passed is a recorded run of a script, not a measurement of nature, and an open mark means no theorem yet.

### Questions for a specialist (E5)

- **A data engineer** would ask whether a tie of dates should be an error. The build lets the later record win (E5.2); no row states the intent: open.
- **An auditor** would ask whether every count of a run record can be traced to its log. For 229 of 255 records with a shipped log the counts and the last line agree with the log as the log reader reads it; the 26 others are of other formats (E4.5): a schema rule for log formats is open.
- **A model builder** would ask whether the status can be predicted from the label alone. That is the task "label to law" of the export; the Atlas states it as the aim of the tuning, not as a result (the tuning README of `content/tuning/`).

## E6 · Reading any script of the package by its shape

### E6.1 · Families and folders

The scripts live in a few folders, and the folder says what kind of check a script is. `checks/selfcheck/` holds the page scripts (one per page of the steps: `maxwell_selfcheck.py`, `spring_selfcheck.py`, `gravity_selfcheck.py` …, each with a JSON file of the page's numbers that `--compare` checks against). `checks/selfcheck/gravity/` holds the gravity steps with their helpers, logs, `mut/` tables and README. `checks/selfcheck/proofs/` holds the checks written to close one statement each, with their logs and fault logs. `checks/selfcheck/bridges/` holds the bridges between fields (mathematics and physics, one family per theme). `checks/researchers_checks/` holds the checks of the theorems T1 to T20 (`check_T<n>.py`, statements in `content/theorems.json`) and the minimal engine `bitrule_A.py`. `checks/reports/` holds the checks of the reports (Baez, the category report, Furey, Hestenes, Pumplün, Schuller), `checks/selfcheck/reports/` the checks of the lenses (`cat_check.py`, `bridge_check.py`, `fibre_check.py` …), and `checks/selfcheck/steps15_17/` the chapter scripts on `bitcliff.py`.

![The folders of the check scripts with the number of records of content/checks.json in each (bar) and the number of statement ids they carry (right): 344 records in all. Drawn by figs_code.py from the script field of each record.](figs/folders.svg)

The counts say how each folder speaks. The gravity folder has the most records (112) but few statement ids (81), because a gravity step is one statement per script; the bridges (79 records, 348 ids) and the proofs (18 records, 235 ids) decide many statements per script. The 23 records of `researchers_checks/` carry no ids in `checks.json`: their statements are the theorems.

### E6.2 · Ids

Three conventions name what a script decides. A statement id of a family is `fam·n` with a middle dot (`shd·RET`, `aty·matter·1`, `bd·sol·17`, `scw·P1c`): a family prefix chosen by the script, then the number or name of the statement. A gravity step is named by its step id in capitals with hyphens (A4, C1, H3-pseudoscalar, YM-SOL), which is also the name in its last line `FAILS (C1): none`. A record whose script decides one thing is named by the script itself (`selfcheck/gravity/c1_birkhoff.py`, or the bare name `c1_birkhoff` in a row's evidence). A row of the Atlas has a third kind of id, its group and number (ATY-004, GRV-012, CAND-124, LNS-013d).

### E6.3 · The docstring

A check script opens with four header lines (shebang, the SPDX licence, the notice, the terms) and a docstring in the present tense, in a fixed order: the statement, with the statement ids in brackets; `[bit]`, what the engine path computes and in which arithmetic; `[std]`, the independent route; `[ctl]`, the controls and the `--fault` names with what each one breaks; `Scope.`, the n, points and orders reached and what is not built; `Run:`, the command line, from the package root, from the script's own folder, and under `python3 -I -B`. A script finds its engine from its own location (`os.path.abspath(__file__)`), never from the current folder, and writes nothing into the package at run time but stdout.

### E6.4 · Find the check that decides a row

`node tools/proofs_todo.mjs --row ID` prints a row's status, kind, flags and page, its evidence with each script and mode, what it depends on and what rests on it, and its research text. For ATY-004:

```text
== ATY-004 · status proved-by-atlas · kind computation · ptype identity · legacy flags ["checked"] · page steps/coupling#eq-coupling
   evidence: shd·RET [checks/selfcheck/proofs/shifted_dirac.py] ran; shd·SYM [checks/selfcheck/proofs/shifted_dirac.py] ran; shd·ORD [checks/selfcheck/proofs/shifted_dirac.py] ran
   depends on: EQN-009 (derives), CPL-003 (derives); 2 rows rest on it
```

From there the path is fixed: the statement id (`shd·RET`) is in the record of the script in `checks.json`; its statement says what the assert decides; the script's docstring names the part, and the log shows the line. A row is closed by a check only when the assert that decides each part of its sentence has been read and matched to the sentence's words and numbers; where the script decides less than the sentence says, the sentence is narrowed to the scope the check shows.

### E6.5 · Read a mutation table

A `mut/<script>.mut.log` has a header (the script, the engine, the run without a fault with its ok and fail counts and seconds), one block per fault (SEEN or NOT seen, the counts, the first failing lines) and a last line `TABLE` with the eight cells. Read it with E4.4: a cell of 0 is not a pass of the fault, it is the statement that the script never reads the quantity that fault changes, and the README or a probe script says why.

> **Try it.** Pick a gravity script from the README of `checks/selfcheck/gravity/`, find its row of the claims table, then run `node tools/proofs_todo.mjs --row` on one of those rows: does the row's evidence name the script with mode `ran`, and does the row's sentence say no more than the script's `[bit==std]` lines?

### Questions for a specialist (E6)

- **A maintainer** would ask for one grammar of ids. The three conventions (E6.2) coexist, and the build accepts a script name or a statement id as `check`; a single grammar is open.
- **A librarian** would ask where the statements of the theorem checks live, since their records carry no ids: in `content/theorems.json` (T1 to T20), cited by rows such as MAP-001.
- **A reviewer** would ask which rows have no check at all. In the built status none is cited; the 119 open and 138 ours rows are not claimed as proved, and LNC-086 is an example of an open question.

## E7 · One worked check per engine

Each script below is a complete check of at most forty lines in `scripts/`, with its log in `scripts/logs/` and one `--fault`. They import the package's rule by path through `scripts/tutlib.py`, which finds the package's `checks/` folder (the variable `ATLAS_CHECKS`, else the first `checks/` above the file), imports `researchers_checks/bitrule_A.py` from it and gives `chk`, `head`, `finish` and the fault option, as `b1lib.py` does for the gravity folder. `scripts/run_all.sh` runs them one at a time under `ulimit -v 3000000`, `nice -n 10`, `timeout 900` and `python3 -I -B`, and writes the logs and `logs/SUMMARY.txt`.

### E7.1 · Maxwell: a plane wave on the labels

Statement: a plane wave $F = F_0 f(k \cdot x)$, $F_0$ a constant bivector, solves $\nabla F = 0$ on the labels of Cl(1,3) exactly when $\omega^2 = |\mathbf{k}|^2$. The rows: the Maxwell equation on the cells, EQN-006 (proved by the Atlas), and its split by grade (E9.1); the Hodge star as multiplication by the pseudoscalar, which on labels is the complement $a \mapsto a \oplus 1111$, LNS-011b (proved by the Atlas). The trick: $\nabla F = \hat k F_0 f'$ with $\hat k = \omega\gamma_0 + k_1\gamma_1 + k_2\gamma_2 + k_3\gamma_3$, so a wave exists exactly when left multiplication by the vector $\hat k$ has a kernel on the bivectors, and $\hat k^2 = \omega^2 - |\mathbf{k}|^2$.

`scripts/maxwell_wave.py` (38 lines) computes the kernel by exact rank on the labels (`rank_fr` of `bitrule_A.py`), and the standard route solves the vector form $\mathbf{k}\cdot\mathbf{E} = \mathbf{k}\cdot\mathbf{B} = 0$, $\mathbf{k}\times\mathbf{E} = \omega\mathbf{B}$, $\mathbf{k}\times\mathbf{B} = -\omega\mathbf{E}$ with numpy. Its log, `scripts/logs/maxwell_wave.log`:

```text
1. nabla F = 0 for F = F0 f(k.x): the kernel of F0 -> khat F0 on the bivectors of Cl(1,3)
  ok   [bit] kernel 2 on the 5 null k, 0 on the 5 others (exact rank on the labels): [2, 2, 2, 2, 2, 0, 0, 0, 0, 0]
  ok   [bit] khat F0 for a generic F0 has 4 grade-1 and 4 grade-3 components: the two halves of the equations
  ok   [bit] k = (5,3,4,0): F0 = khat g3 and its star F0 I solve the equation; the star sends each label of F0 to its complement
  ok   [std] the vector form has the same kernels (numpy SVD): [2, 2, 2, 2, 2, 0, 0, 0, 0, 0]
  ok   [bit==std] the 10 kernel dimensions agree
  ok   [ctl] Cl(4,0) (all squares +1): no plane wave at any of the 10 k: the light cone comes from the signature

checks: 6 ok, 0 FAIL
FAILS (MAXWELL-WAVE): none
```

The control runs the same code on Cl(4,0), where $\hat k^2 = \omega^2 + |\mathbf{k}|^2$ is never 0: no wave, so the light cone comes from the signature and not from the code. That is the content of LNS-102 (proved by the Atlas): waves that travel like light need exactly one plus switch or exactly one minus switch. Under `--fault NOSIGN` (the swap sign dropped from the product) three lines fail and the kernels read `[2, 0, 0, 0, 2, 0, 0, 0, 0, 0]` (`scripts/logs/maxwell_wave.fault.log`).

![The dimension of the kernel of F₀ ↦ k̂F₀ on the six bivectors for ω and k = (k, 0, 0) from 0 to 6: in Cl(1,3) it is 2 exactly on ω = |k|, the light cone, in Cl(4,0) it is 0 off the origin (6 at k = 0, ω = 0). Drawn by figs_code.py with the exact rank of bitrule_A.py.](figs/maxwell_kernel.svg)

### E7.2 · Dirac–Hestenes: the rest solution

Statement: the rest solution $\psi = \rho^{1/2} R\, e^{-J m t}$, with $R$ a rotor of space, solves $\nabla\psi J = m\psi\gamma_0$ (EQN-008, proved by the Atlas), where $J = \gamma_2\gamma_1$ and both $J$ and $\gamma_0$ multiply $\psi$ on the right. At rest the solutions are the four real dimensions of the even Pauli part, each $\psi_0 = \rho^{1/2}R$ (CAND-126, proved by the Atlas). The trick: the complex unit of the Dirac equation is the bivector $J$, which squares to −1 and commutes with $\gamma_0$, so the phase $e^{-Jmt}$ is a real even element and the equation lives in the real algebra (E9.2).

`scripts/dirac_rest.py` (40 lines) checks the equation as an exact power series in $t$: with $\psi_k = \psi_0(-mJ)^k/k!$, the coefficient of $t^k$ is $\gamma_0 (k+1)\psi_{k+1} J = m\psi_k\gamma_0$, to order 8. The standard route takes the Dirac matrices of the Dirac representation, where the rest equation is $(\Gamma_0 - 1)u = 0$. Its log, `scripts/logs/dirac_rest.log`:

```text
1. the rest solutions of nabla psi J = m psi g0 (series in t, exact on the labels)
  ok   [bit] psi_0 = 2 R with R = (3 + 4 e12)/5 (5 + 12 e23)/13: psi_0 rev(psi_0) = rho = 4
  ok   [bit] psi = psi_0 exp(-J m t), m = 3: the equation holds at every order t^0 ... t^7
  ok   [bit] the even psi_0 that commute with g0 span 4 real dimensions: 1, e12, e13, e23 (the even Pauli part), each a solution
  ok   [std] Dirac matrices: G_a G_b + G_b G_a = 2 eta_ab; the rest equation (G0 - 1) u = 0 has 4 real dimensions
  ok   [bit==std] the two counts of rest solutions agree (4 = 4)
  ok   [ctl] psi_0 = 1 + e01 (a boost part) is not a solution: the order t^0 fails

checks: 6 ok, 0 FAIL
FAILS (DIRAC-REST): none
```

The rotor is rational on purpose, $R = \frac{3 + 4e_{12}}{5}\cdot\frac{5 + 12e_{23}}{13}$, so that $R\tilde R = 1$ holds exactly. Under `--fault LEFTJ` (the phase put on the left of $\psi_0$) three lines fail; the line `[bit==std]` still passes, because the count of rest solutions does not read the series, which is why a fault is judged on the whole log and not on one line.

### E7.3 · Yang–Mills: a Lie table of bivectors

Statement: the triangles of the commutator graph that close are so(3) (YM-001, proved by the Atlas: from four generators the graph also has open triangles), and the BPST field is self-dual at a rational point (CAND-124, proved by the Atlas: self-dual on Euclidean ℝ⁴ with instanton number 1). The trick: the gauge algebra is the Lie table of the bivectors, $[B_a, B_b] = f_{ab}{}^c B_c$, read off the bit rule; the field strength is $F^c = dA^c + \tfrac12 f_{ab}{}^c A^a A^b$, and the Hodge star of 2-forms is the complement map with the sign of the permutation, which the bit rule with null squares computes.

`scripts/ym_bpst.py` (40 lines) builds the table of the six bivectors of Cl(0,4) and the so(3) of Cl(0,3), the 't Hooft symbols with the sign of each permutation read off the rule, and the BPST field $A^a_m = 2\eta^a_{mn}x^n/(x^2 + \rho^2)$ with its exact derivatives at $x = (1, 2, -1, 3)$, $\rho^2 = 2$. Its log, `scripts/logs/ym_bpst.log`:

```text
1. the commutator graph of the bivectors of Cl(0,4), and the BPST field at one rational point
  ok   [bit] 8 triangles: 4 closed {e_ab, e_bc, e_ac}, 4 open {e_ab, e_ac, e_ad}
  ok   [std] numpy: on each closed triangle ad(B) is antisymmetric of rank 3, an isomorphism onto so(3)
  ok   [bit] BPST at x = (1,2,-1,3), rho^2 = 2: F^a = *F^a on the six 2-form labels, the star read as the complement map with its sign
  ok   [std] numpy: eta^a_mn = (1/2) eps_mnrs eta^a_rs (Levi-Civita by the parity of inversions), so F = -4 eta rho^2/Q^2 is self-dual
  ok   [bit==std] the exact components equal the closed form -4 eta rho^2/Q^2, Q = 17, 18 components (max deviation 0.0e+00)
  ok   [ctl] the anti-instanton (eta-bar): F = -*F, so the self-duality line fails for it

checks: 6 ok, 0 FAIL
FAILS (YM-BPST): none
```

The standard route is the closed form $F = -4\eta\rho^2/(x^2+\rho^2)^2$ of Belavin, Polyakov, Schwarz and Tyupkin ("Pseudoparticle solutions of the Yang–Mills equations", recalled), with the self-duality of $\eta$ checked by numpy's Levi-Civita symbol; the package's own check of the same field (`checks/selfcheck/gravity/ym_solutions.py`, YM-SOL) runs it on exact jets at many points, with $D{\star}F = 0$ and the instanton number. Under `--fault ABELIAN` (the bracket term dropped) the self-duality fails and the components miss the closed form by 1.8e-01: the bracket of the Lie table is what makes the field self-dual.

### E7.4 · Gravity: Schwarzschild at one rational point

Statement: the Einstein form $E_a$ of the gravity engine vanishes on the Kerr–Schild frame of Schwarzschild, $f = M/\rho$, at the point $p = (1, 2, 2)$ with $\rho = 3$ and $M = 1/2$. The rows: the solutions in the radial Kerr–Schild class, GRV-012 (proved by the Atlas); the Einstein form is the Einstein tensor for any frame, GRV-010 (proved by the Atlas); the metric itself is borrowed, INP-054 (an input). The trick: forms are the bit rule with null generators, so $d$, $\wedge$ and the curvature $R = d\omega + \tfrac14[\omega, \omega]$ are the same product (E9.4).

The engine's objects do not fit forty lines, so `scripts/schwarzschild_point.py` (35 lines) imports them by path through `checks/selfcheck/gravity/b1lib.py` (which imports `gravity_selfcheck.py`: `Forms`, `Lie`, `Grav`) and holds only the calls, as `c1_birkhoff.py` makes them: the frame as an exact 2-jet (`ks_frame_jet`), $\omega$ by the closed form (`engine_om_R`), the components of $E_a$ (`engine_E_from_R`), and b1lib's Christoffel route on $g = e^{T}\eta e$ (`std_metric`, `std_riemann`, `std_einstein_mixed`). It uses b1lib's own `chk`, `head` and `finish`, so its last line has no count line before it. Its log, `scripts/logs/schwarzschild_point.log`:

```text
1. Schwarzschild in Kerr-Schild form at p = (1, 2, 2), rho = 3, M = 1/2: the engine and the Christoffel route
  ok   [bit] the engine's Einstein form E_a vanishes at p: all 16 components are 0 (exact)
  ok   [bit] the engine's curvature at p has 30 non-zero components, so E_a = 0 is not a match of zeros
  ok   [std] the Christoffel route: the mixed Einstein tensor of g = e^T eta e is 0 at p (16 entries, exact)
  ok   [bit==std] the engine read as G^mu_nu equals the Christoffel route for f = M/rho and for f = M/rho^2 (32 entries, exact)
  ok   [ctl] f = M/rho^2: 16 of the 16 components of E_a are not 0: the vanishing is a property of M/rho

FAILS (SCHW-POINT): none
```

The second line is the habit of E4.2: a vanishing that would also hold for a flat frame proves nothing, so the curvature at $p$ is shown to be non-zero. The comparison `[bit==std]` runs on $M/\rho^2$ as well, where both tensors are non-zero, so it compares numbers and not zeros. Under `--fault RHO2` ($f = M/\rho^2$ in the main lines) two lines fail. The scope is one point; the class is the work of `c1_birkhoff.py` (C1: Birkhoff in the radial Kerr–Schild class, 23 checks in its shipped log).

### E7.5 · The clock: p − q mod 8 gives the type

Statement: the type of Cl(p,q) as a matrix algebra depends on p − q mod 8 only, and the bit rule alone computes it. The rows: the clock c = p − q mod 8 is the phase of a Gauss sum over the labels, LNC-055 (proved by the Atlas); it fixes n and p − q mod 8 and nothing more, LAB-019 (proved by the Atlas); which sign counts as p is a convention, INP-017 (an input). The trick, from `checks/selfcheck/steps15_17/labels_check.py`: two invariants of the rule fix the type, the number $z$ of central blades and the difference $d = N_+ - N_-$ of the blades of square +1 and −1, the signature of the trace form. With $z = 1$ the algebra is $M_d(\mathbb{R})$ for $d > 0$ and $M_{-d/2}(\mathbb{H})$ for $d < 0$; with $z = 2$ it is $M_k(\mathbb{C})$ for $d = 0$, two copies of $M_{d/2}(\mathbb{R})$ for $d > 0$ and of $M_{-d/4}(\mathbb{H})$ for $d < 0$.

`scripts/clock_types.py` (36 lines) computes the invariants for the 45 cells with n ≤ 8 and compares them with the textbook table at p − q mod 8 (Lawson and Michelsohn, "Spin Geometry", recalled) and with the stored type table `engines/stored/labels_v15.json`. Its log, `scripts/logs/clock_types.log`:

```text
1. the type of Cl(p,q) from the bit rule, against the clock p - q mod 8 (45 cells, n <= 8)
  ok   [bit] the type from the centre and the squares takes one value per clock: 0:R 1:R2 2:R 3:C 4:H 5:H2 6:H 7:C
  ok   [std] the stored table is the textbook table at p - q mod 8 for the 45 cells, and N^2 dim(K) copies = 2^n
  ok   [bit==std] the invariant type (kind and matrix size N) equals the stored type and the textbook entry at the clock, 45 of 45 cells
  ok   [ctl] the clock read as p + q mod 8 gives the wrong type on 21 of the 45 cells
  ok   [ctl] the clock read as q - p mod 8 gives the wrong type on 32 of the 45 cells
  ok   [bit] the 45 cells by type: R 13, R2 5, C 10, H 12, H2 5

checks: 6 ok, 0 FAIL
FAILS (CLOCK-TYPES): none
```

The textbook table enters only as a comparison, never as an input, as in `bitcliff.py` (`TYPES`, "used only to COMPARE, never as input"). The control q − p is the mirror convention of INP-017: it gives the wrong type on 32 cells, so the convention is an input the check must state. Under `--fault PLUS` two lines fail.

![The clock: the eight values of p − q mod 8 and the type of Cl(p,q) at each, computed from the number of central blades and the squares of the blades for the 45 cells with n ≤ 8, with the number of cells at each hour. Drawn by figs_code.py with BR of bitrule_A.py.](figs/clock.svg)

> **Try it.** Copy `scripts/maxwell_wave.py`, change the cell to Cl(3,1) (`BR([1, 1, 1, -1])`, time as the minus switch) and keep the vectors as they are: where is the light cone now, and which sign of $\hat k^2$ do you have to write? Then run your copy with `--fault NOSIGN` and read its log with the log reader.

### Questions for a specialist (E7)

- **A field theorist** would ask for the moving Dirac solutions, the rest solution boosted. CAND-126 states the stabilisers of timelike, null and spacelike momenta (proved by the Atlas); the package's plane-wave checks at every momentum are those of the coupling step (ATY-004, proved by the Atlas); the boost of this guide's script is not built: open here.
- **A relativist** would ask for Kerr at a rational point. `c2_kerr.py` checks it (EQN-020, proved by the Atlas, with the horizon generator and its surface gravity); the class of all solutions is GRV-012.
- **A gauge theorist** would ask for the instanton number from the same table. `ym_solutions.py` gets it as an exact rational (CAND-124); the guide's script checks self-duality at one point only.

## E8 · A template

### E8.1 · The skeleton

`scripts/template_check.py` is the shape of a check of the Atlas, filled with one small statement: the cell Cl(1,1) is M₂(ℝ) (MAP-001). It runs on its own (it finds the package's `checks/` folder itself) and prints a log of the same shape as every log above:

```text
1. the cell Cl(1,1) and the real 2 x 2 matrices
  ok   [bit] the 16 products of 1, e1, e2, e12: labels by XOR, 4 signs -1
  ok   [std] numpy: E1^2 = 1, E2^2 = -1, and the four blade matrices have rank 4 (a basis of M2(R))
  ok   [bit==std] the bit-rule table equals the matrix products, all 16: Cl(1,1) = M2(R)
  ok   [ctl] E2 = [[0, 1], [1, 0]] (square +1) does not reproduce the table: the comparison can fail

checks: 4 ok, 0 FAIL
FAILS (TEMPLATE): none
```

Under `--fault SWAP` (the product taken as $e_b e_a$) the `[bit==std]` line fails and the run exits 1. The figure shows the regions of the file and the checklist that goes with them.

![The skeleton of scripts/template_check.py: the header, the docstring, then the five numbered regions (0 the package's rule imported by path, 1 the helpers, 2 the fault option, 3 the parts, 4 the last line) with their line numbers, and the checklist an agent follows before shipping. Drawn by figs_code.py, which reads the regions from the file's own section lines.](figs/template.svg)

### E8.2 · The checklist before shipping

1. **BEFORE first.** Write the statement under test before the script, with the rows it touches and their text as it stands (`node tools/proofs_todo.mjs --row ID`), the sentence you would propose on a pass and the sentence on a fail or on a narrower scope, the controls you plan and, for an engine script, which of the faults M1 to M8 each check should see.
2. **Two routes.** A `[bit]` route on the labels, exact where it can be, with its scope; a `[std]` route that never touches the labels; a `[bit==std]` line that compares them. Where they can differ only by a convention, say which.
3. **Controls.** A `[ctl]` line for every comparison that could pass vacuously (a match of zeros, a flat frame, a symmetric case), and a `--fault` name for every wrong version that should sink the main lines.
4. **The log.** Fixed seeds, no timing inside a check line, the last line `FAILS (STEP): none`, exit code 0; the fault runs exit 1 and their log is kept. A fault that is not seen is reported, with the quantity the script does not read.
5. **The record.** A record in `content/checks.json` with the statement ids and their statements, the independent route, the controls, the log; a run record in `content/check_runs.json` with the counts and the last line read from that log; the rows cite the ids in `evidence` with mode `ran`. The status follows by the rule of E5.3; it is never typed.
6. **The words.** Present tense; "checked at these points, these orders, these n, with these controls"; recalled facts with author and title only; a negative result as a negative result; no history words (the package's scan, `scan_words.mjs`, must print no hits).

A template does not make a check right. It makes a wrong check easy to see: a script that has no `[std]` line, no control or no last line is visibly incomplete.

> **Try it.** Fill the template with the statement "Cl(0,2) is the quaternions": change the cell to `BR([-1, -1])`, the matrices to $E_1 = i\sigma_x$ and $E_2 = i\sigma_y$ as complex 2 × 2 matrices, and the counts to the 6 minus signs of E0. Which line has to change in the `[std]` route, and what is a good control?

### Questions for a specialist (E8)

- **A reviewer** would ask who checks the checker. The package's working rules (in `docs/`) ask a second agent to re-run every added script, read every proposed wording against the assert that backs it and try to break the controls; no row states it: open as a row.
- **A tooling engineer** would ask for a linter of the shape (header, docstring order, a `[std]` line, a control, `finish`). The guide's checklist is that linter in words; no tool of the package enforces it: open.
- **A logician** would ask when a finite check becomes a proof. Only with a derivation valid for all n, attached and said to be one, as T1 is for associativity (MAP-001).

## E9 · The key equations as tricks

Each key equation of the four engines becomes computable on labels by one trick. The physics tutorial of the Atlas ("Physics on the bit rule: the four engines") takes each in its own part (Maxwell; Dirac; Yang–Mills; Gravity I and II; the clock in "The rule and the frame"); here is the trick, in the words a script needs.

### E9.1 · Maxwell: a vector times a bivector splits by grade

The product of a vector and a bivector has a vector part and a trivector part and nothing else. So $\nabla F = J$ is one equation that splits into two by grade: the vector part holds Gauss's law and the Ampère–Maxwell law, the trivector part the absence of magnetic charge and Faraday's law (recalled: Hestenes, "Space-Time Algebra"). In code: multiply, then sort the labels of the result by `popcount`.

![The 24 products e_μ · e_B of the four vectors and the six bivectors of Cl(1,3) (e₀ is time, the labels counted from 0), with their signs and labels: 12 of grade 1 (blue) and 12 of grade 3. Drawn by figs_code.py with BR of bitrule_A.py and the squares (+1, −1, −1, −1).](figs/grade_split.svg)

### E9.2 · Dirac: the complex unit is a bivector of the frame

The $i$ of the printed Dirac equation is not an element of the algebra; on plane waves it is the Fourier $i$ of $\partial \to ip$ (LNS-003b, LNS-119, both proved by the Atlas). In the real algebra its place is taken by $J = \gamma_2\gamma_1$, which squares to −1 and commutes with $\gamma_0$; which element plays the complex unit is a choice of complex structure (INP-067, an input). In code: $J$ is the label 0110 with sign −1, and every "$i$" of the textbook becomes a right multiplication by $J$.

### E9.3 · Yang–Mills: a Lie table of bivectors

The commutator of two bivector labels is 0 when they share no switch or two, and $\pm 2$ times the label $a \oplus b$ when they share exactly one. That table is the structure constants of the gauge algebra (EQN-007, proved by the Atlas), and its closed triangles are so(3) (YM-001). In code: `comm(alg, {a: 1}, {b: 1})` from `bitrule_A.py`, once per pair, gives $f_{ab}{}^c$; the field strength and the covariant derivative are then sums over that table.

### E9.4 · The Einstein form: forms are the rule with null generators

Give every generator the square 0 and the product of the labels is the wedge product of forms, with the sign of the permutation, which is the Levi-Civita symbol (the docstring of `gravity_selfcheck.py`). So $d$, $\wedge$, the curvature $R^C = d\omega^C + \tfrac14 f_{AB}{}^C\omega^A\wedge\omega^B$ and the Einstein form $E_a = \sum_{b<c}\varepsilon_{abc\ldots}F^{bc}\wedge e\wedge\cdots\wedge e$ are one product used twice: once with the squares of the frame (the Lie tables), once with null squares (the forms). E_a equals the Einstein tensor for any frame (GRV-010, proved by the Atlas).

### E9.5 · The clock: p − q mod 8

The type of a cell is read off two counts of the rule, the central blades and the squares, and depends on p − q mod 8 only (E7.5; LNC-055, LAB-019). In code: `(p - q) % 8`, never `(p + q) % 8`, with the convention of which sign is p stated as an input (INP-017).

### Questions for a specialist (E9)

- **A physicist** would ask whether the split by grade survives a medium. The constitutive relation is an input there (INP-002: in vacuum H = ⋆F, in a medium a map with 36 components); the split of ∇F is the same.
- **A geometer** would ask why null squares give forms and not some other algebra. With every square 0 the rule is the exterior algebra (Part 0 of the shipped tutorial; MAP-001 for every choice of squares), and the sign of the permutation is all that is left.
- **A topologist** would ask what the clock is as an invariant. LAB-018 reads it as the Brown (Arf–Brown–Kervaire) invariant of a ℤ₄ enhancement of the dot product (proved by the Atlas).

## E10 · Try next, and where the Atlas shows these objects

### E10.1 · Try next

- Rebuild the counts of E0 with `bmul`: for the squares [1, 1], [−1, −1] and [0, 0], count the 16 ordered pairs (a, b) of labels 0 to 3 whose product vanishes, and those whose sign is −1. E0 gives 0, 0, 7 and 4, 6, 1.
- Check that $e_a^2 = (-1)^{k(k-1)/2}$ times the product of the squares of the $k$ switches that are on in $a$, for every label of every signature with up to four generators; write it as a check with a `[bit]` line (the rule), a `[std]` line (the formula), a `[bit==std]` line and a control (the exponent $k(k+1)/2$), and give it a `--fault`.
- Turn `scripts/clock_types.py` into a check of the even subalgebra: the type of Cl⁰(p,q) against the type of Cl(q, p − 1) for p ≥ 1 (CAND-069, proved by the Atlas, states Cl⁺(1, n − 1) ≅ Cl(n − 1, 0) and the algebras it gives for n = 4 to 8).
- Add a `--fault` to `scripts/dirac_rest.py` that the `[bit==std]` line does see, and say in one sentence why LEFTJ does not.
- Run `scripts/test_widgets.mjs` with `--show-off` and explain one of the run records that the log reader does not match.

### E10.2 · Where the Atlas shows these objects

The rule: the page The rule (`#/rule`). The cells and the clock: `#/cells` and `#/clock`. Light and the Maxwell step: `#/light` and `#/steps/comm`. The Dirac step and the coupling step: `#/steps/dirac`, `#/steps/coupling`. Yang–Mills: `#/steps/ym`. Gravity: `#/steps/grav1`, `#/steps/grav2`. The spring of E3: `#/steps/spring`. The statements and their checks: the logbook (`#/logbook`), where every row ends with its record, and For researchers › Run the checks and › Theorems. The export for agents: `#/agents`. The scripts: `checks/` of the package, with the README of each folder.

## Closing table · one object, three names

The objects of this guide in three columns: the name a course on programming gives them, the Atlas's name, and the row with its status (the status as the build computes it).

| The course's name | The Atlas's name | Row and status |
|---|---|---|
| a bit pattern, an integer mask | a label, the blade $e_a$ | MAP-001 (proved by the Atlas) |
| a multiplication table | the bit rule: XOR and a sign | MAP-001 (proved by the Atlas); T1 |
| a 2-cocycle, a twisted group algebra | the sign $s(a,b)$ | T1; CAND-092 (proved by the Atlas) |
| a change of basis that keeps the laws | a gauge transform of the sign | CAND-103 (proved by the Atlas) |
| a monoid with zero | the labels with null bits | LNC-086 (open) |
| an exact power series | the oscillator $s' = \omega B s$ | EQN-018 (proved by the Atlas) |
| a standard result, checked | circle, hyperbola, line from $B^2$ | SPR-002 (proved by the Atlas) |
| a kernel of a linear map | a plane wave of $\nabla F = 0$ | EQN-006 (proved by the Atlas) |
| a duality operator | the star as the complement map | LNS-011b (proved by the Atlas) |
| an eigen-solution | the rest solution of Dirac–Hestenes | CAND-126 (proved by the Atlas) |
| a structure-constant table | the Lie table of bivectors | YM-001 (proved by the Atlas) |
| a known closed form | the BPST field | CAND-124 (proved by the Atlas) |
| an evaluation at a point | the Einstein form at a rational point | GRV-012 (proved by the Atlas) |
| a borrowed input | the Schwarzschild metric | INP-054 (an input) |
| a lookup table indexed mod 8 | the clock p − q mod 8 | LNC-055 (proved by the Atlas) |
| a convention | which sign is p | INP-017 (an input) |
| a test that must fail | a control `[ctl]`, a `--fault` | (the discipline, E4) |
| a computed field of a record | the status word | (tools/build_content.mjs, E5.3) |

## Sources, and how far each was read

The rows of the Atlas, read in full (their research text, status, evidence and dependencies, by `node tools/proofs_todo.mjs --row ID` or in `content/rows.json`, `content/texts.json` and `content/derived/status.json`): MAP-001, CAND-092, CAND-094, CAND-103, LNC-086, EQN-006, EQN-007, EQN-008, EQN-018, SPR-002, LNS-011b, LNS-102, LNS-003b, LNS-119, CAND-126, YM-001, CAND-124, GRV-010, GRV-012, INP-054, INP-002, INP-017, INP-049, INP-067, LNC-055, LAB-018, LAB-019, CAND-069, EQN-020, CPL-011, ATY-004, LNB-005b; the theorem T1 in `content/theorems.json`.

The checks and logs, read in full: `engines/bitrule.js`, `checks/researchers_checks/bitrule_A.py`, `checks/selfcheck/steps15_17/bitcliff.py` and the head of `labels_check.py`, `tests/kernel.test.mjs` with its fixture, `engines/stored/labels_v15.json`, `checks/selfcheck/spring_selfcheck.py` (bmul, MV and the row A1, run), `checks/selfcheck/gravity/b1lib.py` (the helpers and the engine helpers), the README of `checks/selfcheck/gravity/` (the run rules, the line kinds, the engine faults), the 42 full mutation logs of `checks/selfcheck/gravity/mut/`, the head of `c1_birkhoff.py` and its log, the head of `ym_solutions.py`, `checks/selfcheck/proofs/shifted_dirac.py` (docstring, helpers, fault parser, the last part) with `logs/shifted_dirac.log` and `logs/shifted_dirac.faults.log`, the head of `gravity_selfcheck.py` (Forms, Lie, Grav); this guide's own scripts and logs in `scripts/`.

The records: `content/checks.json` (344 records; the record of `shifted_dirac.py` in full), `content/check_runs.json` (601 records; the run of `shifted_dirac.py` in full), `tools/build_content.mjs` (the status rule, read in full), `tools/proofs_todo.mjs` (its header), `package.json` (the scripts), `build.sh` and `tools/release.sh` (their headers), `content/tuning/README.md` and the tuning guide `AI_TUNING.md` of the docs.

The shipped tutorial "The bit rule and four college courses", Part 0 and Part E (E1 to E4, Try next, Where the Atlas shows these objects), read in full: E1 to E3 are kept (the blocks copied word for word from `spring_selfcheck.py`, the transcripts), E4 is rewritten as E4 to E6 here.

Recalled, not in the package: Lawson and Michelsohn, "Spin Geometry" (the table of types at p − q mod 8); Belavin, Polyakov, Schwarz and Tyupkin, "Pseudoparticle solutions of the Yang–Mills equations" (the closed form of the BPST field); the Schwartz–Zippel lemma (as recalled in `gravity_selfcheck.py`); the remainder of the exponential series.
