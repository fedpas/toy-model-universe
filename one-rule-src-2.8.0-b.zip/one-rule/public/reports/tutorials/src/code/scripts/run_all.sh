#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# run_all.sh -- runs the scripts of this folder one at a time, under the limits the package uses for its own (ulimit -v 3000000, nice -n 10,
# timeout 900, python3 -I -B), and writes logs/<name>.log (the plain run, which must exit 0), logs/<name>.fault.log (the run with the script's
# --fault option, which must exit 1) and logs/SUMMARY.txt (one line per run: exit code, ok and FAIL lines, the last line).
#   ATLAS_CHECKS=<the package's checks folder> sh run_all.sh      (the variable is not needed when this folder sits inside the package)
cd "$(dirname "$0")" || exit 1
mkdir -p logs
: > logs/SUMMARY.txt
run() {   # run <name> <log> [args]
  name=$1; log=$2; shift 2
  ( ulimit -v 3000000; timeout 900 nice -n 10 python3 -I -B "$name.py" "$@" ) > "logs/$log" 2>&1
  rc=$?
  printf '%-22s %-26s exit %d  ok %3d  FAIL %3d  %s\n' "$name" "$log" "$rc" "$(grep -c '^  ok ' "logs/$log")" "$(grep -c '^  FAIL ' "logs/$log")" "$(tail -1 "logs/$log" | cut -c1-60)" >> logs/SUMMARY.txt
}
for pair in template_check:SWAP maxwell_wave:NOSIGN dirac_rest:LEFTJ ym_bpst:ABELIAN schwarzschild_point:RHO2 clock_types:PLUS; do
  name=${pair%%:*}; fault=${pair#*:}
  run "$name" "$name.log"
  run "$name" "$name.fault.log" --fault "$fault"
done
cat logs/SUMMARY.txt
