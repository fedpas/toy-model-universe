#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""tutlib.py -- the shared part of the tutorial's scripts, as b1lib.py is for the gravity scripts of the package.
It finds the package's checks/ folder (the variable ATLAS_CHECKS, else the first checks/ above this file), imports the bit rule of
checks/researchers_checks/bitrule_A.py from it (imported, never copied), and gives the log helpers chk, head, finish and the --fault option.
A check line reads   ok   [tag] statement   or   FAIL [tag] statement;  the last line of a run is  FAILS (STEP): none  when every line passed."""
import os, sys
sys.dont_write_bytecode = True

def find_checks():
    d = os.environ.get('ATLAS_CHECKS')
    if d and os.path.isfile(os.path.join(d, 'researchers_checks', 'bitrule_A.py')): return os.path.abspath(d)
    d = os.path.dirname(os.path.abspath(__file__))
    while True:
        c = os.path.join(d, 'checks')
        if os.path.isfile(os.path.join(c, 'researchers_checks', 'bitrule_A.py')): return c
        if os.path.dirname(d) == d: raise SystemExit('the checks/ folder of the package is not found: set ATLAS_CHECKS to it')
        d = os.path.dirname(d)

CHECKS = find_checks()
if os.path.join(CHECKS, 'researchers_checks') not in sys.path: sys.path.insert(0, os.path.join(CHECKS, 'researchers_checks'))
from bitrule_A import BR, popcount, N_pairs, rank_fr, comm, anticomm      # the package's own bit rule

FAILS, COUNT = [], [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[0 if cond else 1] += 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(step):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (step, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
def fault_option(names):
    """the name after --fault (one of names) or None; a fault puts a wrong version into the main lines, and the run must then end with FAILS"""
    if '--fault' not in sys.argv: return None
    i = sys.argv.index('--fault'); f = sys.argv[i + 1] if i + 1 < len(sys.argv) else ''
    if f not in names: raise SystemExit('unknown fault %r; one of %s' % (f, ', '.join(names)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % f)
    return f
