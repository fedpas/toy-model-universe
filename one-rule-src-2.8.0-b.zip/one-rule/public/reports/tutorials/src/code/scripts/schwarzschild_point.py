#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""schwarzschild_point.py -- the Einstein form of the package's gravity engine vanishes on the Kerr-Schild frame of Schwarzschild, f = M/rho, at the
rational point p = (1, 2, 2), rho = 3, M = 1/2, c = 0.  The engine (Forms, Lie, Grav of gravity_selfcheck.py) and its helpers are imported by path
through checks/selfcheck/gravity/b1lib.py; this file holds only the calls.
[bit] the frame e^a = dx^a - f l^a l as an exact 2-jet at p, omega by the closed form (A3), R = d omega + 1/4 [omega, omega], the Einstein form E_a.
[std] b1lib's Christoffel route on g = e^T eta e: Riemann, the mixed Einstein tensor G^mu_nu, exact, never the engine.
[ctl] f = M/rho^2 is not a solution.  Run: python3 schwarzschild_point.py [--fault RHO2]  (RHO2: f = M/rho^2 in the main lines)"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import tutlib; sys.path.insert(0, os.path.join(tutlib.CHECKS, 'selfcheck', 'gravity'))
from b1lib import *                       # the package's helpers: chk, head, finish, F, Lie, Grav, koszul_S, ks_frame_jet, engine_om_R, std_riemann, ...
FAULT = tutlib.fault_option(['RHO2'])
SQ = LORENTZ(4); Lie_ = Lie(SQ); Gv = Grav(4, Lie_); S = koszul_S(4, SQ, Lie_)        # as c1_birkhoff.py builds them
p, rho0, M = (F(1), F(2), F(2)), F(3), F(1, 2)
jets = lambda k: (M / rho0 ** k, -k * M / rho0 ** (k + 1), k * (k + 1) * M / rho0 ** (k + 2))       # the 2-jet of f = M / rho^k at rho0
def engine(k):                                                     # [bit] E_a and R at p, then E_a read as the coordinate tensor (as engine_M of c1_birkhoff.py)
    e = ks_frame_jet(p, rho0, *jets(k))[0]; e0, E0, det = E0_of(e, 4, 4)
    om, R = engine_om_R(Gv, e, S, 4); comp = engine_E_from_R(Gv, e, R, 4, 0); Mfr = mixed_from_components(comp, e0, det, 4, s=-1)
    return comp, R, [[sum(E0[m][b] * Mfr[b][a] * e0[a][n] for b in range(4) for a in range(4)) for n in range(4)] for m in range(4)]
def std(k):                                                        # [std] the Christoffel route on the same jet
    e = ks_frame_jet(p, rho0, *jets(k))[0]; g = std_metric(e, 4, SQ, 4, 2); R1, g0, g0i = std_riemann(g, 4, 4, 1)
    return std_einstein_mixed(R1, g0, g0i, 4)[0]
k = 2 if FAULT else 1
head('1. Schwarzschild in Kerr-Schild form at p = (1, 2, 2), rho = 3, M = 1/2: the engine and the Christoffel route')
comp, R, Mco = engine(k); G = std(k)
chk('bit', all(v == 0 for v in comp.values()), "the engine's Einstein form E_a vanishes at p: all 16 components are 0 (exact)")
nz = sum(1 for A in range(6) for m in R[A] if at0(R[A][m], 4) != 0)
chk('bit', nz > 0, "the engine's curvature at p has %d non-zero components, so E_a = 0 is not a match of zeros" % nz)
chk('std', all(v == 0 for row in G for v in row), 'the Christoffel route: the mixed Einstein tensor of g = e^T eta e is 0 at p (16 entries, exact)')
comp2, _, Mco2 = engine(2); G2 = std(2)
chk('bit==std', Mco == G and Mco2 == G2, 'the engine read as G^mu_nu equals the Christoffel route for f = M/rho and for f = M/rho^2 (32 entries, exact)')
chk('ctl', sum(v != 0 for v in comp2.values()) > 0, 'f = M/rho^2: %d of the 16 components of E_a are not 0: the vanishing is a property of M/rho' % sum(v != 0 for v in comp2.values()))
finish('SCHW-POINT')
