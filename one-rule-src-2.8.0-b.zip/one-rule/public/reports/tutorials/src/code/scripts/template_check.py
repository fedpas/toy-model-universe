#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""template_check.py -- the shape of a check of the Atlas, filled with one small statement: the cell Cl(1,1) is the algebra M2(R) of real 2 x 2 matrices.
[bit] the product table of the four blades 1, e1, e2, e12 of Cl(1,1) by the package's bit rule (researchers_checks/bitrule_A.py), exact integers.
[std] numpy, never the labels: the matrices E1 = diag(1, -1), E2 = [[0, 1], [-1, 0]]; their 16 products, and the rank of the four blade matrices.
[ctl] E2 = [[0, 1], [1, 0]] (square +1, a matrix of Cl(2,0)) does not represent Cl(1,1): the comparison must fail for it.
Scope. One cell, n = 2, all 16 products; nothing beyond n = 2.
Run:   python3 template_check.py [--fault SWAP]     (SWAP: the product taken as e_b e_a, a wrong version in the main lines; the run must end with FAILS)
       from any folder, also under python3 -I -B; set ATLAS_CHECKS to the package's checks/ folder when this file is not inside the package."""
# ---------------------------------------------------------------------------------------------- 0. the package's rule, imported by path (never a copy)
import os, sys
sys.dont_write_bytecode = True
import numpy as np
def find_checks():
    d = os.environ.get('ATLAS_CHECKS')
    if d and os.path.isfile(os.path.join(d, 'researchers_checks', 'bitrule_A.py')): return d
    d = os.path.dirname(os.path.abspath(__file__))
    while os.path.dirname(d) != d:
        if os.path.isfile(os.path.join(d, 'checks', 'researchers_checks', 'bitrule_A.py')): return os.path.join(d, 'checks')
        d = os.path.dirname(d)
    raise SystemExit('the checks/ folder of the package is not found: set ATLAS_CHECKS to it')
sys.path.insert(0, os.path.join(find_checks(), 'researchers_checks'))
from bitrule_A import BR

# ---------------------------------------------------------------------------------------------- 1. the helpers: one line per check, a last line that sums up
FAILS, COUNT = [], [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[0 if cond else 1] += 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(step):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (step, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

# ---------------------------------------------------------------------------------------------- 2. the fault option: each wrong version has a name
STEP, FAULT_NAMES, FAULT = 'TEMPLATE', ['SWAP'], None
if '--fault' in sys.argv:
    i = sys.argv.index('--fault'); FAULT = sys.argv[i + 1] if i + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)

# ---------------------------------------------------------------------------------------------- 3. the parts
head('1. the cell Cl(1,1) and the real 2 x 2 matrices')
A = BR([1, -1])                                                   # [bit] e1^2 = +1, e2^2 = -1
def prod(a, b):                                                   # e_a e_b = s e_(a xor b) as (sign, label)
    return (A.s(b, a), a ^ b) if FAULT == 'SWAP' else (A.s(a, b), a ^ b)
TABLE = {(a, b): prod(a, b) for a in range(4) for b in range(4)}
chk('bit', sum(s == -1 for s, _ in TABLE.values()) == 4 and all(m == a ^ b for (a, b), (_, m) in TABLE.items()),
    'the 16 products of 1, e1, e2, e12: labels by XOR, %d signs -1' % sum(s == -1 for s, _ in TABLE.values()))
def blades(E1, E2): return [np.eye(2), E1, E2, E1 @ E2]          # [std] the blade of label a as a matrix: the product in increasing order
def represents(E1, E2):
    M = blades(E1, E2)
    return all(np.array_equal(M[a] @ M[b], s * M[m]) for (a, b), (s, m) in TABLE.items())
E1, E2 = np.diag([1, -1]), np.array([[0, 1], [-1, 0]])
rank = np.linalg.matrix_rank(np.array([X.ravel() for X in blades(E1, E2)]))
chk('std', np.array_equal(E1 @ E1, np.eye(2)) and np.array_equal(E2 @ E2, -np.eye(2)) and rank == 4, 'numpy: E1^2 = 1, E2^2 = -1, and the four blade matrices have rank %d (a basis of M2(R))' % rank)
chk('bit==std', represents(E1, E2), 'the bit-rule table equals the matrix products, all 16: Cl(1,1) = M2(R)')
chk('ctl', not represents(E1, np.array([[0, 1], [1, 0]])), 'E2 = [[0, 1], [1, 0]] (square +1) does not reproduce the table: the comparison can fail')

# ---------------------------------------------------------------------------------------------- 4. the last line
finish(STEP)
