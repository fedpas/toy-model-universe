#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""clock_types.py -- the clock p - q mod 8 names the type of Cl(p,q).  The type is computed from the bit rule alone (the centre and the squares of the
blades) and compared with the textbook table at p - q mod 8 and with the stored type table engines/stored/labels_v15.json, 45 cells, n = p + q <= 8.
[bit] z = the number of central blades, d = N+ - N- (blades of square +1 minus those of square -1, the signature of the trace form):
      z = 1: M_d(R) for d > 0, M_(-d/2)(H) for d < 0;  z = 2: M_k(C) for d = 0, two copies of M_(d/2)(R) for d > 0, two of M_(-d/4)(H) for d < 0.
[std] the table R, R+R, R, C, H, H+H, H, C at p - q mod 8 (recalled: Lawson and Michelsohn, Spin Geometry) and the stored table.
[ctl] the wrong clocks p + q and q - p mod 8.  Run: python3 clock_types.py [--fault PLUS]  (PLUS: the clock read as p + q mod 8 in the main lines)"""
import os, sys, json; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tutlib import *
FAULT = fault_option(['PLUS'])
TEXTBOOK = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']                  # used only to compare, never as an input
stored = json.load(open(os.path.join(CHECKS, '..', 'engines', 'stored', 'labels_v15.json'), encoding='utf-8'))['cells']
def invariant_type(p, q):
    A = BR([1] * p + [-1] * q); n = p + q; D = 1 << n
    z = sum(all(A.s(a, 1 << i) == A.s(1 << i, a) for i in range(n)) for a in range(D))
    d = sum(A.sq(a) for a in range(D))
    if z == 1: return ('R', d) if d > 0 else ('H', -d // 2)
    return ('C', round((D // 2) ** 0.5)) if d == 0 else ('R2', d // 2) if d > 0 else ('H2', -d // 4)
cells = [(n - q, q) for n in range(9) for q in range(n + 1)]
clock = lambda p, q: (p + q if FAULT else p - q) % 8
head('1. the type of Cl(p,q) from the bit rule, against the clock p - q mod 8 (45 cells, n <= 8)')
inv = {c: invariant_type(*c) for c in cells}; st = {c: (stored['%d,%d' % c]['kind'], stored['%d,%d' % c]['N']) for c in cells}
by_clock = {k: {inv[c][0] for c in cells if clock(*c) == k} for k in range(8)}
chk('bit', all(len(v) == 1 for v in by_clock.values()), 'the type from the centre and the squares takes one value per clock: %s' % ' '.join('%d:%s' % (k, ''.join(v)) for k, v in by_clock.items()))
dims = all(2 ** (p + q) == st[(p, q)][1] ** 2 * {'R': 1, 'C': 2, 'H': 4}[st[(p, q)][0][0]] * (2 if st[(p, q)][0].endswith('2') else 1) for p, q in cells)
chk('std', dims and all(st[c][0] == TEXTBOOK[(c[0] - c[1]) % 8] for c in cells), 'the stored table is the textbook table at p - q mod 8 for the 45 cells, and N^2 dim(K) copies = 2^n')
chk('bit==std', all(inv[c] == st[c] and inv[c][0] == TEXTBOOK[clock(*c)] for c in cells), 'the invariant type (kind and matrix size N) equals the stored type and the textbook entry at the clock, 45 of 45 cells')
for name, wrong in (('p + q', lambda p, q: (p + q) % 8), ('q - p', lambda p, q: (q - p) % 8)):
    bad = sum(inv[c][0] != TEXTBOOK[wrong(*c)] for c in cells)
    chk('ctl', bad > 0, 'the clock read as %s mod 8 gives the wrong type on %d of the 45 cells' % (name, bad))
counts = {k: sum(inv[c][0] == k for c in cells) for k in ('R', 'R2', 'C', 'H', 'H2')}
chk('bit', sum(counts.values()) == 45, 'the 45 cells by type: %s' % ', '.join('%s %d' % kv for kv in counts.items()))
finish('CLOCK-TYPES')
