#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""ym_bpst.py -- the closed triangles of the commutator graph of Cl(0,4) are so(3); the BPST field A^a_m = 2 eta^a_mn x^n / (x^2 + rho^2) on the
so(3) of Cl(0,3) is self-dual at x = (1, 2, -1, 3), rho^2 = 2.  [bit] the Lie table [B_a, B_b] = f_ab^c B_c by the bit rule; F^c = dA^c + (1/2)
f_ab^c A^a A^b exactly; the star as the complement map.  [std] numpy: ad(B) antisymmetric of rank 3; the closed form -4 eta rho^2/(x^2 + rho^2)^2
(recalled) with eta self-dual by the Levi-Civita symbol.  [ctl] the anti-instanton.  Run: python3 ym_bpst.py [--fault ABELIAN] (bracket dropped)"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tutlib import *
from fractions import Fraction as Fr; from itertools import combinations as cmb, permutations as perm; from functools import reduce; import numpy as np
FAULT = fault_option(['ABELIAN'])
def table(alg, B): return {(a, b): next(iter(c.items())) for a, b in perm(range(len(B)), 2) if (c := comm(alg, {B[a]: 1}, {B[b]: 1}))}
B4 = [m for m in range(16) if popcount(m) == 2]; f4 = table(BR([-1] * 4), B4)                       # the six bivectors of Cl(0,4)
tri = [t for t in cmb(range(6), 3) if all(p in f4 for p in cmb(t, 2))]; closed = [t for t in tri if all(B4.index(f4[p][0]) in t for p in cmb(t, 2))]
def ad(t): return [np.array([[f4[(a, b)][1] if (a, b) in f4 and f4[(a, b)][0] == B4[i] else 0 for b in t] for i in t]) for a in t]
B3 = [3, 5, 6]; f3 = {k: (B3.index(m), v) for k, (m, v) in table(BR([-1] * 3), B3).items()}; x, r2 = [Fr(1), Fr(2), Fr(-1), Fr(3)], Fr(2)
def psign(seq): return next(iter(reduce(BR([0] * 4).mul, [{1 << i: 1} for i in seq]).values()))   # a permutation's sign: e_i e_j ... with null squares
def eta(bar):                                                           # the 't Hooft symbols eta^a_mn (slot 3 = x^4)
    e = [[[psign((a, i, j)) if len({a, i, j}) == 3 and 3 not in (i, j) else 0 for j in range(4)] for i in range(4)] for a in range(3)]
    for a in range(3): e[a][a][3], e[a][3][a] = (-1, 1) if bar else (1, -1)
    return e
def field(bar):                                                         # F^c_mn on the six 2-form labels, exact at x
    E, Q = eta(bar), sum(v * v for v in x) + r2; A = [[2 * sum(E[a][m][n] * x[n] for n in range(4)) / Q for m in range(4)] for a in range(3)]
    dA = lambda a, l, m: 2 * E[a][m][l] / Q - A[a][m] * 2 * x[l] / Q    # d_l A^a_m
    br = lambda c, m, n: 0 if FAULT else sum(Fr(v, 2) * A[a][m] * A[b][n] for (a, b), (cc, v) in f3.items() if cc == c)
    return {(c, m, n): dA(c, m, n) - dA(c, n, m) + br(c, m, n) for c in range(3) for m, n in cmb(range(4), 2)}
cpl = lambda m, n: tuple(i for i in range(4) if i not in (m, n))       # the complement of the label {m, n}
dual = lambda F, s: all(F[(c,) + cpl(m, n)] == s * psign((m, n) + cpl(m, n)) * F[(c, m, n)] for c, m, n in F)
head('1. the commutator graph of the bivectors of Cl(0,4), and the BPST field at one rational point')
chk('bit', (len(closed), len(tri) - len(closed)) == (4, 4), '%d triangles: %d closed {e_ab, e_bc, e_ac}, %d open {e_ab, e_ac, e_ad}' % (len(tri), len(closed), len(tri) - len(closed)))
chk('std', all(np.array_equal(M, -M.T) for t in closed for M in ad(t)) and all(np.linalg.matrix_rank(np.array([M.ravel() for M in ad(t)])) == 3 for t in closed), 'numpy: on each closed triangle ad(B) is antisymmetric of rank 3, an isomorphism onto so(3)')
F, Q = field(False), sum(v * v for v in x) + r2
chk('bit', dual(F, 1), 'BPST at x = (1,2,-1,3), rho^2 = 2: F^a = *F^a on the six 2-form labels, the star read as the complement map with its sign')
eps, eta_n = np.zeros((4,) * 4), np.array(eta(False), float); [eps.__setitem__(p, (-1) ** sum(p[i] > p[j] for i, j in cmb(range(4), 2))) for p in perm(range(4))]
chk('std', np.abs(0.5 * np.einsum('mnrs,ars->amn', eps, eta_n) - eta_n).max() == 0, 'numpy: eta^a_mn = (1/2) eps_mnrs eta^a_rs (Levi-Civita by the parity of inversions), so F = -4 eta rho^2/Q^2 is self-dual')
dev = max(abs(float(F[(c, m, n)]) + 4 * 2 / float(Q) ** 2 * eta_n[c, m, n]) for c, m, n in F)
chk('bit==std', dev == 0, 'the exact components equal the closed form -4 eta rho^2/Q^2, Q = %s, 18 components (max deviation %.1e)' % (Q, dev))
chk('ctl', dual(field(True), -1) and not dual(field(True), 1), 'the anti-instanton (eta-bar): F = -*F, so the self-duality line fails for it')
finish('YM-BPST')
