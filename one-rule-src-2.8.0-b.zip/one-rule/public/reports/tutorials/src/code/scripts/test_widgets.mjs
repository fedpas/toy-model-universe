// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_widgets.mjs -- the three widgets of the tutorial against the package itself:
//   product    its sign against the fixture of tests/kernel.test.mjs (the Python reference, every pair of labels of 121 cells) and its ten stored
//              products against engines/bitrule.js;
//   logreader  its counts and last line against the run records of content/check_runs.json whose log is shipped;
//   status     its rule against content/derived/status.json (written by tools/build_content.mjs) for every row of content/rows.json.
// Run: ATLAS_CHECKS=<the package's checks folder> node test_widgets.mjs [--cases]   (--cases prints ten rows for the status widget's self-test)
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath, pathToFileURL } from 'node:url';
const HERE = path.dirname(fileURLToPath(import.meta.url));
function findChecks() {
  const e = process.env.ATLAS_CHECKS; if (e && fs.existsSync(path.join(e, 'researchers_checks', 'bitrule_A.py'))) return path.resolve(e);
  for (let d = HERE; path.dirname(d) !== d; d = path.dirname(d)) if (fs.existsSync(path.join(d, 'checks', 'researchers_checks', 'bitrule_A.py'))) return path.join(d, 'checks');
  console.error('the checks/ folder of the package is not found: set ATLAS_CHECKS'); process.exit(2);
}
const ROOT = path.dirname(findChecks()), J = p => JSON.parse(fs.readFileSync(path.join(ROOT, p), 'utf8'));
const widget = n => (0, eval)(fs.readFileSync(path.join(HERE, '..', 'widgets', n + '.js'), 'utf8'))('test');
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } else console.log('ok  ', m); };

// ---- product
const P = widget('product'), K = await import(pathToFileURL(path.join(ROOT, 'engines', 'bitrule.js')).href), FX = J('tests/fixtures/bitrule_reference.json');
let pairs = 0, same = 0;
for (const c of FX.cells) { const N = 1 << c.eps.length; for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) { pairs++; if (P.sign(a, b, c.eps) === c.S[a][b]) same++; } }
ok(P.selfTest && same === pairs, `product: self-test holds; the widget's sign equals the Python reference on ${same} of ${pairs} pairs (${FX.cells.length} cells)`);
ok(P.STORED.every(([e, a, b, s, m]) => K.sign(a, b, e) === s && (a ^ b) === m), 'product: the ten stored products equal engines/bitrule.js');

// ---- log reader
const L = widget('logreader'), runs = J('content/check_runs.json');
let tried = 0, agree = 0; const off = [];
for (const r of runs) {
  const f = r.source && path.join(ROOT, r.source); if (!f || !f.endsWith('.log') || !fs.existsSync(f)) continue;
  const p = L.parse(fs.readFileSync(f, 'utf8')); tried++;
  if (p.ok === Number(r.ok) && p.fail === Number(r.fail) && p.last === String(r.lastLine).trim()) agree++; else off.push(`${r.source}: widget ${p.ok}/${p.fail} "${p.last.slice(0, 40)}", record ${r.ok}/${r.fail} "${String(r.lastLine).slice(0, 40)}"`);
}
ok(L.selfTest && tried > 0, `logreader: self-test holds; ${agree} of ${tried} run records with a shipped log agree with the widget on ok, FAIL and the last line`);
if (process.argv.includes('--show-off')) off.slice(0, 40).forEach(x => console.log('   differs:', x));

// ---- status: the inputs of every row as build_content.mjs reads them
const S = widget('status'), rows = J('content/rows.json'), derived = J('content/derived/status.json');
const lastRun = {}; for (const r of runs) if (r.script) { const k = r.script; if (!lastRun[k] || r.date >= lastRun[k].date) lastRun[k] = r; }
const runOf = s => { const k = s && (s.startsWith('checks/') ? s : 'checks/' + s.replace(/^(selfcheck|researchers_checks)/, '$1')); return lastRun[k] || Object.values(lastRun).find(x => x.script.endsWith('/' + path.basename(s || ''))) || null; };
const runPassed = s => { const r = runOf(s); return !!r && r.passed !== false && !(Number(r.fail) > 0); };
const SQ = n => n.startsWith('i-') ? 0 : (n.startsWith('s-') || n === 'src') ? -1 : 1;
const input = r => { const no = r.notions || [];
  return { id: r.id, kind: r.kind, ptype: r.ptype, group: r.group, legacyLabel: r.legacyLabel || null, onlyMeta: no.length === 1 && no[0] === 'i-meta', flags: r.legacyFlags || [],
    ev: (r.evidence || []).map(e => ({ mode: e.mode, passed: e.mode === 'ran' ? runPassed(e.script || e.check) : false })),
    q: no.filter(n => SQ(n) === -1).length, rr: no.filter(n => SQ(n) === 0).length,
    stdRead: typeof r.standardRef === 'string' && r.standardRef.trim() !== '' && !/\bunread\b|\bnot read\b|\bpointer\b/i.test(r.standardRef) }; };
let rowSame = 0; const diff = [];
for (const r of rows) { const s = S.status(input(r))[0]; if (s === derived[r.id].status) rowSame++; else diff.push(`${r.id}: widget ${s}, build ${derived[r.id].status}`); }
ok(S.selfTest && rowSame === rows.length, `status: self-test holds; the widget's rule gives the built status of ${rowSame} of ${rows.length} rows${diff.length ? ' (' + diff.slice(0, 5).join('; ') + ')' : ''}`);
const okStored = S.CASES.every(([r, s]) => { const row = rows.find(x => x.id === r.id); return row && JSON.stringify(input(row)) === JSON.stringify(r) && derived[r.id].status === s; });
ok(okStored, 'status: the ten stored cases are rows of content/rows.json as the rule reads them, with their built status');
if (process.argv.includes('--cases')) {
  const pick = [], seen = new Set();                                  // the first row for each rule of the chain that fires, up to ten
  for (const r of rows) { const i = input(r), [st, why] = S.status(i); if (pick.length < 10 && !seen.has(why) && i.ev.length <= 3) { seen.add(why); pick.push([i, st]); } }
  console.log(JSON.stringify(pick));
}
console.log(`widgets: ${checks - bad} of ${checks} checks hold${bad ? `, ${bad} FAIL` : ''}`); process.exit(bad ? 1 : 0);
