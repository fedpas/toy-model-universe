#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""maxwell_wave.py -- a plane wave F = F0 f(k.x) solves nabla F = 0 on the labels of Cl(1,3) exactly when omega^2 = |k|^2.
[bit] nabla F = khat F0 f', khat = omega g0 + k1 g1 + k2 g2 + k3 g3: the kernel of F0 -> khat F0 on the 6 bivectors (bit rule, exact rank);
      khat F0 has grades 1 and 3 only (the two halves of Maxwell's equations); the star F -> F I sends the label a to a xor 1111.
[std] numpy: k.E = k.B = 0, k x E = omega B, k x B = -omega E (8 equations on E, B in R^3), rank by SVD.
[ctl] the same code on Cl(4,0) has no plane wave.  Run: python3 maxwell_wave.py [--fault NOSIGN]  (NOSIGN: the swap sign dropped)"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tutlib import *
import numpy as np
FAULT = fault_option(['NOSIGN'])
class NoSign(BR):                                                   # the wrong product of the fault: squares kept, swap sign dropped
    def s(self, a, b): return abs(BR.s(self, a, b))
A = (NoSign if FAULT else BR)([1, -1, -1, -1])                      # Cl(1,3): bit 0 is time
BIV = [m for m in range(16) if popcount(m) == 2]
KS = [(1, 1, 0, 0), (5, 3, 4, 0), (3, 1, 2, 2), (7, 2, 6, 3), (1, 0, 0, 1), (2, 1, 0, 0), (5, 3, 0, 0), (3, 0, 0, 0), (0, 1, 0, 0), (4, 1, 2, 2)]
null = lambda k: k[0] ** 2 == k[1] ** 2 + k[2] ** 2 + k[3] ** 2
vec = lambda k: {1 << mu: k[mu] for mu in range(4) if k[mu]}
def kernel(alg, k): return 6 - rank_fr([alg.mul(vec(k), {b: 1}) for b in BIV], 16)
def kernel_std(k):
    w, q = k[0], np.array(k[1:], float); z = np.zeros(1)
    colE = [np.concatenate([[q @ v], z, np.cross(q, v), w * v]) for v in np.eye(3)]
    colB = [np.concatenate([z, [q @ v], -w * v, np.cross(q, v)]) for v in np.eye(3)]
    return 6 - int(np.linalg.matrix_rank(np.array(colE + colB).T, tol=1e-9))
head('1. nabla F = 0 for F = F0 f(k.x): the kernel of F0 -> khat F0 on the bivectors of Cl(1,3)')
kb, ks = [kernel(A, k) for k in KS], [kernel_std(k) for k in KS]
chk('bit', kb == [2 if null(k) else 0 for k in KS], 'kernel 2 on the 5 null k, 0 on the 5 others (exact rank on the labels): %s' % kb)
F0 = dict(zip(BIV, (2, 3, 5, 7, 11, 13))); P = A.mul(vec((4, 1, 2, 2)), F0)
chk('bit', {popcount(m) for m in P} == {1, 3}, 'khat F0 for a generic F0 has %d grade-1 and %d grade-3 components: the two halves of the equations' % (sum(popcount(m) == 1 for m in P), sum(popcount(m) == 3 for m in P)))
S = A.mul(vec((5, 3, 4, 0)), {1 << 3: 1}); star = A.mul(S, {15: 1})
chk('bit', not A.mul(vec((5, 3, 4, 0)), S) and not A.mul(vec((5, 3, 4, 0)), star) and set(star) == {m ^ 15 for m in S},
    'k = (5,3,4,0): F0 = khat g3 and its star F0 I solve the equation; the star sends each label of F0 to its complement')
chk('std', ks == [2 if null(k) else 0 for k in KS], 'the vector form has the same kernels (numpy SVD): %s' % ks)
chk('bit==std', kb == ks, 'the 10 kernel dimensions agree')
chk('ctl', [kernel(BR([1, 1, 1, 1]), k) for k in KS] == [0] * 10, 'Cl(4,0) (all squares +1): no plane wave at any of the 10 k: the light cone comes from the signature')
finish('MAXWELL-WAVE')
