#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""dirac_rest.py -- the rest solution psi = rho^(1/2) R exp(-J m t) solves the Dirac-Hestenes equation nabla psi J = m psi g0 on the labels of
Cl(1,3) (J = g2 g1, both J and g0 multiply psi on the right), exactly, as a power series in t to order 8.
[bit] psi_k = psi_0 (-m J)^k / k!, and the coefficient of t^k: g0 (k+1) psi_(k+1) J = m psi_k g0; the even psi_0 with g0 psi_0 = psi_0 g0.
[std] numpy Dirac matrices (Dirac representation): (i G0 d_t - m) u exp(-i m t) = 0 is (G0 - 1) u = 0, 2 complex = 4 real dimensions.
[ctl] psi_0 with a boost part fails.  Run: python3 dirac_rest.py [--fault LEFTJ]  (LEFTJ: the phase exp(-J m t) put on the left of psi_0)"""
import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tutlib import *
from fractions import Fraction as Fr
import numpy as np
FAULT = fault_option(['LEFTJ'])
A = BR([1, -1, -1, -1]); m, N = 3, 8                                   # Cl(1,3), bit 0 is time; mass 3, order 8
g0, J = {1: 1}, {6: -1}                                                # J = g2 g1 = -e_{12}, label 0110
rev = lambda x: {a: (-1 if popcount(a) % 4 in (2, 3) else 1) * v for a, v in x.items()}
R = A.mul({0: Fr(3, 5), 6: Fr(4, 5)}, {0: Fr(5, 13), 12: Fr(12, 13)})    # a rotor: R rev(R) = 1
def series(psi0):
    out, step = [psi0], A.scal(J, -m)
    for k in range(1, N + 1): out.append(A.scal(A.mul(step, out[-1]) if FAULT else A.mul(out[-1], step), Fr(1, k)))
    return out
def solves(psi0):
    P = series(psi0)
    return all(A.scal(A.mul(A.mul(g0, P[k + 1]), J), k + 1) == A.scal(A.mul(P[k], g0), m) for k in range(N))
head('1. the rest solutions of nabla psi J = m psi g0 (series in t, exact on the labels)')
psi0 = A.scal(R, 2)
chk('bit', A.mul(psi0, rev(psi0)) == {0: 4}, 'psi_0 = 2 R with R = (3 + 4 e12)/5 (5 + 12 e23)/13: psi_0 rev(psi_0) = rho = 4')
chk('bit', solves(psi0), 'psi = psi_0 exp(-J m t), m = 3: the equation holds at every order t^0 ... t^%d' % (N - 1))
EVEN = [a for a in range(16) if popcount(a) % 2 == 0]
ker = 8 - rank_fr([A.add(A.mul(g0, {a: 1}), A.mul({a: 1}, g0), -1) for a in EVEN], 16)
chk('bit', ker == 4 and all(solves({a: 1}) for a in (0, 6, 10, 12)), 'the even psi_0 that commute with g0 span %d real dimensions: 1, e12, e13, e23 (the even Pauli part), each a solution' % ker)
G0 = np.diag([1, 1, -1, -1]).astype(complex); sx, sy, sz = np.array([[0, 1], [1, 0]]), np.array([[0, -1j], [1j, 0]]), np.diag([1, -1])
Gk = [np.block([[0 * s, s], [-s, 0 * s]]) for s in (sx, sy, sz)]; G = [G0] + Gk; eta = np.diag([1, -1, -1, -1])
cliff = all(np.allclose(G[a] @ G[b] + G[b] @ G[a], 2 * eta[a, b] * np.eye(4)) for a in range(4) for b in range(4))
kstd = 2 * (4 - np.linalg.matrix_rank(G0 - np.eye(4)))
chk('std', cliff and kstd == 4, 'Dirac matrices: G_a G_b + G_b G_a = 2 eta_ab; the rest equation (G0 - 1) u = 0 has %d real dimensions' % kstd)
chk('bit==std', ker == kstd, 'the two counts of rest solutions agree (%d = %d)' % (ker, kstd))
chk('ctl', not solves({0: 1, 3: 1}), 'psi_0 = 1 + e01 (a boost part) is not a solution: the order t^0 fails')
finish('DIRAC-REST')
