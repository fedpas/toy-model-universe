# Algebra on the bit rule

## Opening · one rule, three algebras

A first course in algebra asks what a structure is, up to isomorphism: a group by its table, a ring by its ideals and units, an algebra over a field by its dimension, its centre, its simple pieces and its modules. A second course adds forms, cohomology classes and the division algebras. This tutorial meets each of these notions on one finite object of the Atlas, the bit rule, and draws it.

Take n switches. A label is a setting of the switches, a string a of n bits; it stands for a basis element $e_a$, the product of the generators $e_i$ that are on, in increasing order of i. Two basis elements multiply by

$$\begin{aligned} e_a\,e_b &= s(a,b)\,e_{a\oplus b},\\ s(a,b) &= (-1)^{N(a,b)}\prod_{i\in a\wedge b}\varepsilon_i ,\end{aligned}$$

where a ⊕ b is the bitwise XOR, a ∧ b the bitwise AND, N(a,b) the number of pairs (i in a, j in b) with j < i, and $\varepsilon_i \in \{+1,-1,0\}$ the square of $e_i$. That is the whole input: n and the n squares. With p squares +1, q squares −1 and r squares 0 the rule is the Clifford algebra Cl(p,q,r) written in an orthonormal frame, and it is associative for every n and every choice of squares (Thm T1; the check cat·S1 runs the 331 776 = 81 × 16³ blade triples of n = 4, all 81 choices of squares). The Atlas calls Cl(p,q,r) a *cell*; the cell with no generator is ℝ (ATL-001).

What the rule gives an algebra course is a supply of objects that are finite, explicit and computed: a group (the labels), a 2-cocycle (the sign), quadratic forms over 𝔽₂ and ℤ₄, the division algebras ℝ, ℂ, ℍ and the matrix algebras over them, a period of eight, modules and the groups they generate, Frobenius forms, lattices, Lie algebras and, with a sign that is not a cocycle, the octonions. Each section below takes one notion of the course, names the row of the Atlas that holds it, quotes the log that checks it, draws the object, and says where the course goes further than the finite object.

**The worked example, n = 2.** There are four labels, 1, e₁, e₂, e₁₂, and the label of a product is the XOR: the first panel of the figure is the group table of ℤ₂², the same for every choice of squares. The signs are where the squares enter. With squares (+,+) the matrices e₁ = diag(1, −1) and e₂ = [[0, 1], [1, 0]] multiply as the table says and the four blades are independent: Cl(2,0) = M₂(ℝ). With squares (−,−), i = e₁, j = e₂, k = e₁₂ satisfy i² = j² = k² = ijk = −1: the quaternions, Cl(0,2) = ℍ. With (0,0) the generators square to zero and anticommute: the exterior algebra Λ(ℝ²) = Cl(0,0,2). In the three tables 4, 6 and 1 of the 16 signs are minus and 0, 0 and 7 products vanish. The Atlas stores the same three tables for its check scw·P1c ("for every choice of squares in {+1,-1,0} on 2 and 3 switches (36 tables) the bit-rule product is associative"), and the figure script recomputes the counts.

![One rule, three algebras at n = 2. First panel: the label a ⊕ b of each product, the group table of ℤ₂², the same for every choice of squares. The other panels: the sign s(a,b), row a, column b, for the squares (+,+), (−,−) and (0,0): Cl(2,0) = M₂(ℝ), Cl(0,2) = ℍ, Cl(0,0,2) = Λ(ℝ²). Drawn by figs_alg.py with the bit rule of checks/selfcheck/steps15_17/bitcliff.py; the counts 4, 6, 1 (minus) and 0, 0, 7 (zero) are checked against the shipped tutorial's Part 0.](figs/f01_three_n2.svg)

The widget is the product of two labels, step by step: the label by XOR, the swaps that sort the word, the squares of the shared generators, and the sign.

@@widget product

> **Try it.** Take n = 2 and the squares (−1, −1): check ij = k and ji = −k, then k² = −1. Set one square to 0 and see which products vanish: exactly those whose labels share the null switch.

## Part I · The rule as an algebra

Part I is first-course material: a group, an algebra, a form. Its second section goes one step beyond, to the cohomology class that the sign is.

### B1 · The group ℤ₂ⁿ and the algebra of dimension 2ⁿ

**The course.** An elementary abelian 2-group is a group in which every element other than the identity has order 2; a finite one is (ℤ/2)ⁿ, a vector space over the field 𝔽₂ with two elements. A real algebra is a real vector space with a bilinear product; it is associative when (xy)z = x(yz) for all x, y, z, and commutative when xy = yx.

**The Atlas's object.** The 2ⁿ labels with XOR are this group: a ⊕ a = 0, so every label is its own inverse, and the labels are the vector space 𝔽₂ⁿ. The algebra lens of the Atlas writes them as the frame lattice reduced mod 2 (its dictionary entry D01) and as the label ring (𝔽₂ⁿ, xor, and) (D67): xor gives the label of a product, the bitwise and gives the overlap where the squares enter. The 2ⁿ blades are a basis of a real algebra of dimension 2ⁿ whose product is associative for every choice of squares (Thm T1, cat·S1). The group is abelian; the algebra is not. For squares ±1 two blades commute or anticommute,

$$e_a\,e_b = (-1)^{|a||b|-|a\wedge b|}\,e_b\,e_a ,$$

with |a| the number of switches on; Thm T6 (c) calls |a||b| − |a ∧ b| the polar form of the Clifford class.

The labels are the vertices of the n-cube, and an edge joins a to a + i, the label with one more switch on. The rule puts a sign on each edge: $e_i\,e_a = \sigma(a,i)\,e_{a+i}$ with σ(a,i) = (−1) to the number of j in a with j < i, the Jordan–Wigner sign. Thm T6 (a) proves that this sign makes every square face of the cube anticommute, and that every edge sign that does so is one of its gauge transforms: the first cohomology of the cube's 2-skeleton over 𝔽₂ is zero. check_T6 runs it ("every square of the n-cube anticommutes with the Jordan-Wigner sign, n <= 7"; H¹ = 0 for n ≤ 5) and at n = 3 finds by brute force "128 = 2^7 anticommuting assignments = one gauge orbit". Reading the blades as the faces and vertices of this cube is the Atlas's own reading, and it is marked so; its computable part, one label per ordered product of distinct generators and a generator moving a label along a cube edge, is checked exactly in every cell with n ≤ 4 (PAG-002b).

![The cube of labels at n = 3. Each vertex is a label; the edge from a to a + i carries the sign of e_i e_a, solid blue for +, dashed orange for −. Each of the six faces has an odd number of minus edges, so the generators anticommute. Drawn by figs_alg.py from the bit rule (bitcliff.py), which also checks the six faces; the count 128 of such sign choices is that of check_T6.log.](figs/f02_cube_signs.svg)

Each signed blade ±eₐ is an element of a finite group of order 2ⁿ⁺¹, an extension of ℤ₂ⁿ by {±1}. The Atlas's groups page calls it the finite shadow of the cell and computes, for every class, its form Q and its orthogonal group O(Q), with W(E_n) mod 2 = O(Q) for n = 3 … 8 (LAB-009). Over the field 𝔽₂ itself the rule would collapse, since −1 = 1: the shadow keeps the signs and drops the real coefficients.

**Where the course goes further.** A first course classifies the finitely generated abelian groups and studies non-abelian groups through subgroups, quotients and actions. The labels give one family, the elementary abelian 2-groups, and the blade groups above them; the structure theorem for finitely generated abelian groups is recalled (D. S. Dummit and R. M. Foote, *Abstract Algebra*; recalled, not in the package).

> **Try it.** In the product widget take n = 3 and all squares +1. The blades e₁₂ and e₁₃ share one switch: |a||b| − |a∧b| = 4 − 1 = 3 is odd, so they anticommute. Predict, then check, whether e₁₂ and e₃ commute.

### B2 · Forms, 2-cocycles and coboundaries

**The course.** A symmetric bilinear form b and its quadratic form q(x) = b(x,x) determine each other by polarization, b(x,y) = ½(q(x+y) − q(x) − q(y)), in characteristic not 2. One step beyond the first course: a 2-cocycle α of a group G with values in the units of a ring gives the twisted group algebra with basis $u_g$ and $u_g u_h = \alpha(g,h)\,u_{gh}$; it is associative exactly when α satisfies the cocycle identity, and rescaling the basis multiplies α by a coboundary, which gives an isomorphic algebra. The classes form H²(G; units).

**The Atlas's objects.** For $v=\sum x_i e_i$ the rule gives $v^2 = \sum \varepsilon_i x_i^2$, because $e_ie_j=-e_je_i$ for i ≠ j: the cell is built on the form b(eᵢ, eⱼ) = εᵢ δᵢⱼ, and vw + wv = 2b(v,w) (scw·P1c checks $e_ie_j+e_je_i = 2\varepsilon_i\delta_{ij}$ on its 36 tables). Over 𝔽₂ there is no ½, and the Atlas reads three objects off the labels: the parity π(a) = |a| mod 2, the binary form Q(a) = [eₐ² = −1], which is 1 when the blade squares to −1, and the ℤ₄-valued form w = π + 2Q. The check core·B1 shows that w is a quadratic refinement of the dot product: "w(a+b) - w(a) - w(b) = 2|a & b| mod 4 for every blade pair of every Cl(p,q), n <= 5".

The sign of the rule is a 2-cocycle of ℤ₂ⁿ. For squares ±1 it is bimultiplicative in each argument, and a bimultiplicative sign satisfies

$$s(a,b)\,s(a\oplus b,c) = s(a,b\oplus c)\,s(b,c);$$

Thm T1 gives this reason, and the same two lines with values in the monoid {+1, −1, 0} when a square is 0. So a cell is the twisted group algebra ℝˢ[ℤ₂ⁿ] (dictionary D02). A gauge eₐ ↦ f(a)eₐ with f = ±1 and f(0) = 1 multiplies s by the coboundary f(a) f(b) f(a ⊕ b). Thm T6 (c) identifies the classes: H²(ℤ₂ⁿ; 𝔽₂) is the space of quadratic forms on 𝔽₂ⁿ, of dimension n(n+1)/2, that is 1, 3, 6, 10 for n = 1 … 4 (cat·K2a solves the cocycle equations as linear systems; check_T6, H2), and the Clifford cells are the classes whose polar form is |a||b| − |a ∧ b|. A class is fixed by the squares of the blades and the commutation signs; the figure script checks at n = 3 that all 2⁷ = 128 gauges keep both, for all eight choices of squares ±1.

![Cl(2,0) as a twisted group algebra. Top left: its table, entry e_a e_b = ±e_(a⊕b). Top right: the matrices e₁ = diag(1, −1), e₂ = the swap matrix with rows (0 1) and (1 0), and their products, which multiply as the table says. Bottom: the gauge that sends e₁₂ to −e₁₂, its coboundary f(a) f(b) f(a ⊕ b), and the new signs; six entries change, no square and no commutation sign does. Drawn by figs_alg.py with bitcliff.py, which checks the matrices against the table and the invariance of the class under all 128 gauges at n = 3.](figs/f03_cl20_gauge.svg)

What the class remembers, LAB-019 says exactly: for r = 0 the triple (V, Q, π) fixes n and p − q mod 8 and nothing more — Wood's classification of ℤ₄ forms by the Brown invariant, "checked for n ≤ 12 with explicit block isometries (core·B18) and for n ≤ 5 by a full search (core·B6c)" — while Q alone fixes only the type, with c ↔ 2 − c, and Cl(2,0) and Cl(1,1) have isometric Q. At n = 2 the rule has four classes, the squares (±, ±); three of them give the same algebra M₂(ℝ), and (−,−) gives ℍ.

The widget applies a gauge by hand: flip a label and the table changes, the algebra does not.

@@widget gauge

> **Try it.** At n = 2 with squares (+1, +1), flip e₁ and e₂ together: no entry changes, because this f is a character, f(a ⊕ b) = f(a) f(b), and its coboundary is 1. Then flip e₁₂ as well: the coboundary of the gauge f = (+, −, −, −) changes the sign of e₁e₂ and e₂e₁ alike, so their quotient, the commutation sign, stays.

**Where the course goes further.** Group cohomology in every degree, for groups that are not elementary abelian, with any module of coefficients; the Schur multiplier; crossed products and Galois cohomology. The Atlas computes H² of ℤ₂ⁿ with 𝔽₂ values, and the cocycle with values in the monoid {+1, −1, 0} for null squares (Thm T1); a cohomology for the labels with null bits is an open question (LNC-086, in B5). Recalled: K. S. Brown, *Cohomology of Groups* (recalled, not in the package).

### Three questions for an algebraist (Part I)

1. Thm T6 (c) singles out the Clifford cells among the classes of H²(ℤ₂ⁿ; 𝔽₂) by their polar form |a||b| − |a ∧ b|. Which other classes give graded-central-simple real algebras, and are they all twisted forms of cells? The nearest rows are T6 (c) and LAB-019 (proved by the Atlas); the count for every n is not in the Atlas.
2. Thm T6 (a, b) make the Jordan–Wigner sign a 1-cochain on the cube whose coboundary is −1 on every face, unique up to gauge, and the labels a Koszul complex that is exact. Is there a standard cubical cohomology in which these are known statements, and what would the higher skeleta classify? Nearest: T6, and PAG-002b (our reading, its label count checked).
3. With null squares the sign takes values in a monoid with zero. LNC-086 (open) asks for a cohomology of such cocycles on the contracted monoid of labels in which the radical is a cohomological notion.

## Part II · The clock: simple algebras and their modules

Part II is the algebra of the cells themselves: their Wedderburn type, their tensor products, their radical, their Frobenius forms, their simple modules and the group the modules make. The convention for p and q is the Atlas's: Cl(p,q) has p generators of square +1 and q of square −1.

### B3 · ℝ, ℂ, ℍ and matrix algebras: the clock

**The course.** Wedderburn's theorem: a finite-dimensional simple algebra over a field is a matrix algebra $M_N(D)$ over a division algebra D, and a semisimple one is a finite product of simple ones. Over ℝ, Frobenius' theorem says D is ℝ, ℂ or ℍ. The centre counts the simple factors and says whether D is ℂ.

**The Atlas's object.** Thm T4 (i): Cl(p,q) is k copies of $M_N(D)$, with (D, k) depending only on the clock c = p − q mod 8, and $kN^2\dim D = 2^n$:

| clock c | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| D | ℝ | ℝ | ℝ | ℂ | ℍ | ℍ | ℍ | ℂ |
| copies k | 1 | 2 | 1 | 1 | 1 | 2 | 1 | 1 |
| even part | ℝ ⊕ ℝ | ℝ | ℂ | ℍ | ℍ ⊕ ℍ | ℍ | ℂ | ℝ |

It is proved inside the bit rule from the isomorphisms Cl(n+2,0) = Cl(0,n) ⊗ Cl(2,0), Cl(0,n+2) = Cl(n,0) ⊗ Cl(0,2) and Cl(p+1,q+1) = Cl(p,q) ⊗ M₂(ℝ), six base cells, and ℍ ⊗ ℍ = M₄(ℝ) taken twice around for the period 8; the theorem's status is *reduced*, because that the eight pairs are the graded Morita classes forming ℤ₈ is Wall's theorem, recalled. The ungraded type takes five values, and the pair (type of the cell, type of its even part) takes eight, one per clock value (Thm T4 (ii)); cat·C1 prints the eight pairs, the last row of the table. The figure script reads them from cat_check.log and checks them on the cells of solid_cube.log: the type of Cl(p,q) and that of its even part Cl(p,q−1) (Thm T5).

![The clock. Outer ring: the type of Cl(p,q) at c = p − q mod 8, with two cells of that clock in small print; a double ring marks two copies. Inner ring: the type of the even part. Adding a generator of square +1 moves one step clockwise. Drawn by figs_alg.py from cat_check.log (cat·C1) and solid_cube.log (solid.K1), which agree on all 36 cells.](figs/f04_clock_wheel.svg)

The types are computed, not only tabled, on the 36 cells with p + q ≤ 7. The check solid_cube.py, which CAND-116 cites, builds for each cell a minimal left ideal from the rule (B7), computes its commutant exactly and finds ℝ, ℂ or ℍ with the number of simple summands given by the clock (solid.K1): 13 cells of type ℝ, 10 of type ℂ, 13 of type ℍ (solid.K2). The ℍ cells carry Kramers' degeneracy: with i, j, ij a quaternion triple of the commutant (j² = −1, an antiunitary T with T² = −1), every symmetric element that the check draws at random has each eigenvalue four times over ℝ, a Kramers pair over ℂ (solid.K3); on the ℝ cells the spectrum is simple, so Kramers is not forced there. A control: the mirror clock −(p − q) "disagrees with the computed type on 28 of the 36 cells" (solid.K6).

![The 36 cells Cl(p,q) with p + q ≤ 7, row n = p + q, column q. The number is the real dimension of the minimal module; the colour is its commutant ℝ, ℂ or ℍ; a superscript ² and a double frame mark two simple summands. Each diagonal q − p = constant is one clock. Drawn by figs_alg.py from solid_cube.log (solid.K1); the counts 13, 10, 13 are those of solid.K2.](figs/f06_type_table.svg)

At row 8 the table closes on itself. Cl(4,4) ≅ Cl(0,8) ≅ Cl(8,0) ≅ M₁₆(ℝ), the three cells of row 8 with clock 0, one graded algebra; Cl(5,3) and Cl(1,7) are M₁₆(ℝ) too, with clock 2 and a volume element of square −1 (GEN-009, ATL-023; ATL-020 for Cl(4,4)). ATL-023 states the repeat: "Period 8 means the types repeat: Cl(n+8)=Cl(n)⊗M₁₆(ℝ)".

**The clock's phase.** The clock is also an angle. Sum $i^{w(a)}$ over the labels, with w = π + 2Q of B2:

$$\begin{aligned} S(p,q)=\sum_a i^{\,w(a)} &= (1+i)^p\,(1-i)^q\\ &= 2^{n/2}\,e^{i\pi(p-q)/4}.\end{aligned}$$

core·B3 checks it exactly for n ≤ 8 and cat·K4a for p + q ≤ 10, so the clock is the Brown invariant of the ℤ₄-form w (LAB-017, RSN-029; Thm T4 (iii)). With r null generators the null bits add nothing to the exponent, and the sum is $2^r(1+i)^p(1-i)^q$: the Gauss sum of the mother cell Cl(p+r, q+r), and 2ʳ times that of the quotient Cl(p,q), whose Brown invariant is the clock (LAB-017; core·B3 up to n ≤ 6). The type is a sign of the same sum: ν = Σₐ eₐ² = Re((1 − i)S) is positive for ℝ, zero for ℂ and negative for ℍ (Thm T4 (iv), cat·K4c, LNC-055), and ν = kN·ind(D) with ind(ℝ) = 1, ind(ℂ) = 0, ind(ℍ) = −2, the Frobenius–Schur count of the blade group.

![The Gauss sum of the labels on the complex plane. Each cell Cl(p,q) with n = p + q ≤ 6 sits on the circle of radius n at the angle π(p − q)/4: the eight rays are the eight clock values; ×2 marks two cells at one place; the colour is the type. Drawn by figs_alg.py, which sums i^w(a) over the labels with the bit rule and checks the closed form (1 + i)^p (1 − i)^q on the 27 cells, and 2^r times it with null generators (LAB-017).](figs/f05_gauss_phases.svg)

The clock widget reads everything from the labels: it sums the Gauss sum and ν, squares the top label, and from these finds D, the number of copies k and N; its self-test compares the result with the 36 cells of solid_cube.log.

@@widget clock

> **Try it.** Start at Cl(0,0) and add generators of square −1: ℝ, ℂ, ℍ, ℍ ⊕ ℍ, M₂(ℍ), M₄(ℂ), M₈(ℝ), M₈(ℝ) ⊕ M₈(ℝ), M₁₆(ℝ). At each step check kN² dim D = 2ⁿ and watch the Gauss sum turn by −π/4.

**Where the course goes further.** The course proves Wedderburn–Artin for every semisimple ring and Frobenius' theorem for every real division algebra; the Atlas proves the type table for its cells only, inside the rule. That the period 8 is Bott periodicity in topology is a pointer: LAB-018 says "the identification with KO is Atiyah–Bott–Shapiro, a pointer, source unread". Recalled: the classification of real Clifford algebras in H. B. Lawson and M.-L. Michelsohn, *Spin Geometry*, ch. I, and P. Lounesto, *Clifford Algebras and Spinors* (recalled, not in the package).

### B4 · Tensor and graded tensor products; the Bott repeat

**The course.** The tensor product A ⊗ B of two algebras multiplies factor by factor, (a ⊗ b)(a′ ⊗ b′) = aa′ ⊗ bb′. When A and B are ℤ₂-graded, the graded tensor product A ⊗̂ B inserts the Koszul sign, $(a\otimes b)(a'\otimes b') = (-1)^{|b||a'|}\,aa'\otimes bb'$, and the graded tensor product of the Clifford algebras of two spaces is the Clifford algebra of their orthogonal sum (K. Wernli, *Lecture Notes on Spin Geometry*, Def. 1.1.8 and Thm 1.4.1, as the shipped tutorial's B6 quotes them; recalled, not in the package).

**The Atlas's object.** Put the first m generators in one factor and the rest in the other. A label becomes a pair (a₁, a₂), and the sign factors:

$$s(a,b) = s_1(a_1,b_1)\;s_2(a_2,b_2)\;(-1)^{|a_2||b_1|}.$$

Concatenating generator lists is the graded tensor product with the Koszul sign, and the clock adds (LNC-117; cat·K5a "on all label pairs, for six pairs of signatures including null generators", cat·K4a). cat·K5c reads the same sign as the parity of the inversions of the concatenated list, counted by an independent bubble sort on all 65 536 label pairs of 8 generators. The figure script checks the factorisation for every split of every n ≤ 4 and all 3ⁿ choices of squares.

![The graded tensor product Cl(1,0) ⊗̂ Cl(1,1) at n = 3. Left: the Koszul sign (−1)^(|a₂||b₁|), with a₁ the bit of e₁ and a₂ the bits of e₂, e₃. Right: the sign of the bit rule for the squares (+, +, −); outlined where the Koszul sign is −1, which is exactly where s differs from the product of the two factor signs. Drawn by figs_alg.py with bitcliff.py, which checks the 64 entries and every split for n ≤ 4.](figs/f10_koszul.svg)

The ordinary tensor product has no sign, and the difference shows at n = 2: Cl(1,0) ⊗ Cl(1,0) = ℝ⁴ is commutative, while Cl(1,0) ⊗̂ Cl(1,0) = Cl(2,0) = M₂(ℝ) is not. With the null generators in the second factor, Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝʳ) (Thm T2 (1)). Halving is the inverse move: the even part is a cell again, Cl⁰(p,q,r) ≅ Cl(p,q−1,r) through a generator t of square −1 and ≅ Cl(q,p−1,r) through one of square +1, and "it fails only for p = q = 0 and r ≥ 3" (LNC-117; Thm T5).

The Bott repeat is a tensor product with a matrix algebra. Thm T4 (i) proves Cl(p+1,q+1) = Cl(p,q) ⊗ M₂(ℝ), an ungraded tensor product, and with Cl(n+2,0) = Cl(0,n) ⊗ Cl(2,0) and ℍ ⊗ ℍ = M₄(ℝ) eight steps around the clock give the repeat of ATL-023 and GEN-009. In the Schuller lens a fibre bundle is the same product: "base Cl(1,3), fibre Cl(0,3): a blade of the total algebra is a pair (base label | fibre label), labels concatenate and the sign is (−1)^{|b||c|} times the two factor signs: the graded tensor product, total Cl(1,6)" (LNS-015).

**Where the course goes further.** Tensor products over a commutative ring, of modules and of graded modules; the graded Brauer group, whose law this product is (B12). Recalled: T. Y. Lam, *Introduction to Quadratic Forms over Fields*, ch. IV–V (recalled, not in the package).

> **Try it.** In the product widget take n = 3 and the squares (+1, +1, −1). Compute e₂e₁ and e₁e₂₃. Which of the two picks up the Koszul sign of the split {e₁} | {e₂, e₃}? (Look for |a₂||b₁| odd.)

### B5 · Exterior algebra, nilpotent generators and the radical

**The course.** The exterior algebra Λ(V) is generated by V with v ∧ v = 0; it is graded-commutative, ω ∧ ν = (−1)^{nm} ν ∧ ω. In a finite-dimensional algebra the Jacobson radical J is the largest nilpotent ideal; the algebra is semisimple exactly when J = 0, and A/J is always semisimple.

**The Atlas's object.** All squares 0 give Λ(ℝⁿ) = Cl(0,0,n) (the Opening; scw·P1c: "with all squares 0 it is the wedge"). With only some squares 0, Thm T2 describes the whole structure. J, the span of the labels that contain a null bit, is the Jacobson radical, of dimension 2ⁿ − 2^(p+q), and the quotient is Cl(p,q); Jᵏ is spanned by the labels with at least k null bits, the layers have dimension C(r,k)·2^(p+q), and the Loewy length is r + 1; the super-centre is Λ(ℝʳ), of dimension 2ʳ; and the cell is graded-simple with super-centre ℝ exactly when r = 0. The reason is in the labels: a product of two labels vanishes or carries the null bits of both. The labels without a null bit are closed under the product and span a copy of Cl(p,q) inside the cell, a complement to J.

![The radical of Cl(1,1,2), squares (+, −, 0, 0). The 16 labels in three layers by the number of null bits: 4 without (the quotient Cl(1,1)), 8 with one (J/J²), 4 with two (J²); a product adds the null bits or vanishes, so J³ = 0. Drawn by figs_alg.py with bitcliff.py, which checks the layer rule on all 256 products and J³ = 0.](figs/f19_radical.svg)

The algebra lens adds a filtration: the popcount is an algebra grading only for ε = 0; for other squares it is a filtration whose associated graded is Λ(ℝⁿ) (dictionary, "the integer weight above the squares"), so the exterior algebra is the associated graded of every cell (D63). With null squares the labels, with the product "zero when two labels share a null bit", form a monoid with zero, M = (ℤ/2)^(p+q) × (subsets of an r-set under disjoint union), and the bit-rule sign is a 2-cocycle on M: Cl(p,q,r) is a twisted contracted monoid algebra. Whether a cohomology of such cocycles makes the radical a cohomological notion is open (LNC-086).

**Where the course goes further.** The radical of an Artinian ring, Nakayama's lemma, and the Wedderburn–Malcev theorem, which gives the complement above for every finite-dimensional algebra over a perfect field. Recalled: R. S. Pierce, *Associative Algebras* (recalled, not in the package).

> **Try it.** In the product widget take n = 2 and the squares (+1, 0). Compute e₂e₁₂: the product e₂e₁e₂ = −e₁e₂e₂ uses the null square, so it is 0. Then list the four labels of Cl(1,0,1) by layer.

### B6 · Frobenius forms and the trace

**The course.** One step beyond a first course: a finite-dimensional algebra A is a Frobenius algebra when it has a linear form λ whose pairing (x, y) ↦ λ(xy) is non-degenerate; it is symmetric when λ(xy) = λ(yx). The Nakayama automorphism ν measures the failure, λ(xy) = λ(y ν(x)). A group algebra of a finite group is symmetric Frobenius with λ the coefficient of the identity; a matrix algebra with the trace.

**The Atlas's object.** Let λ(x) be the coefficient of the full label F = 1…1 in x. LNC-028 states and Thm T3 (F1) proves: "λ(e_{a}e_{b}) ≠ 0 exactly when b = a ⊕ F, and then it is ±1. Because a and a ⊕ F share no bit, no square is ever used: the signed antidiagonal is the same for every signature, and the pairing is non-degenerate with null generators too. Cl(p,q,r) is a Frobenius algebra for every (p,q,r)." The check cat·F1 runs all 55 signatures with 1 to 5 generators (LNC-111); the figure script checks the 27 choices of squares at n = 3. The Nakayama automorphism is the identity for n odd and the grade involution α for n even; ungraded, a symmetric Frobenius form exists exactly when n is odd or r = 0, and for n even and r = 0 it is ⟨x⟩₀ = λ(e_F x); the projective algebra Cl(3,0,1) is Frobenius and not symmetric, since every w with α(x)w = wx lies in J (LNC-004, LNC-030). In super vector spaces every cell is a symmetric Frobenius algebra: λ(xy) = (−1)^{|x||y|}λ(yx), the Nakayama twist is the Koszul sign (LNC-004). The Frobenius forms are the λ(u·) with u a unit, a torsor under the unit group (Thm T3).

![The Frobenius pairing at n = 3. Left: λ(e_a e_b) with λ the coefficient of e₁₂₃: a signed antidiagonal pairing each label with its complement, the same for all 27 choices of squares. Right: the scalar-part pairing ⟨e_a e_b⟩₀ in Cl(1,1,1): the squares on the diagonal, zero on the labels with the null bit, rank 4. Drawn by figs_alg.py with bitcliff.py.](figs/f11_frobenius.svg)

The trace of the course is the scalar part. LNC-060: "The trace is ⟨x⟩₀ = λ(ωx), a symmetric Frobenius form, canonical up to a central unit among the symmetric ones. The top-blade form λ is a Frobenius form but never a state: λ(1) = 0; with null generators every state vanishes on J." The scalar-part pairing has rank 2^(p+q): it is blind to every label with a null bit (Thm T3 (F4)). In Cl(3,0) = M₂(ℂ) it is the trace of quantum mechanics: ρ = (1 + v)/2 is positive iff |v| ≤ 1, and the projector P = (1 + u)/2 gives 2⟨ρP⟩₀ = (1 + v·u)/2 (LNC-060; cat·C2 on 12 rational pairs). Reading the trace as a Frobenius form of the algebra is marked ours in the same row.

A commutative Frobenius algebra is what a two-dimensional topological field theory needs. Among the cells the commutative one is Λ(ℝʳ), "a commutative Frobenius monoid in super vector spaces, and not a special one": with the copairing inverse to the pairing, m∘Δ is 0 for r even and, for r odd, multiplication by 2^r times the top label, which squares to 0 (LNB-025c; hch·8, r ≤ 4); reading it through cospans is ours (LNB-025d).

**Where the course goes further.** Frobenius and self-injective algebras in representation theory, the Nakayama functor, and the equivalence between commutative Frobenius algebras and two-dimensional topological field theories. Recalled: J. Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories* (recalled, not in the package); the Atlas's Atiyah lens reads Hitchin's account of the same equivalence (reports/analyses/atiyah_lens.html, theme 11).

> **Try it.** The figure shows λ(e₂e₁₃) = −1. Compute e₂e₁₃ in the product widget for the squares (+,+,+), (−,−,−) and (0,0,0): the sign is −1 each time, because e₂ and e₁₃ share no switch and only one swap sorts the word.

### B7 · Minimal left ideals and spinors

**The course.** A simple algebra $M_N(D)$ has, up to isomorphism, one simple left module, the column space $D^N$. It is a minimal left ideal Af for a primitive idempotent f, its endomorphisms are $fAf \cong D$ (up to the opposite), and as a left module A is N copies of it.

**The Atlas's object.** A minimal left ideal of a cell comes from commuting labels. Take blades $e_{s_1},\dots,e_{s_k}$ of square +1 that commute with each other; then

$$f = \prod_{i=1}^{k}\frac{1+e_{s_i}}{2}$$

is an idempotent, and the left ideal Cl·f has the basis $e_R f$, one vector for each coset R of the group H that the sᵢ span: each basis vector is the signed sum of the labels of one coset, a label with a sign in each place. LNC-059 gives the count: "The largest set of mutually commuting labels whose blades square to +1 spans a split commutative algebra of dimension 2^{w}, whose 2^{w} orthogonal idempotents are the finite shadow of the spectral theorem; w is the Witt index of the 𝔽₂ quadric q(a) = [e_{a}² = −1], and 2^{w} = (number of simple factors) × N for Cl(p,q) = M_{N}(D) or two copies of it (36 signatures)" (Thm T11 (W1)). The ideal is minimal when f Cl f is a division algebra; solid.K1 finds this on the 36 cells, and the control solid.K6 builds an ideal with one idempotent factor left out and finds it "not irreducible ... on 33 of the 33 cells with k >= 1".

![Minimal left ideals of Cl(3,1) = M₄(ℝ) and Cl(1,3) = M₂(ℍ). Each row is a basis vector e_R f of the ideal Cl·f: the labels of one coset R ⊕ H, each with its sign. For Cl(3,1), f = (1 + e₁ + e₂₄ + e₁₂₄)/4 from two commuting labels of square +1; four rows, so 16 = 4 × 4 and N = 4. For Cl(1,3), f = (1 + e₁)/2; eight rows, 16 = 2 × 8, N = 2, and f Cl f = ℍ. Drawn by figs_alg.py with bitcliff.py; the dimensions 4 and 8 and the commutants 1 and 4 are checked against solid.K1.](figs/f08_min_ideal.svg)

The number of copies is the clock's N: at c = 2 the cell Cl(3,1) is four copies of its 4-dimensional ideal, at c = 6 the cell Cl(1,3) two copies of its 8-dimensional one. In the Dirac lens the same construction counts spinors. CAND-069: the even algebra Cl⁺(1,n−1) ≅ Cl(n−1,0) is N copies of its spinor module, with the commutant acting on the multiplicity space (dlim·MOD for n = 4 … 8: "primitive idempotent from 1 label involution(s); e Cl+ e = C; left ideal dim 4 ... N = 2: M2(C)" at n = 4). At n = 5 the right multiplication by Q = γ₁γ₂γ₃γ₄ splits a field ψ into two minimal left ideals of dimension 8 with commutant ℍ, two Dirac fields, and for n = 5, 6, 7, 8 the right multiplications that commute with the Dirac operator split ψ into 2, 2, 4, 4 Dirac fields (CPL-007b). In Cl(2,2) the nine blades of square +1 and their six commuting lines form the Peres–Mermin square: the product of the six line signs is −1, so no assignment of ±1 to the nine blades respects all six lines (LNC-059). For p + q even, the real spinor module splits into two real half-spin modules, the Majorana–Weyl case, exactly when p − q ≡ 0 mod 8 (CAND-024).

**Where the course goes further.** The groups Spin(p,q) and Pin(p,q) as groups of units, their representations, and the spinor bundles of geometry. Recalled: Lawson and Michelsohn, *Spin Geometry*, ch. I, §5, as CAND-069 cites it (recalled, not in the package).

> **Try it.** The row e₂f of Cl(3,1) in the figure reads +e₂, −e₁₂, +e₄, −e₁₄. Multiply e₂ into f = (1 + e₁ + e₂₄ + e₁₂₄)/4 by hand with the rule (e₂e₁ = −e₁₂, e₂e₂₄ = e₄ since e₂² = +1) and recover the four signs.

### B8 · Clifford modules and the K-theory of a point

**The course.** Beyond a first course: the Grothendieck group of the modules of an algebra, formal differences with [M ⊕ N] = [M] + [N]. For a subalgebra B ⊂ A, restriction sends A-modules to B-modules; Atiyah, Bott and Shapiro read the cokernels of restriction along the Clifford algebras as the K-groups of a point.

**The Atlas's object.** ATY-001: "A grading of a Cl(p,q)-module is one more label of square +1, so the graded Cl(p,q)-modules are the Cl(p+1,q)-modules." The check aty_twisted_k.py builds the irreducible modules from minimal left ideals (aty.A1: on 57 cells "the ideal matrices obey the Clifford relations and the exact commutant is R, C or H"), restricts them, and computes cokernels by integer Smith normal form. For each of the 36 cells with p + q ≤ 7, the graded modules of Cl(p,q) modulo those restricted from Cl(p,q+1) form the group KO^(p−q)(point) of the recalled table ℤ, ℤ₂, ℤ₂, 0, ℤ, 0, 0, 0 (Atiyah–Bott–Shapiro), and modulo those from Cl(p+1,q) the group KO^(q−p)(point): "72 cokernels, mismatches []" (aty.A3). Along Cl(0,n), n = 0 … 9, the log prints ℤ ℤ₂ ℤ₂ 0 ℤ 0 0 0 ℤ ℤ₂, the recalled KO^(−n)(point) (aty.A2).

![The 72 graded cokernels of the cells with p + q ≤ 7. Left: a generator of square −1 added, the group KO^(p−q); right: one of square +1 added, KO^(q−p); row n = p + q, column q. Below: the eight values by the clock. The pattern runs along the diagonals: the clock alone decides. Drawn by figs_alg.py from aty_twisted_k.log (aty.A2, aty.A3), whose lists the script checks against each other.](figs/f09_cokernels.svg)

Concatenating labels (B4) gives the products. η, the generator of the ℤ₂ at n = 1, has η² ≠ 0 at n = 2; α, the irreducible of Cl(1,4) on which the volume element is +1, generates the ℤ at n = 4, and "alpha^2 (dimension 64, multiplicities [4, 0]) has class -4 = 4 beta", β the 16-dimensional irreducible of Cl(1,8); η·β ≠ 0 at n = 9 (aty.A6). Over ℂ the groups are ℤ for p + q even and 0 for p + q odd, the period 2 of complex K-theory (aty.A5). The controls are named in the log: without the grading label the list is not KO^(−n) (UNGRADED), and a generator of square +1 in place of −1 gives another list (SIGN) (aty.A2).

**Where the course goes further.** That these algebraic groups are the topological KO-groups of a point is the Atiyah–Bott–Shapiro theorem; the Atlas marks it recalled, a pointer with its source unread (LAB-018, ATY-001). K-theory of spaces, Bott periodicity through loop spaces, and the index theorem lie beyond the finite object (the Atiyah lens, theme 1). Recalled: M. F. Atiyah, R. Bott and A. Shapiro, "Clifford modules" (recalled, not in the package).

> **Try it.** The graded Cl(0,n)-modules are the ungraded Cl(1,n)-modules. In the clock widget set p = 1 and read the module dimension for q = 0 … 9: 1, 2, 4, 8, 8, 16, 16, 16, 16, 32, the list of aty.A1. Where does it stand still, and why does that match the zeros of the table?

### Three questions for an algebraist (Part II)

1. LAB-017 calls the clock the Brown invariant of the ℤ₄-form w, and the dictionary (D07) the Brauer–Wall class of Cl(p,q) with the generator Cl(1,0) ↦ 1. Is either name misleading about the generator or about the sign convention (p squares +1)? The nearest rows, LAB-017 and LAB-018, are proved by the Atlas; the identification with BW(ℝ) beyond the cells is recalled.
2. ATY-001 finds the 72 cokernels fixed by the clock for p + q ≤ 7, and the products η² ≠ 0, α² = 4β, η·β ≠ 0 up to n = 9. Is there a proof inside the rule, without topology, that the cokernels repeat with period 8 for every n? Nearest: ATY-001 and Thm T4; the identification with KO stays a pointer (LAB-018).
3. LNC-004 finds the Nakayama automorphism of the top-label form to be the grade involution for n even, and every cell symmetric Frobenius in super vector spaces. Does the graded Frobenius structure depend only on the Brauer–Wall class and r? Nearest: LNC-004, LNC-030 (proved by the Atlas).

## Part III · Lattices and Lie algebras

Part III leaves the cells for two objects built on them: the lattice that a frame spans, and the Lie algebra that the bivectors span.

### B9 · Lattices from cells; E₈

**The course.** An integral lattice is ℤⁿ with a symmetric bilinear form of integer values; it is unimodular when its Gram determinant is ±1 and even when every x·x is even. Its signature is the number of positive minus the number of negative squares in a diagonal form. E₈ is the even unimodular positive-definite lattice of rank 8, with 240 roots.

**The Atlas's object.** The lattice of a cell is its frame: the generators of Cl(p,q) span $I_{p,q}$ = ℤ^(p+q) with eᵢ·eᵢ = eᵢ², the form diag(+1 × p, −1 × q) (aty_matter_models.log, part L1, for ten cells; ATY-016 reads it as the intersection form of p·CP² # q·(−CP²), recalled). The clock sum of B3 equals the lattice Gauss sum over L/2L with x·x mod 4, both 2^(n/2) ζ₈^(p−q) (L1): the phase of the clock is the signature of I_{p,q} mod 8. LAB-018 says the same in the language of forms: "w(a) = x·x mod 4 for the 0/1 vector x of a in the lattice I_{p,q}, and the clock is the signature of I_{p,q} mod 8 (Brown's theorem ...; van der Blij for the characteristic vector 1…1)". For the forms of Atiyah, Manton and Schroers the same sum gives ζ₈^σ with σ = 0, 1, −1, 0, 0, −16, −7 for S⁴, CP², −CP², S² × S², CP² # −CP², K3 and the cell (1,8) (ATY-016; part L2).

![The phase of a lattice Gauss sum is the signature mod 8. The forms of aty_matter_models.log (part L2) at σ mod 8 on the eight positions of ζ₈^σ, and the cells Cl(p,q) of part L1 at their clock p − q, whose label sum is the lattice sum. Drawn by figs_alg.py, which reads the signatures from the log and checks, for the ten cells, that the clock sum of the labels equals the Gauss sum of I(p,q).](figs/f13_forms_wheel.svg)

E₈ sits inside the cell Cl(1,8). GOS-005: "E_n is the part of the frame lattice I_{1,n} of the cell Cl(1,n) orthogonal to k = (3; −1, …, −1). The vector k is characteristic (k·x ≡ x·x mod 2 for every x), and det E_n = k·k = 9 − n; mod 8 this is 1 − n, the clock of Cl(1,n) (van der Blij's lemma). The sign of k·k is the type: finite for n ≤ 8, affine at n = 9, Lorentzian from n = 10." At n = 8, k·k = 1 and I_{1,8} = ℤk ⊕ k^⊥ with k^⊥ = −E₈: the eight vectors h − e₁ − e₂ − e₃ and eᵢ − eᵢ₊₁ are orthogonal to k with norm −2 and Gram determinant 1, and their Gram matrix is minus the Cartan matrix of E₈ (part L4).

![E₈ inside the frame lattice I(1,8) of Cl(1,8). The eight roots h − e₁ − e₂ − e₃ and eᵢ − eᵢ₊₁, orthogonal to k = 3h − e₁ − … − e₈; a bond joins two roots with inner product +1. The diagram is the E₈ diagram. Drawn by figs_alg.py, which takes the form diag(+1, −1 × 8) from the squares of the generators of Cl(1,8) in the bit rule, computes the Gram matrix and its determinant 1, and checks the 240 roots of k^⊥ against part L4 of aty_matter_models.log.](figs/f12_e8_in_I18.svg)

The 240 roots split as 112 + 128: the vectors ±eᵢ ± eⱼ for the 28 pairs of eight bits, and the vectors ½(±1, …, ±1) with an even number of minus signs, one for each even label of 8 bits (SHP-006: "the 112 edges and the 128 even facets make the 240 roots of E8"; elad·1; Thm T10 (5)). core·B10c reads the 128 as the half-spin weights of so(16), "the 112 roots of D8 are the other part of 112 + 128 = 240".

![The 240 roots of E₈ built from labels, projected on a Coxeter plane: blue, the 112 vectors ±e_i ± e_j; orange, the 128 vectors ½(±1, …, ±1) of the even labels. They fall on 8 rings of 30, 30 being the Coxeter number. Drawn by figs_alg.py, which builds the roots from the labels, finds a simple system and the Coxeter element, and checks 240 = 112 + 128 against e_ladder.log (elad·1).](figs/f14_e8_roots.svg)

Dropping one frame vector at a time, E_{n−1} = E_n ∩ e_n^⊥, gives the descent of root counts 240 → 126 → 72 → 40 → 20 → 8 (E₈, E₇, E₆, D₅, A₄, A₂ × A₁), and the W(E_n)-orbit of e_n has 6, 10, 16, 27, 56, 240 elements, the vertex counts of the Gosset polytopes (GOS-005; check_T10: "norm-2 vectors = roots: 8, 20, 40, 72, 126, 240"; bd·en·6). In the del Pezzo reading those classes are the exceptional curves of dP_n; that reading is ours (GOS-007). The clock's 8 and the 8 of even unimodular lattices are one fact, a signature mod 8 read through a Gauss sum (MAP-014; core·B13, bd·str·16).

![The E-series in I(1,n) for n = 3 … 8: det = k·k = 9 − n, the number of roots (x·x = −2, k·x = 0) and the number of Gosset vertices (x·x = −1, k·x = 1). Drawn by figs_alg.py, which counts the vectors of I(1,n) and checks the roots against check_T10.log and both counts against en_weyl.log (bd·en·6).](figs/f15_gosset.svg)

**Where the course goes further.** The classification of indefinite unimodular lattices (an odd one is I_{p,q}, an even one a sum of copies of E₈ and of the hyperbolic plane), Rokhlin's theorem and Donaldson's theorem: recalled (J. Milnor and D. Husemoller, *Symmetric Bilinear Forms*; J.-P. Serre, *A Course in Arithmetic*, ch. V; recalled, not in the package). For an odd unimodular lattice that is not I_{p,q}, the form k^⊥/2k^⊥ is the label form of the even part of a cell with the same signature mod 8 for E₈ ⊕ ℤ, checked on all 484 characteristic vectors with k·k ≤ 9 (GOS-006c, lat·9); for the other odd unimodular lattices it is open (GOS-006d).

> **Try it.** In figure f12, compute the inner product of h − e₁ − e₂ − e₃ with e₃ − e₄ in I(1,8), where h·h = +1 and eᵢ·eᵢ = −1: it is +1, a bond. With e₁ − e₂ it is (+1) + (−1) = 0: no bond. Which simple root does k^⊥ lose when you drop e₈?

### B10 · Lie algebras of bivectors; the E-series and McKay

**The course.** A Lie algebra is a vector space with an antisymmetric bracket that satisfies the Jacobi identity; in an associative algebra the commutator [x, y] = xy − yx is one. so(m) is spanned by the m(m − 1)/2 infinitesimal rotations. The irreducible characters of a finite group are an orthonormal basis of its class functions.

**The Atlas's object.** In a cell the bivectors B_ab = eₐe_b (a < b) close under the commutator, and two of them commute or anticommute by the rule: they anticommute exactly when they share one index, and then [B_ab, B_bc] = 2B_ab B_bc = ±2B_ac. YM-001 reads the gauge algebra off the commutator graph: "its index triples {B_ab, B_bc, B_ac} (the triangles closed under the commutator) are so(3) subalgebras. From m = 4 the graph also has open triangles {B_ab, B_ac, B_ad}, which are not subalgebras. Nothing is added to the bit rule."

![The commutator graph of the bivectors. Left, Cl(3,0): three bivectors, one closed triangle, so(3). Right, Cl(4,0): six bivectors, an edge when two anticommute; each bivector commutes only with its complement. Of the eight triangles, four are closed, the index triples (blue, the outer one drawn thick), and four are open, the stars {B_ab, B_ac, B_ad} (orange). Drawn by figs_alg.py with bitcliff.py, which checks the closure by the products.](figs/f16_commutator.svg)

The rule also builds the exceptional Lie algebras. CAND-050: for an even lattice L the Lie algebra 𝔥 ⊕ ⊕ ℝe_α with $[e_\alpha,e_\beta]=\varepsilon(\alpha,\beta)\,e_{\alpha+\beta}$ needs a bimultiplicative sign ε with ε(α,α) = (−1)^(α·α/2), and for E₈ the cocycle is, up to gauge, the sign of Cl(8,0). The check elad·2 builds e₈ from the Cl(8,0) sign carried to E₈/2E₈ and runs the Jacobi identity "on all 248^3 = 15252992 ordered basis triples, exact integers: 1501032 triples carry a non-zero term, 0 fail", with the Killing form 60 times the Cartan matrix. Deleting simple roots of E₈ one at a time gives the algebras of dimension 248, 133, 78, 45, 24, 11 (LNB-016), and the folding of the E₆ diagram, lifted to the bracket, fixes a 52-dimensional f₄ inside e₆ (CAND-082; elad·5).

A finite group enters through the even part of Cl(3,0), the quaternions. Two unit rotors of orders 10 and 6 generate the binary icosahedral group 2I: 120 elements in 9 conjugacy classes of sizes 1, 1, 12, 12, 12, 12, 20, 20, 30 (elad·24, exact over ℚ(√5)). Its McKay graph, with a node for each irreducible representation and an edge when the tensor product with the 2-dimensional one contains the other, is the affine diagram Ẽ₈, and the dimensions of the representations are the marks of its null root (CAND-140; elad·25; elad·26 by a numpy route; controls: the binary octahedral group gives Ẽ₇ and the cyclic group of order 8 gives Ã₇).

![The McKay graph of the binary icosahedral group, rebuilt by figs_alg.py: the 120 rotors from the even part of Cl(3,0) with the bit rule, the nine characters (orthonormal), and the tensor products with χ₂. The graph is affine E₈; each node is labelled by its dimension, and twice a dimension is the sum of the neighbours. The class sizes and dimensions are checked against e_ladder.log (elad·24, elad·25).](figs/f17_mckay.svg)

**Where the course goes further.** The classification of simple Lie algebras by Dynkin diagrams, the Weyl character formula, and the McKay correspondence for every finite subgroup of SU(2): recalled (J. E. Humphreys, *Introduction to Lie Algebras and Representation Theory*; J. McKay, "Graphs, singularities, and finite groups", as CAND-140 cites it; recalled, not in the package). CAND-140 itself keeps the general statement recalled; the Atlas's Atiyah lens lists the families it has not run, the binary tetrahedral and the binary dihedral groups (theme 14).

> **Try it.** Check the McKay rule at the branch node of figure f17: 2 × 6 = 5 + 4 + 3. Then at an end of the long arm: 2 × 1 = 2. Why must Σ dim² = 120?

### Three questions for an algebraist (Part III)

1. GOS-006d (open): for an odd unimodular lattice L that is neither I_{p,q} nor E₈ ⊕ ℤ, is the form k^⊥/2k^⊥ the label form of the even part of the cell (p, q) with p + q = n and p − q ≡ σ(L) mod 8? For E₈ ⊕ ℤ it is (GOS-006c, proved by the Atlas).
2. CAND-050 takes the E₈ cocycle, up to gauge, from the sign of Cl(8,0). Do the other simply-laced algebras take their Frenkel–Kac sign from a cell in the same way, and from which one? Nearest: CAND-050 and the checks elad·1–4 (proved by the Atlas).
3. CAND-140 finds Ẽ₈ as the McKay graph of 2I, and GOS-005 finds E₈ as k^⊥ in the frame lattice of Cl(1,8). Is there a map inside the rule from the one to the other that does not pass through the classification? Our question; the nearest rows are CAND-140 and GOS-005.

## Part IV · Beyond associativity, and the classes

Part IV goes one step beyond a second course twice: to an algebra that is not associative, built on the same labels, and to the classes, Morita and Brauer–Wall, in which the clock lives.

### B11 · Octonions, composition algebras and the Albert algebra

**The course.** A composition algebra has a non-degenerate quadratic norm with N(xy) = N(x)N(y). By Hurwitz's theorem the real ones with a definite norm are ℝ, ℂ, ℍ and the octonions 𝕆, of dimensions 1, 2, 4, 8; they are alternative, x(xy) = (xx)y and (yx)x = y(xx), and 𝕆 is not associative. A Jordan algebra has a commutative product with (x²y)x = x²(yx); the 27-dimensional algebra h₃(𝕆) of hermitian 3 × 3 octonion matrices is the exceptional one, the Albert algebra.

**The Atlas's object: a cochain that fails.** The octonions use the same eight labels and the same shape ±e_(a⊕b), but the sign is not a 2-cocycle. Thm T6 (d): with the Albuquerque–Majid cochain F, dF = (−1)^det(a,b,c), −1 exactly on the 168 = 7·6·4 ordered triples of independent labels (check_T6, OCT); this is the associator of B1 switched on. LNB-002 builds the octonions by three Cayley–Dickson doublings: "every product of two units is ±1 times the unit at the XOR of the labels, and every non-zero label squares to −1; the associator sign is −1 exactly on the 168 = 7·6·4 ordered triples independent over 𝔽₂. The sign of Cl(0,3) on the same labels is associative and differs at e₁₁₁² and on 15 of the 42 products of distinct non-zero labels." The figure script recomputes the 168 and the 15 with the Cayley–Dickson product of composition_basis.py.

![Octonions on the eight labels. Left: the seven lines {a, b, a ⊕ b} of the plane over 𝔽₂ (three sides, three medians, the circle), each oriented by the octonion table: along the arrows e_a e_b = +e_c. Right: the sign of e_a e_b in 𝕆, outlined where it differs from the sign of Cl(0,3): 15 of the 42 products of distinct labels and e₁₂₃². Drawn by figs_alg.py with the Cayley–Dickson product of checks/selfcheck/proofs/composition_basis.py, which also checks the associator (−1)^det on all 512 triples.](figs/f07_octonions.svg)

Among the ±1 sign cochains on the eight labels the octonions are the only real division algebra, "one gauge orbit of 16 presentations" (LNB-018; bd·alg·21–22); over a finite field no sign cochain on n ≥ 2 labels gives a division algebra (dictionary D41). The split and null octonions are the doublings with μ = +1 and 0, one family on the labels, the doubling bit behaving as a generator of square −1, +1, 0 (dictionary D42, marked new by the Atlas; bd·alg·16). The automorphisms of 𝕆 that permute the basis lines number 1344 = 8 × 168, a non-split extension 2³·GL(3,2) (bd·alg·15).

Composition algebras are CAND-070. composition_basis.log checks in exact integers that the Cayley–Dickson algebras of dimension 1, 2, 4, 8 are composition algebras — N(xy) = N(x)N(y) on all basis pairs and, by polarisation, for all x, y — with an alternating associator, while the sedenions of dimension 16 fail: "N(xy) != N(x)N(y) on 672 of 65536 pairs of two-term sums, a zero divisor", and 1008 basis conditions of alternativity fail. The split octonions are Zorn's vector matrices; on the labels of Λℝ³ every non-zero product of two labels is ± the join (disjoint labels) or the meet (labels covering the three bits) (composition_basis.log), and the complement of a label with the sign (−1)^(k(k+1)/2) on grade k is an automorphism of the Zorn algebra (LNB-019).

**The Albert algebra.** h₃(𝕆) has 27 = 3 + 3 × 8 real coordinates. LNB-021: "The 27-dimensional space of hermitian 3 × 3 matrices over the XOR octonions, with (xy + yx)/2, satisfies the Jordan identity (random pairs; numerical) and has the Peirce split 27 = 1 + 16 + 10 for the idempotent e₁; its derivations form a 52-dimensional algebra, f₄." The check elad·21 finds the nullity 52 exactly, and the 36 derivations that keep h₂(𝕆) act faithfully as so(9); the Peirce ½ space of e₃, of dimension 16, is the real spinor module of Spin(9), built by the bit rule in Cl(9,0) (CAND-023; elad·22). The Jordan data (r, a, b) = (3, 8, 0) of the Albert triple give dim = r + a·r(r−1)/2 + b·r = 27 (LNB-004; the multiplicities recalled from Loos, an input, INP-082).

![The Albert algebra h₃(𝕆): three real diagonal entries and three octonions, 27 = 3 + 3 × 8. The colours are the Peirce spaces of e₁ = diag(1, 0, 0), eigenvalues 1, ½, 0 of X ↦ e₁ ∘ X with dimensions 1, 16, 10. Drawn by figs_alg.py, which computes the eigenvalues with the Cayley–Dickson octonions on the labels; the numbers at the right (52, 36, 16) are read from e_ladder.log (elad·21).](figs/f18_albert.svg)

**Where the course goes further.** Hurwitz's theorem itself, the classification of formally real Jordan algebras by Jordan, von Neumann and Wigner, the exceptional groups G₂ = Aut 𝕆 and F₄ = Aut h₃(𝕆): recalled (T. A. Springer and F. D. Veldkamp, *Octonions, Jordan Algebras and Exceptional Groups*; R. D. Schafer, *An Introduction to Nonassociative Algebras*; J. C. Baez, "The Octonions"; recalled, not in the package). The octonion table of the Baez papers and their embeddings are imported into the Atlas, an input (INP-082).

> **Try it.** Pick a line of figure f07, read eₐe_b along its arrows in the table at the right, then against them: the sign flips, as for i, j, k in ℍ. Then take three labels not on one line, such as e₁, e₂, e₃, and check in the table that (e₁e₂)e₃ = −e₁(e₂e₃).

### B12 · Extensions, Brauer–Wall, Morita, Azumaya, Hochschild

**The course.** Extensions of a group G by an abelian group A with a given action are classified by H²(G, A) (Schreier). The Brauer group of a field classifies central simple algebras up to Morita equivalence, with the tensor product as the law; Br(ℝ) = ℤ₂. Its graded version, the Brauer–Wall group BW(F), classifies graded central simple algebras, and BW(ℝ) ≅ ℤ/8. An algebra A over a commutative ring R is Azumaya when A ⊗ A^op → End_R(A) is an isomorphism. Hochschild cohomology measures derivations (HH¹) and deformations (HH²).

**The Atlas's objects.** H² is the home of the sign (B2): the signed blades are an extension of ℤ₂ⁿ by ±1, and the algebra lens names Q(a) = [eₐ² = −1] the quadratic map of that extension, a complete invariant of its class (the dictionary's entry for Q; LAB-009 computes Q and O(Q) for every class). The clock is the Brauer–Wall class of Cl(p,q), with the generator Cl(1,0) ↦ 1; the graded tensor product of B4 is the group law, which is why the clock adds (dictionary D07; LNC-117; cat·K4a). Doubling is the graded Azumaya property: left multiplications and twisted right multiplications of Cl(V) generate Cl(n,n), so Cl(V) ⊗̂ Cl(−V) = End Cl(V) as algebras (core·B10, every non-degenerate Cl(p,q) with n ≤ 4; dictionary D16). With null generators the class is that of the quotient Cl(p,q) (D10; B5).

LNC-055 says what r is: "Nor is r a second coordinate of the class: over its super-centre Λ(ℝ^{r}) the cell is graded Azumaya, and its graded Hochschild groups HH¹ and HH² relative to Λ(ℝ^{r}) vanish (r = 1 with p + q ≤ 3 and r = 2 with p + q ≤ 2; for r = 1 and p + q ≤ 3 every free graded Λ(ℝ)-algebra with fibre Cl(p,q) is Cl(p,q,1), computed from first principles), so r is the base ring; for every (p,q,r) this follows from the separability of Cl(p,q) (pointer, source unread). Over ℝ the graded Morita classes of the cells form the monoid ℤ₈ × ℕ, (clock, r), with no inverse for r ≥ 1." A Morita context appears once more, in the dictionary: fibre and base of a bundle, with the identity bimodule and the commutant chain a double centraliser, the connection being an input (D48).

Gradings close the course. Among the gradings in which every label is homogeneous, the universal grading group is ℤ₂^(p+q) × ℤʳ; for arbitrary gradings the rank can be larger, since M₂(ℝ) = Cl(2,0) carries a ℤ-grading by matrix units (Thm T2 (6)). Whether the universal grading group for arbitrary gradings is known, torsion part included, is open (LNC-085).

**The honest scope.** Computed: H² of ℤ₂ⁿ with 𝔽₂ values for n ≤ 4 as linear systems (cat·K2a) and as the quadratic forms for every n (Thm T6 (c)); the clock as the class of every cell, with the eight graded pairs (cat·C1); the doubling for n ≤ 4 (core·B10); HH¹ and HH² in the small ranges of LNC-055. Pointers, with the source unread: the separability of Cl(p,q), hence the vanishing for every (p,q,r); Schreier's theorem; the Brauer–Wall group of ℝ as a group of all graded central simple algebras (Wall). Open: the grading group (LNC-085) and a cohomology of the contracted monoid (LNC-086).

**Where the course goes further.** The Brauer group of a commutative ring, Galois descent, the Hochschild–Kostant–Rosenberg theorem. Recalled: C. T. C. Wall, "Graded Brauer groups"; T. Y. Lam, *Introduction to Quadratic Forms over Fields*; M. Auslander and O. Goldman, "The Brauer group of a commutative ring"; C. A. Weibel, *An Introduction to Homological Algebra*, ch. 9 (recalled, not in the package).

> **Try it.** In the clock widget take Cl(1,0) and Cl(0,1): their clocks are 1 and 7, and 1 + 7 ≡ 0 mod 8. Then take Cl(1,1): clock 0, type M₂(ℝ). A class times its inverse is a matrix algebra: the Brauer–Wall law on the cells.

### Three questions for an algebraist (Part IV)

1. The dictionary (D41) reads: the octonions are the only sign-cochain division algebra on 8 labels over ℝ, and over a finite field there is none for n ≥ 2. Is that known, and in which form? The nearest rows are LNB-018 and Thm T6 (d), proved by the Atlas on the finite statements and reduced to Hurwitz's theorem for the identification with 𝕆.
2. LNC-055: Cl(p,q,r) is graded Azumaya over Λ(ℝʳ) with vanishing graded HH¹ and HH² (computed for p + q ≤ 3, r ≤ 2), and for every (p,q,r) by separability, a pointer. Is that known, or trivial?
3. LNC-085 (open): is the universal grading group of Cl(p,q,r) for arbitrary gradings known, torsion part included?

## Closing table · one object, three languages

| The course's name | The Atlas's name | Row and its status |
|---|---|---|
| elementary abelian group ℤ₂ⁿ | the labels, multiplied by XOR | ATL-001, PAG-002b (proved by the Atlas; the cube drawing is our reading) |
| associative algebra of dimension 2ⁿ | the cell Cl(p,q,r), the bit rule | Thm T1 (proved) |
| quadratic form over 𝔽₂ and ℤ₄ | Q, π and w = π + 2Q | LAB-019 (proved by the Atlas) |
| 2-cocycle, coboundary, twisted group algebra | the sign s, the gauge | Thm T6 (reduced); LAB-009 (proved by the Atlas) |
| Wedderburn type k·M_N(D) | the clock and the type table | ATL-023, GEN-009, CAND-116 (proved by the Atlas) |
| Gauss sum, Brown invariant | the clock's phase | LAB-017, RSN-029 (proved by the Atlas) |
| graded tensor product, Koszul sign | concatenating labels | LNC-117 (proved by the Atlas) |
| periodicity of real Clifford algebras | the Bott repeat at row 8 | ATL-020, ATL-023, GEN-009 (proved by the Atlas) |
| exterior algebra, Jacobson radical | the labels with a null bit | Thm T2 (proved); LNC-086 (open) |
| Frobenius algebra, Nakayama automorphism | the top-label form | LNC-028, LNC-111, LNC-004, LNC-030 (proved by the Atlas) |
| trace form | the scalar part ⟨x⟩₀ | LNC-060 (proved by the Atlas, its reading ours) |
| commutative Frobenius algebra, 2D TQFT | Λ(ℝʳ) | LNB-025c (proved by the Atlas); LNB-025d (our reading) |
| minimal left ideal, primitive idempotent | commuting labels of square +1 | LNC-059, CAND-069, CPL-007b (proved by the Atlas) |
| K-theory of a point | the 72 graded cokernels | ATY-001 (proved by the Atlas); LAB-018 (proved by the Atlas, KO a pointer) |
| integral lattice, signature mod 8 | the frame lattice I_{p,q} | ATY-016, LAB-018 (proved by the Atlas) |
| E₈ and its roots | k^⊥ in I_{1,8}; 112 + 128 | GOS-005, SHP-006 (proved by the Atlas); GOS-007 (its del Pezzo reading ours); GOS-006c (proved by the Atlas for E₈ ⊕ ℤ); GOS-006d (open) |
| Lie algebra so(m), structure constants | the commutator graph of bivectors | YM-001 (proved by the Atlas) |
| exceptional Lie algebras e₈, f₄ | the Cl(8,0) sign on E₈/2E₈; the folding of e₆ | CAND-050, CAND-082 (proved by the Atlas) |
| McKay correspondence | 2I in the even part of Cl(3,0) | CAND-140 (proved by the Atlas) |
| octonions, alternative algebra | the cochain that fails | LNB-002, LNB-018 (proved by the Atlas) |
| composition algebras, Hurwitz | Cayley–Dickson on the labels | CAND-070, LNB-019 (proved by the Atlas) |
| exceptional Jordan algebra | h₃(𝕆) on the labels | LNB-021, LNB-004, CAND-023 (proved by the Atlas); INP-082 (input) |
| Brauer–Wall group, Azumaya, Hochschild | the clock as a class; doubling; r as the base ring | LNC-055 (proved by the Atlas) |
| universal grading group | the label grading | LNC-085 (open) |

The statuses are those of the Atlas's register: a row id above links to its page, with the status in its frame. The theorems T1–T20 are the Atlas's researcher theorems (content/theorems.json): T1, T2, T3, T5, T10, T11 have the status *proved*; T4 and T6 the status *reduced*, each with a part proved inside the rule and a part reduced to a recalled theorem (Wall's Brauer–Wall group for T4, Hurwitz's theorem for T6 (d)).

## Sources, and how far each was read

**The rows of the Atlas** (read in full, with their status, by `node tools/proofs_todo.mjs --row ID`): ATL-001, ATL-020, ATL-023, GEN-009, PAG-002b, LAB-009, LAB-017, LAB-018, LAB-019, RSN-029, CAND-023, CAND-024, CAND-050, CAND-069, CAND-070, CAND-082, CAND-116, CAND-140, CPL-007b, LNC-004, LNC-028, LNC-030, LNC-055, LNC-059, LNC-060, LNC-085, LNC-086, LNC-111, LNC-117, LNS-015, ATY-001, ATY-016, GOS-005, GOS-006c, GOS-007, SHP-006, MAP-014, YM-001, LNB-002, LNB-004, LNB-016, LNB-018, LNB-019, LNB-021, LNB-025c, LNB-025d, INP-082. The theorems T1–T6, T10, T11 of content/theorems.json (statements and status notes). The algebra lens dictionary (content/lenses.json, key `alg`; the entries D01–D67 quoted by their number).

**The checks and their logs**: checks/selfcheck/proofs/logs/solid_cube.log (solid.K1–K6), aty_twisted_k.log (aty.A1–A6), e_ladder.log (elad·1, 2, 5, 21–26), composition_basis.log (all of it); checks/selfcheck/gravity/logs/aty_matter_models.log (parts L1–L4); checks/selfcheck/proofs/logs/reruns/: cat_check.log (cat·S1, K2a, K4a, K4c, K5a, K5c, F1, C1, C2), core_check.log (core·B1–B3, B10, B10c, B13), check_T6.log (SQ, H1, KZ, H2, OCT), check_T10.log (1, 6, 7), en_weyl.log (bd·en·6), alg_octonion.log (bd·alg·14–17, 21, 22, 24), lens_sch_check.compare.log (scw·P1c); dirac_limits.log (dlim·MOD). Every figure is drawn by figs_alg.py, which imports the rule from checks/selfcheck/steps15_17/bitcliff.py and the octonions from checks/selfcheck/proofs/composition_basis.py, reads the logs above, and stops if a recomputed number disagrees with its log or row.

**The pages of the Atlas**: `#/rule`, `#/cells`, `#/clock`, `#/shapes`, `#/steps/groups`, `#/steps/category`, `#/steps/baez`, `#/steps/ym`, `#/steps/coupling`, `#/steps/schuller`, `#/logbook`; the reports reports/analyses/reading_algebra.html (the algebraist's reading of the Atlas: its summary and breaks read) and reports/analyses/atiyah_lens.html (section 5, themes 1, 2, 11 and 14 read).

**The shipped tutorial**: public/reports/html/bit_rule_tutorial.html, Part 0 and Part B (B1 to B9 and its three questions) read in full; this tutorial keeps their order (B1, B2 → B1; B3, B4 → B2; B5 → B3; B6 → B4; B7 → B5; B8 → B11; B9 → B12) and their sources as the shipped tutorial records them.

**Textbooks and papers, recalled** (none of them is in the package's second source): D. S. Dummit and R. M. Foote, *Abstract Algebra*; K. S. Brown, *Cohomology of Groups*; H. B. Lawson and M.-L. Michelsohn, *Spin Geometry*; P. Lounesto, *Clifford Algebras and Spinors*; K. Wernli, *Lecture Notes on Spin Geometry*; T. Y. Lam, *Introduction to Quadratic Forms over Fields*; R. S. Pierce, *Associative Algebras*; J. Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories*; M. F. Atiyah, R. Bott and A. Shapiro, "Clifford modules"; J. Milnor and D. Husemoller, *Symmetric Bilinear Forms*; J.-P. Serre, *A Course in Arithmetic*; J. E. Humphreys, *Introduction to Lie Algebras and Representation Theory*; J. McKay, "Graphs, singularities, and finite groups"; T. A. Springer and F. D. Veldkamp, *Octonions, Jordan Algebras and Exceptional Groups*; R. D. Schafer, *An Introduction to Nonassociative Algebras*; J. C. Baez, "The Octonions"; C. T. C. Wall, "Graded Brauer groups"; M. Auslander and O. Goldman, "The Brauer group of a commutative ring"; C. A. Weibel, *An Introduction to Homological Algebra*.
