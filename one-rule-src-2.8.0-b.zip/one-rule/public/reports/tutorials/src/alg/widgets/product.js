(function (id) {
  // product.js: the product of two labels by the bit rule, with the sign steps shown. No library, no network.
  var el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  function popcount(x) { var c = 0; while (x) { x &= x - 1; c++; } return c; }
  function nPairs(a, b) { var c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  function reorderSign(a, b) { return nPairs(a, b) & 1 ? -1 : 1; }
  function sign(a, b, eps) { var v = reorderSign(a, b), m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  // self-test: ten products and the sign counts of the three n = 2 tables of Part 0 (the shipped tutorial; scw·P1c)
  var STORED = [[[1, 1], 2, 1, -1, 3], [[1, 1], 3, 3, -1, 0], [[1, 1], 3, 1, -1, 2], [[1, 1], 1, 3, 1, 2], [[-1, -1], 1, 1, -1, 0],
    [[-1, -1], 1, 3, -1, 2], [[-1, -1], 2, 3, 1, 1], [[-1, -1], 3, 2, -1, 1], [[0, 0], 1, 1, 0, 0], [[0, 0], 2, 1, -1, 3]];
  var COUNTS = [[[1, 1], 4, 0], [[-1, -1], 6, 0], [[0, 0], 1, 7]];
  var ok = STORED.every(function (t) { return sign(t[1], t[2], t[0]) === t[3] && (t[1] ^ t[2]) === t[4]; });
  COUNTS.forEach(function (t) {
    var neg = 0, zer = 0;
    for (var a = 0; a < 4; a++) for (var b = 0; b < 4; b++) { var s = sign(a, b, t[0]); if (s === -1) neg++; if (s === 0) zer++; }
    if (neg !== t[1] || zer !== t[2]) ok = false;
  });
  if (!ok) { el.textContent = 'self-test failed'; return; }

  var SUB = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'];
  function name(a) { if (!a) return '1'; var s = 'e'; for (var i = 0; i < 10; i++) if ((a >> i) & 1) s += SUB[i + 1]; return s; }
  function bits(a, n) { var s = ''; for (var i = 0; i < n; i++) s += (a >> i) & 1; return s; }
  function sq(e) { return e === 1 ? '+1' : (e === -1 ? '−1' : '0'); }
  var st = { n: 3, eps: [1, 1, -1, 1, 1, 1], a: 5, b: 6 };

  el.innerHTML = '<div class="pw-row"><span class="pw-l">n</span> <button type="button" data-k="n-">−</button> <b class="pw-n"></b> <button type="button" data-k="n+">+</button></div>' +
    '<div class="pw-row"><span class="pw-l">squares</span> <span class="pw-eps"></span></div>' +
    '<div class="pw-row"><span class="pw-l">label a</span> <span class="pw-a"></span></div>' +
    '<div class="pw-row"><span class="pw-l">label b</span> <span class="pw-b"></span></div>' +
    '<p class="widget__out" aria-live="polite"></p>';
  var css = document.createElement('style');
  css.textContent = '#' + id + ' .pw-row{margin:4px 0;display:flex;flex-wrap:wrap;gap:4px;align-items:center}#' + id + ' .pw-l{display:inline-block;min-width:4.6em;font-size:14px;color:var(--ink2)}' +
    '#' + id + ' .pw-n{display:inline-block;min-width:1.4em;text-align:center}';
  el.appendChild(css);
  var out = el.querySelector('.widget__out');

  function buttons(box, kind) {
    box.innerHTML = '';
    for (var i = 0; i < st.n; i++) {
      var bt = document.createElement('button'); bt.type = 'button'; bt.setAttribute('data-k', kind + i);
      if (kind === 'e') { bt.textContent = name(1 << i) + ' ' + sq(st.eps[i]); bt.setAttribute('aria-label', 'square of ' + name(1 << i) + ': ' + sq(st.eps[i]) + '; click to change'); }
      else { var on = (st[kind] >> i) & 1; bt.textContent = name(1 << i); bt.setAttribute('aria-pressed', on ? 'true' : 'false'); }
      box.appendChild(bt);
    }
  }
  function show() {
    var n = st.n, eps = st.eps.slice(0, n), a = st.a & ((1 << n) - 1), b = st.b & ((1 << n) - 1);
    el.querySelector('.pw-n').textContent = n;
    buttons(el.querySelector('.pw-eps'), 'e'); buttons(el.querySelector('.pw-a'), 'a'); buttons(el.querySelector('.pw-b'), 'b');
    var c = a ^ b, swaps = [], i, j;
    for (i = 0; i < n; i++) if ((a >> i) & 1) for (j = 0; j < i; j++) if ((b >> j) & 1) swaps.push('(' + (i + 1) + ',' + (j + 1) + ')');
    var rs = swaps.length % 2 ? -1 : 1, shared = a & b, sqs = [], f = 1;
    for (i = 0; i < n; i++) if ((shared >> i) & 1) { sqs.push('ε' + SUB[i + 1] + ' = ' + sq(eps[i])); f *= eps[i]; }
    var s = sign(a, b, eps), t = sign(b, a, eps);
    var L = [];
    L.push('a = ' + name(a) + ' (bits ' + bits(a, n) + '), b = ' + name(b) + ' (bits ' + bits(b, n) + '), bits read e₁ to e' + SUB[n]);
    L.push('1. label:  a ⊕ b = ' + bits(c, n) + '  →  ' + name(c));
    L.push('2. swaps:  pairs (i in a, j in b, j < i): ' + (swaps.length ? swaps.join(' ') : 'none') + '  →  (−1)^' + swaps.length + ' = ' + (rs > 0 ? '+1' : '−1'));
    L.push('3. squares: a ∧ b = ' + (shared ? name(shared) : 'empty') + (sqs.length ? ': ' + sqs.join(', ') + '  →  ' + sq(f) : '  →  +1'));
    L.push('4. sign:   s(a,b) = ' + (rs > 0 ? '+1' : '−1') + ' · ' + sq(f) + ' = ' + sq(s));
    L.push('');
    L.push('e_a e_b = ' + (s === 0 ? '0' : (s > 0 ? '+' : '−') + name(c)) + ';   e_b e_a = ' + (t === 0 ? '0' : (t > 0 ? '+' : '−') + name(c)) +
      (s === 0 ? '' : (s === t ? ': they commute' : ': they anticommute')));
    out.textContent = L.join('\n');
  }
  el.addEventListener('click', function (ev) {
    var k = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-k'); if (!k) return;
    if (k === 'n-') st.n = Math.max(1, st.n - 1);
    else if (k === 'n+') st.n = Math.min(6, st.n + 1);
    else { var i = +k.slice(1), kind = k[0];
      if (kind === 'e') st.eps[i] = st.eps[i] === 1 ? -1 : (st.eps[i] === -1 ? 0 : 1);
      else st[kind] ^= 1 << i; }
    show();
  });
  show();
})
