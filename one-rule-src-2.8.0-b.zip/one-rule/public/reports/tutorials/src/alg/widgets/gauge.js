(function (id) {
  // gauge.js: a gauge e_a -> f(a) e_a multiplies the sign by the coboundary f(a) f(b) f(a xor b); the squares and the commutation signs stay.
  var el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  function popcount(x) { var c = 0; while (x) { x &= x - 1; c++; } return c; }
  function nPairs(a, b) { var c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  function reorderSign(a, b) { return nPairs(a, b) & 1 ? -1 : 1; }
  function sign(a, b, eps) { var v = reorderSign(a, b), m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  function table(eps, f) {
    var N = 1 << eps.length, T = [];
    for (var a = 0; a < N; a++) { T.push([]); for (var b = 0; b < N; b++) T[a].push(sign(a, b, eps) * f[a] * f[b] * f[a ^ b]); }
    return T;
  }
  // self-test: ten products of Part 0 (the shipped tutorial), and the number of figure f03: the gauge e12 -> -e12 changes 6 of the 16 signs of Cl(2,0)
  var STORED = [[[1, 1], 2, 1, -1], [[1, 1], 3, 3, -1], [[1, 1], 3, 1, -1], [[1, 1], 1, 3, 1], [[-1, -1], 1, 1, -1],
    [[-1, -1], 1, 3, -1], [[-1, -1], 2, 3, 1], [[-1, -1], 3, 2, -1], [[0, 0], 1, 1, 0], [[0, 0], 2, 1, -1]];
  var ok = STORED.every(function (t) { return sign(t[1], t[2], t[0]) === t[3]; });
  var T0 = table([1, 1], [1, 1, 1, 1]), T1 = table([1, 1], [1, 1, 1, -1]), ch = 0;
  for (var a = 0; a < 4; a++) for (var b = 0; b < 4; b++) if (T0[a][b] !== T1[a][b]) ch++;
  if (!ok || ch !== 6) { el.textContent = 'self-test failed'; return; }

  var SUB = ['₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'];
  function name(a) { if (!a) return '1'; var s = 'e'; for (var i = 0; i < 9; i++) if ((a >> i) & 1) s += SUB[i + 1]; return s; }
  function sq(e) { return e === 1 ? '+1' : (e === -1 ? '−1' : '0'); }
  var st = { n: 2, eps: [1, 1, 1], f: [1, 1, 1, -1, 1, 1, 1, 1] };
  el.innerHTML = '<div class="gw-row"><span class="gw-l">n</span> <button type="button" data-k="n2">2</button> <button type="button" data-k="n3">3</button></div>' +
    '<div class="gw-row"><span class="gw-l">squares</span> <span class="gw-eps"></span></div>' +
    '<div class="gw-row"><span class="gw-l">gauge f</span> <span class="gw-f"></span></div>' +
    '<div class="gw-t"></div><p class="widget__out" aria-live="polite"></p>';
  var css = document.createElement('style');
  css.textContent = '#' + id + ' .gw-row{margin:4px 0;display:flex;flex-wrap:wrap;gap:4px;align-items:center}#' + id + ' .gw-l{display:inline-block;min-width:4.6em;font-size:14px;color:var(--ink2)}' +
    '#' + id + ' table{border-collapse:separate;border-spacing:2px;margin:6px 0;font-size:13px}#' + id + ' td,#' + id + ' th{min-width:0;width:30px;height:24px;padding:0;text-align:center;border:0;border-radius:4px}' +
    '#' + id + ' th{font-weight:500;color:var(--ink2);font-size:11px}#' + id + ' td.p{background:rgba(42,120,214,.24)}#' + id + ' td.m{background:rgba(235,104,52,.36)}#' + id + ' td.z{background:var(--tint)}' +
    '#' + id + ' td.c{outline:2px solid var(--ink);outline-offset:-2px}';
  el.appendChild(css);
  var out = el.querySelector('.widget__out');
  function show() {
    var n = st.n, N = 1 << n, eps = st.eps.slice(0, n), f = st.f.slice(0, N), one = [], i, a, b;
    for (i = 0; i < N; i++) one.push(1);
    var T = table(eps, one), G = table(eps, f);
    el.querySelectorAll('[data-k^="n"]').forEach(function (bt) { bt.setAttribute('aria-pressed', bt.getAttribute('data-k') === 'n' + n ? 'true' : 'false'); });
    var e = el.querySelector('.gw-eps'); e.innerHTML = '';
    for (i = 0; i < n; i++) { var bt = document.createElement('button'); bt.type = 'button'; bt.setAttribute('data-k', 'e' + i); bt.textContent = name(1 << i) + ' ' + sq(eps[i]); e.appendChild(bt); }
    var g = el.querySelector('.gw-f'); g.innerHTML = '';
    for (a = 1; a < N; a++) { var b2 = document.createElement('button'); b2.type = 'button'; b2.setAttribute('data-k', 'f' + a); b2.textContent = (f[a] > 0 ? '+' : '−') + name(a); b2.setAttribute('aria-pressed', f[a] < 0 ? 'true' : 'false'); g.appendChild(b2); }
    var h = '<table><tr><th></th>';
    for (b = 0; b < N; b++) h += '<th>' + name(b) + '</th>';
    h += '</tr>';
    var changed = 0, sqOK = true, cmOK = true;
    for (a = 0; a < N; a++) {
      h += '<tr><th>' + name(a) + '</th>';
      for (b = 0; b < N; b++) {
        var v = G[a][b], c = v !== T[a][b];
        if (c) changed++;
        if (a === b && v !== T[a][b]) sqOK = false;
        if (G[a][b] * G[b][a] !== T[a][b] * T[b][a]) cmOK = false;
        h += '<td class="' + (v > 0 ? 'p' : (v < 0 ? 'm' : 'z')) + (c ? ' c' : '') + '">' + (v > 0 ? '+' : (v < 0 ? '−' : '0')) + '</td>';
      }
      h += '</tr>';
    }
    el.querySelector('.gw-t').innerHTML = h + '</table>';
    var flipped = []; for (a = 1; a < N; a++) if (f[a] < 0) flipped.push(name(a));
    out.textContent = 'the signs of e_a e_b after e_a ↦ f(a) e_a (' + (flipped.length ? flipped.join(', ') + ' ↦ minus itself' : 'no label flipped') + ')\n' +
      'changed (outlined): ' + changed + ' of ' + N * N + ' entries\n' +
      'squares e_a²: ' + (sqOK ? 'all unchanged' : 'CHANGED') + ';  commutation signs: ' + (cmOK ? 'all unchanged' : 'CHANGED') + '\n' +
      'there are 2^' + (N - 1) + ' = ' + Math.pow(2, N - 1) + ' gauges at n = ' + n + '; none changes the algebra';
  }
  el.addEventListener('click', function (ev) {
    var k = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-k'); if (!k) return;
    if (k === 'n2') st.n = 2; else if (k === 'n3') st.n = 3;
    else if (k[0] === 'e') { var i = +k.slice(1); st.eps[i] = st.eps[i] === 1 ? -1 : (st.eps[i] === -1 ? 0 : 1); }
    else if (k[0] === 'f') { var a = +k.slice(1); st.f[a] = -st.f[a]; }
    show();
  });
  show();
})
