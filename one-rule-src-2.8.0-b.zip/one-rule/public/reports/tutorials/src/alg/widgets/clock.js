(function (id) {
  // clock.js: a cell Cl(p,q) → its clock, its type read from the labels, the minimal module, the commutant and the Gauss sum.
  var el = document.getElementById(id); if (!el) return;
  // the bit rule, as engines/bitrule.js
  function popcount(x) { var c = 0; while (x) { x &= x - 1; c++; } return c; }
  function nPairs(a, b) { var c = 0, i = 0; while (a >> i) { if ((a >> i) & 1) c += popcount(b & ((1 << i) - 1)); i++; } return c; }
  function reorderSign(a, b) { return nPairs(a, b) & 1 ? -1 : 1; }
  function sign(a, b, eps) { var v = reorderSign(a, b), m = a & b, i = 0; while (m) { if (m & 1) { v *= eps[i]; if (v === 0) return 0; } m >>= 1; i++; } return v; }
  function cell(p, q) { var e = []; for (var i = 0; i < p; i++) e.push(1); for (i = 0; i < q; i++) e.push(-1); return e; }

  // everything is read from the labels: the Gauss sum S, nu = sum of the squares (T4 (iii), (iv)), the square of the top label
  function read(p, q) {
    var eps = cell(p, q), n = p + q, N = 1 << n, re = 0, im = 0, nu = 0, a;
    var IP = [[1, 0], [0, 1], [-1, 0], [0, -1]];
    for (a = 0; a < N; a++) {
      var s = sign(a, a, eps); nu += s;
      var w = ((popcount(a) & 1) + (s === -1 ? 2 : 0)) % 4;      // w = parity + 2Q
      re += IP[w][0]; im += IP[w][1];
    }
    var top = sign(N - 1, N - 1, eps);
    var D = nu > 0 ? 'R' : (nu === 0 ? 'C' : 'H'), dimD = { R: 1, C: 2, H: 4 }[D];
    var k = (n % 2 === 1 && top === 1) ? 2 : 1;                   // the top label is central for n odd; square +1 splits the algebra
    var Nm = Math.round(Math.sqrt(N / (k * dimD)));
    return { n: n, c: ((p - q) % 8 + 8) % 8, re: re, im: im, nu: nu, top: top, D: D, dimD: dimD, k: k, N: Nm, module: Nm * dimD };
  }
  // the closed form (1+i)^p (1-i)^q
  function closed(p, q) { var r = 1, i = 0, t, j; for (j = 0; j < p; j++) { t = r - i; i = r + i; r = t; } for (j = 0; j < q; j++) { t = r + i; i = i - r; r = t; } return [r, i]; }
  // the pairs (type of Cl(p,q), type of its even part) by the clock, as cat_check.log (cat·C1) prints them
  var PAIRS = ['R/R2', 'R2/R', 'R/C', 'C/H', 'H/H2', 'H2/H', 'H/C', 'C/R'];
  // self-test: the 36 cells of solid_cube.log (solid.K1): p, q, module dimension, commutant dimension, simple summands
  var K1 = [[0,0,1,1,1],[1,0,1,1,2],[0,1,2,2,1],[2,0,2,1,1],[1,1,2,1,1],[0,2,4,4,1],[3,0,4,2,1],[2,1,2,1,2],[1,2,4,2,1],[0,3,4,4,2],
    [4,0,8,4,1],[3,1,4,1,1],[2,2,4,1,1],[1,3,8,4,1],[0,4,8,4,1],[5,0,8,4,2],[4,1,8,2,1],[3,2,4,1,2],[2,3,8,2,1],[1,4,8,4,2],[0,5,8,2,1],
    [6,0,16,4,1],[5,1,16,4,1],[4,2,8,1,1],[3,3,8,1,1],[2,4,16,4,1],[1,5,16,4,1],[0,6,8,1,1],[7,0,16,2,1],[6,1,16,4,2],[5,2,16,2,1],
    [4,3,8,1,2],[3,4,16,2,1],[2,5,16,4,2],[1,6,16,2,1],[0,7,8,1,2]];
  var ok = K1.length === 36 && K1.every(function (t) {
    var r = read(t[0], t[1]), cl = closed(t[0], t[1]), pr = PAIRS[r.c].split('/')[0];
    var ind = { R: 1, C: 0, H: -2 }[r.D];
    return r.module === t[2] && r.dimD === t[3] && r.k === t[4] && r.re === cl[0] && r.im === cl[1] && pr[0] === r.D && (pr.length === 2) === (r.k === 2) &&
      r.nu === r.k * r.N * ind && r.k * r.N * r.N * r.dimD === (1 << r.n);
  });
  if (!ok) { el.textContent = 'self-test failed'; return; }

  var SYM = { R: 'ℝ', C: 'ℂ', H: 'ℍ' }, SUPS = ['⁰', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹', '¹⁰'];
  function tname(t) { return t.length === 2 ? SYM[t[0]] + ' ⊕ ' + SYM[t[0]] : SYM[t]; }
  var st = { p: 1, q: 3 };
  el.innerHTML = '<div class="cw-row"><span class="cw-l">p (square +1)</span> <button type="button" data-k="p-">−</button> <b class="cw-p"></b> <button type="button" data-k="p+">+</button></div>' +
    '<div class="cw-row"><span class="cw-l">q (square −1)</span> <button type="button" data-k="q-">−</button> <b class="cw-q"></b> <button type="button" data-k="q+">+</button></div>' +
    '<div class="cw-wrap"><svg class="cw-dial" viewBox="0 0 120 120" width="120" height="120" aria-hidden="true"></svg><p class="widget__out" aria-live="polite"></p></div>';
  var css = document.createElement('style');
  css.textContent = '#' + id + ' .cw-row{margin:4px 0;display:flex;align-items:center;gap:4px}#' + id + ' .cw-l{display:inline-block;min-width:8em;font-size:14px;color:var(--ink2)}' +
    '#' + id + ' .cw-p,#' + id + ' .cw-q{display:inline-block;min-width:1.4em;text-align:center}#' + id + ' .cw-wrap{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-start}' +
    '#' + id + ' .cw-dial text{font:10px system-ui,sans-serif;fill:var(--muted)}#' + id + ' .cw-wrap .widget__out{flex:1 1 220px;margin-top:2px}';
  el.appendChild(css);
  var out = el.querySelector('.widget__out'), dial = el.querySelector('.cw-dial');
  function drawDial(r) {
    var s = '<circle cx="60" cy="60" r="44" fill="none" stroke="var(--line2)"/>';
    for (var c = 0; c < 8; c++) {
      var a = c * Math.PI / 4, x = 60 + 54 * Math.cos(a), y = 60 - 54 * Math.sin(a);
      s += '<text x="' + x.toFixed(1) + '" y="' + (y + 3.5).toFixed(1) + '" text-anchor="middle">' + c + '</text>';
    }
    var ang = Math.atan2(r.im, r.re), X = 60 + 40 * Math.cos(ang), Y = 60 - 40 * Math.sin(ang);
    s += '<line x1="60" y1="60" x2="' + X.toFixed(1) + '" y2="' + Y.toFixed(1) + '" stroke="var(--acc)" stroke-width="3" stroke-linecap="round"/><circle cx="60" cy="60" r="3" fill="var(--acc)"/>';
    dial.innerHTML = s;
  }
  function show() {
    var p = st.p, q = st.q, r = read(p, q), cl = closed(p, q), pr = PAIRS[r.c].split('/');
    el.querySelector('.cw-p').textContent = p; el.querySelector('.cw-q').textContent = q;
    var alg = (r.k === 2 ? '2 × ' : '') + (r.N > 1 ? 'M' + r.N + '(' + SYM[r.D] + ')' : SYM[r.D]);
    var L = [];
    L.push('Cl(' + p + ',' + q + '): n = ' + r.n + ', dimension 2' + SUPS[r.n] + ' = ' + (1 << r.n) + ', clock c = p − q mod 8 = ' + r.c);
    L.push('read from the labels:');
    L.push('  Gauss sum Σ i^w(a) = ' + r.re + (r.im < 0 ? ' − ' : ' + ') + Math.abs(r.im) + 'i = (1+i)^' + p + ' (1−i)^' + q + ', phase c·π/4');
    L.push('  ν = Σ e_a² = ' + r.nu + ' → ' + (r.nu > 0 ? 'positive: ℝ' : (r.nu === 0 ? 'zero: ℂ' : 'negative: ℍ')) +
      (r.n % 2 ? ';  top label squared: ' + (r.top > 0 ? '+1 (central, splits: two copies)' : '−1') : ''));
    L.push('type: ' + alg + '   (k·N²·dim D = ' + r.k + '·' + r.N * r.N + '·' + r.dimD + ' = ' + (1 << r.n) + ')');
    L.push('even part: ' + tname(pr[1]) + ' type   (the pair ' + tname(pr[0]) + ' / ' + tname(pr[1]) + ' of cat·C1)');
    L.push('minimal module: real dimension ' + r.module + ', commutant ' + SYM[r.D] + (r.D === 'H' ? ' (Kramers: T² = −1)' : ''));
    if (r.n > 10) L.push('');
    out.textContent = L.join('\n');
    drawDial(r);
  }
  el.addEventListener('click', function (ev) {
    var k = ev.target && ev.target.getAttribute && ev.target.getAttribute('data-k'); if (!k) return;
    var v = k[0], d = k[1] === '+' ? 1 : -1;
    st[v] = Math.max(0, Math.min(9, st[v] + d));
    if (st.p + st.q > 10) st[v] -= d;
    show();
  });
  show();
})
