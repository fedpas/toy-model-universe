// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Steps 15-17 of the atlas (labels, gauge gravity, finite groups): the small engine behind the page's pictures.
// Everything here is computed in the browser from the bit rule  e_a e_b = s(a,b) e_{a xor b}  (blades are bit masks) and plain integer arithmetic;
// the Python scripts labels_check.py, gtg_check.py and groups_check.py (README_update_v10.md) are the reference, and test_labels.mjs compares the two.

// ---------------------------------------------------------------- the bit rule
const pc = x => { let c = 0; while (x) { c += x & 1; x >>>= 1; } return c; };
export const popcount = pc;
// sign from putting the generators of a b into increasing order
export const reorder = (a, b) => { let s = 0, x = a >> 1; while (x) { s += pc(x & b); x >>= 1; } return s & 1 ? -1 : 1; };
// signature: p generators squaring to +1, then q to -1, then r to 0
export const sigVec = (p, q, r = 0) => [...Array(p).fill(1), ...Array(q).fill(-1), ...Array(r).fill(0)];
// product of two blades: [blade, sign]
export const bladeMul = (a, b, sq) => { let s = reorder(a, b), c = a & b, i = 0; while (c) { if (c & 1) s *= sq[i]; c >>= 1; i++; } return [a ^ b, s]; };
export const mvZero = n => new Float64Array(1 << n);
export const mul = (x, y, sq) => { const o = new Float64Array(x.length); for (let a = 0; a < x.length; a++) if (x[a]) for (let b = 0; b < y.length; b++) if (y[b]) { const [c, s] = bladeMul(a, b, sq); o[c] += s * x[a] * y[b]; } return o; };

// ---------------------------------------------------------------- the clock (Step 15)
// c = p - q mod 8 names the graded class; the ungraded type follows (the five types R, R2 = R+R, C, H, H2 = H+H)
export const TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C'];
export const FIELD_DIM = { R: 1, R2: 1, C: 2, H: 4, H2: 4 };
export const clockOf = (p, q) => (((p - q) % 8) + 8) % 8;
export const typeOf = (p, q) => TYPES[clockOf(p, q)];
// Cl(p,q) = M_k(type) (twice for R2 and H2); k from the number of generators n
export function wedderburn(p, q) {
  const n = p + q, t = typeOf(p, q);
  const k = t === 'R' ? 2 ** (n / 2) : t === 'R2' || t === 'C' ? 2 ** ((n - 1) / 2) : t === 'H' ? 2 ** ((n - 2) / 2) : 2 ** ((n - 3) / 2);
  const copies = t === 'R2' || t === 'H2' ? 2 : 1;
  return { n, c: clockOf(p, q), type: t, k, copies, dim: copies * k * k * FIELD_DIM[t] };
}
// Gauss sum over all 2^n blade addresses: sum_a i^(pos(a) - neg(a)), exact in Z[i]; its phase is the clock
export function gaussSum(p, q) {
  const n = p + q, posMask = (1 << p) - 1, negMask = ((1 << n) - 1) ^ posMask; let re = 0, im = 0;
  for (let a = 0; a < (1 << n); a++) { const e = (((pc(a & posMask) - pc(a & negMask)) % 4) + 4) % 4; if (e === 0) re++; else if (e === 1) im++; else if (e === 2) re--; else im--; }
  const ang = Math.atan2(im, re), c = (((Math.round(ang / (Math.PI / 4))) % 8) + 8) % 8;
  return { re, im, norm2: re * re + im * im, c };
}
// Every Cl(p,q) sits inside the all-positive cell Cl(n+2,0): a positive generator stays e_j, a negative one becomes e_j P with P = e_{n+1} e_{n+2} (P^2 = -1, P commutes with every e_j)
export function embedCheck(p, q) {
  const n = p + q, host = Array(n + 2).fill(1), P = (1 << n) | (1 << (n + 1));
  const img = []; for (let j = 0; j < n; j++) img.push(j < p ? [1 << j, 1] : [(1 << j) ^ P, 1]);
  const mulS = (u, v) => { const [m, s] = bladeMul(u[0], v[0], host); return [m, s * u[1] * v[1]]; };
  let squaresOk = true, anticommOk = true, oddOk = true;
  for (let j = 0; j < n; j++) { const s = mulS(img[j], img[j]); if (s[0] !== 0 || s[1] !== (j < p ? 1 : -1)) squaresOk = false; if (!(pc(img[j][0]) & 1)) oddOk = false; }
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const a = mulS(img[i], img[j]), b = mulS(img[j], img[i]); if (a[0] !== b[0] || a[1] !== -b[1]) anticommOk = false; }
  // distinct subsets give distinct blades (the low n bits are the subset itself), so the map is one-to-one
  return { n, host: n + 2, squaresOk, anticommOk, oddOk, ok: squaresOk && anticommOk && oddOk, images: img.map(([m]) => m) };
}
export const bladeName = (m, off = 0) => (m === 0 ? '1' : 'e' + Array.from({ length: 12 }, (_, i) => (m >> i & 1 ? String(i + 1 + off) : '')).join(''));

// ---------------------------------------------------------------- the trinity (Step 15, n = 2)
// X = a e1 + b e2 + c e12 in Cl(2,0) = M_2(R):  X^2 = (a^2 + b^2 - c^2) * 1
export const traceless = (a, b, c) => a * a + b * b - c * c;
export const trinityClass = (s, eps = 1e-9) => (s < -eps ? -1 : s > eps ? 1 : 0);   // -1: rotation, +1: boost, 0: translation
export const matrixOf = (a, b, c) => [[a, b + c], [b - c, -a]];
// the same square rebuilt with the bit rule of Cl(2,0), for integer a, b, c (e1 = 1, e2 = 2, e12 = 3)
export function squareByBitRule(a, b, c) { const sq = [1, 1], X = mvZero(2); X[1] = a; X[2] = b; X[3] = c; const Y = mul(X, X, sq); return { scalar: Y[0], rest: Math.abs(Y[1]) + Math.abs(Y[2]) + Math.abs(Y[3]) }; }
// exp(tX) as a 2x2 matrix, by the three closed forms
export function expTX(a, b, c, t) {
  const s = traceless(a, b, c), M = matrixOf(a, b, c); let f, g;
  if (s < -1e-12) { const w = Math.sqrt(-s); f = Math.cos(w * t); g = Math.sin(w * t) / w; } else if (s > 1e-12) { const w = Math.sqrt(s); f = Math.cosh(w * t); g = Math.sinh(w * t) / w; } else { f = 1; g = t; }
  return [[f + g * M[0][0], g * M[0][1]], [g * M[1][0], f + g * M[1][1]]];
}
export const apply = (E, v) => [E[0][0] * v[0] + E[0][1] * v[1], E[1][0] * v[0] + E[1][1] * v[1]];
// the spring x'' = -k x as a generator: a = 0, b = (1-k)/2, c = (1+k)/2, so X^2 = -k
export const springX = k => [0, (1 - k) / 2, (1 + k) / 2];
export function gridCounts(R = 6) { let ell = 0, hyp = 0, par = 0; for (let a = -R; a <= R; a++) for (let b = -R; b <= R; b++) for (let c = -R; c <= R; c++) { const s = traceless(a, b, c); if (s < 0) ell++; else if (s > 0) hyp++; else if (a || b || c) par++; } return { ell, hyp, par, total: (2 * R + 1) ** 3 }; }

// ---------------------------------------------------------------- bivectors at n = 4 (Step 15)
export const BIV_MASKS = [3, 5, 9, 6, 10, 12];   // e12 e13 e14 e23 e24 e34
export const BIV_NAMES = ['e12', 'e13', 'e14', 'e23', 'e24', 'e34'];
export const SIGS4 = [[4, 0], [3, 1], [2, 2], [1, 3], [0, 4]];
// B^2 = S + W e1234; the two squares lambda of the commuting simple parts solve  l^2 - S l + W^2 I^2/4 = 0  with I^2 = (-1)^q
export function bivector4(p, q, coef) {
  const sq = sigVec(p, q), B = mvZero(4); BIV_MASKS.forEach((m, i) => { B[m] = coef[i]; });
  const B2 = mul(B, B, sq), S = B2[0], W = B2[15]; let other = 0; for (let m = 1; m < 15; m++) other += Math.abs(B2[m]);
  const I2 = q % 2 ? -1 : 1, disc = S * S - W * W * I2, eps = 1e-9, zero = coef.every(x => x === 0);
  let kind, lam;
  if (disc < -eps) { kind = 'complex'; lam = [[S / 2, Math.sqrt(-disc) / 2], [S / 2, -Math.sqrt(-disc) / 2]]; } else { const r = Math.sqrt(Math.max(0, disc)); lam = [[(S + r) / 2, 0], [(S - r) / 2, 0]]; kind = 'real'; }
  const sg = x => (x < -eps ? -1 : x > eps ? 1 : 0);
  let label;
  if (zero) label = 'zero';
  else if (kind === 'complex') label = 'complex';
  else if (Math.abs(W) < eps) label = S < -eps ? 'rotation' : S > eps ? 'boost' : 'null';
  else { const a = sg(lam[0][0]), b = sg(lam[1][0]); label = a === -1 && b === -1 ? 'double-rotation' : a === 1 && b === 1 ? 'double-boost' : a === 0 && b === 0 ? 'null' : a * b === -1 ? 'rotation-boost' : 'null-mixed'; }
  return { S, W, I2, disc, kind, lam, label, other };
}
// a deterministic generator, so that "random" counts are the same on every machine
export function lcg(seed) { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
export function sampleBivectors(p, q, N = 400, seed = 12345) {
  const r = lcg(seed + 7 * p + q); let real = 0, complex = 0, skipped = 0;
  for (let i = 0; i < N; i++) { const c = Array.from({ length: 6 }, () => Math.round(r() * 6 - 3)); const v = bivector4(p, q, c); if (v.label === 'zero' || Math.abs(v.disc) < 1e-9) { skipped++; continue; } if (v.kind === 'complex') complex++; else real++; }
  return { real, complex, skipped, N };
}

// ---------------------------------------------------------------- gauge gravity (Step 16)
// Painleve-Gullstrand: g = sqrt(2M/r); the radial gradient hbar(e_r) = e_r + g e_t in Cl(1,1) (e_t^2 = +1, e_r^2 = -1) squares to g^2 - 1 = -T, T = 1 - 2M/r
export const pgG = (r, M = 0.5) => Math.sqrt(2 * M / r);       // r in units where 2M = 1 when M = 1/2
export const pgSquare = g => g * g - 1;
export function pgSquareByBitRule(g) { const sq = [1, -1], X = mvZero(2); X[1] = g; X[2] = 1; return mul(X, X, sq)[0]; }   // e_t = bit 1 (index 0), e_r = bit 2
export const pgClass = (g, eps = 1e-9) => { const s = pgSquare(g); return s < -eps ? -1 : s > eps ? 1 : 0; };   // -1 spacelike outside, 0 null on the horizon, +1 timelike inside
// light rays in (r, t): ds^2 = dt^2 - (dr + g dt)^2 gives dr/dt = -g +- 1 ; rain falls with dr/dt = -g ; reversing time sends g to -g
export const pgRays = (g, sign = 1) => ({ out: 1 - sign * g, inn: -1 - sign * g, rain: -sign * g });
export const curvature = n => ({ n, riemann: n * n * (n * n - 1) / 12, ricci: n * (n + 1) / 2, weyl: n >= 3 ? n * (n + 1) * (n + 2) * (n - 3) / 12 : 0, scalarOnly: n <= 3 });

// ---------------------------------------------------------------- finite groups (Step 17)
// from groups_check.py part A and B (exact orders, Schreier-Sims there; the numbers are copied from groups_check.log and compared by test_labels.mjs)
export const RAILS = {
  // n: [E_n type, class of Cl(n,0), |W(E_n)|, image mod 2 = |O(Q)|, kernel]
  E: { 3: ['A2+A1', 'C', 12, 6, 2], 4: ['A4', 'H', 120, 120, 1], 5: ['D5', 'H2', 1920, 1920, 1], 6: ['E6', 'H', 51840, 51840, 1], 7: ['E7', 'C', 2903040, 1451520, 2], 8: ['E8', 'R', 696729600, 348364800, 2] },
  // n: [class of Cl(0,n), |S_{n+1}| = image, |O(Q)|]
  A: { 2: ['H', 6, 6], 3: ['H2', 24, 24], 4: ['H', 120, 120], 5: ['C', 720, 720], 6: ['R', 5040, 40320], 7: ['R2', 40320, 2580480], 8: ['R', 362880, 348364800] },
};
export const factorial = n => { let f = 1; for (let i = 2; i <= n; i++) f *= i; return f; };
// [24,12,8] Golay code: the cyclic [23,12,7] code with generator x^11+x^10+x^6+x^5+x^4+x^2+1, plus an overall parity bit
export function golay() {
  const G = 0xC75, words = new Int32Array(4096);
  for (let m = 0; m < 4096; m++) { let w = 0; for (let i = 0; i < 12; i++) if (m >> i & 1) w ^= G << i; if (pc(w) & 1) w |= 1 << 23; words[m] = w; }
  const hist = {}; for (const w of words) { const k = pc(w); hist[k] = (hist[k] || 0) + 1; }
  const octads = Array.from(words).filter(w => pc(w) === 8);
  return { words, hist, octads };
}
// the unique octad through five points (a 24-bit mask with five bits), or null
export const octadThrough = (octads, mask) => { const hit = octads.filter(o => (o & mask) === mask); return hit.length === 1 ? hit[0] : hit.length ? 'many' : null; };
// primes: a prime p first divides 2^n - 1 at n = ord_p(2)
export const ordTwo = p => { let x = 2 % p, n = 1; while (x !== 1) { x = (x * 2) % p; n++; } return n; };
export function factorize(m) { const f = []; for (let d = 2; d * d <= m; d++) while (m % d === 0) { f.push(d); m = m / d; } if (m > 1) f.push(m); return f; }
export const newPrimes = n => [...new Set(factorize(2 ** n - 1))].filter(p => ordTwo(p) === n);
export const MONSTER_PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 41, 47, 59, 71];
