// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Data of the "For researchers" page (v10.2): the twenty theorems of the second audit round with their verification status, the errata record, the open questions, the sources the atlas was compared with, the check scripts to run, and the note on the frozen Genesis story.
// English only on purpose (the audience is the researchers themselves); the page chrome around it is EN and IT. Every number here is read from the derivation files, the two verifiers' verdicts and the scripts' own output; where a derivation and a verifier disagree the verifier's correction is what this file says.
// Statuses: proved = proof written, checked by its script and re-derived once by an independent reader; reduced = proved from a named standard theorem that is recalled, not re-proved; range = exhaustive computation over a stated range only; open = a stuck part. No specialist outside this project has reviewed any of it.

export const THEOREMS = [
  {
    id: 'T1', title: 'Associativity of the bit rule for every n and every choice of squares',
    statement: "On the labels a ∈ 𝔽₂ⁿ put e_a e_b = s(a,b) e_{a xor b} with s(a,b) = (−1)^{N(a,b)} ∏_{i ∈ a∧b} ε_i, N(a,b) = #{(i,j): i ∈ a, j ∈ b, j < i} and ε ∈ {+1, −1, 0}ⁿ. The product is associative with unit e₀, and the algebra is Cl(p,q,r). Reason: the sign is a bilinear form mod 2, hence a 2-cocycle of ℤ₂ⁿ; the square factor is a 2-cocycle with values in the monoid {+1, −1, 0}, because the exponent of each ε_i agrees as an integer on the two sides of the cocycle identity, so ε_i = 0 passes. The same two lines give associativity for any bilinear sign.",
    status: 'proved', statusNote: "Proof written and checked; the ε = 0 case rests on the integer identity ab + (a xor b)c = a(b xor c) + bc on bits. Side result: replacing j < i by j ≤ i in the sign stays associative (it is the bit rule with every ε negated), so that flip is not a sabotage of associativity.",
    verifier: 'verified', verifierNote: "Lane A verifier: cocycle proof correct for all n; an independent word-reduction engine agrees; mutants killed, the j ≤ i control survives as predicted.",
    script: 'check_T1.py', checks: "The cocycle identity exhaustively for n ≤ 7 (2²¹ triples at n = 7); the integer identity on all 8 bit triples; blade associativity for all 120 choices of ε with n ≤ 4 and random ε at n = 5, 6; 200 random multivectors; the j ≤ i variant; a non-bilinear sabotage fails at the triple (1,0,0). Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['PAG-001', 'PAG-002', 'MAP-001', 'PRJ-001'], corrections: []
  },
  {
    id: 'T2', title: 'Radical, Loewy layers, super-centre and graded structure of Cl(p,q,r)',
    statement: "Let J be the span of the labels that contain a null bit. (1) Concatenating generator lists is the graded tensor product: Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r). (2) J is the Jacobson radical, of dimension 2ⁿ − 2^{p+q}; the quotient is Cl(p,q). (3) J^k is spanned by the labels with at least k null bits; the layers have dimension C(r,k)·2^{p+q}; the Loewy length is r + 1. (4) The super-centre is Λ(ℝ^r), of dimension 2^r. (5) The algebra is graded-simple with super-centre ℝ exactly when r = 0. (6) Among gradings in which every label is homogeneous, the universal grading group is ℤ₂^{p+q} × ℤ^r (free rank r); the unqualified sentence is false: M₂(ℝ) = Cl(2,0) carries a ℤ-grading by matrix units.",
    status: 'proved', statusNote: "Parts 1–5 proved for all signatures; part 6 proved in the label-homogeneous form only. The universal grading group for arbitrary gradings (torsion included) is not determined.",
    verifier: 'gaps', verifierNote: "Verified with gaps (check only): the mathematics is right; check items GL and GRA are tautologies, LOE hangs instead of failing on a non-nilpotent radical; the count '119 signatures with n ≤ 6' is 83.",
    script: 'check_T2.py', checks: "Koszul factorisation over every split of every signature n ≤ 6; the radical as the kernel of the trace form of the regular representation (exact rank) for all 83 signatures n ≤ 6; Loewy layers C(r,k)·2^{p+q} and length r + 1; super-centre dimension 2^r (n ≤ 5); the centre of Cl(p,q); the relation lattice of the label-homogeneous grading. Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['NUL-004', 'EQN-020', 'FRQ-003', 'PRJ-006', 'LAB-007', 'SHP-002', 'MAP-012'],
    corrections: [
      "The count 'all 119 signatures with n ≤ 6' in T2.md, T3.md and the lane summary is 83 (119 is n ≤ 7).",
      "Check items GL and GRA never test the algebra (tautologies); LOE does not terminate on a non-nilpotent radical (a mutant is killed by timeout, not by a FAIL line).",
      "The atlas sentence on the grading lift must say 'among label-homogeneous gradings'; for arbitrary gradings it is false (M₂(ℝ) has a ℤ-grading by matrix units)."
    ]
  },
  {
    id: 'T3', title: 'The top-label Frobenius form, its Nakayama automorphism, and the torsor of Frobenius forms',
    statement: "Let λ(x) be the coefficient of the full label e_F in x. (F1) λ(e_a e_b) ≠ 0 iff b = a xor F, and then it is ±1: the pairing λ(xy) is non-degenerate, so Cl(p,q,r) is a Frobenius algebra for every signature, null generators included. (F2) Its Nakayama automorphism is the identity for odd n and the grade involution α for even n. (F3) A symmetric non-degenerate associative form exists iff n is odd or r = 0; for even n with r ≥ 1 every w with α(x)w = wx lies in the radical (it is c·e_F plus an odd element of Λ(ℝ^r)). (F4) The scalar-part pairing ⟨xy⟩₀ has rank 2^{p+q}: blind to every label with a null bit. (TOR) All Frobenius forms are λ(u·) with u any unit, a torsor under the unit group; the symmetric ones, when they exist, are λ_s(z·) with z a central unit. In Cl(3,0), λ(x) = −⟨ωx⟩₀ with ω = e₁₂₃.",
    status: 'proved', statusNote: "All parts proved. The two standard facts used (the Nakayama automorphism; symmetric iff it is inner) are recalled from Skowroński–Yamagata; the computation for Cl(p,q,r) is own. The category report's 'Frobenius forms are a torsor under the central units' is corrected by TOR.",
    verifier: 'verified', verifierNote: "Torsor correction right (all units; central units only for the symmetric forms; u = 2 + e₁ in Cl(3,0) is the counterexample); the non-symmetry argument is airtight.",
    script: 'check_T3.py', checks: "F1, F2, F4 on all 83 signatures n ≤ 6; for every even n ≤ 6 the space of conjugators of α computed exactly (dimension 1 + 2^{r−1}, all nilpotent when r ≥ 1); a rank test finds no symmetric form for n = 2, 4 with r ≥ 1 and finds one for Cl(3,1); TOR on four cells with 30 random u each; the sign in Cl(3,0). Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['NUL-004'], corrections: []
  },
  {
    id: 'T4', title: 'The mod-8 type table from the bit rule; five ungraded types, eight graded pairs; Gauss sum; Frobenius–Schur count',
    statement: "(i) Cl(p,q) is k copies of M_N(D) with (D,k) depending only on c = p − q mod 8: c = 0 (ℝ,1), 1 (ℝ,2), 2 (ℝ,1), 3 (ℂ,1), 4 (ℍ,1), 5 (ℍ,2), 6 (ℍ,1), 7 (ℂ,1), with kN²·dim D = 2ⁿ. Proved inside the bit rule: Cl(n+2,0) = Cl(0,n) ⊗ Cl(2,0), Cl(0,n+2) = Cl(n,0) ⊗ Cl(0,2), Cl(p+1,q+1) = Cl(p,q) ⊗ M₂(ℝ), six base cells, and ℍ ⊗ ℍ = M₄(ℝ) taken twice around for the period 8. (ii) The ungraded type takes 5 values; the pair (type of A, type of its even part) takes 8, one per clock value. (iii) Σ_a i^{|a∧P| − |a∧Q|} = (1+i)^p (1−i)^q = 2^{n/2} e^{iπ(p−q)/4}; null generators only double the sum. (iv) ν = Σ_a e_a² = Re((1−i)(1+i)^p(1−i)^q) = kN·ind(D) with ind(ℝ) = +1, ind(ℂ) = 0, ind(ℍ) = −2: the Frobenius–Schur count of the group {±e_a} acting on the algebra by left multiplication; its sign is the type.",
    status: 'reduced', statusNote: "(i) and (ii) proved by reduction: the three isomorphisms and the tensor identities are proved and checked; that the eight pairs are the graded Morita classes forming ℤ₈ (Wall's Brauer–Wall group of ℝ, 1964) is recalled, not re-proved. (iii) and (iv) proved.",
    verifier: 'gaps', verifierNote: "Verified with gaps (text errors): the proof of (ii) wrote clock c − 1 for the even part, which is c + 1 or 1 − c (the listed pairs are right); statement (iv) said 'regular representation of G', which is wrong (it is G acting on the algebra by left multiplication); check C1 tests that the pairs are distinct, not the pairs themselves.",
    script: 'check_T4.py', checks: "The three isomorphisms with exact basis rank for p + q ≤ 5; the base matrices; the tensor identities by explicit maps (ℍ ⊗ ℍ of rank 16 on 256 basis pairs, ℂ ⊗ ℍ of rank 8); the recursion against the mod-8 list for p + q ≤ 10 with kN²·dim D = 2ⁿ; the Gaussian-integer identity; ν = kN·ind(D); 8 distinct pairs, 5 ungraded types. Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['ATL-001', 'ATL-002', 'ATL-003', 'ATL-004', 'ATL-005', 'ATL-006', 'ATL-007', 'ATL-008', 'ATL-009', 'ATL-010', 'ATL-011', 'ATL-012', 'ATL-013', 'ATL-014', 'ATL-015', 'ATL-016', 'ATL-017', 'ATL-018', 'ATL-019', 'ATL-020', 'ATL-021', 'ATL-022', 'ATL-023', 'ATL-024', 'ATL-025', 'MAP-002', 'MAP-006', 'PAG-004', 'PAG-005', 'LAB-001', 'LAB-002', 'RSN-029'],
    corrections: [
      "Proof of (ii): the even part Cl(p,q−1) or Cl(q,p−1) has clock c + 1 or 1 − c, not c − 1 (the symmetry type(c) = type(2 − c) relates the two); the table of pairs is unaffected.",
      "Statement (iv): the count is the Frobenius–Schur indicator of the representation of G = {±e_a} on the algebra by left multiplication (the regular A-module), not of the regular representation of G, whose count is #{g: g² = 1} ≠ ν.",
      "Check script: item H has one vacuous entry (ℂ ⊗ ℂ) and item C1 checks the distinctness of the eight pairs, not the listed pairs (a wrong table would pass C1)."
    ]
  },
  {
    id: 'T5', title: 'Even subalgebra, D1, the graded embedding D2, and what fails with only null generators',
    statement: "(a) With one invertible generator t (t² = τ = ±1) and f_i = e_i t for i ≠ k, the f_i anticommute, f_i² = −τ e_i², and they generate the even part: Cl⁰(p,q,r) = Cl(p,q−1,r) for τ = −1 and Cl(q,p−1,r) for τ = +1; null generators ride along as null generators. (b) D1: Cl(0,m) = Cl⁰(m+1,0) for every m, so ℂ = Cl⁰(2,0) and ℍ = Cl⁰(3,0). (c) D2: e_j ↦ e_j for a square +1 and e_j ↦ e_j e_{n+1} e_{n+2} for a square −1 is an injective ℤ₂-graded homomorphism Cl(p,q) → Cl(n+2,0) that sends every label to ± a blade. (d) With only null generators, the even part Λ^{ev}(ℝ^r) is a Clifford algebra on r − 1 generators only for r ≤ 2 (r = 2: the dual numbers): for r ≥ 3 its radical has dimension 2^{r−1} − 1 and its Loewy length is ⌊r/2⌋ + 1 < r. Label 0 cannot be peeled off from the top in exactly this sense.",
    status: 'proved', statusNote: "All four parts proved; D2 gains the injectivity line it lacked; the null failure is made precise (first failure at r = 3, never recovered).",
    verifier: 'verified', verifierNote: "Even part, D1, D2 with injectivity, and the r ≤ 2 criterion confirmed; all mutants killed.",
    script: 'check_T5.py', checks: "140 (signature, invertible generator) pairs with n ≤ 5, null generators included: relations and exact rank 2^{n−1} inside the even labels; D1 for m ≤ 7; D2 for all p + q ≤ 5 (squares, anticommutation, odd images, 2ⁿ distinct blades); for r = 1..5 the radical dimension and Loewy length of the even part against every Cl(p′,q′,r′) on r − 1 generators (a match only for r = 1, 2). Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['LAB-001', 'RSN-029', 'MAP-013', 'PAG-018', 'GOS-001', 'EQN-002'], corrections: []
  },
  {
    id: 'T6', title: 'The cube of labels: the sign is unique up to gauge, the Koszul complex, H²(ℤ₂ⁿ; 𝔽₂) = quadratic forms, the octonion cochain',
    statement: "(a) The Jordan–Wigner sign σ(a,i) = (−1)^{#{j ∈ a: j < i}} on the edges of the cube of labels makes every square anticommute, and every anticommuting sign is one of its 2^{2ⁿ − 1} gauge transforms: H¹ of the cube's 2-skeleton over 𝔽₂ is 0. (b) d e_a = Σ_{i ∈ a} σ(a−i, i) e_{a−i} squares to zero and wedging with e₀ is a contracting homotopy: the complex is exact, of total rank 2^{n−1}, rank C(n−1,k−1) in degree k. (c) H²(ℤ₂ⁿ; 𝔽₂) is the space of quadratic forms on 𝔽₂ⁿ, of dimension n(n+1)/2; the Clifford algebras are the classes with polar form |a||b| − |a∧b|. (d) The octonions are the eight labels with the Albuquerque–Majid cochain F: dF = (−1)^{det(a,b,c)}, −1 exactly on the 168 independent ordered triples, and F satisfies the composition criterion, so the algebra is a unital composition algebra of dimension 8, hence 𝕆 (Hurwitz).",
    status: 'reduced', statusNote: "(a)–(c) proved; (d) proved for the finite statements (coboundary on 512 triples, composition on 448 cases) and reduced to Hurwitz's theorem (recalled) for the identification with 𝕆; the Albuquerque–Majid framing (a quasialgebra in the category of ℤ₂³-graded spaces) is recalled. The pentagon check K3b of the category report is automatic once dF = (−1)^det holds.",
    verifier: 'gaps', verifierNote: "Verified with gaps (cosmetic): 'rank 2^{n−1} in every degree' was wrong (total rank 2^{n−1}; C(n−1,k−1) per degree); the bit-rule cochain is the transpose of the stated representative.",
    script: 'check_T6.py', checks: "Squares anticommute for n ≤ 7; H¹ = 0 by 𝔽₂ ranks for n ≤ 5 and by brute force (128 assignments) on the 3-cube; d² = 0 and dh + hd = 1 for n ≤ 7, rank 2^{n−1} for n ≤ 6; dim H² by exact 𝔽₂ linear algebra for n ≤ 4; the octonion cochain: squares, anticommutation, dF = (−1)^det with 168 independent triples, the 448-case composition criterion plus 200 random N(xy) = N(x)N(y); the Cl(0,3) sign is a cocycle but not a composition sign. Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['FUR-003'],
    corrections: [
      "T6.md (b): the complex has total rank 2^{n−1}, and rank C(n−1,k−1) on degree k; not 'rank 2^{n−1} in every degree'.",
      "T6.md (c): the bit-rule sign is Σ_{j<i} a_i b_j, the transpose of the stated representative Σ_{i<j} a_i b_j (cohomologous, not equal)."
    ]
  },
  {
    id: 'T7', title: "Tian's algebra is Cl(m,m) or Cl(m−1,m−1,1) in a hyperbolic basis; the sorting sign is the bit-rule sign",
    statement: "Let T_k be generated by a₁, …, a_k with a_i² = 0, a_i a_{i+1} + a_{i+1} a_i = 1 and a_i a_j = −a_j a_i for |i − j| > 1 (Tian, arXiv:1309.6049). (1) T_k is the Clifford algebra of Q(c) = Σ c_i c_{i+1}, of signature (⌊k/2⌋, ⌊k/2⌋, k mod 2): T_{2m} = Cl(m,m) = M_{2^m}(ℝ) and T_{2m−1} = Cl(m−1,m−1,1). (2) With the hyperbolic pairs u_j = (e_j + f_j)/2, v_j = (e_j − f_j)/2 of Cl(m,m), the elements a_{2j−1} = u_j + u_{j−1} and a_{2j} = v_j satisfy Tian's relations and generate Cl(m,m). (3) The radical vector of the odd truncation, a₁ − a₃ + a₅ − …, equals (−1)^{m−1} u_m: the half of the last hyperbolic pair whose partner a_{2m} = v_m is missing. A label 0 of the truncation is a paired null that lost its partner. (4) The bit-rule sign is the parity of the number of inversions of the word sorted(a) ++ sorted(b): Tian's η of Lemma 4.20.",
    status: 'proved', statusNote: "All four parts proved; the identification for general k uses the explicit embedding of (2) and Sylvester's law (standard). The DG category of the paper is not touched.",
    verifier: 'gaps', verifierNote: "Verified with gaps (cosmetic): the body is right (T_{2m} = Cl(m,m), T_{2m−1} = Cl(m−1,m−1,1), radical vector (−1)^{m−1}u_m); the title still read Cl(m,m,1).",
    script: 'check_T7.py', checks: "Relations and exact rank 4^m of the 2^k words in Cl(m,m) for k = 2, 4, 6, 8; rank 2^k for k = 1, 3, 5, 7 with the alternating sum equal to (−1)^{m−1}u_m exactly, squaring to 0 and anticommuting with all a_i; the Gram matrix read from the algebra for k ≤ 8 and the signature for k ≤ 12; bubble-sort inversion parity = bit-rule sign, exhaustive n ≤ 8 (65536 pairs). Prints ALL OK (needs bitrule_A.py).",
    usedFor: ['GEN-004', 'GEN-005', 'GEN-006'],
    corrections: ["Title: Cl(m−1,m−1,1), not Cl(m,m,1) (which would have 2m + 1 generators); the candidate list had the same slip."]
  },
  {
    id: 'T8', title: 'Representation type of the cube category (the incidence algebra of the Boolean lattice)',
    statement: "Let A_n = k B_n = (k A₂)^{⊗n}, the path algebra of the n-cube with commuting squares. (1) Cartan matrix kron^n [[1,1],[0,1]], Euler form the Möbius function, Coxeter matrix Φ_n = (−1)^{n−1} kron^n Φ₁; Coxeter polynomials x² + x + 1 (n = 1), (x+1)²(x² − x + 1) = D₄ (n = 2), (x−1)²(x² + x + 1)³ = the tubular (3,3,3) profile (n = 3); the radical of the symmetrised Euler form is Fix(Φ_n); signatures (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0..5. (2) The Tits form equals the Euler form for n ≤ 2; at n = 3 it is χ + x₀x₇, signature (6,1,1), weakly non-negative; at n = 4, 5 it is negative on non-negative vectors. (3) Representation-finite for n ≤ 2 (n = 2: tilted of type D₄, 11 indecomposables, recalled); not finite from n = 3 (the rank-1-2 labels form a convex subposet, the hexagon crown Ã₅); wild for n ≥ 4 (de la Peña, recalled). Tame or wild at n = 3 is open.",
    status: 'reduced', statusNote: "Closed forms, Fix(Φ) = Euler radical, Tits versus Euler form and 'not finite from n = 3' proved; wild for n ≥ 4 by reduction to de la Peña's theorem (recalled, over an algebraically closed field); n = 2 finite recalled. OPEN: tame versus wild at n = 3; the derived equivalence with the tubular (3,3,3) algebra is not proved (only the Coxeter polynomial and the corank-2 positive semidefinite Euler form match that profile).",
    verifier: 'gaps', verifierNote: "Verified with gaps: Coxeter polynomials, Euler radical, Tits (6,1,1) against Euler (6,0,2), not finite at n = 3, wild for n ≥ 4 are all right; '12 indecomposables' for the commutative square was false (11); the TITS loop at n = 3 does not terminate on some false inputs (a mutant is killed by timeout).",
    script: 'check_T8.py', checks: "Cartan and Möbius matrices with exact signatures by rational diagonalisation, reproducing the category report's E1 independently; Φ_n as integer matrices with eigenvalue multiplicities for n ≤ 5 and fixed space = Euler radical; Tits = Euler for n ≤ 2, q_T − χ = x₀x₇ at n = 3, a descent search finds no negative value at n = 3 and finds witnesses at n = 4, 5; convexity and the cycle count of the rank-1-2 subposet. Prints ALL OK (needs bitrule_A.py).",
    usedFor: [],
    corrections: [
      "The commutative square (n = 2) has 11 indecomposables, not 12 (11 positive roots of its positive-definite Tits form, all thin).",
      "'n = 3 is tubular (3,3,3)' overstates the result: only the Coxeter polynomial and the corank-2 PSD Euler form have the tubular profile; derived-tubular or tame at n = 3 stays open.",
      "The signatures (…, (6,0,2), …) of the category report's E1 are those of the symmetrised Euler form; the Tits form differs from n = 3 on (signature (6,1,1)), and the representation-type criteria use the Tits form.",
      "Check script: the TITS loop at n = 3 does not terminate on some false inputs (killed by timeout, not by a FAIL line)."
    ]
  },
  {
    id: 'T9', title: 'W(E_n) mod 2 is the isometry group of the label form of Cl(n,0); the 𝔽₂ classes of E_n/2E_n and A_n/2A_n',
    statement: "For an even lattice L put q(x) = x·x/2 mod 2 on L/2L; the label form of Cl(p,q) is Q(a) = [e_a² = −1] on 𝔽₂ⁿ. (a) For every n ≥ 3, (E_n/2E_n, q) is isometric to (𝔽₂ⁿ, Q_{Cl(n,0)}) by an explicit map, and A_n/2A_n to Q_{Cl(0,n)} for every n ≥ 1. (b) Q_{Cl(n,0)} and Q_{Cl(0,n)} are isometric iff 4 | n. (c) For n = 3..8 reduction mod 2 maps W(E_n) onto O(q), with kernel of order 2, 1, 1, 1, 2, 2 and image orders 6, 120, 1920, 51840, 1451520, 348364800 (Sp₂(2), O⁻₄(2), 2⁴:O⁻₄(2), O⁻₆(2), Sp₆(2), O⁺₈(2)). (d) W(A_n) = S_{n+1} injects into O(Q_{Cl(0,n)}) and is onto iff n ≤ 5 (indices 8, 64, 960 at n = 6, 7, 8). (e) W(E_n) mod 2 = O(q) also for n = 9..12 (computed). (f) The 𝔽₂ class is not a function of rank and signature: A₆ and E₆ are both even, positive definite, of rank 6 with odd determinant, but A₆/2A₆ has Arf invariant 0 and E₆/2E₆ has Arf invariant 1.",
    status: 'proved', statusNote: "(a), (b), (d), (f) proved by hand for all n; (c) proved by two routes, each resting on one named standard theorem (the orders of W(E_n) from Bourbaki's tables, or Dieudonné's generation of O(q) by transvections), and independently by an exact Schreier–Sims computation of the finite statement; (e) is computation only for n = 9..12, general n open. The atlas's 'E_n sits at c = n exactly' is too strong: the 𝔽₂ form sees c only up to c ↔ 2 − c.",
    verifier: 'verified', verifierNote: "All proofs correct, all numbers recomputed (kernels 2, 1, 1, 1, 2, 2; n = 9..12; the A₆/E₆ example); 5/5 mutants killed. The crude bound used for n > 40 in (d) is asserted, not written out (trivial, declared by the deriver).",
    script: 'check_T9.py', checks: "The explicit isometries on every vector for n = 3..16 (E_n) and n = 1..16 (A_n); coincidence iff 4 | n by brute force for n ≤ 14 and by Gauss sums to 40; brute-force |O(q)| against the order formula for all 14 classes with n ≤ 6; for n = 3..8 the image order by Schreier–Sims, |W| on the roots, the kernel orders and the membership of −1; n = 9..12; A₆ against E₆; the S_{n+1} indices; orthogonal-root certificates. Prints ALL 186 CHECKS PASSED (needs f2lib.py; about 15 s).",
    usedFor: ['LAB-009', 'LAB-011', 'RSN-030'], corrections: []
  },
  {
    id: 'T10', title: "The E_n series: determinants, signatures, Kac types, roots, and what 'stops at 8' can mean",
    statement: "E_n (n ≥ 3) is the Cartan matrix of the tree T_{2,3,n−3}, equivalently k^⊥ in I_{1,n} with k = (3; −1, …, −1). (1) det = 9 − n; in general det T_{p,q,r} = pq + qr + rp − pqr. (2) Signature (n,0,0) for 3 ≤ n ≤ 8, (8,0,1) at n = 9, (n−1,1,0) for n ≥ 10. (3) Finite for n ≤ 8, affine at 9 (E₉ = Ẽ₈), hyperbolic only at 10, Lorentzian for all n ≥ 10. (4) The null root of E₉ has marks (3; 2,4,6,5,4,3,2,1), sum 30, and is k itself. (5) 8, 20, 40, 72, 126, 240 norm-2 vectors for n = 3..8 (positive roots 4, 10, 20, 36, 63, 120); D₈⁺ = D₈ ∪ (D₈ + (½)⁸) has 112 + 128 = 240 and is E₈. (6) Mod 2 the root pairs are the blades of Cl(n,0) with square −1, plus the radical class at n = 7. (7) The finite series stops because det = 9 − n reaches 0; the 8 it shares with the Clifford clock is the period of the Gauss-sum phase (van der Blij, Milgram; recalled); the stop is not caused by Clifford periodicity.",
    status: 'proved', statusNote: "(1)–(6) proved by hand and recomputed exactly for n = 3..20; (7) separates theorem from reading: the Gosset card may say 'resembles' only together with 'the shared 8 is the Gauss-sum period; the stop itself is det = 9 − n'.",
    verifier: 'verified', verifierNote: "det = 9 − n, signatures, Kac types, marks (3; 2,4,6,5,4,3,2,1), root counts: correct; 4/4 mutants killed.",
    script: 'check_T10.py', checks: "det E_n for n = 3..20 and det T_{p,q,r} for p, q, r ≤ 9 by exact Bareiss elimination; exact inertia for n = 3..20; Perron-vector type for n = 4..12; the E₉ null vector (corank 1, marks, sum 30, equals k); all connected subdiagrams of E₁₀ (none indefinite) and E₁₁ (one: E₁₀); norm-2 vectors by enumeration against the W-orbit sizes; D₈⁺ counts and a simple system with the E₈ Cartan matrix. Prints ALL 805 CHECKS PASSED (needs f2lib.py).",
    usedFor: ['MAP-014', 'SHP-006', 'PAG-017', 'PAG-020', 'GOS-001', 'GOS-002', 'MIR-003', 'MAP-012'], corrections: []
  },
  {
    id: 'T11', title: 'Quadric counts over 𝔽₂ (W1–W3) and the Peres–Mermin square',
    statement: "On 𝔽₂ⁿ let Q(a) = [e_a² = −1]; a point is a non-zero label with Q = 0, a totally singular subspace a set of labels closed under xor whose blades commute and square to +1, w the largest such dimension. (1) Such a subspace of dimension k spans ℝ^{2^k}; the counts of totally singular subspaces of every non-degenerate class have a closed form in m and the type ε. (2) W1: 2^w = (number of simple factors) × N for Cl(p,q) = M_N(D) or M_N(D)². (3) Cl(4,0): 5 points, no lines. Cl(6,0): 27 points, 45 lines, the elliptic quadric Q⁻(5,2), not the Klein quadric, which (35 points, 105 lines, 30 planes) is the class of Cl(3,3), Cl(4,2), Cl(0,6). Cl(8,0): 135 points, 1575 lines, 2025 planes, 270 solids in two families of 135. (4) In Cl(2,2) the 9 blades with square +1 and their 6 lines form the Peres–Mermin grid, and the product of the six line signs is −1, so no ±1 assignment exists.",
    status: 'proved', statusNote: "(1), (3), (4) proved (the counting formula N_ε(m,k) is in T11.md); (2) by reduction to the type table of T4 plus an exhaustive check for p + q ≤ 9. The reading 'the three 135s of triality' is standard (recalled); only its counting shadow is proved. The W(E₆) sentence (27 lines, 45 tritangent planes) is consistent with T9 and is standard, not verified here.",
    verifier: 'verified', verifierNote: "Counts and the Klein/elliptic correction confirmed (Gauss sum of Cl(6,0) is −8); one typo in the derivation text (35 = (2³ − 1)(2² + 1), not (2³ + 1)(2² − 1)); 5/5 real mutants killed.",
    script: 'check_T11.py', checks: "All totally singular subspaces of every Cl(p,q) with p + q ≤ 9 (W1 against the type table; counts against N_ε(m,k) for n ≤ 8); Cl(4,0), Cl(6,0), the Klein classes and Cl(8,0); the two families for Cl(8,0) and Cl(3,3); the Pfaffian form and 35 = 35; the Peres–Mermin grid, signs, product −1 under all 512 re-signings, and no solution among 512 assignments. Prints ALL 74749 CHECKS PASSED (needs f2lib.py; about 45 s).",
    usedFor: ['GOS-003', 'ATL-011', 'GEN-005'],
    corrections: [
      "Line 56 of T11.md: 35 = (2³ − 1)(2² + 1), not (2³ + 1)(2² − 1), which is 27.",
      "The candidate list called Cl(6,0) the Klein quadric Q⁺(5,2): it is the elliptic quadric Q⁻(5,2) (27 points, 45 lines); the Klein quadric is the class of Cl(3,3), Cl(4,2), Cl(0,6). The category report's numbers were right."
    ]
  },
  {
    id: 'T12', title: 'Reflections over 𝔽₂: Cartan–Dieudonné in characteristic 2',
    statement: "In O(Q) for the label forms the mirror of a non-singular label w is the transvection t_w(x) = x + b(x,w)w, the mod-2 shadow of x ↦ −wxw⁻¹. (1) For non-degenerate Q the t_w generate O(Q) except for O⁺₄(2), the class of Cl(2,2), where they generate a subgroup of index 2; for the degenerate classes with singular radical they generate everything for ε = − and an index-2 subgroup for ε = + with m = 1, 2 (the cells Cl(2,1) and Cl(3,2)); for the ℂ class they generate O(Q) ≅ Sp_{2m}(2). (2) Largest transvection length for n ≤ 6: 2, 1 at n = 2; 3, 2, 2 at n = 3; 4, 4 at n = 4; 5, 5, 6 at n = 5; 7 for O⁺₆(2) and 6 for O⁻₆(2) at n = 6. (3) So 'at most n mirrors' (Cartan–Dieudonné over ℝ) does not carry over to 𝔽₂: the class of Cl(3,3), Cl(4,2), Cl(0,6) needs 7 > 6 transvections and the class of Cl(3,2) needs 6.",
    status: 'range', statusNote: "Generation and lengths proved exhaustively for every class with n ≤ 6 (breadth-first search of the Cayley graph); generation for general n reduced to Dieudonné's theorem (1948; recalled, Taylor ch. 11 not consulted); no hand proof of the O⁺₄(2) exception (the exhaustive count is the proof); no general length formula.",
    verifier: 'gaps', verifierNote: "Verified with gaps, all declared: generation except O⁺₄(2) and lengths up to 7 > n at n = 6 confirmed by an own breadth-first search; general n rests on Dieudonné; the 'Resolution' paragraph is garbled but reaches the right reason; 4/4 mutants killed.",
    script: 'check_T12.py', checks: "For each 𝔽₂ class with n ≤ 6, a breadth-first search of the transvection group: generation for every non-degenerate class except O⁺₄(2) and index 2 there (36 of 72; 4 of 8 for the Cl(2,1) class; 576 of 1152 for the Cl(3,2) class); the exact length table. Prints ALL 7 CHECKS PASSED (needs f2lib.py; about 10 s).",
    usedFor: ['MAP-022', 'RSN-007', 'RSN-023', 'EQN-014', 'LAB-012'],
    corrections: [
      "Lengths are tabulated for n ≤ 6 only; no general-n bound is claimed.",
      "No hand proof of the O⁺₄(2) exception (Dickson invariant): the exhaustive count stands in.",
      "The 'Resolution' paragraph of the proof is self-contradictory as written; the right reason is that the nonsingular vectors of the O⁺₂(2) quotient span only one functional, so the kernel part is 2¹, not 2²."
    ]
  },
  {
    id: 'T13', title: 'E₈ ⊃ E₆ × A₂, the three 27s, E₇ ⊃ A₂ × A₅, and the 27-point graph',
    statement: "(1) Every root of E₈ has exactly 56 roots at inner product −1; the A₂ subsystems number 240·56/12 = 1120. (2) They form a single W(E₈)-orbit, and the roots orthogonal to any one of them form an E₆ (72 roots). (3) Relative to one A₂: 240 = 72 + 6 + 6 × 27, the six classes of 27 being the roots whose projection to the A₂ plane is one of the six minuscule weights; so 248 = (78,1) + (1,8) + (27,3) + (27̄,3̄) at the level of weights. (4) On one class of 27 the residual inner products are 1/3 or −2/3; the −2/3 graph is srg(27,10,1,5), the intersection graph of the 27 lines on a cubic surface, and the 1/3 graph is its complement, the Schläfli graph srg(27,16,10,8). (5) Inside E₇ every A₂ has complement A₅ (30 roots); the 126 roots project as 30 + 6 + 90 and the 56 split as 18 + 18 + 20 = (3,6) + (3̄,6̄) + (1,20). Every A₂ of E₈ has an E₆ complement; 'a different A₂' is true inside E₇ only.",
    status: 'proved', statusNote: "(1) by hand; (2), (4), (5) by exhaustive computation (finite statements; the hand route through W(E₈)-transitivity is recalled); (3) proved at the level of roots, the identification of each class with the 27-module of e₆ standard (recalled). Whether Furey's End(V) contains this A₂ stays open.",
    verifier: 'verified', verifierNote: "56 partners, 1120 A₂'s in one orbit, the E₆ complement, 6 × 27, srg(27,10,1,5) with the Schläfli complement, E₇ 30/6/90: all recomputed; 5/5 real mutants killed.",
    script: 'check_T13.py', checks: "D₈⁺ in doubled integer coordinates: 56 partners per root, 1120 A₂'s, a breadth-first orbit under the 120 reflections, 72 orthogonal roots forming E₆ (determinant 3, branched diagram), the projection classes 6 × 27, the graph parameters, the E₇ counts. Prints ALL 302 CHECKS PASSED (needs f2lib.py).",
    usedFor: ['RSN-004', 'GOS-003', 'MAP-009'], corrections: []
  },
  {
    id: 'T14', title: "Hamming [8,4,4], Turyn's Golay [24,12,8], and the Golay code as a Lagrangian of Cl(24,0)",
    statement: "(1) The extended Hamming code (generator 1 + x + x³ plus parity) is RM(1,3) up to a coordinate permutation; weight enumerator 1 + 14x⁴ + x⁸; |Aut| = 1344 = |AGL(3,2)|. (2) With H′ the extended code of the reciprocal polynomial, H ∩ H′ = {0, 1}, and Turyn's G = {(a + x, b + x, a + b + x)} is a [24,12,8] doubly-even self-dual code with enumerator 1 + 759x⁸ + 2576x¹² + 759x¹⁶ + x²⁴ (second Pless moment). (3) G is totally singular and maximal for the label form of Cl(24,0): Witt index 12, 2²³ + 2¹¹ singular vectors. (4) A doubly-even self-dual code of length n is exactly an n/2-dimensional totally singular subspace of (𝔽₂ⁿ, Q_{Cl(n,0)}) containing the label 1…1, and one exists iff 8 | n: 'Type II codes only in lengths 8k' reads 'the label form of Cl(n,0) has a Lagrangian through the pseudoscalar iff the clock c = n is 0 mod 8'. (5) The 759 octads form a Steiner system S(5,8,24).",
    status: 'proved', statusNote: "All five parts proved. The route to 'Type II iff 8 | n' through the Clifford label form is elementary and, as far as we know, not in print. M₂₄, Co₁, the Monster, Leech minimality and the uniqueness of the Golay code stay standard (recalled).",
    verifier: 'verified', verifierNote: "Hamming/RM(1,3), |Aut| = 1344, the enumerator by the Pless moment (recomputed 759/2576), the Lagrangian of Cl(24,0), Type II iff 8 | n, S(5,8,24): all correct; 5/5 mutants killed.",
    script: 'check_T14.py', checks: "Builds H, H′, RM(1,3); brute-force Aut over all 8! permutations (1344); H ∩ H′; the Turyn code: size, enumerator, doubly even, self-orthogonal basis, Pless formula; Q and the polar form vanish on G; Gauss sum 2¹² and the singular count by binomial sums; S(5,8,24) over all 42504 five-sets; the 8 | n criterion for n = 2..64 realised by copies of H; the Leech shape arithmetic. Prints ALL 54 CHECKS PASSED (needs f2lib.py).",
    usedFor: ['LAB-009', 'LAB-010', 'LAB-013', 'LAB-014', 'PAG-029', 'PAG-030', 'RSN-031'], corrections: []
  },
  {
    id: 'T15', title: 'States and the probability rule with null generators',
    statement: "Let J be the span of the labels of Cl(p,q,r) with a null bit; a state is a positive normalised functional for an involution. Theorem 1 (r = 0): for the dagger involution e_a† = e_a⁻¹, L_{x†} = L_xᵀ and ⟨x†x⟩₀ = Σ x_a²; the scalar part is a faithful tracial state, unique iff Cl(p,q) is simple; every hermitian functional is ⟨ρx⟩₀ with ρ = ρ†, positive iff ρ ≥ 0; in Cl(3,0) the states are ρ = (1 + v)/2 with |v| ≤ 1 and the Born rule is 2⟨ρP⟩₀ = (1 + v·u)/2; the top-blade form λ = −⟨ωx⟩₀ is a Frobenius form, not a state. Theorem 2 (r ≥ 1), for every involution: every positive (over ℝ: positive hermitian) functional vanishes on J; the states of Cl(p,q,r) are exactly those of Cl(p,q); the top-blade form is never positive. The scalar part remains a state for the dagger involution; the radical adds Grassmann observables with expectation 0 and an indefinite pairing (the Berezin integral).",
    status: 'proved', statusNote: "Theorems 1, 2 and the corollary proved; the Berezin identification is a definition (recalled). Over ℝ the word hermitian cannot be dropped (counterexample in Cl(0,0,1)). Composite systems are not treated.",
    verifier: 'gaps', verifierNote: "Verified with gaps: the Cauchy–Schwarz chain is airtight and the top-blade form is never a state; GAP in the wording: 'the scalar part remains a state' holds for the dagger involution only (reversion is not positive on Cl(0,2), conjugation not on Cl(1,1)); the atlas wording must name the involution. 5/5 mutants killed.",
    script: 'check_T15.py', checks: "Positivity tested exactly as a finite problem (the Gram matrix w(e_b* e_a) is positive semidefinite): four involutions on all 34 signatures n ≤ 4; L_{x†} = L_xᵀ for r = 0; the Bloch ball and the Born rule in Cl(3,0) on 200 random v; for all 20 null signatures n ≤ 4 every positive base point has zero Gram diagonal on J and every hermitian perturbation supported on J breaks positivity; the top-blade form is never positive-hermitian; the Cl(0,0,1) counterexample; tracial functionals on all 20 cells n ≤ 5. Prints 'check_T15: 4648 of 4648 assertions hold' (needs clC.py).",
    usedFor: ['SPN-004', 'NUL-004'],
    corrections: ["'The scalar part remains a state' must say 'for the dagger involution e_a* = e_a⁻¹': with reversion ⟨x̃x⟩₀ is not positive on Cl(0,2), nor is Clifford conjugation on Cl(1,1); Theorem 2's 'every involution' concerns only the vanishing on J."]
  },
  {
    id: 'T16', title: 'Dirac-type symbol determinants and the sign remark (F9 / F12)',
    statement: "Let P = Σ k_i e_i in Cl(p,q,r), Q(k) = P² = Σ ε_i k_i², V a real module of dimension N. (1) (P − m)(P + m) = Q(k) − m² for every signature. (2) If p + q ≥ 2, or (p,q) = (0,1), or V is ℤ₂-graded, then det(P − m | V) = (m² − Q(k))^{N/2} as polynomials; exponent 2^{n−1} on the regular module; the exceptions are (p,q) = (1,0) with an ungraded module and the trivial p = q = 0 odd-dimensional case. The determinant never sees a momentum along a null generator (the F12 row 'm is frozen out' is a theorem), and det L_x = (det L_x̄ on Cl(p,q))^{2^r}. (3) In Cl(3,1) with η = diag(−1,1,1,1) the real operator γ·∂ − m has the physical shell E² = |k|² + m² and the printed (iγ·∂ − m) is tachyonic; in Cl(1,3) the roles swap; the i is the Fourier i, never an element of the algebra. Hestenes' T_m(ψ) = pψ + mψγ₀ on the even part of Cl(1,3) has det T_m = σ(p² − m²)⁴, σ = ±1 fixed by the blade order.",
    status: 'proved', statusNote: "All parts proved for every signature and every module (m² − Q is irreducible in ℝ[k,m] when its rank is at least 3, and the polynomial ring is a UFD); the F12 correction of 5 October is now a theorem, not only a numerical check.",
    verifier: 'verified', verifierNote: "det = (m² − Q)^{N/2} for every module when p + q ≥ 2, the (1,0) exception, null momenta invisible, the 2^r power law, the Cl(3,1) shells and Hestenes' (p² − m²)⁴: correct; nit: p = q = 0 with an ungraded module of odd dimension is a second, trivial exception. 5/5 mutants killed.",
    script: 'check_T16.py', checks: "Exact rational determinants on the regular module for all 55 signatures n ≤ 5 with random integer (k, m), null momenta included; det L_x = (det L_x̄)^{2^r} in 8 null signatures; explicit minimal modules of every Cl(p,q) with n ≤ 5 found by a Kronecker-word search, with det(P − m) = (m² − Q)^{N/2} exactly (Cl(1,0) on ℝ gives k − m); Hestenes 8×8 with one sign on 25 samples; Cl(3,1) with real 4×4 gammas on 20 integer samples and the numerical zero at E = 0.9327 for k = (0.3, −0.2, 0.5), m = 0.7. Prints 'check_T16: 391 of 391 assertions hold' (needs clC.py).",
    usedFor: ['MAP-017', 'EQN-008', 'RSN-027', 'NUL-010', 'ATL-010'],
    corrections: ["T16.md, Theorem 2(c): besides (p,q) = (1,0) with an ungraded module, the case p = q = 0 with an ungraded module of odd dimension (det = (−m)^N) is a second, trivial exception to the formula."]
  },
  {
    id: 'T17', title: 'Bivector squares and the rotation / boost / translation trichotomy (D3)',
    statement: "In Cl(p,q,r) let B be a bivector. (a) B² = S + B∧B with S = −Σ ε_i ε_j B_ij², in every signature; B² is a scalar iff B is simple (always when n ≤ 3). (b) For simple B = u∧v, s = B² = −det Gram(u,v): s < 0 rotation, s > 0 boost, s = 0 unipotent (the vector generator D satisfies D³ = sD). The unipotent case has three kinds: translation (the plane's radical lies in the radical of the whole space); null rotation (the only s = 0 kind inside a non-degenerate cell); totally null plane (Gram = 0), which needs two independent null vectors (p,q ≥ 2; or p,q ≥ 1 with r ≥ 1; or r ≥ 2). (c) At n = 4, B∧B = 2 Pf(B) e₁₂₃₄; the roots of λ² − Sλ + Pf(B)²I² are non-real for some B only in Cl(2,2) among the 15 signatures with n = 4; for λ₁ ≠ λ₂ the commuting decomposition B = b₁ + b₂ exists, is unique, and is b_i = B(T − λ_i)/(λ_j − λ_i), T = B∧B/2; Mozzi–Chasles is the case λ = S, 0 in Cl(3,0,1).",
    status: 'proved', statusNote: "(a), (b) proved; (c) proved for n = 4 when λ₁ ≠ λ₂; also proved: with the strain S(h) = hᵀηh − η of ATL-018, S = 0 iff h ∈ O(η) and to first order tr(η⁻¹S) = 2(det h − 1). GAP: the isoclinic case λ₁ = λ₂ and the general-n invariant decomposition (Roelfs–De Keninck) are not proved here. The decision D3 must read 'translation, null rotation or totally null plane' where it says 'translation' for s = 0.",
    verifier: 'gaps', verifierNote: "Verified with gaps: the proofs of (a)–(d) and Mozzi–Chasles are correct; two side remarks were wrong and are corrected here (kind (iii) does not need p,q ≥ 2 once r ≥ 1, Cl(1,1,1) has (e₁+e₂)∧e₀; there are 15, not nine, n = 4 signatures). 6/6 mutants killed.",
    script: 'check_T17.py', checks: "All 83 signatures n ≤ 6 with random integer bivectors: B² has grades 0 and 4 only, with the stated parts; B∧B = 0 iff rank ≤ 2; for simple u∧v in every signature n ≤ 5: B² = (u·v)² − u²v², D³ = sD, the closed forms of exp, the three s = 0 kinds with an example each; n = 4: the Pfaffian identity, the AM–GM bound in the definite cells, complex roots only in Cl(2,2) (193 of 400 random bivectors), the decomposition formula in the five r = 0 cells; Mozzi–Chasles on 50 random Cl(3,0,1) bivectors; the Riesz example; the strain trace. Prints 'check_T17: 12009 of 12009 assertions hold' (needs clC.py).",
    usedFor: ['LAB-003', 'LAB-004', 'PAG-031', 'RSN-010', 'RSN-013', 'RSN-014', 'ATL-011', 'ATL-018', 'MAP-026', 'EQN-018', 'SPR-002'],
    corrections: [
      "T17.md (c)(iii): a totally null plane needs two independent null vectors, i.e. p,q ≥ 2, or p,q ≥ 1 with r ≥ 1, or r ≥ 2; 'exists only when both p,q ≥ 2' is false once r ≥ 1 (Cl(1,1,1) has (e₁+e₂)∧e₀, Cl(0,0,2) has e₀∧e₀′). The proposed atlas sentence 'a totally null plane (from Cl(2,2) on)' needs 'among the non-degenerate cells'.",
      "T17.md (d): there are 15 signatures with n = 4 (5 with r = 0, 10 with r ≥ 1), not nine; the proof covers all 15, the script tests 8 of them.",
      "The decision D3 and the candidate list say 'translation' for B² = 0; this must read 'translation, null rotation, or totally null plane'."
    ]
  },
  {
    id: 'T18', title: 'Null hypersurfaces, the horizon algebra, and hyperbolicity (step 14, Schuller F2)',
    statement: "(a) A regular level set Σ = {f = c} of a non-degenerate metric is null at p iff g⁻¹(df, df)(p) = 0; the normal then spans the radical of TΣ and is tangent (a photon standing still); for a Lorentzian metric the induced form is (n−2, 0, 1): the tangent algebra is Cl(0, n−2, 1) (time-positive convention). (b) g^{rr} = 0 is this test only where r is a regular function (the Ellis throat has dr = 0 and is timelike); g_tt = 0 is no criterion in general (light cylinder). (c) For a hypersurface-orthogonal Killing field ξ, g⁻¹(dξ², dξ²) = 2ξ²F with F = ∇_aξ_b∇^aξ^b (NUL-003 with n = ½ dξ²). (d) In Cl(1,1), (e_r + g e_t)² = g² − 1: −1 outside, 0 on the horizon, +1 inside (a paired null). (e) In Cl(0,k,1) the blades through the null bit form an ideal J, J·J = 0, quotient Cl(0,k). (f) A quadratic principal polynomial is hyperbolic iff its signature is Lorentzian.",
    status: 'proved', statusNote: "All parts proved as local, pointwise statements; nothing global about horizons is claimed. Also proved in (f): the hyperbolic covectors are the timelike ones (all non-null ones at n = 2), the Maxwell symbol on bivectors has a kernel of dimension n − 2 exactly at null k, and the Dirac symbol has det = (−Q)^{N/2}. the report's 'two ladders', the families Cl(1,d) and Cl(k,1) (one Lorentzian class in two sign conventions, not two classes), found there by search for n = 2..7, hold for all n. Wald's identity for static Killing fields is re-derived, not quoted.",
    verifier: 'verified', verifierNote: "Null criterion, the (0, n−2, 1) tangent algebra, the three g^{rr} forms, the Killing identity (re-derived and checked on Schwarzschild), the Maxwell kernel n − 2, hyperbolic iff Lorentzian: correct; two ok(…) lines of the script are tautologies (cosmetic). 6/6 mutants killed.",
    script: 'check_T18.py', checks: "Random metrics of every signature, n = 2..6: a null covector gives a degenerate hyperplane whose radical is g⁻¹N, generic covectors do not, and the Lorentzian induced signature is (n−2, 0, 1); the three forms of g(dr,dr) in exact fractions at five radii; the Ellis throat and the light cylinder; the Killing identity on 10 random static 3-metrics by finite differences (relative error below 1e−5); Cl(0,k,1) for k = 0..4; hyperbolic directions exist only for min(s,t) = 1 and are the timelike ones; the Maxwell kernel in four cells. Prints 'check_T18: 2023 of 2023 assertions hold' (needs clC.py).",
    usedFor: ['NUL-001', 'NUL-002', 'NUL-003', 'NUL-004', 'NUL-008', 'NUL-010', 'MAP-028', 'EQN-020', 'RSN-015', 'RSN-017', 'LAB-005', 'LAB-007', 'PAG-011'],
    corrections: ["Check script: the lines ok((1 − g²) + g² == 1 and …) and ok(0.0 == 0.0/sqrt(b·b)) are tautologies; the Painlevé–Gullstrand inverse metric is written down, not computed (the claim itself is right and was recomputed by the verifier)."]
  },
  {
    id: 'T19', title: 'The Floquet band trio and the spring on the cube (step 12, Schuller F13)',
    statement: "(1) For M ∈ SL(2,ℝ) (the unit multivectors of Cl(2,0)) with g = ⟨M⟩₀, X = M − g: X² = g² − 1 = a² + b² − c² is a scalar; |tr M| < 2 iff X² < 0 (elliptic, M^N bounded), = 2 iff X² = 0; then M is parabolic (linear growth) iff X ≠ 0, while M = ±I (X = 0) has bounded powers, > 2 iff X² > 0 (hyperbolic, exponential); tr M^N = 2T_N(tr M/2). (2) For ψ″ = (V − E)ψ with V periodic the one-period matrix is in SL(2,ℝ): band iff X² < 0, gap iff X² > 0, edge iff X² = 0 with X ≠ 0 (for M = ±I, X = 0: two bands touch and no gap opens); the pieces of a piecewise-constant potential are cos + n·sin (n² = −1), cosh + n·sinh (n² = +1), 1 + l·n (n² = 0); the spectrum as the union of the closed bands is Floquet–Bloch (recalled). (3) Unit masses on the 2ⁿ vertices, unit springs on the edges: L = nI − A has the Walsh eigenbasis, ω² = 2j with multiplicity C(n,j). (4) The signed network D = Σ L_{e_i} on Cl(n,0) has D² = nI, tr D = 0, flux π through every face: eigenvalues ±√n of multiplicity 2^{n−1}; K = nI − D has two levels n ∓ √n.",
    status: 'proved', statusNote: "Theorems 1, 3, 4 proved; Theorem 2 proved for the one-period matrix and the solutions of the ODE, the operator-spectrum sentence reduced to the standard Floquet–Bloch theorem (Eastham 1973; Reed–Simon IV, XIII.16). Reading the three classes as 'the trio' stays ours.",
    verifier: 'verified', verifierNote: "SL(2,ℝ) trichotomy, Chebyshev, Hill pieces, the cube spring 2j × C(n,j), the signed network D² = nI with flux π: correct; 5/5 mutants killed; the closed-band statement is reduced, not re-derived.",
    script: 'check_T19.py', checks: "300 random SL(2,ℤ) matrices exactly: X² = (g² − 1) = a² + b² − c² and tr M^N = 2T_N(g) for N ≤ 12; the growth of M^N per class; a Kronig–Penney potential: the exact piece product against an RK4 integration (1e−7), det = 1, piece generators squaring to −1, +1, 0, five band edges in (0, 90] by bisection with X² = 0 and an eigenvalue ±1 at each, the Dirac comb formula on three parameter sets; Walsh modes and multiplicities for n = 1..8; D symmetric with D² = nI, tr D = 0, flux −1 on every face, two K-levels for n = 1..7. Prints 'check_T19: 8881 of 8881 assertions hold' (needs clC.py).",
    usedFor: ['MAP-026', 'EQN-018', 'SPR-001', 'SPR-002', 'SPR-003', 'SPR-004', 'PAG-022'], corrections: ['Statement (1) as first written was too strong: M = ±I has X = 0 and bounded powers (E-058).']
  },
  {
    id: 'T20', title: 'Fock space as the label set: Cl(m,m) = End Λ(ℝ^m)',
    statement: "On Λ(ℝ^m) with basis e_S let c_i⁺ be the wedge with e_i and c_i the contraction (Jordan–Wigner signs).(a) In the bit rule with squares ε, left multiplication by e_i on the label space is L_{e_i} = c_i⁺ + ε_i c_i: square 0 gives creation, ±1 give c⁺ ± c. (b) The CAR {c_i, c_j⁺} = δ_ij, {c_i, c_j} = {c_i⁺, c_j⁺} = 0 hold; Pauli exclusion is e_i² = 0. (c) c⁺ + c and c⁺ − c give an isomorphism Cl(m,m) → End_ℝ(Λ) = M_{2^m}(ℝ); the label basis is the Fock basis and the number operator is the popcount. (d) Λ has super-dimension 0, which XY + YX = 1 needs for odd X, Y (str(XY + YX) = 0), while [a, a⁺] = 1 has no finite-dimensional solution. (e) In the bit-rule Cl(m,m), (e_i ± f_i)/2 are Witt pairs, mapped to c_i⁺ and c_i: paired nulls, not null generators. (f) The bivectors of Cl(m,m) are m Cartan elements and 2m(m−1) root vectors of the root system D_m of so(m,m); at m = 8, 112 + 8 = 120.",
    status: 'proved', statusNote: "All parts proved (the CAR also follow from T1's associativity for every ε); standard in substance, the bit-rule formulation (a) is a one-line proof. The shapes card SHP-002 must read '2n null vectors forming n Witt pairs of Cl(n,n)': 2n unpaired null generators give the exterior algebra, whose radical has dimension 2^{2n} − 1.",
    verifier: 'verified', verifierNote: "L_{e_i} = c⁺ + εc, the CAR, Cl(m,m) = End Λ by matrix units, sdim 0, the Witt pairs, the D_m roots: correct; 4/4 mutants killed.",
    script: 'check_T20.py', checks: "Exact integer matrices for m = 1..5: L_{e_i} in Cl(0,0,m) is c_i⁺ and its transpose is the separately coded contraction; L_{e_i} in Cl(m,0) and Cl(0,m) equal c⁺ ± c exactly; all CAR; the 2m generators of Cl(m,m); rank 4^m of the products (m ≤ 4) and every matrix unit; c_S⁺|0⟩ = e_S with sign +1; number operator = popcount; sdim = 0 and the supertrace of anticommutators of random odd matrices; Witt pairs in the bit-rule Cl(m,m) for m ≤ 3; roots and Cartan elements span the bivectors for m = 2..4. Prints 'check_T20: 2015 of 2015 assertions hold' (needs clC.py).",
    usedFor: ['SHP-002', 'SHP-005', 'GOS-002', 'MAP-012', 'FUR-003'], corrections: []
  }
];

// Errata: one entry per error found in our own delivered reports, derivations or atlas statements; dated when found; never edited away. Newest last (the page shows them newest first).
export const ERRATA = [
  {
    id: 'E-001', date: '2026-10-05', where: 'Schuller report F12 and the message of check G4b (fibre_check.py); F9',
    wrong: "'The physical sign needs a central unit i, which M₄(ℝ) does not have; so in the real algebra that i has to come from the fibre, the complex structure of the wave function.'",
    right: "In Cl(3,1) = M₄(ℝ) with real gamma matrices (γ₀² = −1) the real operator γ·∂ − m already has the physical mass shell E² = |p|² + m²; (γ·∂ − m)(γ·∂ + m) is minus the Klein–Gordon operator, and on a plane wave the i is the Fourier i of ∂ → ip, not an element of the algebra. The notes' printed (iγ·∂ − m) with η = diag(−1,1,1,1) is tachyonic, E² = |p|² − m²: the slip is the factor i, not the cell.",
    foundBy: 'the physicist reviewer (round 2); re-checked by our own numerical test and by T16',
    guard: 'fibre_check.py G4b (exact assertion on five Pythagorean shells; mutant M20 caught 20 of 20) and check_T16.py part E (the zero at E = 0.9327 for k = (0.3, −0.2, 0.5), m = 0.7)',
    gradeChange: 'F12 stays checked/ours, the F9 flag stays; the wording of F12 and G4b corrected; 35 fibre checks unchanged'
  },
  {
    id: 'E-002', date: '2026-10-05', where: 'Category report N3, question QA5, the message of check C2, matrix row C6',
    wrong: "'Frobenius forms are a torsor under the central units' (recalled), and the reason given for the non-symmetry at even n with a null generator ('an odd unit flips the null generators but cannot flip the others').",
    right: "All Frobenius forms are λ(u·) with u any unit, a torsor under the whole unit group; only the symmetric forms, when they exist, are a torsor under the central units (counterexample: u = 2 + e₁ in Cl(3,0) is a non-central unit and λ(u·) is a non-symmetric Frobenius form). The non-symmetry reason is that every element conjugating the grade involution lies in the radical, hence is not a unit (T3).",
    foundBy: 'the mathematician reviewer (round 2) and our own derivation T3 (lane A, verified)',
    guard: 'check_T3.py item TOR (non-degenerate iff u is a unit; symmetric iff u central for odd n; the explicit counterexample)',
    gradeChange: 'N3 stays checked (F1–F4 were right); the recalled torsor sentence is withdrawn; the C2 message and row C6 need rewording'
  },
  {
    id: 'E-003', date: '2026-10-05', where: 'Category report P5 refinement (3), N10, question QA5; candidate list T15',
    wrong: "'The scalar-part rule for probabilities needs the top-blade form when null generators are present.'",
    right: "Every state (positive normalised functional, for any involution) vanishes on the labels that contain a null bit, so the states of Cl(p,q,r) are exactly those of Cl(p,q); the top-blade form is a Frobenius duality and never a state; the scalar part stays a state for the dagger involution (T15, verified).",
    foundBy: 'our own derivation T15 (lane C); the physicist reviewer agreed that no atlas statement depends on the wrong sentence',
    guard: 'check_T15.py part C (every hermitian perturbation supported on the radical breaks positivity; the top-blade form is never positive-hermitian)',
    gradeChange: 'P5(3) withdrawn; QA5 answered (no); SPN-004 reworded to name the dagger involution'
  },
  {
    id: 'E-004', date: '2026-10-05', where: 'Category report check K4c, finding N2, matrix rows C5 and W1',
    wrong: "'The real part of the Gauss sum gives the type', and the Frobenius–Schur indicator quoted as +1, 0, −1 per summand.",
    right: "What the check computes is Re S + Im S = Re((1 − i)S) with S = (1+i)^p(1−i)^q; at c = 2 the real part alone is 0. In the normalisation ν = Σ e_a² = kN·ind(D) the quaternionic value is ind(ℍ) = −2 per simple summand, because the skew part of ℍ has dimension 3 (T4 (iv)).",
    foundBy: 'our own derivation T4 and the lane A verifier',
    guard: 'check_T4.py items GS and FS (ν = kN·ind(D) against the mod-8 table for p + q ≤ 10)',
    gradeChange: 'K4c stays E, wording corrected'
  },
  {
    id: 'E-005', date: '2026-10-05', where: 'Category report N1 and check G1 (the grading lift); candidate list T2',
    wrong: "'The largest free abelian grading group of Cl(p,q,r) has rank r' (and 'the ℤ₂-grading lifts to ℤ exactly at the null generators') stated for arbitrary gradings.",
    right: "True for gradings in which every label is homogeneous: the universal group is ℤ₂^{p+q} × ℤ^r (T2, proved). False for arbitrary gradings: M₂(ℝ) = Cl(2,0) carries a ℤ-grading by matrix-unit degree.",
    foundBy: 'our own derivation T2 (lane A, verified)',
    guard: 'check_T2.py item GL guards the label-homogeneous version only (and is a tautology for the general claim): none yet for the general statement',
    gradeChange: 'G1 stays checked with the qualifier added; the finding N1 is reworded'
  },
  {
    id: 'E-006', date: '2026-10-05', where: 'Category report P5 refinement (1) and check K2; atlas LAB-005, LAB-007, PAG-031',
    wrong: "The horizon vector of step 16 and the null generator of step 14 both called 'the 0 label' without saying that they are different kinds of null.",
    right: "The tangent algebra Cl(0, n−2, 1) of a null hypersurface has an unpaired null (the radical); the horizon vector e_t − e_r in the ambient (t,r) plane is a paired null of the non-degenerate Cl(1,1), not a label 0 (T18 (d)). The atlas cards must say which.",
    foundBy: 'the category lens (round 2) and both reviewers',
    guard: 'check_T18.py parts B and E; the LAB-007 wording fixed by the spec (unpaired in the tangent algebra Cl(0,2,1) of the surface, paired inside Cl(1,1))',
    gradeChange: 'LAB-007 stays ours, wording made exact'
  },
  {
    id: 'E-007', date: '2026-10-05', where: 'Category report matrix row C13',
    wrong: "'W(E_n) mod 2 = O(Q)' graded as recalled.",
    right: "The atlas checks it exactly (groups_check.py part B, n = 3..8) and T9 proves it, together with more: E_n/2E_n carries the label form of Cl(n,0) for all n ≥ 3, A_n/2A_n that of Cl(0,n), they coincide iff 4 | n, and A₆ and E₆ have the same rank and signature but different mod-2 classes.",
    foundBy: 'our own check (round 2)',
    guard: 'groups_check.py part B and check_T9.py part D',
    gradeChange: 'row C13 from recalled to checked and proved'
  },
  {
    id: 'E-008', date: '2026-10-05', where: 'Baez report, matrix row G.1 and the combined matrix (an earlier draft of finding J3)',
    wrong: "'The 27 with inner product 0 form the Schläfli graph srg(27,10,1,5).'",
    right: "srg(27,10,1,5) is the intersection graph of the 27 lines on a cubic surface, the complement of the Schläfli graph srg(27,16,10,8) (which is the inner-product-1 graph, the edge graph of the Gosset polytope 2₂₁). The report text already says so; the matrix row was stale (T13, verified).",
    foundBy: 'a second reading of the Baez report; confirmed by T13',
    guard: 'check_T13.py (graph parameters of both graphs); baez_check.py E (Schläfli graph)',
    gradeChange: 'G.1 stays E; the name corrected'
  },
  {
    id: 'E-009', date: '2026-10-05', where: 'Schuller report rows L9 and M5 and the F1 text (Hodge star)',
    wrong: "'The Hodge star is XOR with 1…1, that is multiplication by the pseudoscalar', stated for every signature.",
    right: "With a null generator the top blade is nilpotent, so multiplication by it is not invertible and is not a metric Hodge star; the complement map is the Frobenius duality of T3, non-degenerate for every signature (category N3, T3 F1). The Schuller check A5 behind the sentence tests Cl(1,3), Cl(4,0), Cl(2,2), Cl(3,1) only, all with r = 0.",
    foundBy: 'our own check (category lens, round 2)',
    guard: 'check_T3.py item F1 (non-degenerate for all 83 signatures n ≤ 6)',
    gradeChange: 'L9 and M5 wording; grades unchanged'
  },
  {
    id: 'E-010', date: '2026-10-05', where: 'Candidate list T11 (our own note)',
    wrong: "'Cl(6,0): 27 points and 45 lines, the Klein quadric Q⁺(5,2).'",
    right: "The Klein quadric Q⁺(5,2) has 35 points, 105 lines and 30 planes and is the class of Cl(3,3), Cl(4,2), Cl(0,6); Cl(6,0) is the elliptic quadric Q⁻(5,2) with 27 points and 45 lines (T11; the category report's numbers were right).",
    foundBy: 'our own derivation T11 (lane B, verified)',
    guard: 'check_T11.py (counts of both classes)',
    gradeChange: 'none for the report; the candidate note corrected'
  },
  {
    id: 'E-011', date: '2026-10-05', where: 'Decisions D3 and D4 of the steps 15–17 brief',
    wrong: "D3: 'translation' for a simple bivector with B² = 0. D4: 'Cl(p,q,r) = Cl(p,q) ⊗ Λ(ℝ^r)' as a plain tensor product.",
    right: "B² = 0 for a simple bivector means translation, null rotation, or a totally null plane (T17 (c)); the product in D4 is the graded tensor product (T2 (1)). A wording gap, not an error in a statement.",
    foundBy: 'our own derivations T17 and T2',
    guard: 'check_T17.py part C (the three s = 0 kinds); check_T2.py item GT',
    gradeChange: 'wording of D3 and D4; no grade changes'
  },
  {
    id: 'E-012', date: '2026-10-05', where: 'Round-1 take on GEN-003 (the later candidate), and the spec of GEN-002',
    wrong: "The round-1 reason for the later candidate said that the two signs of Cl(1,1) 'are exchanged by an automorphism'.",
    right: "No automorphism of Cl(1,1) exchanges e and f (e² = +1, f² = −1); the swap ñ → −ñ is an anti-isometry, the cell is its own mirror. 'A gauge choice' is exact for Cl(1,1) only; the physics wording is 'a convention for this pair'. GEN-002 calls [1,+1] space-like and [1,−1] time-like while MAP-001 has time squaring to +1: a convention to reconcile later. The Genesis wording itself is frozen.",
    foundBy: 'the mathematician reviewer (round 2)',
    guard: 'none yet (frozen wording; recorded in GENESIS_NOTE as a later candidate)',
    gradeChange: 'GEN-003 flags unchanged (standard, checked, ours)'
  },
  {
    id: 'E-013', date: '2026-10-05', where: 'Genesis node 7 (GEN-008), frozen wording',
    wrong: "'This is the same mechanism as at Nodes 1, 3, 5 with a larger block' (the central involution ω² = +1 splitting Cl(4,3)).",
    right: "At nodes 1, 3, 5 (Cl(0,0,1), Cl(1,1,1), Cl(2,2,1)) the top blade is central but contains the null bit, so it squares to 0 and splits nothing; the mechanism holds for the signed odd cells Cl(1,0), Cl(2,1), Cl(3,2). Checked: any label containing a null bit squares to 0 (T2).",
    foundBy: 'the mathematician reviewer (round 2); confirmed by the radical computation of T2',
    guard: 'check_T2.py item RAD (labels with a null bit are nilpotent); none for the wording (frozen, recorded as a later candidate)',
    gradeChange: 'GEN-008 flags unchanged'
  },
  {
    id: 'E-014', date: '2026-10-05', where: 'Atlas GOS-002 and SHP-005 (orthoplex and Fock view)',
    wrong: "'The 112 edges are the roots of so(16)' for the bivectors of 16 null generators, and 'the 40 edges are the roots of so(10)' for Cl(5,5).",
    right: "The bivectors of the real Cl(8,8) span the split form so(8,8) and those of Cl(5,5) the split form so(5,5); the compact so(16) and so(10) have the same complexified root systems (D₈, D₅) but are other real forms. The counts are right; the real form is named by the spec.",
    foundBy: 'the mathematician reviewer (round 2)',
    guard: 'check_T20.py part I (roots ±e_i ± e_j of D_m in Cl(m,m)); the spec instructions for GOS-002 and SHP-005',
    gradeChange: 'GOS-002 adds ours; SHP-005 split into a standard+checked line and an ours+open line'
  },
  {
    id: 'E-015', date: '2026-10-05', where: 'Atlas YM-001 and the yangmills selfcheck message',
    wrong: "'The closed triangles of the commutator graph are the so(3) subalgebras' and 'every non-commuting pair lies in exactly one triangle'.",
    right: "True for index triples {B_ab, B_bc, B_ac}; from m = 4 the graph also has open triangles {B_ab, B_ac, B_ad}, which are not subalgebras. The script counts index triples only.",
    foundBy: 'the mathematician reviewer (round 2)',
    guard: 'yangmills_selfcheck.py counts the C(n,3) index triples; the spec rewords YM-001',
    gradeChange: 'YM-001 flags standard, checked (was checked)'
  },
  {
    id: 'E-016', date: '2026-10-05', where: 'Atlas MAP-002 and ATL-024',
    wrong: "'The standard 8-fold classification of types (cross-checked, not derived here)'.",
    right: "Eight graded classes against five ungraded types are two different counts; and the types are recomputed from the squares of the labels for every cell shown (step 15, groups_check.py part A, category K4b, T4), so 'not derived here' understated the atlas's own checks and contradicted PAG-005 and PAG-029.",
    foundBy: 'the mathematician reviewer (round 2)',
    guard: 'groups_check.py part A; check_T4.py TAB and C1; the spec rewords both cards',
    gradeChange: 'ATL-024 split into standard+checked and ours+open lines'
  },
  {
    id: 'E-017', date: '2026-10-05', where: 'Atlas PAG-002, PRJ-001 and RSN-028 (flags)',
    wrong: "Tagged ours only: 'reading blades as faces, cube vertices and labels', 'one extra generator is one more bit', and the pointor/chirality statement of the Hestenes note.",
    right: "Blades as subsets with XOR and a sign is the textbook combinatorial Clifford algebra (KTH notes, Def. 2.4); the extra generator as one more bit is the same construction; the even-spinor form of the Dirac equation is standard space-time algebra. Only the picture choices (faces, bits of the cube, the pointor slice b = 0, chirality as XOR 9) are ours.",
    foundBy: 'the two reviewers (round 2)',
    guard: 'test_claims_sync.mjs on the final flags',
    gradeChange: 'PRJ-001 and RSN-028 gain standard; PAG-002 keeps ours with a note'
  },
  {
    id: 'E-018', date: '2026-10-05', where: 'Baez report, first draft (corrected before delivery by a second reading)',
    wrong: "so(4,2) written for the complex algebra of the Jordan-pair paper (a real-form slip); the E₈ step of the ladder called 3-graded; two statements of novelty (the argument of Lemma 2, the chain of triples) already in the papers; matrix rows K.5, T.4, C.2 graded exact and E.3 graded analogy.",
    right: "The Jordan-pair paper's tables list so(6,ℂ) and its compact form, not so(4,2); the E₈ step is 5-graded (240 = 126 + 2·56 + 2); the two arguments belong to the papers; K.5, T.4, C.2 are structural and E.3 is exact.",
    foundBy: 'a second reader who had not seen the work',
    guard: 'baez_check.py block E (grade sizes 56, 27, 16, 10, 6 and the 5-graded first step); the report tests',
    gradeChange: 'K.5, T.4, C.2 from E to S; E.3 from A to E'
  },
  {
    id: 'E-019', date: '2026-10-06', where: 'Derivation T4.md, proof of (ii)',
    wrong: "'A₀ = Cl(p,q−1) or Cl(q,p−1), whose clock is c − 1 or 1 − c.'",
    right: "The clock of the even part is c + 1 or 1 − c (the type table has the symmetry type(c) = type(2 − c)); the table of the eight pairs in the statement is right.",
    foundBy: 'the lane A verifier',
    guard: 'none yet: check C1 would also accept a wrong table (mutant M4 survives)',
    gradeChange: 'T4 verified with gaps; text to be corrected'
  },
  {
    id: 'E-020', date: '2026-10-06', where: 'Derivation T4.md, statement (iv)',
    wrong: "'ν is the Frobenius–Schur indicator of the regular representation of the finite group G = {±e_a}.'",
    right: "ν is the indicator of the representation of G on the algebra by left multiplication (the regular A-module); for the regular representation of G the count is #{g: g² = 1}, which is not ν.",
    foundBy: 'the lane A verifier',
    guard: 'check_T4.py item FS ties ν to the type table; the wording itself is not guarded',
    gradeChange: 'T4 verified with gaps; text to be corrected'
  },
  {
    id: 'E-021', date: '2026-10-06', where: 'Derivation T8.md, statement 3 (n = 2)',
    wrong: "'The commutative square is a tilted algebra of type D₄ with 12 indecomposables.'",
    right: "11 indecomposables: the 11 positive roots of its positive-definite Tits form, all thin.",
    foundBy: 'the lane A verifier',
    guard: 'none yet (a recalled statement; the script does not count indecomposables)',
    gradeChange: 'T8 verified with gaps'
  },
  {
    id: 'E-022', date: '2026-10-06', where: 'Derivation T6.md, parts (b) and (c)',
    wrong: "'Rank 2^{n−1} in every degree' for the Koszul complex, and the bit-rule sign given as the upper-triangular representative Σ_{i<j} a_i b_j.",
    right: "The complex has total rank 2^{n−1} and rank C(n−1,k−1) on degree k; the bit-rule sign is Σ_{j<i} a_i b_j, the transpose of the stated representative (cohomologous, not equal).",
    foundBy: 'the lane A verifier',
    guard: 'check_T6.py item KZ asserts the total rank 2^{n−1} for n ≤ 6; the per-degree ranks and the transpose are not asserted: none yet',
    gradeChange: 'T6 verified with gaps (cosmetic)'
  },
  {
    id: 'E-023', date: '2026-10-06', where: 'Derivation T7.md (title) and the candidate list',
    wrong: "'Tian's algebra is Cl(m,m) or Cl(m,m,1).'",
    right: "The odd truncation on 2m − 1 generators is Cl(m−1,m−1,1); Cl(m,m,1) would have 2m + 1 generators. The body of T7 is right.",
    foundBy: 'the lane A verifier',
    guard: 'check_T7.py item ODD (rank 2^k for k = 1, 3, 5, 7); the title text is not guarded',
    gradeChange: 'T7 verified with gaps (cosmetic)'
  },
  {
    id: 'E-024', date: '2026-10-06', where: 'Derivations T2.md, T3.md and the lane A summary',
    wrong: "'All 119 signatures with n ≤ 6.'",
    right: "There are 83 signatures (p,q,r) with 1 ≤ n ≤ 6; 119 is the count for n ≤ 7. The scripts loop over the right set; only the prose was wrong.",
    foundBy: 'the lane A verifier',
    guard: 'none yet (the count in the prose is not asserted by the scripts)',
    gradeChange: 'none'
  },
  {
    id: 'E-025', date: '2026-10-06', where: 'Check scripts check_T2.py, check_T4.py, check_T8.py (lane A)',
    wrong: "Check items presented as tests that cannot fail: T2 GL and GRA (tautologies), T4 H has okH &= True for ℂ ⊗ ℂ (vacuous, rule unused), T4 C1 checks the distinctness of the pairs rather than the pairs; T2 LOE and T8 TITS (n = 3) do not terminate on some false inputs.",
    right: "The mathematics is unaffected (the verifier recomputed it with own code); the four surviving mutants of the lane A mutation harness (37 mutants, 30 killed by a FAIL line, 2 by timeout, 1 intended control) expose these weak items.",
    foundBy: 'the lane A verifier (mutation harness mut_check_T*.py)',
    guard: 'the mutation logs mut_T2.log, mut_T4.log, mut_T8.log in the verification folder; the scripts themselves: none yet',
    gradeChange: 'T2 and T4 verified with gaps (check only)'
  },
  {
    id: 'E-026', date: '2026-10-06', where: 'ROUND2_STATE (derivation summary) and the candidate list T8 / category E1',
    wrong: "'n = 3 is tubular (3,3,3)'; and the signatures (…, (6,0,2), …) called the Tits form.",
    right: "Only the Coxeter polynomial (x−1)²(x²+x+1)³ and the corank-2 positive semidefinite Euler form have the tubular (3,3,3) profile; tame or derived-tubular at n = 3 is open. The listed signatures are those of the symmetrised Euler form; the Tits form differs from n = 3 on (signature (6,1,1)).",
    foundBy: 'the lane A verifier',
    guard: 'check_T8.py items COX and TITS',
    gradeChange: 'T8 stays reduced with the open part stated'
  },
  {
    id: 'E-027', date: '2026-10-06', where: 'Derivation T17.md, statement (c)(iii) and the proposed atlas sentence',
    wrong: "'Kind (iii), the totally null plane, exists only when both p, q ≥ 2' and 'a totally null plane (from Cl(2,2) on)'.",
    right: "A totally null plane needs two independent null vectors: p,q ≥ 2, or p,q ≥ 1 with r ≥ 1, or r ≥ 2; Cl(1,1,1) has (e₁+e₂)∧e₀ and Cl(0,0,2) has e₀∧e₀′. The atlas sentence needs 'among the non-degenerate cells'.",
    foundBy: 'the lane B/C verifier (own_extra.log)',
    guard: 'none yet (check_T17.py tests a Cl(2,2) example only)',
    gradeChange: 'T17 verified with gaps'
  },
  {
    id: 'E-028', date: '2026-10-06', where: 'Derivation T17.md, statement (d)',
    wrong: "'Among the nine n = 4 signatures.'",
    right: "There are 15 signatures (p,q,r) with n = 4: 5 with r = 0 and 10 with r ≥ 1; the proof covers all 15, the script tests 8 of them.",
    foundBy: 'the lane B/C verifier',
    guard: 'none yet',
    gradeChange: 'none'
  },
  {
    id: 'E-029', date: '2026-10-06', where: "Derivation T15.md, section 'what the atlas may say now'",
    wrong: "'The scalar part remains a state' without naming the involution.",
    right: "It holds for the dagger involution e_a* = e_a⁻¹; with reversion ⟨x̃x⟩₀ is not positive on Cl(0,2), and Clifford conjugation is not positive on Cl(1,1). Theorem 2's 'every involution' concerns only the vanishing on the radical.",
    foundBy: 'the lane B/C verifier',
    guard: 'check_T15.py part A tests four involutions; the SPN-004 wording now names the dagger involution',
    gradeChange: 'T15 verified with gaps'
  },
  {
    id: 'E-030', date: '2026-10-06', where: 'Derivation T11.md, line 56',
    wrong: "'35 = (2³ + 1)(2² − 1)' (which is 27).",
    right: "35 = (2³ − 1)(2² + 1), the number of 2-planes of 𝔽₂⁴.",
    foundBy: 'the lane B/C verifier',
    guard: 'check_T11.py asserts the count 35; the typo is in the prose: none yet',
    gradeChange: 'none'
  },
  {
    id: 'E-031', date: '2026-10-06', where: 'Derivation T16.md, Theorem 2(c)',
    wrong: "'The only exception is (p,q) = (1,0).'",
    right: "Also p = q = 0 with an ungraded module of odd dimension (det = (−m)^N, N odd): a second, trivial exception.",
    foundBy: 'the lane B/C verifier',
    guard: 'none yet',
    gradeChange: 'none'
  },
  {
    id: 'E-032', date: '2026-10-06', where: "Derivation T12.md, proof paragraph 'Resolution'",
    wrong: "A self-contradictory paragraph ('the quotient group is generated, yet the script finds index 2') before the right reason.",
    right: "In the degenerate lift over O⁺₂(2) the nonsingular vectors span only one functional, so the transvections reach a kernel part 2¹, not 2²: index 2 for the class of Cl(2,1). One sentence; the statement is right.",
    foundBy: 'the lane B/C verifier',
    guard: 'check_T12.py (4 of 8 for that class)',
    gradeChange: 'T12 verified with gaps (declared)'
  },
  {
    id: 'E-033', date: '2026-10-06', where: 'Check script check_T18.py, lines 84 and 103',
    wrong: "Two ok(…) lines that cannot fail (the Painlevé–Gullstrand inverse metric written down, not computed; a trivial zero).",
    right: "The claims are right (recomputed by the verifier with his own code); the two lines are cosmetic and should compute what they assert.",
    foundBy: 'the lane B/C verifier',
    guard: 'the verifier\u2019s own recomputation (not shipped); the shipped script: none yet',
    gradeChange: 'none'
  },
  {
    id: 'E-034', date: '2026-10-06', where: "Candidate list T9 and the atlas wording 'E_n sits at c = n exactly'",
    wrong: "'E_n sits at c = n exactly' (the F₂ class of E_n/2E_n read as the clock value n).",
    right: "The 𝔽₂ form sees only the ungraded type, so c up to c ↔ 2 − c; E_n/2E_n has the class of Cl(n,0) for every n ≥ 3, and at n = 11 that class (ℂ) differs from the class of Cl(10,1) (2ℝ) although the real signature is (10,1). The class is not a function of the signature (A₆ against E₆).",
    foundBy: 'the lane B deriver (T9), confirmed by the verifier',
    guard: 'check_T9.py parts A and F',
    gradeChange: 'the finite-lens wording to be scoped'
  },
  {
    id: 'E-035', date: '2026-10-06', where: 'Atlas MAP-022, RSN-007, RSN-023, EQN-014 (mirrors) and the candidate list T12',
    wrong: "'At most n mirrors' read as holding for the 𝔽₂ shadow of the mirrors.",
    right: "Cartan–Dieudonné holds over the reals; over 𝔽₂ the class of Cl(3,3), Cl(4,2), Cl(0,6) needs 7 > 6 transvections and O⁺₄(2), the class of Cl(2,2), is not generated by transvections at all (T12, exhaustive for n ≤ 6).",
    foundBy: 'the lane B deriver (T12), confirmed by the verifier',
    guard: 'check_T12.py; the spec adds "over the reals" to the cards',
    gradeChange: 'MAP-022 and RSN-007 scoped; RSN-007 gains checked'
  },
  {
    id: 'E-036', date: '2026-10-06', where: 'Atlas SHP-002 (Fock reading)',
    wrong: "'n modes are n Witt pairs: 2n null generators.'",
    right: "2n null vectors forming n Witt pairs of the non-degenerate Cl(n,n); 2n unpaired null generators would give the exterior algebra Cl(0,0,2n), whose radical has dimension 2^{2n} − 1 (T20).",
    foundBy: 'the lane C deriver (T20), confirmed by the verifier',
    guard: 'check_T20.py part H (Witt pairs in the bit-rule Cl(m,m)); the spec instruction for SHP-002',
    gradeChange: 'SHP-002 gains standard'
  },
  {
    id: 'E-037', date: '2026-10-06', where: 'Atlas NUL-003 (when g_tt = 0 is the criterion)',
    wrong: "The identity n·n = ½(ξ·ξ)F stated without its normalisation, and g_tt = 0 presented as the criterion.",
    right: "The identity needs n = ½ d(ξ·ξ) (the selfcheck uses it, the card did not say it); the general criterion is g⁻¹(df,df) = 0 for a regular level function f; g_tt = 0 fails on the light cylinder of rotating flat space (T18).",
    foundBy: 'the lane C deriver (T18), confirmed by the verifier',
    guard: 'check_T18.py parts C and D (the factor 2 fails by a factor 4 if mis-normalised); the spec instruction for NUL-003',
    gradeChange: 'NUL-003 flags unchanged (standard, checked); wording made exact'
  },
  {
    id: 'E-038', date: '2026-10-06', where: 'Derivation T17.md, check section (A)',
    wrong: "'For all 49 signatures (p,q,r) with n ≤ 6.'",
    right: "There are 83 signatures with 1 ≤ n ≤ 6, and the script loops over all of them (it prints '83 signatures n <= 6'); only the prose count was wrong. Found while writing this page.",
    foundBy: 'our own check (re-running check_T17.py for this page)',
    guard: 'the printed count of check_T17.py part A',
    gradeChange: 'none'
  },
  {
    id: 'E-039', date: '2026-10-06', where: 'Category report N1, the answer card "what is label 0 now?", the ladder row n = 5, matrix row C8 (title and projective cell), the message of check G1 (cat_check.py)',
    wrong: "'Among label-homogeneous gradings the Z₂-grading lifts to a conserved integer degree' (N1); 'conserved charge' (row C8, the G1 message); 'the lift of a null generator to a conserved charge' (ladder row n = 5).",
    right: "An additive ℤ-degree, among label-homogeneous gradings (universal group ℤ₂^{p+q} × ℤ^r, T2 (6)). 'Conserved' needs a Hamiltonian and there is none in these statements.",
    foundBy: 'the physicist reviewer of the design round (wording of the category chapter)',
    guard: 'cat_check.py G1, G2; check_T2.py item GL; test_report_cat.py (v1.2 pins: the retired words are absent outside the corrections section)',
    gradeChange: 'none; wording of N1, row C8 and the G1 message (id unchanged)'
  },
  {
    id: 'E-040', date: '2026-10-06', where: 'Category report, title of N10',
    wrong: "'The fermionic and the bosonic ladder are the same relations with a super-commutator; the Born rule is the Frobenius form.'",
    right: "In Cl(3,0) the trace of the Born rule is a symmetric Frobenius form; the top-blade form is never a state (λ(1) = 0).",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'cat_check.py C2 (Cl(3,0), λ = −⟨ωx⟩₀), C3 (states vanish on the radical); check_T15.py part C',
    gradeChange: 'none; N10 retitled (checked, ours)'
  },
  {
    id: 'E-041', date: '2026-10-06', where: 'Category report N8, P4, Limits, the E_n table; the messages of Q1 and Q2 (cat_check.py)',
    wrong: "'Label 0 is the boundary between the definite and the Lorentzian rungs' (tagged ours, but stated as a fact about label 0); E10 and E11 called Lorentzian without a guard; nothing said about why the series stops at 8.",
    right: "det = 9 − n is 0 only at n = 9, the only rung with a null direction (checked); calling it a 'boundary' is ours. E10 and E11 are Lorentzian as signatures of the Cartan form on the root lattice, not of a spacetime; nothing here touches E10 or E11 in supergravity (standard). The finite series stops because 9 − n reaches 0; the 8 it shares with the clock is the period of the Gauss-sum phase; Clifford periodicity does not cause the stop (T10 (7)).",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'cat_check.py Q1, Q2 (exact signatures and determinants for n = 3..11); check_T10.py',
    gradeChange: 'none'
  },
  {
    id: 'E-042', date: '2026-10-06', where: 'Category report N2, edge b of Fig. 1, question QC3, P6, matrix row W5 (clock cell)',
    wrong: "'That is the reason for the ten of the Tenfold Way'; 'that the eight clock values and two complex ones are the ten symmetry classes of matter is our reading only' (row W5 graded A, 'reading ours').",
    right: "The count behind the ten (Wall, recalled): eight real classes and two complex. That the ten super division algebras correspond to the ten symmetry classes of free-fermion matter is stated in Baez's paper: standard, quoted, not computed here; which class sits at which clock value is open (QC3). The atlas computes only the eight graded pairs (C1).",
    foundBy: 'the physicist reviewer of the design round (the old tag under-claimed)',
    guard: 'cat_check.py C1 (the eight graded pairs); wording',
    gradeChange: 'matrix row W5, clock cell: A → S (a standard fact, not our reading); category best grades 27/6/2/5 (was 27/5/3/5); totals E 118, S 106, A 22 (was S 105, A 23)'
  },
  {
    id: 'E-043', date: '2026-10-06', where: 'Category report N5, Fig. 6, matrix row C16, dead ends, "the way down"; the message of K5b (cat_check.py)',
    wrong: "'With only null generators [taking the even subalgebra] fails' (and 'a pure label 0 cannot be peeled off'), stated for every number of null generators.",
    right: "It fails exactly for p = q = 0 and r ≥ 3: Λ^ev(ℝ^r) is a Clifford algebra on r − 1 generators iff r ≤ 2 (Λ^ev(ℝ) = ℝ, Λ^ev(ℝ²) = the dual numbers); for r ≥ 3 its Loewy length is ⌊r/2⌋ + 1 < r (T5 (d)).",
    foundBy: 'the mathematician reviewer of the design round (F-a)',
    guard: 'cat_check.py K5b (the r = 3 case); check_T5.py part D',
    gradeChange: 'none; wording of N5, Fig. 6, row C16 and the K5b message (id unchanged)'
  },
  {
    id: 'E-044', date: '2026-10-06', where: 'Category report: the one-paragraph summary, the answer card, N5 (sideways), P1, the legend of Fig. 2, Fig. 6',
    wrong: "'In the cube of labels [label 0] is a face'; 'the radical is the half of the cube that contains the null bit', for every r.",
    right: "True for one null generator (r = 1). For r ≥ 2 the radical is spanned by the labels with at least one null bit: the complement of the face {a ∩ Z = ∅}, not a face.",
    foundBy: 'the mathematician reviewer of the design round (F-b)',
    guard: 'cat_check.py R1 (dimension 2ⁿ − 2^{p+q} for all 56 signatures with up to five generators)',
    gradeChange: 'none'
  },
  {
    id: 'E-045', date: '2026-10-06', where: 'Category report N3 (title and tags), question QA4, view 4, the summary, Fig. 4',
    wrong: "N3's title 'it is symmetric only for odd n or without null generators', mixing the form λ and the algebra; N3 tagged open.",
    right: "The top-blade form λ is symmetric iff n is odd; the algebra has some symmetric Frobenius form iff n is odd or r = 0. Both are proved for every n (T3), so the tag open was stale.",
    foundBy: 'the mathematician reviewer of the design round (F-f)',
    guard: 'cat_check.py F2, F3, F5; check_T3.py',
    gradeChange: 'N3 tags: checked, standard (open removed)'
  },
  {
    id: 'E-046', date: '2026-10-06', where: 'Category report N2 (the Gauss sum over the labels)',
    wrong: "N2 gives a label with a null bit weight 0 while T4 (iii) has null generators doubling the sum, without saying which convention is meant.",
    right: "N2 now fixes weight 0 (each null generator a factor 1, so S = (1 + i)^p (1 − i)^q; needed for Σe_a² = Re((1 − i)S)) and says that with weight 1 (T4 (iii)) each null generator doubles S: the moduli differ by 2^r, the phase (the clock) is the same.",
    foundBy: 'the mathematician reviewer of the design round (F-c)',
    guard: 'cat_check.py K4a (weight 0, checked with two extra null labels), K4c',
    gradeChange: 'none'
  },
  {
    id: 'E-047', date: '2026-10-06', where: 'Category report: the summary, the answer card, the ladder row n = 3, "top down", N7 (title and text), the caption of Fig. 5, Limits; the message of E1 (cat_check.py)',
    wrong: "'Label 0 first appears in the category at n = 3' (read from the symmetrised Euler form only), and N7 / Fig. 5: '[the quiver-form reading] gives the same pattern as the category itself'.",
    right: "At n = 3 the symmetrised Euler form of the cube category is (6,0,2) and its Tits form, which governs the representation type, is (6,1,1) (T8): both are shown. Reading a null direction as a label 0 is ours; whether the Gram, Euler and E_n sequences share a reason is question QB4, not a pattern.",
    foundBy: 'the mathematician reviewer of the design round (F-d)',
    guard: 'cat_check.py E1 (Euler signatures n = 0..5); check_T8.py (Tits form)',
    gradeChange: 'none'
  },
  {
    id: 'E-048', date: '2026-10-06', where: 'Category report N5 (title), "the way down", view 6, Fig. 6, matrix row K5 (spin cell)',
    wrong: "'Ladders as functors', 'three functors and a duality', 'the same functor'.",
    right: "Maps: no categories are named, halving depends on the chosen generator t, and the complement keeps n.",
    foundBy: 'the mathematician reviewer of the design round (F-e)',
    guard: 'wording only (the maps are checked by K5a–K5c, R1, F1)',
    gradeChange: 'none'
  },
  {
    id: 'E-049', date: '2026-10-06', where: 'Baez report J10, J5, the geometry paper card, the dead ends, matrix row C.2; the messages of H1b, O2d, K2a and C1 (baez_check.py)',
    wrong: "'The Hodge complement' for the complement of a label and for the top-label form (J10: 'the Berezin integral and the Hodge complement'), the E-009 slip surviving in this report; J10 and C1 also used 'label 0' for the empty label; row C.2 paired the label algebra with the commutative Frobenius monoids of cospans without a note.",
    right: "The complement pairing, a Frobenius duality for every signature; a metric Hodge star only without null generators (and Λ(ℝ³) of the Zorn algebra has no metric). The empty label is the unit; 'label 0' means a generator with square 0. Row C.2 now says that the label algebra is a non-commutative Frobenius algebra and the cospan monoids are commutative: only the existence of a non-degenerate form matches.",
    foundBy: 'the physicist and the mathematician reviewers of the design round',
    guard: 'baez_check.py C1; bridge_check.py A6; cat_check.py F1; check_T3.py; test_report_baez.py T36, T38',
    gradeChange: 'none (C.2 stays S, annotated)'
  },
  {
    id: 'E-050', date: '2026-10-06', where: 'Baez report, matrix row K.6 (rule cell)',
    wrong: "Row K.6 (the Madelung rules) graded E with no remark, although no product of the bit rule is used.",
    right: "The note now says that E there means the counts agree exactly (closures 2, 10, 18, 36, 54, 86, 118; periods 2m²), by bit counting only.",
    foundBy: 'the mathematician reviewer of the design round',
    guard: 'baez_check.py K3; test_report_baez.py T38',
    gradeChange: 'none (K.6 stays E, annotated)'
  },
  {
    id: 'E-051', date: '2026-10-06', where: 'Baez report J1, the figure of J1 (caption and tooltips), matrix row E.2, P4; the message of H1b (baez_check.py)',
    wrong: "'The complement mask 11111 maps even to odd labels and flips Q and Y: particle to antiparticle'; 'the odd labels, the antiparticle side'.",
    right: "The mask exchanges even and odd labels, and Y and Q flip (checked); calling that flip charge conjugation is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'baez_check.py H1b, H2c; test_report_baez.py T36',
    gradeChange: 'none'
  },
  {
    id: 'E-052', date: '2026-10-06', where: 'Baez report J1, P1, matrix row E.6',
    wrong: "'The labels explain why those and only those [six pieces] occur'; the anomaly sums 'computed by us'.",
    right: "On the labels the Peirce value is 1 − d/4, so the six non-empty classes are the six pieces (checked); reading this as the reason is ours. The anomaly sums are the standard cancellation, recomputed over the labels (standard, checked).",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'baez_check.py H1a–H2d; test_report_baez.py T36, T37',
    gradeChange: 'none'
  },
  {
    id: 'E-053', date: '2026-10-06', where: 'Baez report J3 (title and text), the summary, view 3, Limits, P2',
    wrong: "'The four exceptional triples are one ladder, and under the Standard Model they build a generation step by step.'",
    right: "Under the E7 paper's su(3) + su(2) the nested triples 6 ⊂ 10 ⊂ 16 ⊂ 27 contain (3,2); then + (3̄,1) + (1,1); then one generation; then 11 more states (checked). The word 'builds' is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'baez_check.py S1, E1a–E2d; test_report_baez.py T36, T37',
    gradeChange: 'none'
  },
  {
    id: 'E-054', date: '2026-10-06', where: 'Baez report J6, matrix row G.5 (furey cell)',
    wrong: "'[The Standard Model group] acts on h3(O) in a self-conjugate (real) way, with no chiral generation inside h3(O)'; 'the chiral generation of the atlas page does not sit in h3(O) itself'.",
    right: "The 27 = h3(O) is self-conjugate (checked); real representations are vector-like (standard); Lie-algebra level only.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'baez_check.py S2, O3a–O3h; test_report_baez.py T36, T37',
    gradeChange: 'none'
  },
  {
    id: 'E-055', date: '2026-10-06', where: 'Schuller report P2, F7, matrix row M4 (maxwell cell)',
    wrong: "'The excluded Cl(2,2) is also the quadric of entangled two-qubit states' (P2); F7 and row M4 without 'real'.",
    right: "det = 0 is the cone of product states, and only for real amplitudes: for real amplitudes product states are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is det = 0 on M₂(ℂ). The link to hyperbolicity is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'bridge_check_qm.py Q10a, Q10b; test_report.py T24, T25, T26',
    gradeChange: 'none'
  },
  {
    id: 'E-056', date: '2026-10-06', where: 'Schuller report F12 (title and text), the summary, the introduction to F10–F15, the checks table; fibre_check.py (the G4 comment and the message of G4d)',
    wrong: "'Mass is a fibre momentum, and hyperbolicity says the fibre is space-like'; 'the hyperbolicity filter is the statement \"fibre momenta behave like space\"'.",
    right: "A momentum along an extra space-like direction enters as a mass, E² = |p|² + m² (Kaluza–Klein, standard). A time-like direction breaks hyperbolicity. A null direction never enters the determinant (T16, checked). Reading the mass as coming from the fibre of F11 is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'fibre_check.py G4a–G4d; check_T16.py; test_report.py T24, T25',
    gradeChange: 'F12 tags: checked, standard, ours (standard added)'
  },
  {
    id: 'E-057', date: '2026-10-06', where: 'Schuller report F6, Fig. 1 (link 3, link 7)',
    wrong: "F6: 'Grades along his pipeline: E, S, E, S, S, S, A' and 'steps 1–3 of his pipeline: exact'; Fig. 1, link 3: 'Cl(2,2) is first to fail. The third condition has no counterpart'.",
    right: "The figure's order, S, E, E, S, S, S, A: step 1 structural, steps 2 and 3 exact for the first condition. Link 3: first condition, quadratic P: E (T18 (f)); third condition (energy-distinguishing): a gap. Link 7 now says 'ours; untested against his equations' for Λ ~ −s·κ².",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'bridge_check.py B1–B5; check_T18.py; test_report.py T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-058', date: '2026-10-06', where: 'Derivation T19, statement (1) (researchersData.js); Schuller report F13 (text and legend), the checks table, matrix row M11',
    wrong: "T19 (1): '|tr M| = 2 iff X² = 0 (parabolic, linear growth)'; the report's legend 'edge: X² = 0, parabolic'.",
    right: "Too strong: M = ±I has X = 0 and bounded powers (two bands touch, no gap opens). |tr M| = 2 iff X² = 0, and M is then parabolic with linear growth iff X ≠ 0; a band edge is X² = 0 with X ≠ 0.",
    foundBy: 'the mathematician reviewer of the design round',
    guard: 'fibre_check.py G5e (X ≠ 0 at every one of the 7 band edges found); test_report.py T24, T25, T26 (the planned check scw·P2 of the Schuller widget script is meant to pin M = ±I; not verified by the reports agent)',
    gradeChange: 'none; T19 statement (1) needs the condition X ≠ 0 (see HANDOFF_reports.md, requests)'
  },
  {
    id: 'E-059', date: '2026-10-06', where: 'Schuller report F2 (title and text), the summary, Fig. 1, the legend of the cell map, P2, matrix row C3 (cells)',
    wrong: "'Hyperbolicity filters the cells: two ladders'; 'the first excluded is Cl(2,2)'; 'hyperbolicity admits exactly two ladders of cells'.",
    right: "One Lorentzian class in two conventions, P ↔ −P. P cannot tell them apart; the algebras can: Cl(1,3) = M₂(ℍ), Cl(3,1) = M₄(ℝ). Cl(2,2) is the first ultrahyperbolic cell. Domain: quadratic P, r = 0 (T18 (f)).",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'bridge_check.py B1–B3; check_T18.py; test_report.py T24–T26',
    gradeChange: 'none'
  },
  {
    id: 'E-060', date: '2026-10-06', where: 'Schuller report, matrix row L13 (spin cell); F5 and view 5',
    wrong: "Row L13: 'Casimir of the spin representation = C(n,2)/4 in every signature'; F5: 'Σ(e_ab/2)² equals −C(n,2)/4 in every signature' without saying where the indices sit.",
    right: "Σ_{a<b}(e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 for r = 0, with the indices raised; minus it is the 3/4 at n = 3 (Example 17.13; Ω = ΣS_i² = 3/4 at j = ½).",
    foundBy: 'the mathematician reviewer of the design round (C.4)',
    guard: 'bridge_check.py E4, E5; test_report.py T24–T26',
    gradeChange: 'none'
  },
  {
    id: 'E-061', date: '2026-10-06', where: 'Schuller report F13 (title and text), the summary, matrix row M11 (clock cell)',
    wrong: "'The bands of chapter 20 are the trio'; 'So this is a fifth home of the trio −1, 0, +1 of F3'.",
    right: "The textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ) (T19); grouping it with the other homes of the trio is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'fibre_check.py G5a–G5f; check_T19.py; test_report.py T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-062', date: '2026-10-06', where: 'Schuller report F10, the caption of F11; fibre_check.py (the message of G2d)',
    wrong: "'The total Cl(4,4) = M₁₆(ℝ) is Furey's End(V)'; 'k = 4 has the type M₂(ℍ) of Cl(1,3), k = 8 is Furey's M₁₆(ℝ)'; G2d: '= End(V), Furey's V'.",
    right: "Isomorphic as algebras; the generators are not matched (not a Lorentz frame). The base/fibre convention is printed: base = left action, fibre = twisted right action; reversion swaps left and right.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'fibre_check.py G1a–G2d, G3a–G3e; test_report.py T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-063', date: '2026-10-06', where: 'Schuller report F1, P1',
    wrong: "F1: 'It is the place where his lectures stop: they build forms and the Hodge star, and never name a Clifford algebra'; P1: 'the bit rule gives the missing step'.",
    right: "His lectures go from ch. 12 to ch. 15 without naming a Clifford algebra (a text search of the four documents finds the word nowhere); that a Clifford chapter belongs there is ours.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'test_report.py T15 (the text search, needs the lecture texts) and T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-064', date: '2026-10-06', where: 'Schuller report F3 (text and table), P3',
    wrong: "F3: 'an abelian ideal (the BMS₃ pattern, Carroll)', 'Witt ⊗ ℂ (Euclid)'; P3: 'ε = −1, 0, +1 would be Euclid, Carroll and Lorentz inside one formula'.",
    right: "The names Euclid, Carroll and Lorentz for ε = −1, 0, +1 are ours; the computation is a frozen flat 1+1 model, not his (48)–(50); whether a family in the sign ε with Euclidean, Carroll-type and Lorentzian members exists for d > 1 is open (P3).",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'bridge_check.py C1–C6 (the frozen model only); test_report.py T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-065', date: '2026-10-06', where: 'Schuller report F4, P4',
    wrong: "The so(4) split 5 + 5 + 9 + 1 + 1 of the 21 area-metric components and the octahedral split 6 + 12 + 3 given without their limits.",
    right: "The so(4) count is Euclidean while his area metrics are Lorentzian: under so(1,3) the two Weyl 5s are complex conjugates of each other and do not split over ℝ (standard). The 6 + 12 + 3 split depends on the chosen frame of ℝ⁴.",
    foundBy: 'the physicist reviewer of the design round',
    guard: 'bridge_check.py D1–D8 (the counts); test_report.py T25',
    gradeChange: 'none'
  },
  {
    id: 'E-066', date: '2026-10-06', where: 'Schuller report F15',
    wrong: "The orthogonal root systems 'E₇, E₆, D₅, A₄, A₂ + A₁ (identified by count and rank)', stated as an identification.",
    right: "Named from count and rank only: the Cartan matrices were not computed, and count and rank do not identify a root system in general (B₃ and C₃ both have 18 roots and rank 3).",
    foundBy: 'the mathematician reviewer of the design round (C.10)',
    guard: 'fibre_check.py G8c (counts and ranks); test_report.py T24, T25',
    gradeChange: 'none'
  },
  {
    id: 'E-067', date: '2026-10-06', where: 'bridge_check.py, the comment above check A5 (shipped as selfcheck/reports/bridge_check.py)',
    wrong: "'# Hodge star = multiplication by the pseudoscalar = XOR with the all-ones label', with no condition.",
    right: "Only in the non-degenerate cells; with a null generator multiplication by the top blade is nilpotent and not a Hodge star (A6, E-009). The comment now says so.",
    foundBy: 'the design round (DECISIONS §6, check wording)',
    guard: 'bridge_check.py A5, A6; mutate_fibre.py M21',
    gradeChange: 'none (comment only; the A5 and A6 messages were already right)'
  },
  {
    id: 'E-068', date: '2026-10-06', where: 'Schuller report F14 (the closing paragraph)',
    wrong: "'The Golay–Cl(0,24) statement is a computed observation about doubly-even self-dual codes, not a theorem I have proved in general.'",
    right: "Stale (an under-claim): the general statement is now proved in T14: a doubly-even self-dual code of length n is a maximal totally singular subspace of the label form through the pseudoscalar, and one exists iff 8 | n (stated for Cl(n,0)).",
    foundBy: 'the mathematician reviewer of the design round (C.9)',
    guard: 'fibre_check.py G9a, G9b (the Golay computation); check_T14.py; test_report.py T24, T25, T27',
    gradeChange: 'none'
  }
];

// Questions for specialists: the 23 of the category report (QA1–QE7) in their corrected form (see ERRATA), then up to ten from the open or recalled parts of the theorems (QT1–QT8). 'checked' is what a script computed; 'notChecked' is what an answer would have to supply.
export const QUESTIONS = [
  { id: 'QA1', topic: 'The null label as an algebra element: a graded Brauer-type group with r', ask: "For the bit-rule algebra Cl(p,q,r) the super-centre is the exterior algebra on the r null generators and the algebra is graded-Azumaya exactly when r = 0 (now proved for all n, T2). Is this a known statement, and is there a graded Brauer-type group that contains the degenerate Clifford algebras, so that the clock p − q mod 8 can be extended by a second coordinate for r?", whom: 'graded ring theory', checked: "R1–R4 for all 56 signatures with up to five generators (category report); T2 proves the radical, the Loewy layers and the super-centre for every signature; the clock is blind to r (K4a, T4 (iii)).", notChecked: 'Any group law that includes r; a literature search.' },
  { id: 'QA2', topic: 'Representation type of the degenerate algebras', ask: "The exterior algebra Λ(k^r) has finite representation type for r ≤ 1, tame for r = 2 and wild for r ≥ 3 (recalled). Does that measure how far label 0 is from invertible, and what does it become for Cl(p,q,r) with p + q ≥ 1 (a Morita-type reduction to the exterior algebra through Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r))?", whom: 'representation theory of algebras', checked: 'Loewy length r + 1 and the layer sizes C(r,k)·2^{p+q} (R2; proved in T2), the graded tensor product (T2 (1)).', notChecked: 'The representation types themselves; the reduction.' },
  { id: 'QA3', topic: 'The universal grading group of Cl(p,q,r)', ask: "Among gradings in which every label is homogeneous, the universal grading group of Cl(p,q,r) is ℤ₂^{p+q} × ℤ^r, of free rank r (T2, proved; the earlier unqualified sentence 'free rank r' is false, since M₂(ℝ) carries a ℤ-grading by matrix units). Is the universal grading group for arbitrary gradings known, torsion part included?", whom: 'graded algebra', checked: 'The label-homogeneous universal group, by linear algebra on the labels for every signature n ≤ 6 (check_T2.py GL) and for 34 signatures with n ≤ 4 in the category report (G1).', notChecked: 'Arbitrary gradings; the torsion part; larger n.' },
  { id: 'QA4', topic: 'The complement mask as a Frobenius duality', ask: "The complement mask pairs a with a xor 1…1 and is a Frobenius pairing for every signature; it is symmetric only for odd n or r = 0, and for even n with r ≥ 1 (the 3D projective algebra Cl(3,0,1), for example) no symmetric form exists; the Nakayama automorphism is the grade involution (all proved for all n, T3). Is this known for the exterior and projective algebras, and does the twist matter for the duality ('dual', 'Hodge') used in the projective-geometric-algebra literature?", whom: 'Frobenius and Gorenstein algebras; PGA', checked: 'F1–F3 for every signature with up to six generators, exactly (check_T3.py), and the proof for all n.', notChecked: 'Any use of the twist in PGA practice; a reference for the degenerate case (we could not name one).' },
  { id: 'QA5', topic: 'Frobenius forms, the trace, and states on projective-type algebras', ask: "All Frobenius forms of Cl(p,q,r) are λ(u·) with u any unit; only the symmetric ones are a torsor under the central units (T3; our earlier sentence was wrong). In Cl(3,0) the trace is the top-blade form up to the central pseudoscalar (C2). With null generators the scalar part is blind to every label with a null bit (F4), only the top-blade form is non-degenerate, and T15 shows that the top-blade form is never a state and every state vanishes on the radical. Is this dichotomy known for degenerate Clifford algebras, and what is the right notion of state for composite systems?", whom: 'Frobenius algebras and quantum foundations', checked: 'C2 and F4 (category report); check_T3.py TOR; check_T15.py (states on all signatures n ≤ 4, four involutions).', notChecked: 'Composite systems (graded against ungraded tensor products); the literature.' },
  { id: 'QB1', topic: 'The cube of labels and categorification', ask: "The cube of labels with the Jordan–Wigner sign is the standard picture of a cube of resolutions, and the sign is unique up to gauge (H¹(cube; 𝔽₂) = 0, now proved for all n, T6 (a)). Is Tian's DG category CL a categorification of this signed cube, or of something else, and is the uniqueness of the sign the reason the sign conventions of such constructions agree?", whom: 'categorification; knot homology', checked: 'K1a–K1e (n ≤ 6; brute force on the 3-cube: 128 sign assignments, one gauge orbit); K5c and T7 (4): the sign equals the sorting sign of Tian, Lemma 4.20.', notChecked: 'The DG category, its diagrammatics, Remark 2.6 and Conjecture 2.11 of the paper.' },
  { id: 'QB2', topic: 'A cohomology for the monoid-valued sign', ask: "For ε = ±1 the bit rule is a 2-cocycle of ℤ₂ⁿ in {±1}. For a null generator the sign takes the value 0 on some pairs, so it lives in the multiplicative monoid {+1, −1, 0}, which is not a group; T1 proves associativity for every n by an integer identity on the exponents. Is there a cohomology theory (twisted monoid algebras, partial cocycles) in which the degenerate algebras are twisted algebras and the radical is a cohomological notion?", whom: 'cohomology with a monoid of coefficients', checked: 'S1 (associativity for all 81 choices of squares with four generators); T1 for every n and every ε (exhaustive to n = 7 for the cocycle).', notChecked: 'Anything about a cohomology of the monoid-valued rule. We do not know the right framework.' },
  { id: 'QB3', topic: 'The octonion cochain and a null analogue', ask: "The octonion sign is a 2-cochain on ℤ₂³ whose coboundary is the associator (−1)^det, a 3-cocycle; the Clifford sign of Cl(0,3) on the same labels is a cocycle. This is the cochain-twist picture of Albuquerque and Majid (recalled); T6 (d) proves the finite content (coboundary and composition) and leaves the identification with 𝕆 to Hurwitz. Is there a null analogue (split or dual octonions) and a place for the radical in it?", whom: 'non-associative algebra; cochain twists', checked: 'K3a, K3b (all 4096 quadruples); check_T6.py OCT (168 independent triples, 448 composition cases).', notChecked: 'Null octonions; the literature statement itself.' },
  { id: 'QB4', topic: 'Is the 3-cube derived-tubular?', ask: "The Euler form of the n-cube category has signature (1,0,0), (2,0,0), (4,0,0), (6,0,2), (14,2,0), (20,2,10) for n = 0..5. T8 proves that its Coxeter polynomial is the D₄ polynomial at n = 2 and (x−1)²(x²+x+1)³ at n = 3, the tubular (3,3,3) profile, that the two null directions at n = 3 are exactly the Coxeter-fixed vectors, that the algebra is not representation-finite from n = 3 and wild from n = 4 (Tits form negative on a non-negative vector; de la Peña). Is the 3-cube derived equivalent to the tubular algebra of type (3,3,3), and is it tame?", whom: 'derived categories of finite-dimensional algebras', checked: 'The signatures (E1, exact rational diagonalisation); check_T8.py (Coxeter polynomials, Fix(Φ) = Euler radical, Tits form (6,1,1) at n = 3, witnesses at n = 4, 5).', notChecked: 'The derived equivalence; tame versus wild at n = 3 (open in T8).' },
  { id: 'QB5', topic: "Tian's radical vector in the categorification", ask: "Tian's odd truncations have a radical vector a₁ − a₃ + a₅ − …, which T7 identifies as (−1)^{m−1} u_m, the half of the last hyperbolic pair whose partner a_{2m} is missing. Is there an object in CL (or in K₀) whose class is that vector, and what happens to it in the limit of the infinite algebra Cl_ℤ, which has no radical?", whom: 'categorification', checked: 'T2 and T3 of the category report (n ≤ 3; signature ⌊k/2⌋, ⌊k/2⌋, k mod 2 for k ≤ 10); check_T7.py (the closed form for k ≤ 7, the signature for k ≤ 12).', notChecked: 'Anything inside the DG category.' },
  { id: 'QC1', topic: 'Graded Morita classes with r', ask: "The clock is a homomorphism for the graded product (K4a, K5a) and null generators contribute 0; T2 shows that the algebra is graded-simple only for r = 0. What is the graded Morita class of Cl(p,q,r), and is there a version of the Brauer–Wall group in which r is a second coordinate (classes over dual numbers or exterior algebras)?", whom: 'Brauer–Wall groups', checked: 'The clock of the quotient (K4a); five ungraded against eight graded types (C1; T4 (ii)).', notChecked: 'Any group that includes r.' },
  { id: 'QC2', topic: 'A finite-field clock', ask: "Over 𝔽_p the one-generator algebra has (p − 1)(p − χ(d)) units: split, ramified, inert as +1, 0, −1 (L1b). Does the clock have a finite-field version (the Brauer–Wall group of 𝔽_q, recalled to be ℤ₄ or ℤ₂ × ℤ₂), and for n = 2 is 'null' the same thing as 'ramified' for quaternion algebras over ℚ (Hilbert symbols)?", whom: 'number theory; algebra over finite fields', checked: 'The unit count at n = 1 for p = 3, 5, 7, 11, 13.', notChecked: 'Everything for n ≥ 2 and every field other than ℝ and the five primes above.' },
  { id: 'QC3', topic: 'The tenfold way and a nilpotent generator', ask: "The eight clock values and two complex ones are the ten symmetry classes of free-fermion matter (the tenfold way; Freed–Moore). Does a nilpotent generator (r ≥ 1) correspond to anything physical in that classification (gapless or degenerate directions), or is it simply absent?", whom: 'condensed-matter classification', checked: 'Nothing: this is our reading only.', notChecked: 'All of it.' },
  { id: 'QD1', topic: 'E_n/2E_n and the label form of Cl(n,0)', ask: "T9 proves that E_n/2E_n carries the label form of Cl(n,0) for every n ≥ 3 (and A_n/2A_n that of Cl(0,n)), that the two coincide iff 4 | n, that W(E_n) mod 2 is the full isometry group for n = 3..8 (and by computation for n = 9..12), and that the class is not a function of rank and signature (A₆ against E₆). The identification continues through E₉, E₁₀, E₁₁ although the real form turns affine and Lorentzian. Is this identification known, and does W(E_n) mod 2 = O(q) hold for all n?", whom: 'Kac–Moody algebras; lattices', checked: 'Q1, Q2, Q5 of the category report; check_T9.py (isometries to n = 16, the groups for n = 3..12 by Schreier–Sims); check_T10.py (signatures to n = 20).', notChecked: 'The group statement for general n; a reference.' },
  { id: 'QD2', topic: 'Is the clock the Brown invariant?', ask: "The phase of the Gauss sum over the labels of Cl(n,0) is (p − q)π/4 (K4a; T4 (iii)), and for the root lattices A₃, A₈, D₄, D₈, E₆, E₇, E₈ the Gauss–Milgram sum of the discriminant form has the phase n·π/4 (Q4). Is 'clock = Brown invariant of the ℤ₄-valued quadratic form of the labels' the correct statement, and is it the same ℤ₈ as the signature mod 8 of an even lattice (van der Blij; T10 (7) relies on this, recalled)?", whom: 'topology; lattices', checked: 'Numerically on seven lattices (tolerance 1e−9); exact Gaussian integers for the Gauss sum with p + q ≤ 10 (check_T4.py GS).', notChecked: 'The naming; a proof for all n.' },
  { id: 'QD3', topic: 'Blades with square −1 against positive roots', ask: "The number of blades with square −1 equals the number of positive roots of E_n for n = 3, 4, 5, 6, 8 (4, 10, 20, 36, 120) and is 64 = 63 + 1 for n = 7, the extra class being the central pseudoscalar (T10 (6), proved). By Gabriel's theorem (recalled) the positive roots count the indecomposable representations of the quiver. Is there a reason, or a use, for reading the same number as blades of a Clifford algebra?", whom: 'quiver representations', checked: 'Q3 and Q5 of the category report; check_T10.py (root counts for n = 3..8 by enumeration).', notChecked: "Gabriel's theorem; any use of the reading." },
  { id: 'QE1', topic: 'The Born rule in a general cell', ask: "In Cl(3,0) the mixed state ρ = (1 + v)/2 and the projector P = (1 + u)/2 give 2⟨ρP⟩₀ = (1 + v·u)/2, ρ is positive iff |v| ≤ 1 and pure iff |v| = 1 (the Bloch ball). T15 proves the general version: for every Cl(p,q) with the dagger involution the states are the density elements ρ ≥ 0 of the scalar-part trace, and with null generators the states are exactly those of Cl(p,q). Is this the right notion of state for the atlas's cells, and how do entanglement and composite systems enter?", whom: 'quantum foundations', checked: 'C2 (exact, rational), F4; check_T15.py (4648 assertions).', notChecked: 'Entanglement; composite systems; involutions other than the diagonal ones (covered by the proof, not tested numerically).' },
  { id: 'QE2', topic: 'The finite shadow of the spectral theorem and contextuality', ask: "The largest set of mutually commuting blades with square +1 spans ℝ^{2^w}, w the Witt index of the quadric of squares, and 2^w is the number of simple factors times the matrix size (W1). The counts are 5 points for Cl(4,0); 27 points and 45 lines for Cl(6,0) (the elliptic quadric Q⁻(5,2), not the Klein quadric); 135 points and 270 solids in two families for Cl(8,0); Cl(2,2) has 9 points and 6 lines, the Peres–Mermin square, whose sign pattern is now proved (T11). Is this the known polar-space picture of Pauli-type groups, and which of the counts are new to the contextuality literature?", whom: 'quantum foundations; finite geometry', checked: 'W1–W3 by exhaustive enumeration over totally singular subspaces; check_T11.py (74749 checks, p + q ≤ 9).', notChecked: 'The identification with contextuality sets; infinite dimensions.' },
  { id: 'QE3', topic: 'Super-dimension 0 and the bosonic ladder', ask: "The fermionic and the bosonic ladders satisfy the same relations [N, a] = −a and [a, a⁺] = 1 once the commutator is a super-commutator; the dimension is 2ⁿ and the super-dimension is 0, which is what [a, a⁺] = 1 needs in finite dimension (T20 (e), proved). Is 'super-dimension 0' the finite shadow of why the bosonic ladder needs infinite dimension, and what is the right limit n → ∞ taking one into the other?", whom: 'mathematical physics', checked: 'B1 (n ≤ 4); check_T20.py part G.', notChecked: 'The bosonic side beyond the commutator relations; the limit.' },
  { id: 'QE4', topic: 'One combined matrix along the pipeline', ask: "The Schuller report asked for a single matrix with the geometry and quantum rows reordered along his pipeline. The combined matrix now exists (131 rows from the three reports against the 22 atlas columns; the heatmap on this page), but it keeps the three reports' row orders. Is the reordering along the pipeline worth doing, and which rows would it move?", whom: 'mathematical physics', checked: 'The three matrices and their merge (translation_matrix.json, 131 × 22).', notChecked: 'The reordering.' },
  { id: 'QE5', topic: "The three 135s and the Golay code's three bricks", ask: "The three families of 135 in Cl(8,0) are the three 135s of triality (W3, counted; T11 (4)). T14 proves that the Golay code is a Lagrangian of the label form of Cl(24,0) built from three 8-bit bricks (Turyn). Whether the three 135s of Spin(8) and the three bricks of the Golay code are the same triple is not touched.", whom: 'number theory; finite groups', checked: 'W3; check_T14.py (the Turyn construction, 759 octads, S(5,8,24)).', notChecked: 'Any link between the two triples.' },
  { id: 'QE6', topic: "Is 'null' more than a resemblance?", ask: "Timelike, null, spacelike as −1, 0, +1 is the trichotomy inert, ramified, split at n = 1 over 𝔽_p (L1b), and the clock does not distinguish the three beyond ±1 against 0 (K4a). Is there a statement at n ≥ 2 (QC2) or in the energy-cone picture that makes 'null' more than a resemblance?", whom: 'quantum theory; number theory', checked: 'L1a, L1b.', notChecked: 'Everything at n ≥ 2.' },
  { id: 'QE7', topic: 'Two layerings with no link', ask: "The filtration of Cl(p,q,r) by powers of the radical has layers C(r,k)·2^{p+q} (R2; proved in T2); the layer sizes of the E₈ root ladder in the Schuller report (240, 126, 72, 40, 20, 8 and 56, 27, 16, 10, 6; the first steps proved in T13) are a different count. No mechanism connects them and nothing here tests one.", whom: 'representation theory', checked: 'R2; check_T2.py LOE; check_T13.py (56 and 27).', notChecked: 'The link.' },
  { id: 'QT1', topic: "Wall's theorem inside the bit rule (T4)", ask: "T4 proves that the pair (type of Cl(p,q), type of its even part) is a complete invariant of the clock, with 8 values, but that the eight pairs are the graded Morita classes forming the Brauer–Wall group ℤ₈ of ℝ is recalled from Wall (1964). Is there a short self-contained proof of Wall's theorem in the twisted-group-algebra language of the labels?", whom: 'graded Brauer groups', checked: 'check_T4.py C1 (8 distinct pairs, 5 ungraded types; the pairs constant per clock value).', notChecked: "Wall's theorem itself." },
  { id: 'QT2', topic: 'Tame or wild at n = 3 (T8)', ask: "The cube category at n = 3 has Coxeter polynomial (x−1)²(x²+x+1)³ and a positive semidefinite Euler form of corank 2, the profile of the tubular algebra of type (3,3,3), but it is not strongly simply connected (the rank-1-2 subposet is a hexagon crown), so the Brüstle–de la Peña–Skowroński criterion does not apply. Is k B₃ tame, and is it derived equivalent to the tubular (3,3,3) algebra (Ladkani's work on tensor products of path algebras may contain the answer; we could not verify the statement)?", whom: 'representation theory of algebras; derived categories', checked: 'check_T8.py (the Coxeter polynomial, the Tits form (6,1,1) at n = 3, the convex crown subposet).', notChecked: 'Tameness and the derived equivalence.' },
  { id: 'QT3', topic: 'Transvections over 𝔽₂: generation and lengths for all n (T12)', ask: "For every label form with n ≤ 6 the transvections generate O(Q) except for the class of Cl(2,2) (O⁺₄(2), index 2) and its degenerate relatives, and the longest words need up to n + 1 transvections (7 at n = 6). General n rests on Dieudonné's theorem (recalled), there is no hand proof of the O⁺₄(2) exception (Dickson invariant), and no length formula. Is there a closed form for the maximal transvection length in O^ε_{2m}(2) and in the degenerate classes?", whom: 'classical groups over finite fields', checked: 'check_T12.py (breadth-first search of the Cayley graphs, n ≤ 6).', notChecked: "Dieudonné's theorem; the length formula; the Dickson-invariant argument." },
  { id: 'QT4', topic: 'States of composite systems with null generators (T15)', ask: "T15 settles the single-system case: every state of Cl(p,q,r) vanishes on the radical, for every involution. Composite systems (the graded against the ungraded tensor product, Schuller's chapter 14) are not treated, and non-diagonal involutions on the complexification are covered by the proof but not tested numerically. What is the right state space of Cl(p,q,r) ⊗̂ Cl(p′,q′,r′), and does the radical of the product see anything?", whom: 'operator algebras; quantum foundations', checked: 'check_T15.py (single systems, n ≤ 4, four involutions).', notChecked: 'Composite systems; non-diagonal involutions numerically.' },
  { id: 'QT5', topic: 'The isoclinic case and the general-n decomposition (T17)', ask: "At n = 4 the commuting decomposition B = b₁ + b₂ is proved to exist and to be unique when λ₁ ≠ λ₂, with b_i = B(T − λ_i)/(λ_j − λ_i). The isoclinic case λ₁ = λ₂ (in the definite cells and for some Cl(2,2) bivectors) and the general-n invariant decomposition of Roelfs and De Keninck are not proved here. What is the right statement for λ₁ = λ₂, and does the formula extend to n ≥ 5 with the same proof?", whom: 'geometric algebra; invariant decomposition', checked: 'check_T17.py part D (the formula in the five r = 0 cells at n = 4; complex roots only in Cl(2,2)).', notChecked: 'λ₁ = λ₂; n ≥ 5.' },
  { id: 'QT6', topic: 'W(E_n) mod 2 for all n (T9)', ask: "W(E_n) reduced mod 2 is the full isometry group O(q) of E_n/2E_n for n = 3..8 (proved) and for n = 9..12 (computed by Schreier–Sims). Does it hold for every n ≥ 3, where W(E_n) is infinite from n = 10 on?", whom: 'Coxeter groups; lattices', checked: 'check_T9.py parts D and E.', notChecked: 'n ≥ 13; a proof for general n.' },
  { id: 'QT7', topic: 'Type II codes through the Clifford label form (T14)', ask: "T14 proves that doubly-even self-dual codes of length n are exactly the n/2-dimensional totally singular subspaces of (𝔽₂ⁿ, Q_{Cl(n,0)}) containing the all-ones label, and that they exist iff 8 | n, by the Gauss sum of the label form alone. The classical proof goes through Gleason's theorem or the MacWilliams identity. Is this route in print?", whom: 'coding theory', checked: 'check_T14.py (the criterion for n = 2..64, realised by copies of the Hamming code).', notChecked: 'The literature.' },
  { id: 'QT8', topic: "Does Furey's End(V) contain the E₆-complement A₂? (T13)", ask: "All 1120 A₂ subsystems of E₈ are W(E₈)-conjugate and each has an E₆ complement (T13), so the 'generation sl₃' used inside e₇ is conjugate in E₈ to one whose centraliser is E₆, while inside E₇ its complement is A₅. Whether the model built on End(V) = M₁₆(ℝ) contains this A₂, and whether the 3 of the branching has anything to do with generations, stays open (RSN-004, GOS-003).", whom: 'model building; exceptional Lie algebras', checked: 'check_T13.py (the orbit, the complements, 240 = 72 + 6 + 6 × 27, the E₇ counts).', notChecked: 'The model; any physical reading.' }
];

// Sources the atlas was compared with (the three translation-matrix reports of 5 October 2026 and the notes to researchers): what the source says, what we computed, the verdict, and the dead ends (deadEnd: true = the comparison fails as written; the entry says what survives). Authors are named by their papers; no address of any person appears here.
export const SOURCES = [
  { id: 'S1', source: 'Lundholm and Svensson, Clifford algebra, geometric algebra, and applications (KTH lecture notes, rev. 2016)', itSays: "A course on Clifford and geometric algebra. The combinatorial definition Cl(X,R,r) puts a basis element on every subset of X with a product A·B = τ(A,B)·(A△B) (Def. 2.4; Lemma 2.6 proves associativity by recursion, no closed sign formula); signature value 0 is allowed; the real classification as a table (Thm 5.5, Table 5.1); the graded tensor product (Prop. 5.8), the even subalgebra (Prop. 5.1), the mother algebra Cl(s,t,u) inside Cl(n,n) with a null generator f⁺ − f⁻ (Sect. 5.3); Fock space (Sect. 4.3).", weComputed: "The bit rule is this combinatorial algebra; its sign is a closed 2-cocycle and the rule is associative for every n and every choice of squares, null included (T1); the mod-8 table and the types from one Gauss sum (T4); concatenation of generators is the graded product with the Koszul sign (T2); the even subalgebra needs an invertible generator (T5); the mother algebra as the Cl(m−1,m−1,1) inside Cl(m,m) (T7); Fock space on the labels (T20).", verdict: "Exact: the atlas rebuilds the notes' definitions and tables and adds the closed cocycle. Not touched: spin groups, Clifford analysis, the octonion formula with the 3-vector.", deadEnd: false },
  { id: 'S2', source: 'Baez, The Tenfold Way (arXiv:2011.14234)', itSays: "Schur's lemma makes ℝ, ℂ, ℍ the endomorphism algebras of irreducible real representations; for super vector spaces there are ten real super division algebras, all Clifford algebras (Wall): the eight real ones are the eight Morita classes of real Clifford algebras, the two complex ones the complex classes; real and complex Bott periodicity are united.", weComputed: "The eight classes as the clock p − q mod 8, the three types as the sign of one Gauss sum equal to a Frobenius–Schur count (T4 (iii), (iv)); five ungraded types against eight graded pairs separated by the even part (T4 (ii)); the n = 1 graded division algebras with e² = ±1.", verdict: "Exact for the classes and the types; Wall's theorem and the Brauer–Wall group ℤ₈ are recalled, not recomputed; the ten symmetry classes of matter are our reading only (QC3).", deadEnd: false },
  { id: 'S3', source: 'Tian, A diagrammatic categorification of a Clifford algebra (arXiv:1309.6049)', itSays: "The ℤ-algebra Cl_ℤ with a_i² = 0, a_i a_j = −a_j a_i for |i − j| > 1 and a_i a_{i+1} + a_{i+1} a_i = 1 acts faithfully on an exterior algebra (Lemma 3.3); a DG category CL of diagrams has K₀(CL) = Cl_ℤ (Thm 1.1); signs come from odd cohomological shifts with η the number of inversions (Lemma 4.20).", weComputed: "Over ℝ the truncations are Cl(m,m) (even length) and Cl(m−1,m−1,1) (odd length) in a hyperbolic basis; the radical vector a₁ − a₃ + a₅ − … is (−1)^{m−1}u_m, the orphaned half of the last pair; the sorting sign η is the bit-rule sign (T7).", verdict: "Exact for the algebra. Dead end on the way: reading Tian's nilpotent generators as the atlas's label 0 fails, they are paired nulls; only the radical vector of an odd truncation is a label 0. The DG category, the diagrammatics and the conjecture are not touched.", deadEnd: false },
  { id: 'S4', source: 'Majkić, Categorial geometry and algebraic topology (arXiv:2403.19689)', itSays: "A category read as a discrete geometric object whose arrows are vectors: a partial addition of composable arrows, a norm counting generating arrows, an inner product f·g = ‖f‖‖g‖ when f, g compose or coincide and 0 otherwise, an outer product, and the claim of the two Clifford conditions e² = 1 and fg = −gf for orthogonal f, g (Corollary 2).", weComputed: "Implemented literally on the cube category: the inner product of Def. 4 is not additive along composition, and the two Clifford properties hold by definition, not as consequences of a quadratic form (J1, J2). A constructive reading of our own, the quiver form with 2 on the diagonal and 1 on composable atoms, has signatures (4,0,0), (11,0,1), (26,4,2) (J3).", verdict: "Dead end as written: not a Clifford algebra of a vector space. What survives is our quiver-form reading, tagged ours (grade A). The Metacategory and comma-propagation parts were not examined.", deadEnd: true },
  { id: 'S5', source: 'Schuller, Lectures on the Geometric Anatomy of Theoretical Physics (FAU 2013/14, notes by Rea) and Lectures on Quantum Theory (FAU 2015, notes by Rea and Dadhley; read in part)', itSays: "Forms and the Hodge star (ch. 12), SL(2,ℂ) and the Casimir (ch. 15, 17) without naming a Clifford algebra; in the quantum notes: Stern–Gerlach, spin and Clebsch–Gordan (ch. 13, 15), tensor products and entanglement (ch. 14), the oscillator ladder (ch. 16), periodic potentials and the one-period matrix (ch. 20), Schrödinger, Klein–Gordon, Dirac and Fock space (ch. 21).", weComputed: "Wedge and Clifford as one multiplication table (F1); SL(2,ℂ) at the cell Cl(1,2), the Casimir −C(n,2)/4 (F5); the Fock space as the label set with Cl(n,n) acting (F7; T20); spin and total spin from the grades (F8); the Floquet bands as the sign of X² (F13; T19); the Dirac signs of §21.3 (F9; T16).", verdict: "Exact on the algebraic side (23 of 43 rows exact, 14 structural). Flag F9: the printed (iγ·∂ − m) with η = diag(−1,1,1,1) is tachyonic; the slip is the factor i (T16). Dead ends: chapters 3–6 and 19–20 of the geometry lectures (topology, bundles, connections) and the analysis of the quantum notes (Banach spaces, the spectral theorem, the bosonic Fock space) are beyond a finite, fibre-level atlas (rows L3, L4).", deadEnd: false },
  { id: 'S6', source: 'Düll, Schuller, Stritzelberger and Wolz, Gravitational closure of matter field equations (arXiv:1611.08878), and Schuller, Constructive gravity (arXiv:2003.09726)', itSays: "A matter action gives a principal polynomial; three conditions (hyperbolic, dual hyperbolic, energy-distinguishing) filter the admissible geometries; observers, a foliation and the hypersurface deformation algebra lead to closure equations whose solution for Klein–Gordon is Einstein–Hilbert with two integration constants; general linear electrodynamics has an area metric with 21 components.", weComputed: "The hyperbolicity filter as a map of cells: the two ladders Cl(1,d), Cl(k,1), Cl(2,2) first excluded (F2; proved for all n in T18 (f)); the Dirac symbol determinant (p²)⁴ and its reduced polynomial (B4; T16); the area metric as an octahedron 6 + 12 + 3 and the so(4) split 5 + 5 + 9 + 1 + 1 (F4); a frozen flat 1+1 deformation algebra Witt ⊗ A_ε with ε = −1, 0, +1 (F3).", verdict: "Exact for the front half of the pipeline (what a quadratic form allows); structural for the frozen deformation algebra (not his structure-function algebra; a scalar lapse fails Jacobi). Dead end: the closure equations and the action principle are not rebuilt and the atlas has neither (rows C7, C12).", deadEnd: false },
  { id: 'S7', source: 'Schuller, the closure equations and the global structure (rows L3, L4, C7, C12 of the Schuller matrix)', itSays: "Topology, bundles and connections as sections over a manifold (geometry lectures ch. 3–6, 19–20); an action principle and linear PDEs on a manifold whose solutions are the gravitational dynamics (closure paper).", weComputed: "Nothing: the atlas is pointwise algebra and finite combinatorics, with fields as polynomials in one chart and no Lagrangian.", verdict: "Dead end: four rows with no counterpart. What survives: the local product base × fibre as the graded tensor product and the left/right action of an algebra on itself (F10), a reading tagged ours.", deadEnd: true },
  { id: 'S8', source: 'Baez and Schwahn, The Standard Model gauge group from the exceptional Jordan algebra (arXiv:2606.15235)', itSays: "F₄ acts on pairs of Jordan subalgebras X ⊂ B of the Albert algebra h₃(𝕆) with X ≅ h₂(ℂ) and B ≅ h₃(ℂ); the stabiliser of X intersected with the identity component of the stabiliser of B is S(U(2) × U(3)) (Theorems 1 and 2).", weComputed: "The octonions as the XOR rule with another sign, h₃(𝕆), f₄ (52), the stabiliser dimensions 28, 16, 36, 18, 12 and the structure su(2) + su(3) + u(1) of the 12, triality, h₂(𝕆) of signature (1,9) (O1–O3); how that algebra acts on the 27 (S2, J6).", verdict: "Exact at the Lie-algebra level; the group statements (identity components, ℤ₆ quotient) are not checked. Flag: the subalgebra acts on the 27 differently from the E₇ paper's (J6), so the two Standard Model embeddings are not conjugate in E₆; how they relate is open.", deadEnd: false },
  { id: 'S9', source: 'Baez, Bokor and Boyle, Jordan pair quantum theory and the Standard Model (arXiv:2607.10833)', itSays: "Hermitian Jordan pairs and triples, their Peirce decomposition and 3-graded Lie algebras; the bi-Cayley triple cut by two colinear minimal tripotents falls into the six pieces of one generation (eqs. (69), (75), (76)); ordinary quantum mechanics rewritten with triples.", weComputed: "The six pieces from five bits with the Peirce eigenvalue 1 − d/4 (a Hamming distance), hypercharge Y = a/2 − b/3 and B − L = 1 − 2b/3 as bit counts, vanishing anomaly sums (J1); the Fock realisation of the pair, Cl(5,5) = M₃₂(ℝ) acting on the 32 labels, the triple product of skew matrices, so(5,5) = 10 + 25 + 10 (J2).", verdict: "Exact; what is ours is only that each statement comes out of one operator rule on the 32 labels, and that the tower of triples builds a generation step by step (J3, not stated in the paper).", deadEnd: false },
  { id: 'S10', source: 'Baez, Three generations in E₇ (arXiv:2608.06271)', itSays: "Starting from g_SM = sl₃ + sl₂ + ℂ inside e₇, the algebra splits as a subalgebra containing g_SM plus three 32-dimensional subspaces, each a copy of one generation with antiparticles and of the exterior algebra Λℂ⁵ (Prop. 1, Lemmas 2–4, Prop. 5, Thm 12); the Levi series e₇ ⊃ e₆ ⊃ so(10) ⊃ sl₅ ⊃ sl₃ + sl₂ (Table 2).", weComputed: "The Levi series with the E₈ end (240, 56), the grade-1 sizes 56, 27, 16, 10, 6 and the Peirce counts (J3); the 126 roots sorted by their shadows on the generation plane (30 + 90 + 6) and the lattice of those shadows (J4); E₈ ⊃ E₆ × A₂ with all 1120 A₂'s conjugate and E₇ ⊃ A₂ × A₅ with 30 + 6 + 90 (T13); srg(27,10,1,5) and its Schläfli complement.", verdict: "Exact (by enumeration for the stated embedding); three generations in e₇ are the paper's theorem, not derived here; 'a different A₂' is true inside E₇ only (T13). The name of the 27-point graph in our first matrix row was wrong (E-008).", deadEnd: false },
  { id: 'S11', source: 'Baez and Pumplün, Three-dimensional geometry in exceptional mathematics (arXiv:2609.07538)', itSays: "Functorial constructions of the octonions 𝕆 (from a 3d complex inner-product space with a volume form), the split octonions (from a 3d real space with a volume form, Zorn's product on Λ(ℝ³)) and the bioctonions; e₆ ⊃ sl₃ + sl₃ + sl₃ from three complex 3-spaces.", weComputed: "The octonions as the XOR rule with a non-associative sign, −1 on the 168 independent triples (J5; T6 (d) proves the cochain's coboundary and the composition property); Zorn's product on the eight labels as join, meet or 0; the Peirce reading of the popcount (O1, O2).", verdict: "Exact for the three algebras on the label sets. Dead end on the way: the bare Hodge complement is not an automorphism of the Zorn algebra (it needs the conjugation sign (−1)^{k(k+1)/2}). The 3-manifold applications and the ℤ₃-grading of e₆ are not computed.", deadEnd: false },
  { id: 'S12', source: 'Baez, Second quantization for the Kepler problem (arXiv:2507.11428)', itSays: "The hidden SU(2) × SU(2) of the Kepler problem; the spin-½ bound states are equivalent, as representations, to solutions of the Weyl equation on ℝ × S³; the Fock space on them is a free chiral field; a modified Hamiltonian gives the Madelung rules and the rough shape of the periodic table.", weComputed: "The Poisson algebra of L and the Runge–Lenz vector at both energy signs; the three energy regimes as bivector algebras of the bit rule with squares (+1,+1,+1,ε), Killing counts (0,6,0), (0,3,3), (3,3,0); the half-sums as two commuting su(2); shells 2n² by Clebsch–Gordan; the Madelung order as a prefix of set bits (J8, J9); so(4,2) as 4 + 7 + 4.", verdict: "Exact for the algebra and the counts; reading the energy trio as the trio of the extra generator of step 9 is ours (analogy). A possible slip in the paper's eq. (12) is noted (the half-sums need ε_{jkl}L_l). The Weyl equation and the analysis are not touched.", deadEnd: false },
  { id: 'S13', source: 'Baez, Triangulations of the sphere (arXiv:2606.10072)', itSays: "Thurston's theorem: stars cut from the Eisenstein lattice fold into polyhedra with twelve cone points; the number of triangles is a hermitian form on ℂ¹⁰ of signature (1,9); the author asks whether the resemblance to ten-dimensional Minkowski space is a coincidence.", weComputed: "The theta series of the Eisenstein lattice (1, 6, 0, 6, 6, 0, 0, 12), which is the lattice of the generation plane in the E₇ paper (J4); the form reproduced from the shoelace formula with real signature (2,18); Gauss–Bonnet; the clock of Cl(1,9) (clock 0, M₃₂(ℝ), real Majorana–Weyl spinors; only (1,9), (5,5), (9,1) among the (p, 10 − p)); h₂(𝕆) = ℝ^{1,9} (J7).", verdict: "Dead end for the numerology: the 10 of h₂(𝕆) is real, the 10 of the triangulation form is complex, and no mechanism connects them (matching numbers without a mechanism are not evidence). What survives: the Eisenstein-lattice identification (J4) and what the clock says (1,9) is as an algebra (J7). Thurston's moduli space is not touched.", deadEnd: true },
  { id: 'S14', source: 'Baez, Double categories of open systems: the cospan approach (arXiv:2509.22584)', itSays: "An overview of double categories of open systems composed by identifying variables: structured and decorated cospans, open Petri nets, open dynamical systems, hypergraph double categories.", weComputed: "Read at overview level. One computation: the Frobenius forms of the label algebra for all 117 patterns of generator squares with n = 2, 3, 4 (the scalar form is non-degenerate exactly without null generators, 28 of 117; the top-label form always, 117 of 117); a reading of composition by shared variables as contraction of shared bits (C1, J10).", verdict: "Dead end: the atlas has no categories, no Petri nets and no rates. What survives: the Frobenius-form check (now T3 for every signature) and an analogy tagged ours.", deadEnd: true },
  { id: 'S15', source: 'Hsu, Barker, Hobson and Lasenby, The radial metric function does not identify null surfaces (arXiv:2504.13255)', itSays: "Four claims: the generator of a null surface is a photon that stands still; g^{rr} = 0 is not the criterion (Schwarzschild against the Ellis wormhole); when g_tt = 0 is the criterion for a static ξ and four ways it fails; a closed loophole in Vishveshwara's argument.", weComputed: "The four claims rebuilt on the bit rule in exact fractions (null_selfcheck.py, 64 checks): n·n = −T, ξ·∇ξ = −κξ, Kerr's dφ/dt = a/(r₊² + a²), the Ellis throat; the tangent algebra Cl(0, n−2, 1) with its ideal J, J·J = 0; T18 proves the null criterion g⁻¹(df,df) = 0, the Killing identity (dξ²)² = 2ξ²F and the hyperbolicity statement for all n.", verdict: "Exact; Eq. (12) of the paper is not rebuilt; NUL-003 needed the normalisation n = ½ d(ξ·ξ) (E-037). Of the references only Vishveshwara's Appendix B and the abstract of Vollick were read.", deadEnd: false },
  { id: 'S16', source: "Vollick, null surfaces in static space-times (abstract only)", itSays: "Which surfaces of a static space-time are null, g_tt = 0 or g^{rr} = 0 (as described by the paper of Hsu, Barker, Hobson and Lasenby, which closes a loophole in Vishveshwara's argument).", weComputed: "g^{rr} = n·n/(TR) vanishes for two unrelated reasons, a null surface or an infinitely long radial unit; Schwarzschild against the Ellis wormhole (null_selfcheck.py); the criterion for a regular level function (T18).", verdict: "Open: we read only the abstract, so a reading we call ours may already be in the paper; the g^{rr} = 0 argument as we state it may be only a neighbour of the author's.", deadEnd: false },
  { id: 'S17', source: 'Lasenby, Doran and Gull, Gravity, gauge theories and geometric algebra (the gauge theory of gravity)', itSays: "Gravity as gauge fields h̄ and Ω on flat space-time in the space-time algebra; Schwarzschild in the Newtonian (Painlevé–Gullstrand) gauge; Kerr–Schild forms; time reversal; the Dirac action; the field equations and cosmology.", weComputed: "The Newtonian gauge as a single shear h̄ = 1 + N, N² = 0, det 1; the radial gradient h̄(e_r) = e_r + g e_t, the physical gradient of r, with square g² − 1 = −T (−1 outside, 0 on the horizon, +1 inside; T18 (d)); the Kerr–Schild null vector and its time shift to the Painlevé–Gullstrand form (exact fractions); the metrics of both shears are vacuum with Kretschmann scalar 48M²/r⁶, the curvature operator in the orthonormal frame has the point-mass Weyl pattern (−2, −2, 1, 1, 1, 1) M/r³, and free fall gives d²r/dτ² = −M/r² with the conserved energy (6.83) and the rain crossing r = 2M (finite differences, numpy); time reversal as a reflection of e_t sending g to −g; the Euler–Lagrange equations of the Dirac action as the Dirac equation up to an invertible 8×8 map; the curvature counts by dimension (gtg_check.py parts S and G).", verdict: "Exact for the computed items; the field equations of the gauge theory, the cosmology and the Hawking parts are not decoded (the metrics are tested against Ricci = 0 directly). 'The horizon as the 0 label' is ours, and the 0 there is a paired null of Cl(1,1) (E-006).", deadEnd: false },
  { id: 'S18', source: "Hestenes, Space-Time Algebra and the real form of the Dirac equation", itSays: "Electromagnetism as ∇F = J with F a bivector of Cl(1,3); the Dirac equation ∇ψJ = mψγ₀ with ψ even and J = γ₂γ₁; the decomposition ψ = ρ^½ e^{Iβ/2} R of an even spinor, with the Yvon–Takabayasi angle β.", weComputed: "∇F = J on every split with k, d ≤ 4 and k + d ≤ 7 in exact arithmetic (maxwell_selfcheck.py); the Dirac equation with 8 components, 40 incidences and covariance (equations_selfcheck.py, dirac_matrix_check.py); det T_m = σ(p² − m²)⁴ with one sign, proved for every module of every Cl(p,q,r) with p + q ≥ 2 (T16); the free plane waves of the Dirac step as exact kernels at 8 on-shell momenta, all with ψψ̃ = a + bI, b = 0 (β = 0 for positive and π for negative energy), which places them in the slice that holds the pointors of Roelfs, Eelbode and De Keninck among the even spinors (spin_selfcheck.py); the chirality ψ ↦ IψJ as XOR 9 (ours).", verdict: "Exact; the demicube reading of the 8 components, the pointor slice and the XOR reading of chirality are ours; spin sums and a gauge field are not shown, and the only solutions are free plane waves. Most of the author's own writing is known to us only through standard sources.", deadEnd: false },
  { id: 'S19', source: 'Dorst and De Keninck, May the Forque Be with You: dynamics in PGA (v2.6)', itSays: "Rigid-body dynamics in projective geometric algebra: Ṁ = −½MB_b, momentum P = I[B], force and torque in one line, Ṗ = F ⇔ Ḃ = I⁻¹[B × I[B] + F]; the equations of motion coincide in the three PGAs (credited to Gunn).", weComputed: "A 41-row translation matrix on the bit rule as exact power series (forque_selfcheck.py): 27 rows agree exactly, 9 after a noted correction, 5 not checked; numpy 4×4 matrices against Newton–Euler agree (forque_matrix_check.py); Mozzi–Chasles as the λ = S, 0 case of the n = 4 decomposition (T17 (d)).", verdict: "Exact for 27 rows, structural for 9; the three-PGA statement is cited, not re-derived (only the degenerate case is here); the nine corrected rows are listed neutrally and may be our slips.", deadEnd: false },
  { id: 'S20', source: 'Roelfs, Eelbode and De Keninck, From invariant decomposition to spinors, and Roelfs and De Keninck, Graded symmetry groups: plane and simple', itSays: "Pointors ψOψ̃ = ρO, the invariant decomposition of a bivector into commuting simple parts, the Riesz-type example in Cl(2,2) with complex λ, the Clifford representation.", weComputed: "30 rows arranged by subject with matrix checks in Cl(2,0)…Cl(7,0) and Cl(1,3) (spin_selfcheck.py, 604 claims): 22 agree exactly, 2 after a noted correction, 6 not checked; at n = 4 the roots λ² − Sλ + W²I²/4 = 0 are complex only in Cl(2,2) and the decomposition formula b_i = B(T − λ_i)/(λ_j − λ_i) is proved for λ₁ ≠ λ₂ (T17 (d)); Mozzi–Chasles, non-coplanar boosts, the regular representation (gtg_check.py part R).", verdict: "Exact for 22 rows; Theorem 2 with independent angles fails at k = 2 in our exact check (we suspect a misreading); the isoclinic case and the general-n decomposition are open (QT5).", deadEnd: false },
  { id: 'S21', source: 'Gunn, projective geometric algebra (SIGGRAPH 2019 course notes) and the three Cayley–Klein cases', itSays: "Euclidean, elliptic and hyperbolic geometry from one algebra with an extra generator of square 0, −1 or +1; the plane-based picture; the equations of motion coincide in the three cases.", weComputed: "One extra generator of square s ∈ {0, −1, +1} gives the three geometries with [B_an, B_bn] = −2s·B_ab, Jacobi, and a Killing form degenerate exactly on the n translations at s = 0; Poincaré, de Sitter and anti-de Sitter on a Lorentz base; PGA inside CGA for n = 2, 3 (projective_selfcheck.py, projective_matrix_check.py); isometries of ℝⁿ as at most n + 1 plane mirrors.", verdict: "Standard, checked; the extra-bit reading is ours; any physical role of the extra generator and conformal dynamics stay open.", deadEnd: false },
  { id: 'S22', source: 'Furey, Standard Model symmetries and the nested embeddings ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 (arXiv:2607.18450)', itSays: "A 16-dimensional real module V with a complex structure ω = L(e₇); End(V) = M₁₆(ℝ) splits into Peirce blocks; hypercharge from an equal-trace condition on block idempotents (eqs. 38–39); one generation on the off-diagonal blocks.", weComputed: "With the construction as input: Peirce blocks of ranks (2,6,4,2,1,1), diagonal 62 and off-diagonal 194; six edges hold exactly one generation (16 complex dimensions); four edges hold 8 replica-type dimensions; all 20 labels and charges of her Fig. 1 equal the Peirce-edge irreps of their cells; the board holds one complete Standard Model set, or two with every cell doubled; an exhaustive search over 5582 admissible blocks finds at most one complete set, and three first fit at 14 complex dimensions (furey_papers_check.py, run_all.py, threegen_selfcheck.py, dictionary_selfcheck.py); the Cartan operators as signed combinations of 14 faces.", verdict: "Checked as computations on a given input; nothing derives the Standard Model, and no link between the Maxwell test and the model is claimed. Open: the cell of the top quark, a family structure, the mass scale, whether the replica edges are physical; whether End(V) contains the E₆-complement A₂ of T13 (QT8).", deadEnd: false },
  { id: 'S23', source: 'Ablamowicz, On Clifford algebras and related finite groups and group algebras (arXiv:1610.03583)', itSays: "Clifford algebras and the finite groups they generate (Salingaros vee groups), with references to Chernov and to Albuquerque and Majid for the twisted-group-algebra view.", weComputed: "Nothing against the paper itself; the atlas's step 17 (the quadratic form over 𝔽₂, O(Q) per class, W(E_n) mod 2, S_{n+1} in O(Q), the Golay code) and T9, T11, T12, T14 are its closest neighbours.", verdict: "Open: the closest published relative we know of, found late, listed here and not yet compared line by line; whether the bit rule as a twisted group algebra tied to Walsh functions and the Gray code is in this work or in Chernov's is a question for its author.", deadEnd: false },
  { id: 'S24', source: 'Recalled theorems used without being opened in this round', itSays: "Wall 1964 (the Brauer–Wall group ℤ₈), Hurwitz (composition algebras), de la Peña 1991 (tame implies a weakly non-negative Tits form), Ladkani (derived equivalences of incidence algebras), Dieudonné 1948 and Taylor (generation of O(q) by transvections), Bourbaki's tables of Weyl-group orders, Kac (types of generalized Cartan matrices), Milnor–Husemoller (van der Blij, Milgram), MacWilliams–Sloane (Turyn's construction), Conway–Sloane (Leech, M₂₄), Eastham and Reed–Simon (Floquet–Bloch), Wald 12.5, Skowroński–Yamagata (Nakayama automorphism).", weComputed: "In every case the finite claim that the atlas needs is computed independently, and where a theorem is used for general n the status is 'reduced' (T4, T6, T8, T12) or the sentence is marked recalled.", verdict: "No verdict depends on a recalled source; what rests on them is listed theorem by theorem (statusNote) and in QT1–QT3.", deadEnd: false },
  { id: 'S25', source: 'Matching numbers across papers without a mechanism (10, 12, 16, 24, 27, 32, the two 8s)', itSays: "The same numbers recur: 27 (cubic surface lines, E₆ minuscule, the elliptic quadric of Cl(6,0)), 24 (the 24-cell, the Golay length, the three 8s), 8 (the Clifford period and the stop of the finite E_n series), (1,9) (h₂(𝕆) and the triangulation form).", weComputed: "Each number has a computed model on labels; where a mechanism exists it is stated as a theorem (the 27 of Cl(6,0) is Q⁻(5,2) and W(E₆) = O⁻₆(2) acts on it, T9 and T11; the Type II codes and the Golay Lagrangian, T14; the shared 8 is the Gauss-sum period, T10 (7)); where none exists the match is tagged open.", verdict: "Dead end as evidence: a shared number is not a link. What survives is the list of the computed mechanisms above; the stop at E₈ is not caused by Clifford periodicity (T10) and the (1,9) match has no mechanism (S13).", deadEnd: true }
];

// The check scripts: those shipped in the app package (selfcheck/, the steps 15–17 folder, the Furey scripts at the package root) and the twenty theorem checks (to be shipped in researchers_checks/ with their three helper modules bitrule_A.py, f2lib.py, clC.py). Every script below was run on 6 October 2026 on the v10.1 package and the derivation folders; the 'checks' column quotes what the script prints. Times are from one run on a shared 2-vCPU machine.
export const RUN = [
  { script: 'selfcheck/maxwell_selfcheck.py', what: 'Maxwell ∇F = J in k time and d space dimensions, every split with k, d ≤ 4 and k + d ≤ 7, exact polynomial fields (Test 1).', checks: 'Prints ALL MAXWELL CHECKS PASS (no count printed); about 5 s.', command: 'python3 selfcheck/maxwell_selfcheck.py' },
  { script: 'selfcheck/dictionary_selfcheck.py', what: "The Furey dictionary: V = 𝕆 + 𝕆′, Cl(0,8) generators, blades as faces of the 7-simplex, Peirce blocks (needs numpy).", checks: 'Prints ALL DICTIONARY CHECKS PASS; about 1 s.', command: 'python3 selfcheck/dictionary_selfcheck.py' },
  { script: 'selfcheck/equations_selfcheck.py', what: "Bivector commutators (so(p,q)) and Hestenes' Dirac equation in the even part of Cl(1,3): 8 components, 40 incidences, covariance (step 1, step 2).", checks: 'Prints ALL EQUATION CHECKS PASS; under 1 s.', command: 'python3 selfcheck/equations_selfcheck.py' },
  { script: 'selfcheck/dirac_matrix_check.py', what: 'The Hestenes form against the usual 4×4 complex gamma matrices, no free parameters (needs numpy).', checks: 'Prints ALL DIRAC MATRIX CHECKS PASS (worst error 0.0e+00, s = 1); under 1 s.', command: 'python3 selfcheck/dirac_matrix_check.py' },
  { script: 'selfcheck/coupling_selfcheck.py', what: 'Maxwell meets Dirac with minimal coupling, n = 1..8, exact (step 3).', checks: 'Prints ALL COUPLING CHECKS PASS; about 1 s.', command: 'python3 selfcheck/coupling_selfcheck.py' },
  { script: 'selfcheck/coupling_matrix_check.py', what: 'The coupled system with explicit complex matrices, n = 3..7 (needs numpy).', checks: 'Prints ALL MATRIX CHECKS PASS; under 1 s.', command: 'python3 selfcheck/coupling_matrix_check.py' },
  { script: 'selfcheck/yangmills_selfcheck.py', what: 'Yang–Mills with the bivectors of Cl(0,m) as gauge algebra, exact fields (step 4).', checks: 'Prints ALL YANG-MILLS CHECKS PASS; about 4 s.', command: 'python3 selfcheck/yangmills_selfcheck.py' },
  { script: 'selfcheck/yangmills_matrix_check.py', what: 'The Yang–Mills structure with explicit matrices, m = 2..6 (needs numpy).', checks: 'Prints ALL YANG-MILLS MATRIX CHECKS PASS; under 1 s.', command: 'python3 selfcheck/yangmills_matrix_check.py' },
  { script: 'selfcheck/matter_selfcheck.py', what: 'Charged matter: the Dirac field with an internal so(m) index, covariant derivative and current (step 5).', checks: 'Prints ALL MATTER CHECKS PASS; about 20 s.', command: 'python3 selfcheck/matter_selfcheck.py' },
  { script: 'selfcheck/matter_matrix_check.py', what: 'The matter equation and its current with explicit matrices, (n,m) = (3,2) … (4,4) (needs numpy).', checks: 'Prints ALL MATTER MATRIX CHECKS PASS; about 8 s.', command: 'python3 selfcheck/matter_matrix_check.py' },
  { script: 'selfcheck/gravity_selfcheck.py', what: 'Connection, curvature, torsion, the Einstein form and its conservation, with forms as the all-null bit rule (steps 6, 7).', checks: 'Prints ALL GRAVITY CHECKS PASS; about 12 s.', command: 'python3 selfcheck/gravity_selfcheck.py' },
  { script: 'selfcheck/gravity_matrix_check.py', what: 'The gravity structure constants and curvature with explicit matrices and tensors (needs numpy).', checks: 'Prints ALL GRAVITY MATRIX CHECKS PASS; about 1 s.', command: 'python3 selfcheck/gravity_matrix_check.py' },
  { script: 'selfcheck/mirrors_selfcheck.py', what: 'Reflections, versors and Cartan–Dieudonné on the bit rule, n = 2..5 (step 8).', checks: 'Prints ALL MIRRORS CHECKS PASS; about 2 s.', command: 'python3 selfcheck/mirrors_selfcheck.py' },
  { script: 'selfcheck/mirrors_matrix_check.py', what: 'The twisted sandwich and Householder Cartan–Dieudonné with explicit matrices, n = 2..6 (needs numpy).', checks: 'Prints ALL MIRRORS MATRIX CHECKS PASS; under 1 s.', command: 'python3 selfcheck/mirrors_matrix_check.py' },
  { script: 'selfcheck/projective_selfcheck.py', what: 'One more generator and a null pair: the Cayley–Klein ladder, Poincaré / de Sitter / anti-de Sitter, PGA inside CGA (step 9; needs mirrors_selfcheck.py beside it).', checks: 'Prints ALL PROJECTIVE CHECKS PASS; about 5 s.', command: 'python3 selfcheck/projective_selfcheck.py' },
  { script: 'selfcheck/projective_matrix_check.py', what: 'The projective and conformal step with explicit matrices, n = 2..4 (needs numpy).', checks: 'Prints ALL PROJECTIVE MATRIX CHECKS PASS; under 1 s.', command: 'python3 selfcheck/projective_matrix_check.py' },
  { script: 'selfcheck/forque_selfcheck.py', what: "The Forque dynamics of Dorst and De Keninck as a 41-row translation matrix, exact power series (step 10).", checks: 'Prints the matrix and the line 41 rows: 27 agree exactly, 9 agree after the noted correction, 5 not checked; with --quick about 5 s (the slow power-series rows are skipped; the full run was not timed here).', command: 'python3 selfcheck/forque_selfcheck.py --quick' },
  { script: 'selfcheck/forque_matrix_check.py', what: 'The Forque dynamics with explicit 4×4 matrices against Newton–Euler, RK4 (needs numpy).', checks: 'Prints ALL NUMERIC CHECKS PASS with the negative controls; about 26 s.', command: 'python3 selfcheck/forque_matrix_check.py' },
  { script: 'selfcheck/spin_selfcheck.py', what: 'Spinors, the three kinds of i, and the invariant decomposition and pointors of Roelfs, Eelbode and De Keninck (step 11).', checks: 'Prints 604/604 claims hold. ALL SPIN CHECKS PASS; about 1 s.', command: 'python3 selfcheck/spin_selfcheck.py' },
  { script: 'selfcheck/spring_selfcheck.py', what: 'A spring on the cube: one oscillator as a rotor, the spring network, the signed network (step 12).', checks: 'Prints 60/60 claims hold. ALL SPRING CHECKS PASS; under 1 s.', command: 'python3 selfcheck/spring_selfcheck.py' },
  { script: 'selfcheck/pgadyn_selfcheck.py', what: 'Rigid bodies from the segment to the tesseract in R(n,0,1), exact rational arithmetic (step 13).', checks: 'Prints 110/110 checks hold in 56 claims. ALL RIGID-BODY CHECKS PASS; about 3 s.', command: 'python3 selfcheck/pgadyn_selfcheck.py' },
  { script: 'selfcheck/null_selfcheck.py', what: 'Null surfaces: the four claims of Hsu, Barker, Hobson and Lasenby in exact fractions, the horizon algebra Cl(0, n−2, 1) (step 14).', checks: 'Prints one PASS line per check and 64 of 64 computed checks pass; 2 readings listed, not counted; about 16 s.', command: 'python3 selfcheck/null_selfcheck.py' },
  { script: 'selfcheck/shapes_selfcheck.py', what: 'The orthoplex and the demicube: face counts, duality, even subalgebras (More shapes).', checks: 'Prints ALL SHAPE CHECKS PASS; about 3 s.', command: 'python3 selfcheck/shapes_selfcheck.py' },
  { script: 'selfcheck/gosset_selfcheck.py', what: 'E₆, E₇, E₈ (and E₉, E₁₀) from the Cartan matrices, exact (Gosset series).', checks: 'Prints ALL GOSSET CHECKS PASS; under 1 s.', command: 'python3 selfcheck/gosset_selfcheck.py' },
  { script: 'selfcheck/furey_papers_check.py', what: 'Her six papers rebuilt from the octonion table, her Fig. 1 against the Peirce edges, the count of complete sets and the room three sets need (Furey, four tabs).', checks: 'Prints ALL FUREY-PAPER CHECKS PASS (30 checks); about 15 s; needs numpy; --compare checks the stored data.', command: 'python3 selfcheck/furey_papers_check.py' },
  { script: 'selfcheck/threegen_selfcheck.py', what: 'How many generations the 256 real dimensions of M₁₆(ℝ) can hold: the search over admissible blocks (Furey, three generations).', checks: 'Prints ALL THREE-GENERATION CHECKS PASS; about 3 s.', command: 'python3 selfcheck/threegen_selfcheck.py' },
  { script: 'selfcheck/matrixrep_check.py', what: 'The matrix route: Cl(k,k) = M_{2^k}(ℝ) for n = 2..10, Cl(N+8) = M₁₆(Cl(N)), the motor product as three Euclidean products.', checks: 'Prints ALL MATRIX-ROUTE CHECKS PASS; about 8 s.', command: 'python3 selfcheck/matrixrep_check.py' },
  { script: 'selfcheck/steps15_17/labels_check.py', what: 'Step 15, the clock: the labels −1, +1, 0 and the type of every cell from invariants, walking up from Cl(0) (needs numpy for one section).', checks: 'Prints the tables and ALL LABELS CHECKS PASS; about 3 s.', command: 'cd selfcheck/steps15_17 && python3 labels_check.py' },
  { script: 'selfcheck/steps15_17/gtg_check.py', what: 'Step 16: the space-time algebra, gauge gravity as shears, with vacuum and free-fall tests of their metrics, the Dirac action, the Roelfs–De Keninck decomposition, reflection lengths over 𝔽₂ (needs numpy).', checks: 'Prints ALL GTG/RDK CHECKS PASS; about 11 s.', command: 'cd selfcheck/steps15_17 && python3 gtg_check.py' },
  { script: 'selfcheck/steps15_17/groups_check.py', what: 'Step 17, the finite lens: O(Q) per class, W(E_n) mod 2, Pin lifts, the Golay code, M₂₄, Leech, the primes, the Klein correspondence (needs numpy for one check).', checks: 'Prints 189 ok lines and ALL GROUP CHECKS PASS; about 25 s.', command: 'cd selfcheck/steps15_17 && python3 groups_check.py' },
  { script: 'selfcheck/steps15_17/run_mutations.py', what: 'Mutation test of the three step 15–17 scripts: each mutant changes one line and must make its script fail.', checks: 'Prints one line per mutant with KILLED or SURVIVED; about 4 minutes, so run_tests.sh does not run it (not re-run here).', command: 'cd selfcheck/steps15_17 && python3 run_mutations.py' },
  { script: 'run_all.py', what: "Furey's Peirce-block construction in an explicit 16-dimensional real model (with model.py): block ranks, edge capacities, hypercharge, the Witt torus; writes furey_results.json (needs numpy).", checks: 'Prints ALL FUREY CHECKS PASS and the result summary; about 3 s.', command: 'python3 run_all.py' },
  { script: 'family_test.py', what: 'The family of block partitions behind the Furey page (with model.py; needs numpy).', checks: 'Prints ALL FAMILY ASSERTIONS PASS; about 15 s.', command: 'python3 family_test.py' },
  { script: 'peirce_test.py, witt_test.py, z2_test.py', what: 'Exploratory printouts of the Peirce edges, the Witt torus and the ω′ = −R(e₇) question (with model.py; needs numpy); the assertions live in run_all.py.', checks: 'Print tables, no pass line; a few seconds each.', command: 'python3 peirce_test.py; python3 witt_test.py; python3 z2_test.py' },
  { script: 'researchers_checks/check_T1.py', what: 'T1: associativity of the bit rule for every n and every ε (needs bitrule_A.py and numpy).', checks: 'Prints one ok line per item and ALL OK; about 2 s.', command: 'cd researchers_checks && python3 check_T1.py' },
  { script: 'researchers_checks/check_T2.py', what: 'T2: radical, Loewy layers, super-centre, graded tensor product, grading lift (needs bitrule_A.py).', checks: 'Prints ALL OK; about 3 s.', command: 'cd researchers_checks && python3 check_T2.py' },
  { script: 'researchers_checks/check_T3.py', what: 'T3: the top-label Frobenius form, Nakayama automorphism, symmetric forms, the torsor (needs bitrule_A.py).', checks: 'Prints ALL OK; about 4 s.', command: 'cd researchers_checks && python3 check_T3.py' },
  { script: 'researchers_checks/check_T4.py', what: 'T4: the three isomorphisms, the mod-8 table, the Gauss sum, the Frobenius–Schur count (needs bitrule_A.py and numpy).', checks: 'Prints ALL OK; under 1 s.', command: 'cd researchers_checks && python3 check_T4.py' },
  { script: 'researchers_checks/check_T5.py', what: 'T5: even subalgebra, D1, D2, the null failure (needs bitrule_A.py).', checks: 'Prints ALL OK; about 1 s.', command: 'cd researchers_checks && python3 check_T5.py' },
  { script: 'researchers_checks/check_T6.py', what: 'T6: the cube sign, the Koszul complex, H², the octonion cochain (needs bitrule_A.py).', checks: 'Prints ALL OK; under 1 s.', command: 'cd researchers_checks && python3 check_T6.py' },
  { script: 'researchers_checks/check_T7.py', what: "T7: Tian's algebra in a hyperbolic basis, the radical vector, the sorting sign (needs bitrule_A.py and numpy).", checks: 'Prints ALL OK; about 3 s.', command: 'cd researchers_checks && python3 check_T7.py' },
  { script: 'researchers_checks/check_T8.py', what: 'T8: Cartan, Euler, Coxeter and Tits forms of the cube category (needs bitrule_A.py and numpy).', checks: 'Prints ALL OK; under 1 s.', command: 'cd researchers_checks && python3 check_T8.py' },
  { script: 'researchers_checks/check_T9.py', what: 'T9: E_n/2E_n and A_n/2A_n as label forms, W(E_n) mod 2 by Schreier–Sims (needs f2lib.py).', checks: 'Prints ALL 186 CHECKS PASSED; about 15 s.', command: 'cd researchers_checks && python3 check_T9.py' },
  { script: 'researchers_checks/check_T10.py', what: 'T10: determinants, signatures and types of E_n to n = 20, roots, D₈⁺ (needs f2lib.py and numpy).', checks: 'Prints ALL 805 CHECKS PASSED; about 4 s.', command: 'cd researchers_checks && python3 check_T10.py' },
  { script: 'researchers_checks/check_T11.py', what: 'T11: totally singular subspaces of every Cl(p,q) with p + q ≤ 9, the quadric counts, the Peres–Mermin square (needs f2lib.py).', checks: 'Prints ALL 74749 CHECKS PASSED; about 45 s.', command: 'cd researchers_checks && python3 check_T11.py' },
  { script: 'researchers_checks/check_T12.py', what: 'T12: transvection groups and lengths for every 𝔽₂ class with n ≤ 6 (needs f2lib.py).', checks: 'Prints the length table and ALL 7 CHECKS PASSED; about 10 s.', command: 'cd researchers_checks && python3 check_T12.py' },
  { script: 'researchers_checks/check_T13.py', what: 'T13: the A₂ subsystems of E₈, their E₆ complements, the 27-point graphs, E₇ ⊃ A₂ × A₅ (needs f2lib.py).', checks: 'Prints ALL 302 CHECKS PASSED; about 2 s.', command: 'cd researchers_checks && python3 check_T13.py' },
  { script: 'researchers_checks/check_T14.py', what: "T14: the Hamming and Golay codes, the Lagrangian of Cl(24,0), Type II iff 8 | n, S(5,8,24) (needs f2lib.py).", checks: 'Prints ALL 54 CHECKS PASSED; under 1 s.', command: 'cd researchers_checks && python3 check_T14.py' },
  { script: 'researchers_checks/check_T15.py', what: 'T15: states and positivity with null generators, four involutions, the Bloch ball (needs clC.py and numpy).', checks: 'Prints check_T15: 4648 of 4648 assertions hold; under 1 s.', command: 'cd researchers_checks && python3 check_T15.py' },
  { script: 'researchers_checks/check_T16.py', what: 'T16: Dirac-type symbol determinants on every module, the Cl(3,1) shells, the Hestenes determinant (needs clC.py and numpy).', checks: 'Prints check_T16: 391 of 391 assertions hold; under 1 s.', command: 'cd researchers_checks && python3 check_T16.py' },
  { script: 'researchers_checks/check_T17.py', what: 'T17: bivector squares, the trichotomy, the n = 4 decomposition, Mozzi–Chasles, the strain trace (needs clC.py and numpy).', checks: 'Prints check_T17: 12009 of 12009 assertions hold; about 3 s.', command: 'cd researchers_checks && python3 check_T17.py' },
  { script: 'researchers_checks/check_T18.py', what: 'T18: the null criterion, the horizon algebra, the Killing identity, hyperbolicity (needs clC.py and numpy).', checks: 'Prints check_T18: 2023 of 2023 assertions hold; under 1 s.', command: 'cd researchers_checks && python3 check_T18.py' },
  { script: 'researchers_checks/check_T19.py', what: 'T19: the SL(2,ℝ) trichotomy, a Kronig–Penney potential, the cube spring, the signed network (needs clC.py and numpy).', checks: 'Prints check_T19: 8881 of 8881 assertions hold; about 1 s.', command: 'cd researchers_checks && python3 check_T19.py' },
  { script: 'researchers_checks/check_T20.py', what: 'T20: creation and annihilation from the bit rule, the CAR, Cl(m,m) = End Λ, Witt pairs, the D_m roots (needs clC.py and numpy).', checks: 'Prints check_T20: 2015 of 2015 assertions hold; under 1 s.', command: 'cd researchers_checks && python3 check_T20.py' }
];

export const GENESIS_NOTE = {
  frozen: 'The nine node texts of the Genesis story are frozen: they are not changed by the audit; the audit statements GEN-001..009 are not what the page shows.',
  later: [
    { id: 'GEN-002', note: "Time convention. Node 1 calls the cell [1,+1] space-like and [1,−1] time-like, while the atlas's rule page (MAP-001) and its Dirac step take time to square to +1 (Cl(1,3)). The two conventions are both in use; which one the Genesis story follows should be said once, on the rule page or in the node, in a later pass." },
    { id: 'GEN-003', note: "'Positive versus negative is a gauge choice.' No automorphism of Cl(1,1) exchanges e = n + ñ (square +1) and f = n − ñ (square −1): the swap ñ → −ñ is an anti-isometry, the cell is its own mirror. The sentence is exact for this one pair and would be wrong for larger cells, where Cl(p,q) and Cl(q,p) differ (M₄(ℝ) against M₂(ℍ)) and the choice must match the sign conventions of the Dirac operator; the wording to prefer later is 'a convention for this pair'." },
    { id: 'GEN-008', note: "'The same mechanism as at Nodes 1, 3, 5 with a larger block.' The mechanism, a central top blade with ω² = +1 that splits the algebra into two sectors, holds for the signed odd cells Cl(1,0), Cl(2,1), Cl(3,2). At the null-spectator nodes 1, 3, 5 (Cl(0,0,1), Cl(1,1,1), Cl(2,2,1)) the top blade is central but contains the null bit, so it squares to 0 and splits nothing (any label with a null bit is nilpotent, T2). The sentence should name the signed cells in a later pass." }
  ]
};
