// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// "Notes to the researcher" (v10.1 add-on): for every group of researchers whose work the atlas rebuilds or points to, one short note on how to read the atlas from their own work.
// One source for two uses: the pop-up of the atlas (ResearcherNote.jsx, opened by  ?for=<slug>) and the standalone e-mail file (built by a private tool that lives outside this package), so that the e-mail, the note and the atlas cannot disagree.
// Every statement is a ledger item of the atlas (lib/chatPersona.js) or a line of a check script (selfcheck/*.py, selfcheck/steps15_17/*.py), quoted with its tag (checked / standard / ours / open).
// test_notes.mjs pins: every link `go` is a real page/tab, every tag is one of the four, the e-mail stays short, and addresses are marked by where they come from.
// English only for now (the audience is the researchers themselves). Plain text and Unicode: no markup, so the note needs no typesetter.

export const TAG_NAMES = ['checked', 'standard', 'ours', 'open'];

// This file holds no e-mail address (the atlas ships none, test_license.mjs); the addresses and where they were found are kept in a private folder outside this package, never in it.

export const NOTE_TEXT = {
  title: id => `A note for ${id}`,
  who: 'The Cascade Atlas is a free, non-commercial web atlas that rebuilds Clifford algebras from one bit rule (e_a e_b = ± e_(a xor b)) and checks known results with exact scripts. It was built by Federico Pasinato together with Claude, an AI model made by Anthropic; the work and its errors are ours, and an AI wrote much of the code and the first drafts.',
  scope: 'What this is not: a theory of nature. Every item below is a rebuilding of something you or others wrote, or a reading of it, and each carries one of four tags: checked (computed by a script you can run), standard (textbook or published), ours (a reading we propose) and open (not established). Some items may be our mistakes; please say so.',
  first: 'Three things to look at first',
  path: 'A reading path from your own work',
  standard: 'Standard, ours, open',
  check: 'Where your eyes would help most',
  unread: 'What we have not read',
  write: 'Write to the authors',
  close: 'Close and open the atlas',
  openIn: 'Open',
  tagHelp: { checked: 'computed by a script', standard: 'textbook or published', ours: 'our reading', open: 'not established' },
};

// go: 'page' or 'page/tab' of the atlas (hash route). tag (a point of the letter): one of TAG_NAMES. tags (a stop of the reading path): the tags of that
// statement, in the order standard, checked, ours, open, as the second audit round set them (v10.2); none for a stop that only points to a page. A stop made of
// statements with different tags lists them as parts ({ text, tags }); its what is their text joined, its tags their union.
// The curvature stop of the Lasenby note: a count (checked) and a reading (ours).
const CURVATURE = [
  { text: 'Riemann = n²(n²−1)/12, Ricci = n(n+1)/2, Weyl first non-zero at n = 4 (20 = 10 + 10); the 4-vector part B∧B of a bivector square lives in Λ⁴, exactly the space the first Bianchi identity removes from Sym²(Λ²), and both first appear at n = 4.', tags: ['standard', 'checked'] },
  { text: 'That Weyl’s first appearance and the 4-vector part of B² share a cause is a reading, not a theorem.', tags: ['ours'] },
];
export const RESEARCHERS = [
  {
    id: 'furey', slug: 'furey', priority: 'send',
    people: [{ name: 'Cohl Furey', role: 'to', affil: 'Humboldt-Universität zu Berlin' }],
    salutation: 'Dear Dr Furey,',
    work: 'your paper “Standard Model Symmetries and the Nested Embeddings of R ⊂ C ⊂ H ⊂ O” (arXiv:2607.18450v2)',
    subject: 'Your R ⊂ C ⊂ H ⊂ O model rebuilt in a small open atlas: feedback welcome',
    hooks: [
      { text: 'With your module and ω = L(e₇) as input, End(V) = M₁₆(ℝ) splits into Peirce blocks of ranks (2,6,4,2,1,1); six edges hold exactly one Standard Model generation (16 complex dimensions).', go: 'furey/findings', tag: 'checked' },
      { text: 'An exhaustive search over 5,582 admissible 8-dimensional blocks finds at most one complete Standard Model set; the 20 cells of your Fig. 1 hold one, or two with every cell doubled, and three sets first fit at 14 complex dimensions.', go: 'furey/threegen', tag: 'checked' },
      { text: 'The Cartan operators Y₀, Q₀, T₃, λ₃, λ₈ are signed combinations of 14 faces, and the 28 edges are 4 gauge, 16 matter and 8 replica edges forming a Fano plane of 7 channels.', go: 'furey/findings', tag: 'checked' },
    ],
    note: {
      lead: 'The atlas takes your construction as given input and asks only what can be computed inside it. Nothing here derives the Standard Model, and no link between our Maxwell test and your model is claimed.',
      path: [
        { go: 'furey/dictionary', title: 'Dictionary', what: 'Every Standard Model particle and gauge generator of one generation of your model, in six notations, side by side.', tags: ['standard', 'checked'] },
        { go: 'furey/findings', title: 'Her 2026 model', what: 'Peirce blocks of End(V) = M₁₆(ℝ) with ranks (2,6,4,2,1,1), diagonal 62, off-diagonal 194; ω swaps the two rank-1 blocks and gives M₈(ℂ). Six edges hold exactly one generation (16 complex dimensions: Q_L 6, u_R 3, d_R 3, L 2, e_R 1, ν_R 1); four edges hold 8 complex dimensions of replica-type content; the largest edge, 12 complex dimensions, is Q_L plus its conjugate.', tags: ['checked'] },
        { go: 'furey/threegen', title: 'Three generations', what: 'All 20 labels and charges of your Fig. 1 equal the Peirce-edge irrep of their cell. With one label per cell the board holds one complete Standard Model set and 8 complex dimensions beyond it (b_R, τ_R, two doublets); with every cell doubled it holds two sets, and exactly Q_L, u_R and ν_R lack a third copy. In gauge quantum numbers b_R ⊗ h contains Q_L, b_R ⊗ τ_R† contains u_R and h ⊗ the lepton doublet contains ν_R. End(V) is 128 complex dimensions (16 diagonal, 48 linear off-diagonal, 64 antilinear, of which 32 have exotic charges). Over all 5,582 admissible 8-dimensional blocks at most one set fits; three sets first fit at 14 complex dimensions.', tags: ['checked'] },
        { go: 'shapes/gosset', title: 'A coincidence we leave open', what: 'E8 contains E6 × A2 with 72 + 6 + 3 × 27 + 3 × 27̄: a 3 from branching. This A2 is, up to the Weyl group of E8, the generation sl₃ of Baez’s “Three generations in E7” (all 1120 A2 subsystems of E8 are conjugate, each with complement E6). Whether it has anything to do with generations in our model is open.', tags: ['checked', 'open'] },
      ],
      standard: 'Standard: your construction (the nested flag and ω) is the input, not derived. Checked by us: Peirce ranks, edge capacities, hypercharge differences, the 14-face Cartan ledger, the 5,582-block search. Ours: reading the 28 edges as 4 gauge, 16 matter, 8 replica. Open: the cell of the top quark, a family structure giving three generations, the mass scale and the Higgs value, whether the replica edges are physical, weak chirality, confinement.',
      check: [
        'The Witt-torus partition (which axes belong to which block) is input in our scripts: 616 of 18,480 candidate quadruples diagonalise all the block projectors. Is our choice the one you use?',
        'Whether “replica” is a fair name for the edges that hold 8 complex dimensions of replica-type content, or whether you see them differently.',
        'Our three-generation search is restricted to blocks 1, 2, 3, 3̄ with Standard Model hypercharges |y| ≤ 2. If your intended counting is different, the result may not apply.',
        'Is Fig. 1 meant with one label per cell (the 8 × 8 complex form) or with every cell doubled (the hermitian 16 × 16 form)? The count of complete sets depends on it: one, or two.',
      ],
      unread: 'Your 2025 paper “A Superalgebra Within”, which we know only through the 2026 paper; of the other five papers we rebuilt the statements on the page, not their other results.',
    },
  },
  {
    id: 'dorst', slug: 'dorst', priority: 'send',
    people: [
      { name: 'Leo Dorst', role: 'to', affil: 'University of Amsterdam' },
      { name: 'Steven De Keninck', role: 'to', affil: 'University of Amsterdam / bivector.net' },
    ],
    salutation: 'Dear Leo Dorst and Steven De Keninck,',
    work: 'your paper “May the Forque Be with You: Dynamics in PGA” (v2.6) and the PGA work around it',
    subject: 'Your Forque dynamics translated to a bit rule, with a 41-row comparison: feedback welcome',
    hooks: [
      { text: 'The Forque equations, translated to the bit rule and checked as exact power series: of 41 rows, 27 agree exactly, 9 need a small adjustment that we list neutrally (probably our slips), 5 are not checked.', go: 'equations/forque', tag: 'checked' },
      { text: 'The same equation runs from a free segment to a tesseract: the free top is an oscillator, an inverted oscillator (the tennis-racket flip) or null by the sign of one number, and RK4 keeps points as points while one Euler step leaves the motor group.', go: 'equations/rigid', tag: 'checked' },
      { text: 'The sign of X² for a bivector in Cl(2,0) sorts rotation, translation and boost; from n = 4 a bivector square has two parts, complex only in Cl(2,2), the case behind the Roelfs and De Keninck invariant decomposition.', go: 'labels/clock', tag: 'checked' },
    ],
    note: {
      lead: 'The atlas rebuilds the equations of your PGA dynamics on the bit rule, where a motor is an even blade, that is a vertex of the n-cube. We did this to see whether the rule carries a real piece of physics, and we are aware that you did the thinking first.',
      path: [
        { go: 'equations/forque', title: 'Step 10, Forque dynamics', what: 'Ṁ = −½ M B_b, momentum P = I[B], force and torque in one line F = f·Q, and Ṗ = F ⇔ Ḃ = I⁻¹[B × I[B] + F], as exact power series. A 41-row translation matrix (your equation, ours, a one-line check, a worked instance): 27 agree, 9 agree after a noted correction, 5 not checked (Lagrangian form 2.38, constrained motion 2.9, code figures, exp/log closed forms, exercises). numpy 4×4 matrices against Newton–Euler agree.', tags: ['standard', 'checked'] },
        { go: 'equations/rigid', title: 'Step 13, a rigid body from a segment to a tesseract', what: '110 claims in 56 rows: spin about a principal axis is stationary and a diagonal one is not; the free top oscillates, flips or is null by the sign of μ = b²(I_c − I_a)(I_a − I_b)/(I_b I_c); Kepler energy, angular momentum and the Laplace–Runge–Lenz vector are exact. The versor condition fails by one equation at n = 5 (17 needed, 16 given): a statement about the check, not about nature.', tags: ['standard', 'checked'] },
        { go: 'equations/mirrors', title: 'Step 8, mirrors', what: 'A corner of the n-cube is the product of the coordinate mirrors on its axes; Cartan–Dieudonné (at most n mirrors, same parity, over the reals) checked exactly for n = 2…5.', tags: ['standard', 'checked'] },
        { go: 'equations/projective', title: 'Step 9, one more generator', what: 'One extra generator of square 0, −1 or +1 gives Euclid, elliptic or hyperbolic geometry when space squares −1 (with space +1, as in your PGA papers, elliptic is +1); on the Lorentz base Cl(1,3), Poincaré, de Sitter, anti-de Sitter; PGA embeds in CGA as an injective homomorphism for n = 2, 3.', tags: ['standard', 'checked'] },
        { go: 'equations/spin', title: 'Step 11, pointors and spin (De Keninck, Roelfs, Eelbode)', what: 'The spinor paper read in full and arranged by subject, with matrix checks (see the note for Roelfs and Eelbode).', tags: [] },
        { go: 'labels/clock', title: 'Step 15, the trinity', what: 'For n = 2 the sign of X² for X = a e₁ + b e₂ + c e₁₂ is a² + b² − c²: ellipses, parallel lines, hyperbolas, that is rotation, translation, boost. At n = 4 a bivector square is S + W e₁₂₃₄ and the two roots are complex only in Cl(2,2).', tags: ['standard', 'checked'] },
      ],
      standard: 'Standard: your equations, Cartan–Dieudonné, the Cayley–Klein families, the closed-form motor exponentials. Checked by us: the translation matrix and the ladder. Ours: the cube reading of motors and versors, the bit-rule form. Open: conformal dynamics (your paper has none, and we did not extend it), any physical role.',
      check: [
        'The 9 rows that agree only after a noted correction: please tell us which are our slips and which are typos in print. We have listed them neutrally on purpose.',
        'You are credited with the statement that the equations of motion coincide in the three PGAs. We did not re-derive it; we only have the degenerate case.',
        'Any dynamics we should rebuild next, in the order you would trust.',
      ],
      unread: 'Roelfs and De Keninck on outer exponentials, and the rest of the bivector.net material beyond the Forque paper and the spinor paper.',
    },
  },
  {
    id: 'roelfs', slug: 'roelfs', priority: 'send',
    people: [
      { name: 'Martin Roelfs', role: 'to', affil: 'University of Antwerp' },
      { name: 'David Eelbode', role: 'to', affil: 'University of Antwerp' },
    ],
    salutation: 'Dear Martin Roelfs and David Eelbode,',
    work: 'your papers on the invariant decomposition and spinors (and Steven De Keninck’s share in them)',
    subject: 'Your invariant decomposition and spinor papers rebuilt on a bit rule: a 30-row comparison, feedback welcome',
    hooks: [
      { text: 'Your spinor paper and the GAME23 lecture, arranged by subject with matrix checks in Cl(2,0)…Cl(7,0) and Cl(1,3): of 30 rows, 22 agree exactly, 2 after a noted correction, 5 are not checked, and the probability reading is computed for Cl(3,0) only.', go: 'equations/spin', tag: 'checked' },
      { text: 'Four kinds of “i” are kept apart; our reading of the conjugation label is the ratio of the left to the right eigenvalue.', go: 'equations/spin', tag: 'ours' },
      { text: 'Your Cl(2,2) example with B∧B = −e₁₂₃₄ and the complex pair b₁² = +i/2, b₂² = −i/2 is reproduced exactly, and a live widget shows that from n = 4 complex roots occur only in Cl(2,2).', go: 'labels/clock', tag: 'checked' },
    ],
    note: {
      lead: 'The atlas reads your spinor paper and the lecture by subject and puts a matrix check beside each claim; the invariant-decomposition side of your graded-symmetry work was checked in a separate script. We are sure to have misread something, and the list below says where.',
      path: [
        { go: 'equations/spin', title: 'Step 11, pointors and spin', what: '30 rows in six threads, each with the paper’s view, the lecture’s view and ours, with matrix rows and a live widget. 22 agree exactly, 2 agree after a noted correction (both about which sums of rotors are pointors), 5 are not checked (Theorem 1 in general, PGA points, the announced real idempotent, complex λ, the representation framing), and the probability reading is computed for Cl(3,0) only (Born rule and Bloch ball from the scalar part) and open for the other cells.', tags: ['standard', 'checked'] },
        { go: 'equations/spin', title: 'Four kinds of i', what: '(scalar, 1-vector): the Cl(0,1) mirror unit. (scalar, 2-vector): the bivector unit of the even part. (1-vector, 1-vector): the odd carrier plane x∘y = xuy, an algebra only after choosing u, split-complex for Cl(1,1). The central pseudoscalar I of odd dimension (I² = −1 for Cl(3,0) and Cl(7,0)), which acts as the lecture’s i with no complex numbers added.', tags: ['ours'] },
        { go: 'labels/clock', title: 'Step 15, bivector lab at n = 4', what: 'B² = S + W e₁₂₃₄; the two roots solve λ² − Sλ + W²I²/4 = 0 and are complex only in Cl(2,2). Your Riesz-type example there: B∧B = −e₁₂₃₄, λ = ±i/2, b₁ + b₂ = B, commuting, exp(B) = exp(b₁) exp(b₂). Of 400 random integer bivectors per signature, only Cl(2,2) gives complex roots.', tags: ['standard', 'checked'] },
        { go: 'labels/clock', title: 'Other checks of the decomposition (script gtg_check.py, part R)', what: 'Mozzi–Chasles in Cl(3,0,1); three non-coplanar boosts give a non-simple rotor and the closed-form logarithm works; your “Clifford representation” equals the left-regular representation of the bit rule; the translation rotor T = 1 − a n_∞/2 moves conformal points exactly with n_∞ a null vector of a non-degenerate cell. These live in the script and its log, which we are happy to send; the atlas page shows only the trinity and the bivector lab so far.', tags: ['standard', 'checked'] },
      ],
      standard: 'Standard: your theorems and the Cl(p,q) tables. Checked by us: the 30 rows and the part-R checks. Ours: the left/right eigenvalue reading of the conjugation label, the labels as cosets of a self-dual binary code, the four-i classification. Open: the lecture’s i in even dimension, the probability reading, any physical role.',
      check: [
        'Theorem 2 with independent angles per class fails at k = 2 in our exact check; one common rotor for all classes works for k ≤ 2. We suspect we misread the statement.',
        'Theorem 3 is a remark on wording: “every pointor has this form” against a proof that concludes P = vR with the same R. Our check only covers the converse direction.',
        'Two printed lines about which sums of rotors are pointors differ from our check. Example 9.2 (two boosts) did not reproduce for us as printed: their product lies in Cl(1,2) and is simple.',
      ],
      unread: 'The lecture video (we read the slides only) and the two papers you cite for the decomposition beyond the checks listed above.',
    },
  },
  {
    id: 'lasenby', slug: 'lasenby', priority: 'send',
    people: [
      { name: 'Anthony Lasenby', role: 'to', affil: 'Cavendish Laboratory and Kavli Institute for Cosmology, Cambridge' },
      { name: 'Yi-Hsiung Hsu', role: 'to', affil: 'Cavendish Laboratory, Cambridge' },
      { name: 'Will Barker', role: 'to', affil: 'Institute of Physics, Czech Academy of Sciences, Prague' },
      { name: 'Michael Hobson', role: 'to', affil: 'Cavendish Laboratory, Cambridge' },
      { name: 'Chris Doran', role: 'cc', affil: 'co-author of the gauge theory of gravity' },
      { name: 'Stephen Gull', role: 'cc', affil: 'co-author of the gauge theory of gravity' },
    ],
    salutation: 'Dear Anthony Lasenby, Yi-Hsiung Hsu, Will Barker and Michael Hobson,',
    work: 'your paper “The radial metric function does not identify null surfaces” (arXiv:2504.13255) and the gauge theory of gravity of Lasenby, Doran and Gull',
    subject: 'Null surfaces and the gauge-theory horizon, rebuilt on a bit rule: feedback welcome',
    hooks: [
      { text: 'Four claims of your null-surface paper rebuilt in exact fractions (64 checks): the generator is a photon that stands still, ξ·∇ξ = −κξ with κ = ½ dT/dx, Kerr’s dφ/dt = a/(r₊² + a²), and Schwarzschild against the Ellis wormhole (g^rr = 0 but a timelike throat).', go: 'equations/nullsurf', tag: 'checked' },
      { text: 'Four named situations where g_tt = 0 stops being the null criterion for a static ξ, and the tangent algebra Cl(0,n−2,1) of a null hypersurface, with a null-bit ideal J, J·J = 0.', go: 'equations/nullsurf', tag: 'checked' },
      { text: 'In the gauge theory of gravity, a point mass in the Painlevé–Gullstrand gauge is one shear h̄ = 1 + N, N² = 0; its metric is vacuum (Kretschmann scalar 48M²/r⁶) and free fall gives −M/r². The radial gradient h̄(e_r) squares to g² − 1 = −T: negative outside, 0 on the horizon, positive inside.', go: 'labels/gauge', tag: 'checked' },
    ],
    note: {
      lead: 'Two of your works meet in the atlas: your null-surface paper (rebuilt on the bit rule, step 14) and the gauge theory of gravity (step 16), where the horizon appears as the “0 label” of a three-way sorting by the sign of a square.',
      path: [
        { go: 'equations/nullsurf', title: 'Step 14, null surfaces', what: '(1) The generator of a null surface is a photon that stands still: for n = dx, n·n = −T with T = g_tt, so x = const is null exactly when T = 0, and ξ·∇ξ = −κξ with κ = ½ dT/dx, a geodesic that is not affinely parametrised. On Kerr the radical of the induced metric is the paper’s photon, dφ/dt = a/(r₊² + a²) = 1/30 at five polar angles. (2) Horizon or throat: g^rr = n·n/(T R) vanishes for two unrelated reasons. (3) When g_tt = 0 is the criterion and four ways it fails. (4) The tangent algebra of a null hypersurface, Cl(0,n−2,1).', tags: ['standard', 'checked'] },
        { go: 'equations/nullsurf', title: 'What is ours in step 14', what: 'That “by contrast with the induced-metric approach” is a difference of presentation, and the reading of the ideal J as a facet of the cube and as the star of a vertex. Neither is computed.', tags: ['ours'] },
        { go: 'labels/gauge', title: 'Step 16, gauge gravity', what: 'Newtonian gauge: a point mass is a single shear h̄ = 1 + N, N² = 0, det = 1. The radial gradient h̄(e_r) = e_r + g e_t, the physical gradient of r, squares to g² − 1 = −T with g = √(2M/r): negative outside, 0 on the horizon, positive inside, the same −T as the norm of dr in step 14. The metric dt² − (dr + g dt)² − r²dΩ² is vacuum (Ricci = 0, Kretschmann scalar 48M²/r⁶), free fall gives d²r/dτ² = −M/r² with the conserved energy (6.83), and the curvature operator in the orthonormal frame has eigenvalues (−2, −2, 1, 1, 1, 1) M/r³, those of the point-mass Weyl map. Kerr–Schild h̄ = 1 + (M/r) e₋(e₋·) with e₋ null is the same metric after the time shift φ′ = g/(1+g). Time reversal reflects e_t and sends g to −g. Light cones and a falling raindrop are drawn live.', tags: ['standard', 'checked'] },
        { go: 'labels/gauge', title: 'Curvature by dimension', parts: CURVATURE, what: CURVATURE.map(x => x.text).join(' '), tags: ['standard', 'checked', 'ours'] },
      ],
      standard: 'Standard: the gauge theory of gravity (Lasenby–Doran–Gull), Painlevé–Gullstrand and Kerr–Schild forms, the curvature counts. Checked by us: the signs, the shears, the vacuum test, free fall and chart shifts of the shear metrics, the 64 null-surface checks. Ours: the horizon as the 0 label; the cube reading of J. Open: the field equations of the gauge theory, cosmology and the Hawking parts are not decoded; Eq. (12) of your paper is not rebuilt.',
      check: [
        'Whether our four failure modes of g_tt = 0 match the situations you had in mind, or whether one of them is outside your hypotheses.',
        'Of your references only Vishveshwara’s Appendix B and the abstract of Vollick were read, so something we call ours may already be known.',
        'One author wrote both the claims and the checks, and no second reader has gone through them.',
      ],
      unread: 'Eq. (12) of the null-surface paper; Vollick’s papers beyond the abstract; Doran and Lasenby, Geometric Algebra for Physicists; the action principles and the cosmology of the gauge theory.',
    },
  },
  {
    id: 'vollick', slug: 'vollick', priority: 'send',
    people: [{ name: 'Dan Vollick', role: 'to', affil: 'University of British Columbia Okanagan' }],
    salutation: 'Dear Dr Vollick,',
    work: 'your work on null surfaces in static space-times',
    subject: 'Your null-surface criterion rebuilt on a bit rule, with honest limits: feedback welcome',
    hooks: [
      { text: 'We took the question you answered (which surfaces are null, g_tt = 0 or g^rr = 0) and rebuilt it on a bit rule in exact fractions (64 checks): g^rr = n·n/(T R) vanishes for two unrelated reasons, a null surface or an infinitely long radial unit.', go: 'equations/nullsurf', tag: 'checked' },
      { text: 'Schwarzschild against the Ellis wormhole: the throat has g^rr = 0 but n·n = −1, a timelike surface; and g_tt = 0 is the criterion for a static ξ with regular level set and finite F = ∇ξ·∇ξ, failing in four named ways.', go: 'equations/nullsurf', tag: 'checked' },
      { text: 'We must say plainly that we read only the abstract of your paper, and took the rest from the paper by Hsu, Barker, Hobson and Lasenby that discusses it; a reading we call ours may already be in your work.', go: 'equations/nullsurf', tag: 'open' },
    ],
    note: {
      lead: 'The atlas has one page on null surfaces (step 14), built on the paper by Hsu, Barker, Hobson and Lasenby, which describes how you closed a loophole in Vishveshwara’s argument for g_tt = 0.',
      path: [
        { go: 'equations/nullsurf', title: 'Step 14, null surfaces', what: 'Four claims rebuilt on the bit rule in exact fractions, 64 computed checks, drawn live: the photon that stands still, horizon or throat, when g_tt = 0 is the criterion and four ways it fails, and the algebra Cl(0,n−2,1) of a null hypersurface.', tags: ['standard', 'checked'] },
        { go: 'equations/nullsurf', title: 'Horizon or throat', what: 'Schwarzschild against the Ellis wormhole: both have g^rr = 0 at the surface of interest, but only one is null.', tags: ['standard', 'checked'] },
        { go: 'equations/nullsurf', title: 'When g_tt = 0 is the criterion', what: 'For a static ξ whose level set is regular and whose F = ∇ξ·∇ξ is finite. It fails when F is infinite (Eq. (18) of the Hsu et al. paper), at the extremal horizon, for a ξ that is not hypersurface-orthogonal (rotating flat space, the Kerr ergosurface) and for a spacelike ξ.', tags: ['standard', 'checked'] },
      ],
      standard: 'Standard: the geodesic generators of null hypersurfaces, the Kerr data. Checked by us: the examples above. Ours: a reading of the induced-metric approach as a difference of presentation. Open: Eq. (12) of the Hsu et al. paper is not rebuilt.',
      check: ['Whether the g^rr = 0 argument as we state it is the one you made, or only a neighbour of it.'],
      unread: 'Your papers beyond the abstract of one.',
    },
  },
  {
    id: 'gunn', slug: 'gunn', priority: 'send',
    people: [{ name: 'Charles Gunn', role: 'to', affil: 'Raum+Gegenraum, Falkensee (Germany)' }],
    salutation: 'Dear Dr Gunn,',
    work: 'your projective geometric algebra (the SIGGRAPH 2019 course notes) and the three Cayley–Klein cases',
    subject: 'The Euclid / elliptic / hyperbolic ladder of PGA rebuilt on a bit rule: feedback welcome',
    hooks: [
      { text: 'One extra generator of square s ∈ {0, −1, +1} gives your three cases, with [B_an, B_bn] = −2s B_ab, Jacobi, and a Killing form that is degenerate exactly on the n translations at s = 0; on a Lorentz base they become Poincaré, de Sitter and anti-de Sitter. All checked exactly for n = 2…6.', go: 'equations/projective', tag: 'checked' },
      { text: 'With R(n,0,1) on the bit rule, a motor is an even blade, a vertex of the n-cube; a corner of the cube is the product of the coordinate mirrors on its axes, and every isometry of Rⁿ is at most n + 1 plane mirrors (checked for n = 2, 3).', go: 'equations/mirrors', tag: 'checked' },
      { text: 'The Forque paper credits you with the statement that the equations of motion coincide in the three PGAs. We did not re-derive it and say so on the page; we have the degenerate case only.', go: 'equations/forque', tag: 'open' },
    ],
    note: {
      lead: 'The atlas meets your PGA through the Cayley–Klein ladder (step 9) and through rigid-body dynamics (steps 10 and 13), where we followed Dorst and De Keninck.',
      path: [
        { go: 'equations/projective', title: 'Step 9, one more generator', what: 'Space base: Euclid, elliptic (s = −1), hyperbolic (s = +1); Lorentz base: Poincaré, de Sitter, anti-de Sitter. Contraction to s = 0 checked. PGA embeds in CGA as an injective homomorphism for n = 2, 3. A null pair e_p (−1), e_m (+1) gives the conformal points, with translation as two parallel planes, rotation as two planes through a point, dilation as two concentric spheres.', tags: ['standard', 'checked'] },
        { go: 'equations/mirrors', title: 'Step 8, mirrors', what: 'Cube corners as products of coordinate mirrors; Cartan–Dieudonné; |B_n| and |D_n| by closure for n ≤ 5.', tags: ['standard', 'checked'] },
        { go: 'equations/rigid', title: 'Step 13, rigid bodies', what: 'A segment, a square, a cube with its own labels, a body on a spring, the frame table for n = 1…6, a free top, orbits.', tags: ['standard', 'checked'] },
      ],
      standard: 'Standard: the three geometries and PGA itself. Checked by us: the ladder and the contraction. Ours: the extra-bit reading (the extra generator as one more bit). Open: any physical role of the extra generator; conformal dynamics.',
      check: ['Whether the extra-bit reading matches how you think of the degenerate generator, or hides something your treatment makes explicit.'],
      unread: 'Your later work beyond the 2019 notes.',
    },
  },
  {
    id: 'hestenes', slug: 'hestenes', priority: 'send',
    people: [{ name: 'David Hestenes', role: 'to', affil: 'Arizona State University (emeritus)' }],
    salutation: 'Dear Professor Hestenes,',
    work: 'your space-time algebra, which the atlas uses for Maxwell, Dirac and pointors',
    subject: 'Your space-time algebra rebuilt on a bit rule: Maxwell, Dirac and pointors, feedback welcome',
    hooks: [
      { text: 'Maxwell’s ∇F = J in n = k + d generators: all splits with k, d ≤ 4 and k + d ≤ 7, in exact arithmetic. Grade 1 gives the n source equations, grade 3 gives Faraday and no-monopole, and for each cell exactly two sign conventions reproduce them.', go: 'maxwell/views', tag: 'checked' },
      { text: 'Your Dirac equation ∇ψJ = mψγ₀, J = γ₂γ₁, with ψ even in Cl(1,3): its 8 real components are the 8 corners of the 4-demicube; the determinant is (p² − m²)⁴, exact.', go: 'equations/dirac', tag: 'checked' },
      { text: 'Among your even spinors in Cl(1,3), the pointors of Roelfs, Eelbode and De Keninck are the slice b = 0 of the Yvon–Takabayasi angle (β = 0 or π), where every free plane wave of the Dirac step sits; the chirality ψ ↦ IψJ is XOR 9 on the labels of the bit rule.', go: 'equations/spin', tag: 'ours' },
    ],
    note: {
      lead: 'The atlas uses your space-time algebra as the standard form for electromagnetism and for the Dirac equation, and checks it against a different bookkeeping, the bit rule, where the algebra is a table of signs on binary labels.',
      path: [
        { go: 'maxwell/views', title: 'Test 1, Maxwell', what: '∇F = J with F a bivector in n = k + d generators; grade 1 and grade 3 equations; ∇∇F = □F and charge conservation hold; the Lorentz force is the grade-1 part of F u, the contraction F·u = ½(Fu − uF).', tags: ['standard', 'checked'] },
        { go: 'maxwell/charges', title: 'Charges in the fields', what: 'Circle, hyperbola, E × B drift, a plane wave and the relativistic Kepler perihelion advance (61.35° at κ = 0.3, v₀ = 0.5) agree with closed forms. Nothing predicts anything.', tags: ['standard', 'checked'] },
        { go: 'equations/dirac', title: 'Step 2, the Dirac equation', what: 'ψ even in Cl(1,3); 8 components, 8 equations, 40 incidences; covariance under the 6 bivectors exact; numpy with 4×4 gamma matrices agrees, and two wrong versions fail.', tags: ['standard', 'checked'] },
        { go: 'equations/spin', title: 'Step 11, pointors', what: 'Among the even spinors of Cl(1,3), the pointors are the slice b = 0 of the Yvon–Takabayasi angle (β = 0 or π). Every free plane wave of the Dirac step lies in it, β = 0 for positive and β = π for negative energy (exact kernel computation at 8 on-shell momenta). The chirality ψ ↦ IψJ is XOR 9 on the even labels.', tags: ['standard', 'checked', 'ours'] },
      ],
      standard: 'Standard: space-time algebra electromagnetism and your form of the Dirac equation. Checked by us: the counts and identities above, and the free plane waves in the b = 0 slice. Ours: the demicube reading of the 8 components, the pointor slice and the XOR reading of chirality. Open: any physical role; no spin sums or gauge field are shown, and the only solutions are free plane waves.',
      check: ['Whether the pointor statement (b = 0 slice of the Yvon–Takabayasi angle) is the way you would put it, or loses something.'],
      unread: 'Most of your own writing: we know the space-time algebra mostly from standard sources.',
    },
  },
  {
    id: 'ablamowicz', slug: 'ablamowicz', priority: 'send',   // read for steps 15–17; the atlas lists it among its sources on the For researchers page, and the note says so
    people: [{ name: 'Rafał Ablamowicz', role: 'to', affil: 'Tennessee Technological University' }],
    salutation: 'Dear Professor Ablamowicz,',
    work: 'your paper “On Clifford algebras and related finite groups and group algebras” (arXiv:1610.03583)',
    subject: 'A bit rule for Clifford algebras and the finite groups it counts: is this known to you? Feedback welcome',
    hooks: [
      { text: 'We write Cl(p,q) as e_a e_b = s(a,b) e_(a xor b) on binary labels (a twisted group algebra of Z₂ⁿ), read its type from the clock c = p − q mod 8 as the phase of a Gauss sum, and embed every Cl(p,q) graded in Cl(n+2,0). We suspect all of this is known to you; where is it written down?', go: 'labels/clock', tag: 'checked' },
      { text: 'Over F₂ each cell leaves a quadratic form Q (Q(a) = 1 when e_a squares to −1) and an orthogonal group O(Q): W(Eₙ) mod 2 equals O(Q) of Cl(n,0) for n = 3…8, while Sₙ₊₁ fills O(Q) of Cl(0,n) only for n ≤ 5.', go: 'labels/groups', tag: 'checked' },
      { text: 'The Golay code [24,12,8] and the Steiner system S(5,8,24) come out live from a cyclic generator (any five points lie in exactly one octad), with M₂₄ of order 244,823,040 and the Pin lifts 2.A₄ and 2.A₅.', go: 'labels/groups', tag: 'checked' },
    ],
    note: {
      lead: 'Your paper is the closest published relative we know of to the step 17 of the atlas (finite groups over F₂). We found it late; the atlas lists it among its sources (the page For researchers) but has not compared it line by line; this note says where the two meet.',
      path: [
        { go: 'labels/clock', title: 'Step 15, the clock', what: 'The class c = p − q mod 8 is the phase of the Gauss sum Σ_a i^(pos − neg) over the 2ⁿ blade addresses, which equals (1 + i)^p (1 − i)^q; every Cl(p,q) embeds Z₂-graded in Cl(n+2,0) (a negative generator goes to e_j P with P = e_(n+1) e_(n+2), P² = −1).', tags: ['standard', 'checked'] },
        { go: 'labels/groups', title: 'Step 17, the finite lens', what: 'The quadratic form Q on F₂ⁿ, its group O(Q) counted exactly per class; W(Eₙ) mod 2 = O(Q) of Cl(n,0) for n = 3…8; Sₙ₊₁ in O(Q) of Cl(0,n), filling it only up to n = 5 (index 8, 64, 960 at n = 6, 7, 8); Pin lifts 2.A₄ and 2.A₅; the primes enter |GL(n,2)| at n = ord_p(2).', tags: ['standard', 'checked'] },
        { go: 'labels/groups', title: 'Golay code and Steiner system', what: 'The binary Golay code [24,12,8] from a cyclic generator, 759 octads, any five points in exactly one octad (all 42,504 five-sets checked), M₂₄ of order 244,823,040, 196,560 Leech vectors.', tags: ['standard', 'checked'] },
      ],
      standard: 'Standard: the classification statements, the orders of the sporadic groups, the periodicity of eight. Checked by us: the counts above. Ours: Sₙ₊₁ permuting the positive generators, translation as 2ⁿ⁻¹, the link to the Klein group at n = 4. Open: groups of Lie type over more than two elements, most sporadic groups, Cartan–Dieudonné in characteristic 2.',
      check: [
        'Is the bit rule, written as a twisted group algebra and tied to Walsh functions and the Gray code, in your work or in Chernov’s and Albuquerque–Majid’s? Then the atlas should cite it and we should say so.',
        'Do the Salingaros vee groups explain the pattern of which Sₙ₊₁ and W(Eₙ) fill O(Q)?',
      ],
      unread: 'Chernov, Albuquerque and Majid, and Salingaros directly; we know them only through your paper.',
    },
  },
  // ---- on hold: named in the atlas (Map page) as pointers for dynamics; their work has not been read, so the e-mail asks and claims nothing.
  {
    id: 'jlasenby', slug: 'jlasenby', priority: 'hold',
    people: [{ name: 'Joan Lasenby', role: 'to', affil: 'Department of Engineering, University of Cambridge' }],
    salutation: 'Dear Joan Lasenby,',
    work: 'your work on geometric algebra for motion estimation and signal processing',
    subject: 'Which of your geometric-algebra papers should we read first? (a small open atlas names your work)',
    hooks: [
      { text: 'Our atlas runs rigid-body dynamics with PGA motors on a bit rule, from a segment to a tesseract; RK4 keeps points as points while one Euler step leaves the motor group.', go: 'equations/rigid', tag: 'checked' },
      { text: 'We name your motion-estimation work on our Map page as a pointer for what to borrow next, but we have not read it yet.', go: 'map', tag: 'open' },
    ],
    note: null,
  },
  {
    id: 'mann', slug: 'mann', priority: 'hold',
    people: [{ name: 'Stephen Mann', role: 'to', affil: 'University of Waterloo' }],
    salutation: 'Dear Dr Mann,',
    work: 'your work on conformal geometric algebra in practice',
    subject: 'Conformal geometric algebra on a bit rule: where should we read first? (a small open atlas names your work)',
    hooks: [
      { text: 'In our atlas a null pair e_p (−1), e_m (+1) gives conformal points P(x) = o + x − ½x²ε; translation, rotation, dilation and inversion are one or two spheres or planes, and PGA embeds in CGA for n = 2, 3.', go: 'equations/projective', tag: 'checked' },
      { text: 'We name your practical conformal geometric algebra on our Map page as a pointer for what to borrow, but we have not read it yet.', go: 'map', tag: 'open' },
    ],
    note: null,
  },
  {
    id: 'dechant', slug: 'dechant', priority: 'hold',
    people: [{ name: 'Pierre-Philippe Dechant', role: 'to', affil: 'Clifford algebra, E8 and H4' }],
    salutation: 'Dear Dr Dechant,',
    work: 'your work on Clifford algebras, Coxeter groups, E8 and H4',
    subject: 'E8 from a bit rule: where should we read first? (a small open atlas names your work)',
    hooks: [
      { text: 'In our atlas the 240 roots of E8 are 112 edges of the 8-orthoplex plus 128 corners of the 8-demicube, all permuted by their mirrors; E7 = 60 + 2 + 64, E6 = 40 + 32.', go: 'shapes/gosset', tag: 'checked' },
      { text: 'We name your work on the subject on the Map page as something to read, and have not read it yet; we would like to know whether our decomposition is known to you.', go: 'map', tag: 'open' },
    ],
    note: null,
  },
  {
    id: 'todd', slug: 'todd', priority: 'hold',
    people: [{ name: 'Hamish Todd', role: 'to', affil: 'visual rotors and geometric algebra' }],
    salutation: 'Dear Hamish Todd,',
    work: 'your visual work on rotors and geometric algebra',
    subject: 'Live pictures of Clifford algebras: a small open atlas names your work',
    hooks: [
      { text: 'Our atlas draws each algebra four ways (Clifford, simplex, cube, prime) and runs live widgets for spinors, rigid bodies and horizons.', go: 'rule', tag: 'checked' },
      { text: 'We name your visual rotors on the Map page as a pointer, and have not read them yet; we would like to know what we should look at first.', go: 'map', tag: 'open' },
    ],
    note: null,
  },
  {
    id: 'holmer', slug: 'holmer', priority: 'hold',
    people: [{ name: 'Freya Holmer', role: 'to', affil: 'visual explanations of rotors' }],
    salutation: 'Dear Freya Holmer,',
    work: 'your visual explanations of rotations and geometric algebra',
    subject: 'Live pictures of Clifford algebras: a small open atlas names your work',
    hooks: [
      { text: 'Our atlas has a Young Learner mode that tells the same results in plain words with live pictures (the clock, falling space, counting the ways to shuffle).', go: 'labels/clock', tag: 'checked' },
      { text: 'We name your explanations on the Map page as a pointer, and have not looked at them closely yet; any pointers on how to explain a rotor well would help.', go: 'map', tag: 'open' },
    ],
    note: null,
  },
];

// short names that open the same note as their group (an individual link such as ?for=eelbode)
export const ALIASES = { dekeninck: 'dorst', deckeninck: 'dorst', eelbode: 'roelfs', hsu: 'lasenby', barker: 'lasenby', hobson: 'lasenby', doran: 'lasenby', gull: 'lasenby' };

// Named in the atlas but not reachable by e-mail: no address is looked for.
export const HISTORICAL = [
  'William Rowan Hamilton', 'William Kingdon Clifford', 'Élie Cartan', 'H. S. M. Coxeter', 'Thorold Gosset', 'Raoul Bott', 'J. H. M. Wedderburn', 'Arthur Cayley', 'L. E. Dickson',
  'Paul Dirac', 'Wolfgang Pauli', 'Hermann Weyl', 'Chen Ning Yang', 'Robert Mills', 'James Clerk Maxwell', 'Hermann Minkowski', 'Karl Schwarzschild', 'Paul Painlevé', 'Allvar Gullstrand',
  'Marcel Golay', 'John Leech', 'C. V. Vishveshwara',
];

export const slugOf = s => { const k = String(s || '').toLowerCase().replace(/[^a-z]/g, ''); return ALIASES[k] || (RESEARCHERS.some(r => r.slug === k && r.note) ? k : null); };
export const noteOf = slug => RESEARCHERS.find(r => r.slug === slug && r.note) || null;
