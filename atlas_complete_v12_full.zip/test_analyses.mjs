// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The analyses (reports/analyses/: index.json -> make_analyses.mjs -> the pages; index.json -> make_analyses_data.mjs -> analysesData.js -> the Analyses block), in node:
// (1) the registry: every entry well formed, every file it names in the folder, and the folder holds nothing else (its four tool files apart); every source has the sha256 the
//     registry records (a source is shipped as it is); analysesData.js is what make_analyses_data.mjs gives and says what the registry says;
// (2) the pages are what the generator gives: written again into a temporary folder, each is byte for byte the shipped one (a skip, exit 77, when markdown-it is not installed);
// (3) each page is self-contained (no script, no style sheet or font to fetch, no request of any kind; a link is an anchor of the page or a download of its own source or code);
//     it shows its source's headings in order, its tables, its formulas as MathML (as many as pandoc finds in the three texts that pandoc rendered), at most the recorded number
//     of formulas as text, light and dark, a print style sheet, its download links and its date;
// (4) the check ids: exactly the ids the texts quote, in the form of the package, that are checks of selfcheck/bridges/ or rows of core_check.py (no info line);
// (5) the words of the block: English and the same in both slots, no status word as a chip, no word of how the package was built; the line of each id list (checkText);
// (6) no address of any person, no mail link and no path of a working machine in any file of the folder or in any member of a code zip; the folder stays under 4 MB;
// (7) the README says how to add an analysis; build.sh copies the pages and their downloads next to the app.   Run: node test_analyses.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import crypto from 'node:crypto'; import zlib from 'node:zlib'; import { spawnSync } from 'node:child_process';
import { PKG, DIST } from './paths.mjs'; process.chdir(PKG);
import { ANALYSES, ANALYSES_META } from './analysesData.js';
import { RS } from './researchersCopy.js';
import { checkText } from './researchersModel.js';
import { readRegistry, validate, quotedChecks, sortIds, loadPackages, sha256, ID_MAP } from './reports/analyses/make_analyses.mjs';
let bad = 0, n = 0, skipped = ''; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const DIR = 'reports/analyses', R = readRegistry(), A = R.analyses, rd = f => fs.readFileSync(f, 'utf8');
const TOOLS = ['README.md', 'analysis_style.css', 'index.json', 'make_analyses.mjs'];
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]);
const inDir = walk(DIR).map(f => path.relative(DIR, f).split(path.sep).join('/')).sort();
const named = a => [a.html, ...a.source.map(s => s.file), ...(a.code ? [a.code] : [])];

// ---- (1) the registry and the data module
{ const errs = validate(R, DIR); ok(errs.length === 0, 'index.json is well formed, and every source has the sha256 it records: ' + errs.join(' | ')); }
ok(A.length >= 11 && new Set(A.map(a => a.id)).size === A.length && R.generator.script === 'make_analyses.mjs' && Object.keys(R.generator.packages).sort().join() === 'katex,markdown-it', `${A.length} analyses with unique ids; the registry names the generator and its two packages`);
ok(A.every(a => a.source.every(s => sha256(fs.readFileSync(path.join(DIR, s.file))) === s.sha256)), 'every markdown source is byte for byte the text the registry records (sha256)');
{ const want = [...TOOLS, ...A.flatMap(named)].sort(), have = inDir; ok(JSON.stringify([...new Set(want)].sort()) === JSON.stringify(have), 'reports/analyses/ holds exactly the pages, sources and zips of index.json and its four tool files: ' + [...have.filter(f => !want.includes(f)).map(f => '+' + f), ...want.filter(f => !have.includes(f)).map(f => '-' + f)].join(', ')); }
// the analyses of the merged tree: the readings of three physicists and four mathematicians, the two joint reports, the analysis of the two, the seven discovery runs
{ const ids = A.map(a => a.id).join(), disc = A.find(a => a.id === 'discovery-runs');
  ok(ids === 'readings,physics,mathematics,string-theory,solid-state,theoretical-physics,whole-mathematics,geometry,algebra,category-theory,discovery-runs', 'the eleven analyses, in the order of the block: ' + ids);
  ok(disc && disc.source.map(s => s.anchor).join() === 'hh,fk,rev,tor,en,fur,kep' && disc.code === 'src/discovery_runs_code.zip' && A.filter(a => a.source.length === 1).length === A.length - 1, 'the discovery runs are one page of seven sources (HH, FK, REV, TOR, EN, FUR, KEP) with the zip of their scripts and logs; every other analysis is one source');
  const zipNames = disc ? readZip(path.join(DIR, disc.code)).map(m => m.name).sort() : [];
  ok(JSON.stringify(zipNames) === JSON.stringify(['HH', 'FK', 'REV', 'TOR', 'EN', 'FUR', 'KEP'].flatMap(r => [`${r}/disc_${r}.log`, `${r}/disc_${r}.py`, `${r}/disc_${r}_sabotage.log`]).sort()), 'the code zip of the discovery runs holds each run\'s script, its log and its sabotage log: ' + zipNames.join(' ')); }
// the code of the ten readings is one zip, shared: the scripts of selfcheck/bridges/ with their README and logs, member for member and byte for byte (make_package.py writes it)
{ const rd10 = A.filter(a => a.id !== 'discovery-runs'), ZB = 'src/bridges_code.zip', br = fs.readdirSync('selfcheck/bridges').filter(f => fs.statSync(path.join('selfcheck/bridges', f)).isFile()).sort();
  ok(rd10.length === 10 && rd10.every(a => a.code === ZB), 'the ten readings (and joint reports) share one code zip, src/bridges_code.zip');
  const ms = fs.existsSync(path.join(DIR, ZB)) ? readZip(path.join(DIR, ZB)) : [];
  ok(JSON.stringify(ms.map(m => m.name).sort()) === JSON.stringify(br.map(f => 'bridges/' + f).sort()), 'src/bridges_code.zip holds exactly the files of selfcheck/bridges/, under bridges/: ' + ms.length + ' members, ' + br.length + ' files');
  ok(ms.length > 0 && ms.every(m => m.data.equals(fs.readFileSync(path.join('selfcheck/bridges', m.name.slice('bridges/'.length))))), 'every member of src/bridges_code.zip is byte for byte the file of selfcheck/bridges/ (python3 reports/make_package.py writes it again after a regeneration of the checks)');
  ok(ms.some(m => m.name === 'bridges/README.md') && ms.some(m => m.name === 'bridges/bridges_phys.json') && ms.some(m => m.name === 'bridges/bridges_math.json') && ms.filter(m => m.name.endsWith('.py')).length >= 50, 'the zip holds the README, the two logs and the scripts of the checks the texts quote'); }
{ const g = spawnSync(process.execPath, ['make_analyses_data.mjs', '--check'], { encoding: 'utf8' });
  ok(g.status === 0, 'analysesData.js is what make_analyses_data.mjs builds from reports/analyses/index.json: ' + (g.stdout + g.stderr).trim());
  ok(/^\/\/ GENERATED by make_analyses_data\.mjs from reports\/analyses\/index\.json/m.test(rd('analysesData.js')), 'analysesData.js says it is generated, and from what');
  const rel = f => DIR + '/' + f;
  ok(ANALYSES.length === A.length && ANALYSES_META.count === A.length && ANALYSES.every((x, i) => { const a = A[i]; return x.id === a.id && x.title === a.title && x.line === a.line && x.kind === a.kind && x.html === rel(a.html) && JSON.stringify(x.sources) === JSON.stringify(a.source.map(s => rel(s.file))) && x.code === (a.code ? rel(a.code) : null) && JSON.stringify(x.checks) === JSON.stringify(a.checks); }),
    'analysesData.js gives, per analysis, the id, title, line, kind, paths (relative to the package) and check ids of the registry, in its order');
  ok(ANALYSES.every(x => !('date' in x) && fs.existsSync(x.html) && x.sources.every(f => fs.existsSync(f)) && (!x.code || fs.existsSync(x.code))), 'every path of analysesData.js is a file of the package (the date stays on the page)'); }

// ---- (2) the pages are what the generator gives, byte for byte
const pk = loadPackages();
if (pk.missing) { skipped = `the generator needs the node package ${pk.missing} (npm install --no-save markdown-it@${R.generator.packages['markdown-it']}, or NODE_PATH): the pages were not written again`; console.log('NOTE ' + skipped); }
else {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-analyses-'));
  try {
    const r = spawnSync(process.execPath, [path.join(DIR, 'make_analyses.mjs'), '--out', tmp], { encoding: 'utf8', env: process.env });
    const versions = `markdown-it ${pk.versions['markdown-it']}, katex ${pk.versions.katex}; recorded ${JSON.stringify(R.generator.packages)}`;
    ok(r.status === 0, 'make_analyses.mjs --out <temporary folder> runs and writes every page: ' + (r.stdout + r.stderr).trim().split('\n').slice(-3).join(' | '));
    const diff = A.filter(a => !fs.existsSync(path.join(tmp, a.html)) || !fs.readFileSync(path.join(tmp, a.html)).equals(fs.readFileSync(path.join(DIR, a.html))));
    ok(diff.length === 0, `every page, written again into a temporary folder, is byte for byte the shipped one (${versions}): ` + diff.map(a => a.html).join(', '));
    ok(fs.readdirSync(tmp).sort().join() === A.map(a => a.html).sort().join(), 'the generator writes exactly the pages of the registry');
    const c = spawnSync(process.execPath, [path.join(DIR, 'make_analyses.mjs'), '--check'], { encoding: 'utf8', env: process.env });
    ok(c.status === 0 && (c.stdout.match(/^current /gm) || []).length === A.length, 'make_analyses.mjs --check finds every page current: ' + (c.stdout + c.stderr).trim().split('\n').filter(l => !/^current /.test(l)).slice(0, 3).join(' | '));
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
  // the generator stops on a source that is not the recorded text (in a temporary copy of the folder)
  const cp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-analyses-src-'));
  try {
    for (const f of inDir) { fs.mkdirSync(path.dirname(path.join(cp, f)), { recursive: true }); fs.copyFileSync(path.join(DIR, f), path.join(cp, f)); }
    const s0 = A[0].source[0].file; fs.appendFileSync(path.join(cp, s0), '\nOne more line.\n');
    const r = spawnSync(process.execPath, [path.join(cp, 'make_analyses.mjs'), '--check'], { encoding: 'utf8', env: process.env });
    ok(r.status === 1 && new RegExp(s0.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + ' has sha256').test(r.stderr), 'a changed source stops the generator, which names the file and the recorded sha256: ' + (r.stderr || '').trim().split('\n')[0]);
  } finally { fs.rmSync(cp, { recursive: true, force: true }); }
}

// ---- (3) each page: self-contained, its text in order, its formulas as MathML
const PANDOC = { readings: 126, physics: 477, mathematics: 803 };   // the inline formulas pandoc finds in the three texts it rendered (no display formula)
const strip = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&');
const alnum = s => s.normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu, '').toLowerCase();
for (const a of A) {
  const f = path.join(DIR, a.html), h = fs.existsSync(f) ? rd(f) : '', tag = a.html + ':';
  const body = h.replace(/<style>[\s\S]*?<\/style>/, '');
  ok(/^<!doctype html>\n<html lang="en">/.test(h) && h.endsWith('</html>\n') && /<meta charset="utf-8">/.test(h) && h.includes(`<title>${a.title.replace(/&/g, '&amp;')}</title>`), `${tag} a whole HTML document in English, titled “${a.title}”`);
  ok(!/<script|<link|<img|<iframe|<object|<embed|<video|<audio|<source|@import|url\(|@font-face|\ssrc=/i.test(h), `${tag} no script, no linked style sheet, font, image or frame, no @import and no url(): nothing to fetch`);
  const hrefs = [...body.matchAll(/\shref="([^"]*)"/g)].map(m => strip(m[1])), own = new Set([...a.source.map(s => s.file), ...(a.code ? [a.code] : [])]);
  const ids = new Set([...body.matchAll(/\sid="([^"]*)"/g)].map(m => m[1]));
  const stray = hrefs.filter(x => !(x.startsWith('#') && ids.has(x.slice(1))) && !own.has(x) && !/^https:\/\/(arxiv\.org|doi\.org)\//.test(x));
  ok(stray.length === 0 && !/https?:\/\//.test(h.replace(/<a href="https:\/\/(arxiv\.org|doi\.org)\/[^"]*"/g, '')), `${tag} every link is an anchor of the page or a download of its own source or code (a link to a paper on arxiv.org or doi.org is the one kind of address allowed): ` + stray.slice(0, 4).join(' '));
  ok(a.source.every(s => body.includes(`<a href="${s.file}" download="${path.basename(s.file)}">`)) && (!a.code || body.includes(`<a href="${a.code}" download="${path.basename(a.code)}">`)) && body.includes(`<time datetime="${a.date}">`), `${tag} the header downloads the markdown source${a.code ? ' and the code' : ''} and gives the date`);
  ok(/@media \(prefers-color-scheme: dark\)/.test(h) && /@media print\{/.test(h) && /<meta name="color-scheme" content="light dark">/.test(h), `${tag} light and dark follow the system; a print style sheet`);
  ok(h.includes(`<meta name="generator" content="make_analyses.mjs (markdown-it ${R.generator.packages['markdown-it']}, katex ${R.generator.packages.katex})">`), `${tag} the page names its generator and the versions of the registry`);
  // the source's own text in order: its headings (formulas and markup left out) are the page's headings, in the same order, each with an anchor; its tables are tables
  const srcText = a.source.map(s => rd(path.join(DIR, s.file)));
  const mdHeads = srcText.flatMap(t => t.split('\n').filter(l => /^#{1,6} /.test(l)).map(l => alnum(l.replace(/^#+ /, '').replace(/\$[^$]*\$/g, ''))));
  const htmlHeads = [...body.replace(/<header[\s\S]*?<\/header>/, '').matchAll(/<h([1-6]) id="[^"]+">([\s\S]*?)<\/h\1>/g)].map(m => alnum(strip(m[2].replace(/<math[\s\S]*?<\/math>/g, '').replace(/<[^>]+>/g, ''))));
  ok(mdHeads.length > 3 && JSON.stringify(mdHeads) === JSON.stringify(htmlHeads), `${tag} the ${mdHeads.length} headings of the source are the page's headings, in order, each with an anchor`);
  const mdTables = srcText.reduce((s, t) => s + (t.match(/^\s*\|?\s*:?-{3,}:?\s*\|/gm) || []).length, 0), htmlTables = (body.match(/<div class="tw"><table>/g) || []).length;
  ok(mdTables === htmlTables, `${tag} the ${mdTables} tables of the source are tables of the page, each in a frame that scrolls sideways (${htmlTables})`);
  const maths = (body.match(/<math[ >]/g) || []).length, texts = (body.match(/<code class="tex">/g) || []).length;
  ok(texts <= a.fallbacks, `${tag} ${texts} formula(s) shown as TeX text, at most the ${a.fallbacks} the registry records`);
  ok(!/<semantics>|<annotation|mathvariant="(double-struck|fraktur|script|bold)"|xmlns=/.test(body) && (maths > 0 || !srcText.join('').includes('$')), `${tag} ${maths} formulas as bare MathML (no katex wrapper, namespace or annotation; ℤ, 𝔽, 𝔰 as their own characters)`);
  if (PANDOC[a.id]) ok(maths + texts === PANDOC[a.id], `${tag} ${maths} formulas, as many as pandoc finds in the same text (${PANDOC[a.id]})`);
  const visible = strip(body.replace(/<code[\s\S]*?<\/code>/g, '').replace(/<math[\s\S]*?<\/math>/g, '').replace(/<[^>]+>/g, ''));
  ok(!visible.includes('$'), `${tag} no unpaired $ in the text of the page (every formula of the source is typeset)`);
}

// ---- (4) the check ids
const BR = ['bridges_phys.json', 'bridges_math.json'].map(f => JSON.parse(rd(path.join('selfcheck/bridges', f))));
const CHECK = new Set([...BR[0].rows.filter(r => r.kind !== 'info').map(r => r.id), ...BR[1].rows.map(r => r.id)]);
const INFO = new Set([...BR[0].rows.filter(r => r.kind === 'info').map(r => r.id), ...BR[1].summary.info.map(r => r.id)]);
const CORE = new Set([...rd('selfcheck/core_check.py').matchAll(/core·B(\d+)/g)].map(m => 'core·B' + m[1]));
const expected = a => { const out = new Set(); for (const id of quotedChecks(a.source.map(s => rd(path.join(DIR, s.file))).join('\n'))) {
  if (CHECK.has(id) || CORE.has(id)) out.add(id); else if (!INFO.has(id)) for (const c of CHECK) if (new RegExp('^' + id + '[a-z]$').test(c)) out.add(c); } return sortIds([...out]); };
for (const a of A) { const e = expected(a); ok(JSON.stringify(a.checks) === JSON.stringify(e), `${a.id}: checks are exactly the ${e.length} ids its text quotes that are checks of the package: ` + [...a.checks.filter(x => !e.includes(x)).map(x => '+' + x), ...e.filter(x => !a.checks.includes(x)).map(x => '-' + x)].join(' ')); }
ok(A.every(a => a.checks.every(id => (CHECK.has(id) || CORE.has(id)) && !INFO.has(id))), 'every listed id is a check of selfcheck/bridges/ or a row of core_check.py, never an info line');
ok(quotedChecks('rv·M_geo·1–3, rv·P_ss·1 … rv·P_ss·3, disc·HH2, bd·en·5, core·B1–B2, rv·merge·4 and rv·MG·1') .join() === 'bd·en·5,bd·geo·1,bd·geo·2,bd·geo·3,bd·hh·2,bd·sol·1,bd·sol·2,bd·sol·3,bd·xck·4,bd·xph·1,core·B1,core·B2' && ID_MAP['rv·P_all'] === 'bd·phy' && ID_MAP['rv·merge'] === 'bd·xck', 'the ids of the texts map to those of the package by the fixed rule; a range stands for every number in it');
{ const R2 = A.find(a => a.id === 'readings'); ok(R2 && R2.checks.includes('bd·str·25') && R2.checks.includes('bd·xck·6') && R2.checks.includes('core·B3') && !R2.checks.includes('bd·str·3'), 'the analysis quotes rv·P_str·25 (bd·str·25), rv·merge·6 (bd·xck·6) and core·B3; rv·P_str·3 is an info line of the package and is not listed'); }

// ---- (5) the words of the block
const E = RS.en.analyses, I = RS.it.analyses, KEYS = ['h', 'intro', 'open', 'page', 'source', 'sources', 'code', 'checks', 'none', 'listLbl'];
ok(E && I && KEYS.every(k => typeof E[k] === 'string' && E[k].trim()) && JSON.stringify(E) === JSON.stringify(I) && RS.en.toc.analyses === 'Analyses' && RS.it.toc.analyses === 'Analyses', 'the block\'s words: English, the same in the Italian slot (like the Reports block), with its menu entry');
ok(E.open === 'Open' && E.page === 'Download page' && E.source === 'Download source (md)' && E.code === 'Download code', 'the four actions: Open, Download page, Download source (md), Download code');
const PROCESS = /\b(lanes?|workers?|sessions?|lead|reviewers?|merged?|merging|rounds?|specialists?|agents?)\b/i, STATUS = /\b(standard|checked|ours|open|input)\b/;
ok(A.every(a => !PROCESS.test(a.title + ' ' + a.line + ' ' + a.kind)) && !PROCESS.test(Object.values(E).join(' ')), 'no word of how the package was built in a title, line, kind or word of the block: ' + A.filter(a => PROCESS.test(a.title + ' ' + a.line + ' ' + a.kind)).map(a => a.id).join(' '));
ok(A.every(a => !STATUS.test(a.kind)) && A.every(a => !/\$|\\[a-z]+|[_^]\{/.test(a.title + a.line)), 'a kind is no status word (the block shows no status chip), and titles and lines hold no formula');
ok(checkText(['bd·str·1', 'bd·str·2', 'bd·str·5', 'bd·str·6', 'bd·str·7', 'bd·phy·1', 'bd·phy·2a', 'bd·phy·2b', 'bd·phy·3', 'bd·phy·4', 'bd·phy·5', 'core·B1', 'core·B2', 'core·B3', 'core·B10']) === 'bd·str·1, 2, 5–7 · bd·phy·1, 2a, 2b, 3–5 · core·B1–B3, B10' && checkText([]) === '', 'checkText: families in the order given, three or more consecutive numbers as a range, a split id on its own');
{ const R2 = A.find(a => a.id === 'readings'); ok(R2 && checkText(R2.checks) === 'bd·cat·3 · bd·geo·15 · bd·mat·17–19 · bd·sol·10, 18 · bd·str·5, 25 · bd·xck·6–8 · bd·xph·3, 4 · core·B3, B6', 'the line of the ids of the analysis: ' + (R2 && checkText(R2.checks))); }

// ---- (6) no address, no mail link, no machine path, anywhere in the folder; the size
const MAIL = new RegExp('[A-Za-z0-9._%+-]+' + '@' + '[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}'), LINK = new RegExp('mail' + 'to:', 'i'), MACHINE = new RegExp(['/tm' + 'p/claude', '/ho' + 'me/claude', 'scratch' + 'pad', '/Us' + 'ers/'].join('|'));
function readZip(file) { const b = fs.readFileSync(file), out = []; let e = b.length - 22; while (e >= 0 && b.readUInt32LE(e) !== 0x06054b50) e--; if (e < 0) return out; let p = b.readUInt32LE(e + 16); const k = b.readUInt16LE(e + 10);
  for (let i = 0; i < k; i++) { const meth = b.readUInt16LE(p + 10), csz = b.readUInt32LE(p + 20), nl = b.readUInt16LE(p + 28), xl = b.readUInt16LE(p + 30), cl = b.readUInt16LE(p + 32), lho = b.readUInt32LE(p + 42);
    const name = b.toString('utf8', p + 46, p + 46 + nl), ds = lho + 30 + b.readUInt16LE(lho + 26) + b.readUInt16LE(lho + 28), raw = b.subarray(ds, ds + csz);
    if (!name.endsWith('/')) out.push({ name, data: meth === 8 ? zlib.inflateRawSync(raw) : raw }); p += 46 + nl + xl + cl; } return out; }
const hits = [];
for (const f of inDir) { const full = path.join(DIR, f);
  const texts = f.endsWith('.zip') ? readZip(full).map(m => [f + ':' + m.name, m.data.toString('utf8')]) : [[f, rd(full).replace(/<style>[\s\S]*?<\/style>/, '')]];
  for (const [w, t] of texts) { if (MAIL.test(t)) hits.push(w + ': ' + t.match(MAIL)[0]); if (LINK.test(t)) hits.push(w + ': mail link'); if (MACHINE.test(t)) hits.push(w + ': ' + t.match(MACHINE)[0]); } }
ok(hits.length === 0, 'no e-mail address, no mail link and no path of a working machine in any file of reports/analyses/ or member of its zips: ' + hits.slice(0, 5).join(' | '));
{ const total = inDir.reduce((s, f) => s + fs.statSync(path.join(DIR, f)).size, 0); ok(total < 4e6, `reports/analyses/ stays under 4 MB (${total} bytes)`); }

// ---- (7) the README, the build
{ const t = rd(path.join(DIR, 'README.md'));
  ok(['index.json', 'make_analyses.mjs', 'make_analyses_data.mjs', 'analysesData.js', 'src/', 'sha256', '--check', '--ids', '--sha', 'markdown-it', 'katex', 'NODE_PATH', 'fallbacks', 'make_package.py', 'test_analyses.mjs', 'build.sh', '## Adding an analysis'].every(x => t.includes(x)), 'reports/analyses/README.md says what each file is, what the generator needs, and how to add an analysis');
  const b = rd('build.sh'); ok(/cp reports\/analyses\/\*\.html "\$OUT\/reports\/analyses\/"/.test(b) && /cp reports\/analyses\/src\/\* "\$OUT\/reports\/analyses\/src\/"/.test(b), 'build.sh copies the pages and their downloads to dist/reports/analyses/');
  const dd = path.join(DIST, 'reports', 'analyses');
  if (fs.existsSync(dd)) ok(A.flatMap(named).every(f => fs.existsSync(path.join(dd, f)) && fs.readFileSync(path.join(dd, f)).equals(fs.readFileSync(path.join(DIR, f)))), 'the build holds every page, source and zip of the registry, byte for byte');
  else console.log('NOTE no build in ' + DIST + ': the copy of the build is not compared (sh build.sh)'); }

console.log(bad ? `${bad} FAILURES of ${n}` : `ANALYSES OK (${n} checks): ${A.length} analyses, ${A.reduce((s, a) => s + a.source.length, 0)} sources, ${new Set(A.filter(a => a.code).map(a => a.code)).size} code zip(s)${skipped ? '; SKIPPED: ' + skipped : ''}`);
process.exit(bad ? 1 : skipped ? 77 : 0);
