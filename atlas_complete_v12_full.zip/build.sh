#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Bundle the app for the browser tests: dist/app.js and dist/app.html, the reports of reports/html/ as dist/reports/html/, and the analyses of reports/analyses/ (pages and src/) as
# dist/reports/analyses/. Run from anywhere; every path is inside the package.
#   sh build.sh          react-katex, streamdown and @streamdown/math are replaced by the stand-ins in harness/stubs (what the tests were written against)
#   sh build.sh --real   no stand-ins: your node_modules must hold react-katex, streamdown and @streamdown/math (used by test_real_renderers_ui.mjs)
# Needs the files of your own repository that this package does not ship (see BUILDING.md): SimplexCanvas.jsx, GenesisCanvas.jsx and what they import (canvasFacts.js), and "three" in node_modules.
set -e
cd "$(dirname "$0")"
REAL=0; OUT=dist
for a in "$@"; do case "$a" in --real) REAL=1; OUT=dist_real;; *) echo "build.sh: unknown option $a (use --real)" >&2; exit 2;; esac; done
MISSING=""
for f in SimplexCanvas.jsx GenesisCanvas.jsx canvasFacts.js; do [ -f "$f" ] || MISSING="$MISSING $f"; done
if [ -n "$MISSING" ]; then
  echo "build.sh: these files of your own repository must sit next to App.jsx, and are missing:$MISSING" >&2
  echo "build.sh: this package is an update over your repository (see BUILDING.md); copy it into your repository as BUILDING.md says (extract next to it, merge package.json, then copy), or copy those files in here." >&2
  exit 1
fi
if [ -x node_modules/.bin/esbuild ]; then ESB=node_modules/.bin/esbuild
elif command -v esbuild >/dev/null 2>&1; then ESB=esbuild
elif command -v npx >/dev/null 2>&1 && npx --no-install esbuild --version >/dev/null 2>&1; then ESB="npx --no-install esbuild"
else echo "build.sh: esbuild was not found (npm install, see BUILDING.md)" >&2; exit 1; fi
ALIAS=""
if [ "$REAL" = 0 ]; then ALIAS="--alias:streamdown=./harness/stubs/streamdown.jsx --alias:@streamdown/math=./harness/stubs/smath.js --alias:react-katex=./harness/stubs/katex.jsx"; fi
mkdir -p "$OUT"
$ESB harness/harness_app.jsx --bundle --outfile="$OUT/app.js" --loader:.js=jsx $ALIAS --define:process.env.NODE_ENV='"production"' --log-level=warning
cp harness/app.html "$OUT/app.html"
# the reports the app links to (the Reports index of the For researchers page and the links of the Lenses page) are served next to the app, as $OUT/reports/html/<name>.html
if [ -d reports/html ]; then
  mkdir -p "$OUT/reports/html"
  cp reports/html/*.html "$OUT/reports/html/"
  NREP=$(ls "$OUT/reports/html" | wc -l | tr -d ' ')
else NREP=0; fi
# the analyses of the Analyses block (same page): each page next to the app as $OUT/reports/analyses/<name>.html, its downloads (markdown sources, code zips) in $OUT/reports/analyses/src/
if [ -d reports/analyses ]; then
  rm -rf "$OUT/reports/analyses"; mkdir -p "$OUT/reports/analyses/src"
  cp reports/analyses/*.html "$OUT/reports/analyses/"
  cp reports/analyses/src/* "$OUT/reports/analyses/src/"
  NAN=$(ls "$OUT/reports/analyses" | grep -c '\.html$')
else NAN=0; fi
echo "build.sh: built $OUT/app.js ($(wc -c < "$OUT/app.js") bytes), $OUT/app.html, $NREP report page(s) in $OUT/reports/html and $NAN analysis page(s) in $OUT/reports/analyses"
