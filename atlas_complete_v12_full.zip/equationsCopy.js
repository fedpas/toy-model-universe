// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import E from './equationsData.js';
import S from './shapesData.js';
import KD from './couplingData.js';
import YD from './yangmillsData.js';
import MD from './matterData.js';
import GD from './gravityData.js';
import MRD from './mirrorsData.js';
import PJD from './projectiveData.js';
import FQD from './forqueData.js';
import { numWord, capital, stepNo } from './steps.js';
import SPD from './spinData.js';
import SRD from './springData.js';
import PGD from './pgadynData.js';
import NUD from './nullData.js';
import { TREE, flat } from './mapData.js';
// The status tags of a tally row are the tags of its node on the Map (mapData.js TREE), which is also the glance strip of the step:
// one source, so the tally, its sums and the glance cannot disagree (test_equations.mjs, test_yl_ui.mjs). Both Gravity steps share the node 'grav'.
// The gauge-gravity step has its own node (mapData.js reads its tags from its glance strip, labelsCopy.js tabs.gauge.glance, and from its needs strip), so its row and its glance agree by construction.
export const TT = id => flat(TREE).find(x => x.id === (/^grav[12]$/.test(id) ? 'grav' : id)).tags;
export const TTG = TT('gauge');
const NUK = NUD.portal.kappa.map(x => x.kappa.replace('-', '−')).join(', '), NUJ = NUD.portal.ladder.map(x => x.J).join(', '), NUS = NUD.portal.summary;

// Copy for the "More equations" page (English and Italian). Kept apart from the component so the tests can read it.
const K4 = KD.coupling.ladder[4], YM4 = YD.ym.ladder[3], MT3 = MD.mt.ladder[3], GV4 = GD.gv.ladder[4], GVC4 = GV4.pair_classes.diagonal + GV4.pair_classes.share_one_index + GV4.pair_classes.disjoint, MR4 = MRD.mr.ladder[4], PJ4 = PJD.pj.counts[4];
const FQC = FQD.fq.counts, SPC = SPD.spm.counts;
const C = E.eq.commutators, D = E.eq.dirac, M = E.matrix, MX4 = S.demicube.maxwell[4];
const err = M.worst_error === 0 ? '0' : M.worst_error.toExponential(0);
const ctrl = Object.values(M.negative_controls_fail_with_error).map(x => x.toFixed(1));
// The status cell of a tally row says what each of its tags covers on that step: one short phrase per tag, taken from the step's own lines (English in both languages).
// The tags are those of the Map node (TT, below), in the same order; test_equations.mjs compares the two.
const STATUS = {
  maxwell: [['checked', 'incidence counts and exact fields for every split of time and space'], ['standard', 'Maxwell’s ∇F = J in Hestenes’ space-time algebra'], ['ours', 'reading the algebra as faces of a simplex, bit moves on a cube and XOR on labels'], ['open', 'any link to Furey’s model'], ['input', 'the action, the constitutive relation, units, chart and frame, the grade of F, a time direction γ₀']],
  comm: [['checked', 'which bivectors commute, and the commutator itself, for every signature up to n = 8'], ['standard', 'the structure constants of so(p,q)'], ['open', 'a Yang–Mills equation with a gauge field, and any dynamics of the commutator terms']],
  dirac: [['checked', `the ${D.counts.incidences} incidences, the determinant (p² − m²)⁴ and covariance, against gamma matrices`], ['standard', 'the Dirac equation in Hestenes’ space-time algebra'], ['ours', 'reading the 8 even blades as the corners of the 4-demicube and the derivatives as cube edges'], ['open', 'solutions, spin sums, antiparticles and a gauge field'], ['input', 'the action, the grade of ψ, a time orientation, the complex structure J = γ₂γ₁']],
  coupling: [['checked', 'the ladder for n = 1 to 8 and the conservation identity, exactly'], ['standard', 'the Dirac–Maxwell system in Hestenes’ form'], ['ours', 'drawing the terms as edges of the cube and the current on the demicube'], ['open', 'n = 1 and 2; the extra parts of ψ from n = 5'], ['input', 'the action, the size of e, the time orientation and J of the Dirac step']],
  ym: [['checked', 'Bianchi identity, gauge covariance and conservation, exactly, for m = 2 to 8'], ['standard', 'the textbook Yang–Mills system with gauge algebra so(m)'], ['ours', 'drawing the generators as demicube corners and the pairs that do not commute as its edges'], ['open', 'the coupling constant g and which gauge algebra the model uses'], ['input', 'the action, so(m) as gauge algebra, the coupling g']],
  matter: [['checked', 'term counts, gauge covariance and conservation of the current on shell, exactly'], ['standard', 'the Dirac field in a representation of a gauge group, with its Noether currents'], ['ours', 'drawing the gauge action as demicube edges and the current as pairs of corners'], ['open', 'the coupling constant, which representation the model uses, chirality, solutions'], ['input', 'the action, the representation and the coupling κ']],
  grav1: [['checked', 'Bianchi identities of R and T, local Lorentz covariance and the curvature counts, exactly'], ['standard', 'first-order (Cartan) gravity: the structure equations'], ['ours', 'the curvature table read by plane pairs and by the demicube'], ['open', 'a field equation; solving T = 0 for ω, the usual connection from the tetrad'], ['input', 'the action, the tetrad, the grades of ω and e']],
  grav2: [['checked', 'D E_a is torsion terms only, and E_a is the Einstein tensor at e = dx, exactly'], ['standard', 'Einstein–Cartan with the MacDowell–Mansouri embedding'], ['ours', 'the cosmological term as one more generator; the pictures of the Einstein form'], ['open', 'the field equation with matter (no source is built), solutions'], ['input', 'the action and its Einstein form, the sign k = −s, the coupling κ']],
  mirrors: [['checked', 'at most n mirrors for any move, the layers of the cube, the E8 roots permuted by mirrors'], ['standard', 'versors, Cartan–Dieudonné and the reflection groups Bₙ and Dₙ'], ['ours', 'reading each corner of the cube as a set of mirrors'], ['open', `a mirror in a null vector (step ${stepNo('eq', 'projective')})`], ['input', 'which of two sign conventions a mirror fixes, and the normalisation by the reversion']],
  projective: [['checked', '[B_an, B_bn] = −2s B_ab, the null pair and PGA inside CGA, exactly'], ['standard', 'the plane-based algebras of Dorst and De Keninck; Poincaré, de Sitter, anti-de Sitter'], ['ours', 'reading the extra generators as bits of the cube'], ['open', 'dynamics; no physical role of the extra generator is claimed'], ['input', 'the label Cl(n,0,1) or Cl(0,n,1) and the tables of Dorst and De Keninck']],
  forque: [['checked', 'the paper’s rows reproduced by exact power series in time'], ['standard', 'the equations of the paper (Dorst and De Keninck)'], ['ours', 'putting the equations on the bit rule, the extra bit 0 as the null generator'], ['open', `${FQC.not_checked} items not checked; no conformal dynamics`], ['input', 'the paper’s equations, its inertia map and examples, the sign convention of the metric']],
  spin: [['checked', 'the rows reproduced by exact arithmetic'], ['standard', 'the equations of the authors and of the lecture'], ['ours', 'the side-by-side reading: the ⊞ identification, the left/right/conjugation label, the chirality XOR 9'], ['open', `${SPC.not_checked} items not checked; two cited papers not read`], ['input', 'the authors’ and the lecturer’s equations, the choice of the complex unit']],
  spring: [['checked', 'oscillator cases, normal modes, energy conservation and the signed network, exactly'], ['standard', 'Hooke’s law and the spectrum of the hypercube'], ['ours', 'masses, springs and faces as one cube; the flux π reading of the signs'], ['open', 'vector displacements, a continuum limit and an action principle'], ['input', 'Hooke’s law, the signed matrix D, the sign s; the translations of the cube, for a Dirac reading']],
  rigid: [['checked', 'the labels of the motors and the exact series of the flows'], ['standard', 'plane-based dynamics, Euler’s equation, Hooke, Newton and Kepler'], ['ours', 'the vertex, the blade and the motor coefficient as one label; the frame table'], ['open', 'the speed-ups timed on one machine, the planets table, bodies of springs'], ['input', 'Euler, Hooke, Newton and Kepler, the planets’ table, the time parameter']],
  gauge: [['checked', 'the shear N² = 0, the vacuum test, free fall, the Kerr–Schild form and the curvature counts'], ['standard', 'the gauge theory of gravity of Lasenby, Doran and Gull, and the textbook metric formulas'], ['ours', 'reading the horizon as the radical of the tangent algebra and a paired null of Cl(1,1)'], ['open', 'the field equations, the cosmology and the Hawking parts of the paper'], ['input', 'the point-mass solution of the paper, the frame and the radial gradient g']],
  nullsurf: [['checked', 'the horizon algebra, the five values of κ and the null directions as a plane'], ['standard', 'the paper’s claims about null hypersurfaces; the principal symbol of ∇F = J'], ['ours', 'readings of the horizon algebra and of the names ℍ and ℂ that carry labels'], ['open', 'Eq. (12) of the paper, most references, a second reader'], ['input', 'the metrics (Schwarzschild, Kerr, Ellis), the static Killing vector, the paper’s four claims']]
};
// Young Learner readings of steps 2 and 4 (plain words, no formulas; the formal text above stays for the other audiences and in the fold)
const AX4 = ['t', 'x', 'y', 'z'];
const andList = (a, w) => (a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ` ${w} ` + a[a.length - 1]);
const timeDirs = {
  en: p => (p === 0 ? 'Here all four directions are space.' : p === 4 ? 'Here all four directions are time.' : `Here ${andList(AX4.slice(0, p), 'and')} ${p === 1 ? 'is' : 'are'} time, and ${andList(AX4.slice(p), 'and')} ${4 - p === 1 ? 'is' : 'are'} space.`),
  it: p => (p === 0 ? 'Qui tutte e quattro le direzioni sono spazio.' : p === 4 ? 'Qui tutte e quattro le direzioni sono tempo.' : `Qui ${andList(AX4.slice(0, p), 'e')} ${p === 1 ? 'è' : 'sono'} tempo, e ${andList(AX4.slice(p), 'e')} ${4 - p === 1 ? 'è' : 'sono'} spazio.`)
};
const COPY = {
  en: {
    c: {
      yl: {
        name: 'WHEN THE ORDER MATTERS',
        title: 'Turning in two planes: when does the order matter?',
        picH: 'Six planes on a circle', pick: 'How many of the four directions are time? The others are space.',
        cap: p => `${timeDirs.en(p)} Each dot is a plane, named by its two directions. A line joins two planes that share one direction: for them the order matters, and the difference is the plane of the two directions they do not share. ${C.by_n['4'].edges} lines. Opposite dots share no direction and are not joined: for them the order does not matter.`,
        legend: 'Colour of a dot or a line:', roles: { E: 'one time direction: a boost, which is a change of speed', B: 'no time direction: a turn', T: 'two time directions' },
        lorentz: 'With one time direction and three of space, as in our world: two boosts, done in the two orders, differ by a turn (3 lines); two turns differ by a turn (3 lines); a turn and a boost differ by a boost (6 lines). 3 + 3 + 6 = 12.',
        edge: (a, b, c) => `${a} and ${b}: the order matters, and the difference is ${c}`,
        points: [
          [['checked'], 'Checked by a computer for every number of directions up to 8, and for every choice of which directions are time.'],
          [['checked'], `The same ${C.by_n['4'].edges} lines appear on the Maxwell page: two parts of the electric and magnetic field share an equation exactly when they share a direction.`],
          [['standard'], 'With one time direction, this is how turns and changes of speed combine in Einstein’s relativity. It is well known; we rebuilt it from the same rule.'],
          [['open'], 'This step only shows how the moves combine. It does not turn them into a force: step 7 tries that.']
        ]
      },
      title: 'Commutators: the Lorentz algebra from the same bits',
      lede: 'In Maxwell the field F is a bivector. Bivectors also generate rotations: the commutator of two bivectors is again a bivector. The bit rule says exactly when it is not zero: two bivectors anticommute when they share exactly one index, and commute when they share none. This is the structure of so(p,q), which is the Lorentz algebra when p = 1 and q = 3.',
      tableH: 'The rule, for every number of generators', cols: ['n generators', 'bivectors', 'pairs that do not commute', 'pairs that commute', 'closed triangles (index triples)'],
      note: 'Every signature up to n = 8 was checked. A non-zero commutator is always a bivector with coefficient ±2. The Jacobi identity holds exactly for every triple up to n = 6. The action on vectors is faithful and keeps the metric, so the bivectors really are so(p,q). The pairs that do not commute number n(n−1)(n−2)/2.',
      picH: 'The four-generator case: an octahedron', pick: 'Signature: time axes + space axes',
      cap: p => `6 bivectors on a circle, complementary pairs opposite (tx with yz, ty with xz, tz with xy), joined unless complementary: 12 edges. An edge is a pair that does not commute, and the commutator is the third corner of its triangle. Signature ${p} + ${4 - p}.`,
      legend: 'Colour = role of the bivector or of the commutator.', roles: { E: 'E: one time index (a boost when there is one time axis)', B: 'B: no time index (a rotation)', T: 'T: two time indices' },
      roleH: 'What each commutator is made of', roleCols: ['pair', 'shared index', 'result', 'edges'], via: { t: 'a time axis', s: 'a space axis' },
      lorentz: 'With one time and three space axes this is the Lorentz algebra: boost with boost gives a rotation (3 edges), rotation with rotation gives a rotation (3), rotation with boost gives a boost (6). Nothing else is needed.',
      points: [
        [['checked', 'standard'], `Maxwell (Calibration 1). Two field components share an equation exactly when they share an index. That is the same graph as the pairs that do not commute: ${C.by_n['4'].edges} edges at n = 4 on both sides, and equal counts for every n from 3 to 7.`],
        [['checked', 'standard'], 'Demicube (More shapes, step 2). At n = 4 the 16-cell has the scalar and the pseudoscalar at two poles and the six bivectors as its equator. The octahedron above is that equator: 12 edges, and the three commuting pairs are the antipodes.'],
        [['standard'], 'What this is. The structure constants of so(p,q). A non-abelian field strength F = dA + A∧A needs a gauge algebra, and so(n) is one choice whose structure is exactly this graph. Other Lie algebras are not covered.'],
        [['open'], 'Not shown: a Yang–Mills equation with a gauge field, and any dynamics of the commutator terms.']
      ]
    },
    d: {
      yl: {
        name: 'THE ELECTRON’S EQUATION',
        title: 'The electron’s equation lives on the even corners',
        numbers: `${D.counts.components} numbers, ${D.counts.equations} equations, ${D.counts.incidences} links. Each equation has ${D.counts.terms_per_equation.derivative} links for change (in time, and along x, y and z) and ${D.counts.terms_per_equation.mass} link for the mass.`,
        picH: 'Who is linked to whom',
        cap: 'Left: the 8 numbers of the electron, one on each corner with an even number of letters (1 is the corner with none). Right: the 8 equations, one on each corner with an odd number of letters. Coloured lines: how a number changes in time or along x, y and z. Dashed lines: the mass. Click a corner on the right to see its equation alone.',
        terms: n => `links in this equation: ${n}`, sign: 'sign', kinds: { dt: 'change in time', dx: 'change along x', dy: 'change along y', dz: 'change along z', m: 'mass' },
        points: [
          [['checked'], `A second program compares this with the usual way of writing the equation: they agree on all ${M.trials} random tries, and two versions that are wrong on purpose fail.`],
          [['checked'], 'After a turn or a change of speed the equation keeps its form: checked for all six of them.']
        ],
        limits: 'We do not solve the equation, and we say nothing about real electrons beyond these counts. This way of writing it is known (David Hestenes found it); we rebuilt it from the same rule and checked it.'
      },
      title: 'The Dirac equation lives on the even half',
      lede: 'In the algebra of one time and three space axes, write the electron field as an even multivector ψ: a scalar, six bivectors and a pseudoscalar. That is 8 real numbers, exactly the 8 corners of the 4-demicube. The equation is ∇ψJ = mψγ₀, where J = γ₂γ₁ squares to −1 and plays the role of i. Both sides are odd: ∇ flips parity, as in Maxwell.',
      numbers: `${D.counts.components} components, ${D.counts.equations} equations, ${D.counts.incidences} incidences. Each equation has ${D.counts.terms_per_equation.derivative} derivative terms and ${D.counts.terms_per_equation.mass} mass term.`,
      picH: 'The incidence picture', cap: 'Left: the 8 even blades (ψ). Right: the 8 odd blades, one equation each. Coloured lines are the four derivatives. Dashed lines are the mass term. Click an odd blade to isolate its equation.',
      terms: n => `terms in this equation: ${n}`, sign: 'sign', kinds: { dt: '∂t', dx: '∂x', dy: '∂y', dz: '∂z', m: 'mass' },
      xrefH: 'Cross-references',
      cube: { h: 'Cube view', t: `The ${D.counts.cube_edges_used_by_derivative} derivative terms are all ${D.counts.cube_edges_used_by_derivative} edges of the 4-cube, from an even corner to an odd one, followed by one fixed shift by the bits of J. The ${D.counts.mass_edges} mass terms are the time edges of the cube.` },
      maxwell: { h: 'Maxwell (Calibration 1)', t: `The six bivector components of ψ are the same blades Maxwell uses for E and B. Maxwell's ∇F = J has ${MX4.incidences} incidences with ${MX4.vector_equations} vector and ${MX4.trivector_equations} trivector equations; the Dirac equation has ${D.counts.incidences} incidences, because ψ also carries a scalar and a pseudoscalar and the mass term returns to the odd half.` },
      comm: { h: 'Commutators (step 2)', t: 'Left multiplication of ψ by a bivector is an infinitesimal Lorentz transformation. For each of the 6 bivectors B the identity D(Bψ) = B D(ψ) − D′(ψ) holds exactly, where D′ has the momentum rotated by the commutator [B, p] and no mass term. So the graph of step 2 acts on the components of step 4.' },
      disp: { h: 'Momentum space', t: `The 8 × 8 system has determinant (p² − m²)⁴, checked exactly at ${D.dispersion.length} points. On the mass shell p² = m² the solutions at a given momentum p form a ${D.solution_space.massive_shell_real_dim}-dimensional real space, that is two complex dimensions: the two spin states. The sign of the energy is the sign of p⁰ and belongs to the point p, not to the solution space: at p and at −p the kernel has the same dimension and a definite, opposite energy sign (the spin step checks this at 8 on-shell momenta of both signs of the energy, row S23). Off the shell there are none.` },
      mat: { h: 'Independent check', t: `With explicit 4 × 4 gamma matrices (numpy) we send ψ to Ψ = ψu, with u = (1, 0, 0, 0). Right multiplication by J then acts as i, and the expression above equals the standard Dirac equation on ${M.trials} random cases (largest error ${err}). Two wrong versions, J with the wrong sign and no J, fail by ${ctrl[0]} and ${ctrl[1]}.` },
      limits: 'What this does not show: solutions, spin sums, anything about antiparticles, or a gauge field. It is a known formulation (Hestenes’ space-time algebra). We rebuilt it on the bit rule and checked it.',
      tags: [['checked'], ['standard'], ['ours']]
    },
    t: {
      eyebrow: 'WHERE THE TALLY STANDS', title: 'Equations we can draw and check',
      lede: 'Each row is an equation whose structure is drawn from the bit rule and checked by a script. The pictures show which components enter which equation, with which operation. They do not show solutions. Each status cell lists what each tag covers on that step.',
      cols: ['equation', 'where', 'components', 'incidences', 'status'],
      rows: [
        ['∇F = J (Maxwell)', 'Calibration 1; cells n = 2 to 7', `${MX4.F_components} in 4D`, `${MX4.incidences} in 4D`, TT('maxwell'), STATUS.maxwell],
        ['Commutators of bivectors (so(p,q))', 'step ' + stepNo('eq', 'comm') + '; n = 2 to 8', `${C.by_n['4'].bivectors} in 4D`, `${C.by_n['4'].edges} relations in 4D`, TT('comm'), STATUS.comm],
        ['Mirrors: x ↦ −a x a⁻¹, versors, Cartan–Dieudonné', 'step ' + stepNo('eq', 'mirrors') + '; n = 2 to 8', `${MR4.corners} corners in 4D`, `${MR4.rotors} rotors, ${MR4.reflections} reflections, at most ${MR4.max_mirrors} mirrors in 4D`, TT('mirrors'), STATUS.mirrors],
        ['∇ψJ = mψγ₀ (Dirac)', 'step ' + stepNo('eq', 'dirac') + '; Cl(1,3)', `${D.counts.components}`, `${D.counts.incidences}`, TT('dirac'), STATUS.dirac],
        ['Spinors: pointors ψOψ̃ = ρO, the labels of the b_j, ⊞ = Πw₊w₋ and the lecture’s B + i', 'step ' + stepNo('eq', 'spin') + '; Cl(2,0) to Cl(7,0) and Cl(1,3); the three kinds of i', `${SPC.rows} statements from a paper and a lecture`, `${SPC.ok} agree exactly, ${SPC.note} after a small adjustment, ${SPC.not_checked} not checked`, TT('spin'), STATUS.spin],
        ['Coupling: ∇F = eX and −eAψ', 'step ' + stepNo('eq', 'coupling') + '; n = 1 to 8 (charged form from n = 3)', `${K4.psi_components} + ${K4.F_components} + 4 in 4D`, `${K4.incidences_total} + ${K4.maxwell_incidences} in 4D`, TT('coupling'), STATUS.coupling],
        ['Yang–Mills: D^μF_{μν} = J_ν, gauge algebra so(m)', 'step ' + stepNo('eq', 'ym') + '; m = 2 to 8', `${YM4.F_components} in 4D at m = 3`, `${YM4.equation_terms + YM4.bianchi_terms} in 4D at m = 3`, TT('ym'), STATUS.ym],
        ['Charged matter: Dirac + so(m), current j^a', 'step ' + stepNo('eq', 'matter') + '; m = 2 to 8', `${MT3.components} in 4D at m = 3`, `${MT3.terms_total} in 4D at m = 3`, TT('matter'), STATUS.matter],
        ['Gravity I: R = dω + ¼[ω,ω], T = de + ωe', 'step ' + stepNo('eq', 'grav1') + '; n = 2 to 8', `${GV4.curvature_components} + ${GV4.torsion_components} in 4D`, `${GVC4} cells − ${GV4.first_bianchi_constraints} relation in 4D`, TT('grav1'), STATUS.grav1],
        ['Gravity II: Einstein form E_a, F = R + c e∧e', 'step ' + stepNo('eq', 'grav2') + '; n = 3 to 8 (none at n = 2)', `${GV4.einstein_components} in 4D`, `${GV4.einstein_terms_per_component} terms in each E_a in 4D`, TT('grav2'), STATUS.grav2],
        ['One more generator and a null pair: [B_an, B_bn] = −2s B_ab; ε, o', 'step ' + stepNo('eq', 'projective') + '; n = 2 to 6 (null pair n = 2 to 4)', `${PJ4.ladder_generators} generators and ${PJ4.cga_dimension} blades in 4D`, `${PJ4.conformal_generators} conformal generators in 4D`, TT('projective'), STATUS.projective],
        ['Gauge gravity: the shear h̄ = 1 + N, the radial gradient h̄(e_r) = e_r + g e_t and the horizon r = 2M', 'step ' + stepNo('eq', 'gauge') + '; a point mass in Cl(1,3); curvature counts for n = 2 to 8', `${GV4.riemann_independent} Riemann components in 4D`, 'no incidence picture: the shear (N² = 0), the vacuum test and free fall are computed live; the field equations are not decoded', TT('gauge'), STATUS.gauge],
        ['Null surfaces: the generator of a null hypersurface, g^rr and g_tt = 0 as tests, the horizon algebra Cl(0, n−2, 1)', 'step ' + stepNo('eq', 'nullsurf') + '; n = 2 to 6 for the algebra; five horizons, three Eq. (1) cases, Kerr with M = 5 and a = 3', `κ = ${NUK} for the five horizons; dim J = 2^(n−2) = ${NUJ} for n = 2 to 6`, `${NUS.passed} of ${NUS.computed} computed checks pass; ${NUS.readings} readings are ours and not computed`, TT('nullsurf'), STATUS.nullsurf],
        ['Forque dynamics: Ṗ = F, Ḃ = I⁻¹[B×I[B]+F], Ṁ = −½MB', 'step ' + stepNo('eq', 'forque') + '; PGA with d = 2 and 3 (inertia map also d = 4)', `${FQC.rows} equations of one paper`, `${FQC.ok} agree exactly, ${FQC.note} after a small adjustment, ${FQC.not_checked} not checked`, TT('forque'), STATUS.forque],
        ['A spring network on the cube: x″ = −Lx, plain and with the sign of the generator', 'step ' + stepNo('eq', 'spring') + '; n = 2 to 5 (series at n = 3); the three kinds of i as oscillator, inverted oscillator, free motion', `${SRD.cube['3'].V} masses and ${SRD.cube['3'].E} springs in 3D, ${SRD.cube['4'].V} and ${SRD.cube['4'].E} in 4D`, `${SRD.summary.ok} exact claims in ${SRD.rows.length} rows, all hold; 2 levels n ± √n against n + 1`, TT('spring'), STATUS.spring],
        ['A rigid body: M′ = −½MB, B′ = A⁻¹(F + ½[B, A(B)]), gravity, Hooke and damping as lines', 'step ' + stepNo('eq', 'rigid') + '; n = 1 to 4 (counts to n = 5); segment, square, cube, tesseract, then the free top, the Moon, and the Sun with five planets', `${PGD.frame_table['3'].vertices} vertices carry ${PGD.frame_table['3'].motor_coefficients} motor coefficients in 3D, ${PGD.frame_table['4'].vertices} and ${PGD.frame_table['4'].motor_coefficients} in 4D`, `${PGD.summary.ok} claims in ${PGD.summary.rows} rows, all hold (reference rows against ganja.js); the speed of the labels is timed, not proved`, TT('rigid'), STATUS.rigid]
      ],
      next: 'Still not drawn: chiral coupling (the electroweak doublets, where left and right feel different forces), whose mass term needs a scalar doublet (one more step, not an input), the Dirac equation on a curved tetrad, the field equation of gravity with matter (the coupling and its sign), the neutral (real) form at n = 1 and 2, and the solutions of any of these equations.',
      note: '{N} rows, none new. Maxwell, bivector commutators and Dirac are each linear in their own field; the coupling is bilinear (Aψ) and quadratic (ψγ₀ψ̃), and Yang–Mills adds terms quadratic and cubic in A from its own commutator, and gravity multiplies curvature (itself quadratic in ω) by tetrads, so the joint systems are nonlinear. The mirrors row, the one-more-generator row and the null-surfaces row are not equations to be solved but groups of motions, a condition on a surface and an algebra, so they give counts and identities and no terms. We drew where the terms sit and checked identities, not solutions, except in five steps ({FIVE}), which check another group’s equations of rigid-body motion, including exact power-series solutions, a paper and a lecture on spinors, where the claims are exact identities, a spring network on the cube, again with exact power-series solutions, a rigid body from a segment to a tesseract, where a live engine is checked against exact power-series solutions, and a paper on null surfaces, where the claims are exact identities and counts. Nothing here predicts anything.'
    },
    dl: { h: 'Check it yourself', text: 'Two Python files. The first (standard library only) rebuilds the commutator tables, the Dirac incidences, the determinant, the shell dimensions and the covariance identity, exactly. The second (needs numpy) compares the Dirac form with the usual gamma matrices and runs two wrong versions that must fail.', py: 'Download equations_selfcheck.py', py2: 'Download dirac_matrix_check.py', json: 'Download equations.json', cmd: 'python3 equations_selfcheck.py --compare equations.json   ·   python3 dirac_matrix_check.py' }
  },
  it: {
    c: {
      yl: {
        name: 'QUANDO L’ORDINE CONTA',
        title: 'Girare in due piani: quando conta l’ordine?',
        picH: 'Sei piani su un cerchio', pick: 'Quante delle quattro direzioni sono tempo? Le altre sono spazio.',
        cap: p => `${timeDirs.it(p)} Ogni punto è un piano, chiamato con le sue due direzioni. Una linea unisce due piani che hanno una direzione in comune: per loro l’ordine conta, e la differenza è il piano delle due direzioni che non hanno in comune. ${C.by_n['4'].edges} linee. I punti opposti non hanno direzioni in comune e non sono uniti: per loro l’ordine non conta.`,
        legend: 'Colore di un punto o di una linea:', roles: { E: 'una direzione di tempo: un boost, cioè un cambio di velocità', B: 'nessuna direzione di tempo: una rotazione', T: 'due direzioni di tempo' },
        lorentz: 'Con una direzione di tempo e tre di spazio, come nel nostro mondo: due boost, fatti nei due ordini, differiscono per una rotazione (3 linee); due rotazioni differiscono per una rotazione (3 linee); una rotazione e un boost differiscono per un boost (6 linee). 3 + 3 + 6 = 12.',
        edge: (a, b, c) => `${a} e ${b}: l’ordine conta, e la differenza è ${c}`,
        points: [
          [['checked'], 'Controllato da un computer per ogni numero di direzioni fino a 8, e per ogni scelta di quali direzioni sono tempo.'],
          [['checked'], `Le stesse ${C.by_n['4'].edges} linee compaiono nella pagina di Maxwell: due parti del campo elettrico e magnetico condividono un’equazione esattamente quando condividono una direzione.`],
          [['standard'], 'Con una direzione di tempo, è il modo in cui rotazioni e cambi di velocità si combinano nella relatività di Einstein. È noto; lo abbiamo ricostruito con la stessa regola.'],
          [['open'], 'Questo passo mostra solo come si combinano le mosse. Non le trasforma in una forza: ci prova il passo 7.']
        ]
      },
      title: 'Commutatori: l’algebra di Lorentz dagli stessi bit',
      lede: 'In Maxwell il campo F è un bivettore. I bivettori generano anche le rotazioni: il commutatore di due bivettori è di nuovo un bivettore. La regola dei bit dice esattamente quando non è zero: due bivettori anticommutano quando condividono esattamente un indice, e commutano quando non ne condividono nessuno. È la struttura di so(p,q), cioè l’algebra di Lorentz quando p = 1 e q = 3.',
      tableH: 'La regola, per ogni numero di generatori', cols: ['n generatori', 'bivettori', 'coppie che non commutano', 'coppie che commutano', 'triangoli chiusi (terne di indici)'],
      note: 'Abbiamo controllato ogni segnatura fino a n = 8. Un commutatore non nullo è sempre un bivettore con coefficiente ±2. L’identità di Jacobi vale esattamente per ogni terna fino a n = 6. L’azione sui vettori è fedele e conserva la metrica, quindi i bivettori sono davvero so(p,q). Le coppie che non commutano sono n(n−1)(n−2)/2.',
      picH: 'Il caso a quattro generatori: un ottaedro', pick: 'Segnatura: assi di tempo + assi di spazio',
      cap: p => `6 bivettori su un cerchio, coppie complementari opposte (tx con yz, ty con xz, tz con xy), uniti salvo i complementari: 12 spigoli. Uno spigolo è una coppia che non commuta, e il commutatore è il terzo vertice del suo triangolo. Segnatura ${p} + ${4 - p}.`,
      legend: 'Colore = ruolo del bivettore o del commutatore.', roles: { E: 'E: un indice di tempo (un boost se c’è un solo asse di tempo)', B: 'B: nessun indice di tempo (una rotazione)', T: 'T: due indici di tempo' },
      roleH: 'Di che cosa è fatto ogni commutatore', roleCols: ['coppia', 'indice condiviso', 'risultato', 'spigoli'], via: { t: 'un asse di tempo', s: 'un asse di spazio' },
      lorentz: 'Con un asse di tempo e tre di spazio è l’algebra di Lorentz: boost con boost dà una rotazione (3 spigoli), rotazione con rotazione dà una rotazione (3), rotazione con boost dà un boost (6). Non serve altro.',
      points: [
        [['checked', 'standard'], `Maxwell (Calibration 1). Two field components share an equation exactly when they share an index. That is the same graph as the pairs that do not commute: ${C.by_n['4'].edges} edges at n = 4 on both sides, and equal counts for every n from 3 to 7.`],
        [['checked', 'standard'], 'Demicubo (Altre forme, passo 2). A n = 4 la 16-cella ha lo scalare e lo pseudoscalare ai due poli e i sei bivettori come equatore. L’ottaedro qui sopra è quell’equatore: 12 spigoli, e le tre coppie che commutano sono gli antipodi.'],
        [['standard'], 'Che cos’è. Le costanti di struttura di so(p,q). Un campo non abeliano F = dA + A∧A richiede un’algebra di gauge, e so(n) è una scelta la cui struttura è esattamente questo grafo. Altre algebre di Lie non sono coperte.'],
        [['open'], 'Non mostrato: un’equazione di Yang–Mills con un campo di gauge, e qualunque dinamica dei termini di commutatore.']
      ]
    },
    d: {
      yl: {
        name: 'L’EQUAZIONE DELL’ELETTRONE',
        title: 'L’equazione dell’elettrone vive sui vertici pari',
        numbers: `${D.counts.components} numeri, ${D.counts.equations} equazioni, ${D.counts.incidences} legami. Ogni equazione ha ${D.counts.terms_per_equation.derivative} legami per il cambiamento (nel tempo, e lungo x, y e z) e ${D.counts.terms_per_equation.mass} legame per la massa.`,
        picH: 'Chi è legato a chi',
        cap: 'A sinistra: gli 8 numeri dell’elettrone, uno su ogni vertice con un numero pari di lettere (1 è il vertice senza lettere). A destra: le 8 equazioni, una su ogni vertice con un numero dispari di lettere. Linee colorate: come cambia un numero nel tempo o lungo x, y e z. Linee tratteggiate: la massa. Clicca un vertice a destra per vedere da sola la sua equazione.',
        terms: n => `legami in questa equazione: ${n}`, sign: 'segno', kinds: { dt: 'cambio nel tempo', dx: 'cambio lungo x', dy: 'cambio lungo y', dz: 'cambio lungo z', m: 'massa' },
        points: [
          [['checked'], `Un secondo programma confronta tutto questo con il modo usuale di scrivere l’equazione: coincidono in tutte le ${M.trials} prove a caso, e due versioni sbagliate apposta falliscono.`],
          [['checked'], 'Dopo una rotazione o un cambio di velocità l’equazione mantiene la sua forma: controllato per tutti e sei.']
        ],
        limits: 'Non risolviamo l’equazione, e non diciamo nulla sugli elettroni reali oltre a questi conteggi. Questo modo di scriverla è noto (l’ha trovato David Hestenes); l’abbiamo ricostruito con la stessa regola e controllato.'
      },
      title: 'L’equazione di Dirac vive sulla metà pari',
      lede: 'Nell’algebra di un asse di tempo e tre di spazio, scriviamo il campo dell’elettrone come un multivettore pari ψ: uno scalare, sei bivettori e uno pseudoscalare. Sono 8 numeri reali, esattamente gli 8 vertici del 4-demicubo. L’equazione è ∇ψJ = mψγ₀, dove J = γ₂γ₁ ha quadrato −1 e fa da i. Entrambi i lati sono dispari: ∇ scambia la parità, come in Maxwell.',
      numbers: `${D.counts.components} componenti, ${D.counts.equations} equazioni, ${D.counts.incidences} incidenze. Ogni equazione ha ${D.counts.terms_per_equation.derivative} termini di derivata e ${D.counts.terms_per_equation.mass} termine di massa.`,
      picH: 'Il quadro delle incidenze', cap: 'A sinistra: gli 8 blade pari (ψ). A destra: gli 8 blade dispari, uno per equazione. Le linee colorate sono le quattro derivate. Le linee tratteggiate sono il termine di massa. Clicca un blade dispari per isolare la sua equazione.',
      terms: n => `termini in questa equazione: ${n}`, sign: 'segno', kinds: { dt: '∂t', dx: '∂x', dy: '∂y', dz: '∂z', m: 'massa' },
      xrefH: 'Rimandi',
      cube: { h: 'Vista cubo', t: `I ${D.counts.cube_edges_used_by_derivative} termini di derivata sono tutti i ${D.counts.cube_edges_used_by_derivative} spigoli del 4-cubo, da un vertice pari a uno dispari, seguiti da un solo spostamento fisso con i bit di J. Gli ${D.counts.mass_edges} termini di massa sono gli spigoli temporali del cubo.` },
      maxwell: { h: 'Maxwell (Calibration 1)', t: `Le sei componenti bivettoriali di ψ sono gli stessi blade che Maxwell usa per E e B. ∇F = J di Maxwell ha ${MX4.incidences} incidenze con ${MX4.vector_equations} equazioni vettoriali e ${MX4.trivector_equations} trivettoriali; l’equazione di Dirac ha ${D.counts.incidences} incidenze, perché ψ porta anche uno scalare e uno pseudoscalare e il termine di massa torna alla metà dispari.` },
      comm: { h: 'Commutatori (passo 2)', t: 'La moltiplicazione a sinistra di ψ per un bivettore è una trasformazione di Lorentz infinitesima. Per ciascuno dei 6 bivettori B l’identità D(Bψ) = B D(ψ) − D′(ψ) vale esattamente, dove D′ ha l’impulso ruotato dal commutatore [B, p] e nessun termine di massa. Quindi il grafo del passo 2 agisce sulle componenti del passo 4.' },
      disp: { h: 'Spazio degli impulsi', t: `The 8 × 8 system has determinant (p² − m²)⁴, checked exactly at ${D.dispersion.length} points. On the mass shell p² = m² the solutions at a given momentum p form a ${D.solution_space.massive_shell_real_dim}-dimensional real space, that is two complex dimensions: the two spin states. The sign of the energy is the sign of p⁰ and belongs to the point p, not to the solution space: at p and at −p the kernel has the same dimension and a definite, opposite energy sign (the spin step checks this at 8 on-shell momenta of both signs of the energy, row S23). Off the shell there are none.` },
      mat: { h: 'Controllo indipendente', t: `Con matrici gamma 4 × 4 esplicite (numpy) mandiamo ψ in Ψ = ψu, con u = (1, 0, 0, 0). La moltiplicazione a destra per J agisce allora come i, e l’espressione qui sopra coincide con l’equazione di Dirac standard su ${M.trials} casi casuali (errore massimo ${M.worst_error.toExponential(0)}). Due versioni sbagliate, J con il segno sbagliato e senza J, falliscono di ${ctrl[0]} e ${ctrl[1]}.` },
      limits: 'What this does not show: solutions, spin sums, anything about antiparticles, or a gauge field. It is a known formulation (Hestenes’ space-time algebra). We rebuilt it on the bit rule and checked it.',
      tags: [['checked'], ['standard'], ['ours']]
    },
    t: {
      eyebrow: 'A CHE PUNTO È IL BILANCIO', title: 'Equazioni che possiamo disegnare e controllare',
      lede: 'Ogni riga è un’equazione la cui struttura è disegnata dalla regola dei bit e controllata da uno script. I disegni mostrano quali componenti entrano in quale equazione, con quale operazione. Non mostrano le soluzioni. Each status cell lists what each tag covers on that step.',
      cols: ['equazione', 'dove', 'componenti', 'incidenze', 'stato'],
      rows: [
        ['∇F = J (Maxwell)', 'Calibration 1; cells n = 2 to 7', `${MX4.F_components} in 4D`, `${MX4.incidences} in 4D`, TT('maxwell'), STATUS.maxwell],
        ['Commutatori dei bivettori (so(p,q))', 'passo ' + stepNo('eq', 'comm') + '; n = 2…8', `${C.by_n['4'].bivectors} in 4D`, `${C.by_n['4'].edges} relazioni in 4D`, TT('comm'), STATUS.comm],
        ['Specchi: x ↦ −a x a⁻¹, versori, Cartan–Dieudonné', 'passo ' + stepNo('eq', 'mirrors') + '; n = 2…8', `${MR4.corners} vertici in 4D`, `${MR4.rotors} rotori, ${MR4.reflections} riflessioni, al massimo ${MR4.max_mirrors} specchi in 4D`, TT('mirrors'), STATUS.mirrors],
        ['∇ψJ = mψγ₀ (Dirac)', 'passo ' + stepNo('eq', 'dirac') + '; Cl(1,3)', `${D.counts.components}`, `${D.counts.incidences}`, TT('dirac'), STATUS.dirac],
        ['Spinori: pointor ψOψ̃ = ρO, le etichette dei b_j, ⊞ = Πw₊w₋ e il B + i della lezione', 'passo ' + stepNo('eq', 'spin') + '; da Cl(2,0) a Cl(7,0) e Cl(1,3); i tre tipi di i', `${SPC.rows} affermazioni di un articolo e di una lezione`, `${SPC.ok} agree exactly, ${SPC.note} after a small adjustment, ${SPC.not_checked} not checked`, TT('spin'), STATUS.spin],
        ['Accoppiamento: ∇F = eX e −eAψ', 'passo ' + stepNo('eq', 'coupling') + '; n = 1…8 (forma carica da n = 3)', `${K4.psi_components} + ${K4.F_components} + 4 in 4D`, `${K4.incidences_total} + ${K4.maxwell_incidences} in 4D`, TT('coupling'), STATUS.coupling],
        ['Yang–Mills: D^μF_{μν} = J_ν, algebra di gauge so(m)', 'passo ' + stepNo('eq', 'ym') + '; m = 2…8', `${YM4.F_components} in 4D a m = 3`, `${YM4.equation_terms + YM4.bianchi_terms} in 4D a m = 3`, TT('ym'), STATUS.ym],
        ['Materia carica: Dirac + so(m), corrente j^a', 'passo ' + stepNo('eq', 'matter') + '; m = 2…8', `${MT3.components} in 4D a m = 3`, `${MT3.terms_total} in 4D a m = 3`, TT('matter'), STATUS.matter],
        ['Gravità I: R = dω + ¼[ω,ω], T = de + ωe', 'passo ' + stepNo('eq', 'grav1') + '; n = 2…8', `${GV4.curvature_components} + ${GV4.torsion_components} in 4D`, `${GVC4} celle − ${GV4.first_bianchi_constraints} relazione in 4D`, TT('grav1'), STATUS.grav1],
        ['Gravità II: forma di Einstein E_a, F = R + c e∧e', 'passo ' + stepNo('eq', 'grav2') + '; n = 3…8 (nessuna a n = 2)', `${GV4.einstein_components} in 4D`, `${GV4.einstein_terms_per_component} termini in ogni E_a in 4D`, TT('grav2'), STATUS.grav2],
        ['Un generatore in più e una coppia nulla: [B_an, B_bn] = −2s B_ab; ε, o', 'passo ' + stepNo('eq', 'projective') + '; n = 2…6 (coppia nulla n = 2…4)', `${PJ4.ladder_generators} generatori e ${PJ4.cga_dimension} lame in 4D`, `${PJ4.conformal_generators} generatori conformi in 4D`, TT('projective'), STATUS.projective],
        ['Gauge gravity: the shear h̄ = 1 + N, the radial gradient h̄(e_r) = e_r + g e_t and the horizon r = 2M', 'passo ' + stepNo('eq', 'gauge') + '; a point mass in Cl(1,3); curvature counts for n = 2 to 8', `${GV4.riemann_independent} Riemann components in 4D`, 'no incidence picture: the shear (N² = 0), the vacuum test and free fall are computed live; the field equations are not decoded', TT('gauge'), STATUS.gauge],
        ['Superfici nulle: il generatore di un’ipersuperficie nulla, g^rr e g_tt = 0 come test, l’algebra dell’orizzonte Cl(0, n−2, 1)', 'passo ' + stepNo('eq', 'nullsurf') + '; n = 2…6 per l’algebra; cinque orizzonti, tre casi dell’Eq. (1), Kerr con M = 5 e a = 3', `κ = ${NUK} per i cinque orizzonti; dim J = 2^(n−2) = ${NUJ} per n = 2…6`, `${NUS.passed} controlli calcolati su ${NUS.computed} riusciti; ${NUS.readings} letture sono nostre e non calcolate`, TT('nullsurf'), STATUS.nullsurf],
        ['Dinamica del forque: Ṗ = F, Ḃ = I⁻¹[B×I[B]+F], Ṁ = −½MB', 'passo ' + stepNo('eq', 'forque') + '; PGA con d = 2 e 3 (mappa d’inerzia anche d = 4)', `${FQC.rows} equazioni di un solo articolo`, `${FQC.ok} agree exactly, ${FQC.note} after a small adjustment, ${FQC.not_checked} not checked`, TT('forque'), STATUS.forque],
        ['Una rete di molle sul cubo: x″ = −Lx, semplice e con il segno del generatore', 'passo ' + stepNo('eq', 'spring') + '; n = 2…5 (serie a n = 3); i tre tipi di i come oscillatore, oscillatore invertito, moto libero', `${SRD.cube['3'].V} masse e ${SRD.cube['3'].E} molle in 3D, ${SRD.cube['4'].V} e ${SRD.cube['4'].E} in 4D`, `${SRD.summary.ok} affermazioni esatte in ${SRD.rows.length} righe, tutte valide; 2 livelli n ± √n contro n + 1`, TT('spring'), STATUS.spring],
        ['Un corpo rigido: M′ = −½MB, B′ = A⁻¹(F + ½[B, A(B)]), gravità, Hooke e smorzamento come rette', 'passo ' + stepNo('eq', 'rigid') + '; n = 1…4 (conteggi fino a n = 5); segmento, quadrato, cubo, tesseratto, poi la trottola libera, la Luna e il Sole con cinque pianeti', `${PGD.frame_table['3'].vertices} vertici portano ${PGD.frame_table['3'].motor_coefficients} coefficienti del motore in 3D, ${PGD.frame_table['4'].vertices} e ${PGD.frame_table['4'].motor_coefficients} in 4D`, `${PGD.summary.ok} affermazioni in ${PGD.summary.rows} righe, tutte valide (righe di riferimento contro ganja.js); la velocità delle etichette è misurata, non dimostrata`, TT('rigid'), STATUS.rigid]
      ],
      next: 'Still not drawn: chiral coupling (the electroweak doublets, where left and right feel different forces), whose mass term needs a scalar doublet (one more step, not an input), the Dirac equation on a curved tetrad, the field equation of gravity with matter (the coupling and its sign), the neutral (real) form at n = 1 and 2, and the solutions of any of these equations.',
      note: '{N} righe, nessuna nuova. Maxwell, i commutatori dei bivettori e Dirac sono lineari ciascuno nel proprio campo; l’accoppiamento è bilineare (Aψ) e quadratico (ψγ₀ψ̃), e Yang–Mills aggiunge termini quadratici e cubici in A dal proprio commutatore, e la gravità moltiplica la curvatura (già quadratica in ω) per le tetradi, quindi i sistemi congiunti sono non lineari. La riga sugli specchi, quella sul generatore in più e quella sulle superfici nulle non sono equazioni da risolvere ma gruppi di moti, una condizione su una superficie e un’algebra, quindi danno conteggi e identità e nessun termine. Abbiamo disegnato dove stanno i termini e controllato identità, non soluzioni, tranne in cinque passi ({FIVE}), che controllano le equazioni del moto del corpo rigido di un altro gruppo, comprese soluzioni esatte in serie di potenze, un articolo e una lezione sugli spinori, dove le affermazioni sono identità esatte, una rete di molle sul cubo, con soluzioni esatte in serie di potenze, un corpo rigido da un segmento a un tesseratto, dove un motore dal vivo è controllato contro soluzioni esatte in serie di potenze, e un articolo sulle superfici nulle, dove le affermazioni sono identità e conteggi esatti. Niente qui predice qualcosa.'
    },
    dl: { h: 'Verificalo tu', text: 'Due file Python. Il primo (solo libreria standard) ricostruisce le tabelle dei commutatori, le incidenze di Dirac, il determinante, le dimensioni sulla superficie di massa e l’identità di covarianza, esattamente. Il secondo (richiede numpy) confronta la forma di Dirac con le solite matrici gamma e fa girare due versioni sbagliate che devono fallire.', py: 'Scarica equations_selfcheck.py', py2: 'Scarica dirac_matrix_check.py', json: 'Scarica equations.json', cmd: 'python3 equations_selfcheck.py --compare equations.json   ·   python3 dirac_matrix_check.py' }
  }
};
// the number of tally rows is written out from the rows themselves, so it can never go stale; so are the numbers of the five steps whose claims are solutions or exact identities of another group's equations
// (the spinor step, the null surfaces, the Forque, the spring network and the rigid body: test_equations.mjs ties the list to the steps)
export const SOLVED_STEPS = ['spin', 'nullsurf', 'forque', 'spring', 'rigid'];
const FIVE = SOLVED_STEPS.map(id => stepNo('eq', id)).sort((a, b) => a - b).join(', ');
for (const l of ['en', 'it']) { const w = numWord(l, COPY[l].t.rows.length); if (!w) throw new Error(`no number word for ${COPY[l].t.rows.length} tally rows (steps.js NUMW)`); COPY[l].t.note = COPY[l].t.note.replace('{N}', capital(w)).replace('{FIVE}', FIVE); }
export default COPY;
