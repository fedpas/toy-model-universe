// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { CONV } from './conventionsCopy.js';
import { Tags } from './StatusBadge.jsx';
import { storyFor } from './StoryShell.jsx';
import { Tx } from './MathText.jsx';

// The Conventions tab: the statements (a list, one entry per row, each with the places that use it, its tags and the checks it stands on),
// the primordial ideas with what is proved and what would settle them, and the glossary. Lists, not tables: the page reads on a phone.
// Each line of tags is one paragraph that holds its badges and its note (the reader filter hides it when it is known ground).
const STYLE = `
.cv{margin:14px 0}.cv h3{margin:1.1em 0 .4em;font-size:1.05em}.cv-lede{font-size:.9em;opacity:.85;margin:.3em 0 .8em}
.cv-rows,.cv-ideas{list-style:none;margin:0;padding:0}
.cv-row,.cv-idea{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:10px 14px;margin:10px 0}
.cv-row p,.cv-idea p{margin:.35em 0}.cv-n{display:inline-block;min-width:1.8em;opacity:.7;font-variant-numeric:tabular-nums}
.cv-where,.cv-ids{font-size:.82em;opacity:.8;overflow-wrap:anywhere}.cv-where .gl-k,.cv-ids .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}
.cv-tags{font-size:.85em}.cv-tags .tag{margin-right:4px}
.cv-proved .gl-k,.cv-would .gl-k,.cv-refute .gl-k{display:block;font-size:.78em;letter-spacing:.05em;opacity:.7}
.cv-gloss{margin:.4em 0}.cv-gloss dt{font-weight:600;margin-top:.7em}.cv-gloss dd{margin:.15em 0 0;overflow-wrap:anywhere}.cv-gloss-tags{margin:0}.cv-gloss-tags .tag{margin-right:4px}
`;

export default function ConventionsSection({ lang = 'en', yl = false }) {
  const L = lang === 'it' ? 'it' : 'en', c = CONV[L], s = storyFor(L, yl ? 'Young Learner' : 'Physicist');
  const label = { where: c.where, checks: c.checks };
  return <div className="cv" id="cv-top"><style>{STYLE}</style>
    <h3 id="cv-statements"><Tx>{c.rowsH}</Tx></h3>
    <ol className="cv-rows">{c.rows.map(r => <li className="cv-row" id={'cv-row-' + r.n} key={r.n}>
      <p className="cv-h"><span className="cv-n">{r.n}</span> <b><Tx>{r.title}</Tx></b> <Tx>{r.text}</Tx></p>
      {r.where.length > 0 && <p className="cv-where"><span className="gl-k"><Tx>{label.where.toUpperCase()}</Tx></span><Tx>{r.where.join(' · ')}</Tx></p>}
      {((r.ids && r.ids.length) || (r.scripts && r.scripts.length)) ? <p className="cv-ids"><span className="gl-k"><Tx>{label.checks.toUpperCase()}</Tx></span><code>{[...(r.ids || []), ...(r.scripts || [])].join(' · ')}</code></p> : null}
      <p className="audit-line cv-tags"><Tags kinds={r.tags} lang={L} strings={s} /> <Tx>{r.note}</Tx></p></li>)}</ol>
    <h3 id="cv-ideas"><Tx>{c.ideasH}</Tx></h3>
    <p className="cv-lede"><Tx>{c.ideasLede}</Tx></p>
    <ul className="cv-ideas">{c.ideas.map(h => <li className="cv-idea" id={'cv-idea-' + h.id} key={h.id}>
      <p className="audit-line cv-tags"><b>{h.id}</b> <Tags kinds={['ours']} lang={L} strings={s} /> <Tx>{h.idea}</Tx></p>
      <p className={'cv-proved' + (h.tags.length > 0 ? ' audit-line cv-tags' : '')}><span className="gl-k"><Tx>{c.ideaCols.proved.toUpperCase()}</Tx></span>{h.tags.length > 0 && <Tags kinds={h.tags} lang={L} strings={s} />} <Tx>{h.proved}</Tx></p>
      <p className="cv-would"><span className="gl-k"><Tx>{c.ideaCols.would.toUpperCase()}</Tx></span><Tx>{h.would}</Tx></p>
      <p className="cv-refute"><span className="gl-k"><Tx>{c.ideaCols.refute.toUpperCase()}</Tx></span><Tx>{h.refute}</Tx></p></li>)}</ul>
    <p className="cv-lede"><Tx>{c.ideasFurther}</Tx></p>
    <h3 id="cv-gloss-h"><Tx>{c.glossH}</Tx></h3>
    <p className="cv-lede"><Tx>{c.glossLede}</Tx></p>
    <dl className="cv-gloss" id="cv-gloss">{c.gloss.map(([t, m, k]) => <React.Fragment key={t}><dt><Tx>{t}</Tx></dt><dd>{k ? <p className="audit-line cv-gloss-tags"><Tags kinds={k} lang={L} strings={s} /> <Tx>{m}</Tx></p> : <Tx>{m}</Tx>}</dd></React.Fragment>)}</dl></div>;
}
