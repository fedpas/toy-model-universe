// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// What each tab needs and what it takes from outside the bit rule (the "needs and inputs" strip, NeedsStrip.jsx). Key: tab id ('maxwell/<tab>' for the three Maxwell tabs).
//   needs:  tab ids (or the page words 'conventions', 'maxwell') to read first; StoryShell resolves them to links.
//   inputs: [kind, text]; kind is a key of KINDS; every text is a statement tagged `input` (INPUT_FLAGS), never `standard`, never `checked`.
//   yl:     the plain line for the Young Learner (no formula, no jargon: test_yl_ui.mjs lists).
//   none:   true on a tab that takes nothing from outside the bit rule.
// The input lines are also the rows INP-001 to INP-0NN of the claims table (claimsLocators_inp.json points at them in this order).
export const KINDS = {
  chart: 'chart and ∇', grade: 'grade of a field', representation: 'representation of a field', time: 'time direction', complex: 'complex structure', involution: 'involution',
  action: 'the action', postulate: 'postulated equation', solution: 'borrowed solution', data: 'imported data', convention: 'sign convention',
};
export const NEEDS = {
  // ---- page "maxwell" (Calibration 1), three tabs
  'maxwell/views': { needs: ['conventions', 'clock'], inputs: [
    ['action', 'The action of this step: ½⟨FF⟩₀ − ⟨AJ⟩₀ with F = ∇∧A. In Cl(1,3) its stationarity in A gives the vector part of ∇F = J (bd·phy·19); the rest holds since F = ∇∧A. The page checks ∇F = J term by term on the bit rule.'],
    ['postulate', 'The constitutive relation: in vacuum H = ⋆F, the Hodge dual of F; in a medium H = χ(F) with 36 components (20 principal, 15 skewon, 1 axion; bd·sol·14).'],
    ['chart', 'A flat chart with ∇ = Σ e^μ ∂_μ, in the orthonormal frame of the labels. The frame is gauge under Pin(p,q); rotors keep its orientation and time orientation, four values when p, q ≥ 1 (bd·tor·6, n ≤ 5).'],
    ['grade', 'F is a bivector (grade 2) and J a vector (grade 1): the grades are assigned, not found.'],
    ['convention', 'Which generators count as time, and the overall sign of J: see the Conventions page.'],
    ['convention', 'Units with c = ε₀ = μ₀ = 1: the speed of light and the two vacuum constants are set to one.']],
    yl: 'The rule for light comes from one recipe taken from books, and the boxes give the same answer. We chose the units, and which pieces are electric and which magnetic.' },
  'maxwell/charges': { needs: ['conventions'], inputs: [
    ['postulate', 'The Lorentz force as the grade-1 part of F u: a postulated force law, not derived from ∇F = J.'],
    ['data', 'Charge, mass, start position and start speed are chosen by hand in each of the six situations.'],
    ['time', 'The time direction γ₀ of a frame splits F into E and B; another γ₀ splits the same F differently. Only a time orientation is chosen: one orbit of the even versors, two of the rotors (bd·tor·1, n ≤ 6).'],
    ['solution', 'The Coulomb field of a point charge and the plane wave f(t − z) are put in as given fields; the page checks that they solve ∇F = J away from the charge (J = 0), it does not solve for them.']],
    yl: 'The push on a charge comes from a rule taken from books. The size of the charge, its weight and its first speed are ours to choose.' },
  'maxwell/ladders': { needs: ['clock', 'conventions'], inputs: [
    ['convention', 'Which sign is called time (the minority sign), and Cl(k,d) versus its mirror Cl(d,k), are conventions; only a Lorentzian split gives a hyperbolic wave operator (T18).'],
    ['time', 'Extra time generators: no time-domain realisation, as a causal medium has a Lorentzian principal symbol (bd·sol·16); at fixed frequency indefinite media give extraordinary waves a (2,2) or z-time Lorentzian dispersion (bd·sol·15).']],
    yl: 'Which direction counts as time is a choice of words. The boxes do not decide it.' },
  // ---- page "shapes"
  orth: { needs: [], inputs: [
    ['complex', 'The Fock reading pairs the 2n null vectors and picks a vacuum: a Witt split, not given by the labels. It is gauge under Pin(k,k); under Spin one bit remains, the family of the Lagrangian (bd·tor·3, k ≤ 4).'],
    ['data', 'The charge formulas Y = a/2 − b/3 and B − L = 1 − 2b/3 at n = 5 are Baez, Bokor and Boyle’s; the page checks the bit counts and the vanishing sums, not the formulas.']],
    yl: 'Pairing the two poles of each line into a switch is a choice we make; the boxes alone do not say which poles go together. Some counts for the particles come from a paper.' },
  demi: { needs: [], inputs: [
    ['data', 'The Furey box uses her 16-dimensional model as imported on the Furey page; the page checks the bijection and the axes only.']],
    yl: 'One box is about her model of particles; we take her model as she gives it and check only that the shapes match.' },
  gosset: { needs: ['orth', 'demi'], inputs: [
    ['data', 'The Cartan matrices of E6, E7 and E8 are imported; the Lie bracket of E8 is not built (it needs a cocycle choice).']],
    yl: 'The big shape comes from a table of numbers taken from books.' },
  // ---- the clock and the equations page
  clock: { needs: [], inputs: [
    ['convention', 'The clock c = p − q mod 8 assumes that p counts the generators that square to +1; the mirror convention gives −c.']],
    yl: 'The clock counts in the direction we picked. The mirror picture counts the other way round.' },
  comm: { needs: [], inputs: [], none: true, yl: 'Nothing is brought in from outside here.' },
  mirrors: { needs: ['comm'], inputs: [
    ['convention', 'The reflection formula x ↦ −a x a⁻¹ fixes one of two sign conventions for mirrors (Pin versus its twin).'],
    ['involution', 'The Dirac line uses the reversion ψ̃ in ψγ₀ψ̃ and ψψ̃, defined by the rule. Choosing it over Clifford conjugation is a gauge in Cl(1,3) (e_i ↦ e_iI), and in general only for n ≡ 0 mod 4, indefinite (bd·tor·7, n ≤ 8).'],
    ['time', 'A time orientation, given by the unit vector e_t (γ₀ in the Dirac line; one orbit of the even versors, two of the rotors, bd·tor·1): e_t enters the mirror x ↦ −e_t x e_t; γ₀ in ψγ₀ψ̃ is a reference (bd·geo·11).']],
    yl: 'A mirror can be written in two equally good ways. We picked one.' },
  dirac: { needs: ['conventions', 'clock', 'demi'], inputs: [
    ['action', 'The action of this step: ⟨∇ψIγ₃ψ̃⟩₀ − m⟨ψψ̃⟩₀; its stationarity gives ∇ψJ = mψγ₀ (bd·phy·18). Checked: the incidences, the determinant and the covariance of the equation.'],
    ['grade', 'ψ is an even multivector (8 components in Cl(1,3)): the grade of the field is assigned.'],
    ['time', 'A time orientation (one orbit of the even versors, two of the rotors; bd·tor·1). γ₀ and J on the right are a reference, observers act on the left (bd·geo·11); the positive involution γ₀ψ̃γ₀ is a datum (bd·phy·9, bd·tor·7).'],
    ['complex', 'J = γ₂γ₁ plays the part of the Dirac i: a complex structure chosen in the algebra, not given by it. For n ≥ 4 it is gauge, one rotor orbit; at n = 3 J and −J differ (bd·tor·2, n ≤ 6).'],
    ['convention', 'Cl(1,3) with γ₀² = +1 is used; Cl(3,1) reads the same system with the signs swapped.'],
    ['chart', 'A flat chart with the vector derivative ∇ = Σ e^μ ∂_μ: the derivative term of ∇ψJ comes from the action.']],
    yl: 'The electron’s rule follows from one recipe taken from books, and we check what follows from it. We choose which way time runs, and which turn plays the part of the number i.' },
  coupling: { needs: ['maxwell', 'dirac'], inputs: [
    ['action', 'The action of this step: ⟨∇ψIγ₃ψ̃ − mψψ̃ − eAψγ₀ψ̃⟩₀ + ½⟨FF⟩₀. Its stationarity gives both equations with one e (bd·phy·18, bd·phy·19); its coupling term is A·⟨X⟩₁, so no projection is chosen by hand (bd·phy·11).'],
    ['data', 'The coupling constant e: its size is a free constant, as in every theory.'],
    ['grade', 'The potential A is a vector (grade 1) and the current X a vector: assigned.'],
    ['time', 'The time orientation of the Dirac step (bd·tor·1): ψ ↦ ψL̃ moves its reference γ₀, J and keeps X = ψγ₀ψ̃ (bd·geo·11). Reversion or Clifford conjugation in X is a gauge in Cl(1,3); γ₀ψ̃γ₀ is a datum (bd·phy·9, bd·tor·7).'],
    ['complex', 'J = γ₂γ₁ of the Dirac step is the complex structure of ∇ψJ and of the charged form, which exists from n = 3: a datum there (J or −J), one rotor orbit for n = 4, 5, 6 (bd·tor·2).'],
    ['chart', 'The potential A is a vector-valued 1-form on a flat chart, and the replacement ∇ → ∇ − eA uses the same derivative.']],
    yl: 'How light pushes the electron and how the electron makes light follow from one recipe taken from books. How strong the push is, is a number we put in.' },
  ym: { needs: ['comm'], inputs: [
    ['action', 'The action of this step: the Yang–Mills action of so(m) with a source (pointer, source unread); its stationarity gives D^μF_{μν} = J_ν. Checked: the structure, the Bianchi identity, covariance and conservation.'],
    ['postulate', 'so(m) as the gauge algebra is one choice; the Standard Model algebra is not an so(m) for any m.'],
    ['data', 'The gauge coupling g is a free constant.'],
    ['chart', 'The covariant derivative D^μ = ∂^μ + gA^μ takes the potential A as a vector-valued 1-form on a flat chart.']],
    yl: 'The rule for forces with many charges follows from one recipe taken from books. Which family of turns carries the charge is our choice.' },
  matter: { needs: ['dirac', 'ym'], inputs: [
    ['action', 'The action of this step: the Dirac action of Ψ with ∂ replaced by D (pointer, source unread); its stationarity gives the matter equation, and its Noether current of each generator is j^a. Checked: covariance and conservation.'],
    ['grade', 'Ψ = Σ Ψ_{S,T} is even in the space-time part and carries an internal blade T of Cl(0,m); the generators act on T: assigned.'],
    ['representation', 'The representation of the gauge algebra on Ψ is a choice: left multiplication on Cl(0,m), the spinor-type one; tensor-type ones and chiral doublets are not drawn.'],
    ['data', 'The coupling κ in D^μF_{μν} = κ j_ν: its size is a free constant; the standard action ties it to g (pointer, source unread).'],
    ['chart', 'The covariant derivative D = ∂ + gA^aB_a acts on a flat chart: the chart and ∂ are those of the Dirac step.'],
    ['complex', 'J = γ₂γ₁ of the Dirac step, acting from the right, is the complex structure of the matter equation; the J-generator gives the coupling step. One rotor orbit for n = 4 to 6, a datum at n = 3 (bd·tor·2).'],
    ['time', 'The time orientation of the Dirac step (bd·tor·1): γ₀ (label 1) on the right is a reference (bd·geo·11) in the mass term and the currents, built with the reversion; the positive involution γ₀ψ̃γ₀ is a datum (bd·phy·9, bd·tor·7).']],
    yl: 'Matter that feels these forces follows from one recipe taken from books. How strongly it feels them is a number we put in.' },
  grav1: { needs: ['comm', 'conventions'], inputs: [
    ['action', 'The action of this step: the Einstein–Cartan action of e and ω (pointer, source unread), with R = dω + ¼[ω,ω] and T = de + ωe; its stationarity in ω gives T = 0 in vacuum, not solved here. Checked: Bianchi identities and counts.'],
    ['chart', 'A tetrad e on a chart: grade 1 is identified with tangent vectors by a choice of frame, gauge under Pin(1,n−1); rotors keep its orientation and time orientation, four values (bd·tor·6, n ≤ 5).'],
    ['grade', 'ω is a bivector-valued 1-form and e a vector-valued 1-form: assigned.'],
    ['convention', 'The frame algebra is Cl(1, n−1): one generator squares +1 (time) and the n−1 others square −1; the other convention swaps the two signs of the squares (see Conventions).']],
    yl: 'Gravity as bending space follows from one recipe taken from books. We pick the frame that measures the bending.' },
  grav2: { needs: ['grav1'], inputs: [
    ['action', 'The action of this step: Einstein–Cartan with a cosmological term, MacDowell–Mansouri form (pointer, source unread); varied in e it gives E_a = 0 in vacuum. Checked: D E_a = torsion terms; E_a at e = dx is the Einstein tensor.'],
    ['convention', 'The sign of the cosmological term is minus the sign of the square of the extra generator (k = −s); that rests on the signature convention. Invariant: an extra spatial generator gives de Sitter.'],
    ['data', 'The coupling κ of matter to the Einstein form is a free constant.']],
    yl: 'Einstein’s equation follows from one recipe taken from books, in a form our boxes can draw. How strongly matter bends space is a number we put in.' },
  projective: { needs: ['mirrors', 'grav2'], inputs: [
    ['convention', 'PGA is Cl(n,0,1) when space squares +1 (Dorst and De Keninck) and Cl(0,n,1) when space squares −1 (the convention used here).'],
    ['data', 'The three plane-based geometries and the extension to spheres are taken from Dorst and De Keninck’s tables.'],
    ['data', 'Conformal invariance of Maxwell, Yang–Mills and the massless Dirac equation is cited from the literature and not rebuilt; the algebra itself needs no postulated equation.']],
    yl: 'Flat, round and saddle-shaped geometries come from one extra direction, as in a paper we read. Which sign each gets is a matter of convention.' },
  gauge: { needs: ['grav1', 'grav2', 'projective', 'conventions'], inputs: [
    ['solution', 'The Schwarzschild metric (a point mass) is borrowed (Lasenby, Doran and Gull): the page rebuilds it as a shear of the frame and checks it; it does not solve for it.'],
    ['chart', 'A frame: the shear h̄ and the static time direction e_t are chosen; the same metric has other frames. At a point a frame is gauge under Pin(1,3), up to its orientation and time orientation (bd·tor·6, bd·tor·1).'],
    ['postulate', 'The field equations of the theory are not used: the metric is put in, not derived.'],
    ['convention', 'Time squares +1; with the other convention the two signs of the squares swap and the 0 does not (see Conventions).']],
    yl: 'The shape of space around a heavy ball is taken from books. We rebuild it from simple bends of the frame and check that the pieces fit.' },
  nullsurf: { needs: ['gauge', 'projective'], inputs: [
    ['solution', 'The metrics (Schwarzschild, Kerr, the Ellis wormhole) are borrowed; the page rebuilds the null-surface statements on them and checks them.'],
    ['chart', 'A static Killing vector ξ and the covector n = dx: the null normal exists once the chart and the time direction are chosen.'],
    ['data', 'The four claims of the paper (Hsu, Barker, Hobson and Lasenby) are taken as given; its Eq. (12) is not rebuilt.']],
    yl: 'Surfaces of light that stand still are studied on shapes of space taken from books.' },
  forque: { needs: ['mirrors', 'projective'], inputs: [
    ['postulate', 'The Newton–Euler equations Ṗ = F, Ḃ = I⁻¹[B × I[B] + F], Ṁ = −½MB of Dorst and De Keninck are taken as given: 27 of 41 rows agree exactly, 9 after a small adjustment.'],
    ['data', 'The inertia map I and the forces are the paper’s examples.'],
    ['convention', 'With space squaring −1 the kinetic term changes sign (mainly-minus mechanics): a convention of the metric.'],
    ['chart', 'The time derivative along the motor path: the only chart is the time parameter t.'],
    ['involution', 'The motor is normalised by M M̃ = 1 with the reversion; the rule defines the reversion, and using it rather than Clifford conjugation is a choice.']],
    yl: 'Push and spin as one line comes from a paper we read. The weights and pushes in the examples are the paper’s.' },
  spin: { needs: ['dirac', 'clock'], inputs: [
    ['postulate', 'The pointor and spinor equations are the authors’ and the lecturer’s (Roelfs, Eelbode, De Keninck; Eelbode’s lecture): 22 of 30 rows agree exactly.'],
    ['complex', 'Which kind of i plays the complex unit (the central I, a bivector J, or the lecture’s B + i) is a choice of complex structure. In Cl(1,3) any unit spatial bivector serves as J: one rotor orbit (bd·tor·2).'],
    ['grade', 'The pointor ψ lives in the even subalgebra; the chirality map ψ ↦ IψJ uses the chosen J.'],
    ['chart', 'The Dirac step is reused with its chart and ∇: its free plane waves solve the Dirac equation of that step.'],
    ['time', 'The time orientation of the Dirac step (bd·tor·1) fixes the energy sign of a plane wave (β = 0 or π; bd·geo·11) and the positive involution γ₀ψ̃γ₀ (T15), a datum: the reversion in ψψ̃ is indefinite (bd·phy·9, bd·tor·7).']],
    yl: 'Things that turn twice are described as in a paper and a lecture. Which turn plays the part of the number i is our choice.' },
  spring: { needs: ['comm', 'spin'], inputs: [
    ['postulate', 'Hooke’s law x″ = −Lx on the cube’s graph, with one scalar displacement per vertex, is a postulated force law.'],
    ['convention', 'The sign s of the generator (−1, 0, +1) is a parameter you choose. The matrix D = Σ e_i is built from the generators and checked (D² = n·I); that it is the signed matrix of Huang (2019) is standard.'],
    ['involution', 'The rotor sandwich R s R̃ uses the reversion; using it rather than Clifford conjugation is a choice, a datum: in Cl(2,0) and Cl(1,1) the two are not isomorphic; the dagger is the reversion in Cl(2,0) only (bd·tor·7).'],
    ['chart', 'The time derivative along the flow: the only chart is the time parameter t.']],
    yl: 'A spring on the cube follows the law of springs from books. We choose the weights and the stiffness.' },
  rigid: { needs: ['forque', 'spring'], inputs: [
    ['postulate', 'Euler’s equation, Hooke’s and Newton’s laws and Kepler’s problem are taken as given; the identities G1–G5 are checked exactly.'],
    ['data', 'The planets’ masses and positions are the example’s own printed table (JPL was not reached): six bodies, checked for plausibility only.'],
    ['chart', 'The time derivative along the motor path: the only chart is the time parameter t (the engine integrates numerically in t).'],
    ['involution', 'The versor condition M M̃ = 1 uses the reversion; using it rather than Clifford conjugation is a choice (the rule only defines it).']],
    yl: 'A solid body moves by the laws of books. The weights of the planets in the example are numbers copied from the paper.' },
  groups: { needs: ['clock'], inputs: [
    ['data', 'The uniqueness of the Golay code, the simplicity of the large groups, the orders of Co₁ and the Monster, and Monster ⊃ 2^{1+24}.Co₁ are quoted from the literature, not rebuilt.']],
    yl: 'Counting the ways to shuffle uses numbers that mathematicians have worked out; we quote the biggest ones.' },
  // ---- the lens chapters
  category: { needs: ['clock'], inputs: [
    ['involution', 'States use the dagger involution (e_i† = ε_i e_i, null generators fixed; T15) rather than the reversion or Clifford conjugation: a datum, as the dagger is the reversion only if q = 0, conjugation only if p = 0 (bd·tor·7, r = 0).'],
    ['data', 'The classical theorems that T4, T6 and T8 reduce to (Wall, Hurwitz, de la Peña) are recalled from the literature, not rebuilt.']],
    yl: 'A few famous results are quoted, not rebuilt.' },
  baez: { needs: ['groups'], inputs: [
    ['data', 'Baez’s octonion table and his embeddings of generations (E7, the Albert algebra) are imported; the multiplicities (a, b) are recalled from Loos.'],
    ['convention', 'The colour labels 3 and 3̄ depend on a sign convention for the weights.'],
    ['data', 'The periodic-table section fills subshells in the Madelung order (n + l, then n), a textbook rule taken as given and an approximation for real atoms; the page counts the rows it closes.']],
    yl: 'The seven papers are read as written, and so is the order in which electrons fill. Their names for the colours are a choice of words.' },
  schuller: { needs: ['maxwell', 'dirac', 'grav2'], inputs: [
    ['postulate', 'The matter action (Schuller’s stone 1) and his closure construction are imported; the page rebuilds the symbol and hyperbolicity (T18(f)), not the dynamics.'],
    ['convention', 'One Lorentzian class in two conventions, P ↔ −P: the quantum notes print Cl(3,1), the Atlas Cl(1,3).']],
    yl: 'The lectures are followed from the rule to how things move. We check the first steps and not the last.' },
  // ---- the Furey page, three tabs
  dictionary: { needs: ['clock'], inputs: [
    ['data', 'Furey’s octonion table and her nested flag ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 in 𝕍 (real dimension 16) are imported: the octonion sign is not the rule’s cocycle.'],
    ['complex', 'The complex structure ω = L_{e₇} is imported. As a blade of Cl(0,8) it is gauge: one of the 56 even blades of square −1, one orbit of the label automorphisms (bd·tor·5).']],
    yl: 'The model of particles is her own idea. We rebuild it from her table and count what fits.' },
  earlier: { needs: ['dictionary'], inputs: [
    ['data', 'Her octonion table and the constructions of her papers (Roadmap I–III, Trialities, the 2026 paper) are taken as given; the page rebuilds the algebra from the octonion units and recomputes the quoted numbers.']],
    yl: 'Her older papers are her own ideas. We rebuild them from her table of numbers and count again what she quotes.' },
  findings: { needs: ['dictionary'], inputs: [
    ['data', 'The partition of the 16 axes into blocks is input: the 616 of 18 480 quadruple sets that diagonalise its projectors are the bases of one Lagrangian, a gauge; given it and ω, the partition is a datum, 11 orbits (bd·tor·5).'],
    ['complex', 'The complex structure ω = L_{e₇} of the Dictionary tab is hers; the page builds 𝕍 with it and computes the blocks. At label level ω is gauge, also with her torus fixed (bd·tor·5).'],
    ['data', 'The formulas of Y and Q as sums of projectors (her eqs. 44, 45) are hers; the page computes their traces and their values on the blocks.']],
    yl: 'Which pieces go into which block is a choice she makes; the rule alone does not decide it. Her formulas for the charges are used as she gives them.' },
  threegen: { needs: ['dictionary', 'findings'], inputs: [
    ['data', 'The Standard Model labels on the edges of her Fig. 1 are imported; that one complete set fits is computed.']],
    yl: 'The labels of the particles are hers. That only one family fits in the board is something we counted.' },
  help: { needs: ['threegen'], inputs: [
    ['data', 'The labels of the 20 cells of her Fig. 1 are hers; the table to download repeats them with the irreps and charges computed on the Three generations tab.']],
    yl: 'The labels of the particles in her figure are hers. We list what we counted and what stays open.' },
};
export const INPUT_FLAGS = ['input'];

// The words of the strip (English in both languages) and of its line in the legend. `words` names a page when a need is a page and not a tab; `pages` is the page word in front of the label of a link to a tab.
export const NEEDS_COPY = {
  aria: 'Needs and inputs', script: 'Script', needs: 'Needs', inputs: 'Inputs', none: 'None beyond the bit rule.', nothing: 'Nothing outside this page.',
  words: { conventions: 'Conventions', maxwell: 'Maxwell' },
  pages: { conventions: 'Conventions', maxwell: 'Maxwell', shapes: 'Shapes', equations: 'Equations', furey: 'Furey', lenses: 'Lenses' },   // the page that a link to a tab names first ("Shapes · 2 · The demicube"): step numbers repeat from page to page
  help: 'The strip under the tabs says what a tab needs (read those first) and what it takes from outside the algebra: the action (a field equation is the condition that the action be stationary), a postulated equation, a chart and derivative, the grade or the representation a field lives in, a time direction, a complex structure, an involution (the reversion used for norms and currents), a borrowed solution, imported data or a sign convention. Each such line is an input.',
  yl: { aria: 'Needs and what we brought in', script: 'The check', needs: 'Read first', words: { conventions: 'How we name things', maxwell: 'Light' }, pages: { conventions: 'Our words', maxwell: 'Light', shapes: 'Shapes', equations: 'Equations', furey: 'Furey', lenses: 'Lenses' },
    help: 'Under the tabs, a short bar says what to read first and what we had to bring in from outside the boxes. Some pages bring in one recipe from which the equations of motion follow; we take the recipe from books and check what follows from it.' },
};

// The label of a link to a tab names its page first ("Shapes · 2 · The demicube", "Equations · 2 · Commutators"), because the step numbers repeat from page to page.
// `t` is what the router resolves a need to ({ page, sub, label }), `w` the need, `pages` the page words of NEEDS_COPY (plain ones for the Young Learner).
// A need that is a page ('maxwell') keeps the name of the page; a tab whose label is the page word itself ('Conventions') is not named twice.
export const needLabel = (t, w, pages) => { const p = t.sub === w ? pages[t.page] : null; return p && t.label !== p ? p + ' · ' + t.label : t.label; };
