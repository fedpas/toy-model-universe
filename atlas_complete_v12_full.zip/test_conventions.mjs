// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Conventions tab of the Conventions page (conventionsCopy.js, ConventionsSection.jsx).
//  1. the data: 18 rows, each with one or more of the five flags; a row tagged checked names a check that exists (an id of the core table, a script of the package);
//     every file a row says it is used in exists; the 11 ideas H1 to H11; the glossary has each of the 14 terms of the vocabulary list (and calibration) once;
//     the Young Learner version is two plain sentences
//  2. the page, in a browser, is test_conventions_ui.mjs (the browser group of run_tests.sh)
// Run: node test_conventions.mjs
import fs from 'node:fs';
import path from 'node:path';
import { PKG } from './paths.mjs';
import { CONV, CORE_IDS, ROWS, IDEAS, GLOSSARY, PAGE, PAGE_YL } from './conventionsCopy.js';
import { stepNo } from './steps.js';
let n = 0, bad = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const FLAGS = ['standard', 'checked', 'ours', 'open', 'input'];

// ---- 1. the data
ok(CONV.en === CONV.it, 'one English text serves both language slots (v11)');
ok(ROWS.length === 18 && ROWS.every((r, i) => r.n === i + 1), 'eighteen rows, numbered 1 to 18');
ok(ROWS.every(r => r.tags.length > 0 && r.tags.every(t => FLAGS.includes(t))), 'every row carries at least one of the five flags, and only those');
ok(ROWS.every(r => r.title && r.text && r.note), 'every row has a title, a statement and a note on its status');
// every file a row says it is used in (a name that ends in .js, .jsx or .py) is in the package
const all = []; const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (e.name === 'node_modules' || e.name === 'dist' || e.name.startsWith('.')) continue; const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else all.push(e.name); } };
walk(PKG);
const have = new Set(all);
const files = r => [...new Set([...(r.where || []), ...(r.scripts || [])].join(' ').match(/[A-Za-z0-9_]+\.(?:jsx|js|py)\b/g) || [])];
for (const r of ROWS) for (const f of files(r)) ok(have.has(f), `row ${r.n}: the file ${f} exists`);
// the checks: ids of the core table (read from selfcheck/core.json when it is in the package, else from the fixed list B1..B17 in conventionsCopy.js), scripts that exist
const coreFile = path.join(PKG, 'selfcheck', 'core.json');
let known = new Set(CORE_IDS), source = 'the fixed list B1 to B17';
if (fs.existsSync(coreFile)) { known = new Set(JSON.parse(fs.readFileSync(coreFile, 'utf8')).rows.map(x => x.id)); source = 'selfcheck/core.json'; }
for (const r of ROWS) for (const id of r.ids || []) ok(known.has(id), `row ${r.n}: ${id} is an id of ${source}`);
for (const r of ROWS) for (const s of r.scripts || []) ok(have.has(s), `row ${r.n}: the script ${s} exists`);
// X3: a row that carries the flag checked names at least one check (a core id or a script of the package)
for (const r of ROWS.filter(r => r.tags.includes('checked'))) ok((r.ids || []).length + (r.scripts || []).length > 0 || r.n === 2, `row ${r.n}: a checked row names a check`);
ok(ROWS[1].tags.includes('checked') && (ROWS[1].scripts || []).includes('labels_check.py'), 'row 2: the checked algebra Cl(3,1) names labels_check.py');
// the ids that the statements and notes quote in their text exist too
for (const r of ROWS) for (const id of (r.text + ' ' + r.note).match(/core·B\d+[a-z]?/g) || []) ok(known.has(id), `row ${r.n}: the text quotes ${id}, which exists`);
for (const t of [...CONV.en.lede, ...CONV.en.ledeM, ...IDEAS.flatMap(h => [h.proved, h.would, h.refute]), ...GLOSSARY.map(g => g[1])]) for (const id of t.match(/core·B\d+[a-z]?/g) || []) ok(known.has(id), `${id} exists (quoted in a text of the tab)`);
// the three conventions and the mirror state what the vocabulary says
ok(/Cl\(3,1\)/.test(ROWS[1].text) && /Cl\(1,3\)/.test(ROWS[2].text) && /Cl\(n,0,1\)/.test(ROWS[3].text), 'rows 2 to 4 are the conventions S, T and D (Cl(3,1), Cl(1,3), Cl(n,0,1))');
ok(/Q to Q \+ π/.test(ROWS[6].text) && /w to −w/.test(ROWS[6].text) && /nothing runs backwards/.test(ROWS[6].text), 'row 7 is the mirror: Q to Q + π, w to −w, nothing runs backwards');
ok(/exactly when its grade is even/.test(ROWS[7].text), 'row 8: a blade keeps its square under the mirror exactly when its grade is even');
// the present statements of the rows: the two namings are in general two algebras; doubling is stated for r = 0; the states statement is for hermitian functionals; the +1 PGA label is standard with its own script
ok(/chooses between Cl\(p,q\) and Cl\(q,p\)/.test(CONV.en.lede[1]) && /in general different algebras \(Cl\(3,1\) = M₄\(ℝ\), Cl\(1,3\) = M₂\(ℍ\)\)/.test(CONV.en.lede[1]) && /have isomorphic even parts and the same bivector squares/.test(CONV.en.lede[1]) && !/two namings of one picture|renames an algebra/.test(CONV.en.lede[1]), 'the lede says that Cl(p,q) and Cl(q,p) are in general different algebras with isomorphic even parts and the same bivector squares');
ok(/^A non-degenerate Clifford algebra A = Cl\(p,q\) \(r = 0\)/.test(ROWS[15].text) && /For r ≥ 1 the two actions of a null generator multiply to 0, so they generate only a proper subalgebra of End\(A\)/.test(ROWS[15].text) && /non-degenerate signature \(r = 0\) with n ≤ 4/.test(ROWS[15].note), 'row 16 (doubling) has its domain: r = 0, and says what happens for r ≥ 1');
ok(/Every positive hermitian functional vanishes/.test(ROWS[13].text) && /the word hermitian cannot be dropped/.test(ROWS[13].text), 'row 14: the functionals of the states statement are hermitian');
ok(/with n ≤ 6, with r = 0, 1, 2 null generators/.test(ROWS[8].note) && ROWS[8].ids.includes('core·B5b') && /core·B5b also with r = 1, 2 null generators/.test(ROWS[7].note), 'rows 8 and 9 cite B5b with its range: n ≤ 6 and r = 0, 1, 2');
ok(JSON.stringify(ROWS[10].tags) === '["checked","standard"]' && ROWS[10].scripts.includes('projective_selfcheck.py') && ROWS[10].scripts.includes('pgadyn_selfcheck.py') && /pointer, the source is not read here/.test(ROWS[10].note) && /Cl\(n,0,1\) for a \+1 base/.test(ROWS[10].note), 'row 11: the −1 and Lorentz bases are checked by projective_selfcheck.py, the +1 label is standard (pointer, source unread) with pgadyn_selfcheck.py');
{ const r5 = ROWS[4].text; for (const [id, g] of [['spin', 'eq'], ['comm', 'eq'], ['matter', 'eq'], ['spring', 'eq']]) ok(r5.includes(`step ${stepNo(g, id)})`) || r5.includes(`step ${stepNo(g, id)} `) || r5.includes(`(${stepNo(g, id)})`), `row 5 names the ${id} step (step ${stepNo(g, id)})`);
  ok(/spin step \(step \d+\) uses T for its spacetime algebra Cl\(1,3\)/.test(r5) && /state nothing that depends on the convention/.test(r5), 'row 5: the spin step uses T, the others state nothing that depends on the convention'); }
ok(!/lattice address/.test(ROWS[0].text + ROWS[0].where.join(' ')) && /Its place in the lattice of cells is \[p \+ q, p − q\]/.test(ROWS[0].text) && /“lattice address” \[p \+ q, p − q\] of a cell is something else/.test(GLOSSARY[0][1]), 'row 1 says the place in the lattice, and the glossary separates the lattice address from the address of a blade');
ok(/Three uses\./.test(GLOSSARY.find(g => g[0] === 'base / fibre')[1]) && /Three different meanings/.test(IDEAS[6].proved) && !/Used only for/.test(GLOSSARY.find(g => g[0] === 'base / fibre')[1]), 'the glossary lists the three uses of base / fibre that idea H7 counts');
ok(!/older|first assumed|previously/i.test(CONV.en.glossLede) && /uses a different word for the same thing/.test(CONV.en.glossLede), 'the glossary lede names no older word');
ok(!/proofs file/.test(IDEAS[7].proved) && /the Atlas page marks every role name as a reading we propose, not a result/.test(IDEAS[7].proved), 'H8: what is proved is stated as the page states it');
ok(/at most one spare null/.test(IDEAS[0].proved) && /Cl\(m,m\) for k = 2m and Cl\(m−1,m−1,1\) for k = 2m − 1/.test(IDEAS[0].proved) && /not a theorem/.test(IDEAS[0].proved), 'H1: the ladder of T7 has at most one spare null; more are the construction of ideas A and B');
ok(!ROWS[9].where.includes('the projective step') && ROWS[9].where.filter(w => /projectiveCopy/.test(w)).length === 1, 'row 10 lists the projective chapter once');
for (const l of ['en', 'it']) { ok(/25 cards/.test(PAGE_YL[l].before) && !/25 boxes|25 cells/.test(PAGE_YL[l].before), `${l}: the Young Learner frame says 25 cards`);
  ok(/core checks, labels_check\.py and the scripts named in each row/.test(PAGE[l].tags[0][1]) && /pgadyn_selfcheck\.py, projective_selfcheck\.py/.test(CONV[l].glance.tags[0][1]), `${l}: the frame and the glance name the scripts the checked rows stand on`); }
// the cell and the clock with their scope (r = 0: the triple; r >= 1: the quadruple and the clock of the quotient), the frame, the signature, the reversion, Pin, the two ends of a chain
ok(/^Without null generators \(r = 0\) the cell is the triple \(V, Q, π\)/.test(CONV.en.ledeM[0]) && /With r ≥ 1 null generators the cell is \(V, Q, π, N\), N the span of the null bits, and its clock is the Brown invariant of its semisimple quotient Cl\(p,q\) \(row 14\)/.test(CONV.en.ledeM[0]), 'the formal introduction scopes the triple to r = 0 and names the quadruple and the clock of the quotient for r ≥ 1');
{ const r13 = ROWS[12], r14 = ROWS[13], r12 = ROWS[11], r7 = ROWS[6];
  ok(/^For r = 0 the cell is the triple \(V, Q, π\)/.test(r13.text) && /the triples of two frames are isometric, so the isometry class is frame-free; the triple itself is attached to the frame/.test(r13.text) && !/Different frames give the same triple, so the triple is frame-free/.test(r13.text), 'row 13: the isometry class is frame-free, the triple is attached to the frame');
  ok(/Cl\(1,4\) and Cl\(5,0\) share it and only the first is hyperbolic/.test(r13.text) && /it decides hyperbolicity only for n = 2, 3, 4, 6/.test(r13.text) && /two cells with the same triple have isomorphic reversions exactly when they are equal or both indefinite \(n ≤ 10\)/.test(r13.text), 'row 13: the triple does not fix the signature, and it forgets the reversion by one datum (definite or indefinite)');
  ok(JSON.stringify(r13.tags) === '["checked","standard"]' && ['core·B18', 'core·B19', 'core·B17', 'core·B6c'].every(i => r13.ids.includes(i)) && /Wood 1993, §5; read/.test(r13.note) && /checked for n ≤ 12/.test(r13.note) && /bd·rev·1–3/.test(r13.note), 'row 13: standard for every n (Wood, read), checked for n ≤ 12 (core·B18), the reversion checked for n ≤ 10');
  ok(/With r ≥ 1 the cell is \(V, Q, π, N\), N the span of the null bits/.test(r14.text) && /two such cells are isomorphic exactly when n, r and p − q mod 8 agree/.test(r14.text) && /The clock of Cl\(p,q,r\) is the Brown invariant of its semisimple quotient Cl\(p,q\), which is that of its mother cell Cl\(p\+r, q\+r\)/.test(r14.text) && /the value 2 on a null bit makes the Gauss sum 0/.test(r14.text) && /π \+ 2Q is not a Z_\{4\}-form when r ≥ 1/.test(r14.text), 'row 14: the quadruple, the clock of the quotient and of the mother cell, weight 0 forced, π + 2Q not a Z4-form for r ≥ 1');
  ok(/Over its super-centre Λ\(ℝ\^\{r\}\) the cell is graded Azumaya, and every graded algebra over Λ\(ℝ\^\{r\}\) that is free with fibre Cl\(p,q\) is Cl\(p,q,r\)/.test(r14.text) && JSON.stringify(r14.tags) === '["checked","ours"]' && r14.ids.includes('core·B3') && /bd·hh·2, bd·hh·3/.test(r14.note) && /separability of Cl\(p,q\), a pointer, source unread/.test(r14.note) && /reading r as the base ring and the clock as the only class over it: ours/.test(r14.note), 'row 14: graded Azumaya over the super-centre (checked in its range), the step for every (p, q, r) a pointer, the reading of r as the base ring ours');
  ok(/the mirror reverses that structure/.test(r12.text) && /swaps Pin⁺ ⊂ Cl\(n,0\) with Pin⁻ ⊂ Cl\(0,n\)/.test(r12.text) && /Pin⁺ and Pin⁻ as symmetry classes of neutral fermions are not treated/.test(r12.text) && JSON.stringify(r12.tags) === '["checked","standard","open"]' && !/The Atlas does not treat this/.test(r12.text), 'row 12: the mirror reverses the Pin⁻ structure and swaps Pin⁺ and Pin⁻; Pin± for neutral fermions stays open');
  ok(/For systems that share one time reversal the difference of their clocks does not depend on the naming: the two ends of one model chain of Majorana modes carry c and −c/.test(r7.text) && /bd·sol·8/.test(r7.note) && /bd·fk·3/.test(r7.note), 'row 7: relative clocks of systems that share one time reversal (bd·sol·8, bd·fk·3)'); }
{ const G = Object.fromEntries(GLOSSARY);
  ok(/It generates the radical, which is spanned by the addresses with a null bit/.test(G['label 0']) && /the base ring over which the cell is graded Azumaya/.test(G['label 0']), 'glossary label 0: it generates the radical; the null generators span the base ring');
  ok(/it fixes the cell when r = 0 \(row 13\); with null generators the cell also needs N/.test(G.form) && /with null generators, that of the semisimple quotient Cl\(p,q\) \(row 14\)/.test(G['clock value']), 'glossary form and clock value: the scope r = 0 and r ≥ 1');
  ok(/One element can be \(1\) and \(2\) in two algebras/.test(G.null), 'glossary null: one element can be a null generator and a paired null in two algebras'); }
ok(/core·B18/.test(IDEAS[2].proved) && /core·B19/.test(IDEAS[2].proved) && /bd·rev·3, n ≤ 10/.test(IDEAS[2].refute) && !/None known/.test(IDEAS[2].refute), 'H3: the triple is the graded algebra; shown that it forgets the signature and the reversion');
ok(/^One element, two algebras/.test(IDEAS[4].proved) && /bd·str·21, bd·xph·3/.test(IDEAS[4].proved) && !/two objects, not one/.test(IDEAS[4].refute), 'H5: one element in two algebras');
// row 15: which choices are a gauge (one orbit of a group the algebra supplies) and which carry a datum, with the involution case of Cl(1,3)
ok(/some of these choices carry no information, being one orbit of a group the algebra supplies \(a gauge\): the frame and the Witt split under Pin, J for n ≥ 4/.test(ROWS[14].text) && /the time direction its time orientation, J at n = 3 the orientation of its plane, the Witt split under Spin one bit, the frame under rotors its orientations/.test(ROWS[14].text) && /the reversion and Clifford conjugation are one gauge in the indefinite cells with n ≡ 0 mod 4, as in Cl\(1,3\)/.test(ROWS[14].text) && JSON.stringify([...ROWS[14].tags].sort()) === '["checked","input"]' && ROWS[14].scripts.includes('tor_orbits.py') && ['bd·tor·1', 'bd·tor·2', 'bd·tor·3', 'bd·tor·4', 'bd·tor·5', 'bd·tor·6', 'bd·tor·7'].every(i => ROWS[14].note.includes(i)), 'row 15: gauge or datum for each choice of structure, checked by tor_orbits.py (bd·tor·1 to bd·tor·7)');
// the ideas
ok(IDEAS.length === 11 && IDEAS.every((h, i) => h.id === 'H' + (i + 1)), 'eleven ideas, H1 to H11');
ok(IDEAS.every(h => h.idea && h.proved && h.would && h.refute), 'every idea says what is proved, what would prove it and what would refute it');
ok(!IDEAS[3].tags.includes('checked') && /depend on n only/.test(IDEAS[3].proved), 'H4 is not tagged checked: the n-only fact is tested in test_story.mjs');
for (const h of IDEAS.filter(h => h.tags.includes('checked'))) ok(/core·B\d|check_T\d|cat_check|T\d+/.test(h.proved), `${h.id}: a checked line names its check`);
// the glossary
const TERMS = ['address', 'label −1, +1, 0', 'label 0', 'form', 'state label', 'mode', 'vertex', 'prime name', 'clock value', 'base / fibre', 'bit rule', 'mirror', 'null', 'trio'];
for (const t of [...TERMS, 'calibration']) ok(GLOSSARY.filter(g => g[0] === t).length === 1, `the glossary holds "${t}" once`);
ok(/Say “the square of a generator is −1, \+1 or 0”/.test(GLOSSARY[1][1]) && /not the empty address/.test(GLOSSARY[2][1]) && /Three objects share the word/.test(GLOSSARY[12][1]) && /Both sort a real square by its sign/.test(GLOSSARY[13][1]), 'the glossary says what label −1/+1/0 and label 0 are, the three kinds of null and the two trios');
// the Young Learner version: two plain sentences
const src = fs.readFileSync(path.join(PKG, 'test_yl_ui.mjs'), 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
ok(CONV.en.ledeY.length === 2 && CONV.en.ledeY.every(s => /^[A-Z][^.]*\.$/.test(s)), 'the Young Learner reads two sentences');
for (const s of [...CONV.en.ledeY, CONV.en.eyebrowY, CONV.en.wordsLinkY]) ok(!SYM.test(s) && !JAR.test(s), `plain words, no formula and no jargon: ${s}`);
ok(/choice of words/.test(CONV.en.ledeY[0]) && /top of the page/.test(CONV.en.ledeY[1]), 'the two sentences say that the words are a choice and that each page says which words it uses');
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL CONVENTIONS TESTS PASS: ${n} checks`);
process.exit(bad ? 1 : 0);
