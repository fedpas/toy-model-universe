// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The tree of knowledge: one node per part of the app. `go` = [page, anchor] is where the part lives; `script` is the file that checks it
// (selfcheck/ unless a path is given); `lens` and `th` are the lenses and threads the branch belongs to. The text of each node is in mapCopy.js.
// The branches follow the order of the pages. The clock, gauge-gravity and finite-groups steps are tabs of the Conventions, equations and lenses pages; each has its own branch (clock, gauge, groups) whose tags are read from its glance strip.
// A node carries the tag `input` when the needs strip of the tab it opens lists at least one input line (inputsData.js NEEDS; test_map.mjs compares both ways).
import { COPY as LABELS_COPY } from './labelsCopy.js';
import { NEEDS } from './inputsData.js';
import { MAP_NODES as CAT_NODES } from './categoryIntegration.js';
import { MAP_NODES as BAEZ_NODES } from './baezIntegration.js';
import { MAP_NODES as SCHULLER_NODES } from './schullerIntegration.js';
export const LENSES = ['clifford', 'cube', 'simplex', 'mirror', 'spinor', 'null', 'flow'];
export const MTHREADS = ['cube', 'mirror', 'i', 'eight', 'three', 'spring'];
const n = (id, go, script, tags, lens, th, kids = [], extra = {}) => ({ id, go, script, tags, lens, th, kids, ...extra });
// the tags of a numbered step that is a tab of a page with other content (clock, gauge, groups): the flags of its own glance strip (labelsCopy.js), in the order of the five kinds, and `input` when its needs strip lists an input line
const FIVE = ['checked', 'standard', 'ours', 'open', 'input'];
const stripTags = id => FIVE.filter(k => (k === 'input' ? NEEDS[id].inputs.length > 0 : LABELS_COPY.en.tabs[id].glance.tags.some(t => (Array.isArray(t[0]) ? t[0] : String(t[0]).split(/\s+/)).includes(k))));
// the chapters of the lenses page (steps 18 to 20, after the finite-groups step 17): each chapter's file lists its own nodes (the first is the tab, the rest are leaves inside it);
// the head of a chapter carries `input` when the strip of its tab (key = the head's id) lists an input line
const chapter = list => { const [head, ...rest] = list; return n(head.id, head.go, head.script, NEEDS[head.id] && NEEDS[head.id].inputs.length && !head.tags.includes('input') ? [...head.tags, 'input'] : head.tags, head.lens, head.th, rest.map(r => n(r.id, r.go, r.script, r.tags, r.lens, r.th, [], r.planned ? { planned: true } : {}))); };
export const TREE = [
  n('rule', ['rule', 'top'], 'genesis_audit_v3.js', ['standard', 'checked', 'ours'], ['clifford', 'cube', 'simplex'], ['cube', 'eight'], [
    n('atlas', ['atlas', null], 'genesis audit (JS), maxwell_selfcheck.py (type table)', ['checked', 'standard'], ['clifford', 'cube', 'simplex'], ['eight', 'cube'])]),
  n('conventions', ['conventions', 'cv-conventions'], 'core_check.py', ['checked', 'standard', 'ours', 'open'], ['clifford', 'mirror'], ['mirror'], [
    n('clock', ['conventions', 'cv-clock'], 'labels_check.py', stripTags('clock'), ['clifford', 'null'], ['eight', 'i'])]),
  n('maxwell', ['maxwell', 'maxwell'], 'maxwell_selfcheck.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube', 'simplex', 'flow'], ['cube', 'eight'], [
    n('views', ['maxwell', 'mx-views'], 'maxwell_selfcheck.py', ['checked', 'standard', 'input'], ['clifford', 'cube', 'simplex'], ['cube', 'eight']),
    n('charges', ['maxwell', 'mx-charges'], 'maxwell_selfcheck.py (charges block), test_charges.mjs', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'simplex', 'flow'], ['cube', 'eight']),
    n('ladders', ['maxwell', 'mx-ladders'], 'maxwell_selfcheck.py', ['checked', 'standard', 'input'], ['clifford', 'mirror'], ['eight', 'mirror'])]),
  n('shapes', ['shapes', 'sh-orth'], 'shapes_selfcheck.py, gosset_selfcheck.py', ['checked', 'standard', 'ours'], ['cube', 'simplex'], ['cube', 'eight', 'three'], [
    n('orth', ['shapes', 'sh-orth'], 'shapes_selfcheck.py', ['checked', 'standard', 'ours', 'input'], ['cube', 'simplex'], ['cube', 'three']),
    n('demi', ['shapes', 'sh-demi'], 'shapes_selfcheck.py', ['checked', 'standard', 'input'], ['cube', 'clifford'], ['cube']),
    n('gosset', ['shapes', 'sh-gosset'], 'gosset_selfcheck.py', ['checked', 'standard', 'open', 'input'], ['cube', 'mirror'], ['eight', 'mirror'])]),
  n('equations', ['equations', 'eq-comm'], 'one script per step', ['ours'], ['clifford'], [], [
    n('comm', ['equations', 'eq-comm'], 'equations_selfcheck.py', ['checked', 'standard', 'open'], ['clifford', 'cube'], ['cube']),
    n('mirrors', ['equations', 'eq-mirrors'], 'mirrors_selfcheck.py, mirrors_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['mirror', 'cube'], ['mirror', 'cube']),
    n('dirac', ['equations', 'eq-dirac'], 'equations_selfcheck.py, dirac_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube', 'spinor'], ['cube', 'i']),
    n('spin', ['equations', 'eq-spin'], 'spin_selfcheck.py', ['checked', 'standard', 'ours', 'open', 'input'], ['spinor', 'mirror', 'clifford', 'flow'], ['i', 'mirror', 'cube']),
    n('coupling', ['equations', 'eq-coupling'], 'coupling_selfcheck.py, coupling_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube'], ['i', 'cube']),
    n('ym', ['equations', 'eq-ym'], 'yangmills_selfcheck.py, yangmills_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube'], ['cube']),
    n('matter', ['equations', 'eq-matter'], 'matter_selfcheck.py, matter_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'spinor'], ['i', 'cube']),
    n('grav', ['equations', 'eq-grav1'], 'gravity_selfcheck.py, gravity_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube'], ['cube']),
    n('projective', ['equations', 'eq-projective'], 'projective_selfcheck.py, projective_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['null', 'mirror'], ['mirror', 'i']),
    n('gauge', ['equations', 'eq-gauge'], 'gtg_check.py', stripTags('gauge'), ['clifford', 'null', 'flow'], ['cube']),
    n('nullsurf', ['equations', 'eq-nullsurf'], 'null_selfcheck.py, test_null.mjs, test_null_ui.mjs', ['checked', 'standard', 'ours', 'open', 'input'], ['clifford', 'cube', 'simplex', 'mirror', 'null', 'flow'], ['cube', 'mirror'], [], {}),
    n('forque', ['equations', 'eq-forque'], 'forque_selfcheck.py, forque_matrix_check.py', ['checked', 'standard', 'ours', 'open', 'input'], ['flow', 'null', 'mirror'], ['mirror']),
    n('spring', ['equations', 'eq-spring'], 'spring_selfcheck.py', ['checked', 'standard', 'ours', 'open', 'input'], ['flow', 'cube', 'spinor', 'clifford'], ['spring', 'cube', 'i', 'mirror']),
    n('rigid', ['equations', 'eq-rigid'], 'pgadyn_selfcheck.py, matrixrep_check.py, bench_labels.mjs', ['checked', 'standard', 'ours', 'open', 'input'], ['flow', 'cube', 'null', 'mirror', 'clifford'], ['spring', 'cube', 'mirror', 'i'], [], {}),
    n('tally', ['equations', 'eq-tally'], 'test_equations.mjs, test_plain_steps.mjs', [], [], [])]),
  n('furey', ['furey', 'dictionary'], 'dictionary_selfcheck.py, furey_papers_check.py, threegen_selfcheck.py, run_all.py, family_test.py', ['checked', 'ours', 'open'], ['clifford', 'spinor'], ['three', 'i'], [
    n('dictionary', ['furey', 'dictionary'], 'dictionary_selfcheck.py', ['checked', 'input'], ['clifford', 'cube'], ['cube']),
    n('earlier', ['furey', 'earlier'], 'furey_papers_check.py', ['standard', 'checked', 'open', 'input'], ['clifford', 'spinor'], ['three', 'i']),
    n('findings', ['furey', 'findings'], 'run_all.py, family_test.py', ['checked', 'ours', 'open', 'input'], ['clifford', 'spinor'], ['three', 'i']),
    n('threegen', ['furey', 'tg-h'], 'furey_papers_check.py, threegen_selfcheck.py', ['checked', 'ours', 'open', 'input'], ['clifford', 'spinor'], ['three']),
    n('help', ['furey', 'help'], 'furey_papers_check.py, threegen_selfcheck.py', ['checked', 'standard', 'open', 'input'], ['clifford', 'spinor'], ['three'])]),
  n('lenses', ['lenses', 'ln-category'], 'groups_check.py, reports/cat_check.py, reports/baez_check.py, reports/fibre_check.py, reports/bridge_check.py, reports/bridge_check_qm.py', ['ours'], ['clifford'], [], [
    n('groups', ['lenses', 'ln-groups'], 'groups_check.py', stripTags('groups'), ['clifford', 'cube', 'mirror'], ['cube', 'eight']), chapter(CAT_NODES), chapter(BAEZ_NODES), chapter(SCHULLER_NODES)]),
  n('map', ['map', 'map-top'], 'test_map.mjs', [], [], []),
  n('ask', ['ask', null], 'lib/chatPersona.js, test_persona.mjs', ['open'], [], []),
  n('next', ['map', 'map-next'], '—', ['open'], ['flow'], ['spring'], [
    n('next_network', ['map', 'map-next'], 'bridges/sol_lattice_springs.py, spring_selfcheck.py, pgadyn_selfcheck.py (to extend)', ['standard', 'checked', 'open'], ['flow', 'cube', 'null', 'mirror'], ['spring', 'mirror'], [], { planned: true }),
    n('next_action', ['map', 'map-next'], '—', ['open'], ['flow', 'cube', 'clifford'], ['spring', 'i'], [], { planned: true }),
    n('next_read', ['map', 'map-research'], '—', ['open'], ['flow', 'mirror', 'null'], ['mirror'], [], { planned: true })]),
];
export const flat = (nodes = TREE) => nodes.flatMap(x => [x, ...flat(x.kids)]);
export const ALL_IDS = flat().map(x => x.id);

// the scripts of the project, counted from the files (test_map.mjs compares these lists with selfcheck/ and with what each file imports)
export const SCRIPTS = {
  stdlib: ['coupling', 'equations', 'forque', 'gosset', 'gravity', 'matter', 'maxwell', 'mirrors', 'null', 'pgadyn', 'projective', 'shapes', 'spin', 'spring', 'threegen', 'yangmills'].map(x => x + '_selfcheck.py').concat(['matrixrep_check.py', 'core_check.py']),
  numpy: ['coupling_matrix', 'dirac_matrix', 'forque_matrix', 'gravity_matrix', 'matter_matrix', 'mirrors_matrix', 'projective_matrix', 'yangmills_matrix'].map(x => x + '_check.py').concat(['dictionary_selfcheck.py', 'furey_papers_check.py']),
};

// the researchers' table: source, status of our reading of it (read / slides / partly / not read), and the tags
export const RESEARCH = [
  { id: 'forque', read: 'read', tags: ['checked', 'standard'] },
  { id: 'roelfs', read: 'read', tags: ['checked', 'ours'] },
  { id: 'eelbode', read: 'slides', tags: ['checked'] },
  { id: 'hestenes', read: 'standard', tags: ['standard'] },
  { id: 'doran', read: 'not', tags: ['open'] },
  { id: 'exp', read: 'not', tags: ['open'] },
  { id: 'visual', read: 'not', tags: ['open'] },
  { id: 'huang', read: 'standard', tags: ['standard', 'checked'] },
];
