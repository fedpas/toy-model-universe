// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Copy of step 20 of the lenses page: Schuller's chain (constructive gravity, his geometry and quantum lectures) against the bit rule.
// COPY.en / COPY.it: the formal voice (Physicist and Mathematician; the level decides what is open). COPY.yl.en / COPY.yl.it: the Young Learner
// (plain words, no formulas). A tagged statement is a line [kinds, text, checks]: kinds are the four statuses (checked, standard, ours, open),
// checks the namespaced ids of the checks that carry it (bridge· = selfcheck/reports/bridge_check.py, qm· = bridge_check_qm.py, fibre· = fibre_check.py,
// cat· = cat_check.py, scw· = lens_sch_check.py of the widgets, Thm T# = researchers_checks/check_T#.py). A finding is {id, title, lines}.
// The report's own ids (F1-F15, P1-P10, matrix rows L1-L20, C1-C12, M1-M11) are unique inside this chapter. Every line is resolved by
// claimsLocators_lns.json ({file, path}), so a path here is part of the claims table.

// ---------------------------------------------------------------- English, formal voice
const EN = {
  title: 'From how matter moves to the law of gravity: Schuller’s chain, and how far the bit rule follows',
  menuLbl: 'In this chapter',
  menu: { first: 'Overview', chain: 'His chain', table: 'One table', hyper: 'Hyperbolicity', area: 'Area metric', deform: 'Deformation algebra', fibre: 'Fibre and base', fock: 'Fock space', spin: 'SL(2,ℂ) and 3/4', total: 'Total spin', bands: 'Bands', stops: 'Where it stops', persp: 'Perspectives', quantum: 'Quantum lectures', notes: 'Notes on the texts', questions: 'Questions', honest: 'Honest list', bar: 'Honesty bar', thm: 'Theorems', scripts: 'Scripts', sources: 'Sources' },
  checksLbl: 'Checks',
  first: {
    lede: 'Schuller derives gravity from matter: action, then principal polynomial, then three conditions, then closure. The atlas follows the algebraic front exactly and stops where dynamics begins.',
    ledeM: 'Over ℝ, in finite dimension and in one chart: which links of Schuller’s chain are identities of the bit rule in Cl(p,q,r), each with its domain, its check and its status, and where the identities stop.',
    disclaimer: 'No action principle, no manifold: the closure equations are not rebuilt; the energy-distinguishing condition is a gap (row C12); the deformation algebra is a frozen flat 1+1 model; the quantum notes are a student transcript, not endorsed by the lecturer.',
    fullH: 'Full introduction',
    full: [
      'F. P. Schuller’s constructive-gravity programme (the closure paper with M. Düll, N. Stritzelberger and F. Wolz, and the review “Constructive Gravity”) and his two lecture courses meet the atlas at one place: a quadratic form on a vector space and the algebra it generates. He uses the form, the principal polynomial of the matter field equations, to decide which geometries can carry predictive matter, and then closes the hypersurface deformation algebra to obtain the gravitational dynamics. The atlas takes the form as given and builds every object from one sign rule, e_a e_b = s(a,b) e_{a⊕b}.',
      'The translation matrix of this chapter lays the objects of his documents against the 22 pages and steps of the atlas. A cell is E (the same algebraic identity, pointwise, in one chart, computed), S (the same structure, or a standard fact) or A (our reading). The honesty bar at the end counts the rows by their best grade; an E is not a statement about his theory.',
      'What we read: the geometry lectures in targeted chapters, the closure paper in parts, the review for its framing, the quantum notes in chapters 1, 12.4, 13–15, 16.2–16.3, 17.3, 17.5, 19.4, 20 and 21. Three scripts recompute every statement tagged checked: fibre_check.py (35 checks), bridge_check.py (77) and bridge_check_qm.py (51), 163 in all, Python 3 and numpy.',
    ],
    scope: 'Domain: the real algebras Cl(p,q,r) of the bit rule (p squares +1, q squares −1, r squares 0), finite dimension, one chart. Each statement names its range; “Thm T#” is a theorem of the page for researchers, with the status shown there.',
    statementsH: 'The statements, with their domains',
    statements: [
      { id: 'St1', title: 'One table for forms and Clifford algebras', lines: [
        ['checked standard', 'All squares 0 gives the exterior algebra Λ(ℝⁿ) = Cl(0,0,n); squares ±1 give Cl(p,q). The labels, the XOR and the reorder sign are the same; only the squares of the generators that two blades share enter the sign (computed for the all-null rule with n ≤ 6 and for Cl(p,q) with p, q ≤ 4 and n ≤ 6).', ['bridge·A1–A4']],
        ['checked standard', 'The complement a ↦ a ⊕ F (F = 1…1) is a Frobenius duality for every (p,q,r); multiplication by e_F is a metric Hodge star iff r = 0 (with a null generator e_F² = 0 and e_F· reaches only 2^{p+q} of the 2ⁿ labels).', ['bridge·A5', 'bridge·A6', 'Thm T3']]] },
      { id: 'St2', title: 'Hyperbolic iff Lorentzian', lines: [
        ['checked standard', 'Domain r = 0. A non-degenerate quadratic principal polynomial P(k) = Σ ε_i k_i² is hyperbolic iff its signature is (1, n−1) or (n−1, 1): found by direct search for every (k,d) with n = 2…7, proved in general (Thm T18(f)); the chapter’s own script recomputes the map of cells.', ['bridge·B1–B3', 'Thm T18', 'scw·P1']]] },
      { id: 'St3', title: 'The symbol determinant', lines: [
        ['checked standard', 'Domain: all (p,q,r). For P = Σ k_i e_i and a real module V of dimension N: (P − m)(P + m) = Q(k) − m², and det(P − m | V) = (m² − Q(k))^{N/2} except for (p,q) = (1,0) on an ungraded module and the trivial odd case p = q = 0 (Thm T16). A momentum along a null generator never enters the determinant. The atlas’s real 8×8 Dirac symbol has |det| = (p²)⁴, reduced polynomial p².', ['bridge·B4', 'Thm T16', 'scw·P1']],
        ['checked standard', 'The i of the printed (iγ·∂ − m) is the Fourier i of ∂ → ip, not an element of the algebra: in Cl(3,1) the real operator γ·∂ − m has the physical shell E² = |p|² + m².', ['fibre·G4b', 'qm·Q11b', 'Thm T16']]] },
      { id: 'St4', title: 'The spin Casimir', lines: [
        ['checked standard', 'Domain r = 0, indices raised: Σ_{a<b} (e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 in every signature. At n = 3, with the Hermitian S_i = e_i/2 of Cl(3,0) = M₂(ℂ), Ω = Σ S_i² = 3/4 = j(j+1) at j = ½.', ['bridge·E4', 'qm·Q8b', 'qm·Q8c']]] },
      { id: 'St5', title: 'Fock space is the label set', lines: [
        ['checked standard', 'Cl(m,m) ≅ End Λ(ℝ^m) = M_{2^m}(ℝ): the operators ε_k ± ι_k square to ±1 and anticommute, the label basis is the Fock basis, Pauli exclusion is ε_k² = 0, and the number operator returns the popcount (computed for m = 1, 2, 3; Thm T20 for every m).', ['qm·Q5–Q7', 'Thm T20']]] },
      { id: 'St6', title: 'Left and right: base and mirror', lines: [
        ['checked standard', 'Domain r = 0. For A = Cl(p,q) the left multiplications L_i and the twisted right multiplications R′_j x = (−1)^{|x|} x e_j anticommute and generate Cl(n,n) ≅ End(A), signature (ε | −ε); the plain right multiplications commute with the L_i and generate the commutant, A^{op} ≅ A. Computed for the 20 signatures with n ≤ 5; the clocks of A and of its mirror add to 0 mod 8 for every n ≤ 12.', ['fibre·G2a–d']]] },
      { id: 'St7', title: 'Keep the 8 fixed: the commutant', lines: [
        ['checked standard', 'With eight anticommuting γ’s of square −1 in M₁₆(ℝ), the commutant of Cl(0,k) has dimension 2^{8−k} (k = 0…8), the double commutant is Cl(0,k) again, and the two share centre and type. The type equality holds in any End(V) by the double-centraliser theorem; fixing the 8 adds only the dimensions and the explicit generators ω_kγ_j.', ['fibre·G3a–e']]] },
      { id: 'St8', title: 'The Floquet classes', lines: [
        ['checked standard', 'For M ∈ SL(2,ℝ), the unit multivectors of Cl(2,0), write M = g + X with g = ⟨M⟩₀: X² = g² − 1. Band iff X² < 0, gap iff X² > 0, band edge iff X² = 0 with X ≠ 0. M = ±I has X = 0 and bounded powers and is not an edge.', ['fibre·G5a–f', 'Thm T19', 'scw·P2']]] },
      { id: 'St9', title: 'The E₈ ladder (a link)', lines: [
        ['checked', 'The common-neighbour ladder 240 → 56 → 27 → 16 → 10 → 6 → 3 of the E₈ roots and the orthogonal root systems of 126, 72, 40, 20 and 8 roots are computed; their home is the Baez chapter. The script names the systems by root count and rank only: the Cartan matrices are not computed, and count and rank do not identify a root system in general (B₃ and C₃ both have 18 roots and rank 3).', ['fibre·G8a–c']]] },
    ],
  },
  chain: {
    h: 'His chain, our trail',
    intro: 'Seven stones, left to right: what a quadratic form allows (stones 1–3), then dynamics on a manifold (stones 4–7). Each stone carries the best grade of what the atlas has there, in the order of the report’s figure.',
    findings: [
      { id: 'F6', title: 'Matter first, gravity second: where the atlas starts', lines: [
        ['standard', 'His pipeline: the matter action gives a principal polynomial; three conditions (hyperbolic, dual hyperbolic, energy-distinguishing) filter it; observers and a foliation give the induced geometry; the closure of the hypersurface deformation algebra gives linear equations whose solution, for Klein–Gordon matter, is the Einstein–Hilbert action with two integration constants (κ, Λ).', []],
        ['checked', 'Grades along his chain: S, E, E, S, S, S, A. Stone 2 is exact (the real 8×8 Dirac symbol has |det| = (p²)⁴, reduced polynomial p²); stone 3 is exact for its first condition with quadratic P (Thm T18(f)), and its third condition has no counterpart (row C12).', ['bridge·B1–B5', 'Thm T18']],
        ['checked', 'The middle is a frozen caricature: in a flat 1+1 model the deformation algebra is Witt ⊗ A_ε (stone 6, structural; see below).', ['bridge·C1–C6']],
        ['ours', 'Reading the atlas as running his chain the other way is ours: its steps 9 and 10 start from the tetrad, the curvature and the Einstein form and check them, where he reaches the gravitational action by closure.', []],
        ['open', 'The back half, the closure equations and the action principle, is not rebuilt: row C7 stays an analogy and row C12 a gap.', []],
        ['ours', 'One reading connects the ends: the sign class of Λ read as −s·κ², with s the square of the extra generator of step 11. Ours; untested against his equations.', []]] },
    ],
  },
  table: {
    h: 'One table, three choices of square',
    intro: 'The widget below sets each generator’s square to −1, 0 or +1 and redraws the same multiplication table.',
    foldH: 'Finding F1 in full',
    catLink: 'The complement as a Frobenius duality: Category chapter',
    findings: [
      { id: 'F1', title: 'Wedge and Clifford share one multiplication table', lines: [
        ['checked standard', 'In the bit rule e_a e_b = s(a,b) e_{a⊕b} the sign is the reorder sign times the product of the squares of the generators the two blades share. All squares 0: the exterior algebra of his chapter 12, the sign of his Theorem 12.8 included. Squares ±1: Cl(p,q). Labels, XOR and reorder sign never change (the all-null rule with n ≤ 6; Cl(p,q) with p, q ≤ 4 and n ≤ 6, 17 976 products).', ['bridge·A1–A4']],
        ['checked standard', 'For a non-degenerate cell his Hodge star is multiplication by the pseudoscalar, which on labels is the complement a ↦ a ⊕ 1…1 (Cl(1,3), Cl(3,1), Cl(2,2), Cl(4,0)). With a null generator the top blade squares to 0 and multiplication by it reaches only 2^{p+q} of the 2ⁿ labels: it is not a Hodge star. The complement itself stays a Frobenius duality for every signature; its home is the Category chapter.', ['bridge·A5', 'bridge·A6', 'Thm T3']],
        ['standard', 'Not a new theorem: the Clifford algebra as a deformation of the exterior algebra is classical.', []],
        ['ours', 'The notes go from chapter 12 (forms) to chapter 15 (SL(2,ℂ)) without naming a Clifford algebra; one table could sit between them.', []]] },
    ],
  },
  hyper: {
    h: 'Which cells let waves propagate: hyperbolicity',
    intro: 'For the Physicist and the Mathematician a bench follows: pick a cell, and the browser computes the determinant of the symbol, the reduced polynomial and the verdict.',
    findings: [
      { id: 'F2', title: 'Hyperbolicity filters the cells', lines: [
        ['checked standard', 'Take the quadratic form of a cell Cl(k,d) as a principal polynomial P(k) = Σ ε_i k_i². A direction h with P(h) ≠ 0 is hyperbolic when q ↦ B(q,h)² − P(h)P(q) is non-negative for every q; this happens exactly for signature (1, n−1) or (n−1, 1). Elliptic cells (min(k,d) = 0) and ultrahyperbolic cells (min(k,d) ≥ 2) fail. Found by direct search for every (k,d) with n = 2…7; the Maxwell page’s wave-type table gives the same verdict for every cell. With r ≥ 1 null generators, Cl(k,d,r), a hyperbolic direction exists iff k = 1 or d = 1, and never a strict one: every null covector gives a double root (bd·geo·8, every r with n ≤ 6; bd·xck·5, the smallest case Cl(1,1,1)).', ['bridge·B1–B3', 'Thm T18', 'bd·geo·8', 'bd·xck·5']],
        ['standard', 'That the filter returns the Lorentzian signature is his own conclusion for the metric case.', []],
        ['checked standard', 'One Lorentzian class in two conventions, P ↔ −P: P cannot tell them apart, the algebras can, Cl(1,3) = M₂(ℍ) at clock 6 and Cl(3,1) = M₄(ℝ) at clock 2. Cl(2,2), at clock 0, is the first ultrahyperbolic cell.', ['bridge·B3', 'bridge·B3b', 'qm·Q11c']],
        ['checked standard', 'The Dirac field passes the same filter: the real 8×8 symbol on even ψ in Cl(1,3) has |det| = (p²)⁴ (12 rational momenta), so the reduced polynomial (his eqs. 22–24) is p²; two metrics G and H give the product (G·k)(H·k), his bimetric polynomial.', ['bridge·B4', 'bridge·B5']],
        ['ours', 'Drawing the filter as a map of cells is ours.', []]] },
    ],
  },
  area: {
    h: 'The area metric on the octahedron',
    octaLink: 'The octahedron of step 2',
    findings: [
      { id: 'F4', title: 'The area metric: 6 + 12 + 3 = 21', lines: [
        ['checked standard', 'General linear electrodynamics has an area metric G^{abcd} with 21 independent components when the constitutive law comes from a Lagrangian: the symmetric pairs of the six coordinate planes of a 4-space. A general local linear medium has 36, 20 principal, 15 skewon and 1 axion (Jancewicz, arXiv:0807.2989), and the axion part does not enter the wave operator (bd·sol·14). On the octahedron of step 2, with the six bivectors e₁₂ … e₃₄ as vertices: 6 vertices are a plane paired with itself, 12 edges two planes sharing one index, 3 antipodal pairs two disjoint planes, which commute; their cross terms are the three terms of F∧F.', ['bridge·D1', 'bridge·D2', 'bridge·F1', 'bd·sol·14']],
        ['checked', 'His density needs ε_{abcd}G^{abcd} = 8(G^{01,23} − G^{02,13} + G^{03,12}): only the three antipodal axes enter. The pure metric part 2η^{a[c}η^{d]b} contributes 0, so |ε·G| = 24 comes from the −ε^{abcd} term of his background. One cyclic (Bianchi) relation removes one combination: 21 − 1 = 20 = Ricci 10 + Weyl 10, the n²(n²−1)/12 of the atlas at n = 4.', ['bridge·D3', 'bridge·D6', 'bridge·D7', 'bridge·D8', 'bridge·F2']],
        ['checked standard', 'Under the Euclidean so(4) = su(2) ⊕ su(2) the 21 split as 5 + 5 + 9 + 1 + 1: the self-dual and anti-self-dual Weyl parts, the trace-free Ricci part, the scalar part and the ε part.', ['bridge·D5']],
        ['standard', 'His area metrics are Lorentzian. Under so(1,3) the self-dual and anti-self-dual parts are complex conjugates of each other, so the two 5s form one real 10 (the Weyl tensor as a complex 5-vector): recalled, not computed here.', []],
        ['ours', 'The split 6 + 12 + 3 is a picture in one frame of coordinate planes: a change of frame mixes the three classes, so it is not an invariant decomposition. Drawing it on the octahedron is ours.', []],
        ['open', 'Whether the eleven or more integration constants of his closure of general linear electrodynamics organise along 6 + 12 + 3, or along the invariant pieces, is a question, not a result; we have not tried.', []]] },
    ],
  },
  deform: {
    h: 'The deformation algebra, frozen',
    findings: [
      { id: 'F3', title: 'A frozen 1+1 model of the deformation algebra: Witt ⊗ A_ε', lines: [
        ['checked', 'His hypersurface deformation algebra (48)–(50) has structure functions. In a frozen model (flat 1+1, a constant c = (deg P − 1)p¹¹, a lapse of weight −1) it becomes Witt ⊗ A_ε with A_ε = ℝ[h]/(h² = ε), the one-generator Clifford algebra: Cl(0,1) = ℂ for ε = −1, the dual numbers Cl(0,0,1) for ε = 0, the split-complex numbers Cl(1,0) for ε = +1. Witt ⊗ A_ε is a Lie algebra by construction: A_ε is commutative, so the cyclic sum of the double brackets is the Jacobi sum of Witt times the symmetric product uvw, which is 0; bridge·C1, which recomputes the Jacobi identity for the modes |j| ≤ 3, is a regression test. The content of the finding is the reduction: with a lapse of weight −1 the frozen brackets are those of Witt ⊗ A_ε, whose three cases bridge·C3–C6 identify, and with a scalar lapse they are not (next line).', ['bridge·C1', 'bridge·C3']],
        ['checked', 'With a scalar lapse (weight 0) and a constant structure function the Jacobi identity fails, with residual 36: that is why (48) carries a structure function and not a constant.', ['bridge·C2']],
        ['checked standard', 'For ε = +1 the algebra is Witt ⊕ Witt, E± = (D ± H)/2, and with the central term Vir ⊕ Vir, two commuting Virasoro algebras. For ε = 0 it is BMS₃, with [M,M] = 0 and central charges (c_L, c_M), isomorphic to the 2d Galilean conformal algebra (Bagchi, arXiv:1006.3354); BMS is the conformal extension of the Carroll group (Duval, Gibbons, Horvathy, arXiv:1402.5894), so in 2d “Carroll” and “Galilei” are one algebra. For ε = −1 it is Witt ⊗ ℂ read as a real algebra.', ['bridge·C4', 'bridge·C5', 'bridge·C6', 'bd·str·14', 'bd·phy·13']],
        ['ours', 'This is a frozen flat 1+1 model, not his equations (48)–(50), whose structure functions depend on the phase space. Reading ε = +1 as the light cone, and the two Virasoro copies as the left and right movers of a closed string (a textbook picture; pointer, source unread), is ours, and so is grouping the three values of the generator’s square, −1, 0, +1, with the other three-way sortings of squares in the atlas (see the Conventions page).', []],
        ['open', 'P3: in 1+1 both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. Whether his deformation algebra has a family in the sign ε with Euclidean, Carroll-type and Lorentzian members for d > 1 stays open. Frozen 1+1 model only, not his (48)–(50); nothing is computed beyond it.', []]] },
    ],
  },
  fibre: {
    h: 'Fibre and base: left and right',
    convention: 'Convention printed here, as in finding F10: the base is the left action of an algebra on itself. Its right action gives two fibres, not to be mixed: the twisted right action anticommutes with the base and is its mirror (F10); the plain right action commutes with it, is its commutant and has the same type (F11 and the widget below). Reversion turns left multiplication into right multiplication ((ax)~ = x̃ã), so the opposite convention is just as valid. Nothing below depends on the choice.',
    findings: [
      { id: 'F10', title: 'Locally a product; left and right action as base and fibre', lines: [
        ['checked standard', 'Product. Base Cl(1,3), fibre Cl(0,3): a blade of the total algebra is a pair (base label | fibre label), labels concatenate and the sign is (−1)^{|b||c|} times the two factor signs: the graded tensor product, total Cl(1,6). The three fibre bivectors commute with every base generator and with the six Lorentz bivectors, and close into so(3) = su(2).', ['fibre·G1a–c']],
        ['checked standard', 'Left and right. L_i and R_j commute. With the grading twist R′_j x = (−1)^{|x|} x e_j the right action anticommutes with every L_i and squares to −ε_j: the 2n operators obey the bit rule of Cl(n,n) with signature (ε | −ε), so A acts on itself through A ⊗̂ mirror(A) = Cl(n,n) = M_{2ⁿ}(ℝ) = End(A) (the 20 signatures with n ≤ 5, r = 0). The clocks of A and of its mirror add to 0 mod 8 for every n ≤ 12: the mirror is the inverse in the Brauer–Wall group.', ['fibre·G2a–c']],
        ['checked', 'In that algebra the n commuting bivectors L_i R′_i square to +1 and every blade e_a is a joint eigenvector with eigenvalue (−1)^{[i ∈ a]} ε_i, all 2ⁿ sign patterns occurring once: the blade labels are the weights of the spinor of so(V ⊕ −V) (core·B10, core·B10b, every non-degenerate signature with n ≤ 4).', ['fibre·G2a–c']],
        ['checked', 'At n = 4 the twisted right action of Cl(1,3) squares to (−1, +1, +1, +1): the mirror is Cl(3,1), the convention the quantum notes print for Dirac, and together they give Cl(4,4) = M₁₆(ℝ), the algebra of the Furey page. Isomorphic as algebras; the generators are not matched (this is not a Lorentz frame).', ['fibre·G2d']],
        ['ours', 'Calling the left action the base and the twisted right action the fibre is ours. For odd n the pseudoscalar is central and left and right overlap through it. All of this is local: how fibres are glued over a manifold is the gap of row L4.', []]] },
      { id: 'F11', title: 'Keep the 8 fixed and step the base down: the commutant fills', lines: [
        ['checked standard', 'Fix V = ℝ¹⁶ and eight real 16×16 matrices γ₁ … γ₈ that anticommute and square to −1: Cl(0,8) = M₁₆(ℝ). Base: the algebra of the first k of them; fibre: its commutant in End(V). For k = 0 … 8 the fibre has dimension 256, 128, 64, 32, 16, 8, 4, 2, 1 = 2^{8−k}; the commutant of the fibre is the base again; base and fibre have the same centre, of dimension 1 for k even and 2 for k odd.', ['fibre·G3a–d']],
        ['checked standard', 'Explicit generators span the fibre (for k even, the freed generators dressed with the top blade of the base, ω_kγ_j with j > k), and its types run ℝ, ℂ, ℍ, ℍ², ℍ, ℂ, ℝ, ℝ², ℝ for k = 0 … 8, the same as the base Cl(0,k). The type equality holds in any End(V) by the double-centraliser theorem; fixing the 8 adds only the dimensions and the generators.', ['fibre·G3e']],
        ['ours', 'That the fibre of the physical Lorentz base is this commutant, and what lives in it, is a reading and is not tested. Isomorphic as algebras; generators not matched.', []]] },
    ],
    massH: 'An extra direction and the mass shell (finding F12)',
    mass: { id: 'F12', title: 'One extra direction and the mass shell', lines: [
      ['standard', 'A momentum along an extra space-like direction enters as a mass, E² = |p|² + m² (Kaluza–Klein).', []],
      ['checked standard', 'A time-like extra direction breaks hyperbolicity: a fibre of signature (f₊, f₋) added to Cl(1,3) keeps a hyperbolic total form exactly when f₊ = 0 (the nine signatures with f± ≤ 2).', ['fibre·G4d']],
      ['checked', 'A null direction never enters the determinant: its momentum is frozen out.', ['Thm T16']],
      ['checked standard', 'At n = 4 the extra direction is already inside the algebra: in Cl(1,3) the pseudoscalar ω squares to −1 and anticommutes with every generator, so (P + mω)² = E² − |p|² − m² exactly (60 integer samples); in Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ) the two summands carry the two signs of m.', ['fibre·G4a', 'fibre·G4c']],
      ['ours', 'Reading the mass as coming from the descent of F11 is ours; nothing here says which direction a physical mass is.', []]] },
    ladder: ['checked', 'Stepping down the E₈ root system, 240 → 126 → 72 → 40 → 20 → 8 roots with links of 56, 27, 16, 10 and 6, has its home in the Baez chapter.', ['fibre·G8a–c']],
    baezLink: 'The E₈ ladder: Baez chapter',
  },
  fock: {
    h: 'Fock space and the Pauli strings',
    findings: [
      { id: 'F7', title: 'The label set is the Fock basis', lines: [
        ['checked standard', 'The notes’ fermionic Fock space ∧F = ℂ ⊕ H ⊕ (H∧H) ⊕ … (§21.4) is the exterior algebra Λ(H): on n modes, 2ⁿ basis states, the n-bit labels. The wedge ε_k and the interior product ι_k satisfy ε_k² = 0, his Pauli exclusion (Remark 14.17), and {ε_k, ι_l} = δ_kl; the operators ε_k ± ι_k square to ±1 and generate Cl(n,n) = M_{2ⁿ}(ℝ) acting on the 2ⁿ states (n = 1, 2, 3; the bit rule holds for every product at n = 1, 2 and for 1 500 sampled products at n = 3; Thm T20 for every n).', ['qm·Q5a', 'qm·Q5b', 'qm·Q6', 'Thm T20']],
        ['checked standard', 'The number operator N = Σ_k (1 − e_{k,n+k})/2 is a sum of idempotents; on a label it returns the popcount, and N = j has C(n,j) states: 1, 3, 3, 1 for three modes.', ['qm·Q7']],
        ['checked standard', 'N qubits are the same rule through Jordan–Wigner: the 4^N Pauli strings are the blades up to a phase, the bit-rule product is the Pauli-group product, and a blade squares to +1 exactly when it is Hermitian (6 of the 16 at N = 2).', ['qm·Q1a–d', 'scw·P4b']],
        ['ours', 'Reading a label as an occupation pattern and its popcount as a particle number is ours; so is reading the complement a ↦ a ⊕ 1…1 (popcount n − |a|) as particle–hole conjugation.', []],
        ['checked standard', 'His symmetric Fock space and the oscillator [a₋, a₊] = 1 have no finite counterpart: the trace of a commutator is 0, the trace of 1 is the dimension.', ['Thm T20']],
        ['checked standard', 'For real amplitudes, product states are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is det = 0 on M₂(ℂ). The Bell state has det ½ ≠ 0.', ['qm·Q10a', 'qm·Q10b']],
        ['ours', 'Linking that (2,2) to the first ultrahyperbolic cell of the hyperbolicity map is ours.', []]] },
    ],
    tableH: 'Three modes: the Fock table',
    tableCols: ['particles N', 'labels', 'states'],
    tableCap: 'N is the popcount of the label, computed here from the labels; qm·Q7 checks the same counts.',
  },
  spin: {
    h: 'SL(2,ℂ) and the 3/4 of both courses',
    findings: [
      { id: 'F5', title: 'Where SL(2,ℂ) lives, and the 3/4 of both lecture courses', lines: [
        ['checked standard', 'The even part of Cl(1,3) is Cl(1,2) ≅ M₂(ℂ), the cell [3,−1] at clock 7, type ℂ: its centre is {1, e₁₂₃₄} with e₁₂₃₄² = −1, and the unit even versors are generated by the six bivectors (to first order, dimension 6): SL(2,ℂ), the spin group of his chapter 15. SU(2) sits in Cl(0,2) = ℍ at [2,−2]; Cl(1,3) itself is at [4,−2], clock 6, type ℍ.', ['bridge·E1–E3']],
        ['checked standard', 'Indices raised, r = 0: Σ_{a<b} (e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 in every signature. At n = 3 the spin Casimir is 3/4 = dim so(3)/dim ℂ², the number of his Example 17.13; in the quantum notes Ω = Σ S_i² = j(j+1) = 3/4 at j = ½, with S_i = e_i/2 in Cl(3,0) = M₂(ℂ) and e₁₂₃ in the part of i.', ['bridge·E4', 'bridge·E5', 'qm·Q8a–c']]] },
    ],
  },
  total: {
    h: 'Total spin and Stern–Gerlach',
    findings: [
      { id: 'F8', title: 'Spin and total spin, read off the grades', lines: [
        ['checked standard', 'Under J_i = e_{jk}/2 the four grades of Cl(3,0) carry the Casimir values 0, 2, 2, 0: a singlet (the scalar and e₁₂₃) and a triplet (vectors and bivectors), his ½ ⊗ ½ = 0 ⊕ 1 (§15.7).', ['qm·Q2']],
        ['checked standard', 'His Clebsch–Gordan amplitudes of §15.6 at j = j_A + j_B − 1 are reproduced, numerically, for five pairs (j_A, j_B): a test of the text, not of the atlas.', ['qm·Q9a', 'qm·Q9b']],
        ['checked standard', 'Stern–Gerlach (§1.1): with the projectors (1 ± e_i)/2 of Cl(3,0), z then z passes 100%, z then x 50%, and a further z again 50%, as in his figures, because e₃ and e₁ anticommute.', ['qm·Q12']]] },
    ],
  },
  bands: {
    h: 'Bands and gaps of a periodic potential',
    findings: [
      { id: 'F13', title: 'The bands of chapter 20 as the sign of X²', lines: [
        ['checked standard', 'Chapter 20 of the quantum notes gives the one-period matrix M of a periodic potential, det M = 1 (his Lemma 20.8); an energy is allowed when ½ Tr M lies in [−1, 1]. A real 2×2 matrix of determinant 1 is a unit multivector of Cl(2,0) = M₂(ℝ) and ½ Tr M is its scalar part g; write M = g + X: X² = g² − 1 is a scalar.', ['fibre·G5a', 'Thm T19']],
        ['checked standard', 'Band: X² < 0, the multipliers are e^{±iθ}. Gap: X² > 0, real multipliers with product 1. Band edge: X² = 0 with X ≠ 0, a Jordan block (the periodic or antiperiodic solution). M = ±I has X = 0 and bounded powers. Computed on 500 random potentials and energies and, numerically, at 7 band edges of one potential found by bisection (X² = 0 to 10⁻⁷).', ['fibre·G5d', 'fibre·G5e', 'scw·P2']],
        ['checked standard', 'The pieces are the three kinds of element: free flight above the potential is cos kl + sin kl · n with n² = −1, below it cosh + sinh · n with n² = +1, a delta kick 1 + g n with n² = 0. The Dirac-comb condition cos θ = cos kl + (g/2k) sin kl is the scalar part of (kick)(flight); the product of the pieces agrees with a numerical integration of the equation.', ['fibre·G5b', 'fibre·G5c', 'fibre·G5f']],
        ['checked standard', 'This is the textbook elliptic, parabolic and hyperbolic split of SL(2,ℝ) (Thm T19).', ['Thm T19']],
        ['ours', 'Grouping band, edge and gap (the sign of X², the square of an element) with the other places of the sign trio −1, 0, +1 is ours.', []]] },
    ],
  },
  stops: {
    h: 'Where the rule stops',
    items: [
      ['open', 'Gluing. Topology, bundles and connections as sections over a manifold: the atlas is pointwise algebra and finite combinatorics, its fields are polynomials in one chart. Row L4 stays a gap.'],
      ['open', 'An action principle. No Lagrangian and no variation, so no closure equations: rows C7 and C8 are not rebuilt, and the energy-distinguishing condition (row C12) has no counterpart.'],
      ['open', 'Infinite dimensions. Banach and Hilbert spaces, the spectral theorem and the bosonic Fock space (row M2); measurement and mixed states beyond Cl(3,0) (row M10).'],
      ['open', 'Analysis. Chapter 20 is reached only through its one-period matrix, not through the spectrum of the Schrödinger operator.'],
    ],
  },
  persp: {
    h: 'Perspectives',
    intro: 'Offered to his side as questions; each is ours or open, and none is a statement about nature.',
    items: [
      { id: 'P1', h: 'A Clifford chapter between 12 and 15', lines: [
        ['ours', 'His geometry lectures go from forms (ch. 12) to Lie groups, SL(2,ℂ) (ch. 15) and the Casimir (ch. 17); the notes go from chapter 12 to chapter 15 without naming a Clifford algebra. Would one table (F1), which puts SL(2,ℂ) at a computed address (F5), be a useful bridge between them?', []]] },
      { id: 'P2', h: 'Matter conditions as a map of cells', lines: [
        ['checked', 'For quadratic P the first condition is the (k,d) map of F2.', ['bridge·B1–B3']],
        ['checked standard', 'For real amplitudes, product states are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is det = 0 on M₂(ℂ).', ['qm·Q10a', 'qm·Q10b']],
        ['ours', 'The link of that (2,2) to hyperbolicity is ours.', []],
        ['open', 'Do the second and third conditions carve a similar map for the quartic area-metric P?', []]] },
      { id: 'P3', h: 'The deformation algebra in more dimensions', lines: [
        ['open', 'In the frozen 1+1 model ε is the sign class of the constant c = (deg P − 1)p¹¹, and both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. Is there a family in the sign ε with Euclidean, Carroll-type and Lorentzian members? Frozen 1+1 model only.', []]] },
      { id: 'P4', h: 'The area-metric constants and the octahedron', lines: [
        ['open', 'Do the eleven or more constants of the closure of general linear electrodynamics organise along 6 + 12 + 3, or along the invariant pieces of the 21 (F4)? A check of whether the closure equations respect either split would say.', []]] },
      { id: 'P5', h: 'One object for Grassmann and Fock', lines: [
        ['checked standard', 'His geometry course builds Λ(V) as forms (ch. 12) and his quantum course builds ∧F as the fermionic Fock space (§21.4): the same exterior algebra; the Pauli exclusion of §14.4 is e² = 0 in the all-null rule.', ['qm·Q6', 'bridge·A1']],
        ['ours', 'Bit label = occupation pattern is our reading.', []]] },
      { id: 'P6', h: 'Closure with spinorial matter', lines: [
        ['open', 'His paper treats Dirac matter through its principal tensor only. Would a closure that keeps the tetrad and the spinor need the structure the atlas has at fibre level (steps 4, 5, 9, 12)? Beyond what we can test.', []]] },
      { id: 'P7', h: 'A convention flag', lines: [
        ['checked', 'The Dirac signs of the notes (F9) are settled in the algebra: the factor i is the slip, not the cell.', ['fibre·G4b', 'qm·Q11b', 'Thm T16']],
        ['open', 'Only the lecture video would show whether the printed form is the lecturer’s or the transcript’s; optional.', []]] },
      { id: 'P8', h: 'Λ and the extra generator', lines: [
        ['ours', 'The sign of Λ in his closure of Klein–Gordon matter and the square s ∈ {0, −1, +1} of the atlas’s extra generator (flat, de Sitter, anti-de Sitter) read together as Λ ~ −s·κ². Ours; untested against his equations.', []]] },
      { id: 'P9', h: 'A Clifford home for the Floquet classes', lines: [
        ['checked standard', 'Band, edge and gap are the sign of X² for the one-period matrix (F13); the same three classes sort the elements of SL(2,ℝ).', ['fibre·G5a–f', 'Thm T19']],
        ['ours', 'Setting them beside the frozen deformation algebra (F3) is ours.', []]] },
      { id: 'P10', h: 'Base and fibre as left and right', lines: [
        ['ours', 'A local algebraic counterpart of his bundles: the plain right action is a commuting fibre of the same type, the twisted one the mirror (F10, F11).', []],
        ['open', 'Does a global version exist? That is what row L4 leaves open.', []]] },
    ],
  },
  quantum: {
    h: 'Integrating the quantum lectures',
    readH: 'Read so far, in part',
    read: 'Chapters 1 (desiderata, axioms, Stern–Gerlach), 12.4 (position, momentum, angular momentum), 13 (spin, Casimir, ladder operators), 14 (tensor products, entanglement), 15 (total spin, Clebsch–Gordan), 16.2–16.3 (oscillator ladder), 17.3 and 17.5 (measurement and mixed states), 19.4 and 20 (periodic potentials, Floquet matrix, bands) and 21 (Schrödinger, Klein–Gordon, Dirac, Fock space). Not read: 2–11, 12.1–12.3, the rest of 16 and of 17–19.',
    itemsH: 'The five items of the report’s plan, and where they stand',
    items: [
      ['checked open', '1. Chapter 17, mixed states as (1 + v)/2 in Cl(3,0) and the probability rule as a trace: answered for n = 3 by the category chapter (the Bloch ball, 2⟨ρP⟩₀ = (1 + v·u)/2; with null generators every state vanishes on the radical); other signatures open.', ['cat·C2', 'cat·C3', 'Thm T15']],
      ['checked open', '2. Chapters 8–11, the finite shadow of the spectral theorem (commuting blades of square +1 and their projectors): the counts are done in the category chapter; the link to contextuality is open.', ['cat·W1–W3']],
      ['checked open', '3. Chapter 16, the fermionic oscillator against the bosonic ladder: the relations agree once the commutator is a super-commutator (the super-dimension of the label space is 0); the limit is open.', ['cat·B1', 'Thm T20']],
      ['checked', '4. The Dirac signs (F9): settled in the algebra.', ['fibre·G4b', 'qm·Q11b']],
      ['open', '5. One combined matrix: the rows of the three reports stand in one translation matrix on the page for researchers, but they are not ordered along his pipeline.', []],
    ],
  },
  notes: {
    h: 'Notes on the texts as posted (unconfirmed)',
    intro: 'The quantum notes are a student transcript, not endorsed by the lecturer; the video may differ. These are notes on that text.',
    items: [
      ['checked open', 'F9. The notes (§21.3, footnote 54) write (iγ^μ∂_μ − m)Ψ = 0 with {γ^μ, γ^ν} = 2η^{μν} and η = diag(−1, 1, 1, 1): then γ⁰ squares to −1 and the γ_a to +1, the cell Cl(3,1) = M₄(ℝ) at clock 2, and the plane-wave symbol vanishes at E² = |p|² − m², the wrong sign for a mass. The notes’ own Klein–Gordon equation has the right sign, so this reads as a convention slip between two sections. The slip is the factor i, not the cell: the real operator γ·∂ − m of Cl(3,1) has the physical shell.', ['qm·Q11a–c', 'fibre·G4b', 'Thm T16']],
      ['ours', 'F13. The trace is written ψ₁(a) + ψ₂(a) where the band condition uses ψ₁(a) + ψ₂′(a): our reading of a slip in the transcript.', []],
      ['standard', 'F13. The spectrum is called a union of open intervals; the standard statement has closed bands, the edges (the parabolic points) included (Floquet–Bloch, recalled).', []],
    ],
  },
  questions: {
    h: 'Questions',
    items: [
      ['open', 'For the quartic area-metric P, do the second and third conditions carve a map like the hyperbolicity map of cells (P2)?', []],
      ['open', 'P cannot separate Cl(1,3) from Cl(3,1), yet a real (Majorana) Dirac operator exists in Cl(3,1) (Thm T16(3)). Would Majorana matter make the closure pipeline see the difference?', []],
      ['open', 'Beyond 1+1, is there a family in the sign ε of the frozen deformation algebra with Euclidean, Carroll-type and Lorentzian members (P3)?', []],
      ['open', 'Do the closure constants of general linear electrodynamics respect the invariant split of the 21, and can a closure keep the tetrad and the spinor (P4, P6)?', []],
      ['ours open', 'Does the sign of Λ follow the square s of the extra generator, Λ ~ −s·κ² (P8)? Ours; untested against his equations.', []],
      ['open', 'Is there a global version of base and fibre as left and right actions (P10, row L4)?', []],
      ['open', 'For r ≥ 1 the quadratic principal polynomial is at best weakly hyperbolic and its gradient misses the null directions: is the dual polynomial of his second condition defined there, and are null generators then excluded by the second condition rather than by the first (closure paper, Sect. II: pointer, source unread)?', []],
    ],
  },
  honest: {
    h: 'The honest list',
    items: [
      ['checked', 'Forms and the atlas’s cells share one multiplication table: only the squares change.', ['bridge·A1', 'bridge·A2']],
      ['checked standard', 'For r = 0 a quadratic principal polynomial is hyperbolic exactly for a Lorentzian signature, one sign against all the others; with null generators a hyperbolic direction exists for one plus or one minus generator, never a strict one. That this selects the Lorentzian metric is his result.', ['bridge·B1–B5', 'Thm T18', 'bd·geo·8', 'bd·xck·5']],
      ['checked standard', 'With the 8 kept fixed, the base Cl(0,k) has dimension 2^k and its commutant 2^{8−k}, the product stays 256, and both have the same type; locally the total algebra is the graded product of base and fibre.', ['fibre·G3a–e', 'fibre·G1a–c']],
      ['ours', 'The names base and fibre, outside and inside, are ours.', []],
      ['checked standard', 'A second particle in a full mode gives nothing (ε_k² = 0), and three Stern–Gerlach magnets give 100%, 50%, 50%.', ['qm·Q1a–d', 'qm·Q5–Q7', 'qm·Q12']],
      ['ours', 'Bands, orbits and springs as one trio −1, 0, +1 is ours (the bands and the springs sort the square of an element, the orbits the square of the extra generator); so is Λ ~ −s·κ², untested against his equations.', []],
      ['open', 'His gravity equations need gluing and an action; we did not rebuild them (rows C7, C8; L4).', []],
    ],
  },
  bar: {
    h: 'The honesty bar and the translation matrix',
    note: 'E means the same algebraic identity, pointwise, in one chart; it is not a statement about his theory.',
    matrixFold: 'The translation matrix of this chapter',
  },
  thm: {
    h: 'Theorems this chapter leans on',
    intro: 'Each is a theorem of the page for researchers; its status and the verdict of the independent verifier are read from there. “Proved here” means proved for the atlas and re-derived once by an independent reader: unreviewed, no specialist has checked it yet.',
    status: 'Status', verifier: 'Verifier',
    items: [
      { id: 'T3', line: ['checked standard', 'Thm T3, every (p,q,r): λ, the coefficient of e_F, is a Frobenius form for every signature, null generators included; its Nakayama automorphism is the identity for odd n and the grade involution for even n; a symmetric form exists iff n is odd or r = 0.', ['Thm T3']] },
      { id: 'T16', line: ['checked standard', 'Thm T16, every (p,q,r): (P − m)(P + m) = Q(k) − m²; det(P − m | V) = (m² − Q(k))^{N/2} with two exceptions; a null momentum never enters; in Cl(3,1) the real γ·∂ − m has the physical shell, and the i is the Fourier i.', ['Thm T16']] },
      { id: 'T18', line: ['checked standard', 'Thm T18(f), r = 0: a quadratic principal polynomial is hyperbolic iff its signature is Lorentzian.', ['Thm T18']] },
      { id: 'T19', line: ['checked standard', 'Thm T19, SL(2,ℝ): X² = g² − 1; elliptic, parabolic, hyperbolic by the sign of X²; for a periodic potential, band iff X² < 0 and gap iff X² > 0, an edge being X² = 0 with X ≠ 0.', ['Thm T19']] },
      { id: 'T20', line: ['checked standard', 'Thm T20, every m: Cl(m,m) ≅ End Λ(ℝ^m); the label basis is the Fock basis and the number operator the popcount; [a, a⁺] = 1 has no finite-dimensional solution.', ['Thm T20']] },
    ],
  },
  scripts: {
    h: 'The scripts',
    report: { lead: 'Full report:', title: 'Schuller’s lectures read as fibre and base', file: 'reports/html/schuller_bridge_report.html' },
    intro: 'Three scripts recompute every statement tagged checked in this chapter; they need Python 3 and numpy, and each runs in a few seconds. The script of the widgets (lens_sch_check.py) checks the numbers the widgets show.',
    files: [
      { file: 'selfcheck/reports/fibre_check.py', note: 'Fibre and base, checks G1–G9: 35 checks.' },
      { file: 'selfcheck/reports/bridge_check.py', note: 'The pipeline, checks A–F: 77 checks (B1 runs once per signature).' },
      { file: 'selfcheck/reports/bridge_check_qm.py', note: 'The quantum lectures, checks Q1–Q12: 51 checks.' },
    ],
    run: 'cd selfcheck/reports; python3 fibre_check.py; python3 bridge_check.py; python3 bridge_check_qm.py',
    sabotage: 'Sabotage: 21 deliberate mutations of the checks are caught by the report’s automated mutation script (mutate_fibre.py, shipped with the report), and 16 more were run by hand when the checks were written.',
    widgets: 'The script of the widgets',
  },
  sources: {
    h: 'Sources',
    langNote: '',
    items: [
      'F. P. Schuller, Lectures on the Geometric Anatomy of Theoretical Physics, FAU Erlangen-Nürnberg 2013/14; notes by S. Rea, updated 25 October 2017 (read in targeted chapters).',
      'M. Düll, F. P. Schuller, N. Stritzelberger, F. Wolz, Gravitational closure of matter field equations, arXiv:1611.08878 v3, 2018 (read in parts).',
      'F. P. Schuller, Constructive Gravity: Foundations and Applications, rapporteur article, 15th Marcel Grossmann Meeting, arXiv:2003.09726, 2020.',
      'F. P. Schuller, Lectures on Quantum Theory, FAU 2015; notes by S. Rea and R. Dadhley, 31 January 2019 (read in part; the notes state that they are not endorsed by the lecturer).',
      'M. Bojowald, E. I. Duque, A. Shah, Hypersurface deformations, arXiv:2410.18807 (abstract level, for the form of the deformation algebra).',
    ],
  },
};

// ---------------------------------------------------------------- Italiano, voce formale (same shape, same tags and checks as EN)
const IT = {
  title: 'Da come si muove la materia alla legge della gravità: la catena di Schuller, e fin dove la segue la regola dei bit',
  menuLbl: 'In questo capitolo',
  menu: { first: 'Panoramica', chain: 'La sua catena', table: 'Una tabella', hyper: 'Iperbolicità', area: 'Metrica d’area', deform: 'Algebra delle deformazioni', fibre: 'Fibra e base', fock: 'Spazio di Fock', spin: 'SL(2,ℂ) e 3/4', total: 'Spin totale', bands: 'Bande', stops: 'Dove si ferma', persp: 'Prospettive', quantum: 'Lezioni quantistiche', notes: 'Note sui testi', questions: 'Domande', honest: 'Elenco onesto', bar: 'Barra di onestà', thm: 'Teoremi', scripts: 'Script', sources: 'Fonti' },
  checksLbl: 'Controlli',
  first: {
    lede: 'Schuller ricava la gravità dalla materia: azione, poi polinomio principale, poi tre condizioni, poi chiusura. L’atlante segue esattamente il fronte algebrico e si ferma dove comincia la dinamica.',
    ledeM: 'Su ℝ, in dimensione finita e in una carta: quali anelli della catena di Schuller sono identità della regola dei bit in Cl(p,q,r), ciascuno con il suo dominio, il suo controllo e il suo stato, e dove le identità si fermano.',
    disclaimer: 'Nessun principio d’azione, nessuna varietà: le equazioni di chiusura non sono ricostruite; la condizione che distingue l’energia è una lacuna (riga C12); l’algebra delle deformazioni è un modello piatto 1+1 congelato; le note quantistiche sono la trascrizione di uno studente, non approvata dal docente.',
    fullH: 'Introduzione completa',
    full: [
      'Il programma della gravità costruttiva di F. P. Schuller (l’articolo sulla chiusura con M. Düll, N. Stritzelberger e F. Wolz, e la rassegna “Constructive Gravity”) e i suoi due corsi di lezioni incontrano l’atlante in un punto solo: una forma quadratica su uno spazio vettoriale e l’algebra che essa genera. Lui usa la forma, il polinomio principale delle equazioni di campo della materia, per decidere quali geometrie possono portare una materia predittiva, e poi chiude l’algebra delle deformazioni delle ipersuperfici per ottenere la dinamica gravitazionale. L’atlante prende la forma come data e costruisce ogni oggetto da una sola regola dei segni, e_a e_b = s(a,b) e_{a⊕b}.',
      'La matrice di traduzione di questo capitolo mette gli oggetti dei suoi documenti contro le 22 pagine e i passi dell’atlante. Una cella è E (la stessa identità algebrica, punto per punto, in una carta, calcolata), S (la stessa struttura, o un fatto standard) o A (una nostra lettura). La barra di onestà, alla fine, conta le righe secondo il loro grado migliore; una E non è un’affermazione sulla sua teoria.',
      'Che cosa abbiamo letto: le lezioni di geometria in capitoli scelti, l’articolo sulla chiusura in parte, la rassegna per la sua cornice, le note quantistiche nei capitoli 1, 12.4, 13–15, 16.2–16.3, 17.3, 17.5, 19.4, 20 e 21. Tre script ricalcolano ogni affermazione con l’etichetta verificato: fibre_check.py (35 controlli), bridge_check.py (77) e bridge_check_qm.py (51), 163 in tutto, Python 3 e numpy.',
    ],
    scope: 'Dominio: le algebre reali Cl(p,q,r) della regola dei bit (p quadrati +1, q quadrati −1, r quadrati 0), dimensione finita, una carta. Ogni affermazione dice il suo intervallo; “Thm T#” è un teorema della pagina per i ricercatori, con lo stato indicato lì.',
    statementsH: 'Le affermazioni, con i loro domini',
    statements: [
      { id: 'St1', title: 'Una sola tabella per le forme e per le algebre di Clifford', lines: [
        ['checked standard', 'Tutti i quadrati 0 danno l’algebra esterna Λ(ℝⁿ) = Cl(0,0,n); quadrati ±1 danno Cl(p,q). Le etichette, lo XOR e il segno di riordino sono gli stessi; nel segno entrano solo i quadrati dei generatori che due blade hanno in comune (calcolato per la regola tutta nulla con n ≤ 6 e per Cl(p,q) con p, q ≤ 4 e n ≤ 6).', ['bridge·A1–A4']],
        ['checked standard', 'Il complemento a ↦ a ⊕ F (F = 1…1) è una dualità di Frobenius per ogni (p,q,r); la moltiplicazione per e_F è una stella di Hodge metrica se e solo se r = 0 (con un generatore nullo e_F² = 0 ed e_F· raggiunge solo 2^{p+q} delle 2ⁿ etichette).', ['bridge·A5', 'bridge·A6', 'Thm T3']]] },
      { id: 'St2', title: 'Iperbolico se e solo se lorentziano', lines: [
        ['checked standard', 'Dominio r = 0. Un polinomio principale quadratico non degenere P(k) = Σ ε_i k_i² è iperbolico se e solo se la sua segnatura è (1, n−1) o (n−1, 1): trovato con una ricerca diretta per ogni (k,d) con n = 2…7, dimostrato in generale (Thm T18(f)); lo script del capitolo ricalcola la mappa delle celle.', ['bridge·B1–B3', 'Thm T18', 'scw·P1']]] },
      { id: 'St3', title: 'Il determinante del simbolo', lines: [
        ['checked standard', 'Dominio: ogni (p,q,r). Per P = Σ k_i e_i e un modulo reale V di dimensione N: (P − m)(P + m) = Q(k) − m², e det(P − m | V) = (m² − Q(k))^{N/2} tranne che per (p,q) = (1,0) su un modulo non graduato e per il caso dispari banale p = q = 0 (Thm T16). Un impulso lungo un generatore nullo non entra mai nel determinante. Il simbolo di Dirac reale 8×8 dell’atlante ha |det| = (p²)⁴, polinomio ridotto p².', ['bridge·B4', 'Thm T16', 'scw·P1']],
        ['checked standard', 'La i dello stampato (iγ·∂ − m) è la i di Fourier di ∂ → ip, non un elemento dell’algebra: in Cl(3,1) l’operatore reale γ·∂ − m ha il guscio fisico E² = |p|² + m².', ['fibre·G4b', 'qm·Q11b', 'Thm T16']]] },
      { id: 'St4', title: 'Il Casimir dello spin', lines: [
        ['checked standard', 'Dominio r = 0, indici alzati: Σ_{a<b} (e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 in ogni segnatura. A n = 3, con gli S_i = e_i/2 hermitiani di Cl(3,0) = M₂(ℂ), Ω = Σ S_i² = 3/4 = j(j+1) a j = ½.', ['bridge·E4', 'qm·Q8b', 'qm·Q8c']]] },
      { id: 'St5', title: 'Lo spazio di Fock è l’insieme delle etichette', lines: [
        ['checked standard', 'Cl(m,m) ≅ End Λ(ℝ^m) = M_{2^m}(ℝ): gli operatori ε_k ± ι_k hanno quadrato ±1 e anticommutano, la base delle etichette è la base di Fock, l’esclusione di Pauli è ε_k² = 0, e l’operatore numero restituisce il numero di bit accesi (calcolato per m = 1, 2, 3; Thm T20 per ogni m).', ['qm·Q5–Q7', 'Thm T20']]] },
      { id: 'St6', title: 'Sinistra e destra: base e speculare', lines: [
        ['checked standard', 'Dominio r = 0. Per A = Cl(p,q) le moltiplicazioni a sinistra L_i e quelle a destra con il segno del grado R′_j x = (−1)^{|x|} x e_j anticommutano e generano Cl(n,n) ≅ End(A), segnatura (ε | −ε); le moltiplicazioni a destra semplici commutano con le L_i e generano il commutante, A^{op} ≅ A. Calcolato per le 20 segnature con n ≤ 5; gli orologi di A e della sua speculare sommano a 0 mod 8 per ogni n ≤ 12.', ['fibre·G2a–d']]] },
      { id: 'St7', title: 'Tenere fisso l’8: il commutante', lines: [
        ['checked standard', 'Con otto γ anticommutanti di quadrato −1 in M₁₆(ℝ), il commutante di Cl(0,k) ha dimensione 2^{8−k} (k = 0…8), il doppio commutante è di nuovo Cl(0,k), e i due hanno lo stesso centro e lo stesso tipo. L’uguaglianza dei tipi vale in ogni End(V) per il teorema del doppio centralizzatore; tenere fisso l’8 aggiunge solo le dimensioni e i generatori espliciti ω_kγ_j.', ['fibre·G3a–e']]] },
      { id: 'St8', title: 'Le classi di Floquet', lines: [
        ['checked standard', 'For M ∈ SL(2,ℝ), the unit multivectors of Cl(2,0), write M = g + X with g = ⟨M⟩₀: X² = g² − 1. Band iff X² < 0, gap iff X² > 0, band edge iff X² = 0 with X ≠ 0. M = ±I has X = 0 and bounded powers and is not an edge.', ['fibre·G5a–f', 'Thm T19', 'scw·P2']]] },
      { id: 'St9', title: 'La scala di E₈ (un rimando)', lines: [
        ['checked', 'The common-neighbour ladder 240 → 56 → 27 → 16 → 10 → 6 → 3 of the E₈ roots and the orthogonal root systems of 126, 72, 40, 20 and 8 roots are computed; their home is the Baez chapter. The script names the systems by root count and rank only: the Cartan matrices are not computed, and count and rank do not identify a root system in general (B₃ and C₃ both have 18 roots and rank 3).', ['fibre·G8a–c']]] },
    ],
  },
  chain: {
    h: 'La sua catena, la nostra traccia',
    intro: 'Sette pietre, da sinistra a destra: che cosa permette una forma quadratica (pietre 1–3), poi la dinamica su una varietà (pietre 4–7). Ogni pietra porta il grado migliore di ciò che l’atlante ha lì, nell’ordine della figura del rapporto.',
    findings: [
      { id: 'F6', title: 'Prima la materia, poi la gravità: dove comincia l’atlante', lines: [
        ['standard', 'La sua catena: l’azione della materia dà un polinomio principale; tre condizioni (iperbolico, iperbolico duale, che distingue l’energia) lo filtrano; osservatori e una fogliazione danno la geometria indotta; la chiusura dell’algebra delle deformazioni delle ipersuperfici dà equazioni lineari la cui soluzione, per la materia di Klein–Gordon, è l’azione di Einstein–Hilbert con due costanti d’integrazione (κ, Λ).', []],
        ['checked', 'I gradi lungo la sua catena: S, E, E, S, S, S, A. La pietra 2 è esatta (il simbolo di Dirac reale 8×8 ha |det| = (p²)⁴, polinomio ridotto p²); la pietra 3 è esatta per la sua prima condizione con P quadratico (Thm T18(f)), e la sua terza condizione non ha corrispondente (riga C12).', ['bridge·B1–B5', 'Thm T18']],
        ['checked', 'Il centro è una caricatura congelata: in un modello piatto 1+1 l’algebra delle deformazioni è Witt ⊗ A_ε (pietra 6, strutturale; vedi sotto).', ['bridge·C1–C6']],
        ['ours', 'Leggere l’atlante come la sua catena percorsa al contrario è nostro: i suoi passi 9 e 10 partono dalla tetrade, dalla curvatura e dalla forma di Einstein e le controllano, mentre lui arriva all’azione gravitazionale per chiusura.', []],
        ['open', 'La seconda metà, le equazioni di chiusura e il principio d’azione, non è ricostruita: la riga C7 resta un’analogia e la riga C12 una lacuna.', []],
        ['ours', 'Una lettura collega i due estremi: la classe di segno di Λ letta come −s·κ², dove s è il quadrato del generatore in più del passo 11. Nostra; non messa alla prova con le sue equazioni.', []]] },
    ],
  },
  table: {
    h: 'Una tabella, tre scelte di quadrato',
    intro: 'Il widget qui sotto mette il quadrato di ogni generatore a −1, 0 o +1 e ridisegna la stessa tabella di moltiplicazione.',
    foldH: 'Il risultato F1 per intero',
    catLink: 'Il complemento come dualità di Frobenius: capitolo sulle categorie',
    findings: [
      { id: 'F1', title: 'Il prodotto esterno e quello di Clifford hanno una sola tabella', lines: [
        ['checked standard', 'Nella regola dei bit e_a e_b = s(a,b) e_{a⊕b} il segno è il segno di riordino per il prodotto dei quadrati dei generatori che i due blade hanno in comune. Tutti i quadrati 0: l’algebra esterna del suo capitolo 12, compreso il segno del suo Teorema 12.8. Quadrati ±1: Cl(p,q). Etichette, XOR e segno di riordino non cambiano mai (la regola tutta nulla con n ≤ 6; Cl(p,q) con p, q ≤ 4 e n ≤ 6, 17 976 prodotti).', ['bridge·A1–A4']],
        ['checked standard', 'Per una cella non degenere la sua stella di Hodge è la moltiplicazione per lo pseudoscalare, che sulle etichette è il complemento a ↦ a ⊕ 1…1 (Cl(1,3), Cl(3,1), Cl(2,2), Cl(4,0)). Con un generatore nullo il blade di grado massimo ha quadrato 0 e la moltiplicazione per esso raggiunge solo 2^{p+q} delle 2ⁿ etichette: non è una stella di Hodge. Il complemento in sé resta una dualità di Frobenius per ogni segnatura; la sua casa è il capitolo sulle categorie.', ['bridge·A5', 'bridge·A6', 'Thm T3']],
        ['standard', 'Non è un teorema nuovo: l’algebra di Clifford come deformazione dell’algebra esterna è classica.', []],
        ['ours', 'Le note passano dal capitolo 12 (le forme) al capitolo 15 (SL(2,ℂ)) senza nominare un’algebra di Clifford; una tabella potrebbe stare fra i due.', []]] },
    ],
  },
  hyper: {
    h: 'Quali celle lasciano propagare le onde: l’iperbolicità',
    intro: 'Per il fisico e il matematico segue un banco di prova: scegli una cella, e il browser calcola il determinante del simbolo, il polinomio ridotto e il verdetto.',
    findings: [
      { id: 'F2', title: 'L’iperbolicità filtra le celle', lines: [
        ['checked standard', 'Take the quadratic form of a cell Cl(k,d) as a principal polynomial P(k) = Σ ε_i k_i². A direction h with P(h) ≠ 0 is hyperbolic when q ↦ B(q,h)² − P(h)P(q) is non-negative for every q; this happens exactly for signature (1, n−1) or (n−1, 1). Elliptic cells (min(k,d) = 0) and ultrahyperbolic cells (min(k,d) ≥ 2) fail. Found by direct search for every (k,d) with n = 2…7; the Maxwell page’s wave-type table gives the same verdict for every cell. With r ≥ 1 null generators, Cl(k,d,r), a hyperbolic direction exists iff k = 1 or d = 1, and never a strict one: every null covector gives a double root (bd·geo·8, every r with n ≤ 6; bd·xck·5, the smallest case Cl(1,1,1)).', ['bridge·B1–B3', 'Thm T18', 'bd·geo·8', 'bd·xck·5']],
        ['standard', 'Che il filtro restituisca la segnatura lorentziana è la sua stessa conclusione nel caso metrico.', []],
        ['checked standard', 'Una sola classe lorentziana in due convenzioni, P ↔ −P: P non le distingue, le algebre sì, Cl(1,3) = M₂(ℍ) all’orologio 6 e Cl(3,1) = M₄(ℝ) all’orologio 2. Cl(2,2), all’orologio 0, è la prima cella ultraiperbolica.', ['bridge·B3', 'bridge·B3b', 'qm·Q11c']],
        ['checked standard', 'Il campo di Dirac passa lo stesso filtro: il simbolo reale 8×8 su ψ pari in Cl(1,3) ha |det| = (p²)⁴ (12 impulsi razionali), quindi il polinomio ridotto (sue eq. 22–24) è p²; due metriche G e H danno il prodotto (G·k)(H·k), il suo polinomio bimetrico.', ['bridge·B4', 'bridge·B5']],
        ['ours', 'Disegnare il filtro come una mappa di celle è nostro.', []]] },
    ],
  },
  area: {
    h: 'La metrica d’area sull’ottaedro',
    octaLink: 'L’ottaedro del passo 2',
    findings: [
      { id: 'F4', title: 'La metrica d’area: 6 + 12 + 3 = 21', lines: [
        ['checked standard', 'General linear electrodynamics has an area metric G^{abcd} with 21 independent components when the constitutive law comes from a Lagrangian: the symmetric pairs of the six coordinate planes of a 4-space. A general local linear medium has 36, 20 principal, 15 skewon and 1 axion (Jancewicz, arXiv:0807.2989), and the axion part does not enter the wave operator (bd·sol·14). On the octahedron of step 2, with the six bivectors e₁₂ … e₃₄ as vertices: 6 vertices are a plane paired with itself, 12 edges two planes sharing one index, 3 antipodal pairs two disjoint planes, which commute; their cross terms are the three terms of F∧F.', ['bridge·D1', 'bridge·D2', 'bridge·F1', 'bd·sol·14']],
        ['checked', 'La sua densità richiede ε_{abcd}G^{abcd} = 8(G^{01,23} − G^{02,13} + G^{03,12}): entrano solo i tre assi antipodali. La parte puramente metrica 2η^{a[c}η^{d]b} contribuisce 0, quindi |ε·G| = 24 viene dal termine −ε^{abcd} del suo sfondo. Una relazione ciclica (di Bianchi) toglie una combinazione: 21 − 1 = 20 = Ricci 10 + Weyl 10, il n²(n²−1)/12 dell’atlante a n = 4.', ['bridge·D3', 'bridge·D6', 'bridge·D7', 'bridge·D8', 'bridge·F2']],
        ['checked standard', 'Sotto so(4) = su(2) ⊕ su(2), euclidea, le 21 componenti si spezzano in 5 + 5 + 9 + 1 + 1: le parti di Weyl autoduale e antiautoduale, la parte di Ricci a traccia nulla, la parte scalare e la parte ε.', ['bridge·D5']],
        ['standard', 'Le sue metriche d’area sono lorentziane. Sotto so(1,3) la parte autoduale e quella antiautoduale sono coniugate complesse l’una dell’altra, quindi i due 5 formano un solo 10 reale (il tensore di Weyl come vettore complesso a 5 componenti): richiamato, non calcolato qui.', []],
        ['ours', 'La suddivisione 6 + 12 + 3 è un’immagine in un solo sistema di piani coordinati: un cambio di riferimento mescola le tre classi, quindi non è una decomposizione invariante. Disegnarla sull’ottaedro è nostro.', []],
        ['open', 'Se le undici o più costanti d’integrazione della sua chiusura dell’elettrodinamica lineare generale si ordinino secondo 6 + 12 + 3, o secondo i pezzi invarianti, è una domanda, non un risultato; non l’abbiamo provato.', []]] },
    ],
  },
  deform: {
    h: 'L’algebra delle deformazioni, congelata',
    findings: [
      { id: 'F3', title: 'Un modello 1+1 congelato dell’algebra delle deformazioni: Witt ⊗ A_ε', lines: [
        ['checked', 'His hypersurface deformation algebra (48)–(50) has structure functions. In a frozen model (flat 1+1, a constant c = (deg P − 1)p¹¹, a lapse of weight −1) it becomes Witt ⊗ A_ε with A_ε = ℝ[h]/(h² = ε), the one-generator Clifford algebra: Cl(0,1) = ℂ for ε = −1, the dual numbers Cl(0,0,1) for ε = 0, the split-complex numbers Cl(1,0) for ε = +1. Witt ⊗ A_ε is a Lie algebra by construction: A_ε is commutative, so the cyclic sum of the double brackets is the Jacobi sum of Witt times the symmetric product uvw, which is 0; bridge·C1, which recomputes the Jacobi identity for the modes |j| ≤ 3, is a regression test. The content of the finding is the reduction: with a lapse of weight −1 the frozen brackets are those of Witt ⊗ A_ε, whose three cases bridge·C3–C6 identify, and with a scalar lapse they are not (next line).', ['bridge·C1', 'bridge·C3']],
        ['checked', 'Con un lapse scalare (peso 0) e una funzione di struttura costante l’identità di Jacobi fallisce, con residuo 36: per questo (48) porta una funzione di struttura e non una costante.', ['bridge·C2']],
        ['checked standard', 'For ε = +1 the algebra is Witt ⊕ Witt, E± = (D ± H)/2, and with the central term Vir ⊕ Vir, two commuting Virasoro algebras. For ε = 0 it is BMS₃, with [M,M] = 0 and central charges (c_L, c_M), isomorphic to the 2d Galilean conformal algebra (Bagchi, arXiv:1006.3354); BMS is the conformal extension of the Carroll group (Duval, Gibbons, Horvathy, arXiv:1402.5894), so in 2d “Carroll” and “Galilei” are one algebra. For ε = −1 it is Witt ⊗ ℂ read as a real algebra.', ['bridge·C4', 'bridge·C5', 'bridge·C6', 'bd·str·14', 'bd·phy·13']],
        ['ours', 'This is a frozen flat 1+1 model, not his equations (48)–(50), whose structure functions depend on the phase space. Reading ε = +1 as the light cone, and the two Virasoro copies as the left and right movers of a closed string (a textbook picture; pointer, source unread), is ours, and so is grouping the three values of the generator’s square, −1, 0, +1, with the other three-way sortings of squares in the atlas (see the Conventions page).', []],
        ['open', 'P3: in 1+1 both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. Whether his deformation algebra has a family in the sign ε with Euclidean, Carroll-type and Lorentzian members for d > 1 stays open. Frozen 1+1 model only, not his (48)–(50); nothing is computed beyond it.', []]] },
    ],
  },
  fibre: {
    h: 'Fibra e base: sinistra e destra',
    convention: 'Convenzione stampata qui, come nel risultato F10: la base è l’azione sinistra di un’algebra su sé stessa. La sua azione destra dà due fibre, da non confondere: l’azione destra con il segno del grado anticommuta con la base ed è la sua speculare (F10); l’azione destra semplice commuta con essa, è il suo commutante e ha lo stesso tipo (F11 e il widget qui sotto). La reversione trasforma la moltiplicazione a sinistra in moltiplicazione a destra ((ax)~ = x̃ã), quindi la convenzione opposta è altrettanto valida. Niente di ciò che segue dipende dalla scelta.',
    findings: [
      { id: 'F10', title: 'Localmente un prodotto; azione sinistra e destra come base e fibra', lines: [
        ['checked standard', 'Prodotto. Base Cl(1,3), fibra Cl(0,3): un blade dell’algebra totale è una coppia (etichetta della base | etichetta della fibra), le etichette si concatenano e il segno è (−1)^{|b||c|} per i segni dei due fattori: il prodotto tensoriale graduato, totale Cl(1,6). I tre bivettori della fibra commutano con ogni generatore della base e con i sei bivettori di Lorentz, e si chiudono in so(3) = su(2).', ['fibre·G1a–c']],
        ['checked standard', 'Sinistra e destra. L_i e R_j commutano. Con il segno del grado R′_j x = (−1)^{|x|} x e_j l’azione destra anticommuta con ogni L_i e ha quadrato −ε_j: i 2n operatori seguono la regola dei bit di Cl(n,n) con segnatura (ε | −ε), quindi A agisce su sé stessa attraverso A ⊗̂ speculare(A) = Cl(n,n) = M_{2ⁿ}(ℝ) = End(A) (le 20 segnature con n ≤ 5, r = 0). Gli orologi di A e della sua speculare sommano a 0 mod 8 per ogni n ≤ 12: la speculare è l’inversa nel gruppo di Brauer–Wall.', ['fibre·G2a–c']],
        ['checked', 'In that algebra the n commuting bivectors L_i R′_i square to +1 and every blade e_a is a joint eigenvector with eigenvalue (−1)^{[i ∈ a]} ε_i, all 2ⁿ sign patterns occurring once: the blade labels are the weights of the spinor of so(V ⊕ −V) (core·B10, core·B10b, every non-degenerate signature with n ≤ 4).', ['fibre·G2a–c']],
        ['checked', 'A n = 4 l’azione destra con il segno del grado di Cl(1,3) ha quadrati (−1, +1, +1, +1): la speculare è Cl(3,1), la convenzione che le note quantistiche stampano per Dirac, e insieme danno Cl(4,4) = M₁₆(ℝ), l’algebra della pagina di Furey. Isomorfe come algebre; i generatori non sono abbinati (questo non è un riferimento di Lorentz).', ['fibre·G2d']],
        ['ours', 'Chiamare base l’azione sinistra e fibra l’azione destra con il segno del grado è nostro. Per n dispari lo pseudoscalare è centrale e sinistra e destra si sovrappongono attraverso di esso. Tutto ciò è locale: come le fibre si incollano su una varietà è la lacuna della riga L4.', []]] },
      { id: 'F11', title: 'Tenere fisso l’8 e scendere con la base: il commutante si riempie', lines: [
        ['checked standard', 'Si fissi V = ℝ¹⁶ e otto matrici reali 16×16 γ₁ … γ₈ che anticommutano e hanno quadrato −1: Cl(0,8) = M₁₆(ℝ). Base: l’algebra delle prime k; fibra: il suo commutante in End(V). Per k = 0 … 8 la fibra ha dimensione 256, 128, 64, 32, 16, 8, 4, 2, 1 = 2^{8−k}; il commutante della fibra è di nuovo la base; base e fibra hanno lo stesso centro, di dimensione 1 per k pari e 2 per k dispari.', ['fibre·G3a–d']],
        ['checked standard', 'Generatori espliciti generano la fibra (per k pari, i generatori liberati vestiti con il blade di grado massimo della base, ω_kγ_j con j > k), e i suoi tipi sono ℝ, ℂ, ℍ, ℍ², ℍ, ℂ, ℝ, ℝ², ℝ per k = 0 … 8, gli stessi della base Cl(0,k). L’uguaglianza dei tipi vale in ogni End(V) per il teorema del doppio centralizzatore; tenere fisso l’8 aggiunge solo le dimensioni e i generatori.', ['fibre·G3e']],
        ['ours', 'Che la fibra della base fisica di Lorentz sia questo commutante, e che cosa ci viva dentro, è una lettura e non è messa alla prova. Isomorfe come algebre; generatori non abbinati.', []]] },
    ],
    massH: 'Una direzione in più e il guscio di massa (il risultato F12)',
    mass: { id: 'F12', title: 'Una direzione in più e il guscio di massa', lines: [
      ['standard', 'Un impulso lungo una direzione in più di tipo spazio entra come una massa, E² = |p|² + m² (Kaluza–Klein).', []],
      ['checked standard', 'Una direzione in più di tipo tempo rompe l’iperbolicità: una fibra di segnatura (f₊, f₋) aggiunta a Cl(1,3) mantiene iperbolica la forma totale esattamente quando f₊ = 0 (le nove segnature con f± ≤ 2).', ['fibre·G4d']],
      ['checked', 'Una direzione nulla non entra mai nel determinante: il suo impulso resta congelato fuori.', ['Thm T16']],
      ['checked standard', 'A n = 4 la direzione in più è già dentro l’algebra: in Cl(1,3) lo pseudoscalare ω ha quadrato −1 e anticommuta con ogni generatore, quindi (P + mω)² = E² − |p|² − m² esattamente (60 campioni interi); in Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ) i due addendi portano i due segni di m.', ['fibre·G4a', 'fibre·G4c']],
      ['ours', 'Leggere la massa come proveniente dalla discesa di F11 è nostro; niente qui dice quale direzione sia una massa fisica.', []]] },
    ladder: ['checked', 'La discesa nel sistema di radici di E₈, 240 → 126 → 72 → 40 → 20 → 8 radici con legami di 56, 27, 16, 10 e 6, ha la sua casa nel capitolo su Baez.', ['fibre·G8a–c']],
    baezLink: 'La scala di E₈: capitolo su Baez',
  },
  fock: {
    h: 'Lo spazio di Fock e le stringhe di Pauli',
    findings: [
      { id: 'F7', title: 'L’insieme delle etichette è la base di Fock', lines: [
        ['checked standard', 'Lo spazio di Fock fermionico delle note ∧F = ℂ ⊕ H ⊕ (H∧H) ⊕ … (§21.4) è l’algebra esterna Λ(H): su n modi, 2ⁿ stati di base, le etichette a n bit. Il prodotto esterno ε_k e il prodotto interno ι_k soddisfano ε_k² = 0, la sua esclusione di Pauli (Osservazione 14.17), e {ε_k, ι_l} = δ_kl; gli operatori ε_k ± ι_k hanno quadrato ±1 e generano Cl(n,n) = M_{2ⁿ}(ℝ) che agisce sui 2ⁿ stati (n = 1, 2, 3; la regola dei bit vale per ogni prodotto a n = 1, 2 e per 1 500 prodotti scelti a caso a n = 3; Thm T20 per ogni n).', ['qm·Q5a', 'qm·Q5b', 'qm·Q6', 'Thm T20']],
        ['checked standard', 'L’operatore numero N = Σ_k (1 − e_{k,n+k})/2 è una somma di idempotenti; su un’etichetta restituisce il numero di bit accesi, e N = j ha C(n,j) stati: 1, 3, 3, 1 per tre modi.', ['qm·Q7']],
        ['checked standard', 'N qubit sono la stessa regola attraverso Jordan–Wigner: le 4^N stringhe di Pauli sono i blade a meno di una fase, il prodotto della regola dei bit è il prodotto del gruppo di Pauli, e un blade ha quadrato +1 esattamente quando è hermitiano (6 dei 16 a N = 2).', ['qm·Q1a–d', 'scw·P4b']],
        ['ours', 'Leggere un’etichetta come uno schema di occupazione e il suo numero di bit accesi come un numero di particelle è nostro; lo è anche leggere il complemento a ↦ a ⊕ 1…1 (n − |a| bit accesi) come coniugazione particella–lacuna.', []],
        ['checked standard', 'Il suo spazio di Fock simmetrico e l’oscillatore [a₋, a₊] = 1 non hanno corrispondente finito: la traccia di un commutatore è 0, la traccia di 1 è la dimensione.', ['Thm T20']],
        ['checked standard', 'Per ampiezze reali, gli stati prodotto sono il cono nullo di det su M₂(ℝ), segnatura (2,2); su ℂ la condizione è det = 0 su M₂(ℂ). Lo stato di Bell ha det ½ ≠ 0.', ['qm·Q10a', 'qm·Q10b']],
        ['ours', 'Collegare quel (2,2) alla prima cella ultraiperbolica della mappa dell’iperbolicità è nostro.', []]] },
    ],
    tableH: 'Tre modi: la tabella di Fock',
    tableCols: ['particelle N', 'etichette', 'stati'],
    tableCap: 'N è il numero di bit accesi dell’etichetta, calcolato qui dalle etichette; qm·Q7 controlla gli stessi conteggi.',
  },
  spin: {
    h: 'SL(2,ℂ) e il 3/4 dei due corsi',
    findings: [
      { id: 'F5', title: 'Dove vive SL(2,ℂ), e il 3/4 dei due corsi di lezioni', lines: [
        ['checked standard', 'La parte pari di Cl(1,3) è Cl(1,2) ≅ M₂(ℂ), la cella [3,−1] all’orologio 7, tipo ℂ: il suo centro è {1, e₁₂₃₄} con e₁₂₃₄² = −1, e i versori pari unitari sono generati dai sei bivettori (al primo ordine, dimensione 6): SL(2,ℂ), il gruppo di spin del suo capitolo 15. SU(2) sta in Cl(0,2) = ℍ a [2,−2]; Cl(1,3) stessa è a [4,−2], orologio 6, tipo ℍ.', ['bridge·E1–E3']],
        ['checked standard', 'Indici alzati, r = 0: Σ_{a<b} (e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 in ogni segnatura. A n = 3 il Casimir dello spin è 3/4 = dim so(3)/dim ℂ², il numero del suo Esempio 17.13; nelle note quantistiche Ω = Σ S_i² = j(j+1) = 3/4 a j = ½, con S_i = e_i/2 in Cl(3,0) = M₂(ℂ) ed e₁₂₃ nel ruolo di i.', ['bridge·E4', 'bridge·E5', 'qm·Q8a–c']]] },
    ],
  },
  total: {
    h: 'Spin totale e Stern–Gerlach',
    findings: [
      { id: 'F8', title: 'Spin e spin totale, letti dai gradi', lines: [
        ['checked standard', 'Con J_i = e_{jk}/2 i quattro gradi di Cl(3,0) portano i valori del Casimir 0, 2, 2, 0: un singoletto (lo scalare ed e₁₂₃) e un tripletto (vettori e bivettori), il suo ½ ⊗ ½ = 0 ⊕ 1 (§15.7).', ['qm·Q2']],
        ['checked standard', 'Le sue ampiezze di Clebsch–Gordan del §15.6 a j = j_A + j_B − 1 sono riprodotte, numericamente, per cinque coppie (j_A, j_B): una prova del testo, non dell’atlante.', ['qm·Q9a', 'qm·Q9b']],
        ['checked standard', 'Stern–Gerlach (§1.1): con i proiettori (1 ± e_i)/2 di Cl(3,0), z poi z fa passare il 100%, z poi x il 50%, e un altro z ancora il 50%, come nelle sue figure, perché e₃ ed e₁ anticommutano.', ['qm·Q12']]] },
    ],
  },
  bands: {
    h: 'Bande e lacune di un potenziale periodico',
    findings: [
      { id: 'F13', title: 'Le bande del capitolo 20 come segno di X²', lines: [
        ['checked standard', 'Il capitolo 20 delle note quantistiche dà la matrice di un periodo M di un potenziale periodico, det M = 1 (suo Lemma 20.8); un’energia è permessa quando ½ Tr M sta in [−1, 1]. Una matrice reale 2×2 di determinante 1 è un multivettore unitario di Cl(2,0) = M₂(ℝ) e ½ Tr M è la sua parte scalare g; si scriva M = g + X: X² = g² − 1 è uno scalare.', ['fibre·G5a', 'Thm T19']],
        ['checked standard', 'Banda: X² < 0, i moltiplicatori sono e^{±iθ}. Lacuna: X² > 0, moltiplicatori reali con prodotto 1. Bordo di banda: X² = 0 con X ≠ 0, un blocco di Jordan (la soluzione periodica o antiperiodica). M = ±I ha X = 0 e potenze limitate. Calcolato su 500 potenziali ed energie a caso e, numericamente, in 7 bordi di banda di un potenziale trovati per bisezione (X² = 0 a meno di 10⁻⁷).', ['fibre·G5d', 'fibre·G5e', 'scw·P2']],
        ['checked standard', 'I pezzi sono i tre tipi di elemento: il volo libero sopra il potenziale è cos kl + sin kl · n con n² = −1, sotto è cosh + sinh · n con n² = +1, un calcio delta 1 + g n con n² = 0. La condizione del pettine di Dirac cos θ = cos kl + (g/2k) sin kl è la parte scalare di (calcio)(volo); il prodotto dei pezzi coincide con un’integrazione numerica dell’equazione.', ['fibre·G5b', 'fibre·G5c', 'fibre·G5f']],
        ['checked standard', 'È la suddivisione da manuale di SL(2,ℝ) in ellittico, parabolico e iperbolico (Thm T19).', ['Thm T19']],
        ['ours', 'Grouping band, edge and gap (the sign of X², the square of an element) with the other places of the sign trio −1, 0, +1 is ours.', []]] },
    ],
  },
  stops: {
    h: 'Dove la regola si ferma',
    items: [
      ['open', 'Incollare. Topologia, fibrati e connessioni come sezioni su una varietà: l’atlante è algebra punto per punto e combinatoria finita, i suoi campi sono polinomi in una carta. La riga L4 resta una lacuna.'],
      ['open', 'Un principio d’azione. Nessuna lagrangiana e nessuna variazione, quindi nessuna equazione di chiusura: le righe C7 e C8 non sono ricostruite, e la condizione che distingue l’energia (riga C12) non ha corrispondente.'],
      ['open', 'Dimensione infinita. Spazi di Banach e di Hilbert, il teorema spettrale e lo spazio di Fock bosonico (riga M2); misura e stati misti oltre Cl(3,0) (riga M10).'],
      ['open', 'Analisi. Il capitolo 20 è raggiunto solo attraverso la sua matrice di un periodo, non attraverso lo spettro dell’operatore di Schrödinger.'],
    ],
  },
  persp: {
    h: 'Prospettive',
    intro: 'Offerte alla sua parte come domande; ognuna è nostra o aperta, e nessuna è un’affermazione sulla natura.',
    items: [
      { id: 'P1', h: 'Un capitolo su Clifford fra il 12 e il 15', lines: [
        ['ours', 'Le sue lezioni di geometria vanno dalle forme (cap. 12) ai gruppi di Lie, a SL(2,ℂ) (cap. 15) e al Casimir (cap. 17); le note passano dal capitolo 12 al capitolo 15 senza nominare un’algebra di Clifford. Una sola tabella (F1), che mette SL(2,ℂ) a un indirizzo calcolato (F5), sarebbe un ponte utile fra i due?', []]] },
      { id: 'P2', h: 'Le condizioni sulla materia come mappa di celle', lines: [
        ['checked', 'Per P quadratico la prima condizione è la mappa (k,d) di F2.', ['bridge·B1–B3']],
        ['checked standard', 'Per ampiezze reali, gli stati prodotto sono il cono nullo di det su M₂(ℝ), segnatura (2,2); su ℂ la condizione è det = 0 su M₂(ℂ).', ['qm·Q10a', 'qm·Q10b']],
        ['ours', 'Il legame di quel (2,2) con l’iperbolicità è nostro.', []],
        ['open', 'La seconda e la terza condizione disegnano una mappa simile per il P quartico della metrica d’area?', []]] },
      { id: 'P3', h: 'L’algebra delle deformazioni in più dimensioni', lines: [
        ['open', 'Nel modello 1+1 congelato ε è la classe di segno della costante c = (deg P − 1)p¹¹, ed entrambe le deformazioni sono funzioni su una retta; per d > 1, Witt ⊗ A_ε non vale alla lettera. Esiste una famiglia nel segno ε con membri euclideo, di tipo Carroll e lorentziano? Solo il modello 1+1 congelato.', []]] },
      { id: 'P4', h: 'Le costanti della metrica d’area e l’ottaedro', lines: [
        ['open', 'Le undici o più costanti della chiusura dell’elettrodinamica lineare generale si ordinano secondo 6 + 12 + 3, o secondo i pezzi invarianti delle 21 (F4)? Lo direbbe una verifica del rispetto dell’una o dell’altra suddivisione da parte delle equazioni di chiusura.', []]] },
      { id: 'P5', h: 'Un solo oggetto per Grassmann e Fock', lines: [
        ['checked standard', 'Il suo corso di geometria costruisce Λ(V) come forme (cap. 12) e il suo corso quantistico costruisce ∧F come spazio di Fock fermionico (§21.4): la stessa algebra esterna; l’esclusione di Pauli del §14.4 è e² = 0 nella regola tutta nulla.', ['qm·Q6', 'bridge·A1']],
        ['ours', 'Etichetta di bit = schema di occupazione è una nostra lettura.', []]] },
      { id: 'P6', h: 'Chiusura con materia spinoriale', lines: [
        ['open', 'Il suo articolo tratta la materia di Dirac solo attraverso il suo tensore principale. Una chiusura che conservi la tetrade e lo spinore richiederebbe la struttura che l’atlante ha al livello della fibra (passi 4, 5, 9, 12)? Oltre ciò che possiamo mettere alla prova.', []]] },
      { id: 'P7', h: 'Un segnale di convenzione', lines: [
        ['checked', 'I segni di Dirac delle note (F9) sono decisi nell’algebra: la svista è il fattore i, non la cella.', ['fibre·G4b', 'qm·Q11b', 'Thm T16']],
        ['open', 'Solo il video della lezione mostrerebbe se la forma stampata sia del docente o della trascrizione; facoltativo.', []]] },
      { id: 'P8', h: 'Λ e il generatore in più', lines: [
        ['ours', 'Il segno di Λ nella sua chiusura della materia di Klein–Gordon e il quadrato s ∈ {0, −1, +1} del generatore in più dell’atlante (piatto, de Sitter, anti-de Sitter) letti insieme come Λ ~ −s·κ². Nostro; non messo alla prova con le sue equazioni.', []]] },
      { id: 'P9', h: 'Una casa di Clifford per le classi di Floquet', lines: [
        ['checked standard', 'Banda, bordo e lacuna sono il segno di X² per la matrice di un periodo (F13); le stesse tre classi ordinano gli elementi di SL(2,ℝ).', ['fibre·G5a–f', 'Thm T19']],
        ['ours', 'Metterle accanto all’algebra delle deformazioni congelata (F3) è nostro.', []]] },
      { id: 'P10', h: 'Base e fibra come sinistra e destra', lines: [
        ['ours', 'Una controparte algebrica locale dei suoi fibrati: l’azione destra semplice è una fibra che commuta, dello stesso tipo, quella con il segno del grado è la speculare (F10, F11).', []],
        ['open', 'Esiste una versione globale? È ciò che la riga L4 lascia aperto.', []]] },
    ],
  },
  quantum: {
    h: 'Integrare le lezioni quantistiche',
    readH: 'Letto finora, in parte',
    read: 'Capitoli 1 (desiderata, assiomi, Stern–Gerlach), 12.4 (posizione, impulso, momento angolare), 13 (spin, Casimir, operatori a scala), 14 (prodotti tensoriali, entanglement), 15 (spin totale, Clebsch–Gordan), 16.2–16.3 (scala dell’oscillatore), 17.3 e 17.5 (misura e stati misti), 19.4 e 20 (potenziali periodici, matrice di Floquet, bande) e 21 (Schrödinger, Klein–Gordon, Dirac, spazio di Fock). Non letti: 2–11, 12.1–12.3, il resto del 16 e dei capitoli 17–19.',
    itemsH: 'Le cinque voci del piano del rapporto, e a che punto sono',
    items: [
      ['checked open', '1. Capitolo 17, gli stati misti come (1 + v)/2 in Cl(3,0) e la regola delle probabilità come traccia: risposto per n = 3 dal capitolo sulle categorie (la palla di Bloch, 2⟨ρP⟩₀ = (1 + v·u)/2; con generatori nulli ogni stato si annulla sul radicale); le altre segnature sono aperte.', ['cat·C2', 'cat·C3', 'Thm T15']],
      ['checked open', '2. Capitoli 8–11, l’ombra finita del teorema spettrale (blade che commutano con quadrato +1 e i loro proiettori): i conteggi sono fatti nel capitolo sulle categorie; il legame con la contestualità è aperto.', ['cat·W1–W3']],
      ['checked open', '3. Capitolo 16, l’oscillatore fermionico contro la scala bosonica: le relazioni coincidono quando il commutatore diventa un super-commutatore (la super-dimensione dello spazio delle etichette è 0); il limite è aperto.', ['cat·B1', 'Thm T20']],
      ['checked', '4. The Dirac signs (F9): settled in the algebra.', ['fibre·G4b', 'qm·Q11b']],
      ['open', '5. Una sola matrice combinata: le righe dei tre rapporti stanno in una sola matrice di traduzione nella pagina per i ricercatori, ma non sono ordinate lungo la sua catena.', []],
    ],
  },
  notes: {
    h: 'Note sui testi come pubblicati (non confermate)',
    intro: 'Le note quantistiche sono la trascrizione di uno studente, non approvata dal docente; il video può differire. Queste sono note su quel testo.',
    items: [
      ['checked open', 'F9. Le note (§21.3, nota 54) scrivono (iγ^μ∂_μ − m)Ψ = 0 con {γ^μ, γ^ν} = 2η^{μν} e η = diag(−1, 1, 1, 1): allora γ⁰ ha quadrato −1 e i γ_a +1, la cella Cl(3,1) = M₄(ℝ) all’orologio 2, e il simbolo sull’onda piana si annulla a E² = |p|² − m², il segno sbagliato per una massa. L’equazione di Klein–Gordon delle note stesse ha il segno giusto, quindi si legge come una svista di convenzione fra due sezioni. La svista è il fattore i, non la cella: l’operatore reale γ·∂ − m di Cl(3,1) ha il guscio fisico.', ['qm·Q11a–c', 'fibre·G4b', 'Thm T16']],
      ['ours', 'F13. La traccia è scritta ψ₁(a) + ψ₂(a) dove la condizione delle bande usa ψ₁(a) + ψ₂′(a): una nostra lettura di una svista della trascrizione.', []],
      ['standard', 'F13. Lo spettro è chiamato unione di intervalli aperti; l’enunciato standard ha bande chiuse, con i bordi (i punti parabolici) inclusi (Floquet–Bloch, richiamato).', []],
    ],
  },
  questions: {
    h: 'Domande',
    items: [
      ['open', 'Per il P quartico della metrica d’area, la seconda e la terza condizione disegnano una mappa come quella dell’iperbolicità delle celle (P2)?', []],
      ['open', 'P non separa Cl(1,3) da Cl(3,1), eppure in Cl(3,1) esiste un operatore di Dirac reale (di Majorana) (Thm T16(3)). La materia di Majorana farebbe vedere la differenza alla catena della chiusura?', []],
      ['open', 'Oltre 1+1, esiste una famiglia nel segno ε dell’algebra delle deformazioni congelata con membri euclideo, di tipo Carroll e lorentziano (P3)?', []],
      ['open', 'Le costanti di chiusura dell’elettrodinamica lineare generale rispettano la suddivisione invariante delle 21, e una chiusura può conservare la tetrade e lo spinore (P4, P6)?', []],
      ['ours open', 'Il segno di Λ segue il quadrato s del generatore in più, Λ ~ −s·κ² (P8)? Nostro; non messo alla prova con le sue equazioni.', []],
      ['open', 'Esiste una versione globale di base e fibra come azioni sinistra e destra (P10, riga L4)?', []],
      ['open', 'For r ≥ 1 the quadratic principal polynomial is at best weakly hyperbolic and its gradient misses the null directions: is the dual polynomial of his second condition defined there, and are null generators then excluded by the second condition rather than by the first (closure paper, Sect. II: pointer, source unread)?', []],
    ],
  },
  honest: {
    h: 'L’elenco onesto',
    items: [
      ['checked', 'Le forme e le celle dell’atlante hanno una sola tabella di moltiplicazione: cambiano solo i quadrati.', ['bridge·A1', 'bridge·A2']],
      ['checked standard', 'For r = 0 a quadratic principal polynomial is hyperbolic exactly for a Lorentzian signature, one sign against all the others; with null generators a hyperbolic direction exists for one plus or one minus generator, never a strict one. That this selects the Lorentzian metric is his result.', ['bridge·B1–B5', 'Thm T18', 'bd·geo·8', 'bd·xck·5']],
      ['checked standard', 'Tenendo fisso l’8, la base Cl(0,k) ha dimensione 2^k e il suo commutante 2^{8−k}, il prodotto resta 256, ed entrambi hanno lo stesso tipo; localmente l’algebra totale è il prodotto graduato di base e fibra.', ['fibre·G3a–e', 'fibre·G1a–c']],
      ['ours', 'I nomi base e fibra, fuori e dentro, sono nostri.', []],
      ['checked standard', 'Una seconda particella in un modo pieno non dà nulla (ε_k² = 0), e tre magneti di Stern–Gerlach danno 100%, 50%, 50%.', ['qm·Q1a–d', 'qm·Q5–Q7', 'qm·Q12']],
      ['ours', 'Bands, orbits and springs as one trio −1, 0, +1 is ours (the bands and the springs sort the square of an element, the orbits the square of the extra generator); so is Λ ~ −s·κ², untested against his equations.', []],
      ['open', 'Le sue equazioni della gravità richiedono di incollare e un’azione; non le abbiamo ricostruite (righe C7, C8; L4).', []],
    ],
  },
  bar: {
    h: 'La barra di onestà e la matrice di traduzione',
    note: 'E significa la stessa identità algebrica, punto per punto, in una carta; non è un’affermazione sulla sua teoria.',
    matrixFold: 'La matrice di traduzione di questo capitolo',
  },
  thm: {
    h: 'I teoremi su cui si appoggia questo capitolo',
    intro: 'Ognuno è un teorema della pagina per i ricercatori; il suo stato e il verdetto del verificatore indipendente sono letti da lì. “Dimostrato qui” significa dimostrato per l’atlante e ricavato di nuovo una volta da un lettore indipendente: non ancora esaminato da uno specialista.',
    status: 'Stato', verifier: 'Verificatore',
    items: [
      { id: 'T3', line: ['checked standard', 'Thm T3, ogni (p,q,r): λ, il coefficiente di e_F, è una forma di Frobenius per ogni segnatura, generatori nulli compresi; il suo automorfismo di Nakayama è l’identità per n dispari e l’involuzione di grado per n pari; una forma simmetrica esiste se e solo se n è dispari o r = 0.', ['Thm T3']] },
      { id: 'T16', line: ['checked standard', 'Thm T16, ogni (p,q,r): (P − m)(P + m) = Q(k) − m²; det(P − m | V) = (m² − Q(k))^{N/2} con due eccezioni; un impulso nullo non entra mai; in Cl(3,1) il γ·∂ − m reale ha il guscio fisico, e la i è la i di Fourier.', ['Thm T16']] },
      { id: 'T18', line: ['checked standard', 'Thm T18(f), r = 0: un polinomio principale quadratico è iperbolico se e solo se la sua segnatura è lorentziana.', ['Thm T18']] },
      { id: 'T19', line: ['checked standard', 'Thm T19, SL(2,ℝ): X² = g² − 1; ellittico, parabolico, iperbolico secondo il segno di X²; per un potenziale periodico banda se e solo se X² < 0 e lacuna se e solo se X² > 0, e un bordo è X² = 0 con X ≠ 0.', ['Thm T19']] },
      { id: 'T20', line: ['checked standard', 'Thm T20, ogni m: Cl(m,m) ≅ End Λ(ℝ^m); la base delle etichette è la base di Fock e l’operatore numero è il numero di bit accesi; [a, a⁺] = 1 non ha soluzioni in dimensione finita.', ['Thm T20']] },
    ],
  },
  scripts: {
    h: 'Gli script',
    report: { lead: 'Full report:', title: 'Schuller’s lectures read as fibre and base', file: 'reports/html/schuller_bridge_report.html' },
    intro: 'Tre script ricalcolano ogni affermazione con l’etichetta verificato in questo capitolo; richiedono Python 3 e numpy, e ognuno gira in pochi secondi. Lo script dei widget (lens_sch_check.py) controlla i numeri che i widget mostrano.',
    files: [
      { file: 'selfcheck/reports/fibre_check.py', note: 'Fibra e base, controlli G1–G9: 35 controlli.' },
      { file: 'selfcheck/reports/bridge_check.py', note: 'La catena, controlli A–F: 77 controlli (B1 gira una volta per segnatura).' },
      { file: 'selfcheck/reports/bridge_check_qm.py', note: 'Le lezioni quantistiche, controlli Q1–Q12: 51 controlli.' },
    ],
    run: 'cd selfcheck/reports; python3 fibre_check.py; python3 bridge_check.py; python3 bridge_check_qm.py',
    sabotage: 'Sabotaggi: 21 mutazioni deliberate dei controlli sono colte dallo script automatico di mutazione del rapporto (mutate_fibre.py, distribuito con il rapporto), e altre 16 sono state provate a mano quando i controlli sono stati scritti.',
    widgets: 'Lo script dei widget',
  },
  sources: {
    h: 'Fonti',
    langNote: 'I titoli dei lavori sono citati in inglese, come sono pubblicati.',
    items: [
      'F. P. Schuller, Lectures on the Geometric Anatomy of Theoretical Physics, FAU Erlangen-Nürnberg 2013/14; appunti di S. Rea, aggiornati al 25 ottobre 2017 (letti in capitoli scelti).',
      'M. Düll, F. P. Schuller, N. Stritzelberger, F. Wolz, Gravitational closure of matter field equations, arXiv:1611.08878 v3, 2018 (letto in parte).',
      'F. P. Schuller, Constructive Gravity: Foundations and Applications, articolo di rassegna, 15° Marcel Grossmann Meeting, arXiv:2003.09726, 2020.',
      'F. P. Schuller, Lectures on Quantum Theory, FAU 2015; appunti di S. Rea e R. Dadhley, 31 gennaio 2019 (letti in parte; gli appunti dicono di non essere approvati dal docente).',
      'M. Bojowald, E. I. Duque, A. Shah, Hypersurface deformations, arXiv:2410.18807 (al livello del riassunto, per la forma dell’algebra delle deformazioni).',
    ],
  },
};

// ---------------------------------------------------------------- the Young Learner: plain words, no formulas (EN and IT, same shape)
// Words of the app: switch (plus, minus or zero), box = cell, corner = label, outside / inside (page 1), a paired zero = a zero made from a pair.
// Under a widget the Young Learner reads the widget's own tagged caption (SchullerWidgets.jsx); the lines here add only what the caption does not say.
const YL_EN = {
  title: 'Schuller’s chain: from how matter moves to the law of gravity, and how far our rule can follow',
  lede: 'Our rule follows two of his first three steps exactly and loses the trail where motion over a whole space begins; we did not rebuild his gravity equations.',
  intro: [
    'Schuller is a physicist who teaches how geometry and physics fit together. In his work on gravity he starts from how matter and light move, and goes step by step to the law of gravity. Here we lay his chain of steps beside our switch rule and say, at each step, how far the rule follows.',
    'Every picture on this page is worked out by your browser while you look, three scripts check the same facts, and what any of it means in nature we do not claim.',
  ],
  menuLbl: 'On this page',
  menu: { first: 'Start', chain: 'His chain', table: 'One table', hyper: 'Waves like light', fibre: 'Outside and inside', fock: 'Seats', total: 'Three magnets', bands: 'Bands', stops: 'Where it stops', honest: 'Honest list', bar: 'How close', scripts: 'Scripts' },
  chain: {
    h: 'His chain, our trail',
    text: ['His chain has seven stones. At the first three the question is what a way of measuring lengths allows; at the last four it is how things move over a whole space. Tap a stone to see how close our rule comes there.'],
    lines: [
      ['checked', 'Two of his seven stones match our rule exactly, and a script checks both.', ['bridge·B1–B5']],
      ['ours', 'The other stones match only in shape, or only as our reading: how close each one comes is our judgement, shown stone by stone.', []],
    ],
  },
  table: {
    h: 'One table, three choices',
    text: ['Take two or three switches. Our rule says where the product of two corners lands, and with which sign. Schuller’s geometry course uses the very same table for what it calls forms: there every switch is a zero switch, whose square is nothing. Set the switches to plus or minus instead and you get the boxes of the atlas.'],
    lines: [],
  },
  hyper: {
    h: 'Which boxes let waves travel like light',
    text: ['Schuller asks which ways of measuring lengths let light and matter send waves forward in time, neither stuck in place nor blowing up. With switches the answer is a count.'],
    lines: [
      ['checked standard', 'Light-like waves need exactly one plus switch or exactly one minus switch, with at least two switches in all. That this picks our space-time is Schuller’s result.', ['bridge·B1–B5', 'Thm T18']],
      ['checked standard', 'Boxes whose switches are all plus or all minus fail; so do boxes with at least two of each kind, the first of them having two plus and two minus switches.', ['bridge·B1', 'bridge·B3']],
    ],
  },
  fibre: {
    h: 'Outside and inside',
    text: [
      'Page 1 split every picture into outside, where things are, and inside, hidden turning clocks. Here is one way to make that exact. Take a box of eight minus switches: it has 256 pieces. Choose some of its switches as the outside. The inside is everything that never gets in the way of the outside moves.',
      'Move a switch out of the outside: the outside halves and the inside doubles, so their two sizes multiplied together always make 256. And both sides are made of the same kind of numbers.',
    ],
    lines: [
      ['ours', 'Calling them outside and inside, and what they are in physics, is our reading.', []],
    ],
  },
  fock: {
    h: 'Seats and particles',
    text: [
      'Three seats, each empty or full: that makes eight patterns, the eight corners of a cube. One pattern has no particle, three have one, three have two and one has three.',
      'Putting a second particle into a full seat gives nothing: that is Pauli’s rule. It is a paired zero, because taking the particle out again is its partner.',
    ],
    lines: [
      ['ours', 'Reading a corner of the cube as a pattern of full seats is our reading.', []],
    ],
  },
  total: {
    h: 'Three magnets',
    text: ['A beam of tiny magnets goes through three filters, one after the other. If they all point the same way, every magnet passes. Turn the middle filter sideways: half pass. The third filter, pointing the first way again, lets half of those through.'],
    lines: [],
  },
  bands: {
    h: 'Allowed and forbidden energies',
    text: ['A wave runs along a row of equal kicks, like a ball rolling over a row of equal bumps. At some energies it travels on forever, at others it cannot get through. One number, worked out from a box with two plus switches, decides which: is it below zero, at zero or above zero?'],
    lines: [
      ['ours', 'Seeing here the same three signs as the switches have (minus, zero, plus) is our reading.', []],
    ],
  },
  stops: {
    h: 'Where our rule stops',
    lines: [
      ['open', 'His gravity equations need many small pieces of space glued into a whole, and a rule that picks the motion; we did not rebuild them.', []],
      ['open', 'Our rule works at one point at a time, with a finite number of switches; spaces with endless directions are out of its reach.', []],
    ],
  },
  honest: {
    h: 'What we checked, what is our idea, what is open',
    lines: [
      ['checked', 'Forms and the atlas’s boxes share one table.', ['bridge·A1', 'bridge·A2']],
      ['checked standard', 'Light-like waves need exactly one plus or one minus switch. That this picks our space-time is Schuller’s result.', ['bridge·B1–B5']],
      ['checked standard', 'Outside halves, inside doubles, the two sizes multiply to 256, with the same kind of numbers on both sides.', ['fibre·G3a–e', 'fibre·G1a–c']],
      ['ours', 'The names outside and inside are ours.', []],
      ['checked standard', 'A second particle in a full seat gives nothing. Three magnets give 100%, 50%, 50%.', ['qm·Q5–Q7', 'qm·Q12']],
      ['ours', 'Bands, orbits and springs as one trio of signs is our reading.', []],
      ['open', 'His gravity equations need gluing pieces of space together and a rule that picks the motion; we did not rebuild them.', []],
    ],
  },
  bar: { h: 'How close does the rule come?', text: 'Each thing from his papers is counted once, by how closely the rule matches it.' },
  scripts: { h: 'The scripts', text: 'Three scripts check every fact marked as checked on this page. You can download them from the fold for older readers below.' },
};

const YL_IT = {
  title: 'La catena di Schuller: da come si muove la materia alla legge della gravità, e fin dove la nostra regola riesce a seguirla',
  lede: 'La nostra regola segue esattamente due dei suoi primi tre passi e perde la traccia dove comincia il moto su uno spazio intero; non abbiamo ricostruito le sue equazioni della gravità.',
  intro: [
    'Schuller è un fisico che insegna come stanno insieme la geometria e la fisica. Nel suo lavoro sulla gravità parte da come si muovono la materia e la luce, e arriva passo dopo passo alla legge della gravità. Qui mettiamo la sua catena di passi accanto alla nostra regola degli interruttori e diciamo, a ogni passo, fin dove la regola lo segue.',
    'Ogni immagine di questa pagina è rifatta dal tuo browser mentre guardi, tre script controllano gli stessi fatti, e che cosa significhi tutto questo in natura non lo affermiamo.',
  ],
  menuLbl: 'In questa pagina',
  menu: { first: 'Inizio', chain: 'La sua catena', table: 'Una tabella', hyper: 'Onde come la luce', fibre: 'Fuori e dentro', fock: 'Posti', total: 'Tre magneti', bands: 'Bande', stops: 'Dove si ferma', honest: 'Elenco onesto', bar: 'Quanto vicino', scripts: 'Script' },
  chain: {
    h: 'La sua catena, la nostra traccia',
    text: ['La sua catena ha sette pietre. Nelle prime tre la domanda è che cosa permette un modo di misurare le lunghezze; nelle ultime quattro è come si muovono le cose su uno spazio intero. Tocca una pietra per vedere quanto si avvicina lì la nostra regola.'],
    lines: [
      ['checked', 'Due delle sue sette pietre coincidono esattamente con la nostra regola, e uno script le controlla entrambe.', ['bridge·B1–B5']],
      ['ours', 'Le altre pietre coincidono solo nella forma, o solo come nostra lettura: quanto si avvicina ciascuna è un nostro giudizio, mostrato pietra per pietra.', []],
    ],
  },
  table: {
    h: 'Una tabella, tre scelte',
    text: ['Prendi due o tre interruttori. La nostra regola dice dove cade il prodotto di due angoli, e con quale segno. Il corso di geometria di Schuller usa proprio la stessa tabella per quelle che chiama forme: lì ogni interruttore è un interruttore zero, il cui quadrato è nulla. Metti invece gli interruttori a più o a meno e ottieni le scatole dell’atlante.'],
    lines: [],
  },
  hyper: {
    h: 'Quali scatole lasciano viaggiare le onde come la luce',
    text: ['Schuller chiede quali modi di misurare le lunghezze permettono alla luce e alla materia di mandare onde avanti nel tempo, senza restare ferme e senza esplodere. Con gli interruttori la risposta è un conto.'],
    lines: [
      ['checked standard', 'Le onde come la luce richiedono esattamente un interruttore più o esattamente un interruttore meno, con almeno due interruttori in tutto. Che questo scelga il nostro spazio-tempo è un risultato di Schuller.', ['bridge·B1–B5', 'Thm T18']],
      ['checked standard', 'Le scatole con interruttori tutti più o tutti meno non passano; non passano nemmeno quelle con almeno due interruttori di ciascun tipo, la prima delle quali ha due interruttori più e due meno.', ['bridge·B1', 'bridge·B3']],
    ],
  },
  fibre: {
    h: 'Fuori e dentro',
    text: [
      'La pagina 1 divide ogni immagine in fuori, dove stanno le cose, e dentro, orologi nascosti che girano. Ecco un modo di renderlo esatto. Prendi una scatola con otto interruttori meno: ha 256 pezzi. Scegli alcuni dei suoi interruttori come il fuori. Il dentro è tutto ciò che non ostacola mai le mosse del fuori.',
      'Togli un interruttore dal fuori: il fuori si dimezza e il dentro raddoppia, quindi le loro due grandezze moltiplicate fanno sempre 256. E i due lati sono fatti dello stesso tipo di numeri.',
    ],
    lines: [
      ['ours', 'Chiamarli fuori e dentro, e che cosa siano in fisica, è una nostra lettura.', []],
    ],
  },
  fock: {
    h: 'Posti e particelle',
    text: [
      'Tre posti, ognuno vuoto o pieno: fanno otto schemi, gli otto angoli di un cubo. Uno schema non ha particelle, tre ne hanno una, tre ne hanno due e uno ne ha tre.',
      'Mettere una seconda particella in un posto pieno non dà nulla: è la regola di Pauli. È uno zero accoppiato, perché togliere di nuovo la particella è il suo compagno.',
    ],
    lines: [
      ['ours', 'Leggere un angolo del cubo come uno schema di posti pieni è una nostra lettura.', []],
    ],
  },
  total: {
    h: 'Tre magneti',
    text: ['Un fascio di minuscoli magneti attraversa tre filtri, uno dopo l’altro. Se puntano tutti nello stesso verso, passano tutti i magneti. Gira di lato il filtro di mezzo: ne passa metà. Il terzo filtro, di nuovo nel primo verso, lascia passare metà di quelli.'],
    lines: [],
  },
  bands: {
    h: 'Energie permesse e proibite',
    text: ['Un’onda corre lungo una fila di colpi uguali, come una palla che rotola su una fila di dossi uguali. A certe energie viaggia per sempre, ad altre non riesce a passare. Un solo numero, calcolato da una scatola con due interruttori più, decide quale: è sotto zero, a zero o sopra zero?'],
    lines: [
      ['ours', 'Vedere qui gli stessi tre segni degli interruttori (meno, zero, più) è una nostra lettura.', []],
    ],
  },
  stops: {
    h: 'Dove la nostra regola si ferma',
    lines: [
      ['open', 'Le sue equazioni della gravità richiedono di incollare tanti piccoli pezzi di spazio in un tutto, e una regola che scelga il moto; non le abbiamo ricostruite.', []],
      ['open', 'La nostra regola lavora un punto alla volta, con un numero finito di interruttori; gli spazi con infinite direzioni sono fuori dalla sua portata.', []],
    ],
  },
  honest: {
    h: 'Che cosa abbiamo controllato, che cosa è una nostra idea, che cosa è aperto',
    lines: [
      ['checked', 'Le forme e le scatole dell’atlante hanno una sola tabella.', ['bridge·A1', 'bridge·A2']],
      ['checked standard', 'Le onde come la luce richiedono esattamente un interruttore più o un interruttore meno. Che questo scelga il nostro spazio-tempo è un risultato di Schuller.', ['bridge·B1–B5']],
      ['checked standard', 'Il fuori si dimezza, il dentro raddoppia, le due grandezze moltiplicate fanno 256, con lo stesso tipo di numeri dai due lati.', ['fibre·G3a–e', 'fibre·G1a–c']],
      ['ours', 'I nomi fuori e dentro sono nostri.', []],
      ['checked standard', 'Una seconda particella in un posto pieno non dà nulla. Tre magneti danno 100%, 50%, 50%.', ['qm·Q5–Q7', 'qm·Q12']],
      ['ours', 'Bande, orbite e molle come un solo trio di segni è una nostra lettura.', []],
      ['open', 'Le sue equazioni della gravità richiedono di incollare pezzi di spazio e una regola che scelga il moto; non le abbiamo ricostruite.', []],
    ],
  },
  bar: { h: 'Quanto si avvicina la regola?', text: 'Ogni cosa dei suoi lavori è contata una volta, secondo quanto la regola le si avvicina.' },
  scripts: { h: 'Gli script', text: 'Tre script controllano ogni fatto segnato come controllato in questa pagina. Puoi scaricarli dalla sezione per i lettori più grandi, qui sotto.' },
};

export const COPY = { en: EN, it: IT, yl: { en: YL_EN, it: YL_IT } };
// the stones of his chain in the order of the report's figure
export const CHAIN_GRADES = ['S', 'E', 'E', 'S', 'S', 'S', 'A'];
