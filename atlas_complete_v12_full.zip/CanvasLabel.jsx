// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The name of the atlas picture. The picture is drawn by the owner's SimplexCanvas.jsx (a host file: the package does not ship it and needs no edit of it), which names its
// element itself (for example "Clifford visualization"). App.jsx puts this wrapper around it. For the Young Learner the wrapper gives that element the plain name of the view
// that is shown (ylAtlas.js ylPictureLabel: "Switches picture", "Immagine: Interruttori"); for the other audiences the host's own name stands, and when the reader leaves the
// Young Learner view the wrapper puts the host's name back. The wrapper adds no box to the layout (display: contents).
// The labelled element is the first element inside the wrapper that carries an aria-label (the host's div.canvas), else the host's outer element.
// The wrapper runs after every render of its own (a layout effect: after React has written the host's props to the page, before the browser paints), so a name the host
// writes again (another view, another cell) is replaced at once; the host component re-renders only with its parent, so it cannot write a name the wrapper does not see.
import React, { useLayoutEffect, useRef } from 'react';
import { ylPictureLabel } from './ylAtlas.js';

export default function CanvasLabel({ yl, view, lang, children }) {
  const box = useRef(null), st = useRef({ el: null, host: null, mine: null });   // st: the labelled element, the host's own name for it, the name this wrapper wrote (null: none)
  useLayoutEffect(() => {
    const b = box.current; if (!b) return;
    const el = b.querySelector('[aria-label]') || b.firstElementChild, s = st.current; if (!el) return;
    if (s.el !== el) { s.el = el; s.host = null; s.mine = null; }
    const cur = el.getAttribute('aria-label');
    if (s.mine === null || cur !== s.mine) s.host = cur;   // a name this wrapper did not write is the host's own
    if (yl) { s.mine = ylPictureLabel(view, lang); if (cur !== s.mine) el.setAttribute('aria-label', s.mine); }
    else if (s.mine !== null) { if (cur === s.mine) { if (s.host === null) el.removeAttribute('aria-label'); else el.setAttribute('aria-label', s.host); } s.mine = null; }
  });
  return <div className="canvas-label" ref={box} style={{ display: 'contents' }}>{children}</div>;
}
