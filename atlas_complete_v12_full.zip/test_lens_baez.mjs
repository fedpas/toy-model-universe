// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_lens_baez.mjs: the words of the Baez chapter (step 19 of the lenses page), without a browser. baezCopy.js in English and Italian has the same shape,
// the same tags and the same check ids line by line; four flags only; a line that says "ours" or "open" carries that tag and known ground holds no reading;
// every line tagged checked names a namespaced check id that exists in a shipped script (selfcheck/reports/*.py) or a theorem with its check script;
// no retired wording (DECISIONS.md §2 and X10 of the v10.2 round); the Young Learner's words have no formula and no jargon; the mirror of baez_check.py is
// the file byte for byte; the Map nodes point at anchors of BaezSection.jsx and at existing scripts; the claims rows resolve; the persona fits; the numbers
// the chapter quotes are recomputed here (five-bit labels, the E8 Levi ladder, the eleven signatures, the Eisenstein shells, the 117 patterns, Madelung,
// the honesty counts from the matrix). Run: node test_lens_baez.mjs   (exit 1 on a failure)
import fs from 'node:fs'; import path from 'node:path';
import { PKG } from './paths.mjs'; process.chdir(PKG);
import { COPY, PAPERS, TEN_ROWS, GAP_IDS, SECTIONS, SECTIONS_YL } from './baezCopy.js';
import { MAP_NODES, MAP_TEXT, PERSONA } from './baezIntegration.js';
import { BAEZ_CHECK_PY } from './baezSelfcheckSource.js';
import { LENSES, MTHREADS } from './mapData.js';
import { THEOREMS } from './researchersData.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { buildClaims } from './make_claims_data.mjs';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8');
const FOUR = ['checked', 'standard', 'ours', 'open'];
const flags = k => (Array.isArray(k) ? k : String(k || '').split(/\s+/)).filter(Boolean);

// ---- every tagged line of the copy: [where, tags, text, ids]; a tagged line is an array whose first element is a tag string and second a text
const LINES = [];
function walk(o, p, out) {
  if (Array.isArray(o) && o.length >= 2 && typeof o[0] === 'string' && typeof o[1] === 'string' && flags(o[0]).length && flags(o[0]).every(f => FOUR.includes(f) || /^[a-z]+$/.test(f)) && flags(o[0]).some(f => FOUR.includes(f))) { out.push([p, flags(o[0]), o[1], Array.isArray(o[2]) ? o[2] : []]); return out; }
  if (o && typeof o === 'object' && !Array.isArray(o) && typeof o.kinds === 'string' && typeof o.text === 'string') { out.push([p + '.text', flags(o.kinds), o.text, []]); if (o.q) out.push([p + '.q', flags(o.qKinds), o.q, []]); return out; }
  if (Array.isArray(o)) o.forEach((x, i) => walk(x, p + '[' + i + ']', out)); else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) walk(v, p + '.' + k, out);
  return out;
}
const lines = (o, p) => walk(o, p, []);
const EN = lines(COPY.en, 'en'), IT = lines(COPY.it, 'it'), YEN = lines(COPY.yl.en, 'yl.en'), YIT = lines(COPY.yl.it, 'yl.it');
LINES.push(...EN, ...IT, ...YEN, ...YIT);
ok(EN.length > 100 && YEN.length > 25, `the copy holds tagged lines (${EN.length} formal, ${YEN.length} plain)`);
// every string of an object (for the word sweeps), functions called with a sample id
const strings = (o, p = '', out = []) => { if (typeof o === 'string') out.push([p, o]); else if (typeof o === 'function') { try { strings(o('J9'), p + '()', out); } catch { /* not a text function */ } } else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) strings(v, p + '.' + k, out); return out; };

// ---- 1. EN / IT parity: the same shape, the same tags, the same check ids, line by line
const shape = o => (typeof o === 'function' ? 'fn' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o);
ok(JSON.stringify(shape(COPY.en)) === JSON.stringify(shape(COPY.it)), 'formal voice: English and Italian have the same shape');
ok(JSON.stringify(shape(COPY.yl.en)) === JSON.stringify(shape(COPY.yl.it)), 'Young Learner: English and Italian have the same shape');
// English also in the Italian slots (v11): the lines below carry the English text in both slots; the list names them and must not rot
const EN_IN_IT = ['en.findings[4].lines[0]', 'en.findings[7].lines[0]', 'en.findings[7].lines[2]', 'en.findings[7].lines[3]', 'en.findings[7].lines[4]', 'en.findings[7].lines[5]', 'en.notes[0]', 'en.findings[4].lines[6]', 'en.findings[6].lines[3]', 'en.findings[9].lines[2]', 'en.findings[9].lines[3]', 'en.ledeM[12]', 'en.ledeM[13]', 'en.ledeM[14]', 'en.persp[6].text', 'en.questions[4]'];
const atPath = (o, w) => w.replace(/^en\./, '').split(/\.|(?=\[)/).filter(Boolean).reduce((x, k) => x?.[/^\[\d+\]$/.test(k) ? +k.slice(1, -1) : k], o);
// a bridge check of selfcheck/bridges/ is bd·<family>·n (or a range n–m); the alternation reads it before the cat· inside bd·cat·n
const ID_RE = /bd·(?:phy|str|sol|xph|fk|mat|geo|alg|cat|xck|hh|rev|tor|en|fur|kep)·\d+(?:–\d+)?|(baez|bridge|cat|fibre|qm|catw|bzw|scw)·([A-Z]\d*[a-z]?)(?:–([A-Z]\d*[a-z]?))?/g, THM_RE = /Thm (T\d+)/g;
const idsIn = s => [...String(s).matchAll(ID_RE)].map(m => m[0]), thmsIn = s => [...String(s).matchAll(THM_RE)].map(m => m[1]);
for (const [A, B] of [[EN, IT], [YEN, YIT]]) {
  ok(A.length === B.length, `same number of tagged lines (${A.length} / ${B.length})`);
  A.forEach((a, i) => { const b = B[i]; if (!b) return; ok(a[1].join() === b[1].join(), `${a[0]} / ${b[0]}: same tags (${a[1]} / ${b[1]})`);
    ok(JSON.stringify(idsIn(a[2])) === JSON.stringify(idsIn(b[2])) && JSON.stringify(thmsIn(a[2])) === JSON.stringify(thmsIn(b[2])) && JSON.stringify(a[3]) === JSON.stringify(b[3]), `${a[0]}: the same check ids in both languages`);
    ok(a[2] !== b[2] || a[2].length < 40 || EN_IN_IT.includes(a[0]), `${a[0]}: the Italian line is translated, not copied`); });
}
for (const k of ['findings', 'persp']) ok(JSON.stringify(COPY.en[k].map(x => [x.id, x.checks, x.guard])) === JSON.stringify(COPY.it[k].map(x => [x.id, x.checks, x.guard])), `${k}: the same ids, checks and guards in both languages`);

// the chapter block of the perspectives is titled "Perspectives" (the Italian slot carries the same English word); it names no addressee
ok(COPY.en.sec.persp === 'Perspectives' && COPY.it.sec.persp === 'Perspectives' && !/author|autore/i.test(COPY.en.sec.persp + COPY.it.sec.persp) && COPY.en.menu.persp === 'Perspectives' && COPY.it.menu.persp === 'Prospettive', 'the Baez perspectives block is titled "Perspectives" in both slots');
ok(!/Perspectives for the author|Prospettive per l’autore/.test(JSON.stringify(COPY)), 'no block of the Baez copy is addressed to the author');

// ---- 2. four flags only; tags agree with what a line says
for (const [w, t, s] of LINES) {
  ok(t.length > 0 && t.every(f => FOUR.includes(f) || (f === 'input' && /\binput: /.test(s))) && new Set(t).size === t.length, `${w}: four flags only, no repeats, and input only on a line that names its input (${t})`);
  const known = t.includes('standard') && t.includes('checked') && !t.includes('ours') && !t.includes('open') && !t.includes('input');
  const saysOurs = /\b(is|are) ours\b|\bour (reading|remark|computation|identification|observation|idea|link|links)\b|\bis our\b|\bwe drew\b|\bè nostr[oa]\b|\bsono nostri\b|\bnostra (lettura|osservazione|identificazione|idea)\b|\bnostro calcolo\b|\bnostri legami\b|\bnostro legame\b|tracciato noi|\bours\b(?! or open)/i.test(s);
  const saysOpen = /\b(is|stays|remains) open\b|\bOpen[;:,]|\bopen question\b|\bè aperto\b|\bresta aperto\b|\bAperto[;:,]|\bdomanda aperta\b|\bnon confermat|\bunconfirmed\b|no mechanism|nessun meccanismo|found no reason|non abbiamo trovato una ragione/i.test(s);
  ok(!known || (!saysOurs && !saysOpen), `${w}: a line of known ground holds no reading and no open item: ${s.slice(0, 90)}`);
  ok(!saysOurs || t.includes('ours') || /^(yl\.(en|it)|en|it)\.honest\[3\]$/.test(w) && t.join() === 'standard' && /our links?\b|nostri legami|nostro legame/.test(s), `${w}: a line that says something is ours carries the tag ours: ${s.slice(0, 100)}`);
  ok(!saysOpen || t.includes('open'), `${w}: a line that says something is open carries the tag open: ${s.slice(0, 100)}`);
  ok(!t.includes('ours') || !/\bderiv(ed|ation|es)\b|\bderivat[oaie]\b|\bderivazione\b/i.test(s) || /not derive|non deriva/.test(s), `${w}: a line tagged ours says nothing like "derived"`);
}

// ---- 3. every check id exists in a shipped script; every line tagged checked names one; theorems exist with their check script
const SCRIPT = { baez: 'selfcheck/reports/baez_check.py', bridge: 'selfcheck/reports/bridge_check.py', cat: 'selfcheck/reports/cat_check.py', fibre: 'selfcheck/reports/fibre_check.py', qm: 'selfcheck/reports/bridge_check_qm.py', catw: 'selfcheck/reports/lens_cat_check.py', bzw: 'selfcheck/reports/lens_baez_check.py', scw: 'selfcheck/reports/lens_sch_check.py' };
const ORDER = {}; for (const [ns, f] of Object.entries(SCRIPT)) if (fs.existsSync(f)) ORDER[ns] = [...rd(f).matchAll(/\bchk\(\s*['"]([A-Z]\d*[a-z]?)['"]/g)].map(m => m[1]).concat([...rd(f).matchAll(/\bcheck\(\s*['"]([A-Z]\d*[a-z]?)['"]/g)].map(m => m[1]));
ok(ORDER.baez && ORDER.baez.length === 56 && ORDER.baez[0] === 'R1', `baez_check.py holds R1 and the 55 checks that run (${ORDER.baez && ORDER.baez.length} ids)`);
let pending = 0;
const BRIDGES = 'selfcheck/bridges', BD_SRC = fs.existsSync(BRIDGES) ? fs.readdirSync(BRIDGES).filter(f => /\.py$/.test(f)).map(f => [f, rd(BRIDGES + '/' + f)]) : null;
const bdHas = id => BD_SRC.some(([f, t]) => f.startsWith(id.split('·')[1] + '_') && new RegExp(id + '(?!\\d)').test(t));
const expand = id => { const bb = /^bd·([a-z]+)·(\d+)(?:–(\d+))?$/.exec(id); if (bb) { const a0 = +bb[2], z = bb[3] ? +bb[3] : a0; return Array.from({ length: z - a0 + 1 }, (_, i) => `bd·${bb[1]}·${a0 + i}`); }
  const m = /^(\w+)·([A-Z]\d*[a-z]?)(?:–([A-Z]\d*[a-z]?))?$/.exec(id); if (!m) return null; const [, ns, a, b] = m, L = ORDER[ns]; if (!L) return ns in SCRIPT ? 'pending' : null; const i = L.indexOf(a), j = b ? L.indexOf(b) : i; return i >= 0 && j >= i ? L.slice(i, j + 1).map(x => ns + '·' + x) : null; };
const allIds = new Set();
const checkIds = (w, list) => { for (const id of list) { const e = expand(id); if (e === 'pending') { pending++; continue; }
  if (/^bd·/.test(id)) { if (BD_SRC) for (const x of e) ok(bdHas(x), `${w}: bridge check ${x} is a check of ${BRIDGES}/${x.split('·')[1]}_*.py`); else pending += e.length; e.forEach(x => allIds.add(x)); continue; } ok(Array.isArray(e) && e.length > 0, `${w}: check id ${id} exists in ${SCRIPT[id.split('·')[0]] || '?'}`); (e || []).forEach(x => allIds.add(x)); } };
const THM = new Set(THEOREMS.map(t => t.id));
for (const [w, t, s, extra] of LINES) {
  const ids = [...idsIn(s), ...extra], th = thmsIn(s);
  checkIds(w, ids);
  for (const x of th) ok(THM.has(x) && fs.existsSync(`researchers_checks/check_${x}.py`), `${w}: theorem ${x} exists with researchers_checks/check_${x}.py`);
  if (t.includes('checked')) ok(ids.length + th.length > 0, `${w}: a line tagged checked names its checks: ${s.slice(0, 90)}`);
  if (t.includes('checked')) ok(!ids.includes('baez·R1') || ids.length > 1, `${w}: no checked line rests on R1 alone (skipped by the shipped script)`);
}
for (const l of ['en', 'it']) { for (const f of COPY[l].findings) { checkIds(`${l}.${f.id}.checks`, f.checks); const cited = new Set(f.lines.flatMap(x => idsIn(x[1]).flatMap(id => expand(id) || []))); ok(f.checks.every(c => cited.has(c)) && [...cited].every(c => f.checks.includes(c)), `${l} ${f.id}: the Checks line is exactly the ids its lines cite`); }}
ok(['baez·H1a', 'baez·H1b', 'baez·H2a', 'baez·H2b', 'baez·H2c', 'baez·H2d', 'baez·H3f', 'baez·O1a', 'baez·O1b', 'baez·O3a', 'baez·O3h', 'baez·E1a', 'baez·E1c', 'baez·E2a', 'baez·E2d', 'baez·E3a', 'baez·S1', 'baez·S2', 'baez·K1a', 'baez·K1c', 'baez·K2a', 'baez·K2b', 'baez·K3', 'baez·T1a', 'baez·T1b'].every(x => allIds.has(x)), 'the check ids of the brief are all cited and all exist');
ok(allIds.has('bridge·A6') && !LINES.some(([, , s]) => /cat·A6/.test(s)), 'the complement pairing is pinned by bridge·A6 (bridge_check.py), not by a cat·A6 that does not exist');
if (pending) console.log(`  note: ${pending} citations of a widget script (catw·/bzw·/scw·) or of selfcheck/bridges/ (bd·) wait for their files`);

// ---- 4. no retired wording (DECISIONS §2 Retired wording and X10) in any string of the chapter, the Map text or the persona; the chapter has no corrections block
for (const l of ['en', 'it']) ok(!('corrections' in COPY[l]) && !('corrIntro' in COPY[l]) && !('corrCols' in COPY[l]) && !('corrections' in COPY[l].menu) && !('corrections' in COPY[l].sec) && !SECTIONS.includes('corrections') && !('corr' in COPY.yl[l]), `${l}: the chapter has no corrections block`);
ok(!/bz-corrections|bz-corr\b|<del>/.test(rd('BaezSection.jsx')) && !/\bE-\d{3}\b/.test(JSON.stringify(COPY)), 'BaezSection.jsx draws no corrections section and no struck sentence; the copy holds no erratum id');
// present statements of the lens review: the octonion sign function is an input and not a bit-rule cocycle; Kepler against step 11 (opposite printed squares, ε = −s, same classes of bivectors); the E8 roots are those of the Gosset tab
for (const l of ['en', 'it']) { const F = id => COPY[l].findings.find(x => x.id === id), L5 = F('J5').lines[0], L8 = F('J8').lines;
  ok(/different sign function, a 2-cochain whose coboundary is the associator/.test(L5[1]) && /not a bit-rule cocycle/.test(L5[1]) && /the input to the Furey page is not the 64 signs but the property “associativity dropped, no zero divisors”/.test(L5[1]) && /the octonions are the only real division algebra/.test(L5[1]) && /bd·alg·21–22/.test(L5[1]) && L5[0] === 'standard checked' && /baez·O1a/.test(L5[1]), `${l}: J5 says the octonion sign function is not a bit-rule cocycle, and that the input to the Furey page is the property no zero divisors, which forces the table up to gauge (bd·alg·21–22)`);
  { const L = COPY[l].ledeM, H = L.find(x => /Hull’s signatures/.test(x[1])), I2 = L.find(x => /II₂,₁₈/.test(x[1])), O = L.find(x => /^B\.10 \(open\)/.test(x[1]));
    ok(H && H[0] === 'standard checked input' && /M-theory in \(10,1\), \(9,2\), \(6,5\); IIA in \(10,0\), \(9,1\), \(8,2\), \(6,4\), \(5,5\); IIB in \(9,1\), \(7,3\), \(5,5\)/.test(H[1]) && /each with its mirror/.test(H[1]) && /bd·str·7/.test(H[1]) && /input: 32 real supercharges/.test(H[1]), `${l}: B.10 gives Hull's lists from the even part (standard, checked, input; bd·str·7)`);
    ok(I2 && I2[0] === 'checked' && /bd·str·19/.test(I2[1]) && /pointer, source unread/.test(I2[1]) && O && O[0] === 'open' && /remains numerology/.test(O[1]), `${l}: B.10 gives the lattice II₂,₁₈ (bd·str·19) and keeps the link to ℝ^{1,9} open`);
    const J10 = COPY[l].findings.find(x => x.id === 'J10'); ok(/commutative Frobenius monoid in super vector spaces, and not a special one/.test(J10.lines[2][1]) && J10.checks.includes('bd·cat·22') && /For p \+ q ≥ 1 it pairs unlike things/.test(J10.lines[3][1]), `${l}: J10: the null part is a commutative, non-special Frobenius monoid in super vector spaces (bd·cat·22); for p + q ≥ 1 the pairing is of unlike things`);
    const J5 = COPY[l].findings.find(x => x.id === 'J5'), F = J5.lines.find(x => /CD\(ℍ, μ\) with μ = −1, \+1, 0/.test(x[1])); ok(F && F[0] === 'checked' && /bd·alg·16, bd·alg·24/.test(F[1]), `${l}: J5: octonions, split and null octonions as one family on the doubling bit (bd·alg·16, bd·alg·24)`); }
  const K = L8.find(x => /opposite sign of the printed square/.test(x[1])), O = L8.find(x => /three classes of the extra generator against the base/.test(x[1]));
  ok(K && K[0] === 'checked' && /ε = −s/.test(K[1]) && /core·B16/.test(K[1]) && /baez·K1b/.test(K[1]) && !/\btrio\b|spring/i.test(K[1]), `${l}: J8 gives the step 11 comparison as a checked line (ε = −s; baez·K1b, core·B16)`);
  ok(O && O[0] === 'checked' && /^Through Fock’s projection, ellipse, parabola and hyperbola are the three classes of the extra generator against the base\./.test(O[1]) && ['bd·kep·3', 'bd·kep·4', 'bd·kep·5', 'bd·kep·6'].every(x => O[1].includes(x)) && /exactly for s = −ε = sign E/.test(O[1]) && /every hodograph to a geodesic/.test(O[1]) && /Fock and Moser: pointers, sources unread/.test(O[1]) && !/\btrio\b|\bours\b|spring/i.test(O[1]), `${l}: J8 gives the orbits as the three classes of the extra generator through Fock's projection (checked, bd·kep·3–6; Fock and Moser pointers)`);
  const SP = L8[L8.indexOf(O) + 1]; ok(SP && SP[0] === 'ours' && /^The comparison with the spring is ours: the spring’s signs are the squares of bivectors, a different thing from the square of a generator/.test(SP[1]), `${l}: J8 keeps the spring's signs apart in the next line (ours)`);
  const X = L8[0], W = L8[2];
  ok(X[0] === 'standard checked' && /exactly at every phase-space point/.test(X[1]) && /\{A_a, A_b\} = −2μH L_ab/.test(X[1]) && /bd·kep·1/.test(X[1]) && /baez·K1a/.test(X[1]) && !/numerical/.test(X[1]), `${l}: J8 gives the Kepler brackets as exact identities (bd·kep·1), with the finite-difference recomputation (baez·K1a)`);
  ok(W[0] === 'standard checked' && /one Inönü–Wigner family in c = −2μE/.test(W[1]) && /bd·kep·2/.test(W[1]) && !/not in the paper/.test(W[1]), `${l}: J8 gives so(4), e(3), so(3,1) as one Inönü–Wigner family in the energy (bd·kep·2)`);
  ok(COPY[l].findings.filter(f => /roots are the ones of the Gosset tab on the shapes page/.test(JSON.stringify(f))).length >= 1 && /240, 126, 72, 40, 20, 8/.test(JSON.stringify(COPY[l])), `${l}: the E8 ladder points to the Gosset tab for its roots`); }
for (const w of EN_IN_IT) { const a = atPath(COPY.en, w), b = atPath(COPY.it, w), ta = Array.isArray(a) ? a[1] : a, tb = Array.isArray(b) ? b[1] : b; ok(typeof ta === 'string' && ta.length > 40 && ta === tb, `${w}: the named line is English in both slots (the allowance does not rot)`); }
for (const l of ['en', 'it']) ok(COPY[l].report && COPY[l].report.file === 'reports/html/baez_atlas_report.html' && fs.existsSync(COPY[l].report.file) && !('report' in COPY.yl[l]), `${l}: the chapter ends with a link to its full report (the file ships in reports/html/); the Young Learner has none`);
ok(/^Words\. In this atlas label 0 is a generator whose square is 0 \(a lone null direction\); the empty label is the unit 1\. “Zero” has three meanings here/.test(COPY.en.words), 'the words note defines label 0 and the empty label');
const RETIRED = [
  [/(?<!not |non )deriv(e|es|ed) (the )?Standard Model|(?<!non )deriva il Modello Standard/i, 'derives the Standard Model'],
  [/\bbuild(s|ing)? (a|one|the) generation|costruisc\w* (una|la) generazione/i, 'builds a generation'], [/generation builder/i, 'generation builder'],
  [/particle (to|↔|<->|into) antiparticle|particle–antiparticle|particella (in|↔) antiparticella|particella-antiparticella/i, 'particle to antiparticle'],
  [/\bexplain(s|ed|ing)?\b|\bspiega(no|re)?\b/i, 'explains'], [/\bconserved\b|\bconservat[oaie]\b/i, 'conserved'],
  [/Hodge complement|complemento di Hodge/i, 'Hodge complement'], [/Hodge star ?=|XOR with 1…1 is|stella di Hodge è lo XOR/i, 'Hodge star = XOR'],
  [/Schläfli graph srg\(27, ?10|grafo di Schläfli srg\(27, ?10/i, 'Schläfli for srg(27,10,1,5)'], [/no chiral generation inside|nessuna generazione chirale dentro/i, 'no chiral generation inside h3(O)'],
  [/light cone of ten-dimensional|cono di luce .{0,30}dieci dimensioni/i, 'light cone of ten-dimensional Minkowski space'], [/computed by us|calcolat[ae] da noi/i, 'anomaly sums computed by us'],
  [/the labels explain|le etichette spiegano/i, 'the labels explain'], [/Born rule is the Frobenius|regola di Born è la forma di Frobenius/i, 'Born rule = Frobenius form'],
  [/quadric of entangled|quadrica degli stati entangled/i, 'Cl(2,2) quadric of entangled states'], [/ten classes|dieci classi|\binert\b|\bramified\b|Golay|Three 8s|tre 8|quark row|24 = 3 ?× ?8|Majki|\bTian\b|Horizon speculation/i, 'numerology, Majkić, Tian, horizon'],
  [/\bfifth home of the trio\b|\bthe group\b(?! of)/i, '"the group" for a Lie algebra'], [/so\(10\)(?!,ℂ)/, 'so(10) without ℂ (so(5,5) is the real form)'],
];
const SWEEP = [...strings(COPY, 'COPY'), ...strings(MAP_TEXT, 'MAP_TEXT'), ['PERSONA', PERSONA]];
for (const [re, what] of RETIRED) { const hits = SWEEP.filter(([, s]) => re.test(s)); ok(hits.length === 0, `no retired wording (${what}): ${hits.map(h => h[0] + ': ' + h[1].slice(0, 80)).join(' | ')}`); }
// "Hodge" only with "only without null generators"; "label 0" only as a generator of square 0; every (1,9) of the formal voice next to "real 10 vs complex 10"
for (const [w, s] of SWEEP) for (const sen of s.split(/(?<=[.;])\s+/)) {
  if (/Hodge/.test(sen)) ok(/only without null generators|solo senza generatori nulli/.test(sen), `${w}: Hodge only as "a metric Hodge star only without null generators": ${sen}`);
  if (/label 0|etichetta 0/.test(sen)) ok(/square is 0|quadrato è 0|never does|non lo fa mai/.test(sen), `${w}: "label 0" is a generator of square 0, never the empty label: ${sen}`);
}
// every block (a finding, a perspective, the statements B.1–B.10, a line elsewhere, a Map node, the persona) that mentions (1,9) carries "real 10 vs complex 10"
{ const R10 = /real 10 vs complex 10|10 reale contro 10 complesso/i, blocks = [];
  for (const l of ['en', 'it']) { const C = COPY[l];
    for (const f of C.findings) blocks.push([`${l}.${f.id}`, f.title + ' ' + f.lines.map(x => x[1]).join(' ')]);
    for (const p of C.persp) blocks.push([`${l}.${p.id}`, [p.title, p.q, p.text].join(' ')]);
    blocks.push([`${l}.ledeM`, C.ledeM.map(x => x[1]).join(' ')], [`${l}.ledePts`, C.ledePts.map(x => x[1]).join(' ') + ' ' + C.lede], [`${l}.numbers`, C.numbers.map(x => x[1]).join(' ')]);
    for (const k of ['questions', 'honest', 'notes', 'limits', 'dead', 'papersPts']) C[k].forEach((x, i) => blocks.push([`${l}.${k}[${i}]`, x[1]]));
    for (const id of Object.keys(C.papers)) blocks.push([`${l}.papers.${id}`, C.papers[id][1]]);
    for (const [id, v] of Object.entries(MAP_TEXT[l])) blocks.push([`MAP_TEXT.${l}.${id}`, v.join(' ')]); }
  blocks.push(['PERSONA', PERSONA]);
  let seen = 0; for (const [w, s] of blocks) if (/\(1,9\)|1,9\}/.test(s)) { seen++; ok(R10.test(s), `${w}: a block that mentions (1,9) says "real 10 vs complex 10": ${s.slice(0, 100)}`); }
  ok(seen >= 10, `the (1,9) sweep found the mentions (${seen} blocks)`); }
// the trio and the spring's signs only in lines tagged ours
for (const [w, t, s] of LINES) if (/\btrio\b|\bterna\b|spring’s signs|segni della molla/i.test(s)) ok(t.includes('ours'), `${w}: the trio and "the spring's signs" appear only in lines tagged ours: ${s.slice(0, 90)}`);
for (const [w, s] of strings(MAP_TEXT, 'MAP_TEXT')) if (/\btrio\b|\bterna\b|spring’s signs|segni della molla/i.test(s)) ok(/is ours|è nostr|our reading|nostra lettura/i.test(s), `${w}: the trio on the Map is said to be ours`);

// ---- 5. the Young Learner: no formula, no jargon (the lists of test_yl_ui.mjs, plus DECISIONS X0)
const SRC_YL = rd('test_yl_ui.mjs'), SYMBOLS = new RegExp(/const SYMBOLS = \/(.*)\/;\n/.exec(SRC_YL)[1], 'u'), JARGON = new RegExp(/const JARGON = \/(.*)\/i;\n/.exec(SRC_YL)[1], 'i');
const X0 = /\bCl\(|\balgebr|\bradical|Frobenius|Jordan|Peirce|Casimir|Killing|\bLie\b|hypercharge|ipercarica|anomal|octonion|ottonion|Majorana|Weyl|Minkowski|Madelung|tripotent|Schl[äa]fli|Eisenstein|Hamming|\bFock\b|fermion|bivector|bivettor|spinor|matri(x|ce|ci)\b|Standard Model|Modello Standard|\bE[678]\b|\bE₈|label 0|etichetta 0|[α-ωΑ-Ω]/i;
const ylStrings = [...strings(COPY.yl, 'COPY.yl'), ...strings(MAP_TEXT.yl, 'MAP_TEXT.yl')].filter(([w]) => !/\.checks$/.test(w));
for (const [w, s] of ylStrings) { const a = SYMBOLS.exec(s), b = JARGON.exec(s), c = X0.exec(s); ok(!a && !b && !c, `${w}: Young Learner words, no formula or jargon (${(a || b || c || [''])[0]}): ${s.slice(0, 90)}`); }
for (const [w, , , ids] of [...YEN, ...YIT]) for (const id of ids) ok(!SYMBOLS.test(id) && !JARGON.test(id), `${w}: the check codes shown to the Young Learner pass the formula scan (${id})`);
ok(ylStrings.length > 60, `the Young Learner sweep read the plain copy (${ylStrings.length} strings)`);

// ---- 6. the mirror is the file
ok(BAEZ_CHECK_PY === rd('selfcheck/reports/baez_check.py'), 'baezSelfcheckSource.js BAEZ_CHECK_PY equals selfcheck/reports/baez_check.py byte for byte');
ok(/^export const BAEZ_CHECK_PY = ".*";\n$/s.test(rd('baezSelfcheckSource.js')) && rd('baezSelfcheckSource.js').split('\n').length === 2, 'the mirror module is one export on one line (the shape test_license.mjs reads)');
ok(/regen_lens_baez/.test(rd('selfcheck/regen_lens_baez.sh')) && /baez_check\.py/.test(rd('selfcheck/regen_lens_baez.sh')), 'selfcheck/regen_lens_baez.sh writes the mirror');

// ---- 7. the Map: anchors of BaezSection.jsx, scripts that exist, known lenses and threads, text for every node in four voices
const SEC = rd('BaezSection.jsx'), has = a => SEC.includes(`id="${a}"`);
ok(MAP_NODES[0].id === 'baez' && MAP_NODES[0].go.join() === 'lenses,ln-baez' && has('ln-baez'), 'the chapter node comes first and goes to ln-baez');
for (const nd of MAP_NODES) {
  ok(nd.go[0] === 'lenses' && has(nd.go[1]) && (nd === MAP_NODES[0] || /^bz-/.test(nd.go[1])), `${nd.id}: anchor ${nd.go[1]} is an id="…" of BaezSection.jsx`);
  ok(fs.existsSync('selfcheck/' + nd.script), `${nd.id}: script ${nd.script} exists`);
  ok(nd.tags.length && nd.tags.every(x => FOUR.includes(x)) && nd.lens.every(x => LENSES.includes(x)) && nd.th.every(x => MTHREADS.includes(x)), `${nd.id}: four flags, known lenses and threads`);
  for (const [k, T] of [['en', MAP_TEXT.en], ['it', MAP_TEXT.it], ['yl.en', MAP_TEXT.yl.en], ['yl.it', MAP_TEXT.yl.it]]) ok(T[nd.id] && T[nd.id][0].length > 2 && T[nd.id][1].length > 20, `${nd.id}: a title and a text in ${k}`);
}
for (const T of [MAP_TEXT.en, MAP_TEXT.it, MAP_TEXT.yl.en, MAP_TEXT.yl.it]) ok(Object.keys(T).length === MAP_NODES.length, 'no orphan Map text');
ok(new Set(MAP_NODES.map(x => x.id)).size === MAP_NODES.length && MAP_NODES.slice(1).every(x => /^bz_/.test(x.id)), 'node ids are unique and carry the chapter prefix');
for (const s of new Set([...SECTIONS, ...SECTIONS_YL])) { const k = SEC.split(`<Sec id="bz-${s}"`).length - 1; ok(k === (SECTIONS_YL.includes(s) ? 2 : 1), `section ${s}: <Sec id="bz-${s}"> drawn ${k} times (once per voice that has it)`); }
{ const cited = new Set(LINES.flatMap(([, , s]) => thmsIn(s))), listed = /const THM_IDS = \[([^\]]*)\]/.exec(SEC)[1].match(/T\d+/g);
  ok(JSON.stringify([...cited].sort()) === JSON.stringify([...listed].sort()), `the theorem list of the chapter is exactly the theorems its lines cite (${[...cited].sort().join(' ')})`); }
for (const w of ['bz-w-family', 'bz-w-which', 'bz-w-ladder', 'bz-w-kepler', 'bz-w-papers', 'bz-w-ring', 'bz-w-madelung', 'bz-w-script']) ok(has(w), `widget slot ${w} is in BaezSection.jsx`);
ok(new Set(SECTIONS.concat(SECTIONS_YL)).size === SECTIONS.length && SECTIONS_YL.every(s => SECTIONS.includes(s)), 'the plain sections are a subset of the formal ones (one anchor per topic)');
for (const l of ['en', 'it']) { ok(SECTIONS.every(s => COPY[l].menu[s] && COPY[l].sec[s]), `${l}: every section has a menu label and a heading`); ok(SECTIONS_YL.every(s => COPY.yl[l].menu[s] && COPY.yl[l].sec[s]), `${l}: every plain section has a menu label and a heading`); }

// ---- 8. the claims rows resolve, EN and IT, with the same labels and flags
const claims = (await buildClaims()).filter(c => c.group === 'LNB' && Number(c.id.slice(4)) <= 99), loc = JSON.parse(rd('claimsLocators_lnb.json')), NROWS = 65;   // the A range LNB-001…099; LNB-101… are the widget captions of baezWidgetsCopy.js (claimsLocators_lnbw.json)
ok(claims.length === loc.length && loc.length === NROWS && loc.every((r, i) => r.id === 'LNB-' + String(i + 1).padStart(3, '0')), `claims: rows LNB-001…LNB-${String(loc.length).padStart(3, '0')} (${claims.length})`);
for (const c of claims) {
  ok(c.en.length > 0 && c.it && c.it.length === c.en.length && c.it.every((x, i) => x.label === c.en[i].label && x.flags.join() === c.en[i].flags.join()), `${c.id}: Italian lines carry the labels and flags of the English ones`);
  ok(c.flags.join() === c.flagsSpec.join(), `${c.id}: the lines' flags are the row's flags`);
  ok(c.en.every(l => l.label === 'line'), `${c.id}: the lines of a card are plain lines (the rule of test_researchers.mjs for split statements)`);
  ok(c.known === c.en.every(x => x.known) && c.known === (c.flags.includes('standard') && c.flags.includes('checked') && !c.flags.includes('ours') && !c.flags.includes('open') && !c.flags.includes('input')), `${c.id}: known ground from the lines is the reader filter's definition on the row's flags`);
  ok(c.page === 'lenses' && /^bz-/.test(c.anchor) && has(c.anchor), `${c.id}: shown on the lenses page at an anchor of the chapter (${c.anchor})`);
  for (const id of idsIn(c.checkedBy)) ok(Array.isArray(expand(id)) || expand(id) === 'pending', `${c.id}: checkedBy id ${id} exists`);
}
ok(claims.filter(c => c.visibleTo.includes('Young Learner')).length >= 20, 'claims: the Young Learner sees its own rows and the findings in the fold');
ok(LINES.filter(([w]) => !/\.q$/.test(w)).length >= loc.reduce((s, r) => s + r.lines.length, 0) / 1.2, 'claims: the rows cover the tagged lines');

// ---- 9. persona and e-mail addresses
const MAIL = new RegExp('[\\w.+-]+' + String.fromCharCode(64) + '[\\w-]+\\.[a-z][\\w.-]*|' + 'mail' + 'to:', 'i');   // built from parts, so that this file does not match itself
ok(PERSONA.length > 600 && PERSONA.length <= 1800, `persona: ${PERSONA.length} characters (at most 1 800)`);
ok(/R1 skipped/.test(PERSONA) && /does not derive/.test(PERSONA) && /only without null generators/.test(PERSONA) && /real 10 vs complex 10/.test(PERSONA), 'persona: R1 skipped, no derivation, the complement pairing, the open (1,9)');
for (const f of ['baezCopy.js', 'BaezSection.jsx', 'baezIntegration.js', 'claimsLocators_lnb.json', 'test_lens_baez.mjs', 'test_lens_baez_ui.mjs', 'selfcheck/regen_lens_baez.sh', 'BaezWidgets.jsx'].filter(f => fs.existsSync(f)))
  ok(!MAIL.test(rd(f)), `${f}: no e-mail address`);
for (const f of ['baezCopy.js', 'BaezSection.jsx', 'baezIntegration.js', 'test_lens_baez.mjs', 'test_lens_baez_ui.mjs', 'selfcheck/regen_lens_baez.sh']) ok(rd(f).split('\n').slice(0, 6).join('\n').includes('SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0'), `${f}: SPDX header`);

// ---- 10. the numbers, recomputed
const T = s => SWEEP.map(x => x[1]).join(' ').includes(s);
{ // five-bit labels: two weak bits (0, 1) and three colour bits (2, 3, 4); exact rationals as sixths
  const pc = x => x.toString(2).split('').filter(c => c === '1').length, ev = [...Array(32).keys()].filter(x => pc(x) % 2 === 0);
  const cls = {}; for (const x of ev) { const k = pc(x & 3) + ',' + pc(x >> 2); cls[k] = (cls[k] || 0) + 1; }
  ok(ev.length === 16 && ['0,0', '0,2', '1,1', '1,3', '2,0', '2,2'].map(k => cls[k]).join() === '1,3,6,2,1,3' && Object.keys(cls).length === 6, 'five bits: 16 even labels in six classes of 1, 3, 6, 2, 1, 3');
  const Y6 = x => 3 * pc(x & 3) - 2 * pc(x >> 2), Q6 = x => 6 * (x & 1) - 2 * pc(x >> 2);
  ok(ev.reduce((s, x) => s + Y6(x), 0) === 0 && ev.reduce((s, x) => s + Q6(x), 0) === 0 && ev.reduce((s, x) => s + Y6(x) ** 3, 0) === 0, 'the sums of Y, Q and Y³ over the 16 even labels are 0');
  ok([...Array(32).keys()].every(x => Y6(x ^ 31) === -Y6(x) && Q6(x ^ 31) === -Q6(x) && pc(x ^ 31) % 2 !== pc(x) % 2), 'XOR 11111: even ↔ odd, Y and Q flip on all 32 labels');
  const ys = [...new Set(ev.map(Y6))].sort((a, b) => a - b).map(v => v / 6); ok(JSON.stringify(ys) === JSON.stringify([-4, -3, 0, 1, 2, 6].map(v => v / 6)), 'the six hypercharges are −2/3, −1/2, 0, +1/6, +1/3, +1');
  ok(T('1, 3, 6, 2, 1 and 3') && T('0, +1, +1/6, +1/3, −2/3, −1/2') && T('1, 1, 6, 3, 3, 2'), 'the copy quotes these counts');
}
{ // the E8 Levi ladder from D8 ∪ (D8 + ½) in doubled coordinates, Bourbaki simple roots
  const R = []; for (let i = 0; i < 8; i++) for (let j = i + 1; j < 8; j++) for (const a of [2, -2]) for (const b of [2, -2]) { const v = Array(8).fill(0); v[i] = a; v[j] = b; R.push(v); }
  for (let m = 0; m < 256; m++) { const v = [...Array(8).keys()].map(k => (m >> k & 1 ? -1 : 1)); if (v.filter(x => x < 0).length % 2 === 0) R.push(v); }
  const al = [null, [1, -1, -1, -1, -1, -1, -1, 1], [2, 2, 0, 0, 0, 0, 0, 0], [-2, 2, 0, 0, 0, 0, 0, 0]]; for (let k = 4; k <= 8; k++) { const v = Array(8).fill(0); v[k - 2] = 2; v[k - 3] = -2; al[k] = v; }
  // coefficients: solve sum c_k al_k = r by fraction-free Gauss–Jordan on integers (exact: every pivot step multiplies rows by integers; the last division is exact)
  const A = al.slice(1);
  const coef = r => { const M = A[0].map((_, row) => A.map(c => c[row]).concat([r[row]])); for (let c = 0; c < 8; c++) { let p = c; while (M[p][c] === 0) p++; [M[c], M[p]] = [M[p], M[c]]; for (let q = 0; q < 8; q++) if (q !== c && M[q][c] !== 0) { const f = M[q][c], g = M[c][c]; M[q] = M[q].map((x, i) => x * g - M[c][i] * f); } } return M.map((row, i) => row[8] / row[i]); };
  let cur = R.map(r => [r, coef(r)]); const counts = [cur.length], g1 = [];
  for (const d of [8, 7, 6, 5, 4]) { g1.push(cur.filter(([, c]) => Math.round(c[d - 1]) === 1).length); if (d === 8) ok(cur.filter(([, c]) => Math.abs(c[7]) === 2).length === 2, 'E8: two roots at grade ±2 of α8 (the 5-graded first step)'); cur = cur.filter(([, c]) => Math.round(c[d - 1]) === 0); counts.push(cur.length); }
  ok(R.length === 240 && R.every(r => r.reduce((s, x) => s + x * x, 0) === 8), 'E8: 240 roots of squared length 2 (doubled: 8)');
  ok(counts.join() === '240,126,72,40,20,8' && g1.join() === '56,27,16,10,6', `Levi ladder ${counts.join(', ')} with grade-1 sizes ${g1.join(', ')}`);
  ok(T('240, 126, 72, 40, 20, 8') && T('56, 27, 16, 10, 6') && T('240 = 126 + 2·56 + 2'), 'the copy quotes the ladder');
}
{ // the eleven signatures (p, 10 − p): clock, algebra from the mod-8 table, pseudoscalar square (−1)^{n(n−1)/2}(−1)^q
  const TYPE = { 0: ['ℝ', 1], 1: ['ℝ', 2], 2: ['ℝ', 1], 3: ['ℂ', 1], 4: ['ℍ', 1], 5: ['ℍ', 2], 6: ['ℍ', 1], 7: ['ℂ', 1] }, dim = { 'ℝ': 1, 'ℂ': 2, 'ℍ': 4 }, sub = n => String(n).replace(/\d/g, d => '₀₁₂₃₄₅₆₇₈₉'[d]);
  const rows = [...Array(11).keys()].map(p => { const q = 10 - p, c = ((p - q) % 8 + 8) % 8, [D, k] = TYPE[c], N = Math.round(Math.sqrt(1024 / (k * dim[D]))), w = (-1) ** 45 * (-1) ** q; return [`(${p},${q})`, String(c), (k === 2 ? '2×' : '') + `M${sub(N)}(${D})`, w > 0 ? '+1' : '−1', c === 0 && w > 0 ? '★' : '']; });
  ok(JSON.stringify(rows) === JSON.stringify(TEN_ROWS), 'the table of the eleven signatures is the mod-8 rule: ' + JSON.stringify(rows.filter(r => r[4]).map(r => r[0])));
  ok(rows.filter(r => r[4]).map(r => r[0]).join() === '(1,9),(5,5),(9,1)', 'exactly (1,9), (5,5) and (9,1) have clock 0 and pseudoscalar square +1');
}
{ // Eisenstein shells, the 117 patterns, Madelung
  const E = [...Array(8).keys()].map(N => { let c = 0; for (let a = -12; a <= 12; a++) for (let b = -12; b <= 12; b++) if (a * a - a * b + b * b === N) c++; return c; });
  ok(E.join() === '1,6,0,6,6,0,0,12' && T('1, 6, 0, 6, 6, 0, 0, 12'), 'Eisenstein norms 0…7: 1, 6, 0, 6, 6, 0, 0, 12');
  ok([2, 3, 4].reduce((s, k) => s + 3 ** k, 0) === 117 && [2, 3, 4].reduce((s, k) => s + 2 ** k, 0) === 28 && T('(28 of 117)'), '117 patterns of squares, 28 without a null generator');
  const sub = []; for (let nn = 1; nn <= 7; nn++) for (let l = 0; l < nn; l++) sub.push([nn + l, nn, l]); sub.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  let cum = 0; const cs = sub.map(([, , l]) => (cum += 2 * (2 * l + 1))).slice(0, 19);
  ok(cs.join(', ') === '2, 4, 10, 12, 18, 20, 30, 36, 38, 48, 54, 56, 70, 80, 86, 88, 102, 112, 118' && T(cs.join(', ')) && T('2, 10, 18, 36, 54, 86, 118'), 'Madelung: the cumulative counts and the closures');
  ok([1, 2, 3, 4, 5, 6, 7].map(k => 2 * k * k).join(', ') === '2, 8, 18, 32, 50, 72, 98' && T('2, 8, 18, 32, 50, 72, 98'), 'shells 2n²');
  ok(7 * 6 * 4 === 168 && T('168 = 7·6·4'), 'the 168 independent ordered triples');
}
{ // the honesty counts and the gaps come from the matrix data (the rule of LensKit.jsx bestGrades: a row counts once, by its best cell)
  const rows = MATRIX_ROWS.filter(r => r.src === 'baez'), c = { E: 0, S: 0, A: 0, none: 0 }; for (const r of rows) { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : 'none']++; }
  ok(rows.length === 48 && `${c.E},${c.S},${c.A},${c.none}` === '26,11,2,9', `honesty counts from the matrix: ${c.E}/${c.S}/${c.A}/${c.none} of ${rows.length}`);
  ok(MAP_TEXT.en.baez[1].includes(`26 exact, 11 structural, 2 analogy, 9 gaps`) && MAP_TEXT.it.baez[1].includes('26 esatte, 11 strutturali, 2 analogie, 9 lacune'), 'the Map text quotes the counts the bar draws');
  ok(JSON.stringify(rows.filter(r => !Object.keys(r.cells).length).map(r => r.id)) === JSON.stringify(GAP_IDS) && ['en', 'it'].every(l => GAP_IDS.every(g => COPY[l].gaps[g])), 'the nine gaps are the matrix rows with no cell, each with its words');
  ok(PAPERS.length === 7 && new Set(PAPERS.map(p => p.arxiv)).size === 7 && ['en', 'it'].every(l => PAPERS.every(p => COPY[l].papers[p.id])), 'seven papers, seven arXiv numbers, each with its line');
}
{ // every place that quotes one of these sequences quotes it whole and right (a sequence is found by its first three numbers)
  const SEQ = ['240, 126, 72, 40, 20, 8', '56, 27, 16, 10, 6', '1, 6, 0, 6, 6, 0, 0, 12', '2, 10, 18, 36, 54, 86, 118', '2, 8, 18, 32, 50, 72, 98', '1, 1, 6, 3, 3, 2', '2, 4, 3, 6, 12', '3, 6, 0, 12, 6', '248, 133, 78, 45, 24, 11'];
  const all = SWEEP.map(x => x[1]).join(' \u0000 '), nums = f => f.split(/, | and | e /);   // "20 and 8" ends a quote as "20, 8" does
  for (const q of SEQ) { const head = q.split(', ').slice(0, 3).join(', '), re = new RegExp(head.replace(/[()]/g, '\\$&') + '((, | and | e )[−+]?\\d+)*', 'g'); const found = [...all.matchAll(re)].map(m => m[0]);
    ok(found.length > 0 && found.every(f => { const F = nums(f), Q = nums(q), k = Math.min(F.length, Q.length); return F.slice(0, k).join() === Q.slice(0, k).join(); }), `every quote of ${q} is whole and right: ${[...new Set(found)].join(' | ')}`); }
  // and nobody found a mechanism for (1,9)
  ok(!SWEEP.some(([, s]) => /\b(we )?(find|found) a mechanism|a mechanism (that )?connects|troviamo un meccanismo|abbiamo trovato un meccanismo/i.test(s)), 'no sentence claims a mechanism for the (1,9)');
}
console.log(`${n} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL BAEZ CHAPTER TESTS PASS'); process.exit(bad ? 1 : 0);
