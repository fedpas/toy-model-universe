// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import K from './matterData.js';
import { gname } from './yangmillsCopy.js';

// Copy for step 8 of the equations page: matter charged under so(m) (English and Italian).
// Every number is read from selfcheck/matter.json (exact, standard library) and selfcheck/matter_matrix.json (numpy).
const L = K.mt.ladder, ST = K.mt.spacetime;
const pe = (k, one, many) => (k === 1 ? one : many);
const pc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
export const internalHalves = m => { const all = [...Array(1 << m).keys()]; return [all.filter(x => pc(x) % 2 === 0), all.filter(x => pc(x) % 2 === 1)]; };
export const halfEdges = (m, half) => { const nodes = internalHalves(m)[half], e = []; for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) if (pc(nodes[i] ^ nodes[j]) === 2) e.push([nodes[i], nodes[j]]); return e; };
export const nodeName = x => (x === 0 ? '1' : gname(x));
const names = { 2: 'u(1) on one quaternion module', 3: 'su(2): two doublets', 4: 'su(2) + su(2) doublets', 5: '—', 6: '—', 7: '—', 8: '—' };
const namesIt = { 2: 'u(1) su un modulo quaternionico', 3: 'su(2): due doppietti', 4: 'doppietti di su(2) + su(2)', 5: '—', 6: '—', 7: '—', 8: '—' };
const merr = Object.values(K.matrix.max_error_equation).every(x => x === 0) ? '0' : '< 1e-9';
const maskNames = ν => ({ 0: 'xy', 1: 'ty', 2: 'tx', 3: 'txyz', 4: 'txyzu' }[ν]);

// the Young Learner sees a label as its row of switches (switch 1 first): 12 at m = 4 is 1100
export const bitRow = (x, m) => Array.from({ length: m }, (_, i) => (x >> i) & 1).join('');
const COPY = {
  en: {
    names,
    // the Young Learner reading: plain words beside the same picture; the formal text below stays for the other audiences and in the fold
    yl: {
      name: 'MATTER WITH AN EXTRA LABEL',
      title: 'The electron gets an extra label',
      pickH: 'Pick a number of switches', pick: 'How many switches in the label? Each pair of switches is one kind of charge.',
      picH: 'How the forces flip the switches',
      picCap: (m, g, e) => `Each dot is one label: a row of ${m} switches, 1 for on and 0 for off. Left: an even number of switches on. Right: an odd number. A line joins two labels that differ in exactly two switches: that is where a force acts. ${g} kind${pe(g, '', 's')} of force, ${e} line${pe(e, '', 's')} in each half. Click a force below to see its lines: it pairs every label with exactly one other.`,
      picBig: m => `With ${m} switches there are too many lines to draw (${2 ** (m - 1)} labels in each half). The pattern is the same: each force pairs every label with exactly one other.`,
      selCap: (a, k) => `Force ${a} flips switches ${a[0]} and ${a[1]}: ${k} line${pe(k, '', 's')} in each half, and every label has exactly one partner.`, selNone: 'No force selected: all lines are shown.', evenH: 'even number on', oddH: 'odd number on',
      points: [
        [['checked'], 'Checked by a computer, exactly: whenever the electron’s equation holds, the flow of each kind of charge balances. With a single kind of charge it gives back the flow of step 6.'],
        [['open', 'input'], 'How strong the force is, is a number we put in. With which sign matter feeds it comes from a recipe in books that is not rebuilt here, and nothing is solved.'],
        [['open'], 'Which labels real particles carry is not decided here, and left-handed and right-handed particles are not told apart.'],
        [['ours'], 'Drawing a force as lines between labels that differ in two switches is our way of showing it: an idea we try, not a result.']
      ]
    },
    title: 'Charged matter: the electron field gets an internal index',
    lede: 'Step 6 coupled the electron field to one gauge field, with the phase J acting from the right. Step 7 gave a gauge field with many generators but no matter. Here we join them. The field ψ gets an internal blade T of the algebra Cl(0,m): Ψ = Σ Ψ_{S,T}. The generators of step 7, the bivectors B of Cl(0,m), act by left multiplication on T. The Dirac equation keeps its form, with ∂ replaced by ∂ + gA^aB_a, and every generator gets a current. We climb from m = 2 with space-time fixed at one time and three space axes, then vary the space-time dimension.',
    numbers: 'Exact arithmetic for the counts (m = 2 to 8) and for the identities on random polynomial fields and exact points at the (space-time, gauge) pairs listed below; explicit complex matrices (numpy) for five pairs.',
    tableH: 'The ladder (space-time 1 + 3)', cols: ['m', 'internal blades', 'components of Ψ', 'terms in each equation', 'of them gauge terms', 'internal algebra Cl(0,m)', 'module (real dimension × copies)', 'known as'],
    pickH: 'Pick a gauge dimension', pick: 'm generators of the internal algebra Cl(0,m)',
    picH: 'The gauge action on the internal blades', picCap: (m, g, e) => `Left: the even internal blades. Right: the odd ones. A line joins two blades that differ in exactly two bits: that is a demicube edge, and it is where a generator acts. ${g} generators, ${e} lines in each half. Click a generator to see its lines; it joins every blade to exactly one other.`, picBig: m => `At m = ${m} there are too many lines to draw (${2 ** (m - 1)} blades in each half). The structure is the same: each half is the ${m}-demicube and each generator is a perfect matching of it.`,
    selCap: (a, k) => `Generator ${a}: ${k} lines in each half, every blade has exactly one partner.`, selNone: 'No generator selected: all lines are shown.', evenH: 'even blades', oddH: 'odd blades',
    viewsH: m => `Every view at m = ${m}`,
    views: r => {
      const m = r.m_value;
      const cl = { h: 'Clifford', t: `The internal algebra Cl(0,${m}) is ${r.internal_cell}, of real dimension ${r.internal_dim}. By left multiplication it splits into ${r.summands === 2 ? 'two modules' : 'one module'} of real dimension ${r.minimal_module_real_dim}, each ${pe(r.copies_of_each_module, 'once', `${r.copies_of_each_module} times`)} (standard).${m === 3 ? ' At m = 3 each of the two modules is the quaternions with su(2) acting by unit quaternions: a doublet.' : ''} Ψ has ${r.components} real components: 8 for the even half of the space-time algebra times ${r.internal_dim}.`, tags: ['checked', 'standard'] };
      const cu = { h: 'Cube and demicube', t: `Space-time part: the derivative and mass terms are the edges of step 4. Internal part: a generator moves an internal blade by a distance-2 edge, so it is a demicube edge of the ${m}-cube, in each parity half. The ${r.gauge_terms_per_equation} gauge terms of an equation are products: one space-time cube edge (shifted by J) times one internal edge. The current of a generator pairs components whose space-time corners differ by the masks ${[0, 1, 2, 3].map(nu => `${r.current_corner_masks[nu]}`).join(', ')} for the four space-time directions: the first three are edges of the 4-demicube, the last joins antipodal corners at distance ${r.current_corner_distance[3]}: the four antipodal pairs of the 16-cell, which are the pair of poles and the three commuting bivector pairs of step 2.`, tags: ['checked', 'ours'] };
      const si = { h: 'Simplex', t: `Each internal blade has ${r.gens} partners, one for each generator. Each equation component has ${r.derivative_terms_per_equation} derivative terms, ${r.gauge_terms_per_equation} gauge terms and 1 mass term: ${r.terms_per_equation} in all. The gauge terms sit on the same ${4} even neighbours as the derivative terms, the corner simplex of the odd blade moved by J, once for each generator, and each also moves the internal blade to its partner.`, tags: ['checked'] };
      const la = { h: 'Labels', t: `γ₀ is label 1 and J is label 6, as in step 6. Internal blades are named by the indices they contain; a generator B_ab has the label of the pair (a, b), and a commutator is the label of the symmetric difference. Labels are notation.`, tags: ['checked'] };
      const ma = { h: 'Yang–Mills (step 7)', t: `The current j^a_ν exists for each of the ${r.gens} generator${pe(r.gens, '', 's')} and each of the 4 space-time directions: ${r.gens * 4} components, each a sum of ${r.current_monomials_per_component[0]} products of two components of Ψ. Step 7 showed that D^μF_{μν} = J_ν forces D^νJ_ν = 0 for every gauge field. Here D^νj_ν = 0 holds on the solutions of the matter equation, exactly, so the two are consistent. j transforms in the adjoint representation.`, tags: ['checked'] };
      const co = { h: 'Coupling (step 6)', t: m === 2 ? 'The abelian current X = ψγ₀ψ̃ of step 6 is the same formula with the generator ‘multiply by J on the right’ in place of B. Checked exactly at several space-time dimensions. So step 6 is this construction with the internal index removed and a different generator.' : 'The abelian current of step 6 is the same formula with the generator ‘multiply by J on the right’. The generators here act on the internal index instead, which is a different action; the two can be combined, but we do not draw their combination.', tags: ['checked', 'open'] };
      return [cl, cu, si, la, ma, co];
    },
    stH: 'Space-time dimension, at m = 3', stCols: ['space-time n', 'components of Ψ', 'terms in each equation', 'of them gauge terms', 'current: corner masks, one for each direction', 'corner distances'],
    stNote: 'A component of the equation has n derivative terms, n·G gauge terms and 1 mass term, with G = 3 generators at m = 3. The corner mask of the direction ν is the bits of ν with the bits of γ₀ and J.',
    idH: 'Exact identities', idCols: ['space-time n', 'gauge m', '[D, D]Ψ = gFΨ', 'equation covariant (first order)', 'D·j = 0 on shell', 'j in the adjoint', 'J-generator gives step 6'],
    idNote: 'Commutator: the covariant derivatives satisfy [D_μ, D_ν]Ψ = gF_{μν}Ψ, with F the field strength of step 7. Covariance: Ψ → Ψ − gλΨ and A → A + Dλ change the matter equation by −gλE, so a solution stays a solution. Conservation: at points where the matter equation holds, D^νj^a_ν = 0, with the gauge term of the adjoint derivative included; a wrong sign of g breaks it.',
    xrH: 'What each view teaches the others',
    xr: [
      [['standard', 'checked'], 'Step 7 → matter. The gauge algebra of step 7 acts on the internal blades through the demicube edges of the internal cube. The commutator rule that made a graph in step 2 is the same rule that makes the representation.'],
      [['standard', 'checked'], 'Step 6 → matter. The current of the abelian case is the non-abelian formula with a different generator. The conservation identity of step 6 (div X = −2⟨γ₀ψ̃DJ⟩₀) is the abelian case of the one checked here.'],
      [['standard', 'checked'], 'Dirac → Yang–Mills. The source of the gauge field has 4 components for each generator, all built from pairs of components of Ψ, and it is conserved covariantly exactly when the matter equation holds. This is the consistency that made the source of Maxwell’s equation a conserved current.'],
      [['standard', 'checked', 'input'], 'This is the standard Dirac field in a representation of a gauge group, with the Noether current of each generator. We rebuilt it on the bit rule and checked it.'],
      [['ours'], 'Drawing the gauge action as edges of the internal demicube, the gauge terms as products of a space-time cube edge and an internal edge, and the current as pairs of space-time corners is our reading: an idea we try, not a result.']
    ],
    matH: 'Independent check with matrices',
    mat: `With Jordan–Wigner gamma matrices (numpy) and the internal action as a real matrix, the multivector expression equals the usual i γ^μ(∂_μ + gA^a_μ L_a)Ψ − mΨ at 25 random points for each of five (space-time, gauge) pairs (largest error ${merr}). Each current equals the imaginary part of Ψ†γ₀γ^ν L_aΨ, with the constant of absolute value 1. Four wrong versions fail: the wrong sign of J, the gauge term dropped on one side, gamma matrices of the wrong signature, and the current without J (which is zero).`,
    open: [
      [['open', 'input'], 'The size of the coupling is a free parameter. The standard action of this step (pointer, source unread) ties the κ of D^μF_{μν} = κj_ν to the g of D and fixes the sign of the source, as the one action of step 6 does there (bd·phy·18, bd·phy·19); it is not rebuilt here.'],
      [['standard', 'open', 'input'], 'Which representation the model uses. Left multiplication on Cl(0,m) is the spinor-type one; the commutator action gives tensor-type ones, and they are not drawn. The doublets of the standard electroweak theory are left-handed and charged under two groups; chiral coupling is not treated here (the real-linear chirality of the Spin step is not coupled to a gauge field). With a chiral coupling the mass term needs a scalar doublet: one more step, not an input (the electroweak theory: pointer, source unread).'],
      ['open', 'Solutions of any of these equations. Gravity is drawn in steps 9–10.']
    ],
    dl: { h: 'Check it yourself', text: 'Two Python files. The first (standard library only) rebuilds the term counts, the commutator identity, the gauge covariance and the conservation of the current, exactly. The second (needs numpy, and the first file next to it) compares with explicit gamma matrices and runs four wrong versions that must fail.', py: 'Download matter_selfcheck.py', py2: 'Download matter_matrix_check.py', json: 'Download matter.json', cmd: 'python3 matter_selfcheck.py --compare matter.json   ·   python3 matter_matrix_check.py --compare matter_matrix.json' }
  },
  it: { names: namesIt,
    yl: {
      name: 'MATERIA CON UN’ETICHETTA IN PIÙ',
      title: 'L’elettrone riceve un’etichetta in più',
      pickH: 'Scegli un numero di interruttori', pick: 'Quanti interruttori nell’etichetta? Ogni coppia di interruttori è un tipo di carica.',
      picH: 'Come le forze cambiano gli interruttori',
      picCap: (m, g, e) => `Ogni punto è un’etichetta: una fila di ${m} interruttori, 1 per acceso e 0 per spento. A sinistra: un numero pari di interruttori accesi. A destra: un numero dispari. Una linea unisce due etichette che differiscono in esattamente due interruttori: è lì che agisce una forza. ${g} tip${pe(g, 'o', 'i')} di forza, ${e} line${pe(e, 'a', 'e')} in ciascuna metà. Clicca una forza qui sotto per vedere le sue linee: accoppia ogni etichetta con esattamente un’altra.`,
      picBig: m => `Con ${m} interruttori ci sono troppe linee da disegnare (${2 ** (m - 1)} etichette in ciascuna metà). Lo schema è lo stesso: ogni forza accoppia ogni etichetta con esattamente un’altra.`,
      selCap: (a, k) => `La forza ${a} cambia gli interruttori ${a[0]} e ${a[1]}: ${k} line${pe(k, 'a', 'e')} in ciascuna metà, e ogni etichetta ha esattamente un compagno.`, selNone: 'Nessuna forza scelta: sono mostrate tutte le linee.', evenH: 'accesi in numero pari', oddH: 'accesi in numero dispari',
      points: [
        [['checked'], 'Controllato da un computer, esattamente: ogni volta che vale l’equazione dell’elettrone, il flusso di ogni tipo di carica si bilancia. Con un solo tipo di carica ridà il flusso del passo 6.'],
        [['open', 'input'], 'How strong the force is, is a number we put in. With which sign matter feeds it comes from a recipe in books that is not rebuilt here, and nothing is solved.'],
        [['open'], 'Quali etichette portino le particelle reali qui non è deciso, e le particelle sinistrorse e destrorse non sono distinte.'],
        [['ours'], 'Drawing a force as lines between labels that differ in two switches is our way of showing it: an idea we try, not a result.']
      ]
    },
    title: 'Materia carica: il campo dell’elettrone acquista un indice interno',
    lede: 'Il passo 6 accoppiava il campo dell’elettrone a un solo campo di gauge, con la fase J che agisce da destra. Il passo 7 dava un campo di gauge con molti generatori ma senza materia. Qui li uniamo. Il campo ψ acquista un blade interno T dell’algebra Cl(0,m): Ψ = Σ Ψ_{S,T}. I generatori del passo 7, i bivettori B di Cl(0,m), agiscono per moltiplicazione a sinistra su T. L’equazione di Dirac conserva la sua forma, con ∂ sostituito da ∂ + gA^aB_a, e ogni generatore ha una corrente. Saliamo da m = 2 con lo spazio-tempo fisso a un asse di tempo e tre di spazio, poi facciamo variare la dimensione dello spazio-tempo.',
    numbers: 'Aritmetica esatta per i conteggi (m = 2…8) e per le identità su campi polinomiali casuali e su punti esatti nelle coppie (spazio-tempo, gauge) elencate sotto; matrici complesse esplicite (numpy) per cinque coppie.',
    tableH: 'La scala (spazio-tempo 1 + 3)', cols: ['m', 'blade interni', 'componenti di Ψ', 'termini in ogni equazione', 'di cui termini di gauge', 'algebra interna Cl(0,m)', 'modulo (dimensione reale × copie)', 'noto come'],
    pickH: 'Scegli una dimensione di gauge', pick: 'm generatori dell’algebra interna Cl(0,m)',
    picH: 'L’azione di gauge sui blade interni', picCap: (m, g, e) => `A sinistra: i blade interni pari. A destra: quelli dispari. Una linea unisce due blade che differiscono in esattamente due bit: è uno spigolo del demicubo, ed è dove agisce un generatore. ${g} generatori, ${e} linee in ciascuna metà. Clicca un generatore per vedere le sue linee; unisce ogni blade a esattamente un altro.`, picBig: m => `A m = ${m} ci sono troppe linee da disegnare (${2 ** (m - 1)} blade in ciascuna metà). La struttura è la stessa: ogni metà è il ${m}-demicubo e ogni generatore è un accoppiamento perfetto.`,
    selCap: (a, k) => `Generatore ${a}: ${k} linee in ciascuna metà, ogni blade ha esattamente un partner.`, selNone: 'Nessun generatore selezionato: sono mostrate tutte le linee.', evenH: 'blade pari', oddH: 'blade dispari',
    viewsH: m => `Tutte le viste a m = ${m}`,
    views: r => {
      const m = r.m_value;
      const cl = { h: 'Clifford', t: `L’algebra interna Cl(0,${m}) è ${r.internal_cell}, di dimensione reale ${r.internal_dim}. Per moltiplicazione a sinistra si scinde in ${r.summands === 2 ? 'due moduli' : 'un modulo'} di dimensione reale ${r.minimal_module_real_dim}, ciascuno ${pe(r.copies_of_each_module, 'una volta', `${r.copies_of_each_module} volte`)} (standard).${m === 3 ? ' A m = 3 ciascuno dei due moduli è i quaternioni con su(2) che agisce per quaternioni unitari: un doppietto.' : ''} Ψ ha ${r.components} componenti reali: 8 per la metà pari dell’algebra dello spazio-tempo per ${r.internal_dim}.`, tags: ['checked', 'standard'] };
      const cu = { h: 'Cubo e demicubo', t: `Parte spazio-temporale: i termini di derivata e di massa sono gli spigoli del passo 4. Parte interna: un generatore sposta un blade interno lungo uno spigolo a distanza 2, cioè uno spigolo del demicubo del ${m}-cubo, in ciascuna metà di parità. I ${r.gauge_terms_per_equation} termini di gauge di un’equazione sono prodotti: uno spigolo del cubo spazio-temporale (spostato da J) per uno spigolo interno. La corrente di un generatore accoppia componenti i cui vertici spazio-temporali differiscono per le maschere ${[0, 1, 2, 3].map(nu => `${r.current_corner_masks[nu]}`).join(', ')} per le quattro direzioni: le prime tre sono spigoli del 4-demicubo, l’ultima unisce vertici antipodali a distanza ${r.current_corner_distance[3]}: le quattro coppie antipodali della 16-cella, cioè la coppia dei poli e le tre coppie di bivettori che commutano del passo 2.`, tags: ['checked', 'ours'] };
      const si = { h: 'Simplesso', t: `Ogni blade interno ha ${r.gens} partner, uno per generatore. Ogni componente dell’equazione ha ${r.derivative_terms_per_equation} termini di derivata, ${r.gauge_terms_per_equation} termini di gauge e 1 termine di massa: ${r.terms_per_equation} in tutto. I termini di gauge stanno sugli stessi ${4} vicini pari dei termini di derivata, il simplesso d’angolo del blade dispari spostato da J, una volta per generatore, e ognuno sposta anche il blade interno sul suo partner.`, tags: ['checked'] };
      const la = { h: 'Etichette', t: 'γ₀ è l’etichetta 1 e J è l’etichetta 6, come nel passo 6. I blade interni sono nominati dagli indici che contengono; un generatore B_ab ha l’etichetta della coppia (a, b), e un commutatore è l’etichetta della differenza simmetrica. Le etichette sono solo notazione.', tags: ['checked'] };
      const ma = { h: 'Yang–Mills (passo 7)', t: `La corrente j^a_ν esiste per ciascuno dei ${r.gens} generator${pe(r.gens, 'e', 'i')} e ciascuna delle 4 direzioni dello spazio-tempo: ${r.gens * 4} componenti, ciascuna somma di ${r.current_monomials_per_component[0]} prodotti di due componenti di Ψ. Il passo 7 ha mostrato che D^μF_{μν} = J_ν impone D^νJ_ν = 0 per ogni campo di gauge. Qui D^νj_ν = 0 vale sulle soluzioni dell’equazione della materia, esattamente, quindi le due sono coerenti. j si trasforma nella rappresentazione aggiunta.`, tags: ['checked'] };
      const co = { h: 'Accoppiamento (passo 6)', t: m === 2 ? 'La corrente abeliana X = ψγ₀ψ̃ del passo 6 è la stessa formula con il generatore ‘moltiplica per J a destra’ al posto di B. Controllato esattamente in più dimensioni dello spazio-tempo. Quindi il passo 6 è questa costruzione senza l’indice interno e con un altro generatore.' : 'La corrente abeliana del passo 6 è la stessa formula con il generatore ‘moltiplica per J a destra’. I generatori qui agiscono invece sull’indice interno, che è un’azione diversa; le due si possono combinare, ma non disegniamo la loro combinazione.', tags: ['checked', 'open'] };
      return [cl, cu, si, la, ma, co];
    },
    stH: 'Dimensione dello spazio-tempo, a m = 3', stCols: ['spazio-tempo n', 'componenti di Ψ', 'termini in ogni equazione', 'di cui termini di gauge', 'corrente: maschere dei vertici, una per direzione', 'distanze dei vertici'],
    stNote: 'Una componente dell’equazione ha n termini di derivata, n·G termini di gauge e 1 termine di massa, con G = 3 generatori a m = 3. La maschera dei vertici della direzione ν sono i bit di ν con i bit di γ₀ e J.',
    idH: 'Identità esatte', idCols: ['spazio-tempo n', 'gauge m', '[D, D]Ψ = gFΨ', 'equazione covariante (primo ordine)', 'D·j = 0 sulla superficie', 'j nell’aggiunta', 'il generatore J dà il passo 6'],
    idNote: 'Commutatore: le derivate covarianti soddisfano [D_μ, D_ν]Ψ = gF_{μν}Ψ, con F l’intensità di campo del passo 7. Covarianza: Ψ → Ψ − gλΨ e A → A + Dλ cambiano l’equazione della materia di −gλE, quindi una soluzione resta una soluzione. Conservazione: nei punti in cui vale l’equazione della materia, D^νj^a_ν = 0, con il termine di gauge della derivata aggiunta incluso; un segno sbagliato di g la rompe.',
    xrH: 'Che cosa ogni vista insegna alle altre',
    xr: [
      [['standard', 'checked'], 'Passo 7 → materia. L’algebra di gauge del passo 7 agisce sui blade interni attraverso gli spigoli del demicubo del cubo interno. La regola dei commutatori che nel passo 2 faceva un grafo è la stessa che fa la rappresentazione.'],
      [['standard', 'checked'], 'Passo 6 → materia. La corrente del caso abeliano è la formula non abeliana con un generatore diverso. L’identità di conservazione del passo 6 (div X = −2⟨γ₀ψ̃DJ⟩₀) è il caso abeliano di quella controllata qui.'],
      [['standard', 'checked'], 'Dirac → Yang–Mills. La sorgente del campo di gauge ha 4 componenti per ogni generatore, tutte costruite da coppie di componenti di Ψ, ed è conservata in modo covariante esattamente quando vale l’equazione della materia. È la coerenza che faceva della sorgente dell’equazione di Maxwell una corrente conservata.'],
      [['standard', 'checked', 'input'], 'È il campo di Dirac standard in una rappresentazione di un gruppo di gauge, con la corrente di Noether di ogni generatore. Lo abbiamo ricostruito sulla regola dei bit e controllato.'],
      [['ours'], 'Drawing the gauge action as edges of the internal demicube, the gauge terms as products of a space-time cube edge and an internal edge, and the current as pairs of space-time corners is our reading: an idea we try, not a result.']
    ],
    matH: 'Controllo indipendente con matrici',
    mat: `Con matrici gamma di Jordan–Wigner (numpy) e l’azione interna come matrice reale, l’espressione a multivettori coincide con l’usuale i γ^μ(∂_μ + gA^a_μ L_a)Ψ − mΨ in 25 punti casuali per ciascuna di cinque coppie (spazio-tempo, gauge) (errore massimo ${merr}). Ogni corrente coincide con la parte immaginaria di Ψ†γ₀γ^ν L_aΨ, con costante di valore assoluto 1. Quattro versioni sbagliate falliscono: il segno sbagliato di J, il termine di gauge tolto da un lato, matrici gamma di segnatura sbagliata, e la corrente senza J (che è zero).`,
    open: [
      [['open', 'input'], 'The size of the coupling is a free parameter. The standard action of this step (pointer, source unread) ties the κ of D^μF_{μν} = κj_ν to the g of D and fixes the sign of the source, as the one action of step 6 does there (bd·phy·18, bd·phy·19); it is not rebuilt here.'],
      [['standard', 'open', 'input'], 'Which representation the model uses. Left multiplication on Cl(0,m) is the spinor-type one; the commutator action gives tensor-type ones, and they are not drawn. The doublets of the standard electroweak theory are left-handed and charged under two groups; chiral coupling is not treated here (the real-linear chirality of the Spin step is not coupled to a gauge field). With a chiral coupling the mass term needs a scalar doublet: one more step, not an input (the electroweak theory: pointer, source unread).'],
      ['open', 'Le soluzioni di tutte queste equazioni. La gravità è disegnata nei passi 9–10.']
    ],
    dl: { h: 'Verificalo tu', text: 'Due file Python. Il primo (solo libreria standard) ricostruisce i conteggi dei termini, l’identità dei commutatori, la covarianza di gauge e la conservazione della corrente, esattamente. Il secondo (richiede numpy e il primo file accanto) confronta con matrici gamma esplicite e fa girare quattro versioni sbagliate che devono fallire.', py: 'Scarica matter_selfcheck.py', py2: 'Scarica matter_matrix_check.py', json: 'Scarica matter.json', cmd: 'python3 matter_selfcheck.py --compare matter.json   ·   python3 matter_matrix_check.py --compare matter_matrix.json' }
  }
};
export default COPY;
