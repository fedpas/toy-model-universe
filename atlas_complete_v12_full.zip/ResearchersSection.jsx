// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { BlockMath } from 'react-katex';
import { STORY, PAGES } from './storyCopy.js';
import { scrollToAnchor, navHeight, SUBS, tabLabel } from './StoryShell.jsx';
import { Tx } from './MathText.jsx';
import { CLAIMS, CLAIMS_META } from './claimsData.js';
import { MATRIX_META, MATRIX_COLUMNS, MATRIX_SOURCES, MATRIX_ROWS } from './translationMatrixData.js';
import { RULE_KINDS, RULE_COL_LONG } from './ruleKinds.js';
import { THEOREMS, QUESTIONS, SOURCES, RUN, GENESIS_NOTE } from './researchersData.js';
import { REPORTS } from './reportsData.js';
import { ANALYSES } from './analysesData.js';
import { RS, VERSION } from './researchersCopy.js';
import { FLAGS, GROUNDS, GRADES, isKnown, claimHaystack, claimMatches, flagCounts, whereOf, groundOfReaderFilter, rowMatches, columnCounts, noneIn, checkText } from './researchersModel.js';
import { Tags, StatusBadge, StatusIcon, VerdictMark, Legend } from './StatusBadge.jsx';

// The "For researchers" page (page 9 of 10): the status of the audit, every statement with its flags (claimsData.js), the translation matrix
// (translationMatrixData.js), and the theorems, questions, sources, reports, analyses, scripts and the Genesis note (researchersData.js, reportsData.js and analysesData.js, English only).
// Anchors: status, claims, matrix, theorems, questions, sources, reports, analyses, run, genesis; one per matrix row (matrix-<uid>), per statement (claim-<id>) and per analysis (an-<id>).
// The address #researchers/<anchor> scrolls there on load (#researchers/matrix-L9 also opens that row). The Young Learner reads only a plain pointer.
// Data without an Italian text sits in its own block marked lang="en"; on the Italian page every such section opens with one Italian line saying so (.lang-note).
const YL = 'Young Learner';
const ANCHORS = ['status', 'claims', 'matrix', 'theorems', 'questions', 'sources', 'reports', 'analyses', 'run', 'genesis'];
const flagList = x => (Array.isArray(x) ? x : String(x || '').split(/\s+/).filter(Boolean)).filter(k => FLAGS.includes(k)).sort((a, b) => FLAGS.indexOf(a) - FLAGS.indexOf(b));
const CL = CLAIMS.map(c => ({ ...c, flags: flagList(c.flags), en: (c.en || []).map(x => ({ ...x, flags: flagList(x.flags) })) }));
const GROUPS = [...new Set(CL.map(c => c.group))];
const TALLY = CL.filter(c => c.tally).length;
// where a column of the matrix lives in the app: [page, anchor] (the tabs of the clock, gauge-gravity and finite-groups steps are opened by their address)
// the grade marks of the matrix take the colours of the flag tags whose meaning they share: E exact (checked in a script), S structural (standard), A analogy (ours)
const GRADE_TAG = { E: 'checked', S: 'standard', A: 'ours' };
// a theorem's status and its verifier's verdict are icons (the word is the accessible name and the hover text; the caption of the theorems is the legend)
const THM_ICON = { proved: 'checked', reduced: 'standard', range: 'checked', open: 'open' };
// a grade mark: the letter is the mark, the word of the grade is its hover text and, where no word is printed beside it, its accessible name (`hide`: the word sits next to it or in the cell's own label)
const G = ({ g, word, hide }) => <span className={'tag rs-g g' + g + ' ' + GRADE_TAG[g]} title={word} {...(hide ? { 'aria-hidden': 'true' } : { role: 'img', 'aria-label': word || g })}>{g}</span>;
const COL_GO = { rule: ['rule'], cells: ['atlas'], maxwell: ['maxwell'], furey: ['furey'], shapes: ['shapes'], comm: ['equations', 'eq-comm'], dirac: ['equations', 'eq-dirac'], coupling: ['equations', 'eq-coupling'], ym: ['equations', 'eq-ym'], matter: ['equations', 'eq-matter'], grav1: ['equations', 'eq-grav1'], grav2: ['equations', 'eq-grav2'], mirrors: ['equations', 'eq-mirrors'], projective: ['equations', 'eq-projective'], forque: ['equations', 'eq-forque'], spin: ['equations', 'eq-spin'], spring: ['equations', 'eq-spring'], rigid: ['equations', 'eq-rigid'], null: ['equations', 'eq-nullsurf'], clock: ['conventions', '#clock'], gauge: ['equations', '#gauge'], groups: ['lenses', '#groups'] };
const subOfHash = () => { try { return decodeURIComponent(String(location.hash || '').replace(/^#/, '').split('/')[1] || ''); } catch { return ''; } };
const setSubHash = id => { try { const h = '#researchers' + (id ? '/' + id : ''); if (location.hash !== h) history.replaceState(null, '', h); } catch { /* ignore */ } };
const reduced = () => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

const STYLE = `.rs{max-width:1000px;margin:20px auto;padding:0 16px}.rs>section{scroll-margin-top:var(--nav-h,60px)}
.rs h3{margin:1.5em 0 .4em}.rs h4{margin:0;font-size:1em}.rs .rs-cap{font-size:.86em;opacity:.82;margin:.3em 0 .6em;max-width:72ch}.rs .lang-note{font-size:.82em;opacity:.8;font-style:italic;margin:.2em 0 .6em}
.rs-toc{position:relative;display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:4px 0 10px;border-bottom:1px solid rgba(128,128,128,.3)}.rs-toc>span{font-size:.78em;letter-spacing:.06em;opacity:.75;margin-right:2px}
.rs-toc a{color:inherit;text-decoration:none;border:1px solid rgba(128,128,128,.4);border-radius:999px;padding:3px 11px;font-size:.85em}.rs-toc a:hover{border-color:currentColor}
.rs-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px}.rs-stat{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:10px 12px;min-width:0}
.rs-stat b{display:block;font-size:1.45rem;white-space:nowrap;font-variant-numeric:tabular-nums;line-height:1.2}.rs-stat span{font-size:.84em;opacity:.85;overflow-wrap:anywhere}.rs-stat .tag{margin:2px 0 4px}
.rs-legend{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:4px 14px;font-size:.86em;margin:.4em 0 .8em}.rs-legend p{margin:0}
.rs-bar{display:flex;flex-wrap:wrap;gap:8px 14px;align-items:center;margin:8px 0}.rs-grp{display:flex;flex-wrap:wrap;gap:6px;align-items:center}label.rs-grp{max-width:100%}.rs-grp select{max-width:100%;min-width:0;box-sizing:border-box}.rs-k{font-size:.76em;letter-spacing:.05em;opacity:.75;text-transform:uppercase}
.rs-chip{background:none;border:1px solid rgba(128,128,128,.45);border-radius:999px;padding:3px 11px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.rs-chip[aria-pressed=true]{background:rgba(128,128,128,.3);border-color:currentColor;font-weight:600}
.rs button.tag{cursor:pointer;font:inherit;font-size:.82em;background:none;padding:3px 10px;margin:0;border-radius:999px}.rs button.tag[aria-pressed=true]{background:rgba(128,128,128,.28);font-weight:600}.rs button.tag.sb{padding:5px 9px;line-height:0}.rs button.tag[aria-pressed=true]{box-shadow:inset 0 0 0 2px currentColor}.rs-pill.tag.open{padding:0 6px}.rs-pill,.rs-ver{line-height:0;vertical-align:middle}.rs-ver{display:inline-flex;gap:2px}
.rs select,.rs input[type=search]{font:inherit;font-size:.9em;color:inherit;background:var(--bg,#0b1020);border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:5px 8px;max-width:100%;min-width:0;box-sizing:border-box}.rs input[type=search]{width:19em}
.rs label{font-size:.85em}.rs-count{font-size:.88em;margin:6px 0;display:flex;flex-wrap:wrap;gap:4px 8px;align-items:center}.rs-count .tag{margin:0}.rs-cnt{display:inline-flex;align-items:center;gap:3px}.rs-note{font-size:.8em;opacity:.75;margin:2px 0 8px}
.rs-wrap{overflow:auto;max-height:76vh;border:1px solid rgba(128,128,128,.3);border-radius:10px;overscroll-behavior:contain}
.rs table{border-collapse:separate;border-spacing:0}.rs th,.rs td{text-align:left;vertical-align:top}
.rs-ct{width:100%;min-width:780px;font-size:.87em}.rs-ct th,.rs-ct td{padding:7px 9px;border-bottom:1px solid rgba(128,128,128,.22)}
.rs-ct thead th{position:sticky;top:0;z-index:2;background:var(--bg,#0b1020);border-bottom:1px solid rgba(128,128,128,.55);font-weight:600;white-space:nowrap}
.rs-ct td:first-child,.rs-ct th:first-child{position:sticky;left:0;z-index:1;background:var(--bg,#0b1020);width:7.2em;min-width:7.2em}.rs-ct thead th:first-child{z-index:3}
.rs-ct td:nth-child(2){width:9.5em}.rs-ct td:nth-child(4),.rs-ct td:nth-child(5){width:15%;font-size:.92em;opacity:.9;overflow-wrap:anywhere}
.rs-ct code{font-size:.95em;white-space:nowrap}.rs-ct p{margin:2px 0 0}.rs-ct tr.kg td:first-child{box-shadow:inset 3px 0 0 rgba(128,128,128,.6)}
.rs-line{margin:0 0 8px}.rs-line:last-child{margin-bottom:0}.rs-line .tag{margin:2px 4px 2px 0}.rs-lab{font-size:.72em;letter-spacing:.06em;text-transform:uppercase;opacity:.7;margin-right:6px}
.rs-mark{display:inline-block;margin:4px 4px 0 0;font-size:.72em;border:1px dashed rgba(128,128,128,.65);border-radius:6px;padding:0 6px;white-space:nowrap}.rs-mark.rs-kg{border-style:solid}
.rs-go{display:block;margin-top:4px;background:none;border:none;padding:0;color:inherit;text-decoration:underline;cursor:pointer;font:inherit;text-align:left}
.rs-empty{padding:16px;opacity:.8}
.rs-mxwrap{max-height:72vh}.rs-mx{font-size:.84em;width:100%}.rs-mx th,.rs-mx td{border-bottom:1px solid rgba(128,128,128,.16)}
.rs-mx thead th{position:sticky;top:0;z-index:2;background:var(--bg,#0b1020);vertical-align:bottom;padding:4px 0;border-bottom:1px solid rgba(128,128,128,.55)}
.rs-mx th[scope=row],.rs-mx thead th:first-child,.rs-mx tfoot th{position:sticky;left:0;z-index:1;background:var(--bg,#0b1020);padding:3px 8px 3px 6px;text-align:left;font-weight:400;border-right:1px solid rgba(128,128,128,.35)}.rs-mx thead th:first-child{z-index:3;vertical-align:bottom;font-size:.85em;opacity:.8}
.rs-colbtn{background:none;border:1px solid transparent;border-radius:6px;color:inherit;cursor:pointer;font:inherit;font-size:.92em;padding:4px 2px;width:26px}.rs-colbtn span{writing-mode:vertical-rl;transform:rotate(180deg);white-space:nowrap;display:inline-block}
.rs-colbtn[aria-pressed=true],.rs-mx thead th.oncol .rs-colbtn{border-color:currentColor;background:rgba(128,128,128,.3)}
.rs-rowbtn{background:none;border:1px solid rgba(128,128,128,.4);border-radius:6px;color:inherit;cursor:pointer;font:inherit;padding:0 5px;margin-right:6px;min-width:3.4em;text-align:left}.rs-rowbtn[aria-pressed=true]{border-color:currentColor;background:rgba(128,128,128,.3)}
.rs-rt{display:inline-block;vertical-align:bottom;max-width:24em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:.85}
.rs-mx td.g{width:26px;min-width:26px;max-width:26px;height:25px;padding:0;text-align:center;vertical-align:middle;border-left:1px solid rgba(128,128,128,.1)}
.rs .rs-g{display:inline-block;box-sizing:border-box;position:relative;width:21px;height:19px;line-height:17px;margin:0;padding:0;border-radius:4px;font-size:.8rem;font-weight:700;text-align:center;white-space:nowrap;vertical-align:middle}
.rs .rs-g::before{content:'';position:absolute;inset:0;border-radius:3px;background:currentColor;opacity:.22}.rs .rs-g.gE::before{opacity:.34}.rs .rs-g.gA{border-style:dashed;font-weight:400}.rs .rs-g.gA::before{opacity:0}
.rs-mx td.dim{opacity:.22}.rs-mx td.oncol{background:rgba(128,128,128,.14)}.rs-mx tr.on>th{box-shadow:inset 3px 0 0 currentColor}.rs-mx tr.on>td{background:rgba(128,128,128,.12)}
.rs-mx tfoot td{text-align:center;font-size:.85em;opacity:.85;padding:2px 0}.rs-mx tfoot th{font-size:.8em;opacity:.8;white-space:nowrap}
.rs-panel{border:1px solid rgba(128,128,128,.4);border-left:4px solid rgba(128,128,128,.75);border-radius:10px;padding:8px 14px 10px;margin:10px 0;scroll-margin-top:var(--nav-h,60px)}
.rs-panel-h{display:flex;flex-wrap:wrap;gap:6px 10px;align-items:baseline}.rs-panel-h .rs-x{margin-left:auto}.rs-panel ul{margin:.4em 0;padding-left:1.1em}.rs-panel li{margin:.45em 0}.rs-panel p{margin:.25em 0}
.rs-x,.rs-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:4px 10px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}
.rs-ids{display:flex;flex-wrap:wrap;gap:4px}.rs-idbtn{background:none;border:1px solid rgba(128,128,128,.4);border-radius:6px;color:inherit;cursor:pointer;font:inherit;padding:0 5px}
.rs-cards{display:grid;gap:10px}.rs-cards.two{grid-template-columns:repeat(auto-fit,minmax(290px,1fr))}
.rs-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:10px 14px;min-width:0;overflow-wrap:anywhere;scroll-margin-top:var(--nav-h,60px)}.rs-card>p{margin:.45em 0}
.rs-card-h{display:flex;flex-wrap:wrap;gap:4px 10px;align-items:baseline;margin-bottom:4px}.rs-card-h h4{flex:1 1 14em;min-width:0}
.rs-kv{display:grid;grid-template-columns:10.5em 1fr;gap:2px 10px;font-size:.9em;margin:.35em 0}.rs-kv>.k{opacity:.7;font-size:.92em}.rs-kv>p,.rs-kv>ul,.rs-kv>div{margin:0;min-width:0}.rs-kv ul{padding-left:1.1em}.rs-ans .tag{margin:2px 4px 2px 0}.rs-ans p{margin:3px 0 0}
@media(max-width:560px){.rs-kv{grid-template-columns:1fr}.rs-kv>.k{margin-top:4px}}
.rs .rs-pill{display:inline-block;font-size:.76em;border:1px solid currentColor;border-radius:999px;padding:0 8px;margin:0;white-space:nowrap}.rs .rs-pill.kind{line-height:1.5;padding:0 8px}.rs-pill.st-reduced{border-style:dashed}.rs-pill.st-range{border-style:dotted}
.rs-ver{font-size:.76em;opacity:.85;white-space:nowrap}.rs-ver.v-gaps{font-style:italic}
.rs-rep .rs-open{font-weight:600;color:inherit;text-decoration:underline}.rs-rep code{white-space:normal;overflow-wrap:anywhere}.rs-rep .rs-here a{color:inherit;text-decoration:underline;margin-right:10px;display:inline-block}
.rs-an .rs-dl a{color:inherit;text-decoration:underline;margin-right:12px;display:inline-block}.rs-an .rs-dl .rs-open{font-weight:600}.rs-an .rs-dl span{margin-right:6px}.rs-an .rs-ck{font-size:.86em;overflow-wrap:anywhere;margin:.5em 0 0}.rs-an .rs-ck .rs-k{margin-right:4px}.rs-an .rs-kind{white-space:nowrap}
.rs-cmd{margin:0;overflow-x:auto;font-size:.9em;padding:4px 8px;border:1px solid rgba(128,128,128,.3);border-radius:6px}
.rs-yl{border:1px solid rgba(128,128,128,.4);border-left:4px solid rgba(128,128,128,.75);border-radius:10px;padding:10px 16px;font-size:1.05em}
.rs-toc a:focus-visible,.rs button:focus-visible,.rs select:focus-visible,.rs input:focus-visible,.rs-wrap:focus-visible{outline:2px solid currentColor;outline-offset:2px}
@media(max-width:560px){.rs input[type=search]{width:100%}.rs-bar{gap:8px}.rs-rt{display:none}.rs-mx th[scope=row]{white-space:nowrap}.rs-mx tfoot th{white-space:normal;max-width:5.5em}.rs-ct td:first-child,.rs-ct th:first-child{width:6.4em;min-width:6.4em}}`;


const Kv = ({ k, children }) => <div className="rs-kv"><span className="k"><Tx>{k}</Tx></span>{children}</div>;
const En = ({ children, as: As = 'p', ...p }) => <As lang="en" {...p}><Tx>{children}</Tx></As>;
// an Italian page names the English data once per section
const EnNote = ({ l, text }) => (l === 'it' ? <p className="lang-note"><Tx>{text}</Tx></p> : null);
const H = ({ id, children }) => <h3 id={id + '-h'}><Tx>{children}</Tx></h3>;

export default function ResearchersSection({ lang = 'en', profile = 'Young Learner', go = () => {} }) {
  const l = RS[lang] ? lang : 'en', C = RS[l];
  if (profile === YL) return <div className="rs" id="researchers-yl" data-rf-own=""><style>{STYLE}</style><p className="rs-yl"><Tx>{C.pointer}</Tx></p></div>;
  return <Full l={l} C={C} go={go} />;
}

function Full({ l, C, go }) {
  // the claims filters live here so that the theorems can show a statement in the table
  const [cf, setCf] = useState({ flags: [], mode: 'all', ground: 'all', group: '', q: '' });
  // the matrix choice: a row (uid) or a column (key), opened from a click or from the address #researchers/matrix-<uid>
  const [sel, setSel] = useState(() => { const s = subOfHash(); return s.startsWith('matrix-') && MATRIX_ROWS.some(r => 'matrix-' + r.uid === s) ? { kind: 'row', uid: s.slice(7) } : null; });
  // the reader filter (Settings, readerFilter.js) sets the attribute main[data-rf]: off | known | known+std. The table follows it (read only, live): "known"
  // and "known+std" select the same hiding choice here, "off" shows all again. A choice made in the table stays on this page (it does not change
  // the setting of the whole app). The container carries data-rf-own, so the filter's own CSS leaves these lines to the table.
  useEffect(() => {
    const m = typeof document !== 'undefined' && document.querySelector('main'); if (!m || typeof MutationObserver === 'undefined') return undefined;
    const read = () => { const g = groundOfReaderFilter(m.getAttribute('data-rf')); if (g) setCf(f => (g === 'all' ? (f.ground === 'hide' || f.ground === 'hide+std' ? { ...f, ground: 'all' } : f) : f.ground === g ? f : { ...f, ground: g })); };
    read(); const mo = new MutationObserver(read); mo.observe(m, { attributes: true, attributeFilter: ['data-rf'] }); return () => mo.disconnect();
  }, []);
  // the address #researchers/<anchor> scrolls to the anchor (and opens a matrix row) on load and when it changes
  useEffect(() => {
    const land = () => { const s = subOfHash(); if (!s) return; if (s.startsWith('matrix-')) { const uid = s.slice(7); if (MATRIX_ROWS.some(r => r.uid === uid)) setSel({ kind: 'row', uid }); }
      // a row inside a table frame: first scroll the frame to the row (below its sticky head), then the window (to the row, or to the notes of a matrix row)
      setTimeout(() => { const el = document.getElementById(s); if (!el) return; const pane = el.closest('.rs-wrap'); if (pane && pane !== el) { const head = pane.querySelector('thead'); pane.scrollTop += el.getBoundingClientRect().top - pane.getBoundingClientRect().top - (head ? head.getBoundingClientRect().height : 0); } scrollToAnchor(s.startsWith('matrix-') && document.getElementById('matrix-panel') ? 'matrix-panel' : pane && pane !== el && pane.id ? pane.id : s); }, 80); };
    land(); window.addEventListener('hashchange', land); return () => window.removeEventListener('hashchange', land);
  }, []);
  const jump = id => { setSubHash(id); scrollToAnchor(id); };
  const showClaim = id => { setCf({ flags: [], mode: 'all', ground: 'all', group: '', q: id }); setTimeout(() => jump('claims'), 30); };
  return <div className="rs" id="researchers-top" data-rf-own=""><style>{STYLE}</style>
    <nav className="rs-toc" aria-label={C.tocLbl}><span><Tx>{C.tocLbl.toUpperCase()}</Tx></span>{ANCHORS.map(a => <a key={a} href={'#researchers/' + a} data-to={a} onClick={e => { e.preventDefault(); jump(a); }}><Tx>{C.toc[a]}</Tx></a>)}</nav>
    <Status l={l} C={C} />
    <Claims l={l} C={C} go={go} cf={cf} setCf={setCf} />
    <Matrix l={l} C={C} go={go} sel={sel} setSel={setSel} />
    <Theorems l={l} C={C} showClaim={showClaim} />
    <Questions l={l} C={C} />
    <Sources l={l} C={C} />
    <Reports l={l} C={C} />
    <Analyses l={l} C={C} />
    <Run l={l} C={C} />
    <section id="genesis" aria-labelledby="genesis-h"><H id="genesis">{C.genesis.h}</H><EnNote l={l} text={C.enNote} />
      <En>{GENESIS_NOTE.text}</En></section>
  </div>;
}

function Status({ l, C }) {
  const S = C.status, n = flagCounts(CL), date = CLAIMS_META.audit || CLAIMS_META.generated || '';
  const tiles = [[n.total, S.total], [n.known, S.known], ...FLAGS.map(k => [n[k], S.flag, k]), [VERSION, S.version], [date, S.date], [RUN.length, S.run], [THEOREMS.length, S.theorems], [S.matrix(MATRIX_META.rows, MATRIX_META.columns), S.matrixLbl]];
  return <section id="status" aria-labelledby="status-h"><H id="status">{S.h}</H><p className="rs-cap"><Tx>{S.intro}</Tx></p>
    <div className="rs-stats">{tiles.map(([b, s, k], i) => <div key={i} className="rs-stat" data-stat={k || i}><b>{String(b)}</b>{k && <><StatusBadge flag={k} lang={l} strings={STORY[l]} /><br /></>}<span><Tx>{s}</Tx></span></div>)}</div><p className="rs-cap"><Tx>{S.several}</Tx></p></section>;
}

function Claims({ l, C, go, cf, setCf }) {
  const T = C.claims, groupLabel = g => (l === 'it' && C.groups[g]) || CL.find(c => c.group === g)?.groupName || g;
  const hay = useMemo(() => new Map(CL.map(c => [c.id, claimHaystack(c, l === 'it' ? C.groups[c.group] || '' : '')])), [l]);
  const shown = useMemo(() => CL.filter(c => claimMatches(c, { ...cf, hay: hay.get(c.id) })), [cf, hay]);
  const cnt = flagCounts(shown), set = p => setCf(f => ({ ...f, ...p }));
  const toggle = k => set({ flags: cf.flags.includes(k) ? cf.flags.filter(x => x !== k) : [...cf.flags, k] });
  return <section id="claims" aria-labelledby="claims-h"><H id="claims">{T.h}</H><p className="rs-cap"><Tx>{T.intro}</Tx></p>
    <div className="rs-legend" role="group" aria-label={T.legendH}><Legend lang={l} flags={FLAGS} strings={STORY[l]} /></div>
    <div className="rs-bar">
      <div className="rs-grp" role="group" aria-label={T.flagsLbl}><span className="rs-k"><Tx>{T.flagsLbl}</Tx></span>{FLAGS.map(k => <button key={k} className={'tag sb ' + k} data-flag={k} aria-pressed={cf.flags.includes(k)} aria-label={STORY[l].tags[k]} title={STORY[l].tags[k] + ': ' + STORY[l].tagHelp[k]} onClick={() => toggle(k)}><StatusIcon flag={k} size={16} /></button>)}</div>
      <div className="rs-grp" role="group" aria-label={T.modeLbl}><span className="rs-k"><Tx>{T.modeLbl}</Tx></span>{['all', 'any'].map(m => <button key={m} className="rs-chip" data-mode={m} aria-pressed={cf.mode === m} onClick={() => set({ mode: m })}><Tx>{T.mode[m]}</Tx></button>)}</div>
    </div>
    <div className="rs-bar"><div className="rs-grp" role="group" aria-label={T.groundLbl}><span className="rs-k"><Tx>{T.groundLbl}</Tx></span>{GROUNDS.map(g => <button key={g} className="rs-chip" data-ground={g} aria-pressed={cf.ground === g} onClick={() => set({ ground: g })}><Tx>{T.ground[g]}</Tx></button>)}</div></div>
    <p className="rs-note"><Tx>{T.groundNote(TALLY)}</Tx></p>
    <div className="rs-bar">
      <label className="rs-grp"><span className="rs-k"><Tx>{T.groupLbl}</Tx></span><select value={cf.group} data-filter="group" onChange={e => set({ group: e.target.value })}><option value="">{T.allGroups}</option>{GROUPS.map(g => <option key={g} value={g}>{g + ' · ' + groupLabel(g)}</option>)}</select></label>
      <label className="rs-grp"><span className="rs-k"><Tx>{T.searchLbl}</Tx></span><input type="search" value={cf.q} placeholder={T.searchPh} data-filter="q" onChange={e => set({ q: e.target.value })} /></label>
      <button className="rs-btn" data-clear="claims" onClick={() => setCf({ flags: [], mode: 'all', ground: 'all', group: '', q: '' })}><Tx>{T.clear}</Tx></button>
    </div>
    <p className="rs-count" aria-live="polite" data-shown={shown.length}><b><Tx>{T.shown(shown.length, CL.length)}</Tx></b> · <Tx>{T.among}</Tx>:{FLAGS.map(k => <span key={k} className="rs-cnt" data-count={k}><StatusBadge flag={k} lang={l} strings={STORY[l]} /><b>{cnt[k]}</b></span>)}<span className="rs-mark rs-kg" data-count="known"><Tx>{T.known + ' ' + cnt.known}</Tx></span></p>
    <EnNote l={l} text={C.claimsNote} />
    <div className="rs-wrap" id="claims-table" tabIndex={0} role="region" aria-label={T.tableLbl}><table className="rs-ct"><thead><tr>{['id', 'where', 'lines', 'cited', 'checked'].map(k => <th key={k} scope="col"><Tx>{T.cols[k]}</Tx></th>)}</tr></thead>
      <tbody>{shown.map(c => { const known = isKnown(c.flags), w = whereOf(c.page, PAGES), it = l === 'it' && Array.isArray(c.it) ? c.it : null;
        return <tr key={c.id} id={'claim-' + c.id} data-id={c.id} data-group={c.group} data-flags={c.flags.join(' ')} data-known={known ? '1' : '0'} className={[known && 'kg', c.frozen && 'frozen', c.tally && 'tally'].filter(Boolean).join(' ')}>
          <td><code>{c.id}</code><br />{c.frozen && <span className="rs-mark rs-frozen" title={T.frozenHelp}><Tx>{T.frozen}</Tx></span>}{c.tally && <span className="rs-mark rs-tally" title={T.tallyHelp}><Tx>{T.tally}</Tx></span>}{known && <span className="rs-mark rs-kg"><Tx>{T.known}</Tx></span>}</td>
          <td><span className="rs-grpname"><Tx>{groupLabel(c.group)}</Tx></span>{w && <button className="rs-go" data-go={w.page + (w.anchor ? '#' + w.anchor : '')} title={T.go} onClick={() => go(w.page, w.anchor)}><Tx>{STORY[l].nav[w.page]}</Tx></button>}</td>
          <td>{c.en.map((x, i) => { const t = it && it[i] && it[i].text, lab = T.label[x.label] || ''; return <div key={i} className="rs-line" data-label={x.label}>{lab && <span className="rs-lab"><Tx>{lab}</Tx></span>}<Tags kinds={x.flags} l={l} />{!x.flags.length && <span className="rs-mark rs-noflag"><Tx>{T.noFlag}</Tx></span>}{t ? <p><Tx>{t}</Tx></p> : <En>{x.text}</En>}</div>; })}</td>
          <td>{c.standardRef ? <En>{c.standardRef}</En> : '—'}</td>
          <td>{c.checkedBy ? <En>{c.checkedBy}</En> : '—'}</td></tr>; })}</tbody></table>
      {!shown.length && <p className="rs-empty"><Tx>{T.none}</Tx></p>}</div>
  </section>;
}

function Matrix({ l, C, go, sel, setSel }) {
  const M = C.matrix, [src, setSrc] = useState(''), [col, setCol] = useState(''), [grades, setGrades] = useState([]);
  const colShort = c => (l === 'it' && M.cols[c.key]?.[0]) || c.short, colLong = c => (c.key === 'rule' ? RULE_COL_LONG : (l === 'it' && M.cols[c.key]?.[1]) || c.long);
  const srcName = k => (l === 'it' && M.sources[k]) || MATRIX_SOURCES.find(s => s.key === k)?.name || k;
  const bySrc = useMemo(() => MATRIX_ROWS.filter(r => rowMatches(r, { src })), [src]);
  const shown = useMemo(() => MATRIX_ROWS.filter(r => rowMatches(r, { src, col, grades })), [src, col, grades]);
  const counts = useMemo(() => columnCounts(bySrc, MATRIX_COLUMNS), [bySrc]);
  const panelRef = useRef(null);
  // the panel opens above the table: bring it into view when it is under the page bar or low in the window
  const toView = () => setTimeout(() => { const p = panelRef.current; if (!p) return; const r = p.getBoundingClientRect(); if (r.top < navHeight() || r.top > window.innerHeight * 0.6) window.scrollTo({ top: Math.max(0, window.scrollY + r.top - navHeight() - 4), behavior: reduced() ? 'auto' : 'smooth' }); }, 30);
  const pickRow = uid => { const on = sel?.kind === 'row' && sel.uid === uid; setSel(on ? null : { kind: 'row', uid }); setSubHash(on ? 'matrix' : 'matrix-' + uid); if (!on) toView(); };
  const pickCol = key => { const on = sel?.kind === 'col' && sel.key === key; setSel(on ? null : { kind: 'col', key }); if (!on) toView(); };
  const close = () => { setSel(null); setSubHash('matrix'); };
  const goCol = key => { const [p, a] = COL_GO[key] || []; if (!p) return; if (a && a.startsWith('#')) { try { location.hash = '#' + p + '/' + a.slice(1); window.scrollTo(0, 0); } catch { /* ignore */ } } else go(p, a); };
  const tg = g => setGrades(x => (x.includes(g) ? x.filter(y => y !== g) : [...x, g]));
  const row = sel?.kind === 'row' ? MATRIX_ROWS.find(r => r.uid === sel.uid) : null, ccol = sel?.kind === 'col' ? MATRIX_COLUMNS.find(c => c.key === sel.key) : null;
  return <section id="matrix" aria-labelledby="matrix-h"><H id="matrix">{M.h}</H><p className="rs-cap"><Tx>{M.intro}</Tx></p>
    <div className="rs-bar">
      <div className="rs-grp" role="group" aria-label={M.srcLbl}><span className="rs-k"><Tx>{M.srcLbl}</Tx></span><button className="rs-chip" data-src="" aria-pressed={!src} onClick={() => setSrc('')}><Tx>{M.allSrc}</Tx></button>{MATRIX_SOURCES.map(s => <button key={s.key} className="rs-chip" data-src={s.key} aria-pressed={src === s.key} title={srcName(s.key)} onClick={() => setSrc(s.key)}><Tx>{srcName(s.key).split(/[(,]/)[0].trim() + ' · ' + s.rows}</Tx></button>)}</div>
    </div>
    <div className="rs-bar">
      <label className="rs-grp"><span className="rs-k"><Tx>{M.colLbl}</Tx></span><select value={col} data-filter="col" onChange={e => setCol(e.target.value)}><option value="">{M.allCols}</option>{MATRIX_COLUMNS.map(c => <option key={c.key} value={c.key}>{colLong(c)}</option>)}</select></label>
      <div className="rs-grp" role="group" aria-label={M.gradeLbl}><span className="rs-k"><Tx>{M.gradeLbl}</Tx></span>{GRADES.map(g => <button key={g} className="rs-chip" data-grade={g} aria-pressed={grades.includes(g)} onClick={() => tg(g)}><G g={g} word={M.grade[g]} hide /> <Tx>{M.grade[g]}</Tx></button>)}</div>
    </div>
    <p className="rs-count" aria-live="polite" data-shown={shown.length}><b><Tx>{M.shown(shown.length, MATRIX_ROWS.length)}</Tx></b> · <Tx>{M.help}</Tx></p>
    {(row || ccol) && <div className="rs-panel" id="matrix-panel" ref={panelRef} role="region" aria-label={row ? row.id : colLong(ccol)} data-panel={row ? 'row:' + row.uid : 'col:' + ccol.key}>
      {row && <><div className="rs-panel-h"><code>{row.id}</code><span className="rs-k"><Tx>{srcName(row.src)}</Tx></span><button className="rs-x" onClick={close}><Tx>{M.close}</Tx></button></div><EnNote l={l} text={C.enNote} />
        <En className="rs-ptitle"><b>{row.title}</b></En>
        {Object.keys(row.cells).length ? <ul>{MATRIX_COLUMNS.filter(c => row.cells[c.key]).map(c => { const x = row.cells[c.key]; return <li key={c.key} data-col={c.key}><G g={x.grade} word={M.grade[x.grade]} hide /> <b><Tx>{colLong(c)}</Tx></b> <span className="rs-k"><Tx>{M.grade[x.grade]}</Tx></span>{c.key === 'rule' && RULE_KINDS[row.uid] && <> <span className="rs-k rs-kind" data-kind={RULE_KINDS[row.uid]}>{RULE_KINDS[row.uid]}</span></>}<En>{x.note}</En></li>; })}</ul> : <p><Tx>{M.noCells}</Tx></p>}</>}
      {ccol && <><div className="rs-panel-h"><b><Tx>{colLong(ccol)}</Tx></b>{COL_GO[ccol.key] && <button className="rs-btn" data-gocol={ccol.key} onClick={() => goCol(ccol.key)}><Tx>{M.go}</Tx></button>}<button className="rs-x" onClick={close}><Tx>{M.close}</Tx></button></div>
        <p data-counts={ccol.key}><Tx>{M.colCounts(counts[ccol.key].E, counts[ccol.key].S, counts[ccol.key].A)}</Tx></p><EnNote l={l} text={C.enNote} />
        <h4><Tx>{M.withCell}</Tx></h4><ul>{bySrc.filter(r => r.cells[ccol.key]).map(r => <li key={r.uid}><G g={r.cells[ccol.key].grade} word={M.grade[r.cells[ccol.key].grade]} /> <button className="rs-idbtn" onClick={() => pickRow(r.uid)}><code>{r.id}</code></button>{ccol.key === 'rule' && RULE_KINDS[r.uid] && <> <span className="rs-k rs-kind" data-kind={RULE_KINDS[r.uid]}>{RULE_KINDS[r.uid]}</span></>}<En>{r.title + ': ' + r.cells[ccol.key].note}</En></li>)}</ul>
        <div className="rs-none" data-nonein={ccol.key}><h4><Tx>{M.noneIn(colShort(ccol)) + ' (' + noneIn(bySrc, ccol.key).length + ')'}</Tx></h4>{noneIn(bySrc, ccol.key).length ? <div className="rs-ids">{noneIn(bySrc, ccol.key).map(r => <button key={r.uid} className="rs-idbtn" title={r.title} onClick={() => pickRow(r.uid)}><code>{r.id}</code></button>)}</div> : <p><Tx>{M.noneInEmpty}</Tx></p>}</div></>}
    </div>}
    <EnNote l={l} text={C.enNote} />
    <div className="rs-wrap rs-mxwrap" id="matrix-table" tabIndex={0} role="region" aria-label={M.tableLbl}><table className="rs-mx"><thead><tr><th scope="col"><Tx>{M.item}</Tx></th>{MATRIX_COLUMNS.map(c => <th key={c.key} scope="col" className={col === c.key ? 'oncol' : undefined}><button className="rs-colbtn" data-col={c.key} aria-pressed={sel?.kind === 'col' && sel.key === c.key} title={colLong(c)} aria-label={colLong(c)} onClick={() => pickCol(c.key)}><span><Tx>{colShort(c)}</Tx></span></button></th>)}</tr></thead>
      <tbody>{shown.map(r => <tr key={r.uid} id={'matrix-' + r.uid} data-uid={r.uid} data-src={r.src} className={sel?.kind === 'row' && sel.uid === r.uid ? 'on' : undefined}>
        <th scope="row"><button className="rs-rowbtn" data-uid={r.uid} aria-pressed={sel?.kind === 'row' && sel.uid === r.uid} aria-label={r.id + ': ' + r.title} onClick={() => pickRow(r.uid)}><code>{r.id}</code></button><span className="rs-rt" lang="en" title={r.title}>{r.title}</span></th>
        {MATRIX_COLUMNS.map(c => { const x = r.cells[c.key], dim = x && grades.length && !grades.includes(x.grade); return <td key={c.key} className={'g ' + (x ? 'g' + x.grade : 'g0') + (dim ? ' dim' : '') + (col === c.key ? ' oncol' : '')} data-g={x ? x.grade : ''} aria-label={M.cellLbl(colLong(c), x ? x.grade + ' ' + M.grade[x.grade] + (c.key === 'rule' && RULE_KINDS[r.uid] ? ', ' + RULE_KINDS[r.uid] : '') : M.grade.gap)}>{x ? <G g={x.grade} word={M.grade[x.grade]} hide /> : ''}</td>; })}</tr>)}</tbody>
      <tfoot>{GRADES.map(g => <tr key={g} data-count={g}><th scope="row"><Tx>{M.countRow(g)}</Tx></th>{MATRIX_COLUMNS.map(c => <td key={c.key}>{counts[c.key][g] || '·'}</td>)}</tr>)}</tfoot></table></div>
  </section>;
}

function Theorems({ l, C, showClaim }) {
  const T = C.theorems;
  return <section id="theorems" aria-labelledby="theorems-h"><H id="theorems">{T.h}</H><p className="rs-cap"><Tx>{T.intro}</Tx></p>
    <p className="rs-cap rs-caption"><b><Tx>{T.status.proved}</Tx></b> <Tx>{T.caption.replace(/^[^=]*/, '')}</Tx></p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards">{THEOREMS.map(t => <article key={t.id} id={'thm-' + t.id} className="rs-card" data-status={t.status}>
      <div className="rs-card-h"><code>{t.id}</code><En as="h4">{t.title}</En><span className={(t.status === 'open' ? 'tag open ' : '') + 'rs-pill st-' + t.status} data-st={t.status} role="img" aria-label={T.status[t.status] || t.status} title={(T.status[t.status] || t.status) + ': ' + (T.statusHelp[t.status] || '')}><StatusIcon flag={THM_ICON[t.status] || 'open'} size={14} /></span><VerdictMark v={t.verifier} word={T.verifier[t.verifier] || t.verifier} /></div>
      <En>{t.statement}</En>{t.eq && <div className="rs-eq" style={{ overflowX: 'auto' }}><BlockMath math={t.eq} /></div>}
      {t.statusNote && <Kv k={T.kv.status}><En>{t.statusNote}</En></Kv>}
      <Kv k={T.kv.verifier}>{t.verifierNote ? <En>{t.verifierNote}</En> : <p><Tx>{T.verifier[t.verifier] || ''}</Tx></p>}</Kv>
      <Kv k={T.kv.script}><p><code>{t.script}</code></p></Kv>{t.checks && <Kv k={T.kv.checks}><En>{t.checks}</En></Kv>}
      {t.usedFor?.length > 0 && <Kv k={T.kv.usedFor}><div className="rs-ids">{t.usedFor.map(id => <button key={id} className="rs-idbtn" data-claim={id} title={T.usedForHelp} onClick={() => showClaim(id)}><code>{id}</code></button>)}</div></Kv>}
      {t.limits?.length > 0 && <Kv k={T.kv.limits}><ul lang="en">{t.limits.map((x, i) => <li key={i}><Tx>{x}</Tx></li>)}</ul></Kv>}
    </article>)}</div></section>;
}

function Questions({ l, C }) {
  const Q = C.questions;
  return <section id="questions" aria-labelledby="questions-h"><H id="questions">{Q.h}</H><p className="rs-cap"><Tx>{Q.intro}</Tx></p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards two">{QUESTIONS.map(q => <article key={q.id} id={'q-' + q.id} className="rs-card"><div className="rs-card-h"><code>{q.id}</code><En as="h4">{q.topic}</En></div><En>{q.ask}</En>
      {q.whom && <Kv k={Q.kv.whom}><En>{q.whom}</En></Kv>}{q.checked && <Kv k={Q.kv.checked}><En>{q.checked}</En></Kv>}{q.notChecked && <Kv k={Q.kv.notChecked}><En>{q.notChecked}</En></Kv>}
      {q.answer && <Kv k={Q.kv.answer}><div className="rs-ans"><Tags kinds={q.answerTags} lang={l} /><En>{q.answer}</En></div></Kv>}</article>)}</div></section>;
}

function Sources({ l, C }) {
  const S = C.sources;
  return <section id="sources" aria-labelledby="sources-h"><H id="sources">{S.h}</H><p className="rs-cap"><Tx>{S.intro}</Tx></p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards two">{SOURCES.map(s => <article key={s.id} id={'src-' + s.id} className="rs-card" data-dead={s.deadEnd ? '1' : '0'}><div className="rs-card-h"><code>{s.id}</code><En as="h4">{s.source}</En>{s.deadEnd && <span className="tag kind rs-pill st-dead"><Tx>{S.deadEnd}</Tx></span>}</div>
      {s.itSays && <Kv k={S.kv.itSays}><En>{s.itSays}</En></Kv>}{s.weComputed && <Kv k={S.kv.weComputed}><En>{s.weComputed}</En></Kv>}{s.verdict && <Kv k={S.kv.verdict}><En>{s.verdict}</En></Kv>}</article>)}</div></section>;
}

// the tab or page that holds an id of `on`: a tab id is found in SUBS (whatever page holds it), a page id is a page; anything else is not linked
const hereOf = id => { const p = Object.keys(SUBS).find(k => SUBS[k].includes(id)); return p ? { page: p, sub: id } : PAGES.includes(id) ? { page: id, sub: null } : null; };
function Reports({ l, C }) {
  const R = C.reports, nav = STORY[l].nav;
  return <section id="reports" aria-labelledby="reports-h"><H id="reports">{R.h}</H><p className="rs-cap"><Tx>{R.intro}</Tx></p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards two" role="list" aria-label={R.listLbl}>{REPORTS.map(r => { const here = r.on.map(hereOf).filter(Boolean); return <article key={r.id} id={'rep-' + r.id} className="rs-card rs-rep" role="listitem" data-report={r.id}><div className="rs-card-h"><En as="h4">{r.title}</En></div>
      <En>{r.line}</En>
      <Kv k={R.file}><p><a className="rs-open" href={r.file} target="_blank" rel="noopener" data-report-link={r.id}><Tx>{R.open}</Tx></a> <code>{r.file}</code></p></Kv>
      <Kv k={R.script}><p>{r.script.map(([n, c], i) => <React.Fragment key={n}>{i > 0 && ' · '}<code>{n}</code>{c != null && <> <Tx>{c + ' ' + R.checks}</Tx></>}</React.Fragment>)}</p></Kv>
      <Kv k={R.suite}><p><code>{r.suite}</code></p></Kv>
      {here.length > 0 && <Kv k={R.onPage}><p className="rs-here">{here.map(h => <a key={h.page + '/' + (h.sub || '')} href={'#' + h.page + (h.sub ? '/' + h.sub : '')}><Tx>{h.sub ? tabLabel(l, h.page, h.sub) : nav[h.page]}</Tx></a>)}</p></Kv>}</article>; })}</div></section>;
}

// the analyses (analysesData.js, from reports/analyses/index.json): each page opens in a new tab and downloads, with its markdown source and, where there is one, the zip of its code;
// the check ids it quotes are plain text
const base = f => f.split('/').pop();
function Analyses({ l, C }) {
  const A = C.analyses;
  // the intro names check ids such as rv·P_str·5: plain text (the formula reader would take P_str for a subscript)
  return <section id="analyses" aria-labelledby="analyses-h"><H id="analyses">{A.h}</H><p className="rs-cap" lang="en">{A.intro}</p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards two" role="list" aria-label={A.listLbl}>{ANALYSES.map(a => <article key={a.id} id={'an-' + a.id} className="rs-card rs-an" role="listitem" data-analysis={a.id}>
      <div className="rs-card-h"><En as="h4">{a.title}</En><span className="rs-k rs-kind" lang="en">{a.kind}</span></div>
      <En>{a.line}</En>
      <p className="rs-dl"><a className="rs-open" href={a.html} target="_blank" rel="noopener" data-analysis-link={a.id}><Tx>{A.open}</Tx></a><a href={a.html} download={base(a.html)} data-dl="page"><Tx>{A.page}</Tx></a>
        {a.sources.length === 1 ? <a href={a.sources[0]} download={base(a.sources[0])} data-dl="source"><Tx>{A.source}</Tx></a>
          : <><span><Tx>{A.sources + ':'}</Tx></span>{a.sources.map(f => <a key={f} href={f} download={base(f)} data-dl="source"><code>{base(f)}</code></a>)}</>}
        {a.code && <a href={a.code} download={base(a.code)} data-dl="code"><Tx>{A.code}</Tx></a>}</p>
      <p className="rs-ck" data-checks={a.checks.length}><span className="rs-k"><Tx>{A.checks}</Tx></span> <span lang="en">{a.checks.length ? checkText(a.checks) : A.none}</span></p></article>)}</div></section>;
}

function Run({ l, C }) {
  const R = C.run;
  return <section id="run" aria-labelledby="run-h"><H id="run">{R.h}</H><p className="rs-cap"><Tx>{R.intro}</Tx></p><EnNote l={l} text={C.enNote} />
    <div className="rs-cards two">{RUN.map((r, i) => <article key={r.script + i} className="rs-card" data-script={r.script}><div className="rs-card-h"><code>{r.script}</code></div>
      {r.what && <Kv k={R.kv.what}><En>{r.what}</En></Kv>}{r.checks && <Kv k={R.kv.checks}><En>{r.checks}</En></Kv>}{r.command && <Kv k={R.kv.command}><pre className="rs-cmd"><code>{r.command}</code></pre></Kv>}</article>)}</div></section>;
}
