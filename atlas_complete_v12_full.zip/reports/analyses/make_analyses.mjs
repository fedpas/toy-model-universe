// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Builds the pages of reports/analyses/: one self-contained HTML page per entry of index.json, from the markdown sources in src/, which are shown as they are.
//   node reports/analyses/make_analyses.mjs                 writes every page next to index.json and prints, per page, its size and the formulas that fall back to text
//   node reports/analyses/make_analyses.mjs --check         writes nothing; exit 1 if a source differs from the sha256 that index.json records, or a page differs from what the generator gives
//   node reports/analyses/make_analyses.mjs --out <folder>  writes the pages into another folder (the package's test compares them with the shipped ones, byte for byte)
//   node reports/analyses/make_analyses.mjs --ids <file.md> prints the check ids that a text quotes, in the form of the package (bd·<family>·<n>, core·B<n>)
//   node reports/analyses/make_analyses.mjs --sha <file>    prints the sha256 of a file (the value index.json records for a source)
// Needs the node packages markdown-it and katex (the versions index.json records under "generator"); the pages it writes need nothing: no script, no font, no style sheet,
// no request of any kind. A formula is rendered by katex as MathML; one that katex cannot parse is printed as its own source in a <code class="tex"> and counted: the count of
// each page is recorded in index.json ("fallbacks") and the run fails when a page has more. The output is deterministic: the same sources give the same bytes.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

export const HERE = path.dirname(fileURLToPath(import.meta.url));
export const REGISTRY_FILE = path.join(HERE, 'index.json');
const STYLE_FILE = path.join(HERE, 'analysis_style.css');
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export const sha256 = b => crypto.createHash('sha256').update(b).digest('hex');
export const readRegistry = (file = REGISTRY_FILE) => JSON.parse(fs.readFileSync(file, 'utf8'));
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const dateWords = iso => { const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); return m ? `${+m[3]} ${MONTHS[+m[2] - 1]} ${m[1]}` : String(iso || ''); };

// ---- the node packages: found next to the package (node_modules) or on NODE_PATH; their versions go into every page
export function loadPackages() {
  const req = createRequire(import.meta.url), out = { versions: {} };
  for (const [key, name] of [['MarkdownIt', 'markdown-it'], ['katex', 'katex']]) {
    try { out[key] = req(name); out.versions[name] = JSON.parse(fs.readFileSync(req.resolve(name + '/package.json'), 'utf8')).version; }
    catch (e) { return { missing: name, why: String(e.message).split('\n')[0] }; }
  }
  return out;
}

// ---- the check ids a text quotes, in the form of the package: the ids of the readers' scripts map to the bridge families of selfcheck/bridges/ (one fixed rule),
// the ids of the discovery runs likewise; core·B<n> is a row of selfcheck/core_check.py. A range a–b (or "a … b", "a to b") stands for every number in it.
export const ID_MAP = { 'rv·P_all': 'bd·phy', 'rv·P_str': 'bd·str', 'rv·P_ss': 'bd·sol', 'rv·MG': 'bd·xph', 'rv·M_all': 'bd·mat', 'rv·M_geo': 'bd·geo', 'rv·M_alg': 'bd·alg',
  'rv·M_cat': 'bd·cat', 'rv·merge': 'bd·xck', 'disc·HH': 'bd·hh', 'disc·FK': 'bd·fk', 'disc·REV': 'bd·rev', 'disc·TOR': 'bd·tor', 'disc·EN': 'bd·en', 'disc·FUR': 'bd·fur', 'disc·KEP': 'bd·kep' };
const PREFIX = 'rv·(?:P_all|P_str|P_ss|MG|M_all|M_geo|M_alg|M_cat|merge)·|disc·(?:HH|FK|REV|TOR|EN|FUR|KEP) ?·?|bd·[a-z]+·|core·B';
const ID_RE = new RegExp('(' + PREFIX + ')(\\d+)([a-z]?)(?:\\s*(?:–|—|-|…|\\.\\.|to)\\s*(' + PREFIX + '|B)?(\\d+)(?![\\d·]))?', 'g');
const famOf = p => { const k = p.replace(/[ ·]+$/, '').replace(/·$/, ''); return k === 'core·B' ? 'core·B' : (ID_MAP[k] || k); };
const idOf = (fam, n, suf = '') => fam === 'core·B' ? `core·B${n}` : `${fam}·${n}${suf}`;
export function quotedChecks(text) {
  const out = new Set();
  for (const m of String(text).matchAll(ID_RE)) {
    const fam = famOf(m[1]), a = +m[2], suf = m[3] || '', fam2 = m[4] && m[4] !== 'B' ? famOf(m[4]) : fam, b = m[5] !== undefined && (m[4] !== 'B' || fam === 'core·B') ? +m[5] : null;
    if (b !== null && fam2 === fam && b > a && b - a < 100 && !suf) for (let k = a; k <= b; k++) out.add(idOf(fam, k));
    else { out.add(idOf(fam, a, suf)); if (b !== null && fam2 === fam && b !== a) out.add(idOf(fam, b)); }
  }
  return sortIds([...out]);
}
const idKey = id => { const m = /^(.*?)(\d+)([a-z]?)$/.exec(id); return m ? [m[1], +m[2], m[3]] : [id, 0, '']; };
export const sortIds = ids => [...ids].sort((x, y) => { const [a, b, c] = idKey(x), [d, e, f] = idKey(y); return a < d ? -1 : a > d ? 1 : b - e || (c < f ? -1 : c > f ? 1 : 0); });

// ---- markdown: markdown-it (CommonMark and pipe tables, raw HTML shown as text), formulas between $ … $ (inline) and $$ … $$ (display) by the rule of pandoc:
// the opening $ has a non-space character on its right, the closing $ a non-space character on its left and no digit after it; \$ is a dollar sign. One addition:
// a closing $ may follow the space that ends a control word ("\vert $"), as in TeX.
const isSp = c => c === 0x20 || c === 0x09 || c === 0x0a || c === 0x0d || Number.isNaN(c);
function inlineClose(src, pos, max) {
  if (pos + 1 >= max || isSp(src.charCodeAt(pos + 1)) || src.charCodeAt(pos + 1) === 0x24) return -1;
  for (let i = pos + 1; i < max; i++) {
    const c = src.charCodeAt(i);
    if (c === 0x5c) { i++; continue; }
    if (c !== 0x24) continue;
    const after = src.charCodeAt(i + 1); if (after >= 0x30 && after <= 0x39) continue;
    if (!isSp(src.charCodeAt(i - 1)) || /\\[A-Za-z]+ $/.test(src.slice(Math.max(pos + 1, i - 40), i))) return i;
  }
  return -1;
}
function mathPlugin(md, renderMath) {
  md.inline.ruler.before('escape', 'math', (state, silent) => {
    const src = state.src, pos = state.pos, max = state.posMax;
    if (src.charCodeAt(pos) !== 0x24) return false;
    if (src.charCodeAt(pos + 1) === 0x24) {
      const end = src.indexOf('$$', pos + 2);
      if (end < 0 || end + 2 > max || !src.slice(pos + 2, end).trim()) return false;
      if (!silent) { const t = state.push('math_display', 'math', 0); t.content = src.slice(pos + 2, end); }
      state.pos = end + 2; return true;
    }
    const end = inlineClose(src, pos, max);
    if (end < 0) return false;
    if (!silent) { const t = state.push('math_inline', 'math', 0); t.content = src.slice(pos + 1, end); }
    state.pos = end + 1; return true;
  });
  md.renderer.rules.math_inline = (tokens, idx) => renderMath(tokens[idx].content, false);
  md.renderer.rules.math_display = (tokens, idx) => renderMath(tokens[idx].content, true);
}
// a | inside a formula of a table row belongs to the formula, not to the table: before the table is split, such a | is held by a private character and given back to
// the formula (only where the formula, with its |, is one katex can read; code spans and escaped characters are left alone)
const PIPE = '';
function protectTablePipes(text, readable) {
  let held = 0;
  const out = text.split('\n').map(line => {
    if (!/^\s*\|/.test(line) || !line.includes('$')) return line;
    let o = '', i = 0;
    while (i < line.length) {
      const c = line[i];
      if (c === '\\') { o += line.slice(i, i + 2); i += 2; continue; }
      if (c === '`') { const run = /^`+/.exec(line.slice(i))[0], j = line.indexOf(run, i + run.length); if (j < 0) { o += run; i += run.length; continue; } o += line.slice(i, j + run.length); i = j + run.length; continue; }
      if (c === '$' && line[i + 1] !== '$') { const j = inlineClose(line, i, line.length); if (j > 0) { let tex = line.slice(i + 1, j); if (tex.includes('|') && readable(tex)) { held += tex.split('|').length - 1; tex = tex.split('|').join(PIPE); } o += '$' + tex + '$'; i = j + 1; continue; } }
      o += c; i++;
    }
    return o;
  }).join('\n');
  return { text: out, held };
}

// a heading's anchor: its text in lower case, letters and digits joined by hyphens, unique on the page (a second one gets -2, and so on)
const slug = s => String(s).normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\$[^$]*\$|`[^`]*`/g, m => m.replace(/[\\{}^_$`]/g, ' ')).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48).replace(/-+$/, '') || 'section';

// katex reads ℤ, ℝ, ℂ, … in a formula as a plain letter in its MathML; they are given to it as \mathbb{Z}, … so that the page shows them in blackboard bold.
// \slashed (the Feynman slash) is not a command of katex: it is read as \not, which draws the same slash through the letter.
const DOUBLE = { 'ℕ': 'N', 'ℤ': 'Z', 'ℚ': 'Q', 'ℝ': 'R', 'ℂ': 'C', 'ℍ': 'H', 'ℙ': 'P' };
// MathML Core (Chromium) draws a letter by its own code point and ignores a mathvariant such as blackboard bold or fraktur: such a letter is written as its character of the
// Mathematical Alphanumeric Symbols (ℤ, 𝔽, 𝔰, 𝒞, 𝟏), which every browser draws; a token with a character that has no such form keeps its attribute
const MV = { bold: [0x1D400, 0x1D41A, 0x1D7CE], italic: [0x1D434, 0x1D44E, 0], 'bold-italic': [0x1D468, 0x1D482, 0], script: [0x1D49C, 0x1D4B6, 0], 'bold-script': [0x1D4D0, 0x1D4EA, 0],
  fraktur: [0x1D504, 0x1D51E, 0], 'double-struck': [0x1D538, 0x1D552, 0x1D7D8], 'bold-fraktur': [0x1D56C, 0x1D586, 0], 'sans-serif': [0x1D5A0, 0x1D5BA, 0x1D7E2],
  'bold-sans-serif': [0x1D5D4, 0x1D5EE, 0x1D7EC], 'sans-serif-italic': [0x1D608, 0x1D622, 0], 'sans-serif-bold-italic': [0x1D63C, 0x1D656, 0], monospace: [0x1D670, 0x1D68A, 0x1D7F6] };
const HOLES = { italic: { h: 'ℎ' }, script: { B: 'ℬ', E: 'ℰ', F: 'ℱ', H: 'ℋ', I: 'ℐ', L: 'ℒ', M: 'ℳ', R: 'ℛ', e: 'ℯ', g: 'ℊ', o: 'ℴ' }, fraktur: { C: 'ℭ', H: 'ℌ', I: 'ℑ', R: 'ℜ', Z: 'ℨ' },
  'double-struck': { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' } };
const letter = (v, ch) => { if (HOLES[v] && HOLES[v][ch]) return HOLES[v][ch]; const c = ch.codePointAt(0), [U, L, D] = MV[v];
  return c >= 65 && c <= 90 ? String.fromCodePoint(U + c - 65) : c >= 97 && c <= 122 ? String.fromCodePoint(L + c - 97) : D && c >= 48 && c <= 57 ? String.fromCodePoint(D + c - 48) : null; };
const styled = m => m.replace(/<(mi|mn)((?: [a-z-]+="[^"]*")*?) mathvariant="([a-z-]+)"((?: [a-z-]+="[^"]*")*)>([^<&]*)<\/\1>/g, (all, tag, pre, v, post, txt) => {
  if (!MV[v]) return all; const out = [...txt].map(ch => letter(v, ch)); return out.includes(null) ? all : `<${tag}${pre}${post}>${out.join('')}</${tag}>`; });
const LONG = 24;   // the length (of the TeX source) from which an inline formula gets its own sideways-scrolling box
const KATEX = { output: 'mathml', throwOnError: true, strict: 'ignore', trust: false, macros: { '\\slashed': '\\not{#1}' } };
function makeRenderer(pk, fallbacks) {
  const tex4 = tex => tex.split(PIPE).join('|').replace(/[ℕℤℚℝℂℍℙ]/g, c => '\\mathbb{' + DOUBLE[c] + '}');
  const renderMath = (tex, display) => {
    try {
      const out = pk.katex.renderToString(tex4(tex), { ...KATEX, macros: { ...KATEX.macros }, displayMode: display });
      // the MathML element alone: no katex wrapper, no namespace (an HTML page needs none) and no TeX annotation (the markdown source is one link away); a display formula keeps display="block"
      const m = out.replace(/^<span class="katex(?:-display)?">(?:<span class="katex">)?/, '').replace(/(?:<\/span>)+$/, '').replace(' xmlns="http://www.w3.org/1998/Math/MathML"', '')
        .replace(/<semantics>|<\/semantics>/g, '').replace(/<annotation encoding="application\/x-tex">[\s\S]*?<\/annotation>/, '');
      const m2 = styled(m);
      // a long inline formula cannot break across lines: it sits in a box that scrolls sideways on a narrow screen instead of widening the page
      return !display && tex.length >= LONG ? `<span class="mx">${m2}</span>` : m2;
    } catch (e) {
      fallbacks.push({ tex: tex.split(PIPE).join('|'), why: String(e.message).split('\n')[0].slice(0, 160) });
      const d = display ? '$$' : '$';
      return `<code class="tex">${esc(d + tex.split(PIPE).join('|') + d)}</code>`;
    }
  };
  const readable = tex => { try { pk.katex.renderToString(tex4(tex), { ...KATEX, macros: { ...KATEX.macros } }); return true; } catch { return false; } };
  const md = new pk.MarkdownIt({ html: false, linkify: false, typographer: false, breaks: false });
  mathPlugin(md, renderMath);
  md.renderer.rules.table_open = () => '<div class="tw"><table>\n';
  md.renderer.rules.table_close = () => '</table></div>\n';
  md.readable = readable;
  return md;
}

// one source, rendered: headings get anchors (prefix for a page of several sources) and move down by `shift` levels
function renderSource(md, source, { prefix = '', shift = 0, used }) {
  const { text, held } = protectTablePipes(source, md.readable), env = {}, tokens = md.parse(text, env), heads = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i]; if (t.type !== 'heading_open' && t.type !== 'heading_close') continue;
    const lvl = Math.min(6, +t.tag.slice(1) + shift); t.tag = 'h' + lvl;
    if (t.type === 'heading_open') {
      let id = (prefix ? prefix + '-' : '') + slug(tokens[i + 1].content), k = 2; const base = id; while (used.has(id)) id = base + '-' + k++;
      used.add(id); t.attrSet('id', id); heads.push({ id, level: lvl, inline: tokens[i + 1] });
    }
  }
  const html = md.renderer.render(tokens, md.options, env).split(PIPE).join('|');
  return { html, held, heads: heads.map(h => ({ id: h.id, level: h.level, html: md.renderer.renderInline(h.inline.children, md.options, env) })) };
}

const plainOfInline = h => h.replace(/<[^>]+>/g, '');

export function renderAnalysis(entry, { root = HERE, pk, style }) {
  const fallbacks = [], md = makeRenderer(pk, fallbacks), used = new Set(['top', 'sections', 'main']);
  const multi = entry.source.length > 1, parts = [];
  for (const s of entry.source) {
    const text = fs.readFileSync(path.join(root, s.file), 'utf8');
    const prefix = multi ? (s.anchor || slug(path.basename(s.file, '.md'))) : '';
    if (multi) used.add(prefix);
    parts.push({ s, prefix, ...renderSource(md, text, { prefix, shift: multi ? 1 : 0, used }) });
  }
  const dl = (href, label) => `<a href="${esc(href)}" download="${esc(path.basename(href))}">${label}</a>`;
  const links = [];
  if (multi) links.push('The markdown sources: ' + entry.source.map(s => dl(s.file, '<code>' + esc(path.basename(s.file)) + '</code>')).join(', '));
  else links.push(dl(entry.source[0].file, 'The markdown source'));
  if (entry.code) links.push(dl(entry.code, multi ? 'The code and the logs' : 'The code') + ' <span class="fn">(<code>' + esc(path.basename(entry.code)) + '</code>)</span>');
  links.push(`<time datetime="${esc(entry.date)}">${esc(dateWords(entry.date))}</time>`);
  // the table of contents: the sections of one source (its level-2 headings), or the sources of a page of several (their first heading)
  const toc = multi ? parts.map(p => { const h = p.heads[0]; return h ? `<a href="#${h.id}">${h.html}</a>` : ''; }).filter(Boolean)
    : parts[0].heads.filter(h => h.level === 2).map(h => `<a href="#${h.id}">${h.html}</a>`);
  const body = multi ? parts.map(p => `<section class="part" id="${p.prefix}">\n${p.html}</section>\n`).join('') : parts[0].html;
  const gen = `make_analyses.mjs (markdown-it ${pk.versions['markdown-it']}, katex ${pk.versions.katex})`;
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="generator" content="${esc(gen)}">
<title>${esc(entry.title)}</title>
<style>
${style.trim()}
</style>
</head>
<body id="top">
<header class="hero"><div class="wrap">
<p class="kick">Cascade Atlas · ${esc(entry.kind)}</p>
${multi ? `<h1>${esc(entry.title)}</h1>` : `<p class="an-t">${esc(entry.title)}</p>`}
<p class="sub">${esc(entry.line)}</p>
<p class="dl">${links.join(' · ')}</p>
</div></header>
${toc.length ? `<nav class="toc" id="sections" aria-label="${multi ? 'The sources on this page' : 'Sections'}"><div class="wrap">${toc.join('\n')}</div></nav>\n` : ''}<main class="wrap md" id="main">
${body}</main>
<footer class="wrap"><p>The text above is the markdown source as it is, rendered by ${esc(gen)}; the formulas are MathML. Part of the Cascade Atlas package, PolyForm Noncommercial 1.0.0 (see LICENSE). <a href="#top">Back to the top</a></p></footer>
</body>
</html>
`;
  return { html, fallbacks, toc: toc.map(plainOfInline) };
}

// ---- the registry: every entry is checked before anything is written
export function validate(R, root = HERE) {
  const errs = [], ids = new Set(), pages = new Set();
  if (!R || !Array.isArray(R.analyses) || !R.generator || !R.generator.packages) return ['index.json needs "generator": {"packages": {…}} and "analyses": […]'];
  for (const a of R.analyses) {
    const w = a && a.id ? a.id : JSON.stringify(a).slice(0, 60);
    for (const k of ['id', 'title', 'line', 'kind', 'html', 'date']) if (typeof a[k] !== 'string' || !a[k].trim()) errs.push(`${w}: "${k}" is missing`);
    if (!/^[a-z0-9-]+$/.test(a.id || '')) errs.push(`${w}: the id is lower case letters, digits and hyphens`);
    if (ids.has(a.id)) errs.push(`${w}: the id is used twice`); ids.add(a.id);
    if (!/^[a-z0-9_]+\.html$/.test(a.html || '') || pages.has(a.html)) errs.push(`${w}: "html" is one file name <name>.html of this folder, used once`); pages.add(a.html);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(a.date || '')) errs.push(`${w}: "date" is YYYY-MM-DD`);
    if (!Array.isArray(a.source) || !a.source.length) errs.push(`${w}: "source" is a list of {file, sha256}`);
    else for (const s of a.source) {
      if (!s || !/^src\/[^/]+\.md$/.test(s.file || '')) { errs.push(`${w}: a source is src/<name>.md`); continue; }
      if (s.anchor !== undefined && !/^[a-z][a-z0-9-]*$/.test(s.anchor)) errs.push(`${w}: the anchor of ${s.file} is lower case letters, digits and hyphens`);
      if (!fs.existsSync(path.join(root, s.file))) { errs.push(`${w}: ${s.file} is not there`); continue; }
      const h = sha256(fs.readFileSync(path.join(root, s.file)));
      if (h !== s.sha256) errs.push(`${w}: ${s.file} has sha256 ${h}, index.json records ${s.sha256} (a source is shipped as it is: a changed text needs its new sha256 in index.json)`);
    }
    if (a.code !== undefined && (!/^src\/[^/]+\.zip$/.test(a.code || '') || !fs.existsSync(path.join(root, a.code)))) errs.push(`${w}: "code" is src/<name>.zip and must be there`);
    if (!Array.isArray(a.checks) || !a.checks.every(x => typeof x === 'string')) errs.push(`${w}: "checks" is a list of ids`);
    if (!Number.isInteger(a.fallbacks) || a.fallbacks < 0) errs.push(`${w}: "fallbacks" is the number of formulas the page shows as text (0 or more)`);
  }
  return errs;
}

export function buildAll({ root = HERE, registry = readRegistry(path.join(root, 'index.json')), pk = loadPackages() } = {}) {
  if (pk.missing) return { error: `make_analyses.mjs needs the node package ${pk.missing} (${pk.why}); install it next to the package or name its folder in NODE_PATH` };
  const errs = validate(registry, root); if (errs.length) return { error: errs.join('\n') };
  const style = fs.readFileSync(path.join(root, 'analysis_style.css'), 'utf8'), pages = [];
  for (const a of registry.analyses) pages.push({ entry: a, ...renderAnalysis(a, { root, pk, style }) });
  const versions = pk.versions, recorded = registry.generator.packages;
  return { pages, versions, sameVersions: Object.keys(versions).every(k => versions[k] === recorded[k]) && Object.keys(recorded).length === 2 };
}

// ---- the command line
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), opt = f => { const i = args.indexOf(f); return i >= 0 ? args[i + 1] : null; };
  if (opt('--sha')) { console.log(sha256(fs.readFileSync(opt('--sha')))); process.exit(0); }
  if (opt('--ids')) { console.log(quotedChecks(fs.readFileSync(opt('--ids'), 'utf8')).join(' ')); process.exit(0); }
  const check = args.includes('--check'), out = opt('--out') ? path.resolve(opt('--out')) : HERE;
  const r = buildAll();
  if (r.error) { console.error(r.error); process.exit(1); }
  if (!r.sameVersions) console.log(`note: markdown-it ${r.versions['markdown-it']} and katex ${r.versions.katex} here; index.json records ${JSON.stringify(readRegistry().generator.packages)} (the pages may differ)`);
  let bad = 0;
  for (const p of r.pages) {
    const file = path.join(out, p.entry.html), n = p.fallbacks.length, over = n > p.entry.fallbacks;
    if (over) bad++;
    if (check) { const same = fs.existsSync(file) && fs.readFileSync(file, 'utf8') === p.html; if (!same) bad++; console.log(`${same ? 'current' : 'OUT OF DATE'}  ${p.entry.html}  (${n} formula(s) as text, ${p.entry.fallbacks} recorded)`); }
    else { fs.mkdirSync(out, { recursive: true }); fs.writeFileSync(file, p.html); console.log(`wrote ${path.relative(process.cwd(), file) || file}: ${Buffer.byteLength(p.html)} bytes, ${n} formula(s) as text (${p.entry.fallbacks} recorded)${over ? '  MORE THAN RECORDED' : ''}`); }
    for (const f of p.fallbacks) console.log(`   as text: $${f.tex}$  (${f.why})`);
  }
  process.exit(bad ? 1 : 0);
}
