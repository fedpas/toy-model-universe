# Discovery KEP: the Kepler energy trio is the step-11 trio through Fock's projection

Script: `disc_KEP.py` (standard library, exact rational arithmetic, symbolic). Logs: `disc_KEP.log` (checks), `disc_KEP_sabotage.log` (sabotage run). Discovery D6 of the merged math report (D3 of the geometry review).

## (a) The question

The Atlas compares the Kepler problem with step 11 at the level of Lie algebras only:
- core·B16: the bivector algebras of (+1,+1,+1,ε) (the Baez chapter) and (−1,−1,−1,s) (step 11) are so(4), e(3), so(3,1) with ε = −s;
- J8 and baez·K1a–K1b: the Poisson algebra of L and the Runge–Lenz vector, by finite differences (numerical);
- the S12 verdict, J8 line 5 and the bz_kepler card call the geometric identification "ours (analogy)".

Fock's projection (stereographic projection of momentum space) is the candidate for a geometric map. Under it, does the Poisson algebra of (L, A), rescaled by √(−2μE), √(2μE) or 1, become the Killing algebra of the target (so(4) for S³, e(3) for ℝ³, so(3,1) for H³) with the sign ε = −s of core·B16? Do the hodographs go to geodesics: a great circle of S³, a line of ℝ³, a geodesic of H³? Are the three algebras one Inönü–Wigner family in E?

## (b) The result

**Yes, for the classical problem with potential −k/r in dimensions n = 2 and n = 3.**

Put c = −2μE, with μ the (reduced) mass. Define:
- the Fock family m(c) = ½(|p|² − c) x − (x·p) p;
- Fock's map F_c(p) = (c − |p|², 2p)/(c + |p|²);
- Fock's metric g_c = 4|dp|²/(c + |p|²)².

Every statement below is an exact polynomial identity, with c a free symbol, so one computation covers all three energy signs:
- **The Kepler algebra.** {L, L} = L, {L, A} = A, {A_a, A_b} = −2μH L_ab, {H, L} = {H, A} = 0, A ∧ L = 0, |A|² = μ²k² + 2μH|L|². These hold at every point of T*(ℝⁿ∖0), with μ and k as symbols.
- **One family.** A = m(−2μH) as functions. The pair (L, m(c)) closes with {m_a, m_b} = c L_ab, identically in c. The Killing form is diag(−2(n−1) on L, −2(n−1)c on m). So so(n+1), e(n), so(n,1) for c > 0, = 0, < 0 form one Inönü–Wigner family in c = −2μE, contracted at E = 0.
- **The targets.** F_c maps onto the quadric z₀² + c|z|² = 1 and pulls the target metric back to g_c, which has constant sectional curvature c (full Riemann tensor). The targets are therefore S³ (E < 0), ℝ³ (E = 0, where F₀ is the inversion p ↦ 2p/|p|² into the hyperplane z₀ = −1) and H³ (E > 0).
- **The algebra pushed through the map.** Each generator is linear in x, so its flow moves the momentum by a vector field. That field is a Killing field of g_c, and F_c carries it to a rotation (from L) or to the field z₀∂_a − c z_a∂₀ (from m). This is a Lie algebra isomorphism onto the Killing algebra of the target: among polynomial fields of degree ≤ 3 that algebra has dimension exactly n(n+1)/2.
- **The step-11 identification.** The rescaled algebra (ε = −sign E) is the bivector algebra of the bit-rule Cl(−1,…,−1,s), via L_ab ↦ ½e_ae_b and M_a ↦ −½e_ae_ext. This holds exactly when s = −ε = sign E, as in core·B16; the other six pairs (ε, s) fail.
  - Fock's quadric carries the dual (transpose) of the Clifford vector representation.
  - The rotations L are the isotropy algebra of the Fock pole z = (−1, 0), the collision direction |p| = ∞. This is step 11's Klein pair (bivectors, base bivectors) with the pole as base point.
- **The hodographs.** Every hodograph, at every phase-space point, has these properties:
  - It lies on the sphere |L|²(|p|² + 2μH) + 2N·p = 0, where N_a = Σ_c L_ac A_c is conserved.
  - With c = −2μH, its Fock image lies in the fixed 2-plane |L|²z₀ = N·z, L ∧ z = 0 through the origin of ℝⁿ⁺¹.
  - It is a pregeodesic of g_c, and it has unit speed in the parameter s with ds/dt = 1/(μr). The relation used here is c + |p|² = 2μk/r.
  - Its image is therefore a great circle of Sⁿ (E < 0), a straight line in z₀ = −1 (E = 0), or a geodesic of Hⁿ (E > 0).

Sizes: six checks, n = 2 and 3. The Poisson identities live in ℚ[x, p, r, μ, k, c]/(r² − |x|²). The Riemann tensor of g_c is computed for symbolic c. The Killing-field linear algebra is over ℚ at c = 1, 0, −1, 4, −1/4. The bit-rule brackets are computed for s = −1, 0, +1.

## (c) The checks, the statements the Atlas can carry

Units in all rows: H = |p|²/(2μ) − k/r, with μ the (reduced) mass and k > 0 the coupling (k = G m₁m₂). c = −2μE has the units of momentum², and M = A/√|2μE| has the units of L. Baez's normalisation (J8: e² = 1 + 2L²E) is μ = k = 1 with e = A.

| id | Statement (Atlas form, plain text) | Status | Replaces / adds |
|---|---|---|---|
| bd·kep·1 | For the Kepler problem H = \|p\|²/(2μ) − k/r on T*(ℝⁿ∖0), with L_ab = x_a p_b − x_b p_a and A = \|p\|²x − (x·p)p − μk x/r (= p × L − μk x̂ for n = 3), the brackets hold exactly at every point and for all μ, k:<br>• {L_ab, A_c} = δ_ac A_b − δ_bc A_a;<br>• {A_a, A_b} = −2μH L_ab;<br>• {H, L} = {H, A} = 0;<br>• A ∧ L = 0 (A·L = 0 for n = 3);<br>• \|A\|² = μ²k² + 2μH\|L\|².<br>All brackets are one formula, that of so(diag(−2μH, 1, …, 1)). | checked (n = 2, 3; symbolic) | replaces "(finite differences; numerical)" in J8 line 1 (baez·K1a) by an exact identity; complements the rigid page's N4, which follows A along one orbit as an exact series. Supports the Atlas's own computed side of the "ours open" line on the paper's eq. (12): the bracket of the Runge–Lenz vector with itself is a multiple of L. The paper-reading side stays as it is (paper unread here). |
| bd·kep·2 | One Inönü–Wigner family in the energy. With c = −2μE and m(c) = ½(\|p\|² − c)x − (x·p)p, A = m(−2μE) on the energy surface H = E. (L, m(c)) close with {m_a, m_b} = c L_ab, polynomially in c, and the Killing form is diag(−2(n−1), −2(n−1)c). So E < 0, = 0, > 0 give so(n+1), e(n), so(n,1), with Killing signatures (0,6,0), (0,3,3), (3,3,0) for n = 3 and (0,3,0), (0,1,2), (2,1,0) for n = 2. M = A/√\|2μE\| (M = A at E = 0) satisfies [M, M] = εL with ε = −sign E, and E = 0 is the contraction. | checked | makes J8 line 3 ("e(3) and so(3,1) for E = 0 and E > 0 are standard and not in the paper") checked; adds the family statement (core·B16 lists the three algebras separately) |
| bd·kep·3 | Fock's map F_c(p) = (c − \|p\|², 2p)/(c + \|p\|²) with c = −2μE maps momentum space onto z₀² + c\|z\|² = 1. It is an isometry from Fock's metric g_c = 4\|dp\|²/(c + \|p\|²)², which has constant sectional curvature c = −2μE. The target is a round 3-sphere for E < 0, flat ℝ³ for E = 0 (F₀(p) = (−1, 2p/\|p\|²), the inversion) and the hyperboloid H³ for E > 0. | checked (n = 2, 3; Riemann tensor exact; sign convention anchored by the half-space metric, curvature −1) | adds; replaces the three rational sample orbits of rv·M_geo·17 by one symbolic family |
| bd·kep·4 | Fock's map carries the Poisson algebra of L and the rescaled Runge–Lenz vector onto the Killing algebra of its target.<br>• On H = E, A coincides with the function m(−2μE), which is linear in x; the Hamiltonian fields of A and m(−2μE) differ there by a multiple of the Kepler flow.<br>• The flow of each generator moves the momentum by a Killing field of g_c, and F_c sends it to a rotation of the quadric (from L) or to z₀∂_a − c z_a∂₀ (from m).<br>• f ↦ (its field) is a Lie algebra isomorphism onto the Killing algebra of S³, ℝ³, H³. | checked (n = 2, 3; the Killing algebra shown complete among polynomial fields of degree ≤ 3, dimension n(n+1)/2 at c = 1, 0, −1, 4, −1/4) | answers D6; replaces "ours (analogy)" in the S12 verdict, J8 line 5 and the bz_kepler card |
| bd·kep·5 | Through bd·kep·4 the Kepler algebra with ε = −sign E is the step-11 bivector algebra of Cl(−1,−1,−1,s) with s = sign E, via L_ab ↦ ½e_ae_b and M_a ↦ −½e_ae₄. It is an isomorphism exactly for s = −ε (core·B16): bound orbits ↔ s = −1 (sphere), parabolic ↔ s = 0 (Euclid), scattering ↔ s = +1 (hyperbolic space).<br>• Fock's quadric carries the dual (transpose) of the Clifford vector representation. For s = 0 the Clifford vectors are planes (plane-based algebra, PRJ-004) and Fock's z are points.<br>• The rotations L are the isotropy algebra of the Fock pole z = (−1, 0), the image of \|p\| = ∞ (collision), so (𝔤, span L) is step 11's Klein pair with the pole as base point. | checked (n = 2, 3; ε, s ∈ {+1, 0, −1}: 3 of 9 pairs are isomorphisms, the diagonal s = −ε) | gives core·B16 and PRJ-002 ("as in the Kepler orbits of the Baez chapter: ε = −s") and J8 line 4 a geometric map; links rv·M_geo·13 (Klein pairs of step 11) |
| bd·kep·6 | Every Kepler hodograph (any orbit with L ≠ 0, any energy, eccentricity and orientation, planar or spatial) is carried by Fock's map with c = −2μE into the 2-plane \|L\|²z₀ = N·z, L ∧ z = 0 through the origin of ℝⁿ⁺¹, where N_a = Σ_c L_ac A_c (N = −L × A for n = 3) is conserved. It is a geodesic of Fock's metric g_c with unit speed in the time s, ds/dt = 1/(μr), and c + \|p\|² = 2μk/r along the orbit. So the hodograph of a bound orbit goes to a whole great circle of S³, a parabolic one to a whole line of ℝ³, and a scattering one to a whole geodesic of H³ (the sheet z₀ < 0 for k > 0). | checked (n = 2, 3; identities at every phase-space point) | replaces rv·M_geo·17 (exact but three orbits, rank test) by the symbolic statement; adds the geodesic and the time change |

Suggested wording for the S12 verdict:

> "Exact for the algebra and the counts. The energy trio is the trio of the extra generator of step 11 through Fock's projection.
> - F_c(p) = (c − |p|², 2p)/(c + |p|²), c = −2μE, maps momentum space with the metric 4|dp|²/(c + |p|²)² isometrically onto S³, ℝ³ (by inversion) and H³.
> - It carries L and the rescaled Runge–Lenz vector to the Killing algebra so(4), e(3), so(3,1), which is the bivector algebra of Cl(−1,−1,−1,s) with s = sign E (core·B16).
> - It carries every hodograph to a geodesic.
>
> Checked: bd·kep·1–6. Fock (1935) and Moser (1970): pointers, sources unread."

J8 line 5 becomes checked for the geometric part. Its second sentence stays as it is: the spring's signs are squares of bivectors, a different thing.

Sabotages, each CAUGHT:
- bd·kep·1: the potential term of A with the wrong sign. The machinery then sees {2μH, A₃} = −19/81 at a sample point.
- bd·kep·2: the wrong sign of E in the rescaling (the requested one). A − m on the energy surface becomes −35/144 at a sample point, and the bound and scattering algebras swap to (3,3,0) and (0,6,0).
- bd·kep·3 and bd·kep·4: Fock's map, or the Fock family, with c → −c, i.e. p₀² = +2μE. The quadric identity fails, the curvature comes out −c, and the Killing equation holds for only 3 of 6 generators.
- bd·kep·5: the identification with s = +ε.
- bd·kep·6: c = +2μH in Fock's map. The plane residual and the geodesic residual are non-zero (−18655/10368 and −140/19683 at a sample point).

The non-sabotage run also contains matching and non-matching answers:
- the 3 × 3 table of (ε, s) shows six "no";
- the half-space control gives curvature −1;
- the Killing solver finds 3 (n = 3) and 1 (n = 2) fields, not 6 and 3, for the less symmetric metric 4|dp|²/(1 + p₁²)².

## (d) What the result does not show

- **Classical only.** Fock's own 1935 result concerns the quantum hydrogen atom: momentum-space wavefunctions as harmonics on S³. That, Baez's Weyl equation on ℝ × S³, the shells 2n² and the Madelung order are not touched here (J8 and J9 keep their own checks).
- **Not the full symplectic statement of Moser's regularisation.** The checks cover four things:
  - the action of the generators on momentum space;
  - their momentum maps (the functions linear in x);
  - the momentum curve as a unit-speed geodesic after the time change ds = dt/(μr);
  - the coincidence A = m(−2μE) on H = E.

  They do not show that (x, p) ↦ (F_c(p), cotangent lift of −x) is a symplectomorphism of the energy surface onto the unit cotangent bundle of the target, nor that the Kepler flow is its cogeodesic flow.
- **Collision orbits (L = 0).** The identities hold there, but the plane degenerates. Adding the fibre over the pole (Moser's compactification) is not done.
- **The repulsive case.** The identities are symbolic in k, so they hold for k < 0 too. The statements that c + |p|² = 2μk/r > 0 along orbits and that scattering orbits use the sheet z₀ < 0 assume k > 0; for k < 0 the same identities put scattering orbits on the other sheet, z₀ > 0, which is not stated as a separate check.
- **Dimensions.** n = 2 (planar problem: so(3), e(2), so(2,1)) and n = 3 (spatial problem: so(4), e(3), so(3,1)) only. The bracket formula is dimension-free, but it is not checked for n ≥ 4.
- **Completeness of the Killing algebra.** It is computed among polynomial vector fields of degree ≤ 3 in Fock's momentum chart, at c = 1, 0, −1, 4, −1/4. That no other Killing fields exist follows from the bound n(n+1)/2 on the dimension of a Killing algebra (standard; pointer, source unread).
- **The rescaling for general c.** It is the basis change m ↦ m/√|c|. The structure constants are verified as polynomials in c, and the rescaled sign is computed at sample energies.
- **The step-11 link.** It consists of an abstract Lie algebra isomorphism, the transpose relation between Fock's quadric and the Clifford vector representation, and the isotropy of the pole. Fock's model is the point (dual) picture and the Atlas's plane-based algebras are the plane picture. For s = 0 they are not the same representation; they are dual.
- Nothing is claimed about nature. "Bound / parabolic / scattering ↔ sphere / Euclid / hyperbolic space of step 11" is a statement about the Kepler model and the Atlas's step-11 algebras.

Sources:
- Fock (Z. Phys. 1935), Moser (Comm. Pure Appl. Math. 1970), Milnor (Amer. Math. Monthly 1983, the velocity metric of curvature −2E), Bander–Itzykson (Rev. Mod. Phys. 1966): pointers, sources unread.
- Keane–Barrett–Simmons, arXiv:1411.5355: they state the correspondence S³ / E³ / H³ and the algebras so(4), iso(3), so(3,1) for E < 0, = 0, > 0. Seen only through a summary of the abstract and the conclusion; a pointer, not relied on.

No row above rests on a source.

## (e) Run time and logs

- `python3 disc_KEP.py`: 0.36 s wall time on one core, peak memory 16 MB, exit 0, "ALL PASS (6 checks)". Saved as `disc_KEP.log`.
- `python3 disc_KEP.py --sabotage`: 0.3 s, "ALL SABOTAGES CAUGHT" (6 of 6). Saved as `disc_KEP_sabotage.log`.
- The script is deterministic: no random input; the sample points serve only to print the values of non-zero residuals. It runs from any directory and reads no files.
- An independent float finite-difference evaluation of {A₁, A₂} + 2μH L₁₂ and {L₁₂, A₁} − A₂ at five random points agrees with the symbolic identities to 6·10⁻⁹. This was a one-off probe, not part of the script.
