# Review P_ss: the Cascade Atlas v11 read by a solid-state experimentalist

Reviewer id P_ss. Clone `$SP/atlas11/rv_P_ss`; my scripts are `review2/P_ss/ss_*.py` (31 checks, ids rv·P_ss·1 … rv·P_ss·31), copied with their logs to `$SP/atlas11/review2/out/P_ss_code/`. Every statement below is about structures and models, not about nature. Status words: *standard* (source read, or "pointer, source unread"), *checked* (script and output line), *ours* (a reading, never "derived"), *open*, *input*. In formulas, "Atlas $Cl(p,q)$" has $p$ generators of square $+1$ and $q$ of square $-1$ (Atlas convention, CONV row 0).

## 0. Summary

**Fits exactly.** The cell $(V,Q,\pi)$ is the edge algebra of Majorana zero modes with an antiunitary time reversal $T$. A generator square $\pm1$ is the $T$-parity of a Majorana, $Q(a)=0$ iff the $T$-invariant monomial $e_a$ is Hermitian, and $\pi$ is fermion parity (rv·P_ss·1). The clock $c=p-q \bmod 8$ is the Fidkowski–Kitaev $\mathbb Z_8$: for every even $n\le12$ the edge invariants $(T^2,\,[T,P])$, and for $n\le10$ the generic degeneracy of interacting edges, depend on $c$ alone (rv·P_ss·2–3). T14 and core·B11 are the interaction that gaps 8 chains (rv·P_ss·4–6). The mirror is $T\mapsto TP$ (rv·P_ss·7). A lattice of BDI chains puts $(p,q)$ at one end and the mirror at the other, with the free winding number $W=p-q$, the second lattice address of the cell (rv·P_ss·8).

**Five most important items.**
(1) Clock = Fidkowski–Kitaev $\mathbb Z_8$ = Brown invariant; the Atlas under-claims this (§3 L4–L6, B1, D1).
(2) The bit rule's own modules give the ABS cokernels $KO^{-k}(\mathrm{pt})$, the $d=0$ column of the periodic table (rv·P_ss·25–26). The Atlas's "inputs" $J$ (CONV row 14) are the objects my field classifies (§3 L8–L9, B2).
(3) The $*$-closure of $Cl(p,q,r)$ is $Cl(p+r,q+r)$ (rv·P_ss·12). This answers QC3: no Hermitian symmetry class has a null generator. It also makes the "weight 0" convention of null bits natural. Exceptional points are paired nulls (rv·P_ss·11) and band edges are element-square nulls (rv·P_ss·13) (§3 L10, B3–B4, D6).
(4) Springs (step 15). The signed cube is the zone-centre Bloch Hamiltonian of the π-flux lattice (rv·P_ss·18). It is Lieb's flux phase on the $n$-cube for every $n$, and for Hubbard fermions on the 3-cube (rv·P_ss·27, 31). MAP-033 is closed: 6 rigid + 6 floppy modes, and the braced cube is rigid (rv·P_ss·19) (§3 L12, B9–B10, D5).
(5) Calibration 1 does not name the constitutive relation as an input. The axion component is invisible to every wave operator, yet measured in topological insulators. Indefinite media realise the "two-time" ladder only at fixed frequency. The relative sign of source and force is fixed by positive field energy (rv·P_ss·14–17) (§3 L14, B5–B8, D4).

**Count:** 15 breaks (WRONG 0, OVERCLAIM 0, SCOPE 3, GAP 8, DICTIONARY 4) and 6 discoveries.

## 1. How I read the Atlas

My field sees the Atlas as the **algebra of a few fermion modes with a reality condition**: Majoranas, time reversal, fermion parity, Fock space, Bloch bands, point groups, linear media and mechanical frames. I took these pieces, with the ids I used:

- **Core.** The bit rule (T1, MAP-001) and the cell $(V,Q,\pi)$ (CONV row 12; core·B6–B6c). The clock (LAB-017, LAB-018, PAG-029; core·B1–B3; QD2). The mirror (CONV rows 6–7; core·B4–B5c). The null part (CONV row 13; core·B7–B9; T2, T15; QA1, QC1, QC3, QE6). Doubling and spinor weights (core·B10–B10c). The central split (GEN-008, core·B14). The Genesis ideas A–C (GEN-001…009, CONV ideas H1–H11). The 25 cards (ATL-001…025, PAG-004–007).
- **Calibration 1 (Maxwell).** PAG-008–012, PAG-034, MAP-003–006, INP-001…010, RSN-025/026, EQN-001/006, and `selfcheck/maxwell_selfcheck.py` (charges, point charge, signs).
- **Equations.** Step 4 Dirac (EQN-008, MAP-017, T16, RSN-027/028). Step 5 spin (SPN-001…005, T15). Step 6 coupling (CPL-001…010). Steps 7–8 (YM, MAT). Step 11 projective (PRJ). Step 13 null surfaces (NUL, T18). Step 14 Forque (FRQ). Step 15 springs (SPR-001…004, T19, MAP-026, MAP-033/034). Step 16 rigid bodies (RIG, RSN-006).
- **Shapes.** SHP-001…006 (orthoplex/Fock), GOS-001…004, T10, core·B13.
- **Lenses.** Finite groups (LAB-009…012, RSN-030/031, T9, T11, T12, T14; `groups_check.py`). Category (LNC claims on the clock, T3, T6, T8, QE2, QE3). Baez (LNB-001…010, S2, S12 Kepler). Schuller (LNS-004…044: area metric F4, hyperbolicity F2, bands F13, Dirac sign F9, Fock F7). Hestenes/LDG through the Maxwell and Dirac pages.
- **Furey (Calibration 2).** FUR-001…005, core·B11, `witt_test.py` and `model.py` (her explicit $Cl(0,8)=\mathrm{End}_{\mathbb R}(V)$). Pumplün only as far as the README states it.
- **Theorems and questions.** T1–T20 (`pack/theorems_questions_sources.md`); open questions QA1–QT8; sources S1–S19. The translation matrix (`reports/translation_matrix.json`) only through its description: it has 131 rows from the three lenses and no condensed-matter column.

**Scripts I ran first** (logs in `out/P_ss_code/logs/`), with their result lines:

| Script | Result |
|---|---|
| `core_check.py` | `25/25 core checks hold` |
| `check_T11` | `ALL 74749 CHECKS PASSED` |
| `check_T14` | `ALL 54 CHECKS PASSED` |
| `check_T15` | `4648 of 4648` |
| `check_T16` | `391 of 391` |
| `check_T18` | `2023 of 2023` |
| `check_T19` | `8881 of 8881` |
| `check_T20` | `2015 of 2015` |
| `maxwell_selfcheck.py` | `ALL MAXWELL CHECKS PASS` |
| `spring_selfcheck.py` | `60/60` |
| `null_selfcheck.py` | `64 of 64` |
| `spin_selfcheck.py` | `604/604` |
| `mirrors_selfcheck.py` | `ALL MIRRORS CHECKS PASS` |
| `groups_check.py` | `ALL GROUP CHECKS PASS` |

## 2. Dictionary

My notation:
- $\gamma_j$: Hermitian Majorana operators, with $\gamma_j^2=1$ and $\{\gamma_i,\gamma_j\}=2\delta_{ij}$.
- $T$: an antiunitary time reversal, with $T\gamma_jT^{-1}=\pm\gamma_j$.
- $P$: fermion parity.
- $c,c^\dagger$: fermion ladder operators.
- $H(k)$: a Bloch Hamiltonian.
- $\chi^{abcd}$: a constitutive tensor.
- $C$: a compatibility (rigidity) matrix.

| Atlas object (ids) | object in my field (my notation) | match | evidence | flag |
|---|---|---|---|---|
| labels $a\in\mathbb F_2^n$, blades $e_a$, bit-rule sign (T1, MAP-001, T6(a)) | Majorana monomials $\gamma_a=\gamma_{i_1}\cdots\gamma_{i_k}$ ($i_1<\dots<i_k$), Jordan–Wigner signs; the real form $e_j=\gamma_j$ ($T$-even) or $i\gamma_j$ ($T$-odd) | exact with convention | rv·P_ss·1: "obeys the Atlas bit rule of Cl(p,q) (30000 blade products, n <= 6)" | checked |
| generator square $\varepsilon_i=\pm1$ | $T$-parity of a Majorana: $T\gamma_iT^{-1}=\pm\gamma_i$. Kitaev's $\mathrm{Cl}^{p,q}$ counts the $-1$ generators first: Atlas $Cl(p,q)$ = Kitaev $\mathrm{Cl}^{q,p}$ | exact with convention | rv·P_ss·1; Kitaev 2009 eq. (17) (read) | checked, standard |
| generator square $0$, "label 0", radical (T2, CONV gloss 2) | a creation operator $c^\dagger$ (Pauli exclusion $c^{\dagger2}=0$); not Hermitian; its adjoint pairs it | exact (label basis orthonormal) | rv·P_ss·12; T20(a) | checked |
| $Q(a)=[e_a^2=-1]$ | $e_a$ anti-Hermitian, so not an observable; $Q(a)=0$: a $T$-invariant observable with spectrum $\pm1$ | exact | rv·P_ss·1 "e_a is Hermitian iff Q(a) = 0" | checked |
| $\pi(a)$ | fermion parity of $\gamma_a$ (bosonic or fermionic operator; superselection) | exact | rv·P_ss·1 | checked |
| $w=\pi+2Q \bmod 4$ (core·B1) | $w=0$: $T$-invariant bosonic observable; $w=2$: bosonic, $T$-odd once made Hermitian ($i e_a$); $w$ odd: fermionic operator | exact | rv·P_ss·1, core·B1 | checked |
| clock $c=p-q \bmod 8$ = Brown$(V,w)$ (LAB-017/018, core·B3) | Fidkowski–Kitaev $\mathbb Z_8$ index of a Majorana edge; Arf–Brown–Kervaire invariant, $\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$ | exact for even $n$ (computed); odd $n$ by pointer | rv·P_ss·2, 3; Kirby–Taylor Lemma 3.6 (read); Kapustin et al. Table 1 (read) | checked, standard |
| cell lattice address $[p+q,\,p-q]$ (CONV row 0) | $(n,W)$: number of Majorana zero modes before coupling, and the free BDI winding number $W\in\mathbb Z$; the clock is $W \bmod 8$ | exact | rv·P_ss·8 "W = p − q" | checked |
| type table R, C, H, R⊕R, H⊕H (T4) | Dyson/Wigner type of time reversal: $T^2=+1$, no $T$, $T^2=-1$ (Kramers), via the Frobenius–Schur indicator | exact | rv·P_ss·23; T4(iv) | checked |
| type pairs and restriction maps (T4(ii)) | ABS cokernels $KO^{-k}(\mathrm{pt})=\pi_0(R_k)$: the $d=0$ entries of the 8 real classes; complex: $KU^{-k}$ | exact | rv·P_ss·25, 26; Kitaev Table 1 (read) | checked, standard |
| Lagrangian of $w$ through the top label (T14(4), core·B11) | a commuting set of $n/2$ $T$-invariant parity-even stabilizers that gaps the edge to a unique state (Fidkowski–Kitaev collapse) | exact | rv·P_ss·4, 5, 6 | checked |
| mirror $Q\mapsto Q+\pi$, $c\mapsto-c$ (core·B4) | relabelling $T\mapsto TP$ (every $T$-parity flips); for a chain, its other end | exact | rv·P_ss·7, 8 | checked |
| Genesis idea A, null seed $n^2=0$ (GEN-002) | Pauli exclusion $c^{\dagger2}=0$ | exact | T20(b) | checked |
| Genesis idea B, polarization $\{n,\tilde n\}=1$ (GEN-003) | CAR $\{c,c^\dagger\}=1$ with $\tilde n=c$ the adjoint; $e=c+c^\dagger$, $f=c-c^\dagger$ (Majorana split) | exact with an input (the inner product) | rv·P_ss·12 | checked, input |
| Genesis idea C, the 8 (GEN-009, H2) | 8 Majorana chains are interaction-trivial; $Cl(8,0)=M_{16}(\mathbb R)$ carries a unique real stabilizer state | fits (reading) | rv·P_ss·5, 6 | ours |
| neutral cells $Cl(k,k)$, Witt pairs (GEN-005/007, T7, T20) | $k$ complex fermion modes; a closed chain with both ends | exact | T20; rv·P_ss·8 | checked |
| central split, $\omega^2=+1$ (GEN-008, core·B14) | Kitaev honeycomb gauge projection $D=b^xb^yb^zc=\pm1$ on $Cl^0(4,0)=Cl(0,3)=\mathbb H\oplus\mathbb H$; the sign picks the chirality of the Pauli algebra | exact | rv·P_ss·28, 29 | checked |
| $Cl(3,0)=M_2(\mathbb C)$, central $I=e_{123}$ (ATL-006) | Pauli algebra; Weyl node $H=\chi\,\sigma\cdot k$; chirality $\chi$ = sign of $I=\chi i$ = Berry monopole charge | exact | rv·P_ss·24 | checked |
| $Cl(3,1)=M_4(\mathbb R)$, $Cl(1,3)=M_2(\mathbb H)$, Dirac sign (ATL-010/012, T16, F9) | Majorana (real) and quaternionic Dirac representations; the mass-shell sign is fixed by the factor $i$ | exact with convention | T16 log "real operator shell E^2 = \|k\|^2 + m^2" | checked |
| $Cl(2,2)=M_4(\mathbb R)$, Peres–Mermin grid (T11(4), QE2) | real two-qubit observables; the Peres–Mermin square, measured with trapped ions | exact | T11; Kirchmair et al. 2009 (read) | checked, standard |
| $Cl(3,0)$ states $\rho=(1+v)/2$ (T15, SPN-004) | Bloch ball of spin-1/2 polarisation | exact | T15 | checked; experiment pointer |
| one-period matrix, band/gap/edge (T19, F13) | 1D Bloch bands; gaps; band edges = van Hove singularities with exponent $-1/2$ | exact | rv·P_ss·13 "DOS exponents … [-0.5, -0.5, -0.5]" | checked |
| element-square trio $-1/0/+1$ (CONV gloss 13 B) | with $X=-iH$: PT-unbroken / exceptional point / PT-broken; stable / marginal / unstable | exact with convention (the factor $i$) | rv·P_ss·11 | checked |
| paired null of $Cl(1,1)$ (GEN-003, CONV gloss 12(2)) | exceptional point of the PT dimer $H=\kappa\sigma_x+i\gamma\sigma_z$, together with its partner | exact | rv·P_ss·11 "{H,H'} = 4 kappa^2" | checked |
| signed cube $D$, $D^2=nI$, flux π (SPR-004, T19(4), Huang) | zone-centre Bloch Hamiltonian $H(0)/2$ of the π-flux (Kogut–Susskind) lattice; Lieb's flux phase | exact | rv·P_ss·18, 27 | checked |
| spring Laplacian $L=nI-A$ (step 15) | phonons on the hypercube graph with one scalar displacement per site (Walsh modes) | exact | `spring_selfcheck.py` 60/60 | checked |
| rigid motions, PGA bivectors (step 16, MAP-033) | trivial zero modes of the compatibility matrix $C$ | exact | rv·P_ss·19 | checked |
| strain $S=h^T\eta h-\eta$ (ATL-018) | $S/2$ = Green–Lagrange finite strain of continuum mechanics (measured by strain gauges) | exact (Euclidean $\eta$) | ATL-018; T17 part G | standard (textbook, pointer), ours |
| $\nabla F=J$ (Calibration 1) | vacuum Maxwell: $\chi$ = metric Hodge dual; units $c=\varepsilon_0=\mu_0=1$ | exact with an input | rv·P_ss·14; maxwell_selfcheck | checked, input |
| area metric $G^{abcd}$, 21 components, "ε part" (LNS-013) | constitutive tensor of a Lagrangian linear medium: 20 principal + 1 axion; a general medium has 36 (+15 skewon) | partial | rv·P_ss·14; Jancewicz (read) | checked, standard |
| hyperbolicity map, ladders $Cl(k,d)$ (T18(f), F2, INP-010) | wave type of the extraordinary optical metric; hyperbolic metamaterials | exact with an input (fixed $\omega$) | rv·P_ss·15, 16; Smolyaninov–Narimanov (read) | checked, standard |
| Lorentz force as the grade-1 part of $Fu$ (charges tab) | Lorentz force; cyclotron orbit, $E\times B$ (Hall) drift | exact | maxwell_selfcheck rows | checked |
| 3-bit labels with XOR (RSN-007, step 3) | orthorhombic point group $mmm$ ($D_{2h}$); $\pi$ = det (improper elements) | exact | rv·P_ss·21 | checked |
| signs $\pm e_a$ on 3 bits | double group of $mmm$: $Cl(0,3)$ with the convention "inversion acts as +1"; $Cl(3,0)$ with "inversion acts as $i$" | exact with convention | rv·P_ss·21 | checked |
| $B_n$, $D_n$ (MIR, RSN-023) | for $n=3$: $O_h$ ($m\bar3m$) and $T_d$ ($\bar43m$) | exact | rv·P_ss·22 | checked |
| Pin lifts 2.A4, 2.A5 (LAB-009, groups_check C) | double groups of $T$ (crystallographic) and $I$ (not crystallographic: icosahedral clusters, quasicrystals) | exact | rv·P_ss·22 "traces … non-integral" | checked |
| E8 (GOS, T10, core·B13) | Construction A lattice of the FK code $[8,4,4]$ | partial | rv·P_ss·9 | checked |
| choices the algebra does not make: $J$, $\gamma_0$, Witt split (CONV row 14, INP-011, INP-023) | the objects being classified: a gapped free-fermion phase is a symmetry-compatible complex structure $J$; $\pi_0$ of their space is the invariant | exact (Kitaev's construction) | rv·P_ss·25, 20; Kitaev (read) | checked, standard |
| cell role names: quark, lepton, … (PAG-006, H8) | none. The same cell has unrelated realisations, e.g. $Cl(2,1)$ ("quark") is the edge of a $W=1$ BDI chain (one net $T$-even Majorana) | none | rv·P_ss·8 | ours (no counterpart) |
| Furey's $V$ and Fano-line blades (core·B11, FUR-003) | edge Fock space of 8 Majoranas; FK quartic couplings, a perfect Hamming $[7,4,3]$ pattern; her blocks are not FK levels | partial | rv·P_ss·6, 10 | checked |
| label speed test (MAP-027, RIG-004, README_label_bench) | a measurement: medians of 7, spreads, explicit verdict rule, noise flagged | fits | README_label_bench.md lines 45–82 (read) | ours |

## 3. Reconnection

The one picture: **the Atlas's cells are the real (time-reversal-invariant) operator algebras of a handful of Majorana modes. Their clock is the interacting topological index. Their null part is what Hermiticity pairs away. The equations pages are band theory, constitutive electrodynamics and mechanics of frames, each with named inputs.** The chain, with the computation behind each link:

**L1. Labels are Majorana monomials.** Jordan–Wigner Majoranas on $n/2$ qubits, with $e_j=\gamma_j$ for $j<p$ and $e_j=i\gamma_j$ for $j\ge p$, reproduce the Atlas sign $s(a,b)$ on every pair of blades. — *fits* [checked: `python3 -I ss_fk_clock.py`, line `ok rv·P_ss·1 … obeys the Atlas bit rule of Cl(p,q) (30000 blade products, n <= 6)`]. The sign is the Jordan–Wigner string, unique up to gauge on the simply connected cube (T6(a)).

**L2. The cell $(V,Q,\pi)$ in my words.**
- $V$ is the Majorana group modulo phases.
- $Q(a)=1$ iff the $T$-invariant monomial is anti-Hermitian.
- $\pi$ is fermion parity.
- $w=0$ marks exactly the bosonic $T$-invariant observables.

— *fits* [checked: rv·P_ss·1, "e_a is Hermitian iff Q(a) = 0 and fermion-odd iff pi(a) = 1 (every label, every (p,q), n even <= 8)"].

**L3. The generator-square trio is a symmetry datum, the element-square trio is a dynamical one.** A generator square $\pm1$ is the $T$-parity of one Majorana (L1). An element square is the class of a one-parameter flow. In physics the evolution generator is $X=-iH$, so $X^2=-H^2$: a real spectrum is the elliptic class. The PT-dimer trio is the same orbit trichotomy as T19's band/gap/edge. This supports the Atlas's own split of the "one trio" (CONV gloss 13, idea H6). — *fits* [checked: rv·P_ss·11 "X = -iH: PT-unbroken is X^2 < 0"; rv·P_ss·13].

**L4. The clock is the Fidkowski–Kitaev $\mathbb Z_8$.** For each $(p,q)$ with $n$ even $\le12$ I built $T=UK$. The pair ($T^2$, $T$ commuting or anticommuting with $P$) takes four values and depends only on $c$:

| $c$ | $T^2$ | $T$ vs $P$ |
|---|---|---|
| 0 | $+1$ | commute |
| 2 | $+1$ | anticommute |
| 4 | $-1$ | commute |
| 6 | $-1$ | anticommute |

Random Hermitian, $T$-invariant, parity-even Hamiltonians are the most general interacting edge. Their levels are non-degenerate iff $c\equiv0$ and exactly 2-fold otherwise. — *fits* for even $n$ [checked: rv·P_ss·2, 3]. Fidkowski and Kitaev state that interactions break $\mathbb Z$ to $\mathbb Z_8$ [standard: arXiv:0904.2197 and 1008.4138, abstracts read]. The Brown invariant of a $\mathbb Z_4$ enhancement is defined from the Gauss sum $\sum_x e^{2\pi i q(x)/4}$, and $\beta:\Omega_2^{\mathrm{Pin}^-}\to\mathbb Z_8$ is an isomorphism [standard: Kirby–Taylor, Lemma 3.6, read]. $\Omega_2^{\mathrm{Pin}^-}=\mathbb Z_8$ is the classification of $1{+}1$D fermionic phases with $T^2=1$ [standard: Kapustin–Thorngren–Turzillo–Wang, Table 1, read]. With core·B1 ($w$ is a $\mathbb Z_4$ refinement of the non-degenerate dot product) and core·B3 (Gauss sum $(1+i)^p(1-i)^q$), "clock = Brown invariant" is a definition, not a reading. — *fits* (see B1). Odd $n$ (an unpaired Majorana) is not computed here [input: the far end, or an ancilla].

**L5. T14 and core·B11 are the Fidkowski–Kitaev collapse.** A Lagrangian $L$ of $w$ consists of $n/2$ independent commuting labels with $w=0$. These are commuting, $T$-invariant, Hermitian, parity-even monomials, so $H=-\sum_{g\in\mathrm{basis}(L)}e_g$ has a unique ground state. The ground state is $T$-invariant, of definite parity, with gap 2.
- Exhaustive search for every cell with $n$ even $\le8$: a Lagrangian exists iff $c\equiv0$.
- Explicit construction for every $c\equiv0$ cell with $n\le16$: Witt pairs $e_if_i$ plus $[8,4,4]$ Hamming blocks.
- The Hamiltonian check for every such cell with $n\le12$.

[checked: rv·P_ss·4, 5]. The converse needs one line (ours): if $L=L^\perp$ is a Lagrangian, then
$$\sum_{x\in V}i^{w(x)}=\sum_{y\in V/L}i^{w(y)}\sum_{l\in L}(-1)^{b(y,l)}=|L|=2^{n/2},$$
whose phase is 0. So T14(4) ("Type II codes iff $8\mid n$") is literally "8 $T$-even Majorana chains can be gapped by a $T$-invariant interaction, fewer cannot". Furey's seven Fano-line blades (core·B11) are such an interaction. With the Atlas signs $H=-\sum_\ell e_\ell$ has spectrum $-7,-1^{7},+1^{7},+7$ and a unique ground state, in $Cl(8,0)$ and in $Cl(0,8)$ [checked: rv·P_ss·6]. Construction A on the same code gives the 240 roots of $E_8$ [checked: rv·P_ss·9]. — *fits*.

**L6. The mirror is a relabelling of $T$; the lattice address is the free index.** $T'=TP$ flips every $T$-parity, so the $T'$-invariant algebra is $Cl(q,p)$ with the invariants of $-c$ [checked: rv·P_ss·7]. In a lattice model of $p$ chains with $\Delta=+t$ and $q$ chains with $\Delta=-t$ (sweet spot, $L=12$):
- the bulk winding is $W=p-q$;
- the left end carries $p$ $T$-even and $q$ $T$-odd zero modes, and the right end the mirror $(q,p)$;
- random $T$-invariant end couplings leave $|p-q|$ per end (free $\mathbb Z$);
- $T$-breaking couplings leave $(p+q) \bmod 2$ (class D, $\mathbb Z_2$).

[checked: rv·P_ss·8, e.g. "(8,0): W=8, left 8+0, right 0+8, after T-inv. couplings 16, after T-breaking 0"]. So the second coordinate $p-q$ of the cell address is the free invariant ($\mathbb Z$), and the clock ($p-q \bmod 8$) the interacting one. "Period 8 is not a wall": free chains keep $W$. — *fits*.

**L7. Types are Dyson/Wigner classes.** On the irreducible complex module of $G=\{\pm e_a\}$ the Frobenius–Schur indicator is $+1,0,-1$ for types R, C, H, as in T4(iv). For FS $=\pm1$ a commuting antiunitary $T$ exists with $T^2$ = FS. For H-type every $G$-invariant Hermitian operator is Kramers-degenerate. — *fits* [checked: rv·P_ss·23, all 14 cells with $n\le4$].

**L8. The type table gives the periodic table at $d=0$.** For $k=0\dots10$ I built an irreducible real module of $Cl(0,k)$ inside the bit-rule regular representation, as the minimal ideal $AP$ with $P$ the product of $(1+e_a)/2$ over a maximal commuting set of square-$+1$ blades.
- The dimensions are $1,2,4,4,8,8,8,8,16,32,64$; the numbers of irreducibles are $1,1,1,2,1,1,1,2,1,1,1$.
- The restriction to $Cl(0,k-1)$ gives integer matrices, and their cokernels are $\mathbb Z_2,\mathbb Z_2,0,\mathbb Z,0,0,0,\mathbb Z,\mathbb Z_2,\mathbb Z_2$ for $k=1..10$. These are the entries $\pi_0(R_q)$ of Kitaev's table.
- The complex count gives $0,\mathbb Z,0,\mathbb Z,\dots$

— *fits* [checked: rv·P_ss·25, 26; standard: Kitaev, Table 1 and "an increase in $d$ corresponds to a step up (mod 8)", read]. The dimension shift (one Clifford generator per spatial dimension, via a Dirac representative) is *fits with an input*: the momentum, i.e. translations (Kitaev; Ryu–Schnyder–Furusaki–Ludwig, abstract read).

**L9. The Atlas's inputs are my field's phases.** CONV row 14 lists "a complex structure $J$, a time direction, a Witt split with a vacuum" as choices the algebra does not make. In band theory a gapped quadratic Hamiltonian, flattened, *is* such a $J$: $J^2=-1$, and $J$ fixes the Fock vacuum and the Witt split (INP-011). The topological invariant is $\pi_0$ of the space of $J$'s compatible with the cell's generators. The Kitaev ring shows the simplest case: two classes of $J$ ($\operatorname{sign}\mathrm{Pf}$) = ground-state fermion parity [checked: rv·P_ss·20]. — *fits*. This turns the Atlas's `input` flag into a classification problem that the bit rule can compute (L8).

**L10. The null part is what Hermiticity pairs away.**
- In the label basis a null generator acts as $L_e=c^\dagger$.
- $L_e+L_e^T$ is a Majorana.
- The real algebra generated by all $L_e$ and $L_e^T$ has dimension $2^{p+q}4^r$, generated by $p+r$ anticommuting square-$(+1)$ and $q+r$ square-$(-1)$ elements. So the $*$-closure of $Cl(p,q,r)$ is $Cl(p+r,q+r)$, clock $p-q$.
- A symmetric $N$ with $N^2=0$ is zero.

[checked: rv·P_ss·12, all $Cl(p,q,r)$ with $n\le4$]. Hence every symmetry operator of an Altland–Zirnbauer class (an invertible (anti)unitary) and every flattened Hamiltonian lives in a non-degenerate cell.

Gapless points appear in the Atlas's other two kinds of null (CONV gloss 12):
- **Paired null.** The exceptional point of the PT dimer $H=\kappa\sigma_x+i\gamma\sigma_z$ is a null vector of $Cl(1,1)$ with partner $\kappa\sigma_x-i\gamma\sigma_z$. Its splitting exponent is $1/2$, against $1$ at a Hermitian crossing [checked: rv·P_ss·11 "splitting exponents 0.500 (EP) and 1.000 (diabolic)"]. The PT experiment of Rüter et al. (2010) is the measured face [standard: abstract read].
- **Element-square null.** A band edge: the one-period matrix has $X^2=0$, $X\neq0$, and the density of states diverges as $|E-E_e|^{-1/2}$ [checked: rv·P_ss·13].

— *fits*, and answers QC3 (B3).

**L11. Genesis ideas in my language.**
- Idea A is Pauli exclusion (T20(b)).
- Idea B ("polarization, an extra datum") is the CAR once a positive inner product is given: the partner is the adjoint (L10). So the extra datum is the $*$-structure (B13).
- Idea C's 8 is the Fidkowski–Kitaev 8 (L5).

— *fits with an input* (the inner product).

**L12. Springs and lattices (step 15).**
- The signed network's signs are the Kogut–Susskind phases $\eta_\mu(x)=(-1)^{x_1+\dots+x_{\mu-1}}$ on the magnetic unit cell (the $n$-cube of labels).
- The Bloch Hamiltonian is $H(k)=\sum_\mu 2\cos k_\mu L_\mu$, with $H(0)=2D$ and $H(k)^2=4\sum\cos^2k_\mu$. It agrees with real-space diagonalisation for $n=2,3$.
- At the Dirac point $k_\mu=\pi/2$ the $2^n$ zero modes are (irrep $2^{\lfloor n/2\rfloor}$) × ($2^{\lceil n/2\rceil}$ tastes) [checked: rv·P_ss·18].
- A naive first-order stencil has $2^d$ zeros and a Wilson mass leaves one [checked: rv·P_ss·30].
- The Clifford signing is the unique minimiser of the half-filled energy over all $\mathbb Z_2$ gauge fields on the $n$-cube: exhaustive for $n=2,3,4$, and for all $n$ by Cauchy–Schwarz (D5) [checked: rv·P_ss·27; standard: Lieb, flux phase π per square plaquette for planar bipartite graphs, abstract read].
- It stays the unique minimiser with Hubbard repulsion $U=0,2,4,8$ on the 3-cube [checked: rv·P_ss·31].
- Vector springs (the open item MAP-033). The $n$-cube frame has zero modes = $\binom{n+1}2$ rigid motions (the PGA bivectors) + mechanisms: $1, 6, 22, 65$ for $n=2..5$, with no state of self-stress. The cube braced by six face diagonals is rigid. The Calladine/Kane–Lubensky index $N_0-N_{ss}=dN-N_b$ and the chiral (class BDI) form $\begin{pmatrix}0&C\\C^T&0\end{pmatrix}$ hold [checked: rv·P_ss·19; standard: Kane–Lubensky, eq. (1)–(2), read].

— *fits* (with an input for the Dirac cones: translations).

**L13. Rigid bodies (step 16).** The tennis-racket flip (RSN-006, sign of $\mu$) is the element-square trio on the Euler flow: stable, marginal, unstable. The rigid motions are the trivial zero modes of L12. — *fits* [Atlas checked: pgadyn_selfcheck (Atlas log, not rerun by me)]. Measurable: the intermediate-axis flip [pointer, source unread].

**L14. Maxwell (Calibration 1) in media.** In premetric form ($dF=0$, $dH=J$, $H=\chi(F)$):
- The vacuum $\chi$ of $\eta$ gives the Fresnel polynomial $\pm(\eta(k,k))^2$, which is the Atlas's $\nabla F=J$. The constitutive relation is therefore an input.
- The $\chi$'s split $36=21+15$, and inside the 21: $1$ (axion) $+20$ (principal) [checked: rv·P_ss·14; standard: Jancewicz, "36 = 20 + 15 + 1", read].
- The axion part gives the wave operator $\chi^{abcd}k_bk_c\equiv0$: a constant $\theta$ is invisible to every bulk wave and acts only through $d\theta$.
- A uniaxial medium factors into ordinary × extraordinary quadric. The extraordinary form has signature $(1,3)$, $(2,2)$, $(3,1)$ (odd direction $z$) or definite, according to the signs of $(\varepsilon_\perp,\varepsilon_\parallel)$. With the Atlas's hyperbolicity test it is hyperbolic in $t$ only for $(+,+)$, in $z$ only for $(+,-)$, and never in the other two [checked: rv·P_ss·15].
- With a Drude axis the iso-frequency surface is a hyperboloid below $\omega_p$ and an ellipsoid above. As $\omega\to\infty$, $\varepsilon\to1$, so the time-domain principal symbol is the vacuum Lorentzian one [checked: rv·P_ss·16; standard: Smolyaninov–Narimanov, "(−−++) effective metric signature" and the stress on dispersion, read].
- The relative sign of source and force follows from Poynting's theorem with $u=\tfrac12(E^2+B^2)>0$: the balance is $0$ with the textbook sign and $2J\cdot E$ with the flipped source [checked: rv·P_ss·17].

— *fits with an input* (the constitutive relation; units $c=\varepsilon_0=\mu_0=1$; positivity of the energy). See B5–B8.

**L15. Charges tab.** The Lorentz force as the grade-1 part of $Fu$, cyclotron circle, hyperbola, $E\times B$ drift, plane wave and Sommerfeld-type perihelion advance are textbook. The same drift is the Hall effect; cyclotron resonance measures effective masses in crystals. — *fits* [Atlas checked: maxwell_selfcheck "ALL MAXWELL CHECKS PASS", rerun by me]. The orientation convention cancels between $B$ and the force (the force uses $F$, not $I$) [ours].

**L16. Dirac and spin pages.**
- **Weyl nodes.** No non-zero $2\times2$ matrix anticommutes with $\sigma_{x,y,z}$, so a Weyl node is ungappable. Its chirality is the eigenvalue of the central pseudoscalar, $\chi^3\sigma_x\sigma_y\sigma_z=\chi i$. The lower band of $\chi\sigma\cdot k$ has Chern number $-\chi$. A $4\times4$ Dirac node has a $U(1)$ circle of anticommuting masses [checked: rv·P_ss·24]. The Fermi arcs of TaAs are the measured face [standard: Xu et al., abstract read].
- **Kitaev projection.** Kitaev's honeycomb spin $\sigma^a=ib^ac$ with $D=b^xb^yb^zc$: $D$ is the central top blade of $Cl^0(4,0)=Cl(0,3)$, and $\sigma^x\sigma^y\sigma^z=iD$. The gauge projection $D=\pm1$ is the Atlas's central split, and it selects the chirality [checked: rv·P_ss·28].
- **Dirac mass shell.** "The Dirac kernel at a given momentum has one sign of energy" (equations copy) is band language for fixed $(E,\mathbf k)$ on shell: two spin states [fits; Atlas checked S23].
- **Bloch ball.** T15's Bloch ball is spin-1/2 polarisation [fits].

**L17. Finite groups (step 17).**
- The 3-bit labels with XOR are $mmm$, and $\pi$ is the determinant (improper operations).
- Spin-1/2 double group with "inversion acts as +1": the mirror lifts $M_k=I\otimes(-i\sigma_k)$ obey the sign table of $Cl(0,3)$, and the group is $Q_8\times\mathbb Z_2$.
- With "inversion acts as $i$" the sign table is that of $Cl(3,0)$ (the Pauli group) [checked: rv·P_ss·21].
- $B_3=O_h$ and $D_3\cong T_d$. 2.A4 maps to 12 rotations with integer traces. 2.A5 maps to 60 rotations with traces $(1\pm\sqrt5)/2$: crystallographic restriction [checked: rv·P_ss·22].

The F₂ forms, $W(E_n) \bmod 2$, the Golay code, $M_{24}$ and the Monster have no counterpart in crystal point groups: scope (one line). — *fits* for the point-group part.

**L18. Furey (Calibration 2).**
- Her $V$ (real 16) with $Cl(0,8)=\mathrm{End}_{\mathbb R}(V)$ is the real edge space of 8 Majoranas, and her Fano-line blades are FK couplings (L5).
- In her explicit model (`witt_test.py`) the sign patterns of the 7 line blades on the 16 axes form a perfect Hamming $[7,4,3]$ code, so every one of the 128 sign choices of an FK interaction has a unique ground state.
- Her own line orientation is not a character: the minimum is $-5$, on axis 14 (block H).
- No sign choice has levels that contain her six blocks, and none has levels that lie inside them.

[checked: rv·P_ss·10]. — *fits* for the shared code, *does not fit* for the partition (D3). The Standard Model content of her edges is outside my field.

**L19. Lenses.**
- **Category.** T6(a) (sign unique up to gauge, $H^1=0$) holds on the cube. On a ring $H^1(S^1;\mathbb F_2)=\mathbb F_2$, and the two classes are periodic and antiperiodic boundary conditions. A Kitaev ring has opposite ground-state parities in them exactly when $|\mu|<2t$ [checked: rv·P_ss·20]. This is a measurable sign class (fermion-parity switch; the $4\pi$ Josephson effect is a pointer, source unread). T3, T8, QB1–QB5: outside my field.
- **Baez.** Kepler: $so(4)$/$e(3)$/$so(3,1)$ (core·B16) are the bound, threshold and scattering regimes of hydrogen, whose $n^2$ degeneracy is measured (pointer, textbook). Madelung is an approximation, as the Atlas says. The $E_6$/$E_7$/generation chapters are outside.
- **Schuller.** F4 area metric = constitutive tensor (L14). F2 = optical hyperbolicity (L14). F13 = Bloch bands (L10). F7 = Fock (T20). F9 = Dirac sign (L16). F5: $\sum S_i^2=3/4$, measured as spin-1/2 (pointer).
- **Hestenes/LDG.** STA through Maxwell and Dirac (L14–L16). Gauge-theory gravity is outside (analogue horizons in fluids or BECs: pointer, source unread).
- **Pumplün** (crossed products, Petit algebras): outside my field.

**L20. Gravity, projective, null-surface steps (9–13).** Outside my field, except two facts. The strain $S$ of ATL-018 is the Green–Lagrange strain. The little group $iso(2)$ at $T=0$ (NUL-004) is the photon's, and polarisation of light is measured (pointer). — scope.

**L21. Theorems.**
- T1: Jordan–Wigner consistency.
- T2: Grassmann radical.
- T4: FS = Wigner type (L7).
- T5: Kitaev's even algebra (L16).
- T6: JW gauge (L19).
- T7: Tian's chain is a hyperbolic (Witt) basis of Cl(m,m), the CAR in a chain basis (L11) (ours).
- T11: Peres–Mermin. Its nine observables are the published nine (Kirchmair et al., read): all real symmetric two-qubit products, i.e. $Q=0$ labels of $Cl(2,2)$ (L2).
- T14: FK collapse (L5).
- T15: Bloch, and "states vanish on $J$" (L10).
- T16: Dirac shell.
- T17: rotation/boost/translation.
- T18: optical hyperbolicity (L14).
- T19: bands (L10).
- T20: Fock space.
- T3, T8, T9, T10, T12, T13: outside my field.

## 4. Breaks

| B | Atlas ids | what my field says | what the Atlas says | minimal computation or counterexample | kind | natural patch |
|---|---|---|---|---|---|---|
| B1 | LAB-018, QD2 (first half), CONV gloss 8 | The Brown invariant *is defined* as the phase of $\sum_x e^{2\pi i q(x)/4}$ for a $\mathbb Z_4$ enhancement of a non-singular form (Kirby–Taylor L. 3.6, read); it realises $\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$ (Kapustin et al., read); physically it is the FK index | "calling the clock the Brown invariant is our identification … pointers, sources unread"; QD2 open | core·B1 ($w$ refines the non-degenerate dot product) + core·B3 (Gauss sum); rv·P_ss·2, 3 | DICTIONARY | "The clock is the Brown invariant of $(V,w)$ by definition (Kirby–Taylor, Lemma 3.6) [standard+checked: core·B1, core·B3]; it is the Fidkowski–Kitaev index of Majorana edges [checked: rv·P_ss·2–5]." |
| B2 | S2 verdict ("the ten symmetry classes of matter are our reading only"), QC3 premise | Kitaev (read): the 2 + 8 rows of the periodic table correspond to the 2 complex and 8 real Clifford types, with $d$ shifting the row; RSFL (read): the 8-fold periodicity is that of spinors | reading only (ours) | rv·P_ss·25, 26 (ABS cokernels from bit-rule modules = $KO^{-k}$, $KU^{-k}$) | DICTIONARY | "The eight clock values and two complex classes are the ten symmetry classes: standard (Kitaev 2009, Table 1); the $d=0$ entries are recomputed from the bit rule [checked: rv·P_ss·25, 26]." |
| B3 | QC3 ("does a nilpotent generator correspond to anything physical … gapless or degenerate directions, or is it simply absent?") | In any $*$-representation a null generator is paired by its adjoint; AZ symmetries are invertible; gapless points are paired nulls (EPs, non-Hermitian) or element-square nulls (band edges) | open | rv·P_ss·12 ($*$-closure $Cl(p+r,q+r)$), rv·P_ss·11 (EP), rv·P_ss·13 (van Hove) | GAP | "Absent from the Hermitian tenfold way: the $*$-closure of $Cl(p,q,r)$ is $Cl(p+r,q+r)$ [checked: rv·P_ss·12]; nulls of kinds (2) and (3) of the glossary carry the gapless physics (exceptional points, band edges) [checked: rv·P_ss·11, 13]; the radical remains a non-Hermitian object (D6)." |
| B4 | INP-016, INP-083, LNC clock line | Weight 0 for a null bit is what the Hermitian closure gives | "a convention of the page" | rv·P_ss·12: clock of $Cl(p+r,q+r)$ is $p-q$ | GAP | "A null bit has weight 0: this equals the clock of the $*$-closure $Cl(p+r,q+r)$ [checked: rv·P_ss·12]; it costs the inner product (the involution input of T15), nothing else." Flag: checked+input. |
| B5 | INP-001…004, PAG-010, MAP-004 (needs of Calibration 1) | Maxwell = $dF=0$, $dH=J$ plus a constitutive relation $H=\chi(F)$; $\nabla F=J$ is the vacuum case $\chi=\star_\eta$ in units $c=\varepsilon_0=\mu_0=1$ | the inputs listed are the equation, chart, grades, time and sign; no constitutive relation, no units | rv·P_ss·14 (premetric operator; vacuum Fresnel $\propto(\eta(k,k))^2$; the 36-dim space of $\chi$) | GAP | Add two input lines to maxwell/views: "(input) the vacuum constitutive relation $H=\star_\eta F$; in a medium $H=\chi(F)$ with 36 components (20 principal, 15 skewon, 1 axion)"; "(input) units with $c=\varepsilon_0=\mu_0=1$ (Heaviside–Lorentz)." |
| B6 | PAG-008, MAP-003, CONV row 2 ("exactly two sign choices … differ by an overall sign"), charges tab | The overall sign is the charge convention; the relative sign of source term and force law (like charges repel, Lenz) is fixed by energy conservation with a positive field energy | both are matched separately to the textbook; "nothing is predicted" | rv·P_ss·17: balance $0$ (textbook) vs $2J\cdot E$ (flipped source), 200 exact random fields | GAP | "The relative sign of $J$ in $\nabla F=J$ and of $q$ in the force is not free: with $u=\tfrac12(E^2+B^2)>0$ energy conservation fixes it [checked: rv·P_ss·17]; input: positivity of the field energy." |
| B7 | LNS-013 ("General linear electrodynamics has an area metric with 21 independent components") | Local linear media have 36 constitutive components = 20 + 15 + 1 (Jancewicz, read); 21 is the Lagrangian (pair-symmetric) case; the 1 axion part is invisible to every bulk wave operator but measured in topological insulators (Wu et al., abstract read) | 21 | rv·P_ss·14: "36 = 21 + 15; axion 1, principal 20; chi^abcd k_b k_c = 0 identically" | SCOPE | "… with 21 independent components when the constitutive law comes from a Lagrangian (pair symmetry); a general local linear medium has 36 (15 skewon). The ε part is invisible to the principal polynomial and to the wave operator [checked: rv·P_ss·14]." |
| B8 | INP-010, CONV row 5, maxwell ladders | Indefinite (hyperbolic) media realise $(2,2)$ and $z$-time Lorentzian extraordinary dispersion at fixed frequency (Smolyaninov–Narimanov, read); causal dispersion makes the time-domain principal symbol Lorentzian, so T18's verdict and physics agree | "extra time generators are a mathematical exercise here" | rv·P_ss·15 (signature map), rv·P_ss·16 (Drude: hyperboloid below $\omega_p$, vacuum symbol as $\omega\to\infty$) | SCOPE | "Extra time generators have one physical home: the fixed-frequency dispersion of indefinite media (input: $\chi(\omega)$), measurable as iso-frequency surfaces; as a principal symbol a causal medium is Lorentzian in $t$ [checked: rv·P_ss·15, 16]." |
| B9 | SPR-004, MAP-026 ("Whether it is the Dirac operator on the demicube in a stronger sense is open") | $D$ is $H(0)/2$ of the π-flux (Kogut–Susskind) lattice; the Dirac operator lives at $k=\pi/2$ with $2^{\lceil n/2\rceil}$ tastes; it needs the translations of the lattice | open | rv·P_ss·18 | GAP | "D is the zone-centre Bloch Hamiltonian (÷2) of the π-flux lattice whose Bloch Hamiltonian is $\sum_\mu2\cos k_\mu L_\mu$; its Dirac points need the lattice translations (input) [checked: rv·P_ss·18]." |
| B10 | MAP-033, RIG-006, SPR-004 ("one scalar displacement … real springs need vector displacements"; "to check on our matrix; not done") | Settled: the $n$-cube frame has $\binom{n+1}{2}$ rigid + $(n2^{n-1}-\binom{n+1}2)$ floppy modes, no self-stress; the braced cube is rigid | open | rv·P_ss·19 | GAP | "Checked [rv·P_ss·19]: 12 bars, zero modes 12 = 6 rigid (the PGA bivectors) + 6 mechanisms; 18 bars (one diagonal per face): 6 zero modes, rigid; for $n=4,5$: 22, 65 mechanisms; Calladine index and the BDI form hold." |
| B11 | core·B14 text ("it splits the algebra in two: Cl(1,0), Cl(2,1), Cl(3,2), Cl(4,3), the signed cells [n,+1]") | The split cells are all with $p-q\equiv1 \bmod 4$: also $Cl(0,3)$, $Cl(1,4)$, $Cl(5,0)$, $Cl(0,7)$, $Cl(2,5)$, $Cl(6,1)$; $Cl(0,3)=Cl^0(4,0)$ is the split used in Kitaev's honeycomb | the list names only $[n,+1]$ (the check itself tests the correct condition) | rv·P_ss·29 | DICTIONARY | "(it splits the algebra in two exactly when $p-q\equiv1 \bmod 4$: e.g. Cl(1,0), Cl(0,3), Cl(2,1), Cl(5,0), Cl(4,3); the signed cells [n,+1] are one family of them)." |
| B12 | CONV rows 6 and 11 (mirror "a change of naming … no dynamics"; Pin "not treated") | For one system the mirror is the relabelling $T\mapsto TP$ (fits); for two systems under one $T$ the *relative* clock is physical (junction zero modes); for point-group lifts the mirror is the rephasing of improper elements by $i$, a convention only when a $U(1)$ charge exists; for neutral (Majorana) fermions Pin± is a physical choice | naming; Pin open | rv·P_ss·7, 8 (two ends of one chain carry $c$ and $-c$), rv·P_ss·21 (double groups) | GAP | "The mirror is a change of naming for a single system [checked: rv·P_ss·7]; differences of clocks of systems sharing one time reversal are invariant and observable [rv·P_ss·8]; on point-group lifts it swaps Pin± (inversion $+1$ vs $i$) [rv·P_ss·21], which is a convention iff a $U(1)$ is present (input)." |
| B13 | GEN-003, idea H1 ("a pairing … is added (an extra datum)") | In quantum mechanics the extra datum is the positive inner product: the partner of $n$ is $n^\dagger$ and $\{n,n^\dagger\}=1$ is the CAR | extra datum, unnamed | rv·P_ss·12 ($L+L^T$ squares to 1) | GAP | "… an extra datum: a positive inner product ($*$-structure); with it the partner is the adjoint and the pair is a fermion mode [checked: rv·P_ss·12]." |
| B14 | PAG-020, MAP-014, QD2 (second half: "is it the same $\mathbb Z_8$ as the signature mod 8 of an even lattice?") | Both phases are a signature mod 8 read through a Gauss sum. The clock is the Brown invariant of $(\mathbb Z^{p,q}/2\mathbb Z^{p,q},\,x\cdot x \bmod 4)$: its exponent is $\mathrm{pos}-\mathrm{neg}=x\cdot x$ (core·B2), the odd lattice $I_{p,q}$. core·B13 is the Gauss–Milgram phase of the even $E_n$. The stop at 9 ($\det=9-n$) is separate, as the Atlas says | "whether they are related … is open" | core·B2, B3 (odd $I_{p,q}$), core·B13 (even $E_n$) | DICTIONARY | "Both 8s are the signature mod 8 of a lattice read through a Gauss sum: of $I_{p,q}$ for the clock [checked: core·B2, B3], of $E_n$ for core·B13 [checked]; whether this is one $\mathbb Z_8$ as Witt groups: ours, reduces to Milgram/van der Blij (pointer, source unread); the stop of the $E_n$ series is not this fact." |
| B15 | SHP-003 ("Lattice stencils fit too: the faces are the neighbours of a cell of the integer lattice") | A first-order stencil on $\mathbb Z^d$ has $2^d$ zeros of its symbol (fermion doubling); a Wilson mass (one more anticommuting generator) removes all but one and breaks the chiral symmetry; staggering leaves $2^{\lceil d/2\rceil}$ tastes | fits (ours), no doubling mentioned | rv·P_ss·30, rv·P_ss·18 | SCOPE | "Lattice stencils fit, with fermion doubling: the naive first-order symbol vanishes at the $2^d$ corners of the Brillouin zone [checked: rv·P_ss·30]; the signed (Kogut–Susskind) stencil keeps $2^{\lceil d/2\rceil}$ tastes [rv·P_ss·18]." |

No break is of kind WRONG. Every computed statement of the Atlas that I reran, or used as ground, held. The breaks are under-claims (B1, B2, B14), unnamed inputs (B5, B6, B13), open items my field closes (B3, B4, B9, B10), scope (B7, B8, B15), and one incomplete list (B11).

## 5. Patches

**B1 (LAB-018, QD2 first half).** Patched statement: "The clock $c=p-q \bmod 8$ is the Brown invariant of $(\mathbb F_2^n,w)$, $w=\pi+2Q$. By definition (Kirby–Taylor, Lemma 3.6) the Brown invariant is the phase of the Gauss sum of a $\mathbb Z_4$ enhancement of a non-singular form, and $w$ is one (core·B1). The sum is $(1+i)^p(1-i)^q$ (core·B3). It is also the Fidkowski–Kitaev index of an edge with $p$ $T$-even and $q$ $T$-odd Majoranas (rv·P_ss·2–5)."
- New flag: standard + checked.
- Cost: none; two citations (Kirby–Taylor, read; Kapustin et al., read).

**B2 (S2 verdict; QC3 premise).** Patched statement: "The eight clock values and the two complex classes correspond to the ten symmetry classes of free-fermion matter (standard: Kitaev 2009, Table 1; Ryu–Schnyder–Furusaki–Ludwig 2010). Their $d=0$ invariants $KO^{-k}(\mathrm{pt})$, $KU^{-k}(\mathrm{pt})$ are the ABS cokernels of the bit-rule modules (rv·P_ss·25–26). The dimension shift needs one Clifford generator per momentum (input: translations)."
- New flag: standard + checked + input.
- Cost: the momentum input.

**B3 (QC3 answer).** Patched statement: "In a Hilbert-space (positive $*$-) representation a null generator acts as a creation operator, and its adjoint is its partner. The $*$-closure of $Cl(p,q,r)$ is $Cl(p+r,q+r)$ (rv·P_ss·12). Hence no Altland–Zirnbauer class contains a null generator. Gapless physics appears through the other two kinds of null of the glossary: the paired null of $Cl(1,1)$ at an exceptional point (rv·P_ss·11), and the element of square 0 at a band edge (rv·P_ss·13)."
- New flag: checked; the rest of QC3 moves to D6 (open).
- Cost: the involution (already an input of T15).

**B4 (INP-016, INP-083).** Patched statement: "A null bit adds weight 0 to the clock sum. This is the clock of the Hermitian closure $Cl(p+r,q+r)$ (rv·P_ss·12); it costs the involution input of T15."
- New flag: checked + input (was: input as a bare convention).

**B5 (Calibration 1 inputs).** Add to `needs_inputs.md`, maxwell/views:
- "(postulate) the constitutive relation: in vacuum $H=\star_\eta F$; in a medium $H=\chi(F)$ with 36 components (20 principal, 15 skewon, 1 axion)."
- "(convention) units $c=\varepsilon_0=\mu_0=1$; in SI $F=E+cIB$ and the source carries $1/\varepsilon_0$."

New flag: input. Cost: none (it names what is used).

**B6 (two sign solutions).** Add to PAG-008: "The overall sign is the charge convention. The relative sign of the source term and of the force law is fixed by energy conservation with a positive field energy (rv·P_ss·17)."
- New flag: checked + input (input: $u>0$).

**B7 (LNS-013).** Replace "General linear electrodynamics has an area metric with 21 independent components" by: "General linear electrodynamics derived from a Lagrangian has an area metric with 21 independent components (20 principal + 1 axion); a general local linear medium has 36 (Jancewicz 2008, read). The axion component does not enter the wave operator $\chi^{abcd}k_bk_c$ (rv·P_ss·14)."
- Flag: standard + checked.

**B8 (INP-010).** Replace "Extra time generators are a mathematical exercise here" by: "Extra time generators have no time-domain realisation: a causal medium has a Lorentzian principal symbol (rv·P_ss·16). At fixed frequency, indefinite media give the extraordinary waves a $(2,2)$ or a $z$-time Lorentzian dispersion (Smolyaninov–Narimanov; rv·P_ss·15), measurable as iso-frequency surfaces."
- Flag: standard + checked + input ($\chi(\omega)$).

**B9 (SPR-004).** Replace the open clause by: "D is the zone-centre Bloch Hamiltonian (÷2) of the π-flux (Kogut–Susskind) lattice, $H(k)=\sum_\mu2\cos k_\mu L_\mu$. Its Dirac points at $k_\mu=\pi/2$ carry $2^{\lceil n/2\rceil}$ tastes (rv·P_ss·18). The Dirac operator in the strong sense needs the translations (input)."
- Flag: checked + input.

**B10 (MAP-033, RIG-006).** Replace "To check on our matrix; not done" by the checked counts of rv·P_ss·19.
- Flag: checked (was open).

**B11 (core·B14 text).** Replace the parenthesis by "(it splits the algebra in two exactly when $p-q\equiv1 \bmod 4$, e.g. Cl(1,0), Cl(0,3), Cl(2,1), Cl(5,0), Cl(4,3); the signed cells [n,+1] are one family of them)".
- No change to the check.

**B12 (CONV rows 6, 11).** Add: "For one system the mirror is a relabelling (in Majorana language, $T\mapsto TP$, rv·P_ss·7). For systems that share one time reversal, the difference of clocks is invariant and observable: the two ends of one chain carry $c$ and $-c$ (rv·P_ss·8). On point-group lifts the mirror swaps the two double groups (inversion $+1$ or $i$, rv·P_ss·21). That swap is a convention iff a $U(1)$ charge is present."
- Flag: checked + input (presence of $U(1)$). Row 11 stays open for Pin groups in general.

**B13 (GEN-003, H1).** Replace "an extra datum" by "an extra datum: a positive inner product (the $*$-structure); with it the partner of $n$ is $n^\dagger$ and $\{n,n^\dagger\}=1$ is the canonical anticommutation relation (rv·P_ss·12)".
- Flag: checked + input.

**B14 (PAG-020, QD2 second half).** Add: "Both 8s are signatures mod 8 read through Gauss sums: of the odd lattice $I_{p,q}$ for the clock (core·B2, B3), of the even $E_n$ for core·B13. That they are one $\mathbb Z_8$ of quadratic forms is ours (Milgram/van der Blij: pointer, source unread)."
- Flag: checked + ours.

**B15 (SHP-003).** Add: "… with fermion doubling: the naive first-order symbol vanishes at all $2^d$ corners of the Brillouin zone; the Kogut–Susskind signs keep $2^{\lceil d/2\rceil}$ tastes (rv·P_ss·30, 18)."
- Flag: ours + checked.

## 6. Discoveries to explore

**D1. The clock as a measurable $\mathbb Z_8$: junctions of BDI wire stacks.**
- *Question.* For two stacks of $T$-invariant (BDI) Majorana chains with windings $W$, $W'$ joined end to end, is the junction's protected ground-state degeneracy, with generic $T$-invariant interactions, a function of the clock difference $(W-W') \bmod 8$ alone? The Atlas predicts the pattern: non-degenerate for $0$; 2-fold for $\pm2$ and $4$, with $T^2=-1$ (Kramers) at 4. Free fermions instead keep $|W-W'|$ zero modes.
- *Why it does not yet fit.* The edge computation (rv·P_ss·3) treats an isolated edge. A junction is a many-body problem with interactions on both sides.
- *Smallest decisive computation.* Exact diagonalisation of two short stacks away from the sweet spot ($\mu\neq0$, so that the bulk does not decouple), $W=8$ against $W'=0$: 8 chains × 2 sites = 32 Majoranas, dimension $2^{16}$, sparse Lanczos. Use a $T$-invariant FK interaction at the junction sites and compare the ground-state degeneracy with and without it. Then repeat with $W-W'=4$ (expect 2-fold, $T^2=-1$) and $W-W'=2$.
- *Outcomes.* If the pattern holds, the clock is an experimental observable: zero-bias tunnelling at the junction would show $(W-W') \bmod 8$, not $|W-W'|$. If it fails, the edge algebra misses junction physics (e.g. bulk gap closing), and the dictionary of §3 L4 is edge-only.
- *Done.* The edge part (rv·P_ss·2–5) and the free lattice part (rv·P_ss·8).
- *Experimental handle.* Multi-channel chiral-symmetric wires or cold-atom chains (proposal; I know no specific realisation, unsure).

**D2. Is Kitaev's 16-fold way the square root of the clock?**
- *Question.* The Atlas Gauss sum for $n$ generators has modulus $2^{n/2}$, i.e. $\sqrt2$ per generator. That is the quantum dimension of a Majorana zero mode (ours). Its phase is $e^{i\pi(p-q)/4}$. For 2D class D with $\nu$ Majorana edge modes, the Gauss–Milgram phase of the anyon theory would be $e^{2\pi i\nu/16}$ (pointer, source unread: Kitaev 2006). This is the square root of the clock phase. Is there a $\mathbb Z_8$-valued refinement of $w$ (a "half clock") whose Brown-type sum gives $\nu \bmod 16$, e.g. a weight $e^{i\pi/8}$ per generator, and does it relate to $\Omega_4^{\mathrm{Pin}^+}=\mathbb Z_{16}$ (pointer, source unread)?
- *Why it does not fit.* The Atlas's $w$ is $\mathbb Z_4$-valued and only sees $\nu \bmod 8$. The 16-fold way needs a twice finer phase.
- *Smallest decisive computation.* Tabulate $\sum_a d_a^2\theta_a$ for the 16 Ising-type theories, with data from the read source once read, against $(1+i)^p(1-i)^q$ squared or square-rooted.
- *Outcomes.* "Yes" gives a second clock for 2D matter. "No" means the 16-fold way is outside the label calculus.
- *Done.* Nothing beyond core·B3.

**D3. Furey's partition is not selected by the FK structure.**
- *Question.* Do Furey's six blocks of $V$ come from the energy shells of a time-reversal-invariant quartic interaction built from her own Fano-line blades?
- *Done* [checked: rv·P_ss·10]:
  - the 16 axis patterns form a perfect Hamming $[7,4,3]$ code;
  - every sign choice gives a unique ground state (shapes $(1,7,7,1)$ ×16, $(1,3,4,4,3,1)$ ×112);
  - none of the 128 has levels that contain her blocks, and none has levels that lie inside them;
  - her own orientation is not a character (minimum $-5$ on axis 14, block H).
- *Meaning.* Her $V$ and lines are an FK edge with its gapping code. Her partition is extra input, independent evidence for FUR-003's "the partition is input". Clean "does not fit".
- *Next decisive computation.* None needed for the FK question. A different candidate (an FK term plus one quadratic $T$-odd term) could be tested the same way.

**D4. The axion blind spot of the hyperbolicity/closure pipeline.**
- *Question.* Schuller's pipeline starts from the principal polynomial (LNS-012/013). The axion component of the 21 drops out of the wave operator identically (rv·P_ss·14) and of the Fresnel polynomial. Yet its value $\theta=\pi$ in a 3D topological insulator is measured through quantized Faraday/Kerr rotation (Wu et al., abstract read). Does the gravitational closure of general linear electrodynamics constrain the ε part, which Schuller's background contains (LNS-013, $|\varepsilon\cdot G|=24$), or is it a free constant like $\theta$?
- *Why it does not fit.* Hyperbolicity and energy-distinguishing conditions see only the principal part; the axion enters the field equations only through $d\theta\wedge F$ (surfaces).
- *Smallest decisive computation.* Write the closure equations for $G=G_{\mathrm{principal}}+\theta\varepsilon$ and check whether $\theta$ appears in any coefficient. The input is Schuller's closure equations (not rebuilt in the Atlas: S6, S7 dead ends).
- *Outcomes.* If $\theta$ is absent, the closure leaves a measurable constant undetermined, mirroring the TI. If present, the closure would fix what materials show to be free.
- *Done.* The wave-operator independence.

**D5. Lieb's flux phase on hypercubes from the Clifford relation, with interactions.**
- *Statement (ours, proof).* For any $\mathbb Z_2$ gauge field $s$ on the $n$-cube, $\operatorname{tr}A_s^2=n2^n$ and $\operatorname{tr}A_s=0$, so
$$E_{\mathrm{half}}(s)=-\tfrac12\sum_i|\lambda_i|\ \ge\ -\tfrac12\sqrt{2^n\,n2^n}=-2^{n-1}\sqrt n .$$
Equality holds iff $A_s^2=nI$, iff the flux through every square face is π: the Atlas/Huang signing.
- *Checked.* Exhaustively over all flux sectors for $n=2,3,4$ (2, 32, 131072 sectors) [rv·P_ss·27]. With Hubbard $U=0,2,4,8$ on the 3-cube (Hilbert space 4900) the all-π sector stays the unique minimiser [rv·P_ss·31].
- *Question.* Does it hold for the Hubbard model on the $n$-cube for all $n$ and $U$ (Lieb's theorem covers planar bipartite graphs and higher dimensions with periodicity, abstract read)?
- *Smallest decisive computation.* The 4-cube at half filling ($\binom{16}{8}^2\approx1.6\times10^8$ states) is beyond plain ED here. A sector-by-sector DMRG, or reflection-positivity arguments, would decide it.
- *Meaning.* If yes, the bit-rule sign is the ground-state gauge field of interacting fermions on the cube, a physical selection of the Atlas sign.

**D6. Is the radical (label 0) a non-Hermitian object?**
- *Question.* The Hermitian closure pairs every null (B3), but open systems are not closed under adjoints. Is there a physical operator algebra that is exactly $Cl(p,q,r)$ with $r\ge1$? Candidates: effective Hamiltonians at higher-order exceptional points (Jordan blocks); Lindbladians with pure loss, where only annihilators act.
- *Smallest decisive computation.* For a PT dimer at its EP, the algebra generated by $H$ alone is the dual numbers $Cl(0,0,1)$; with its partner it is $M_2$ (rv·P_ss·11). Next: the superoperator algebra of a single lossy mode, $\mathcal L(\rho)=c\rho c^\dagger-\tfrac12\{c^\dagger c,\rho\}$. Compute whether the jump superoperator $\rho\mapsto c\rho c^\dagger$ generates an algebra with a radical, and its Loewy length.
- *Outcomes.* "Yes" gives the null part a measurable home: square-root splittings (exponent $1/2$, rv·P_ss·11, measured in PT optics). "No" leaves the radical as bookkeeping (Grassmann directions, T15).

## 7. Code

All scripts are in `$SP/atlas11/rv_P_ss/review2/P_ss/`, copied with logs to `$SP/atlas11/review2/out/P_ss_code/`. Each has the 3-line licence header of `core_check.py`, is deterministic, prints one `ok`/`FAIL` line per check id, and exits non-zero on failure. They use Python 3, numpy, and scipy (sparse, one script).

| script | command | runtime | checks | result line |
|---|---|---|---|---|
| `ss_fk_clock.py` | `python3 -I ss_fk_clock.py` | 3.4 s | rv·P_ss·1–9 | `ALL ss_fk_clock checks done` (9 ok) |
| `ss_furey_fk.py` | `python3 -s ss_furey_fk.py` (imports the clone's `model.py`) | <1 s | rv·P_ss·10 | `ALL ss_furey_fk checks done` |
| `ss_null_bands.py` | `python3 -I ss_null_bands.py` | 2.2 s | rv·P_ss·11–13 | `ALL ss_null_bands checks done` |
| `ss_maxwell_media.py` | `python3 -I ss_maxwell_media.py` | 0.3 s | rv·P_ss·14–17 | `ALL ss_maxwell_media checks done` |
| `ss_lattice_springs.py` | `python3 -I ss_lattice_springs.py` | 0.2 s | rv·P_ss·18–20, 30 | `ALL ss_lattice_springs checks done` |
| `ss_point_groups.py` | `python3 -I ss_point_groups.py` | 0.3 s | rv·P_ss·21–24 | `ALL ss_point_groups checks done` |
| `ss_abs_tenfold.py` | `python3 -I ss_abs_tenfold.py` | 5.4 s | rv·P_ss·25–26 | `ALL ss_abs_tenfold checks done` |
| `ss_kitaev_lieb.py` | `python3 -I ss_kitaev_lieb.py` | 4.5 s | rv·P_ss·27–29 | `ALL ss_kitaev_lieb checks done` |
| `ss_hubbard_cube.py` | `python3 -I ss_hubbard_cube.py` | 2.5 s | rv·P_ss·31 | `ALL ss_hubbard_cube checks done` |

Notes on honesty of the checks:
- rv·P_ss·26 (complex ABS) is arithmetic on the complex type counts and dimensions, not a module construction.
- rv·P_ss·4's "only if" is exhaustive only for $n\le8$; for larger $n$ it rests on the Gauss-sum argument in §3 L5.
- rv·P_ss·8's winding number is computed from the bulk chiral block of each chain, with the sign convention $W=-\mathrm{wind}$ stated in the code.

Three checks failed on first run because my expectations were wrong. They were rewritten to state what the computation gives:
- rv·P_ss·10 expected 16 unique sign choices and got 128 (the perfect-code fact).
- rv·P_ss·13 counted Kronig–Penney states with double-counted edge roots, and only two complete bands lay below the first range of $E$.
- rv·P_ss·23 built a reducible module for odd $n$.

One check (rv·P_ss·14) first passed spuriously through an operator-precedence slip; after the fix it failed (wrong kernel vector), and it passes after the correction. The logs record the final runs.

**Provided scripts run** (logs in `out/P_ss_code/logs/`):

| script | command | runtime | result line |
|---|---|---|---|
| `core_check.py` | `python3 -I selfcheck/core_check.py` | 8.2 s | `25/25 core checks hold. ALL CORE CHECKS PASS` |
| `check_T11.py` | `cd researchers_checks; python3 -s check_T11.py` (with `-I` the local modules are not found) | 102 s | `ALL 74749 CHECKS PASSED` |
| `check_T14.py` | same | 1.1 s | `ALL 54 CHECKS PASSED` |
| `check_T15.py` | same | 1.9 s | `4648 of 4648 assertions hold` |
| `check_T16.py` | same | 0.8 s | `391 of 391` |
| `check_T18.py` | same | 0.6 s | `2023 of 2023` |
| `check_T19.py` | same | 1.6 s | `8881 of 8881` |
| `check_T20.py` | same | 1.2 s | `2015 of 2015` |
| `maxwell_selfcheck.py` | `python3 -I selfcheck/…` | 4.6 s | `ALL MAXWELL CHECKS PASS` |
| `spring_selfcheck.py` | same | 0.4 s | `60/60 claims hold` |
| `null_selfcheck.py` | same | 15.9 s | `64 of 64 computed checks pass` |
| `spin_selfcheck.py` | same | 1.4 s | `604/604 claims hold` |
| `mirrors_selfcheck.py` | same | 1.8 s | `ALL MIRRORS CHECKS PASS` |
| `steps15_17/groups_check.py` | `python3 -s` | 35.8 s | `ALL GROUP CHECKS PASS` |

No Atlas script was modified.

## 8. Sources

**Read** (the relevant part fetched and read, in some cases through quoted excerpts of the fetched page):
- L. Fidkowski, A. Kitaev, "The effects of interactions on the topological classification of free fermion systems", arXiv:0904.2197. Abstract and the sentence "with the introduction of interactions the ℤ is broken to ℤ₈".
- L. Fidkowski, A. Kitaev, "Topological phases of fermions in one dimension", arXiv:1008.4138. Abstract (BDI chain, $k$ modulo 8).
- A. Kitaev, "Periodic table for topological insulators and superconductors", arXiv:0901.2686. Abstract; eq. (17) (Cliff$^{p,q}$ with the first $p$ generators of square $-1$); the Clifford extension problem; Table 1 entries; "an increase in $d$ corresponds to a step up (mod 8)".
- S. Ryu, A. P. Schnyder, A. Furusaki, A. W. W. Ludwig, "Topological insulators and superconductors: ten-fold way and dimensional hierarchy", arXiv:0912.2157. Abstract and the sentence on 8-fold periodicity and spinors.
- A. Kapustin, R. Thorngren, A. Turzillo, Z. Wang, "Fermionic symmetry protected topological phases and cobordisms", arXiv:1406.7329. Abstract; Table 1 ($\Omega_2^{\mathrm{Pin}^-}=\mathbb Z_8$).
- R. Kirby, L. Taylor, "Pin structures on low-dimensional manifolds" (PDF hosted at webhomes.maths.ed.ac.uk). Lemma 3.6 (Gauss sum $A_q$; $\beta:\pi_2^{\mathrm{pin}^-}\to\mathbb Z/8$ an isomorphism); exercise on $\mathbb{RP}^2$, $\beta=\pm1$; Lemma 3.7.
- J. C. Baez, "The Tenfold Way", arXiv:2011.14234. The sentence on the eight real and two complex super division algebras as Morita classes of Clifford algebras. My fetch found no explicit Altland–Zirnbauer table there.
- B. Jancewicz, "Premetric electrodynamics", arXiv:0807.2989. The split 36 = 20 + 15 + 1 of the constitutive tensor.
- I. I. Smolyaninov, E. E. Narimanov, "Metric signature transitions in optical metamaterials", arXiv:1007.1130. Abstract ("(−−++) effective metric signature"); eq. (8); the remarks on 2T space-time without dispersion and on dispersion.
- C. L. Kane, T. C. Lubensky, "Topological boundary modes in isostatic lattices", arXiv:1308.0554. Abstract; eq. (1) ($\nu=N_0-N_{ss}=dN_s-N_b$); eq. (2) (chiral $\mathcal H$); SSH and class BDI remarks.
- H. Huang, "Induced subgraphs of hypercubes and a proof of the Sensitivity Conjecture", arXiv:1907.00847. Abstract; Lemma 2.2 ($A_n$ recursion, eigenvalues $\pm\sqrt n$).
- E. H. Lieb, "The flux phase of the half-filled band", arXiv:cond-mat/9410025. Abstract (π per square plaquette for planar bipartite graphs; extensions).
- G. Kirchmair et al., "State-independent experimental test of quantum contextuality", arXiv:0904.1655. Abstract and the nine observables of the Peres–Mermin square.
- C. E. Rüter et al., "Observation of parity–time symmetry in optics", Nature Physics 6, 192–195 (2010). Abstract (repository page).
- S.-Y. Xu et al., "Discovery of a Weyl fermion semimetal and topological Fermi arcs", arXiv:1502.03807. Abstract.
- "Quantized Faraday and Kerr rotation and axion electrodynamics of a 3D topological insulator", arXiv:1603.04317. Abstract; author list not checked.
- The Atlas pack: `spec_REVIEW_COMMON.md`, `READING_GUIDE.md`, `README.md`, `RELEASE_NOTES_v11.md`, `claims_en.md` (read in full for ATL, GEN, FUR, PAG, LAB, EQN, SHP, GOS, CPL, GRV, MAT, MIR, PRJ, YM, NUL, FRQ, SPN, SPR, RIG, MAP, RSN, INP; LNB, LNC, LNS by search), `needs_inputs.md`, `theorems_questions_sources.md`, `copy_en/conventionsCopy.txt` (statements, ideas, glossary), `README_label_bench.md`.

**Pointer, source unread** (not relied on):
- Atiyah–Bott–Shapiro (Clifford modules); Wall (Brauer–Wall group); Milgram / van der Blij (Gauss sums of lattices).
- Kitaev 2006 (anyons, 16-fold way).
- Nielsen–Ninomiya (doubling); Kogut–Susskind (staggered fermions).
- Dyson's threefold way; Calladine.
- Experiments on the tennis-racket effect, the $4\pi$ Josephson effect, Stern–Gerlach, hydrogen spectra and analogue horizons; the thermal Hall effect.
- Hehl–Obukhov on skewon and axion interpretation.

## 9. Limits

- **Odd $n$.** The odd-$n$ (unpaired-Majorana) part of the Fidkowski–Kitaev dictionary is not computed. rv·P_ss·2–5 cover even $n$. For odd $n$ the edge needs the far end or an ancilla (§3 L4).
- **Interacting junctions** (D1) and the 4-cube Hubbard question (D5) are not computed. The FK identification is checked at the level of one edge's operator algebra, not as a phase diagram.
- **Sources read through excerpts.** Most papers were read at abstract and statement level, through excerpts of the fetched pages; I did not read proofs. Where a quoted line came from a page summary, I used it only for the statement quoted. The FK interaction formula reported by my fetch of arXiv:0904.2197 ($W=\hat c_1\hat c_2\hat c_3\hat c_4+\dots$) looked garbled, and I did not use it.
- **Signature labels.** In rv·P_ss·15 the "$(2,2)$" and "$z$-time" labels depend on which axis carries $\varepsilon_\perp$. I fixed the convention in the code ($P_e=-\omega^2+k_\perp^2/\varepsilon_\parallel+k_z^2/\varepsilon_\perp$). Smolyaninov–Narimanov's $\varepsilon_1,\varepsilon_2$ map to it by the obvious relabelling.
- **Physical readings I could not settle.** Unsure: the skewon's interpretation, and the identification of Pin± with specific Majorana symmetry classes beyond Kapustin et al.'s $\Omega_2^{\mathrm{Pin}^-}$ line. I left both as pointers.
- **Not covered in depth** (outside my field, one line each above): Furey's Standard Model content, the Baez $E_6$/$E_7$ chapters, the category-theoretic results T3, T8, QB1–QB5, the Pumplün dictionary, the gravity steps 9–13, and Forque details. I did not open the translation matrix JSON.
- **Atlas tests.** No browser, no `build.sh`, no `run_tests.sh`. The Atlas's JS engines and UI tests are untouched.
