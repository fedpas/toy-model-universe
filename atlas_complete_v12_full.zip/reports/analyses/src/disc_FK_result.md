# Discovery run FK: is the clock a junction observable?

Script: `disc_FK.py` (numpy and scipy.sparse; one core). Logs: `disc_FK.log` (normal run) and `disc_FK_sabotage.log` (`--sabotage`).

## (a) The question

Two stacks of time-reversal-invariant (class BDI) Kitaev chains are joined end to end. The left stack has winding $W$ and the right stack has winding $W'$, and both stacks share one antiunitary time reversal $T$. At the interface the free zero modes are $p$ $T$-even and $q$ $T$-odd Majoranas. This is the Atlas cell $Cl(p,q)$, with clock $(p-q) \bmod 8$.

The question has two parts:
- Allow every time-reversal-invariant, fermion-parity-conserving interaction at the junction. Is the ground-state degeneracy of the junction then a function of $(W-W') \bmod 8$ alone?
- Does a unique gapped ground state exist exactly when $(W-W') \equiv 0 \bmod 8$?

Together these ask whether the clock is a junction observable, and not only a label of one edge.

## (b) The result

**Yes, within the model below.** The junction's ground-state degeneracy is a function of $(W-W') \bmod 8$ alone. The interface cell's clock is $(W'-W) \bmod 8$, the same information up to sign.

| $(W-W') \bmod 8$ | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| degeneracy | 1 | 2 | 2 | 4 | 2 | 4 | 2 | 2 |

For odd residues the count includes one decoupled spectator end mode. Free fermions instead keep the integer $|W-W'|$: their degeneracy is $2^{|W-W'|/2}$.

**The model.**
- The left stack has $|W|$ chains of 2 sites at the sweet spot, so it has a bulk. The right stack has $|W'|$ chains of 1 site.
- The outer zero modes of both stacks are exactly decoupled, standing for infinitely long stacks. They are removed from the Hilbert space, except one kept as a spectator when the number of remaining Majoranas is odd.
- The junction region is the interface modes plus the bulk Majorana next to each one.
- The Hamiltonian is the sweet-spot bulk bonds plus every $T$-invariant Hermitian parity-even monomial of weight 2 and 4 in the junction region. The weights are Gaussian with fixed seeds, normalised below the bulk gap.

**What was computed.**
- Sparse exact diagonalisation on the Jordan–Wigner Fock space, of dimension up to $2^{14}$ (28 kept Majoranas). The ground multiplicity is counted per fermion-parity sector by Lanczos with deflation, as the number of states with $|E-E_0|<10^{-8}$.
- 18 junctions: $W=8$ against $W'=0,1,2,3,4,-1,-2,-3$, which covers every residue, and ten smaller pairs.
- Every residue is realised in several ways, with different $|W-W'|$ for the same residue. For example $(8,0)$, $(4,4)$ and $(4,-4)$ all have residue 0 but $|W-W'| = 8, 0, 8$.
- Residue 0 has positive evidence. The four independent Fano-line blades of core·B11, the $[8,4,4]$ Hamming code, gap $(8,0)$ and $(4,-4)$ to a unique, $T$-invariant, parity-definite ground state with gap 2. That state stays unique after a random $T$-invariant perturbation.
- For a nonzero even residue no Hamiltonian of the class is non-degenerate. On the junction space $T^2=-1$ (residues 4 and 6), or $T$ anticommutes with fermion parity (residues 2 and 6).

**The extra data the statement needs.**
- One common time reversal for both stacks. With independent conventions ($T$ on one side, $TP$ on the other) the residue would read $(W+W') \bmod 8$.
- Outer ends far away.
- Interactions that conserve $T$ and fermion parity.

| $(W,W')$ | $(W-W') \bmod 8$ | interface cell | clock $(W'-W) \bmod 8$ | free degeneracy | interacting degeneracy | gap above the ground multiplet |
|---|---|---|---|---|---|---|
| (8,0) | 0 | Cl(0,8) | 0 | 16 | 1 | 0.030 |
| (8,−1) | 1 | Cl(0,9) | 7 | (32) | 2 | 0.070 |
| (8,−2) | 2 | Cl(0,10) | 6 | (32) | 2 | 0.033 |
| (8,−3) | 3 | Cl(0,11) | 5 | (64) | 4 | 0.075 |
| (8,4) | 4 | Cl(4,8) | 4 | (4) | 2 | 0.008 |
| (8,3) | 5 | Cl(3,8) | 3 | (8) | 4 | 0.026 |
| (8,2) | 6 | Cl(2,8) | 2 | (8) | 2 | 0.020 |
| (8,1) | 7 | Cl(1,8) | 1 | (16) | 2 | 0.040 |
| (4,4) | 0 | Cl(4,4) | 0 | 1 | 1 | 0.012 |
| (4,−4) | 0 | Cl(0,8) | 0 | 16 | 1 | 0.030 |
| (2,−2) | 4 | Cl(0,4) | 4 | (4) | 2 | 0.109 |
| (4,0) | 4 | Cl(0,4) | 4 | 4 | 2 | 0.028 |
| (1,−1) | 2 | Cl(0,2) | 6 | 2 | 2 | 2.098 |
| (3,−3) | 6 | Cl(0,6) | 2 | (8) | 2 | 0.123 |
| (3,0) | 3 | Cl(0,3) | 5 | 4 | 4 | 1.774 |
| (2,−3) | 5 | Cl(0,5) | 3 | (8) | 4 | 0.263 |
| (1,0) | 1 | Cl(0,1) | 7 | (2) | 2 | 2.098 |
| (4,−3) | 7 | Cl(0,7) | 1 | (16) | 2 | 0.080 |

Notes on the table:
- The interacting degeneracy and the gap are from `disc_FK.log`, seed 101.
- Free degeneracies without parentheses are computed in disc·FK2 (quadratic couplings only). Those in parentheses are the formula $2^{\lceil |W-W'|/2\rceil}$ that disc·FK2 checks on the other cases. They were not recomputed for these junctions.
- A second seed (202) gives the same interacting degeneracy for every junction with $|W|+|W'|\le8$.

## (c) The checks: statements the Atlas can carry

**disc·FK1** — checked.
- *Statement.* In a junction of two BDI stacks with windings W and W′ sharing one time reversal, the free zero modes at the interface are p T-even and q T-odd Majoranas with p − q = W′ − W. The interface carries the cell Cl(p, q), clock (W′ − W) mod 8. Computed as the kernel of the free Majorana (BdG) matrix of every junction in the table.
- *Adds to:* the reading of the mirror as the two ends of one chain (CONV row 6, core·B4). It places the cell address [p + q, p − q] of CONV row 0 at an interface.

**disc·FK2** — checked.
- *Statement.* Without quartic terms, i.e. with every T-invariant quadratic junction coupling allowed, the junction ground state is $2^{d/2}$-fold degenerate, d = |W − W′|. For odd d the count includes one more mode, the spectator. Free fermions see the integer |W − W′|. Examples: 16-fold for (8, 0) and (4, −4), non-degenerate for (4, 4).
- *Adds:* a control where the answer is known to be degenerate. It shows that the reduction to a residue mod 8 comes from the interactions.

**disc·FK3** — checked.
- *Statement.* Allow every T-invariant, parity-conserving term of weight 2 and 4 among the junction Majoranas (random weights below the bulk gap). The ground-state degeneracy of the junction is then 1, 2, 2, 4, 2, 4, 2, 2 for (W − W′) ≡ 0, 1, …, 7 mod 8, odd residues counted with one decoupled end mode. It is the same for every tested realisation of a residue: W = 8 against W′ = 0, 1, 2, 3, 4, −1, −2, −3, and (4, 4), (4, −4), (2, −2), (4, 0), (1, −1), (3, −3), (3, 0), (2, −3), (1, 0), (4, −3).
- *Adds:* the clock as a junction observable, not only an edge label (LAB-017, LAB-018, CONV gloss 8). The interacting class is the residue of the cell address p − q mod 8; the free class is p − q itself.

**disc·FK4** — checked.
- *Statement.* For residue 0 the unique gapped ground state exists and is built explicitly. On (8, 0) and (4, −4) the 8 interface Majoranas have one T-parity. Taking the four independent Fano-line blades of core·B11 (the [8,4,4] Hamming code) as commuting stabilizers gives a unique T-invariant ground state of definite fermion parity, with gap 2. After a random T-invariant perturbation it is still unique, with gap about 1.9. (4, 4) is gapped by quadratic pairing alone.
- *Adds to:* T14 (4) and core·B11. A Lagrangian of the label form through the top label is the interaction that gaps a residue-0 junction with no free pairing available.

**disc·FK5** — checked (the relations); the implication is ours.
- *Statement.* On the junction Fock space the common time reversal satisfies (T², TP = ±PT) = (+1, +), (+1, −), (−1, +), (−1, −) for (W′ − W) ≡ 0, 2, 4, 6 mod 8. For an even nonzero residue, every T-invariant parity-conserving junction Hamiltonian is therefore at least 2-fold degenerate: Kramers pairs for 4 and 6, one state of each parity for 2 and 6. For odd residues the spectator end mode and the product of the junction Majoranas anticommute, and both commute with every such Hamiltonian: at least 2-fold.
- *Status detail.* The relations are computed for the listed junctions. The implication is a one-line argument (ours): an antiunitary T with T² = −1 commuting with H forces Kramers pairs; a T that anticommutes with P maps each parity sector onto the other.
- *Adds:* the lower bound that makes FK3's degeneracy a property of the residue, not of the random draw. With FK4, the minimum degeneracy over the class is 1 exactly at residue 0.

## (d) What the result does not show

- **Idealised outer ends.** The outer zero modes are taken exactly decoupled; this stands for long stacks. Their finite-length hybridisation with the interface is not computed. Away from the junction the bulk sits at the sweet spot.
- **Sizes.**
  - The left stack has 2 sites per chain; the right stack has 1 site per chain, so it has no bulk of its own.
  - The kept Hilbert space reaches dimension $2^{14}$ (28 Majoranas). The full system with the decoupled outer modes would be larger only by known factors of 2.
- **Interaction class.**
  - Terms of weight 2 and 4, only in the junction region (interface modes and one adjacent bulk Majorana per left chain).
  - Random Gaussian weights normalised below the bulk gap: one seed for the W = 8 junctions, two seeds for the smaller ones.
  - No strong-coupling regime, no phase diagram, no interaction in the far bulk.
- **Common time reversal.** The statement needs one time reversal shared by both stacks. With independent conventions the residue reads (W + W′) mod 8.
- **Odd residues.** They are counted with one spectator end mode. A single odd edge has no Fock space of its own, so the "√2" degeneracy of an isolated odd edge is not defined here.
- **The lower bound of 4 for residues 3 and 5.** It is observed for every tested junction but not proved. The proved bound for odd residues is 2.
- **No physical system claimed.** Junction spectroscopy (zero-bias features set by (W − W′) mod 8) is a reading (ours). The interacting Z → Z₈ of BDI chains is in Fidkowski and Kitaev, arXiv:0904.2197 (abstract read). Their invariants and edge-degeneracy table are a pointer, source unread.
- **Free fermions** (disc·FK2) are tested on eight junctions only, as listed.

## (e) Run time and logs

- Normal run: `python3 disc_FK.py > disc_FK.log`, 37.5 s on one core; output `ALL PASS`.
- Sabotage: `python3 disc_FK.py --sabotage > disc_FK_sabotage.log`, 24 s; output `ALL CAUGHT`. Each line shows what the broken input computed:
  - FK1: the right stack's T-parity is mislabelled, so the interface cells change.
  - FK2: the Hamming terms added to the free (8,0) junction give degeneracy 1 instead of 16.
  - FK3: T-odd bilinears give degeneracies {0: 1, 1: 2, 2: 1, 3: 2, 4: 1, 5: 2, 6: 1, 7: 2}. The machinery sees non-matching answers.
  - FK4: three Hamming generators leave a 2-fold ground state.
  - FK5: mislabelled T-parities give the wrong (T², TP) pairs.
