# Discovery FUR: the commutant of the gauge algebra in Furey's 16-dimensional model, and the order-3 question

Script: `disc_FUR.py` (standard library, exact rational arithmetic). Logs: `disc_FUR.log` (checks), `disc_FUR_sabotage.log` (sabotage run).

## (a) The question

Idea H9 of the Atlas ("three generations from an order-3 symmetry") and question QT8 ask whether Furey's model carries an order-3 symmetry that commutes with the Standard Model gauge algebra and permutes the cells of her Fig. 1.

The model is the one of the Atlas's Furey report (`reports/furey/model.py`, `run_all.py`), rebuilt here with exact integers:
- $V=\mathbb O\oplus\mathbb O'$, 16 real dimensions;
- the complex structure $\omega=L_{e_7}$ on both copies;
- six real Peirce blocks $\mathbb O_1$ (2), $\mathbb O_2$ (6), $\mathbb H$ (4), $\mathbb C$ (2), $e_7\mathbb R$ (1), $\mathbb R$ (1);
- five complex blocks $C_O$, $C3_O$, $C2_H$, $C_C$, $C_{\rm last}$ of complex sizes 1, 3, 2, 1, 1.

The gauge algebra is the 12-dimensional $su(3)\oplus su(2)\oplus u(1)_Y$:
- $su(3)$: the derivations of $\mathbb O$ that kill $e_7$, acting on the first copy;
- $su(2)$: the maps of the $\mathbb H$ block that are antisymmetric, commute with $\omega$ and have complex trace 0;
- $u(1)_Y$: $\omega Y$ with $Y=P_{\mathbb O_2}/3+P_{\mathbb H}/2+P_{\mathbb C}$.

What is its commutant in $M_{16}(\mathbb R)$? Which elements of order 3 in it normalise the Peirce blocks, and how do they act on the 20 cells? The two possible outcomes:
- (i) block phases only: H9 is refuted inside the model;
- (ii) a cell-permuting element: then test it against $G_2$, the label group $2^3\cdot GL(3,2)$ and triality.

## (b) The result

**Outcome (i) for order 3; there is also one order-2 cell permutation, which is not an octonion symmetry.**

The commutant of the 12-dimensional gauge algebra in $M_{16}(\mathbb R)$ (256 unknowns, exact) has dimension 22:
$$M_4(\mathbb R)\oplus\mathbb C\oplus\mathbb C\oplus\mathbb C.$$
- $M_4(\mathbb R)$ acts on the four real dimensions of the two hypercharge-0 singlet blocks $C_O\oplus C_{\rm last}$; each $\mathbb C$ acts on one of $C3_O$, $C2_H$, $C_C$.
- Its centre has dimension 7. It is not a division algebra: the block projector $P_{C_O}$ lies in it.
- The only piece between different blocks is $C_O\to C_{\rm last}$ (4 real dimensions).
- The complex-linear commutant (adding $\omega$) has dimension 14, $M_2(\mathbb C)\oplus\mathbb C^3$, with centre of dimension 8.

Order-3 elements fix every cell:
- An element of the commutant that normalises the Peirce blocks can only exchange blocks of equal size carrying isomorphic gauge representations.
- These classes are $\{C_O,C_{\rm last}\},\{C3_O\},\{C2_H\},\{C_C\}$ (complex blocks) and $\{e_7\mathbb R,\mathbb R\}$ plus singletons (real blocks). No class has more than two blocks.
- So an element of order 3 fixes every block, and therefore every cell. If it is complex-linear it acts on each block by a cube root of unity: block phases only.
- H9, as an order-3 symmetry commuting with the gauge algebra, has no solution inside the model.

The order-2 swap $S$ exchanges the two hypercharge-0 singlet blocks ($1,e_7$ of the first copy with $1',e_7'$ of the second):
- $S$ commutes with the gauge algebra and with $\omega$, and permutes the cells of Fig. 1 (labels as printed in the paper).
- It exchanges the first-generation cells $d_R$, $(\nu_e,e)_L$, $e_R$ with $b_R$, $(\nu_\tau,\tau)_L$, $\tau_R$.
- It fixes $Q_L$, $u_R$, $\nu_{eR}$ and $h$, which are exactly the cells whose irreps lack a third copy (Furey report S11), together with $h$.
- $S$ sends $1$ to $1'$, so it is not an automorphism of $\mathbb O$ acting on the two copies: it is in neither $G_2$ nor the label group.
- It comes from the two-copy structure $V=\mathbb O\oplus\mathbb O'$, not from triality (the model has two copies of $\mathbb O$, not the three spaces of a triality).

Colour and the label group:
- In the model's basis the label automorphisms of $\mathbb O$ number 1344 ($2^3\cdot GL(3,2)$), and 32 of them have order 3 and fix $e_7$.
- Only the identity commutes with colour $su(3)$, which confirms `rv·M_alg·17` (cited as bd·alg·17) in the model's own basis.

## (c) The checks, the statements the Atlas can carry

| id | Statement (Atlas form, plain text) | Status | Replaces / adds |
|---|---|---|---|
| bd·fur·1 | In the 16-dimensional model V = 𝕆 ⊕ 𝕆′ the gauge algebra su(3) ⊕ su(2) ⊕ u(1)_Y is realised explicitly: the 8 derivations of 𝕆 that kill e₇ (first copy), the 3 antisymmetric maps of the ℍ block that commute with ω and have complex trace 0, and ωY. It has dimension 12, closes, commutes with ω and with the six real Peirce projectors. Its representation on the five complex blocks is: trivial on C_O and C_last, irreducible of complex type on C3_O, C2_H and C_C. | checked | adds the explicit gauge algebra to FUR-001 (which gives Δ_SM of dimension 31 and the blocks) |
| bd·fur·2 | The commutant of this 12-dimensional gauge algebra in M₁₆(ℝ) has dimension 22: M₄(ℝ) on the two hypercharge-0 singlet blocks together, and ℂ on each of the 3-block, the doublet block and the charge-1 singlet block. Its centre has dimension 7 and it is not a division algebra. The only map between different blocks goes from C_O to C_last. Requiring ω-linearity leaves M₂(ℂ) ⊕ ℂ³ (dimension 14, centre 8). | checked | refines the Atlas line "the maps of V that commute with the gauge algebra Δ_SM form a 12-dimensional algebra with nothing between blocks" (Furey page, family_test.py). That line is about the 31-dimensional associative Δ_SM, which contains the block projectors. For the 12-dimensional Lie algebra the commutant is larger and has one piece between blocks |
| bd·fur·3 | An element of the commutant that normalises the Peirce blocks can only exchange blocks of equal size carrying isomorphic gauge representations. The classes are {C_O, C_last}, {C3_O}, {C2_H}, {C_C} (real blocks: {e₇ℝ, ℝ} and singletons), never more than two. So every element of order 3 fixes every block and every one of the 20 cells, and if ω-linear acts on each block by a cube root of unity (block phases). Inside the model no order-3 symmetry commuting with the gauge algebra permutes cells: H9 is refuted there. | checked | answers H9 ("would prove it: an order-3 automorphism … acting compatibly on Furey's data") inside her model; QT8 |
| bd·fur·4 | The exchange S of the two hypercharge-0 singlet blocks (span{1, e₇} of the first copy with span{1′, e₇′} of the second) commutes with the gauge algebra and with ω. It is an involution of the cells of Fig. 1: b_R ↔ d_R, (ν_e,e)_L ↔ (ν_τ,τ)_L, e_R ↔ τ_R, fixing Q_L, u_R, ν_eR and h, so the cells it fixes are exactly those whose irreps lack a third copy, together with h. S maps 1 to 1′, so it is not an automorphism of 𝕆 on the two copies (not in G₂, not in the label group 2³·GL(3,2)). | checked (the labels of the cells are the paper's, as listed in the Atlas's Furey report; the check maps cells to cells and compares hypercharges and blocks) | adds; relates to FUR-004 and S14 (the ℤ₂ question): the cell-permuting symmetry the model does have is this order-2 swap of the two copies' singlet blocks |
| bd·fur·5 | In the basis of the model the automorphisms of 𝕆 permuting the basis lines number 1344 (2³·GL(3,2)); 32 of them have order 3 and fix e₇; none except the identity commutes with the colour su(3) (the 8 derivations killing e₇). | checked | confirms rv·M_alg·17 in the model's own basis; H9 |

**Reading (ours).** The ω-linear commutant contains $M_2(\mathbb C)$ on the two hypercharge-0 singlet lines (bd·fur·2). Its unitary group $U(2)$ commutes with the gauge algebra and mixes the two lines, so the three pairs $(d_R,b_R)$, $((\nu_e,e)_L,(\nu_\tau,\tau)_L)$, $(e_R,\tau_R)$ are doublets of this $U(2)$. In the model the family symmetry compatible with the gauge algebra is therefore a $U(2)$ acting on two copies, not a $\mathbb Z_3$ or $SU(3)$ on three. This matches the count "two complete sets with every cell doubled" (Furey report S11). It is a reading, not a statement about nature.

## (d) What the result does not show

- It concerns only this explicit model and the 12-dimensional gauge algebra built from it. The $su(2)$ is fixed by the conditions above (antisymmetric, ω-linear, complex-traceless on the $\mathbb H$ block). Another choice conjugate to it gives an isomorphic commutant, but this is not computed.
- The commutant is computed inside $\mathrm{End}_{\mathbb R}(V)=M_{16}(\mathbb R)$ only. Antilinear symmetries count as elements of $M_{16}(\mathbb R)$ that need not commute with ω, and they are included in the 22-dimensional commutant. Symmetries of larger spaces (the 32-dimensional $\mathbb C\otimes\mathbb H\otimes\mathbb O$ of the Roadmap, the triple $(\Psi^+,\Psi^-,V)$ of Trialities, $e_7$ or $e_8$) are not touched.
- Elements of order 3 that do not normalise the Peirce blocks exist (for example in the $U(2)$ above, mixing $C_O$ and $C_{\rm last}$). They mix cells rather than permute them; they are not examined further.
- The labels of the 20 cells are the paper's (input I4 of the Furey report). The script checks only that the swap maps cells with equal gauge numbers to each other.
- Nothing is claimed about nature or about the generations of the Standard Model.

## (e) Run time and logs

`python3 disc_FUR.py` runs in about 0.3 s, prints five `PASS` lines and `ALL PASS` (log: `disc_FUR.log`). `python3 disc_FUR.py --sabotage` prints `CAUGHT` for all five checks and `ALL SABOTAGES CAUGHT` (log: `disc_FUR_sabotage.log`). The sabotages, each printed with what the check sees:
- bd·fur·1: one colour generator replaced by a $g_2$ derivation that moves $e_7$; the algebra no longer closes or commutes with ω.
- bd·fur·2: $u(1)_Y$ dropped; the commutant dimension changes from 22 to 42.
- bd·fur·3: $u(1)_Y$ dropped; a class of three isomorphic blocks $\{C_O,C_C,C_{\rm last}\}$ appears, so an order-3 cell permutation would exist. This shows the search sees a non-trivial answer when one is there.
- bd·fur·4: $C_O$ swapped with $C_C$ instead (hypercharge 0 against 1); not in the commutant.
- bd·fur·5: only one colour generator kept; 31 non-trivial label automorphisms commute with it.
