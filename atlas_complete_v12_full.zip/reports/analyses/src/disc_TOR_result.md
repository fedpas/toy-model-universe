# Discovery TOR: inputs as torsors

## (a) The question

Some `input` lines of the Atlas (`inputsData.js`, the "needs and inputs" strips) choose a structure inside the algebra rather than an equation or a number. They choose a time direction γ₀, a complex structure J, a Witt split (the Fock vacuum), a Lagrangian of a clock-0 cell, Furey's partition of the 16 axes into blocks, an orthonormal frame, or an involution. For each, the question is how many orbits a group supplied by the algebra has on the space of choices. One orbit makes the choice a gauge: it carries no information. Several orbits make it a datum with that many values.

## (b) The result

The answer is partly: some of these inputs are gauges, some are data, and the computation says which. Everything is exact and runs on small sizes (ranges in (c)).

**Gauges (one orbit):**
- The graded Lagrangian of a clock-0 cell. This covers Furey's torus.
- The complex structure J, for n ≥ 4.
- Furey's ω.
- The frame, under the Pin group.
- The Witt split, under the Pin group.

**Data:**
- **The time direction** carries exactly a time orientation: one orbit of the even Clifford group, two orbits of the rotors.
- **J at n = 3** carries the orientation of the spatial plane.
- **The Witt split under Spin** carries 2 values: the family of the Lagrangian, i.e. the parity of the Fock vacuum.
- **The frame under the rotors** carries its orientation and time orientation: 4 values if p, q ≥ 1, 2 for a definite cell.
- **Furey's block partition of the 16 axes is a datum.** The block projectors force the torus: the 616 diagonalising quadruples are the 616 bases of one Lagrangian, her Hamming code H_F, and 18480 = 30 × 616. The torus is gauge, but the partition is not. The 6720 ω-compatible partitions with her block sizes fall into 11 orbits of the full graded group fixing ω and the torus. Her partition is the one whose O-blocks are even and whose other blocks are odd.
- **The involution:**
  - Reversion and Clifford conjugation give isomorphic structures iff n ≡ 0 mod 4 and the cell is indefinite. So for Cl(1,3), the cell of the Dirac, coupling and matter steps, the choice is a gauge (e_i ↦ e_i I).
  - The dagger equals the reversion iff q = 0 and the conjugation iff p = 0. Otherwise the choice of involution is a datum.

### The groups

The groups are the ones the algebra supplies, acting as follows:

- **On vectors and spinors:**
  - rotors (R even, RR̃ = 1);
  - the even Clifford group (even versors);
  - the Pin group (odd versors included);
  - each by R x R⁻¹.
- **On labels:**
  - Conjugation by the even 90-degree rotors exp(π e_v/4) with e_v² = −1 induces the transvection x ↦ x + (x·v)v. These generate the graded label group G_w.
  - Conjugation by (1 + e_v)/√2 for any blade of square −1 gives the ungraded group G_Q.
- **On Furey's axes:**
  - The full group is every graded automorphism of Cl(0,8) ≅ End(ℝ^{8|8}) that fixes ω and maps the torus to itself, i.e. conjugation by homogeneous invertibles. On the 16 axes it acts by permuting the 8 ω-pairs within each parity class, swapping the two classes, and applying ω inside a pair.
  - The label-preserving subgroup acts on the axes by affine maps: all translations, with linear parts from the stabiliser of H_F and ω in G_w.

## (c) The table and the checks

Each row lists: input (strip: text) | structure | acting group | orbits | gauge or datum | sentence the Atlas can carry (≤ 25 words, tag).

1. **Time direction.** Inputs:
   - maxwell/charges "The observer's time direction γ₀ splits F into E and B…"
   - mirrors "The time direction (e_t, called γ₀ …)"
   - dirac "γ₀, the observer's time direction, enters the mass term…"
   - coupling, matter, spin "γ₀ of the Dirac step…"
   - gauge "the static time direction e_t"

   | | |
   |---|---|
   | Structure | a unit vector u with u² = +1 in Cl(1,n−1) |
   | Group | rotors / even Clifford group |
   | Orbits | 2 / 1 |
   | Verdict | datum with 2 values (the time orientation); the rest of γ₀ is gauge |
   | Sentence | "Only a time orientation is chosen: unit time vectors are one orbit of the even versors and two of the rotors (bd·tor·1, n ≤ 6)." |
   | Tag | checked, n = 2..6 |

2. **Complex structure J (bivector kind).** Inputs:
   - dirac "J = γ₂γ₁ plays the part of the Dirac i…"
   - coupling "J = γ₂γ₁ … chosen in the algebra"
   - matter "J = γ₂γ₁ of the Dirac step, acting from the right…"
   - spin (grade) "the chirality map ψ ↦ IψJ uses the chosen J"

   | | |
   |---|---|
   | Structure | a unit spatial bivector |
   | Group | right spatial rotors Spin(n−1) |
   | Orbits | n = 3: 2; n = 4, 5, 6: 1 |
   | Verdict | gauge for n ≥ 4; datum with 2 values (plane orientation) at n = 3 |
   | Sentence | "For n ≥ 4 any unit spatial bivector serves as J, one rotor orbit; at n = 3 J and −J differ (bd·tor·2)." |
   | Tag | checked on the coordinate bivectors ±γᵢγⱼ, n = 3..6. That every unit simple spatial bivector is a rotor image of a coordinate one is standard (pointer, source unread). |

3. **The kind of i.** Input: spin "Which kind of i plays the complex unit (the central I, a bivector J, or the lecture's B + i)".

   | | |
   |---|---|
   | Structure | central element vs bivector |
   | Group | any automorphism |
   | Orbits | at least 2 (centrality is invariant) |
   | Verdict | datum (the kind); within the bivector kind see row 2 |
   | Sentence | "Central I and a bivector J are different kinds of i, never related by an automorphism; the bivector choice itself is gauge for n ≥ 4." |
   | Tag | ours (centrality is preserved by automorphisms); row 2 checked |

4. **Witt split.** Input: orth "The Fock reading splits the 2n null vectors into n pairs and picks a vacuum: a choice of Witt split…"

   | | |
   |---|---|
   | Structure | a Lagrangian of ℝ^{k,k} (coordinate splits: k!·2^k) |
   | Group | Pin (signed permutations) / even Clifford group / rotors |
   | Orbits | 1 / 2 / 2 |
   | Verdict | gauge under Pin; datum with 2 values (the family, sign(σ)∏sᵢ) under Spin |
   | Sentence | "The Fock vacuum is gauge under Pin(k,k); under Spin it keeps one bit, the family of the Lagrangian (bd·tor·3, k ≤ 4)." |
   | Tag | checked for the coordinate splits, k ≤ 4. The extension to all real Lagrangians (two components, swapped by det A det D = −1) is standard (pointer, source unread). |

5. **Lagrangian of a clock-0 cell (graded).** Inputs: findings "The partition of the 16 axes …" (its torus part); core·B11 (Furey's axes).

   | | |
   |---|---|
   | Structure | L ⊂ V with \|L\|² = 2ⁿ and w = 0 on L |
   | Group | G_w (graded label automorphisms) |
   | Orbits | 1, for Cl(1,1), Cl(2,2), Cl(3,3), Cl(4,4), Cl(8,0), Cl(0,8) (1, 2, 6, 30, 30, 30 Lagrangians) |
   | Verdict | gauge |
   | Sentence | "In a clock-0 cell the graded Lagrangians (graded spinor modules) form one orbit of the algebra's label automorphisms: Furey's axes are gauge (bd·tor·4)." |
   | Tag | checked, n ≤ 8 |

   The ungraded Lagrangians are one orbit of G_Q, and two orbits of G_w: inside the even labels or not.

6. **Furey's quadruple choice.** Input: findings "…616 of 18 480 candidate quadruple sets diagonalise the block projectors…"

   | | |
   |---|---|
   | Structure | a basis of weight-4 words of the torus H_F |
   | Group | Stab(H_F) / Stab(H_F) ∩ Stab(ω) in G_w |
   | Orbits | 3 / 10 (presentations, not structure) |
   | Verdict | not a structure: the 616 are the bases of one torus |
   | Sentence | "The 616 diagonalising quadruples are the 616 bases of one Lagrangian, H_F (18480 = 30 × 616): the blocks force the torus (bd·tor·5)." |
   | Tag | checked, exact |

7. **Furey's ω.** Inputs:
   - dictionary "The complex structure ω = L_{e₇} is imported."
   - findings "ω = L_{e₇} of the Dictionary tab is hers"

   | | |
   |---|---|
   | Structure | ω = the grade-6 blade e₀₁₃₄₅₆ of Cl(0,8) |
   | Group | G_w; Stab(H_F) |
   | Orbits | 1 on the 56 even blades of square −1, also under Stab(H_F) |
   | Verdict | gauge (among blade complex structures) |
   | Sentence | "ω is one of 56 even blades of square −1, all one orbit of the label automorphisms, even with the torus fixed (bd·tor·5)." |
   | Tag | checked, label level. The signs ±ω are not seen at label level. |

8. **Furey's block partition.** Input: findings "The partition of the 16 axes into blocks is input…"

   | | |
   |---|---|
   | Structure | a partition of the 16 axes into blocks of sizes 2, 6, 4, 2, 1, 1 (ω-compatible: 6720) |
   | Group | the full graded group fixing ω and the torus / the label-preserving group |
   | Orbits | 11 / 22 |
   | Verdict | datum (11 values) |
   | Sentence | "Given her torus and ω, the block partition is a datum: 11 orbits of ω-compatible partitions; hers has even O-blocks (bd·tor·5)." |
   | Tag | checked |

   Cross-check: the 11 are the 22 parity profiles of the five blocks modulo the parity swap.

9. **Orthonormal frame.** Inputs:
   - maxwell/views "…in the orthonormal frame that the labels already give."
   - grav1 "grade 1 is identified with tangent vectors by a choice of frame"
   - gauge "A frame: the shear h̄ and the static time direction e_t are chosen"

   | | |
   |---|---|
   | Structure | an ordered orthonormal frame (coordinate frames: 2ⁿ p! q!) |
   | Group | Pin (signed permutations) / even Clifford group / rotors |
   | Orbits | 1, free / 2 / 4 for p, q ≥ 1, 2 if definite |
   | Verdict | gauge (a torsor) up to orientation and time orientation |
   | Sentence | "A frame is a torsor of Pin(p,q); under rotors it keeps orientation and time orientation, four values for indefinite cells (bd·tor·6, n ≤ 5)." |
   | Tag | checked on the coordinate frames, n ≤ 5. O(p,q) acting simply transitively on all frames is standard (pointer, source unread). |

10. **Involution: reversion vs Clifford conjugation.** Inputs:
    - mirrors "…using it rather than Clifford conjugation is a choice"
    - dirac "…rather than Clifford conjugation or a dagger, is a choice"
    - coupling, matter (current X = ψγ₀ψ̃)

    | | |
    |---|---|
    | Structure | the anti-involution of the cell |
    | Group | graded automorphisms (block maps) |
    | Orbits | rev ≅ conj iff n ≡ 0 mod 4 and indefinite |
    | Verdict | gauge for Cl(1,3) and Cl(3,1) (e_i ↦ e_i I); datum otherwise |
    | Sentence | "In Cl(1,3) reversion and Clifford conjugation are related by eᵢ ↦ eᵢI, a gauge; generally only for n ≡ 0 mod 4, indefinite (bd·tor·7)." |
    | Tag | checked, n ≤ 8 |

11. **Involution: reversion vs dagger.** Inputs:
    - spin "…that the scalar part is a state holds for the dagger involution (T15)…"
    - category "States use the dagger involution…"
    - spring "The rotor sandwich R s R̃ uses the reversion…"

    | | |
    |---|---|
    | Structure | same |
    | Group | same |
    | Orbits | rev = dag iff q = 0; conj = dag iff p = 0 |
    | Verdict | datum when q ≥ 1 (the dagger is positive, the reversion is not) |
    | Sentence | "The dagger coincides with the reversion only for q = 0; in Cl(1,3) choosing the dagger instead is a datum, not a gauge (bd·tor·7)." |
    | Tag | checked, n ≤ 8 |

12. **Sign convention (which square is time).** Inputs:
    - maxwell/views, clock, dirac, grav1, gauge, schuller, projective, forque "…Cl(3,1) reads the same system with the signs swapped" and similar

    | | |
    |---|---|
    | Structure | not a structure on one algebra: Cl(p,q) against Cl(q,p) |
    | Group | none (the mirror is the super-opposite, not an automorphism) |
    | Orbits | — |
    | Verdict | a naming convention; the two cells differ unless p − q ≡ 0, 4 mod 8 |
    | Sentence | "Which square is time is a convention between two mirror cells, not a gauge orbit: Cl(1,3) and Cl(3,1) have clocks 6 and 2." |
    | Tag | checked by core·B6c (not by this script) |

Not covered, as they are not choices of a structure inside the algebra: the postulated equations, the imported data and borrowed solutions, the grades of fields, the flat charts and ∇, the representation of the gauge algebra, and the PGA lines (forque, rigid) with a null generator (r = 1).

**Check ids.** Each is checked for the stated range:
- **bd·tor·1:** time direction, Cl(1,n−1), n = 2..6.
- **bd·tor·2:** complex structure J, coordinate bivectors, n = 3..6.
- **bd·tor·3:** Witt split, coordinate splits of Cl(k,k), k ≤ 4.
- **bd·tor·4:** Lagrangians of the clock-0 cells, n ≤ 8, graded and ungraded.
- **bd·tor·5:** Furey: the quadruples, ω, the torus, the partition.
- **bd·tor·6:** frames, every cell with n ≤ 5.
- **bd·tor·7:** involutions, every cell with n ≤ 8.

**What it replaces or adds.**
- It adds a column "gauge / datum (k)" to the input strips, where k is the number of values.
- It corrects the reading of the findings line "616 of 18 480": the blocks determine the torus, and what the torus leaves open is the partition, a datum with 11 values.
- It supports M_geo B4: the time line chooses a time orientation.
- It makes the reversion-versus-conjugation input lines exact for Cl(1,3).
- It is consistent with bd·xck·8 (one S₈-orbit of 30 for Cl(0,8)).

## (d) What the result does not show

- **Range.** Only the stated ranges are computed: n ≤ 8 for the Lagrangians and involutions, n ≤ 6 for J and the time direction, k ≤ 4 for the Witt splits, n ≤ 5 for the frames.
- **Finite witnesses for continuous groups.** For the continuous groups (rotors on unit vectors, bivectors and Lagrangians of ℝ^{k,k}), the script proves the separating invariant exactly for all elements: the identity ⟨e_a γ₀ ẽ_b γ₀⟩₀ = δ_ab gives sign(u·γ₀) = sign(RR̃). Transitivity is shown on finite or rational witnesses only; the continuous transitivity statements are standard (pointer, source unread).
- **Label-level groups.** The label groups are the rotor-induced groups G_w and G_Q. Whether G_w is all of O(V, w) at n = 8 is not checked; one-orbit results do not depend on it.
- **Furey.** The partition count uses the axis action of the full graded group fixing ω. It does not ask which partitions reproduce her hypercharges or the Standard Model content; that is the threegen search (bd threegen).
- **Not treated:** r ≥ 1 (PGA), the Pin sign conventions, any manifold or chart data.
- **No physics.** Nothing is claimed about which choice nature makes.

## (e) Run time and logs

- `python3 disc_TOR.py`: 13.2 s on one core, seven lines, ending with ALL PASS. Log: `disc_TOR.log`.
- `python3 disc_TOR.py --sabotage`: 6.7 s; every check prints CAUGHT, with the reason. Log: `disc_TOR_sabotage.log`.
- Several sabotages turn a one-orbit case into many orbits, so the "1" results are not blind:
  - J with rotations in one plane only gives 3, 6, 11 orbits at n = 4, 5, 6.
  - The graded Lagrangians of Cl(4,4) under coordinate permutations only give 2 orbits (6 + 24).
  - The frames under rotors only give 2 or 4 orbits.
  - Under S₈ alone the label orbit of ω shrinks from 56 to 28 (only the weight-6 blades). The stabiliser of ω in S₈ is still transitive on the 30 Lagrangians, so the torus is gauge even for coordinate permutations alone.
- Standard library only, no randomness, no files; the script runs from any directory.
