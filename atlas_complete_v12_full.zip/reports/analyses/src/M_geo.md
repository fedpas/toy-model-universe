# Review M_geo: the Cascade Atlas v11 read by a geometer

Reviewer ID: M_geo. Frame: spin and differential geometry (spin and Pin structures, Dirac operators, Atiyah–Bott–Shapiro), Lorentzian and causal geometry (null hypersurfaces, horizons), Cartan, conformal and Cayley–Klein geometry, Coxeter groups and polytopes, Lie groups and symmetric spaces, bundles and connections, complex and symplectic structures, characteristic classes.

Status words on every claim: *standard* (with a source I read), *checked* (script, command, output line), *ours* (my reading), *open*, *input*. "Pointer, source unread" marks a literature name I did not read here; nothing in this report rests on such a pointer alone. Statements are about structures and models, not about nature. Check ids of this review are `rv·M_geo·1` to `rv·M_geo·17` (scripts in `review2/M_geo/`, copied to `out/M_geo_code/`).

## 0. Summary

**Fits.** In my language the Atlas is the pointwise (fibre-level) part of spin geometry, and almost every piece fits. The cell $(V,Q,\pi)$ is a Pin⁻ surface: $V=H_1(\#^n\mathbb{RP}^2;\mathbb Z_2)$ with its intersection form, $\pi=w_1$, $w=\pi+2Q$ the Kirby–Taylor $\mathbb Z_4$ enhancement. The clock is the Arf–Brown–Kervaire invariant in $\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$, and the mirror is the twist by $w_1$ (§3 L1–L3; `rv·M_geo·2–4`). $Q$ itself is the class $w_2$ (Pin⁺) or $w_2+w_1^2$ (Pin⁻) restricted to the reflection torus $\mathbb Z_2^n$ of the frame (L2, `rv·M_geo·1`). Steps 9–11 are Cartan geometry on the three Klein pairs; the involution of the symmetric pair is the mirror in the extra generator exactly when $s\neq0$ (L10, `rv·M_geo·13`). The horizon algebra is the null little group for every $n$ (L12, `rv·M_geo·9`). The forque is Lie–Poisson with the Klein form, which is the top-blade pairing (L13, `rv·M_geo·14–15`). The spring operator is the ABS/Koszul symbol (L14, `rv·M_geo·16`).

**Breaks (8, all with a natural patch).** B1 is the clock with null generators: the summand is not $i^{w}$. B2 is T17(b): Cl(2,2) is non-degenerate and has totally null planes. B3 is T18(f), which is unscoped for $r\ge1$. B4 is "$\gamma_0$, the observer's time direction" in the Dirac step, where $\gamma_0$ is in fact a right-hand reference and the datum the page needs is a time orientation. B5 is the branch of the horizon in NUL-001. B6 is the wording of ATL-008 on SL(2,ℂ). B7 is a missing unit in LAB-006. B8 is a sourcing gap: QD2 and LAB-018 are answered by sources I read.

**Discoveries (5).** D1 asks which theorems on $(V,Q,\pi)$ are mapping-class statements on Pin⁻ surfaces. D2 proposes null bits as boundary circles: a reading of QA1 and QC1. D3 shows that the Kepler trio is the step-11 trio through Fock's projection, beyond analogy (`rv·M_geo·17`). D4 asks whether the spring operator is a Kähler–Dirac operator in the strong sense. D5 asks whether degenerate principal polynomials pass Schuller's dual-hyperbolicity condition.

**Five most important items:**
1. Clock = ABK invariant of a Pin⁻ surface, mirror = twist by $w_1$, $(V,Q,\pi)$ classified by the clock for $n\le8$ (§3 L1–L3, §5 P8).
2. B4: $\gamma_0$ and $J$ on the right are a gauge reference, and the input is a time orientation (§4, `rv·M_geo·11`).
3. B2 and B3: T17(b) and T18(f) need "min(p,q) ≤ 1" and "r = 0" respectively (§4, `rv·M_geo·8`, `rv·M_geo·10`).
4. Steps 9–11 as Cartan geometry, with the symmetric involution equal to the mirror in $e_n$ iff $s\ne0$ (§3 L10).
5. The ABS/Koszul reading that unites T6(b), T19(4) and T20(d), and the computation of $KO^{-k}(\mathrm{pt})$ from the Atlas's own type table (§3 L5, L14).

## 1. How I read the Atlas

I took the core as given by `selfcheck/core_check.py`: I ran it and all 25 checks pass (`core·B1`–`core·B17`). I took the theorems T1–T20 as given by `researchers_checks/check_T#.py`: I ran all twenty and all pass. I also ran every page script in my field. These are projective, gravity, null, mirrors, shapes, gosset, spin, forque, spring, pgadyn, maxwell, equations and dirac_matrix, plus `steps15_17/gtg_check.py`, `labels_check.py`, `groups_check.py`, `reports/fibre_check.py`, `bridge_check.py` and `cat_check.py`; all pass. The logs are in `out/M_geo_code/logs/`.

The pieces my field sees:

- **Spin algebra at a point.** These are the bit rule (T1, PAG-002), the cell $(V,Q,\pi)$, the clock and the mirror (core·B1–B6c, LAB-017–019, QD2), and the null part (T2, core·B7–B9). Doubling and spinor weights come in through core·B10–B10c, GOS-002, T20 and SHP-002. The type table is T4 (PAG-004), the even part is T5 (MAP-013), and the Pin conventions are Conventions row 11.
- **Symbols and characteristic varieties.** T16 is the Dirac symbol, T18 covers null hypersurfaces and hyperbolicity (PAG-011, LNS-002), and the Maxwell ladders are INP maxwell/ladders.
- **Spinors and complex structures.** These are step 4 (EQN-008, INP dirac), step 5 (SPN-*, INP spin), steps 6 and 8 (CPL-*, MAT-*), MAP-018, and Furey's $\omega=L_{e_7}$ (INP dictionary).
- **Cartan and Klein geometry.** Steps 9–11 (GRV-*, PRJ-*, EQN-012–015), core·B16 and the Baez Kepler items S12/J8 belong here.
- **Lorentzian geometry.** Steps 12–13 (LAB-005–007, NUL-001–011, T18) and the source S15 belong here.
- **Mechanics.** Steps 14–16 (FRQ-*, SPR-*, RIG-*, T17, T19) belong here.
- **Polytopes and root systems.** These are SHP-*, GOS-*, MIR-*, T9, T10, T13, core·B13 and fibre·G6–G8.
- **Bundles.** The relevant pieces are the Schuller fibre/base glossary (Conventions gloss[9]), fibre·G1–G4 and the source S7.
- **Genesis.** The relevant pieces are GEN-001–009 and the primordial ideas A–C (MAP-001).

Outside my reach, each in one line:
- Furey's model internals (FUR-*, the 616 of 18 480 block partitions, the Standard Model edge labels): only the complex-structure input has a geometric reading (§2).
- The category lens beyond Frobenius forms: representation type of the cube category (T8), Tian's DG category (T7 beyond the radical vector), Majkić.
- The Pumplün crossed-product dictionary (non-associative algebra).
- The finite sporadic groups of step 17 beyond Coxeter and Weyl groups (Golay, $M_{24}$, Co₁, the Monster).
- The 25 role names on the cards ("quark", "cosmic horizon", …), which are readings with no geometric content to test.
- T15 (states, Born rule), T8 (representation type) and the 131-row translation matrix: read, not re-audited. T11's polar spaces enter only through D1. My dictionary (§2) is a 40-row geometric counterpart of the matrix, not a revision of it.
- The Ask guide and the speed test.

## 2. Dictionary

Notation: $N_n=\#^n\mathbb{RP}^2$ (closed non-orientable surface), $x_i\in H^1(B\mathbb Z_2^n;\mathbb F_2)$, $\sigma_k$ elementary symmetric polynomials, $\Gamma_n=\{\pm e_a\}$, $\beta$ = Brown / ABK invariant, $\ell$ a null vector, $\ell^\perp$ its orthogonal hyperplane, $\mathfrak h\oplus\mathfrak m$ a Klein pair.

| Atlas object (ids) | object in my field | match | evidence | flag |
|---|---|---|---|---|
| bit rule $e_ae_b=s(a,b)e_{a\oplus b}$ (T1, PAG-002) | Clifford algebra in an orthonormal frame; $\Gamma_n=\{\pm e_a\}$ is the finite Pin group lifting the reflection torus $\mathbb Z_2^n\subset O(p,q)$ | exact | T1; `rv·M_geo·1` | – |
| $Q(a)=[e_a^2=-1]$ (core·B1, T6(c), glossary "form") | extension class of $\Gamma_n\to\mathbb Z_2^n$; $=\sigma_2+\sum_{i\in N}x_i^2$: the pullback of $w_2$ (all $\varepsilon=+1$, Pin⁺) or $w_2+w_1^2$ (all $-1$, Pin⁻) | exact with convention (Kirby–Taylor: $v^2=\pm1$ for Pin$^\pm$) | `rv·M_geo·1` (9216 cases, $n\le9$); KT Lemma 1.3 (read) | – |
| grading $\pi$ | $w_1$ of the reflection torus; on $N_n$ the orientation character, $\pi(a)=a\cdot a$ | exact | `rv·M_geo·2` | – |
| $w=\pi+2Q$, clock (core·B1–B3, LAB-017/018, QD2) | $\mathbb Z_4$ quadratic enhancement of the intersection form of $N_n$, i.e. a Pin⁻ structure (KT Thm 3.2); clock = ABK $\in\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$ | exact with convention ($\varepsilon_i=+1\leftrightarrow q=1$) | `rv·M_geo·2`; KT Lemma 3.6; Debray–Gunningham (DG) eq. 3.14, Thm 3.15, Ex. 3.17 (read) | B8 |
| mirror $Q\mapsto Q+\pi$ (core·B4, B4b) | twist of the Pin⁻ structure by $w_1$: $q\mapsto q+2w_1=-q$, $\beta\mapsto-\beta$; on $Q$: $w_2\leftrightarrow w_2+w_1^2$ (Pin⁺ ↔ Pin⁻, Conventions row 11) | exact | `rv·M_geo·1`, `rv·M_geo·4` | – |
| $(V,Q,\pi)$ iso ⇔ same clock (core·B6c, $n\le5$) | $O(H_1,\cdot)$-orbits of enhancements = ABK classes | exact ($n\le8$) | `rv·M_geo·3` | – |
| null part $Cl(p,q)\hat\otimes\Lambda(\mathbb R^r)$ (T2, core·B7) | Clifford algebra of a degenerate form; at a point of a null hypersurface, the Carrollian tangent space; in PGA, the degenerate co-metric of Euclidean space | exact | T2; T18(e); `rv·M_geo·9` | D5-type duality, §6 |
| clock with null bits (INP clock, core·B3) | Brown invariant of the degenerate enhancement $w_D(a\wedge D)$: radical = null span, $w=0$ there | exact with convention; the literal $w=\pi+2Q$ fails | `rv·M_geo·5` | B1 |
| type table, "Bott clock" (T4, PAG-004) | Brauer–Wall class of $Cl(p,q)$; separately, ABS: $\operatorname{coker}(M(Cl_k)\to M(Cl_{k-1}))=KO^{-k}(\mathrm{pt})$ from the same types | exact (two different invariants) | `rv·M_geo·6`; ABS pointer, source unread | – |
| doubling $Cl(V)\hat\otimes Cl(-V)=\operatorname{End}Cl(V)$ (core·B10); "base/fibre" use 1 (glossary) | $Cl(V)$ as bimodule: left = Clifford module over the base, right = commuting $Cl$-action (the $Cl_k$-linear spinor module) | partial: pointwise only | core·B10, fibre·G2c; Lawson–Michelsohn pointer, source unread | ours |
| blade labels = spinor weights (core·B10b/c, GOS-002, SHP-002) | weights of the spinor module $\Lambda(\mathbb R^m)$ of $Cl(m,m)\supset\mathfrak{so}(m,m)$ after a Witt split | exact with input (Witt split, INP orth) | core·B10b/c, T20 | – |
| "base ⊗̂ fibre" use 2 (fibre·G1, LNS) | $T_eE=H_e\oplus V_e$: $Cl(T_eE)=Cl(H_e)\hat\otimes Cl(V_e)$ | fits with input: an Ehresmann connection (and a fibre metric) | fibre·G1a/b | – |
| "base/fibre" use 3 (plus = base, minus = fibre) | none | none | – | naming only |
| bivectors, step 2 (EQN-001/007) | $\Lambda^2V\cong\mathfrak{so}(V)=\operatorname{Lie}\mathrm{Spin}(V)$ | exact | equations_selfcheck | – |
| mirrors $x\mapsto -axa^{-1}$, versors, Cartan–Dieudonné (step 3, MIR-*) | twisted adjoint action of Pin; reflection groups $B_n,D_n$ | exact with convention (Pin± swap) | mirrors_selfcheck | – |
| transvections over $\mathbb F_2$ (T12) | Cartan–Dieudonné in characteristic 2 | exact | T12 | – |
| sign of a square $-1,+1,0$ (T17, PAG-031, LAB-003/015) | elliptic / hyperbolic / parabolic one-parameter subgroups; nilpotent Jordan types in $\mathfrak{so}(p,q)$ | partial | T17; `rv·M_geo·10` | B2 |
| $\nabla F=J$ (Calibration 1) | $dF=0$, $d{\star}F=J$; in the geometric-product form only the metric is needed, not an orientation | exact on a flat chart (inputs as listed) | maxwell_selfcheck | – |
| hyperbolicity map (T18(f), PAG-011, LNS-002) | Gårding hyperbolicity of the principal symbol | exact for $r=0$; incomplete for $r\ge1$ | `rv·M_geo·8` | B3 |
| Dirac $\nabla\psi J=m\psi\gamma_0$ (EQN-008, INP dirac) | Dirac operator on the spinor module $Cl^0(1,3)$ with a right $U(1)$ (Hestenes' real form) | exact; $\gamma_0$ and $J$ form a right reference | `rv·M_geo·11` | B4 |
| complex structure inputs ($J$, MAP-018 counts $0,0,1,3,6$; "three kinds of $i$") | complex structures on a module commuting with an algebra action: central $I$ (complex algebra), right $J$ (complex module); the choices of $J$ are one orbit of the right $\mathrm{Spin}(n-1)$ | exact with convention | `rv·M_geo·11` | ours |
| $\omega=L_{e_7}$ (INP dictionary/findings) | a point of $O(16)/U(8)$ (orthogonal complex structures on $\mathbb R^{16}$) | partial | – | input (correct as stated) |
| T16 symbol determinant | Dirac symbol $\sigma(\xi)^2=Q(\xi)$; characteristic variety = null cone | exact | T16 | – |
| ATL-008 "unit even versors form SL(2,ℂ)" | $\mathrm{Spin}(1,3)=SL(2,\mathbb C)=\{x\in Cl(1,2):x\bar x=1\}$; $\mathrm{Spin}(1,2)=SL(2,\mathbb R)$ | wording | `rv·M_geo·12` | B6 |
| steps 9–10, Cartan gravity, MacDowell–Mansouri (GRV-*) | Cartan geometry modelled on dS/AdS/Minkowski: $F=(R-\tfrac{\Lambda}{3}e\wedge e)+d_\omega e$ (Wise §1) | exact with convention (sign of $k$ depends on $\Lambda^2V\cong\mathfrak{so}(V)$) | gravity_selfcheck; Wise (read); `rv·M_geo·13` | – |
| step 11, extra generator $s$ (PRJ-*, EQN-015) | Klein pairs $(\mathfrak{so}(n+1),\mathfrak{so}(n))$, $(\mathfrak e(n),\mathfrak{so}(n))$, $(\mathfrak{so}(1,n),\mathfrak{so}(n))$ and their Lorentz analogues; Cayley–Klein geometries | exact | `rv·M_geo·13`; core·B16 | name "projective" = Klein's sense, not Cartan's projective structures |
| null pair, $P(x)=o+x-\tfrac12x^2\varepsilon$ (PRJ, NUL-008) | conformal compactification; projectivised null cone; celestial sphere $S^2=\mathbb R^2\cup\infty$; "the generator is the point at infinity" = choice of stereographic pole | exact with input (the pole) | projective_selfcheck, null S6.5 | – |
| translation = null rotation $T=1-an_\infty/2$ (LAB-004) | translations of the celestial plane = null rotations fixing $\ell$ | exact | gtg_check R; `rv·M_geo·9` | – |
| step 12 shear $\bar h=1+N$ (LAB-005) | Painlevé–Gullstrand coframe; soldering form on $\mathbb R^4$ | exact with input (borrowed solution, topology $\mathbb R^4$) | gtg_check | – |
| Weyl map (LAB-006) | Petrov type D, eigenvalues $(-2,1,1)M/r^3$ (complex) | exact once the unit is given | gtg_check S10, G8 | B7 |
| $\xi\cdot\nabla\xi=-\kappa\xi$ (NUL-001, null S12.1) | surface gravity; the Atlas chart is the retarded EF chart, covering the past horizon | exact with convention | `rv·M_geo·7` | B5 |
| tangent algebra $Cl(0,n-2,1)$ (NUL-004, T18(a,e)) | Clifford algebra of the Carrollian degenerate metric on $\ell^\perp$; its bivectors = $\mathfrak{so}(1,n-1)_\ell=\mathfrak{iso}(n-2)$ | exact, every $n$ | `rv·M_geo·9` | – |
| two kinds of null (LAB-007, NUL-004, T7(3)) | $\ell$ is a Witt partner of $m$ in $T_pM$; in $\ell^\perp$ the partner is cut off and $\ell$ spans the radical | exact (one fact) | `rv·M_geo·9` | – |
| forque, step 14 (FRQ-*) | Lie–Poisson / Euler–Arnold on $\mathfrak{se}(3)^*$; the Klein form (screw reciprocal product) = top-blade Frobenius pairing | exact | `rv·M_geo·14–15` | – |
| spring $D=\sum L_{e_i}$ (T19(4), SPR-004); Koszul complex (T6(b)); $\operatorname{sdim}\Lambda=0$ (T20(d)) | ABS (Koszul) symbol at $v=(1,\dots,1)$: $D=d+d^{T}$, $d$ = augmented boundary of the full simplex, $D^2=n$ | exact | `rv·M_geo·16` | – |
| T19 trichotomy in SL(2,ℝ) | conjugacy classes in $Sp(2,\mathbb R)$; stability of linear Hamiltonian systems | exact | T19, fibre·G5 | – |
| shapes (SHP, GOS, T10, T13, fibre·G8) | Coxeter groups $B_n,D_n,E_n$; orthoplex/cube duality; Gosset $k_{21}$; $E_8=D_8^+$ | exact | shapes, gosset, fibre·G6–G8 | – |
| T9: $W(E_n)\bmod2=O(q)$ | Weyl group mod 2 | exact | T9 | – |
| Kepler trio vs extra generator (S12, core·B16) | Fock's projection: orbits of energy $E<0,=0,>0$ ↦ geodesics of $S^3,\mathbb R^3,H^3$ | exact (more than analogy) | `rv·M_geo·17` | D3 |
| Genesis ideas A, B (GEN-002–007) | Witt decomposition: radical ⊕ hyperbolic planes; Witt class 0; ABK 0 | exact with input (an anisotropic part for clock $\ne0$) | core·B3; `rv·M_geo·2` | – |
| idea C, "tour of 8" (MAP-001) | period of the Brauer–Wall / ABK group | partial (a scope, not a structure) | – | ours |
| 25 role names (PAG-006) | none | none | – | readings |

## 3. Reconnection: the one picture

The picture in one sentence. *The Atlas is the algebra of one tangent space with a quadratic form, read through the finite Pin group of an orthonormal frame. Its $\mathbb F_2$ data $(V,Q,\pi)$ are those of a Pin⁻ surface. Its steps are the standard pointwise constructions of spin, Lorentzian and Cartan geometry, each needing a named global input that the Atlas, being pointwise, does not supply.* Links, in order of dependence:

**L1 (fits).** The bit rule is the Clifford algebra in an orthonormal frame (T1). The 2ⁿ signed blades form the finite group $\Gamma_n=\{\pm e_a\}\subset\mathrm{Pin}(p,q)$, the preimage of the diagonal reflection torus $\mathbb Z_2^n\subset O(p,q)$. Its extension data are $e_a^2=(-1)^{Q(a)}$ and $e_ae_b=(-1)^{\mathrm{polar}\,Q(a,b)}e_be_a$. *checked*: `rv·M_geo·1`, line "e_a e_b = (-1)^{polar Q(a,b)} e_b e_a (n <= 6)".

**L2 (fits).** $Q_{Cl(p,q)}(a)=\sigma_2(a)+|a\wedge N|\bmod 2$, with $N$ the set of $-1$ generators. This is the class $\sigma_2(x)+\sum_{i\in N}x_i^2\in H^2(\mathbb Z_2^n;\mathbb F_2)$ under the identification of T6(c) (classes = quadratic forms). For all $\varepsilon=+1$ it is $w_2$ of the representation $\bigoplus_i\mathrm{sign}_i$. For all $\varepsilon=-1$ it is $w_2+w_1^2$. These are exactly the obstructions to Pin⁺ and Pin⁻ lifts (Kirby–Taylor, Lemma 1.3, read; their convention $vw+wv=\pm2(v,w)$ for Pin$^\pm$ is the Atlas's sign of $\varepsilon$). *checked*: `rv·M_geo·1`, "for all 9216 (cell, label) pairs, n <= 9". Consequence: the mirror $\varepsilon\mapsto-\varepsilon$ (core·B4: $Q\mapsto Q+\pi$) exchanges $w_2$ and $w_2+w_1^2$, which is the Pin⁺ ↔ Pin⁻ swap that Conventions row 11 says "the Atlas does not treat". It is now treated at the level of the frame.

**L3 (fits).** The pair $(V,\cdot)$ with the dot product is $H_1(N_n;\mathbb Z_2)$ with its intersection form in the crosscap basis. $\pi(a)=a\cdot a$ is $w_1$. $w=\pi+2Q$ satisfies $w(a+b)=w(a)+w(b)+2a\cdot b$, so it is a $\mathbb Z_4$ quadratic enhancement. By Kirby–Taylor Thm 3.2 (read) these are the Pin⁻ structures on $N_n$. The normalised Gauss sum $2^{-n/2}\sum_ai^{w(a)}=\zeta_8^{p-q}$ is the ABK invariant (DG eq. 3.14), an isomorphism $\Omega_2^{\mathrm{Pin}^-}\to\mathbb Z_8$ (KT Lemma 3.6; DG Thm 3.15, read). $Cl(1,0)$ and $Cl(0,1)$ are $\mathbb{RP}^2$ with its two Pin⁻ structures, ABK $=\pm1$ (DG Ex. 3.17, read). *checked*: `rv·M_geo·2`, "n = 1: [(0, 1, 7), (1, 0, 1)]". Further:
- The mirror is the twist by $w_1$: $\beta(w+2a\cdot)=\beta(w)-2w(a)$, and $\beta\equiv w(1\dots1)\pmod4$. *checked*: `rv·M_geo·4`, $n\le7$, every class $a$.
- $(V,Q,\pi)$ up to isomorphism is the clock. The $2^n$ enhancements are exactly the $w_\varepsilon$, and the orbits of $O(V,\cdot)$ on them are exactly the ABK classes. *checked*: `rv·M_geo·3`, "(3, 4, [1, 3, 5, 7]) … (8, 4, [0, 2, 4, 6])"; this extends core·B6c from $n\le5$ to $n\le8$.

**L4 (fits with an input: the null bits are put in the radical with weight 0).** For $r\ge1$ the summand of the clock (core·B3 code) is $i^{w_D(a\wedge D)}$. This is an enhancement of the degenerate form $|a\wedge b\wedge D|$, whose radical is exactly the null span and on which $w=0$; its Gauss sum is $2^rG_D$. The other admissible value $w=2$ on a radical vector makes the sum $0$. *checked*: `rv·M_geo·5`. The literal $w=\pi+2Q$ with $\pi$ counting null generators is not an enhancement (B1). The reading is that a null generator is a boundary circle with the bounding spin structure (*ours*; D2).

**L5 (fits; two different period-8 invariants).** The type table (T4) gives the Brauer–Wall class (the clock). The same bit-rule types of $Cl(0,k)$ also give the Atiyah–Bott–Shapiro groups. The relevant data are the factors, the division algebra and the irreducible dimensions $(1,\mathbb R,1),(1,\mathbb C,2),(1,\mathbb H,4),(2,\mathbb H,4),(1,\mathbb H,8),(1,\mathbb C,8),(1,\mathbb R,8),(2,\mathbb R,8),(1,\mathbb R,16)$; whenever there are two irreducibles, the next generator anticommutes with the central top blade and swaps them. Then $\operatorname{coker}(M(Cl_k)\to M(Cl_{k-1}))=\mathbb Z_2,\mathbb Z_2,0,\mathbb Z,0,0,0,\mathbb Z$ for $k=1..8$, which is $KO^{-k}(\mathrm{pt})$ (ABS: pointer, source unread). *checked*: `rv·M_geo·6`. The Atlas uses the first invariant (a group $\mathbb Z_8$); index theory uses the second. Neither is misused anywhere I read.

**L6 (fits pointwise; the global part is outside).** Doubling (core·B10) is $Cl(V)$ acting on itself on both sides, with the right action the Brauer–Wall inverse (fibre·G2c). In a spinor bundle $S=P_{\mathrm{Spin}}\times Cl(V)$ the left action is Clifford multiplication by tangent vectors of the base. The right action commutes with it and with any Dirac operator: this is the $Cl_k$-linear structure whose index lies in $KO^{-k}$ (Lawson–Michelsohn: pointer, source unread). So glossary use 1 ("left = base, right = fibre") matches "Clifford module of the base versus commutant". Use 2 (base ⊗̂ fibre, fibre·G1) matches $Cl(T_eE)=Cl(H_e)\hat\otimes Cl(V_e)$ and needs an Ehresmann connection to choose $H_e$: an input. Use 3 (plus = base) has no counterpart.

**L7 (fits).** Step 2: bivectors $=\mathfrak{so}(p,q)$. Step 3: $x\mapsto-axa^{-1}$ is the twisted adjoint action of Pin. Corners of the cube are products of coordinate mirrors (MIR-001, RSN-007), i.e. the torus of L1. Over $\mathbb F_2$ Cartan–Dieudonné fails as T12 says. *checked* by mirrors_selfcheck and T12.

**L8 (fits with an input: a time orientation).** Step 4: $\nabla\psi J=m\psi\gamma_0$ on even $\psi$ is Hestenes' real Dirac equation. For a plane wave, $\psi_0=m+p\gamma_0$ solves $p\psi_0=m\psi_0\gamma_0$. A change of observer acts on the left and keeps $\gamma_0$. A change of the right pair $(\gamma_0,J)\to(L\gamma_0\tilde L,LJ\tilde L)$ is undone by $\psi\mapsto\psi\tilde L$ and leaves the current $\psi\gamma_0\tilde\psi=2(m+p\cdot\gamma_0)p$ unchanged. The sign of $\psi\tilde\psi=2m(m+p\cdot u)$ is the same for every future unit $u$. *checked*: `rv·M_geo·11`. So $(\gamma_0,J)$ is a gauge reference of the right action, and the datum the step needs is a time orientation (B4). The complex structure $J$ is any unit simple spatial bivector; these form one orbit of the right $\mathrm{Spin}(n-1)$ that fixes $\gamma_0$. The rotation case is computed in `rv·M_geo·11`; the general orbit statement is *ours*, consistent with MAP-018's counts $0,0,1,3,6$ $=\binom{n-1}{2}$.

**L9 (fits for $r=0$; incomplete for $r\ge1$).** T16 is the Dirac symbol identity $\sigma(\xi)^2=Q(\xi)$. T18(f) is Gårding hyperbolicity of a quadratic symbol. With null generators the criterion becomes "$s=1$ or $t=1$, any $r$", with strict hyperbolicity iff $r=0$. *checked*: `rv·M_geo·8`. The characteristic variety is the null cone, and null surfaces are the wavefronts (NUL-010, T18 G).

**L10 (fits).** Steps 9–11 are Cartan geometry. For a base $Cl(0,d)$ or $Cl(1,d-1)$ and an extra generator of square $s$, $\mathfrak g=\mathfrak h\oplus\mathfrak m$ with $\mathfrak m=\operatorname{span}B_{an}$. Here $[\mathfrak h,\mathfrak m]$ acts on $\mathfrak m$ as the vector representation and $[B_{an},B_{bn}]=-2sB_{ab}$. These are the Klein pairs of $S^d,\mathbb E^d,H^d$ and of dS, Minkowski, AdS. All three pairs are symmetric. The involution $\theta=+1$ on $\mathfrak h$ and $-1$ on $\mathfrak m$ is the mirror in the extra generator, $x\mapsto e_nxe_n^{-1}$, exactly when $s\neq0$; for $s=0$ it is no sandwich ($e_nXe_n=0$). *checked*: `rv·M_geo·13`, $d=2..5$. The curvature of step 10, "$R+k\kappa^2e\wedge e$ on the first generators and $\mu\kappa T$ on the new ones", is the split of a Cartan curvature into its $\mathfrak h$ part and its torsion. Wise §1 (read) writes $F=(R-\frac{\Lambda}{3}e\wedge e)+d_\omega e$, with $\mathfrak{so}(4,1)$ for $\Lambda>0$ and $\mathfrak{so}(3,2)$ for $\Lambda<0$. The invariant content, "an extra generator with the square of space gives de Sitter", agrees. The sign of $k$ itself depends on the identification $\Lambda^2V\cong\mathfrak{so}(V)$ (the Atlas says so). This reconnects step 3 with step 11: the curved model spaces get their symmetry from a mirror, and the flat one does not, which is MIR-006 and NUL-009 seen from Cartan geometry.

**L11 (fits).** Adding a null pair gives the conformal model. $P(x)=o+x-\frac12x^2\varepsilon$ parametrises the projectivised null cone (projective_selfcheck; null S6.5). In $Cl(1,3)$ the null directions are the celestial sphere, and naming the horizon generator "the point at infinity" chooses a stereographic pole (an input). Translations of that plane are null rotations fixing $\ell$ (LAB-004, gtg_check R). By L12 these are the horizon's motors.

**L12 (fits with a convention).** Step 13, read in Lorentzian geometry:
- For any $n$, the bivectors of $\ell^\perp$ commute with $\ell$ and have rank $\binom{n-1}{2}=\dim\mathfrak{so}(1,n-1)-(n-1)$. Their brackets equal those of the bivectors of $Cl(0,n-2,1)$. So the horizon algebra's motors are the null little group $\mathfrak{iso}(n-2)$ for every $n$, not only for the tube at $n=4$ (NUL-004). *checked*: `rv·M_geo·9`, $n=3..7$.
- The restricted form on $\ell^\perp$ has radical exactly $\operatorname{span}\ell$, while $\ell\cdot m=1$ for $m=(e_0-e_1)/2\notin\ell^\perp$. LAB-007's "paired null of spacetime" and "radical of the surface" are the same vector before and after the cut. This is also T7(3)'s "orphaned half of a hyperbolic pair" (one fact, three places).
- The tangent structure is Carrollian (*ours*, standard name; pointer, source unread: Duval–Gibbons–Horváthy). The surface gravity $\kappa=T'/2$ matches the five Atlas values; the sign in $\xi\cdot\nabla\xi=\mp\kappa\xi$ is a branch choice (B5). *checked*: `rv·M_geo·7`.

**L13 (fits).** Steps 14 and 16: the motors are $\mathfrak e(3)$ (step 11, $s=0$). Its invariant symmetric bilinear forms form a 2-dimensional space. The scalar part $\langle XY\rangle_0$ has signature $(0,3,3)$: it is blind to the null bit (T3 F4). The top-blade part $\langle XY\rangle_4$ has signature $(3,3,0)$: this is the Klein form (reciprocal product) of screw theory, and it is FRQ-002's "join pairing". *checked*: `rv·M_geo·14`, for both PGA conventions. The force-free forque equation $\dot P=[P,B]$ with $P=A[B]$ and $A$ Klein-symmetric is the Lie–Poisson (Euler–Arnold) flow: both Casimirs and the energy are conserved exactly. *checked*: `rv·M_geo·15`. Gunn's "the equations coincide in the three PGAs" (PRJ-004, cited not derived) is in this language the statement that the Euler–Arnold formula is the same for the three Klein pairs of L10; only the structure constants $-2s$ change (*ours*).

**L14 (fits).** Step 15: on the labels, $D_\varepsilon=\sum_iL_{e_i}$ is wedge by $v=\sum e_i$ plus $\varepsilon$-weighted contraction (T20(a)), with $D_\varepsilon^2=(p-q)I$.
- For $\varepsilon=+1$ the contraction is the augmented simplicial boundary of the full simplex on $n$ vertices (T6(b)). $D=d+d^T$ has Hodge Laplacian $nI$, so the simplex has no reduced homology.
- $D$ is odd and $\operatorname{str}I=0$ (T20(d)). For $\varepsilon=0$, $D=v\wedge$ is a differential.
- For every $v$, $\sigma(v)=v\wedge+v\lrcorner$ squares to $|v|^2$: this is the Koszul/ABS symbol (the Thom class of $\mathbb R^n$ in K-theory; pointer, source unread).

*checked*: `rv·M_geo·16`, $n=1..7$. So T6(b), T19(4) and T20(d) are one statement: the ABS symbol at $v=(1,\dots,1)$ is invertible, hence its index on the $\mathbb Z_2$-graded label space is $0$.

**L15 (fits).** Shapes and root systems, all *checked* by the Atlas scripts:
- orthoplex/cube duality (SHP-001);
- $24=3\times8$ in $2T$ (SHP-004, fibre·G6);
- $D_5$ roots as orthoplex edges (SHP-005);
- $E_8=D_8\cup(D_8+(\tfrac12)^8)$ (SHP-006, fibre·G8a);
- the Gosset chain $240\to56\to27\to16\to10\to6\to3$ (fibre·G8b), matching the vertex counts of $4_{21},3_{21},2_{21},1_{21},0_{21},-1_{21}$ and the vertex figure of $-1_{21}$;
- $E_8\supset E_6\times A_2$ (T13).

**L16 (fits more than the Atlas says).** Baez's Kepler trio (S12) and the extra generator of step 11 share their Lie algebras (core·B16). Geometrically, Fock's projection maps orbits of energy $E<0,=0,>0$ to geodesics of $S^3,\mathbb R^3,H^3$, which are the three model spaces of L10 with a space base. *checked*: `rv·M_geo·17`. See D3.

**L17 (fits with an input).** Genesis: idea A is a radical vector and idea B a hyperbolic plane. Ideas A and B alone give the Witt-class-0 cells $Cl(k,k,r)$, all with clock 0, i.e. Pin⁻ null-bordant enhancements in L3. A non-zero clock needs an anisotropic summand, i.e. an $\mathbb{RP}^2$ with a fixed Pin⁻ structure, the generator of $\Omega_2^{\mathrm{Pin}^-}$. This is GEN-005 ("Cl(4,0) and Cl(0,4) cannot be reached by pairing alone") in bordism language (*ours*). Idea C, the tour of 8, is the order of that generator (*ours*).

**What has no counterpart.** The Atlas has no manifold. Spin structures as global objects ($w_2(M)=0$), the index of a Dirac operator on a compact manifold, holonomy, curvature as a field solving equations, causal structure beyond a point, and contact structures do not appear. The Atlas says so for bundles (source S7). For each step the global input is named: the Atlas's "chart", plus in my words a spin structure (steps 4–8), a time orientation (step 4), a connection (fibre/base), a Cartan connection (steps 9–12), a horizon branch (step 13), and a symplectic manifold $T^*SE(3)$ reduced to $\mathfrak{se}(3)^*$ (step 14).

## 4. Breaks

Each break is decided by a computation. Script paths are relative to the clone; my scripts are in `review2/M_geo/`, copied to `out/M_geo_code/`.

| B | Atlas ids | what my field says | what the Atlas says | minimal computation or counterexample | kind | natural patch |
|---|---|---|---|---|---|---|
| B1 | core·B3 (row text), LAB-017 | The Brown invariant needs a $\mathbb Z_4$ enhancement of a bilinear form. For a degenerate form it is that of $V/\mathrm{Rad}$ when $w|_{\mathrm{Rad}}=0$; the Gauss sum is $0$ when $w=2$ on a radical vector. | "the Gauss sum of $i^w$ over all blades equals $(1+i)^p(1-i)^q$ … and $2^r$ times it for r = 1, 2 null generators". The code (core_check.py lines 82–88) sums $i^{\lvert a\wedge P\rvert-\lvert a\wedge Q\rvert}$, not $i^w$. | `rv·M_geo·5`. With $w=\pi+2Q$ ($\pi$ counting all generators), $Cl(0,0,1)$ gives $\sum i^w=1+i\neq2$. The enhancement identity fails at $Cl(0,0,2)$, $a=1,b=2$: $w(a+b)=0$, $w(a)=w(b)=1$, $2a\cdot b=0$. | WRONG (text against code) | "for $r\ge1$, $w$ is replaced by its pullback $w_D(a\wedge D)$ from $V/\mathrm{Rad}$ (null bits weight 0); this is an enhancement of the degenerate form whose radical is the null span, with $w=0$ there, and its Gauss sum is $2^r(1+i)^p(1-i)^q$" |
| B2 | T17(b) (researchersData THEOREMS[16]; theorems page) | In $\mathfrak{so}(p,q)$ with $p,q\ge2$ a totally isotropic plane gives a nilpotent $u\wedge v$ of Jordan type $2^2$ ($D^2=0$), distinct from a null rotation ($D^2\ne0$, $D^3=0$). | "null rotation (the only s = 0 kind inside a non-degenerate cell); totally null plane … needs … p,q ≥ 2" | `rv·M_geo·10`: in $Cl(2,2)$, $u=e_1+f_1$, $v=e_2+f_2$ give $B^2=0$, $D\ne0$, $D^2=0$. check_T17.py's own output lists `(2, 2, 0) ['boost', 'totally null plane']`. | WRONG (wording; the script is right) | "null rotation (the only s = 0 kind inside a non-degenerate cell with min(p,q) = 1; for min(p,q) ≥ 2 a non-degenerate cell also has totally null planes)" |
| B3 | T18(f), PAG-011, LNS-052 (INP-009/010 are about the Maxwell ladders, where r = 0, and are correct) | Gårding: a quadratic symbol of signature $(s,t,r)$ has a hyperbolic direction iff $s=1$ or $t=1$, for any $r$; it is strictly hyperbolic iff also $r=0$. | "A quadratic principal polynomial is hyperbolic iff its signature is Lorentzian" (T18(f); PAG-011 "hyperbolic exactly for Lorentzian signatures"). check_T18.py part F tests only $(s,t)$. LNS-002 and LNS-060 do scope it to $r=0$. | `rv·M_geo·8`: signature $(1,1,1)$, $P=k_0^2-k_1^2$: $h=e_0$ is hyperbolic ($B(k,h)^2-P(h)P(k)=k_1^2\ge0$), and $\xi=e_2$ gives a double root. | SCOPE | add "(r = 0)" to T18(f), PAG-011 and LNS-052, and the sentence of P3 |
| B4 | INP-022, INP-030, INP-044, INP-073, INP-019 (current half) | In Hestenes' real Dirac theory $\gamma_0$ and $J$ act on the right. Observers act on the left. A change of the right pair is an internal gauge equivalence, and the energy sign depends on a time orientation. | "(time) $\gamma_0$, the observer's time direction, enters the mass term and the current $\psi\gamma_0\tilde\psi$"; "… defines the energy of a plane wave" | `rv·M_geo·11` (exact, 5 momenta, boosts and rotations): the left change keeps $\gamma_0$; the right change $(\gamma_0,J)\to(L\gamma_0\tilde L,LJ\tilde L)$ with $\psi\mapsto\psi\tilde L$ leaves the current unchanged; $\operatorname{sign}\psi\tilde\psi=\operatorname{sign}(m+p\cdot u)$ for all future $u$. | DICTIONARY (input mislabelled) | P4 |
| B5 | NUL-001, null S12.1, MAP-028 | Surface gravity: $\xi^b\nabla_b\xi^a=\kappa\xi^a$ on the future horizon and $-\kappa\xi^a$ on the past horizon (same $\kappa$). | "The generator obeys $\xi\cdot\nabla\xi=-\kappa\xi$ with $\kappa=\frac12dT/dx$" in the "regular chart" $T\,dv^2+2\,dv\,dx$, shown as "Eddington–Finkelstein"; the branch is not named. null_selfcheck S3.4 defines $v=t-\bar r$, i.e. retarded time. | `rv·M_geo·7`: in $T\,dv^2+2c\,dv\,dx$, $\xi\cdot\nabla\xi=-c\,\kappa\,\xi$. With $c=+1$ the future null lines $v=$ const are outgoing (retarded chart, past horizon); $c=-1$ gives $+\kappa\xi$ (advanced chart, future horizon). | DICTIONARY | P5 |
| B6 | ATL-008 | $\mathrm{Spin}(1,2)=SL(2,\mathbb R)$ (dimension 3); $SL(2,\mathbb C)=\mathrm{Spin}(1,3)$ sits in $Cl^0(1,3)\cong Cl(1,2)$ as $\{x\bar x=1\}$ (Clifford conjugation of $Cl(1,2)$). | "Cl(1,2) is also the even subalgebra of the spacetime algebra Cl(1,3); its unit even versors form SL(2,ℂ)" ("its" reads as Cl(1,2)) | `rv·M_geo·12`: the Lie algebra of the unit even versors of $Cl(1,2)$ has dimension 3 and Killing signature $(2,1)$; $\{x\bar x=1\}$ has tangent grades $1+2$, dimension 6 = that of the even versors of $Cl(1,3)$. | DICTIONARY (wording) | P6 |
| B7 | LAB-006 | Point-mass Weyl map: complex eigenvalues $(-2,1,1)M/r^3$ (real $(-2,-2,1,1,1,1)M/r^3$). | "the Weyl map of a point mass, eigenvalues (4, −2, −2)" | gtg_check.py S10: "(4,4,-2,-2,-2,-2) x(-M/2r^3)", and G8: "(-2, -2, 1, 1, 1, 1) M/r^3" (both ok). | GAP (unit missing) | "eigenvalues (4, −2, −2) in units of −M/(2r³), i.e. (−2, 1, 1) M/r³" |
| B8 | LAB-018, QD2 (first half), PAG-020 | Kirby–Taylor Thm 3.2 and Lemma 3.6, Debray–Gunningham eq. 3.14 and Thm 3.15 (read): the Brown/ABK invariant is the normalised Gauss sum of a $\mathbb Z_4$ enhancement $q(x+y)=q(x)+q(y)+2x\cdot y$. | "calling the clock 'the Brown invariant' is our identification … (Brown; Kirby–Taylor: pointers, sources unread)"; QD2 asks whether it is correct | `rv·M_geo·2` (identity and Gauss sum), with core·B1–B3 | GAP (status) | P8 |

Not breaks, recorded for completeness:
- The Atlas's "projective" (step 11) is Klein's sense (Cayley–Klein metric geometries as projective geometries with an absolute). It is not Cartan's "projective structure". This is a naming flag only.
- The sign "$k=-s$" (GRV-007, PRJ-002) differs from Wise's $-\Lambda/3$ by the identification $\Lambda^2V\cong\mathfrak{so}(V)$. The Atlas already says its sign rests on a convention, and the invariant statement agrees.
- GOS-002 and core·B10c: "in Cl(8,0) the 128 even blades carry the half-spinor weights". The weights are eigenvalues of $L_iR_i\in Cl(8,8)=\operatorname{End}Cl(8,0)$, so the statement is about $\mathfrak{so}(8,8)$ (complexified $\mathfrak{so}(16)$) acting on $Cl(8,0)$ as a module. It is correct as written.

## 5. Patches

**P1 (B1).** core·B3 row text and LAB-017. Replace "and 2^r times it for r = 1, 2 null generators" by: "with r = 1, 2 null generators the clock sum gives each null bit weight 0, i.e. it is the Gauss sum of $w_D(a\wedge D)$, the form of the non-degenerate part pulled back along $V\to V/\mathrm{Rad}$. This is a $\mathbb Z_4$ enhancement of the degenerate form $|a\wedge b\wedge D|$ whose radical is the null span, with $w=0$ on it, and its Gauss sum is $2^r(1+i)^p(1-i)^q$. The literal $w=\pi+2Q$, with $\pi$ counting null generators, is not an enhancement when $r\ge1$ (rv·M_geo·5)." New flag: checked (core·B3 and rv·M_geo·5). Cost: none; the code already does this. The convention INP "a null generator adds weight 0" becomes "the unique convention that puts the null bits in the radical and keeps the Gauss sum non-zero" (the value 2 kills it): still an input, but a forced one.

**P2 (B2).** T17(b): "The unipotent case has three kinds. Translation: the plane's radical lies in the radical of the whole space. Null rotation: Gram rank 1, $D^2\ne0$, $D^3=0$; this is the only $s=0$ kind in a non-degenerate cell with $\min(p,q)=1$. Totally null plane: Gram $=0$, $D^2=0$; it needs two independent orthogonal null vectors ($p,q\ge2$; or $p,q\ge1$ with $r\ge1$; or $r\ge2$), so it occurs in non-degenerate cells with $\min(p,q)\ge2$, the first being $Cl(2,2)$." New flag: proved; checked by check_T17.py part C and rv·M_geo·10. Cost: none.

**P3 (B3).** T18(f) and PAG-011: "(r = 0) A non-degenerate quadratic principal polynomial is hyperbolic iff its signature is Lorentzian. With r ≥ 1 null generators, $P$ has a hyperbolic direction iff exactly one generator has one of the two non-zero signs ($s=1$ or $t=1$). It is then hyperbolic only in the weak sense: never strictly, since every radical covector gives a double root. Elliptic cells with a null generator, such as $(0,n-1,1)$, have none unless $n-1=1$." New flag: checked (rv·M_geo·8 for $n\le6$); the proof is two lines (B(k,h)² − P(h)P(k) = −ε_i Σ_{j≠i} ε_j k_j² for $h=e_i$; with two generators of each sign the $P$-orthogonal complement of any $h$ contains a vector of the same sign as $P(h)$). Cost: none. Consequence: the hyperbolicity map of cells (Schuller lens) gets a column for $r\ge1$. The horizon algebra $Cl(0,n-2,1)$ is hyperbolic only at $n=3$.

**P4 (B4).** INP-022, INP-030, INP-044, INP-073, and the current half of INP-019: replace "(time) $\gamma_0$, the observer's time direction, …" by: "(time) a time orientation, i.e. which half of the light cone is the future. The $\gamma_0$ and $J=\gamma_2\gamma_1$ on the right of $\nabla\psi J=m\psi\gamma_0$ and of $\psi\gamma_0\tilde\psi$ are a fixed reference pair of the right action, not an observer. A change of observer acts on the left and does not touch them. Any other pair $(L\gamma_0\tilde L,LJ\tilde L)$ with $L$ orthochronous gives an equivalent equation via $\psi\mapsto\psi\tilde L$, with the same current. The sign of $\psi\tilde\psi$ (β = 0 or π) is the sign of $p$ against the future cone (rv·M_geo·11)." Keep INP-007 (Maxwell charges: there $\gamma_0$ is an observer, correctly) and the time-reversal half of INP-019 (a reflection $x\mapsto-e_txe_t$ does pick a timelike vector). The (complex) input $J$ becomes: "a complex structure on the right; all unit simple spatial bivectors are conjugate under the right $\mathrm{Spin}(n-1)$ fixing $\gamma_0$ (for $n\ge4$), so the choice is a gauge, and only its existence ($n\ge3$, MAP-018) is a datum". New flags: input (time orientation) + checked (rv·M_geo·11). Cost: none; the free waves and identities checked by spin_selfcheck and dirac_matrix_check are unchanged. *Unsure*: at $n=3$ the sign of $J$ is an orientation of the spatial plane, not a gauge.

**P5 (B5).** NUL-001 (and S12.1, MAP-028): "In the chart $ds^2=T\,dv^2+2\,dv\,dx$ (time +1, $x=r$) the null lines $v=$ const are future-directed outgoing, so $v$ is retarded time (as in null_selfcheck S3.4, $v=t-\bar r$). The surface $T=0$ of this chart is the past (white-hole) horizon, where $\xi\cdot\nabla\xi=-\kappa\xi$. In the advanced chart $T\,dv^2-2\,dv\,dx$ the same $\xi$ on the future horizon satisfies $\xi\cdot\nabla\xi=+\kappa\xi$, the textbook form. $\kappa=\frac12\,dT/dx$ in both: 1/6, 1/8, −1/2 (inner horizon), 0 (extremal), 3/10." New flag: standard (surface gravity; pointer, source unread) + checked (rv·M_geo·7, null_selfcheck S12.1). Cost: none.

**P6 (B6).** ATL-008: "Cl(1,2) ≅ M₂(ℂ) is also the even subalgebra of Cl(1,3). The unit even versors of Cl(1,3) form Spin⁺(1,3) ≅ SL(2,ℂ); inside Cl(1,2) they are $\{x: x\bar x=1\}$ (Clifford conjugation of Cl(1,2)). The unit even versors of Cl(1,2) itself form Spin(1,2) ≅ SL(2,ℝ)." New flag: standard + checked (rv·M_geo·12). Cost: none.

**P7 (B7).** LAB-006: "(4, −2, −2) in units of −M/(2r³), i.e. (−2, 1, 1)M/r³ on the complex bivectors (−2 on the radial pair e_t e_r, I e_t e_r)". Flag unchanged (gtg_check S10, G8). Cost: none.

**P8 (B8).** LAB-018: "the clock is the Brown (Arf–Brown–Kervaire) invariant of the $\mathbb Z_4$ enhancement $w=\pi+2Q$ of the dot product. $(V,\cdot)$ is $H_1(\#^n\mathbb{RP}^2;\mathbb Z_2)$ with its intersection form, $w$ is a Pin⁻ structure (Kirby–Taylor Thm 3.2) and the clock is its class in $\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$ (KT Lemma 3.6; Debray–Gunningham Thm 3.15). $Cl(1,0)$ and $Cl(0,1)$ are $\mathbb{RP}^2$ with its two Pin⁻ structures. The mirror is the twist by $w_1$ (rv·M_geo·2–4)." New flag: standard + checked. QD2's first question is answered; its second (the same $\mathbb Z_8$ as signature mod 8 of an even lattice) stays as core·B13 has it. Conventions row 11 can add: "on the reflection torus of the frame the mirror exchanges the Pin⁺ obstruction $w_2$ and the Pin⁻ obstruction $w_2+w_1^2$ (rv·M_geo·1)". Cost: none; two sources are added.

**P9 (optional upgrade, from D3).** S12/J8 verdict "reading the energy trio as the trio of the extra generator of step 11 is ours (analogy)". It can read: "the same three Klein geometries: Fock's projection carries Kepler orbits of energy E < 0, 0, > 0 to geodesics of S³, ℝ³, H³ (rv·M_geo·17); the Lie algebras agree (core·B16)". New flag: checked; Fock/Moser as pointer until read. Cost: one source to read.

## 6. Discoveries to explore

**D1. The cell as a Pin⁻ surface: which Atlas theorems are mapping-class statements?**
- *Question.* Is $\mathrm{Aut}(V,Q,\pi)$ (core·B12) the image of the Pin⁻ mapping class group of $N_n=\#^n\mathbb{RP}^2$ in $O(H_1;\mathbb Z_2)$? Equivalently, are Pin⁻ structures on $N_n$ up to diffeomorphism classified by the clock? The same question extends to T9 ($O(q)$ of $E_n/2E_n$), T11 (polar spaces of $Q$) and T14 (doubly-even codes as Lagrangians on which $w=0$, i.e. algebraic null-bordisms of the Pin⁻ structure, existing iff ABK $=0$ iff $8\mid n$).
- *Why it does not fit yet.* The identification is exact at the level of $(V,w)$ (L3). The Atlas has no surface, and "isometry of $(V,w)$" equals "diffeomorphism class" only if the mapping class group surjects onto $O(V,\cdot)$. I am unsure of that statement for non-orientable surfaces and did not read a source.
- *Smallest decisive computation.* Write down the homology actions of the standard generators: Dehn twists about two-sided curves, which act as transvections in even classes, and crosscap transpositions or slides. Check that they generate $O(\mathbb F_2^n,\cdot)$ (orders $|O|$ computable for $n\le8$).
- *First computation done.* `rv·M_geo·3` uses exactly even transvections and coordinate transpositions; their orbits on the $2^n$ enhancements are the ABK classes for $n\le8$. If every even class is represented by a two-sided simple closed curve (*unsure*), this already gives "Pin⁻ structures on $N_n$ up to diffeomorphism ↔ clock" for $n\le8$.
- *Outcomes.* If yes, core·B6c, B12 and T14(4) become theorems about Pin⁻ surfaces and bordism (T14(4) reads "a Pin⁻ surface bounds algebraically iff ABK = 0"). If no, the Atlas's isomorphism classes are coarser than diffeomorphism classes, and the difference is a new invariant.

**D2. Null generators as boundary circles (a reading of QA1, QC1).**
- *Question.* Does $Cl(p,q,r)$ correspond to a Pin⁻ surface $N_{p+q}$ with $r+1$ boundary circles carrying the bounding (Neveu–Schwarz) spin structure? Under this correspondence, would the forbidden value $w=2$ on a radical class be a non-bounding (Ramond) boundary, where the ABK Gauss sum vanishes?
- *Why it does not fit yet.* The null generator is an algebra element with $e^2=0$; the boundary circle carries no algebra. They agree only through the Gauss sum: the radical classes of a surface with boundary sit in the radical of the intersection form, and the Atlas's null bits sit in the radical with $w=0$ (`rv·M_geo·5`).
- *Smallest decisive computation.* Compute $H_1(N_{p+q}\setminus(r+1)\,\text{discs};\mathbb Z_2)$, its degenerate intersection form, and the value of the enhancement on each boundary class for each boundary spin structure (Kirby–Taylor treat surfaces with boundary; not read here). Compare the Gauss sum with $2^rG$ or $0$.
- *Outcomes.* If they match, the "second coordinate for r" asked in QA1/QC1 is a boundary datum: $r$ counts NS boundary circles, and the Ramond option is the case the Atlas's convention excludes. The graded Brauer group with $r$ would then be a relative Pin⁻ bordism group (the Arf–Brown TQFT of DG on surfaces with boundary). If they do not match, the null part needs a different topological home.
- *First computation done.* The algebraic side, `rv·M_geo·5`.

**D3. The Kepler trio is the step-11 trio (beyond analogy).**
- *Question.* Is the isomorphism of core·B16 (Kepler $\mathfrak{so}(4),\mathfrak e(3),\mathfrak{so}(3,1)$ against the extra-generator algebras) induced by an equivariant map from Kepler phase space to the unit cotangent bundles of $S^3,\mathbb R^3,H^3$, i.e. Fock's projection and Moser's regularisation (pointers, sources unread)?
- *Why it does not fit in the Atlas.* The Atlas compares Lie algebras only and tags the geometric identification "ours (analogy)" (S12).
- *First computation done.* `rv·M_geo·17`: exact hodographs at $e=3/5,1,5/3$. Under Fock's map the images are a great circle of $S^3$ (rank 2, $|\xi|=1$), a geodesic of $H^3$ (rank 2, $\xi_0^2-|\xi|^2=1$) and a line of $\mathbb R^3$ (affine rank 1). The control with a wrong $p_0$ is not planar.
- *Smallest decisive remaining computation.* Push the Poisson algebra of $(L,A)$ (Runge–Lenz) through Fock's map and check that it becomes the Killing algebra of the target, with the sign $\varepsilon=-s$ of core·B16.
- *Outcomes.* If yes, S12/J8 can be checked (P9) and the Kepler problem becomes a fourth calibration of step 11. If no, only the orbit geometry matches.

**D4. Is the spring operator a Kähler–Dirac operator? (SPR-004, open)**
- *Question.* L14 shows that on one cube $D=\sum L_{e_i}$ is the ABS symbol $\sigma(v)$ at a single $v$, not a differential operator. Assembled over $(\mathbb Z_L)^n$ with the bit-rule signs as Kogut–Susskind phases, does it converge to $2^{\lfloor n/2\rfloor}$ tastes of the continuum Dirac operator (pointer: staggered fermions / Dirac–Kähler, sources unread)?
- *Why it does not fit.* The Atlas's operator lives on one cube, while a Dirac operator needs a lattice of cubes and a derivative.
- *Smallest decisive computation.* Build $D=\sum_\mu\eta_\mu(x)(T_\mu-T_\mu^{-1})/2$ on $(\mathbb Z_L)^n$ for $n=2,4$ and $L=8$, with $\eta_\mu(x)=(-1)^{\sum_{\nu<\mu}x_\nu}$, the Jordan–Wigner sign of the bit rule. Count the near-zero modes and check $D^2$ against $-\sum_\mu\nabla_\mu^2$ at small momenta.
- *Outcomes.* $2^n$ zero modes grouped into $2^{n/2}$ tastes would make "the Dirac operator on the demicube in a stronger sense" a standard fact (Kähler–Dirac). Anything else would be a new statement.

**D5. Degenerate symbols, dual hyperbolicity, and the two "label 0"s.**
- *Question.* For a principal polynomial with $r\ge1$, weakly hyperbolic by P3, does Schuller's dual polynomial exist, so that his second and third conditions (dual hyperbolic, energy-distinguishing; LNS-*) can even be stated?
- *Why it does not fit.* The gradient map $k\mapsto DP(k)$ on the null cone of $P=k_0^2-k_1^2-k_2^2$ on $\mathbb R^4$ lands in $\{v_3=0\}$, a cone of codimension 2. A degenerate symbol has no dual quadric on $V$: its dual is a co-metric degenerate in the other direction (Carroll ↔ Galilei). This is the same duality that separates the Atlas's two placements of a null generator, which share one algebra $Cl(0,d,1)$ with motors $\mathfrak e(d)$ (L12, L13):
  - on a null hypersurface the radical is a vector (Carrollian tangent space);
  - in PGA it is the plane at infinity, a covector (dual Euclidean structure).
- *Smallest decisive computation.* Apply Schuller's definition of the dual polynomial (Düll et al. §II; not read here) to $P=\operatorname{diag}(1,-1,-1,0)$, and decide whether condition 2 fails or is undefined. On the algebra side, check whether the Frobenius complement $e_a\mapsto e_{a\oplus F}$ (T3) intertwines the vector-degenerate and covector-degenerate readings of $Cl(0,d,1)$ (Gunn's duality; pointer).
- *Outcomes.* If condition 2 fails, null generators are excluded from Schuller's admissible geometries by condition 2 and not by condition 1. This would sharpen LNS-002's "Domain r = 0" and show the Atlas's null part is invisible to gravitational closure. If the complement intertwines the two readings, the Atlas's single "label 0" is one object seen through Poincaré duality.

## 7. Code

All runs are in my clone with `python3` (Python 3, numpy 2.5.3, scipy 1.18.1; sympy not installed and not needed). The `-I` flag is used where the script is self-contained. The researchers' scripts import sibling modules (`clC`, `f2lib`) and were run without `-I`. Logs are in `out/M_geo_code/logs/`.

**Provided scripts run (all pass):**

| script | command | time | result line |
|---|---|---|---|
| core | `python3 -I selfcheck/core_check.py` | 5.2 s | "25/25 core checks hold. ALL CORE CHECKS PASS" |
| T1–T20 | `python3 researchers_checks/check_T#.py` | 0.3–89 s (T11 89 s) | T13 "ALL 302 CHECKS PASSED"; T17 "12009 of 12009 assertions hold"; T18 "2023 of 2023"; T16 "391 of 391"; T19 "8881 of 8881"; T20 "2015 of 2015"; T1–T8, T9, T10, T11, T12, T14, T15 all OK |
| pages | `python3 selfcheck/<name>.py` for projective(_matrix), gravity(_matrix), null, mirrors, shapes, gosset, spin, forque, spring, pgadyn, maxwell, equations, dirac_matrix | 0.2–14.8 s | e.g. null "64 of 64 computed checks pass"; spin "604/604"; pgadyn "110/110"; forque "41 rows: 27 agree exactly, 9 … 5 not checked" |
| steps15_17, reports | gtg_check, labels_check, groups_check, fibre_check, bridge_check, cat_check | 4.5–24.7 s | gtg "ALL GTG/RDK CHECKS PASS"; fibre "35 ok, 0 failed"; bridge "77 ok, 0 failed" |

**Created** (each has the three-line licence header copied from `selfcheck/core_check.py`, one ok/FAIL line per check id, exit code 1 on failure, and prints counterexamples):

| script | command | time | result |
|---|---|---|---|
| `review2/M_geo/geo_pin.py` (rv·M_geo·1–6) | `python3 -I review2/M_geo/geo_pin.py` | 9.1 s | "ALL 6 of 6 geo_pin checks hold" |
| `review2/M_geo/geo_lorentz.py` (rv·M_geo·7–12) | `python3 -I review2/M_geo/geo_lorentz.py` | 0.3 s | "ALL 6 of 6 geo_lorentz checks hold" |
| `review2/M_geo/geo_cartan.py` (rv·M_geo·13–16; numpy) | `python3 -I review2/M_geo/geo_cartan.py` | 0.4 s | "ALL 4 of 4 geo_cartan checks hold" |
| `review2/M_geo/geo_kepler.py` (rv·M_geo·17) | `python3 -I review2/M_geo/geo_kepler.py` | 0.03 s | "ALL 1 of 1 geo_kepler checks hold" |

What each check id asserts (short form):
1. $Q=\sigma_2+|a\wedge N|$ (Pin extension class), $n\le9$; commutators of $\Gamma_n$ = polar form.
2. $w$ is a $\mathbb Z_4$ enhancement and the clock is ABK; RP² gives ±1.
3. The enhancements are exactly the $w_\varepsilon$; the $O(\cdot)$-orbits are the ABK classes, $n\le8$.
4. Twisting formula $\beta(w+2a\cdot)=\beta(w)-2w(a)$; mirror = twist by $w_1$; $\beta\equiv w(1..1)\bmod4$.
5. Null bits: counterexamples to the literal $w$; the pulled-back form gives $2^rG$; $w=2$ on the radical gives 0.
6. Bit-rule types of $Cl(0,k)$ → ABS cokernels $=KO^{-k}(\mathrm{pt})$.
7. $\xi\cdot\nabla\xi=-c\kappa\xi$ and the branch of each chart.
8. Hyperbolicity for $(s,t,r)$.
9. Horizon bivectors = null little group, $n=3..7$; paired versus radical null.
10. Totally null plane in $Cl(2,2)$; null rotation Jordan type.
11. Dirac right reference and time orientation.
12. Spin(1,2) versus SL(2,ℂ) in $Cl(1,2)$.
13. Klein pairs, symmetric involution = mirror iff $s\ne0$.
14. The invariant forms of $\mathfrak e(3)$; Klein form = top-blade pairing.
15. Lie–Poisson conservation.
16. Koszul/ABS operator on the labels.
17. Fock projection of Kepler hodographs.

The scripts were rerun with identical output (fixed seeds). One correction was made during the work. The first version of check 3 used transvections in odd vectors, which are not isometries of the dot product in characteristic 2. The script now uses even vectors and asserts that every generator preserves the dot product.

## 8. Sources

**Read** (the relevant part fetched and read in this session):
- A. Debray, S. Gunningham, *The Arf–Brown TQFT of Pin⁻ surfaces*, arXiv:1803.11183: Def. 3.9 and eq. 3.11 ($\mathbb Z_4$ enhancement), Def. 3.13 and eq. 3.14 (Arf–Brown invariant as a normalised Gauss sum), Thm 3.12 (Pin⁻ structures ↔ enhancements, attributed to Kirby–Taylor), Thm 3.15 ($\Omega_2^{\mathrm{Pin}^-}\cong\mathbb Z_8$), Ex. 3.17 (RP², $e^{\pm2\pi i/8}$). The paper treats closed surfaces only.
- R. Kirby, L. Taylor, *Pin structures on low-dimensional manifolds* (copy on A. Ranicki's page, webhomes.maths.ed.ac.uk/~v1ranick/papers/kirbytaylorpin.pdf): the Pin± conventions ($vw+wv=\mp2(v,w)$ for Pin⁻/Pin⁺), Lemma 1.3 (obstructions $w_2$ and $w_2+w_1^2$), Thm 3.2 (Pin⁻ structures on surfaces ↔ enhancements), Lemma 3.6 ($\Omega_2^{\mathrm{Pin}^-}=\mathbb Z/8$ by the Brown invariant). *Unsure*: my read of Lemma 3.7 gave $\beta(q_a)=\beta(q)+2q(a)$, while my exact computation in my convention $q_a=q+2a\cdot$ gives $-2q(a)$ (`rv·M_geo·4`); I rely only on the computation.
- D. K. Wise, *MacDowell–Mansouri gravity and Cartan geometry*, arXiv:gr-qc/0611154 (ar5iv HTML), §1: dS ↔ SO(4,1), Λ > 0; AdS ↔ SO(3,2), Λ < 0; $A=\omega+e/\ell$; $F=(R-\frac{\Lambda}{3}e\wedge e)+d_\omega e$.
- The Atlas pack itself: spec, READING_GUIDE, README, RELEASE_NOTES, theorems_questions_sources, needs_inputs, the claims table (ATL, GEN, PAG, LAB, EQN, SHP, GOS, CPL, GRV, MAT, MIR, PRJ, YM, NUL, FRQ, SPN, SPR, RIG in full; MAP, RSN, INP, LNS, LNB, LNC by search), copy_en (projective, gravity, null, conventions glossary, spin by search), and the fibre_check output.

**Pointers, sources unread** (not relied on): Atiyah–Bott–Shapiro, *Clifford modules* (1964); Lawson–Michelsohn, *Spin Geometry* (the $Cl_k$-linear Dirac operator); Wall, graded Brauer groups (1964); Brown's invariant (original paper); Gårding (1951); Wald, *General Relativity* (surface gravity sign); Fock (1935) and Moser (1970) on the Kepler problem; Duval–Gibbons–Horváthy (Carroll structures); Kogut–Susskind and Becher–Joos (staggered and Kähler–Dirac fermions); Huang (2019, signed hypercube); Gunn (PGA duality); the mapping class group of non-orientable surfaces and its action on $H_1$; Hestenes' papers (I rely on the Atlas's equation and my computation only); Düll–Schuller–Stritzelberger–Wolz §II (dual polynomial).

## 9. Limits

- I did not read the Furey pages in depth, the category report beyond the Frobenius and clock parts, the Pumplün report, or the Baez report beyond the Kepler items. My dictionary rows for them are one line each.
- I did not read every LNS, LNB and LNC claim (388 statements). I searched them for geometric keywords (hyperbolic, fibre, base, Cartan, conformal, Kepler, Weyl, Pin, spin) and read the hits.
- No global computation was made: there are no manifolds, bundles, indices or spin structures as global objects. All my geometric identifications are pointwise or finite. L6's link to the $Cl_k$-linear Dirac operator and L5's ABS identification rest on unread sources plus my finite computation of the cokernels.
- *Unsure*:
  - whether the mapping class group of $N_n$ surjects onto $O(H_1;\mathbb Z_2,\cdot)$ (D1);
  - how Kirby–Taylor treat surfaces with boundary (D2);
  - Kirby–Taylor's sign in Lemma 3.7;
  - whether the right-$J$ choice is a gauge at $n=3$ (P4).
- `rv·M_geo·8` proves "no hyperbolic direction" by random sampling of $h$ with explicit integer witnesses, not by a proof in the script. The two-line proof is in P3.
- `rv·M_geo·15` checks conservation laws, which hold for either sign of the coadjoint flow. It does not fix the sign convention of the forque equation; that is the Atlas's forque_selfcheck.
- I did not run `run_tests.sh`, `build.sh`, any node test, or the sabotage harness (`run_mutations.py`), as the spec asks.
