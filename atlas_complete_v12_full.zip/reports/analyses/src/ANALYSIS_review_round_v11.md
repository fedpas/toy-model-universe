# Review round on Atlas v11: analysis of the two merged reports (7 Oct 2026)

Files: `MERGED_physics.md` (all-knowing physicist, Fable, merging the string theorist, the solid-state experimentalist and his own report), `MERGED_math.md` (all-knowing mathematician, Fable, merging the geometer, the algebraist, the category theorist and his own report), the seven specialist reports, and all code (`code/`). The two merges were written without sight of each other, so where they agree they agree independently. Both used only v11 and the provided scripts, updated or new scripts, and sources they fetched.

## 1. Verdict

1. **The core of the Atlas holds.** Seven reviewers, 161 new checks, every provided script rerun: no wrong computation anywhere. Every "break" is a scope, wording, status or missing-link item.
2. **The clock has a standard home, and the Atlas under-claims it.** The cell's $\mathbb Z_4$-valued form $w=\pi+2Q$ is a quadratic enhancement of the dot product on $\mathbb F_2^n$; its Gauss sum is the Brown (Arf–Brown–Kervaire) invariant, the class in $\Omega_2^{Pin^-}=\mathbb Z_8$, the Brauer–Wall class, the signature mod 8 of the frame lattice $I_{p,q}$, and (physics side) the Fidkowski–Kitaev $\mathbb Z_8$ of a Majorana edge. All seven reviewers reach it. LAB-018 ("ours, pointers unread") can become *standard + checked*; QD2 is answered.
3. **The one real scope break is the null generator.** "The cell is $(V,Q,\pi)$" and "the clock is the Brown invariant of $\pi+2Q$" hold for $r=0$ only. $Cl(1,0)$ and $Cl(0,0,1)$ have the same triple; the literal Gauss sum of $Cl(0,0,1)$ is $1+i$ (clock 1; the Atlas says 0). The code is right, the sentence is not. The natural patch (math, 4 of 4) agrees with the physics side's closure picture: the clock of $Cl(p,q,r)$ is that of its quotient $Cl(p,q)$, which equals that of the mother cell $Cl(p+r,q+r)$ (physics: the $*$-closure). "Weight 0 on a null bit" stops being a convention and becomes a theorem.
4. **The shapes page is a statement about one lattice.** $E_n=k^\perp\subset I_{1,n}$ with $k=(3;-1^n)$ characteristic; $\det E_n=k\cdot k=9-n\equiv$ clock of $Cl(1,n)$ (van der Blij); $E_n/2E_n$ = the even labels of $Cl(1,n)$. This explains T9 (a) and the "shared 8" of T10 (7), and it is the same fact as the del Pezzo reading (physics: $K_{dP_n}$ is characteristic). The stop at $E_8$ is $k$ turning null, not period 8: T10 (7) stands.
5. **Where the Atlas overclaims** (wording): "the triple is frame-free / loses nothing" (it forgets $\min(p,q)$, hence hyperbolicity: $Cl(1,4)$ and $Cl(5,0)$ share a triple; it forgets the reversion: $Cl(4,0)\cong Cl(0,4)$ as superalgebras, not with reversions); T17 (b) contradicts its own next clause and its own script; T14's "not in print" is in print (Wood 1993 §5); F3's "Jacobi holds for all modes" is automatic.
6. **What the physics side adds** that the algebra cannot: the signs listed as open inputs are fixed once one action is admitted; Calibration 1 never names the constitutive relation or the units; the signed cube is Majorana/π-flux hopping, not a Dirac operator; Schuller's Witt$\otimes A_\varepsilon$ is Vir⊕Vir / BMS$_3$ / Witt$\otimes\mathbb C$; Furey's partition is not a Fidkowski–Kitaev level structure; the 25 role names have no counterpart.

## 2. Where the two independent merges agree

| finding | physics merge | math merge | my reading |
|---|---|---|---|
| Clock = Arf–Brown of a Pin⁻ enhancement, $\Omega_2^{Pin^-}=\mathbb Z_8$ | MB2; sources DG, KT, Taylor, KTTW read | B11; DG, KT, Taylor, Wood read | strong: same sources, two readers, plus my check L2 (modulus $2^{n/2}$, phase $(p-q)\pi/4$, $n\le7$) |
| Mirror = reversed Pin structure = super-opposite = $T\mapsto TP$ | dictionary | dictionary, "on the nose" | strong |
| Null generator: absent from the tenfold way, present as $*$-closure $Cl(p+r,q+r)$ / superpoint / Carroll radical | MB3 | B1, D1: quotient, mother cell $Cl(p+r,q+r)$, base change to $\Lambda(\mathbb R^r)$ | strong: the same mother cell reached from two sides |
| $E_n$ and the lattice $I_{1,n}$ (characteristic vector, $9-n$) | MD5: del Pezzo, `rv·P_str·25` | D2: van der Blij, `rv·M_all·17–19`, `rv·merge·6–7` | strong; the single most valuable cross-field link |
| "frame-free / loses nothing" overclaimed | MB1 (forgets $\min(p,q)$, type, $D$) | B5 (forgets reversion) | strong, two different things the triple forgets |
| Role names have no counterpart | MB11 | row "25 role names: none" | agree; no computation can decide it |
| Three generations do not come from the labels | H9, RSN-004 | B13: order-3 label automorphisms exist but permute colours | agree |
| Furey's axes / partition are inputs | `rv·P_ss·10` (not an FK structure) | `rv·merge·8` (axes = one $S_8$-orbit, a gauge) | complementary |
| Spring operator: $D^2=n$ is the Clifford relation | MB5 | D11 (ABS symbol at $v=(1,\dots,1)$) | agree; physics already answers D11's "tastes" question: $2^{\lceil n/2\rceil}$ (`rv·P_ss·18`) |

## 3. Tensions and open reconciliations

1. **The Dirac reference $\gamma_0$.** Physics (MB10): the involution and "the observer's time direction" are one input. Math (B17): $\gamma_0$ and $J$ sit on the right as a fixed reference, observers act on the left; the datum is a time orientation. Compatible, but the two patched wordings differ. Decide one line per step: "time orientation (a right reference $(\gamma_0,J)$); the observer acts on the left". Math flags *unsure* at $n=3$.
2. **The two 1344's.** Physics (MD5) asks whether the stabiliser of $A_1^7\subset E_7$ matches the 168-element collineation group behind $|\mathrm{Aut}[8,4,4]|=1344=8\cdot168$. Math (D4): the octonion label symmetry group $2^3\cdot GL(3,2)$ is non-split of order 1344; the Hamming-code automorphism group is the split $2^3:GL(3,2)$. Same order, different groups. Any statement joining Furey's axes to octonion automorphisms must say which.
3. **T18 (f).** The math merge's B3 asks for "$(r=0)$" in four places. Three claims (LNS-002, LNS-060, LNS-116) already carry "$r=0$"; the theorem statement, PAG-011, LNS-052 and Conventions row 5 say "signature", which already implies a non-degenerate form. The edit is one parenthesis, and the $r\ge1$ result (hyperbolic iff $s=1$ or $t=1$, never strictly) is a useful addition, not a correction.
4. **A row to delete.** The math change list asks `researchers_checks/README.md` to say "run without `-I`". The shipped README already says `cd researchers_checks && python3 check_T1.py`. The `-I` failures came from my reading guide, not from the package. No fix needed.

## 4. What I discount

- **Counts of breaks** (17 physics, 23 math) are inflated by minor items (a missing unit on the Weyl eigenvalues, "unit" for "norm 1"). The consequential set is about twelve (§5).
- **Checks that cannot fail**: `rv·P_str·3`, `·4`, `·22`, `rv·P_ss·26`, `rv·P_all·15`, `rv·M_geo·15`, `rv·M_cat·3`, `rv·M_all·14`, and the Atlas's own `bridge·C1`. The merges flag them; none carries a claim alone.
- **Hull's lists** (M, IIA, IIB signatures from the even part) were produced from criteria the reviewer chose (32 real supercharges, chirality, real self-dual 5-forms); they are a dictionary, not evidence.
- **Speculative discoveries**: the K3/F-theory reading of $II_{2,18}$, the 16-fold way as a square root of the clock. Pointers unread.
- **Sources read through abstracts or summary pages** (KPT, Bagchi 2013, Witten, DMNO, Albuquerque–Majid): the merges downgraded them; nothing in either top ten rests on them alone. Wang and Ladkani (T8 closed) are read at statement level and are over an algebraically closed field; the Atlas's T8 should say over which field it closes.
- **Convergence is evidence, not proof**: all reviewers share one text and similar training. Only scripts prove.

## 5. What must change (the union of the two "needed" lists, twelve groups)

| # | statement ids | change | source |
|---|---|---|---|
| 1 | README, RELEASE_NOTES, Conventions row 12, LAB-017, core·B3 text, needs_inputs `clock`/`category` | scope the cell and the clock to $r=0$; for $r\ge1$ the cell is $(V,Q,\pi,N)$; the clock is that of the quotient = of the mother cell; "weight 0" becomes a theorem | math B1 (4/4), physics MB3 |
| 2 | Conventions row 13/12, H3 | the triple is the graded Brauer datum, attached to a frame; it forgets $\min(p,q)$, the ungraded type, $D$, the reversion | physics MB1, math B5 |
| 3 | GEN-009, ATL-023 | "three cells of row 8 with the same algebra" → three with clock 0; five with $M_{16}(\mathbb R)$ | physics MB1 (`rv·P_str·5`) |
| 4 | LAB-018, QD2, LAB-019, core·B6/B6c text, PAG-020, Gosset "resemblance" | *standard + checked*: Brown/Pin⁻/Brauer–Wall/lattice signature; "checked $n\le5$" → every $n$ (Wood 1993, block isometry) | both |
| 5 | QC3, H5, LAB-007, glossary "null" | the null generator's homes; one element, two algebras (horizon null and its transverse partner) | physics MB3, `rv·MG·3–4` |
| 6 | T17 (b) | null rotation only with $\min(p,q)=1$; totally null planes first in $Cl(2,2)$ | math B2, my check L8 |
| 7 | T18 (f), Conventions row 5 | add "$r=0$" to the theorem; with $r\ge1$ hyperbolic iff $s=1$ or $t=1$, never strictly | math B3 (small) |
| 8 | T14 note, QT7 | withdraw "not in print": Wood 1993 §5 | math B4 |
| 9 | Schuller F3, bridge·C1; LNS-014 | the Jacobi check is a regression test; the identification with Vir⊕Vir / BMS$_3$ / Witt$\otimes\mathbb C$ is standard | math B6, physics MB6 |
| 10 | CPL-005, MAT-005, GRV-011, INP-027/028/041, CPL-009 | one action gives both equations with one $e$; positivity fixes the relative sign. **Decision for you**: admit "an action" as one named input | physics MB4 |
| 11 | SPR-004, MAP-026 | the signed cube is Majorana/π-flux hopping; the staggered Dirac operator vanishes on the period-2 cube; Dirac points need the translations (input) | physics MB5 |
| 12 | needs_inputs maxwell/views | add the constitutive relation and the units as inputs | physics MB9 |

The remaining items (30 or so *useful* rows in the two §8 tables) are sharper wordings, citations and new statements; the new check scripts worth adding are listed in each merged report's §8.

## 6. Discoveries worth running first

Ranked by how decisive and how cheap the next computation is.

1. **What is a degenerate cell in a classification?** (math D1, physics MD3; QA1/QC1). Is $BW(\Lambda(\mathbb R^r))\to BW(\mathbb R)$ an isomorphism? Decisive: graded $HH^2$ of $Cl(1,0)$, $Cl(0,1)$, $M_{1|1}(\mathbb R)$ (a linear system of size $\le16^2$). $0$ means the clock is the complete invariant and "$r$ is absent from the clock" is a theorem; nonzero means a genuine second coordinate. Expected 0, no source.
2. **The clock as a junction observable** (physics MD1). Exact diagonalisation of two BDI Majorana stacks ($W=8$ against $0,4,2$; 32 Majoranas, dimension $2^{16}$, sparse) with a $T$-invariant junction interaction. Degeneracy a function of $W-W'$ mod 8 makes the clock measurable; otherwise the dictionary is edge-only. Feasible here.
3. **The reversion invariant** (math D3). Classify $(Cl(p,q),\pi,\tilde{\ })$: sits strictly between the clock and $(p,q)$. Exhaustive for $n\le10$ over $e_i\mapsto\pm e_{\sigma(i)}\omega^k$; cheap.
4. **Inputs as torsors, and the action as the single input** (math D5, physics MD4). Per `input` line: one orbit of a group the algebra supplies (gauge) or several (datum). Then see how many of the 98 `INP` lines survive an action. Mostly orbit counts and Noether-identity checks.
5. **The $E_n$ ladder, finished** (math D2, physics MD5): $W(E_n)\bmod2=O(q)$ beyond $n=12$ (QT6); the two 1344's; Cartan's quartic on Furey's seven blocks.
6. **Furey's commutant** (math D4): the commutant of the 12-dimensional gauge algebra in $M_{16}(\mathbb R)$, its order-3 elements, their action on the 20 cells. Only block phases would refute H9 inside her model.
7. **Kepler through Fock's map** (math D6): turns the Kepler trio "analogy" into a checked fourth calibration of step 11.

## 7. Blind spots (no reviewer reached, or only superficially)

The translation matrix (131 rows) and QE4; the Pumplün report; steps 14 and 16 (Forque, rigid bodies) beyond their scripts; the Baez $E_6$/Albert chapter and the Jordan-pair chapters; the gravity field equations and cosmology parts of LDG; Furey's dynamics beyond quantum numbers; the Map, Ask, label bench, replication kit, Italian slots. Pin± as symmetry classes of neutral fermions and odd $n$ in the Fidkowski–Kitaev dictionary are open in the physics merge.

## 8. What I did

- Read both merged reports in full; did not read the seven specialist reports.
- Wrote `lead_checks.py` from the bit rule alone (no reviewer code): L1 $Cl(1,0)$ and $Cl(0,0,1)$ share a triple; L2 the Gauss sum of $w$ has modulus $2^{n/2}$ and phase $(p-q)\pi/4$ for every cell $n\le7$; L3 the literal sum for $Cl(0,0,1)$ is $1+i$; L4 exactly 5 collisions with a null generator for $n\le3$ (the merge's number; the category theorist's 7 does not hold); L5 $Cl(1,4)$, $Cl(5,0)$ share $(n,p-q \bmod 8)$; L6 $Cl(0,2,1)$ and $Cl(1,2)$ do not share a triple; L7 $k=(3;-1^n)$ is characteristic with $k\cdot k=9-n\equiv1-n$, $n\le12$; L8 a totally null plane in $Cl(2,2)$ via the bit-rule product ($B^2=0$), none in $Cl(1,3)$. All pass.
- Reran `merge_checks.py` (8 of 8) and the two physics merge scripts (4 of 4).
- Confirmed in the Atlas text the wordings the reports quote: "frame-free" (Conventions row 12, H3), LAB-018 "pointers, sources unread", T14 "not in print", T17 (b), T18 (f), GEN-009, ATL-023.
- Not done by me: rerunning the 161 reviewer checks (the merges did, 78 of 78 and 83 of 83, with stated exceptions), fetching sources.

## 9. Proposed next step

Apply groups 1 to 9, 11 and 12 as a wording and status patch with the new scripts added as checks (a v11.1 or the head of v12); 10 needs your decision (admit an action as an input). Then run discoveries 1 to 3, the cheap decisive ones. I have changed nothing in the package.
