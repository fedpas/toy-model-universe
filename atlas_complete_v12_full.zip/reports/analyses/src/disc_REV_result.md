# Discovery REV: the cell with its reversion

## (a) The question

Classify the real Clifford algebras Cl(p,q) (no null generators, r = 0) as superalgebras with an anti-involution, up to isomorphism: two cells are identified when a grading-preserving algebra isomorphism carries the anti-involution of one onto that of the other. The main row is the reversion x ↦ x̃ (a blade of grade k gets (−1)^{k(k−1)/2}). Two further rows use the Clifford conjugation x̄ = α(x̃), with α the grade involution, and the dagger of Thm T15, e_a^† = e_a^{−1}. The range is every n = p + q ≤ 10. Wanted: the complete invariant, the list of collisions, the sentence for the core page, and the datum a cell card should show.

## (b) The result

The answer is yes and complete for every n ≤ 10. The complete invariant of (algebra, grading, reversion) is the cell triple, i.e. (n, p − q mod 8), together with the definiteness of the cell: positive definite (q = 0), negative definite (p = 0), or indefinite (p, q ≥ 1). Two cells with the same triple have isomorphic reversions iff they are equal or both indefinite.

The decision runs over all 65 cells with 1 ≤ n ≤ 10, and every pair of cells with the same triple is decided by one of two means:

- **An isomorphism.** A chain of block maps joins the pair. Each map is e′_i ↦ e_i ω_B for i in a block B of generators and e′_j ↦ e_j outside it, with ω_B the product of the generators in B. Each map is checked generator by generator, and on every label pair for n ≤ 7.
- **A separating invariant.** The trace forms ⟨x x̃⟩₀ and ⟨x α(x̃)⟩₀ separate the pair. ⟨x x̃⟩₀ is positive definite iff q = 0, and ⟨x α(x̃)⟩₀ iff p = 0.

No pair is both joined and separated.

Within one triple class, every pair of non-isomorphic cells involves a definite cell; there are 18 such pairs for n ≤ 10. Every pair of indefinite cells with the same triple is isomorphic; there are 16 such pairs for n ≤ 10, from n = 6 on.

The other two rows:

- **Clifford conjugation.** It gives the same partition, because α is fixed by the grading; only the roles of p and q in the positivity invariant are exchanged.
- **Dagger.** It is positive for every cell, and its partition is exactly the triple partition: the dagger forgets the definiteness that the reversion keeps.

The global maps e_i ↦ ±e_σ(i) ω^k on their own (permutations and the pseudoscalar map) are not enough: they find 3 of the 16 isomorphic pairs and miss the other 13, for instance Cl(5,3) ≅ Cl(1,7) at n = 8. The block maps with blocks of six generators are what is needed.

### Which generator maps are covered, and why the procedure is complete

- **Covered maps.** The script searches every block B of generators with |B| even, in every composition: k generators with square +1 and m with square −1, k + m even and at least 2. These are composed with permutations of the generators.
- **Validity of a map.** The images must be odd, pairwise anticommuting and independent over 𝔽₂. The anti-involution must act on each image f_i as it acts on the generator e′_i of the target. Together these imply, by the universal property, an isomorphism of superalgebras with anti-involution.
- **The global family reduces to two maps.** In the family e_i ↦ ±e_σ(i) ω^k with k varying from generator to generator, images with and without ω commute instead of anticommuting (n even). For n odd, ω is central and e_i ω is even. So that family reduces to the permutations and the single map e_i ↦ e_i ω.
- **The block family is sufficient, not exhaustive.** It is only a sufficient family of isomorphisms; the decision becomes complete because the positivity invariants separate every pair that the block family does not join.
- **What the trace forms add.** The finer signature of the trace forms on the four pieces (even or odd, fixed or anti-fixed by τ) equals the counts of the labels a with |a| mod 4 fixed and ∏_{i∈a} ε_i = ±1. Their generating function is (1+z)^p (1−z)^q evaluated at z^4 = 1. Those numbers are functions of n, p − q mod 8, [p = 0] and [q = 0], so they add nothing beyond the two positivity bits.

### The argument for every n (ours, not run beyond n = 10)

1. **The positivity of ⟨x x̃⟩₀ and of ⟨x α(x̃)⟩₀ is an invariant for every n.** Both forms are diagonal on blades, with entries ∏_{i∈a} ε_i and ∏_{i∈a} (−ε_i).
2. **The block move is valid for every n ≥ 6.** Take a block B of six generators with five squares +1 and one square −1. The images e_i ω_B have grade 5, so they are odd and fixed by the reversion. They anticommute with each other, because ω_B anticommutes with every generator of B, and with every generator outside B, because ω_B commutes with those. Their squares are ε_i ∏_B ε = −ε_i, since ω_B² = −∏_B ε. So the map sends Cl(p − 4, q + 4) isomorphically onto Cl(p, q), reversion included.
3. **Indefinite cells are connected.** For two indefinite cells (p, q) and (p′, q′) with p > p′ and p ≡ p′ mod 4, one has p ≥ 5 and q ≥ 1. A move lands on (p − 4, q + 4), which is still indefinite; repeating it reaches (p′, q′).

## (c) The checks: statements the Atlas can carry

**disc·REV1** (invariants). For every cell with n ≤ 10, the forms t(x) = ⟨x x̃⟩₀ and t′(x) = ⟨x α(x̃)⟩₀ are diagonal on the blades, with entries ∏_{i∈a} ε_i and ∏_{i∈a} (−ε_i). t is positive definite iff q = 0, and t′ iff p = 0. Both are invariants of (algebra, grading, reversion). The reversion is a graded anti-involution on every label pair for n ≤ 7.
- Status: checked.
- Adds: the involution datum that the triple of CONV row 12 does not carry, and the reason behind core·B17 (rotors and norms use the reversion).

**disc·REV2** (block maps). For every cell with p ≥ 5, q ≥ 1 and n ≤ 10, the block of five generators with square +1 and one with square −1 gives images e_i ω_B (and e_j outside the block). They are odd, fixed by the reversion, pairwise anticommuting and independent, with squares of signature (p − 4, q + 4). So Cl(p − 4, q + 4) ≅ Cl(p, q) as superalgebras with reversion.
- Status: checked (15 cells; the 3 cells with n ≤ 7 also on every label pair). The general-n validity is ours: the argument in (b).
- Corrects: the review report M_cat D1, which states identifications only at n ≡ 2 mod 4.

**disc·REV3** (classification, reversion). For n ≤ 10, two cells with the same triple (V, Q, π) have isomorphic reversions iff they are equal or both indefinite (p ≥ 1 and q ≥ 1).
- Status: checked for n ≤ 10; ours for every n (argument in (b)).
- Collision classes (same triple and isomorphic reversion):
  - n = 6: {(5,1), (1,5)}
  - n = 7: {(5,2), (1,6)}, {(6,1), (2,5)}
  - n = 8: {(5,3), (1,7)}, {(6,2), (2,6)}, {(7,1), (3,5)}
  - n = 9: {(5,4), (1,8)}, {(6,3), (2,7)}, {(7,2), (3,6)}, {(8,1), (4,5)}
  - n = 10: {(9,1), (5,5), (1,9)}, {(6,4), (2,8)}, {(7,3), (3,7)}, {(8,2), (4,6)}
- Same triple, reversions not isomorphic:
  - n = 4: (4,0) | (0,4)
  - n = 5: (4,1) | (0,5); (5,0) | (1,4)
  - n = 6: (4,2) | (0,6); (6,0) | (2,4)
  - n = 7: (4,3) | (0,7); (7,0) | (3,4)
  - n = 8: (8,0) | (4,4) | (0,8)
  - n = 9: (9,0) | {(5,4), (1,8)}; (0,9) | {(4,5), (8,1)}
  - n = 10: (10,0) | {(6,4), (2,8)}; (0,10) | {(4,6), (8,2)}
- Sentence for the core page: "Two cells with the same triple have isomorphic reversions iff they are equal or both indefinite (p, q ≥ 1). The reversion of Cl(p,q) is a positive involution (⟨x x̃⟩₀ > 0 for x ≠ 0) iff q = 0; the Clifford conjugation is positive iff p = 0."
- Datum for a card: positive definite / negative definite / indefinite. Equivalently, whether the reversion (q = 0) or the Clifford conjugation (p = 0) is positive. Within a triple class this is one bit (definite or not), except for n ≡ 0 mod 4, where (n,0) and (0,n) share the triple and the datum takes all three values.
- Replaces: H3's "would refute: none known" (the triple loses the reversion: Cl(4,0) | Cl(0,4)). Adds a row to the Conventions page beside row 12.

**disc·REV4** (Clifford conjugation). For n ≤ 10, the Clifford conjugation is a graded anti-involution, and it gives the same partition of the cells as the reversion. ⟨x x̄⟩₀ is positive definite iff p = 0.
- Status: checked.
- Adds: the second row asked for. The choice "reversion or Clifford conjugation" in the involution input lines of `needs_inputs.md` (Dirac, coupling) does not change which cells are identified; it exchanges the roles of p and q in positivity.

**disc·REV5** (dagger). For n ≤ 10, the dagger e_a^† = e_a^{−1} of Thm T15 is a graded anti-involution, and ⟨x x^†⟩₀ is positive definite for every cell. Block maps with blocks of four generators respect it. Two cells are isomorphic with their daggers iff they have the same triple.
- Status: checked.
- Adds to T15 and LNC-005 / LNC-019: the dagger, which makes every cell a positive (state-carrying) algebra, is exactly the involution that does not see the definiteness of the cell.

**disc·REV6** (the global family is not enough). The global maps e_i ↦ ±e_σ(i) ω^k identify only (p,q) ~ (q,p) for n ≡ 2 mod 4 with q odd. For n ≤ 10 they miss 13 isomorphic pairs, for instance Cl(5,3) ~ Cl(1,7) at n = 8. Blocks of six are needed.
- Status: checked.
- Adds: the method statement (which family of generator maps decides the question).

Literature: anti-involutions of Clifford algebras (Porteous) and the KO-dimension of real spectral triples are pointers, sources unread. Positive involutions of real semisimple algebras are a pointer, source unread. Nothing in (c) relies on them.

## (d) What the result does not show

- Only r = 0. Cells with null generators are not treated: there the reversion acts on the radical, and the invariant would need the patched cell (V, Q, π, N) of the review report.
- Real field only. Isomorphisms are graded algebra isomorphisms that intertwine the given anti-involution.
- Three anti-involutions are classified: the reversion, the Clifford conjugation and the dagger. Arbitrary graded anti-involutions of Cl(p,q) are not classified.
- The computation covers n ≤ 10. The statement for every n rests on the argument in (b), which is ours and is not run beyond n = 10.
- The anti-automorphism property of the bit-rule reversion formula is checked on every label pair only for n ≤ 7. For n = 8, 9, 10 the generator-level certificates use that the reversion is the anti-automorphism extending the identity on the generators.
- Nothing is claimed about Pin groups, spinor modules or physics.

## (e) Run time and logs

- `python3 disc_REV.py`: 2.8 s on one core, six lines, ending with ALL PASS. Log: `disc_REV.log`.
- `python3 disc_REV.py --sabotage`: 1.7 s; every check prints CAUGHT, with the reason. Log: `disc_REV_sabotage.log`. The sabotages:
  - REV1: Clifford conjugation in place of the reversion.
  - REV2: a block of four in place of six.
  - REV3: the dagger in place of the reversion. This gives a different, coarser partition: the log lists 18 pairs that are isomorphic with their daggers and not with their reversions, so a "matches the formula" result is not blind.
  - REV4: the conjugation without the reversion sign, i.e. α, which is not an anti-automorphism.
  - REV5: the reversion in place of the dagger.
  - REV6: the global search allowed every block.
- The script uses the standard library only, no randomness and no files, and runs from any directory.
