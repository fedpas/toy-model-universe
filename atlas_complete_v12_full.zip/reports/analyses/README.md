# reports/analyses: the analyses of the atlas

Analyses of the atlas, each shipped as it was generated: its markdown source, unchanged, in `src/`; one self-contained page made from that source; and, where there is one, the zip of the scripts (and their logs) that it ran, also in `src/`. The ten readings and joint reports share one zip, `src/bridges_code.zip`: the checks they quote, the scripts of `selfcheck/bridges/` with their README and logs (`python3 reports/make_package.py` writes it from that folder and `--check` says whether it is current); the discovery runs have their own, `src/discovery_runs_code.zip`. The For researchers page lists them in its Analyses block, where each one opens as a page and downloads as a page, as its source and as its code.

## Files

| Path | What it is |
|---|---|
| `index.json` | The registry, the one list of the analyses. One entry per page: `id`, `title`, `line` (one plain sentence), `kind`, `source` (the markdown files in `src/`, each with its `sha256`; a page of several sources gives each an `anchor`), `html` (the page), `code` (the zip in `src/`, optional), `checks` (the check ids the text quotes, in the form of the package), `date`, `fallbacks` (the number of formulas the page shows as their TeX source). `generator` names the node packages and versions that made the pages. |
| `src/` | The markdown sources, as they are, and the code zips. |
| `<name>.html` | The pages, one per entry of `index.json`. |
| `make_analyses.mjs` | The generator of the pages. |
| `analysis_style.css` | The style of the pages; the generator writes it into each page. |

`node make_analyses_data.mjs` (at the package root) writes `analysesData.js`, the module that the For researchers page reads, from `index.json`; `--check` writes nothing and says whether the module is current. `build.sh` copies the pages and `src/` to `dist/reports/analyses/`, next to the app.

## The pages

A page is one HTML file that needs nothing else: no script, no font, no style sheet, no request of any kind. It shows the source's own text in its own order, with its own tables and headings; every heading carries an anchor, and a bar at the top links the sections (or, on a page of several sources, the sources). A small header gives the title, the line, the download of the markdown source and of the code, and the date. Light and dark follow the system setting; a print style sheet drops the bar and lets tables and formulas run over the full width of the paper.

Formulas between `$ … $` and `$$ … $$` (the rule of pandoc: the opening `$` has a non-space character on its right, the closing `$` a non-space character on its left and no digit after it; a closing `$` may also follow the space that ends a control word, as in `\vert $`) are typeset by katex as MathML, which every current browser draws without help. A letter such as ℤ or 𝔽 is written as its own character, so that every browser draws it in blackboard bold; `\slashed` (not a command of katex) is read as `\not`; a `|` inside a formula of a table row belongs to the formula; a long formula sits in a box that scrolls sideways on a narrow screen. A formula that katex cannot read is shown as its TeX source in a dashed box: the generator counts and prints them, and `fallbacks` in `index.json` records the count of each page (0 for every page here).

## The generator

    node reports/analyses/make_analyses.mjs                 # writes every page; prints its size and the formulas shown as text
    node reports/analyses/make_analyses.mjs --check         # writes nothing; exit 1 if a source or a page is not what index.json and the generator give
    node reports/analyses/make_analyses.mjs --out <folder>  # writes the pages into another folder
    node reports/analyses/make_analyses.mjs --ids src/<name>.md   # the check ids a text quotes, in the form of the package
    node reports/analyses/make_analyses.mjs --sha src/<name>.md   # the sha256 that index.json records for a source

It needs the node packages `markdown-it` and `katex`, at the versions that `index.json` records under `generator` (markdown-it 14.2.0, katex 0.16.47). `katex` is a dependency of the package; `markdown-it` is not: install it next to the package (`npm install --no-save markdown-it@14.2.0`) or name a folder that holds it in `NODE_PATH`. The pages it writes need no package at all. The output is deterministic: the same sources give the same bytes.

## Shipped as generated

A source is never edited: `index.json` records its sha256, and `test_analyses.mjs` fails when the file differs from it, so a change of the text is a change of the registry, made on purpose (the new sha256 goes into `index.json`). A page is what the generator gives: `test_analyses.mjs` writes every page again into a temporary folder and compares it with the shipped one, byte for byte (it reports a skip when `markdown-it` is not installed). `test_no_history.mjs` leaves the sources and the pages out of its scan, because generated reports are shipped as generated, and checks that what it leaves out is exactly the pages and sources of `index.json`. `test_license.mjs`, `test_analyses.mjs` and `make_package.py` hold them, and every member of a code zip, to the rules of every file of the package: no address of any person, no mail link, no path of a working machine.

## Check ids

The texts name a check by the id of the script that ran it; `checks` names the same check by its id in the package, where the scripts sit in `selfcheck/bridges/` (and `core·B<n>` is a row of `selfcheck/core_check.py`):

| In the texts | In the package |
|---|---|
| `rv·P_all·n`, `rv·P_str·n`, `rv·P_ss·n`, `rv·MG·n` | `bd·phy·n`, `bd·str·n`, `bd·sol·n`, `bd·xph·n` |
| `rv·M_all·n`, `rv·M_geo·n`, `rv·M_alg·n`, `rv·M_cat·n`, `rv·merge·n` | `bd·mat·n`, `bd·geo·n`, `bd·alg·n`, `bd·cat·n`, `bd·xck·n` |
| `disc·HHn`, `disc·FKn`, `disc·REVn` | `bd·hh·n`, `bd·fk·n`, `bd·rev·n` |

A range (`rv·M_geo·1–17`, `rv·P_ss·1 … rv·P_ss·31`) stands for every number in it. An id that the package prints as an info line (a value read off, not a check) is not listed, and an id the package splits (`bd·phy·2a`, `bd·phy·2b`) is listed in its parts. `test_analyses.mjs` checks that `checks` is exactly this list for every entry.

## Adding an analysis

1. Put `<name>.md` into `src/`, and, if it ran scripts, the zip of the scripts and their logs as `src/<name>_code.zip`.
2. Add one entry to `analyses` in `index.json`: `id`, `title`, `line`, `kind`, `source` (`[{"file": "src/<name>.md", "sha256": "…"}]`, the value of `--sha`), `html` (`<name>.html`), `code` (if there is a zip), `checks` (the ids of `--ids` that are rows of `selfcheck/bridges/bridges_*.json` or of `selfcheck/core_check.py`), `date` (YYYY-MM-DD) and `fallbacks` (0).
3. `node reports/analyses/make_analyses.mjs` writes the page and prints the formulas it shows as text; their number goes into `fallbacks`.
4. `node make_analyses_data.mjs` and `python3 reports/make_package.py`.
5. `node test_analyses.mjs`, `node test_researchers.mjs`, then `sh build.sh` and `node test_researchers_ui.mjs`.

The Analyses block, its tests and the build take the entry from there; nothing else names the analyses one by one.
