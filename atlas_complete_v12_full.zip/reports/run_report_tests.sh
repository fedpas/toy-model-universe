#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Runs everything that ships with the six reports, one line each (PASS, FAIL or SKIP):
#   the check scripts (their ok lines must equal the recorded logs; for Hestenes the numbers that carry a residual or a timing are compared after normalisation),
#   the six report test suites (the browser parts when python's playwright is installed, can start Chromium and REPORT_NO_BROWSER is not set, and for the Pumplun page node's
#   playwright; else without them, and a line says so), the Pumplun engine test, the matrix json, the check-id table of selfcheck/reports/README.md, the zips and MANIFEST.json.
#   sh reports/run_report_tests.sh              about 5 minutes
#   sh reports/run_report_tests.sh --long       also the exhaustive MRD enumeration over F_8 of the Pumplun report (about 10 minutes more)
#   sh reports/run_report_tests.sh --mutation   also the five sabotage scripts (about 1.5 hours on two cores): every mutant must be caught
# Needs python3 and node. Most check scripts also need numpy, scipy or networkx: requirements.txt (pip install -r reports/requirements.txt) names, after each module, the parts that
# import it. A part whose modules are missing is not run; it gets one line  SKIP <part>: needs <modules>  and every other part runs. A part that is run and stops on a missing
# module that its line does not name FAILS (the table is kept honest that way). The papers' texts are not shipped: Baez check R1 and the text-pinned report tests are skipped and say so.
#   REPORT_WITHOUT="numpy scipy networkx"   (any of them) runs as if those modules were not installed: every python started here finds them missing
#   ATLAS_REQUIRE_BROWSER=1                 a Chromium that python's playwright cannot start is a FAIL instead of a skip of the browser parts
# Exit 1 if anything FAILED, 77 if nothing at all could run, else 0.
cd "$(dirname "$0")" || exit 2
MUT=0; LONG=0
for a in "$@"; do case "$a" in --mutation) MUT=1;; --long) LONG=1;; *) echo "run_report_tests.sh: unknown option $a" >&2; exit 2;; esac; done
command -v python3 >/dev/null 2>&1 || { echo "run_report_tests.sh: python3 is needed"; exit 77; }
ATLAS_PKG=${ATLAS_PKG:-$(cd .. && pwd)}; export ATLAS_PKG
TMP=$(mktemp -d "${TMPDIR:-/tmp}/report_tests.XXXXXX") || exit 2
trap 'rm -rf "$TMP"' EXIT
FAILS=0; PASSES=0; SKIPS=0
say() { echo "$1 $2: $3"; case $1 in PASS) PASSES=$((PASSES+1));; FAIL) FAILS=$((FAILS+1));; SKIP) SKIPS=$((SKIPS+1));; esac; }
TIMED=0; command -v timeout >/dev/null 2>&1 && TIMED=1
# the python modules: those of requirements.txt; REPORT_WITHOUT hides the ones it names (a module file that raises ModuleNotFoundError, first on PYTHONPATH)
if [ -n "${REPORT_WITHOUT:-}" ]; then
  mkdir -p "$TMP/without"
  for m in $REPORT_WITHOUT; do printf 'raise ModuleNotFoundError("No module named %s (REPORT_WITHOUT)", name=%s)\n' "'$m'" "'$m'" > "$TMP/without/$m.py"; done
  PYTHONPATH="$TMP/without${PYTHONPATH:+:$PYTHONPATH}"; export PYTHONPATH
fi
MODULES=$(awk '/^[A-Za-z]/ { print $1 }' requirements.txt)
MISSING=""; for m in $MODULES; do python3 -c "import $m" 2>/dev/null || MISSING="$MISSING $m"; done
# needs <part>: the modules of requirements.txt whose line names the part;  lacks <part>: those of them that are missing here
needs() { awk -v p="$1" '/^[A-Za-z]/ { for (i = 2; i <= NF; i++) if ($i == p) print $1 }' requirements.txt; }
lacks() { for m in $(needs "$1"); do case " $MISSING " in *" $m "*) printf '%s ' "$m";; esac; done; }
# skip <part>: true (and a SKIP line) when the part needs a missing module
skip() { lk=$(lacks "$1"); [ -z "$lk" ] && return 1; say SKIP "$1" "needs ${lk% } (pip install -r reports/requirements.txt)"; return 0; }
# unlisted <output file>: the missing module a run stopped on, when it is one of requirements.txt (then the part's line in requirements.txt is incomplete)
unlisted() { for m in $MISSING; do grep -q "No module named '\{0,1\}$m" "$1" && { echo "$m"; return 0; }; done; return 1; }
oklines() { grep -E '^(ok  |FAIL) ' "$1" | grep -v '^ok   R1:'; }
normal() { sed -E 's/[0-9.]+e[-+][0-9]+/<n>/g; s/[0-9]+\.[0-9]+/<n>/g'; }   # a number that carries a residual or a timing is compared as <n>
# 1. the check scripts against their logs (R1 of baez_check.py needs the papers' texts; it is left out of the comparison when skipped).  A pair is script:log, or script:log:n
#    when the numbers that carry a residual are compared after normalisation.
for pair in category/cat_check.py:category/logs/cat_check.log baez/baez_check.py:baez/logs/baez_check.log schuller/fibre_check.py:schuller/logs/fibre_check_final.log \
            schuller/bridge_check.py:schuller/logs/bridge_check_final.log schuller/bridge_check_qm.py:schuller/logs/bridge_check_qm_final.log \
            hestenes/hest_check.py:hestenes/logs/hest_check.log:n furey/furey_papers_check.py:furey/logs/furey_papers_check.log \
            furey/furey_construction_check.py:furey/logs/furey_construction_check.log pumplun/pumplun_checks.py:pumplun/logs/pumplun_checks.log; do
  s=${pair%%:*}; rest=${pair#*:}; l=${rest%%:*}; n=; case $rest in *:*) n=${rest#*:};; esac
  skip "$s" && continue
  out="$TMP/$(basename "$s").out"
  (cd "$(dirname "$s")" && python3 "$(basename "$s")") > "$out" 2>&1; rc=$?
  if [ -n "$n" ]; then oklines "$out" | normal > "$TMP/a"; oklines "$l" | normal > "$TMP/b"; else oklines "$out" > "$TMP/a"; oklines "$l" > "$TMP/b"; fi
  if [ $rc -eq 0 ] && [ -s "$TMP/a" ] && cmp -s "$TMP/a" "$TMP/b"; then say PASS "$s" "$(grep -c '^ok  ' "$out") ok, the same lines as $l$([ -n "$n" ] && echo ' (residuals normalised)')$(grep -q '^skip R1' "$out" && echo ' (R1 skipped: no texts)')"
  elif m=$(unlisted "$out"); then say FAIL "$s" "stops on the missing module $m, which its line in requirements.txt does not name"
  else say FAIL "$s" "exit $rc or lines differ from $l"; fi
done
if ! skip hestenes/gtg_check.py; then
  (cd hestenes && python3 gtg_check.py S G) > "$TMP/gtg.out" 2>&1 && grep -q '^ALL GTG/RDK CHECKS PASS' "$TMP/gtg.out" && say PASS "hestenes/gtg_check.py S G" "ALL GTG/RDK CHECKS PASS" || say FAIL "hestenes/gtg_check.py S G" "$(m=$(unlisted "$TMP/gtg.out") && echo "stops on the missing module $m, which its line in requirements.txt does not name" || tail -1 "$TMP/gtg.out")"
fi
# 2. the report suites. Their browser parts need python's playwright and a Chromium it can start (tried once, at most 25 s); REPORT_NO_BROWSER=1 leaves them out on purpose
PYPROBE='import re, sys
try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch(); b.close()
except Exception as e:
    ls = [re.sub("[\u2550-\u256c]", "", l).strip() for l in str(e).splitlines()]; ls = [l for l in ls if l] or [repr(e)]
    print(next((l for l in ls if re.search("error while loading|exist|missing|sandbox|cannot open|not found|denied", l, re.I)), ls[0]).replace("BrowserType.launch: ", "")[:240]); sys.exit(1)'
pyprobe() { if [ -n "${ATLAS_BROWSER_FAIL:-}" ]; then echo "$ATLAS_BROWSER_FAIL"; return 1; fi
  if [ "$TIMED" = 1 ]; then o=$(timeout 25 python3 -c "$PYPROBE" 2>&1); else o=$(python3 -c "$PYPROBE" 2>&1); fi; r=$?
  [ $r = 0 ] && return 0; [ $r = 124 ] && o="no answer within 25 s"; printf '%s\n' "$o" | tail -1; return 1; }
if [ -n "${REPORT_NO_BROWSER:-}" ]; then NB=1; NBWHY="REPORT_NO_BROWSER is set"
elif ! python3 -c 'import playwright' 2>/dev/null; then NB=1; NBWHY="python's playwright is not installed"
elif ! why=$(pyprobe); then NB=1; NBWHY="Chromium cannot be launched from python ($why)"
  if [ "${ATLAS_REQUIRE_BROWSER:-}" = 1 ]; then say FAIL "browser parts of the report suites" "$NBWHY"; else say SKIP "browser parts of the report suites" "$NBWHY"; fi
else NB=; NBWHY=; fi
for pair in category:test_report_cat.py baez:test_report_baez.py schuller:test_report.py hestenes:test_report_hestenes.py furey:test_report_furey.py; do
  d=${pair%%:*}; t=${pair#*:}
  skip "$d/$t" && continue
  (cd "$d" && REPORT_NO_BROWSER=$NB python3 "$t") > "$TMP/$d.out" 2>&1 && say PASS "$d/$t" "$(tail -1 "$TMP/$d.out")" || say FAIL "$d/$t" "$(m=$(unlisted "$TMP/$d.out") && echo "stops on the missing module $m, which its line in requirements.txt does not name" || echo "$(grep -m3 '^FAIL' "$TMP/$d.out" | tr '\n' ' ') $(tail -1 "$TMP/$d.out")")"
done
if [ $LONG = 1 ]; then PL=--full; else PL=; fi
if ! skip pumplun/test_report_pumplun.py; then
  (cd pumplun && python3 test_report_pumplun.py $PL) > "$TMP/pum.out" 2>&1 && say PASS "pumplun/test_report_pumplun.py" "$(tail -1 "$TMP/pum.out")" || say FAIL "pumplun/test_report_pumplun.py" "$(m=$(unlisted "$TMP/pum.out") && echo "stops on the missing module $m, which its line in requirements.txt does not name" || echo "$(grep -m3 '^FAIL' "$TMP/pum.out" | tr '\n' ' ') $(tail -1 "$TMP/pum.out")")"
fi
if command -v node >/dev/null 2>&1; then
  (cd pumplun/build && node test_engine.js) > "$TMP/eng.out" 2>&1 && grep -q '^ALL OK' "$TMP/eng.out" && say PASS "pumplun/build/test_engine.js" "ALL OK" || say FAIL "pumplun/build/test_engine.js" "$(tail -2 "$TMP/eng.out" | tr '\n' ' ')"
  if [ $LONG = 1 ]; then
    (cd pumplun/build && node test_f8.js) > "$TMP/f8.out" 2>&1 && say PASS "pumplun/build/test_f8.js" "$(tail -1 "$TMP/f8.out")" || say FAIL "pumplun/build/test_f8.js" "$(tail -2 "$TMP/f8.out" | tr '\n' ' ')"
  else say SKIP "pumplun/build/test_f8.js" "run with --long (the F_8 enumeration, about 10 minutes more)"; fi
  if [ -n "$NB" ]; then say SKIP "pumplun/test_page_pumplun.mjs" "the browser part is left out ($NBWHY)"
  else
    (cd pumplun && node test_page_pumplun.mjs) > "$TMP/pg.out" 2>&1; rc=$?
    if [ $rc -eq 0 ]; then say PASS "pumplun/test_page_pumplun.mjs" "$(tail -1 "$TMP/pg.out")"
    elif [ $rc -eq 77 ]; then say SKIP "pumplun/test_page_pumplun.mjs" "$(tail -1 "$TMP/pg.out")"
    else say FAIL "pumplun/test_page_pumplun.mjs" "$(grep -m3 '^FAIL' "$TMP/pg.out" | tr '\n' ' ') $(tail -1 "$TMP/pg.out")"; fi
  fi
else say SKIP "pumplun node tests" "node is not installed"; fi
# 3. generated files are current
for g in make_matrix_json.py make_check_table.py make_package.py; do
  skip "$g" && continue
  python3 "$g" --check > "$TMP/g.out" 2>&1 && say PASS "$g" "$(tail -1 "$TMP/g.out")" || say FAIL "$g" "$(m=$(unlisted "$TMP/g.out") && echo "stops on the missing module $m, which its line in requirements.txt does not name" || tail -1 "$TMP/g.out")"
done
# 4. sabotage (optional, long): in a copy, so the shipped logs stay as they are
if [ $MUT = 1 ]; then
  cp -R category baez schuller hestenes furey "$TMP/"
  for pair in schuller:mutate_fibre.py category:mutate_cat.py baez:mutate_baez.py hestenes:mutate_hestenes.py furey:mutate_furey.py; do
    d=${pair%%:*}; s=${pair#*:}
    skip "$d/$s" && continue
    ONLY=; NOTE=
    if [ "$s" = mutate_baez.py ] && [ ! -d baez/txt ]; then ONLY=$(seq -f 'M%02g' 2 56); NOTE=' (M01, the sabotage of R1, needs the papers'"'"' texts: not run)'; fi
    (cd "$TMP/$d" && python3 "$s" $ONLY) > "$TMP/$s.log" 2>&1; caught=$(grep -o 'mutants caught: [0-9]* of [0-9]*' "$TMP/$s.log")
    n1=$(echo "$caught" | awk '{print $3}'); n2=$(echo "$caught" | awk '{print $5}')
    if [ -n "$n1" ] && [ "$n1" = "$n2" ]; then say PASS "$d/$s" "$caught$NOTE"; else say FAIL "$d/$s" "${caught:-no verdict}$NOTE"; fi
  done
else say SKIP "sabotage scripts" "run with --mutation (about 1.5 hours)"; fi
echo "run_report_tests.sh: $PASSES passed, $FAILS failed, $SKIPS skipped$([ -n "$MISSING" ] && echo " (python modules missing here:$MISSING)")"
[ $FAILS = 0 ] || exit 1
[ $((PASSES + FAILS)) -gt 0 ] || exit 77
exit 0
