# reports: the six research reports of the atlas

Six reports ship with the atlas, each one a self-contained page that opens offline (light and dark, readable at 375 px) and that is built from a log, a data file or a script of its own folder: every number on a page is read from there, none is typed by hand. Each report says, statement by statement, whether it is standard, checked (a script in the folder recomputes it, and the page names the check), ours, open, or an input (a choice that the algebra does not make); a status is a small drawn icon (the five drawings of the atlas's own badges), its word is the chip's accessible name and hover text, and each page's legend line gives the word and the meaning. Nothing in them is a result about nature. They carry one date of issue, 7 October 2026.

This folder holds the pages, the scripts that build them, their check scripts, their test suites and sabotage scripts, their logs, the zips, the combined translation matrix and the files that keep the folder consistent; and, in `analyses/`, the analyses of the atlas (below).

## The six reports

| Page (`html/`) | What it is | Folder | Checks | Sabotages | Tests |
|---|---|---|---|---|---|
| `category_atlas_report.html` | What is label 0, seen through categories? Findings, dead ends and perspectives, and the translation matrix of the category lens. | `category/` | 52 (`cat_check.py`) | 54 | 63, and 16 in a browser |
| `baez_atlas_report.html` | Seven Baez papers and the atlas: findings and the translation matrix. | `baez/` | 56 (`baez_check.py`) | 56 | 40, 11 more with the papers' texts |
| `schuller_bridge_report.html` | Schuller and the atlas: a translation matrix, and the reading as fibre and base. | `schuller/` | 163 (`bridge_check.py` 77, `bridge_check_qm.py` 51, `fibre_check.py` 35) | 21 | 31, 7 more with the papers' texts |
| `hestenes_ldg_report.html` | Space-time algebra and gauge-theory gravity in the bit rule: the Dirac and Maxwell objects of steps 4, 5, 12, 13 and Calibration 1, recomputed with a second implementation. | `hestenes/` | 95 (`hest_check.py`, with `gtg_check.py` and the independent scripts) | 26 | 39, and 10 in a browser |
| `furey_report.html` | The division algebras and the Standard Model in the bit rule: six papers of Furey rebuilt from the octonion table, the explicit sixteen-dimensional model, and the counts of complete sets. The long form of Calibration 2 (Furey). | `furey/` | 42 (`furey_papers_check.py` 30, `furey_construction_check.py` 12) | 44 | 38, and 12 in a browser |
| `pumplun_dictionary_report.html` | The bit rule in the language of crossed products and Petit algebras: a dictionary to arXiv:2606.18371, with thirteen live widgets and nineteen noise tests that run in the browser. | `pumplun/` | 9 (`pumplun_checks.py`; 11 with `--full`), and the engine test | none (19 noise tests run in the page) | 34, and the browser test |

`html/index.json` lists the six reports for the web app: id, file, title, one line, check scripts, the number of ok lines of their logs, test suite, zip and size of the page. `make_package.py` writes it from the pages and the logs.

Each report folder holds `README_<name>.md` (every file of the folder, how to rerun it, what is not verified), the builder of the page, the check scripts (the ones that the package also holds are byte-identical copies; `test_reports.mjs` compares them), the test suite, the sabotage script, and `logs/`.

## What else is here

| Path | What it is |
|---|---|
| `zips/category_report.zip`, `baez_report.zip`, `schuller_report.zip`, `hestenes_report.zip`, `furey_report.zip`, `pumplun_report.zip` | One zip per report. A zip holds the page (`html/<page>`) and the folder (`<folder>/…`), so unpacking it in this folder gives the same tree: each zip unpacks to exactly its page and its folder. |
| `MANIFEST.json` | sha256 and size of every file in this folder (itself excepted). |
| `make_package.py` | Rebuilds the zips, `html/index.json` and `MANIFEST.json`, deterministically; `--check` writes nothing and says whether they are current. It refuses a file that holds an e-mail address, a mail link or a path of a working machine. |
| `translation_matrix.json` | The combined translation matrix: 131 rows (Schuller 43, Baez 48, category 40) × 22 atlas columns, 246 cells. |
| `make_matrix_json.py` | Builds `translation_matrix.json` from the three matrix modules; then `node make_matrix_data.mjs reports/translation_matrix.json` builds the app's `translationMatrixData.js`. |
| `lens_dictionary.json` | The lens dictionary: one row per atlas object with its names in string theory, solid state, field theory, algebra, geometry and category theory (see below). |
| `make_check_table.py` | Writes the table "check id → one line" of `selfcheck/reports/README.md` from the five check scripts' own output. |
| `no_history.py` | The shared list of patterns that a page never shows (numbered-note ids, notes that a wording was fixed, strike-through text, version stamps, and the like) and the reader of a page's visible text; each report's test suite imports it. |
| `status_check.py` | The shared check of the status icons: every status chip of a page is an icon chip (role `img`, the word as name and hover text, no word on the chip), the five drawings are those of `StatusBadge.jsx`, the legend line gives each flag its word and meaning; each report's test suite imports it. |
| `<folder>/status_chips.py` (`pumplun/build/status_chips.py`) | The one chip module (the five drawings as a hidden sprite, the chip, the legend line and the style rules), the same file in the six report folders; `test_reports.mjs` compares the copies and the drawings. |
| `analyses/` | The analyses of the atlas, each shipped as it was generated: the markdown sources and code zips in `analyses/src/`, one self-contained page per analysis (formulas as MathML, nothing to fetch), the registry `analyses/index.json` and the generator `analyses/make_analyses.mjs` (node, with markdown-it and katex). `analyses/README.md` says how the pages are made and how an analysis is added; the For researchers page lists them in its Analyses block, and `make_package.py` lists their files in `MANIFEST.json` and reads every member of their code zips for addresses and machine paths. |
| `run_report_tests.sh` | Runs everything here, one line each: the check scripts against their logs, the six report suites, the Pumplün engine test, the generated files; `--long` adds the exhaustive MRD enumeration of the Pumplün report, `--mutation` the five sabotage scripts. A part whose python modules are missing is skipped and named; the rest runs. |
| `requirements.txt` | The python modules of the check scripts, here and in the rest of the package (numpy, scipy, networkx: `pip install -r reports/requirements.txt`), and after each module the parts of `run_report_tests.sh` that import it. |

The check scripts of the three Lenses chapters (`cat_check.py`, `baez_check.py`, `fibre_check.py`, `bridge_check.py`, `bridge_check_qm.py`) are also in `selfcheck/reports/`, where the Lenses page offers them for download; `gtg_check.py` and `bitcliff.py` of the Hestenes report are in `selfcheck/steps15_17/`; the three scripts, the data file and the two model files of the Furey report are in `selfcheck/` and at the package root. The copies here are byte-identical.

`lens_dictionary.json` is hand-maintained and is the one source of the lens dictionary. Each row names one atlas object (with the ids of the statements, theorems, core rows or pages where it lives), gives its name in up to six fields (`str` string theory, `sol` solid state, `fld` field theory, `alg` algebra, `geo` geometry, `cat` category theory; the part of a term before its first semicolon is its short name), says how far the names agree (`exact`, `partial`, `none`, or `new` when the field's object is an addition of the atlas), carries the tags of the translation (checked only with a cited check id of `selfcheck/bridges/` or a core row, standard only for a source read at statement level), the range in which it holds, and the ids of the translation-matrix rows that cover the same object in the Schuller, Baez and category lenses. `node make_lens_dictionary.mjs` checks every id and writes `lensDictionaryData.js` (`--check` writes nothing and says whether it is current); the chat persona prints the compact form of that module in its fixed core, and `test_lens_dictionary.mjs` and `test_persona.mjs` hold the two to the json.

## Running

Python 3; numpy, scipy and networkx for most check scripts (`pip install -r reports/requirements.txt`; that file names, after each module, the parts that import it). Without one of them `run_report_tests.sh` leaves out the parts that need it, one line each (`SKIP <part>: needs numpy`), runs every other part, and exits 0 when nothing failed (77 only when nothing at all could run); `REPORT_WITHOUT="numpy scipy networkx"` runs it as if they were missing. The browser parts also need Python's playwright with a Chromium it can start (else they are left out and a line says why); the Pumplün page needs node, and node's playwright for its browser test. The scripts find the atlas package two folders up (`selfcheck/steps15_17/bitcliff.py` and the other mirrored scripts); set `ATLAS_PKG` to run them from elsewhere. The folders `selfcheck/` and `researchers_checks/` of the package are both looked at; without `researchers_checks/` the Hestenes test T19 skips its one cross-reference to `check_T16.py` and says so.

    sh reports/run_report_tests.sh              # about 5 minutes, with the browser parts
    sh reports/run_report_tests.sh --long       # adds the F_8 enumeration of the Pumplün report, about 10 minutes more
    sh reports/run_report_tests.sh --mutation   # adds the five sabotage scripts, about 1.5 hours on two cores
    cd reports/category && python3 build_report_cat.py && python3 test_report_cat.py      # one report: rebuild its page in ../html/ and test it
    python3 reports/make_package.py             # after any change: zips, html/index.json, MANIFEST.json

The package's own test `test_reports.mjs` (in `run_tests.sh --data`) runs a faster subset: the data checks of this folder, the six suites without a browser, and the check scripts against their logs; it leaves out the same parts the same way when a module is missing.

## Not shipped, and why

- The papers' texts (`txt/` in each folder, made with `pdftotext` from the PDFs): they are the authors' work. Without them `baez_check.py` skips check R1 (the cross-citations) and says so, eleven Baez report tests and seven Schuller report tests are skipped and say so, and the sabotage of R1 cannot run. With the texts put back in `txt/`, everything runs as recorded in the logs (which were made with them).
- Screenshots, checkpoint archives, backups and scratch scripts of the working folders.
- Anything private: no address of any person is in any file or zip member (`test_license.mjs` and `test_reports.mjs` check it).

Licence: PolyForm Noncommercial 1.0.0, as the rest of the package (see `LICENSE` and `NOTICE` at the package root).
