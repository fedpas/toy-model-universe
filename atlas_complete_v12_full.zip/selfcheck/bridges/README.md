# Bridge checks (selfcheck/bridges)

The scripts of this folder compute the statements that join the cells of the atlas to the languages of physics and of mathematics: the clock as an edge invariant of Majorana modes, as a K-theory degree and as a lattice phase; the frame-free cell against the number of time directions; the null generator as a horizon, a creation operator and a base change; and so on. They are checks, not readings: each prints what it computes.

Every script prints one line per check id, `ok   <id>  <what is computed>` (or `FAIL <id>  ...`), and as its last line `<n>/<n> bridge checks hold.  ALL BRIDGE CHECKS PASS`; it exits 1 when a check fails. A line `info <id>  ...` reads a value off or does arithmetic that cannot fail: it is not a check, it is not counted, and it never stands behind a `checked` tag. The ids are `bd·<family>·<n>`. A statement of the atlas that a bridge check computes names the script and the ids in its `checkedBy`, in the form `selfcheck/bridges/<file>.py, bd·<family>·<n>`.

The scripts read no file outside this folder, write nothing, use no network, use fixed seeds and print the same lines on every run. They run from any folder: `python3 selfcheck/bridges/<file>.py`.

## Physics family (phy, str, sol, xph, fk)

Ids `bd·phy·n` (the frame-free cell, Dirac, coupling, null surfaces, trios, the staggered cube), `bd·str·n` (worldsheet, K-theory, spinors, dualities, lattices), `bd·sol·n` (Majorana edges, bands, media, lattices, point groups), `bd·xph·n` (two cross-checks that compute two of these readings again, independently, and compare them) and `bd·fk·n` (the junction of two stacks of Kitaev chains).

- **Run and rebuild.** `sh selfcheck/regen_bridges_phys.sh` runs the 25 scripts one at a time on one core and writes `bridges_phys.json`: every printed line (id, script, kind `check` or `info`, text, ok), the processor seconds of each script, its imports and the counts (83 checks, 5 info lines). `node test_bridges_phys.mjs` runs every script again from another folder and compares the lines with the json, checks this table, the imports and the words, runs a sabotaged copy of every script (one documented changed line, listed in the test, must make the copy exit 1 with `FAIL` for the intended id) and `fk_junction.py --sabotage`, and checks that every `bd·phy`, `bd·str`, `bd·sol`, `bd·xph` or `bd·fk` id that a file of the package cites is a row of the json.
- **Dependencies.** Python 3 with numpy for every script except three: `str_dualities.py`, `str_lattices.py` and `str_null.py` use the standard library only and pass with `python3 -I`. scipy is used by two scripts: `sol_hubbard_cube.py` (sparse matrices and the Lanczos solver `eigsh`) and `fk_junction.py` (the same, on Fock spaces of dimension up to 2^14). `phy_bitrule.py` is the bit-rule engine (no check of its own) that `phy_coupled_action.py`, `phy_dirac.py`, `phy_horizon_little_group.py`, `phy_staggered.py` and `phy_trio.py` import from this folder. `sol_furey_fk.py` carries the octonion lines of `model.py` (the test checks that they are lines of `model.py`).
- **Seconds.** Processor seconds of one run on one core (`OMP_NUM_THREADS=1`), as stored in `bridges_phys.json`; every script stays under 60 on an idle core. `fk_junction.py` is the longest (38 to 46 s on an idle core, up to 55 s when other processes share the cores); `python3 fk_junction.py --only bd·fk·1` runs one of its checks, and `python3 fk_junction.py --sabotage` runs each of its five checks on a deliberately broken input and prints `CAUGHT` for each (`ALL CAUGHT`, exit 0).

| id | script | what it computes | range | seconds |
|---|---|---|---|---|
| bd·phy·1 | phy_cell_vs_signature.py | an explicit isometry of triples (V, Q, pi) Cl(5,0) -> Cl(1,4) from five odd anticommuting blades of square +1 | n = 5 | 0.4 |
| bd·phy·2a | phy_cell_vs_signature.py | the same for Cl(5,2) -> Cl(1,6) | n = 7 | 0.4 |
| bd·phy·2b | phy_cell_vs_signature.py | the same for Cl(5,3) -> Cl(1,7) | n = 8 | 0.4 |
| bd·phy·3 | phy_cell_vs_signature.py | the hyperbolicity test of T18 (f) holds for the Lorentzian member of each pair and for no tested direction of the other | the three pairs; 200 random directions | 0.4 |
| bd·phy·4 | phy_cell_vs_signature.py | the generators of Cl(5,0) go to blades of grades 1, 3, 3, 3, 3: the frame is data beyond the triple; eps carries min(p,q) | n = 5 | 0.4 |
| bd·phy·20 | phy_cell_vs_signature.py | the classes (n, clock) that hold a Lorentzian and a non-Lorentzian cell: none exactly for n = 2, 3, 4, 6 | n = 2..12 | 0.4 |
| bd·phy·5 | phy_horizon_little_group.py | the stabiliser of the null vector l = e0 + e1 in so(1,3) has dimension 3, basis l e2, l e3, e2 e3 | Cl(1,3) | 0.1 |
| bd·phy·6 | phy_horizon_little_group.py | l e_k -> n e_k, e2 e3 -> e2 e3 is a Lie algebra isomorphism onto the bivectors of Cl(0,2,1); both are iso(2) | Cl(1,3), Cl(0,2,1) | 0.1 |
| bd·phy·7 | phy_horizon_little_group.py | the isomorphism intertwines the actions on l-perp and on span(n, e2, e3) | Cl(1,3), Cl(0,2,1) | 0.1 |
| bd·phy·8 | phy_horizon_little_group.py | the tube algebra Cl(T,-1,-1): [K1, K2] = -2T J, so(1,2), iso(2), so(3) | T = 1, 0, -1 | 0.1 |
| bd·phy·9 | phy_dirac.py | the dagger of T15 is gamma0 psi~ gamma0; its state functional is the gamma0 component of the Dirac current (positive), while the reversion scalar takes both signs | Cl(1,3); 300 random psi | 0.2 |
| bd·phy·10 | phy_dirac.py | the chirality I psi J commutes with the right action of J; the Weyl halves have real dimension 4 + 4 | Cl(1,3); 50 random psi | 0.2 |
| bd·phy·11 | phy_dirac.py | the current psi gamma0 psi~ has grades 1 and 5, and the coupling term sees only its grade-1 part | Cl(1,4); 200 random cases | 0.2 |
| bd·phy·12 | phy_dirac.py | the real operators gamma.d - m and gamma.d + m are singular on E^2 = p^2 + m^2; i gamma.d - m on the tachyonic shell | real 4x4 matrices of Cl(3,1); 50 random p, m | 0.2 |
| bd·phy·13 | phy_trio.py | Witt (x) A_eps is bms3 = gca2 (eps = 0), Witt + Witt (+1), Witt (x) C (-1); the Jacobi identity holds | modes up to 4 (Jacobi up to 2) | 0.1 |
| bd·phy·14 | phy_trio.py | the Killing signatures of the bivectors of Cl(1,3) plus one generator of square s: so(1,4), so(2,3), iso(1,3) | s = -1, +1, 0 | 0.1 |
| bd·phy·16 | phy_staggered.py | the bit-rule signs on the n-cube are the Kogut-Susskind phases; D^2 = n | n = 2..6 | 0.1 |
| bd·phy·17 | phy_staggered.py | the antisymmetric staggered operator vanishes on the lattice of side 2 and the signed cube D is the symmetric part; side 3 and 4 give a nonzero one | n = 2..6; (n, L) = (2,3), (2,4), (3,3) | 0.1 |
| bd·phy·18 | phy_coupled_action.py | the Euler-Lagrange equation in psi of the coupled action is T times the Dirac equation with the term -e A psi | Cl(1,3); 50 random cases | 0.2 |
| bd·phy·19 | phy_coupled_action.py | the Euler-Lagrange equation in A is c (grad F - e X) with one c; flipping L_int flips both equations together | Cl(1,3); 30 random cases | 0.2 |
| bd·str·1 | str_clock.py | the Z_4 refinements of the dot product are the bit-rule forms w = pi + 2Q, with Gauss phase p - q (the Arf-Brown invariant of a Pin- surface) | n up to 6 | 0.7 |
| bd·str·2 | str_clock.py | the Atiyah-Bott-Shapiro cokernels of the bit-rule modules of Cl(0,k) are KO^{-k}(pt) | k = 1..10 | 0.7 |
| bd·str·5 | str_clock.py | row 8: five cells with ungraded algebra M_16(R), three with clock 0 | n = 8 | 0.7 |
| bd·str·6 | str_spinors.py | the type of the even part Cl^0(s,t) depends on s - t mod 8 only; Majorana-Weyl exactly when s - t = 0 mod 8 | s + t up to 12 | 3.1 |
| bd·str·7 | str_spinors.py | Hull's lists of M, IIA and IIB signatures from the even part (Hull's criteria are the input) | s + t = 10, 11 | 3.1 |
| bd·str·8 | str_spinors.py | the Hodge star on middle forms of Cl(D-1,1) squares to the top-blade square: real self-dual forms for D = 2, 6, 10 | D = 2..12 even | 3.1 |
| bd·str·9 | str_spinors.py | the 3-psi rule holds for every invariant symmetric pairing exactly for D = 3, 4, 6, 10 | D = 3..11 | 3.1 |
| bd·str·10 | str_dualities.py | T-duality on polyforms: CAR of T + T*, the reflection swaps dx^i wedge and iota_i and is odd | n up to 5 | 0.9 |
| bd·str·11 | str_dualities.py | B-shifts are null bivectors; e^N is even and is the B-transform | n = 4 | 0.9 |
| bd·str·12 | str_dualities.py | triality as the Hadamard transform of F_2^4 on the weights of D4 | n = 4 | 0.9 |
| bd·str·13 | str_dualities.py | the two ideals of Cl(4,3): exchanged by the grade involution and the reversion, fixed by Clifford conjugation, one Spin module | Cl(4,3) | 0.9 |
| bd·str·14 | str_dualities.py | Witt (x) A_eps with central terms: Jacobi; Vir + Vir, BMS3 = GCA2, Witt (x) C | modes up to 4 | 0.9 |
| bd·str·15 | str_lattices.py | E8 two ways: Construction A on the code of Furey's Fano blades and D8 + (D8 + s), 240 and 2160 vectors | rank 8 | 8.8 |
| bd·str·16 | str_lattices.py | the Brown phase of Z^n/2Z^n and the Gauss-Milgram phase of D_n are both n mod 8 | n = 1..24 | 8.8 |
| bd·str·17 | str_lattices.py | del Pezzo: K.K = 9 - n, the E_n roots, the exceptional classes 6, 10, 16, 27, 56, 240 | n = 3..8 | 8.8 |
| bd·str·18 | str_lattices.py | the 56 of E7 split 7 x 8 over seven orthogonal roots, whose triples form a Fano plane | E8 | 8.8 |
| bd·str·19 | str_lattices.py | Thurston's form on Z[w]^10 is even, unimodular, of signature (2,18) | rank 20 | 8.8 |
| bd·str·20 | str_syk.py | Majorana SYK level statistics by parity sector are GOE, GUE, GSE as the type of Cl^0(N,0) | N = 8, 10, 12, 14, 16 | 14.4 |
| bd·str·21 | str_null.py | the horizon generator l is a paired null of Cl(1,n-1) and the radical of the subalgebra Cl(0,n-2,1) | n = 3..6 | 0.0 |
| bd·str·23 | str_extra.py | the graded map A (x) A^op -> End(A) has image of dimension 4^(p+q) 2^r = dim End_Z(A) | every Cl(p,q,r), n up to 4, r at least 1 | 1.8 |
| bd·str·24 | str_extra.py | Furey's Lagrangian as the Cayley 4-form: eigenvalue 14 once, stabiliser of dimension 21 = dim spin(7) | Cl(0,8) | 1.8 |
| bd·str·25 | str_extra.py | E_n mod 2 is the set of even labels of Cl(1,n), and dropping the H-bit gives the labels of Cl(n,0); the same for A_n | n = 3..9 (E_n), 1..9 (A_n) | 1.8 |
| bd·str·26 | str_extra.py | E7: 135 sets of seven orthogonal roots, 30 of them Hamming codes mod 2, one of them Furey's Fano lines; the 56 split 7 x 8 | n = 7 | 1.8 |
| bd·str·27 | str_extra.py | the 3-psi rule on Cayley-Dickson labels holds for R, C, H, O and fails for the sedenions | 1, 2, 4, 8, 16 labels; 40 random psi | 1.8 |
| bd·sol·1 | sol_fk_clock.py | the T-invariant real algebra of p T-even and q T-odd Majoranas is the bit rule of Cl(p,q); Hermitian iff Q = 0, fermion-odd iff pi = 1 | n even up to 8 (all products up to 6) | 3.1 |
| bd·sol·2 | sol_fk_clock.py | the edge invariants (T^2, T against P) depend on the clock only | n even up to 12 | 3.1 |
| bd·sol·3 | sol_fk_clock.py | the generic level degeneracy of a T-invariant edge is 1 exactly when c = 0 mod 8, else 2 | n even up to 10 | 3.1 |
| bd·sol·4 | sol_fk_clock.py | a Lagrangian of w exists exactly when c = 0 mod 8 | exhaustive for n even up to 8; built up to 16 | 3.1 |
| bd·sol·5 | sol_fk_clock.py | the stabilizer Hamiltonian of a Lagrangian has a unique T-invariant ground state and gap 2 | c = 0 cells, n up to 12 | 3.1 |
| bd·sol·6 | sol_fk_clock.py | Furey's seven Fano blades as an 8-Majorana interaction: a unique ground state of definite parity | Cl(8,0), Cl(0,8) | 3.1 |
| bd·sol·7 | sol_fk_clock.py | the mirror is the relabelling T -> T P | n even up to 10 | 3.1 |
| bd·sol·8 | sol_fk_clock.py | stacks of BDI chains: winding p - q, end modes (p,q) and (q,p), p - q left after T-invariant couplings | eight stacks, 12 sites | 3.1 |
| bd·sol·9 | sol_fk_clock.py | Construction A on the code of bd·sol·6: 240 roots spanning an even unimodular lattice (E8) | rank 8 | 3.1 |
| bd·sol·10 | sol_furey_fk.py | Furey's line blades as Fidkowski-Kitaev couplings: a perfect Hamming code, a unique ground state for all 128 sign choices, minimum -5 with her orientation, her blocks are not levels | 128 sign choices | 0.1 |
| bd·sol·11 | sol_null_bands.py | the PT dimer is a vector of Cl(1,1); at the exceptional point a paired null; splitting exponents 1/2 and 1 | one dimer | 1.9 |
| bd·sol·12 | sol_null_bands.py | the *-closure of Cl(p,q,r) is Cl(p+r,q+r), with the clock of Cl(p,q,r) at weight 0 on the null bits | every Cl(p,q,r), n up to 4 | 1.9 |
| bd·sol·13 | sol_null_bands.py | Kronig-Penney: X^2 = g^2 - 1, van Hove exponent -1/2 at the band edges, L states per band | the first three band edges | 1.9 |
| bd·sol·14 | sol_maxwell_media.py | constitutive tensors 36 = 21 + 15; the axion part is invisible to the wave operator; the vacuum Fresnel polynomial | 20 random k | 0.2 |
| bd·sol·15 | sol_maxwell_media.py | uniaxial media: the Fresnel factorisation and the hyperbolicity in t or z of each sign class | four sign classes | 0.2 |
| bd·sol·16 | sol_maxwell_media.py | a Drude axis: hyperboloid below omega_p, ellipsoid above, the vacuum form in the limit | seven frequencies | 0.2 |
| bd·sol·17 | sol_maxwell_media.py | the Poynting balance fixes the relative sign of source and force | 200 random linear fields, exact | 0.2 |
| bd·sol·18 | sol_lattice_springs.py | the pi-flux lattice: phases = bit-rule signs, H(k), Dirac points, tastes | n = 2, 3, 4 | 0.1 |
| bd·sol·19 | sol_lattice_springs.py | n-cube frames: C(n+1,2) rigid motions, 1, 6, 22, 65 mechanisms, no self-stress; the braced cube is rigid | n = 2..5 | 0.1 |
| bd·sol·20 | sol_lattice_springs.py | Kitaev ring: the ground parities of periodic and antiperiodic rings differ exactly when abs(mu) < 2t | N = 12, five values of mu | 0.1 |
| bd·sol·30 | sol_lattice_springs.py | fermion doubling: 2^d zeros of the naive stencil, one with a Wilson mass | d = 1..4 | 0.1 |
| bd·sol·21 | sol_point_groups.py | the 3-bit labels are mmm; the spin double groups are the sign tables of Cl(0,3) and Cl(3,0) | n = 3 | 0.2 |
| bd·sol·22 | sol_point_groups.py | B3 = O_h, D3 = T_d; integral traces of the crystallographic groups, (1 +- sqrt5)/2 for 2.A5 | point groups | 0.2 |
| bd·sol·23 | sol_point_groups.py | the Frobenius-Schur indicator is the type R, C, H; T^2 = FS; Kramers degeneracy for H | n up to 4 | 0.2 |
| bd·sol·24 | sol_point_groups.py | a Weyl node cannot be gapped in Cl(3,0); Dirac masses; Chern number -chi | Cl(3,0) | 0.2 |
| bd·sol·25 | sol_abs_tenfold.py | the Atiyah-Bott-Shapiro cokernels from bit-rule modules are KO^{-k}(pt) | k = 1..10 | 0.9 |
| bd·sol·27 | sol_kitaev_lieb.py | Lieb's flux phase on the cube: the half-filled energy is lowest exactly in the all-pi sector | n = 2, 3, 4, every flux sector | 4.8 |
| bd·sol·28 | sol_kitaev_lieb.py | Kitaev's spin from four Majoranas: D is the central top blade of the even part; the projection picks one chirality | Cl(4,0) | 4.8 |
| bd·sol·29 | sol_kitaev_lieb.py | the central split happens exactly for p - q = 1 mod 4 | odd n up to 7 | 4.8 |
| bd·sol·31 | sol_hubbard_cube.py | Hubbard model on the 3-cube: the all-pi sector has the lowest ground energy | 32 flux sectors; U = 0, 2, 4, 8 | 2.1 |
| bd·xph·1 | xph_clock_crosscheck.py | the edge pair (T^2, T against P) and the type of the even part are one function of the clock | n even up to 8 | 0.4 |
| bd·xph·2 | xph_clock_crosscheck.py | the even-part types of Cl(N,0) are the Dyson classes of the SYK sectors | N = 8..16 even | 0.4 |
| bd·xph·3 | xph_null_join.py | the dagger of l is e_t - e_r; the subalgebra of l, e2, e3 is Cl(0,2,1), and with the dagger of l it is Cl(1,3) | n = 4 | 0.4 |
| bd·xph·4 | xph_null_join.py | dimensions 2^(n-1) and 2^n; the clock of the closure is the clock with weight 0 on the null bit | n = 3..6 | 0.4 |
| bd·fk·1 | fk_junction.py | the interface zero modes of a free junction of two BDI stacks form Cl(p,q) with p - q = W' - W | 18 junctions | 55.0 |
| bd·fk·2 | fk_junction.py | free junctions: the ground state is 2^(d/2)-fold degenerate, d = abs(W - W') | 8 junctions | 55.0 |
| bd·fk·3 | fk_junction.py | interacting junctions: degeneracy 1, 2, 2, 4, 2, 4, 2, 2 by (W - W') mod 8 | 18 junctions; seeds 101, 202 | 55.0 |
| bd·fk·4 | fk_junction.py | residue 0: the Hamming stabilizers give a unique gapped ground state, robust to a perturbation | (8,0), (4,-4), (4,4) | 55.0 |
| bd·fk·5 | fk_junction.py | T^2 and T against P on the junction force a degeneracy of at least 2 for every nonzero residue | 13 junctions | 55.0 |

### Info lines (read-offs, not checks)

- bd·phy·15 (phy_trio.py): the bivector squares -1, +1, 0 of Cl(2,0), Cl(1,1), Cl(1,0,1) read as three trios (orbits, tubes, bands): three one-line squares, a table.
- bd·str·3 (str_clock.py): the Type I D-brane charge list indexed from the groups that bd·str·2 computes: a read-off of bd·str·2.
- bd·str·4 (str_clock.py): KO^{nu} + KO^{-nu} as a function of {c, -c}: symmetric by construction, it cannot fail.
- bd·str·22 (str_null.py): AdS_d and the conformal model of its boundary give the same cell Cl(2,d-1): signature arithmetic, it cannot fail (the line also reads the type M_4(C) of Cl^0(2,4) from the bit rule).
- bd·sol·26 (sol_abs_tenfold.py): the complex cokernels KU^{-k}(pt) from the counts of complex modules: arithmetic on the counts.

## Mathematics

The mathematics bridge scripts recompute the statements that join the cells of the Atlas to standard mathematics: the cell as a twisted group
algebra and as a lattice mod 2 (`mat_*`, `alg_*`), spin geometry, Lorentzian geometry and Klein pairs (`geo_*`), Frobenius, Morita and modular
categories (`cat_*`), cross-checks between these scripts (`xck_*`), the graded Hochschild groups of the degenerate cells (`hh_*`) and the cell
with its reversion (`rev_*`), which choices of structure are gauge and which are data (`tor_*`), the image of W(E_n) mod 2 (`en_*`), the
commutant of the gauge algebra in Furey's model (`fur_*`) and the Kepler trio through Fock's projection (`kep_*`). Every check id has the form
`bd·<family>·n`; a statement of the Atlas that rests on one of them names the script and the id (`selfcheck/bridges/<script>.py, bd·mat·5`).

- Run one script: `python3 selfcheck/bridges/<script>.py` from any folder (`python3 -I` gives the same output). Each prints one line per check,
  `ok   <id>  <what is computed>` (or `FAIL <id>  …`), indented lines with the witnesses, and the verdict line
  `<k>/<k> bridge checks hold.  ALL BRIDGE CHECKS PASS`; it exits 1 on any failing check. No script reads or writes a file or uses the network;
  random data come from generators with fixed seeds, so the output is the same on every run.
- Rebuild the log: `sh selfcheck/regen_bridges_math.sh` runs every script and writes `selfcheck/bridges/bridges_math.json`
  (`rows`: id, script, text, ok, seconds of the whole script; `summary`: the scripts, the counts and the info lines). It stops at the first
  error and then leaves the stored json as it is.
- Test: `node test_bridges_math.mjs` (no browser, about 6 minutes; `--citations` runs only the id, source and citation parts): the json equals a fresh run; every script exits 0 with its verdict line;
  every id of this table is a row; the imports are the allowed ones; no script reads, writes or connects; one sabotaged copy per script
  (a one-line change that breaks the check it targets) must stop with `FAIL` for that id; every `bd·` id of these families that any file of the
  package cites is a row of the json, and a `checkedBy` that names a bridge script names the script that prints the id.
- Memory: `en_weyl.py` holds about 0.5 GB at n = 20; every other script stays far below.
- Dependencies: the Python standard library (`array` in `en_weyl.py`); numpy (exact integer and rational data, float eigenvalues only for signatures and for picking
  candidate zero divisors that an exact determinant then confirms) in `alg_finite_fields.py`, `alg_octonion.py` and `geo_cartan.py`. No script
  needs scipy.

Seconds: the run time of the whole script on one idle core (every row of a script shows the same number). Range: the cases the script runs;
a statement for all n rests on the argument or the source named in the row text, not on the range.

| id | script | what it computes | range | seconds |
|---|---|---|---|---|
| `bd·mat·17` | `mat_En_in_Cl1n.py` | k = (3; -1^n) is characteristic in I_{1,n}, k.k = 9 - n = 1 - n mod 8 = clock of Cl(1,n) = det E_n (van der Blij) | n = 3..13 | 0.1 |
| `bd·mat·18` | `mat_En_in_Cl1n.py` | E_n/2E_n maps bijectively onto the even labels of Cl(1,n), with x.x/2 = Q | n = 3..10 | 0.1 |
| `bd·mat·19` | `mat_En_in_Cl1n.py` | on the even labels of Cl(1,n) the Z_4 form is 2 Q_Cl(n,0); the sign of the even Gauss sum is the Arf type of E_n/2E_n | n = 3..10 | 0.1 |
| `bd·mat·12` | `mat_En_trio.py` | E_n = k^perp in I_{1,n}, k = (3; -1^n): k.k = 9 - n, determinant and signature of k^perp | n = 3..13 | 0.1 |
| `bd·mat·13` | `mat_En_trio.py` | the norm -2 vectors of k^perp number 8, 20, 40, 72, 126, 240 | n = 3..8 | 0.1 |
| `bd·mat·5` | `mat_cell_classification.py` | explicit isometry of the triples of Cl(4,0) and Cl(0,4) (the four 3-subsets of a block), extended to Cl(p,q) -> Cl(p-4,q+4) | 4 <= n <= 9 | 1.4 |
| `bd·mat·6` | `mat_cell_classification.py` | the bilinear form of w is the dot product; the polar form of Q has radical {0} (n even) or {0, 1...1} (n odd) | n <= 7 | 1.4 |
| `bd·mat·7` | `mat_cell_classification.py` | w(a) = x.x mod 4 in the odd lattice I_{p,q}; the Gauss sum is (1+i)^p (1-i)^q: clock = signature of I_{p,q} mod 8 | n <= 8 | 1.4 |
| `bd·mat·8` | `mat_cell_classification.py` | for Cl(n,0), Q on the even labels is the mod-2 norm of D_n, and Q = floor(w/2) | n <= 8 | 1.4 |
| `bd·mat·15` | `mat_codes_misc.py` | the Lagrangians of w on Cl(n,0) are the doubly-even self-dual codes: only at n = 8 (extended Hamming); Q has them at n = 2, 8 | n = 2, 4, 6, 8 | 1.5 |
| `bd·mat·16` | `mat_codes_misc.py` | explicit ungraded isomorphism Cl(p,q) = Cl(q+1, p-1) | p >= 1, n <= 6 | 1.5 |
| `bd·mat·1` | `mat_degenerate_cell.py` | the triple (V, Q, pi) does not fix the cell once r >= 1: every pair of cells with isomorphic triples and different r is listed (full isometry test) | n <= 4 | 0.1 |
| `bd·mat·2` | `mat_degenerate_cell.py` | w = pi + 2Q is a Z_4 refinement of the dot product exactly for r = 0 and for Cl(0,0,1), Cl(0,1,1) | n <= 5 | 0.1 |
| `bd·mat·3` | `mat_degenerate_cell.py` | for r >= 1 the sum of i^(pi+2Q) over all labels is not a Gauss sum; over the labels without a null bit (the quotient Cl(p,q)) it is (1+i)^p (1-i)^q | r >= 1, n <= 6 | 0.1 |
| `bd·mat·4` | `mat_degenerate_cell.py` | (V, Qt, pi) with the ternary square map determines the cell: isomorphic iff r and p - q mod 8 agree | all pairs, n <= 4 | 0.1 |
| `bd·mat·9` | `mat_null_part.py` | the label monoid with zero is Z_2^{p+q} x Rees(N^r) | all eps, n <= 4 | 0.4 |
| `bd·mat·10` | `mat_null_part.py` | the operators x -> (-1)^{\|b\|\|x\|} e_a x e_b span 4^{p+q} 2^r dimensions: Cl(p,q,r) is graded Azumaya over Lambda(R^r) | n <= 4 | 0.4 |
| `bd·mat·11` | `mat_null_part.py` | Loewy layers dim J^k/J^{k+1} = C(r,k) 2^{p+q} | n <= 5 | 0.4 |
| `bd·geo·13` | `geo_cartan.py` | Klein pairs of the projective step: [h, m] in m, [m, m] = -2s h; the involution is the mirror in e_n iff s != 0 | d = 2..5, s = -1, 0, 1 | 0.4 |
| `bd·geo·14` | `geo_cartan.py` | invariant forms on the bivectors: 2-dimensional; for e(3) the top-blade pairing is the Klein form, signature (3,3) | e(3), so(4), so(1,3) | 0.4 |
| `bd·geo·15` | `geo_cartan.py` | Euler-Arnold flow dP/dt = [P, B]: the invariant quadratics and the energy are conserved exactly | four algebras, seeded data | 0.4 |
| `bd·geo·16` | `geo_cartan.py` | D_eps = sum L_{e_i} on the labels: D^2 = (p - q) I, simplex boundary for eps = +1, ABS symbol sigma(v)^2 = \|v\|^2 | n = 1..7 | 0.4 |
| `bd·geo·17` | `geo_kepler.py` | Fock's map sends Kepler hodographs of E < 0, = 0, > 0 to geodesics of S^3, R^3, H^3 | three orbits | 0.1 |
| `bd·geo·7` | `geo_lorentz.py` | xi.grad xi = -c (T'/2) xi: the chart c = +1 is retarded (past horizon), c = -1 advanced (future horizon) | five horizons | 0.3 |
| `bd·geo·8` | `geo_lorentz.py` | a hyperbolic direction exists iff s = 1 or t = 1, for every r; strictly hyperbolic iff also r = 0 | n <= 6 | 0.3 |
| `bd·geo·9` | `geo_lorentz.py` | the bivectors of l-perp in Cl(1,n-1) have the brackets of the horizon algebra Cl(0,n-2,1) | n = 3..7 | 0.3 |
| `bd·geo·10` | `geo_lorentz.py` | a totally null plane in the non-degenerate Cl(2,2); null rotations in Cl(1,3); none with min(p,q) = 1 | n = 4, 5 | 0.3 |
| `bd·geo·11` | `geo_lorentz.py` | the Dirac gamma0 is a reference of the right action; the datum is a time orientation | Cl(1,3), five momenta | 0.3 |
| `bd·geo·12` | `geo_lorentz.py` | the unit even versors of Cl(1,2) form SL(2,R) (Lie algebra dimension 3, Killing (2,1)); {x xbar = 1} has dimension 6 | Cl(1,2), Cl(1,3) | 0.3 |
| `bd·geo·1` | `geo_pin.py` | Q = sigma_2(a) + \|a & N\| mod 2: the Pin extension class on the reflection group; commutators in {+-e_a} are the polar form of Q | n <= 9 (n <= 6) | 7.8 |
| `bd·geo·2` | `geo_pin.py` | w is a Z_4 enhancement of #^n RP^2; normalised Gauss sum exp(2 pi i (p-q)/8): clock = ABK invariant | n <= 8 | 7.8 |
| `bd·geo·3` | `geo_pin.py` | the Z_4 enhancements are the 2^n forms w_eps; the orbits of the isometries of dot are the ABK classes | n <= 8 | 7.8 |
| `bd·geo·4` | `geo_pin.py` | twisting by a class a: beta(w + 2 a.x) = beta(w) - 2 w(a); the mirror is the twist by w1 | n <= 7 | 7.8 |
| `bd·geo·5` | `geo_pin.py` | with null generators pi + 2Q is not an enhancement; weight 0 on the null bits gives Gauss sum 2^r G_D, weight 2 gives 0 | n <= 6, every r | 7.8 |
| `bd·geo·6` | `geo_pin.py` | ABS cokernels from the bit-rule types of Cl(0,k): Z2, Z2, 0, Z, 0, 0, 0, Z = KO^{-k}(pt) | k = 1..8 | 7.8 |
| `bd·alg·1` | `alg_core_bw.py` | H^2(Z_2^n; F_2) has dimension n(n+1)/2 and q(a) = c(a,a) is a complete invariant | n <= 4 | 6.4 |
| `bd·alg·2` | `alg_core_bw.py` | the super-commutation form of Cl(p,q) is the dot product; w refines it | n <= 6 | 6.4 |
| `bd·alg·3` | `alg_core_bw.py` | every graded-central-simple twisted group algebra of Z_2^n is Cl(p',q') or M(R)/M(H); BW class = Brown invariant | n <= 4 | 6.4 |
| `bd·alg·4` | `alg_core_bw.py` | explicit block isometries a -> a + \|a & B\| B between triples with equal p - q mod 8 | n <= 8 | 6.4 |
| `bd·alg·5` | `alg_core_bw.py` | the isometry class of Q alone gives the ungraded type R, R2, C, H, H2 | n <= 12 | 6.4 |
| `bd·alg·6` | `alg_core_bw.py` | the super-opposite has the square form of the mirror; Brown(w) + Brown(-w) = 0; the diagonal is a Lagrangian | n <= 5 | 6.4 |
| `bd·alg·7` | `alg_core_bw.py` | null generators: pi + 2Q is not the clock exponent; the clock sum is 2^r times the quotient Gauss sum | n <= 6, r = 1, 2 | 6.4 |
| `bd·alg·8` | `alg_core_bw.py` | the cell is Z^{p,q} mod 2; every characteristic vector c has c.c = p - q mod 8 (van der Blij) | n <= 6 | 6.4 |
| `bd·alg·9` | `alg_core_bw.py` | L_i = R'_i exactly for null generators; the left and twisted right actions span 4^{p+q} 2^r dimensions | n <= 5 | 6.4 |
| `bd·alg·18` | `alg_finite_fields.py` | no n = 2 sign-cochain algebra over F_l is a division algebra | l = 3..23 | 2.2 |
| `bd·alg·21` | `alg_finite_fields.py` | det L_x of the 512 sign-cochain algebras on Z_2^2: 510 have zero divisors, 2 are the quaternions | n = 2 | 2.2 |
| `bd·alg·19` | `alg_finite_fields.py` | the Brauer-Wall class of Cl(p,q) over F_l is the real clock reduced | n even <= 8, l = 3..13 | 2.2 |
| `bd·alg·20` | `alg_finite_fields.py` | over F_p the algebra with squares (a, 0) has J^2 = 0 and quotient F_p[e1]/(e1^2 - a), a field iff a is a non-residue | p = 3..13 | 2.2 |
| `bd·alg·10` | `alg_groups.py` | the blade group {+-e_a}: extraspecial 2^{1+n}_+ (type R) or _- (type H) for n even; centre cyclic iff type C for n odd | n <= 6 | 4.4 |
| `bd·alg·11` | `alg_groups.py` | O(Q) of Cl(0,6) is S_8, the 28 transvections are the transpositions | n = 6 | 4.4 |
| `bd·alg·12` | `alg_groups.py` | 270 maximal totally singular subspaces of Cl(0,8); the 30 through the top label are the doubly-even self-dual codes | n = 8 | 4.4 |
| `bd·alg·13` | `alg_groups.py` | the blade group of Cl(8k,0) is extraspecial of + type (Arf 0) | k = 1, 2, 3 | 4.4 |
| `bd·alg·23` | `alg_groups.py` | over F_2 the tables of Cl(2,0), Cl(1,1), Cl(0,2) coincide: F_2[Z_2^2], not semisimple | n = 2 | 4.4 |
| `bd·alg·14` | `alg_octonion.py` | Cayley-Dickson octonions on the labels: associator (-1)^det, alternative, normed; the Albuquerque-Majid cochain too | 3-bit labels | 6.3 |
| `bd·alg·15` | `alg_octonion.py` | the label automorphisms of O: 2^3.GL(3,2), order 1344, non-split | 3-bit labels | 6.3 |
| `bd·alg·16` | `alg_octonion.py` | split and null octonions as the trio of the doubling bit; the null octonions have J^2 = 0 and quotient H | 3-bit labels | 6.3 |
| `bd·alg·24` | `alg_octonion.py` | the alternative null-pattern cochains: 80, in 5 gauge classes, exactly 1 non-associative (CD(H, 0)) | n = 3 | 6.3 |
| `bd·alg·22` | `alg_octonion.py` | among the 128 quaternionic-line cochains on Z_2^3, 16 (one gauge orbit) are the octonions, 112 have zero divisors | n = 3 | 6.3 |
| `bd·alg·17` | `alg_octonion.py` | Der(O) = g2 (14), the stabiliser of e7 is su(3) (8); no label automorphism but 1 commutes with it | 3-bit labels | 6.3 |
| `bd·cat·1` | `cat_cell.py` | the triple does not fix the cell for r >= 1: 5 pairs of non-isomorphic cells share a triple (full isometry test) | n <= 3 | 0.2 |
| `bd·cat·2` | `cat_cell.py` | with r >= 1 the Gauss sum of pi + 2Q never has the Brown form with phase (p - q) pi/4 | r >= 1, n <= 6 | 0.2 |
| `bd·cat·3` | `cat_cell.py` | w_D (weight 0 on the null bits) is the pull-back of the r = 0 form; radical = null span; Gauss sum 2^r (1+i)^p (1-i)^q | all eps, n <= 5 | 0.2 |
| `bd·cat·4` | `cat_cell.py` | the Gauss sum of w_D equals that of the mother cell Cl(p+r,q+r) and 2^r times that of the quotient Cl(p,q) | r >= 1, n <= 6 | 0.2 |
| `bd·cat·19` | `cat_cohomology.py` | dim H^2 of the contracted label monoid is n(n+1)/2 - r | n <= 5, every r | 0.5 |
| `bd·cat·20` | `cat_cohomology.py` | the radical of every twisted contracted algebra is the span of the labels with a null bit | n <= 3 | 0.5 |
| `bd·cat·21` | `cat_cohomology.py` | the octonions are commutative in (Vec_{Z2^3}, phi = dF, R = F F^T), a symmetric category | 3-bit labels | 0.5 |
| `bd·cat·5` | `cat_frobenius.py` | the top-label form is non-degenerate and super-symmetric, parity n mod 2 | all eps, n <= 7 | 2.2 |
| `bd·cat·6` | `cat_frobenius.py` | the scalar part is symmetric, super-symmetric only for p = q = 0, non-degenerate iff r = 0 | n <= 6 | 2.2 |
| `bd·cat·7` | `cat_frobenius.py` | the parity of a homogeneous Frobenius form is forced only for Cl(0,0,r) | n <= 5 | 2.2 |
| `bd·cat·8` | `cat_frobenius.py` | the super-symmetric Frobenius forms are a torsor under the units of the super-centre Lambda(R^r) | n <= 5 | 2.2 |
| `bd·cat·22` | `cat_frobenius.py` | the window element of the top-label form is 2^n e_{1...1}, of square 0 iff r >= 1 | n <= 5 | 2.2 |
| `bd·cat·16` | `cat_functor.py` | halving phi_t is a natural isomorphism Cl o (halve) => Cl^0 | all eps, n <= 4 | 0.6 |
| `bd·cat·17` | `cat_functor.py` | quotient V -> V/N and mother map are algebra maps; Cl is a functor on q-preserving maps | r >= 1, n <= 4 | 0.6 |
| `bd·cat·18` | `cat_functor.py` | the labels are functorial in the frame only: the 90-degree rotor is not a square in Aut(V,Q,pi) | Cl(2,0) | 0.6 |
| `bd·cat·12` | `cat_modular.py` | theta = i^w is the metric group Sem^p (x) Sem-bar^q; Gauss sum (1+i)^p (1-i)^q | n <= 8 | 1.6 |
| `bd·cat·13` | `cat_modular.py` | a Lagrangian of (V, i^w) exists iff p - q = 0 mod 8; Furey's code is one of the 30 of Cl(0,8) | n <= 8 | 1.6 |
| `bd·cat·14` | `cat_modular.py` | w = x.x mod 4 on Z^{p,q}; the discriminant group of D_{p,q} with twists exp(2 pi i (p-q)/8) | n <= 4 (n <= 10) | 1.6 |
| `bd·cat·15` | `cat_modular.py` | the E_n roots in I_{1,n} have the Cartan Gram matrix, are orthogonal to k, det = k.k = 9 - n | n = 3..12 | 1.6 |
| `bd·cat·23` | `cat_modular.py` | from a Lagrangian: Cl(p,q) = End(S) as superalgebras for the cells of clock 0 | six cells, n <= 8 | 1.6 |
| `bd·cat·9` | `cat_morita.py` | the super-opposite of the bit rule with squares eps is the bit rule with squares -eps | all eps, n <= 6 | 8.4 |
| `bd·cat·10` | `cat_morita.py` | Cl(4,0) = Cl(0,4) as superalgebras, not with their reversions; Cl(5,1) = Cl(1,5) with them | n <= 6 | 8.4 |
| `bd·cat·11` | `cat_morita.py` | the graded product has radical dimension 2^{n+n'} - 2^{p+q+p'+q'}: the Morita classes form the monoid Z_8 x N | n + n' <= 5 | 8.4 |
| `bd·xck·1` | `xck_merge.py` | full isometry test: exactly 5 pairs of non-isomorphic cells share a triple; the horizon algebra Cl(0,2,1) is not among them | n <= 3 | 15.3 |
| `bd·xck·2` | `xck_merge.py` | the 30 Lagrangians of w on Cl(0,8) are the 30 maximal totally singular subspaces of Q through 1...1 | n = 8 | 15.3 |
| `bd·xck·3` | `xck_merge.py` | the weight-0 null-bit sum equals the mother cell sum and 2^r times the quotient sum | r >= 1, n <= 6 | 15.3 |
| `bd·xck·4` | `xck_merge.py` | Cl(2,2): a totally null plane, D != 0, D^2 = 0 | Cl(2,2) | 15.3 |
| `bd·xck·5` | `xck_merge.py` | Cl(1,1,1): hyperbolic direction e0, double root at the null covector e2 | Cl(1,1,1) | 15.3 |
| `bd·xck·6` | `xck_merge.py` | van der Blij: k.k = 9 - n = 1 - n mod 8 in I_{1,n}; c.c = p - q mod 8 for characteristic c in I_{p,q} | n = 3..13; n <= 7 | 15.3 |
| `bd·xck·7` | `xck_merge.py` | roots of E_8 orthogonal to e_8, e_7, ..., e_4: 240, 126, 72, 40, 20, 8 | n = 8 | 15.3 |
| `bd·xck·8` | `xck_merge.py` | the 30 Lagrangians of w on Cl(0,8) are one S_8-orbit (of the extended Hamming code) | n = 8 | 15.3 |
| `bd·hh·1` | `hh_graded.py` | d o d = 0 on the super Hochschild complex; HH^0 of Cl(p,q) in Cl(p,q,r) has dimension 2^r | p + q <= 2, r <= 2 | 6.7 |
| `bd·hh·2` | `hh_graded.py` | every Cl(p,q) is rigid: HH^0 = (1,0), HH^1 = HH^2 = 0 | 1 <= p + q <= 3 | 6.7 |
| `bd·hh·3` | `hh_graded.py` | the relative groups over Lambda(R^r) vanish in degrees 1, 2: every free graded L_r-algebra with fibre Cl(p,q) is Cl(p,q,r) | r = 1: p + q <= 3; r = 2: p + q <= 2 | 6.7 |
| `bd·hh·4` | `hh_graded.py` | over R[eps] every associative deformation of Cl(p,q) is the base change (Z = B) | p + q <= 3 | 6.7 |
| `bd·hh·5` | `hh_graded.py` | controls: HH^1, HH^2 of Cl(0,0,1) and HH^2 of degenerate cells over R are not zero | n <= 3 | 6.7 |
| `bd·hh·6` | `hh_graded.py` | M_(1\|1)(R) from matrix units: HH^0 = (1,0), HH^1 = HH^2 = 0, graded isomorphic to Cl(1,1) | n = 2 | 6.7 |
| `bd·rev·1` | `rev_reversion.py` | <x x~>_0 is positive definite iff q = 0, <x alpha(x~)>_0 iff p = 0 | n <= 10 | 2.6 |
| `bd·rev·2` | `rev_reversion.py` | blocks of five plus and one minus generators give Cl(p-4,q+4) = Cl(p,q) with reversion | p >= 5, q >= 1, n <= 10 | 2.6 |
| `bd·rev·3` | `rev_reversion.py` | same triple, isomorphic reversions iff equal or both indefinite | n <= 10 | 2.6 |
| `bd·rev·4` | `rev_reversion.py` | Clifford conjugation: the same partition; <x x->_0 positive definite iff p = 0 | n <= 10 | 2.6 |
| `bd·rev·5` | `rev_reversion.py` | the dagger e_a^-1: positive for every cell, partition = the triple partition | n <= 10 | 2.6 |
| `bd·rev·6` | `rev_reversion.py` | the global maps e_i -> +-e_sigma(i) w^k miss 13 isomorphic pairs; the block family is needed | n <= 10 | 2.6 |
| `bd·tor·1` | `tor_orbits.py` | unit timelike vectors: one orbit of the even Clifford group, two of the rotors: the datum is a time orientation (2 values) | Cl(1,n-1), n = 2..6 | 14.1 |
| `bd·tor·2` | `tor_orbits.py` | the complex structure J (a unit spatial bivector) under the spatial rotors: 2 orbits at n = 3 (J, -J), 1 for n = 4..6 | coordinate bivectors, n = 3..6 | 14.1 |
| `bd·tor·3` | `tor_orbits.py` | Witt splits (Fock vacua) of Cl(k,k): one orbit of the signed permutations (Pin), two of the even Clifford group and of the rotors (Spin) | coordinate splits, k = 1..4 | 14.1 |
| `bd·tor·4` | `tor_orbits.py` | the graded Lagrangians of a clock-0 cell (Furey's axes among them) are one orbit of the rotor-induced label group | clock-0 cells, n <= 8 | 14.1 |
| `bd·tor·5` | `tor_orbits.py` | Furey's blocks fix the torus H_F (gauge: Stab(omega) is transitive on the 30); the block partition of the 16 axes is a datum: 6720 partitions in 11 orbits | Furey's model | 14.1 |
| `bd·tor·6` | `tor_orbits.py` | orthonormal coordinate frames: one free orbit of the square-preserving signed permutations; 2 orbits of the even Clifford group; 4 or 2 of the rotors | n <= 5 | 14.1 |
| `bd·tor·7` | `tor_orbits.py` | reversion and Clifford conjugation are isomorphic iff n = 0 mod 4 and the cell is indefinite (e_i -> e_i I); reversion = dagger iff q = 0, conjugation = dagger iff p = 0 | n <= 8 | 14.1 |
| `bd·en·1` | `en_weyl.py` | the quadratic module E_n/2E_n: det 9 - n, radical {0, r} for n odd with q(r) = 1 iff n = 3 mod 4, Gauss sum, type, \|O(q)\| (brute force n <= 6) | n = 3..20 | 27.6 |
| `bd·en·2` | `en_weyl.py` | the image of W(E_n) in GL(E_n/2E_n) is all of O(q): certified lower bound = orbit-stabiliser upper bound = order formula | n = 3..20 | 27.6 |
| `bd·en·3` | `en_weyl.py` | \|W(E_n)\| = 12, 120, 1920, 51840, 2903040, 696729600; the kernel of W(E_n) -> O(q) is the centre (orders 2, 1, 1, 1, 2, 2) | n = 3..8 | 27.6 |
| `bd·en·4` | `en_weyl.py` | n odd: for n = 3 mod 4 the image is all of Sp_{n-1}(2) on V/r; for n = 1 mod 4 it holds the 2^{n-1} radical translations and maps onto O(V/r, q mod r) | n = 3..19 odd | 27.6 |
| `bd·en·5` | `en_weyl.py` | the W(E_n)-orbit of a root class is the set of nonsingular vectors outside rad b; the label-weight closure holds to n = 200: the image is generated by all orthogonal transvections | n = 4..20; closure n <= 200 | 27.6 |
| `bd·en·6` | `en_weyl.py` | Gosset descent: the roots of E_n orthogonal to e_n are the roots of E_{n-1}; the W(E_n)-orbit of e_n has 6, 10, 16, 27, 56, 240 elements | n = 3..8 | 27.6 |
| `bd·fur·1` | `fur_commutant.py` | the gauge algebra su(3) + su(2) + u(1)_Y of Furey's model: dimension 12, closed, commutes with omega and the six Peirce projectors | 16-dimensional model | 0.3 |
| `bd·fur·2` | `fur_commutant.py` | its commutant in M16(R) has dimension 22 (M4(R) on the two hypercharge-0 singlets, C on each of C3_O, C2_H, C_C), centre 7; with omega 14, centre 8 | 16-dimensional model | 0.3 |
| `bd·fur·3` | `fur_commutant.py` | an order-3 element of the commutant that normalises the Peirce blocks fixes every block and every cell of Fig. 1: block phases only | 16-dimensional model | 0.3 |
| `bd·fur·4` | `fur_commutant.py` | the exchange of the two hypercharge-0 singlet blocks commutes with the gauge algebra and omega and swaps d_R, (nu_e,e)_L, e_R with b_R, (nu_tau,tau)_L, tau_R; not an automorphism of O | 16-dimensional model | 0.3 |
| `bd·fur·5` | `fur_commutant.py` | 1344 label automorphisms of O; 32 of order 3 fix e7; none but the identity commutes with the colour su(3) | 16-dimensional model | 0.3 |
| `bd·kep·1` | `kep_fock.py` | exact Poisson algebra of L and the Laplace-Runge-Lenz vector A: {A_a, A_b} = -2 mu H L_ab, conserved, \|A\|^2 = mu^2 k^2 + 2 mu H \|L\|^2 | n = 2, 3, symbolic | 0.4 |
| `bd·kep·2` | `kep_fock.py` | one Inonu-Wigner family m(c), c = -2 mu E: so(n+1), e(n), so(n,1) for bound / parabolic / scattering orbits | n = 2, 3, symbolic | 0.4 |
| `bd·kep·3` | `kep_fock.py` | Fock's map is an isometry from g_c = 4\|dp\|^2/(c + \|p\|^2)^2, of constant curvature c, onto sphere / flat / hyperboloid | n = 2, 3, symbolic | 0.4 |
| `bd·kep·4` | `kep_fock.py` | Fock's map carries the Poisson algebra of (L, m(c)) onto the Killing algebra of its target | n = 2, 3; c = 1, 0, -1, 4, -1/4 | 0.4 |
| `bd·kep·5` | `kep_fock.py` | the Kepler algebra is the bivector algebra of Cl(-1,..,-1, s) of step 11 exactly for s = sign E = -eps (core·B16) | n = 2, 3 | 0.4 |
| `bd·kep·6` | `kep_fock.py` | every hodograph goes by Fock's map to a geodesic: a great circle of S^n (E < 0), a line (E = 0), a geodesic of H^n (E > 0) | n = 2, 3, any orbit | 0.4 |

Info lines (printed as `info <id>  …`, not counted as checks, listed in `summary.info` of the json):

- `bd·mat·14` (`mat_En_trio.py`): the Brown invariant 1 − n of I_{1,n}, the Gauss–Milgram phase n of E_n and the clock n of Cl(n,0), for
  n = 3..8. The three numbers are read off the signature formulas, nothing is recomputed, so the line is a read-off and cannot back a `checked` tag.

Two checks recompute an identity that holds by construction; they confirm the computation, they do not test a convention:
`bd·cat·3` (the form w_D is core·B1 on the non-null bits) and `bd·geo·15` (the conservation laws hold for every Lie–Poisson flow with a
symmetric inertia map, whatever the sign of the flow).
