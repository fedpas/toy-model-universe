#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# rebuild selfcheck/bridges/bridges_math.json, the log of the mathematics bridge scripts, from a fresh run of every one of them:
# the families mat, geo, alg, cat, xck, hh, rev, tor, en, fur, kep (every script selfcheck/bridges/<family>_*.py, in this order, sorted by name).
# One row per printed check line (id, script, text, ok, seconds of the whole script); the info lines (read-offs, not checks) go to summary.info.
# Run from anywhere; every path is inside the package; stops at the first error (set -e): a script that exits non-zero, a FAIL line, a missing
# verdict line or a repeated id is an error, and the stored json is then left as it was.
set -e
cd "$(dirname "$0")/bridges"
NEW=bridges_math.json.new
trap 'rm -f "$NEW"' EXIT
python3 -I - "$NEW" <<'PY'
import glob, json, re, subprocess, sys, time
PREFIXES = ['mat', 'geo', 'alg', 'cat', 'xck', 'hh', 'rev', 'tor', 'en', 'fur', 'kep']
LINE = re.compile(r'^(ok  |FAIL) (bd·[a-z]+·\d+)  (.*)$')
INFO = re.compile(r'^info (bd·[a-z]+·\d+)  (.*)$')
VERDICT = re.compile(r'^(\d+)/(\d+) bridge checks hold\.  ALL BRIDGE CHECKS PASS$')
rows, info, scripts, seen = [], [], [], set()
for prefix in PREFIXES:
    for path in sorted(glob.glob(prefix + '_*.py')):
        t0 = time.perf_counter()
        r = subprocess.run([sys.executable, '-I', path], capture_output=True, text=True, timeout=600)
        dt = round(time.perf_counter() - t0, 1)
        out = r.stdout.splitlines()
        if r.returncode != 0:
            sys.stderr.write(r.stdout[-3000:] + r.stderr[-3000:] + f'\nregen: {path} exited {r.returncode}\n'); sys.exit(1)
        mine = []
        for line in out:
            m = LINE.match(line)
            if m:
                if m.group(1) != 'ok  ': sys.exit(f'regen: {path}: {line[:200]}')
                mine.append({'id': m.group(2), 'script': path, 'text': m.group(3), 'ok': True, 'seconds': dt})
                continue
            m = INFO.match(line)
            if m: info.append({'id': m.group(1), 'script': path, 'text': m.group(2)})
        last = [l for l in out if l.strip()][-1]
        v = VERDICT.match(last)
        if not v or int(v.group(1)) != len(mine) or int(v.group(2)) != len(mine):
            sys.exit(f'regen: {path}: the verdict line does not count its {len(mine)} rows: {last[:200]}')
        for x in mine + [i for i in info if i['script'] == path]:
            if not x['id'].startswith('bd·' + prefix + '·'): sys.exit(f'regen: {path} prints {x["id"]}, outside its family {prefix}')
            if x['id'] in seen: sys.exit(f'regen: the id {x["id"]} is printed twice')
            seen.add(x['id'])
        rows += mine
        scripts.append({'script': path, 'rows': len(mine), 'info': sum(1 for i in info if i['script'] == path), 'seconds': dt})
d = {'rows': rows, 'summary': {'family': 'mathematics', 'scripts': scripts, 'rows': len(rows), 'ok': sum(1 for x in rows if x['ok']),
                               'info': info, 'seconds': round(sum(s['seconds'] for s in scripts), 1)}}
json.dump(d, open(sys.argv[1], 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
print(f"{d['summary']['ok']}/{d['summary']['rows']} bridge checks hold in {len(scripts)} scripts ({len(info)} info lines), {d['summary']['seconds']} s")
PY
mv "$NEW" bridges_math.json
echo "regen_bridges_math: done"
