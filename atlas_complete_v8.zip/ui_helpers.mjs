// Shared helper of the browser tests: the language is chosen once in Settings (the gear at the end of the top navigation), not in the control bar.
export async function setLang(pg, lang) {
  const sum = pg.locator('.story-nav .settings > summary');
  if (!(await pg.locator('.story-nav .settings').evaluate(e => e.open))) await sum.click();
  await pg.locator(`.story-nav .settings [data-lang="${lang}"]`).click();
  await pg.waitForTimeout(120);
}
// pages with tabs (furey, shapes, equations): open one tab
export async function tab(pg, id) { await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(150); }
