import React, { useState } from 'react';
import { Fold, Intro, level } from './Fold.jsx';
import K from './matterData.js';
import { MT_PY, MTM_PY } from './matterSelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY, { internalHalves, halfEdges, nodeName } from './matterCopy.js';
import { gensOf, gname } from './yangmillsCopy.js';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';

// Step 5 of the equations page: matter charged under so(m), m = 2 ... 8.
// Numbers come from selfcheck/matter_selfcheck.py (exact) and selfcheck/matter_matrix_check.py (numpy); test_matter.mjs recomputes the structure independently.
const pc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
const PAL = ['#fbbf24', '#34d399', '#60a5fa', '#c084fc', '#f87171', '#2dd4bf', '#fb923c', '#a3e635', '#f472b6', '#94a3b8'];
const download = (name, text, type) => { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } };
const Tags = ({ kinds, lang }) => <>{kinds.map(k => <span key={k} className={'tag ' + k} title={STORY[lang].tagHelp[k]}><Tx>{STORY[lang].tags[k]}</Tx></span>)}</>;

// the two parity halves of the internal cube as graphs; a line = two blades that differ in exactly two bits = where a generator acts
function Halves({ m, sel, lang, t }) {
  const gens = gensOf(m), colour = x => PAL[gens.indexOf(x) % PAL.length], halves = internalHalves(m), W = 170, R = m === 5 ? 62 : 56;
  return <svg className="eq-svg" style={{ maxWidth: 520 }} viewBox="0 0 340 190" role="img" aria-label="The even and odd internal blades and the lines where the generators act" data-m={m}>
    {halves.map((nodes, h) => { const c = [85 + 170 * h, 95], pos = Object.fromEntries(nodes.map((x, k) => [x, [c[0] + R * Math.cos((-90 + 360 * k / nodes.length) * Math.PI / 180), c[1] + R * Math.sin((-90 + 360 * k / nodes.length) * Math.PI / 180)]]));
      return <g key={h}>{halfEdges(m, h).map(([a, b]) => { const g = a ^ b, on = sel == null || g === sel; return <line key={a + '-' + b} className={'mt-edge mt-g' + gens.indexOf(g)} x1={pos[a][0]} y1={pos[a][1]} x2={pos[b][0]} y2={pos[b][1]} stroke={sel == null ? 'currentColor' : colour(g)} strokeWidth={sel == null ? .7 : 1.8} opacity={sel == null ? (m > 4 ? .25 : .45) : on ? .95 : .04}><title>{`[${nodeName(a)}, ${nodeName(b)}] generator ${gname(g)}`}</title></line>; })}
        {nodes.map(x => <g key={x} className="mt-node"><circle cx={pos[x][0]} cy={pos[x][1]} r="4" fill={h ? 'none' : '#8b93a7'} stroke="#8b93a7" strokeWidth="1.2" />{nodes.length <= 8 && <text x={pos[x][0] + (pos[x][0] >= c[0] ? 7 : -7)} y={pos[x][1] + 3} textAnchor={pos[x][0] >= c[0] ? 'start' : 'end'} fontSize="9" fill="currentColor">{nodeName(x)}</text>}</g>)}
        <text x={c[0]} y="186" textAnchor="middle" fontSize="10" fill="currentColor" opacity=".8">{h ? t.oddH : t.evenH}</text></g>; })}</svg>;
}

export default function MatterSection({ lang = 'en', profile = 'Young Learner' }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l], Lad = K.mt.ladder, [m, setM] = useState(3), [sel, setSelRaw] = useState(null), r = { ...Lad[m], m_value: m }, ID = K.mt.identities, views = t.views(r), gens = gensOf(m);
  const pick = k => { setM(k); setSelRaw(null); };
  const edgesPerHalf = 2 ** (m - 2) * (m * (m - 1) / 2);
  return <section className="eq" id="eq-matter" aria-labelledby="eq-mt-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'matter')}</Tx></p><h2 id="eq-mt-h"><Tx>{t.title}</Tx></h2><Intro lang={l} profile={profile} id="matter" lede={t.lede} />
    <div><Tags kinds={['checked', 'standard']} lang={l} /></div>
    <Fold title={t.tableH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="mt-table"><thead><tr>{t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {Object.entries(Lad).map(([k, x]) => <tr key={k} className={+k === m ? 'on' : ''} onClick={() => pick(+k)} style={{ cursor: 'pointer' }}><td><Tx>{k}</Tx></td><td><Tx>{x.internal_dim}</Tx></td><td><Tx>{x.components}</Tx></td><td><Tx>{x.terms_per_equation}</Tx></td><td><Tx>{x.gauge_terms_per_equation}</Tx></td><td><Tx>{x.internal_cell}</Tx></td><td><Tx>{x.minimal_module_real_dim}</Tx> × <Tx>{x.copies_of_each_module}</Tx><Tx>{x.summands === 2 ? ' (×2)' : ''}</Tx></td><td><Tx>{t.names[k]}</Tx></td></tr>)}</tbody></table></div></Fold>
    <h3><Tx>{t.pickH}</Tx></h3><div className="eq-card"><p className="eq-cap"><Tx>{t.pick}</Tx></p>
      <div className="eq-chips" role="group">{Object.keys(Lad).map(k => <button key={k} className={'eq-chip mt-chip' + (+k === m ? ' on' : '')} aria-pressed={+k === m} onClick={() => pick(+k)}><Tx>{k}</Tx></button>)}</div>
      <h4><Tx>{t.picH}</Tx></h4>{m <= 5 ? <><Halves m={m} sel={sel} lang={l} t={t} /><p className="eq-cap mt-cap"><Tx>{t.picCap(m, gens.length, edgesPerHalf)}</Tx></p>
        <div className="eq-chips mt-gens" role="group">{gens.map(g => <button key={g} className={'eq-chip mt-gen' + (sel === g ? ' on' : '')} aria-pressed={sel === g} onClick={() => setSelRaw(sel === g ? null : g)}><Tx>{gname(g)}</Tx></button>)}</div>
        <p className="eq-cap mt-selcap"><Tx>{sel == null ? t.selNone : t.selCap(gname(sel), 2 ** (m - 2))}</Tx></p></> : <p className="eq-cap mt-cap"><Tx>{t.picBig(m)}</Tx></p>}
      <Fold nested title={t.viewsH(m)} open={lv >= 1}><div className="mt-views">{views.map(v => <div key={v.h} className="eq-xr mt-view"><h4><Tx>{v.h}</Tx> <Tags kinds={v.tags} lang={l} /></h4><p><Tx>{v.t}</Tx></p></div>)}</div></Fold></div>
    <Fold title={t.stH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="mt-st"><thead><tr>{t.stCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {Object.entries(K.mt.spacetime).map(([n, x]) => <tr key={n}><td><Tx>{n}</Tx></td><td><Tx>{x.components}</Tx></td><td><Tx>{x.terms_per_equation}</Tx></td><td><Tx>{x.gauge_terms_per_equation}</Tx></td><td><Tx>{Object.values(x.current_corner_masks).join(', ')}</Tx></td><td><Tx>{Object.values(x.current_corner_distance).join(', ')}</Tx></td></tr>)}</tbody></table><p className="eq-cap"><Tx>{t.stNote}</Tx></p></div></Fold>
    <Fold title={t.idH} open={lv >= 1}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="mt-id"><thead><tr>{t.idCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{Object.entries(ID).map(([k, v]) => { const [n, gm] = k.split(','); return <tr key={k}><td><Tx>{n}</Tx></td><td><Tx>{gm}</Tx></td><td><Tx>{v.commutator_identity ? '✓' : '✗'}</Tx></td><td><Tx>{v.gauge_covariance_of_E_first_order ? '✓' : '✗'}</Tx></td><td><Tx>{v.conserved_on_shell ? '✓' : '✗'}</Tx></td><td><Tx>{v.adjoint_covariance ? '✓' : '✗'}</Tx></td><td><Tx>{v.abelian_current_equals_step3_X ? '✓' : '✗'}</Tx></td></tr>; })}</tbody></table><p className="eq-cap"><Tags kinds={['checked']} lang={l} /> <Tx>{t.idNote}</Tx></p></div></Fold>
    <Fold title={t.xrH} open={lv >= 2}>{t.xr.map(([k, txt], i) => <div key={i} className="eq-xr"><p><Tags kinds={[k]} lang={l} /> <Tx>{txt}</Tx></p></div>)}</Fold>
    <Fold title={t.matH} open={lv >= 2}><div className="eq-card"><p><Tags kinds={['checked', 'standard']} lang={l} /> <Tx>{t.mat}</Tx></p><p className="eq-cap"><Tx>{t.numbers}</Tx></p></div></Fold>
    <div>{t.open.map(([k, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={[k]} lang={l} /></div><p><Tx>{txt}</Tx></p></div>)}</div>
    <Fold title={t.dl.h} open={lv >= 2}><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('matter_selfcheck.py', MT_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('matter_matrix_check.py', MTM_PY, 'text/x-python')}><Tx>{t.dl.py2}</Tx></button><button className="eq-btn" onClick={() => download('matter.json', JSON.stringify(K.mt, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p></Fold></section>;
}
