# Update v7 (since v6)

## What the 19:30 list asked, and what was done
| Request | Done |
|---|---|
| Play button on the segment widget ("free, with a spring, with a reversed spring") | A play/pause/step/reset bar on every live widget of the rigid-body page that lacked one. |
| Test 1 (Maxwell): charges moving in E and B fields | New tab **Charges**: six presets (circle, hyperbola, E×B drift, spiral drift, relativistic Kepler orbit, plane wave), the force drawn on a simplex, its symbolic table, live readouts and a closed-form check line. `selfcheck/maxwell_selfcheck.py` has a `charges` block: 14 rows, 9 exact (the table of force terms against an independent Clifford product, u·u conserved, B does no work, circle and hyperbola by rational parametrisation, drift frames at Pythagorean (E,B), the point charge, the plane wave) and 5 numeric (RK4: cyclotron radius, hyperbolic x(t), drift velocity, wave drift, relativistic perihelion advance). |
| Furey page: misaligned "Three generations · a test of the 256"; split into three tabs | Three tabs; the block is aligned. |
| Shapes: steps as buttons that fill the page below; same for Equations (same frame for every step) | Done: one step at a time, in the same frame, tab-routed (`#page/step`). |
| Cut useless sentences ("Whether this is the gravity of the model…", "three generations not happening" outside the SM-particle context) | Copy audit of every page, EN and IT; the three-generations remark stays only where particles are discussed. |
| Speed check: a standalone downloadable webapp to test several scenarios | `label_bench.html` (version 1.1.0): one file, no network, Worker-based, seven scenarios, JSON/CSV export, compare with another run. New in 1.1.0: the **Product** scenario (below). |
| Language set once, not in the scrolling bar; lens count | Language and audience live in Settings; every statement of the lens count updated. |
| Independent unbiased replication from first principles | `replication/`: a self-contained brief, 52 exact answers computed independently, a grader, and the runs (below). |
| "Are you sure that in higher dimensions you lose speed? The point of reaching 8 is a new base unit, like M16(R) for R." | You were right to doubt it. I had only counted the plain bit-rule product (4^n terms for dense multivectors). With n = 2k, Cl(k,k) is the algebra of 2^k × 2^k real matrices, a matrix product is 8^k multiplications, so 2^(n/2) times fewer, and Cl(N+8) = M16(Cl(N)) makes a product 4096 products in Cl(N) instead of 65536 times as many terms. `selfcheck/matrixrep_check.py` builds the representation exactly (signed permutation matrices) and checks all of it in integer arithmetic; `productKernels.js` is the same thing in JavaScript; the benchmark times it. See below. |
| Playing widgets follow slider changes; paused ones do not move | Done for the chain, the top, the orbits and the charges; `test_livetweak_ui.mjs`. |
| Better view of "D^μF_{μν} = J_ν" | A typesetter (`mathTextCore.js`, `MathText.jsx`) draws sub- and superscripts and math italics inside sentences on every page; file names and prose are left alone (`test_mathtext*.mjs`). |

## The matrix route, in numbers (one machine; timed, not proved)
Exact (Python integers, 7 s): Cl(k,k) = M(2^k, R) at n = 2, 4, 6, 8, 10 (every pair of blades up to n = 8, 20000 sampled pairs at n = 10; independent; random products equal); Cl(N+8) = M16(Cl(N)) for N = 0..3 (relations, independence, 4096 products, ratio 16); a motor product of R(n,0,1) is three products in the Euclidean Cl(n) (n = 2..5); three negative controls fail as they should.
Timed (node 22, 2-core Xeon, batches ≥ 60 ms, median of 7), bit rule with a sign table against the matrix route: n = 2, 4, 6, 8, 10, 12 → 0.26×, 0.13×, 0.51×, 3.8×, 20×, 57×; against the plain rule 0.14× … 632×. The 16 × 16 blocks alone: 8.1× at n = 10, 11× at n = 12.
So for **dense** products the gain grows with n and the route loses at small n (n = 2–6 in the node run; the crossing is machine dependent), because the conversion costs more than it saves. A product of a few blades is a different case and is not timed. The matrix route was not tested before this update.
Run it yourself: `label_bench.html` → Product, or `node selfcheck/bench_labels.mjs`.

## Independent replication (`replication/`)
52 exact answers in eight blocks (Clifford classification, the sign rule, the product counts, charges in fields, E8 roots, three fermion modes and SU(3), a rotor, the Moon). Reference answers are computed by routes different from the app's (`reference/make_reference.py`). Claude Fable and Claude Opus, each given only the brief: 52/52 and 52/52. Limits, stated plainly: the blindness is by instruction (the file system was not sandboxed; each run lists the files it read in `notes.md`); the questions are textbook results, so agreement shows the reference is right, not that the atlas's interpretive claims are; version 1 of the brief gave `M(2,H)`, the true answer to Cl(1,3), as a format example (both models derived it independently; fixed in version 2, `runs/*/INSTRUCTIONS.md` are the copies they saw); no OpenAI model has been run (no access from here): `PROMPT_FOR_ANOTHER_MODEL.txt` says how to.

## Tests (all pass at this version)
25 data suites (`node test_*.mjs` without `_ui`), 16 browser suites (need the build harness), `test_label_bench.mjs` (163 checks, Playwright), `test_product.mjs` (43 checks). New: `test_charges*.mjs`, `test_livetweak_ui.mjs`, `test_mathtext*.mjs`, `test_product.mjs`; `test_persona.mjs` now ties the persona's benchmark numbers to `benchData.js` and the matrix-route facts to `matrixrep.json`.

## Not done / open
Cross-vendor replication run; the matrix route for non-neutral signatures was checked for the period-8 step (N = 0..3) but timed only for the neutral Cl(k,k); the benchmark's comparison table with a second run still covers vertices, contact and outline only; what a charge means in the ultrahyperbolic (2,2) cell is not touched.
