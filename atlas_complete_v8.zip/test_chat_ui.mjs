// The chat page against a faked /api: what a reader sees when the route streams text, when it reports an error half way, when it refuses (429, 403), and when it is down.
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
const b = await chromium.launch(); const errs = [];
const DIST = process.env.ATLAS_DIST || '/home/claude/ui/dist';          // the built page; the work-copy script rewrites /home/claude/ui, or set ATLAS_DIST
// a fetch to /api from a file:// page is refused by the browser before it can be faked, so the built page is served over http from a throwaway server
const srv = http.createServer((q, r) => { const f = path.join(DIST, q.url.split('?')[0].replace(/^\/+/, '') || 'app.html'); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' }); r.end(d); }); });
await new Promise(r => srv.listen(0, r)); const URL = `http://localhost:${srv.address().port}/app.html#ask`;
const sse = parts => parts.map(p => `data: ${JSON.stringify(p)}\n\n`).join('');
const delta = t => ({ type: 'content_block_delta', delta: { text: t } });
const CASES = [
  ['text', 200, sse([delta('Hello '), delta('atlas')]), /Hello atlas/],
  ['error half way', 200, sse([delta('Partial'), { type: 'error', message: 'The model service was interrupted.' }]), 'UNAVAILABLE'],
  ['error only', 200, sse([{ type: 'error', message: 'The OpenAI model service is unavailable.' }]), 'UNAVAILABLE'],
  ['429', 429, 'Too many requests. Try again shortly.', 'UNAVAILABLE'],
  ['403', 403, 'Origin not allowed.', 'UNAVAILABLE'],
  ['502', 502, 'The model service is unavailable.', 'UNAVAILABLE'],
];
for (const lang of ['en', 'it']) for (const [name, status, body, want] of CASES) {
  const pg = await b.newPage({ viewport: { width: 1100, height: 800 } });
  pg.on('pageerror', e => errs.push(`${lang}/${name}: ${e.message}`));
  await pg.route('**/api/chat', r => r.fulfill({ status, contentType: status === 200 ? 'text/event-stream' : 'text/plain', body }));
  await pg.goto(URL); await pg.waitForTimeout(300); if (lang === 'it') await setLang(pg, 'it');
  await pg.locator('.chat-composer textarea').fill('What is checked?'); await pg.locator('.ask-button').click(); await pg.waitForTimeout(500);
  const ans = ((await pg.locator('article.answer').first().textContent().catch(() => '')) || '').trim();
  const un = lang === 'it' ? 'Il servizio chat non è disponibile.' : 'Chat is unavailable.';
  if (want === 'UNAVAILABLE') { if (ans !== un) errs.push(`${lang}/${name}: expected "${un}", the page shows "${ans}"`); }
  else if (!want.test(ans)) errs.push(`${lang}/${name}: expected ${want}, the page shows "${ans}"`);
  if (await pg.locator('.ask-button').isDisabled()) errs.push(`${lang}/${name}: the Ask button stays disabled`);
  await pg.close();
}
{ // the OpenAI side, and the match mode (one side fails, the other speaks)
  const pg = await b.newPage({ viewport: { width: 1100, height: 800 } }); pg.on('pageerror', e => errs.push('match: ' + e.message));
  await pg.route('**/api/chat', r => r.fulfill({ status: 200, contentType: 'text/event-stream', body: sse([delta('Claude side')]) }));
  await pg.route('**/api/chat-openai', r => r.fulfill({ status: 200, contentType: 'text/event-stream', body: sse([{ type: 'status', message: 'OpenAI o3 is reasoning…' }, { type: 'error', message: 'down' }]) }));
  await pg.goto(URL); await pg.waitForTimeout(300); await pg.locator('.chat-composer textarea').fill('Compare'); await pg.locator('.match-button').click(); await pg.waitForTimeout(600);
  const cols = await pg.locator('.agent-column').allTextContents();
  if (!/Claude side/.test(cols[0] || '')) errs.push('match: the Claude column shows "' + cols[0] + '"');
  if (!/Chat is unavailable\./.test(cols[1] || '')) errs.push('match: the OpenAI column shows "' + cols[1] + '"');
  await pg.close();
}
await b.close(); srv.close(); console.log(errs.length ? errs.join('\n') + '\n' + errs.length + ' FAILURES' : 'ALL CHAT UI CHECKS PASS'); process.exit(errs.length ? 1 : 0);
