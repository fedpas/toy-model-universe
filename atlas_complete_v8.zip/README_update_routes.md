# Update: the two chat routes and the chat page's error handling

Requested before the audit ("fix the routes"). Made in a staging copy; `out/` and `audit/pkg/` are untouched until this is rolled in.

## What was wrong (all observed, none exploited)
| Where | Problem |
|---|---|
| `api/chat.js`, `api/chat-openai.js` | No origin check: any page on the web could call the routes from a visitor's browser, and any script could call them directly. |
| both | No rate limit and no cap on streams in flight. |
| both | `max_tokens` / `max_completion_tokens` of 32768 on Opus 4.6 and o3: one anonymous call could spend a large share of a budget. |
| both | No limit on the size of the request body; no content-type check. |
| both | Messages were cut to the last 12, but a list that began with an assistant turn was sent upstream (the model API refuses it, so the caller saw a 502), and a blank or non-user last turn was accepted. |
| `api/chat-openai.js` | When the reader left, the loop kept reading from the upstream call to its end (the cost went on). |
| both | No timeout on the upstream call. |
| `api/chat-openai.js` | The upstream error text (500 characters) was written to the log. |
| `App.jsx` (`readStream`) | An error event from a route was thrown inside the same `try` that parses a line, and the `catch` swallowed it: the page showed an empty or half answer and no message. |
| audit harness `stubs/streamdown.jsx` | No `import React`: any chat answer crashed the harness build ("React is not defined"). Scaffold only, not in the zip. |

## What changed
New `lib/chatGuard.js`, used by both routes, so they now behave the same way:
- **Method, key, origin, content type**, in that order, before the body is read. Origin: the request's own host, an entry of `CHAT_ALLOWED_ORIGINS`, or (with no Origin header) `Sec-Fetch-Site: same-origin`. No CORS header is sent.
- **Rate limit**: per client and route (default 6 a minute), per route and instance (default 60 a minute), and at most 12 streams in flight (`CHAT_RATE_PER_MIN`, `CHAT_GLOBAL_PER_MIN`, `CHAT_MAX_INFLIGHT`). 429 with `Retry-After`. The table of clients cannot grow without limit.
- **Body**: at most 128 KB, read as it arrives; JSON object only; 413, 415 and 400 for what is not.
- **Context**: language, audience and metric as before; blank turns dropped; the first turn is the user's and the last one is the question; `isMatchMode` counts only when it is exactly `true`.
- **Token caps**: 8192 (Claude) and 16384 (o3, which includes its reasoning tokens), configurable with `CHAT_MAX_TOKENS` and `CHAT_MAX_TOKENS_OPENAI`, never above 32768. **These two defaults are my choice, not yours: a long answer can now be cut off, and the page does not say so.**
- **Timeout** 240 s (`CHAT_TIMEOUT_MS`), and the upstream call is aborted when the reader leaves or the request is cancelled, on both routes.
- **Errors**: upstream failures give 502 (429 stays 429) with a fixed sentence; a stream that breaks half way ends with an `error` event; nothing from upstream is returned, and the logs carry a status or an error name only, never a key, a message or the prompt.
- `App.jsx`: the line is parsed first; an `error` event now reaches the page, which shows "Chat is unavailable." (EN) or "Il servizio chat non è disponibile." (IT). In the match view each side fails on its own.

## What this does not do
There is still **no authentication**: the chat is public. The Origin header and the client address can be set by whoever sends the request, and the counters live in one edge instance, not across instances, so a determined script can still reach the models at the rate the limits allow, on every instance. Set a **monthly spend limit at both providers** (an operator action, not code) and, if wanted, a rate rule at the host's firewall. The limits above bound the cost per instance; they do not remove it.

## Tests
- `test_routes.mjs` (88 checks, mocked upstream, no network): method, key, origin (allowed, refused, malformed, allow-list), content type, body size (declared and streamed), invalid contexts (10 kinds, both routes), cleaning, what goes upstream (URL, key header, model, caps, system prompt), secrets, upstream 5xx / 429 / network failure / stream breaking, cancellation, client disconnect, timeout, streams in flight, rate limits (per client, per route, global, the keying by address), the limiter table, and the source files. Of 13 deliberate breakages of the guard and the page, 11 are caught by this test (two of them by crashing it); of the other two, one added a status number to a fixed error sentence (harmless) and one was an edit that changed nothing. The real removal of the page's throw is caught by `test_chat_ui.mjs`.
- `test_chat_ui.mjs` (browser, EN and IT): text, an error half way, an error only, 429, 403, 502, and the match view with one side down. Removing the one line that throws an error event makes five of its checks fail.
- `test_persona.mjs` still passes.
