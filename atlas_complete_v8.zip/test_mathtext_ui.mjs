import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
// Formulas inside sentences are typeset on every page: no raw X_{..} / X^{..} markup is left in the visible text (outside code and file names), and the Maxwell equation is drawn with scripts.
const b = await chromium.launch(); const errs = []; const left = {};
const PAGES = ['rule', 'atlas', 'maxwell', 'furey', 'shapes', 'equations', 'map', 'ask'];
const RAW = /(?<![A-Za-z0-9_.\/])[A-Za-zα-ωΑ-Ω][_^](?:\{[^}]{1,20}\}|[A-Za-zα-ω0-9]{1,3}(?![A-Za-z0-9]))|\)\^[{A-Za-z0-9]|(?<![A-Za-z0-9.])\d\^[{A-Za-z0-9]/;
let runs = 0;
for (const lang of ['en', 'it']) for (const page of PAGES) {
  const ctx = await b.newContext({ viewport: { width: 1000, height: 900 } }); const pg = await ctx.newPage();
  pg.on('pageerror', e => errs.push(`${lang}/${page}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${lang}/${page} console: ${m.text()}`));
  await pg.goto('file:///home/claude/ui/dist/app.html#' + page); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg,'it');
  const ids = await pg.locator('.tabbar [data-tab]').evaluateAll(els => els.map(e => e.getAttribute('data-tab')));
  for (const id of ids.length ? ids : [null]) {
    if (id) { await pg.locator(`.tabbar [data-tab="${id}"]`).click(); await pg.waitForTimeout(120); }
    await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(250);
    runs += await pg.locator('.mt').count();
    const hits = await pg.evaluate(src => {
      const re = new RegExp(src), out = [], w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      for (let n = w.nextNode(); n; n = w.nextNode()) { const p = n.parentElement; if (!p || p.closest('code,pre,style,script,textarea,.mt,svg text,[data-raw]')) continue; const t = n.nodeValue; const m = t.match(re); if (m) out.push(t.slice(Math.max(0, m.index - 25), m.index + 40).replace(/\s+/g, ' ')); }
      return out;
    }, RAW.source);
    if (hits.length) left[`${lang}/${page}${id ? '/' + id : ''}`] = hits.slice(0, 6);
  }
  if (page === 'equations' && lang === 'en') {
    await pg.locator('.tabbar [data-tab="matter"]').click(); await pg.waitForTimeout(150); await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(150);
    const el = pg.locator('.mt[data-raw="D^μF_{μν} = κj_ν"]').first();
    if (!(await el.count())) errs.push('the coupling equation is not typeset');
    else { const h = await el.innerHTML(); if (!/<sup>.*μ.*<\/sup>/.test(h) || !/<sub>.*μν.*<\/sub>/.test(h) || /[_^]/.test(await el.textContent())) errs.push('D^μF_{μν} is not drawn with scripts: ' + h.slice(0, 200)); }
  }
  await ctx.close();
}
if (runs < 600) errs.push('only ' + runs + ' formula runs over the pages');
for (const [k, v] of Object.entries(left)) errs.push(`raw script markup left on ${k}: ${v.join(' || ')}`);
console.log(errs.length ? errs.join('\n') : 'MATHTEXT UI OK (' + runs + ' formula runs)');
await b.close(); process.exit(errs.length ? 1 : 0);
