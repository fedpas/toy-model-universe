import React, { useEffect, useRef, useState } from 'react';

// One story, five pages. Every page says what the previous page showed, what it does, and what it hands on.
// Status vocabulary used everywhere: checked (exact arithmetic or script), standard (textbook mathematics),
// ours (the reading we propose), open (not established).
import { PAGES, STORY } from './storyCopy.js';
import { Intro } from './Fold.jsx';
import { pageEyebrow, STEP_GROUPS, NAV_NAMES, stepNo } from './steps.js';
import { TREE, flat } from './mapData.js';
import { NODES } from './mapCopy.js';
import { Tx } from './MathText.jsx';
export { PAGES, STORY };

const STYLE = `
.story-nav{position:sticky;top:0;z-index:20;display:flex;gap:6px;flex-wrap:wrap;align-items:center;padding:8px 16px;background:var(--bg,#0b1020);border-bottom:1px solid rgba(128,128,128,.3)}
.story-nav .brand{margin-right:12px;font-weight:600;text-decoration:none;color:inherit}
.story-nav button{background:none;border:1px solid rgba(128,128,128,.4);border-radius:999px;padding:4px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}
.story-nav button.active{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.story-nav .settings{margin-left:auto;position:relative}.settings>summary{cursor:pointer;list-style:none;opacity:.75;font-size:.85em;padding:4px 10px;border:1px solid rgba(128,128,128,.4);border-radius:999px}.settings>summary::-webkit-details-marker{display:none}
.settings[open]>summary{opacity:1;border-color:#4aa8ff}.settings .settings-pop{position:absolute;right:0;top:calc(100% + 8px);z-index:30;min-width:230px;padding:12px;background:var(--bg,#0b1020);border:1px solid rgba(128,128,128,.45);border-radius:10px;box-shadow:0 8px 24px rgba(0,0,0,.35)}
.settings .settings-pop p{margin:0 0 6px;font-size:.8em;letter-spacing:.06em;opacity:.75}.settings .settings-pop small{display:block;margin-top:8px;opacity:.65}.settings .settings-pop button{margin-right:6px}
.view-picker{max-width:1000px;margin:12px auto;padding:0 16px;display:flex;flex-wrap:wrap;gap:6px;align-items:center}.tabbar{max-width:1000px;margin:12px auto 0;padding:0 16px;scroll-margin-top:60px}
.tabbar [role=tablist]{display:flex;flex-wrap:wrap;gap:6px;padding:2px 0 8px}
@media(max-width:700px){.tabbar [role=tablist]{flex-wrap:nowrap;overflow-x:auto;scrollbar-width:thin}}
.tabbar .tab{flex:0 0 auto;white-space:nowrap;background:none;border:1px solid rgba(128,128,128,.4);border-radius:8px;padding:6px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}
.tabbar .tab.on{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.glance{max-width:1000px;margin:10px auto 0;padding:8px 16px;border-left:3px solid rgba(80,170,255,.55);font-size:.85em}.glance p{margin:.2em 0}.glance .gl-k{opacity:.7;margin-right:6px;letter-spacing:.05em;font-size:.9em}.glance code{font-size:.95em}
.stepnav{max-width:1000px;margin:20px auto 0;padding:12px 16px;display:flex;justify-content:space-between;gap:12px;border-top:1px solid rgba(128,128,128,.3)}
.stepnav button{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:8px 14px;color:inherit;cursor:pointer;font:inherit;text-align:left;max-width:48%}.stepnav .gl-map{opacity:.8;font-size:.85em}
.view-picker p{margin:0 8px 0 0;font-size:.8em;letter-spacing:.06em;opacity:.75}
.view-picker button{background:none;border:1px solid rgba(128,128,128,.4);border-radius:999px;padding:4px 12px;color:inherit;cursor:pointer;font:inherit;font-size:.85em}.view-picker button.active{background:rgba(80,170,255,.2);border-color:#4aa8ff}
.page-intro{max-width:1000px;margin:24px auto 8px;padding:0 16px}
.page-intro h2{margin:.2em 0}
.page-intro .before{opacity:.7;font-size:.9em;margin:.2em 0}
.tag{display:inline-block;margin:2px 6px 2px 0;padding:1px 8px;border-radius:6px;border:1px solid;font-size:.78em;white-space:nowrap}
.tag.checked{color:#34d399}.tag.standard{color:#60a5fa}.tag.ours{color:#fbbf24}.tag.open{color:#f87171}
.page-tags .tag{white-space:normal;display:block;max-width:100%;overflow-wrap:anywhere}
.page-tags{margin:8px 0}
.page-tags details{font-size:.8em;opacity:.85}
.eq-fold{margin:12px 0}.eq-fold>summary{cursor:pointer;font-weight:600;padding:6px 0}.eq-short{font-size:1.05em}.page-intro .lede{font-size:1em;margin:.4em 0}.page-intro .eq-fold>summary{cursor:pointer;font-weight:600}
.story-pager{display:flex;justify-content:space-between;gap:16px;max-width:1000px;margin:32px auto;padding:16px;border-top:1px solid rgba(128,128,128,.3)}
.story-pager button{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:8px 14px;color:inherit;cursor:pointer;font:inherit;text-align:left;max-width:48%}
.story-pager small{display:block;opacity:.75;margin-top:4px}
`;

// The language is chosen once, in Settings, and remembered in this browser; it is not a control that scrolls with the page.
const LANG_KEY = 'atlas.lang';
export const readLang = () => {
  try { const v = localStorage.getItem(LANG_KEY); if (v === 'en' || v === 'it') return v; } catch { /* storage can be blocked */ }
  try { if (String(navigator.language || '').toLowerCase().startsWith('it')) return 'it'; } catch { /* ignore */ }
  return 'en';
};
export const saveLang = l => { try { localStorage.setItem(LANG_KEY, l); } catch { /* ignore */ } };

// A page may have tabs: the address is #page or #page/tab (for example #equations/rigid), so that every tab can be linked to.
export const SUBS = { maxwell: ['views', 'charges', 'ladders'], furey: ['dictionary', 'threegen', 'findings'], shapes: STEP_GROUPS.shapes, equations: [...STEP_GROUPS.eq, 'tally'] };
const FUREY_ANCHOR = { dictionary: 'dictionary', 'tg-h': 'threegen', findings: 'findings' };
// the tab that holds an anchor of the Map ("Go there"), or null
export const anchorSub = (page, a) => {
  if (!a || !SUBS[page]) return null;
  const id = page === 'equations' ? a.replace(/^eq-/, '') : page === 'shapes' ? a.replace(/^sh-/, '') : page === 'maxwell' ? a.replace(/^mx-/, '') : FUREY_ANCHOR[a];
  return SUBS[page].includes(id) ? id : null;
};
const hashParts = () => (typeof location !== 'undefined' ? location.hash : '').replace('#', '').split('/');
export function usePage() {
  const read = () => { const h = hashParts()[0]; return PAGES.includes(h) ? h : 'rule'; };
  const [page, setPageState] = useState(read);
  useEffect(() => { const f = () => setPageState(read()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
  const setPage = (p, sub) => { try { history.replaceState(null, '', '#' + p + (sub ? '/' + sub : '')); } catch { /* ignore */ } setPageState(p); if (typeof window !== 'undefined') window.scrollTo?.(0, 0); };
  return [page, setPage];
}
export function useSub(page) {
  const ids = SUBS[page];
  const read = () => { const [h, s] = hashParts(); return h === page && ids.includes(s) ? s : ids[0]; };
  const [sub, setSubState] = useState(read);
  useEffect(() => { const f = () => setSubState(read()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, [page]);
  const setSub = id => { try { history.replaceState(null, '', '#' + page + '/' + id); } catch { /* ignore */ } setSubState(id); };
  return [sub, setSub];
}
export const tabLabel = (lang, page, id) => {
  const n = (NAV_NAMES[lang] || NAV_NAMES.en)[id];
  if (page === 'furey') return (NODES[lang] || NODES.en)[id][0];
  const group = page === 'equations' ? 'eq' : page;
  return (STEP_GROUPS[group] || []).includes(id) ? stepNo(group, id) + ' · ' + n : n;
};

// the tab bar of a page; arrow keys move between tabs
export function TabBar({ lang, page, active, onPick }) {
  const s = STORY[lang] || STORY.en, ids = SUBS[page], ref = useRef(null);
  const pick = id => { onPick(id); const r = ref.current; if (r && r.scrollIntoView) setTimeout(() => r.scrollIntoView({ block: 'start' }), 0); };
  const key = (e, i) => { const d = e.key === 'ArrowRight' ? 1 : e.key === 'ArrowLeft' ? -1 : 0; if (!d) return; e.preventDefault(); const id = ids[(i + d + ids.length) % ids.length]; onPick(id); setTimeout(() => ref.current?.querySelector(`[data-tab="${id}"]`)?.focus(), 0); };
  return <div className="tabbar" ref={ref}><div role="tablist" aria-label={s.tabsLbl[page]}>{ids.map((id, i) => <button key={id} role="tab" id={'tab-' + page + '-' + id} data-tab={id} aria-selected={id === active} aria-controls={'panel-' + page} tabIndex={id === active ? 0 : -1} className={'tab' + (id === active ? ' on' : '')} onClick={() => pick(id)} onKeyDown={e => key(e, i)}><Tx>{tabLabel(lang, page, id)}</Tx></button>)}</div></div>;
}

// the frame every tab shares: an at-a-glance strip (status, script, what is established), the tab's content, then previous / next and the Map
export function TabPanel({ lang, page, id, onPick, children, goMap }) {
  const s = STORY[lang] || STORY.en, ids = SUBS[page], i = ids.indexOf(id), prev = ids[i - 1], next = ids[i + 1];
  const node = flat(TREE).find(x => x.id === id && x.go[0] === page), txt = node && (NODES[lang] || NODES.en)[id];
  return <div role="tabpanel" id={'panel-' + page} aria-labelledby={'tab-' + page + '-' + id} data-sub={id}>
    {node && <aside className="glance" aria-label={s.glance}><p><span className="gl-k"><Tx>{s.glance.toUpperCase()}</Tx></span>{node.tags.map(k => <span key={k} className={'tag ' + k} title={s.tagHelp[k]}><Tx>{s.tags[k]}</Tx></span>)}</p>
      <p><span className="gl-k"><Tx>{s.checkedBy.toUpperCase()}</Tx></span><code><Tx>{node.script}</Tx></code></p>{txt && <p><Tx>{txt[1]}</Tx></p>}</aside>}
    {children}
    <nav className="stepnav" aria-label={s.tabsLbl[page]}><div>{prev && <button className="sn-prev" onClick={() => onPick(prev)}>← <Tx>{s.prevStep}</Tx>: <Tx>{tabLabel(lang, page, prev)}</Tx></button>}</div>
      <div>{goMap && <button className="gl-map" onClick={() => goMap('map', 'map-top')}><Tx>{s.onMap}</Tx></button>}</div>
      <div>{next && <button className="sn-next" onClick={() => onPick(next)}><Tx>{s.nextStep}</Tx>: <Tx>{tabLabel(lang, page, next)}</Tx> →</button>}</div></nav></div>;
}

export function Settings({ lang, setLang }) {
  const s = STORY[lang] || STORY.en, ref = useRef(null);
  const pick = l => { setLang(l); saveLang(l); if (ref.current) ref.current.open = false; };
  return <details className="settings" ref={ref}><summary aria-label={s.settings}>⚙ <Tx>{s.settings}</Tx></summary>
    <div className="settings-pop" role="group" aria-label={s.langLabel}><p><Tx>{s.langLabel.toUpperCase()}</Tx></p>
      <button className={lang === 'en' ? 'active' : ''} data-lang="en" aria-pressed={lang === 'en'} onClick={() => pick('en')}>English</button>
      <button className={lang === 'it' ? 'active' : ''} data-lang="it" aria-pressed={lang === 'it'} onClick={() => pick('it')}>Italiano</button><small><Tx>{s.langNote}</Tx></small></div></details>;
}

export function StoryNav({ lang, setLang, page, setPage }) {
  const s = STORY[lang] || STORY.en;
  return <><style>{STYLE}</style><nav className="story-nav" aria-label="Story pages"><a className="brand" href="#rule" onClick={() => setPage('rule')}><span>01</span> CASCADE ATLAS</a>
    {PAGES.map((p, i) => <button key={p} className={p === page ? 'active' : ''} aria-current={p === page ? 'page' : undefined} onClick={() => setPage(p)}><Tx>{i + 1}</Tx> · <Tx>{s.nav[p]}</Tx></button>)}
    {setLang && <Settings lang={lang} setLang={setLang} />}</nav></>;
}

export function PageIntro({ lang, page, profile = 'Mathematician' }) {
  const s = STORY[lang] || STORY.en, p = s.pages[page], i = PAGES.indexOf(page);
  return <section className="page-intro"><p className="eyebrow"><Tx>{pageEyebrow(lang in STORY ? lang : 'en', i + 1, PAGES.length)}</Tx></p><h2><Tx>{p.h}</Tx></h2>
    {p.before && <p className="before"><b><Tx>{s.before}</Tx>:</b> <Tx>{p.before}</Tx></p>}
    <Intro lang={lang} profile={profile} id={'page_' + page} lede={p.does} />
    <div className="page-tags">{p.tags.map(([k, txt]) => <span key={txt} className={'tag ' + k} title={s.tagHelp[k]}><Tx>{s.tags[k]}</Tx> · <Tx>{txt}</Tx></span>)}
      <details><summary><Tx>{s.legend}</Tx></summary>{Object.keys(s.tags).map(k => <p key={k}><span className={'tag ' + k}><Tx>{s.tags[k]}</Tx></span> <Tx>{s.tagHelp[k]}</Tx></p>)}</details></div></section>;
}

export function StoryPager({ lang, page, setPage }) {
  const s = STORY[lang] || STORY.en, i = PAGES.indexOf(page), prev = PAGES[i - 1], next = PAGES[i + 1];
  return <div className="story-pager"><div>{prev && <button onClick={() => setPage(prev)}>← <Tx>{s.prev}</Tx>: <Tx>{s.nav[prev]}</Tx></button>}</div>
    <div>{next && <button onClick={() => setPage(next)}><Tx>{s.next}</Tx>: <Tx>{s.nav[next]}</Tx> →<small><Tx>{s.pages[page].after}</Tx></small></button>}</div></div>;
}
