// Readable maths inside sentences. The copy of the pages writes formulas in plain text: D^μF_{μν} = J_ν, e^{θB}, B_an, (−1)^k V x V⁻¹, 2^{n−1}.
// parseMath(text) finds them and returns a small tree; MathText.jsx draws it (real subscripts and superscripts, math letters in italic, one run per formula).
// It is conservative: a script is only read after one base symbol (a single letter, ∇, ∂, a closing bracket or a number), never inside a longer word,
// so file names such as gravity_selfcheck.py, snake_case words and ordinary prose are left alone.
const isLetter = c => !!c && /\p{L}/u.test(c);
const isDigit = c => !!c && /[0-9]/.test(c);
const isGreek = c => !!c && /[Ͱ-Ͽ]/.test(c);
const isLatin = c => !!c && /[A-Za-z]/.test(c);
const BASE_SYM = '∇∂';
const GLUE_OPS = /[=≠≈≡<>≤≥+−\-×·∘∈∉⊂⊆∧∨/*|,;:()[\]→↦⇒∑∏]/;

// the script after a base: _x  ^x  _{xy}  ^{x+y}; an atom is up to three letters or digits (or a sign and digits, or a dagger/prime) ending at a boundary
export const WORD_SCRIPTS = ['dual', 'duale', 'max', 'min', 'tot', 'eff', 'ext', 'rest'];
export const NAMES = ['Ric', 'Cl', 'Spin', 'Pin', 'End', 'Hom', 'Tr', 'tr', 'det', 'dim', 'Aut', 'Re', 'Im', 'Lie', 'Sym', 'Riem'];
function readScript(s, j) {
  const kind = s[j]; if (kind !== '_' && kind !== '^') return null;
  const k = j + 1; if (k >= s.length) return null;
  for (const w of WORD_SCRIPTS) if (s.startsWith(w, k) && !/\p{L}/u.test(s[k + w.length] || '')) return { kind, text: w, end: k + w.length };
  if (s[k] === '{') {
    let depth = 0, e = k;
    for (; e < s.length; e++) { if (s[e] === '{') depth++; else if (s[e] === '}') { depth--; if (!depth) break; } }
    if (depth || e - k < 2 || e - k > 28) return null;
    return { kind, text: s.slice(k + 1, e), end: e + 1 };
  }
  let e = k; if (s[e] === '−' || s[e] === '-' || s[e] === '+') e++;
  if (/[†∗*′]/.test(s[e] || '')) return { kind, text: s.slice(k, e + 1), end: e + 1 };
  const cls = ch => (isDigit(ch) ? 'd' : isGreek(ch) ? 'g' : /[a-z]/.test(ch) ? 'l' : /[A-Z]/.test(ch) ? 'u' : '');
  const st = e, c0 = cls(s[e]); if (!c0) return null;
  while (e < s.length && e - st < 3) { const cc = cls(s[e]); if (!cc) break; if (cc !== c0 && !(c0 === 'u' && cc === 'u')) { if (!(c0 === 'l' && cc === 'l')) break; } e++; }
  if (e < s.length && cls(s[e]) === c0 && e - st >= 3) return null;           // x_maxima is a word, not x_{max}
  return { kind, text: s.slice(k, e), end: e };
}

function tryToken(s, i, afterScript) {
  const c = s[i]; let base = null, j = i, back = 0, named = false;
  const nm = !afterScript && isLetter(c) ? NAMES.find(w => s.startsWith(w, i) && /[_^]/.test(s[i + w.length] || '') && !isLatin(s[i - 1]) && s[i - 1] !== '_') : null;
  if (nm) { base = nm; j = i + nm.length; named = true; }
  else if (isLetter(c) || BASE_SYM.includes(c)) {
    const p = s[i - 1];
    if (!afterScript && i > 0 && ((isLatin(p) && isLatin(s[i - 2])) || p === '_' || p === '^')) return null;      // inside a longer word: gravity_selfcheck is not a formula; eA_μ is e A_μ
    base = c; j = i + 1;
  } else if (c === ')' || c === ']') {
    const open = c === ')' ? '(' : '[', close = c; let d = 0, o = i;
    for (; o >= 0; o--) { if (s[o] === close) d++; else if (s[o] === open) { d--; if (!d) break; } }
    if (o < 0 || i - o > 20 || s.slice(o, i).includes('_') || s.slice(o, i).includes('^')) return null;
    base = s.slice(o, i + 1); back = i - o; j = i + 1;
  }
  else if (isDigit(c)) {
    const p = s[i - 1]; if (!afterScript && i > 0 && (isLetter(p) || isDigit(p) || p === '.' || p === '_' || p === '^')) return null;
    let e = i; while (isDigit(s[e])) e++; if (s[e] !== '^') return null;                                                        // a number only takes a power
    base = s.slice(i, e); j = e;
  } else return null;
  let sub = '', sup = '', n = 0;
  for (;;) { const sc = readScript(s, j); if (!sc) break; if (sc.kind === '_') sub += sc.text; else sup += sc.text; j = sc.end; n++; if (n >= 3) break; }
  if (!n) return null;
  if (isDigit(base[0]) && !sup) return null;
  return { tok: { k: 'sym', base, sub, sup, named, src: s.slice(i - back, j) }, end: j, back };
}

const hasWord = g => /[A-Za-z]{2}/.test(g);
// text between two formulas that still belongs to one formula: operators, commas, brackets, single letters
const isGlue = g => g.length <= 16 && !/\n/.test(g) && !hasWord(g) && (g === '' || GLUE_OPS.test(g));

// characters that stick to a formula when there is no space between them: [D_μ, D_ν]Ψ, (F_{μν}), ∇A_μ
const ATT = /[\p{L}\p{N}[\](){}⟨⟩|‖∇∂−+·×′½¼¾*]/u;
const isWordish = t => /[A-Za-z]{2}/.test(t);
function tailAttached(s) {            // number of trailing characters of s that belong to a formula that follows
  let i = s.length; while (i > 0 && s.length - i < 12 && ATT.test(s[i - 1])) i--;
  while (i < s.length && (isWordish(s.slice(i)) || (isLatin(s[i]) && isLatin(s[i - 1])))) i++;
  return s.length - i;
}
function headAttached(s) {            // number of leading characters of s that belong to a formula that precedes
  let i = 0; while (i < s.length && i < 12 && ATT.test(s[i])) i++;
  while (i > 0 && (isWordish(s.slice(0, i)) || (isLatin(s[i - 1]) && isLatin(s[i])))) i--;
  return i;
}

export function parseMath(str) {
  if (typeof str !== 'string' || !/[_^]/.test(str)) return [{ k: 'text', s: str }];
  const flat = []; let buf = '', i = 0, after = false;
  const flush = () => { if (buf) { flat.push({ k: 'text', s: buf }); buf = ''; } };
  while (i < str.length) {
    const m = tryToken(str, i, after);
    if (m) {
      if (m.back) { if (buf.length >= m.back) buf = buf.slice(0, buf.length - m.back); else { buf += str[i]; i++; after = false; continue; } }
      flush(); flat.push(m.tok); i = m.end; after = true; continue; }
    buf += str[i]; i++; after = false;
  }
  flush();
  if (!flat.some(x => x.k === 'sym')) return [{ k: 'text', s: str }];
  const out = []; let q = 0;
  while (q < flat.length) {
    const x = flat[q];
    if (x.k !== 'sym') { out.push(x); q++; continue; }
    const parts = [x]; q++;
    const pv = out[out.length - 1];
    if (pv && pv.k === 'text') { const nn = tailAttached(pv.s); if (nn) { const g = pv.s.slice(-nn); pv.s = pv.s.slice(0, -nn); parts.unshift({ k: 'glue', s: g, src: g }); if (!pv.s) out.pop(); } }
    for (;;) {
      const a = flat[q], b = flat[q + 1];
      if (a && a.k === 'sym') { parts.push(a); q++; continue; }
      if (a && a.k === 'text' && b && b.k === 'sym' && isGlue(a.s)) { parts.push({ k: 'glue', s: a.s, src: a.s }, b); q += 2; continue; }
      break;
    }
    const nx = flat[q];
    if (nx && nx.k === 'text') { const nn = headAttached(nx.s); if (nn) { const g = nx.s.slice(0, nn); nx.s = nx.s.slice(nn); parts.push({ k: 'glue', s: g, src: g }); if (!nx.s) q++; } }
    out.push({ k: 'run', parts, raw: parts.map(x => x.src).join('') });
  }
  return out;
}

// letters of a formula: Latin and lower-case Greek are variables (italic); upper-case Greek, digits, operators, ℝ ℂ ∇ ∂ are upright
export const isVariable = c => /[A-Za-zα-ω]/.test(c) && c !== 'ς';
// in a script, a label such as L, R, SM is upright; indices (a, μν, b<c) are italic
export const scriptIsLabel = s => /^[A-Z]{1,3}$/.test(s) || WORD_SCRIPTS.includes(s);
export const visibleText = nodes => nodes.map(n => n.k === 'text' ? n.s : n.parts.map(p => p.k === 'sym' ? p.base + (p.sub ? p.sub : '') + (p.sup ? p.sup : '') : p.s).join('')).join('');
