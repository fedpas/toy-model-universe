import { eqNavIds, stepCount } from './steps.js';
import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];
const C=(n,k)=>{if(k<0||k>n)return 0;let r=1;for(let i=0;i<k;i++)r=r*(n-i)/(i+1);return Math.round(r);};
const AX=['t','x','y','z','u'];const pc=x=>{let c=0;while(x){c+=x&1;x>>=1;}return c;};
const names=S=>AX.filter((_,i)=>S>>i&1).join('');
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${lang}${w}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${lang}${w} console: ${m.text()}`));
 await pg.goto('file:///home/claude/ui/dist/app.html#equations/mirrors');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator('[data-profile="Mathematician"]').click();await pg.waitForTimeout(200);
 const nav=await pg.locator('.tabbar [role=tab]').count(); if(nav!==eqNavIds().length)errs.push(`${lang}${w}: nav ${nav}`);
 const rows=await pg.locator('#eq-mirrors .mr-table tbody tr').count(); if(rows!==7)errs.push(`${lang}${w}: ladder rows ${rows}`);
 const idr=await pg.locator('#eq-mirrors .mr-id tbody tr').count(); if(idr!==4)errs.push(`${lang}${w}: identity rows ${idr}`);
 const ticks=await pg.locator('#eq-mirrors .mr-id td').filter({hasText:'✓'}).count(); if(ticks!==12)errs.push(`${lang}${w}: ticks ${ticks}`);
 const chips=pg.locator('#eq-mirrors .mr-chip'); if(await chips.count()!==7)errs.push('chips '+await chips.count());
 for(let n=2;n<=8;n++){
  await chips.nth(n-2).click();
  const v=await pg.locator('#eq-mirrors .mr-view').count(); if(v!==7)errs.push(`${lang}${w} n=${n}: ${v} views`);
  const on=await pg.locator('#eq-mirrors .mr-table tbody tr.on td').first().textContent(); if(+on!==n)errs.push(`${lang}${w} n=${n}: row ${on}`);
  const txt=await pg.locator('#eq-mirrors').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} n=${n}: placeholder`);
  if(n<=5){
   const all=await pg.locator('#eq-mirrors .mr-corner').count(); if(all!==1<<n)errs.push(`${lang}${w} n=${n}: ${all} corners`);
   const ev=await pg.locator('#eq-mirrors .mr-corner.even').count(); if(ev!==1<<(n-1))errs.push(`${lang}${w} n=${n}: ${ev} even corners`);
   for(let k=0;k<=n;k++){const c=await pg.locator(`#eq-mirrors .mr-corner[data-w="${k}"]`).count(); if(c!==C(n,k))errs.push(`${lang}${w} n=${n}: weight ${k} has ${c}`);}
   // click every corner: the text names its axes and its number of mirrors and its parity
   for(let S=0;S<1<<n;S++){
    await pg.locator(`#eq-mirrors .mr-corner[data-mask="${S}"]`).dispatchEvent('click');
    const head=await pg.locator('#eq-mirrors .mr-head').textContent(), l1=await pg.locator('#eq-mirrors .mr-line').nth(1).textContent(), l2=await pg.locator('#eq-mirrors .mr-line').nth(2).textContent();
    if(S&&!head.includes(names(S)))errs.push(`${lang}${w} n=${n} S=${S}: head ${head}`);
    if(!l1.includes(String(pc(S))))errs.push(`${lang}${w} n=${n} S=${S}: mirrors line ${l1}`);
    const even=pc(S)%2===0; if(even!==/Even|Pari/.test(l2))errs.push(`${lang}${w} n=${n} S=${S}: parity line ${l2}`);
    const sel=await pg.locator('#eq-mirrors .mr-corner.on').count(); if(sel!==1)errs.push(`${lang}${w} n=${n} S=${S}: ${sel} selected`);
   }
   // the demicube toggle dims the odd corners
   await pg.locator('#eq-mirrors .mr-toggle').click(); const dimmed=await pg.evaluate(()=>[...document.querySelectorAll('#eq-mirrors .mr-corner.odd')].every(e=>+e.getAttribute('opacity')<.5)&&[...document.querySelectorAll('#eq-mirrors .mr-corner.even')].every(e=>+e.getAttribute('opacity')===1)); if(!dimmed)errs.push(`${lang}${w} n=${n}: toggle`);
   await pg.locator('#eq-mirrors .mr-toggle').click();
  } else {
   const bars=await pg.locator('#eq-mirrors .mr-bar').count(); if(bars!==n+1)errs.push(`${lang}${w} n=${n}: ${bars} bars`);
   for(let k=0;k<=n;k++){const c=await pg.locator(`#eq-mirrors .mr-bar[data-w="${k}"]`).getAttribute('data-count'); if(+c!==C(n,k))errs.push(`${lang}${w} n=${n}: bar ${k} = ${c}`);}
  }
 }
 const end=await pg.locator('#eq-mirrors .mr-two-pic').getAttribute('data-end'); if(end!=='0.600000,0.800000')errs.push(`${lang}${w}: two mirrors end ${end}`);
 const rowsT=await pg.locator('#eq-mirrors .mr-two tbody tr').count(); if(rowsT!==2)errs.push('two-mirror rows '+rowsT);
 const opens=await pg.locator('#eq-mirrors .eq-pt').count(); if(opens!==2)errs.push(`${lang}${w}: open items ${opens}`);
 const dl=await pg.locator('#eq-mirrors .eq-btn').count(); if(dl!==3)errs.push(`${lang}${w}: download buttons ${dl}`);
 await pg.close();}
await b.close();
console.log(errs.length?errs:'MIRRORS UI OK');
