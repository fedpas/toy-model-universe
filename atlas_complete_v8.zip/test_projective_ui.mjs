import { eqNavIds, stepCount } from './steps.js';
import {chromium} from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
const b=await chromium.launch();const errs=[];
const NAME={en:{'space,0':'Euclid','space,-1':'elliptic','space,1':'hyperbolic','lorentz,0':'Poincaré','lorentz,-1':'de Sitter','lorentz,1':'anti-de Sitter'},it:{'space,0':'euclideo','space,-1':'ellittico','space,1':'iperbolico','lorentz,0':'Poincaré','lorentz,-1':'de Sitter','lorentz,1':'anti-de Sitter'}};
const C=(n,k)=>{if(k<0||k>n)return 0;let r=1;for(let i=0;i<k;i++)r=r*(n-i)/(i+1);return Math.round(r);};
for(const lang of ['en','it']) for(const w of [1100,375]){
 const pg=await b.newPage({viewport:{width:w,height:800}});
 pg.on('pageerror',e=>errs.push(`${lang}${w}: ${e.message}`));pg.on('console',m=>m.type()==='error'&&errs.push(`${lang}${w} console: ${m.text()}`));
 await pg.goto('file:///home/claude/ui/dist/app.html#equations/projective');await pg.waitForTimeout(300);
 if(lang==='it')await setLang(pg,'it');
 await pg.locator('[data-profile="Mathematician"]').click();await pg.waitForTimeout(200);
 const nav=await pg.locator('.tabbar [role=tab]').count(); if(nav!==eqNavIds().length)errs.push(`${lang}${w}: nav ${nav}`);
 const rows=await pg.locator('#eq-projective .pj-table tbody tr').count(); if(rows!==7)errs.push(`${lang}${w}: count rows ${rows}`);
 const idr=await pg.locator('#eq-projective .pj-id tbody tr').count(); if(idr!==3)errs.push(`${lang}${w}: identity rows ${idr}`);
 const tk=await pg.locator('#eq-projective .pj-id td').filter({hasText:'✓'}).count(), dash=await pg.locator('#eq-projective .pj-id td').filter({hasText:'—'}).count(); if(tk!==16||dash!==2)errs.push(`${lang}${w}: id ticks ${tk} dashes ${dash}`);
 const dbl=await pg.locator('#eq-projective .pj-dbl tbody tr').count(); if(dbl!==4)errs.push('doubling rows '+dbl);
 const mot=await pg.locator('#eq-projective .pj-motions tbody tr').count(), mt=await pg.locator('#eq-projective .pj-motions td').filter({hasText:'✓'}).count(); if(mot!==5||mt!==5)errs.push(`${lang}${w}: motions ${mot} ticks ${mt}`);
 // the point table: P(x).P(y) = (x-y)^2/2
 for(let x=0;x<4;x++)for(let y=0;y<4;y++){const v=await pg.locator(`#eq-projective .pj-dot[data-x="${x}"][data-y="${y}"]`).textContent(); if(Math.abs(+v-(x-y)*(x-y)/2)>1e-9)errs.push(`${lang}${w}: dot ${x},${y} = ${v}`);}
 const kinds=pg.locator('#eq-projective .pj-kind'), ss=pg.locator('#eq-projective .pj-s'), chips=pg.locator('#eq-projective .pj-chip');
 if(await kinds.count()!==2||await ss.count()!==3||await chips.count()!==5)errs.push('chip counts');
 for(let ki=0;ki<2;ki++) for(let si=0;si<3;si++) for(let n=2;n<=6;n++){
  await kinds.nth(ki).click(); await ss.nth(si).click(); await chips.nth(n-2).click();
  const kind=['space','lorentz'][ki], s=[0,-1,1][si];
  const spokes=await pg.locator('#eq-projective .pj-spoke').evaluateAll(es=>es.map(e=>+e.getAttribute('data-square')));
  const nodes=await pg.locator('#eq-projective .pj-node').evaluateAll(es=>es.map(e=>+e.getAttribute('data-sq')));
  const bs=kind==='space'?Array(n).fill(-1):[1,...Array(n-1).fill(-1)];
  if(spokes.length!==n||nodes.length!==n)errs.push(`${lang}${w} ${kind} ${s} n=${n}: ${spokes.length} spokes ${nodes.length} nodes`);
  if(spokes.some((v,a)=>v!==(-bs[a]*s||0))||nodes.some((v,a)=>v!==bs[a]))errs.push(`${lang}${w} ${kind} ${s} n=${n}: squares ${spokes} ${nodes}`);
  const lines=await pg.locator('#eq-projective .pj-line').allTextContents(); if(lines.length!==3||!lines[0].includes(NAME[lang][`${kind},${s}`]))errs.push(`${lang}${w} ${kind} ${s} n=${n}: info ${lines[0]}`);
  if(!lines[0].includes(`${C(n+1,2)}`))errs.push(`${lang}${w} ${kind} ${s} n=${n}: dimension missing`);
  const v=await pg.locator('#eq-projective .pj-view').count(); if(v!==7)errs.push(`${lang}${w} n=${n}: ${v} views`);
  const on=await pg.locator('#eq-projective .pj-table tbody tr.on td').first().textContent(); if(+on!==n)errs.push(`${lang}${w} n=${n}: row ${on}`);
  const txt=await pg.locator('#eq-projective').textContent(); if(/undefined|NaN|\[object/.test(txt))errs.push(`${lang}${w} ${kind} ${s} n=${n}: placeholder`);
 }
 const opens=await pg.locator('#eq-projective .eq-pt').count(); if(opens!==2)errs.push(`${lang}${w}: open items ${opens}`);
 const dl=await pg.locator('#eq-projective .eq-btn').count(); if(dl!==3)errs.push(`${lang}${w}: download buttons ${dl}`);
 await pg.close();}
await b.close();
console.log(errs.length?errs:'PROJECTIVE UI OK');
