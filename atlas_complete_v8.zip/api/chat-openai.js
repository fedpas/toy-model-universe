export const config = { runtime: 'edge' };
import { buildSystemPrompt, PROFILES as profiles, LANGUAGES as languages, METRICS as metrics } from '../lib/chatPersona.js';
import { precheck, readJson, cleanContext, begin, sse, reply, sseError } from '../lib/chatGuard.js';

// OpenAI route. Same guard as chat.js. The first event is a status line so the page shows that the model is reasoning; upstream failures after that are reported as error events.
export default async function handler(request) {
  const early = precheck(request, 'openai', process.env.ToyModelKeyOpenAi);
  if (early) return early;
  const parsed = await readJson(request);
  if (parsed.status) return reply(parsed.status, parsed.text);
  const ctx = cleanContext(parsed.body, { languages, profiles, metrics });
  if (!ctx) return reply(400, 'Invalid chat context.');
  const system = buildSystemPrompt({ spokenLang: ctx.spokenLang, userProfile: ctx.userProfile, metricMode: ctx.metricMode, isMatchMode: ctx.isMatchMode });
  const enc = new TextEncoder(), ctl = begin(request); let reader = null;
  const stream = new ReadableStream({
    async start(controller) {
      controller.enqueue(enc.encode('data: {"type":"status","message":"OpenAI o3 is reasoning…"}\n\n'));
      try {
        const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST', signal: ctl.signal,
          headers: { 'content-type': 'application/json', 'authorization': `Bearer ${process.env.ToyModelKeyOpenAi}` },
          body: JSON.stringify({ model: 'o3', stream: true, max_completion_tokens: ctl.maxTokens.openai, messages: [{ role: 'system', content: system }, ...ctx.messages] }),
        });
        if (!upstream.ok || !upstream.body) {
          console.error('OpenAI upstream status', upstream.status);
          ctl.end(); controller.enqueue(enc.encode(sseError('The OpenAI model service is unavailable.'))); controller.close(); return;
        }
        reader = upstream.body.getReader();
      } catch (error) {
        console.error('OpenAI gateway failure:', error?.name || 'error');
        ctl.end(); try { controller.enqueue(enc.encode(sseError('The OpenAI model service is unavailable.'))); controller.close(); } catch { /* already closed */ }
      }
    },
    async pull(controller) {
      if (!reader) return;
      try { const { value, done } = await reader.read(); if (done) { ctl.end(); controller.close(); } else controller.enqueue(value); }
      catch { ctl.end(); try { controller.enqueue(enc.encode(sseError('The OpenAI model service was interrupted.'))); controller.close(); } catch { /* already closed */ } }
    },
    cancel(reason) { const p = reader ? reader.cancel(reason).catch(() => {}) : undefined; ctl.abort(); ctl.end(); return p; },
  });
  return sse(stream);
}
