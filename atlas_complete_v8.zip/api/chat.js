import { buildSystemPrompt, PROFILES as profiles, LANGUAGES as languages, METRICS as metrics } from '../lib/chatPersona.js';
import { precheck, readJson, cleanContext, begin, relay, sse, reply, upstreamFailure } from '../lib/chatGuard.js';
export const config = { runtime: 'edge' };

// Claude route. The guard (lib/chatGuard.js) checks method, key, origin, content type and rate before the body is read; the same guard serves chat-openai.js.
export default async function handler(request) {
  const early = precheck(request, 'anthropic', process.env.toy_model_key);
  if (early) return early;
  const parsed = await readJson(request);
  if (parsed.status) return reply(parsed.status, parsed.text);
  const ctx = cleanContext(parsed.body, { languages, profiles, metrics });
  if (!ctx) return reply(400, 'Invalid chat context.');
  const system = buildSystemPrompt({ spokenLang: ctx.spokenLang, userProfile: ctx.userProfile, metricMode: ctx.metricMode, isMatchMode: ctx.isMatchMode });
  const ctl = begin(request);
  try {
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: ctl.signal,
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.toy_model_key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: 'claude-opus-4-6', max_tokens: ctl.maxTokens.anthropic, stream: true, temperature: 0.15, system, messages: ctx.messages }),
    });
    if (!upstream.ok || !upstream.body) { ctl.end(); return upstreamFailure('anthropic', upstream.status); }
    return sse(relay(upstream.body, ctl));
  } catch (error) {
    ctl.end();
    console.error('Anthropic gateway failure:', error?.name || 'error');
    return reply(502, 'The model service is unavailable.');
  }
}
