// Data and copy test of step 14 (null surfaces). No browser. Run: node test_null.mjs   (run from this folder)
// 1. the data module, the embedded script and selfcheck/null.json agree, and the script rebuilds the portal data (--compare)
// 2. nullEngine.js (the formulas the figures draw) reproduces the numbers of null.json, and an independent computation agrees with both
// 3. the algebra facts of the figures are re-derived here by enumeration with the bit rule (ideal, quotient, dimensions, Killing form of the tube algebra)
// 4. the copy: EN and IT have the same shape, no banned wording, the numbers in the sentences are the script's, readings fit their length limits, the step is wired
import fs from 'fs';
import { execFileSync } from 'child_process';
import K from './nullData.js';
import { NULL_PY } from './nullSelfcheckSource.js';
import COPY from './nullCopy.js';
import * as E from './nullEngine.js';
import { STEP_GROUPS, STEP_NAMES, NAV_NAMES, eqNavIds, stepEyebrow, stepNo, stepCount } from './steps.js';
import { SHORT } from './audienceCopy.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const near = (a, b, tol, m) => ok(Number.isFinite(a) && Math.abs(a - b) <= tol, `${m}: ${a} vs ${b}`);

// ---- 1. files
const J = JSON.parse(fs.readFileSync('./selfcheck/null.json', 'utf8'));
ok(JSON.stringify(J) === JSON.stringify(K), 'data module equals selfcheck/null.json');
ok(NULL_PY === fs.readFileSync('./selfcheck/null_selfcheck.py', 'utf8'), 'embedded script equals the file');
ok(/--compare/.test(NULL_PY) && /--write/.test(NULL_PY), 'script interfaces');
{ const counted = K.checks.filter(c => c.tag !== 'ours'), readings = K.checks.filter(c => c.tag === 'ours');
  ok(K.portal.summary.computed === counted.length && K.portal.summary.passed === counted.filter(c => c.pass).length && K.portal.summary.passed === K.portal.summary.computed, 'summary counts equal the check list (readings excluded), all pass');
  ok(K.portal.summary.readings === readings.length && readings.length === 2 && readings.every(c => c.tag === 'ours'), 'the two readings are tagged ours and are not counted'); }
{ const out = execFileSync('python3', ['null_selfcheck.py', '--compare', 'null.json'], { cwd: './selfcheck', encoding: 'utf8' }); ok(/64 of 64 computed checks pass/.test(out), 'the script passes all 64 computed checks'); ok(!/FAIL/.test(out), 'no FAIL line'); ok(/portal data equals the rebuilt data/.test(out), 'the script rebuilds the portal data and it equals null.json'); }

// ---- 2. engine against the data
K.portal.kappa.forEach((k, i) => { const h = E.HORIZONS[i]; near(E.kappaNum(h), E.frac(k.kappa), 1e-6, `kappa ${h.id}`); ok(h.xh === +k.xh, `x_h ${h.id}`); ok(Math.abs(h.T(h.xh)) < 1e-12, `T(x_h) = 0 ${h.id}`); });
K.portal.kappa.forEach((k, i) => { const h = E.HORIZONS[i], xs = Object.keys(k.T); ok(xs.length === 4, `T samples of ${h.id}`); for (const x of xs) near(h.T(E.frac(x)), E.frac(k.T[x]), 1e-12, `T(${x}) of ${h.id} equals the script's exact value ${k.T[x]}`); });
ok(K.portal.kappa.map(k => k.kappa).join() === '1/6,1/8,-1/2,0,3/10', `the five κ: ${K.portal.kappa.map(k => k.kappa)}`);
K.portal.kerr.forEach(r => { const w = E.frac(r.w); near(E.kerrErgo(w), E.frac(r.r), 1e-12, `r_E at w=${r.w}`); near(E.kerrNN(w), E.frac(r.n2), 1e-12, `n.n at w=${r.w}`); near(E.kerrGtt(E.kerrErgo(w), w), 0, 1e-12, `g_tt = 0 at w=${r.w}`); });
ok(E.kerrErgo(0) - 2 * E.KERR.M === 0 && E.KERR.M + Math.sqrt(E.KERR.M ** 2 - E.KERR.a ** 2) === E.KERR.rh, 'Kerr M=5, a=3: r_E(equator) = 10, r_+ = 9');
{ const D = (r => r * r - 2 * E.KERR.M * r + E.KERR.a ** 2)(E.KERR.rh); ok(D === 0, 'Delta(r_+) = 0'); }
K.portal.ladder.forEach(l => { ok(l.dim === 2 ** (l.n - 1) && l.J === 2 ** (l.n - 2), `ladder dims n=${l.n}`); let c = 0; for (let S = 0; S < 1 << (l.n - 1); S++) if (E.inJ(l.n, S)) c++; ok(c === l.J, `J by enumeration n=${l.n}`); });
ok(K.portal.ladder.map(l => l.n).join() === E.NS.join(), 'ladder rows are n = 2..6');
const nm = { 'simple zero': 0, 'extremal': 1, 'Eq. (18)': 2 };
K.figs.f3.forEach(r => { const c = E.EQ1[nm[r.c]]; ok(c !== undefined, `f3 case ${r.c}`); ok(Math.abs(c.eq1(r.x1) / r.m1 - 1) < 1e-5 && Math.abs(c.eq1(r.x2) / r.m2 - 1) < 1e-5, `f3 ${r.c}`); near(c.T(r.x1) * c.dT(r.x1) ** 2 / c.eq1(r.x1), 1, 1e-9, `identity |Eq.(1)| = T (dT/dx)^2 at ${r.c}`); });
for (const c of E.EQ1) { const x = [1e-3, 1e-2, 1e-1], sl = Math.log(c.eq1(8 * x[0]) / c.eq1(x[0])) / Math.log(8); near(sl, { simple: 1, extremal: 4, eq18: -1 }[c.id], 1e-9, `log-log slope of Eq.(1), ${c.id}`); }
K.figs.f2.forEach(r => { const sp = r.cs === 'Schwarzschild' ? E.rates.schw : E.rates.ellis, f = r.q === 'dr/dv' ? sp.dr : sp.dl; near(f(r.r1), r.v1, 1e-4, `f2 ${r.cs} ${r.q} r1`); near(f(r.r2), r.v2, 1e-4, `f2 ${r.cs} ${r.q} r2`); });
K.figs.f1.forEach(r => { if (r.kind !== 'static') return; if (r.p === 'k') for (const [X, T] of [[r.a1, r.b1], [r.a2, r.b2]]) near(X, E.kruskalX(r.rv, T), 2e-4, 'f1 Kruskal row'); else near(r.a1, E.ellisL(r.rv), 1e-4, 'f1 Ellis row'); });
// the two geometries side by side: the same T, different g^rr; the neck keeps n.n = -1
for (const r of [1.02, 1.3, 1.7, 2]) { near(E.invariants.schw(r).n2, E.invariants.schw(r).grr, 1e-12, `Schwarzschild: n.n and g^rr equal in size at r=${r}`); ok(E.invariants.ellis(r).n2 === 1 && E.invariants.ellis(r).grr < 1, `Ellis: n.n = -1 and |g^rr| < 1 at r=${r}`); near(E.rates.ellis.dl(r), 0.5, 1e-12, 'Ellis dl/dv = 1/2'); }
// |g^rr| = 1/R and (dr/dv)^2 = T/(4R) give |g^rr| = 4 (dr/dv)^2 / T: the quantity drawn for g^rr is tied to the rates, which the script's data fixes
for (const r of [1.02, 1.3, 1.7, 2]) { near(E.invariants.schw(r).grr, 4 * E.rates.schw.dr(r) ** 2 / E.schwT(r), 1e-12, `Schwarzschild: |g^rr| = 4 (dr/dv)^2 / T at r=${r}`); near(E.invariants.ellis(r).grr, 4 * E.rates.ellis.dr(r) ** 2, 1e-12, `Ellis: |g^rr| = 4 (dr/dv)^2 at r=${r}`); }
// a mirror in n = dx: the image is a reflection (twice gives the vector back) and it fixes the surface's tangent vector xi = d_v only when T = 0 would be needed, so no image there
for (const T of [0.5, -0.25, 2]) { const w = [0.4, 0.8], i1 = E.mirrorImage(w, T), i2 = E.mirrorImage(i1, T); near(i2[0], w[0], 1e-12, 'mirror twice (v)'); near(i2[1], w[1], 1e-12, 'mirror twice (x)'); near(i1[1], -w[1] * (T / T), 1e-12, 'x-component flips'); }
ok(E.mirrorImage([0.4, 0.8], 0) === null, 'no mirror on a null surface');

// ---- 3. the bit rule, by an independent product, and the algebra facts
const indep = (a, b, sq) => { let s = 1; for (let i = 0; i < 8; i++) for (let j = 0; j < i; j++) if ((a >> i & 1) && (b >> j & 1)) s = -s; for (let i = 0; i < 8; i++) if ((a & b) >> i & 1) s *= sq[i]; return s; };
{ let all = true; const sq = [0.7, -1, -1, 0, 2, 0, -3, 0.5]; for (let a = 0; a < 256; a += 5) for (let b = 0; b < 256; b += 3) { const r = E.bitMul(a, b, sq); if (r.m !== (a ^ b) || Math.abs(r.c - indep(a, b, sq)) > 1e-12) all = false; } ok(all, 'bitMul equals the independent product'); }
// the horizon's tangent algebra Cl(0, n-2, 1): bits 0..n-3 square to -1, bit n-2 squares to 0
for (const l of K.portal.ladder) { const nn = l.n, m = nn - 1, N = 1 << m, sq = Array(8).fill(0); for (let i = 0; i < nn - 2; i++) sq[i] = -1;
  let ideal = true, jj = true, quot = true, nz = 0;
  for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) { const p = E.bitMul(a, b, sq), aJ = E.inJ(nn, a), bJ = E.inJ(nn, b);
    if ((aJ || bJ) && !E.inJ(nn, p.m) && p.c !== 0) ideal = false;                         // a product with a blade of J stays in J (or is zero)
    if (aJ && bJ && p.c !== 0) jj = false;                                                // J.J = 0
    if (!aJ && !bJ) { if (E.inJ(nn, p.m)) quot = false; const sq2 = Array(8).fill(-1); if (Math.abs(p.c - E.bitMul(a, b, sq2).c) > 0) quot = false; }   // the quotient multiplies as Cl(0, n-2)
    if (p.c !== 0) nz++; }
  ok(ideal && jj && quot, `n=${nn}: J is a two-sided ideal with J.J = 0 and the quotient multiplies as Cl(0,${nn - 2})`);
  // the number of nonzero products: a*b is zero exactly when both carry the null bit
  let zeros = 0; for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) if (E.bitMul(a, b, sq).c === 0) zeros++; ok(zeros === (N / 2) ** 2, `n=${nn}: zero products = (2^(n-2))^2 = ${(N / 2) ** 2}`);
}
// the tube algebra Cl(T, -1, -1): Killing form of the span of K1, K2, J
const killing = T => { const sq = [T, -1, -1, 0, 0, 0, 0, 0], B = [3, 5, 6], idx = m => B.indexOf(m);
  const ad = B.map(x => B.map(() => [0, 0, 0]));                                         // ad[x][y] = coordinates of [x, y]
  B.forEach((x, i) => B.forEach((y, j) => { const br = E.bracket(x, y, sq); if (br.c !== 0) { ok(idx(br.m) >= 0, `T=${T}: [${x},${y}] closes on the three bivectors`); ad[i][j][idx(br.m)] += br.c; } }));
  const M = i => B.map((_, k) => B.map((_, j) => ad[i][j][k]));                           // matrix of ad x_i: column j = [x_i, x_j]
  const mul = (A, C) => A.map((_, i) => C[0].map((__, j) => A[i].reduce((s, _c, k) => s + A[i][k] * C[k][j], 0)));
  const tr = A => A.reduce((s, r, i) => s + r[i], 0); return B.map((_, i) => B.map((_, j) => tr(mul(M(i), M(j))))); };
const diag = G => { let off = 0; for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++) if (i !== j) off = Math.max(off, Math.abs(G[i][j])); return off; };
for (const T of [1, 0.5, 3]) { const G = killing(T); ok(diag(G) < 1e-12, `T=${T}: Killing form diagonal`); const d = [0, 1, 2].map(i => G[i][i]); ok(d.filter(x => x > 1e-12).length === 2 && d.filter(x => x < -1e-12).length === 1, `T=${T} > 0: Killing form has signature (2,1), so(1,2): ${d}`); }
for (const T of [-1, -0.25, -3]) { const G = killing(T), d = [0, 1, 2].map(i => G[i][i]); ok(diag(G) < 1e-12 && d.every(x => x < -1e-12), `T=${T} < 0: Killing form negative definite, so(3): ${d}`); }
{ const G = killing(0), d = [0, 1, 2].map(i => G[i][i]); ok(diag(G) < 1e-12 && d.filter(x => Math.abs(x) < 1e-12).length === 2 && d.filter(x => x < -1e-12).length === 1, `T=0: Killing form of rank 1, iso(2): ${d}`); ok(E.bracket(3, 5, [0, -1, -1, 0, 0, 0, 0, 0]).c === 0, 'T=0: [K1,K2] = 0 (the translations commute)'); }
for (const T of [1, 0, -1, 0.5, -0.25]) { const t = E.tube(T); near(t.sq.K1, T, 1e-12, `K1^2 = T at T=${T}`); near(t.sq.K2, T, 1e-12, `K2^2 = T at T=${T}`); near(t.sq.J, -1, 1e-12, `J^2 = -1 at T=${T}`); near(t.K1K2.c, -2 * T, 1e-12, `[K1,K2] = -2T J at T=${T}`); ok(t.kind === (T === 0 ? 'iso2' : T > 0 ? 'so12' : 'so3'), `kind at T=${T}`); }
ok(E.surfaceKind(0) === 'null' && E.surfaceKind(1e-3) === 'timelike' && E.surfaceKind(-1e-3) === 'spacelike', 'surface kinds');
near(E.gramTortoise(0.3).det, -0.09, 1e-12, 'Gram determinant in the tortoise chart is -T^2'); ok(E.gramEF().det === -1, 'Gram determinant in the regular chart is -1');
ok(E.choose(5, 2) === 10 && E.choose(5, 6) === 0 && E.isPow2(32) && !E.isPow2(12) && E.popc(255) === 8, 'helpers');

// ---- 4. the copy
const shape = (v, p = '') => (v === null || v === undefined ? [p + ':nil'] : typeof v === 'function' ? [p + ':fn'] : Array.isArray(v) ? [p + ':[' + v.length + ']', ...v.flatMap((x, i) => shape(x, p + '[' + i + ']'))] : typeof v === 'object' ? Object.keys(v).sort().flatMap(k => shape(v[k], p + '.' + k)) : [p + ':' + typeof v]);
const se = shape(COPY.en), si = shape(COPY.it);
ok(se.join('\n') === si.join('\n'), 'EN and IT copy have the same shape' + (se.join() === si.join() ? '' : ': ' + se.filter(x => !si.includes(x)).concat(si.filter(x => !se.includes(x))).slice(0, 6).join(' ; ')));
const strings = (v, out = []) => { if (typeof v === 'string') out.push(v); else if (Array.isArray(v)) v.forEach(x => strings(x, out)); else if (v && typeof v === 'object') Object.values(v).forEach(x => strings(x, out)); return out; };
// call the template functions with sample arguments so their wording is checked too
const callAll = c => { const out = strings(c); const L = c.ladder.lab; out.push(L.matrices('ℍ'), L.simplex(4), L.starCount([1, 3, 3, 1]), L.pick(4, 8), L.vertex('ℓe1', '011', true), L.vertex('1', '000', false), L.faces(4, 4)); return out; };
const BANS = [/proves?\b.*generation/i, /explains? why three/i, /predict(s|ed)? (the|a)\b/i, /confirms?\b/i, /GUT\b/, /grand unif/i, /(?<!not a )\bwall\b|\breset/i, /undefined/, /\bNaN\b/, /\[object/, /Infinity/];
for (const lang of ['en', 'it']) { const all = callAll(COPY[lang]).join('\n'); for (const b of BANS) ok(!b.test(all), `${lang} banned ${b} → ${(all.match(b) || [])[0]}`); }
for (const lang of ['en', 'it']) { const c = COPY[lang]; ok(c.cards.length === 4 && c.cards.every(x => x.h && x.text.length >= 1 && x.tags.length >= 1 && x.tags.every(t => ['checked', 'standard', 'ours', 'open'].includes(t))), `${lang}: four result cards with valid tags`);
  ok(c.limits.every(([k, t]) => ['checked', 'standard', 'ours', 'open'].includes(k) && t.length > 20) && c.limits.some(([k]) => k === 'open'), `${lang}: limits carry tags and at least one is open`);
  ok(c.links.every(([ks, h, t]) => ks.length && h && t), `${lang}: links well formed`);
  for (const lens of ['clifford', 'cube', 'simplex', 'prime', 'mirror', 'null', 'flow']) ok(typeof c.lens[lens] === 'string' && c.lens[lens].length > 2, `${lang}: lens name ${lens}`);
  for (const k of ['cone', 'neck', 'crit', 'kerr', 'ladder']) ok(c[k] && c[k].aria && c[k].aria.length > 20, `${lang}: ${k} has an aria label`);
  for (const lens of ['clifford', 'cube', 'mirror']) ok(c.cone.caps[lens].length > 30, `${lang}: cone caption ${lens}`);
  for (const lens of ['clifford', 'null', 'flow']) ok(c.neck.caps[lens].length > 30, `${lang}: neck caption ${lens}`);
  for (const lens of ['clifford', 'cube', 'simplex', 'prime']) ok(c.ladder.caps[lens].length > 30, `${lang}: ladder caption ${lens}`);
  ok(Object.keys(c.cone.cases).join() === E.HORIZONS.map(h => h.id).join(), `${lang}: cone cases are the five horizons in order`);
  ok(Object.keys(c.crit.cases).join() === E.EQ1.map(e => e.id).join(), `${lang}: criterion cases are the three surfaces in order`);
  // the numbers in the summary sentence are the script's
  const s = c.summary; ok(s.includes(String(K.portal.summary.passed)) && s.includes(String(K.portal.summary.computed)) && s.includes(String(K.portal.summary.readings)), `${lang}: summary states ${K.portal.summary.passed} of ${K.portal.summary.computed} and ${K.portal.summary.readings} readings: ${s.slice(0, 160)}`);
  // the Kerr numbers quoted in the text are the engine's
  ok(c.kerrText.includes(`M = ${E.KERR.M}, a = ${E.KERR.a}, r₊ = ${E.KERR.rh}`) && c.kerr.lab.horizon.includes(`r₊ = ${E.KERR.rh}`), `${lang}: the Kerr numbers are the engine's: ${c.kerrText.slice(0, 160)}`);
}

// ---- 5. wiring
ok(STEP_GROUPS.eq.length === 14 && STEP_GROUPS.eq[13] === 'nullsurf' && stepNo('eq', 'nullsurf') === 14 && stepCount('eq') === 14, `14 steps, the last is nullsurf (${STEP_GROUPS.eq.length})`);
ok(eqNavIds().length === 15 && eqNavIds()[13] === 'nullsurf' && eqNavIds()[14] === 'tally', 'the tabs are the 14 steps and the tally');
for (const lang of ['en', 'it']) { ok(typeof STEP_NAMES[lang].nullsurf === 'string' && typeof NAV_NAMES[lang].nullsurf === 'string', `${lang}: step and tab names`); ok(/14/.test(stepEyebrow(lang, 'eq', 'nullsurf')) && stepEyebrow(lang, 'eq', 'nullsurf').split('14').length === 3, `${lang}: eyebrow says 14 of 14: ${stepEyebrow(lang, 'eq', 'nullsurf')}`); }
for (const lang of ['en', 'it']) for (const lv of [0, 1]) { const s = (SHORT[lang] || {}).nullsurf?.[lv]; ok(typeof s === 'string' && s.length > 60, `${lang} level ${lv}: short reading exists`); ok(s && s.length < (lv === 0 ? 330 : 460), `${lang} level ${lv}: short reading length ${s && s.length}`); }
console.log(bad ? `${bad} FAILURES of ${n}` : `ok: ${n} checks`);
process.exit(bad ? 1 : 0);
