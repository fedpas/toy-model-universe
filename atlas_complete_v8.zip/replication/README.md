# Blind replication kit

**What it is.** 52 exact answers across eight blocks (the classification of Cl(p,q), the sign rule on bit labels, the operation counts of the matrix route and of period 8, charges in E and B fields, the E8 root system, three fermion modes and SU(3), a rotor, the Moon). The brief (`INSTRUCTIONS.md`) is self-contained and mentions no project. `reference/make_reference.py` computes the reference answers by routes that differ from the app's code (bubble sorting instead of popcounts, enumeration, RK4, a field-tensor boost) and cross-checks closed forms against numerics; `grade.py` compares an `answers.json` with them.

**How to use it with any model**: `PROMPT_FOR_ANOTHER_MODEL.txt`. Give it only `INSTRUCTIONS.md` and `answers_template.json`.

**What it shows, and what it does not.**
* It shows that someone who has not seen our code or text, starting from the brief, reaches the same numbers: the reference answers are not an artefact of our conventions or of one reader.
* The blindness is by instruction (the brief and the prompt forbid reading other files and using the web, and ask for a list of files read and commands run in `notes.md`). The harness did not sandbox the file system, so it is an honour system with an audit trail, not a proof. A clean machine and a model from another vendor is the stronger test.
* Most of the questions are textbook results. Agreement says the reference is right; it says nothing about the interpretive claims of the atlas (what the three generations mean, whether the model is physics). Those are marked open on the pages.
* Version 1 of the brief gave `M(2,H)` as a format example, which is the answer to one question (Cl(1,3)); both models in `runs/` saw version 1. They also computed that entry independently (see their `notes.md`), but strictly 51 of the 52 answers were unleaked. Version 2 (this folder's `INSTRUCTIONS.md`) fixes it, adds the bit order of the labels (q2) and the 1×1 format (q1). `runs/*/INSTRUCTIONS.md` are the exact copies the models saw.

**Runs so far** (see `runs/*/graded.json`): Claude Fable and Claude Opus, each given the brief alone: both 52/52 (Fable marked q2 unsure for the bit-order ambiguity of version 1, and its answer was right under the ordinary-binary reading).
