# Blind replication brief (version 2: version 1 gave `M(2,H)` as a format example, which is the true answer for one question (1,3); the example is replaced, and the bit order of the labels in q2 and the 1×1 format of q1 are now stated)

You are asked to work out a set of results **from first principles**. You have only this page. The answers are graded automatically against an exact reference you cannot see.

## Rules
1. Work only inside the folder you were given. Read **no other file** on this machine (not this machine's other folders, not any project that is lying around), and use **no web access**. You may use your own knowledge and reasoning and run code that you write yourself (Python with the standard library and numpy; sympy if it is installed).
2. Write your own code. Nothing is provided to run.
3. If you are not sure of an answer, give your best value **and** list its id under `unsure` in `answers.json`. A wrong answer marked unsure is counted as an honest miss; a guess presented as certain is not better. Do not tune an answer to look plausible.
4. Finish by writing two files in your folder:
   * `answers.json`: one JSON object, with exactly the keys listed below (values as described), plus the key `"unsure"` (a list of ids, possibly empty) and the key `"methods"` (an object: id of each question block q1…q8 → one or two sentences on how you got it: derived, computed numerically, or recalled from memory; be candid about which).
   * `notes.md`: the list of files you read and commands you ran (so that the claim "worked blind" can be audited), and anything in the brief that you found ambiguous.
5. Units: c = 1 throughout. Numbers are graded to a relative tolerance of 2·10⁻³ (integers and strings exactly).

## q1 · Which matrix algebra is Cl(p,q)?
Cl(p,q) is the real Clifford algebra with p generators squaring to +1 and q generators squaring to −1 (all anticommuting). Give the algebra it is isomorphic to as a string `M(d,K)` with K ∈ {R, C, H} (real, complex, quaternionic d×d matrices) or a sum of two equal summands `M(d,K)+M(d,K)`. No spaces.
A 1×1 case is written with d = 1, for instance `M(1,C)`. Ids: `q1_p_q` for (p,q) in: (1,0) (0,1) (2,0) (0,2) (1,1) (3,0) (0,3) (2,1) (1,3) (3,1) (4,4) (0,8) (5,3) (2,6) (6,0) (0,6); the id for (p,q) = (1,3) is `q1_1_3`. Format example only (not the answer to any question here): `"M(7,C)"`.

## q2 · The sign rule on bit labels
Six generators e₀…e₅ with e_i² = +1 for even i and −1 for odd i, anticommuting. A **label** is a 6-bit number a, written below as an ordinary binary numeral (the rightmost digit is bit 0); the blade e_a is the product of the generators i with bit i of a set, in increasing order of i. For two labels, e_a e_b = s · e_(a xor b) with s = ±1.
Id `q2`: a list of the eight values s for the pairs (a,b), in this order (labels written in binary): (000110, 001010), (101000, 000101), (111111, 111111), (010101, 101010), (001000, 001000), (011011, 110110), (100001, 010010), (000111, 001110).

## q3 · Counting the dense product
The neutral algebra Cl(k,k) has 2^(2k) basis blades. Cl(k,k) is a full algebra of real matrices.
* `q3_size_4`, `q3_size_5`: the size d of the real d×d matrices for k = 4 and k = 5.
* `q3_terms_8`, `q3_terms_10`: the number of coefficient products ("terms") in the schoolbook product of two dense multivectors with n = 2k = 8 and n = 10 generators.
* `q3_mults_8`, `q3_mults_10`: the number of real multiplications in the schoolbook product of two d×d matrices for the same two algebras.
* Bott/Clifford period 8: Cl(N+8) is the algebra of 16×16 matrices whose entries are elements of Cl(N). `q3_blocks_products`: the number of products in Cl(N) that a schoolbook product of two such 16×16 matrices uses. `q3_ratio`: the ratio of (the number of terms of the schoolbook product in Cl(N+8)) to (that number of Cl(N) products times the terms of one product in Cl(N)), as an integer.

## q4 · Charges and fields
A point charge with charge-to-mass ratio q/m = 1, relativistic motion, c = 1, the force on it d(γ m v)/dt = q(E + v × B).
* `q4_radius`, `q4_period`: B = 1 along z, no E; the charge moves at speed 0.8 perpendicular to B. Radius of the circle and its period in lab time.
* `q4_drift_speed`, `q4_drift_vy`, `q4_drift_gamma`: E = 3 along x, B = 5 along z (|E| < |B|). The speed of the drift (the mean velocity of the motion), the y component of the mean velocity (with its sign), and the Lorentz factor of the frame in which the electric field vanishes.
* `q4_hyp_x`, `q4_hyp_v`: E = 1 along x, no B, the charge at rest at x = 0 at t = 0. Its x at lab time t = 3 and its speed there.
* `q4_wave_drift`: a plane wave travelling along +z, E = (a cos(t − z), 0, 0), B = (0, a cos(t − z), 0) with a = 1.5; the charge is at rest at the origin at t = 0. The long-time average of dz/dt (total displacement over total lab time as the time grows).
* `q4_kepler_deg`: a charge in the field of a fixed centre, with d(γ v)/dt = −κ r̂/r² (a Coulomb attraction, relativistic momentum), κ = 0.3, started at r = 1 with a tangential speed 0.5. The angle, in degrees, by which the perihelion advances from one orbit to the next (angle between successive perihelia minus 360°).
* `q4_boost`: the electromagnetic field E = (1,2,3), B = (4,5,6) in frame S. A second frame S′ moves with velocity +0.6 x̂ relative to S (axes parallel). The six numbers (E′x, E′y, E′z, B′x, B′y, B′z) measured in S′, in this order.
* `q4_E2mB2`, `q4_EdotB`: the two Lorentz invariants E² − B² and E·B of the field above.

## q5 · The E8 root system
The 240 roots of E8 are the vectors of R⁸ of two kinds: (±1, ±1, 0, 0, 0, 0, 0, 0) with the two non-zero entries anywhere (112 of them), and (±½, …, ±½) with an even number of minus signs (128). Take the fixed root r₀ = (1, 1, 0, 0, 0, 0, 0, 0).
* `q5_roots`: the number of roots.
* `q5_ip1`: the number of roots with inner product 1 with r₀; `q5_ip0`: the number with inner product 0 with r₀.
* `q5_edges`: the number of pairs of roots at the smallest distance from each other (the edges of the convex hull's 1-skeleton, the 4₂₁ polytope).
* `q5_orth_A2`: take two roots r₁, r₂ with inner product −1; the number of roots orthogonal to both.

## q6 · Three fermion modes
Three modes with annihilation operators a₁, a₂, a₃ ({a_i, a_j†} = δ_ij, {a_i, a_j} = 0) act on an 8-dimensional Fock space with number operator N = Σ a_i†a_i. The operators T^k = Σ_ij a_i† (λ^k/2)_ij a_j, with λ^1…λ^8 the Gell-Mann matrices, generate an SU(3).
* `q6_dim`: the dimension of the Fock space.
* `q6_N_mult`: the list of the number of states with N = 0, 1, 2, 3.
* `q6_su3_dim`: the number of generators T^k.
* `q6_casimir_by_N`: the quadratic Casimir Σ_k T^k T^k on the states with N = 0, 1, 2, 3 (a list of four numbers; each N-sector is an irreducible representation).

## q7 · A rotor
In Cl(3,0), with e₁e₂ the bivector of the plane of e₁ and e₂, let R = exp(−(θ/2) e₁e₂) = cos(θ/2) − sin(θ/2) e₁e₂ and R̃ its reverse (R̃ = cos(θ/2) + sin(θ/2) e₁e₂). For θ = π/2 compute the vector R e_i R̃ for i = 1, 2, 3: ids `q7_Re1`, `q7_Re2`, `q7_Re3`, each a list of three components on (e₁, e₂, e₃). `q7_R2pi`: for θ = 2π, the value of R (a scalar).

## q8 · The Moon
Two bodies of masses M = 5.97237·10²⁴ kg and m = 7.342·10²² kg, G = 6.6703·10⁻¹¹ (SI). At the start they are 362400 km apart and the relative velocity is 1085 m/s, perpendicular to the line joining them. The orbital period of the relative orbit, in days: `q8_period_days`. Also `q8_semi_major_km`, its semi-major axis in km.

## answers.json (the skeleton)
```
{ "q1_1_0": "...", "q1_0_1": "...", ..., "q2": [..8 values..], "q3_size_4": 0, ..., "q4_radius": 0.0, ..., "q4_boost": [6 numbers], "q5_roots": 0, ..., "q6_casimir_by_N": [4 numbers], ..., "q7_Re1": [3 numbers], ..., "q8_period_days": 0.0, "q8_semi_major_km": 0.0,
  "unsure": [], "methods": { "q1": "...", "q2": "...", "q3": "...", "q4": "...", "q5": "...", "q6": "...", "q7": "...", "q8": "..." } }
```
All ids are listed in `answers_template.json`.
