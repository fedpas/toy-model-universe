"""Assemble answers.json from the intermediate results, keyed exactly as answers_template.json."""
import json

d = '/home/claude/replication/runs/fable/'
template = json.load(open(d + 'answers_template.json'))
r12 = json.load(open(d + '_q1q2.json'))
r34 = json.load(open(d + '_q3q4.json'))
r58 = json.load(open(d + '_q5to8.json'))

ans = {}
ans.update(r12['q1'])
ans['q2'] = [int(s) for s in r12['q2']]
ans.update(r34)
ans.update(r58)

# tidy types: integers where the quantity is a count
for k in ['q3_size_4', 'q3_size_5', 'q3_terms_8', 'q3_terms_10', 'q3_mults_8', 'q3_mults_10',
          'q3_blocks_products', 'q3_ratio', 'q5_roots', 'q5_ip1', 'q5_ip0', 'q5_edges', 'q5_orth_A2',
          'q6_dim', 'q6_su3_dim']:
    ans[k] = int(ans[k])
ans['q6_N_mult'] = [int(x) for x in ans['q6_N_mult']]
ans['q4_boost'] = [float(round(x, 12)) for x in ans['q4_boost']]

ans['unsure'] = ['q2']
ans['methods'] = {
    'q1': 'Derived and computed: I enumerated the 2^(p+q) blades, computed the centre (1 and, for odd n, the pseudoscalar, '
          'whose square decides C versus R+R) and the signature of the trace form <xy> on blades (more blades squaring to +1 '
          'than to -1 gives real type, equal gives complex, fewer gives quaternionic), then fixed d from the dimension. '
          'Cross-checked by an independent recursion Cl(p+1,q+1)=M(2,Cl(p,q)), Cl(p+2,q)=Cl(q,p)xM(2,R), Cl(p,q+2)=Cl(q,p)xH from Cl(0,0)=R, Cl(1,0)=R+R, Cl(0,1)=C; both methods agree.',
    'q2': 'Computed: concatenated the generator lists, bubble-sorted with a -1 per swap, cancelled adjacent equal generators '
          'with e_i^2; labels read as ordinary binary numbers (rightmost digit = bit 0). Hand-checked two entries.',
    'q3': 'Derived: Cl(k,k)=M(2^k,R) (from q1), terms = (2^n)^2, matrix multiplications = d^3, 16x16 block product = 16^3 '
          'Cl(N) products, ratio 2^(2N+16)/(2^12 2^(2N)) = 16.',
    'q4': 'Derived analytically (r = gamma v/B, T = 2 pi gamma/B; drift E x B/B^2; hyperbolic motion x = sqrt(1+t^2)-1; '
          'plane wave via the conserved gamma - p_z and p_x = a sin(phase), giving <dz/dt> = a^2/(4+a^2); Sommerfeld orbit '
          'u\'\' + (1 - kappa^2/L^2) u = const giving advance 360(1/sqrt(1-kappa^2/L^2) - 1); standard field boost formulas and '
          'invariants). Every dynamical value was confirmed by RK4 integration of d(gamma v)/dt = E + v x B, and the boost by F\' = L F L^T.',
    'q5': 'Computed numerically: enumerated the 240 roots, built the Gram matrix, counted inner products with r0, '
          'nearest pairs (|r-r\'|^2 = 2, i.e. r.r\' = 1), and roots orthogonal to a pair with inner product -1 (72 = E6).',
    'q6': 'Computed numerically: Jordan-Wigner matrices for three modes on the 8-dim Fock space (CAR verified), '
          'T^k = a^dag (lambda^k/2) a, closure of the algebra and commutation with N checked, Casimir evaluated per N sector '
          '(0, 4/3, 4/3, 0 for singlet, 3, 3bar, singlet); multiplicities from the diagonal of N.',
    'q7': 'Derived by hand (R e1 R~ = cos(theta) e1 + sin(theta) e2, etc.) and confirmed with the Pauli-matrix representation of Cl(3,0).',
    'q8': 'Derived: mu = G(M+m) for the relative orbit, vis-viva 1/a = 2/r - v^2/mu, T = 2 pi sqrt(a^3/mu); confirmed by '
          'integrating the two-body relative motion and timing the return to the starting direction.',
}

# make sure the key set matches the template exactly
missing = set(template) - set(ans)
extra = set(ans) - set(template)
assert not missing and not extra, (missing, extra)
assert set(ans['methods']) == set(template['methods'])

ordered = {k: ans[k] for k in template}
json.dump(ordered, open(d + 'answers.json', 'w'), indent=1)
print(json.dumps(ordered, indent=1))
