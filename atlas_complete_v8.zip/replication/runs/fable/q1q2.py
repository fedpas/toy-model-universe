"""q1: classify Cl(p,q); q2: blade product signs.  Own code, numpy/stdlib only."""
from itertools import combinations
import json

# ---------- blade machinery (shared by q1 and q2) ----------
def blade_mul(a, b, sq):
    """Product of blades labelled by bitmasks a, b.  sq[i] = e_i^2 = +-1.
    Returns (sign, a ^ b).  Blade e_a = product of e_i for set bits of a, i increasing."""
    gens = [i for i in range(len(sq)) if a >> i & 1] + [i for i in range(len(sq)) if b >> i & 1]
    sign = 1
    # bubble sort with sign tracking (each adjacent swap of distinct generators gives -1)
    n = len(gens)
    changed = True
    while changed:
        changed = False
        for k in range(n - 1):
            if gens[k] > gens[k + 1]:
                gens[k], gens[k + 1] = gens[k + 1], gens[k]
                sign = -sign
                changed = True
    # cancel adjacent equal generators using their squares
    out = []
    for g in gens:
        if out and out[-1] == g:
            out.pop()
            sign *= sq[g]
        else:
            out.append(g)
    mask = 0
    for g in out:
        mask |= 1 << g
    assert mask == (a ^ b)
    return sign, mask

# ---------- q1 ----------
def classify(p, q):
    n = p + q
    sq = [1] * p + [-1] * q
    nb = 1 << n
    # sign of each blade's square
    plus = minus = 0
    for a in range(nb):
        s, m = blade_mul(a, a, sq)
        assert m == 0
        if s > 0:
            plus += 1
        else:
            minus += 1
    # center: blades commuting with all generators
    central = []
    for a in range(nb):
        ok = True
        for i in range(n):
            s1, m1 = blade_mul(a, 1 << i, sq)
            s2, m2 = blade_mul(1 << i, a, sq)
            if s1 != s2:
                ok = False
                break
        if ok:
            central.append(a)
    dimZ = len(central)
    if dimZ == 1:
        if plus > minus:
            K, summands = 'R', 1
        elif plus < minus:
            K, summands = 'H', 1
        else:
            raise RuntimeError('balanced trace form with trivial center?')
    elif dimZ == 2:
        w = [a for a in central if a != 0][0]
        s, _ = blade_mul(w, w, sq)
        if s < 0:
            K, summands = 'C', 1          # center = C
            assert plus == minus
        else:
            summands = 2                  # center = R + R
            if plus > minus:
                K = 'R'
            elif plus < minus:
                K = 'H'
            else:
                raise RuntimeError('balanced form with split center?')
    else:
        raise RuntimeError('center too big')
    dimK = {'R': 1, 'C': 2, 'H': 4}[K]
    total = nb // summands            # real dimension of one summand
    d2 = total // dimK
    d = int(round(d2 ** 0.5))
    assert d * d * dimK * summands == nb, (p, q, d, K, summands)
    s = f'M({d},{K})'
    return s + '+' + s if summands == 2 else s

# independent check: recursive isomorphisms.
# representation: (d, K, summands)
def tensor_R_scale(alg, k):
    d, K, s = alg
    return (d * k, K, s)

def tensor_H(alg):
    d, K, s = alg
    if K == 'R':
        return (d, 'H', s)
    if K == 'H':             # H (x) H = M(4,R)
        return (4 * d, 'R', s)
    if K == 'C':             # C (x) H = M(2,C)
        return (2 * d, 'C', s)

def classify_rec(p, q):
    if (p, q) == (0, 0):
        return (1, 'R', 1)
    if (p, q) == (1, 0):
        return (1, 'R', 2)
    if (p, q) == (0, 1):
        return (1, 'C', 1)
    if p >= 1 and q >= 1:            # Cl(p,q) = M(2, Cl(p-1,q-1))
        return tensor_R_scale(classify_rec(p - 1, q - 1), 2)
    if p >= 2:                        # Cl(p,q) = Cl(q,p-2) (x) Cl(2,0),  Cl(2,0)=M(2,R)
        return tensor_R_scale(classify_rec(q, p - 2), 2)
    if q >= 2:                        # Cl(p,q) = Cl(q-2,p) (x) Cl(0,2),  Cl(0,2)=H
        return tensor_H(classify_rec(q - 2, p))

def fmt(alg):
    d, K, s = alg
    t = f'M({d},{K})'
    return t + '+' + t if s == 2 else t

sigs = [(1, 0), (0, 1), (2, 0), (0, 2), (1, 1), (3, 0), (0, 3), (2, 1), (1, 3), (3, 1), (4, 4), (0, 8), (5, 3), (2, 6), (6, 0), (0, 6)]
q1 = {}
for p, q in sigs:
    a = classify(p, q)
    b = fmt(classify_rec(p, q))
    flag = '' if a == b else '   <-- MISMATCH'
    print(f'Cl({p},{q}) : trace/center -> {a:16s} recursion -> {b:16s}{flag}')
    q1[f'q1_{p}_{q}'] = a

# ---------- q2 ----------
sq6 = [1 if i % 2 == 0 else -1 for i in range(6)]   # e_i^2 = +1 for even i, -1 for odd i
pairs = ['000110 001010', '101000 000101', '111111 111111', '010101 101010',
         '001000 001000', '011011 110110', '100001 010010', '000111 001110']
q2_lsb = []   # rightmost binary digit = bit 0 (ordinary binary number)
q2_msb = []   # alternative reading: leftmost digit = bit 0
for pr in pairs:
    sa, sb = pr.split()
    a, b = int(sa, 2), int(sb, 2)
    s, m = blade_mul(a, b, sq6)
    q2_lsb.append(s)
    ar, br = int(sa[::-1], 2), int(sb[::-1], 2)
    s2, _ = blade_mul(ar, br, sq6)
    q2_msb.append(s2)
    print(f'({sa},{sb}): s = {s:+d}   [reversed-bit reading: {s2:+d}]   e_(a xor b) = {m:06b}')
print('q2 (LSB = bit 0):', q2_lsb)
print('q2 (MSB = bit 0):', q2_msb)

json.dump({'q1': q1, 'q2': q2_lsb, 'q2_alt': q2_msb}, open('/home/claude/replication/runs/fable/_q1q2.json', 'w'), indent=1)
