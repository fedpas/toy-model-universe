# Notes: blind replication run

## Files read
- `/home/claude/replication/runs/opus/INSTRUCTIONS.md` (the brief)
- `/home/claude/replication/runs/opus/answers_template.json` (the key list, which the brief points to)

No other file on the machine was opened. There was no web access. The scratchpad directory was not used, so everything stayed inside the working folder.

## Commands run (all inside `/home/claude/replication/runs/opus`)
1. `ls -la /home/claude/replication/runs/opus/`: list the folder.
2. `python3 -c "import numpy, sys; ..."` and `python3 -c "import sympy"`: checked the toolchain (Python 3.13, numpy 2.5.3; sympy not installed).
3. `python3 solve.py`: my own solver. Run 1 crashed in q6 because of a numpy scalar-times-matrix bug. I fixed it, made the perihelion detection more precise, and re-ran.
4. `python3 solve.py`: run 2, which completed (output piped through `grep`/`head` for display only).
5. `python3 finalize.py`: assembles `answers.json` in template order, and a one-line `python3 -c` check that it parses.

## Files written
- `solve.py`: all computations and cross-checks.
- `finalize.py`: writes `answers.json`.
- `computed_values.json`: an intermediate file from `solve.py`.
- `answers.json`, `notes.md`.

## Cross-checks done
- q1: the mod-8 table agrees with a computed invariant for all 16 signatures. The invariant uses the pseudoscalar square and the trace-form signature Σ_A sign(e_A²).
- q2: the bit rule agrees with a bubble-sort of the generator word for all 64×64 label pairs.
- q4: each analytic result was checked by RK4 integration of the relativistic equations:
  - radius: 1.33333
  - drift: −0.59996 at t = 200, from rest
  - hyperbolic motion: x = 2.16228, v = 0.948683
  - plane-wave drift: 0.3597 at t ≈ 600
  - Kepler advance: 61.34813° numerically against 61.34813° analytically
  - Moon period: 27.32194 d numerically
  - boost: checked against an explicit Λ F Λᵀ tensor transformation; both invariants are preserved.
- q5: found by brute-force enumeration. q6: found by an explicit 8×8 Jordan–Wigner construction; su(3) closure was checked.

## Ambiguities and interpretations
- **q1:** R⊕R is written `M(1,R)+M(1,R)`, C is `M(1,C)` and H is `M(1,H)`. For the 1×1 cases the brief's format is not completely explicit.
- **q3:**
  - "Terms" is taken as every coefficient pair, (2^n)², with no zero-skipping.
  - "Mults" is the plain d³ schoolbook count, with no Strassen.
  - The block product is 16³ products in Cl(N), so the ratio is 4⁸/16³ = 16.
- **q4 drift:**
  - No initial condition is given. The lab-time mean velocity is exactly E×B/B² whatever the initial condition, relativistically too, because the motion is periodic in the drift frame.
  - Any frame obtained by adding a boost along B also has E′ = 0. I took the drift frame (velocity E×B/B²), so γ = 1.25.
- **q4 period:** taken as the lab-time gyration period, 2πγm/(qB).
- **q4 Kepler:** taken as 360°/√(1−κ²/L²) − 360°. The starting point r = 1 is actually the aphelion of the precessing orbit, but that does not affect the advance.
- **q4 boost:** standard convention, with S′ moving at +0.6 x̂ and parallel axes:
  - E′⊥ = γ(E + v×B)⊥
  - B′⊥ = γ(B − v×E)⊥
- **q7:** floating-point noise of about 1e-16 was rounded to exact 0 and ±1.
- **q8:**
  - The relative orbit uses μ = G(M+m) with the given G = 6.6703e-11, which is not the CODATA value.
  - Because the velocity is perpendicular, the start is an apsis, and here it is the perigee (r < a).
