// Browser test of step 14 (null surfaces): every widget, every lens, every slider, EN and IT, desktop and phone width.
// The expected numbers are recomputed here from nullEngine.js (which test_null.mjs ties to selfcheck/null.json), not copied from the page.
// Run: node test_null_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default ../ui/dist next to this folder)
import { chromium } from '/opt/npm-tools/node_modules/playwright/index.mjs';
import { setLang } from './ui_helpers.mjs';
import * as E from './nullEngine.js';
import K from './nullData.js';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(process.env.ATLAS_DIST || path.resolve(here, '../ui/dist'), 'app.html');         // ATLAS_DIST is the dist folder, as in test_chat_ui.mjs
const errs = []; let checks = 0;
const ok = (c, m) => { checks++; if (!c) errs.push(m); };
const near = (a, b, tol, m) => ok(Number.isFinite(+a) && Math.abs(+a - b) <= tol, `${m}: ${a} vs ${b}`);
const b = await chromium.launch();

// move a range input and let React see it
const setRange = (loc, v) => loc.evaluate((el, val) => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, String(val)); el.dispatchEvent(new Event('input', { bubbles: true })); }, v);
const attr = (loc, a) => loc.getAttribute(a);
const f3 = (v, d) => (Math.abs(v) < 5 * 10 ** -(d + 1) ? '0' : String(+v.toFixed(d)));      // the page's own rounding, restated

for (const lang of ['en', 'it']) for (const w of [1100, 375]) {
  const tag = `${lang}${w}`;
  const pg = await b.newPage({ viewport: { width: w, height: 900 } });
  pg.on('pageerror', e => errs.push(`${tag}: pageerror ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${tag}: console ${m.text()}`));
  await pg.goto('file://' + DIST + '#equations/nullsurf'); await pg.waitForTimeout(350);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator('[data-profile="Mathematician"]').click(); await pg.waitForTimeout(250);
  const S = pg.locator('#eq-nullsurf');

  // ---- the page: eyebrow, tabs, cards, five figures, summary line from the data
  ok((await S.locator('.eyebrow').textContent()).includes('14'), `${tag}: eyebrow ${await S.locator('.eyebrow').textContent()}`);
  ok(await pg.locator('.tabbar [role=tab]').count() === 15, `${tag}: tabs ${await pg.locator('.tabbar [role=tab]').count()}`);
  ok(await S.locator('.nl-res').count() === 4, `${tag}: cards`);
  ok(await S.locator('[data-widget]').count() === 5, `${tag}: widgets`);
  for (let k = 1; k <= 5; k++) ok(await S.locator(`[data-fig="${k}"]`).count() === 1, `${tag}: fig ${k}`);
  // where each figure sits, and the empty-heading / empty-label guard
  for (const [res, ws] of [[1, ['cone']], [2, ['neck']], [3, ['crit', 'kerr']], [4, ['ladder']]]) { ok(await S.locator(`[data-result="${res}"] [data-widget]`).count() === ws.length, `${tag}: result ${res} holds ${ws.length} figure(s)`); for (const wd of ws) ok(await S.locator(`[data-result="${res}"] [data-widget="${wd}"]`).count() === 1, `${tag}: ${wd} is in result ${res}`); }
  ok(await S.locator('h2').count() === 1 && await S.locator('h3').count() >= 5, `${tag}: headings`); for (const hd of await S.locator('h2, h3, h4, .nl-fig, summary').allTextContents()) ok(hd.replace(/[\s0-9.]/g, '').length > 2, `${tag}: an empty heading "${hd}"`);
  for (const lab of await S.locator('svg[aria-label]').evaluateAll(es => es.map(e => e.getAttribute('aria-label')))) ok(lab.length > 20 && !/undefined/.test(lab), `${tag}: svg label "${lab}"`);
  ok(await S.locator('.eq-cap').evaluateAll(es => es.every(e => e.textContent.trim().length > 20)), `${tag}: every caption has text`);
  const sum = S.locator('.nl-sum');
  ok(await attr(sum, 'data-passed') === String(K.portal.summary.passed) && await attr(sum, 'data-computed') === String(K.portal.summary.computed) && await attr(sum, 'data-readings') === String(K.portal.summary.readings), `${tag}: summary data`);
  ok((await sum.textContent()).includes(String(K.portal.summary.passed)), `${tag}: summary text shows ${K.portal.summary.passed}`);
  ok(await S.locator('.tag.open').count() >= 1 && await S.locator('.tag.checked').count() >= 1 && await S.locator('.tag.standard').count() >= 1 && await S.locator('.tag.ours').count() >= 1, `${tag}: status tags`);

  // ---- figure 1: the cone. five cases x three lenses; the probe slider moves the surface off the horizon
  const cone = S.locator('[data-widget="cone"]'), csvg = cone.locator('svg');
  for (let ci = 0; ci < 5; ci++) {
    const h = E.HORIZONS[ci];
    await cone.locator(`[data-case="${h.id}"]`).first().click();
    for (const lens of ['clifford', 'cube', 'mirror']) {
      await cone.locator(`.nl-lens [data-lens="${lens}"]`).click();
      ok(await attr(csvg, 'data-lens') === lens && await attr(csvg, 'data-case') === h.id, `${tag} cone ${h.id}/${lens}: state`);
      ok(await cone.locator(`.nl-lens [data-lens="${lens}"]`).getAttribute('aria-pressed') === 'true' && await cone.locator('.nl-lens [aria-pressed="true"]').count() === 1, `${tag} cone ${lens}: pressed`);
      for (const d of [0, 0.3, -0.45]) {
        await setRange(cone.locator('[data-probe]'), d);
        const T = h.T(h.xh + d);
        near(await attr(csvg, 'data-T'), Math.abs(T) < 5e-6 ? 0 : +T.toFixed(5), 2e-5, `${tag} cone ${h.id} d=${d}: T`);
        ok(await attr(csvg, 'data-kind') === E.surfaceKind(T), `${tag} cone ${h.id} d=${d}: kind ${await attr(csvg, 'data-kind')}`);
        { const pt = await cone.locator('.nl-pt').evaluate(e => [+e.getAttribute('cx'), +e.getAttribute('cy')]), tm = E.tMax(h), tl = tm * 1.15, y0 = h.xh - E.PROBE - 0.05, y1 = h.xh + E.PROBE + 0.05;
          near(pt[0], 22 + (T + tl) / (2 * tl) * 130, 1e-6, `${tag} cone ${h.id} d=${d}: inset marker x (T)`); near(pt[1], 300 - ((h.xh + d) - y0) / (y1 - y0) * 270, 1e-6, `${tag} cone ${h.id} d=${d}: inset marker y (x)`); }
        if (lens === 'clifford') { const ln = await cone.locator('.nl-probe line').nth(1).evaluate(e => ['x1', 'y1', 'x2', 'y2'].map(a => +e.getAttribute(a))); near((ln[3] - ln[1]) / (ln[2] - ln[0]), T / E.tMax(h), 1e-9, `${tag} cone ${h.id} d=${d}: the drawn null line tilts as T / T_max`);
          ok(await cone.locator('.nl-cone').count() === 6 && await cone.locator('.nl-probe').count() === 1, `${tag} cone clifford: six cones, one probe`); near(await attr(cone.locator('.nl-probe'), 'data-T'), T, 6e-5, `${tag} cone probe T`); }
        if (lens === 'cube') {
          ok(await cone.locator('.nl-cv').count() === 8 && await cone.locator('.nl-br').count() === 3, `${tag} cone cube: 8 corners, 3 brackets`);
          const k1k2 = cone.locator('.nl-k1k2'); ok((await k1k2.getAttribute('stroke-dasharray')) === (d === 0 ? '4 3' : null), `${tag} cone cube ${h.id} d=${d}: [K1,K2] dashed only on the surface`);
          const alg = await cone.locator('[data-r="alg"]').getAttribute('data-kind'); ok(alg === (d === 0 ? 'iso2' : T > 0 ? 'so12' : 'so3'), `${tag} cone cube ${h.id} d=${d}: algebra ${alg}`);
        }
        if (lens === 'mirror') {
          const none = await cone.locator('[data-r="mir"]').getAttribute('data-none'); ok(none === (d === 0 ? '1' : '0'), `${tag} cone mirror ${h.id} d=${d}: no image only at T = 0 (${none})`);
          ok(await cone.locator('.nl-image').count() === 1, `${tag} cone mirror: image group`);
          if (d !== 0) { const img = E.mirrorImage([0.4, 0.8], T), txt = (await cone.locator('[data-r="mir"]').textContent()).replace(/\s/g, '').replace(/−/g, '-');
            ok(txt.includes(`w′=(${f3(img[0], 2)},${f3(img[1], 2)})`), `${tag} cone mirror ${h.id} d=${d}: image text ${txt}`); }
        }
        const t = await cone.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(t), `${tag} cone ${h.id}/${lens} d=${d}: placeholder in text`);
      }
    }
    await cone.locator('.nl-lens [data-lens="clifford"]').click(); await cone.locator('.nl-zero').click();
    ok(+await cone.locator('[data-probe]').inputValue() === 0 && await attr(csvg, 'data-kind') === 'null', `${tag} cone ${h.id}: the on-surface button returns to T = 0`);
    const kt = await cone.locator('[data-r="T"]').textContent(); ok(kt.includes('κ'), `${tag} cone ${h.id}: κ in readout`);
  }

  { const rg = async (loc) => loc.evaluate(e => [+e.min, +e.max]); const a = await rg(cone.locator('[data-probe]')); ok(a[0] === -E.PROBE && a[1] === E.PROBE, `${tag} cone probe range ${a}`); }
  // ---- figure 2: horizon or throat; slider r; lenses clifford / null / flow
  const neck = S.locator('[data-widget="neck"]'), nsvg = neck.locator('svg');
  for (const lens of ['clifford', 'null', 'flow']) {
    await neck.locator(`.nl-lens [data-lens="${lens}"]`).click();
    ok(await attr(nsvg, 'data-lens') === lens, `${tag} neck ${lens}: state`);
    for (const r of [1.02, 1.3, 2]) {
      await setRange(neck.locator('[data-r].nl-range'), r);
      near(await attr(nsvg, 'data-r'), r, 1e-9, `${tag} neck ${lens} r=${r}: r`);
      const rd = (await neck.locator('[data-r="schw"]').textContent()).replace('−', '-'), re = (await neck.locator('[data-r="ellis"]').textContent()).replace('−', '-');
      ok(rd.includes(String(+E.schwT(r).toFixed(4))), `${tag} neck r=${r}: schw readout ${rd}`);
      const flat = x => x.replace(/\s/g, '').replace(/\^/g, '');
      ok(flat(re).includes('T=1') && flat(re).includes(`grr=${f3(-(1 - 1 / (r * r)), 4)}`), `${tag} neck r=${r}: ellis readout ${re}`);
      if (lens === 'clifford') { const mk = await neck.locator('.nl-marks circle').evaluateAll(es => es.map(e => [+e.getAttribute('cx'), +e.getAttribute('cy')])), top = 50, hh = 230, px = c0 => c0 + (r - 1) * 300, py = v => top + hh - v * hh;
        ok(mk.length === 3, `${tag} neck r=${r}: three marks`); if (mk.length === 3) { const want = [[px(40), py(E.invariants.schw(r).n2)], [px(420), py(E.invariants.ellis(r).n2)], [px(420), py(E.invariants.ellis(r).grr)]]; want.forEach((w2, q) => { near(mk[q][0], w2[0], 1e-6, `${tag} neck r=${r}: mark ${q} x`); near(mk[q][1], w2[1], 1e-6, `${tag} neck r=${r}: mark ${q} y`); }); } }
      if (lens === 'clifford') ok(await neck.locator('.nl-c-n2').count() === 2 && await neck.locator('.nl-c-grr').count() === 2, `${tag} neck clifford: curves`);
      if (lens === 'null') ok(await neck.locator('.nl-live-k').count() === 2 && await neck.locator('.nl-live-e').count() === 2 && await neck.locator('.nl-row').count() > 6, `${tag} neck null: live curves and the K figure`);
      if (lens === 'flow') { ok(await neck.locator('.nl-f-dr').count() === 2 && await neck.locator('.nl-f-dl').count() === 2 && await neck.locator('[data-r="rates"]').count() === 1, `${tag} neck flow: rates`);
        const rt = (await neck.locator('[data-r="rates"]').textContent()).replace('−', '-'); ok(rt.includes(String(+E.rates.schw.dr(r).toFixed(4))) && rt.includes(String(+E.rates.ellis.dr(r).toFixed(4))), `${tag} neck flow r=${r}: ${rt}`); }
      const t = await neck.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(t), `${tag} neck ${lens} r=${r}: placeholder`);
    }
  }
  { const a = await neck.locator('[data-r].nl-range').evaluate(e => [+e.min, +e.max]); ok(a[0] === 1.02 && a[1] === 2, `${tag} neck r range ${a}`); }
  // the throat's n.n stays -1 while the horizon's goes to 0: read it at the extreme
  await setRange(neck.locator('[data-r].nl-range'), 1.02);
  const nn1 = (await neck.locator('[data-r="schw"]').textContent()).replace('−', '-'); ok(/n·n = -?0\.0196/.test(nn1) || nn1.includes('0.0196'), `${tag} neck: n·n near the horizon ${nn1}`);

  // ---- figure 3: Eq. (1) on three null surfaces
  const crit = S.locator('[data-widget="crit"]'), qsvg = crit.locator('svg');
  for (const cs of E.EQ1) {
    await crit.locator(`[data-eq="${cs.id}"]`).click();
    ok(await attr(qsvg, 'data-case') === cs.id && await crit.locator(`.nl-eq1[data-id="${cs.id}"]`).count() === 1, `${tag} crit ${cs.id}: state`);
    for (const lx of [-3, -2, -0.3]) {
      await setRange(crit.locator('[data-x]'), lx);
      const x = 10 ** lx, e1 = cs.eq1(x);
      near(Math.log10(+(await attr(qsvg, 'data-eq1'))), Math.log10(e1), 1e-6, `${tag} crit ${cs.id} lx=${lx}: Eq.(1) magnitude`);
      near(cs.T(x) * cs.dT(x) ** 2 / e1, 1, 1e-9, `${tag} crit ${cs.id}: identity |Eq.(1)| = T (dT/dx)^2`);
      { const pt = await crit.locator('.nl-pt').evaluate(e => [+e.getAttribute('cx'), +e.getAttribute('cy')]); near(pt[0], 60 + (lx + 3) * 150, 1e-6, `${tag} crit ${cs.id} lx=${lx}: marker x`); near(pt[1], 300 - (Math.log10(e1) + 12) * 18, 1e-6, `${tag} crit ${cs.id} lx=${lx}: marker y`); }
    }
    const t = await crit.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(t), `${tag} crit ${cs.id}: placeholder`);
  }

  { const a = await crit.locator('[data-x]').evaluate(e => [+e.min, +e.max]); ok(a[0] === -3 && a[1] === -0.3, `${tag} crit slider range ${a}`); }
  // ---- figure 4: Kerr, slider theta
  const kerr = S.locator('[data-widget="kerr"]'), ksvg = kerr.locator('svg');
  for (const deg of [0, 30, 60, 90]) {
    await setRange(kerr.locator('[data-theta].nl-range'), deg);
    const w2 = Math.cos(deg * Math.PI / 180) ** 2, nn = E.kerrNN(w2);
    ok(await attr(ksvg, 'data-theta') === String(deg), `${tag} kerr ${deg}: theta`);
    ok(await kerr.locator('[data-r="nn"]').getAttribute('data-pole') === (Math.abs(w2 - 1) < 1e-9 ? '1' : '0'), `${tag} kerr ${deg}: pole flag`);
    near(Math.log10(Math.abs(+await attr(ksvg, 'data-nn')) + 1e-300), Math.log10(Math.abs(nn) + 1e-300), 1e-5, `${tag} kerr ${deg}: n·n`);
    ok(nn <= 1e-12, `${tag} kerr ${deg}: n·n is not positive`);
    { const th = deg * Math.PI / 180, p = E.kerrXZ(E.kerrErgo(w2), th), mk = await kerr.locator('.nl-mark').evaluate(e => [+e.getAttribute('cx'), +e.getAttribute('cy')]); near(mk[0], 250 + 14 * p[0], 1e-6, `${tag} kerr ${deg}: marker x`); near(mk[1], 165 - 14 * p[1], 1e-6, `${tag} kerr ${deg}: marker y`);
      const fill = await kerr.locator('.nl-mark').getAttribute('fill'); ok((nn < 0) === (fill === '#fbbf24'), `${tag} kerr ${deg}: the marker is amber while the normal is time-like (${fill})`); }
    ok(await kerr.locator('.nl-horizon').count() === 2 && await kerr.locator('.nl-ergo').count() === 2, `${tag} kerr: two curves each side`);
    const t = await kerr.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(t), `${tag} kerr ${deg}: placeholder`);
  }
  { const raw = await kerr.locator('[data-r=\"rE\"] .mt').first().getAttribute('data-raw'), txt = (await kerr.locator('[data-r=\"rE\"]').textContent()).trim(); ok(/g_tt\(r_E\)/.test(raw || '') && /gtt\(rE\)\s*=\s*0$/.test(txt), `${tag} kerr: g_tt is zero on the ergosurface (readout): ${txt}`); }

  { const a = await kerr.locator('[data-theta].nl-range').evaluate(e => [+e.min, +e.max]); ok(a[0] === 0 && a[1] === 90, `${tag} kerr angle range ${a}`); }
  // ---- figure 5: the ladder n = 2..6 x four lenses; vertex click and keyboard
  const lad = S.locator('[data-widget="ladder"]'), lsvg = lad.locator('svg');
  for (const n of E.NS) {
    await lad.locator(`[data-n="${n}"]`).first().click();
    const m = n - 1, N = 1 << m, row = K.portal.ladder.find(r => r.n === n);
    ok(await attr(lsvg, 'data-n') === String(n) && await attr(lsvg, 'data-dim') === String(row.dim) && await attr(lsvg, 'data-j') === String(row.J), `${tag} ladder n=${n}: state`);
    for (const lens of ['clifford', 'cube', 'simplex', 'prime']) {
      await lad.locator(`.nl-lens [data-lens="${lens}"]`).click();
      ok(await attr(lsvg, 'data-lens') === lens, `${tag} ladder n=${n}/${lens}: lens`);
      if (lens === 'clifford') { ok(await lad.locator('.nl-J').count() === 1 && await lad.locator('.nl-Q').count() === 1 && await lad.locator('.nl-q').count() === 4, `${tag} ladder n=${n} clifford: boxes`); const cl = (await lad.locator('[data-r="cl"]').textContent()); ok(cl.includes(`dim ${row.dim}`) && cl.includes(`dim J = ${row.J}`), `${tag} ladder n=${n}: readout ${cl}`); }
      if (lens === 'cube') {
        ok(await lad.locator('.nl-lv').count() === N && await lad.locator('.nl-j').count() === N / 2 && await lad.locator('.nl-qv').count() === N / 2, `${tag} ladder n=${n} cube: ${await lad.locator('.nl-lv').count()} vertices, J ${await lad.locator('.nl-j').count()}`);
        ok(await lad.locator('.nl-j').count() === row.J && await attr(lad.locator('[data-r="cube"]'), 'data-count') === String(row.J), `${tag} ladder n=${n} cube: J count`);
        { const vs = await lad.locator('.nl-lv').evaluateAll(es => es.map(e => [+e.getAttribute('data-s'), e.getAttribute('data-j'), e.classList.contains('nl-j'), e.getAttribute('fill'), e.parentElement.getAttribute('aria-label')])); ok(vs.every(([S, dj, isJ, fill, al]) => { const inJ = (S >> (n - 2) & 1) === 1; return dj === (inJ ? '1' : '0') && isJ === inJ && fill === (inJ ? '#fbbf24' : '#34d399') && al.includes('· J') === inJ; }), `${tag} ladder n=${n} cube: a vertex is in J exactly when its label has the null bit (class, fill, data and accessible name)`); }
        // click the last vertex (all bits, in J) and the first (the scalar, not in J)
        await lad.locator(`.nl-lv[data-s="${N - 1}"]`).dispatchEvent('click'); ok(await lad.locator('.nl-lv.on').count() === 1 && (lang === 'en' ? /in J and/ : /sta in J/).test(await lad.locator('[data-r="cube"]').textContent()), `${tag} ladder n=${n}: select top vertex (in J)`);
        await lad.locator(`g[role=button]`).nth(0).focus(); await pg.keyboard.press('Enter'); ok(await lad.locator(`.nl-lv[data-s="0"]`).evaluate(e => e.classList.contains('on')), `${tag} ladder n=${n}: keyboard selects the scalar`);
        { const line = await lad.locator('[data-r="cube"]').textContent(); ok(lang === 'en' ? /in the quotient/.test(line) && !/in J and/.test(line) : /nel quoziente/.test(line) && !/sta in J/.test(line), `${tag} ladder n=${n}: scalar vertex is in the quotient: ${line}`); }
      }
      if (lens === 'simplex') { const lab = await lsvg.locator('text').allTextContents(); ok(lab.includes('ℓ') && Array.from({ length: m - 1 }, (_, k) => 'e' + (k + 1)).every(x => lab.includes(x)), `${tag} ladder n=${n} simplex: generator labels ℓ, e1..e${m - 1}: ${lab}`); ok(await lad.locator('.nl-sv').count() === m && await lad.locator('.nl-sv0').count() === 1, `${tag} ladder n=${n} simplex: ${await lad.locator('.nl-sv').count()} vertices (need ${m})`); ok(await lad.locator('.nl-se').count() === m * (m - 1) / 2 && await lad.locator('.nl-star').count() === m - 1, `${tag} ladder n=${n} simplex: edges ${await lad.locator('.nl-se').count()}, star ${await lad.locator('.nl-star').count()}`); ok(await attr(lad.locator('[data-r="simplex"]'), 'data-count') === String(row.J), `${tag} ladder n=${n} simplex: faces count`); }
      if (lens === 'prime') { ok(await lad.locator('.nl-pr').count() === 3 && await attr(lad.locator('[data-r="prime"]'), 'data-pow2') === '1', `${tag} ladder n=${n} prime: three powers of two`); const vs = await lad.locator('.nl-pr').evaluateAll(es => es.map(e => +e.getAttribute('data-val'))); ok(vs.join() === [row.dim * 2, row.dim, row.J].join(), `${tag} ladder n=${n} prime: values ${vs}`); }
      const t = await lad.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(t), `${tag} ladder n=${n}/${lens}: placeholder`);
    }
  }
  // n = 5, 6 carry the textbook tag in the readout; n = 2, 3, 4 do not
  await lad.locator('[data-n="4"]').first().click(); await lad.locator('.nl-lens [data-lens="clifford"]').click();
  const t4 = await lad.locator('[data-r="cl"]').textContent(); await lad.locator('[data-n="5"]').first().click(); const t5 = await lad.locator('[data-r="cl"]').textContent();
  ok(t5.length > t4.length && t5.includes('('), `${tag} ladder: textbook note appears at n = 5 only`);

  // ---- the whole page: no placeholder, no horizontal overflow, nothing empty in the figures, no English in the Italian page's figure text
  const all = await S.textContent(); ok(!/undefined|NaN|\[object|Infinity/.test(all), `${tag}: placeholder in page`);
  const over = await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(over <= 1, `${tag}: horizontal overflow ${over}px`);
  const wide = await S.evaluate(el => [...el.querySelectorAll('svg, .nl-line, .eq-card')].filter(e => e.getBoundingClientRect().right > window.innerWidth + 1).length); ok(wide === 0, `${tag}: ${wide} elements wider than the screen`);
  const lensNames = await S.locator('.nl-lens button').allTextContents(); ok(lensNames.every(s => s.trim().length > 0), `${tag}: lens chip text`);
  if (lang === 'it') { const it = await S.locator('h2, h3, h4, .eq-cap').allTextContents(); ok(!it.some(s => /\b(the|which|because|where|while)\b/i.test(s)), `${tag}: English words in Italian headings or captions: ${it.filter(s => /\b(the|which|because|where|while)\b/i.test(s)).join(' | ').slice(0, 200)}`); }
  await pg.close();
}

// ---- the three audiences change the lede and the folds, never the numbers
{
  const pg = await b.newPage({ viewport: { width: 1100, height: 900 } });
  pg.on('pageerror', e => errs.push(`aud: pageerror ${e.message}`));
  await pg.goto('file://' + DIST + '#equations/nullsurf'); await pg.waitForTimeout(350);
  const seen = {};
  for (const prof of ['Young Learner', 'Physicist', 'Mathematician']) {
    await pg.locator(`[data-profile="${prof}"]`).click(); await pg.waitForTimeout(200);
    seen[prof] = (await pg.locator('#eq-nullsurf .lede').first().textContent()) || '';
    ok(await pg.locator('#eq-nullsurf [data-widget]').count() === 5 && await pg.locator('#eq-nullsurf .nl-res').count() === 4, `aud ${prof}: widgets and cards stay`);
    const s = pg.locator('#eq-nullsurf .nl-sum'); ok(await attr(s, 'data-passed') === String(K.portal.summary.passed), `aud ${prof}: summary numbers stay`);
  }
  ok(new Set(Object.values(seen)).size >= 2, 'aud: the lede differs between audiences');
  await pg.close();
}

// ---- the download buttons produce a file (python source and json) without an error
{
  const pg = await b.newPage({ viewport: { width: 1100, height: 900 }, acceptDownloads: true });
  pg.on('pageerror', e => errs.push(`dl: pageerror ${e.message}`));
  await pg.goto('file://' + DIST + '#equations/nullsurf'); await pg.waitForTimeout(350);
  await pg.locator('[data-profile="Mathematician"]').click(); await pg.waitForTimeout(200);
  for (const name of ['null_selfcheck.py', 'null.json']) {
    const [dl] = await Promise.all([pg.waitForEvent('download', { timeout: 4000 }).catch(() => null), pg.locator('#eq-nullsurf .eq-btn').filter({ hasText: name.endsWith('py') ? /\.py|python|Python/ : /json|JSON/ }).first().click()]);
    ok(dl && dl.suggestedFilename() === name, `download ${name}: ${dl ? dl.suggestedFilename() : 'none'}`);
  }
  await pg.close();
}
await b.close();
console.log(errs.length ? `${errs.length} FAILURES of ${checks}\n` + errs.slice(0, 60).join('\n') : `ok: ${checks} checks`);
process.exit(errs.length ? 1 : 0);
