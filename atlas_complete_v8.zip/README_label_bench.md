# Label speed test (`label_bench.html`)

A single standalone page that **times**, in your own browser, whether the "bit-label" speed-ups claimed in the maths app give any gain on your machine.
It measures; it does not prove. A result is true of this browser, this machine, its power mode and the load it had at that moment, and of nothing else.

**What is ours and what is standard** (shown at the top of the page and in every section): for each job the page times the *standard* method against *ours*, on the same inputs, after checking that both give the same answers.

| Job | Standard | Ours |
|---|---|---|
| Vertices of the cube | one sandwich per corner (2^n sandwiches) | the frame: n + 1 sandwiches, then additions |
| Contact: deepest corner under a plane | scan of all 2^n corners | n sign bits of the frame |
| Outline of the projected cube | convex hull of the 2^n projected points | zonogon from the n projected edges |
| Product of two dense multivectors | the matrix route Cl(k,k) = M(2^k, R), the textbook way | the bit rule (signs from the labels, XOR), here with a sign table |
| Many bodies, whole step | direct corners, then scan | the frame, then sign bits |
| Allocation | Float64Array | plain Array (the engine's choice) |

After a run, **At a glance** gives one row per job, read from the side of ours: the ratio (standard time / ours) at the largest size timed, the verdict, a noisy flag, and by n where ours is faster. Above it a generated sentence names the best result *of that run* and, if there is one, where ours loses (in the product, the matrix route wins from some n on; the page says so). The sentence is computed from the timings, nothing in it is fixed. To show a fixed sentence about our best model as well, put it in `OUR_SENTENCE` at the top of the scenario block in `label_bench_src/page.js` and rebuild; it is then shown above the generated text.

## Open it
Download `label_bench.html` and double-click it (Chrome, Firefox or Safari, `file://` is fine). It makes no network request, loads no library and no font, and sends nothing anywhere.
For a stable result: close other tabs, plug in the power, keep the tab in the foreground, do not resize the window while it runs. Press **Run** (the **Quick** preset is selected: 20 ms batches, 3 repetitions);
use **Careful** (200 ms batches, 15 repetitions) when a row is flagged noisy. **Stop** ends the run and keeps what has been timed.

The timing runs in a Web Worker built from a Blob URL of the same inlined source, so the page stays responsive. If a Worker cannot be started the page falls back to the main thread (chunked with `setTimeout`)
and says so under the buttons ("Mode: ..."). Adding `#main` to the address forces the fallback.

## The scenarios (each runs the correctness check first: all variants must give the same answers, otherwise nothing is timed)
| Scenario | What is timed, per call |
|---|---|
| **Vertices** | The 2^n world corners of an n-cube from a motor: *direct* (2^n sandwiches), *frame* (n+1 sandwiches then 2^n-1 additions), *frame with the odd half mirrored through the centre*, the *matrix route* (frame, then n^2 flops a corner), and the table step alone (doubling against n^2 a corner, frame given). Claim: frame against direct. |
| **Contact** | The deepest corner under a plane: *scan* of 2^n dot products against *n sign bits* of the frame, with the table or frame **given** and with its **building counted**. |
| **Outline** | The flat outline of the projected cube: *convex hull* of the 2^n points against the 2n-corner *zonogon* from the n projected edges, given and building counted. |
| **Product** (new in 1.1.0) | The dense product of two multivectors of the neutral algebra Cl(k,k), n = 2k = 2, 4, ..., 12 (14 optional and slow). *Bit rule*: 4^n terms, each sign worked out. *Sign table*: the same terms, signs read from a table built before the clock. *Matrix route*: Cl(k,k) = M(2^k, R), so the multivector becomes a 2^k x 2^k real matrix (a butterfly on each of the k sites, k 4^k additions), one matrix product (8^k multiplications), and back. *Matrix product alone*: the matrices already exist. *Period 8 blocks* (n >= 10): Cl(N+8) = M16(Cl(N)), the product as 16^3 = 4096 products in Cl(n-8) by the bit rule. Inputs are dense integers; the check compares the answers **exactly** (`===`) before any timing, and `selfcheck/matrixrep_check.py` proves the representation in exact Python integers (the page's tables are rebuilt in JavaScript and `test_product.mjs` compares them with its fixtures). Claim: the matrix route against the sign table, against the plain rule, the matrix product alone, and the period-8 blocks. The ratio should be below 1 at small n (the conversion costs more than it saves) and then grow. Counting says the matrix product alone gains 2^(n/2) over the bit rule, about 2x per two dimensions, and the measurements on one machine agree (2.1x to 2.4x per two dimensions from n = 6 to 12). The whole route grew faster than that between n = 8 and 12 (2.7x to 3.2x per two dimensions) because the conversion, k 4^k additions, becomes small next to the product (route time over matrix-product time: 2.2, 1.5, 1.3 at n = 10, 12, 14), so the route can only approach the product's own gain from below. Sparse multivectors (a few blades) are another case and are not timed. |
| **Many bodies** | B bodies (100, 1000, 10000), each with its own motor from a seeded generator (seed 12345, so the scene is reproducible). One scene step: build every body's corners (direct against frame); a contact query of every body against one plane (scan against sign bits, given and building counted); and the whole path (direct and scan against frame and sign bits). Reported as ms per scene step and bodies per second. Motors are fixed: integrating the dynamics is not counted. |
| **Warm-up and cold start** | Call 1, calls 1-10, 11-100, 101-1000 of one function against its steady state. Every repeat starts a **fresh worker** so the code is cold (in main-thread mode it cannot be, and the page says so). The set-up (algebra tables, motor) is outside the clock. Times below the timer step are shown as upper bounds, not as numbers. |
| **Allocation** | Plain `Array` against `Float64Array` for allocating 8, 16, 32 and 64 doubles, and for a small sandwich-like loop (with and without reused Float64Array buffers). Reproduces, or not, the finding that made the engine use plain arrays (node 22: a Float64Array of 16 or more doubles cost about 2.3 us against 0.06 us). Whatever your browser gives is shown. |

## How to read a row
* **At a glance**: ratio = standard time / ours (medians), so 3x means ours took a third of the time and 0.3x is shown as "3.3x slower". The verdict rule below is applied in the direction of the detail comparison (so the product row is the matrix route against the sign-table bit rule, turned around to read from ours).
* **Detail tables**: only the key comparison of each scenario is open (marked *key result*); the other comparisons, all timings and the method text are folds (open them with the arrows). In Many bodies and Warm-up the timing table is the result and stays open.
* **Ratio** = baseline time / variant time (medians). "frame is 3.24x faster" means the frame took 1/3.24 of the direct time; "frame is 0.67x, i.e. slower" means it took 1/0.67 of it.
* **Spread** of a timing = (slowest batch - fastest batch) / median over the repetitions. Above 15% the row is flagged "⚠ noisy" (repeat with Careful).
* **Verdict**: *about equal within noise* when |ratio - 1| is below the larger of 5% and the larger spread of the two timings; otherwise *faster* or *slower*. A rule of thumb for one run, not a statistical test.
* **Chart**: log scale, bars start at the 1x line (up: faster, down: slower), colour follows the verdict, and every bar carries its value as text (`*` = noisy). Hatched bars are the "building counted" series.
* **Timer step**: the smallest observable step of `performance.now()` is measured and shown. Above 5 us the page warns; batches of at least 20 ms make that irrelevant for the batch timings, but single-call times (warm-up) are then only indicative.

## Save, share, compare
**Download JSON** (settings, machine info, checks, rows, and, new in 1.2.0, `glance`: the At a glance rows and summary; `formatVersion` is still 1, the field is additive), **Download CSV** (one row per timing and per ratio), **Copy as text** (a readable summary, also shown in the "Text summary" box).
To compare two machines, send the JSON; the other person opens the page, runs it, and loads your JSON under **Compare with another run** (or loads the embedded *reference run on one 2-core VM, node 22*).
The table shows the claimed ratio on each side and the ratio between the two. The product timings are in the JSON under `product` and in the CSV and the text summary; the comparison table covers the vertices, contact and outline scenarios only. The JSON `rows` have the same shape as `selfcheck/bench_labels.json`, so a file from `node selfcheck/bench_labels.mjs --write file.json` can be loaded as well.
Everything stays in your browser.

## Versions
* **1.2.0**: a clearer page, no change to any timed code (same kernel fingerprint, same variants, same verdict rule). A short opening and a table of what is standard and what is ours; a new **At a glance** table with a generated best-result sentence (and where ours loses); each section opens with the standard/ours pair and shows its key comparison, with the other comparisons, all timings and the method text folded; the seven repeated "correctness check passed" paragraphs became one line each; hints, notes and warnings are shorter (about 30% less text on screen after a run); the noisy tag in tables is just "⚠ noisy" (the banner says what to do); the chart titles say which side is ours; the text summary and the JSON carry the glance. The pre-existing `Many bodies` and `Warm-up` tables stay open. v1.1.1 is kept unchanged next to it.
* **1.1.1**: the text summary now prints the scenario settings (Many bodies: B, n and seed; product: largest n; warm-up: n) and the Many-bodies heading carries B and n. Before, only the CSV and JSON did, so two summaries from runs with different scene sizes looked comparable. Timings and checks are unchanged (same kernel fingerprint).
* **1.1.0**: the Product scenario.

## Regenerate
```
node build_label_bench.mjs          # writes label_bench.html (about 157 KB, deterministic: same sources, same bytes)
node test_label_bench.mjs           # Playwright checks, prints LABEL BENCH OK
```
The build inlines the **real source** of `pgaEngine.js`, `benchKernels.js` and `productKernels.js`: only the `import` line and the `export` keywords are removed, mechanically.
The variants that the page times are not retyped: the 14 lambdas and the set-up line are cut out of `runBench` in `benchKernels.js` at build time (the build fails if that file changes shape), so the page cannot drift from the kernels the app uses.
The page-specific code is in `label_bench_src/` (`template.html`, `style.css`, `runners.js` for the scenarios and the worker side (the product job is there), `page.js` for the interface). `test_label_bench.mjs` needs Playwright (module path at the top of the file).

## What this does not show
Other machines, browsers, engines and languages are open; WebAssembly and SIMD were not tried; the kernels are small plain-JavaScript functions; the counts of operations are an arithmetic fact, the seconds are a measurement
with a spread. The worker's results are shown live, which costs the page a little work on another thread while the worker times; on a one-core machine that can add noise.
