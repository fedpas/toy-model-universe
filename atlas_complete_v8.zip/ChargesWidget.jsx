import React, { useState, useRef } from 'react';
import M from './maxwellData.js';
import { SPEC, PRESET_IDS, defaults, initRun, advance, readout, TERMS } from './chargeEngine.js';
import { Tx } from './MathText.jsx';

// "A charge moving in the fields": the Lorentz force as the contraction half of the same move, then six situations to play with.
// chargeEngine.js integrates the motion with the table that selfcheck/maxwell_selfcheck.py checks exactly; test_charges.mjs compares the two, test_charges_ui.mjs the widget.
// Playing: while it plays, a slider that changes the field (B, E, E/B, q/m, κ, a) acts on the running motion; a slider that changes the start (v₀) begins a new run and keeps the play state.
const CH = M.charges, ROW = Object.fromEntries(CH.rows.map(r => [r.id, r]));
const C = { E: '#4cc9f0', B: '#ffa06f', F: '#4fd18b', V: '#e5e7eb', T: '#a78bfa', R: '#ff5d8f' };
const f2 = x => { const r = Math.abs(x) < 5e-5 ? 0 : Math.round(x * 100) / 100; return String(r).replace('-', '−'); };
const f3 = x => { const r = Math.abs(x) < 5e-5 ? 0 : Math.round(x * 1000) / 1000; return String(r).replace('-', '−'); };
const AXN = ['t', 'x', 'y', 'z'];
const W = 360, H = 300;

const T = {
  en: {
    h: 'A charge moving in the fields', eyebrow: 'FROM THE FIELD TO THE MOTION',
    lede: 'Until now the field only sat there. Put a charge into it and let go. The force on the charge is the same kind of move as in ∇F = J: take a piece of F, add or drop one direction. Press play, then move a field slider while it plays: the motion goes on with the new field.',
    presetLbl: 'Choose a situation',
    presets: { circle: 'B only: a circle', hyper: 'E only: a speed limit', crossed: 'E and B crossed: a drift', spiral: 'E parallel to B: a spiral', orbit: 'A point charge: an orbit', wave: 'A light wave: a figure of eight' },
    worldTag: w => w === 2 ? 'in a plane: 2 space dimensions' : 'in space: 3 space dimensions',
    what: {
      circle: 'B points out of the page. The force is always sideways to the velocity, so the speed never changes and the charge goes round a circle of radius γ m v / (q B). Faster means a bigger circle, and a bigger γ makes it bigger again.',
      hyper: 'E pushes along its lines for ever, yet the speed never reaches that of light: x(t) = (√(m² + (qEt)²) − m) / (qE) with m² = 1 + u_y². Look at the sideways motion: no force acts sideways, yet it slows down, because the total speed cannot pass 1. Newton would say the speed grows without limit (the number in the check).',
      crossed: 'E points up the page and B out of it. The charge does not follow E: on average it drifts sideways at E/B of the speed of light, whatever its charge and mass. Take E/B above 1 and the drift is gone: there is a frame where B vanishes, and the charge runs away along E.',
      spiral: 'E and B both point along z. The boost along z (from E) and the rotation in the plane (from B) do not disturb each other, because the two generators commute (checked exactly). So the charge circles while it speeds up: a spiral. E·B ≠ 0 in every frame.',
      orbit: 'A fixed point charge attracts the test charge. With Newton the orbit is an ellipse that closes. With the speed limit it does not: the ellipse turns by 2π(1/√(1 − κ²/L²) − 1) each time round, a rosette. Make κ larger and the turn grows; make it negative and the charge is pushed away.',
      wave: 'A plane light wave E_x = B_y = a cos(t − z) goes by. The quantity u_t − u_z cannot change (checked exactly), so the sideways motion is exactly u_x = a sin τ and the charge is pushed along z, on average at a²/(4 + a²) of the speed of light. Switch to the frame that moves with that average and it traces a figure of eight (the z axis is stretched four times).'
    },
    play: 'Play', pause: 'Pause', step: 'Step', reset: 'Reset', speedLbl: 'Animation speed',
    params: { B: 'magnetic field B', E: 'electric field E', rho: 'E / B', qm: 'charge ÷ mass, q/m', v0: 'starting speed ↻', kappa: 'attraction κ', a: 'wave strength a' },
    ctlNote: 'The slider marked ↻ sets the start and begins a new run (it keeps playing if it was playing). The others change the field or the charge and act on the motion while it plays; paused, they change nothing until you press play.',
    top: 'Seen from above (x right, y up)', side: 'Seen from the side (z right, x up)', speedChart: 'Speed against time, as a fraction of the speed of light', c: 'c',
    legend: ['the charge and its velocity', 'the field at the charge: E (blue), B (orange)', 'the force (green)'],
    read: { t: 'time t', tau: 'its own time τ', gamma: 'γ = u_t', v: 'speed v/c', u2: 'u·u − 1', i1: 'E² − B²', i2: 'E·B' },
    forceH: 'Where the force comes from',
    forceText: 'Each edge of F joins two vertices. It sends the velocity at one end to the force at the other: f at a vertex is the sum over the edges there of (the value on the edge) × (the velocity at the other end). That is the “drop one direction” move of ∇F = J, with ∂ replaced by u; only the contraction half is kept, the force is a vector. The charge times E at the time vertex is the work done; B never appears there.',
    rowsH: 'The same thing as equations (q/m = 1)',
    f: { t: 'f_t', x: 'f_x', y: 'f_y', z: 'f_z' },
    chk: {
      circle: (m, f) => `Radius from the path: ${m}. From the formula γ m v / (q B): ${f}.`, circleWait: 'Go round half a turn and the radius is measured from the path.',
      hyper: (m, f, n, sp) => `Position x from the run: ${m}. From x(t) above: ${f}. Speed ${sp} c; Newton would say ${n} c.`,
      drift: (m, f, k) => `Mean velocity over ${k} full turn${k === 1 ? '' : 's'} in the drift frame: ${m}. E/B: ${f}.`, driftWait: 'Complete one turn in the drift frame and the mean velocity is measured.',
      runaway: r => `E/B = ${r}: E is stronger than B. A frame exists where B vanishes and the charge is accelerated for ever: its speed tends to c, it never reaches it.`,
      spiral: (m, f) => `u_z from the run: ${m}. From γ₀ sinh(q E τ / m): ${f}.`,
      orbit: (m, f, k) => `Advance of the perihelion each turn: ${m}° measured. From 2π(1/√(1 − κ²/L²) − 1): ${f}°. (${k} perihelia so far)`, orbitWait: (f, k) => `Wait for two perihelia (${k} so far). The formula says ${f}° each turn.`,
      repulsive: 'Repulsion: no orbit to close. The charge is scattered once.', falls: r => `κ/L = ${r} ≥ 1: no stable orbit, the charge falls onto the centre.`,
      wave: (c, m, f, k) => `u_t − u_z = ${c}, and stays so. Mean drift over ${k} full cycle${k === 1 ? '' : 's'}: ${m}. a²/(4 + a²): ${f}.`, waveWait: (c, f) => `u_t − u_z = ${c}, and stays so. Mean drift: complete a cycle (formula a²/(4 + a²) = ${f}).`,
      changed: 'You changed the field while it was running. The closed forms belong to the field the run started with, so they are hidden; u·u = 1 still holds and is shown above.'
    },
    exact: 'checked exactly', numeric: 'checked numerically',
    listH: 'What is checked, and how',
    listNote: 'Rational numbers and exact algebra on the bit rule for the first nine lines (the script is at the end of this tab, under “Check it yourself”); a Runge–Kutta run of the same table against the closed form for the last five.',
    list: {
      force_is_grade1: r => `The force on a charge is the grade-1 part of the product F u: it equals the textbook force in 2, 3 and 4 space dimensions (${r.trials} random rational cases). The other sign does not.`,
      force_is_contraction: r => `Its terms are the contraction terms of ∇F = J: same edges, same targets, with ∂ replaced by u and a fixed sign rule (${r.terms[2]}, ${r.terms[3]} and ${r.terms[4]} terms in 2, 3 and 4 space dimensions: two per edge).`,
      speed_limit: r => `u·f = 0, so u·u stays 1: the speed can approach c and never reach it. A magnetic field alone does no work (${r.trials} cases).`,
      circle_and_hyperbola: r => `The circle (B only) and the hyperbola (E only) solve the equation of motion exactly: ${r.circle_points} and ${r.hyperbola_points} rational points of their parametrisations, rate qB/m and rapidity qEτ/m.`,
      drift_frame: r => `For E ⊥ B and E < B a charge moving at E×B/B² feels no force (${r.cases.length} exact cases); the boost that removes E is found, and B′ = √(B² − E²).`,
      invariants: r => `E² − B² and E·B do not change under boosts and rotations (${r.checks} cases).`,
      parallel: () => 'For E ∥ B the two bivector generators commute: a boost along z times a rotation in the plane, and E·B ≠ 0.',
      point_charge: r => `The field of a point charge obeys Gauss and Faraday away from the charge (${r.points} points); the force on a test charge is central.`,
      light_wave: r => `E_x = B_y = f(t − z) solves the vacuum equations (and B_y = −E_x is the wave going the other way); u_t − u_z never changes (${r.u0_minus_uz_conserved} cases).`,
      num_cyclotron: () => 'Cyclotron radius γ m v/(q B), and the return to the start after τ = 2π m/(q B).',
      num_hyperbolic: () => 'Hyperbolic motion x(t) = √(1 + t²) − 1 from rest in E = 1.',
      num_drift: () => 'Mean velocity E/B over a turn in the drift frame, from rest.',
      num_wave: () => 'u_x = a sin τ, u_t − u_z = 1, and mean drift a²/(4 + a²).',
      num_orbit: () => 'The perihelion advance 2π(1/√(1 − κ²/L²) − 1) per turn of the relativistic Kepler orbit.'
    },
    frameNote: 'A note on signs. This page writes the gradient with components ∂ₐ in the basis eₐ, so the velocity is written the same way, with components (γ, −γv). That is bookkeeping: the force that comes out is the textbook force, and the check compares them term by term.',
    scope: 'What this is, and is not. The Lorentz force on a test charge in a given field is standard physics, and the geometric-algebra form F·u is Hestenes’. What is ours is the reading as moves on the simplex and the checks on the bit rule. The charge does not change the field here: its own field, radiation and any quantum behaviour are not in this picture, and not claimed.',
    frameLbl: 'Frame of the side view', frames: { lab: 'Lab frame', avg: 'Frame moving with the average' },
    a11yTop: 'Path of the charge seen from above', a11ySide: 'Path of the charge seen from the side', a11yChart: 'Speed of the charge against time'
  },
  it: {
    h: 'Una carica che si muove nei campi', eyebrow: 'DAL CAMPO AL MOTO',
    lede: 'Finora il campo stava fermo lì. Metti una carica e lasciala andare. La forza sulla carica è lo stesso tipo di mossa di ∇F = J: prendi un pezzo di F, aggiungi o togli una direzione. Premi play e muovi un cursore del campo mentre gira: il moto prosegue con il nuovo campo.',
    presetLbl: 'Scegli una situazione',
    presets: { circle: 'Solo B: un cerchio', hyper: 'Solo E: un limite di velocità', crossed: 'E e B incrociati: una deriva', spiral: 'E parallelo a B: una spirale', orbit: 'Una carica puntiforme: un’orbita', wave: 'Un’onda di luce: un otto' },
    worldTag: w => w === 2 ? 'in un piano: 2 dimensioni spaziali' : 'nello spazio: 3 dimensioni spaziali',
    what: {
      circle: 'B esce dalla pagina. La forza è sempre laterale rispetto alla velocità, quindi la velocità non cambia e la carica percorre un cerchio di raggio γ m v / (q B). Più veloce vuol dire un cerchio più grande, e un γ più grande lo ingrandisce ancora.',
      hyper: 'E spinge lungo le sue linee per sempre, eppure la velocità non raggiunge mai quella della luce: x(t) = (√(m² + (qEt)²) − m) / (qE) con m² = 1 + u_y². Guarda il moto laterale: nessuna forza agisce di lato, eppure rallenta, perché la velocità totale non può superare 1. Newton direbbe che la velocità cresce senza limite (il numero nella verifica).',
      crossed: 'E punta verso l’alto della pagina e B esce dalla pagina. La carica non segue E: in media deriva di lato a E/B volte la velocità della luce, qualunque siano carica e massa. Con E/B sopra 1 la deriva sparisce: esiste un sistema in cui B si annulla, e la carica scappa lungo E.',
      spiral: 'E e B puntano entrambi lungo z. Il boost lungo z (da E) e la rotazione nel piano (da B) non si disturbano, perché i due generatori commutano (verificato esattamente). Quindi la carica gira mentre accelera: una spirale. E·B ≠ 0 in ogni sistema.',
      orbit: 'Una carica puntiforme ferma attrae la carica di prova. Con Newton l’orbita è un’ellisse che si chiude. Con il limite di velocità no: l’ellisse ruota di 2π(1/√(1 − κ²/L²) − 1) a ogni giro, una rosetta. Con κ più grande la rotazione cresce; con κ negativo la carica viene respinta.',
      wave: 'Passa un’onda di luce piana E_x = B_y = a cos(t − z). La quantità u_t − u_z non può cambiare (verificato esattamente), quindi il moto laterale è esattamente u_x = a sin τ e la carica viene spinta lungo z, in media a a²/(4 + a²) della velocità della luce. Passa al sistema che si muove con quella media e disegna un otto (l’asse z è allungato quattro volte).'
    },
    play: 'Play', pause: 'Pausa', step: 'Passo', reset: 'Reset', speedLbl: 'Velocità dell’animazione',
    params: { B: 'campo magnetico B', E: 'campo elettrico E', rho: 'E / B', qm: 'carica ÷ massa, q/m', v0: 'velocità iniziale ↻', kappa: 'attrazione κ', a: 'forza dell’onda a' },
    ctlNote: 'Il cursore con ↻ fissa la partenza e comincia una nuova corsa (continua a girare se girava). Gli altri cambiano il campo o la carica e agiscono sul moto mentre gira; in pausa non cambiano nulla finché non premi play.',
    top: 'Visto dall’alto (x a destra, y in su)', side: 'Visto di lato (z a destra, x in su)', speedChart: 'Velocità nel tempo, come frazione della velocità della luce', c: 'c',
    legend: ['la carica e la sua velocità', 'il campo sulla carica: E (blu), B (arancione)', 'la forza (verde)'],
    read: { t: 'tempo t', tau: 'tempo proprio τ', gamma: 'γ = u_t', v: 'velocità v/c', u2: 'u·u − 1', i1: 'E² − B²', i2: 'E·B' },
    forceH: 'Da dove viene la forza',
    forceText: 'Ogni spigolo di F unisce due vertici. Manda la velocità a un’estremità sulla forza all’altra: la f in un vertice è la somma, sugli spigoli lì, di (il valore sullo spigolo) × (la velocità all’altra estremità). È la mossa “togli una direzione” di ∇F = J, con ∂ sostituito da u; si tiene solo la metà di contrazione, perché la forza è un vettore. Carica per E al vertice del tempo è il lavoro compiuto; B lì non compare mai.',
    rowsH: 'Le stesse cose come equazioni (q/m = 1)',
    f: { t: 'f_t', x: 'f_x', y: 'f_y', z: 'f_z' },
    chk: {
      circle: (m, f) => `Raggio dal percorso: ${m}. Dalla formula γ m v / (q B): ${f}.`, circleWait: 'Fai mezzo giro e il raggio viene misurato dal percorso.',
      hyper: (m, f, n, sp) => `Posizione x dalla corsa: ${m}. Da x(t) sopra: ${f}. Velocità ${sp} c; Newton direbbe ${n} c.`,
      drift: (m, f, k) => `Velocità media su ${k} giri interi nel sistema di deriva: ${m}. E/B: ${f}.`, driftWait: 'Completa un giro nel sistema di deriva e la velocità media viene misurata.',
      runaway: r => `E/B = ${r}: E è più forte di B. Esiste un sistema in cui B si annulla e la carica accelera per sempre: la velocità tende a c, non la raggiunge mai.`,
      spiral: (m, f) => `u_z dalla corsa: ${m}. Da γ₀ sinh(q E τ / m): ${f}.`,
      orbit: (m, f, k) => `Avanzamento del perielio a ogni giro: ${m}° misurato. Da 2π(1/√(1 − κ²/L²) − 1): ${f}°. (${k} perieli finora)`, orbitWait: (f, k) => `Aspetta due perieli (${k} finora). La formula dà ${f}° a ogni giro.`,
      repulsive: 'Repulsione: non c’è un’orbita da chiudere. La carica viene deviata una volta sola.', falls: r => `κ/L = ${r} ≥ 1: nessuna orbita stabile, la carica cade sul centro.`,
      wave: (c, m, f, k) => `u_t − u_z = ${c}, e resta così. Deriva media su ${k} cicli interi: ${m}. a²/(4 + a²): ${f}.`, waveWait: (c, f) => `u_t − u_z = ${c}, e resta così. Deriva media: completa un ciclo (formula a²/(4 + a²) = ${f}).`,
      changed: 'Hai cambiato il campo mentre girava. Le forme chiuse valgono per il campo con cui è partita la corsa, quindi sono nascoste; u·u = 1 vale ancora ed è mostrato sopra.'
    },
    exact: 'verificato esattamente', numeric: 'verificato numericamente',
    listH: 'Che cosa è verificato, e come',
    listNote: 'Numeri razionali e algebra esatta sulla regola dei bit per le prime nove righe (lo script è in fondo a questa scheda, sotto “Verificalo tu”); una corsa Runge–Kutta della stessa tabella contro la forma chiusa per le ultime cinque.',
    list: {
      force_is_grade1: r => `La forza su una carica è la parte di grado 1 del prodotto F u: coincide con la forza dei libri di testo in 2, 3 e 4 dimensioni spaziali (${r.trials} casi razionali casuali). L’altro segno no.`,
      force_is_contraction: r => `I suoi termini sono i termini di contrazione di ∇F = J: stessi spigoli, stessi bersagli, con ∂ sostituito da u e una regola fissa dei segni (${r.terms[2]}, ${r.terms[3]} e ${r.terms[4]} termini in 2, 3 e 4 dimensioni spaziali: due per spigolo).`,
      speed_limit: r => `u·f = 0, quindi u·u resta 1: la velocità può avvicinarsi a c e non raggiungerla mai. Un campo magnetico da solo non compie lavoro (${r.trials} casi).`,
      circle_and_hyperbola: r => `Il cerchio (solo B) e l’iperbole (solo E) risolvono esattamente l’equazione del moto: ${r.circle_points} e ${r.hyperbola_points} punti razionali delle loro parametrizzazioni, frequenza qB/m e rapidità qEτ/m.`,
      drift_frame: r => `Per E ⊥ B ed E < B una carica che si muove a E×B/B² non sente nessuna forza (${r.cases.length} casi esatti); si trova il boost che elimina E, e B′ = √(B² − E²).`,
      invariants: r => `E² − B² ed E·B non cambiano con boost e rotazioni (${r.checks} casi).`,
      parallel: () => 'Per E ∥ B i due generatori bivettoriali commutano: un boost lungo z per una rotazione nel piano, ed E·B ≠ 0.',
      point_charge: r => `Il campo di una carica puntiforme rispetta Gauss e Faraday lontano dalla carica (${r.points} punti); la forza su una carica di prova è centrale.`,
      light_wave: r => `E_x = B_y = f(t − z) risolve le equazioni nel vuoto (e B_y = −E_x è l’onda che va dall’altra parte); u_t − u_z non cambia mai (${r.u0_minus_uz_conserved} casi).`,
      num_cyclotron: () => 'Raggio di ciclotrone γ m v/(q B), e ritorno alla partenza dopo τ = 2π m/(q B).',
      num_hyperbolic: () => 'Moto iperbolico x(t) = √(1 + t²) − 1 da fermo in E = 1.',
      num_drift: () => 'Velocità media E/B su un giro nel sistema di deriva, da fermo.',
      num_wave: () => 'u_x = a sin τ, u_t − u_z = 1, e deriva media a²/(4 + a²).',
      num_orbit: () => 'L’avanzamento del perielio 2π(1/√(1 − κ²/L²) − 1) per giro dell’orbita kepleriana relativistica.'
    },
    frameNote: 'Una nota sui segni. Questa pagina scrive il gradiente con componenti ∂ₐ nella base eₐ, quindi la velocità è scritta allo stesso modo, con componenti (γ, −γv). È contabilità: la forza che ne esce è la forza dei libri di testo, e la verifica le confronta termine per termine.',
    scope: 'Che cosa è, e che cosa no. La forza di Lorentz su una carica di prova in un campo dato è fisica standard, e la forma F·u in algebra geometrica è di Hestenes. Nostra è la lettura come mosse sul simplesso e le verifiche sulla regola dei bit. Qui la carica non cambia il campo: il suo campo, la radiazione e ogni comportamento quantistico non sono in questa immagine, e non sono rivendicati.',
    frameLbl: 'Sistema della vista di lato', frames: { lab: 'Sistema del laboratorio', avg: 'Sistema che si muove con la media' },
    a11yTop: 'Percorso della carica visto dall’alto', a11ySide: 'Percorso della carica visto di lato', a11yChart: 'Velocità della carica nel tempo'
  }
};

const Mark = ({ ok }) => <span className={'cg-mark ' + (ok ? 'ok' : 'bad')} aria-label={ok ? 'true' : 'false'}><Tx>{ok ? '✓' : '✗'}</Tx></span>;
const Arrow = ({ x1, y1, x2, y2, c, w = 2 }) => {
  const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy); if (L < 1.5) return null; const ux = dx / L, uy = dy / L, hx = x2 - ux * 6, hy = y2 - uy * 6;
  return <g stroke={c} fill={c} strokeWidth={w}><line x1={x1} y1={y1} x2={hx} y2={hy} /><polygon stroke="none" points={`${x2},${y2} ${hx - uy * 3.5},${hy + ux * 3.5} ${hx + uy * 3.5},${hy - ux * 3.5}`} /></g>;
};
const ext = pts => pts.reduce((b, [x, y]) => [Math.min(b[0], x), Math.max(b[1], x), Math.min(b[2], y), Math.max(b[3], y)], [Infinity, -Infinity, Infinity, -Infinity]);

// the view of one panel: a = the horizontal world coordinate, b = the vertical one
function makeView(run, sp, a, b, key) {
  const cur = [a(run.s), b(run.s)];
  let cx, cy, half;
  if (sp.view === 'follow') { cx = cur[0]; cy = cur[1]; half = sp.ext; }
  else {
    const pts = run.trail.map(p => [a([0, p[0], p[1], p[2]]), b([0, p[0], p[1], p[2]])]).concat([cur]); const [x0, x1, y0, y1] = ext(pts);
    cx = (x0 + x1) / 2; cy = (y0 + y1) / 2; half = Math.max(sp.ext, 0.58 * Math.max(x1 - x0, y1 - y0) + 0.15);
    run[key] = Math.max(run[key] || 0, half); half = run[key];
  }
  const s = Math.min(W, H) / (2 * half);
  return { X: v => W / 2 + (v - cx) * s, Y: v => H / 2 - (v - cy) * s, s, cx, cy, half };
}
const trailPath = (run, va, vb, view) => run.trail.map((p, i) => (i ? 'L' : 'M') + view.X(va(p)).toFixed(1) + ' ' + view.Y(vb(p)).toFixed(1)).join('');

function Top({ run, sp, o, P, t }) {
  const A = s => s[1], B = s => s[2], view = makeView(run, sp, A, B, 'fitTop'), px = view.X(run.s[1]), py = view.Y(run.s[2]);
  const E = [o.F[0], o.F[1]], Bz = o.F[5], fo = [o.f[1], o.f[2]], u = [o.u[1], o.u[2]];
  const grid = !['circle', 'hyper', 'crossed', 'spiral'].includes(run.id) ? [] : [[60, 50], [180, 50], [300, 50], [60, 150], [180, 150], [300, 150], [60, 250], [180, 250], [300, 250]];
  const cen = run.id === 'orbit' ? [view.X(0), view.Y(0)] : null;
  const arr = (v, k = 1) => { const L = Math.hypot(v[0], v[1]); return L < 1e-9 ? [0, 0] : [v[0] / L * (12 + 26 * Math.tanh(L * k)), -v[1] / L * (12 + 26 * Math.tanh(L * k))]; };
  return <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={t.a11yTop} className="cg-top" style={{ background: 'rgba(120,130,170,.05)', borderRadius: 10 }}>
    {grid.map(([gx, gy], i) => <g key={i} opacity=".5">{Math.hypot(E[0], E[1]) > 1e-9 && <Arrow x1={gx} y1={gy} x2={gx + arr(E, .6)[0] * .8} y2={gy + arr(E, .6)[1] * .8} c={C.E} w={1.5} />}
      {Math.abs(Bz) > 1e-9 && <g stroke={C.B} fill="none" strokeWidth="1.4"><circle cx={gx + 22} cy={gy + 18} r="6" />{Bz > 0 ? <circle cx={gx + 22} cy={gy + 18} r="1.6" fill={C.B} /> : <path d={`M${gx + 18} ${gy + 14}l8 8M${gx + 26} ${gy + 14}l-8 8`} />}</g>}</g>)}
    {cen && <g><circle cx={cen[0]} cy={cen[1]} r="7" fill={P.kappa >= 0 ? C.R : C.E} /><text x={cen[0]} y={cen[1] + 3.5} fontSize="10" textAnchor="middle" fill="#0b1020">{P.kappa >= 0 ? '+' : '−'}</text></g>}
    <path d={trailPath(run, p => p[0], p => p[1], view)} fill="none" stroke={C.T} strokeWidth="1.6" opacity=".85" />
    <circle className="cg-dot" cx={px} cy={py} r="5" fill="#fff" stroke="#111" strokeWidth="1" />
    <Arrow x1={px} y1={py} x2={px + arr(u, 1.2)[0]} y2={py + arr(u, 1.2)[1]} c={C.V} w={1.6} />
    {Math.hypot(E[0], E[1]) > 1e-9 && <Arrow x1={px} y1={py} x2={px + arr(E, .8)[0] * .7} y2={py + arr(E, .8)[1] * .7} c={C.E} w={1.6} />}
    {Math.abs(Bz) > 1e-9 && <g stroke={C.B} fill="none" strokeWidth="1.4"><circle cx={px - 14} cy={py - 14} r="6" />{Bz > 0 ? <circle cx={px - 14} cy={py - 14} r="1.6" fill={C.B} /> : <path d={`M${px - 18} ${py - 18}l8 8M${px - 10} ${py - 18}l-8 8`} />}</g>}
    <Arrow x1={px} y1={py} x2={px + arr(fo, 1)[0]} y2={py + arr(fo, 1)[1]} c={C.F} w={2.2} />
    <text x="8" y="16" fontSize="11" fill="currentColor" opacity=".7">y ↑  x →</text>
  </svg>;
}

function Side({ run, sp, o, P, t, frame }) {
  const avg = frame === 'avg' && run.id === 'wave', a = Math.max(0.05, run.changed ? P.a : run.P0.a || P.a), vd = a * a / (4 + a * a);
  const sd = { ...sp, ext: sp.sideExt || sp.ext }, tt = run.s[0];
  const view = avg ? (() => { const sy = H / (2 * 1.15 * (a + 0.3)); return { X: v => W / 2 + v * sy * 4, Y: v => H / 2 - (v - a) * sy, s: sy, cx: 0 }; })() : makeView(run, sd, s => s[3], s => s[1], 'fitSide');
  const zOf = p => (avg ? p[2] - vd * p[3] : p[2]), pz = avg ? run.s[3] - vd * run.s[0] : run.s[3], px = view.X(pz), py = view.Y(run.s[1]);
  const stripes = []; if (run.id === 'wave' && !avg) { for (let i = 0; i < W; i += 4) { const z = view.cx + (i + 2 - W / 2) / view.s, v = Math.cos(tt - z), q = Math.abs(v); stripes.push(<rect key={i} x={i} y="0" width="4" height={H} fill={v > 0 ? C.E : C.R} opacity={(q * .22).toFixed(3)} />); } }
  const fo = [o.f[3], o.f[1]], u = [o.u[3] - (avg ? vd * o.u[0] : 0), o.u[1]]; const arr = (v, k = 1) => { const L = Math.hypot(v[0], v[1]); return L < 1e-9 ? [0, 0] : [v[0] / L * (12 + 26 * Math.tanh(L * k)), -v[1] / L * (12 + 26 * Math.tanh(L * k))]; };
  return <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={t.a11ySide} className="cg-side" style={{ background: 'rgba(120,130,170,.05)', borderRadius: 10 }}>
    {stripes}
    <path d={run.trail.map((p, i) => (i ? 'L' : 'M') + view.X(zOf(p)).toFixed(1) + ' ' + view.Y(p[0]).toFixed(1)).join('')} fill="none" stroke={C.T} strokeWidth="1.6" opacity=".85" />
    <circle className="cg-sdot" cx={px} cy={py} r="5" fill="#fff" stroke="#111" strokeWidth="1" />
    <Arrow x1={px} y1={py} x2={px + arr(u, 1.2)[0]} y2={py + arr(u, 1.2)[1]} c={C.V} w={1.6} />
    {!avg && <Arrow x1={px} y1={py} x2={px + arr(fo)[0]} y2={py + arr(fo)[1]} c={C.F} w={2.2} />}
    {run.id === 'spiral' && <g><Arrow x1={W - 70} y1={26} x2={W - 24} y2={26} c={C.E} w={2} /><text x={W - 70} y="16" fontSize="10" fill={C.E}>E</text><Arrow x1={W - 70} y1={52} x2={W - 24} y2={52} c={C.B} w={2} /><text x={W - 70} y="46" fontSize="10" fill={C.B}>B</text></g>}
    <text x="8" y="16" fontSize="11" fill="currentColor" opacity=".7">{avg ? "x ↑  z′ → (×4)" : 'x ↑  z →'}</text>
  </svg>;
}

function Chart({ hist, o, t }) {
  const Tm = Math.max(10, hist.length ? hist[hist.length - 1][0] : 0), X = v => 30 + v / Tm * (W - 44), Y = v => H - 30 - v * (H - 60);
  return <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label={t.a11yChart} className="cg-chart" style={{ background: 'rgba(120,130,170,.05)', borderRadius: 10 }}>
    <line x1="30" y1={Y(1)} x2={W - 14} y2={Y(1)} stroke={C.R} strokeDasharray="5 4" /><text x="34" y={Y(1) - 4} fontSize="11" fill={C.R}>{t.c}</text>
    <line x1="30" y1={Y(0)} x2={W - 14} y2={Y(0)} stroke="currentColor" opacity=".4" /><line x1="30" y1={Y(0)} x2="30" y2={Y(1)} stroke="currentColor" opacity=".4" />
    <text x="6" y={Y(0) + 4} fontSize="10" fill="currentColor">0</text><text x="6" y={Y(1) + 4} fontSize="10" fill="currentColor">1</text>
    <path d={hist.map(([a, b], i) => (i ? 'L' : 'M') + X(a).toFixed(1) + ' ' + Y(b).toFixed(1)).join('')} fill="none" stroke={C.F} strokeWidth="1.8" />
    <text x={W / 2} y={H - 8} fontSize="10" textAnchor="middle" fill="currentColor" opacity=".7">t</text>
  </svg>;
}

// F as the edges of a simplex: the value on each edge, the velocity at each vertex, the force at each vertex
function Simplex({ world, o }) {
  const n = world + 1, pos = world === 2 ? [[180, 62], [60, 215], [300, 215]] : [[180, 62], [50, 220], [310, 220], [180, 150]];
  const edge = (a, b) => a === 0 ? `E_${AXN[b]}` : (a === 1 && b === 2) ? 'B_z' : (a === 2 && b === 3) ? 'B_x' : 'B_y';
  const idx = nm => ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z'].indexOf(nm), edges = [];
  for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) { const nm = edge(a, b); edges.push({ a, b, nm, v: o.F[idx(nm)] }); }
  const mx = Math.max(1e-9, ...edges.map(e => Math.abs(e.v)));
  return <svg viewBox="0 0 360 260" role="img" aria-label="F as the edges of a simplex" className="cg-simplex" style={{ background: 'rgba(120,130,170,.05)', borderRadius: 10 }}>
    {edges.map(e => { const [x1, y1] = pos[e.a], [x2, y2] = pos[e.b], col = e.nm[0] === 'E' ? C.E : C.B; return <g key={e.nm}><line x1={x1} y1={y1} x2={x2} y2={y2} stroke={col} strokeWidth={1 + 6 * Math.abs(e.v) / mx} opacity={Math.abs(e.v) < 1e-9 ? .25 : .85} />
      <text x={(x1 + x2) / 2 + (e.a === 1 && e.b === 2 ? 0 : 6)} y={(y1 + y2) / 2 - 5} fontSize="10.5" fill={col} textAnchor="middle" className="cg-edge"><tspan>{e.nm.replace('_', '')}</tspan><tspan> = {f2(e.v)}</tspan></text></g>; })}
    {pos.map(([x, y], a) => <g key={a} className="cg-vertex"><circle cx={x} cy={y} r="14" fill="#1b2236" stroke="#8b93a8" /><text x={x} y={y + 4} fontSize="12" textAnchor="middle" fill="#e5e7eb">{AXN[a]}</text>
      <text x={x} y={y + (a === 0 ? -24 : 29)} fontSize="10.5" textAnchor="middle" fill={C.V}>u{AXN[a]} = {f2(o.u[a])}</text><text x={x} y={y + (a === 0 ? -37 : 41)} fontSize="10.5" textAnchor="middle" fill={C.F}>f{AXN[a]} = {f2(o.f[a])}</text></g>)}
  </svg>;
}

const rowFormula = (world, out) => {
  const parts = TERMS[world].filter(x => x.out === out).sort((p, q) => p.in - q.in).map(x => ({ s: x.sign, t: `${x.field} u_${AXN[x.in]}` }));
  return parts.map((p, i) => (i ? (p.s > 0 ? ' + ' : ' − ') : (p.s > 0 ? '' : '−')) + p.t).join('');
};

export default function ChargesWidget({ lang = 'en', profile = 'Young Learner' }) {
  const t = T[lang] || T.en, expert = profile !== 'Young Learner';
  const [id, setId] = useState('circle'), [P, setP] = useState(defaults('circle')), [play, setPlay] = useState(false), [speed, setSpeed] = useState(1), [frame, setFrame] = useState('lab'), [, setN] = useState(0);
  const run = useRef(null), Pref = useRef(P), hist = useRef([]), playRef = useRef(false), speedRef = useRef(1), idRef = useRef('circle');
  if (!run.current) run.current = initRun('circle', P);
  Pref.current = P; playRef.current = play; speedRef.current = speed; idRef.current = id;
  const sp = SPEC[id], r = run.current;
  const rd = () => { const o = readout(run.current, Pref.current); const h = hist.current, s = run.current.s; if (!h.length || s[0] - h[h.length - 1][0] > 0.05) { h.push([s[0], o.speed]); if (h.length > 1500) h.splice(0, 300); } return o; };
  const fresh = (nid, np) => { run.current = initRun(nid, np); hist.current = []; };
  const adv = dt => { advance(run.current, Pref.current, dt); setN(x => x + 1); };
  // the ticker: simulated time per second is fixed for each situation, so a stronger field really does go round faster
  React.useEffect(() => { if (!play) return undefined; const k = setInterval(() => adv(SPEC[idRef.current].rate * speedRef.current * 0.033), 33); return () => clearInterval(k); }, [play]);
  const pickPreset = pid => { const np = defaults(pid); setId(pid); setP(np); Pref.current = np; idRef.current = pid; fresh(pid, np); setN(x => x + 1); };
  const onParam = (q, v) => {
    const np = { ...Pref.current, [q.id]: v }; setP(np); Pref.current = np;
    if (q.live) { const rr = run.current; if (rr.steps === 0) rr.P0 = { ...np }; else rr.changed = true; } else fresh(idRef.current, np);
    setN(x => x + 1);
  };
  const o = rd(), world = sp.world, side = id === 'spiral' || id === 'wave', c = o.check;
  const chk = (() => {
    if (r.changed) return { text: t.chk.changed, ok: null };
    if (!c) return null;
    const k = c.kind;
    if (k === 'circle') return c.measured === null ? { text: t.chk.circleWait, ok: null } : { text: t.chk.circle(f3(c.measured), f3(c.formula)), ok: Math.abs(c.measured - c.formula) < 2e-3 * Math.max(1, c.formula) };
    if (k === 'hyper') return { text: t.chk.hyper(f3(c.measured), f3(c.formula), f2(c.newton), f3(c.speed)), ok: c.diff < 1e-3 * Math.max(1, Math.abs(c.formula)) };
    if (k === 'drift') return c.measured === null ? { text: t.chk.driftWait, ok: null } : { text: t.chk.drift(f3(c.measured), f3(c.formula), c.turns), ok: Math.abs(c.measured - c.formula) < 2e-3 };
    if (k === 'runaway') return { text: t.chk.runaway(f2(c.rho)), ok: null };
    if (k === 'spiral') return { text: t.chk.spiral(f3(c.measured), f3(c.formula)), ok: c.diff < 1e-3 * Math.max(1, Math.abs(c.formula)) };
    if (k === 'orbit') return c.measured === null ? { text: t.chk.orbitWait(f2(c.formula), c.perihelia), ok: null } : { text: t.chk.orbit(f2(c.measured), f2(c.formula), c.perihelia), ok: Math.abs(c.measured - c.formula) < 0.05 };
    if (k === 'repulsive') return { text: t.chk.repulsive, ok: null };
    if (k === 'falls') return { text: t.chk.falls(f2(c.ratio)), ok: null };
    if (k === 'wave') return c.measured === null ? { text: t.chk.waveWait(f3(c.conserved), f3(c.formula)), ok: null } : { text: t.chk.wave(f3(c.conserved), f3(c.measured), f3(c.formula), c.turns), ok: Math.abs(c.measured - c.formula) < 2e-3 && Math.abs(c.conserved - 1) < 1e-6 };
    return null;
  })();
  const rows = world === 2 ? [0, 1, 2] : [0, 1, 2, 3];
  return <section className="cg" id="mx-charges" aria-labelledby="cg-h">
    <style>{STYLE}</style>
    <p className="eyebrow"><Tx>{t.eyebrow}</Tx></p><h3 id="cg-h"><Tx>{t.h}</Tx></h3><p className="cg-lede"><Tx>{t.lede}</Tx></p>
    <div className="cg-chips" role="group" aria-label={t.presetLbl}>{PRESET_IDS.map(p => <button key={p} className={'cg-chip' + (p === id ? ' on' : '')} data-preset={p} aria-pressed={p === id} onClick={() => pickPreset(p)}><Tx>{t.presets[p]}</Tx></button>)}</div>
    <p className="cg-what"><span className="cg-world"><Tx>{t.worldTag(world)}</Tx></span> <Tx>{t.what[id]}</Tx></p>
    <div className="cg-bar"><button className="cg-btn cg-play" aria-pressed={play} onClick={() => setPlay(p => !p)}><Tx>{play ? t.pause : t.play}</Tx></button>
      <button className="cg-btn cg-step" onClick={() => adv(sp.rate * 0.25)}><Tx>{t.step}</Tx></button>
      <button className="cg-btn cg-reset" onClick={() => { fresh(id, P); setPlay(false); setN(x => x + 1); }}><Tx>{t.reset}</Tx></button>
      <span className="cg-chips" role="group" aria-label={t.speedLbl}>{[0.5, 1, 2].map(k => <button key={k} className={'cg-chip' + (speed === k ? ' on' : '')} aria-pressed={speed === k} onClick={() => setSpeed(k)}>×<Tx>{k}</Tx></button>)}</span>
      <span className="cg-mono cg-time">t = <Tx>{f2(o.t)}</Tx></span></div>
    <div className="cg-sliders">{sp.params.map(q => <label key={q.id} className="cg-sl"><span><Tx>{t.params[q.id]}</Tx></span>
      <input className={'cg-p cg-p-' + q.id} type="range" min={q.min} max={q.max} step={q.step} value={P[q.id]} onChange={e => onParam(q, parseFloat(e.target.value))} aria-label={t.params[q.id]} /><output className="cg-mono"><Tx>{f2(P[q.id])}</Tx></output></label>)}</div>
    <p className="cg-note"><Tx>{t.ctlNote}</Tx></p>
    <div className="cg-grid">
      <div className="cg-card"><h4><Tx>{t.top}</Tx></h4><Top run={r} sp={sp} o={o} P={P} t={t} /></div>
      <div className="cg-card"><h4><Tx>{side ? t.side : t.speedChart}</Tx></h4>{id === 'wave' && <div className="cg-chips cg-frames" role="group" aria-label={t.frameLbl}>{['lab', 'avg'].map(k => <button key={k} className={'cg-chip' + (frame === k ? ' on' : '')} data-frame={k} aria-pressed={frame === k} onClick={() => setFrame(k)}><Tx>{t.frames[k]}</Tx></button>)}</div>}{side ? <Side run={r} sp={sp} o={o} P={P} t={t} frame={frame} /> : <Chart hist={hist.current} o={o} t={t} />}</div>
    </div>
    <p className="cg-note cg-legend"><span style={{ color: C.V }}>● <Tx>{t.legend[0]}</Tx></span> · <span style={{ color: C.E }}>● <Tx>{t.legend[1]}</Tx></span> · <span style={{ color: C.F }}>● <Tx>{t.legend[2]}</Tx></span></p>
    <div className="cg-read">
      <span><b><Tx>{t.read.tau}</Tx></b> <Tx>{f2(o.tau)}</Tx></span><span><b><Tx>{t.read.gamma}</Tx></b> <span className="cg-gamma"><Tx>{f2(o.gamma)}</Tx></span></span>
      <span className="cg-speed"><b><Tx>{t.read.v}</Tx></b> <Tx>{f3(o.speed)}</Tx></span><span className="cg-u2"><b><Tx>{t.read.u2}</Tx></b> <Tx>{Math.abs(o.u2) < 1e-9 ? '0' : o.u2.toExponential(1).replace('-', '−')}</Tx></span>
      <span><b><Tx>{t.read.i1}</Tx></b> <Tx>{f2(o.I1)}</Tx></span><span><b><Tx>{t.read.i2}</Tx></b> <Tx>{f2(o.I2)}</Tx></span></div>
    <div className="cg-gauge" aria-hidden="true"><div style={{ width: (Math.min(1, o.speed) * 100).toFixed(2) + '%' }} /></div>
    {chk && <p className={'cg-check' + (chk.ok === false ? ' bad' : '')}>{chk.ok !== null && <Mark ok={chk.ok} />} <Tx>{chk.text}</Tx></p>}
    <div className="cg-grid">
      <div className="cg-card"><h4><Tx>{t.forceH}</Tx></h4><Simplex world={world} o={o} /><p className="cg-note"><Tx>{t.forceText}</Tx></p></div>
      <div className="cg-card"><h4><Tx>{t.rowsH}</Tx></h4><table className="cg-mono cg-rows"><tbody>{rows.map(a => <tr key={a}><td><Tx>{t.f[AXN[a]]}</Tx></td><td>=</td><td><Tx>{rowFormula(world, a)}</Tx></td><td className="cg-num">= <Tx>{f2(o.f[a])}</Tx></td></tr>)}</tbody></table>
        <p className="cg-note"><Tx>{t.frameNote}</Tx></p></div>
    </div>
    {expert && <div className="cg-card cg-list"><h4><Tx>{t.listH}</Tx></h4><p className="cg-note"><Tx>{t.listNote}</Tx></p>
      <ul>{CH.rows.map(rw => <li key={rw.id} data-row={rw.id}><span className={'cg-kind ' + rw.kind}><Tx>{t[rw.kind]}</Tx></span> <Tx>{t.list[rw.id](rw)}</Tx></li>)}</ul></div>}
    <p className="cg-note cg-scope"><Tx>{t.scope}</Tx></p>
  </section>;
}

const STYLE = `
.cg{margin:26px 0}.cg h3{margin:.3rem 0 .5rem}.cg .cg-lede{margin:.3rem 0 .8rem}
.cg .cg-chips{display:inline-flex;flex-wrap:wrap;gap:.35rem;align-items:center}
.cg button.cg-chip,.cg button.cg-btn{font:inherit;font-size:.82rem;border:1px solid rgba(160,170,200,.4);background:transparent;color:inherit;border-radius:99px;padding:.22rem .75rem;cursor:pointer}
.cg button.cg-chip.on,.cg button.cg-btn[aria-pressed=true]{background:#4cc9f0;color:#06222b;border-color:#4cc9f0}
.cg .cg-what{font-size:.9rem;margin:.7rem 0}.cg .cg-world{display:inline-block;font-size:.72rem;border:1px solid rgba(160,170,200,.45);border-radius:6px;padding:0 .4rem;margin-right:.4rem;opacity:.85}
.cg .cg-bar{display:flex;flex-wrap:wrap;gap:.5rem;align-items:center;margin:.5rem 0}
.cg .cg-sliders{display:grid;grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:.35rem .9rem;margin:.4rem 0}
.cg label.cg-sl{display:grid;grid-template-columns:1fr auto;gap:.1rem .5rem;font-size:.8rem}.cg label.cg-sl input{grid-column:1/3;width:100%}
.cg .cg-mono{font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.78rem}
.cg .cg-note{font-size:.76rem;opacity:.78;margin:.35rem 0}
.cg .cg-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.8rem;margin:.6rem 0}
.cg .cg-card{border:1px solid rgba(160,170,200,.28);border-radius:14px;padding:.8rem .9rem;background:rgba(120,130,170,.07)}.cg .cg-card h4{margin:.1rem 0 .4rem;font-size:.86rem}
.cg svg{width:100%;height:auto;display:block}
.cg .cg-read{display:flex;flex-wrap:wrap;gap:.3rem 1.1rem;font-size:.82rem;margin:.5rem 0 .3rem}.cg .cg-read b{font-weight:600;margin-right:.25rem;opacity:.85}
.cg .cg-gauge{height:6px;border-radius:3px;background:rgba(160,170,200,.25);overflow:hidden;margin:.2rem 0 .6rem}.cg .cg-gauge div{height:100%;background:linear-gradient(90deg,#4fd18b,#ff5d8f)}
.cg .cg-check{font-size:.84rem;margin:.4rem 0;padding:.45rem .7rem;border-left:3px solid #4fd18b;background:rgba(79,209,139,.08);border-radius:0 8px 8px 0}.cg .cg-check.bad{border-color:#ff5d8f;background:rgba(255,93,143,.1)}
.cg .cg-mark.ok{color:#4fd18b;font-weight:700}.cg .cg-mark.bad{color:#ff5d8f;font-weight:700}
.cg table.cg-rows{border-collapse:collapse;width:100%}.cg .cg-rows td{padding:2px 6px}.cg .cg-rows td.cg-num{text-align:right;white-space:nowrap}
.cg .cg-list ul{margin:.3rem 0;padding-left:1.1rem;font-size:.82rem}.cg .cg-list li{margin:.3rem 0}
.cg .cg-kind{display:inline-block;font-size:.68rem;border-radius:5px;padding:0 .35rem;margin-right:.3rem;border:1px solid}.cg .cg-kind.exact{color:#4fd18b}.cg .cg-kind.numeric{color:#ffa06f}
@media(max-width:760px){.cg .cg-grid{grid-template-columns:1fr}}`;
