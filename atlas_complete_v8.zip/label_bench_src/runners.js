// ---------------------------------------------------------------- the page's runners (everything above is the real source of pgaEngine.js and benchKernels.js)
// This part is written for the page. It times exactly the lambdas that runBench times (VARIANTS and CTX_BUILD are generated from benchKernels.js by build_label_bench.mjs),
// with the same timeIt, and adds the scenarios that runBench does not have (the dense product of productKernels.js, many bodies, cold start, allocation). It runs unchanged in a Web Worker and on the main thread.
const nowMs = () => performance.now();
let SINK2 = 0;
const T_ = (fn, minMs, reps) => { const r = timeIt(fn, nowMs, minMs, reps); return { med: r.med * 1e6, min: r.min * 1e6, max: r.max * 1e6, iters: r.iters }; };       // ms -> ns, as in runBench

/*__GENERATED__*/

const KERNEL_SCENARIOS = {
  vertices: ['direct', 'frame', 'matrix', 'mirror', 'doubling', 'matrixGiven'],
  contact: ['scan', 'bits', 'scanBuilt', 'bitsBuilt'],
  outline: ['hull', 'zono', 'hullBuilt', 'zonoBuilt'],
};
const BODY_VARIANTS = ['buildDirect', 'buildFrame', 'scanGiven', 'bitsGiven', 'scanBuilt', 'bitsBuilt', 'e2eNaive'];
const ALLOC_SIZES = [8, 16, 32, 64];
const WARM_TARGETS = ['direct', 'frame', 'scan', 'bits', 'hull', 'zono'];
const WARM_NEED = { direct: [], frame: [], scan: ['fr', 'V'], bits: ['fr'], hull: ['fr', 'V', 'P'], zono: ['fr', 'g'] };       // what each target needs before its first call (built before the clock starts)
for (const k of Object.values(KERNEL_SCENARIOS).flat()) if (!VARIANTS[k]) throw new Error('benchKernels.js has no variant ' + k);
for (const k of WARM_TARGETS) if (!VARIANTS[k]) throw new Error('benchKernels.js has no variant ' + k);

const variantsFor = (scn, n) => KERNEL_SCENARIOS[scn].filter(k => !(VARIANTS[k].min2 && n < 2));
function makeCtx(n, need) {
  const { A, s, M, normals } = setup(n), ctx = { n, A, s, M, normals };
  for (const k of CTX_ORDER) if (!need || need.includes(k)) ctx[k] = CTX_BUILD[k](ctx);
  return ctx;
}

// the same check as runBench makes, plus two numbers the page shows (and the test compares with node): the sum of the 2^n vertex coordinates and the worst |direct - frame|
function checkDetail(n) {
  const d = { n, ok: checkAll(n), vertices: 1 << n };
  if (n <= 8) {
    const { A, s, M } = setup(n), fr = frame(A, M, s), D = verticesDirect(A, M, s), F = verticesFrame(A, M, s, fr);
    let sum = 0, err = 0; for (let v = 0; v < D.length; v++) for (let k = 0; k < n; k++) { sum += D[v][k]; err = Math.max(err, Math.abs(D[v][k] - F[v][k])); }
    d.sum = sum; d.maxErr = err;
  }
  return d;
}

// the smallest observable step of performance.now(), in ms (null: no tick within 100 ms)
function timerStep() {
  const deltas = []; let last = nowMs(), seen = 0, t; const stop = last + 100;
  while ((t = nowMs()) < stop && deltas.length < 30) if (t !== last) { if (seen++ > 0) deltas.push(t - last); last = t; }
  return deltas.length ? Math.min(...deltas) : null;
}

// ---------------------------------------------------------------- the jobs. Each is a generator: it yields after every timed unit, so the main thread can chunk it and a Stop can fall between two units.
function* checkJob(scn, ns, emit) {
  for (const n of ns) {
    emit({ type: 'status', label: 'correctness check, n = ' + n });
    const d = checkDetail(n); emit({ type: 'check', scenario: scn, detail: d }); emit({ type: 'unit' });
    if (!d.ok) throw new Error('the variants disagree at n = ' + n + ': correctness check failed, nothing was timed');
    yield;
  }
}

function* kernelJob(scn, cfg, emit) {
  yield* checkJob(scn, cfg.ns, emit);
  for (const n of cfg.ns) {
    const ctx = makeCtx(n);
    for (const name of variantsFor(scn, n)) {
      emit({ type: 'status', scenario: scn, label: scn + ', n = ' + n + ': ' + name });
      const st = T_(VARIANTS[name].mk(ctx), cfg.minMs, cfg.reps);
      emit({ type: 'cell', scenario: scn, key: n, variant: name, stats: st }); emit({ type: 'unit' });
      yield;
    }
  }
}

function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

// a scene of B bodies, each with its own random motor (a translation and a rotation in every coordinate plane) and its own edge lengths, and one plane: all drawn from the seeded generator
function makeScene(n, B, seed) {
  const rnd = mulberry32(seed), A = alg(n), M = new Array(B), S = new Array(B), pairs = [];
  for (let i = 1; i <= n; i++) for (let j = i + 1; j <= n; j++) pairs.push([i, j]);
  for (let b = 0; b < B; b++) {
    const t = Array.from({ length: n }, () => (rnd() - 0.5) * 20), planes = pairs.map(([i, j]) => [i, j, rnd() * 2 * Math.PI]);
    M[b] = A.motor(t, planes); S[b] = Array.from({ length: n }, () => 0.5 + 1.5 * rnd());
  }
  let nu = Array.from({ length: n }, () => rnd() - 0.5); const L = Math.hypot(...nu); nu = nu.map(x => x / L);
  return { A, M, S, nu, d: (rnd() - 0.5) * 10 };
}

function* bodiesJob(cfg, emit) {
  const { B, n, seed } = cfg.bodies;
  yield* checkJob('bodies', [n], emit);
  emit({ type: 'status', scenario: 'bodies', label: 'bodies: building the scene (' + B + ' motors)' });
  const { A, M, S, nu, d } = makeScene(n, B, seed), last = (1 << n) - 1, FR = new Array(B), V = new Array(B);
  for (let b = 0; b < B; b++) { FR[b] = frame(A, M[b], S[b]); V[b] = verticesFrame(A, M[b], S[b], FR[b]); }
  // the answers of the variants must agree on every body of the scene, not only on the cube of the check above
  let maxErr = 0, labelBad = 0, ties = 0;
  for (let b = 0; b < B; b++) {
    const D = verticesDirect(A, M[b], S[b]);
    for (let v = 0; v <= last; v++) for (let k = 0; k < n; k++) maxErr = Math.max(maxErr, Math.abs(D[v][k] - V[b][v][k]) / Math.max(1, Math.abs(D[v][k])));
    const ls = deepestScan(V[b], nu, d), lb = deepestBits(FR[b], nu);
    if (ls !== lb) { const dep = l => { let s = d; for (let k = 0; k < n; k++) s += nu[k] * V[b][l][k]; return s; }; if (Math.abs(dep(ls) - dep(lb)) <= 1e-9 * Math.max(1, Math.abs(dep(ls)))) ties++; else labelBad++; }
  }
  emit({ type: 'sceneCheck', maxErr, labelBad, ties, B, n });
  if (maxErr > 1e-9 || labelBad) throw new Error('the variants disagree on the scene (max relative error ' + maxErr + ', ' + labelBad + ' different deepest vertices): nothing was timed');
  emit({ type: 'unit' }); yield;
  const sum = f => () => { let a = 0; for (let b = 0; b < B; b++) a += f(b); return a; };
  const fns = {
    buildDirect: sum(b => verticesDirect(A, M[b], S[b])[last][0]),
    buildFrame: sum(b => verticesFrame(A, M[b], S[b])[last][0]),
    scanGiven: sum(b => deepestScan(V[b], nu, d)),
    bitsGiven: sum(b => deepestBits(FR[b], nu)),
    scanBuilt: sum(b => deepestScan(verticesFrame(A, M[b], S[b]), nu, d)),
    bitsBuilt: sum(b => deepestBits(frame(A, M[b], S[b]), nu)),
    e2eNaive: sum(b => deepestScan(verticesDirect(A, M[b], S[b]), nu, d)),
  };
  for (const name of BODY_VARIANTS) {
    emit({ type: 'status', scenario: 'bodies', label: 'bodies (B = ' + B + ', n = ' + n + '): ' + name });
    const st = T_(fns[name], cfg.minMs, cfg.reps);
    emit({ type: 'cell', scenario: 'bodies', key: 'scene', variant: name, stats: st }); emit({ type: 'unit' });
    yield;
  }
}

// allocation: the engine allocates its multivectors as plain arrays (z in alg); a Float64Array of 16 or more doubles was measured to cost far more in node 22. Here it is measured in whatever runs this page.
// The three product functions are written out separately so that each one only ever sees one kind of array.
function mulPlain(SG, N, EV, a, b) { const out = new Array(N).fill(0); for (let p = 0; p < EV.length; p++) { const i = EV[p], ai = a[i]; if (ai === 0) continue; const row = i * N; for (let q = 0; q < EV.length; q++) { const j = EV[q], s = SG[row + j]; if (s !== 0) out[i ^ j] += s * ai * b[j]; } } return out; }
function mulF64(SG, N, EV, a, b) { const out = new Float64Array(N); for (let p = 0; p < EV.length; p++) { const i = EV[p], ai = a[i]; if (ai === 0) continue; const row = i * N; for (let q = 0; q < EV.length; q++) { const j = EV[q], s = SG[row + j]; if (s !== 0) out[i ^ j] += s * ai * b[j]; } } return out; }
function mulF64r(SG, N, EV, a, b, out) { out.fill(0); for (let p = 0; p < EV.length; p++) { const i = EV[p], ai = a[i]; if (ai === 0) continue; const row = i * N; for (let q = 0; q < EV.length; q++) { const j = EV[q], s = SG[row + j]; if (s !== 0) out[i ^ j] += s * ai * b[j]; } } return out; }

function* allocJob(cfg, emit) {
  // the check: the three product functions agree with the engine's own product on a sandwich-like expression M X M~ of even multivectors (n = 3, 16 doubles)
  const A = alg(3), N = A.N, SG = A.SG, EV = A.EVEN, M = A.motor([0.3, -0.2, 0.5], [[1, 2, 0.7], [2, 3, 0.4]]), X = A.motor([-0.4, 0.1, 0.2], [[1, 3, 0.9]]), Mr = A.rev(M);
  const ref = A.mul(A.mul(M, X, EV, EV), Mr, EV, EV), Mf = Float64Array.from(M), Xf = Float64Array.from(X), Mrf = Float64Array.from(Mr), T1 = new Float64Array(N), T2 = new Float64Array(N);
  const outs = [mulPlain(SG, N, EV, mulPlain(SG, N, EV, M, X), Mr), mulF64(SG, N, EV, mulF64(SG, N, EV, Mf, Xf), Mrf), mulF64r(SG, N, EV, mulF64r(SG, N, EV, Mf, Xf, T1), Mrf, T2)];
  let err = 0; for (const o of outs) for (let i = 0; i < N; i++) err = Math.max(err, Math.abs(o[i] - ref[i]));
  const ok = err <= 1e-12; emit({ type: 'check', scenario: 'alloc', detail: { n: 3, ok, maxErr: err, vertices: 0 } }); emit({ type: 'unit' });
  if (!ok) throw new Error('the three product functions disagree (max difference ' + err + '): nothing was timed');
  yield;
  const ring = new Array(64);
  for (const k of ALLOC_SIZES) {
    const fp = i => { const a = new Array(k).fill(0); a[i & 7] = 1; ring[i & 63] = a; return a[i & 7]; };
    const ff = i => { const a = new Float64Array(k); a[i & 7] = 1; ring[i & 63] = a; return a[i & 7]; };
    for (const [name, fn] of [['plain', fp], ['f64', ff]]) {
      emit({ type: 'status', scenario: 'alloc', label: 'allocation of ' + k + ' doubles: ' + name });
      emit({ type: 'cell', scenario: 'alloc', key: 'a' + k, meta: { doubles: k }, variant: name, stats: T_(fn, cfg.minMs, cfg.reps) }); emit({ type: 'unit' }); yield;
    }
  }
  const loops = { plain: () => { const o = mulPlain(SG, N, EV, mulPlain(SG, N, EV, M, X), Mr); return o[0] + o[3]; }, f64: () => { const o = mulF64(SG, N, EV, mulF64(SG, N, EV, Mf, Xf), Mrf); return o[0] + o[3]; },
    f64reuse: () => { const o = mulF64r(SG, N, EV, mulF64r(SG, N, EV, Mf, Xf, T1), Mrf, T2); return o[0] + o[3]; } };
  for (const name of ['plain', 'f64', 'f64reuse']) {
    emit({ type: 'status', scenario: 'alloc', label: 'sandwich-like loop: ' + name });
    emit({ type: 'cell', scenario: 'alloc', key: 'loop', meta: { doubles: 16 }, variant: name, stats: T_(loops[name], cfg.minMs, cfg.reps) }); emit({ type: 'unit' }); yield;
  }
}

// cold start: ONE target per job, and the page starts a fresh worker for every job (in the main-thread fallback the code is not cold; the page says so).
// The set-up (algebra tables, motor, the inputs the target needs) is done before the clock starts. Then: call 1 alone, calls 2-10, 11-100, 101-1000, each block timed as a block.
function* warmJob(job, cfg, emit) {
  const { target, rep, n } = job;
  emit({ type: 'status', scenario: 'warm', label: 'cold start of ' + target + ', n = ' + n + ', run ' + rep });
  const t0 = nowMs(), ctx = makeCtx(n, WARM_NEED[target]), setupMs = nowMs() - t0, fn = VARIANTS[target].mk(ctx);
  let a = nowMs(); SINK2 += fn(0); const call1 = nowMs() - a;
  const block = (from, to) => { const s = nowMs(); for (let i = from; i < to; i++) SINK2 += fn(i); return nowMs() - s; };
  const t2_10 = block(1, 10), t11_100 = block(10, 100), t101_1000 = block(100, 1000);
  emit({ type: 'cold', target, rep, n, setupMs, call1, t2_10, t11_100, t101_1000 });
  if (job.steady) { emit({ type: 'status', scenario: 'warm', label: 'steady state of ' + target }); emit({ type: 'steady', target, n, stats: T_(fn, cfg.minMs, cfg.reps) }); }
  emit({ type: 'unit' });
  yield;
}

// the dense product of two multivectors of Cl(k,k), n = 2k: the bit rule against the matrix route (productKernels.js). The check compares exact integers; the set-up (sign table, representation tables, the inputs as matrices) is done before the clock starts.
const PRODUCT_ORDER = ['bitRule', 'signTable', 'matmulGiven', 'matrixRoute', 'period8'];
const productVariantsFor = n => PRODUCT_ORDER.filter(v => v === 'signTable' ? productHasTable(n) : v === 'period8' ? productPeriodN(n) != null : true);
const productNsFor = cfg => PRODUCT_NS.filter(n => n <= cfg.productMax);
function* productJob(cfg, emit) {
  const ns = productNsFor(cfg);
  for (const n of ns) {
    emit({ type: 'status', scenario: 'product', label: 'product: correctness check, n = ' + n });
    const d = productCheck(n); emit({ type: 'check', scenario: 'product', detail: d }); emit({ type: 'unit' });
    if (!d.ok) throw new Error('the product variants disagree at n = ' + n + ': correctness check failed, nothing was timed');
    yield;
  }
  for (const n of ns) {
    emit({ type: 'status', scenario: 'product', label: 'product, n = ' + n + ': building the tables' });
    const fns = productVariants(productSetup(n));
    for (const name of productVariantsFor(n)) {
      emit({ type: 'status', scenario: 'product', label: 'product, n = ' + n + ': ' + name });
      const st = T_(fns[name], cfg.minMs, cfg.reps);
      emit({ type: 'cell', scenario: 'product', key: n, variant: name, stats: st }); emit({ type: 'unit' });
      yield;
    }
  }
}

function* runJob(job, cfg, emit) {
  switch (job.kind) {
    case 'kernel': yield* kernelJob(job.scenario, cfg, emit); break;
    case 'product': yield* productJob(cfg, emit); break;
    case 'bodies': yield* bodiesJob(cfg, emit); break;
    case 'alloc': yield* allocJob(cfg, emit); break;
    case 'check': yield* checkJob(job.scenario, job.ns, emit); break;
    case 'warm': yield* warmJob(job, cfg, emit); break;
    default: throw new Error('unknown job ' + job.kind);
  }
}
const unitsFor = (job, cfg) => {
  switch (job.kind) {
    case 'kernel': return cfg.ns.length + cfg.ns.reduce((s, n) => s + variantsFor(job.scenario, n).length, 0);
    case 'product': return productNsFor(cfg).reduce((t, n) => t + 1 + productVariantsFor(n).length, 0);
    case 'bodies': return 1 + 1 + BODY_VARIANTS.length;
    case 'alloc': return 1 + 2 * ALLOC_SIZES.length + 3;
    case 'check': return job.ns.length;
    default: return 1;
  }
};
