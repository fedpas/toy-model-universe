import { parseMath, visibleText } from './mathTextCore.js';
// Unit tests of the typesetter rules (formulas inside sentences become sub/superscripts; file names and words stay as they are).
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };
const runs = s => parseMath(s).filter(n => n.k === 'run').map(n => n.raw);
const rest = s => parseMath(s).map(n => (n.k === 'text' ? n.s : '\u0000')).join('');
ok(JSON.stringify(runs('D^μF_{μν} = J_ν')) === JSON.stringify(['D^μF_{μν} = J_ν']), 'the Maxwell equation is one formula');
{ const r = parseMath('D^μF_{μν} = J_ν')[0].parts; ok(r.length === 4 && r[0].base === 'D' && r[0].sup === 'μ' && r[0].sub === '' && r[1].base === 'F' && r[1].sub === 'μν' && r[3].base === 'J' && r[3].sub === 'ν', 'D^μ F_{μν} = J_ν reads D (up μ) F (down μν) = J (down ν)'); }
ok(JSON.stringify(runs('in D^μF_{μν} = κj_ν. There is')) === JSON.stringify(['D^μF_{μν} = κj_ν']) && rest('in D^μF_{μν} = κj_ν. There is') === 'in \u0000. There is', 'sentence text and the full stop stay outside');
ok(runs('gravity_selfcheck.py').length === 0 && runs('snake_case_name').length === 0 && runs('pgadyn_selfcheck.py and matrix_check.py').length === 0, 'file names and snake_case words are not formulas');
ok(runs('x_maxima and my_variable').length === 0, 'a script that is a longer word is not read');
ok(JSON.stringify(runs('(−1)^k V x V⁻¹')) === JSON.stringify(['(−1)^k']) && rest('(−1)^k V x V⁻¹') === '\u0000 V x V⁻¹', 'a bracket group takes its power');
ok(JSON.stringify(runs('2^{n−1} vertices and 2^n')) === JSON.stringify(['2^{n−1}', '2^n']), 'powers of numbers');
ok(JSON.stringify(runs('B_an, B_bn and B_ab')) === JSON.stringify(['B_an, B_bn', 'B_ab']), 'a comma list is one formula, a word ends it');
ok(JSON.stringify(runs('u_R, d_R, Q_L')) === JSON.stringify(['u_R, d_R, Q_L']), 'particle labels');
{ const p = parseMath('F^a_{μν}')[0].parts[0]; ok(p.sup === 'a' && p.sub === 'μν', 'both scripts on one symbol'); }
ok(JSON.stringify(runs('[D_μ, D_ν]Ψ = gF_{μν}Ψ.')) === JSON.stringify(['[D_μ, D_ν]Ψ = gF_{μν}Ψ']), 'neighbouring brackets and letters stay with the formula');
ok(runs('the term(D_μ) and wordx_1 here').join('|') === '(D_μ)', 'a letter inside a longer word is not a base');
ok(runs('e^{θB}').length === 1 && runs('Σ_{b<c} R^{bc}').length === 2, 'braces with operators');
ok(runs('plain text with no formulas at all.').length === 0 && parseMath('plain')[0].s === 'plain', 'plain text is returned as it is');
for (const s of ['D^μF_{μν} = J_ν', 'e^{θB}', 'B_an, B_bn', '(−1)^k', '2^{n−1}']) ok(parseMath(s).map(n => n.raw || n.s).join('') === s, 'the source text of ' + s + ' is kept (data-raw)');
console.log(bad ? bad + ' FAILURES' : 'ALL MATHTEXT TESTS PASS'); process.exit(bad ? 1 : 0);
