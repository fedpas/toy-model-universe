import React from 'react';
import DictionarySection from './DictionarySection.jsx';
import ThreeGenSection from './ThreeGenSection.jsx';
import FureyFindings from './FureyFindings.jsx';
import { TabBar, TabPanel, useSub } from './StoryShell.jsx';

// Test 2 (Furey) is three parts that read one at a time: the dictionary, the test of the 256 for three generations, and the findings on Furey's construction.
export default function FureyPage({ lang = 'en', profile = 'Young Learner', go }) {
  const [sub, setSub] = useSub('furey');
  return <><TabBar lang={lang} page="furey" active={sub} onPick={setSub} />
    <TabPanel lang={lang} page="furey" id={sub} onPick={setSub} goMap={go}>
      {sub === 'dictionary' && <DictionarySection lang={lang} profile={profile} />}
      {sub === 'threegen' && <ThreeGenSection lang={lang} profile={profile} />}
      {sub === 'findings' && <FureyFindings lang={lang} profile={profile} />}
    </TabPanel></>;
}
