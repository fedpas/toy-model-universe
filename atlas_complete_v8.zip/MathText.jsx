import React from 'react';
import { parseMath, isVariable, scriptIsLabel } from './mathTextCore.js';

// <Tx>{text}</Tx> draws the formulas that sit inside a sentence: D^μF_{μν} = J_ν becomes D with a superscript μ, F with a subscript μν, math letters in italic.
// Text without a formula comes back untouched (the same string), other children pass through. The rules live in mathTextCore.js.
const CSS = `.mt{font-family:"STIX Two Text","STIX Two Math","Cambria Math","Latin Modern Math","Times New Roman",serif;font-size:1.07em;line-height:1;color:inherit}
.mt i{font-style:italic}.mt-s{white-space:nowrap}
.mt sub,.mt sup{font-size:.7em;line-height:0;position:relative;vertical-align:baseline}.mt sup{top:-.48em}.mt sub{top:.26em}
.mt .mt-st{display:inline-flex;flex-direction:column;vertical-align:-.5em;font-size:.7em;line-height:1.05;text-align:left}
.mt .mt-st sub,.mt .mt-st sup{font-size:1em;position:static;top:auto}`;
if (typeof document !== 'undefined' && !document.getElementById('mt-style')) { const st = document.createElement('style'); st.id = 'mt-style'; st.textContent = CSS; document.head.appendChild(st); }

const Chars = ({ s, upright }) => {
  const out = []; let buf = '', ital = false, n = 0;
  const flush = () => { if (!buf) return; out.push(ital && !upright ? <i key={n++}>{buf}</i> : buf); buf = ''; };
  for (const ch of s) { const v = isVariable(ch); if (v !== ital) { flush(); ital = v; } buf += ch; }
  flush(); return <>{out}</>;
};
const Script = ({ text }) => {
  if (scriptIsLabel(text)) return <Chars s={text} upright />;
  const nodes = parseMath(text);
  return <>{nodes.map((x, i) => (x.k === 'text' ? <Chars key={i} s={x.s} /> : <Run key={i} run={x} />))}</>;
};
const Sym = ({ p }) => {
  const sub = p.sub ? <sub><Script text={p.sub} /></sub> : null, sup = p.sup ? <sup><Script text={p.sup} /></sup> : null;
  return <span className="mt-s"><Chars s={p.base} upright={p.named} />{sub && sup ? <span className="mt-st">{sup}{sub}</span> : <>{sup}{sub}</>}</span>;
};
const Run = ({ run }) => <span className="mt" data-raw={run.raw}>{run.parts.map((p, i) => (p.k === 'sym' ? <Sym key={i} p={p} /> : <Chars key={i} s={p.s} />))}</span>;

const cache = new Map();
const typeset = s => {
  let r = cache.get(s);
  if (r === undefined) {
    const nodes = parseMath(s);
    r = nodes.length === 1 && nodes[0].k === 'text' ? s : nodes.map((x, i) => (x.k === 'text' ? <React.Fragment key={i}>{x.s}</React.Fragment> : <Run key={i} run={x} />));
    if (cache.size > 5000) cache.clear();
    cache.set(s, r);
  }
  return r;
};
const walk = c => (typeof c === 'string' ? typeset(c) : Array.isArray(c) ? c.map((x, i) => (typeof x === 'string' ? <React.Fragment key={'m' + i}>{typeset(x)}</React.Fragment> : x)) : c);
export function Tx({ children }) { return <>{walk(children)}</>; }
export default Tx;
