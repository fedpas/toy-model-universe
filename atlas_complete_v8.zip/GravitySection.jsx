import React, { useState } from 'react';
import { Fold, Intro, level } from './Fold.jsx';
import K from './gravityData.js';
import { GV_PY, GVM_PY } from './gravitySelfcheckSource.js';
import { STORY } from './storyCopy.js';
import COPY, { planes, pairClass, subsets4, plane } from './gravityCopy.js';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';

// Steps 6 and 7 of the equations page: gravity, n = 2 ... 8.
// Numbers come from selfcheck/gravity_selfcheck.py (exact) and selfcheck/gravity_matrix_check.py (numpy); test_gravity.mjs recomputes the structure independently.
const download = (name, text, type) => { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } };
const Tags = ({ kinds, lang }) => <>{kinds.map(k => <span key={k} className={'tag ' + k} title={STORY[lang].tagHelp[k]}><Tx>{STORY[lang].tags[k]}</Tx></span>)}</>;
const COL = { diagonal: '#fbbf24', one: '#60a5fa', disjoint: '#34d399' };
const AX = ['t', 'x', 'y', 'z', 'u', 'v', 'w', 's'];
const NS = Object.keys(K.gv.ladder).map(Number);
const tick = v => (v ? '✓' : '✗');

// the table of curvature components: unordered pairs of planes, coloured by how many axes the planes share
function PairGrid({ n, cls, sub, t }) {
  const pl = planes(n), P = pl.length, s = Math.min(16, 320 / P), W = P * s + 20;
  const hit = new Set();
  if (sub != null && sub !== '') {
    const [a, b, c, d] = subsets4(n)[+sub], key = (x, y) => (1 << x | 1 << y), ix = m => pl.indexOf(m);
    for (const [p, q] of [[key(a, b), key(c, d)], [key(a, c), key(b, d)], [key(a, d), key(b, c)]]) { const i = ix(p), j = ix(q); hit.add(Math.min(i, j) + ',' + Math.max(i, j)); }
  }
  const cells = [];
  for (let i = 0; i < P; i++) for (let j = i; j < P; j++) {
    const c = pairClass(pl[i], pl[j]), on = sub != null && sub !== '' ? hit.has(i + ',' + j) : (cls === 'all' || cls === c);
    cells.push(<rect key={i + ',' + j} className={'gv-cell' + (on ? ' on' : '')} data-class={c} data-on={on ? 1 : 0} x={10 + j * s} y={10 + i * s} width={s - 1} height={s - 1} fill={COL[c]} opacity={on ? .95 : .1}><title>{`(${axn(pl[i])} | ${axn(pl[j])}) ${t.classes[c]}`}</title></rect>);
  }
  return <svg className="eq-svg" style={{ maxWidth: 420 }} viewBox={`0 0 ${W} ${W}`} role="img" aria-label="Table of pairs of planes, coloured by the number of shared axes" data-n={n}><Tx>{cells}</Tx></svg>;
}
const axn = m => AX.filter((_, i) => m >> i & 1).join('');

export function GravityOneSection({ lang = 'en', profile = 'Young Learner' }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l].g1, Lad = K.gv.ladder, [n, setN] = useState(4), [cls, setCls] = useState('all'), [sub, setSub] = useState('');
  const r = { ...Lad[n], n_value: n }, ID = K.gv.identities, views = t.views(r), CS = K.gv.curvature_space;
  const pick = k => { setN(k); setCls('all'); setSub(''); };
  const subs = n >= 4 ? subsets4(n) : [];
  const subName = i => subs[i].map(x => AX[x]).join('');
  const subCells = i => { const [a, b, c, d] = subs[i]; return [`${plane(a, b)}|${plane(c, d)}`, `${plane(a, c)}|${plane(b, d)}`, `${plane(a, d)}|${plane(b, c)}`].join(', '); };
  return <section className="eq" id="eq-grav1" aria-labelledby="eq-gv1-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'grav1')}</Tx></p><h2 id="eq-gv1-h"><Tx>{t.title}</Tx></h2><Intro lang={l} profile={profile} id="grav1" lede={t.lede} />
    <div><Tags kinds={['checked', 'standard']} lang={l} /></div>
    <Fold title={t.tableH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="gv-table"><thead><tr>{t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {NS.map(k => { const x = Lad[k], cs = CS[k]; return <tr key={k} className={k === n ? 'on' : ''} onClick={() => pick(k)} style={{ cursor: 'pointer' }}><td><Tx>{k}</Tx></td><td><Tx>{x.frame_algebra}</Tx></td><td><Tx>{x.bivectors}</Tx> (<Tx>{x.boosts}</Tx> + <Tx>{x.rotations}</Tx>)</td><td><Tx>{x.omega_components}</Tx></td><td><Tx>{x.tetrad_components}</Tx></td><td><Tx>{x.curvature_components}</Tx></td><td><Tx>{x.torsion_components}</Tx></td><td><Tx>{x.riemann_independent}</Tx></td><td><Tx>{x.first_bianchi_constraints}</Tx></td><td><Tx>{cs ? `${cs.ricci_rank} + ${cs.weyl_dimension}` : '—'}</Tx></td></tr>; })}</tbody></table></div></Fold>
    <h3><Tx>{t.pickH}</Tx></h3><div className="eq-card"><p className="eq-cap"><Tx>{t.pick}</Tx></p>
      <div className="eq-chips" role="group">{NS.map(k => <button key={k} className={'eq-chip gv-chip' + (k === n ? ' on' : '')} aria-pressed={k === n} onClick={() => pick(k)}><Tx>{k}</Tx></button>)}</div>
      <h4><Tx>{t.picH}</Tx></h4><PairGrid n={n} cls={cls} sub={sub} t={t} /><p className="eq-cap gv-cap"><Tx>{t.picCap(n)}</Tx></p>
      <div className="eq-chips gv-classes" role="group">{['all', 'diagonal', 'one', 'disjoint'].map(c => <button key={c} className={'eq-chip gv-cls' + (cls === c && sub === '' ? ' on' : '')} aria-pressed={cls === c && sub === ''} onClick={() => { setCls(c); setSub(''); }}><Tx>{t.classes[c]}</Tx><Tx>{c !== 'all' ? ` · ${c === 'diagonal' ? r.pair_classes.diagonal : c === 'one' ? r.pair_classes.share_one_index : r.pair_classes.disjoint}` : ''}</Tx></button>)}</div>
      {n >= 4 && <p className="eq-cap"><label><Tx>{t.subLabel}</Tx>: <select className="gv-sub" value={sub} onChange={e => setSub(e.target.value)}><option value="">{t.subNone}</option>{subs.map((_, i) => <option key={i} value={i}>{subName(i)}</option>)}</select></label></p>}
      <p className="eq-cap gv-selcap"><Tx>{sub !== '' && n >= 4 ? t.subCap(subName(+sub), subCells(+sub)) : t.classCap(cls, cls === 'diagonal' ? r.pair_classes.diagonal : cls === 'one' ? r.pair_classes.share_one_index : r.pair_classes.disjoint)}</Tx></p>
      <Fold nested title={t.viewsH(n)} open={lv >= 1}><div className="gv-views">{views.map(v => <div key={v.h} className="eq-xr gv-view"><h4><Tx>{v.h}</Tx> <Tags kinds={v.tags} lang={l} /></h4><p><Tx>{v.t}</Tx></p></div>)}</div></Fold></div>
    <Fold title={t.idH} open={lv >= 1}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="gv-id"><thead><tr>{t.idCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{Object.entries(ID).map(([k, v]) => <tr key={k}><td><Tx>{k}</Tx></td><td><Tx>{tick(v.second_bianchi)}</Tx></td><td><Tx>{tick(v.first_bianchi)}</Tx></td><td><Tx>{tick(v.local_lorentz_covariance)}</Tx></td><td><Tx>{tick(v.spinor_commutator)}</Tx></td></tr>)}</tbody></table><p className="eq-cap"><Tags kinds={['checked']} lang={l} /> <Tx>{t.idNote}</Tx></p></div></Fold>
    <Fold title={t.xrH} open={lv >= 2}>{t.xr.map(([k, txt], i) => <div key={i} className="eq-xr"><p><Tags kinds={[k]} lang={l} /> <Tx>{txt}</Tx></p></div>)}</Fold>
    <Fold title={t.matH} open={lv >= 2}><div className="eq-card"><p><Tags kinds={['checked', 'standard']} lang={l} /> <Tx>{t.mat}</Tx></p><p className="eq-cap"><Tx>{t.numbers}</Tx></p></div></Fold>
    <div>{t.open.map(([k, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={[k]} lang={l} /></div><p><Tx>{txt}</Tx></p></div>)}</div>
    <Fold title={t.dl.h} open={lv >= 2}><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('gravity_selfcheck.py', GV_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('gravity_matrix_check.py', GVM_PY, 'text/x-python')}><Tx>{t.dl.py2}</Tx></button><button className="eq-btn" onClick={() => download('gravity.json', JSON.stringify(K.gv, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p></Fold></section>;
}

// the terms of E_a: for a fixed index a, the pairs {b, c} of the other axes (edges of the simplex on them); the remaining axes carry tetrads
function TermRing({ n, a, selected, onSelect, t }) {
  const R = 78, C = [130, 100], pos = k => [C[0] + R * Math.cos((-90 + 360 * k / n) * Math.PI / 180), C[1] + R * Math.sin((-90 + 360 * k / n) * Math.PI / 180)];
  const others = [...Array(n).keys()].filter(x => x !== a), edges = [];
  for (let i = 0; i < others.length; i++) for (let j = i + 1; j < others.length; j++) edges.push([others[i], others[j]]);
  const sel = selected && selected[0] !== a && selected[1] !== a ? selected : null, rest = sel ? others.filter(x => x !== sel[0] && x !== sel[1]) : [];
  return <svg className="eq-svg" style={{ maxWidth: 400 }} viewBox="0 0 260 200" role="img" aria-label="The pairs of axes that make the terms of the Einstein form" data-n={n}>
    {edges.map(([b, c]) => { const on = sel && sel[0] === b && sel[1] === c; return <g key={b + '-' + c}><line className={'gv-edge' + (on ? ' on' : '')} x1={pos(b)[0]} y1={pos(b)[1]} x2={pos(c)[0]} y2={pos(c)[1]} stroke={on ? '#34d399' : 'currentColor'} strokeWidth={on ? 2.4 : .8} opacity={sel ? (on ? 1 : .25) : .55} /><line x1={pos(b)[0]} y1={pos(b)[1]} x2={pos(c)[0]} y2={pos(c)[1]} stroke="transparent" strokeWidth="9" style={{ cursor: 'pointer' }} className="gv-edge-hit" onClick={() => onSelect([b, c])}><title>{`{${AX[b]}, ${AX[c]}}`}</title></line></g>; })}
    {[...Array(n).keys()].map(k => { const p = pos(k), isA = k === a, isR = rest.includes(k), isP = sel && (sel[0] === k || sel[1] === k); return <g key={k} className="gv-node"><circle className={isA ? 'gv-a' : isR ? 'gv-rest' : isP ? 'gv-pair' : 'gv-plain'} cx={p[0]} cy={p[1]} r={isA ? 7 : 5} fill={isR ? '#fbbf24' : isP ? '#34d399' : isA ? 'none' : '#8b93a7'} stroke={isA ? '#f87171' : '#8b93a7'} strokeWidth={isA ? 2 : 1} /><text x={p[0] + (p[0] >= C[0] ? 10 : -10)} y={p[1] + 4} textAnchor={p[0] >= C[0] ? 'start' : 'end'} fontSize="11" fill="currentColor">{AX[k]}</text></g>; })}</svg>;
}

export function GravityTwoSection({ lang = 'en', profile = 'Young Learner' }) {
  const lv = level(profile), l = COPY[lang] ? lang : 'en', t = COPY[l].g2, Lad = K.gv.ladder, [n, setN] = useState(4), [a, setA] = useState(0), [selected, setSelected] = useState(null);
  const r = { ...Lad[n], n_value: n }, views = t.views(r);
  const pick = k => { setN(k); setA(0); setSelected(null); };
  const sel = selected && selected[0] !== a && selected[1] !== a ? selected : null, rest = sel ? [...Array(n).keys()].filter(x => x !== a && x !== sel[0] && x !== sel[1]).map(x => AX[x]) : [];
  const EI = K.gv.einstein_identities, DS = K.gv.desitter, RT = K.gv.einstein_tensor_ratio;
  return <section className="eq" id="eq-grav2" aria-labelledby="eq-gv2-h"><p className="eyebrow"><Tx>{stepEyebrow(l, 'eq', 'grav2')}</Tx></p><h2 id="eq-gv2-h"><Tx>{t.title}</Tx></h2><Intro lang={l} profile={profile} id="grav2" lede={t.lede} />
    <div><Tags kinds={['checked', 'standard']} lang={l} /></div>
    <Fold title={t.tableH} open={lv >= 2}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="gv-table2"><thead><tr>{t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {NS.map(k => { const x = Lad[k]; return <tr key={k} className={k === n ? 'on' : ''} onClick={() => pick(k)} style={{ cursor: 'pointer' }}><td><Tx>{k}</Tx></td><td><Tx>{x.einstein_components}</Tx></td><td><Tx>{x.einstein_terms_per_component}</Tx></td><td><Tx>{k >= 3 ? k - 3 : 0}</Tx></td><td><Tx>{x.divergence_torsion_terms_per_component}</Tx></td><td><Tx>{x.desitter_generators}</Tx></td><td><Tx>{x.desitter_curvature_components}</Tx></td></tr>; })}</tbody></table></div></Fold>
    <h3><Tx>{t.pickH}</Tx></h3><div className="eq-card"><p className="eq-cap"><Tx>{t.pick}</Tx></p>
      <div className="eq-chips" role="group">{NS.map(k => <button key={k} className={'eq-chip gv-chip2' + (k === n ? ' on' : '')} aria-pressed={k === n} onClick={() => pick(k)}><Tx>{k}</Tx></button>)}</div>
      <h4><Tx>{t.picH}</Tx></h4>
      <p className="eq-cap"><Tx>{t.aLabel}</Tx>:</p><div className="eq-chips gv-achips" role="group">{[...Array(n).keys()].map(k => <button key={k} className={'eq-chip gv-achip' + (a === k ? ' on' : '')} aria-pressed={a === k} onClick={() => { setA(k); setSelected(null); }}><Tx>{AX[k]}</Tx></button>)}</div>
      <TermRing n={n} a={a} selected={selected} onSelect={setSelected} t={t} /><p className="eq-cap gv-cap"><Tx>{t.picCap(n)}</Tx></p>
      <p className="eq-cap gv-selcap"><Tx>{sel ? t.capSel(AX[sel[0]], AX[sel[1]], rest) : t.capNone}</Tx></p>
      <Fold nested title={t.viewsH(n)} open={lv >= 1}><div className="gv-views2">{views.map(v => <div key={v.h} className="eq-xr gv-view2"><h4><Tx>{v.h}</Tx> <Tags kinds={v.tags} lang={l} /></h4><p><Tx>{v.t}</Tx></p></div>)}</div></Fold></div>
    <Fold title={t.idH} open={lv >= 1}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="gv-id2"><thead><tr>{t.idCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{Object.entries(EI).map(([k, v]) => { const [nn, c] = k.split(','); return <tr key={k}><td><Tx>{nn}</Tx></td><td><Tx>{c}</Tx></td><td><Tx>{tick(v.covariant_divergence_of_E_is_torsion_terms)}</Tx></td><td><Tx>{+c === 0 && RT[nn] === '1' ? '✓' : '—'}</Tx></td></tr>; })}</tbody></table><p className="eq-cap"><Tags kinds={['checked']} lang={l} /> <Tx>{t.idNote}</Tx></p></div></Fold>
    <Fold title={t.dsH} open={lv >= 1}><div className="eq-card" style={{ overflowX: 'auto' }}><table className="gv-ds"><thead><tr>{t.dsCols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{Object.entries(DS).map(([k, v]) => <tr key={k}><td><Tx>{k.split(',')[0]}</Tx></td><td><Tx>{v.extra_generator_square > 0 ? '+1' : '−1'}</Tx></td><td><Tx>{v.group}</Tx></td><td><Tx>{v.coefficient_of_e_wedge_e > 0 ? '+' : ''}</Tx><Tx>{v.coefficient_of_e_wedge_e}</Tx></td><td><Tx>{v.coefficient_of_torsion}</Tx></td></tr>)}</tbody></table><p className="eq-cap"><Tags kinds={['checked', 'standard']} lang={l} /> <Tx>{t.dsNote}</Tx></p></div></Fold>
    <Fold title={t.xrH} open={lv >= 2}>{t.xr.map(([k, txt], i) => <div key={i} className="eq-xr"><p><Tags kinds={[k]} lang={l} /> <Tx>{txt}</Tx></p></div>)}</Fold>
    <Fold title={t.matH} open={lv >= 2}><div className="eq-card"><p><Tags kinds={['checked', 'standard']} lang={l} /> <Tx>{t.mat}</Tx></p><p className="eq-cap"><Tx>{t.numbers}</Tx></p></div></Fold>
    <div>{t.open.map(([k, txt], i) => <div key={i} className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={[k]} lang={l} /></div><p><Tx>{txt}</Tx></p></div>)}</div>
    <Fold title={t.dl.h} open={lv >= 2}><p><Tx>{t.dl.text}</Tx></p><div><button className="eq-btn" onClick={() => download('gravity_selfcheck.py', GV_PY, 'text/x-python')}><Tx>{t.dl.py}</Tx></button><button className="eq-btn" onClick={() => download('gravity_matrix_check.py', GVM_PY, 'text/x-python')}><Tx>{t.dl.py2}</Tx></button><button className="eq-btn" onClick={() => download('gravity.json', JSON.stringify(K.gv, null, 1), 'application/json')}><Tx>{t.dl.json}</Tx></button></div><p className="eq-mono eq-cap"><Tx>{t.dl.cmd}</Tx></p></Fold></section>;
}
export default GravityOneSection;
