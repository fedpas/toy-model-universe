// Copy of step 14 (null surfaces), English and Italian. The numbers in the sentences come from selfcheck/null.json (K.portal); the figures draw from nullEngine.js.
// Strings used inside an SVG <text> are plain Unicode (no _ or ^ markup, which only <Tx> reads); every other string may carry plain-text formulas.
import K from './nullData.js';
import { stepNo } from './steps.js';

const S = K.portal.summary, P9 = stepNo('eq', 'projective'), P8 = stepNo('eq', 'mirrors'), P10 = stepNo('eq', 'forque'), P13 = stepNo('eq', 'rigid');
const sum = a => a.reduce((x, y) => x + y, 0);

const en = {
  title: 'Null surfaces: a horizon is a photon that stands still',
  lede: 'A surface is null when its normal is null, and then the light that generates it runs along the surface. This step takes four claims about null hypersurfaces from Hsu, Barker, Hobson and Lasenby (arXiv:2504.13255), rebuilds them on the bit rule with exact arithmetic, and draws each one live. Move a slider, switch the lens, and the same state is drawn another way. This page keeps the results and the figures; the full analysis is in a separate write-up.',
  summary: `${S.computed} computed checks, ${S.passed} pass. ${S.readings} readings are ours and are not computed.`,
  fig: 'Figure',
  lensH: 'Lens: the same state drawn another way',
  lens: { clifford: 'Clifford', cube: 'Cube', simplex: 'Simplex', prime: 'Prime', mirror: 'Mirror', null: 'Null', flow: 'Flow' },
  cards: [
    { h: 'The generator of a null surface is a photon that stands still', tags: ['checked', 'standard', 'ours'], text: [
      'Take the regular covector n = dx. Its norm is n·n = −T with T = g_tt, so the surface x = const is null exactly when T = 0, and then the vector dual to n is ∂_v: at once the normal and the generator. The generator obeys ξ·∇ξ = −κξ with κ = ½ dT/dx, a geodesic that is not affinely parametrised: the photon that stands still. κ is computed for five horizons (the chips below): 1/6, 1/8, −1/2, 0 and 3/10.',
      'On Kerr the radical of the induced metric is the paper’s photon, with dφ/dt = a/(r₊² + a²) = 1/30 at five polar angles. The generators of any null hypersurface are geodesics, with or without a symmetry (standard; checked on one example with no Killing vector). So the claim is true and not specific to the paper’s method; “by contrast with the induced-metric approach” is a difference of presentation (our reading).'] },
    { h: 'Horizon or throat: T decides, g^rr does not', tags: ['checked'], text: [
      'g^rr = n·n/(T R), where R is the radial factor of the metric. It vanishes for two unrelated reasons: the surface is null (n·n = 0), or the radial unit has become infinitely long (R → ∞) while n·n stays finite. In Schwarzschild T R = 1, so the two coincide and g^rr = 0 looks like the horizon. In the Ellis wormhole T = 1: at the throat g^rr = 0 but n·n = −1, a timelike surface. Said another way, g^rr = −(dr/dℓ)² with ℓ the proper radial length, so g^rr = 0 wherever r is stationary along the slice, a neck, whatever T does.'] },
    { h: 'Is g_tt = 0 the criterion for a null surface?', tags: ['checked', 'standard'], text: [
      'Yes, for a static ξ whose level set g_tt = 0 is regular and whose F = ∇ξ·∇ξ is finite: then n·n = ½ (ξ·ξ) F. Not as an unqualified statement. (a) F infinite: the surface of Eq. (18) is still null, but Eq. (1) does not vanish. (b) Extremal horizon: ∇(ξ·ξ) = 0, so the level set is not regular. (c) ξ not hypersurface-orthogonal: g_tt = 0 is a timelike surface, in rotating flat space and on the Kerr ergosurface. (d) ξ spacelike: null planes with ξ·ξ ≠ 0 exist.'] },
    { h: 'The horizon has an algebra of its own', tags: ['checked', 'standard', 'ours'], text: [
      `For n = 2 to 6 the tangent algebra of a null hypersurface is Cl(0, n−2, 1), of dimension 2^{n−1}. The blades through the null bit form a two-sided ideal J with J·J = 0 and dimension 2^{n−2}, and the quotient is the cross-section algebra Cl(0, n−2): ℝ, ℂ, ℍ, ℍ ⊕ ℍ, M₂(ℍ). At n = 4 its even part is the even plane PGA R(2,0,1) of steps ${P10} and ${P13}. Crossing the horizon changes one sign: the tube’s tangent algebra Cl(T, −1, −1) is so(1,2), iso(2) or so(3) for T > 0, T = 0, T < 0 (the cube lens of figure 1). The counts and the quotients for n ≤ 4 are computed; the names for n = 5, 6 and for the cells are the textbook classification; reading J as a facet of the cube and as the star of a vertex is ours.`] },
  ],
  critH: 'Eq. (1) on three null surfaces', critText: 'All three surfaces are null (T = 0, so n·n = −T = 0). Eq. (1) is T (dT/dx)² up to sign. Slide toward the surface and watch where it goes.',
  kerrH: 'Kerr: the ergosurface is not the horizon', kerrText: 'In Kerr, ξ = ∂_t is not hypersurface-orthogonal, so its null set g_tt = 0 is not the null surface. M = 5, a = 3, r₊ = 9. Slide along the ergosurface.',
  cone: {
    caseH: 'Which horizon', probe: 'Probe surface: distance x − x_h from the horizon', onSurf: 'Put it on the horizon',
    aria: 'Light cones along the radial coordinate x, the surface x = const and its normal, with the function T of x on the left',
    cases: { schw: 'Schwarzschild', rn_out: 'Reissner–Nordström, outer', rn_in: 'Reissner–Nordström, inner', extremal: 'Extremal', areal: 'Areal radius' },
    kinds: { timelike: 'timelike', null: 'null', spacelike: 'spacelike' },
    read: { surface: 'the surface x = const is', gram: 'Gram determinant of the null pair', tort: 'tortoise', ef: 'Eddington–Finkelstein' },
    alg: { so12: 'T > 0: the tube’s tangent algebra is so(1,2)', iso2: 'T = 0: iso(2), the null case (K1 and K2 commute)', so3: 'T < 0: so(3)' },
    lab: { xi: 'ξ = ∂ᵥ', n: 'n = dx', surface: 'x = const', axes: 'horizontal v · vertical x', tbit: 'time bit (T)', cube: '3-cube: K1 = 3, K2 = 5, J = 6', w: 'w', img: 'w′', off: 'w′ (off the page)', none: 'no image: n·n = 0' },
    caps: {
      clifford: 'Grey: the light cones along x, with T(x) plotted on the left. Colour: the cone at the probe. The surface x = const is the horizontal line; ξ = ∂_v runs along it and n = dx points across. As T falls to 0 the second edge of the cone lies along the surface: ξ is null, and the surface is a photon that stands still. The tilt is drawn at its own vertical scale for each horizon (the largest |T| in the window tips the edge by 45°), so compare shapes within a horizon, not between horizons.',
      cube: 'The tube r = const has tangent algebra Cl(T, −1, −1): bit 0 is the time bit (square T), bits 1 and 2 span the sphere. The even corners 3, 5, 6 of the 3-cube are K1, K2 and J, and the three edges between them are their brackets. [J, K1] = 2 K2 and [J, K2] = −2 K1 do not depend on T; [K1, K2] = −2T J fades with T and vanishes at T = 0 (dashed): so(1,2) becomes iso(2), then so(3) for T < 0.',
      mirror: 'A mirror in the covector n sends w to w − 2 (n·w)/(n·n) n♯. With n = dx, n·n = −T: the x component of w flips sign and the v component becomes w^v + 2 w^x/T. Slide the probe toward the horizon: the image runs off to infinity, and at T = 0 there is none. A null plane is not a mirror, because a null vector has no inverse.' },
  },
  neck: {
    r: 'Radius r (Schwarzschild r_S = 1; Ellis throat radius = 1)',
    aria: 'Schwarzschild and Ellis compared: the norm of the normal and g^rr, the two spacetimes in null coordinates, and the rates along an ingoing photon',
    schw: 'Schwarzschild', ellis: 'Ellis wormhole', kruskal: 'Schwarzschild: Kruskal (X, T)', ellisChart: 'Ellis: (ℓ, t)',
    lab: { n2: '|n·n|, norm of the normal', grr: '|gʳʳ|', null: 'r = 1: horizon (null), throat (timelike)', photon: 'a photon crossing it', live: 'the slice at the chosen r', dr: 'dr/dv along an ingoing photon', dl: 'dℓ/dv, proper length' },
    caps: {
      clifford: 'Solid: |n·n|, the norm of the normal. Dashed: |g^rr|. In Schwarzschild they are one curve (T R = 1), so g^rr = 0 looks like the horizon. In the Ellis wormhole n·n = −1 all the way down while g^rr goes to 0 at the throat: r is stationary along the slice, a neck, but the surface r = 1 is timelike.',
      null: 'The same two spacetimes in null coordinates. Schwarzschild in Kruskal (X, T): the horizon r = 1 is the null pair X = ±T, and a photon crosses it. Ellis in (ℓ, t): the throat ℓ = 0 is a vertical, timelike line, and a photon crosses it too. Amber: the slice at your r (X² − T² = (r − 1) e^r in Kruskal, ℓ = ±√(r² − 1) in Ellis).',
      flow: 'Along an ingoing photon, how fast do r and the proper length ℓ change per unit v? At the Schwarzschild horizon both go to 0: the photon stands still. At the Ellis throat dr/dv goes to 0 but dℓ/dv = ½: r is stationary and the photon keeps moving.' },
  },
  crit: {
    caseH: 'Which surface', probe: 'Distance x from the surface (log scale)',
    aria: 'Eq. (1) against the distance from the surface, log-log, for three null surfaces',
    cases: { simple: 'T = x (simple zero)', extremal: 'T = x² (extremal)', eq18: 'Eq. (18): T = (3x)^{1/3}' },
    lab: { x: 'distance x from the surface (log scale)', y: '|Eq. (1)| (log scale)' },
    caps: {
      simple: 'Simple zero: dT/dx = 1 and Eq. (1) = x, which goes to 0 with x. The test works: the surface is null and Eq. (1) vanishes on it.',
      extremal: 'Extremal: dT/dx = 2x, Eq. (1) = 4x⁴, which goes to 0 even faster. The surface is null and Eq. (1) vanishes, but ∇g_tt = 0 on it, so g_tt = 0 is not a regular level set and the derivation does not apply as written.',
      eq18: 'Eq. (18): dT/dx = (3x)^{−2/3} blows up, F = −(dT/dx)²/2 is infinite, and Eq. (1) = 1/(3x) grows while n·n = −T → 0. The surface is null; Eq. (1) fails. The condition is that dT/dx stays finite.' },
  },
  kerr: {
    theta: 'Polar angle θ of the point on the ergosurface', aria: 'Meridian plane of Kerr with the horizon and the ergosurface',
    lab: { axis: 'axis of rotation', horizon: 'horizon r₊ = 9 (null)', ergo: 'ergosurface gₜₜ = 0 (not null)' },
    pole: 'zero: at the pole the ergosurface touches the horizon', timelike: 'negative: a timelike surface, not null',
    cap: 'Kerr with M = 5 and a = 3 in the meridian plane (oblate coordinates). Blue: the horizon r₊ = 9, where Δ = 0 and the surface is null. Amber: the ergosurface g_tt = 0, outside the horizon and touching it at the poles. Its normal has n·n < 0 everywhere else, so g_tt = 0 bounds the region where ∂_t is timelike but is not the null surface. Seven values of n·n are exact in the script.',
  },
  ladder: {
    nH: 'Spacetime dimension n', aria: 'The algebra of a null hypersurface: the cell, the horizon algebra, its ideal J and the quotient',
    lab: {
      cell: 'The cell', matrices: nq => `2×2 matrices over ${nq}`, horizon: 'The horizon algebra', quot: 'quotient', std: 'textbook',
      cols: 'columns: grade · amber: through the null bit (the ideal J) · green: the quotient',
      simplex: m => `${m} generators as the vertices of a simplex: ℓ (null) and ${m - 1} for the sphere`,
      starCount: a => `faces that contain ℓ, by number of vertices: ${a.join(' + ')} = ${sum(a)}`,
      pCell: 'the cell', pHor: 'the horizon algebra', pJ: 'the ideal J',
      odd: 'Only the prime 2 appears. Each generator is a factor 2; the horizon drops one, and J fixes the null bit.',
      pick: (J, N) => `${J} of the ${N} corners lie through the null bit: one facet of the cube, the ideal J. Click a corner.`,
      vertex: (name, bits, inJ) => `Blade ${name}, label ${bits}: ${inJ ? 'through the null bit, so it is in J and its product with any blade of J is 0' : 'not through the null bit, so it is in the quotient'}`,
      faces: (J, m) => `The star of the null vertex has ${J} = 2^{${m - 1}} faces, counting the vertex itself: the same number as the blades of J.`,
      allPow2: 'The cell, the horizon algebra and J have dimensions 2^n, 2^{n−1} and 2^{n−2}: powers of 2 only. The null bit changes the product, not the count.',
    },
    caps: {
      clifford: 'Left: the cell Cl(1, n−1) is 2×2 matrices over the cross-section algebra Cl(0, n−2), the standard rule Cl(p+1, q+1) = M₂(Cl(p, q)). Right: the horizon algebra Cl(0, n−2, 1) has half the dimension of the cell and two parts, the ideal J (everything through the null bit, with J·J = 0) and the quotient, each of dimension 2^{n−2}.',
      cube: 'The blades of the horizon algebra as the corners of an (n−1)-cube, in columns by grade. The amber corners, all through the null bit, are one facet: half the cube, and they multiply to 0 among themselves. The green corners multiply as the cross-section algebra. In an orthonormal basis the horizon is not a face of the cube: the facet belongs to the null basis (our reading).',
      simplex: 'The same blades as the faces of a simplex whose vertices are the generators ℓ, e1, …; the empty face is the scalar. The ideal J is the star of the null vertex: every face that contains it (the amber edges and everything they span).',
      prime: 'The same three counts as factors of 2: 2^n for the cell, 2^{n−1} for the horizon algebra, 2^{n−2} for J. There is no odd prime anywhere.' },
  },
  limitsH: 'What this step does not cover',
  limits: [
    ['open', 'Eq. (12) of the paper is not rebuilt here.'],
    ['open', 'Of the references only Vishveshwara’s Appendix B and the abstract of Vollick were read, so a reading marked “ours” may already be known.'],
    ['open', 'One author wrote both the claims and the checks. A second reader has not gone through them.'],
  ],
  linksH: 'Links to the rest of the atlas',
  links: [
    [['checked', 'ours'], `Step ${P9}: the null directions are a plane`, 'The null directions of Cl(1,3) form the plane P(x) = o + x − ½x² ε of the projective step, the celestial sphere, and the horizon’s generator ε is its point at infinity. All 96 nonzero integer null vectors with entries up to 4 are a multiple of some P(x) or of ε (checked).'],
    [['checked'], `Step ${P8}: a null plane is not a mirror`, 'A null vector has no inverse, so a null hyperplane gives no reflection: the mirror lens of figure 1 shows the image running away as T → 0.'],
    [['checked'], 'Maxwell and Dirac: null covectors carry wavefronts', 'The principal symbol of ∇F = J, and of the Dirac equation, has a two-dimensional kernel on bivectors exactly at a null covector n. Null surfaces are the surfaces that can carry a wavefront.'],
    [['checked', 'ours'], 'Same names, different elements', 'Three kinds of ℍ and three of ℂ sit in these algebras, with different bit labels, grades and roles. The tangent algebra of the sphere is {0,1,2,3}, the rotor quaternions of ℝ³ are {0,3,5,6}, and an ideal of Cl(0,3) is the third (checked). A name that carries the labels, ℍ[0,1,2,3] and ℍ[0,3,5,6], does not mislead (ours).'],
  ],
  dl: { h: 'Check it yourself', text: 'null_selfcheck.py recomputes every number on this page with exact fractions (standard library only). It prints PASS or FAIL for each check and lists the two readings it does not compute. null.json is the data this page reads.', py: 'Download null_selfcheck.py', json: 'Download null.json', cmd: 'python3 null_selfcheck.py   ·   python3 null_selfcheck.py --compare null.json' },
};

const it = {
  title: 'Superfici nulle: un orizzonte è un fotone fermo',
  lede: 'Una superficie è nulla quando la sua normale è nulla, e allora la luce che la genera corre lungo la superficie. Questo passo prende quattro affermazioni sulle ipersuperfici nulle di Hsu, Barker, Hobson e Lasenby (arXiv:2504.13255), le ricostruisce sulla regola dei bit con aritmetica esatta e disegna ciascuna dal vivo. Muovi un cursore, cambia lente, e lo stesso stato viene disegnato in un altro modo. Questa pagina tiene i risultati e le figure; l’analisi completa è in un documento a parte.',
  summary: `${S.computed} controlli calcolati, ${S.passed} riusciti. ${S.readings} letture sono nostre e non sono calcolate.`,
  fig: 'Figura',
  lensH: 'Lente: lo stesso stato disegnato in un altro modo',
  lens: { clifford: 'Clifford', cube: 'Cubo', simplex: 'Simplesso', prime: 'Primi', mirror: 'Specchio', null: 'Nulla', flow: 'Flusso' },
  cards: [
    { h: 'Il generatore di una superficie nulla è un fotone fermo', tags: ['checked', 'standard', 'ours'], text: [
      'Prendi il covettore regolare n = dx. La sua norma è n·n = −T con T = g_tt, quindi la superficie x = const è nulla esattamente quando T = 0, e allora il vettore duale di n è ∂_v: insieme normale e generatore. Il generatore soddisfa ξ·∇ξ = −κξ con κ = ½ dT/dx, una geodetica non parametrizzata in modo affine: il fotone fermo. κ è calcolato per cinque orizzonti (i pulsanti qui sotto): 1/6, 1/8, −1/2, 0 e 3/10.',
      'Su Kerr il radicale della metrica indotta è il fotone dell’articolo, con dφ/dt = a/(r₊² + a²) = 1/30 a cinque angoli polari. I generatori di una qualsiasi ipersuperficie nulla sono geodetiche, con o senza simmetria (standard; controllato su un esempio senza vettore di Killing). Quindi l’affermazione è vera e non specifica del metodo dell’articolo; “a differenza dell’approccio con la metrica indotta” è una differenza di presentazione (nostra lettura).'] },
    { h: 'Orizzonte o gola: decide T, non g^rr', tags: ['checked'], text: [
      'g^rr = n·n/(T R), dove R è il fattore radiale della metrica. Si annulla per due ragioni scollegate: la superficie è nulla (n·n = 0), oppure l’unità radiale è diventata infinitamente lunga (R → ∞) mentre n·n resta finita. In Schwarzschild T R = 1, quindi le due coincidono e g^rr = 0 sembra l’orizzonte. Nel wormhole di Ellis T = 1: alla gola g^rr = 0 ma n·n = −1, una superficie di tipo tempo. Detto altrimenti, g^rr = −(dr/dℓ)² con ℓ la lunghezza radiale propria, quindi g^rr = 0 dove r è stazionario lungo la fetta, una strozzatura, qualunque cosa faccia T.'] },
    { h: 'g_tt = 0 è il criterio per una superficie nulla?', tags: ['checked', 'standard'], text: [
      'Sì, per un ξ statico il cui insieme di livello g_tt = 0 è regolare e il cui F = ∇ξ·∇ξ è finito: allora n·n = ½ (ξ·ξ) F. Non come affermazione senza condizioni. (a) F infinito: la superficie dell’Eq. (18) è ancora nulla, ma l’Eq. (1) non si annulla. (b) Orizzonte estremale: ∇(ξ·ξ) = 0, quindi l’insieme di livello non è regolare. (c) ξ non ortogonale a ipersuperfici: g_tt = 0 è una superficie di tipo tempo, nello spazio piatto rotante e sull’ergosuperficie di Kerr. (d) ξ di tipo spazio: esistono piani nulli con ξ·ξ ≠ 0.'] },
    { h: 'L’orizzonte ha un’algebra tutta sua', tags: ['checked', 'standard', 'ours'], text: [
      `Per n = 2…6 l’algebra tangente di un’ipersuperficie nulla è Cl(0, n−2, 1), di dimensione 2^{n−1}. I blade che passano per il bit nullo formano un ideale bilatero J con J·J = 0 e dimensione 2^{n−2}, e il quoziente è l’algebra della sezione Cl(0, n−2): ℝ, ℂ, ℍ, ℍ ⊕ ℍ, M₂(ℍ). A n = 4 la sua parte pari è il PGA del piano pari R(2,0,1) dei passi ${P10} e ${P13}. Attraversare l’orizzonte cambia un segno: l’algebra tangente del tubo Cl(T, −1, −1) è so(1,2), iso(2) o so(3) per T > 0, T = 0, T < 0 (la lente del cubo della figura 1). I conteggi e i quozienti per n ≤ 4 sono calcolati; i nomi per n = 5, 6 e per le celle sono la classificazione dei manuali; leggere J come una faccetta del cubo e come la stella di un vertice è nostro.`] },
  ],
  critH: 'L’Eq. (1) su tre superfici nulle', critText: 'Tutte e tre le superfici sono nulle (T = 0, quindi n·n = −T = 0). L’Eq. (1) è T (dT/dx)² a meno del segno. Scorri verso la superficie e guarda dove va.',
  kerrH: 'Kerr: l’ergosuperficie non è l’orizzonte', kerrText: 'In Kerr, ξ = ∂_t non è ortogonale a ipersuperfici, quindi il suo insieme nullo g_tt = 0 non è la superficie nulla. M = 5, a = 3, r₊ = 9. Scorri lungo l’ergosuperficie.',
  cone: {
    caseH: 'Quale orizzonte', probe: 'Superficie di prova: distanza x − x_h dall’orizzonte', onSurf: 'Mettila sull’orizzonte',
    aria: 'Coni di luce lungo la coordinata radiale x, la superficie x = const e la sua normale, con la funzione T di x a sinistra',
    cases: { schw: 'Schwarzschild', rn_out: 'Reissner–Nordström, esterno', rn_in: 'Reissner–Nordström, interno', extremal: 'Estremale', areal: 'Raggio areale' },
    kinds: { timelike: 'di tipo tempo', null: 'nulla', spacelike: 'di tipo spazio' },
    read: { surface: 'la superficie x = const è', gram: 'determinante di Gram della coppia nulla', tort: 'tartaruga', ef: 'Eddington–Finkelstein' },
    alg: { so12: 'T > 0: l’algebra tangente del tubo è so(1,2)', iso2: 'T = 0: iso(2), il caso nullo (K1 e K2 commutano)', so3: 'T < 0: so(3)' },
    lab: { xi: 'ξ = ∂ᵥ', n: 'n = dx', surface: 'x = const', axes: 'orizzontale v · verticale x', tbit: 'bit del tempo (T)', cube: 'cubo 3D: K1 = 3, K2 = 5, J = 6', w: 'w', img: 'w′', off: 'w′ (fuori dal foglio)', none: 'nessuna immagine: n·n = 0' },
    caps: {
      clifford: 'Grigio: i coni di luce lungo x, con T(x) tracciata a sinistra. Colore: il cono nella superficie di prova. La superficie x = const è la retta orizzontale; ξ = ∂_v corre lungo di essa e n = dx punta di traverso. Quando T scende a 0 il secondo bordo del cono si posa sulla superficie: ξ è nullo, e la superficie è un fotone fermo. L’inclinazione è disegnata con una propria scala verticale per ogni orizzonte (il |T| più grande nella finestra inclina il bordo di 45°), quindi confronta le forme dentro un orizzonte, non tra orizzonti.',
      cube: 'Il tubo r = const ha algebra tangente Cl(T, −1, −1): il bit 0 è il bit del tempo (quadrato T), i bit 1 e 2 generano la sfera. Gli angoli pari 3, 5, 6 del cubo 3D sono K1, K2 e J, e i tre spigoli tra loro sono i loro commutatori. [J, K1] = 2 K2 e [J, K2] = −2 K1 non dipendono da T; [K1, K2] = −2T J sbiadisce con T e si annulla a T = 0 (tratteggiato): so(1,2) diventa iso(2), poi so(3) per T < 0.',
      mirror: 'Uno specchio nel covettore n manda w in w − 2 (n·w)/(n·n) n♯. Con n = dx, n·n = −T: la componente x di w cambia segno e la componente v diventa w^v + 2 w^x/T. Porta la superficie di prova verso l’orizzonte: l’immagine scappa all’infinito, e a T = 0 non c’è. Un piano nullo non è uno specchio, perché un vettore nullo non ha inverso.' },
  },
  neck: {
    r: 'Raggio r (Schwarzschild r_S = 1; raggio della gola di Ellis = 1)',
    aria: 'Schwarzschild ed Ellis a confronto: la norma della normale e g^rr, i due spaziotempi in coordinate nulle, e i tassi lungo un fotone entrante',
    schw: 'Schwarzschild', ellis: 'Wormhole di Ellis', kruskal: 'Schwarzschild: Kruskal (X, T)', ellisChart: 'Ellis: (ℓ, t)',
    lab: { n2: '|n·n|, norma della normale', grr: '|gʳʳ|', null: 'r = 1: orizzonte (nulla), gola (tipo tempo)', photon: 'un fotone che l’attraversa', live: 'la fetta al r scelto', dr: 'dr/dv lungo un fotone entrante', dl: 'dℓ/dv, lunghezza propria' },
    caps: {
      clifford: 'Linea piena: |n·n|, la norma della normale. Tratteggiata: |g^rr|. In Schwarzschild sono un’unica curva (T R = 1), quindi g^rr = 0 sembra l’orizzonte. Nel wormhole di Ellis n·n = −1 fino in fondo mentre g^rr va a 0 alla gola: r è stazionario lungo la fetta, una strozzatura, ma la superficie r = 1 è di tipo tempo.',
      null: 'Gli stessi due spaziotempi in coordinate nulle. Schwarzschild in Kruskal (X, T): l’orizzonte r = 1 è la coppia nulla X = ±T, e un fotone lo attraversa. Ellis in (ℓ, t): la gola ℓ = 0 è una retta verticale, di tipo tempo, e anche qui un fotone la attraversa. Ambra: la fetta al tuo r (X² − T² = (r − 1) e^r in Kruskal, ℓ = ±√(r² − 1) in Ellis).',
      flow: 'Lungo un fotone entrante, quanto in fretta cambiano r e la lunghezza propria ℓ per unità di v? All’orizzonte di Schwarzschild vanno entrambi a 0: il fotone sta fermo. Alla gola di Ellis dr/dv va a 0 ma dℓ/dv = ½: r è stazionario e il fotone continua a muoversi.' },
  },
  crit: {
    caseH: 'Quale superficie', probe: 'Distanza x dalla superficie (scala logaritmica)',
    aria: 'L’Eq. (1) contro la distanza dalla superficie, in scala log-log, per tre superfici nulle',
    cases: { simple: 'T = x (zero semplice)', extremal: 'T = x² (estremale)', eq18: 'Eq. (18): T = (3x)^{1/3}' },
    lab: { x: 'distanza x dalla superficie (scala log)', y: '|Eq. (1)| (scala log)' },
    caps: {
      simple: 'Zero semplice: dT/dx = 1 e Eq. (1) = x, che va a 0 con x. Il criterio funziona: la superficie è nulla e l’Eq. (1) si annulla su di essa.',
      extremal: 'Estremale: dT/dx = 2x, Eq. (1) = 4x⁴, che va a 0 ancora più in fretta. La superficie è nulla e l’Eq. (1) si annulla, ma ∇g_tt = 0 su di essa, quindi g_tt = 0 non è un insieme di livello regolare e la derivazione non vale così com’è.',
      eq18: 'Eq. (18): dT/dx = (3x)^{−2/3} diverge, F = −(dT/dx)²/2 è infinito, e l’Eq. (1) = 1/(3x) cresce mentre n·n = −T → 0. La superficie è nulla; l’Eq. (1) fallisce. La condizione è che dT/dx resti finita.' },
  },
  kerr: {
    theta: 'Angolo polare θ del punto sull’ergosuperficie', aria: 'Piano meridiano di Kerr con l’orizzonte e l’ergosuperficie',
    lab: { axis: 'asse di rotazione', horizon: 'orizzonte r₊ = 9 (nulla)', ergo: 'ergosuperficie gₜₜ = 0 (non nulla)' },
    pole: 'zero: al polo l’ergosuperficie tocca l’orizzonte', timelike: 'negativo: una superficie di tipo tempo, non nulla',
    cap: 'Kerr con M = 5 e a = 3 nel piano meridiano (coordinate oblate). Blu: l’orizzonte r₊ = 9, dove Δ = 0 e la superficie è nulla. Ambra: l’ergosuperficie g_tt = 0, fuori dall’orizzonte e a contatto con esso ai poli. La sua normale ha n·n < 0 ovunque altrove, quindi g_tt = 0 delimita la regione dove ∂_t è di tipo tempo ma non è la superficie nulla. Sette valori di n·n sono esatti nello script.',
  },
  ladder: {
    nH: 'Dimensione n dello spaziotempo', aria: 'L’algebra di un’ipersuperficie nulla: la cella, l’algebra dell’orizzonte, il suo ideale J e il quoziente',
    lab: {
      cell: 'La cella', matrices: nq => `matrici 2×2 su ${nq}`, horizon: 'L’algebra dell’orizzonte', quot: 'quoziente', std: 'dai manuali',
      cols: 'colonne: grado · ambra: per il bit nullo (l’ideale J) · verde: il quoziente',
      simplex: m => `${m} generatori come vertici di un simplesso: ℓ (nullo) e ${m - 1} per la sfera`,
      starCount: a => `facce che contengono ℓ, per numero di vertici: ${a.join(' + ')} = ${sum(a)}`,
      pCell: 'la cella', pHor: 'l’algebra dell’orizzonte', pJ: 'l’ideale J',
      odd: 'Compare solo il primo 2. Ogni generatore è un fattore 2; l’orizzonte ne toglie uno, e J fissa il bit nullo.',
      pick: (J, N) => `${J} dei ${N} angoli passano per il bit nullo: una faccetta del cubo, l’ideale J. Clicca un angolo.`,
      vertex: (name, bits, inJ) => `Blade ${name}, etichetta ${bits}: ${inJ ? 'passa per il bit nullo, quindi sta in J e il suo prodotto con qualsiasi blade di J è 0' : 'non passa per il bit nullo, quindi sta nel quoziente'}`,
      faces: (J, m) => `La stella del vertice nullo ha ${J} = 2^{${m - 1}} facce, contando il vertice stesso: lo stesso numero dei blade di J.`,
      allPow2: 'La cella, l’algebra dell’orizzonte e J hanno dimensioni 2^n, 2^{n−1} e 2^{n−2}: solo potenze di 2. Il bit nullo cambia il prodotto, non il conteggio.',
    },
    caps: {
      clifford: 'A sinistra: la cella Cl(1, n−1) è fatta di matrici 2×2 sull’algebra della sezione Cl(0, n−2), la regola standard Cl(p+1, q+1) = M₂(Cl(p, q)). A destra: l’algebra dell’orizzonte Cl(0, n−2, 1) ha metà della dimensione della cella e due parti, l’ideale J (tutto ciò che passa per il bit nullo, con J·J = 0) e il quoziente, ciascuno di dimensione 2^{n−2}.',
      cube: 'I blade dell’algebra dell’orizzonte come angoli di un cubo (n−1)-dimensionale, in colonne per grado. Gli angoli ambra, tutti per il bit nullo, sono una faccetta: metà del cubo, e tra loro si moltiplicano a 0. Gli angoli verdi si moltiplicano come l’algebra della sezione. In una base ortonormale l’orizzonte non è una faccia del cubo: la faccetta appartiene alla base nulla (nostra lettura).',
      simplex: 'Gli stessi blade come facce di un simplesso i cui vertici sono i generatori ℓ, e1, …; la faccia vuota è lo scalare. L’ideale J è la stella del vertice nullo: ogni faccia che lo contiene (gli spigoli ambra e tutto ciò che generano).',
      prime: 'Gli stessi tre conteggi come fattori 2: 2^n per la cella, 2^{n−1} per l’algebra dell’orizzonte, 2^{n−2} per J. Non c’è nessun primo dispari.' },
  },
  limitsH: 'Che cosa questo passo non copre',
  limits: [
    ['open', 'L’Eq. (12) dell’articolo non è ricostruita qui.'],
    ['open', 'Dei riferimenti sono stati letti solo l’Appendice B di Vishveshwara e l’abstract di Vollick, quindi una lettura segnata “nostra” potrebbe essere già nota.'],
    ['open', 'Un solo autore ha scritto sia le affermazioni sia i controlli. Un secondo lettore non li ha ancora ripercorsi.'],
  ],
  linksH: 'Collegamenti con il resto dell’atlante',
  links: [
    [['checked', 'ours'], `Passo ${P9}: le direzioni nulle sono un piano`, 'Le direzioni nulle di Cl(1,3) formano il piano P(x) = o + x − ½x² ε del passo proiettivo, la sfera celeste, e il generatore ε dell’orizzonte ne è il punto all’infinito. Tutti i 96 vettori nulli interi non nulli con componenti fino a 4 sono un multiplo di qualche P(x) o di ε (controllato).'],
    [['checked'], `Passo ${P8}: un piano nullo non è uno specchio`, 'Un vettore nullo non ha inverso, quindi un iperpiano nullo non dà una riflessione: la lente dello specchio della figura 1 mostra l’immagine che scappa quando T → 0.'],
    [['checked'], 'Maxwell e Dirac: i covettori nulli portano i fronti d’onda', 'Il simbolo principale di ∇F = J, e quello dell’equazione di Dirac, ha un nucleo bidimensionale sui bivettori esattamente per un covettore nullo n. Le superfici nulle sono le superfici che possono portare un fronte d’onda.'],
    [['checked', 'ours'], 'Stessi nomi, elementi diversi', 'Tre tipi di ℍ e tre di ℂ stanno in queste algebre, con etichette di bit, gradi e ruoli diversi. L’algebra tangente della sfera è {0,1,2,3}, i quaternioni rotori di ℝ³ sono {0,3,5,6}, e un ideale di Cl(0,3) è il terzo (controllato). Un nome che porta le etichette, ℍ[0,1,2,3] e ℍ[0,3,5,6], non inganna (nostro).'],
  ],
  dl: { h: 'Verificalo tu', text: 'null_selfcheck.py ricalcola ogni numero di questa pagina con frazioni esatte (solo libreria standard). Stampa PASS o FAIL per ogni controllo ed elenca le due letture che non calcola. null.json è il dato che questa pagina legge.', py: 'Scarica null_selfcheck.py', json: 'Scarica null.json', cmd: 'python3 null_selfcheck.py   ·   python3 null_selfcheck.py --compare null.json' },
};

export default { en, it };
