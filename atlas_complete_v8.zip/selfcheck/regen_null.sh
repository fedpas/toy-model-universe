#!/bin/sh
# rebuild null.json (exact) and the two modules the page imports from it
cd /home/claude/out/selfcheck && python3 null_selfcheck.py --write null.json | tail -2 && python3 null_selfcheck.py --compare null.json | tail -1
cd /home/claude/out && python3 - <<'PY'
import json
d=json.load(open('selfcheck/null.json'))
open('nullData.js','w').write('export default '+json.dumps(d,ensure_ascii=False,separators=(',',':'))+'\n')
open('nullSelfcheckSource.js','w').write('export const NULL_PY = '+json.dumps(open('selfcheck/null_selfcheck.py').read(),ensure_ascii=False)+';\n')
PY
mkdir -p /home/claude/ui/selfcheck && cp selfcheck/null* /home/claude/ui/selfcheck/
