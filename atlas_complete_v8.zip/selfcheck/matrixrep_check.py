#!/usr/bin/env python3
"""The matrix route for the bit-rule Clifford product, checked exactly (standard library only, integers, no floating point).

Question behind it: does a product get slower as the dimension n grows, or does reaching n = 8 give a new base unit, M16(R), the way M16(R) sits over R?
The bit rule: blades e_a, a an n-bit label, e_a e_b = s(a,b) e_(a xor b), with e_i^2 = +1 for even i and -1 for odd i (the neutral signature (k,k) when n = 2k).
A dense product of two multivectors then adds up 4^n terms. Three facts are checked here, none of them assumed.

  1. Cl(k,k) = M_(2^k)(R).  An explicit representation by signed permutation matrices (a Jordan-Wigner string of sigma_z, one sigma_x and one epsilon = [[0,1],[-1,0]] per pair of
     generators) is built and checked for n = 2, 4, 6, 8, 10:  P_a P_b = s(a,b) P_(a xor b) for every pair of blades (all pairs up to n = 8, a seeded sample of 20000 pairs at n = 10),
     tr(P_a^T P_b) = 2^k [a = b] (the 2^n matrices are independent, so the map is onto the 2^k x 2^k real matrices), and random integer multivectors multiplied by the bit rule and by
     the matrix route give the same product.  The way in and out is a butterfly on each site (i, z, x, e -> i+z, x+e, x-e, i-z) that costs k 4^k additions, not 8^k.
     Cost: 4^n = 16^k terms for the bit rule against (2^k)^3 = 8^k multiplications for a matrix product: a gain of 2^k = 2^(n/2).
  2. Period 8.  Cl(N+8) = M16(Cl(N)): the generator e_j (j < N) goes to e_j (x) Gamma, the 8 new generators go to 1 (x) gamma_t, where gamma_t are the 8 real 16 x 16 matrices of Cl(4,4)
     (or its sign-shifted twin when N is odd) and Gamma is the product of all eight (Gamma^2 = +1, Gamma anticommutes with every gamma_t).  The relations of Cl(N+8) hold exactly,
     the 2^(N+8) images are independent and the dimensions agree, so it is an isomorphism, for N = 0, 1, 2, 3 (whichever of R, C, H, ... the base is).  A product in Cl(N+8) is then a 16 x 16
     matrix product with entries in Cl(N): 16^3 = 4096 products in Cl(N) instead of 4^8 = 65536 times as many terms: sixteen times fewer.  Counted, and equal to the bit-rule product.
  3. The plane-based algebra R(n,0,1) (e_0^2 = 0) is not a matrix algebra itself, but a motor M = R + e_0 T (R even and T odd in the Euclidean part) multiplies as
     (R1 + e_0 T1)(R2 + e_0 T2) = R1 R2 + e_0 (R1 T2 + T1 R2): three products in the Euclidean Cl(n), where the matrix route applies (Cl(8,0) = M16(R) at n = 8).  Checked for n = 2..5.
What this does not say: it is a count of operations and an exact identity, not a speed.  The timing is a separate, measured thing (the standalone benchmark and benchKernels.js).
  python3 matrixrep_check.py            run;     python3 matrixrep_check.py --write matrixrep.json"""
import json, sys, random

def pc(x): return bin(x).count('1')
ODD = int('10' * 16, 2)                                   # bits 1, 3, 5, ... : the generators that square to -1

def sgn_blades(a, b, g=None):                             # e_a e_b = sgn * e_(a^b); reorder sign by inversions, metric sign by the shared generators
    s, t = 0, a >> 1
    while t: s += pc(t & b); t >>= 1
    c = a & b
    s += pc(c & ODD) if g is None else sum(1 for i in range(c.bit_length()) if (c >> i & 1) and g[i] < 0)
    return -1 if s & 1 else 1

def bit_product(x, y, n):                                 # dense product of two coefficient lists, 4^n terms
    N = 1 << n; out = [0] * N
    for a in range(N):
        xa = x[a]
        if xa == 0: continue
        for b in range(N): out[a ^ b] += sgn_blades(a, b) * xa * y[b]
    return out

# ---------------------------------------------------------------- monomial (signed permutation) matrices: col[r], val[r]
def mono_mul(A, B):
    (ca, va), (cb, vb) = A, B
    return ([cb[ca[r]] for r in range(len(ca))], [va[r] * vb[ca[r]] for r in range(len(ca))])
def mono_eye(m): return (list(range(m)), [1] * m)
def jw_gens(k, shifted=False):                            # 2k real 2^k x 2^k signed permutation matrices, squares +1,-1,+1,-1,... (or -1,+1,... when shifted)
    m = 1 << k; G = []
    for j in range(k):
        low = (1 << j) - 1
        X = ([r ^ (1 << j) for r in range(m)], [(-1) ** pc(r & low) for r in range(m)])                          # Z...Z X I...I   (squares +1)
        E = ([r ^ (1 << j) for r in range(m)], [(-1) ** pc(r & low) * (1 if not (r >> j & 1) else -1) for r in range(m)])   # Z...Z eps I...I (squares -1)
        G += [E, X] if shifted else [X, E]
    return G
def blade_mono(G, mask, m):
    P = mono_eye(m)
    for i in range(len(G)):
        if mask >> i & 1: P = mono_mul(P, G[i])
    return P
def mono_is_scalar(P, s):                                 # P = s * identity
    return P[0] == list(range(len(P[0]))) and all(v == s for v in P[1])

# ---------------------------------------------------------------- 1. Cl(k,k) = M_(2^k)(R)
def check_neutral(k, rng, sample_pairs):
    n, m = 2 * k, 1 << k; G = jw_gens(k); NB = 1 << n
    for i in range(n):                                    # generators: squares and anticommutation
        assert mono_is_scalar(mono_mul(G[i], G[i]), 1 if i % 2 == 0 else -1)
        for j in range(i):
            ab, ba = mono_mul(G[i], G[j]), mono_mul(G[j], G[i])
            assert ab[0] == ba[0] and all(u == -v for u, v in zip(ab[1], ba[1]))
    P = [blade_mono(G, b, m) for b in range(NB)]
    exhaustive = sample_pairs is None
    pairs = [(a, b) for a in range(NB) for b in range(NB)] if exhaustive else [(rng.randrange(NB), rng.randrange(NB)) for _ in range(sample_pairs)]
    for a, b in pairs:                                    # the homomorphism on every pair of blades
        C = mono_mul(P[a], P[b]); T = P[a ^ b]; s = sgn_blades(a, b)
        assert C[0] == T[0] and all(u == s * v for u, v in zip(C[1], T[1])), (n, a, b)
    # independence: tr(P_a^T P_b) = m [a = b]
    def inner(A, B): return sum(A[1][r] * B[1][r] for r in range(m) if A[0][r] == B[0][r])
    gram_pairs = [(a, b) for a in range(NB) for b in range(a, NB)] if exhaustive else [(a, a) for a in range(NB)] + [(rng.randrange(NB), rng.randrange(NB)) for _ in range(sample_pairs)]
    for a, b in gram_pairs: assert inner(P[a], P[b]) == (m if a == b else 0), (n, a, b)
    # a generic element: to a matrix by the blades (direct), by the butterfly (fast), and back
    def to_matrix_direct(x):
        M = [[0] * m for _ in range(m)]
        for b in range(NB):
            if x[b]:
                for r in range(m): M[r][P[b][0][r]] += x[b] * P[b][1][r]
        return M
    # Pauli address and sign of every blade: the blade is  sign * (tensor product over sites of one of I, Z, X, eps)
    I2, Z2, X2, E2 = ((1, 0), (0, 1)), ((1, 0), (0, -1)), ((0, 1), (1, 0)), ((0, 1), (-1, 0))
    def m2mul(A, B): return tuple(tuple(sum(A[i][t] * B[t][j] for t in range(2)) for j in range(2)) for i in range(2))
    def m2find(A):
        for idx, B in enumerate((I2, Z2, X2, E2)):
            if A == B: return idx, 1
            if A == tuple(tuple(-v for v in row) for row in B): return idx, -1
        raise AssertionError(A)
    addr, sign = [0] * NB, [1] * NB
    for b in range(NB):
        ops = [I2] * k                                    # build the tensor factors of the product, in increasing generator order
        sg = 1
        for g in range(n):
            if b >> g & 1:
                j = g // 2; new = list(ops)
                for s_ in range(j): new[s_] = m2mul(ops[s_], Z2)          # the string Z on the sites below j
                new[j] = m2mul(ops[j], X2 if g % 2 == 0 else E2)
                ops = new
        a = 0
        for j in range(k):
            idx, s_ = m2find(ops[j]); a |= idx << (2 * j); sg *= s_
        addr[b], sign[b] = a, sg
    assert len(set(addr)) == NB, 'the blades are not a bijection onto the 4^k Pauli addresses'
    def to_matrix_fast(x):                                # signed permutation, then k butterflies
        v = [0] * NB
        for b in range(NB): v[addr[b]] = sign[b] * x[b]
        for j in range(k):
            sh = 2 * j
            for base in range(NB):
                if (base >> sh) & 3: continue
                i_, z_, x_, e_ = v[base], v[base | 1 << sh], v[base | 2 << sh], v[base | 3 << sh]
                v[base], v[base | 1 << sh], v[base | 2 << sh], v[base | 3 << sh] = i_ + z_, x_ + e_, x_ - e_, i_ - z_      # slots: 00, 01, 10, 11 of (row bit, column bit)
        M = [[0] * m for _ in range(m)]
        for a in range(NB):
            r = c = 0
            for j in range(k): d = a >> (2 * j) & 3; r |= (d >> 1) << j; c |= (d & 1) << j
            M[r][c] = v[a]
        return M
    def from_matrix_fast(M):
        v = [0] * NB
        for a in range(NB):
            r = c = 0
            for j in range(k): d = a >> (2 * j) & 3; r |= (d >> 1) << j; c |= (d & 1) << j
            v[a] = M[r][c]
        for j in range(k):
            sh = 2 * j
            for base in range(NB):
                if (base >> sh) & 3: continue
                m00, m01, m10, m11 = v[base], v[base | 1 << sh], v[base | 2 << sh], v[base | 3 << sh]
                v[base], v[base | 1 << sh], v[base | 2 << sh], v[base | 3 << sh] = m00 + m11, m00 - m11, m01 + m10, m01 - m10   # 2i, 2z, 2x, 2e
        out = [0] * NB
        for b in range(NB):
            t = sign[b] * v[addr[b]]; assert t % (1 << k) == 0; out[b] = t >> k
        return out
    def matmul(A, B): return [[sum(A[r][t] * B[t][c] for t in range(m)) for c in range(m)] for r in range(m)]
    trials = 3 if n <= 8 else 1
    fixtures = None
    for t in range(trials):
        x = [rng.randint(-9, 9) for _ in range(NB)]; y = [rng.randint(-9, 9) for _ in range(NB)]
        if n <= 8: assert to_matrix_direct(x) == to_matrix_fast(x), 'the butterfly disagrees with the sum of blade matrices'
        Mx, My = to_matrix_fast(x), to_matrix_fast(y)
        via_matrix = from_matrix_fast(matmul(Mx, My))
        ref = bit_product(x, y, n)
        assert via_matrix == ref, ('the matrix route and the bit rule disagree', n)
        assert from_matrix_fast(Mx) == x
        if t == 0 and n <= 10: fixtures = {'x': x, 'y': y, 'xy': ref}
    return {'n': n, 'k': k, 'size': m, 'blades': NB, 'pairs_checked': len(pairs), 'pairs_exhaustive': exhaustive, 'gram_exhaustive': exhaustive,
            'dense_terms_bit_rule': 4 ** n, 'multiplications_matmul': m ** 3, 'gain': 4 ** n // m ** 3, 'butterfly_additions_per_conversion': k * NB,
            'random_products_equal': trials}, fixtures

# ---------------------------------------------------------------- 2. period 8: Cl(N+8) = M16(Cl(N))
def check_period8(N, rng, twist=True):
    n = N + 8; NB = 1 << n; M = 16
    gsq = [1 if i % 2 == 0 else -1 for i in range(n)]
    Gm = jw_gens(4, shifted=(N % 2 == 1))                  # the 8 new generators as 16 x 16 signed permutations: squares gsq[N..N+7]
    for t in range(8): assert mono_is_scalar(mono_mul(Gm[t], Gm[t]), gsq[N + t])
    for t in range(8):
        for u in range(t):
            ab, ba = mono_mul(Gm[t], Gm[u]), mono_mul(Gm[u], Gm[t]); assert ab[0] == ba[0] and all(p == -q for p, q in zip(ab[1], ba[1]))
    Gam = mono_eye(M)
    for t in range(8): Gam = mono_mul(Gam, Gm[t])
    assert Gam[0] == list(range(M)), 'Gamma is diagonal'
    assert mono_is_scalar(mono_mul(Gam, Gam), 1), 'Gamma^2 = +1'
    for t in range(8):
        a, b = mono_mul(Gam, Gm[t]), mono_mul(Gm[t], Gam); assert a[0] == b[0] and all(p == -q for p, q in zip(a[1], b[1])), 'Gamma anticommutes with each new generator'
    # elements of M16(Cl(N)): dict (r, c) -> dict blade -> int
    def eadd(X, Y):
        Z = {k: dict(v) for k, v in X.items()}
        for key, mv in Y.items():
            d = Z.setdefault(key, {})
            for b, c in mv.items():
                d[b] = d.get(b, 0) + c
                if d[b] == 0: del d[b]
            if not d: del Z[key]
        return Z
    products = [0]                                         # the number of Cl(N) products used
    def clmul(u, v):                                       # product in Cl(N) of two sparse multivectors (dict blade -> int)
        out = {}
        for a, ca in u.items():
            for b, cb in v.items():
                s = sgn_blades(a, b); out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
        return {b: c for b, c in out.items() if c}
    def mmul(X, Y):                                        # the 16 x 16 block product: 16^3 Cl(N) products, every one counted (zero blocks too)
        Z = {}
        for r in range(M):
            for d in range(M):
                acc = {}
                for c in range(M):
                    products[0] += 1
                    u, v = X.get((r, c)), Y.get((c, d))
                    if u and v:
                        for b, cf in clmul(u, v).items(): acc[b] = acc.get(b, 0) + cf
                acc = {b: c for b, c in acc.items() if c}
                if acc: Z[(r, d)] = acc
        return Z
    def mono_elem(P, blade):                               # P (x) e_blade
        return {(r, P[0][r]): {blade: P[1][r]} for r in range(M)}
    def gen_image(g):
        if g < N: return mono_elem(Gam if twist else mono_eye(M), 1 << g)            # e_g (x) Gamma   (without the Gamma, e_g would commute with the new generators)
        return mono_elem(Gm[g - N], 0)                     # 1 (x) gamma_t
    # relations on the generators, with the block product (cheap, a few matrix products)
    sc = lambda s: {(r, r): {0: s} for r in range(M)}
    imgs = [gen_image(g) for g in range(n)]
    products_before = products[0]
    holds = True
    for g in range(n):
        holds = holds and mmul(imgs[g], imgs[g]) == sc(gsq[g])
        for h in range(g):
            ab, ba = mmul(imgs[g], imgs[h]), mmul(imgs[h], imgs[g])
            holds = holds and eadd(ab, ba) == {}
    if not twist: return {'relations_hold': holds}
    assert holds, ('the relations of Cl(N+8) fail on the images', N)
    rel_products = products[0] - products_before
    # the images of the 2^(N+8) blades are independent: blade (S, T) goes to  +- e_S (x) (Gamma^|S| gamma_T), supports in different S are disjoint, and for each S the 256 patterns are orthogonal
    for parity in (0, 1):
        pats = []
        for T in range(256):
            P = blade_mono(Gm, T, M)
            if parity: P = mono_mul(Gam, P)
            pats.append(P)
        for a in range(256):
            for b in range(a, 256):
                ip = sum(pats[a][1][r] * pats[b][1][r] for r in range(M) if pats[a][0][r] == pats[b][0][r])
                assert ip == (M if a == b else 0), ('images not independent', N, parity, a, b)
    assert M * M * (1 << N) == NB                          # the dimensions agree
    # a random dense product: sent in, multiplied as 16 x 16 blocks, sent out; equal to the bit rule
    def image_of_blade(b):
        S, T = b & ((1 << N) - 1), b >> N
        P = blade_mono(Gm, T, M)
        if pc(S) & 1: P = mono_mul(Gam, P)
        # blade e_S e_T = (product of the e_j (x) Gamma over j in S) (1 (x) gamma_T) = e_S (x) Gamma^|S| gamma_T, with e_S the ordered product in Cl(N)
        return {(r, P[0][r]): {S: P[1][r]} for r in range(M)}
    def to_blocks(x):
        out = {}
        for b in range(NB):
            if x[b]: out = eadd(out, {key: {s: c * x[b] for s, c in mv.items()} for key, mv in image_of_blade(b).items()})
        return out
    def from_blocks(Xb):
        x = [0] * NB
        for b in range(NB):                                # coefficient of blade b: the entries of the image of b, matched (the images are orthogonal)
            im = image_of_blade(b); tot = 0
            for key, mv in im.items():
                for s, c in mv.items(): tot += c * Xb.get(key, {}).get(s, 0)
            assert tot % M == 0; x[b] = tot // M
        return x
    xs = [rng.randint(-5, 5) if rng.random() < 0.5 else 0 for _ in range(NB)] if n >= 10 else [rng.randint(-5, 5) for _ in range(NB)]
    ys = [rng.randint(-5, 5) if rng.random() < 0.5 else 0 for _ in range(NB)] if n >= 10 else [rng.randint(-5, 5) for _ in range(NB)]
    Xb, Yb = to_blocks(xs), to_blocks(ys)
    products[0] = 0
    Zb = mmul(Xb, Yb)
    used = products[0]
    got = from_blocks(Zb)
    assert got == bit_product(xs, ys, n), ('the block product and the bit rule disagree', N)
    assert used == 4096
    return {'N': N, 'n': n, 'base': 'Cl(%d,%d)' % ((N + 1) // 2, N // 2), 'blocks': M, 'relations_hold': True, 'images_independent': True, 'dimension': NB,
            'cl_n_products_per_product': used, 'bit_rule_terms_in_cl_n_plus_8': 4 ** n, 'bit_rule_terms_per_cl_n_product': 4 ** N, 'operation_ratio': (4 ** n) // (used * 4 ** N), 'random_product_equal': True}

# ---------------------------------------------------------------- 3. the motor of R(n,0,1) as three products in the Euclidean Cl(n)
def check_pga(n, rng, wrong=False):
    # generators 0..n: bit 0 is the null e_0 (square 0), bits 1..n the Euclidean e_1..e_n (square +1)
    def sg(a, b):
        s, t = 0, a >> 1
        while t: s += pc(t & b); t >>= 1
        return -1 if s & 1 else 1
    def mul_pga(x, y):                                      # x, y: dict label -> coeff, label bit 0 = e_0
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                if (a & b) & 1: continue                    # e_0^2 = 0
                out[a ^ b] = out.get(a ^ b, 0) + sg(a, b) * ca * cb
        return {k: v for k, v in out.items() if v}
    def mul_euc(x, y):                                      # Euclidean Cl(n) on labels of n bits (bit i is e_(i+1))
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                out[a ^ b] = out.get(a ^ b, 0) + sg(a << 1, b << 1) * ca * cb
        return {k: v for k, v in out.items() if v}
    ev = [l for l in range(1 << (n + 1)) if pc(l) % 2 == 0]
    def motor(): return {l: rng.randint(-6, 6) for l in ev if rng.random() < 0.8}
    ok = 0
    for _ in range(6):
        M1, M2 = motor(), motor(); ref = mul_pga(M1, M2)
        split = lambda M: ({l >> 1: c for l, c in M.items() if not l & 1}, {l >> 1: c for l, c in M.items() if l & 1})      # R: no e_0 (even in Cl(n)); T: with e_0 (odd in Cl(n))
        R1, T1 = split(M1); R2, T2 = split(M2)
        assert all(pc(l) % 2 == 0 for l in R1) and all(pc(l) % 2 == 1 for l in T1)
        RR = mul_euc(R1, R2); RT = mul_euc(R1, T2); TR = {} if wrong else mul_euc(T1, R2)
        got = {l << 1: c for l, c in RR.items()}
        for l, c in list(RT.items()) + list(TR.items()):
            # e_0 (R1 T2 + T1 R2): e_0 e_S = e_(0 + S) with e_0 first, so no extra sign
            got[(l << 1) | 1] = got.get((l << 1) | 1, 0) + c
        got = {k: v for k, v in got.items() if v}
        if wrong: return got == ref
        assert got == ref, ('motor product is not R1R2 + e0(R1T2 + T1R2)', n)
        ok += 1
    half = 1 << (n - 1)
    return {'n': n, 'motor_coefficients': 1 << n, 'dense_terms_motor_product': 4 ** n, 'products_in_euclidean_cl_n': 3, 'terms_in_those_products': 3 * half * half, 'random_motor_products_equal': ok}

def controls(rng):
    res = {}
    G = jw_gens(2); G[1] = G[0]                             # a generator that should square to -1 replaced by one that squares to +1
    res['a generator with the wrong square is caught'] = not mono_is_scalar(mono_mul(G[1], G[1]), -1)
    res['Cl(N+8) without the chirality Gamma: the relations fail'] = check_period8(1, rng, twist=False)['relations_hold'] is False
    res['motor product without the term T1 R2 is wrong'] = check_pga(3, rng, wrong=True) is False
    assert all(res.values()), res
    return res

def build():
    rng = random.Random(8)
    D = {'rep': [], 'period8': [], 'pga': [], 'fixtures': {}}
    for k in (1, 2, 3, 4, 5):
        row, fx = check_neutral(k, rng, None if 2 * k <= 8 else 20000)
        D['rep'].append(row)
        if fx and 2 * k <= 10: D['fixtures'][str(2 * k)] = fx
    for N in (0, 1, 2, 3): D['period8'].append(check_period8(N, rng))
    for n in (2, 3, 4, 5): D['pga'].append(check_pga(n, rng))
    D['negative_controls'] = controls(rng)
    D['counts'] = {'rep_sizes': [r['n'] for r in D['rep']], 'period8_bases': [r['base'] for r in D['period8']], 'pga_dims': [r['n'] for r in D['pga']]}
    D['gain_table'] = [{'n': 2 * k, 'bit_rule_terms': 16 ** k, 'matmul_mults': 8 ** k, 'gain': 2 ** k} for k in range(1, 9)]
    D['meaning'] = ('Cl(k,k) is the algebra of 2^k x 2^k real matrices, shown by an explicit signed-permutation representation; a dense product costs 16^k terms by the bit rule and 8^k multiplications by the matrix route (gain 2^k), '
                    'and Cl(N+8) is the 16 x 16 matrices over Cl(N), so a product is 4096 products in Cl(N) instead of 65536 times the work: the gain grows with n. Operation counts and exact identities only, not timings.')
    return D

if __name__ == '__main__':
    D = build()
    if '--write' in sys.argv: open(sys.argv[sys.argv.index('--write') + 1], 'w').write(json.dumps(D, indent=1, sort_keys=True))
    print('ALL MATRIX-ROUTE CHECKS PASS: Cl(k,k) = M_(2^k)(R) for n = %s; Cl(N+8) = M16(Cl(N)) for N = 0..3; motor product = 3 Euclidean products for n = 2..5' % ', '.join(str(r['n']) for r in D['rep']))
