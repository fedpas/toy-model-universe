#!/usr/bin/env python3
"""Self-check for the portal's "Maxwell with k time and d space dimensions" section.  Standard library only.
  python3 maxwell_selfcheck.py                      rebuild and assert every claim
  python3 maxwell_selfcheck.py --write out.json     also write the data the portal shows
  python3 maxwell_selfcheck.py --compare m.json     check the portal data equals the rebuilt data
Clifford algebra Cl(k,d), n = k+d generators: the k time generators square to +1, the d space generators to -1.
Blades are bitmasks (face S <-> blade e_S).  Fields are exact polynomials in the n coordinates, so every identity is exact.
The field equation is always  grad F = J  with F a bivector and J a vector; its grade-1 part is  delta F = J  and its grade-3 part is  dF = 0.
A charge in the field (the "charges" block, exact unless marked numeric): the Lorentz force is the grade-1 part of the product F u (the contraction half of the same move), checked against
the textbook force in 2, 3 and 4 space dimensions; the circle, the hyperbola, the drift frame, the invariants, E parallel to B, the field of a point charge and a light wave; then a
fourth-order Runge-Kutta run of the same table against the closed forms (cyclotron radius, hyperbolic motion, E x B drift, the wave's figure of eight, and the relativistic perihelion advance)."""
import sys, json, itertools, random, argparse
from fractions import Fraction as Fr
from math import comb

AX = ['t', 'x', 'y', 'z', 'w']
SPACE = ['x', 'y', 'z', 'w']
def grade(m): return bin(m).count('1')
def bprod(a, b, p=1):                       # generators 0..p-1 square to +1 (time), the rest to -1 (space)
    s = 1; t = a >> 1
    while t:
        s *= -1 if bin(t & b).count('1') % 2 else 1; t >>= 1
    c = a & b; i = 0
    while c:
        if c & 1: s *= 1 if i < p else -1
        c >>= 1; i += 1
    return a ^ b, s
# ---- exact polynomials in nv variables: {exponent tuple: Fraction}
def padd(P, Q):
    R = dict(P)
    for k, v in Q.items():
        R[k] = R.get(k, 0) + v
        if R[k] == 0: del R[k]
    return R
def pscale(P, c): return {k: v * c for k, v in P.items()} if c else {}
def pder(P, a):
    R = {}
    for k, v in P.items():
        if k[a]:
            kk = list(k); kk[a] -= 1; kk = tuple(kk); R[kk] = R.get(kk, 0) + v * k[a]
    return R
def prand(rng, nv):
    mons = [e for e in itertools.product(range(3), repeat=nv) if sum(e) <= 2]
    P = {e: Fr(rng.randint(-5, 5)) for e in mons if rng.random() < .6}
    P = {k: v for k, v in P.items() if v}
    return P or {tuple([0] * nv): Fr(1)}
def clean(P): return {k: v for k, v in P.items() if v}
def mv_add(A, B):
    R = dict(A)
    for m, P in B.items():
        R[m] = padd(R.get(m, {}), P)
        if not R[m]: del R[m]
    return R
def nabla(F, n, p):                          # grad F = sum_a e_a d_a F
    R = {}
    for m, P in F.items():
        for a in range(n):
            mm, s = bprod(1 << a, m, p); R = mv_add(R, {mm: pscale(pder(P, a), s)})
    return R

# =====================================================================================================
# The usual physical form (one time, d space): E_i, B_ij, rho, J_i with the textbook signs
# =====================================================================================================
def eps(i, j, k):
    return {(1, 2, 3): 1, (2, 3, 1): 1, (3, 1, 2): 1, (1, 3, 2): -1, (3, 2, 1): -1, (2, 1, 3): -1}.get((i, j, k), 0)
def bfields(d):
    """B_ij (i<j) and the blade e_i e_j that carries it.  d=2: B_z = B_12;  d=3: B_z = B_12, B_x = B_23, B_y = B_31 (= -B_13);  d=4: B_12 ... B_34."""
    if d == 2: return [('B_z', 1, 2)]
    if d == 3: return [('B_x', 2, 3), ('B_y', 3, 1), ('B_z', 1, 2)]
    return [(f'B_{i}{j}', i, j) for i in range(1, d + 1) for j in range(i + 1, d + 1)]
def Bij(d, i, j):
    for key, a, b in bfields(d):
        if (a, b) == (i, j): return 1, key
        if (a, b) == (j, i): return -1, key
def phys_standard(d):
    """Gauss: sum_i d_i E_i = rho;  Ampere_i: d_t E_i - sum_j d_j B_ij = -J_i;  Faraday: d_t B_ij + d_i E_j - d_j E_i = 0;  Bianchi: d_i B_jk + d_j B_ki + d_k B_ij = 0."""
    eqs = {1: {'id': 'gauss', 'name': 'Gauss', 'deriv': [(1, i, f'E_{AX[i]}') for i in range(1, d + 1)], 'src': (-1, 'rho')}}
    for i in range(1, d + 1):
        der = [(1, 0, f'E_{AX[i]}')]
        for j in range(1, d + 1):
            if j != i:
                sg, key = Bij(d, i, j); der.append((-sg, j, key))
        eqs[1 << i] = {'id': f'amp_{AX[i]}', 'name': f'Ampère {AX[i]}', 'deriv': der, 'src': (1, f'J_{AX[i]}')}
    for key, i, j in bfields(d):
        eqs[1 | (1 << i) | (1 << j)] = {'id': 'far_' + key[2:], 'name': 'Faraday ' + key[2:], 'src': None,
                                        'deriv': [(1, 0, key), (1, i, f'E_{AX[j]}'), (-1, j, f'E_{AX[i]}')]}
    for i, j, k in itertools.combinations(range(1, d + 1), 3):
        der = []
        for a, b, c in ((i, j, k), (j, k, i), (k, i, j)):
            sg, key = Bij(d, b, c); der.append((sg, a, key))
        eqs[(1 << i) | (1 << j) | (1 << k)] = {'id': 'divB' if d == 3 else f'bian_{i}{j}{k}', 'name': 'no monopole' if d == 3 else f'Bianchi {i}{j}{k}', 'deriv': der, 'src': None}
    return eqs
def phys_spec(d):
    n = d + 1
    Fmask = {f'E_{AX[i]}': 1 | (1 << i) for i in range(1, d + 1)}
    for key, i, j in bfields(d): Fmask[key] = (1 << i) | (1 << j)
    Jmask = {'rho': 1} | {f'J_{AX[i]}': 1 << i for i in range(1, d + 1)}
    show = lambda f: 'B' if (d == 2 and f == 'B_z') else f.replace('_', '')
    std = phys_standard(d)
    role = {0: ('scalar', '1'), (1 << n) - 1: ('pseudo', 'I'), 1: ('rho', 'ρ')}
    for f, m in Fmask.items(): role[m] = ('E' if f[0] == 'E' else 'B', show(f))
    for i in range(1, d + 1): role[1 << i] = ('J', f'J{AX[i]}')
    for m, e in std.items():
        if grade(m) == 3:
            role[m] = ('divB', '∇·B' if d == 3 else '∇B' + e['id'][5:]) if e['id'][:3] in ('div', 'bia') else ('Faraday', 'I' if n == 3 else 'Far' + e['id'][4:])
    return dict(k=1, d=d, n=n, axes=AX[:n], Fmask=Fmask, Jmask=Jmask, std=std, show=show, role=role, kind='physical')

# =====================================================================================================
# The covariant form, any signature:  delta F = J:  sum_a eta_a d_a F_ab = J_b ;   dF = 0:  d_a F_bc - d_b F_ac + d_c F_ab = 0
# =====================================================================================================
def cov_spec(k, d):
    n = k + d; times = ['t'] if k == 1 else [f't{i + 1}' for i in range(k)]; axes = times + SPACE[:d]; eta = [1] * k + [-1] * d
    def fname(a, b):
        if b < k: return f'T{a + 1}{b + 1}'
        if a < k: return f'E{SPACE[b - k]}' if k == 1 else f'E{a + 1}{SPACE[b - k]}'
        return f'B{SPACE[a - k]}{SPACE[b - k]}'
    pairs = sorted(itertools.combinations(range(n), 2), key=lambda ab: (0 if ab[0] < k <= ab[1] else 1 if ab[1] < k else 2, ab))
    Fmask = {fname(a, b): (1 << a) | (1 << b) for a, b in pairs}
    jn = lambda a: ('rho' if k == 1 else f'rho{a + 1}') if a < k else f'J{SPACE[a - k]}'
    Jmask = {jn(a): 1 << a for a in range(n)}
    std = {}
    for b in range(n):
        der = [((eta[a] if a < b else -eta[a]), a, fname(min(a, b), max(a, b))) for a in range(n) if a != b]
        std[1 << b] = {'id': ('gauss' if k == 1 else f'gauss_{b + 1}') if b < k else f'amp_{SPACE[b - k]}',
                       'name': ('Gauss' if k == 1 else f'Gauss {times[b]}') if b < k else f'Ampère {SPACE[b - k]}', 'deriv': der, 'src': (-1, jn(b))}
    for a, b, c in itertools.combinations(range(n), 3):
        nt = sum(1 for x in (a, b, c) if x < k); lab = ' '.join(axes[x] for x in (a, b, c))
        std[(1 << a) | (1 << b) | (1 << c)] = {'id': 'd_' + ''.join(axes[x] for x in (a, b, c)), 'src': None,
            'name': ('no monopole ' if nt == 0 else 'Faraday ' if nt == 1 else 'dF ') + lab,
            'deriv': [(1, a, fname(b, c)), (-1, b, fname(a, c)), (1, c, fname(a, b))]}
    role = {0: ('scalar', '1'), (1 << n) - 1: ('pseudo', 'I')}
    for a in range(n): role[1 << a] = ('rho', 'ρ' if k == 1 else f'ρ{a + 1}') if a < k else ('J', 'J' + SPACE[a - k])
    for (a, b) in pairs: role[(1 << a) | (1 << b)] = (('T' if b < k else 'E' if a < k else 'B'), fname(a, b))
    for m in std:
        if grade(m) == 3:
            idx = [x for x in range(n) if m >> x & 1]; nt = sum(1 for x in idx if x < k)
            role[m] = ('divB' if nt == 0 else 'Faraday', ('∇·B' if nt == 0 and (k, d) == (1, 3) else 'F' + ''.join(str(x + 1) if x < k else SPACE[x - k] for x in idx)))
    return dict(k=k, d=d, n=n, axes=axes, Fmask=Fmask, Jmask=Jmask, std=std, show=lambda f: f, role=role, kind='covariant')

SRC = {'rho': 'ρ', 'J_x': 'Jx', 'J_y': 'Jy', 'J_z': 'Jz', 'J_w': 'Jw'}
def srcname(s): return SRC.get(s, s.replace('rho', 'ρ'))
def eq_string(e, spec):
    s = ''
    for c, a, f in e['deriv']:
        s += (' + ' if c > 0 else ' − ') if s else ('' if c > 0 else '−')
        s += f'∂{spec["axes"][a]} {spec["show"](f)}'
    rhs = '0' if e['src'] is None else (srcname(e['src'][1]) if -e['src'][0] > 0 else '−' + srcname(e['src'][1]))
    return s + ' = ' + rhs

# =====================================================================================================
def find_conventions(spec, rng):
    """F = sum s_f f e_f, J = sum s_j j e_j.  The residual grad F - J is linear in the signs, so solve equation by equation (exactly) and join."""
    n, k, std, Fmask, Jmask = spec['n'], spec['k'], spec['std'], spec['Fmask'], spec['Jmask']
    fnames, snames = list(Fmask), list(Jmask); names = fnames + snames
    fields = lambda: {nm: prand(rng, n) for nm in names}
    tests = [fields() for _ in range(3)]
    def target(f):
        T = {}
        for m, e in std.items():
            P = {}
            for c, a, name in e['deriv']: P = padd(P, pscale(pder(f[name], a), c))
            if e['src']: P = padd(P, pscale(f[e['src'][1]], e['src'][0]))
            T[m] = P
        return T
    def unit(f, nm, idx):
        return nabla({Fmask[nm]: f[nm]}, n, k) if idx < len(fnames) else {Jmask[nm]: pscale(f[nm], -1)}
    C = [[unit(f, nm, i) for i, nm in enumerate(names)] for f in tests]; T = [target(f) for f in tests]
    for t in range(3):
        for u in C[t]: assert all(m in std or not clean(P) for m, P in u.items()), 'a component feeds a target outside the equations'
    partial = {}
    for m in std:
        inv = sorted({i for i in range(len(names)) if any(clean(C[t][i].get(m, {})) for t in range(3))})
        sols = []
        for vals in itertools.product([1, -1], repeat=len(inv)):
            for kk in (1, -1):
                ok = True
                for t in range(3):
                    R = {}
                    for idx, sv in zip(inv, vals): R = padd(R, pscale(C[t][idx].get(m, {}), sv))
                    if clean(R) != clean(pscale(T[t][m], kk)): ok = False; break
                if ok: sols.append((dict(zip(inv, vals)), kk))
        partial[m] = sols; assert sols, (spec['k'], spec['d'], std[m]['id'])
    matches = []
    def join(ms, assign, ks):
        if not ms:
            if len(assign) == len(names): matches.append({'signs': [assign[i] for i in range(len(names))], 'eqsign': dict(ks)})
            return
        for sol, kk in partial[ms[0]]:
            if all(assign.get(i, v) == v for i, v in sol.items()): join(ms[1:], {**assign, **sol}, {**ks, ms[0]: kk})
    join(sorted(std), {}, {})
    assert len(matches) == 2 and [-x for x in matches[0]['signs']] == matches[1]['signs'], f'(k,d)=({spec["k"]},{spec["d"]}): {len(matches)} conventions'
    return matches

TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']
def cell(p, q):
    n = p + q; ty = TYPES[(p - q) % 8]
    copies = 2 if ty in ('R2', 'H2') else 1; dd = {'R': 1, 'R2': 1, 'C': 2, 'H': 4, 'H2': 4}[ty]
    N2 = 2 ** n // (dd * copies); N = int(round(N2 ** .5)); assert N * N == N2
    return ty, N
def algebra(k, d):
    n = k + d; ty, N = cell(k, d); I = (1 << n) - 1; I2 = bprod(I, I, k)[1]
    central = all(bprod(I, 1 << a, k)[1] == bprod(1 << a, I, k)[1] for a in range(n))
    assert central == (n % 2 == 1) and I2 == (-1) ** (n * (n - 1) // 2) * (-1) ** d
    return {'type': ty, 'matrix_size': N, 'pseudoscalar_square': I2, 'pseudoscalar_central': central, 'splits_in_two': central and I2 == 1}
def symbol(k, d):
    cls = 'elliptic' if min(k, d) == 0 else 'hyperbolic' if min(k, d) == 1 else 'ultrahyperbolic'
    ev = None
    if cls == 'hyperbolic': ev = 'time' if k == 1 else 'space'          # the single odd-signed direction is the one a Cauchy problem can be posed along
    return {'plus': k, 'minus': d, 'class': cls, 'well_posed_along': ev}

def build_cell(spec, rng):
    k, d, n = spec['k'], spec['d'], spec['n']; D = {'k': k, 'd': d, 'n': n, 'axes': spec['axes'], 'kind': spec['kind']}
    Fmask, Jmask, std, role = spec['Fmask'], spec['Jmask'], spec['std'], spec['role']
    fnames, snames = list(Fmask), list(Jmask)
    assert len(Fmask) == comb(n, 2) and len(std) == n + comb(n, 3) and len(set(Fmask.values())) == len(Fmask)
    D['counts'] = {'E': sum(1 for m in Fmask.values() if m & ((1 << k) - 1) and m >> k), 'T': sum(1 for m in Fmask.values() if m >> k == 0),
                   'B': sum(1 for m in Fmask.values() if m & ((1 << k) - 1) == 0)}
    assert D['counts'] == {'E': k * d, 'T': comb(k, 2), 'B': comb(d, 2)}
    D['algebra'] = algebra(k, d); D['symbol'] = symbol(k, d)
    D['blades'] = [{'N': m, 'S': [a for a in range(n) if m >> a & 1], 'grade': grade(m), 'name': 'γ' + 'γ'.join(str(a) for a in range(n) if m >> a & 1) if m else '1',
                    'role': role.get(m, ('other', '·'))[0], 'label': role.get(m, ('other', '·'))[1], 'square': bprod(m, m, k)[1]} for m in range(1 << n)]
    matches = find_conventions(spec, random.Random(11 * n + 7 * k))
    vec = [m for m in std if grade(m) == 1]
    chosen = [m for m in matches if all(m['eqsign'][v] == 1 for v in vec)]
    assert len(chosen) == 1; sg = chosen[0]['signs']; sF = {Fmask[nm]: sg[i] for i, nm in enumerate(fnames)}
    if spec['kind'] == 'covariant': assert all(x == 1 for x in sg), 'in the covariant form F_ab e_a e_b and J_b e_b carry all-plus signs'
    D['conventions'] = {'found': len(matches), 'field_order': fnames + snames, 'signs': sg, 'grad': f'Σ γa ∂a, with {k} generator(s) squaring to +1 and {d} to −1',
                        'F': ' + '.join(('' if sF[Fmask[nm]] > 0 else '− ') + spec['show'](nm) + ' ' + D['blades'][Fmask[nm]]['name'] for nm in fnames).replace('+ −', '−'),
                        'J': ' + '.join(('' if sg[len(fnames) + i] > 0 else '− ') + srcname(nm) + ' ' + D['blades'][Jmask[nm]]['name'] for i, nm in enumerate(snames)).replace('+ −', '−')}
    inc = []
    for fname, src in Fmask.items():
        for a in range(n):
            mm, s = bprod(1 << a, src, k); assert mm == src ^ (1 << a)
            inc.append({'source': src, 'field': fname, 'axis': a, 'axis_name': spec['axes'][a], 'target': mm, 'op': 'contract' if grade(mm) == 1 else 'wedge',
                        'sign': s * sF[src], 'term': ('+' if s * sF[src] > 0 else '−') + '∂' + spec['axes'][a] + spec['show'](fname)})
    assert len(inc) == n * comb(n, 2) and all(grade(i['target']) == (1 if i['op'] == 'contract' else 3) for i in inc)
    for m, e in std.items():                                        # the algebra's terms into a target ARE the equation's derivative terms
        assert sorted((i['axis'], i['field']) for i in inc if i['target'] == m) == sorted((a, f) for c, a, f in e['deriv']), (k, d, e['id'])
        for c, a, f in e['deriv']:
            i = next(x for x in inc if x['target'] == m and x['axis'] == a and x['field'] == f)
            assert i['sign'] * chosen[0]['eqsign'][m] == c, (k, d, e['id'], f)
    D['incidences'] = inc
    D['equations'] = [{'id': e['id'], 'name': e['name'], 'target': m, 'eq': eq_string(e, spec), 'op': 'contract' if grade(m) == 1 else 'wedge',
                       'terms': [i['term'] for i in inc if i['target'] == m]} for m, e in sorted(std.items())]
    rng = random.Random(5 + n + 31 * k)
    eta = [1] * k + [-1] * d
    def box(P):
        R = {}
        for a in range(n): R = padd(R, pscale(pder(pder(P, a), a), eta[a]))
        return R
    for _ in range(3):
        F = {m: prand(rng, n) for m in Fmask.values()}
        GF = nabla(F, n, k); assert set(GF) <= {m for m in range(1 << n) if grade(m) in (1, 3)}
        G = nabla(GF, n, k)
        assert all(clean(G.get(m, {})) == clean(box(F[m])) for m in F) and not (set(G) - set(F)) and not clean(G.get(0, {}))
    D['checks'] = {'wave_equation': True, 'only_grades_1_and_3': True, 'charge_conservation': True, 'conventions': len(matches)}
    D['cube'] = {'vertices': [{'N': m, 'bits': format(m, f'0{n}b'), 'grade': grade(m)} for m in range(1 << n)],
                 'edges': [[m, m ^ (1 << a), a] for m in range(1 << n) for a in range(n) if m < m ^ (1 << a)], 'layers': [comb(n, q) for q in range(n + 1)]}
    assert len(D['cube']['edges']) == n * 2 ** (n - 1)
    D['primes'] = {'labels': list(range(1 << n)), 'prime_labels': [m for m in range(1 << n) if m > 1 and all(m % q for q in range(2, m))]}
    return D

def mirror_check(k, d):
    """The mirror world swaps time and space generators.  Its equation system must be the same system, with delta F = J turning into delta F = -J."""
    A, B = cov_spec(k, d)['std'], cov_spec(d, k)['std']; n = k + d
    sig = lambda i: d + i if i < k else i - k
    fac = {1: set(), 3: set()}
    for m, e in A.items():
        m2 = sum(1 << sig(i) for i in range(n) if m >> i & 1); mapped = {}
        for c, a, f in e['deriv']:
            x, y = [i for i in range(n) if _fmask(cov_spec(k, d), f) >> i & 1]
            a2, x2, y2 = sig(a), sig(x), sig(y); o = 1
            if x2 > y2: x2, y2, o = y2, x2, -1
            mapped[(a2, (1 << x2) | (1 << y2))] = c * o
        spec2 = cov_spec(d, k); tgt = {(a, spec2['Fmask'][f]): c for c, a, f in B[m2]['deriv']}
        assert set(mapped) == set(tgt), (k, d, e['id'])
        r = {mapped[q] * tgt[q] for q in tgt}; assert len(r) == 1
        fac[grade(m)] |= r
    assert fac[1] == {-1} and (fac[3] == {1} or not fac[3]), (k, d, fac)
    return {'mirror_of': [d, k], 'vector_equations_factor': -1, 'triple_equations_factor': 1 if fac[3] else None}
def _fmask(spec, f): return spec['Fmask'][f]

def build():
    rng = random.Random(7); D = {}
    # ---- the ladder along space (one time), as before
    lad = []
    for n in range(1, 10):
        p, q = 1, n - 1; ty, N = cell(p, q); al = algebra(p, q)
        lad.append({'n': n, 'd': n - 1, 'p': p, 'q': q, 'type': ty, 'matrix_size': N, **{k_: al[k_] for k_ in ('pseudoscalar_square', 'pseudoscalar_central', 'splits_in_two')},
                    'same_algebra_as_Cl08': (ty, N) == cell(0, 8), 'F_components': comb(n, 2), 'E_components': n - 1, 'B_components': comb(n - 1, 2),
                    'equations_vector': n, 'equations_trivector': comb(n, 3), 'equations_total': n + comb(n, 3)})
    assert [(l['type'], l['matrix_size']) for l in lad[:5]] == [('R2', 1), ('R', 2), ('C', 2), ('H', 2), ('H2', 2)]
    assert [(l['type'], l['matrix_size']) for l in lad[5:]] == [('H', 4), ('C', 8), ('R', 16), ('R2', 16)]
    assert [l['equations_total'] for l in lad] == [1, 2, 4, 8, 15, 26, 42, 64, 93]
    assert [l['d'] for l in lad if l['same_algebra_as_Cl08']] == [7] and cell(0, 8) == ('R', 16)
    assert [l['d'] for l in lad if l['splits_in_two']] == [0, 4, 8]
    D['ladder'] = lad
    # ---- the ladder along time (one space dimension): Cl(k,1)
    tl = []
    for k in range(1, 10):
        n = k + 1; ty, N = cell(k, 1); al = algebra(k, 1)
        tl.append({'k': k, 'n': n, 'type': ty, 'matrix_size': N, **{k_: al[k_] for k_ in ('pseudoscalar_square', 'pseudoscalar_central', 'splits_in_two')},
                   'E_components': k, 'T_components': comb(k, 2), 'B_components': 0, 'F_components': comb(n, 2),
                   'equations_vector': n, 'equations_trivector': comb(n, 3), 'equations_total': n + comb(n, 3),
                   'step_new_generator': 1, 'step_new_blades': 2 ** (n - 1), 'step_new_F': n - 1, 'step_new_E': 1, 'step_new_T': k - 1,
                   'step_new_equations': 1 + comb(n - 1, 2), 'mirror_type': cell(1, k)[0], 'mirror_matrix_size': cell(1, k)[1],
                   'symbol': symbol(k, 1)})
    for a, b in zip(tl, tl[1:]):                                      # each step really adds what the formula says
        assert b['F_components'] - a['F_components'] == b['step_new_F'] and b['equations_total'] - a['equations_total'] == b['step_new_equations']
        assert b['E_components'] - a['E_components'] == 1 and b['T_components'] - a['T_components'] == a['k']
    # period 8: Cl(k+8,1) = Cl(k,1) tensor M16(R): same type, matrix size times 16
    assert all(cell(k + 8, 1)[0] == cell(k, 1)[0] and cell(k + 8, 1)[1] == 16 * cell(k, 1)[1] for k in range(1, 12))
    assert [(l['type'], l['matrix_size']) for l in tl] == [('R', 2), ('R2', 2), ('R', 4), ('C', 4), ('H', 4), ('H2', 4), ('H', 8), ('C', 16), ('R', 32)]
    D['time_ladder'] = tl
    # ---- every (k,d) with k,d <= 4 and k+d <= 7: the picture depends only on n = k+d, the signs and the algebra on the split
    cells = {}
    for k in range(1, 5):
        for d in range(1, 5):
            if k + d > 7: continue
            spec = phys_spec(d) if k == 1 else cov_spec(k, d)
            C = build_cell(spec, rng); C['mirror'] = mirror_check(k, d)
            if k == 1:                                               # the physical form and the covariant form must be the same theory
                cv = build_cell(cov_spec(1, d), random.Random(3)); C['covariant_agrees'] = (len(cv['equations']) == len(C['equations']) and len(cv['incidences']) == len(C['incidences']) and cv['checks']['conventions'] == 2)
                assert C['covariant_agrees']
            cells[f'{k},{d}'] = C
    assert sorted(cells) == sorted(f'{k},{d}' for k in range(1, 5) for d in range(1, 5) if k + d <= 7)
    for key, C in cells.items():                                      # same n => same pictures: incidence structure (source, axis, target) is identical
        n = C['n']; ref = cells.get(f'1,{n - 1}')
        assert ref is None or C['kind'] == 'covariant' or [(i['source'], i['axis'], i['target']) for i in C['incidences']] == [(i['source'], i['axis'], i['target']) for i in ref['incidences']]
    for n in (3, 4, 5, 6, 7):                                               # ... and also across covariant cells of equal n, up to the order in which fields are listed
        ks = [c for c in cells.values() if c['n'] == n]
        sets = [sorted((i['source'], i['axis'], i['target']) for i in c['incidences']) for c in ks]
        assert all(s == sets[0] for s in sets), n
    D['cells'] = cells
    D['charges'] = charges()
    return D


# =====================================================================================================
# A charge moving in the field.   m du/dtau = q F.u   with F.u = (F u - u F)/2 the grade-1 part of the product (c = 1, u.u = 1).
# The page writes the gradient as  sum_a e_a d_a  (components d_a, lower index), so the four-velocity is written the same way, u~ = (u_0, u_1, ..) = (g, -g v):
# the textbook force  f0 = E.u,  f_i = u0 E_i + sum_j B_ij u_j  is then exactly the grade-1 part of F u~, and everything below is exact (Fractions) unless marked numeric.
# =====================================================================================================
from math import cos, sin, sqrt, cosh, sinh, pi, atan2, hypot
def _gp(A, B, p=1):
    R = {}
    for a, x in A.items():
        for b, y in B.items():
            m, sg = bprod(a, b, p); R[m] = R.get(m, 0) + sg * x * y
    return {m: v for m, v in R.items() if v}
def _phys_convention(d):
    spec = phys_spec(d); matches = find_conventions(spec, random.Random(11 * (d + 1) + 7))
    vec = [m for m in spec['std'] if grade(m) == 1]; chosen = [m for m in matches if all(m['eqsign'][v] == 1 for v in vec)]
    assert len(chosen) == 1
    names = list(spec['Fmask']); sg = chosen[0]['signs']
    return spec, {nm: sg[i] for i, nm in enumerate(names)}
def _Fmv(spec, sF, f): return {spec['Fmask'][nm]: sF[nm] * v for nm, v in f.items() if v}
def _lower(u): return {1 << a: (u[a] if a == 0 else -u[a]) for a in range(len(u)) if u[a]}
def _force_bits(F, u, n):                    # grade-1 part of (F u~ - u~ F)/2, read back as the textbook components (f0, f1..)
    Fu, uF = _gp(F, _lower(u)), _gp(_lower(u), F)
    c = {m: (Fu.get(m, 0) - uF.get(m, 0)) / 2 for m in set(Fu) | set(uF)}
    assert all(grade(m) == 1 for m, v in c.items() if v), 'the commutator has only grade 1'
    return [c.get(1 << a, 0) * (1 if a == 0 else -1) for a in range(n)]
def _bmat(d, f):                              # B_ij as an antisymmetric matrix from the named components
    M = {}
    for key, i, j in bfields(d):
        M[(i, j)] = f[key]; M[(j, i)] = -f[key]
    return M
def _textbook(d, f, u):
    Bm = _bmat(d, f)
    return [sum(f[f'E_{AX[i]}'] * u[i] for i in range(1, d + 1))] + [u[0] * f[f'E_{AX[i]}'] + sum(Bm.get((i, j), 0) * u[j] for j in range(1, d + 1)) for i in range(1, d + 1)]
def _unitrot(F, R, Rt, N):                     # R F R~ / N  for a simple rotor R = 1 + t e
    return {m: v / N for m, v in _gp(_gp(R, F), Rt).items()}

def charges():
    out = {'frame': 'u~ = (u_0, u_1, ..) = (gamma, -gamma v): written like the gradient, with components in the basis e_a', 'sign': 1}
    rng = random.Random(2024); rows = []
    def rnd(): return Fr(rng.randint(-9, 9), rng.randint(1, 5))
    worlds = {}
    # ---- 1. the force is the grade-1 part of F u~; it equals the textbook Lorentz force, in 2, 3 and 4 space dimensions, and no other sign does
    trials = 0
    for d in (2, 3, 4):
        spec, sF = _phys_convention(d); n = d + 1; names = list(spec['Fmask'])
        for _ in range(25):
            f = {nm: rnd() for nm in names}; u = [rnd() for _ in range(n)]
            F = _Fmv(spec, sF, f); got = _force_bits(F, u, n); want = _textbook(d, f, u)
            assert got == want, (d, got, want); assert [-x for x in got] != want or all(x == 0 for x in want)          # +1 is the only sign that gives the textbook force
            Fu, uF = _gp(F, _lower(u)), _gp(_lower(u), F)                       # F u~ = grade 1 (contraction) + grade 3 (wedge): the force is the grade-1 half, the grade-3 half is dropped
            sym = {m: (Fu.get(m, 0) + uF.get(m, 0)) / 2 for m in set(Fu) | set(uF)}; assert all(grade(m) == 3 for m, v in sym.items() if v)
            trials += 1
        # the terms: which piece of F, times which component of u, lands on which component of the force
        terms = []
        for nm in names:
            for b in range(n):
                f = {x: 0 for x in names}; f[nm] = Fr(1); u = [Fr(0)] * n; u[b] = Fr(1)
                col = _force_bits(_Fmv(spec, sF, f), u, n)
                for a, v in enumerate(col):
                    if v: terms.append({'out': a, 'field': nm, 'in': b, 'sign': int(v)})
        assert len(terms) == n * (n - 1) == 2 * comb(n, 2)                    # each edge gives exactly two terms
        # compare with the textbook table, term by term
        want = []
        for nm in names:
            for b in range(n):
                f = {x: 0 for x in names}; f[nm] = Fr(1); u = [Fr(0)] * n; u[b] = Fr(1)
                for a, v in enumerate(_textbook(d, f, u)):
                    if v: want.append({'out': a, 'field': nm, 'in': b, 'sign': int(v)})
        assert terms == want
        # ... and they are the contract half of the Maxwell incidences (d_b -> u_b): same edge, same axis, same target
        cell = build_cell(spec, random.Random(3)); contr = [i for i in cell['incidences'] if i['op'] == 'contract']
        assert len(contr) == len(terms)
        ratio = set()
        for i in contr:
            tgt = [a for a in range(n) if i['target'] >> a & 1][0]
            t = [x for x in terms if x['field'] == i['field'] and x['in'] == i['axis'] and x['out'] == tgt]
            assert len(t) == 1, (d, i)
            eta = lambda a: 1 if a == 0 else -1
            ratio.add(t[0]['sign'] * i['sign'] * eta(tgt) * eta(i['axis']))           # force sign = ratio * incidence sign * (flip of the out index) * (flip of the in index)
        assert len(ratio) == 1; worlds[str(d)] = {'d': d, 'n': n, 'fields': names, 'terms': terms, 'incidence_ratio': ratio.pop()}
    assert worlds['2']['incidence_ratio'] == worlds['3']['incidence_ratio'] == worlds['4']['incidence_ratio'] == -1
    out['worlds'] = worlds
    rows.append({'id': 'force_is_grade1', 'kind': 'exact', 'trials': trials, 'worlds': [2, 3, 4], 'terms': {k: len(v['terms']) for k, v in worlds.items()}})
    rows.append({'id': 'force_is_contraction', 'kind': 'exact', 'ratio': -1, 'terms': {k: len(v['terms']) for k, v in worlds.items()}})

    # ---- 2. u.u = 1 stays 1 (the force is perpendicular to u), and a magnetic field alone does no work
    spec3, sF3 = _phys_convention(3); names3 = list(spec3['Fmask']); pw = 0; cnt = 0
    for d in (2, 3, 4):
        spec, sF = _phys_convention(d); n = d + 1; names = list(spec['Fmask'])
        for _ in range(25):
            f = {nm: rnd() for nm in names}; u = [rnd() for _ in range(n)]; fo = _force_bits(_Fmv(spec, sF, f), u, n)
            assert fo[0] * u[0] - sum(fo[i] * u[i] for i in range(1, n)) == 0; cnt += 1               # u . f = 0 in the (+,-,-,-) metric
            fB = {nm: (0 if nm[0] == 'E' else v) for nm, v in f.items()}; assert _force_bits(_Fmv(spec, sF, fB), u, n)[0] == 0; pw += 1
    rows.append({'id': 'speed_limit', 'kind': 'exact', 'trials': cnt, 'no_work_by_B': pw})

    # ---- 3. the circle (B only) and the hyperbola (E only) solve the equation of motion exactly, parametrised by t = tan(theta/2) and t = tanh(rho/2)
    Bz, rho_ = Fr(3), Fr(5, 4); circ = 0
    for t in [Fr(1, 3), Fr(2, 5), Fr(-3, 4), Fr(7, 2), Fr(5, 12)]:
        c, s_ = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t); dc, ds = -4 * t / (1 + t * t) ** 2, 2 * (1 - t * t) / (1 + t * t) ** 2          # derivatives with respect to t
        u = [Fr(7, 4), rho_ * c, rho_ * s_, Fr(1, 3)]; f = {nm: Fr(0) for nm in names3}; f['B_z'] = Bz
        fo = _force_bits(_Fmv(spec3, sF3, f), u, 4)
        dth = 2 / (1 + t * t); dtau = -dth / Bz                                    # theta' = -Bz  (clockwise seen from +z), so d tau/dt = -theta'(t)/Bz
        assert [fo[1], fo[2]] == [rho_ * dc / dtau, rho_ * ds / dtau] and fo[0] == 0 and fo[3] == 0; circ += 1
    hyp = 0; Ex = Fr(7, 3)
    for t in [Fr(1, 3), Fr(1, 5), Fr(-2, 7), Fr(3, 5)]:
        ch, sh = (1 + t * t) / (1 - t * t), 2 * t / (1 - t * t); dch, dsh = 4 * t / (1 - t * t) ** 2, 2 * (1 + t * t) / (1 - t * t) ** 2
        drho = 2 / (1 - t * t); dtau = drho / Ex
        u = [ch, sh, Fr(0), Fr(0)]; f = {nm: Fr(0) for nm in names3}; f['E_x'] = Ex; fo = _force_bits(_Fmv(spec3, sF3, f), u, 4)
        assert fo == [dch / dtau, dsh / dtau, 0, 0]; hyp += 1
    rows.append({'id': 'circle_and_hyperbola', 'kind': 'exact', 'circle_points': circ, 'hyperbola_points': hyp, 'cyclotron_rate': 'qB/m per unit of proper time', 'hyperbola': 'u = (cosh(qEtau/m), sinh(qEtau/m))'})

    # ---- 4. crossed fields: the drift frame, and the two invariants of F
    drift = []
    for E_, B_ in [(3, 5), (5, 13), (8, 17), (7, 25), (20, 29)]:
        r = int(round((B_ * B_ - E_ * E_) ** .5)); assert r * r == B_ * B_ - E_ * E_
        f = {nm: Fr(0) for nm in names3}; f['E_y'] = Fr(E_); f['B_z'] = Fr(B_); F = _Fmv(spec3, sF3, f)
        ud = [Fr(B_, r), Fr(E_, r), Fr(0), Fr(0)]; assert ud[0] ** 2 - ud[1] ** 2 == 1
        assert _force_bits(F, ud, 4) == [0, 0, 0, 0]                                # a charge moving at E x B / B^2 feels no force at all
        t = Fr(B_ - r, E_); assert Fr(2) * t / (1 + t * t) == Fr(E_, B_)            # tanh(rho/2) with tanh(rho) = E/B
        ok_sign = []
        for sg in (1, -1):
            R = {0: Fr(1), 3: sg * t}; Rt = {0: Fr(1), 3: -sg * t}                    # the unnormalised boost 1 +- t e0 e1
            RRt = _gp(R, Rt); N = RRt[0]; assert set(RRt) == {0}
            Fp = {m: v / N for m, v in _gp(_gp(R, F), Rt).items()}
            Eprime = [Fp.get(m, 0) * sF3[nm] for nm, m in spec3['Fmask'].items() if nm[0] == 'E'] ; ok_sign.append(all(x == 0 for x in Eprime))
        assert sorted(ok_sign) == [False, True]                                     # exactly one of the two boosts removes E
        drift.append({'E': E_, 'B': B_, 'sqrt': r, 'drift_speed': f'{E_}/{B_}', 'gamma': f'{B_}/{r}', 'B_in_drift_frame': r})
    # invariants: <F^2>_0 = E^2 - B^2 and the pseudoscalar part (E.B) do not change under boosts and rotations of the frame
    inv = 0
    for _ in range(30):
        f = {nm: rnd() for nm in names3}; F = _Fmv(spec3, sF3, f); F2 = _gp(F, F)
        E2 = sum(f[f'E_{c}'] ** 2 for c in 'xyz'); B2 = sum(f[f'B_{c}'] ** 2 for c in 'xyz'); EB = sum(f[f'E_{c}'] * f[f'B_{c}'] for c in 'xyz')
        assert F2.get(0, 0) == E2 - B2 and set(F2) <= {0, 15}
        pi_ = F2.get(15, 0); assert abs(pi_) == 2 * abs(EB)
        for (a, b) in [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]:
            e = (1 << a) | (1 << b); tt = Fr(rng.randint(-5, 5), rng.randint(6, 9)); R = {0: Fr(1), e: tt}; Rt = {0: Fr(1), e: -tt}; N = _gp(R, Rt)[0]
            Fp = {m: v / N for m, v in _gp(_gp(R, F), Rt).items()}; F2p = _gp(Fp, Fp)
            assert F2p.get(0, 0) == F2.get(0, 0) and F2p.get(15, 0) == F2.get(15, 0); inv += 1
    rows.append({'id': 'drift_frame', 'kind': 'exact', 'cases': drift})
    rows.append({'id': 'invariants', 'kind': 'exact', 'checks': inv, 'scalar': 'E^2 - B^2', 'pseudoscalar': '2 E.B (up to the sign of the orientation)'})

    # ---- 5. E parallel to B: the two bivector generators commute, so the motion is a boost along z times a rotation in x,y
    Ez, Bz2 = Fr(3), Fr(4); f = {nm: Fr(0) for nm in names3}; f['E_z'] = Ez; f['B_z'] = Bz2; F = _Fmv(spec3, sF3, f)
    gE = {spec3['Fmask']['E_z']: Fr(1)}; gB = {spec3['Fmask']['B_z']: Fr(1)}
    assert _gp(gE, gB) == _gp(gB, gE) and set(_gp(gE, gB)) == {15}
    assert _gp(F, F).get(15, 0) != 0                                                  # E.B is not zero, so no frame removes E or B
    rows.append({'id': 'parallel', 'kind': 'exact', 'generators_commute': True, 'E_dot_B': 12})

    # ---- 6. the field of a point charge (away from the charge) obeys Gauss, Faraday, and the central force keeps r x u: exact at rational points
    pts = [(1, 2, 2), (2, 3, 6), (1, 4, 8), (4, 4, 7), (2, 6, 9)]; cc = 0
    for p_ in pts:
        r = int(round(sum(x * x for x in p_) ** .5)); assert r * r == sum(x * x for x in p_)
        r = Fr(r); P = [Fr(x) for x in p_]
        dE = lambda i, j: (r ** -3 if i == j else 0) - 3 * P[i] * P[j] * r ** -5       # d_i (x_j / r^3)
        assert sum(dE(i, i) for i in range(3)) == 0                                    # Gauss away from the charge: div E = 0
        assert all(dE(i, j) == dE(j, i) for i in range(3) for j in range(3))             # Faraday for a static field: d_i E_j = d_j E_i
        E = [x / r ** 3 for x in P]; cross = [P[1] * E[2] - P[2] * E[1], P[2] * E[0] - P[0] * E[2], P[0] * E[1] - P[1] * E[0]]
        assert cross == [0, 0, 0]; cc += 1                                              # r x E = 0: the force is central, so d(r x u)/d tau = 0
    rows.append({'id': 'point_charge', 'kind': 'exact', 'points': cc, 'note': 'away from the charge; the charge itself is the source rho in Gauss'})

    # ---- 7. a light wave E_x = B_y = f(t - z): a vacuum solution of the same system, and u0 - u_z cannot change
    rngw = random.Random(9); nvar = 4; P = {(a, 0, 0, b): Fr(rngw.randint(-4, 4)) for a in range(4) for b in range(0, 1)}
    f_poly = {}
    for k_, cf in [(3, Fr(1)), (2, Fr(-2)), (1, Fr(3)), (0, Fr(5))]:                       # f(phi) = phi^3 - 2 phi^2 + 3 phi + 5, phi = t - z
        for j in range(k_ + 1):
            from math import comb as _c
            e = (j, 0, 0, k_ - j); f_poly[e] = f_poly.get(e, 0) + cf * _c(k_, j) * (-1) ** (k_ - j)
    f_poly = clean(f_poly)
    def wave(sB):
        Fm = {spec3['Fmask']['E_x']: pscale(f_poly, sF3['E_x']), spec3['Fmask']['B_y']: pscale(f_poly, sF3['B_y'] * sB)}; return nabla(Fm, 4, 1)
    assert all(not clean(P_) for P_ in wave(1).values()), 'E_x = B_y = f(t - z) must solve the vacuum equations'
    assert any(clean(P_) for P_ in wave(-1).values()), 'B_y = -E_x is the wave going the other way'
    wz = 0
    for _ in range(40):
        f = {nm: Fr(0) for nm in names3}; fv = rnd(); f['E_x'] = fv; f['B_y'] = fv; u = [rnd() for _ in range(4)]
        fo = _force_bits(_Fmv(spec3, sF3, f), u, 4); assert fo[0] - fo[3] == 0 and fo == _textbook(3, f, u); wz += 1
    rows.append({'id': 'light_wave', 'kind': 'exact', 'solves_vacuum_equations': True, 'u0_minus_uz_conserved': wz})

    # ---- numeric (floating point, the same table the widget uses): the closed forms against a fourth-order Runge-Kutta integration
    T3 = worlds['3']['terms']
    def force_t(Fv, u):                                           # f^a = sum sign * field * u^b over the table
        fo = [0.0] * 4
        for tm in T3: fo[tm['out']] += tm['sign'] * Fv.get(tm['field'], 0.0) * u[tm['in']]
        return fo
    def run(field, x0, u0, qm, tau_end, h, hook=None):
        x = list(x0); u = list(u0); t = 0.0; tau = 0.0; traj = [(tau, t, tuple(x), tuple(u))]
        def rhs(t_, x_, u_):
            fo = force_t(field(t_, x_), u_); return [u_[0]] + list(u_[1:]), [qm * c for c in fo]
        while tau < tau_end - 1e-12:
            hh = min(h, tau_end - tau) if hook is None else min(hook(x, u), tau_end - tau)
            def f(state):
                t_, x_, u_ = state[0], state[1:4], state[4:8]; dx, du = rhs(t_, x_, u_); return [dx[0]] + dx[1:] + du
            s0 = [t] + x + u
            k1 = f(s0); k2 = f([a + hh / 2 * b for a, b in zip(s0, k1)]); k3 = f([a + hh / 2 * b for a, b in zip(s0, k2)]); k4 = f([a + hh * b for a, b in zip(s0, k3)])
            s1 = [a + hh / 6 * (b + 2 * c + 2 * d_ + e) for a, b, c, d_, e in zip(s0, k1, k2, k3, k4)]
            t, x, u = s1[0], s1[1:4], s1[4:8]; tau += hh; traj.append((tau, t, tuple(x), tuple(u)))
        return traj
    gam = lambda u: u[0] ** 2 - u[1] ** 2 - u[2] ** 2 - u[3] ** 2
    num = {}
    # (a) cyclotron: B = 1, v = 0.8 -> radius gamma v / B = 4/3, back to the start after tau = 2 pi / B
    v = .8; g = 1 / sqrt(1 - v * v); tr = run(lambda t, x: {'B_z': 1.0}, [0, 0, 0], [g, g * v, 0, 0], 1.0, 2 * pi, 2 * pi / 20000)
    last = tr[-1]; cx = [p[2][0] for p in tr]; cy = [p[2][1] for p in tr]
    rad = (max(cy) - min(cy)) / 2; num['cyclotron'] = {'radius_formula': round(g * v, 9), 'radius_measured': round(rad, 7), 'closure_below': 1e-7, 'u2_drift_below': 1e-9}
    assert abs(rad - g * v) < 1e-7 and hypot(last[2][0], last[2][1]) < 1e-7 and max(abs(gam(p[3]) - 1) for p in tr) < 1e-9
    # (b) hyperbolic motion: E = 1, from rest: x(t) = sqrt(1 + t^2) - 1
    tr = run(lambda t, x: {'E_x': 1.0}, [0, 0, 0], [1, 0, 0, 0], 1.0, 3.0, 3.0 / 6000); e = max(abs(p[2][0] - (sqrt(1 + p[1] ** 2) - 1)) for p in tr)
    num['hyperbolic'] = {'max_error_x_below': 1e-8, 'tau_end': 3.0, 'speed_at_end': round(tr[-1][3][1] / tr[-1][3][0], 9), 'x_at_end': round(tr[-1][2][0], 7), 'newtonian_x_at_same_time': round(tr[-1][1] ** 2 / 2, 5)}
    assert e < 1e-8 and tr[-1][3][1] / tr[-1][3][0] < 1
    # (c) drift: E_y = 0.6, B_z = 1, from rest: over one period the mean velocity is E/B
    Ey, Bz_ = .6, 1.0; Tp = 2 * pi / sqrt(Bz_ ** 2 - Ey ** 2); tr = run(lambda t, x: {'E_y': Ey, 'B_z': Bz_}, [0, 0, 0], [1, 0, 0, 0], 1.0, Tp, Tp / 20000)
    md = tr[-1][2][0] / tr[-1][1]; num['drift'] = {'mean_velocity': round(md, 8), 'E_over_B': Ey / Bz_, 'period_tau': round(Tp, 9), 'max_speed': round(max(p[3][1] / p[3][0] for p in tr), 8)}
    assert abs(md - Ey / Bz_) < 1e-8
    # (d) the wave: u_x = a sin(omega tau), u0 - u_z = 1 for ever, mean drift speed a^2 / (4 + a^2)
    a_ = 1.5; w_ = 1.0
    tr = run(lambda t, x: {'E_x': a_ * w_ * cos(w_ * (t - x[2])), 'B_y': a_ * w_ * cos(w_ * (t - x[2]))}, [0, 0, 0], [1, 0, 0, 0], 1.0, 2 * pi * 4, 2 * pi / 8000)
    e1 = max(abs(p[3][1] - a_ * sin(w_ * p[0])) for p in tr); e2 = max(abs(p[3][0] - p[3][3] - 1) for p in tr)
    k4 = [p for p in tr if abs(p[0] - 2 * pi * 4) < 1e-9][-1]; dv = k4[2][2] / k4[1]
    num['wave'] = {'a': a_, 'max_error_ux_below': 1e-8, 'u0_minus_uz_drift_below': 1e-9, 'mean_drift_speed': round(dv, 7), 'formula': round(a_ ** 2 / (4 + a_ ** 2), 9)}
    assert e1 < 1e-8 and e2 < 1e-9 and abs(dv - a_ ** 2 / (4 + a_ ** 2)) < 1e-6
    # (e) attraction by a point charge: the orbit is r = p / (1 + e cos(s phi)) with s = sqrt(1 - kappa^2 / L^2): the perihelion advances by 2 pi (1/s - 1) per turn
    kap = .3; v0 = .5; g0 = 1 / sqrt(1 - v0 * v0); L = g0 * v0            # start at r = 1, tangential, mass 1, charge -1 and source kappa: attraction kappa / r^2
    fld = lambda t, x: (lambda r3: {'E_x': kap * x[0] / r3, 'E_y': kap * x[1] / r3, 'E_z': kap * x[2] / r3})((x[0] ** 2 + x[1] ** 2 + x[2] ** 2) ** 1.5)
    hook = lambda x, u: 2e-3 * min(1.0, (x[0] ** 2 + x[1] ** 2) ** .5) ** 1.5
    tr = run(fld, [1, 0, 0], [g0, 0, g0 * v0, 0], -1.0, 40.0, 2e-3, hook)
    ph = 0.0; prev = atan2(tr[0][2][1], tr[0][2][0]); peri = []
    ang = [prev]
    for i in range(1, len(tr)):
        a = atan2(tr[i][2][1], tr[i][2][0]); da = (a - prev + pi) % (2 * pi) - pi; ph += da; prev = a; ang.append(ph)
    rr = [hypot(p[2][0], p[2][1]) for p in tr]
    for i in range(1, len(tr) - 1):
        if rr[i] < rr[i - 1] and rr[i] <= rr[i + 1]:
            y0, y1, y2 = rr[i - 1], rr[i], rr[i + 1]; den = y0 - 2 * y1 + y2; off = .5 * (y0 - y2) / den if den else 0.0
            peri.append(ang[i] + off * (ang[i + 1] - ang[i - 1]) / 2)
    assert len(peri) >= 3
    s_ = sqrt(1 - kap ** 2 / L ** 2); meas = [b - a for a, b in zip(peri, peri[1:])]; form = 2 * pi / s_
    num['relativistic_orbit'] = {'kappa': kap, 'L': round(L, 9), 'sqrt_1_minus_k2_over_L2': round(s_, 9), 'angle_between_perihelia_formula': round(form, 6), 'angle_between_perihelia_measured': [round(x, 4) for x in meas[:3]],
                                 'advance_degrees_formula': round(360 * (1 / s_ - 1), 4), 'advance_degrees_measured': round(360 * (meas[0] / (2 * pi) - 1), 3), 'u2_drift_below': 1e-7}
    assert all(abs(m_ - form) < 2e-4 for m_ in meas[:3]) and max(abs(gam(p[3]) - 1) for p in tr) < 1e-7
    out['numeric'] = num
    rows += [{'id': 'num_cyclotron', 'kind': 'numeric'}, {'id': 'num_hyperbolic', 'kind': 'numeric'}, {'id': 'num_drift', 'kind': 'numeric'}, {'id': 'num_wave', 'kind': 'numeric'}, {'id': 'num_orbit', 'kind': 'numeric'}]
    out['rows'] = rows; out['counts'] = {'exact': sum(1 for r in rows if r['kind'] == 'exact'), 'numeric': sum(1 for r in rows if r['kind'] == 'numeric')}
    return out

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    D = build(); txt = json.dumps(D, indent=1, sort_keys=True, ensure_ascii=False)
    if a.write: open(a.write, 'w', encoding='utf8').write(txt)
    if a.compare:
        assert json.loads(txt) == json.load(open(a.compare, encoding='utf8')), 'portal data differs from the rebuilt data'; print('portal data == rebuilt data')
    print('ALL MAXWELL CHECKS PASS')
if __name__ == '__main__': main()
