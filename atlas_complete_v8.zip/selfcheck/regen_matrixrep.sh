#!/bin/sh
# rebuild matrixrep.json (exact, standard library, ~8 s) and the two modules the app imports from it (run from anywhere)
set -e
cd "$(dirname "$0")"
python3 matrixrep_check.py --write matrixrep.json | tail -1
cd ..
python3 - <<'PY'
import json
d=json.load(open('selfcheck/matrixrep.json')); d.pop('fixtures')          # the fixtures stay in the json (tests); the app does not need them
open('matrixrepData.js','w').write('export default '+json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':'))+';\n')
open('matrixrepSelfcheckSource.js','w').write('export const MATRIXREP_PY = '+json.dumps(open('selfcheck/matrixrep_check.py').read(),ensure_ascii=False)+';\n')
PY
if [ -d /home/claude/ui ]; then mkdir -p /home/claude/ui/selfcheck && cp selfcheck/matrixrep* /home/claude/ui/selfcheck/; fi
