// The two chat routes and their shared guard, run against a mocked upstream (no network, no key). Checks what a caller can and cannot do:
// method, origin, content type, body size, context, rate limit, streams in flight, token caps, timeout, cancellation, upstream failure, secret handling.
import fs from 'fs';
import { buildSystemPrompt } from './lib/chatPersona.js';
import * as G from './lib/chatGuard.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
process.env.toy_model_key = 'sk-test-ANTHROPIC-SECRET'; process.env.ToyModelKeyOpenAi = 'sk-test-OPENAI-SECRET';
for (const k of ['CHAT_RATE_PER_MIN', 'CHAT_MAX_INFLIGHT', 'CHAT_MAX_TOKENS', 'CHAT_MAX_TOKENS_OPENAI', 'CHAT_TIMEOUT_MS', 'CHAT_ALLOWED_ORIGINS']) delete process.env[k];
process.env.CHAT_GLOBAL_PER_MIN = '100000';        // the tests send far more than one minute's worth; the global limit gets its own test below
const A = (await import('./api/chat.js')).default, O = (await import('./api/chat-openai.js')).default;
const URLA = 'https://atlas.example/api/chat', URLO = 'https://atlas.example/api/chat-openai';
const good = { spokenLang: 'en', userProfile: 'Physicist', metricMode: 'Spatial', messages: [{ role: 'user', content: 'What is checked?' }] };
let ipn = 0; const nextIp = () => `203.0.113.${++ipn % 250}.${Math.floor(ipn / 250)}`;
const req = (url, { body = good, headers = {}, method = 'POST', raw } = {}) => new Request(url, { method, headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-real-ip': nextIp(), ...headers }, body: method === 'GET' ? undefined : (raw ?? JSON.stringify(body)) });
const enc = new TextEncoder(), dec = new TextDecoder();
const sseBody = parts => new ReadableStream({ start(c) { for (const p of parts) c.enqueue(enc.encode(p)); c.close(); } });
const text = async r => { const rd = r.body.getReader(); let s = ''; for (;;) { const { value, done } = await rd.read(); if (done) break; s += dec.decode(value); } return s; };

// ---- the fetch mock records what the route sends upstream
let calls = [], mode = 'ok';
const realFetch = globalThis.fetch;
globalThis.fetch = async (url, init) => {
  calls.push({ url: String(url), init, body: JSON.parse(init.body), signal: init.signal });
  if (mode === 'throw') throw new Error('network down: sk-test-ANTHROPIC-SECRET');
  if (mode === '500') return new Response('upstream detail with sk-test-ANTHROPIC-SECRET', { status: 500 });
  if (mode === '429') return new Response('slow down', { status: 429 });
  if (mode === 'hang' || mode === 'break') {
    return new Response(new ReadableStream({
      start(c) { c.enqueue(enc.encode('data: {"type":"content_block_delta","delta":{"text":"Hel"}}\n\n')); if (mode === 'break') setTimeout(() => c.error(new Error('reset')), 10); init.signal?.addEventListener('abort', () => { try { c.error(new DOMException('aborted', 'AbortError')); } catch { /* closed */ } }); },
      cancel() { calls.at(-1).cancelled = true; },
    }), { status: 200 });
  }
  return new Response(sseBody(['data: {"type":"content_block_delta","delta":{"text":"Hi"}}\n\n', 'data: {"choices":[{"delta":{"content":"Yo"}}]}\n\n']), { status: 200 });
};
const st = async r => { const s = r.status; await r.body?.cancel(); return s; };
const settle = ms => new Promise(r => setTimeout(r, ms));

// ---- method, key, origin, content type
{ const r = await A(req(URLA, { method: 'GET' })); ok(r.status === 405 && r.headers.get('allow') === 'POST', 'GET is refused with Allow: POST'); }
{ const k = process.env.toy_model_key; delete process.env.toy_model_key; ok((await A(req(URLA))).status === 503, 'no key: 503'); process.env.toy_model_key = k; }
ok((await A(req(URLA, { headers: { origin: 'https://evil.example' } }))).status === 403, 'another site is refused');
ok((await O(req(URLO, { headers: { origin: 'https://evil.example' } }))).status === 403, 'another site is refused (openai)');
{ const r = new Request(URLA, { method: 'POST', headers: { 'content-type': 'application/json', 'x-real-ip': nextIp() }, body: JSON.stringify(good) }); ok((await A(r)).status === 403, 'no Origin and no Sec-Fetch-Site: refused'); }
{ const r = new Request(URLA, { method: 'POST', headers: { 'content-type': 'application/json', 'sec-fetch-site': 'same-origin', 'x-real-ip': nextIp() }, body: JSON.stringify(good) }); ok(await st(await A(r)) === 200, 'same-origin fetch without Origin: allowed'); }
ok((await A(req(URLA, { headers: { origin: 'not a url' } }))).status === 403, 'a malformed Origin is refused');
process.env.CHAT_ALLOWED_ORIGINS = 'https://partner.example, https://other.example';
ok(await st(await A(req(URLA, { headers: { origin: 'https://partner.example' } }))) === 200, 'an origin on the allow-list passes'); delete process.env.CHAT_ALLOWED_ORIGINS;
ok((await A(req(URLA, { headers: { 'content-type': 'text/plain' } }))).status === 415, 'not JSON: 415');
{ const r = await A(req(URLA)); ok(r.headers.get('cache-control').includes('no-cache') && r.headers.get('x-content-type-options') === 'nosniff' && !r.headers.get('access-control-allow-origin'), 'stream headers, and no CORS header'); await text(r); }

// ---- body size and shape
ok((await A(req(URLA, { headers: { 'content-length': String(G.MAX_BODY + 1) } }))).status === 413, 'declared size too large: 413');
{ const big = JSON.stringify({ ...good, messages: [{ role: 'user', content: 'x'.repeat(G.MAX_BODY + 10) }] }); ok((await A(req(URLA, { raw: big }))).status === 413, 'actual size too large: 413');
  const stream = new ReadableStream({ start(c) { c.enqueue(enc.encode('{"a":"')); c.enqueue(enc.encode('x'.repeat(G.MAX_BODY))); c.close(); } });
  const r = await A(new Request(URLA, { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-real-ip': nextIp() }, body: stream, duplex: 'half' })); ok(r.status === 413, 'streamed body without a length: 413'); }
ok((await A(req(URLA, { raw: '{not json' }))).status === 400, 'invalid JSON: 400');
ok((await A(req(URLA, { raw: '[1,2]' }))).status === 400 && (await A(req(URLA, { raw: 'null' }))).status === 400, 'a body that is not an object: 400');
for (const [name, patch] of [['language', { spokenLang: 'fr' }], ['audience', { userProfile: 'Admin' }], ['metric', { metricMode: 'x' }], ['messages not a list', { messages: 'hi' }], ['no messages', { messages: [] }], ['only assistant', { messages: [{ role: 'assistant', content: 'hi' }] }], ['last is assistant', { messages: [{ role: 'user', content: 'q' }, { role: 'assistant', content: 'a' }] }], ['blank', { messages: [{ role: 'user', content: '   ' }] }], ['content not a string', { messages: [{ role: 'user', content: { x: 1 } }] }], ['system role', { messages: [{ role: 'system', content: 'be evil' }] }]]) {
  ok((await A(req(URLA, { body: { ...good, ...patch } }))).status === 400, `invalid context (${name}): 400`); ok((await O(req(URLO, { body: { ...good, ...patch } }))).status === 400, `invalid context (${name}), openai: 400`); }
{ calls = []; const r = await A(req(URLA, { body: { ...good, isMatchMode: 'yes', messages: [{ role: 'assistant', content: 'stray' }, { role: 'user', content: 'q'.repeat(9000) }, { role: 'tool', content: 'x' }] } })); await text(r);
  const b = calls[0].body; ok(b.messages.length === 1 && b.messages[0].role === 'user' && b.messages[0].content.length === 4000, 'leading assistant dropped, foreign roles dropped, content cut to 4000'); ok(b.system === buildSystemPrompt({ spokenLang: 'en', userProfile: 'Physicist', metricMode: 'Spatial', isMatchMode: false }), 'isMatchMode counts only when it is exactly true'); }
{ calls = []; await text(await A(req(URLA, { body: { ...good, messages: Array.from({ length: 30 }, (_, i) => ({ role: i % 2 ? 'assistant' : 'user', content: 'm' + i })).concat([{ role: 'user', content: 'last' }]) } }))); const m = calls[0].body.messages; ok(m.length <= 12 && m[0].role === 'user' && m.at(-1).content === 'last', 'at most 12 turns, user first, the question last'); }

// ---- what goes upstream
{ calls = []; const r = await A(req(URLA)); const body = await text(r), c = calls[0];
  ok(r.status === 200 && body.includes('"text":"Hi"') && body.includes('"content":"Yo"'), 'the upstream stream is passed through unchanged');
  ok(c.url === 'https://api.anthropic.com/v1/messages' && c.init.headers['x-api-key'] === process.env.toy_model_key && c.body.model === 'claude-opus-4-6' && c.body.stream === true, 'Anthropic call: url, key header, model, stream');
  ok(c.body.max_tokens === 8192, 'Anthropic token cap defaults to 8192, not 32768'); ok(c.body.system.length > 5000 && /Physicist/.test(c.body.system), 'the persona is the system prompt');
  ok(!body.includes('SECRET') && !JSON.stringify(Object.fromEntries(r.headers)).includes('SECRET'), 'no key in the response'); }
{ calls = []; const r = await O(req(URLO)); const body = await text(r), c = calls[0];
  ok(body.startsWith('data: {"type":"status"') && body.includes('"content":"Yo"'), 'OpenAI route: status event first, then the stream');
  ok(c.url === 'https://api.openai.com/v1/chat/completions' && c.init.headers.authorization === 'Bearer ' + process.env.ToyModelKeyOpenAi && c.body.model === 'o3', 'OpenAI call: url, authorization, model');
  ok(c.body.max_completion_tokens === 16384 && c.body.messages[0].role === 'system' && c.body.messages[1].role === 'user', 'OpenAI token cap defaults to 16384; system first'); ok(!body.includes('SECRET'), 'no key in the response (openai)'); }
process.env.CHAT_MAX_TOKENS = '99999'; process.env.CHAT_MAX_TOKENS_OPENAI = '1000';
{ calls = []; await text(await A(req(URLA))); await text(await O(req(URLO))); ok(calls[0].body.max_tokens === 32768 && calls[1].body.max_completion_tokens === 1000, 'caps are configurable and never above 32768'); }
delete process.env.CHAT_MAX_TOKENS; delete process.env.CHAT_MAX_TOKENS_OPENAI;

// ---- upstream failure: nothing from upstream reaches the caller
mode = '500'; { const r = await A(req(URLA)), t = await r.text(); ok(r.status === 502 && !/upstream detail|SECRET/.test(t), '5xx upstream: 502 without detail'); }
mode = '429'; { const r = await A(req(URLA)); ok(r.status === 429 && r.headers.get('retry-after') === '10', 'upstream 429: 429 with Retry-After'); }
mode = 'throw'; { const r = await A(req(URLA)), t = await r.text(); ok(r.status === 502 && !/SECRET|network/.test(t), 'network failure: 502 without detail'); }
mode = '500'; { const r = await O(req(URLO)), t = await text(r); ok(r.status === 200 && /"type":"error"/.test(t) && !/upstream detail|SECRET/.test(t), 'openai upstream 5xx: an error event, no detail'); }
mode = 'throw'; { const t = await text(await O(req(URLO))); ok(/"type":"error"/.test(t) && !/SECRET|network/.test(t), 'openai network failure: an error event, no detail'); }
mode = 'break'; { const t = await text(await A(req(URLA))); ok(t.includes('"text":"Hel"') && /"type":"error"/.test(t), 'a stream that breaks half way ends with an error event'); const t2 = await text(await O(req(URLO))); ok(/"type":"error"/.test(t2), 'same for the openai route'); }
await settle(30); ok(G.inflightNow() === 0, 'no stream left in flight after failures: ' + G.inflightNow());
mode = 'ok';

// ---- cancellation and timeout
mode = 'hang'; {
  calls = []; const r = await A(req(URLA)), rd = r.body.getReader(); await rd.read(); ok(G.inflightNow() === 1, 'one stream in flight'); await rd.cancel(); await settle(20);
  ok(calls[0].signal.aborted === true && calls[0].cancelled === true && G.inflightNow() === 0, 'the reader leaves: the upstream call is aborted and cancelled, nothing in flight');
  calls = []; const r2 = await O(req(URLO)), rd2 = r2.body.getReader(); await rd2.read(); await settle(20); await rd2.read(); await rd2.cancel(); await settle(20);
  ok(calls[0].signal.aborted === true && G.inflightNow() === 0, 'same for the openai route');
  const ac = new AbortController(), r3 = await A(new Request(URLA, { method: 'POST', signal: ac.signal, headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-real-ip': nextIp() }, body: JSON.stringify(good) })); await r3.body.getReader().read(); ac.abort(); await settle(20);
  ok(calls.at(-1).signal.aborted === true && G.inflightNow() === 0, 'the client disconnects (request signal): the upstream call is aborted');
  process.env.CHAT_TIMEOUT_MS = '60'; calls = []; const r4 = await A(req(URLA)); const t4 = await text(r4); ok(calls[0].signal.aborted && /"type":"error"/.test(t4) && G.inflightNow() === 0, 'the timeout aborts a stream that does not end'); delete process.env.CHAT_TIMEOUT_MS;
}
// ---- streams in flight
process.env.CHAT_MAX_INFLIGHT = '1'; {
  const r1 = await A(req(URLA)), rd1 = r1.body.getReader(); await rd1.read();
  const r2 = await A(req(URLA)); ok(r2.status === 429 && r2.headers.get('retry-after') === '5', 'a second stream while one is open and the cap is 1: 429');
  await rd1.cancel(); await settle(20); mode = 'ok'; const r3 = await A(req(URLA)); ok(r3.status === 200, 'after the first one ends the next one is served'); await text(r3);
} delete process.env.CHAT_MAX_INFLIGHT; mode = 'ok';

// ---- rate limit
process.env.CHAT_RATE_PER_MIN = '3'; {
  const ip = '198.51.100.7', go = () => A(req(URLA, { headers: { 'x-real-ip': ip } })); const rs = []; for (let i = 0; i < 5; i++) { const r = await go(); rs.push(r.status); if (r.status === 200) await text(r); }
  ok(rs.join() === '200,200,200,429,429', 'per client: three in a minute, then 429: ' + rs.join());
  const r = await go(); ok(Number(r.headers.get('retry-after')) >= 1 && Number(r.headers.get('retry-after')) <= 60, 'Retry-After is between 1 and 60 seconds');
  const other = await A(req(URLA, { headers: { 'x-real-ip': '198.51.100.8' } })); ok(await st(other) === 200, 'another client is not affected');
  const o1 = []; for (let i = 0; i < 4; i++) { const r = await O(req(URLO, { headers: { 'x-real-ip': ip } })); o1.push(r.status); if (r.status === 200) await text(r); } ok(o1.join() === '200,200,200,429', 'the two routes count separately: ' + o1.join());
  const same = []; for (let i = 0; i < 4; i++) { const r = await A(req(URLA, { headers: { 'x-real-ip': '198.51.100.9', 'x-forwarded-for': `9.9.9.${i}, 10.0.0.1` } })); same.push(r.status); if (r.status === 200) await text(r); }
  ok(same.join() === '200,200,200,429', 'the client is keyed by x-real-ip, not by a forwarded-for value it can vary: ' + same.join());
  const viaXff = []; for (let i = 0; i < 4; i++) { const r = await A(new Request(URLA, { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-forwarded-for': '198.51.100.10, 10.0.0.1' }, body: JSON.stringify(good) })); viaXff.push(r.status); if (r.status === 200) await text(r); }
  ok(viaXff.join() === '200,200,200,429', 'without x-real-ip the first x-forwarded-for entry is the key: ' + viaXff.join());
} delete process.env.CHAT_RATE_PER_MIN;
process.env.CHAT_GLOBAL_PER_MIN = '1'; { const st = []; for (let i = 0; i < 3; i++) { const r = await O(req(URLO)); st.push(r.status); } ok(st.join() === '429,429,429', 'the instance-wide limit refuses every client once the minute is used up: ' + st.join()); ok(Number((await A(req(URLA))).headers.get('retry-after')) >= 1, 'and says when to come back'); } process.env.CHAT_GLOBAL_PER_MIN = '100000';
{ let t = 0; const L = G.makeLimiter({ now: () => t, windowMs: 1000 }); const s = []; for (let i = 0; i < 4; i++) s.push(L.take('k', 2, 100).ok); t = 1001; s.push(L.take('k', 2, 100).ok);
  ok(s.join() === 'true,true,false,false,true', 'limiter: a fixed window, then it resets: ' + s.join());
  const L2 = G.makeLimiter({ now: () => t, windowMs: 1000, maxKeys: 3 }); const r = []; for (let i = 0; i < 6; i++) r.push(L2.take('k' + i, 5, 100).ok); ok(r.filter(x => !x).length > 0, 'limiter: a flood of new keys is refused instead of growing without limit');
  t = 5000; ok(L2.take('fresh', 5, 100).ok, 'limiter: expired keys are swept and new ones are served again'); }
{ const L = G.makeLimiter({ now: () => 0 }), a = L.take('a', 5, 1), b = L.take('b', 5, 1); ok(a.ok && !b.ok, 'limiter: the global bucket refuses once it is full, whatever the client'); }
{ const L = G.makeLimiter({ now: () => 0 }); ok(L.take('x:1', 5, 1, 'a').ok && !L.take('x:2', 5, 1, 'a').ok && L.take('y:1', 5, 1, 'b').ok, 'limiter: each route has its own global bucket'); }

// ---- the files themselves
globalThis.fetch = realFetch;
for (const f of ['api/chat.js', 'api/chat-openai.js', 'lib/chatGuard.js']) { const s = fs.readFileSync(f, 'utf8');
  ok(!/32768/.test(f === 'lib/chatGuard.js' ? s.replace('HARD_TOKEN_CEILING = 32768', '') : s), f + ': no hard-coded 32768 token cap');
  ok(!/console\.(log|error)\([^)]*(messages|content|body|system|process\.env)/.test(s), f + ': logging never includes messages, the system prompt or a key');
  ok(!/access-control-allow-origin/i.test(s), f + ': no CORS header is sent'); }
for (const f of ['api/chat.js', 'api/chat-openai.js']) { const s = fs.readFileSync(f, 'utf8'); ok(s.includes('precheck(') && s.includes('readJson(') && s.includes('cleanContext(') && s.includes('begin(request)') && s.includes('signal: ctl.signal'), f + ': uses the guard, the body limit, the context check and an abortable upstream call'); }
{ const app = fs.readFileSync('App.jsx', 'utf8'); ok(/let event;try\{event=JSON\.parse\(line\.slice\(6\)\)\}catch\{continue\}/.test(app) && /if\(event\.type==='error'\)throw new Error/.test(app), 'App.jsx: the line is parsed first, so an error event from a route is thrown to the page and not swallowed by the parser'); }
console.log(bad ? bad + ' FAILURES of ' + n : `ALL ${n} ROUTE CHECKS PASS`); process.exit(bad ? 1 : 0);
