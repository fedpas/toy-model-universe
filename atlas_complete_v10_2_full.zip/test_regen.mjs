// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// A failing check never overwrites the stored data (retest T6-2). null_selfcheck.py writes its json before it counts the passing checks, so selfcheck/regen_null.sh must write into a new
// file and keep it only when the check passed. Here the script runs in a temporary copy of the five files it reads and writes, with the bit rule of null_selfcheck.py broken on purpose (the sign
// (-1)^N(a,b) of every product replaced by +1): it must stop with a non-zero exit code at the failing check, and selfcheck/null.json, nullData.js and nullSelfcheckSource.js must be byte for byte
// what they were, with no temporary file left. The package itself is not touched. One run of the check script (about 15 s).   Run: node test_regen.mjs
import fs from 'node:fs'; import os from 'node:os'; import path from 'node:path'; import crypto from 'node:crypto'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const FILES = ['selfcheck/regen_null.sh', 'selfcheck/null_selfcheck.py', 'selfcheck/null.json', 'nullData.js', 'nullSelfcheckSource.js'];
const BREAK = ['    return -1 if s & 1 else 1\n', '    return 1\n'];   // rsign(a, b): the sign of e_a e_b; always +1 breaks the bit rule
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const pkgBefore = Object.fromEntries(FILES.map(f => [f, sha(path.join(PKG, f))]));
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'atlas-regen-'));
const cleanup = () => { try { fs.rmSync(tmp, { recursive: true, force: true }); } catch { /* already gone */ } };
process.on('exit', cleanup); for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { cleanup(); process.exit(130); });
for (const f of FILES) { fs.mkdirSync(path.dirname(path.join(tmp, f)), { recursive: true }); fs.copyFileSync(path.join(PKG, f), path.join(tmp, f)); }
const py = path.join(tmp, 'selfcheck', 'null_selfcheck.py'), src = fs.readFileSync(py, 'utf8');
ok(src.split(BREAK[0]).length === 2, 'the sign line of rsign is in null_selfcheck.py exactly once (the line this test breaks)');
fs.writeFileSync(py, src.replace(BREAK[0], BREAK[1]));
const kept = FILES.filter(f => f !== 'selfcheck/null_selfcheck.py'), before = Object.fromEntries(kept.map(f => [f, sha(path.join(tmp, f))]));
// started from another folder, by absolute path: the script finds its files itself
const r = spawnSync('sh', [path.join(tmp, 'selfcheck', 'regen_null.sh')], { cwd: os.tmpdir(), encoding: 'utf8', timeout: 300000 });
const out = (r.stdout || '') + '\n' + (r.stderr || '');
ok(r.status !== 0 && r.status !== null, 'regen_null.sh exits with an error when the check fails (exit code ' + r.status + (r.signal ? ', signal ' + r.signal : '') + ')');
const m = /(\d+) of (\d+) computed checks pass/.exec(out);
ok(!!m && +m[1] < +m[2] && /regen: failed: python3 null_selfcheck\.py --write/.test(out), 'it stops at the failing check, which says so: ' + (m ? m[0] : out.trim().split('\n').slice(-3).join(' | ')));
for (const f of kept) ok(sha(path.join(tmp, f)) === before[f], f + ' is unchanged after the failed run');
const left = fs.readdirSync(path.join(tmp, 'selfcheck')).sort();
ok(left.join(',') === 'null.json,null_selfcheck.py,regen_null.sh', 'no temporary file is left in selfcheck/: ' + left.join(', '));
ok(FILES.every(f => sha(path.join(PKG, f)) === pkgBefore[f]), 'the files of the package were not touched');
cleanup();
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL REGEN TESTS PASS'); process.exit(bad ? 1 : 0);
