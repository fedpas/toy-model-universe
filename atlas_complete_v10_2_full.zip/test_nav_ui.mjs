// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import { STORY } from './storyCopy.js';
// Navigation, settings and tabs (v9):
//  1. history: every page or tab the reader opens is a history entry; Back and Forward move between them inside the app; deep links still work;
//     an address that names no page or no tab is corrected on load without a new entry (L5-008)
//  2. the page says which language it is in: <html lang> and <main lang> follow the language, on load and on every change (L5-009)
//  3. the audience is remembered like the language (atlas.audience); a stored value that is not an audience is ignored; blocked storage is harmless (L5-015)
//  4. Next/Previous bring the start of the new step into view below the page bar and move the focus to its tab; a tab click does not hide the tab under
//     the page bar; on phones the page bar is one short row (L5-006)
//  5. the stage chooser of the dictionary is a real tablist: role=tab, aria-selected, aria-controls -> tabpanel, one tab in the Tab order, arrow keys (L5-012)
//  6. (v9 fix round) the button of the page already shown keeps the tab and the address (T2-3); the page bar's name is in the page's language (T2-8);
//     Escape closes the Settings menu; the Map's "Go there" buttons put the target just below the sticky page bar, not under it (T2-2)
// Run: node test_nav_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const hash = pg => pg.evaluate(() => location.hash);
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`)); };

// ---- 1. history
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'history');
  await pg.goto('about:blank'); await pg.goto(APP + '#rule'); await pg.waitForTimeout(300);
  const h0 = await pg.evaluate(() => history.length);
  await pg.locator('.story-nav > button').nth(8).click(); await pg.waitForTimeout(150);                       // 9 · Map (7 is Labels · gravity · groups, 8 is Lenses)
  ok(await hash(pg) === '#map' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('9'), 'the Map page opens: ' + await hash(pg));
  await pg.locator('.story-nav > button').nth(5).click(); await pg.waitForTimeout(150);                       // 6 · More equations
  await pg.locator('.tabbar [data-tab="spin"]').click(); await pg.waitForTimeout(150);
  ok(await hash(pg) === '#equations/spin', 'the spin tab opens: ' + await hash(pg));
  ok(await pg.evaluate(() => history.length) === h0 + 3, `three navigations make three history entries (${h0} -> ${await pg.evaluate(() => history.length)})`);
  await pg.goBack(); await pg.waitForTimeout(250);
  ok(await hash(pg) === '#equations' && await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'comm', 'Back returns to the first tab of the equations page: ' + await hash(pg));
  await pg.goBack(); await pg.waitForTimeout(250);
  ok(await hash(pg) === '#map' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('9') && await pg.locator('.tabbar').count() === 0, 'Back again returns to the Map page: ' + await hash(pg));
  await pg.goBack(); await pg.waitForTimeout(250);
  ok(await hash(pg) === '#rule' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('1'), 'Back again returns to the first page, still inside the app: ' + pg.url());
  await pg.goForward(); await pg.waitForTimeout(250);
  ok(await hash(pg) === '#map' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('9'), 'Forward returns to the Map page: ' + await hash(pg));
  await pg.goForward(); await pg.goForward(); await pg.waitForTimeout(250);
  ok(await hash(pg) === '#equations/spin' && await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'spin', 'Forward twice restores page and tab: ' + await hash(pg));
  // the button of the page already shown (6 · More equations while on #equations/spin) adds no entry and keeps the tab in the address, so a reload shows the same tab (T2-3)
  // ... and it scrolls to the top (V2-2): the page is scrolled down first
  await pg.evaluate(() => window.scrollTo(0, 600)); await pg.waitForTimeout(100); const y1 = await pg.evaluate(() => scrollY);
  const h2 = await pg.evaluate(() => history.length); await pg.locator('.story-nav > button').nth(5).click(); await pg.waitForTimeout(150);
  const top = await pg.waitForFunction(() => scrollY === 0, null, { timeout: 2000 }).then(() => true, () => false);
  ok(y1 >= 500 && top, `the button of the page already shown scrolls to the top (scrollY ${y1} before, ${await pg.evaluate(() => scrollY)} after)`);
  ok(await hash(pg) === '#equations/spin' && await pg.evaluate(() => history.length) === h2 && await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'spin', `the button of the page already shown keeps page, tab and address (${await hash(pg)}, ${h2} -> ${await pg.evaluate(() => history.length)})`);
  await pg.reload(); await pg.waitForTimeout(300);
  ok(await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'spin', 'after that, a reload still shows the spin tab');
  // the brand link does not add a second entry
  const h1 = await pg.evaluate(() => history.length); await pg.locator('.story-nav .brand').click(); await pg.waitForTimeout(150);
  ok(await hash(pg) === '#rule' && await pg.evaluate(() => history.length) === h1 + 1, 'the brand link adds exactly one entry');
  await ctx.close(); }
// deep links and corrections on load
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'deeplink');
  await pg.goto(APP + '#furey/threegen'); await pg.waitForTimeout(300);
  ok(await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'threegen' && await hash(pg) === '#furey/threegen', 'a deep link opens its page and tab');
  await pg.goto('about:blank'); await pg.goto(APP + '#nowhere'); await pg.waitForTimeout(300); const l1 = await pg.evaluate(() => history.length);
  ok(await hash(pg) === '#rule' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('1'), 'an address with no page is corrected to #rule: ' + await hash(pg));
  await pg.goto(APP + '#equations/nothing'); await pg.waitForTimeout(300); const l2 = await pg.evaluate(() => history.length);
  ok(await hash(pg) === '#equations/comm' && l2 === l1 + 1, `an unknown tab is corrected to the first tab without an extra entry (${await hash(pg)}, ${l1} -> ${l2})`);
  await ctx.close(); }

// ---- 2. language attribute, 3. audience remembered
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 }, locale: 'en-GB' }), pg = await ctx.newPage(); onErr(pg, 'settings');
  await pg.goto(APP + '#equations/spin'); await pg.waitForTimeout(300);
  const langs = () => pg.evaluate(() => [document.documentElement.lang, document.querySelector('main')?.getAttribute('lang')].join());
  ok(await langs() === 'en,en', 'English page: html and main say en: ' + await langs());
  const navName = () => pg.locator('nav.story-nav').getAttribute('aria-label');
  ok(await navName() === STORY.en.navLbl, `English page: the page bar is named from STORY.en (${await navName()})`);
  await setLang(pg, 'it'); await pg.waitForTimeout(100);
  ok(await langs() === 'it,it', 'after choosing Italiano: html and main say it: ' + await langs());
  ok(await navName() === STORY.it.navLbl && STORY.it.navLbl !== STORY.en.navLbl, `Italian page: the page bar is named in Italian (${await navName()})`);
  // Escape closes the Settings menu and gives the focus back to its button
  await pg.locator('.story-nav .settings > summary').click(); await pg.waitForTimeout(80); await pg.keyboard.press('Escape'); await pg.waitForTimeout(80);
  ok(await pg.evaluate(() => { const d = document.querySelector('.story-nav .settings'); return !d.open && document.activeElement === d.querySelector('summary'); }), 'Escape closes the Settings menu and the focus returns to its button');
  await pg.locator('[data-profile="Mathematician"]').click();
  // wait until the stored value can be read back before reloading (a reload issued too early could race the write)
  ok(await pg.waitForFunction(() => localStorage.getItem('atlas.audience') === 'Mathematician', null, { timeout: 3000 }).then(() => true, () => false), 'the audience is stored under atlas.audience');
  await pg.reload(); await pg.waitForTimeout(300);
  ok(await langs() === 'it,it', 'after a reload the page still says it: ' + await langs());
  ok((await pg.locator('[data-profile="Mathematician"]').getAttribute('class') || '').includes('active') && await hash(pg) === '#equations/spin', 'after a reload the audience is still Mathematician and the tab still spin');
  await setLang(pg, 'en'); await pg.waitForTimeout(100); ok(await langs() === 'en,en', 'back to English: en again');
  await pg.evaluate(() => localStorage.setItem('atlas.audience', 'Hacker')); await pg.reload(); await pg.waitForTimeout(300);
  ok((await pg.locator('[data-profile="Young Learner"]').getAttribute('class') || '').includes('active'), 'a stored value that is not an audience is ignored (Young Learner)');
  await ctx.close(); }
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } });
  await ctx.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('storage blocked'); } }); });
  const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message));
  await pg.goto(APP + '#rule'); await pg.waitForTimeout(300); await pg.locator('[data-profile="Physicist"]').click(); await pg.waitForTimeout(100);
  ok(!errs.length && (await pg.locator('[data-profile="Physicist"]').getAttribute('class') || '').includes('active') && await pg.locator('.story-nav').count() === 1, 'blocked storage: the page works and the audience can be chosen ' + errs.join(' '));
  await ctx.close(); }

// the Labels · gravity · groups page (7 of 11): a deep link, its button, its three tabs, Next between them
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'labels');
  await pg.goto(APP + '#labels/gauge'); await pg.waitForTimeout(300);
  ok(await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'gauge' && await hash(pg) === '#labels/gauge' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('7'), 'the labels deep link opens the gauge tab on page 7: ' + await hash(pg));
  ok(await pg.locator('.tabbar [role=tab]').count() === 3, 'the labels page has three tabs');
  await pg.locator('.stepnav .sn-next').scrollIntoViewIfNeeded(); await pg.locator('.stepnav .sn-next').click(); await pg.waitForTimeout(200);
  ok(await hash(pg) === '#labels/groups', 'Next on the gauge tab opens the groups tab: ' + await hash(pg));
  await pg.locator('.story-nav > button').nth(5).click(); await pg.waitForTimeout(150); await pg.locator('.story-nav > button').nth(6).click(); await pg.waitForTimeout(150);
  ok((await hash(pg)).startsWith('#labels') && await pg.locator('.tabbar [role=tab][aria-selected="true"]').count() === 1, 'the page button 7 returns to the labels page: ' + await hash(pg));
  await ctx.close(); }
// the Lenses page (8 of 11: the category lens, Baez, Schuller): a deep link, its button, its three tabs, Next between them, the Map button after it
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'lenses');
  await pg.goto(APP + '#lenses/baez'); await pg.waitForTimeout(300);
  ok(await pg.locator('.tabbar [role=tab][aria-selected="true"]').getAttribute('data-tab') === 'baez' && await hash(pg) === '#lenses/baez' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('8'), 'the lenses deep link opens the Baez tab on page 8: ' + await hash(pg));
  ok(await pg.locator('.tabbar [role=tab]').count() === 3, 'the lenses page has three tabs');
  await pg.locator('.stepnav .sn-next').scrollIntoViewIfNeeded(); await pg.locator('.stepnav .sn-next').click(); await pg.waitForTimeout(200);
  ok(await hash(pg) === '#lenses/schuller', 'Next on the Baez tab opens the Schuller tab: ' + await hash(pg));
  await pg.locator('.story-nav > button').nth(6).click(); await pg.waitForTimeout(150); await pg.locator('.story-nav > button').nth(7).click(); await pg.waitForTimeout(150);
  ok((await hash(pg)).startsWith('#lenses') && await pg.locator('.tabbar [role=tab][aria-selected="true"]').count() === 1, 'the page button 8 returns to the lenses page: ' + await hash(pg));
  await ctx.close(); }
// the page for researchers (10 of 11, between the Map and Ask): its button, a deep link to one of its anchors (kept in the address), Back and Next of the pager
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'researchers');
  await pg.goto(APP + '#map'); await pg.waitForTimeout(300);
  await pg.locator('.story-nav > button').nth(9).click(); await pg.waitForTimeout(200);
  ok(await hash(pg) === '#researchers' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('10') && (await pg.locator('.story-nav > button').nth(10).textContent()).startsWith('11'), 'button 10 opens the page for researchers, and Ask is button 11: ' + await hash(pg));
  await pg.goto('about:blank'); await pg.goto(APP + '#researchers/errata'); await pg.waitForTimeout(400);
  ok(await hash(pg) === '#researchers/errata' && (await pg.locator('.story-nav > button.active').textContent()).startsWith('10'), 'a deep link to an anchor of the page opens it and keeps the address: ' + await hash(pg));
  await pg.locator('.story-pager .pg-next').click(); await pg.waitForTimeout(200);
  ok(await hash(pg) === '#ask', 'Next on the page for researchers opens Ask: ' + await hash(pg));
  await pg.goBack(); await pg.waitForTimeout(250);
  ok((await hash(pg)).startsWith('#researchers'), 'Back returns to the page for researchers: ' + await hash(pg));
  await ctx.close(); }

// ---- 4. Next / Previous and the tab bar below the sticky page bar
for (const [w, h, motion] of [[375, 667, 'reduce'], [320, 568, 'reduce'], [1100, 800, 'reduce'], [375, 667, 'no-preference']]) {
  const tag = `${w}x${h} ${motion}`;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, reducedMotion: motion }), pg = await ctx.newPage(); onErr(pg, tag);
  await pg.goto(APP + '#equations/dirac'); await pg.waitForTimeout(300);
  const navH = await pg.evaluate(() => document.querySelector('.story-nav').getBoundingClientRect().height);
  if (w < 700) ok(navH <= 56, `${tag}: the page bar is one short row on a phone (${navH} px)`);
  await pg.locator('.stepnav .sn-next').scrollIntoViewIfNeeded(); await pg.locator('.stepnav .sn-next').click(); await pg.waitForTimeout(motion === 'reduce' ? 150 : 1200);
  const after = await pg.evaluate(() => { const nav = document.querySelector('.story-nav').getBoundingClientRect().bottom, bar = document.querySelector('.tabbar').getBoundingClientRect(), on = document.querySelector('.tabbar .tab.on').getBoundingClientRect(); return { hash: location.hash, nav, bar: bar.top, tabTop: on.top, focus: document.activeElement?.getAttribute('data-tab') }; });
  ok(after.hash === '#equations/coupling', `${tag}: Next opens the next step (${after.hash})`);
  ok(after.bar >= after.nav - 1 && after.bar <= after.nav + 24 && after.tabTop >= after.nav - 1, `${tag}: after Next the tab bar sits just below the page bar (bar ${after.bar}, page bar ends ${after.nav})`);
  ok(after.focus === 'coupling', `${tag}: after Next the keyboard focus is on the new tab (${after.focus})`);
  await pg.locator('.stepnav .sn-prev').scrollIntoViewIfNeeded(); await pg.locator('.stepnav .sn-prev').click(); await pg.waitForTimeout(motion === 'reduce' ? 150 : 1200);
  const back = await pg.evaluate(() => [location.hash, document.querySelector('.tabbar').getBoundingClientRect().top, document.querySelector('.story-nav').getBoundingClientRect().bottom]);
  ok(back[0] === '#equations/dirac' && back[1] >= back[2] - 1 && back[1] <= back[2] + 24, `${tag}: Previous does the same (${back})`);
  await pg.locator('.tabbar [data-tab="ym"]').click(); await pg.waitForTimeout(motion === 'reduce' ? 150 : 1200);
  const tc = await pg.evaluate(() => [document.querySelector('.story-nav').getBoundingClientRect().bottom, document.querySelector('.tabbar .tab.on').getBoundingClientRect().top]);
  ok(tc[1] >= tc[0] - 1, `${tag}: a clicked tab is not hidden under the page bar (tab top ${tc[1]}, page bar ends ${tc[0]})`);
  await ctx.close();
}
// on a phone the page bar scrolls sideways; Settings stays reachable and its menu opens in view
{ const ctx = await b.newContext({ viewport: { width: 320, height: 568 } }), pg = await ctx.newPage(); onErr(pg, '320 settings');
  await pg.goto(APP + '#map'); await pg.waitForTimeout(300);
  const act = await pg.evaluate(() => { const r = document.querySelector('.story-nav > button.active').getBoundingClientRect(); return [r.left, r.right, innerWidth]; });
  ok(act[0] >= 0 && act[1] <= act[2], `320: the active page button is scrolled into view (${act})`);
  await setLang(pg, 'it'); await pg.waitForTimeout(100);
  ok(await pg.evaluate(() => document.documentElement.lang) === 'it', '320: the language can be changed in Settings on a phone');
  await pg.locator('.story-nav .settings > summary').click(); await pg.waitForTimeout(100);
  const pop = await pg.evaluate(() => { const r = document.querySelector('.settings .settings-pop').getBoundingClientRect(); return [r.left, r.right, r.top, r.bottom, innerWidth]; });
  ok(pop[0] >= 0 && pop[1] <= pop[4] && pop[2] > 0 && pop[3] - pop[2] > 40, `320: the Settings menu is fully in view (${pop})`);
  await ctx.close(); }

// ---- 6. the Map's "Go there" buttons: the target starts just below the sticky page bar, not under it (T2-2); wide and reduced motion, phone and smooth scrolling
for (const [w, h, motion, every] of [[1100, 800, 'reduce', 2], [375, 667, 'no-preference', 4]]) {
  const tag = `go there ${w} ${motion}`;
  const ctx = await b.newContext({ viewport: { width: w, height: h }, reducedMotion: motion }), pg = await ctx.newPage(); onErr(pg, tag);
  const openMap = async () => { await pg.locator('.story-nav > button').nth(8).click(); await pg.waitForTimeout(200); await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(100); };
  await pg.goto(APP + '#rule'); await pg.waitForTimeout(300); await openMap();
  const gos = [...new Set(await pg.locator('main button.map-go').evaluateAll(es => es.map(e => e.dataset.go)))].filter(g => g.includes('#'));
  ok(gos.length >= 10, `${tag}: the Map has Go there buttons with anchors (${gos.length})`);
  const sample = gos.filter((g, i) => i % every === 1 || /eq-spin|threegen|charges|gosset/.test(g)), under = [], missing = [];
  for (const g of sample) {
    if (await hash(pg) !== '#map') await openMap();
    const bt = pg.locator(`main button.map-go[data-go="${g}"]`).first(); await bt.scrollIntoViewIfNeeded(); await bt.click(); await pg.waitForTimeout(motion === 'reduce' ? 250 : 1300);
    const r = await pg.evaluate(a => { const el = document.getElementById(a), nav = document.querySelector('.story-nav').getBoundingClientRect().bottom; if (!el) return null;
      return { top: Math.round(el.getBoundingClientRect().top), nav: Math.round(nav), end: scrollY + innerHeight >= document.documentElement.scrollHeight - 2 }; }, g.split('#')[1]);
    if (!r) missing.push(g); else if (r.top < r.nav - 1 || (r.top > r.nav + 24 && !r.end)) under.push(`${g}: top ${r.top}, page bar ends ${r.nav}`);
  }
  ok(sample.length >= 6 && !missing.length, `${tag}: every sampled Go there target exists (${sample.length} sampled; missing ${missing})`);
  ok(!under.length, `${tag}: after Go there the target starts just below the page bar: ${under.join('; ')}`);
  await ctx.close(); }

// ---- 5. the stage chooser of the dictionary is a tablist
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 800 } }), pg = await ctx.newPage(); onErr(pg, 'stages');
  await pg.goto(APP + '#furey/dictionary'); await pg.waitForTimeout(300);
  const L = pg.locator('.d-stages[role=tablist]');
  const info = () => L.evaluate(t => { const tabs = [...t.children]; const sel = tabs.filter(x => x.getAttribute('aria-selected') === 'true'); const p = sel[0] && document.getElementById(sel[0].getAttribute('aria-controls'));
    return { n: tabs.length, roles: tabs.every(x => x.getAttribute('role') === 'tab'), sel: sel.map(x => x.dataset.stage), zero: tabs.filter(x => x.tabIndex === 0).length, panel: !!p && p.getAttribute('role') === 'tabpanel' && p.getAttribute('aria-labelledby') === sel[0].id, pressed: tabs.some(x => x.hasAttribute('aria-pressed')) }; });
  let s = await info();
  ok(s.n === 10 && s.roles && s.sel.join() === '8' && s.zero === 1 && s.panel && !s.pressed, 'ten role=tab children, one selected (8), one in the Tab order, aria-controls names the tabpanel: ' + JSON.stringify(s));
  if (await L.locator('[aria-selected="true"]').count()) await L.locator('[aria-selected="true"]').focus(); else await L.locator('button').nth(8).focus();
  await pg.keyboard.press('ArrowRight'); await pg.waitForTimeout(80);
  s = await info(); const f = await pg.evaluate(() => document.activeElement?.dataset.stage);
  ok(s.sel.join() === '9' && f === '9' && s.zero === 1 && s.panel, 'ArrowRight selects and focuses the next stage: ' + JSON.stringify(s) + ' focus ' + f);
  await pg.keyboard.press('Home'); await pg.waitForTimeout(80); s = await info();
  ok(s.sel.join() === '0' && await pg.evaluate(() => document.activeElement?.dataset.stage) === '0', 'Home selects the first stage');
  await pg.keyboard.press('ArrowLeft'); await pg.waitForTimeout(80); s = await info();
  ok(s.sel.join() === '9', 'ArrowLeft wraps around to the last stage');
  await L.locator('button').nth(3).click(); s = await info(); ok(s.sel.join() === '3' && s.panel, 'a click selects a stage');
  await ctx.close(); }

await b.close();
console.log(bad ? bad + ' FAILURES of ' + n : 'NAV UI OK (' + n + ' checks)'); process.exit(bad ? 1 : 0);
