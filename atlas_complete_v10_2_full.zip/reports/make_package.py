#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Rebuilds the three work-in-progress zips from the shipped report folders and writes MANIFEST.json (sha256 and size of every file in reports/).
Python standard library only.  Deterministic: fixed member order (sorted paths), fixed timestamps (6 October 2026, 12:00), fixed permissions.

    python3 make_package.py            writes zips/category_atlas_wip.zip, zips/baez_wip.zip, zips/schuller_bridge_wip.zip and MANIFEST.json
    python3 make_package.py --check    writes nothing; exit 1 if a zip does not unpack to exactly its folder or MANIFEST.json is not current

A zip holds its folder under the folder's name (category/..., baez/..., schuller/...), so unpacking it next to html/ gives the same tree.  Left out
of zips and manifest: __pycache__, the papers' texts (txt/, never shipped) and editor or system files.  Refused: any e-mail address or mail link in a
text file, and any absolute path of a working machine."""
import hashlib, io, json, os, re, sys, zipfile
HERE = os.path.dirname(os.path.abspath(__file__))
ZIPS = {'category_atlas_wip.zip': 'category', 'baez_wip.zip': 'baez', 'schuller_bridge_wip.zip': 'schuller'}
SKIP_DIRS = {'__pycache__', 'txt', '.git'}
SKIP_FILES = re.compile(r'(\.pyc|~|\.swp|\.DS_Store)$')
TEXT = re.compile(r'\.(py|sh|js|mjs|md|json|html|css|log|txt)$')
MAIL = re.compile(r'[\w.+-]+@[\w-]+(\.[\w-]+)*\.[A-Za-z]{2,}')
MACHINE = re.compile('|'.join(['/tm' + 'p/claude', '/ho' + 'me/claude', 'scratch' + 'pad', '/Us' + 'ers/']))   # written in pieces so that this file does not match itself
DATE = (2026, 10, 6, 12, 0, 0)

def files(root):
    out = []
    for d, dirs, fs in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(fs):
            if not SKIP_FILES.search(f): out.append(os.path.relpath(os.path.join(d, f), HERE).replace(os.sep, '/'))
    return sorted(out)

def clean(rel, data):
    if TEXT.search(rel):
        t = data.decode('utf-8')
        if rel.endswith('.html'): t = re.sub(r'<!--.*?-->', '', t, flags=re.S)
        if MAIL.search(t) or ('mail' + 'to:') in t: sys.exit(f'refused: an e-mail address or a mail link in {rel}')
        if MACHINE.search(t): sys.exit(f'refused: a path of a working machine in {rel}')

def zip_bytes(folder):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for rel in files(os.path.join(HERE, folder)):
            data = open(os.path.join(HERE, rel), 'rb').read(); clean(rel, data)
            info = zipfile.ZipInfo(rel, date_time=DATE); info.create_system = 3; info.external_attr = 0o644 << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buf.getvalue()

def unpacks_to_folder(zpath, folder):
    """True when the zip holds exactly the files of the folder, byte for byte (and nothing else)."""
    with zipfile.ZipFile(zpath) as z:
        members = sorted(i.filename for i in z.infolist() if not i.is_dir())
        want = files(os.path.join(HERE, folder))
        return members == want and all(z.read(m) == open(os.path.join(HERE, m), 'rb').read() for m in members)

def manifest():
    entries = {}
    for rel in files(HERE):
        if rel == 'MANIFEST.json': continue
        data = open(os.path.join(HERE, rel), 'rb').read(); clean(rel, data)
        entries[rel] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
    return json.dumps({'about': 'reports/ of the Cascade Atlas web-app package: sha256 and size of every shipped file (this file excepted); written by make_package.py',
                       'zips': {z: f'{f}/' for z, f in ZIPS.items()}, 'files': entries, 'total_bytes': sum(e['bytes'] for e in entries.values())},
                      ensure_ascii=False, indent=1) + '\n'

if '--check' in sys.argv:
    bad = [z for z, f in ZIPS.items() if not os.path.exists(os.path.join(HERE, 'zips', z)) or not unpacks_to_folder(os.path.join(HERE, 'zips', z), f)]
    m = os.path.join(HERE, 'MANIFEST.json'); man_ok = os.path.exists(m) and open(m, encoding='utf-8').read() == manifest()
    print(('up to date' if not bad and man_ok else 'STALE') + f': zips {"ok" if not bad else "differ: " + ", ".join(bad)}, MANIFEST.json {"current" if man_ok else "stale"}')
    sys.exit(0 if not bad and man_ok else 1)
os.makedirs(os.path.join(HERE, 'zips'), exist_ok=True)
for z, f in ZIPS.items():
    data = zip_bytes(f); open(os.path.join(HERE, 'zips', z), 'wb').write(data)
    assert unpacks_to_folder(os.path.join(HERE, 'zips', z), f)
    print(f'wrote zips/{z}: {len(files(os.path.join(HERE, f)))} files, {len(data)} bytes')
open(os.path.join(HERE, 'MANIFEST.json'), 'w', encoding='utf-8').write(manifest())
print(f'wrote MANIFEST.json: {len(files(HERE)) - 1} files')
