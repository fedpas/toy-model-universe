# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The second-pass section of the report: fibre and base (findings F10-F15) and its figures.  Imported by build_report.py.
Every number drawn here is computed in this module from the same definitions as fibre_check.py (transfer matrices, F4 Coxeter element, E8 roots, the F_2 quadric formulas)
or read from logs/fibre_check_final.log by the caller; the names of the root systems are identifications by root count and rank."""
import math, itertools, random
import numpy as np

SUB = '₀₁₂₃₄₅₆₇₈₉'
def sub(n): return ''.join(SUB[int(c)] for c in str(n))
BB = {'R': 'ℝ', 'C': 'ℂ', 'H': 'ℍ'}

def cl_name(p, q, TYPES):
    """name of Cl(p,q) as M_m(D) or M_m(D) + M_m(D), from the clock type and the dimension"""
    n = p + q; t = TYPES[(p - q) % 8]; f = 2 if t.endswith('2') else 1; d = {'R': 1, 'C': 2, 'H': 4}[t[0]]
    m = round(math.sqrt(2 ** n / (f * d))); assert f * d * m * m == 2 ** n
    one = (f'M{sub(m)}({BB[t[0]]})' if m > 1 else BB[t[0]])
    return one + (' ⊕ ' + one if f == 2 else '')

def name_from_dim(dim, t):
    f = 2 if t.endswith('2') else 1; d = {'R': 1, 'C': 2, 'H': 4}[t[0]]
    m = round(math.sqrt(dim / (f * d))); assert f * d * m * m == dim, (dim, t)
    one = (f'M{sub(m)}({BB[t[0]]})' if m > 1 else BB[t[0]])
    return one + (' ⊕ ' + one if f == 2 else '')

# ---------------------------------------------------------------------------------------------------------------- figures
def descent_svg(TYPES, tip):
    """Fig. D: n = 8 fixed; base = first k gamma (type of Cl(0,k)), fibre = commutant (dimension 2^(8-k), same type)"""
    unit = 27; x0 = 168; rowh = 31; top = 40; W = 560; H = top + 9 * rowh + 34
    out = [f'<svg class="chart fx" viewBox="0 0 {W} {H}" role="img" aria-label="Eight units of total dimension; stepping the base down from 8 to 0 moves units from base to fibre">']
    out.append(f'<text class="t2" x="{x0}" y="14">8 units = dimension 2⁸ = 256</text>')
    out.append(f'<text class="t2" x="8" y="{top - 8}">k · base Cl(0,k)</text><text class="t2" x="{W - 8}" y="{top - 8}" text-anchor="end">fibre (commutant)</text>')
    for r, k in enumerate(range(8, -1, -1)):
        y = top + r * rowh
        bt = TYPES[(-k) % 8]; bname = cl_name(0, k, TYPES) if k else 'ℝ'
        fdim = 2 ** (8 - k); fname = name_from_dim(fdim, bt)
        t = tip(f'k = {k}: base Cl(0,{k}) = {bname}, dimension {2 ** k}', f'fibre (commutant in End(ℝ¹⁶)) = {fname}, dimension {fdim}', f'type of both: {bt} (the clock row c = {(-k) % 8})', 'computed: fibre_check G3b–G3e')
        out.append(f'<g data-tip="{t}" tabindex="0">')
        out.append(f'<text class="t" x="8" y="{y + 17}"><tspan font-weight="700">{k}</tspan> · {bname}</text>')
        if k: out.append(f'<rect class="ds-b" x="{x0}" y="{y}" width="{k * unit}" height="{rowh - 6}" rx="3"/><text class="ds-bt" x="{x0 + k * unit / 2}" y="{y + 16}" text-anchor="middle">{2 ** k}</text>')
        if k < 8: out.append(f'<rect class="ds-f" x="{x0 + k * unit}" y="{y}" width="{(8 - k) * unit}" height="{rowh - 6}" rx="3"/><text class="ds-ft" x="{x0 + k * unit + (8 - k) * unit / 2}" y="{y + 16}" text-anchor="middle">{fdim}</text>')
        out.append(f'<text class="t" x="{W - 8}" y="{y + 17}" text-anchor="end">{fname if k < 8 else "ℝ"}</text></g>')
    out.append(f'<text class="t2" x="8" y="{top + 9 * rowh + 14}">dark: base, k units (dimension 2ᵏ)</text><text class="t2" x="8" y="{top + 9 * rowh + 30}">light: fibre, 8 − k units (dimension 2⁸⁻ᵏ)</text>')
    out.append('</svg>')
    return ''.join(out)

def trans(kap2, l):
    if abs(kap2) < 1e-14: return np.array([[1, l], [0, 1.]])
    if kap2 > 0:
        k = math.sqrt(kap2); return np.array([[math.cos(k * l), math.sin(k * l) / k], [-k * math.sin(k * l), math.cos(k * l)]])
    q = math.sqrt(-kap2); return np.array([[math.cosh(q * l), math.sinh(q * l) / q], [q * math.sinh(q * l), math.cosh(q * l)]])

def gamma_of(E, cell):
    M = np.eye(2)
    for (l, V) in cell: M = trans(E - V, l) @ M
    return 0.5 * np.trace(M), M

BAND_CELL = [(0.8, 0.0), (0.5, 5.0)]
def band_data(Emax=60.0, n=2400):
    Es = np.linspace(0.0, Emax, n); g = np.array([gamma_of(E, BAND_CELL)[0] for E in Es])
    edges = []; prev = abs(g[0]) <= 1
    for E0, E1, a, b in zip(Es[:-1], Es[1:], g[:-1], g[1:]):
        cur = abs(b) <= 1
        if cur != prev:
            lo, hi = E0, E1
            for _ in range(70):
                mid = (lo + hi) / 2
                if (abs(gamma_of(mid, BAND_CELL)[0]) <= 1) == prev: lo = mid
                else: hi = mid
            edges.append((lo + hi) / 2)
        prev = cur
    return Es, g, edges

def bands_svg(tip):
    Es, g, edges = band_data()
    W, H = 560, 280; x0, x1, y0, y1 = 40, 548, 30, 232; ymax = 2.6
    X = lambda E: x0 + (x1 - x0) * E / Es[-1]
    Y = lambda v: y1 - (y1 - y0) * (max(-ymax, min(ymax, v)) + ymax) / (2 * ymax)
    out = [f'<svg class="chart fx" viewBox="0 0 {W} {H}" role="img" aria-label="Half the trace of the one-period matrix against energy, with bands where it lies between minus one and one">']
    bounds = [0.0] + edges + [float(Es[-1])]
    for a, b in zip(bounds[:-1], bounds[1:]):
        mid = (a + b) / 2
        inside = abs(gamma_of(mid, BAND_CELL)[0]) <= 1
        if inside:
            t = tip(f'band: E from {a:.2f} to {b:.2f}', '|½Tr M| ≤ 1, X² < 0 inside: elliptic', 'edges: X² = 0 (parabolic)')
            out.append(f'<rect class="bd-shade" data-tip="{t}" tabindex="0" x="{X(a):.1f}" y="{y0}" width="{max(X(b) - X(a), 1):.1f}" height="{y1 - y0}"/>')
    for v, lab in ((1, '+1'), (-1, '−1')):
        out.append(f'<line class="bd-ref" x1="{x0}" x2="{x1}" y1="{Y(v):.1f}" y2="{Y(v):.1f}"/><text class="t2" x="{x0 - 6}" y="{Y(v) + 4:.1f}" text-anchor="end">{lab}</text>')
    out.append(f'<line class="bd-ax" x1="{x0}" x2="{x1}" y1="{y1}" y2="{y1}"/><line class="bd-ax" x1="{x0}" x2="{x0}" y1="{y0}" y2="{y1}"/>')
    pts = ' '.join(f'{X(E):.1f},{Y(v):.1f}' for E, v in zip(Es, g))
    out.append(f'<polyline class="bd-curve" points="{pts}"/>')
    for e in edges:
        gm, M = gamma_of(e, BAND_CELL)
        t = tip(f'band edge at E = {e:.3f}', f'½Tr M = {gm:+.6f}', 'X² = 0 with X ≠ 0: the null (parabolic) element', 'a Jordan block: the periodic or antiperiodic solution')
        out.append(f'<circle class="bd-edge" data-tip="{t}" tabindex="0" cx="{X(e):.1f}" cy="{Y(gm):.1f}" r="4.5"/>')
    for E in range(0, int(Es[-1]) + 1, 10): out.append(f'<text class="t2" x="{X(E):.1f}" y="{y1 + 16}" text-anchor="middle">{E}</text>')
    out.append(f'<text class="t2" x="{(x0 + x1) / 2}" y="{y1 + 34}" text-anchor="middle">energy E (ħ²/2m = 1); widths 0.8 at V = 0, 0.5 at V = 5</text>')
    out.append(f'<text class="t2" x="{x0}" y="16">γ(E) = ½ Tr M(E), scalar part of M ∈ Cl(2,0); clipped at ±{ymax}</text>')
    out.append('</svg>')
    return ''.join(out), edges

def coxeter_points():
    vec = []
    for i in range(4):
        for s in (1, -1):
            v = [0.0] * 4; v[i] = float(s); vec.append((tuple(v), 'v'))
    sp = []
    for sg in itertools.product((1, -1), repeat=4):
        sp.append((tuple(0.5 * s for s in sg), 'e' if sum(1 for s in sg if s < 0) % 2 == 0 else 'o'))
    pts = vec + sp
    f4 = [np.array(x) for x in [(0, 1, -1, 0), (0, 0, 1, -1), (0, 0, 0, 1), (.5, -.5, -.5, -.5)]]
    refl = lambda r: np.eye(4) - 2 * np.outer(r, r) / (r @ r)
    cox = refl(f4[0]) @ refl(f4[1]) @ refl(f4[2]) @ refl(f4[3])
    w, v = np.linalg.eig(cox)
    k = [i for i in range(4) if abs(np.angle(w[i]) - 2 * math.pi / 12) < 1e-6][0]
    ux = v[:, k].real; uy = v[:, k].imag; ux = ux / np.linalg.norm(ux); uy = uy - (uy @ ux) * ux; uy = uy / np.linalg.norm(uy)
    return pts, ux, uy

def cell24_svg(tip):
    pts, ux, uy = coxeter_points()
    P = np.array([p for p, c in pts]); S = 150.0 / 0.888
    xy = [(float(p @ ux) * S, float(p @ uy) * S) for p in P]
    W, H = 380, 350; cx, cy = W / 2, H / 2 + 4
    out = [f'<svg class="chart fx" viewBox="0 0 {W} {H}" role="img" aria-label="The 24 weights of the three eight-dimensional representations of Spin(8), projected to the Coxeter plane of F4">']
    # edges: inner product 1/2
    for i in range(24):
        for j in range(i + 1, 24):
            if abs(P[i] @ P[j] - 0.5) < 1e-9:
                out.append(f'<line class="c24-edge" x1="{cx + xy[i][0]:.1f}" y1="{cy - xy[i][1]:.1f}" x2="{cx + xy[j][0]:.1f}" y2="{cy - xy[j][1]:.1f}"/>')
    names = {'v': 'vector 8 (±eₖ)', 'e': 'even spinor 8', 'o': 'odd spinor 8'}
    for (p, c), (x, y) in zip(pts, xy):
        X, Y = cx + x, cy - y
        t = tip(names[c], 'weight (' + ', '.join('%+g' % u for u in p) + ')', 'class = parity of minus signs for spinors (chirality of the top blade)')
        if c == 'v': out.append(f'<circle class="c24-v" data-tip="{t}" tabindex="0" cx="{X:.1f}" cy="{Y:.1f}" r="7"/>')
        elif c == 'e': out.append(f'<rect class="c24-e" data-tip="{t}" tabindex="0" x="{X - 6.5:.1f}" y="{Y - 6.5:.1f}" width="13" height="13" rx="1.5"/>')
        else: out.append(f'<path class="c24-o" data-tip="{t}" tabindex="0" d="M{X:.1f},{Y - 8:.1f} L{X + 8:.1f},{Y + 6:.1f} L{X - 8:.1f},{Y + 6:.1f} Z"/>')
    out.append('</svg>')
    return ''.join(out)

def e8_ladder():
    roots = []
    for i in range(8):
        for j in range(i + 1, 8):
            for si in (1, -1):
                for sj in (1, -1):
                    v = [0] * 8; v[i] = 2 * si; v[j] = 2 * sj; roots.append(tuple(v))
    for signs in itertools.product((1, -1), repeat=8):
        if sum(1 for s in signs if s < 0) % 2 == 0: roots.append(tuple(signs))
    R = np.array(roots); G = (R @ R.T) // 4
    rr = random.Random(5)
    S = [s for s in range(240) if G[s, 0] == 1]; Ro = [s for s in range(240) if G[s, 0] == 0]
    rk = lambda idx: int(np.linalg.matrix_rank(R[idx])) if idx else 0
    rows = [(0, None, 240, 8), (1, len(S), len(Ro), rk(Ro))]
    for j in range(2, 6):
        c = S[rr.randrange(len(S))]
        Ro = [s for s in Ro if G[s, c] == 0]; S = [s for s in S if G[s, c] == 1]
        rows.append((j, len(S), len(Ro), rk(Ro)))
    return rows

ROOTSYS = {240: 'E₈', 126: 'E₇', 72: 'E₆', 40: 'D₅', 20: 'A₄', 8: 'A₂ + A₁'}
LINKREP = {56: '56 of E₇', 27: '27 of E₆', 16: '16 of SO(10)', 10: '10 of SU(5)', 6: '(3,2) of SU(3)×SU(2)'}

def gosset_html(tip):
    rows = e8_ladder()
    h = ['<div style="overflow-x:auto"><table class="gs"><thead><tr><th>step</th><th>common neighbours (link)</th><th colspan="2">roots orthogonal to the chain</th><th>the layer, as a weight set (recalled)</th></tr></thead><tbody>']
    for j, link, orth, rank in rows:
        lk = '—' if link is None else f'<span class="gs-n">{link}</span><span class="gs-bar" style="width:{max(2, round(100 * link / 56))}px"></span>'
        h.append(f'<tr><td class="num">{j}</td><td>{lk}</td><td><span class="gs-n">{orth}</span><span class="gs-bar gs-bar2" style="width:{max(2, round(100 * orth / 240))}px"></span></td><td style="white-space:nowrap">{ROOTSYS[orth]} · rank {rank}</td><td>{LINKREP.get(link, "—") if link else "—"}</td></tr>')
    h.append('</tbody></table></div>')
    return ''.join(h), rows

def triality_table():
    pts = lambda m: (2 ** m - 1) * (2 ** (m - 1) + 1)
    fam = lambda m: math.prod(2 ** i + 1 for i in range(1, m))
    h = ['<div style="overflow-x:auto"><table class="gs"><thead><tr><th>m</th><th>n = 2m</th><th class="num">singular points</th><th class="num">solids, one family</th><th></th></tr></thead><tbody>']
    for m in range(1, 9):
        same = pts(m) == fam(m)
        trc = ' class="hl"' if same else ''
        h.append(f'<tr{trc}><td class="num">{m}</td><td class="num">{2 * m}</td><td class="num">{pts(m)}</td><td class="num">{fam(m)}</td><td>{"equal: triality" if same else ""}</td></tr>')
    h.append('</tbody></table></div>')
    return ''.join(h), [m for m in range(1, 13) if pts(m) == fam(m)]

# ---------------------------------------------------------------------------------------------------------------- the section
def build(finding, chip, E, tip, TYPES, nchecks, nmut, g5e_edges):
    DESC = descent_svg(TYPES, tip)
    BANDS, edges = bands_svg(tip)
    C24 = cell24_svg(tip)
    GS, grows = gosset_html(tip)
    TT, tri = triality_table()
    assert tri == [4]
    assert [r[2] for r in grows] == [240, 126, 72, 40, 20, 8] and [r[1] for r in grows[1:]] == [56, 27, 16, 10, 6]
    n_edges = g5e_edges

    F10_fig = ('<div class="figtitle">A acting on itself</div>'
        '<div class="aa"><div class="aa-b"><b>left</b> L<sub>i</sub><br>base<br><span>Cl(1,3) = M₂(ℍ)</span></div>'
        '<div class="aa-x">⊗̂</div>'
        '<div class="aa-f"><b>twisted right</b> R′<sub>j</sub><br>fibre = mirror<br><span>Cl(3,1) = M₄(ℝ)</span></div>'
        '<div class="aa-eq">=</div>'
        '<div class="aa-t"><b>End(A)</b><br>Cl(4,4)<br><span>M₁₆(ℝ)</span></div></div>'
        '<table class="gs" style="margin-top:12px"><thead><tr><th>right action</th><th>with L</th><th>squares</th><th>fibre type</th></tr></thead><tbody>'
        '<tr><td>plain R<sub>j</sub></td><td>commutes</td><td>ε<sub>j</sub></td><td>same as the base (commutant)</td></tr>'
        '<tr><td>twisted R′<sub>j</sub></td><td>anticommutes</td><td>−ε<sub>j</sub></td><td>mirror Cl(q,p)</td></tr></tbody></table>'
        '<figcaption>Shown at n = 4. Computed for all 20 signatures with n ≤ 5 (the table of types for n ≤ 12). The mirror is the inverse in the Brauer–Wall group ℤ/8.</figcaption>')
    F10 = finding('F10', 'Locally a product, and left and right are base and fibre', ['checked', 'standard', 'ours'],
        '<p><b>Product.</b> Take the base Cl(1,3) and a fibre Cl(0,3). A blade of the total algebra is a pair (base label | fibre label): the labels concatenate, and the product of two such blades is the product of the parts times (−1)<sup>|b||c|</sup>. That is the graded tensor product, and the total is Cl(1,6). The fibre’s three bivectors commute with every base generator and with the six Lorentz bivectors; a single fibre generator anticommutes with every base generator; the three bivectors close into so(3) = su(2). So “walking on the base while carrying the fibre” has an algebraic form: Spin(base) and Spin(fibre) act on one algebra and commute.</p>'
        '<p><b>Left and right.</b> An algebra A = Cl(p,q) acts on itself from the left (L<sub>i</sub>) and from the right (R<sub>j</sub>). The two commute. With the grading twist R′<sub>j</sub>x = (−1)<sup>|x|</sup>x e<sub>j</sub> the right action instead anticommutes with the left and squares to −ε<sub>j</sub>: the 2n operators obey the bit rule of Cl(n,n) with signature (ε | −ε). So A acts on itself through A ⊗̂ mirror(A) = Cl(n,n) = M<sub>2ⁿ</sub>(ℝ), exactly End(A). The mirror is the inverse in the Brauer–Wall group: the two clocks add to 0 mod 8 for every n ≤ 12, so the pair is always of type ℝ. At n = 4 the fibre of Cl(1,3) has signature (−,+,+,+): Cl(3,1), the one the quantum notes print for Dirac, and the total Cl(4,4) = M₁₆(ℝ) is isomorphic as an algebra to the End(V) of the atlas’s Furey page (generators not matched; not a Lorentz frame).</p>'
        '<p class="not">Two fibres, not to be mixed: the commuting one (plain right action, the commutant, same type as the base: used in F11) and the anticommuting one (twisted right action, the mirror). For odd n the pseudoscalar is central, so left and right overlap through it and base and fibre are not independent. All of this is local; how fibres are glued over a manifold is the gap L4. Convention: here the base is the left action and the fibre the (twisted) right action; reversion x ↦ x̃ exchanges left and right, so the opposite labelling is equally valid.</p>'
        '<p class="ids">checks G1a–c, G2a–d.</p>', F10_fig)

    F11 = finding('F11', 'Keep the 8 fixed and step the base down: the fibre fills', ['checked', 'standard', 'ours'],
        '<p>Fix V = ℝ¹⁶ and eight real 16×16 matrices γ<sub>1</sub>…γ<sub>8</sub> that anticommute and square to −1: Cl(0,8) = M₁₆(ℝ) acts on V. Let the <em>base</em> be the algebra of the first k of them and the <em>fibre</em> its commutant in End(V). Computed for k = 0…8: the fibre has dimension 256, 128, 64, 32, 16, 8, 4, 2, 1 = 2<sup>8−k</sup>; the commutant of the fibre is the base again; the two have the same centre (dimension 1 for k even, 2 for k odd). The product of the dimensions stays 2⁸: stepping the base down by one frees one generator and doubles the fibre.</p>'
        '<p>The fibre can be written down. For k even it is generated by h<sub>j</sub> = ω<sub>k</sub>γ<sub>j</sub> (j &gt; k), the freed generators dressed with the top blade ω<sub>k</sub> of the base; these commute with the base and are Cl(0,8−k) or Cl(8−k,0). For k odd it is generated by the even products γ<sub>i</sub>γ<sub>j</sub> (i, j &gt; k) together with the central ω<sub>k</sub>. Their types run ℝ, ℂ, ℍ, ℍ², ℍ, ℂ, ℝ, ℝ², ℝ as k = 0…8, the same sequence as the base Cl(0,k): the clock again. In the words of the request: yes, the stepping down populates the fibre, and the 8 stays fixed because the freed generators do not disappear, they reappear dressed in the fibre.</p>'
        '<p class="not">This is the algebraic commutant, a statement about generators and dimensions. That the fibre of the physical Lorentz base is this commutant, and what lives in it (the gauge steps 4 and 16 of the atlas), is a reading and is not tested here. The double-centraliser theorem behind the type sequence is standard; the dimensions, centres and explicit generators are computed.</p>'
        '<p class="ids">checks G3a–e.</p>',
        '<div class="figtitle">Eight units, stepped down</div>' + DESC + '<figcaption>Each row is one k. Dark: the base, 2ᵏ-dimensional. Light: its commutant, 2⁸⁻ᵏ-dimensional. Left and right: the algebras (M<sub>m</sub>(D) with D = ℝ, ℂ, ℍ). Hover for the details. With the atlas’s own addresses: k = 1 is ℂ (the phase), k = 2 is ℍ (SU(2), F5), k = 4 is isomorphic as an algebra to Cl(1,3) = M₂(ℍ), k = 8 to the M₁₆(ℝ) of the Furey page (isomorphic as algebras only: the generators are not matched and are not a Lorentz frame; our reading of what each stage is for).</figcaption>')

    F12_fig = ('<div class="figtitle">One extra direction, three signs</div>'
        '<table class="gs"><thead><tr><th>fibre direction squares</th><th>total</th><th>shell P² = 0</th><th>verdict</th></tr></thead><tbody>'
        '<tr><td>−1 (like space)</td><td>Cl(1,4)</td><td>E² = |p|² + m²</td><td>hyperbolic, real mass</td></tr>'
        '<tr><td>0 (null)</td><td>Cl(1,3,1)</td><td>E² = |p|²</td><td>m is frozen out: massless</td></tr>'
        '<tr><td>+1 (a second time)</td><td>Cl(2,3)</td><td>E² = |p|² − m²</td><td>not hyperbolic: excluded (F2)</td></tr></tbody></table>'
        '<figcaption>The Cl(1,3,1) row is read from the shell formula (a null direction never enters the determinant, T16); only the −1 and +1 rows are computed as cells (G4a, G4d).</figcaption>'
        '<div class="figtitle" style="margin-top:12px">At n = 4 the direction is inside the algebra</div>'
        '<p style="font-size:14px">In Cl(1,3) the pseudoscalar ω = e₀₁₂₃ squares to −1 and anticommutes with all four generators, so for P = E e₀ + p·e: <code>(P + mω)² = E² − |p|² − m²</code>. In Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ) the fifth generator is e₄ = −ω₄ω₅, with ω₅ = ±1 on the two summands.</p>')
    F12 = finding('F12', 'A momentum along an extra space-like direction enters as a mass; a time-like one breaks hyperbolicity; a null one never enters', ['checked', 'standard', 'ours'],
        '<p>Put a Dirac-type operator on base × fibre: P<sub>tot</sub> = P<sub>base</sub> + m f, where f is a fibre generator (anticommuting with the base) and m the momentum along it. Then P<sub>tot</sub>² = P² + m²f², and the shell P<sub>tot</sub>² = 0 reads E² = |p|² − ε<sub>f</sub>m². With ε<sub>f</sub> = −1, a direction that squares like space, this is the mass shell E² = |p|² + m²; with ε<sub>f</sub> = +1 it is tachyonic. This is the Kaluza–Klein statement (standard). Adding a fibre direction of signature (f<sub>+</sub>, f<sub>−</sub>) to Cl(1,3) keeps one time direction, hence real mass shells, exactly when f<sub>+</sub> = 0: a time-like extra direction breaks hyperbolicity (F2; checked for the nine signatures with f<sub>±</sub> ≤ 2, using F2’s criterion), and a null direction never enters the determinant (T16). (The first version of this page put this as a slogan about mass and the fibre; see Corrections, E-056.)</p>'
        '<p>At n = 4 the extra direction is already inside the algebra: the pseudoscalar of Cl(1,3) squares to −1 and anticommutes with every generator, so (P + mω)² = E² − |p|² − m² exactly (60 integer samples). In Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ) the fifth generator is e₄ = −ω₄ω₅, and the two summands (the central ω₅ = ±1) carry the two signs of m.</p>'
        '<p><b>The Dirac sign flag (F9), located and corrected (5 October 2026).</b> In the notes’ convention Cl(3,1) = M₄(ℝ) the pseudoscalar mass term gives (P + mω)² = |p|² − E² − m²: the wrong shell, E² = |p|² − m². The physical sign does <i>not</i> need a central i: the real operator γ<sup>μ</sup>∂<sub>μ</sub> − m of Cl(3,1) already has it, because (γ∂ − m)(γ∂ + m) = ∇² − ∂<sub>t</sub>² − m² is minus the Klein–Gordon operator; on a plane wave the i is the Fourier i of ∂ → ip, not an element of the algebra (G4b, exact in five shells; with real 4×4 matrices, momentum (0.3, −0.2, 0.5) and m = 0.7 the zero is at E = 0.933 = √(p² + m²)). The factor i printed in (iγ∂ − m) is the slip; it belongs to the Cl(1,3) convention. In Cl(1,3) no such issue arises. The first version of this page said the i had to come from the fibre; a physicist reviewer found that this is wrong and I re-checked it independently.</p>'
        '<p class="not">Ours: reading a mass as coming from the fibre of the descent in F11. The Kaluza–Klein form of it is standard; nothing here says which fibre direction a physical mass is.</p>'
        '<p class="ids">checks G4a–d.</p>', F12_fig)

    F13 = finding('F13', 'The bands of chapter 20 are the elliptic, parabolic and hyperbolic classes of SL(2,ℝ)', ['checked', 'standard', 'ours'],
        '<p>Chapter 20 of the quantum notes gives the one-period matrix M<sup>E</sup>(a) of a periodic potential, with det M = 1 (his Lemma 20.8), and calls ½Tr M = cos θ; an energy is allowed when this lies in [−1, 1]. A real 2×2 matrix of determinant 1 is a unit multivector of Cl(2,0) = M₂(ℝ), and ½Tr M is its scalar part. Write M = γ + X with X the rest: X² = b² + c² − d² is a scalar. Then <b>a band is X² &lt; 0</b> (the multipliers are e<sup>±iθ</sup>), <b>a gap is X² &gt; 0</b> (real multipliers, product 1), and <b>a band edge is X² = 0 with X ≠ 0</b> (a Jordan block: the periodic or antiperiodic solution). Computed on 500 random potentials and energies, and on one fixed potential where ' + str(n_edges) + ' band edges were found by bisection: at each, X² vanishes to 1e-7.</p>'
        '<p>The pieces of a potential are the three elements. Free flight above the potential is cos kl + sin kl · n with n² = −1; below it, cosh + sinh · n with n² = +1; a delta kick is 1 + g n with n² = 0. The Dirac comb condition cos θ = cos kl + (g/2k) sin kl is the scalar part of (null)(elliptic). The scalar part of M<sup>N</sup> is the Chebyshev polynomial T<sub>N</sub>(γ) in both phases. This is the textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ) (T19); grouping it with the trio −1, 0, +1 of F3 as band, edge, gap is ours. An edge needs X ≠ 0: M = ±I has X = 0 and bounded powers (two bands touch there and no gap opens), so “|tr M| = 2 iff X² = 0, parabolic, linear growth” is too strong without that condition (as T19 (1) is stated in the round-2 derivations).</p>'
        '<p class="not">Two wording points about the notes, not about the lecturer: the trace is written ψ₁(a) + ψ₂(a) where ψ₁(a) + ψ₂′(a) is meant (they differ in the checks); and the spectrum is called a union of open intervals, while the standard statement has closed bands, the edges (the parabolic points) included. Ours: calling the three classes “the trio”. Not done: any infinite-dimensional statement (rigged Hilbert space, the spectrum of the operator), only the one-period matrix.</p>'
        '<p class="ids">checks G5a–f.</p>',
        '<div class="figtitle">Bands and edges of one periodic potential</div>' + BANDS +
        '<div class="legend"><span><i class="sw" style="background:var(--s);opacity:.35">▮</i> band: X² &lt; 0, elliptic</span><span><i class="sw" style="border:1px solid var(--line2)">▯</i> gap: X² &gt; 0, hyperbolic</span><span><i class="sw" style="background:var(--ours)">●</i> edge: X² = 0 with X ≠ 0, parabolic</span></div>'
        '<figcaption>Computed here from the Clifford form of the transfer matrix (E ≤ 60 shown; the check G5e finds ' + str(n_edges) + ' edges up to E = 90); G5b compares the matrix with a numerical integration of ψ″ = (V − E)ψ.</figcaption>')

    F14 = finding('F14', 'Three 8s: the 24 at n = 2, at n = 8, and the Golay 24', ['checked', 'standard', 'ours', 'open'],
        '<p><b>n = 2.</b> In Cl(0,2) = ℍ, ω = (−1 + e₁ + e₂ + e₁₂)/2 has order 3; with Q₈ = {±1, ±e₁, ±e₂, ±e₁₂} it generates the binary tetrahedral group of order 24 = Q₈ ∪ ωQ₈ ∪ ω²Q₈. The 16 elements with all coefficients ±½ split 8 + 8 by the parity of the number of minus signs. Conjugation by ω cycles e₁ → e₁₂ → e₂ → e₁, a 3-cycle on the three non-zero labels of F₂². As points of ℝ⁴ the 24 elements are the 24-cell: every vertex has 8 neighbours.</p>'
        '<p><b>n = 8.</b> On V = ℝ¹⁶ = 8<sub>s</sub> ⊕ 8<sub>c</sub> take the Cartan elements H<sub>k</sub> = ½γ<sub>2k</sub>γ<sub>2k+1</sub>. The 16 spinor weights are the vectors (±½)⁴, the 8 weights of the vector (the action on the γ’s) are ±e<sub>k</sub>: the 24 weight vectors <em>are</em> the 24 elements above, as points of ℝ⁴. The chirality of the top blade is the parity of minus signs, the same rule that separates ωQ₈ from ω²Q₈. The three 8s are pairwise inequivalent (traces at random group elements differ). The triality is a rotation of the picture: the Coxeter element of F₄ has order 12, and its fourth power, a 120° rotation of the Coxeter plane, sends vector → odd spinor → even spinor → vector.</p>'
        '<p><b>Over F₂.</b> The quadric x₁x₂ + x₃x₄ + … on F₂<sup>2m</sup> has (2<sup>m</sup>−1)(2<sup>m−1</sup>+1) singular points and ∏(2<sup>i</sup>+1) maximal totally singular subspaces in each of two families. These are equal only at m = 4 (checked for m = 1…12): 135 = 135 = 135, each point on 15 solids of each family. The triality of O⁺(8,2) exists at n = 8 and at no other n.</p>'
        '<p><b>n = 24.</b> Three 8-bit bricks (a + x | b + x | a + b + x), a, b in the extended Hamming code and x in a second copy with permuted coordinates, build the extended Golay code: 4096 words, weights 0, 8, 12, 16, 24, with 759 octads. In the bit rule the 16 Hamming labels give blades that commute and square to +1 in Cl(0,8), a maximal diagonalising set whose 16 sign patterns are the 16 coordinates of ℝ¹⁶; the 4096 Golay labels do the same in Cl(0,24) = M₄₀₉₆(ℝ).</p>'
        '<p class="not">Ours/open: a cyclic order of three has no starting point, so a literal “before, now, after” reading would need an extra choice; nothing here says whether the three 8s of Spin(8) and the three bricks of the Golay code are the same triple. The identification of the three 8s with what the atlas’s Furey page calls one generation is not tested. The general statement behind the Golay–Cl(0,24) computation is now a theorem: a doubly-even self-dual code of length n is a maximal totally singular subspace of the label form through the pseudoscalar, and one exists iff 8 | n (T14 of the round-2 derivations, stated for Cl(n,0)).</p>'
        '<p class="ids">checks G6a–c, G7a–e, G9a–b.</p>',
        '<div class="figtitle">The 24 weights in the Coxeter plane of F₄</div>' + C24 +
        '<div class="legend" style="justify-content:center"><span><b style="color:var(--e)">●</b> vector 8</span><span><b style="color:var(--s)">■</b> even spinor 8</span><span><b style="color:var(--ours)">▲</b> odd spinor 8</span></div>'
        '<figcaption>Two rings of 12, four points of each class on each ring. A 120° rotation (the 4th power of the Coxeter element) sends ● → ▲ → ■ → ●. Lines join the 96 pairs at inner product ½.</figcaption>'
        '<div class="figtitle" style="margin-top:14px">Points against solids on the quadric O⁺(2m,2)</div>' + TT)

    F15 = finding('F15', 'Stepping down the Gosset polytope: 240 → 126 → 72 → 40 → 20 → 8', ['checked', 'standard', 'open'],
        '<p>The 240 roots of E₈ are the vertices of the Gosset polytope 4<sub>21</sub>. Step down by choosing a root and keeping its neighbours (inner product 1), then repeating inside the neighbours. The sizes of the layers are 56, 27, 16, 10, 6, 3 (all 240 first choices and all 56 second choices were tried, deeper levels sampled): the vertex counts of 3<sub>21</sub>, 2<sub>21</sub>, 1<sub>21</sub>, the rectified 5-cell, the triangular prism, and the three neighbours of a prism vertex. The roots <em>orthogonal</em> to the chain form root systems of 126, 72, 40, 20, 8 roots, of rank 7, 6, 5, 4, 3: named E₇, E₆, D₅, A₄, A₂ + A₁ from count and rank only (the Cartan matrices were not computed, and count and rank alone do not fix a root system: B₃ and C₃ both have 18 roots and rank 3), and each step splits the previous system as R<sub>j−1</sub> = R<sub>j</sub> + 2 × (link) (plus 2 at the first step): 240 = 126 + 2·56 + 2, 126 = 72 + 2·27, 72 = 40 + 2·16, 40 = 20 + 2·10, 20 = 8 + 2·6.</p>'
        '<p>So the descent has the same shape as in F11, one layer freed per step, with the layer’s size read off the polytope. The numbers 56, 27, 16, 10, (3,2) are the dimensions of the minimal representations of E₇, E₆, SO(10), SU(5) and SU(3)×SU(2): the chain of the grand-unification literature. That is recalled, not recomputed here.</p>'
        '<p class="not">Open and ours: reading each freed layer as the fibre representation at that step, and the last row as quarks and leptons, is a proposal and is not tested against any dynamics. What is computed is the combinatorics of the roots. The last two steps of the vertex-figure tower (triangle, segment, point) are not computed in root coordinates.</p>'
        '<p class="ids">checks G8a–c.</p>',
        '<div class="figtitle">The ladder, computed from the 240 roots</div>' + GS +
        '<figcaption>Left bars: link sizes (scale 56). Right bars: orthogonal root counts (scale 240). The last column is recalled and is not computed.</figcaption>')

    INTRO = ('<p class="lead">The request, in three parts. (1) Locally the whole is base × fibre, and we walk on the base carrying the fibre: is that the bit rule’s own product? (2) Base and fibre as the left and right action of the algebra on itself: do they match? (3) Go from the largest dimension down and repeat; if the 8 is kept fixed, is the stepping down what populates the fibre? Answers, each computed in <code>fibre_check.py</code> (' + str(nchecks) + ' checks, with ' + str(nmut) + ' automated sabotages caught): yes (F10); yes, with a twist that makes the right action the mirror (F10); yes, as a precise statement about commutants (F11). Four consequences follow: a momentum along an extra space-like direction enters as a mass (F12), the bands follow the elliptic/parabolic/hyperbolic split (F13), the 24 as three 8s (F14), and the E₈ ladder (F15).</p>'
        '<div class="grid3"><div class="card"><h3>1 · Local product ' + chip('checked') + '</h3><p>Labels concatenate, sign (−1)<sup>|b||c|</sup>; fibre bivectors commute with the Lorentz ones. F10.</p></div>'
        '<div class="card"><h3>2 · Left and right ' + chip('checked') + chip('ours') + '</h3><p>Commuting right action = same-type fibre; twisted right action = the mirror, Cl(n,n) together. F10.</p></div>'
        '<div class="card"><h3>3 · The 8 kept fixed ' + chip('checked') + chip('ours') + '</h3><p>Base 2<sup>k</sup>, fibre 2<sup>8−k</sup>, types follow the clock; the freed generators reappear in the fibre. F11, F15.</p></div></div>')
    TAIL = ('<div class="card" style="margin-top:14px"><h3>What this does not say</h3><ul class="tight">'
        '<li><b>Global gluing.</b> Everything is local or fibre-level: no transition functions, no connection on a manifold, no topology. The row L4 stays a gap.</li>'
        '<li><b>Which fibre is physical.</b> The commutant, the mirror and the Gosset layers are exact algebra and combinatorics; calling them gauge groups, generations or masses is a reading.</li>'
        '<li><b>Where the notes stand.</b> The quantum notes are a student transcript; the full lectures are online and their last chapters are the ones that matter for the translation. I read chapters 17.3, 17.5, 19.4 and 20, not 18 or the rest of 17.</li>'
        '<li><b>Recalled, not recomputed:</b> the minimal representations 56, 27, 16, 10, (3,2); W(F₄) = W(D₄) ⋊ S₃ as the triality group; the real Clifford group 2<sup>1+2m</sup>.O⁺(2m,2).</li></ul></div>')
    return dict(INTRO=INTRO, FINDINGS2=''.join([F10, F11, F12, F13, F14, F15]), TAIL=TAIL, n_edges=n_edges)
