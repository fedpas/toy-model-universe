#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Automated sabotage test for fibre_check.py (and, since 6 October 2026, one mutant of bridge_check.py, A6): each mutant changes one line of a temporary copy; the run must FAIL the named check (a crash does not count as caught).
Python standard library only.   Run: python3 mutate_fibre.py   (about 3 minutes)"""
import os, sys, subprocess, tempfile, re
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, 'fibre_check.py')).read(); SRCS = {'fibre_check.py': SRC, 'bridge_check.py': open(os.path.join(HERE, 'bridge_check.py')).read()}
M = [
 ('M1  G1: drop the (-1)^(|b||c|) sign of the graded product', "((-1) ** (pc(b) * pc(c))) * s1 * s2", "s1 * s2", 'G1a'),
 ('M2  G2: right multiplication without the grading twist', "Rti[c, x] = s * (-1 if pc(x) & 1 else 1)", "Rti[c, x] = s", 'G2b'),
 ('M3  G2: wrong mirror signature printed/used for Cl(1,3)', "[int(-e) for e in sig(1, 3)] == [-1, 1, 1, 1]", "[int(e) for e in sig(1, 3)] == [-1, 1, 1, 1]", 'G2d'),
 ('M4  G3: search gamma that commute instead of anticommute', "np.allclose(cands[i] @ g + g @ cands[i], 0) for g in cur", "np.allclose(cands[i] @ g - g @ cands[i], 0) for g in cur", 'G3a'),
 ('M5  G3: fibre generators without the omega twist', "hs = [om @ g for g in ferm]", "hs = [g for g in ferm]", 'G3e'),
 ('M6  G4: Lorentz base replaced by (3,1) in the mass-shell test', "A13 = Alg(sig(1, 3)); om13", "A13 = Alg(sig(3, 1)); om13", 'G4a'),
 ('M7  G4: hyperbolicity filter loosened to min <= 2', "return min(npl, nmi) <= 1 and (npl, nmi) != (0, 0)", "return min(npl, nmi) <= 2 and (npl, nmi) != (0, 0)", 'G4d'),
 ('M8  G5: swapped order of e1 e2 in the 2x2 representation', "E12m = E1m @ E2m", "E12m = E2m @ E1m", 'G5a'),
 ('M9  G5: wrong sign in the flight matrix (det 1 lost)', "M = np.array([[math.cos(k * l), math.sin(k * l) / k], [-k * math.sin(k * l), math.cos(k * l)]])", "M = np.array([[math.cos(k * l), math.sin(k * l) / k], [k * math.sin(k * l), math.cos(k * l)]])", 'G5b'),
 ('M10 G5: band condition read the wrong way (elliptic <-> X^2 > 0)', "ok &= xs < 0 and complex_ev", "ok &= xs > 0 and complex_ev", 'G5d'),
 ('M11 G5: band edges taken at |gamma| = 1.2 instead of 1', "cur = abs(gam(E1_)) <= 1\n", "cur = abs(gam(E1_)) <= 1.2\n", 'G5e'),
 ('M12 G6: w = (1 + e1 + e2 + e12)/2 (order 6, not 3)', "om = mvk(-h, h, h, h)", "om = mvk(h, h, h, h)", 'G6a'),
 ('M13 G7: Cartan elements not commuting (neighbouring gamma pairs overlap)', "Hk = [0.5 * G8[2 * k] @ G8[2 * k + 1] for k in range(4)]", "Hk = [0.5 * G8[k] @ G8[k + 1] for k in range(4)]", 'G7a'),
 ('M14 G7: quadric made linear (x1 + x3 + x5 + x7)', "r ^= (x >> (2 * i) & 1) & (x >> (2 * i + 1) & 1)", "r ^= (x >> (2 * i) & 1)", 'G7d'),
 ('M15 G8: all sign patterns allowed in the half-integer roots', "if sum(1 for s_ in signs if s_ < 0) % 2 == 0: roots.append(tuple(signs))", "roots.append(tuple(signs))", 'G8a'),
 ('M16 G8: orthogonal complement taken with <= 0', "cur_R = [s_ for s_ in cur_R if gram[s_, c] == 0]", "cur_R = [s_ for s_ in cur_R if gram[s_, c] <= 0]", 'G8c'),
 ('M17 G9: Hamming generator row of odd weight', "[0, 1, 0, 1, 0, 1, 0, 1]]", "[0, 1, 0, 1, 0, 1, 0, 0]]", 'G9a'),
 ('M19 G7: wrong fourth simple root of F4 (Coxeter element changes)', "(0, 0, 0, 1), (.5, -.5, -.5, -.5)]]", "(0, 0, 0, 1), (1, -1, 0, 0)]]", 'G7e'),
 ('M20 G4: real Dirac operator shell with the wrong sign of m^2', "real_val = sk + m_ * m_; printed_val = sk - m_ * m_", "real_val = sk - m_ * m_; printed_val = sk + m_ * m_", 'G4b'),
 ('M18 G9: Golay blades in a mixed-signature algebra', "A24 = Alg(sig(0, 24))", "A24 = Alg(sig(0, 23) + (1,))", 'G9b'),
 ('M21 A6 (bridge_check.py): multiplication by the top blade claimed to reach every label with a null generator, i.e. "Hodge star = XOR with 1...1" for every signature (E-009)', "a6_ok &= I2 == 0 and killed and len(img) == 2 ** (p + q) and pairing", "a6_ok &= I2 == 0 and killed and len(img) == N and pairing", 'A6', 'bridge_check.py'),
]
caught = 0; lines = []
for m in M:
    name, old, new, cid = m[:4]; target = m[4] if len(m) > 4 else 'fibre_check.py'; src = SRCS[target]
    if src.count(old) != 1:
        lines.append(f'ERROR {name}: pattern found {src.count(old)} times'); continue
    code = src.replace(old, new)
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, target); open(path, 'w').write(code)
        env = dict(os.environ); env['ATLAS_PKG'] = os.environ.get('ATLAS_PKG', os.path.abspath(os.path.join(HERE, '..', '..')))   # the package this folder ships in
        r = subprocess.run([sys.executable, path], capture_output=True, text=True, env=env, timeout=600)
    failed = re.findall(r'^FAIL ([A-Z]\d+[a-z]?)', r.stdout, re.M)
    crash = r.returncode != 0 and 'Traceback' in r.stderr
    hit = cid in failed
    caught += hit
    lines.append(f"{'caught' if hit else 'MISSED'}  {name}  -> failing: {','.join(failed) or '-'}{'  (crash)' if crash else ''}")
for l in lines: print(l)
print(f'mutants caught: {caught} of {len(M)}')
sys.exit(0 if caught == len(M) else 1)
