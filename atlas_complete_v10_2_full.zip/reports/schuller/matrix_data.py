# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The translation matrix between Schuller's framework and the atlas.
Rows: what Schuller's three documents and his quantum lectures (read in part) talk about.  Columns: where the atlas draws or checks it.
Grade of a cell:
  E  exact        the same object or identity; the atlas page or bridge_check.py computes it (check ids in the note)
  S  structural   the same structure in a different generality (the atlas is local, polynomial, finite; Schuller's is global, smooth), or a standard fact the atlas uses
  A  analogy      a reading we propose (tagged ours); no computation says it is the same
  .  (absent)     no counterpart
A row with no cell at all is a GAP: the atlas has nothing there."""

COLS = [  # key, short label, long label, atlas page
    ('rule', 'Rule', 'The rule: bit labels, XOR, signs', 'page 1'),
    ('cells', 'Cells', 'The atlas of cells Cl(p,q), the clock', 'page 2'),
    ('maxwell', 'Maxwell', 'Test 1: Maxwell ∇F=J', 'page 3'),
    ('furey', 'Furey', 'Test 2: Furey, one generation in Cl(0,8)', 'page 4'),
    ('shapes', 'Shapes', 'Orthoplex, demicube, Gosset series', 'page 5'),
    ('comm', '1 Comm', 'Step 1: bivector commutators', 'step 1'),
    ('dirac', '2 Dirac', 'Step 2: Dirac equation', 'step 2'),
    ('coupling', '3 Coupl', 'Step 3: coupling', 'step 3'),
    ('ym', '4 YM', 'Step 4: Yang–Mills', 'step 4'),
    ('matter', '5 Matter', 'Step 5: charged matter', 'step 5'),
    ('grav1', '6 Grav', 'Step 6: gravity, tetrad and curvature', 'step 6'),
    ('grav2', '7 Grav', 'Step 7: gravity, Einstein form', 'step 7'),
    ('mirrors', '8 Mirr', 'Step 8: mirrors and versors', 'step 8'),
    ('projective', '9 Proj', 'Step 9: projective and conformal', 'step 9'),
    ('forque', '10 Forq', 'Step 10: forque dynamics', 'step 10'),
    ('spin', '11 Spin', 'Step 11: spinors', 'step 11'),
    ('spring', '12 Sprg', 'Step 12: springs', 'step 12'),
    ('rigid', '13 Rigd', 'Step 13: rigid bodies', 'step 13'),
    ('null', '14 Null', 'Step 14: null surfaces', 'step 14'),
    ('clock', '15 Clock', 'Step 15: clock and trinity', 'step 15'),
    ('gauge', '16 Gauge', 'Step 16: gauge gravity', 'step 16'),
    ('groups', '17 Grps', 'Step 17: finite groups', 'step 17'),
]

# source: L = Schuller, Lectures on the Geometric Anatomy of Theoretical Physics (2013/14); C = closure paper (arXiv:1611.08878) or the review (arXiv:2003.09726);
#         Q = Schuller, Lectures on Quantum Theory (2015, notes by Rea and Dadhley): read in part: ch. 1, 12.4, 13, 14, 15, 16.2-16.3, 17.3, 17.5, 19.4, 20, 21; NOT read: 2-11, 12.1-12.3, rest of 16, rest of 17-19
ROWS = [
 ('L1', 'L', 'Logic: propositions, exclusive or (ch. 1)', {
   'rule': ('E', 'The "Y" (exclusive or) of §1.1 is the product on labels: p XOR q is the bit rule.')}),
 ('L2', 'L', 'Sets, maps, equivalence relations (ch. 2–3)', {
   'rule': ('S', 'Blades are subsets of {1..n}; XOR is the symmetric difference.'),
   'cells': ('S', 'The clock c = p−q mod 8 is an equivalence relation on signatures.')}),
 ('L3', 'L', 'Topology: spaces, compactness, π₁ (ch. 4–5)', {
   'shapes': ('A', 'Polytopes are spaces, but the atlas only counts their faces: no topological invariant is used.')}),
 ('L4', 'L', 'Topological manifolds and bundles (ch. 6)', {}),
 ('L5', 'L', 'Smooth atlases and structures (ch. 7)', {
   'grav2': ('S', 'Fields are polynomials in one chart (exact for n = 2..5): a single local chart.')}),
 ('L6', 'L', 'Vector and tensor spaces, determinant (ch. 8)', {
   'rule': ('E', 'Generators span V; the 2ⁿ blades span Λ(V); the determinant is the coefficient on the all-ones label.'),
   'cells': ('S', 'Cl(p,q) is the tensor algebra of V modulo the quadratic relation.')}),
 ('L7', 'L', 'Tangent spaces, derivations (ch. 9–10)', {
   'comm': ('S', 'Bivectors act on Cl by the commutator: inner derivations.'),
   'grav1': ('S', 'The tetrad is a frame of the tangent space.')}),
 ('L8', 'L', 'Vector fields, modules (ch. 11)', {
   'cells': ('S', 'Cl(p,q) = M(K): the irreducible module is Kᵏ.'),
   'spin': ('S', 'Spinor spaces are left modules of Cl.')}),
 ('L9', 'L', 'Grassmann algebra, d, de Rham (ch. 12)', {
   'rule': ('E', 'All-null bit rule = wedge, sign (−1)^{nm} (A1–A4). The complement map XOR with 1…1 is multiplication by the pseudoscalar, his metric Hodge star, only in the non-degenerate cells (A5: Cl(1,3), Cl(4,0), Cl(2,2), Cl(3,1)); with a null generator the top blade is nilpotent and the complement map is the Frobenius duality of the top-blade form, non-degenerate for every signature (A6; T3). Corrected 6 October 2026 (E-009).'),
   'maxwell': ('E', 'dF=0 and d⋆F=J are grades 3 and 1 of ∇F=J.'),
   'grav1': ('E', 'Forms are the bit rule with null generators; D R=0 exact for polynomial fields.'),
   'grav2': ('E', 'Same, with the Einstein form E_a.')}),
 ('L10', 'L', 'Lie groups and Lie algebras (ch. 13)', {
   'comm': ('E', 'Bivectors form so(p,q); Jacobi exact.'),
   'ym': ('E', 'The gauge algebra is the bivectors of Cl(0,m).'),
   'projective': ('E', 'so(1,n), so(2,n−1), iso: Killing form computed.'),
   'groups': ('E', 'Finite groups over F₂ from the same labels.')}),
 ('L11', 'L', 'Cartan classification, Dynkin diagrams, Weyl group (ch. 14, 16)', {
   'shapes': ('E', 'Gosset series E₃..E₈: Cartan matrices, det Eₙ = 9−n, 240 roots.'),
   'groups': ('E', 'W(Eₙ) mod 2 = O(Q) of Cl(n,0), n = 3..8.'),
   'projective': ('S', 'Killing form signature.')}),
 ('L12', 'L', 'SL(2,ℂ), the relativistic spin group (ch. 15)', {
   'cells': ('E', 'Spin(1,3) lives in Cl⁰(1,3) = Cl(1,2), cell [3,−1], clock 7, ℂ (E1–E3).'),
   'comm': ('E', 'Lorentz algebra = 3 boosts + 3 rotations.'),
   'dirac': ('E', 'Dirac on Cl(1,3), 8 real components.'),
   'spin': ('E', 'Pointors in Cl(1,3).'),
   'mirrors': ('S', 'Versors and the double cover.')}),
 ('L13', 'L', 'Representations, Casimir operator (ch. 17)', {
   'cells': ('E', 'Cl(p,q) = M(K): the irreducible modules (standard table).'),
   'matter': ('E', 'Bivectors act by left multiplication; Cl(0,3) = ℍ⊕ℍ gives two su(2) doublets.'),
   'spin': ('E', 'Casimir of the spin representation: Σ_{a<b}(e^{ab}/2)(e_{ab}/2) = −C(n,2)/4 with the indices raised, in every signature without null generators; at n = 3 minus it is the 3/4 of Example 17.13 (E4–E5).'),
   'furey': ('S', 'Standard Model representations on 16ℂ (Furey).')}),
 ('L14', 'L', 'Exponential map, integral curves (ch. 18)', {
   'spring': ('E', 'B² = −1, +1, 0 gives e^{tB} = cos, cosh, a line.'),
   'spin': ('E', 'e^{tB}Φ = (cos t + σ i sin t)Φ.'),
   'forque': ('S', 'Motor ODE solved as an exact power series.'),
   'rigid': ('S', 'Same, for rigid bodies.')}),
 ('L15', 'L', 'Principal bundles, group actions (ch. 19)', {
   'ym': ('S', 'A gauge group acts; only local sections are used.'),
   'grav1': ('S', 'The tetrad is a local section of the frame bundle.'),
   'mirrors': ('S', 'A group acting by sandwich.')}),
 ('L16', 'L', 'Associated bundles (ch. 20)', {
   'matter': ('S', 'Ψ lives in the left module of the gauge algebra: a fibre, locally.'),
   'dirac': ('S', 'ψ lives in the spinor module.'),
   'spin': ('S', 'Spinor spaces by dimension.')}),
 ('L17', 'L', 'Connections, Yang–Mills local form (ch. 21–22)', {
   'ym': ('E', 'F = ∂A−∂A+g[A,A], Bianchi, gauge covariance.'),
   'grav1': ('E', 'R = dω + ¼[ω,ω], T = de + ωe.'),
   'coupling': ('E', 'Dirac gains −eAψ.'),
   'matter': ('E', 'D = ∂ + gAᵃBₐ, [D,D]Ψ = gFΨ.')}),
 ('L18', 'L', 'Parallel transport, path-ordered exponential (ch. 23)', {
   'forque': ('S', 'Same ODE Ṁ = −½MB, solved by series.'),
   'rigid': ('S', 'Same ODE for bodies.'),
   'spring': ('S', 'Rotor flow s′ = ωBs.')}),
 ('L19', 'L', 'Curvature and torsion (ch. 24)', {
   'grav1': ('E', 'Curvature and torsion, first and second Bianchi identities.'),
   'grav2': ('E', 'Einstein form; first Bianchi = one relation per 4-subset.'),
   'gauge': ('E', 'Riemann = Ricci + Weyl, Weyl first nonzero at n = 4 (20 = 10 + 10).'),
   'projective': ('S', 'R − sκ²e∧e.')}),
 ('L20', 'L', 'Covariant derivative (ch. 25)', {
   'coupling': ('E', 'D = ∂ − eA.'),
   'matter': ('E', 'D acts on the internal cube.'),
   'grav2': ('E', '[D,D]ψ = ½Rψ.')}),
 ('C1', 'C', 'Matter action on a tensor geometry (closure §II.A)', {
   'dirac': ('S', 'ψ even in Cl(1,3) on the Clifford geometry.'),
   'maxwell': ('S', 'F on a fixed flat background; no dynamical geometry.')}),
 ('C2', 'C', 'Principal polynomial and its reduction (closure §II.B, (22)–(24))', {
   'dirac': ('E', 'det of the 8×8 Dirac symbol = (p²)⁴, reduced polynomial p² (B4).'),
   'cells': ('S', 'P = Σ εᵢkᵢ² is the Clifford form of the cell.'),
   'maxwell': ('S', 'Wave operator □F.')}),
 ('C3', 'C', 'Hyperbolicity, dual polynomial, energy cone (closure §II.C)', {
   'maxwell': ('E', 'The wave-type table is hyperbolicity for quadratic P (B1–B3).'),
   'cells': ('E', 'Admissible cells are the Lorentzian ones, Cl(1,d) and Cl(k,1): one class in two conventions P ↔ −P (the algebras differ: Cl(1,3) = M₂(ℍ), Cl(3,1) = M₄(ℝ)); Cl(2,2) is the first ultrahyperbolic cell (B1–B3; domain r = 0).'),
   'null': ('S', 'Null cones, T = 0.'),
   'gauge': ('S', 'The cones tilt through the horizon.')}),
 ('C4', 'C', 'Observers, Legendre map, particle actions (closure §II.D)', {
   'maxwell': ('S', 'Charges tab: u·u conserved, as for the action ∫√(g ẋẋ).'),
   'gauge': ('S', 'Raindrop observers.'),
   'cells': ('A', 'The mirror reading Cl(q,p) corresponds to the sign convention P → −P.')}),
 ('C5', 'C', 'Foliation, lapse and shift, induced geometry (closure §III.A)', {
   'gauge': ('S', 'Painlevé–Gullstrand: unit lapse and a shift g·e_r.'),
   'null': ('S', 'Foliation by the level sets of g_tt.')}),
 ('C6', 'C', 'Hypersurface deformation algebra (closure (48)–(50))', {
   'spring': ('S', 'Witt ⊗ A_ε, A_ε the one-generator algebra of square ε = +1, 0, −1 (C1–C6).'),
   'projective': ('S', 'The extra generator s ∈ {0, −1, +1}.'),
   'null': ('S', 'Tube algebra so(1,2), iso(2), so(3).'),
   'clock': ('S', 'The trinity −1, +1, 0.'),
   'spin': ('S', 'Unit squares −1, +1, 0 = ℂ, split, dual.')}),
 ('C7', 'C', 'Gravitational closure equations (closure §IV)', {
   'grav2': ('A', 'Closure derives the Einstein action; the atlas starts from the Einstein form.')}),
 ('C8', 'C', 'Klein–Gordon → Einstein–Hilbert with (κ, Λ) (closure §V.A)', {
   'grav2': ('S', 'Einstein form E_a exact for n = 3, 4, 5.'),
   'projective': ('A', 'The sign class of Λ ~ the square s of the extra generator (ours; untested against his equations).'),
   'gauge': ('S', 'Gauge-theory gravity, Painlevé–Gullstrand.')}),
 ('C9', 'C', 'Bi-metric closure, P = G⁽ⁱʲHᵏˡ⁾ (closure §V.B)', {
   'dirac': ('S', 'Two Dirac fields: det = (G·k)⁴(H·k)⁴, reduced P = (G·k)(H·k) (B5).'),
   'cells': ('A', 'Graded product of cells Cl(p,q) ⊗̂ Cl(p′,q′) = Cl(p+p′, q+q′) (Q3).')}),
 ('C10', 'C', 'General linear electrodynamics, the area metric (closure §V.C, review (3)–(4))', {
   'clock': ('E', 'The (S, W) plane: B² = S + W e₁₂₃₄ (D4).'),
   'grav2': ('E', '21 = 6 + 12 + 3 plane pairs; 20 after Bianchi (D1–D3).'),
   'comm': ('E', 'The 3 antipodal planes commute: the F∧F terms (D2).'),
   'maxwell': ('S', 'F is a bivector with E, T, B parts.')}),
 ('C11', 'C', 'Dirac fields give the same principal tensor (closure §V.A)', {
   'dirac': ('E', 'γ⁽ᵃγᵇ⁾ = Gᵃᵇ is the bit rule; det computed (B4).')}),
 ('C12', 'C', 'Canonical quantisability, energy-distinguishing condition', {}),
 ('M1', 'Q', 'Axioms: Hilbert space, observables, measurement, projective dynamics; Stern–Gerlach (QT 1)', {
   'cells': ('E', 'Stern–Gerlach z→x→z gives 1, ½, ½ from the idempotents (1±e_i)/2 of Cl(3,0) (Q12).'),
   'rule': ('S', 'Hermitian ⇔ the blade squares to +1 (Q1d): the finite shadow of "observables are self-adjoint". Axiom 1 (separable Hilbert space, trace-class states) needs infinite dimension.')}),
 ('M2', 'Q', 'Banach and Hilbert spaces, measure theory, spectral theorem, self-adjointness, Stone (QT 2–12)', {}),
 ('M3', 'Q', 'Spin: so(3) from commutators, Casimir, ladder operators, pure spin-j (QT 13, Example 13.6)', {
   'comm': ('E', 'The Pauli spin algebra [Sᵢ,Sⱼ] = iεSₖ with Sᵢ = eᵢ/2 and i = e₁₂₃ (Q8a–c).'),
   'spin': ('E', 'Casimir Ω = ΣSᵢ² = 3/4 = j(j+1) at j = ½, central (Proposition 13.9; Q8b–c).'),
   'cells': ('E', 'Cl(3,0) = M₂(ℂ): the bit rule is the Pauli matrix algebra (Q8a).')}),
 ('M4', 'Q', 'Composite systems: tensor products, operators A⊗1 + 1⊗B, entanglement (QT 14.1–14.3, 14.6)', {
   'rule': ('E', 'Graded tensor product = concatenation of the bit labels with the sign (−1)^{|b||c|} (Q3).'),
   'cells': ('E', 'Cl(p,q) ⊗̂ Cl(p′,q′) = Cl(p+p′, q+q′); ℍ⊗ℍ = M₄(ℝ) so Cl(1,3)⊗Cl(1,3) = M₁₆(ℝ) (Q3, Q4).'),
   'furey': ('A', 'End(V) = M₁₆(ℝ) read as the real operators of 4 qubits (ours; not tested beyond the algebra).'),
   'maxwell': ('A', 'For real amplitudes, simple tensors (product states) are the null cone of det on M₂(ℝ), signature (2,2), the signature of the first ultrahyperbolic cell; over ℂ the condition is det = 0 on M₂(ℂ) (Q10; the identification is standard, the link to the atlas table is ours).'),
   'shapes': ('A', 'The 2ⁿ occupation patterns are the vertices of the n-cube; n modes are n Witt pairs (orthoplex): our reading.')}),
 ('M5', 'Q', 'Antisymmetric tensor product, Pauli exclusion, the fermionic Fock space (QT 14.4, 21.4)', {
   'rule': ('E', 'Λ(H) is the all-null bit rule: ψ∧ψ = 0 is e² = 0 (Q6); bit label = occupation pattern (reading ours).'),
   'cells': ('E', 'Cl(n,n) = M_{2ⁿ}(ℝ) acts on Λ(ℝⁿ) by ε_k ± ι_k (Q5a–b).'),
   'groups': ('A', 'The complement map XOR with 1…1 (on the all-null Fock labels a Frobenius duality, not a metric Hodge star: the top blade is nilpotent, A6) reads as particle–hole conjugation (ours; popcount n−|a|).')}),
 ('M6', 'Q', 'Harmonic oscillator: ladder operators a±, [a₋,a₊] = 1, spectrum (ħω)(n+½) (QT 16)', {
   'cells': ('E', 'The fermionic oscillator: one Witt pair, N = (1−e₁₂)/2 with spectrum {0,1}; n modes give C(n,j) states at N = j (Q7).'),
   'spring': ('S', 'The classical network (Walsh modes ω² = 2|s|); the bosonic ladder [a₋,a₊] = 1 has no finite matrices (tr[A,B] = 0 ≠ n), so the atlas cannot draw it.')}),
 ('M7', 'Q', 'Total spin, Clebsch–Gordan, J = A⊗1 + 1⊗B (QT 15)', {
   'spin': ('E', '½ ⊗ ½ = 0 ⊕ 1 is read off the grades of Cl(3,0): Casimir 0, 2, 2, 0 (Q2).'),
   'comm': ('S', 'Total spin obeys the same relations; the lecture\'s Clebsch–Gordan formulas are reproduced numerically for five (j_A, j_B) (Q9a–b): a test of the text, not of the atlas.')}),
 ('M8', 'Q', 'Position, momentum, orbital angular momentum Lⱼ = −i(x∂ − x∂) (QT 12.4)', {
   'comm': ('S', 'The Lⱼ obey the so(3) relations of the bivectors of step 1; the atlas has the algebra, not the differential operators.'),
   'rigid': ('S', 'Angular momentum of a rigid body, classical.')}),
 ('M9', 'Q', 'Relativistic quantum mechanics: Klein–Gordon, Dirac equation, signature (QT 21.2–21.3)', {
   'dirac': ('E', 'Step 2. With the notes\' convention (γ⁰² = −1, γₐ² = +1, η = (−,+,+,+)) the determinant of the symbol vanishes at E² = |p|² − m² (Q11b); flipped, at |p|² + m².'),
   'cells': ('E', 'The two conventions are Cl(3,1) = M₄(ℝ) (clock 2) and Cl(1,3) = M₂(ℍ) (clock 6): the same complexification, different cells (Q11a, Q11c).')}),
 ('M10', 'Q', 'Measurement, probabilities, preparation, mixed states (QT 17; 17.3 and 17.5 read, not yet encoded)', {}),
 ('M11', 'Q', 'Periodic potentials: Floquet matrix, energy bands (QT 20); Fourier and Schrödinger operators (QT 18–19, not read)', {
   'cells': ('E', 'The one-period matrix (det 1, real) is a unit multivector of Cl(2,0) = M₂(ℝ); ½Tr M is its scalar part, checked against numerical integration (G5a–b). The notes\' trace is written ψ₁+ψ₂, a slip for ψ₁+ψ₂′.'),
   'clock': ('E', 'Bands (|½Tr M| < 1) are X² < 0, gaps X² > 0, band edges X² = 0 with X ≠ 0 (G5d–e): the textbook elliptic/hyperbolic/parabolic split of SL(2,ℝ); M = ±I has X = 0 and is not an edge; reading the three as the trio is ours.'),
   'null': ('S', 'A delta kick 1 + g n has n² = 0, the null element; the Dirac comb is a null kick after an elliptic flight (G5c, G5f).')}),
]

SRC_NAME = {'L': 'Lectures on the Geometric Anatomy of Theoretical Physics', 'C': 'Gravitational closure / Constructive gravity', 'Q': 'Lectures on Quantum Theory (read in part)'}

def stats():
    from collections import Counter
    n = len(ROWS); col = {k: Counter() for k, *_ in COLS}; per = []
    for rid, src, title, cells in ROWS:
        best = 'gap'
        order = {'E': 3, 'S': 2, 'A': 1}
        for k, (g, note) in cells.items():
            col[k][g] += 1
            if best == 'gap' or order[g] > order[best]: best = g
        per.append((rid, best))
    cnt = Counter(b for _, b in per)
    bysrc = {s: Counter(b for (rid, b), r in zip(per, ROWS) if r[1] == s) for s in 'LCQ'}
    total_cells = sum(len(r[3]) for r in ROWS)
    cellg = Counter(g for r in ROWS for g, _ in r[3].values())
    return dict(n=n, best=cnt, bysrc=bysrc, col=col, total_cells=total_cells, cellg=cellg)

if __name__ == '__main__':
    s = stats()
    print('rows', s['n'], 'best grade per row', dict(s['best']), 'cells', s['total_cells'], dict(s['cellg']))
    for k, v in s['bysrc'].items(): print(k, dict(v))
    keys = [k for k, *_ in COLS]
    for k in keys:
        assert all(kk in keys for r in ROWS for kk in r[3]), 'unknown column'
    print('columns', {k: sum(s['col'][k].values()) for k in keys})
