# Correction of 5 October 2026 (statement review, item C1; approved by the user the same evening)

Wrong sentence (Schuller report F12, and the tail of the message of check G4b in fibre_check.py):
"The physical sign needs a central unit i, which M4(R) does not have; so in the real algebra that i has to come from the fibre, the complex structure of the wave function."

Why it is wrong: in Cl(3,1) = M4(R) with real gamma matrices (gamma_0^2 = -1) the real operator (gamma.d - m) already has the physical mass shell. Exactly: (gamma.d - m)(gamma.d + m) = |d|^2 - d_t^2 - m^2 is minus the Klein-Gordon operator; on a plane wave the i is the Fourier i of d -> i p, not an element of the algebra. The factor i printed in the notes' (i gamma.d - m) is the slip; it belongs to the Cl(1,3) convention (time squares +1). In Cl(3,1) it gives E^2 = |p|^2 - m^2.

What stays: the F9 flag (the printed equation has the wrong sign: checks Q11a-c), and the pseudoscalar-mass computations G4a and G4b as computations.

What changed: fibre_check.py (G4b: message + an exact assertion on five Pythagorean shells; still 35 checks), mutate_fibre.py (new mutant M20: 20 of 20 caught), fibre_section.py (F12 paragraph), build_report.py (F9 addition, P7 card, "Next, in order" line). Independent numerical test: `../review/mine/mass_shell_check.py` (a working-folder script, not part of this package; the same zero is pinned by check G4b and by check_T16.py part E of the round-2 derivations) (real 4x4 gamma matrices; momentum (0.3, -0.2, 0.5), m = 0.7: zero at E = 0.9327 = sqrt(p^2 + m^2); the printed form has none there and, for |p| > m, the tachyonic shell E^2 = |p|^2 - m^2).
Found by the physicist reviewer; re-checked by me.
