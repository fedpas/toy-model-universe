#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Bridge checks, quantum side.  Schuller's "Lectures on Quantum Theory" (FAU 2015, notes by Rea and Dadhley, 207 pages) are now attached and READ in part:
ch. 1 (desiderata, the five axioms), 12.4 (position, momentum, angular momentum), 13 (spin: the Casimir and ladder derivation), 14 (composite systems, tensor products,
symmetric and antisymmetric products, entanglement), 15 (total spin, Clebsch-Gordan), 16.2-16.3 (oscillator ladder operators), 21 (Schroedinger, Klein-Gordon, Dirac, Fock space).
NOT read: ch. 2-11 (Banach spaces, measure theory, spectral theorem), 12.1-12.3, the rest of 16, ch. 17-20 (measurement, Fourier, Schroedinger operator, periodic potentials).
Q1-Q4b were written from the contents list; Q5-Q12 test statements that the text makes (the lecture numbers are in each message).  Python standard library + numpy.
Run: python3 bridge_check_qm.py
Shipped in the webapp package as selfcheck/reports/bridge_check_qm.py: needs bitcliff.py at <package>/selfcheck/steps15_17 (default: the package two levels up from this script; override with the environment variable ATLAS_PKG). Python dependencies: numpy (and the standard library). Writes nothing."""
import os, sys, random, itertools, math
from fractions import Fraction as Fr
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the webapp package: two levels up from selfcheck/reports/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, reorder_sign, TYPES

N_OK = N_BAD = 0
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))

# ---------------------------------------------------------------------------------------------------------------------------------
# Q1. Lecture 14 (composite systems) and 13 (spin): N qubits.  Jordan-Wigner Majorana generators g_{2k}=Z..Z X I.., g_{2k+1}=Z..Z Y I.. (2N of them, all square to +1)
#     are the generators of Cl(2N,0) over C.  The bit-rule blades e_a (a in F_2^{2N}) are, up to the phases 1,i,-1,-i, exactly the 4^N Pauli strings,
#     and the bit rule's sign table is the multiplication table of the Pauli group.
# ---------------------------------------------------------------------------------------------------------------------------------
I2 = np.eye(2, dtype=complex); X = np.array([[0, 1], [1, 0]], dtype=complex); Y = np.array([[0, -1j], [1j, 0]]); Z = np.diag([1., -1]).astype(complex)
def kron(*ms):
    out = np.eye(1, dtype=complex)
    for m in ms: out = np.kron(out, m)
    return out
def majoranas(N):
    gs = []
    for k in range(N):
        for P in (X, Y):
            gs.append(kron(*([Z] * k + [P] + [I2] * (N - k - 1))))
    return gs
def blade(gs, a):
    M = np.eye(gs[0].shape[0], dtype=complex)
    for i, g in enumerate(gs):
        if a >> i & 1: M = M @ g
    return M
def pauli_key(M):
    """identify M as phase * Pauli string: return the string over 'IXYZ' or None"""
    N = int(round(math.log2(M.shape[0])))
    best = None
    for s in itertools.product('IXYZ', repeat=N):
        P = kron(*[{'I': I2, 'X': X, 'Y': Y, 'Z': Z}[c] for c in s])
        ph = np.trace(P.conj().T @ M) / M.shape[0]
        if abs(abs(ph) - 1) < 1e-9 and np.allclose(M, ph * P):
            if ph.real in (1., -1.) or True: return ''.join(s), ph
    return None, None
for N in (1, 2, 3):
    gs = majoranas(N); n = 2 * N; al = Alg(sig(n, 0))
    chk('Q1a', all(np.allclose(g @ g, np.eye(2 ** N)) for g in gs) and all(np.allclose(gs[i] @ gs[j] + gs[j] @ gs[i], 0) for i in range(n) for j in range(n) if i != j), f'N={N}: the {n} Jordan-Wigner Majorana generators square to +1 and anticommute: Cl({n},0) over C')
    keys = {}; ok = True
    for a in range(al.N):
        k, ph = pauli_key(blade(gs, a))
        if k is None or abs(ph ** 4 - 1) > 1e-9: ok = False; break
        keys[a] = k
    chk('Q1b', ok and len(set(keys.values())) == 4 ** N, f'N={N}: the {4 ** N} blades are the {4 ** N} Pauli strings, each up to a phase in {{1,i,-1,-i}}, all distinct (a bijection of labels: 2N bits <-> N pairs (x,z))')
    pairs_ = [(a, b) for a in range(al.N) for b in range(al.N)]
    if len(pairs_) > 700: pairs_ = random.Random(3).sample(pairs_, 700)
    ok = True
    for a, b in pairs_:
        s, c = al.blade_mul(a, b)
        if not np.allclose(blade(gs, a) @ blade(gs, b), s * blade(gs, c)): ok = False; break
    chk('Q1c', ok, f'N={N}: e_a e_b = s(a,b) e_(a xor b) holds as matrices ({len(pairs_)} pairs): the bit rule is the Pauli-group multiplication, the sign table is s(a,b)')
    # Q: which blades are Hermitian (square +1) vs anti-Hermitian (square -1)? the F_2 quadratic form of Step 17
    sq = [al.sq(a) for a in range(al.N)]
    herm = [bool(np.allclose(blade(gs, a), blade(gs, a).conj().T)) for a in range(al.N)]
    chk('Q1d', all((sq[a] == 1) == herm[a] for a in range(al.N)), f'N={N}: blade squares to +1 exactly when it is a Hermitian Pauli string (-1 when anti-Hermitian): the form Q(a)=C(|a|,2) mod 2 of the atlas is the Hermitian/anti-Hermitian split of the Pauli group')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q2. Lecture 15 (total spin, Clebsch-Gordan) with Cl(3,0): End(C^2) = 1/2 (x) 1/2 = 0 + 1.  Under J_i = e_jk/2 the grades of Cl(3,0) carry Casimir j(j+1): 0, 2, 2, 0.
# ---------------------------------------------------------------------------------------------------------------------------------
A3 = Alg(sig(3, 0)); Js = [{3: Fr(1, 2)}, {5: Fr(1, 2)}, {6: Fr(1, 2)}]    # e12, e13, e23 halves (quaternion units / 2)
def comm(al, x, y): return al.add(al.mul(x, y), al.mul(y, x), -1)
cas = {}
for a in range(8):
    x = {a: Fr(1)}; tot = {}
    for J in Js:
        y = comm(A3, J, comm(A3, J, x)); tot = A3.add(tot, y, -1)       # Omega = - sum ad(J)^2
    # eigenvalue: tot must be lambda * x
    lam = None
    if not tot: lam = Fr(0)
    elif set(tot) == {a}: lam = tot[a]
    cas[a] = lam
bygrade = {}
for a, lam in cas.items(): bygrade.setdefault(pc(a), set()).add(lam)
chk('Q2', bygrade == {0: {Fr(0)}, 1: {Fr(2)}, 2: {Fr(2)}, 3: {Fr(0)}}, f'Casimir of ad(J) on the grades of Cl(3,0): {{ {", ".join(f"grade {g}: {sorted(v)}" for g, v in sorted(bygrade.items()))} }}: singlet (scalar, e123) and triplet (vectors, bivectors), j(j+1)=0 and 2: the Clebsch-Gordan split 1/2 x 1/2 = 0 + 1, read off the grades')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q3. Lecture 14 (tensor product of Hilbert spaces) and the atlas: the graded tensor product Cl(p,q) (x)^ Cl(p',q') = Cl(p+p',q+q'): the label of a joint blade is the
#     concatenation of the two labels, and the sign is (-1)^{|b||c|} times the two factor signs.
# ---------------------------------------------------------------------------------------------------------------------------------
def check_graded(p1, q1, p2, q2):
    A = Alg(sig(p1, q1)); B = Alg(sig(p2, q2)); C = Alg(sig(p1, q1) + sig(p2, q2)); nA = A.n
    ok = True
    for a in range(A.N):
        for b in range(B.N):
            for c in range(A.N):
                for d in range(B.N):
                    # (e_a (x) e_b)(e_c (x) e_d) = (-1)^{|b||c|} (e_a e_c) (x) (e_b e_d)
                    s1, m1 = A.blade_mul(a, c); s2, m2 = B.blade_mul(b, d)
                    want = ((-1) ** (pc(b) * pc(c))) * s1 * s2, m1 | (m2 << nA)
                    got = C.blade_mul(a | (b << nA), c | (d << nA))
                    if want != got: ok = False
    return ok
for spec in [(1, 0, 0, 1), (0, 2, 0, 2), (1, 1, 1, 0), (0, 1, 1, 1), (1, 3, 1, 0)]:
    chk('Q3', check_graded(*spec), f'graded tensor product Cl({spec[0]},{spec[1]}) (x)^ Cl({spec[2]},{spec[3]}) = Cl({spec[0] + spec[2]},{spec[1] + spec[3]}): all joint products agree with (-1)^(|b||c|) rule; label = concatenation of the two bit strings')
# ungraded: H (x) H = M4(R): the 16 operators x -> a x b on R^4 = H are linearly independent (so they span M4(R))
def left(q):
    a, b, c, d = q
    return np.array([[a, -b, -c, -d], [b, a, -d, c], [c, d, a, -b], [d, -c, b, a]], float)
def right(q):
    a, b, c, d = q
    return np.array([[a, -b, -c, -d], [b, a, d, -c], [c, -d, a, b], [d, c, -b, a]], float)
units = [(1, 0, 0, 0), (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)]
ops = [(left(u) @ right(v)).flatten() for u in units for v in units]
chk('Q4', np.linalg.matrix_rank(np.array(ops)) == 16 and all(np.allclose(left(u) @ right(v), right(v) @ left(u)) for u in units for v in units), 'H (x) H -> End(R^4): the 16 maps x -> a x b are independent and left and right multiplications commute: H (x) H = M4(R) (standard); with Cl(1,3) = M2(H) this gives Cl(1,3) (x) Cl(1,3) = M4(H (x) H) = M16(R), the algebra of the atlas Furey page (End(V)=M16(R) = Cl(0,8))')
# quaternion left/right actions really are H: check left(i)^2 = -1 etc.
chk('Q4b', all(np.allclose(left(u) @ left(u), -np.eye(4)) for u in units[1:]) and np.allclose(left((0, 1, 0, 0)) @ left((0, 0, 1, 0)), left((0, 0, 0, 1))), 'left multiplication by i, j, k satisfies i^2 = j^2 = -1, ij = k (the quaternion units, = e12, e13, e23 of Cl(3,0))')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q5-Q7. Lectures 14.4 and 21.4: the antisymmetric tensor product H^H = grade 2 of the exterior algebra; the fermionic Fock space  (^)F = C + H + H^H + ...  = Lambda(H).
#   On Lambda(R^n) (2^n basis states = the n-bit labels = occupation patterns) let eps_k = wedge with e_k and iota_k = its transpose (the interior product).
#   Then c_k = eps_k + iota_k squares to +1, d_k = eps_k - iota_k squares to -1: 2n generators of Cl(n,n), acting on a space of dimension 2^n (Chevalley).
# ---------------------------------------------------------------------------------------------------------------------------------
def fock_ops(n):
    D = 1 << n; eps = []
    for k in range(n):
        M = np.zeros((D, D))
        for S in range(D):
            if not (S >> k) & 1:
                sign = -1 if pc(S & ((1 << k) - 1)) & 1 else 1      # moving e_k past the occupied modes below k
                M[S | (1 << k), S] = sign
        eps.append(M)
    return eps
for n in (1, 2, 3):
    eps = fock_ops(n); iota = [E.T for E in eps]; D = 1 << n
    cs = [eps[k] + iota[k] for k in range(n)]; ds = [eps[k] - iota[k] for k in range(n)]
    gens = cs + ds                                                  # generator i < n squares +1, generator n+i squares -1: sig(n,n)
    al = Alg(sig(n, n)); N2 = al.N
    def Mblade(a):
        M = np.eye(D)
        for i in range(2 * n):
            if a >> i & 1: M = M @ gens[i]
        return M
    mats = [Mblade(a) for a in range(N2)]
    ok = all(np.allclose(g @ g, al.eps[i] * np.eye(D)) for i, g in enumerate(gens)) and all(np.allclose(gens[i] @ gens[j] + gens[j] @ gens[i], 0) for i in range(2 * n) for j in range(i))
    chk('Q5a', ok, f'n={n}: on Lambda(R^{n}) (dim {D}) the 2n operators eps_k+iota_k (square +1) and eps_k-iota_k (square -1) anticommute: Cl({n},{n}) acts on the Fock space (Lecture 21.4: (^)F = C + H + H^H + ...)')
    pairs_ = [(a, b) for a in range(N2) for b in range(N2)]
    if len(pairs_) > 1500: pairs_ = random.Random(5).sample(pairs_, 1500)
    okp = all(np.allclose(mats[a] @ mats[b], al.blade_mul(a, b)[0] * mats[a ^ b]) for a, b in pairs_)
    rank = np.linalg.matrix_rank(np.array([m.flatten() for m in mats]))
    chk('Q5b', okp and rank == N2 == D * D, f'n={n}: the bit rule holds for these real {D}x{D} matrices ({len(pairs_)} pairs) and the {N2} blades are independent (rank {rank}): Cl({n},{n}) = M_{D}(R), the Fock cell of the atlas (standard)')
    # Q6: Pauli exclusion (Lecture 14.17: psi ^ psi = 0) = the null generators of the Grassmann algebra: eps_k^2 = 0, {eps_k, iota_l} = delta_kl
    ok6 = all(np.allclose(E @ E, 0) for E in eps) and all(np.allclose(eps[k] @ iota[l] + iota[l] @ eps[k], (k == l) * np.eye(D)) for k in range(n) for l in range(n)) and all(np.allclose(eps[k] @ eps[l] + eps[l] @ eps[k], 0) for k in range(n) for l in range(n))
    gal = Alg(sig(0, 0, n)); okg = True
    for a in range(gal.N):
        for b in range(gal.N):
            M = np.eye(D)
            for k in range(n):
                if a >> k & 1: M = M @ eps[k]
            Mb = np.eye(D)
            for k in range(n):
                if b >> k & 1: Mb = Mb @ eps[k]
            sgn, c = gal.blade_mul(a, b)
            Mc = np.eye(D)
            for k in range(n):
                if c >> k & 1: Mc = Mc @ eps[k]
            if not np.allclose(M @ Mb, sgn * Mc): okg = False
    chk('Q6', ok6 and okg, f'n={n}: eps_k^2 = 0 (Pauli exclusion, Lecture 14.17) and {{eps_k, iota_l}} = delta_kl (the CAR); the eps_k multiply as the all-null bit rule Cl(0,0,{n}): the Grassmann algebra is the exclusion principle, the Clifford algebra is the CAR')
    # Q7: number operator N = sum eps_k iota_k = sum (1 - c_k d_k)/2: a bit-rule element; its eigenvalue on a basis state is the popcount of the label; multiplicity of j is C(n,j) = the grade
    Nop = sum(eps[k] @ iota[k] for k in range(n))
    Nbit = sum((np.eye(D) - Mblade((1 << k) | (1 << (n + k)))) / 2 for k in range(n))
    idem = all(np.allclose(((np.eye(D) - Mblade((1 << k) | (1 << (n + k)))) / 2) @ ((np.eye(D) - Mblade((1 << k) | (1 << (n + k)))) / 2), (np.eye(D) - Mblade((1 << k) | (1 << (n + k)))) / 2) for k in range(n))
    diag_ok = np.allclose(np.diag(Nop), [pc(S) for S in range(D)]) and np.allclose(Nop, np.diag(np.diag(Nop)))
    mult = {j: int(round(sum(1 for S in range(D) if pc(S) == j))) for j in range(n + 1)}
    chk('Q7', np.allclose(Nop, Nbit) and idem and diag_ok and all(mult[j] == math.comb(n, j) for j in mult), f'n={n}: N = sum_k (1 - e_(k,n+k))/2 with each e_(k,n+k)^2 = +1 (so each term is an idempotent, spectrum {{0,1}}); N|label> = popcount(label)|label>; multiplicity of N=j is C({n},j) = {[math.comb(n, j) for j in range(n + 1)]} = dim of the grade j: bit label = occupation pattern, popcount = particle number (our reading; the matrices are exact)')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q8. Lecture 13, Example 13.6: the Pauli spin algebra S_i = sigma_i/2 on C^2 and Proposition 13.9 (Casimir).  In Cl(3,0) = M2(C): e_i -> sigma_i, e_123 -> i.
# ---------------------------------------------------------------------------------------------------------------------------------
sig_ = [np.array([[0, 1], [1, 0]], complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], complex)]
Pb = {a: np.eye(2, dtype=complex) for a in range(8)}
for a in range(8):
    M = np.eye(2, dtype=complex)
    for i in range(3):
        if a >> i & 1: M = M @ sig_[i]
    Pb[a] = M
ok = True
for a in range(8):
    for b in range(8):
        s_, c_ = A3.blade_mul(a, b)
        if not np.allclose(Pb[a] @ Pb[b], s_ * Pb[c_]): ok = False
chk('Q8a', ok and np.allclose(Pb[7], 1j * np.eye(2)), 'the bit rule of Cl(3,0) is the Pauli matrix algebra: e_i = sigma_i (i=1,2,3), e_12 = i sigma_3 etc., and e_123 = i (the central pseudoscalar plays the role of the complex unit): Cl(3,0) = M2(C) (Lecture 13.6)')
Sx = [Pb[1] / 2, Pb[2] / 2, Pb[4] / 2]
eijk = {(0, 1, 2): 1, (1, 2, 0): 1, (2, 0, 1): 1, (0, 2, 1): -1, (2, 1, 0): -1, (1, 0, 2): -1}
okc = all(np.allclose(Sx[i] @ Sx[j] - Sx[j] @ Sx[i], 1j * sum(eijk.get((i, j, k), 0) * Sx[k] for k in range(3))) for i in range(3) for j in range(3))
Om = sum(S @ S for S in Sx)
chk('Q8b', okc and np.allclose(Om, 0.75 * np.eye(2)) and all(np.allclose(Om @ S, S @ Om) for S in Sx), 'S_i = e_i/2: [S_i,S_j] = i eps_ijk S_k (Lemma 13.1 form) and Omega = sum S_i^2 = 3/4 = j(j+1) at j = 1/2, central (Proposition 13.9); in the algebra: S_i S_j - S_j S_i = e_123 eps_ijk S_k, Omega = 3/4 (scalar)')
Sa = [{1: Fr(1, 2)}, {2: Fr(1, 2)}, {4: Fr(1, 2)}]
okalg = all(A3.add(A3.mul(Sa[i], Sa[j]), A3.mul(Sa[j], Sa[i]), -1) == {k_: v for k_, v in A3.mul({7: Fr(1)}, {[1, 2, 4][k]: Fr(1, 2) * eijk.get((i, j, k), 0)}).items() if v != 0} if i != j else True for i in range(3) for j in range(3) for k in [3 - i - j] if i != j)
Omega = {}
for S in Sa: Omega = A3.add(Omega, A3.mul(S, S))
chk('Q8c', okalg and Omega == {0: Fr(3, 4)}, 'the same two statements computed inside the bit rule (exact fractions): [S_i,S_j] = e_123 eps_ijk S_k and Omega = 3/4 in Cl(3,0)')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q9. Lecture 15: total spin.  J = A (x) 1 + 1 (x) B.  The spectrum of J^2 is j(j+1), j = |jA-jB| .. jA+jB, each with multiplicity 2j+1 (15.7); sigma(J3) = sigma(A3)+sigma(B3) (14.14);
#     the Clebsch-Gordan amplitudes of (15.6): C = sqrt(jA/(jA+jB)) and -sqrt(jB/(jA+jB)) at level jA+jB-1.
# ---------------------------------------------------------------------------------------------------------------------------------
def spin_mats(j):
    d = int(round(2 * j + 1)); ms = [j - k for k in range(d)]            # basis order m = j, j-1, ..., -j
    Jp = np.zeros((d, d), complex)
    for c_, m in enumerate(ms):
        if c_ > 0: Jp[c_ - 1, c_] = math.sqrt(j * (j + 1) - m * (m + 1))   # Proposition 13.24
    Jm = Jp.conj().T; J3 = np.diag(ms).astype(complex)
    return (Jp + Jm) / 2, (Jp - Jm) / (2j), J3, ms
for jA, jB in [(0.5, 0.5), (1, 0.5), (1, 1), (1.5, 1), (2, 1.5)]:
    A_ = spin_mats(jA); B_ = spin_mats(jB); dA = int(2 * jA + 1); dB = int(2 * jB + 1)
    okcomm = all(np.allclose(A_[0] @ A_[1] - A_[1] @ A_[0], 1j * A_[2]) for _ in [0]) and np.allclose(sum(M @ M for M in A_[:3]), jA * (jA + 1) * np.eye(dA))
    Jt = [np.kron(A_[i], np.eye(dB)) + np.kron(np.eye(dA), B_[i]) for i in range(3)]
    J2 = sum(M @ M for M in Jt)
    ev = np.round(np.linalg.eigvalsh(J2), 6)
    want = []
    jj = abs(jA - jB)
    while jj <= jA + jB + 1e-9:
        want += [round(jj * (jj + 1), 6)] * int(round(2 * jj + 1)); jj += 1
    j3ev = sorted(set(np.round(np.linalg.eigvalsh(Jt[2]), 6)))
    sumset = sorted(set(round(a + b, 6) for a in A_[3] for b in B_[3]))
    chk('Q9a', okcomm and sorted(ev) == sorted(want) and j3ev == sumset, f'jA={jA}, jB={jB}: [J_1,J_2]=iJ_3 and Casimir j(j+1) from the ladder formula; J^2 on H_A (x) H_B has eigenvalues j(j+1) for j = {abs(jA - jB)}..{jA + jB}, each 2j+1 times (Lecture 15.7: the direct sum of spin-j); sigma(J_3) = sigma(A_3)+sigma(B_3) (Theorem 14.14)')
    # CG amplitudes at level j = jA+jB-1, m = j
    jtop = jA + jB - 1; w, V = np.linalg.eigh(J2)
    idx = [i for i in range(len(w)) if abs(w[i] - jtop * (jtop + 1)) < 1e-6]
    Jz = Jt[2]; vec = None
    for i in idx:
        v = V[:, i]
        pass
    # restrict to the J^2 eigenspace and diagonalise J3 there
    Vs = V[:, idx]; Jz_s = Vs.conj().T @ Jz @ Vs; w3, U = np.linalg.eigh(Jz_s)
    k = int(np.argmin(abs(w3 - jtop))); v = Vs @ U[:, k]
    # component of |mA=jA, mB=jB-1> is index (0)*(dB)+1, of |mA=jA-1, mB=jB> is 1*dB+0
    a1 = v[0 * dB + 1]; a2 = v[1 * dB + 0]
    want1 = math.sqrt(jA / (jA + jB)); want2 = -math.sqrt(jB / (jA + jB))
    sgn = np.sign((a1 / want1).real)
    chk('Q9b', abs(abs(v[0 * dB + 1]) - want1) < 1e-9 and abs(sgn * a2 - want2) < 1e-9 and abs(np.linalg.norm(v) - 1) < 1e-9, f'jA={jA}, jB={jB}: the Clebsch-Gordan amplitudes at j=jA+jB-1, m=j are sqrt(jA/(jA+jB)) = {want1:.6f} on |jA,jB-1> and -sqrt(jB/(jA+jB)) = {want2:.6f} on |jA-1,jB> (the formulas of Section 15.6, reproduced numerically)')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q10. Lecture 14.6: entanglement.  Psi in C^2 (x) C^2 is simple iff its 2x2 coefficient matrix a has rank 1, iff det a = 0.
#      On real coefficients det a = a00 a11 - a01 a10 is a quadratic form on R^4 of signature (2,2): the cell Cl(2,2) = M4(R), the first cell the hyperbolicity filter excludes (B1-B3).
# ---------------------------------------------------------------------------------------------------------------------------------
Gd = np.zeros((4, 4))
Gd[0, 3] = Gd[3, 0] = 0.5; Gd[1, 2] = Gd[2, 1] = -0.5                     # a = (a00,a01,a10,a11): det a = a00 a11 - a01 a10
evals = np.linalg.eigvalsh(Gd)
chk('Q10a', sum(evals > 1e-9) == 2 and sum(evals < -1e-9) == 2, 'det on M2(R) = R^4 has signature (2,2): the null cone of this form is the set of simple tensors (rank <= 1): the Segre quadric, Lemma 14.19 (standard); (2,2) is the signature of the first ultrahyperbolic cell of the atlas')
okr = True; rng = random.Random(10)
for _ in range(200):
    u = [rng.randint(-3, 3) for _ in range(2)]; v = [rng.randint(-3, 3) for _ in range(2)]
    a = np.outer(u, v); okr &= abs(np.linalg.det(a)) < 1e-9
    b = np.array([[rng.randint(-3, 3) for _ in range(2)] for _ in range(2)])
    okr &= (abs(np.linalg.det(b)) < 1e-9) == (np.linalg.matrix_rank(b) <= 1)
bell = np.array([[1, 0], [0, 1]]) / math.sqrt(2)
chk('Q10b', okr and abs(np.linalg.det(bell) - 0.5) < 1e-12 and np.linalg.matrix_rank(bell) == 2, 'product states u v^T have det 0 (200 samples); the Bell state (|00>+|11>)/sqrt2 has det 1/2 != 0: entangled; the rank-1 / null-cone equivalence holds on integer samples')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q11. Lecture 21.3: the Dirac equation (i gamma^mu d_mu - m) Psi = 0 with {gamma^mu, gamma^nu} = 2 eta^mu^nu and eta = diag(-1,1,1,1) (footnote 54: signature (-,+,+,+)).
#      Gamma^0 squares to -1 and the three gamma^a to +1: in the atlas convention that is Cl(3,1) = M4(R) (cell [4,2], clock 2), NOT Cl(1,3) = M2(H) (cell [4,-2], clock 6).
#      On a plane wave exp(i(-E t + p.x)) the symbol is gamma^0 E - gamma^a p_a - m; where does its determinant vanish?
# ---------------------------------------------------------------------------------------------------------------------------------
Ir = np.eye(2); sx = np.array([[0, 1], [1, 0.]]); sz = np.array([[1, 0], [0, -1.]]); ee = np.array([[0, 1], [-1, 0.]])
cands = {'1': Ir, 'x': sx, 'z': sz, 'e': ee}
gfound = None
names = [(a, b) for a in cands for b in cands]
for combo in itertools.combinations(names, 4):
    Ms = [np.kron(cands[a], cands[b]) for a, b in combo]
    sq_ = [int(round(np.trace(M @ M) / 4)) for M in Ms]
    if sorted(sq_) == [-1, 1, 1, 1] and all(np.allclose(Ms[i] @ Ms[j] + Ms[j] @ Ms[i], 0) for i in range(4) for j in range(i)):
        order = sorted(range(4), key=lambda i: sq_[i]); gfound = [Ms[i] for i in order]; break
G = gfound                                                                      # G[0]^2 = -1, G[1..3]^2 = +1: the lecture's convention
ok_sig = G is not None and np.allclose(G[0] @ G[0], -np.eye(4)) and all(np.allclose(g @ g, np.eye(4)) for g in G[1:])
a3 = Alg(sig(3, 1)); mats31 = []
for a in range(16):
    M = np.eye(4)
    for i in range(4):
        if a >> i & 1: M = M @ ([G[1], G[2], G[3], G[0]][i])
    mats31.append(M)
okbit = all(np.allclose(mats31[a] @ mats31[b], a3.blade_mul(a, b)[0] * mats31[a ^ b]) for a in range(16) for b in range(16))
chk('Q11a', ok_sig and okbit and np.linalg.matrix_rank(np.array([m.flatten() for m in mats31])) == 16 and TYPES[(3 - 1) % 8] == 'R', f'real 4x4 matrices with gamma0^2 = -1 and gamma_a^2 = +1 (the lecture convention) satisfy the bit rule of Cl(3,1) and span M4(R); the atlas cell [4,2] has clock 2, type {TYPES[2]} (standard table)')
def detsym(gs, E, p, m):
    S = gs[0] * E - sum(gs[1 + a] * p[a] for a in range(3)) - m * np.eye(4)
    return np.linalg.det(S)
p3 = [0.3, -0.4, 1.2]; pp = sum(x * x for x in p3); m = 0.7
Ghalf = [1j * g for g in G]                                                      # i*G squares +1 on gamma0, -1 on the three gamma_a: Cl(1,3), complex 4x4 rep
Ew_lec = math.sqrt(pp - m * m); Ew_flip = math.sqrt(pp + m * m)                  # tachyonic vs physical
chk('Q11b', abs(detsym(G, Ew_lec, p3, m)) < 1e-9 and abs(detsym(G, Ew_flip, p3, m)) > 1e-3 and abs(detsym(Ghalf, Ew_flip, p3, m)) < 1e-9 and abs(detsym(Ghalf, Ew_lec, p3, m)) > 1e-3, f'with the lecture convention {{gamma,gamma}} = +2 eta, eta = (-,+,+,+), the determinant of the symbol vanishes at E^2 = |p|^2 - m^2 (here E = {Ew_lec:.4f}): the wrong sign for a mass; with the squares flipped (gamma0^2 = +1, gamma_a^2 = -1: the atlas cell Cl(1,3) = M2(H)) it vanishes at E^2 = |p|^2 + m^2 (E = {Ew_flip:.4f}). The notes are a student transcription: we flag the convention, not the lecturer')
chk('Q11c', TYPES[(1 - 3) % 8] == 'H' and TYPES[(3 - 1) % 8] == 'R', 'the two conventions are two different real algebras with the same complexification M4(C): Cl(1,3) clock 6 = M2(H), Cl(3,1) clock 2 = M4(R) (standard table); the mirror reading Cl(q,p) of row C4 is exactly this sign choice')

# ---------------------------------------------------------------------------------------------------------------------------------
# Q12. Lecture 1.1(b) and Axioms 2-3: Stern-Gerlach.  In Cl(3,0) = M2(C) the observables with spectrum {+1,-1} are the unit vectors; P_z+ = (1+e_3)/2, P_x+ = (1+e_1)/2 are idempotents;
#      Axiom 3 probability = Tr(P rho); the three-step sequence z -> x -> z gives 1, 1/2, 1/2 as in the lecture's figures.
# ---------------------------------------------------------------------------------------------------------------------------------
Pz = (np.eye(2) + Pb[4]) / 2; Px = (np.eye(2) + Pb[1]) / 2; Pzm = (np.eye(2) - Pb[4]) / 2
rho = Pz
p_zz = np.trace(Pz @ rho).real; p_zm = np.trace(Pzm @ rho).real; p_x = np.trace(Px @ rho).real
rho_x = Px @ rho @ Px / np.trace(Px @ rho @ Px)                                  # Axiom 5: projective dynamics
p_z_after = np.trace(Pz @ rho_x).real
chk('Q12', np.allclose(Pz @ Pz, Pz) and np.allclose(Px @ Px, Px) and abs(p_zz - 1) < 1e-12 and abs(p_zm) < 1e-12 and abs(p_x - 0.5) < 1e-12 and abs(p_z_after - 0.5) < 1e-12 and not np.allclose(Pz @ Px, Px @ Pz), 'SG(z) then SG(z): 100% / 0%; SG(z) then SG(x): 50%; then SG(z) again: 50% (Lecture 1.1(b), Axioms 3 and 5): the projectors are (1 +/- e_i)/2 in Cl(3,0), and e_3, e_1 anticommute, so the two measurements are incompatible (standard)')

print()
print(f'bridge_check_qm: {N_OK} ok, {N_BAD} failed')
sys.exit(1 if N_BAD else 0)
