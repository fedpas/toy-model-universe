# reports: the three research reports behind the Lenses page

The Lenses page of the atlas (page 8; steps 18 Category, 19 Baez, 20 Schuller) is built from three research reports. This folder ships them whole: the report pages, the scripts that build them, their own test suites and sabotage scripts, their logs, the work-in-progress zips, the errata and the combined translation matrix. Every number in a report page is read from a log, a data file or the matrix module; none is typed by hand. Each report says what is checked (a script recomputes it), standard, ours or open; nothing in them is a result about nature.

## What is here

| Path | What it is |
|---|---|
| `html/category_atlas_report.html` | Category lens: "What is label 0, seen through categories?" (v1.2). Self-contained, opens offline, light and dark. |
| `html/baez_atlas_report.html` | Seven Baez papers and the atlas (corrected 6 October 2026). |
| `html/schuller_bridge_report.html` | Schuller and the atlas: a translation matrix, with the second pass on fibre and base (corrected 6 October 2026). |
| `category/` | Sources of the category report: `cat_check.py` (52 checks), `mutate_cat.py` (54 sabotages), `content_cat.py`, `figs_cat.py`, `matrix_cat.py`, `build_report_cat.py`, `test_report_cat.py` (78 tests), the styles and the page script, `cat_results.json`, `logs/`, `digests/` (reading notes on two of the papers), `README_cat.md`. |
| `baez/` | Sources of the Baez report: `baez_check.py` (56 checks), `mutate_baez.py` (56 sabotages), `figs_baez.py`, `matrix_baez.py`, `build_report_baez.py`, `test_report_baez.py` (48 tests), styles, page script, `logs/`, `README_baez.md`. |
| `schuller/` | Sources of the Schuller report: `bridge_check.py` (77), `bridge_check_qm.py` (51), `fibre_check.py` (35), `mutate_fibre.py` (21 sabotages), `fibre_section.py`, `matrix_data.py`, `build_report.py`, `test_report.py` (32 tests), `logs/`, `README_schuller.md`, `CORRECTION_F12.md`. |
| `zips/category_atlas_wip.zip`, `zips/baez_wip.zip`, `zips/schuller_bridge_wip.zip` | The three folders above, zipped (members `category/…`, `baez/…`, `schuller/…`): each zip unpacks to exactly its folder. |
| `errata_changelog_6oct.md` | The first correction round of 6 October 2026 (E-002 to E-011), as delivered that morning. |
| `errata_changelog_6oct_addendum.md` | The second round of the same day (E-039 to E-068): wording found too strong (and one stale under-claim) when the reports became chapters. |
| `translation_matrix.json` | The combined translation matrix: 131 rows (Schuller 43, Baez 48, category 40) × 22 atlas columns, 246 cells. |
| `make_matrix_json.py` | Builds `translation_matrix.json` from the three matrix modules; then `node make_matrix_data.mjs reports/translation_matrix.json` builds the app's `translationMatrixData.js`. |
| `make_check_table.py` | Writes the table "check id → one line" of `selfcheck/reports/README.md` from the scripts' own output. |
| `make_package.py` | Rebuilds the zips from the folders (deterministic) and writes `MANIFEST.json`. |
| `MANIFEST.json` | sha256 and size of every file in this folder (itself excepted). |
| `run_report_tests.sh` | Runs everything here: the five check scripts against their logs, the three report suites, the generated files; `--mutation` adds the sabotage scripts. |

The five check scripts are also in `selfcheck/reports/` (where the Lenses page offers them for download); the copies here are byte-identical, and `test_reports.mjs` checks it.

## Running

Python 3 with numpy, scipy and networkx (the category suite's browser part also needs Python's playwright with Chromium). The scripts find the atlas package two folders up (`selfcheck/steps15_17/bitcliff.py`); set `ATLAS_PKG` to run them from elsewhere.

    sh reports/run_report_tests.sh              # about 1 minute
    sh reports/run_report_tests.sh --mutation   # adds the three sabotage scripts, about 40 minutes on two cores
    cd reports/category && python3 build_report_cat.py && python3 test_report_cat.py      # one report: rebuild ../html/ and test it

The package's own test `test_reports.mjs` (in `run_tests.sh --data`) runs a faster subset: the data checks of this folder, the three suites without a browser, and the check scripts against their logs.

## Not shipped, and why

- The papers' texts (`txt/` in each folder, made with `pdftotext` from the PDFs): they are the authors' work. Without them `baez_check.py` skips check R1 (the cross-citations) and says so, eleven Baez report tests and seven Schuller report tests are skipped and say so, and the sabotage of R1 cannot run. With the texts put back in `txt/`, everything runs as recorded in the logs (which were made with them).
- Screenshots, checkpoint archives, backups and scratch scripts of the working folders; a screenshot helper of the category folder.
- Anything private: no address of any person is in any file or zip member (`test_license.mjs` and `test_reports.mjs` check it).

Licence: PolyForm Noncommercial 1.0.0, as the rest of the package (see `LICENSE` and `NOTICE` at the package root).
