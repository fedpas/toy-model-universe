#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds ../html/baez_atlas_report.html: one self-contained page (inline CSS, SVG and a little JS, no external request).
Every number in it is read from logs/baez_check.log (the checks), logs/mutate_baez.log (the sabotage run), logs/baez_figdata.json (figure data written by baez_check.py), or computed from matrix_baez.py
(the matrix) and the atlas engine (bitcliff); none is typed by hand.
Run: python3 baez_check.py > logs/baez_check.log ; python3 mutate_baez.py > logs/mutate_baez.log ; python3 build_report_baez.py"""
import os, sys, re, json, html, math
HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.environ.get('ATLAS_PKG', os.path.join(HERE, '..', '..'))      # the package this folder ships in: two levels up from reports/baez/
sys.path.insert(0, os.path.join(PKG, 'selfcheck', 'steps15_17'))
from bitcliff import Alg, sig, pc, TYPES
sys.path.insert(0, HERE)
import matrix_baez as MD
import figs_baez as FG

E = html.escape
TODAY = '5 October 2026'; VERSION = 'corrected 6 October 2026 (row G.1; wording, E-049 to E-054)'
tip = FG.tip

# ------------------------------------------------------------------ the checks (from the log) and the sabotage run
def read_log(name):
    ok, bad, ids = 0, 0, []
    for line in open(os.path.join(HERE, 'logs', name), encoding='utf-8'):
        m = re.match(r'(ok  |FAIL) (\S+?):', line)
        if m:
            if m.group(1).startswith('ok'): ok += 1
            else: bad += 1
            ids.append(m.group(2))
    return ok, bad, ids
OK, BAD, IDS = read_log('baez_check.log')
assert BAD == 0, 'a check fails: fix it before building the report'
_m = re.search(r'mutants caught: (\d+) of (\d+)', open(os.environ.get('MUT_LOG') or os.path.join(HERE, 'logs', 'mutate_baez.log'), encoding='utf-8').read())
MUT_OK, MUT_ALL = int(_m.group(1)), int(_m.group(2))
FD = json.load(open(os.path.join(HERE, 'logs', 'baez_figdata.json'), encoding='utf-8'))
assert FD['counts']['ok'] == OK and FD['counts']['bad'] == 0
EDGES_FOUND = {tuple(e) for e in FD['edges']}

def block(pred): return sum(1 for i in IDS if pred(i))
BLOCKS = [
    ('R', 'How the papers cite one another (arXiv numbers found in the texts)', block(lambda i: i.startswith('R')), 'baez_check.py'),
    ('H', 'One generation as five bits: Peirce rule, charges, anomalies, Fock space, Cl(5,5), so(10), TKK, su(3) × su(2)', block(lambda i: i.startswith('H')), 'baez_check.py'),
    ('E', 'E8 > E7 > E6 > so(10) > sl5 > sl3 + sl2: Levi pieces, Peirce counts, the 27-line graph and its Schläfli complement, the generation plane, three D6, 3 × 32', block(lambda i: i.startswith('E')), 'baez_check.py'),
    ('O', 'Octonions, split octonions, Albert algebra, F4, stabilisers, triality; h2(O) of signature (1,9)', block(lambda i: i.startswith('O')), 'baez_check.py'),
    ('S', 'Standard Model subalgebras: the tower of triples under the E7 su(3) + su(2); the Albert-algebra one on the 27', block(lambda i: i.startswith('S')), 'baez_check.py'),
    ('K', 'Kepler: Poisson algebra, so(4)/e(3)/so(3,1), hidden SU(2) × SU(2), shells, Madelung, so(4,2)', block(lambda i: i.startswith('K')), 'baez_check.py'),
    ('T', 'Triangulations: Eisenstein theta series, E7 shadows, Gauss–Bonnet, the form of signature (1,9), the clock of Cl(1,9)', block(lambda i: i.startswith('T')), 'baez_check.py'),
    ('C', 'Cospans: Frobenius forms of the label algebra for 117 patterns of generator squares', block(lambda i: i.startswith('C')), 'baez_check.py'),
]
assert sum(b[2] for b in BLOCKS) == OK, (sum(b[2] for b in BLOCKS), OK)

# ------------------------------------------------------------------ the matrix
ST = MD.stats()
ROWS, COLS = MD.ROWS, MD.COLS
GRADE_WORD = {'E': 'exact', 'S': 'structural', 'A': 'analogy'}
best = ST['best']; nrows = ST['n']; ncells = ST['total_cells']
SRC_NAME = {'G': 'Baez–Schwahn · The Standard Model gauge group from the exceptional Jordan algebra', 'J': 'Baez–Bokor–Boyle · Jordan pair quantum theory and the Standard Model',
            'E': 'Baez · Three generations in E7', 'D': 'Baez–Pumplün · Three-dimensional geometry in exceptional mathematics', 'K': 'Baez · Second quantization for the Kepler problem',
            'T': 'Baez · Triangulations of the sphere', 'C': 'Baez · Double categories of open systems: the cospan approach (overview level)'}
SRC_SHORT = {'G': 'Gauge group', 'J': 'Jordan pair', 'E': 'E7', 'D': '3D geometry', 'K': 'Kepler', 'T': 'Triangulations', 'C': 'Cospans'}
ORDER = 'GJEDKTC'
SRC_N = {s: sum(1 for r in ROWS if r[1] == s) for s in ORDER}
GAP_ROWS = [r for r in ROWS if not r[3]]

def matrix_html():
    bands = [('pages 1–5', 5), ('steps 1–14', 14), ('steps 15–17', 3)]
    out = ['<div class="mxwrap" role="group" aria-label="Translation matrix, rows are objects in the seven papers, columns are atlas pages and steps"><div class="mx">']
    out.append('<div class="mx-corner"></div>')
    for name, span in bands: out.append(f'<div class="mx-band" style="grid-column: span {span}">{name}</div>')
    out.append('<div class="mx-corner2">row</div>')
    for k, short, long_, page in COLS: out.append(f'<div class="mx-ch" title="{E(long_)}"><span>{E(short)}</span></div>')
    cur = None
    for rid, src, title, cells in ROWS:
        if src != cur:
            cur = src
            out.append(f'<div class="mx-grp" style="grid-column: 1 / -1">{E(SRC_NAME[src])} <b>· {SRC_N[src]} rows</b></div>')
        gap = not cells
        lab = f'<span class="rid">{rid}</span> {E(title)}'
        if gap: lab = '<span class="pill open">gap</span> ' + lab
        out.append(f'<div class="rl{" gaprow" if gap else ""}" title="{E(title)}">{lab}</div>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                t = tip(f'{rid}  {title}', f'× {long_} ({page})', f'{GRADE_WORD[g].capitalize()} ({g})', note)
                out.append(f'<div class="c g-{g}" tabindex="0" data-tip="{t}" aria-label="{E(rid)} by {E(short)}: {GRADE_WORD[g]}">{g}</div>')
            else:
                out.append('<div class="c z"></div>')
    out.append('</div></div>')
    rows = []
    for rid, src, title, cells in ROWS:
        if not cells: rows.append(f'<tr><td>{rid}</td><td>{E(title)}</td><td colspan="3"><i>gap: no counterpart in the atlas</i></td></tr>')
        for k, short, long_, page in COLS:
            if k in cells:
                g, note = cells[k]
                rows.append(f'<tr><td>{rid}</td><td>{E(title)}</td><td>{E(long_)}</td><td>{g} {GRADE_WORD[g]}</td><td>{E(note)}</td></tr>')
    out.append('<details class="tv"><summary>Table view of the same matrix (%d filled cells and %d gap rows)</summary><div class="tvscroll"><table><thead><tr><th>Row</th><th>Object in the papers</th><th>Atlas column</th><th>Grade</th><th>What matches</th></tr></thead><tbody>%s</tbody></table></div></details>' % (ncells, len(GAP_ROWS), ''.join(rows)))
    return '\n'.join(out)

def coverage_svg():
    W = 520; x0 = 118; scale = 17
    H = 12 + 38 * len(ORDER)
    parts = [f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Rows by best grade for each paper" class="chart">']
    y = 8
    for s_ in ORDER:
        parts.append(f'<text x="0" y="{y + 14}" class="t">{SRC_SHORT[s_]}</text><text x="0" y="{y + 27}" class="t2">{SRC_N[s_]} rows</text>')
        x = x0
        for g in ('E', 'S', 'A', 'gap'):
            n = ST['bysrc'][s_].get(g, 0)
            if not n: continue
            w = n * scale; cls = f'sv-{g}' if g != 'gap' else 'sv-gap'
            tp = f'{SRC_SHORT[s_]}: {n} rows, best grade {GRADE_WORD.get(g, "none (gap)")}'
            parts.append(f'<rect x="{x + 1}" y="{y}" width="{w - 2}" height="28" rx="3" class="{cls}" data-tip="{E(tp, quote=True)}" tabindex="0"/>')
            txt = (g if g != 'gap' else '–') + ('' if w < 30 else f' {n}')
            parts.append(f'<text x="{x + w / 2}" y="{y + 19}" text-anchor="middle" class="bar-{g}">{txt}</text>')
            x += w
        y += 38
    parts.append('</svg>')
    leg = '<div class="legend"><span><i class="sw g-E">E</i> exact</span><span><i class="sw g-S">S</i> structural</span><span><i class="sw g-A">A</i> analogy</span><span><i class="sw gapsw">–</i> gap (no counterpart)</span></div>'
    cnt = {k: sum(ST['col'][k].values()) for k, *_ in COLS}
    order = [k for k in sorted(cnt, key=lambda k: (-cnt[k], [c[0] for c in COLS].index(k))) if cnt[k] > 0]
    bh = 18; H2 = bh * len(order) + 8; xl = 78; sc = 14
    long_of = {c[0]: c[2] for c in COLS}; short_of = {c[0]: c[1] for c in COLS}
    p2 = [f'<svg viewBox="0 0 440 {H2}" role="img" aria-label="Filled cells per atlas column" class="chart">']
    for i, k in enumerate(order):
        yy = 3 + i * bh
        p2.append(f'<text x="{xl - 8}" y="{yy + 12}" text-anchor="end" class="t">{E(short_of[k])}</text>')
        x = xl
        for g in ('E', 'S', 'A'):
            n = ST['col'][k].get(g, 0)
            if not n: continue
            w = n * sc
            p2.append(f'<rect x="{x + 1}" y="{yy}" width="{max(w - 2, 2)}" height="14" rx="2" class="sv-{g}" data-tip="{E(f"{long_of[k]}: {n} {GRADE_WORD[g]} cell(s)", quote=True)}" tabindex="0"/>')
            x += w
        p2.append(f'<text x="{x + 5}" y="{yy + 12}" class="t2">{cnt[k]}</text>')
    p2.append('</svg>')
    unused = [short_of[k] for k, *_ in COLS if cnt[k] == 0]
    return ('<div class="figcols"><div><div class="figtitle">Rows by their best grade</div>' + ''.join(parts) + leg + '</div><div><div class="figtitle">Filled cells per atlas column</div>' + ''.join(p2)
            + f'<div class="cap2">Atlas columns with no cell at all: {len(unused)} of {len(COLS)} ({E(", ".join(unused))}). The seven papers are about algebra and groups, not about electromagnetism, gravity, mechanics or the Dirac equation.</div></div></div>')

def chip(kind): return f'<span class="chip {kind}"><i></i>{kind}</span>'

def finding(fid, title, chips, left, right='', one=False):
    cls = 'fbody one' if (one or not right) else 'fbody'
    ch = ''.join(chip(c) for c in chips)
    return (f'<article class="finding" id="{fid.lower()}"><div class="fhead"><span class="fid">{fid}</span><h3>{title}</h3><div class="chips">{ch}</div></div>'
            f'<div class="{cls}"><div>{left}</div>{("<div>" + right + "</div>") if right else ""}</div></article>')

def wrap_sv(h):                                           # a drawing scrolls sideways on a phone instead of shrinking its text to nothing
    return re.sub(r'(<svg [^>]*class="chart[^"]*"[^>]*>.*?</svg>)', r'<div class="sv">\1</div>', h, flags=re.S)


def fig(title, body, cap=''):
    return f'<div class="figtitle">{title}</div>{wrap_sv(body)}' + (f'<figcaption>{cap}</figcaption>' if cap else '')

# ------------------------------------------------------------------ numbers used in the text, all from the data
S = FD['stab']; L = FD['ladder']
n_cells_E, n_cells_S, n_cells_A = ST['cellg']['E'], ST['cellg']['S'], ST['cellg']['A']
bestE, bestS, bestA, bestG = best.get('E', 0), best.get('S', 0), best.get('A', 0), best.get('gap', 0)
assert bestE + bestS + bestA + bestG == nrows
FR = FD['frob']
kdict = FD['kepler']
cont, cont7 = FD['cont'], FD['cont7']
TH = FD['theta'][:8]
assert TH == [1, 6, 0, 6, 6, 0, 0, 12]
assert L['sizes'] == [240, 126, 72, 40, 20, 8] and L['g1'] == [56, 27, 16, 10, 6]
assert {k: int(v) for k, v in S.items()} == dict(f4=52, frame=28, B=16, A=36, X=18, SM=12, derived=11)

# ------------------------------------------------------------------ the seven papers
PAPER_CARDS = [
 ('gauge', 'The Standard Model Gauge Group from the Exceptional Jordan Algebra', 'John C. Baez, Paul Schwahn · arXiv:2606.15235',
  'The group F4 acts on pairs of Jordan subalgebras X ⊂ B of the Albert algebra h3(O), with X ≅ h2(C) (a qubit) and B ≅ h3(C) (a qutrit). The stabiliser of X intersected with the identity component of the stabiliser of B is the Standard Model gauge group S(U(2) × U(3)) (Theorems 1 and 2).',
  'Octonions, h3(O), the Jordan-frame split, f4 (52), the stabiliser dimensions 28, 16, 36, 18, 12, the structure su(2) + su(3) + u(1) of the 12, triality, h2(O) of signature (1,9) (O1–O3, O3i), and how that group acts on the 27 (S2). Lie algebra level only.', ['checked', 'standard', 'open']),
 ('jordan', 'Jordan Pair Quantum Theory and the Standard Model', 'John C. Baez, Endre Bokor, Latham Boyle · arXiv:2607.10833',
  'Hermitian Jordan pairs and triples, their Peirce decomposition and 3-graded Lie algebras; the bi-Cayley triple (16 complex dimensions) cut by two colinear minimal tripotents falls into the six pieces of one generation of fermions (their eqs. (69), (75), (76)); ordinary quantum mechanics rewritten with triples.',
  'The six pieces from five bits and the Hamming-distance Peirce rule; hypercharge and charge as bit counts; anomaly sums; the Fock realisation of the pair and its triple product; the four triples as one ladder (H1–H3, E1–E2, S1).', ['checked', 'standard', 'ours']),
 ('e7', 'Three Generations in E7', 'John C. Baez · arXiv:2608.06271',
  'Starting from g_SM = sl3 + sl2 + C inside e7, the algebra splits as a subalgebra containing g_SM plus three 32-dimensional subspaces, each a copy of one generation with antiparticles and each a copy of the exterior algebra ΛC⁵ (Prop. 1, Lemmas 2–4, Prop. 5, Thm. 12).',
  'The Levi series e8 > e7 > … (the paper’s Table 2 starts at e7) and the grade-1 sizes 56, 27, 16, 10, 6; the 126 roots by their shadows on the generation plane; the three D6; the weight systems of the 32 as ΛC⁶ even and as the 5-bit labels (E1–E3).', ['checked', 'standard', 'ours']),
 ('geo', 'Three-Dimensional Geometry in Exceptional Mathematics', 'John Baez, Susanne Pumplün · arXiv:2609.07538',
  'Functorial constructions of the octonions O (from a 3d complex vector space with an inner product and a complex volume form), the split octonions O′ (from a 3d real space with a volume form) and the bioctonions O_C (from a 3d complex space with a complex volume form); applications to 3-dimensional manifolds; the complex Albert algebra h3(O_C) and e6 ⊃ sl3 + sl3 + sl3 from three complex 3-spaces.',
  'Octonions as the XOR rule with another sign; Zorn’s product on Λ(R³) as join and meet on labels; the complement automorphism (the complement label with the Clifford-conjugation sign; not a Hodge star: there is no metric); the Peirce reading of popcount (O1, O2). The 3-manifold applications and the Z3-grading of e6 are not computed.', ['checked', 'standard']),
 ('kepler', 'Second Quantization for the Kepler Problem', 'John C. Baez · arXiv:2507.11428',
  'The hidden SU(2) × SU(2) of the Kepler problem; the spin-½ bound states are unitarily equivalent, as representations of SU(2) × SU(2), to the solutions of the Weyl equation on R × S³; the Fock space on them is a free chiral field; a modified Hamiltonian gives the Madelung rules and the rough shape of the periodic table.',
  'The Poisson algebra (the paper treats E < 0 and so(4); the versions e(3), so(3,1) for E = 0, E > 0 are standard), the three of them as one trio, the half-sums A, B, left and right multiplication on H, the shell counts, the Madelung order and the 4 + 7 + 4 grading of so(4,2) (K1–K4). The Weyl equation itself is not touched.', ['checked', 'ours']),
 ('tri', 'Triangulations of the Sphere', 'John C. Baez · arXiv:2606.10072',
  'Thurston’s theorem: stars cut from the Eisenstein lattice fold into polyhedra with twelve cone points; the number of triangles is a hermitian form on C¹⁰ of signature (1,9); Baez asks whether the resemblance to ten-dimensional Minkowski space is a coincidence (“I do not know”). (The 10 there is a complex dimension; the 10 of h2(O) is real; we know no mechanism.)',
  'The theta series of the Eisenstein lattice, the form from the shoelace formula (the paper cites Engel and Smillie for it; not read), Gauss–Bonnet, the clock of Cl(1,9), the E7 shadows on the same lattice, and h2(O) = R¹·⁹ (T1–T4, E3a, O3i). The moduli space and Thurston’s bijection are not touched.', ['checked', 'open']),
 ('cospan', 'Double Categories of Open Systems: the Cospan Approach', 'John C. Baez · arXiv:2509.22584',
  'An overview of double categories of open systems composed by identifying variables: structured and decorated cospans, open Petri nets, open dynamical systems, the exoskeleton and outer shell of a double category, and hypergraph double categories as a common framework.',
  'Read at overview level. Only one thing is computed: the Frobenius forms of the label algebra (C1); the composition of open systems is read, by us, as contraction of shared bits (an analogy).', ['checked', 'ours', 'open']),
]
def cards_html():
    out = []
    for k, title, by, says, did, chips in PAPER_CARDS:
        out.append(f'<div class="card paper"><h3>{E(title)}</h3><div class="by">{E(by)}</div><p><b>It says.</b> {says}</p><p><b>What we computed.</b> {did}</p><p>{"".join(chip(c) for c in chips)}</p></div>')
    return ''.join(out)

# ------------------------------------------------------------------ the exploration (views tried before choosing)
LENSES = [
 ('1 · Who cites whom', 'kept', 'The arXiv numbers in the texts: the Jordan-pair paper cites the gauge-group paper, the E7 paper cites the Jordan-pair paper, the geometry paper cites the gauge-group paper. The Kepler, triangulation and cospan papers cite none of the others and are cited by none. So any link beyond these three is ours.', 'R1'),
 ('2 · Shared algebraic objects', 'kept', 'Octonions, h3(O), the four hermitian triples, the series e7 > e6 > so(10) > sl5 > sl3 + sl2 (and e8 above it). Rebuilt on bit labels; everything the papers state about their counts and Peirce pieces was recomputed.', 'O1–O3, E1, E2'),
 ('3 · The Standard Model as a shared group', 'partly', 'Three papers use it, in three embeddings (stabiliser in F4; K0 of M_{3,2}(C); g_SM in e7). The two we could compare act differently on the 27, so a naive “same group, same representation” expectation is a dead end; what survives is the split of the nested triples under the E7 paper’s su(3) + su(2), which contains one generation at the bi-Cayley step (S1); the word “builds” is ours.', 'S1, S2'),
 ('4 · A shared lattice', 'kept', 'The Eisenstein lattice of the triangulation note is the plane of the generation sl3 in the E7 paper: the root shadows fill the shells the theta series allows.', 'T1a, T1b, E3a'),
 ('5 · A dictionary of bits', 'kept', 'Every finite structure we computed has a bit-label model: 16 = even 5-bit labels, 10 = pairs, 6 = 2 × 3, 32 = all five-bit labels, 8 = three-bit labels for the octonions and for Λ(R³).', 'H, E2c, E3e, O1, O2'),
 ('6 · Clifford signature and the clock', 'kept', 'What the signatures that occur (1,9), (4,2), (9,0), (5,5) are as algebras: h2(O) and the Spin(9) spinor, Cl(1,9) = M₃₂(ℝ), so(4,2) as bivectors.', 'O3i, T4, K4'),
 ('7 · Fock space and second quantisation', 'partly', 'Kepler’s Fock space and the E7 paper’s ΛC⁵ are both “subsets of a labelled set”; the atlas has that structure, the physical identification is our reading.', 'H3a, H3b, K3'),
 ('8 · Composition of open systems', 'deadend', 'The cospan paper is about categories; the atlas has none. All that survives is a reading of shared wires as contracted bits and a Frobenius-form check on the label algebra. We do not claim more.', 'C1'),
 ('9 · Matching numbers (10, 12, 16, 27, 32…)', 'deadend', 'Many of the same numbers occur across the papers. Without a mechanism they are not evidence: we kept only the matches that came with a computation, and left (1,9) against ten-dimensional Minkowski space as open (a real 10 against a complex 10; no mechanism).', 'T4, O3i'),
]
CHIPLAB = {'kept': 'kept', 'partly': 'partly', 'deadend': 'dead end', 'recalled': 'recalled'}
LENS_HTML = ''.join(f'<div class="card"><h3>{E(t)}</h3><p><span class="chip {c}"><i></i>{CHIPLAB[c]}</span> <span class="ids">{E(ids)}</span></p><p>{E(txt)}</p></div>' for t, c, txt, ids in LENSES)

# ------------------------------------------------------------------ relation list under figure 1
KINDLAB = {'cite': 'cites', 'chk': 'computed', 'our': 'our reading', 'opn': 'open'}
REL_HTML = '<div class="rel">' + ''.join(f'<div class="r"><span class="badge">{lab}</span><div><b>{E(FG.PAPERS[a][0])}</b> and <b>{E(FG.PAPERS[b][0])}</b> <span class="chip {"checked" if kind in ("cite", "chk") else ("ours" if kind == "our" else "open")}"><i></i>{KINDLAB[kind]}</span><br>{E(txt)}</div></div>' for lab, a, b, kind, txt in FG.REL) + '</div>'

# ------------------------------------------------------------------ findings
J1 = finding('J1', 'One generation is the 16 even five-bit labels, and the Peirce rule is a Hamming distance', ['checked', 'ours'],
 '<p>Baez, Bokor and Boyle cut the 16 complex dimensions of the bi-Cayley triple with the Peirce projectors of two colinear minimal tripotents and find six non-vanishing pieces of dimension 1, 1, 6, 3, 3, 2: the six irreducible representations of one generation (their eqs. (69), (75), (76)), and three combinations that vanish.</p>'
 '<p>Put two weak bits and three colour bits on five-bit labels. The 16 even labels are the 16. The Peirce eigenvalue of a label x for a tripotent sitting at label S is <code>1 − d(x, S)/4</code>, with d the Hamming distance. For the vacuum label and the weak pair this gives exactly the six pieces, as the classes (weak bits set, colour bits set); the three vanishing combinations are empty. Hypercharge is linear in the bit counts, <code>Y = a/2 − b/3</code>, the charge is <code>Q = (first weak bit) − b/3</code>, and the sums of Y, Q, Y³ and the two mixed anomalies over the 16 labels are all 0: the standard anomaly cancellation, recomputed over the labels. The complement mask 11111 maps even to odd labels and flips Q and Y (H2c); calling that flip charge conjugation is ours.</p>'
 '<p class="not">What this is not: a new result about the Standard Model. The six pieces and their hypercharges are in the paper. On the labels the Peirce value is 1 − d/4, so the six non-empty classes are the six pieces (a statement about Hamming distances, checked), and the charges are counts; reading this as the reason why those pieces occur is ours. The names of the pieces follow the paper’s eq. (69).</p>'
 '<p class="ids">checks H1a–H2d.</p>',
 fig('The 32 labels by (weak bits, colour bits)', FG.gentable_svg(FD), 'Coloured cells: the six pieces of one generation, with their Peirce eigenvalue pair for the two tripotents, hypercharge Y and multiplicity. Dashed cells: the odd labels, the complements of the even ones (Y and Q flipped). Bars: the grading 1, 5, 10, 10, 5, 1 of all 32 labels. Hover for the particle and its charges.'))

J2 = finding('J2', 'The Fock space of five bits carries the triple’s 3-grading and its triple product', ['checked', 'standard'],
 '<p>Five fermionic modes act on the 32 labels (a Jordan–Wigner sign; the canonical anticommutation relations hold; the number operator is the popcount). The operators a + a⁺ (square +1) and a − a⁺ (square −1) are 32 × 32 real matrices that multiply by the bit rule of Cl(5,5): the 1024 blades are linearly independent, so Cl(5,5) = M₃₂(ℝ), the cell [10, 0] at clock 0, and the 32 is its module.</p>'
 '<p>The 45 bivectors close into so(5,5), the real form of so(10) that the signature of Cl(5,5) gives (a standard fact, not computed here; over ℂ it is the so(10) of the paper); the number operator minus 5/2 is one of them; ad(N) splits the algebra into degrees +2, 0, −2 of dimensions 10, 25, 10: the 3-grading of D III. For kets x<sub>A</sub> = ½ Σ A<sub>ij</sub> a<sub>i</sub>⁺a<sub>j</sub>⁺ with A skew, the commutator triple [[x<sub>A</sub>, x<sub>B</sub>⁺], x<sub>C</sub>] equals 2 · x of ½(AB⁺C + CB⁺A), the triple product of skew matrices a₅(ℂ) in Table 1 of the paper (tested on random real skew matrices; the paper’s triple is skew-linear in the middle slot). The tripotent a₀⁺a₁⁺ has Peirce eigenvalue |{i,j} ∩ {0,1}|/2 on the ten kets, with multiplicities 1, 6, 3. Under su(2) on the weak bits and su(3) on the colour bits (generators a<sub>i</sub>⁺a<sub>j</sub>) the Casimirs and highest weights of the six pieces are those of (3,2), (3̄,1) twice, (1,2), (1,1) twice.</p>'
 '<p class="not">All standard; what is new is only that each statement comes out of one operator rule on the 32 labels, so that “bras, operators, kets” is “annihilate, number-preserving, create”.</p>'
 '<p class="ids">checks H3a–H3f.</p>',
 '<div class="figtitle">What the three degrees are</div><table class="tabsm"><thead><tr><th>degree (ad N)</th><th>dim</th><th>meaning on labels</th></tr></thead><tbody>'
 '<tr><td>+2</td><td class="num">10</td><td>Λ² ℂ⁵: create a pair</td></tr><tr><td>0</td><td class="num">25</td><td>gl(5): move a particle</td></tr><tr><td>−2</td><td class="num">10</td><td>annihilate a pair</td></tr></tbody></table>'
 '<figcaption>so(10) = 10 + 25 + 10 under the number operator (real form so(5,5), complexified): the 3-graded Lie algebra whose positive part is the Jordan triple of skew 5 × 5 matrices (type D III), as in the paper’s Section 2.4.</figcaption>')

J3 = finding('J3', 'The four exceptional triples are one ladder; under the E7 paper’s su(3) + su(2) the nested triples contain (3,2), then (3̄,1) + (1,1), then one generation, then 11 more states', ['checked', 'ours'],
 '<p>Delete the simple roots α₈, α₇, α₆, α₅, α₄ of E8 one at a time (Bourbaki labels). The root systems have 240, 126, 72, 40, 20, 8 roots, the algebras dimension 248, 133, 78, 45, 24, 11 (the paper’s Table 2 gives 133, 78, 45, 24, 11), and the roots with coefficient 1 on the deleted node number 56, 27, 16, 10, 6. From e7 down each step is 3-graded: |roots(e<sub>n</sub>)| = |roots(e<sub>n−1</sub>)| + 2 × (grade-1 size), so 126 = 72 + 2·27, 72 = 40 + 2·16, 40 = 20 + 2·10, 20 = 8 + 2·6; the first step is 5-graded, 240 = 126 + 2·56 + 2. The grade-1 pieces are the Albert, bi-Cayley, a₅(ℂ) and M₃,₂(ℂ) triples. Read as Jordan data they have rank and multiplicities (r, a, b) = (3,8,0), (2,6,4), (2,4,2), (2,2,1), and the Peirce counts 0, ½, 1 of a minimal tripotent computed from root inner products agree with dim = r + a·r(r−1)/2 + b·r and the Peirce formulas for all four.</p>'
 '<p>The root graphs, coloured by inner product, are isomorphic to label models: 16 = even five-bit labels with inner product 2 − d/2 (the five-demicube), 10 = two-subsets with the size of the intersection, 6 = {u,d} × {r,g,b}, and the 27 with inner product 0 form the strongly regular graph srg(27, 10, 1, 5), the intersection graph of the 27 lines on a cubic surface; its complement, inner product 1, is the Schläfli graph srg(27, 16, 10, 8), the edge graph of the Gosset polytope 2₂₁. So the rule of J1 is the Peirce rule of all the triples.</p>'
 '<p>Now take the su(3) + su(2) of the E7 paper (the nodes α₁, α₃ and α₂) and split each grade-1 piece by highest weights: M₃,₂ is the quark doublet (3,2); a₅(ℂ) adds (3̄,1) and (1,1); the bi-Cayley triple adds a second (3̄,1), the lepton doublet (1,2) and a second (1,1) and is one full generation; the Albert triple adds eleven more states, a third (3̄,1), one (3,1), two more (1,2) and a third (1,1), which are not part of the 16 (the E7 paper’s Table 1 reads (3,1) + (1,2) and (3̄,1) + (1,2̄) as the SU(5) Higgs multiplets; whether the rest has a role the Jordan-pair paper’s Section 5.2 leaves open).</p>'
 '<p class="not">The chain from e7 down is in the E7 paper (its Table 2) and the chain of triples in the Jordan-pair paper (Table 3 and eq. (77)); the E8 end (240, 56) and the Peirce counts are ours; the split of each piece by the Standard Model subalgebra is our computation (S1) and is not stated in either; the word “builds” for this nesting is ours. The labels 3 and 3̄ depend on a convention for the sign of the weights.</p>'
 '<p class="ids">checks E1a–E2d, S1.</p>',
 fig('The pieces of each triple under su(3) × su(2)', FG.tower_svg(FD), 'Each column is a triple, with its number of states below and its (r, a, b). The coloured pieces are the irreducible representations; each triple contains the previous one. Hover a piece for its name.'))

J4 = finding('J4', 'The plane of the three generations is the Eisenstein lattice of the triangulation note', ['checked', 'ours'],
 '<p>In the E7 paper the roots of e7 orthogonal to g_SM form an A₂ (the generation sl3), and the 126 roots are sorted by their orthogonal shadows on its plane P: 30 roots shadow to 0, 90 to six vectors ±w<sub>k</sub> of squared length 2/3, and 6 are the roots of A₂ themselves (squared length 2): Lemma 2 gives the three kinds of shadow and Lemma 3 the counts. The three lines through ±w<sub>k</sub> index the three subalgebras so(12) + sl2 and the three 32-dimensional spaces V<sub>k</sub>.</p>'
 '<p>The shadows lie on the weight lattice of A₂, which is the Eisenstein lattice rescaled. Its number of vectors of Eisenstein norm N = a² − ab + b² is 1, 6, 0, 6, 6, 0, 0, 12 for N = 0…7: there is nothing at N = 2. The shadows have N = (3/2)|π|² between 0 and 3 (the shadow is never longer than a root), so only N = 0, 1, 3 can occur, and all three do, with 30, 90, 6 roots. That is the argument of the paper’s proof of Lemma 2 (squared lengths 2/3, 2, 8/3, … and |π(r)|² ≤ 2). What we add is only the identification: the lattice is the one of Thurston’s stars in Baez’s triangulation note, whose theta series 1, 6, 0, 6, … is the same list.</p>'
 '<p>We also checked the rest of this part of the E7 paper by enumeration: the 30 roots of Φ₀ have the inner-product profile of A₅ and are irreducible; the 60 roots orthogonal to β<sub>k</sub> have that of D₆; the 32 roots at +1 project to the weights of the half-spin representation (32 = 1 + 15 + 15 + 1 by Hamming distance 0, 2, 4, 6); and V<sub>k</sub> has the weight system of Λ<sup>even</sup>ℂ⁶ and, dropping the sixth bit, of the 32 five-bit labels: 133 = 35 + 2 + 3 × 32.</p>'
 '<p class="not">The tie to the triangulation note is ours and is only the identification of the lattice: the two papers do not cite each other, and the argument itself is the E7 paper’s. Checks are by enumeration for the stated embedding, not proofs for all embeddings.</p>'
 '<p class="ids">checks E3a–E3e, T1a, T1b.</p>',
 fig('Shadows of the 126 roots of e7 on the generation plane', FG.plane_svg(FD), 'The dots are the Eisenstein lattice; the dashed circle is the shell N = 2, where it has no point. Circle area grows with the number of roots that land there. Hover for the count.'))

J5 = finding('J5', 'Octonions and split octonions are the label rule with another sign', ['checked', 'standard'],
 '<p>Three Cayley–Dickson doublings of the reals give a product in which every product of two basis units is ±1 times the unit whose label is the XOR of the two labels, and every non-zero label squares to −1: the octonions are the bit rule on three bits with a different sign function. The product is alternative and normed (checked on random vectors). The associator sign is −1 for exactly the 168 = 7·6·4 ordered triples of labels that are independent over F₂, that is, not on a line of the Fano plane; the sign rule of Cl(0,3) on the same labels is associative; its squares differ from the octonion squares only at the label 111, but it also differs on 15 of the 42 products of distinct non-zero labels, necessarily, since one rule is associative and the other is not.</p>'
 '<p>The derivations of the octonions form g₂ (dimension 14); those that kill a chosen unit form su(3) (dimension 8) and commute with multiplication by that unit, so they act complex-linearly on the complement ℂ³: O = ℂ ⊕ ℂ³, the construction of the geometry paper. Zorn’s product on Λ(ℝ³) (the eight labels 000, {i}, complements of {i}, 111) has a norm of signature (4,4) and satisfies composition; every product of two labels is the join, the meet or 0 (16, 16 and 32 of the 64), and the units a<sub>i</sub> square to 0. The complement of a label (x ↦ x XOR 111), composed with the Clifford conjugation sign (−1)<sup>k(k+1)/2</sup>, is an automorphism; the bare complement is neither an automorphism nor an anti-automorphism. Left and right multiplication by π = 111 are diagonal, with popcount = 2 × (left eigenvalue) + (right eigenvalue).</p>'
 '<p class="not">All standard (Cayley–Dickson, Zorn, Fano); the point is that the geometry paper’s three algebras sit on the same label sets as the atlas’s Clifford and projective algebras. Join and meet are the products of projective geometric algebra (step 13).</p>'
 '<p class="ids">checks O1a–O1c, O2a–O2d.</p>',
 fig('The seven lines of the Fano plane = a, b, a XOR b', FG.fano_svg(FD), 'Each line is a triple of labels closing under XOR: a quaternion subalgebra, where the product associates. Any three labels not on one line anti-associate. Hover a point or a line.'))

J6 = finding('J6', 'The Standard Model group of the Albert algebra, in numbers, and a flag about the 27', ['checked', 'open'],
 '<p>The 27-dimensional Jordan algebra h3(O) on the XOR octonions satisfies the Jordan identity and has the Peirce split 27 = 1 + 16 + 10 for a primitive idempotent. Its derivations form a 52-dimensional algebra, f4. At the level of Lie algebras the stabilisers of the paper come out as: the Jordan frame so(8), 28 (acting irreducibly and inequivalently on the three 8-blocks, with equal Casimir: triality); B = h3(C), su(3) + su(3), 16; A = h2(O), spin(9), 36; X = h2(C), so(3) + so(6), 18; and X with B (equally A with B): 12. This twelve-dimensional algebra closes, has a one-dimensional centre, derived algebra of dimension 11, rank 4, a compact Killing form and two simple ideals of dimensions 3 and 8: su(2) + su(3) + u(1), the Lie algebra of the Standard Model group (Theorems 1 and 2).</p>'
 f'<p><b>A table for comparing the two embeddings.</b> The proof of the paper’s Lemma 4 gives the action explicitly: (X, M) ↦ (gXg*, hMg*) on h3(O) = h3(C) ⊕ M₃(ℂ), so the complexified 27 is (1,1) + (1,8) + (3,3̄) + (3̄,3) under SU(3)<sub>colour</sub> × SU(3)<sub>g</sub>, with SU(2) × U(1) inside SU(3)<sub>g</sub>. We computed the Casimirs of the two ideals on the 27 from the stabiliser itself: the dimensions of the classes (singlet, weak doublet, weak triplet, colour triplet, colour triplet with weak doublet) are {cont["0|0"]}, {cont["0|3/8"]}, {cont["0|1"]}, {cont["4/9|0"]}, {cont["4/9|3/8"]} (27 in all), exactly what that description predicts. The su(3) + su(2) of the E7 paper, acting on the 27 of E6, has {cont7["0|0"]}, {cont7["0|3/8"]}, 0, {cont7["4/9|0"]}, {cont7["4/9|3/8"]}: a different table. (The Jordan-pair paper’s introduction already says that the F4 line “has not managed to explain the chiral structure of the fermions” and turns to the bioctonions; this puts numbers on the difference.) The 27 of E6 restricts to the real h3(O) = 1 + 26 under F4, so the two subalgebras are not conjugate in E6. The group of the gauge-group paper is the Standard Model group, and the 27 = h3(O) on which it acts is self-conjugate, a real representation (checked, S2); a real representation is vector-like (standard). Lie-algebra level only. The chiral 16 sits in the bi-Cayley triple under a differently embedded su(3) + su(2).</p>'
 '<p class="not">Open: how the two embeddings relate (for instance through Spin(9) inside Spin(10), where the 16 of Spin(9) is real). The E7 paper chooses its embedding on purpose, as a “good” one, and notes that there are countably many subalgebras of so10 isomorphic to g_SM; our computation covers the root-based (regular) ones only. Lie algebra level only: connectedness, the Z₆ quotient and the identity component are not tested.</p>'
 '<p class="ids">checks O3a–O3h, S2.</p>',
 fig('Dimensions of the stabilisers inside f4', FG.stab_svg(FD)) + fig('The 27 under the two Standard Model subalgebras', FG.sm27_svg(FD), 'Each bar is the 27 states, split by the Casimir values of su(3) and su(2). The two bars differ, so the subalgebras are not conjugate.'))

J7 = finding('J7', 'Ten dimensions: h2(O), Cl(1,9) and the form of the triangulation note', ['checked', 'open'],
 '<p>The Jordan algebra A = h2(O) of the gauge-group paper has dimension 10 and satisfies x² − tr(x)x + det(x)·1 = 0 with det = ab − |z|² (checked on random elements). It is the spin factor ℝ ⊕ ℝ⁹: the traceless part is a Euclidean ℝ⁹ with v∘v = |v|²·1, and the determinant has signature (1,9): the positive cone of h2(O) is the forward light cone of ten-dimensional Minkowski space. The same ℝ⁹ generates the bit-rule algebra Cl(9,0), at clock 1, type R2: its centre is {1, e₁…₉} with e₁…₉² = +1 and its dimension is 512 = 2 × 16², so Cl(9,0) = M₁₆(ℝ) ⊕ M₁₆(ℝ). The 16 is the Peirce ½ space of A in the Albert algebra (27 = 10 + 16 + 1) and the real spinor module of Spin(9) = Stab(A).</p>'
 '<p>The triangulation note counts triangles with a quadratic form; from the shoelace formula (not taken from Engel and Smillie) we reproduce it as (4/√3) × area(P) − Σ|v<sub>j</sub>|², invariant under multiplication by i and by ω, integer-valued on Eisenstein 10-tuples, with eigenvalue signs (2, 18) over ℝ: complex signature (1,9). Baez asks whether this resemblance to ten-dimensional Minkowski space is a coincidence. What the clock says: the algebra of signature (1,9) has clock 0, type R, is M₃₂(ℝ), its pseudoscalar squares to +1, and it has real Majorana–Weyl spinors of 16 components; among the eleven signatures (p, 10 − p) exactly (1,9), (5,5) and (9,1) have that property.</p>'
 '<p class="not">Open, and honest: the 10 of h2(O) is a real dimension (ℝ⁹ plus time), the 10 of the triangulation form is a complex dimension (ℂ¹⁰ = ℝ²⁰, real signature (2,18)). We find no mechanism that connects them; the clock only says what (1,9) is as an algebra.</p>'
 '<p class="ids">checks O3i, T3, T4.</p>',
 fig('The eleven signatures (p, 10 − p)', FG.sig_svg(FD), 'Each cell: clock c = p − q mod 8, type of the real algebra, and whether the pseudoscalar squares to +1. The framed cells have real Weyl spinors.'))

J8 = finding('J8', 'Kepler: the energy sign is the trio −1, 0, +1, the hidden symmetry is two commuting bivector algebras, and so(4,2) is a triple', ['checked', 'ours'],
 '<p>At random phase-space points of both energy signs the Poisson brackets of the angular momentum L and the Runge–Lenz vector e satisfy e² = 1 + 2L²E, {L,L} = L, {L,e} = e and {e,e} = −2E·L (the paper’s eqs. (6), (9)); the structure constants depend on the energy only through −2E. In the bit rule, take the bivectors L = −e<sub>j</sub>e<sub>k</sub>/2 and M = −e<sub>k</sub>e<sub>4</sub>/2 of the algebra whose generators square to (+1, +1, +1, ε): [L,L] = L, [L,M] = M, [M,M] = εL, and the Killing form has (positive, negative, zero) counts (0,6,0) for ε = +1, (0,3,3) for ε = 0, (3,3,0) for ε = −1: so(4), e(3), so(3,1). With M = e/√(−2E), ε = −sign(E): ellipse, parabola, hyperbola are the trio of the fourth generator’s square.</p>'
 '<p>For ε = +1 the half-sum and half-difference A, B = (L ± M)/2 commute and each closes into so(3): so(4) = so(3) + so(3), the paper’s eqs. (13) and (14). On H = Cl(0,2) left and right multiplication by e₁, e₂, e₁₂ are skew 4 × 4 matrices, commuting pairs of su(2) that span all six dimensions of so(4); conjugation L − R fixes the unit label. The shells: V<sub>j</sub> ⊗ V<sub>j</sub> has 4A² + 1 = n² and splits under L = A + B as V<sub>0</sub> … V<sub>n−1</sub> (Clebsch–Gordan from the spin matrices for n up to 13); with spin, 2n² = n(n+1) + n(n−1).</p>'
 '<p>The conformal algebra so(4,2) is the 15 bivectors of the algebra with squares (+1,+1,+1,+1,−1,−1). A hyperbolic bivector (the dilatation of step 9) splits it with eigenvalues +1, 0, −1 of multiplicities 4, 7, 4; an elliptic one (the energy of the Einstein universe) has +i, 0, −i, again 4, 7, 4, and commutes with the six bivectors of the four positive generators: so(4) = su(2) + su(2), the rotation subgroup of the conformal group in the paper’s Section 5.1 (which writes SO(2,4); so(4,2) is the same algebra). The complexification of so(4,2) is the 3-graded Lie algebra so(6, ℂ) = 4 + 7 + 4 that the Jordan-pair paper associates with its triple of type BDI with n = 4 (Tables 1 and 2, which list the complex algebra and its compact form, not so(4,2) itself), and with A III for (p, q) = (2, 2).</p>'
 '<p class="not">Ours: the reading of the energy trio as the same trio as the extra generator of step 9 of the atlas (projective and conformal). That the complexified so(4,2) is a Jordan-triple Lie algebra is standard; that one author uses so(4,2) for hydrogen and so(6, ℂ) for matter in two papers is a remark, not a theorem. A possible slip found on the way: the third line of the Kepler paper’s eq. (12) reads {M<sub>j</sub>, M<sub>k</sub>} = ε<sub>jkℓ</sub> M<sub>ℓ</sub>, while the half-sums of eq. (13) need ε<sub>jkℓ</sub> L<sub>ℓ</sub> (our check K1 gives L).</p>'
 '<p class="ids">checks K1a–K1c, K2a, K2b, K4.</p>',
 fig('The three orbit types and the algebra of each', FG.orbits_svg(FD), 'The fourth generator squares to +1, 0, −1 for bound, parabolic and scattering orbits; the Killing counts are computed from bivectors of the bit rule.'))

J9 = finding('J9', 'The periodic table as bits: electrons are set bits, a ground state is a prefix of the Madelung order', ['checked', 'ours'],
 '<p>Subshells (n, l) hold 2(2l + 1) electrons and are filled in order of n + l, then n. Running that order gives the cumulative counts 2, 4, 10, 12, 18, 20, 30, 36, 38, 48, 54, 56, 70, 80, 86, 88, 102, 112, 118, the noble-gas closures 2, 10, 18, 36, 54, 86, 118 and the period lengths 2, 8, 8, 18, 18, 32, 32, which are 2m² for m = 1, 2, 2, 3, 3, 4, 4. In the second quantisation of the paper, a state of N electrons is a set of N orbitals: N set bits among the orbital labels; a ground state of the modified Hamiltonian fills the subshells in the Madelung order, so the first N bits are one ground state (within the last, partly filled subshell the choice of the orbitals is free, a degeneracy the rules do not remove).</p>'
 '<p>That is the same structure as in J1 and J2: a state is a subset of a labelled set, creation flips a bit with a Jordan–Wigner sign, the number operator is the popcount, and complement is particle–hole. The shells of J8 give the lengths 2n², and the Madelung order then regroups them into periods.</p>'
 '<p class="not">Ours: the label reading. The Madelung rules are an approximation to real atoms (the paper says so), and the Weyl equation on R × S³ and the unitary equivalence of the Hilbert spaces are analysis the atlas does not touch.</p>'
 '<p class="ids">checks K2b, K3, H3a, H3b.</p>',
 fig('Subshells in Madelung order, one row per period', FG.madelung_svg(FD), 'Box width is the number of electrons the subshell holds; the number at the end of a row is the electron count when the row closes. Hover a box.'))

J10 = finding('J10', 'Composition by shared variables, read on labels; and what the Frobenius check says', ['ours', 'open'],
 '<p>The cospan paper composes open systems by identifying variables. On labels there is a natural counterpart: two blades that share a bit are multiplied by contracting that bit with the square of its generator (ε = +1, −1, or 0, the trio), and the unshared bits are glued by XOR. The identity e₁e₂ · e₂e₃ = ε₂ e₁e₃ was checked in the bit rule for all 27 choices of the three squares.</p>'
 f'<p>The Frobenius structure of the cospan category has a finite counterpart in the label algebra. For all {FR["n"]} patterns of generator squares in {{+1, −1, 0}} with n = 2, 3, 4 generators, the scalar-part form (coefficient of the empty label, the unit, in xy) is non-degenerate exactly when no generator is null, which is {FR["nondeg_scalar"]} of {FR["n"]}; the top-label form (coefficient of the all-ones label, the Berezin integral; its pairing is the complement pairing, a Frobenius duality, and a metric Hodge star only without null generators, as A6 of bridge_check.py and F1 of cat_check.py, two companion scripts of the atlas, show) is non-degenerate for every pattern, {FR["nondeg_top"]} of {FR["n"]}, including the null ones. So the exterior algebra (all squares 0) is Frobenius through its top form and not through its scalar part. The label algebra is a non-commutative Frobenius algebra, while the Frobenius monoids of the cospan category are commutative: what matches is the existence of a non-degenerate form, not the structure.</p>'
 '<p class="not">This is a reading of the words “variable sharing” and “Frobenius monoid”, not a computation of any double category. The cospan paper was read at overview level, and the atlas has no categories, no Petri nets and no rates.</p>'
 '<p class="ids">check C1.</p>',
 fig('Two open systems composed along a wire, and the same on labels', FG.cospan_svg(Alg)))

FINDINGS = ''.join([J1, J2, J3, J4, J5, J6, J7, J8, J9, J10])

# ------------------------------------------------------------------ page
CSS = open(os.path.join(HERE, 'report_style.css'), encoding='utf-8').read()
JS = open(os.path.join(HERE, 'report_script.js'), encoding='utf-8').read()
CHECKS_TABLE = ''.join(f'<tr><td><b>{E(b[0])}</b></td><td>{E(b[1])}</td><td class="num">{b[2]}</td><td>{E(b[3])}</td></tr>' for b in BLOCKS)
MATRIX = matrix_html(); COVER = coverage_svg(); CARDS = cards_html(); RELSVG = wrap_sv(FG.relation_svg(EDGES_FOUND))
CHIPS = ' '.join(chip(c) for c in ['checked', 'standard', 'ours', 'open']) + ' (checked: computed by a script; standard: textbook or the paper’s own statement, used as is; ours: our reading; open: not settled).'

TEMPLATE = r'''<!doctype html>
<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 -->
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Baez–Atlas Translation Matrix</title>
<meta name="description" content="Seven papers of John Baez and co-authors laid against the Cascade Atlas: how they relate to each other, a graded translation matrix, computed checks, findings, honest gaps and open questions.">
<style>%%CSS%%</style>
</head>
<body>
<header class="hero"><div class="wrap">
 <span class="kick">First pass · %%TODAY%% · %%VERSION%%</span>
 <h1>Seven Baez papers and the atlas</h1>
 <p class="sub">How the seven papers are related to each other, and what the atlas’s one rule (bit labels, XOR and a sign) says about them: where it is the same object, the same structure, only our reading, or nothing.</p>
 <div class="notice"><b>Preliminary.</b> The papers were read from the attached texts: the Standard Model, Jordan-pair, E7, geometry, Kepler and triangulation papers through their statements and the arguments behind the numbers we recompute; the cospan paper at overview level. Proofs were not re-derived: every statement we call checked was recomputed from the labels or from the E8 roots. Nothing here is a result about nature. Tags are the atlas’s: %%CHIPS%% Grades E, S, A are explained under Fig. 2.</div>
 <div class="kpis">
  <div class="kpi"><b>%%NOK%%</b><span>checks pass, %%NBAD%% fail</span></div>
  <div class="kpi"><b>%%MUTOK%% of %%MUTALL%%</b><span>deliberate sabotages of the checks were caught (automated)</span></div>
  <div class="kpi"><b>%%NROWS%% × 22</b><span>rows from the papers × atlas columns, %%NCELLS%% filled cells</span></div>
  <div class="kpi"><b>%%NGAP%%</b><span>rows with no counterpart: the honest gaps</span></div>
 </div>
 <p class="lead"><b>In one paragraph.</b> Four of the seven papers are one cluster about exceptional algebra (the gauge group from the Albert algebra, Jordan pairs, E7 and the octonions from 3-dimensional geometry; the first three are about the Standard Model); three citations tie the four together, and the Kepler, triangulation and cospan papers stand outside it (Fig. 1). The atlas meets the cluster at one place, bit labels of three and five bits with the XOR rule, and from there %%BE%% of the %%NROWS%% things the papers discuss have an exact counterpart that we compute, %%BS%% a structural one, %%BA%% an analogy and %%BG%% none. The best-supported links: one generation is the 16 even five-bit labels and the Peirce rule is a Hamming distance (J1); the chain of four triples (6, 10, 16, 27) is one E8 ladder, and under the E7 paper’s su(3) + su(2) the nested triples contain one generation at the bi-Cayley step, our computation (J3); the weight lattice of A₂ that carries the root shadows of the E7 paper is the Eisenstein lattice of the triangulation note (J4); and the Kepler energy trio, the hidden so(4) and so(4,2) are the atlas’s trio −1, 0, +1 and its bivectors (J8). One small table for comparing the two Standard Model embeddings: the subalgebras of the Albert-algebra paper and of the E7 paper act differently on the same 27, which the Jordan-pair paper already says in words (J6). One question left open that Baez himself asks: the signature (1,9) of the triangulation form (J7), where we only add that its 10 is complex while the 10 of h2(O) is real, and that we know no mechanism.</p>
</div></header>

<nav class="toc"><div class="wrap">
 <a href="#obj">Objectives</a><a href="#how">How I explored</a><a href="#papers">The papers</a><a href="#fig1">Fig. 1 relations</a><a href="#fig2">Fig. 2 matrix</a><a href="#findings">Findings</a><a href="#limits">Limits</a><a href="#persp">Perspectives</a><a href="#horizon">Horizon</a><a href="#corr">Corrections</a><a href="#checks">Checks</a><a href="#src">Sources</a>
 <button id="themebtn" type="button" aria-label="Switch colour theme">theme: auto</button>
</div></nav>

<main class="wrap">

<section id="obj"><h2>Definite objectives <small>what the request reduced to</small></h2>
 <div class="grid3">
  <div class="card"><h3>1 · How the papers relate</h3><p>Which paper cites which, and which objects they share, so that the seven are read as a map and not as seven separate things (Fig. 1).</p></div>
  <div class="card"><h3>2 · Tested links to the atlas</h3><p>A matrix of the objects in the papers against the 22 atlas pages and steps, every “exact” link computed in a script, and a sabotage of each check that must be caught (Fig. 2).</p></div>
  <div class="card"><h3>3 · Perspectives for the author</h3><p>A short list of statements the label view may offer him: a dictionary, a flag, a few questions, each tagged ours or open, none presented as a fact about nature.</p></div>
 </div>
 <p>Ground rules kept: explore the views before ranking them; the authors’ own statements are quoted or numbered as in their papers, not paraphrased into claims; every pointer (equation, lemma, table, section) is to the number printed in the paper; no address of any person appears in this report.</p>
</section>

<section id="how"><h2>How I explored <small>nine views, before choosing</small></h2>
 <div class="lens">%%LENSES%%</div>
</section>

<section id="papers"><h2>The seven papers <small>what each says and what we computed</small></h2>
 <div class="papers">%%CARDS%%</div>
</section>

<section id="fig1"><h2>Fig. 1 · How the papers are related <small>three citations, the rest through shared objects</small></h2>
 <p class="lead">The letters on the edges are keyed to the list below. A solid arrow is a citation found by the arXiv number in the text; the other edges are links through a shared object, drawn solid when we computed it, dashed when it is our reading, dotted when it is an open question.</p>
 %%RELSVG%%
 %%RELLIST%%
</section>

<section id="fig2"><h2>Fig. 2 · The translation matrix <small>%%NROWS%% rows × 22 columns</small></h2>
 <p class="lead">Each row is an object in one of the papers (G gauge group, J Jordan pair, E E7, D 3D geometry, K Kepler, T triangulations, C cospans). Each column is an atlas page or step. Hover or focus a cell for what matches. A row without cells is a gap. Row ids are written G.1, J.3, K.4 … with a dot, to tell them from the findings J1–J10 and from the check ids K4, E1a, T3 and C1.</p>
 <div class="legend"><span><i class="sw g-E">E</i> exact: same object or identity, computed</span><span><i class="sw g-S">S</i> structural: same structure, other generality, or a standard fact</span><span><i class="sw g-A">A</i> analogy: our reading, not computed as the same</span><span><i class="sw gapsw">–</i> no cell: nothing in the atlas</span></div>
 %%MATRIX%%
 <h3 style="margin-top:18px">Fig. 3 · Coverage</h3>
 %%COVER%%
 <p>Reading it: the atlas is closest to the Peirce, Fock and Clifford content of the Jordan-pair, E7 and Kepler papers, because those reduce to finite label combinatorics. It is farther from the gauge-group and geometry papers where the content is Lie groups and global constructions (the stabilisers are computed at Lie algebra level only), and it has nothing for the moduli space of the triangulation paper (T.5), the Z3-grading and manifold applications of the geometry paper (D.4, D.5), the maximal subgroups and Yokota’s remark (G.7), the symmetric spaces (J.7), or almost all of the cospan paper (C.3–C.5).</p>
</section>

<section id="findings"><h2>Findings <small>each with its tags and check ids</small></h2>
%%FINDINGS%%
</section>

<section id="limits"><h2>Dead ends and honest limits</h2>
 <div class="grid2">
  <div class="card"><h3>What the atlas cannot reach</h3><ul class="tight">
   <li><b>Categories.</b> Double categories, structured and decorated cospans, Petri nets with rates: the atlas has no categories. Only a Frobenius-form check on the label algebra (J10).</li>
   <li><b>Global geometry.</b> Thurston’s moduli space, the bijection with lattice vectors, the 3-manifold applications of the geometry paper: not touched.</li>
   <li><b>Analysis.</b> The Weyl equation on R × S³, unitary equivalence of Hilbert spaces, the physics of real atoms behind the Madelung rules.</li>
   <li><b>Groups, not only algebras.</b> The gauge-group paper’s theorems are about groups (identity components, quotients by Z₃ or Z₆); we checked Lie algebras.</li>
  </ul></div>
  <div class="card"><h3>What I did not do or verify</h3><ul class="tight">
   <li>The cospan paper was read at overview level (abstract, contents, introduction and the sections on structured and decorated cospans in part).</li>
   <li>No proof in the six other papers was re-derived. What was recomputed are the statements and counts; the E7 lemmas are checked by enumeration for the stated embedding (Bourbaki labels, nodes α₁–α₄ for g_SM), not proved for every embedding.</li>
   <li>The split of the tower of triples under the E7 paper’s su(3) + su(2) (J3) and the comparison of the two Standard Model subalgebras (J6) are our computations and are in none of the papers; the labels 3 and 3̄ depend on a sign convention.</li>
   <li>Equations and lemmas are cited by the numbers printed in the papers; page numbers are not given, because the texts were extracted from the attached files and their pagination may differ.</li>
   <li>The Table 1 classification of simple triples and Table 2 of symmetric spaces were taken from the paper, not re-derived.</li>
   <li>Layout was checked by screenshot at 1100 and 375 px, light and dark, with no page overflow. The matrix has hover tooltips and a table view; the other figures have tooltips. on a phone the drawings and the matrix scroll sideways instead of shrinking their text.</li>
   <li>A second reading of this report against the seven texts (by a reader who had not seen the work) corrected: the name of the graph srg(27, 10, 1, 5) (it is the complement of the Schläfli graph); so(4,2) against the complex algebra of the Jordan-pair paper (a real-form slip); the claim that the E8 step is 3-graded (it is 5-graded); two statements of novelty that the papers already contain (the argument of Lemma 2, the chain of triples); the matrix rows, now worded as what the papers contain, with three regraded (K.5, T.4, C.2 from exact to structural, E.3 from analogy to exact); and two internal notes removed. Correction of 6 October 2026 (erratum E-008 of the round-2 errata): the matrix row G.1 still gave the 27-vertex graph with inner product 0 the name of its complement; it now reads: srg(27, 10, 1, 5) is the intersection graph of the 27 lines, and its complement srg(27, 16, 10, 8) is the Schläfli graph (check E2d, whose sabotage test 20 of mutate_baez.py is unchanged). No grade and no atlas statement changes.</li>
   <li>Dead ends met on the way: the bare complement is not an automorphism of the Zorn algebra (it needs the conjugation sign, J5); the stabiliser of X is 18-dimensional, not 36 as first assumed (J6); an unsymmetrised cubic Casimir cannot tell 3 from 3̄ (replaced by highest weights, J2).</li>
  </ul></div>
 </div>
</section>

<section id="persp"><h2>Perspectives for the author <small>all ours or open; offered, not claimed</small></h2>
 <div class="grid2">
  <div class="card"><h3>P1 · A dictionary for the six Peirce pieces %%C_CHK%% %%C_OURS%%</h3><p>On five-bit labels the Peirce eigenvalue is 1 − d/4 and the six pieces are the classes (weak bits, colour bits), with Y = a/2 − b/3 (J1). This may be a short remark for Section 5.1 of the Jordan-pair paper: on the labels the six non-empty classes are exactly the six pieces, and hypercharge is a count (reading this as the reason they occur is ours).</p></div>
  <div class="card"><h3>P2 · The ladder and one generation %%C_CHK%% %%C_OURS%%</h3><p>The chain is in both papers (the E7 paper’s Table 2 and introduction; the Jordan-pair paper’s Table 3 and eq. (77)). What a table that the two papers could share would add is the su(3) + su(2) content of each step: (3,2) → + (3̄,1), (1,1) → one generation → + eleven states (J3), our computation.</p></div>
  <div class="card"><h3>P3 · The Eisenstein lattice and Lemma 2 %%C_CHK%% %%C_OURS%%</h3><p>The proof of Lemma 2 uses the weight lattice of A₂ (squared lengths 2/3, 2, 8/3, …) and the bound |π(r)|² ≤ 2. That lattice is, rescaled, the Eisenstein lattice of the triangulation note, with theta series 1, 6, 0, 6, … (J4). Only the identification is ours; it ties two of the notes to one lattice.</p></div>
  <div class="card"><h3>P4 · A model of the three 32s %%C_OURS%% %%C_OPEN%%</h3><p>Each V<sub>k</sub> is the label space of five bits with Cl(5,5) = M₃₂(ℝ) acting by real matrices and the complement exchanging even and odd labels (J2, J4; reading it as charge conjugation is ours). Is there a way to see the three copies V₁, V₂, V₃ as one label space with sl3 acting on a “generation index”? Open; not computed.</p></div>
  <div class="card"><h3>P5 · Hydrogen and matter as the same construction %%C_OURS%% %%C_OPEN%%</h3><p>The complexification of so(4,2), so(6, ℂ) = 4 + 7 + 4, is the Lie algebra of the triple M₂,₂(ℂ) ≅ BDI₄ (Tables 1 and 2 of the Jordan-pair paper), whose K₀ contains the Kepler SU(2) × SU(2); the Standard Model group is K₀ of M₃,₂(ℂ), one row more (J8). Could hydrogen be read as a Jordan-pair quantum system of the kind in the Jordan-pair paper? A question; the identification of M₂,₂ inside M₃,₂ is trivial, the physics is not.</p></div>
  <div class="card"><h3>P6 · Which Standard Model? %%C_CHK%% %%C_OPEN%%</h3><p>The subalgebra of the Albert-algebra paper and the one of the E7 paper act on the 27 in different ways (J6); the Jordan-pair paper says as much in words, and the E7 paper chooses its embedding on purpose. The table of J6 may help when the two are compared in print, and the way they are related (through Spin(9) inside Spin(10), perhaps) is open.</p></div>
  <div class="card"><h3>P7 · The signature (1,9) %%C_CHK%% %%C_OPEN%%</h3><p>The clock says what (1,9) is as an algebra (real Majorana–Weyl, J7), and h2(O) is a place where ℝ¹·⁹ is canonical. The 10 of h2(O) is real, the 10 of the triangulation form is complex: no mechanism connects them. The numerology stays a question.</p></div>
  <div class="card"><h3>P8 · A label counterpart of open systems %%C_OURS%% %%C_OPEN%%</h3><p>Shared wires as contracted bits, with the trio of squares as the three behaviours of a wire (J10). If it is useful, the Frobenius forms of label algebras might serve as a finite test case for the category-theoretic statements. Low priority and well outside what the atlas can check.</p></div>
 </div>
</section>

<section id="horizon"><h2>Horizon <small>speculation, no claims</small></h2>
 <div class="spec"><p>Three thoughts, kept as questions. (1) The label set recurs: five bits for a generation, six bits (even) for V<sub>k</sub>, orbital bits for the periodic table, three bits for the octonions. Whether one explicit dictionary can take the exceptional ladder to the Fock space of the Kepler paper is open; what is computed is that each piece has a bit model. (2) The trio of squares appears again: Kepler’s three energy signs, the extra generator of step 9 of the atlas; whether that is more than a resemblance is open. (3) The two Standard Model subalgebras of J6 differ by what they do to the 27; a table of the root-based (regular) ways su(3) + su(2) + u(1) sits in F4, E6 and Spin(10) would show how the three papers’ groups relate, and the atlas could build that table from the roots (the non-regular embeddings, countably many in so10 according to the E7 paper, are beyond it).</p></div>
</section>

<section id="corr"><h2>Corrections of 6 October 2026 <small>wording found too strong by the design review of the atlas chapter; fixed at the source, retested</small></h2>
 <p class="lead">Found when the report was turned into a chapter of the atlas (the physicist’s and the mathematician’s reviews of the wording); every item was checked against the scripts before the change. No check, no sabotage and no matrix grade changes; the errata ids continue the round-2 list (E-008 above was the first correction of this report).</p>
 <div class="card"><div style="overflow-x:auto"><table class="tabsm"><thead><tr><th>#</th><th>The report said</th><th>Right</th><th>Fixed in</th><th>Pinned by</th></tr></thead><tbody>
  <tr><td>E-049</td><td>“the Hodge complement” for the complement of a label and for the top-label form (J10, J5, the geometry paper’s card, the dead ends, the messages of H1b, O2d and C1); and “label 0” for the empty label in J10.</td><td>The complement pairing, a Frobenius duality; a metric Hodge star only without null generators (and Λ(R³) of the Zorn algebra has no metric at all). The empty label is the unit; “label 0” means a generator with square 0. Row C.2 now says that the label algebra is a non-commutative Frobenius algebra while the cospan monoids are commutative.</td><td>J5, J10, the geometry card, dead ends, row C.2, the messages of H1b, O2d, K2a and C1</td><td>C1; A6 of bridge_check.py and F1 of cat_check.py (companion scripts of the atlas)</td></tr>
  <tr><td>E-050</td><td>Row K.6 graded E without saying that no product is used.</td><td>The note now says that E there means the counts agree exactly (K3), by bit counting only. The grade is unchanged.</td><td>row K.6</td><td>K3</td></tr>
  <tr><td>E-051</td><td>“The complement mask 11111 maps even to odd labels and flips Q and Y: particle to antiparticle” (J1, the figure of J1, row E.2, the message of H1b).</td><td>The mask exchanges even and odd labels and Y and Q flip (checked); calling it charge conjugation is ours.</td><td>J1, its figure, row E.2, P4, the message of H1b</td><td>H1b, H2c</td></tr>
  <tr><td>E-052</td><td>“The labels explain why those and only those [pieces] occur” (J1, P1); the anomaly sums “computed by us” (row E.6).</td><td>On the labels the Peirce value is 1 − d/4, so the six non-empty classes are the six pieces (checked); reading it as the reason is ours. The anomaly sums are the standard cancellation, recomputed over the labels.</td><td>J1, P1, row E.6</td><td>H1a–H2d</td></tr>
  <tr><td>E-053</td><td>J3: “under the Standard Model they build a generation step by step” (title, summary, view 3, limits, P2).</td><td>Under the E7 paper’s su(3) + su(2) the nested triples 6 ⊂ 10 ⊂ 16 ⊂ 27 contain (3,2); then + (3̄,1) + (1,1); then one generation; then 11 more states. Checked; the word “builds” is ours.</td><td>J3, summary, view 3, limits, P2</td><td>S1, E1a–E2d</td></tr>
  <tr><td>E-054</td><td>J6 and row G.5: “no chiral generation inside h3(O)”, “the chiral generation … does not sit in h3(O)”.</td><td>The 27 = h3(O) is self-conjugate (checked); real representations are vector-like (standard); Lie-algebra level only.</td><td>J6, row G.5</td><td>S2, O3a–O3h</td></tr>
 </tbody></table></div></div>
 <p>Also made explicit, not an error: every place that sets the (1,9) of h2(O) beside the (1,9) of the triangulation form now says that the first 10 is real and the second complex, and that we know no mechanism (J7, the triangulation card, view 9, Fig. 1 edge h, the signature figure, row T.4).</p>
</section>

<section id="checks"><h2>Checks <small>%%NOK%% pass, %%NBAD%% fail</small></h2>
 <div class="grid2">
  <div class="card"><div style="overflow-x:auto"><table><thead><tr><th>Block</th><th>What it tests</th><th class="num">Checks</th><th>Script</th></tr></thead><tbody>%%CHECKS%%<tr><td></td><td><b>Total</b></td><td class="num"><b>%%NOK%%</b></td><td></td></tr></tbody></table></div></div>
  <div class="card"><h3>Sabotage test</h3><p>Each check was run against a deliberately wrong version (a flipped sign, a swapped formula, a wrong count, a wrong simple root, a swapped ideal). The run changes one place in a temporary copy of the script and requires the named check to fail: <b>%%MUTOK%% of %%MUTALL%%</b> were caught, automated in <code>mutate_baez.py</code>.</p>
   <h3 style="margin-top:12px">Rerun</h3><pre>cd reports/baez
python3 baez_check.py --write &gt; logs/baez_check.log   # the %%NOK%% checks (--write: the figure data)
python3 mutate_baez.py &gt; logs/mutate_baez.log   # automated sabotage (about 20 minutes)
python3 build_report_baez.py  # this page, into ../html/</pre><p style="font-size:13px;color:var(--muted)">Needs the atlas package this folder ships in (two folders up; or set <code>ATLAS_PKG</code>), Python 3, numpy, scipy and networkx. Check R1 (the cross-citations) also needs the text files of the seven papers in <code>txt/</code>; they are not shipped, and without them R1 is skipped and not counted. Every number on this page is read from the logs, the figure data written by the check script, or the matrix data.</p></div>
 </div>
</section>

<section id="src"><h2>Sources</h2>
 <ul class="tight">
  <li>J. C. Baez, P. Schwahn, <i>The Standard Model Gauge Group from the Exceptional Jordan Algebra</i>, <a href="https://arxiv.org/abs/2606.15235">arXiv:2606.15235</a>, June 2026. (Attached.)</li>
  <li>J. C. Baez, E. Bokor, L. Boyle, <i>Jordan Pair Quantum Theory and the Standard Model</i>, <a href="https://arxiv.org/abs/2607.10833">arXiv:2607.10833</a>, July 2026. (Attached.)</li>
  <li>J. C. Baez, <i>Three Generations in E7</i>, <a href="https://arxiv.org/abs/2608.06271">arXiv:2608.06271</a> v3, September 2026. (Attached.)</li>
  <li>J. Baez, S. Pumplün, <i>Three-Dimensional Geometry in Exceptional Mathematics</i>, <a href="https://arxiv.org/abs/2609.07538">arXiv:2609.07538</a>, September 2026. (Attached.)</li>
  <li>J. C. Baez, <i>Second Quantization for the Kepler Problem</i>, <a href="https://arxiv.org/abs/2507.11428">arXiv:2507.11428</a> v5, May 2026. (Attached.)</li>
  <li>J. C. Baez, <i>Triangulations of the Sphere</i>, <a href="https://arxiv.org/abs/2606.10072">arXiv:2606.10072</a> v2, June 2026. (Attached.)</li>
  <li>J. C. Baez, <i>Double Categories of Open Systems: the Cospan Approach</i>, <a href="https://arxiv.org/abs/2509.22584">arXiv:2509.22584</a> v3, July 2026. (Attached; read at overview level.)</li>
  <li>W. P. Thurston, <i>Shapes of polyhedra and triangulations of the sphere</i>, <a href="https://arxiv.org/abs/math/9801088">arXiv:math/9801088</a>; P. Engel, P. Smillie, <i>The number of convex tilings of the sphere by triangles, squares, or hexagons</i>, <a href="https://arxiv.org/abs/1702.02614">arXiv:1702.02614</a>. (Cited by the triangulation paper; not read here. The hermitian form is reproduced from the shoelace formula, not taken from them.)</li>
  <li>Standard facts used without a fetch in this session (recalled): Cayley–Dickson doubling and Zorn’s vector matrices, the Fano plane, Tits–Kantor–Koecher construction, Peirce decomposition, Borel–de Siebenthal theory, Bourbaki’s simple roots of E8, the Madelung rules.</li>
  <li>The atlas package (steps 1–17, ledger, <code>bitcliff.py</code>) as delivered in v10 and v10.1, and the atlas’s pages 1–5 and steps 1–17, which are the columns of the matrix.</li>
 </ul>
</section>
</main>
<footer><div class="wrap">Cascade Atlas · preliminary report, %%TODAY%%, %%VERSION%% · generated by <code>build_report_baez.py</code> from the logs, the figure data and the matrix data. Not a theory of nature: a set of checks and readings.</div></footer>
<div id="tip" role="tooltip"></div>
<script>%%JS%%</script>
</body></html>
'''
out = TEMPLATE
rep = {'%%CSS%%': CSS, '%%JS%%': JS, '%%TODAY%%': TODAY, '%%VERSION%%': VERSION, '%%CHIPS%%': CHIPS, '%%NOK%%': str(OK), '%%NBAD%%': str(BAD), '%%MUTOK%%': str(MUT_OK), '%%MUTALL%%': str(MUT_ALL),
       '%%NROWS%%': str(nrows), '%%NCELLS%%': str(ncells), '%%NGAP%%': str(len(GAP_ROWS)), '%%BE%%': str(bestE), '%%BS%%': str(bestS), '%%BA%%': str(bestA), '%%BG%%': str(bestG),
       '%%LENSES%%': LENS_HTML, '%%CARDS%%': CARDS, '%%RELSVG%%': RELSVG, '%%RELLIST%%': REL_HTML, '%%MATRIX%%': MATRIX, '%%COVER%%': COVER, '%%FINDINGS%%': FINDINGS, '%%CHECKS%%': CHECKS_TABLE,
       '%%C_OURS%%': chip('ours'), '%%C_CHK%%': chip('checked'), '%%C_OPEN%%': chip('open'), '%%C_STD%%': chip('standard')}
for k, v in rep.items(): out = out.replace(k, v)
assert '%%' not in out, re.findall(r'%%\w+%%', out)
assert not re.search(r'[\w.+-]+@[\w-]+\.[\w.]+', re.sub(r'<!--.*?-->', '', out, flags=re.S)), 'an e-mail address is in the page'
path = os.path.join(HERE, '..', 'html', 'baez_atlas_report.html'); os.makedirs(os.path.dirname(path), exist_ok=True)   # the shipped page lives in reports/html/
open(path, 'w', encoding='utf-8').write(out)
print('wrote', path, len(out), 'bytes;', f'checks {OK}, rows {nrows}, cells {ncells}, best E/S/A/gap {bestE}/{bestS}/{bestA}/{bestG}')
