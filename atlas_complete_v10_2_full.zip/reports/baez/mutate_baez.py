#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Automated sabotage test for baez_check.py: each mutant changes one place of a temporary copy; the run must FAIL the named check (a crash does not count as caught).
Python standard library only.   Run: python3 mutate_baez.py   (about 15 minutes on two cores; give mutant ids as arguments to run only some)"""
import os, sys, subprocess, tempfile, re
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, 'baez_check.py')).read()
M = [
 ('M01 R1: wrong arXiv number for the Jordan-pair paper (edge e7 -> jordan disappears)', "'jordan': '2607.10833'", "'jordan': '2607.10834'", 'R1'),
 ('M02 H1a: only 31 labels', "LAB = range(32)", "LAB = range(31)", 'H1a'),
 ('M03 H1b: complement with the wrong mask (01111 instead of 11111)', "pc(x ^ 31) == 5 - pc(x) and", "pc(x ^ 15) == 5 - pc(x) and", 'H1b'),
 ('M04 H2a: Peirce eigenvalue 1 - d/3 instead of 1 - d/4', "lam2 = lambda x: 1 - Fr(pc(x ^ S2), 4)", "lam2 = lambda x: 1 - Fr(pc(x ^ S2), 3)", 'H2a'),
 ('M05 H2b: hypercharge with colour weight 1/2 instead of 1/3', "Yf = lambda x: Fr(a_of(x), 2) - Fr(b_of(x), 3)", "Yf = lambda x: Fr(a_of(x), 2) - Fr(b_of(x), 2)", 'H2b'),
 ('M06 H2c: electric charge read off the second weak bit', "Q = lambda x: (x & 1) - Fr(b_of(x), 3)", "Q = lambda x: ((x >> 1) & 1) - Fr(b_of(x), 3)", 'H2c'),
 ('M07 H2d: colour anomaly summed over triplets only', "if b_of(x) in (1, 2))", "if b_of(x) in (1,))", 'H2d'),
 ('M08 H3a: Jordan-Wigner sign dropped', "(-1) ** pc(x & ((1 << i) - 1))", "1", 'H3a'),
 ('M09 H3b: all ten generators square to +1', "GE = [A + A.T for A in A5] + [A - A.T for A in A5]", "GE = [A + A.T for A in A5] + [A + A.T for A in A5]", 'H3b'),
 ('M10 H3c: number operator shifted by 2 instead of 5/2', "coords(Nop - 2.5 * np.eye(32))", "coords(Nop - 2.0 * np.eye(32))", 'H3c'),
 ('M11 H3d: triple product with a minus sign', "Em = A @ B.conj().T @ C + C @ B.conj().T @ A", "Em = A @ B.conj().T @ C - C @ B.conj().T @ A", 'H3d'),
 ('M12 H3e: tripotent on the pair (0,2) while the rule is stated for (0,1)', "A0[0, 1], A0[1, 0] = 1, -1", "A0[0, 2], A0[2, 0] = 1, -1", 'H3e'),
 ('M13 H3f: wrong normalisation of the su(3) Casimir', "C2_3 = 0.5 * sum(", "C2_3 = 0.25 * sum(", 'H3f'),
 ('M14 E1a: a wrong simple root (the Cartan matrix is no longer E8)', "[0, 0, -2, 2, 0, 0, 0, 0], [0, 0, 0, -2, 2, 0, 0, 0],", "[0, 0, -2, 2, 0, 0, 0, 0], [0, 0, 0, -2, 0, 2, 0, 0],", 'E1a'),
 ('M15 E1b: Levi subsystem deletes one node too many', "all(coef[k, m] == 0 for m in range(n, 8))", "all(coef[k, m] == 0 for m in range(n - 1, 8))", 'E1b'),
 ('M16 E1c: grading step without the factor 2', "len(levi(n)) == len(levi(n - 1)) + 2 * len(g1[n])", "len(levi(n)) == len(levi(n - 1)) + len(g1[n])", 'E1c'),
 ('M17 E2a: Peirce count over a truncated grade-1 set', "Counter(ip(R8[ga], R8[be]) for ga in G).items()", "Counter(ip(R8[ga], R8[be]) for ga in G[:-1]).items()", 'E2a'),
 ('M18 E2b: wrong characteristic multiplicity b of the bi-Cayley triple', "6: (2, 6, 4)", "6: (2, 6, 3)", 'E2b'),
 ('M19 E2c: wrong inner product in the model of the 6', "lambda x, y: (x[0] == y[0]) + (x[1] == y[1]))", "lambda x, y: (x[0] == y[0]) + 2 * (x[1] == y[1]))", 'E2c'),
 ('M20 E2d: orthogonality replaced by inner product 1', "if ip(R8[G27[i]], R8[G27[j]]) == 0: adj0.add_edge(i, j)", "if ip(R8[G27[i]], R8[G27[j]]) == 1: adj0.add_edge(i, j)", 'E2d'),
 ('M21 E3a: generation plane taken as span(alpha_5, alpha_6)', "Pb = np.array([S8[5], S8[6]], dtype=float)", "Pb = np.array([S8[4], S8[5]], dtype=float)", 'E3a'),
 ('M22 E3b: profile of Phi_0 compared with D6 instead of A5', "profile(Phi0) == model_prof(A5m)", "profile(Phi0) == model_prof(D6m)", 'E3b'),
 ('M23 E3c: centraliser taken with <= 0 instead of = 0', "D = [r for r in E7 if ip(R8[r], R8[bk[0]]) == 0]", "D = [r for r in E7 if ip(R8[r], R8[bk[0]]) <= 0]", 'E3c'),
 ('M24 E3d: roots at inner product >= 1 (adds beta_k itself)', "plus = [r for r in E7 if ip(R8[r], R8[bk]) == 1]", "plus = [r for r in E7 if ip(R8[r], R8[bk]) >= 1]", 'E3d'),
 ('M25 E3e: wrong centring of the weights of Lambda^even C^6', "pc(S & T) - pc(S) * pc(T) / 6, 6)", "pc(S & T) - pc(S) * pc(T) / 5, 6)", 'E3e'),
 ('M26 O1a: Cayley-Dickson doubling with a plus sign (imaginary units square to +1)', "return [u - v for u, v in zip(p1, p2)] + [u + v for u, v in zip(p3, p4)]", "return [u + v for u, v in zip(p1, p2)] + [u + v for u, v in zip(p3, p4)]", 'O1a'),
 ('M27 O1b: associator sign without the second bracketing', "    return s1 * s2\n", "    return s1\n", 'O1b'),
 ('M28 O1c: derivations that kill e2 instead of e1', "[D[:, 1] for D in Dlist][t]", "[D[:, 2] for D in Dlist][t]", 'O1c'),
 ('M29 O2a: Zorn product with the wrong sign of the cross product', "*(al * b + bep * a - np.cross(ap, bp))", "*(al * b + bep * a + np.cross(ap, bp))", 'O2a'),
 ('M30 O2b: labels of the a-prime units not the complements', "ZL = [0, 1, 2, 4, 6, 5, 3, 7]", "ZL = [0, 1, 2, 4, 3, 5, 6, 7]", 'O2b'),
 ('M31 O2c: idempotent alpha instead of pi', "pi_ = unit(8, 7)", "pi_ = unit(8, 1)", 'O2c'),
 ('M32 O2d: complement without the Clifford-conjugation sign', "def tau_sign(x): return -1 if (pc(x) * (pc(x) + 1) // 2) % 2 else 1", "def tau_sign(x): return 1", 'O2d'),
 ('M33 O3a: off-diagonal entries not conjugated (matrix no longer hermitian)', "M[0, 1], M[1, 0] = x12, cd_conj(list(x12))", "M[0, 1], M[1, 0] = x12, np.array(x12)", 'O3a'),
 ('M34 O3b: Peirce operator of an off-diagonal unit instead of e1', "Le1 = JT[0].T", "Le1 = JT[3].T", 'O3b'),
 ('M35 O3c: derivation equation with a wrong sign', "row[:, j] -= JT[i, :, l]", "row[:, j] += JT[i, :, l]", 'O3c'),
 ('M36 O3d: the set B no longer closed (wrong complex entry)', "Bset = {0, 1, 2, 3, 4, 11, 12, 19, 20}", "Bset = {0, 1, 2, 3, 4, 11, 12, 19, 21}", 'O3d'),
 ('M37 O3e: X not a subalgebra (wrong coordinates)', "Xset = {0, 1, 3, 4}", "Xset = {0, 1, 3, 5}", 'O3e'),
 ('M38 O3f: the Standard Model slot filled with the stabiliser of A', "('SM', sBX)", "('SM', stab([Aset]))", 'O3f'),
 ('M39 O3g: adjoint action of the derived algebra with an anticommutator', "Yc = sum(d[t] * sBX[t] for t in range(12)); Zc = Xc @ Yc - Yc @ Xc", "Yc = sum(d[t] * sBX[t] for t in range(12)); Zc = Xc @ Yc + Yc @ Xc", 'O3g'),
 ('M40 O3h: third block shifted by one coordinate', "'31': list(range(19, 27))", "'31': list(range(18, 26))", 'O3h'),
 ('M41 K1a: Runge-Lenz vector with the wrong sign of the potential term', "(np.cross(p, np.cross(q, p)) - q / np.linalg.norm(q))[i]", "(np.cross(p, np.cross(q, p)) + q / np.linalg.norm(q))[i]", 'K1a'),
 ('M42 K1b: one rotation bivector with the wrong sign', "one(0b0101, -1), one(0b0011)]", "one(0b0101, 1), one(0b0011)]", 'K1b'),
 ('M43 K1c: B taken as the half-sum instead of the half-difference', "Bb = [A4_.scal(A4_.add(Lk[i], Mk[i], -1), Fr(1, 2)) for i in range(3)]", "Bb = [A4_.scal(A4_.add(Lk[i], Mk[i], 1), Fr(1, 2)) for i in range(3)]", 'K1c'),
 ('M44 K2a: right multiplication replaced by left', "def Rmat(a): return np.array([[AH.blade_mul(b, a)[0] * (AH.blade_mul(b, a)[1] == c) for b in range(4)] for c in range(4)], dtype=float)",
  "def Rmat(a): return np.array([[AH.blade_mul(a, b)[0] * (AH.blade_mul(a, b)[1] == c) for b in range(4)] for c in range(4)], dtype=float)", 'K2a'),
 ('M45 K2b: L = A - B instead of A + B', "Lop = [a + b for a, b in zip(Aop, Bop)]", "Lop = [a - b for a, b in zip(Aop, Bop)]", 'K2b'),
 ('M46 K3: subshells ordered by n instead of n + l (Bohr order)', "sub = sorted(((n + l, n, l) for", "sub = sorted(((n, n, l) for", 'K3'),
 ('M47 K4: the hyperbolic bivector replaced by a plane of two positive generators', "Dh = {0b010001: Fr(1, 2)}", "Dh = {0b000011: Fr(1, 2)}", 'K4'),
 ('M48 T1a: wrong quadratic form for the Eisenstein norm', "if a * a - a * b + b * b == nn)", "if a * a - 2 * a * b + b * b == nn)", 'T1a'),
 ('M49 T1b: wrong normalisation of the Eisenstein norm', "Ns = Counter(round(1.5 * nz(p)) for p in proj)", "Ns = Counter(round(2 * nz(p)) for p in proj)", 'T1b'),
 ('M50 T2: Gauss-Bonnet with valence 5 as the flat value', "V_ * (6 - k_) == 12", "V_ * (5 - k_) == 12", 'T2'),
 ('M51 T3: the removed yellow triangles added instead of subtracted', "return 4 / sq3 * area - sum(abs(t) ** 2 for t in v)", "return 4 / sq3 * area + sum(abs(t) ** 2 for t in v)", 'T3'),
 ('M52 T4: clock shifted by one', "return TYPES[c], A.sq(top)", "return TYPES[(c + 1) % 8], A.sq(top)", 'T4'),
 ('M53 C1: scalar form read at label 1 instead of the empty label (the unit)', "if c == 0: Gs[a, b] = s_", "if c == 1: Gs[a, b] = s_", 'C1'),
 ('M54 O3i: determinant of h2(O) with the wrong sign of the octonion part (signature (9,1))', "x = np.zeros(27); x[Ai] = vec; return x[0] * x[1] - np.sum(x[3:11] ** 2)", "x = np.zeros(27); x[Ai] = vec; return x[0] * x[1] + np.sum(x[3:11] ** 2)", 'O3i'),
 ('M55 S1: su(3) taken on alpha_1 and alpha_4 instead of alpha_1 and alpha_3', "def labE(k): return (ip(R8[k], S8[0]), ip(R8[k], S8[2]), ip(R8[k], S8[1]))", "def labE(k): return (ip(R8[k], S8[0]), ip(R8[k], S8[3]), ip(R8[k], S8[1]))", 'S1'),
 ('M56 S2: the two ideals exchanged (su(2) Casimir read on the su(3) ideal)', "m2, m3 = mats_of(ideals[3]), mats_of(ideals[8])", "m2, m3 = mats_of(ideals[8]), mats_of(ideals[3])", 'S2'),
]
def run(item):
    name, old, new, cid = item
    if SRC.count(old) != 1:
        return f'ERROR {name}: pattern found {SRC.count(old)} times', False
    code = SRC.replace(old, new)
    with tempfile.TemporaryDirectory() as td:
        path = os.path.join(td, 'baez_check.py'); open(path, 'w').write(code)
        # the check script finds its text files and the atlas package through HERE / ATLAS_PKG
        env = dict(os.environ); env['ATLAS_PKG'] = os.environ.get('ATLAS_PKG', os.path.abspath(os.path.join(HERE, '..', '..')))   # the package this folder ships in
        env['OMP_NUM_THREADS'] = '1'; env['OPENBLAS_NUM_THREADS'] = '1'
        os.symlink(os.path.join(HERE, 'txt'), os.path.join(td, 'txt'))
        r = subprocess.run([sys.executable, path], capture_output=True, text=True, env=env, timeout=900)
    failed = re.findall(r'^FAIL (\w+)', r.stdout, re.M)
    crash = r.returncode != 0 and 'Traceback' in r.stderr
    hit = cid in failed
    return f"{'caught' if hit else 'MISSED'}  {name}  -> failing: {','.join(failed) or '-'}{'  (crash)' if crash else ''}", hit
if __name__ == '__main__':
    only = sys.argv[1:]                                           # optional: run only the mutants whose name starts with one of the given ids (e.g. M04 M26)
    if only: M = [m for m in M if m[0].split()[0] in only]
    with ThreadPoolExecutor(2) as ex: res = list(ex.map(run, M))
    for l, _ in res: print(l)
    caught = sum(h for _, h in res)
    print(f'mutants caught: {caught} of {len(M)}')
    sys.exit(0 if caught == len(M) else 1)
