# Errata changelog, 6 October 2026, second round: wording of the three reports (errata E-039 to E-068)

Scope: when the three reports became chapters of the web app (Lenses page, steps 18 to 20), a design review of their wording for a physicist and a mathematician listed sentences that say more than the scripts show ("Overreach", "Too strong"). Every item was checked against the check scripts, the round-2 theorems (T2, T3, T5, T8, T10, T15, T16, T18, T19) and, for statements about the papers, the papers' texts, before anything was changed. Each fix was made at the source (the content, figure and matrix modules and the builders), each report was rebuilt with its own builder into `html/`, and each report's own test suite now pins the correction: the retired wording must be absent outside the report's "Corrections" section and the right wording present. The first round of the same day (E-002 to E-011) is in `errata_changelog_6oct.md`.

What did not change: no check id was renamed, renumbered, added or removed; no check result changed (52, 56 with the papers' texts, 35 + 77 + 51 = 163); the messages of eleven checks, two comments and one docstring were reworded (listed below), so the logs were regenerated and differ from the previous ones only in those lines; the sabotage scripts find every pattern exactly once and catch every mutant (`logs/mutation_cat.log`, `logs/mutate_baez.log`, `logs/mutation_fibre.log`, rerun after the edits). One matrix grade changed (E-042). No statement of the web app changes because of these corrections.

## 1. Category report (`category/`, v1.1 -> v1.2)

| # | The report said | Now | Fixed in | Pinned by |
|---|---|---|---|---|
| E-039 | "lifts to a conserved integer degree" (N1, answer card); "conserved charge" (row C8, ladder row n = 5, G1 message) | an additive Z-degree among label-homogeneous gradings; "conserved" needs a Hamiltonian | `build_report_cat.py`, `content_cat.py`, `matrix_cat.py`, `cat_check.py` (G1 message) | G1, G2; T2 (6) |
| E-040 | N10 title: "the Born rule is the Frobenius form" | in Cl(3,0) the trace of the Born rule is a symmetric Frobenius form; the top-blade form is never a state (lambda(1) = 0) | `build_report_cat.py` | C2, C3; T15 |
| E-041 | "label 0 is the boundary between the definite and the Lorentzian rungs"; E10, E11 "Lorentzian" without a guard | det = 9 - n is 0 only at n = 9, the only rung with a null direction; "boundary" is ours; Lorentzian = a signature of the Cartan form on the root lattice, not of a spacetime; the stop at 8 (T10 (7)) | `build_report_cat.py`, `content_cat.py`, `figs_cat.py`, `matrix_cat.py`, `cat_check.py` (Q1, Q2 messages) | Q1, Q2; T10 |
| E-042 | "the reason for the ten"; the ten classes of matter "our reading only" (row W5 graded A) | the count behind the ten (Wall, recalled); the correspondence is stated in Baez's paper (standard, quoted, not computed); which class at which clock value is open | `build_report_cat.py`, `content_cat.py`, `figs_cat.py`, `matrix_cat.py` | C1; wording. Row W5 clock: A -> S |
| E-043 | halving "fails with only null generators" | fails exactly for p = q = 0, r >= 3 (T5 (d)) | `build_report_cat.py`, `content_cat.py`, `figs_cat.py`, `matrix_cat.py`, `cat_check.py` (K5b message) | K5b; T5 |
| E-044 | "the radical is a face" | for r = 1 only; for r >= 2 the complement of the face of labels without a null bit | `build_report_cat.py`, `figs_cat.py` | R1 |
| E-045 | N3 title "symmetric only for odd n or without null generators"; tag open | lambda symmetric iff n odd; a symmetric form exists iff n odd or r = 0; proved (T3), tag open removed | `build_report_cat.py`, `content_cat.py`, `figs_cat.py` | F2, F3, F5; T3 |
| E-046 | null-bit weight in the Gauss sum not fixed against T4 (iii) | weight 0 here, weight 1 in T4 (iii): same phase, moduli differ by 2^r | `build_report_cat.py` | K4a, K4c |
| E-047 | "label 0 first appears in the category at n = 3"; "the same pattern" (N7, Fig. 5) | Euler (6,0,2) and Tits (6,1,1) both shown (T8); reading as label 0 ours; the likeness is question QB4 | `build_report_cat.py`, `content_cat.py`, `figs_cat.py`, `cat_check.py` (E1 message) | E1; T8 |
| E-048 | "functors" | maps (no categories named; halving depends on t; the complement keeps n) | `build_report_cat.py`, `content_cat.py`, `figs_cat.py`, `matrix_cat.py` | wording |

Totals, category: checks 52 (ids and results unchanged; messages of G1, K5b, Q1, Q2, E1 reworded), sabotage 54 of 54, report tests 73 -> 78 (five v1.2 pins), matrix 40 rows, 76 cells, best grades 27/6/2/5 (was 27/5/3/5).

## 2. Baez report (`baez/`)

| # | The report said | Now | Fixed in | Pinned by |
|---|---|---|---|---|
| E-049 | "the Hodge complement" (J5, J10, the geometry card, dead ends, H1b/O2d/C1 messages); "label 0" for the empty label (J10, K2a/C1 messages); row C.2 without a note | the complement pairing, a Frobenius duality, a metric Hodge star only without null generators; the empty label is the unit; C.2: non-commutative against commutative Frobenius | `build_report_baez.py`, `matrix_baez.py`, `baez_check.py` (docstring and four messages) | C1; bridge A6; cat F1; T3 |
| E-050 | row K.6 graded E with no remark | E = the counts agree exactly; no product of the bit rule is used | `matrix_baez.py` | K3 |
| E-051 | "particle to antiparticle", "the antiparticle side" | even <-> odd, Y and Q flip; calling it charge conjugation is ours | `build_report_baez.py`, `figs_baez.py`, `matrix_baez.py`, `baez_check.py` (H1b message) | H1b, H2c |
| E-052 | "the labels explain why"; anomaly sums "computed by us" | the six non-empty classes are the six pieces (checked), the reason is ours; the standard cancellation, recomputed over labels | `build_report_baez.py`, `matrix_baez.py` | H1a-H2d |
| E-053 | J3 "under the Standard Model they build a generation" | the nested triples contain (3,2); + (3bar,1) + (1,1); one generation; 11 more states; "builds" ours | `build_report_baez.py` | S1, E1a-E2d |
| E-054 | J6 "no chiral generation inside h3(O)" | the 27 is self-conjugate (checked); real representations are vector-like (standard); Lie-algebra level only | `build_report_baez.py`, `matrix_baez.py` | S2, O3a-O3h |

Also made explicit (not an error): every comparison of the (1,9) of h2(O) with the (1,9) of the triangulation form says real 10 against complex 10, no mechanism (J7, the triangulation card, view 9, Fig. 1 edge h, the signature figure, row T.4).

Totals, Baez: checks 56 with the papers' texts (55 and "skip R1" without them; messages of H1b, O2d, K2a, C1 reworded), sabotage 56 of 56, report tests 49 -> 48 (five tests of a file that is not part of the package removed with its builder; four pins T36-T39 added; eleven tests need the papers' texts and are skipped without them), matrix 48 rows, 61 cells, grades unchanged (26/11/2/9).

## 3. Schuller report (`schuller/`)

| # | The report said | Now | Fixed in | Pinned by |
|---|---|---|---|---|
| E-055 | P2 "the excluded Cl(2,2) is also the quadric of entangled two-qubit states" | det = 0 is the cone of product states, for real amplitudes; over C det = 0 on M2(C); the link to hyperbolicity is ours | `build_report.py`, `matrix_data.py` | Q10a, Q10b |
| E-056 | F12 "Mass is a fibre momentum, and hyperbolicity says the fibre is space-like" | Kaluza-Klein (standard); a time-like direction breaks hyperbolicity; a null one never enters (T16); the fibre reading is ours | `fibre_section.py`, `build_report.py`, `fibre_check.py` (G4 comment, G4d message) | G4a-G4d; T16 |
| E-057 | F6 "E, S, E, S, S, S, A", "steps 1-3 exact"; Fig. 1 link 3 | S, E, E, S, S, S, A (the figure); link 3: first condition E (T18 (f)), third condition a gap | `build_report.py` | B1-B5; T18 |
| E-058 | edge "X^2 = 0, parabolic"; T19 (1) | M = +-I has X = 0 and bounded powers: an edge is X^2 = 0 with X != 0 | `fibre_section.py`, `build_report.py`, `matrix_data.py`; T19 (1) in the errata list | G5e |
| E-059 | "two ladders", "first excluded" | one Lorentzian class in two conventions; Cl(2,2) the first ultrahyperbolic cell; r = 0 | `build_report.py`, `matrix_data.py` | B1-B3; T18 |
| E-060 | row L13 "Casimir = C(n,2)/4"; F5 without the raised indices | -C(n,2)/4 with indices raised, r = 0 | `build_report.py`, `matrix_data.py` | E4, E5 |
| E-061 | F13 "the bands ... are the trio", "a fifth home of the trio" | the textbook SL(2,R) split (T19); the grouping is ours | `fibre_section.py`, `build_report.py`, `matrix_data.py` | G5a-G5f; T19 |
| E-062 | F10/F11 "is Furey's End(V)", "the type of Cl(1,3)"; G2d message | isomorphic as algebras, generators not matched; base/fibre convention printed (reversion swaps) | `fibre_section.py`, `fibre_check.py` (G2d message) | G1a-G3e |
| E-063 | F1 "never name", P1 "the missing step" | without naming one (text search of the four documents); that it belongs there is ours | `build_report.py` | report test T15 |
| E-064 | F3 "Carroll", "Euclid"; P3 | the names are ours; frozen 1+1 model; the family for d > 1 is open (P3) | `build_report.py` | C1-C6 |
| E-065 | F4 so(4) split and 6 + 12 + 3 without limits | Euclidean count; Lorentzian Weyl 5s are complex conjugates; 6 + 12 + 3 depends on the frame | `build_report.py` | D1-D8 |
| E-066 | F15 "identified by count and rank" | named from count and rank only; Cartan matrices not computed (B3, C3: 18 roots, rank 3) | `fibre_section.py` | G8c |
| E-067 | bridge_check.py comment "Hodge star = ... XOR with the all-ones label" | only in the non-degenerate cells (A6, E-009) | `bridge_check.py` (comment) | A5, A6; M21 |
| E-068 | F14: the Golay statement "not a theorem I have proved in general" | stale under-claim: proved in T14 (a doubly-even self-dual code is a Lagrangian of the label form through the pseudoscalar; one exists iff 8 \| n) | `fibre_section.py` | G9a, G9b; T14 |

Also made explicit (not an error): Lambda ~ -s kappa^2 carries "ours; untested against his equations" wherever it appears (Fig. 1, row C8); the summary says what an exact cell means (the same algebraic identity, pointwise, in one chart).

Totals, Schuller: checks 163 (77 + 51 + 35; messages of G2d and G4d and two comments reworded), sabotage 21 automated (rerun) + 16 by hand, report tests 28 -> 32 (T24-T27; seven tests need the lecture texts and are skipped without them), matrix 43 rows, 109 cells, grades unchanged (23/14/2/4).

## 4. Combined translation matrix

`make_matrix_json.py` (this folder) rebuilds `translation_matrix.json` from the three corrected matrix modules; `node make_matrix_data.mjs reports/translation_matrix.json` rebuilds the web app's `translationMatrixData.js`. 131 rows x 22 columns, 246 cells, grades E 118, S 106, A 22 (was S 105, A 23), 18 rows with no cell. Changed against the json of the first round: 17 cell notes and 2 row titles (category C8 and C16), one grade (category W5, clock, A -> S):

- schuller L13 spin, C3 cells, C8 projective, M4 maxwell, M11 clock
- baez G.5 furey, E.2 rule, E.6 rule, K.6 rule, T.4 cells, C.2 rule
- category K5 spin, W5 clock (grade A -> S), C8 title and projective, C11 null, C16 title, cells and null

## 5. The five check scripts of the web app

`selfcheck/reports/cat_check.py`, `baez_check.py`, `fibre_check.py`, `bridge_check.py` are reworded as listed above (messages, comments, one docstring); `bridge_check_qm.py` is unchanged. Each copy in `reports/<report>/` is byte-identical to the one in `selfcheck/reports/` (the package test `test_reports.mjs` checks it). The mirror modules of the chapters (`*SelfcheckSource.js`) must be regenerated from the new files.
