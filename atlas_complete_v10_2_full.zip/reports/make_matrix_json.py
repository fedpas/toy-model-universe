#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Builds the combined translation matrix (Schuller 43 + Baez 48 + category 40 rows x 22 atlas columns) from the three matrix sources shipped in
this folder (schuller/matrix_data.py, baez/matrix_baez.py, category/matrix_cat.py), in the format that make_matrix_data.mjs reads.
Python standard library only.  Deterministic: the same sources give the same bytes.

    python3 make_matrix_json.py                  writes translation_matrix.json next to this script
    python3 make_matrix_json.py --check          writes nothing; exit 1 if translation_matrix.json is not what the sources give
Then, in the package folder:  node make_matrix_data.mjs reports/translation_matrix.json   (regenerates translationMatrixData.js)"""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
for sub in ('schuller', 'baez', 'category'):
    sys.path.insert(0, os.path.join(HERE, sub))
import matrix_data as S
import matrix_baez as B
import matrix_cat as C
assert S.COLS == B.COLS == C.COLS, 'the three matrices must share the 22 atlas columns'
cols = [dict(key=k, short=s, long=l, where=w) for k, s, l, w in S.COLS]
MATS = [('schuller', 'Schuller lectures and gravitational closure', S), ('baez', 'Seven Baez papers', B),
        ('category', 'Category lens (KTH Clifford notes, Tenfold Way, Tian, Majkic, background)', C)]
mats = {}
for key, name, mod in MATS:
    rows = []
    for rid, src, title, cells in mod.ROWS:
        rows.append(dict(id=rid, source=src, title=title, cells={k: dict(grade=g, note=n) for k, (g, n) in cells.items()}))
    mats[key] = dict(name=name, rows=rows)
text = json.dumps(dict(columns=cols, matrices=mats), ensure_ascii=False, indent=1)
out = os.path.join(HERE, 'translation_matrix.json')
n = sum(len(m['rows']) for m in mats.values()); cells = sum(len(r['cells']) for m in mats.values() for r in m['rows'])
grades = {g: sum(1 for m in mats.values() for r in m['rows'] for c in r['cells'].values() if c['grade'] == g) for g in 'ESA'}
if '--check' in sys.argv:
    same = os.path.exists(out) and open(out, encoding='utf-8').read() == text
    print(('up to date: ' if same else 'STALE: ') + f'{n} rows, {cells} cells, grades {grades}')
    sys.exit(0 if same else 1)
open(out, 'w', encoding='utf-8').write(text)
print(f'wrote translation_matrix.json: {n} rows, {cells} cells, grades {grades}')
