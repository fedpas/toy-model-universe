#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Runs everything that ships with the three reports, one line each (PASS, FAIL or SKIP), and exits 1 if anything failed:
#   the five check scripts (their ok lines must equal the recorded logs), the three report test suites (the category one in a browser when python's
#   playwright is installed and REPORT_NO_BROWSER is not set, else without its 16 browser tests), the matrix json, the check-id table of selfcheck/reports/README.md, the zips and MANIFEST.json.
#   sh reports/run_report_tests.sh              about 1 minute
#   sh reports/run_report_tests.sh --mutation   also the three sabotage scripts (about 40 minutes on two cores): every mutant must be caught
# Needs python3 with numpy, scipy and networkx (exit 77 without them). The papers' texts are not shipped: Baez check R1 and the text-pinned report tests are skipped and say so.
cd "$(dirname "$0")" || exit 2
MUT=0
for a in "$@"; do case "$a" in --mutation) MUT=1;; *) echo "run_report_tests.sh: unknown option $a" >&2; exit 2;; esac; done
python3 -c 'import numpy, scipy, networkx' 2>/dev/null || { echo "run_report_tests.sh: python3 with numpy, scipy and networkx is needed (pip install numpy scipy networkx)"; exit 77; }
ATLAS_PKG=${ATLAS_PKG:-$(cd .. && pwd)}; export ATLAS_PKG
TMP=$(mktemp -d "${TMPDIR:-/tmp}/report_tests.XXXXXX") || exit 2
trap 'rm -rf "$TMP"' EXIT
FAILS=0; PASSES=0; SKIPS=0
say() { echo "$1 $2: $3"; case $1 in PASS) PASSES=$((PASSES+1));; FAIL) FAILS=$((FAILS+1));; SKIP) SKIPS=$((SKIPS+1));; esac; }
oklines() { grep -E '^(ok  |FAIL) ' "$1" | grep -v '^ok   R1:'; }
# 1. the check scripts against their logs (R1 of baez_check.py needs the papers' texts; it is left out of the comparison when skipped)
for pair in category/cat_check.py:category/logs/cat_check.log baez/baez_check.py:baez/logs/baez_check.log schuller/fibre_check.py:schuller/logs/fibre_check_final.log \
            schuller/bridge_check.py:schuller/logs/bridge_check_final.log schuller/bridge_check_qm.py:schuller/logs/bridge_check_qm_final.log; do
  s=${pair%%:*}; l=${pair#*:}; out="$TMP/$(basename "$s").out"
  (cd "$(dirname "$s")" && python3 "$(basename "$s")") > "$out" 2>&1; rc=$?
  if [ $rc -eq 0 ] && oklines "$out" > "$TMP/a" && oklines "$l" > "$TMP/b" && cmp -s "$TMP/a" "$TMP/b"; then say PASS "$s" "$(grep -c '^ok  ' "$out") ok, the same lines as $l$(grep -q '^skip R1' "$out" && echo ' (R1 skipped: no texts)')"
  else say FAIL "$s" "exit $rc or lines differ from $l"; fi
done
# 2. the report suites
if [ -n "${REPORT_NO_BROWSER:-}" ]; then NB=1; elif python3 -c 'import playwright' 2>/dev/null; then NB=; else NB=1; fi   # REPORT_NO_BROWSER=1: leave the browser part out on purpose
(cd category && REPORT_NO_BROWSER=$NB python3 test_report_cat.py) > "$TMP/cat.out" 2>&1 && say PASS category/test_report_cat.py "$(tail -1 "$TMP/cat.out")" || say FAIL category/test_report_cat.py "$(grep -m3 '^FAIL' "$TMP/cat.out" | tr '\n' ' ') $(tail -1 "$TMP/cat.out")"
(cd baez && python3 test_report_baez.py) > "$TMP/baez.out" 2>&1 && say PASS baez/test_report_baez.py "$(tail -1 "$TMP/baez.out")" || say FAIL baez/test_report_baez.py "$(grep -m3 '^FAIL' "$TMP/baez.out" | tr '\n' ' ')"
(cd schuller && python3 test_report.py) > "$TMP/sch.out" 2>&1 && say PASS schuller/test_report.py "$(tail -1 "$TMP/sch.out")" || say FAIL schuller/test_report.py "$(grep -m3 '^FAIL' "$TMP/sch.out" | tr '\n' ' ')"
# 3. generated files are current
python3 make_matrix_json.py --check > "$TMP/m.out" 2>&1 && say PASS make_matrix_json.py "$(tail -1 "$TMP/m.out")" || say FAIL make_matrix_json.py "$(tail -1 "$TMP/m.out")"
python3 make_check_table.py --check > "$TMP/t.out" 2>&1 && say PASS make_check_table.py "$(tail -1 "$TMP/t.out")" || say FAIL make_check_table.py "$(tail -1 "$TMP/t.out")"
python3 make_package.py --check > "$TMP/p.out" 2>&1 && say PASS make_package.py "$(tail -1 "$TMP/p.out")" || say FAIL make_package.py "$(tail -1 "$TMP/p.out")"
# 4. sabotage (optional, long): in a copy, so the shipped logs stay as they are
if [ $MUT = 1 ]; then
  cp -R category baez schuller "$TMP/"
  for pair in schuller:mutate_fibre.py category:mutate_cat.py baez:mutate_baez.py; do
    d=${pair%%:*}; s=${pair#*:}
    ONLY=; NOTE=
    if [ "$s" = mutate_baez.py ] && [ ! -d baez/txt ]; then ONLY=$(seq -f 'M%02g' 2 56); NOTE=' (M01, the sabotage of R1, needs the papers'"'"' texts: not run)'; fi
    (cd "$TMP/$d" && python3 "$s" $ONLY) > "$TMP/$s.log" 2>&1; caught=$(grep -o 'mutants caught: [0-9]* of [0-9]*' "$TMP/$s.log")
    n1=$(echo "$caught" | awk '{print $3}'); n2=$(echo "$caught" | awk '{print $5}')
    if [ -n "$n1" ] && [ "$n1" = "$n2" ]; then say PASS "$d/$s" "$caught$NOTE"; else say FAIL "$d/$s" "${caught:-no verdict}$NOTE"; fi
  done
else say SKIP "sabotage scripts" "run with --mutation (about 40 minutes)"; fi
echo "run_report_tests.sh: $PASSES passed, $FAILS failed, $SKIPS skipped"
[ $FAILS = 0 ]
