// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import T from './threegenData.js';
import { THREEGEN_PY } from './threegenSelfcheckSource.js';
import { Intro } from './Fold.jsx';
import { Tx } from './MathText.jsx';
import { Formal, isLearner } from './Formal.jsx';

// T4-17: what the search with Furey’s block sizes found, read from the data: the most generations any choice holds, the fewest exotic complex
// dimensions of any choice (none is free of them), the fewest among the choices that hold at least one generation, and Furey’s own frame
const PF = T.search_peirce_frame, PF_E = PF.least_exotic_dimension_for_generations;
export const FRAME = { top: Math.max(...Object.keys(PF.histogram).map(Number)), e0: Math.min(...Object.values(PF_E)), e1: Math.min(...Object.entries(PF_E).filter(([g]) => +g >= 1).map(([, v]) => v)), furey: T.generations.furey_frame, fureyExotic: T.exotic.antilinear };
const COPY = {
  en: {
    eyebrow: 'THREE GENERATIONS · A TEST OF THE 256', title: 'Can the 256 hold three generations?',
    lede: 'Short answer: by counting dimensions, yes; by counting gauge representations, no. We decompose all 256 real dimensions of End(V) = M₁₆(ℝ) into Standard Model irreps, using the gauge action that Furey’s blocks define, and count how many complete generations fit.',
    sectors: 'Where the 128 complex dimensions go (256 real)',
    bars: [['gauge blocks', 16, 'diag'], ['linear off-diagonal: one generation + replica, all Standard-Model type', 48, 'sm'], ['antilinear: Standard-Model type', 32, 'sm2'], ['antilinear: exotic charges (5/6, 4/3, 2, …)', 32, 'ex']],
    fits: 'Dimension count: one generation with its antiparticles is 16 + 16 complex dimensions, so three would take 96 of the 112 matter dimensions. Also 48 = 3 × 16, but that is a coincidence of capacity: the 48 holds one generation, its conjugate and a partial replica, not three generations.',
    tableH: 'How many copies of each Standard Model irrep the matter part holds', cols: ['irrep', 'linear', 'antilinear', 'total', 'needed for 3'],
    tableNote: 'Linear counts the 48 off-diagonal dimensions. The bottleneck is Q_L = (3,2,+1/6): it appears once, in the linear part, and the antilinear part adds none. ν_R is its own conjugate, so its count includes both directions of one edge.',
    searchH: 'Could another block structure do better?',
    search1: n => `We tried every 8-dimensional structure built from singlets, doublets, triplets and anti-triplets with Standard Model hypercharges (${n} of them). The most complete generations any of them holds is 2. Furey’s own structure holds 1.`,
    search2: n => `Keeping Furey’s block sizes (1,3,2,1,1) and only changing the hypercharges (${n} choices): at most ${FRAME.top} generations. No choice is free of exotic charges: every one has at least ${FRAME.e0} complex dimensions of them, and every one that holds a generation at least ${FRAME.e1}. Furey’s own choice holds ${FRAME.furey} ${FRAME.furey === 1 ? 'generation' : 'generations'} and has ${FRAME.fureyExotic}.`,
    verdictH: 'What this says',
    verdict: ['The linear off-diagonal part is exactly Standard-Model type and holds one generation plus a partial replica (d_R, two L, e_R): checked.', 'Three complete generations do not fit the gauge-representation content of Cl(0,8) in any admissible block structure: checked, with the limits of the search stated below.', 'So a family structure for generations has to come from somewhere outside the gauge action. That is open, and we do not claim it.'],
    limits: 'Limits of the search: blocks of size 1, 2 and 3 (singlet, doublet, triplet, anti-triplet), hypercharges up to |y| = 2, generations counted as copies of the six irreps in the matter part (linear off-diagonal plus antilinear). It does not test family symmetries, other representations of Cl(0,8), or a different identification of fermions with operators.',
    dlH: 'Check it yourself', dlText: 'One self-contained Python file (standard library only). It rebuilds the decomposition, the counts and both searches.', dlPy: 'Download threegen_selfcheck.py', dlJson: 'Download threegen.json', dlCmd: 'python3 threegen_selfcheck.py --compare threegen.json',
    tags: [['checked', 'decomposition and counts'], ['checked', 'exhaustive search over the stated structures'], ['open', 'a family structure outside the gauge action']]
  },
  it: {
    eyebrow: 'TRE GENERAZIONI · UNA PROVA SUI 256', title: 'I 256 possono contenere tre generazioni?',
    lede: 'Risposta breve: contando le dimensioni sì; contando le rappresentazioni di gauge no. Scomponiamo tutte le 256 dimensioni reali di End(V) = M₁₆(ℝ) in irreps del Modello Standard, usando l’azione di gauge definita dai blocchi di Furey, e contiamo quante generazioni complete ci stanno.',
    sectors: 'Dove vanno le 128 dimensioni complesse (256 reali)',
    bars: [['blocchi di gauge', 16, 'diag'], ['lineare fuori diagonale: una generazione + replica, tutto di tipo Modello Standard', 48, 'sm'], ['antilineare: tipo Modello Standard', 32, 'sm2'], ['antilineare: cariche esotiche (5/6, 4/3, 2, …)', 32, 'ex']],
    fits: 'Conto delle dimensioni: una generazione con le sue antiparticelle sono 16 + 16 dimensioni complesse, quindi tre ne richiederebbero 96 delle 112 dimensioni di materia. Inoltre 48 = 3 × 16, ma è una coincidenza di capacità: i 48 contengono una generazione, la sua coniugata e una replica parziale, non tre generazioni.',
    tableH: 'Quante copie di ogni irrep del Modello Standard contiene la parte di materia', cols: ['irrep', 'lineare', 'antilineare', 'totale', 'servono per 3'],
    tableNote: 'Lineare conta le 48 dimensioni fuori diagonale. Il collo di bottiglia è Q_L = (3,2,+1/6): compare una sola volta, nella parte lineare, e quella antilineare non ne aggiunge. ν_R è coniugato di sé stesso, quindi il suo conteggio include entrambe le direzioni di uno stesso spigolo.',
    searchH: 'Un’altra struttura a blocchi farebbe meglio?',
    search1: n => `Abbiamo provato ogni struttura a 8 dimensioni fatta di singoletti, doppietti, tripletti e anti-tripletti con ipercariche del Modello Standard (${n} in tutto). Il massimo di generazioni complete che una di esse contiene è 2. La struttura di Furey ne contiene 1.`,
    search2: n => `Tenendo le dimensioni dei blocchi di Furey (1,3,2,1,1) e cambiando solo le ipercariche (${n} scelte): al massimo ${FRAME.top} generazioni. Nessuna scelta è priva di cariche esotiche: ognuna ne ha almeno ${FRAME.e0} dimensioni complesse, e ognuna che contiene una generazione almeno ${FRAME.e1}. La scelta di Furey contiene ${FRAME.furey} ${FRAME.furey === 1 ? 'generazione' : 'generazioni'} e ha ${FRAME.fureyExotic} dimensioni esotiche.`,
    verdictH: 'Che cosa dice',
    verdict: ['La parte lineare fuori diagonale è esattamente di tipo Modello Standard e contiene una generazione più una replica parziale (d_R, due L, e_R): verificato.', 'Tre generazioni complete non stanno nel contenuto di rappresentazioni di gauge di Cl(0,8) in nessuna struttura a blocchi ammissibile: verificato, entro i limiti della ricerca indicati sotto.', 'Quindi una struttura di famiglia per le generazioni deve venire da fuori dell’azione di gauge. È aperto e non lo affermiamo.'],
    limits: 'Limiti della ricerca: blocchi di dimensione 1, 2 e 3 (singoletto, doppietto, tripletto, anti-tripletto), ipercariche fino a |y| = 2, generazioni contate come copie dei sei irreps nella parte di materia (lineare fuori diagonale più antilineare). Non prova simmetrie di famiglia, altre rappresentazioni di Cl(0,8) né un’altra identificazione dei fermioni con gli operatori.',
    dlH: 'Verificalo tu', dlText: 'Un unico file Python autonomo (solo libreria standard). Ricostruisce la scomposizione, i conteggi e le due ricerche.', dlPy: 'Scarica threegen_selfcheck.py', dlJson: 'Scarica threegen.json', dlCmd: 'python3 threegen_selfcheck.py --compare threegen.json',
    tags: [['checked', 'scomposizione e conteggi'], ['checked', 'ricerca esaustiva sulle strutture indicate'], ['open', 'una struttura di famiglia fuori dall’azione di gauge']]
  }
};
// the Young Learner reads this tab in plain words: boxes, places and families; the formal tables and checks are in the fold "for older readers".
// Every sentence is true of threegenData.js (counts 16 / 48 / 32 / 32 of 128, the six kinds and their copies, the two searches).
const YL = {
  en: {
    eyebrow: 'THREE FAMILIES · A TEST OF THE BOXES', title: 'Room for three families?',
    sectors: 'Where the 128 places go',
    bars: ['inside the boxes: the forces act here', 'links between boxes that turn along with the special key: one family, its antiparticles and some spares, all of kinds nature has', 'links that turn against the special key, of kinds nature has', 'links that turn against the special key, with charges no known particle has (5/6, 4/3, 2, …)'],
    key: 'The special key is a quarter-turn of the model: turn it twice and every sign flips.',
    fits: 'Counting places: one family with its antiparticles needs 16 + 16 = 32 places, so three families would need 96. There are 112 places outside the boxes, so by counting alone there is room. (The 48 links are 3 × 16, but that is a coincidence: they hold one family, its antiparticles and some spares, not three families.)',
    tableH: 'The real check: are the right pieces there three times?', cols: ['piece of the family', 'how many times it is there', 'needed for three families'],
    names: { Q_L: 'left-handed quarks (up and down together)', u_R: 'right-handed up quarks', d_R: 'right-handed down quarks', L: 'left-handed electron and neutrino', e_R: 'right-handed electron', nu_R: 'right-handed neutrino' },
    tableNote: 'The left-handed quarks are there only once, so only one complete family fits. The right-handed neutrino is counted in both directions of its link, which is why its number is high.',
    searchH: 'Could other boxes do better?',
    search1: n => `We tried every way of building the boxes from pieces of size 1, 2 and 3 with the charges nature uses (${n} ways). The best of them holds 2 complete families, never 3. Furey’s own boxes hold 1.`,
    search2: n => `Keeping Furey’s box sizes (1, 3, 2, 1, 1) and only changing the charges (${n} choices): at most ${FRAME.top} complete families. Every choice also has places with charges no known particle has: at least ${FRAME.e0} of them, and at least ${FRAME.e1} in every choice that holds a family. Furey’s own boxes hold ${FRAME.furey} ${FRAME.furey === 1 ? 'family' : 'families'} and have ${FRAME.fureyExotic} such places.`,
    hist: (g, n) => `${g} ${g === '1' ? 'family' : 'families'}: ${n}`,
    verdictH: 'What this says',
    verdict: ['One family fits: checked.', 'Three complete families do not fit, in any of the box layouts we tried: checked, within the limits written in the fold.', 'So if three families come from this structure at all, they must come from something this check does not look at. That is open, and we do not claim it. Nothing here is a claim about real particles: it is a check of one model.'],
    tags: [['checked', 'the counting'], ['checked', 'a search over all the box layouts we allowed'], ['open', 'where three families could come from']]
  },
  it: {
    eyebrow: 'TRE FAMIGLIE · UNA PROVA DELLE SCATOLE', title: 'C’è posto per tre famiglie?',
    sectors: 'Dove vanno i 128 posti',
    bars: ['dentro le scatole: qui agiscono le forze', 'legami tra scatole che girano con la chiave speciale: una famiglia, le sue antiparticelle e qualche posto di scorta, tutti di tipi che esistono in natura', 'legami che girano contro la chiave speciale, di tipi che esistono in natura', 'legami che girano contro la chiave speciale, con cariche che nessuna particella nota ha (5/6, 4/3, 2, …)'],
    key: 'La chiave speciale è un quarto di giro del modello: girala due volte e ogni segno si capovolge.',
    fits: 'Contando i posti: una famiglia con le sue antiparticelle chiede 16 + 16 = 32 posti, quindi tre famiglie ne chiederebbero 96. Fuori dalle scatole ci sono 112 posti, quindi contando e basta c’è spazio. (I 48 legami sono 3 × 16, ma è una coincidenza: contengono una famiglia, le sue antiparticelle e qualche posto di scorta, non tre famiglie.)',
    tableH: 'La vera prova: i pezzi giusti ci sono tre volte?', cols: ['pezzo della famiglia', 'quante volte c’è', 'servono per tre famiglie'],
    names: { Q_L: 'quark sinistrorsi (up e down insieme)', u_R: 'quark up destrorsi', d_R: 'quark down destrorsi', L: 'elettrone e neutrino sinistrorsi', e_R: 'elettrone destrorso', nu_R: 'neutrino destrorso' },
    tableNote: 'I quark sinistrorsi ci sono una sola volta, quindi ci sta una sola famiglia completa. Il neutrino destrorso è contato nelle due direzioni del suo legame, ed ecco perché il suo numero è alto.',
    searchH: 'Altre scatole farebbero meglio?',
    search1: n => `Abbiamo provato ogni modo di costruire le scatole con pezzi di grandezza 1, 2 e 3 e con le cariche che usa la natura (${n} modi). Il migliore contiene 2 famiglie complete, mai 3. Le scatole di Furey ne contengono 1.`,
    search2: n => `Tenendo le grandezze delle scatole di Furey (1, 3, 2, 1, 1) e cambiando solo le cariche (${n} scelte): al massimo ${FRAME.top} famiglie complete. Ogni scelta ha anche posti con cariche che nessuna particella nota ha: almeno ${FRAME.e0}, e almeno ${FRAME.e1} in ogni scelta che contiene una famiglia. Le scatole di Furey contengono ${FRAME.furey} ${FRAME.furey === 1 ? 'famiglia' : 'famiglie'} e hanno ${FRAME.fureyExotic} posti così.`,
    hist: (g, n) => `${g} ${g === '1' ? 'famiglia' : 'famiglie'}: ${n}`,
    verdictH: 'Che cosa dice',
    verdict: ['Una famiglia ci sta: verificato.', 'Tre famiglie complete non ci stanno, in nessuna delle disposizioni di scatole che abbiamo provato: verificato, entro i limiti scritti nella parte chiusa.', 'Quindi, se tre famiglie vengono da questa struttura, devono venire da qualcosa che questa prova non guarda. È aperto, e non lo affermiamo. Niente qui è un’affermazione sulle particelle vere: è la prova di un modello.'],
    tags: [['checked', 'il conteggio'], ['checked', 'una ricerca su tutte le disposizioni di scatole ammesse'], ['open', 'da dove potrebbero venire tre famiglie']]
  }
};
export const THREEGEN_YL = YL, THREEGEN_COPY = COPY;
const TAGCOL = { checked: '#34d399', open: '#f87171' };
const BARCOL = { diag: '#8b93a7', sm: '#34d399', sm2: '#60a5fa', ex: '#f87171' };
function download(name, text, type) { try { const b = new Blob([text], { type }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 1000); } catch (e) { /* ignore */ } }
const STYLE = `.tg{max-width:1000px;margin:28px auto;padding:0 16px}.tg h3{margin:1.2em 0 .4em}.tg-card{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:12px 14px;margin:10px 0}.tg-scroll{overflow-x:auto}.tg table{border-collapse:collapse;width:100%;font-size:.88em}.tg th,.tg td{text-align:left;padding:3px 8px;border-bottom:1px solid rgba(128,128,128,.25)}.tg .mono{font-family:ui-monospace,Menlo,monospace}.tg-tag{display:inline-block;margin:2px 6px 2px 0;padding:1px 8px;border-radius:6px;border:1px solid;font-size:.78em}.tg-cap{font-size:.85em;opacity:.8}.tg-btn{background:none;border:1px solid rgba(128,128,128,.5);border-radius:8px;padding:6px 12px;color:inherit;cursor:pointer;font:inherit;margin:4px 8px 4px 0}`;

export default function ThreeGenSection({ lang = 'en', profile = 'Young Learner' }) {
  const t = COPY[lang] || COPY.en, y = YL[lang] || YL.en, learner = isLearner(profile), rows = ['Q_L', 'u_R', 'd_R', 'L', 'e_R', 'nu_R'].map(n => [n, T.sm_rows[n]]), W = 620, tot = 128;
  const genW = g => lang === 'it' ? (g === '1' ? 'generazione' : 'generazioni') : 'generations';
  const hist = (h, plain) => Object.entries(h).map(([g, n]) => plain ? y.hist(g, n) : `${g} ${genW(g)}: ${n}`).join(' · ');
  const tags = list => <div>{list.map(([k, s]) => <span key={s} className="tg-tag" style={{ color: TAGCOL[k] }}><Tx>{k === 'checked' ? (lang === 'it' ? 'verificato' : 'checked') : (lang === 'it' ? 'aperto' : 'open')}</Tx> · <Tx>{s}</Tx></span>)}</div>;
  let x = 0;
  const bars = <svg viewBox={`0 0 ${W} 54`} role="img" aria-label={learner ? y.sectors : t.sectors} style={{ width: '100%' }}>
        {t.bars.map(([l, n, c]) => { const w = n / tot * (W - 4), r = <rect key={l} x={2 + x} y="6" width={w - 2} height="30" rx="4" fill={BARCOL[c]} fillOpacity=".75" />; const tx = x; x += w; return <g key={l}><Tx>{r}</Tx><text x={2 + tx + (w - 2) / 2} y="26" textAnchor="middle" fontSize="13" fill="#0b1020">{n}{learner ? '' : 'ℂ'}</text></g>; })}
        <text x="2" y="50" fontSize="10" fill="currentColor" opacity=".7">0</text><text x={W - 2} y="50" fontSize="10" textAnchor="end" fill="currentColor" opacity=".7">{learner ? '128' : '128ℂ = 256 ℝ'}</text>
      </svg>;
  const legend = (labels, unit) => t.bars.map(([l, n, c], i) => <p key={l} className="tg-cap" style={{ margin: '2px 0' }}><span style={{ display: 'inline-block', width: 10, height: 10, borderRadius: 3, background: BARCOL[c], marginRight: 6 }} /><Tx>{labels[i]}</Tx> (<Tx>{n}</Tx>{unit})</p>);
  const tableF = <><table><thead><tr>{t.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {rows.map(([n, r]) => <tr key={n}><td className="mono"><Tx>{n.replace('nu_R', 'ν_R')}</Tx> <Tx>{r.rep}</Tx></td><td><Tx>{r.linear}</Tx></td><td><Tx>{r.antilinear}</Tx></td><td><Tx>{r.linear + r.antilinear}</Tx></td><td>3</td></tr>)}</tbody></table>
      <p className="tg-cap"><Tx>{t.tableNote}</Tx></p></>;
  const searchF = <><p><Tx>{t.search1(T.search_all.admissible_W)}</Tx></p>
      <p className="mono tg-cap"><Tx>{hist(T.search_all.histogram)}</Tx></p>
      <p><Tx>{t.search2(T.search_peirce_frame.assignments)}</Tx></p>
      <p className="mono tg-cap"><Tx>{hist(T.search_peirce_frame.histogram)}</Tx></p></>;
  const dlF = <><h3><Tx>{t.dlH}</Tx></h3><p><Tx>{t.dlText}</Tx></p>
    <div><button className="tg-btn" onClick={() => download('threegen_selfcheck.py', THREEGEN_PY, 'text/x-python')}><Tx>{t.dlPy}</Tx></button><button className="tg-btn" onClick={() => download('threegen.json', JSON.stringify(T, null, 1), 'application/json')}><Tx>{t.dlJson}</Tx></button></div>
    <p className="mono tg-cap"><Tx>{t.dlCmd}</Tx></p></>;
  const head = <><p className="eyebrow"><Tx>{learner ? y.eyebrow : t.eyebrow}</Tx></p><h2 id="tg-h"><Tx>{learner ? y.title : t.title}</Tx></h2><Intro lang={lang} profile={profile} id="threegen" lede={t.lede} /></>;
  // the young learner: boxes, places and families in plain words, a plain table of the six pieces, and one fold with everything formal
  if (learner) return <section className="tg" aria-labelledby="tg-h"><style>{STYLE}</style>{head}
    {tags(y.tags)}
    <h3><Tx>{y.sectors}</Tx></h3>
    <div className="tg-card">{bars}{legend(y.bars, '')}<p className="tg-cap"><Tx>{y.key}</Tx></p><p><Tx>{y.fits}</Tx></p></div>
    <h3><Tx>{y.tableH}</Tx></h3>
    <div className="tg-card tg-scroll"><table className="tg-plain"><thead><tr>{y.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>
      {rows.map(([n, r]) => <tr key={n}><td><Tx>{y.names[n]}</Tx></td><td><Tx>{r.linear + r.antilinear}</Tx></td><td>3</td></tr>)}</tbody></table>
      <p className="tg-cap"><Tx>{y.tableNote}</Tx></p></div>
    <h3><Tx>{y.searchH}</Tx></h3>
    <div className="tg-card"><p><Tx>{y.search1(T.search_all.admissible_W)}</Tx></p>
      <p className="mono tg-cap"><Tx>{hist(T.search_all.histogram, true)}</Tx></p>
      <p><Tx>{y.search2(T.search_peirce_frame.assignments)}</Tx></p>
      <p className="mono tg-cap"><Tx>{hist(T.search_peirce_frame.histogram, true)}</Tx></p></div>
    <h3><Tx>{y.verdictH}</Tx></h3>
    <div className="tg-card">{y.verdict.map(v => <p key={v}><Tx>{v}</Tx></p>)}</div>
    <Formal profile={profile} lang={lang}><h3><Tx>{t.title}</Tx></h3>{tags(t.tags)}<h4><Tx>{t.sectors}</Tx></h4>{legend(t.bars.map(b => b[0]), 'ℂ')}<p><Tx>{t.fits}</Tx></p>
      <h4><Tx>{t.tableH}</Tx></h4><div className="tg-scroll">{tableF}</div><h4><Tx>{t.searchH}</Tx></h4>{searchF}
      <h4><Tx>{t.verdictH}</Tx></h4>{t.verdict.map(v => <p key={v}><Tx>{v}</Tx></p>)}<p className="tg-cap"><Tx>{t.limits}</Tx></p>{dlF}</Formal>
  </section>;
  return <section className="tg" aria-labelledby="tg-h"><style>{STYLE}</style>{head}
    {tags(t.tags)}
    <h3><Tx>{t.sectors}</Tx></h3>
    <div className="tg-card">
      {bars}
      {legend(t.bars.map(b => b[0]), 'ℂ')}
      <p><Tx>{t.fits}</Tx></p>
    </div>
    <h3><Tx>{t.tableH}</Tx></h3>
    <div className="tg-card tg-scroll">{tableF}</div>
    <h3><Tx>{t.searchH}</Tx></h3>
    <div className="tg-card">{searchF}</div>
    <h3><Tx>{t.verdictH}</Tx></h3>
    <div className="tg-card">{t.verdict.map(v => <p key={v}><Tx>{v}</Tx></p>)}<p className="tg-cap"><Tx>{t.limits}</Tx></p></div>
    {dlF}
  </section>;
}
