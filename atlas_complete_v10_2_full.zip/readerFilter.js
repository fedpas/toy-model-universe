// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The reader filter (v10.2, for researchers). A first visit shows everything. In Settings the reader can hide KNOWN GROUND: the lines tagged both standard and
// checked, and neither ours nor open (a line tagged standard alone, a citation without a check of ours, stays). A second switch also hides those plain
// citations. The 15 rows of the tally on the equations page (#eq-tally) are navigation and are never hidden; neither is anything inside [data-rf-own]
// (a page that filters its own lines, such as the researchers page, reads getFilter / subscribeFilter and does it itself).
// How: the statement lines are drawn by many small components, each with its own markup, and there is no single "claim" component. So the filter is CSS
// on the structure that is already there: main[data-rf="known"] (or "known+std") plus, for each kind of line, a rule that hides the line when the tags
// inside it say known ground (LINES below). Nothing is inserted into the parts of the page that React draws. The number of hidden lines is COUNTED by a
// read-only scan of <main> (the same selectors, querySelectorAll; again after every change of the page, by a MutationObserver): one notice per page and
// the Settings menu show it. The setting: off (default) | known | known+std, stored in localStorage atlas.filter; ?filter=known in the address wins (not stored).
export const FILTERS = ['off', 'known', 'known+std'];
export const FILTER_KEY = 'atlas.filter';
export const DEFAULT_FILTER = 'off';
// "?filter=known+std" reaches the page as "known std" (a + in a query string is a space): both spellings are accepted
export const validFilter = v => { const x = typeof v === 'string' ? v.trim().replace(/\s+/g, '+') : ''; return FILTERS.includes(x) ? x : null; };
export function pickFilter(search, storage) {
  let u = null; try { u = validFilter(new URLSearchParams(search || '').get('filter')); } catch { /* not a query string */ }
  if (u) return { filter: u, from: 'url' };
  let s = null; try { s = storage ? validFilter(storage.getItem(FILTER_KEY)) : null; } catch { /* storage can be blocked */ }
  if (s) return { filter: s, from: 'storage' };
  return { filter: DEFAULT_FILTER, from: 'default' };
}

// ---- the definitions, on a list of flags (for pages that hold their claims as data, e.g. the claims table)
export const KINDS = ['checked', 'standard', 'ours', 'open'];
const flagsOf = f => (Array.isArray(f) ? f : String(f || '').split(/[\s,]+/)).filter(Boolean);
export const isKnownGround = f => { const s = new Set(flagsOf(f)); return s.has('standard') && s.has('checked') && !s.has('ours') && !s.has('open'); };
export const isPlainCitation = f => { const s = new Set(flagsOf(f)); return s.has('standard') && !s.has('checked') && !s.has('ours') && !s.has('open'); };
export const hiddenBy = (mode, f) => (mode === 'known' ? isKnownGround(f) : mode === 'known+std' ? isKnownGround(f) || isPlainCitation(f) : false);

// ---- the lines of the page, as they are drawn today: [the line, where its tags sit inside it (a relative selector; null: the line is a tag itself), extra condition]
// A new kind of line is added here (and in test_filter_ui.mjs, which checks every rule against the tags it finds on the pages).
const TAG = k => `:is(.tag,.rn-tag).${k}`;
export const LINES = [
  ['.page-tags > .tag', null],                                    // one entry of the tag strip under a page's introduction (the strip title and the legend stay)
  ['.ls-glance .tag', null],                                      // one entry of the at-a-glance strip of a labels tab
  ['aside.glance', '> p:first-child > '],                         // the at-a-glance strip of a tab: one Map node, its tags in the first row
  [':is(.eq-pt,.gs-pt,.sh-pt)', '> div > '],                      // a point: a column of tags, then the text
  ['.nl-res', '> div > '],                                        // a result of the null-surfaces step
  ['.f-card', '> .f-tags > '],                                    // a finding of the Furey page: its tags sit in a span under the card's top
  [':is(.eq-xr,.gs-xr,.sh-xr)', '> h4 > '],                       // a view: a heading with its tags, then the text
  [':is(.fq-row,.sp-row,.spr-row,.rg-row)', '> button '],         // a ledger row: status and source tags in the row's header
  ['details.leaf', '> summary > '],                               // a leaf of the Map tree (a branch stays: it holds other lines)
  ['.map-rtab tbody tr', '> td > '],                              // a row of the Map's research table
  ['.rn-dialog li', '> '],                                        // a line of a researcher note
  ['div:has(> p)', '> div > ', '', true],                         // any other point drawn like the ones above (a div of tags, then the text in a p), whatever its class
  [':is(p,li)', '> ', '', true],                                  // any other paragraph or item that holds its tags and its text (captions, cards, notes, the atlas audit line)
  ['div', '> ', ':has(> :not(.tag,.rn-tag))', true],              // a div with tags and text in spans (a div of tags only is the tag column of a point above)
];
// never: the tally rows (navigation), a page that filters itself, the Settings menu; the generic rules (true above) also skip the tag strips and the legend.
// Left alone as well (no rule above reaches them): a branch of the Map tree (it holds other lines) and the status strip of a whole step (a div of tags
// only, directly under its section: it sums the step up, and the step's own lines carry their tags). test_filter_ui.mjs checks that every other tag is in a line.
const NEVER = ':not(#eq-tally *):not([data-rf-own]):not([data-rf-own] *):not(.settings-pop *)';
const NOT_STRIPS = ':not(.page-tags):not(.page-tags *):not(.glance *):not(.ls-glance *)';
// has(k) / lacks(k): the line carries / does not carry a tag of kind k (scope null: the line is the tag, so it is its own class)
const has = (k, scope) => (scope == null ? `.${k}` : `:has(${scope}${TAG(k)})`);
const lacks = (k, scope) => (scope == null ? `:not(.${k})` : `:not(:has(${scope}${TAG(k)}))`);
const known = scope => has('checked', scope) + has('standard', scope) + lacks('ours', scope) + lacks('open', scope);
const plain = scope => has('standard', scope) + lacks('checked', scope) + lacks('ours', scope) + lacks('open', scope);
const sel = pred => LINES.map(([line, scope, extra = '', generic]) => line + extra + pred(scope) + NEVER + (generic ? NOT_STRIPS : ''));
export const KNOWN_SELECTORS = sel(known), PLAIN_SELECTORS = sel(plain);
export const KNOWN_SELECTOR = KNOWN_SELECTORS.join(','), PLAIN_SELECTOR = PLAIN_SELECTORS.join(',');
export const FILTER_CSS = [
  ...KNOWN_SELECTORS.map(s => `main[data-rf="known"] ${s},main[data-rf="known+std"] ${s}{display:none!important}`),
  ...PLAIN_SELECTORS.map(s => `main[data-rf="known+std"] ${s}{display:none!important}`),
].join('\n');

// ---- counting (read only): the lines a setting hides in a root (default <main>); a line inside another hidden line is not counted again
export function countHidden(root, mode = 'known+std') {
  const out = { known: 0, plain: 0 };
  try {
    const r = root || (typeof document !== 'undefined' ? document.querySelector('main') : null); if (!r || mode === 'off') return out;
    const all = new Set([...r.querySelectorAll(KNOWN_SELECTOR), ...(mode === 'known+std' ? r.querySelectorAll(PLAIN_SELECTOR) : [])]);
    for (const e of all) { let up = e.parentElement, inner = false; for (; up && up !== r; up = up.parentElement) if (all.has(up)) { inner = true; break; } if (inner) continue; if (e.matches(KNOWN_SELECTOR)) out.known++; else out.plain++; }
  } catch { /* a browser without :has() cannot use the filter (supported() is false) */ }
  return out;
}
// what a notice says is hidden under a setting: {known, plain} as countHidden gives it (plain is 0 unless the setting is known+std)
export const hiddenUnder = (mode, c) => (!c || mode === 'off' ? { known: 0, plain: 0 } : mode === 'known' ? { known: c.knownOnly, plain: 0 } : { known: c.known, plain: c.plain });
export const supported = () => { try { return typeof CSS !== 'undefined' && !!CSS.supports && CSS.supports('selector(:has(> p))'); } catch { return false; } };

// ---- state: the setting, its subscribers, the count of hidden lines (one MutationObserver on <main>, shared, while anyone listens)
const hasDoc = typeof document !== 'undefined' && !!document.documentElement;
const store = () => { try { return typeof localStorage !== 'undefined' ? localStorage : null; } catch { return null; } };
let filter = pickFilter(typeof location !== 'undefined' ? location.search : '', store()).filter;
const subs = new Set();
export const getFilter = () => filter;
export function setFilter(v) {
  const x = validFilter(v); if (!x) return;
  filter = x;
  try { const s = store(); if (s) s.setItem(FILTER_KEY, x); } catch { /* storage can be blocked: the setting lasts as long as the page */ }
  subs.forEach(f => { try { f(x); } catch { /* a subscriber's error is its own */ } });
}
export const subscribeFilter = f => { subs.add(f); return () => subs.delete(f); };
const counters = new Set(); let obs = null, timer = null, last = null, watched = null;
// the count delivered to the listeners: {known, plain} with both switches on, and knownOnly with the first switch alone
const recount = () => { timer = null; const m = typeof document !== 'undefined' ? document.querySelector('main') : null; if (m && m !== watched) watch(m); const c = { ...countHidden(m, 'known+std'), knownOnly: countHidden(m, 'known').known }; if (!last || c.known !== last.known || c.plain !== last.plain || c.knownOnly !== last.knownOnly) { last = c; counters.forEach(f => f(c)); } };
const later = () => { if (timer == null) timer = setTimeout(recount, 40); };
function watch(m) { if (obs) obs.disconnect(); watched = m; try { obs = new MutationObserver(later); obs.observe(m, { childList: true, subtree: true }); } catch { obs = null; } }
// cb({known, plain, knownOnly}) now and after every change of the page (elements added or removed); returns the function that stops listening
export function watchHidden(cb) {
  if (!hasDoc) return () => {};
  counters.add(cb); if (last) cb(last); later();
  return () => { counters.delete(cb); if (!counters.size && obs) { obs.disconnect(); obs = null; watched = null; last = null; } };
}
if (hasDoc && !document.getElementById('atlas-reader-filter')) { const st = document.createElement('style'); st.id = 'atlas-reader-filter'; st.textContent = FILTER_CSS; (document.head || document.documentElement).appendChild(st); }

// ---- the words, EN and IT (the Settings group and the notice of a page)
const plural = (n, one, many) => (n === 1 ? one : many);
export const FILTER_COPY = {
  en: {
    label: 'Reader filter', off: 'Show everything', known: 'Hide known ground (standard and checked)', plain: 'Also hide plain citations',
    note: 'Known ground: a line tagged both standard and checked, and neither ours nor open. A plain citation: a line tagged standard only.',
    count: (k, p) => `On this page: ${k} ${plural(k, 'line', 'lines')} of known ground, ${p} ${plural(p, 'plain citation', 'plain citations')}.`,
    notice: (k, p, both) => (both
      ? `${k + p} ${plural(k + p, 'line is', 'lines are')} hidden on this page: ${k} of known ground, ${p} ${plural(p, 'plain citation', 'plain citations')}.`
      : `${k} ${plural(k, 'line', 'lines')} of known ground ${plural(k, 'is', 'are')} hidden on this page.`),
    show: 'Show them',
  },
  it: {
    label: 'Filtro del lettore', off: 'Mostra tutto', known: 'Nascondi il terreno noto (standard e verificato)', plain: 'Nascondi anche le sole citazioni',
    note: 'Terreno noto: una riga con le etichette standard e verificato, e né nostro né aperto. Una sola citazione: una riga con la sola etichetta standard.',
    count: (k, p) => `In questa pagina: ${k} ${plural(k, 'riga', 'righe')} di terreno noto, ${p} ${plural(p, 'sola citazione', 'sole citazioni')}.`,
    notice: (k, p, both) => (both
      ? `${k + p} ${plural(k + p, 'riga è nascosta', 'righe sono nascoste')} in questa pagina: ${k} di terreno noto, ${p} ${plural(p, 'sola citazione', 'sole citazioni')}.`
      : `${k} ${plural(k, 'riga', 'righe')} di terreno noto ${plural(k, 'è nascosta', 'sono nascoste')} in questa pagina.`),
    show: 'Mostrale',
  },
};
