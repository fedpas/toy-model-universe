// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The noise of the stored benchmark run is said wherever its ratios are quoted (re-test T5-2): the step-13 copy (EN and IT), the Map's step-13 node (EN and IT), the chat persona, and the README
// tables. A timing is noisy, by the speed test's own marker, when its spread (slowest - fastest batch) / median is above 15 %. Every count and every largest spread is recomputed here from
// selfcheck/bench_labels.json and must be the one the texts print; none may be typed into a source. Data only (node).   node test_bench_noise.mjs
import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { PKG } from './paths.mjs';

let bad = 0, checks = 0; const ok = (c, m, d = '') => { checks++; if (!c) { bad++; console.log('FAIL  ' + m + (d ? ': ' + d : '')); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8'), imp = f => import(pathToFileURL(path.join(PKG, f)).href);
const RUN = JSON.parse(rd('selfcheck/bench_labels.json'));

// ---- 1. the noise of the run, worked out here
const T = 0.15, sp = t => (t.max - t.min) / t.med;
const of = ts => { const s = ts.filter(Boolean).map(sp); return { n: s.length, noisy: s.filter(v => v > T).length, max: Math.round(100 * Math.max(0, ...s)) }; };
const K = of(RUN.rows.flatMap(r => Object.values(r.ns))), P = of(RUN.product.flatMap(r => Object.values(r.ns))), ALL = of([...RUN.rows, ...RUN.product].flatMap(r => Object.values(r.ns)));
const at = (a, b) => RUN.product.filter(r => r.ns[a] && r.ns[b] && Math.max(sp(r.ns[a]), sp(r.ns[b])) > T).map(r => r.n);
const ROUTE = at('signTable', 'matrixRoute'), REUSE = at('signTableReuse', 'matrixRouteReuse');
const and = (xs, w) => xs.length < 2 ? xs.join('') : xs.slice(0, -1).join(', ') + ' ' + w + ' ' + xs[xs.length - 1];
console.log(`stored run ${RUN.machine.date}: kernel ${K.noisy}/${K.n} noisy (max ${K.max} %), product ${P.noisy}/${P.n} (max ${P.max} %); as written noisy at n = ${ROUTE}, reuse at n = ${REUSE}`);
ok(K.n > 0 && P.n > 0, 'the stored run has kernel and product timings');

// ---- 2. the threshold is the page's own marker
const page = rd('label_bench_src/page.js');
ok(/noisy: spread > 0\.15 \}/.test(page) && /spread above 15%/.test(page), 'the speed test marks a timing noisy above a 15 % spread (the threshold the texts use)');
const RC = await imp('rigidCopy.js');
ok(RC.NOISY === T, 'rigidCopy.js uses the same 15 % threshold');
ok(JSON.stringify(RC.BENCH_NOISE.kernel) === JSON.stringify(K) && JSON.stringify(RC.BENCH_NOISE.product) === JSON.stringify(P) && JSON.stringify(RC.BENCH_NOISE.all) === JSON.stringify(ALL)
  && JSON.stringify(RC.BENCH_NOISE.route) === JSON.stringify(ROUTE) && JSON.stringify(RC.BENCH_NOISE.reuse) === JSON.stringify(REUSE), 'rigidCopy.js BENCH_NOISE equals the noise worked out here', JSON.stringify(RC.BENCH_NOISE));

// ---- 3. the step-13 copy: the frame thread quotes the kernel ratios and the product lists; the caveat follows them, in both languages
const C = RC.default, alg = l => C[l].s.threads.frame.alg;
const fmtList = (xs, l) => xs.map(v => (v >= 10 ? v.toFixed(0) : v.toFixed(2)).replace('.', l === 'it' ? ',' : '.') + '×').join(', ');
const routeList = l => fmtList(RUN.product.map(r => r.ns.signTable.med / r.ns.matrixRoute.med), l);
const WANT = {
  en: { k: K.noisy ? `${K.noisy} of the ${K.n} timings have a spread above 15 % (up to ${K.max} %), so read single values as direction only` : `no timing has a spread above 15 % (the largest is ${K.max} %)`,
    p: P.noisy ? `These lists give the direction only: in this run ${P.noisy} of the ${P.n} product timings have a spread above 15 % (up to ${P.max} %)` + (ROUTE.length ? `; the ratio as written rests on such a timing at n = ${and(ROUTE, 'and')}` : '') + (REUSE.length ? `, the one with buffers allocated once at n = ${and(REUSE, 'and')}` : '') + '. Re-time on an idle machine (sh selfcheck/regen_bench.sh) before relying on the exact figures.'
      : `No product timing of this run has a spread above 15 % (the largest is ${P.max} %).` },
  it: { k: K.noisy ? `${K.noisy} dei ${K.n} tempi hanno una dispersione sopra il 15 % (fino al ${K.max} %), quindi leggi i singoli valori solo come direzione` : `nessun tempo ha una dispersione sopra il 15 % (la più grande è il ${K.max} %)`,
    p: P.noisy ? `Queste liste indicano solo la direzione: in questa serie ${P.noisy} dei ${P.n} tempi del prodotto hanno una dispersione sopra il 15 % (fino al ${P.max} %)` + (ROUTE.length ? `; il rapporto della via così come è scritta poggia su un tempo così a n = ${and(ROUTE, 'e')}` : '') + (REUSE.length ? `, quello con gli array allocati una volta a n = ${and(REUSE, 'e')}` : '') + '. Prima di fidarti delle cifre esatte, rimisura su una macchina scarica (sh selfcheck/regen_bench.sh).'
      : `Nessun tempo del prodotto in questa serie ha una dispersione sopra il 15 % (la più grande è il ${P.max} %).` },
};
for (const l of ['en', 'it']) {
  const t = alg(l), iList = t.indexOf(routeList(l)), iCav = t.indexOf(WANT[l].p);
  ok(t.includes(WANT[l].k), `step 13 (${l}): the kernel timings carry their noise (count and largest spread from the run)`, t.slice(t.indexOf(l === 'en' ? 'median spread' : 'dispersione mediana'), (t.indexOf(l === 'en' ? 'median spread' : 'dispersione mediana') + 200)));
  ok(iList > 0 && iCav > iList, `step 13 (${l}): the product lists (as written: ${routeList(l)}) are followed by their noise caveat`, 'list at ' + iList + ', caveat at ' + iCav);
}

// ---- 4. the Map's step-13 node (EN and IT): the run's noise after the ratios it quotes
const MC = await imp('mapCopy.js');
const mapWant = { en: ALL.noisy ? `A noisy run: ${ALL.noisy} of its ${ALL.n} timings have a spread above 15 % (up to ${ALL.max} %), so these figures give the direction only.` : null,
  it: ALL.noisy ? `Una serie rumorosa: ${ALL.noisy} dei suoi ${ALL.n} tempi hanno una dispersione sopra il 15 % (fino al ${ALL.max} %), quindi queste cifre indicano solo la direzione.` : null };
for (const l of ['en', 'it']) { const t = MC.NODES[l].rigid[1], x8 = (RUN.product.find(r => r.n === 8).ns.signTable.med / RUN.product.find(r => r.n === 8).ns.matrixRoute.med).toFixed(1).replace('.', l === 'it' ? ',' : '.') + '×';
  ok(mapWant[l] ? t.includes(mapWant[l]) && t.indexOf(mapWant[l]) > t.indexOf(x8) : !/spread above 15|dispersione sopra il 15/.test(t), `Map, step 13 (${l}): the ratios it quotes (${x8} at n = 8) are followed by the run's noise`, t.slice(-260)); }

// ---- 5. the chat persona
const PER = await imp('lib/chatPersona.js'), PR = PER.buildSystemPrompt('en');
const perP = P.noisy ? `Noisy run: ${P.noisy} of ${P.n} product timings spread above 15 % (up to ${P.max} %)` + (ROUTE.length ? `, the ratios as written at n=${ROUTE.join(',')} among them` : '') + ': give the lists as direction only; exact figures need a re-timing on an idle machine (sh selfcheck/regen_bench.sh).' : null;
const perList = RUN.product.map(r => { const v = r.ns.signTable.med / r.ns.matrixRoute.med; return (v >= 10 ? v.toFixed(0) : v >= 1 ? v.toFixed(1) : v.toFixed(2)) + '×'; }).join(', ');
ok(perP ? PR.includes(perP) && PR.indexOf(perP) > PR.indexOf(perList) : !/Noisy run:/.test(PR), 'persona: the product lists (as written: ' + perList + ') are followed by the run\'s noise', perP);
ok(PR.includes(`${K.noisy} of the ${K.n} timings above 15 %, up to ${K.max} %)`), 'persona: the kernel benchmark sentence carries the kernel timings\' noise');

// ---- 6. the README tables: a generated noise line under each (selfcheck/bench_tables.mjs), with the run's numbers
const RL = rd('README_label_bench.md'), RP = rd('README_update_pgadyn.md'), blk = (s, n) => (s.match(new RegExp(`<!-- bench_tables:${n} begin -->([\\s\\S]*?)<!-- bench_tables:${n} end -->`)) || ['', ''])[1];
const A = of(RUN.alloc.flatMap(a => [a.ns.plain, a.ns.f64]));
const line = (z, what) => z.noisy ? `${z.noisy} of the ${z.n} ${what} timings of this run, up to ${z.max} %` : `no ${what} timing of this run has a spread above 15 % (the largest is ${z.max} %)`;
ok(blk(RL, 'product').includes(line(P, 'product')) && (!ROUTE.length || blk(RL, 'product').includes(`the ratio as written rests on such a timing at n = ${and(ROUTE, 'and')}`)), 'README_label_bench.md: the product table says how many timings are noisy and where the ratio as written rests on one');
ok(blk(RP, 'kernels').includes(line(K, 'kernel')), 'README_update_pgadyn.md: the kernel table says how many timings are noisy');
ok(blk(RL, 'alloc').includes(line(A, 'allocation')) && blk(RP, 'alloc').includes(line(A, 'allocation')), 'both READMEs: the allocation table says how many timings are noisy');
ok(!P.noisy || /re-time on an idle machine \(`sh selfcheck\/regen_bench\.sh`\) before relying on the exact figures/.test(blk(RL, 'product')), 'README_label_bench.md: the noisy product run says to re-time on an idle machine');

// ---- 7. computed, not typed: no source carries the run's noise figures as text
for (const f of ['rigidCopy.js', 'mapCopy.js', 'lib/chatPersona.js', 'selfcheck/bench_tables.mjs']) {
  const s = rd(f), typed = [`up to ${P.max} %`, `fino al ${P.max} %`, `up to ${K.max} %`, `fino al ${K.max} %`, `${P.noisy} of the ${P.n}`, `${P.noisy} of ${P.n}`, `${K.noisy} of the ${K.n}`, `${ALL.noisy} of its ${ALL.n}`, `${ALL.noisy} dei suoi`].filter(x => s.includes(x));
  ok(typed.length === 0, f + ': the noise figures are read from the run, not typed', typed.join(' | '));
}

console.log(bad ? `${bad} of ${checks} checks failed\nBENCH NOISE FAILED` : `${checks} checks passed\nBENCH NOISE OK`);
process.exit(bad ? 1 : 0);
