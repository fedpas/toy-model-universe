// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The widgets of the Baez chapter (step 19 of the lenses page): BW1 five bits, one generation; BW2 which Standard Model?; BW3 the E8 ladder; BW4 the Kepler
// trio; BW5 seven papers, one map; BW6 the empty ring; BW7 electrons fill in order; and BaezWidgetsScript (the check script). Props { lang, profile }.
// Each root is <div class="ln-card" data-widget="BWn">; the chapter (BaezSection.jsx) places them at its own anchors and decides who sees which.
// "live" = computed now in the browser by baezEngine.js (exact); "stored" = the JSON of selfcheck/reports/lens_baez_check.py (baezWidgetData.js); the badge
// compares the two at render time. Captions are Pts lines with their tags (LensKit.jsx), so the reader filter and the claims table see them.
import React, { useMemo, useState } from 'react';
import * as E from './baezEngine.js';
import D from './baezWidgetData.js';
import { BWC } from './baezWidgetsCopy.js';
import { BZW_PY } from './baezWidgetsSelfcheckSource.js';
import { Pts, ScriptBox } from './LensKit.jsx';
import { Tx } from './MathText.jsx';

const LG = lang => (lang === 'it' ? 'it' : 'en');
const isYL = p => p === 'Young Learner';
const sgn = s => String(s).replace(/^-/, '−');
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const GROUP_COL = ['#60a5fa', '#fbbf24', '#34d399', '#f472b6', '#a78bfa', '#22d3ee'];
const KIND_COL = { '-1': '#60a5fa', 0: '#34d399', 1: '#f87171' };
const MARK = ['①', '②', '③', '④', '⑤'];                                       // the five Casimir classes of BW2: a mark beside the colour
const STYLE = `
.bzw .bzw-read{min-height:2.6em;font-size:.9em;margin:.4em 0}.bzw .bzw-sub{font-size:.85em;opacity:.85;margin:.3em 0}
.bzw button.bzw-dot{width:22px;height:22px;border-radius:50%;border:2px solid currentColor;background:transparent;color:inherit;padding:0;margin:1px;cursor:pointer;opacity:.45;position:relative}
.bzw button.bzw-dot.lit{opacity:1}.bzw button.bzw-dot[aria-pressed=true]::after{content:'';position:absolute;inset:5px;border-radius:50%;background:currentColor}
.bzw button.bzw-dot.sel{outline:2px solid #4aa8ff;outline-offset:1px}
.bzw-grid{display:grid;grid-template-columns:auto repeat(4,minmax(0,1fr));gap:4px;align-items:stretch;font-size:.82em}
.bzw-cell{border:1px solid rgba(128,128,128,.4);border-radius:8px;padding:3px;min-width:0;display:flex;flex-direction:column;gap:2px}.bzw-cell.odd{border-style:dashed}.bzw-cell.lit{background:rgba(128,128,128,.08)}
.bzw-cell .bzw-ch{font-size:.85em;opacity:.8;overflow-wrap:anywhere}.bzw-dots{display:flex;flex-wrap:wrap}
.bzw-hd{opacity:.75;align-self:center;text-align:center;font-size:.9em}
.bzw button:focus-visible,.bzw input:focus-visible,.bzw [role=button]:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.bzw [role=button]:focus-visible circle,.bzw [role=button]:focus-visible rect{stroke:#4aa8ff;stroke-width:3}
.bzw-bar{display:flex;width:100%;min-height:34px;border-radius:6px;overflow:hidden;gap:2px;margin:4px 0}
.bzw-bar button{border:0;color:#0b1020;font:inherit;font-size:.8em;font-weight:600;cursor:pointer;padding:0;min-width:0}.bzw-bar button[aria-pressed=true]{box-shadow:inset 0 0 0 3px currentColor}
.bzw-bar button.h11{background-image:repeating-linear-gradient(45deg,rgba(11,16,32,.55) 0 3px,transparent 3px 7px)}
.bzw-papers{columns:2 13em;font-size:.82em;margin:4px 0;padding-left:1.6em}.bzw-papers li{break-inside:avoid}
.bzw-legend{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:.8em;margin:4px 0}.bzw-legend i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:4px;vertical-align:-2px}
.bzw-ladder{display:flex;flex-direction:column;gap:3px;max-width:420px}.bzw-rung{border:1px solid rgba(128,128,128,.45);border-radius:8px;padding:4px 10px;display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap}
.bzw-step{align-self:center;border:1px solid rgba(128,128,128,.5);border-radius:999px;background:none;color:inherit;font:inherit;font-size:.82em;padding:2px 12px;cursor:pointer}.bzw-step[aria-pressed=true]{background:rgba(80,170,255,.22);border-color:#4aa8ff}
.bzw-pieces{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0}.bzw-piece{border:1px solid rgba(128,128,128,.5);border-radius:6px;padding:2px 8px;font-size:.85em}.bzw-piece.new{border-color:#34d399;border-width:2px}
.bzw-moves{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin:6px 0}.bzw-move{border:1px solid rgba(128,128,128,.45);border-radius:8px;padding:4px 6px;font-size:.82em;text-align:center}
.bzw-rows{display:flex;flex-direction:column;gap:3px;margin:6px 0}.bzw-prow{display:flex;gap:2px;align-items:center}.bzw-prow .bzw-rl{width:3.2em;font-size:.75em;opacity:.75;flex:none}
.bzw-sh{height:22px;border:1px solid rgba(128,128,128,.55);border-radius:4px;position:relative;overflow:hidden;font-size:.7em;display:flex;align-items:center;justify-content:center;min-width:0}
.bzw-sh>i{position:absolute;left:0;top:0;bottom:0;background:rgba(96,165,250,.55)}.bzw-sh>span{position:relative}
.bzw-sl{display:grid;grid-template-columns:minmax(70px,1.2fr) 3fr 5ch;gap:8px;align-items:center;font-size:.85em;margin:4px 0}.bzw-sl input{width:100%;min-width:0}
@media (prefers-reduced-motion:no-preference){.bzw-sh>i,.bzw button.bzw-dot{transition:width .15s,opacity .15s}}
`;
const Card = ({ w, title, children, ...rest }) => <div className="ln-card bzw" data-widget={w} {...rest}><style>{STYLE}</style><h4><Tx>{title}</Tx></h4>{children}</div>;
const Badge = ({ lang, kind }) => <span className="ln-live" data-badge={kind}>{BWC[lang].badge[kind]}</span>;
const Ids = ({ lang, ids }) => <p className="ln-chk"><span className="ln-k">{BWC[lang].checks}</span> {ids.map(c => <code key={c} className="ln-id">{c}</code>)}</p>;
const Prov = ({ text }) => <p className="ln-cap" data-prov><Tx>{text}</Tx></p>;
const Cap = ({ lang, yl, items }) => <div className="bzw-cap" data-voice={yl ? 'yl' : 'formal'}><Pts lang={lang} items={items} /></div>;
const Name = ({ nm }) => (Array.isArray(nm) ? <>{nm[0]}<sub>{nm[1]}</sub></> : <>{nm}</>);

// ================================================================ BW1 five bits, one generation
const groupOf = x => { const y = E.pc(x) % 2 === 0 ? x : E.flipAll(x); return [[0, 0], [0, 2], [1, 1], [1, 3], [2, 0], [2, 2]].findIndex(([a, b]) => a === E.weakOf(y) && b === E.colourOf(y)); };
function pieceName(t, yl, x) {
  const y = E.pc(x) % 2 === 0 ? x : E.flipAll(x), i = E.labelInfo(y), q = E.labelInfo(y).Q, mem = (yl ? t.membersY : t.members)[i.piece + '|' + q];
  if (yl) return mem ? `${t.piecesY[i.piece]} (${mem})` : t.piecesY[i.piece];
  return mem ? [t.pieces[i.piece], mem] : [t.pieces[i.piece]];
}
const nameText = nm => (typeof nm === 'string' ? nm : nm.map(([b, s], k) => (k ? ` (${b}_${s})` : `${b}_${s}`)).join(''));
const NameJsx = ({ nm }) => (typeof nm === 'string' ? <>{nm}</> : <>{nm.map((p, k) => <React.Fragment key={k}>{k ? ' (' : ''}<Name nm={p} />{k ? ')' : ''}</React.Fragment>)}</>);
export function BW1({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), C = BWC[L], t = C.bw1, yl = isYL(profile);
  const [flipped, setFlipped] = useState(false), [sel, setSel] = useState(null), [picks, setPicks] = useState(() => new Set());
  const fam = useMemo(() => E.family(flipped), [flipped]), lit = useMemo(() => new Set(fam), [fam]);
  const classes = useMemo(() => E.classesOf(fam), [fam]), sums = useMemo(() => E.anomalySums(fam), [fam]);
  const check = useMemo(() => { const adn = E.adNDegrees(); return { adn, ok: same(E.LABELS.map(E.labelInfo), D.P1.labels) && same(E.grading(), D.P1.grading) && same(E.anomalySums(E.EVEN), D.P1.sums)
    && same(E.classesOf(E.EVEN).map(c => [c.a, c.b, c.n, c.piece, c.Y, c.Q, c.l1, c.l2, c.labels]), D.P1.classes.map(c => [c.a, c.b, c.n, c.piece, c.Y, c.Q, c.l1, c.l2, c.labels])) && adn.ok && same(adn.counts, D.P1.adN) }; }, []);
  const tap = x => { setSel(x); if (lit.has(x)) setPicks(p => { const n = new Set(p); if (n.has(x)) n.delete(x); else n.add(x); return n; }); };
  const flip = () => { setFlipped(f => !f); setSel(s => (s == null ? s : E.flipAll(s))); setPicks(p => new Set([...p].map(E.flipAll))); };
  const pk = [...picks], psum = E.chargeSum(pk), info = sel == null ? null : { ...E.labelInfo(sel), bits: t.bits(sel) };
  const selName = sel == null ? null : pieceName(t, yl, sel);
  return <Card w="BW1" title={yl ? t.hY : t.h} data-flipped={flipped ? '1' : '0'}>
    <p className="ln-cap"><Tx>{yl ? t.introY : t.intro}</Tx></p>
    <div className="bzw-grid" role="group" aria-label={yl ? t.gridY : t.grid}>
      <span />{[0, 1, 2, 3].map(b => <span key={b} className="bzw-hd">{yl ? `${b} ${t.colHY}` : `b = ${b}`}</span>)}
      {[0, 1, 2].map(a => <React.Fragment key={a}><span className="bzw-hd">{yl ? `${a} ${t.rowHY}` : `a = ${a}`}</span>
        {[0, 1, 2, 3].map(b => { const xs = E.LABELS.filter(x => E.weakOf(x) === a && E.colourOf(x) === b), on = xs.length && lit.has(xs[0]), g = groupOf(xs[0]);
          return <div key={b} className={'bzw-cell' + ((a + b) % 2 ? ' odd' : '') + (on ? ' lit' : '')} data-cell={`${a},${b}`}>
            <span className="bzw-ch">{xs.length}{on ? <> · <NameJsx nm={yl ? t.piecesY[E.labelInfo(flipped ? E.flipAll(xs[0]) : xs[0]).piece] : [t.pieces[E.labelInfo(flipped ? E.flipAll(xs[0]) : xs[0]).piece]]} />{flipped ? '*' : ''}</> : null}</span>
            <span className="bzw-dots">{xs.map(x => <button key={x} type="button" className={'bzw-dot' + (lit.has(x) ? ' lit' : '') + (sel === x ? ' sel' : '')} data-label={x} data-lit={lit.has(x) ? '1' : '0'}
              aria-pressed={picks.has(x)} aria-label={yl ? t.lblY(x, E.pc(x)) : t.lbl(x)} style={{ color: lit.has(x) ? GROUP_COL[g] : undefined }} onClick={() => tap(x)} />)}</span></div>; })}</React.Fragment>)}
    </div>
    <p className="bzw-sub" data-family={flipped ? 'odd' : 'even'}>{yl ? t.familyY(flipped) : t.family(flipped)}{flipped ? ' (*)' : ''}</p>
    <div className="ln-chips"><button type="button" className="ln-btn" data-act="flip" aria-pressed={flipped} onClick={flip}>{yl ? t.flipY : t.flip}</button>
      <button type="button" className="ln-btn" data-act="all" onClick={() => setPicks(new Set(fam))}>{t.all}</button>
      <button type="button" className="ln-btn" data-act="clear" onClick={() => setPicks(new Set())}>{t.clear}</button></div>
    <p className="bzw-read" aria-live="polite" data-read data-label={sel ?? ''} data-y={info ? info.Y : ''} data-q={info ? info.Q : ''}>
      {info ? (yl ? t.readY(info, nameText(selName)) : <Tx>{t.read(info, nameText(selName))}</Tx>) : (yl ? t.noneY : t.none)}</p>
    <p className="bzw-read" aria-live="polite" data-pick data-count={pk.length} data-sum={psum}>{yl ? t.pickY(pk.length, psum) : t.pick(pk.length, psum)}</p>
    {!yl && <div className="ln-wrap"><table className="ln-tab" data-twin="classes"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{classes.map(c => <tr key={c.a + ',' + c.b} data-class={`${c.a},${c.b}`} data-n={c.n} data-y={c.Y} data-q={c.Q.join(' ')}><td>({c.a}, {c.b})</td><td>{c.n}</td><td>{flipped ? <>* <Name nm={t.pieces[E.labelInfo(E.flipAll(c.labels[0])).piece]} /></> : <Name nm={t.pieces[c.piece]} />}</td>
        <td>{sgn(c.Y)}</td><td>{c.Q.map(sgn).join(', ')}</td><td>{c.l1 != null ? `(${c.l1}, ${c.l2})` : '–'}</td></tr>)}</tbody></table></div>}
    {yl && <div className="ln-wrap"><table className="ln-tab" data-twin="classes"><caption className="ln-cap">{C.tableY}</caption><thead><tr>{t.thY.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{classes.map(c => <tr key={c.a + ',' + c.b} data-class={`${c.a},${c.b}`} data-n={c.n} data-q={c.Q.join(' ')}><td>{c.a}, {c.b}</td><td>{c.n}</td><td>{(flipped ? '* ' : '') + t.piecesY[flipped ? E.labelInfo(E.flipAll(c.labels[0])).piece : c.piece]}</td><td>{c.Q.map(sgn).join(', ')}</td></tr>)}</tbody></table></div>}
    {!yl && <div className="ln-wrap"><table className="ln-tab" data-twin="sums"><caption className="ln-cap">{t.sums}</caption><thead><tr><th scope="col" />{t.sumsH.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody><tr data-row="live"><th scope="row">{t.live}</th>{Object.keys(sums).map(k => <td key={k} data-sum-key={k}>{sgn(sums[k])}</td>)}</tr>
        <tr data-row="stored"><th scope="row">{t.stored}</th>{Object.keys(D.P1.sums).map(k => <td key={k} data-sum-key={k}>{sgn(D.P1.sums[k])}</td>)}</tr></tbody></table></div>}
    {!yl && <p className="ln-cap" data-adn>{t.adN(check.adn.counts, check.adn.ok)}</p>}
    <Badge lang={L} kind={check.ok ? 'match' : 'differ'} /><Prov text={yl ? C.prov.liveY : C.prov.live('bzw·P1, baez·H1a–H2d', L === 'it' ? 'tutte le 32 etichette' : 'all 32 labels')} />
    <Cap lang={L} yl={yl} items={yl ? t.capY : t.cap} />{!yl && <Ids lang={L} ids={t.ids} />}
  </Card>;
}

// ================================================================ BW2 which Standard Model? (stored)
export function BW2({ lang = 'en' }) {
  const L = LG(lang), C = BWC[L], t = C.bw2, P = D.P2, [show16, setShow16] = useState(false), [sel, setSel] = useState(null);
  const cols = ['#9ca3af', '#60a5fa', '#a78bfa', '#fbbf24', '#f87171'];
  const rowsData = [P.f4, P.e7];
  const read = sel == null ? t.none : t.read(t.classes[sel[1]], P.f4[sel[1]], P.e7[sel[1]], show16 ? P.e7_16[sel[1]] : null);
  const seg = (r, k, n, part) => <button key={k + (part || '')} type="button" data-row={r} data-class={k} data-n={n} data-part={part || 'all'} className={part === '11' ? 'h11' : undefined}
    aria-pressed={!!sel && sel[0] === r && sel[1] === k} aria-label={`${t.rows[r]}: ${t.classes[k]} ${n}${part ? ' (' + (part === '16' ? t.in16 : t.in11) + ')' : ''}`}
    style={{ flexGrow: n, flexBasis: 0, background: cols[k] }} onClick={() => setSel([r, k])} onFocus={() => setSel([r, k])} onMouseEnter={() => setSel([r, k])}>{n >= 3 ? `${MARK[k]} ${n}` : n >= 2 ? n : ''}</button>;
  return <Card w="BW2" title={t.h} data-show16={show16 ? '1' : '0'}>
    <p className="ln-cap"><Tx>{t.intro}</Tx></p>
    {rowsData.map((row, r) => <div key={r}><p className="bzw-sub"><Tx>{t.rows[r]}</Tx> · 27</p>
      <div className="bzw-bar" role="group" aria-label={t.rows[r]}>{row.map((n, k) => (n === 0 ? null : r === 1 && show16 ? [P.e7_16[k] ? seg(r, k, P.e7_16[k], '16') : null, P.e7_11[k] ? seg(r, k, P.e7_11[k], '11') : null] : seg(r, k, n)))}</div></div>)}
    <div className="bzw-legend">{t.classes.map((c, k) => <span key={c}><i style={{ background: cols[k] }} />{MARK[k]} {c}</span>)}</div>
    <div className="ln-chips"><button type="button" className="ln-chip" data-act="where16" aria-pressed={show16} onClick={() => setShow16(v => !v)}>{t.where16}</button></div>
    {show16 && <p className="ln-cap" data-note16><Tx>{t.note16}</Tx></p>}
    <p className="bzw-read" aria-live="polite" data-read data-class={sel ? sel[1] : ''}><Tx>{read}</Tx></p>
    <div className="ln-wrap"><table className="ln-tab" data-twin="classes"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(h => <th key={h} scope="col"><Tx>{h}</Tx></th>)}</tr></thead>
      <tbody>{t.classes.map((c, k) => <tr key={c} data-class={k}><th scope="row">{MARK[k]} {c}</th><td>({sgn(P.classes[k][0])}, {sgn(P.classes[k][1])})</td><td data-col="f4">{P.f4[k]}</td><td data-col="e7">{P.e7[k]}</td><td data-col="e7_16">{P.e7_16[k]}</td><td data-col="e7_11">{P.e7_11[k]}</td></tr>)}
        <tr data-class="total"><th scope="row">{t.total}</th><td /><td data-col="f4">{P.f4.reduce((a, b) => a + b, 0)}</td><td data-col="e7">{P.e7.reduce((a, b) => a + b, 0)}</td><td data-col="e7_16">{P.e7_16.reduce((a, b) => a + b, 0)}</td><td data-col="e7_11">{P.e7_11.reduce((a, b) => a + b, 0)}</td></tr></tbody></table></div>
    <div className="ln-wrap"><table className="ln-tab" data-twin="stab"><caption className="ln-cap"><Tx>{t.stabH}</Tx></caption><thead><tr>{t.stabTh.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{Object.keys(t.stab).map(k => <tr key={k} data-stab={k}><th scope="row"><Tx>{t.stab[k]}</Tx></th><td>{P.stab[k]}</td></tr>)}</tbody></table></div>
    <Badge lang={L} kind="stored" /><Prov text={C.prov.stored(L === 'it' ? 'lens_baez_check.py (bzw·P2, P2b); il lato del gruppo di gauge è uguale all’output numerico di baez_check.py (baez·S2, O3e)' : 'lens_baez_check.py (bzw·P2, P2b); the gauge-group side equals the numerical output of baez_check.py (baez·S2, O3e)')} />
    <Cap lang={L} yl={false} items={t.cap} /><Ids lang={L} ids={t.ids} />
  </Card>;
}

// ================================================================ BW3 the E8 ladder (roots live, branchings stored)
export function BW3({ lang = 'en' }) {
  const L = LG(lang), C = BWC[L], t = C.bw3, P = D.P3, [step, setStep] = useState(7), [links, setLinks] = useState(false);
  const live = useMemo(() => ({ lad: E.ladder(), links: E.linkChain() }), []);
  const ok = same([live.lad.roots, live.lad.sizes, live.lad.dims, live.lad.g1, live.lad.graded, live.lad.grades8], [P.roots, P.sizes, P.dims, P.g1, P.graded, P.grades8]) && same(live.links, P.links);
  const ns = [8, 7, 6, 5, 4], i = ns.indexOf(step), dec = P.dec[String(step)], prev = P.dec[String(step - 1)] || [];
  const mult = (d, k) => (d.find(x => x.su3 === k.su3 && x.su2 === k.su2) || { m: 0 }).m;
  const rep = k => `(${k.su3 === '3b' ? '3̄' : k.su3},${k.su2})`;
  return <Card w="BW3" title={t.h} data-step={step} data-links={links ? live.links.join(',') : ''}>
    <p className="ln-cap"><Tx>{t.intro}</Tx></p>
    <div className="ln-row"><div className="ln-col"><div className="bzw-ladder" role="group" aria-label={t.h}>
      {t.rungs.map((r, k) => <React.Fragment key={r}><div className="bzw-rung" data-rung={k}><b>{r}</b><span>{live.lad.sizes[k]} {L === 'it' ? 'radici' : 'roots'} · dim {live.lad.dims[k]}</span></div>
        {k < 5 && <button type="button" className="bzw-step" data-step={ns[k]} aria-pressed={step === ns[k]} onClick={() => setStep(ns[k])}>{live.lad.g1[k]} · {live.lad.graded[k]} {L === 'it' ? 'gradi' : 'grades'}{links ? <span data-link-size={live.links[k + 1]}> · {t.nb} {live.links[k + 1]}</span> : null}</button>}</React.Fragment>)}
    </div></div>
    <div className="ln-col"><p className="bzw-read" aria-live="polite" data-read data-g1={live.lad.g1[i]}><Tx>{t.step(t.rungs[i], t.rungs[i + 1], live.lad.g1[i], live.lad.graded[i])}{t.triples[step] ? ` · ${t.triples[step]}` : ''}</Tx></p>
      <p className="bzw-sub"><Tx>{t.pieces}</Tx> <Badge lang={L} kind="stored" /></p>
      {dec ? <div className="bzw-pieces" data-pieces={step}>{dec.map(k => { const nw = k.m - mult(prev, k); return <span key={k.su3 + k.su2} className={'bzw-piece' + (nw > 0 ? ' new' : '')} data-piece={k.su3 + '|' + k.su2} data-m={k.m} data-new={nw}>
        {k.m > 1 ? `${k.m} × ` : ''}{rep(k)} · {k.m * k.dim}{nw > 0 ? ` (+${nw} ${t.new})` : ''}</span>; })}</div> : <p className="ln-cap" data-pieces="none"><Tx>{t.none56}</Tx></p>}
      <div className="ln-chips"><button type="button" className="ln-chip" data-act="links" aria-pressed={links} onClick={() => setLinks(v => !v)}>{t.links}</button></div>
      {links && <p className="ln-cap" data-chain={live.links.join(',')}><Tx>{t.linksH}</Tx>: {live.links.join(' → ')}</p>}</div></div>
    <div className="ln-wrap"><table className="ln-tab" data-twin="ladder"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{t.rungs.map((r, k) => <tr key={r} data-rung={k}><th scope="row">{r}</th><td data-col="live">{live.lad.sizes[k]}</td><td data-col="stored">{P.sizes[k]}</td><td>{live.lad.dims[k]}</td><td>{k < 5 ? live.lad.g1[k] : '–'}</td><td>{k < 5 ? live.lad.graded[k] : '–'}</td></tr>)}</tbody></table></div>
    <Badge lang={L} kind={ok ? 'match' : 'differ'} /><Prov text={C.prov.live('bzw·P3, baez·E1a–c', L === 'it' ? 'le 240 radici; le ramificazioni sono memorizzate (bzw·P3b, baez·S1)' : 'the 240 roots; the branchings are stored (bzw·P3b, baez·S1)')} />
    <Cap lang={L} yl={false} items={t.cap} /><Ids lang={L} ids={t.ids} />
  </Card>;
}

// ================================================================ BW4 the Kepler trio
let KEP = null; const keplerAll = () => KEP || (KEP = Object.fromEntries([1, 0, -1].map(e => [e, E.kepler(e)])));
// the three kinds of move as small drawings (no arrow glyphs in the text): turn = a circle with a dot, slide = a straight track, stretch = a bar pulled at both ends
const MoveIcon = ({ q }) => <svg width="26" height="16" viewBox="0 0 26 16" aria-hidden="true" style={{ display: 'block', margin: '0 auto 2px' }}>
  {q === -1 ? <><circle cx="13" cy="8" r="6" fill="none" stroke="currentColor" strokeWidth="1.8" /><circle cx="19" cy="8" r="2" fill="currentColor" /></>
    : q === 0 ? <><line x1="3" y1="11" x2="23" y2="11" stroke="currentColor" strokeWidth="1.8" /><rect x="9" y="4" width="8" height="5" fill="currentColor" /></>
      : <><line x1="5" y1="8" x2="21" y2="8" stroke="currentColor" strokeWidth="3" /><path d="M1 8L6 4V12Z M25 8L20 4V12Z" fill="currentColor" /></>}</svg>;
export function BW4({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), C = BWC[L], t = C.bw4, yl = isYL(profile), [s, setS] = useState(-3);
  const Ev = s / 10, eps = E.epsOfEnergy(Ev), K = useMemo(keplerAll, []), k = K[eps], orbit = useMemo(() => E.keplerOrbit(Ev), [Ev]);
  const ok = [1, 0, -1].every(e => { const st = D.P4.eps[String(e)]; return same(K[e].killing, st.killing) && same(K[e].squares, st.squares) && K[e].turn === st.turn && K[e].slide === st.slide && K[e].stretch === st.stretch && K[e].brackets; })
    && K[1].halves === true && same(E.shells(), D.P4.shells) && same(E.shellsSpin(), D.P4.shells_spin);
  // fit the drawn arc and the Sun into the box (the scale changes with E: a picture, not a measurement)
  const xs = [0, ...orbit.pts.map(q => q[0])], ys = [0, ...orbit.pts.map(q => q[1])], W = 280, H = 200, pad = 16;
  const sc = Math.min(60, (W - 2 * pad) / Math.max(1e-9, Math.max(...xs) - Math.min(...xs)), (H - 2 * pad) / Math.max(1e-9, Math.max(...ys) - Math.min(...ys)));
  const ox = pad + (W - 2 * pad - (Math.max(...xs) - Math.min(...xs)) * sc) / 2 - Math.min(...xs) * sc, oy = pad + (H - 2 * pad - (Math.max(...ys) - Math.min(...ys)) * sc) / 2 + Math.max(...ys) * sc;
  const path = orbit.pts.map(([x, y], j) => `${j ? 'L' : 'M'}${(ox + x * sc).toFixed(1)} ${(oy - y * sc).toFixed(1)}`).join('');
  const kind = (yl ? t.kindsY : t.kinds)[eps], count = yl ? t.countY(k) : t.count(k);
  return <Card w="BW4" title={yl ? t.hY : t.h} data-eps={eps}>
    <label className="bzw-sl"><span>{yl ? t.energyY : t.energy}</span><input type="range" min={-4} max={4} step={1} value={s} aria-valuetext={yl ? kind : `E = ${sgn(String(Ev))}`} onChange={e => setS(+e.target.value)} /><output>{sgn(Ev.toFixed(1))}</output></label>
    <div className="ln-chips">{[1, 0, -1].map(e => <button key={e} type="button" className="ln-chip" data-preset={e} aria-pressed={eps === e} onClick={() => setS(e === 1 ? -3 : e === 0 ? 0 : 3)}>{(yl ? t.presetsY : t.presets)[e]}</button>)}</div>
    <div className="ln-row"><div className="ln-col"><svg className="ln-svg" viewBox="0 0 280 200" role="img" aria-label={kind} data-orbit-e={orbit.e.toFixed(3)}>
      <rect x="0" y="0" width="280" height="200" fill="none" stroke="currentColor" strokeOpacity=".15" />
      <path d={path} fill="none" stroke={KIND_COL[-eps]} strokeWidth="2.5" strokeDasharray={eps === 0 ? '7 4' : eps === -1 ? '2 4' : undefined} />
      <circle cx={ox} cy={oy} r="7" fill="#fbbf24" /><text x={ox + 10} y={oy - 10} fontSize="11" fill="currentColor">{t.sun}</text></svg>
      <p className="ln-cap"><Tx>{yl ? t.pictureY : t.picture}</Tx></p></div>
    <div className="ln-col"><p className="bzw-read" aria-live="polite" data-read data-eps={eps} data-turn={k.turn} data-slide={k.slide} data-stretch={k.stretch} data-killing={k.killing.join(',')}>
        {yl ? t.readY(kind, count) : <Tx>{t.read(String(Ev), eps, k.killing, t.algs[eps]) + ' · ' + count}</Tx>}</p>
      <div className="bzw-moves" role="list">{k.squares.map((q, j) => <div key={j} role="listitem" className="bzw-move" data-sq={q} style={{ borderColor: KIND_COL[q] }}><MoveIcon q={q} /><Tx>{(yl ? t.moveNamesY : t.moveNames)[j]}</Tx>: {(yl ? t.moveY : t.move)[q]}{yl ? '' : ` (${sgn(String(q))})`}</div>)}</div>
      {!yl && eps === 1 && <p className="ln-cap" data-halves={K[1].halves ? '1' : '0'}><Tx>{t.halves(K[1].halves)}</Tx></p>}</div></div>
    {!yl && <><div className="ln-wrap"><table className="ln-tab" data-twin="kepler"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{[1, 0, -1].map(e => <tr key={e} data-eps={e} className={e === eps ? 'on' : undefined}><td>{sgn(String(e))}</td><td data-col="live">({K[e].killing.join(', ')})</td><td data-col="stored">({D.P4.eps[String(e)].killing.join(', ')})</td><td>{K[e].turn} / {K[e].slide} / {K[e].stretch}</td><td>{t.algs[e]}</td></tr>)}</tbody></table></div>
      <div className="ln-wrap"><table className="ln-tab" data-twin="shells"><caption className="ln-cap">{t.shellsH}</caption><thead><tr>{t.shellsTh.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
        <tbody>{E.shells().map((n2, j) => <tr key={j} data-n={j + 1}><td>{j + 1}</td><td>{n2}</td><td data-col="live">{E.shellsSpin()[j]}</td><td data-col="stored">{D.P4.shells_spin[j]}</td></tr>)}</tbody></table></div></>}
    <Badge lang={L} kind={ok ? 'match' : 'differ'} /><Prov text={yl ? C.prov.liveY : C.prov.live('bzw·P4, baez·K1b', L === 'it' ? 'ε = +1, 0, −1 e n = 1 … 7' : 'ε = +1, 0, −1 and n = 1 … 7')} />
    <Cap lang={L} yl={yl} items={yl ? t.capY : t.cap} />{!yl && <Ids lang={L} ids={t.ids} />}
  </Card>;
}

// ================================================================ BW5 seven papers, one map (stored: Fig. 1 of the report)
const POS = { gauge: [60, 62], jordan: [200, 62], e7: [200, 192], geo: [60, 192], kepler: [352, 62], tri: [352, 192], cospan: [352, 268] };
const DASH = { cites: undefined, computed: undefined, ours: '8 5', open: '2 5' };
const LBL_AT = { f: 0.55, h: 0.3 };                                            // where the letter of a line sits along it (default: the middle)
export function BW5({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), C = BWC[L], t = C.bw5, yl = isYL(profile), [sel, setSel] = useState(null);
  const names = yl ? t.papersY : t.papers, kinds = yl ? t.kindsY : t.kinds, items = sel ? (yl ? t.edgesY : t.edges)[sel] : null;
  const num = p => String(E.PAPERS.indexOf(p) + 1), key = id => e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setSel(id); } };
  return <Card w="BW5" title={yl ? t.hY : t.h} data-sel={sel || ''}>
    <p className="ln-cap"><Tx>{yl ? t.introY : t.intro}</Tx></p>
    <svg className="ln-svg" viewBox="0 0 420 300" role="group" aria-label={yl ? t.hY : t.h}>
      <defs><marker id="bzw-arr" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="currentColor" /></marker></defs>
      <rect x="18" y="24" width="228" height="206" rx="12" fill="rgba(128,128,128,.07)" stroke="currentColor" strokeOpacity=".35" strokeDasharray="3 3" />
      <text x="24" y="246" fontSize="11" fill="currentColor" opacity=".75">{yl ? t.clusterY : t.cluster}</text>
      {E.EDGES.map(e => { const [x1, y1] = POS[e.from], [x2, y2] = POS[e.to], dx = x2 - x1, dy = y2 - y1, d = Math.hypot(dx, dy), ux = dx / d, uy = dy / d, r = 17;
        const at = LBL_AT[e.id] ?? 0.5, mx = x1 + dx * at, my = y1 + dy * at, on = sel === e.id;
        return <g key={e.id} role="button" tabIndex={0} aria-pressed={on} aria-label={`${t.line(e.id)}: ${names[e.from]} – ${names[e.to]}, ${kinds[e.kind]}`} data-edge={e.id} data-kind={e.kind} onClick={() => setSel(e.id)} onKeyDown={key(e.id)} style={{ cursor: 'pointer' }}>
          <line x1={x1 + ux * r} y1={y1 + uy * r} x2={x2 - ux * r} y2={y2 - uy * r} stroke="currentColor" strokeOpacity={on ? 1 : .7} strokeWidth={on ? 3.5 : e.kind === 'computed' ? 2.6 : 1.8} strokeDasharray={DASH[e.kind]} markerEnd={e.kind === 'cites' ? 'url(#bzw-arr)' : undefined} />
          <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="transparent" strokeWidth="14" />
          <circle cx={mx} cy={my} r="10" fill={on ? '#4aa8ff' : 'var(--bg,#0b1020)'} stroke="currentColor" strokeWidth="1.5" /><text x={mx} y={my + 4} textAnchor="middle" fontSize="12" fill="currentColor" fontWeight="600">{e.id}</text></g>; })}
      {E.PAPERS.map(p => <g key={p} data-paper={p}><circle cx={POS[p][0]} cy={POS[p][1]} r="16" fill="rgba(128,128,128,.25)" stroke="currentColor" /><text x={POS[p][0]} y={POS[p][1] + 5} textAnchor="middle" fontSize="14" fontWeight="700" fill="currentColor">{num(p)}</text></g>)}
    </svg>
    <ol className="bzw-papers">{E.PAPERS.map(p => <li key={p} data-paper={p}><Tx>{yl ? names[p].replace(/^\d+ /, '') : names[p]}</Tx></li>)}</ol>
    <div className="bzw-legend" data-legend>{Object.keys(kinds).map(k => <span key={k}><svg width="34" height="10" aria-hidden="true"><line x1="1" y1="5" x2="31" y2="5" stroke="currentColor" strokeWidth="2" strokeDasharray={DASH[k]} markerEnd={k === 'cites' ? 'url(#bzw-arr)' : undefined} /></svg>{kinds[k]}</span>)}</div>
    <div className="ln-chips" role="group" aria-label={yl ? t.hY : t.h}>{E.EDGES.map(e => <button key={e.id} type="button" className="ln-chip" data-edge={e.id} aria-pressed={sel === e.id} onClick={() => setSel(e.id)}>{t.line(e.id)}</button>)}</div>
    <div className="bzw-read" aria-live="polite" data-read data-edge={sel || ''}>{items ? <><p className="bzw-sub">{t.line(sel)}: <Tx>{names[E.EDGES.find(e => e.id === sel).from]}</Tx> – <Tx>{names[E.EDGES.find(e => e.id === sel).to]}</Tx></p><Pts lang={L} items={items} /></> : <p className="bzw-sub">{yl ? t.noneY : t.none}</p>}</div>
    {!yl && <div className="ln-wrap"><table className="ln-tab" data-twin="edges"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
      <tbody>{E.EDGES.map(e => <tr key={e.id} data-edge={e.id}><td>{e.id}</td><td><Tx>{names[e.from]}</Tx></td><td><Tx>{names[e.to]}</Tx></td><td>{kinds[e.kind]}</td><td>{e.checks.map(c => <code key={c} className="ln-id">{c}</code>)}</td></tr>)}</tbody></table></div>}
    <Badge lang={L} kind="stored" /><Prov text={yl ? C.prov.storedY : C.prov.stored(L === 'it' ? 'la Fig. 1 del rapporto (letta dai sette articoli; non calcolata)' : 'Fig. 1 of the report (read from the seven papers; not computed)')} />
    <Cap lang={L} yl={yl} items={yl ? t.capY : t.cap} />{!yl && <Ids lang={L} ids={t.ids} />}
  </Card>;
}

// ================================================================ BW6 the empty ring
export function BW6({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), C = BWC[L], t = C.bw6, yl = isYL(profile), [ring, setRing] = useState(2);
  const live = useMemo(() => ({ rings: E.eisensteinRings(), pts: E.eisensteinPoints(), shd: E.shadows() }), []);
  const ok = same(live.rings, D.P5.rings) && same(live.shd.points, D.P5.points) && same(Object.fromEntries(Object.keys(live.shd.byRing).map(k => [k, live.shd.byRing[k]])), D.P5.shadows);
  const u = 30, cx = 150, cy = 150, h = Math.sqrt(3) / 2, P = (x, y) => [cx + (x - y / 2) * u, cy - y * h * u];
  const shN = N => live.shd.byRing[N] || 0, stN = N => D.P5.shadows[String(N)] || 0;
  return <Card w="BW6" title={yl ? t.hY : t.h} data-ring={ring}>
    <p className="ln-cap"><Tx>{yl ? t.introY : t.intro}</Tx></p>
    <div className="ln-row"><div className="ln-col"><svg className="ln-svg" viewBox="0 0 300 300" role="img" aria-label={yl ? t.hY : t.h} style={{ maxWidth: 360 }}>
      {[1, 2, 3, 4, 5, 6, 7].map(N => <circle key={N} cx={cx} cy={cy} r={Math.sqrt(N) * u} fill="none" stroke={N === ring ? '#4aa8ff' : 'currentColor'} strokeOpacity={N === ring ? 1 : live.rings[N] ? .3 : .55} strokeWidth={N === ring ? 2.5 : 1} strokeDasharray={live.rings[N] ? undefined : '4 4'} />)}
      {live.pts.map(({ x, y, N }) => { const [X, Y] = P(x, y); return <circle key={x + ',' + y} cx={X} cy={Y} r={N === ring ? 3.6 : 2.4} fill="currentColor" opacity={N === ring ? 1 : .55} />; })}
      {live.shd.points.map(({ a, b, n }) => { const [X, Y] = P(a, -b); return <circle key={'s' + a + ',' + b} cx={X} cy={Y} r={2.6 * Math.sqrt(n)} fill="#f472b6" fillOpacity=".38" stroke="#f472b6" />; })}
      <text x={cx + Math.sqrt(2) * u * .72} y={cy - Math.sqrt(2) * u * .72 - 4} fontSize="11" fill="currentColor">2</text></svg></div>
    <div className="ln-col"><div className="ln-chips" role="group" aria-label={yl ? t.hY : t.h}>{[0, 1, 2, 3, 4, 5, 6, 7].map(N => <button key={N} type="button" className="ln-chip" data-ring={N} aria-pressed={ring === N} onClick={() => setRing(N)}>{t.ring(N)}</button>)}</div>
      <p className="bzw-read" aria-live="polite" data-read data-points={live.rings[ring]} data-shadows={shN(ring)}>{(yl ? t.readY : t.read)(ring, live.rings[ring], shN(ring))}</p>
      {!yl && <div className="ln-wrap"><table className="ln-tab" data-twin="rings"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(x => <th key={x} scope="col">{x}</th>)}</tr></thead>
        <tbody>{live.rings.map((n, N) => <tr key={N} data-ring={N}><td>{N}</td><td data-col="live">{n}</td><td data-col="stored">{D.P5.rings[N]}</td><td data-col="slive">{shN(N)}</td><td data-col="sstored">{stN(N)}</td></tr>)}</tbody></table></div>}</div></div>
    <Badge lang={L} kind={ok ? 'match' : 'differ'} /><Prov text={yl ? C.prov.liveY : C.prov.live('bzw·P5, baez·T1a, T1b', L === 'it' ? 'N = 0 … 7 e le 126 radici di E7' : 'N = 0 … 7 and the 126 roots of E7')} />
    <Cap lang={L} yl={yl} items={yl ? t.capY : t.cap} />{!yl && <Ids lang={L} ids={t.ids} />}
  </Card>;
}

// ================================================================ BW7 electrons fill in order
export function BW7({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), C = BWC[L], t = C.bw7, yl = isYL(profile), [N, setN] = useState(36);
  const m = useMemo(() => E.madelung(), []), f = { ...E.fillTo(N), N };
  const ok = same(m, D.P5.madelung);
  const rows = m.closings.map((c, r) => { const lo = r ? m.closings[r - 1] : 0; return m.sub.map((s, i) => ({ s, i, before: i ? m.cum[i - 1] : 0, cap: m.cum[i] - (i ? m.cum[i - 1] : 0) })).filter(x => x.before >= lo && m.cum[x.i] <= c); });
  return <Card w="BW7" title={yl ? t.hY : t.h} data-n={N}>
    <label className="bzw-sl"><span>{yl ? t.sliderY : t.slider}</span><input type="range" min={1} max={118} step={1} value={N} onChange={e => setN(+e.target.value)} /><output>{N}</output></label>
    <div className="bzw-rows" role="img" aria-label={yl ? t.readY(f) : t.read(f)}>{rows.map((row, r) => <div key={r} className="bzw-prow" data-row={r + 1}><span className="bzw-rl">{t.row(r + 1)}</span>
      {row.map(x => { const fill = Math.max(0, Math.min(x.cap, N - x.before)); return <div key={x.i} className="bzw-sh" data-sub={x.s.join(',')} data-fill={fill} style={{ flex: `${x.cap} 1 0` }}><i style={{ width: `${100 * fill / x.cap}%` }} /><span>{yl ? '' : x.s[0] + E.SUBSHELL(x.s[1])}</span></div>; })}
      <span className="bzw-rl" style={{ textAlign: 'right' }}>{m.closings[r]}</span></div>)}</div>
    <p className="bzw-read" aria-live="polite" data-read data-row={f.row} data-closes={f.closesAt} data-name={f.name} data-closed={f.closed ? '1' : '0'}>{yl ? t.readY(f) : t.read(f)}</p>
    {!yl && <div className="ln-wrap"><table className="ln-tab" data-twin="rows"><caption className="ln-cap">{C.table}</caption><thead><tr>{t.th.map(x => <th key={x} scope="col">{x}</th>)}</tr></thead>
      <tbody>{rows.map((row, r) => <tr key={r} data-row={r + 1}><td>{r + 1}</td><td>{row.map(x => x.s[0] + E.SUBSHELL(x.s[1])).join(' ')}</td><td data-col="live">{m.closings[r]}</td><td data-col="stored">{D.P5.madelung.closings[r]}</td><td>{m.periods[r]}</td></tr>)}</tbody></table></div>}
    <Badge lang={L} kind={ok ? 'match' : 'differ'} /><Prov text={yl ? C.prov.liveY : C.prov.live('bzw·P5, baez·K3', L === 'it' ? 'N = 1 … 118' : 'N = 1 … 118')} />
    <Cap lang={L} yl={yl} items={yl ? t.capY : t.cap} />{!yl && <Ids lang={L} ids={t.ids} />}
  </Card>;
}

// ================================================================ the check script
export function BaezWidgetsScript({ lang = 'en', profile = 'Physicist' }) {
  const L = LG(lang), s = BWC[L].script;
  return <div className="ln-card bzw" data-widget="BaezWidgetsScript"><ScriptBox lang={L} file="selfcheck/reports/lens_baez_check.py" text={BZW_PY} note={isYL(profile) ? s.noteY : s.note} /></div>;
}
