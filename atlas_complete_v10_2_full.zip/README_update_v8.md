# Update v8 (since v7)

Three things, each with its own note. Nothing else in v7 changed except the test counts that depended on the number of steps.

| What | Where | Note |
|---|---|---|
| **Step 14: null surfaces** (new Equations page, Map node, EN/IT, three audiences) | `NullSection.jsx`, `NullWidgets.jsx`, `nullEngine.js`, `nullData.js`, `nullCopy.js`, `nullSelfcheckSource.js`, `selfcheck/null_selfcheck.py`, `selfcheck/null.json`, `test_null.mjs`, `test_null_ui.mjs`; `steps.js`, `EquationsSection.jsx`, `equationsCopy.js`, `audienceCopy.js`, `mapData.js`, `mapCopy.js`, `build.sh` | `README_update_null.md` |
| **The two chat routes** ("fix the routes") | `api/chat.js`, `api/chat-openai.js`, `lib/chatGuard.js`, the error handling in `App.jsx` (`readStream`), `test_routes.mjs` (88 checks), `test_chat_ui.mjs` | `README_update_routes.md`. **Decision for you:** the token caps (8192 Claude, 16384 o3) are my defaults; a long answer can now be cut off without a notice. There is still no authentication: set a spend limit at both providers. |
| **Speed test 1.2.0** (`label_bench.html`) | `label_bench.html`, `label_bench_src/*`, `build_label_bench.mjs`, `test_label_bench.mjs` (188 checks at v8; correction, 2026-10-05: the test prints its own count, which has grown since), `README_label_bench.md` | A clearer page: what is ours and what is standard, an "At a glance" table with the best result of the run and where ours loses, folded details. No timed code changed (same kernel fingerprint). |

## Tests (all pass at this version)
46 test files: 28 data suites (`node test_*.mjs` without `_ui`; `test_label_bench.mjs` and `test_routes.mjs` among them) and 18 browser suites (`*_ui.mjs`, with `test_chat_ui.mjs` run as `ATLAS_DIST=<dist folder> node test_chat_ui.mjs`). The browser suites need the build harness at `/home/claude/ui` (paths as in v7); they were run on a harness build with stubbed KaTeX and streamdown and without your global stylesheet. `test_null_ui.mjs` and `test_chat_ui.mjs` both read the build from `<ATLAS_DIST>/app.html`, the other browser suites keep their fixed `/home/claude/ui/dist` path. *Correction, 2026-10-04 (audit L7-002, L7-003): the paths of the author's machine named in this paragraph (`/home/claude/ui`) and `build.sh`'s file list are gone in v9; the build and the tests are package-relative, and eleven of the "28 data suites" are not node-only (see `BUILDING.md`).* The counts that used to be typed into ~17 tests (number of steps, tally rows, nav buttons, script counts) are now derived from `steps.js` and `mapData.js`, so the next step does not break them.

## Not done / open
- The chat persona does not know step 14 (not patched, as agreed).
  *Correction, 2026-10-04 (audit L6-005, v9):* the persona now knows step 14: the step list and counts are generated from `steps.js`, and a null-surfaces paragraph says only what the page says. See `README_update_routes.md`, section "v9 changes".
- Roll-in: this package has not been applied to `out/`; copy it over, run `build.sh`, then `selfcheck/regen_null.sh` is only needed if `null_selfcheck.py` changes.
- Everything open in `README_update_v7.md` and `README_update_null.md` stays open.
