// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import S from './shapesData.js';

// Copy for the shapes page (English and Italian). Kept apart from the component so the tests can read it.
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
const sup = n => String(n).split('').map(c => SUP[+c]).join('');
const pow2 = n => `2${sup(n)}`;
const COPY = {
  en: {
    o: {
      title: 'The orthoplex: every axis gets two poles',
      lede: 'Put a point on each side of the origin on every one of n axes. Their hull is the n-orthoplex. A face is a choice of axes with a pole for each, so it is a signed blade. It is the cube turned inside out: every face of one matches a face of the other, with the sizes swapped.',
      pick: 'Dimension n', tableH: 'The ladder, one step at a time', cols: ['n', 'shape', 'vertices', 'edges', 'facets', 'all faces (with the empty one)', 'Genesis node', 'algebra for n modes'],
      note: 'The budget of 8 is used up at n = 4 (node 8). Past it, Cl(n+4,n+4) = Cl(n,n) ⊗ M₁₆(ℝ): the same cells again, sixteen times bigger. A dash means the count is not defined for that dimension.',
      shapes: ['point', 'segment', 'square', 'octahedron', '16-cell', '5-orthoplex', '6-orthoplex', '7-orthoplex', '8-orthoplex'],
      picH: 'The 2D trick: the Petrie polygon',
      pic: n => n < 2 ? 'Too small to draw as a polygon: a point, then a segment with its two poles.' : `${2 * n} poles on a circle, antipodes opposite, and every pair joined except the antipodes: ${2 * n * (n - 1)} edges. This works for every n. The ${pow2(n)} facets are not drawn.`,
      points: [
        [['standard', 'checked'], 'Dual of the cube. The 2ⁿ facets match the 2ⁿ corners of the cube, which are our blades, and a face with m vertices matches a cube face of dimension n − m. Checked for every face up to n = 5.'],
        [['standard', 'checked', 'ours'], 'Fock reading. n modes are 2n null vectors forming n Witt pairs of Cl(n,n), which is Genesis node 2n with Cl(n,n) = M₂ⁿ(ℝ). A face is a set of constraints “this mode is empty” or “this mode is full”, and the matching cube face is the set of states that solve them. The count is checked; reading it as Genesis is ours.'],
        [['ours'], 'Equations. First-order spinor equations fit, with real Weyl halves (the even and odd facets) in split signature. Lattice stencils fit too: the faces are the neighbours of a cell of the integer lattice, and faces with equally many time and space poles are light-like steps. The second-order wave equation appears only after squaring.'],
        [['standard', 'checked'], 'n = 4. The 24 unit quaternions are three 16-cells (the poles, the even facets, the odd facets), with Q₈ of index 3. It is the same 8 seen three ways, so nothing is new. The poles equal half the facets only at n = 4.'],
        [['standard', 'checked'], 'n = 5. The 32 facets split 16 + 16 by parity; the even 16 have grades 1 + 10 + 5, and the 40 edges are the roots of so(10). In Cl(5,5) = M₃₂(ℝ) the bivectors span the split real form so(5,5) and the even 16 is its real half-spin space; the compact algebra of the Standard Model sits in another real form with the same weights, the compact so(10). This is the standard SU(5) ⊂ Spin(10) picture of one generation: 16 = 1 + 10 + 5̄, the even part of Λℂ⁵, with Y = a/2 − b/3 and B − L = 1 − 2b/3 as bit counts (a ones among the two weak bits, b among the three colour bits; Baez–Bokor–Boyle; checked).'],
        [['ours', 'open'], 'n = 5, reading. The orthoplex language (facets as particles) and that this 16 is the generation of our model are ours; the second is open.'],
        [['standard', 'checked'], 'n = 8. The 112 edges and the 128 even facets make the 240 roots of E8. The roots of E6, E7 and E8 split into orthoplex edges, facets and a few extras, and the finite series stops at E8 (step 3 rebuilds this exactly). No claim about our model.']
      ]
    },
    d: {
      title: 'The demicube: the even half of the cube',
      lede: 'Keep every second corner of the n-cube: the corners with an even number of 1s. In our dictionary these are exactly the even blades: the scalar, the bivectors, the 4-vectors and so on. The other corners are the odd blades, and the two halves together are the cube. Every cube edge changes the parity, so no edge joins a half to itself.',
      pick: 'Dimension n', tableH: 'The demicubes', cols: ['n', 'shape', 'vertices', 'edges', 'facets', 'faces of each dimension'],
      facets: 'Facets: 2n smaller demicubes (one on each cube facet) plus 2ⁿ⁻¹ simplices, one cutting off each odd corner. At n = 3 only the four simplices remain. Every face count was also found by building the face lattice by brute force.',
      xref: 'The same shape in the views we already have', legend: 'Colour = blade grade. Hollow grey = odd blades.',
      cube: { h: 'Cube view', t: n => `The ${pow2(n)} corners are the blades. ${pow2(n - 1)} are even (filled, coloured by grade) and ${pow2(n - 1)} odd (hollow). Lines join even corners that differ in two bits. The picture is the same 2D trick as the orthoplex: n directions equally spaced in a half turn, one per axis.` },
      cliff: { h: 'Clifford view', t: n => `Even blades multiply among themselves, so they form the even subalgebra, and it equals the algebra of one generator fewer: Cl⁰(p,q) = Cl(p,q−1) for q ≥ 1 (Cl(q,p−1) for p ≥ 1). We rebuilt it from explicit generators for every signature up to n = 8. For n = ${n}: the even half of node ${n} is the whole algebra of node ${n - 1}.`, cols: ['time + space', 'whole algebra', 'even half'], note: 'At n = 8 the balanced cell Cl(4,4) = M₁₆(ℝ) has even half M₈(ℝ) ⊕ M₈(ℝ), which is the whole algebra of Cl(4,3): two identical halves, the “mirror gate” of Genesis node 7.' },
      simp: { h: 'Simplex view', t: n => `Every odd corner has exactly n even neighbours, and they form a simplex with n vertices: the corner it cuts off. It is the same complete graph as in the Simplex view. Choose the grade of the odd blade; the filled vertices are bivectors.`, pick: 'Grade of the odd blade' },
      lab: { h: 'Labels (Prime view)', t: n => n <= 5 ? `Integer labels of the even blades for n = ${n}: ${S.demicube.rows[n].even_labels.join(', ')}.` : 'The even labels are the integers below 2ⁿ with an even number of 1s in binary.', note: ' Labels are notation only, as everywhere else.' },
      mx: {
        h: 'Maxwell (Test 1)', t: n => `The field F is a bivector, so it sits on the even half. The current J and the equations are odd. The operator ∇ flips parity, so ∇F = J maps the even half to the odd half. Rebuilt from the bit rule for n = ${n}: ${S.demicube.maxwell[n].incidences} incidences; each vector equation uses ${S.demicube.maxwell[n].vector_equation_terms} field components and each trivector equation uses 3, all inside the corner simplex of its odd blade. Two field components share an equation exactly when they share an index, which is exactly an edge of the demicube between two bivectors, and then they share two equations (one vector, one trivector).`,
        pick: 'Time axes k', note: 'Left: field components (bivectors). Right: odd blades, the vector equations then the trivector equations. Green: contraction. Red: wedge. Click an odd blade to isolate its equation.', cap7: 'The Maxwell cells in the atlas stop at 7 generators, so this picture shows n = 7.', E: 'E', B: 'B', T: 'T', terms: n => `terms in this equation: ${n}`
      },
      orth: { h: 'Orthoplex (step 1)', t: 'n = 3: the demicube is the tetrahedron, the simplex. n = 4: it is the 16-cell, one of the three 16-cells of step 1 (the even facets of the 4-orthoplex). n = 5: its 16 vertices are the even facets of the 5-orthoplex, grades 1 + 10 + 5. n = 8: its 128 vertices plus the 112 edges of the 8-orthoplex are the 240 roots of E8: step 3 builds on this.' },
      fur: { h: 'Furey (Test 2)', t: 'Dropping the last bit turns the vertices of the n-demicube into the vertices of the (n−1)-cube, and this respects the XOR rule: even blades of n generators are all blades of n−1 generators. At n = 5 that is the tesseract. In the explicit 16-dimensional model the 16 Witt axes are the vertices of a tesseract, with the Peirce blocks H and C + e₇R + R as square faces and O₁ + O₂ as a cube. One generation also has 16 complex dimensions. The bijection and the axes are checked, the equal count is not an identification. Whether they are one thing is open, and the family test found that no shape here gives a 3.' },
      limits: 'What this does not show: nothing on this page is a physical claim beyond the Maxwell and Furey tests it points to.',
      dlH: 'Check it yourself', dlText: 'One self-contained Python file (standard library only). It rebuilds every number on this page, including the brute-force face lattices.', dlPy: 'Download shapes_selfcheck.py', dlJson: 'Download shapes.json', dlCmd: 'python3 shapes_selfcheck.py --compare shapes.json'
    }
  },
  it: {
    o: {
      title: 'L’ortoplesso: ogni asse ha due poli',
      lede: 'Metti un punto da una parte e dall’altra dell’origine su ciascuno di n assi. Il loro guscio convesso è l’n-ortoplesso. Una faccia è una scelta di assi con un polo per ciascuno, quindi è una lama con segno. È il cubo rovesciato: a ogni faccia dell’uno corrisponde una faccia dell’altro, con le dimensioni scambiate.',
      pick: 'Dimensione n', tableH: 'La scala, un passo alla volta', cols: ['n', 'forma', 'vertici', 'spigoli', 'sfaccettature', 'tutte le facce (con quella vuota)', 'nodo Genesis', 'algebra per n modi'],
      note: 'Il budget di 8 si esaurisce a n = 4 (nodo 8). Oltre, Cl(n+4,n+4) = Cl(n,n) ⊗ M₁₆(ℝ): le stesse celle di nuovo, sedici volte più grandi. Un trattino significa che il conteggio non è definito per quella dimensione.',
      shapes: ['punto', 'segmento', 'quadrato', 'ottaedro', '16-celle', '5-ortoplesso', '6-ortoplesso', '7-ortoplesso', '8-ortoplesso'],
      picH: 'Il trucco in 2D: il poligono di Petrie',
      pic: n => n < 2 ? 'Troppo piccolo per un poligono: un punto, poi un segmento con i suoi due poli.' : `${2 * n} poli su una circonferenza, i poli opposti sono antipodi e ogni coppia è unita tranne gli antipodi: ${2 * n * (n - 1)} spigoli. Funziona per ogni n. Le ${pow2(n)} sfaccettature non sono disegnate.`,
      points: [
        [['standard', 'checked'], 'Duale del cubo. Le sfaccettature sono tante quanti i vertici del cubo, cioè le nostre lame, e una faccia con m vertici corrisponde a una faccia del cubo di dimensione n − m. Verificato per ogni faccia fino a n = 5.'],
        [['standard', 'checked', 'ours'], 'Lettura di Fock. n modi sono 2n vettori nulli che formano n coppie di Witt di Cl(n,n), cioè il nodo Genesis 2n con Cl(n,n) = M₂ⁿ(ℝ). Una faccia è un insieme di vincoli “questo modo è vuoto” o “questo modo è pieno”, e la faccia del cubo corrispondente è l’insieme degli stati che li risolvono. Il conteggio è verificato; leggerlo come Genesis è nostro.'],
        [['ours'], 'Equazioni. Le equazioni spinoriali del primo ordine ci stanno, con metà di Weyl reali (le sfaccettature pari e dispari) in segnatura split. Ci stanno anche gli stencil di reticolo: le facce sono i vicini di una cella del reticolo intero, e le facce con tanti poli di tempo quanti di spazio sono passi di tipo luce. L’equazione d’onda del secondo ordine compare solo elevando al quadrato.'],
        [['standard', 'checked'], 'n = 4. I 24 quaternioni unitari sono tre 16-celle (i poli, le sfaccettature pari, quelle dispari), con Q₈ di indice 3. Sono gli stessi 8 visti in tre modi, quindi nulla di nuovo. I poli sono metà delle sfaccettature solo a n = 4.'],
        [['standard', 'checked'], 'n = 5. Le 32 sfaccettature si dividono 16 + 16 per parità; i 16 pari hanno gradi 1 + 10 + 5, e i 40 spigoli sono le radici di so(10). In Cl(5,5) = M₃₂(ℝ) i bivettori generano la forma reale split so(5,5) e il 16 pari è il suo spazio reale di semispinori; l’algebra compatta del Modello Standard sta in un’altra forma reale con gli stessi pesi, la so(10) compatta. È il quadro standard SU(5) ⊂ Spin(10) di una generazione: 16 = 1 + 10 + 5̄, la parte pari di Λℂ⁵, con Y = a/2 − b/3 e B − L = 1 − 2b/3 come conteggi di bit (a cifre 1 tra i due bit deboli, b tra i tre bit di colore; Baez–Bokor–Boyle; verificato).'],
        [['ours', 'open'], 'n = 5, lettura. Il linguaggio dell’ortoplesso (sfaccettature come particelle) e che questo 16 sia la generazione del nostro modello sono nostri; il secondo punto è aperto.'],
        [['standard', 'checked'], 'n = 8. I 112 spigoli e le 128 sfaccettature pari formano le 240 radici di E8. Le radici di E6, E7 ed E8 si dividono in spigoli dell’ortoplesso, sfaccettature e pochi extra, e la serie finita si ferma a E8 (il passo 3 lo ricostruisce con esattezza). Nessuna affermazione sul nostro modello.']
      ]
    },
    d: {
      title: 'Il demicubo: la metà pari del cubo',
      lede: 'Tieni un vertice su due dell’n-cubo: quelli con un numero pari di 1. Nel nostro dizionario sono esattamente le lame pari: lo scalare, i bivettori, i 4-vettori e così via. Gli altri vertici sono le lame dispari, e le due metà insieme sono il cubo. Ogni spigolo del cubo cambia la parità, quindi nessuno spigolo unisce una metà a sé stessa.',
      pick: 'Dimensione n', tableH: 'I demicubi', cols: ['n', 'forma', 'vertici', 'spigoli', 'sfaccettature', 'facce di ogni dimensione'],
      facets: 'Sfaccettature: 2n demicubi più piccoli (uno su ogni sfaccettatura del cubo) più 2ⁿ⁻¹ simplessi, uno per ogni vertice dispari tagliato via. A n = 3 restano solo i quattro simplessi. Ogni conteggio è stato ritrovato anche costruendo il reticolo delle facce a forza bruta.',
      xref: 'La stessa forma nelle viste che già abbiamo', legend: 'Colore = grado della lama. Grigio vuoto = lame dispari.',
      cube: { h: 'Vista cubo', t: n => `I ${pow2(n)} vertici sono le lame. ${pow2(n - 1)} sono pari (pieni, colorati per grado) e ${pow2(n - 1)} dispari (vuoti). Le linee uniscono vertici pari che differiscono in due bit. Il disegno usa lo stesso trucco 2D dell’ortoplesso: n direzioni equispaziate in mezzo giro, una per asse.` },
      cliff: { h: 'Vista Clifford', t: n => `Le lame pari si moltiplicano tra loro, quindi formano la sottoalgebra pari, e coincide con l’algebra di un generatore in meno: Cl⁰(p,q) = Cl(p,q−1) per q ≥ 1 (Cl(q,p−1) per p ≥ 1). L’abbiamo ricostruita da generatori espliciti per ogni segnatura fino a n = 8. Per n = ${n}: la metà pari del nodo ${n} è l’intera algebra del nodo ${n - 1}.`, cols: ['tempo + spazio', 'algebra intera', 'metà pari'], note: 'A n = 8 la cella bilanciata Cl(4,4) = M₁₆(ℝ) ha metà pari M₈(ℝ) ⊕ M₈(ℝ), che è l’intera algebra di Cl(4,3): due metà identiche, il “cancello specchio” del nodo Genesis 7.' },
      simp: { h: 'Vista simplesso', t: n => `Ogni vertice dispari ha esattamente n vicini pari, e formano un simplesso con n vertici: l’angolo che taglia via. È lo stesso grafo completo della vista Simplesso. Scegli il grado della lama dispari; i vertici pieni sono bivettori.`, pick: 'Grado della lama dispari' },
      lab: { h: 'Etichette (vista Primi)', t: n => n <= 5 ? `Etichette intere delle lame pari per n = ${n}: ${S.demicube.rows[n].even_labels.join(', ')}.` : 'Le etichette pari sono gli interi sotto 2ⁿ con un numero pari di 1 in binario.', note: ' Le etichette sono solo notazione, come ovunque.' },
      mx: {
        h: 'Maxwell (Prova 1)', t: n => `Il campo F è un bivettore, quindi sta sulla metà pari. La corrente J e le equazioni sono dispari. L’operatore ∇ inverte la parità, quindi ∇F = J manda la metà pari nella metà dispari. Ricostruito dalla regola dei bit per n = ${n}: ${S.demicube.maxwell[n].incidences} incidenze; ogni equazione vettoriale usa ${S.demicube.maxwell[n].vector_equation_terms} componenti del campo e ogni equazione trivettoriale ne usa 3, tutte nel simplesso d’angolo della sua lama dispari. Due componenti del campo condividono un’equazione esattamente quando condividono un indice, cioè esattamente quando sono uno spigolo del demicubo tra due bivettori, e allora condividono due equazioni (una vettoriale, una trivettoriale).`,
        pick: 'Assi temporali k', note: 'A sinistra: componenti del campo (bivettori). A destra: lame dispari, prima le equazioni vettoriali poi quelle trivettoriali. Verde: contrazione. Rosso: cuneo. Clicca una lama dispari per isolare la sua equazione.', cap7: 'Le celle di Maxwell dell’atlante si fermano a 7 generatori, quindi qui il disegno mostra n = 7.', E: 'E', B: 'B', T: 'T', terms: n => `termini in questa equazione: ${n}`
      },
      orth: { h: 'Ortoplesso (passo 1)', t: 'n = 3: il demicubo è il tetraedro, il simplesso. n = 4: è la 16-celle, una delle tre 16-celle del passo 1 (le sfaccettature pari del 4-ortoplesso). n = 5: i suoi 16 vertici sono le sfaccettature pari del 5-ortoplesso, gradi 1 + 10 + 5. n = 8: i suoi 128 vertici più i 112 spigoli dell’8-ortoplesso sono le 240 radici di E8: il passo 3 parte da qui.' },
      fur: { h: 'Furey (Prova 2)', t: 'Togliere l’ultimo bit trasforma i vertici dell’n-demicubo nei vertici dell’(n−1)-cubo, e rispetta la regola XOR: le lame pari di n generatori sono tutte le lame di n−1 generatori. A n = 5 è il tesseratto. Nel modello esplicito a 16 dimensioni i 16 assi di Witt sono i vertici di un tesseratto, con i blocchi di Peirce H e C + e₇R + R come facce quadrate e O₁ + O₂ come cubo. Anche una generazione ha 16 dimensioni complesse. La biiezione e gli assi sono verificati, l’uguaglianza dei conteggi non è un’identificazione. Se siano una sola cosa è aperto, e la prova di famiglia ha trovato che nessuna forma qui dà un 3.' },
      limits: 'Che cosa questo non mostra: nulla in questa pagina è un’affermazione fisica oltre alle prove di Maxwell e Furey a cui rimanda.',
      dlH: 'Verificalo tu', dlText: 'Un unico file Python autonomo (solo libreria standard). Ricostruisce ogni numero di questa pagina, compresi i reticoli delle facce a forza bruta.', dlPy: 'Scarica shapes_selfcheck.py', dlJson: 'Scarica shapes.json', dlCmd: 'python3 shapes_selfcheck.py --compare shapes.json'
    }
  }
};
// The Young Learner reads the shapes in plain words: directions, corners, edges, outer faces, the inside-out cube and the half cube.
// The formal tables, names and notes are in the fold "for older readers". Every count is read from shapesData.js.
const P2 = n => 2 ** n;
const YL_LETTERS = ['x', 'y', 'z', 'w', 'v', 'u', 's', 'r'];
COPY.en.o.yl = {
  title: 'Every direction gets two points',
  tableH: 'One step at a time', cols: ['directions', 'shape', 'corners', 'edges', 'outer faces'],
  shapes: ['a point', 'a segment', 'a square', 'an octahedron (two pyramids)', 'the 16-cell', 'in 5 directions', 'in 6 directions', 'in 7 directions', 'in 8 directions'],
  picH: 'A flat picture of the shape', pick: 'Number of directions',
  pic: n => n < 2 ? 'Too small for a picture: a point, then a segment with its two ends.' : `${2 * n} points on a circle, each one opposite its partner, and every pair joined except partners: ${2 * n * (n - 1)} edges. The ${P2(n)} outer faces are not drawn.`,
  pole: (i, plus) => `${YL_LETTERS[i] || i + 1}${plus ? '+' : '−'}`,
  points: [
    [['checked'], 'It is the cube turned inside out: each corner of the cube matches an outer face of this shape, and the other way round. Checked for every face up to 5 directions.'],
    [['checked', 'ours'], 'An idea we try: read each direction as a little box that is either empty or full. Then each face is a list of rules such as “this box is empty”, and the matching part of the cube is every way of filling the boxes that obeys them. The counting is checked; the reading is ours.'],
    [['checked'], 'In 4 directions there are 8 points and 16 outer faces. Split the faces into two halves of 8: the points and the two halves are three copies of the same shape, the 16-cell. Nothing new: the same 8, seen three ways.'],
    [['standard', 'ours'], 'In 5 directions the 32 outer faces split into 16 + 16. One family of particles also has 16 members. The numbers agree; that they are one thing is an idea we try, and it is open.'],
    [['standard'], 'In 8 directions the 112 edges and half of the outer faces (128) make the 240 corners of a famous shape called E8. Step 3 rebuilds it. No claim about our model.']
  ]
};
COPY.it.o.yl = {
  title: 'Ogni direzione ha due punti',
  tableH: 'Un passo alla volta', cols: ['direzioni', 'forma', 'vertici', 'spigoli', 'facce esterne'],
  shapes: ['un punto', 'un segmento', 'un quadrato', 'un ottaedro (due piramidi)', 'la 16-celle', 'in 5 direzioni', 'in 6 direzioni', 'in 7 direzioni', 'in 8 direzioni'],
  picH: 'Un disegno piatto della forma', pick: 'Numero di direzioni',
  pic: n => n < 2 ? 'Troppo piccola per un disegno: un punto, poi un segmento con i suoi due estremi.' : `${2 * n} punti su una circonferenza, ciascuno di fronte al suo compagno, e ogni coppia unita tranne i compagni: ${2 * n * (n - 1)} spigoli. Le ${P2(n)} facce esterne non sono disegnate.`,
  pole: (i, plus) => `${YL_LETTERS[i] || i + 1}${plus ? '+' : '−'}`,
  points: [
    [['checked'], 'È il cubo rovesciato: ogni vertice del cubo corrisponde a una faccia esterna di questa forma, e viceversa. Verificato per ogni faccia fino a 5 direzioni.'],
    [['checked', 'ours'], 'Un’idea che proviamo: leggi ogni direzione come una scatolina vuota o piena. Allora ogni faccia è un elenco di regole come “questa scatola è vuota”, e la parte del cubo che le corrisponde è ogni modo di riempire le scatole che le rispetta. Il conteggio è verificato; la lettura è nostra.'],
    [['checked'], 'In 4 direzioni ci sono 8 punti e 16 facce esterne. Dividi le facce in due metà da 8: i punti e le due metà sono tre copie della stessa forma, la 16-celle. Niente di nuovo: gli stessi 8, visti in tre modi.'],
    [['standard', 'ours'], 'In 5 direzioni le 32 facce esterne si dividono in 16 + 16. Anche una famiglia di particelle ha 16 membri. I numeri coincidono; che siano la stessa cosa è un’idea che proviamo, ed è aperto.'],
    [['standard'], 'In 8 direzioni i 112 spigoli e metà delle facce esterne (128) formano i 240 vertici di una forma famosa chiamata E8. Il passo 3 la ricostruisce. Nessuna affermazione sul nostro modello.']
  ]
};
COPY.en.d.yl = {
  title: 'The half cube: keep every second corner',
  facets: 'Its outer faces are smaller half cubes, plus one little corner piece for each corner that was cut away (in 3 directions only the corner pieces are left). Every count was also checked by building all the faces one by one.',
  tableH: 'Half cubes, one size at a time', cols: ['directions', 'corners', 'edges', 'outer faces'], pick: 'Number of directions',
  names: { 3: 'the tetrahedron', 4: 'the 16-cell' },
  cube: { h: 'Cube view', t: n => `The ${P2(n)} corners of the cube in ${n} directions, drawn flat. ${P2(n - 1)} have an even number of 1s (filled, coloured by how many 1s) and ${P2(n - 1)} an odd number (hollow). Lines join filled corners that differ in two digits.` },
  legend: 'Colour = how many 1s. Hollow grey = an odd number of 1s.', ones: g => `${g} ${g === 1 ? 'one' : 'ones'}`,
  cliff: { h: 'Combining corners', t: n => `Combine two even corners (XOR of their digits) and you get an even corner again. So the even half is a small world of its own. With the full rule of the algebra it works exactly like the whole cube with one direction fewer: here, like the cube in ${n - 1} directions (checked up to 8 directions).` },
  simp: { h: 'Corner pieces', t: n => `Every odd corner has exactly ${n} even neighbours, one along each direction. Together they form a little corner piece with ${n} corners, every pair joined. Choose how many 1s the odd corner has; filled dots have two 1s.`, pick: 'How many 1s in the odd corner' },
  lab: { h: 'Numbers', t: n => n <= 5 ? `The number labels of the even corners in ${n} directions: ${S.demicube.rows[n].even_labels.join(', ')}.` : `The even labels are the numbers below ${P2(n)} with an even number of 1s when written in binary.`, note: ' The numbers are just labels, as everywhere else.' },
  mx: { h: 'Maxwell (Test 1)', t: 'The electric and magnetic field pieces sit on the even corners, and the equations on the odd corners. Each equation only uses the field pieces next to its own corner.', pick: 'Time directions', note: 'Left: the field pieces. Right: the equations. Click an equation to see which pieces it uses.', cap7: 'The Maxwell cells stop at 7 directions, so this picture shows 7.', terms: n => `pieces in this equation: ${n}` },
  orth: { h: 'Inside-out cube (step 1)', t: 'In 3 directions the half cube is the tetrahedron, a pyramid of four triangles. In 4 directions it is the 16-cell, one of the three copies of step 1. In 5 directions its 16 corners are the even outer faces of step 1’s shape. In 8 directions its 128 corners plus the 112 edges of step 1’s shape are the 240 corners of E8: step 3 builds on this.' },
  fur: { h: 'Furey (Test 2)', t: 'Drop the last digit of each even corner in 5 directions and you get every corner of the cube in 4 directions, once each. In the particle model the 16 hidden lanes also sit on the corners of a cube in 4 directions, and one family also has 16 members. The shapes are checked; equal counts are not the same thing. Whether they are one thing is open, and the family test found no 3 here.' }
};
COPY.it.d.yl = {
  title: 'Il mezzo cubo: tieni un vertice su due',
  facets: 'Le sue facce esterne sono mezzi cubi più piccoli, più un piccolo pezzo d’angolo per ogni vertice tolto (in 3 direzioni restano solo i pezzi d’angolo). Ogni conteggio è stato verificato anche costruendo tutte le facce una per una.',
  tableH: 'Mezzi cubi, una grandezza alla volta', cols: ['direzioni', 'vertici', 'spigoli', 'facce esterne'], pick: 'Numero di direzioni',
  names: { 3: 'il tetraedro', 4: 'la 16-celle' },
  cube: { h: 'Vista cubo', t: n => `I ${P2(n)} vertici del cubo in ${n} direzioni, disegnati in piano. ${P2(n - 1)} hanno un numero pari di cifre 1 (pieni, colorati secondo quante cifre 1) e ${P2(n - 1)} un numero dispari (vuoti). Le linee uniscono vertici pieni che differiscono in due cifre.` },
  legend: 'Colore = quante cifre 1. Grigio vuoto = un numero dispari di cifre 1.', ones: g => `${g} ${g === 1 ? 'cifra 1' : 'cifre 1'}`,
  cliff: { h: 'Combinare vertici', t: n => `Combina due vertici pari (XOR delle loro cifre) e ottieni di nuovo un vertice pari. Quindi la metà pari è un piccolo mondo a sé. Con la regola completa dell’algebra funziona esattamente come il cubo intero con una direzione in meno: qui, come il cubo in ${n - 1} direzioni (verificato fino a 8 direzioni).` },
  simp: { h: 'Pezzi d’angolo', t: n => `Ogni vertice dispari ha esattamente ${n} vicini pari, uno per ogni direzione. Insieme formano un piccolo pezzo d’angolo con ${n} vertici, ogni coppia unita. Scegli quante cifre 1 ha il vertice dispari; i punti pieni hanno due cifre 1.`, pick: 'Quante cifre 1 nel vertice dispari' },
  lab: { h: 'Numeri', t: n => n <= 5 ? `Le etichette numeriche dei vertici pari in ${n} direzioni: ${S.demicube.rows[n].even_labels.join(', ')}.` : `Le etichette pari sono i numeri sotto ${P2(n)} con un numero pari di cifre 1 quando li scrivi in binario.`, note: ' I numeri sono solo etichette, come ovunque.' },
  mx: { h: 'Maxwell (Prova 1)', t: 'I pezzi del campo elettrico e magnetico stanno sui vertici pari, e le equazioni sui vertici dispari. Ogni equazione usa solo i pezzi di campo vicini al suo vertice.', pick: 'Direzioni di tempo', note: 'A sinistra: i pezzi del campo. A destra: le equazioni. Clicca un’equazione per vedere quali pezzi usa.', cap7: 'Le celle di Maxwell si fermano a 7 direzioni, quindi qui il disegno mostra 7.', terms: n => `pezzi in questa equazione: ${n}` },
  orth: { h: 'Cubo rovesciato (passo 1)', t: 'In 3 direzioni il mezzo cubo è il tetraedro, una piramide di quattro triangoli. In 4 direzioni è la 16-celle, una delle tre copie del passo 1. In 5 direzioni i suoi 16 vertici sono le facce esterne pari della forma del passo 1. In 8 direzioni i suoi 128 vertici più i 112 spigoli della forma del passo 1 sono i 240 vertici di E8: il passo 3 parte da qui.' },
  fur: { h: 'Furey (Prova 2)', t: 'Togli l’ultima cifra di ogni vertice pari in 5 direzioni e ottieni ogni vertice del cubo in 4 direzioni, una volta ciascuno. Nel modello delle particelle anche le 16 corsie nascoste stanno sui vertici di un cubo in 4 direzioni, e anche una famiglia ha 16 membri. Le forme sono verificate; conteggi uguali non sono la stessa cosa. Se siano una sola cosa è aperto, e la prova di famiglia qui non ha trovato nessun 3.' }
};
export default COPY;
export { sup, pow2 };
