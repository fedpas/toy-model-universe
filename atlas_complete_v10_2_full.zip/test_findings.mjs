// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import katex from 'katex';
import {FINDINGS,FINDINGS_UI,EDGES,REAL_BLOCKS,COMPLEX_BLOCKS,BLOCK_NAMES,NUMBERS} from './findingsData.js';
import {peirceDecomposition} from './genesis_audit_v3.js';
const J=JSON.parse(fs.readFileSync('./furey_results.json','utf8'));
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
ok(eq(REAL_BLOCKS,J.real_blocks),'real blocks');ok(eq(COMPLEX_BLOCKS,J.complex_blocks),'complex blocks');
ok(NUMBERS.realDiag===J.real_diag&&NUMBERS.realOff===J.real_off&&NUMBERS.cxDiag===J.complex_diag&&NUMBERS.cxOff===J.complex_off,'peirce numbers');
ok(NUMBERS.deltaSM===J.delta_SM_real_dim&&NUMBERS.generation===J.sm_generation_dim&&NUMBERS.replicas===J.extras_dim&&NUMBERS.maxEdge===J.maxEdge.capacity_C,'sm numbers');
ok(NUMBERS.quadruples===J.witt.independent_commuting_grade4_quadruples&&NUMBERS.diagonalising===J.witt.diagonalising_all_block_projectors&&NUMBERS.fanoLines===J.witt.fano_lines,'witt numbers');
const idx={'C_O(1)':0,'C3_O(3)':1,'C2_H(2)':2,'C_C(1)':3,'C_last(1)':4};
ok(J.edges.length===EDGES.length,'edge count');
for(const e of J.edges){const a=idx[e.a],b=idx[e.b];const m=EDGES.find(x=>(x[0]===a&&x[1]===b)||(x[0]===b&&x[1]===a));ok(!!m&&m[2]===e.capacity_C,`edge ${e.a}-${e.b} capacity`);
 // block sizes consistent with capacity
 ok(e.capacity_C===2*COMPLEX_BLOCKS[a]*COMPLEX_BLOCKS[b],`2nn ${e.a}-${e.b}`)}
const smSet=EDGES.filter(x=>x[4]==='sm'),rep=EDGES.filter(x=>x[4]==='rep');
const smOne=smSet.reduce((t,x)=>t+(x[2]===12?6:x[2]/2),0),repOne=rep.reduce((t,x)=>t+x[2]/2,0);
ok(smOne===16&&repOne===8,'one-way SM 16 / replicas 8: '+smOne+'/'+repOne);
const pd=peirceDecomposition();ok(pd.edgeTotalC===48&&pd.smContent.generationC===16&&pd.smContent.replicaC===8,'audit module agrees');
ok(J.witt.cayley_dickson_flag_affine.every(Boolean)&&J.witt.block_is_affine.O2===false,'affine flag');
ok(eq(J.omega_prime_over_omega_minus_axes,[0,3,8,11])&&/0,3,8,11/.test(FINDINGS.find(f=>f.id==='z2').en.Physicist[1]),'z2 axes');
// text coverage + no stale claims
for(const f of FINDINGS)for(const L of['en','it'])for(const P of['Young Learner','Physicist','Mathematician']){const t=f[L]?.[P];ok(Array.isArray(t)&&t.length===2&&t[0]&&t[1],`${f.id}.${L}.${P}`)}
for(const f of FINDINGS)for(const L of['en','it'])for(const P in f[L])ok(!/withdrawn|retract|ritirat|ritrattaz|two generations|due generazioni|rejected|respint|corrected/i.test(f[L][P][1]+f[L][P][0]),`no history claims ${f.id}.${L}.${P}`);
// v10.2 (audit round 2): the tags of each card are from the four, in order, and a card tagged ours never says derived; the edge listing says it
// carries gauge quantum numbers only, and its sum of Y³ (recomputed here from the listing the card prints) is the −4/9 it quotes
{ const ORDER = ['standard', 'checked', 'ours', 'open'];
  for (const f of FINDINGS) { ok(Array.isArray(f.flags) && f.flags.join() === ORDER.filter(k => f.flags.includes(k)).join(), `${f.id}: tags from the four, in order (${f.flags})`);
    if (f.flags.includes('ours')) for (const L of ['en', 'it']) for (const P of ['Physicist', 'Mathematician']) ok(!/deriv/i.test(f[L][P].join(' ')), `${f.id}.${L}.${P}: a card tagged ours never says derived`); }
  ok(FINDINGS.find(f => f.id === 'edges').flags.join() === 'checked,open' && FINDINGS.find(f => f.id === 'open').flags.join() === 'ours,open', 'one generation fits by gauge quantum numbers (checked, open); the open questions are ours and open');
  const ph = FINDINGS.find(f => f.id === 'edges').en.Physicist[1], fr = x => { const [n, d] = x.replace('−', '-').split('/').map(Number); return [n, d || 1]; };
  let num = 0, den = 1; for (const m of ph.matchAll(/(?:Q_L|u_R|d_R|L|e_R|ν_R) \(\d,\d,([+−-]?\d+(?:\/\d+)?)\) (\d)/g)) { const [a, b] = fr(m[1]), k = +m[2]; num = num * b ** 3 + k * a ** 3 * den; den *= b ** 3; }
  const g = (x, y) => (y ? g(y, x % y) : Math.abs(x)), q = g(num, den);
  ok(num / q === -4 && den / q === 9 && /gauge quantum numbers only/.test(ph) && /ΣY³ over this listing is −4\/9/.test(ph) && /ΣY³ su questo elenco vale −4\/9/.test(FINDINGS.find(f => f.id === 'edges').it.Physicist[1]), `the edge listing: ΣY³ = ${num / q}/${den / q}, quoted as −4/9 with "gauge quantum numbers only" (EN, IT)`); }
const YL_COPY = [['findings cards', FINDINGS.map(f => f.en['Young Learner']), FINDINGS.map(f => f.it['Young Learner'])], ['findings pictures', { c: FINDINGS_UI.en.ylCaption, s: FINDINGS_UI.en.ylSum, g: FINDINGS_UI.en.ylGrid }, { c: FINDINGS_UI.it.ylCaption, s: FINDINGS_UI.it.ylSum, g: FINDINGS_UI.it.ylGrid }]];
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));   // status keys are the same in both
  }
}
console.log(bad?bad+' FAILURES':'ALL FINDINGS TESTS PASS');process.exit(bad?1:0)
