// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import T from './threegenData.js';
import {THREEGEN_PY} from './threegenSelfcheckSource.js';
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}};
const J=JSON.parse(fs.readFileSync('./selfcheck/threegen.json','utf8')),Fu=JSON.parse(fs.readFileSync('./furey_results.json','utf8'));
ok(JSON.stringify(J)===JSON.stringify(JSON.parse(JSON.stringify(T))),'data equals rebuilt JSON');
ok(THREEGEN_PY===fs.readFileSync('./selfcheck/threegen_selfcheck.py','utf8'),'embedded script equals file');
// parse irreps independently of the python tables: dimension and hypercharge in sixths
const CD={'1':1,'3':3,'3b':3,'6':6,'6b':6,'8':8};
const parse=s=>{const m=/^\((\w+),(\d),([+-]?\d+(?:\/\d+)?)\)$/.exec(s);const [n,d]=m[3].split('/').map(Number);return {dim:CD[m[1]]*Number(m[2]),y6:Math.round(6*n/(d||1))}};
const tot=o=>Object.entries(o).reduce((a,[k,m])=>a+parse(k).dim*m,0);
ok(tot(T.linear_off_diagonal_irreps)===48&&tot(T.antilinear_irreps)===64,'sector dimensions 48 and 64');
// independent hypercharge bookkeeping, state by state: blocks (dim, y in sixths) from the data
const states=[];for(const b of T.blocks){const [n,d]=b.y.split('/').map(Number);for(let i=0;i<b.dim;i++)states.push(Math.round(6*n/(d||1)))}
ok(states.length===8,'eight complex dimensions');
const cnt=(arr)=>{const c={};for(const v of arr)c[v]=(c[v]||0)+1;return JSON.stringify(Object.entries(c).sort((a,b)=>a[0]-b[0]))};
// antilinear sector: charge y_t + y_s over all ordered pairs of states
const antiExp=[];for(const t of states)for(const s of states)antiExp.push(t+s);
const antiGot=[];for(const [k,m] of Object.entries(T.antilinear_irreps)){const p=parse(k);for(let i=0;i<p.dim*m;i++)antiGot.push(p.y6)}
ok(cnt(antiExp)===cnt(antiGot),'antilinear charges state by state');
// linear sector off the diagonal blocks: y_t - y_s over pairs in different blocks
const blockOf=[];T.blocks.forEach((b,i)=>{for(let j=0;j<b.dim;j++)blockOf.push(i)});
const linExp=[];states.forEach((yt,a)=>states.forEach((ys,b)=>{if(blockOf[a]!==blockOf[b])linExp.push(yt-ys)}));
const linGot=[];for(const [k,m] of Object.entries(T.linear_off_diagonal_irreps)){const p=parse(k);for(let i=0;i<p.dim*m;i++)linGot.push(p.y6)}
ok(cnt(linExp)===cnt(linGot),'linear off-diagonal charges state by state');
// agrees with the earlier explicit-model audit (run_all.py)
ok(Fu.complex_off===48&&Fu.sm_generation_dim===16&&Fu.extras_dim===8,'furey_results.json');
ok(T.sm_rows.Q_L.linear===1&&T.sm_rows.u_R.linear===1&&T.sm_rows.d_R.linear===2&&T.sm_rows.L.linear===3&&T.sm_rows.e_R.linear===2,'multiplicities = one generation + replicas');
ok(T.linear_beyond_one_generation.d_R===1&&T.linear_beyond_one_generation.L===2&&T.linear_beyond_one_generation.e_R===1,'replica content d_R, 2 L, e_R');
ok(T.exotic.linear_off_diagonal===0&&T.exotic.antilinear===32,'exotic content');
// the dimension count that makes three generations look possible, and why it does not work
ok(3*2*16*2===192&&192<=256,'three generations of particle and antiparticle would fit in 256 real dimensions');
ok(48===3*16,'48 = 3 x 16 is a numerical coincidence of capacity, not a content statement');
ok(T.search_all.max_generations===2&&!('3' in T.search_all.histogram)&&T.search_all.admissible_W===5582,'no admissible W has three generations');
ok(T.search_peirce_frame.assignments===4000&&!('3' in T.search_peirce_frame.histogram)&&T.search_peirce_frame.histogram['2']===60,'Peirce frame search');
ok(T.search_all.least_exotic_dimension_for_generations['2']>0&&T.search_peirce_frame.least_exotic_dimension_for_generations['2']>0,'two generations always come with exotic content');
ok(Object.values(T.max_copies_of_each_irrep).every(v=>v>=2)&&T.max_copies_of_each_irrep.Q_L===4,'each irrep alone can be repeated, never all six together');
ok(/--compare/.test(THREEGEN_PY)&&/ALL THREE-GENERATION CHECKS PASS/.test(THREEGEN_PY),'script interface');
// the plain copy of a section lives in its .jsx file: bundle it with esbuild and read the exported object
import { buildSync } from 'esbuild';
const jsxModule = f => import('data:text/javascript;base64,' + Buffer.from(buildSync({ absWorkingDir: PKG, entryPoints: [f], bundle: true, write: false, format: 'esm', platform: 'node', loader: { '.js': 'jsx' }, logLevel: 'silent', alias: { streamdown: './stubs/streamdown.jsx', '@streamdown/math': './stubs/smath.js', 'react-katex': './stubs/katex.jsx' } }).outputFiles[0].text).toString('base64'));
const TGM = await jsxModule('./ThreeGenSection.jsx');
const YL_COPY = [['three generations', TGM.THREEGEN_YL.en, TGM.THREEGEN_YL.it]];
// T4-17 (fix round): the sentence on the search with Furey's block sizes says what the data says. No choice of hypercharges is free of exotic charges
// (least exotic dimension over all choices > 0), so "1 generation at best with Standard-Model content" was false; every number is the data's.
{ const P = T.search_peirce_frame, E = P.least_exotic_dimension_for_generations, top = Math.max(...Object.keys(P.histogram).map(Number)), e0 = Math.min(...Object.values(E)), e1 = Math.min(...Object.entries(E).filter(([g]) => +g >= 1).map(([, v]) => v));
  ok(e0 > 0 && JSON.stringify(TGM.FRAME) === JSON.stringify({ top, e0, e1, furey: T.generations.furey_frame, fureyExotic: T.exotic.antilinear }), `the page reads the search from the data: ${JSON.stringify(TGM.FRAME)}`);
  const en = TGM.THREEGEN_YL.en.search2(P.assignments), it = TGM.THREEGEN_YL.it.search2(P.assignments);
  ok(en.includes(`at most ${top} complete families`) && en.includes(`at least ${e0} of them`) && en.includes(`at least ${e1} in every choice that holds a family`) && !/at best with known kinds|only if many places/.test(en), 'EN young learner: every choice has exotic places; numbers from the data');
  ok(it.includes(`al massimo ${top} famiglie complete`) && it.includes(`almeno ${e0}, e almeno ${e1}`) && !/al meglio 1 famiglia con tipi di particelle noti/.test(it), 'IT young learner: ogni scelta ha posti esotici; numeri dai dati');
  const src = fs.readFileSync('./ThreeGenSection.jsx', 'utf8');
  ok(!/at best with Standard Model content|al meglio 1 generazione con contenuto del Modello Standard/.test(src) && /No choice is free of exotic charges/.test(src) && /Nessuna scelta è priva di cariche esotiche/.test(src), 'Physicist: no choice is free of exotic charges (EN/IT)');
  // V4-6 (round 3): the Physicist sentence too gives the data's numbers, not typed ones
  const pe = TGM.THREEGEN_COPY.en.search2(P.assignments), pi = TGM.THREEGEN_COPY.it.search2(P.assignments);
  ok(pe.includes(`at most ${top} generations`) && pe.includes(`at least ${e0} complex dimensions`) && pe.includes(`at least ${e1}.`) && pi.includes(`al massimo ${top} generazioni`) && pi.includes(`almeno ${e0} dimensioni complesse`) && pi.includes(`almeno ${e1}.`), `Physicist EN/IT: at most ${top} generations, at least ${e0} and ${e1} exotic dimensions (data)`); }
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));   // status keys are the same in both
  }
}
console.log(bad?bad+' FAILURES':'ALL THREEGEN TESTS PASS');process.exit(bad?1:0)
