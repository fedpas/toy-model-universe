// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import K from './gravityData.js';
import { axname } from './couplingCopy.js';

// Copy for steps 6 and 7 of the equations page: gravity (English and Italian).
// Every number is read from selfcheck/gravity.json (exact, standard library) and selfcheck/gravity_matrix.json (numpy).
const L = K.gv.ladder, CS = K.gv.curvature_space, DS = K.gv.desitter;
const pe = (k, one, many) => (k === 1 ? one : many);
const pc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
export const planes = n => { const g = []; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) g.push((1 << i) | (1 << j)); return g; };
export const pairClass = (a, b) => (a === b ? 'diagonal' : pc(a & b) === 1 ? 'one' : 'disjoint');
export const subsets4 = n => { const o = []; for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) for (let c = b + 1; c < n; c++) for (let d = c + 1; d < n; d++) o.push([a, b, c, d]); return o; };
export const plane = (a, b) => axname((1 << a) | (1 << b));
const wy = n => (CS[n] ? `${CS[n].ricci_rank} + ${CS[n].weyl_dimension}` : '—');
const merrNote = '< 1e-9';
const C2 = n => n * (n - 1) / 2;
const dsName = (n, s) => DS[`${n},${s}`];

// for the Young Learner readings: the counts of the table of plane pairs, and a plain list ("x, y and z")
const boxes = n => { const P = planes(n).length, cells = P * (P + 1) / 2; return { P, cells, rel: L[n].first_bianchi_constraints, free: L[n].riemann_independent }; };
const andList = (a, w) => (a.length < 2 ? a.join('') : a.slice(0, -1).join(', ') + ` ${w} ` + a[a.length - 1]);
const lines2 = n => (n - 1) * (n - 2) / 2;
const COPY = {
  en: {
    g1: {
      // the Young Learner reading: plain words beside the same picture; the formal text below stays for the other audiences and in the fold
      yl: {
        name: 'GRAVITY, PART ONE: HOW SPACE BENDS',
        title: 'Gravity, part one: a table of how space bends',
        pickH: 'Pick a number of directions', pick: 'How many directions? One of them is time.',
        picH: 'The table of how space bends',
        picCap: n => { const { P, cells, rel, free } = boxes(n); return `Each box is a pair of planes, and a plane is a pair of directions. ${P} plane${pe(P, '', 's')}, ${cells} box${pe(cells, '', 'es')}. Yellow: the same plane twice. Blue: two planes that share one direction. Green: two planes that share none. ${rel ? `For every four directions one rule ties three green boxes together, so ${cells} − ${rel} = ${free} numbers are free.` : cells === 1 ? 'Its one number is free.' : `All ${cells} numbers are free.`} Pick a colour to see its boxes${n >= 4 ? ', or pick four directions' : ''}.`; },
        classes: { all: 'all', diagonal: 'same plane', one: 'one direction shared', disjoint: 'no direction shared' },
        classCap: (c, v) => (c === 'all' ? 'All boxes are shown.' : `${v} box${pe(v, '', 'es')} of this colour.`),
        subLabel: 'Four directions', subNone: 'none chosen', with: 'with',
        subCap: (nm, a) => `Directions ${nm}: there are three ways to split them into two planes: ${a}. One rule ties these three boxes together: once you know two of them, the third is fixed.`,
        points: [
          [['checked'], `Checked by a computer, exactly, for ${Object.keys(K.gv.identities).join(', ').replace(/, (\d+)$/, ' and $1')} directions: the bending obeys the same kind of rules as Maxwell’s field. The count of free numbers agrees with a second count made another way.`],
          [['open'], 'This step has no equation that says how matter bends space. That comes next, and its strength is not worked out.'],
          [['open'], 'The rule for how the arrows turn is not worked out from the arrows themselves. The usual way to do that is known, but it is not built here.']
        ]
      },
      title: 'Gravity, first half: the frame, its connection and its curvature',
      lede: 'Gravity is drawn here the way step 4 drew a gauge field, with the Lorentz bivectors of step 1 as the gauge algebra. The frame algebra is Cl(1, n−1) (one time axis). The spin connection ω has a 1-form for each bivector, the curvature is R = dω + ¼[ω,ω] (step 4 with g = ½), and the tetrad e has a 1-form for each vector, with torsion T = de + ωe. Forms are the same bit rule with every generator null, so the sign of a wedge product and the sign of a permutation are the null product of axiom A. We climb from n = 2 and read every view.',
      numbers: 'Exact arithmetic (rational numbers, polynomial fields) for the identities at n = 2 to 5 and for the counts at n = 2 to 8; linear algebra for the curvature space at n = 2 to 7; explicit gamma matrices and tensors (numpy) as an independent check.',
      tableH: 'The ladder', cols: ['n', 'frame algebra', 'bivectors (boosts + rotations)', 'components of ω', 'tetrad', 'curvature components', 'torsion components', 'independent curvature', 'first-Bianchi relations', 'Ricci + Weyl'],
      pickH: 'Pick a space-time dimension', pick: 'n axes, one of them time',
      picH: 'The table of curvature components',
      picCap: n => `Each cell is an unordered pair of planes (a b | c d). ${planes(n).length} planes, ${planes(n).length * (planes(n).length + 1) / 2} cells. Diagonal: the two planes are the same. One axis shared: the planes do not commute, they are joined by an edge of the commutator graph of step 1 (a distance-2 edge of the demicube). No axis shared: the planes commute (distance 4). Pick a class to see where its cells are${n >= 4 ? ', or pick four axes to see the three cells that one first-Bianchi relation ties together' : ''}.`,
      classes: { all: 'all', diagonal: 'same plane', one: 'one axis shared', disjoint: 'no axis shared' },
      classCap: (c, v) => (c === 'all' ? 'All cells are shown.' : `${v} cells of this class.`),
      subLabel: 'Four axes', subNone: 'none selected',
      subCap: (nm, a) => `Axes ${nm}: the three ways to split them into two planes are ${a}. The relation R(ab|cd) + R(ac|db) + R(ad|bc) = 0 ties exactly these three cells together.`,
      viewsH: n => `Every view at n = ${n}`,
      views: r => {
        const n = r.n_value, G = r.bivectors, P = G, cs = CS[n];
        const cl = { h: 'Clifford', t: `The frame algebra is Cl(1,${n - 1}) = ${r.frame_algebra}, and its even half is ${r.even_half}. The bivectors are the Lorentz generators of step 1: ${G} in all, ${r.boosts} boost${pe(r.boosts, '', 's')} (a plane with the time axis) and ${r.rotations} rotation${pe(r.rotations, '', 's')}. The spin connection has ${r.omega_components} components (${G} bivectors × ${n} directions), the tetrad ${r.tetrad_components}, the curvature ${r.curvature_components} (${G} bivectors × ${C2(n)} planes) and the torsion ${r.torsion_components} (${n} vectors × ${C2(n)} planes). The Poincaré algebra adds ${n} translations: ${r.poincare_generators} generators.`, tags: ['checked', 'standard'] };
        const cu = { h: 'Cube and demicube', t: `The curvature is a table indexed by unordered pairs of planes. Same plane: ${r.pair_classes.diagonal}. One axis shared: ${r.pair_classes.share_one_index}, the edges of the commutator graph of step 1, the distance-2 edges of the demicube. No axis shared: ${r.pair_classes.disjoint}, the commuting pairs${n === 4 ? ', which at n = 4 are the 3 antipodal pairs of the 16-cell, as in step 1' : ''}. The three classes together are ${r.pair_classes.diagonal + r.pair_classes.share_one_index + r.pair_classes.disjoint} cells.`, tags: ['checked', 'ours'] };
        const si = { h: 'Simplex', t: r.first_bianchi_constraints === 0 ? `With ${n} axes there is no set of four, so the first Bianchi identity adds no relation to the cells once pair symmetry is used: ${r.riemann_independent} independent component${pe(r.riemann_independent, '', 's')}.` : `Four axes make a tetrahedron, and its three ways to split the four corners into two pairs are the three no-axis-shared cells. The first Bianchi identity is one relation among these three cells for each set of four axes: ${r.first_bianchi_constraints} in all (the 3-faces of the ${n - 1}-simplex). The cells minus the relations give ${r.pair_classes.diagonal + r.pair_classes.share_one_index + r.pair_classes.disjoint} − ${r.first_bianchi_constraints} = ${r.riemann_from_classes}, equal to n²(n²−1)/12 = ${r.riemann_independent}${cs ? ', the same number that linear algebra on the full identity gives' : ''}.`, tags: ['checked', 'ours'] };
        const la = { h: 'Labels', t: `Planes are named by their axes (tx, ty, xy, …) and a commutator of two planes sharing an axis is the plane of the other two, up to sign: the symmetric difference of the labels. Contracting R^{bc}_{ce} over c adds the cells whose first plane contains b: ${cs ? `the Ricci part has rank ${cs.ricci_rank}${n >= 3 ? ' (a symmetric n × n matrix)' : ''} and the rest, the Weyl part, has ${cs.weyl_dimension} component${pe(cs.weyl_dimension, '', 's')}` : 'the Ricci and Weyl split is not computed at this n'}. Labels are notation.`, tags: ['checked', 'standard'] };
        const ma = { h: 'Maxwell', t: `${G === 1 ? 'Here there is a single generator, so R = dω is exactly Maxwell’s F = dA and D R = 0 is the identity dF = 0 of the Maxwell page.' : `With one generator, R would be Maxwell’s F = dA and the second Bianchi identity dF = 0 is the rule of the Maxwell page. With ${G} generators it becomes D R = 0 with D the covariant derivative.`} Checked exactly on random polynomial fields at n = ${n <= 5 ? n : '2 to 5'}${n <= 5 ? '' : ' (not run at this n)'}.`, tags: n <= 5 ? ['checked'] : ['standard'] };
        const ym = { h: 'Yang–Mills (step 4)', t: `R is step 4’s field strength for the ${G} bivectors, with g = ½ and the signature of Cl(1,${n - 1}) in place of the Euclidean one. The Bianchi identity and the first-order gauge covariance carry over: a local Lorentz transformation λ changes ω by Dλ and R by [R, λ], and that is exact at n = ${n <= 5 ? n : '2 to 5'}${n <= 5 ? '' : ' (not run at this n)'}. The tetrad is not a gauge field: it is a vector-valued 1-form with D T = R ∧ e, the first Bianchi identity, also exact.`, tags: n <= 5 ? ['checked', 'standard'] : ['standard'] };
        const di = { h: 'Dirac', t: `On spinors ω acts by ½ω^A B_A, by left multiplication as the internal generators of step 5 did. The commutator of two covariant derivatives is [D, D]ψ = ½Rψ: exact at n = ${n <= 5 ? n : '2 to 5'}${n <= 5 ? '' : ' (not run at this n)'}, and with explicit matrices up to n = 6 (error ${merrNote}), in the spinor and in the vector representation. The Dirac equation on a curved tetrad is not drawn here.`, tags: n <= 5 ? ['checked', 'open'] : ['standard', 'open'] };
        return [cl, cu, si, la, ma, ym, di];
      },
      idH: 'Exact identities', idCols: ['n', 'D R = 0', 'D T = R ∧ e', 'local Lorentz covariance', '[D, D]ψ = ½Rψ'],
      idNote: 'Second Bianchi: the covariant derivative of the curvature vanishes. First Bianchi: the covariant derivative of the torsion is R ∧ e. Covariance: ω → ω + Dλ changes R by [R, λ]. Spinors: the commutator of the covariant derivatives is ½R acting by left multiplication. All on random polynomial fields (derivative terms included), in exact rational arithmetic.',
      xrH: 'What each view teaches the others',
      xr: [
        [['standard', 'checked'], 'Cube → simplex. The first Bianchi identity is one relation for each set of four axes (the Λ⁴ part of the curvature table), and the counts agree with linear algebra on the full identity for n = 2 to 7.'],
        ['ours', 'The same table of plane pairs, read twice: its classes as the edges and antipodes of the demicube, and each set of four axes as a tetrahedron of the axis simplex (our reading).'],
        [['standard', 'checked'], 'Step 4 → gravity. Curvature, Bianchi identity and covariance are step 4 for the bivector algebra; what is new is the second index type: the tetrad, which carries torsion.'],
        [['standard', 'checked'], 'Step 5 → gravity. The generators act on spinors by left multiplication, as the internal generators acted on the index T: [D, D]ψ = ½Rψ here is [D, D]Ψ = gFΨ there.'],
        [['standard', 'checked', 'ours'], 'This is first-order (Cartan) gravity. The reading of the curvature table by plane pairs and by the demicube is ours; the Riemann dimension n²(n²−1)/12 and the Ricci–Weyl split are textbook.']
      ],
      matH: 'Independent check with matrices',
      mat: `With Jordan–Wigner gamma matrices (numpy) the structure constants of the bivectors and of the bivector–vector action equal those of the bit rule at n = 2 to 6. For constant connections, the curvature built from the constants equals the commutator of the connection in the vector representation and ½R equals the commutator in the spinor representation (error ${merrNote}). The curvature space is rebuilt by SVD with the metric: the same dimensions, pair symmetry and Ricci rank at n = 2 to 7. Wrong versions fail: a gamma matrix with the wrong square, and the first Bianchi identity dropped (36 instead of 20 components at n = 4, and no pair symmetry).`,
      open: [
        ['open', 'This step has no field equation. The Einstein form comes next, and it comes without a derived coupling.'],
        [['standard', 'open'], 'Nothing here makes ω a function of e. Solving T = 0 for ω (the usual Levi-Civita connection) is standard but not built here.']
      ],
      dl: { h: 'Check it yourself', text: 'Two Python files. The first (standard library only) rebuilds the counts, the identities and the curvature space, exactly. The second (needs numpy, and the first file and gravity.json next to it) compares with explicit matrices and runs wrong versions that must fail.', py: 'Download gravity_selfcheck.py', py2: 'Download gravity_matrix_check.py', json: 'Download gravity.json', cmd: 'python3 gravity_selfcheck.py --compare gravity.json   ·   python3 gravity_matrix_check.py --compare gravity_matrix.json' }
    },
    g2: {
      yl: {
        name: 'GRAVITY, PART TWO: EINSTEIN’S EQUATION',
        title: 'Gravity, part two: Einstein’s equation, piece by piece',
        pickH: 'Pick a number of directions', pick: 'How many directions? One of them is time.',
        picH: 'The pieces of the equation', aLabel: 'Pick a direction',
        picCap: n => (n < 3 ? 'With 2 directions there is no Einstein equation: each piece needs three different directions.' : `The equation has one part for each of the ${n} directions: pick one (it is circled in red). Each line is a pair of the other ${n - 1} directions and makes one piece: the bending of that plane${n > 4 ? `, with one arrow on each of the remaining ${n - 3} directions` : n === 4 ? ', with one arrow on the remaining direction' : ''}. ${lines2(n)} line${pe(lines2(n), '', 's')}. Click a line.`),
        capNone: 'No piece chosen.', capSel: (b, c, rest) => `Piece ${b}${c}: the bending of the plane ${b}${c}${rest.length ? `, and an arrow on ${andList(rest, 'and')}` : ', and no arrows'}.`,
        points: [
          [['checked'], 'Checked by a computer, exactly, for 3, 4 and 5 directions: when the arrows do not twist, whatever feeds the equation can never be made or lost. When the arrows are the plain grid arrows, it is exactly Einstein’s usual equation.'],
          [['checked', 'standard'], 'The push or pull of empty space can come from one extra direction, and its sign is the opposite of the sign of that direction’s square (+1 or −1). This construction is known; we checked it.'],
          [['open'], 'How strongly matter bends space, and with which sign, is not worked out: there is no deeper principle here to fix it.'],
          [['open'], 'Nothing is solved: no shape of space is built from these pieces.']
        ]
      },
      title: 'Gravity, second half: the Einstein form and its conservation',
      lede: 'The Einstein equation in first-order form uses the tetrad and the curvature only: E_a = Σ_{b<c} ε_{abcd…} F^{bc} ∧ e^d ∧ …, an (n−1)-form with F^{bc} = R^{bc} + c e^b ∧ e^c (c is a cosmological term). The symbol ε is the sign of the null product of axiom A, the same sign as the wedge. Each term has the curvature and n−3 tetrads. We draw where the terms sit, check what D E_a is, check that E_a is the Einstein tensor, and read the cosmological term as one more generator.',
      numbers: 'Exact arithmetic on random polynomial fields for D E_a (n = 3, 4, 5) and for the de Sitter curvature (n = 3, 4); tensor contraction with permutation signs and explicit matrices (numpy) for the Einstein tensor (n = 3 to 5) and the de Sitter constants (n = 3 to 5).',
      tableH: 'The ladder', cols: ['n', 'components of E', 'terms in each E_a', 'tetrads in each term', 'torsion terms in D E_a', 'generators with a cosmological term', 'their curvature components'],
      pickH: 'Pick a space-time dimension', pick: 'n axes, one of them time',
      picH: 'Where the terms of E_a sit',
      picCap: n => `Pick the index a of E_a (the circled axis). Each line is a pair {b, c} of the other ${n - 1} axes: one term, with the curvature F^{bc} and a tetrad on each of the remaining ${n - 3} axes. ${(n - 1) * (n - 2) / 2} lines. Click a line to see the axes that carry tetrads.`,
      aLabel: 'Index a', capNone: 'No term selected.', capSel: (b, c, rest) => `Term {${b}, ${c}}: the curvature F^{${b}${c}} and ${rest.length === 0 ? 'no tetrads' : `a tetrad on ${rest.join(', ')}`}.`,
      viewsH: n => `Every view at n = ${n}`,
      views: r => {
        const n = r.n_value, ok = n >= 3, cd = n >= 3 && n <= 5, ds = n === 3 || n === 4;
        const cl = { h: 'Clifford', t: ok ? `E_a is an (n−1)-form with values in the vectors: ${r.einstein_components} components. The symbol ε_{abcd…} is the permutation sign, and that is the sign the null product of axiom A produces. Each term is the curvature of a plane (b c) times one tetrad for every other axis.` : 'At n = 2 the symbol ε needs three distinct axes and there are only two: no Einstein form, and the Einstein tensor of two dimensions is zero (standard).', tags: ['checked', 'standard'] };
        const cu = { h: 'Cube and demicube', t: ok ? `An (n−1)-form has its components on the n corners next to the full corner of the n-cube (all axes but one): ${n} corners, and with the index a, ${r.einstein_components} components. The picture above puts the terms on the pairs {b, c}, edges of the axis simplex on the other ${n - 1} axes.` : 'No Einstein form at n = 2.', tags: ok ? ['checked'] : ['standard'] };
        const si = { h: 'Simplex', t: ok ? `For fixed a the terms are the edges of the simplex on the other ${n - 1} axes: ${r.einstein_terms_per_component}. Each term has ${n - 3} tetrad${pe(n - 3, '', 's')}, so replacing one tetrad by the torsion in turn gives ${r.divergence_torsion_terms_per_component} terms in D E_a that contain T, with c = 0${n === 3 ? ': none, and D E_a = 0 identically' : ''}. Counted from the definition of E_a.` : 'No terms.', tags: ok ? ['checked'] : ['standard'] };
        const la = { h: 'Labels', t: ok ? (cd ? `At e^a = dx^a, E_a is the Einstein tensor G^μ_a = Ric^μ_a − ½Sδ^μ_a, with Ric^b_e = Σ_c R^{bc}_{ce} and S its trace: the ratio is exactly 1 in these sign conventions, for an arbitrary curvature (not only a Riemann-symmetric one), exactly at n = ${n} and by an independent contraction with permutation signs. Ricci alone, or a trace coefficient of 1, would give a ratio that varies.` : 'At e = dx the Einstein form is the Einstein tensor Ric − ½Sδ by construction; the exact check was run at n = 3, 4, 5 only (not run at this n).') : 'No Einstein tensor in two dimensions.', tags: cd ? ['checked', 'standard'] : ['standard'] };
        const ma = { h: 'Maxwell', t: ok ? `Maxwell’s equation forces the source to be conserved, because dd = 0. Here D E_a equals the torsion terms and nothing else${cd ? `, exactly on random fields with and without the cosmological term (n = ${n})` : ' (not run at this n)'}. With zero torsion E is conserved, for any curvature. This is the contracted Bianchi identity, standard. A source in E_a = κ(source) must then be conserved too; that is the same forcing as in steps 3 and 4.` : 'Nothing to conserve at n = 2.', tags: cd ? ['checked', 'standard'] : ['standard'] };
        const ym = { h: 'Yang–Mills (step 4)', t: ds ? `One more generator with square s = ∓1 gives ${dsName(n, 'dS').group} (s = −1) or ${dsName(n, 'AdS').group} (s = +1): ${r.desitter_generators} generators, the same count as the Poincaré algebra, and ${r.desitter_curvature_components} curvature components. Put ω on the first ${n} generators and κe on the new ones. The curvature is (R − sκ² e ∧ e, κT): the cosmological term has the sign of minus the square of the extra generator: +κ² e∧e (k = ${dsName(n, 'dS').coefficient_of_e_wedge_e}) for s = −1 and −κ² e∧e (k = ${dsName(n, 'AdS').coefficient_of_e_wedge_e}) for s = +1. Exact on random fields at n = 3, 4; with matrices at n = 3, 4, 5.` : `One more generator of square s gives so(1,n) or so(2,n−1): ${r.desitter_generators} generators, ${r.desitter_curvature_components} curvature components, the same count as step 4 at m = ${n + 1} with another signature. ${n === 5 ? 'The constants k = −s and μ = 1 are checked with matrices at this n; the exact polynomial check was run at n = 3, 4.' : 'Not run at this n.'}`, tags: ds || n === 5 ? ['checked', 'standard'] : ['standard'] };
        const di = { h: 'Dirac', t: 'The source of E_a would be the energy-momentum built from ψ and the tetrad. We did not build it, and we have no action, so the size and sign of the coupling κ are open. What step 6 did give is the spinor curvature [D, D]ψ = ½Rψ.', tags: ['open'] };
        return [cl, cu, si, la, ma, ym, di];
      },
      idH: 'Exact identities',
      idCols: ['n', 'cosmological term c', 'D E_a = torsion terms only', 'E at e = dx is the Einstein tensor'],
      idNote: 'The first identity is exact on random polynomial ω and e (derivatives included), with the second Bianchi identity used. At n = 3 with c = 0 every torsion term is absent and D E_a = 0 identically. The second is the ratio of E to the Einstein tensor, checked at n = 3, 4, 5 with c = 0.',
      dsH: 'The cosmological term as one more generator',
      dsCols: ['n', 'extra generator squares to', 'group', 'e ∧ e in the curvature', 'torsion in the curvature'],
      dsNote: 'The curvature of ω plus κe on the new generators is R + k κ² e∧e in the first n generators and μκT in the new ones; k and μ are listed at κ = 1. Exact on polynomial fields, and with explicit matrices up to n = 5.',
      xrH: 'What each view teaches the others',
      xr: [
        [['standard', 'checked', 'ours'], 'Simplex → Clifford. The sign of the cosmological term is minus the sign of the square of one extra generator (k = −s; axiom B, polarization): the choice between de Sitter and anti-de Sitter is the choice of one sign. This is an observation about the known embedding, not a new result.'],
        [['standard', 'checked'], 'Maxwell, step 3 and step 4 → gravity. In each, a source must be conserved because the field’s Bianchi identity forces it. Here the Bianchi identity shows up as D E_a = torsion terms.'],
        [['standard', 'checked'], 'Step 6 → step 7. The curvature and the tetrad of step 6 are the only inputs of the Einstein form; the torsion enters only through D E_a.'],
        [['standard', 'ours'], 'This is Einstein–Cartan gravity in first-order form with the MacDowell–Mansouri embedding. The pictures and the bit-rule reading are ours; the identities are textbook, and we have only checked that our rebuilding of them is right.']
      ],
      matH: 'Independent check with matrices',
      mat: 'E_a at e = dx is rebuilt by a tensor contraction with permutation signs, not with bit masks: the ratio to the Einstein tensor is 1 at n = 3, 4, 5. Two wrong versions fail: Ricci instead of the Einstein tensor, and a trace coefficient of 1 instead of ½ (the ratio then varies). The extra generator is built as a gamma matrix of square s: the commutator of two vector-like generators is −2s times the plane generator, so k = −s for every n = 3, 4, 5 and both signs of s, and μ = 1; flipping the sign of the square flips k.',
      open: [
        ['open', 'The field equation with matter: the coupling κ and the sign of the source are not derived. There is no action.'],
        ['open', 'Solutions. No field equation is solved here, and T = 0 is not solved for ω. Step 16 takes the Schwarzschild solution from the literature, in its Painlevé–Gullstrand and Kerr–Schild forms, as shears of the frame and rebuilds its metric from the frame.']
      ],
      dl: { h: 'Check it yourself', text: 'The same two Python files as in step 6 (they hold both steps).', py: 'Download gravity_selfcheck.py', py2: 'Download gravity_matrix_check.py', json: 'Download gravity.json', cmd: 'python3 gravity_selfcheck.py --compare gravity.json   ·   python3 gravity_matrix_check.py --compare gravity_matrix.json' }
    }
  },
  it: {
    g1: {
      yl: {
        name: 'GRAVITÀ, PRIMA PARTE: COME SI PIEGA LO SPAZIO',
        title: 'Gravità, prima parte: una tabella di come si piega lo spazio',
        pickH: 'Scegli un numero di direzioni', pick: 'Quante direzioni? Una di esse è il tempo.',
        picH: 'La tabella di come si piega lo spazio',
        picCap: n => { const { P, cells, rel, free } = boxes(n); return `Ogni casella è una coppia di piani, e un piano è una coppia di direzioni. ${P} pian${pe(P, 'o', 'i')}, ${cells} casell${pe(cells, 'a', 'e')}. Giallo: lo stesso piano due volte. Blu: due piani con una direzione in comune. Verde: due piani senza direzioni in comune. ${rel ? `Per ogni gruppo di quattro direzioni una regola lega tre caselle verdi, quindi ${cells} − ${rel} = ${free} numeri sono liberi.` : cells === 1 ? 'Il suo unico numero è libero.' : `Tutti i ${cells} numeri sono liberi.`} Scegli un colore per vedere le sue caselle${n >= 4 ? ', oppure scegli quattro direzioni' : ''}.`; },
        classes: { all: 'tutte', diagonal: 'stesso piano', one: 'una direzione in comune', disjoint: 'nessuna direzione in comune' },
        classCap: (c, v) => (c === 'all' ? 'Sono mostrate tutte le caselle.' : `${v} casell${pe(v, 'a', 'e')} di questo colore.`),
        subLabel: 'Quattro direzioni', subNone: 'nessuna scelta', with: 'con',
        subCap: (nm, a) => `Direzioni ${nm}: ci sono tre modi di dividerle in due piani: ${a}. Una regola lega queste tre caselle: se ne conosci due, la terza è fissata.`,
        points: [
          [['checked'], `Controllato da un computer, esattamente, per ${Object.keys(K.gv.identities).join(', ').replace(/, (\d+)$/, ' e $1')} direzioni: la piegatura rispetta lo stesso tipo di regole del campo di Maxwell. Il conteggio dei numeri liberi coincide con un secondo conteggio fatto in un altro modo.`],
          [['open'], 'Questo passo non ha un’equazione che dica come la materia piega lo spazio. Arriva dopo, e la sua forza non è calcolata.'],
          [['open'], 'La regola di come girano le frecce non è ricavata dalle frecce stesse. Il modo usuale di farlo è noto, ma qui non è costruito.']
        ]
      },
      title: 'Gravità, prima metà: il riferimento, la sua connessione e la sua curvatura',
      lede: 'Qui la gravità è disegnata come il passo 4 ha disegnato un campo di gauge, con i bivettori di Lorentz del passo 1 come algebra di gauge. L’algebra del riferimento è Cl(1, n−1) (un asse di tempo). La connessione di spin ω ha una 1-forma per ogni bivettore, la curvatura è R = dω + ¼[ω,ω] (il passo 4 con g = ½), e la tetrade e ha una 1-forma per ogni vettore, con torsione T = de + ωe. Le forme sono la stessa regola dei bit con ogni generatore nullo, quindi il segno di un prodotto esterno e il segno di una permutazione sono il prodotto nullo dell’assioma A. Saliamo da n = 2 e leggiamo ogni vista.',
      numbers: 'Aritmetica esatta (numeri razionali, campi polinomiali) per le identità a n = 2…5 e per i conteggi a n = 2…8; algebra lineare per lo spazio delle curvature a n = 2…7; matrici gamma e tensori espliciti (numpy) come controllo indipendente.',
      tableH: 'La scala', cols: ['n', 'algebra del riferimento', 'bivettori (boost + rotazioni)', 'componenti di ω', 'tetrade', 'componenti della curvatura', 'componenti della torsione', 'curvatura indipendente', 'relazioni della prima identità di Bianchi', 'Ricci + Weyl'],
      pickH: 'Scegli una dimensione dello spazio-tempo', pick: 'n assi, uno dei quali è il tempo',
      picH: 'La tabella delle componenti della curvatura',
      picCap: n => `Ogni cella è una coppia non ordinata di piani (a b | c d). ${planes(n).length} piani, ${planes(n).length * (planes(n).length + 1) / 2} celle. Diagonale: i due piani sono lo stesso. Un asse in comune: i piani non commutano, sono uniti da uno spigolo del grafo dei commutatori del passo 1 (uno spigolo a distanza 2 del demicubo). Nessun asse in comune: i piani commutano (distanza 4). Scegli una classe per vedere dove stanno le sue celle${n >= 4 ? ', oppure scegli quattro assi per vedere le tre celle che una relazione della prima identità di Bianchi lega insieme' : ''}.`,
      classes: { all: 'tutte', diagonal: 'stesso piano', one: 'un asse in comune', disjoint: 'nessun asse in comune' },
      classCap: (c, v) => (c === 'all' ? 'Sono mostrate tutte le celle.' : `${v} celle di questa classe.`),
      subLabel: 'Quattro assi', subNone: 'nessuno scelto',
      subCap: (nm, a) => `Assi ${nm}: i tre modi di dividerli in due piani sono ${a}. La relazione R(ab|cd) + R(ac|db) + R(ad|bc) = 0 lega esattamente queste tre celle.`,
      viewsH: n => `Tutte le viste a n = ${n}`,
      views: r => {
        const n = r.n_value, G = r.bivectors, cs = CS[n];
        const cl = { h: 'Clifford', t: `L’algebra del riferimento è Cl(1,${n - 1}) = ${r.frame_algebra}, e la sua metà pari è ${r.even_half}. I bivettori sono i generatori di Lorentz del passo 1: ${G} in tutto, ${r.boosts} boost (un piano con l’asse del tempo) e ${r.rotations} rotazion${pe(r.rotations, 'e', 'i')}. La connessione di spin ha ${r.omega_components} componenti (${G} bivettori × ${n} direzioni), la tetrade ${r.tetrad_components}, la curvatura ${r.curvature_components} (${G} bivettori × ${C2(n)} piani) e la torsione ${r.torsion_components} (${n} vettori × ${C2(n)} piani). L’algebra di Poincaré aggiunge ${n} traslazioni: ${r.poincare_generators} generatori.`, tags: ['checked', 'standard'] };
        const cu = { h: 'Cubo e demicubo', t: `La curvatura è una tabella indicizzata da coppie non ordinate di piani. Stesso piano: ${r.pair_classes.diagonal}. Un asse in comune: ${r.pair_classes.share_one_index}, gli spigoli del grafo dei commutatori del passo 1, gli spigoli a distanza 2 del demicubo. Nessun asse in comune: ${r.pair_classes.disjoint}, le coppie che commutano${n === 4 ? ', che a n = 4 sono le 3 coppie antipodali della 16-cella, come nel passo 1' : ''}. Le tre classi insieme sono ${r.pair_classes.diagonal + r.pair_classes.share_one_index + r.pair_classes.disjoint} celle.`, tags: ['checked', 'ours'] };
        const si = { h: 'Simplesso', t: r.first_bianchi_constraints === 0 ? `Con ${n} assi non c’è nessun insieme di quattro, quindi la prima identità di Bianchi non aggiunge relazioni alle celle una volta usata la simmetria per coppie: ${r.riemann_independent} component${pe(r.riemann_independent, 'e indipendente', 'i indipendenti')}.` : `Quattro assi formano un tetraedro, e i suoi tre modi di dividere i quattro vertici in due coppie sono le tre celle senza assi in comune. La prima identità di Bianchi è una relazione tra queste tre celle per ogni insieme di quattro assi: ${r.first_bianchi_constraints} in tutto (le facce 3-dimensionali del ${n - 1}-simplesso). Le celle meno le relazioni danno ${r.pair_classes.diagonal + r.pair_classes.share_one_index + r.pair_classes.disjoint} − ${r.first_bianchi_constraints} = ${r.riemann_from_classes}, uguale a n²(n²−1)/12 = ${r.riemann_independent}${cs ? ', lo stesso numero che dà l’algebra lineare sull’identità completa' : ''}.`, tags: ['checked', 'ours'] };
        const la = { h: 'Etichette', t: `I piani sono nominati dai loro assi (tx, ty, xy, …) e il commutatore di due piani con un asse in comune è il piano degli altri due, a meno del segno: la differenza simmetrica delle etichette. Contrarre R^{bc}_{ce} su c somma le celle il cui primo piano contiene b: ${cs ? `la parte di Ricci ha rango ${cs.ricci_rank}${n >= 3 ? ' (una matrice n × n simmetrica)' : ''} e il resto, la parte di Weyl, ha ${cs.weyl_dimension} component${pe(cs.weyl_dimension, 'e', 'i')}` : 'la decomposizione di Ricci e Weyl non è calcolata a questo n'}. Le etichette sono solo notazione.`, tags: ['checked', 'standard'] };
        const ma = { h: 'Maxwell', t: `${G === 1 ? 'Qui c’è un solo generatore, quindi R = dω è esattamente l’F = dA di Maxwell e D R = 0 è l’identità dF = 0 della pagina di Maxwell.' : `Con un solo generatore R sarebbe l’F = dA di Maxwell e la seconda identità di Bianchi dF = 0 è la regola della pagina di Maxwell. Con ${G} generatori diventa D R = 0 con D la derivata covariante.`} Controllato esattamente su campi polinomiali casuali a n = ${n <= 5 ? n : '2…5'}${n <= 5 ? '' : ' (non eseguito a questo n)'}.`, tags: n <= 5 ? ['checked'] : ['standard'] };
        const ym = { h: 'Yang–Mills (passo 4)', t: `R è l’intensità di campo del passo 4 per i ${G} bivettori, con g = ½ e la segnatura di Cl(1,${n - 1}) al posto di quella euclidea. L’identità di Bianchi e la covarianza di gauge al primo ordine si trasferiscono: una trasformazione di Lorentz locale λ cambia ω di Dλ e R di [R, λ], ed è esatto a n = ${n <= 5 ? n : '2…5'}${n <= 5 ? '' : ' (non eseguito a questo n)'}. La tetrade non è un campo di gauge: è una 1-forma a valori vettoriali con D T = R ∧ e, la prima identità di Bianchi, anch’essa esatta.`, tags: n <= 5 ? ['checked', 'standard'] : ['standard'] };
        const di = { h: 'Dirac', t: `Sugli spinori ω agisce con ½ω^A B_A, per moltiplicazione a sinistra come i generatori interni del passo 5. Il commutatore di due derivate covarianti è [D, D]ψ = ½Rψ: esatto a n = ${n <= 5 ? n : '2…5'}${n <= 5 ? '' : ' (non eseguito a questo n)'}, e con matrici esplicite fino a n = 6 (errore ${merrNote}), nella rappresentazione spinoriale e in quella vettoriale. L’equazione di Dirac su una tetrade curva non è disegnata qui.`, tags: n <= 5 ? ['checked', 'open'] : ['standard', 'open'] };
        return [cl, cu, si, la, ma, ym, di];
      },
      idH: 'Identità esatte', idCols: ['n', 'D R = 0', 'D T = R ∧ e', 'covarianza di Lorentz locale', '[D, D]ψ = ½Rψ'],
      idNote: 'Seconda Bianchi: la derivata covariante della curvatura si annulla. Prima Bianchi: la derivata covariante della torsione è R ∧ e. Covarianza: ω → ω + Dλ cambia R di [R, λ]. Spinori: il commutatore delle derivate covarianti è ½R che agisce per moltiplicazione a sinistra. Tutto su campi polinomiali casuali (termini di derivata inclusi), in aritmetica razionale esatta.',
      xrH: 'Che cosa ogni vista insegna alle altre',
      xr: [
        [['standard', 'checked'], 'Cubo → simplesso. La prima identità di Bianchi è una relazione per ogni insieme di quattro assi (la parte Λ⁴ della tabella della curvatura), e i conteggi coincidono con l’algebra lineare sull’identità completa per n = 2…7.'],
        ['ours', 'La stessa tabella di coppie di piani, letta due volte: le sue classi come spigoli e antipodi del demicubo, e ogni insieme di quattro assi come un tetraedro del simplesso degli assi (nostra lettura).'],
        [['standard', 'checked'], 'Passo 4 → gravità. Curvatura, identità di Bianchi e covarianza sono il passo 4 per l’algebra dei bivettori; la novità è il secondo tipo di indice: la tetrade, che porta la torsione.'],
        [['standard', 'checked'], 'Passo 5 → gravità. I generatori agiscono sugli spinori per moltiplicazione a sinistra, come i generatori interni agivano sull’indice T: [D, D]ψ = ½Rψ qui è [D, D]Ψ = gFΨ là.'],
        [['standard', 'checked', 'ours'], 'È la gravità al primo ordine (di Cartan). La lettura della tabella della curvatura per coppie di piani e per il demicubo è nostra; la dimensione di Riemann n²(n²−1)/12 e la decomposizione di Ricci e Weyl sono da manuale.']
      ],
      matH: 'Controllo indipendente con matrici',
      mat: `Con matrici gamma di Jordan–Wigner (numpy) le costanti di struttura dei bivettori e dell’azione bivettore–vettore coincidono con quelle della regola dei bit a n = 2…6. Per connessioni costanti, la curvatura costruita dalle costanti coincide con il commutatore della connessione nella rappresentazione vettoriale e ½R coincide con il commutatore nella rappresentazione spinoriale (errore ${merrNote}). Lo spazio delle curvature è ricostruito con la SVD e la metrica: stesse dimensioni, simmetria per coppie e rango di Ricci a n = 2…7. Le versioni sbagliate falliscono: una matrice gamma con il quadrato sbagliato, e la prima identità di Bianchi tolta (36 componenti invece di 20 a n = 4, e nessuna simmetria per coppie).`,
      open: [
        ['open', 'Questo passo non ha equazione di campo. La forma di Einstein viene dopo, e viene senza un accoppiamento derivato.'],
        [['standard', 'open'], 'Niente qui fa di ω una funzione di e. Risolvere T = 0 per ω (la solita connessione di Levi-Civita) è standard ma non è costruito qui.']
      ],
      dl: { h: 'Verificalo tu', text: 'Due file Python. Il primo (solo libreria standard) ricostruisce i conteggi, le identità e lo spazio delle curvature, esattamente. Il secondo (richiede numpy, e il primo file e gravity.json accanto) confronta con matrici esplicite e fa girare versioni sbagliate che devono fallire.', py: 'Scarica gravity_selfcheck.py', py2: 'Scarica gravity_matrix_check.py', json: 'Scarica gravity.json', cmd: 'python3 gravity_selfcheck.py --compare gravity.json   ·   python3 gravity_matrix_check.py --compare gravity_matrix.json' }
    },
    g2: {
      yl: {
        name: 'GRAVITÀ, SECONDA PARTE: L’EQUAZIONE DI EINSTEIN',
        title: 'Gravità, seconda parte: l’equazione di Einstein, pezzo per pezzo',
        pickH: 'Scegli un numero di direzioni', pick: 'Quante direzioni? Una di esse è il tempo.',
        picH: 'I pezzi dell’equazione', aLabel: 'Scegli una direzione',
        picCap: n => (n < 3 ? 'Con 2 direzioni non c’è un’equazione di Einstein: ogni pezzo richiede tre direzioni diverse.' : `L’equazione ha una parte per ognuna delle ${n} direzioni: scegline una (è cerchiata in rosso). Ogni linea è una coppia delle altre ${n - 1} direzioni e forma un pezzo: la piegatura di quel piano${n > 4 ? `, con una freccia su ciascuna delle ${n - 3} direzioni che restano` : n === 4 ? ', con una freccia sulla direzione che resta' : ''}. ${lines2(n)} line${pe(lines2(n), 'a', 'e')}. Clicca una linea.`),
        capNone: 'Nessun pezzo scelto.', capSel: (b, c, rest) => `Pezzo ${b}${c}: la piegatura del piano ${b}${c}${rest.length ? `, e una freccia su ${andList(rest, 'e')}` : ', e nessuna freccia'}.`,
        points: [
          [['checked'], 'Controllato da un computer, esattamente, per 3, 4 e 5 direzioni: quando le frecce non si torcono, ciò che alimenta l’equazione non si crea e non si perde mai. Quando le frecce sono quelle semplici della griglia, è esattamente la solita equazione di Einstein.'],
          [['checked', 'standard'], 'La spinta o l’attrazione dello spazio vuoto può venire da una direzione in più, e il suo segno è l’opposto del segno del quadrato di quella direzione (+1 o −1). Questa costruzione è nota; l’abbiamo controllata.'],
          [['open'], 'Quanto forte la materia pieghi lo spazio, e con quale segno, non è calcolato: qui non c’è un principio più profondo che lo fissi.'],
          [['open'], 'Niente è risolto: con questi pezzi non si costruisce nessuna forma dello spazio.']
        ]
      },
      title: 'Gravità, seconda metà: la forma di Einstein e la sua conservazione',
      lede: 'L’equazione di Einstein al primo ordine usa solo la tetrade e la curvatura: E_a = Σ_{b<c} ε_{abcd…} F^{bc} ∧ e^d ∧ …, una (n−1)-forma con F^{bc} = R^{bc} + c e^b ∧ e^c (c è un termine cosmologico). Il simbolo ε è il segno del prodotto nullo dell’assioma A, lo stesso segno del prodotto esterno. Ogni termine ha la curvatura e n−3 tetradi. Disegniamo dove stanno i termini, controlliamo che cosa sia D E_a, controlliamo che E_a sia il tensore di Einstein, e leggiamo il termine cosmologico come un generatore in più.',
      numbers: 'Aritmetica esatta su campi polinomiali casuali per D E_a (n = 3, 4, 5) e per la curvatura di de Sitter (n = 3, 4); contrazione di tensori con segni di permutazione e matrici esplicite (numpy) per il tensore di Einstein (n = 3…5) e per le costanti di de Sitter (n = 3…5).',
      tableH: 'La scala', cols: ['n', 'componenti di E', 'termini in ogni E_a', 'tetradi in ogni termine', 'termini di torsione in D E_a', 'generatori con un termine cosmologico', 'le loro componenti di curvatura'],
      pickH: 'Scegli una dimensione dello spazio-tempo', pick: 'n assi, uno dei quali è il tempo',
      picH: 'Dove stanno i termini di E_a',
      picCap: n => `Scegli l’indice a di E_a (l’asse cerchiato). Ogni linea è una coppia {b, c} degli altri ${n - 1} assi: un termine, con la curvatura F^{bc} e una tetrade su ciascuno dei ${n - 3} assi restanti. ${(n - 1) * (n - 2) / 2} linee. Clicca una linea per vedere gli assi che portano le tetradi.`,
      aLabel: 'Indice a', capNone: 'Nessun termine selezionato.', capSel: (b, c, rest) => `Termine {${b}, ${c}}: la curvatura F^{${b}${c}} e ${rest.length === 0 ? 'nessuna tetrade' : `una tetrade su ${rest.join(', ')}`}.`,
      viewsH: n => `Tutte le viste a n = ${n}`,
      views: r => {
        const n = r.n_value, ok = n >= 3, cd = n >= 3 && n <= 5, ds = n === 3 || n === 4;
        const cl = { h: 'Clifford', t: ok ? `E_a è una (n−1)-forma a valori nei vettori: ${r.einstein_components} componenti. Il simbolo ε_{abcd…} è il segno della permutazione, ed è il segno che produce il prodotto nullo dell’assioma A. Ogni termine è la curvatura di un piano (b c) per una tetrade per ogni altro asse.` : 'A n = 2 il simbolo ε richiede tre assi distinti e ce ne sono solo due: nessuna forma di Einstein, e il tensore di Einstein in due dimensioni è zero (standard).', tags: ['checked', 'standard'] };
        const cu = { h: 'Cubo e demicubo', t: ok ? `Una (n−1)-forma ha le sue componenti sugli n vertici accanto al vertice pieno dell’n-cubo (tutti gli assi tranne uno): ${n} vertici, e con l’indice a, ${r.einstein_components} componenti. L’immagine sopra mette i termini sulle coppie {b, c}, spigoli del simplesso degli assi sugli altri ${n - 1} assi.` : 'Nessuna forma di Einstein a n = 2.', tags: ok ? ['checked'] : ['standard'] };
        const si = { h: 'Simplesso', t: ok ? `A a fissato i termini sono gli spigoli del simplesso sugli altri ${n - 1} assi: ${r.einstein_terms_per_component}. Ogni termine ha ${n - 3} tetrad${pe(n - 3, 'e', 'i')}, quindi sostituendo a turno una tetrade con la torsione si hanno ${r.divergence_torsion_terms_per_component} termini in D E_a che contengono T, con c = 0${n === 3 ? ': nessuno, e D E_a = 0 identicamente' : ''}. Contati dalla definizione di E_a.` : 'Nessun termine.', tags: ok ? ['checked'] : ['standard'] };
        const la = { h: 'Etichette', t: ok ? (cd ? `A e^a = dx^a, E_a è il tensore di Einstein G^μ_a = Ric^μ_a − ½Sδ^μ_a, con Ric^b_e = Σ_c R^{bc}_{ce} e S la sua traccia: il rapporto è esattamente 1 con queste convenzioni di segno, per una curvatura arbitraria (non solo con simmetrie di Riemann), esattamente a n = ${n} e con una contrazione indipendente con segni di permutazione. Ricci da solo, o un coefficiente della traccia pari a 1, darebbe un rapporto variabile.` : 'A e = dx la forma di Einstein è il tensore di Einstein Ric − ½Sδ per costruzione; il controllo esatto è stato eseguito solo a n = 3, 4, 5 (non eseguito a questo n).') : 'Nessun tensore di Einstein in due dimensioni.', tags: cd ? ['checked', 'standard'] : ['standard'] };
        const ma = { h: 'Maxwell', t: ok ? `L’equazione di Maxwell impone che la sorgente sia conservata, perché dd = 0. Qui D E_a è uguale ai termini di torsione e nient’altro${cd ? `, esattamente su campi casuali con e senza termine cosmologico (n = ${n})` : ' (non eseguito a questo n)'}. A torsione nulla E è conservata, per qualunque curvatura. È l’identità di Bianchi contratta, standard. Una sorgente in E_a = κ(sorgente) deve quindi essere conservata anch’essa; è la stessa imposizione dei passi 3 e 4.` : 'Niente da conservare a n = 2.', tags: cd ? ['checked', 'standard'] : ['standard'] };
        const ym = { h: 'Yang–Mills (passo 4)', t: ds ? `Un generatore in più con quadrato s = ∓1 dà ${dsName(n, 'dS').group === 'de Sitter' ? 'de Sitter' : dsName(n, 'dS').group} (s = −1) o anti-de Sitter (s = +1): ${r.desitter_generators} generatori, lo stesso numero dell’algebra di Poincaré, e ${r.desitter_curvature_components} componenti di curvatura. Si mette ω sui primi ${n} generatori e κe su quelli nuovi. La curvatura è (R − sκ² e ∧ e, κT): il termine cosmologico ha il segno di meno il quadrato del generatore extra: +κ² e∧e (k = ${dsName(n, 'dS').coefficient_of_e_wedge_e}) per s = −1 e −κ² e∧e (k = ${dsName(n, 'AdS').coefficient_of_e_wedge_e}) per s = +1. Esatto su campi casuali a n = 3, 4; con matrici a n = 3, 4, 5.` : `Un generatore in più di quadrato s dà so(1,n) o so(2,n−1): ${r.desitter_generators} generatori, ${r.desitter_curvature_components} componenti di curvatura, lo stesso numero del passo 4 a m = ${n + 1} con un’altra segnatura. ${n === 5 ? 'Le costanti k = −s e μ = 1 sono controllate con matrici a questo n; il controllo polinomiale esatto è stato eseguito a n = 3, 4.' : 'Non eseguito a questo n.'}`, tags: ds || n === 5 ? ['checked', 'standard'] : ['standard'] };
        const di = { h: 'Dirac', t: 'La sorgente di E_a sarebbe l’energia-impulso costruita da ψ e dalla tetrade. Non l’abbiamo costruita, e non abbiamo un’azione, quindi grandezza e segno dell’accoppiamento κ sono aperti. Il passo 6 ha dato la curvatura spinoriale [D, D]ψ = ½Rψ.', tags: ['open'] };
        return [cl, cu, si, la, ma, ym, di];
      },
      idH: 'Identità esatte',
      idCols: ['n', 'termine cosmologico c', 'D E_a = solo termini di torsione', 'E a e = dx è il tensore di Einstein'],
      idNote: 'La prima identità è esatta su ω ed e polinomiali casuali (derivate incluse), usando la seconda identità di Bianchi. A n = 3 con c = 0 ogni termine di torsione è assente e D E_a = 0 identicamente. La seconda è il rapporto tra E e il tensore di Einstein, controllato a n = 3, 4, 5 con c = 0.',
      dsH: 'Il termine cosmologico come generatore in più',
      dsCols: ['n', 'il generatore extra ha quadrato', 'gruppo', 'e ∧ e nella curvatura', 'torsione nella curvatura'],
      dsNote: 'La curvatura di ω più κe sui generatori nuovi è R + k κ² e∧e nei primi n generatori e μκT in quelli nuovi; k e μ sono elencati a κ = 1. Esatto su campi polinomiali, e con matrici esplicite fino a n = 5.',
      xrH: 'Che cosa ogni vista insegna alle altre',
      xr: [
        [['standard', 'checked', 'ours'], 'Simplesso → Clifford. Il segno del termine cosmologico è l’opposto del segno del quadrato di un generatore extra (k = −s; assioma B, polarizzazione): la scelta tra de Sitter e anti-de Sitter è la scelta di un segno. È un’osservazione sull’immersione nota, non un risultato nuovo.'],
        [['standard', 'checked'], 'Maxwell, passo 3 e passo 4 → gravità. In ciascuno una sorgente deve essere conservata perché l’identità di Bianchi del campo lo impone. Qui l’identità di Bianchi compare come D E_a = termini di torsione.'],
        [['standard', 'checked'], 'Passo 6 → passo 7. La curvatura e la tetrade del passo 6 sono gli unici ingressi della forma di Einstein; la torsione entra solo attraverso D E_a.'],
        [['standard', 'ours'], 'È la gravità di Einstein–Cartan al primo ordine con l’immersione di MacDowell–Mansouri. Le immagini e la lettura con la regola dei bit sono nostre; le identità sono da manuale, e abbiamo controllato soltanto che la nostra ricostruzione sia giusta.']
      ],
      matH: 'Controllo indipendente con matrici',
      mat: 'E_a a e = dx è ricostruita con una contrazione di tensori con segni di permutazione, non con maschere di bit: il rapporto con il tensore di Einstein è 1 a n = 3, 4, 5. Due versioni sbagliate falliscono: Ricci al posto del tensore di Einstein, e un coefficiente della traccia pari a 1 invece di ½ (il rapporto allora varia). Il generatore extra è costruito come matrice gamma di quadrato s: il commutatore di due generatori di tipo vettoriale è −2s volte il generatore del piano, quindi k = −s per ogni n = 3, 4, 5 e per entrambi i segni di s, e μ = 1; cambiando il segno del quadrato cambia k.',
      open: [
        ['open', 'L’equazione di campo con la materia: l’accoppiamento κ e il segno della sorgente non sono derivati. Non c’è un’azione.'],
        ['open', 'Soluzioni. Qui non si risolve nessuna equazione di campo, e T = 0 non viene risolta per ω. Il passo 16 prende dalla letteratura la soluzione di Schwarzschild, nelle forme di Painlevé–Gullstrand e di Kerr–Schild, come scorrimenti (shear) del riferimento e ne ricostruisce la metrica dal riferimento.']
      ],
      dl: { h: 'Verificalo tu', text: 'Gli stessi due file Python del passo 6 (contengono entrambi i passi).', py: 'Scarica gravity_selfcheck.py', py2: 'Scarica gravity_matrix_check.py', json: 'Scarica gravity.json', cmd: 'python3 gravity_selfcheck.py --compare gravity.json   ·   python3 gravity_matrix_check.py --compare gravity_matrix.json' }
    }
  }
};
export default COPY;
