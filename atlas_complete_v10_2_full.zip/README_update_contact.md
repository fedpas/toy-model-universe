# Update: a contact form with a human check

Requested: "add a contact form, with some human check, to get in touch". Decided before the work: delivery goes through a **form service** (a server-side POST of JSON to an endpoint URL, Formspree-style), and the human check is **our own puzzle**, not a third-party captcha. The owner's e-mail address is never in the page, the source, the tests or these notes: it lives only in the form service's own settings (and, if the service puts it in the endpoint URL, in an environment variable of the host).

## What it is
| File | What it does |
|---|---|
| `api/contact.js` | Edge route. `GET /api/contact?lang=en\|it` hands out a puzzle and a signed token; `POST /api/contact` checks the human check and forwards one message to the form service. |
| `lib/contactGuard.js` | The helpers: puzzles, token, honeypot, minimum fill time, rate limiter, field validation, origin check, body cap. Only Web Crypto (`crypto.subtle`) is used, so it runs on the Vercel edge and on Node 19+ (Node 18 needs `--experimental-global-webcrypto`). |
| `contactCopy.js` | All the text of the form, English and Italian, same keys on both sides. |
| `ContactForm.jsx` | The dialog. Opened by a plain **Contact / Contatti** button in the footer (next to the credit link). |
| `App.jsx` | Three small edits: the import, one `useState`, the footer button and `<ContactForm/>`. Nothing else in the footer changed. |
| `test_contact.mjs`, `test_contact_mutation.mjs`, `test_contact_ui.mjs` | Tests, see the end. |

## Settings (environment of the host)
| Variable | Meaning |
|---|---|
| `FORMSPREE_ENDPOINT` | **Required.** The form service's endpoint, an `https://` URL. Anything else (missing, `http://`, not a URL) counts as "not configured". |
| `CONTACT_SECRET` | **Required.** A random string of at least 16 characters; it signs the puzzle tokens and is never sent anywhere. Make one with `openssl rand -base64 32`. Changing it invalidates the puzzles on screen (visitors just get a new one). |
| `CONTACT_RATE_PER_HOUR` | Optional. Messages per client and hour. Default 3. |
| `CONTACT_GLOBAL_PER_HOUR` | Optional. Messages per instance and hour. Default 40. |
| `CONTACT_ALLOWED_ORIGINS` | Optional. Comma list of extra origins allowed to POST (for a second domain). `CHAT_ALLOWED_ORIGINS` is read too, so one list can serve the chat and the form. |

If `FORMSPREE_ENDPOINT` or `CONTACT_SECRET` is unusable, both GET and POST answer `503 {"error":"not_configured"}`, and the form says "The contact form is not set up on this copy of the site yet." The answer never says which of the two is missing.

## Creating the form (Formspree, or any service that takes a JSON POST)
1. In the service's dashboard create a new form and enter **the address that should receive the messages there**. That is the only place it goes.
2. Copy the form's endpoint. For Formspree it looks like `https://formspree.io/f/<form id>`.
3. In the host's project settings add `FORMSPREE_ENDPOINT` (that URL) and `CONTACT_SECRET` (a fresh random string), then redeploy.
4. Send a test message from the site. Look at how the service shows it (the fields are `message`, `name`, `_replyto`, `lang` and `page`, the last one always `cascade-atlas`), and set its notification and spam-filter options to taste.

What the route sends: `POST <endpoint>`, headers `content-type: application/json` and `accept: application/json`, body `{"message", "name", "_replyto", "lang", "page":"cascade-atlas"}`, with a 10 second timeout. A name or address the visitor left empty is left out of the JSON. Any 2xx answer counts as delivered; anything else, a network error or a timeout becomes `502 {"error":"delivery_failed"}`. A different service works if it accepts that request; the field names are the only thing to check. If a service wants the recipient in the URL, that URL is the value of `FORMSPREE_ENDPOINT`: it is read from the environment only, and never returned or logged.

## What happens on a POST, in this order
method, then origin (the page's own host, an entry of the allow-lists, or a same-origin browser fetch without an Origin header; no CORS header is ever sent), then JSON content type, then the body (at most 16 KB, read as it arrives), then the settings, then the **honeypot**, then the **token and the answer**, then the **minimum fill time**, then the **rate limit**, then the fields, then forwarding. `GET` is not origin-checked: a puzzle is handed to anyone, and the token proves nothing by itself.

| Code (JSON `error`) | Status | When |
|---|---|---|
| `method_not_allowed` / `forbidden` / `unsupported_media_type` / `too_large` / `bad_request` | 405 / 403 / 415 / 413 / 400 | the first checks |
| `not_configured` | 503 | a setting is unusable |
| `rejected` | 400 | the hidden field `website` was filled |
| `bad_token` / `expired` / `wrong_answer` / `replayed` | 400 | the puzzle: not ours, older than 10 minutes, wrong (a changed token reads the same: the signature covers the answer), already used |
| `too_fast` | 400 | under 4 seconds since the puzzle was issued; the same puzzle works a moment later |
| `rate_limited` | 429 + `Retry-After` | the client or the instance has used its hour |
| `invalid_message` / `invalid_name` / `invalid_reply` | 400 | message not 10 to 2000 characters after trimming, name over 100, address over 200 or not shaped like an address (`lang` must be `en` or `it`, else `bad_request`; any other field is ignored) |
| `delivery_failed` | 502 | the form service refused, failed or did not answer |
| (none) `{"ok":true}` | 200 | delivered |

Control characters, line and paragraph separators, bidi overrides and the byte-order mark are stripped; a message keeps its line breaks. Answers are fixed codes: nothing from upstream, from the message, from an address or from a secret is ever returned, and the log gets a status number or an error name at most (nothing from the message, no address, no key, not even the endpoint).

A message that fails validation does **not** use up the puzzle or the client's allowance; a delivery that fails does (the nonce is spent before the call goes out, and the page asks for a new question).

## The human check: what it does and does not stop
The puzzle is a short question about the atlas bit rule (the index of `e_a · e_b` is `a XOR b`; also the missing index of a product, the product of three, the number of grade-k parts C(n,k), the number of generators after adding some, and how the basis doubles). Answers are small whole numbers, there are no sign questions, the text is English or Italian, and the one-line hint is shown with it.

*Re-test T1-8 (dated 2026-10-05):* a reader on the **Young Learner** audience (the default) now gets the same kind of check in plain words: the page asks `GET /api/contact?lang=..&aud=yl`, and the route draws from four plain kinds ("What is 5 XOR 3?", "5 XOR w = 6, what is w?", how many boxes one more switch gives, how many pairs of switches), with a plain hint (write each number as a sum of 1, 2, 4 and 8; XOR keeps the parts in only one of the two). `aud` is checked against a fixed list (only `yl`); any other value, or none, gives the usual puzzles, which the Physicist and the Mathematician keep. The route stays stateless: only the answer is signed, so the POST check is the same for both sets. *Re-test T1-9:* the message box no longer has `maxLength` (HTML counts UTF-16 units there, so an emoji counted twice); the counter, the check before sending and the route count characters.

It is **a friendly check for a person, not a lock. A script that can compute an XOR can pass it**, and so can anyone who reads this file. What it adds is cost and friction, together with the other measures, none of which is strong alone:
- **Honeypot**: a field named `website`, hidden from sight, from the keyboard (`tabindex=-1`) and from screen readers (`aria-hidden`), with autocomplete off. Anything in it is refused. (Refused openly, not silently: some browsers and password managers fill a field called "website", and a visitor must not think a lost message was sent.)
- **Minimum fill time** of 4 seconds, measured from the token.
- **Signed, short-lived token**: `base64url(nonce) . expiry . base64url(HMAC-SHA256(secret, nonce|expiry|answer))`, valid 10 minutes. The server stores nothing, and the answer is never sent to the browser.
- **One token, one message**: a used nonce is remembered until it expires.
- **Rate limits**: 3 messages per client and hour, 40 per instance and hour (settings above), bounded tables, `429` with `Retry-After`.
- **The form service's own spam filter**, which is the real last line.

## Limits, said plainly
- The counters (rate limits, used nonces) live in **one edge instance**, in memory. Another instance, or a restart, has its own. So the limits are per instance and best effort: a script that spreads over instances is not held to 3 an hour, and a token used on one instance could be used once more on another. The cost of a message to the owner is bounded by the form service's plan, not by this code.
- The client is told apart by `x-real-ip`, then `x-vercel-forwarded-for`, then the first `x-forwarded-for` entry (the chat does the same). On a host that does not set these itself, a caller can vary them. Visitors with no usable address share one bucket called `unknown`.
- The Origin header and the client address can be set by whoever sends the request; the origin rule keeps other web pages from using a visitor's browser, not scripts.
- Puzzle requests (`GET`) are not rate limited here; the host's own limits apply.
- **The site stores no message, no address and no answer.** Each message is held in memory for the length of one request. The form service stores messages under **its own terms** (retention, who can read them, where): read them before putting the form into use.
- The intro on the form says so in one sentence: your message goes to the authors through a form service; we only use your address to answer you; do not send anything private. It does not promise an answer.

## What the form never does
No cookies. No `localStorage`, `sessionStorage` or IndexedDB (the draft lives in memory and is dropped on reload). No script, font, image or frame from another site, and no request except to `/api/contact` on the page's own origin. No e-mail address in the source: there is no `mailto:` link anywhere. No tracking of the visitor beyond the rate limiter's in-memory counter.

## The dialog
`role="dialog"`, `aria-modal`, labelled by its title and described by the intro; the focus moves in (to the message field) and goes back to the footer button on close; Tab and Shift+Tab stay inside; Escape closes (not while a message is being sent); every field has a real `<label>`; errors are announced with `role="alert"`; progress ("Sending…", "A new question is ready.") goes to a polite live region; focus rings are visible; at 320 px there is no horizontal scroll and the page behind is locked while it is open. A draft survives an accidental close until the page is reloaded or the message is sent. On a wrong or expired answer the page shows the sentence and loads a new question.

## Tests (run from the folder with the sources)
- `test_contact.mjs` (360 checks, mocked form service, no network, no secret): the six puzzle kinds (3000 random puzzles, each solved again by an independent solver that reads the English and the Italian text and must agree with the generator; extreme random numbers; no sign questions); the token (round trip, every tamper, another secret, wrong and malformed answers, malformed tokens, expiry to the millisecond, replay, simultaneous replay, 4 s boundary); the helpers (configuration, settings, client key, limiter, bounded tables, fields, control characters); the route step by step **in the order it runs** (each step checked against the ones before and after it); the forwarded JSON byte for byte; the failure paths (500, 429, network error, timeout); both rate limits and their windows; and that no secret, endpoint, owner address, message or client address appears in any response or log line. Also the copy (same keys and placeholders in EN and IT, the same hint as the route, the same limits) and the source files (no Node-only API, no CORS header, no storage, no e-mail address outside `example.*` placeholders, the footer wiring).
- `test_contact_mutation.mjs` (36 deliberate breakages: skip the MAC compare, drop the expiry, ignore the honeypot (route and helper), drop the origin check, leak the answer, allow replay (two ways), drop the rate limit (route, per client, per instance), skip the minimum fill time (and set it to 0), accept `http://`, accept a one-character secret, change the XOR rule, keep control characters, reuse one nonce, log the message or the endpoint, echo the upstream status, forward unknown fields, allow caching, send a CORS header, name the missing setting, drop the timeout, ...). Each is applied to a temporary copy; `test_contact.mjs` must fail on each. The package files are compared by checksum before and after, and the temporary folder is removed (also on Ctrl-C). Set `CONTACT_MUT_TMP` to choose where it works.
- `test_contact_ui.mjs` (browser, faked `/api/contact`, English and Italian at 1100 px and 375 px, plus 320 px wide at two heights): footer link and the rest of the footer, dialog semantics, labels, the honeypot, Tab trap and focus rings, Escape and focus back, client-side checks, a wrong answer (new puzzle, answer cleared and focused, message kept), the right answer (exact POST body, thanks, form emptied), the sentence for each error code (too fast, expired, bad token, replayed, rate limit with minutes, not configured, delivery failed, rejected, invalid fields, unknown code, 403, network), the sending state, a puzzle route that is down or not configured, no request to another site, no cookie or storage, no overflow or page error. I also broke `ContactForm.jsx` and `App.jsx` on purpose in 22 ways, one at a time, and ran this test on each (by hand, with a throwaway script that is not part of the package): no Escape, no focus given back, no Tab trap, no `aria-modal`, a visible honeypot, a wrong answer that keeps the old question, "too fast" that replaces it, no `role="alert"`, a question that cannot wrap (overflow at 320 px), no focus on opening, a label that points nowhere, a rate-limit sentence without minutes, a second click while sending, Escape while sending, no scroll lock, no focus on the thanks, a form not emptied after success, no puzzle request on opening, no numeric keypad, an untrimmed answer, the last question showing when the dialog opens again, and the footer button not wired or always in English. All 22 fail the test. (A first "fixed 560 px dialog" survived, because the flex layout shrinks it: the page is robust there, so that breakage was replaced by the one that really overflows.) That run also found two real faults in the form, fixed here: the "name too long" sentence showed the message limit (2000) instead of 100, and the question and answer of the last visit could show for an instant when the dialog was opened again.
- `test_map_ui.mjs` (renders the footer) still passes.

- Re-test additions (2026-10-05): `test_contact.mjs` now also checks the Young Learner's puzzles (2000 drawn, solved by the independent solver, no technical word in EN or IT, the plain hint the same on the route and the page, `aud` values not on the list give the usual puzzles, a plain puzzle passes the same POST), look-alike origins (`evil-atlas.example`, `atlas.example.evil.com`, ...) refused, and `credentials: 'omit'` on both fetches of the form, call by call; `test_contact_ui.mjs` checks the Young Learner's GET (`&aud=yl`), plain hint and dialog text, a Physicist pass with the usual puzzle and hint, and 1500 typed emoji kept whole with the counter at 1500.

## For the owner, before this goes live
1. Create the form at the service and enter your address there (not in any file of this package).
2. Set `FORMSPREE_ENDPOINT` and `CONTACT_SECRET` on the host and redeploy; until then the form says it is not set up.
3. Send yourself a test message in English and in Italian, and check what the service shows.
4. Read the service's terms on what it stores, and switch on its spam filter.
5. Decide whether 3 an hour per client and 40 per instance suit you (`CONTACT_RATE_PER_HOUR`, `CONTACT_GLOBAL_PER_HOUR`).
