// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The reader filter (v10.2; readerFilter.js, the Settings group, the page notice). Without a browser: the definitions (known ground = standard AND checked,
// neither ours nor open; a plain citation = standard alone), the setting off | known | known+std and its order (?filter=, then atlas.filter, then off),
// and, when a claims table is at hand (claimsData.js in the package, or ATLAS_CLAIMS=<file>), that its "known" column is this definition.
// In the browser: a first visit shows everything; every tag on every page and tab (three audiences, folds and rows open) sits in a line the filter knows
// (or in a place it leaves alone on purpose: the tally, the legend, a Map branch); switching the filter on in Settings hides lines on the equations page,
// and every line it hides is known ground (by the tags in it), the lines with a standard tag alone stay, the tally rows stay; the second switch hides the
// plain citations too; the notice of the page and the count in Settings say exactly how many lines the DOM hides; "Show them" shows everything again;
// the setting survives a reload, works from the address and with blocked storage, in English and Italian.   Run: node test_filter_ui.mjs
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';
import { APP_HTML, PKG } from './paths.mjs';
import { setLang, tab } from './ui_helpers.mjs';
import * as RF from './readerFilter.js';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const info = m => console.log('  ' + m);

// ---- 0. without a browser
ok(JSON.stringify(RF.FILTERS) === '["off","known","known+std"]' && RF.DEFAULT_FILTER === 'off' && RF.FILTER_KEY === 'atlas.filter', 'settings off | known | known+std, default off, key atlas.filter');
ok(RF.validFilter('known std') === 'known+std' && RF.validFilter('known+std') === 'known+std' && [null, '', 'on', 'Known', 'std'].every(v => RF.validFilter(v) === null), 'the three values only ("known std" is how ?filter=known+std arrives)');
const mem = o => ({ getItem: k => (k in o ? o[k] : null), setItem: (k, v) => { o[k] = v; } }), blocked = { getItem() { throw new Error('blocked'); } };
const P = (s, st) => { const r = RF.pickFilter(s, st); return r.filter + '/' + r.from; };
ok(P('', null) === 'off/default' && P('?filter=known', mem({ 'atlas.filter': 'off' })) === 'known/url' && P('', mem({ 'atlas.filter': 'known+std' })) === 'known+std/storage' && P('?filter=x', mem({ 'atlas.filter': 'x' })) === 'off/default' && P('', blocked) === 'off/default', 'order: address, then storage, then off; wrong values ignored; blocked storage throws nowhere');
const TT = [[['standard', 'checked'], true, false], [['checked', 'standard'], true, false], [['standard'], false, true], [['checked'], false, false], [['standard', 'checked', 'ours'], false, false], [['standard', 'checked', 'open'], false, false], [['standard', 'open'], false, false], [['ours'], false, false], [[], false, false], ['standard checked', true, false]];
ok(TT.every(([f, k, p]) => RF.isKnownGround(f) === k && RF.isPlainCitation(f) === p && RF.hiddenBy('known', f) === k && RF.hiddenBy('known+std', f) === (k || p) && RF.hiddenBy('off', f) === false), 'known ground = standard and checked, neither ours nor open; plain citation = standard alone; what each setting hides');
const CLAIMS = process.env.ATLAS_CLAIMS ? path.resolve(process.env.ATLAS_CLAIMS) : fs.existsSync(path.join(PKG, 'claimsData.js')) ? path.join(PKG, 'claimsData.js') : null;
let claims = null;
if (CLAIMS) { claims = (await import(pathToFileURL(CLAIMS).href)).CLAIMS;
  const off = claims.filter(c => RF.isKnownGround(c.flags) !== !!c.known);
  ok(claims.length > 0 && off.length === 0, `claims (${claims.length} in ${path.basename(CLAIMS)}): the known column is this definition: ${off.map(c => c.id).join(' ')}`);
  info(`claims: ${claims.filter(c => c.known).length} known ground, ${claims.filter(c => RF.isPlainCitation(c.flags)).length} plain citations, of ${claims.length}`);
} else info('claims: no claimsData.js in the package and no ATLAS_CLAIMS: the claims cross-check is skipped');

// ---- the browser
const b = await chromium.launch();
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => { if (m.type() === 'error') ok(false, `${tag}: console error ${m.text()}`); }); };
const url = (q, hash) => APP_HTML + (q ? '?' + q : '') + '#' + hash;
const rf = pg => pg.evaluate(() => document.querySelector('main')?.getAttribute('data-rf'));
const stored = pg => pg.evaluate(() => { try { return localStorage.getItem('atlas.filter'); } catch { return 'blocked'; } });
const openSettings = async pg => { if (!(await pg.locator('.story-nav .settings').evaluate(e => e.open))) { await pg.locator('.story-nav .settings > summary').click(); await pg.waitForTimeout(80); } };
const closeSettings = pg => pg.evaluate(() => { const d = document.querySelector('.story-nav .settings'); if (d) d.open = false; });
const choose = async (pg, v) => { await openSettings(pg); await pg.locator(`.story-nav .settings [data-rf-choice="${v}"]`).click(); await pg.waitForTimeout(250); };
const tabsOf = pg => pg.locator('.tabbar [data-tab]').evaluateAll(es => es.map(e => e.dataset.tab));
const openAll = pg => pg.evaluate(() => { document.querySelectorAll('main details').forEach(d => { if (!d.closest('.story-nav')) d.open = true; }); document.querySelectorAll('main button[aria-expanded="false"]').forEach(x => { if (!x.closest('.story-nav')) x.click(); }); });
// the display of every element of <main> now (kept on the element itself, as a property: nothing is written into the page)
const remember = pg => pg.evaluate(() => { document.querySelectorAll('main *').forEach(e => { e.__rfOff = getComputedStyle(e).display; }); });
// the lines hidden since remember(): elements that were displayed and are not now, the outermost only; each with the kinds of the tags it holds
const hiddenNow = pg => pg.evaluate(() => {
  const all = [...document.querySelectorAll('main *')].filter(e => e.__rfOff && e.__rfOff !== 'none' && getComputedStyle(e).display === 'none'), set = new Set(all);
  const top = all.filter(e => { for (let p = e.parentElement; p; p = p.parentElement) if (set.has(p)) return false; return true; });
  const kinds = e => { const ts = e.matches('.tag,.rn-tag') ? [e] : [...e.querySelectorAll('.tag,.rn-tag')]; return [...new Set(ts.flatMap(t => ['checked', 'standard', 'ours', 'open'].filter(k => t.classList.contains(k))))].sort(); };
  return top.map(e => ({ kinds: kinds(e), tally: !!e.closest('#eq-tally'), what: (e.className && typeof e.className === 'string' ? e.tagName.toLowerCase() + '.' + e.className.split(' ')[0] : e.tagName.toLowerCase()), text: (e.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 60) }));
});
const notice = pg => pg.evaluate(() => { const n = document.querySelectorAll('.rf-notice'); return n.length ? { n: n.length, count: Number(n[0].dataset.rfHidden), text: n[0].textContent } : { n: 0, count: 0, text: '' }; });
const popCount = async pg => { await openSettings(pg); await pg.waitForTimeout(150); return pg.evaluate(() => { const c = document.querySelector('.settings-pop .rf-count'); return c ? { known: Number(c.dataset.known), plain: Number(c.dataset.plain), text: c.textContent } : null; }); };
// visible lines whose tags are a lone "standard" (a strip entry, a point, a view, a paragraph or an item): they stay under the first switch
const plainVisible = pg => pg.evaluate(() => { const lines = new Set();
  for (const t of document.querySelectorAll('main .tag.standard')) { if (t.closest('#eq-tally, .page-tags details, .settings-pop') || !t.getClientRects().length) continue;
    const line = t.matches('.page-tags > .tag, .ls-glance .tag') ? t : t.closest('.eq-pt, .gs-pt, .sh-pt, .nl-res, .eq-xr, .gs-xr, .sh-xr, p, li'); if (!line) continue;
    const ks = new Set([...(line === t ? [t] : line.querySelectorAll('.tag'))].flatMap(x => ['checked', 'standard', 'ours', 'open'].filter(k => x.classList.contains(k)))); if (ks.size === 1) lines.add(line); }
  return lines.size; });

// ---- 1. coverage: every tag of every page and tab sits in a line of LINES, or in a place left alone on purpose
const LINE_SPECS = RF.LINES.map(([line, scope, extra = '']) => [line + extra, scope]);
// left alone on purpose: the tally (navigation), the legend of the tags, Settings, a page that filters itself, a branch of the Map tree (it holds other lines),
// and the status strip of a whole step (a div of tags only, directly under its section: it sums the step up, the step's lines carry their own tags)
const EXEMPT = '#eq-tally, .page-tags details, .settings-pop, [data-rf-own], details:not(.leaf) > summary, section > div:not(:has(> :not(.tag, .rn-tag)))';
const coverage = pg => pg.evaluate(([specs, exempt]) => {
  const covered = new Set();
  for (const [line, scope] of specs) for (const e of document.querySelectorAll('main ' + line)) { if (scope == null) covered.add(e); else e.querySelectorAll(':scope ' + scope.trim() + ' :is(.tag,.rn-tag)').forEach(t => covered.add(t)); }
  return [...document.querySelectorAll('main .tag, main .rn-tag')].filter(t => !covered.has(t) && !t.closest(exempt)).map(t => { let p = t.parentElement, sig = ''; for (let i = 0; i < 3 && p; i++, p = p.parentElement) sig += ' < ' + p.tagName.toLowerCase() + (typeof p.className === 'string' && p.className ? '.' + p.className.split(' ')[0] : ''); return t.className + sig; });
}, [LINE_SPECS, EXEMPT]);
const PAGES = ['rule', 'atlas', 'maxwell', 'furey', 'shapes', 'equations', 'labels', 'lenses', 'map', 'ask'];
let pagesSeen = 0, hiddenAll = 0; const RF_KNOWN = RF.isKnownGround, RF_PLAIN = RF.isPlainCitation;
for (const prof of ['Physicist', 'Young Learner', 'Mathematician']) {
  const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(a => { try { localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, prof);
  const pg = await ctx.newPage(); onErr(pg, 'coverage ' + prof);
  for (const p of PAGES) { await pg.goto(url('', p)); await pg.waitForTimeout(200); const subs = await tabsOf(pg); for (const sub of subs.length ? subs : [null]) {
    const link = p + (sub ? '/' + sub : ''); await pg.goto(url('', link)); await pg.waitForTimeout(250);
    for (let k = 0; k < 2; k++) { await openAll(pg); await pg.waitForTimeout(120); }
    const un = await coverage(pg); pagesSeen++;
    ok(un.length === 0, `${prof} #${link}: every tag is in a line the filter knows; not: ${[...new Set(un)].slice(0, 4).join(' | ')}`);
    // what both switches would hide on this view (the attribute is set here for a moment, then put back): known ground and plain citations only, never a tally row
    await remember(pg); await pg.evaluate(() => document.querySelector('main').setAttribute('data-rf', 'known+std')); const h = await hiddenNow(pg); await pg.evaluate(() => document.querySelector('main').setAttribute('data-rf', 'off'));
    const wrong = h.filter(x => x.tally || !(RF_KNOWN(x.kinds) || RF_PLAIN(x.kinds)));
    ok(wrong.length === 0, `${prof} #${link}: both switches hide only known ground and plain citations (${h.length} lines): ${JSON.stringify(wrong.slice(0, 2))}`); hiddenAll += h.length;
  } }
  await ctx.close();
}
ok(pagesSeen >= 3 * 30 && hiddenAll > 0, `coverage: ${pagesSeen} views (all pages and tabs, three audiences); ${hiddenAll} lines hidden by both switches over them`);
// the researcher note (a pop-up over the page) too
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } }), pg = await ctx.newPage(); onErr(pg, 'note');
  await pg.goto(url('for=furey', 'equations')); await pg.waitForTimeout(400);
  ok(await pg.locator('.rn-dialog .rn-tag').count() > 0 && (await coverage(pg)).length === 0, 'the tags of a researcher note sit in lines the filter knows'); await ctx.close(); }

// ---- 2. a first visit shows everything; the switches on the equations page, tab by tab
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.audience', 'Physicist'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(); onErr(pg, 'switch');
  await pg.goto(url('', 'equations')); await pg.waitForTimeout(400);
  ok(await rf(pg) === 'off' && await stored(pg) === null && (await notice(pg)).n === 0, 'a first visit: main[data-rf="off"], nothing stored, no notice');
  await openSettings(pg);
  const grp = await pg.evaluate(() => { const g = [...document.querySelectorAll('.settings-pop [role=group]')].find(x => x.querySelector('[data-rf-choice]')); return g && [g.getAttribute('aria-label'), [...g.querySelectorAll('button')].map(x => [x.textContent, x.getAttribute('aria-pressed')])]; });
  ok(grp && grp[0] === 'Reader filter' && JSON.stringify(grp[1]) === JSON.stringify([['Show everything', 'true'], ['Hide known ground (standard and checked)', 'false'], ['Also hide plain citations', 'false']]), 'Settings has the Reader filter group: ' + JSON.stringify(grp));
  let total = 0, totalPlain = 0, tallySeen = 0; const EQ = await tabsOf(pg);
  for (const sub of EQ) {
    const tagT = 'equations/' + sub;
    await choose(pg, 'off'); await closeSettings(pg); await tab(pg, sub); await pg.waitForTimeout(150); for (let k = 0; k < 2; k++) { await openAll(pg); await pg.waitForTimeout(120); }
    await remember(pg);
    const stdBefore = await plainVisible(pg);
    await choose(pg, 'known');
    ok(await rf(pg) === 'known' && await stored(pg) === 'known', `${tagT}: the first switch sets main[data-rf="known"] and stores it`);
    const h = await hiddenNow(pg), nt = await notice(pg), pc = await popCount(pg);
    const notKnown = h.filter(x => !RF.isKnownGround(x.kinds));
    ok(notKnown.length === 0, `${tagT}: every hidden line is known ground by its own tags: ${JSON.stringify(notKnown.slice(0, 3))}`);
    ok(h.every(x => !x.tally), `${tagT}: no tally row is hidden`);
    ok(nt.count === h.length && (h.length ? nt.n === 1 : nt.n === 0), `${tagT}: the notice says ${nt.count} (${nt.n} notice), the DOM hides ${h.length}`);
    ok(pc && pc.known === h.length, `${tagT}: Settings counts ${pc && pc.known} lines of known ground, the DOM hides ${h.length}`);
    ok(await plainVisible(pg) === stdBefore, `${tagT}: the ${stdBefore} lines with a standard tag alone stay visible under the first switch`);
    if (h.length) ok(/^\d+ lines? of known ground (is|are) hidden on this page\.Show them$/.test(nt.text) && nt.text.startsWith(String(h.length)), `${tagT}: notice text "${nt.text}"`);
    total += h.length; const by = {}; h.forEach(x => { by[x.what] = (by[x.what] || 0) + 1; }); if (h.length) info(`${tagT}: hides ${h.length} (${Object.entries(by).map(([k, v]) => k + ' ' + v).join(', ')})`);
    await choose(pg, 'known+std'); await closeSettings(pg);
    const h2 = await hiddenNow(pg), nt2 = await notice(pg), pc2 = await popCount(pg), plain = h2.filter(x => RF.isPlainCitation(x.kinds)).length;
    ok(await rf(pg) === 'known+std' && h2.every(x => RF.isKnownGround(x.kinds) || RF.isPlainCitation(x.kinds)) && h2.every(x => !x.tally), `${tagT}: the second switch hides known ground and plain citations only, no tally row: ${JSON.stringify(h2.filter(x => !RF.isKnownGround(x.kinds) && !RF.isPlainCitation(x.kinds)).slice(0, 2))}`);
    ok(await plainVisible(pg) === 0 && h2.length === h.length + plain, `${tagT}: the second switch hides the plain citations as well (${h.length} + ${plain} = ${h2.length}; ${await plainVisible(pg)} left visible of ${stdBefore})`);
    ok(nt2.count === h2.length && pc2 && pc2.known + pc2.plain === h2.length, `${tagT}: notice ${nt2.count} and Settings ${pc2 && pc2.known}+${pc2 && pc2.plain} agree with the DOM (${h2.length})`);
    totalPlain += plain;
    if (sub === 'tally') { tallySeen = await pg.evaluate(() => [...document.querySelectorAll('#eq-tally tbody tr, #eq-tally .yl-tally-list li')].filter(r => r.getClientRects().length).length); }
  }
  ok(total > 0 && totalPlain > 0, `the first switch hides lines on the equations page: ${total} lines of known ground over ${EQ.length} tabs (and ${totalPlain} plain citations under the second)`);
  ok(tallySeen === 15, `the 15 tally rows stay visible with both switches on (${tallySeen})`);
  info(`equations page (Physicist): ${total} lines of known ground, ${totalPlain} plain citations`);
  // "Show them" in the notice shows everything again
  await closeSettings(pg); await tab(pg, 'coupling'); await choose(pg, 'known'); await closeSettings(pg); await pg.waitForTimeout(100);
  ok((await notice(pg)).n === 1, 'the coupling tab has a notice under the first switch');
  await pg.locator('.rf-notice .rf-show').click(); await pg.waitForTimeout(200);
  ok(await rf(pg) === 'off' && (await notice(pg)).n === 0 && await stored(pg) === 'off', '"Show them" switches the filter off (no notice, stored off)');
  await ctx.close(); }
// reload keeps the setting, then the Italian wording of the notice and of Settings. A context of its own and NO init script on purpose: in headless Chromium a script added with
// addInitScript that touches localStorage at the start of every page can make the browser lose the origin's storage on a reload (a plain page does the same, so it is the harness,
// not the app); the reader here picks the audience with the button, as a person does, and the page is reloaded as it is.
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  const pg = await ctx.newPage(); onErr(pg, 'reload');
  await pg.goto(url('', 'equations/coupling')); await pg.waitForTimeout(400);
  await pg.locator('[data-profile="Physicist"]').click(); await pg.waitForTimeout(150);
  await choose(pg, 'known'); const before = [await stored(pg), await pg.evaluate(() => location.hash)];
  await pg.waitForTimeout(500);
  await pg.reload(); await pg.waitForFunction(() => document.querySelector('.rf-notice'), null, { timeout: 20000 }).catch(() => {});
  ok(await rf(pg) === 'known' && (await notice(pg)).n === 1, `the setting survives a reload (main[data-rf="${await rf(pg)}"], ${(await notice(pg)).n} notice; before the reload: stored ${before[0]}, ${before[1]})`);
  // Italian
  await setLang(pg, 'it'); await pg.waitForFunction(() => /terreno noto/.test(document.querySelector('.rf-notice')?.textContent || ''), null, { timeout: 20000 }).catch(() => {}); const ni = await notice(pg);
  ok(/^\d+ (righe di terreno noto sono nascoste|riga di terreno noto è nascosta) in questa pagina\.Mostrale$/.test(ni.text), 'Italian notice: ' + ni.text);
  await openSettings(pg); const gi = await pg.evaluate(() => { const g = [...document.querySelectorAll('.settings-pop [role=group]')].find(x => x.querySelector('[data-rf-choice]')); return [g.getAttribute('aria-label'), [...g.querySelectorAll('button')].map(x => x.textContent), g.querySelector('.rf-count')?.textContent]; });
  ok(gi[0] === 'Filtro del lettore' && JSON.stringify(gi[1]) === JSON.stringify(['Mostra tutto', 'Nascondi il terreno noto (standard e verificato)', 'Nascondi anche le sole citazioni']) && /^In questa pagina: \d+ righ[ae] di terreno noto, \d+ sol[ae] citazion[ei]\.$/.test(gi[2] || ''), 'Italian Settings group: ' + JSON.stringify(gi));
  await choose(pg, 'known+std'); const ni2 = await notice(pg);
  ok(/^\d+ (righe sono nascoste|riga è nascosta) in questa pagina: \d+ di terreno noto, \d+ sol[ae] citazion[ei]\.Mostrale$/.test(ni2.text) || ni2.n === 0, 'Italian notice, both switches: ' + ni2.text);
  await setLang(pg, 'en'); await choose(pg, 'off');
  await ctx.close(); }

// ---- 3. the address, blocked storage, and the cross-check with the claims table
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(() => { try { localStorage.setItem('atlas.audience', 'Physicist'); } catch { /* ignore */ } });
  const pg = await ctx.newPage(); onErr(pg, 'url');
  await pg.goto(url('filter=known', 'equations/coupling')); await pg.waitForTimeout(400);
  ok(await rf(pg) === 'known' && await stored(pg) === null && (await notice(pg)).n === 1, '?filter=known: on, not stored, the notice is there');
  await pg.goto(url('filter=known+std', 'equations/coupling')); await pg.waitForTimeout(400);
  ok(await rf(pg) === 'known+std', '?filter=known+std (the + arrives as a space) works');
  if (claims) {
    // a claim of the equations page that is known ground and whose line carries the same tags on the page must be hidden; any other must be visible
    await pg.goto('about:blank'); await pg.goto(url('filter=known', 'equations')); await pg.waitForTimeout(400); const res = { hidden: 0, shown: 0, other: 0 };
    for (const sub of await tabsOf(pg)) { await tab(pg, sub); await openAll(pg); await pg.waitForTimeout(150);
      for (const c of claims.filter(x => x.group === 'EQN' && !x.tally)) for (const line of c.en || []) {
        const r = await pg.evaluate(t => { const e = [...document.querySelectorAll('main .eq-pt, main p, main li')].find(x => (x.textContent || '').includes(t)); if (!e) return null; const ln = e.closest('.eq-pt') || e;
          return { shown: ln.getClientRects().length > 0, kinds: [...new Set([...ln.querySelectorAll('.tag')].flatMap(t2 => ['checked', 'standard', 'ours', 'open'].filter(k => t2.classList.contains(k))))].sort() }; }, line.text.slice(0, 22));
        if (!r) continue; const same = JSON.stringify(r.kinds) === JSON.stringify([...line.flags].sort());
        if (same) { ok(r.shown === !RF.isKnownGround(line.flags), `claims: ${c.id} "${line.text.slice(0, 40)}" (${line.flags}) is ${r.shown ? 'shown' : 'hidden'}`); res[r.shown ? 'shown' : 'hidden']++; } else res.other++;
      } }
    info(`claims on the equations page: ${res.hidden} hidden, ${res.shown} shown as their flags say; ${res.other} lines whose tags on the page differ from the claims table (the statement agents' flags not merged yet)`);
  }
  await ctx.close(); }
{ const ctx = await b.newContext({ viewport: { width: 1100, height: 900 } });
  await ctx.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('storage blocked'); } }); });
  const pg = await ctx.newPage(); onErr(pg, 'blocked');
  await pg.goto(url('', 'equations/coupling')); await pg.waitForTimeout(400);
  await choose(pg, 'known'); await closeSettings(pg); await pg.locator('.tabbar [data-tab="ym"]').click(); await pg.waitForTimeout(250);
  ok(await rf(pg) === 'known', 'blocked storage: the filter can be switched on and holds while the reader moves');
  await ctx.close(); }
await b.close();
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL FILTER UI TESTS PASS'); process.exit(bad ? 1 : 0);
