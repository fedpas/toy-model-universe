# Update v10 (since v9): Steps 15–17 as a live page

This is a **quick roll-in**, as asked: the work of "Steps 15–17" (labels, gauge gravity, finite groups) is wired into the atlas as page 7 with live pictures. It is not the polished version; the list "Not done" says what was left for the next update. It is an update over v9 and is applied the same way (`BUILDING.md`).

## What is new

**Page 7, "Labels · gravity · groups"** (between *More equations* and *Map*; the Map and Ask pages are now 8 and 9, "PAGE k OF 9"). Three tabs, numbered **STEP 15, 16, 17 OF 17**, continuing the fourteen equation steps. Every picture is computed in the browser by `labelsEngine.js` from the bit rule (blades are bit masks, product by XOR with the sign rule); nothing is a stored image.

| Tab | Live pictures | What they show |
|---|---|---|
| 15 Clock · trinity | **Cell lattice + clock wheel** (45 cells, n ≤ 8, click one) · **Trinity** (a spring slider and three generator sliders, a phase portrait with a moving point, the cone picture) · **Bivector lab at n = 4** (five signatures, six sliders, presets, the (S, W) plane, a 400-bivector count per signature) | the clock c = p − q mod 8 read from a Gauss sum; the type and size of every cell; Cl(p,q) inside Cl(n+2,0); the sign of X² sorting ellipses / parallel lines / hyperbolas, and the sign of a spring being the type; two numbers instead of one from n = 4, complex roots only in Cl(2,2) |
| 16 Gauge gravity | **Horizon**: light cones in Painlevé–Gullstrand coordinates, a falling raindrop, a position slider, a "reverse time" switch · **Curvature bars** for n = 2…8 | the flow vector squaring to g² − 1 (−1 outside, 0 on the horizon, +1 inside); the cones tilting through the horizon; Riemann = Ricci + Weyl with Weyl first non-zero at n = 4 |
| 17 Finite groups | **Two rails** (W(E_n) mod 2 against O(Q) of Cl(n,0), S_{n+1} against O(Q) of Cl(0,n), log-scale bars) · **Golay code** (weights, a 24-point ring where any five points pick one octad) · **Primes by rung** (a slider and the Monster primes on a number line) | E-rail fills O(Q) for n = 3…8, S-rail only for n = 2…5; the Steiner system S(5,8,24) found live; the rung where each prime first enters |

Each tab has the same status strip as the other steps (checked / standard / ours / open), the script that checks it, and a sentence on what is established and what is not. The Young Learner sees the pictures with plain words; formulas, signatures and group names are folded away (`Formal.jsx`). English and Italian throughout.

Files added: `labelsEngine.js`, `labelsCopy.js`, `LabelsWidgets.jsx`, `LabelsSection.jsx`, `test_labels.mjs`, `test_labels_ui.mjs`; `selfcheck/steps15_17/{labels_check,gtg_check,groups_check,bitcliff,permgroup}.py`, `selfcheck/steps15_17/logs/`, `selfcheck/steps15_17/run_mutations.py` (in a subfolder so that the Map's count of the 26 scripts of `selfcheck/` stays what it is).
Files changed: `App.jsx` (one import, one line), `storyCopy.js` (page list, copy, nav, tab label, the "next" and "before" sentences of the pages around it), `StoryShell.jsx` (`SUBS.labels`), `steps.js` (group `labels`, offset 14, total 17, the names), `audienceCopy.js` (the short readings), `lib/chatPersona.js` (the Ask model now knows page 7 and the status of each claim; about 2 400 characters).

## Tests

`test_labels.mjs` (new, 269 checks, about 50 s with the three scripts): the engine against the bit rule and against the logs of the three scripts (the 516 / 1616 / 64 trinity counts, (e12 + e34)² in three signatures, complex roots only in Cl(2,2), the horizon signs, the curvature rows, every row of the E and A rails, the Golay weights, every one of the 42 504 five-sets in exactly one octad, the primes by rung, the 91 clock cells, the 45 embeddings), the numbering 15–17 of 17, English/Italian copy of the same shape, the plain texts free of formula markup, and the known gap below. The engine and the copy were mutated 20 times (one edit each: the clock, the sign of I², the discriminant, the horizon square, the Golay generator, a rail number, the Weyl formula, the Gauss exponent, the embedding, the spring generator, the grid count, the ray slopes, the prime filter, the step offset, the copy shape, a formula in a plain text): 19 caught; the twentieth, a change in Italian prose, survives by design (prose is not tested). The 29 mutants of the three scripts were rerun from their place in this package: 29 caught.

`test_labels_ui.mjs` (new, 30 checks, under a minute, in a real browser): every widget is driven and the result is checked against the claim: a click on Cl(1,3) gives clock place 6 and Gauss phase 6 × 45°; the spring slider at +1 / 0 / −1 gives rotation / translation / boost; the bivector preset is complex in Cl(2,2) and not in Cl(4,0), and of 400 random bivectors per signature only Cl(2,2) has complex roots; the horizon slider at 3 / 1 / 0.5 gives outside / on the horizon / inside, and the time-reversal switch changes the raindrop; the curvature chips give Riemann 20 = Ricci 10 + Weyl 10 at n = 4 and Weyl 0 at n = 3; four points of the Golay ring leave no single octad, a fifth leaves exactly one (8 points lit); rung 11 shows the primes 23 (a Monster prime) and 89; plus the Mathematician introduction, the Young Learner at 375 px, and Italian.

Existing tests whose pinned expectation changes because there is now a page 7 (each edited, not weakened elsewhere): `test_audience` (the ids of the short readings), `test_equations` and `test_map` (page order), `test_map` (the "every page is on the tree" line excludes `labels`, with the reason in its message), `test_persona` (the step totals 14 and 17; the length limit 37 000 → 39 000 characters), `test_routes` (the budget test left a margin of 0.0912 against 0.09114 for the OpenAI reservation, a knife edge that the longer persona tipped; the margin is now half of the smaller reservation), `test_nav_ui` and `test_map_ui` (the Map is button 8 and "page 8 of 9" now; `test_nav_ui` also gets a check of the new page's deep link, tabs and Next), `test_i18n_audit` (the new page is in its list: English/Italian, three audiences, "STEP 15–17 OF 17"), `test_story` (no edit: the `map.before` sentence keeps naming step 14 as the end of the equations page).

Results of the final full run (`sh run_tests.sh`): see RESULTS_LINE below.

## Not done (deliberately, to be quick)

- **The Map tree has no node for the new page** (`mapData.js`, `mapCopy.js`). Consequences: the page has its own status strip instead of the Map-fed one, and the "Where this sits on the Map" button goes to the top of the Map, not to a branch. `test_labels.mjs` pins this gap (it fails when someone adds the nodes, as a reminder to remove that line).
- **The browser test of the new page is a first version**: it drives every widget once, but it does not cover the keyboard (Tab / Enter on the cells and the ring), nor every audience × language × width combination (`layout_check` covers overflow of the three new deep links at 320 / 375 / 1280 px in both languages and all audiences, and `test_yl_ui` the formula-free Young Learner text at 1100 / 375 px).
- **The Italian is mine and unreviewed**; the plain (Young Learner) texts were written once and not tested with a reader.
- **Genesis wording is not touched** (decided: later, once the picture is clearer). Only the scope sentences already agreed are in the new page; the other scope sentences (D1, D3, D4, D5) of the chapter are not yet put into the existing pages.
- The independent blind replications, the cross-check by the second model and the mutation records are in the chapter package (`cascade_steps15_17.zip`) and are not repeated here; only the three scripts, their logs and the mutation harness are.
- Honest limits of the content itself are on each tab (and in the chapter): the 0 label is a translation in the generator algebra and in the projective picture, a null rotation on the vectors of a non-degenerate cell; the field equations of the gauge theory of gravity are not decoded; groups over more than two elements, the exceptional families and most sporadic groups are not reached; classes for n > 8 are checked as F₂ forms only.

## Run

```
sh build.sh                 # dist/app.html; open #labels, #labels/gauge, #labels/groups
sh run_tests.sh --data      # includes test_labels.mjs
cd selfcheck/steps15_17 && python3 labels_check.py && python3 gtg_check.py && python3 groups_check.py
cd selfcheck/steps15_17 && python3 run_mutations.py     # 29 mutants, about 4 minutes; not part of run_tests.sh
```

Licence: PolyForm Noncommercial 1.0.0, Copyright (c) 2026 the Cascade Atlas authors (every new file carries the header).
