#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T16: Dirac-type symbol determinants (lane C, independent code, exact arithmetic).
Asserts:
 A. regular module, every signature (p,q,r) with n <= 5: det L_{P - m} = (m^2 - Q(k))^{2^(n-1)} exactly, for random
    integer momenta (null components included: the determinant does not see them).
 B. det L_x on Cl(p,q,r) = (det L_xbar on Cl(p,q))^(2^r) for random integer x (xbar = drop labels with a null bit).
 C. explicit minimal real modules (Kronecker words of 1, sx, sz, eps found by search) for every Cl(p,q), n <= 5:
    det(P - m) = (m^2 - Q)^(N/2) when p + q >= 2 or the cell is Cl(0,1); Cl(1,0) on R gives k - m (the exception).
 D. Hestenes form (MAP-017, EQN-008): psi in Cl+(1,3) (8 dims) -> p psi + m psi gamma_0 (8 odd dims):
    det = sign * (p^2 - m^2)^4 with ONE fixed sign, p^2 = p0^2 - |p|^2.
 E. Cl(3,1) (time squares -1): real (Majorana) operator gamma.d - m on plane waves exp(i k.x): complex symbol
    i kslash - m has det_C = (m^2 + Q(k))^2, zero at E^2 = |k|^2 + m^2; the printed i gamma.d - m has symbol
    -kslash - m with det_C = (m^2 - Q(k))^2, zero at E^2 = |k|^2 - m^2 (F9).
Would fail if any determinant identity were off by a factor, a sign that changes with p, or a dependence on null momenta."""
import itertools
from fractions import Fraction
import numpy as np
from clC import Alg, det_frac, int_mat

rng = np.random.default_rng(16)
fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


def sigs(nmax):
    for n in range(1, nmax + 1):
        for r in range(0, n + 1):
            for q in range(0, n - r + 1):
                yield (n - q - r, q, r)


# ---------- A ----------
nsig = 0
for (p, q, r) in sigs(5):
    A = Alg.pq(p, q, r)
    nsig += 1
    for _ in range(2 if A.n == 5 else 4):
        k = [int(v) for v in rng.integers(-3, 4, A.n)]
        m = int(rng.integers(-3, 4))
        x = [0] * A.N
        x[0] = -m
        for i in range(A.n):
            x[1 << i] = k[i]
        Q = sum(A.eps[i] * k[i] ** 2 for i in range(A.n))
        d = det_frac(int_mat(A, x))
        ok(d == Fraction(m * m - Q) ** (2 ** (A.n - 1)), f'regular det {p,q,r} k={k} m={m}: {d}')
print(f'A: det L_(P-m) = (m^2 - Q)^(2^(n-1)) on the regular module, {nsig} signatures n <= 5 (null momenta included)')

# ---------- B ----------
for (p, q, r) in [(1, 0, 1), (0, 1, 1), (1, 1, 1), (2, 0, 1), (1, 0, 2), (0, 2, 1), (2, 1, 1), (3, 0, 1)]:
    A = Alg.pq(p, q, r)
    Ab = Alg.pq(p, q, 0)
    for _ in range(3):
        x = [int(v) for v in rng.integers(-2, 3, A.N)]
        mask = sum(1 << i for i in range(p + q))
        xb = [x[a] for a in range(Ab.N)]  # labels inside the first p+q bits = labels with no null bit
        d = det_frac(int_mat(A, x))
        db = det_frac(int_mat(Ab, xb)) if Ab.N > 1 else Fraction(xb[0])
        ok(d == db ** (2 ** r), f'det on Cl(p,q,r) = det on Cl(p,q)^(2^r) {p,q,r}')
print('B: det L_x(Cl(p,q,r)) = det L_xbar(Cl(p,q))^(2^r) for random integer x in 8 null signatures')

# ---------- C: minimal real modules by search over Kronecker words ----------
I2 = np.eye(2, dtype=np.int64)
SX = np.array([[0, 1], [1, 0]])
SZ = np.array([[1, 0], [0, -1]])
EP = np.array([[0, 1], [-1, 0]])
LET = [I2, SX, SZ, EP]


def kron_word(w):
    M = np.array([[1]])
    for c in w:
        M = np.kron(M, LET[c])
    return M


def find_rep(p, q):
    for L in range(0, 5):
        words = list(itertools.product(range(4), repeat=L))
        mats = [kron_word(w) for w in words]
        d = 2 ** L
        sq = {}
        for i, M in enumerate(mats):
            S = M @ M
            if np.array_equal(S, np.eye(d, dtype=np.int64)):
                sq[i] = 1
            elif np.array_equal(S, -np.eye(d, dtype=np.int64)):
                sq[i] = -1
        pos = [i for i in sq if sq[i] == 1 and not np.array_equal(mats[i], np.eye(d, dtype=np.int64))]
        neg = [i for i in sq if sq[i] == -1]

        def anti(i, j):
            return np.array_equal(mats[i] @ mats[j], -(mats[j] @ mats[i]))

        def extend(chosen, need_p, need_q, start_p, start_q):
            if need_p == 0 and need_q == 0:
                return chosen
            if need_p:
                for idx in range(start_p, len(pos)):
                    i = pos[idx]
                    if all(anti(i, j) for j in chosen):
                        res = extend(chosen + [i], need_p - 1, need_q, idx + 1, start_q)
                        if res:
                            return res
                return None
            for idx in range(start_q, len(neg)):
                i = neg[idx]
                if all(anti(i, j) for j in chosen):
                    res = extend(chosen + [i], 0, need_q - 1, start_p, idx + 1)
                    if res:
                        return res
            return None
        if L == 0:
            if p == 0 and q == 0:
                return []
            continue
        res = extend([], p, q, 0, 0)
        if res:
            return [mats[i] for i in res]
    return None


minimal_dims = {}
for n in range(1, 6):
    for q in range(n + 1):
        p = n - q
        gens = find_rep(p, q)
        ok(gens is not None, f'rep found {p,q}')
        d = gens[0].shape[0]
        minimal_dims[(p, q)] = d
        eps = [1] * p + [-1] * q
        for _ in range(4):
            k = [int(v) for v in rng.integers(-3, 4, n)]
            m = int(rng.integers(-3, 4))
            M = sum(k[i] * gens[i] for i in range(n)) - m * np.eye(d, dtype=np.int64)
            Q = sum(eps[i] * k[i] ** 2 for i in range(n))
            dt = det_frac(M.tolist())
            ok(dt == Fraction(m * m - Q) ** (d // 2), f'module det {p,q} d={d}')
print('C: smallest Kronecker-word modules found (real dimension):', minimal_dims)
# the textbook minimal real module dimensions for n <= 5 (recalled, Lawson-Michelsohn Table I.4.3) for comparison
expected = {(1, 0): 1, (0, 1): 2, (2, 0): 2, (1, 1): 2, (0, 2): 4, (3, 0): 4, (2, 1): 2, (1, 2): 4, (0, 3): 4,
            (4, 0): 8, (3, 1): 4, (2, 2): 4, (1, 3): 8, (0, 4): 8, (5, 0): 8, (4, 1): 8, (3, 2): 4, (2, 3): 8,
            (1, 4): 8, (0, 5): 8}
# Cl(1,0) = R + R has the 1-dim modules; the Kronecker search starts at 2x2 for n >= 1, so compare from dim 2
for kq, v in expected.items():
    if kq != (1, 0):
        ok(minimal_dims[kq] == v, f'minimal module dim {kq}: {minimal_dims[kq]} vs {v}')
# Cl(1,0) on R (dimension 1, e acts as +1): det(k e - m) = k - m, a proper factor of m^2 - k^2
for k0, m0 in [(2, 1), (3, -1), (0, 2)]:
    d1 = k0 - m0
    ok(d1 * d1 != (m0 * m0 - k0 * k0) or k0 == 0, 'Cl(1,0) 1-dim module: det^2 != (m^2-k^2) in general')
print('   Cl(1,0) on the 1-dim module e = +1: det(k e - m) = k - m (not (m^2 - k^2)^(1/2)): the only exception')

# ---------- D: Hestenes form ----------
A = Alg.pq(1, 3)   # bit 0 = gamma_0 (square +1), bits 1..3 = gamma_k (square -1)
even = [a for a in range(16) if bin(a).count('1') % 2 == 0]
odd = [a for a in range(16) if bin(a).count('1') % 2 == 1]
signs = set()
for _ in range(25):
    pv = [int(v) for v in rng.integers(-4, 5, 4)]
    m = int(rng.integers(-4, 5))
    Mx = [[0] * 8 for _ in range(8)]
    for c, b in enumerate(even):
        # p psi
        for i in range(4):
            s = int(A.S[1 << i, b])
            Mx[odd.index((1 << i) ^ b)][c] += s * pv[i]
        # m psi gamma_0
        s = int(A.S[b, 1])
        Mx[odd.index(b ^ 1)][c] += s * m
    d = det_frac(Mx)
    p2 = pv[0] ** 2 - pv[1] ** 2 - pv[2] ** 2 - pv[3] ** 2
    target = Fraction(p2 - m * m) ** 4
    ok(abs(d) == abs(target), f'Hestenes |det| p={pv} m={m}')
    if target != 0:
        signs.add(1 if d == target else -1)
ok(len(signs) == 1, 'one fixed sign of the Hestenes determinant')
print(f'D: Hestenes 8x8 symbol det = {signs.pop():+d} * (p^2 - m^2)^4 (25 random integer (p, m), one sign)')

# ---------- E: Cl(3,1) Majorana and the printed operator ----------
g = find_rep(3, 1)   # gamma_1..3 square +1, gamma_0 = last, square -1; real 4x4
G = [g[3], g[0], g[1], g[2]]  # index 0 = time
for _ in range(20):
    E = int(rng.integers(-5, 6))
    kv = [int(v) for v in rng.integers(-4, 5, 3)]
    m = int(rng.integers(1, 5))
    ks = E * G[0] + sum(kv[i] * G[i + 1] for i in range(3))   # kslash, Q = |k|^2 - E^2
    Q = sum(v * v for v in kv) - E * E
    # complex 4x4 as real 8x8: (i kslash - m) -> [[-m, -ks],[ks, -m]]
    Z = np.zeros((4, 4), dtype=np.int64)
    I4 = np.eye(4, dtype=np.int64)
    Re = -m * I4
    Im = ks
    big = np.block([[Re, -Im], [Im, Re]])
    dreal = det_frac(big.tolist())       # = |det_C|^2
    ok(dreal == Fraction(m * m + Q) ** 4, 'Majorana |det_C|^2')
    printed = (-ks - m * I4)
    dp = det_frac(printed.tolist())
    ok(dp == Fraction(m * m - Q) ** 2, 'printed operator det')
# the explicit shell: k = (0.3, -0.2, 0.5), m = 0.7
kv = np.array([0.3, -0.2, 0.5]); m = 0.7
Es = np.sqrt(kv @ kv + m * m)
ks = Es * G[0] + sum(kv[i] * G[i + 1] for i in range(3))
sym = 1j * ks - m * np.eye(4)
ok(abs(np.linalg.det(sym)) < 1e-12, 'Majorana zero at E = sqrt(k^2 + m^2)')
print(f'E: Cl(3,1): real operator shell E^2 = |k|^2 + m^2 (E = {Es:.4f} at k = (0.3,-0.2,0.5), m = 0.7); '
      'printed i*gamma.d - m: E^2 = |k|^2 - m^2')

print(f'check_T16: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
