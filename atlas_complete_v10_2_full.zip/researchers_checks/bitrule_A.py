# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""bitrule_A.py -- own minimal bit-rule engine for the lane-A checks (no atlas import).
e_a e_b = s(a,b) e_{a xor b}, s(a,b) = (-1)^{#(i in a, j in b, j<i)} prod_{i in a&b} eps_i.  Multivectors: dict mask -> Fraction/int."""
from fractions import Fraction

def popcount(x): return bin(x).count('1')

def N_pairs(a, b):
    c = 0; i = 0
    while a >> i:
        if (a >> i) & 1: c += popcount(b & ((1 << i) - 1))
        i += 1
    return c

class BR:
    def __init__(self, eps):
        self.eps = tuple(eps); self.n = len(eps); self.M = 1 << self.n
    def s(self, a, b):
        v = -1 if N_pairs(a, b) & 1 else 1
        m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v
    def mul(self, x, y):
        out = {}
        for a, ca in x.items():
            for b, cb in y.items():
                v = self.s(a, b)
                if v: out[a ^ b] = out.get(a ^ b, 0) + v * ca * cb
        return {k: v for k, v in out.items() if v != 0}
    def add(self, x, y, c=1):
        out = dict(x)
        for k, v in y.items(): out[k] = out.get(k, 0) + c * v
        return {k: v for k, v in out.items() if v != 0}
    def scal(self, x, c): return {k: c * v for k, v in x.items() if c * v != 0}
    def blade(self, a, c=1): return {a: c}
    def gen(self, i): return {1 << i: 1}
    def one(self): return {0: 1}
    def grade(self, x, k): return {a: v for a, v in x.items() if popcount(a) == k}
    def sq(self, a): return self.s(a, a)
    def word(self, gens, J):
        """product of the elements gens[j] for j in J (sorted)"""
        out = self.one()
        for j in sorted(J): out = self.mul(out, gens[j])
        return out

def anticomm(A, x, y): return A.add(A.mul(x, y), A.mul(y, x))
def comm(A, x, y): return A.add(A.mul(x, y), A.mul(y, x), -1)

def rank_fr(rows, ncols):
    """exact rank over Q of a list of dict-rows (mask -> coeff) in a space of ncols basis masks"""
    M = [[Fraction(r.get(c, 0)) for c in range(ncols)] for r in rows]
    rk = 0; col = 0; nr = len(M)
    while rk < nr and col < ncols:
        piv = next((i for i in range(rk, nr) if M[i][col] != 0), None)
        if piv is None: col += 1; continue
        M[rk], M[piv] = M[piv], M[rk]
        inv = 1 / M[rk][col]; M[rk] = [v * inv for v in M[rk]]
        for i in range(nr):
            if i != rk and M[i][col] != 0:
                f = M[i][col]; M[i] = [u - f * w for u, w in zip(M[i], M[rk])]
        rk += 1; col += 1
    return rk

def subsets(n):
    return range(1 << n)
