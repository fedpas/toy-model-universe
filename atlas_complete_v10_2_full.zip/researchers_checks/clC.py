#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Lane C's own bit-rule engine (independent of the atlas modules).
Blades are bitmasks a in [0, 2^n); e_a e_b = s(a,b) e_{a^b},
s(a,b) = (-1)^{#(i in a, j in b, j < i)} * prod_{i in a&b} eps_i, eps_i in {+1,-1,0}.
Multivectors are numpy float arrays (or object arrays of Fractions) of length 2^n."""
import numpy as np
from fractions import Fraction


def popcount(x):
    return bin(x).count('1')


def reorder_sign(a, b):
    """(-1)^{#(i in a, j in b, j < i)}"""
    s = 0
    a2 = a >> 1
    while a2:
        s += popcount(a2 & b)
        a2 >>= 1
    return -1 if s & 1 else 1


def sign(a, b, eps):
    s = reorder_sign(a, b)
    c = a & b
    i = 0
    while c:
        if c & 1:
            s *= eps[i]
            if s == 0:
                return 0
        c >>= 1
        i += 1
    return s


class Alg:
    def __init__(self, eps):
        self.eps = list(eps)
        self.n = len(eps)
        self.N = 1 << self.n
        N = self.N
        self.S = np.zeros((N, N), dtype=np.int64)
        for a in range(N):
            for b in range(N):
                self.S[a, b] = sign(a, b, self.eps)
        self.grade = np.array([popcount(a) for a in range(N)])

    @staticmethod
    def pq(p, q, r=0):
        return Alg([1] * p + [-1] * q + [0] * r)

    def mul(self, x, y):
        N = self.N
        z = np.zeros(N, dtype=np.result_type(x, y))
        nzx = np.nonzero(x)[0]
        nzy = np.nonzero(y)[0]
        for a in nzx:
            xa = x[a]
            for b in nzy:
                s = self.S[a, b]
                if s:
                    z[a ^ b] += s * xa * y[b]
        return z

    def blade(self, a, c=1.0, dtype=float):
        v = np.zeros(self.N, dtype=dtype)
        v[a] = c
        return v

    def scalar(self, c, dtype=float):
        return self.blade(0, c, dtype)

    def vec(self, coeffs, dtype=float):
        v = np.zeros(self.N, dtype=dtype)
        for i, c in enumerate(coeffs):
            v[1 << i] = c
        return v

    def gp(self, x, k):
        y = x.copy()
        y[self.grade != k] = 0
        return y

    def Lmat(self, x):
        """matrix of left multiplication y -> x y in the blade basis"""
        N = self.N
        M = np.zeros((N, N), dtype=np.result_type(x, float) if x.dtype != object else object)
        if x.dtype == object:
            M = np.array([[Fraction(0)] * N for _ in range(N)], dtype=object)
        for a in np.nonzero(x)[0]:
            for b in range(N):
                s = self.S[a, b]
                if s:
                    M[a ^ b, b] += s * x[a]
        return M

    def Rmat(self, x):
        """matrix of right multiplication y -> y x"""
        N = self.N
        M = np.zeros((N, N))
        for a in np.nonzero(x)[0]:
            for b in range(N):
                s = self.S[b, a]
                if s:
                    M[b ^ a, b] += s * x[a]
        return M

    def reverse(self, x):
        k = self.grade
        sg = np.where(((k * (k - 1)) // 2) % 2 == 1, -1, 1)
        return x * sg

    def bivector(self, B):
        """B: dict {(i,j): coeff} with i<j"""
        v = np.zeros(self.N)
        for (i, j), c in B.items():
            v[(1 << i) | (1 << j)] += c
        return v

    def bivec_index(self):
        return [(i, j) for i in range(self.n) for j in range(i + 1, self.n)]

    def wedge(self, x, y):
        """outer product: keep only terms with disjoint labels, same sign as the reorder sign"""
        z = np.zeros(self.N, dtype=np.result_type(x, y))
        for a in np.nonzero(x)[0]:
            for b in np.nonzero(y)[0]:
                if a & b == 0:
                    z[a | b] += reorder_sign(a, b) * x[a] * y[b]
        return z


def exp_mv(A, x, terms=40):
    """power series exp(x) in the algebra A (float)"""
    r = A.scalar(1.0)
    t = A.scalar(1.0)
    for k in range(1, terms):
        t = A.mul(t, x) / k
        r = r + t
    return r


def det_frac(M):
    """exact determinant of a square matrix of Fractions/ints by Gaussian elimination"""
    M = [[Fraction(v) for v in row] for row in M]
    n = len(M)
    d = Fraction(1)
    for c in range(n):
        p = None
        for r in range(c, n):
            if M[r][c] != 0:
                p = r
                break
        if p is None:
            return Fraction(0)
        if p != c:
            M[c], M[p] = M[p], M[c]
            d = -d
        d *= M[c][c]
        for r in range(c + 1, n):
            f = M[r][c] / M[c][c]
            if f:
                for k in range(c, n):
                    M[r][k] -= f * M[c][k]
    return d


def int_mat(A, x_int):
    """left-multiplication matrix with exact integer entries (x_int: list/array of ints)"""
    N = A.N
    M = [[0] * N for _ in range(N)]
    for a in range(N):
        if x_int[a]:
            for b in range(N):
                s = int(A.S[a, b])
                if s:
                    M[a ^ b][b] += s * x_int[a]
    return M
