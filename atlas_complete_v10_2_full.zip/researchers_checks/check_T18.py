#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""check_T18: null hypersurfaces, the horizon algebra, hyperbolicity (lane C, independent code).
 A. constant metrics of every signature (s, t) with n = 2..6 (and Lorentzian with random frames): the hyperplane
    ker(N) of a covector N is degenerate  <=>  g^{-1}(N, N) = 0; in the Lorentzian null case the induced form has
    signature (n-2 spacelike, 0, 1 null) and its radical is spanned by the vector g^{-1}N.
 B. Painleve-Gullstrand (signature +,-,-,-; g = sqrt(2M/r)): g^{rr} = g^2 - 1 exactly (Fractions), zero only at r = 2M;
    Schwarzschild and Eddington-Finkelstein give the same scalar g(dr, dr) = 1 - 2M/r up to the overall sign convention.
 C. regularity matters: Ellis wormhole ds^2 = -dt^2 + dl^2 + (b^2 + l^2) dOmega^2 with r = sqrt(b^2 + l^2):
    g(dr, dr) = l^2 / r^2 -> 0 at the throat, but dr = 0 there; with the regular function l, g(dl, dl) = 1 (timelike
    throat). Rotating flat space: g_tt = 0 on the light cylinder, which is timelike (g(d rho, d rho) = 1).
 D. static Killing identity on random static metrics (t, x, y): for xi = d_t, f = xi.xi:
    g^{-1}(df, df) = 2 f F with F = nabla_a xi_b nabla^a xi^b (finite-difference Christoffels).
 E. horizon algebra (atlas convention, time +1, space -1): the tangent space of a null hyperplane carries the form
    (0, n-2, 1): Cl(0, n-2, 1); the null-bit ideal J has J J = 0 and dim 2^(n-2), quotient Cl(0, n-2) with centre
    dimension 1, 2, 1, 2, 1 for n - 2 = 0..4 (R, C, H, H+H, M2(H)).
 F. hyperbolicity of a quadratic P (signature (s, t), n = 2..6): some h with P(h) != 0 makes k -> B(k,h)^2 - P(h)P(k)
    positive semidefinite (random search, 400 h) only when min(s, t) = 1; for Lorentzian P exactly the timelike h work."""
from fractions import Fraction
import numpy as np
from clC import Alg

rng = np.random.default_rng(18)
fails = 0
count = 0


def ok(cond, msg):
    global fails, count
    count += 1
    if not cond:
        fails += 1
        print('FAIL', msg)


def kernel_basis(N):
    n = len(N)
    _, _, Vt = np.linalg.svd(N.reshape(1, -1))
    return Vt[1:].T   # n x (n-1)


# ---------- A ----------
for n in range(2, 7):
    for t in range(0, n + 1):
        s = n - t
        G0 = np.diag([1.0] * s + [-1.0] * t)
        for _ in range(15):
            Fr = rng.normal(size=(n, n))
            G = Fr.T @ G0 @ Fr          # random metric of signature (s, t)
            Gi = np.linalg.inv(G)
            # a null covector if one exists, else random
            if 0 < s < n:
                # pick N = Fr^{-T}-image of a G0-null covector
                c = np.zeros(n); c[0] = 1; c[-1] = 1
                N = Fr.T @ c      # covectors transform with Fr^T; g^{-1} = Fr^{-1} G0^{-1} Fr^{-T}
                ok(abs(N @ Gi @ N) < 1e-8, 'constructed covector is null')
                K = kernel_basis(N)
                ind = K.T @ G @ K
                ev = np.linalg.eigvalsh(ind)
                ok(np.min(abs(ev)) < 1e-8 * max(1, np.max(abs(ev))), 'null covector => degenerate hyperplane')
                v = Gi @ N
                ok(abs(N @ v) < 1e-8, 'g^{-1}N lies in ker N')
                ok(np.allclose(G @ v @ K, 0, atol=1e-8), 'g^{-1}N is orthogonal to the hyperplane (radical)')
                if t == 1:
                    npos = int(np.sum(ev > 1e-8)); nneg = int(np.sum(ev < -1e-8))
                    ok((npos, nneg) == (n - 2, 0), f'induced signature (n-2, 0, 1) for (s,t)=({s},{t})')
                if s == 1:
                    npos = int(np.sum(ev > 1e-8)); nneg = int(np.sum(ev < -1e-8))
                    ok((npos, nneg) == (0, n - 2), 'induced signature (0, n-2, 1) in the time-positive convention')
            N = rng.normal(size=n)
            K = kernel_basis(N)
            dg = np.linalg.det(K.T @ G @ K)
            ok(abs(N @ Gi @ N) > 1e-6 and abs(dg) > 1e-10, 'generic covector: non-degenerate hyperplane')
print('A: ker N degenerate <=> g^{-1}(N,N) = 0, radical = g^{-1}N, Lorentzian induced form (n-2, 0, 1), n = 2..6')

# ---------- B ----------
for M in [Fraction(1), Fraction(5, 2)]:
    for r in [Fraction(1, 2), M, 2 * M, 3 * M, Fraction(17, 3)]:
        g2 = 2 * M / r
        # PG (t, r) block, signature +,-: ds^2 = dt^2 - (dr + g dt)^2 = (1 - g^2) dt^2 - 2 g dt dr - dr^2
        # inverse of [[1 - g^2, -g], [-g, -1]]: det = -(1 - g^2) - g^2 = -1 ; inverse = [[1, -g], [-g, g^2 - 1]]
        # verify with g^2 rational and g symbolic: entries of G * Ginv
        gtt, gtr, grr = 1 - g2, None, Fraction(-1)
        # products not involving g alone: (G Ginv)_tt = (1-g^2)*1 + (-g)(-g) = 1 ; (G Ginv)_rr = (-g)(-g) + (-1)(g^2-1) = 1
        ok((1 - g2) + g2 == 1 and g2 - (g2 - 1) == 1, 'PG inverse')
        grr_inv = g2 - 1
        ok((grr_inv == 0) == (r == 2 * M), 'g^rr = g^2 - 1 vanishes only at r = 2M')
        # Schwarzschild: g_rr = -1/(1 - 2M/r) -> g^rr = -(1 - 2M/r) = g^2 - 1
        if r != 2 * M:
            ok(-(1 - 2 * M / r) == grr_inv, 'Schwarzschild g(dr,dr) = PG g(dr,dr)')
        # Eddington-Finkelstein (v, r): ds^2 = (1 - 2M/r) dv^2 - 2 dv dr ; inverse rr = -(1 - 2M/r)
        Gef = [[1 - 2 * M / r, Fraction(-1)], [Fraction(-1), Fraction(0)]]
        det = Gef[0][0] * Gef[1][1] - Gef[0][1] * Gef[1][0]
        inv_rr = Gef[0][0] / det
        ok(inv_rr == grr_inv, 'EF g(dr,dr) = PG g(dr,dr)')
print('B: PG / Schwarzschild / EF: g(dr,dr) = g^2 - 1 = -(1 - 2M/r) (signature +---), zero only at r = 2M; dr != 0 there')

# ---------- C ----------
b = 1.3
for l in [-2.0, -0.5, 0.0, 0.4, 3.0]:
    r = np.sqrt(b * b + l * l)
    drdl = l / r
    ok(np.isclose(drdl ** 2 * 1.0, l * l / r / r), 'g(dr,dr) = (dr/dl)^2 g(dl,dl)')
ok(0.0 == 0.0 / np.sqrt(b * b), 'dr = 0 at the throat l = 0 (r is not a regular defining function there)')
# rotating flat space: metric in (t, rho, phi, z), Omega = 0.5
Om = 0.5
for rho in [1.0, 1 / Om, 3.0]:
    G = np.array([[-(1 - Om ** 2 * rho ** 2), 0, Om * rho ** 2, 0], [0, 1, 0, 0], [Om * rho ** 2, 0, rho ** 2, 0], [0, 0, 0, 1.]])
    Gi = np.linalg.inv(G)
    ok(np.isclose(Gi[1, 1], 1.0), 'g(d rho, d rho) = 1: rho = const is timelike')
    if rho == 1 / Om:
        ok(abs(G[0, 0]) < 1e-12, 'g_tt = 0 on the light cylinder')
print('C: Ellis throat (dr = 0) and the light cylinder (g_tt = 0, timelike) are not null: the criterion needs df != 0')

# ---------- D: static Killing identity ----------
def metric_fn(params):
    a1, a2, a3, b1, b2, b3, c1 = params
    def g(x):
        X, Y = x[1], x[2]
        T = 1.5 + 0.4 * np.sin(a1 * X + a2 * Y) + 0.2 * np.cos(a3 * X * Y)
        h11 = 1.2 + 0.3 * np.cos(b1 * X) + 0.1 * Y * Y
        h22 = 1.1 + 0.2 * np.sin(b2 * Y + b3 * X)
        h12 = c1 * np.sin(X + Y) * 0.2
        return np.array([[-T, 0, 0], [0, h11, h12], [0, h12, h22]])
    return g


def christoffel(g, x, eps=1e-4):
    n = 3
    dg = np.zeros((n, n, n))
    for c in range(n):
        e = np.zeros(n); e[c] = eps
        dg[c] = (g(x + e) - g(x - e)) / (2 * eps)
    Gi = np.linalg.inv(g(x))
    Gam = np.zeros((n, n, n))
    for a in range(n):
        for b_ in range(n):
            for c in range(n):
                Gam[a, b_, c] = 0.5 * sum(Gi[a, d] * (dg[b_][d, c] + dg[c][d, b_] - dg[d][b_, c]) for d in range(n))
    return Gam, dg


for _ in range(10):
    params = rng.uniform(0.3, 1.5, 7)
    g = metric_fn(params)
    x = np.array([0.0, rng.uniform(-1, 1), rng.uniform(-1, 1)])
    G = g(x); Gi = np.linalg.inv(G)
    Gam, dg = christoffel(g, x)
    xi_up = np.array([1.0, 0, 0])
    xi_low = G @ xi_up
    # nabla_a xi_b = d_a xi_b - Gam^c_{ab} xi_c ; xi_b(x) = g_{b t}(x)
    dxi = np.array([[dg[a][b_, 0] for b_ in range(3)] for a in range(3)])
    nab = dxi - np.einsum('cab,c->ab', Gam, xi_low)
    ok(np.allclose(nab + nab.T, 0, atol=1e-6), 'Killing: nabla xi antisymmetric')
    F = np.einsum('ab,ac,bd,cd->', nab, Gi, Gi, nab)
    f_grad = np.array([dg[a][0, 0] for a in range(3)])   # d(xi.xi) = d g_tt
    lhs = f_grad @ Gi @ f_grad
    ok(abs(lhs - 2 * G[0, 0] * F) < 1e-5 * max(1, abs(lhs)), f'(d xi^2)^2 = 2 xi^2 F: {lhs:.6g} vs {2 * G[0, 0] * F:.6g}')
print('D: static Killing identity g^{-1}(d xi^2, d xi^2) = 2 (xi.xi) F on 10 random static metrics (finite differences)')

# ---------- E ----------
for n in range(2, 7):
    k = n - 2
    A = Alg.pq(0, k, 1)   # k space-like (square -1), one null generator (the last bit)
    nb = 1 << k
    J = [a for a in range(A.N) if a & nb]
    ok(len(J) == 2 ** (n - 2), 'dim J = 2^(n-2)')
    ok(all(A.S[a, b] == 0 for a in J for b in J), 'J J = 0')
    Q = Alg.pq(0, k, 0)
    # centre dimension of the quotient
    C = np.zeros((Q.N * Q.N, Q.N))
    for x_ in range(Q.N):
        for y in range(Q.N):
            C[y * Q.N + (x_ ^ y), x_] += Q.S[x_, y] - Q.S[y, x_]
    cdim = Q.N - np.linalg.matrix_rank(C) if Q.N > 1 else 1
    ok(cdim == [1, 2, 1, 2, 1][k], f'centre of Cl(0,{k}) has dimension {cdim}')
print('E: horizon algebra Cl(0, n-2, 1): J^2 = 0, dim J = 2^(n-2), quotient Cl(0, n-2) with centres 1,2,1,2,1 (n = 2..6)')

# ---------- F ----------
def hyp_ok(G, h):
    Ph = h @ G @ h
    if abs(Ph) < 1e-9:
        return False
    Mq = np.outer(G @ h, G @ h) - Ph * G
    return np.linalg.eigvalsh(Mq).min() >= -1e-9


for n in range(2, 7):
    for t in range(0, n + 1):
        s = n - t
        G = np.diag([1.0] * s + [-1.0] * t)
        found = any(hyp_ok(G, h) for h in list(np.eye(n)) + [rng.normal(size=n) for _ in range(400)])
        ok(found == (min(s, t) == 1), f'hyperbolic direction exists for ({s},{t}): {found}')
        if t == 1 and s >= 1:
            for _ in range(50):
                h = rng.normal(size=n)
                Ph = h @ G @ h
                if abs(Ph) > 1e-6:
                    ok(hyp_ok(G, h) == (Ph < 0 or s == 1), 'Lorentzian: exactly the timelike h are hyperbolic (all non-null h when n = 2)')
print('F: a hyperbolic direction exists only for signatures (1, n-1) and (n-1, 1); for Lorentzian P exactly timelike h')
# ---------- G: Maxwell symbol kernel ----------
for (p, q) in [(1, 3), (3, 1), (1, 2), (1, 4)]:
    A = Alg.pq(p, q)
    n = p + q
    biv = [a for a in range(A.N) if A.grade[a] == 2]
    for _ in range(20):
        # null k: time-like unit plus a unit spatial vector (time = the single generator of the minority sign)
        u = rng.normal(size=n - 1); u /= np.linalg.norm(u)
        if p == 1:
            kv = np.concatenate([[1.0], u])
        else:
            kv = np.concatenate([u, [1.0]])
        k = A.vec(kv)
        ok(np.allclose(A.mul(k, k), 0), 'k null')
        Msym = np.array([A.mul(k, A.blade(b)) for b in biv]).T
        dimker = len(biv) - np.linalg.matrix_rank(Msym, tol=1e-9)
        ok(dimker == n - 2, f'Maxwell symbol kernel on bivectors has dim n - 2 at a null k ({p},{q})')
        kv2 = rng.normal(size=n)
        k2 = A.vec(kv2)
        if abs(A.mul(k2, k2)[0]) > 1e-3:
            Msym = np.array([A.mul(k2, A.blade(b)) for b in biv]).T
            ok(np.linalg.matrix_rank(Msym, tol=1e-9) == len(biv), 'non-null k: injective')
print('G: F -> kF on bivectors has kernel {k ^ a : a.k = 0} of dimension n - 2 exactly at null k (2 at n = 4)')
print(f'check_T18: {count - fails} of {count} assertions hold')
if fails:
    raise SystemExit(1)
