#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The numbers behind the five widgets of the category lens (step 18 of the atlas), checked exactly: integers and fractions, Python standard library only.

  python3 lens_cat_check.py                    run every check (one line each), exit 1 if one fails
  python3 lens_cat_check.py --write f.json     also write the data the widgets embed as "stored"
  python3 lens_cat_check.py --compare f.json   and check that the stored file equals what this run rebuilds

Blades are bit masks; generator i (bit i) squares to eps[i] in {+1, -1, 0}; Cl(p,q,r) puts p generators with square +1 first, then q with -1, then r with 0
(label 0 = a generator with square 0; the empty label is the unit 1).  e_a e_b = s(a,b) e_{a xor b}, s = (-1)^{#{i in a, j in b, j < i}} * prod_{i in a&b} eps[i].
J = the span of the labels that hold a null bit.  The checks (the widgets cite them as catw.P1 ... catw.P6):
  P1  restrict to a face: for every choice of squares with n <= 4 and every T, the inclusion of Cl(T) is an injective homomorphism; the projection
      pi_T (e_a -> e_a if a is inside T, else 0) is a homomorphism iff every generator outside T is null; pi o iota = id; with T = the non-null generators, ker pi_T = J
  P2  halve: Cl^0(p,q,r) = Cl(p,q-1,r) (t of square -1) or Cl(q,p-1,r) (t of square +1), an explicit isomorphism on all labels, n <= 5; with p = q = 0 the even part
      of the exterior algebra is a Clifford algebra on r-1 generators iff r <= 2 (radical dimension and Loewy length decide), so halving fails exactly for p = q = 0, r >= 3
  P3  the label-0 card, every (p,q,r) with n <= 6: J, its powers computed from products (layers C(r,k) 2^(p+q), Loewy length r + 1), super-centre 2^r and centre
      (linear systems over Q), the quotient Cl/J multiplies as Cl(p,q)
  P4  the complement pairing, every (p,q,r) with n <= 6: lambda = coefficient of the full label F; its Gram matrix has rank 2^n and the same signed antidiagonal
      for every signature of a given n; e_F x and the scalar-part pairing have rank 2^(p+q); the Nakayama sign per label; a symmetric non-degenerate form is
      exhibited when n is odd or r = 0, and for n even, r >= 1 every conjugator of the grade involution lies in J (the premise of T3 (F3))
  P5  the E_n series, n = 3..20: Bareiss determinant 9 - n, exact inertia, Kac type (hyperbolic only at n = 10), the null root of E_9, the mod-2 counts against Cl(n,0)
  P6  (candidate) the null root of E_9 spans the radical of E_9 / 2E_9; the radical of the label form of Cl(9,0) is spanned by the full label 1...1 alone
Nothing here is a statement about physics."""
import argparse, json, math, sys
from fractions import Fraction as Fr

N_OK = N_BAD = 0
def chk(cid, cond, msg=''):
    global N_OK, N_BAD
    if cond: N_OK += 1
    else: N_BAD += 1
    print(('ok   ' if cond else 'FAIL ') + cid + (': ' + msg if msg else ''))

# ---------------------------------------------------------------- the bit rule and small exact tools
def pc(x): return bin(x).count('1')
def reorder(a, b):
    s, x = 0, a >> 1
    while x: s += pc(x & b); x >>= 1
    return -1 if s & 1 else 1
def bmul(a, b, eps):
    s, c, i = reorder(a, b), a & b, 0
    while c:
        if c & 1: s *= eps[i]
        c >>= 1; i += 1
    return s, a ^ b
def sig(p, q, r): return (1,) * p + (-1,) * q + (0,) * r
def triples(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
def nullmask(eps): return sum(1 << i for i, e in enumerate(eps) if e == 0)
def rank_q(rows, ncols):
    """exact rank over Q of sparse rows (dicts column -> integer or Fraction)"""
    piv = {}
    for r0 in rows:
        r = {c: Fr(v) for c, v in r0.items() if v}
        while r:
            c = min(r)
            if c not in piv: piv[c] = r; break
            f = r[c] / piv[c][c]
            for k, v in piv[c].items():
                r[k] = r.get(k, 0) - f * v
                if r[k] == 0: del r[k]
    return len(piv)
def rank_f2(rows):
    """rank over GF(2) of rows given as integers (bit j = column j)"""
    piv = {}
    for v in rows:
        while v:
            h = v.bit_length() - 1
            if h not in piv: piv[h] = v; break
            v ^= piv[h]
    return len(piv)
def bareiss(M):
    """exact determinant of an integer matrix (fraction-free elimination)"""
    A = [row[:] for row in M]; n = len(A); sgn, prev = 1, 1
    for k in range(n - 1):
        if A[k][k] == 0:
            sw = next((i for i in range(k + 1, n) if A[i][k] != 0), None)
            if sw is None: return 0
            A[k], A[sw] = A[sw], A[k]; sgn = -sgn
        for i in range(k + 1, n):
            for j in range(k + 1, n): A[i][j] = (A[i][j] * A[k][k] - A[i][k] * A[k][j]) // prev
        prev = A[k][k]
    return sgn * A[n - 1][n - 1] if n else 1
def inertia(G):
    """exact (positive, negative, zero) of a symmetric rational matrix by congruence diagonalisation"""
    A = [[Fr(x) for x in row] for row in G]; pos = neg = zer = 0
    while A:
        m = len(A); k = next((i for i in range(m) if A[i][i] != 0), None)
        if k is None:
            pr = next(((i, j) for i in range(m) for j in range(i + 1, m) if A[i][j] != 0), None)
            if pr is None: zer += m; break
            i, j = pr
            for t in range(m): A[i][t] += A[j][t]
            for t in range(m): A[t][i] += A[t][j]
            k = i
        pv = A[k][k]; pos += pv > 0; neg += pv < 0
        for i in range(m):
            if i != k and A[i][k] != 0:
                f = A[i][k] / pv
                for t in range(m): A[i][t] -= f * A[k][t]
                for t in range(m): A[t][i] -= f * A[t][k]
        A = [[A[i][j] for j in range(m) if j != k] for i in range(m) if i != k]
    return pos, neg, zer
TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']          # c = p - q mod 8 (the clock of step 15)

# ---------------------------------------------------------------- P1. restrict to a face, and the quotient by J
def compress(a, T):
    out, k = 0, 0
    for i in range(T.bit_length()):
        if T >> i & 1:
            if a >> i & 1: out |= 1 << k
            k += 1
    return out
def expand(b, T):
    out, k = 0, 0
    for i in range(T.bit_length()):
        if T >> i & 1:
            if b >> k & 1: out |= 1 << i
            k += 1
    return out
def p1():
    pairs = homs = crit_ok = 0; inj_ok = iota_ok = pio_ok = quot_ok = True
    for n in range(0, 5):
        for code in range(3 ** n):
            eps = tuple((1, -1, 0)[code // 3 ** i % 3] for i in range(n)); N = 1 << n
            for T in range(N):
                epsT = tuple(eps[i] for i in range(n) if T >> i & 1); NT = 1 << len(epsT); pairs += 1
                im = [expand(b, T) for b in range(NT)]
                inj_ok &= len(set(im)) == NT
                for x in range(NT):
                    for y in range(NT):                                 # iota(x) iota(y) = iota(x y)
                        s1, c1 = bmul(im[x], im[y], eps); s2, c2 = bmul(x, y, epsT)
                        iota_ok &= s1 == s2 and (s1 == 0 or c1 == expand(c2, T))
                pio_ok &= all(compress(im[b], T) == b for b in range(NT))
                def pi(s, a): return (s, compress(a, T)) if (s and a & ~T == 0) else (0, 0)
                hom = True
                for a in range(N):
                    for b in range(N):
                        lhs = pi(*bmul(a, b, eps))
                        pa, pb = pi(1, a), pi(1, b)
                        if pa[0] and pb[0]:
                            s, c = bmul(pa[1], pb[1], epsT); rhs = (s, c) if s else (0, 0)
                        else: rhs = (0, 0)
                        if lhs != rhs: hom = False; break
                    if not hom: break
                homs += hom
                outside_null = all(eps[i] == 0 for i in range(n) if not T >> i & 1)
                crit_ok += hom == outside_null
                Z = nullmask(eps)
                if T == (N - 1) ^ Z:                                     # T = the non-null generators: ker pi_T = J, image = Cl(p,q)
                    ker = [a for a in range(N) if a & ~T]
                    quot_ok &= hom and ker == [a for a in range(N) if a & Z] and all(e != 0 for e in epsT)
    ok = inj_ok and iota_ok and pio_ok and quot_ok and crit_ok == pairs
    chk('P1', ok, f'{pairs} pairs (choice of squares, face T) with n <= 4 (all 3^n orders of +1, -1, 0): iota_T is an injective homomorphism on all label pairs; pi_T is a '
        f'homomorphism in {homs} cases, exactly those where every generator outside T is null ({crit_ok}/{pairs} agree); pi o iota = id; with T = the non-null generators '
        'pi_T is onto Cl(p,q) with kernel J (the labels with a null bit)')
    return dict(pairs=pairs, homs=homs, agree=crit_ok)

# ---------------------------------------------------------------- P2. halve: the even part
def even_iso(eps, t):
    n = len(eps); others = [i for i in range(n) if i != t]; tgt = tuple(-eps[i] * eps[t] for i in others)
    def img(b):
        s, m = 1, 0
        for k, i in enumerate(others):
            if b >> k & 1:
                s1, f = bmul(1 << i, 1 << t, eps); s2, m = bmul(m, f, eps); s *= s1 * s2
        return s, m
    I = [img(b) for b in range(1 << (n - 1))]
    ok = all(s != 0 and pc(m) % 2 == 0 for s, m in I) and len({m for _, m in I}) == 1 << (n - 1)
    for x in range(len(I)):
        for y in range(len(I)):
            s, c = bmul(x, y, tgt); s1, m1 = I[x]; s2, m2 = I[y]; s3, m3 = bmul(m1, m2, eps)
            ok &= (s1 * s2 * s3 == s * I[c][0] and m3 == I[c][1]) if s else s3 == 0
    return ok, (tgt.count(1), tgt.count(-1), tgt.count(0))
def powers(eps, rad):
    """the label sets spanning rad^1, rad^2, ... computed from products of labels (rad is spanned by labels and a product of labels is 0 or +- a label)"""
    out, cur = [], set(rad)
    while cur and len(out) <= len(eps):                                  # a nilpotent ideal of labels dies within n + 1 steps; a longer list means it is not nilpotent
        out.append(cur); cur = {a ^ b for a in cur for b in rad if bmul(a, b, eps)[0]}
    return out
def lam_even(r):
    eps = (0,) * r; ev = [a for a in range(1 << r) if pc(a) % 2 == 0]; rad = [a for a in ev if a]
    lay = powers(eps, rad); return dict(r=r, dim=len(ev), rad=len(rad), loewy=len(lay) + 1)
def p2():
    rows, ok = [], True
    for n in range(1, 6):
        for p, q, r in triples(n):
            eps = sig(p, q, r); row = dict(p=p, q=q, r=r, via={})
            for kind, t in (('plus', 0 if p else None), ('minus', p if q else None)):
                if t is None: continue
                good, tg = even_iso(eps, t); want = (p, q - 1, r) if kind == 'minus' else (q, p - 1, r)
                ok &= good and tg == want; row['via'][kind] = list(tg)
            if p + q == 0:
                L = lam_even(r)
                cliff = [(pp, qq, n - 1 - pp - qq) for pp, qq, _ in triples(n - 1)]
                same = [c for c in cliff if 2 ** (n - 1) - 2 ** (c[0] + c[1]) == L['rad'] and c[2] + 1 == L['loewy']]
                if r <= 2:                                               # explicit: r = 1 -> R = Cl(0,0,0); r = 2 -> span{1, e12}, e12^2 = 0 -> Cl(0,0,1)
                    exp = r == 1 or (bmul(3, 3, eps)[0] == 0 and L == dict(r=2, dim=2, rad=1, loewy=2))
                    ok &= exp and same == [(0, 0, r - 1)]; row['via']['null'] = [0, 0, r - 1]
                else:
                    ok &= same == [] and L['rad'] == 2 ** (r - 1) - 1 and L['loewy'] == r // 2 + 1
                row['lam_even'] = L
            row['halves'] = bool(row['via']); ok &= row['halves'] == (p + q >= 1 or r <= 2); rows.append(row)
    jams = [f"({x['p']},{x['q']},{x['r']})" for x in rows if not x['halves']]
    chk('P2', ok, 'even part = Cl(p,q-1,r) via a generator t of square -1 and Cl(q,p-1,r) via t of square +1 (f_i = e_i e_t, an isomorphism on all label pairs), every '
        '(p,q,r) with 1 <= n <= 5; the even part of the exterior algebra on r null generators has radical 2^(r-1) - 1 and Loewy length floor(r/2) + 1 (from products): a '
        'Clifford algebra on r - 1 generators for r = 1, 2 and for no r >= 3. Halving fails exactly at ' + ', '.join(jams) + ' (p = q = 0, r >= 3); with one or two null '
        'generators only, it works')
    return rows

# ---------------------------------------------------------------- P3. the label-0 card
def centre_dim(eps, graded):
    n = len(eps); N = 1 << n; rows = []
    for i in range(n):
        for c in range(N):                                               # coefficient of e_c in x e_i - (+-) e_i x
            a = c ^ (1 << i); s1 = bmul(a, 1 << i, eps)[0]; s2 = bmul(1 << i, a, eps)[0]
            v = s1 - ((-1) ** pc(a) if graded else 1) * s2
            if v: rows.append({a: v})
    return N - rank_q(rows, N)
def card(p, q, r):
    eps = sig(p, q, r); n = p + q + r; N = 1 << n; Z = nullmask(eps); J = [a for a in range(N) if a & Z]
    ideal = all(bmul(a, b, eps)[0] == 0 or (a ^ b) & Z for a in J for b in range(N)) and all(bmul(b, a, eps)[0] == 0 or (a ^ b) & Z for a in J for b in range(N))
    pw = powers(eps, J); lay = [len(x) for x in pw]                       # J^1, J^2, ... and their dimensions
    pw_ok = all(pw[k - 1] == {a for a in range(N) if pc(a & Z) >= k} for k in range(1, len(pw) + 1))
    layers = [N - len(J)] + [lay[k] - (lay[k + 1] if k + 1 < len(lay) else 0) for k in range(len(lay))]
    quot = all(bmul(a, b, eps) == bmul(a, b, eps[:p + q]) for a in range(1 << (p + q)) for b in range(1 << (p + q)))
    return dict(n=n, dim=N, J=len(J), layers=layers, loewy=len(lay) + 1, sc=centre_dim(eps, True), centre=centre_dim(eps, False),
                quotient=[p, q], type=TYPES[(p - q) % 8], clock=(p - q) % 8), ideal and pw_ok and quot
def p3():
    out, ok = {}, True
    for n in range(0, 7):
        for p, q, r in triples(n):
            d, good = card(p, q, r); out[f'{p},{q},{r}'] = d
            ok &= good and d['J'] == 2 ** n - 2 ** (p + q) and d['layers'] == [math.comb(r, k) * 2 ** (p + q) for k in range(r + 1)] and d['loewy'] == r + 1 and d['sc'] == 2 ** r
    chk('P3', ok, f'{len(out)} signatures (p,q,r) with n <= 6: J (labels with a null bit) is a two-sided ideal of dimension 2^n - 2^(p+q); its powers, computed as products of '
        'labels, are the labels with at least k null bits, layers C(r,k) 2^(p+q), Loewy length r + 1; the super-centre has dimension 2^r (a linear system over Q); the centre '
        'is computed the same way; the labels without a null bit multiply exactly as in Cl(p,q) (the quotient Cl/J)')
    return out

# ---------------------------------------------------------------- P4. the complement pairing (Frobenius duality)
def frob(p, q, r):
    eps = sig(p, q, r); n = p + q + r; N = 1 << n; F = N - 1; Z = nullmask(eps)
    lam = [[0] * N for _ in range(N)]
    for a in range(N):
        for b in range(N):
            s, c = bmul(a, b, eps)
            if s and c == F: lam[a][b] = s
    supp = all((lam[a][b] != 0) == (b == a ^ F) for a in range(N) for b in range(N))
    rk_lam = rank_q([{b: v for b, v in enumerate(row) if v} for row in lam], N)
    anti = ''.join('+' if lam[a][a ^ F] > 0 else '-' for a in range(N))
    ef = [bmul(F, a, eps) for a in range(N)]; rk_ef = rank_q([{c: s} for s, c in ef if s], N)
    rk_0 = rank_q([{a: bmul(a, a, eps)[0]} for a in range(N) if bmul(a, a, eps)[0]], N)
    nak = ''.join('+' if lam[a][a ^ F] * lam[a ^ F][a] > 0 else '-' for a in range(N))
    nak_ok = all((nak[a] == '+') == ((pc(a) * (n - pc(a))) % 2 == 0) for a in range(N))
    conj = [a for a in range(N) if all(sum(x[0] for x in (bmul(a, 1 << i, eps), bmul(1 << i, a, eps))) == 0 for i in range(n))]
    sym_cert = None                                                      # a symmetric non-degenerate associative form, when one is exhibited
    if n % 2 == 1 and nak.count('-') == 0 and rk_lam == N: sym_cert = 'lambda'
    elif r == 0 and rk_0 == N: sym_cert = 'scalar'
    w2 = bmul(F, F, eps)[0]
    return dict(n=n, rank_lam=rk_lam, rank_ef=rk_ef, rank_0=rk_0, omega2=w2, reach=sum(1 for s, _ in ef if s), conj=conj, conj_in_J=all(a & Z for a in conj),
                fair=sym_cert is not None, cert=sym_cert), supp, anti, nak, nak_ok
def p4():
    out, anti_of, nak_of, ok = {}, {}, {}, True
    for n in range(0, 7):
        for p, q, r in triples(n):
            d, supp, anti, nak, nak_ok = frob(p, q, r); out[f'{p},{q},{r}'] = d
            ok &= supp and nak_ok and d['rank_lam'] == 2 ** n and d['rank_ef'] == 2 ** (p + q) == d['reach'] and d['rank_0'] == 2 ** (p + q)
            ok &= anti_of.setdefault(n, anti) == anti and nak_of.setdefault(n, nak) == nak
            ok &= d['fair'] == (n % 2 == 1 or r == 0)
            if n % 2 == 0 and r >= 1: ok &= d['conj_in_J'] and len(d['conj']) >= 1
            if n % 2 == 0 and r == 0 and n > 0: ok &= d['conj'] == [2 ** n - 1]
    c301 = out['3,0,1']['conj']; ok &= c301 == [8, 15]
    chk('P4', ok, f'{len(out)} signatures with n <= 6: lambda(e_a e_b) is non-zero exactly for b = a xor F, rank 2^n, and its signed antidiagonal is the same for every '
        'signature of a given n; multiplication by e_F and the scalar-part pairing have rank 2^(p+q); Nakayama sign (-1)^(|a|(n-|a|)) per label (identity for odd n, the '
        'grade involution for even n); a symmetric non-degenerate form is exhibited exactly when n is odd (lambda) or r = 0 (the scalar part); for even n with r >= 1 every '
        f'conjugator of the grade involution lies in J (Cl(3,0,1): the labels {c301}, e4 and e1234), so by T3 no symmetric form exists there')
    return out, {str(k): v for k, v in anti_of.items()}, {str(k): v for k, v in nak_of.items()}

# ---------------------------------------------------------------- P5. the E_n series, from the bottom of the tree to n = 20
def en_graph(n):
    """nodes: 0 = the short arm (the branch), then the chain: far end of the 2-node arm, its near node, the centre, the long arm outwards (n >= 4); E_3 = A2 x A1"""
    if n == 3: return 3, [(1, 2)]
    edges = [(1, 2), (2, 3), (0, 3)] + [(k, k + 1) for k in range(3, n - 1)]
    return n, edges
def cartan(nd, edges, drop=()):
    keep = [i for i in range(nd) if i not in drop]; ix = {v: k for k, v in enumerate(keep)}
    C = [[2 if i == j else 0 for j in range(len(keep))] for i in range(len(keep))]
    for i, j in edges:
        if i in ix and j in ix: C[ix[i]][ix[j]] = C[ix[j]][ix[i]] = -1
    return C, keep
def components(keep, edges):
    adj = {v: set() for v in keep}
    for i, j in edges:
        if i in adj and j in adj: adj[i].add(j); adj[j].add(i)
    seen, comps = set(), []
    for v in keep:
        if v in seen: continue
        st, cc = [v], []
        while st:
            x = st.pop()
            if x in seen: continue
            seen.add(x); cc.append(x); st.extend(adj[x] - seen)
        comps.append(sorted(cc))
    return comps
def kind(nd, edges, nodes):
    C, _ = cartan(nd, edges, drop=[i for i in range(nd) if i not in nodes]); s = inertia(C)
    return 'finite' if s == (len(nodes), 0, 0) else 'affine' if s == (len(nodes) - 1, 0, 1) else 'indefinite'
def mod2_counts(nd, edges):
    adj = [0] * nd
    for i, j in edges: adj[i] |= 1 << j; adj[j] |= 1 << i
    x, qv, q1, q0 = 0, 0, 0, 0
    for k in range(1, 1 << nd):                                          # Gray code: flipping bit i changes q = sum x_i + sum_edges x_i x_j by 1 + |adj(i) & x|
        i = (k & -k).bit_length() - 1; qv ^= (1 + pc(adj[i] & x)) & 1; x ^= 1 << i
        if qv: q1 += 1
        else: q0 += 1
    C, _ = cartan(nd, edges); rad = nd - rank_f2([sum((C[i][j] % 2) << j for j in range(nd)) for i in range(nd)])
    return q1, q0, rad
def cl_counts(n):
    q1 = sum(math.comb(n, k) for k in range(n + 1) if k % 4 in (2, 3)); q0 = 2 ** n - 1 - q1
    B = [sum(((1 + (i == j)) % 2) << j for j in range(n)) for i in range(n)]     # commutation form of the labels on the generators: |a||b| + |a & b| mod 2
    return q1, q0, n - rank_f2(B)
def null_root(C):
    n = len(C); A = [[Fr(x) for x in row] for row in C]; piv = []; r = 0
    for c in range(n):
        pr = next((i for i in range(r, n) if A[i][c] != 0), None)
        if pr is None: continue
        A[r], A[pr] = A[pr], A[r]; A[r] = [x / A[r][c] for x in A[r]]
        for i in range(n):
            if i != r and A[i][c] != 0: f = A[i][c]; A[i] = [a - f * b for a, b in zip(A[i], A[r])]
        piv.append(c); r += 1
    free = [c for c in range(n) if c not in piv]
    if len(free) != 1: return None
    v = [Fr(0)] * n; v[free[0]] = Fr(1)
    for i, c in enumerate(piv): v[c] = -A[i][free[0]]
    L = math.lcm(*[x.denominator for x in v]); v = [int(x * L) for x in v]; g = math.gcd(*v); v = [x // g for x in v]
    return [-x for x in v] if v[0] < 0 else v
def p5():
    rows, ok = [], True
    for n in range(3, 21):
        nd, ed = en_graph(n); C, _ = cartan(nd, ed); det = bareiss(C); s = inertia(C)
        typ = kind(nd, ed, list(range(nd)))
        if typ == 'indefinite':
            hyp = all(kind(nd, ed, cc) in ('finite', 'affine') for v in range(nd) for cc in components([i for i in range(nd) if i != v], ed))
            typ = 'hyperbolic' if hyp else 'lorentzian' if s == (n - 1, 1, 0) else 'indefinite'
        q1, q0, rad = mod2_counts(nd, ed); c1, c0, crad = cl_counts(n)
        rows.append(dict(n=n, det=det, inertia=list(s), type=typ, q1=q1, q0=q0, rad=rad, cl_q1=c1, cl_q0=c0, cl_rad=crad))
        ok &= det == 9 - n and s == ((n, 0, 0) if n <= 8 else (8, 0, 1) if n == 9 else (n - 1, 1, 0)) and (q1, q0, rad) == (c1, c0, crad)
        ok &= typ == ('finite' if n <= 8 else 'affine' if n == 9 else 'hyperbolic' if n == 10 else 'lorentzian')
    C9, _ = cartan(*en_graph(9)); marks = null_root(C9) or []                    # [] when the kernel is not one line: then the check below fails
    ok &= marks == [3, 2, 4, 6, 5, 4, 3, 2, 1] and sum(marks) == 30 and all(sum(C9[i][j] * marks[j] for j in range(9)) == 0 for i in range(9))
    chk('P5', ok, 'E_n = the tree T(2,3,n-3) (E_3 = A2 x A1), n = 3..20: Bareiss determinant 9 - n; inertia (n,0,0) for n <= 8, (8,0,1) at n = 9, (n-1,1,0) for n >= 10; '
        'Kac type finite, affine at 9, hyperbolic only at 10 (every proper connected subdiagram finite or affine), Lorentzian beyond; null root of E_9 with marks '
        f'(3; 2,4,6,5,4,3,2,1) (branch; chain), sum {sum(marks)}; mod 2 the counts of q = 1, of non-zero q = 0 and the radical of E_n/2E_n equal those of the labels of '
        'Cl(n,0) (square -1, square +1, central) for every n = 3..20, as T9 (a) predicts')
    return rows, marks

# ---------------------------------------------------------------- P6. (candidate) the E_9 null root mod 2
def p6(marks):
    nd, ed = en_graph(9); C, _ = cartan(nd, ed); m2 = sum((x % 2) << i for i, x in enumerate(marks))
    rows = [sum((C[i][j] % 2) << j for j in range(nd)) for i in range(nd)]
    rad = [v for v in range(1, 1 << nd) if all(pc(rw & v) % 2 == 0 for rw in rows)]
    q = lambda v: (pc(v) + sum(1 for i, j in ed if v >> i & 1 and v >> j & 1)) % 2
    B9 = [sum(((1 + (i == j)) % 2) << j for j in range(9)) for i in range(9)]
    crad = [a for a in range(1, 1 << 9) if all(pc(rw & a) % 2 == 0 for rw in B9)]
    Q = lambda a: 1 if pc(a) % 4 in (2, 3) else 0
    ok = rad == [m2] and q(m2) == 0 and crad == [511] and Q(511) == 0
    chk('P6', ok, f'marks of the E_9 null root mod 2: {[x % 2 for x in marks]} (non-zero); the radical of the mod-2 pairing of E_9/2E_9 is the line through it (q = 0 there); the '
        'radical of the label form of Cl(9,0) is the line through the full label 1...1 (e_F squares to +1, so Q = 0 there). An isometry (T9 (a)) maps radical to radical, so '
        'it sends the null root mod 2 to the full label 1...1. Computed: the two radicals and the values of q and Q on them; the isometry itself is T9 (a), not rebuilt here')
    return dict(marks_mod2=[x % 2 for x in marks], radical=[m2], cl_radical=crad)

def run():
    data = {'P1': p1(), 'P2': p2(), 'P3': p3()}
    data['P4'], data['P4_anti'], data['P4_nakayama'] = p4()
    data['P5'], data['marks9'] = p5(); data['P6'] = p6(data['marks9'])
    data['summary'] = dict(ok=N_OK, failed=N_BAD, script='selfcheck/reports/lens_cat_check.py')
    return json.loads(json.dumps(data))

if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--write'); ap.add_argument('--compare'); a = ap.parse_args()
    data = run()
    print('\nchecks: %d ok, %d failed' % (N_OK, N_BAD))
    if a.write and not N_BAD: json.dump(data, open(a.write, 'w'), indent=None, separators=(',', ':'), ensure_ascii=False); print('wrote', a.write)
    if a.compare:
        same = json.load(open(a.compare)) == data; print('stored data == rebuilt data' if same else 'FAIL the stored data differs from the rebuilt data')
        if not same: sys.exit(1)
    sys.exit(1 if N_BAD else 0)
