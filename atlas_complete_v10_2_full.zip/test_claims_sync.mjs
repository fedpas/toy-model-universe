// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_claims_sync.mjs: the 654 statements of the claims table (the 260 audited ones and the 394 of the Lenses page) (claimsData.js) are exactly what the pages' copy modules say.
// claimsLocators.json points each statement (and each line of a split statement), in English and Italian, at its text and its flags in the
// copy files; make_claims_data.mjs resolves them; this test regenerates the table and compares it with the shipped claimsData.js, then checks the
// audit rules: four flags only, a statement tagged ours says nothing like "derived", known ground means standard and checked and neither ours nor open.
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { buildClaims, FOUR } from './make_claims_data.mjs';
const HERE = path.dirname(fileURLToPath(import.meta.url));
let fails = 0, checks = 0; const ok = (c, m) => { checks++; if (!c) { fails++; console.log('FAIL ' + m); } };
const claims = await buildClaims(), shipped = (await import('./claimsData.js')).CLAIMS;
ok(claims.length === 654 && new Set(claims.map(c => c.id)).size === 654, 'the table holds 654 distinct statements');
ok(JSON.stringify(claims) === JSON.stringify(shipped), 'claimsData.js equals what the locators resolve to (run: node make_claims_data.mjs)');
const GROUPS = { ATL: 25, GEN: 9, FUR: 5, PAG: 32, LAB: 16, EQN: 20, SHP: 6, GOS: 4, CPL: 8, YM: 7, MAT: 7, GRV: 12, MIR: 6, PRJ: 6, NUL: 11, FRQ: 5, SPN: 5, SPR: 4, RIG: 6, MAP: 35, RSN: 31, LNP: 4, LNC: 135, LNB: 144, LNS: 111 };   // the first 21 groups are the 260 audited statements of the second audit round; LNP, LNC, LNB and LNS are the Lenses page (steps 18-20: its strip and the three chapters, text and widgets), added in the same release
for (const [g, n] of Object.entries(GROUPS)) ok(claims.filter(c => c.group === g).length === n, `group ${g} has ${n} statements`);
// where the lines' flags differ from the audit's merged flags on purpose (each reason recorded here)
const EXCEPT = {
  'ATL-024': 'split into an open list (ours, open) and the standard classification sentence (standard, checked): the union is shown',
  'PAG-006': 'one strip entry holds the textbook identifications and the readings: union of both parts',
  'PAG-029': 'one strip entry: scripts plus the textbook curvature counts: checked and standard',
  'LAB-013': 'same strip entry as PAG-029',
  'PAG-031': 'one strip entry: theorem part standard, readings ours: union',
  'LAB-015': 'same strip entry as PAG-031',
  'GRV-001': 'split into a theorem line (standard, checked) and a reading line (ours): union',
  'ATL-020': 'split (6 Oct verification) into a theorem line (standard, checked) and a reading line (ours, open): union',
  'RSN-018': 'split into a counts line (standard, checked: the dimensions are textbook, 6 Oct verification) and a reading line (ours): union',
  'FUR-003': 'tagged checked after the 6 Oct verification: witt_test.py reproduces every statement of both lines (18480 and 616 included)',
  'MAP-010': 'standard dropped after the 6 Oct verification: a computed finding and an open item, no textbook statement behind it',
};
for (const id of ['EQN-007', 'EQN-009', 'EQN-010', 'EQN-011', 'EQN-015', 'EQN-016', 'EQN-017', 'EQN-018', 'EQN-019']) EXCEPT[id] = 'tally row (navigation): keeps the tags it had; never filtered';
let diff = 0;
for (const c of claims) {
  if (c.frozen) { ok(c.en.length === 1 && c.known === false, `${c.id}: frozen genesis row is listed, never known ground`); continue; }
  ok(c.en.length >= 1, `${c.id}: has a line`);
  for (const lang of ['en', 'it']) for (const x of c[lang] || []) {
    ok(typeof x.text === 'string' && x.text.length > 3, `${c.id} ${lang}: text`);
    ok(x.flags.every(f => FOUR.includes(f)) && new Set(x.flags).size === x.flags.length, `${c.id} ${lang}: four flags only`);
    if (x.flags.includes('ours') && !x.notShown) ok(!/\bderiv(ed|ation)\b/i.test(x.text) || /not derived|nothing is derived|is not a derivation|none of them is a derivation/i.test(x.text), `${c.id} ${lang}: a line tagged ours says nothing like "derived": ${x.text.slice(0, 80)}`);
    ok(x.known === (x.flags.includes('standard') && x.flags.includes('checked') && !x.flags.includes('ours') && !x.flags.includes('open')), `${c.id} ${lang}: known ground is standard and checked, neither ours nor open`);
  }
  if (c.it) ok(c.it.length === c.en.length && c.it.every((x, i) => x.label === c.en[i].label && x.flags.join() === c.en[i].flags.join()), `${c.id}: Italian lines carry the same labels and flags as the English ones`);
  if (c.group !== 'RSN' && c.id !== 'EQN-005') ok(c.it !== null, `${c.id}: has Italian text`);
  const a = c.flags.join(), b = c.flagsSpec.join();
  if (a !== b) { diff++; ok(!!EXCEPT[c.id], `${c.id}: lines carry ${a}, the audit says ${b}: record the reason in EXCEPT`); }
  else ok(!EXCEPT[c.id] || /tally/.test(EXCEPT[c.id]), `${c.id}: no exception needed`);
  if (c.known) ok(c.flags.includes('standard') && c.flags.includes('checked'), `${c.id}: known ground claim`);
}
// the files that ship claims hold no e-mail address
for (const f of ['claimsData.js', 'claimsLocators.json', 'make_claims_data.mjs']) ok(!/[\w.+-]+@[\w-]+\.[\w.-]+|mailto:/i.test(fs.readFileSync(path.join(HERE, f), 'utf8')), `${f}: no e-mail address`);
const known = claims.filter(c => c.known).length, lines = claims.reduce((n, c) => n + c.en.filter(x => x.known).length, 0);
console.log(`${checks} checks, ${diff} statements differ from the audit's flags on purpose (listed), ${known} statements and ${lines} lines are known ground`);
console.log(fails ? `${fails} FAILURES` : 'ALL CLAIMS TESTS PASS'); process.exit(fails ? 1 : 0);
