// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Steps 15-17 (labels, gauge gravity, finite groups): the engine behind the page (labelsEngine.js) against the scripts' logs and against the bit rule,
// the copy (English and Italian, plain and formal), the step numbering, and the known gap (the page is not on the Map tree yet).
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);
import { execSync } from 'child_process';
import * as E from './labelsEngine.js';
import { PAGE, PAGE_YL, SHORT, COPY, TABS_LBL } from './labelsCopy.js';
import { PAGES, STORY, STORY_YL } from './storyCopy.js';
import { STEP_GROUPS, STEP_OFFSET, stepNo, stepTotal, stepEyebrow, NAV_NAMES, NAV_NAMES_YL, STEP_NAMES, STEP_NAMES_YL } from './steps.js';
import { TREE, flat } from './mapData.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const near = (a, b, t = 1e-9) => Math.abs(a - b) <= t * Math.max(1, Math.abs(a), Math.abs(b));
const LOG = f => fs.readFileSync('selfcheck/steps15_17/logs/' + f, 'utf8');
const L1 = LOG('labels_check.log'), L2 = LOG('gtg_check.log'), L3 = LOG('groups_check.log');

// ---- 0. the scripts and their logs ship with the package and end in their all-pass line
ok(/ALL LABELS CHECKS PASS/.test(L1) && /ALL GTG\/RDK CHECKS PASS/.test(L2) && /ALL GROUP CHECKS PASS/.test(L3), 'the three logs end in their all-pass lines');
for (const f of ['bitcliff.py', 'permgroup.py', 'labels_check.py', 'gtg_check.py', 'groups_check.py', 'run_mutations.py']) ok(fs.existsSync('selfcheck/steps15_17/' + f), 'selfcheck/steps15_17/' + f + ' is in the package');
let numpy = true; try { execSync('python3 -c "import numpy"', { stdio: 'ignore' }); } catch { numpy = false; }
if (numpy && !process.env.SKIP_PY) {
  const run = f => { try { return execSync('python3 ' + f, { cwd: 'selfcheck/steps15_17', encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { return String(e.stdout || '') + String(e.stderr || e.message); } };
  ok(/ALL LABELS CHECKS PASS/.test(run('labels_check.py')), 'labels_check.py passes now');
  ok(/ALL GTG\/RDK CHECKS PASS/.test(run('gtg_check.py')), 'gtg_check.py passes now');
  ok(/ALL GROUP CHECKS PASS/.test(run('groups_check.py')), 'groups_check.py passes now');
} else console.log('note: numpy is not installed; the three scripts were not re-run (the logs were compared)');

// ---- 1. the clock and the cells (Step 15)
{
  let cells = 0, dimOk = true, gaussOk = true, typeOk = true;
  for (let p = 0; p <= 12; p++) for (let q = 0; p + q <= 12; q++) { if (p + q < 1 && !(p === 0 && q === 0)) continue; const w = E.wedderburn(p, q), g = E.gaussSum(p, q); cells++; if (w.dim !== 2 ** (p + q)) dimOk = false; if (g.c !== w.c || g.norm2 !== 2 ** (p + q)) gaussOk = false; }
  ok(cells === 91, 'cells n <= 12: 91 (the log says 91)'); ok(/91 cells n<=12/.test(L3), 'groups_check.log has the 91 cells');
  ok(dimOk, 'k^2 * dim(field) * copies = 2^n for every cell n <= 12'); ok(gaussOk, 'the Gauss sum has norm 2^n and phase c = p - q mod 8 for every cell n <= 12');
  const T = (p, q, t, k) => { const w = E.wedderburn(p, q); return w.type === t && w.k === k; };
  ok(T(1, 0, 'R2', 1) && T(0, 1, 'C', 1) && T(2, 0, 'R', 2) && T(0, 2, 'H', 1) && T(0, 3, 'H2', 1) && T(3, 0, 'C', 2) && T(4, 0, 'H', 2) && T(1, 1, 'R', 2) && T(8, 0, 'R', 16) && T(0, 8, 'R', 16), 'textbook cells: Cl(1,0)=R+R, Cl(0,1)=C, Cl(2,0)=M2(R), Cl(0,2)=H, Cl(0,3)=H+H, Cl(3,0)=M2(C), Cl(4,0)=M2(H), Cl(8,0)=M16(R)');
  ok(E.TYPES.join() === 'R,R2,R,C,H,H2,H,C', 'the types around the clock');
  let emb = 0, embOk = true; for (let p = 0; p <= 8; p++) for (let q = 0; p + q <= 8; q++) { const e = E.embedCheck(p, q); emb++; if (!e.ok) embOk = false; for (let j = 0; j < p + q; j++) { const hasP = (e.images[j] >> (p + q) & 3) === 3; if (hasP !== (j >= p)) embOk = false; } }
  ok(emb === 45 && embOk, 'every Cl(p,q), n <= 8 (45 cells), embeds in Cl(n+2,0): squares, anticommutation, odd images; only the negative generators carry P');
  // the trinity
  const gc = E.gridCounts(6); ok(gc.ell === 516 && gc.hyp === 1616 && gc.par === 64 && gc.total === 2197, 'grid [-6,6]^3: 516 / 1616 / 64');
  ok(/elliptic \(X\^2 < 0\)\s+516/.test(L1) && /hyperbolic \(X\^2 > 0\)\s+1616/.test(L1) && /parabolic \(X\^2 = 0, X != 0\)\s+64/.test(L1), 'the same three counts are in labels_check.log');
  let sq = true; for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) for (let c = -3; c <= 3; c++) { const r = E.squareByBitRule(a, b, c); if (r.scalar !== E.traceless(a, b, c) || r.rest !== 0) sq = false; const M = E.matrixOf(a, b, c), s = E.traceless(a, b, c); const M2 = [[M[0][0] * M[0][0] + M[0][1] * M[1][0], M[0][0] * M[0][1] + M[0][1] * M[1][1]], [M[1][0] * M[0][0] + M[1][1] * M[1][0], M[1][0] * M[0][1] + M[1][1] * M[1][1]]]; if (M2[0][0] !== s || M2[1][1] !== s || M2[0][1] !== 0 || M2[1][0] !== 0) sq = false; }
  ok(sq, 'X^2 = a^2 + b^2 - c^2 by the bit rule of Cl(2,0) and by the 2x2 matrices, for 343 integer generators');
  let ex = true; for (const [a, b, c] of [[0, 0.5, 0.5], [0, 0, 1], [0, 1, 0], [0.3, -0.7, 0.2], [1, 0.4, 0.1], [0, 0, 0]]) for (const t of [0, 0.37, 1.1]) { const h = 1e-6, E1 = E.expTX(a, b, c, t + h), E0 = E.expTX(a, b, c, t - h), X = E.expTX(a, b, c, t), M = E.matrixOf(a, b, c); for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { const d = (E1[i][j] - E0[i][j]) / (2 * h), XM = M[i][0] * X[0][j] + M[i][1] * X[1][j]; if (Math.abs(d - XM) > 1e-5) ex = false; } const A = E.expTX(a, b, c, 0.4), B = E.expTX(a, b, c, 0.9), C = E.expTX(a, b, c, 1.3); for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) if (Math.abs(A[i][0] * B[0][j] + A[i][1] * B[1][j] - C[i][j]) > 1e-9) ex = false; }
  ok(ex, 'exp(tX): d/dt exp(tX) = X exp(tX) and exp(t)exp(u) = exp(t+u) in the elliptic, hyperbolic and parabolic cases');
  ok(E.trinityClass(E.traceless(...E.springX(1))) === -1 && E.trinityClass(E.traceless(...E.springX(0))) === 0 && E.trinityClass(E.traceless(...E.springX(-1))) === 1 && near(E.traceless(...E.springX(0.7)), -0.7), 'the spring k > 0, 0, < 0 is rotation, translation, boost, and X^2 = -k');
  const sp = E.springX(0.6), Mx = E.matrixOf(...sp); ok(near(Mx[0][1], 1) && near(Mx[1][0], -0.6) && near(Mx[0][0], 0), 'the spring generator is [[0,1],[-k,0]]');
}
// ---- bivectors at n = 4
{
  const v40 = E.bivector4(4, 0, [1, 0, 0, 0, 0, 1]), v31 = E.bivector4(3, 1, [1, 0, 0, 0, 0, 1]), v22 = E.bivector4(2, 2, [1, 0, 0, 0, 0, 1]);
  ok(v40.S === -2 && v40.W === 2 && v31.S === 0 && v31.W === 2 && v22.S === -2 && v22.W === 2 && v40.other === 0, '(e12 + e34)^2 = -2 + 2 e1234 in Cl(4,0) and Cl(2,2), 2 e1234 in Cl(3,1): the log lines');
  ok(/\(e12 \+ e34\)\^2 = \{0: -2, 15: 2\}/.test(L1) && /Cl\(3, 1\):  \(e12 \+ e34\)\^2 = \{15: 2\}/.test(L1), 'the same three squares are in labels_check.log');
  const cx = E.bivector4(2, 2, [1, 1, 0, 0, 1, 0]); ok(cx.label === 'complex' && cx.disc === -3 && cx.S === 1 && Math.abs(cx.W) === 2, 'the preset "a complex pair" in Cl(2,2): S = 1, |W| = 2, discriminant -3 (roots exp(+-i pi/3))');
  ok(E.SIGS4.filter(([p, q]) => !(p === 2 && q === 2)).every(([p, q]) => E.bivector4(p, q, [1, 1, 0, 0, 1, 0]).kind === 'real'), 'the same bivector has real roots in the other four signatures');
  ok(E.bivector4(3, 1, [1, 0, 0, 0, -1, 0]).label === 'null', 'a null simple bivector exists in Cl(3,1) (e12 - e24)');
  // the roots solve the quadratic and B^2 has only grades 0 and 4
  const r = E.lcg(99); let quad = true, grades = true;
  for (const [p, q] of E.SIGS4) for (let i = 0; i < 200; i++) { const c = Array.from({ length: 6 }, () => Math.round(r() * 8 - 4)), v = E.bivector4(p, q, c); if (v.other !== 0) grades = false; const [l1, l2] = v.lam; const sum = l1[0] + l2[0], prod = l1[0] * l2[0] - l1[1] * l2[1]; if (Math.abs(sum - v.S) > 1e-9 || Math.abs(prod - v.W * v.W * v.I2 / 4) > 1e-9) quad = false; }
  ok(grades && quad, 'for 1000 random bivectors B^2 has only a scalar and an e1234 part, and the two roots satisfy l1 + l2 = S, l1 l2 = W^2 I^2 / 4');
  const mc = E.SIGS4.map(([p, q]) => E.sampleBivectors(p, q, 400));
  ok(mc.every((m, i) => (i === 2 ? m.complex > 100 && m.complex < 260 : m.complex === 0)), 'complex roots only in Cl(2,2): ' + mc.map(m => m.complex).join(', '));
  ok(/complex lambda \(loxodromic, the Riesz "counter-example"\) occurs in Cl\(2,2\) = M_4\(R\) ONLY/.test(L1), 'labels_check.log says the same');
  ok(mc[2].complex / (mc[2].real + mc[2].complex) > .35 && mc[2].complex / (mc[2].real + mc[2].complex) < .55, 'about 45 per cent complex in Cl(2,2) (the log has 33 of 72)');
}
// ---- 2. gauge gravity (Step 16)
{
  for (const g of [0, 0.6, 1, 5 / 3, 3, -2]) ok(near(E.pgSquareByBitRule(g), g * g - 1), `(e_r + g e_t)^2 = g^2 - 1 by the bit rule of Cl(1,1) at g = ${g}`);
  ok(E.pgClass(3 / 5) === -1 && E.pgClass(1) === 0 && E.pgClass(5 / 3) === 1 && near(E.pgSquare(3 / 5), -16 / 25) && near(E.pgSquare(5 / 3), 16 / 9), 'outside -16/25, horizon 0, inside 16/9 (the log lines G2)');
  ok(/g=3\/5 outside.*-16\/25/.test(L2) && /g=1 on the horizon.*= 0/.test(L2) && /g=5\/3 inside.*16\/9/.test(L2), 'gtg_check.log has the three lines');
  ok(near(E.pgG(1, 0.5), 1) && E.pgClass(E.pgG(1, 0.5)) === 0 && E.pgClass(E.pgG(0.5, 0.5)) === 1 && E.pgClass(E.pgG(2, 0.5)) === -1, 'g = sqrt(2M/r): the horizon at r = 2M');
  const R = E.pgRays(0.5), R1 = E.pgRays(1), R2 = E.pgRays(2); ok(near(R.out, .5) && near(R1.out, 0) && near(R2.out, -1) && near(R2.inn, -3) && near(R.rain, -.5), 'light rays dr/dt = -g +- 1: the outgoing ray stands still at g = 1 and falls in for g > 1');
  const rv = E.pgRays(0.5, -1); ok(near(rv.out, 1.5) && near(rv.inn, -.5) && near(rv.rain, .5), 'reversing time (g -> -g) tilts the cones the other way');
  const rows = { 4: [20, 10, 10], 5: [50, 15, 35], 6: [105, 21, 84], 7: [196, 28, 168], 8: [336, 36, 300] };
  for (const [m, [a, b, c]] of Object.entries(rows)) { const k = E.curvature(+m); ok(k.riemann === a && k.ricci === b && k.weyl === c && k.riemann === k.ricci + k.weyl, `n = ${m}: ${a} = ${b} + ${c}`); ok(new RegExp(`^\\s*${m}\\s+${a}\\s+${b}\\s+${c}\\s`, 'm').test(L2), `n = ${m}: the row is in gtg_check.log`); }
  const k3 = E.curvature(3), k2 = E.curvature(2); ok(k3.riemann === 6 && k3.ricci === 6 && k3.weyl === 0 && k2.riemann === 1 && k2.weyl === 0 && E.curvature(3).scalarOnly && !E.curvature(4).scalarOnly, 'n = 3: 6 = 6 + 0; n = 2: Riemann 1; B^2 is a scalar up to n = 3');
}
// ---- 3. finite groups (Step 17)
{
  const esc = s => s.replace(/[+]/g, '\\+');
  for (const [m, e] of Object.entries(E.RAILS.E)) ok(new RegExp(`^\\s*${m}\\s+${esc(e[0])}\\s+\\d+\\s+${e[2]}\\s+${e[3]}\\s+${e[4]}\\s+${e[3]}\\s`, 'm').test(L3), `E rail n = ${m}: ${e[0]}, |W| ${e[2]}, image ${e[3]}, kernel ${e[4]} is in groups_check.log`);
  for (const [m, a] of Object.entries(E.RAILS.A)) { ok(new RegExp(`^\\s*${m}\\s+${a[0]}\\s+${a[1]}\\s+${a[2]}\\s+1\\s*$`, 'm').test(L3), `A rail n = ${m}: class ${a[0]}, S image ${a[1]}, |O(Q)| ${a[2]} is in groups_check.log`); ok(a[1] === E.factorial(+m + 1), `n = ${m}: the image is |S_(n+1)| = ${(+m) + 1}!`); }
  ok(Object.values(E.RAILS.E).every(e => e[2] === e[3] * e[4]), 'W(E_n) order = image times kernel');
  ok(Object.entries(E.RAILS.A).filter(([, a]) => a[1] === a[2]).map(([m]) => m).join() === '2,3,4,5' && E.RAILS.A[6][2] / E.RAILS.A[6][1] === 8 && E.RAILS.A[7][2] / E.RAILS.A[7][1] === 64 && E.RAILS.A[8][2] / E.RAILS.A[8][1] === 960, 'S_(n+1) fills O(Q) for n = 2..5 and has index 8, 64, 960 at n = 6, 7, 8');
  ok(E.RAILS.E[8][2] === 696729600 && E.RAILS.E[8][3] === 348364800 && E.RAILS.E[7][2] === 2903040, '|W(E8)| = 696 729 600, |W(E7)| = 2 903 040');
  // Golay
  const G = E.golay(); ok(JSON.stringify(G.hist) === '{"0":1,"8":759,"12":2576,"16":759,"24":1}' && G.octads.length === 759, 'Golay weights 0:1, 8:759, 12:2576, 16:759, 24:1');
  ok(/weights \{0: 1, 8: 759, 12: 2576, 16: 759, 24: 1\}/.test(L3), 'the same weights are in groups_check.log');
  ok(new Set(G.words).size === 4096 && Array.from(G.words).every(w => E.popcount(w) % 4 === 0), '4096 distinct words, every weight divisible by 4');
  let closed = true, orth = true; const W = Array.from(G.words); for (let i = 0; i < 300; i++) { const a = W[(i * 97) % 4096], b = W[(i * 389 + 11) % 4096]; if (!(new Set(W)).has(a ^ b) && closed) closed = false; if (E.popcount(a & b) % 2) orth = false; }
  ok(closed && orth, 'sums of words are words and words are pairwise orthogonal (sample of 300 pairs)');
  const S = new Set(W); let allSum = true; for (let i = 0; i < 12; i++) for (let j = 0; j < 12; j++) if (!S.has(W[1 << i] ^ W[1 << j])) allSum = false; ok(allSum, 'sums of generators are words');
  let steiner = 0, five = 0; const O = G.octads;
  for (let a = 0; a < 24; a++) for (let b = a + 1; b < 24; b++) for (let c = b + 1; c < 24; c++) for (let d = c + 1; d < 24; d++) for (let e = d + 1; e < 24; e++) { const m = (1 << a) | (1 << b) | (1 << c) | (1 << d) | (1 << e); let h = 0; for (const o of O) if ((o & m) === m) h++; five++; if (h === 1) steiner++; }
  ok(five === 42504 && steiner === 42504, 'every one of the 42 504 five-sets lies in exactly one octad: S(5,8,24)');
  const o0 = O[0], bits = []; for (let i = 0; i < 24; i++) if (o0 >> i & 1) bits.push(i);
  ok([1, 2, 3, 4, 5].map(k => O.filter(o => { const m = bits.slice(0, k).reduce((s, i) => s | (1 << i), 0); return (o & m) === m; }).length).join() === '253,77,21,5,1', 'octads through 1, 2, 3, 4, 5 points: 253, 77, 21, 5, 1');
  ok(E.octadThrough(O, bits.slice(0, 5).reduce((s, i) => s | (1 << i), 0)) === o0 && E.octadThrough(O, 1) === 'many', 'octadThrough finds the unique octad');
  // primes
  const newp = {}; for (const m of L3.matchAll(/^\s+(\d+): \[([\d, ]*)\]$/gm)) newp[+m[1]] = m[2] ? m[2].split(', ').map(Number) : [];
  ok(Object.keys(newp).length === 23, 'the log lists the primes entering at n = 2..24');
  ok(Object.entries(newp).every(([m, ps]) => JSON.stringify(E.newPrimes(+m)) === JSON.stringify(ps)), 'newPrimes(n) equals the log for n = 2..24');
  const ordLog = /\{3: 2, 5: 4, 7: 3, 11: 10, 13: 12, 17: 8, 19: 18, 23: 11, 29: 28, 31: 5, 41: 20, 47: 23, 59: 58, 71: 35\}/.test(L3); ok(ordLog && E.MONSTER_PRIMES.slice(1).every(p => ({ 3: 2, 5: 4, 7: 3, 11: 10, 13: 12, 17: 8, 19: 18, 23: 11, 29: 28, 31: 5, 41: 20, 47: 23, 59: 58, 71: 35 })[p] === E.ordTwo(p)) && E.MONSTER_PRIMES.length === 15, 'ord_p(2) of the 14 odd Monster primes equals the log');
  ok(E.newPrimes(6).length === 0 && E.newPrimes(36).length > 0, 'n = 6 brings no new prime (Zsigmondy)');
}
// ---- 4. the page: order, numbering, names, copy
ok(PAGES.indexOf('labels') === PAGES.indexOf('equations') + 1 && PAGES.indexOf('lenses') === PAGES.indexOf('labels') + 1 && PAGES.indexOf('map') === PAGES.indexOf('lenses') + 1, 'the labels page follows the equations, the lenses page follows the labels page, and the map follows the lenses page');
ok(STEP_GROUPS.labels.join() === 'clock,gauge,groups' && STEP_OFFSET.labels === STEP_GROUPS.eq.length && STEP_GROUPS.labels.map(id => stepNo('labels', id)).join() === '15,16,17' && stepTotal('labels') === 17, 'the three steps are 15, 16, 17 of 17');
ok(stepEyebrow('en', 'labels', 'gauge').startsWith('STEP 16 OF 17 · ') && stepEyebrow('it', 'labels', 'groups').startsWith('PASSO 17 DI 17 · '), 'eyebrows: STEP 16 OF 17, PASSO 17 DI 17');
for (const lang of ['en', 'it']) {
  for (const id of STEP_GROUPS.labels) for (const D of [NAV_NAMES, NAV_NAMES_YL, STEP_NAMES, STEP_NAMES_YL]) ok(typeof D[lang][id] === 'string' && D[lang][id].length > 3, `${lang} ${id} has a name in each of the four lists`);
  ok(STORY[lang].pages.labels === PAGE[lang] && STORY_YL[lang].pages.labels === PAGE_YL[lang] && STORY[lang].nav.labels && STORY[lang].tabsLbl.labels === TABS_LBL[lang], `${lang}: STORY holds the page copy, the nav name and the tab label`);
  for (const P of [PAGE[lang], PAGE_YL[lang]]) ok(P.h && P.does && P.before && P.after && P.tags.length === 4 && P.tags.map(t => t[0]).join() === 'checked standard,standard,checked standard ours,checked open', `${lang}: page copy has heading, text, before, after and the four tags (audit round-2 flags)`);
  ok(SHORT[lang].length === 2 && SHORT[lang][0].length > 60 && SHORT[lang][0].length < 330 && SHORT[lang][1].length > 60 && SHORT[lang][1].length < 460, `${lang}: the two short readings fit the limits of test_audience`);
}
const shape = (o, p = '') => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' && !Array.isArray(v) ? shape(v, p + k + '.') : [p + k + (typeof v === 'function' ? '()' : Array.isArray(v) ? '[' + v.length + ']' : '')]));
ok(shape(COPY.en).join() === shape(COPY.it).join(), 'English and Italian copy have the same shape');
ok(shape(COPY.en).length > 150, 'the copy is not empty (' + shape(COPY.en).length + ' entries)');
// plain words for the Young Learner: no formula markup, no algebra names
const yl = []; const collect = (o, p) => { for (const [k, v] of Object.entries(o)) { const path = p + '.' + k; if (typeof v === 'string') { if (/Y$/.test(k) || /\.(ledeY|namesY|typesY|rowsY|rotorY)/.test(path)) yl.push([path, v]); } else if (Array.isArray(v)) { if (/Y$/.test(k)) v.forEach((s, i) => typeof s === 'string' && yl.push([path + i, s])); } else if (v && typeof v === 'object') collect(v, path); } };
for (const lang of ['en', 'it']) { collect(COPY[lang], lang); yl.push([lang + '.page.does', PAGE_YL[lang].does], [lang + '.page.h', PAGE_YL[lang].h], [lang + '.short', SHORT[lang][0]]); PAGE_YL[lang].tags.forEach((t, i) => yl.push([lang + '.tag' + i, t[1]])); }
ok(yl.length > 60, 'the plain texts were found (' + yl.length + ')');
for (const [path, s] of yl) ok(!/[\^_{}√∑⟨⟩≠≤≥·]|Cl\(|\bO\(Q\)|M_\d|\bGL\b|\bW\(E/.test(s), `plain text without formulas: ${path}: ${s.slice(0, 80)}`);
// every status word used is one of the four
const GLANCE = { clock: 'checked standard,standard,checked ours,checked standard', gauge: 'checked standard ours,checked standard,ours,open', groups: 'checked standard,standard,checked standard ours,open' };
for (const lang of ['en', 'it']) for (const [id, t] of Object.entries(COPY[lang].tabs)) ok(t.glance.tags.map(x => x[0]).join() === GLANCE[id], `${lang}: tab ${id} has its four status lines (audit round-2 flags)`);
// the page names every script and test it stands on
ok(['labels_check.py', 'gtg_check.py', 'groups_check.py'].every(s => Object.values(COPY.en.tabs).some(t => t.glance.script.includes(s))), 'the tabs name the three scripts');
// known gap: the Map tree has no node for the labels page yet (README_update_v10.md, "Not done"); when nodes are added, this line must change
ok(!flat(TREE).some(x => x.go[0] === 'labels'), 'KNOWN GAP: the labels page is not on the Map tree yet');
console.log(bad ? `${bad} FAILURES of ${n}` : `ALL LABELS-PAGE TESTS PASS: ${n} checks`); process.exit(bad ? 1 : 0);
