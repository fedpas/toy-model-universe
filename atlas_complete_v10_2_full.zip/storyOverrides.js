// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Final wording for nodes whose text still claimed more than the audit supports.
// Applied last (see matrixData.js). Each entry: id -> lang -> profile -> { Spatial: {...}, Temporal: {...} }.
// A field given under Spatial and also needed in the Temporal reading is repeated explicitly; unspecified fields are kept.
const same = (o) => ({ Spatial: o, Temporal: { title: o.title, subtitle: o.subtitle, ...(o.grade ? { grade: o.grade } : {}) } });
export const STORY_OVERRIDES = {
  // grade: n = 0 has no grade 7 (re-check V3-6); the old caption "Grade 0 Identity / Grade 7 Inversion" reached every audience
  Sector_Vacuum_Mass_Generation: {
    en: {
      'Young Learner': same({ grade: 'Grade 0: just the number 1', title: 'The Invisible Origin Key', subtitle: 'A quiet starting point, and a guess about what it might become.', desc: 'Multiplying by the number 1 changes nothing, so it can sit quietly in the background. One idea in the toy model reads that quiet 1 as a sterile neutrino, and, when it acts, as the Higgs field that gives matter weight. That is only a reading: the rules do not produce either one, and they do not tell us any weights. Open.' }),
      Physicist: same({ grade: 'Grade 0 Identity', title: 'The scalar identity, read as Higgs and sterile neutrino', subtitle: 'An interpretation, not a derivation.', desc: 'Cl(0,0) = ℝ holds only the scalar identity. Reading its passive role as a sterile-neutrino state and its active role as the Higgs VEV operator is our interpretation. Neither is derived from the algebra, and no mass scale comes out of it. Open.' }),
      Mathematician: same({ grade: 'Grade 0 Identity', title: 'The identity scalar, Cl(0,0) = ℝ', subtitle: 'The Grade-0 identity as passive ideal and as active multiplier.', desc: 'Cl(0,0) = ℝ has one basis element, the unit. Passively it generates the trivial column ideal; actively it acts by left multiplication. Identifying these two roles with a sterile neutrino and a Higgs VEV is interpretive, and nothing in the algebra fixes a mass scale. Open.' })
    },
    it: {
      'Young Learner': same({ grade: 'Grado 0: solo il numero 1', title: 'La Chiave d’Origine Invisibile', subtitle: 'Un punto di partenza silenzioso e un’ipotesi su ciò che potrebbe diventare.', desc: 'Moltiplicare per il numero 1 non cambia nulla, quindi può restare tranquillo sullo sfondo. Un’idea del modello giocattolo legge quell’1 silenzioso come un neutrino sterile e, quando agisce, come il campo di Higgs che dà peso alla materia. È solo una lettura: le regole non producono né l’uno né l’altro e non ci dicono nessun peso. Aperto.' }),
      Physicist: same({ grade: 'Grado 0 Identità', title: 'L’identità scalare, letta come Higgs e neutrino sterile', subtitle: 'Un’interpretazione, non una derivazione.', desc: 'Cl(0,0) = ℝ contiene solo l’identità scalare. Leggere il suo ruolo passivo come stato di neutrino sterile e quello attivo come operatore del VEV di Higgs è una nostra interpretazione. Nessuno dei due deriva dall’algebra e non ne esce nessuna scala di massa. Aperto.' }),
      Mathematician: same({ grade: 'Grado 0 Identità', title: 'L’identità scalare, Cl(0,0) = ℝ', subtitle: 'L’identità di Grado 0 come ideale passivo e come moltiplicatore attivo.', desc: 'Cl(0,0) = ℝ ha un solo elemento di base, l’unità. In modo passivo genera l’ideale colonna banale; in modo attivo agisce per moltiplicazione a sinistra. Identificare questi due ruoli con un neutrino sterile e un VEV di Higgs è interpretativo, e nulla nell’algebra fissa una scala di massa. Aperto.' })
    }
  },
  Sector_Cosmic_Horizon: {
    en: {
      'Young Learner': same({ title: 'The Last Switch', subtitle: 'All eight switches on, and then the pattern starts again.', desc: 'Turn all eight switches on and you reach the biggest block, with 256 pieces. It is not a wall. The same kinds of box simply come around again: eight more switches give the old box, made sixteen times bigger.' }),
      Physicist: same({ title: 'The maximal pseudoscalar of Cl(0,8)', subtitle: 'Where the algebra types repeat.', desc: 'The product of all eight generators squares to +1, and the cell is Cl(0,8) ≅ Cl(4,4) ≅ Cl(8,0) ≅ M₁₆(ℝ). It is not a boundary: Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ), so the types repeat with matrices sixteen times larger. Reading it as a reset of the universe is a metaphor, not a result.' }),
      Mathematician: same({ title: 'The top pseudoscalar and period 8', subtitle: 'I₈² = +1 and Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ).', desc: 'The top blade e₁…e₈ squares to +1 and gives Cl(0,8) ≅ Cl(4,4) ≅ Cl(8,0) ≅ M₁₆(ℝ). Periodicity says the cell types repeat every 8 generators with matrices sixteen times larger (standard; the Maxwell test cross-checks the type table against its classical recursion). No new type appears and nothing is reset.' })
    },
    it: {
      'Young Learner': same({ title: 'L’Ultimo Interruttore', subtitle: 'Tutti gli otto interruttori accesi, e poi lo schema ricomincia.', desc: 'Accendi tutti e otto gli interruttori e arrivi al blocco più grande, con 256 pezzi. Non è un muro. Gli stessi tipi di scatola tornano semplicemente: otto interruttori in più danno la vecchia scatola, sedici volte più grande.' }),
      Physicist: same({ title: 'Lo pseudoscalare massimo di Cl(0,8)', subtitle: 'Dove i tipi di algebra si ripetono.', desc: 'Il prodotto di tutti e otto i generatori ha quadrato +1 e la cella è Cl(0,8) ≅ Cl(4,4) ≅ Cl(8,0) ≅ M₁₆(ℝ). Non è un confine: Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ), quindi i tipi si ripetono con matrici sedici volte più grandi. Leggerlo come un reset dell’universo è una metafora, non un risultato.' }),
      Mathematician: same({ title: 'Lo pseudoscalare massimo e il periodo 8', subtitle: 'I₈² = +1 e Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ).', desc: 'La lama massima e₁…e₈ ha quadrato +1 e dà Cl(0,8) ≅ Cl(4,4) ≅ Cl(8,0) ≅ M₁₆(ℝ). La periodicità dice che i tipi di cella si ripetono ogni 8 generatori con matrici sedici volte più grandi (standard; la prova di Maxwell controlla la tabella dei tipi contro la sua ricorsione classica). Non compare alcun tipo nuovo e nulla viene azzerato.' })
    }
  },
  // Row 7 (re-test T3-7): the old caption "Grade 7 Inversion Horizon" and the Mathematician's "threshold before global saturation" read period 8 as a closure; the cell only splits in two
  Sector_Row7_Mirror: {
    en: {
      'Young Learner': { Spatial: { grade: 'Grade 7: the piece made of all seven switches' }, Temporal: { grade: 'Grade 7: the piece made of all seven switches' } },
      Physicist: { Spatial: { grade: 'Grade 7 Central Pseudoscalar', title: 'The Cl(4,3) split into two halves' }, Temporal: { grade: 'Grade 7 Central Pseudoscalar' } },
      Mathematician: {
        Spatial: { grade: 'Grade 7 Central Pseudoscalar', title: 'The Cl(4,3) direct sum M₈(ℝ) ⊕ M₈(ℝ)', subtitle: 'A central top blade with square +1 splits the cell in two.', desc: 'Cl(4,3) has dimension 2⁷ = 128. In Cl(4,3) the top blade I = e₁e₂e₃e₄f₁f₂f₃ is central (n is odd) and I² = +1, so z± = ½(1 ± I) are central idempotents and the cell is M₈(ℝ) ⊕ M₈(ℝ), each piece a copy of the even part Cl(4,2) ≅ M₈(ℝ). Nothing saturates or closes here: row 8 has new cells, and the types go on repeating with period 8 (standard). Audit: Cl(4,3)=M₈(ℝ)², and the same split occurs at every Cl(k+1,k). The matter/antimatter reading is interpretive; the mirror cell is [7,−1]=Cl(3,4)=M₈(ℂ). In Furey §VIII (Obs. a), quark versus antiquark depends on the choice of complex structure L_{e₇} versus R_{e₇}, a Z₂ sign of J like ω→−ω here; she only proposes studying whether that choice bears on baryon asymmetry.' },
        Temporal: { grade: 'Grade 7 Central Pseudoscalar', subtitle: 'The mirror swaps the counts: M₈(ℝ) ⊕ M₈(ℝ) becomes M₈(ℂ).' }
      }
    },
    it: {
      'Young Learner': { Spatial: { grade: 'Grado 7: il pezzo fatto di tutti e sette gli interruttori' }, Temporal: { grade: 'Grado 7: il pezzo fatto di tutti e sette gli interruttori' } },
      Physicist: { Spatial: { grade: 'Grado 7 Pseudoscalare Centrale', title: 'La scissione in due metà di Cl(4,3)' }, Temporal: { grade: 'Grado 7 Pseudoscalare Centrale' } },
      Mathematician: {
        Spatial: { grade: 'Grado 7 Pseudoscalare Centrale', title: 'La somma diretta M₈(ℝ) ⊕ M₈(ℝ) di Cl(4,3)', subtitle: 'Una lama massima centrale con quadrato +1 divide la cella in due.', desc: 'Cl(4,3) ha dimensione 2⁷ = 128. In Cl(4,3) la lama massima I = e₁e₂e₃e₄f₁f₂f₃ è centrale (n è dispari) e I² = +1, quindi z± = ½(1 ± I) sono idempotenti centrali e la cella è M₈(ℝ) ⊕ M₈(ℝ), ciascun pezzo una copia della parte pari Cl(4,2) ≅ M₈(ℝ). Qui nulla si satura né si chiude: la riga 8 ha celle nuove, e i tipi continuano a ripetersi con periodo 8 (standard). Audit: Cl(4,3)=M₈(ℝ)², e la stessa scissione avviene in ogni Cl(k+1,k). La lettura materia/antimateria è interpretativa; la cella speculare è [7,−1]=Cl(3,4)=M₈(ℂ). In Furey §VIII (Oss. a), quark o antiquark dipende dalla scelta della struttura complessa L_{e₇} o R_{e₇}, un segno Z₂ di J come ω→−ω qui; lei propone solo di studiare se questa scelta c’entri con l’asimmetria barionica.' },
        Temporal: { grade: 'Grado 7 Pseudoscalare Centrale', subtitle: 'Lo specchio scambia i conteggi: M₈(ℝ) ⊕ M₈(ℝ) diventa M₈(ℂ).' }
      }
    }
  },
  // row 8 (re-test T3-7, same sweep): no saturation or closure reading of the cells at n = 8 in the remaining node-metadata subtitles
  Sector_Baryon_Conservation: {
    en: { Mathematician: { Spatial: {}, Temporal: { subtitle: 'The same conjecture, seen in the mirror.' } } },
    it: { Mathematician: { Spatial: {}, Temporal: { subtitle: 'La stessa congettura, vista nello specchio.' } } }
  },
  Sector_GUT_Junction: {
    en: {
      'Young Learner': { Spatial: { subtitle: 'A number that keeps showing up, and an open question.' }, Temporal: { subtitle: 'The same open question, seen in the mirror.' } },
      Physicist: { Spatial: { subtitle: 'A primorial label: 210 = 2·3·5·7, not derived.' }, Temporal: { subtitle: 'The same open question, seen in the mirror.' } },
      Mathematician: { Spatial: {}, Temporal: { subtitle: 'The same open question, seen in the mirror.' } }
    },
    it: {
      'Young Learner': { Spatial: { subtitle: 'Un numero che ritorna, e una domanda aperta.' }, Temporal: { subtitle: 'La stessa domanda aperta, vista nello specchio.' } },
      Physicist: { Spatial: { subtitle: 'Un’etichetta primoriale: 210 = 2·3·5·7, non derivata.' }, Temporal: { subtitle: 'La stessa domanda aperta, vista nello specchio.' } },
      Mathematician: { Spatial: {}, Temporal: { subtitle: 'La stessa domanda aperta, vista nello specchio.' } }
    }
  },
  Sector_Electroweak_Unified: {
    en: {
      Physicist: { Spatial: { title: 'The Neutral Cell and an Electroweak Reading', subtitle: 'An internal count of 17 neutral paths; Furey’s 3/8 is a separate computation.', desc: 'The centered 4-base, 4-fiber matrix contains 17 neutral paths, and the fraction 4/17 is an internal counting convention, not a Standard Model prediction. Furey’s 3/8 is a different computation: Tr_ℂ Y = ⅓·3 + ½·2 + 1·1 = 3 over dim_ℂ 𝕍 = 8 (her eqs. 44–45). Cell Cl(4,4) = M₁₆(ℝ) is verified.' } },
      // Cl(4,4) = M16(R) is simple (centre R, no proper two-sided ideal), so "intersections of principal sub-ideals" said nothing; replaced by what the data shows
      Mathematician: { Spatial: { title: 'The Neutral Cell Cl(4,4) ≅ M₁₆(ℝ)', subtitle: 'Central simple with centre ℝ; 4/17 is a counting convention.', desc: 'The neutral cell [8,0] is Cl(4,4) ≅ M₁₆(ℝ): a central simple algebra with centre ℝ, so it has no proper two-sided ideals, and its minimal left ideals are the columns ℝ¹⁶. Any "intersection of sub-ideals" here is trivial. The count 4/17 is an internal counting convention of the lattice, not a derived weak mixing angle, and it is not Furey’s 3/8, which is a trace computation. Cell Cl(4,4) = M₁₆(ℝ) is verified.' } }
    },
    it: {
      Physicist: { Spatial: { title: 'La Cella Neutra e una Lettura Elettrodebole', subtitle: 'Un conteggio interno di 17 percorsi neutri; il 3/8 di Furey è un calcolo diverso.', desc: 'La matrice centrata 4-base, 4-fibra contiene 17 percorsi neutri, e la frazione 4/17 è una convenzione di conteggio interna, non una previsione del Modello Standard. Il 3/8 di Furey è un calcolo diverso: Tr_ℂ Y = ⅓·3 + ½·2 + 1·1 = 3 su dim_ℂ 𝕍 = 8 (sue eq. 44–45). La cella Cl(4,4) = M₁₆(ℝ) è verificata.' } },
      Mathematician: { Spatial: { title: 'La Cella Neutra Cl(4,4) ≅ M₁₆(ℝ)', subtitle: 'Centrale semplice con centro ℝ; 4/17 è una convenzione di conteggio.', desc: 'La cella neutra [8,0] è Cl(4,4) ≅ M₁₆(ℝ): un’algebra centrale semplice con centro ℝ, quindi non ha ideali bilateri propri, e i suoi ideali sinistri minimi sono le colonne ℝ¹⁶. Qualsiasi «intersezione di sotto-ideali» qui è banale. Il conteggio 4/17 è una convenzione di conteggio interna al reticolo, non un angolo di mescolamento debole derivato, e non è il 3/8 di Furey, che è un calcolo di traccia. La cella Cl(4,4) = M₁₆(ℝ) è verificata.' } }
    }
  },
  Sector_EM_Maxwell: {
    en: {
      'Young Learner': { Spatial: { subtitle: 'Light as one equation, with a push part and a twist part.', desc: 'Light is a wave made of numbers: electric pushes and magnetic twists. With one line of space there is just one push. With three lines of space there are three pushes and three twists. The page “Test 1 · Maxwell” lets you add space and extra time one step at a time and shows every term.' } },
      Physicist: { Spatial: { subtitle: 'One equation, ∇F = J; three space plus time gives six components.', desc: 'F is a grade-2 element of the spacetime algebra: in three space dimensions plus time it has six components (E and B), obeying the single equation ∇F = J. Test 1 rebuilds it in 1 to 4 space and 1 to 4 time dimensions from the bit rule and checks every term exactly. This is standard geometric-algebra electromagnetism. No link to Furey’s model is claimed.' } },
      Mathematician: { Spatial: { desc: 'Grade is blade degree inside the algebra; the cell is the algebra itself. dF = 0 and d⋆F = J are the grade-3 and grade-1 parts of ∇F = J, and the field has C(n,2) components in n generators. Test 1 verifies the incidence structure exactly for every split (k,d) with k+d ≤ 5.' } }
    },
    it: {
      'Young Learner': { Spatial: { subtitle: 'La luce come una sola equazione, con una parte di spinta e una di torsione.', desc: 'La luce è un’onda fatta di numeri: spinte elettriche e torsioni magnetiche. Con una sola linea di spazio c’è una sola spinta. Con tre linee di spazio ci sono tre spinte e tre torsioni. La pagina «Prova 1 · Maxwell» ti fa aggiungere spazio e tempo extra un passo alla volta e mostra ogni termine.' } },
      Physicist: { Spatial: { subtitle: 'Una sola equazione, ∇F = J; tre dimensioni spaziali più il tempo danno sei componenti.', desc: 'F è un elemento di grado 2 dell’algebra dello spaziotempo: in tre dimensioni spaziali più il tempo ha sei componenti (E e B) e obbedisce all’unica equazione ∇F = J. La Prova 1 la ricostruisce da 1 a 4 dimensioni spaziali e da 1 a 4 temporali con la regola dei bit e verifica ogni termine in modo esatto. È elettromagnetismo standard in algebra geometrica. Non si afferma alcun legame con il modello di Furey.' } },
      Mathematician: { Spatial: { desc: 'Il grado è il grado della lama dentro l’algebra; la cella è l’algebra stessa. dF = 0 e d⋆F = J sono le parti di grado 3 e di grado 1 di ∇F = J, e il campo ha C(n,2) componenti con n generatori. La Prova 1 verifica in modo esatto la struttura di incidenza per ogni suddivisione (k,d) con k+d ≤ 5.' } }
    }
  }
};
export function applyStory(id, lang, profile, metricMode, rec) {
  const o = STORY_OVERRIDES[id]?.[lang]?.[profile]?.[metricMode];
  return o && Object.keys(o).length ? { ...rec, ...o } : rec;
}
