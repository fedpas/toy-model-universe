# Label speed test (`label_bench.html`)

A single standalone page that **times**, in your own browser, whether the "bit-label" speed-ups claimed in the maths app give any gain on your machine.
It measures; it does not prove. A result is true of this browser, this machine, its power mode and the load it had at that moment, and of nothing else.

**What is ours and what is standard** (shown at the top of the page and in every section; this table is the page's own, word for word, and `test_label_bench.mjs` compares the two): for each job the page times the *standard* method against *ours*, on the same inputs, after checking that both give the same answers (within 1e-9 relative; the product kernels exactly). "Ours" is used only where the label's own idea is what is timed.

| Job | Standard | Ours |
|---|---|---|
| Vertices of the cube | the matrix route built from the same frame (n² multiplications a corner) | doubling by the label from the same frame (one addition a corner) |
| Vertices: the frame (both standard) | one sandwich per corner (2^n sandwiches); the frame: n + 1 sandwiches, then additions (linearity of the sandwich) | none: no idea of the label is timed here |
| Contact: deepest corner under a plane | scan of all 2^n corners | n sign bits of the frame |
| Outline of the projected cube | convex hull of the 2^n projected points | zonogon from the n projected edges |
| Product of two dense multivectors | the matrix route: Cl(k,k) = M(2^k, R), the textbook way | the bit rule: signs from the labels (XOR), here with a sign table |
| Many bodies, contact step | build each body’s table from its frame, then scan | build each body’s frame, then n sign bits |
| Allocation | Float64Array | plain Array (the engine’s choice) |

The frame (n + 1 sandwiches, then 2^n − 1 additions) replaces 2^n sandwiches by linearity of the sandwich, a standard fact; the bit label is only the address (the step-13 copy says the same). Up to 1.2.0 the page tagged the frame "ours" and credited it with its gain over one sandwich per corner; since 1.2.1 that comparison is shown as one of two standard methods, and the vertices job compares the label's own part, the doubling, with its standard rival from the same frame, the matrix route. The same holds for Many bodies: its key comparison is now sign bits against the scan, both built from the frame; the whole path (direct and scan against frame and sign bits) is still timed, in the folded comparisons, with a note that it mixes the two.

After a run, **At a glance** gives one row per job, read from the side of ours: the ratio (standard time / ours) at the largest size timed, the verdict, a noisy flag, and by n where ours is faster; a row marked *both standard* (the frame against one sandwich per corner) is shown for context and left out of the tally. Above it a generated sentence names the best result *of that run* and, if there is one, where ours loses (in the product, the matrix route wins from some n on; the page says so). The sentence is computed from the timings, nothing in it is fixed. To show a fixed sentence about our best model as well, put it in `OUR_SENTENCE` at the top of the scenario block in `label_bench_src/page.js` and rebuild; it is then shown above the generated text.

## Open it
Download `label_bench.html` and double-click it (Chrome, Firefox or Safari, `file://` is fine). It makes no network request, loads no library and no font, and sends nothing anywhere.
For a stable result: close other tabs, plug in the power, keep the tab in the foreground, do not resize the window while it runs. Press **Run** (the **Quick** preset is selected: 20 ms batches, 3 repetitions);
use **Careful** (200 ms batches, 15 repetitions) when a row is flagged noisy. **Stop** ends the run and keeps what has been timed.

The timing runs in a Web Worker built from a Blob URL of the same inlined source, so the page stays responsive. If a Worker cannot be started the page falls back to the main thread (chunked with `setTimeout`)
and says so under the buttons ("Mode: ..."). Adding `#main` to the address forces the fallback.

## The scenarios (each runs the correctness check first: all variants must give the same answers, otherwise nothing is timed)
| Scenario | What is timed, per call |
|---|---|
| **Vertices** | The 2^n world corners of an n-cube from a motor: *direct* (2^n sandwiches), *frame* (n+1 sandwiches then 2^n-1 additions), *frame with the odd half mirrored through the centre*, the *matrix route* (frame, then n^2 flops a corner), and the table step alone (doubling against n^2 a corner, frame given). Claim: frame against direct. |
| **Contact** | The deepest corner under a plane: *scan* of 2^n dot products against *n sign bits* of the frame, with the table or frame **given** and with its **building counted**. |
| **Outline** | The flat outline of the projected cube: *convex hull* of the 2^n points against the 2n-corner *zonogon* from the n projected edges, given and building counted. |
| **Product** (new in 1.1.0) | The dense product of two multivectors of the neutral algebra Cl(k,k), n = 2k = 2, 4, ..., 12 (14 optional and slow). *Bit rule*: 4^n terms, each sign worked out. *Sign table*: the same terms, signs read from a table built before the clock. *Matrix route*: Cl(k,k) = M(2^k, R), so the multivector becomes a 2^k x 2^k real matrix (a butterfly on each of the k sites, k 4^k additions), one matrix product (8^k multiplications), and back. *Matrix product alone*: the matrices already exist. *Period 8 blocks* (n >= 10): Cl(N+8) = M16(Cl(N)), the product as 16^3 = 4096 products in Cl(n-8) by the bit rule. **Allocation (new in 1.2.1)**: as written, one call of the matrix route allocates seven Float64Arrays of 2^n doubles (the sign-table product one), so *matrix route, whole* measures the route **plus** that allocation; *matrix route, buffers allocated once* runs the same arithmetic on buffers made before the clock (and *sign table, output allocated once* likewise), so it measures the route itself; *the route's 7 allocations alone* times those seven allocations and nothing else. Inputs are dense integers; the check compares the answers **exactly** (`===`) before any timing, on the timed inputs and on a second pair, the reused-buffer variants twice; `selfcheck/matrixrep_check.py` proves the representation in exact Python integers (the page's tables are rebuilt in JavaScript and `test_product.mjs` compares them with its fixtures). Claim: the matrix route against the sign table (as written, and with buffers allocated once), against the plain rule, the matrix product alone, and the period-8 blocks. Counting operations only, the matrix product alone needs 2^(n/2) times fewer multiplications than the bit rule has terms (2x more per two dimensions), and the whole route, with k 4^k additions each way, is about even with the bit rule at n = 4 and cheaper from n = 6. What one machine measured is in the table below, generated from `selfcheck/bench_labels.json`; it is not claimed to follow 2x per two dimensions (at small n the timings of the route as written are dominated by allocation; compare its rows). n = 14 is offered by the page but not timed in the stored run. Sparse multivectors (a few blades) are another case and are not timed. |
| **Many bodies** | B bodies (100, 1000, 10000), each with its own motor from a seeded generator (seed 12345, so the scene is reproducible). One scene step: build every body's corners (direct against frame); a contact query of every body against one plane (scan against sign bits, given and building counted); and the whole path (direct and scan against frame and sign bits). Reported as ms per scene step and bodies per second. Motors are fixed: integrating the dynamics is not counted. |
| **Warm-up and cold start** | Call 1, calls 1-10, 11-100, 101-1000 of one function against its steady state. Every repeat starts a **fresh worker** so the code is cold (in main-thread mode it cannot be, and the page says so). The set-up (algebra tables, motor) is outside the clock. Times below the timer step are shown as upper bounds, not as numbers. |
| **Allocation** | Plain `Array` against `Float64Array` for allocating 8, 16, 32 and 64 doubles, and for a small sandwich-like loop (with and without reused Float64Array buffers). Reproduces, or not, the finding that made the engine use plain arrays; node's figures are stored in the alloc rows of `selfcheck/bench_labels.json` (same kernel, `allocKernels` in benchKernels.js; table below), and the page quotes them from its embedded reference run. Whatever your browser gives is shown. |

## The stored run (node, one machine; timed, not proved)
The page embeds this run as its *reference run*; the step-13 copy, the Map and the persona read the same file through `benchData.js`. The tables are generated, so they follow a re-timing (`sh selfcheck/regen_bench.sh`).

<!-- bench_tables:product begin -->
Stored run: node v22.22.0, Intel(R) Xeon(R) Processor @ 2.10GHz, 2 cores, 2026-10-04; batches of at least 60 ms, median of 7 (`selfcheck/bench_labels.json`). Generated by `selfcheck/bench_tables.mjs`; do not edit by hand.

| n | 2 | 4 | 6 | 8 | 10 | 12 |
|---|---|---|---|---|---|---|
| counting: bit-rule terms / matrix-product multiplications, 2^(n/2) | 2 | 4 | 8 | 16 | 32 | 64 |
| sign table / matrix route as written (the route plus its 7 allocations a call) | 0.26× | 0.13× | 0.37× | 3.34× | 19.3× | 54.6× |
| the same with buffers allocated once on both sides (the route itself) | 0.47× | 0.90× | 2.84× | 8.44× | 23.0× | 58.4× |
| the route's 7 allocations alone, share of the route as written | 63 % | 73 % | 63 % | 78 % | 40 % | 8 % |
| plain bit rule / matrix route as written | 0.41× | 0.13× | 2.00× | 25.7× | 183.5× | 618.5× |
| plain bit rule / matrix product alone (matrices given) | 1.75× | 0.95× | 19.1× | 119.1× | 337.9× | 871.5× |
| growth of the last row per two dimensions | – | 0.54× | 20.0× | 6.24× | 2.84× | 2.58× |
| largest spread of the timings in the column | 41 % | 55 % | 129 % | 31 % | 9 % | 13 % |

Noise (the page's "⚠ noisy" marker, a spread above 15 %): 15 of the 44 product timings of this run, up to 129 %; the ratio as written rests on such a timing at n = 2, 4, 6 and 8, the one with buffers allocated once at n = 4; read the ratios built on noisy timings as direction only, and re-time on an idle machine (`sh selfcheck/regen_bench.sh`) before relying on the exact figures.
<!-- bench_tables:product end -->

<!-- bench_tables:alloc begin -->
Allocation of one multivector (`allocKernels` in benchKernels.js, the kernel of the page's Allocation scenario). Stored run: node v22.22.0, Intel(R) Xeon(R) Processor @ 2.10GHz, 2 cores, 2026-10-04; batches of at least 60 ms, median of 7 (`selfcheck/bench_labels.json`). Generated by `selfcheck/bench_tables.mjs`; do not edit by hand.

| doubles | 8 | 16 | 32 | 64 |
|---|---|---|---|---|
| plain Array (the engine's choice) | 62 ns | 85 ns | 106 ns | 174 ns |
| Float64Array | 42 ns | 1.9 µs | 1.9 µs | 1.8 µs |
| Float64Array / plain Array | 0.67× | 22.4× | 18.1× | 10.6× |
| largest spread of the two | 21 % | 29 % | 16 % | 65 % |

Noise (the page's "⚠ noisy" marker, a spread above 15 %): 5 of the 8 allocation timings of this run, up to 65 %; read the ratios built on noisy timings as direction only, and re-time on an idle machine (`sh selfcheck/regen_bench.sh`) before relying on the exact figures.
<!-- bench_tables:alloc end -->

## How to read a row
* **At a glance**: ratio = standard time / ours (medians), so 3x means ours took a third of the time and 0.3x is shown as "3.3x slower". The verdict rule below is applied in the direction of the detail comparison (so the product row is the matrix route against the sign-table bit rule, turned around to read from ours).
* **Detail tables**: only the key comparison of each scenario is open (marked *key result*); the other comparisons, all timings and the method text are folds (open them with the arrows). In Many bodies and Warm-up the timing table is the result and stays open.
* **Ratio** = baseline time / variant time (medians). For example, "frame is 4.00x faster" would mean the frame took a quarter of the baseline's time, and "frame is 0.50x, i.e. slower" twice that time.
* **Spread** of a timing = (slowest batch - fastest batch) / median over the repetitions. Above 15% the row is flagged "⚠ noisy" (repeat with Careful).
* **Verdict** (on the log scale since 1.2.1): *about equal within noise* when |ln ratio| < ln(1 + t), where t is the larger of 5% and the larger spread of the two timings, i.e. when the ratio lies between 1/(1 + t) and 1 + t; otherwise *faster* or *slower*. A k-fold gain and a k-fold loss are judged alike. (Up to 1.2.0 the rule was |ratio - 1| < t; since a loss has a ratio below 1, a loss of any size read "about equal" once the spread reached 100%, while a gain of the same size read "faster".) A rule of thumb for one run, not a statistical test.
* **Chart**: log scale, bars start at the 1x line (up: faster, down: slower), colour follows the verdict, and every bar carries its value as text (`*` = noisy). Hatched bars are the "building counted" series.
* **Timer step**: the smallest observable step of `performance.now()` is measured and shown. Above 5 µs the page warns and compares the quantisation of a batch (one step against the batch length) with the 5% floor of the verdict: below 1% (a fifth of the floor) it calls it small, from 1% *comparable to* the floor, from 5% *as large as or larger than* it, as with a 1 ms timer and the 20 ms batches of Quick (5.0%: then use Careful, 200 ms batches, 0.5%). Single-call times (warm-up) are then only indicative. (Correction, 2026-10-05: this line said that batches of at least 20 ms make a coarse timer irrelevant, and the page called a 5.0% quantisation "small next to the 5% floor"; found by an independent re-test, T5-5.)
* **Not judged**: a comparison whose timing has a median of 0 (its batches were shorter than one timer step, as when an interruption of the thread ends the calibration of the batch length early) is shown as *not judged* and counted in the banner, never left out. Since 1.2.2 the page also times such a variant again, at most twice, when its median batch lasted less than half the batch length (`retimed` in the JSON cells); node's `runBench` does not.

## Save, share, compare
**Download JSON** (settings, machine info, checks, rows, and, new in 1.2.0, `glance`: the At a glance rows and summary; `formatVersion` is still 1, the field is additive; since 1.2.1 each glance row has a `kind`, `ours-vs-standard` or `standard-vs-standard`, and the product cells include the new variants), **Download CSV** (one row per timing and per ratio), **Copy as text** (a readable summary, also shown in the "Text summary" box).
To compare two machines, send the JSON; the other person opens the page, runs it, and loads your JSON under **Compare with another run** (or loads the embedded *reference run on one 2-core VM, node 22*).
The table shows the claimed ratio on each side and the ratio between the two. The product timings are in the JSON under `product` and in the CSV and the text summary; the comparison table covers the vertices, contact and outline scenarios only. The JSON `rows` have the same shape as `selfcheck/bench_labels.json`, so a file from `node selfcheck/bench_labels.mjs --write file.json` can be loaded as well.
Everything stays in your browser.

## Versions
The kernel fingerprint is the first 12 hex digits of the SHA-256 of the inlined kernels (pgaEngine.js, benchKernels.js, productKernels.js, import/export removed); the page shows it in the footer and in the machine panel, and an export carries it, so two runs can be told apart when their timed code differs. `test_label_bench.mjs` checks that the fingerprint below is the one the build computes.
* **1.2.2** (kernel fingerprint **c261bead202f**, unchanged from 1.2.1: no kernel changed): fixes from an independent re-test. The coarse-timer note compares the quantisation of a batch honestly with the 5% floor of the verdict (it called 5.0% "small next to" 5%); a timing whose calibration was cut short by an interruption (median batch under half the batch length) is taken again, at most twice, in the page's wrapper of `timeIt` (`label_bench_src/runners.js`; `timeIt` itself is unchanged); a comparison that cannot be judged (a median of 0) is shown as *not judged* and counted in the banner instead of disappearing from its table. The README tables carry a generated noise line (how many timings of the stored run are noisy, and the largest spread).
* **1.2.1** (kernel fingerprint **c261bead202f**; 1.2.0 was 8b111dc05052): fixes from an independent audit of the speed test. The fingerprint changed because the timed code changed: `productKernels.js` gained optional output buffers (same arithmetic), the matrix route with its seven work arrays allocated once (`productMatrixRouteReuse`), the sign-table product with its output allocated once, the seven allocations of one route call alone (`productRouteAllocs`), and a check on the timed inputs (seed 1) as well as on a second pair; `benchKernels.js` gained the allocation kernel (`allocKernels`, moved there from the page so that node and the page time the same code); a comment in `pgaEngine.js` lost an allocation figure that no stored run held. Page: the verdict is judged on the log ratio (a k-fold gain and a k-fold loss alike); the frame is tagged standard and the vertices job compares doubling with the matrix route from the same frame, the frame against one sandwich per corner is shown as two standard methods outside the tally; Many bodies compares sign bits with the scan, both from the frame; the product shows the route as written (route plus allocation), with buffers allocated once (the route itself) and its allocations alone; the checks say "within 1e-9 relative (the product kernels exactly)" instead of "identical"; the allocation figure of node is read from the embedded reference run; no sideways scroll at 320 px. `selfcheck/bench_labels.mjs` now also writes the new product rows and allocation rows, and `selfcheck/regen_bench.sh` re-times, regenerates `benchData.js`, the README tables and the page, and runs the test.
* **1.2.0**: a clearer page, no change to any timed code (same kernel fingerprint, same variants, same verdict rule). A short opening and a table of what is standard and what is ours; a new **At a glance** table with a generated best-result sentence (and where ours loses); each section opens with the standard/ours pair and shows its key comparison, with the other comparisons, all timings and the method text folded; the seven repeated "correctness check passed" paragraphs became one line each; hints, notes and warnings are shorter (about 30% less text on screen after a run); the noisy tag in tables is just "⚠ noisy" (the banner says what to do); the chart titles say which side is ours; the text summary and the JSON carry the glance. The pre-existing `Many bodies` and `Warm-up` tables stay open. (Correction, 2026-10-04: this entry said "v1.1.1 is kept unchanged next to it"; no 1.1.1 page is in the package, only the current `label_bench.html`, so the "same kernel fingerprint" of the versions below cannot be compared from the package.)
* **1.1.1**: the text summary now prints the scenario settings (Many bodies: B, n and seed; product: largest n; warm-up: n) and the Many-bodies heading carries B and n. Before, only the CSV and JSON did, so two summaries from runs with different scene sizes looked comparable. Timings and checks are unchanged (same kernel fingerprint).
* **1.1.0**: the Product scenario.

## Regenerate
```
node build_label_bench.mjs          # writes label_bench.html (deterministic: same sources, same bytes); embeds selfcheck/bench_labels.json as the reference run
node test_label_bench.mjs           # Playwright checks, prints LABEL BENCH OK (LB_FINAL=1: also fails while the stored run predates 1.2.1)
node selfcheck/bench_tables.mjs     # checks the generated tables above against selfcheck/bench_labels.json (--write rewrites them)
sh selfcheck/regen_bench.sh         # re-time on this machine (idle, plugged in): bench_labels.json, benchData.js, the tables, the page, then the tests
sh selfcheck/regen_bench.sh --dry   # the same without the timing, from the stored run
```
The build inlines the **real source** of `pgaEngine.js`, `benchKernels.js` and `productKernels.js`: only the `import` line and the `export` keywords are removed, mechanically.
The variants that the page times are not retyped: the 14 lambdas and the set-up line are cut out of `runBench` in `benchKernels.js` at build time (the build fails if that file changes shape), so the page cannot drift from the kernels the app uses.
The page-specific code is in `label_bench_src/` (`template.html`, `style.css`, `runners.js` for the scenarios and the worker side (the product job is there), `page.js` for the interface). `test_label_bench.mjs` needs Playwright (module path at the top of the file).

## What this does not show
Other machines, browsers, engines and languages are open; WebAssembly and SIMD were not tried; the kernels are small plain-JavaScript functions; the counts of operations are an arithmetic fact, the seconds are a measurement
with a spread. The worker's results are shown live, which costs the page a little work on another thread while the worker times; on a one-core machine that can add noise.
