// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';
import { KIT_STYLE, Tags, ScriptBox, HonestyBar } from './LensKit.jsx';
import LensMatrix from './LensMatrix.jsx';
import { Fold, level } from './Fold.jsx';
import { FOLD } from './audienceCopy.js';
import { THEOREMS } from './researchersData.js';
import { RS } from './researchersCopy.js';
import { scrollToAnchor } from './StoryShell.jsx';
import { COPY, PAPERS, TEN_ROWS, GAP_IDS, SECTIONS, SECTIONS_YL } from './baezCopy.js';
import { BAEZ_CHECK_PY } from './baezSelfcheckSource.js';
import { BW1, BW2, BW3, BW4, BW5, BW6, BW7, BaezWidgetsScript } from './BaezWidgets.jsx';

// Step 19 of the lenses page: seven papers by John Baez and where the bit rule meets them (DECISIONS.md §2 of the v10.2 round).
// Three voices: the Young Learner reads plain sections and the pictures, and finds the findings with their formulas in a closed fold "For older readers";
// the Physicist reads a short introduction with the statements one click away, and the long findings, the notes and the matrix in folds; the Mathematician
// reads everything open. Every statement is a tagged line (class eq-pt: a column of tags, then the text), the shape the reader filter knows. The widgets are
// BaezWidgets.jsx (the B agent's file), each inside its own anchor of this chapter (bz-w-…), shown to exactly the audiences DECISIONS gives:
//   BW1 all · BW2 P/M · BW3 P/M · BW4 all · BW5 all · BW6 all · BW7 Young Learner and Physicist · BaezWidgetsScript all.
// The words are in baezCopy.js; test_lens_baez.mjs checks them, test_lens_baez_ui.mjs drives this page.
const STYLE = `
.bz-sec{margin-top:26px;scroll-margin-top:72px}.bz-sec>h3:focus{outline:none}.bz-sec>h3:focus-visible{outline:2px solid #4aa8ff;outline-offset:2px}
.bz-find{border-left:3px solid rgba(128,128,128,.35);padding:2px 0 2px 12px;margin:14px 0;min-width:0}.bz-find h4{margin:.2em 0 .4em;font-size:.98em;line-height:1.35}
.bz-scope{border-left:3px solid rgba(251,191,36,.75);padding:4px 10px;margin:10px 0;font-size:.92em}
.bz-words{font-size:.85em;opacity:.85;margin:8px 0}
.bz-papers{list-style:none;padding:0;margin:8px 0}.bz-papers>li{margin:.7em 0;min-width:0}.bz-papers .bz-pt{font-weight:600}.bz-papers .ln-mono{display:inline}
.bz-gaps{margin:6px 0 6px 1.1em;padding:0}.bz-gaps li{margin:.25em 0;overflow-wrap:anywhere}
.bz-corr{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:8px 12px;margin:10px 0;font-size:.9em}.bz-corr p{margin:.25em 0;overflow-wrap:anywhere}.bz-corr del{opacity:.7}
.bz-q{font-style:italic}.bz-w{min-width:0}.bz-links{font-size:.88em}.bz-links a{color:inherit}
.bz-ten th,.bz-ten td{padding:3px 10px 3px 0;white-space:nowrap}
`;
const kinds = k => (Array.isArray(k) ? k : String(k || '').split(/\s+/)).filter(Boolean);
// a text with its check ids (baez·H1a, bridge·A6, Thm T13(4) …) drawn as code: an id is a name, the same in both languages
const IDS = /((?:baez|bridge|cat|fibre|qm|catw|bzw|scw)·[A-Z]\d*[a-z]?(?:–[A-Z]\d*[a-z]?)?|Thm T\d+(?:\([^)]*\))?)/;
const TxIds = ({ s }) => <>{String(s).split(IDS).map((x, i) => (i % 2 ? <code key={i} className="ln-id">{x}</code> : x ? <Tx key={i}>{x}</Tx> : null))}</>;
// one tagged statement: [tags, text] or, for the Young Learner, [tags, text, [check ids]]
function Line({ l, lang, label }) {
  return <div className="eq-pt"><div style={{ minWidth: 92 }}><Tags kinds={kinds(l[0])} lang={lang} /></div>
    <p><TxIds s={l[1]} />{label && l[2] && l[2].length ? <span className="ln-chk"> · <span className="ln-k">{label}</span>{l[2].map(c => <code key={c} className="ln-id">{c}</code>)}</span> : null}</p></div>;
}
const Lines = ({ items, lang, label }) => <div>{items.map((l, i) => <Line key={i} l={l} lang={lang} label={label} />)}</div>;
// a finding of the report: id, title, its lines (each with its own tags), the checks that carry it
function Finding({ f, lang, t }) {
  return <div className="bz-find" id={'bz-' + f.id.toLowerCase()} data-finding={f.id}>
    <h4><code className="ln-id">{f.id}</code> <Tx>{f.title}</Tx></h4><Lines items={f.lines} lang={lang} />
    <p className="ln-chk"><span className="ln-k">{t.checks}</span> {f.checks.map(c => <code key={c} className="ln-id">{c}</code>)}</p></div>;
}
// a widget of the B agent, inside this chapter's anchor
const W = ({ id, C, lang, profile }) => <div id={id} className="bz-w" data-slot={id}><C lang={lang} profile={profile} /></div>;
// a section with its anchor; its heading takes the focus when the in-page menu jumps to it
const Sec = ({ id, h, children }) => <section className="bz-sec" id={id} aria-labelledby={id + '-h'}><h3 id={id + '-h'} tabIndex={-1}><Tx>{h}</Tx></h3>{children}</section>;
function Menu({ label, items }) {
  const jump = id => { scrollToAnchor(id); const h = document.getElementById(id + '-h'); if (h) { try { h.focus({ preventScroll: true }); } catch { /* ignore */ } } };
  return <nav className="ln-menu" id="bz-menu" aria-label={label}>{items.map(([id, txt]) => <button key={id} type="button" data-go={id} onClick={() => jump(id)}><Tx>{txt}</Tx></button>)}</nav>;
}
const fid = (t, id) => t.findings.find(f => f.id === id);
// the theorems of the page For researchers that this chapter cites (their status and verifier are read from researchersData.js, never retyped)
const THM_IDS = ['T3', 'T4', 'T6', 'T10', 'T13', 'T20'];
// what the Young Learner does not get even in the fold for older readers (DECISIONS §2 Leave out and the learner's note): J6 and its perspective P6,
// the cospan reading J10 and its perspective P8, and P5
const YL_OUT = ['J6', 'J10', 'P5', 'P6', 'P8'];

// the eleven signatures (p, 10 − p) of finding J7, as a table with its caption line
function TenTable({ t, lang }) {
  return <div className="bz-tenbox"><h4><Tx>{t.tenH}</Tx></h4><div className="ln-wrap"><table className="ln-tab bz-ten" data-ten="11"><thead><tr>{t.tenCols.map((c, i) => <th key={i} scope="col"><Tx>{c}</Tx></th>)}</tr></thead>
    <tbody>{TEN_ROWS.map(r => <tr key={r[0]} data-star={r[4] ? '1' : '0'}>{r.map((c, i) => (i === 0 ? <th key={i} scope="row"><Tx>{c}</Tx></th> : <td key={i}><Tx>{c}</Tx></td>))}</tr>)}</tbody></table></div>
    <Line l={t.tenCap} lang={lang} /></div>;
}

// the formal findings, shared by the Physicist and the Mathematician (main text) and by the Young Learner (inside the fold for older readers)
function FindingsBody({ t, L, profile, lv, yl }) {
  const open = lv >= 2, P = { lang: L, profile };
  const F = id => <Finding f={fid(t, id)} lang={L} t={t} />;
  if (yl) return <div className="bz-older">
    {F('J1')}{F('J2')}
    <div id="bz-ladder">{F('J3')}</div>
    <div id="bz-ten">{F('J7')}<TenTable t={t} lang={L} /></div>
    {F('J8')}{F('J9')}{F('J4')}
    <div id="bz-more">{F('J5')}</div>
    <h4><Tx>{t.sec.persp}</Tx></h4>{t.persp.filter(p => !YL_OUT.includes(p.id)).map(p => <div key={p.id} className="bz-find" data-persp={p.id}><h4><code className="ln-id">{p.id}</code> <Tx>{p.title}</Tx></h4><Line l={[p.kinds, p.text]} lang={L} /></div>)}
  </div>;
  return <>
    <Sec id="bz-generation" h={t.sec.generation}><W id="bz-w-family" C={BW1} {...P} />{F('J1')}{F('J2')}</Sec>
    <Sec id="bz-ladder" h={t.sec.ladder}><W id="bz-w-ladder" C={BW3} {...P} />{F('J3')}</Sec>
    <Sec id="bz-which" h={t.sec.which}><p className="bz-links"><button type="button" className="ln-btn" data-go="bz-w-which" onClick={() => scrollToAnchor('bz-w-which')}><Tx>{t.whichHook}</Tx></button></p>{F('J6')}</Sec>
    <Sec id="bz-ten" h={t.sec.ten}>{F('J7')}<TenTable t={t} lang={L} /></Sec>
    <Sec id="bz-kepler" h={t.sec.kepler}><W id="bz-w-kepler" C={BW4} {...P} />{F('J8')}<p className="bz-links"><a href="#equations/projective"><Tx>{t.step9Link}</Tx></a></p></Sec>
    <Sec id="bz-periodic" h={t.sec.periodic}>{lv === 1 && <W id="bz-w-madelung" C={BW7} {...P} />}<Fold title={t.periodicFold} open={open}>{F('J9')}</Fold></Sec>
    <Sec id="bz-ring" h={t.sec.ring}><W id="bz-w-ring" C={BW6} {...P} /><Fold title={t.ringFold} open={open}>{F('J4')}</Fold></Sec>
    <Sec id="bz-more" h={t.sec.more}><Fold title={t.foldFinding('J5')} open={open}>{F('J5')}<p className="bz-links"><a href="#lenses/category"><Tx>{t.catLink}</Tx></a> · <a href="#equations/rigid"><Tx>{t.step13Link}</Tx></a></p></Fold>
      <Fold title={t.foldFinding('J10')} open={open}>{F('J10')}</Fold></Sec>
  </>;
}

function FormalBody({ t, L, profile, lv }) {
  const P = { lang: L, profile }, F = FOLD[L] || FOLD.en, M = lv >= 2;
  const R = (RS[L] || RS.en).theorems, thms = THEOREMS.filter(x => THM_IDS.includes(x.id));
  const statements = <div className="bz-mlede"><h4><Tx>{t.mH}</Tx></h4><p className="ln-cap"><Tx>{t.mIntro}</Tx></p><Lines items={t.ledeM} lang={L} />
    <div className="bz-thm"><h4><Tx>{t.thmH}</Tx></h4>{L === 'it' ? <p className="ln-cap lang-note"><Tx>{t.thmLangNote}</Tx></p> : null}
      <ul className="bz-gaps">{thms.map(x => <li key={x.id} data-thm={x.id}><code className="ln-id">{'Thm ' + x.id}</code> <span lang="en"><Tx>{x.title}</Tx></span> · <Tx>{R.status[x.status] || x.status}</Tx> · <Tx>{R.verifier[x.verifier] || x.verifier}</Tx> · <code className="ln-id">{'researchers_checks/' + x.script}</code></li>)}</ul></div></div>;
  return <>
    <h2 id="bz-h"><Tx>{t.title}</Tx></h2>
    <div id="bz-top"><p className="lede"><TxIds s={M ? t.ledeMath : t.lede} /></p><Lines items={t.ledePts} lang={L} />
      <p className="bz-scope" data-scope="1"><Tx>{t.scope}</Tx></p>
      {M ? statements : <Fold title={F.full} open={false}>{statements}</Fold>}
      <p className="bz-words"><Tx>{t.words}</Tx></p>
      <W id="bz-w-which" C={BW2} {...P} /></div>
    <Menu label={t.menuLbl} items={SECTIONS.map(s => ['bz-' + s, t.menu[s]])} />
    <Sec id="bz-papers" h={t.sec.papers}><p><Tx>{t.papersIntro}</Tx></p>{L === 'it' ? <p className="ln-cap lang-note"><Tx>{t.papersLangNote}</Tx></p> : null}
      <ul className="bz-papers">{PAPERS.map(p => <li key={p.id} data-paper={p.id}><span lang="en"><span className="bz-pt"><Tx>{p.title}</Tx></span> · <Tx>{p.who}</Tx></span> · <code className="ln-mono">{p.arxiv}</code><Line l={t.papers[p.id]} lang={L} /></li>)}</ul>
      <Lines items={t.papersPts} lang={L} /><W id="bz-w-papers" C={BW5} {...P} /></Sec>
    <FindingsBody t={t} L={L} profile={profile} lv={lv} />
    <Sec id="bz-numbers" h={t.sec.numbers}><Lines items={t.numbers} lang={L} /></Sec>
    <Sec id="bz-gaps" h={t.sec.gaps}><Line l={t.gapsIntro} lang={L} /><ul className="bz-gaps">{GAP_IDS.map(g => <li key={g} data-gap={g}><code className="ln-id">{g}</code> <Tx>{t.gaps[g]}</Tx></li>)}</ul>
      <h4><Tx>{t.limitsH}</Tx></h4><Lines items={t.limits} lang={L} /><h4><Tx>{t.deadH}</Tx></h4><Lines items={t.dead} lang={L} /></Sec>
    <Sec id="bz-persp" h={t.sec.persp}><p className="ln-cap"><Tx>{t.perspIntro}</Tx></p>
      {t.persp.map(p => <div key={p.id} className="bz-find" id={'bz-' + p.id.toLowerCase()} data-persp={p.id}><h4><code className="ln-id">{p.id}</code> <Tx>{p.title}</Tx></h4>
        {M ? <Line l={[p.kinds, p.text]} lang={L} /> : <><div className="bz-q"><Line l={[p.qKinds, p.q]} lang={L} /></div><Fold title={t.why} open={false}><Line l={[p.kinds, p.text]} lang={L} /></Fold></>}</div>)}</Sec>
    <Sec id="bz-questions" h={t.sec.questions}><p className="ln-cap"><Tx>{t.questionsIntro}</Tx></p><Lines items={t.questions} lang={L} /></Sec>
    <Sec id="bz-notes" h={t.sec.notes}><Fold title={t.sec.notes} open={M}><p className="ln-cap"><Tx>{t.notesIntro}</Tx></p><Lines items={t.notes} lang={L} /></Fold></Sec>
    <Sec id="bz-honest" h={t.sec.honest}><Lines items={t.honest} lang={L} /></Sec>
    <Sec id="bz-bar" h={t.sec.bar}><HonestyBar lang={L} source="baez" voice="formal" /><p className="ln-cap"><Tx>{t.barNote}</Tx></p>
      {M ? <LensMatrix lang={L} source="baez" /> : <Fold title={t.matrixFold} open={false}><LensMatrix lang={L} source="baez" /></Fold>}</Sec>
    <Sec id="bz-corrections" h={t.sec.corrections}><p className="ln-cap"><Tx>{t.corrIntro}</Tx></p>
      {t.corrections.map((c, i) => <div key={i} className="bz-corr" data-corr={c.id}><p><code className="ln-id">{c.label || c.id}</code> <Tx>{c.where}</Tx></p>
        <p><span className="ln-k">{t.corrCols.wrong}</span> <del><Tx>{c.wrong}</Tx></del></p><p><span className="ln-k">{t.corrCols.right}</span> <Tx>{c.right}</Tx></p>
        <p className="ln-chk"><span className="ln-k">{t.corrCols.guard}</span> <code className="ln-id">{c.guard}</code></p></div>)}</Sec>
    <Sec id="bz-script" h={t.sec.script}><p><Tx>{t.scriptText}</Tx></p><ScriptBox lang={L} file="selfcheck/reports/baez_check.py" text={BAEZ_CHECK_PY} />
      <p className="ln-cap"><Tx>{t.widgetsScript}</Tx></p><W id="bz-w-script" C={BaezWidgetsScript} {...P} /></Sec>
  </>;
}

function PlainBody({ t, y, L, profile }) {
  const P = { lang: L, profile };
  return <>
    <h2 id="bz-h"><Tx>{y.title}</Tx></h2>
    <div id="bz-top"><p className="lede"><Tx>{y.sentence}</Tx></p><W id="bz-w-family" C={BW1} {...P} /></div>
    <Menu label={y.menuLbl} items={SECTIONS_YL.map(s => ['bz-' + s, y.menu[s]])} />
    <Sec id="bz-generation" h={y.sec.generation}><Lines items={y.generation} lang={L} /></Sec>
    <Sec id="bz-papers" h={y.sec.papers}><span id="bz-which" aria-hidden="true" /><W id="bz-w-papers" C={BW5} {...P} /><Lines items={y.papers} lang={L} /></Sec>
    <Sec id="bz-kepler" h={y.sec.kepler}><W id="bz-w-kepler" C={BW4} {...P} /><Lines items={y.kepler} lang={L} /><p className="bz-words"><Tx>{y.keplerWord}</Tx></p></Sec>
    <Sec id="bz-ring" h={y.sec.ring}><W id="bz-w-ring" C={BW6} {...P} /><Lines items={y.ring} lang={L} /></Sec>
    <Sec id="bz-periodic" h={y.sec.periodic}><W id="bz-w-madelung" C={BW7} {...P} /><Lines items={y.periodic} lang={L} /></Sec>
    <Sec id="bz-numbers" h={y.sec.numbers}><Lines items={y.numbers} lang={L} /></Sec>
    <Sec id="bz-gaps" h={y.sec.gaps}><Line l={y.gapsIntro} lang={L} /><ul className="bz-gaps">{y.gaps.map((g, i) => <li key={i} data-gap={GAP_IDS[i]}><Tx>{g}</Tx></li>)}</ul></Sec>
    <div className="bz-sec" id="bz-older"><p><Tx>{y.older}</Tx></p><Fold title={(FOLD[L] || FOLD.en).older} open={false}><FindingsBody t={t} L={L} profile={profile} lv={0} yl /></Fold></div>
    <Sec id="bz-honest" h={y.sec.honest}><Lines items={y.honest} lang={L} /><Line l={y.corr} lang={L} /></Sec>
    <Sec id="bz-bar" h={y.sec.bar}><HonestyBar lang={L} source="baez" voice="yl" /></Sec>
    <Sec id="bz-script" h={y.sec.script}><p><Tx>{y.scriptText}</Tx></p><Fold title={(FOLD[L] || FOLD.en).older} open={false}><ScriptBox lang={L} file="selfcheck/reports/baez_check.py" text={BAEZ_CHECK_PY} />
      <p className="ln-cap"><Tx>{y.widgetsScript}</Tx></p><W id="bz-w-script" C={BaezWidgetsScript} {...P} /></Fold></Sec>
  </>;
}

export default function BaezSection({ lang = 'en', profile = 'Young Learner' }) {
  const L = lang === 'it' ? 'it' : 'en', lv = level(profile), t = COPY[L], y = COPY.yl[L];
  return <section className="ln" id="ln-baez" data-level={lv} aria-labelledby="bz-h"><style>{KIT_STYLE + STYLE}</style>
    <p className="eyebrow"><Tx>{stepEyebrow(L, 'lens', 'baez')}</Tx></p>
    {lv === 0 ? <PlainBody t={t} y={y} L={L} profile={profile} /> : <FormalBody t={t} L={L} profile={profile} lv={lv} />}</section>;
}
