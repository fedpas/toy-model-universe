# Update v10.1 (since v10): "Note to the researcher" pop-up

A small add-on, as agreed: it touches v10 in **one place** (`App.jsx`: one import and one line) and adds three files and two tests. Everything else in v10 is unchanged. It is applied over v10 the same way (`BUILDING.md`).

## What it is

An address like `<atlas>/?for=furey` opens a pop-up, **"A note for Cohl Furey"**, over whatever page the address names (`…/?for=furey#labels/gauge` shows the Gauge tab under the note). The note is the "how to read the atlas from your own research" page for one researcher or group:

- who we are and, in one line, **what this is not** (a set of checks and readings, not a theory of nature);
- **three things to look at first**, in the researcher's own words, each with its status tag (checked / standard / ours / open) and a link to the page and tab;
- a **reading path** of three or four stops through the atlas, each with a link;
- **Standard, ours, open**: what is textbook, what is our reading of it, what is not settled;
- **Where your eyes would help most** (the places we are least sure) and **What we have not read**;
- a button **Write to the authors** (the atlas's own contact form) and a button to close and go on to the atlas.

Eight groups have a note: Furey; Dorst and De Keninck; Roelfs and Eelbode; A. Lasenby, Hsu, Barker and Hobson (Doran and Gull in copy); Vollick; Gunn; Hestenes; Ablamowicz (whose paper the atlas does not cite yet, and the note says so). Five more (J. Lasenby, Mann, Dechant, Todd, Holmer) are named by the atlas only as "to read next": they have no note, and `?for=` for them (or for an unknown name) opens nothing. Aliases work: `?for=eelbode`, `?for=dekeninck`, and so on (`ALIASES` in `researcherNotes.js`).

A link in the note is an ordinary hash link: it closes the note, removes `?for=` from the address and opens the page and tab. Escape, the × and a click outside close it and leave the reader where they were. The focus moves into the note, Tab stays inside it, it scrolls on a phone and never makes the page wider.

**Without `?for=` nothing changes**: no element is added, no request is made; the hash routes work as before (the query string is used on purpose, because an unknown hash page is corrected to `#rule`).

## Files

Added: `researcherNotes.js` (the data: names, the three points, the notes; **no e-mail address**, test_license.mjs forbids any in the package), `ResearcherNote.jsx` (the pop-up), `test_notes.mjs`, `test_notes_ui.mjs`, this file.
Changed: `App.jsx`, two lines: `import ResearcherNote from './ResearcherNote';` and `<ResearcherNote lang={lang} onContact={()=>setContactOpen(true)}/>` (after the ContactForm line).

The same `researcherNotes.js` is the source of the standalone e-mail file that is kept outside the package (so the letter, the note and the atlas cannot disagree). The addresses stay in that private folder.

## Tests

`test_notes.mjs` (187 checks, data group): the structure (13 groups: 8 with a note, 5 on hold; slugs and aliases; three points of 60–330 characters; subjects), every `go` is a page and tab that exists (read from `StoryShell.jsx`), tags, sections, language (no claim of proof, confirmation or prediction except as a denial; no raw markup; no e-mail address), **the atlas names every person written to** (their surname is found in the atlas's own sources; Ablamowicz must *not* be, and the note says so), and **every number the notes quote is pinned** to the atlas's own sources (5 582 blocks, ranks (2,6,4,2,1,1), 616 of 18 480, 27/9/5 of 41 rows, 110 claims in 56 rows, 22/2/6 of 30 rows, 64 checks, 1/30, 759 octads, 244 823 040, 196 560, Weyl 20 = 10 + 10, 61.35°, index 8/64/960). Mutated twice (a quoted number, a `go`): both caught.

`test_notes_ui.mjs` (93 checks, browser group): no overlay without `?for=`, for an unknown name, or for a group on hold; the note over a deep link (title, focus, sections, the page and tab under it kept); a link closes it and opens the tab; Escape, ×, backdrop and the close button; an alias; Tab and Shift+Tab trapped; "Write to the authors" opens the contact form (served over http with the puzzle route stubbed, since a browser does not allow fetch on file://); every note at 1100 and 375 px with no overflow, no console error and links that lead to real tabs.

Result of the final full run (`sh run_tests.sh`, 5 October 2026, after the last edit): **65 passed, 0 failed, 1 skipped** (v10 had 63: the two new tests; `test_real_renderers_ui` skips itself where react-katex, streamdown and @streamdown/math are not installed, as before). One test failed on the way, `test_proofs`, which checks that every script an app source names exists in the package: a comment in `researcherNotes.js` named the private builder; the comment was reworded, not the test.

## Honest limits

- The notes are **English only** (the pop-up says so in the Italian atlas). They are written for the researchers, in their language, and would need review by a native speaker to be translated.
- The pop-up and its data are plain text, written once and not tested with a reader; the researchers' own wording is ours, not theirs.
- The notes claim nothing about nature and say so in the second line; every item carries the same status tag as in the atlas.
- Nothing tests that the atlas, once deployed, is at the address put in a letter: the letters carry whatever address is typed into the e-mail page.
