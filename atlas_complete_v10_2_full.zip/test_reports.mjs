// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The three research reports ship whole in reports/ and agree with themselves. (a) Data: MANIFEST.json lists every file of reports/ with its sha256 and size; each
// work-in-progress zip unpacks (python zipfile) to exactly the folder it mirrors; no e-mail address or mail link in any file or zip member; every report folder has its
// check scripts (byte-identical to selfcheck/reports/), builder, test suite, sabotage script and README; the three pages open as files, carry their headings, the
// corrected sentences of 6 October 2026 and none of the retired ones (outside their "Corrections" section), and every erratum id they cite is defined; the matrix json,
// translationMatrixData.js and the check-id table of selfcheck/reports/README.md are what their generators give. (b) Runs: the three report suites (the category one
// without its browser part), and the five check scripts, whose ok lines must equal the recorded logs. About a minute. reports/run_report_tests.sh runs everything,
// the browser part and the sabotage scripts included.  Needs python3 with numpy, scipy and networkx: exit 77 (skipped) without them.   Run: node test_reports.mjs
import fs from 'node:fs'; import path from 'node:path'; import crypto from 'node:crypto'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
process.chdir(PKG);
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(f, 'utf8'), sha = b => crypto.createHash('sha256').update(b).digest('hex');
const py = (args, opts = {}) => spawnSync('python3', args, { encoding: 'utf8', maxBuffer: 64 << 20, ...opts });
const pv = py(['-c', 'import numpy, scipy, networkx']);
if (pv.error || pv.status !== 0) { console.log('SKIP: test_reports needs python3 with numpy, scipy and networkx (the report scripts import them): ' + (pv.error ? 'no python3' : (pv.stderr || '').trim().split('\n').pop())); process.exit(77); }

const R = 'reports', FOLDERS = { category: 'category_atlas_wip.zip', baez: 'baez_wip.zip', schuller: 'schuller_bridge_wip.zip' };
const SKIP_DIRS = new Set(['__pycache__', 'txt', '.git']), SKIP_FILE = /(\.pyc|~|\.swp|\.DS_Store)$/;
const walk = d => fs.readdirSync(d, { withFileTypes: true }).filter(e => !(e.isDirectory() && SKIP_DIRS.has(e.name))).flatMap(e => e.isDirectory() ? walk(path.join(d, e.name)) : SKIP_FILE.test(e.name) ? [] : [path.join(d, e.name)]);
const rel = f => path.relative(R, f).split(path.sep).join('/');
const ALL = walk(R).map(rel).sort();

// ---- (a1) the manifest: exactly the files of reports/, with their hashes and sizes
const M = JSON.parse(rd(path.join(R, 'MANIFEST.json')));
const listed = Object.keys(M.files).sort(), present = ALL.filter(f => f !== 'MANIFEST.json');
ok(JSON.stringify(listed) === JSON.stringify(present), 'MANIFEST.json lists exactly the files of reports/: ' + [...present.filter(f => !listed.includes(f)), ...listed.filter(f => !present.includes(f)).map(f => '-' + f)].join(', '));
const wrongHash = listed.filter(f => { const b = fs.existsSync(path.join(R, f)) ? fs.readFileSync(path.join(R, f)) : null; return !b || sha(b) !== M.files[f].sha256 || b.length !== M.files[f].bytes; });
ok(wrongHash.length === 0 && present.length > 40, 'every file has the sha256 and size the manifest gives (' + present.length + ' files): ' + wrongHash.join(', '));
ok(M.total_bytes === present.reduce((s, f) => s + fs.statSync(path.join(R, f)).size, 0) && M.total_bytes < 4e6, 'the manifest total is the sum of the sizes, and reports/ stays small (' + M.total_bytes + ' bytes)');

// ---- (a2) each zip unpacks (python zipfile) to exactly its folder; no address inside any member
const EMAIL = '[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*\\.[A-Za-z]{2,}';
const ZPY = `import sys, zipfile, hashlib, json, re
E = re.compile(sys.argv[1]); out = {}
for z in sys.argv[2:]:
    with zipfile.ZipFile(z) as f:
        ms = {}
        for i in f.infolist():
            if i.is_dir(): continue
            b = f.read(i.filename); t = b.decode('utf-8', 'replace')
            ms[i.filename] = [hashlib.sha256(b).hexdigest(), bool(E.search(t)) or ('mail' + 'to:') in t.lower()]
        out[z] = ms
print(json.dumps(out))`;
const zr = py(['-I', '-c', ZPY, EMAIL, ...Object.values(FOLDERS).map(z => path.join(R, 'zips', z))]);
const Z = zr.status === 0 ? JSON.parse(zr.stdout) : {};
ok(zr.status === 0, 'python zipfile reads the three zips: ' + (zr.stderr || '').trim().split('\n').pop());
for (const [folder, zip] of Object.entries(FOLDERS)) {
  const members = Z[path.join(R, 'zips', zip)] || {}, files = ALL.filter(f => f.startsWith(folder + '/'));
  const same = JSON.stringify(Object.keys(members).sort()) === JSON.stringify(files) && files.every(f => members[f][0] === sha(fs.readFileSync(path.join(R, f))));
  ok(same && files.length >= 10, `zips/${zip} unpacks to exactly reports/${folder}/ (${files.length} files, byte for byte): ` + [...files.filter(f => !(f in members)), ...Object.keys(members).filter(m => !files.includes(m)).map(m => '+' + m)].join(', '));
  ok(Object.values(members).every(([, mail]) => !mail), `no e-mail address and no mail link in any member of zips/${zip}: ` + Object.entries(members).filter(([, v]) => v[1]).map(([k]) => k).join(', '));
}
const RESERVED = /@([A-Za-z0-9-]+\.)*(example\.(com|org|net)|[A-Za-z0-9-]+\.invalid|example|invalid|test|localhost)$/i;
const mails = ALL.filter(f => /\.(py|sh|js|mjs|md|json|html|css|log|txt)$/.test(f)).flatMap(f => { const t = rd(path.join(R, f)).replace(/<!--[\s\S]*?-->/g, ''); return [...t.matchAll(new RegExp(EMAIL, 'g'))].filter(m => !RESERVED.test(m[0].slice(m[0].indexOf('@')))).map(m => f + ': ' + m[0]).concat(t.toLowerCase().includes('mail' + 'to:') ? [f + ': mail link'] : []); });
ok(mails.length === 0, 'no e-mail address and no mail link in any file of reports/: ' + mails.slice(0, 5).join(' | '));

// ---- (a3) the folders: what each one must hold; the check scripts are the ones of selfcheck/reports/
const NEED = { category: ['cat_check.py', 'mutate_cat.py', 'build_report_cat.py', 'test_report_cat.py', 'content_cat.py', 'figs_cat.py', 'matrix_cat.py', 'README_cat.md', 'cat_results.json', 'logs/cat_check.log', 'logs/mutation_cat.log'],
  baez: ['baez_check.py', 'mutate_baez.py', 'build_report_baez.py', 'test_report_baez.py', 'figs_baez.py', 'matrix_baez.py', 'README_baez.md', 'logs/baez_check.log', 'logs/baez_figdata.json', 'logs/mutate_baez.log'],
  schuller: ['bridge_check.py', 'bridge_check_qm.py', 'fibre_check.py', 'mutate_fibre.py', 'build_report.py', 'fibre_section.py', 'matrix_data.py', 'test_report.py', 'README_schuller.md', 'CORRECTION_F12.md', 'logs/bridge_check_final.log', 'logs/bridge_check_qm_final.log', 'logs/fibre_check_final.log', 'logs/mutation_fibre.log'] };
for (const [folder, need] of Object.entries(NEED)) ok(need.every(f => ALL.includes(folder + '/' + f)), `reports/${folder}/ has its check scripts, builder, suite, sabotage script, logs and README: missing ` + need.filter(f => !ALL.includes(folder + '/' + f)).join(', '));
const COPIES = [['category', 'cat_check.py'], ['baez', 'baez_check.py'], ['schuller', 'fibre_check.py'], ['schuller', 'bridge_check.py'], ['schuller', 'bridge_check_qm.py']];
ok(COPIES.every(([d, s]) => sha(fs.readFileSync(path.join(R, d, s))) === sha(fs.readFileSync(path.join('selfcheck', 'reports', s)))), 'the five check scripts in reports/ are byte-identical to selfcheck/reports/ (one script, two places): ' + COPIES.filter(([d, s]) => sha(fs.readFileSync(path.join(R, d, s))) !== sha(fs.readFileSync(path.join('selfcheck', 'reports', s)))).map(x => x.join('/')).join(', '));
const PRIVATE = ['baez_letter', 'build_letter', 'researcher_emails', 'outreach', 'shots.py'];
ok(ALL.every(f => !PRIVATE.some(p => f.includes(p))), 'nothing private or scratch is shipped (the letter, its builder, outreach files, the screenshot helper): ' + ALL.filter(f => PRIVATE.some(p => f.includes(p))).join(', '));
const SPDX = ['SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors', 'Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)'];
const unheaded = ALL.filter(f => /\.(py|sh|js|mjs)$/.test(f) && !SPDX.every(l => rd(path.join(R, f)).split('\n').slice(0, 6).join('\n').includes(l)));
ok(unheaded.length === 0, 'every script in reports/ carries the three-line SPDX header: ' + unheaded.join(', '));
const readme = rd(path.join(R, 'README.md'));
ok(['html/', 'zips/', 'MANIFEST.json', 'make_package.py', 'make_matrix_json.py', 'make_check_table.py', 'run_report_tests.sh', 'errata_changelog_6oct.md', 'errata_changelog_6oct_addendum.md', 'translation_matrix.json', ...Object.values(FOLDERS)].every(x => readme.includes(x)), 'reports/README.md names the pages, the zips, the generators, the runner, the errata and the matrix');

// ---- (a4) the three pages: headings, the corrections of 6 October 2026 (second round), the retired wording gone, the cited errata defined
const PAGES = {
  'category_atlas_report.html': { h1: 'What is label 0, seen through categories?', ids: [39, 48],
    right: ['an additive integer degree', 'the trace of the Born rule is a symmetric Frobenius form', 'det = 9 − n is 0 only at n = 9', 'Clifford periodicity does not cause the stop', 'the count behind the ten of the Tenfold Way (Wall, recalled)', 'fails from three generators on, and only there', 'the complement of the face of labels with none', 'the top-blade form is symmetric iff n is odd', 'the Tits form there is (6,1,1)', 'three maps and a duality'],
    retired: ['conserved integer degree', 'conserved charge', 'the Born rule is the Frobenius form', 'is the boundary between the definite and the Lorentzian', 'the reason for the ten', 'our reading only', 'Ladders as functors', 'three functors and a duality', 'the same pattern as the category itself', 'it is symmetric only for odd n or without null generators'] },
  'baez_atlas_report.html': { h1: 'Seven Baez papers and the atlas', ids: [49, 54],
    right: ['calling that flip charge conjugation is ours', 'the standard anomaly cancellation, recomputed over the labels', 'the nested triples contain (3,2), then (3̄,1) + (1,1), then one generation, then 11 more states', 'a real representation is vector-like (standard)', 'a metric Hodge star only without null generators', 'coefficient of the empty label, the unit'],
    retired: ['particle to antiparticle', 'the antiparticle side', 'the labels explain', 'computed by us', 'build a generation', 'no chiral generation inside', 'Hodge complement', 'coefficient of label 0'] },
  'schuller_bridge_report.html': { h1: 'Schuller and the atlas: a translation matrix', ids: [55, 68],
    right: ['product states are the null cone of det on M₂(ℝ)', 'over ℂ the condition is det = 0 on M₂(ℂ)', 'A momentum along an extra space-like direction enters as a mass', 'S, E, E, S, S, S, A', 'one Lorentzian class in two conventions, P ↔ −P', 'Cl(2,2) is the first ultrahyperbolic cell', 'M = ±I has X = 0 and bounded powers', 'the textbook elliptic/parabolic/hyperbolic split of SL(2,ℝ)', 'isomorphic as an algebra to the End(V)', 'with the indices raised', 'is now a theorem: a doubly-even self-dual code of length n'],
    retired: ['quadric of entangled', 'Mass is a fibre momentum', 'hyperbolicity says the fibre is space-like', 'E, S, E, S, S, S, A', 'exactly two ladders', 'first excluded', 'fifth home', 'is Furey’s End(V)', 'edge: X² = 0, parabolic', 'Casimir of the spin representation = C(n,2)/4', 'not a theorem I have proved in general'] } };
const unent = s => s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#x27;|&#39;/g, "'").replace(/&amp;/g, '&');
const plainOf = h => unent(h.replace(/<style[\s\S]*?<\/style>|<script[\s\S]*?<\/script>/g, '').replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ');
const tipsOf = h => [...h.matchAll(/data-tip="([^"]*)"/g)].map(m => unent(m[1])).join(' ');
const defined = new Set([...(fs.existsSync('ERRATA_NEW.md') ? rd('ERRATA_NEW.md') : '').matchAll(/id: '(E-\d{3})'/g), ...rd('researchersData.js').matchAll(/id: '(E-\d{3})'/g)].map(m => m[1]));
for (const [file, P] of Object.entries(PAGES)) {
  const f = path.join(R, 'html', file), h = fs.existsSync(f) ? rd(f) : '';
  ok(/^<!doctype html>/i.test(h.trimStart()) && h.includes('</html>') && h.includes(`<h1>${P.h1}</h1>`), `${file} opens as a self-contained file with its heading “${P.h1}”`);
  ok(!/(src|href)="https?:\/\/(?!arxiv\.org)/.test(h) && !/<script[^>]+src=|<link[^>]+href|@import|url\(http/.test(h), `${file}: no external request (links to arxiv.org only)`);
  const corr = (h.match(/<section id="corr">[\s\S]*?<\/section>/) || [''])[0], outside = h.replace(/<section id="corr">[\s\S]*?<\/section>/, '');
  const all = plainOf(h) + ' ' + tipsOf(h), out = plainOf(outside) + ' ' + tipsOf(outside);
  ok(P.right.every(s => all.includes(s)), `${file}: the corrected sentences are on the page: missing ` + P.right.filter(s => !all.includes(s)).join(' | '));
  ok(P.retired.every(s => !out.includes(s)), `${file}: none of the retired sentences is left outside the corrections section: ` + P.retired.filter(s => out.includes(s)).join(' | '));
  const want = Array.from({ length: P.ids[1] - P.ids[0] + 1 }, (_, i) => 'E-0' + (P.ids[0] + i)), cited = [...new Set([...corr.matchAll(/E-\d{3}/g)].map(m => m[0]))];
  ok(want.every(e => cited.includes(e)) && cited.every(e => defined.has(e)), `${file}: its corrections section lists ${want[0]}..${want.at(-1)} and every erratum id it cites is defined (ERRATA_NEW.md or researchersData.js): ` + [...want.filter(e => !cited.includes(e)), ...cited.filter(e => !defined.has(e)).map(e => 'undefined ' + e)].join(', '));
}

// ---- (a5) generated files are what their generators give
const gm = py([path.join(R, 'make_matrix_json.py'), '--check']);
ok(gm.status === 0, 'reports/translation_matrix.json is what make_matrix_json.py builds from the three matrix modules: ' + gm.stdout.trim());
const gd = spawnSync(process.execPath, ['make_matrix_data.mjs', path.join(R, 'translation_matrix.json'), '--check'], { encoding: 'utf8' });
ok(gd.status === 0, 'translationMatrixData.js is what make_matrix_data.mjs builds from reports/translation_matrix.json: ' + (gd.stdout + gd.stderr).trim());
const J = JSON.parse(rd(path.join(R, 'translation_matrix.json'))), best = rows => rows.reduce((c, r) => { const g = Object.values(r.cells).map(x => x.grade); c[g.includes('E') ? 0 : g.includes('S') ? 1 : g.includes('A') ? 2 : 3]++; return c; }, [0, 0, 0, 0]).join('/');
ok(['schuller', 'baez', 'category'].map(k => k + ' ' + J.matrices[k].rows.length + ' ' + best(J.matrices[k].rows)).join(', ') === 'schuller 43 23/14/2/4, baez 48 26/11/2/9, category 40 27/6/2/5' && J.columns.length === 22,
   'the matrix: 22 columns; rows and best grades Schuller 43 (23/14/2/4), Baez 48 (26/11/2/9), category 40 (27/6/2/5; W5 is standard since E-042)');
const gt = py([path.join(R, 'make_check_table.py'), '--check']);
ok(gt.status === 0, 'the check-id table of selfcheck/reports/README.md is what make_check_table.py gives from the logs: ' + gt.stdout.trim());
const gp = py([path.join(R, 'make_package.py'), '--check']);
ok(gp.status === 0, 'the zips and MANIFEST.json are what make_package.py builds from the folders: ' + gp.stdout.trim());

// ---- (b) the runs: the three report suites (no browser) and the five check scripts against their logs
const env = { ...process.env, ATLAS_PKG: PKG, REPORT_NO_BROWSER: '1' };
for (const [folder, suite, min] of [['category', 'test_report_cat.py', 62], ['baez', 'test_report_baez.py', 37], ['schuller', 'test_report.py', 25]]) {
  const r = py([suite], { cwd: path.join(R, folder), env }), last = (r.stdout || '').trim().split('\n').pop() || '', n = +((last.match(/(\d+) ok/) || [])[1] || 0);
  ok(r.status === 0 && /, 0 failed/.test(last) && n >= min, `reports/${folder}/${suite} passes (${last}): ` + (r.stdout || '').split('\n').filter(l => /^FAIL/.test(l)).slice(0, 3).join(' | ') + (r.stderr || '').trim().split('\n').pop());
}
const okLines = t => t.split('\n').filter(l => /^(ok  |FAIL) /.test(l) && !/^ok   R1:/.test(l));
for (const [script, log] of [['cat_check.py', 'category/logs/cat_check.log'], ['baez_check.py', 'baez/logs/baez_check.log'], ['fibre_check.py', 'schuller/logs/fibre_check_final.log'], ['bridge_check.py', 'schuller/logs/bridge_check_final.log'], ['bridge_check_qm.py', 'schuller/logs/bridge_check_qm_final.log']]) {
  const r = py([script], { cwd: path.join('selfcheck', 'reports'), env }), fresh = okLines(r.stdout || ''), rec = okLines(rd(path.join(R, log)));
  ok(r.status === 0 && fresh.length > 20 && JSON.stringify(fresh) === JSON.stringify(rec) && fresh.every(l => l.startsWith('ok')), `selfcheck/reports/${script} passes and prints exactly the ok lines of reports/${log} (${fresh.length} lines${/^skip R1/m.test(r.stdout) ? '; R1 skipped, no texts' : ''})`);
}
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL REPORT TESTS PASS'); process.exit(bad ? 1 : 0);
