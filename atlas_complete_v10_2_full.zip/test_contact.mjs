// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The contact form's data and route, run against a mocked form service (no network, no secret, no real address). Checks: the puzzle kinds (one whole-number answer each, EN and IT
// text built from the same numbers, solved here by an independent solver), the signed token, the guard helpers, every step of POST /api/contact in the order it runs, the rate limits,
// the forwarded JSON, the failure paths, and that no secret, endpoint, address or message reaches a response or a log line. test_contact_mutation.mjs breaks the guard on purpose and
// runs this file against each broken copy; the file only uses relative paths, so it can run from a copy.
import fs from 'fs';
import { fileURLToPath } from 'url'; process.chdir(fileURLToPath(new URL('.', import.meta.url)));   // relative paths below: run from any folder (re-test T6-8); a copy (test_contact_mutation) has no paths.mjs
import * as G from './lib/contactGuard.js';
import { CONTACT, CONTACT_LIMITS } from './contactCopy.js';
const out = console.log.bind(console);
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; out('FAIL', m); } };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);

// ---- the world: a fake clock, a fake form service, a log recorder, a recorder of every response
const SECRET = 'test-secret-ABCDEF-0123456789', OTHER = 'another-secret-ZYXWVU-9876543210', OWNER = 'owner.canary@example.invalid';
const ENDPOINT = `https://forms.example.test/f/${OWNER}`;
process.env.FORMSPREE_ENDPOINT = ENDPOINT; process.env.CONTACT_SECRET = SECRET;
for (const k of ['CONTACT_RATE_PER_HOUR', 'CONTACT_GLOBAL_PER_HOUR', 'CONTACT_ALLOWED_ORIGINS', 'CHAT_ALLOWED_ORIGINS']) delete process.env[k];
let T = 1_800_000_000_250; Date.now = () => T;
const logs = []; const show = x => (x instanceof Error ? `${x.name}: ${x.message}` : typeof x === 'string' ? x : (() => { try { return JSON.stringify(x); } catch { return String(x); } })());
for (const k of ['log', 'info', 'warn', 'error', 'debug']) console[k] = (...a) => logs.push(a.map(show).join(' '));
const realTimeout = AbortSignal.timeout.bind(AbortSignal); let timeoutArgs = [], timeoutOverride = null; AbortSignal.timeout = ms => { timeoutArgs.push(ms); return realTimeout(timeoutOverride ?? ms); };
let calls = [], mode = 'ok';
globalThis.fetch = async (url, init) => {
  calls.push({ url: String(url), init, raw: init.body, body: JSON.parse(init.body) });
  if (mode === 'throw') throw Object.assign(new Error('network down ' + SECRET + ' ' + ENDPOINT), { name: 'TypeError' });
  if (mode === '500') return new Response('upstream detail with ' + SECRET + ' and ' + OWNER, { status: 500 });
  if (mode === '429') return new Response('slow down', { status: 429 });
  if (mode === 'hang') return new Promise((_, rej) => init.signal.addEventListener('abort', () => rej(init.signal.reason)));
  return new Response('{"ok":true}', { status: 200, headers: { 'content-type': 'application/json' } });
};
const URLC = 'https://atlas.example/api/contact';
let ipn = 0; const nextIp = () => `203.0.113.${(++ipn % 250) + 1}.${Math.floor(ipn / 250)}`;
const getReq = (lang, headers = {}) => new Request(URLC + (lang ? '?lang=' + lang : ''), { headers });
const postReq = ({ body, raw, headers = {}, method = 'POST' }) => new Request(URLC, { method, headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-real-ip': nextIp(), ...headers }, body: method === 'GET' ? undefined : (raw ?? JSON.stringify(body)) });
const seen = []; let inst = 0;
const freshRoute = async () => (await import('./api/contact.js?instance=' + (++inst))).default;     // a new import has its own counters and its own table of used tokens
async function send(h, req) {
  const r = await h(req), text = await r.text(); let json = null; try { json = JSON.parse(text); } catch { /* not JSON */ }
  const res = { status: r.status, headers: r.headers, text, json }; seen.push({ status: r.status, headers: JSON.stringify(Object.fromEntries(r.headers)), text }); return res;
}

// ---- an independent solver: reads the question text (either language) and finds the answer without using the generator's formula
const nums = s => [...s.matchAll(/\d+/g)].map(m => Number(m[0]));
const xorBits = (a, b) => { let r = 0; for (let i = 0; i < 8; i++) r += (((a >> i) & 1) + ((b >> i) & 1)) % 2 << i; return r; };      // add in binary, column by column, no carry
const subsets = (n, k) => { let c = 0; for (let m = 0; m < 1 << n; m++) { let ones = 0; for (let i = 0; i < n; i++) ones += (m >> i) & 1; if (ones === k) c++; } return c; };
const kindOfText = q => /switch rule|regola degli interruttori/.test(q) ? (/XOR w =/.test(q) ? 'plain-xor-missing' : 'plain-xor') : /boxes|scatole/.test(q) ? 'plain-doubles' : /pairs|coppie/.test(q) ? 'plain-pairs' : /grade|grado/.test(q) ? 'grade-count' : /starts with|parte con/.test(q) ? 'generators-added' : /numbered|numerati/.test(q) ? 'basis-doubles' : /Multiply|Moltiplica/.test(q) ? 'xor-three' : /What is x|vale x/.test(q) ? 'xor-missing' : 'xor-product';
function solve(q) {
  const v = nums(q);
  switch (kindOfText(q)) {
    case 'plain-xor': return xorBits(v[0], v[1]);
    case 'plain-xor-missing': { const xs = []; for (let x = 0; x < 64; x++) if (xorBits(v[0], x) === v[1]) xs.push(x); return xs.length === 1 ? xs[0] : NaN; }
    case 'plain-doubles': return v[1] === 2 ** v[0] && v[2] === v[0] + 1 ? 2 * v[1] : NaN;
    case 'plain-pairs': return subsets(v[0], 2);
    case 'grade-count': return subsets(v[0], v[1]);
    case 'generators-added': return v[0] + v[1];
    case 'basis-doubles': return v[1] === 2 ** v[0] && v[3] === v[1] - 1 ? 2 * v[1] : NaN;
    case 'xor-three': return xorBits(xorBits(v[0], v[1]), v[2]);
    case 'xor-missing': { const xs = []; for (let x = 0; x < 64; x++) if (xorBits(v[0], x) === v[1]) xs.push(x); return xs.length === 1 ? xs[0] : NaN; }
    default: return xorBits(v[0], v[1]);
  }
}
const lcg = seed => () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

// ---- the puzzle kinds
{
  const kinds = G.PUZZLE_KINDS.map(k => k.id); ok(kinds.length >= 5 && new Set(kinds).size === kinds.length, 'at least five puzzle kinds, each with its own id: ' + kinds);
  const count = {}, rng = lcg(7);
  for (let i = 0; i < 3000; i++) {
    const p = G.makePuzzle(rng), en = p.question.en, it = p.question.it; count[p.kind] = (count[p.kind] || 0) + 1;
    const good = typeof en === 'string' && typeof it === 'string' && en.length > 30 && it.length > 30 && en !== it && !/undefined|NaN|\[object/.test(en + it)
      && Number.isInteger(p.answer) && p.answer >= 1 && p.answer <= 64 && same(nums(en), nums(it)) && kindOfText(en) === p.kind && kindOfText(it) === p.kind && solve(en) === p.answer && solve(it) === p.answer;
    if (!good) { ok(false, `puzzle ${i} (${p.kind}) is not sound: ${en} / ${it} / answer ${p.answer} / solver ${solve(en)} ${solve(it)}`); break; }
    if (/^xor/.test(p.kind) && new Set(p.kind === 'xor-three' ? [] : nums(en)).size !== (p.kind === 'xor-three' ? 0 : 2)) { ok(false, 'the two numbers of ' + p.kind + ' are equal: ' + en); break; }
    const lastSentence = en.split(/(?<=[.?]) /).pop(), lastIt = it.split(/(?<=[.?]) /).pop();
    if (!/\?$/.test(lastSentence) || /\bsign\b|\bsegno\b/i.test(lastSentence + lastIt) || /\bsign\b|\bsegno\b/i.test(en.replace(/the order only changes the sign/, '') + it.replace(/l’ordine cambia solo il segno/, ''))) { ok(false, 'a puzzle asks about, or leans on, a sign: ' + en); break; }
  }
  ok(kinds.every(k => count[k] > 300), 'every puzzle kind is drawn, each about 1/6 of the time: ' + JSON.stringify(count));
  for (const k of G.PUZZLE_KINDS) for (const r of [() => 0, () => 1 - Number.EPSILON, () => 0.5]) {
    const p = k.build(r), en = p.en;
    ok(Number.isInteger(p.answer) && p.answer >= 1 && p.answer <= 64 && solve(en) === p.answer && solve(p.it) === p.answer && kindOfText(en) === k.id, `${k.id}: extreme or constant random numbers give a sound puzzle (${en})`);
  }
  { const p = G.makePuzzle(); ok(typeof p.answer === 'number' && p.question.en && p.question.it, 'makePuzzle() works with the default random source'); }
  { const seen2 = new Set(); for (let i = 0; i < 400; i++) seen2.add(G.makePuzzle(lcg(i + 1)).question.en); ok(seen2.size > 60, 'different seeds give many different questions: ' + seen2.size); }
  // the XOR kinds really are about the bit rule, and "which index completes the product" has exactly one answer
  for (let a = 1; a <= 15; a++) for (let c = 1; c <= 15; c++) if (a !== c) { const xs = []; for (let x = 0; x < 64; x++) if (xorBits(a, x) === c) xs.push(x); if (xs.length !== 1 || xs[0] !== (a ^ c)) { ok(false, `missing index of ${a}, ${c}: ${xs}`); a = c = 99; } }
  ok(subsets(5, 2) === 10 && subsets(6, 3) === 20 && subsets(4, 3) === 4, 'the solver itself counts subsets correctly');
  ok(G.HINT.en.includes('XOR') && G.HINT.it.includes('XOR') && G.HINT.en.includes('without carrying') && G.HINT.it.includes('senza riporto'), 'the hint explains XOR as binary addition without carrying (EN and IT)');
}
// ---- re-test T1-8: the Young Learner's puzzles, in plain words (house rule 6: no formulas or technical words; very easy arithmetic such as 5 XOR 3 = 6 is allowed)
const TECH = /e_|·|basis|element|grade|generator|index|binary|algebra|carry|elemento|grado|generator|indice|binario|algebra|riporto|\bsign\b|segno/i;
{
  const kinds = G.PLAIN_KINDS.map(k => k.id); ok(kinds.length >= 3 && kinds.every(k => k.startsWith('plain-')) && !kinds.some(k => G.PUZZLE_KINDS.some(f => f.id === k)), 'plain kinds of their own: ' + kinds);
  const count = {}, rng = lcg(11); let bad1 = null;
  for (let i = 0; i < 2000 && !bad1; i++) {
    const p = G.makePuzzle(rng, 'yl'), en = p.question.en, it = p.question.it; count[p.kind] = (count[p.kind] || 0) + 1;
    if (!kinds.includes(p.kind) || !Number.isInteger(p.answer) || p.answer < 1 || p.answer > 64 || !same(nums(en), nums(it)) || en === it || kindOfText(en) !== p.kind || kindOfText(it) !== p.kind || solve(en) !== p.answer || solve(it) !== p.answer || !/\?$/.test(en) || !/\?$/.test(it) || TECH.test(en) || TECH.test(it) || /undefined|NaN|\[object/.test(en + it)) bad1 = `${p.kind}: ${en} / ${it} / ${p.answer} / solver ${solve(en)}`;
  }
  ok(!bad1, 'every Young Learner puzzle is sound, in plain words, EN and IT with the same numbers, solved independently: ' + bad1);
  ok(kinds.every(k => count[k] > 2000 / kinds.length / 2), 'every plain kind is drawn: ' + JSON.stringify(count));
  for (const k of G.PLAIN_KINDS) for (const r of [() => 0, () => 1 - Number.EPSILON, () => 0.5]) { const p = k.build(r); ok(Number.isInteger(p.answer) && p.answer >= 1 && p.answer <= 64 && solve(p.en) === p.answer && solve(p.it) === p.answer, `${k.id}: extreme or constant random numbers give a sound puzzle (${p.en})`); }
  for (const a of [null, undefined, '', 'YL', 'young', 'yl ', 'physicist', '__proto__', 'constructor', 'toString', 5, {}]) { const p = G.makePuzzle(lcg(3), a); ok(G.PUZZLE_KINDS.some(k => k.id === p.kind) && G.puzzleAudience(a) === null, 'audience ' + JSON.stringify(a) + ' is not on the list: the usual puzzles'); }
  ok(G.puzzleAudience('yl') === 'yl' && G.hintFor('en', 'yl') === G.HINT_PLAIN.en && G.hintFor('it', 'yl') === G.HINT_PLAIN.it && G.hintFor('en') === G.HINT.en && G.hintFor('it', 'x') === G.HINT.it, 'hintFor: the plain hint for yl, the usual one otherwise');
  ok(!TECH.test(G.HINT_PLAIN.en) && !TECH.test(G.HINT_PLAIN.it) && G.HINT_PLAIN.en.includes('5 XOR 3 = 4 + 2 = 6') && G.HINT_PLAIN.it.includes('5 XOR 3 = 4 + 2 = 6') && (5 ^ 3) === 4 + 2, 'the plain hint has no technical words and a right worked example (EN and IT)');
  ok(G.HINT_PLAIN.en === CONTACT.en.hintPlain && G.HINT_PLAIN.it === CONTACT.it.hintPlain, 'the plain hint is the same in the route and on the page');
  ok(TECH.test(G.HINT.en) && G.PUZZLE_KINDS.some(k => TECH.test(k.build(lcg(1)).en)), 'the technical-word detector does see the usual hint and puzzles (it is not blind)');
}

// ---- the token
{
  const t0 = T, tok = await G.issueToken(SECRET, 12, t0);
  ok(/^[A-Za-z0-9_-]{22}\.\d{10}\.[A-Za-z0-9_-]{43}$/.test(tok) && !tok.includes('='), 'token shape: base64url nonce . expiry (seconds) . base64url MAC: ' + tok);
  const exp = Number(tok.split('.')[1]); ok(exp === Math.ceil(t0 / 1000) + 600, 'expiry is the issue time (rounded up to a second) plus 10 minutes');
  const v = await G.verifyToken(SECRET, tok, '12', t0 + 5000); ok(v.ok === true && v.issuedAt >= t0 && v.issuedAt - t0 < 1000 && v.exp === exp && v.nonce === tok.split('.')[0], 'round trip: ok, with the nonce, the expiry and the issue time');
  const toks = new Set(); for (let i = 0; i < 300; i++) toks.add((await G.issueToken(SECRET, 12, t0)).split('.')[0]); ok(toks.size === 300, 'every token has its own nonce');
  const parts = tok.split('.'), flip = c => (c === 'A' ? 'B' : 'A');
  for (const [name, t] of [['nonce', parts[0].slice(0, 3) + flip(parts[0][3]) + parts[0].slice(4) + '.' + parts[1] + '.' + parts[2]], ['nonce, last character', parts[0].slice(0, 21) + flip(parts[0][21]) + '.' + parts[1] + '.' + parts[2]], ['expiry (+1 s)', `${parts[0]}.${exp + 1}.${parts[2]}`], ['expiry (+1 day)', `${parts[0]}.${exp + 86400}.${parts[2]}`], ['MAC', `${parts[0]}.${parts[1]}.${parts[2].slice(0, 10)}${flip(parts[2][10])}${parts[2].slice(11)}`], ['MAC, last char', `${parts[0]}.${parts[1]}.${parts[2].slice(0, 42)}${flip(parts[2][42])}`], ['all upper case', tok.toUpperCase()]]) {
    const r = await G.verifyToken(SECRET, t, '12', t0 + 5000); ok(!r.ok && (r.reason === 'wrong_answer' || r.reason === 'bad_token'), `tampered token (${name}) is refused: ${JSON.stringify(r)}`);
  }
  { const r = await G.verifyToken(OTHER, tok, '12', t0 + 5000); ok(!r.ok && r.reason === 'wrong_answer', 'a token made with another secret is refused'); const r2 = await G.verifyToken(SECRET, await G.issueToken(OTHER, 12, t0), '12', t0 + 5000); ok(!r2.ok, 'and the other way round'); }
  for (const a of ['13', '0', '', ' ', 'twelve', '12a', '1 2', '-12', '12.0', '1e1', '０１２', null, undefined, 13, 12.5, -12, NaN, {}, [], [12]]) { const r = await G.verifyToken(SECRET, tok, a, t0 + 5000); ok(!r.ok && r.reason === 'wrong_answer', `answer ${JSON.stringify(a)} is refused as wrong`); }
  for (const a of ['12', ' 12 ', '012', '0012', 12, '\t12\n']) { const r = await G.verifyToken(SECRET, tok, a, t0 + 5000); ok(r.ok, `answer ${JSON.stringify(a)} is accepted (trimmed, digits only, leading zeros ignored)`); }
  ok(G.normaliseAnswer('  007 ') === '7' && G.normaliseAnswer('0') === '0' && G.normaliseAnswer('1234567') === null && G.normaliseAnswer('+5') === null, 'normaliseAnswer');
  for (const t of ['', 'x', 'a.b.c', `${parts[0]}.${parts[1]}`, `${parts[0]}.${parts[1]}.${parts[2]}.x`, `${parts[0]}.0${parts[1]}.${parts[2]}`, `${parts[0]}..${parts[2]}`, tok + ' ', ' ' + tok, 'A'.repeat(500), null, undefined, 12, {}, [tok]]) {
    const r = await G.verifyToken(SECRET, t, '12', t0 + 5000); ok(!r.ok && r.reason === 'bad_token', `a malformed token (${String(t).slice(0, 25)}) is bad_token`); }
  // expiry: valid up to the last millisecond before issue + 10 minutes
  { const e = exp * 1000; ok((await G.verifyToken(SECRET, tok, '12', e - 1)).ok, 'valid one millisecond before it expires'); const r = await G.verifyToken(SECRET, tok, '12', e); ok(!r.ok && r.reason === 'expired', 'expired at the expiry second'); const r2 = await G.verifyToken(SECRET, tok, '12', e + 3600e3); ok(r2.reason === 'expired', 'expired an hour later');
    const r3 = await G.verifyToken(SECRET, tok, '99', e + 1); ok(r3.reason === 'expired', 'an expired token with a wrong answer says expired (a new puzzle is the cure either way)'); }
  // replay: the nonce store
  { const store = G.makeNonceStore(), now = t0 + 5000; ok((await G.verifyToken(SECRET, tok, '12', now, store)).ok, 'unused token passes with a store');
    ok(store.add(v.nonce, v.exp * 1000, now) === true && store.add(v.nonce, v.exp * 1000, now) === false, 'a nonce can be added once');
    const r = await G.verifyToken(SECRET, tok, '12', now, store); ok(!r.ok && r.reason === 'replayed', 'a used token is replayed: ' + JSON.stringify(r));
    ok((await G.verifyToken(SECRET, tok, '13', now, store)).reason === 'wrong_answer', 'a used token with a wrong answer is still wrong_answer');
    const tok2 = await G.issueToken(SECRET, 5, t0); ok((await G.verifyToken(SECRET, tok2, '5', now, store)).ok, 'another token is not affected');
    const s2 = G.makeNonceStore({ max: 3 }); for (let i = 0; i < 5; i++) s2.add('n' + i, now + 1e6, now); ok(s2.size() <= 3 && s2.has('n4', now) && !s2.has('n0', now), 'the store is bounded; the oldest are forgotten first: ' + s2.size());
    const s3 = G.makeNonceStore({ max: 2 }); s3.add('old', now - 1, now - 10); s3.add('live', now + 1e6, now); s3.add('new', now + 1e6, now); ok(s3.has('live', now) && s3.has('new', now) && !s3.has('old', now), 'expired nonces are dropped before live ones');
    ok(!s3.has('live', now + 2e6), 'a nonce is only "used" until it expires'); }
  // minimum fill time
  ok(G.MIN_FILL_MS === 4000 && G.tooFast(1000, 1000 + 3999) === true && G.tooFast(1000, 1000 + 4000) === false && G.tooFast(1000, 1000, 4000) === true, 'tooFast: refuses under 4 s, accepts from 4 s');
  ok(G.TOKEN_LIFETIME_S === 600 && G.MAX_BODY === 16384, 'lifetime 10 min, body cap 16 KB');
}
// ---- honeypot, config, settings, client key, origin, limiter, fields
{
  ok(!G.honeypotTripped(undefined) && !G.honeypotTripped(null) && !G.honeypotTripped('') && !G.honeypotTripped('   '), 'honeypot: absent or empty passes');
  ok(G.honeypotTripped('x') && G.honeypotTripped('http://spam.example') && G.honeypotTripped(0) && G.honeypotTripped(false) && G.honeypotTripped({}) && G.honeypotTripped(['']), 'honeypot: anything else is refused');
  const E = (e, s) => ({ FORMSPREE_ENDPOINT: e, CONTACT_SECRET: s }), S16 = 'x'.repeat(16);
  ok(G.readConfig(E('https://forms.example.test/f/abc', S16))?.endpoint === 'https://forms.example.test/f/abc', 'config: https endpoint and a 16-character secret are accepted');
  for (const [name, env] of [['no endpoint', E(undefined, S16)], ['empty endpoint', E('', S16)], ['http', E('http://forms.example.test/f/a', S16)], ['ftp', E('ftp://forms.example.test/f/a', S16)], ['not a URL', E('not a url', S16)], ['no host', E('https://', S16)], ['no secret', E('https://forms.example.test/f/a', undefined)], ['15-character secret', E('https://forms.example.test/f/a', 'x'.repeat(15))], ['empty secret', E('https://forms.example.test/f/a', '')]]) ok(G.readConfig(env) === null, 'config: ' + name + ' is not configured');
  ok(same(G.settings({}), { perClient: 3, perInstance: 40 }) && same(G.settings({ CONTACT_RATE_PER_HOUR: '5', CONTACT_GLOBAL_PER_HOUR: '9' }), { perClient: 5, perInstance: 9 }) && same(G.settings({ CONTACT_RATE_PER_HOUR: '0', CONTACT_GLOBAL_PER_HOUR: 'x' }), { perClient: 3, perInstance: 40 }), 'settings: 3 and 40 by default, configurable, junk falls back to the defaults');
  const hdr = h => ({ headers: new Headers(h) });
  ok(G.clientKey(hdr({ 'x-real-ip': '1.1.1.1', 'x-forwarded-for': '2.2.2.2' })) === '1.1.1.1' && G.clientKey(hdr({ 'x-vercel-forwarded-for': '3.3.3.3', 'x-forwarded-for': '2.2.2.2' })) === '3.3.3.3' && G.clientKey(hdr({ 'x-forwarded-for': '2.2.2.2, 10.0.0.1' })) === '2.2.2.2' && G.clientKey(hdr({})) === 'unknown', 'client key: x-real-ip, then x-vercel-forwarded-for, then the first x-forwarded-for entry, else unknown');
  // limiter
  let t = 0; const L = G.makeLimiter({ now: () => t, windowMs: 1000 });
  ok(L.check('a', 2, 100).ok && L.check('a', 2, 100).ok, 'limiter: check() alone does not count'); L.hit('a'); L.hit('a');
  { const r = L.check('a', 2, 100); ok(!r.ok && r.retryAfter === 1, 'limiter: refuses after two hits, with Retry-After'); } ok(L.check('b', 2, 100).ok, 'limiter: another client is not affected');
  t = 1001; ok(L.check('a', 2, 100).ok, 'limiter: the window resets'); L.hit('a'); L.hit('a'); L.hit('b'); L.hit('b'); ok(!L.check('c', 5, 4).ok && L.check('c', 5, 5).ok, 'limiter: the instance-wide count refuses every client');
  t = 2002; ok(L.check('c', 5, 4).ok, 'limiter: and resets too');
  const L2 = G.makeLimiter({ now: () => t, windowMs: 1000, maxKeys: 3 }); for (let i = 0; i < 3; i++) L2.hit('k' + i); ok(!L2.check('new', 5, 100).ok && L2.size() === 3, 'limiter: a flood of new clients is refused, the table does not grow');
  ok(L2.check('k0', 5, 100).ok, 'limiter: a client already in the table is still served'); t = 5000; ok(L2.check('fresh', 5, 100).ok, 'limiter: expired clients are swept and new ones served again');
  ok(G.makeLimiter({ now: () => 0 }).check('x', 1, 1).ok, 'limiter: default window is accepted');
  { const H = G.makeLimiter({ now: () => 0 }); H.hit('x'); const r = H.check('x', 1, 100); ok(!r.ok && r.retryAfter === 3600, 'limiter: the default window is one hour'); }
  // fields
  const V = b => G.validateFields(b), M10 = 'a'.repeat(10);
  ok(V({ message: M10 }).ok && V({ message: '  ' + M10 + '  ' }).value.message === M10, 'fields: 10 characters, trimmed');
  ok(V({ message: 'a'.repeat(9) }).error === 'invalid_message' && V({ message: ' '.repeat(5) + 'a'.repeat(9) + ' '.repeat(5) }).error === 'invalid_message', 'fields: 9 characters after trim is too short');
  ok(V({ message: 'a'.repeat(2000) }).ok && V({ message: 'a'.repeat(2001) }).error === 'invalid_message' && V({ message: '😀'.repeat(2000) }).ok && V({ message: '😀'.repeat(2001) }).error === 'invalid_message', 'fields: 2000 characters (an emoji counts once), not 2001');
  for (const m of [undefined, null, 12, ['abcdefghijkl'], { a: 1 }, '', true]) ok(V({ message: m }).error === 'invalid_message', 'fields: message ' + JSON.stringify(m) + ' is invalid');
  ok(V({ message: M10, name: 'a'.repeat(100) }).ok && V({ message: M10, name: 'a'.repeat(101) }).error === 'invalid_name' && V({ message: M10, name: 5 }).error === 'invalid_name' && V({ message: M10, name: null }).value.name === '', 'fields: name up to 100 characters, a string, optional');
  ok(V({ message: M10, reply: 'a@example.com' }).ok && V({ message: M10, reply: 'first.last+tag@sub.example.org' }).ok && V({ message: M10, reply: "o'brien@example.com" }).ok && V({ message: M10, reply: '' }).value.reply === '', 'fields: reasonable addresses pass, empty is fine');
  for (const r of ['plain', 'a@b', 'a@@example.com', 'a b@example.com', '@example.com', 'a@.com', 'a@example.' + '.com', '.a@example.com', 'a@example.c', '<a@example.com>', 'a@example.com, b@example.com', 'a@example.com\nBcc: x@example.com', 5, {}, `${'a'.repeat(64)}@${'b'.repeat(150)}.com`, 'a'.repeat(190) + '@example.com']) ok(V({ message: M10, reply: r }).error === 'invalid_reply', 'fields: reply ' + JSON.stringify(r).slice(0, 40) + ' is invalid');
  ok(V({ message: M10, reply: 'a'.repeat(190) + '@example.com' }).error === 'invalid_reply' && V({ message: M10, reply: 'a'.repeat(60) + '@' + 'b'.repeat(140) + '.com' }).ok === false, 'fields: a reply over 200 characters is refused');
  ok(V({ message: M10 }).value.lang === 'en' && V({ message: M10, lang: 'it' }).value.lang === 'it' && V({ message: M10, lang: 'fr' }).error === 'bad_request' && V({ message: M10, lang: 5 }).error === 'bad_request', 'fields: lang is en or it, en by default');
  { const v = V({ message: 'Hi\u0000 th\u0007ere\r\nline two\r\n\r\n\r\n\r\nline\tthree‮ end\u007F\u0085﻿', name: 'Ada\n\tLovelace\u0000‎  x', reply: ' a@example.com ', admin: true, _next: 'https://evil.example' });
    ok(v.ok && v.value.message === 'Hi there\nline two\n\nline three' + 'end' && v.value.name === 'Ada Lovelace‎ x' && v.value.reply === 'a@example.com' && same(Object.keys(v.value), ['message', 'name', 'reply', 'lang']), 'fields: control characters stripped, line breaks kept in a message, runs of blank lines shortened, other fields ignored: ' + JSON.stringify(v.value)); }
}

// ---- the route, step by step
const MSG = 'Hello authors, MSG-SENTINEL-4417: does the XOR rule hold for e_5 and e_3?', NAME = 'NAME-SENTINEL-4417', REPLY = 'reply.sentinel@example.test';
async function ticket(h, lang = 'en', headers = {}) { const r = await send(h, getReq(lang, headers)); return { ...r.json, answer: String(solve(r.json.question)), status: r.status }; }
async function submit(h, over = {}, { wait = 5000, ip, headers = {}, lang = 'en' } = {}) {
  const tk = await ticket(h, lang); T += wait;
  return send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG, name: NAME, reply: REPLY, lang, website: '', ...over }, headers: ip ? { 'x-real-ip': ip, ...headers } : headers }));
}
const forwarded = () => calls.length;
const withEnv = async (env, fn) => { const old = {}; for (const k of Object.keys(env)) { old[k] = process.env[k]; if (env[k] === undefined) delete process.env[k]; else process.env[k] = env[k]; } try { return await fn(); } finally { for (const k of Object.keys(old)) { if (old[k] === undefined) delete process.env[k]; else process.env[k] = old[k]; } } };
{
  const h = await freshRoute();
  // GET
  for (const lang of ['en', 'it']) {
    const r = await send(h, getReq(lang)), j = r.json;
    ok(r.status === 200 && /^application\/json/.test(r.headers.get('content-type')) && r.headers.get('cache-control') === 'no-store' && r.headers.get('x-content-type-options') === 'nosniff' && !r.headers.get('access-control-allow-origin'), `GET ${lang}: 200, JSON, no-store, nosniff, no CORS header`);
    ok(same(Object.keys(j).sort(), ['expiresIn', 'hint', 'question', 'token']) && j.expiresIn === 600 && j.hint === G.HINT[lang] && j.hint === CONTACT[lang].hint, `GET ${lang}: exactly token, question, hint, expiresIn (the answer is not among them)`);
    ok(lang === 'en' ? /What is|How many/.test(j.question) : /Quanto vale|Quanti/.test(j.question), `GET ${lang}: the question is in ${lang}: ${j.question}`);
    const ans = solve(j.question); ok(!/answer|risposta/i.test(r.text), `GET ${lang}: the word "answer" is not in the response`);
    ok((await G.verifyToken(SECRET, j.token, String(ans), T + 5000)).ok && !(await G.verifyToken(SECRET, j.token, String(ans + 1), T + 5000)).ok, `GET ${lang}: the token stands for the answer of the question that came with it`);
  }
  { const a = await send(h, getReq()), b = await send(h, getReq('fr')), c = await send(h, getReq('it')); ok(/What is|How many/.test(a.json.question) && /What is|How many/.test(b.json.question) && /Quanto|Quanti/.test(c.json.question), 'GET: no language or an unknown one gives English, ?lang=it Italian'); ok(a.json.token !== b.json.token, 'GET: every call has its own token'); }
  // re-test T1-8: ?aud=yl gives the plain puzzles and hint; any other value the usual ones; the token is checked the same way
  for (const lang of ['en', 'it']) { let plainOk = 0; for (let i = 0; i < 24; i++) { const r = await send(h, getReq(lang + '&aud=yl')), j = r.json, ans = solve(j.question);
      if (r.status === 200 && /^plain-/.test(kindOfText(j.question)) && !TECH.test(j.question) && j.hint === G.HINT_PLAIN[lang] && j.hint === CONTACT[lang].hintPlain && !('answer' in j) && (await G.verifyToken(SECRET, j.token, String(ans), T + 5000)).ok) plainOk++; }
    ok(plainOk === 24, `GET ${lang}&aud=yl: plain question, plain hint, a token for its answer (${plainOk}/24)`); }
  for (const aud of ['YL', 'x', '', 'yl%20', '__proto__']) { const r = await send(h, getReq('en&aud=' + aud)); ok(r.status === 200 && !/^plain-/.test(kindOfText(r.json.question)) && r.json.hint === G.HINT.en, `GET aud=${aud}: not on the list, the usual puzzle and hint`); }
  { let leaks = 0; for (let i = 0; i < 60; i++) { const r = await send(h, getReq(i % 2 ? 'it' : 'en')), a = String(solve(r.json.question)); const toks = r.json.token.split('.'); if ('answer' in r.json || Object.values(r.json).some(v => v === a || v === Number(a)) || toks[1] === a) leaks++; } ok(leaks === 0, 'GET: the answer is never a field of the response (60 puzzles)'); }
  { const r = await send(h, getReq('en', { origin: 'https://evil.example' })); ok(r.status === 200, 'GET: a puzzle is handed to anyone (the token proves nothing by itself); the origin rule is for POST'); }
  for (const m of ['PUT', 'DELETE', 'PATCH', 'HEAD', 'OPTIONS']) { const r = await send(h, new Request(URLC, { method: m, headers: { origin: 'https://atlas.example' } })); ok(r.status === 405 && r.headers.get('allow') === 'GET, POST' && !r.headers.get('access-control-allow-origin') && r.text.includes('method_not_allowed'), m + ' is refused with Allow: GET, POST and no CORS'); }
  ok(calls.length === 0, 'nothing was forwarded so far');
  { const tk = await ticket(h, 'en&aud=yl'); T += 5000; const r = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG, lang: 'en' } })); ok(r.status === 200 && r.json?.ok === true, 'a plain puzzle answered right is accepted by the same POST: ' + r.status); }

  // origin
  const goodBody = async () => { const tk = await ticket(h); T += 5000; return { token: tk.token, answer: tk.answer, message: MSG }; };
  { calls = []; const b = await goodBody();
    ok((await send(h, postReq({ body: b, headers: { origin: 'https://evil.example' } }))).status === 403, 'POST from another site: 403');
    ok((await send(h, postReq({ body: b, headers: { origin: 'not a url' } }))).status === 403 && (await send(h, postReq({ body: b, headers: { origin: 'null' } }))).status === 403, 'POST with a malformed or "null" Origin: 403');
    // re-test T1-4: look-alike hosts (a suffix or prefix of the page's host is not the page's host)
    for (const o of ['https://evil-atlas.example', 'https://atlas.example.evil.com', 'http://atlas.example.evil.com:443', 'https://xatlas.example', 'https://atlas.example:8443']) ok((await send(h, postReq({ body: b, headers: { origin: o } }))).status === 403, 'POST from a look-alike host: 403: ' + o);
    ok(G.originAllowed(new Request(URLC, { method: 'POST', headers: { origin: 'https://atlas.example' } })) && !G.originAllowed(new Request(URLC, { method: 'POST', headers: { origin: 'https://evil-atlas.example' } })) && !G.originAllowed(new Request(URLC, { method: 'POST', headers: { origin: 'https://atlas.example.evil.com' } })), 'originAllowed: the page\'s own host only, not a look-alike');
    { const r = new Request(URLC, { method: 'POST', headers: { 'content-type': 'application/json', 'x-real-ip': nextIp() }, body: JSON.stringify(b) }); ok((await send(h, r)).status === 403, 'POST with no Origin and no Sec-Fetch-Site: 403'); }
    { const r = new Request(URLC, { method: 'POST', headers: { 'content-type': 'application/json', 'sec-fetch-site': 'cross-site', 'x-real-ip': nextIp() }, body: JSON.stringify(b) }); ok((await send(h, r)).status === 403, 'POST with Sec-Fetch-Site: cross-site: 403'); }
    ok(forwarded() === 0, 'a refused origin forwards nothing');
    { const r = new Request(URLC, { method: 'POST', headers: { 'content-type': 'application/json', 'sec-fetch-site': 'same-origin', 'x-real-ip': nextIp() }, body: JSON.stringify(b) }); const x = await send(h, r); ok(x.status === 200 && forwarded() === 1, 'a same-origin fetch without an Origin header is allowed: ' + x.status); }
    process.env.CONTACT_ALLOWED_ORIGINS = 'https://partner.example, https://other.example'; { const b2 = await goodBody(); ok((await send(h, postReq({ body: b2, headers: { origin: 'https://partner.example' } }))).status === 200, 'an origin on CONTACT_ALLOWED_ORIGINS is allowed'); } delete process.env.CONTACT_ALLOWED_ORIGINS;
    process.env.CHAT_ALLOWED_ORIGINS = 'https://sister.example'; { for (const o of ['https://sister.example.evil.com', 'https://sister.examplex', 'https://sister.example:8443']) { const bx = await goodBody(); ok((await send(h, postReq({ body: bx, headers: { origin: o } }))).status === 403, 're-test V1-8: a look-alike of an allow-listed origin is refused: ' + o); } const b3 = await goodBody(); ok((await send(h, postReq({ body: b3, headers: { origin: 'https://sister.example' } }))).status === 200, 'an origin on CHAT_ALLOWED_ORIGINS is allowed too'); const b4 = await goodBody(); ok((await send(h, postReq({ body: b4, headers: { origin: 'https://evil.example' } }))).status === 403, 'but not another one'); } delete process.env.CHAT_ALLOWED_ORIGINS;
  }
  // content type, body, shape
  calls = [];
  ok((await send(h, postReq({ raw: '{}', headers: { 'content-type': 'text/plain' } }))).status === 415 && (await send(h, postReq({ raw: '{}', headers: { 'content-type': 'application/x-www-form-urlencoded' } }))).status === 415, 'not JSON: 415');
  ok((await send(h, postReq({ raw: '{}', headers: { 'content-type': 'Application/JSON; charset=utf-8' } }))).status !== 415, 'application/json with a charset is fine');
  ok((await send(h, postReq({ raw: '{not json' }))).status === 400 && (await send(h, postReq({ raw: '' }))).status === 400, 'invalid JSON: 400');
  for (const raw of ['[1,2]', 'null', '"text"', '12', 'true']) ok((await send(h, postReq({ raw }))).status === 400, 'a body that is not an object (' + raw + '): 400');
  { const tk = await ticket(h); T += 5000;
    const exactBody = JSON.stringify({ token: tk.token, answer: tk.answer, message: MSG, junk: 'x'.repeat(G.MAX_BODY - JSON.stringify({ token: tk.token, answer: tk.answer, message: MSG, junk: '' }).length) }); ok(exactBody.length === G.MAX_BODY, 'exact-size body built');
    { const r = await send(h, postReq({ raw: exactBody })); ok(r.status === 200, 'a body of exactly 16 KB is accepted: ' + r.status); }
    { const r = await send(h, postReq({ raw: exactBody + ' ' })); ok(r.status === 413 && r.json.error === 'too_large', 'a body of 16 KB + 1 byte: 413'); }
    { const r = await send(h, postReq({ raw: exactBody, headers: { 'content-length': String(G.MAX_BODY + 1) } })); ok(r.status === 413, 'a declared length over the cap: 413 before the body is read'); }
    const huge = JSON.stringify({ message: 'x'.repeat(200000) }); ok((await send(h, postReq({ raw: huge }))).status === 413, 'a huge body: 413');
    const enc = new TextEncoder(), stream = new ReadableStream({ start(c) { c.enqueue(enc.encode('{"a":"')); c.enqueue(enc.encode('x'.repeat(G.MAX_BODY))); c.close(); } });
    ok((await send(h, new Request(URLC, { method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://atlas.example', 'x-real-ip': nextIp() }, body: stream, duplex: 'half' }))).status === 413, 'a streamed body without a length: 413'); }
  ok(forwarded() === 1, 'only the exact-size body was forwarded: ' + forwarded());
}
// not configured (GET and POST), and the order of the checks that come before the configuration
{
  const h = await freshRoute(), tk = await ticket(h); T += 5000; calls = [];
  const full = { token: tk.token, answer: tk.answer, message: MSG };
  const E = { FORMSPREE_ENDPOINT: ENDPOINT, CONTACT_SECRET: SECRET };
  for (const [name, env] of [['no endpoint', { ...E, FORMSPREE_ENDPOINT: undefined }], ['http endpoint', { ...E, FORMSPREE_ENDPOINT: 'http://forms.example.test/f/a' }], ['endpoint that is not a URL', { ...E, FORMSPREE_ENDPOINT: 'not a url' }], ['empty endpoint', { ...E, FORMSPREE_ENDPOINT: '' }], ['no secret', { ...E, CONTACT_SECRET: undefined }], ['secret of 15 characters', { ...E, CONTACT_SECRET: 'x'.repeat(15) }], ['neither', { FORMSPREE_ENDPOINT: undefined, CONTACT_SECRET: undefined }]]) await withEnv(env, async () => {
    const g = await send(h, getReq('en')), p = await send(h, postReq({ body: full }));
    ok(g.status === 503 && g.text === '{"error":"not_configured"}' && p.status === 503 && p.text === '{"error":"not_configured"}', `${name}: GET and POST answer 503 not_configured and nothing else`);
    ok(!/FORMSPREE|CONTACT_SECRET|endpoint|secret|variable/i.test(g.text + p.text + JSON.stringify([...g.headers]) + JSON.stringify([...p.headers])), `${name}: the response does not say which setting is missing`);
  });
  ok(forwarded() === 0, 'nothing forwarded while not configured');
  await withEnv({ CONTACT_SECRET: 'x'.repeat(16) }, async () => ok((await send(h, getReq('en'))).status === 200, 'a 16-character secret is enough'));
  // order: method -> origin -> content type -> body -> config -> honeypot -> token -> too fast -> rate limit -> validation -> forward
  await withEnv({ FORMSPREE_ENDPOINT: undefined }, async () => {
    ok((await send(h, new Request(URLC, { method: 'PUT', headers: { origin: 'https://evil.example' } }))).status === 405, 'order: the method comes before the origin');
    ok((await send(h, postReq({ raw: '{}', headers: { origin: 'https://evil.example', 'content-type': 'text/plain' } }))).status === 403, 'order: the origin comes before the content type');
    ok((await send(h, postReq({ raw: '{bad', headers: { 'content-type': 'text/plain' } }))).status === 415, 'order: the content type comes before the body');
    ok((await send(h, postReq({ raw: '{bad' }))).status === 400 && (await send(h, postReq({ raw: JSON.stringify({ x: 'y'.repeat(G.MAX_BODY) }) }))).status === 413, 'order: the body (invalid, too large) comes before the configuration');
    ok((await send(h, postReq({ body: { ...full, website: 'spam' } }))).status === 503, 'order: the configuration comes before the honeypot');
  });
  { const r = await send(h, postReq({ body: { ...full, token: 'junk', website: 'spam' } })); ok(r.status === 400 && r.json.error === 'rejected', 'order: the honeypot comes before the token'); }
  { const t2 = await ticket(h); T += 1000; const r = await send(h, postReq({ body: { token: t2.token, answer: String(Number(t2.answer) + 1), message: MSG } })); ok(r.json.error === 'wrong_answer', 'order: the answer comes before the minimum fill time'); T += 4000; }
  await withEnv({ CONTACT_RATE_PER_HOUR: '1' }, async () => {
    const ip = '198.51.100.99'; const a = await submit(h, {}, { ip }); ok(a.status === 200, 'order setup: the first message of this client is delivered');
    const t3 = await ticket(h); T += 1000; const r = await send(h, postReq({ body: { token: t3.token, answer: t3.answer, message: 'x' }, headers: { 'x-real-ip': ip } })); ok(r.status === 400 && r.json.error === 'too_fast', 'order: the minimum fill time comes before the rate limit: ' + r.text);
    T += 4000; const r2 = await send(h, postReq({ body: { token: t3.token, answer: t3.answer, message: 'x' }, headers: { 'x-real-ip': ip } })); ok(r2.status === 429, 'order: the rate limit comes before the validation of the fields: ' + r2.status);
  });
  { const t4 = await ticket(h); T += 5000; const r = await send(h, postReq({ body: { token: t4.token, answer: t4.answer, message: 'short' } })); ok(r.status === 400 && r.json.error === 'invalid_message', 'order: validation, last before forwarding'); }
}
// the token and the answer, through the route
{
  const h = await freshRoute(); calls = [];
  { const r = await submit(h, { answer: '9999' }); ok(r.status === 400 && r.json.error === 'wrong_answer', 'a wrong answer: 400 wrong_answer'); }
  for (const a of [undefined, '', 'abc', null, '12 13']) { const r = await submit(h, { answer: a }); ok(r.status === 400 && r.json.error === 'wrong_answer', 'a missing or malformed answer (' + JSON.stringify(a) + '): wrong_answer'); }
  for (const tok of [undefined, '', 'garbage', null, 5, 'a.b.c']) { const r = await submit(h, { token: tok }); ok(r.status === 400 && r.json.error === 'bad_token', 'a missing or malformed token (' + JSON.stringify(tok) + '): bad_token'); }
  { const tk = await ticket(h); T += 5000; const [a, e, m] = tk.token.split('.');
    for (const [name, tok] of [['MAC', `${a}.${e}.${m.slice(0, 5)}${m[5] === 'A' ? 'B' : 'A'}${m.slice(6)}`], ['expiry', `${a}.${Number(e) + 600}.${m}`], ['nonce', `${a.slice(0, 5)}${a[5] === 'A' ? 'B' : 'A'}${a.slice(6)}.${e}.${m}`]]) { const r = await send(h, postReq({ body: { token: tok, answer: tk.answer, message: MSG } })); ok(r.status === 400 && ['wrong_answer', 'bad_token'].includes(r.json.error), `a tampered token (${name}) is refused: ${r.text}`); }
    const alien = await G.issueToken(OTHER, Number(tk.answer), T - 5000); { const r = await send(h, postReq({ body: { token: alien, answer: tk.answer, message: MSG } })); ok(r.status === 400 && r.json.error === 'wrong_answer', 'a token signed with another secret is refused'); }
    let swap; do { swap = await ticket(h); } while (swap.answer === tk.answer); T += 5000;
    { const r = await send(h, postReq({ body: { token: tk.token, answer: swap.answer, message: MSG } })); ok(r.status === 400 && r.json.error === 'wrong_answer', 'the answer of another puzzle does not fit this token'); }
  }
  ok(forwarded() === 0, 'none of the refused tokens or answers was forwarded');
  // expired
  { const tk = await ticket(h); T += 601_000; const r = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG } })); ok(r.status === 400 && r.json.error === 'expired' && forwarded() === 0, 'a token older than 10 minutes: expired'); }
  { const tk = await ticket(h); T += 595_000; const r = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG } })); ok(r.status === 200, 'a token a few seconds before the 10 minutes is still good: ' + r.status); }
  // too fast: not burnt, so the same token works a moment later
  { calls = []; const tk = await ticket(h);
    for (const wait of [0, 1000, 2500]) { T += wait; const r = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG } })); ok(r.status === 400 && r.json.error === 'too_fast', `a POST ${T % 100000} ms after the puzzle came is too_fast`); }
    T += 3000; const ok2 = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG } })); ok(ok2.status === 200 && forwarded() === 1, 'the same token is accepted once 4 s have passed (too_fast does not spend it)'); }
  // replay
  { calls = []; const tk = await ticket(h); T += 5000; const body = { token: tk.token, answer: tk.answer, message: MSG };
    const a = await send(h, postReq({ body })), b = await send(h, postReq({ body })); ok(a.status === 200 && b.status === 400 && b.json.error === 'replayed' && forwarded() === 1, 'the same token twice: the second is replayed, and only one message went out');
    const tk2 = await ticket(h); T += 5000; const body2 = { token: tk2.token, answer: tk2.answer, message: MSG }; const rs = await Promise.all([send(h, postReq({ body: body2 })), send(h, postReq({ body: body2 })), send(h, postReq({ body: body2 }))]);
    ok(rs.filter(r => r.status === 200).length === 1 && rs.filter(r => r.json?.error === 'replayed').length === 2 && forwarded() === 2, 'three simultaneous POSTs with one token: exactly one wins: ' + rs.map(r => r.status));
    const h2 = await freshRoute(), c = await send(h2, postReq({ body })); ok(c.status === 200, 'known limit, as documented: another instance has not seen the nonce, so replay protection is per instance (best effort)'); }
  // a refused message does not spend the puzzle or the allowance
  { calls = []; const tk = await ticket(h); T += 5000; const bad1 = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: 'short' } })), good1 = await send(h, postReq({ body: { token: tk.token, answer: tk.answer, message: MSG } })); ok(bad1.json.error === 'invalid_message' && good1.status === 200 && forwarded() === 1, 'a message that fails validation does not spend the token: fix it and send again'); }
  // honeypot
  { calls = []; for (const w of ['http://spam.example', 'x', 0, false, {}]) { const r = await submit(h, { website: w }); ok(r.status === 400 && r.json.error === 'rejected', 'honeypot filled with ' + JSON.stringify(w) + ': rejected'); } ok(forwarded() === 0, 'a filled honeypot forwards nothing');
    for (const w of ['', '   ', undefined, null]) { const r = await submit(h, { website: w }); ok(r.status === 200, 'honeypot empty (' + JSON.stringify(w) + '): accepted'); } }
}
// fields and the forwarded JSON
{
  const h = await freshRoute();
  for (const [name, over, code] of [['no message', { message: undefined }, 'invalid_message'], ['9 characters', { message: '123456789' }, 'invalid_message'], ['blank message', { message: ' \n\t ' }, 'invalid_message'], ['2001 characters', { message: 'a'.repeat(2001) }, 'invalid_message'], ['message not a string', { message: 12345678901 }, 'invalid_message'], ['name of 101 characters', { name: 'n'.repeat(101) }, 'invalid_name'], ['name not a string', { name: ['x'] }, 'invalid_name'], ['bad address', { reply: 'not-an-address' }, 'invalid_reply'], ['address without a dot', { reply: 'a@b' }, 'invalid_reply'], ['two addresses', { reply: 'a@example.com,b@example.com' }, 'invalid_reply'], ['address of 201 characters', { reply: 'a'.repeat(190) + '@example.com' }, 'invalid_reply'], ['unknown language', { lang: 'fr' }, 'bad_request']]) {
    calls = []; const r = await submit(h, over); ok(r.status === 400 && r.json.error === code && forwarded() === 0, `${name}: 400 ${code}, nothing forwarded (${r.text})`); }
  { calls = []; const r = await submit(h, { message: 'a'.repeat(10) }); ok(r.status === 200, 'a message of 10 characters is accepted'); const r2 = await submit(h, { message: 'a'.repeat(2000) }); ok(r2.status === 200 && calls.at(-1).body.message.length === 2000, '2000 characters are accepted'); const r3 = await submit(h, { message: '😀'.repeat(2000) }); ok(r3.status === 200, '2000 emoji are accepted (counted as characters)'); }
  // the forwarded JSON
  calls = []; timeoutArgs = [];
  { const r = await submit(h, {}); const c = calls[0];
    ok(r.status === 200 && r.text === '{"ok":true}' && forwarded() === 1, 'success: 200 {"ok":true}, one call to the form service');
    ok(c.url === ENDPOINT && c.init.method === 'POST' && c.init.headers['content-type'] === 'application/json' && c.init.headers.accept === 'application/json', 'it goes to the configured URL, as a JSON POST');
    ok(c.raw === JSON.stringify({ message: MSG, name: NAME, _replyto: REPLY, lang: 'en', page: 'cascade-atlas' }), 'exactly the intended JSON: ' + c.raw);
    ok(c.init.signal instanceof AbortSignal && timeoutArgs.at(-1) === 10000, 'with a 10 second timeout (AbortSignal.timeout(10000))');
    ok(same(Object.keys(c.init).sort(), ['body', 'headers', 'method', 'signal']), 'and nothing else in the request init: ' + Object.keys(c.init)); }
  { calls = []; await submit(h, { name: undefined, reply: undefined }); ok(calls[0].raw === JSON.stringify({ message: MSG, lang: 'en', page: 'cascade-atlas' }), 'without a name and an address they are left out: ' + calls[0].raw);
    calls = []; await submit(h, { name: '', reply: '', lang: 'it' }, { lang: 'it' }); ok(calls[0].body.lang === 'it' && !('name' in calls[0].body) && !('_replyto' in calls[0].body), 'empty ones are left out; lang it is forwarded'); }
  { calls = []; await submit(h, { admin: true, _next: 'https://evil.example/thanks', _cc: 'x@example.com', _subject: 'hello', _gotcha: 'x', _replyto: 'evil@example.com', page: 'elsewhere', extra: { deep: 1 } }); ok(same(Object.keys(calls[0].body), ['message', 'name', '_replyto', 'lang', 'page']) && calls[0].body._replyto === REPLY && calls[0].body.page === 'cascade-atlas', 'fields the page did not define are ignored (no _next, _cc, _subject, no forged _replyto): ' + calls[0].raw); }
  { calls = []; await submit(h, { message: '  Hello\u0000 wor\u0007ld\r\nsecond‮line here  ', name: 'Ada\n\tVisitor\u0000' }); ok(calls[0].body.message === 'Hello world\nsecondline here' && calls[0].body.name === 'Ada Visitor', 'control characters are stripped and the message is trimmed: ' + JSON.stringify(calls[0].body.message)); }
  // upstream failures: one fixed code, nothing from upstream
  for (const [m, label] of [['500', 'a 500'], ['429', 'a 429'], ['throw', 'a network error'], ['hang', 'a form service that never answers']]) {
    mode = m; calls = []; timeoutOverride = m === 'hang' ? 40 : null; const keepAlive = setInterval(() => {}, 20);       // AbortSignal.timeout does not keep a bare Node process alive
    const r = await submit(h, {}); clearInterval(keepAlive); timeoutOverride = null; mode = 'ok';
    ok(r.status === 502 && r.text === '{"error":"delivery_failed"}' && forwarded() === 1, `${label} from the form service: 502 delivery_failed, and only that: ${r.status} ${r.text}`);
    ok(!/upstream|network|SECRET|secret|forms\.example|canary|slow down|Timeout|TypeError/i.test(r.text + JSON.stringify([...r.headers])), `${label}: nothing from upstream in the response`);
  }
  { mode = '500'; const tk = await ticket(h); T += 5000; const body = { token: tk.token, answer: tk.answer, message: MSG }; const a = await send(h, postReq({ body })); mode = 'ok'; const b = await send(h, postReq({ body })); ok(a.status === 502 && b.json.error === 'replayed', 'after a failed delivery the puzzle is spent too: the page asks for a new one'); }
}
// rate limits
{
  { const h = await freshRoute(), ip = '198.51.100.7', st = []; for (let i = 0; i < 5; i++) st.push((await submit(h, {}, { ip })).status);
    ok(st.join() === '200,200,200,429,429', 'default: three a client, then 429: ' + st.join());
    const r = await submit(h, {}, { ip }); ok(r.status === 429 && r.json.error === 'rate_limited' && Number(r.headers.get('retry-after')) >= 1 && Number(r.headers.get('retry-after')) <= 3600, 'the 429 carries Retry-After (seconds, at most an hour): ' + r.headers.get('retry-after'));
    ok((await submit(h, {}, { ip: '198.51.100.8' })).status === 200, 'another client is not affected');
    const via = []; for (let i = 0; i < 4; i++) via.push((await submit(h, {}, { ip: '198.51.100.9', headers: { 'x-forwarded-for': `9.9.9.${i}, 10.0.0.1` } })).status); ok(via.join() === '200,200,200,429', 'the client is keyed by x-real-ip, not by an x-forwarded-for value it can vary: ' + via);
    T += 3600_000 + 5000; ok((await submit(h, {}, { ip })).status === 200, 'after the hour the client can write again'); }
  await withEnv({ CONTACT_RATE_PER_HOUR: '1' }, async () => { const h = await freshRoute(), ip = '198.51.100.20'; const a = await submit(h, {}, { ip }), b = await submit(h, {}, { ip }); ok(a.status === 200 && b.status === 429, 'CONTACT_RATE_PER_HOUR=1 is honoured'); });
  await withEnv({ CONTACT_RATE_PER_HOUR: '2' }, async () => { const h = await freshRoute(), ip = '198.51.100.21', st = []; for (let i = 0; i < 3; i++) st.push((await submit(h, { message: 'short' }, { ip })).status); const a = await submit(h, {}, { ip }), b = await submit(h, {}, { ip }), c = await submit(h, {}, { ip }); ok(st.join() === '400,400,400' && a.status === 200 && b.status === 200 && c.status === 429, 'failed validations do not use up the allowance: ' + st + ' ' + a.status + b.status + c.status); });
  await withEnv({ CONTACT_GLOBAL_PER_HOUR: '2' }, async () => { const h = await freshRoute(), st = []; for (let i = 0; i < 4; i++) st.push((await submit(h, {}, { ip: '192.0.2.' + (i + 1) })).status); ok(st.join() === '200,200,429,429', 'CONTACT_GLOBAL_PER_HOUR=2: the instance refuses every client once two are through: ' + st); const r = await submit(h, {}, { ip: '192.0.2.77' }); ok(Number(r.headers.get('retry-after')) >= 1, 'and says when to come back'); });
  { const h = await freshRoute(), st = []; for (let i = 0; i < 42; i++) st.push((await submit(h, {}, { ip: '192.0.2.' + (i + 100) })).status); ok(st.slice(0, 40).every(s => s === 200) && st[40] === 429 && st[41] === 429, 'default: 40 an hour for the whole instance: ' + st.filter(s => s === 200).length + ' through'); }
  { const h = await freshRoute(), a = await submit(h, {}, { ip: '192.0.2.200' }); ok(a.status === 200, 'a fresh instance has fresh counters (limits are per instance)'); }
}
// nothing secret leaves
{
  const SECRETS = [SECRET, OTHER, ENDPOINT, OWNER, 'forms.example.test', MSG, 'MSG-SENTINEL-4417', NAME, REPLY, '203.0.113.', '198.51.100.', '192.0.2.'];
  const body = seen.map(s => s.status + ' ' + s.headers + ' ' + s.text).join('\n'), log = logs.join('\n');
  for (const s of SECRETS) { ok(!body.includes(s), `no response (${seen.length} of them) contains "${s.slice(0, 24)}"`); ok(!log.includes(s), `no log line (${logs.length} of them) contains "${s.slice(0, 24)}"`); }
  ok(logs.length > 0 && logs.every(l => /^contact: form service (status \d{3}|failure \w+)$/.test(l)), 'the only log lines are a status number or an error name: ' + [...new Set(logs)].join(' | '));
  const codes = new Set(seen.map(s => { try { return JSON.parse(s.text).error; } catch { return null; } }).filter(Boolean));
  const generic = ['method_not_allowed', 'forbidden', 'unsupported_media_type', 'too_large', 'bad_request'];
  ok([...codes].every(c => generic.includes(c) || c in CONTACT.en.errors), 'every error code the route sent has a sentence in the copy: ' + [...codes].filter(c => !generic.includes(c) && !(c in CONTACT.en.errors)));
  ok(['wrong_answer', 'expired', 'replayed', 'too_fast', 'rate_limited', 'not_configured', 'delivery_failed', 'rejected', 'invalid_message', 'invalid_name', 'invalid_reply', 'bad_token'].every(c => codes.has(c)), 'the test exercised each of the route\'s own codes: ' + [...codes]);
  ok(seen.every(s => !/access-control-allow/i.test(s.headers)), 'no response carries a CORS header');
  ok(seen.filter(s => s.status !== 200 || s.text !== '{"ok":true}').every(s => /^\{"error":"[a-z_]+"\}$/.test(s.text) || /^\{"token":/.test(s.text)), 'every response is a fixed code, a puzzle or {"ok":true}');
}
// the copy
{
  const keys = (o, p = '') => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' ? keys(v, p + k + '.') : [p + k])), strings = o => Object.values(o).flatMap(v => (v && typeof v === 'object' ? strings(v) : [v]));
  ok(same(keys(CONTACT.en).sort(), keys(CONTACT.it).sort()) && keys(CONTACT.en).length > 30, 'copy: EN and IT have the same keys: ' + keys(CONTACT.en).filter(k => !keys(CONTACT.it).includes(k)) + keys(CONTACT.it).filter(k => !keys(CONTACT.en).includes(k)));
  ok(['en', 'it'].every(l => strings(CONTACT[l]).every(s => typeof s === 'string' && s.trim().length > 2)), 'copy: no empty or non-string entry');
  const ph = s => [...String(s).matchAll(/\{(\w+)\}/g)].map(m => m[1]).sort().join(); let phOk = true; const flat = l => Object.fromEntries(keys(CONTACT[l]).map(k => [k, k.split('.').reduce((o, p) => o[p], CONTACT[l])])); const fe = flat('en'), fi = flat('it'); for (const k of Object.keys(fe)) if (ph(fe[k]) !== ph(fi[k])) { phOk = false; out('placeholder mismatch', k); } ok(phOk, 'copy: EN and IT use the same {placeholders} in every sentence');
  const differ = Object.keys(fe).filter(k => fe[k] === fi[k] && /[A-Za-z]{3,}/.test(fe[k].replace(/\{\w+\}/g, ''))); ok(differ.length === 0, 'copy: every Italian sentence is translated: ' + differ);
  ok(CONTACT.en.link === 'Contact' && CONTACT.it.link === 'Contatti', 'copy: the footer link reads Contact / Contatti');
  ok(/form service/.test(CONTACT.en.intro) && /private/.test(CONTACT.en.intro) && /answer you/.test(CONTACT.en.intro) && /servizio di moduli/.test(CONTACT.it.intro) && /privato/.test(CONTACT.it.intro) && /risponderti/.test(CONTACT.it.intro), 'copy: the intro says where the message goes, what the address is for, and not to send anything private');
  ok(/not set up on this copy/.test(CONTACT.en.errors.not_configured) && /non è ancora configurato/.test(CONTACT.it.errors.not_configured) && /wait a moment/.test(CONTACT.en.errors.too_fast), 'copy: the not-configured and too-fast sentences are the ones asked for');
  ok(CONTACT.en.hint === G.HINT.en && CONTACT.it.hint === G.HINT.it, 'copy: the hint on the form is the hint the route sends');
  ok(CONTACT_LIMITS.min === G.LIMITS.messageMin && CONTACT_LIMITS.max === G.LIMITS.messageMax && CONTACT_LIMITS.name === G.LIMITS.nameMax && CONTACT_LIMITS.reply === G.LIMITS.replyMax, 'copy: the limits the form shows are the limits the route enforces');
  const all = JSON.stringify(CONTACT) + (fs.existsSync('./ContactForm.jsx') ? fs.readFileSync('./ContactForm.jsx', 'utf8') : '');
  ok(!/bot-?proof|spam-?proof|a prova di bot|unbreakable|impenetrab|100% secure/i.test(all), 'copy and form: no claim that the check cannot be got round');
}
// the files
{
  const rd = f => (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null), route = rd('api/contact.js'), guard = rd('lib/contactGuard.js'), form = rd('ContactForm.jsx'), copy = rd('contactCopy.js'), app = rd('App.jsx');
  ok(route && guard && form && copy && app, 'all the files are there');
  for (const [f, s] of [['api/contact.js', route], ['lib/contactGuard.js', guard]]) {
    ok(!/access-control-allow-origin/i.test(s), f + ': no CORS header is sent');
    ok(!/\bBuffer\b|require\(|from 'node:|from "node:|process\.(?!env)/.test(s), f + ': no Node-only API (it runs on the edge runtime)');
    ok(!/console\.(log|error|warn|info|debug)\([^)]*\b(message|body|reply|process\.env|secret|endpoint|token|answer|request|fields|cfg|key)\b/i.test(s.replace(/'contact: form service (status|failure)'/g, '')), f + ': logging never includes a message, an address, a secret, a token or the request');
    ok(!/localStorage|sessionStorage|indexedDB|document\.cookie|set-cookie/i.test(s), f + ': nothing is stored');
  }
  ok(/export const config = \{ runtime: 'edge' \}/.test(route) && /AbortSignal\.timeout\(10000\)/.test(route) && /process\.env/.test(guard) && !/process\.env\.FORMSPREE/.test(route), 'route: edge runtime, 10 s timeout; the settings are read from the environment through the guard');
  { const text = [route, guard, form, copy, ...['README_update_contact.md', 'test_contact.mjs', 'test_contact_ui.mjs', 'test_contact_mutation.mjs'].map(rd)].filter(Boolean).join('\n');
    const foreign = (text.match(/[A-Za-z0-9._%+'-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g) || []).filter(a => !/@(?:[A-Za-z0-9-]+\.)*(?:example\.(?:com|org|net)|[A-Za-z0-9-]+\.(?:invalid|test))$/.test(a));
    ok(foreign.length === 0, 'no e-mail address in any contact file except example.com/.org/.net and .invalid/.test placeholders: ' + foreign); }
  ok(!/mailto:/i.test(form + copy + route + (app || '')), 'no mailto: link anywhere');
  ok(!/localStorage|sessionStorage|indexedDB|document\.cookie/.test(form) && !/<script|https?:\/\/|@import|<link|<iframe|<img/i.test((form + copy).replace(/^\/\/ (SPDX-License-Identifier|Required Notice|Free for noncommercial use only).*\n/gm, '')), 'form: no storage, no cookie, no script, link, frame or URL of another site');
  ok(/role="dialog"/.test(form) && /aria-modal="true"/.test(form) && /aria-labelledby="cf-title"/.test(form) && /role="alert"/.test(form) && /aria-live="polite"/.test(form) && /e\.key === 'Escape'/.test(form) && /e\.key !== 'Tab'/.test(form), 'form: dialog, modal, labelled, alert, polite status, Escape and Tab handling');
  ok(/htmlFor="cf-message"/.test(form) && /htmlFor="cf-name"/.test(form) && /htmlFor="cf-reply"/.test(form) && /htmlFor="cf-answer"/.test(form), 'form: every field has a real <label>');
  ok(/className="cf-hp" aria-hidden="true"/.test(form) && /name="website" tabIndex=\{-1\} autoComplete="off"/.test(form) && /inputMode="numeric"/.test(form), 'form: honeypot (hidden, aria-hidden, tabIndex -1, autocomplete off), numeric answer input');
  ok(/fetch\('\/api\/contact\?lang='/.test(form) && /fetch\('\/api\/contact', \{ method: 'POST'/.test(form) && /credentials: 'omit'/.test(form), 'form: GET for the puzzle, POST for the message, no credentials');
  // re-test T1-4: every fetch of the form, the GET and the POST, carries credentials: 'omit' (read call by call, with balanced parentheses)
  { const calls2 = []; for (let i = form.indexOf('fetch('); i >= 0; i = form.indexOf('fetch(', i + 1)) { let d = 0, j = i + 5; for (; j < form.length; j++) { if (form[j] === '(') d++; else if (form[j] === ')' && --d === 0) break; } calls2.push(form.slice(i, j + 1)); }
    ok(calls2.length === 2 && calls2.every(c => /credentials: 'omit'/.test(c)) && /method: 'POST'/.test(calls2[1]) && !/credentials: '(include|same-origin)'/.test(form), 'form: both fetches (GET and POST) send no credentials: ' + calls2.map(c => c.slice(0, 60)).join(' | ')); }
  // re-test T1-8 and T1-9: the page asks for plain puzzles for the Young Learner; the message box has no maxLength (HTML would count UTF-16 units, the route counts characters)
  ok(/audience === 'Young Learner'/.test(form) && /\(plain \? '&aud=yl' : ''\)/.test(form) && /plain \? t\.hintPlain : t\.hint/.test(form) && /<ContactForm [^\n]*audience=\{profile\}/.test(app), 'form: the Young Learner asks for ?aud=yl and shows the plain hint; App.jsx passes the audience');
  ok(!/<textarea[^>]*maxLength/.test(form), 'form: the message box has no maxLength');
  const foot = /<footer>[\s\S]*<\/footer>/.exec(app)?.[0] || '';
  ok(/import ContactForm/.test(app) && /import \{ CONTACT \} from '\.\/contactCopy\.js'/.test(app) && /useState\(false\)/.test(app) && /<ContactForm lang=\{lang\} open=\{contactOpen\} onClose=/.test(app), 'App.jsx: imports, state and the dialog are wired');
  ok(/<button type="button" className="contact-link" data-contact-open/.test(foot) && /\(CONTACT\[lang\]\|\|CONTACT\.en\)\.link/.test(foot) && /className="made-with"/.test(foot) && /MAP_LENSES/.test(foot) && /STORY\[lang\]/.test(foot), 'App.jsx: the footer has the Contact button, and still has the lenses, the note and the credit');
}
out(bad ? `${bad} FAILURES of ${n}` : `ALL ${n} CONTACT CHECKS PASS`); process.exit(bad ? 1 : 0);
