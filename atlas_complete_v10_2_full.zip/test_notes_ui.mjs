// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import { RESEARCHERS } from './researcherNotes.js';
// The "Note to the researcher" pop-up (v10.1 add-on) in a real browser. It opens with  <atlas>/?for=<name>  over whatever page is showing and touches nothing under it:
//  - without ?for= the atlas is exactly what it was (no overlay, no extra element); an unknown name opens nothing;
//  - ?for=furey (or an alias such as ?for=eelbode) opens the note for that group, over the page named by the hash, which keeps its tab;
//  - a link in the note closes it, removes ?for= from the address and opens the page and tab it names; Escape and the close button close it, and the reader stays where they were;
//  - "Write to the authors" opens the atlas's own contact form; Tab stays inside the note; the note scrolls on a phone and never makes the page wider;
//  - every note opens without a console error, on a desktop and on a phone, and its links all lead to a tab that exists.
// Run: node test_notes_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
// the contact form asks /api/contact for a puzzle, and a browser refuses fetch() on file:// - so the one test that opens the form is served over http, with the route answered by a stub
const srv = http.createServer((q, r) => { const f = path.join(DIST, q.url.split('?')[0].replace(/^\/+/, '') || 'app.html'); fs.readFile(f, (e, d) => { if (e) { r.writeHead(404); return r.end(); } r.writeHead(200, { 'content-type': f.endsWith('.js') ? 'text/javascript' : 'text/html' }); r.end(d); }); });
await new Promise(r => srv.listen(0, r)); const ORIGIN = `http://localhost:${srv.address().port}`, HTTP_APP = ORIGIN + '/app.html';
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const onErr = (pg, tag) => { pg.on('pageerror', e => ok(false, `${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`)); };
const hash = pg => pg.evaluate(() => location.hash), search = pg => pg.evaluate(() => location.search);
const open = async (w, url, tag, pre) => { const ctx = await b.newContext({ viewport: { width: w, height: 860 }, reducedMotion: 'reduce' }), pg = await ctx.newPage(); onErr(pg, tag); if (pre) await pre(pg); await pg.goto(url); await pg.waitForTimeout(350); return [ctx, pg]; };

// ---- 1. nothing changes without ?for=
{ const [ctx, pg] = await open(1100, APP + '#labels/gauge', 'plain');
  ok(await pg.locator('.rn-overlay').count() === 0 && await pg.locator('[data-researcher]').count() === 0, 'without ?for= there is no overlay');
  ok(await hash(pg) === '#labels/gauge' && await pg.locator('.tabbar [aria-selected="true"]').getAttribute('data-tab') === 'gauge', 'and the page is where the address says');
  await ctx.close(); }
{ const [ctx, pg] = await open(1100, APP + '?for=nobody#rule', 'unknown');
  ok(await pg.locator('.rn-overlay').count() === 0, 'an unknown name opens nothing');
  await ctx.close(); }
{ const [ctx, pg] = await open(1100, APP + '?for=todd#rule', 'hold');
  ok(await pg.locator('.rn-overlay').count() === 0, 'a group on hold (no note) opens nothing');
  await ctx.close(); }

// ---- 2. open over a deep link, follow a link, close
{ const [ctx, pg] = await open(1100, APP + '?for=furey#labels/gauge', 'furey');
  ok(await pg.locator('.rn-dialog[role=dialog][aria-modal=true]').count() === 1 && /A note for Cohl Furey/.test(await pg.locator('#rn-title').innerText()), 'the note for Cohl Furey opens');
  ok(await pg.locator('.rn-overlay').getAttribute('data-researcher') === 'furey', 'it says which group it is for');
  ok(await hash(pg) === '#labels/gauge' && await pg.locator('.tabbar [aria-selected="true"]').getAttribute('data-tab') === 'gauge', 'the page under the note keeps its address and tab');
  ok(await pg.evaluate(() => document.activeElement && document.activeElement.classList.contains('rn-dialog')), 'the focus moves into the note');
  const t = await pg.locator('.rn-dialog').innerText();
  ok(/checked/i.test(t) && /Standard, ours, open/.test(t) && /Where your eyes would help most/.test(t) && /What we have not read/.test(t) && /What this is not: a theory of nature/.test(t), 'the note has its sections and says it is not a theory of nature');
  await pg.locator('.rn-dialog a.rn-go', { hasText: 'Three generations' }).click(); await pg.waitForTimeout(300);
  ok(await pg.locator('.rn-overlay').count() === 0, 'a link closes the note');
  ok(await hash(pg) === '#furey/threegen' && await pg.locator('.tabbar [aria-selected="true"]').getAttribute('data-tab') === 'threegen', 'and opens the page and tab it names: ' + await hash(pg));
  ok(!/for=/.test(await search(pg)), '?for= is gone from the address: ' + await search(pg));
  await ctx.close(); }

// ---- 3. Escape, the close button, the backdrop; the reader stays where they were
for (const how of ['escape', 'x', 'backdrop', 'close']) {
  const [ctx, pg] = await open(1100, APP + '?for=gunn#equations/mirrors', 'close-' + how);
  ok(await pg.locator('.rn-overlay').count() === 1, `${how}: opens`);
  if (how === 'escape') await pg.keyboard.press('Escape');
  else if (how === 'x') await pg.locator('.rn-x').click();
  else if (how === 'backdrop') await pg.mouse.click(5, 400);
  else await pg.locator('.rn-btn', { hasText: 'Close and open the atlas' }).click();
  await pg.waitForTimeout(250);
  ok(await pg.locator('.rn-overlay').count() === 0, `${how}: closes`);
  ok((how === 'close' ? true : await hash(pg) === '#equations/mirrors') && !/for=/.test(await search(pg)), `${how}: the reader stays on the page (${await hash(pg)}) and ?for= is removed`);
  await ctx.close();
}

// ---- 4. aliases, the contact form, the Tab trap
const stub = pg => pg.route(/\/api\/contact(\?.*)?$/, r => r.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ token: 'tok-1', question: 'Test question: what is 1 XOR 2?', hint: 'binary' }) }));   // the contact form asks its route for a puzzle: answered by a stub, there is no server behind file://
{ const [ctx, pg] = await open(1100, HTTP_APP + '?for=eelbode#rule', 'alias', stub);
  ok(await pg.locator('.rn-overlay').getAttribute('data-researcher') === 'roelfs' && /Martin Roelfs and David Eelbode/.test(await pg.locator('#rn-title').innerText()), '?for=eelbode opens the note for Roelfs and Eelbode');
  let inside = true; for (let i = 0; i < 40; i++) { await pg.keyboard.press('Tab'); if (!await pg.evaluate(() => !!document.activeElement.closest('.rn-dialog'))) inside = false; }
  ok(inside, 'Tab stays inside the note (40 presses)');
  inside = true; for (let i = 0; i < 6; i++) { await pg.keyboard.press('Shift+Tab'); if (!await pg.evaluate(() => !!document.activeElement.closest('.rn-dialog'))) inside = false; }
  ok(inside, 'Shift+Tab stays inside too');
  await pg.locator('.rn-btn.main').click(); await pg.waitForTimeout(300);
  ok(await pg.locator('.rn-overlay').count() === 0 && await pg.locator('.cf-dialog').count() === 1, '"Write to the authors" closes the note and opens the contact form');
  await ctx.close(); }
{ const [ctx, pg] = await open(1100, APP + '?for=lasenby#rule', 'lasenby-title');
  const title = await pg.locator('#rn-title').innerText();
  ok(/Anthony Lasenby, Yi-Hsiung Hsu, Will Barker and Michael Hobson/.test(title) && !/Doran|Gull/.test(title), 'the title names the people written to, not those in copy: ' + title);
  await ctx.close(); }

// ---- 5. every note, desktop and phone: no error, no overflow, links lead to real tabs
for (const w of [1100, 375]) for (const r of RESEARCHERS.filter(x => x.note)) {
  const [ctx, pg] = await open(w, APP + '?for=' + r.slug + '#rule', `${r.slug}@${w}`);
  ok(await pg.locator('.rn-dialog').count() === 1, `${r.slug}@${w}: opens`);
  const fits = await pg.evaluate(() => { const d = document.querySelector('.rn-dialog'); return d.scrollWidth <= d.clientWidth + 1 && document.documentElement.scrollWidth <= window.innerWidth + 1; });
  ok(fits, `${r.slug}@${w}: nothing wider than the screen`);
  const hrefs = await pg.locator('.rn-dialog a.rn-go').evaluateAll(es => es.map(e => e.getAttribute('href')));
  ok(hrefs.length === r.hooks.length + r.note.path.length && hrefs.every(h => /^#[a-z]+(\/[a-z0-9]+)?$/.test(h)), `${r.slug}@${w}: ${hrefs.length} links, all hash routes`);
  if (w === 1100) for (const [k, h] of [hrefs[0], hrefs[hrefs.length - 1]].entries()) {
    await pg.locator(`.rn-dialog a.rn-go[href="${h}"]`).first().click(); await pg.waitForTimeout(250);
    const [p, s] = h.slice(1).split('/'), got = (await hash(pg)).slice(1).split('/');
    ok(got[0] === p && (!s || got[1] === s) && await pg.locator('.rn-overlay').count() === 0, `${r.slug}: the link ${h} opens ${await hash(pg)}`);
    if (k === 0) { await pg.goto(APP + '?for=' + r.slug + '#rule'); await pg.waitForTimeout(250); }
  }
  await ctx.close();
}

await b.close(); srv.close();
console.log(bad ? `${bad} FAILURES of ${n}` : `NOTES UI OK (${n} checks)`);
process.exit(bad ? 1 : 0);
