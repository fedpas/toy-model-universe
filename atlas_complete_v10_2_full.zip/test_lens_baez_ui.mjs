// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// test_lens_baez_ui.mjs: the Baez chapter (step 19, #lenses/baez) in a real browser. English and Italian × Young Learner, Physicist, Mathematician × 1100 and
// 375 px, dark and light: no page error, no horizontal scroll, the eyebrow, the in-page menu (every button has its target and jumps there, by mouse and by
// keyboard), every fold opens, each widget slot [data-widget] is there for exactly the audiences DECISIONS.md §2 gives (BW2, BW3 P/M; BW7 Young Learner and
// Physicist; the rest all), the honesty bar shows 26/11/2/9 and the matrix (P/M only) 48 rows and 9 gaps, the script box downloads baez_check.py byte for byte,
// the Young Learner sees no formula and no jargon outside a closed fold (the widgets are the B agent's and are scanned by its own test), and ?filter=known hides
// exactly the lines of known ground of the chapter, with the page notice counting them. The widgets are found by [data-widget] only, so this test passes with
// the stub BaezWidgets.jsx and with the real one.   Run: node test_lens_baez_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
import fs from 'node:fs'; import path from 'node:path';
import { chromium } from 'playwright';
import { PKG, DIST } from './paths.mjs';
import { SECTIONS, SECTIONS_YL, COPY } from './baezCopy.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
const APP = 'file://' + DIST + '/app.html', PY = fs.readFileSync(path.join(PKG, 'selfcheck/reports/baez_check.py'), 'utf8');
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const PROFS = ['Young Learner', 'Physicist', 'Mathematician'];
const WANT = { 'Young Learner': ['BW1', 'BW4', 'BW5', 'BW6', 'BW7', 'BaezWidgetsScript'], Physicist: ['BW1', 'BW2', 'BW3', 'BW4', 'BW5', 'BW6', 'BW7', 'BaezWidgetsScript'], Mathematician: ['BW1', 'BW2', 'BW3', 'BW4', 'BW5', 'BW6', 'BaezWidgetsScript'] };
const SLOT = { BW1: 'bz-w-family', BW2: 'bz-w-which', BW3: 'bz-w-ladder', BW4: 'bz-w-kepler', BW5: 'bz-w-papers', BW6: 'bz-w-ring', BW7: 'bz-w-madelung', BaezWidgetsScript: 'bz-w-script' };
const rows = MATRIX_ROWS.filter(r => r.src === 'baez'), cells = g => rows.reduce((a, r) => a + Object.values(r.cells).filter(x => x.grade === g).length, 0);
const LM = `${rows.length},${cells('E')},${cells('S')},${cells('A')},${rows.filter(r => !Object.keys(r.cells).length).length}`;
// the lists of test_yl_ui.mjs (read from its source, so that the two tests cannot drift apart), plus the words DECISIONS X0 keeps from the Young Learner
const SRC_YL = fs.readFileSync(path.join(PKG, 'test_yl_ui.mjs'), 'utf8');
const SYMBOLS = /const SYMBOLS = \/(.*)\/;\n/.exec(SRC_YL)[1], JARGON = /const JARGON = \/(.*)\/i;\n/.exec(SRC_YL)[1];
const X0 = String.raw`\bCl\(|\balgebr|\bradical|Frobenius|Jordan|Peirce|Casimir|Killing|\bLie\b|hypercharge|ipercarica|anomal|octonion|ottonion|Majorana|Weyl|Minkowski|Madelung|tripotent|Schl[äa]fli|Eisenstein|Hamming|\bFock\b|fermion|bivector|bivettor|spinor|Standard Model|Modello Standard|\bE[678]\b|[α-ωΑ-Ω]`;

async function open({ lang, prof, w, theme = 'dark', q = '' }) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce', acceptDownloads: true });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, prof]);
  const pg = await ctx.newPage(), tag = `${lang} ${prof} ${w}px ${theme}`, errs = [];
  pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push(m.text()); });
  await pg.goto(APP + '?theme=' + theme + (q ? '&' + q : '') + '#lenses/baez'); await pg.waitForTimeout(450);
  return { ctx, pg, tag, errs };
}
const overflow = pg => pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

// ---- 1. every language, audience and width
// BZ_QUICK=1 (for the mutation runs only): English at 1100 px; the full run is both languages at both widths
const QUICK = process.env.BZ_QUICK === '1';
for (const lang of QUICK ? ['en'] : ['en', 'it']) for (const prof of PROFS) for (const w of QUICK ? [1100] : [1100, 375]) {
  const theme = w === 375 ? 'light' : 'dark', { ctx, pg, tag, errs } = await open({ lang, prof, w, theme }), yl = prof === 'Young Learner', t = yl ? COPY.yl[lang] : COPY[lang];
  ok(await pg.locator('#ln-baez').count() === 1, `${tag}: the chapter is on #lenses/baez`);
  ok(await pg.evaluate(() => document.documentElement.getAttribute('data-theme')) === theme, `${tag}: theme ${theme}`);
  const eb = await pg.locator('#ln-baez .eyebrow').innerText();
  ok((lang === 'en' ? /STEP 19 OF 20/ : /PASSO 19 DI 20/).test(eb), `${tag}: eyebrow ${eb}`);
  ok((await pg.locator('#bz-h').innerText()).trim() === t.title, `${tag}: the title is the ${yl ? 'plain' : 'formal'} one in ${lang}`);
  // widgets: exactly the audiences DECISIONS gives, each in its slot
  const got = (await pg.locator('#ln-baez [data-widget]').evaluateAll(es => es.map(e => e.dataset.widget))).sort();
  ok(JSON.stringify(got) === JSON.stringify([...WANT[prof]].sort()), `${tag}: widgets ${got.join(',')} (want ${WANT[prof].join(',')})`);
  for (const x of WANT[prof]) ok(await pg.locator(`#${SLOT[x]} > [data-widget="${x}"]`).count() === 1, `${tag}: ${x} sits in #${SLOT[x]}`);
  // the in-page menu: one button per section, each with its target
  const secs = yl ? SECTIONS_YL : SECTIONS, gos = await pg.locator('#bz-menu [data-go]').evaluateAll(es => es.map(e => e.dataset.go));
  ok(JSON.stringify(gos) === JSON.stringify(secs.map(s => 'bz-' + s)), `${tag}: the menu lists the ${secs.length} sections in order`);
  for (const g of gos) ok(await pg.locator('#' + g).count() === 1, `${tag}: menu target #${g} exists`);
  // the honesty bar (all) and the matrix (P/M)
  ok(await pg.locator('#bz-bar [data-hb]').getAttribute('data-hb') === '26,11,2,9', `${tag}: the honesty bar counts 26, 11, 2, 9`);
  ok(await pg.locator('#lm-baez').count() === (yl ? 0 : 1), `${tag}: the matrix is shown to the Physicist and the Mathematician only`);
  if (!yl) ok(await pg.locator('#lm-baez [data-lm-counts]').getAttribute('data-lm-counts') === LM && LM.startsWith('48,') && LM.endsWith(',9'), `${tag}: the matrix has 48 rows and 9 gaps (${LM})`);
  ok(await overflow(pg) <= 1, `${tag}: no horizontal page scroll before the folds open (${await overflow(pg)} px)`);
  // the Young Learner: no formula and no jargon outside a closed fold (own words: the widgets are scanned by the B agent's test)
  if (yl) { const hits = await pg.evaluate(([S, J, X]) => { const re = [new RegExp(S, 'u'), new RegExp(J, 'i'), new RegExp(X, 'iu')], out = [];
      const clean = t => t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' ').replace(/\barXiv:[\d.]+(v\d+)?/gi, ' ');
      for (const root of [document.querySelector('#ln-baez'), document.querySelector('aside.glance')].filter(Boolean)) { const tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
        for (let x = tw.nextNode(); x; x = tw.nextNode()) { const el = x.parentElement, s = x.nodeValue.replace(/\s+/g, ' ').trim(); if (!s || !el || el.closest('[data-widget],style,script') || (el.closest('details:not([open])') && !el.closest('summary'))) continue;
          for (const r of re) { const m = r.exec(clean(s)); if (m) { out.push(m[0] + ' in: ' + s.slice(0, 80)); break; } } }
        for (const el of root.querySelectorAll('[aria-label],[title]')) { if (el.closest('[data-widget]') || el.closest('details:not([open])')) continue; for (const a of ['aria-label', 'title']) { const s = el.getAttribute(a); if (s) for (const r of re) { const m = r.exec(s); if (m) { out.push(m[0] + ' in @' + a + ': ' + s.slice(0, 60)); break; } } } } }
      return out; }, [SYMBOLS, JARGON, X0]);
    ok(hits.length === 0, `${tag}: Young Learner text has no formula or jargon outside a closed fold: ${hits.slice(0, 5).join(' | ')}`);
    ok(await pg.locator('#ln-baez details:not([open])').count() >= 1, `${tag}: the findings with their formulas wait in a closed fold for older readers`); }
  // every fold opens (nested ones after their parent), and the page still does not scroll sideways
  for (let i = 0; i < 40; i++) { const s = pg.locator('#ln-baez details:not([open]) > summary').first(); if (!(await s.count())) break; await s.click(); await pg.waitForTimeout(40); }
  ok(await pg.locator('#ln-baez details:not([open])').count() === 0, `${tag}: every fold opens`);
  const fids = await pg.locator('#ln-baez [data-finding]').evaluateAll(es => es.filter(e => e.getClientRects().length).map(e => e.dataset.finding)), wantF = yl ? ['J1', 'J2', 'J3', 'J7', 'J8', 'J9', 'J4', 'J5'] : ['J1', 'J2', 'J3', 'J6', 'J7', 'J8', 'J9', 'J4', 'J5', 'J10'];
  ok(JSON.stringify(fids) === JSON.stringify(wantF), `${tag}: with the folds open the findings ${wantF.join(' ')} are on the page (${fids.join(' ')})`);
  const pids = await pg.locator('#ln-baez [data-persp]').evaluateAll(es => es.filter(e => e.getClientRects().length).map(e => e.dataset.persp));
  ok(JSON.stringify(pids) === JSON.stringify(yl ? ['P1', 'P2', 'P3', 'P4', 'P7'] : ['P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7', 'P8']), `${tag}: the perspectives shown (${pids.join(' ')}; the Young Learner reads neither P5, P6, P8 nor J6, J10)`);
  ok(await overflow(pg) <= 1, `${tag}: no horizontal page scroll with every fold open (${await overflow(pg)} px)`);
  // the menu jumps: click the last button, the target comes to the top of the window and its heading takes the focus
  // a section in the middle comes to the top (just under the sticky bar); the last one, at the end of the page, comes into view
  for (const g of [gos[Math.floor(gos.length / 2)], gos[gos.length - 1]]) { await pg.evaluate(() => window.scrollTo(0, 0)); await pg.locator(`#bz-menu [data-go="${g}"]`).click(); await pg.waitForTimeout(250);
    const [top, bot, vh] = await pg.evaluate(id => { const r = document.getElementById(id).getBoundingClientRect(); return [r.top, r.bottom, window.innerHeight]; }, g), foc = await pg.evaluate(() => document.activeElement && document.activeElement.id);
    ok((g === gos[gos.length - 1] ? top >= -2 && top < vh : top >= -2 && top < 300) && foc === g + '-h', `${tag}: the menu jumps to #${g} (top ${Math.round(top)} px of ${vh}, focus on ${foc})`); }
  ok(errs.length === 0, `${tag}: no page or console error: ${errs.slice(0, 3).join(' | ')}`);
  await ctx.close();
}

// ---- 2. the keyboard reaches the menu and Enter jumps; the script box downloads the shipped file (EN and IT)
for (const [lang, prof] of [['en', 'Physicist'], ['it', 'Young Learner']]) {
  const { ctx, pg, tag, errs } = await open({ lang, prof, w: 1100 });
  await pg.locator('#bz-menu [data-go]').first().focus(); await pg.keyboard.press('Tab'); await pg.keyboard.press('Enter'); await pg.waitForTimeout(250);
  const second = await pg.locator('#bz-menu [data-go]').nth(1).getAttribute('data-go');
  ok(await pg.evaluate(() => document.activeElement && document.activeElement.id) === second + '-h', `${tag}: Tab and Enter on the menu move the focus to #${second}`);
  if (prof === 'Young Learner') await pg.locator('#bz-script details > summary').first().click();   // v10.2 complete: the Young Learner's script box sits in the fold "For older readers", like the category and Schuller chapters
  const [dl] = await Promise.all([pg.waitForEvent('download'), pg.locator('#bz-script [data-download="selfcheck/reports/baez_check.py"]').click()]);
  const file = await dl.path(), text = file ? fs.readFileSync(file, 'utf8') : '';
  ok(dl.suggestedFilename() === 'baez_check.py' && text === PY, `${tag}: the script box downloads baez_check.py byte for byte (${text.length} of ${PY.length} characters)`);
  ok((await pg.locator('#bz-script .ln-script').first().innerText()).includes('selfcheck/reports/baez_check.py'), `${tag}: the script box names the file`);
  ok(errs.length === 0, `${tag}: no error: ${errs.join(' | ')}`);
  await ctx.close();
}

// ---- 3. ?filter=known hides exactly the chapter's lines of known ground (standard and checked, neither ours nor open), and the notice counts them
for (const [lang, prof] of [['en', 'Physicist'], ['it', 'Mathematician'], ['en', 'Young Learner']]) {
  const { ctx, pg, tag, errs } = await open({ lang, prof, w: 1100, q: 'filter=known' });
  for (let i = 0; i < 40; i++) { const s = pg.locator('#ln-baez details:not([open]) > summary').first(); if (!(await s.count())) break; await s.click(); await pg.waitForTimeout(30); }
  await pg.waitForTimeout(200);
  const r = await pg.evaluate(() => { const known = e => { const k = [...e.querySelectorAll(':scope > div > .tag')].map(t => t.classList); const has = c => k.some(l => l.contains(c)); return has('standard') && has('checked') && !has('ours') && !has('open'); };
    const pts = [...document.querySelectorAll('main .eq-pt')], mine = [...document.querySelectorAll('#ln-baez .eq-pt')];
    const shown = e => getComputedStyle(e).display !== 'none';
    return { rf: document.querySelector('main')?.getAttribute('data-rf'), notice: Number(document.querySelector('.rf-notice')?.getAttribute('data-rf-hidden') ?? -1),
      known: mine.filter(known).length, knownShown: mine.filter(known).filter(shown).length, otherHidden: mine.filter(e => !known(e)).filter(e => !shown(e)).length, pageKnown: pts.filter(known).length, stripHidden: [...document.querySelectorAll('.page-tags > .tag')].filter(e => !shown(e)).length }; });
  ok(r.rf === 'known' && r.known > 0 && r.knownShown === 0, `${tag}: ?filter=known hides all ${r.known} lines of known ground of the chapter (${r.knownShown} still shown)`);
  ok(r.otherHidden === 0, `${tag}: no line with ours, open, or a single tag is hidden (${r.otherHidden})`);
  ok(r.notice === r.pageKnown + r.stripHidden && r.notice >= r.known, `${tag}: the page notice counts the hidden lines (${r.notice} = ${r.pageKnown} points on the page + ${r.stripHidden} entries of the page strip, ${r.known} in the chapter)`);   // the strip under the page introduction (lensesCopy.js) has one line of known ground
  ok(errs.length === 0, `${tag}: no error: ${errs.join(' | ')}`);
  await ctx.close();
}
await b.close();
console.log(`${n} checks`); console.log(bad ? `${bad} FAILURES` : 'ALL BAEZ CHAPTER UI TESTS PASS'); process.exit(bad ? 1 : 0);
