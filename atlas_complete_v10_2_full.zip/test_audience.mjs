// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);   // the files below are named relative to the package folder: this makes the test run from any folder (re-test T6-8)
import { SHORT, FOLD, level } from './audienceCopy.js';
import G from './gravityData.js';
import EQ from './equationsData.js';
let bad = 0; const ok = (c, m) => { if (!c) { bad++; console.log('FAIL', m); } };
const EQIDS = ['comm', 'dirac', 'coupling', 'ym', 'matter', 'grav1', 'grav2', 'mirrors', 'projective', 'forque', 'spin', 'spring', 'rigid', 'nullsurf'];
// every section lede and every page introduction has a short reading too
const IDS = [...EQIDS.slice(0, 9), 'maxwell', 'dictionary', 'threegen', 'findings', 'orth', 'demi', 'gosset', 'tally', ...['rule', 'atlas', 'maxwell', 'furey', 'shapes', 'equations', 'labels', 'lenses', 'map', 'researchers', 'ask'].map(p => 'page_' + p), 'forque', 'spin', 'spring', 'rigid', 'nullsurf'];
ok(level('Young Learner') === 0 && level('Physicist') === 1 && level('Mathematician') === 2, 'levels');
ok(Object.keys(FOLD.en).join() === Object.keys(FOLD.it).join(), 'fold labels');
for (const lang of ['en', 'it']) {
  ok(Object.keys(SHORT[lang]).join() === IDS.join(), `${lang}: ids`);
  for (const id of IDS) { const v = SHORT[lang][id]; ok(v.length === 2 && v.every(x => typeof x === 'string' && x.length > 60), `${lang} ${id}: two readings`); ok(v[0].length < 330, `${lang} ${id}: the learner reading is short (${v[0].length})`); ok(v[1].length < 460, `${lang} ${id}: the physicist reading is short (${v[1].length})`); }
  const all = JSON.stringify(SHORT[lang]);
  ok(!/undefined|NaN|\[object/.test(all), `${lang} placeholders`);
  for (const b of [/proves?\b.*generation/i, /explains? why three/i, /predict(s|ed)? (the|a)\b/i, /confirms?\b/i, /GUT\b/, /grand unif/i, /(?<!not a )\bwall\b|\breset/i, /\b1 (generators|terms|blades)\b/]) ok(!b.test(all), `${lang} banned ${b}`);
}
// the numbers in the readings agree with the data
ok(G.gv.ladder[4].riemann_independent === 20 && /20 in four dimensions/.test(SHORT.en.grav1[0]) && /20 a n = 4|20 in quattro/.test(SHORT.it.grav1[1] + SHORT.it.grav1[0]), 'Riemann count 20 at n = 4');
ok(/40 incidences/.test(SHORT.en.dirac[1]) && /40 incidenze/.test(SHORT.it.dirac[1]), 'Dirac incidences');
ok(JSON.stringify(EQ.eq.dirac).includes('40'), 'the data has the Dirac incidence count');
ok(/n = 3/.test(SHORT.en.coupling[1]), 'complex structure from n = 3');
for (const id of ['coupling', 'ym', 'matter', 'grav2']) ok(/Open|Aperti?/.test(SHORT.en[id][1] + SHORT.it[id][1]), `${id}: the physicist reading says what is open`);
for (const id of ['coupling', 'ym', 'matter', 'grav1', 'grav2']) ok(!/(?<!not )\bsolv/i.test(SHORT.en[id][0].replace(/we (do not|build no) /gi, '')) || /do not|no solutions|open/i.test(SHORT.en[id][0]), `${id}: the learner reading does not imply solutions`);
// v9, the Young Learner readings of equation steps 1–8 (the yl blocks of the copy files and the short readings): every reading exists in both
// languages with the same keys, Italian is not left in English, and no string, caption or label (each function is called over the values its
// picture can take) holds a formula symbol or a technical word from the lists of test_yl_ui.mjs, which are read from that file so they cannot drift
{
  const fs = await import('fs'), src = fs.readFileSync(new URL('./test_yl_ui.mjs', import.meta.url), 'utf8');
  const SYM = new RegExp(eval(src.match(/^const SYMBOLS = (\/.*\/);$/m)[1]).source, 'u'), JAR = eval(src.match(/^const JARGON = (\/.*\/i);$/m)[1]);   // the flags the browser test uses
  const [EC, KC, YC, MC, GC, RC] = (await Promise.all(['equations', 'coupling', 'yangmills', 'matter', 'gravity', 'mirrors'].map(f => import(`./${f}Copy.js`)))).map(m => m.default);
  const YL = l => ({ comm: EC[l].c.yl, dirac: EC[l].d.yl, coupling: KC[l].yl, ym: YC[l].yl, matter: MC[l].yl, grav1: GC[l].g1.yl, grav2: GC[l].g2.yl, mirrors: RC[l].m1.yl });
  const N = a => a.map(Number), T = (n, k) => n * (n - 1) / 2 * 2 ** (n - 2) / (k || 1);
  const CALLS = {
    comm: y => [...[0, 1, 2, 3, 4].map(p => y.cap(p)), y.edge('tx', 'ty', 'xy')],
    dirac: y => [y.terms(5)],
    coupling: y => [...N([3, 4, 5, 6, 7, 8]).map(n => y.ringCap(n)), y.ringNone(1), y.ringNone(2)],
    ym: y => [...[2, 3, 4, 5, 6, 7, 8].map(m => y.graphCap(m)), y.selCap('12', [['13', '23'], ['14', '24']]), y.selCap('12', [['13', '23']]), y.edge('12', '13', '23')],
    matter: y => [...[2, 3, 4, 5].map(m => y.picCap(m, m * (m - 1) / 2, T(m))), ...[6, 7, 8].map(m => y.picBig(m)), y.selCap('12', 1), y.selCap('12', 2)],
    grav1: y => [...[2, 3, 4, 5, 6, 7, 8].map(n => y.picCap(n)), y.classCap('all', 21), y.classCap('one', 1), y.classCap('one', 12), y.subCap('txyz', `tx ${y.with} yz, ty ${y.with} xz, tz ${y.with} xy`)],
    grav2: y => [...[2, 3, 4, 5, 6, 7, 8].map(n => y.picCap(n)), y.capSel('x', 'y', ['z']), y.capSel('x', 'y', ['z', 'u']), y.capSel('x', 'y', [])],
    mirrors: y => [...[2, 3, 4, 5, 6, 7, 8].map(n => y.picCap(n)), ...[2, 4, 5].flatMap(n => [...Array(1 << n).keys()].flatMap(S => { const c = y.corner(n, S); return [c.head, ...c.lines]; }))]
  };
  const leaves = v => (typeof v === 'string' ? [v] : Array.isArray(v) ? v.flatMap(leaves) : v && typeof v === 'object' ? Object.values(v).flatMap(leaves) : []);
  const en = YL('en'), it = YL('it');
  for (const id of Object.keys(CALLS)) {
    ok(en[id] && it[id] && Object.keys(en[id]).sort().join() === Object.keys(it[id]).sort().join(), `${id}: the Young Learner reading has the same keys in English and Italian`);
    for (const [l, y] of [['en', en[id]], ['it', it[id]]]) {
      const all = [...leaves(y), ...CALLS[id](y), SHORT[l][id][0]];
      ok(all.length > 8 && all.every(s => typeof s === 'string' && s.length && !/undefined|NaN|\[object/.test(s)), `${l} ${id}: the Young Learner strings are complete`);
      for (const s of all) { const m = SYM.exec(s) || JAR.exec(s); ok(!m, `${l} ${id}: a formula or technical word ("${m && m[0]}") in the Young Learner text "${s.slice(0, 90)}"`); }
    }
    for (const k of Object.keys(en[id])) if (typeof en[id][k] === 'string' && en[id][k].length > 20) ok(en[id][k] !== it[id][k], `${id}.${k}: the Italian reading is a translation`);
  }
  ok(/20 in four dimensions/.test(SHORT.en.grav1[0]) && /20 in quattro dimensioni/.test(SHORT.it.grav1[0]) && en.grav1.picCap(4).includes('21 − 1 = 20') && it.grav1.picCap(4).includes('21 − 1 = 20'), 'the Young Learner gravity count is the data count (21 boxes, 1 rule, 20 free)');
  ok(/opposite of the sign of its square/.test(SHORT.en.grav2[0]) && /opposto del segno del suo quadrato/.test(SHORT.it.grav2[0]), 'the cosmological sign stays opposite to the square of the extra direction');
  // T4-6 (fix round): the step page itself says it too, not only its short reading: the Young Learner points of Gravity II (gravityCopy.js g2.yl),
  // in English and Italian, give the sign of the push or pull of empty space as the opposite of the sign of the extra direction's square
  { const pt = l => (l === 'en' ? en : it).grav2.points.map(p => p[1]).filter(x => /extra direction|direzione in più/.test(x));
    ok(pt('en').length === 1 && /its sign is the opposite of the sign of that direction’s square/.test(pt('en')[0]) && !/its sign is the sign of/.test(pt('en')[0]), 'EN Gravity II step page (g2.yl.points): the sign is the opposite of the square of the extra direction');
    ok(pt('it').length === 1 && /il suo segno è l’opposto del segno del quadrato di quella direzione/.test(pt('it')[0]) && !/il suo segno è il segno del/.test(pt('it')[0]), 'IT Gravity II step page (g2.yl.points): il segno è l’opposto del quadrato della direzione in più'); }
}
const YL_COPY = ['maxwell', 'dictionary', 'threegen', 'findings', 'orth', 'demi', 'gosset'].map(id => [`learner reading ${id}`, [SHORT.en[id][0], SHORT.en[id][0], SHORT.en[id][0]], [SHORT.it[id][0], SHORT.it[id][0], SHORT.it[id][0]]]);
// v9 Young Learner: the plain copy of this page exists in English and Italian with the same keys, the Italian does not read as English, and it holds
// no formula symbol and no technical word (the patterns are read from test_yl_ui.mjs, the acceptance test of the young learner pages)
{ const src = fs.readFileSync('./test_yl_ui.mjs', 'utf8'), SYM = new RegExp(src.match(/^const SYMBOLS = \/(.*)\/;$/m)[1], 'u'), JAR = new RegExp(src.match(/^const JARGON = \/(.*)\/i;$/m)[1], 'i');
  const strs = (o, out = []) => { if (typeof o === 'string') out.push(o); else if (typeof o === 'function') { for (let a = 0; a <= 10; a++) { try { strs(o(a, a % 2 === 0, 3, 4, 5, 6), out); } catch { /* not defined for this argument */ } } } else if (o && typeof o === 'object') Object.values(o).forEach(v => strs(v, out)); return out; };
  const shape = o => typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).sort().map(k => [k, shape(o[k])])) : typeof o;
  for (const [name, en, it] of YL_COPY) {
    ok(en && it && JSON.stringify(shape(en)) === JSON.stringify(shape(it)), `${name}: plain copy in EN and IT with the same keys`);
    const se = strs(en), si = strs(it); ok(se.length >= 3 && se.length === si.length, `${name}: ${se.length} EN and ${si.length} IT plain strings`);
    for (const s of [...se, ...si]) { const m = SYM.exec(s.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json)\b/g, ' ')) || JAR.exec(s); ok(!m, `${name}: formula or technical word "${m && m[0]}" in the plain copy: ${s.slice(0, 90)}`); }
    se.forEach((s, i) => ok(s !== si[i] || !/[a-z]{4,}/i.test(s) || /^(checked|standard|ours|open)$/.test(s), `${name}: the Italian plain copy reads as English: ${s.slice(0, 80)}`));   // status keys are the same in both
  }
}
console.log(bad ? bad + ' FAILURES' : 'ALL AUDIENCE TESTS PASS'); process.exit(bad ? 1 : 0);
