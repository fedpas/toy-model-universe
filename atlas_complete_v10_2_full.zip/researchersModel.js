// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The logic of the "For researchers" page, kept apart from the component so that test_researchers.mjs runs it in node:
// the four flags, known ground, the filters of the claims table and of the translation matrix, the counts, the order of the errata.
export const FLAGS = ['standard', 'checked', 'ours', 'open'];
// known ground: standard AND checked, and neither ours nor open (a line that is standard only is a citation without a check: not known ground)
export const isKnown = f => f.includes('standard') && f.includes('checked') && !f.includes('ours') && !f.includes('open');
export const isPlainCitation = f => f.includes('standard') && !f.includes('checked') && !f.includes('ours') && !f.includes('open');
// the ground switch of the claims table: all | known (known ground only) | hide (everything except known ground: what the reader filter "known" hides)
// | hide+std (also the plain citations: the reader filter "known+std"). The tally rows of the equations page are navigation: never hidden by hide / hide+std.
export const GROUNDS = ['all', 'known', 'hide', 'hide+std'];
export const groundOfReaderFilter = v => (v === 'known' ? 'hide' : v === 'known+std' ? 'hide+std' : v === 'off' ? 'all' : null);
const fold = s => String(s || '').toLowerCase().normalize('NFKD').replace(/\p{M}/gu, '');
// the text a search reads: id, group, every line (English and Italian), the citation and the checking script
export const claimHaystack = (c, extra = '') => fold([c.id, c.group, c.groupName, extra, ...(c.en || []).map(l => l.text), ...(c.it || []).map(l => (l && l.text) || ''), c.standardRef, c.checkedBy].join(' \u0001 '));
// flags: the chosen flag chips; mode 'all' = a statement must carry every chosen flag, 'any' = at least one of them
export function claimMatches(c, { flags = [], mode = 'all', ground = 'all', group = '', q = '', hay } = {}) {
  const f = c.flags || [];
  if (group && c.group !== group) return false;
  if (flags.length && !(mode === 'any' ? flags.some(x => f.includes(x)) : flags.every(x => f.includes(x)))) return false;
  if (ground === 'known' && !isKnown(f)) return false;
  if ((ground === 'hide' || ground === 'hide+std') && !c.tally && (isKnown(f) || (ground === 'hide+std' && isPlainCitation(f)))) return false;
  if (q) { const h = hay ?? claimHaystack(c), words = fold(q).split(/\s+/).filter(Boolean); if (!words.every(w => h.includes(w))) return false; }
  return true;
}
// how many statements carry each flag (a statement can carry several), how many are known ground
export const flagCounts = list => {
  const n = { total: list.length, known: 0, standard: 0, checked: 0, ours: 0, open: 0 };
  for (const c of list) { for (const k of FLAGS) if ((c.flags || []).includes(k)) n[k]++; if (isKnown(c.flags || [])) n.known++; }
  return n;
};
// where a statement is shown: 'equations', 'equations/tally', 'equations#eq-tally' or { page, anchor | tab } (null while the claims file does not say)
export const whereOf = (p, pages) => {
  if (!p) return null;
  const o = typeof p === 'string' ? (([page, anchor]) => ({ page, anchor }))(p.split(/[#/]/)) : { page: p.page, anchor: p.anchor || p.tab };
  return o.page && (!pages || pages.includes(o.page)) ? { page: o.page, anchor: o.anchor || undefined } : null;
};
// ---- the translation matrix
export const GRADES = ['E', 'S', 'A'];
// src: '' or a source key; col: '' or a column key; grades: [] (all) or a subset of E, S, A. With a column chosen a row needs a cell there
// (of a chosen grade); with grades only, a cell of a chosen grade anywhere; with neither, every row (the gaps too).
export function rowMatches(r, { src = '', col = '', grades = [] } = {}) {
  if (src && r.src !== src) return false;
  const ok = x => x && (!grades.length || grades.includes(x.grade));
  if (col) return ok(r.cells[col]);
  if (grades.length) return Object.values(r.cells).some(ok);
  return true;
}
export const columnCounts = (rows, cols) => Object.fromEntries(cols.map(c => [c.key, Object.fromEntries(GRADES.map(g => [g, rows.filter(r => r.cells[c.key]?.grade === g).length]))]));
export const noneIn = (rows, col) => rows.filter(r => !r.cells[col]);
// the errata: newest first (date, then the higher number), never edited away
export const sortErrata = list => [...list].sort((a, b) => String(b.date).localeCompare(String(a.date)) || String(b.id).localeCompare(String(a.id), 'en', { numeric: true }));
