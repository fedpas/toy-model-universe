// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The widgets of the Schuller chapter (step 20, SchullerWidgets.jsx) without a browser: the engine (schullerEngine.js) against the stored fixture
// (selfcheck/reports/lens_sch_check.json, embedded as schullerWidgetData.js) for every number a widget shows; the check script runs and passes; the data
// module and the script mirror equal their files (selfcheck/regen_lens_schuller_widgets.sh writes both); the copy (schullerWidgetsCopy.js) in English
// and Italian: same shape, same tags, four flags only, the Young Learner strings free of formulas and technical words, no retired wording; every check
// id the widgets cite exists in a shipped script or is a theorem of researchersData.js; no e-mail address in the files of the widgets.
// Run: node test_lens_schuller_widgets.mjs     (SKIP_PY=1 skips the Python run)
import fs from 'fs';
import { PKG } from './paths.mjs'; process.chdir(PKG);
import { execSync } from 'child_process';
import * as E from './schullerEngine.js';
import { SWC } from './schullerWidgetsCopy.js';
import DATA from './schullerWidgetData.js';
import { LENS_SCH_PY } from './schullerWidgetsSelfcheckSource.js';
import { MATRIX_ROWS } from './translationMatrixData.js';
import { THEOREMS } from './researchersData.js';
let bad = 0, n = 0; const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const SCRIPT = 'selfcheck/reports/lens_sch_check.py', FIX = 'selfcheck/reports/lens_sch_check.json';

// ---- 0. the script, its fixture, the data module, the mirror
const fixture = JSON.parse(fs.readFileSync(FIX, 'utf8'));
ok(same(fixture, DATA), 'schullerWidgetData.js holds exactly selfcheck/reports/lens_sch_check.json (run selfcheck/regen_lens_schuller_widgets.sh)');
ok(LENS_SCH_PY === fs.readFileSync(SCRIPT, 'utf8'), 'schullerWidgetsSelfcheckSource.js mirrors lens_sch_check.py byte for byte');
const src = fs.readFileSync(SCRIPT, 'utf8');
ok(src.split('\n').length <= 500 && /SPDX-License-Identifier/.test(src.split('\n').slice(0, 4).join('\n')) && !/^\s*import\s+numpy|^\s*from\s+numpy/m.test(src), 'the script has the SPDX header, at most 500 lines, and needs no numpy');
let out = '';
if (!process.env.SKIP_PY) {
  try { out = execSync('python3 lens_sch_check.py --compare lens_sch_check.json', { cwd: 'selfcheck/reports', encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] }); } catch (e) { out = String(e.stdout || '') + String(e.stderr || e.message); }
  ok(/lens_sch_check: 12 ok, 0 failed/.test(out) && !/FAIL/.test(out), 'python3 lens_sch_check.py --compare passes: 11 checks and the fixture: ' + out.split('\n').filter(l => /FAIL|lens_sch_check:/.test(l)).join(' | '));
} else { console.log('note: SKIP_PY: the script was not run'); out = '' + src; }
const SCW_IDS = new Set([...(out || src).matchAll(/scw·(P\d[a-z]?)/g)].map(m => m[1]));
for (const id of ['P1', 'P1b', 'P1c', 'P2', 'P3', 'P3b', 'P4', 'P4b']) ok(SCW_IDS.has(id), `the script prints scw·${id}`);

// ---- 1. SW4, SW1: the map of cells and the symbol determinant (scw·P1, P1b)
const map = E.hypMap(2, 9);
ok(map.ok && map.hyperbolic === 15 && same(map.cells, DATA.p1.cells), 'hyperbolicity map n = 2..9: certificates and witnesses hold, 15 hyperbolic cells, every cell as stored');
ok(Object.entries(map.cells).every(([key, v]) => { const [k, d] = key.split(',').map(Number); return (v === 'hyperbolic') === (k === 1 || d === 1); }) && map.cells['2,2'] === 'ultrahyperbolic', 'hyperbolic exactly when Lorentzian; Cl(2,2) ultrahyperbolic');
ok(Object.keys(DATA.p1.det).length === 20, 'twenty stored determinant samples (every r = 0 cell with n <= 5)');
for (const [key, v] of Object.entries(DATA.p1.det)) { const [k, d] = key.split(',').map(Number), r = E.symbolDet(E.sigOf(k, d), v.mom, v.m); ok(r.ok && String(r.det) === v.det && r.Q === v.Q && r.exp === v.exp && same(v.mom, DATA.default.mom.slice(0, k + d)) && v.m === DATA.default.m, `det(P - m) on Cl(${key}) at the default input: ${r.det} = (m² − Q)^${r.exp}, as stored`); }
for (const [k, d] of [[1, 3], [3, 1], [2, 2], [0, 5], [2, 3]]) for (const mom of [[1, -1, 2, 0, 1], [3, 0, -2, 1, -1]]) for (const m of [0, 2]) ok(E.symbolDet(E.sigOf(k, d), mom.slice(0, k + d), m).ok, `det(P − m) = (m² − Q)^(2^(n−1)) on Cl(${k},${d}) at another input`);
ok(E.symbolDet(E.sigOf(1, 2, 1), [2, 1, 1, 3], 1).det === E.symbolDet(E.sigOf(1, 2, 1), [2, 1, 1, 0], 1).det && E.symbolDet(E.sigOf(1, 2, 1), [2, 1, 1, 3], 1).ok, 'a momentum along a null generator never enters the determinant (Cl(1,2,1))');
for (const [eps, row] of Object.entries(DATA.p1b)) {
  const e = +eps, x = E.extraGen(E.sigOf(1, 3), [row.E, row.p, 0, 0], row.m, e), tot = e === 0 ? [1, 3, 1] : e < 0 ? [1, 4, 0] : [2, 3, 0];
  ok(x.ok && x.square === 0 && row.shell_zero && same(row.total, tot) && row.kind === (e === 0 ? 'null' : E.waveKind(tot[0], tot[1])), `extra generator of square ${eps} on Cl(1,3): the stored shell point (${row.E}; ${row.p}; ${row.m}) has (P + m f)² = 0, total Cl(${tot}), ${row.kind}`);
}
for (const e of [-1, 0, 1]) ok(E.extraGen(E.sigOf(2, 2), [1, 2, -1, 3], 2, e).ok && E.extraGen(E.sigOf(1, 1), [3, -2], 1, e).ok, `(P + m f)² = Q + eps m² and det = (Q + eps m²)^(2^n) for eps = ${e}`);
ok(same(E.squareVec(E.sigOf(1, 3), [1, 2, 0, 1]), { scalar: -4, rest: 0 }), 'P·P by the bit rule is the scalar Q (Cl(1,3), default input: −4)');

// ---- 2. SW2: one table, three squares (scw·P1c)
ok(Object.keys(DATA.p1c).length === 36, '36 stored tables (every choice of squares on 2 and 3 generators)');
for (const [key, v] of Object.entries(DATA.p1c)) { const sq = key.split(',').map(Number), s = E.tableStats(sq); ok(same(s, v), `table ${key}: ${JSON.stringify(s)} as stored`); }
{ const T = E.productTable([0, 0, 0]); ok(T[3][4].sign === 1 && T[4][3].sign === 1 && T[1][2].sign === 1 && T[2][1].sign === -1 && T[3][1].sign === 0, 'the all-null table is the wedge: e1e2 = +e12, e2e1 = −e12, e12 e1 = 0, e12 e3 = e3 e12 (even times odd)'); }

// ---- 3. SW5: Floquet (scw·P2)
const counts = { band: 0, edge: 0, scalar: 0, gap: 0 };
for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) for (let c = -3; c <= 3; c++) for (let d = -3; d <= 3; d++) if (a * d - b * c === 1) counts[E.sl2Class([[a, b], [c, d]]).cls]++;
ok(same(counts, DATA.p2.counts), 'SL(2,Z) with entries in [−3,3] by class: ' + JSON.stringify(counts) + ' as stored');
for (const [name, v] of Object.entries(DATA.p2.presets)) { const c = E.sl2Class(v.M); ok(c.cls === v.class && c.X2 === v.X2 && c.half_trace === v.half_trace && same(E.traceSeq(v.M, 6), v.traces), `preset ${name}: ${c.cls}, X² = ${c.X2}, ½ tr = ${c.half_trace}, traces as stored`); }
const PW = { T: ['T'], S: ['S'], ST: ['S', 'T'], cat: ['T', 'U'], minusT: ['S', 'S', 'Ti'], I: [], minusI: ['S', 'S'] };
for (const [name, w] of Object.entries(PW)) ok(same(E.wordMatrix(w), DATA.p2.presets[name].M), `the widget's word for the preset ${name} gives its matrix`);
ok(E.sl2Class([[1, 0], [0, 1]]).cls === 'scalar' && E.sl2Class([[-1, 0], [0, -1]]).cls === 'scalar' && E.sl2Class([[1, 1], [0, 1]]).cls === 'edge', 'M = ±I is not an edge (X = 0); T is');
const near = (a, b) => a.length === b.length && a.every((x, i) => Math.abs(x - b[i]) < 1e-7);
ok(near(E.bandEdges(e => E.halfTraceSteps(e, E.G5_CELL), 0.05, 90, 18000), DATA.p2.g5_edges) && DATA.p2.g5_edges.length === 7 && same(E.G5_CELL, DATA.p2.g5_cell), 'the two-step potential of fibre G5e: 7 band edges, live = stored to 1e−7');
let combOk = 0; for (const c of DATA.p2.comb) if (near(E.bandEdges(e => E.halfTraceComb(e, c.g, c.l), ...DATA.p2.comb_E), c.edges)) combOk++;
ok(combOk === 119 && DATA.p2.comb.length === 119, `Dirac comb: the band edges of all 119 slider positions, live = stored to 1e−7 (${combOk})`);
for (const [En, g, l] of [[8, 2, 1], [-3, -2, 1.5], [30, 4, 0.5], [0.5, 0, 2]]) { const cc = E.combCell(En, g, l); ok(Math.abs(cc.half - cc.closed) < 1e-12 && cc.xsKick.s === 0 && (g === 0 ? cc.xsKick.Xnorm === 0 : cc.xsKick.Xnorm > 0) && Math.sign(cc.xsFlight.s) === (En > 0 ? -1 : 1) * (cc.xsFlight.s === 0 ? 0 : 1), `Dirac comb at E = ${En}, g = ${g}, l = ${l}: the bit-rule product of the pieces has the closed-form scalar part; the kick squares to 0, the flight has the sign of its class`); }

// ---- 4. SW3: outside and inside (scw·P3, P3b)
ok(same(E.gammas().map(g => g[0]), DATA.p3.gamma_words), 'the eight gammas: the same Kronecker words as the script (and fibre_check.py G3)');
for (const row of DATA.p3.rows) { const r = E.outsideInside(row.k); ok(r.comm && Object.keys(row).every(f => r[f] === row[f]), `k = ${row.k}: ` + Object.keys(row).map(f => `${f} ${r[f]}`).join(', ')); }
ok(DATA.p3.rows.every(r => r.outside * r.inside === 256 && r.base_type === r.fibre_type), 'outside × inside = 256 and the same type on both sides, every k');
ok(Object.keys(DATA.p3b).length === 34, '34 stored signatures with n <= 4');
for (const [key, v] of Object.entries(DATA.p3b)) { const [p, q, r] = key.split(',').map(Number), x = E.leftRight(p, q, r); ok(x.rel && x.rank_LRt === v.rank_LRt && x.rank_LR === v.rank_LR && x.centre === v.centre && same(x.Rt_eq_L, v.Rt_eq_L), `left and right on Cl(${key}): ranks ${x.rank_LRt}, ${x.rank_LR}, centre ${x.centre}, R′ = L for ${JSON.stringify(x.Rt_eq_L)}`); }

// ---- 5. SW6, SW7: seats, Pauli strings, magnets (scw·P4, P4b)
ok(same(E.byNumber(), DATA.p4.by_number) && same(DATA.p4.by_number, [1, 3, 3, 1]), 'three seats: 1, 3, 3, 1');
for (const [key, v] of Object.entries(DATA.p4.put)) { const [a, k] = key.split(',').map(Number); ok(same(E.putParticle(a, k), v), `putting a particle into seat ${k + 1} of the pattern ${a}: ${JSON.stringify(v)}`); }
for (let a = 0; a < 8; a++) for (let k = 0; k < 3; k++) if (a >> k & 1) { const t = E.takeParticle(a, k); ok(t && same(E.putParticle(t[0], k), [a, t[1]]), `taking the particle out of seat ${k + 1} of ${a} is the inverse of putting it in`); }
const F = E.fockMatrices(); ok(F.car && F.excl && F.plusMinus && F.numberOk, 'Fock: {eps_k, iota_l} = delta, eps² = 0, (eps ± iota)² = ±1, N = popcount');
for (const [key, v] of Object.entries(DATA.p4.pass)) { const [u, w] = key.split('>'); ok(E.passProb(u, w) === v, `magnet ${u} then ${w}: ${v}`); }
ok(same(E.magnets(['z', 'x', 'z']).steps, DATA.p4.sequence.slice(1)) && E.magnets(['z', 'x', 'z']).total === 0.25 && E.passProb('z', 'z') === DATA.p4.sequence[0], 'z, x, z: 1/2 then 1/2, a quarter in all; z, z: 1');
{ const z = E.zxCommute(); ok(!z.same && z.e3e1[1] === -1 && z.e1e3[1] === 1, 'P_z P_x ≠ P_x P_z; e3 e1 = −e13, e1 e3 = +e13'); }
const PT = E.pauliTable(); ok(Object.entries(DATA.p4b).every(([a, v]) => PT[a].pauli === v.pauli && PT[a].phase === v.phase && PT[a].square === v.square && PT[a].hermitian === (v.square === 1)), 'two qubits: 16 Pauli strings, phases and squares as stored; Hermitian iff square +1');

// ---- 6. SW1: the grades of the stones are the best grades of their rows of the matrix
const best = id => { const r = MATRIX_ROWS.find(x => x.src === 'schuller' && x.id === id); if (!r) return null; const g = Object.values(r.cells).map(c => c.grade); return g.includes('E') ? 'E' : g.includes('S') ? 'S' : g.includes('A') ? 'A' : '-'; };
ok(E.STONES.map(s => s.grade).join('') === 'SEESSSA', 'the stones are graded S, E, E, S, S, S, A (the figure, not F6)');
// the first row of a stone is the one the figure grades (stone 7: C7, analogy; its second row C8, Klein-Gordon to Einstein-Hilbert, is structural; stone 3: C12 is the gap)
for (const s of E.STONES) { const g = s.rows.map(best); ok(g.every(Boolean) && g[0] === s.grade, `stone ${s.id} (${s.grade}): rows ${s.rows.join(', ')} have best grades ${g.join(', ')}; the first is the stone's grade`); }

// ---- 7. the copy: shape, tags, Young Learner words, retired wording
const shape = o => (typeof o === 'function' ? 'f' : Array.isArray(o) ? o.map(shape) : o && typeof o === 'object' ? Object.fromEntries(Object.keys(o).map(k => [k, shape(o[k])])) : typeof o);
ok(same(shape(SWC.en), shape(SWC.it)), 'English and Italian copy have the same shape');
const FOUR = ['standard', 'checked', 'ours', 'open'];
const caps = []; for (const L of ['en', 'it']) for (const w of Object.keys(SWC[L]).filter(k => /^sw\d$/.test(k))) for (const v of ['yl', 'pm']) (SWC[L][w][v].caps || []).forEach((c, i) => caps.push([L, w, v, i, c]));
// 36 since the English-consistency check: the caption of SW6 that said "ours ... is standard" in one line became two lines (ours / standard), one tag set each (LNS-133)
ok(caps.length === 2 * 36, 'the tagged captions: 36 per language (' + caps.length + ')');
for (const [L, w, v, i, [tags, text]] of caps) {
  const fl = tags.split(/\s+/); ok(fl.length && fl.every(f => FOUR.includes(f)) && new Set(fl).size === fl.length, `${L} ${w}.${v}.caps[${i}]: four flags only (${tags})`);
  const other = SWC[L === 'en' ? 'it' : 'en'][w][v].caps[i]; ok(other && other[0] === tags, `${L} ${w}.${v}.caps[${i}]: the same tags in both languages`);
  if (fl.includes('ours')) ok(!/\bderiv(ed|ation)\b|\bderivat[oaie]\b/i.test(text), `${L} ${w}.${v}.caps[${i}]: a line tagged ours says nothing like "derived"`);
}
// what the Young Learner sees: the yl blocks (functions called with sample arguments), the badge words, the number words; the lists of test_yl_ui.mjs
const SYMBOLS = /[∇∂∫∑∏⊗⊕⊙≅≈≠≤≥∈∉∀∃⟨⟩†ℝℂℍ𝕆𝔹𝕊𝕍ℤℕ→↔⇒⇔√∞∧∨⊂⊃∪∩⊥ωψφθΩλμνρσκτΣΔΓΛΠΦΨΘαβγδεζηιξπχ]|[₀-₉⁰¹⁴-⁹]|\^|[A-Za-z0-9)\]}]_[A-Za-z0-9{(]|\bCl\(|\bM\d*\(|\bso\(|\bsu\(|\bSU\(|\bSO\(|\bU\(\d|\\[a-zA-Z]+|\bdet\b|\bTr\b|\bP[₀-₉]|\be[₀-₉]|\be\d{2,}\b|\[\s*\d+\s*,\s*[+−-]?\d+\s*\]|\bB\+F\b|\bB[−-]F\b|\[\s*[A-Za-z]{1,4}\d*\s*,\s*[A-Za-z]{1,4}\d*\s*\]\s*=|[²³ⁿ±½⅓¼¾ℏ]|\b[a-zA-Z]\s*=\s*[−+-]?[a-zA-Z0-9]|\b[b-df-hj-np-tv-zB-DF-HJ-NP-TV-Z]\s?[−±]\s?\d|\d\s?\/\s?\(/;
const JARGON = /isomorph|idempotent|pseudoscalar|bivector|trivector|multivector|\bPeirce\b|\bWitt\b|involution|semisimple|eigen(value|vector)|Lagrangian|Hamiltonian|manifold|holonomy|cohomolog|automorphism|Casimir|Lie algebra|radical ideal|zero divisor|tensor|commutator|anticommut|orthoplex|demicube|polytope|\bincidence|Clifford algebra|matrix ring|\bPGA\b|metric signature|quadratic form|Killing|geodesic|Schwarzschild|Kerr\b|covariant|gauge|Hodge|spinor|pointor|rotor|versor|motor\b|forque|axiom|assiom|quaternion/i;
const call = (f, a) => { try { return f(...a); } catch { return null; } };
const strings = (o, args) => (typeof o === 'string' ? [o] : typeof o === 'function' ? args.flatMap(a => strings(call(o, a), args)) : Array.isArray(o) ? o.flatMap(x => strings(x, args)) : o && typeof o === 'object' ? Object.values(o).flatMap(x => strings(x, args)) : []);
const ARGS = [[1, 2, true], [3, 'a box', 'passes'], [0, 16, 16, 'spinning numbers'], ['101', 2], [2, '110'], [2, null], ['1/2', 'half pass', '25%']];
for (const L of ['en', 'it']) {
  const yl = [...Object.keys(SWC[L]).filter(k => /^sw\d$/.test(k)).flatMap(w => strings(SWC[L][w].yl, ARGS)), ...strings(SWC[L].badge, []), ...strings(SWC[L].typesYl, []), SWC[L].script.yl, SWC[L].checks];
  const hits = yl.filter(s => SYMBOLS.test(s) || JARGON.test(s));
  ok(yl.length > 60 && hits.length === 0, `${L}: the ${yl.length} Young Learner strings carry no formula and no technical word: ` + hits.slice(0, 4).join(' | '));
}
const ALL = JSON.stringify(SWC, (k, v) => (typeof v === 'function' ? String(v) : v)), JSX = fs.readFileSync('SchullerWidgets.jsx', 'utf8'), ENG = fs.readFileSync('schullerEngine.js', 'utf8');
const RETIRED = [[/Hodge star\s*=\s*XOR|XOR (with|con) 1+…1|XOR (with|con) 11…1/i, 'Hodge star = XOR with 1…1 (E-009)'], [/\bexplains?\b|\bspiega\b/i, 'explains'], [/\bconserv(ed|ata|ato)\b/i, 'conserved'], [/particle to antiparticle|charge conjugation|coniugazione di carica/i, 'particle to antiparticle'],
  [/quadric of entangled|quadrica degli stati entangled/i, 'Cl(2,2) as the quadric of entangled states'], [/Born rule is the Frobenius/i, 'Born rule = Frobenius form'], [/exactly two ladders|esattamente due scale|first excluded|prima esclusa/i, '"exactly two ladders" / "first excluded"'],
  [/three 8s|tre 8|Golay|before, now, after|prima, ora, dopo|quark row/i, 'F14 numerology'], [/fifth home|quinta casa/i, 'F13 "fifth home"'], [/mass is a fibre momentum|la massa è un impulso della fibra/i, 'F12 headline'], [/never names?\b|missing step|passo mancante/i, 'F1/P1 wording'],
  [/is Furey.s End\(V\)|the type of Cl\(1,3\)/i, 'F10/F11 wording'], [/\bderived\b/i, 'derived'], [/left \/ right|sinistra \/ destra/i, 'left / right for the Young Learner']];
for (const [re, what] of RETIRED) ok(!re.test(ALL) && !re.test(JSX), 'no retired wording: ' + what);
for (const s of strings(SWC, ARGS).filter(x => /Hodge/.test(x))) ok(/r = 0|E-009/.test(s), 'every mention of the Hodge star says r = 0 or E-009: ' + s.slice(0, 80));
ok(!JSON.stringify(strings(SWC.en.sw3.yl, ARGS)).match(/\b(left|right)\b/i) && !JSON.stringify(strings(SWC.it.sw3.yl, ARGS)).match(/sinistr|destr/i), 'the Young Learner reads outside / inside, never left / right');

// ---- 8. every check id the widgets cite exists
const read = f => fs.readFileSync(f, 'utf8'), IDS = { bridge: read('selfcheck/reports/bridge_check.py'), fibre: read('selfcheck/reports/fibre_check.py'), qm: read('selfcheck/reports/bridge_check_qm.py') };
const has = (pre, id) => (pre === 'scw' ? SCW_IDS.has(id) || [...SCW_IDS].some(x => x.startsWith(id)) : new RegExp(`chk\\('${id}[a-z]?'`).test(IDS[pre]));
const cited = new Set(); const TXT = ALL + JSX + ENG;
for (const m of TXT.matchAll(/\b(bridge|fibre|qm|scw)·([A-Z]\d+[a-z]?)((?:\s*[–,]\s*(?:[A-Z]?\d+[a-z]?|[a-z]))*)/g)) {
  const pre = m[1], first = m[2]; cited.add(pre + '·' + first);
  for (const part of m[3].split(/[,]/)) { const r = part.trim(); if (!r) continue;
    const range = /^–\s*(.+)$/.exec(r) || /^(.*)–(.*)$/.exec(r); if (range) { const end = range[range.length - 1].trim(); const L1 = /^([A-Z])(\d+)([a-z]?)$/.exec(first); if (/^[a-z]$/.test(end) && L1) for (let c = L1[3].charCodeAt(0); c <= end.charCodeAt(0); c++) cited.add(`${pre}·${L1[1]}${L1[2]}${String.fromCharCode(c)}`); else { const L2 = /^([A-Z])(\d+)([a-z]?)$/.exec(end); if (L1 && L2) for (let k = +L1[2]; k <= +L2[2]; k++) cited.add(`${pre}·${L1[1]}${k}${k === +L2[2] ? L2[3] : ''}`); } }
    else if (/^[A-Z]\d+[a-z]?$/.test(r)) cited.add(pre + '·' + r); }
}
for (const c of [...cited].sort()) { const [pre, id] = c.split('·'); ok(has(pre, id), `the cited check ${c} exists in its script`); }
ok(cited.size > 30, `${cited.size} check ids cited`); if (process.env.VERBOSE) console.log('cited:', [...cited].sort().join(' '));
for (const m of new Set([...TXT.matchAll(/Thm (T\d+)/g)].map(x => x[1]))) ok(THEOREMS.some(t => t.id === m), `the cited theorem ${m} is in researchersData.js`);
// ---- 9. the widget contract and the files
for (const w of ['SW1', 'SW2', 'SW3', 'SW4', 'SW5', 'SW6', 'SW7']) ok(new RegExp(`export function ${w}\\(\\{ lang = 'en', profile = '[A-Za-z ]+' \\}\\)`).test(JSX) && JSX.includes(`<Card id="${w}"`), `${w}: exported with props { lang, profile }, root .ln-card[data-widget="${w}"]`);
ok(/export function SchullerWidgetsScript\(/.test(JSX) && /data-widget="SchullerWidgetsScript"/.test(JSX) && /className="ln-card scw" data-widget=\{id\}/.test(JSX), 'SchullerWidgetsScript exported; every root is .ln-card with its data-widget');
for (const f of ['SchullerWidgets.jsx', 'schullerEngine.js', 'schullerWidgetsCopy.js', 'schullerWidgetData.js', 'schullerWidgetsSelfcheckSource.js', SCRIPT, FIX, 'selfcheck/regen_lens_schuller_widgets.sh', 'claimsLocators_lnsw.json', 'test_lens_schuller_widgets_ui.mjs'])
  ok(fs.existsSync(f) && !/[\w.+-]+@[\w-]+\.[\w.-]+|mailto:/i.test(read(f)), `${f}: present, no e-mail address`);
ok(!/localStorage|fetch\(|XMLHttpRequest|https?:\/\/(?!polyformproject)/.test(JSX + ENG), 'the widgets make no external request and use no localStorage');
console.log(`${n} checks, ${bad} failed`); console.log(bad ? `${bad} FAILURES` : 'ALL SCHULLER WIDGET TESTS PASS'); process.exit(bad ? 1 : 0);
