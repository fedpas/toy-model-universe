// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Checks of label_bench.html: build determinism, no external request, the page runs the real kernels, the correctness numbers equal node's, the scenarios run (worker and main thread),
// verdict words, the chart, export and compare, layout at 1100 and 375 px in light and dark, Stop, and (1.2.0) the ours-against-the-standard views: the roles table, the At a glance table
// (recomputed here from the raw timings), the folds and the short texts; and (1.2.1, audit fixes) the verdict against a hand-worked table, the frame tagged standard, the product's
// reused-buffer route, the recorded kernel fingerprint, the README tables against the stored run, the layout at 320 px; and (1.2.2, re-test fixes) the shipped page against a fresh build,
// the README roles table against the page's, no machine figure typed in README prose, the exact edge of the verdict, the coarse-timer note, an interrupted calibration and a pair
// that cannot be judged. Prints LABEL BENCH OK or exits 1.
//   node test_label_bench.mjs            (LB_FINAL=1: also fail while the stored run predates 1.2.1, i.e. while anything says "regeneration pending")
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { chromium } from 'playwright';

const here = path.dirname(fileURLToPath(import.meta.url));
const PAGE = path.join(here, 'label_bench.html'), URL_ = pathToFileURL(PAGE).href;
const SHOTS = process.env.LB_SHOTS || path.join(os.tmpdir(), 'label_bench_shots'); fs.mkdirSync(SHOTS, { recursive: true });
const FINAL = !!process.env.LB_FINAL;      // final mode (selfcheck/regen_bench.sh): fail while the stored run predates 1.2.1 and anything still says "regeneration pending"
const fails = []; let nchecks = 0;
const check = (name, cond, detail = '') => { nchecks++; if (!cond) { fails.push(name + (detail ? ': ' + detail : '')); console.log('FAIL  ' + name + (detail ? ': ' + detail : '')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');

// ---------------------------------------------------------------- 1. the build
// the page as shipped must be the page the sources build (re-test T5-7b: a stale label_bench.html, e.g. one embedding an older reference run, used to pass because the test rebuilds first)
const shippedSha = fs.existsSync(PAGE) ? sha(PAGE) : 'missing';
const buildOut = execFileSync('node', [path.join(here, 'build_label_bench.mjs')], { encoding: 'utf8' });
const h1 = sha(PAGE); const size = fs.statSync(PAGE).size;
execFileSync('node', [path.join(here, 'build_label_bench.mjs')], { stdio: 'pipe' });
check('rebuilding gives an identical file (deterministic)', sha(PAGE) === h1);
check('the shipped label_bench.html is what the sources build (node build_label_bench.mjs; nothing stale)', shippedSha === h1, 'shipped ' + shippedSha.slice(0, 12) + ', built ' + h1.slice(0, 12));
// the kernel fingerprint the build computes is the one the README records for this version (L4-009: a changed kernel must be recorded, with the reason)
const KHASH = (/kernel fingerprint ([0-9a-f]{12})/.exec(buildOut) || [])[1], README_LB = fs.readFileSync(path.join(here, 'README_label_bench.md'), 'utf8');
check('the build reports version 1.2.2 and a kernel fingerprint', /version 1\.2\.2,/.test(buildOut) && !!KHASH, buildOut.trim());
check('README_label_bench.md records the fingerprint of 1.2.2 as unchanged from 1.2.1', README_LB.includes(`**1.2.2** (kernel fingerprint **${KHASH}**, unchanged from 1.2.1`), 'build: ' + KHASH);
check('README_label_bench.md records this fingerprint for 1.2.1 and the old one of 1.2.0', README_LB.includes(`**1.2.1** (kernel fingerprint **${KHASH}**; 1.2.0 was 8b111dc05052)`), 'build: ' + KHASH);
check('README_label_bench.md no longer says that v1.1.1 is kept in the package, and says it is not', !README_LB.includes('v1.1.1 is kept unchanged next to it.') && /no 1\.1\.1 page is in the package/.test(README_LB));
// the README tables are generated from the stored run and still match it (G35 / L4-004, L4-005); in final mode the stored run must have the 1.2.1 rows
{ let out = '', ok = true; try { out = execFileSync('node', [path.join(here, 'selfcheck', 'bench_tables.mjs'), ...(FINAL ? ['--final'] : [])], { encoding: 'utf8' }); } catch (e) { ok = false; out = String(e.stdout || '') + String(e.stderr || ''); }
  check('selfcheck/bench_tables.mjs: the README tables equal what selfcheck/bench_labels.json gives' + (FINAL ? ', and nothing is pending (final)' : ''), ok, out.trim().split('\n').filter(l => /FAIL/.test(l)).join(' | '));
  if (/regeneration pending/.test(out) && !FINAL) console.log('NOTE  regeneration pending: the stored run predates 1.2.1 (sh selfcheck/regen_bench.sh on an idle machine; LB_FINAL=1 makes this a failure)'); }
// no typed machine-dependent figure left where the audit found them (L4-005, L4-008)
for (const [f, bad] of [['README_label_bench.md', /2\.1x to 2\.4x|2\.7x to 3\.2x|2\.2, 1\.5, 1\.3|2\.3 us|0\.06 us|3\.24x/], ['README_update_pgadyn.md', /\| 0\.67 \| 0\.95 \||2\.3 microseconds|13\.9 to 14\.6x|0\.64 to 0\.71x/], ['README_update_v7.md', /→ 0\.26×, 0\.13×/], ['pgaEngine.js', /2\.3 us|0\.06 us/]])
  check('no untraceable figure typed in ' + f, !bad.test(fs.readFileSync(path.join(here, f), 'utf8')));
// no machine figure typed into README prose: outside the generated blocks there is no ratio like "14.5×" or "2.9x at n = 4" (re-test T5-7c; the tables are generated from the stored run)
for (const f of ['README_label_bench.md', 'README_update_pgadyn.md', 'README_update_v7.md']) {
  const prose = fs.readFileSync(path.join(here, f), 'utf8').replace(/<!-- bench_tables:(\w+) begin -->[\s\S]*?<!-- bench_tables:\1 end -->/g, ''), hit = prose.match(/.{0,40}(\d(\.\d+)?×|\d(\.\d+)?x at n\b|× at n\b).{0,20}/);
  check('no machine figure typed in the prose of ' + f + ' (outside the generated blocks)', !hit, hit && hit[0]);
}
check('selfcheck/regen_bench.sh uses only paths inside the package, stops on error, and rebuilds the page and runs the test', (() => { const s = fs.readFileSync(path.join(here, 'selfcheck', 'regen_bench.sh'), 'utf8'); return !/\/home\/|\/tmp\//.test(s) && /^set -e$/m.test(s) && /cd "\$\(dirname "\$0"\)"/.test(s) && /build_label_bench\.mjs/.test(s) && /test_label_bench\.mjs/.test(s) && /--dry/.test(s); })());
check('size under 300 KB', size < 300 * 1024, size + ' bytes');
const html = fs.readFileSync(PAGE, 'utf8');
const urls = [...html.matchAll(/https?:\/\/[^\s'"<>)]+/g)].map(m => m[0]);
const LIC = 'https://polyformproject.org/licenses/noncommercial/1.0.0';
check('the only URLs in the file are the SVG namespace and the licence address', urls.every(u => u === 'http://www.w3.org/2000/svg' || u === LIC), urls.join(' '));
// the licence address is text for a reader: it may stand in a comment or in one link the reader clicks; nothing may load it
const esc = LIC.replace(/[.*+?^${}()|[\]\\\/]/g, '\\$&'), noComments = html.replace(/(^|[\s;])\/\/[^\n]*|<!--[\s\S]*?-->/gm, '').replace(new RegExp('<a href="' + esc + '" target="_blank" rel="noreferrer noopener">', 'g'), '');
check('the licence address stands only in comments and in the one link of the footer', !noComments.includes(LIC) && (html.match(new RegExp('<a href="' + esc + '"', 'g')) || []).length === 1, String((html.match(new RegExp('<a href="' + esc + '"', 'g')) || []).length));
check('the page names its licence and its authors (footer text and the notice comment)', /PolyForm Noncommercial License 1\.0\.0/.test(html) && /Copyright \(c\) 2026 the Cascade Atlas authors/.test(html) && /SPDX-License-Identifier: PolyForm-Noncommercial-1\.0\.0/.test(html));
for (const bad of ['<script src', '<link', '@import', 'fetch(', 'XMLHttpRequest', 'sendBeacon', 'WebSocket', 'importScripts', 'eval(', 'new Function', 'localStorage']) check('no ' + bad + ' in the page', !html.includes(bad));
check('title is short', /<title>Label speed test<\/title>/.test(html));
// the kernels in the page are the source, line by line
for (const f of ['pgaEngine.js', 'benchKernels.js', 'productKernels.js']) {
  const lines = fs.readFileSync(path.join(here, f), 'utf8').split('\n').filter(l => !/^import\s/.test(l) && l.trim() !== '');
  const missing = lines.filter(l => !html.includes(l.replace(/^export\s+(?=(const|let|function|class)\b)/, '')));
  check('every line of ' + f + ' is in the page (only export/import removed)', missing.length === 0, missing.slice(0, 2).join(' | '));
}
// the variants the page times are the ones runBench times
const BK = await import(pathToFileURL(path.join(here, 'benchKernels.js')).href), E = await import(pathToFileURL(path.join(here, 'pgaEngine.js')).href);
const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'lb-')), tmpBk = path.join(tmpDir, 'bk.mjs');
fs.writeFileSync(tmpBk, fs.readFileSync(path.join(here, 'benchKernels.js'), 'utf8').replace("from './pgaEngine.js'", "from '" + pathToFileURL(path.join(here, 'pgaEngine.js')).href + "'") + '\nexport { setup };\n');
const BKX = await import(pathToFileURL(tmpBk).href);
const rb = BK.runBench({ ns: [2], minMs: 1, reps: 1 })[0].ns;
const nodeDetail = n => {
  const { A, s, M } = BKX.setup(n), fr = E.frame(A, M, s), D = E.verticesDirect(A, M, s), F = E.verticesFrame(A, M, s, fr); let sum = 0, err = 0;
  for (let v = 0; v < D.length; v++) for (let k = 0; k < n; k++) { sum += D[v][k]; err = Math.max(err, Math.abs(D[v][k] - F[v][k])); }
  return { ok: BK.checkAll(n), sum, maxErr: err };
};

const REF = JSON.parse(fs.readFileSync(path.join(here, 'selfcheck', 'bench_labels.json'), 'utf8')), r6 = REF.rows.find(r => r.n === 6).ns, rr6 = r6.direct.med / r6.frame.med, refRatio6 = rr6.toFixed(rr6 >= 10 ? 1 : 2) + 'x';
const PK = await import(pathToFileURL(path.join(here, 'productKernels.js')).href);

// ---------------------------------------------------------------- browser helpers
const browser = await chromium.launch({ headless: true });
const open = async (ctxOpts = {}, init = null, hash = '') => {
  const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 }, acceptDownloads: true, ...ctxOpts }), page = await ctx.newPage(), errs = [], reqs = [];
  page.on('pageerror', e => errs.push('pageerror: ' + e.message)); page.on('console', m => { if (m.type() === 'error') errs.push('console.error: ' + m.text()); });
  page.on('request', r => reqs.push(r.url())); if (init) await page.addInitScript(init);
  await page.goto(URL_ + hash); return { ctx, page, errs, reqs };
};
const st = page => page.evaluate(() => { const s = window.__labelBench.state(); return JSON.parse(JSON.stringify({ mode: s.mode, modeNote: s.modeNote, stopped: s.stopped, error: s.error, timerStepMs: s.timerStepMs, cells: s.cells, checks: s.checks, warm: s.warm })); });
const finished = (page, ms = 240000) => page.waitForFunction(() => !document.getElementById('run').disabled, null, { timeout: ms });
const setOnly = async (page, ids) => { for (const id of ['vertices', 'contact', 'outline', 'product', 'bodies', 'warm', 'alloc']) await page.locator('#sc-' + id).setChecked(ids.includes(id)); };
const noOverflow = page => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth);
// the verdict (G33 / L4-002): the page's own judge is tested against synthetic timings whose verdicts are worked out by hand below, not against a re-implementation of the rule.
// T3(med, s): a timing with median med and spread s = (max - min) / med. The rule to hold: about equal when the ratio (baseline / candidate) lies between 1/(1 + t) and 1 + t,
// t = max(5%, the larger spread), so that a k-fold loss and a k-fold win get mirror verdicts. The rows include the audit card's examples (spread 1.0 with a 3x and a 50x loss; 1.16x either way at spread 0.15).
const T3 = (med, s) => ({ med, min: med * (1 - s / 2), max: med * (1 + s / 2) });
const VERDICT_TABLE = [
  [T3(100, 1), T3(300, 1), 'slower', 'spread 1.0, the candidate takes 3x the time (card: was "about equal")'], [T3(300, 1), T3(100, 1), 'faster', 'spread 1.0, the candidate takes a third of the time'],
  [T3(100, 1), T3(5000, 1), 'slower', 'spread 1.0, a 50x loss (card: was "about equal")'], [T3(5000, 1), T3(100, 1), 'faster', 'spread 1.0, a 50x win'],
  [T3(100, 1), T3(190, 1), 'equal', 'spread 1.0, a 1.9x loss is within a factor 2'], [T3(190, 1), T3(100, 1), 'equal', 'spread 1.0, a 1.9x win is within a factor 2'],
  [T3(100, 0.15), T3(116, 0.15), 'slower', 'spread 0.15, 1.16x slower (card: was "about equal")'], [T3(116, 0.15), T3(100, 0.15), 'faster', 'spread 0.15, 1.16x faster'],
  [T3(100, 0.15), T3(112, 0.15), 'equal', 'spread 0.15, 1.12x slower is within 1.15'], [T3(112, 0.15), T3(100, 0.15), 'equal', 'spread 0.15, 1.12x faster is within 1.15'],
  [T3(100, 0), T3(104, 0), 'equal', 'no spread, 4% slower is under the 5% floor'], [T3(104, 0), T3(100, 0), 'equal', 'no spread, 4% faster is under the 5% floor'],
  [T3(100, 0), T3(106, 0), 'slower', 'no spread, 6% slower is over the 5% floor'], [T3(106, 0), T3(100, 0), 'faster', 'no spread, 6% faster is over the 5% floor'],
  [T3(100, 0.02), T3(125, 0.3), 'equal', 'spreads 0.02 and 0.3: the larger counts, 1.25x slower is within 1.3'], [T3(100, 0.02), T3(135, 0.3), 'slower', 'spreads 0.02 and 0.3: 1.35x slower is beyond 1.3'],
  [T3(100, 0.5), T3(160, 0.5), 'slower', 'spread 0.5, 1.6x slower (the old rule needed a ratio below 0.5, i.e. a 2x loss)'], [T3(160, 0.5), T3(100, 0.5), 'faster', 'spread 0.5, 1.6x faster'],
  // the exact edge (re-test T5-7d): spread exactly 0.5, ratio exactly 1.5 = 1 + t, and ln 1.5 == log1p(0.5) in V8 (checked below), so |ln ratio| equals ln(1 + t): the rule is strict (<), the ratio
  // must lie strictly between 1/(1 + t) and 1 + t, so the edge itself is not "about equal". Its mirror 100/150 rounds just below 2/3, so it lies outside as well: slower under either reading.
  [T3(150, 0.5), T3(100, 0.5), 'faster', 'spread 0.5, exactly 1.5x faster: the edge 1 + t is outside "about equal" (strict <)'], [T3(100, 0.5), T3(150, 0.5), 'slower', 'spread 0.5, exactly 1/1.5: outside, slower'],
];
const judgeIn = (page, pairs) => page.evaluate(ps => ps.map(([b, c]) => window.__labelBench.judge(b, c)), pairs);
const parseCSV = text => text.trim().split('\n').map(l => { const out = []; let cur = '', q = false; for (let i = 0; i < l.length; i++) { const c = l[i]; if (q) { if (c === '"' && l[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; } else if (c === '"') q = true; else if (c === ',') { out.push(cur); cur = ''; } else cur += c; } out.push(cur); return out; });

try {
  // ---------------------------------------------------------------- 1b. before any run: the verdict against hand-worked expectations, the layout at 320 and 375 px (L5-016), the allocation text
  {
    const { ctx, page, errs } = await open();
    const got = await judgeIn(page, VERDICT_TABLE.map(([b, c]) => [b, c]));
    check('the exact-edge rows are exact in this engine: ln 1.5 == log1p(0.5), spreads exactly 0.5', await page.evaluate(() => Math.log(1.5) === Math.log1p(0.5)) && (T3(150, 0.5).max - T3(150, 0.5).min) / 150 === 0.5 && (T3(100, 0.5).max - T3(100, 0.5).min) / 100 === 0.5);
    VERDICT_TABLE.forEach(([, , want, why], i) => check('verdict: ' + why + ' -> ' + want, got[i] && got[i].verdict === want, got[i] && got[i].verdict));
    check('verdict: a k-fold loss and a k-fold win get mirror verdicts on every row pair of the table', VERDICT_TABLE.every(([b, c], i) => { const j = VERDICT_TABLE.findIndex(([b2, c2]) => b2.med === c.med && c2.med === b.med && b2.max - b2.min === c.max - c.min); return j < 0 || ({ faster: 'slower', slower: 'faster', equal: 'equal' })[got[i].verdict] === got[j].verdict; }));
    // the roles table of README_label_bench.md is the page's own, word for word (re-test T5-7a: the README could put the frame back in the Ours column unnoticed)
    { const md = README_LB.split('\n'), i0 = md.indexOf('| Job | Standard | Ours |'), mdRows = [];
      for (let i = i0 + 2; i0 >= 0 && i < md.length && md[i].startsWith('|'); i++) mdRows.push(md[i].split('|').slice(1, -1).map(c => c.trim()));
      const pgRows = await page.evaluate(() => [...document.querySelectorAll('#roles tbody tr')].map(tr => [...tr.children].map(c => c.textContent.trim())));
      check('README_label_bench.md has the roles table of the page, row for row and word for word', pgRows.length === 7 && JSON.stringify(mdRows) === JSON.stringify(pgRows), JSON.stringify(mdRows.map((r, i) => JSON.stringify(r) === JSON.stringify(pgRows[i]) ? null : [r, pgRows[i]]).filter(Boolean)).slice(0, 400));
      check('in the README roles table the frame (n + 1 sandwiches, then additions) is never in the Ours column', mdRows.length === 7 && mdRows.every(r => !/n \+ 1 sandwiches/.test(r[2]))); }
    for (const [w, scheme] of [[320, 'light'], [320, 'dark'], [375, 'light']]) {
      await page.setViewportSize({ width: w, height: 800 }); await page.emulateMedia({ colorScheme: scheme }); await sleep(250);
      check('before a run: no horizontal page scroll at ' + w + ' px, ' + scheme + ' (the file input of Compare fits)', await noOverflow(page), await page.evaluate(() => document.documentElement.scrollWidth + ' > ' + innerWidth + ', #cmp-file ' + document.getElementById('cmp-file').getBoundingClientRect().width));
    }
    const a16 = Array.isArray(REF.alloc) ? REF.alloc.find(a => a.doubles === 16) : null, allocWhat = await page.evaluate(() => document.querySelector('#res-alloc .what').textContent);
    const fmtNs = ns => { const v = ns >= 1e3 ? ns / 1e3 : ns, u = ns >= 1e3 ? 'µs' : 'ns', d = v >= 100 ? 0 : v >= 10 ? 1 : 2; return v.toFixed(d) + ' ' + u; };
    if (a16) check('the allocation text quotes node\'s figures from the embedded reference run', allocWhat.includes('a Float64Array of 16 doubles took ' + fmtNs(a16.ns.f64.med) + ' to allocate and a plain Array ' + fmtNs(a16.ns.plain.med)) && !/regeneration pending/.test(allocWhat), allocWhat);
    else check('the reference run has no allocation rows: the allocation text says so and types no figure', /no allocation rows yet \(regeneration pending\)/.test(allocWhat) && !/µs/.test(allocWhat), allocWhat);
    const pageText = await page.evaluate(() => { const b = document.body.cloneNode(true); b.querySelectorAll('script').forEach(e => e.remove()); return b.textContent; });     // the text of the page, folds included, without the script source
    if (FINAL) check('final check: the page quotes no pending figure (the reference run has the 1.2.1 rows)', !!a16 && !/regeneration pending/.test(pageText));
    else check('the page says "regeneration pending" exactly when the reference run lacks the allocation rows', /regeneration pending/.test(pageText) === !a16);
    check('no errors (before a run)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
  // LB_ONLY_STATIC=1 stops here (the build, the files and the page before any run: a quick check, e.g. for mutation tests); the timed runs follow
  if (!process.env.LB_ONLY_STATIC) {
  // ---------------------------------------------------------------- 2. the Quick preset on every scenario, in a Worker
  {
    const { ctx, page, errs, reqs } = await open();
    check('the page starts with the Quick preset', (await page.getAttribute('#p-quick', 'aria-pressed')) === 'true' && (await page.inputValue('#minMs')) === '20' && (await page.inputValue('#reps')) === '3');
    check('defaults: n from 1 to 8, B = 1000', (await page.inputValue('#nFrom')) === '1' && (await page.inputValue('#nTo')) === '8' && (await page.inputValue('#bodiesB')) === '1000');
    check('Stop is disabled before a run', await page.isDisabled('#stop'));
    check('export buttons disabled before a run', await page.isDisabled('#dl-json') && await page.isDisabled('#dl-csv') && await page.isDisabled('#cp-text'));
    await page.selectOption('#nTo', '4'); await page.selectOption('#prodN', '10');
    check('the product scenario is on by default, up to n = 12', (await page.isChecked('#sc-product')) && (await page.locator('#prodN option[selected]').getAttribute('value')) === '12');
    await page.click('#run');
    check('Run is disabled while running', await page.isDisabled('#run'));
    check('Stop is enabled while running', !(await page.isDisabled('#stop')));
    await finished(page);
    const s = await st(page);
    check('run finished without error', (await page.textContent('#now')).startsWith('Finished') && !s.error, await page.textContent('#now'));
    check('Worker mode ran', s.mode === 'worker' && (await page.textContent('#mode')).includes('Web Worker'), s.mode + ' ' + s.modeNote);
    check('the timer step was measured', typeof s.timerStepMs === 'number' && s.timerStepMs > 0, String(s.timerStepMs));
    for (const id of ['vertices', 'contact', 'outline', 'product', 'bodies', 'warm', 'alloc']) {
      check('section ' + id + ' is shown', await page.locator('#res-' + id).isVisible());
      check('section ' + id + ' has a timings table', (await page.locator('#res-' + id + ' table').count()) >= 1);
      check('section ' + id + ' correctness check passed', (await page.locator('#res-' + id + ' .check.ok').count()) === 1 && (await page.locator('#res-' + id + ' .check.fail').count()) === 0);
    }
    for (const id of ['vertices', 'contact', 'outline', 'product']) { check('SVG chart in ' + id, (await page.locator('#res-' + id + ' .chartbox svg').count()) === 1); check('chart bars carry value text in ' + id, (await page.locator('#res-' + id + ' .chartbox svg text.vl').count()) >= 3); }
    const chips = await page.locator('.chip').allTextContents();
    const allowed = new Set(['▲ faster', '▼ slower', '≈ about equal within noise']);
    check('verdict chips exist and use the plain words only', chips.length > 20 && chips.every(c => allowed.has(c)), [...new Set(chips)].join(' | '));
    check('the word "faster" appears as a verdict', chips.some(c => c.includes('faster')));
    check('the page never says it proved anything', !/proved/i.test((await page.innerText('body')).replace(/not proved/gi, '')));
    check('"timed, not proved" is on the page', /timed, not proved/i.test(await page.innerText('body')));
    check('the how-to-read box and the banner exist', await page.locator('#howto').isVisible());

    // ---- 1.2.0: what is ours, what is standard, and the At a glance table (recomputed here from the raw timings, independently of the page)
    check('the opening text is short (under 420 characters)', (await page.innerText('#intro')).length < 420, String((await page.innerText('#intro')).length));
    // G34 / L4-003: "ours" only where the label's own idea is timed; the frame against one sandwich per corner is a row of two standard methods (kind 'std'), left out of the tally
    const ROLES = [['Vertices of the cube', 'the matrix route built from the same frame', 'doubling by the label from the same frame'], ['Vertices: the frame (both standard)', 'one sandwich per corner (2^n sandwiches); the frame: n + 1 sandwiches, then additions', 'none: no idea of the label is timed here'], ['Contact: deepest corner under a plane', 'scan of all 2^n corners', 'n sign bits of the frame'], ['Outline of the projected cube', 'convex hull', 'zonogon'], ['Product of two dense multivectors', 'the matrix route', 'the bit rule'], ['Many bodies, contact step', 'build each body’s table from its frame, then scan', 'build each body’s frame, then n sign bits'], ['Allocation', 'Float64Array', 'plain Array']];
    const roleRows = await page.evaluate(() => [...document.querySelectorAll('#roles tbody tr')].map(tr => [...tr.children].map(c => c.innerText)));
    check('the roles table names the standard and ours for all six jobs, and the frame as standard on a row of its own', roleRows.length === 7 && ROLES.every((r, i) => roleRows[i][0] === r[0] && roleRows[i][1].includes(r[1]) && roleRows[i][2].includes(r[2])), JSON.stringify(roleRows).slice(0, 300));
    check('the frame (n + 1 sandwiches, then additions) is never in the Ours column', roleRows.every(r => !/n \+ 1 sandwiches/.test(r[2])));
    check('the roles table header says Standard and Ours', JSON.stringify(await page.locator('#roles thead th').allInnerTexts()) === JSON.stringify(['Job', 'Standard', 'Ours']));
    check('the vertices section tags the frame standard as well, and only the doubling ours', await page.evaluate(() => { const r = document.querySelector('#res-vertices .rolebox'), std = [...r.querySelectorAll('.role.std')].map(e => e.parentElement.textContent).join(' | '), ours = r.querySelector('.role.ours').parentElement.textContent; return /n \+ 1 sandwiches, then additions/.test(std) && /matrix route built from the same frame/.test(std) && /doubling by the label/.test(ours) && !/n \+ 1 sandwiches/.test(ours); }));
    const fmtR = r => r.toFixed(r >= 10 ? 1 : 2) + 'x';
    const c = s.cells, sc = s.cells.bodies.scene;
    // [scenario, kind, baseline of the comparison, candidate of the comparison, is the candidate ours?]. The verdict is the page's judge (tested above against the hand-worked table), applied in the
    // direction of the comparison (baseline / candidate), as in the detail tables, and then read from the side of ours.
    const FLIP = { faster: 'slower', slower: 'faster', equal: 'equal' };
    const GL0 = [['vertices', 'ours', c.vertices[4].matrix, c.vertices[4].frame, true], ['vertices', 'std', c.vertices[4].direct, c.vertices[4].frame, true], ['contact', 'ours', c.contact[4].scanBuilt, c.contact[4].bitsBuilt, true], ['outline', 'ours', c.outline[4].hullBuilt, c.outline[4].zonoBuilt, true],
      ['product', 'ours', c.product[10].signTable, c.product[10].matrixRoute, false], ['bodies', 'ours', sc.scanBuilt, sc.bitsBuilt, true], ['alloc', 'ours', c.alloc.a16.f64, c.alloc.a16.plain, true]];
    const J0 = await judgeIn(page, GL0.map(g => [g[2], g[3]]));
    check('every glance comparison has two valid timings', J0.every(Boolean), JSON.stringify(GL0.map((g, i) => J0[i] ? null : [g[0], g[1], g[2], g[3]]).filter(Boolean)));
    for (let i = 0; i < J0.length; i++) if (!J0[i]) J0[i] = { ratio: NaN, verdict: 'none', noisy: false };
    const GL = GL0.map(([id, kind, base, cand, candOurs], i) => { const j = J0[i], ratio = candOurs ? j.ratio : 1 / j.ratio, v = candOurs ? j.verdict : FLIP[j.verdict]; return { id, kind, ratio, v, noisy: j.noisy, shown: fmtR(v === 'slower' ? 1 / ratio : ratio) }; });
    const OURS = GL.filter(g => g.kind === 'ours');
    const gl = await page.evaluate(() => [...document.querySelectorAll('#glance-tab tbody tr')].map(tr => ({ job: tr.children[0].innerText, std: tr.children[1].innerText, ours: tr.children[2].innerText, res: tr.children[3].innerText })));
    check('At a glance has one row for each of the six jobs and the row of two standard methods, in the order of the roles table', gl.length === 7 && ROLES.every((r, i) => gl[i].job === r[0] && gl[i].std.includes(r[1].split(';')[0]) && (i === 1 ? /^none: the frame: n \+ 1 sandwiches, then additions .* is standard too$/.test(gl[i].ours) : gl[i].ours.includes(r[2]))), JSON.stringify(gl.map(g => [g.job, g.ours])));
    check('the vertices row of At a glance is the frame against the matrix route from the same frame, not against one sandwich per corner', /matrix route built from the same frame/.test(gl[0].std) && /doubling/.test(gl[0].ours) && /the frame against one sandwich per corner/.test(gl[1].res));
    const WORDS = { faster: '▲ faster', slower: '▼ slower', equal: '≈ about equal within noise' };
    let glOk = gl.length === 7; for (let i = 0; i < gl.length && glOk; i++) { const g = GL[i], t = gl[i].res.replace(/ /g, ' '); glOk = t.split('\n')[0] === g.shown && t.includes(WORDS[g.v]) && (t.includes('noisy') === g.noisy); if (!glOk) console.log('glance mismatch', g.id, JSON.stringify(g), JSON.stringify(t)); }
    check('every At a glance row shows the ratio, the verdict and the noisy flag of the page\'s judge on the raw timings (standard time / ours, turned around for the product)', glOk);
    check('the product row is read from the side of ours: the bit rule against the matrix route, not the other way round', Math.abs(GL[4].ratio / (c.product[10].matrixRoute.med / c.product[10].signTable.med) - 1) < 1e-12);
    const sumTxt = await page.innerText('#glance-sum');
    const nF = OURS.filter(g => g.v === 'faster').length, nE = OURS.filter(g => g.v === 'equal').length, nS = OURS.filter(g => g.v === 'slower').length;
    const parts = [nF && 'faster in ' + nF, nE && 'about equal in ' + nE, nS && 'slower in ' + nS].filter(Boolean).join(', ').replace(/, ([^,]*)$/, ' and $1');
    check('the tally sentence counts the verdicts of the six rows of ours (not the row of two standard methods)', sumTxt.includes('6 jobs timed, at the size shown: ours is ' + parts + '.'), sumTxt.slice(0, 300));
    const wins = OURS.filter(g => g.v === 'faster'), quiet = wins.filter(g => !g.noisy), bestG = (quiet.length ? quiet : wins).slice().sort((a, b) => b.ratio - a.ratio)[0];
    const OURS_SHORT = { vertices: 'doubling by the label', contact: 'the sign bits', outline: 'the zonogon', product: 'the bit rule', bodies: 'frame and sign bits', alloc: 'plain Array' };
    if (bestG) check('the best-result sentence names the largest quiet win of ours with its ratio', sumTxt.includes('Best result on this run: ' + OURS_SHORT[bestG.id] + ' (ours) is ' + fmtR(bestG.ratio) + ' faster than'), 'expected ' + bestG.id + ' ' + fmtR(bestG.ratio) + ' | ' + sumTxt.slice(0, 200));
    else check('no best result of ours when ours never wins', sumTxt.includes('No job is clearly faster with ours on this run.'));
    check('the frame is never credited to ours in the summary', !/the frame \(ours\)/.test(sumTxt) && !/n \+ 1 sandwiches[^.]*\(ours\)/.test(sumTxt));
    const stdG = GL[1], stdWant = stdG.v === 'equal' ? 'the frame and one sandwich per corner (both standard) are about equal' : stdG.v === 'faster' ? 'the frame (standard) is ' + fmtR(stdG.ratio) + ' faster than one sandwich per corner (standard)' : 'one sandwich per corner (standard) is ' + fmtR(1 / stdG.ratio) + ' faster than the frame (standard)';
    check('the frame against one sandwich per corner is reported as two standard methods', sumTxt.includes('Not ours, both standard: ' + stdWant), stdWant + ' | ' + sumTxt);
    for (const g of OURS.filter(x => x.v === 'slower')) check('a job where ours is slower is named under "Where ours loses": ' + g.id, sumTxt.includes('Where ours loses: ') && sumTxt.includes('(standard) is ' + fmtR(1 / g.ratio) + ' faster than'), sumTxt);
    if (!OURS.some(g => g.v === 'slower')) check('no "Where ours loses" line when ours is never slower', !sumTxt.includes('Where ours loses'));
    check('the summary says how closely the answers agreed in 7 of 7 scenarios (not "identical")', sumTxt.includes('the methods agreed in 7 of 7 scenarios checked: within 1e-9 relative (the product kernels exactly)') && !/identical/.test(sumTxt) && !/identical/.test(await page.innerText('#intro')) && /agree within 1e-9 relative \(the product kernels exactly\)/.test(await page.innerText('#intro')));
    check('a fixed sentence about our best model is not invented: none is shown unless the page source sets OUR_SENTENCE', (await page.locator('#glance-sum .position').count()) === 0);
    check('At a glance comes before the scenario sections, and after the banner', await page.evaluate(() => { const g = document.getElementById('glance'), r = document.getElementById('res'), b = document.getElementById('banner'); return !!(b.compareDocumentPosition(g) & Node.DOCUMENT_POSITION_FOLLOWING) && !!(g.compareDocumentPosition(r) & Node.DOCUMENT_POSITION_FOLLOWING) && !g.hidden; }));
    // folds: the ratios are the result, the timings and the method fold away; for the two scenarios whose result is the timing table it stays open
    for (const id of ['vertices', 'contact', 'outline', 'product', 'alloc']) check('folds in ' + id + ': timings, method and more comparisons closed by default', (await page.locator('#res-' + id + ' details.fold').count()) >= 2 && await page.evaluate(i => [...document.querySelectorAll('#res-' + i + ' details.fold')].every(d => !d.open), id) && (await page.locator('#res-' + id + ' details.alltimes table').count()) === 1);
    for (const id of ['bodies', 'warm']) check('in ' + id + ' the timing table is not folded', (await page.locator('#res-' + id + ' details.alltimes').count()) === 0 && await page.locator('#res-' + id + ' table').first().isVisible());
    check('the key comparison of each scenario is visible and marked "key result"', await page.evaluate(() => ['vertices', 'contact', 'outline', 'product', 'bodies', 'alloc'].every(id => { const t = document.querySelector('#res-' + id + ' table.cmp'); return t && t.getClientRects().length > 0 && t.querySelector('.keytag') && t.querySelectorAll('.keytag').length === 1; })));
    check('the other comparisons sit in the folded "More comparisons"', await page.evaluate(() => ['vertices', 'contact', 'outline', 'product', 'bodies', 'alloc'].every(id => { const d = document.querySelector('#res-' + id + ' details.more'); return d && !d.open && d.querySelector('table.cmp') && !d.querySelector('.keytag'); })));
    check('each scenario says which method is standard and which is ours (the warm-up has no such pair)', await page.evaluate(() => ['vertices', 'contact', 'outline', 'product', 'bodies', 'alloc'].every(id => { const r = document.querySelector('#res-' + id + ' .rolebox'); return r && r.querySelector('.role.std').textContent === 'standard' && r.querySelector('.role.ours').textContent === 'ours'; }) && !document.querySelector('#res-warm .rolebox')));
    const bodyTxt = await page.innerText('body');
    check('no stray "null", "undefined", "NaN" or "[object" on the page', !/\b(null|undefined|NaN)\b|\[object/.test(bodyTxt), (bodyTxt.match(/.{0,30}\b(null|undefined|NaN)\b.{0,30}/) || [''])[0]);
    check('the check lines are one short sentence each (under 260 characters)', (await page.locator('.check.ok').allInnerTexts()).every(t => t.length < 260), (await page.locator('.check.ok').allInnerTexts()).map(t => t.length).join());
    // the verdict words shown are the judge's on the raw timings (key comparison: the frame with doubling against the matrix route from the same frame, n = 1..4)
    const vrows = await page.evaluate(() => [...document.querySelectorAll('#res-vertices table.cmp tbody')][0].innerText);
    const vc = s.cells.vertices, vj = await judgeIn(page, [1, 2, 3, 4].map(n => [vc[n].matrix, vc[n].frame]));
    const lines = (await page.locator('#res-vertices table.cmp tbody').first().locator('tr').allInnerTexts()).slice(1);
    let ruleOk = lines.length === 4 && /matrix route from the same frame/.test(vrows); for (let i = 0; i < lines.length && ruleOk; i++) { const n = i + 1, v = vj[i].verdict; const word = { faster: 'faster', slower: 'slower', equal: 'about equal within noise' }[v]; ruleOk = lines[i].includes(word); if (!ruleOk) console.log('verdict mismatch at n=' + n, v, lines[i]); }
    check('the key vertices comparison is the frame against the matrix route from the same frame, with the judge\'s verdicts (n = 1..4)', ruleOk, vrows.slice(0, 120));
    check('spread is shown for every timing', (await page.locator('#res-vertices td .r').count()) > 20);
    check('noisy rows carry a visible warning when the spread exceeds 15%', await page.evaluate(() => { const s = window.__labelBench.state(); let need = 0; for (const n of Object.keys(s.cells.vertices)) for (const v of Object.values(s.cells.vertices[n])) if ((v.max - v.min) / v.med > 0.15) need++; return need === 0 || document.querySelectorAll('#res-vertices .noisy, #res-vertices td .r').length > 0 && document.body.innerText.includes('noisy'); }));
    check('machine panel shows the user agent, processors, mode and version', /HeadlessChrome|Chrome/.test(await page.innerText('#machine')) && /Logical processors/.test(await page.innerText('#machine')) && /Web Worker/.test(await page.innerText('#machine')) && /1\.2\.2/.test(await page.innerText('#machine')) && (await page.innerText('#machine')).includes(KHASH));
    check('timer note: coarse or fine, the timer is reported', /Timer step/.test(await page.innerText('#machine')));
    // the coarse-timer note says how the quantisation of a batch compares with the 5% floor, by the rule of the page (below 1%: small; below 5%: comparable; else as large or larger)
    { const q = s.timerStepMs / 20, want = q < 0.01 ? 'small next to' : q < 0.05 ? 'comparable to' : 'as large as or larger than', ban = await page.innerText('#banner');
      if (s.timerStepMs > 0.005) check('the coarse-timer note compares the quantisation honestly with the 5% floor (' + (100 * q).toFixed(1) + '%: ' + want + ')', ban.includes('quantised by up to ' + (100 * q).toFixed(1) + '%, ' + want + ' the 5% floor of the verdict'), ban);
      else check('a fine timer: no coarse-timer note', !/Coarse timer/.test(ban), ban); }
    // correctness numbers: the page's (computed in the worker) against node's
    for (const n of [1, 2, 3, 4]) { const w = s.checks.vertices[n], nd = nodeDetail(n); check('worker check n=' + n + ' equals node checkAll', w && w.ok === true && nd.ok === true && Math.abs(w.sum - nd.sum) <= 1e-9 * Math.max(1, Math.abs(nd.sum)) && Math.abs(w.maxErr - nd.maxErr) <= 1e-12, JSON.stringify([w, nd])); }
    // all of n = 1..8 on the main thread of the page (the same code), against node
    const pageChecks = await page.evaluate(() => [1, 2, 3, 4, 5, 6, 7, 8].map(n => LBCORE.checkDetail(n)));
    for (const n of [1, 2, 3, 4, 5, 6, 7, 8]) { const p = pageChecks[n - 1], nd = nodeDetail(n); check('page check n=' + n + ' equals node checkAll (ok, vertex sum, |direct-frame|)', p.ok === nd.ok && p.ok === true && Math.abs(p.sum - nd.sum) <= 1e-9 * Math.max(1, Math.abs(nd.sum)) && Math.abs(p.maxErr - nd.maxErr) <= 1e-12, JSON.stringify([p, nd])); }
    check('the page times the same variants as runBench', JSON.stringify((await page.evaluate(() => LBCORE.VARIANT_KEYS)).slice().sort()) === JSON.stringify(Object.keys(rb).sort()));
    check('the page cell for direct n=4 is a positive time in ns', s.cells.vertices[4].direct.med > 0 && s.cells.vertices[4].direct.min <= s.cells.vertices[4].direct.med && s.cells.vertices[4].direct.med <= s.cells.vertices[4].direct.max);
    check('many-bodies cells: 7 variants', Object.keys(s.cells.bodies.scene).length === 7);
    check('warm-up: 6 targets, 3 cold runs each, a steady state each', Object.keys(s.warm.cold).length === 6 && Object.values(s.warm.cold).every(a => a.length === 3) && Object.keys(s.warm.steady).length === 6 && s.warm.fresh === true);
    check('allocation cells: 4 sizes and the loop', ['a8', 'a16', 'a32', 'a64', 'loop'].every(k => s.cells.alloc[k]));

    // export
    const [dj] = await Promise.all([page.waitForEvent('download'), page.click('#dl-json')]);
    const json = JSON.parse(fs.readFileSync(await dj.path(), 'utf8'));
    check('JSON: valid, with rows, settings, machine, mode, checks', Array.isArray(json.rows) && json.rows.length === 4 && json.rows.every(r => r.ns && r.ns.direct && r.ns.frame && r.ns.direct.med > 0) && json.settings.minMs === 20 && json.settings.reps === 3 && json.machine.userAgent && json.mode === 'worker' && json.checks.vertices['1'].ok === true && json.format === 'label-bench');
    check('JSON: the product cells are there', json.product && [2, 4, 6, 8, 10].every(n => json.product.ns[n] && json.product.ns[n].bitRule && json.product.ns[n].matrixRoute) && json.product.ns[10].period8 && !json.product.ns[8].period8);
    check('JSON: other scenarios present', json.bodies && json.bodies.ns.buildFrame && json.warmup && json.warmup.targets.direct.runs.length === 3 && json.alloc && json.alloc.a16.plain);
    check('JSON file name', /^label-bench-\d{8}-\d{4}\.json$/.test(dj.suggestedFilename()), dj.suggestedFilename());
    const [dc] = await Promise.all([page.waitForEvent('download'), page.click('#dl-csv')]);
    const csv = parseCSV(fs.readFileSync(await dc.path(), 'utf8'));
    check('CSV: non-empty, header, 10 columns everywhere', csv.length > 40 && csv[0].join() === 'kind,scenario,key,name,median_ns,min_ns,max_ns,spread,ratio,verdict' && csv.every(r => r.length === 10), csv.length + ' rows');
    check('CSV: ratio rows carry a verdict word', csv.filter(r => r[0] === 'ratio' && r[1] === 'vertices').every(r => ['faster', 'slower', 'equal'].includes(r[9])));
    await page.click('#cp-text');
    await page.waitForFunction(() => document.getElementById('exp-msg').textContent.length > 0);
    const text = await page.inputValue('#textOut');
    check('text summary is readable and honest', /VERTICES/.test(text) && /timed, not proved/i.test(text) && /about equal within noise|faster|slower/.test(text) && text.split('\n').length > 30);
    check('text summary says which scene and which settings were run', /Scenario settings: .*many bodies: B = \d+, n = \d, seed \d+/.test(text) && /MANY BODIES \(B = \d+, n = \d\)/.test(text), (text.match(/Scenario settings:[^\n]*/) || ['none'])[0]);
    // compare
    await page.click('#cmp-ref');
    check('compare with the embedded reference run renders', (await page.locator('#cmp-out table.cmp tbody').count()) >= 6 && /reference run on one 2-core VM, node 22/.test(await page.innerText('#cmp-out')) && new RegExp(refRatio6.replace('.', '\\.')).test(await page.innerText('#cmp-out')));
    check('compare shows the ratio between the two ratios for a common n', /\b\d\.\d\d\b/.test(await page.locator('#cmp-out table.cmp tbody').first().locator('tr').nth(4).innerText()));
    await page.click('#cmp-clear'); check('compare can be cleared', (await page.locator('#cmp-out table').count()) === 0);
    await page.setInputFiles('#cmp-file', { name: 'run.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(json)) });
    await page.waitForFunction(() => document.getElementById('cmp-out').querySelector('table'));
    check('compare with a downloaded JSON renders', (await page.locator('#cmp-out table.cmp').count()) === 1 && /1\.00/.test(await page.innerText('#cmp-out')));
    await page.setInputFiles('#cmp-file', { name: 'bad.json', mimeType: 'application/json', buffer: Buffer.from('{"x":1}') });
    await page.waitForFunction(() => /Could not/.test(document.getElementById('cmp-msg').textContent));
    check('a wrong file gives a plain message', true);

    // layout: 1100 and 375, light and dark
    const shot = async name => { await page.locator('#res-vertices').screenshot({ path: path.join(SHOTS, 'lb_test_' + name + '.png') }); await page.screenshot({ path: path.join(SHOTS, 'lb_test_top_' + name + '.png') }); };
    for (const [w, scheme] of [[1100, 'light'], [1100, 'dark'], [375, 'light'], [375, 'dark'], [360, 'light'], [320, 'light']]) {
      await page.setViewportSize({ width: w, height: 900 }); await page.emulateMedia({ colorScheme: scheme }); await sleep(450);
      check('no horizontal page scroll at ' + w + ' px, ' + scheme, await noOverflow(page), await page.evaluate(() => document.documentElement.scrollWidth + ' > ' + innerWidth));
      check('charts redrawn at ' + w + ' px', (await page.locator('.chartbox svg').count()) === 4 && (await page.locator('.chartbox svg').first().evaluate(e => e.getBoundingClientRect().width)) <= w);
      const bg = await page.evaluate(() => getComputedStyle(document.body).backgroundColor); check('explicit dark/light body background at ' + scheme, scheme === 'dark' ? /rgb\(20, 20, 19\)/.test(bg) : /rgb\(252, 252, 251\)/.test(bg), bg);
      check('16 px side gutters at ' + w, await page.evaluate(() => { const r = document.querySelector('.wrap').getBoundingClientRect(); return r.left >= 0 && getComputedStyle(document.querySelector('.wrap')).paddingLeft === '16px'; }));
      await shot(w + '_' + scheme);
    }
    // keyboard: a control has a visible focus style and labels exist
    check('every select and checkbox has a label', await page.evaluate(() => [...document.querySelectorAll('select, input[type=checkbox], input[type=file]')].every(e => e.labels && e.labels.length > 0)));
    check('aria-live polite region exists', (await page.getAttribute('#status', 'aria-live')) === 'polite');
    check('no request left the file (only file:, blob:, data:)', reqs.every(u => /^(file|blob|data):/.test(u)), reqs.filter(u => !/^(file|blob|data):/.test(u)).join(' '));
    // a pair that cannot be judged (a median of 0) is shown as "not judged" and counted in the banner, not dropped (re-test T6-11: the folded "More comparisons" of a section vanished when its only
    // other pair had such a timing). Set on the finished run's own state, redrawn, then restored: independent of the timings.
    { const r = await page.evaluate(() => { const S = window.__labelBench.state(), keep = S.cells.alloc.loop.f64reuse; S.cells.alloc.loop.f64reuse = { med: 0, min: 0, max: 2e5, iters: 1, retimed: 2 }; window.__labelBench.render();
        const d = document.querySelector('#res-alloc details.more'), out = { more: !!(d && !d.open && d.querySelector('table.cmp')), row: d ? [...d.querySelectorAll('tr.unjudged')].map(t => t.textContent) : [], banner: document.getElementById('banner').innerText };
        S.cells.alloc.loop.f64reuse = keep; window.__labelBench.render(); out.after = document.querySelectorAll('tr.unjudged').length; return out; });
      check('a pair with a median of 0 stays in its table as "not judged" (the folded More comparisons does not vanish), and the banner counts it', r.more && r.row.length === 1 && /not judged: a median of 0/.test(r.row[0]) && /1 comparison was not judged/.test(r.banner) && r.after === 0, JSON.stringify(r).slice(0, 300)); }
    check('no page error and no console error (main run)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 2b. the product scenario alone, up to n = 12
  {
    const { ctx, page, errs } = await open();
    await setOnly(page, ['product']); await page.selectOption('#prodN', '12');
    check('the product warning at n = 12 is shown and mentions the sign table', await page.locator('#warn-n').isVisible() && /16 MB/.test(await page.innerText('#warn-n')));
    await page.selectOption('#prodN', '14'); check('the n = 14 warning says the sign table is left out', /268 MB/.test(await page.innerText('#warn-n')) && /left out/.test(await page.innerText('#warn-n')));
    await page.selectOption('#prodN', '12');
    await page.click('#run'); await finished(page, 300000);
    const s = await st(page), c = s.cells.product;
    check('product run finished without error, in a Worker', (await page.textContent('#now')).startsWith('Finished') && !s.error && s.mode === 'worker', await page.textContent('#now'));
    check('product cells for n = 2, 4, 6, 8, 10, 12', Object.keys(c).map(Number).join() === '2,4,6,8,10,12');
    check('every n has the seven plain variants (with the route with buffers allocated once and its allocations alone); period 8 only from n = 10', [2, 4, 6, 8, 10, 12].every(n => ['bitRule', 'signTable', 'signTableReuse', 'matmulGiven', 'matrixRoute', 'matrixRouteReuse', 'routeAllocs'].every(v => c[n][v] && c[n][v].med > 0) && (n >= 10) === !!c[n].period8));
    // the page's correctness numbers (computed in the worker) equal node's, exactly
    let same = true; for (const n of [2, 4, 6, 8, 10, 12]) { const w = s.checks.product[n], nd = PK.productCheck(n); if (!(w && w.ok && nd.ok && w.checksum === nd.checksum && w.terms === nd.terms)) { same = false; console.log('product check differs at n =', n, JSON.stringify([w, nd])); } }
    check('the page and node give the same exact checksums for n = 2..12', same);
    check('the correctness line says what was compared, and that the timed inputs were among them', /same integer coefficients, compared exactly, on the timed inputs and a second pair/.test(await page.innerText('#res-product .check')) && /16 × 16 blocks/.test(await page.innerText('#res-product .check')) && /buffers allocated once/.test(await page.innerText('#res-product .check')));
    await page.evaluate(() => document.querySelectorAll('#res-product details').forEach(d => { d.open = true; }));
    check('the product table has a row for every n and a dash where a variant does not apply', (await page.locator('#res-product table.stack tbody tr').count()) === 6 && /–/.test(await page.locator('#res-product table.stack tbody tr').first().innerText()));
    check('row labels carry the operation counts (4^n terms against 8^k multiplications)', /16 terms vs 8 multiplications/.test(await page.locator('#res-product table.stack tbody tr').first().innerText()) && /17 M terms vs 262 k multiplications/.test(await page.locator('#res-product table.stack tbody tr').last().innerText()));
    // the verdict words shown are the judge's on the raw timings, for the matrix route against the sign table
    const grp = (await page.locator('#res-product table.cmp tbody').first().locator('tr').allInnerTexts()).slice(1), pj = await judgeIn(page, [2, 4, 6, 8, 10, 12].map(n => [c[n].signTable, c[n].matrixRoute]));
    let rule = grp.length === 6; for (let i = 0; i < grp.length && rule; i++) { const n = [2, 4, 6, 8, 10, 12][i], v = pj[i].verdict; rule = grp[i].includes({ faster: 'faster', slower: 'slower', equal: 'about equal within noise' }[v]); if (!rule) console.log('product verdict mismatch at n =', n, v, grp[i]); }
    check('the page shows the judge\'s verdicts (matrix route against the sign table)', rule);
    check('the comparisons include the route with buffers allocated once on both sides, and the cost of the allocations to the route', await page.evaluate(() => { const t = document.getElementById('res-product').innerText; return /the same two with their buffers allocated once: the route itself/.test(t) && /matrix route: buffers allocated once against allocated on every call/.test(t); }));
    // robust measured facts: the plain bit rule loses by a wide margin at n = 12; at n = 2 the route is slower in every variant (the audit measured 0.15x to 0.33x)
    const q = n => c[n].bitRule.med / c[n].matrixRoute.med, qt = n => c[n].signTable.med / c[n].matrixRoute.med;
    check('at n = 12 the matrix route is at least 10 times faster than the plain bit rule', q(12) > 10, String(q(12)));
    check('at n = 2 the matrix route is slower than the sign-table bit rule (as written and with buffers allocated once)', qt(2) < 1 && !!(c[2].signTableReuse && c[2].matrixRouteReuse) && c[2].signTableReuse.med / c[2].matrixRouteReuse.med < 1, String(qt(2)));
    check('the gain over the sign table grows from n = 8 to n = 12', qt(12) > qt(8), qt(8) + ' ' + qt(12));
    check('the chart has bars for the sign-table and plain-rule series', (await page.locator('#res-product .chartbox svg text.vl').count()) >= 10 && /hatched: against the plain rule/.test(await page.innerText('#res-product .legend')));
    check('the note names allocation and does not put a small-n loss down to the conversion', /before reading a small-n loss as a cost of the conversion/.test(await page.innerText('#res-product')) && !/costs more than it saves/.test(await page.innerText('#res-product')));
    const csv = await page.evaluate(() => window.__labelBench.buildCSV());
    check('CSV has product timings and ratios', /^timing,product,12,matrixRoute,/m.test(csv) && /^timing,product,12,matrixRouteReuse,/m.test(csv) && /^timing,product,4,routeAllocs,/m.test(csv) && /^ratio,product,12,signTable\/matrixRoute,/m.test(csv) && /^ratio,product,4,signTableReuse\/matrixRouteReuse,/m.test(csv) && /^ratio,product,10,signTable\/period8,/m.test(csv));
    const txt = await page.evaluate(() => window.__labelBench.buildText());
    check('the text summary has the product section', /PRODUCT: BIT RULE AGAINST MATRIX ROUTE/.test(txt) && /matrix route is [\d.]+x faster/.test(txt));
    // layout at 375 px
    await page.setViewportSize({ width: 375, height: 900 }); await sleep(400);
    check('no horizontal page scroll at 375 px with the product table', await noOverflow(page));
    await page.locator('#res-product').screenshot({ path: path.join(SHOTS, 'lb_test_product_375.png') });
    check('no errors (product run)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 3. Stop in Worker mode
  {
    const { ctx, page, errs } = await open();
    await setOnly(page, ['vertices']); await page.selectOption('#minMs', '60'); await page.selectOption('#reps', '7'); await page.selectOption('#nTo', '8');
    check('presets follow the selects', (await page.getAttribute('#p-quick', 'aria-pressed')) === 'false' && (await page.getAttribute('#p-careful', 'aria-pressed')) === 'false');
    await page.click('#p-careful'); check('Careful preset sets 200 ms and 15 repetitions', (await page.inputValue('#minMs')) === '200' && (await page.inputValue('#reps')) === '15');
    await page.click('#p-quick'); await page.selectOption('#minMs', '60'); await page.selectOption('#reps', '7');
    await page.click('#run');
    await page.waitForFunction(() => { const s = window.__labelBench.state(); return s.cells.vertices && Object.keys(s.cells.vertices).length > 0; }, null, { timeout: 60000 });
    const t0 = Date.now(); await page.click('#stop');
    await finished(page, 8000);
    const dt = Date.now() - t0, c1 = Object.keys((await st(page)).cells.vertices || {}).length;
    check('Stop in Worker mode returns quickly', dt < 3000, dt + ' ms');
    check('Stop says so and keeps the partial rows', /Stopped/.test(await page.textContent('#now')) && (await st(page)).stopped === true && (await page.locator('#res-vertices table').count()) >= 1 && /stopped/i.test(await page.innerText('#banner')));
    check('exports stay available after Stop', !(await page.isDisabled('#dl-json')));
    const nCells = async () => (await page.evaluate(() => { const s = window.__labelBench.state(); return Object.values(s.cells.vertices || {}).reduce((a, r) => a + Object.keys(r).length, 0); }));
    const a = await nCells(); await sleep(1500); const b = await nCells();
    check('nothing is timed after Stop', a === b && a > 0 && a < 8 * 6, a + ' ' + b);
    // a second run after Stop works
    await page.selectOption('#nTo', '2'); await page.click('#run'); await finished(page);
    check('a new run after Stop works', /Finished/.test(await page.textContent('#now')) && (await st(page)).stopped === false);
    // n >= 9 warning
    await page.selectOption('#nTo', '10'); check('n >= 9 shows the warning about direct', await page.locator('#warn-n').isVisible() && /direct/.test(await page.innerText('#warn-n')));
    await page.selectOption('#nTo', '4'); check('the warning goes away', !(await page.locator('#warn-n').isVisible()));
    check('no errors (stop test)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }

  // ---------------------------------------------------------------- 4. the main-thread fallback: forced by #main, and by a Worker that cannot be created
  for (const [label, init, hash] of [['forced by #main', null, '#main'], ['Worker construction fails', () => { window.Worker = function () { throw new Error('blocked by the test'); }; }, '']]) {
    const { ctx, page, errs } = await open({}, init, hash);
    await page.selectOption('#nTo', '3'); await page.selectOption('#prodN', '8'); await page.click('#run'); await finished(page);
    const s = await st(page);
    check('fallback (' + label + '): main thread ran and says so', s.mode === 'main' && /main thread/.test(await page.textContent('#mode')) && s.modeNote.length > 0, s.mode + ' ' + s.modeNote + ' | ' + (s.error || ''));
    check('fallback (' + label + '): the reason is shown', label.includes('#main') ? /#main/.test(s.modeNote) : /could not be started/.test(s.modeNote) && /blocked by the test/.test(s.modeNote), s.modeNote);
    check('fallback (' + label + '): finished with results in every scenario', /Finished/.test(await page.textContent('#now')) && (await page.locator('.chip').count()) > 10 && (await page.locator('.chartbox svg').count()) === 4 && (await page.locator('#res-warm table').count()) === 1);
    check('fallback (' + label + '): warm-up is flagged as not a cold start', /Main-thread mode/.test(await page.innerText('#res-warm')) && s.warm.fresh === false && Object.values(s.warm.cold).every(a => a.length === 1));
    check('fallback (' + label + '): correctness check passed in all seven', (await page.locator('.check.ok').count()) === 7);
    check('no errors (fallback ' + label + ')', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
  // ---------------------------------------------------------------- 4b. a coarse 1 ms timer and an interrupted calibration (main thread, so that the page's clock can be wrapped)
  // The clock is floored to 1 ms (as browsers that coarsen the timer do) and jumps by 25 ms once, inside the first calibration batch of the reused-buffer loop of the Allocation scenario: an interruption
  // of the thread (re-test T6-11). timeIt then stops calibrating after one call; the page must take that timing again (T_ in runners.js), so its median is not 0. The banner must compare the 5.0%
  // quantisation of a 20 ms batch honestly with the 5% floor (re-test T5-5: it said "small next to").
  {
    const { ctx, page, errs } = await open({}, () => { const real = performance.now.bind(performance); let off = 0, armed = false, calls = 0;
      performance.now = () => { const el = document.getElementById('now'); if (!armed && el && el.textContent === 'sandwich-like loop: f64reuse') { armed = true; calls = 0; } if (armed && ++calls === 3 && off === 0) off = 25; return Math.floor(real() + off); }; }, '#main');
    await setOnly(page, ['vertices', 'alloc']); await page.selectOption('#nTo', '2'); await page.click('#run'); await finished(page);
    const s = await st(page), ban = await page.innerText('#banner'), loop = s.cells.alloc && s.cells.alloc.loop || {};
    check('coarse timer: the step is measured as 1 ms', Math.abs(s.timerStepMs - 1) < 1e-9, String(s.timerStepMs));
    check('coarse timer: the note says a 5.0% quantisation is as large as the 5% floor, and that Careful brings it to 0.5%', ban.includes('quantised by up to 5.0%, as large as or larger than the 5% floor of the verdict (Careful, with 200 ms batches, brings it to 0.5%)') && !/small next to/.test(ban), ban);
    check('an interrupted calibration is timed again: the loop with reused buffers has a positive median from batches of many calls', !!loop.f64reuse && loop.f64reuse.retimed >= 1 && loop.f64reuse.med > 0 && loop.f64reuse.iters > 1, JSON.stringify(loop.f64reuse));
    check('after it, every pair is judged and the folded More comparisons of Allocation is there', !/not judged/.test(ban) && (await page.locator('tr.unjudged').count()) === 0 && await page.evaluate(() => { const d = document.querySelector('#res-alloc details.more'); return !!(d && d.querySelector('table.cmp')); }));
    check('no errors (coarse timer, interrupted calibration)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
  // Stop in main-thread mode
  {
    const { ctx, page, errs } = await open({}, null, '#main');
    await setOnly(page, ['vertices']); await page.selectOption('#nTo', '8'); await page.click('#run');
    await page.waitForFunction(() => { const s = window.__labelBench.state(); return s.cells.vertices && Object.keys(s.cells.vertices).length > 1; }, null, { timeout: 60000 });
    const t0 = Date.now(); await page.click('#stop'); await finished(page, 20000);
    check('Stop in main-thread mode returns after the current timing', Date.now() - t0 < 8000 && /Stopped/.test(await page.textContent('#now')) && (await st(page)).stopped === true, (Date.now() - t0) + ' ms');
    check('no errors (main-thread stop)', errs.length === 0, errs.join(' | '));
    await ctx.close();
  }
  }   // end of the timed runs (skipped with LB_ONLY_STATIC=1)
} finally { await browser.close(); fs.rmSync(tmpDir, { recursive: true, force: true }); }

if (fails.length) { console.log('\n' + fails.length + ' of ' + nchecks + ' checks failed'); process.exit(1); }
console.log(nchecks + ' checks passed; screenshots in ' + SHOTS);
console.log(process.env.LB_ONLY_STATIC ? 'LABEL BENCH STATIC PART OK (the timed runs were skipped: LB_ONLY_STATIC)' : 'LABEL BENCH OK');
