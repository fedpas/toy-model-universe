// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Pure functions behind step 14 (null surfaces). No React in this file: the widgets draw these numbers and test_null.mjs recomputes them
// against selfcheck/null.json (made by selfcheck/null_selfcheck.py, exact arithmetic). Units: r_S = 1 for the Schwarzschild picture, the Ellis throat has radius 1.

export const popc = x => { let c = 0; while (x) { c += x & 1; x >>= 1; } return c; };
export const frac = s => { const [a, b] = String(s).split('/'); return b ? +a / +b : +a; };

// ---- the bit rule: e_a e_b = (-1)^N(a,b) * prod over the shared bits of their squares * e_{a xor b}, N(a,b) = number of pairs i in a, j in b with i > j
export function bitMul(a, b, sq) {
  let n = 0;
  for (let i = 0; i < 8; i++) if (a >> i & 1) for (let j = 0; j < i; j++) if (b >> j & 1) n++;
  let c = n % 2 ? -1 : 1;
  for (let i = 0; i < 8; i++) if ((a & b) >> i & 1) c *= sq[i];
  return { c, m: a ^ b };
}
export const bracket = (a, b, sq) => { const p = bitMul(a, b, sq), q = bitMul(b, a, sq); return { c: p.c - q.c, m: p.m }; };

// the tangent algebra of the tube r = const is Cl(T, -1, -1): bit 0 is the time bit (square T = g_tt), bits 1 and 2 are the sphere.
// K1 = e0 e1 (label 3), K2 = e0 e2 (label 5), J = e1 e2 (label 6): the even corners of the 3-cube
export const KJ = { K1: 3, K2: 5, J: 6 };
export function tube(T) {
  const sq = [T, -1, -1, 0, 0, 0, 0, 0];
  return {
    sq: { K1: bitMul(3, 3, sq).c, K2: bitMul(5, 5, sq).c, J: bitMul(6, 6, sq).c },
    JK1: bracket(6, 3, sq), JK2: bracket(6, 5, sq), K1K2: bracket(3, 5, sq),
    kind: Math.abs(T) < 1e-12 ? 'iso2' : T > 0 ? 'so12' : 'so3',
  };
}

// ---- 3a: the five horizons of S12.1 (regular chart ds^2 = T dv^2 + 2 dv dx - r^2 dOmega^2), in the order of the script's data
export const HORIZONS = [
  { id: 'schw', xh: 3, T: x => 1 - 3 / x },
  { id: 'rn_out', xh: 2, T: x => (1 - 2 / x) * (1 - 1 / x) },
  { id: 'rn_in', xh: 1, T: x => (1 - 2 / x) * (1 - 1 / x) },
  { id: 'extremal', xh: 1, T: x => (1 - 1 / x) ** 2 },
  { id: 'areal', xh: 2, T: x => (x - 2) * (x + 1) / (x + 3) },
];
export const PROBE = 0.6;                                               // the probe moves over x_h +- 0.6
export const kappaNum = h => { const e = 1e-6; return (h.T(h.xh + e) - h.T(h.xh - e)) / (4 * e); };      // kappa = (1/2) dT/dx
export const tMax = h => { let m = 0; for (let i = -30; i <= 30; i++) m = Math.max(m, Math.abs(h.T(h.xh + PROBE * i / 30))); return m; };
// the null directions of the cone in the chart (v, x): N1 = d_x, N2 = d_v - (T/2) d_x; the surface x = const has tangent d_v with squared length T and normal dx with n.n = -T
export const surfaceKind = T => (Math.abs(T) < 1e-12 ? 'null' : T > 0 ? 'timelike' : 'spacelike');
export const gramTortoise = T => ({ det: -T * T });                       // diag(T, -T)
export const gramEF = () => ({ det: -1 });                                // [[T, 1], [1, 0]]
// the mirror in the normal covector n = dx: w -> w - 2 (n.w)/(n.n) n#, with n# = g^{-1} n = (1, -T); n.n = -T
export function mirrorImage(w, T) {
  if (Math.abs(T) < 1e-12) return null;
  const k = 2 * w[1] / T;                                                // n.w = w^x and n.n = -T, so w' = w + (2 w^x / T) (1, -T)
  return [w[0] + k, w[1] - k * T];
}

// ---- 3a: horizon or throat. Schwarzschild r_S = 1, T = 1 - 1/r, R = 1/T; Ellis: T = 1, R = 1/(1 - 1/r^2), r^2 = 1 + l^2
export const schwT = r => 1 - 1 / r;
export const kruskalX = (r, T) => Math.sqrt((r - 1) * Math.exp(r) + T * T);              // X^2 - T^2 = (r - 1) e^r, exterior
export const ellisL = r => Math.sqrt(r * r - 1);
export const invariants = {                                              // |n.n| and |g^rr| as functions of r
  schw: r => ({ n2: schwT(r), grr: schwT(r) }),                           // T R = 1, so g^rr = n.n / (T R) = -T
  ellis: r => ({ n2: 1, grr: 1 - 1 / (r * r) }),                          // n.n = -1 while g^rr = -1/R = -(1 - 1/r^2)
};
export const rates = {                                                   // (dr/dv)^2 = T/(4R) and (dl/dv)^2 = T/4
  schw: { dr: r => 0.5 * schwT(r), dl: r => 0.5 * Math.sqrt(schwT(r)) },
  ellis: { dr: r => 0.5 * Math.sqrt(1 - 1 / (r * r)), dl: () => 0.5 },
};

// ---- 3b: Vollick's Eq. (1) = T (dT/dx)^2 up to sign, for three surfaces that are all null (n = dx has n.n = -T = 0 there)
export const EQ1 = [
  { id: 'simple', T: x => x, dT: () => 1, eq1: x => x },
  { id: 'extremal', T: x => x * x, dT: x => 2 * x, eq1: x => 4 * x ** 4 },
  { id: 'eq18', T: x => Math.cbrt(3 * x), dT: x => Math.pow(3 * x, -2 / 3), eq1: x => 1 / (3 * x) },
];
export const Ffac = (c, x) => -(c.dT(x) ** 2) / 2;                       // F = grad xi . grad xi = -2 kappa^2 with kappa = dT/dx / 2

// ---- 3b: Kerr M = 5, a = 3. w = cos^2 theta. r_+ = 9; the ergosurface g_tt = 0 is r_E = M + sqrt(M^2 - a^2 w)
export const KERR = { M: 5, a: 3, rh: 9 };
export const kerrErgo = w => KERR.M + Math.sqrt(KERR.M ** 2 - KERR.a ** 2 * w);
export const kerrGtt = (r, w) => 1 - 2 * KERR.M * r / (r * r + KERR.a ** 2 * w);
export function kerrNN(w) {                                              // n.n of the normal to g_tt = const, on the ergosurface: -(Delta f_r^2 + 4 w (1 - w) f_w^2) / Sigma
  const { M, a } = KERR, r = kerrErgo(w), Sig = r * r + a * a * w, Dl = r * r - 2 * M * r + a * a;
  const fr = 2 * M * (r * r - a * a * w) / (Sig * Sig), fw = 2 * M * r * a * a / (Sig * Sig);
  return -(Dl * fr * fr + 4 * w * (1 - w) * fw * fw) / Sig;
}
export const kerrXZ = (r, th) => [Math.sqrt(r * r + KERR.a ** 2) * Math.sin(th), r * Math.cos(th)];     // oblate coordinates of the meridian plane

// ---- 4: the ladder. The tangent algebra of a null hypersurface in n dimensions is Cl(0, n-2, 1); the null bit is the top bit of the label
export const NS = [2, 3, 4, 5, 6];
export const QUOT = { 2: 'ℝ', 3: 'ℂ', 4: 'ℍ', 5: 'ℍ ⊕ ℍ', 6: 'M₂(ℍ)' };                                 // Cl(0, n-2); n = 6 is the textbook classification, not in the script
export const CELL = { 2: 'Cl(1,1) = M₂(ℝ)', 3: 'Cl(1,2) = M₂(ℂ)', 4: 'Cl(1,3) = M₂(ℍ)', 5: 'Cl(1,4) = M₂(ℍ) ⊕ M₂(ℍ)', 6: 'Cl(1,5) = M₄(ℍ)' };
export const bitName = (n, i) => (i === n - 2 ? 'ℓ' : 'e' + (i + 1));        // bits 0 .. n-3 are e1 .. e_{n-2}, bit n-2 is the null bit
export const blade = (n, S) => { const m = n - 1; const names = []; if (S >> (m - 1) & 1) names.push('ℓ'); for (let i = 0; i < m - 1; i++) if (S >> i & 1) names.push('e' + (i + 1)); return names.join('') || '1'; };
export const inJ = (n, S) => !!(S >> (n - 2) & 1);                       // the blades through the null bit: the ideal J
export const choose = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 0; i < k; i++) r = r * (n - i) / (i + 1); return Math.round(r); };
export const isPow2 = x => x > 0 && (x & (x - 1)) === 0;
