// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Mutation check for the contact form. Each entry below breaks the guard, the route or the puzzle in one small way, in a temporary copy of the files; test_contact.mjs is then run
// against that copy and must fail. The files in the package are never touched (their checksums are compared before and after) and the temporary folder is removed at the end,
// also when this script is interrupted. Set CONTACT_MUT_TMP to choose where the copies go; by default the system temporary folder.
import fs from 'fs'; import os from 'os'; import path from 'path'; import crypto from 'crypto';
import { spawnSync } from 'child_process';
import { PKG } from './paths.mjs';
const HERE = PKG;   // the package folder (fileURLToPath: a URL's .pathname keeps %20 for a space and broke a path with one)
const FILES = ['lib/contactGuard.js', 'api/contact.js', 'contactCopy.js', 'ContactForm.jsx', 'App.jsx', 'test_contact.mjs', 'README_update_contact.md'];
const G = 'lib/contactGuard.js', R = 'api/contact.js';
const MUTATIONS = [
  // the ones asked for
  ['skip the HMAC compare', G, 'if (!safeEqual(enc.encode(tag),', 'if (false && !safeEqual(enc.encode(tag),'],
  ['drop the expiry check', G, "if (now >= exp * 1000) return { ok: false, reason: 'expired' };", "if (false) return { ok: false, reason: 'expired' };"],
  ['ignore the honeypot (route)', R, 'honeypotTripped(body.website)', 'false'],
  ['ignore the honeypot (helper)', G, 'export const honeypotTripped = v => !(', 'export const honeypotTripped = v => false && !('],
  ['drop the origin check (route)', R, 'if (!originAllowed(request))', 'if (false)'],
  ['leak the answer in the puzzle response', R, '{ token, question: puzzle.question[lang],', '{ token, answer: puzzle.answer, question: puzzle.question[lang],'],
  ['allow replay (never record the nonce)', R, 'if (!used.add(v.nonce, v.exp * 1000, now))', 'if (false)'],
  ['allow replay (the store forgets at once)', G, 'seen.set(nonce, expMs); return true;', 'return true;'],
  ['drop the rate limit (route)', R, 'if (!rate.ok)', 'if (false)'],
  ['skip the minimum fill check', R, 'if (tooFast(v.issuedAt, now))', 'if (false)'],
  // more
  ['minimum fill time set to zero', G, 'export const MIN_FILL_MS = 4000;', 'export const MIN_FILL_MS = 0;'],
  ['token lifetime of 100 minutes', G, 'export const TOKEN_LIFETIME_S = 600;', 'export const TOKEN_LIFETIME_S = 6000;'],
  ['replay check in the verifier removed', G, 'if (used && used.has(nonce, now))', 'if (false)'],
  ['per-instance limit removed', G, 'if (global.n >= perInstance)', 'if (false)'],
  ['per-client limit removed', G, 'return b.n >= perClient ?', 'return false ?'],
  ['origin rule accepts everything', G, 'return o.host === new URL(request.url).host || extra.includes(o.origin);', 'return true;'],
  ['a request without Origin always passes', G, "return request.headers.get('sec-fetch-site') === 'same-origin';", 'return true;'],
  ['content type not checked', R, "if (!/^application\\/json\\b/i.test(request.headers.get('content-type') || ''))", 'if (false)'],
  ['body cap not enforced on a stream', G, 'total += value.byteLength; if (total > max)', 'total += value.byteLength; if (false)'],
  ['a one-character message is enough', G, 'n < LIMITS.messageMin', 'n < 1'],
  ['http endpoint accepted', G, "u.protocol !== 'https:'", 'false'],
  ['a one-character secret is enough', G, 'secret.length < 16', 'secret.length < 1'],
  ['the XOR answer is an OR', G, 'answer: a ^ b,', 'answer: a | b,'],
  ['control characters kept', G, 'const HIDDEN_RE = new RegExp(', 'const HIDDEN_RE = /(?!)/g; const unusedRe = new RegExp('],
  ['every token has the same nonce', G, 'globalThis.crypto.getRandomValues(new Uint8Array(16))', 'new Uint8Array(16)'],
  ['leading zeros change the answer', G, 'String(Number(s))', 's'],
  ['the message is logged on failure', R, "console.error('contact: form service failure', error?.name || 'error');", "console.error('contact: form service failure', error?.name || 'error', body.message);"],
  ['the endpoint is logged on a bad status', R, "console.error('contact: form service status', upstream.status);", "console.error('contact: form service status', upstream.status, cfg.endpoint);"],
  ['the upstream status is echoed', R, 'if (!upstream.ok) {', "if (!upstream.ok) { return json(502, { error: 'delivery_failed', status: upstream.status });"],
  ['unknown fields are forwarded', R, "page: 'cascade-atlas' })", "page: 'cascade-atlas', _next: body._next })"],
  ['the puzzle response may be cached', R, "'cache-control': 'no-store',", "'cache-control': 'public, max-age=60',"],
  ['a CORS header is sent', R, "'vary': 'Origin' };", "'vary': 'Origin', 'access-control-allow-origin': '*' };"],
  ['"not configured" names the missing setting (GET)', R, "return cfg ? issue(request, cfg) : json(503, { error: 'not_configured' });", "return cfg ? issue(request, cfg) : json(503, { error: 'not_configured', missing: 'FORMSPREE_ENDPOINT' });"],
  ['"not configured" names the missing setting (POST)', R, "if (!cfg) return json(503, { error: 'not_configured' });", "if (!cfg) return json(503, { error: 'not_configured', missing: 'CONTACT_SECRET' });"],
  ['a refused message still uses up the allowance', R, 'const fields = validateFields(body);', 'limiter.hit(key); const fields = validateFields(body);'],
  ['no timeout on the form service call', R, 'signal: AbortSignal.timeout(10000),', 'signal: undefined,'],
];

const sha = f => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const originals = Object.fromEntries(FILES.filter(f => fs.existsSync(path.join(HERE, f))).map(f => [f, sha(path.join(HERE, f))]));
const base = fs.mkdtempSync(path.join(process.env.CONTACT_MUT_TMP || os.tmpdir(), 'contact-mut-'));
const cleanup = () => { try { fs.rmSync(base, { recursive: true, force: true }); } catch { /* already gone */ } };
process.on('exit', cleanup); for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { cleanup(); process.exit(130); });

function copyTo(dir, mutation) {
  fs.mkdirSync(dir, { recursive: true });
  for (const f of Object.keys(originals)) { fs.mkdirSync(path.dirname(path.join(dir, f)), { recursive: true }); fs.copyFileSync(path.join(HERE, f), path.join(dir, f)); }
  fs.writeFileSync(path.join(dir, 'package.json'), '{"type":"module"}');
  if (!mutation) return null;
  const [, file, from, to] = mutation, p = path.join(dir, file), src = fs.readFileSync(p, 'utf8'), parts = src.split(from);
  if (parts.length !== 2) return `the text to break was found ${parts.length - 1} times in ${file}`;
  fs.writeFileSync(p, parts.join(to)); return null;
}
function run(dir) {
  const env = { ...process.env }; for (const k of ['FORMSPREE_ENDPOINT', 'CONTACT_SECRET']) delete env[k];
  const r = spawnSync(process.execPath, ['test_contact.mjs'], { cwd: dir, env, encoding: 'utf8', timeout: 120000 });
  return { code: r.status, out: (r.stdout || '') + '\n' + (r.stderr || ''), signal: r.signal };
}

let survived = 0, applied = 0; const rows = [];
{ const dir = path.join(base, 'control'); const err = copyTo(dir, null); const r = run(dir);
  if (err || r.code !== 0 || !/ALL \d+ CONTACT CHECKS PASS/.test(r.out)) { console.log('CONTROL RUN FAILED: the unbroken copy does not pass\n' + r.out.slice(-1500)); cleanup(); process.exit(1); }
  console.log('control: the unbroken copy passes (' + r.out.match(/ALL (\d+)/)[1] + ' checks)'); }
for (const [i, m] of MUTATIONS.entries()) {
  const dir = path.join(base, 'm' + i), err = copyTo(dir, m);
  if (err) { console.log(`NOT APPLIED  ${m[0]}: ${err}`); survived++; rows.push([m[0], 'not applied']); continue; }
  applied++; const r = run(dir), fails = r.out.split('\n').filter(l => l.startsWith('FAIL ')), summary = (r.out.match(/(\d+) FAILURES of (\d+)/) || [])[1];
  const syntax = /SyntaxError/.test(r.out);
  if (r.code === 0) { survived++; console.log(`SURVIVED     ${m[0]}`); rows.push([m[0], 'SURVIVED']); }
  else if (syntax) { survived++; console.log(`BROKEN COPY  ${m[0]}: the change is a syntax error, not a test of the guard`); rows.push([m[0], 'syntax error']); }
  else if (fails.length) { console.log(`caught       ${m[0]}  [${summary || fails.length} failing checks] ${fails[0].slice(0, 110)}`); rows.push([m[0], 'caught']); }
  else { console.log(`caught (crash) ${m[0]}  ${(r.out.trim().split('\n').find(l => /Error/.test(l)) || '').slice(0, 110)}`); rows.push([m[0], 'crash']); }
  fs.rmSync(dir, { recursive: true, force: true });
}
cleanup();
const after = Object.fromEntries(Object.keys(originals).map(f => [f, sha(path.join(HERE, f))]));
const untouched = Object.keys(originals).every(f => after[f] === originals[f]);
console.log(`${untouched ? 'the package files are unchanged' : 'A PACKAGE FILE CHANGED'}; temporary copies ${fs.existsSync(base) ? 'STILL THERE' : 'removed'}`);
const good = survived === 0 && untouched && !fs.existsSync(base) && applied === MUTATIONS.length;
console.log(good ? `ALL ${applied} MUTATIONS CAUGHT` : `${survived} MUTATION(S) NOT CAUGHT of ${MUTATIONS.length}`);
process.exit(good ? 0 : 1);
