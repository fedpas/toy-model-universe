// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The five widgets of the category lens (step 18) in a real browser, through the real route #lenses/category: in English and Italian, for the Young Learner,
// the Physicist and the Mathematician, at 1100 and 375 px, in the dark and the light theme (?theme=light). Every widget is found by data-widget (CW1 ... CW5,
// CategoryWidgetsScript; closed folds around them are opened first) and driven: its controls change its readout to the value that categoryEngine.js and the
// stored output of lens_cat_check.py (categoryWidgetData.js) give; the badge says live = stored where the script covers the case and live beyond it; the twin
// table agrees with the picture; keyboard works; no page error; no horizontal scroll; the Young Learner's widgets carry no formula and no jargon (the lists of
// test_yl_ui.mjs); every tag is one of the four. The engine itself is tested by test_lens_category_widgets.mjs.
// Run: node test_lens_category_widgets_ui.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)   ONLY=en-Physicist-1100-dark limits the run
import fs from 'node:fs';
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
import { setLang } from './ui_helpers.mjs';
import * as E from './categoryEngine.js';
import STORED from './categoryWidgetData.js';
import { CWC } from './categoryWidgetsCopy.js';
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const Y = fs.readFileSync(new URL('./test_yl_ui.mjs', import.meta.url), 'utf8'), SYM = /^const SYMBOLS = \/(.+)\/;$/m.exec(Y)[1], JAR = /^const JARGON = \/(.+)\/i;$/m.exec(Y)[1];
const b = await chromium.launch(); let bad = 0, n = 0;
const ok = (c, m) => { n++; if (!c) { bad++; console.log('FAIL', m); } };
const W = name => `[data-widget="${name}"]`;
const attr = (pg, sel, a) => pg.locator(sel).first().getAttribute(a);
const txt = (pg, sel) => pg.locator(sel).first().innerText().then(t => t.replace(/\s+/g, ' ').trim());
const click = async (pg, sel) => { await pg.locator(sel).first().click(); await pg.waitForTimeout(50); };
const slide = async (pg, sel, v) => { await pg.locator(sel).first().fill(String(v)); await pg.waitForTimeout(60); };
const cell = (pg, w, row, col = 'live') => txt(pg, `${W(w)} [data-row="${row}"] [data-col="${col}"]`);
const pqr = eps => { const x = E.pqrOf(eps); return `${x.p},${x.q},${x.r}`; };

async function open(lang, prof, w, theme, tag) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 }, reducedMotion: 'reduce' }), pg = await ctx.newPage();
  pg.on('pageerror', e => ok(false, `${tag}: page error ${e.message}`)); pg.on('console', m => m.type() === 'error' && ok(false, `${tag} console: ${m.text()}`));
  await pg.goto(APP + (theme === 'light' ? '?theme=light' : '') + '#lenses/category'); await pg.waitForTimeout(300);
  if (lang === 'it') await setLang(pg, 'it');
  await pg.locator(`[data-profile="${prof}"]`).first().click(); await pg.waitForTimeout(250);
  await pg.evaluate(() => document.querySelectorAll('[data-widget]').forEach(w => { for (let e = w.parentElement; e; e = e.parentElement) if (e.tagName === 'DETAILS') e.open = true; }));
  await pg.waitForTimeout(100);
  return [ctx, pg];
}
// what every view must satisfy: the five widgets, badges, tags, live regions, no horizontal scroll, the theme
async function common(pg, lang, prof, theme, tag) {
  for (const w of ['CW1', 'CW2', 'CW3', 'CW4', 'CW5']) {
    ok(await pg.locator(W(w)).count() === 1, `${tag}: one ${w}`);
    ok(await pg.locator(`${W(w)}.ln-card`).count() === 1, `${tag}: ${w} is a card (ln-card)`);
    const badge = await attr(pg, `${W(w)} .ln-live`, 'data-badge'), bt = await txt(pg, `${W(w)} .ln-live`);
    ok(badge === 'match' && bt === CWC[lang].badge.match, `${tag}: ${w} opens with the badge live = stored (${badge}: ${bt})`);
    const tags = await pg.locator(`${W(w)} .eq-pt .tag`).evaluateAll(es => es.map(e => [...e.classList].filter(c => c !== 'tag').join(' ')));
    ok(tags.length >= 1 && tags.every(t => ['checked', 'standard', 'ours', 'open'].includes(t)), `${tag}: ${w} captions carry the four tags only: ${tags.join(',')}`);
    ok(await pg.locator(`${W(w)} [aria-live="polite"]`).count() >= 1, `${tag}: ${w} has a live region`);
    ok(await pg.locator(`${W(w)} :is(.ln-tab,[data-twin])`).count() === (prof === 'Young Learner' ? 0 : w === 'CW3' ? 1 : 1), `${tag}: ${w} has its twin table only for the formal readers`);
    ok(prof === 'Young Learner' ? await pg.locator(`${W(w)} .ln-id`).count() === 0 : await pg.locator(`${W(w)} .ln-id`).count() >= 4, `${tag}: ${w} names its check ids only for the formal readers`);
  }
  const unnamed = await pg.locator('[data-widget] :is(button,input,[role=button])').evaluateAll(es => es.filter(e => !(e.getAttribute('aria-label') || e.textContent.trim())).length);
  ok(unnamed === 0, `${tag}: every control has a name (${unnamed} without)`);
  const ov = await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  ok(ov <= 1, `${tag}: no horizontal page scroll (${ov}px)`);
  ok(await pg.evaluate(() => document.documentElement.getAttribute('data-theme')) === (theme === 'light' ? 'light' : 'dark'), `${tag}: theme ${theme}`);
  if (prof === 'Young Learner') {
    const hits = await pg.evaluate(([s, j]) => { const S = new RegExp(s, 'u'), J = new RegExp(j, 'i'), out = [], vis = el => { try { return el.checkVisibility({ checkVisibilityCSS: true }); } catch { return true; } };
      for (const w of document.querySelectorAll('[data-widget]')) { const tw = document.createTreeWalker(w, NodeFilter.SHOW_TEXT);
        for (let nd = tw.nextNode(); nd; nd = tw.nextNode()) { const t = nd.nodeValue.replace(/\s+/g, ' ').trim(), el = nd.parentElement; if (!t || !el || el.closest('style,script') || !vis(el)) continue; const c = t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' '); if (S.test(c) || J.test(c)) out.push(t.slice(0, 80)); }
        for (const el of w.querySelectorAll('[aria-label],[title],title')) { const t = el.tagName === 'title' ? el.textContent : (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || ''), c = t.replace(/\b[\w.\/-]+\.(py|mjs|js|jsx|json|md|html|txt|sh)\b/g, ' '); if (S.test(c) || J.test(c)) out.push('attr: ' + t.slice(0, 80)); } }
      return out; }, [SYM, JAR]);
    ok(hits.length === 0, `${tag}: the Young Learner's widgets carry no formula and no jargon: ${hits.slice(0, 4).join(' | ')}`);
  }
}

// ---------------------------------------------------------------- the Young Learner
async function plain(pg, lang, tag) {
  const t = CWC[lang];
  // CW1: three switches plus, plus, zero: 4 of 8 corners lit, multiply 2 of them
  let eps = [1, 1, 0], c = E.labelCard(eps);
  const count = async () => [await attr(pg, `${W('CW1')} [data-out="count"]`, 'data-lit'), await attr(pg, `${W('CW1')} [data-out="count"]`, 'data-all'), await attr(pg, `${W('CW1')} [data-out="count"]`, 'data-k')].map(Number);
  ok(JSON.stringify(await count()) === JSON.stringify([c.J, c.dim, c.r + 1]) && c.J === 4, `${tag} CW1: 4 of 8 corners hold a zero switch, multiply 2: ${await count()}`);
  ok(await txt(pg, `${W('CW1')} [data-out="count"]`) === t.cw1.yl.count(4, 8, 2), `${tag} CW1: the readout sentence`);
  await click(pg, `${W('CW1')} [data-switch="1"]`); await click(pg, `${W('CW1')} [data-switch="1"]`); await click(pg, `${W('CW1')} [data-add]`);
  eps = [1, 0, 0, 1]; c = E.labelCard(eps);
  ok(JSON.stringify(await count()) === JSON.stringify([c.J, c.dim, c.r + 1]) && c.J === 12, `${tag} CW1: switches plus, zero, zero, plus: ${await count()} (engine ${c.J}, ${c.dim}, ${c.r + 1})`);
  const lit = await pg.locator(`${W('CW1')} [data-corner] circle[fill="#fbbf24"]`).count(); ok(lit === c.J, `${tag} CW1: the picture lights ${lit} corners, the readout says ${c.J}`);
  ok(Number(await attr(pg, `${W('CW1')} [data-out="clock"]`, 'data-place')) === E.clockPlace(eps) && Number(await attr(pg, `${W('CW1')} svg[data-place]`, 'data-place')) === 2, `${tag} CW1: the clock hand at place 2 (two plus switches, zero switches leave it)`);
  await click(pg, `${W('CW1')} [data-fill]`);
  ok(await attr(pg, `${W('CW1')} [data-out="tray"]`, 'data-size') === '3' && await attr(pg, `${W('CW1')} [data-out="tray"]`, 'data-sign') === '0', `${tag} CW1: three lit corners in the tray multiply to nothing`);
  await click(pg, `${W('CW1')} [data-empty]`);
  const first = pg.locator(`${W('CW1')} [data-corner][aria-pressed]`).filter({ has: pg.locator('circle[fill="#fbbf24"]') }).first(); await first.focus(); await pg.keyboard.press('Enter'); await pg.waitForTimeout(60);
  ok(await attr(pg, `${W('CW1')} [data-out="tray"]`, 'data-size') === '1', `${tag} CW1: Enter on a focused lit corner puts it in the tray`);
  ok(STORED.P3[pqr(eps)].J === c.J && await attr(pg, `${W('CW1')} .ln-live`, 'data-badge') === 'match', `${tag} CW1: live = stored for the new box`);
  // CW2: corner 100 and its opposite 011; swap keeps the sign (three switches); add a plus switch: no fair pairing, and the sign flips for one switch on
  let f = E.frobenius([1, 1, 0]);
  ok(await attr(pg, `${W('CW2')} [data-out="pair"]`, 'data-b') === '6' && Number(await attr(pg, `${W('CW2')} [data-out="pair"]`, 'data-sign')) === f.pairs[1].ab, `${tag} CW2: corner 100 pairs with 011, sign ${f.pairs[1].ab}`);
  await click(pg, `${W('CW2')} [data-swap]`); ok(await attr(pg, `${W('CW2')} [data-out="swap"]`, 'data-same') === '1', `${tag} CW2: odd number of switches: swapping keeps the sign`);
  ok(await attr(pg, `${W('CW2')} [data-out="fair"]`, 'data-fair') === '1', `${tag} CW2: plus, plus, zero has a fair pairing`);
  await click(pg, `${W('CW2')} [data-add]`); f = E.frobenius([1, 1, 0, 1]);
  ok(await attr(pg, `${W('CW2')} [data-out="fair"]`, 'data-fair') === '0' && !f.fair, `${tag} CW2: three plus and one zero switch (step 9): no fair pairing`);
  await pg.locator(`${W('CW2')} [data-corner="1"]`).first().focus(); await pg.keyboard.press(' '); await click(pg, `${W('CW2')} [data-swap]`);
  ok(await attr(pg, `${W('CW2')} [data-out="swap"]`, 'data-same') === '0' && f.pairs[1].ab !== f.pairs[1].ba, `${tag} CW2: even number of switches, one switch on: the sign flips`);
  ok(await pg.locator(`${W('CW2')} [data-pairline]`).count() === 1, `${tag} CW2: the corner and its opposite are joined by a line`);
  await click(pg, `${W('CW2')} [data-corner="4"]`); ok(await attr(pg, `${W('CW2')} [data-out="self"]`, 'data-v') === '0', `${tag} CW2: the corner of the zero switch times itself is nothing`);
  // CW3: plus, zero, zero -> halve -> join zero -> halve jams -> join plus -> halve -> forget -> join minus
  const last = async () => pg.locator(`${W('CW3')} .cw-trail li`).last().getAttribute('data-pqr');
  await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await last() === '0,0,2', `${tag} CW3: halving plus, zero, zero gives two zero switches: ${await last()}`);
  await click(pg, `${W('CW3')} [data-move="join-zero"]`); ok(await last() === '0,0,3', `${tag} CW3: join a zero switch`);
  await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await attr(pg, `${W('CW3')} [data-out="move"]`, 'data-msg') === 'jam' && await last() === '0,0,3' && STORED.P2.find(x => x.r === 3 && !x.p && !x.q).halves === false, `${tag} CW3: three zero switches: halve jams (stored: fails)`);
  ok(await pg.locator(`${W('CW3')} .cw-jam`).count() === 1, `${tag} CW3: the jam is shown in red`);
  await click(pg, `${W('CW3')} [data-move="join-plus"]`); await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await last() === '0,0,3', `${tag} CW3: with a plus switch the box halves again: ${await last()}`);
  await click(pg, `${W('CW3')} [data-move="forget"]`); ok(await last() === '0,0,0', `${tag} CW3: forget the zero`);
  await click(pg, `${W('CW3')} [data-move="join-minus"]`); ok(await last() === '0,1,0' && await pg.locator(`${W('CW3')} .cw-trail li`).last().getAttribute('data-clock') === '7', `${tag} CW3: one minus switch sits at clock place 7`);
  await click(pg, `${W('CW3')} [data-move="opposite"]`); ok(await attr(pg, `${W('CW3')} [data-out="move"]`, 'data-msg') === 'opposed' && await last() === '0,1,0', `${tag} CW3: opposite keeps the box`);
  // CW4: rungs 8, 9, 10, 11, 3
  for (const [rung, want] of [[8, [8, 0, 0]], [9, [8, 1, 0]], [10, [9, 0, 1]], [11, [10, 0, 1]], [3, [3, 0, 0]]]) {
    await slide(pg, `${W('CW4')} [data-slider="rung"]`, rung); const R = E.ladderRung(rung, false), got = ['data-pos', 'data-zero', 'data-neg'].map(a => attr(pg, `${W('CW4')} [data-out="rung"]`, a));
    const g = (await Promise.all(got)).map(Number); ok(JSON.stringify(g) === JSON.stringify(want) && JSON.stringify([R.inertia[0], R.inertia[2], R.inertia[1]]) === JSON.stringify(want), `${tag} CW4: rung ${rung}: plus, zero, minus = ${g}`);
    ok(Number(await attr(pg, `${W('CW4')} svg[data-dots]`, 'data-dots')) === rung, `${tag} CW4: the drawing of rung ${rung} has ${rung} dots`); }
  // CW5: 2 and 1 give 3; 1 and 1 give nothing; the two zero mixes add to 4; the lone zero has no partner
  ok(await attr(pg, `${W('CW5')} [data-out="mix"]`, 'data-v') === '3', `${tag} CW5: 2 plus and 1 minus: 3`);
  await slide(pg, `${W('CW5')} [data-slider="a"]`, 1); ok(await attr(pg, `${W('CW5')} [data-out="mix"]`, 'data-v') === '0', `${tag} CW5: 1 and 1: a zero direction`);
  await slide(pg, `${W('CW5')} [data-slider="b"]`, -3); ok(await attr(pg, `${W('CW5')} [data-out="mix"]`, 'data-v') === '-8', `${tag} CW5: 1 and −3: −8`);
  await click(pg, `${W('CW5')} [data-show="pair"]`); ok(await attr(pg, `${W('CW5')} [data-out="pair"]`, 'data-sum') === '4', `${tag} CW5: the two zero mixes add to 4`);
  await click(pg, `${W('CW5')} [data-show="lone"]`); ok(await attr(pg, `${W('CW5')} [data-out="lone"]`, 'data-all-zero') === '1', `${tag} CW5: the lone zero switch: always nothing`);
}

// ---------------------------------------------------------------- the Physicist and the Mathematician
async function formal(pg, lang, tag) {
  const t = CWC[lang];
  // CW1: Cl(3,0,1) -> Cl(0,0,3) -> Cl(5,0,3) (beyond the stored range) -> Cl(0,2,1)
  const card = async sig => { const c = E.labelCard(E.sigOf(...sig)), st = STORED.P3[sig.join(',')];
    ok(await cell(pg, 'CW1', 'J') === String(c.J) && await cell(pg, 'CW1', 'layers') === c.layers.join(', ') && await cell(pg, 'CW1', 'loewy') === String(sig[2] + 1) && await cell(pg, 'CW1', 'sc') === String(2 ** sig[2]), `${tag} CW1 ${sig}: J ${c.J}, layers ${c.layers}, Loewy ${sig[2] + 1}, super-centre ${2 ** sig[2]}`);
    ok(await cell(pg, 'CW1', 'J', 'says') === String(c.t2.J) && (st ? await cell(pg, 'CW1', 'J', 'stored') === String(st.J) : await cell(pg, 'CW1', 'J', 'stored') === '—'), `${tag} CW1 ${sig}: T2 says ${c.t2.J}; stored ${st ? st.J : 'none'}`);
    const shaded = await pg.locator(`${W('CW1')} svg [data-corner] .cw-ring:not([fill="none"])`).count(); ok(shaded === c.J, `${tag} CW1 ${sig}: the picture shades ${shaded} labels, the table says ${c.J}`);
    ok(await attr(pg, `${W('CW1')} .ln-live`, 'data-badge') === (st ? 'match' : 'beyond'), `${tag} CW1 ${sig}: badge ${st ? 'live = stored' : 'live, beyond the stored range'}`); };
  await card([3, 0, 1]); ok(await attr(pg, `${W('CW1')} [data-out="face"]`, 'data-r') === '1', `${tag} CW1: r = 1, J is a face`);
  await click(pg, `${W('CW1')} [data-preset="0,0,3"]`); await card([0, 0, 3]); ok((await txt(pg, `${W('CW1')} [data-out="face"]`)) === t.cw1.pm.face(3), `${tag} CW1: r = 3, J is the complement of a face`);
  for (let i = 0; i < 5; i++) await click(pg, `${W('CW1')} [data-inc="p"]`);
  await card([5, 0, 3]); ok(await attr(pg, `${W('CW1')} svg[data-layout]`, 'data-layout') === 'grid' && await pg.locator(`${W('CW1')} [data-inc="p"]`).isDisabled(), `${tag} CW1: n = 8 drawn as a grid; no ninth generator`);
  await click(pg, `${W('CW1')} [data-preset="0,2,1"]`); await card([0, 2, 1]);
  // CW2: Cl(3,0,1): Frobenius, not symmetric; Cl(3,0): symmetric
  const frob = async sig => { const f = E.frobenius(E.sigOf(...sig)), st = STORED.P4[sig.join(',')];
    ok(await cell(pg, 'CW2', 'rankL') === String(f.rankLam) && await cell(pg, 'CW2', 'rank0') === String(f.rank0) && await cell(pg, 'CW2', 'rankEF') === String(f.rankEF) && await cell(pg, 'CW2', 'rankL', 'stored') === String(st.rank_lam), `${tag} CW2 ${sig}: ranks ${f.rankLam}, ${f.rank0}, ${f.rankEF}`);
    ok(Number(await attr(pg, `${W('CW2')} svg[data-gram="lambda"]`, 'data-nonzero')) === f.rankLam && Number(await attr(pg, `${W('CW2')} svg[data-gram="scalar"]`, 'data-nonzero')) === f.rank0, `${tag} CW2 ${sig}: the Gram pictures have as many entries as the ranks`);
    ok(await attr(pg, `${W('CW2')} svg[data-nak]`, 'data-nak') === STORED.P4_nakayama[sig[0] + sig[1] + sig[2]], `${tag} CW2 ${sig}: the Nakayama strip = stored`);
    ok(await cell(pg, 'CW2', 'sym') === t.cw2.pm.symVal(f.cert), `${tag} CW2 ${sig}: symmetric form: ${f.cert}`); };
  await frob([3, 0, 1]); ok(/e4, e1234|e₄, e₁₂₃₄/.test((await cell(pg, 'CW2', 'conj')).replace(/\s+/g, '')) || (await cell(pg, 'CW2', 'conj')).includes('1234'), `${tag} CW2: the conjugators of α in Cl(3,0,1) are e4 and e1234`);
  await click(pg, `${W('CW2')} [data-preset="3,0,0"]`); await frob([3, 0, 0]);
  await click(pg, `${W('CW2')} [data-inc="r"]`); await frob([3, 0, 1]);
  // CW3: Cl(1,3) halved via a minus generator (Cl(1,2)) and via the plus one (Cl(3,0)); doubled with a null; faces; down to Cl(0,0,3), where halving fails
  const box = () => attr(pg, `${W('CW3')} [data-out="box"]`, 'data-pqr');
  ok(await box() === '1,3,0', `${tag} CW3: starts at Cl(1,3)`);
  await click(pg, `${W('CW3')} [data-t="1"]`); await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await box() === '1,2,0', `${tag} CW3: Cl⁰(1,3) via a square −1: Cl(1,2): ${await box()}`);
  await click(pg, `${W('CW3')} [data-move="reset"]`); await click(pg, `${W('CW3')} [data-t="0"]`); await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await box() === '3,0,0', `${tag} CW3: via the square +1: Cl(3,0)`);
  await click(pg, `${W('CW3')} [data-partner="0,0,1"]`); await click(pg, `${W('CW3')} [data-move="double"]`); ok(await box() === '3,0,1' && /✓/.test(await txt(pg, `${W('CW3')} [data-out="move"]`)), `${tag} CW3: doubled with a null: Cl(3,0,1), Koszul sign ✓`);
  const face = async () => ['data-iota', 'data-pi', 'data-crit'].map(a => attr(pg, `${W('CW3')} [data-out="face"]`, a));
  await click(pg, `${W('CW3')} [data-face="3"]`); let fv = await Promise.all(await face()); ok(fv.join() === '1,1,1', `${tag} CW3: T without the null generator: pi_T a homomorphism: ${fv}`);
  await click(pg, `${W('CW3')} [data-face="0"]`); fv = await Promise.all(await face()); ok(fv.join() === '1,0,0' && await pg.locator(`${W('CW3')} [data-move="face"]`).isDisabled(), `${tag} CW3: T without e1 (square +1): not a homomorphism, cannot be applied: ${fv}`);
  await click(pg, `${W('CW3')} [data-move="forget"]`); fv = await Promise.all(await face()); ok(fv.join() === '1,1,1', `${tag} CW3: T = the non-null generators`);
  await click(pg, `${W('CW3')} [data-move="face"]`); ok(await box() === '3,0,0', `${tag} CW3: pi_T onto Cl/J = Cl(3,0)`);
  await click(pg, `${W('CW3')} [data-move="complement"]`); ok(await attr(pg, `${W('CW3')} [data-out="move"]`, 'data-msg') === 'comp' && /✓/.test(await txt(pg, `${W('CW3')} [data-out="move"]`)), `${tag} CW3: the complement reverses inclusion ✓`);
  await click(pg, `${W('CW3')} [data-move="reset"]`);
  for (let i = 0; i < 3; i++) { await click(pg, `${W('CW3')} [data-t="1"]`); await click(pg, `${W('CW3')} [data-move="halve"]`); }
  ok(await box() === '1,0,0', `${tag} CW3: Cl(1,3) halved three times via minus: Cl(1,0): ${await box()}`);
  await click(pg, `${W('CW3')} [data-partner="0,0,1"]`); for (let i = 0; i < 3; i++) await click(pg, `${W('CW3')} [data-move="double"]`);
  await click(pg, `${W('CW3')} [data-t="0"]`); await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await box() === '0,0,3', `${tag} CW3: Cl(1,0,3) halved: Cl(0,0,3)`);
  await click(pg, `${W('CW3')} [data-move="halve"]`); ok(await attr(pg, `${W('CW3')} [data-out="move"]`, 'data-msg') === 'jam' && await box() === '0,0,3', `${tag} CW3: Cl(0,0,3): halving fails`);
  ok(await pg.locator(`${W('CW3')} [data-table="moves"] tbody tr`).count() === 5, `${tag} CW3: the table of the moves has five rows`);
  // CW4: n = 9 (affine, marks), 10 (hyperbolic), 20 (Lorentzian), 3
  for (const nn of [9, 10, 20, 3]) { if (nn !== 9) await slide(pg, `${W('CW4')} [data-slider="n"]`, nn); const R = E.ladderRung(nn), st = STORED.P5.find(x => x.n === nn);
    ok(await attr(pg, `${W('CW4')} [data-out="rung"]`, 'data-det') === String(9 - nn) && await attr(pg, `${W('CW4')} [data-out="rung"]`, 'data-inertia') === st.inertia.join(',') && await attr(pg, `${W('CW4')} [data-out="rung"]`, 'data-type') === st.type, `${tag} CW4 E${nn}: det ${9 - nn}, inertia ${st.inertia}, ${st.type}`);
    ok(await cell(pg, 'CW4', 'q1') === `${R.q1} · ${R.cl_q1}` && R.q1 === R.cl_q1 && await cell(pg, 'CW4', 'q1', 'stored') === `${st.q1} · ${st.cl_q1}`, `${tag} CW4 E${nn}: q = 1 classes = labels with square −1 (${R.q1})`);
    ok(Number(await attr(pg, `${W('CW4')} svg[data-dots]`, 'data-dots')) === nn && await attr(pg, `${W('CW4')} .ln-live`, 'data-badge') === 'match', `${tag} CW4 E${nn}: ${nn} nodes; live = stored`);
    if (nn === 9) ok(await cell(pg, 'CW4', 'marks') === '(3; 2,4,6,5,4,3,2,1), 30', `${tag} CW4: the null root of E9`); }
  // CW5: 1, 1 -> 0; 3, 1 -> 8; the table: uv + vu = 4, radicals 0, 3, 4
  ok(await attr(pg, `${W('CW5')} [data-out="mix"]`, 'data-v') === '0', `${tag} CW5: u = e1 + e2 is null`);
  await slide(pg, `${W('CW5')} [data-slider="a"]`, 3); ok(await attr(pg, `${W('CW5')} [data-out="mix"]`, 'data-v') === '8', `${tag} CW5: 3 e1 + e2 squares to 8`);
  ok(await cell(pg, 'CW5', 'sum') === '4' && await cell(pg, 'CW5', 'rad') === '0 · 3 · 4' && await cell(pg, 'CW5', 'rad', 'stored') === '0 · 3 · 4', `${tag} CW5: uv + vu = 4; radicals 0, 3, 4 live = stored`);
}

// ---------------------------------------------------------------- CW6 (optional): only when the chapter places it
async function sixth(pg, prof, tag) {
  if (!(await pg.locator(W('CW6')).count())) return;
  const out = async () => [await attr(pg, `${W('CW6')} [data-out="faces"]`, 'data-odd'), await attr(pg, `${W('CW6')} [data-out="gauge"]`, 'data-gauge')].join('|');
  ok(await attr(pg, `${W('CW6')} .ln-live`, 'data-badge') === 'live' && await attr(pg, `${W('CW6')} [data-out="count"]`, 'data-count') === '128' && await attr(pg, `${W('CW6')} [data-out="count"]`, 'data-total') === '4096', `${tag} CW6: live; 128 of 4096 ways make every face odd`);
  ok(await out() === '6|', `${tag} CW6: opens on the rule's signs: six good faces, no corner flipped (${await out()})`);
  await click(pg, `${W('CW6')} [data-edge="0,0"]`); ok(await out() === '4|none' && await pg.locator(`${W('CW6')} [data-good="1"]`).count() === 4, `${tag} CW6: one edge flipped: four good faces, the picture agrees (${await out()})`);
  await click(pg, `${W('CW6')} [data-sign-rule]`); await click(pg, `${W('CW6')} [data-corner="3"]`); await click(pg, `${W('CW6')} [data-sign-flip]`);
  ok(await out() === '6|3', `${tag} CW6: flipping the three edges at corner 110 keeps every face good and names that corner (${await out()})`);
  await pg.locator(`${W('CW6')} [data-edge="1,1"]`).first().focus(); await pg.keyboard.press('Enter'); await pg.waitForTimeout(50); ok((await out()).startsWith('4|'), `${tag} CW6: Enter on a focused edge flips it`);
  ok(await pg.locator(`${W('CW6')} .eq-pt`).count() === (prof === 'Mathematician' ? 2 : 1), `${tag} CW6: the cohomology line for the Mathematician only`);
}

const RUNS = []; for (const lang of ['en', 'it']) for (const prof of ['Young Learner', 'Physicist', 'Mathematician']) for (const w of [1100, 375]) for (const theme of ['dark', 'light']) RUNS.push([lang, prof, w, theme]);
const ONLY = process.env.ONLY;
for (const [lang, prof, w, theme] of RUNS) {
  const tag = `${lang}-${prof.split(' ')[0]}-${w}-${theme}`; if (ONLY && !ONLY.split(',').includes(tag)) continue;
  const [ctx, pg] = await open(lang, prof, w, theme, tag);
  await common(pg, lang, prof, theme, tag);
  if (prof === 'Young Learner') await plain(pg, lang, tag); else await formal(pg, lang, tag);
  await sixth(pg, prof, tag);
  const ov = await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth); ok(ov <= 1, `${tag}: still no horizontal scroll after driving the widgets (${ov}px)`);
  if (w === 1100 && theme === 'dark') {   // keyboard focus is visible; reduced motion keeps the clock hand still
    await pg.locator(`${W('CW1')} button:not([disabled])`).first().focus(); await pg.keyboard.press('Tab'); await pg.waitForTimeout(50);   // a keyboard move, so that :focus-visible applies
    const [ol, inside] = await pg.evaluate(() => [getComputedStyle(document.activeElement).outlineStyle, !!document.activeElement.closest('[data-widget="CW1"]')]); ok(ol !== 'none' && inside, `${tag}: Tab moves to the next control of CW1 and shows its focus ring (${ol}, inside ${inside})`);
    if (prof === 'Young Learner') ok(await pg.locator(`${W('CW1')} .cw-hand`).evaluate(e => getComputedStyle(e).transitionDuration) === '0s', `${tag}: reduced motion: the clock hand does not animate`);
    const sb = pg.locator(W('CategoryWidgetsScript')); if (await sb.count()) ok(/lens_cat_check\.py/.test(await sb.innerText()) && await sb.locator('[data-download]').count() === 1, `${tag}: the script box offers lens_cat_check.py`);
  }
  await ctx.close();
}
await b.close();
console.log(`${n} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL CATEGORY WIDGET UI TESTS PASS'); process.exit(bad ? 1 : 0);
