// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { PKG_DIST } from './paths.mjs';
import { chromium } from 'playwright';
// Layout check: no horizontal page overflow and nothing cut off at the right edge, on every page and every tab, opened by its deep link
// (#page or #page/tab), at 320, 375 and 1280 px, in English and Italian, for the three audiences. Every fold and every expandable table row
// is opened first, so the text behind them counts too. Wide content must sit in its own scroll container (overflow-x:auto).
// v10.2: every view is measured in the dark theme and again in the light theme (?theme=light; THEMES=dark or THEMES=light for one of them).
// Exit code 1 when anything overflows. Run: node layout_check.mjs   (the build is read from <ATLAS_DIST>/app.html; default <package>/dist)
const DIST = process.env.ATLAS_DIST || PKG_DIST, APP = 'file://' + DIST + '/app.html';
const PAGES = ['rule', 'atlas', 'maxwell', 'furey', 'shapes', 'equations', 'labels', 'lenses', 'map', 'researchers', 'ask'], PROFS = ['Young Learner', 'Physicist', 'Mathematician'];
const WIDTHS = (process.env.WIDTHS || '320,375,1280').split(',').map(Number);
const THEMES = (process.env.THEMES || 'dark,light').split(',');
const b = await chromium.launch(); const errs = [], rep = []; let views = 0;
// the deep links: every page, and every tab of the pages that have tabs (read from the page itself)
const links = [];
{ const pg = await b.newPage({ viewport: { width: 1100, height: 900 } });
  for (const p of PAGES) { await pg.goto(APP + '#' + p); await pg.waitForTimeout(200); const ids = await pg.locator('.tabbar [data-tab]').evaluateAll(es => es.map(e => e.dataset.tab)); if (ids.length) ids.forEach(id => links.push(p + '/' + id)); else links.push(p); }
  await pg.close(); }
async function run(lang, w, prof, theme) {
  const ctx = await b.newContext({ viewport: { width: w, height: 900 } });
  await ctx.addInitScript(([l, a]) => { try { localStorage.setItem('atlas.lang', l); localStorage.setItem('atlas.audience', a); } catch { /* ignore */ } }, [lang, prof]);
  const pg = await ctx.newPage(), tag = `${lang} ${w} ${prof} ${theme}`, q = theme === 'light' ? '?theme=light' : '';
  pg.on('pageerror', e => errs.push(`${tag}: ${e.message}`)); pg.on('console', m => m.type() === 'error' && errs.push(`${tag} console: ${m.text()}`));
  for (const link of links) {
    await pg.goto(APP + q + '#' + link); await pg.waitForTimeout(150);
    const set = await pg.evaluate(() => [document.documentElement.lang, document.querySelector('.audience-group .active')?.dataset.profile, document.documentElement.getAttribute('data-theme')]);
    if (set[0] !== lang || set[1] !== prof || set[2] !== theme) errs.push(`${tag} #${link}: settings not applied (${set})`);
    await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(60);
    await pg.evaluate(() => document.querySelectorAll('main button[aria-expanded="false"]').forEach(x => x.click())); await pg.waitForTimeout(120);
    await pg.evaluate(() => document.querySelectorAll('details').forEach(d => { d.open = true; })); await pg.waitForTimeout(120);
    views++;
    const r = await pg.evaluate(() => {
      const W = window.innerWidth, out = { overflow: document.documentElement.scrollWidth - W, clipped: [] };
      const inScroller = e => { for (let p = e.parentElement; p && p !== document.body; p = p.parentElement) { const o = getComputedStyle(p).overflowX; if (o === 'auto' || o === 'scroll' || o === 'hidden' || o === 'clip') return true; } return false; };
      for (const e of document.querySelectorAll('main *')) {
        if (e.closest('svg') && e.tagName !== 'svg') continue;
        const cs = getComputedStyle(e); if (cs.display === 'none' || cs.visibility === 'hidden' || cs.position === 'fixed') continue;
        const q = e.getBoundingClientRect(); if (!q.width || !q.height) continue;
        // a box whose own content runs out of it (a long formula or word in a box that does not scroll) counts as cut off too
        if (!inScroller(e) && cs.overflowX === 'visible' && e.scrollWidth > e.clientWidth + 1 && e.clientWidth > 0 && q.left + e.scrollWidth > W + 1 && ![...e.children].some(c => c.scrollWidth > e.clientWidth + 1)) out.clipped.push(`${e.tagName.toLowerCase()} content ${e.scrollWidth}px in a ${e.clientWidth}px box "${(e.textContent || '').trim().slice(0, 30)}"`);
        if ((q.right > W + 1 || q.left < -1) && !inScroller(e)) out.clipped.push(`${e.tagName.toLowerCase()}.${String(e.className && e.className.baseVal !== undefined ? e.className.baseVal : e.className).split(' ')[0]} [${Math.round(q.left)}, ${Math.round(q.right)}] "${(e.textContent || '').trim().slice(0, 30)}"`);
      }
      out.clipped = [...new Set(out.clipped)];
      return out;
    });
    if (r.overflow > 0 || r.clipped.length) { rep.push(`${tag} #${link}: page overflow ${r.overflow}px, ${r.clipped.length} elements cut off ${JSON.stringify(r.clipped.slice(0, 3))}`); }
  }
  await ctx.close();
}
const jobs = []; for (const theme of THEMES) for (const lang of ['en', 'it']) for (const w of WIDTHS) for (const prof of PROFS) jobs.push([lang, w, prof, theme]);
for (let i = 0; i < jobs.length; i += 6) await Promise.all(jobs.slice(i, i + 6).map(j => run(...j)));
await b.close();
const want = links.length * jobs.length;
if (views !== want) errs.push(`only ${views} of ${want} views measured`);
console.log(rep.length ? rep.join('\n') : `no overflow: ${links.length} deep links × ${WIDTHS.join('/')} px × EN/IT × 3 audiences × ${THEMES.join('/')} theme (${views} views)`);
if (errs.length) console.log(errs.slice(0, 40).join('\n'));
process.exit(rep.length || errs.length ? 1 : 0);
