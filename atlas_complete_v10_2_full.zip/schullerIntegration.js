// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Map, claims and chat-persona plug-in of the Schuller chapter (step 20 of the lenses page); mapData.js, mapCopy.js, lib/chatPersona.js and the lenses page read it.
//   MAP_NODES: the chapter's own node first ({id, go: ['lenses', 'ln-schuller'], script, tags, lens, th}), then one leaf per main section of the chapter
//              (go: ['lenses', 'sc-<section>']); every anchor is an id="..." of SchullerSection.jsx; script = files of the package ('reports/<name>.py' means
//              selfcheck/reports/<name>.py); lens and th are ids already used in mapData.js (LENSES, MTHREADS).
//   MAP_TEXT:  the text of every node, [title, body]: en, it (Physicist and Mathematician) and yl.en, yl.it (Young Learner: plain words, no formulas).
//   PERSONA:   the English paragraph added to the chat persona (lib/chatPersona.js): the chapter's established results, each with its tag; under 1 800 characters.
const S3 = 'reports/fibre_check.py, reports/bridge_check.py, reports/bridge_check_qm.py';
export const MAP_NODES = [
  { id: 'schuller', go: ['lenses', 'ln-schuller'], script: S3, tags: ['checked', 'standard', 'ours', 'open'], lens: ['clifford', 'mirror', 'null', 'flow'], th: ['mirror', 'eight', 'spring'] },
  { id: 'sc_chain', go: ['lenses', 'sc-chain'], script: 'reports/bridge_check.py', tags: ['checked', 'standard', 'ours', 'open'], lens: ['clifford', 'flow'], th: ['spring'] },
  { id: 'sc_table', go: ['lenses', 'sc-table'], script: 'reports/bridge_check.py', tags: ['checked', 'standard', 'ours'], lens: ['clifford', 'null', 'cube'], th: ['cube'] },
  { id: 'sc_hyper', go: ['lenses', 'sc-hyper'], script: 'reports/bridge_check.py', tags: ['checked', 'standard', 'ours'], lens: ['clifford', 'mirror'], th: ['mirror', 'eight'] },
  { id: 'sc_fibre', go: ['lenses', 'sc-fibre'], script: 'reports/fibre_check.py', tags: ['checked', 'standard', 'ours'], lens: ['clifford', 'mirror', 'spinor'], th: ['mirror', 'eight'] },
  { id: 'sc_fock', go: ['lenses', 'sc-fock'], script: 'reports/bridge_check_qm.py', tags: ['checked', 'standard', 'ours'], lens: ['cube', 'clifford', 'null'], th: ['cube', 'i'] },
  { id: 'sc_bands', go: ['lenses', 'sc-bands'], script: 'reports/fibre_check.py', tags: ['checked', 'standard', 'ours'], lens: ['flow', 'null'], th: ['spring'] },
  { id: 'sc_stops', go: ['lenses', 'sc-stops'], script: '—', tags: ['open'], lens: ['flow'], th: ['spring'] },
];
export const MAP_TEXT = {
  en: {
    schuller: ['20 · Schuller: from the algebra to the dynamics', 'Step 20. His constructive gravity goes from the matter action to the principal polynomial, three conditions and closure. The atlas follows the algebraic front exactly (grades S, E, E, S, S, S, A along his chain) and stops where dynamics begins: no action principle, no manifold, no closure equations rebuilt. Three scripts, 163 checks; reading left and right action as base and fibre is ours.'],
    sc_chain: ['His chain, graded', 'The seven stones of his pipeline with the best grade of what the atlas has at each: exact for the principal polynomial and for the first condition with quadratic P, structural in the middle, only our reading at closure.'],
    sc_table: ['One table for forms and Clifford', 'All squares 0 gives the exterior algebra of his geometry lectures, squares ±1 give Cl(p,q): labels, XOR and reorder sign never change. Multiplication by the top blade is a Hodge star only without null generators; the complement stays a Frobenius duality.'],
    sc_hyper: ['Hyperbolicity filters the cells', 'A quadratic principal polynomial is hyperbolic iff its signature is Lorentzian (Thm T18): one class in two conventions, P ↔ −P, while the algebras Cl(1,3) = M₂(ℍ) and Cl(3,1) = M₄(ℝ) differ. Cl(2,2) is the first ultrahyperbolic cell.'],
    sc_fibre: ['Fibre and base as left and right', 'Locally a graded product; the twisted right action is the mirror, and A ⊗̂ mirror(A) = Cl(n,n) = End(A). With the 8 kept fixed, the commutant of Cl(0,k) has dimension 2^{8−k} and the type of the base. The names base and fibre are ours.'],
    sc_fock: ['Fock space and Pauli strings', 'The fermionic Fock space of his quantum notes is the label set: Cl(n,n) = End Λ(ℝⁿ), Pauli exclusion is ε² = 0 and the number operator is the popcount (Thm T20). The Pauli strings of N qubits are the blades up to a phase.'],
    sc_bands: ['Bands as the sign of X²', 'The one-period matrix of a periodic potential is a unit multivector of Cl(2,0): band X² < 0, gap X² > 0, edge X² = 0 with X ≠ 0 (Thm T19). Grouping it with the other places of the trio −1, 0, +1 is ours.'],
    sc_stops: ['Where the rule stops', 'Gluing over a manifold (row L4), an action principle and the closure equations (rows C7, C8), the energy-distinguishing condition (row C12), infinite dimensions and analysis: not reached, and not claimed.'],
  },
  it: {
    schuller: ['20 · Schuller: dall’algebra alla dinamica', 'Passo 20. La sua gravità costruttiva va dall’azione della materia al polinomio principale, a tre condizioni e alla chiusura. L’atlante segue esattamente il fronte algebrico (gradi S, E, E, S, S, S, A lungo la sua catena) e si ferma dove comincia la dinamica: nessun principio d’azione, nessuna varietà, nessuna equazione di chiusura ricostruita. Tre script, 163 controlli; leggere l’azione sinistra e destra come base e fibra è nostro.'],
    sc_chain: ['La sua catena, con i gradi', 'Le sette pietre della sua catena con il grado migliore di ciò che l’atlante ha in ciascuna: esatto per il polinomio principale e per la prima condizione con P quadratico, strutturale al centro, solo una nostra lettura alla chiusura.'],
    sc_table: ['Una tabella per le forme e per Clifford', 'Tutti i quadrati 0 danno l’algebra esterna delle sue lezioni di geometria, quadrati ±1 danno Cl(p,q): etichette, XOR e segno di riordino non cambiano mai. La moltiplicazione per il blade di grado massimo è una stella di Hodge solo senza generatori nulli; il complemento resta una dualità di Frobenius.'],
    sc_hyper: ['L’iperbolicità filtra le celle', 'Un polinomio principale quadratico è iperbolico se e solo se la sua segnatura è lorentziana (Thm T18): una sola classe in due convenzioni, P ↔ −P, mentre le algebre Cl(1,3) = M₂(ℍ) e Cl(3,1) = M₄(ℝ) sono diverse. Cl(2,2) è la prima cella ultraiperbolica.'],
    sc_fibre: ['Fibra e base come sinistra e destra', 'Localmente un prodotto graduato; l’azione destra con il segno del grado è la speculare, e A ⊗̂ speculare(A) = Cl(n,n) = End(A). Tenendo fisso l’8, il commutante di Cl(0,k) ha dimensione 2^{8−k} e il tipo della base. I nomi base e fibra sono nostri.'],
    sc_fock: ['Spazio di Fock e stringhe di Pauli', 'Lo spazio di Fock fermionico delle sue note quantistiche è l’insieme delle etichette: Cl(n,n) = End Λ(ℝⁿ), l’esclusione di Pauli è ε² = 0 e l’operatore numero è il numero di bit accesi (Thm T20). Le stringhe di Pauli di N qubit sono i blade a meno di una fase.'],
    sc_bands: ['Le bande come segno di X²', 'La matrice di un periodo di un potenziale periodico è un multivettore unitario di Cl(2,0): banda X² < 0, lacuna X² > 0, bordo X² = 0 con X ≠ 0 (Thm T19). Raggrupparla con gli altri posti del trio −1, 0, +1 è nostro.'],
    sc_stops: ['Dove la regola si ferma', 'Incollare su una varietà (riga L4), un principio d’azione e le equazioni di chiusura (righe C7, C8), la condizione che distingue l’energia (riga C12), la dimensione infinita e l’analisi: non raggiunti, e non affermati.'],
  },
  yl: {
    en: {
      schuller: ['20 · From the switch rule to how things move', 'Schuller works from how matter and light move to the law of gravity. Our rule matches his second and third steps exactly, the first and the middle ones only in shape, and the last only as our reading; we did not rebuild his gravity equations.'],
      sc_chain: ['His chain, our trail', 'Seven stones lead from how matter moves to the law of gravity; tap a stone to see how close the switch rule comes there.'],
      sc_table: ['One table, three choices', 'Set every switch to zero and you get the forms of his geometry course; set them to plus or minus and you get the boxes of the atlas. Only the squares change.'],
      sc_hyper: ['Waves like light', 'Waves travel like light only in boxes with exactly one plus switch or exactly one minus switch. That this picks our space-time is Schuller’s result.'],
      sc_fibre: ['Outside and inside', 'In a box of eight minus switches the outside halves when the inside doubles, and their sizes always multiply to 256. The names are ours.'],
      sc_fock: ['Seats and particles', 'Three seats make eight patterns, with 1, 3, 3 and 1 particles. A second particle in a full seat gives nothing, as Pauli’s rule says.'],
      sc_bands: ['Allowed and forbidden energies', 'One number decides whether a wave gets through a row of kicks: below zero a band, above zero a gap, at zero the edge.'],
      sc_stops: ['Where our rule stops', 'Gluing many small pieces of space into a whole, and the rule that picks the motion, are beyond our switches; we did not rebuild his gravity equations.'],
    },
    it: {
      schuller: ['20 · Dalla regola degli interruttori a come si muovono le cose', 'Schuller parte da come si muovono la materia e la luce e arriva alla legge della gravità. La nostra regola coincide esattamente con il suo secondo e il suo terzo passo, con il primo e con quelli di mezzo solo nella forma, e con l’ultimo solo come nostra lettura; non abbiamo ricostruito le sue equazioni della gravità.'],
      sc_chain: ['La sua catena, la nostra traccia', 'Sette pietre portano da come si muove la materia alla legge della gravità; tocca una pietra per vedere quanto si avvicina lì la regola degli interruttori.'],
      sc_table: ['Una tabella, tre scelte', 'Metti ogni interruttore a zero e ottieni le forme del suo corso di geometria; mettili a più o a meno e ottieni le scatole dell’atlante. Cambiano solo i quadrati.'],
      sc_hyper: ['Onde come la luce', 'Le onde viaggiano come la luce solo nelle scatole con esattamente un interruttore più o esattamente un interruttore meno. Che questo scelga il nostro spazio-tempo è un risultato di Schuller.'],
      sc_fibre: ['Fuori e dentro', 'In una scatola con otto interruttori meno il fuori si dimezza quando il dentro raddoppia, e le loro grandezze moltiplicate fanno sempre 256. I nomi sono nostri.'],
      sc_fock: ['Posti e particelle', 'Tre posti fanno otto schemi, con 1, 3, 3 e 1 particelle. Una seconda particella in un posto pieno non dà nulla, come dice la regola di Pauli.'],
      sc_bands: ['Energie permesse e proibite', 'Un solo numero decide se un’onda attraversa una fila di colpi: sotto zero una banda, sopra zero una lacuna, a zero il bordo.'],
      sc_stops: ['Dove la nostra regola si ferma', 'Incollare tanti piccoli pezzi di spazio in un tutto, e la regola che sceglie il moto, sono oltre i nostri interruttori; non abbiamo ricostruito le sue equazioni della gravità.'],
    },
  },
};
export const PERSONA = 'SCHULLER (step 20, the third chapter of the lenses page; selfcheck/reports/fibre_check.py, bridge_check.py, bridge_check_qm.py: 163 checks). His constructive gravity goes from the matter action to the principal polynomial, three conditions and closure; the atlas follows the algebraic front and stops where dynamics begins. Grades along his chain: S, E, E, S, S, S, A (the report\'s grades; stones 2 and 3 checked). Wedge and Clifford share one table, only the squares change (checked, standard). A quadratic principal polynomial is hyperbolic iff Lorentzian: one class in two conventions P ↔ −P, while Cl(1,3) = M₂(ℍ) and Cl(3,1) = M₄(ℝ) differ; Cl(2,2) is the first ultrahyperbolic cell (checked, standard, Thm T18). The fermionic Fock space of his quantum notes is the label set, Cl(n,n) = End Λ(ℝⁿ) (checked, standard, Thm T20); popcount as particle number is ours. Left action as base, twisted right action as fibre: A ⊗̂ mirror(A) = Cl(n,n); with the 8 kept fixed the commutant of Cl(0,k) has dimension 2^(8−k) and the same type (checked, standard; the names are ours; isomorphic as algebras, generators not matched). Band, gap and edge of a periodic potential are the sign of X² of the one-period matrix in Cl(2,0), an edge being X² = 0 with X ≠ 0 (checked, standard, Thm T19); calling it the same trio as elsewhere is ours. The deformation algebra is only a frozen flat 1+1 model, Witt ⊗ A_ε (checked); more dimensions are open. Λ ~ −s·κ² is ours, untested against his equations. Not rebuilt: closure equations, action principle, gluing (open). The i of the printed Dirac equation of the notes is the slip, not the cell (checked, E-001); the notes are a student transcript, not endorsed by the lecturer.';
