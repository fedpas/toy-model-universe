// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React from 'react';
import { stepEyebrow } from './steps.js';
import { Tx } from './MathText.jsx';
import { KIT_STYLE, Tags, ScriptBox, HonestyBar } from './LensKit.jsx';
import LensMatrix from './LensMatrix.jsx';
import { Fold, level } from './Fold.jsx';
import { FOLD } from './audienceCopy.js';
import { scrollToAnchor } from './StoryShell.jsx';
import { THEOREMS } from './researchersData.js';
import { RS } from './researchersCopy.js';
import { COPY } from './schullerCopy.js';
import { FIBRE_CHECK_PY, BRIDGE_CHECK_PY, QM_CHECK_PY } from './schullerSelfcheckSource.js';
import { SW1, SW2, SW3, SW4, SW5, SW6, SW7, SchullerWidgetsScript } from './SchullerWidgets.jsx';

// Step 20 of the lenses page: Schuller's chain (constructive gravity, his geometry and quantum lectures) against the bit rule, after the report of
// 5 October 2026 and the design round of 6 October (DECISIONS §3). Three voices: the Young Learner reads plain words and sees the widgets that are for
// everyone, with the formal findings in one closed fold "For older readers"; the Physicist reads the short lede, the details folded; the Mathematician
// reads everything open. Every statement is a tagged line (.eq-pt: the tags, then the text and the ids of its checks), so the reader filter and the
// claims table (claimsLocators_lns.json) see it. The widgets come from SchullerWidgets.jsx; this file only places them, inside its own anchors
// (sc-w-*), for the audiences DECISIONS gives: SW1, SW2, SW3, SW5, SW6 for all; SW4 for the Physicist and the Mathematician; SW7 for the Young Learner
// and the Physicist. Anchors: id="sc-<section>"; the in-page menu scrolls to them (it does not change the address, which holds the page and the tab).
const STYLE = `
.sc-h2{margin:.2em 0 .4em;font-size:1.35em}.ln .sc-sec{margin:22px 0}.ln .sc-sec>h3{border-bottom:1px solid rgba(128,128,128,.25);padding-bottom:3px}
.ln .sc-disc{border-left:3px solid rgba(248,113,113,.6);padding:2px 0 2px 10px}.ln .sc-conv{border-left:3px solid rgba(96,165,250,.6);padding:2px 0 2px 10px}
.ln .ln-find{margin:12px 0 4px}.ln .ln-ft{margin:.6em 0 .2em}.ln .sc-persp{margin:10px 0}.ln .sc-persp h4{margin:.6em 0 .2em}
.ln .sc-corr{border:1px solid rgba(128,128,128,.25);border-radius:8px;padding:6px 10px;margin:8px 0;font-size:.92em}.ln .sc-corr p{margin:.25em 0;overflow-wrap:anywhere}
.ln .sc-corr s{opacity:.7}
.ln .sc-thm .ln-k{margin-left:0}.ln .sc-src li{margin:.3em 0;overflow-wrap:anywhere}.ln .sc-w{margin:8px 0}
`;
const kindsOf = k => (Array.isArray(k) ? k : String(k || '').split(/\s+/)).filter(Boolean);
// one tagged line: the tags, then the text and (for the Physicist and the Mathematician) the ids of the checks that carry it
function Line({ l, lang, label, ids = true }) {
  const [k, text, checks = []] = l;
  return <div className="eq-pt" data-kinds={kindsOf(k).join(' ')}><div style={{ minWidth: 92 }}><Tags kinds={kindsOf(k)} lang={lang} /></div>
    <div><p><Tx>{text}</Tx></p>{ids && checks.length ? <p className="ln-chk"><span className="ln-k">{label}</span> {checks.map(c => <code key={c} className="ln-id">{c}</code>)}</p> : null}</div></div>;
}
const Lines = ({ items, lang, label, ids }) => <div>{items.map((l, i) => <Line key={i} l={l} lang={lang} label={label} ids={ids} />)}</div>;
// a finding of the report: its id and title, then its lines (a finding that is partly textbook and partly ours is split into lines)
const FindingBlock = ({ f, lang, label }) => <div className="ln-find" data-finding={f.id}><p className="ln-ft"><code className="ln-id">{f.id}</code> <b><Tx>{f.title}</Tx></b></p><Lines items={f.lines} lang={lang} label={label} /></div>;
const W = ({ id, children }) => <div id={id} className="sc-w">{children}</div>;
const Sec = ({ id, h, children }) => <section id={id} className="sc-sec" aria-labelledby={id + '-h'}><h3 id={id + '-h'}><Tx>{h}</Tx></h3>{children}</section>;
const SCRIPT_TEXT = { 'selfcheck/reports/fibre_check.py': FIBRE_CHECK_PY, 'selfcheck/reports/bridge_check.py': BRIDGE_CHECK_PY, 'selfcheck/reports/bridge_check_qm.py': QM_CHECK_PY };
// the three-mode Fock table: the labels of three bits, grouped by popcount (computed here, the counts 1, 3, 3, 1 are what qm·Q7 checks)
const FOCK = [0, 1, 2, 3].map(N => ({ N, labels: [...Array(8).keys()].filter(a => [0, 1, 2].filter(i => (a >> i) & 1).length === N).map(a => [0, 1, 2].map(i => ((a >> i) & 1 ? '1' : '0')).join('')) }));
// which sections each audience has, in the order of DECISIONS §3
export const MENU = {
  yl: ['first', 'chain', 'table', 'hyper', 'fibre', 'fock', 'total', 'bands', 'stops', 'honest', 'bar', 'scripts'],
  formal: ['first', 'chain', 'table', 'hyper', 'area', 'deform', 'fibre', 'fock', 'spin', 'total', 'bands', 'stops', 'persp', 'quantum', 'notes', 'questions', 'honest', 'bar', 'corr', 'thm', 'scripts', 'sources'],
};
// which audiences see each widget (DECISIONS §3): 'all', or the levels 1 (Physicist) and 2 (Mathematician), 0 being the Young Learner
export const WIDGETS = { SW1: [0, 1, 2], SW2: [0, 1, 2], SW3: [0, 1, 2], SW4: [1, 2], SW5: [0, 1, 2], SW6: [0, 1, 2], SW7: [0, 1], SchullerWidgetsScript: [0, 1, 2] };

export default function SchullerSection({ lang = 'en', profile = 'Young Learner', go }) {
  const L = lang === 'it' ? 'it' : 'en', lv = level(profile), M = lv >= 2, t = COPY[L], y = COPY.yl[L], wp = { lang: L, profile };
  const has = w => WIDGETS[w].includes(lv);
  const toTab = (tab, anchor) => { try { location.hash = '#lenses/' + tab; } catch { /* ignore */ } setTimeout(() => scrollToAnchor(anchor || 'ln-' + tab), 120); };
  const ck = t.checksLbl;
  const menu = (lv === 0 ? MENU.yl : MENU.formal).map(id => [id, (lv === 0 ? y.menu : t.menu)[id]]);
  const Menu = <nav className="ln-menu" aria-label={lv === 0 ? y.menuLbl : t.menuLbl}>{menu.map(([id, lbl]) => <button key={id} type="button" data-go={'sc-' + id} onClick={() => scrollToAnchor('sc-' + id)}><Tx>{lbl}</Tx></button>)}</nav>;
  const Scripts = <>{t.scripts.files.map(f => <ScriptBox key={f.file} lang={L} file={f.file} text={SCRIPT_TEXT[f.file]} note={f.note} />)}
    <p className="ln-mono">{t.scripts.run}</p><p className="ln-cap"><Tx>{t.scripts.sabotage}</Tx></p>
    <h4><Tx>{t.scripts.widgets}</Tx></h4>{has('SchullerWidgetsScript') && <W id="sc-w-script"><SchullerWidgetsScript {...wp} /></W>}</>;
  const findings = sec => t[sec].findings.map(f => <FindingBlock key={f.id} f={f} lang={L} label={ck} />);
  const Persp = t.persp.items.map(p => <div key={p.id} className="sc-persp" data-persp={p.id}><h4><code className="ln-id">{p.id}</code> <Tx>{p.h}</Tx></h4><Lines items={p.lines} lang={L} label={ck} /></div>);

  // ---- the Young Learner
  if (lv === 0) return <section className="ln" id="ln-schuller" data-voice="yl"><style>{KIT_STYLE + STYLE}</style>
    <p className="eyebrow"><Tx>{stepEyebrow(L, 'lens', 'schuller')}</Tx></p>
    <h2 className="sc-h2"><Tx>{y.title}</Tx></h2>{Menu}
    <section id="sc-first" className="sc-sec"><p className="lede"><Tx>{y.lede}</Tx></p>{y.intro.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}</section>
    <Sec id="sc-chain" h={y.chain.h}>{y.chain.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<W id="sc-w-chain"><SW1 {...wp} /></W><Lines items={y.chain.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-table" h={y.table.h}>{y.table.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<W id="sc-w-table"><SW2 {...wp} /></W><Lines items={y.table.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-hyper" h={y.hyper.h}>{y.hyper.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<Lines items={y.hyper.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-fibre" h={y.fibre.h}>{y.fibre.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<W id="sc-w-fibre"><SW3 {...wp} /></W><Lines items={y.fibre.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-fock" h={y.fock.h}>{y.fock.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<W id="sc-w-seats"><SW6 {...wp} /></W><Lines items={y.fock.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-total" h={y.total.h}>{y.total.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}{has('SW7') && <W id="sc-w-magnets"><SW7 {...wp} /></W>}<Lines items={y.total.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-bands" h={y.bands.h}>{y.bands.text.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<W id="sc-w-bands"><SW5 {...wp} /></W><Lines items={y.bands.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-stops" h={y.stops.h}><Lines items={y.stops.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-honest" h={y.honest.h}><Lines items={y.honest.lines} lang={L} ids={false} /></Sec>
    <Sec id="sc-bar" h={y.bar.h}><p><Tx>{y.bar.text}</Tx></p><HonestyBar lang={L} source="schuller" voice="yl" /><p className="ln-cap sc-corr-yl"><Tx>{y.corr}</Tx></p></Sec>
    <Sec id="sc-scripts" h={y.scripts.h}><p><Tx>{y.scripts.text}</Tx></p></Sec>
    <Fold title={(FOLD[L] || FOLD.en).older} open={false}>
      <div className="sc-older">{['chain', 'table', 'hyper', 'area', 'deform', 'fibre', 'fock', 'spin', 'total', 'bands'].map(s => <div key={s}><h4><Tx>{t[s].h}</Tx></h4>{findings(s)}</div>)}
        <h4><Tx>{t.persp.h}</Tx></h4>{Persp}
        <LensMatrix lang={L} source="schuller" />
        <h4><Tx>{t.scripts.h}</Tx></h4>{Scripts}</div></Fold>
  </section>;

  // ---- the Physicist (details folded) and the Mathematician (everything open)
  return <section className="ln" id="ln-schuller" data-voice={M ? 'm' : 'p'}><style>{KIT_STYLE + STYLE}</style>
    <p className="eyebrow"><Tx>{stepEyebrow(L, 'lens', 'schuller')}</Tx></p>
    <h2 className="sc-h2"><Tx>{t.title}</Tx></h2>{Menu}
    <section id="sc-first" className="sc-sec">{M ? <><p className="lede"><Tx>{t.first.ledeM}</Tx></p><p><Tx>{t.first.lede}</Tx></p></> : <p className="lede"><Tx>{t.first.lede}</Tx></p>}<p className="ln-cap sc-disc"><Tx>{t.first.disclaimer}</Tx></p>
      <Fold title={t.first.fullH} open={M}>{t.first.full.map((p, i) => <p key={i}><Tx>{p}</Tx></p>)}<p className="ln-cap"><Tx>{t.first.scope}</Tx></p>
        <h4><Tx>{t.first.statementsH}</Tx></h4>{t.first.statements.map(f => <FindingBlock key={f.id} f={f} lang={L} label={ck} />)}</Fold></section>
    <Sec id="sc-chain" h={t.chain.h}><p><Tx>{t.chain.intro}</Tx></p><W id="sc-w-chain"><SW1 {...wp} /></W>{findings('chain')}</Sec>
    <Sec id="sc-table" h={t.table.h}><p><Tx>{t.table.intro}</Tx></p><W id="sc-w-table"><SW2 {...wp} /></W>
      <Fold title={t.table.foldH} open={M}>{findings('table')}<button type="button" className="ln-btn" data-link="category" onClick={() => toTab('category')}><Tx>{t.table.catLink}</Tx></button></Fold></Sec>
    <Sec id="sc-hyper" h={t.hyper.h}>{findings('hyper')}<p><Tx>{t.hyper.intro}</Tx></p>{has('SW4') && <W id="sc-w-bench"><SW4 {...wp} /></W>}</Sec>
    <Sec id="sc-area" h={t.area.h}><Fold title={'F4 · ' + t.area.findings[0].title} open={M}>{findings('area')}</Fold>
      <button type="button" className="ln-btn" data-link="octahedron" onClick={() => go && go('equations', 'eq-comm')}><Tx>{t.area.octaLink}</Tx></button></Sec>
    <Sec id="sc-deform" h={t.deform.h}><Fold title={'F3 · ' + t.deform.findings[0].title} open={M}>{findings('deform')}</Fold></Sec>
    <Sec id="sc-fibre" h={t.fibre.h}><p className="ln-cap sc-conv"><Tx>{t.fibre.convention}</Tx></p><W id="sc-w-fibre"><SW3 {...wp} /></W>{findings('fibre')}
      <Fold title={t.fibre.massH} open={M}><FindingBlock f={t.fibre.mass} lang={L} label={ck} /></Fold>
      <Line l={t.fibre.ladder} lang={L} label={ck} /><button type="button" className="ln-btn" data-link="baez" onClick={() => toTab('baez')}><Tx>{t.fibre.baezLink}</Tx></button></Sec>
    <Sec id="sc-fock" h={t.fock.h}><W id="sc-w-seats"><SW6 {...wp} /></W>{findings('fock')}
      <h4><Tx>{t.fock.tableH}</Tx></h4><div className="ln-wrap"><table className="ln-tab sc-fock-tab"><thead><tr>{t.fock.tableCols.map(c => <th key={c} scope="col"><Tx>{c}</Tx></th>)}</tr></thead>
        <tbody>{FOCK.map(r => <tr key={r.N} data-n={r.N}><td>{r.N}</td><td className="ln-mono">{r.labels.join(', ')}</td><td>{r.labels.length}</td></tr>)}</tbody></table></div><p className="ln-cap"><Tx>{t.fock.tableCap}</Tx></p></Sec>
    <Sec id="sc-spin" h={t.spin.h}><Fold title={'F5 · ' + t.spin.findings[0].title} open={M}>{findings('spin')}</Fold></Sec>
    <Sec id="sc-total" h={t.total.h}>{has('SW7') && <W id="sc-w-magnets"><SW7 {...wp} /></W>}{findings('total')}</Sec>
    <Sec id="sc-bands" h={t.bands.h}><W id="sc-w-bands"><SW5 {...wp} /></W>{findings('bands')}</Sec>
    <Sec id="sc-stops" h={t.stops.h}><Lines items={t.stops.items} lang={L} label={ck} /></Sec>
    <Sec id="sc-persp" h={t.persp.h}><p className="ln-cap"><Tx>{t.persp.intro}</Tx></p>{Persp}</Sec>
    <Sec id="sc-quantum" h={t.quantum.h}><h4><Tx>{t.quantum.readH}</Tx></h4><p><Tx>{t.quantum.read}</Tx></p><h4><Tx>{t.quantum.itemsH}</Tx></h4><Lines items={t.quantum.items} lang={L} label={ck} /></Sec>
    <Sec id="sc-notes" h={t.notes.h}><Fold title={t.notes.h} open={M}><p className="ln-cap"><Tx>{t.notes.intro}</Tx></p><Lines items={t.notes.items} lang={L} label={ck} /></Fold></Sec>
    <Sec id="sc-questions" h={t.questions.h}><Lines items={t.questions.items} lang={L} label={ck} /></Sec>
    <Sec id="sc-honest" h={t.honest.h}><Lines items={t.honest.items} lang={L} label={ck} /></Sec>
    <Sec id="sc-bar" h={t.bar.h}><HonestyBar lang={L} source="schuller" voice="formal" /><p className="ln-cap"><Tx>{t.bar.note}</Tx></p>
      {M ? <LensMatrix lang={L} source="schuller" /> : <Fold title={t.bar.matrixFold} open={false}><LensMatrix lang={L} source="schuller" /></Fold>}</Sec>
    <Sec id="sc-corr" h={t.corr.h}><Fold title={t.corr.h} open={M}><p className="ln-cap"><Tx>{t.corr.intro}</Tx></p>
      {t.corr.items.map((c, i) => <div key={i} className="sc-corr" data-corr={c.id} data-date={c.date}><p><code className="ln-id">{c.id}</code><span className="ln-k">{c.date}</span> <span className="ln-k">{t.corr.lbl.where}</span> <Tx>{c.where}</Tx></p>
        <p><span className="ln-k">{t.corr.lbl.was}</span> <s><Tx>{c.wrong}</Tx></s></p><p><span className="ln-k">{t.corr.lbl.now}</span> <Tx>{c.right}</Tx></p>
        {c.guard.length ? <p className="ln-chk"><span className="ln-k">{t.corr.lbl.guard}</span> {c.guard.map(g => <code key={g} className="ln-id">{g}</code>)}</p> : null}</div>)}</Fold></Sec>
    <Sec id="sc-thm" h={t.thm.h}><Fold title={t.thm.h} open={M}><p className="ln-cap"><Tx>{t.thm.intro}</Tx></p>
      {t.thm.items.map(x => { const T = THEOREMS.find(z => z.id === x.id) || {}, R = RS[L].theorems; return <div key={x.id} className="sc-thm" data-thm={x.id}><Line l={x.line} lang={L} label={ck} />
        <p className="ln-cap"><span className="ln-k">{t.thm.status}</span> <Tx>{R.status[T.status] || '—'}</Tx> · <span className="ln-k">{t.thm.verifier}</span> <Tx>{R.verifier[T.verifier] || '—'}</Tx> · <code className="ln-id">{T.script || ''}</code></p></div>; })}</Fold></Sec>
    <Sec id="sc-scripts" h={t.scripts.h}><p><Tx>{t.scripts.intro}</Tx></p>{Scripts}</Sec>
    <Sec id="sc-sources" h={t.sources.h}><Fold title={t.sources.h} open={M}>{t.sources.langNote ? <p className="ln-cap lang-note"><Tx>{t.sources.langNote}</Tx></p> : null}
      <ul className="sc-src">{t.sources.items.map((s, i) => <li key={i}><Tx>{s}</Tx></li>)}</ul></Fold></Sec>
  </section>;
}
