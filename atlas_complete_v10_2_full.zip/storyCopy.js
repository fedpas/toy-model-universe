// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Copy for the six-page story. Status vocabulary: checked, standard, ours, open.
import { STEP_GROUPS, NAV_NAMES, NAV_NAMES_YL, stepCount, stepNo, numWord, capital } from './steps.js';
import { PAGE as LABELS_PAGE, PAGE_YL as LABELS_PAGE_YL, TABS_LBL as LABELS_TABS } from './labelsCopy.js';
import { PAGE as LENSES_PAGE, PAGE_YL as LENSES_PAGE_YL, TABS_LBL as LENSES_TABS } from './lensesCopy.js';
export const PAGES = ['rule', 'atlas', 'maxwell', 'furey', 'shapes', 'equations', 'labels', 'lenses', 'map', 'researchers', 'ask'];

// What the Young Learner reads in the frame of every page (heading, "before", "next", the tags strip, the tag legend, the closing note):
// plain words, no formulas, no technical vocabulary. PageIntro and StoryPager use it in place of the same keys of STORY when the audience
// is Young Learner; the other two audiences read STORY unchanged. The status of every claim is kept, in plain words.
const eqFirstLast = l => [NAV_NAMES_YL[l][STEP_GROUPS.eq[0]].toLowerCase(), NAV_NAMES_YL[l][STEP_GROUPS.eq[stepCount('eq') - 1]].toLowerCase()];
export const STORY_YL = {
  en: {
    tagHelp: { checked: 'a computer checked it with exact sums, and you can download the check', standard: 'it is in school or university books', ours: 'our idea, not a result', open: 'not done here, or nobody knows yet' },
    note: 'The maths here is old and well known; the way we read it is ours. Every claim says how sure we are: checked, standard, ours or open. It is not a tested theory of nature.',
    metric: { Spatial: ['Space +', 'Reading 1: the plus switches stand for space'], Temporal: ['Time +', 'Reading 2: the mirror reading, where plus and minus swap names; nothing runs backwards'] },
    pages: {
      rule: { h: 'One switch rule, four pictures', before: '', after: 'Next we spread the same rule over a grid of 25 boxes, then test it on two ideas that other people made.',
        tags: [['standard', 'the rule and the list of all its kinds of box are textbook maths'], ['ours', 'drawing the pieces as faces, cube corners and numbers is our way of showing them'], ['ours', 'the prime-number labels are only names']] },
      atlas: { h: 'The atlas: 25 boxes built from the same rule', before: 'The rule: each piece is a row of switches, and two pieces combine by flipping switches.', after: 'Two boxes are tested closely: first the one for light, because everything about light is known.',
        tags: [['checked standard', 'the kind of every box comes from a table that has been known for a long time'], ['checked standard', 'the size of every box and a few of its numbers are rebuilt from the switch rule by a computer'], ['standard ours open', 'the names from physics that we give to the boxes'], ['open', 'the boxes marked as research or as guesses']] },
      maxwell: { h: 'Test 1: can the rule rebuild what we know about light?', before: 'The atlas gave every box its rules. Here one family of boxes becomes a real equation.', after: 'It works where the answer is known. The harder test is a model with matter in it.',
        tags: [['checked standard', 'every piece of the equation, every sign and every wave'], ['checked standard', 'the push on a moving charge, in six situations'], ['standard', 'writing light this way is a known method'], ['checked standard', 'waves behave in one of three ways, depending on how many time directions there are'], ['open', 'any link to the matter model of Test 2']] },
      furey: { h: 'Test 2: one family of particles', before: 'Test 1 showed that the rule can rebuild light, which has no matter. This test has charges, colours and left and right hands.', after: 'What is left is listed as questions. Next, more shapes grow from the same rule.',
        tags: [['checked', 'the 16-piece model, its list of charges, and 28 links sorted into 7 groups'], ['standard', 'Furey’s way of building it, from a published paper'], ['checked open', 'one family of particles fits; three families do not'], ['open', 'the top quark, the number 210, how heavy things are, the spare links, and why nature has three families']] },
      shapes: { h: 'More shapes: two poles, half a cube, and a famous big shape', before: 'Test 2 rebuilt a model with matter in it: one family fits, three do not.', after: `Next: ${numWord('en', stepCount('eq'))} steps of equations, from “${eqFirstLast('en')[0]}” to “${eqFirstLast('en')[1]}”, drawn and checked like the equation of light.`,
        tags: [['checked standard', 'counts of corners, edges and faces, how the shapes pair up, and the 240 corners of the big shape in eight dimensions'], ['checked standard', 'these shapes and their families are known maths'], ['ours', 'reading the even pieces as fields and the odd pieces as sources'], ['checked standard open', 'whether the big shape stopping at eight has anything to do with our limit of eight switches']] },
      equations: { h: `More equations: ${numWord('en', stepCount('eq'))} steps, from ${eqFirstLast('en')[0]} to ${eqFirstLast('en')[1]}`, before: 'The shapes page showed half of the cube and the big shape that grows from it.', after: 'Next: three more discoveries (steps 15 to 17): the clock, falling space, and counting shuffles.',
        tags: [['', 'every step has a script that checks it with exact sums: turning pairs, the electron’s rule, forces, gravity, mirrors, push and spin, springs and a solid body'], ['standard', 'the equations themselves come from books and from papers by other people'], ['ours', 'drawing the pieces of each equation as edges and corners of the cube, and a speed trick for the labels that was timed on one computer'], ['open', 'how strong the sources are, left and right hands, gravity together with matter, crashes and friction, and the other open points named on each step']] },
      map: { h: 'The map: where we stand and what comes next', before: `The last two pages added six more discoveries (steps 15 to 20). Before them, the equations page ended with step ${stepCount('eq')}, “${eqFirstLast('en')[1]}”, and a tally: one row for each family of equations, what is drawn and what is not.`, after: 'Next: a page of long lists for the grown-ups who check our work, then the questions.',
        tags: [['checked', 'the numbers on this page are read from the same files as the pages they talk about'], ['ours', 'sorting the branches into groups is our choice'], ['open', 'the next steps are plans, not results']] },
      researchers: { h: 'For grown-up researchers', before: 'The map showed where every part sits and what comes next.', after: 'Last stop: ask the model anything, and see how sure each answer is.',
        does: 'A page of long lists for the grown-ups who check our work: every sentence of the atlas once, with how sure we are about it.',
        tags: [['checked', 'the numbers on this page are counted by the computer from the same list'], ['ours', 'which of the four boxes each sentence goes in is our own choice'], ['open', 'no expert has looked at our lists yet']] },
      ask: { h: 'Ask the model', before: `You have seen the rule, the atlas, two tests, ${numWord('en', stepCount('shapes'))} steps of shapes, ${numWord('en', stepCount('eq'))} steps of equations, ${numWord('en', stepCount('labels') + stepCount('lens'))} more discoveries, and the map.`, after: '',
        tags: [['open', 'it has not been tried on every possible question']] }
    }
  },
  it: {
    tagHelp: { checked: 'un computer l’ha controllato con conti esatti, e puoi scaricare il controllo', standard: 'si trova nei libri di scuola o dell’università', ours: 'una nostra idea, non un risultato', open: 'non fatto qui, o nessuno lo sa ancora' },
    note: 'La matematica qui è antica e ben nota; il modo in cui la leggiamo è nostro. Ogni affermazione dice quanto ne siamo sicuri: verificato, standard, nostro o aperto. Non è una teoria della natura messa alla prova.',
    metric: { Spatial: ['Spazio +', 'Lettura 1: gli interruttori più stanno per lo spazio'], Temporal: ['Tempo +', 'Lettura 2: la lettura allo specchio, dove più e meno si scambiano il nome; nulla va all’indietro'] },
    pages: {
      rule: { h: 'Una regola di interruttori, quattro immagini', before: '', after: 'Poi distribuiamo la stessa regola su una griglia di 25 scatole e la mettiamo alla prova su due idee nate da altre persone.',
        tags: [['standard', 'la regola e l’elenco di tutti i suoi tipi di scatola sono matematica da manuale'], ['ours', 'disegnare i pezzi come facce, angoli del cubo e numeri è il nostro modo di mostrarli'], ['ours', 'le etichette con i numeri primi sono solo nomi']] },
      atlas: { h: 'L’atlante: 25 scatole fatte con la stessa regola', before: 'La regola: ogni pezzo è una fila di interruttori, e due pezzi si combinano girando interruttori.', after: 'Due scatole sono messe alla prova da vicino: prima quella della luce, perché della luce si sa tutto.',
        tags: [['checked standard', 'il tipo di ogni scatola viene da una tabella nota da molto tempo'], ['checked standard', 'la grandezza di ogni scatola e alcuni suoi numeri sono ricostruiti dalla regola degli interruttori da un computer'], ['standard ours open', 'i nomi della fisica che diamo alle scatole'], ['open', 'le scatole segnate come ricerca o come ipotesi']] },
      maxwell: { h: 'Prova 1: la regola sa ricostruire ciò che sappiamo della luce?', before: 'L’atlante ha dato a ogni scatola le sue regole. Qui una famiglia di scatole diventa un’equazione vera.', after: 'Funziona dove la risposta è nota. La prova più dura è un modello con la materia dentro.',
        tags: [['checked standard', 'ogni pezzo dell’equazione, ogni segno e ogni onda'], ['checked standard', 'la spinta su una carica in movimento, in sei situazioni'], ['standard', 'scrivere la luce in questo modo è un metodo noto'], ['checked standard', 'le onde si comportano in uno di tre modi, a seconda di quante direzioni di tempo ci sono'], ['open', 'ogni legame con il modello della materia della Prova 2']] },
      furey: { h: 'Prova 2: una famiglia di particelle', before: 'La Prova 1 ha mostrato che la regola sa ricostruire la luce, che non ha materia. Questa prova ha cariche, colori e mani destre e sinistre.', after: 'Ciò che resta è elencato come domande. Poi altre forme crescono dalla stessa regola.',
        tags: [['checked', 'il modello a 16 pezzi, il suo elenco di cariche e 28 collegamenti divisi in 7 gruppi'], ['standard', 'il modo di costruirlo di Furey, da un articolo pubblicato'], ['checked open', 'una famiglia di particelle ci sta; tre famiglie no'], ['open', 'il quark top, il numero 210, quanto pesano le cose, i collegamenti in più e perché la natura ha tre famiglie']] },
      shapes: { h: 'Altre forme: due poli, mezzo cubo e una grande forma famosa', before: 'La Prova 2 ha ricostruito un modello con la materia dentro: una famiglia ci sta, tre no.', after: `Poi: ${numWord('it', stepCount('eq'))} passi di equazioni, da «${eqFirstLast('it')[0]}» a «${eqFirstLast('it')[1]}», disegnati e controllati come l’equazione della luce.`,
        tags: [['checked standard', 'i conteggi di vertici, spigoli e facce, come le forme si accoppiano e i 240 vertici della grande forma a otto dimensioni'], ['checked standard', 'queste forme e le loro famiglie sono matematica nota'], ['ours', 'leggere i pezzi pari come campi e quelli dispari come sorgenti'], ['checked standard open', 'se il fermarsi della grande forma a otto c’entri qualcosa con il nostro limite di otto interruttori']] },
      equations: { h: `Altre equazioni: ${numWord('it', stepCount('eq'))} passi, da «${eqFirstLast('it')[0]}» a «${eqFirstLast('it')[1]}»`, before: 'La pagina delle forme ha mostrato metà del cubo e la grande forma che ne cresce.', after: 'Avanti: tre altre scoperte (passi dal 15 al 17): l’orologio, lo spazio che cade e il conto dei rimescolamenti.',
        tags: [['', 'ogni passo ha uno script che lo controlla con conti esatti: coppie che girano, la regola dell’elettrone, forze, gravità, specchi, spinta e rotazione, molle e un corpo solido'], ['standard', 'le equazioni stesse vengono da libri e da articoli di altre persone'], ['ours', 'disegnare i pezzi di ogni equazione come spigoli e vertici del cubo, e un trucco di velocità per le etichette misurato su un solo computer'], ['open', 'quanto sono forti le sorgenti, mani destre e sinistre, la gravità insieme alla materia, urti e attrito, e gli altri punti aperti nominati in ogni passo']] },
      map: { h: 'La mappa: dove siamo e che cosa viene dopo', before: `Le ultime due pagine hanno aggiunto sei altre scoperte (passi dal 15 al 20). Prima, la pagina delle equazioni è finita con il passo ${stepCount('eq')}, «${eqFirstLast('it')[1]}», e un bilancio: una riga per ogni famiglia di equazioni, che cosa è disegnato e che cosa no.`, after: 'Poi: una pagina di lunghi elenchi per gli adulti che controllano il nostro lavoro, poi le domande.',
        tags: [['checked', 'i numeri di questa pagina sono letti dagli stessi file delle pagine di cui parlano'], ['ours', 'dividere i rami in gruppi è una nostra scelta'], ['open', 'i passi successivi sono piani, non risultati']] },
      researchers: { h: 'Per i ricercatori adulti', before: 'La mappa ha mostrato dove sta ogni parte e che cosa viene dopo.', after: 'Ultima tappa: chiedi qualsiasi cosa al modello e guarda quanto è sicura ogni risposta.',
        does: 'Una pagina di lunghi elenchi per gli adulti che controllano il nostro lavoro: ogni frase dell’atlante una volta, con quanto ne siamo sicuri.',
        tags: [['checked', 'i numeri di questa pagina sono contati dal computer dalla stessa lista'], ['ours', 'in quale delle quattro scatole va ogni frase è una nostra scelta'], ['open', 'nessun esperto ha ancora guardato le nostre liste']] },
      ask: { h: 'Chiedi al modello', before: `Hai visto la regola, l’atlante, due prove, ${numWord('it', stepCount('shapes'))} passi di forme, ${numWord('it', stepCount('eq'))} passi di equazioni, altre ${numWord('it', stepCount('labels') + stepCount('lens'))} scoperte e la mappa.`, after: '',
        tags: [['open', 'non è stato provato su ogni domanda possibile']] }
    }
  }
};

export const STORY = {
  en: {
    glance: 'At a glance', checkedBy: 'Checked by', prevStep: 'Previous', nextStep: 'Next', onMap: 'Where this sits on the Map', tabsLbl: { maxwell: 'Parts of the Maxwell test', furey: 'Parts of the Furey test', shapes: 'Shapes', equations: 'Equations, step by step', labels: LABELS_TABS.en, lenses: LENSES_TABS.en },
    settings: 'Settings', langLabel: 'Language', langNote: 'Set once; remembered in this browser.', navLbl: 'Story pages',
    nav: { rule: 'The rule', atlas: 'The atlas', maxwell: 'Test 1 · Maxwell', furey: 'Test 2 · Furey', shapes: 'More shapes', equations: 'More equations', labels: 'Labels · gravity · groups', lenses: 'Lenses', map: 'Map', researchers: 'For researchers', ask: 'Ask' },
    step: 'Step', of: 'of', prev: 'Back', next: 'Next', before: 'Before this', after: 'Next',
    tags: { checked: 'checked', standard: 'standard', ours: 'ours', open: 'open' },
    tagHelp: { checked: 'verified by exact arithmetic or a script you can download', standard: 'textbook mathematics or physics', ours: 'the reading we propose, not a result', open: 'not established' },
    legend: 'How to read the tags',
    pages: {
      rule: {
        h: 'One bit rule, four pictures',
        does: 'A blade is a bit pattern, and multiplying two blades is XOR on their labels (up to a sign). Here that rule is drawn four ways, and a short story shows the ladder of algebras it builds from three axioms.',
        before: '', after: 'Next we spread the same rule over a map of 25 cells, then test it on two theories we did not invent.',
        tags: [['standard', 'Clifford algebras and their classification'], ['ours', 'reading blades as faces, cube vertices and labels'], ['ours', 'prime labels are notation only']]
      },
      atlas: {
        h: 'The atlas: 25 cells of the same rule',
        does: 'Each cell is one Clifford algebra Cl(p,q), placed by its two gradings. Pick a cell to see its algebra, its simplex, its cube and its labels. Cell names are readings, so each carries its audit status.',
        before: 'The rule: blades are bit patterns and products are XOR.',
        after: 'Two cells are tested in depth: the electromagnetic one first, because everything about it is known.',
        tags: [['checked standard', 'the algebra type of every cell: the classical mod-8 table (the Maxwell test checks it against its recursion)'], ['checked standard', 'dimension, centre and pseudoscalar square of every cell, rebuilt from the bit rule'], ['standard ours open', 'the physical names given to cells: textbook identifications (Pauli algebra Cl(3,0), spacetime algebra Cl(1,3), SL(2,ℂ) in Cl(1,2), SU(2) in ℍ, conformal so(4,2) in Cl(4,2), conformal model Cl(4,1)); the other names (quark, lepton, confinement, electroweak, cosmic horizon, baryon) are readings, not tested'], ['open', 'cells marked research or speculative']]
      },
      maxwell: {
        h: 'Test 1: does the rule reproduce known physics?',
        does: 'Maxwell’s equations are one equation, ∇F = J. We rebuild them in 1 to 4 space dimensions and 1 to 4 time dimensions from the bit rule alone and check every term with exact arithmetic. Then a charge is let go in the field and its motion is drawn live.',
        before: 'The atlas gave every cell an algebra. Here one family of cells is used as a real equation.',
        after: 'It works where the answer is known. The harder test is a model with matter in it.',
        tags: [['checked standard', 'every term, sign and wave equation'], ['checked standard', 'the force on a charge, six situations'], ['standard', 'Maxwell in geometric algebra (Hestenes)'], ['checked standard', 'wave-operator type: elliptic, hyperbolic, ultrahyperbolic'], ['open', 'any link to Furey’s model']]
      },
      furey: {
        h: 'Test 2: one generation of matter',
        does: 'Furey’s model builds one generation of Standard Model states inside Cl(0,8). We rebuild it explicitly, then map its operators onto our blades, edges and channels and mark what fits and what does not.',
        before: 'Test 1 showed the rule reproduces a theory with no matter. This one has charges, colour and chirality.',
        after: 'What remains is listed as questions. Next, more shapes grow from the same rule and are checked against the views we already have.',
        tags: [['checked', 'the 16-dimensional model, the Cartan ledger, the 28 edges in 7 channels'], ['standard', 'Furey’s construction (arXiv 2607.18450)'], ['checked open', 'one generation fits; three do not in our identification (commutator edges, an exhaustive search over 5582 admissible blocks of End(V) = Cl(0,8)); Furey’s Fig. 1 uses another identification, not tested here, and shows three generations without the top-quark irreps'], ['open', 'top quark, 210, mass scale, replica edges, a family structure for generations']]
      },
      shapes: {
        h: 'More shapes: the poles, the half-cube and the Gosset series',
        does: 'The simplex and the cube are two pictures of the same bit rule. Two more shapes exist in every dimension: the orthoplex, which gives each axis two poles, and the demicube, which keeps every second corner of the cube. The third step is the Gosset series E6, E7, E8, which turns out to be built from these two shapes. We add them one at a time and check each against the views we already have.',
        before: 'Test 2 rebuilt a model with matter in it: one generation fits, three do not.',
        after: `Next: ${numWord('en', stepCount('eq'))} steps of equations, from ${NAV_NAMES.en[STEP_GROUPS.eq[0]].toLowerCase()} to ${NAV_NAMES.en[STEP_GROUPS.eq.at(-1)].toLowerCase()}, drawn and checked the same way as Maxwell.`,
        tags: [['checked standard', 'face counts, duality, even subalgebras, equation couplings, E6–E8 roots and polytopes from the Cartan matrices'], ['checked standard', 'Spin(2n) weights, Cl⁰(p,q) = Cl(p,q−1) (q ≥ 1), the classification of E-type diagrams'], ['ours', 'reading even blades as fields and odd blades as sources (true of F and J, and of ψ and its current; not of the potential A or the tetrad e, which are odd fields)'], ['checked standard open', 'whether the stop at E8 (Cartan determinant 9 − n; E9 affine, with one null root) is related to period 8 (known: E8 is the first even unimodular lattice, and such lattices exist only in ranks divisible by 8, by Milgram’s Gauss-sum formula, whose phase is also the clock of Cl(n,0); the Brown invariant of the labels is the same phase as the Gauss–Milgram sum of E_{n}): both put E8 at n = 8, by mechanisms that look different; whether the budget of 8 is related is open']]
      },
      equations: {
        h: `More equations: ${numWord('en', stepCount('eq'))} steps, from ${NAV_NAMES.en[STEP_GROUPS.eq[0]].toLowerCase()} to ${NAV_NAMES.en[STEP_GROUPS.eq[stepCount('eq') - 1]].toLowerCase()}`,
        does: `Maxwell was the first equation we could draw from the bit rule. ${capital(numWord('en', stepCount('eq')))} more steps follow the same recipe, each drawn as an incidence picture and checked by a script: ${STEP_GROUPS.eq.map(id => NAV_NAMES.en[id]).join(' · ')}. Steps ${stepNo('eq', 'forque')} to ${stepCount('eq')} are different. Steps ${stepNo('eq', 'forque')} and ${stepNo('eq', 'spin')} take the equations of other people’s work (a paper on rigid-body dynamics; a paper and a lecture on spinors), translate them to the bit rule and put them in a matrix, so that their authors can check them for themselves. Step ${stepNo('eq', 'spring')} puts a spring network on the cube and solves it exactly. Step ${stepNo('eq', 'rigid')} climbs a ladder from a segment to a tesseract, with a cube that carries its own labels, a body hung from a spring and a frame table, and every rung is checked against an exact solution. Step ${stepNo('eq', 'nullsurf')} takes claims about null surfaces from a published paper, rebuilds them on the bit rule and draws each one live.`,
        before: 'The shapes page showed the even half of the cube as the demicube and the Gosset series that grows from it.',
        after: 'Next: three more steps (15 to 17): labels, gauge gravity and finite groups, then three more on the lenses page (18 to 20).',
        tags: [['', 'bivector commutators for every signature up to n = 8; Dirac incidences, determinant and covariance; the coupling ladder for n = 1 to 8; Yang–Mills identities for gauge dimension 2 to 8; the charged-matter current and its conservation, exact; the Bianchi identities, the Einstein form and its divergence, exact; versors, the Cartan–Dieudonné bound and the cube as a group of mirrors; the extra generator s = 0, ±1, the null pair and the conformal algebra, exact and with matrices; the equations of the Forque paper translated to the bit rule, exact as power series, with a numpy cross-check; the labels, idempotents, pointors and phases of a spinor paper and lecture, exact on the bit rule; a spring network on the cube, plain and with the sign of the generator, exact as power series; a rigid body from the segment to the tesseract (free, under a spring, under gravity, a free top, planets and a moon), 110 claims in 56 rows, exact as power series, with a floating-point engine checked against them'], ['standard', 'Hestenes’ space-time algebra form of the Dirac equation; so(p,q) as bivectors; first-order (Cartan) gravity; reflections, versors, Cartan–Dieudonné, Coxeter groups; Hooke’s law and the hypercube spectrum (Walsh modes); rigid-body dynamics in plane-based PGA (Dorst and De Keninck); the invariant decomposition, pointors and spinors (Roelfs, Eelbode and De Keninck; Eelbode’s lecture); the tennis-racket (inverted oscillator) instability of a free top; Newton’s law of gravitation and Kepler’s laws'], ['ours', 'reading the derivative and coupling terms as edges and corner simplices of the cube; the 2ⁿ corner labels as bit masks, with the n+1 sandwiches of a frame instead of 2ⁿ (timed on one machine; it pays from n = 3)'], ['open', 'the sign and size of the source term, chirality and the electroweak doublets, the gravity field equation with matter, conformal dynamics (the Forque paper has none), the paper’s Lagrangian form and constrained motion, springs with vector displacements and their zero modes on the cube, an action principle, collisions, joints and friction, the label speed-ups outside the one machine they were timed on, the planets table against its JPL source']]
      },
      map: {
        h: 'The map: where we stand, the tree of what we know, and the next step',
        does: 'One page for the whole project. The status of every part, a tree of knowledge in which each branch says where it lives in the app and which script checks it, what could be borrowed from other researchers to do dynamics, the next steps, and who made this.',
        before: `The lenses page added steps 18 to 20 (the category lens, Baez and Schuller), after the labels page with steps 15 to 17. Before them, the equations page ended with step ${stepCount('eq')}, ${NAV_NAMES.en[STEP_GROUPS.eq.at(-1)].toLowerCase()}, and with the tally: one row per family of equations, with what is drawn and what is not.`,
        after: 'Next: the same claims one by one, for researchers, with their flags, sources, checks and errata; then the model.',
        tags: [['checked', 'the counts on this page are read from the same data files as the pages they describe'], ['ours', 'the grouping of branches into lenses and threads is our reading'], ['open', 'the next steps are plans, not results']]
      },
      researchers: {
        h: 'For researchers: every claim with its flags, sources and checks',
        does: 'The audit of the whole atlas in one place. Every statement of the pages is listed once with its flags (standard: textbook or published, with a citation; checked: one of our scripts confirms it; ours: our reading, choice or name; open: not known or not tested), the source it cites and the script that checks it. Known ground is standard and checked, and neither ours nor open. Then the translation matrix (items of three sets of sources against the parts of the atlas, graded exact, structural or analogy), the theorems written for the atlas with their proof status, the questions we would put to specialists, the sources and the dead ends, the errata, and the commands that rerun every check.',
        before: 'The map showed the status of every part, the tree of what we know, and the next steps.',
        after: 'Last stop: put any question to the model, with every claim tagged.',
        tags: [['checked', 'the counts on this page are computed from the same claims table it shows'], ['ours', 'the flags of every line are our own audit (two reviewers and the lead), not a referee’s verdict'], ['open', 'no specialist has reviewed the theorems or the flags yet']]
      },
      ask: {
        h: 'Ask the model',
        does: 'The guide answers from the same axioms and the same audit. It states a status for each claim and says “open” where that is the honest answer.',
        before: `You have seen the rule, the atlas, two tests, ${numWord('en', stepCount('shapes'))} steps of shapes, ${numWord('en', stepCount('eq'))} steps of equations, ${numWord('en', stepCount('labels') + stepCount('lens'))} more on the labels and lenses pages, and the map.`,
        after: '',
        tags: [['open', 'it has not been tested live against every question']]
      }
    },
    hero: {
      'Young Learner': ['One switch rule, four ways to see it.', 'Switches are on or off. Flip two sets of switches together and you get a new set. We draw that one rule four ways, then check it on light and on particles.'],
      Physicist: ['One bit rule, read four ways.', 'Blades are bit patterns and their products are XOR on labels. We draw that one rule as algebra, simplex, cube and numbers, then test it on two known theories.'],
      Mathematician: ['One algebra, four coordinate languages.', 'Clifford blades as bitmasks with product given by XOR up to sign; one incidence structure drawn as Peirce data, simplex faces, cube vertices and integer labels, then checked against Maxwell in Cl(k,d) and Furey’s model in Cl(0,8).']
    },
    note: 'Standard mathematics, re-read. What is ours is the reading, not the algebra. Each claim carries a status: checked, standard, ours or open. Not a peer-reviewed physical theory.',
    metric: { Spatial: ['Space +', 'Reading 1: generators that square to +1 are space'], Temporal: ['Time +', 'Reading 2: the mirror reading, with time and space roles swapped (see Test 1)'] }
  },
  it: {
    glance: 'In breve', checkedBy: 'Controllato da', prevStep: 'Precedente', nextStep: 'Successivo', onMap: 'Dove sta sulla Mappa', tabsLbl: { maxwell: 'Parti della prova di Maxwell', furey: 'Parti della prova di Furey', shapes: 'Forme', equations: 'Equazioni, un passo alla volta', labels: LABELS_TABS.it, lenses: LENSES_TABS.it },
    settings: 'Impostazioni', langLabel: 'Lingua', langNote: 'Si sceglie una volta; resta in questo browser.', navLbl: 'Pagine della storia',
    nav: { rule: 'La regola', atlas: 'L’atlante', maxwell: 'Prova 1 · Maxwell', furey: 'Prova 2 · Furey', shapes: 'Altre forme', equations: 'Altre equazioni', labels: 'Etichette · gravità · gruppi', lenses: 'Lenti', map: 'Mappa', researchers: 'Per i ricercatori', ask: 'Chiedi' },
    step: 'Passo', of: 'di', prev: 'Indietro', next: 'Avanti', before: 'Prima di questa', after: 'Poi',
    tags: { checked: 'verificato', standard: 'standard', ours: 'nostro', open: 'aperto' },
    tagHelp: { checked: 'verificato con aritmetica esatta o con uno script scaricabile', standard: 'matematica o fisica da manuale', ours: 'la lettura che proponiamo, non un risultato', open: 'non stabilito' },
    legend: 'Come leggere le etichette',
    pages: {
      rule: {
        h: 'Una regola di bit, quattro immagini',
        does: 'Una lama è uno schema di bit e moltiplicare due lame è XOR sulle loro etichette (a meno del segno). Qui la regola è disegnata in quattro modi e una breve storia mostra la scala di algebre che costruisce da tre assiomi.',
        before: '', after: 'Poi distribuiamo la stessa regola su una mappa di 25 celle e la mettiamo alla prova su due teorie che non abbiamo inventato.',
        tags: [['standard', 'algebre di Clifford e loro classificazione'], ['ours', 'lettura delle lame come facce, vertici del cubo ed etichette'], ['ours', 'le etichette primi sono solo notazione']]
      },
      atlas: {
        h: 'L’atlante: 25 celle della stessa regola',
        does: 'Ogni cella è un’algebra di Clifford Cl(p,q), collocata dalle sue due gradazioni. Scegli una cella per vedere algebra, simplesso, cubo ed etichette. I nomi delle celle sono letture, quindi ognuna riporta il proprio stato di verifica.',
        before: 'La regola: le lame sono schemi di bit e i prodotti sono XOR.',
        after: 'Due celle sono provate a fondo: prima quella elettromagnetica, perché di essa si sa tutto.',
        tags: [['checked standard', 'il tipo di algebra di ogni cella: la tabella classica mod 8 (la prova di Maxwell la controlla contro la sua ricorsione)'], ['checked standard', 'dimensione, centro e quadrato dello pseudoscalare di ogni cella, ricostruiti dalla regola dei bit'], ['standard ours open', 'i nomi fisici dati alle celle: identificazioni da manuale (algebra di Pauli Cl(3,0), algebra spazio-temporale Cl(1,3), SL(2,ℂ) in Cl(1,2), SU(2) in ℍ, so(4,2) conforme in Cl(4,2), modello conforme Cl(4,1)); gli altri nomi (quark, leptone, confinamento, elettrodebole, orizzonte cosmico, barione) sono letture, non provate'], ['open', 'celle segnate come ricerca o speculative']]
      },
      maxwell: {
        h: 'Prova 1: la regola riproduce la fisica nota?',
        does: 'Le equazioni di Maxwell sono una sola equazione, ∇F = J. Le ricostruiamo da 1 a 4 dimensioni spaziali e da 1 a 4 temporali con la sola regola dei bit e verifichiamo ogni termine con aritmetica esatta. Poi una carica viene lasciata libera nel campo e il suo moto è disegnato dal vivo.',
        before: 'L’atlante ha dato un’algebra a ogni cella. Qui una famiglia di celle diventa un’equazione vera.',
        after: 'Funziona dove la risposta è nota. La prova più dura è un modello con la materia dentro.',
        tags: [['checked standard', 'ogni termine, segno ed equazione d’onda'], ['checked standard', 'la forza su una carica, sei situazioni'], ['standard', 'Maxwell in algebra geometrica (Hestenes)'], ['checked standard', 'tipo dell’operatore d’onda: ellittico, iperbolico, ultraiperbolico'], ['open', 'ogni legame con il modello di Furey']]
      },
      furey: {
        h: 'Prova 2: una generazione di materia',
        does: 'Il modello di Furey costruisce una generazione di stati del Modello Standard dentro Cl(0,8). Lo ricostruiamo in modo esplicito, poi mappiamo i suoi operatori su lame, spigoli e canali nostri e segniamo ciò che combacia e ciò che no.',
        before: 'La Prova 1 ha mostrato che la regola riproduce una teoria senza materia. Questa ha cariche, colore e chiralità.',
        after: 'Ciò che resta è elencato come domande. Poi altre forme crescono dalla stessa regola e vengono confrontate con le viste che già abbiamo.',
        tags: [['checked', 'il modello a 16 dimensioni, il registro di Cartan, i 28 spigoli in 7 canali'], ['standard', 'costruzione di Furey (arXiv 2607.18450)'], ['checked open', 'una generazione ci sta; tre no nella nostra identificazione (spigoli del commutatore, una ricerca esaustiva su 5582 blocchi ammissibili di End(V) = Cl(0,8)); la Fig. 1 di Furey usa un’altra identificazione, non provata qui, e mostra tre generazioni senza gli irreps del quark top'], ['open', 'quark top, 210, scala di massa, spigoli di replica, una struttura di famiglia per le generazioni']]
      },
      shapes: {
        h: 'Altre forme: i poli, il mezzo cubo e la serie di Gosset',
        does: 'Il simplesso e il cubo sono due immagini della stessa regola di bit. In ogni dimensione esistono altre due forme: l’ortoplesso, che dà a ogni asse due poli, e il demicubo, che tiene un vertice su due del cubo. Il terzo passo è la serie di Gosset E6, E7, E8, che risulta fatta di queste due forme. Le aggiungiamo una alla volta e le confrontiamo con le viste che già abbiamo.',
        before: 'La Prova 2 ha ricostruito un modello con la materia dentro: una generazione ci sta, tre no.',
        after: `Poi: ${numWord('it', stepCount('eq'))} passi di equazioni, dal primo, «${NAV_NAMES.it[STEP_GROUPS.eq[0]].toLowerCase()}», all’ultimo, «${NAV_NAMES.it[STEP_GROUPS.eq.at(-1)].toLowerCase()}», disegnati e controllati come Maxwell.`,
        tags: [['checked standard', 'conteggi delle facce, dualità, sottoalgebre pari, accoppiamenti delle equazioni, radici e politopi di E6–E8 dalle matrici di Cartan'], ['checked standard', 'pesi di Spin(2n), Cl⁰(p,q) = Cl(p,q−1) (q ≥ 1), la classificazione dei diagrammi di tipo E'], ['ours', 'leggere le lame pari come campi e quelle dispari come sorgenti (vale per F e J, e per ψ e la sua corrente; non per il potenziale A o la tetrade e, che sono campi dispari)'], ['checked standard open', 'se l’arresto a E8 (determinante di Cartan 9 − n; E9 affine, con una radice nulla) c’entri col periodo 8 (noto: E8 è il primo reticolo pari unimodulare, e tali reticoli esistono solo in ranghi divisibili per 8, per la formula della somma di Gauss di Milgram, la cui fase è anche l’orologio di Cl(n,0); l’invariante di Brown delle etichette è la stessa fase della somma di Gauss–Milgram di E_{n}): entrambi mettono E8 a n = 8, con meccanismi che sembrano diversi; se il budget di 8 c’entri è aperto']]
      },
      equations: {
        h: `Altre equazioni: ${numWord('it', stepCount('eq'))} passi, da ${NAV_NAMES.it[STEP_GROUPS.eq[0]].toLowerCase()} a ${NAV_NAMES.it[STEP_GROUPS.eq[stepCount('eq') - 1]].toLowerCase()}`,
        does: `Maxwell è stata la prima equazione che abbiamo potuto disegnare dalla regola dei bit. Altri ${numWord('it', stepCount('eq'))} passi seguono la stessa ricetta, ciascuno disegnato come quadro di incidenze e controllato da uno script: ${STEP_GROUPS.eq.map(id => NAV_NAMES.it[id]).join(' · ')}. I passi dal ${stepNo('eq', 'forque')} al ${stepCount('eq')} sono diversi. I passi ${stepNo('eq', 'forque')} e ${stepNo('eq', 'spin')} prendono le equazioni del lavoro di altri (un articolo sulla dinamica del corpo rigido; un articolo e una lezione sugli spinori), le traducono nella regola dei bit e le mettono in una matrice, così che i loro autori possano controllarle da soli. Il passo ${stepNo('eq', 'spring')} mette una rete di molle sul cubo e la risolve esattamente. Il passo ${stepNo('eq', 'rigid')} sale una scala dal segmento al tesseratto, con un cubo che porta le proprie etichette, un corpo appeso a una molla e una tabella dei riferimenti, e ogni gradino è controllato contro una soluzione esatta. Il passo ${stepNo('eq', 'nullsurf')} prende da un articolo pubblicato alcune affermazioni sulle superfici nulle, le ricostruisce con la regola dei bit e disegna ciascuna dal vivo.`,
        before: 'La pagina delle forme ha mostrato la metà pari del cubo come demicubo e la serie di Gosset che ne cresce.',
        after: 'Avanti: tre altri passi (dal 15 al 17): etichette, gravità di gauge e gruppi finiti, poi altri tre nella pagina delle lenti (dal 18 al 20).',
        tags: [['', 'commutatori dei bivettori per ogni segnatura fino a n = 8; incidenze di Dirac, determinante e covarianza; la scala dell’accoppiamento per n = 1…8; identità di Yang–Mills per dimensione di gauge 2…8; la corrente della materia carica e la sua conservazione, esatte; le identità di Bianchi, la forma di Einstein e la sua divergenza, esatte; versori, il limite di Cartan–Dieudonné e il cubo come gruppo di specchi; il generatore in più s = 0, ±1, la coppia nulla e l’algebra conforme, esatti e con matrici; le equazioni dell’articolo sul forque tradotte nella regola dei bit, esatte come serie di potenze, con un controllo numpy; le etichette, gli idempotenti, i pointor e le fasi di un articolo e di una lezione sugli spinori, esatti sulla regola dei bit; una rete di molle sul cubo, semplice e con il segno del generatore, esatta come serie di potenze; un corpo rigido dal segmento al tesseratto (libero, con una molla, sotto gravità, una trottola libera, pianeti e una luna), 110 affermazioni in 56 righe, esatte come serie di potenze, con un motore in virgola mobile controllato contro di esse'], ['standard', 'la forma di Hestenes (algebra spazio-temporale) dell’equazione di Dirac; so(p,q) come bivettori; gravità al primo ordine (di Cartan); riflessioni, versori, Cartan–Dieudonné, gruppi di Coxeter; la legge di Hooke e lo spettro dell’ipercubo (modi di Walsh); dinamica del corpo rigido nella PGA basata sui piani (Dorst e De Keninck); la decomposizione invariante, i pointor e gli spinori (Roelfs, Eelbode e De Keninck; la lezione di Eelbode); l’instabilità della trottola libera (racchetta da tennis, oscillatore invertito); la legge di gravitazione di Newton e le leggi di Keplero'], ['ours', 'leggere i termini di derivata e di accoppiamento come spigoli e simplessi d’angolo del cubo; le 2ⁿ etichette degli angoli come maschere di bit, con le n+1 sandwich di un riferimento invece di 2ⁿ (misurato su una macchina; conviene da n = 3)'], ['open', 'il segno e la grandezza del termine sorgente, la chiralità e i doppietti elettrodeboli, l’equazione di campo della gravità con la materia, la dinamica conforme (l’articolo sul forque non ne ha), la forma lagrangiana e il moto vincolato dell’articolo, molle con spostamenti vettoriali e i loro modi zero sul cubo, un principio d’azione, urti, giunti e attrito, le accelerazioni delle etichette fuori dalla macchina su cui sono state misurate, la tabella dei pianeti contro la sua fonte JPL']]
      },
      map: {
        h: 'La mappa: dove siamo, l’albero di ciò che sappiamo e il passo successivo',
        does: 'Una pagina per tutto il progetto. Lo stato di ogni parte, un albero della conoscenza in cui ogni ramo dice dove sta nell’app e quale script lo controlla, che cosa si può prendere da altri ricercatori per fare dinamica, i passi successivi e chi ha fatto tutto questo.',
        before: `La pagina delle lenti ha aggiunto i passi dal 18 al 20 (la lente categoriale, Baez e Schuller), dopo la pagina delle etichette con i passi dal 15 al 17. Prima, la pagina delle equazioni è finita con il passo ${stepCount('eq')}, «${NAV_NAMES.it[STEP_GROUPS.eq.at(-1)].toLowerCase()}», e con il bilancio: una riga per ogni famiglia di equazioni, con ciò che è disegnato e ciò che no.`,
        after: 'Poi: le stesse affermazioni una per una, per i ricercatori, con etichette, fonti, controlli e correzioni; poi il modello.',
        tags: [['checked', 'i conteggi di questa pagina sono letti dagli stessi file di dati delle pagine che descrivono'], ['ours', 'il raggruppamento dei rami in lenti e filoni è una nostra lettura'], ['open', 'i passi successivi sono piani, non risultati']]
      },
      researchers: {
        h: 'Per i ricercatori: ogni affermazione con le sue etichette, le fonti e i controlli',
        does: 'La verifica di tutto l’atlante in un solo posto. Ogni affermazione delle pagine è elencata una volta con le sue etichette (standard: da manuale o pubblicata, con una citazione; verificato: uno dei nostri script la conferma; nostro: una nostra lettura, scelta o nome; aperto: non noto o non provato), la fonte che cita e lo script che la controlla. Il terreno noto è standard e verificato, e né nostro né aperto. Poi la matrice di traduzione (elementi di tre gruppi di fonti a confronto con le parti dell’atlante, con grado esatto, strutturale o analogia), i teoremi scritti per l’atlante con lo stato della dimostrazione, le domande che faremmo agli specialisti, le fonti e i vicoli ciechi, le correzioni e i comandi che rieseguono ogni controllo.',
        before: 'La mappa ha mostrato lo stato di ogni parte, l’albero di ciò che sappiamo e i passi successivi.',
        after: 'Ultima tappa: rivolgi qualsiasi domanda al modello, con ogni affermazione etichettata.',
        tags: [['checked', 'i conteggi di questa pagina sono calcolati dalla stessa tabella delle affermazioni che mostra'], ['ours', 'le etichette di ogni riga sono la nostra verifica (due revisori e il responsabile), non il giudizio di un arbitro'], ['open', 'nessuno specialista ha ancora esaminato i teoremi o le etichette']]
      },
      ask: {
        h: 'Chiedi al modello',
        does: 'La guida risponde dagli stessi assiomi e dallo stesso audit. Dichiara lo stato di ogni affermazione e dice “aperto” dove è la risposta onesta.',
        before: `Hai visto la regola, l’atlante, due prove, ${numWord('it', stepCount('shapes'))} passi di forme, ${numWord('it', stepCount('eq'))} passi di equazioni, altri ${numWord('it', stepCount('labels') + stepCount('lens'))} nelle pagine delle etichette e delle lenti, e la mappa.`,
        after: '',
        tags: [['open', 'non è stata provata dal vivo su ogni domanda']]
      }
    },
    hero: {
      'Young Learner': ['Una regola di interruttori, quattro modi di vederla.', 'Gli interruttori sono accesi o spenti. Gira due gruppi insieme e ottieni un nuovo gruppo. Disegniamo questa regola in quattro modi, poi la proviamo sulla luce e sulle particelle.'],
      Physicist: ['Una regola di bit, letta in quattro modi.', 'Le lame sono schemi di bit e i loro prodotti sono XOR sulle etichette. Disegniamo la regola come algebra, simplesso, cubo e numeri, poi la proviamo su due teorie note.'],
      Mathematician: ['Un’algebra, quattro linguaggi di coordinate.', 'Lame di Clifford come maschere di bit con prodotto dato dallo XOR a meno del segno; una struttura di incidenza disegnata come dati di Peirce, facce di simplesso, vertici del cubo ed etichette intere, poi verificata su Maxwell in Cl(k,d) e sul modello di Furey in Cl(0,8).']
    },
    note: 'Matematica standard, riletta. Nostra è la lettura, non l’algebra. Ogni affermazione ha uno stato: verificato, standard, nostro o aperto. Non è una teoria fisica sottoposta a revisione paritaria.',
    metric: { Spatial: ['Spazio +', 'Lettura 1: i generatori con quadrato +1 sono spazio'], Temporal: ['Tempo +', 'Lettura 2: la lettura speculare, con i ruoli di tempo e spazio scambiati (vedi Prova 1)'] }
  }
};


// The page of Steps 15–17 (labels, gauge gravity, finite groups): its frame copy lives with the page (labelsCopy.js)
for (const l of ['en', 'it']) { STORY[l].pages.labels = LABELS_PAGE[l]; STORY_YL[l].pages.labels = LABELS_PAGE_YL[l]; STORY[l].pages.lenses = LENSES_PAGE[l]; STORY_YL[l].pages.lenses = LENSES_PAGE_YL[l]; }
