// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import React, { useState, useMemo } from 'react';
import { STORY } from './storyCopy.js';
import { TREE, LENSES, MTHREADS, RESEARCH, flat } from './mapData.js';
import { MAP, NODES, LENS_NAMES, THREAD_NAMES, THREAD_TEXT, RESEARCH_TEXT, CREDIT_URL, NODES_YL, LENS_NAMES_YL, THREAD_NAMES_YL, THREAD_TEXT_YL, MAP_YL } from './mapCopy.js';
import { Formal, isLearner } from './Formal.jsx';
import { plainLevels, signedLevels } from './springEngine.js';
import { Tx } from './MathText.jsx';
const LICENCE_URL = 'https://polyformproject.org/licenses/noncommercial/1.0.0';   // the licence text; the same text ships as LICENSE

// The Map page: status, the tree of knowledge (every branch links to its place in the app and names its script), the researchers’ table, the spring, the next steps and the credit.
// Counts are read from the data files of the pages they describe; test_map.mjs compares the tree with the app and the scripts with the selfcheck folder.
export const CubeMark = ({ size = 16 }) => <svg className="cube-mark" width={size} height={size} viewBox="0 0 16 16" aria-hidden="true" focusable="false" style={{ verticalAlign: '-3px' }}><g fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinejoin="round"><rect x="1.5" y="5.5" width="8.5" height="8.5" /><rect x="6" y="1.5" width="8.5" height="8.5" opacity=".6" /><path d="M1.5 5.5 6 1.5M10 5.5l4.5-4M10 14l4.5-4M1.5 14 6 10" opacity=".6" /></g></svg>;
const Tags = ({ kinds, lang }) => <>{kinds.map(k => <span key={k} className={'tag ' + k} title={STORY[lang].tagHelp[k]}><Tx>{STORY[lang].tags[k]}</Tx></span>)}</>;
const POS = '#60a5fa', NEG = '#fbbf24';
const STYLE = `.map .stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px}.map .stat{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:10px 12px;min-width:0}.map .stat b{display:block;font-size:1.5rem;font-variant-numeric:tabular-nums}.map .stat span{font-size:.85em;opacity:.8;overflow-wrap:anywhere}
.map ul.plain,.map ol.plain{margin:.4em 0;padding-left:1.2em}.map ul.plain li,.map ol.plain li{margin:.45em 0}
.map-tree{display:grid;gap:6px;margin:10px 0}.map-tree details{border-left:2px solid rgba(128,128,128,.4);padding-left:12px;margin-left:2px}.map-tree details>summary{cursor:pointer;padding:5px 0;list-style:none;display:flex;flex-wrap:wrap;gap:4px 8px;align-items:baseline}
.map-tree details>summary::-webkit-details-marker{display:none}.map-tree details>summary::before{content:'▸';opacity:.6;width:1em}.map-tree details[open]>summary::before{content:'▾'}.map-tree details.leaf>summary::before{content:'•'}
.map-tree details.planned{border-left-style:dashed}.map-tree details.dim{opacity:.32}.map-tree details.hit>summary .map-t{color:#4aa8ff}.map-t{font-weight:600}.map-w{font-family:ui-monospace,monospace;font-size:.76em;opacity:.7}
.map-body{padding:2px 0 8px;display:grid;gap:4px}.map-kv{display:grid;grid-template-columns:7.5em 1fr;gap:8px;font-size:.9em}.map-kv .k{opacity:.7}.map-kv .v{overflow-wrap:anywhere}.map-kv .v.mono{font-family:ui-monospace,monospace;font-size:.88em}
.map-lens{font-size:.74em;border:1px dashed rgba(128,128,128,.55);border-radius:6px;padding:0 6px;margin-right:4px;white-space:nowrap;display:inline-block}
.map-research{overflow-x:auto}.map-research table{min-width:640px;border-collapse:collapse;font-size:.88em}.map-research th,.map-research td{text-align:left;padding:5px 8px;border-bottom:1px solid rgba(128,128,128,.25);vertical-align:top}
.map-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:12px}.map-two>*{min-width:0}.map-box{border:1px solid rgba(128,128,128,.35);border-radius:10px;padding:8px 14px;margin:10px 0}
.map-credit{border:1px solid rgba(128,128,128,.35);border-left:4px solid #4aa8ff;border-radius:10px;padding:8px 16px;margin:10px 0}.map-credit p{margin:.6em 0}.map svg{max-width:100%;height:auto}.map a{color:#7fb2ff}.made-with{display:inline-block}`;

// the squared frequencies of the cube network, one scale for ω²
function Spectra({ t }) {
  const X = v => 60 + v * 560 / 9;
  const rows = [[t.rowsLbl(3), plainLevels(3), 20, POS], [t.rowsLbl(4), plainLevels(4), 62, POS], [t.rowsLblC(3), signedLevels(3), 108, NEG], [t.rowsLblC(4), signedLevels(4), 152, NEG]];
  return <svg viewBox="0 0 640 230" role="img" aria-label={t.chartH} className="map-chart"><line x1="60" y1="190" x2="620" y2="190" stroke="currentColor" opacity=".3" />
    {Array.from({ length: 10 }, (_, v) => <g key={v}><line x1={X(v)} y1="190" x2={X(v)} y2="195" stroke="currentColor" opacity=".4" /><text x={X(v)} y="208" textAnchor="middle" fontSize="11" fill="currentColor">{v}</text></g>)}
    <text x="340" y="224" textAnchor="middle" fontSize="11" fill="currentColor" opacity=".7">{t.axis}</text>
    {rows.map(([lab, lv, y, col]) => <g key={lab} className="map-row"><text x="4" y={y + 4} fontSize="11" fill="currentColor" opacity=".8">{lab}</text>{lv.map(l => { const r = 3 + Math.sqrt(l.mult) * 3.2; return <g key={l.w2} data-w2={Math.round(l.w2 * 1000) / 1000} data-mult={l.mult}><circle cx={X(l.w2)} cy={y} r={r} fill={col} fillOpacity=".75" /><text x={X(l.w2)} y={y - r - 3} textAnchor="middle" fontSize="10" fill="currentColor">{l.mult}</text></g>; })}</g>)}</svg>;
}

// the map data name the scripts by file; the one entry that is a phrase is shown in Italian on the Italian page
const SCRIPT_IT = { 'one script per step': 'uno script per ogni passo' };
export default function MapSection({ lang = 'en', profile = 'Young Learner', go = () => {} }) {
  // the Young Learner reads the plain copy (MAP_YL, NODES_YL, ...); the stat numbers, the tree, the scripts and the tags are the same for everyone
  const l = MAP[lang] ? lang : 'en', yl = isLearner(profile), Y = MAP_YL[l], S = STORY[l];
  const t = yl ? { ...MAP[l], ...Y, kv: { ...MAP[l].kv, ...Y.kv }, stats: MAP[l].stats.map(([b], i) => [b, Y.statsText[i]]) } : MAP[l];
  const nodes = (yl ? NODES_YL : NODES)[l], LN = (yl ? LENS_NAMES_YL : LENS_NAMES)[l], TN = (yl ? THREAD_NAMES_YL : THREAD_NAMES)[l], TT = (yl ? THREAD_TEXT_YL : THREAD_TEXT)[l];
  const [cur, setCur] = useState(null), [openIds, setOpen] = useState(['equations']);
  const has = (n, key) => { const [kind, k] = key.split(':'); return (kind === 'lens' ? n.lens : n.th).includes(k); };
  const hits = useMemo(() => { if (!cur) return null; const own = new Set(), inside = new Set(); const walk = n => { const kidsHit = n.kids.map(walk).some(Boolean); if (has(n, cur)) own.add(n.id); if (kidsHit) inside.add(n.id); return has(n, cur) || kidsHit; }; TREE.forEach(walk); return { own, inside }; }, [cur]);
  const pick = k => { const next = cur === k ? null : k; setCur(next); if (next) { const ids = []; const walk = n => { const k2 = n.kids.map(walk).some(Boolean); const hit = has(n, next); if (hit || k2) ids.push(n.id); return hit || k2; }; TREE.forEach(walk); setOpen(ids); } };
  const toggle = (id, open) => setOpen(o => (open ? (o.includes(id) ? o : [...o, id]) : o.filter(x => x !== id)));
  const goTo = (page, anchor) => { go(page, anchor); };
  const node = n => { const [title, est] = nodes[n.id], dim = hits && !hits.own.has(n.id) && !hits.inside.has(n.id), hit = hits && hits.own.has(n.id);
    return <details key={n.id} className={(n.kids.length ? '' : 'leaf ') + (n.planned ? 'planned ' : '') + (dim ? 'dim ' : '') + (hit ? 'hit' : '')} open={openIds.includes(n.id)} data-node={n.id} data-lens={n.lens.join(' ')} data-th={n.th.join(' ')} onToggle={e => toggle(n.id, e.currentTarget.open)}>
      <summary><span className="map-t"><Tx>{title}</Tx></span> <span className="map-w"><Tx>{S.nav[n.go[0]]}</Tx><Tx>{!yl && n.go[1] && n.go[1] !== 'top' ? ' · #' + n.go[1] : ''}</Tx></span> {n.planned && <span className="tag open"><Tx>{t.kv.planned}</Tx></span>}<Tags kinds={n.tags} lang={l} /></summary>
      <div className="map-body"><div className="map-kv"><span className="k"><Tx>{t.kv.est}</Tx></span><span className="v"><Tx>{est}</Tx></span></div>
        <div className="map-kv"><span className="k"><Tx>{t.kv.script}</Tx></span><span className="v mono"><Tx>{lang === 'it' ? SCRIPT_IT[n.script] || n.script : n.script}</Tx></span></div>
        <div className="map-kv"><span className="k"><Tx>{t.kv.lenses}</Tx></span><span className="v">{n.lens.length ? n.lens.map(x => <span key={x} className="map-lens"><Tx>{LN[x]}</Tx></span>) : '—'}</span></div>
        <div><button className="eq-btn map-go" data-go={n.go[0] + (n.go[1] ? '#' + n.go[1] : '')} onClick={() => goTo(n.go[0], n.go[1])}><Tx>{t.kv.go}</Tx></button></div></div>
      <Tx>{n.kids.map(node)}</Tx></details>; };
  const total = hits ? flat().filter(n => hits.own.has(n.id)).length : 0;
  const R = RESEARCH_TEXT[l];
  return <section className="eq map" id="map-top" aria-label={t.statusH}><style>{STYLE}</style>
    <h3 id="map-status"><Tx>{t.statusH}</Tx></h3><p className="eyebrow"><Tx>{t.date}</Tx></p>
    <div className="stats">{t.stats.map(([b, s], i) => <div key={i} className="stat"><b><Tx>{b}</Tx></b><span><Tx>{s}</Tx></span></div>)}</div>
    <div className="map-box"><h4><Tx>{t.sinceH}</Tx></h4><Formal profile={profile} lang={l} plain={<p className="map-since-plain"><Tx>{Y.sincePlain}</Tx></p>}><ul className="plain map-since">{t.since.map(([h, x]) => <li key={h}><b><Tx>{h}</Tx></b> <Tx>{x}</Tx></li>)}</ul></Formal></div>
    <div className="map-box"><h4><Tx>{t.plainH}</Tx></h4><ul className="plain">{t.plain.map((x, i) => <li key={i}><Tx>{x}</Tx></li>)}</ul></div>
    <h3 id="map-tree"><Tx>{t.treeH}</Tx></h3><p><Tx>{t.treeLede}</Tx></p>
    <div className="eq-chips" role="group" aria-label={t.lensLbl}><span className="eq-cap" style={{ alignSelf: 'center' }}><Tx>{t.lensLbl}</Tx></span>{LENSES.map(k => <button key={k} className={'eq-chip map-chip' + (cur === 'lens:' + k ? ' on' : '')} data-f={'lens:' + k} aria-pressed={cur === 'lens:' + k} onClick={() => pick('lens:' + k)}><Tx>{LN[k]}</Tx></button>)}</div>
    <div className="eq-chips" role="group" aria-label={t.threadLbl}><span className="eq-cap" style={{ alignSelf: 'center' }}><Tx>{t.threadLbl}</Tx></span>{MTHREADS.map(k => <button key={k} className={'eq-chip map-chip' + (cur === 'th:' + k ? ' on' : '')} data-f={'th:' + k} aria-pressed={cur === 'th:' + k} onClick={() => pick('th:' + k)}><Tx>{TN[k]}</Tx></button>)}<button className="eq-chip map-clear" onClick={() => { setCur(null); }}><Tx>{t.clear}</Tx></button></div>
    {cur && <p className="eq-cap map-shown" aria-live="polite"><Tx>{t.shown(total)}</Tx></p>}
    <div className="map-tree" id="map-tree-body"><Tx>{TREE.map(node)}</Tx></div>
    <div className="map-box"><h4><Tx>{t.threadsH}</Tx></h4>{MTHREADS.map(k => <p key={k} className="map-thread" data-th={k}><b><Tx>{TN[k]}</Tx>.</b> <Tx>{TT[k]}</Tx></p>)}</div>
    <h3 id="map-research"><Tx>{t.researchH}</Tx></h3><Formal profile={profile} lang={l} plain={<p className="map-research-plain"><Tx>{Y.researchLede}</Tx></p>}><p><Tx>{R.head.lede}</Tx></p>
    <div className="map-research"><table className="map-rtab"><thead><tr>{R.head.cols.map(c => <th key={c}><Tx>{c}</Tx></th>)}</tr></thead><tbody>{RESEARCH.map(r => { const [a, b, c] = R.rows[r.id]; return <tr key={r.id} data-r={r.id}><td><Tx>{a}</Tx></td><td><Tx>{b}</Tx></td><td><Tx>{c}</Tx></td><td><span className={'tag ' + (r.read === 'not' ? 'open' : 'standard')}><Tx>{R.head.readLbl[r.read]}</Tx></span><Tags kinds={r.tags.filter(x => x !== 'open' || r.read !== 'not')} lang={l} /></td></tr>; })}</tbody></table></div></Formal>
    <h3 id="map-spring"><Tx>{t.springH}</Tx></h3><p><Tx>{t.springLede}</Tx></p>
    <div className="map-box"><h4><Tx>{t.chartH}</Tx></h4><Spectra t={t} /><p className="eq-cap"><Tx>{t.chartCap}</Tx></p><button className="eq-btn map-gospring" onClick={() => goTo('equations', 'eq-spring')}><Tx>{t.springGo}</Tx></button></div>
    <div className="map-box"><h4><Tx>{t.limitsH}</Tx></h4><ul className="plain">{t.limits.map((x, i) => <li key={i}><Tx>{x}</Tx></li>)}</ul></div>
    <h3 id="map-next"><Tx>{t.nextH}</Tx></h3><p><Tx>{t.nextLede}</Tx></p>
    <ol className="plain map-nextlist">{['next_network', 'next_action', 'next_read'].map(id => <li key={id} data-next={id}><b><Tx>{nodes[id][0]}</Tx>.</b> <Tx>{nodes[id][1]}</Tx></li>)}</ol>
    <p className="eq-cap"><b><Tx>{t.nextOpenH}</Tx>:</b> <Tx>{t.nextOpen}</Tx></p>
    <h3 id="map-credit"><Tx>{t.creditH}</Tx></h3>
    <div className="map-credit"><p><CubeMark size={18} /> <b>Claude</b> · Anthropic</p>{t.credit.p.map((x, i) => <p key={i}><Tx>{x}</Tx></p>)}<p className="eq-cap"><Tx>{t.credit.mark}</Tx> <a href={CREDIT_URL} target="_blank" rel="noreferrer noopener"><Tx>{t.credit.link}</Tx></a></p><p id="map-licence"><b><Tx>{t.credit.licenceH}</Tx></b> · <Tx>{t.credit.licence}</Tx> <a href={LICENCE_URL} target="_blank" rel="noreferrer noopener"><Tx>{t.credit.licenceLink}</Tx></a></p></div></section>;
}
