// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
import { makePuzzle, puzzleAudience, hintFor, issueToken, verifyToken, tooFast, makeNonceStore, makeLimiter, honeypotTripped, readConfig, settings, originAllowed, clientKey, readJson, validateFields, HINT, MAX_BODY, TOKEN_LIFETIME_S } from '../lib/contactGuard.js';
export const config = { runtime: 'edge' };

// Contact form route. GET hands out a puzzle (and a signed token that stands for its answer); POST checks the human check and forwards one message to a form service.
// The site stores nothing: no message, no address, no answer. Answers are fixed codes, never text from upstream, never anything from the message. The log gets an error name
// or a status number at most. No CORS header is sent. Details and limits of the human check: lib/contactGuard.js and README_update_contact.md.
const limiter = makeLimiter(), used = makeNonceStore();
const HEADERS = { 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'vary': 'Origin' };
const json = (status, body, extra = {}) => new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json; charset=utf-8', ...HEADERS, ...extra } });

async function issue(request, cfg) {
  const q = new URL(request.url).searchParams, lang = q.get('lang') === 'it' ? 'it' : 'en';
  const aud = puzzleAudience(q.get('aud'));                     // ?aud=yl: the Young Learner's plain-word puzzles; anything else: the usual ones
  const puzzle = makePuzzle(Math.random, aud);
  const token = await issueToken(cfg.secret, puzzle.answer, Date.now());
  return json(200, { token, question: puzzle.question[lang], hint: aud ? hintFor(lang, aud) : HINT[lang], expiresIn: TOKEN_LIFETIME_S });
}

export default async function handler(request) {
  if (request.method !== 'GET' && request.method !== 'POST') return json(405, { error: 'method_not_allowed' }, { allow: 'GET, POST' });
  if (request.method === 'GET') { const cfg = readConfig(); return cfg ? issue(request, cfg) : json(503, { error: 'not_configured' }); }

  if (!originAllowed(request)) return json(403, { error: 'forbidden' });
  if (!/^application\/json\b/i.test(request.headers.get('content-type') || '')) return json(415, { error: 'unsupported_media_type' });
  const parsed = await readJson(request, MAX_BODY);
  if (parsed.status) return json(parsed.status, { error: parsed.error });
  const cfg = readConfig(); if (!cfg) return json(503, { error: 'not_configured' });
  const body = parsed.body;

  if (honeypotTripped(body.website)) return json(400, { error: 'rejected' });
  const now = Date.now(), v = await verifyToken(cfg.secret, body.token, body.answer, now, used);
  if (!v.ok) return json(400, { error: v.reason });
  if (tooFast(v.issuedAt, now)) return json(400, { error: 'too_fast' });
  const key = clientKey(request), s = settings(), rate = limiter.check(key, s.perClient, s.perInstance);
  if (!rate.ok) return json(429, { error: 'rate_limited' }, { 'retry-after': String(rate.retryAfter) });
  const fields = validateFields(body); if (!fields.ok) return json(400, { error: fields.error });
  const { message, name, reply, lang } = fields.value;

  if (!used.add(v.nonce, v.exp * 1000, now)) return json(400, { error: 'replayed' });      // one token, one message; from here on the puzzle is spent
  limiter.hit(key);
  try {
    const upstream = await fetch(cfg.endpoint, {
      method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ message, name: name || undefined, _replyto: reply || undefined, lang, page: 'cascade-atlas' }),     // empty optional fields are left out
      signal: AbortSignal.timeout(10000),
    });
    upstream.body?.cancel().catch(() => {});
    if (!upstream.ok) { console.error('contact: form service status', upstream.status); return json(502, { error: 'delivery_failed' }); }
    return json(200, { ok: true });
  } catch (error) {
    console.error('contact: form service failure', error?.name || 'error');
    return json(502, { error: 'delivery_failed' });
  }
}
