// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// The Baez widgets without a browser (step 19 of the lenses page; BaezWidgets.jsx, baezEngine.js, baezWidgetsCopy.js, baezWidgetData.js): the check script
// selfcheck/reports/lens_baez_check.py runs under python3, passes and rebuilds exactly the stored JSON; the download mirror is the file byte for byte; the data
// module is the JSON; the browser engine gives every number the widgets show, equal to the stored JSON (live = stored); the copy has the same shape in English
// and Italian, four-flag tags, the numbers of the JSON in its captions, a formula-free and jargon-free Young Learner voice, no retired wording, check ids
// that exist in a shipped script; the claims rows LNB-101 ... cover every tagged caption line; no e-mail address.   Run: node test_lens_baez_widgets.mjs
import fs from 'node:fs'; import path from 'node:path'; import { spawnSync } from 'node:child_process';
import { PKG } from './paths.mjs';
import * as E from './baezEngine.js';
import D from './baezWidgetData.js';
import { BWC } from './baezWidgetsCopy.js';
import { BZW_PY } from './baezWidgetsSelfcheckSource.js';
import { buildClaims } from './make_claims_data.mjs';
let checks = 0, bad = 0; const ok = (c, m) => { checks++; if (!c) { bad++; console.log('FAIL', m); } };
const rd = f => fs.readFileSync(path.join(PKG, f), 'utf8'), same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const SCRIPT = 'selfcheck/reports/lens_baez_check.py', JSONF = 'selfcheck/reports/lens_baez_check.json';
const FOUR = ['standard', 'checked', 'ours', 'open'];

// ---- 1. the script: runs, passes, rebuilds the stored JSON; header, size, standard library only, ASCII
const run = spawnSync('python3', [path.join(PKG, SCRIPT), '--compare', path.join(PKG, JSONF)], { encoding: 'utf8', timeout: 100000 });
const out = run.stdout || '';
ok(run.status === 0 && /^10 checks ok, 0 failed$/m.test(out) && /^stored data == rebuilt data$/m.test(out), 'lens_baez_check.py passes (10 checks) and rebuilds the stored JSON exactly: ' + out.split('\n').slice(-4).join(' | ') + (run.stderr || '').slice(0, 300));
const IDS = ['P1', 'P1b', 'P2', 'P2b', 'P3', 'P3b', 'P3c', 'P4', 'P4b', 'P5'];
ok(IDS.every(id => new RegExp(`^ok   ${id}: `, 'm').test(out)) && (out.match(/^(ok|FAIL) /gm) || []).length === IDS.length, 'one ok line per check id, in the table of DECISIONS §4 (P1-P5) plus P1b, P2b, P3b, P3c, P4b');
const py = rd(SCRIPT);
ok(py.split('\n').length <= 500 && /^#!\/usr\/bin\/env python3\n# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0\n# Required Notice: Copyright \(c\) 2026 the Cascade Atlas authors\n# Free for noncommercial use only/.test(py), 'the script has the SPDX header and at most 500 lines (' + py.split('\n').length + ')');
ok(!/^\s*(import|from)\s+(numpy|scipy|networkx|sympy)\b/m.test(py) && /^[\x00-\x7f]*$/.test(py), 'the script uses the standard library only and is plain ASCII');
ok(BZW_PY === py, 'the download mirror baezWidgetsSelfcheckSource.js equals the script byte for byte');
ok(same(D, JSON.parse(rd(JSONF))), 'baezWidgetData.js is the stored JSON (regenerate with sh selfcheck/regen_lens_baez_widgets.sh)');
ok(/regen_lens_baez_widgets/.test(rd('baezWidgetData.js').split('\n')[3]) && fs.existsSync(path.join(PKG, 'selfcheck/regen_lens_baez_widgets.sh')), 'the data module names its generator selfcheck/regen_lens_baez_widgets.sh');

// ---- 2. BW1: the engine against the stored labels, classes, sums, grading, ad N
ok(same(E.LABELS.map(E.labelInfo), D.P1.labels), 'BW1: all 32 labels (a, b, N, parity, Y, Q, T3, Peirce values, piece) live = stored');
const cls = E.classesOf(E.EVEN);
ok(same(cls.map(c => [c.a, c.b, c.n, c.piece, c.Y, c.Q, c.l1, c.l2, c.labels]), D.P1.classes.map(c => [c.a, c.b, c.n, c.piece, c.Y, c.Q, c.l1, c.l2, c.labels])), 'BW1: the six classes of the 16 even labels live = stored');
ok(same(cls.map(c => c.n), [1, 3, 6, 2, 1, 3]) && same(D.P1.sizes, [1, 3, 6, 2, 1, 3]) && same(E.grading(), D.P1.grading) && same(D.P1.grading, [1, 5, 10, 10, 5, 1]), 'BW1: sizes 1, 3, 6, 2, 1, 3 and grading 1, 5, 10, 10, 5, 1');
ok(same(E.anomalySums(E.EVEN), D.P1.sums) && Object.values(D.P1.sums).every(v => v === '0'), 'BW1: the five anomaly sums over the 16 even labels are exactly 0, live = stored');
const odd = E.classesOf(E.family(true));
ok(odd.length === 6 && same(odd.map(c => c.n), [3, 1, 2, 6, 3, 1]) && odd.every(c => { const ev = cls.find(k => k.a === 2 - c.a && k.b === 3 - c.b); return ev && E.fstr(E.fneg(E.fr(...ev.Y.split('/').map(Number)))) === c.Y && same([...ev.Q].map(q => q.startsWith('-') ? q.slice(1) : q === '0' ? '0' : '-' + q).sort(), [...c.Q].sort()); }), 'BW1: after "flip all five" the 16 odd labels form the complement classes with Y and every Q reversed');
ok(same(E.anomalySums(E.family(true)), D.P1.sums) && E.LABELS.every(x => E.flipAll(E.flipAll(x)) === x && E.pc(E.flipAll(x)) % 2 !== E.pc(x) % 2), 'BW1: the flipped family sums to 0 too; the flip is an involution that swaps parity');
ok(E.chargeSum(E.EVEN) === '0' && E.chargeSum([3]) === '1' && E.chargeSum([5]) === '2/3' && E.chargeSum([6]) === '-1/3', 'BW1: picked-charge sums: all 16 add to 0; single labels 1, 2/3, -1/3');
const adn = E.adNDegrees();
ok(adn.ok && same(adn.counts, D.P1.adN) && same(D.P1.adN, { 2: 10, 0: 25, '-2': 10 }), 'BW1: ad N degrees 10 + 25 + 10, live = stored');
for (let a = 0; a <= 2; a++) for (let b = 0; b <= 3; b++) ok(D.P1.labels.filter(l => l.a === a && l.b === b).length === [1, 2, 1][a] * [1, 3, 3, 1][b], `BW1: cell (${a}, ${b}) holds C(2,${a}) C(3,${b}) labels`);

// ---- 3. BW2 (stored): the tables and their sums
const P2 = D.P2, sum = a => a.reduce((x, y) => x + y, 0);
ok(same(P2.f4, [2, 4, 3, 6, 12]) && same(P2.e7, [3, 6, 0, 12, 6]) && sum(P2.f4) === 27 && sum(P2.e7) === 27 && !same(P2.f4, P2.e7), 'BW2: 2+4+3+6+12 = 27 = 3+6+0+12+6, two different tables');
ok(same(P2.e7_16, [2, 2, 0, 6, 6]) && same(P2.e7_11, [1, 4, 0, 6, 0]) && P2.e7.every((v, k) => v === P2.e7_16[k] + P2.e7_11[k]) && sum(P2.e7_16) === 16 && sum(P2.e7_11) === 11, 'BW2: the E7 27 = the 16 of one generation + 11 further states, class by class');
ok(same(P2.classes, [['0', '0'], ['0', '3/8'], ['0', '1'], ['4/9', '0'], ['4/9', '3/8']]) && same(P2.stab, { f4: 52, frame: 28, B: 16, A: 36, X: 18, SM: 12 }), 'BW2: Casimir classes and the stored stabiliser dimensions 52, 28, 16, 36, 18, 12');

// ---- 4. BW3: the ladder live = stored, the branchings stored and consistent
const lad = E.ladder();
ok(same([lad.roots, lad.sizes, lad.dims, lad.g1, lad.graded, lad.grades8], [D.P3.roots, D.P3.sizes, D.P3.dims, D.P3.g1, D.P3.graded, D.P3.grades8]), 'BW3: 240 roots, rungs, dimensions, grade-1 sizes, gradings live = stored');
ok(same(lad.sizes, [240, 126, 72, 40, 20, 8]) && same(lad.g1, [56, 27, 16, 10, 6]) && same(lad.graded, [5, 3, 3, 3, 3]) && same(lad.dims, [248, 133, 78, 45, 24, 11]), 'BW3: 240, 126, 72, 40, 20, 8; 56, 27, 16, 10, 6; 5-graded then 3-graded');
ok(same(E.linkChain(), D.P3.links) && same(D.P3.links, [240, 56, 27, 16, 10, 6, 3]), 'BW3: the link chain 240, 56, 27, 16, 10, 6, 3 live = stored');
ok(E.e8Roots().every(r => r.reduce((s, v) => s + v * v, 0) === 8) && E.e8Roots().filter(r => r.some(v => Math.abs(v) === 2)).length === 112 && [...E.coefficients().values()].every(c => c.every(v => v >= 0) || c.every(v => v <= 0)), 'BW3: the roots are D8 (112) and D8 + 1/2 (128), squared length 2, each a non-negative or non-positive integer combination of the simple roots');
for (const n of [4, 5, 6, 7]) { const d = D.P3.dec[String(n)]; ok(d.reduce((s, k) => s + k.m * k.dim, 0) === lad.g1[8 - n] && (n === 4 || D.P3.dec[String(n - 1)].every(k => (d.find(x => x.su3 === k.su3 && x.su2 === k.su2) || { m: 0 }).m >= k.m)), `BW3: the stored pieces of the grade-1 space of rung ${n} add up to ${lad.g1[8 - n]} and contain those of the rung below`); }

// ---- 5. BW4: Kepler
for (const e of [1, 0, -1]) { const k = E.kepler(e), s = D.P4.eps[String(e)];
  ok(k.brackets && same(k.killing, s.killing) && same(k.squares, s.squares) && k.turn === s.turn && k.slide === s.slide && k.stretch === s.stretch, `BW4: eps = ${e}: brackets, Killing ${k.killing}, move squares ${k.squares} live = stored`); }
ok(same(D.P4.eps['1'].killing, [0, 6, 0]) && same(D.P4.eps['0'].killing, [0, 3, 3]) && same(D.P4.eps['-1'].killing, [3, 3, 0]) && E.kepler(1).halves === true, 'BW4: (0,6,0), (0,3,3), (3,3,0); for eps = +1 the halves A, B commute');
ok(same(E.shells(), D.P4.shells) && same(E.shellsSpin(), D.P4.shells_spin) && same(D.P4.shells_spin, [2, 8, 18, 32, 50, 72, 98]), 'BW4: shells n^2 and 2n^2 live = stored');
ok(E.epsOfEnergy(-0.3) === 1 && E.epsOfEnergy(0) === 0 && E.epsOfEnergy(0.3) === -1 && Math.abs(E.keplerOrbit(-0.5).e) < 1e-12 && E.keplerOrbit(0).e === 1 && E.keplerOrbit(0.4).e > 1, 'BW4: eps = -sign(E); the picture is a circle at E = -1/2, a parabola at 0, a hyperbola above');
ok(E.MOVES.every(m => [1, 0, -1].every(e => Object.is(E.moveSquare(m, e), E.moveSquare(m, e) + 0))), 'BW4: move squares are -1, 0, +1 (never -0)');

// ---- 6. BW5: the map (stored from the report's Fig. 1)
const cnt = E.edgeCounts();
ok(E.PAPERS.length === 7 && E.EDGES.length === 8 && same(cnt, { cites: 3, ours: 2, computed: 2, open: 1 }), 'BW5: 7 papers, 8 lines: 3 citations, 2 computed, 2 our reading, 1 open');
ok(E.EDGES.filter(e => e.kind === 'cites').every(e => E.CLUSTER.includes(e.from) && E.CLUSTER.includes(e.to)) && !E.EDGES.some(e => e.from === 'cospan' || e.to === 'cospan'), 'BW5: the three citations stay inside the four-paper cluster; the cospan paper has no line');

// ---- 7. BW6 and BW7
ok(same(E.eisensteinRings(), D.P5.rings) && same(D.P5.rings, [1, 6, 0, 6, 6, 0, 0, 12]), 'BW6: rings 1, 6, 0, 6, 6, 0, 0, 12 live = stored');
const sh = E.shadows();
ok(same(sh.points, D.P5.points) && same(sh.byRing, D.P5.shadows) && same(D.P5.shadows, { 0: 30, 1: 90, 3: 6 }), 'BW6: the 126 shadows 30 / 90 / 6 on rings 0 / 1 / 3, positions live = stored');
ok(E.eisensteinPoints().length === E.eisensteinRings().reduce((s, v) => s + v, 0), 'BW6: the drawn lattice points are exactly the counted ones');
const m = E.madelung();
ok(same(m, D.P5.madelung) && same(m.closings, [2, 10, 18, 36, 54, 86, 118]) && same(m.periods, [2, 8, 8, 18, 18, 32, 32]), 'BW7: Madelung closings and periods live = stored');
ok(E.fillTo(36).closed && E.fillTo(36).row === 4 && E.fillTo(37).name === '5s' && E.fillTo(37).closesAt === 54 && E.fillTo(1).name === '1s' && E.fillTo(118).closed && E.fillTo(118).row === 7 && E.fillTo(21).name === '3d', 'BW7: N = 36 closes row 4; 37 opens 5s; 21 is in 3d; 118 closes row 7');

// ---- 8. the copy: same shape in both languages, four flags, numbers from the JSON, voices
const shape = (a, b, p) => { if (typeof a !== typeof b) return [p + ': type']; if (typeof a === 'function') return a.length === b.length ? [] : [p + ': arity'];
  if (Array.isArray(a)) { if (!Array.isArray(b) || a.length !== b.length) return [p + ': length']; if (a.length === 2 && typeof a[0] === 'string' && FOUR.some(f => a[0].split(' ').includes(f))) return a[0] === b[0] ? [] : [p + ': tags differ']; return a.flatMap((x, i) => shape(x, b[i], p + '.' + i)); }
  if (a && typeof a === 'object') { const ka = Object.keys(a).sort(), kb = Object.keys(b).sort(); if (!same(ka, kb)) return [p + ': keys ' + ka.filter(k => !kb.includes(k)).concat(kb.filter(k => !ka.includes(k)))]; return ka.flatMap(k => shape(a[k], b[k], p + '.' + k)); }
  if (typeof a === 'string') return a.length && b.length ? [] : [p + ': empty']; return []; };
const sh2 = shape(BWC.en, BWC.it, 'BWC');
ok(sh2.length === 0, 'the English and Italian copy have the same shape, the same tags line by line, and no empty string: ' + sh2.slice(0, 6).join('; '));
const lines = [];   // every tagged line: [path, tags, text, voice]
const walk = (o, p, yl) => { if (Array.isArray(o) && o.length === 2 && typeof o[0] === 'string' && typeof o[1] === 'string' && o[0].split(' ').some(f => FOUR.includes(f))) { lines.push([p, o[0].split(' '), o[1], yl]); return; }
  if (o && typeof o === 'object') for (const k of Object.keys(o)) walk(o[k], p + '.' + k, yl || /Y$/.test(k)); };
for (const L of ['en', 'it']) walk(BWC[L], L, false);
ok(lines.length === 2 * 78, 'there are 78 tagged lines per language (' + lines.length / 2 + ')');
ok(lines.every(([, f]) => f.length && f.every(x => FOUR.includes(x)) && new Set(f).size === f.length && same(f, FOUR.filter(x => f.includes(x)))), 'every tag is one of the four flags, in the canonical order, without repeats');
const capOf = (L, w, i) => BWC[L][w].cap[i][1], capY = (L, w, i) => BWC[L][w].capY[i][1], AND = { en: ' and ', it: ' e ' };
for (const L of ['en', 'it']) {
  ok(capOf(L, 'bw1', 0).includes(D.P1.sizes.slice(0, 5).join(', ') + AND[L] + D.P1.sizes[5]) && capY(L, 'bw1', 0).includes(D.P1.sizes.slice(0, 5).join(', ') + AND[L] + D.P1.sizes[5]), `${L}: the BW1 captions carry the class sizes of the JSON`);
  ok(capOf(L, 'bw2', 0).includes(D.P2.f4.join(', ')) && capOf(L, 'bw2', 0).includes(D.P2.e7.join(', ')) && capOf(L, 'bw2', 1).includes(D.P2.f4.join(', ')) && capOf(L, 'bw2', 4).includes(D.P2.e7_16.join(', ')) && capOf(L, 'bw2', 4).includes(D.P2.e7_11.join(', ')) && capOf(L, 'bw2', 5).includes(String(D.P2.stab.X)) && capOf(L, 'bw2', 5).includes(String(D.P2.stab.A)), `${L}: the BW2 captions carry the stored tables`);
  ok(capOf(L, 'bw3', 0).includes(D.P3.sizes.slice(1, 5).join(', ') + AND[L] + D.P3.sizes[5]) && capOf(L, 'bw3', 0).includes(D.P3.g1.slice(0, 4).join(', ') + AND[L] + D.P3.g1[4]) && capOf(L, 'bw3', 5).includes(D.P3.links.slice(1, 6).join(', ')), `${L}: the BW3 captions carry the ladder and the link chain`);
  ok(['1', '0', '-1'].every(e => capOf(L, 'bw4', 0).includes('(' + D.P4.eps[e].killing.join(',') + ')')) && capOf(L, 'bw4', 3).includes(D.P4.shells_spin.join(', ')), `${L}: the BW4 captions carry the three Killing signatures and the shells`);
  ok(capOf(L, 'bw6', 0).includes(D.P5.rings.join(', ')) && capY(L, 'bw6', 0).includes(D.P5.rings.slice(0, 7).join(', ') + AND[L] + D.P5.rings[7]) && [30, 90, 6].every(v => capOf(L, 'bw6', 1).includes(String(v)) && capY(L, 'bw6', 1).includes(String(v))), `${L}: the BW6 captions carry the rings and the shadows`);
  ok(capOf(L, 'bw7', 1).includes(D.P5.madelung.closings.join(', ')) && capOf(L, 'bw7', 1).includes(D.P5.madelung.periods.join(', ')) && capY(L, 'bw7', 2).includes(D.P5.madelung.closings.slice(0, 6).join(', ') + AND[L] + '118'), `${L}: the BW7 captions carry the closings and the periods`);
}
// the Young Learner voice: every string under a key ending in Y (and what the Y functions return) is formula-free and jargon-free
const ylText = [];
const ywalk = (o, p, yl) => { if (typeof o === 'string') { if (yl) ylText.push([p, o]); return; } if (typeof o === 'function') return; if (o && typeof o === 'object') for (const k of Object.keys(o)) ywalk(o[k], p + '.' + k, yl || /Y$/.test(k)); };
for (const L of ['en', 'it']) { ywalk(BWC[L], L, false); const t = BWC[L];
  const i = { ...E.labelInfo(5), bits: t.bw1.bits(5) }; ylText.push([L + '.readY', t.bw1.readY(i, 'quark (up quark)')], [L + '.pickY', t.bw1.pickY(16, '0')], [L + '.lblY', t.bw1.lblY(13, 3)], [L + '.familyY', t.bw1.familyY(true)],
    [L + '.countY', t.bw4.countY(E.kepler(0))], [L + '.readY4', t.bw4.readY(t.bw4.kindsY[0], t.bw4.countY(E.kepler(-1)))], [L + '.readY6', t.bw6.readY(2, 0, 0)], [L + '.readY7', t.bw7.readY({ ...E.fillTo(37), N: 37 })], [L + '.provY', t.prov.liveY + t.prov.storedY]); }
const FORMULA = /[=^_√∑∫⊂⊗⊕ℂℝℍ𝕆Λλεωαβγδμνσπθ]|[α-ωΑ-Ω]|\b[a-z]\(|\(\d+,\s*\d+\)/;
const JARGON = /\b(algebra|algebr[ae]|radical|radicale|Frobenius|Jordan|Peirce|Casimir|Killing|bivector|bivettor|lattice|reticolo|hypercharge|ipercarica|anomal|Clifford|isospin|tripot|Eisenstein|\bLie\b|Madelung|eigen|autovalor|Hamming|Fock|XOR|label|etichett|representation|rappresentazion|subshell|sottoguscio|signature|segnatura|derived|derivat)/i;
const badY = ylText.filter(([, s]) => FORMULA.test(s.replace(/\b\d+\/\d+\b/g, '')) || JARGON.test(s));
ok(ylText.length > 60 && badY.length === 0, `the Young Learner strings (${ylText.length}) carry no formula, no Greek letter and none of the technical words: ` + badY.slice(0, 4).map(([p, s]) => p + ': ' + s.slice(0, 70)).join(' | '));
// retired wording (DECISIONS §2, X10) in every string of the copy, in both languages
const allText = []; const awalk = (o, p) => { if (typeof o === 'string') allText.push([p, o]); else if (typeof o === 'function') { /* templates checked through their outputs above */ } else if (o && typeof o === 'object') for (const k of Object.keys(o)) awalk(o[k], p + '.' + k); };
awalk(BWC, 'BWC');
const RETIRED = [/antiparticle|antiparticell/i, /\bHodge\b/i, /\bexplain|\bspieg/i, /\bconserv/i, /\bderived\b|\bderivat[oaie]\b/i, /Schl[äa]fli/i, /so\(10\)/, /light cone|cono di luce/i, /Golay|three 8s|tre 8|24 = 3/i, /particle to antiparticle/i, /Minkowski/i, /\bthe group\b(?! of the forces| delle forze)/i, /horizon|orizzont/i];
const hits = allText.filter(([, s]) => RETIRED.some(r => r.test(s)));
ok(hits.length === 0, 'no retired wording in the widget copy (antiparticle, Hodge, explains, conserved, derived, Schläfli, so(10), light cone, Golay / three 8s, Minkowski, "the group", horizon): ' + hits.slice(0, 4).map(([p, s]) => p + ': ' + s.slice(0, 80)).join(' | '));
ok(lines.filter(([, , s]) => /charge conjugation|coniugazione di carica|building a generation|generazione costruita|spring’s signs|segni della molla/i.test(s)).every(([, f]) => same(f, ['ours'])), 'a line that calls the flip charge conjugation, reads the ladder as building a generation, or names the spring’s signs is tagged ours alone');
ok(lines.filter(([, f]) => f.includes('ours')).every(([, , s]) => !/\bderiv(ed|ation)\b/i.test(s)), 'no line tagged ours says derived');
// check ids named in the copy exist in a shipped script (ranges: both ends)
const SCRIPTS = { baez: 'selfcheck/reports/baez_check.py', bzw: SCRIPT, fibre: 'selfcheck/reports/fibre_check.py' };
const src = Object.fromEntries(Object.entries(SCRIPTS).map(([k, f]) => [k, rd(f)]));
const ids = new Set(); const idText = allText.map(x => x[1]).concat(Object.values(BWC.en).flatMap(w => (w && w.ids) || [])).concat(E.EDGES.flatMap(e => e.checks)).join(' ');
for (const mm of idText.matchAll(/\b(baez|bzw|fibre)·([A-Z]\d+[a-z]?)(?:–([A-Z]\d+)?([a-z]))?/g)) { const [, ns, a, b, c] = mm; ids.add(ns + ':' + a); if (c) ids.add(ns + ':' + (b ? b + c : a.replace(/[a-z]$/, '') + c)); }
const missing = [...ids].filter(x => { const [ns, id] = x.split(':'); return !new RegExp(`chk\\('${id}'`).test(src[ns]); });
ok(ids.size > 40 && missing.length === 0, `every check id named in the widgets (${ids.size}, ranges by both ends) is a chk(...) of its shipped script: missing ${missing.join(', ')}`);
const thms = [...new Set([...idText.matchAll(/Thm (T\d+)/g)].map(x => x[1]))];
ok(thms.length >= 2 && thms.every(t => fs.existsSync(path.join(PKG, 'researchers_checks', `check_${t}.py`))), 'every theorem named (' + thms.join(', ') + ') has its check script in researchers_checks/');

// ---- 9. the claims rows LNB-101 ... (claimsLocators_lnbw.json): one per tagged caption line, the same flags, who sees it
const rows = JSON.parse(rd('claimsLocators_lnbw.json')), claims = (await buildClaims()).filter(c => c.group === 'LNB' && /^LNB-1\d\d$/.test(c.id));
ok(rows.length === 78 && rows.every((r, i) => r.id === 'LNB-' + (101 + i) && r.group === 'LNB' && r.groupName === 'Baez (step 19)' && r.shown_on.page === 'lenses' && r.shown_on.tab === 'baez'), 'claims: 78 rows LNB-101 ... LNB-178, group LNB, shown on lenses / baez');
const enLines = lines.filter(([p]) => p.startsWith('en.'));
ok(enLines.every(([p, f, s]) => claims.filter(c => c.en.length === 1 && c.en[0].text === s && same(c.en[0].flags, f)).length === 1), 'claims: every English tagged line of the widgets is exactly one row, with the same flags: ' + enLines.filter(([, f, s]) => !claims.some(c => c.en[0].text === s)).map(x => x[0]).slice(0, 4).join(', '));
ok(claims.every(c => c.it && c.it.length === 1 && same(c.it[0].flags, c.en[0].flags) && same(c.flags, c.flagsSpec)), 'claims: every row has its Italian line with the same flags, and its flags are the audit flags');
const visOf = p => (/Y\./.test(p.replace(/^en\./, '')) || /\.capY\.|\.edgesY\./.test(p) ? ['Young Learner'] : /\.bw7\./.test(p) ? ['Physicist'] : ['Physicist', 'Mathematician']);
ok(enLines.every(([p, , s]) => same(claims.find(c => c.en[0].text === s).visibleTo, visOf(p))), 'claims: the plain lines are for the Young Learner, the formal ones for the Physicist and the Mathematician (BW7: the Physicist)');
// ---- 10. no e-mail address in the files of this agent
const MINE = ['BaezWidgets.jsx', 'baezEngine.js', 'baezWidgetsCopy.js', 'baezWidgetData.js', 'baezWidgetsSelfcheckSource.js', SCRIPT, JSONF, 'selfcheck/regen_lens_baez_widgets.sh', 'claimsLocators_lnbw.json', 'test_lens_baez_widgets.mjs', 'test_lens_baez_widgets_ui.mjs'];
const MAIL = new RegExp('[\\w.+-]+@[\\w-]+\\.[\\w.-]+|' + 'mail' + 'to:', 'i');   // built from parts, so that this file does not match itself
ok(MINE.every(f => fs.existsSync(path.join(PKG, f)) && !MAIL.test(rd(f))), 'no e-mail address in any file of the Baez widgets: ' + MINE.filter(f => !fs.existsSync(path.join(PKG, f)) || MAIL.test(rd(f))).join(', '));
console.log(`${checks} checks`); console.log(bad ? bad + ' FAILURES' : 'ALL BAEZ WIDGET TESTS PASS'); process.exit(bad ? 1 : 0);
