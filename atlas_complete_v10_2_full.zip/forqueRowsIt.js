// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Italian text for the rows of the translation matrix: how each equation was checked (how), the line that reads differently (note) and the remark.
// The equations themselves are notation and are the same in both languages. English text comes straight from selfcheck/forque.json.
export const ROWS_IT = {
  F00: { how: 'la stella come complemento con segno; i quattro valori dichiarati dall’articolo sono riprodotti in d = 2, 3, 4; join = ⋆⁻¹(⋆A ∧ ⋆B)' },
  F01: { how: 'n e q casuali; rispettato il segno dell’orientazione di ε (ε² = 0, n ε = −ε n)' },
  F02: { how: 'traslazione di O; (1 - eps q) O; punto spezzato rispetto a un altro centro C; I = eps Q per ogni punto Q' },
  F03: { how: 'un punto è l’incontro (meet) di d piani' },
  F04: { how: 'd = 2, 3, 4: -1, -1, +1' },
  F05: { how: 'V è invariante per traslazione; Q + t V_u è il punto spostato di t u' },
  F06: { how: 'join = ⋆⁻¹(⋆A ∧ ⋆B), con la stella di sopra; il join di un punto con se stesso si annulla' },
  F07: { how: 'dove x·A = (xA − Âx)/2 per un vettore x' },
  F08: { how: 'd = 2, 3, 4. L’osservazione dopo (1.5), «u.Q (-1)^(d-1) in R_{d,0,1}», non compare: con il join della nota 3 il segno è +1 in ogni d provato', note: 'In d = 2, 3, 4, con il join della nota 3, troviamo Q v (uI) = u.Q e O v (uI) = u.O senza (-1)^(d-1); quell’osservazione in 1.3.2 potrebbe appartenere alla convenzione precedente del join.' },
  F09: { how: 'i piani per Q con normale perpendicolare a u stanno nel fascio; un piano generico no' },
  F10: { how: 'le due parti commutano e ciascuna è un 2-blade; una vite = una rotazione attorno a L insieme a una traslazione lungo L', note: 'Verifica esatta: B = [B_E + ε (v·B_E)/B_E] + ε (v∧B_E)/B_E, con un PIÙ davanti al secondo termine. L’ultima riga stampata ha un meno, che non dà B (l’esempio svolto mostra la versione con il più).' },
  F11: { how: 'serie di potenze esatta in t fino all’ordine 6: M = exp(-Bt/2) M0 e M0 exp(-B t/2); le due velocità differiscono per M0 (il paradosso) e coincidono solo per M0 = 1' },
  F12: { how: 'per una velocità B(t) variabile: M risolve Mdot = -B M/2; M M~ resta costante, -2 Mdot M~ restituisce B(t), e ha solo grado 2' },
  F13: { how: 'serie di potenze; X è un punto, una retta e un piano; e un X_b in moto (il termine in più di 2.9)' },
  F14: { how: 'x . e12 manda e1 in e2: la velocità B = e12 è antioraria, come dice il testo' },
  F15: { how: 'una traslazione vista nel riferimento del corpo non è nulla: gli elementi ideali fanno parte del riferimento del corpo («share your ideals»)' },
  F16: { how: 'la retta del join non cambia se si fa scorrere il punto lungo la retta (libertà di gauge)' },
  F17: { how: 'esatto in d = 2, 3, 4 con r = x - y (la posizione della massa vista da Y), così in 3D l’ultimo termine è eps (r x p), il momento angolare classico', note: 'La derivazione mostrata è esatta con X - Y = r I, cioè r = x - y. La frase subito prima definisce r = y - x, che cambierebbe il segno dell’ultimo termine.' },
  F18: { how: 'ogni P_i è un blade; il totale è un blade in 2D ma in generale non in 3D; l’inerzia di un’unione è la somma; I è lineare' },
  F19: { how: 'motore, corpo e velocità casuali; l’inerzia nel mondo è l’inerzia del corpo mossa da M' },
  F20: { how: 'corpo centrato; I_C è l’inerzia classica in AG; esatto in d = 2, 3, 4' },
  F21: { how: 'un corpo con assi principali lungo gli assi coordinati; anche la matrice 6 x 6 nella base (e23, e31, e12, e01, e02, e03) e la sua inversa' },
  F22: { how: 'nessun teorema degli assi paralleli: spostare l’asse cambia solo l’argomento. La nota di redazione rimasta a p. 65 («[[[ but sdo we care ... ]]]») è ancora nel testo della versione 2.6', remark: 'Esatto. La pagina contiene anche una nota di bozza rimasta: «[[[ but sdo we care how teh cetnroid moves? Should we not want Q? ]]]» (p. 65, nel paragrafo sullo spezzamento del punto).' },
  F23: { how: 'corpo rigido generale, velocità generale; p e L sono calcolati in modo classico dalle velocità dei punti' },
  F24: { how: 'esatto in d = 2, 3, 4; la coppia è il 2-blade (q−r)∧f, in 3D il suo duale è la coppia classica', note: 'Esatto con T_R = (q − r) ∧ f. A p. 31 la riga «T_R = (r − q) ∧ f» ha il segno opposto (darebbe anche T_R I = +τ invece di −τ). A.16 (T_O = Σ q_i ∧ f_i) è coerente con la forma corretta.' },
  F25: { how: 'lo stato (M, B_b) è risolto come serie di potenze esatta (iterazione di Picard) fino all’ordine 7; i punti materiali si muovono come X_i = M X_i^b M̃; poi d/dt Σ m_i X_i ∨ Ẋ_i è uguale alla somma dei forque, termine per termine, senza forque, con la gravità (2.31) e con una molla di Hooke. Controlli negativi: togliere B × I[B], cambiarne il segno o togliere il 1/2 rompe Ṗ = F' },
  F26: { how: 'le forme con join e con wedge di T sono entrambe uguali alla somma classica di ½ m |ẋ|² (la forma con wedge letta come coefficiente di I); dT/dt = Π = B ∨ F lungo il moto (serie di potenze), e dT/dt = 0 per il corpo libero' },
  F27: { how: 'le due leggi di Eulero sono le due parti di un’unica equazione; la separazione è legittima perché (p, P) -> p.O + P I è iniettiva (prova del rango)' },
  F28: { how: 'serie di potenze esatta per le tre esponenziali (il caso cosh richiede una base di tipo Lorentz, cioè un generatore di segno opposto); l’identità dei numeri di Study su coefficienti interi casuali; e il motore rinormalizzato M/sqrt(M M~) = s(M + d(...)) ha M M~ = 1' },
  F29: { how: 'un corpo con massa unitaria e inerzie principali unitarie ha I = stella esattamente (costruito con masse puntiformi in posizioni razionali); i coefficienti e01 ed e03 della formula stampata con sei moltiplicazioni sono riprodotti; il coefficiente e02 è (b03 b23 - b01 b12), quello stampato ha -b03 b23', note: 'Confrontato con il classico vdot = -omega x v (indipendente dalla stella): e01 ed e03 coincidono con la formula stampata; il coefficiente e02 è (b03 b23 - b01 b12), mentre quello stampato è (-b01 b12 - b03 b23).' },
  F30: { how: 'per rotori unitari con componenti razionali: i coefficienti e12 ed e31 coincidono con quelli stampati; il coefficiente e23 è 2(m31 m23 - m0 m12), quello stampato 2(m31 - m0 m12) manca di un fattore m23 (dimensionalmente gli altri due termini sono quadratici)', note: 'Con il rotore M = m0 + m12 e12 + m31 e31 + m23 e23 troviamo il coefficiente e23 uguale a 2(m31 m23 - m0 m12); il testo stampato riporta 2(m31 - m0 m12), che sembra un fattore m23 perso (gli altri due coefficienti coincidono esattamente).' },
  F31: { how: 'il parallelepipedo è integrato esattamente (i pesi di Simpson 3x3x3 sono esatti per i quadratici). La mappa manda la rotazione attorno a x (e23) in (m/12)(h^2+d^2) e01', note: 'Con w, h, d lungo x, y, z la mappa esatta manda e23 in m(h^2+d^2)/12 e01, e31 in m(w^2+d^2)/12 e02, e12 in m(w^2+h^2)/12 e03. La C stampata associa (h^2+d^2)/12 a e03 e (w^2+h^2)/12 a e01, cioè nell’ordine inverso: un’altra scelta degli assi (w lungo z?) o uno scambio di indici. Merita uno sguardo.' },
  F32: { how: 'trottola libera sferica (un cubo): serie esatta fino all’ordine 5. Con B_0 = L_b / i e p/m = M_0 (eps v_0) M_0~: le due esponenziali non commutano e non si possono fondere' },
  F33: { how: 'trottola libera simmetrica (due inerzie uguali): (B.7), (B.12), la [B]₃ conservata, la forma chiusa di B_b(t) (B.13) e il motore (B.15) soddisfano tutti le equazioni libere come serie esatte fino all’ordine 5, anche con una rotazione iniziale M_0', note: 'Tutto coincide tranne l’ultima forma in (B.14): da A = (1 − i₃/i)[B₀]₃ E₃ e [L_b]₃ = i₃ [B₀]₃ si ottiene A = (1/i₃ − 1/i₁)[L_b]₃ E₃. La forma stampata «(i₁ − i₃)[L_b]₃ E₃» ha le dimensioni sbagliate (probabilmente intende le inerzie inverse).' },
  F34: { how: 'esatto su corpi diagonali casuali; energia e |L|² conservate; per i₁ > i₂ > i₃ l’asse intermedio ha un tasso di crescita al quadrato positivo (racchetta da tennis / effetto Dzhanibekov), gli altri due oscillano' },
  F35: { how: 'due corpi rigidi casuali in 3D, un punto di contatto Q e una retta normale N = n.Q; V = Q v (Q x B) è la retta della velocità in Q. Solo una lettura soddisfa esattamente la legge di restituzione', note: 'Esatto: con B₊ ← B₊ + j I₊⁻¹[N] e B₋ ← B₋ − j I₋⁻¹[N] (eq. 2.33) la legge di restituzione vale quando il denominatore di j contiene I₊⁻¹[N] PIÙ I₋⁻¹[N]. In (2.32) il denominatore stampato ha un meno, e la riga appena sopra (2.33) scrive B_± − (∓) j I⁻¹[N]. Se il meno viene da una convenzione di orientazione di N sul secondo corpo, vale la pena dichiararla.' },
  F36: { paper: 'Derivazione lagrangiana I^r I[Ḃ] = B × (I^r I[B])', note: 'richiede l’algebra duale (reciproca) usata per la forma a prodotto scalare del join; l’equazione libera che ne risulta, I[Ḃ] = B × I[B], È verificata (F25)' },
  F37: { paper: 'moto vincolato: L v F_L = 0 (cerniera)', note: 'non fatto: è un secondo calcolo, più lungo; i mattoni (la mappa d’inerzia, il join) ci sono' },
  F38: { paper: 'il codice ganja.js, l’ipercubo, il test di collisione SAT, gli integratori Euler/RK4', note: 'i listati di codice sono figure nel PDF; abbiamo verificato solo le equazioni che realizzano' },
  F39: { paper: 'forme chiuse di exp e log di un motore 3D (De Keninck)', note: 'dato solo come figura di codice' },
  F40: { paper: 'esercizi e soluzioni', note: 'D.1, D.2 (inerzia 2D di una rotazione attorno al baricentro e di una traslazione) sono casi particolari di F20; il resto non è stato letto riga per riga' },
};
// The nine conventions (theirs -> ours), in Italian; the English text is in selfcheck/forque.json
export const CONV_IT = [
  { ours: 'bit 0, quadrato 0 (sq[0] = 0)', note: 'il loro indice di codice 0 è il nostro bit 0, quindi la maschera 0b1111 è e0123' },
  { theirs: 'e1 ... ed, e_i^2 = +1 (base euclidea)', ours: 'bit 1..d, quadrato +1 (tipo «tempo» nella regola dell’atlante)', note: 'la regola dell’atlante ha quadrati spaziali -1; tutta la dinamica funziona anche con sq = [0, -1, ..., -1] (legge del moto verificata in d = 2, 3), l’energia cambia allora segno' },
  { ours: 'XOR delle maschere con il segno della regola dei bit', note: 'e31 = -maschera 0b1010 (la nostra è ascendente), e032 = -maschera 0b1101, e021 = -maschera 0b0111; il visualizzatore stampa i nomi dell’articolo' },
  { ours: 'O = maschera dei bit 1..d; I = ε·O', note: 'I ha quadrato 0' },
  { theirs: 'piano p = n − δ ε; traslazione T = 1 − ε t/2; X ↦ M X M̃', ours: 'le stesse espressioni', note: 'il loro ε è l’opposto dell’ε di [13] v < 2.0; usiamo ovunque quello attuale' },
  { ours: 'vdot, comm', note: 'x·A è la contrazione sinistra di un vettore' },
  { theirs: 'stella di Hodge: X (⋆X) = X X̃_E I', ours: 'complemento con segno con (⋆B) ∧ B = I', note: 'riproduce ⋆O = ε, ⋆(q I) = q, ⋆E = −E I, ⋆(ε e_k) = e_k I_d (F00); ⋆⁻¹ è l’inversa sulle maschere' },
  { ours: 'join, wedge', note: 'nota 3 di p. 12' },
  { theirs: 'motori exp(−B t/2); B_w = −2 Ṁ M̃; B_b = −2 M̃ Ṁ', ours: 'ser_exp(B, -1/2); serie di potenze esatta in t', note: 'nessuna virgola mobile nelle righe esatte' },
];

// The words inside the formulas of the table (\text{…} in the TeX of forqueData.js), in Italian; texIt swaps each listed phrase, the mathematics stays.
export const TEX_IT = {
  'star': 'stella', 'bit ': 'bit ', 'pseudoscalar': 'pseudoscalare', 'a point without an ': 'un punto senza parte ', ' part': '', 'join': 'join', 'and': 'e',
  'is a bivector': 'è un bivettore', 'depends on the body only': 'dipende solo dal corpo', '3D matrix ': 'matrice 3D ', 'Study number': 'numero di Study', 'diag': 'diag',
  'cyclic': 'ciclico',
};
const TEXT_ARG = /\\(text|mathrm|operatorname)\s*\{((?:[^{}]|\{[^{}]*\})*)\}/g;
export const texIt = (tex, map = TEX_IT) => (typeof tex === 'string' ? tex.replace(TEXT_ARG, (m, cmd, inner) => (map[inner] !== undefined ? `\\${cmd}{${map[inner]}}` : m)) : tex);
export const texPhrases = tex => [...String(tex).matchAll(TEXT_ARG)].map(m => m[2]).filter(x => /[A-Za-z]{3}/.test(x));
// the section references of the paper (eqs, Chapter, Appendix, Table) in Italian
export const refIt = s => String(s).replace(/\beqs\b/g, 'eqq.').replace(/\beq\b(?!\.)/g, 'eq.').replace(/\bChapter\b/g, 'Capitolo').replace(/\bAppendix\b/g, 'Appendice').replace(/\bexercises\b/g, 'esercizi').replace(/\bTable\b/g, 'Tabella').replace(/ and p\./g, ' e p.');
// The script writes its English notes in the ASCII notation of its code (eps, *^-1, A ^ B for the wedge, M~ for the reverse, Mdot, sum, _3); the page shows
// them in the paper's notation (ε, ⋆⁻¹, A ∧ B, M̃, Ṁ, Σ, ₃), as the Italian notes above already are. Exact text only, so nothing else is touched, and
// forqueData.js stays equal to the script's forque.json.
export const ASCII_MATH = [
  ['join = *^-1(*A ^ *B)', 'join = ⋆⁻¹(⋆A ∧ ⋆B)'], ['orientation of eps respected (eps^2 = 0, n eps = - eps n)', 'orientation of ε respected (ε² = 0, n ε = −ε n)'],
  ['x.A = (xA - A^ x)/2', 'x·A = (xA − Âx)/2'], ['B = [B_E + eps (v.B_E)/B_E] + eps (v^B_E)/B_E', 'B = [B_E + ε (v·B_E)/B_E] + ε (v∧B_E)/B_E'],
  ['the 2-blade (q-r)^f', 'the 2-blade (q−r)∧f'], ['T_R = (q - r) ^ f', 'T_R = (q − r) ∧ f'], ['T_R = (r - q) ^ f', 'T_R = (r − q) ∧ f'],
  ['T_R I = +tau instead of -tau', 'T_R I = +τ instead of −τ'], ['(T_O = sum q_i ^ f_i)', '(T_O = Σ q_i ∧ f_i)'], ['X_i = M X_i^b M~', 'X_i = M X_i^b M̃'],
  ['d/dt sum m_i X_i v Xdot_i', 'd/dt Σ m_i X_i ∨ Ẋ_i'], ['B x I[B]', 'B × I[B]'], ['B x (I^r I[B])', 'B × (I^r I[B])'], ['I[Bdot]', 'I[Ḃ]'], ['break Pdot = F', 'break Ṗ = F'],
  ['(1/2) m |xdot|^2', '½ m |ẋ|²'], ['dT/dt = Pi = B v F', 'dT/dt = Π = B ∨ F'],
  ['A = (1 - i3/i)[B0]_3 E3', 'A = (1 − i₃/i)[B₀]₃ E₃'], ['[L_b]_3 = i3 [B0]_3', '[L_b]₃ = i₃ [B₀]₃'], ['A = (1/i3 - 1/i1)[L_b]_3 E3', 'A = (1/i₃ − 1/i₁)[L_b]₃ E₃'],
  ['(i1 - i3)[L_b]_3 E3', '(i₁ − i₃)[L_b]₃ E₃'], ['the conserved [B]_3', 'the conserved [B]₃'], ['|L|^2 conserved; for i1 > i2 > i3', '|L|² conserved; for i₁ > i₂ > i₃'],
  ['B+ <- B+ + j I+^-1[N]', 'B₊ ← B₊ + j I₊⁻¹[N]'], ['B- <- B- - j I-^-1[N]', 'B₋ ← B₋ − j I₋⁻¹[N]'], ['I+^-1[N] PLUS I-^-1[N]', 'I₊⁻¹[N] PLUS I₋⁻¹[N]'],
  ['B_pm - (-+) j I^-1[N]', 'B_± − (∓) j I⁻¹[N]'],
  ['*O = eps, *(q I) = q, *E = -E I, *(eps e_k) = e_k I_d (F00); *^-1 is the inverse on masks', '⋆O = ε, ⋆(q I) = q, ⋆E = −E I, ⋆(ε e_k) = e_k I_d (F00); ⋆⁻¹ is the inverse on masks'],
  ['e0 = eps, eps^2 = 0', 'e₀ = ε, ε² = 0'], ['x . A = (x A - A^ x)/2;  A x B = (A B - B A)/2', 'x·A = (xA − Âx)/2;  A×B = (AB − BA)/2'],
  ['Hodge star: X (*X) = X X~_E I', 'Hodge star: X (⋆X) = X X̃_E I'], ['signed complement with (*B) ^ B = I', 'signed complement with (⋆B) ∧ B = I'],
  ['join A v B = *^-1(*A ^ *B); meet = ^', 'join A ∨ B = ⋆⁻¹(⋆A ∧ ⋆B); meet = ∧'], ['O = e1 ... ed,  I = eps O,  Q = O + q I', 'O = e1 ... ed,  I = ε O,  Q = O + q I'],
  ['plane p = n - delta eps; translation T = 1 - eps t/2; X -> M X M~', 'plane p = n − δ ε; translation T = 1 − ε t/2; X ↦ M X M̃'],
  ['motors exp(-B t/2); B_w = -2 Mdot M~; B_b = -2 M~ Mdot', 'motors exp(−B t/2); B_w = −2 Ṁ M̃; B_b = −2 M̃ Ṁ'],
  ['O = mask of bits 1..d; I = eps * O', 'O = mask of bits 1..d; I = ε·O'], ['their eps is minus the eps of [13]', 'their ε is minus the ε of [13]'], ['x . A is the left contraction', 'x·A is the left contraction'],
];
export const asciiMath = s => (typeof s === 'string' ? ASCII_MATH.reduce((t, [a, b]) => t.split(a).join(b), s) : s);
