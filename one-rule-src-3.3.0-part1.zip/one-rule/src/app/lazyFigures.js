// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/lazyFigures.js — the figures chunk, on the side of app.js (BUILD_CONTRACTS interface 34, D47). The figures under src/figures/physics/ and
// src/figures/explore/ are not in app.js: tools/build_extra.mjs builds them into dist/figures-extra.js, a classic script (an IIFE: it must load from
// file://, where module scripts are refused), and this module inserts it the first time a page needs one of them. The chunk registers its figures in
// window.__ONE_RULE_FIGURES_EXTRA__ and dispatches the event "one-rule:figures".
// One React, one store: the chunk carries no copy of React nor of the modules below; it reads them from window.__ONE_RULE_BRIDGE__, which app.js fills
// (main.jsx calls installFiguresBridge() at start; loadExtraFigures() calls it again before the script is inserted).
//   BRIDGE_KEYS / bridgeModules()  the modules of app.js the chunk reaches through the bridge. tools/build_extra.mjs reads this list: every import of one of
//                  them in the chunk resolves to the bridge, and the build fails when a module of the chunk imports a module of src/ outside src/figures/
//                  that the list does not name. tests/chunk.test.mjs checks that dist/figures-extra.js holds no copy of them.
//                  Two groups. (a) The app: every module of src/ outside src/figures/ the chunk imports, and the ones that hold the state they read (the
//                  table cache, the address, the KaTeX engine, the query memo, a React context): these must exist once. (b) Pure modules app.js already
//                  carries whole and the chunk uses too (the kernel, the stored blocks, three engines, the figure kit, two core figures an extra figure draws
//                  as a part): read from app.js rather than copied, which costs app.js under half a kB each. A namespace import here keeps every export of
//                  its module in app.js, so a pure module app.js uses only in part is copied into the chunk instead (the other engines, labels.js among
//                  them), as is a module whose imports reach a stylesheet (its import here would move the stylesheet in app.css): MaxwellEquations.jsx and
//                  physics/p8kit.jsx. Copies are safe: they hold no state that must be shared (memo caches at most; tests/chunk.test.mjs scans them).
//   isExtraFigure(id)       the id is one the chunk registers: the manifest computed by tools/build_extra.mjs and baked into app.js by build.sh
//                           (__ONE_RULE_EXTRA_IDS__); empty where it is not baked in (server rendering and the tests, which import every figure)
//   extraFigure(id)         its component once the chunk is in, else null (src/app/optional.js figureComponent asks it)
//   loadExtraFigures()      inserts <script src="./figures-extra.js"> once; resolves when the chunk has registered its figures, rejects with a labelled error
//   useExtraFigures(needed) React hook: 'idle' | 'loading' | 'ready' | 'failed', starting the load when needed (FigureFrame)
import React, { useEffect, useSyncExternalStore } from 'react';
import ReactDOM from 'react-dom';
import jsxRuntime from 'react/jsx-runtime';
import * as content from './content.js';
import * as store from './store.js';
import * as settings from './settings.js';
import * as location from './location.js';
import * as router from './router.js';
import * as math from './math.js';
import * as queries from './queries.js';
import * as vocab from './vocab.js';
import * as PageContext from '../components/PageContext.js';
import * as Statement from '../components/Statement.jsx';
import * as Badge from '../components/Badge.jsx';
import * as RichText from '../components/RichText.jsx';
import * as LensReading from '../components/LensReading.jsx';
import * as bitrule from '../../engines/bitrule.js';
import * as storedParts from '../../engines/storedParts.js';
import * as stored from '../../engines/stored.js';
import * as maxwellPhysics from '../../engines/maxwellPhysics.js';
import * as forquePhysics from '../../engines/forquePhysics.js';
import * as physCommutators from '../../engines/physics/commutators.js';
import * as kit from '../figures/kit.jsx';
import * as FourViews from '../figures/FourViews.jsx';
import * as FureyBoard from '../figures/FureyBoard.jsx';

export const BRIDGE = '__ONE_RULE_BRIDGE__';
export const REGISTRY = '__ONE_RULE_FIGURES_EXTRA__';
export const EVENT = 'one-rule:figures';
/** set by the chunk when it failed while it ran (its own code, or a bridge that lacks a module): the reason, for the warning */
export const CHUNK_ERROR = '__ONE_RULE_FIGURES_EXTRA_ERROR__';
export const CHUNK_SRC = './figures-extra.js';

/**
 * The bridged modules, by their path from the repository root. (a) The app: the content store and its contract functions, the address (location,
 * settings, router), the KaTeX helper with its cache, the page queries with their memo, the vocabularies, the page context (a React context: one object),
 * the components the extra figures embed. (b) Pure modules app.js carries whole: the kernel, the stored blocks, three engines, the figure kit, two core
 * figures. Read in a function, after every module of app.js has run.
 */
export const bridgeModules = () => ({
  'src/app/content.js': content,
  'src/app/store.js': store,
  'src/app/settings.js': settings,
  'src/app/location.js': location,
  'src/app/router.js': router,
  'src/app/math.js': math,
  'src/app/queries.js': queries,
  'src/app/vocab.js': vocab,
  'src/components/PageContext.js': PageContext,
  'src/components/Statement.jsx': Statement,
  'src/components/Badge.jsx': Badge,
  'src/components/RichText.jsx': RichText,
  'src/components/LensReading.jsx': LensReading,
  'engines/bitrule.js': bitrule,
  'engines/storedParts.js': storedParts,
  'engines/stored.js': stored,
  'engines/maxwellPhysics.js': maxwellPhysics,
  'engines/forquePhysics.js': forquePhysics,
  'engines/physics/commutators.js': physCommutators,
  'src/figures/kit.jsx': kit,
  'src/figures/FourViews.jsx': FourViews,
  'src/figures/FureyBoard.jsx': FureyBoard,
});
export const BRIDGE_KEYS = Object.freeze(Object.keys(bridgeModules()));

/** fill window.__ONE_RULE_BRIDGE__ once: { React, ReactDOM, jsxRuntime, modules } */
export function installFiguresBridge() {
  if (typeof window === 'undefined' || window[BRIDGE]) return;
  window[BRIDGE] = Object.freeze({ React, ReactDOM, jsxRuntime, modules: Object.freeze(bridgeModules()) });
}

// the manifest: the ids the chunk registers, baked into app.js by build.sh (--define:__ONE_RULE_EXTRA_IDS__=[…])
// eslint-disable-next-line no-undef
const EXTRA_IDS = new Set(typeof __ONE_RULE_EXTRA_IDS__ !== 'undefined' && Array.isArray(__ONE_RULE_EXTRA_IDS__) ? __ONE_RULE_EXTRA_IDS__ : []);
export const isExtraFigure = id => EXTRA_IDS.has(id);

/** the component the chunk registered for an id, or null (before the chunk is in, or outside a browser) */
export function extraFigure(id) {
  const reg = typeof window !== 'undefined' ? window[REGISTRY] : null;
  return reg && Object.prototype.hasOwnProperty.call(reg, id) ? reg[id] : null;
}

// ---- the load: one script, one status for every frame
let status = 'idle';
let loading = null;
const subs = new Set();
const setStatus = s => { status = s; subs.forEach(f => f()); };
const getStatus = () => status;
const subscribe = f => { subs.add(f); return () => subs.delete(f); };
let warned = false;
const warnOnce = msg => { if (!warned && typeof console !== 'undefined') { warned = true; console.warn(`[one-rule] ${msg}`); } };

/** insert the chunk once; resolves with the registry of its figures, rejects with a labelled error (and one warning) */
export function loadExtraFigures() {
  if (loading) return loading;
  if (typeof window === 'undefined' || typeof document === 'undefined') return Promise.reject(new Error('the figures chunk loads in a browser only'));
  installFiguresBridge();
  if (window[REGISTRY]) { setStatus('ready'); loading = Promise.resolve(window[REGISTRY]); return loading; }
  setStatus('loading');
  loading = new Promise((resolve, reject) => {
    let done = false;
    const finish = err => {
      if (done) return;
      done = true;
      window.removeEventListener(EVENT, onEvent);
      if (err) reject(err); else resolve(window[REGISTRY]);
    };
    const onEvent = () => { if (window[REGISTRY]) finish(null); };
    window.addEventListener(EVENT, onEvent);
    const s = document.createElement('script');
    s.src = CHUNK_SRC;
    s.async = true;
    s.setAttribute('data-one-rule', 'figures-extra');
    s.onload = () => finish(window[REGISTRY] ? null : new Error(`figures-extra.js ran but registered no figures${window[CHUNK_ERROR] ? ` (${window[CHUNK_ERROR]})` : ''}`));
    s.onerror = () => finish(new Error('figures-extra.js could not be loaded'));
    document.head.appendChild(s);
  }).then(
    reg => { setStatus('ready'); return reg; },
    err => { warnOnce(`the figures chunk did not load, so its figures say so instead: ${err && err.message}`); setStatus('failed'); throw err; },
  );
  return loading;
}

/** a frame asks for an id the manifest names but the loaded chunk lacks (app.js and figures-extra.js of different builds): one warning */
export function extraFigureMissing(id) {
  warnOnce(`figures-extra.js has no figure "${id}" though app.js expects it (app.js and the chunk come from different builds)`);
}

/** React hook: the status of the chunk ('idle' | 'loading' | 'ready' | 'failed'); starts the load when `needed` */
export function useExtraFigures(needed) {
  const s = useSyncExternalStore(subscribe, getStatus, () => 'idle');
  useEffect(() => { if (needed && status === 'idle') loadExtraFigures().catch(() => { /* the frame says so; warned once */ }); }, [needed]);
  return s;
}
