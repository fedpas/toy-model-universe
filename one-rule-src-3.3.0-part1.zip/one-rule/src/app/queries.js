// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/queries.js — pages as queries over the rows (02 §7, 06): which rows a section shows, in which order, what goes to the drawer
// and to the open fold; titles from pages.json and steps.json; the cards of the cells page and the step index. Pure functions of the tables.
// The story round (docs/STORY_PLAN.md §2, BUILD_CONTRACTS interfaces 26–29) composes a page by role: an intro (the page's lead, "at a glance",
// the next line), parts over sections, and per section lead → figure → captions → key results → "More statements (n)"; see buildPageModel.
// Round 7 (docs/round7/PLAN.md R7-3, R7-4, interfaces 37–38): every page with a hero opens with its top — the lead, the hero figure (a leaf of the
// map when one is anchored at the page top: pages.json `top`, written by tools/merge_explore.mjs), the try line, the three notes (the reserved section
// top-notes), the two ways (the hero row's texts by mode) — and the figures the map places in a section (`slots`) join that section; the record of
// the page (pageRecord) lists every row placed on it.
// Round 14 (docs/round14/STORY_ROUND.md §2, §4.3; interfaces 40–41): a body section carries its chains (content/chains.json), each a story of
// positions with the links between them; the told rows leave the lists that draw rows (key results, "More statements", the open fold) and are drawn
// once, by their chain; a chain's status is the weakest of its rows' (chainStatus); the record of a page lists its chains beside its rows.
import { textFor, statusOf } from './content.js';
import {
  peekTable, rowsByPage, rowsById, pagesByRoute, stepsByRoute, lensesByKey, figuresById, lensTextIndex, lensReadingsIndex, rowsByCell, textRecord,
  checksIndex, lastRuns, chainsOf, chainsOnPage,
} from './store.js';
import {
  KIND_ORDER, STAGE_ORDER, FIELD_ORDER, STAGE_NAMES, DRAWER_TABS, rankIn, INTRO_SECTION, OPEN_PART, DRAWER_PART, INPUT_SECTIONS, KEY_RESULTS, STORY_WORDS,
  TOP_NOTES, TOP_NOTES_MAX, BADGE_WORDS, CHAIN_STATUS_ORDER,
} from './vocab.js';
import { cellRoute } from './router.js';
import { clockOf } from './cellmath.js';

// ---------------------------------------------------------------- titles
const isAllCaps = t => { const up = (t.match(/[A-Z]/g) || []).length, lo = (t.match(/[a-z]/g) || []).length; return up >= 6 && up >= 4 * lo; };
const capFirst = t => (t ? t.charAt(0).toUpperCase() + t.slice(1) : t);

export function pageTitle(route, s) {
  const p = pagesByRoute()?.get(route);
  if (!p) return route;
  const t = p.title || {};
  return (s.level === 'learner' ? t.learner : null) || t[s.mode] || t.phys || route;
}
export const stepOf = route => stepsByRoute()?.get(route) || null;
const isStep = st => st && st.group !== 'shapes';
const stepNav = (st, s) => (s.level === 'learner' ? st.navLearner || st.nav : st.nav);

/**
 * { eyebrow, title, deck, parent } for a page header; numbers come from steps.json. A sub-page (pages.json `parent` and `tab`, interface 29)
 * reads "<parent> · <tab>" in its eyebrow ("Calibration 2 · Her papers"): the parent's title up to its colon, and the tab's title (`tab` as a
 * string or { phys, math, learner }, else the page's own title); `parent` = { route, label } lets the header link the parent's part of it.
 */
export function pageHeading(route, s) {
  const st = stepOf(route);
  let title = pageTitle(route, s), deck = null, eyebrow = null, parent = null;
  if (isStep(st)) {
    eyebrow = `Step ${st.no} of ${st.total}` + (STAGE_NAMES[st.stage] ? ` · ${STAGE_NAMES[st.stage]}` : '');
    title = capFirst(title.replace(/^Step \d+:\s*/i, ''));
    if (isAllCaps(title)) { deck = title; title = stepNav(st, s); }
  }
  const def = pagesByRoute()?.get(route);
  if (def && def.parent && pagesByRoute()?.has(def.parent)) {
    const label = parentLabel(def.parent, s), tab = titleIn(def.tab, s) || title;
    parent = { route: def.parent, label, tab };
    eyebrow = `${label} · ${tab}`;
  }
  return { eyebrow, title, deck, parent };
}
/** the short name of a parent page in a sub-page's eyebrow: its title up to the first colon ("Calibration 2: matter (Furey)" → "Calibration 2") */
export function parentLabel(route, s) {
  const t = pageLabel(route, s);
  const i = t.indexOf(':');
  return i > 0 ? t.slice(0, i).trim() : t;
}
/** the sub-pages of a page (pages.json entries whose `parent` is it), in the order of pages.json */
export function subPagesOf(route) {
  return (peekTable('pages') || []).filter(p => p.parent === route).map(p => p.route);
}
/** a short label for a link to a page (needs chips, prev/next, contents) */
export function pageLabel(route, s) {
  const st = stepOf(route);
  if (isStep(st)) return `Step ${st.no}: ${stepNav(st, s)}`;
  const t = pageTitle(route, s);
  return isAllCaps(t) ? capFirst(t.toLowerCase()) : t;
}

const SLUG_PREFIX = ['eq', 'ns', 'ln', 'nl', 'sh', 'cat', 'bz', 'sc'];
const SLUG_WORDS = { res: 'results', persp: 'perspectives', deadends: 'dead ends', twozeros: 'two zeros', label0: 'label 0' };
/**
 * A section title from pages.json; anchor-like slugs ("eq-grav2", "cat-w-label0") are turned into words: a slug that names a step
 * takes the step's name from steps.json, or "Results" on that step's own page (where the name is the page title).
 */
export function sectionLabel(title, id, s, route) {
  const t = title || id || '';
  if (!/^[a-z0-9-]+$/.test(t)) return t;
  let parts = t.split('-');
  let figure = false;
  if (parts.length > 1 && SLUG_PREFIX.includes(parts[0])) parts = parts.slice(1);
  if (parts.length > 1 && parts[0] === 'w') { figure = true; parts = parts.slice(1); }
  const key = parts.join('-');
  const st = (peekTable('steps') || []).find(x => x.id === key);
  let words;
  if (st && route && st.route === route) words = 'Results';
  else if (st) words = stepNav(st, s);
  else words = parts.map(w => SLUG_WORDS[w] || w).join(' ');
  return capFirst(words) + (figure ? ' (figure)' : '');
}

// ---------------------------------------------------------------- order
export const visibleIn = (row, mode) => !Array.isArray(row.visibleTo) || !row.visibleTo.length || row.visibleTo.includes(mode);

/** sort shownOn entries: physics by shownOn.order, mathematics by kind rank then field; a lens with its own ordering wins */
export function sortEntries(entries, s) {
  const lens = s.lens ? lensesByKey()?.get(s.lens) : null;
  const ord = lens ? lens.ordering : null;
  const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
  const kind = e => rankIn(KIND_ORDER, e.row.kind);
  const field = e => rankIn(FIELD_ORDER, (e.row.fields || [])[0]);
  const stage = e => rankIn(STAGE_ORDER, e.row.stage);
  const grade = e => { const g = statusOf(e.row.id); return g && typeof g.grade === 'number' ? g.grade : 99; };
  let cmp;
  if (ord === 'kind') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else if (ord === 'stage') cmp = (a, b) => stage(a) - stage(b) || byOrder(a, b);
  else if (ord === 'grade') cmp = (a, b) => grade(a) - grade(b) || byOrder(a, b);
  else if (s.mode === 'math') cmp = (a, b) => kind(a) - kind(b) || field(a) - field(b) || byOrder(a, b);
  else cmp = byOrder;
  return entries.map((e, i) => ({ e, i })).sort((x, y) => cmp(x.e, y.e) || x.i - y.i).map(x => x.e);
}

// ---------------------------------------------------------------- the page model
const hasText = (id, s) => textFor(id, s) != null;
const isSlug = t => typeof t === 'string' && /^[a-z0-9-]+$/.test(t);
const isName = t => typeof t === 'string' && t.trim() !== '' && !isSlug(t);
const roleOf = e => e.so.role || 'result';
const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
const isOpenRow = id => (statusOf(id) || {}).status === 'open';
/** a figure field of pages.json (a section's `figure`, a hero's): an id or a list of ids → [ids] */
export const figureList = f => (Array.isArray(f) ? f : f ? [f] : []).filter(x => typeof x === 'string' && x);

/**
 * A title of pages.json in the words of the settings: a string, or { phys, math, learner } (learner level takes `learner`, then the mode's);
 * anchor slugs ("bz-top") are not names. → the name, or null when the title gives none.
 */
export function titleIn(t, s) {
  if (t == null || t === false) return null;
  if (typeof t === 'string') return isName(t) ? t.trim() : null;
  if (s.level === 'learner' && isName(t.learner)) return t.learner.trim();
  if (isName(t[s.mode])) return t[s.mode].trim();
  return isName(t.phys) ? t.phys.trim() : null;
}
/** the heading of a section: the overlay's title (A53), else sectionLabel of its slug; `title: false` is a section with no heading (v15's top) */
function sectionHeading(sec, s, route) {
  const t = sec.title;
  const fallback = () => sectionLabel(t && typeof t === 'object' ? t[s.mode] || t.phys : null, sec.id, s, route);
  if (t === false) return { heading: null, label: fallback() };
  const own = titleIn(t, s);
  const label = own || fallback();
  return { heading: label, label };
}

let assignedMemo = null;
/**
 * The figures some page assigns (a hero's `figure`, a section's `figure`, a page top's figure and the figures of its slots, in every entry of
 * pages.json): such a figure is drawn where it is assigned and is never placed by its caption row (interface 28); the caption-row rule stays for the
 * figures no page assigns.
 */
export function assignedFigures() {
  const pages = peekTable('pages');
  if (!pages) return new Set();
  if (assignedMemo && assignedMemo.pages === pages) return assignedMemo.set;
  const set = new Set();
  for (const p of pages) {
    for (const f of figureList(p.hero && p.hero.figure)) set.add(f);
    if (p.top && p.top.figure) set.add(p.top.figure);
    for (const sl of Array.isArray(p.slots) ? p.slots : []) if (sl && sl.figure) set.add(sl.figure);
    for (const sec of p.sections || []) for (const f of figureList(sec && sec.figure)) set.add(f);
  }
  assignedMemo = { pages, set };
  return set;
}

let mappedMemo = null;
/**
 * The figures the map of the leaves places (R7-3: a leaf figure lives on exactly one Atlas page): figure → { route, at } with `at` "top" (the page
 * top) or the section of its slot. A mapped figure is drawn only there: a section that names it elsewhere (an earlier overlay) does not draw it.
 */
export function mappedFigures() {
  const pages = peekTable('pages');
  if (!pages) return new Map();
  if (mappedMemo && mappedMemo.pages === pages) return mappedMemo.map;
  const map = new Map();
  for (const p of pages) {
    if (p.top && p.top.figure && !map.has(p.top.figure)) map.set(p.top.figure, { route: p.route, at: 'top' });
    for (const sl of Array.isArray(p.slots) ? p.slots : []) if (sl && sl.figure && !map.has(sl.figure)) map.set(sl.figure, { route: p.route, at: sl.section });
  }
  mappedMemo = { pages, map };
  return map;
}
/** may this figure be drawn at this place (route, section or "top"): yes unless the map places it elsewhere */
const drawableAt = (f, route, at) => { const m = mappedFigures().get(f); return !m || (m.route === route && m.at === at); };

/** the figure a page assigns to its hero: its top's figure (a leaf of the map), else hero.figure, else the figure of its reserved section `intro` */
const heroFigureOf = def => (def.top && def.top.figure) || (def.hero && def.hero.figure) || figureList(((def.sections || []).find(x => x && x.id === INTRO_SECTION) || {}).figure)[0] || null;

/** the figure of a hero: the page's (an id missing from figures.json draws nothing), else the first figure no page assigns whose caption row is the hero row */
export function heroFigure(def, s) {
  const figs = peekTable('figures') || [];
  const id = heroFigureOf(def);
  let f = id ? figuresById()?.get(id) || null : null;
  if (!id && def.hero && def.hero.row) {
    const taken = assignedFigures();
    f = figs.find(x => x.captionRow === def.hero.row && !taken.has(x.id) && (s.level !== 'learner' || x.learner)) || null;
  }
  if (f && s.level === 'learner' && !f.learner) return null;
  return f ? f.id : null;
}

/** how many key results a section shows at this level: { n, list } — `key` a number, { research, learner }, or a list of row ids (A54) */
function keyOf(sec, s) {
  const lv = s.level === 'learner' ? 'learner' : 'research';
  const k = sec.key;
  if (typeof k === 'number' && k >= 0) return { n: k, list: null };
  if (Array.isArray(k)) return { n: lv === 'learner' ? KEY_RESULTS.learner : null, list: k };
  if (k && typeof k === 'object') return { n: typeof k[lv] === 'number' ? k[lv] : KEY_RESULTS[lv], list: Array.isArray(k.rows) ? k.rows : null };
  return { n: KEY_RESULTS[lv], list: null };
}

/** the sections of a page in display order: pages.json's order, each part's sections drawn together where its first one stands */
function orderedSections(def) {
  const secs = (def.sections || []).filter(x => x && x.id);
  const parts = Array.isArray(def.parts) ? def.parts.filter(p => p && p.id) : [];
  if (!parts.length) return secs;
  const byId = new Map(secs.map(x => [x.id, x]));
  const members = new Map(parts.map(p => [p.id, [...(p.sections || []).filter(id => byId.has(id))]]));
  for (const x of secs) if (x.part && members.has(x.part) && !members.get(x.part).includes(x.id) && ![...members.values()].some(l => l.includes(x.id))) members.get(x.part).push(x.id);
  const partOf = new Map();
  for (const p of parts) for (const id of members.get(p.id)) if (!partOf.has(id)) partOf.set(id, p.id);
  const out = [], done = new Set();
  for (const x of secs) {
    if (done.has(x.id)) continue;
    const pid = partOf.get(x.id);
    const run = pid ? members.get(pid).filter(id => partOf.get(id) === pid) : [x.id];
    for (const id of run) if (!done.has(id)) { done.add(id); out.push(byId.get(id)); }
  }
  return out;
}

/** a section of the open part with `pairs: "splitFrom"`: each statement with the rows split from it (v15's questions), in their order */
function pairsOf(ids) {
  const set = new Set(ids), used = new Set(), out = [];
  for (const id of ids) {
    if (used.has(id)) continue;
    const r = rowsById()?.get(id);
    const from = r && r.splitFrom && set.has(r.splitFrom) ? r.splitFrom : null;
    const head = from || id;
    if (used.has(head)) { used.add(id); continue; }
    const questions = ids.filter(x => x !== head && (rowsById()?.get(x) || {}).splitFrom === head);
    used.add(head); questions.forEach(q => used.add(q));
    out.push({ statement: head, questions });
  }
  return out;
}

// ---------------------------------------------------------------- chains (round 14: docs/round14/STORY_ROUND.md §2.1, §4.3)
/**
 * The status of a chain (§2.1, not stored): the weakest computed status among its rows and twins (content/derived/status.json), in the order
 * open > cited (not yet proved here) > ours > input > standard > proved-by-atlas; a row with another status (meta) or none counts for nothing.
 * → that status, or null when no row of the chain has one of them. A pure function of the chain record and the status table.
 */
export function chainStatus(chain) {
  if (!chain || !Array.isArray(chain.rows)) return null;
  let k = CHAIN_STATUS_ORDER.length;
  for (const id of [...chain.rows, ...Object.values(chain.twins && typeof chain.twins === 'object' ? chain.twins : {})]) {
    const i = CHAIN_STATUS_ORDER.indexOf((statusOf(id) || {}).status);
    if (i >= 0 && i < k) k = i;
  }
  return k < CHAIN_STATUS_ORDER.length ? CHAIN_STATUS_ORDER[k] : null;
}
/** the word of a chain's title line for its status (D56: a word, not a badge): the research word of the badge of its weakest row; none when proved */
const WEAK_KIND = { open: 'open', cited: 'cited', ours: 'ours', input: 'input' };
export const chainStatusWord = status => (WEAK_KIND[status] ? BADGE_WORDS[WEAK_KIND[status]].research : null);
const SHAPES = ['line', 'fork', 'cycle', 'ladder'];
const TRANSITIVE = new Set(['derives', 'equiv', 'continues']);
/** a chain's title in the words of the settings (learner level: its learner title), else the slug of its id in words */
const chainTitle = (c, s) => titleIn(c.title, s) || capFirst(String(c.id).split('.').pop().replace(/-/g, ' '));

/**
 * The link shown before a position (§4.3). A position not shown in the mode (neither its row nor its twin visible, or no text at this level) is skipped
 * and its link handed on to the next position shown, composed with that position's own link: the relation is kept when every link of the run is the
 * same transitive relation (derives, equiv, continues; forwards, no branch), else the two rows shown side by side get `order`, which claims nothing
 * (C4: no unearned "So"). A branch (`from`) keeps its base when that position is shown, named by the row shown there (a twin in the other mode) and
 * dropped once the base is the position just before; with its base not shown it is an `order` link.
 */
function handOn(link, skipped, prev, shownAt, shown) {
  if (link.from) {
    const at = shownAt.has(link.from) ? shownAt.get(link.from) : null;
    if (!at || !shown.has(at)) return { rel: 'order' };
    const out = { ...link };
    if (at === prev) delete out.from; else out.from = at;
    return out;
  }
  if (!skipped.length) return { ...link };
  return [...skipped, link].every(l => l && !l.from && l.dir !== 'back' && l.rel === link.rel) && TRANSITIVE.has(link.rel) ? { rel: link.rel } : { rel: 'order' };
}

/**
 * One chain of a section at these settings (§4.3), or null when none of its positions is shown:
 *   { id, title, lead, positions: [{ id, n, mention, link, twinOf, toldIn, anchor }], shape, status, word, storied, joins: [{ id, title }] }
 * A position shows its row, or its twin where the row is not visible in the mode (twinOf: the position's row); n is its place in the chain (its span's
 * number); a mention carries toldIn { chain, sid, label, title }, where the page tells it; anchor is false where the page top holds the row's anchor
 * (row-<id>: the hero row and the notes; chains are exempt from the top's claim, §6.1). `storied` when every visible position has its span and the lead
 * its learner text (D54: an unstoried chain renders as the list of its rows in their old words). joins: the chains of the page a join comes from.
 */
function chainModel(c, s, { claimed, toldWhere }) {
  const R = rowsById();
  const twins = c.twins && typeof c.twins === 'object' ? c.twins : {};
  const mention = new Set(Array.isArray(c.mention) ? c.mention : []);
  const visible = id => { const r = R && R.get(id); return !!r && visibleIn(r, s.mode); };
  const shownAt = new Map(c.rows.map(row => [row, visible(row) ? row : twins[row] && visible(twins[row]) ? twins[row] : null]));
  const here = id => textFor(id, { mode: s.mode, level: s.level, lens: s.lens, chain: c.id }) != null;
  const positions = [], shown = new Set();
  let skipped = [], prev = null;
  c.rows.forEach((row, i) => {
    const link = i ? (Array.isArray(c.links) && c.links[i - 1] && typeof c.links[i - 1] === 'object' ? c.links[i - 1] : { rel: 'order' }) : null;
    const id = shownAt.get(row);
    if (!id || !here(id)) { if (link) skipped.push(link); return; }
    const isMention = mention.has(row);
    positions.push({
      id, n: i + 1, mention: isMention, link: positions.length ? handOn(link, skipped, prev, shownAt, shown) : null, twinOf: id !== row ? row : null,
      toldIn: isMention ? toldWhere(row) : null, anchor: !isMention && !claimed.has(id),
    });
    shown.add(id); prev = id; skipped = [];
  });
  if (!positions.length) return null;
  const learnerS = { mode: s.mode, level: 'learner', lens: s.lens };
  const visibleIds = c.rows.map(row => shownAt.get(row)).filter(Boolean);
  const leadShown = !!(c.lead && visible(c.lead));
  const storied = visibleIds.every(id => !!textRecord(id, { ...learnerS, chain: c.id })) && (!leadShown || hasText(c.lead, learnerS));
  const status = chainStatus(c);
  const joins = [];
  for (const j of Array.isArray(c.joins) ? c.joins : []) {
    const t = j && toldWhere(j.from);
    if (t && t.chain !== c.id && !joins.some(x => x.id === t.chain)) joins.push({ id: t.chain, title: t.title });
  }
  return {
    id: c.id, title: chainTitle(c, s), lead: leadShown && hasText(c.lead, s) ? c.lead : null, positions,
    shape: SHAPES.includes(c.shape) ? c.shape : 'line', status, word: chainStatusWord(status), storied, joins,
  };
}

/**
 * Model of a page for the current settings (interface 27; docs/STORY_PLAN.md §2.1–2.3, §2.9). Every field the pages read before the story round is
 * kept with its meaning; the composition is added beside it.
 *
 * buildPageModel(route, settings, opts = { custom: [section ids rendered by the page itself] }) →
 * {
 *   def, route,
 *   hero: { id, register, figure, captions: [row ids] } | null,     the hero row; its figure; the caption rows of the intro, drawn under the figure
 *   top: { lead, hero: { row, figure, wide }, tryLine, notes,       the page top (round 7, interface 37): the intro's lead; the hero row and the top's
 *          ways: { phys, math, one, lens }, leaf, fromMap } | null    figure (a leaf of the map, else the hero figure) and whether its seed is wide; the
 *                                                                  try line (connective["top-notes"]); the notes (the reserved section top-notes, role
 *                                                                  note, at most three, a text at this level each); the two ways: the hero row's text
 *                                                                  records with mode phys and math at this level (one record for both: `one`), and the
 *                                                                  mathematician's way in (the leaf's lens); null on a page without a hero or figure
 *   intro: { lead, next, glance, more, learnerRows },               the reserved section `intro`: the page's lead (one paragraph under the header),
 *                                                                  the next line (above the link to the next page), "at a glance" (its result rows,
 *                                                                  the page strip, A57), its details and captions without a figure ("More statements"),
 *                                                                  its learner-only rows (learner level)
 *   parts: [{ id, title, sections: [ids] }],                        the parts of the body in display order (a chapter's h2 headings); [] without parts
 *   sections: [{
 *     id, label, heading, part, placement, connective, figure, figures, blocks, lead, captions, key, more, learnerRows,
 *     body, details, numbers, drawerRows, all, tabs, show
 *   }],
 *   open: [{ id, label, rows, lead?, sub?, pairs? }], openRows,      the open fold, grouped by part (by section on a page without parts); the open part's
 *                                                                  sections each a group (with its lead; `sub` for grouped sections; `pairs` per statement)
 *   reference: [section],                                          the sections of the reserved part `drawer`, each drawn as a closed fold after the open items
 *   inputs: { rows, lead, learnerRows } | null,                     "What this page takes from outside (n)": the rows of the needs sections
 *   openChains: [{ id, title, sid, label }],                       round 14 (D57): the chains drawn on the page whose weakest link is open, which the
 *                                                                  open fold names by title (their open rows stay in their chain)
 *   rowSection, place, results, learnerShort
 * }
 * Round 14 (docs/round14/STORY_ROUND.md §4.3): a body section has `chains` (chainModel above: its chains of content/chains.json, in order, never sorted)
 * and `told` (the rows its chains tell, as shown in the mode: the drawer lists them). The rows told in a chain of the page, and their twins, leave every
 * list that draws rows — `key`, `more`, `details`, the open fold — so a row is told once per page (D52); `body` and `openRows` keep them, as they keep
 * every row of the section, for the step and stage counts and `results`. `place` registers a told position as { where: 'chain' } (a deep link goes to
 * the told position, the hero row's too) and never a mention; `rowSection` keeps the drawer a row already has (the page top's), else the section's.
 * Per section: `lead` the one `lead` row (section.lead when it is placed there), `figure` the first of `figures` (section.figure explicit — an id of
 * figures.json, or a list — then the figures no page assigns whose caption row the section holds), `captions` its `caption` rows in order (a section
 * without a drawn figure folds them into `more`), `key` the first N results sorted per mode (N = section.key, else 5 research and 3 learner; a list
 * names the key rows), at learner level after the section's `learner` rows; `more` the other results, then the `detail` rows, then the folded captions.
 * Leads, captions and the next line are placed by role and never sorted. `body` (the results with a text at this level, open rows apart), `details`
 * (detail rows, research level), `numbers` (evidence rows, research level) keep their meaning for the step and stage counts and for the pages that
 * render a section themselves (custom). `placement`: body | open | reference | inputs. `place` maps a row to { where, sid } for deep links (at=).
 * `blocks` (round 7): the section's figures in display order, each { id, kind: leaf | own | lens | move, leaf, captions, tryLine, detail } — a leaf of the
 * map first, the section's own figures, then the figures a page top moved here and the explorers; `figures` lists the ids of the figure column, `another`
 * those under the chip "Another view" (an explorer marked detail, beside another figure of the section), and `captions` every caption row the blocks
 * show, in their order (the section's captions under its first own figure, the intro's under the figure the top moved here with them). A leaf and the
 * explorers of one section are views of one slot (b.view: one at a time, a chip each, the leaf first), after the section's own and moved figures.
 * The top claims its rows: the hero row and the notes are not drawn again in the intro or a section; a row placed in two sections is drawn in the first.
 */
export function buildPageModel(route, s, opts = {}) {
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const learner = s.level === 'learner';
  const custom = new Set(opts.custom || []);
  const has = id => hasText(id, s);
  const all = (rowsByPage()?.get(route) || []).filter(e => visibleIn(e.row, s.mode));
  const heroId = def.hero && def.hero.row && rowsById()?.get(def.hero.row) && visibleIn(rowsById().get(def.hero.row), s.mode) ? def.hero.row : null;

  // parts: membership by parts[].sections or section.part; the reserved parts open (the open fold) and drawer (closed folds)
  const parts = Array.isArray(def.parts) ? def.parts.filter(p => p && p.id) : [];
  const partOf = new Map();
  for (const p of parts) for (const id of p.sections || []) if (!partOf.has(id)) partOf.set(id, p);
  for (const sec of def.sections || []) if (sec && sec.part && !partOf.has(sec.id)) { const p = parts.find(x => x.id === sec.part); if (p) partOf.set(sec.id, p); }
  const placementOf = sec => {
    const p = partOf.get(sec.id);
    if (p && p.id === OPEN_PART) return 'open';
    if (p && p.id === DRAWER_PART) return 'reference';
    return INPUT_SECTIONS.includes(sec.id) || sec.inputs === true ? 'inputs' : 'body';
  };

  // the page top (round 7, interface 37): its notes, the rows of the reserved section top-notes (role note) in their order, at most three, each with a
  // text at this level (at learner level a row with only a short learner text counts); the hero row and the notes are the top's: the page shows each
  // once, so another entry of the same row on the page is not drawn again (the top claims its rows first)
  const noteEntries = all.filter(e => e.so.section === TOP_NOTES).sort(byOrder);
  const noteText = id => has(id) || (learner && hasText(id, { ...s, register: 'short' }));
  const topNotes = [...new Set(noteEntries.filter(e => e.row.id !== heroId && noteText(e.row.id)).map(e => e.row.id))].slice(0, TOP_NOTES_MAX);
  const topClaimed = new Set([heroId, ...noteEntries.map(e => e.row.id)].filter(Boolean));
  const rest = all.filter(e => e.so.section !== TOP_NOTES && !topClaimed.has(e.row.id));

  // sections: the declared ones (by their query) in display order, then any section the rows name that pages.json does not declare; the intro apart.
  // A row placed twice on the page (in two sections) is drawn in the first of them.
  const introEntries = rest.filter(e => e.so.section === INTRO_SECTION);
  const groups = [];
  const claimed = new Set(introEntries);
  const seenRows = new Set(introEntries.map(e => e.row.id));
  // A section the page draws itself (custom: the lattice of the cells, the cards of a page) keeps every row placed in it, the top's among them: its rows
  // are its own pictures and ways (a cell card), not statements drawn twice.
  const notNotes = all.filter(e => e.so.section !== TOP_NOTES);
  for (const sec of orderedSections(def)) {
    if (sec.id === INTRO_SECTION || sec.id === TOP_NOTES) continue;
    const key = (sec.query && sec.query['shownOn.section']) || sec.id;
    const own = custom.has(sec.id);
    const entries = (own ? notNotes : rest).filter(e => !claimed.has(e) && (e.so.section === key || e.so.section === sec.id));
    entries.forEach(e => claimed.add(e));
    groups.push({ sec, id: sec.id, entries: own ? entries.map(e => { seenRows.add(e.row.id); return e; }) : entries.filter(e => { if (seenRows.has(e.row.id)) return false; seenRows.add(e.row.id); return true; }) });
  }
  const extra = new Map();
  for (const e of rest) if (!claimed.has(e) && !seenRows.has(e.row.id)) { if (!extra.has(e.so.section)) extra.set(e.so.section, []); extra.get(e.so.section).push(e); seenRows.add(e.row.id); }
  for (const [sid, entries] of extra) groups.push({ sec: { id: sid, title: { phys: sid, math: sid }, drawer: DRAWER_TABS }, id: sid, entries });

  // round 14: the chains of the body sections, and where the page tells each row (the first chain that tells it); the told rows and their twins
  const chainsAt = new Map(), toldAt = new Map(), toldIds = new Set(), chainLabels = new Map();
  for (const g of groups) {
    if (placementOf(g.sec) !== 'body') continue;
    const list = chainsOf(route, g.id);
    if (!list.length) continue;
    chainsAt.set(g.id, list);
    chainLabels.set(g.id, sectionHeading(g.sec, s, route).label);
    for (const c of list) {
      const mention = new Set(Array.isArray(c.mention) ? c.mention : []);
      for (const row of c.rows) {
        if (mention.has(row)) continue;
        for (const id of [row, c.twins && c.twins[row]]) if (id) { toldIds.add(id); if (!toldAt.has(id)) toldAt.set(id, { chain: c, sid: g.id }); }
      }
    }
  }
  const toldWhere = row => { const t = toldAt.get(row); return t ? { chain: t.chain.id, sid: t.sid, label: chainLabels.get(t.sid) || t.sid, title: chainTitle(t.chain, s) } : null; };

  let heroReg = null;
  if (heroId) heroReg = hasText(heroId, { ...s, register: 'short' }) ? 'short' : has(heroId) ? 'full' : null;
  const hero = heroId && heroReg ? { id: heroId, register: heroReg, figure: heroFigure(def, s), captions: [] } : null;
  // the top's figure when no hero row has a text at this level: the page keeps its picture (the frame shows it alone)
  const topFigure = hero ? hero.figure : heroFigure(def, s);
  const fromMap = !!(def.top && def.top.figure && topFigure === def.top.figure);

  const rowSection = new Map(), place = new Map();
  const put = (id, where, sid) => { if (!place.has(id)) place.set(id, { where, sid }); };
  // the top's rows share one drawer, '__top': the hero row, its captions and the notes
  if (hero) { rowSection.set(hero.id, '__top'); put(hero.id, 'hero', '__top'); }
  topNotes.forEach(id => { rowSection.set(id, '__top'); put(id, 'note', '__top'); });

  // the intro: lead, next, at a glance, the hero's captions, details, learner rows (placed by role). A leaf of the map at the top does not take the intro's
  // captions (they read the page's own hero figure): they go with that figure where the map moves it (a slot with captions "intro"), else to the intro's fold
  const io = [...introEntries].filter(e => e.row.id !== heroId).sort(byOrder);
  const firstOf = (list, role) => { const e = list.find(x => roleOf(x) === role && has(x.row.id)); return e ? e.row.id : null; };
  const intro = { lead: null, next: null, glance: [], more: [], learnerRows: [] };
  const named = k => { const id = def.intro && def.intro[k]; const r = id ? rowsById()?.get(id) : null; return r && visibleIn(r, s.mode) && has(id) ? id : null; };
  intro.lead = named('lead') || firstOf(io, 'lead');
  intro.learnerRows = learner ? io.filter(e => roleOf(e) === 'learner' && has(e.row.id)).map(e => e.row.id) : [];
  const introCaptions = io.filter(e => roleOf(e) === 'caption' && has(e.row.id)).map(e => e.row.id);
  const slotsOf = sid => (Array.isArray(def.slots) ? def.slots : []).filter(sl => sl && sl.section === sid && sl.figure);
  const movedCaptions = fromMap && (Array.isArray(def.slots) ? def.slots : []).some(sl => sl && sl.kind === 'move' && sl.captions === 'intro' && figuresById()?.get(sl.figure) && (!learner || figuresById().get(sl.figure).learner));
  let introTaken = false;   // set when a block of a section takes the intro's captions (a figure the top moved, slot captions "intro")
  if (hero && hero.figure && !fromMap) hero.captions = introCaptions;
  const glanceAll = sortEntries(io.filter(e => roleOf(e) === 'result' && has(e.row.id)), s).map(e => e.row.id);
  intro.glance = glanceAll.filter(id => !isOpenRow(id));
  intro.more = [...sortEntries(io.filter(e => roleOf(e) === 'detail' && has(e.row.id)), s).map(e => e.row.id), ...((hero && hero.figure && !fromMap) || movedCaptions ? [] : introCaptions)];
  if (intro.lead) put(intro.lead, 'intro', '__intro');
  intro.learnerRows.forEach(id => put(id, 'intro', '__intro'));
  hero && hero.captions.forEach(id => { rowSection.set(id, '__top'); put(id, 'caption', '__top'); });
  intro.glance.forEach(id => { rowSection.set(id, '__intro'); put(id, 'glance', '__intro'); });
  intro.more.forEach(id => { rowSection.set(id, '__intro'); put(id, 'intro-more', '__intro'); });

  const assigned = assignedFigures();
  const figs = peekTable('figures') || [];
  const drawable = f => !!f && (!learner || !!f.learner);
  const usedFigures = new Set(topFigure ? [topFigure] : []);
  const sections = [], open = [], openRows = [], reference = [];
  const inputs = { rows: [], lead: null, learnerRows: [] };
  const openByPart = new Map();
  let lastPartGroup = null;
  const nextCandidates = io.filter(e => roleOf(e) === 'next');
  let results = 0;
  const pushOpen = id => { openRows.push(id); rowSection.set(id, '__open'); put(id, 'open', '__open'); };
  if (glanceAll.length > intro.glance.length) {
    const rows = glanceAll.filter(isOpenRow);
    open.push({ id: INTRO_SECTION, label: STORY_WORDS.glance, rows });
    rows.forEach(pushOpen);
  }

  for (const g of groups) {
    const sec = g.sec, sid = g.id, isCustom = custom.has(sid), placement = placementOf(sec);
    const part = partOf.get(sid) || null;
    const { heading, label } = sectionHeading(sec, s, route);
    const entries = g.entries.filter(e => e.row.id !== heroId);
    const inOrder = [...entries].sort(byOrder);
    const sorted = sortEntries(entries, s);
    nextCandidates.push(...inOrder.filter(e => roleOf(e) === 'next'));
    const lead = sec.lead && inOrder.some(e => e.row.id === sec.lead) && has(sec.lead) ? sec.lead : firstOf(inOrder, 'lead');
    const captionsAll = inOrder.filter(e => roleOf(e) === 'caption' && has(e.row.id)).map(e => e.row.id);
    const learnerRows = learner ? inOrder.filter(e => roleOf(e) === 'learner' && has(e.row.id)).map(e => e.row.id) : [];
    const body = [], details = [], numbers = [], detailsHere = [], openHere = [], toldOpen = [];
    for (const e of sorted) {
      const id = e.row.id, role = roleOf(e);
      if (role === 'lead' || role === 'caption' || role === 'learner' || role === 'next' || role === 'chain') continue;
      if (role === 'evidence') { if (!learner && has(id)) numbers.push(id); continue; }
      if (!has(id)) continue;
      // a row a chain of the page tells is drawn by its chain (round 14, D52); an open one stays in its chain too (D57)
      const told = placement === 'body' && toldIds.has(id);
      const open = isOpenRow(id) && !isCustom && placement === 'body';
      if (role === 'detail') { if (told) { if (open) toldOpen.push(id); continue; } if (!learner) details.push(id); if (open) openHere.push(id); else detailsHere.push(id); continue; }
      if (open) { if (told) toldOpen.push(id); else openHere.push(id); } else body.push(id);
    }
    const chainModels = placement === 'body' ? (chainsAt.get(sid) || []).map(c => chainModel(c, s, { claimed: topClaimed, toldWhere })).filter(Boolean) : [];
    const toldHere = [...new Set(chainModels.flatMap(ch => ch.positions.filter(p => !p.mention).map(p => p.id)))];
    const ids = new Set(g.entries.map(e => e.row.id));
    const allIds = [...ids].filter(has);
    const connectiveDef = def.connective ? def.connective[sid] : null;
    const connective = typeof connectiveDef === 'string' ? connectiveDef : connectiveDef && typeof connectiveDef === 'object' ? connectiveDef[s.level] || null : null;
    const base = {
      id: sid, label, heading, part: part && part.id !== OPEN_PART && part.id !== DRAWER_PART ? part.id : null, placement, connective,
      figure: null, figures: [], another: [], blocks: [], lead: null, captions: [], key: [], more: [], learnerRows: [],
      body, details, numbers, drawerRows: [], all: allIds, tabs: sec.drawer || DRAWER_TABS, show: false, chains: [], told: [],
    };

    if (placement === 'inputs') {
      // "What this page takes from outside (n)": every row of the section with a text at this level, its lead and learner rows above them
      const rowsHere = sorted.filter(e => !['lead', 'caption', 'learner', 'next', 'evidence', 'chain'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id);
      inputs.rows.push(...rowsHere);
      if (lead && !inputs.lead) inputs.lead = lead;
      inputs.learnerRows.push(...learnerRows);
      rowsHere.forEach(id => { rowSection.set(id, '__inputs'); put(id, 'inputs', '__inputs'); });
      [lead, ...learnerRows].filter(Boolean).forEach(id => put(id, 'inputs', '__inputs'));
      sections.push({ ...base, lead, learnerRows, drawerRows: rowsHere });
      continue;
    }
    if (placement === 'open') {
      // a section of the open part is a group of the open fold: its lead, then every row with a text (v15's perspectives, questions, notes)
      const rowsHere = [...learnerRows, ...sorted.filter(e => ['result', 'detail', 'caption'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id)];
      const pairIds = sec.pairs === 'splitFrom' ? [...learnerRows, ...inOrder.filter(e => ['result', 'detail', 'caption'].includes(roleOf(e)) && has(e.row.id)).map(e => e.row.id)] : null;
      const grp = { id: sid, label, lead, rows: pairIds || rowsHere, part: OPEN_PART, pairs: pairIds ? pairsOf(pairIds) : null, group: sec.group || null };
      const gp = sec.group ? (part.groups || []).find(x => x.id === sec.group) : null;
      if (sec.group && lastPartGroup && lastPartGroup.groupId === sec.group) { lastPartGroup.sub.push(grp); lastPartGroup.rows.push(...grp.rows); }
      else if (sec.group) { lastPartGroup = { id: `group-${sec.group}`, groupId: sec.group, label: titleIn(gp && gp.title, s) || label, rows: [...grp.rows], sub: [grp] }; open.push(lastPartGroup); }
      else if (grp.rows.length || lead) { lastPartGroup = null; open.push(grp); }
      grp.rows.forEach(id => { rowSection.set(id, '__open'); put(id, 'open', '__open'); if (isOpenRow(id)) openRows.push(id); });
      if (lead) put(lead, 'open', '__open');
      sections.push({ ...base, lead, learnerRows, body: grp.rows.filter(id => !isOpenRow(id)), drawerRows: grp.rows });
      continue;
    }

    // body (and reference) sections: figure, captions, key results, More statements. The figures: the section's own (explicit, then those placed by
    // their caption row; a figure the map of the leaves places elsewhere is not drawn here), and the figures the map places in the section (its slots):
    // a leaf before the section's own figures, a figure a page top moved here and a lens explorer after them, an explorer marked detail under a chip.
    // Each figure is a block with its own readings: the section's caption rows under its first own figure (under its first figure when it has none of
    // its own), the intro's captions under the figure the top moved here with them, a leaf's try line under the leaf.
    const explicit = placement === 'body'
      ? figureList(sec.figure).filter(f => !usedFigures.has(f) && drawableAt(f, route, sid)).map(f => figuresById()?.get(f)).filter(drawable).map(f => f.id) : [];
    // a row the map of the leaves placed here (an entry marked overlay "explore") does not bring the figure it captions with it: that figure stays
    // where its own page draws it
    // (the rows the top claims count here too: the hero row's own entry in a section still places the figures it captions, as before the top)
    const capKey = (sec.query && sec.query['shownOn.section']) || sid;
    const capIds = new Set(all.filter(e => (e.so.section === capKey || e.so.section === sid) && e.so.overlay !== 'explore').map(e => e.row.id));
    const byCaption = placement === 'body'
      ? figs.filter(f => f.captionRow && capIds.has(f.captionRow) && !assigned.has(f.id) && !usedFigures.has(f.id) && !explicit.includes(f.id) && drawable(f)).map(f => f.id) : [];
    // a figure the section names and the map places in it too is the map's (a leaf with its try line, an explorer, a moved figure)
    const slotted = new Set(placement === 'body' ? slotsOf(sid).map(sl => sl.figure) : []);
    const own = [...explicit, ...byCaption].filter(f => !slotted.has(f));
    const slotBlocks = placement === 'body' ? slotsOf(sid).filter(sl => !usedFigures.has(sl.figure) && !own.includes(sl.figure) && drawable(figuresById()?.get(sl.figure))) : [];
    const tryOf = sl => (typeof sl.try === 'string' && sl.try.trim() ? sl.try : null);
    // the intro's captions go with the first figure the top moved with them (one block takes them)
    const takesIntro = sl => { if (introTaken || !(movedCaptions && sl.kind === 'move' && sl.captions === 'intro')) return false; introTaken = true; return true; };
    const blocks = [
      ...slotBlocks.filter(sl => sl.kind === 'leaf').map(sl => ({ id: sl.figure, kind: 'leaf', leaf: sl.leaf || null, captions: [], tryLine: tryOf(sl), detail: false })),
      ...own.map(f => ({ id: f, kind: 'own', leaf: null, captions: [], tryLine: null, detail: false })),
      ...[...slotBlocks.filter(sl => sl.kind === 'move'), ...slotBlocks.filter(sl => sl.kind !== 'leaf' && sl.kind !== 'move')].map(sl => ({ id: sl.figure, kind: sl.kind === 'lens' ? 'lens' : 'move', leaf: sl.leaf || null, captions: takesIntro(sl) ? [...introCaptions] : [], tryLine: tryOf(sl), detail: !!sl.detail })),
    ];
    // an explorer marked detail sits under the chip only beside another figure of the section; alone, it is the section's figure
    if (!blocks.some(b => !b.detail)) blocks.forEach(b => { b.detail = false; });
    // a leaf and the lens explorers the map places in the same section share one slot (round 7, wave 2: the leaf field beside the two Maxwell views):
    // one view at a time, a chip each (b.view), the leaf first and shown at first; the views stand where the explorers stand, after the section's own
    // figures and a figure a page top moved here, and none of them sits under "Another view"
    if (blocks.some(b => b.kind === 'leaf') && blocks.some(b => b.kind === 'lens')) {
      const views = [...blocks.filter(b => b.kind === 'leaf'), ...blocks.filter(b => b.kind === 'lens')];
      views.forEach(b => { b.view = true; b.detail = false; });
      blocks.splice(0, blocks.length, ...blocks.filter(b => !b.view), ...views);
    }
    blocks.forEach(b => usedFigures.add(b.id));
    const capHolder = blocks.find(b => b.kind === 'own') || blocks.find(b => !b.detail) || null;
    if (capHolder) capHolder.captions = [...captionsAll, ...capHolder.captions];
    // in display order: the figure column (sec.figures), then the explorers under the chip (sec.another); the captions as the blocks show them
    const inColumn = blocks.filter(b => !b.detail), underChip = blocks.filter(b => b.detail);
    const figures = inColumn.map(b => b.id), another = underChip.map(b => b.id);
    const captions = [...inColumn, ...underChip].flatMap(b => b.captions);
    const orphanCaptions = capHolder ? [] : captionsAll;
    const k = keyOf(sec, s);
    const inList = k.list ? new Set(k.list) : null;
    // the told rows are drawn by their chains: the key results and "More statements" are the section's other rows (its side notes)
    const free = body.filter(id => !toldIds.has(id));
    const keyPool = inList ? free.filter(id => inList.has(id)) : free;
    const restPool = inList ? free.filter(id => !inList.has(id)) : [];
    const pool = [...learnerRows, ...keyPool, ...restPool];
    const n = placement === 'reference' ? 0 : learner ? (k.n ?? KEY_RESULTS.learner) : k.n == null ? keyPool.length : k.n;
    const key = isCustom ? body : pool.slice(0, n);
    const more = isCustom ? [] : [...pool.slice(n), ...detailsHere, ...orphanCaptions];
    const shownRows = [...(lead ? [lead] : []), ...captions, ...key, ...more];
    // a leaf or a lens explorer of the map is a picture to play with at both levels: its section shows even with no row in plain words; so does a
    // figure a page top moved here with the captions that read it in words of this level
    const playable = blocks.some(b => b.kind === 'leaf' || b.kind === 'lens' || (b.kind === 'move' && b.captions.length > 0));
    let show = learner ? shownRows.length > 0 || playable : shownRows.length > 0 || figures.length > 0 || numbers.length > 0;
    if (chainModels.length) show = true;
    if (isCustom) show = show || allIds.length > 0;
    // the drawer lists the told positions with the other statements; a told row keeps a drawer it already has (the page top's, for the hero row)
    const drawerRows = [...new Set([...captions, ...toldHere, ...key, ...more, ...numbers])];
    drawerRows.forEach(id => { if (!toldIds.has(id) || !rowSection.has(id)) rowSection.set(id, sid); });
    if (lead) put(lead, 'lead', sid);
    captions.forEach(id => put(id, 'caption', sid));
    key.forEach(id => put(id, 'key', sid));
    more.forEach(id => put(id, placement === 'reference' ? 'reference' : 'more', sid));
    numbers.forEach(id => put(id, 'drawer', sid));
    for (const ch of chainModels) {
      if (ch.lead) put(ch.lead, 'chain', sid);
      for (const p of ch.positions) if (!p.mention) place.set(p.id, { where: 'chain', sid });
    }
    const model = { ...base, figure: figures[0] || null, figures, another, blocks, lead, captions, key, more, learnerRows, drawerRows, show, chains: chainModels, told: toldHere };
    if (placement === 'reference') { reference.push({ ...model, show: show && (key.length + more.length > 0) }); sections.push({ ...model, show: false }); continue; }
    sections.push(model);
    results += body.length + learnerRows.length + toldHere.filter(id => !body.includes(id)).length;
    toldOpen.forEach(id => { if (!openRows.includes(id)) openRows.push(id); });
    if (openHere.length) {
      if (part && parts.length) {
        let grp = openByPart.get(part.id);
        if (!grp) { grp = { id: part.id, label: titleIn(part.title, s) || label, rows: [] }; openByPart.set(part.id, grp); open.push(grp); }
        grp.rows.push(...openHere);
      } else open.push({ id: sid, label, rows: openHere });
      openHere.forEach(pushOpen);
    }
  }
  // the open groups of the body come first (in page order), then the groups of the open part (in its order)
  const isPartGroup = gr => gr.part === OPEN_PART || !!gr.groupId;
  const openOrdered = [...open.filter(gr => !isPartGroup(gr)), ...open.filter(isPartGroup)];
  // the figure the top moved with the intro's captions is drawn nowhere at this level after all (used before, or no body section holds it): the
  // captions fold into the intro's "More statements", as on a page whose hero figure is not drawn
  if (movedCaptions && !introTaken) introCaptions.forEach(id => { if (!place.has(id)) { intro.more.push(id); rowSection.set(id, '__intro'); put(id, 'intro-more', '__intro'); } });
  const nx = [...nextCandidates].sort(byOrder).find(e => has(e.row.id));
  intro.next = named('next') || (nx ? nx.row.id : null);
  if (intro.next) put(intro.next, 'next', '__next');
  const bodyParts = [];
  for (const sec of sections) {
    if (!sec.show || sec.placement !== 'body' || !sec.part) continue;
    const last = bodyParts[bodyParts.length - 1];
    if (last && last.id === sec.part) last.sections.push(sec.id);
    else { const p = parts.find(x => x.id === sec.part); bodyParts.push({ id: sec.part, title: titleIn(p && p.title, s), sections: [sec.id] }); }
  }
  const hasInputs = inputs.rows.length > 0 || inputs.learnerRows.length > 0;
  // the page top (interface 37): lead · hero figure (wide when its seed says so) · try line · notes · the two ways (the hero row's texts by mode at this
  // level, in the hero's register; with only a text for both modes the two sides are one record, drawn once) · the hero's "How do we know?" line
  let top = null;
  if (heroId || topFigure) {
    const tc = def.connective ? def.connective[TOP_NOTES] : null;
    const tryLine = typeof tc === 'string' ? tc : tc && typeof tc === 'object' ? tc[s.level] || null : null;
    const wayOf = mode => (hero ? (textRecord(hero.id, { mode, level: s.level, lens: s.lens, register: hero.register }) || {}).record || null : null);
    const phys = wayOf('phys'), math = wayOf('math');
    top = {
      lead: intro.lead,
      hero: { row: hero ? hero.id : null, figure: topFigure || null, wide: !!(topFigure && (figuresById()?.get(topFigure) || {}).size === 'wide') },
      tryLine: tryLine && tryLine.trim() ? tryLine : null,
      notes: topNotes,
      ways: { phys, math, one: !!phys && phys === math, lens: (def.top && def.top.lens) || null },
      leaf: (def.top && def.top.leaf) || null,
      fromMap,
    };
  }
  results += topNotes.length;
  // D57: the open fold names by title the chains drawn on the page whose weakest link is open
  const openChains = sections.filter(x => x.show && x.placement === 'body').flatMap(x => x.chains.filter(ch => ch.status === 'open').map(ch => ({ id: ch.id, title: ch.title, sid: x.id, label: x.label })));
  return {
    def, route, hero, intro, top, parts: bodyParts, sections, open: openOrdered, openRows, reference,
    inputs: hasInputs ? inputs : null, rowSection, place, results, learnerShort: learner && results < 3, openChains,
  };
}

/**
 * The lead of a page for a card elsewhere (interface 27; the home's "The Atlas, chapter by chapter", docs/STORY_PLAN.md §2.7). STABLE SIGNATURE:
 *   pageLead(route, settings = { mode, level, lens }) → { id, register, route } | null
 * `id` is the page's lead: pages.json `intro.lead`, else the row of role `lead` in its reserved section `intro`, visible in the mode;
 * `register` is 'short' when the row has a short text at this level, else 'full' (textFor never falls back across levels: at learner level the
 * row needs a learner text). null when the page has no lead with a text at this level. Render it with Statement (id, register), never as free text.
 */
export function pageLead(route, settings) {
  const s = { mode: 'phys', level: 'research', lens: null, ...(settings || {}) };
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const entries = (rowsByPage()?.get(route) || []).filter(e => e.so.section === INTRO_SECTION && roleOf(e) === 'lead' && visibleIn(e.row, s.mode)).sort(byOrder);
  const named = def.intro && def.intro.lead && rowsById()?.get(def.intro.lead);
  const ids = [...(named && visibleIn(named, s.mode) ? [named.id] : []), ...entries.map(e => e.row.id)];
  for (const id of ids) {
    if (hasText(id, { ...s, register: 'short' })) return { id, register: 'short', route };
    if (hasText(id, { ...s, register: 'full' })) return { id, register: 'full', route };
  }
  return null;
}

// ---------------------------------------------------------------- the record of a page (round 7, interface 38)
/** the file name of a page's record: content/records/<route with / as _>.json (the start page "" as "index") */
export const recordFile = route => `content/records/${String(route || '').replace(/\//g, '_') || 'index'}.json`;
let checkIdMemo = null;
/** check id (the base name of a script without its extension, or an id the script prints) → the script's path in checks.json */
function scriptOfCheckId() {
  const checks = peekTable('checks');
  if (!Array.isArray(checks)) return new Map();
  if (checkIdMemo && checkIdMemo.checks === checks) return checkIdMemo.map;
  const map = new Map();
  for (const c of checks) {
    if (!c || !c.script) continue;
    const base = String(c.script).split('/').pop().replace(/\.(py|mjs)$/, '');
    if (!map.has(base)) map.set(base, c.script);
    for (const i of c.ids || []) if (i && i.id && !map.has(i.id)) map.set(i.id, c.script);
  }
  checkIdMemo = { checks, map };
  return map;
}
/** the script of checks.json that an evidence entry names (by its path, its file name, or its check id), or null */
export function evidenceScript(e) {
  const idx = checksIndex();
  if (e && e.script && idx) {
    const p = e.script.startsWith('checks/') ? e.script : `checks/${e.script}`;
    const hit = idx.byScript.get(p) || (idx.byBase.get(String(e.script).split('/').pop()) || [])[0];
    if (hit) return hit.script;
  }
  return (e && e.check && scriptOfCheckId().get(e.check)) || null;
}
/** the rows placed on a page (a shownOn entry on its route), with the hero row, by their first place on the page (lowest order), then by id */
export function placedRows(route) {
  const def = pagesByRoute()?.get(route);
  const first = new Map();
  for (const e of rowsByPage()?.get(route) || []) { const o = e.so.order ?? 0; if (!first.has(e.row.id) || o < first.get(e.row.id)) first.set(e.row.id, o); }
  const hero = def && def.hero && def.hero.row;
  if (hero && rowsById()?.has(hero) && !first.has(hero)) first.set(hero, -1);
  return [...first].sort((a, b) => a[1] - b[1] || (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)).map(([id]) => id);
}
/** the id in checks.json of a script of checks.json (its path, "checks/…", when the entry has no id) */
const checkIdOf = script => { const c = checksIndex()?.byScript.get(script); return (c && c.id) || script; };
const bodyOf = (id, level) => { const r = textRecord(id, { mode: 'both', level, lens: null, register: 'full' }); return r && r.record.mode === 'both' ? r.record.body : null; };
/**
 * The record of a page (interface 38; R7-4 "the record"): every row placed on it with its labels, its status, its scripts and their last runs, its
 * dependencies, how many lens readings it has, its address and its research and learner texts; the scripts the page names; the content version.
 * The same function writes dist/content/records/<route>.json at build (tools/page_records.mjs) and fills the record fold of the page (PageRecord):
 *   { route, title, rows: [{ id, kind, stage, ptype, status, badge, notions, address, evidence: [{ check, script, mode, lastRun: { ok, fail, passed } }],
 *     depends, readingsCount, texts: { research, learner } }], scripts: [ids of checks.json], generated } — `evidence[].script` is the script's
 *     path in checks.json, `scripts` the ids of those entries (each named once, sorted).
 * Round 14 (D55: the agents' view keeps every statement, the reader's view tells the story): `chains`, the chains of content/chains.json on the page,
 * section by section in the page's order, each in its section's order: [{ id, section, title, lead, rows, mention, twins, joins, links, shape, status }]
 * as the chain record holds them, with `status` computed (chainStatus); [] on a page without chains or while the table is not loaded.
 * Needs the tables rows, pages, texts, derived_status, checks, check_runs and lens_readings (and version for `generated`; chains for `chains`); null for
 * an unknown page.
 */
export function pageRecord(route) {
  const def = pagesByRoute()?.get(route);
  if (!def) return null;
  const runs = lastRuns();
  const readings = new Map();
  for (const r of peekTable('lens_readings') || []) if (r && r.row) readings.set(r.row, (readings.get(r.row) || 0) + 1);
  const scripts = new Set();
  const rows = placedRows(route).map(id => {
    const r = rowsById().get(id), st = statusOf(id) || {};
    const evidence = (r.evidence || []).map(e => {
      const script = evidenceScript(e);
      if (script) scripts.add(checkIdOf(script));
      const run = script && runs ? runs.get(script) : null;
      return { check: e.check || null, script, mode: e.mode || null, lastRun: run ? { ok: run.ok ?? null, fail: run.fail ?? null, passed: run.passed ?? null } : null };
    });
    return {
      id, kind: r.kind || null, stage: r.stage || null, ptype: r.ptype || null, status: st.status || null, badge: st.badge || null,
      notions: [...(r.notions || [])], address: st.address || null, evidence, depends: (r.depends || []).map(d => ({ id: d.id, rel: d.rel })),
      readingsCount: readings.get(id) || 0, texts: { research: bodyOf(id, 'research'), learner: bodyOf(id, 'learner') },
    };
  });
  const v = peekTable('version');
  return { route, title: def.title || null, rows, scripts: [...scripts].sort(), chains: recordChains(def), generated: (v && v.contentVersion) || null };
}
/** the chains of a page for its record: section by section in the page's display order (a section the page does not list last), each as chainsOf orders it */
function recordChains(def) {
  const secs = new Map(orderedSections(def).map((x, i) => [x.id, i]));
  const rank = c => (secs.has(c.section) ? secs.get(c.section) : secs.size);
  const copy = x => (x && typeof x === 'object' ? JSON.parse(JSON.stringify(x)) : x ?? null);
  return chainsOnPage(def.route).map((c, i) => ({ c, i })).sort((a, b) => rank(a.c) - rank(b.c) || a.i - b.i).map(({ c }) => ({
    id: c.id, section: c.section, title: copy(c.title), lead: c.lead || null, rows: [...c.rows], mention: [...(c.mention || [])], twins: copy(c.twins || {}),
    joins: copy(c.joins || []), links: copy(c.links || []), shape: c.shape || null, status: chainStatus(c),
  }));
}

/** the rows a route shows, for the lens picker's counts */
export function rowsOfMatch(match) {
  if (!match) return [];
  if (match.name === 'cell') {
    const key = cellKeyOf(match.key);
    return key ? (rowsByCell()?.get(key) || []) : [];
  }
  if (match.page == null || match.name === 'lens' || match.name === 'glossary') return [];
  return [...new Set((rowsByPage()?.get(match.page) || []).map(e => e.row.id))];
}
/** lens key → number of the given rows that have a text in that lens at this level */
export function lensCounts(rowIds, level) {
  const idx = lensTextIndex();
  const rd = lensReadingsIndex();
  const out = new Map();
  if (!idx && !rd) return out;
  const lenses = new Set([...(idx ? idx.keys() : []), ...(rd ? rd.keys() : [])]);
  for (const lens of lenses) {
    const set = idx && idx.get(lens) ? idx.get(lens).get(level) : null;
    const byRow = rd ? rd.get(lens) : null;
    // a row counts when it has a text in the lens at this level, or a reading in the lens (readings with a formula are hidden at learner level)
    const hasReading = id => { const rs = byRow && byRow.get(id); if (!rs || !rs.length) return false; return level === 'learner' ? rs.some(r => !/[$\\^_=]/.test(String(r.term || ''))) : true; };
    out.set(lens, rowIds.filter(id => (set && set.has(id)) || hasReading(id)).length);
  }
  return out;
}

// ---------------------------------------------------------------- links to rows
const QUESTION_RE = /^Q[A-Z]?\d+[a-z]?$/;
/** where a row (or a theorem / question id) lives: { path, at } */
export function rowHome(id) {
  if (/^T\d+$/.test(id)) return { path: 'logbook/theorems', at: id };
  if (/^CAND-/.test(id)) return { path: 'logbook/candidates', at: id };
  const r = rowsById()?.get(id) || rowsById()?.get(id.replace(/[a-z]$/, ''));
  if (r && r.shownOn && r.shownOn.length) {
    const so = [...r.shownOn].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
    return { path: so.page, at: r.id };
  }
  if (QUESTION_RE.test(id) || (peekTable('questions') || []).some(q => q.id === id)) return { path: 'logbook/questions', at: id };
  return { path: 'logbook/register', at: id };
}

// ---------------------------------------------------------------- cells
/** "1,3" → "(1,3,0)"; "1,n-1,0" → "(1,n-1,0)"; "all n" → "all n"; "row 8" → "row 8" */
export function cellKeyOf(key) {
  if (!key) return null;
  const k = key.trim();
  const m = /^(\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?$/.exec(k);
  if (m) return `(${m[1]},${m[2]},${m[3] || 0})`;
  if (/^[\w+\- ]+(,[\w+\- ]+)+$/.test(k)) return `(${k})`;
  return k;
}

const CELL_RE = /Cl\((\d{1,2}),(\d{1,2})(?:,(\d{1,2}))?\)/;
/** the 25 cards of the cells page: one per first line of an ATL row, with its further lines; title = the text up to the cell name */
export function cellCards(s) {
  const entries = (rowsByPage()?.get('cells') || []).filter(e => e.so.section === 'cards' && visibleIn(e.row, s.mode));
  entries.sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0));
  const cards = [], byPrimary = new Map();
  for (const e of entries) {
    const pid = e.row.splitFrom || e.row.id;
    if (!byPrimary.has(pid)) { const c = { primary: pid, lines: [] }; byPrimary.set(pid, c); cards.push(c); }
    byPrimary.get(pid).lines.push(e.row.id);
  }
  const out = [];
  for (const c of cards) {
    const text = textFor(c.primary, s);
    if (!text) continue;
    const row = rowsById().get(c.primary);
    const m = CELL_RE.exec(text);
    let title, sig = null, route = null, cellLabel = null;
    if (m && m.index < 160) {
      let end = m.index + m[0].length;
      const iso = /^(?:[≅=][^\s,;]+)+/.exec(text.slice(end));
      if (iso) end += iso[0].length;
      title = text.slice(0, end).replace(/[.,;:]+$/, '');
      sig = [+m[1], +m[2], +(m[3] || 0)];
      route = `cells/${sig[0]},${sig[1]}${sig[2] ? ',' + sig[2] : ''}`;
    } else {
      const cut = /[,.:;]/.exec(text);
      title = cut && cut.index > 0 && cut.index < 90 ? text.slice(0, cut.index) : text.slice(0, 80).replace(/\s+\S*$/, '') + '…';
      cellLabel = (row && row.cells && row.cells[0]) || null;
      route = cellLabel ? cellRoute(cellLabel) : null;
      // a card whose text names no Cl(p,q) but whose row names one cell "(p,q,r)" is that cell's card
      const m2 = cellLabel ? /^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$/.exec(cellLabel) : null;
      if (m2) { sig = [+m2[1], +m2[2], +m2[3]]; cellLabel = null; }
    }
    out.push({ ...c, title, sig, route, cellLabel, more: c.lines.length - 1 });
  }
  return out;
}

/** the clock of a signature, c = p − q mod 8 (null bits weigh 0), as the kernel's Gauss sum gives it (cellmath.js) */
const clockOfSig = sig => (sig ? clockOf(sig[0], sig[1], sig[2]) : null);

/**
 * The cards laid out as the lattice: one column per n = p + q + r (0 … the largest n of a card, at least 8), and in a column the cards
 * ordered by their clock c, then by p (larger first), then as the page orders them. Cards that name no single cell (a family "(1,n-1,0)",
 * "all n") are `loose`. → { columns, placed: [{ card, n, c, col, row }], loose: [card] }; col and row count from 1.
 */
export function latticeLayout(cards) {
  const placed = [], loose = [];
  cards.forEach((card, i) => {
    if (!card.sig) { loose.push(card); return; }
    const [p, q, r] = card.sig;
    placed.push({ card, n: p + q + r, c: clockOfSig(card.sig), p, i });
  });
  const columns = Math.max(9, ...placed.map(x => x.n + 1));
  placed.sort((a, b) => a.n - b.n || a.c - b.c || b.p - a.p || a.i - b.i);
  const depth = new Map();
  for (const x of placed) { const k = (depth.get(x.n) || 0) + 1; depth.set(x.n, k); x.col = x.n + 1; x.row = k; }
  return { columns, placed: placed.map(({ card, n, c, col, row }) => ({ card, n, c, col, row })), loose };
}

// ---------------------------------------------------------------- the learner's "How do we know?" line under a hero
const plural2 = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const scriptName = e => String(e.script || e.check || '').split('/').pop();
/**
 * One connective line from a row's evidence and status (numbers from rows.json, no law stated): the scripts that ran (named once each),
 * those only read, the inputs it uses; "checked by" only when the status is proved by the Atlas or standard.
 * e.g. "Checked by 6 scripts that ran; 1 input needed."  → string, or null for a row that is not in the tables.
 */
export function howWeKnow(rowId) {
  const r = rowsById()?.get(rowId);
  if (!r) return null;
  const ran = new Set(), read = new Set();
  for (const e of r.evidence || []) { const k = scriptName(e); if (!k) continue; if (e.mode === 'ran') ran.add(k); else if (e.mode === 'read') read.add(k); }
  for (const k of ran) read.delete(k);
  const inputs = new Set((r.depends || []).filter(d => d.rel === 'uses-input').map(d => d.id));
  const st = (statusOf(rowId) || {}).status;
  const parts = [];
  if (ran.size) parts.push(st === 'proved-by-atlas' || st === 'standard' ? `Checked by ${plural2(ran.size, 'script')} that ran` : `${plural2(ran.size, 'script')} ran on it`);
  if (read.size) parts.push(ran.size ? `${read.size} more read, not run here` : `Read in ${plural2(read.size, 'script')}, not run here`);
  if (!ran.size && !read.size) parts.push('No script is recorded for it');
  if (inputs.size) parts.push(`${plural2(inputs.size, 'input')} needed`);
  return parts.join('; ') + '.';
}

// ---------------------------------------------------------------- the map of the steps
let graphMemo = null;
/**
 * The steps as a graph (06 /steps): the twenty steps of steps.json that have a page, and an edge B → A when a row shown on step A derives
 * from a row shown on step B (rows.json `depends`, rel "derives"); `links` counts the pairs of rows behind an edge.
 * → { nodes: [step records by number], edges: [{ from, to, links }] } or null while the tables load.
 */
export function stepGraph() {
  const rows = peekTable('rows'), steps = peekTable('steps'), pages = pagesByRoute();
  if (!rows || !steps || !pages) return null;
  if (graphMemo && graphMemo.rows === rows && graphMemo.steps === steps && graphMemo.pages === pages) return graphMemo.value;
  const nodes = steps.filter(st => isStep(st) && pages.has(st.route)).sort((a, b) => a.no - b.no);
  const routes = new Set(nodes.map(n => n.route));
  const pagesOf = new Map(rows.map(r => [r.id, new Set((r.shownOn || []).map(so => so.page))]));
  const pairs = new Map();
  for (const r of rows) {
    for (const so of r.shownOn || []) {
      if (!routes.has(so.page)) continue;
      for (const d of r.depends || []) {
        if (d.rel !== 'derives') continue;
        for (const from of pagesOf.get(d.id) || []) {
          if (from === so.page || !routes.has(from)) continue;
          const k = `${from}\u0001${so.page}`;
          if (!pairs.has(k)) pairs.set(k, new Set());
          pairs.get(k).add(`${r.id}\u0001${d.id}`);
        }
      }
    }
  }
  const no = new Map(nodes.map(n => [n.route, n.no]));
  const edges = [...pairs].map(([k, set]) => { const [from, to] = k.split('\u0001'); return { from, to, links: set.size }; })
    .sort((a, b) => no.get(a.to) - no.get(b.to) || no.get(a.from) - no.get(b.from));
  const value = { nodes, edges };
  graphMemo = { rows, steps, pages, value };
  return value;
}

// ---------------------------------------------------------------- steps
function dominantField(route) {
  const n = new Map();
  for (const e of rowsByPage()?.get(route) || []) for (const f of e.row.fields || []) n.set(f, (n.get(f) || 0) + 1);
  let best = null, bc = -1;
  for (const f of FIELD_ORDER) if ((n.get(f) || 0) > bc) { best = f; bc = n.get(f) || 0; }
  return bc > 0 ? best : null;
}
/** one card per step page (steps.json, without the shape chapters), with counts from the page model at these settings */
export function stepCards(s) {
  const steps = (peekTable('steps') || []).filter(st => isStep(st) && pagesByRoute()?.has(st.route));
  return steps.map(st => {
    const m = buildPageModel(st.route, s);
    const body = m.sections.flatMap(sec => sec.body);
    const provedAtlas = body.filter(id => (statusOf(id) || {}).status === 'proved-by-atlas').length;
    return { step: st, route: st.route, hero: m.hero, results: m.results, open: m.openRows.length, provedAtlas, stage: st.stage, field: dominantField(st.route) };
  });
}
