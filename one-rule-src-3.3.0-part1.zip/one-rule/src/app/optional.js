// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/optional.js — the parts other owners build: the figures (FIGURES) and src/logbook/LogbookPage.jsx (default export).
// build.sh aliases '@one-rule/figures' and '@one-rule/logbook' to them when they exist, else to the placeholders in src/pages/optional/.
// The figures (D47, interface 34): the browser bundle gets src/figures/core.js (the figures of src/figures/*.jsx) and the extra figures from the chunk
// dist/figures-extra.js once it is in (src/app/lazyFigures.js); server rendering and the tests alias src/figures/index.js, the full registry.
// The modules are required inside try/catch so that a module that throws while loading leaves the rest of the app working.
import { extraFigure } from './lazyFigures.js';

let FIGURES = {};
let LogbookPage = null;
const problems = [];
try {
  // eslint-disable-next-line no-undef
  const m = require('@one-rule/figures');
  FIGURES = (m && (m.FIGURES || (m.default && m.default.FIGURES))) || {};
} catch (e) { problems.push(['figures', e]); }
try {
  // eslint-disable-next-line no-undef
  const m = require('@one-rule/logbook');
  LogbookPage = (m && (m.default || m.LogbookPage)) || null;
} catch (e) { problems.push(['logbook', e]); }
if (problems.length && typeof console !== 'undefined') for (const [w, e] of problems) console.warn(`[one-rule] the ${w} module did not load; a placeholder is shown instead:`, e && e.message);

let figuresOn = true;
/** tests can switch the drawings off to isolate the pages from the figures' own code */
export function setFiguresEnabled(on) { figuresOn = !!on; }
export const figuresEnabled = () => figuresOn;
/** the component C registered for a figure id (a function, or a memo/forwardRef object): the bundle's own, else the chunk's once it is in; or null */
export function figureComponent(id) {
  if (!figuresOn || !FIGURES) return null;
  const c = FIGURES[id] || extraFigure(id);
  return c && (typeof c === 'function' || (typeof c === 'object' && c.$$typeof)) ? c : null;
}
export { LogbookPage };
