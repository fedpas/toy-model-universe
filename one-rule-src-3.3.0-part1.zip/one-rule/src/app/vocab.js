// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/app/vocab.js — the fixed vocabularies of the content model (02 §1, 04 §6, 05 §4). Codes and UI words only; no statement lives here.

/** the mathematician's kinds, in the order mathematics mode sorts by (04_LABELLING.md §6) */
export const KIND_ORDER = ['definition', 'construction', 'lemma', 'theorem', 'range', 'classification', 'invariant', 'example', 'counterexample', 'computation', 'reduction', 'reading', 'conjecture', 'question', 'dead-end', 'pointer', 'meta'];
/** the physicist's stages (02 §1) */
export const STAGE_ORDER = ['A', 'K', 'F', 'D', 'O', 'M'];
export const STAGE_NAMES = { A: 'Algebra', K: 'Kinematics', F: 'Fields', D: 'Dynamics', O: 'Observation', M: 'Method' };
/** the mathematician's fields (02 §1) */
export const FIELD_ORDER = ['algebra', 'geometry', 'topology', 'category', 'combinatorics', 'analysis'];
export const FIELD_NAMES = { algebra: 'Algebra', geometry: 'Geometry', topology: 'Topology', category: 'Category theory', combinatorics: 'Combinatorics', analysis: 'Analysis' };

/** the 29 notions of the labelling scheme, in mask order; the square is +1 (the rule supplies it), −1 (imported), 0 (an input) */
export const NOTIONS = ['lbl', 'sgn', 'sq', 'grd', 'qf', 'clk', 'mir', 'nul', 'tns', 'mod', 'biv', 'cnx', 'var', 'sol', 'lat', 'fin', 'div', 'dyn', 's-alg', 's-geo', 's-phy', 's-cat', 'src', 'i-chart', 'i-time', 'i-J', 'i-act', 'i-tab', 'i-meta'];
export const notionSquare = n => (n.startsWith('i-') ? 0 : n.startsWith('s-') || n === 'src' ? -1 : 1);

/** lens kinds as the picker groups them (lenses.json `kind`) */
export const LENS_KIND_ORDER = ['branch', 'language', 'shape', 'researcher', 'labels', 'convention'];
export const LENS_KIND_NAMES = { branch: 'Branches of mathematics', language: 'Languages of physics', shape: 'Shapes', researcher: 'Researchers', labels: 'Labels', convention: 'Conventions' };

/** the five badges (05 §4): kind → words at the two levels. The research word of an input badge carries its kind, from the status table. */
export const BADGE_KINDS = ['open', 'cited', 'ours', 'input', 'new'];
export const BADGE_WORDS = {
  open: { research: 'open', learner: 'not finished' },
  cited: { research: 'not yet proved here', learner: 'not yet proved here' },
  ours: { research: 'our reading', learner: 'our idea' },
  input: { research: 'needs an input', learner: 'we had to choose this' },
  new: { research: 'new', learner: 'new' },
};
const STATUS_TO_KIND = { open: 'open', cited: 'cited', ours: 'ours', input: 'input' };

/** the badge kind of a status record or of a (status, badge word) pair; null when the statement carries no badge */
export function badgeKind(status, badge) {
  if (!badge) return null;
  if (badge === 'open') return 'open';
  if (badge === 'not yet proved here') return 'cited';
  if (badge === 'our reading') return 'ours';
  if (badge.startsWith('needs an input')) return 'input';
  if (badge === 'new') return 'new';
  return STATUS_TO_KIND[status] || null;
}

/** the status of a statement that carries no badge, in words (the search palette): "checked" and "standard" as content/persona_rules.md names them */
export const STATUS_PLAIN = {
  'proved-by-atlas': { research: 'checked', learner: 'checked' },
  standard: { research: 'standard', learner: 'textbook' },
  meta: { research: 'about the Atlas', learner: 'about the Atlas' },
};

/** the drawer tabs, in order (05 §4) */
export const DRAWER_TABS = ['evidence', 'needs', 'depends', 'readings', 'numbers', 'address'];
export const DRAWER_TAB_NAMES = { evidence: 'Evidence', needs: 'Needs', depends: 'Rests on / leads to', readings: 'Readings', numbers: 'Numbers', address: 'Address' };

export const rankIn = (order, v) => { const i = order.indexOf(v); return i < 0 ? order.length : i; };

// ---------------------------------------------------------------- the story round (docs/STORY_PLAN.md §1.3, §2; BUILD_CONTRACTS interfaces 26–29)
/** the roles of a shownOn entry: lead (one per section, first), caption (the reading of the section's figure, under it), result (statements:
 *  the first N are the key results), detail ("More statements"), learner (shown at learner level only), next (one per page, above the link to
 *  the next page), evidence (the drawer's Numbers), note (one of the three notes of a page top, round 7: interface 37), chain (a story row that
 *  leads a chain, drawn only by its chain, never among the key results or in "More statements": round 14, docs/round14/STORY_ROUND.md §2.3) */
export const ROLES = ['lead', 'caption', 'result', 'detail', 'learner', 'next', 'evidence', 'note', 'chain'];
/** the reserved section of a page that holds its intro: the page's lead, its next line, its "at a glance" rows, the hero figure's captions */
export const INTRO_SECTION = 'intro';
/** the reserved section of a page that holds the notes of its top (role note, at most three, in their order: interface 37) */
export const TOP_NOTES = 'top-notes';
/** the most notes a page top shows */
export const TOP_NOTES_MAX = 3;
/** the reserved parts of a page: "open" holds the sections drawn inside the open fold (perspectives, questions, notes), each a group;
 *  "drawer" the sections kept out of the reading, each a closed fold after the open items */
export const OPEN_PART = 'open';
export const DRAWER_PART = 'drawer';
/** the sections whose rows are the page's inputs ("What this page takes from outside") */
export const INPUT_SECTIONS = ['needs'];
/** key results per section before "More statements (n)" (A54); a section's `key` overrides */
export const KEY_RESULTS = { research: 5, learner: 3 };
/** the connective words of the page template (headings and fold labels; no statement) */
export const STORY_WORDS = {
  glance: 'At a glance',
  more: 'More statements',
  inputs: 'What this page takes from outside',
  behind: 'The statement behind the question',
};
/** the connective words of a page top and of its record (round 7, interfaces 36–38; headings, labels and counts, no statement) */
export const TOP_WORDS = {
  try: 'Try',
  notes: 'Three notes',
  phys: 'The physicist’s way',
  math: 'The mathematician’s way',
  anotherView: 'Another view',
  views: 'Views',
  record: 'The record of this page',
  recordLearner: 'For researchers and agents',
  download: 'Download this record (JSON)',
};
/** the names of the branch lenses in the eyebrow of the mathematician's way ("The mathematician's way · geometry"), as Octavo named its ways in */
export const WAY_IN = { geo: 'geometry', alg: 'algebra', top: 'topology', cat: 'category', comb: 'counting' };
// ---------------------------------------------------------------- the story round 14 (docs/round14/STORY_ROUND.md §2, §4; interfaces 40–41)
/** the research connective of a chain's link (D55), one word or three, each at most 24 characters and in the connective budget: the relation of the
 *  `depends` edge behind the link (V3), so that "So" is never a claim of its own; `from` names the earlier position a branch rests on, `back` a link
 *  whose earlier position rests on the later one, `order` two rows that only sit side by side (no edge: no unearned "So", C4) */
export const CHAIN_WORDS = {
  derives: 'So', from: 'From', instance: 'A case of it', equiv: 'Equivalently', 'uses-input': 'With an input', cycle: 'And back', continues: 'And',
  contrasts: 'By contrast', order: 'Beside it', back: 'It rests on',
};
/** the word before a position at research level: "It rests on" for a link read backwards, "From <id>" for a branch from an earlier position (the id
 *  of the row shown there), else the word of its relation ("Beside it" for a relation the vocabulary does not know); null for the first position */
export function chainWord(link) {
  if (!link || typeof link !== 'object') return null;
  if (link.dir === 'back') return CHAIN_WORDS.back;
  if (link.from) return `${CHAIN_WORDS.from} ${link.from}`;
  return CHAIN_WORDS[link.rel] || CHAIN_WORDS.order;
}
/** the labels of a chain (headings, links and counts, no statement): "Told in <section>" under a mention, "Continues from <chain>" in a title line
 *  with joins, the weakest link of the title line at research level, the shapes, the path of a section with two chains or more, the open fold's group */
export const CHAIN_LABELS = {
  told: 'Told in', continues: 'Continues from', weakest: 'Weakest link:', path: 'The chains of this section',
  open: { research: 'Chains whose weakest link is open', learner: 'Stories with a step not finished' },
  shape: { line: 'Line', fork: 'Fork', cycle: 'Cycle', ladder: 'Ladder' },
};
/** the computed statuses from the weakest to the strongest (LABELLING_SCHEME §6's badge priority): a chain's status is the weakest of its rows' (§2.1) */
export const CHAIN_STATUS_ORDER = ['open', 'cited', 'ours', 'input', 'standard', 'proved-by-atlas'];
/** question A60 for the owner: true keeps the badge "new" on a span exactly where the status has it (D56, badges unchanged: the default); false drops
 *  "new" inside a story only, which tests/coverage.test.mjs must then read too (the other badges, of what is not proved, always stay) */
export const STORY_NEW_BADGE = true;

/** the claim words of test T2 (docs/STORY_PLAN.md §1.4): a title holding one is a sentence, not a name (tests/story/composition.test.mjs) */
export const CLAIM_WORDS = ['prove', 'proves', 'proved', 'proof', 'theorem', 'lemma', 'equals', 'equivalent', 'iff', 'implies', 'unique', 'uniquely',
  'exactly', 'always', 'never', 'isomorphic', 'reduces to', 'is given by', 'holds', 'fails', 'vanishes', 'commutes', 'anticommutes', 'squares to', 'must', 'cannot'];
