// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Agents.jsx — `#/agents`, "For agents and researchers" (decision R7-9, BUILD_CONTRACTS interface 39, docs/round7/AI_TUNING.md): what the
// export tools/export_tuning.mjs writes to dist/content/tuning/ at every build, and how to read it. Sections, in this order at both levels:
//   The loop        the loop in five sentences (the same five as docs/round7/AI_TUNING.md; tests/export.test.mjs holds them equal)
//   The files       the download of each file with its records and size (the table `tuning/manifest`, written by the export)
//   One record      the record format in one table: the keys of rows.jsonl in their order, from the table `tuning/schema` (the schema.json that is
//                   downloaded), with the role each plays in the loop and, at research level, the table each comes from
//   Status words    the guide's words from content/persona_rules.md, as the Ask page shows them (a fold, open)
//   How to cite     the id in square brackets with its status word, and the address of the statement's page
// Every sentence is connective prose of 240 characters or fewer (data-connective) or a description of the schema; the page quotes no statement, so no
// row's words stand outside a Statement. The level changes the words, never the order. The two tables are loaded when the page opens, so the page
// is drawn at once without them (no numbers, no table rows) and again with them; the files are links to ./content/tuning/, which work from file:// too.
import { useSettings, useTable } from '../app/content.js';
import { statusLine } from '../app/personaRules.js';
import { BADGE_KINDS } from '../app/vocab.js';
import PageHeader from '../components/PageHeader.jsx';
import Badge from '../components/Badge.jsx';

/** the loop in five sentences: [name, research words, plain words]; the research sentences are those of docs/round7/AI_TUNING.md */
export const LOOP = [
  ['A record', 'One line',
    'Every statement of the Atlas is one record: its words (OUT₁), its label in the bit rule (IN₁), the known law it states (OUT₀), the check that ran on it, and what it rests on.',
    'Every statement in the Atlas is one line of a file: its words, a code that says which basic ideas it uses, the result it states, the tests that were run on it, and what it depends on.'],
  ['Words to label', 'Words to code',
    'A model reads a statement in the words of one field and gives its label: the notions the statement uses, written as a mask of 29 bits.',
    'A program reads the words of a statement and has to give its code: which of 29 basic ideas the statement uses.'],
  ['Label to law', 'Code to result',
    'From the label it should reach the known law, and say how far the Atlas has checked it: the last recorded run of the check is the probe.',
    'From the code it should reach the known result, and say how far the Atlas has tested it: the day the test last ran, and whether it passed.'],
  ['Lenses and chains', 'Other fields',
    'Lenses are the fields the model translates between; an equiv edge links two wordings of one statement, so the same result holds in both.',
    'The same idea can be told in the words of other fields. The files list how each field says it, and which statements say the same thing.'],
  ['Back to the model', 'Not a promise',
    'The Atlas gives the whole record back to the model (OUT₂). That is the aim of the tuning, not a result: an open or not-yet-proved mark means no theorem yet.',
    'The aim is a program that gets this right. It is not yet a result. A statement marked not finished or not yet proved here keeps that mark wherever it is quoted.'],
];

/** the words of the page that are not the loop: [research, plain] */
export const WORDS = {
  title: 'For agents and researchers',
  deck: ['The Atlas as a tuning set: every statement is one record, with its words, its label, its checks and what it rests on, written again with every build.',
    'The Atlas is also a set of files that a program can read. This page says what is in them and how to read them.'],
  loop: ['The loop', 'What the files are for'],
  loopLead: ['OUT₁, IN₁, OUT₀ and OUT₂ are the names of the sketch behind the files: the model\'s words, the label, the known law and what the Atlas gives back.',
    'The files follow a simple picture: words go in, a code comes out, and the known result is at the end.'],
  files: ['The files', 'The files'],
  filesLead: ['Written again with every build from the tables the pages print. Each file is one download; the README says how to read them.',
    'The files are made again each time the Atlas is built. Each one is a download; the README says how to read them.'],
  record: ['One record of rows.jsonl', 'One statement, one line'],
  recordLead: ['Every key is in every record, in this order. A key with nothing to say is empty or null.', 'Every line has the same parts, in this order. A part with nothing to say is empty.'],
  words: ['The status words', 'The marks'],
  wordsFold: ['The words, with the line the guide uses for each', 'Each mark, in plain words'],
  wordsLead: ['A program that quotes a statement quotes its status word with it; the guide never says more than the word does.', 'When a statement is quoted, its mark goes with it. The marks mean what these lines say, and no more.'],
  cite: ['How to cite a statement', 'How to point to a statement'],
  cite1: ['Cite a statement by its id in square brackets with its status word, as in [GRV-012]. The id never changes and is never reused.',
    'To point to a statement, write its name in brackets, as in [GRV-012], and say if it is marked not finished or not yet proved here.'],
  missing: ['The tuning files are not in this build: sh build.sh writes them to content/tuning/.', 'The files are not in this copy of the Atlas yet.'],
  cite2: ['A page shows the statement at #/<page>?at=<id>, for each page of shownOn. Cite the build by the versions in manifest.json.',
    'A page shows the statement at the address of the page followed by ?at= and the name. The versions of the files are in manifest.json.'],
  head: [['key', 'holds', 'role', 'comes from'], ['part', 'what it holds', 'what it is for']],
};
const pick = (pair, learner) => pair[learner ? 1 : 0];
const TUNING = 'content/tuning/';
const fmtBytes = n => (n >= 1048576 ? `${(n / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} kB`);
const fmtNum = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

function Section({ id, title, children }) {
  return (
    <section className="sec" id={`sec-${id}`} aria-labelledby={`h-${id}`} data-outline={title}>
      <h2 className="sec__title" id={`h-${id}`}>{title}</h2>
      {children}
    </section>
  );
}

/** the status words, each with its line from content/persona_rules.md at the current level (as the Ask page shows them) */
function StatusWords({ learner }) {
  const [rules] = useTable('persona_rules');
  const words = rules && Array.isArray(rules.statusWords) ? rules.statusWords : [];
  if (!words.length) return null;
  return (
    <details className="fold fold--words" id="status-words-fold" open>
      <summary className="fold__summary"><span className="fold__title">{pick(WORDS.wordsFold, learner)}</span></summary>
      <ul className="words">
        {words.map(w => (
          <li className="words__item" key={w.kind} data-kind={w.kind}>
            <span className="words__mark">
              {BADGE_KINDS.includes(w.kind) ? <Badge kind={w.kind} level={learner ? 'learner' : 'research'} /> : <span className="words__plain">{learner ? 'no mark' : w.word}</span>}
            </span>
            <span className="words__line" data-connective="persona" data-kind={w.kind}>{statusLine(w, learner ? 'learner' : 'research')}</span>
          </li>
        ))}
      </ul>
    </details>
  );
}

export default function Agents() {
  const s = useSettings();
  const learner = s.level === 'learner';
  const [schema, schemaError] = useTable('tuning/schema');
  const [manifest] = useTable('tuning/manifest');
  const files = schema && Array.isArray(schema['x-files']) ? schema['x-files'] : [];
  const sized = new Map(manifest && Array.isArray(manifest.files) ? manifest.files.map(f => [f.name, f]) : []);
  const row = schema && schema.definitions && schema.definitions.row ? schema.definitions.row.properties : null;
  const roles = schema && schema['x-roles'] ? schema['x-roles'] : {};
  const heading = { eyebrow: null, title: WORDS.title, deck: pick(WORDS.deck, learner) };
  const c = manifest && manifest.counts ? manifest.counts : null;
  const built = manifest && c
    ? `Built from ONE RULE ${manifest.appVersion}${manifest.contentVersion ? `, content ${manifest.contentVersion}` : ''}: ${learner
      ? `${fmtNum(c.rows)} statements, ${fmtNum(c.texts)} texts, ${fmtNum(c.readings)} readings, ${fmtNum(c.checks)} tests with ${fmtNum(c.runs)} recorded runs.`
      : `${fmtNum(c.rows)} records, ${fmtNum(c.texts)} texts, ${fmtNum(c.readings)} lens readings, ${fmtNum(c.checks)} check scripts with ${fmtNum(c.runs)} recorded runs.`}`
    : null;
  return (
    <article className="page page--agents" data-route="agents">
      <PageHeader route="agents" heading={heading} />
      <Section id="loop" title={pick(WORDS.loop, learner)}>
        <p className="sec__connective" data-connective="section">{pick(WORDS.loopLead, learner)}</p>
        <dl className="glossary agents__loop">
          {LOOP.map((x, i) => (
            <div className="glossary__entry" key={i} data-step={i + 1}>
              <dt className="glossary__term">{learner ? x[1] : x[0]}</dt>
              <dd className="glossary__def" data-connective="agents-loop">{learner ? x[3] : x[2]}</dd>
            </div>
          ))}
        </dl>
      </Section>
      <Section id="files" title={pick(WORDS.files, learner)}>
        <p className="sec__connective" data-connective="section">{pick(WORDS.filesLead, learner)}</p>
        {built ? <p className="sec__connective" data-connective="agents-build">{built}</p> : null}
        {!schema && schemaError ? <p className="sec__connective" data-connective="agents-missing">{pick(WORDS.missing, learner)}</p> : null}
        {files.length ? (
          <dl className="glossary agents__files">
            {files.map(f => {
              const m = sized.get(f.name);
              const note = m ? `${m.records != null ? `${fmtNum(m.records)} records · ` : ''}${fmtBytes(m.bytes)}` : null;
              return (
                <div className="glossary__entry" key={f.name} data-file={f.name}>
                  <dt className="glossary__term"><a href={`${TUNING}${f.name}`} download className="agents__file">{f.name}</a></dt>
                  <dd className="glossary__def" data-connective="agents-file">{learner ? f.plain : f.what}{note ? ` (${note})` : ''}</dd>
                </div>
              );
            })}
          </dl>
        ) : null}
      </Section>
      <Section id="record" title={pick(WORDS.record, learner)}>
        <p className="sec__connective" data-connective="section">{pick(WORDS.recordLead, learner)}</p>
        {row ? (
          <div className="table-scroll" tabIndex={0} role="region" aria-label={pick(WORDS.record, learner)}>
            <table className="dict agents__record">
              <thead><tr>{WORDS.head[learner ? 1 : 0].map(h => <th scope="col" key={h}>{h}</th>)}</tr></thead>
              <tbody>
                {Object.entries(row).map(([key, p]) => (
                  <tr key={key} data-key={key}>
                    <td><code>{key}</code></td>
                    <td data-connective="agents-field">{learner ? p['x-plain'] : p.description}</td>
                    <td>{learner ? (roles[p['x-role']] || {}).plain : (roles[p['x-role']] || {}).label}</td>
                    {learner ? null : <td><code>{p['x-from']}</code></td>}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : null}
      </Section>
      <Section id="status-words" title={pick(WORDS.words, learner)}>
        <p className="sec__connective" data-connective="section">{pick(WORDS.wordsLead, learner)}</p>
        <StatusWords learner={learner} />
      </Section>
      <Section id="cite" title={pick(WORDS.cite, learner)}>
        <p className="sec__connective" data-connective="section">{pick(WORDS.cite1, learner)}</p>
        <p className="sec__connective" data-connective="section">{pick(WORDS.cite2, learner)}</p>
      </Section>
    </article>
  );
}
