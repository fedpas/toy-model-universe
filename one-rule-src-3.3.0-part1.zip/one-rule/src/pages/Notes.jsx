// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Notes.jsx — `#/notes` and `#/notes/<key>`, the notes to researchers (content/notes.json, a shipped table of kind view, docs/02_CONTENT_MODEL.md §8
// and docs/06_PAGES.md §/notes): one note for each researcher whose work the Atlas read. A note is a view of the Atlas: it changes no row, and every count
// on these pages is read from the tables (statusOf) when the page is drawn.
//   #/notes          the file's title and line, then one card per note (NotesList, also the Logbook's Notes tab): "Note to <names>", the lead, the counts of
//                    the note's rows by status in the words of the badges ("16 statements of the Atlas come from this work: 12 proved by the Atlas, 3 our
//                    readings, 1 open"), and "Open →" to #/notes/<key>.
//   #/notes/<key>    the note: "Note to <names>" over the work line, the file's `about` line, then each section — its head, its paragraphs (plain text, one
//                    <p> each: they carry no data-row and are never read as statements), its rows as Statement cards (variant card, the row's badge, its id
//                    and "Open →" to the row's place, rowPlace of src/door/Comic.jsx; a row without a text at this level is left out), its figure (FigureFrame
//                    draws the app's figure by its id, nothing for an unknown id) or its svg (an <img> of a tutorial figure, "<course>/<file>.svg" at
//                    ./reports/tutorials/src/<course>/figs/<file>.svg, alt = the head), its links (a Link
//                    for `to`, with `at`; a plain <a> for `href`, a page outside the app) — then "A question", the thanks line, the fold "What the first letter
//                    said" when `earlier` is present (its date and paragraphs), and the closing line: this note is a view of the Atlas, with the version of the
//                    footer. The settings travel in every link; nothing here typesets a formula (a card's Statement does what it does on every page).
// The words of the page are WORDS below ([research, plain]); the level changes the words, never the order. No style sheet of its own: the cards are the
// leaf cards of src/styles/explore.css, the sections and folds those of components.css and story.css.
import { useSettings, useTable, textFor, statusOf } from '../app/content.js';
import { useRoute } from '../app/router.js';
import PageHeader from '../components/PageHeader.jsx';
import Statement from '../components/Statement.jsx';
import FigureFrame from '../components/FigureFrame.jsx';
import Link from '../components/Link.jsx';
import { ChevronDown } from '../components/Icons.jsx';
import { versionLine } from '../components/Footer.jsx';
import { rowPlace } from '../door/Comic.jsx';
import { STATUS_ORDER, statusCounts } from './Tutorials.jsx';
import NotFound from './NotFound.jsx';
import '../styles/explore.css';

/** the words of the pages: [research, plain] */
export const WORDS = {
  list: ['The notes', 'The notes'],
  to: ['Note to', 'Note to'],
  open: ['Open', 'Open'],
  from: [['statement of the Atlas comes from this work', 'statements of the Atlas come from this work'], ['statement of the Atlas comes from this work', 'statements of the Atlas come from this work']],
  none: ['No statement of the Atlas is listed for this work yet.', 'No statement of the Atlas is listed for this work yet.'],
  rows: ['Statements of the Atlas', 'Statements of the Atlas'],
  question: ['A question', 'A question'],
  earlier: ['What the first letter said', 'What the first letter said'],
  view: ['This note is a view of the Atlas: it changes no row, and its counts are those of the tables of this version.', 'This note is a view of the Atlas: it changes nothing in it, and its counts are read from this version of the tables.'],
  missing: ['The notes are not in this build.', 'The notes are not in this copy of the Atlas.'],
  noNote: ['No note has this key.', 'No note has this key.'],
  all: ['All the notes', 'All the notes'],
};
/** the status words of the counts, singular and plural, in the words of the badges (src/app/vocab.js BADGE_WORDS, plainer for a card): [research, plain] */
export const COUNT_WORDS = {
  'proved-by-atlas': [['proved by the Atlas', 'proved by the Atlas'], ['worked out by a computer', 'worked out by a computer']],
  standard: [['standard', 'standard'], ['from the textbooks', 'from the textbooks']],
  ours: [['our reading', 'our readings'], ['our idea', 'our ideas']],
  open: [['open', 'open'], ['not finished', 'not finished']],
  input: [['an input', 'inputs'], ['a choice we made', 'choices we made']],
  cited: [['not yet proved here', 'not yet proved here'], ['not yet worked out here', 'not yet worked out here']],
  meta: [['about the Atlas', 'about the Atlas'], ['about the Atlas', 'about the Atlas']],
};
const pick = (pair, learner) => pair[learner ? 1 : 0];
const names = note => (Array.isArray(note.to) ? note.to.filter(x => typeof x === 'string' && x.trim()) : []).join(', ');
const paragraphs = v => (Array.isArray(v) ? v.filter(x => typeof x === 'string' && x.trim()) : typeof v === 'string' && v.trim() ? [v] : []);
const rowIds = v => (Array.isArray(v) ? v.filter(x => typeof x === 'string' && x) : []);
const href = f => './' + String(f || '').replace(/^\.?\//, '');
/** a tutorial figure named "<course>/<file>.svg": its shipped path, ./reports/tutorials/src/<course>/figs/<file>.svg; null for anything else */
const svgFile = v => { const m = typeof v === 'string' ? /^([\w-]+)\/([\w-]+\.svg)$/.exec(v) : null; return m ? href(`reports/tutorials/src/${m[1]}/figs/${m[2]}`) : null; };

/** the counts sentence of a note: "<n> statements of the Atlas come from this work: <k> proved by the Atlas, …", from the tables through statusOf */
export function countsLine(rows, learner) {
  const ids = [...new Set(rowIds(rows))];
  if (!ids.length) return pick(WORDS.none, learner);
  const by = statusCounts(ids).map(([k, n]) => `${n} ${COUNT_WORDS[k] ? pick(COUNT_WORDS[k], learner)[n === 1 ? 0 : 1] : k}`);
  return `${ids.length} ${pick(WORDS.from, learner)[ids.length === 1 ? 0 : 1]}: ${by.join(', ')}`;
}

/** one card per note: the names, the lead, the counts, "Open →" to the note (the list of #/notes and of the Logbook's Notes tab) */
export function NotesList({ notes }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const list = (Array.isArray(notes) ? notes : []).filter(n => n && typeof n.key === 'string' && n.key);
  if (!list.length) return null;
  return (
    <ol className="leaf-grid notes-list">
      {list.map(n => (
        <li key={n.key} className="leaf-card note-card" data-note={n.key} data-rows={rowIds(n.rows).length}>
          <h3 className="leaf-card__title note-card__title">{`${pick(WORDS.to, learner)} ${names(n)}`}</h3>
          {n.lead ? <p className="leaf-card__quiet note-card__lead">{n.lead}</p> : null}
          <p className="leaf-card__start note-card__counts" data-counts={n.key}>{countsLine(n.rows, learner)}</p>
          <p className="note-card__way"><Link to={`notes/${n.key}`} className="btn note-card__open" aria-label={`${pick(WORDS.open, learner)}: ${pick(WORDS.to, learner)} ${names(n)}`}>{`${pick(WORDS.open, learner)} →`}</Link></p>
        </li>
      ))}
    </ol>
  );
}

/** a row of a note as a card: its id, its Statement (badge kept, no chevron) and "Open →" to its place; nothing when the row has no text at this level */
function RowCard({ id }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  if (textFor(id, { mode: s.mode, level: s.level, lens: s.lens }) == null) return null;
  const place = rowPlace(id);
  return (
    <li className="leaf-card note-row" data-row-card={id}>
      <p className="leaf-card__under"><code>{id}</code></p>
      <Statement id={id} variant="card" evidence={false} />
      {place ? <p className="note-card__way"><Link to={place.path} at={place.at} className="note-row__open" aria-label={`${pick(WORDS.open, learner)}: ${id}`}>{`${pick(WORDS.open, learner)} →`}</Link></p> : null}
    </li>
  );
}

function NoteLinks({ links }) {
  const list = (Array.isArray(links) ? links : []).filter(l => l && typeof l.label === 'string' && l.label && (typeof l.to === 'string' || typeof l.href === 'string'));
  if (!list.length) return null;
  return (
    <ul className="note-links">
      {list.map((l, i) => (
        <li key={i}>
          {typeof l.to === 'string' ? <Link to={l.to} at={l.at || undefined}>{l.label}</Link> : <a href={href(l.href)} target="_blank" rel="noopener">{l.label}</a>}
        </li>
      ))}
    </ul>
  );
}

function NoteSection({ sec, i, learner }) {
  const rows = [...new Set(rowIds(sec.rows))];
  const head = typeof sec.head === 'string' ? sec.head : '';
  return (
    <section className="sec note-sec" id={`sec-note-${i + 1}`} aria-labelledby={`h-note-${i + 1}`} data-outline={head || undefined}>
      {head ? <h2 className="sec__title" id={`h-note-${i + 1}`}>{head}</h2> : null}
      {paragraphs(sec.text).map((t, k) => <p key={k} className="note__p">{t}</p>)}
      {rows.length ? <ul className="leaf-grid note-rows" aria-label={pick(WORDS.rows, learner)}>{rows.map(id => <RowCard key={id} id={id} />)}</ul> : null}
      {typeof sec.figure === 'string' && sec.figure ? <FigureFrame id={sec.figure} /> : null}
      {svgFile(sec.svg) ? <figure className="note__svg"><img src={svgFile(sec.svg)} alt={head} /></figure> : null}
      <NoteLinks links={sec.links} />
    </section>
  );
}

function Note({ note, title, about }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const [ver] = useTable('version');
  const heading = { eyebrow: title || null, title: `${pick(WORDS.to, learner)} ${names(note)}`, deck: typeof note.work === 'string' ? note.work : null };
  const sections = Array.isArray(note.sections) ? note.sections.filter(x => x && typeof x === 'object') : [];
  const earlier = note.earlier && typeof note.earlier === 'object' ? note.earlier : null;
  return (
    <article className="page page--note" data-route={`notes/${note.key}`} data-note={note.key}>
      <PageHeader route="notes" heading={heading} needs={[]} />
      {about ? <p className="note__about">{about}</p> : null}
      {sections.map((sec, i) => <NoteSection key={i} sec={sec} i={i} learner={learner} />)}
      {typeof note.question === 'string' && note.question ? (
        <section className="sec note-sec note-question" id="sec-question" aria-labelledby="h-question" data-outline={pick(WORDS.question, learner)}>
          <h2 className="sec__title" id="h-question">{pick(WORDS.question, learner)}</h2>
          <p className="note__p">{note.question}</p>
        </section>
      ) : null}
      {typeof note.thanks === 'string' && note.thanks ? <p className="note__thanks">{note.thanks}</p> : null}
      {earlier && paragraphs(earlier.text).length ? (
        <details className="more more--reference note__earlier" id="sec-earlier" data-fold="reference">
          <summary className="more__summary"><span className="more__caret" aria-hidden="true"><ChevronDown /></span><span className="more__label">{pick(WORDS.earlier, learner)}</span></summary>
          <div className="more__body">
            {typeof earlier.date === 'string' && earlier.date ? <p className="note__date"><time>{earlier.date}</time></p> : null}
            {paragraphs(earlier.text).map((t, k) => <p key={k} className="note__p">{t}</p>)}
          </div>
        </details>
      ) : null}
      <p className="note__view" data-connective="note-view">{`${pick(WORDS.view, learner)} ${versionLine(ver)}`}</p>
      <p className="note__all"><Link to="notes" className="btn">{pick(WORDS.all, learner)}</Link></p>
    </article>
  );
}

export default function Notes({ noteKey = null }) {
  const s = useSettings();
  const learner = s.level === 'learner';
  const route = useRoute();
  const key = noteKey != null ? noteKey : (route.match && route.match.name === 'note' ? route.match.key : null);
  const [table, error] = useTable('notes');
  const file = table && typeof table === 'object' && !Array.isArray(table) ? table : null;
  const notes = file && Array.isArray(file.notes) ? file.notes.filter(n => n && typeof n.key === 'string' && n.key) : [];
  if (key != null) {
    if (!file && !error) return <article className="page page--note" data-route={`notes/${key}`} aria-busy="true" />;
    const note = notes.find(n => n.key === key);
    if (!note) return <NotFound />;
    return <Note note={note} title={typeof file.title === 'string' ? file.title : null} about={typeof file.about === 'string' ? file.about : null} />;
  }
  const heading = { eyebrow: null, title: (file && typeof file.title === 'string' && file.title) || 'Notes to researchers', deck: file && typeof file.line === 'string' ? file.line : null };
  return (
    <article className="page page--notes" data-route="notes">
      <PageHeader route="notes" heading={heading} needs={[]} />
      <section className="sec" id="sec-notes" aria-labelledby="h-notes" data-outline={pick(WORDS.list, learner)}>
        <h2 className="sec__title" id="h-notes">{pick(WORDS.list, learner)}</h2>
        {!file && error ? <p className="sec__connective" data-connective="notes-missing">{pick(WORDS.missing, learner)}</p> : null}
        <NotesList notes={notes} />
      </section>
    </article>
  );
}
