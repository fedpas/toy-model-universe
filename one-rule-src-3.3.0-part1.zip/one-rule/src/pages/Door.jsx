// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Door.jsx — `#/`, the door ("Start here"; docs/round7/PLAN.md R7-2, §4 ARCH item 3, interface 36: .door .door-hero .door-cards .door-card
// .door-card-icon .door-card-n .door-shelf .door-chapters .door-atlas .door-door), laid out as Octavo's home: the mark (the name "Atlas" and its
// subtitle "one rule") and the line beside the door's picture, a tiny graphic novel (src/door/Comic.jsx, .door-comic): panels in which one figure asks
// "What is the One Rule?" and the other answers for one field, each answer a row of the Atlas drawn by Statement, each panel with "Open →" to that
// row's place; the door draws no leaf figure (the clock lives at the top of its page, #/clock). "Eight ways in" — the path of eight leaves of
// content/explore/registry.json, each card with the leaf's picture, its number, its name, its line (the hero row of the leaf: the caption row of its
// figure, in the short register where the row has one at this level; a leaf not drawn yet has no line) and "Open →" to the leaf's place on its Atlas
// page (its page at its anchor: at=top, the page top, or at=<section>); a leaf not drawn yet says "coming" and opens its page anyway; "On the shelf" —
// the drawn shelf leaves, each "hangs under n"; "The Atlas, chapter by chapter" — one card per main page of content/story/landing.json, its title and
// its lead story row (else its hero row); then the start page of the full Atlas, merged here (#sec-atlas, where `#/atlas` lands): the rule in one
// screen — the rows of the page record `atlas` of pages.json, drawn as its page model places them (the learner paragraph, the hero, the rows at a
// glance, "More statements"), each by Statement at the reader's level and mode — and the stats (src/components/StageCards.jsx: the stage cards with
// their counts of statements proved by the Atlas and of open items, the calibrations, the links to the steps, the cells and the lenses), ending with
// the record of that page (PageRecord: the fold and the download, content/records/atlas.json); last, the closing strip: the way to the twenty steps
// (#/steps), with the guide for agents (#/agents), the tutorials (#/tutorials) and the notes to researchers (#/notes) beside it. A first visit opens
// at learner level (src/app/settings.js). Every sentence is a row (Statement); the words of this file and of content/story/door.json are names and
// directions. An address with at=<part> (atlas, stages, shelf, …) or at=<row of the start page> brings that place into view.
import { useEffect, useMemo, useState } from 'react';
import { useSettings, textFor } from '../app/content.js';
import { pageTitle, pageLead, visibleIn, buildPageModel } from '../app/queries.js';
import { ATLAS_AT, atlasPage, landingChapters, leafPlace, matchRoute, useRoute } from '../app/router.js';
import { pagesByRoute, rowsById } from '../app/store.js';
import Link from '../components/Link.jsx';
import Statement from '../components/Statement.jsx';
import Hero from '../components/Hero.jsx';
import Lead from '../components/Lead.jsx';
import MoreFold from '../components/MoreFold.jsx';
import PageRecord from '../components/PageRecord.jsx';
import StageCards from '../components/StageCards.jsx';
import LeafIcon, { DoorMark, IconLock } from '../components/LeafIcons.jsx';
import { pathLeaves, shelfLeaves, leafRow, leafName, pathLeaf, isDrawn } from '../components/LeafPath.jsx';
import Comic from '../door/Comic.jsx';
import { registerOf } from '../components/LeafNotes.jsx';
import WORDS from '../../content/story/door.json';
import '../styles/explore.css';
import '../styles/door.css';

const W = WORDS && typeof WORDS === 'object' ? WORDS : {};
const word = (k, sub, fallback) => (sub ? (W[k] && W[k][sub]) : W[k]) || fallback;

// ---------------------------------------------------------------- the chapter cards (STORY_PLAN §2.7, interface 27: pageLead)
const hasText = (id, s, register) => textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register }) != null;
/**
 * The row a chapter card shows, its register and where it comes from: the page's lead story row, from pageLead(route, settings) (interface
 * 27: { id, register } — the short register where the row has one at this level). A page without a lead shows its hero row instead, in the same
 * registers; a hero row the mode does not show, or without a text at this level, leaves the card with its title alone.
 */
export function chapterRow(route, s) {
  const lead = pageLead(route, s);
  if (lead && lead.id) return { id: lead.id, register: lead.register || 'full', source: 'lead' };
  const def = pagesByRoute()?.get(route);
  const id = def && def.hero ? def.hero.row : null;
  const row = id ? rowsById()?.get(id) : null;
  if (!row || !visibleIn(row, s.mode)) return null;
  const register = hasText(id, s, 'short') ? 'short' : 'full';
  return hasText(id, s, register) ? { id, register, source: 'hero' } : null;
}

function ChapterCard({ route }) {
  const s = useSettings();
  const row = pagesByRoute()?.has(route) ? chapterRow(route, s) : null;
  return (
    <li className="door-card door-card--chapter leaf-card leaf-card--chapter" data-chapter={route} data-source={row ? row.source : undefined}>
      <h3 className="door-card__title leaf-card__title"><Link to={route} className="door-card__link leaf-card__link">{pageTitle(route, s)}</Link></h3>
      {row ? <Statement id={row.id} register={row.register} variant="card" evidence={false} /> : null}
    </li>
  );
}

// ---------------------------------------------------------------- the leaves
/** a card of the path or the shelf: picture, number (path) or the leaf it hangs under (shelf), name, line, the way to its place */
function LeafCard({ entry }) {
  const s = useSettings();
  const drawn = isDrawn(entry);
  const row = leafRow(entry);
  const place = leafPlace(entry);
  const reachable = !!(place.path != null && pagesByRoute()?.has(place.path));
  const shelf = entry.kind === 'shelf';
  const under = shelf && entry.under ? pathLeaf(entry.under) : null;
  const shown = row && hasText(row, s, registerOf(row, s)) && visibleIn(rowsById()?.get(row) || {}, s.mode);
  return (
    <li className={`door-card door-card--${entry.kind}${drawn ? '' : ' is-coming'}`} data-leaf={entry.slug} data-page={reachable ? place.path : undefined} data-anchor={reachable ? place.at : undefined}>
      <span className="door-card-icon"><LeafIcon slug={entry.slug} size={shelf ? 48 : 64} /></span>
      {entry.kind === 'path' ? <span className="door-card-n" aria-hidden="true">{entry.n}</span> : null}
      {under ? <span className="door-card-under"><span>{word('shelf', 'under', 'hangs under')}</span>{' '}<span className="door-card-n">{under.n}</span><span className="vh">{`, ${leafName(under)}`}</span></span> : null}
      <h3 className="door-card__title">{leafName(entry)}</h3>
      {!drawn ? <p className="door-card__coming">{word('coming', null, 'coming')}</p> : null}
      {shown ? <Statement id={row} register={registerOf(row, s)} variant="card" evidence={false} /> : null}
      {reachable ? <Link to={place.path} at={place.at} className="door-card__open" aria-label={`${word('open', null, 'Open')}: ${leafName(entry)}`}>{`${word('open', null, 'Open')} →`}</Link> : null}
    </li>
  );
}

// ---------------------------------------------------------------- the start page of the full Atlas, merged into the door (the page record `atlas`)
/**
 * The rule in one screen and the stats (#sec-atlas, where `#/atlas` lands): the rows of the start page's record as its page model places them — the
 * learner paragraphs of its intro (learner level), its hero (Hero: the statement and, at learner level, the "How do we know?" line), the rows at a
 * glance, the other rows in "More statements" — then the stage cards (StageCards, #sec-stages) and the record of that page (PageRecord). The counts
 * are the tables' (research level); the words of the heading and the line are door.json's `atlas`. Nothing is drawn when the tables hold no such page.
 */
function AtlasPart({ at }) {
  const s = useSettings();
  const route = atlasPage();
  const model = useMemo(() => (pagesByRoute()?.has(route) ? buildPageModel(route, s) : null), [route, s.mode, s.level, s.lens]); // eslint-disable-line react-hooks/exhaustive-deps
  const more = (model && model.intro && model.intro.more) || [];
  const [moreOpen, setMoreOpen] = useState(false);
  // a deep link to a row of the fold opens it
  useEffect(() => { if (at && more.includes(at)) setMoreOpen(true); }, [at, more.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!model) return null;
  const intro = model.intro || {};
  return (
    <section className="door-atlas" id={`sec-${ATLAS_AT}`} aria-labelledby="h-atlas-part" data-outline={word('atlas', 'title', 'The rule in one screen')} data-page={route}>
      <h2 className="door-cards__title" id="h-atlas-part">{word('atlas', 'title', 'The rule in one screen')}</h2>
      <p className="door-cards__line" data-connective="door">{word('atlas', 'line', '')}</p>
      <div className="door-atlas__rows">
        {(intro.learnerRows || []).map(id => <Lead key={id} id={id} variant="intro-more" />)}
        <Hero hero={model.hero} />
        {(intro.glance || []).length ? <div className="door-atlas__glance">{intro.glance.map(id => <Statement key={id} id={id} evidence={false} />)}</div> : null}
        <MoreFold rows={more} id="more-atlas" open={moreOpen} onToggle={setMoreOpen} />
      </div>
      <StageCards heading="h3" />
      <PageRecord route={route} />
    </section>
  );
}

// ---------------------------------------------------------------- where a part of the door lands (at=<part>: `#/atlas`, "See the shelf")
/** the gap between the sticky bar and the top of a part brought into view */
const PART_GAP = 12;
/** the bottom edge of the sticky bar (src/components/Shell.jsx, header.shell) while it holds the top of the window, else 0 */
function barBottom() {
  const bar = document.querySelector('header.shell');
  if (!bar) return 0;
  const r = bar.getBoundingClientRect();
  return r.top <= 1 ? Math.max(0, r.bottom) : 0;
}
/**
 * A part of the door brought into view lands with its top PART_GAP under the sticky bar, measured at the moment (the bar is 57 px tall at 1366 px
 * and 95 px at 390 px). scrollIntoView({ block: 'start' }) stacked the root's scroll-padding-top (120 px, src/styles/base.css, for the statements of a
 * page) on the part's own scroll-margin-top (72 px, door.css): `#/atlas` landed 192 px down at every width (round 15).
 */
function landPart(el) {
  const top = el.getBoundingClientRect().top + window.scrollY - barBottom() - PART_GAP;
  window.scrollTo({ top: Math.max(0, Math.round(top)), behavior: 'instant' });
}

/** a page the router knows that is not a page of pages.json (the guide for agents, the tutorials, the notes, once their routes exist) */
const routeKnown = r => !!r && !['notfound', 'redirect'].includes(matchRoute(r).name) && !matchRoute(r).redirect;
/** the way of door.json's entry k (route and title), when the router knows its route */
const wayOf = k => (W[k] && typeof W[k] === 'object' && routeKnown(W[k].route) ? W[k] : null);

export default function Door() {
  const route = useRoute();
  const path = pathLeaves(), shelf = shelfLeaves().filter(isDrawn), chapters = landingChapters();
  const first = path.find(isDrawn) || null;
  // at=<part> (the button "See the shelf", an old link to the Explore home's shelf, the address of the merged start page) brings that part into view
  // just under the sticky bar (landPart); at=<row> of the start page brings its statement into view with the statements' own margins
  useEffect(() => {
    if (!route.at || typeof document === 'undefined') return undefined;
    const t = setTimeout(() => {
      const part = document.getElementById(`sec-${route.at}`);
      if (part) { landPart(part); return; }
      const row = document.getElementById(`row-${route.at}`);
      if (row) row.scrollIntoView({ block: 'start' });
    }, 30);
    return () => clearTimeout(t);
  }, [route.at]);
  const onward = wayOf('door'), agents = wayOf('agents'), tutorials = wayOf('tutorials'), notes = wayOf('notes');
  return (
    <article className="page door" data-route="" aria-labelledby="page-title">
      <section className="door-hero" id="sec-door">
        <div className="door-hero__text">
          <p className="door-hero__mark"><DoorMark size={30} /><span className="door-hero__name">{word('title', null, 'Atlas')}</span><span className="door-hero__sub">{word('subtitle', null, 'one rule')}</span></p>
          <h1 className="door-hero__line" id="page-title">{word('line', null, 'Eight ways into the Atlas.')}</h1>
          <p className="door-hero__actions">
            {first ? <Link to={leafPlace(first).path} at={leafPlace(first).at} className="btn btn--primary door-begin">{`${word('begin', null, 'Begin with the clock')} →`}</Link> : null}
            {shelf.length ? <Link to="" at="shelf" className="btn btn--ghost door-see-shelf">{word('seeShelf', null, 'See the shelf')}</Link> : null}
          </p>
        </div>
        <Comic words={W.comic} />
      </section>

      <section className="door-cards" id="sec-path" aria-labelledby="h-path" data-outline={word('path', 'title', 'Eight ways in')}>
        <h2 className="door-cards__title" id="h-path">{word('path', 'title', 'Eight ways in')}</h2>
        <p className="door-cards__line" data-connective="door">{word('path', 'line', '')}</p>
        <ol className="door-cards__list">{path.map(e => <LeafCard key={e.slug} entry={e} />)}</ol>
      </section>

      {shelf.length ? (
        <section className="door-shelf" id="sec-shelf" aria-labelledby="h-shelf" data-outline={word('shelf', 'title', 'On the shelf')}>
          <h2 className="door-cards__title" id="h-shelf">{word('shelf', 'title', 'On the shelf')}</h2>
          <p className="door-cards__line" data-connective="door">{word('shelf', 'line', '')}</p>
          <ul className="door-cards__list door-cards__list--shelf">{shelf.map(e => <LeafCard key={e.slug} entry={e} />)}</ul>
        </section>
      ) : null}

      {chapters.length ? (
        <section className="door-chapters" id="sec-chapters" aria-labelledby="h-chapters" data-outline={word('chapters', 'title', 'The Atlas, chapter by chapter')}>
          <h2 className="door-cards__title" id="h-chapters">{word('chapters', 'title', 'The Atlas, chapter by chapter')}</h2>
          <p className="door-cards__line" data-connective="door">{word('chapters', 'line', '')}</p>
          <ol className="door-cards__list door-cards__list--chapters leaf-grid leaf-grid--chapters">{chapters.map(r => <ChapterCard key={r} route={r} />)}</ol>
        </section>
      ) : null}

      <AtlasPart at={route.at} />

      {onward ? (
        <nav className="door-door" id="sec-onward" aria-labelledby="h-onward">
          <span className="door-door__icon"><IconLock size={30} /></span>
          <h2 className="door-door__title" id="h-onward">{onward.title}</h2>
          <Link to={onward.route} className="btn btn--primary door-door__open">{`${onward.open || word('open', null, 'Open')} →`}</Link>
          {agents || tutorials || notes ? (
            <div className="door-door__ways">
              {agents ? <Link to={agents.route} className="btn btn--ghost door-door__agents">{agents.title}</Link> : null}
              {tutorials ? <Link to={tutorials.route} className="btn btn--ghost door-door__tutorials">{tutorials.title}</Link> : null}
              {notes ? <Link to={notes.route} className="btn btn--ghost door-door__notes">{notes.title}</Link> : null}
            </div>
          ) : null}
        </nav>
      ) : null}
    </article>
  );
}
