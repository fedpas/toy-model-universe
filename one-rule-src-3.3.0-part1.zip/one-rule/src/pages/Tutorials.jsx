// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/pages/Tutorials.jsx — `#/tutorials`, the tutorials of the Atlas (docs/06_PAGES.md, docs/round8/TUTORIALS.md), a static page in the shape of
// src/pages/Agents.jsx: the page header, a lead line, then one card per entry of content/tutorials.json (the registry that
// tools/tutorials/registry.mjs fills from the sources) in the order of the registry, and last the tutorial of the Logbook's Reports tab
// (content/reports.json, id "tutorial"), the four courses in one page. A card shows the tutorial's part, title, line and readers, its counts
// (figures, widgets, the rows it cites by their status, computed from content/derived/status.json through the store, and the checks it cites) and a
// link that opens the self-contained page (./reports/tutorials/<name>.html, in a new tab, as the Reports tab links a report). The words of the page
// are WORDS below ([research, plain]; the level changes the words, never the order), each at most 240 characters; the cards quote no row's words.
// The registry and the reports table load when the page opens, so the page is drawn at once without them (the header and the lead) and again with them.
// No style sheet of its own: the cards are the leaf cards of src/styles/explore.css (.leaf-grid, .leaf-card) and the chips of components.css.
import { useSettings, useTable, statusOf } from '../app/content.js';
import PageHeader from '../components/PageHeader.jsx';
import '../styles/explore.css';

/** the words of the page: [research, plain] */
export const WORDS = {
  title: 'Tutorials',
  deck: ['Courses taught through the Atlas’s own objects: the rule, the cells, the clock, the lattices. Every statement a tutorial makes names its row, and every number comes from a log.',
    'Lessons that teach a subject with the pieces of the Atlas. Each one is a page of its own, with pictures and boxes to play with.'],
  list: ['The tutorials', 'The lessons'],
  lead: ['One card per tutorial, in the order of the course. Each opens a self-contained page in a new tab; its ids link back to their places here, with their status.',
    'One card per lesson, in order. Each opens a page of its own in a new tab.'],
  part: ['Part', 'Part'],
  readers: ['For', 'For'],
  open: ['Open the tutorial', 'Open the lesson'],
  newTab: ['opens in a new tab', 'opens in a new tab'],
  figures: [['figure', 'figures'], ['picture', 'pictures']],
  widgets: [['widget', 'widgets'], ['box to play with', 'boxes to play with']],
  rows: [['row cited', 'rows cited'], ['statement of the Atlas', 'statements of the Atlas']],
  checks: [['check cited', 'checks cited'], ['test of the Atlas', 'tests of the Atlas']],
  byStatus: ['By status', 'How far each one is known'],
  oldPart: ['The four courses in one page', 'The four courses on one page'],
  oldLine: ['All the courses in one long page: the rule from zero, then geometry, algebra, category theory and topology, coding with the rule, and a closing table.',
    'Four subjects and some coding, on one long page.'],
  how: ['How a tutorial is made', 'How a lesson is made'],
  how1: ['Each tutorial is a markdown source rendered to one page by tools/make_tutorial.mjs, its figures drawn by a script from the Atlas’s objects and its widgets recomputed in the page.',
    'Each lesson is a text turned into one page. Its pictures are drawn by a program from the pieces of the Atlas, and its boxes do the sums in your browser.'],
  how2: ['A row id on a tutorial page links to the row’s place in the Atlas and carries its status; a widget checks its own rule against stored products before it draws.',
    'The name of a statement on a lesson page leads back to its place in the Atlas. A box tests itself before it draws.'],
  missing: ['The list of tutorials is not in this build.', 'The list of lessons is not in this copy of the Atlas.'],
};
/** the status words of the counts, in their order: [research, plain] (the badge words of src/app/vocab.js and content/persona_rules.md, plainer for a card) */
export const STATUS_ORDER = ['proved-by-atlas', 'standard', 'ours', 'open', 'input', 'cited', 'meta'];
export const STATUS_WORDS = {
  'proved-by-atlas': ['proved by the Atlas', 'worked out by a computer'],
  standard: ['standard', 'from the textbooks'],
  ours: ['our reading', 'our idea'],
  open: ['open', 'not finished'],
  input: ['an input', 'a choice we made'],
  cited: ['not yet proved here', 'not yet worked out here'],
  meta: ['about the Atlas', 'about the Atlas'],
};
const pick = (pair, learner) => pair[learner ? 1 : 0];
const count = (n, pair, learner) => `${n} ${pick(pair, learner)[n === 1 ? 0 : 1]}`;
const href = f => './' + String(f || '').replace(/^\.?\//, '');

/** the rows an entry cites, counted by their status (derived/status.json through the store): [[status, n], …] in STATUS_ORDER */
export function statusCounts(rows) {
  const n = {};
  for (const id of Array.isArray(rows) ? rows : []) { const s = (statusOf(id) || {}).status || 'unknown'; n[s] = (n[s] || 0) + 1; }
  return [...STATUS_ORDER, ...Object.keys(n).filter(k => !STATUS_ORDER.includes(k)).sort()].filter(k => n[k]).map(k => [k, n[k]]);
}

function TutorialCard({ entry, learner }) {
  const rows = Array.isArray(entry.rows) ? entry.rows : [], widgets = Array.isArray(entry.widgets) ? entry.widgets : [], checks = Array.isArray(entry.checks) ? entry.checks : [];
  const figures = Number.isFinite(entry.figures) ? entry.figures : 0;
  const by = statusCounts(rows);
  const counts = [count(figures, WORDS.figures, learner), count(widgets.length, WORDS.widgets, learner), count(rows.length, WORDS.rows, learner), count(checks.length, WORDS.checks, learner)].join(' · ');
  return (
    <li className="leaf-card tut-card" data-tutorial={entry.id} data-part={entry.part} data-figures={figures} data-widgets={widgets.length} data-rows={rows.length} data-checks={checks.length}>
      <p className="leaf-card__under tut-card__part">{`${pick(WORDS.part, learner)} ${entry.part}`}</p>
      <h3 className="leaf-card__title tut-card__title">{entry.title}</h3>
      {entry.line ? <p className="tut-card__line" data-connective="tutorial-line">{entry.line}</p> : null}
      {entry.readers ? <p className="leaf-card__quiet tut-card__readers" data-connective="tutorial-readers"><strong>{`${pick(WORDS.readers, learner)}: `}</strong>{entry.readers}</p> : null}
      <p className="leaf-card__start tut-card__counts" data-connective="tutorial-counts">{counts}</p>
      {by.length ? (
        <ul className="chips tut-card__status" aria-label={pick(WORDS.byStatus, learner)}>
          {by.map(([k, n]) => <li key={k} className="chip" data-status={k} data-n={n}>{`${n} ${STATUS_WORDS[k] ? pick(STATUS_WORDS[k], learner) : k}`}</li>)}
        </ul>
      ) : null}
      {entry.html ? (
        <p className="tut-card__way"><a className="btn tut-card__open" href={href(entry.html)} target="_blank" rel="noopener" aria-label={`${pick(WORDS.open, learner)}: ${entry.title} (${pick(WORDS.newTab, learner)})`}>{`${pick(WORDS.open, learner)} →`}</a></p>
      ) : null}
    </li>
  );
}

/** the tutorial of the Logbook's Reports tab (content/reports.json, id "tutorial"): the four courses in one page, last */
function OldCard({ report, learner }) {
  if (!report || !report.file) return null;
  return (
    <li className="leaf-card is-quiet tut-card tut-card--old" data-tutorial="tutorial" data-report={report.id}>
      <p className="leaf-card__under tut-card__part">{pick(WORDS.oldPart, learner)}</p>
      <h3 className="leaf-card__title tut-card__title">{report.title}</h3>
      <p className="tut-card__line" data-connective="tutorial-line">{pick(WORDS.oldLine, learner)}</p>
      <p className="tut-card__way"><a className="btn tut-card__open" href={href(report.file)} target="_blank" rel="noopener" aria-label={`${pick(WORDS.open, learner)}: ${report.title} (${pick(WORDS.newTab, learner)})`}>{`${pick(WORDS.open, learner)} →`}</a></p>
    </li>
  );
}

export default function Tutorials() {
  const s = useSettings();
  const learner = s.level === 'learner';
  const [registry, error] = useTable('tutorials');
  const [reports] = useTable('reports');
  const entries = Array.isArray(registry) ? registry.filter(e => e && e.id && e.title) : [];
  const old = Array.isArray(reports) ? reports.find(r => r && r.id === 'tutorial') : null;
  const heading = { eyebrow: null, title: WORDS.title, deck: pick(WORDS.deck, learner) };
  return (
    <article className="page page--tutorials" data-route="tutorials">
      <PageHeader route="tutorials" heading={heading} />
      <section className="sec" id="sec-list" aria-labelledby="h-list" data-outline={pick(WORDS.list, learner)}>
        <h2 className="sec__title" id="h-list">{pick(WORDS.list, learner)}</h2>
        <p className="sec__connective" data-connective="section">{pick(WORDS.lead, learner)}</p>
        {!registry && error ? <p className="sec__connective" data-connective="tutorials-missing">{pick(WORDS.missing, learner)}</p> : null}
        {entries.length || old ? (
          <ol className="leaf-grid tut-list">
            {entries.map(e => <TutorialCard key={e.id} entry={e} learner={learner} />)}
            <OldCard report={old} learner={learner} />
          </ol>
        ) : null}
      </section>
      <section className="sec" id="sec-how" aria-labelledby="h-how" data-outline={pick(WORDS.how, learner)}>
        <h2 className="sec__title" id="h-how">{pick(WORDS.how, learner)}</h2>
        <p className="sec__connective" data-connective="section">{pick(WORDS.how1, learner)}</p>
        <p className="sec__connective" data-connective="section">{pick(WORDS.how2, learner)}</p>
      </section>
    </article>
  );
}
