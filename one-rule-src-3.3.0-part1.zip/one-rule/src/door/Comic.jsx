// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/door/Comic.jsx — the door's picture (#/, src/pages/Door.jsx): a tiny graphic novel. In each panel the visitor, a round head with a question
// mark, asks "What is the One Rule?", and the guide, a square head with a small lamp, answers for one field ("If you like counting, it's this:").
// Every answer is a row of the Atlas, drawn by Statement at the reader's level and mode (learner level: the short register where the row has one,
// else its full learner text; research level: its research text); the question, the leads and the controls are the words of
// content/story/door.json (comic): names and directions. Each panel ends with "Open →" to the row's place, the settings kept: the place of the drawn
// leaf whose figure the row captions (leafPlace), else the row's home page at the row (rowHome). A panel whose row has no text at this level and in
// this mode, or no place, is left out. Classes: .door-comic (the strip) .door-comic__panel (li, .is-current) .door-comic__ask .door-comic__say
// .door-comic__lead .door-comic__open .door-comic__nav .door-comic__tick; the two figures are inline SVG drawn in the tokens; the styles are
// src/styles/door.css.
// Motion is CSS keyframes only: the current panel slides and fades in; its dot fills in 5 s, and the end of that fill turns the strip to the next
// panel (the strip's only clock); hover, focus and the pause button stop the fill; previous, next and a dot per panel turn it by hand; the current
// panel's lead is read out (aria-live polite) whenever the strip is not turning by itself. Under prefers-reduced-motion every panel is shown at
// once, a static strip with no controls.
import { useState } from 'react';
import { useSettings, textFor } from '../app/content.js';
import { pageTitle, rowHome, visibleIn } from '../app/queries.js';
import { leafPlace } from '../app/router.js';
import { pagesByRoute, rowsById } from '../app/store.js';
import Link from '../components/Link.jsx';
import Statement from '../components/Statement.jsx';
import { pathLeaves, shelfLeaves, leafRow, isDrawn } from '../components/LeafPath.jsx';
import { registerOf } from '../components/LeafNotes.jsx';

/** where a panel's "Open →" leads: the place of the drawn leaf whose figure the row captions, else the row's home page at the row; null off the Atlas */
export function rowPlace(id) {
  const leaf = [...pathLeaves(), ...shelfLeaves()].find(e => isDrawn(e) && leafRow(e) === id);
  if (leaf) return { ...leafPlace(leaf), leaf: leaf.slug };
  const home = rowHome(id);
  return home && pagesByRoute()?.has(home.path) ? { path: home.path, at: home.at, leaf: null } : null;
}

/** the panels drawn at the settings s: those of door.json whose row the mode shows, with a text at this level and a place on a page of the Atlas */
export function comicPanels(words, s) {
  const rows = rowsById();
  return (words && Array.isArray(words.panels) ? words.panels : []).map(p => {
    const row = p && rows ? rows.get(p.row) : null;
    if (!row || !visibleIn(row, s.mode)) return null;
    const register = registerOf(row.id, s);
    if (textFor(row.id, { mode: s.mode, level: s.level, lens: s.lens, register }) == null) return null;
    const place = rowPlace(row.id);
    return place ? { ...p, register, place } : null;
  }).filter(Boolean);
}

// the two figures: ink lines, the visitor's head in the turn's colour, the guide's in the boost's, both standing on the slide's bar; the guide's lamp is lit (--hi)
const INK = { fill: 'none', stroke: 'var(--fg)', strokeWidth: 2.5, strokeLinecap: 'round', strokeLinejoin: 'round' };
const DOT = { fill: 'var(--fg)' };
const FLOOR = { ...INK, stroke: 'var(--slide)', strokeWidth: 3 };
const Visitor = () => (
  <svg className="door-comic__visitor" viewBox="0 0 80 100" aria-hidden="true" focusable="false">
    <path className="door-comic__floor" d="M8 96 H72" style={FLOOR} />
    <path d="M18 94 C18 75 25 67 36 67 C47 67 54 75 54 94 M51 75 L64 59" style={INK} />
    <circle className="door-comic__head" cx="35" cy="40" r="19" style={{ fill: 'var(--panel)', stroke: 'var(--turn)', strokeWidth: 3 }} />
    <circle cx="33" cy="37" r="2.3" style={DOT} /><circle cx="44" cy="37" r="2.3" style={DOT} />
    <circle cx="40" cy="48" r="2.6" style={{ ...INK, strokeWidth: 2 }} />
    <path d="M60 11 C60 5 72 5 72 11 C72 16 66 16 66 22" style={{ ...INK, stroke: 'var(--turn)', strokeWidth: 3 }} />
    <circle cx="66" cy="29" r="2.2" style={{ fill: 'var(--turn)' }} />
  </svg>
);
const Guide = () => (
  <svg className="door-comic__guide" viewBox="0 0 80 100" aria-hidden="true" focusable="false">
    <path className="door-comic__floor" d="M8 96 H72" style={FLOOR} />
    <path d="M26 94 C26 77 33 71 44 71 C55 71 62 77 62 94 M30 79 L14 69 M42 31 V24" style={INK} />
    <g className="door-comic__lamp"><path d="M42 2 V5 M31 7 L33 9 M53 7 L51 9" style={INK} /><circle className="door-comic__bulb" cx="42" cy="17" r="6" style={{ fill: 'var(--hi)', stroke: 'var(--fg)', strokeWidth: 2 }} /></g>
    <rect className="door-comic__head" x="22" y="31" width="40" height="36" rx="9" style={{ fill: 'var(--panel)', stroke: 'var(--boost)', strokeWidth: 3 }} />
    <circle cx="35" cy="47" r="2.3" style={DOT} /><circle cx="48" cy="47" r="2.3" style={DOT} />
    <path d="M34 56 Q41 62 49 56" style={INK} />
  </svg>
);
const icon = d => <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d={d} style={{ ...INK, stroke: 'currentColor', strokeWidth: 2 }} /></svg>;

export default function Comic({ words }) {
  const s = useSettings();
  const W = words && typeof words === 'object' ? words : {};
  const [at, setAt] = useState(0);              // the current panel
  const [stopped, setStopped] = useState(false); // the pause button
  const [inside, setInside] = useState(false);  // the focus is in the strip (the strip stops)
  const [beat, setBeat] = useState(0);          // one more at every turn: the fill of the current dot starts again
  const panels = comicPanels(W, s);
  const n = panels.length;
  if (!n) return null;
  const cur = ((at % n) + n) % n;
  const go = i => { setAt(((i % n) + n) % n); setBeat(b => b + 1); };
  const open = W.open || 'Open';
  return (
    <section className="door-hero__picture door-comic" aria-roledescription="carousel" aria-label={W.label || W.ask} data-stopped={stopped ? 'true' : 'false'}
      onFocus={() => setInside(true)} onBlur={e => { if (!e.currentTarget.contains(e.relatedTarget)) setInside(false); }}>
      <ol className="door-comic__panels">
        {panels.map((p, i) => (
          <li key={p.row} className={`door-comic__panel${i === cur ? ' is-current' : ''}`} data-page={p.place.path} data-anchor={p.place.at}>
            <Visitor />
            <p className="door-comic__ask">{W.ask}</p>
            <div className="door-comic__say">
              <p className="door-comic__lead">{p.lead}</p>
              <Statement id={p.row} register={p.register} variant="bubble" evidence={false} />
            </div>
            <Guide />
            <Link to={p.place.path} at={p.place.at} className="door-comic__open" aria-label={`${open}: ${pageTitle(p.place.path, s)}`}>{`${open} →`}</Link>
          </li>
        ))}
      </ol>
      <div className="door-comic__nav">
        <button type="button" className="btn door-comic__prev" aria-label={W.prev || 'Previous'} onClick={() => go(cur - 1)}>{icon('M10 3 L5 8 L10 13')}</button>
        <div role="group" aria-label={W.dots || W.label}>
          {panels.map((p, i) => (
            <button key={p.row} type="button" aria-label={p.field || p.row} aria-current={i === cur ? 'true' : undefined} onClick={() => go(i)}>
              {i === cur ? <span key={beat} className="door-comic__tick" onAnimationEnd={e => { if (e.animationName === 'comic-tick') go(cur + 1); }} /> : null}
            </button>
          ))}
        </div>
        <button type="button" className="btn door-comic__next" aria-label={W.next || 'Next'} onClick={() => go(cur + 1)}>{icon('M6 3 L11 8 L6 13')}</button>
        <button type="button" className="btn door-comic__stop" aria-label={stopped ? W.play || 'Play' : W.pause || 'Pause'} onClick={() => setStopped(x => !x)}>{icon(stopped ? 'M5 3 L12 8 L5 13 Z' : 'M5.5 3 V13 M10.5 3 V13')}</button>
        <p className="vh" aria-live={stopped || inside ? 'polite' : 'off'} aria-atomic="true">{panels[cur].lead}</p>
      </div>
    </section>
  );
}
