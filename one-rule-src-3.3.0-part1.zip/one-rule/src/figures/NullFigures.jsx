// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure null-figures (step 13): two of v15's five null-surface pictures, from engines/nullEngine.js (the formulas null_selfcheck.py checks; the tube's squares and
// brackets are the kernel's) and the stored null.json (κ_H of each horizon, the dimensions of the horizon algebra).
//  1. The cone, the normal and the photon that stands still: in the regular chart ds² = T dv² + 2 dv dx − r² dΩ², T(x) on the left; on the right the light cones up
//     the x axis, the surface x = const through the probe (the line), ξ = ∂ᵥ along it and n = dx across. As T → 0 one edge of the cone lies along the surface: ξ is
//     null. In the cube lens, the tube's tangent algebra Cl(T, −1, −1): K1 = 3, K2 = 5, J = 6 on the 3-cube, [K1, K2] = −2T J dashed when it vanishes (T = 0).
//     At research level the readouts add the Gram determinants of the null pair (−T² in the tortoise chart, −1 in the Eddington–Finkelstein chart, a Witt pair
//     even at T = 0: checks S3.4, S3.5), and under the cone v15's mirror lens of the same state: the mirror in n = dx sends w to w′ with w′^v = w^v + 2w^x/T and
//     w′^x = −w^x, so the image runs away as T → 0 and there is none at T = 0, a null vector having no inverse (engines/physics/nullPhysics.js mirrorAt; NUL-009).
//  2. The horizon's algebra: the cell Cl(1, n−1) = M₂(Cl(0, n−2)) beside the horizon algebra Cl(0, n−2, 1), half its size, split into the ideal J through the null bit
//     (filled; J·J = 0) and the quotient (hollow) — as boxes (Clifford lens), as the corners of the (n−1)-cube by grade (cube lens), as the faces of the simplex with
//     the star of the null vertex ℓ heavy (simplex lens), or as factors of 2 (prime lens). Above it, the ladder of the stored rungs n = 2 … 6 (decision D37): every
//     rung in the lens picked, from the lowest up; "from the top" starts at n = 6 and steps down, each lower rung drawn inside the one above as its restriction
//     (the blades without the last sphere generator, a subalgebra: nullPhysics.js restrictionOf, the kernel's signs).
// The summary of null_selfcheck.py (computed, passed, readings: null.json portal.summary) closes the figure at research level.
// Controls, as in v15: the horizon (the five cases of S12.1), the probe's distance from it (research level) with "on the horizon", and n = 2 … 6 with "from the
// top" (research level). The other three pictures of v15 (the neck, the criterion of Eq. (1), Kerr's ergosurface) are the figures null-neck and null-criterion.
// Port of v15 NullWidgets.ConeWidget (lenses clifford, cube, mirror) and LadderWidget.
import React, { useState, useEffect } from 'react';
import { HORIZONS, PROBE, tMax, kappaNum, surfaceKind, tube, NS, QUOT, CELL, inJ, blade, choose, popc } from '../../engines/nullEngine.js';
import { NULL } from '../../engines/stored.js';
import { MIRROR_W, mirrorAt, gramAt, nullSummary, restrictionOf } from '../../engines/physics/nullPhysics.js';
import { FigSvg, Controls, Chips, Range, r1, sub, arrowHead, pick, isIn, tx } from './kit.jsx';
import './physics/p9.css';

const CASES = HORIZONS.map(h => h.id);
const CASE_NAME = { schw: 'Schwarzschild', rn_out: 'Reissner–Nordström, outer', rn_in: 'Reissner–Nordström, inner', extremal: 'Extremal', areal: 'Areal radius' };
const f3 = (v, d = 3) => (Math.abs(v) < 5 * 10 ** -(d + 1) ? '0' : String(+v.toFixed(d)).replace('-', '−'));
const pow2 = k => '2' + String(k).replace(/\d/g, d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]).replace('-', '⁻');

function ConePanel({ h, d, cube, research, row }) {
  const x = h.xh + d, T = h.T(x), tm = tMax(h), kind = surfaceKind(T), ci = HORIZONS.indexOf(h);
  const y0 = h.xh - PROBE - 0.05, y1 = h.xh + PROBE + 0.05, Y = v => 222 - (v - y0) / (y1 - y0) * 192, tl = tm * 1.15, TX = v => 14 + (v + tl) / (2 * tl) * 100;
  const curve = Array.from({ length: 61 }, (_, i) => { const v = y0 + (y1 - y0) * i / 60; return `${r1(TX(h.T(v)))},${r1(Y(v))}`; }).join(' ');
  const cx = 290, py = Y(x);
  const cone = (qy, Tc, L, strong, key) => {
    const s = -Tc / tm, nn = Math.hypot(1, s), ux = 1 / nn, uy = s / nn, P = a => a.map(p => p.map(r1).join(',')).join(' ');
    return (
      <g key={key} data-cone-t={f3(Tc, 4)} data-probe={strong ? 1 : 0}>
        <polygon points={P([[cx, qy], [cx, qy - L], [cx + L * ux, qy - L * uy]])} className="ink" style={{ fillOpacity: strong ? 0.28 : 0.1 }} />
        <polygon points={P([[cx, qy], [cx, qy + L], [cx - L * ux, qy + L * uy]])} className="ink" style={{ fillOpacity: strong ? 0.28 : 0.1 }} />
        <line x1={cx} y1={r1(qy - L)} x2={cx} y2={r1(qy + L)} className="stroke-ink" style={{ strokeWidth: strong ? 1.8 : 0.8, strokeOpacity: strong ? 1 : 0.55 }} />
        <line x1={r1(cx - L * ux)} y1={r1(qy + L * uy)} x2={r1(cx + L * ux)} y2={r1(qy - L * uy)} className="stroke-ink" style={{ strokeWidth: strong ? 1.8 : 0.8, strokeOpacity: strong ? 1 : 0.55 }} />
      </g>
    );
  };
  const tb = tube(T), P3 = m => [236 + 70 * (m & 1) + 36 * ((m >> 2) & 1), 206 - 70 * ((m >> 1) & 1) - 28 * ((m >> 2) & 1)];
  const kap = NULL.portal.kappa[ci], G = gramAt(T);
  return (
    <FigSvg id="null-figures" row={row} part="the cone and the normal" viewBox={`0 0 420 ${research ? 274 : 240}`}>
      <g data-case={h.id} data-t={f3(T, 5)} data-kind={kind}>
        <line x1={r1(TX(0))} y1={26} x2={r1(TX(0))} y2={226} className="hair" />
        <polyline points={curve} className="stroke-muted" style={{ strokeWidth: 1.8 }} />
        <line x1={8} y1={r1(py)} x2={124} y2={r1(py)} className="stroke-ink" style={{ strokeDasharray: '4 3', strokeOpacity: 0.7 }} />
        <circle cx={r1(TX(T))} cy={r1(py)} r={4.5} className="ink" />
        {research && <text x={r1(TX(0))} y={18} textAnchor="middle" className="t-small">T(x)</text>}
        {research && <text x={r1(TX(0) + 4)} y={r1(Y(h.xh) - 4)} className="t-tiny t-muted">{`x = ${h.xh}`}</text>}
        {!cube && (
          <g data-view="clifford">
            {[-0.5, -0.25, 0, 0.25, 0.5].map(di => cone(Y(h.xh + di), h.T(h.xh + di), 22, false, 'f' + di))}
            <line x1={cx - 92} y1={r1(py)} x2={cx + 92} y2={r1(py)} className="stroke-ink" style={{ strokeWidth: 2.4 }} data-surface="1" />
            {cone(py, T, 34, true, 'p')}
            <line x1={cx + 44} y1={r1(py)} x2={cx + 76} y2={r1(py)} className="stroke-ink" style={{ strokeWidth: 1.5 }} /><path d={arrowHead(cx + 44, py, cx + 80, py, 7)} className="ink" />
            <text x={cx + 46} y={r1(py + 15)} className="t-small">{research ? 'ξ = ∂ᵥ' : 'along'}</text>
            <line x1={cx - 64} y1={r1(py)} x2={cx - 64} y2={r1(py - 28)} className="stroke-ink" style={{ strokeWidth: 1.5 }} /><path d={arrowHead(cx - 64, py, cx - 64, py - 32, 7)} className="ink" />
            <text x={cx - 60} y={r1(py - 24)} className="t-small">{research ? 'n = dx' : 'across'}</text>
            <text x={cx - 90} y={r1(py + 14)} className="t-small">{research ? 'x = const' : 'the surface'}</text>
          </g>
        )}
        {cube && (
          <g data-view="cube" data-k1k2={f3(tb.K1K2.c)}>
            {[0, 1, 2, 3, 4, 5, 6, 7].flatMap(m => [0, 1, 2].map(b => (((m >> b) & 1) ? null : [m, m | (1 << b)]))).filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} className="hair" />)}
            {[[3, 5], [3, 6], [5, 6]].map(([a, b]) => { const k12 = a === 3 && b === 5, zero = k12 && Math.abs(T) < 1e-12; return <line key={'k' + a + b} x1={P3(a)[0]} y1={P3(a)[1]} x2={P3(b)[0]} y2={P3(b)[1]} className="stroke-ink" style={{ strokeWidth: k12 ? 3 : 1.6, strokeDasharray: zero ? '4 3' : undefined, strokeOpacity: zero ? 0.5 : 1 }} data-bracket={`${a},${b}`} />; })}
            {[0, 1, 2, 3, 4, 5, 6, 7].map(m => { const [px, qy] = P3(m), even = popc(m) % 2 === 0 && m; return <g key={m}><circle cx={px} cy={qy} r={even ? 8 : 6} className={even ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5, strokeOpacity: m === 0 || m === 7 ? 0.5 : 1 }} /><text x={px + 11} y={qy - 7} className="t-mono t-tiny">{m}</text></g>; })}
            <text x={P3(3)[0] - 4} y={P3(3)[1] - 14} className="t-small">K1</text><text x={P3(5)[0] + 4} y={P3(5)[1] + 22} className="t-small">K2</text><text x={P3(6)[0] - 20} y={P3(6)[1] - 10} className="t-small">J</text>
            {research && <text x={190} y={18} className="t-tiny t-muted">3-cube: K1 = 3, K2 = 5, J = 6</text>}
          </g>
        )}
        <text x={150} y={240} className="t-small t-bold">{`${research ? 'the surface x = const is ' : 'the surface is '}${kind}`}</text>
        {research && <text x={8} y={256} className="t-mono t-tiny t-muted" data-kappa={kap.kappa}>{cube
          ? `K1² = K2² = T = ${f3(tb.sq.K1)} · J² = ${tb.sq.J} · [J, K1] = ${tb.JK1.c} K2 · [K1, K2] = −2T J = ${f3(tb.K1K2.c)} J`
          : tx(`T = g_{tt} = ${f3(T)} · n·n = −T · κ_H = ½ dT/dx = ${kap.kappa} (${f3(kappaNum(h), 4)})`)}</text>}
        {research && <text x={8} y={270} className="t-mono t-tiny t-muted" data-gram-tortoise={f3(G.tortoise, 5)} data-gram-ef={G.ef}>{`Gram det: tortoise −T² = ${f3(G.tortoise, 5)}, Eddington–Finkelstein ${f3(G.ef)}${Math.abs(T) < 1e-12 ? ', a Witt pair' : ''}`}</text>}
      </g>
    </FigSvg>
  );
}

/** v15's mirror lens of the cone: the vector w and its image in the mirror n = dx (none when n is null) */
function MirrorPanel({ T, row }) {
  const M = mirrorAt(T), w = MIRROR_W, MX = 52, ox = 210, oy = 104, lim = [3.4, 1.7];
  const clip = b => { const k = Math.max(Math.abs(b[0]) / lim[0], Math.abs(b[1]) / lim[1], 1); return [b[0] / k, b[1] / k, k > 1]; };
  const im = M.img ? clip(M.img) : null, P = ([v, x]) => [ox + v * MX, oy - x * MX];
  const [wx, wy] = P(w);
  return (
    <FigSvg id="null-figures" row={row} part="the mirror in n" viewBox="0 0 420 200">
      <g data-view="mirror" data-t={f3(T, 5)} data-image={M.img ? `${f3(M.img[0], 4)},${f3(M.img[1], 4)}` : 'none'}>
        <line x1={ox - 3.6 * MX} y1={oy} x2={ox + 3.6 * MX} y2={oy} className="stroke-ink" style={{ strokeWidth: 2.4 }} />
        <text x={ox - 3.6 * MX} y={oy - 6} className="t-small">x = const</text>
        <line x1={ox} y1={oy - 1.8 * MX} x2={ox} y2={oy + 1.8 * MX} className="hair" />
        <text x={ox + 3.6 * MX - 2} y={oy + 14} textAnchor="end" className="t-tiny t-muted">v</text>
        <text x={ox + 6} y={oy - 1.8 * MX + 10} className="t-tiny t-muted">x</text>
        <line x1={ox} y1={oy} x2={r1(wx)} y2={r1(wy)} className="stroke-ink" style={{ strokeWidth: 2.4 }} />
        <path d={arrowHead(ox, oy, wx, wy, 7)} className="ink" />
        <text x={r1(wx + 6)} y={r1(wy - 4)} className="t-small t-bold">w</text>
        {im ? (
          <g data-clipped={im[2] ? 1 : 0}>
            <line x1={r1(wx)} y1={r1(wy)} x2={r1(P(im)[0])} y2={r1(P(im)[1])} className="stroke-ink" style={{ strokeDasharray: '4 3', strokeOpacity: 0.6 }} />
            <line x1={ox} y1={oy} x2={r1(P(im)[0])} y2={r1(P(im)[1])} className="stroke-ink" style={{ strokeWidth: 2.4, strokeDasharray: '7 3' }} />
            <path d={arrowHead(ox, oy, P(im)[0], P(im)[1], 7)} className="ink" />
            <text x={r1(Math.min(P(im)[0] + 6, ox + 3.6 * MX - 70))} y={r1(P(im)[1] + 16)} className="t-small t-bold">{im[2] ? 'w′ (off the page)' : 'w′'}</text>
          </g>
        ) : <text x={ox + 20} y={oy + 40} className="t-small t-bold" data-none="1">no image: n·n = 0</text>}
        <text x={8} y={192} className="t-mono t-tiny t-muted">{M.img ? tx(`w = (${w[0]}, ${w[1]}) → w′ = (${f3(M.img[0], 2)}, ${f3(M.img[1], 2)}) · w′^v = w^v + 2 w^x / T`) : `w = (${w[0]}, ${w[1]}) · n·n = −T = 0: no inverse, no mirror`}</text>
      </g>
    </FigSvg>
  );
}

/** one rung of the ladder in a lens, small; within: rung n + 1 faint with the blades of rung n heavy (its restriction, D37) */
function RungMini({ n, view, within, x0, y0 }) {
  const N = within ? n + 1 : n, m = N - 1, img = within ? new Set(restrictionOf(N).image) : null, on = S => !img || img.has(S), w = 64, h = 46;
  let body;
  if (view === 'cube') {
    const cols = Array.from({ length: m + 1 }, () => []); for (let S = 0; S < 1 << m; S++) cols[popc(S)].push(S);
    const mx = Math.max(...cols.map(c => c.length)), dx = w / (m + 1), dy = Math.min(7, (h - 6) / Math.max(1, mx));
    const at = S => { const k = popc(S), j = cols[k].indexOf(S); return [x0 + dx * k + dx / 2, y0 + h / 2 + dy * (j - (cols[k].length - 1) / 2)]; };
    body = Array.from({ length: 1 << m }, (_, S) => { const [x, y] = at(S), J = inJ(N, S); return <circle key={S} cx={r1(x)} cy={r1(y)} r={2} className={J ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 0.8, opacity: on(S) ? 1 : 0.25 }} />; });
  } else if (view === 'simplex') {
    const V = Array.from({ length: m }, (_, i) => { const a = (2 * Math.PI * i) / Math.max(m, 3) - Math.PI / 2 + (m === 2 ? Math.PI / 4 : 0); return m === 1 ? [x0 + w / 2, y0 + h / 2] : m === 2 ? [x0 + w / 2 + (i ? 18 : -18), y0 + h / 2] : [x0 + w / 2 + 19 * Math.cos(a), y0 + h / 2 + 19 * Math.sin(a)]; });
    const keep = i => !within || i < m - 1;
    body = <>{V.flatMap((p, i) => V.map((q, j) => (j > i ? <line key={i + '-' + j} x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: i === 0 ? 1.6 : 0.7, opacity: keep(i) && keep(j) ? 1 : 0.25 }} /> : null)))}{V.map(([x, y], i) => <circle key={i} cx={r1(x)} cy={r1(y)} r={i === 0 ? 3 : 2.2} className={i === 0 ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 0.8, opacity: keep(i) ? 1 : 0.25 }} />)}</>;
  } else if (view === 'prime') {
    body = Array.from({ length: N - 1 }, (_, j) => <g key={j} style={{ opacity: !within || j < N - 2 ? 1 : 0.25 }}><circle cx={x0 + 8 + 11 * j} cy={y0 + h / 2} r={4.6} className="ink" style={{ fillOpacity: 0.2, stroke: 'var(--fg)', strokeWidth: 0.8 }} /><text x={x0 + 8 + 11 * j} y={y0 + h / 2 + 2.6} textAnchor="middle" className="t-micro">2</text></g>);
  } else {
    const full = 1 << m, own = within ? full / 2 : full, bw = 26, bh = (h - 8) * m / (NS[NS.length - 1] - 1), by = y0 + h - 4 - bh;
    body = <>{[0, 1].map(k => <g key={k}><rect x={x0 + 4 + k * (bw + 4)} y={r1(by)} width={bw} height={r1(bh)} rx={2} className={k ? 'on-panel' : 'ink'} style={{ fillOpacity: k ? 1 : 0.15, stroke: 'var(--fg)', strokeWidth: 0.8, opacity: within ? 0.3 : 1 }} />{within && <rect x={x0 + 4 + k * (bw + 4)} y={r1(by + bh * (1 - (m - 1) / m))} width={bw} height={r1(bh * (m - 1) / m)} rx={2} className={k ? 'on-panel' : 'ink'} style={{ fillOpacity: k ? 1 : 0.25, stroke: 'var(--fg)', strokeWidth: 1.1 }} />}</g>)}<text x={x0 + 34} y={r1(by - 2)} textAnchor="middle" className="t-micro t-muted">{`dim ${own}`}</text></>;
  }
  return <g data-rung={n} data-rung-view={view} data-within={within ? n + 1 : 0}>{body}</g>;
}

function LadderPanel({ n, view, down, research, row }) {
  const rec = NULL.portal.ladder.find(r => r.n === n), m = n - 1, N = 1 << m, nq = QUOT[n], top = NS[NS.length - 1];
  const within = down && n < top, R = within ? restrictionOf(n + 1) : null;
  const cols = Array.from({ length: m + 1 }, () => []); for (let S = 0; S < N; S++) cols[popc(S)].push(S);
  const mx = Math.max(...cols.map(c => c.length)), CW = 380 / (m + 1), RH = Math.min(28, 160 / mx);
  const vpos = S => { const k = popc(S), j = cols[k].indexOf(S); return [30 + CW * k + CW / 2 - 10, 160 + RH * (j - (cols[k].length - 1) / 2)]; };
  const poly = Array.from({ length: m }, (_, i) => { const a = (2 * Math.PI * i) / Math.max(m, 3) - Math.PI / 2 + (m === 2 ? Math.PI / 4 : 0); return m === 1 ? [210, 160] : m === 2 ? [210 + (i ? 70 : -70), 160] : [210 + 80 * Math.cos(a), 164 + 80 * Math.sin(a)]; });
  const box = (k, x, y, w, hh, filled, tx) => <g key={k}><rect x={x} y={y} width={w} height={hh} rx={5} className={filled ? 'ink' : 'on-panel'} style={{ fillOpacity: filled ? 0.18 : 1, stroke: 'var(--fg)', strokeWidth: 1.4 }} /><text x={x + w / 2} y={y + hh / 2 + 4} textAnchor="middle" className="t-small">{tx}</text></g>;
  const ladder = down ? [...NS].reverse() : NS, SW = 412 / NS.length;
  return (
    <FigSvg id="null-figures" row={row} part="the horizon algebra" viewBox={`0 0 420 ${research ? 302 : 286}`}>
      <g data-ladder={down ? 'top' : 'up'} data-rungs={NS.join(',')}>
        {ladder.map((k, i) => (
          <g key={k}>
            {k === n && <rect x={r1(4 + i * SW)} y={2} width={r1(SW - 4)} height={64} rx={5} className="stroke-ink" style={{ strokeWidth: 1.4 }} data-rung-on={k} />}
            <RungMini n={k} view={view} within={down && k < top} x0={8 + i * SW} y0={4} />
            <text x={r1(4 + i * SW + SW / 2 - 2)} y={62} textAnchor="middle" className={k === n ? 't-tiny t-bold' : 't-tiny t-muted'}>{`n = ${k}`}</text>
            {i < ladder.length - 1 && <path d={arrowHead(4 + (i + 1) * SW - 9, 28, 4 + (i + 1) * SW - 1, 28, 5)} className="ink" style={{ opacity: 0.5 }} />}
          </g>
        ))}
      </g>
      <g data-n={n} data-view={view} data-dim={rec.dim} data-j={rec.J}>
        {view === 'clifford' && (
          <g>
            <text x={8} y={84} className="t-small t-bold">{research ? `the cell: ${CELL[n]}` : 'the cell'}</text>
            {[0, 1, 2, 3].map(i => box('c' + i, 8 + 98 * (i % 2), 94 + 76 * (i >> 1), 92, 70, false, nq))}
            <text x={8} y={258} className="t-tiny t-muted">{`2×2 matrices over ${nq}`}</text>
            <text x={222} y={84} className="t-small t-bold">{research ? `the horizon: Cl(0,${n - 2},1)` : 'the horizon'}</text>
            {box('J', 222, 94, 90, 152, true, 'J · J = 0')}{box('Q', 318, 94, 94, 152, false, `quotient ${nq}`)}
            <text x={222} y={258} className="t-tiny" data-j-dim={rec.J}>{`dim ${pow2(n - 1)} = ${rec.dim} · dim J = ${pow2(n - 2)} = ${rec.J}`}</text>
          </g>
        )}
        {view === 'cube' && (
          <g>
            {Array.from({ length: N }, (_, S) => Array.from({ length: m }, (_, b) => (((S >> b) & 1) ? null : [S, S | (1 << b)]))).flat().filter(Boolean).map(([a, b]) => <line key={a + '-' + b} x1={r1(vpos(a)[0])} y1={r1(vpos(a)[1])} x2={r1(vpos(b)[0])} y2={r1(vpos(b)[1])} className="hair" />)}
            {Array.from({ length: N }, (_, S) => { const [px, qy] = vpos(S), J = inJ(n, S); return <circle key={S} cx={r1(px)} cy={r1(qy)} r={6} className={J ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} data-blade={S} data-in-j={J ? 1 : 0}><title>{`${blade(n, S)} (${S.toString(2).padStart(m, '0')})${J ? ' · in J' : ''}`}</title></circle>; })}
            {cols.map((c, k) => <text key={k} x={r1(30 + CW * k + CW / 2 - 10)} y={84} textAnchor="middle" className="t-mono t-tiny t-muted">{k}</text>)}
            <text x={8} y={266} className="t-tiny t-muted">columns: grade · filled: through the null bit (J) · hollow: the quotient</text>
          </g>
        )}
        {view === 'simplex' && (
          <g>
            {poly.flatMap((a, i) => poly.map((b, j) => (j > i ? [i, j] : null)).filter(Boolean)).map(([i, j]) => <line key={i + '-' + j} x1={r1(poly[i][0])} y1={r1(poly[i][1])} x2={r1(poly[j][0])} y2={r1(poly[j][1])} className="stroke-ink" style={{ strokeWidth: i === 0 ? 3 : 1.2, strokeOpacity: i === 0 ? 1 : 0.45 }} data-star={i === 0 ? 1 : 0} />)}
            {poly.map((p, i) => <g key={i}><circle cx={r1(p[0])} cy={r1(p[1])} r={i === 0 ? 10 : 7} className={i === 0 ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} /><text x={r1(p[0] + (p[0] >= 210 ? 14 : -14))} y={r1(p[1] + (p[1] >= 164 ? 16 : -10))} textAnchor={p[0] >= 210 ? 'start' : 'end'} className="t-small">{i === 0 ? 'ℓ' : 'e' + sub(i)}</text></g>)}
            <text x={8} y={84} className="t-small">{`${m} generators: ℓ (null) and ${m - 1} for the sphere`}</text>
            <text x={8} y={266} className="t-tiny" data-star-faces={rec.J}>{`faces through ℓ: ${Array.from({ length: m }, (_, k) => choose(m - 1, k)).join(' + ')} = ${rec.J}`}</text>
          </g>
        )}
        {view === 'prime' && (
          <g>
            {[[n, rec.dim * 2, 'the cell'], [n - 1, rec.dim, 'the horizon algebra'], [n - 2, rec.J, 'the ideal J']].map(([k, val, name], i) => (
              <g key={i} data-prime-row={val}>
                <text x={8} y={88 + 60 * i} className="t-small">{`${name} = ${val} = ${pow2(k)}`}</text>
                {Array.from({ length: k }, (_, j) => <g key={j}><circle cx={20 + 28 * j} cy={106 + 60 * i} r={11} className="ink" style={{ fillOpacity: 0.12 + 0.12 * i, stroke: 'var(--fg)', strokeWidth: 1.4 }} /><text x={20 + 28 * j} y={110 + 60 * i} textAnchor="middle" className="t-small">2</text></g>)}
              </g>
            ))}
            <text x={8} y={266} className="t-tiny t-muted">only the prime 2</text>
          </g>
        )}
        {research && <text x={8} y={282} className="t-mono t-tiny t-muted">{`n = ${n} · Cl(0,${n - 2},1): dim ${rec.dim} · dim J = ${rec.J} · quotient Cl(0,${n - 2}) = ${nq}`}</text>}
        {research && within && <text x={8} y={296} className="t-mono t-tiny t-muted" data-restriction-of={n + 1}>{`from the top: Cl(0,${n - 2},1) ⊂ Cl(0,${n - 1},1) without e${sub(n - 1)}: ${R.image.length} of ${1 << n} blades${R.closed ? ' ✓' : ''}`}</text>}
      </g>
    </FigSvg>
  );
}

export default function NullFigures({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [ci, setCi] = useState(pick(params.case, isIn(CASES), 'schw'));
  const [d, setD] = useState(Number.isFinite(params.probe) && Math.abs(params.probe) <= PROBE ? params.probe : 0);
  const [n, setN0] = useState(pick(params.n, isIn(NS), params.top === true ? NS[NS.length - 1] : 4));
  const [down, setDown] = useState(params.top === true);
  useEffect(() => { setCi(pick(params.case, isIn(CASES), 'schw')); setD(Number.isFinite(params.probe) && Math.abs(params.probe) <= PROBE ? params.probe : 0); setN0(pick(params.n, isIn(NS), params.top === true ? NS[NS.length - 1] : 4)); setDown(params.top === true); }, [params.case, params.probe, params.n, params.top]);
  const h = HORIZONS.find(x => x.id === ci), view = lens === 'cube' ? 'cube' : lens === 'simplex' ? 'simplex' : lens === 'prime' ? 'prime' : 'clifford';
  const top = NS[NS.length - 1], S = nullSummary();
  const setN = k => { setN0(k); setDown(false); };
  const fromTop = () => { if (!down || n <= NS[0]) { setN0(top); setDown(true); } else setN0(n - 1); };
  return (
    <div className="fig fig-null-figures">
      <div className="fig-stack">
        <ConePanel h={h} d={d} cube={lens === 'cube'} research={research} row={row} />
        {research && <MirrorPanel T={h.T(h.xh + d)} row={row} />}
        <LadderPanel n={n} view={view} down={down} research={research} row={row} />
      </div>
      {research && <p className="p9-readout" data-computed={S.computed} data-passed={S.passed} data-readings={S.readings}>{`null_selfcheck.py: ${S.computed} computed · ${S.passed} passed · ${S.readings} readings (ours, not computed)`}</p>}
      <Controls label="null surfaces">
        <Chips label={research ? 'horizon' : 'which edge'} items={CASES} value={ci} onPick={c => setCi(c)} render={c => CASE_NAME[c]} param="case" />
        {research && <Range label="probe x − xₕ" value={d} min={-PROBE} max={PROBE} step={0.01} onChange={setD} display={v => f3(v, 2)} param="probe" />}
        {research && <button type="button" className="fig-btn" data-param="probe" onClick={() => setD(0)}>on the horizon</button>}
        {research && <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />}
        {research && <button type="button" className="fig-btn" data-param="top" aria-pressed={down} onClick={fromTop}>{down && n > NS[0] ? `from the top: next rung down (n = ${n - 1})` : 'from the top'}</button>}
      </Controls>
    </div>
  );
}
NullFigures.meta = { id: 'null-figures', lenses: ['clifford', 'simplex', 'cube', 'prime'], learner: true };
/** the numbers the figure draws, for the frame's data download */
NullFigures.data = (params = {}) => { const h = HORIZONS.find(x => x.id === params.case) || HORIZONS[0], d = Number.isFinite(params.probe) ? params.probe : 0, T = h.T(h.xh + d); return { case: h.id, xh: h.xh, probe: d, T, kind: surfaceKind(T), tube: tube(T), kappa: NULL.portal.kappa[HORIZONS.indexOf(h)], gram: gramAt(T), mirror: mirrorAt(T), summary: nullSummary(), ladder: NULL.portal.ladder }; };
