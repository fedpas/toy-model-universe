// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure comm-graph: the six bivectors of a cell Cl(p, 4−p) as the vertices of an octahedron, complementary bivectors opposite; two bivectors are joined when they share
// one generator, and then [e_a, e_b] = ±2 e_{a xor b} (the kernel's signs, engines/labels.js commGraph; counts and roles compared with checks/selfcheck/equations.json).
// The mark of a vertex is its role (the first p generators are time): E one time index (filled), B none (ring), T two (square). Lenses print the labels with the kernel:
// Clifford e₁e₂, simplex {1,2} (an edge of the tetrahedron: the graph is its line graph), cube 0011, prime 2·3. Port of v15 EquationsSection.Octa.
// The physics restoration (owner P5, docs/PHYSICS_AUDIT.md CM1, CM2): under the drawing the roles by mark and word at both levels, as v15 named them (research:
// "E: one time index (a boost when there is one time axis)" …; learner: "one time direction: a boost, which is a change of speed" …), and what each commutator is
// made of in the chosen cell — research: v15's table (pair, shared index, result, edges), learner: the same rows in words ("two boosts sharing a time direction →
// a turn (3)") — from the kernel's commutators (engines/physics/commutators.js rolesOf), which tests/physics/p5.test.mjs ties to equations.json commutators.roles.
import React, { useState, useEffect, useMemo } from 'react';
import { commGraph, label } from '../../engines/labels.js';
import { rolesOf } from '../../engines/physics/commutators.js';
import { RoleIcon } from './MaxwellEquations.jsx';
import { FigSvg, Controls, Chips, r1, labelLens } from './kit.jsx';

const OCT = [[3, 90], [5, 150], [6, 210], [12, 270], [10, 330], [9, 30]];   // mask, angle: e12 e13 e23 e34 e24 e14 (opposite = complementary)
/** the roles in words, as v15 named them (EquationsSection CommTab: c.roles, c.yl.roles); the learner's nouns for the rows; the shared index (c.via) */
const ROLE = {
  research: { E: 'one time index (a boost when there is one time axis)', B: 'no time index (a rotation)', T: 'two time indices' },
  learner: { E: 'one time direction: a boost, which is a change of speed', B: 'no time direction: a turn', T: 'two time directions' },
};
const NOUN = { E: ['a boost', 'two boosts'], B: ['a turn', 'two turns'], T: ['a time–time piece', 'two time–time pieces'] };
const VIA = { research: { t: 'a time axis', s: 'a space axis' }, learner: { t: 'sharing a time direction', s: 'sharing a space direction' } };
/** a row of the role table in words: "two boosts sharing a time direction → a turn (3)" */
export function roleWords(key, v) {
  const [pair, via] = key.split(' via '), [x, y] = pair.split('+');
  return `${x === y ? NOUN[x][1] : `${NOUN[x][0]} and ${NOUN[y][0]}`} ${VIA.learner[via]} → ${NOUN[v.result] ? NOUN[v.result][0] : '?'} (${v.edges})`;
}

function Mark({ x, y, role }) {
  if (role === 'T') return <rect x={x - 6.5} y={y - 6.5} width={13} height={13} rx={2} className="ink-muted" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} />;
  if (role === 'B') return <circle cx={x} cy={y} r={7} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} />;
  return <circle cx={x} cy={y} r={7} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} />;
}

export default function CommGraph({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const valid = x => Number.isInteger(x) && x >= 0 && x <= 4;
  const [p, setP] = useState(valid(params.p) ? params.p : 1);
  useEffect(() => { if (valid(params.p)) setP(params.p); }, [params.p]);   // eslint-disable-line react-hooks/exhaustive-deps
  const G = useMemo(() => commGraph(p, 4 - p), [p]), lensKey = labelLens(lens) || 'clifford';
  const table = useMemo(() => Object.entries(rolesOf(p, 4 - p)), [p]);
  const pos = Object.fromEntries(OCT.map(([m, a]) => [m, [r1(150 + 100 * Math.cos(a * Math.PI / 180)), r1(140 - 100 * Math.sin(a * Math.PI / 180)), a]]));
  const name = m => (research ? label(m, lensKey, G.eps) : label(m, 'set', G.eps).replace(/[{}]/g, '').replace(',', ' '));
  const roleOf = Object.fromEntries(G.bivectors.map(b => [b.m, b]));
  const roles = ['E', 'B', 'T'].filter(r => G.bivectors.some(b => b.role === r));
  const lv = research ? 'research' : 'learner';
  return (
    <div className="fig fig-comm-graph" data-cell={`${p},${4 - p}`}>
      <FigSvg id="comm-graph" row={row} viewBox="0 0 300 282">
        {G.edges.map(e => (
          <line key={e.a + '-' + e.b} x1={pos[e.a][0]} y1={pos[e.a][1]} x2={pos[e.b][0]} y2={pos[e.b][1]} className="stroke-ink" style={{ strokeOpacity: 0.5, strokeWidth: 1.3 }}>
            <title>{`[${label(e.a, 'clifford', G.eps)}, ${label(e.b, 'clifford', G.eps)}] = ${e.coef < 0 ? '−' : ''}2 ${label(e.k, 'clifford', G.eps)}`}</title>
          </line>
        ))}
        {OCT.map(([m, a]) => { const [x, y] = pos[m], b = roleOf[m]; return (
          <g key={m} data-m={m} data-role={b.role}>
            <title>{`${label(m, 'clifford', G.eps)}: ${b.role}, square ${b.square > 0 ? '+1' : '−1'}`}</title>
            <Mark x={x} y={y} role={b.role} />
            <text x={r1(150 + 128 * Math.cos(a * Math.PI / 180))} y={r1(140 - 124 * Math.sin(a * Math.PI / 180) + 4)} textAnchor="middle" className="t-mono t-small">{name(m)}</text>
          </g>); })}
      </FigSvg>
      <ul className="mx-legend" aria-label={research ? 'roles' : 'what the marks mean'} data-legend={lv}>
        {roles.map(r => <li key={r} data-role-word={r}><RoleIcon role={r} />{research ? <b>{r}</b> : null}<span>{ROLE[lv][r]}</span></li>)}
      </ul>
      {research ? (
        <div className="fig-scroll">
          <table className="mx-table" data-roles={`${p},${4 - p}`}>
            <caption>{`what each commutator is made of · Cl(${p},${4 - p})`}</caption>
            <thead><tr><th>pair</th><th>shared index</th><th>result</th><th>edges</th></tr></thead>
            <tbody>{table.map(([k, v]) => { const [pair, via] = k.split(' via '), [x, y] = pair.split('+'); return (
              <tr key={k} data-role-row={k} data-result={v.result} data-edges={v.edges}>
                <td><span className="mx-term"><RoleIcon role={x} />{x}</span>{' · '}<span className="mx-term"><RoleIcon role={y} />{y}</span></td>
                <td>{VIA.research[via]}</td>
                <td><span className="mx-term"><RoleIcon role={v.result} />{v.result}</span></td>
                <td>{v.edges}</td>
              </tr>); })}</tbody>
          </table>
        </div>
      ) : (
        <ul className="mx-legend" aria-label="what each pair gives" data-role-words={`${p},${4 - p}`}>
          {table.map(([k, v]) => <li key={k} data-role-row={k} data-result={v.result} data-edges={v.edges}><RoleIcon role={v.result} /><span>{roleWords(k, v)}</span></li>)}
        </ul>
      )}
      {research ? <p className="mx-counts" data-sum={table.map(([, v]) => v.edges).join('+')}>{`${table.map(([, v]) => v.edges).join(' + ')} = ${G.edges.length} pairs that do not commute · ${G.commuting.length} commute`}</p> : null}
      {research && <Controls label="cell"><Chips label="cell" items={[0, 1, 2, 3, 4]} value={p} onPick={setP} render={x => `Cl(${x},${4 - x})`} param="p" mono /></Controls>}
    </div>
  );
}
CommGraph.meta = { id: 'comm-graph', lenses: ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
CommGraph.data = (params = {}) => { const p = Number.isInteger(params.p) ? params.p : 1, G = commGraph(p, 4 - p); return { cell: [p, 4 - p], bivectors: G.bivectors, edges: G.edges, commuting: G.commuting, roles: rolesOf(p, 4 - p) }; };
