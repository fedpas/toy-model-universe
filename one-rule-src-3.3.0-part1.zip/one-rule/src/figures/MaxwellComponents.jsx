// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure maxwell-components (caption ATL-017; BUILD_CONTRACTS round 5, decision D29): the components of the field F of a cell Cl(k, d) by role, as the
// antisymmetric grid F_ab of its axes — E where one index is a time (k·d of them), B where none is (C(d, 2)), T where both are (C(k, 2), the extra components
// of more than one time) — each with its stored label (with the sign the convention gives it in F, at research level) and, under it, its blade in the current
// lens (the kernel's printer label(mask, lens) of engines/bitrule.js in a label lens, the stored γ-name otherwise); under the grid the sources J: ρ for each
// time, J for each space axis. Tapping a component or a source lists the equations it takes part in (engines/maxwellPhysics.js equationsOf), the term it
// gives each one marked: KaTeX at research level, words at learner level. Every label and sign is recomputed through the kernel and tied to
// checks/selfcheck/maxwell.json by tests/maxwell.test.mjs. The controls: v15's time and space chips, and a tap on a component (Octavo's piece chips).
import React, { useEffect, useState } from 'react';
import { cellPhysics, equationsOf, roleName, nameAt } from '../../engines/maxwellPhysics.js';
import { label } from '../../engines/bitrule.js';
import { useKatex } from '../app/math.js';
import { FigSvg, Controls, r1, labelLens } from './kit.jsx';
import { useCell, CellChips, cellOfParams, RoleShape, RoleIcon, Legend, EqMath, EqWords } from './MaxwellEquations.jsx';
import './maxwell.css';

/** the name of a blade under its component: a label lens prints it with the kernel; else the stored γ-name (research) or the generators' numbers (learner) */
const namer = (C, lens, research) => {
  const L = labelLens(lens);
  if (L) return m => label(m, L, C.eps);
  return research ? m => C.blades[m].name : m => C.blades[m].S.map(i => i + 1).join(' ');
};
const signOf = C => { const s = new Map(); C.components.field.forEach((m, i) => s.set(m, C.conventions.signs[i])); C.components.sources.forEach((m, i) => s.set(m, C.conventions.signs[C.components.field.length + i])); return s; };
const fit = (text, w, base) => Math.max(5.5, Math.min(base, (w - 4) / (0.62 * Math.max(1, [...String(text)].length))));

function Grid({ C, lens, research, level, row, pick, onPick }) {
  const n = C.n, W = 420, hw = 26, cw = Math.min(66, (W - hw - 6) / n), ch = 44, gx = r1((W - hw - n * cw) / 2) + hw, top = 22;
  const nm = namer(C, lens, research), sg = signOf(C);
  const srcTop = top + n * ch + 22, H = srcTop + ch + 6;
  const cellBox = (N, x, y, role) => {
    const b = C.blades[N], on = pick === N, lab = (research && sg.get(N) < 0 ? '−' : '') + b.label, bn = nm(N);
    const act = () => onPick(N);
    return (
      <g key={N} className={'mx-pick' + (on ? ' mx-on' : '')} role="button" tabIndex={0} data-param="pick" data-comp={N} data-role={role} data-label={b.label} data-blade={bn} aria-pressed={on}
        aria-label={`${b.label}, ${roleName(role, level)}, ${bn}`} onClick={act} onKeyDown={ev => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); act(); } }}>
        <title>{`${b.label}: ${roleName(role, level)} · ${bn}`}</title>
        <rect x={r1(x + 1.5)} y={r1(y + 1.5)} width={r1(cw - 3)} height={r1(ch - 3)} rx={4} className="mx-box" />
        <RoleShape role={role} x={x + 8} y={y + 9} r={3.2} />
        <text x={r1(x + cw / 2)} y={r1(y + 21)} textAnchor="middle" className="t-mono" style={{ fontSize: `${r1(fit(lab, cw, 12))}px` }}>{lab}</text>
        <text x={r1(x + cw / 2)} y={r1(y + 35)} textAnchor="middle" className="t-mono t-muted" style={{ fontSize: `${r1(fit(bn, cw, 9))}px` }}>{bn}</text>
      </g>
    );
  };
  return (
    <FigSvg id="maxwell-components" row={row} part={`the components of F by role, and the sources J, in Cl(${C.k},${C.d})`} viewBox={`0 0 ${W} ${H}`}>
      {C.axes.map((a, b) => <text key={'c' + b} x={r1(gx + b * cw + cw / 2)} y={14} textAnchor="middle" className="t-mono t-small t-muted">{a}</text>)}
      {C.axes.map((a, i) => <text key={'r' + i} x={r1(gx - 8)} y={r1(top + i * ch + ch / 2 + 4)} textAnchor="end" className="t-mono t-small t-muted">{a}</text>)}
      {C.axes.map((_, a) => C.axes.map((__, b) => {
        const x = gx + b * cw, y = top + a * ch;
        if (a === b) return <rect key={`${a},${b}`} x={r1(x + 1.5)} y={r1(y + 1.5)} width={r1(cw - 3)} height={r1(ch - 3)} rx={4} className="mx-zero" />;
        if (a > b) return null;
        const N = (1 << a) | (1 << b);
        return cellBox(N, x, y, C.blades[N].role);
      }))}
      <text x={6} y={r1(srcTop - 7)} className="t-small t-muted">{research ? 'J' : 'sources'}</text>
      {C.components.sources.map(N => { const b = C.blades[N], i = b.S[0]; return cellBox(N, gx + i * cw, srcTop, b.role); })}
    </FigSvg>
  );
}

export default function MaxwellComponents({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const cell = useCell(params), C = cellPhysics(cell.k, cell.d);
  const [pick, setPick] = useState(Number.isInteger(params.pick) ? params.pick : null);
  useEffect(() => { setPick(Number.isInteger(params.pick) ? params.pick : null); }, [params.pick]);
  const katex = useKatex(research);
  const valid = m => C.components.field.includes(m) || C.components.sources.includes(m);
  const N = valid(pick) ? pick : C.components.field[0], b = C.blades[N], nm = namer(C, lens, research);
  const list = equationsOf(C.k, C.d, N), c = C.counts, nr = C.components.sources.filter(m => C.blades[m].role === 'rho').length;
  return (
    <div className="fig fig-mx fig-maxwell-components" data-cell={`${C.k},${C.d}`} data-picked={N}>
      <Controls label="Maxwell: the cell"><CellChips cell={cell} research={research} /></Controls>
      <Grid C={C} lens={lens} research={research} level={level} row={row} pick={N} onPick={setPick} />
      <Legend C={C} level={level} />
      <p className="mx-counts" data-counts={`${c.E},${c.B},${c.T}`}>
        {research
          ? `F: ${C.components.field.length} = ${c.E} E${c.B ? ` + ${c.B} B` : ''}${c.T ? ` + ${c.T} T` : ''} · J: ${C.components.sources.length} = ${nr} ρ + ${C.components.sources.length - nr} J`
          : `${C.components.field.length} field pieces · ${C.components.sources.length} sources`}
      </p>
      <div className="fig-note mx-of" aria-live="polite" data-of={N}>
        <p><RoleIcon role={b.role} /><b>{b.label}</b><span>{roleName(b.role, level)}</span><span className="mx-plain">{nm(N)}</span><span className="mx-n">{`${list.length} ${list.length === 1 ? 'equation' : 'equations'}`}</span></p>
        <ul>
          {list.map(e => { const full = C.byTarget.get(e.target); return (
            <li key={e.id} data-of-eq={e.id}>
              <span className="mx-eqname">{nameAt(e, level)}</span>
              {research ? <EqMath e={full} katex={katex} hot={N} /> : <EqWords e={full} level={level} hot={N} />}
            </li>
          ); })}
        </ul>
      </div>
    </div>
  );
}
MaxwellComponents.meta = { id: 'maxwell-components', lenses: ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
MaxwellComponents.data = (params = {}) => {
  const [k, d] = cellOfParams(params), C = cellPhysics(k, d), sg = signOf(C);
  const one = m => ({ N: m, role: C.blades[m].role, label: C.blades[m].label, sign: sg.get(m), blade: C.blades[m].name });
  return { cell: [k, d], axes: C.axes, counts: C.counts, components: C.components.field.map(one), sources: C.components.sources.map(one) };
};
