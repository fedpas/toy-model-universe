// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure maxwell-equations (caption EQN-006, the hero of Calibration 1; BUILD_CONTRACTS round 5, decision D29): the equations of ∇F = J in a cell Cl(k, d)
// of the 15 that maxwell_selfcheck.py stores, by name (Gauss, Ampère x, Faraday z, no monopole, …), each with its terms, as engines/maxwellPhysics.js recomputes
// them through the kernel and tests/maxwell.test.mjs ties them to checks/selfcheck/maxwell.json. At research level each equation is the stored text, typeset
// term by term with KaTeX (the text itself while KaTeX loads); at learner level the same terms read in words (equationWordParts: "the change of the electric
// field Ex along x … equals the charge ρ"; no other sentence). Every term carries the mark of its role (shape and word, never colour alone: a circle for a
// field component, filled with one time index (E) and a ring with none (B), a square with two (T); a diamond for a source, filled for ρ, a ring for J).
// Picking an equation lights the components it uses in the strip above the list, with the sign each carries in it. Folded below: the ladders of equation
// counts (the 15 cells, and the stored time and space ladders), the sign convention F, J, ∇ (an input: the page shows INP-011 with its badge; no badge is
// drawn here) and the stored checks with the mirror cell. The controls are v15's: time and space chips, the equation picker, the mirror.
import React, { useEffect, useMemo, useState } from 'react';
import { cellPhysics, cellsAvailable, roleName, nameAt, eqTokens, texTerm, texRhs, equationWordParts, algebraText, ladders } from '../../engines/maxwellPhysics.js';
import { useKatex, texToHtml } from '../app/math.js';
import { FigSvg, Controls, Chips, r1, sub } from './kit.jsx';
import './maxwell.css';

const KS = [1, 2, 3, 4], DS = [1, 2, 3, 4];
const STORED = new Set(cellsAvailable());
/** the cell the params ask for: k, d in 1 … 4 with k + d <= 7 (the stored cells), default (1, 3) */
export function cellOfParams(params = {}) {
  const k = KS.includes(params.k) ? params.k : 1;
  let d = DS.includes(params.d) ? params.d : 3;
  if (!STORED.has(`${k},${d}`)) d = Math.min(d, 7 - k);
  return [k, d];
}
/** the cell picker's state (v15: the time and space chips; a pick that would leave the stored cells moves the other number) */
export function useCell(params) {
  const [kd, setKD] = useState(() => cellOfParams(params));
  useEffect(() => { setKD(cellOfParams(params)); }, [params.k, params.d]);   // eslint-disable-line react-hooks/exhaustive-deps
  const pickK = v => setKD(([, d]) => [v, Math.min(d, 7 - v)]);
  const pickD = v => setKD(([k]) => [Math.min(k, 7 - v), v]);
  return { k: kd[0], d: kd[1], pickK, pickD, setKD };
}
export function CellChips({ cell, research }) {
  return (
    <>
      <Chips label={research ? 'time k' : 'time'} items={KS} value={cell.k} onPick={cell.pickK} param="k" mono />
      <Chips label={research ? 'space d' : 'space'} items={DS} value={cell.d} onPick={cell.pickD} param="d" mono />
    </>
  );
}

// ---------------------------------------------------------------- the marks of the roles
const LETTER = { E: 'E', B: 'B', T: 'T', rho: 'ρ', J: 'J' };
/** the shape of a role at (x, y): a circle for a field component (filled with one time index, a ring with none), a square for T, a diamond for a source */
export function RoleShape({ role, x = 0, y = 0, r = 4 }) {
  if (role === 'T') return <rect x={r1(x - r)} y={r1(y - r)} width={r1(2 * r)} height={r1(2 * r)} rx={1} className="mk-sq" />;
  if (role === 'rho' || role === 'J') { const q = r * 1.3; return <polygon points={`${r1(x)},${r1(y - q)} ${r1(x + q)},${r1(y)} ${r1(x)},${r1(y + q)} ${r1(x - q)},${r1(y)}`} className={role === 'rho' ? 'mk-fill' : 'mk-ring'} />; }
  return <circle cx={r1(x)} cy={r1(y)} r={r} className={role === 'E' || role === 'Faraday' ? 'mk-fill' : 'mk-ring'} />;
}
/** the mark inline with words (decorative: the word beside it names the role) */
export function RoleIcon({ role }) {
  return <svg className="mx-icon" viewBox="-6 -6 12 12" aria-hidden="true"><RoleShape role={role} r={4} /></svg>;
}
/** the roles a cell has, in the order of the legend */
export const rolesOf = C => ['E', 'B', 'T', 'rho', 'J'].filter(r => C.blades.some(b => b.role === r));
export function Legend({ C, level }) {
  return (
    <ul className="mx-legend" aria-label={level === 'learner' ? 'what the marks mean' : 'roles'}>
      {rolesOf(C).map(r => <li key={r}><RoleIcon role={r} /><b>{LETTER[r]}</b><span>{roleName(r, level)}</span></li>)}
    </ul>
  );
}
const subM = s => s.replace(/M(\d+)/g, (_, m) => 'M' + sub(m));
/** one line of numbers: the cell, its algebra, its generators, the components of F and the equations (research); the counts in words (learner) */
export function headLine(C, research) {
  const v = C.equations.filter(e => e.op === 'contract').length, t = C.equations.length - v, c = C.counts;
  const F = [`${c.E} E`, c.T ? `${c.T} T` : null, c.B ? `${c.B} B` : null].filter(Boolean).join(' + ');
  if (research) return `Cl(${C.k},${C.d}) ≅ ${subM(algebraText(C.algebra))} · ${C.axes.join(' ')} · F: ${F} · ∇F = J: ${v} + ${t} = ${v + t} equations`;
  return `${C.k} time, ${C.d} space directions · ${C.components.field.length} field pieces · ${C.equations.length} equations`;
}

// ---------------------------------------------------------------- an equation: its terms with KaTeX (research) or in words (learner)
function Tex({ tex, text, katex }) {
  const html = katex ? texToHtml(tex) : null;
  return html ? <span className="mx-tex" dangerouslySetInnerHTML={{ __html: html }} /> : <span className="mx-tex mx-plain">{text}</span>;
}
/** the stored equation, token by token (eqTokens), each term with the mark of its role; `hot` underlines the term of one component */
export function EqMath({ e, katex, hot = null }) {
  const T = eqTokens(e.eq);
  return (
    <span className="mx-math">
      {T.lhs.map((x, i) => {
        const L = e.lhs[i];
        return (
          <React.Fragment key={i}>
            {i || x.sign ? <span className="mx-op">{i ? x.sign : '−'}</span> : null}
            <span className={'mx-term' + (hot === L.source ? ' mx-hot' : '')} data-term-role={L.role} data-tex={texTerm(x)} title={`${roleName(L.role)} ${L.label}`}>
              <RoleIcon role={L.role} /><Tex tex={texTerm(x)} text={x.text} katex={katex} />
            </span>
          </React.Fragment>
        );
      })}
      <span className="mx-op">=</span>
      {e.rhs
        ? <span className={'mx-term' + (hot === e.rhs.N ? ' mx-hot' : '')} data-term-role={e.rhs.role} data-tex={texRhs(T.rhs)} title={`${roleName(e.rhs.role)} ${e.rhs.label}`}><RoleIcon role={e.rhs.role} /><Tex tex={texRhs(T.rhs)} text={T.rhs.text} katex={katex} /></span>
        : <span className="mx-term" data-term-role="zero" data-tex={texRhs(T.rhs)}><Tex tex="0" text="0" katex={katex} /></span>}
    </span>
  );
}
/** the same equation in words, each term with its mark */
export function EqWords({ e, level = 'learner', hot = null }) {
  const parts = equationWordParts(e, level);
  return (
    <span className="mx-words" data-words={parts.map(p => p.sep + p.text).join('')}>
      {parts.map((p, i) => <React.Fragment key={i}>{p.sep}<span className={hot !== null && hot === p.source ? 'mx-hot' : undefined}>{p.role ? <RoleIcon role={p.role} /> : null}{p.text}</span></React.Fragment>)}
    </span>
  );
}

// ---------------------------------------------------------------- the strip: the components and sources of the cell, lit by the picked equation
function Strip({ C, cur, level, row }) {
  const W = 420, x0 = 40, rh = 54, top = 4;
  const rows = [['ρ J', C.components.sources], ['E', C.components.field.filter(m => C.blades[m].role === 'E')], ['T', C.components.field.filter(m => C.blades[m].role === 'T')], ['B', C.components.field.filter(m => C.blades[m].role === 'B')]].filter(([, l]) => l.length);
  const step = Math.min(64, (W - x0 - 8) / Math.max(...rows.map(([, l]) => l.length)));
  const H = top + rows.length * rh + 2;
  const used = new Map(cur.lhs.map(x => [x.source, x.coef])), rhs = cur.rhs ? cur.rhs.N : null;
  return (
    <FigSvg id="maxwell-equations" row={row} part={`the components of F and the sources J in Cl(${C.k},${C.d}); lit: ${cur.name}`} viewBox={`0 0 ${W} ${H}`}>
      {rows.map(([lab, list], j) => {
        const y = top + j * rh + 24;
        return (
          <g key={lab} data-strip-row={lab}>
            <text x={4} y={r1(y + 4.5)} className="mx-role" style={{ fontSize: '13px' }}>{lab}</text>
            {list.map((N, i) => {
              const x = x0 + i * step + step / 2, b = C.blades[N], on = used.has(N) || N === rhs, sg = used.has(N) ? used.get(N) : N === rhs ? cur.rhs.sign : 0;
              return (
                <g key={N} className={on ? undefined : 'mx-faint'} data-strip={N} data-lit={on ? 1 : 0}>
                  <title>{`${b.label}: ${roleName(b.role, level)}${on ? (N === rhs ? ' (right side)' : ' (a term)') : ''}`}</title>
                  {on ? <circle cx={r1(x)} cy={r1(y)} r={11.5} className={N === rhs ? 'mk-halo-rhs' : 'mk-halo'} /> : null}
                  <RoleShape role={b.role} x={x} y={y} r={6} />
                  {on ? <text x={r1(x + 13)} y={r1(y - 8)} textAnchor="middle" className="t-mono" style={{ fontSize: '12px', fontWeight: 600 }}>{sg > 0 ? '+' : '−'}</text> : null}
                  <text x={r1(x)} y={r1(y + 25)} textAnchor="middle" className="t-mono" style={{ fontSize: '11.5px' }}>{b.label}</text>
                </g>
              );
            })}
          </g>
        );
      })}
    </FigSvg>
  );
}

// ---------------------------------------------------------------- the folds: ladders, convention, checks and mirror
const yes = v => (v === true ? 'yes' : v === false ? 'no' : '—');
const signed = v => (v > 0 ? '+1' : v < 0 ? '−1' : '—');
function LadderFold({ C, research }) {
  const L = useMemo(() => ladders(), []);
  const at = (k, d) => L.cells.find(c => c.k === k && c.d === d) || null;
  return (
    <details data-fold="ladders">
      <summary>{research ? 'Ladders: the number of equations by (k, d), along time, along space' : 'How many equations each split has'}</summary>
      <div className="mx-body">
        <div className="fig-scroll">
          <table className="mx-table" data-ladder="cells">
            <caption>{research ? 'equations of ∇F = J, by (k, d)' : 'equations, by time and space'}</caption>
            <thead><tr><th>{research ? 'k \\ d' : 'time \\ space'}</th>{DS.map(d => <th key={d}>{d}</th>)}</tr></thead>
            <tbody>{KS.map(k => (
              <tr key={k}><th>{k}</th>{DS.map(d => { const c = at(k, d), cur = c && k === C.k && d === C.d; return <td key={d} className={cur ? 'mx-cur' : undefined} aria-current={cur ? 'true' : undefined} data-cell={c ? `${k},${d}` : undefined} title={c && research ? `${c.vector} + ${c.trivector}` : undefined}>{c ? String(c.total) : '·'}</td>; })}</tr>
            ))}</tbody>
          </table>
        </div>
        {research ? (
          <div className="fig-scroll">
            <table className="mx-table" data-ladder="time">
              <caption>along time: Cl(k, 1)</caption>
              <thead><tr><th>k</th><th>Cl(k,1)</th><th>mirror Cl(1,k)</th><th>F = E + T</th><th>∇F</th></tr></thead>
              <tbody>{L.time.map(r => { const cur = C.d === 1 && r.k === C.k; return <tr key={r.k} className={cur ? 'mx-cur' : undefined}><td>{r.k}</td><td>{subM(algebraText({ type: r.type, matrix_size: r.matrix_size }))}</td><td>{subM(algebraText({ type: r.mirror_type, matrix_size: r.mirror_matrix_size }))}</td><td>{`${r.F_components} = ${r.E_components} + ${r.T_components}`}</td><td>{`${r.equations_vector} + ${r.equations_trivector} = ${r.equations_total}`}</td></tr>; })}</tbody>
            </table>
          </div>
        ) : null}
        {research ? (
          <div className="fig-scroll">
            <table className="mx-table" data-ladder="space">
              <caption>along space: Cl(1, d)</caption>
              <thead><tr><th>d</th><th>Cl(1,d)</th><th>F = E + B</th><th>∇F</th></tr></thead>
              <tbody>{L.space.map(r => { const cur = C.k === 1 && r.d === C.d; return <tr key={r.d} className={cur ? 'mx-cur' : undefined}><td>{r.d}</td><td>{subM(algebraText({ type: r.type, matrix_size: r.matrix_size }))}</td><td>{`${r.F_components} = ${r.E_components} + ${r.B_components}`}</td><td>{`${r.equations_vector} + ${r.equations_trivector} = ${r.equations_total}`}</td></tr>; })}</tbody>
            </table>
          </div>
        ) : null}
      </div>
    </details>
  );
}
function ConventionFold({ C }) {
  const cv = C.conventions;
  return (
    <details data-fold="convention">
      <summary>Sign convention <span className="mx-tag">convention · INP-011</span></summary>
      <div className="mx-body">
        <dl className="mx-kv">
          <dt>∇</dt><dd>{cv.grad}</dd>
          <dt>F</dt><dd>{cv.F}</dd>
          <dt>J</dt><dd>{cv.J}</dd>
          <dt>signs</dt><dd>{cv.field_order.map((f, i) => `${cv.signs[i] > 0 ? '+' : '−'}${f}`).join(' ')}</dd>
          <dt>found</dt><dd>{cv.found}</dd>
        </dl>
      </div>
    </details>
  );
}
/** the label of the mirror cell (d, k) that corresponds to a label of (k, d): time and space generators swap (v15 MaxwellSection: the same equation in the mirror) */
export function mirrorLabel(m, k, d) {
  let out = 0;
  for (let i = 0; i < k + d; i++) if ((m >> i) & 1) out |= 1 << (i < k ? d + i : i - k);
  return out;
}
function ChecksFold({ C, cur }) {
  const M = cellPhysics(C.d, C.k), meq = M ? M.byTarget.get(mirrorLabel(cur.target, C.k, C.d)) : null, ch = C.checks, mi = C.mirror;
  return (
    <details data-fold="checks">
      <summary>Checks and the mirror</summary>
      <div className="mx-body">
        <dl className="mx-kv" data-checks={[ch.wave_equation, ch.only_grades_1_and_3, ch.charge_conservation, ch.conventions].join(',')}>
          <dt>wave equation</dt><dd>{yes(ch.wave_equation)}</dd>
          <dt>only grades 1 and 3</dt><dd>{yes(ch.only_grades_1_and_3)}</dd>
          <dt>charge conservation</dt><dd>{yes(ch.charge_conservation)}</dd>
          <dt>conventions found</dt><dd>{ch.conventions}</dd>
          {C.covariantAgrees !== null ? <><dt>covariant form agrees</dt><dd>{yes(C.covariantAgrees)}</dd></> : null}
          <dt>mirror</dt><dd>{`Cl(${mi.mirror_of[0]},${mi.mirror_of[1]}) ≅ ${M ? subM(algebraText(M.algebra)) : ''} · δF = J × ${signed(mi.vector_equations_factor)} · dF = 0 × ${signed(mi.triple_equations_factor)}`}</dd>
          {meq ? <><dt>{`${cur.name}, mirrored`}</dt><dd>{`${meq.name}: ${meq.eq}`}</dd></> : null}
        </dl>
      </div>
    </details>
  );
}

// ---------------------------------------------------------------- the figure
export default function MaxwellEquations({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const cell = useCell(params), C = cellPhysics(cell.k, cell.d);
  const [eqId, setEqId] = useState(typeof params.eq === 'string' ? params.eq : null);
  useEffect(() => { setEqId(typeof params.eq === 'string' ? params.eq : null); }, [params.eq]);
  const katex = useKatex(research);
  const cur = C.equations.find(e => e.id === eqId) || C.equations[0];
  const groups = [
    { op: 'contract', title: research ? 'grade 1: δF = J, with a source' : 'with a charge or a current on the right', list: C.equations.filter(e => e.op === 'contract') },
    { op: 'wedge', title: research ? 'grade 3: dF = 0' : 'with zero on the right', list: C.equations.filter(e => e.op === 'wedge') },
  ];
  const toMirror = () => { const t = mirrorLabel(cur.target, C.k, C.d), M = cellPhysics(C.d, C.k); cell.setKD([C.d, C.k]); if (M && M.byTarget.get(t)) setEqId(M.byTarget.get(t).id); };
  return (
    <div className="fig fig-mx fig-maxwell-equations" data-cell={`${C.k},${C.d}`} data-eq-picked={cur.id}>
      <Controls label="Maxwell: the cell">
        <CellChips cell={cell} research={research} />
        {C.k !== C.d ? <button type="button" className="fig-btn" data-param="mirror" onClick={toMirror}>{`the mirror (${C.d}, ${C.k})`}</button> : null}
      </Controls>
      <p className="mx-head" data-head>{headLine(C, research)}</p>
      <Strip C={C} cur={cur} level={level} row={row} />
      <Legend C={C} level={level} />
      {research ? (
        <div className={'mx-eqs' + (C.equations.length > 16 ? ' mx-long' : '')} role="group" aria-label="the equations of the cell">
          {groups.map(g => (
            <section key={g.op} data-group={g.op}>
              <h4 className="mx-eqhead">{g.title}<span>{g.list.length}</span></h4>
              <ul className="mx-eqlist">
                {g.list.map(e => (
                  <li key={e.id}>
                    <button type="button" className="mx-eq" data-param="eq" data-eq-id={e.id} data-eq={e.eq} aria-pressed={e.id === cur.id} onClick={() => setEqId(e.id)}>
                      <span className="mx-eqname">{nameAt(e, level)}</span>
                      <EqMath e={e} katex={katex} />
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      ) : (
        <div className="mx-eqs" role="group" aria-label="the equations">
          {groups.map(g => (
            <section key={g.op} data-group={g.op}>
              <h4 className="mx-eqhead">{g.title}<span>{g.list.length}</span></h4>
              <div className="mx-chips">
                {g.list.map(e => <button key={e.id} type="button" className="fig-btn" data-param="eq" data-eq-id={e.id} aria-pressed={e.id === cur.id} onClick={() => setEqId(e.id)}>{nameAt(e, level)}</button>)}
              </div>
            </section>
          ))}
          <p className="fig-note mx-picked" data-picked-words={cur.id}><b className="mx-eqname">{nameAt(cur, level)}</b> <EqWords e={cur} level={level} /></p>
        </div>
      )}
      {research && C.equations.length > 16 ? <p className="mx-counts" data-scroll-note>{`${C.equations.length} equations: the list scrolls`}</p> : null}
      <div className="mx-more">
        <LadderFold C={C} research={research} />
        {research ? <ConventionFold C={C} /> : null}
        {research ? <ChecksFold C={C} cur={cur} /> : null}
      </div>
    </div>
  );
}
MaxwellEquations.meta = { id: 'maxwell-equations', lenses: [], learner: true };
/** the numbers the figure prints, for the frame's data download */
MaxwellEquations.data = (params = {}) => {
  const [k, d] = cellOfParams(params), C = cellPhysics(k, d);
  return { cell: [k, d], axes: C.axes, counts: C.counts, conventions: C.conventions, checks: C.checks, mirror: C.mirror, equations: C.equations.map(({ id, name, eq, op, target, terms }) => ({ id, name, eq, op, target, terms })) };
};
