// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure ladders (the Furey papers): the two ladders of reflections of the Roadmap papers as furey_papers_check.py stores them (engines/stored.js FUREY_PAPERS
// roadmap, nothing recomputed). Top: the Spin(10) line, 45 → 21 → 15 → 11 → 10; middle: the SU(5) line, 24 → 12 → 10 → 9; each bar is the dimension of what is
// left after the reflections switched on so far (𝕆, 𝕆′, ℍ, ℂ). Bottom: the Part III shortcuts, the dimensions of four intersections (24, 12, 9, 9). The control is
// v15's slider of the number of reflections switched on, as chips at both levels (interactive entry k); the bars of that step are solid and its reflections are printed. Port of v15
// FureyWidgets.Cascade. D37 (the Atlas method), read from the top: between two rungs the reflection that restricts the rung above to the one below is named
// (+𝕆 …; engines/physics/furey.js papersLadder checks that the lists are nested), and the SU(5) line, which stores three reflections, has no rung at four: that
// slot is drawn empty and marked "not stored", never filled with the rung before it. At learner level the same bars in words, the ladders named A and B,
// and the number of reflections (mirrors) as the same chips.
import React, { useState, useEffect } from 'react';
import { FUREY_PAPERS } from '../../engines/stored.js';
import { papersLadder } from '../../engines/physics/furey.js';
import { FigSvg, Controls, Chips, r1, pick } from './kit.jsx';

const R = FUREY_PAPERS.roadmap;
const REFL = { O: '𝕆', Or: '𝕆′', H: 'ℍ', C: 'ℂ' };
const SHORT = [['vector_spinor', 'spinor intersection', 'start'], ['three_way_O', 'three-way with 𝕆', 'three mirrors'], ['four_way_no_O', 'four-way without 𝕆', 'four mirrors'], ['five_way_O_H_C', 'five-way (𝕆, ℍ, ℂ)', 'five mirrors']];
const shortName = nm => (nm.includes('=') ? nm.split('=')[1].trim() : nm).replace(/ \(->O\)$/, '').replace(/\+/g, '⊕').replace('Pati-Salam', 'Pati–Salam').replace('Left-Right', 'Left–Right');
const refl = list => list.map(r => REFL[r] || r).join(', ') || '—';
const SLOTS = 5;

export default function Ladders({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [k, setK] = useState(pick(params.k, v => Number.isInteger(v) && v >= 0 && v <= 4, 0));
  useEffect(() => { setK(pick(params.k, v => Number.isInteger(v) && v >= 0 && v <= 4, 0)); }, [params.k]);
  const lines = [[research ? 'Spin(10) line' : 'Ladder A', papersLadder('spin10'), 45, 24, 'spin10'], [research ? 'SU(5) line' : 'Ladder B', papersLadder('su5'), 24, 132, 'su5']];
  const bar = (list, max, y0, kk, key) => list.map((s, j) => {
    const x = 34 + j * 76, h = 64 * s.dim / max, on = j === kk;
    return (
      <g key={key + j} data-line={key} data-step={j} data-dim={s.dim} data-on={on ? 1 : 0}>
        <title>{research ? `${shortName(s.name)}: dimension ${s.dim}; reflections ${refl(s.refl)}` : `${s.dim} turns left after ${j} mirror${j === 1 ? '' : 's'}`}</title>
        <rect x={x} y={r1(y0 + 64 - h)} width={58} height={r1(h)} rx={3} className="ink" style={{ fillOpacity: on ? 0.85 : 0.18, stroke: 'var(--fg)', strokeWidth: on ? 1.6 : 0.6 }} />
        <text x={x + 29} y={r1(Math.min(y0 + 58, y0 + 64 - h + 13))} textAnchor="middle" className="t-mono t-small t-bold" style={on ? { fill: 'var(--panel)' } : undefined}>{s.dim}</text>
        <text x={x + 29} y={y0 + 78} textAnchor="middle" className="t-micro">{research ? shortName(s.name) : String(j)}</text>
      </g>
    );
  });
  const steps = (list, y0, key) => list.slice(1).map(s => (
    <text key={key + 's' + s.j} x={34 + s.j * 76 - 9} y={y0 + 22} textAnchor="middle" className="t-micro t-muted" data-restrict={`${key},${s.j},${s.added.join('+')}`} data-nested={s.nested ? 1 : 0}>{research ? `+${s.added.map(r => REFL[r] || r).join('')}` : '+1'}</text>
  ));
  const empty = (list, y0, key) => Array.from({ length: SLOTS - list.length }, (_, i) => list.length + i).map(j => (
    <g key={key + 'e' + j} data-empty={`${key},${j}`}>
      <rect x={34 + j * 76} y={y0 + 10} width={58} height={54} rx={3} className="on-panel" style={{ stroke: 'var(--muted)', strokeDasharray: '4 3' }} />
      <text x={34 + j * 76 + 29} y={y0 + 41} textAnchor="middle" className="t-micro t-muted">not stored</text>
    </g>
  ));
  const A = lines[0][1], B = lines[1][1], kA = Math.min(k, A.length - 1), kB = k < B.length ? k : null;
  return (
    <div className="fig fig-ladders">
      <FigSvg id="ladders" row={row} viewBox="0 0 420 334">
        {lines.map(([name, list, max, y0, key], i) => (
          <g key={key}>
            <text x={4} y={y0 - 8} className="t-small t-muted">{name}</text>
            {bar(list, max, y0, i === 0 ? kA : kB, key)}
            {steps(list, y0, key)}
            {empty(list, y0, key)}
          </g>
        ))}
        <text x={4} y={238} className="t-mono t-tiny" data-k={k} data-su5={kB === null ? 'not stored' : B[kB].dim}>
          {research ? `${k} reflection${k === 1 ? '' : 's'}: ${refl(A[kA].refl)} → ${A[kA].dim} · ${kB === null ? 'SU(5) line: not stored' : `${refl(B[kB].refl)} → ${B[kB].dim}`}`
            : `mirrors switched on: ${k} · turns left: ${A[kA].dim} · ${kB === null ? 'not stored' : B[kB].dim}`}
        </text>
        <text x={4} y={254} className="t-small t-muted">{research ? 'Part III shortcuts (intersections)' : 'the shortcuts of the third paper'}</text>
        {SHORT.map(([key, name, plain], j) => { const d = R.intersections[key], x = 34 + j * 96, h = 40 * d / 24; return (
          <g key={key} data-intersection={key} data-dim={d}>
            <rect x={x} y={r1(314 - h)} width={70} height={r1(h)} rx={3} className="ink" style={{ fillOpacity: 0.55 }} />
            <text x={x + 35} y={r1(314 - h - 4)} textAnchor="middle" className="t-mono t-small t-bold">{d}</text>
            <text x={x + 35} y={327} textAnchor="middle" className="t-micro">{research ? name : plain}</text>
          </g>); })}
      </FigSvg>
      <Controls label="reflections">
        <Chips label={research ? 'reflections switched on' : 'mirrors switched on'} items={[0, 1, 2, 3, 4]} value={k} onPick={setK} param="k" />
      </Controls>
    </div>
  );
}
Ladders.meta = { id: 'ladders', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
Ladders.data = () => ({ spin10_line: R.spin10_line, su5_line: R.su5_line, intersections: R.intersections, restrictions: { spin10: papersLadder('spin10').map(s => s.added), su5: papersLadder('su5').map(s => s.added) } });
