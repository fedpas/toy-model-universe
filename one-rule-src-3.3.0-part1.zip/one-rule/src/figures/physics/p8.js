// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p8.js — owner P8 registers its figures here (id → component): steps 9–12, gravity I and II, one more generator (docs/PHYSICS_AUDIT.md §2.9–§2.11).
import CurvaturePairs from './CurvaturePairs.jsx';
import EinsteinTerms from './EinsteinTerms.jsx';
import CosmologicalGenerator from './CosmologicalGenerator.jsx';
import NullPairMoves from './NullPairMoves.jsx';
export const P8_FIGURES = { 'curvature-pairs': CurvaturePairs, 'einstein-terms': EinsteinTerms, 'cosmological-generator': CosmologicalGenerator, 'null-pair-moves': NullPairMoves };
