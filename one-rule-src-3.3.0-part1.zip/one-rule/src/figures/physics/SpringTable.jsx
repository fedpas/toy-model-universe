// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spring-table (step 15, caption SPR-001; docs/PHYSICS_AUDIT.md SR3, SR4, SR6; decisions D35, D37): the spring on the cube in numbers, in three parts.
//  1. The lens ladder (v15's "three lenses and a rotor"): vertices x_i with L = n·I − adjacency, edges x_a − x_b with the energy ½ Σ stretch² and L = ∂₁∂₁ᵀ, faces
//     Σ around = 0 with ∂₁∂₂ = 0, the rotor s′ = ωBs with B² = −1, +1, 0: names and formulas, each with what the engine recomputes at every stored n
//     (engines/physics/springPhysics.js ladderMatrices, rotorOf: the matrices of the n-cube and the kernel's squares).
//  2. The rungs n = 2 … 5 of spring.json (content/stored_p9.json), the Atlas method of D37: from the lowest stored rung up, each drawn in the page's lens (cube,
//     Clifford, simplex, demicube, prime labels), and "from the top": the highest stored rung first, each lower rung drawn as the facet of the one above (the
//     vertices with the top bit 0). The numbers per rung: V, E, F, the Betti numbers and V − E + F, the levels ω² = 2j with their multiplicities, the Clifford
//     levels n ± √n (× 2ⁿ⁻¹); a block the script stored for one n only (the 256 label pairs at n = 4, the series at n = 3) is "not stored" elsewhere, never
//     extrapolated. V, E, F and the levels are the engine's until the table is read, then the stored ones (tests/physics/p9.test.mjs: equal); the Betti numbers
//     are the script's only (D11).
//  3. The 22 lines of the claim matrix (D35): the rows SPR-M01 … SPR-M22, each the line's claim and how it is checked, drawn by the shared TranslationMatrix
//     (P6): ids, threads, the checks and their result as spring.json stores them, the negative controls, the command that runs a line alone, the row's badge.
// Controls: "from the top" (D37), and the table's own (status, thread, badges: interactive entries of the seed; a line opens as a native details element).
// Shape and word, tokens only.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../../app/content.js';
import { lensLadder, rungsOf, rungOf, springLines, SPRING_THREADS, binom } from '../../../engines/physics/springPhysics.js';
import { project, edges } from '../../../engines/springEngine.js';
import { PRIMES, popcount } from '../../../engines/bitrule.js';
import { FigSvg, Controls, Toggle, r1 } from '../kit.jsx';
import TranslationMatrix from './TranslationMatrix.jsx';
import { storedSpring, hx } from './p9kit.jsx';
import './p9.css';

const STORED_NS = [2, 3, 4, 5];
const viewOf = lens => (lens === 'clifford' || lens === 'simplex' || lens === 'demicube' ? lens : lens === 'prime' || lens === 'primes' ? 'prime' : 'cube');
const VIEW_NAME = { cube: 'cube', clifford: 'Clifford', simplex: 'simplex', demicube: 'demicube', prime: 'prime labels' };
const sup = n => String(n).replace(/\d/g, d => '⁰¹²³⁴⁵⁶⁷⁸⁹'[d]);
const GW = 104, GH = 64;

/** one rung drawn in a lens: the n-structure, or (within) the (n + 1)-structure faint with the n-structure heavy — the rung as the restriction of the one above */
function RungGlyph({ n, view, within, row }) {
  const N = within ? n + 1 : n, low = x => !within || x < 1 << n, cls = on => (on ? 'stroke-ink' : 'hair');
  let body = null;
  if (view === 'cube' || view === 'demicube') {
    const E = edges(N);
    let pos;
    if (view === 'cube') {
      const U = Array.from({ length: 1 << N }, (_, x) => project(N, x, 1)), xs = U.map(p => p[0]), ys = U.map(p => p[1]);
      const k = Math.min(92 / Math.max(1e-9, Math.max(...xs) - Math.min(...xs)), 52 / Math.max(1e-9, Math.max(...ys) - Math.min(...ys)));
      const ox = GW / 2 - (Math.min(...xs) + Math.max(...xs)) / 2 * k, oy = GH / 2 - (Math.min(...ys) + Math.max(...ys)) / 2 * k;
      pos = U.map(p => [ox + p[0] * k, oy + p[1] * k]);
    } else {
      const ev = [], od = []; for (let x = 0; x < 1 << N; x++) (popcount(x) % 2 ? od : ev).push(x);
      const at = new Map(), step = 54 / Math.max(1, ev.length - 1 || 1);
      ev.forEach((x, i) => at.set(x, [30, ev.length > 1 ? 5 + i * step : GH / 2]));
      od.forEach((x, i) => at.set(x, [74, od.length > 1 ? 5 + i * step : GH / 2]));
      pos = Array.from({ length: 1 << N }, (_, x) => at.get(x));
    }
    body = (
      <>
        {E.map(([a, b]) => <line key={a + '-' + b} x1={r1(pos[a][0])} y1={r1(pos[a][1])} x2={r1(pos[b][0])} y2={r1(pos[b][1])} className={cls(low(a) && low(b))} style={{ strokeWidth: low(a) && low(b) ? 0.9 : 0.6 }} />)}
        {pos.map(([x, y], v) => <circle key={v} cx={r1(x)} cy={r1(y)} r={N >= 5 ? 1.2 : 1.7} className={low(v) ? 'ink' : 'on-panel'} style={low(v) ? undefined : { stroke: 'var(--line)', strokeWidth: 0.6 }} />)}
        {view === 'demicube' && <><text x={30} y={GH - 1} textAnchor="middle" className="t-micro t-muted">even</text><text x={74} y={GH - 1} textAnchor="middle" className="t-micro t-muted">odd</text></>}
      </>
    );
  } else if (view === 'clifford') {
    const cols = Array.from({ length: N + 1 }, (_, j) => Array.from({ length: 1 << N }, (_, x) => x).filter(x => popcount(x) === j));
    const dx = 92 / Math.max(1, N), mx = Math.max(...cols.map(c => c.length)), dy = Math.min(5.4, 48 / Math.max(1, mx - 1));
    body = cols.map((c, j) => (
      <g key={j}>
        {c.map((x, i) => <circle key={x} cx={r1(6 + j * dx)} cy={r1(28 + (i - (c.length - 1) / 2) * dy)} r={1.5} className={low(x) ? 'ink' : 'on-panel'} style={low(x) ? undefined : { stroke: 'var(--line)', strokeWidth: 0.6 }} />)}
        <text x={r1(6 + j * dx)} y={GH - 1} textAnchor="middle" className="t-micro t-muted">{j}</text>
      </g>
    ));
  } else if (view === 'simplex') {
    const V = Array.from({ length: N }, (_, i) => { const a = 2 * Math.PI * i / Math.max(N, 3) - Math.PI / 2 + (N === 2 ? Math.PI / 2 : 0); return N === 1 ? [GW / 2, GH / 2] : [GW / 2 + 26 * Math.cos(a), GH / 2 + 26 * Math.sin(a)]; });
    const on = i => !within || i < n;
    body = (
      <>
        {V.flatMap((p, i) => V.map((q, j) => (j > i ? <line key={i + '-' + j} x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className={cls(on(i) && on(j))} style={{ strokeWidth: on(i) && on(j) ? 1 : 0.6 }} /> : null)))}
        {V.map(([x, y], i) => <g key={i}><circle cx={r1(x)} cy={r1(y)} r={2.4} className={on(i) ? 'ink' : 'on-panel'} style={on(i) ? undefined : { stroke: 'var(--line)', strokeWidth: 0.8 }} /><text x={r1(x + (x >= GW / 2 ? 4 : -4))} y={r1(y + 3)} textAnchor={x >= GW / 2 ? 'start' : 'end'} className="t-micro t-muted">{i + 1}</text></g>)}
      </>
    );
  } else {
    body = (
      <>
        {Array.from({ length: N }, (_, i) => <g key={i}><circle cx={10 + i * 18} cy={24} r={7.5} className={!within || i < n ? 'stroke-ink' : 'hair'} style={{ strokeWidth: 1 }} /><text x={10 + i * 18} y={27} textAnchor="middle" className={!within || i < n ? 't-micro t-bold' : 't-micro t-muted'}>{PRIMES[i]}</text></g>)}
        <text x={2} y={50} className="t-micro t-muted">{`${1 << n} square-free labels`}</text>
      </>
    );
  }
  return (
    <FigSvg id="spring-table" row={row} part={`rung n = ${n} in the ${VIEW_NAME[view]} lens${within ? ', inside n = ' + (n + 1) : ''}`} viewBox={`0 0 ${GW} ${GH}`} className="p9-svg-cell">
      <g data-rung={n} data-view={view} data-within={within ? n + 1 : 0}>{body}</g>
    </FigSvg>
  );
}

export default function SpringTable({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const [T0] = useTable('stored_p9');
  const sr = storedSpring(params, T0);
  const [top, setTop] = useState(params.top === true);
  useEffect(() => { setTop(params.top === true); }, [params.top]);
  const view = viewOf(lens);
  const ns = sr ? rungsOf(sr) : STORED_NS;
  const order = top ? [...ns].reverse() : ns, highest = ns[ns.length - 1];
  const rungs = useMemo(() => ns.map(n => rungOf(sr, n)), [sr, ns.join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const steps = useMemo(() => { const per = ns.map(n => ({ n, L: lensLadder(n) })); return per[0].L.map((s, k) => ({ ...s, okAll: per.every(p => p.L[k].ok), counts: per.map(p => p.L[k].count) })); }, [ns.join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const lines = springLines(sr).map(l => ({
    id: l.id, left: '', right: '', badgeRow: l.row, group: l.thread, ref: l.control ? 'negative control' : undefined,
    status: l.ok === true ? 'ok' : l.ok === false ? 'fail' : '',
    detail: [['claims checked', l.checks == null ? null : String(l.checks), 'checks'], ['run alone', `python3 spring_selfcheck.py --row ${l.id}`, 'run']],
  }));
  const S = sr && sr.summary;
  const levels = ms => ms.map(m => `${m.w2} (${m.mult})`).join(' · ');
  return (
    <div className="fig p9 fig-spring-table">
      <ol className="p9-ladder" aria-label="three lenses and a rotor">
        {steps.map(s => (
          <li key={s.key} className="p9-step" data-step={s.key} data-ok={s.okAll ? 1 : 0} data-counts={s.counts.join(',')}>
            <b>{s.name}</b>
            <code>{hx(s.g)}</code>
            <code>{s.formula}</code>
            <span className="p9-muted">{`${s.key === 'rotor' ? 'three kinds' : `n = ${ns[0]}…${highest}: ${s.counts.join(', ')}`} ${s.okAll ? '✓' : '✗'}`}</span>
          </li>
        ))}
      </ol>
      <div className="fig-scroll">
        <table className="p9-table" data-order={top ? 'top' : 'up'} data-view={view}>
          <caption>{top ? `from the top: n = ${highest} → ${ns[0]}, each rung the facet of the one above (top bit 0) · ${VIEW_NAME[view]} lens` : `from the lowest stored rung: n = ${ns[0]} → ${highest} · ${VIEW_NAME[view]} lens`}</caption>
          <thead><tr><th className="p9-l">{VIEW_NAME[view]}</th><th>n</th><th>V</th><th>E</th><th>F</th><th>b₀, b₁, b₂</th><th>V − E + F</th><th className="p9-l">ω² = 2j (multiplicity)</th><th>Clifford levels</th><th>labels</th><th>series</th></tr></thead>
          <tbody>
            {order.map(n => {
              const R = rungs[ns.indexOf(n)], src = R.stored || R.engine, within = top && n < highest;
              return (
                <tr key={n} data-n={n} data-src={R.stored ? 'stored' : 'engine'} className={top && n === highest ? 'is-top' : undefined}>
                  <td className="p9-glyph"><RungGlyph n={n} view={view} within={within} row={row} /></td>
                  <td>{n}</td>
                  <td data-v={src.V}>{src.V}</td><td data-e={src.E}>{src.E}</td><td data-f={src.F}>{src.F}</td>
                  <td data-betti={R.stored ? R.stored.betti.join(',') : ''}>{R.stored ? R.stored.betti.join(', ') : '…'}</td>
                  <td data-euler={R.stored ? R.stored.euler : ''}>{R.stored ? R.stored.euler : '…'}</td>
                  <td className="p9-l p9-wrap" data-modes={src.modes.map(m => `${m.w2}:${m.mult}`).join(',')}>{levels(src.modes)}</td>
                  <td data-clifford={R.clifford ? `${R.clifford.levels},${R.clifford.each}` : ''}>{R.clifford ? `${R.clifford.levels.replace('+-', '±').replace(/sqrt\((\d+)\)/, '√$1')} (×${R.clifford.each})` : `${n} ± √${n} (×${R.engine.signed[0].mult})`}</td>
                  <td className={R.labels ? undefined : 'p9-ns'} data-labels={R.labels ? R.labels.pairs : ''}>{R.labels ? `${R.labels.pairs} pairs, ω² = ${R.labels.law.replace(/\s+/g, '')}` : sr ? 'not stored' : '…'}</td>
                  <td className={R.dynamics ? undefined : 'p9-ns'} data-series={R.dynamics ? `${R.dynamics.order},${R.dynamics.E0}` : ''}>{R.dynamics ? `order ${R.dynamics.order}, E₀ = ${R.dynamics.E0}` : sr ? 'not stored' : '…'}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
      {research && (
        <Controls label="the rungs">
          <Toggle label={top ? `from the top: n = ${highest} first` : 'from the top'} on={top} onChange={setTop} param="top" />
        </Controls>
      )}
      <TranslationMatrix rows={lines} level={level} lens={lens} mode={mode} figId="spring-table" row={row}
        title={`spring_selfcheck.py · ${lines.length} rows${S ? ` · ${S.ok} of ${S.rows} claims hold` : ''}`}
        columns={{ left: 'claim', right: 'how it is checked' }} statusWords={{ ok: 'checked', fail: 'fails' }}
        groups={SPRING_THREADS.map(k => ({ key: k, name: k }))}
        initial={{ status: params.status, group: params.thread, open: params.open, badges: params.badges === true }} />
    </div>
  );
}
SpringTable.meta = { id: 'spring-table', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: false };
SpringTable.params = [{}, { top: true }, { thread: 'faces', open: 'B2' }, { badges: true, status: 'ok' }];
/** the numbers the figure draws, for the frame's data download (the engine's part; the stored part is content/stored_p9.json) */
SpringTable.data = (params = {}) => ({ top: params.top === true, ladder: STORED_NS.map(n => ({ n, steps: lensLadder(n).map(({ key, count, ok }) => ({ key, count, ok })), rung: rungOf(null, n).engine, binom: Array.from({ length: n + 1 }, (_, j) => binom(n, j)) })), lines: springLines(null) });
