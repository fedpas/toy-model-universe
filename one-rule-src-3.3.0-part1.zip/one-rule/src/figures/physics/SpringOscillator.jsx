// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spring-oscillator (step 15, caption EQN-018; docs/PHYSICS_AUDIT.md SR1): one spring, one rotor. Pick the squares of two generators, u² = a and v² = b:
// the bit rule gives B = uv and its square B² = −ab (engines/physics/springPhysics.js rotorOf, through the kernel), and the phase vector s = xu + qv follows
// s′ = ωBs, so x″ = −ab·ω²x: a circle for (+, +), a hyperbola for (+, −), a straight line for (0, +) in the phase plane (x across, q up). The dot is the state at
// t, the curve its orbit (springEngine.oscillator, ω = 1, x₀ = 3, q₀ = 2, as v15). The readouts: B², the law, x and q, the two sandwiches computed live (the half
// angle R = exp(ωtB/2) reproduces the motion; the full angle does not), the invariant s² = x² + q² of the spring, and the script's run (spring.json oscillator:
// B², the coefficient of x″, the exact series; content/stored_p9.json). tests/physics/p9.test.mjs recomputes B² with the kernel and ties the rest to the stored
// json. Controls, as in v15 OscillatorI: the kind chips, the time (a slider at research level) and play (paused until pressed). Tokens only.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../../app/content.js';
import { OSC, rotorOf, oscillatorAt } from '../../../engines/physics/springPhysics.js';
import { FigSvg, Controls, Chips, Range, PlayButton, useReducedMotion, r1, arrowHead, pick, isIn } from '../kit.jsx';
import { storedSpring } from './p9kit.jsx';
import './p9.css';

const KIND_NAME = { harmonic: 'Spring (+, +)', inverted: 'Inverted spring (+, −)', free: 'Free (0, +)' };
const ORBIT = { harmonic: 'circle', inverted: 'hyperbola', free: 'straight line' };
const sgn = v => (v < 0 ? '−' + Math.abs(v) : String(v));
const f2 = v => { const x = Math.abs(v) < 5e-5 ? 0 : Math.round(v * 100) / 100; return String(x).replace('-', '−'); };
const ttOf = v => (Number.isInteger(v) && v >= 0 && v <= OSC.tMax ? v : OSC.tStart);

const W = 420, H = 250, CX = 150, CY = 125, SC = 19, XM = 13.5, QM = 6.2;
const inside = ([x, q]) => Math.abs(x) <= XM && Math.abs(q) <= QM;

export default function SpringOscillator({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [T0] = useTable('stored_p9');
  const sr = storedSpring(params, T0);
  const [kind, setKind0] = useState(pick(params.kind, isIn(OSC.kinds), 'harmonic'));
  const [tt, setTt] = useState(ttOf(params.t));
  useEffect(() => { setKind0(pick(params.kind, isIn(OSC.kinds), 'harmonic')); setTt(ttOf(params.t)); }, [params.kind, params.t]);
  const [playing, setPlaying] = useState(false), reduced = useReducedMotion();
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => setTt(x => (x >= OSC.tMax ? 0 : x + 1)), 70); return () => clearInterval(id); }, [playing, reduced]);
  const player = { playing, reduced, play: () => setPlaying(on => !on), step: () => setTt(x => (x + 6 > OSC.tMax ? 0 : x + 6)) };
  const R = rotorOf(kind), o = oscillatorAt(kind, tt), st = sr && sr.oscillator ? sr.oscillator[kind] : null;
  const segs = useMemo(() => { const out = []; let cur = []; for (const p of o.path) { if (inside(p)) cur.push(p); else if (cur.length) { out.push(cur); cur = []; } } if (cur.length) out.push(cur); return out; }, [kind]);   // eslint-disable-line react-hooks/exhaustive-deps
  const P = ([x, q]) => [CX + SC * x, CY - SC * q], here = [o.x, o.q], shown = inside(here);
  const edge = shown ? null : (() => { const k = Math.min(XM / Math.max(1e-9, Math.abs(o.x)), QM / Math.max(1e-9, Math.abs(o.q))), e = [o.x * k, o.q * k], from = [e[0] * 0.86, e[1] * 0.86]; return { e, from }; })();
  const w2 = st && st.B_squared !== 0 ? st.x_double_dot_coefficient / st.B_squared : null;
  return (
    <div className="fig p9 fig-spring-oscillator">
      <FigSvg id="spring-oscillator" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-kind={kind} data-bsq={R.Bsq} data-t={o.t.toFixed(1)}>
          <line x1={CX - SC * XM} y1={CY} x2={CX + SC * XM} y2={CY} className="hair" />
          <line x1={CX} y1={CY - SC * QM} x2={CX} y2={CY + SC * QM} className="hair" />
          <text x={CX + SC * XM - 2} y={CY - 4} textAnchor="end" className="t-small t-muted">x</text>
          <text x={CX + 5} y={CY - SC * QM + 10} className="t-small t-muted">q</text>
          {segs.map((sgm, i) => <polyline key={i} points={sgm.map(p => P(p).map(r1).join(',')).join(' ')} className="stroke-ink" style={{ strokeWidth: 1.8, strokeOpacity: 0.85 }} data-orbit={ORBIT[kind]} />)}
          {shown
            ? <circle cx={r1(P(here)[0])} cy={r1(P(here)[1])} r={5.5} className="ink" data-state={`${f2(o.x)},${f2(o.q)}`} />
            : <path d={arrowHead(...P(edge.from), ...P(edge.e), 9)} className="ink" data-state={`${f2(o.x)},${f2(o.q)}`} data-off="1" />}
          <text x={CX + SC * XM - 2} y={20} textAnchor="end" className="t-small t-bold">{ORBIT[kind]}</text>
          <text x={CX + SC * XM - 2} y={34} textAnchor="end" className="t-tiny t-mono t-muted">{`B² = ${sgn(R.Bsq)}`}</text>
        </g>
      </FigSvg>
      <div className="p9-readout">
        <p data-sig={`${R.a},${R.b},${R.Bsq}`}>{`u² = ${sgn(R.a)}, v² = ${sgn(R.b)} → B = uv, B² = ${sgn(R.Bsq)}`}</p>
        <p data-law={o.law}>{`x″ = ${f2(o.law)}·x (ω = ${OSC.w})`}</p>
        <p data-xq={`${f2(o.x)},${f2(o.q)}`}>{`t = ${o.t.toFixed(1)} · x = ${f2(o.x)}, q = ${f2(o.q)}`}</p>
        <p data-half={o.okHalf ? 1 : 0} data-full={o.okFull ? 1 : 0}>{`half angle R = exp(ωtB/2): R s R̃ = s(t) ${o.okHalf ? '✓' : '✗'}${o.t > 0.05 ? ` · full angle exp(ωtB): ≠ s(t) ${!o.okFull ? '✓' : '✗'}` : ''}`}</p>
        {kind === 'harmonic' && <p data-s2={f2(o.s2)}>{`s² = x² + q² = ${f2(o.s2)} at every t`}</p>}
        {research && st && <p className="p9-muted" data-stored={`${st.B_squared},${st.x_double_dot_coefficient},${st.ode_exact ? 1 : 0}`}>{`spring.json (exact series): B² = ${sgn(st.B_squared)} · x″ = ${sgn(st.x_double_dot_coefficient)}·x${w2 ? ` (ω² = ${w2})` : ''} · ${st.ode_exact ? 'ode exact ✓' : 'ode not exact'}`}</p>}
      </div>
      <Controls label="one spring">
        <Chips label="kind" items={OSC.kinds} value={kind} onPick={k => setKind0(k)} render={k => KIND_NAME[k]} param="kind" />
        {research && <Range label="time" value={tt} min={0} max={OSC.tMax} step={1} onChange={v => setTt(ttOf(Math.round(v)))} display={v => `t = ${(v / 10).toFixed(1)}`} param="t" />}
        <PlayButton player={player} />
      </Controls>
    </div>
  );
}
SpringOscillator.meta = { id: 'spring-oscillator', lenses: [], learner: false };
SpringOscillator.params = [{}, { kind: 'inverted', t: 18 }, { kind: 'free', t: 0 }, { kind: 'free', t: 63 }, { kind: 'harmonic', t: 63 }];
/** the numbers the figure draws, for the frame's data download */
SpringOscillator.data = (params = {}) => { const kind = pick(params.kind, isIn(OSC.kinds), 'harmonic'), o = oscillatorAt(kind, ttOf(params.t)); return { kind, rotor: rotorOf(kind), t: o.t, x: o.x, q: o.q, law: o.law, okHalf: o.okHalf, okFull: o.okFull, s2: o.s2, orbit: o.path }; };
