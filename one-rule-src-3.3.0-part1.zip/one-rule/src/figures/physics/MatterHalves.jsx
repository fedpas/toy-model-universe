// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure matter-halves (step 8, hero of steps/matter; audit MT1, MT6): the gauge action on the internal blades. The even and the odd blades of Cl(0,m) (two halves,
// a filled dot and a ring); a line joins two blades that differ in two bits — a demicube edge, where a generator B_ab acts by left multiplication. Each generator is
// a perfect matching of each half (2^{m−2} lines), with B_ab e_T = ± e_{ab⊕T}, the sign the kernel's (engines/physics/gauge.js leftAction, matching). The counts are
// the stored ones (content/stored_p7.json mt.ladder, matter_selfcheck.py), tied to the kernel in tests/physics/p7.test.mjs. Port of v15 MatterSection.jsx Halves,
// with its chips m and its generator chips; up to m = 5 the halves are drawn as rings (v15), from m = 6 as grids of 16 columns, a generator's lines drawn when it is
// picked. D37: the chips run from the lowest stored cell up; "from the top" draws the halves of Cl(0,8) and the chosen Cl(0,m) as its restriction: the blades of the
// first m indices, which are the first rows of each grid, the rest faint. Lenses: clifford, simplex, cube, demicube, prime print the blades in their base; cube and
// demicube add the corners of the current (matter.json current_corner_masks and distances at n = 4: our reading, MAT-008). Learner level: blades as rows of switches.
import React, { useEffect, useMemo, useState } from 'react';
import { soAlgebra, matching, halfEdges, internalHalves, labelIn, genName, nodeName, switchRow, restricts, GAUGE_MS, AXES } from '../../../engines/physics/gauge.js';
import { FigSvg, Controls, Chips, r1 } from '../kit.jsx';
import { useStored, lensKey, intIn, Tex, Rungs, TopSwitch, Readout, Legend, useKatexAt } from './GaugeKit.jsx';

const TOP = 8, COLS = 16;
const within = (g, m) => g < 2 ** m;
const eTex = T => (T === 0 ? '1' : `e_{${genName(T)}}`), ePlain = T => (T === 0 ? '1' : `e${genName(T)}`);
/** the place of every blade of Cl(0, N): rings up to N = 5 (v15), grids of 16 columns from N = 6 (the blades of the first m indices are the first rows) */
function layoutOf(N) {
  const halves = internalHalves(N), pos = new Map();
  if (N <= 5) {
    const R = N === 5 ? 64 : 58;
    halves.forEach((nodes, h) => nodes.forEach((x, k) => { const a = ((-90 + (360 * k) / nodes.length) * Math.PI) / 180; pos.set(x, [90 + 180 * h + R * Math.cos(a), 104 + R * Math.sin(a)]); }));
    return { halves, pos, ring: true, H: 206, cy: 104, R };
  }
  const dx = 9.6, dy = 11.5, x0 = [16, 190], rows = halves[0].length / COLS;
  halves.forEach((nodes, h) => nodes.forEach((x, k) => pos.set(x, [x0[h] + (k % COLS) * dx, 30 + Math.floor(k / COLS) * dy])));
  return { halves, pos, ring: false, H: 30 + rows * dy + 24, rows, x0, dx };
}

export default function MatterHalves({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => { const top = params.top === true, m = intIn(params.m, GAUGE_MS, top ? TOP : 3); return { m, top, gen: soAlgebra(m).gens.includes(params.gen) ? params.gen : null }; };
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.m, params.top, params.gen]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { m, top, gen } = st, drawN = top ? TOP : m;
  const Lay = useMemo(() => layoutOf(drawN), [drawN]), gens = soAlgebra(m).gens;
  const edges = useMemo(() => (Lay.ring && gen == null ? [0, 1].flatMap(h => halfEdges(drawN, h)) : []), [Lay, drawN, gen]);
  const match = useMemo(() => (gen == null ? null : matching(drawN, gen)), [drawN, gen]);
  const matchM = useMemo(() => (gen == null ? null : matching(m, gen)), [m, gen]);
  const restr = useMemo(() => (top && m < TOP ? restricts('internal', m, TOP) : null), [top, m]);
  const lad = S ? S.mt.ladder[String(m)] : null;
  const live = T => within(T, m);
  const name = T => (L ? labelIn(L, T, { n: drawN, kind: 'int' }) : research ? nodeName(T) : switchRow(T, drawN));
  const gname = g => (L ? labelIn(L, g, { n: m, kind: 'int' }) : genName(g));
  const perGen = 2 ** (m - 2), linesPerHalf = gens.length * perGen, showLabels = Lay.ring && Lay.halves[0].length <= 8;
  const line = (a, b, cls, key, data) => <line key={key} x1={r1(Lay.pos.get(a)[0])} y1={r1(Lay.pos.get(a)[1])} x2={r1(Lay.pos.get(b)[0])} y2={r1(Lay.pos.get(b)[1])} className={cls} {...data} />;
  const masks = lad ? lad.current_corner_masks : null, dists = lad ? lad.current_corner_distance : null;
  return (
    <div className="fig fig-matter-halves g7-split" data-m={m} data-top={top ? 'true' : 'false'} data-lens={L || ''} data-gen={gen == null ? '' : gen}>
      <div className="g7-left">
        <FigSvg id="matter-halves" row={row} viewBox={`0 0 360 ${r1(Lay.H)}`} data-drawn={drawN} data-layout={Lay.ring ? 'rings' : 'grids'}>
          {edges.map(([a, b]) => line(a, b, 'g7-line' + (top && !(live(a) && live(b)) ? ' g7-faint' : ''), `e${a}-${b}`, { 'data-edge': `${a},${b}`, 'data-gen': a ^ b, style: { strokeOpacity: drawN > 4 ? 0.3 : 0.5 } }))}
          {match && match.map((pairs, h) => pairs.map(p => line(p.a, p.b, 'g7-line ' + (live(p.a) ? 'is-on' : 'g7-faint'), `m${h}-${p.a}`, { 'data-match': `${h},${p.a},${p.b},${p.sign}` })))}
          {Lay.halves.map((nodes, h) => (
            <g key={h} data-half={h ? 'odd' : 'even'} data-count={nodes.length}>
              {nodes.map(T => {
                const [x, y] = Lay.pos.get(T), cx = Lay.ring ? 90 + 180 * h : 0, right = Lay.ring && x >= cx;
                return (
                  <g key={T} data-blade={T} className={live(T) ? '' : 'g7-faint'}>
                    <circle cx={r1(x)} cy={r1(y)} r={Lay.ring ? 4.2 : 2.9} className={h ? 'g7-ring' : 'g7-dot'} style={Lay.ring ? undefined : { strokeWidth: 1 }} />
                    <title>{`${name(T)}${research && !L ? '' : ` (${nodeName(T)})`}`}</title>
                    {showLabels && <text x={r1(x + (right ? 8 : -8))} y={r1(y + 3.5)} textAnchor={right ? 'start' : 'end'} className="t-tiny t-mono g7-halo" data-label={T}>{name(T)}</text>}
                  </g>
                );
              })}
              <text x={Lay.ring ? 90 + 180 * h : Lay.x0[h] + (COLS - 1) * Lay.dx / 2} y={r1(Lay.H - 6)} textAnchor="middle" className="t-small t-muted">{research ? (h ? 'odd blades' : 'even blades') : (h ? 'odd number on' : 'even number on')}</text>
            </g>
          ))}
          {top && !Lay.ring && m < TOP && <text x={180} y={18} textAnchor="middle" className="t-tiny t-muted" data-restriction={m}>{research ? `Cl(0,${m}): the first ${2 ** (m - 1)} of ${2 ** (TOP - 1)} in each half` : `${m} switches: the first ${2 ** (m - 1)} in each half`}</text>}
        </FigSvg>
        <Legend items={research
          ? [['dot', 'even blade'], ['ring', 'odd blade'], ['solid', 'two bits apart: a generator acts'], gen != null && ['solid', `the lines of B${genName(gen)}`]]
          : [['dot', 'even number on'], ['ring', 'odd number on'], ['solid', 'two switches differ: a force acts']]} />
        <Controls label="internal halves">
          <Rungs label={research ? 'm' : 'switches'} values={GAUGE_MS} value={m} top={top} param="m" onPick={v => setSt(s => ({ ...s, m: v, gen: s.gen != null && within(s.gen, v) ? s.gen : null }))} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ ...s, top: on, m: on ? TOP : s.m }))} />
          <Chips label={research ? 'generator' : 'force'} items={gens} value={gen} param="gen" mono render={g => gname(g)} onPick={g => setSt(s => ({ ...s, gen: s.gen === g ? null : g }))} />
        </Controls>
      </div>
      <div className="g7-right">
        {research ? (
          <>
            <Readout data={{ 'data-readout': 'internal' }} items={[
              [`Cl(0,${m})`, lad ? `≅ ${lad.internal_cell}` : '…', { 'data-cell': lad ? lad.internal_cell : '' }],
              ['blades', lad ? `${lad.internal_dim} = ${lad.internal_dim / 2} even + ${lad.internal_dim / 2} odd` : '…', { 'data-dim': lad ? lad.internal_dim : '' }],
              ['generators', lad ? String(lad.gens) : '…', { 'data-gens': lad ? lad.gens : '' }],
              ['lines in each half', `${linesPerHalf} = ${gens.length} × ${perGen}`, { 'data-lines': `${linesPerHalf},${perGen}` }],
            ]} />
            {gen == null && <p className="g7-idle" data-idle="1">no generator picked</p>}
            {gen != null && (
              <div className="g7-card" data-picked={gen}>
                <h4><Tex katex={katex} tex={`B_{${genName(gen)}}`} plain={`B${genName(gen)}`} /><span className="g7-sub">{`${gname(gen)} · ${matchM[0].length} lines in each half`}</span></h4>
                {m <= 4 && <ul>{matchM.flatMap(pairs => pairs).map(p => <li key={p.a} data-pair={`${p.a},${p.b},${p.sign}`}><Tex katex={katex} tex={`B_{${genName(gen)}}\\,${eTex(p.a)}=${p.sign < 0 ? '-' : ''}${eTex(p.b)}`} plain={`B${genName(gen)} ${ePlain(p.a)} = ${p.sign < 0 ? '−' : ''}${ePlain(p.b)}`} /></li>)}</ul>}
              </div>
            )}
            {(L === 'cube' || L === 'demicube') && (
              <Readout data={{ 'data-readout': 'current' }} items={[
                ['current corners (n = 4)', masks ? [0, 1, 2, 3].map(nu => `${AXES[nu]} ${labelIn(L, masks[nu], { n: 4, kind: 'st' })}`).join(' · ') : '…', { 'data-masks': masks ? [0, 1, 2, 3].map(nu => masks[nu]).join(',') : '' }],
                ['distances', dists ? [0, 1, 2, 3].map(nu => dists[nu]).join(', ') : '…', { 'data-distances': dists ? [0, 1, 2, 3].map(nu => dists[nu]).join(',') : '' }],
                ['', 'our reading (MAT-008)'],
              ]} />
            )}
            {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`Cl(0,${m}) ⊂ Cl(0,${TOP})`, m === TOP ? 'top' : restr ? '✓ every sign the same' : '✗', { 'data-restricts': m === TOP ? 'top' : String(restr) }], ['generators kept', `${gens.length} of ${soAlgebra(TOP).gens.length}`, { 'data-kept': `${gens.length},${soAlgebra(TOP).gens.length}` }]]} />}
            <p className="g7-conv" data-convention="1"><span className="g7-k">inputs:</span> an internal blade of Cl(0,m) (INP-038) · left multiplication (INP-039) · J = γ₂γ₁ (INP-042)</p>
          </>
        ) : (
          <>
            <Readout data={{ 'data-readout': 'learner' }} items={[['', `${gens.length} kind${gens.length === 1 ? '' : 's'} of force`], ['', `${linesPerHalf} line${linesPerHalf === 1 ? '' : 's'} in each half`, { 'data-lines': `${linesPerHalf},${perGen}` }]]} />
            {gen == null && <p className="g7-idle" data-idle="1">no force picked</p>}
            {gen != null && <Readout data={{ 'data-readout': 'picked' }} items={[['', `${genName(gen)} flips switches ${genName(gen).split('').join(' and ')}`], ['', `${matchM[0].length} line${matchM[0].length === 1 ? '' : 's'} in each half`]]} />}
          </>
        )}
      </div>
    </div>
  );
}
MatterHalves.meta = { id: 'matter-halves', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
MatterHalves.params = [{}, { m: 2, gen: 3 }, { m: 4, gen: 5 }, { m: 5 }, { m: 7, gen: 9 }, { m: 4, top: true, gen: 6 }];
/** the numbers the figure draws: the halves of Cl(0,m), the picked generator's matching with the kernel's signs, the restriction from the top */
MatterHalves.data = (p = {}) => {
  const top = p.top === true, m = intIn(p.m, GAUGE_MS, top ? TOP : 3), gens = soAlgebra(m).gens, gen = gens.includes(p.gen) ? p.gen : null;
  return { m, top, halves: internalHalves(m).map(h => h.length), gens, gen, matching: gen == null ? null : matching(m, gen), restricts: top && m < TOP ? restricts('internal', m, TOP) : null };
};
