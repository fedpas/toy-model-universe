// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure null-criterion (step 13, caption NUL-003; docs/PHYSICS_AUDIT.md NS2): is g_tt = 0 the criterion? Two panels, v15's figures 3 and 4.
//  The criterion: |Eq. (1)| = T (dT/dx)² against the distance x from the surface, log-log, for three surfaces that are all null (T = 0 there): a simple zero T = x,
//  an extremal one T = x², and Eq. (18), T = (3x)^{1/3}. The curves are the script's (null.json figs.f3, from content/stored_p9.json; the engine's straight lines
//  of slope 1, 4 and −1 while it loads); the probe at x prints T, dT/dx, |Eq. (1)|, F = −(dT/dx)²/2 and n·n = −T.
//  Kerr (M = 5, a = 3, r₊ = 9) in the meridian plane: the horizon (solid) and the ergosurface g_tt = 0 (dashed), the point of the ergosurface at θ with r_E, g_tt
//  there and n·n of the normal to g_tt = const (negative: a timelike surface; zero at the pole); the script's segments (figs.f4) as dots on the curves, and its
//  seven exact points (null.json portal.kerr) as diamonds, listed with their exact r_E and n·n behind a fold.
// Every number is engines/nullEngine.js's (EQ1, Ffac, kerrErgo, kerrGtt, kerrNN, kerrXZ, through engines/physics/nullPhysics.js) or the stored json's;
// tests/physics/p9.test.mjs ties them (the seven points exactly). Controls, as in v15: the case chips and the probe slider (CriterionWidget), the θ slider
// (KerrWidget); sliders at research level. Curves told apart by stroke and name, the point's kind by fill and word, tokens only.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../../app/content.js';
import { CRIT, CRIT_CASES, F3_CASE, criterionAt, criterionCurve, criterionSlope, KERR_THETA, KERR, kerrAt, kerrCurves, kerrExact } from '../../../engines/physics/nullPhysics.js';
import { FigSvg, Controls, Chips, Range, r1 } from '../kit.jsx';
import { storedNull, Key, hx } from './p9kit.jsx';
import './p9.css';

const CASE_NAME = { simple: 'T = x (simple zero)', extremal: 'T = x² (extremal)', eq18: 'Eq. (18): T = ∛(3x)' };
const CURVE_NAME = { simple: 'simple zero', extremal: 'extremal', eq18: 'Eq. (18)' };
const DASH = { simple: undefined, extremal: '6 3', eq18: '2 3' };
const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sup = e => String(e).split('').map(c => SUP[c] || c).join('');
/** a number in the form m·10ᵉ (v15's sci), plain text */
export const sci = v => { if (v === 0) return '0'; if (!Number.isFinite(v)) return '∞'; const e = Math.floor(Math.log10(Math.abs(v))), m = v / 10 ** e; return `${String(+m.toFixed(2)).replace('-', '−')}·10${sup(e)}`; };
const fx = (v, d = 4) => (Math.abs(v) < 5 * 10 ** -(d + 1) ? '0' : String(+v.toFixed(d)).replace('-', '−'));
const lxOf = v => (Number.isFinite(v) && v >= CRIT.min - 1e-9 && v <= CRIT.max + 1e-9 ? Math.round(v * 100) / 100 : CRIT.start);
const thOf = v => (Number.isInteger(v) && v >= KERR_THETA.min && v <= KERR_THETA.max ? v : KERR_THETA.start);
const caseOf = v => (CRIT_CASES.includes(v) ? v : 'simple');

// the criterion panel: x from 10⁻³ to 1 across, |Eq. (1)| from 10⁻¹² to 10³ up
const CW = 400, CH = 262, PX = x => 46 + (Math.log10(x) + 3) * 108, PY = m => 228 - (Math.log10(m) + 12) * 13.2;
function CriterionPanel({ id, lx, f3, row }) {
  const P = criterionAt(id, lx);
  const curves = CRIT_CASES.map(c => {
    const stored = f3 ? f3.filter(q => F3_CASE[q.c] === c) : null;
    const pts = stored && stored.length ? [[stored[0].x1, stored[0].m1], ...stored.map(q => [q.x2, q.m2])] : criterionCurve(c);
    return { c, pts, src: stored && stored.length ? 'stored' : 'engine' };
  });
  return (
    <FigSvg id="null-criterion" row={row} part="Eq. (1) on three null surfaces" viewBox={`0 0 ${CW} ${CH}`}>
      <g data-case={id} data-x={fx(P.x, 6)} data-eq1={sci(P.eq1)}>
        {[-12, -9, -6, -3, 0, 3].map(m => <g key={'h' + m}><line x1={46} y1={r1(PY(10 ** m))} x2={370} y2={r1(PY(10 ** m))} className="hair-2" /><text x={42} y={r1(PY(10 ** m) + 3.5)} textAnchor="end" className="t-micro t-muted">{`10${sup(m)}`}</text></g>)}
        {[-3, -2, -1, 0].map(m => <g key={'v' + m}><line x1={r1(PX(10 ** m))} y1={30} x2={r1(PX(10 ** m))} y2={228} className="hair-2" /><text x={r1(PX(10 ** m))} y={240} textAnchor="middle" className="t-micro t-muted">{`10${sup(m)}`}</text></g>)}
        {curves.map(({ c, pts, src }) => {
          const on = c === id, at = pts[1] || pts[0];
          return (
            <g key={c} data-curve={c} data-src={src} data-points={pts.length}>
              <polyline points={pts.map(([x, m]) => `${r1(PX(x))},${r1(PY(m))}`).join(' ')} className="stroke-ink" style={{ strokeWidth: on ? 2.8 : 1.2, strokeDasharray: DASH[c], strokeOpacity: on ? 1 : 0.55 }} />
              <text x={r1(PX(at[0]) + 2)} y={r1(Math.max(38, Math.min(222, PY(at[1]) - 6)))} className={on ? 't-tiny t-bold' : 't-tiny t-muted'}>{CURVE_NAME[c]}</text>
            </g>
          );
        })}
        <line x1={r1(PX(P.x))} y1={30} x2={r1(PX(P.x))} y2={228} className="stroke-ink" style={{ strokeDasharray: '4 3', strokeOpacity: 0.7 }} />
        <circle cx={r1(PX(P.x))} cy={r1(PY(P.eq1))} r={5} className="ink" data-probe={fx(P.x, 6)} />
        <text x={208} y={256} textAnchor="middle" className="t-tiny t-muted">distance x from the surface (log scale)</text>
        <text x={6} y={18} className="t-tiny t-muted">|Eq. (1)| (log scale)</text>
      </g>
    </FigSvg>
  );
}

// the Kerr panel: the meridian plane, the axis of rotation vertical
const KW = 400, KH = 262, KX = 200, KY = 128, KU = 10.6;
const kp = ([x, z], sx = 1, sy = 1) => [KX + KU * sx * x, KY - KU * sy * z];
function KerrPanel({ deg, f4, row }) {
  const K = kerrAt(deg), C = useMemo(() => kerrCurves(60), []), ex = kerrExact();
  const pl = (pts, sx) => pts.map(p => kp(p, sx).map(r1).join(',')).join(' ');
  return (
    <FigSvg id="null-criterion" row={row} part="Kerr: the ergosurface is not the horizon" viewBox={`0 0 ${KW} ${KH}`}>
      <g data-theta={deg} data-nn={sci(K.nn)} data-pole={K.pole ? 1 : 0}>
        <line x1={KX} y1={10} x2={KX} y2={KH - 14} className="hair" style={{ strokeDasharray: '3 3' }} />
        <line x1={KX - 150} y1={KY} x2={KX + 150} y2={KY} className="hair" />
        <text x={KX} y={8} textAnchor="middle" className="t-micro t-muted">axis of rotation</text>
        {[1, -1].map(s => <g key={s}>
          <polyline points={pl(C.horizon, s)} className="stroke-ink" style={{ strokeWidth: 2.6 }} data-curve="horizon" />
          <polyline points={pl(C.ergo, s)} className="stroke-ink" style={{ strokeWidth: 2.2, strokeDasharray: '6 3' }} data-curve="ergo" />
        </g>)}
        {f4 ? f4.map((q, k) => { const [x, y] = kp([q.x1, q.z1]); return <circle key={'f' + k} cx={r1(x)} cy={r1(y)} r={1.6} className="ink" data-stored-f4={`${q.kind},${q.th}`}><title>{`${q.s}, θ = ${q.th}° (null.json f4)`}</title></circle>; }) : null}
        {ex.map(p => { const th = p.deg * Math.PI / 180, [x, y] = kp([Math.sqrt(p.rv ** 2 + KERR.a ** 2) * Math.sin(th), p.rv * Math.cos(th)]); return <path key={'x' + p.w} d={`M${r1(x)} ${r1(y - 4)} L${r1(x + 4)} ${r1(y)} L${r1(x)} ${r1(y + 4)} L${r1(x - 4)} ${r1(y)} Z`} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.1 }} data-kerr-exact={`${p.w},${p.r},${p.n2}`}><title>{`cos²θ = ${p.w}: r_E = ${p.r}, n·n = ${p.n2}`}</title></path>; })}
        {[[1, 1], [-1, 1], [1, -1], [-1, -1]].map(([sx, sy], i) => { const [x, y] = kp(K.xz, sx, sy); return <circle key={'p' + i} cx={r1(x)} cy={r1(y)} r={i ? 3.2 : 6} className={K.pole ? 'on-panel' : 'ink'} style={K.pole ? { stroke: 'var(--fg)', strokeWidth: 1.6 } : { fillOpacity: i ? 0.55 : 1 }} data-point={i ? undefined : `${fx(K.w)},${fx(K.rE)}`} />; })}
        <text x={8} y={KH - 6} className="t-micro t-muted">{`M = ${KERR.M}, a = ${KERR.a}, r₊ = ${KERR.rh}`}</text>
      </g>
    </FigSvg>
  );
}

export default function NullCriterion({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [T0] = useTable('stored_p9');
  const figs = storedNull(params, T0);
  const [id, setId] = useState(caseOf(params.case));
  const [lx, setLx] = useState(lxOf(params.x));
  const [deg, setDeg] = useState(thOf(params.theta));
  useEffect(() => { setId(caseOf(params.case)); setLx(lxOf(params.x)); setDeg(thOf(params.theta)); }, [params.case, params.x, params.theta]);
  const P = criterionAt(id, lx), K = kerrAt(deg), ex = kerrExact();
  return (
    <div className="fig p9 fig-null-criterion">
      <div className="fig-panels">
        <div className="fig-panel">
          <CriterionPanel id={id} lx={lx} f3={figs ? figs.f3 : null} row={row} />
          <ul className="p9-legend">{CRIT_CASES.map(c => <li key={c}><Key kind={c === 'simple' ? 'solid' : c === 'extremal' ? 'dashed' : 'thin-dashed'} />{CURVE_NAME[c]}</li>)}</ul>
          <div className="p9-readout">
            <p data-crit={`${sci(P.T)},${sci(P.dT)},${sci(P.eq1)}`}>{`T = ${sci(P.T)} · dT/dx = ${sci(P.dT)} · |Eq. (1)| = T (dT/dx)² = ${sci(P.eq1)}`}</p>
            <p data-f={sci(P.F)}>{`F = −(dT/dx)²/2 = ${sci(P.F)} · n·n = −T = ${sci(P.nn)} → 0`}</p>
            <p className="p9-muted" data-slope={criterionSlope(id)}>{`log-log slope ${fx(criterionSlope(id), 6)} · x = ${sci(P.x)}`}</p>
          </div>
        </div>
        <div className="fig-panel">
          <KerrPanel deg={deg} f4={figs ? figs.f4 : null} row={row} />
          <ul className="p9-legend"><li><Key kind="solid" />horizon r₊ = 9 (null)</li><li><Key kind="dashed" />ergosurface gₜₜ = 0 (not null)</li><li><Key kind="diamond" />exact points (null.json)</li>{figs ? <li><Key kind="dot" />null.json f4</li> : null}</ul>
          <div className="p9-readout">
            <p data-kerr={`${fx(K.w)},${fx(K.rE)},${fx(K.gtt, 6)}`}>{hx(`cos²θ = ${fx(K.w)} · r_E = ${fx(K.rE)} · g_{tt}(r_E) = ${fx(K.gtt, 6)}`)}</p>
            <p data-kerr-nn={sci(K.nn)}>{hx(`n·n of the normal to g_{tt} = const: ${sci(K.nn)} → ${K.pole ? 'zero, at the pole (r_E = r₊)' : 'negative: a timelike surface, not null'}`)}</p>
          </div>
          {research && (
            <details className="p9-exact">
              <summary>{`the ${ex.length} exact points of null_selfcheck.py`}</summary>
              <table className="p9-table">
                <thead><tr><th>cos²θ</th><th>θ</th><th>r<sub>E</sub></th><th>n·n</th></tr></thead>
                <tbody>{ex.map(p => <tr key={p.w} data-exact={`${p.w},${p.r},${p.n2}`}><td>{p.w}</td><td>{`${fx(p.deg, 2)}°`}</td><td>{p.r}</td><td>{p.n2.replace('-', '−')}</td></tr>)}</tbody>
              </table>
            </details>
          )}
        </div>
      </div>
      <Controls label="the criterion and Kerr">
        <Chips label="surface" items={CRIT_CASES} value={id} onPick={setId} render={c => CASE_NAME[c]} param="case" />
        {research && <Range label="distance x (log)" value={lx} min={CRIT.min} max={CRIT.max} step={CRIT.step} onChange={v => setLx(lxOf(v))} display={v => `x = ${sci(10 ** v)}`} param="x" />}
        {research && <Range label="polar angle θ" value={deg} min={KERR_THETA.min} max={KERR_THETA.max} step={KERR_THETA.step} onChange={v => setDeg(thOf(Math.round(v)))} display={v => `θ = ${v}°`} param="theta" />}
      </Controls>
    </div>
  );
}
NullCriterion.meta = { id: 'null-criterion', lenses: [], learner: false };
NullCriterion.params = [{}, { case: 'extremal', x: -3 }, { case: 'eq18', x: -0.3, theta: 0 }, { case: 'simple', theta: 90 }];
/** the numbers the figure draws, for the frame's data download */
NullCriterion.data = (params = {}) => ({ criterion: criterionAt(caseOf(params.case), lxOf(params.x)), kerr: kerrAt(thOf(params.theta)), exact: kerrExact() });
