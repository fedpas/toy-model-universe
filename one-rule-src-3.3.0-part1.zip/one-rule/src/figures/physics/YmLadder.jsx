// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure ym-ladder (step 7, section of steps/ym; audit YG2–YG6): what yangmills_selfcheck.py and yangmills_matrix_check.py store about Yang–Mills with the gauge
// algebra so(m) (content/stored_p7.json ym and ymm, D34). The ladder drawn first (D37): a rung per m = 2 … 8 from the lowest stored cell up, a column per block of
// stored data — the ladder at space-time 1 + 3, the exact identities, the numpy matrix check (m = 2 … 6), the space-time table (m = 3), the Maxwell reduction
// (m = 2), the so(4) split (m = 4) — an empty dashed box where a block has no data; "from the top" starts at so(8) and marks every lower so(m) as its restriction
// (the kernel's signs). Beside it the chosen rung; under it, in folds, the ladder with the standard names (u(1), su(2), …: D29 standard), the space-time table at
// m = 3 (n = 2 … 7, the rungs not stored empty), the Maxwell reduction n·C(n,2), the identities on the grid of (m, n) (KaTeX, ✓ where stored), the so(4) split
// (the signs from the kernel's commutators) and the matrix check with its two wrong versions. Every number is the stored one; tests/physics/p7.test.mjs recomputes
// the counts and the split through the kernel (engines/physics/gauge.js) and ties the identities and the numpy results to the file only (D11). Port of v15
// YangMillsSection.jsx (the table, the space-time table, the identities, the matrix check, the split), with its chips m = 2 … 8 and the click on a row. Research only.
import React, { useEffect, useMemo, useState } from 'react';
import { labelIn, restricts, genName, so4Split, GAUGE_MS, YM_STANDARD } from '../../../engines/physics/gauge.js';
import { Controls } from '../kit.jsx';
import { useStored, lensKey, intIn, Tex, Rungs, TopSwitch, Readout, Legend, Mark, NotStored, Fold, LadderSvg, MiniTable, useKatexAt } from './GaugeKit.jsx';

const TOP = 8, NS = [2, 3, 4, 5, 6, 7];
export const YM_IDENTITIES = [
  ['bianchi', 'Bianchi', 'D_\\lambda F_{\\mu\\nu}+D_\\mu F_{\\nu\\lambda}+D_\\nu F_{\\lambda\\mu}=0', 'D_λF_μν + D_μF_νλ + D_νF_λμ = 0', 'Bianchi'],
  ['gauge_covariance_first_order', 'covariance (first order)', 'A\\to A+D\\lambda:\\ \\delta F=g[F,\\lambda]', 'A → A + Dλ: δF = g[F, λ]', 'covariance'],
  ['covariant_conservation', 'covariant conservation', 'D^\\mu F_{\\mu\\nu}=J_\\nu\\ \\Rightarrow\\ D^\\nu J_\\nu=0', 'D^μF_μν = J_ν ⇒ D^νJ_ν = 0', 'conservation'],
];
const FS = { tex: 'F_{\\mu\\nu}=\\partial_\\mu A_\\nu-\\partial_\\nu A_\\mu+g[A_\\mu,A_\\nu],\\quad D_\\lambda X=\\partial_\\lambda X+g[A_\\lambda,X]', plain: 'F_μν = ∂_μA_ν − ∂_νA_μ + g[A_μ, A_ν], D_λX = ∂_λX + g[A_λ, X]' };
const COUNTS = { tex: '(n-1)(2m-3)\\ \\text{terms per equation},\\quad 3(2m-3)\\ \\text{per Bianchi equation}', plain: '(n − 1)(2m − 3) terms per equation, 3(2m − 3) per Bianchi equation' };
const words = k => k.replace(/_/g, ' ');
const per = (t, e) => (e ? String(t / e) : '—');
/** the stored identity pairs of the gauge rung m: [[n, record]] */
export const idsAt = (ids, m) => Object.entries(ids).filter(([k]) => k.split(',')[0] === String(m)).map(([k, v]) => [Number(k.split(',')[1]), v]);
/** the so(4) split as the kernel gives it (yangmills_selfcheck.py so4_split order): the two triples, each B_ab ± B_cd with its sign */
export function splitTriples() {
  const S = so4Split(), tex = c => c.map(([k, v], i) => `${i ? (v < 0 ? '-' : '+') : ''}B_{${genName(k)}}`).join(''), plain = c => c.map(([k, v], i) => `${i ? (v < 0 ? ' − ' : ' + ') : ''}B${genName(k)}`).join('');
  return S.found ? { signs: S.self_dual_signs, triples: S.triples.map(T => T.map(c => ({ tex: tex(c), plain: plain(c) }))) } : null;
}

export default function YmLadder({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => ({ m: intIn(params.m, GAUGE_MS, params.top === true ? TOP : 4), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.m, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { m, top } = st, pick = v => setSt(s => ({ ...s, m: v }));
  const order = top ? [...GAUGE_MS].reverse() : GAUGE_MS;
  const restr = useMemo(() => Object.fromEntries(GAUGE_MS.map(v => [v, v < TOP ? restricts('internal', v, TOP) : null])), []);
  const split = useMemo(splitTriples, []);
  const Y = S ? S.ym : null, M = S ? S.ymm : null;
  const blocks = [
    { key: 'ladder', name: 'ladder', sub: '1 + 3', mark: 'square', has: v => (Y ? !!Y.ladder[String(v)] : null) },
    { key: 'identities', name: 'identities', sub: 'exact', mark: 'check', has: v => (Y ? idsAt(Y.identities, v).length > 0 : null) },
    { key: 'matrix', name: 'matrix', sub: 'numpy', mark: 'diamond', has: v => (M ? String(v) in M.max_error_field_strength : null) },
    { key: 'spacetime', name: 'space-time', sub: 'n = 2 … 6', mark: 'triangle', has: v => (Y ? v === 3 && !!Y.spacetime : null) },
    { key: 'maxwell', name: 'Maxwell', sub: 'n·C(n,2)', mark: 'circle', has: v => (Y ? v === 2 && !!Y.maxwell_reduction : null) },
    { key: 'split', name: 'so(4) split', sub: '2 triples', mark: 'ring', has: v => (Y ? v === 4 && !!Y.so4_split && Y.so4_split.found : null) },
  ];
  const r = Y ? Y.ladder[String(m)] : null, ids = Y ? idsAt(Y.identities, m) : [], mx = M && String(m) in M.max_error_field_strength ? M : null;
  const gl = g => labelIn(L, g, { n: m, kind: 'int' });
  return (
    <div className="fig fig-ym-ladder g7-split" data-m={m} data-top={top ? 'true' : 'false'} data-lens={L || ''}>
      <div className="g7-left">
        <LadderSvg id="ym-ladder" row={row} rungs={GAUGE_MS} rungLabel={v => `so(${v})`} blocks={blocks} value={m} onPick={pick} top={top} param="m" restricts={v => restr[v]} />
        <Legend items={[['box', 'stored'], ['empty', 'not stored'], top && ['solid', `each lower so(m) ⊂ so(${TOP}): every sign the same`]]} />
        <Controls label="gauge ladder">
          <Rungs label="m" values={GAUGE_MS} value={m} top={top} param="m" onPick={pick} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ top: on, m: on ? TOP : s.m }))} />
        </Controls>
      </div>
      <div className="g7-right">
        <div className="g7-card" data-rung-card={m}>
          <h4>{`so(${m})`}<span className="g7-sub">{r ? `Cl(0,${m}) ≅ ${r.algebra_cell} · even half ${r.even_half} · ${YM_STANDARD[m]}` : 'loading the stored checks'}</span></h4>
          {r && <Readout data={{ 'data-row': m }} items={[
            ['generators', String(r.gens), { 'data-gens': r.gens }],
            ['pairs', `${r.noncommuting_pairs} do not commute · ${r.commuting_pairs} commute`, { 'data-pairs': `${r.noncommuting_pairs},${r.commuting_pairs}` }],
            ['closed triangles', String(r.triangles), { 'data-triangles': r.triangles }],
            ['neighbours of each', String(r.neighbours_of_each_generator), { 'data-neighbours': r.neighbours_of_each_generator }],
            ['F components', String(r.F_components), { 'data-f': r.F_components }],
            ['quadratic terms in each F', String(r.quadratic_terms_per_F_component), { 'data-quad': r.quadratic_terms_per_F_component }],
            ['terms in each equation', per(r.equation_terms, r.equations), { 'data-terms': per(r.equation_terms, r.equations) }],
            r.labels && ['labels', r.labels.map(gl).join(', '), { 'data-labels': r.labels.join(',') }],
          ]} />}
          {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`⊂ so(${TOP})`, m === TOP ? 'top' : restr[m] ? '✓ every sign the same' : '✗', { 'data-restricts': m === TOP ? 'top' : String(restr[m]) }]]} />}
        </div>
        <div className="g7-card" data-identities-at={m}>
          <h4>exact identities<span className="g7-sub">{`m = ${m}`}</span></h4>
          {ids.length ? <MiniTable heads={YM_IDENTITIES.map(([k, nm, , , short]) => short)} titles={YM_IDENTITIES.map(([k, nm]) => nm)} rows={ids.map(([ns, v]) => ({ key: ns, label: `n = ${ns}`, data: { 'data-pair': `${m},${ns}` }, cells: YM_IDENTITIES.map(([k]) => ({ v: v[k], data: { 'data-id': `${k},${v[k]}` } })) }))} /> : Y ? <NotStored /> : null}
        </div>
        <div className="g7-card" data-matrix-at={m}>
          <h4>matrix check (numpy)<span className="g7-sub">{`m = ${m}`}</span></h4>
          {mx ? <Readout items={[['representation', String(mx.max_error_representation[String(m)]), { 'data-err-rep': mx.max_error_representation[String(m)] }], ['field strength', String(mx.max_error_field_strength[String(m)]), { 'data-err-f': mx.max_error_field_strength[String(m)] }], ['Bianchi', String(mx.max_error_bianchi[String(m)]), { 'data-err-b': mx.max_error_bianchi[String(m)] }]]} /> : M ? <NotStored /> : null}
        </div>
        {m === 4 && Y && split && (
          <div className="g7-card" data-split-at="4">
            <h4>so(4) = su(2) + su(2)<span className="g7-sub">{`signs ${Y.so4_split.self_dual_signs.map(s => (s < 0 ? '−' : '+')).join(' ')}`}</span></h4>
            {split.triples.map((T, i) => <p key={i} className="g7-eq" data-triple={i}><Tex katex={katex} tex={T.map(x => x.tex).join(',\\quad ')} plain={T.map(x => x.plain).join(',  ')} /></p>)}
            <Readout items={[['the triples commute', <Mark v={Y.so4_split.ideals_commute} />], ['each closed', <Mark v={Y.so4_split.each_ideal_closed} />], ['dimension of each', String(Y.so4_split.dimension_each)]]} />
          </div>
        )}
        {m === 2 && Y && <div className="g7-card" data-maxwell-at="2"><h4>m = 2<span className="g7-sub">the Maxwell incidences n·C(n,2)</span></h4><Readout items={[['in 4D', `${Y.maxwell_reduction['4'].vector_terms} + ${Y.maxwell_reduction['4'].bianchi_terms} = ${Y.maxwell_reduction['4'].total} = 4·C(4,2)`, { 'data-maxwell4': Y.maxwell_reduction['4'].total }]]} /></div>}
      </div>
      <div className="g7-wide">
        {Y && (
          <Fold id="ladder" title="The ladder (space-time 1 + 3)">
            <table className="g7-table" data-table="ladder">
              <thead><tr>{['m', 'generators', 'pairs that do not commute', 'pairs that commute', 'closed triangles', 'neighbours of each generator', 'F components', 'quadratic terms in each F', 'terms in each equation', 'also known as'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{order.map(v => { const x = Y.ladder[String(v)]; return (
                <tr key={v} className={v === m ? 'is-on' : ''} data-param="m" data-ladder={v} onClick={() => pick(v)}>
                  <td className="g7-n">{v}</td><td className="g7-n">{x.gens}</td><td className="g7-n">{x.noncommuting_pairs}</td><td className="g7-n">{x.commuting_pairs}</td><td className="g7-n">{x.triangles}</td>
                  <td className="g7-n">{x.neighbours_of_each_generator}</td><td className="g7-n">{x.F_components}</td><td className="g7-n">{x.quadratic_terms_per_F_component}</td><td className="g7-n">{per(x.equation_terms, x.equations)}</td><td>{YM_STANDARD[v]}</td>
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {Y && (
          <Fold id="spacetime" title="Space-time dimension, at m = 3 (su(2))">
            <p className="g7-readout"><Tex katex={katex} tex={COUNTS.tex} plain={COUNTS.plain} /></p>
            <table className="g7-table" data-table="spacetime">
              <thead><tr>{['space-time n', 'F components', 'equations', 'terms in each equation', 'Bianchi equations', 'terms in each Bianchi equation'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{(top ? [...NS].reverse() : NS).map(v => { const x = Y.spacetime[String(v)]; return (
                <tr key={v} className={x ? '' : 'is-ns'} data-spacetime={v}>
                  <td className="g7-n">{v}</td>{x ? <><td className="g7-n">{x.F_components}</td><td className="g7-n">{x.equations}</td><td className="g7-n">{per(x.equation_terms, x.equations)}</td><td className="g7-n">{x.bianchi_equations}</td><td className="g7-n">{per(x.bianchi_terms, x.bianchi_equations)}</td></> : <td colSpan={5}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {Y && (
          <Fold id="maxwell" title="m = 2: the Maxwell incidences n·C(n,2)">
            <table className="g7-table" data-table="maxwell">
              <thead><tr>{['space-time n', 'terms of the equation', 'terms of the Bianchi identity', 'together', '= n·C(n,2)'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{(top ? [...NS].reverse() : NS).map(v => { const x = Y.maxwell_reduction[String(v)]; return (
                <tr key={v} className={x ? '' : 'is-ns'} data-maxwell={v}>
                  <td className="g7-n">{v}</td>{x ? <><td className="g7-n">{x.vector_terms}</td><td className="g7-n">{x.bianchi_terms}</td><td className="g7-n">{x.total}</td><td><Mark v={x.equals_n_times_C_n_2} /></td></> : <td colSpan={4}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {Y && (
          <Fold id="identities" title="Exact identities (random polynomial fields), on the grid of (m, n)">
            <p className="g7-readout"><Tex katex={katex} tex={FS.tex} plain={FS.plain} /></p>
            <Readout items={YM_IDENTITIES.map(([k, nm, tex, plain], i) => [`${'BCD'[i]}: ${nm}`, <Tex katex={katex} tex={tex} plain={plain} />])} />
            <table className="g7-table" data-table="identities">
              <thead><tr><th>gauge m \ space-time n</th>{NS.map(v => <th key={v}>{v}</th>)}</tr></thead>
              <tbody>{order.map(v => (
                <tr key={v} className={v === m ? 'is-on' : ''} data-identities={v}>
                  <td className="g7-n">{v}</td>
                  {NS.map(ns => { const x = Y.identities[`${v},${ns}`]; return <td key={ns} data-cell={`${v},${ns}`}>{x ? YM_IDENTITIES.map(([k], i) => <span key={k} data-id={`${k},${x[k]}`}>{'BCD'[i]}<Mark v={x[k]} /> </span>) : <NotStored />}</td>; })}
                </tr>))}</tbody>
            </table>
          </Fold>
        )}
        {Y && split && (
          <Fold id="split" title="so(4) splits into two commuting triples">
            {split.triples.map((T, i) => <p key={i} className="g7-eq" data-triple={i}><Tex katex={katex} tex={T.map(x => x.tex).join(',\\quad ')} plain={T.map(x => x.plain).join(',  ')} /></p>)}
            <Readout data={{ 'data-signs': Y.so4_split.self_dual_signs.join(',') }} items={[['signs found', Y.so4_split.self_dual_signs.map(s => (s < 0 ? '−' : '+')).join(' ')], ['found', <Mark v={Y.so4_split.found} />], ['the triples commute', <Mark v={Y.so4_split.ideals_commute} />], ['each closed', <Mark v={Y.so4_split.each_ideal_closed} />]]} />
          </Fold>
        )}
        {M && (
          <Fold id="matrix" title="Independent check with matrices (numpy)">
            <p className="g7-readout"><Tex katex={katex} tex={'[R_a,R_b]=f_{ab}{}^{c}R_c,\\quad F=\\partial A-\\partial A+g[A,A]'} plain="[R_a, R_b] = f_ab^c R_c, F = ∂A − ∂A + g[A, A]" /></p>
            <table className="g7-table" data-table="matrix">
              <thead><tr>{['m', 'representation', 'field strength', 'Bianchi'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{order.map(v => { const k = String(v), on = k in M.max_error_field_strength; return (
                <tr key={v} className={(v === m ? 'is-on' : '') + (on ? '' : ' is-ns')} data-matrix={v}>
                  <td className="g7-n">{v}</td>{on ? <><td className="g7-n">{M.max_error_representation[k]}</td><td className="g7-n">{M.max_error_field_strength[k]}</td><td className="g7-n">{M.max_error_bianchi[k]}</td></> : <td colSpan={3}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
            <Readout data={{ 'data-controls': Object.keys(M.controls).length }} items={[['wrong versions', ''], ...Object.entries(M.controls).map(([k, v]) => ['', `${words(k)}: ${v}`, { 'data-control': k }]), ['status', M.status]]} />
          </Fold>
        )}
        <p className="g7-conv" data-convention="1"><span className="g7-k">inputs:</span> so(m) as the gauge algebra, one choice (INP-034) · the coupling g (INP-035) · D = ∂ + gA (INP-036)</p>
      </div>
    </div>
  );
}
YmLadder.meta = { id: 'ym-ladder', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: false };
YmLadder.params = [{}, { m: 2 }, { m: 3 }, { m: 7 }, { m: 5, top: true }];
/** the kernel's part of what the figure draws: the rungs, the restrictions from the top, the so(4) split */
YmLadder.data = (p = {}) => {
  const m = intIn(p.m, GAUGE_MS, p.top === true ? TOP : 4), sp = splitTriples();
  return { m, top: p.top === true, rungs: GAUGE_MS, restricts: GAUGE_MS.map(v => (v < TOP ? restricts('internal', v, TOP) : null)), split: sp ? { signs: sp.signs, triples: sp.triples.map(T => T.map(x => x.plain)) } : null };
};
