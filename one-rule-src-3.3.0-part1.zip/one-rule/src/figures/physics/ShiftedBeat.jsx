// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure shifted-beat (Calibration 3, step 6b of `shifted`; caption ATY-040, states ATY-040 and ATY-038; docs/round14/STORY_ROUND.md §6.3, owner B3): two
// quantized modes of one species at one shift, E = 5 and 3 at (m, κ, τ) = (4, 1, π/2), on the frame of a constant potential a = 5/3, 5/4, 2, 4/5: their
// density beats at E₁ − E₂ = 2κ per unit proper time on every frame (a clock) and at 2κ/a per unit coordinate time; over each shift the beat term
// changes sign, (E₁ − E₂)τ = π; the Noether energy does not beat. Drawn over one window of 4π, the same for every frame and both times: the beat term
// (the cosine of the beat), the shifts as dashed lines with the sign of the beat at each, the energy as a flat line. The energies and the beats are
// computed (E = m + (−1)ⁿκ with the kernel's signs, the sign over a shift as the scalar of J², engines/physics/shifted.js beatData) and printed
// beside the stored ones (content/stored_shifted.json beat, loaded on demand: D34). Controls: the frame (chips), coordinate time (toggle). Tokens only.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Toggle, pick, r1, tx } from '../kit.jsx';
import { Loading } from './fureyKit.jsx';
import { useShifted, peekShifted } from './ShiftedQuarterTurn.jsx';
import { beatData } from '../../../engines/physics/shifted.js';

const FRAMES = ['5/3', '5/4', '2', '4/5'];
const piOf = q => { const [a, b] = String(q).split('/'); return `${a === '1' ? '' : a}π${b ? `/${b}` : ''}`; };
const X0 = 44, X1 = 452, Y0 = 92, AMP = 40;

export default function ShiftedBeat({ params = {}, level = 'research', row }) {
  const research = level !== 'learner';
  const [frame, setFrame] = useState(pick(params.frame, v => FRAMES.includes(v), '5/3'));
  const [time, setTime] = useState(params.time === 'coordinate' ? 'coordinate' : 'proper');
  useEffect(() => { setFrame(pick(params.frame, v => FRAMES.includes(v), '5/3')); setTime(params.time === 'coordinate' ? 'coordinate' : 'proper'); }, [params.frame, params.time]);
  const T = useShifted(params), B = T ? beatData(T, { frame: FRAMES.indexOf(frame), time }) : null;
  const X = t => r1(X0 + ((X1 - X0) * t) / (B ? B.span : 1)), Y = v => r1(Y0 - AMP * v);
  const coord = time === 'coordinate';
  return (
    <div className="fig fig-shifted-beat">
      <FigSvg id="shifted-beat" row={row} viewBox="0 0 460 250">
        <text x={4} y={14} className="t-small t-bold">{research ? 'two quantized modes at one shift, and their beat' : 'two waves of one kind, beating'}</text>
        <line x1={X0} y1={Y0} x2={X1} y2={Y0} className="hair" />
        <line x1={X0} y1={Y0 - AMP - 8} x2={X0} y2={Y0 + AMP + 8} className="hair" />
        <text x={X0 - 4} y={Y0 - AMP + 3} textAnchor="end" className="t-micro t-muted">+</text>
        <text x={X0 - 4} y={Y0 + AMP + 3} textAnchor="end" className="t-micro t-muted">−</text>
        <text x={X1} y={Y0 + AMP + 22} textAnchor="end" className="t-micro t-muted">{coord ? (research ? `coordinate time on the frame a = ${frame}` : `the time of frame ${frame}`) : research ? 'proper time' : 'the waves’ own time'}</text>
        {B ? (
          <g data-frame={B.a} data-time={time} data-beat={B.beat} data-shift={B.shift} data-flip={B.flip} data-stored-flip={B.storedFlip}>
            {B.shifts.map((t, j) => (
              <g key={j} data-shift-at={j} data-sign={j % 2 ? -1 : 1}>
                <line x1={X(t)} y1={Y0 - AMP - 6} x2={X(t)} y2={Y0 + AMP + 6} className="stroke-muted" strokeDasharray="3 3" />
                <text x={X(t)} y={Y0 - AMP - 10} textAnchor="middle" className="t-micro">{j % 2 ? '−' : '+'}</text>
              </g>
            ))}
            <polyline points={B.samples.map(([t, v]) => `${X(t)},${Y(v)}`).join(' ')} className="stroke-ink" strokeWidth={1.6} />
            {B.shifts.length > 1 && (
              <text x={(X(B.shifts[0]) + X(B.shifts[1])) / 2} y={Y0 + AMP + 22} textAnchor="middle" className="t-micro" data-value={B.shift}>
                {research ? `${coord ? 'aτ' : 'τ'} = ${piOf(B.shift)}` : 'one delay'}
              </text>
            )}
            <line x1={X0} y1={176} x2={X1} y2={176} className="stroke-ink" strokeWidth={2} />
            <text x={X0} y={170} className="t-tiny">{research ? 'the Noether energy: constant, no beat' : 'the energy: steady, it does not beat'}</text>
          </g>
        ) : <Loading x={X0} y={Y0 - 20} w={X1 - X0} h={40} what="stored results" />}
        {B && (
          <g data-modes={B.modes.map(md => `${md.E}:${md.n}:${md.Ecomputed}`).join(',')} data-proper={B.proper.computed} data-stored-proper={B.proper.stored} data-coordinate={B.coordinate.computed} data-stored-coordinate={B.coordinate.stored || ''}>
            <text x={4} y={200} className="t-tiny">
              {research ? tx(`E_1 = ${B.modes[0].Ecomputed} (n = ${B.modes[0].n}), E_2 = ${B.modes[1].Ecomputed} (n = ${B.modes[1].n}): E = m + (−1)^n κ at (m, κ, τ) = (4, 1, π/2), as stored`)
                : `two waves of energies ${B.modes[0].Ecomputed} and ${B.modes[1].Ecomputed}, both allowed by the same delay`}
            </text>
            <text x={4} y={216} className="t-tiny">
              {research ? tx(`beat E_1 − E_2 = 2κ = ${B.proper.computed} per unit proper time; on the frame a = ${B.a}: 2κ/a = ${B.coordinate.computed} per unit coordinate time`)
                : `they beat ${B.proper.computed} times per unit of their own time, ${B.coordinate.computed} per unit of this frame’s time`}
            </text>
            <text x={4} y={232} className="t-tiny">
              {research ? tx(`over one shift the beat term changes sign: e^{J(E₁ − E₂)τ} = J^2 = ${B.flip < 0 ? '−1' : '+1'}; the energy keeps no beat`)
                : 'each delay turns the beat upside down; in a frame\u2019s own time the beat runs slower or faster, like any clock'}
            </text>
          </g>
        )}
      </FigSvg>
      <Controls label="beat">
        <Chips label={research ? 'frame a' : 'frame'} items={FRAMES} value={frame} onPick={setFrame} param="frame" />
        <Toggle label="coordinate time" on={coord} onChange={on => setTime(on ? 'coordinate' : 'proper')} param="time" />
      </Controls>
    </div>
  );
}
ShiftedBeat.meta = { id: 'shifted-beat', lenses: [], learner: true };
ShiftedBeat.params = [{}, { frame: '2', time: 'coordinate' }, { frame: '4/5', time: 'coordinate' }, { frame: '5/4' }];
/** the numbers the figure draws, for the frame's data download */
ShiftedBeat.data = (params = {}) => {
  const T = peekShifted(params), frame = FRAMES.includes(params.frame) ? params.frame : '5/3', time = params.time === 'coordinate' ? 'coordinate' : 'proper';
  if (!T) return { loading: true, frame, time };
  const B = beatData(T, { frame: FRAMES.indexOf(frame), time });
  return { frame, time, modes: B.modes, proper: B.proper, coordinate: B.coordinate, beat: B.beat, shift: B.shift, flip: B.flip, shifts: B.shifts.length };
};
