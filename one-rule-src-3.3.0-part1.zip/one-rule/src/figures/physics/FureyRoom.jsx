// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure furey-room (Furey, three generations; caption PAG-015; PHYSICS_AUDIT FU3, FU4, FU6): how many generations the board and its kind of block structure
// hold, as two ladders (D37: drawn from the lowest rung up, with a "from the top" switch). Left, the generations wanted, 1 → 3: the complete sets of each of the
// six types (one label per cell, or every cell doubled: engines/fureyPapersEngine.js, the counts furey_papers.json counting stores), what is short for the
// rung shown and what is left over. Right, the complex dimension of V, 8 → 14 (furey_papers.json room): the structures by the complete sets their linear
// off-diagonal cells hold, the best, her structure at 8, three sets first at 14. Below, the exhaustive search over every admissible W of dimension 8
// (threegen.json search_all: generations held by the matter part, never 3, and how far each type alone goes) and where the 128 complex dimensions of End(V)
// go (threegen.json dimensions and exotic; 256 = the 2⁸ labels of Cl(0,8), the kernel's). The exhaustive searches are not rerun (D11): their numbers are
// the stored ones, tied in tests/physics/p10.test.mjs. Controls: v15's Ledger (sets wanted, the count) and Room (the dimension), and D37's switch.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Toggle, r1, pick } from '../kit.jsx';
import { Sc } from '../FureyBoard.jsx';
import * as E from '../../../engines/fureyPapersEngine.js';
import { ledger, roomLadder, wSearch, whole, typeList, thousands } from '../../../engines/physics/furey.js';
import { useStored, peekStored, Loading, Rungs } from './fureyKit.jsx';

const TN = t => t.replace('nu_', 'ν_');
const PLAIN = { Q_L: 'quarks left', u_R: 'up quark right', d_R: 'down quark right', L: 'electron and neutrino left', e_R: 'electron right', nu_R: 'neutrino right' };
const PARTS = {
  research: ['gauge blocks', 'linear off-diagonal: Standard Model types', 'antilinear: Standard Model types', 'antilinear: exotic charges'],
  learner: ['force carriers', 'particles of known kinds (links that turn with the key)', 'particles of known kinds (links that turn against the key)', 'places with charges no known particle has'],
};
const PART_STYLE = [{ fillOpacity: 0.12 }, { fillOpacity: 0.78 }, { fillOpacity: 0.45 }, { fillOpacity: 0 }];
const NS = [8, 9, 10, 11, 12, 13, 14];

export default function FureyRoom({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [dir, setDir] = useState(params.from === 'top' ? 'top' : 'low');
  const [want, setWant] = useState(pick(params.want, v => [1, 2, 3].includes(v), params.from === 'top' ? 3 : 1));
  const [doubled, setDoubled] = useState(params.count !== 'on-shell');
  const [n, setN] = useState(pick(params.n, v => NS.includes(v), params.from === 'top' ? 14 : 8));
  useEffect(() => {
    const top = params.from === 'top'; setDir(top ? 'top' : 'low'); setDoubled(params.count !== 'on-shell');
    setWant(pick(params.want, v => [1, 2, 3].includes(v), top ? 3 : 1)); setN(pick(params.n, v => NS.includes(v), top ? 14 : 8));
  }, [params.from, params.want, params.count, params.n]);
  const flip = on => { const top = !!on; setDir(top ? 'top' : 'low'); setWant(top ? 3 : 1); setN(top ? 14 : 8); };
  const T = useStored(params), L = ledger(want, doubled), U = 34;
  const name = t => (research ? <Sc s={TN(t)} /> : PLAIN[t]);
  const list = (m, unit = '') => typeList(m).map(([t, k], i) => <tspan key={t}>{i ? ', ' : ''}{name(t)}{` ${k}${unit}`}</tspan>);
  const shortCount = k => { const c = typeList(E.missingFor(k, doubled)).reduce((a, [, x]) => a + x, 0); return c ? `${c} short` : 'nothing short'; };
  const shortText = k => { const l = typeList(E.missingFor(k, doubled)); return l.length ? <>{'short of '}{l.map(([t, x], i) => <tspan key={t}>{i ? ', ' : ''}<Sc s={TN(t)} />{` ${x}`}</tspan>)}</> : 'nothing short'; };
  const genRows = [1, 2, 3].map(k => ({ key: String(k), title: research ? `${k} set${k > 1 ? 's' : ''}` : `${k} famil${k > 1 ? 'ies' : 'y'}`, detail: research ? shortText(k) : shortCount(k) }));
  const R = T ? roomLadder(T.fp.room) : null, rung = R ? R.find(x => x.n === n) : null, W = T ? wSearch(T.tg) : null, H = T ? whole(T.tg) : null;
  const roomRows = NS.map(k => { const r = R ? R.find(x => x.n === k) : null; return { key: String(k), title: research ? String(k) : `${k} lanes`, detail: r ? (research ? `best ${r.best} · ${thousands(r.structures)}` : `${r.best} famil${r.best === 1 ? 'y' : 'ies'}`) : '', empty: !!R && !r }; });
  return (
    <div className="fig fig-furey-room">
      <FigSvg id="furey-room" row={row} viewBox="0 0 760 476">
        <g data-ledger={want} data-count={doubled ? 'doubled' : 'on-shell'} data-missing={typeList(L.missing).map(([t, k]) => `${t}:${k}`).join(',')} data-surplus={typeList(L.surplus).map(([t, k]) => `${t}:${k}`).join(',')} data-surplus-dim={L.surplusDim} data-complete={L.complete}>
          <text x={4} y={14} className="t-small t-muted">{research ? 'complete sets of each type, rung by rung' : 'complete families, kind by kind'}</text>
          <Rungs x={0} y={24} w={360} rows={genRows} on={want - 1} dir={dir} step={34} param="want"
            up={() => (research ? 'one more copy of each type' : 'one more of each')} down={() => (research ? 'restricted: one copy of each type fewer' : 'one fewer of each')} />
          {L.types.map((x, i) => {
            const y = 132 + i * 22;
            return (
              <g key={x.t} data-ledger-type={x.t} data-have={x.have} data-short={x.short}>
                <text x={4} y={y + 13} className="t-tiny">{name(x.t)}</text>
                <rect x={128} y={y} width={x.have * U} height={16} rx={3} className="ink" style={{ fillOpacity: 0.75 }} />
                <text x={133} y={y + 12} className="t-tiny t-bold" style={{ fill: 'var(--panel)' }}>{x.have}</text>
                {x.short > 0 && <rect x={128 + x.have * U} y={y} width={x.short * U} height={16} rx={3} className="on-panel" style={{ stroke: 'var(--fg)', strokeDasharray: '4 3' }} />}
                {x.short > 0 && <text x={132 + x.have * U} y={y + 12} className="t-micro">short</text>}
              </g>
            );
          })}
          <line x1={128 + want * U} y1={126} x2={128 + want * U} y2={266} className="stroke-ink" style={{ strokeDasharray: '3 3' }} />
          <text x={131 + want * U} y={274} className="t-micro">{`wanted ${want}`}</text>
          {(() => { const miss = typeList(L.missing), cut = research ? miss.length : 3, line = (part, k0) => part.map(([t, k], i) => <tspan key={t}>{i + k0 ? ', ' : ''}{name(t)}{` ${k}`}</tspan>);
            return (<>
              <text x={4} y={292} className="t-small">{miss.length ? <>{'short of: '}{line(miss.slice(0, cut), 0)}</> : 'nothing short'}</text>
              {miss.length > cut && <text x={4} y={306} className="t-small">{line(miss.slice(cut), cut)}</text>}
            </>); })()}
          <text x={4} y={322} className="t-tiny">{research ? 'beyond the complete sets: ' : 'left over: '}{list(L.surplus)}{` · ${L.surplusDim}${research ? 'ℂ' : ' places'}`}</text>
        </g>

        <g data-room={n}>
          <text x={392} y={14} className="t-small t-muted">{research ? 'complete sets by complex dimension (linear off-diagonal cells)' : 'room for families'}</text>
          <Rungs x={390} y={24} w={176} rows={roomRows} on={NS.indexOf(n)} dir={dir} step={30} param="n"
            up={() => (research ? 'one dimension more' : 'one lane more')} down={() => (research ? 'one dimension fewer' : 'one lane fewer')} />
          {!rung ? <Loading x={578} y={30} w={178} h={180} what="room" /> : (() => {
            const mx = Math.max(...rung.hist.map(h => h.count)), bw = 30, gx = i => 584 + i * 34, base = 190;
            return (
              <g data-room-rung={n} data-structures={rung.structures} data-best={rung.best} data-max-s={rung.maxS} data-total={rung.total}>
                {rung.hist.map((h, i) => {
                  const hh = r1(130 * Math.log10(h.count + 1) / Math.log10(mx + 1)), her = n === T.fp.room.her_frame.dimension && h.S === T.fp.room.her_frame.S;
                  return (
                    <g key={h.S} data-hist-sets={h.sets} data-count={h.count} data-her={her ? 1 : 0}>
                      <rect x={gx(i)} y={base - hh} width={bw} height={hh} rx={2} className={h.sets === rung.best ? 'ink' : 'ink-muted'} style={{ fillOpacity: h.sets === rung.best ? 0.85 : 0.4 }} />
                      <text x={gx(i) + bw / 2} y={base - hh - 4} textAnchor="middle" className="t-micro t-mono">{thousands(h.count)}</text>
                      <text x={gx(i) + bw / 2} y={base + 12} textAnchor="middle" className="t-tiny t-bold">{h.sets}</text>
                      {her && <text x={gx(i) + bw / 2} y={base + 24} textAnchor="middle" className="t-micro">{research ? 'hers' : 'her board'}</text>}
                    </g>
                  );
                })}
                <text x={584} y={base + 36} className="t-micro t-muted">{research ? 'structures by complete sets held (log scale)' : 'layouts by families held'}</text>
              </g>
            );
          })()}
          {rung && (
            <text x={392} y={252} className="t-tiny" data-her={`${T.fp.room.her_frame.dimension},${T.fp.room.her_frame.sets}`} data-first-three={T.fp.room.first_dimension_with_three_sets}>
              {research ? `${thousands(rung.structures)} structures · best ${rung.best} · her structure holds ${T.fp.room.her_frame.sets} (dimension ${T.fp.room.her_frame.dimension}) · three sets first at ${T.fp.room.first_dimension_with_three_sets}`
                : `${thousands(rung.structures)} layouts · most families that fit: ${rung.best} · her board holds ${T.fp.room.her_frame.sets} · three families first fit at ${T.fp.room.first_dimension_with_three_sets}`}
            </text>
          )}
          {rung && research && <text x={392} y={268} className="t-micro t-mono" data-example={rung.example.join(' ')}>{`a structure with the best: ${rung.example.map(s => s.replace(/3b/g, '3̄').replace(/-/g, '−')).join(' ')}`}</text>}
        </g>

        <g transform="translate(0, 338)">
          <text x={4} y={12} className="t-small t-muted">{research ? 'generations held, over every admissible W of dimension 8' : 'every layout of 8 lanes: families held'}</text>
          {research && <text x={4} y={24} className="t-micro t-muted">{'in the linear off-diagonal and the antilinear cells'}</text>}
          {!W ? <Loading x={8} y={30} w={350} h={96} what="search" /> : (
            <g data-w-admissible={W.admissible} data-w-max={W.max} data-w-total={W.total}>
              {W.gens.map((g, i) => {
                const mx = Math.max(...W.gens.map(x => x.count)), hh = g.count ? r1(56 * Math.log10(g.count + 1) / Math.log10(mx + 1)) : 0, x = 12 + i * 52, base = 104;
                return (
                  <g key={g.g} data-w-gen={g.g} data-count={g.count}>
                    {g.count ? <rect x={x} y={base - hh} width={40} height={hh} rx={2} className="ink" style={{ fillOpacity: 0.7 }} />
                      : <rect x={x} y={base - 56} width={40} height={56} rx={2} className="on-panel" style={{ stroke: 'var(--muted)', strokeDasharray: '4 3' }} />}
                    <text x={x + 20} y={g.count ? base - hh - 4 : base - 28} textAnchor="middle" className="t-micro t-mono">{thousands(g.count)}</text>
                    <text x={x + 20} y={base + 12} textAnchor="middle" className="t-tiny t-bold">{g.g}</text>
                  </g>
                );
              })}
              <text x={226} y={50} className="t-tiny">{research ? `admissible W: ${thousands(W.admissible)}` : `layouts: ${thousands(W.admissible)}`}</text>
              <text x={226} y={66} className="t-tiny">{research ? `at most ${W.max} generations` : `at most ${W.max} families`}</text>
              {research && (
                <text x={4} y={132} className="t-micro" data-max-copies={W.copies.map(c => `${c.t}:${c.max}`).join(',')}>
                  {'each type alone, at most: '}{W.copies.map((c, i) => <tspan key={c.t}>{i ? ' · ' : ''}<Sc s={TN(c.t)} />{` ${c.max}`}</tspan>)}
                </text>
              )}
            </g>
          )}
          <text x={392} y={12} className="t-small t-muted">{research ? 'the 128 complex dimensions of End(V)' : 'the 128 places'}</text>
          {!H ? <Loading x={392} y={20} w={364} h={96} what="dimensions" /> : (
            <g data-whole-total={H.total} data-real={H.real}>
              {(() => { let x = 392; return H.parts.map((p, i) => { const w = (p.dim / H.total) * 364, x0 = x; x += w; return (
                <g key={p.key} data-whole-part={p.key} data-dim={p.dim}>
                  <rect x={r1(x0)} y={20} width={r1(w - 2)} height={26} rx={3} className="ink" style={{ ...PART_STYLE[i], stroke: 'var(--fg)', strokeWidth: 0.8, strokeDasharray: i === 3 ? '4 2' : undefined }} />
                  <text x={r1(x0 + (w - 2) / 2)} y={37} textAnchor="middle" className="t-small t-bold" style={i === 1 ? { fill: 'var(--panel)' } : undefined}>{p.dim}</text>
                </g>); }); })()}
              {H.parts.map((p, i) => (
                <g key={'k' + p.key}>
                  <rect x={392} y={56 + i * 14} width={12} height={9} rx={2} className="ink" style={{ ...PART_STYLE[i], stroke: 'var(--fg)', strokeWidth: 0.8, strokeDasharray: i === 3 ? '3 2' : undefined }} />
                  <text x={410} y={64 + i * 14} className="t-micro">{`${PARTS[research ? 'research' : 'learner'][i]} ${p.dim}`}</text>
                </g>
              ))}
              {research && <text x={392} y={124} className="t-micro">{`${H.parts.map(p => p.dim).join(' + ')} = ${H.total} = ${H.real} / 2 · ${H.real} = the 2⁸ labels of Cl(0,8)`}</text>}
            </g>
          )}
        </g>
      </FigSvg>
      <Controls label="generations and room">
        <Chips label={research ? 'sets wanted' : 'families wanted'} items={[1, 2, 3]} value={want} onPick={setWant} param="want" />
        <Chips label="count" items={[false, true]} value={doubled} onPick={setDoubled} param="count" render={d => (d ? (research ? 'every cell doubled' : 'both names') : (research ? 'one label per cell' : 'one name per box'))} />
        <Chips label={research ? 'complex dimension' : 'lanes'} items={NS} value={n} onPick={setN} param="n" />
        <Toggle label="from the top" on={dir === 'top'} onChange={flip} param="from" />
      </Controls>
    </div>
  );
}
FureyRoom.meta = { id: 'furey-room', lenses: [], learner: true };
FureyRoom.params = [{}, { from: 'top' }, { want: 3, count: 'on-shell', n: 11 }];
/** the numbers the figure draws, for the frame's data download */
FureyRoom.data = (params = {}) => {
  const T = peekStored(params), doubled = params.count !== 'on-shell';
  return {
    ledger: [1, 2, 3].map(k => { const L = ledger(k, doubled); return { k, doubled, have: Object.fromEntries(L.types.map(x => [x.t, x.have])), missing: L.missing, surplus: L.surplus, surplusDim: L.surplusDim }; }),
    room: T ? roomLadder(T.fp.room).map(r => ({ n: r.n, structures: r.structures, best: r.best, hist: r.hist })) : null,
    search: T ? wSearch(T.tg) : null, whole: T ? whole(T.tg) : null,
  };
};
