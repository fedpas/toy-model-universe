// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure rigid-segment (step 16, the first rung; caption row EQN-019; docs/PHYSICS_AUDIT.md RB1): a segment, the rigid body of one dimension, in R(1,0,1).
// Left, the mass on its anchor at 1/2 and its spring (a zigzag: plain for +k, dashed for the reversed spring −k, faint with no spring, each with its word);
// right, the position against time: solid the engine (engines/pgaEngine.js stepRK4 on M′ = −½MB, B′ = A⁻¹(F + ½[B, A(B)]), the kernel's signs), dashed the closed
// form. The readouts are v15's (RigidWidgets.jsx SegmentSpring): the equations, the motor M = 1 + (·)e₀₁ now, the engine against the closed form, the kind of i
// (the matrix [[0, 1], [−k, 0]] of the pair (x, b) squares to −k·I: a rotation, a boost or the null i), the rest point a − g/k. Added under D29: the exact series
// of the position through t¹⁰, computed live on the kernel (engines/physics/rigid.js segmentSeries), equal to the closed form's series, and at the state of row
// B3 (spring, x₀ = 2, g = 0) equal to the series pgadyn.json stores. Research level only (no L: in the audit). Controls of v15: the kind, the start, gravity,
// the time and Play.
import React, { useEffect, useMemo, useState } from 'react';
import { alg, unitC, hangForce, stepRK4 } from '../../../engines/pgaEngine.js';
import { segmentSeries, closedSeries, kindOfI, qTenths, qEq } from '../../../engines/physics/rigid.js';
import { FigSvg, Controls, Chips, Range, PlayButton, useReducedMotion, r1, f2 } from '../kit.jsx';
import { useStoredP11, useKatex, Tex, Ok, KV, seriesText, seriesStrings } from './rigidParts.jsx';

const KINDS = ['spring', 'anti', 'free'];
const KIND_WORD = { spring: 'spring (+k)', anti: 'reversed spring (−k)', free: 'no spring' };
const I_WORD = { rotation: 'a rotation: the oscillator, cos', boost: 'a boost: cosh', null: 'the null i: free motion' };
const A_ANCHOR = 0.5, A_EXACT = '1/2', H = 0.01;
const f3 = x => (Math.abs(x) < 5e-5 ? '0' : String(Math.round(x * 1000) / 1000).replace('-', '−'));
const zig = (x1, y1, x2, y2, m = 9, w = 7) => { const dx = x2 - x1, dy = y2 - y1, L = Math.hypot(dx, dy) || 1, px = -dy / L, py = dx / L, pts = [[x1, y1]]; for (let i = 1; i < 2 * m; i++) { const s = i / (2 * m), sg = i % 2 ? 1 : -1; pts.push([x1 + dx * s + px * w * sg, y1 + dy * s + py * w * sg]); } pts.push([x2, y2]); return pts.map(([x, y], i) => (i ? 'L' : 'M') + r1(x) + ' ' + r1(y)).join(' '); };

/** the state of the figure from its parameters (the v15 sliders: x₀ = value / 10 in −1 … 3, g = value / 10 in 0 … 4, t = value / 100 of the run) */
export function segmentState(params = {}) {
  const kind = KINDS.includes(params.kind) ? params.kind : 'spring';
  const x0 = Number.isInteger(params.x0) && params.x0 >= -10 && params.x0 <= 30 ? params.x0 : 20;
  const g = Number.isInteger(params.g) && params.g >= 0 && params.g <= 40 ? params.g : 0;
  const t = Number.isInteger(params.t) && params.t >= 0 && params.t <= 100 ? params.t : 35;
  return { kind, x0, g, t, k: kind === 'spring' ? 4 : kind === 'anti' ? -4 : 0 };
}
/** the run of the engine and the exact side, as the figure draws them */
export function segmentRun({ kind, x0, g, k }) {
  const X0 = x0 / 10, G = g / 10, T = kind === 'anti' ? 1.6 : 6, A = alg(1), c = unitC(A);
  const F = hangForce(A, { g: G, m: 1, k, alpha: 0, pb: [0], anchor: [A_ANCHOR] });
  let st = { M: A.trans([X0]), B: A.z() }; const xs = [X0], motor = [st.M[3]];
  for (let i = 0; i < Math.round(T / H); i++) { st = stepRK4(A, st, c, F, H); xs.push(A.pos(A.sand(st.M, A.point([0])))[0]); motor.push(st.M[3]); }
  const rest = k ? A_ANCHOR - G / k : null;
  const exact = tm => (k > 0 ? rest + (X0 - rest) * Math.cos(Math.sqrt(k) * tm) : k < 0 ? rest + (X0 - rest) * Math.cosh(Math.sqrt(-k) * tm) : X0 - G * tm * tm / 2);
  const err = Math.max(...xs.map((v, j) => Math.abs(v - exact(j * H))));
  const q = { k, a: A_EXACT, x0: qTenths(x0), g: qTenths(g) };
  const series = segmentSeries({ ...q, pb: '0' }).series, closed = closedSeries(q);
  return { X0, G, T, xs, motor, rest, exact, err, series, closed, seriesOk: !!closed && series.every((v, j) => qEq(v, closed[j])), I: kindOfI(k) };
}
/** the state of row B3 of pgadyn_selfcheck.py: a spring k = 4, the anchor at 1/2, released at rest from 2, no gravity */
export const isB3 = s => s.kind === 'spring' && s.x0 === 20 && s.g === 0;

export default function RigidSegment({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const p0 = segmentState(params);
  const [kind, setKind] = useState(p0.kind), [x0, setX0] = useState(p0.x0), [g, setG] = useState(p0.g), [tt, setTt] = useState(p0.t), [playing, setPlaying] = useState(false);
  useEffect(() => { const p = segmentState(params); setKind(p.kind); setX0(p.x0); setG(p.g); setTt(p.t); }, [params.kind, params.x0, params.g, params.t]);   // eslint-disable-line react-hooks/exhaustive-deps
  const reduced = useReducedMotion(), katex = useKatex(research), S = useStoredP11();
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => setTt(x => (x >= 100 ? 0 : x + 1)), 40); return () => clearInterval(id); }, [playing, reduced]);
  const k = kind === 'spring' ? 4 : kind === 'anti' ? -4 : 0, st = { kind, x0, g, k };
  const run = useMemo(() => segmentRun(st), [kind, x0, g]);   // eslint-disable-line react-hooks/exhaustive-deps
  const i = Math.round(tt / 100 * (run.xs.length - 1)), tm = i * H, xn = run.xs[i], xe = run.exact(tm);
  const lo = Math.min(...run.xs.map((v, j) => Math.min(v, run.exact(j * H))), -1), hi = Math.max(...run.xs.map((v, j) => Math.max(v, run.exact(j * H))), 3);
  const sy = 150 / (hi - lo), oy = 175 + lo * sy, sx = 230 / run.T, Y = x => Math.max(4, Math.min(196, oy - sy * x));
  const path = (f, every) => { const pts = []; for (let j = 0; j < run.xs.length; j += every) pts.push([100 + sx * j * H, Y(f(j))]); return pts.map(([x, y], m) => (m ? 'L' : 'M') + r1(x) + ' ' + r1(y)).join(' '); };
  const stored = S && S.segment && S.segment.B3 ? S.segment.B3.series : null, b3 = isB3(st);
  const storedOk = stored ? seriesStrings(run.series).join() === stored.join() : null;
  const ser = seriesText(run.series);
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => setTt(x => (x >= 100 ? 0 : Math.min(100, x + 10))) };
  const springCls = kind === 'free' ? 'stroke-muted' : 'stroke-ink';
  return (
    <div className="fig fig-rigid rg-seg" data-kind={kind} data-k={k} data-x0={x0} data-g={g}>
      <FigSvg id="rigid-segment" row={row} viewBox="0 0 360 214">
        <line x1={40} y1={6} x2={40} y2={198} className="hair" />
        <rect x={28} y={r1(Y(A_ANCHOR) - 3)} width={24} height={6} className="ink-muted" data-anchor={A_ANCHOR} />
        <path d={zig(40, Y(A_ANCHOR), 40, Y(xn))} className={springCls} style={{ strokeWidth: 1.6, strokeDasharray: kind === 'anti' ? '3 2' : undefined, strokeOpacity: kind === 'free' ? 0.35 : 1 }} data-spring={kind} />
        <circle cx={40} cy={r1(Y(xn))} r={7} className="ink" data-mass={f3(xn)} />
        <text x={40} y={r1(Y(xn) + 3.5)} textAnchor="middle" className="t-tiny on-panel">1</text>
        <text x={8} y={210} className="t-tiny t-muted">{KIND_WORD[kind]}</text>
        <line x1={100} y1={r1(Y(0))} x2={350} y2={r1(Y(0))} className="hair-2" />
        <line x1={100} y1={8} x2={100} y2={198} className="hair-2" />
        <text x={346} y={r1(Y(0) - 4)} textAnchor="end" className="t-tiny t-muted">t</text>
        <text x={104} y={14} className="t-tiny t-muted">x</text>
        <path d={path(j => run.xs[j], 4)} className="stroke-ink" style={{ strokeWidth: 2.2 }} data-curve="engine" />
        <path d={path(j => run.exact(j * H), 10)} className="stroke-muted" style={{ strokeWidth: 1.2, strokeDasharray: '3 4' }} data-curve="closed" />
        <circle cx={r1(100 + sx * tm)} cy={r1(Y(xn))} r={4} className="ink" data-now={f2(tm)} />
        <g transform="translate(212 196)">
          <line x1={0} y1={0} x2={18} y2={0} className="stroke-ink" style={{ strokeWidth: 2.2 }} /><text x={22} y={3.5} className="t-tiny">engine</text>
          <line x1={64} y1={0} x2={82} y2={0} className="stroke-muted" style={{ strokeWidth: 1.2, strokeDasharray: '3 4' }} /><text x={86} y={3.5} className="t-tiny">closed form</text>
        </g>
      </FigSvg>
      {research ? (
        <div className="fig-note rg-note" data-series={seriesStrings(run.series).join(',')} data-closed={run.closed ? seriesStrings(run.closed).join(',') : ''} data-square={run.I.scalar} data-err={run.err}>
          <p><KV k="equations of motion in R(1,0,1)"><Tex katex={katex} tex={"M' = -\\tfrac{1}{2}MB,\\quad B' = A^{-1}\\big(F + \\tfrac{1}{2}[B, A(B)]\\big)"} plain="M′ = −½MB, B′ = A⁻¹(F + ½[B, A(B)])" /></KV></p>
          <p><KV k="the motor now" data-motor={run.motor[i]}><Tex katex={katex} tex={`M = 1 + (${f3(run.motor[i]).replace('−', '-')})\\,e_{01}`} plain={`M = 1 + (${f3(run.motor[i])}) e₀₁`} /></KV>
            <KV k="t">{f2(tm)}</KV></p>
          <p><KV k="engine" data-x={xn}>{`x = ${f3(xn)}`}</KV><KV k="closed form" data-xe={xe}>{f3(xe)}</KV><Ok ok={run.err < 1e-6} /></p>
          <p data-kind-of-i={run.I.kind}><KV k="the kind of i"><Tex katex={katex} tex={`\\begin{pmatrix}0&1\\\\${-k}&0\\end{pmatrix}^{2} = -k\\,I = ${run.I.scalar}\\,I`} plain={`[[0, 1], [${String(-k).replace('-', '−')}, 0]]² = −k·I = ${String(run.I.scalar).replace('-', '−')}·I`} /></KV><span>{I_WORD[run.I.kind]}</span></p>
          <p data-rest={run.rest == null ? '' : run.rest}>{k
            ? <KV k="rest point"><Tex katex={katex} tex={`a - g/k = ${f3(run.rest).replace('−', '-')}`} plain={`a − g/k = ${f3(run.rest)}`} /></KV>
            : <KV k="no rest point"><Tex katex={katex} tex="x = x_0 - g t^{2}/2" plain="x = x₀ − g t²/2" /></KV>}</p>
          <p className="rg-series"><KV k="exact series through t¹⁰, on the kernel"><Tex katex={katex} tex={`x(t) = ${ser.tex} + \\dots`} plain={`x(t) = ${ser.plain} + …`} /></KV>
            <Ok ok={run.seriesOk} yes="= the closed form" no="≠ the closed form" />
            {b3 && stored ? <span data-stored-series={stored.join(',')}><Ok ok={storedOk} yes="= the stored series (B3)" no="≠ the stored series (B3)" /></span> : null}</p>
        </div>
      ) : (
        <p className="fig-readout rg-words" data-kind-of-i={run.I.kind}><span>{KIND_WORD[kind]}</span><span>{I_WORD[run.I.kind]}</span></p>
      )}
      <Controls label="the segment">
        <Chips label="spring" items={KINDS} value={kind} onPick={setKind} render={q => KIND_WORD[q]} param="kind" />
        {research && <Range label="start x₀" value={x0} min={-10} max={30} step={1} onChange={setX0} display={v => f2(v / 10)} param="x0" />}
        {research && <Range label="gravity g" value={g} min={0} max={40} step={1} onChange={setG} display={v => f2(v / 10)} param="g" />}
        {research && <Range label="time" value={tt} min={0} max={100} step={1} onChange={setTt} display={() => f2(tm)} param="t" />}
        <PlayButton player={player} />
      </Controls>
    </div>
  );
}
RigidSegment.meta = { id: 'rigid-segment', lenses: [], learner: false };
RigidSegment.params = [{}, { kind: 'anti', x0: 10, g: 20 }, { kind: 'free', x0: -5, g: 30, t: 80 }, { kind: 'spring', x0: 30, g: 40, t: 0 }];
/** the numbers the figure draws, for the frame's data download and the tests */
RigidSegment.data = (params = {}) => {
  const s = segmentState(params), r = segmentRun(s);
  return { kind: s.kind, k: s.k, x0: r.X0, g: r.G, anchor: A_ANCHOR, rest: r.rest, square: r.I.scalar, kindOfI: r.I.kind, engineError: r.err, series: seriesStrings(r.series), closed: r.closed ? seriesStrings(r.closed) : null, b3: isB3(s) };
};
