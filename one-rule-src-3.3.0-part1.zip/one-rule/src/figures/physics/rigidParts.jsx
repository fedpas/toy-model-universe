// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/rigidParts.jsx — what the figures of step 16 (owner P11) share: the stored results of pgadyn_selfcheck.py (content/stored_p11.json, loaded
// on demand, D34), a formula typeset by KaTeX at research level (its plain form while KaTeX loads, the pattern of src/figures/explore/lens/physics.jsx), a check
// mark told by shape and word, and the series of the exact engine written as TeX or as plain text. Tokens only (rigid.css).
import React from 'react';
import { useTable } from '../../app/content.js';
import { useKatex, texToHtml } from '../../app/math.js';
import { qStr, qIsZero } from '../../../engines/physics/rigid.js';
import './rigid.css';

/** the stored table of step 16, or null while it loads (and in a render that did not prime it) */
export const useStoredP11 = () => useTable('stored_p11')[0] || null;
export { useKatex };

/** a formula: KaTeX once the engine is there (research level only), else the plain form in the mono face */
export function Tex({ tex, plain, katex }) {
  const html = katex ? texToHtml(tex) : null;
  if (html) return <span className="rg-tex" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} />;
  return <span className="rg-tex fig-mono" data-tex={tex}>{plain ?? tex}</span>;
}
/** a verdict: a check mark or a cross with its word, never colour alone */
export function Ok({ ok, yes = 'agrees', no = 'differs' }) {
  const word = ok ? yes : no;
  return <span className={'rg-ok' + (ok ? '' : ' is-bad')} data-ok={ok ? 1 : 0}>{(ok ? '✓' : '✗') + (word ? ` ${word}` : '')}</span>;
}
/** a key and its value in a readout line */
export const KV = ({ k, children, ...rest }) => <span className="rg-kv" {...rest}><span className="rg-k">{k}</span> {children}</span>;

const SUP = { 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const sup = k => String(k).split('').map(d => SUP[d]).join('');
/** the series c₀ + c₁ t + … of rationals as TeX and as plain text (the terms that are not zero, in order) */
export function seriesText(series, v = 't') {
  const terms = [];
  series.forEach((q, j) => {
    if (qIsZero(q)) return;
    const neg = q.n < 0n, num = neg ? -q.n : q.n, den = q.d, one = num === 1n && den === 1n && j > 0;
    const coefTex = den === 1n ? (one ? '' : String(num)) : `\\tfrac{${num}}{${den}}`, coefPlain = den === 1n ? (one ? '' : String(num)) : `(${num}/${den})`;
    const powTex = j === 0 ? '' : j === 1 ? v : `${v}^{${j}}`, powPlain = j === 0 ? '' : j === 1 ? v : v + sup(j);
    terms.push({ neg, tex: (coefTex + powTex) || '1', plain: (coefPlain + powPlain) || '1' });
  });
  if (!terms.length) return { tex: '0', plain: '0' };
  const join = key => terms.map((t, i) => (i === 0 ? (t.neg ? '-' : '') : t.neg ? ' - ' : ' + ') + t[key]).join('');
  return { tex: join('tex'), plain: join('plain').replace(/-/g, '−') };
}
/** a series as the strings the stored json writes */
export const seriesStrings = s => s.map(qStr);
