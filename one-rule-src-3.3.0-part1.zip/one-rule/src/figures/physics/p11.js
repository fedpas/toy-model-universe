// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p11.js — owner P11 registers its figures here (id → component): step 16, the rigid body (docs/PHYSICS_AUDIT.md §2.16).
// The tally line of §2.18 is not a figure: src/components/Section.jsx renders the tally rows through ./TallyLine.jsx.
import RigidSegment from './RigidSegment.jsx';
import RigidSquare from './RigidSquare.jsx';
import RigidFrameTable from './RigidFrameTable.jsx';
import RigidMatrix from './RigidMatrix.jsx';
export const P11_FIGURES = { 'rigid-segment': RigidSegment, 'rigid-square': RigidSquare, 'rigid-frame-table': RigidFrameTable, 'rigid-matrix': RigidMatrix };
