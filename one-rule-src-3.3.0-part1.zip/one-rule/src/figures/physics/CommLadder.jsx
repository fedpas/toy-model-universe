// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure comm-ladder (caption EQN-007, research level; owner P5: docs/PHYSICS_AUDIT.md CM3, decision D37): the commutators of bivectors for n = 2 … 8 generators as a
// ladder. The table is v15's (EquationsSection CommTab, "the rule, for every number of generators"): per rung the bivectors C(n,2), the pairs that do not commute
// n(n−1)(n−2)/2, the pairs that commute, the closed triangles C(n,3) and the signatures checked, every number read from the stored table (content/stored_p5.json =
// equations.json commutators.by_n, D34); a rung the table lacks is drawn empty and marked "not stored" (D37). The drawing is the chosen rung's commutator graph,
// recomputed by the kernel (engines/physics/commutators.js graphOf), in the lens of the frame (D37: the lens picker at every rung). clifford (e₁e₂), demicube (0011)
// and prime (2·3): the bivectors on a circle, a chord for each pair that does not commute; in the demicube the chords are its edges between the corners of layer 2,
// and the scalar 0…0 in the centre is one demicube edge from each. simplex: the generators at the corners of a polygon, each bivector the edge {i,j} between two;
// two edges that share a corner do not commute. cube: the layers 0, 1, 2 of the n-cube, each bivector joined to its two generators; two bivectors under one
// generator do not commute. "From the top" starts at the highest stored rung and draws each lower rung as its restriction: the bivectors of the first n generators
// filled and their lines solid, the rest as rings and faint dashed lines (shape and word, never colour alone). Tokens only. Controls: the rung, from the top.
// Layout: the drawing with its key and the table side by side in a .fig-panels block (a wide seed, D31: the drawing first, the controls under it).
import React, { useEffect, useMemo, useState } from 'react';
import { useTable } from '../../app/content.js';
import { label } from '../../../engines/bitrule.js';
import { LADDER, graphOf, countsOf } from '../../../engines/physics/commutators.js';
import { FigSvg, Controls, Chips, Toggle, r1 } from '../kit.jsx';

const W = 340, H = 304, CX = 170, CY = 152, R = 100;
const LENSES = ['clifford', 'simplex', 'cube', 'demicube', 'prime'];
const lensOf = l => (LENSES.includes(l) ? l : l === 'primes' ? 'prime' : l === 'bits' ? 'cube' : 'clifford');
/** the label of a bivector (or a generator) in a lens, printed by the kernel */
export const nameIn = (m, lens, n) => (lens === 'simplex' ? label(m, 'set') : lens === 'cube' || lens === 'demicube' ? label(m, 'bits', new Array(n).fill(1)) : lens === 'prime' ? label(m, 'primes') : label(m, 'clifford'));
const KEY = {
  clifford: 'a dot: a bivector · a chord: a pair that does not commute · no chord: the pair commutes',
  prime: 'a dot: a product of two primes · a chord: two products sharing one prime, a pair that does not commute',
  demicube: 'a dot: a corner of layer 2 · a chord: a demicube edge between two of them, a pair that does not commute · centre: the scalar',
  simplex: 'a corner: a generator · an edge {i,j}: a bivector · two edges with a common corner do not commute',
  cube: 'rows: the layers 0, 1, 2 of the cube · a bivector joined to its two generators · two bivectors under one generator do not commute',
};
const ring = { stroke: 'var(--muted)', strokeWidth: 1 }, MUTED = { color: 'var(--muted)' };
/** the drawing and the table side by side when the frame is wide (the table takes three parts of the room, the drawing one), one under the other when it is not */
const PANELS = { display: 'flex', flexWrap: 'wrap', alignItems: 'flex-start', gap: '12px 24px', minWidth: 0 }, PART = (g, b) => ({ flex: `${g} 1 ${b}px`, minWidth: 0 });
const HALO = { paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3, strokeLinejoin: 'round' };
const lineStyle = (lit, w) => (lit ? { strokeOpacity: 0.55, strokeWidth: w } : { strokeOpacity: 0.35, strokeWidth: 0.6, strokeDasharray: '2 3' });
const sizeOf = k => (k > 15 ? 't-micro' : k > 10 ? 't-tiny' : 't-small');

function Node({ x, y, r, lit, m, name }) {
  return (
    <g data-node={m} data-lit={lit ? 1 : 0} data-label={name}>
      <title>{name}</title>
      {lit ? <circle cx={r1(x)} cy={r1(y)} r={r} className="ink" /> : <circle cx={r1(x)} cy={r1(y)} r={r} className="on-panel" style={ring} />}
    </g>
  );
}
/** a label at a point of the circle: horizontal for few, radial for many */
function CircleLabel({ a, text, k }) {
  const c = Math.cos(a), s = Math.sin(a);
  if (k <= 10) return <text x={r1(CX + (R + 17) * c)} y={r1(CY - (R + 17) * s + 3.5)} textAnchor="middle" className="t-mono t-small">{text}</text>;
  const x = CX + (R + 8) * c, y = CY - (R + 8) * s, left = c < -1e-9, deg = r1((-a * 180) / Math.PI + (left ? 180 : 0));
  return <text x={r1(x)} y={r1(y)} dy="0.32em" textAnchor={left ? 'end' : 'start'} transform={`rotate(${deg} ${r1(x)} ${r1(y)})`} className={'t-mono ' + sizeOf(k)}>{text}</text>;
}
const bitsOf = m => [0, 1, 2, 3, 4, 5, 6, 7].filter(i => (m >> i) & 1);

/** the graph of N generators in a lens, the bivectors of the first n lit */
function Drawing({ N, n, lens }) {
  const G = useMemo(() => graphOf(N), [N]), inR = m => m < 1 << n, k = G.nodes.length, nm = m => nameIn(m, lens, N);
  if (lens === 'simplex') {
    const V = Array.from({ length: N }, (_, i) => { const a = Math.PI / 2 - (2 * Math.PI * i) / N; return [CX + R * Math.cos(a), CY - R * Math.sin(a), a]; });
    return (
      <g data-layout="simplex">
        {G.nodes.map(m => { const [i, j] = bitsOf(m), P = V[i], Q = V[j], lit = inR(m), mx = (P[0] + Q[0]) / 2, my = (P[1] + Q[1]) / 2; return (
          <g key={m} data-node={m} data-lit={lit ? 1 : 0} data-label={nm(m)}>
            <title>{nm(m)}</title>
            <line x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className={lit ? 'stroke-ink' : 'stroke-muted'} style={lineStyle(lit, 1.1)} />
            {lit ? <circle cx={r1(mx)} cy={r1(my)} r={2.4} className="ink" /> : <circle cx={r1(mx)} cy={r1(my)} r={2.4} className="on-panel" style={ring} />}
            {N <= 4 ? <text x={r1(mx + 4)} y={r1(my - 4)} className="t-mono t-tiny t-muted">{nm(m)}</text> : null}
          </g>); })}
        {V.map(([x, y, a], i) => <g key={'v' + i} data-gen={i}><Node x={x} y={y} r={5} lit={i < n} m={1 << i} name={nm(1 << i)} /><CircleLabel a={a} text={nm(1 << i)} k={N} /></g>)}
      </g>
    );
  }
  if (lens === 'cube') {
    const xs = (cnt, x0, x1) => Array.from({ length: cnt }, (_, i) => (cnt === 1 ? (x0 + x1) / 2 : x0 + ((x1 - x0) * i) / (cnt - 1)));
    const g1 = xs(N, 40, W - 40), g2 = xs(k, 14, W - 14), y0 = 30, y1 = 104, y2 = 200;
    return (
      <g data-layout="cube">
        {g1.map((x, i) => <line key={'h' + i} x1={CX} y1={y0} x2={r1(x)} y2={y1} className="hair-2" />)}
        {G.nodes.map((m, j) => bitsOf(m).map(i => <line key={m + '-' + i} x1={r1(g2[j])} y1={y2} x2={r1(g1[i])} y2={y1} data-inc={`${m},${i}`} className={inR(m) ? 'stroke-ink' : 'stroke-muted'} style={lineStyle(inR(m), 0.9)} />))}
        <Node x={CX} y={y0} r={4} lit m={0} name={nm(0)} />
        <text x={CX + 9} y={y0 + 3.5} className="t-mono t-tiny t-muted">{nm(0)}</text>
        {g1.map((x, i) => <g key={'g' + i} data-gen={i}><Node x={x} y={y1} r={4.5} lit={i < n} m={1 << i} name={nm(1 << i)} /><text x={r1(x)} y={y1 - 9 - (N > 5 ? (i % 2) * 10 : 0)} textAnchor="middle" className={'t-mono ' + (N > 5 ? 't-micro' : 't-tiny')}>{nm(1 << i)}</text></g>)}
        {G.nodes.map((m, j) => <g key={'b' + m}><Node x={g2[j]} y={y2} r={k > 15 ? 3 : 4} lit={inR(m)} m={m} name={nm(m)} /><text x={r1(g2[j])} y={y2 + 8} transform={`rotate(-90 ${r1(g2[j])} ${y2 + 8})`} dy="0.32em" textAnchor="end" className={'t-mono ' + (k > 15 ? 't-micro' : 't-tiny')}>{nm(m)}</text></g>)}
      </g>
    );
  }
  const at = i => { const a = Math.PI / 2 - (2 * Math.PI * i) / k; return [CX + R * Math.cos(a), CY - R * Math.sin(a), a]; }, pos = new Map(G.nodes.map((m, i) => [m, at(i)]));
  return (
    <g data-layout={lens === 'demicube' ? 'demicube' : 'circle'}>
      <circle cx={CX} cy={CY} r={R} className="hair-2" />
      {lens === 'demicube' ? G.nodes.map(m => <line key={'s' + m} x1={CX} y1={CY} x2={r1(pos.get(m)[0])} y2={r1(pos.get(m)[1])} className="hair-2" data-spoke={m} />) : null}
      {G.edges.map(([a, b]) => { const lit = inR(a) && inR(b), P = pos.get(a), Q = pos.get(b); return <line key={a + '-' + b} x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} data-edge={`${a},${b}`} data-lit={lit ? 1 : 0} className={lit ? 'stroke-ink' : 'stroke-muted'} style={lineStyle(lit, k > 15 ? 0.6 : 1)} />; })}
      {lens === 'demicube' ? <><Node x={CX} y={CY} r={4} lit m={0} name={nm(0)} /><text x={CX} y={CY + 15} textAnchor="middle" className="t-mono t-tiny t-muted" style={HALO}>{nm(0)}</text></> : null}
      {G.nodes.map(m => { const [x, y, a] = pos.get(m); return <g key={m}><Node x={x} y={y} r={k > 15 ? 3 : 4.5} lit={inR(m)} m={m} name={nm(m)} /><CircleLabel a={a} text={nm(m)} k={k} /></g>; })}
    </g>
  );
}

const COLS = [['bivectors', 'C(n,2)'], ['edges', 'n(n−1)(n−2)/2'], ['commuting_pairs', ''], ['triangles', 'C(n,3)'], ['signatures_checked', 'p + q = n']];
const HEADS = { bivectors: 'bivectors', edges: 'do not commute', commuting_pairs: 'commute', triangles: 'closed triangles', signatures_checked: 'signatures checked' };

export default function CommLadder({ params = {}, lens = null, level = 'research', theme, row }) {
  const [stored] = useTable('stored_p5');
  const byN = stored && stored.commutators && stored.commutators.by_n ? stored.commutators.by_n : null;
  const okN = v => LADDER.includes(v), held = byN ? LADDER.filter(x => byN[x]) : [], highest = held.length ? held[held.length - 1] : LADDER[LADDER.length - 1];
  const [top, setTop] = useState(params.top === true);
  const [n, setN] = useState(okN(params.n) ? params.n : params.top === true ? highest : LADDER[0]);
  useEffect(() => { setTop(params.top === true); if (okN(params.n)) setN(params.n); }, [params.n, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const pickTop = v => { setTop(v); setN(v ? highest : LADDER[0]); };
  const L = lensOf(lens), state = byN ? (byN[n] ? 'stored' : 'not stored') : 'loading', N = top && byN && byN[highest] ? highest : n, s = byN && byN[n];
  const rungs = top ? [...LADDER].reverse() : LADDER;
  return (
    <div className="fig fig-comm-ladder" data-rung={n} data-top={top ? 1 : 0} data-lens={L} data-state={state}>
      <div className="fig-panels" style={PANELS}>
        <div style={PART(1, 260)}>
          <FigSvg id="comm-ladder" row={row} part={`n = ${n}${top ? `, inside n = ${N}` : ''}, lens ${L}`} viewBox={`0 0 ${W} ${H}`}>
            {state === 'stored' ? <Drawing N={N} n={n} lens={L} /> : (
              <g data-empty={state}>
                <rect x={CX - 90} y={CY - 22} width={180} height={44} rx={6} className="hair-2" style={{ strokeDasharray: '4 3' }} />
                <text x={CX} y={CY + 4} textAnchor="middle" className="t-small t-muted">{state === 'loading' ? 'loading the stored ladder' : 'not stored'}</text>
              </g>
            )}
          </FigSvg>
          <p className="mx-counts" data-key={L}>{KEY[L]}{top && state === 'stored' ? ` · filled: the first ${n} generators (n = ${n}) · rings and dashes: the rest of n = ${N}` : ''}</p>
        </div>
        <div style={PART(3, 340)}>
          <p className="mx-head" data-head={s ? COLS.map(([f]) => s[f]).join(',') : state}>
            {s ? `n = ${n} · ${COLS.map(([f]) => `${HEADS[f]} ${s[f]}`).join(' · ')}` : `n = ${n} · ${state === 'loading' ? 'loading the stored ladder' : 'not stored'}`}
          </p>
          <div className="fig-scroll">
            <table className="mx-table" data-ladder="comm">
              <caption>{top ? `from the top: n = ${highest} down to ${LADDER[0]}` : `the ladder: n = ${LADDER[0]} up to ${LADDER[LADDER.length - 1]}`}</caption>
              <thead><tr><th>n</th>{COLS.map(([f, sub]) => <th key={f}>{HEADS[f]}{sub ? <><br /><span style={MUTED}>{sub}</span></> : null}</th>)}</tr></thead>
              <tbody>
                {byN ? rungs.map(x => { const r = byN[x], cur = x === n; return (
                  <tr key={x} className={cur ? 'mx-cur' : undefined} aria-current={cur ? 'true' : undefined} data-row={x} data-stored={r ? 1 : 0} data-values={r ? COLS.map(([f]) => r[f]).join(',') : ''}>
                    <td>{x}</td>{r ? COLS.map(([f]) => <td key={f}>{r[f]}</td>) : <td colSpan={COLS.length} style={MUTED}>not stored</td>}
                  </tr>); }) : <tr><td colSpan={COLS.length + 1} style={MUTED}>loading the stored ladder</td></tr>}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <Controls label="the ladder">
        <Chips label="rung n" items={rungs} value={n} onPick={setN} param="n" mono />
        <Toggle label="from the top" on={top} onChange={pickTop} param="top" />
      </Controls>
    </div>
  );
}
CommLadder.meta = { id: 'comm-ladder', lenses: LENSES, learner: false };
/** the parameter sets tests/figures.render.test.mjs renders */
CommLadder.params = [{}, { n: 4 }, { n: 8 }, { n: 5, top: true }, { top: true }];
/** the numbers the figure prints, recomputed by the kernel, for the frame's data download */
CommLadder.data = (params = {}) => ({ rung: LADDER.includes(params.n) ? params.n : LADDER[0], top: params.top === true, ladder: LADDER.map(countsOf) });
