// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-matrix (step 5; caption row SPN-001; docs/PHYSICS_AUDIT.md SP7, SP8): the 30-line translation matrix of the paper "From Invariant
// Decomposition to Spinors" and the lecture "Rotors and Spinors" against the bit rule, from checks/selfcheck/spin.json (matrix), through the stored
// table content/stored_p6.json. Each line is a row of the Atlas, SPN-M01 … SPN-M30 (D35): the paper's formula and/or the lecture's ↔ the bit rule's,
// v15's status of the line (agrees exactly 22, printed line differs 2, not checked 6), the thread, and, opened, its worked instance (left side,
// right side), the source's reference and page, the one-line check and its re-run command; the badge of the row in the folded column. Filters by
// status and by thread (v15's chips). Under the table, the findings for the authors (id, kind, reference; SP8). Learner level: the strip of the
// 30 lines and the counts by status. Port of v15 SpinSection.jsx (the translation matrix by subject, its filters, RowView).
import React, { useMemo } from 'react';
import TranslationMatrix from './TranslationMatrix.jsx';
import { useStoredP6, STATUS_WORDS, SPIN_THREADS, SPIN_SRC, FINDING_WORDS } from './p6kit.jsx';
import './translation.css';

/** the rows of the table: the stored lines (left, right, status, thread) with each line's detail from the stored row */
export function spinRows(S) {
  const byId = new Map(S.spin.matrix.rows.map(r => [r.id, r]));
  return S.derived.spinLines.map(l => {
    const r = byId.get(l.id) || {}, P = r.paper || null, L = r.lecture || null, w = r.worked || null, nc = l.status === 'nc';
    const page = (P && P.page) || r.page || null;
    const detail = [
      !nc && P && P.ref ? ['paper', `${P.ref}${P.page ? `, p. ${P.page}` : ''}`, 'paper'] : null,
      !nc && L && L.ref ? ['lecture', L.ref, 'lecture'] : null,
      nc && page ? ['page', String(page), 'page'] : null,
      w ? ['worked instance', w.inst, 'inst'] : null,
      w ? ['left side', w.lhs, 'lhs'] : null,
      w ? ['right side', w.rhs, 'rhs'] : null,
      w ? ['agree', w.lhs === w.rhs ? 'equal' : 'not equal', 'equal'] : null,
      r.code ? ['one-line check', r.code, 'code'] : null,
      r.code ? ['re-run', `python3 spin_selfcheck.py --row ${l.id}`, 'cmd'] : null,
    ].filter(Boolean);
    return { id: l.id, left: l.left, right: l.right, badgeRow: l.row, status: l.status, group: l.group, ref: SPIN_SRC[l.src] || null, detail };
  });
}

export default function SpinMatrix({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const S = useStoredP6(params);
  const rows = useMemo(() => (S ? spinRows(S) : []), [S]);
  const groups = SPIN_THREADS.map(k => ({ key: k, name: k }));
  const findings = S && level !== 'learner' ? S.spin.matrix.findings : [];
  return (
    <div className="fig fig-spin-matrix">
      <TranslationMatrix rows={rows} title="The translation matrix, by subject" level={level} lens={lens} mode={mode} figId="spin-matrix" row={row}
        columns={{ left: 'paper · lecture', right: 'bit rule' }} statusWords={STATUS_WORDS} groups={groups}
        initial={{ status: params.status, group: params.thread, open: params.open, badges: params.badges, folded: params.folded !== false }} />
      {findings.length ? (
        <details className="p6-fold" data-fold="findings">
          <summary>{`for the authors · ${findings.length}`}</summary>
          <table className="p6-tab">
            <thead><tr><th>line</th><th>kind</th><th>where</th></tr></thead>
            <tbody>{findings.map(f => <tr key={f.id + f.kind} data-finding={f.id} data-kind={f.kind}><td className="m">{f.id}</td><td>{FINDING_WORDS.spin[f.kind] || f.kind}</td><td>{f.ref}</td></tr>)}</tbody>
          </table>
        </details>
      ) : null}
    </div>
  );
}
SpinMatrix.meta = { id: 'spin-matrix', lenses: [], learner: true };
/** the numbers and lines the figure draws (from the stored table when a test gives it) */
SpinMatrix.data = (params = {}) => {
  const S = params.stored || null;
  if (!S) return { lines: 0, counts: null };
  return { lines: S.derived.spinLines.length, counts: S.spin.matrix.counts, rows: S.derived.spinLines.map(l => ({ id: l.id, row: l.row, status: l.status, thread: l.group })) };
};
SpinMatrix.params = [{}, { status: 'note' }, { thread: 'pointor' }, { badges: true, open: 'S01' }];
