// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure einstein-terms (step 10, GRV-009; docs/PHYSICS_AUDIT.md E1–E2): where the terms of the Einstein form sit. E_a = Σ_{b<c} ε_{a b c d…} F^{bc} ∧ e^d ∧ …,
// F = R + c e∧e. The n axes on a ring; the index a is the double ring; each line joins a pair {b, c} of the other axes and is one term, with the curvature F^{bc}
// (its two axes filled dots) and a tetrad on each remaining axis (filled squares); C(n − 1, 2) terms. The sign ε_{a b c d…} of a term is the all-null rule's
// (every square 0, the sign of the wedge: engines/physics/gravity.js einsteinTerms, through the kernel). Labels in the base of the page lens (D37); in the cube and
// demicube lenses the corner of the (n − 1)-form E_a is printed too. "From the top" (D37) draws the ring of n = 8 and lights the axes and lines of n, the terms of
// n being the terms of 8 on its first n axes. Beside it: E_a written out with the picked term (KaTeX), the counts gravity_selfcheck.py stored (gravity.json ladder)
// and the ladder n = 2 … 8 in a fold. Learner level: the same ring, the picked piece in words. Port of v15 GravitySection.jsx TermRing and the ladder of step 10.
import React, { useState, useEffect, useMemo } from 'react';
import { FigSvg, Controls, Chips, r1, pick, isIn, tx } from '../kit.jsx';
import { einsteinTerms, NS } from '../../../engines/physics/gravity.js';
import { useStored, peekStored, Tex, useKatex, printing, printLabel, TopToggle, Table, Fold, Loading, D37_LENSES, signed } from './p8kit.jsx';

const TOP = 8, C = [150, 132], RAD = 104;
const okPair = (p, n, a) => Array.isArray(p) && p.length === 2 && p.every(v => Number.isInteger(v) && v >= 0 && v < n && v !== a) && p[0] !== p[1];

export default function EinsteinTerms({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner', how = printing(lens, mode, level);
  const init = () => { const n = pick(params.n, isIn(NS), 4), a = Number.isInteger(params.a) && params.a >= 0 && params.a < n ? params.a : 0; return { n, a, pair: okPair(params.pair, n, a) ? [...params.pair].sort((x, y) => x - y) : null, top: params.top === true }; };
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.n, params.a, JSON.stringify(params.pair || null), params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { n, a, pair, top } = st, set = p => setSt(s => ({ ...s, ...p }));
  const katex = useKatex(research), S = useStored();
  const shown = top ? TOP : n, terms = useMemo(() => einsteinTerms(n, a), [n, a]);
  const term = pair ? terms.find(t => t.b === pair[0] && t.c === pair[1]) : null;
  const pos = k => [C[0] + RAD * Math.cos((-90 + 360 * k / shown) * Math.PI / 180), C[1] + RAD * Math.sin((-90 + 360 * k / shown) * Math.PI / 180)];
  const nm = k => printLabel(1 << k, how, shown), L_ = S ? S.gv.ladder[n] : null, corner = ((1 << n) - 1) ^ (1 << a);
  const lat = k => printLabel(1 << k, 'letters', n);
  const texTerm = t => `${t.eps < 0 ? '-' : '+'}F^{${lat(t.b)}${lat(t.c)}}${t.rest.map(r => `\\wedge e^{${lat(r)}}`).join('')}`;
  const sum = terms.length ? (terms.length <= 6 ? terms : [...terms.slice(0, 3), null]).map(t => (t ? texTerm(t) : `+\\cdots`)).join(' ').replace(/^\+/, '') : '0';
  return (
    <div className="fig fig-einstein-terms gp-split">
      <FigSvg id="einstein-terms" row={row} viewBox="0 0 330 250">
        <g data-n={n} data-a={a} data-shown={shown} data-top={top ? 1 : 0} data-printing={how}>
          {Array.from({ length: shown }, (_, b) => Array.from({ length: shown }, (_, c) => [b, c])).flat().filter(([b, c]) => b < c && b !== a && c !== a).map(([b, c]) => {
            const t = terms.find(x => x.b === b && x.c === c), on = !!t, picked = on && pair && pair[0] === b && pair[1] === c, p = pos(b), q = pos(c);
            return (
              <g key={`${b}-${c}`} className={on ? 'gp-pick' : 'gp-faint'} data-term={on ? `${b},${c}` : undefined} data-eps={on ? t.eps : undefined} data-picked={picked ? 1 : 0}
                {...(on ? { role: 'button', tabIndex: 0, 'data-param': 'pair', 'aria-pressed': !!picked, 'aria-label': `${nm(b)} ${nm(c)}`, onClick: () => set({ pair: picked ? null : [b, c] }), onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); set({ pair: picked ? null : [b, c] }); } } } : {})}>
                <title>{`${nm(b)} ${nm(c)}${on ? `: ε = ${signed(t.eps)}` : ''}`}</title>
                <line x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: picked ? 3 : 1, opacity: pair && !picked ? 0.35 : 0.8 }} />
                {on ? <line x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="gp-hit" /> : null}
              </g>
            );
          })}
          {Array.from({ length: shown }, (_, k) => {
            const p = pos(k), isA = k === a, inPair = term && (k === term.b || k === term.c), isRest = term && term.rest.includes(k), off = k >= n, right = p[0] >= C[0];
            return (
              <g key={k} className={off ? 'gp-faint' : undefined} data-axis={k} data-role={off ? 'off' : isA ? 'index' : inPair ? 'curvature' : isRest ? 'tetrad' : 'other'}>
                {isA ? <><circle cx={r1(p[0])} cy={r1(p[1])} r={9} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} /><circle cx={r1(p[0])} cy={r1(p[1])} r={5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.6 }} /></>
                  : isRest ? <rect x={r1(p[0] - 5)} y={r1(p[1] - 5)} width={10} height={10} className="ink" />
                    : <circle cx={r1(p[0])} cy={r1(p[1])} r={inPair ? 6 : 4.5} className={inPair ? 'ink' : 'on-panel'} style={inPair ? undefined : { stroke: 'var(--fg)', strokeWidth: 1.2 }} />}
                <text x={r1(p[0] + (right ? 13 : -13))} y={r1(p[1] + 4)} textAnchor={right ? 'start' : 'end'} className="t-mono t-small">{nm(k)}</text>
              </g>
            );
          })}
        </g>
      </FigSvg>
      <Controls label={research ? 'the terms of E_a' : 'the pieces of the equation'}>
        <Chips label={research ? 'n' : 'directions'} items={NS} value={n} onPick={v => set({ n: v, a: 0, pair: null })} param="n" mono />
        <Chips label={research ? 'index a' : 'direction'} items={Array.from({ length: n }, (_, k) => k)} value={a} onPick={v => set({ a: v, pair: null })} render={k => printLabel(1 << k, how, n)} param="a" mono />
        <TopToggle on={top} onChange={v => set({ top: v })} research={research} top={TOP} />
      </Controls>
      <div className="gp-side">
        <ul className="gp-legend" data-legend="roles">
          <li><span aria-hidden="true">◎</span>{research ? 'the index a' : 'the direction picked'}</li>
          <li><span aria-hidden="true">●</span>{research ? <>the pair b c: the curvature F<sup>bc</sup></> : 'this piece of the bending'}</li>
          <li><span aria-hidden="true">■</span>{research ? 'a tetrad on each other axis' : 'a frame direction'}</li>
        </ul>
        <p className="gp-read" data-terms={terms.length} data-stored-terms={L_ ? L_.einstein_terms_per_component : ''}>
          <span className="gp-k">{research ? <>terms in E<sub>{lat(a)}</sub></> : 'pieces'}</span> <b>{L_ ? L_.einstein_terms_per_component : terms.length}</b>
          {research ? <><span className="gp-k">tetrads in each</span> <b>{Math.max(0, n - 3)}</b><span className="gp-k">components of E</span> <b data-components={L_ ? L_.einstein_components : ''}>{L_ ? L_.einstein_components : '…'}</b></> : null}
          {research && (how === 'bits') ? <><span className="gp-k">corner of E<sub>{lat(a)}</sub></span> <b data-corner={corner}>{printLabel(corner, 'bits', n)}</b></> : null}
        </p>
        {research && terms.length ? <p className="gp-read" data-sum={terms.map(t => `${t.b}${t.c}:${t.eps}`).join(' ')}><Tex katex={katex} tex={`E_{${lat(a)}} = ${sum}`} text={`E_${lat(a)} = Σ ε F^bc ∧ e^d …`} /></p> : null}
        {term ? (
          <p className="gp-read" data-picked-term={`${term.b},${term.c}`} data-picked-eps={term.eps}>
            {research
              ? <><span className="gp-k">{`term {${lat(term.b)}, ${lat(term.c)}}:`}</span> <Tex katex={katex} tex={`\\varepsilon_{${[a, term.b, term.c, ...term.rest].map(lat).join('')}} = ${term.eps < 0 ? '-1' : '+1'},\\quad F^{${lat(term.b)}${lat(term.c)}}${term.rest.map(r => `\\wedge e^{${lat(r)}}`).join('')}`} text={`ε = ${signed(term.eps)} · F^${lat(term.b)}${lat(term.c)} ∧ ${term.rest.map(r => 'e^' + lat(r)).join(' ∧ ')}`} /></>
              : <span>{`${nm(term.b)}${nm(term.c)}: this piece of the bending · ${term.rest.length ? `a frame direction on ${term.rest.map(nm).join(', ')}` : 'no frame direction'}`}</span>}
          </p>
        ) : null}
        {!S ? <Loading /> : null}
        {research && S ? (
          <Fold title={`The ladder, n = ${top ? `${NS[NS.length - 1]} … ${NS[0]}` : `${NS[0]} … ${NS[NS.length - 1]}`}`} name="ladder">
            <Table name="grav2-ladder" caption="gravity.json ladder (gravity_selfcheck.py)" cols={[['n', 'n'], ['E', 'components of E'], ['t', 'terms in each E_a'], ['te', 'tetrads in each term'], ['dt', 'torsion terms in D E_a'], ['g', 'generators with a cosmological term'], ['gc', 'their curvature components']]}
              rows={(top ? [...NS].reverse() : NS).map(k => { const x = S.gv.ladder[k]; return { key: k, cur: k === n, cells: { n: k, E: x.einstein_components, t: x.einstein_terms_per_component, te: Math.max(0, k - 3), dt: x.divergence_torsion_terms_per_component, g: x.desitter_generators, gc: x.desitter_curvature_components } }; })} />
          </Fold>
        ) : null}
      </div>
    </div>
  );
}
EinsteinTerms.meta = { id: 'einstein-terms', lenses: D37_LENSES, learner: true };
EinsteinTerms.params = [{}, { n: 2 }, { n: 3, a: 1 }, { n: 4, a: 0, pair: [1, 2] }, { n: 5, a: 2, pair: [0, 4] }, { n: 8, a: 7, top: true }, { n: 6, a: 3, pair: [0, 1], top: true }];
/** the numbers the figure draws, for the frame's data download */
EinsteinTerms.data = (params = {}) => {
  const n = pick(params.n, isIn(NS), 4), a = Number.isInteger(params.a) && params.a >= 0 && params.a < n ? params.a : 0, S = peekStored();
  return { n, a, terms: einsteinTerms(n, a), stored: S ? S.gv.ladder[n] : null };
};
