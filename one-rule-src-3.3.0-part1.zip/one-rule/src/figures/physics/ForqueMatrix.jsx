// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure forque-matrix (step 14; caption row FRQ-001; docs/PHYSICS_AUDIT.md FQ2, FQ3, FQ4): the 41-line translation matrix of Dorst and De Keninck's
// "May the Forque Be with You" against the bit rule, from checks/selfcheck/forque.json through the stored table content/stored_p6.json. Each line is a
// row of the Atlas, FRQ-M00 … FRQ-M40 (D35; the numbers of F00 … F40): the paper's equation ↔ the bit rule's, v15's status (agrees exactly 27,
// printed line differs 9, not checked 5), and, opened, where in the paper, the page, the dimensions checked, the worked instance (d, left side =
// right side), the one-line check and its re-run command; the badge of the row in the folded column; filter by status (v15's chips). Two folds: the
// conventions, their symbols against the bit rule's, the input they are (FQ3, as forque.json stores them and v15 printed them), and the findings for
// the authors (id, kind, where; FQ4). Learner level: the strip of the 41 lines and the counts by status. Port of v15 ForqueSection.jsx.
import React, { useMemo } from 'react';
import TranslationMatrix from './TranslationMatrix.jsx';
import { useStoredP6, STATUS_WORDS, FINDING_WORDS } from './p6kit.jsx';
import './translation.css';

/** the rows of the table: the stored lines with each line's detail from the stored row */
export function forqueRows(S) {
  const byId = new Map(S.forque.rows.map(r => [r.id, r]));
  return S.derived.forqueLines.map(l => {
    const r = byId.get(l.id) || {}, w = r.worked || null;
    const detail = [
      r.ref ? ['in the paper', r.ref, 'ref'] : null,
      r.page ? ['page', String(r.page), 'page'] : null,
      Array.isArray(r.dims) && r.dims.length ? ['dimensions', r.dims.join(', '), 'dims'] : null,
      w ? ['worked instance', `d = ${w.d}`, 'inst'] : null,
      w ? ['left side', w.lhs, 'lhs'] : null,
      w ? ['right side', w.rhs, 'rhs'] : null,
      w ? ['agree', w.lhs === w.rhs ? 'equal' : 'not equal', 'equal'] : null,
      r.code ? ['one-line check', r.code, 'code'] : null,
      r.code ? ['re-run', `python3 forque_selfcheck.py --row ${l.id}`, 'cmd'] : null,
    ].filter(Boolean);
    return { id: l.id, left: l.left, right: l.right, badgeRow: l.row, status: l.status, ref: r.page ? `p. ${r.page}` : null, detail };
  });
}

export default function ForqueMatrix({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const S = useStoredP6(params);
  const rows = useMemo(() => (S ? forqueRows(S) : []), [S]);
  const research = level !== 'learner';
  const conv = S && research ? S.derived.conventions : [];
  const findings = S && research ? S.forque.findings : [];
  return (
    <div className="fig fig-forque-matrix">
      <TranslationMatrix rows={rows} title="The translation matrix" level={level} lens={lens} mode={mode} figId="forque-matrix" row={row}
        columns={{ left: 'paper', right: 'bit rule' }} statusWords={STATUS_WORDS}
        initial={{ status: params.status, open: params.open, badges: params.badges, folded: params.folded !== false }} />
      {conv.length ? (
        <details className="p6-fold" data-fold="conventions" open={params.conventions === true || undefined}>
          <summary>{`conventions: their symbols, ours · ${conv.length}`}</summary>
          <div className="p6-scroll">
            <table className="p6-tab">
              <thead><tr><th>paper</th><th>bit rule</th><th>note</th></tr></thead>
              <tbody>{conv.map((c, i) => <tr key={i} data-convention={i}><td className="m">{c.theirs}</td><td className="m">{c.ours}</td><td>{c.note}</td></tr>)}</tbody>
            </table>
          </div>
        </details>
      ) : null}
      {findings.length ? (
        <details className="p6-fold" data-fold="findings">
          <summary>{`for the authors · ${findings.length}`}</summary>
          <table className="p6-tab">
            <thead><tr><th>line</th><th>kind</th><th>where</th></tr></thead>
            <tbody>{findings.map(f => <tr key={f.id + f.kind} data-finding={f.id} data-kind={f.kind}><td className="m">{f.id}</td><td>{FINDING_WORDS.forque[f.kind] || f.kind}</td><td>{f.ref}</td></tr>)}</tbody>
          </table>
        </details>
      ) : null}
    </div>
  );
}
ForqueMatrix.meta = { id: 'forque-matrix', lenses: [], learner: true };
ForqueMatrix.data = (params = {}) => {
  const S = params.stored || null;
  if (!S) return { lines: 0, counts: null };
  return { lines: S.derived.forqueLines.length, counts: S.forque.counts, rows: S.derived.forqueLines.map(l => ({ id: l.id, row: l.row, status: l.status })), conventions: S.derived.conventions.length, findings: S.forque.findings.map(f => f.id) };
};
ForqueMatrix.params = [{}, { status: 'nc' }, { badges: true, open: 'F24', conventions: true }];
