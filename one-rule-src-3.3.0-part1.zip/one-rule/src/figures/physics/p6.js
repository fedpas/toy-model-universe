// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p6.js — owner P6 registers its figures here (id → component): step 5 (spin) and step 14 (forque), docs/PHYSICS_AUDIT.md §2.5, §2.14.
import SpinRotor from './SpinRotor.jsx';
import SpinHestenes from './SpinHestenes.jsx';
import SpinPointor from './SpinPointor.jsx';
import SpinHalves from './SpinHalves.jsx';
import SpinMatrix from './SpinMatrix.jsx';
import ForqueLines from './ForqueLines.jsx';
import ForqueMatrix from './ForqueMatrix.jsx';

export const P6_FIGURES = {
  'spin-rotor': SpinRotor,
  'spin-hestenes': SpinHestenes,
  'spin-pointor': SpinPointor,
  'spin-halves': SpinHalves,
  'spin-matrix': SpinMatrix,
  'forque-lines': ForqueLines,
  'forque-matrix': ForqueMatrix,
};
