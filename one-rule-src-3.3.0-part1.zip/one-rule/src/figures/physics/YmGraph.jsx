// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure ym-graph (step 7, hero of steps/ym; audit YG1, YG7): the gauge algebra so(m) as a graph. The C(m,2) generators B_ab (the bivectors of Cl(0,m)) on a
// circle, a line for each pair that does not commute (two generators sharing one index: 3·C(m,3) lines); pick one and its 2(m−2) neighbours stand out with
// [B_ab, B_bc] = ±2 B_ac, the sign from the kernel (engines/physics/gauge.js soAlgebra, commutator). The counts are the stored ones (content/stored_p7.json
// ym.ladder, yangmills_selfcheck.py), recomputed through the kernel in tests/physics/p7.test.mjs. Port of v15 YangMillsSection.jsx Graph, with its chips
// m = 2 … 8 and its pick of a generator. D37: the chips run from the lowest stored cell up; "from the top" draws so(8) and the chosen so(m) as its restriction
// (the generators of the first m indices, the others faint). Lenses: clifford, cube, demicube, prime print the generators in their base (the grade-2 corners of the
// m-cube and the m-demicube); simplex draws so(m) on the simplex of the m directions, a generator as an edge, the picked edge with its neighbours and the closed
// triangles through it (every index triple a copy of so(3): our reading, YM-008). Learner level: "a dot for each pair of directions · a line where the order matters".
import React, { useEffect, useMemo, useState } from 'react';
import { soAlgebra, commutator, labelIn, genName, restricts, GAUGE_MS, YM_STANDARD } from '../../../engines/physics/gauge.js';
import { FigSvg, Controls, r1 } from '../kit.jsx';
import { useStored, lensKey, intIn, Tex, Rungs, TopSwitch, Readout, Legend, useKatexAt } from './GaugeKit.jsx';

const TOP = 8, C = 180;
const within = (g, m) => g < 2 ** m;
const bTex = g => `B_{${genName(g)}}`;
const coefText = c => (c === 2 ? '2' : c === -2 ? '−2' : String(c));
const coefTex = c => (c === 2 ? '2' : c === -2 ? '-2' : String(c));
/** the commutators of the picked generator with its neighbours in so(m), in v15's order: { other, mask, coef } with the kernel's coefficient */
export function commutatorsOf(m, gen) {
  const A = soAlgebra(m);
  return A.edges.filter(([a, b]) => a === gen || b === gen).map(([a, b]) => { const o = a === gen ? b : a, c = commutator(m, gen, o); return { other: o, mask: c.mask, coef: c.coef }; });
}

export default function YmGraph({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => { const top = params.top === true, m = intIn(params.m, GAUGE_MS, top ? TOP : 4); return { m, top, gen: soAlgebra(m).gens.includes(params.gen) ? params.gen : null }; };
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.m, params.top, params.gen]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { m, top, gen } = st, drawM = top ? TOP : m;
  const A = useMemo(() => soAlgebra(drawM), [drawM]), Am = useMemo(() => soAlgebra(m), [m]);
  const restr = useMemo(() => (top && m < TOP ? restricts('internal', m, TOP) : null), [top, m]);
  const list = useMemo(() => (gen == null ? [] : commutatorsOf(m, gen)), [m, gen]);
  const lad = S ? S.ym.ladder[String(m)] : null;
  const nb = new Set(list.map(x => x.other)), live = g => within(g, m);
  const name = g => labelIn(L, g, { n: drawM, kind: 'int' }), pickGen = g => setSt(s => ({ ...s, gen: s.gen === g ? null : g }));
  const pickProps = g => ({ className: 'g7-pick', role: 'button', tabIndex: 0, 'aria-pressed': gen === g, 'aria-label': `B${genName(g)}`, 'data-param': 'gen', 'data-gen': g,
    onClick: () => pickGen(g), onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickGen(g); } } });
  const simplex = L === 'simplex';
  // the circle of generators (every lens but simplex)
  const R = 128, angG = k => ((-90 + (360 * k) / A.gens.length) * Math.PI) / 180, pos = new Map(A.gens.map((g, k) => [g, [C + R * Math.cos(angG(k)), C + R * Math.sin(angG(k))]]));
  // the simplex of the m directions (lens simplex): a generator is the edge between its two indices
  const RV = 124, angV = i => ((-90 + (360 * i) / drawM) * Math.PI) / 180, V = Array.from({ length: drawM }, (_, i) => [C + RV * Math.cos(angV(i)), C + RV * Math.sin(angV(i))]);
  const ends = g => { const ix = []; for (let i = 0; i < drawM; i++) if (Math.floor(g / 2 ** i) % 2 === 1) ix.push(i); return ix; };
  const tri = gen == null ? [] : Am.triples.filter(t => (t & gen) === gen);
  const fs = A.gens.length > 15 ? 't-micro' : A.gens.length > 6 ? 't-tiny' : 't-small';
  return (
    <div className="fig fig-ym-graph g7-split" data-m={m} data-top={top ? 'true' : 'false'} data-lens={L || ''} data-gen={gen == null ? '' : gen}>
      <div className="g7-left">
        <FigSvg id="ym-graph" row={row} viewBox="0 0 360 360" data-drawn={drawM} data-edges={Am.edges.length}>
          {!simplex && A.edges.map(([a, b]) => {
            const on = gen != null && (a === gen || b === gen) && live(a) && live(b), dim = !(live(a) && live(b)) || (gen != null && !on);
            return <line key={a + '-' + b} x1={r1(pos.get(a)[0])} y1={r1(pos.get(a)[1])} x2={r1(pos.get(b)[0])} y2={r1(pos.get(b)[1])} className={'g7-line' + (on ? ' is-on' : '') + (dim ? ' g7-faint' : '')} data-edge={`${a},${b}`}>
              <title>{research ? `[B${genName(a)}, B${genName(b)}] = ${coefText(commutator(drawM, a, b).coef)} B${genName(a ^ b)}` : `${genName(a)} and ${genName(b)} give ${genName(a ^ b)}`}</title>
            </line>;
          })}
          {!simplex && A.gens.map((g, k) => {
            const [x, y] = pos.get(g), lab = [C + (R + 18) * Math.cos(angG(k)), C + (R + 18) * Math.sin(angG(k))], on = gen === g, near = nb.has(g);
            return (
              <g key={g} {...pickProps(g)} data-live={live(g) ? 1 : 0} data-neighbour={near ? 1 : 0}>
                <circle cx={r1(x)} cy={r1(y)} r={11} className="g7-hit" />
                <circle cx={r1(x)} cy={r1(y)} r={on ? 6.5 : 4.8} className={(live(g) ? '' : 'g7-faint ') + (near ? 'g7-ring' : 'g7-dot')} style={near ? { strokeWidth: 2 } : undefined} />
                {on && <circle cx={r1(x)} cy={r1(y)} r={10} className="g7-sel" />}
                <text x={r1(lab[0])} y={r1(lab[1] + 3)} textAnchor="middle" className={`${fs} t-mono${on ? ' t-bold' : ''}${live(g) ? '' : ' g7-faint'}`} data-label={g}>{name(g)}</text>
              </g>
            );
          })}
          {simplex && tri.map(t => { const P = ends(t).map(i => V[i]); return <polygon key={'f' + t} points={P.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ')} className="g7-face" data-triangle={t} />; })}
          {simplex && A.gens.map(g => {
            const [i, j] = ends(g), on = gen === g, near = nb.has(g), ok = live(g);
            return (
              <g key={g} {...pickProps(g)} data-live={ok ? 1 : 0} data-neighbour={near ? 1 : 0}>
                <line x1={r1(V[i][0])} y1={r1(V[i][1])} x2={r1(V[j][0])} y2={r1(V[j][1])} className="g7-hitline" />
                <line x1={r1(V[i][0])} y1={r1(V[i][1])} x2={r1(V[j][0])} y2={r1(V[j][1])} className={'g7-line' + (on ? ' is-on' : near ? ' is-lit g7-dash' : '') + (ok ? '' : ' g7-faint')} />
                <title>{`${research ? 'B' : ''}${genName(g)} · ${name(g)}`}</title>
              </g>
            );
          })}
          {simplex && V.map(([x, y], i) => (
            <g key={'v' + i} data-vertex={i} className={i < m ? '' : 'g7-faint'}>
              <circle cx={r1(x)} cy={r1(y)} r={5} className="g7-dot" />
              <text x={r1(C + (RV + 16) * Math.cos(angV(i)))} y={r1(C + (RV + 16) * Math.sin(angV(i)) + 3.5)} textAnchor="middle" className="t-small t-mono">{String(i + 1)}</text>
            </g>
          ))}
          {A.gens.length === 1 && !simplex && <text x={C} y={C + 4} textAnchor="middle" className="t-small t-muted" data-single="1">{research ? '1 generator · 0 lines' : '1 dot · 0 lines'}</text>}
        </FigSvg>
        <Legend items={research
          ? (simplex ? [['dot', 'a direction'], ['solid', <>a generator B<sub>ab</sub>: the edge ab</>], ['dash', 'its neighbours (they share one index)'], ['face', 'closed triangles: our reading (YM-008)']]
            : [['dot', <>a generator B<sub>ab</sub></>], ['solid', 'a pair that does not commute'], ['ring', 'the neighbours of the picked one']])
          : [['dot', simplex ? 'a direction' : 'a dot for each pair of directions'], ['solid', simplex ? 'a pair of directions' : 'a line where the order matters']]} />
        <Controls label="gauge graph">
          <Rungs label={research ? 'm' : 'directions'} values={GAUGE_MS} value={m} top={top} param="m" onPick={v => setSt(s => ({ ...s, m: v, gen: s.gen != null && within(s.gen, v) ? s.gen : null }))} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ ...s, top: on, m: on ? TOP : s.m }))} />
        </Controls>
      </div>
      <div className="g7-right">
        {research ? (
          <>
            <Readout data={{ 'data-readout': 'algebra' }} items={[
              [`so(${m})`, lad ? `${lad.gens} generators` : '…', { 'data-gens': lad ? lad.gens : '' }],
              ['pairs', lad ? `${lad.noncommuting_pairs} do not commute · ${lad.commuting_pairs} commute` : '…', { 'data-pairs': lad ? `${lad.noncommuting_pairs},${lad.commuting_pairs}` : '' }],
              ['closed triangles', lad ? String(lad.triangles) : '…', { 'data-triangles': lad ? lad.triangles : '' }],
              ['neighbours of each', lad ? String(lad.neighbours_of_each_generator) : '…', { 'data-neighbours': lad ? lad.neighbours_of_each_generator : '' }],
              ['also known as', YM_STANDARD[m], { 'data-standard': YM_STANDARD[m] }],
            ]} />
            {gen == null && <p className="g7-idle" data-idle="1">no generator picked</p>}
            {gen != null && (
              <div className="g7-card" data-picked={gen}>
                <h4><Tex katex={katex} tex={bTex(gen)} plain={`B${genName(gen)}`} /><span className="g7-sub">{`${name(gen)} · ${list.length} neighbour${list.length === 1 ? '' : 's'}`}</span></h4>
                <ul>{list.map(x => <li key={x.other} data-comm={`${gen},${x.other},${x.mask},${x.coef}`}><Tex katex={katex} tex={`[${bTex(gen)},${bTex(x.other)}]=${coefTex(x.coef)}\\,${bTex(x.mask)}`} plain={`[B${genName(gen)}, B${genName(x.other)}] = ${coefText(x.coef)} B${genName(x.mask)}`} /></li>)}</ul>
              </div>
            )}
            {simplex && <Readout data={{ 'data-readout': 'triangles' }} items={[['index triples', lad ? `${lad.triangles} closed triangles` : '…'], gen != null && ['through the picked edge', String(tri.length), { 'data-through': tri.length }], ['', 'our reading (YM-008)']]} />}
            {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`so(${m}) ⊂ so(${TOP})`, m === TOP ? 'top' : restr ? '✓ every sign the same' : '✗', { 'data-restricts': m === TOP ? 'top' : String(restr) }], ['generators kept', `${Am.gens.length} of ${A.gens.length}`, { 'data-kept': `${Am.gens.length},${A.gens.length}` }]]} />}
            <p className="g7-conv" data-convention="1"><span className="g7-k">inputs:</span> the coupling g (INP-035) · D = ∂ + gA (INP-036)</p>
          </>
        ) : (
          <>
            <Readout data={{ 'data-readout': 'learner' }} items={[['', `${Am.gens.length} dot${Am.gens.length === 1 ? '' : 's'}`], ['', `${Am.edges.length} line${Am.edges.length === 1 ? '' : 's'}`, { 'data-lines': Am.edges.length }]]} />
            {gen == null && <p className="g7-idle" data-idle="1">no dot picked</p>}
            {gen != null && <div className="g7-card" data-picked={gen}><h4>{genName(gen)}<span className="g7-sub">{`${list.length} neighbour${list.length === 1 ? '' : 's'}`}</span></h4><ul>{list.map(x => <li key={x.other} data-comm={`${gen},${x.other},${x.mask}`}>{`${genName(gen)} and ${genName(x.other)} give ${genName(x.mask)}`}</li>)}</ul></div>}
          </>
        )}
      </div>
    </div>
  );
}
YmGraph.meta = { id: 'ym-graph', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
YmGraph.params = [{}, { m: 2 }, { m: 3, gen: 3 }, { m: 4, gen: 3 }, { m: 8, gen: 5 }, { m: 5, top: true, gen: 6 }];
/** the numbers the figure draws: so(m) (generators, the pairs that do not commute), the picked generator's commutators, the restriction from the top */
YmGraph.data = (p = {}) => {
  const top = p.top === true, m = intIn(p.m, GAUGE_MS, top ? TOP : 4), A = soAlgebra(m), gen = A.gens.includes(p.gen) ? p.gen : null;
  return { m, top, gens: A.gens, edges: A.edges, gen, commutators: gen == null ? [] : commutatorsOf(m, gen), restricts: top && m < TOP ? restricts('internal', m, TOP) : null };
};
