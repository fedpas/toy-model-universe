// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p9kit.jsx — what the figures of owner P9 share: the stored table of D34 (content/stored_p9.json, read with useTable, or given by a test as
// params.stored), the small keys of the legends (a stroke or a mark drawn as the figure draws it) and hx, a short formula in HTML with "_x" and "^x" as sub- and
// superscripts (the HTML twin of kit.jsx tx). Tokens only.
import React from 'react';

/** the null.json figs of the stored table, from the params when a test passes it, else the content table once loaded (null before) */
export const storedNull = (params, T) => { const s = params && params.stored ? params.stored : T; return s && s.null && s.null.figs ? s.null.figs : null; };
/** spring.json of the stored table, the same way */
export const storedSpring = (params, T) => { const s = params && params.stored ? params.stored : T; return s && s.spring && s.spring.cube ? s.spring : null; };

/** "x_i", "w′^v", "r_E", "g_{tt}": a run after "_" or "^" (letters and digits, or {…}) as <sub> or <sup>; the text content keeps its words */
export function hx(s) {
  const out = []; let k = 0, last = 0, m; const re = /([_^])(?:\{([^}]*)\}|([\p{L}\p{N}]+))/gu;
  while ((m = re.exec(s))) { if (m.index > last) out.push(s.slice(last, m.index)); const t = m[2] ?? m[3]; out.push(m[1] === '_' ? <sub key={k++}>{t}</sub> : <sup key={k++}>{t}</sup>); last = re.lastIndex; }
  if (last < s.length) out.push(s.slice(last));
  return out;
}

/** a small key of a legend: a stroke or a mark drawn as the figure draws it */
export function Key({ kind }) {
  return (
    <svg className="p9-key" viewBox="0 0 24 10" aria-hidden="true">
      {kind === 'solid' && <line x1={1} y1={5} x2={23} y2={5} style={{ strokeWidth: 2.6 }} />}
      {kind === 'dashed' && <line x1={1} y1={5} x2={23} y2={5} style={{ strokeWidth: 1.8, strokeDasharray: '5 3' }} />}
      {kind === 'thin' && <line x1={1} y1={5} x2={23} y2={5} style={{ strokeWidth: 1, opacity: 0.6 }} />}
      {kind === 'thin-dashed' && <line x1={1} y1={5} x2={23} y2={5} style={{ strokeWidth: 1, strokeDasharray: '4 3', opacity: 0.6 }} />}
      {kind === 'heavy' && <line x1={1} y1={5} x2={23} y2={5} style={{ strokeWidth: 3.2 }} />}
      {kind === 'arrow' && <><line x1={1} y1={5} x2={19} y2={5} style={{ strokeWidth: 1.8 }} /><path d="M23 5 L17 2 L17 8 Z" style={{ fill: 'var(--fg)', stroke: 'none' }} /></>}
      {kind === 'live' && <line x1={1} y1={5} x2={23} y2={5} style={{ stroke: 'var(--accent)', strokeWidth: 2.6, strokeDasharray: '7 3' }} />}
      {kind === 'dot' && <circle cx={12} cy={5} r={2.4} style={{ fill: 'var(--fg)', stroke: 'none' }} />}
      {kind === 'ring' && <circle cx={12} cy={5} r={3} style={{ fill: 'var(--panel)', strokeWidth: 1.4 }} />}
      {kind === 'diamond' && <path d="M12 1 L16 5 L12 9 L8 5 Z" style={{ fill: 'var(--panel)', stroke: 'var(--fg)', strokeWidth: 1.1 }} />}
    </svg>
  );
}
