// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spring-faces (step 15, caption SPR-003; docs/PHYSICS_AUDIT.md SR2): faces close the stretches. A field on the edges of the n-cube is either the stretch of
// a displacement of the masses (u_b − u_a on the edge a → b) or an arbitrary field; the sum around every face (x → x+i → x+i+j → x+j → x) is 0 for a stretch and
// generally not for an arbitrary field (engines/physics/springPhysics.js facesAt, on springEngine's stretch, randomDisp, randomField, faceSums). The cube is drawn
// flat with the edge values (n ≤ 3) and a mark on each face: a filled square for a sum of 0, a dashed square with the sum otherwise; every face is listed by its
// axes and base vertex ("12@010"), the base vertex printed in the label lens. Under it, the counts, b₁ = 0 for the filled cube (spring.json cube, from
// content/stored_p9.json: every closed edge field is a stretch) and the flux of the signed network: the four kernel signs around a face multiply to −1 on every face
// (springEngine.fluxes). tests/physics/p9.test.mjs recomputes the sums and the flux and ties b₁ and the face counts to spring.json. Controls, as in v15 FaceCloser:
// chips n = 2, 3, 4, the kind of edge field, and "new sample". Shape and word, never colour alone; tokens only.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../../app/content.js';
import { FACE_NS, FACE_KINDS, facesAt } from '../../../engines/physics/springPhysics.js';
import { project, bits } from '../../../engines/springEngine.js';
import { label } from '../../../engines/bitrule.js';
import { FigSvg, Controls, Chips, r1, pick, isIn, labelLens } from '../kit.jsx';
import { storedSpring } from './p9kit.jsx';
import './p9.css';

const KIND_NAME = { disp: 'Stretch of a displacement', field: 'An arbitrary field' };
const sg = v => (v > 0 ? '+' + v : String(v).replace('-', '−'));
const seedOf = v => (Number.isInteger(v) && v > 0 && v < 1e6 ? v : 1);
const W = 420, H = 232;

export default function SpringFaces({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [T0] = useTable('stored_p9');
  const sr = storedSpring(params, T0);
  const [n, setN] = useState(pick(params.n, isIn(FACE_NS), 3));
  const [kind, setKind] = useState(pick(params.kind, isIn(FACE_KINDS), 'disp'));
  const [seed, setSeed] = useState(seedOf(params.seed));
  useEffect(() => { setN(pick(params.n, isIn(FACE_NS), 3)); setKind(pick(params.kind, isIn(FACE_KINDS), 'disp')); setSeed(seedOf(params.seed)); }, [params.n, params.kind, params.seed]);
  const D = useMemo(() => facesAt(n, kind, seed), [n, kind, seed]);
  const L = labelLens(lens) || 'bits', eps = Array(n).fill(1), base = x => (L === 'bits' ? bits(n, x) : label(x, L === 'primes' ? 'primes' : L === 'set' ? 'set' : 'clifford', eps));
  const name = f => `${f.i + 1}${f.j + 1}@${base(f.x)}`;
  const P = useMemo(() => {
    const U = Array.from({ length: 1 << n }, (_, x) => project(n, x, 1)), xs = U.map(p => p[0]), ys = U.map(p => p[1]);
    const k = Math.min(300 / Math.max(1e-9, Math.max(...xs) - Math.min(...xs)), 170 / Math.max(1e-9, Math.max(...ys) - Math.min(...ys)), 150);
    const ox = 210 - (Math.min(...xs) + Math.max(...xs)) / 2 * k, oy = 112 - (Math.min(...ys) + Math.max(...ys)) / 2 * k;
    return U.map(p => [ox + p[0] * k, oy + p[1] * k]);
  }, [n]);
  const open = D.faces.filter(f => f.sum !== 0).length, cube = sr && sr.cube ? sr.cube[n] : null, cl = sr && sr.clifford ? sr.clifford[n] : null;
  return (
    <div className="fig p9 fig-spring-faces">
      <FigSvg id="spring-faces" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-n={n} data-kind={kind} data-seed={seed} data-closed={D.closed ? 1 : 0} data-open-faces={open} data-flux-minus={D.fluxMinus}>
          {D.field.map(e => { const A = P[e.a], B = P[e.b], mx = (A[0] + B[0]) / 2, my = (A[1] + B[1]) / 2; return (
            <g key={e.a + '-' + e.b} data-edge={`${e.a},${e.b}`} data-value={e.v}>
              <line x1={r1(A[0])} y1={r1(A[1])} x2={r1(B[0])} y2={r1(B[1])} className="stroke-ink" style={{ strokeWidth: 1.3, strokeOpacity: 0.7 }} />
              {n <= 3 && <text x={r1(mx)} y={r1(my - 3)} textAnchor="middle" className="t-mono t-micro" style={{ paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3 }}>{sg(e.v)}</text>}
            </g>); })}
          {n <= 3 && D.faces.map(f => { const cs = [f.x, f.x + (1 << f.i), f.x + (1 << f.i) + (1 << f.j), f.x + (1 << f.j)], cx = cs.reduce((u, c) => u + P[c][0], 0) / 4, cy = cs.reduce((u, c) => u + P[c][1], 0) / 4, z = f.sum === 0; return (
            <g key={'f' + name(f)} data-face={name(f)} data-sum={f.sum}>
              <title>{`face ${name(f)}: sum ${sg(f.sum)}`}</title>
              <rect x={r1(cx - 5)} y={r1(cy + 4)} width={10} height={10} className={z ? 'ink' : 'stroke-ink'} style={z ? { fillOpacity: 0.8 } : { strokeWidth: 1.2, strokeDasharray: '2 1.5' }} />
              <text x={r1(cx)} y={r1(cy + 1)} textAnchor="middle" className={z ? 't-mono t-micro t-muted' : 't-mono t-tiny t-bold'}>{sg(f.sum)}</text>
            </g>); })}
          {P.map(([x, y], v) => <g key={v}><circle cx={r1(x)} cy={r1(y)} r={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.4 }} />{n <= 3 && <text x={r1(x + 6)} y={r1(y + 12)} className="t-mono t-micro t-muted">{base(v)}</text>}</g>)}
          {kind === 'disp' && n <= 3 && <text x={8} y={16} className="t-tiny t-muted">{`u = (${D.u.map(sg).join(', ')})`}</text>}
        </g>
      </FigSvg>
      <ul className="p9-faces" aria-label="the sum around each face">
        {D.faces.map(f => <li key={name(f)} className={'p9-face' + (f.sum !== 0 ? ' is-open' : '')} data-face-sum={`${name(f)}:${f.sum}`}>{`${name(f)}: ${sg(f.sum)}`}</li>)}
      </ul>
      <div className="p9-readout">
        <p data-counts={`${D.counts.V},${D.counts.E},${D.counts.F}`}>{`${D.counts.V} vertices, ${D.counts.E} edges, ${D.counts.F} faces · ${D.closed ? `every face sums to 0 ✓` : `${open} of ${D.counts.F} faces with a nonzero sum ✓`}`}</p>
        {cube && <p data-betti={cube.betti.join(',')}>{`spring.json, n = ${n}: b₀, b₁, b₂ = ${cube.betti.join(', ')} · V − E + F = ${cube.euler}`}</p>}
        <p data-flux={`${D.fluxMinus},${D.faces.length}`}>{`signed network: the four signs round a face multiply to −1 on ${D.fluxMinus} of ${D.faces.length} faces${cl ? ` (spring.json: ${cl.faces} faces)` : ''}`}</p>
      </div>
      <Controls label="faces">
        <Chips label="n" items={FACE_NS} value={n} onPick={setN} param="n" mono />
        <Chips label="edge field" items={FACE_KINDS} value={kind} onPick={setKind} render={k => KIND_NAME[k]} param="kind" />
        {research && <button type="button" className="fig-btn" data-param="seed" onClick={() => setSeed(s => s + 1)}>New sample</button>}
      </Controls>
    </div>
  );
}
SpringFaces.meta = { id: 'spring-faces', lenses: ['bits', 'primes', 'clifford'], learner: false };
SpringFaces.params = [{}, { n: 2 }, { n: 4, kind: 'field' }, { kind: 'field', seed: 3 }];
/** the numbers the figure draws, for the frame's data download */
SpringFaces.data = (params = {}) => { const D = facesAt(pick(params.n, isIn(FACE_NS), 3), pick(params.kind, isIn(FACE_KINDS), 'disp'), seedOf(params.seed)); return { n: D.n, kind: D.kind, seed: D.seed, u: D.u, field: D.field, faces: D.faces, counts: D.counts, closed: D.closed, fluxMinus: D.fluxMinus }; };
