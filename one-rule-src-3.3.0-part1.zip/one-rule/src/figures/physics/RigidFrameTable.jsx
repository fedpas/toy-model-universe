// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure rigid-frame-table (step 16; caption row RIG-001; docs/PHYSICS_AUDIT.md RB3): the frame table of the ladder, every count of the rigid body from the segment
// to the 5-cube, as pgadyn_selfcheck.py enumerates it from the blades (pgadyn.json frame_table, n = 1 … 5, and labels.A7, which counts the motor coefficients, the
// group dimension and the equations of M M̃ = 1 at n = 6 too). D37, the Atlas method: the ladder is drawn from the lowest stored rung up, one panel per rung (the
// n-cube, its 2ⁿ motor coefficients on its vertices: even weight filled, the rotor part; odd weight hollow, the translation part with e₀), the rung n = 6 empty
// and marked "not stored" beside its three stored counts; the lens picker (clifford, cube, simplex, demicube, prime: the frame's lens chips) prints the
// coefficient on every vertex of the picked rung (row A1: the even blade whose unit bits are the vertex, with e₀ exactly at odd weight); "from the top" starts
// at the highest stored rung and draws each lower rung as its restriction, the face of the 5-cube where the higher bits are 0. The table is v15's FrameTable (the
// counts with their closed forms, the row picked by a click, the last row the equations M M̃ = 1 must supply, ✓ up to n = 4, ✗ at n = 5); every cell prints the
// stored number, carries the kernel's count (engines/physics/rigid.js frameCounts) and the closed form (frameClosed), and is marked when they differ.
// The lens panel of the labelled body (A39, decision D49; v15's LabelledBody; the arrangement is our reading, row RIG-003, whose statement carries the badge — the
// figure draws none): the body of the picked rung, n = 1 … 4 as pgadyn_selfcheck.py stores its labels (bit_labels), posed as v15 opened it, on engines/pgaEngine.js
// (engines/physics/rigid.js labelledBody: frame, verticesFrame, deepestBits and deepestScan, zonogon and hull; the sign table is the kernel's), with v15's tabs as
// chips: frame (the vertices from n + 1 sandwiches and 2ⁿ − 1 additions against the 2ⁿ direct ones, the counts against the stored bit_labels), contact (the deepest
// vertex under the plane from n sign bits, and by the scan of the 2ⁿ), outline (the 2n vertices of the zonogon of the n projected edges, and the hull of the 2ⁿ
// projected vertices, each bit flipped twice). Every vertex carries its label in the lens of the frame (vertexLabel: the coefficient on the vertex, as the lens
// prints it), the vertices of the tab in bold (all of them, the deepest, the outline); n = 5 and 6 are drawn empty and marked "not stored".
// Research level only (no L: in the audit).
import React, { useEffect, useMemo, useState } from 'react';
import { edgeList, project } from '../../../engines/pgaEngine.js';
import { popcount } from '../../../engines/bitrule.js';
import { frameCounts, frameClosed, normSupport, vertexLabel, labelledBody, BODY } from '../../../engines/physics/rigid.js';
import { FigSvg, Controls, Chips, Toggle, r1 } from '../kit.jsx';
import { useStoredP11, Ok, KV } from './rigidParts.jsx';

export const RUNGS = [1, 2, 3, 4, 5, 6];
const TOP = 5;                                                             // the highest rung with a stored frame table
const NAMES = { 1: 'segment', 2: 'square', 3: 'cube', 4: 'tesseract', 5: '5-cube', 6: '6-cube' };
// the rows of v15's table (RigidWidgets.jsx FrameTable, rigidCopy.js table.rows): the key in pgadyn.json frame_table and the name with its closed form
export const ROWS = [
  ['vertices', 'vertices 2ⁿ'], ['edges', 'edges n·2ⁿ⁻¹'], ['motor_coefficients', 'motor coefficients 2ⁿ'], ['bivector_components', 'velocity components n(n+1)/2'],
  ['group_dimension', 'group dimension n(n+1)/2'], ['force_components', 'force components C(n+1, n−1)'], ['norm_equations', 'equations of M M̃ = 1: 1 + C(n+1, 4)'],
  ['integration_numbers', 'integration numbers 2ⁿ + n(n+1)/2'], ['solution_numbers', 'solution numbers n(n+1)'], ['sandwiches_direct', 'sandwiches, direct 2ⁿ'],
  ['sandwiches_frame', 'sandwiches, frame n + 1'], ['additions', 'additions 2ⁿ − 1'], ['outline_vertices', 'outline vertices 2n'], ['needed', 'equations needed, 2ⁿ − n(n+1)/2'],
];
// labels.A7 stores three counts per rung n = 1 … 6 under its own names
const A7_KEY = { motor_coefficients: 'coefficients', group_dimension: 'dimension', norm_equations: 'equations' };
const LENS_WORD = { clifford: 'the blade', cube: 'the vertex in bits', bits: 'the vertex in bits', simplex: 'the blade as a set', demicube: 'the even mask of n + 1 bits', prime: 'a product of primes', primes: 'a product of primes' };

/** the stored value of a count at rung n: frame_table for n ≤ 5, labels.A7 for its three counts at n = 6, the needed equations as the difference of two stored
 *  counts; undefined while the table loads, null when it is not stored */
export function storedCount(S, n, key) {
  if (!S) return undefined;
  const FT = S.frame_table && S.frame_table[n], A7 = S.labels && S.labels.A7 && S.labels.A7[n];
  if (FT) return key === 'needed' ? FT.vertices - FT.group_dimension : FT[key] ?? null;
  if (A7) { if (key === 'needed') return A7.coefficients - A7.dimension; return A7_KEY[key] ? A7[A7_KEY[key]] : null; }
  return null;
}
const okInt = (v, list, d) => (list.includes(v) ? v : d);
const KEYS = ROWS.map(r => r[0]);

/** a rung panel of the ladder: the n-cube (or, from the top, the 5-cube with the n-face lit), centred in a box of width w at (x, 0) */
function Cube({ n, x, y, w, h, top = null, labels = null, lens = null, big = false }) {
  const N = top || n, E = edgeList(N), V = 1 << N, P = Array.from({ length: V }, (_, v) => project(N, Array.from({ length: N }, (_, i) => ((v >> i) % 2) - 0.5), 0.35));
  const xs = P.map(p => p[0]), ys = P.map(p => p[1]), spanX = Math.max(...xs) - Math.min(...xs) || 1, spanY = Math.max(...ys) - Math.min(...ys) || 1;
  const sc = Math.min((w - (big ? 70 : 16)) / spanX, (h - (big ? 34 : 14)) / spanY), cx = x + w / 2 - sc * (Math.max(...xs) + Math.min(...xs)) / 2, cy = y + h / 2 + sc * (Math.max(...ys) + Math.min(...ys)) / 2;
  const at = v => [cx + sc * P[v][0], cy - sc * P[v][1]], inFace = v => v < (1 << n);
  return (
    <g data-cube={n} data-top={top || undefined}>
      {E.map(([a, b]) => { const p = at(a), q = at(b), lit = inFace(a) && inFace(b); return <line key={a + '-' + b} x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className={lit ? 'stroke-ink' : 'stroke-muted'} style={{ strokeWidth: lit ? (big ? 1.3 : 1) : 0.6, strokeOpacity: lit ? 0.85 : 0.35 }} />; })}
      {Array.from({ length: V }, (_, v) => { const [px, py] = at(v), lit = inFace(v), even = popcount(v) % 2 === 0, r = big ? (N > 4 ? 3 : 4) : 2.2; return (
        <g key={v} data-v={v} data-lit={lit ? 1 : 0}>
          <circle cx={r1(px)} cy={r1(py)} r={lit ? r : r * 0.6} className={even ? (lit ? 'ink' : 'ink-muted') : 'stroke-ink'} style={even ? undefined : { strokeWidth: lit ? 1.2 : 0.6, fill: 'var(--panel)', strokeOpacity: lit ? 1 : 0.4 }} />
          {labels && lit ? <text x={r1(px + r + 2)} y={r1(py - r - 1)} className={N > 4 ? 't-micro t-mono' : 't-tiny t-mono'} data-label={vertexLabel(n, v, lens)}>{vertexLabel(n, v, lens)}</text> : null}
        </g>); })}
    </g>
  );
}

// ---------------------------------------------------------------- the lens panel of the labelled body (A39)
/** v15's LabelledBody tabs the panel ports (its tab "labels" is the picked rung above; "timing", the benchmark, is RB6 and stays out) */
export const BODY_TABS = ['frame', 'contact', 'outline'];
const DASH = [undefined, '6 3', '2 2', '8 2 2 2'];                    // the four edge directions, told apart by the dash (never by colour alone)
const RANGE = k => Array.from({ length: k }, (_, i) => i);
const SUBS = '₀₁₂₃₄₅₆₇₈₉', fSub = i => 'f' + SUBS[i + 1];
const fmtE = x => (x === 0 ? '0' : x.toExponential(1).replace('-', '−'));
const f2s = x => { const r = Math.abs(x) < 5e-3 ? 0 : Math.round(x * 100) / 100; return String(r).replace('-', '−'); };
/** what the panel prints for rung n in a lens: the engine's body (labelledBody) and the label of every vertex in the lens (vertexLabel); null when not stored */
export function bodyLabels(n, lens = null) {
  const b = labelledBody(n);
  if (!b) return null;
  const lab = v => vertexLabel(n, v, lens);
  return { b, labels: RANGE(1 << n).map(lab), deepBits: lab(b.deepBits), deepScan: lab(b.deepScan), outline: b.outline.map(lab), hull: b.hull.map(lab) };
}
function BodyPanel({ n, tab, lens, S, row, onTab }) {
  const L = useMemo(() => bodyLabels(n, lens), [n, lens]);
  if (!L) return (
    <FigSvg id="rigid-frame-table" row={row} part="the labelled body" viewBox="0 0 600 64">
      <text x={8} y={16} className="t-small t-bold">{`the labelled body · n = ${n} · ${NAMES[n]}`}</text>
      <text x={300} y={46} textAnchor="middle" className="t-small t-muted" data-body-not-stored={n}>not stored</text>
    </FigSvg>
  );
  const { b, labels } = L, V = 1 << n, P = b.projected;
  const xs = P.map(p => p[0]), ys = P.map(p => p[1]), spanX = Math.max(...xs) - Math.min(...xs), spanY = Math.max(...ys) - Math.min(...ys);
  const X0 = 70, Y0 = 46, WW = 460, HH = 158, sc = Math.min(spanX > 1e-9 ? WW / spanX : Infinity, spanY > 1e-9 ? HH / spanY : Infinity);
  const cx = X0 + WW / 2 - sc * (Math.max(...xs) + Math.min(...xs)) / 2, cy = Y0 + HH / 2 + sc * (Math.max(...ys) + Math.min(...ys)) / 2, at = v => [cx + sc * P[v][0], cy - sc * P[v][1]];
  const shown = new Set(tab === 'outline' ? b.outline : tab === 'contact' ? [b.deepBits, b.deepScan] : RANGE(V));
  const st = S === null ? undefined : S && S.bit_labels ? S.bit_labels[n] || null : null;
  const countsOk = st ? st.sandwiches_frame === b.counts.sandwichesFrame && st.additions === b.counts.additions && st.sandwiches_direct === b.counts.sandwichesDirect && st.edges === b.counts.edges : null;
  const twice = b.flips.length === 2 * n && RANGE(n).every(i => b.flips.filter(f => f === i).length === 2);
  const sameSet = b.outline.length === b.hull.length && b.outline.every(v => b.hull.includes(v));
  const signs = b.frame.f.map(f => f.reduce((q, x, k) => q + b.nu[k] * x, 0));
  return (
    <div className="rg-body" data-body={tab} data-body-n={n} data-body-lens={lens || ''} data-body-row="RIG-003">
      <Controls label="the labelled body">
        <Chips label="the labelled body" items={BODY_TABS} value={tab} onPick={onTab} param="body" />
      </Controls>
      <FigSvg id="rigid-frame-table" row={row} part={`the labelled body: ${tab}`} viewBox="0 0 600 236">
        <text x={8} y={16} className="t-small t-bold">{`the labelled body · n = ${n} · ${NAMES[n]} · ${tab}`}</text>
        <text x={8} y={30} className="t-tiny t-muted" data-body-lens-word={lens || 'clifford'}>{`on each vertex its label: ${LENS_WORD[lens] || LENS_WORD.clifford} · v15's pose: turns ${BODY.turns.slice(0, n - 1).map(t => t + '°').join(', ') || 'none'}`}</text>
        {tab === 'outline' && b.outline.length ? <polygon points={b.outline.map(v => at(v).map(r1).join(',')).join(' ')} className="stroke-ink" style={{ fill: 'none', strokeWidth: 2.2, strokeOpacity: 0.7 }} data-body-polygon={b.outline.join(',')} /> : null}
        {edgeList(n).map(([u, w, i]) => { const p = at(u), q = at(w); return <line key={u + '-' + w} x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: tab === 'frame' ? 1.2 : 0.9, strokeOpacity: tab === 'frame' ? 0.8 : 0.35, strokeDasharray: tab === 'frame' ? DASH[i] : undefined }} data-body-edge={i} />; })}
        {tab === 'frame' ? RANGE(n).map(i => { const p = at(0), q = at(1 << i); return <text key={'f' + i} x={r1((p[0] + q[0]) / 2 + 6)} y={r1((p[1] + q[1]) / 2 - 4)} className="t-tiny t-mono">{fSub(i)}</text>; }) : null}
        {RANGE(V).map(v => {
          const [px, py] = at(v), on = shown.has(v), deep = tab === 'contact' && v === b.deepBits, even = popcount(v) % 2 === 0;
          return (
            <g key={v} data-body-v={v} data-body-label={labels[v]} data-body-shown={on ? 1 : 0}>
              {deep ? <circle cx={r1(px)} cy={r1(py)} r={9} className="stroke-ink" style={{ fill: 'none', strokeWidth: 1.6 }} data-body-deep={v} /> : null}
              <circle cx={r1(px)} cy={r1(py)} r={on ? 4 : 2.6} className={even ? 'ink' : 'stroke-ink'} style={even ? { opacity: on ? 1 : 0.45 } : { fill: 'var(--panel)', strokeWidth: 1.2, strokeOpacity: on ? 1 : 0.45 }} />
              <text x={r1(px + 8)} y={r1(py - 7)} className={(n > 3 ? 't-micro t-mono' : 't-tiny t-mono') + (on ? ' t-bold' : ' t-muted')} style={{ paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3, strokeLinejoin: 'round' }}>{labels[v]}</text>
            </g>
          );
        })}
      </FigSvg>
      <div className="fig-note rg-note" data-body-note={tab}>
        {tab === 'frame' ? (
          <>
            <p data-body-frame={`${b.counts.sandwichesFrame},${b.counts.additions},${b.counts.sandwichesDirect},${b.counts.edges}`} data-body-err={b.err}>
              <KV k="frame">{`${b.counts.sandwichesFrame} sandwiches + ${b.counts.additions} additions → ${V} vertices · direct: ${b.counts.sandwichesDirect} sandwiches · largest difference ${fmtE(b.err)}`}</KV>
              <Ok ok={b.err < 1e-9} yes="the same vertices" no="the vertices differ" />
            </p>
            <p data-body-stored={st ? `${st.sandwiches_frame},${st.additions},${st.sandwiches_direct},${st.edges}` : ''}>
              <KV k={`stored, bit_labels n = ${n}`}>{st === undefined ? '…' : st ? `${st.sandwiches_frame} · ${st.additions} · ${st.sandwiches_direct} · ${st.edges} edges` : 'not stored'}</KV>
              {countsOk === null ? null : <Ok ok={countsOk} yes="= the engine's counts" no="≠ the engine's counts" />}
            </p>
          </>
        ) : tab === 'contact' ? (
          <>
            <p data-body-signs={signs.map(x => (x < 0 ? 1 : 0)).join('')}>
              <KV k="ν · fᵢ">{signs.map((x, i) => `${fSub(i)} ${f2s(x)} → ${x < 0 ? 1 : 0}`).join(' · ')}</KV>
            </p>
            <p data-body-deep-bits={b.deepBits} data-body-deep-scan={b.deepScan} data-body-deep-label={L.deepBits}>
              <KV k="the deepest vertex">{`from ${n} sign bit${n === 1 ? '' : 's'}: ${L.deepBits} · by the scan of ${V}: ${L.deepScan}`}</KV>
              <Ok ok={b.deepBits === b.deepScan} yes="the same vertex" no="different vertices" />
            </p>
          </>
        ) : b.outline.length ? (
          <>
            <p data-body-outline={b.outline.join(',')} data-body-outline-labels={L.outline.join('|')}>
              <KV k={`zonogon of the ${n} projected edges`}>{`${b.outline.length} vertices: ${L.outline.join(' → ')}`}</KV>
              <Ok ok={b.outline.length === 2 * n} yes={`2n = ${2 * n}`} no={`not 2n = ${2 * n}`} />
            </p>
            <p data-body-hull={b.hull.join(',')} data-body-flips={b.flips.map(f => (f === null ? 'x' : f + 1)).join(',')}>
              <KV k={`hull of the ${V} projected vertices`}>{`${b.hull.length} vertices · bits flipped along the outline: ${b.flips.map(f => (f === null ? '?' : f + 1)).join(', ')}`}</KV>
              <Ok ok={sameSet} yes="the same vertices" no="other vertices" /> <Ok ok={twice} yes="each bit twice" no="not each bit twice" />
            </p>
          </>
        ) : <p data-body-outline=""><KV k="outline">n = 1: none</KV></p>}
      </div>
    </div>
  );
}

export default function RigidFrameTable({ params = {}, lens = null, level = 'research', theme, row }) {
  const [n, setN] = useState(okInt(params.n, RUNGS, 3)), [fromTop, setFromTop] = useState(params.top === true), [hi, setHi] = useState(okInt(params.row, KEYS, 'motor_coefficients'));
  const [tab, setTab] = useState(okInt(params.body, BODY_TABS, 'contact'));
  useEffect(() => { setN(okInt(params.n, RUNGS, 3)); setFromTop(params.top === true); setHi(okInt(params.row, KEYS, 'motor_coefficients')); setTab(okInt(params.body, BODY_TABS, 'contact')); }, [params.n, params.top, params.row, params.body]);
  const S = useStoredP11();
  const kernel = useMemo(() => Object.fromEntries(RUNGS.map(m => [m, frameCounts(m)])), []), closed = useMemo(() => Object.fromEntries(RUNGS.map(m => [m, frameClosed(m)])), []);
  const support = useMemo(() => normSupport(n), [n]);
  const order = fromTop ? [...RUNGS].reverse() : RUNGS, stored = (m, k) => storedCount(S, m, k), frameStored = m => !!(S && S.frame_table && S.frame_table[m]);
  const verdict = m => { const g = stored(m, 'norm_equations'), need = stored(m, 'needed'); return g == null || need == null ? null : { g, need, ok: g === need }; };
  const W = 720, PW = W / RUNGS.length, LH = 146;
  return (
    <div className="fig fig-rigid rg-ft" data-n={n} data-from-top={fromTop ? 1 : 0} data-lens={lens || ''}>
      <div className="fig-scroll">
        <FigSvg id="rigid-frame-table" row={row} part="the ladder" viewBox={`0 0 ${W} ${LH}`} className="fig-svg-wide">
          {order.map((m, j) => {
            const x = j * PW, v = verdict(m), on = m === n, full = S ? frameStored(m) : m <= TOP;
            return (
              <g key={m} data-rung={m} data-stored={!S ? 'loading' : full ? 'frame' : 'A7'} className="rg-rung">
                <rect x={r1(x + 3)} y={4} width={r1(PW - 6)} height={LH - 8} rx={6} className={on ? 'stroke-ink' : 'hair'} style={{ strokeWidth: on ? 1.6 : 1, strokeDasharray: full ? undefined : '4 3' }} />
                <text x={r1(x + PW / 2)} y={20} textAnchor="middle" className="t-small t-bold">{`n = ${m}`}</text>
                <text x={r1(x + PW / 2)} y={33} textAnchor="middle" className="t-tiny t-muted">{NAMES[m]}</text>
                {full ? <Cube n={m} x={x + 6} y={38} w={PW - 12} h={66} top={fromTop ? TOP : null} />
                  : <text x={r1(x + PW / 2)} y={74} textAnchor="middle" className="t-tiny t-muted" data-not-stored={m}>not stored</text>}
                <text x={r1(x + PW / 2)} y={118} textAnchor="middle" className="t-tiny t-mono" data-coefficients={stored(m, 'motor_coefficients') ?? ''}>{`${stored(m, 'motor_coefficients') ?? '…'} coeff · ${stored(m, 'group_dimension') ?? '…'} dim`}</text>
                <text x={r1(x + PW / 2)} y={132} textAnchor="middle" className="t-tiny t-mono" data-norm={v ? `${v.g}/${v.need}` : ''}>{v ? `M M̃ = 1: ${v.g} of ${v.need} ${v.ok ? '✓' : '✗'}` : '…'}</text>
              </g>
            );
          })}
        </FigSvg>
      </div>
      <FigSvg id="rigid-frame-table" row={row} part="the picked rung" viewBox="0 0 600 236">
        <text x={8} y={16} className="t-small t-bold">{`n = ${n} · ${NAMES[n]}${fromTop && n < TOP ? ' · a face of the 5-cube' : ''}`}</text>
        <text x={8} y={30} className="t-tiny t-muted" data-lens-word={lens || 'clifford'}>{`on each vertex its motor coefficient: ${LENS_WORD[lens] || LENS_WORD.clifford}`}</text>
        {n <= TOP
          ? <Cube n={n} x={60} y={36} w={480} h={196} top={fromTop && n < TOP ? TOP : null} labels lens={lens} big />
          : <text x={300} y={130} textAnchor="middle" className="t-small t-muted" data-not-stored={n}>the frame table: not stored at n = 6</text>}
      </FigSvg>
      <div className="fig-note rg-note">
        <p data-support={`${support.grades.join(',')}:${support.components}`}>
          <KV k={`kernel, X X̃ for a generic even X of R(${n},0,1)`}>{`grades ${support.grades.join(', ')} · ${support.components} components`}</KV>
          {stored(n, 'norm_equations') != null ? <Ok ok={support.components === stored(n, 'norm_equations')} yes="= the stored equations" no="≠ the stored equations" /> : null}
        </p>
        {(() => { const v = verdict(5); return v ? <p data-shortfall={`${v.g}/${v.need}`}><KV k="n = 5">{`given ${v.g} · needed ${v.need}`}</KV><Ok ok={v.ok} yes="enough" no="one short" /></p> : null; })()}
      </div>
      <BodyPanel n={n} tab={tab} lens={lens} S={S} row={row} onTab={setTab} />
      <div className="fig-scroll rg-ft-wrap">
        <table className="rg-tab">
          <thead><tr><th scope="col">count</th>{order.map(m => <th key={m} scope="col" aria-current={m === n ? 'true' : undefined} className={m === n ? 'is-on' : ''}>{`n = ${m}`}</th>)}</tr></thead>
          <tbody>
            {ROWS.map(([key, name]) => (
              <tr key={key} data-row={key} className={key === hi ? 'is-on' : ''}>
                <th scope="row"><button type="button" className="rg-rowbtn" data-param="row" aria-pressed={key === hi} onClick={() => setHi(key)}>{name}</button></th>
                {order.map(m => {
                  const s = stored(m, key), kc = kernel[m][key], cf = closed[m][key], short = key === 'norm_equations' && s != null && verdict(m) && !verdict(m).ok;
                  const bad = s != null && (s !== kc || s !== cf);
                  return (
                    <td key={m} data-n={m} data-stored={s ?? ''} data-kernel={kc} data-closed={cf} className={(m === n ? 'is-on' : '') + (short ? ' is-short' : '')}>
                      {s === undefined ? '…' : s === null ? <span className="rg-ns">not stored</span> : <>{s}{key === 'needed' ? <> <Ok ok={stored(m, 'norm_equations') === s} yes="" no="short" /></> : null}{bad ? <Ok ok={false} no="kernel differs" /> : null}</>}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <Controls label="the frame table">
        <Chips label="rung" items={RUNGS} value={n} onPick={setN} render={m => `n = ${m}`} param="n" mono />
        <Toggle label={fromTop ? 'from the top: on' : 'from the top: off'} on={fromTop} onChange={setFromTop} param="top" />
      </Controls>
    </div>
  );
}
RigidFrameTable.meta = { id: 'rigid-frame-table', lenses: ['clifford', 'cube', 'simplex', 'demicube', 'prime'], learner: false };
RigidFrameTable.params = [{}, { n: 1 }, { n: 5, top: true, row: 'norm_equations' }, { n: 6 }, { n: 2, top: true }, { n: 4, body: 'outline' }, { n: 1, body: 'frame' }, { n: 3, body: 'frame' }];
/** the numbers the figure draws: the kernel's counts and the closed forms of every rung (the stored ones are content/stored_p11.json frame_table) */
RigidFrameTable.data = (params = {}) => { const n = okInt(params.n, RUNGS, 3); return { n, kernel: RUNGS.map(m => ({ n: m, ...frameCounts(m) })), closed: RUNGS.map(m => ({ n: m, ...frameClosed(m) })), support: normSupport(n), labels: Array.from({ length: 1 << Math.min(n, TOP) }, (_, v) => vertexLabel(Math.min(n, TOP), v, 'clifford')),
  body: (L => (L ? { tab: okInt(params.body, BODY_TABS, 'contact'), counts: L.b.counts, err: L.b.err, deepBits: L.b.deepBits, deepScan: L.b.deepScan, outline: L.b.outline, hull: L.b.hull, labels: L.labels } : null))(bodyLabels(n)) }; };
