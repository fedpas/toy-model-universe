// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/GaugeKit.jsx — what the six figures of steps 6–8 share (owner P7): the stored table (content/stored_p7.json through useTable, D34), the formula
// printer (KaTeX at research level, its TeX in data-tex), the marks ✓ / ✗ / not stored, the folds, and the Atlas method of D37: the rungs from the lowest stored
// cell up (or from the top down), the switch "from the top", and the ladder drawn as a grid of rungs × blocks of stored data, where a rung a block lacks is an
// empty dashed box and never a number. The lens picker is FigureFrame's lens chips (clifford, simplex, cube, demicube, prime labels), at every rung.
import React from 'react';
import { useTable } from '../../app/content.js';
import { texToHtml, useKatex } from '../../app/math.js';
import { FigSvg, Chips, Toggle, r1 } from '../kit.jsx';
import './p7.css';

/** the lenses every figure of P7 redraws in (D37: clifford | simplex | cube | demicube | prime labels) */
export const P7_LENSES = ['clifford', 'simplex', 'cube', 'demicube', 'prime'];
export const lensKey = lens => (P7_LENSES.includes(lens) ? lens : null);
/** the name of the view a lens opens (the v15 views of steps 6–8) */
export const LENS_VIEW = { clifford: 'Clifford', simplex: 'simplex', cube: 'cube', demicube: 'demicube', prime: 'labels' };

/** the stored check data of steps 6–8, or null while the table loads */
export function useStored() {
  const [S] = useTable('stored_p7');
  return S && S.cp && S.cpm && S.ym && S.ymm && S.mt && S.mtm ? S : null;
}
export const intIn = (v, list, d) => (list.includes(v) ? v : d);
/** the KaTeX engine at research level only (learner level never typesets a formula) */
export function useKatexAt(research) { const k = useKatex(research); return research ? k : null; }
export const minus = s => String(s).replace(/-/g, '−');

/** a formula: KaTeX when the engine is loaded (research level only), else the plain text; the TeX is kept in data-tex */
export function Tex({ tex, plain, katex }) {
  const html = katex ? texToHtml(tex) : null;
  if (html) return <span className="g7-tex" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} />;
  return <span className="g7-tex fig-mono" data-tex={tex}>{plain}</span>;
}

/** the rungs as chips: from the lowest stored cell up, or from the top down (D37) */
export function Rungs({ label, values, value, onPick, top, param, render = String }) {
  return <Chips label={label} items={top ? [...values].reverse() : values} value={value} onPick={onPick} param={param} render={render} mono />;
}
/** D37: start at the highest stored cell and read each lower one as its restriction */
export function TopSwitch({ on, onChange }) { return <Toggle label="from the top" on={on} onChange={onChange} param="top" />; }

/** ✓ holds · ✗ fails (the word in the title and the label) · a dashed box with the words "not stored" */
export function Mark({ v }) {
  if (v === true) return <span className="g7-ok" role="img" title="holds" aria-label="holds" data-mark="1">✓</span>;
  if (v === false) return <span className="g7-no" role="img" title="fails" aria-label="fails" data-mark="0">✗</span>;
  return <NotStored />;
}
export const NotStored = () => <span className="g7-ns" data-ns="1">not stored</span>;
export function Fold({ title, id, open = false, children }) {
  return <details className="g7-fold" data-fold={id} open={open}><summary>{title}</summary><div>{children}</div></details>;
}
/** a readout line: [[key, value, data attributes]] in the mono printing */
export function Readout({ items, data }) {
  return (
    <p className="g7-readout" {...data}>
      {items.filter(Boolean).map(([k, v, attrs], i) => <span key={i} {...attrs}>{k ? <span className="g7-k">{k} </span> : null}{v}</span>)}
    </p>
  );
}
/** a small table of marks: the identities of a rung, one row per stored cell, one column per identity (its full name in the column's title) */
export function MiniTable({ heads, titles = heads, rows }) {
  return (
    <table className="g7-mini">
      <thead><tr><th />{heads.map((h, i) => <th key={i} title={titles[i]}>{h}</th>)}</tr></thead>
      <tbody>{rows.map(r => <tr key={r.key} {...r.data}><th>{r.label}</th>{r.cells.map((c, i) => <td key={i} {...c.data}><Mark v={c.v} /></td>)}</tr>)}</tbody>
    </table>
  );
}
/** the legend's small marks (decorative: the word beside each one carries the meaning) */
export function LegendMark({ kind }) {
  const g = {
    dot: <circle cx={7} cy={6} r={4} className="g7-dot" />,
    ring: <circle cx={7} cy={6} r={4} className="g7-ring" />,
    double: <><circle cx={7} cy={6} r={5} className="g7-ring" /><circle cx={7} cy={6} r={2.6} className="g7-dot" /></>,
    solid: <line x1={0} y1={6} x2={14} y2={6} className="g7-line is-lit" />,
    dash: <line x1={0} y1={6} x2={14} y2={6} className="g7-line g7-dash" />,
    face: <polygon points="1,11 7,1 13,11" className="g7-face" />,
    box: <rect x={2} y={1} width={10} height={10} className="g7-box" />,
    empty: <rect x={2} y={1} width={10} height={10} className="g7-box-ns" />,
  }[kind];
  return <svg viewBox="0 0 14 12" aria-hidden="true">{g}</svg>;
}
export function Legend({ items }) {
  return <ul className="g7-legend">{items.filter(Boolean).map(([kind, word], i) => <li key={i} data-legend={kind}><LegendMark kind={kind} /><span>{word}</span></li>)}</ul>;
}

// ---------------------------------------------------------------- the ladder drawn (D37)
const MARKS = {
  square: (x, y) => <rect x={r1(x - 5)} y={r1(y - 5)} width={10} height={10} className="g7-dot" />,
  diamond: (x, y) => <path d={`M${r1(x)} ${r1(y - 6.5)} L${r1(x + 6.5)} ${r1(y)} L${r1(x)} ${r1(y + 6.5)} L${r1(x - 6.5)} ${r1(y)} Z`} className="g7-dot" />,
  circle: (x, y) => <circle cx={r1(x)} cy={r1(y)} r={5.4} className="g7-dot" />,
  triangle: (x, y) => <path d={`M${r1(x)} ${r1(y - 6)} L${r1(x + 6.4)} ${r1(y + 5)} L${r1(x - 6.4)} ${r1(y + 5)} Z`} className="g7-dot" />,
  ring: (x, y) => <circle cx={r1(x)} cy={r1(y)} r={5} className="g7-ring" />,
  check: (x, y) => <path d={`M${r1(x - 5)} ${r1(y)} L${r1(x - 1.5)} ${r1(y + 4)} L${r1(x + 5.5)} ${r1(y - 5)}`} className="g7-line is-lit" style={{ strokeWidth: 2.2 }} />,
};
/** The ladder as one picture: a rung per cell of the figure (the highest on top), a column per block of stored data, a filled mark where the block is stored at that
 *  rung and an empty dashed box where it is not; the chosen rung banded, every rung a pick (data-param). From the top, an arrow runs down from the highest rung and a
 *  last column marks each lower rung that is the restriction of the top one (restricts(low) from the kernel); else the arrow runs up from the lowest. */
export function LadderSvg({ id, row, rungs, rungLabel, blocks, value, onPick, top, param, restricts, part }) {
  const W0 = 92, CW = 66, RH = 28, H0 = 46, cols = blocks.length + (top ? 1 : 0), W = W0 + cols * CW + 30, H = H0 + rungs.length * RH + 18;
  const yOf = v => H0 + (rungs.length - 1 - rungs.indexOf(v)) * RH + RH / 2, xOf = j => W0 + j * CW + CW / 2, hi = rungs[rungs.length - 1], lo = rungs[0];
  return (
    <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${W} ${H}`} className="g7-ladder" data-rungs={rungs.join(',')} data-top={top ? 'true' : 'false'}>
      {blocks.map((b, j) => <text key={b.key} x={xOf(j)} y={18} textAnchor="middle" className="t-tiny t-bold">{b.name}</text>)}
      {blocks.map((b, j) => b.sub ? <text key={'s' + b.key} x={xOf(j)} y={31} textAnchor="middle" className="t-micro t-muted">{b.sub}</text> : null)}
      {top && <text x={xOf(blocks.length)} y={18} textAnchor="middle" className="t-tiny t-bold">{`⊂ ${rungLabel(hi)}`}</text>}
      <line x1={W - 14} y1={yOf(top ? hi : lo)} x2={W - 14} y2={yOf(top ? lo : hi)} className="g7-line" />
      <path d={top ? `M${W - 18} ${r1(yOf(lo) - 7)} L${W - 14} ${r1(yOf(lo))} L${W - 10} ${r1(yOf(lo) - 7)}` : `M${W - 18} ${r1(yOf(hi) + 7)} L${W - 14} ${r1(yOf(hi))} L${W - 10} ${r1(yOf(hi) + 7)}`} className="g7-line" data-direction={top ? 'down' : 'up'} />
      {rungs.map(v => {
        const y = yOf(v), on = v === value;
        return (
          <g key={v} className="g7-pick" role="button" tabIndex={0} aria-pressed={on} aria-label={rungLabel(v)} data-param={param} data-rung={v}
            onClick={() => onPick(v)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(v); } }}>
            <rect x={2} y={r1(y - RH / 2 + 2)} width={W - 22} height={RH - 4} rx={4} className={on ? 'g7-band' : 'g7-hit'} />
            <text x={8} y={r1(y + 4)} className={'t-mono t-small' + (on ? ' t-bold' : '')}>{rungLabel(v)}</text>
            {blocks.map((b, j) => {
              const has = b.has(v), x = xOf(j);
              if (has == null) return <g key={b.key} data-block={b.key} data-stored=""><title>{`${b.name}: loading`}</title><circle cx={r1(x)} cy={r1(y)} r={2} className="g7-hair" /></g>;
              return (
                <g key={b.key} data-block={b.key} data-stored={has ? 1 : 0}>
                  <title>{`${b.name} at ${rungLabel(v)}: ${has ? 'stored' : 'not stored'}`}</title>
                  {has ? MARKS[b.mark](x, y) : <rect x={r1(x - 6)} y={r1(y - 6)} width={12} height={12} className="g7-box-ns" />}
                </g>
              );
            })}
            {top && (v === hi
              ? <text x={xOf(blocks.length)} y={r1(y + 4)} textAnchor="middle" className="t-micro t-muted">top</text>
              : <g data-restricts={restricts(v) ? 1 : 0}><title>{`${rungLabel(v)} ⊂ ${rungLabel(hi)}: ${restricts(v) ? 'the restriction (every sign the same)' : 'not a restriction'}`}</title>{restricts(v) ? MARKS.check(xOf(blocks.length), y) : MARKS.ring(xOf(blocks.length), y)}</g>)}
          </g>
        );
      })}
    </FigSvg>
  );
}
