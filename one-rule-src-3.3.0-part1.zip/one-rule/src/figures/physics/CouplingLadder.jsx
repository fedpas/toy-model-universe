// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure coupling-ladder (step 6, section of steps/coupling; audit CP2, CP3, CP5, CP6): what coupling_selfcheck.py and coupling_matrix_check.py store about the coupled
// Dirac–Maxwell system, rung by rung, n = 1 … 8 (content/stored_p7.json cp and cpm, D34). The ladder drawn first (D37): a rung per n from the lowest stored cell up,
// a column per block of stored data — the ladder row, the exact identities (n = 3, 4, 5), the mass shell (n = 3 … 7), the numpy matrix check (n = 3 … 7) — an empty
// dashed box where a block has no data; "from the top" starts at Cl(1,7) and marks every lower cell as its restriction (the kernel's signs). Beside it the chosen
// rung: the ladder row, its identities and its matrix check; under it, in folds, every view at n (Clifford, cube, simplex, demicube, labels, Maxwell, Dirac: names and
// numbers only, the view of the active lens opened beside the rung), the ladder table, the identities (KaTeX, ✓ per stored n) and the matrix check with its three
// wrong versions. Every number is the stored one; tests/physics/p7.test.mjs recomputes the ladder, the shell and the views through the kernel (engines/physics/
// gauge.js) and ties the identities and the numpy results to the file only (D11). Port of v15 CouplingSection.jsx (the table, the views, the identities, the matrix
// check), with its chips n = 1 … 8 and the click on a row. Research level only.
import React, { useEffect, useMemo, useState } from 'react';
import { labelIn, restricts, axName, couplingCell, COUPLING_NS } from '../../../engines/physics/gauge.js';
import { Controls } from '../kit.jsx';
import { useStored, lensKey, LENS_VIEW, intIn, minus, Tex, Rungs, TopSwitch, Readout, Legend, Mark, NotStored, Fold, LadderSvg, useKatexAt } from './GaugeKit.jsx';

const TOP = 8;
export const CP_IDENTITIES = [
  ['conservation_identity', 'conservation', '\\nabla\\cdot X=-2\\langle\\gamma_0\\tilde\\psi DJ\\rangle_0', 'div X = −2⟨γ₀ψ̃DJ⟩₀'],
  ['gauge_first_order', 'gauge invariance (first order)', '\\psi\\to\\psi(1+J\\varepsilon),\\ A\\to A-\\nabla\\varepsilon/e:\\ \\delta D=(DJ)\\varepsilon', 'ψ → ψ(1 + Jε), A → A − ∇ε/e: δD = (DJ)ε'],
  ['maxwell_forces_div_J_zero', 'Maxwell forces div X = 0', '\\nabla\\cdot\\langle\\nabla F\\rangle_1=0', 'div ⟨∇F⟩₁ = 0'],
  ['algebraic_facts', 'algebraic facts', '\\langle\\gamma_0\\tilde\\psi A\\psi J\\rangle_0=0=\\langle\\tilde\\psi\\psi J\\rangle_0', '⟨γ₀ψ̃AψJ⟩₀ = 0 = ⟨ψ̃ψJ⟩₀'],
];
const DEF = { tex: 'D=\\nabla\\psi J-eA\\psi-m\\psi\\gamma_0,\\quad X=\\psi\\gamma_0\\tilde\\psi', plain: 'D = ∇ψJ − eAψ − mψγ₀, X = ψγ₀ψ̃' };
const MAP = { tex: '\\nabla\\psi J-eA\\psi-m\\psi\\gamma_0\\ \\mapsto\\ i\\gamma^\\mu\\partial_\\mu\\Psi-e\\gamma^\\mu A_\\mu\\Psi-m\\Psi,\\quad \\Psi=\\psi u,\\ \\gamma_0u=u,\\ Ju=\\pm iu', plain: '∇ψJ − eAψ − mψγ₀ ↦ iγ^μ∂_μΨ − eγ^μA_μΨ − mΨ, Ψ = ψu, γ₀u = u, Ju = ±iu' };
const words = k => k.replace(/_/g, ' ');
/** terms per equation as stored: all the incidences over the equations (one per odd blade); '—' without J */
export const termsPerEquation = r => (r.incidences_total == null ? '—' : String(r.incidences_total / r.odd_corners));
/** the views of v15 at the rung n, names and numbers only, read from the stored row (and shell); the lens picks one */
export function viewsOf(n, r, shell, L) {
  const J = r.J_exists, lab = m => labelIn(L, m, { n, kind: 'st' }), grades = r.current_grades.map(g => `${r.current_blades[g]} blade${r.current_blades[g] === 1 ? '' : 's'} of grade ${g}`).join(' + ');
  const added = J ? couplingCell(n).newEdges : null;
  return [
    { key: 'Clifford', items: [[`Cl(1,${n - 1})`, `≅ ${r.algebra}`], ['even half', r.even_half], ['ψ', `${r.psi_components} real`], J ? ['one Dirac spinor', `${r.dirac_real_dim} real`] : ['Dirac count', '— (no J)'], J && ['ratio', r.psi_over_dirac]] },
    { key: 'cube', items: J ? [['per corner', `${n} ∂ + ${n} A + 1 m`], ['per equation', termsPerEquation(r)], ['in all', String(r.incidences_total)], ['added by the coupling', `${r.coupling_edges} terms · ${added} new edges`]] : [['mass edges', String(r.mass_edges)], ['∂ and A terms', '— (no J)']] },
    { key: 'simplex', items: J ? [['coupling terms of an odd blade', `on its ${n} even neighbours`], ['corner simplex', r.coupling_terms_are_corner_simplex ? '✓' : '✗'], ['∂ terms', 'the same simplex moved by J'], ['', 'our reading (CPL-010)']] : [['even neighbours', String(n)], ['∂ terms', '— (no J)']] },
    { key: 'demicube', items: [['current ψγ₀ψ̃', grades], ['density', `${r.rho_terms} corners squared · ${r.rho_positive_definite ? 'a sum of squares ✓' : '✗'}`], n > 1 && ['each space component', `${r.demicube_edges_of_type_0k} demicube edges {t, k}`], r.pair_distance['5'] && ['grade-5 pairs', `distance ${r.pair_distance['5'].join(' or ')}`]] },
    { key: 'labels', items: [['γ₀', lab(1)], J ? ['J = γ₂γ₁', lab(r.J_label)] : ['J', 'none'], ['bivectors with J² = −1 commuting with γ₀', String(r.J_count)], r.even_labels && ['even labels', r.even_labels.map(lab).join(', ')]] },
    { key: 'Maxwell', items: [['F', `${r.F_components} components`], ['∇F = eX', `${r.maxwell_incidences} incidences`], ['source', `${n} vector components`], r.current_blades['5'] && ['grade-5 part', `${r.current_blades['5']} blades · no slot in ∇F (grades 1, 3)`]] },
    { key: 'Dirac', items: !J ? [['', 'no Dirac equation of this form (no J)']] : shell ? [['mass shell', `${shell.kernel_real_dim} real`], ['half of ψ', String(shell.half_of_psi)], ['in Dirac spinors', `${shell.kernel_real_dim / shell.one_dirac_spinor} × ${shell.one_dirac_spinor}`]] : [['mass shell', 'not stored']] },
  ];
}
function View({ v, lens, n }) {
  return (
    <div className={'g7-card' + (lens ? ' is-lens' : '')} data-view={v.key}>
      <h4>{v.key}<span className="g7-sub">{`n = ${n}`}</span></h4>
      <Readout items={v.items.filter(Boolean).map(([k, val]) => [k, val])} />
    </div>
  );
}

export default function CouplingLadder({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => ({ n: intIn(params.n, COUPLING_NS, params.top === true ? TOP : 4), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.n, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { n, top } = st, pick = v => setSt(s => ({ ...s, n: v }));
  const order = top ? [...COUPLING_NS].reverse() : COUPLING_NS;
  const restr = useMemo(() => Object.fromEntries(COUPLING_NS.map(v => [v, v < TOP ? restricts('coupling', v, TOP) : null])), []);
  const has = key => v => (S ? (key === 'cpm' ? String(v) in S.cpm.max_error : !!S.cp[key][String(v)]) : null);
  const blocks = [
    { key: 'ladder', name: 'ladder', sub: 'n = 1 … 8', mark: 'square', has: has('ladder') },
    { key: 'identities', name: 'identities', sub: 'exact', mark: 'check', has: has('identities') },
    { key: 'shell', name: 'mass shell', sub: 'exact', mark: 'circle', has: has('shell') },
    { key: 'matrix', name: 'matrix', sub: 'numpy', mark: 'diamond', has: has('cpm') },
  ];
  const r = S ? S.cp.ladder[String(n)] : null, id = S ? S.cp.identities[String(n)] : null, sh = S ? S.cp.shell[String(n)] : null;
  const mx = S && String(n) in S.cpm.max_error ? { err: S.cpm.max_error[String(n)], rank: S.cpm.rank_real[String(n)], cur: S.cpm.current[String(n)] || null } : null;
  const curText = c => (!c ? '—' : c.ratios_X_over_bilinear ? `X / Ψ†γ₀γₘΨ = ${c.ratios_X_over_bilinear.map(minus).join(', ')}` : c.psi_with_zero_spinor_but_nonzero_vector_current ? 'ψu = 0 with X ≠ 0 ✓' : '—');
  const views = useMemo(() => (r ? viewsOf(n, r, sh, L) : []), [n, r, sh, L]);
  const lensView = L ? views.find(v => v.key === LENS_VIEW[L]) : null;
  return (
    <div className="fig fig-coupling-ladder g7-split" data-n={n} data-top={top ? 'true' : 'false'} data-lens={L || ''}>
      <div className="g7-left">
        <LadderSvg id="coupling-ladder" row={row} rungs={COUPLING_NS} rungLabel={v => `Cl(1,${v - 1})`} blocks={blocks} value={n} onPick={pick} top={top} param="n" restricts={v => restr[v]} />
        <Legend items={[['box', 'stored'], ['empty', 'not stored'], top && ['solid', `each lower cell ⊂ Cl(1,${TOP - 1}): every sign the same`]]} />
        <Controls label="coupling ladder">
          <Rungs label="n" values={COUPLING_NS} value={n} top={top} param="n" onPick={pick} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ top: on, n: on ? TOP : s.n }))} />
        </Controls>
      </div>
      <div className="g7-right">
        <div className="g7-card" data-rung-card={n}>
          <h4>{`Cl(1,${n - 1})`}<span className="g7-sub">{r ? `≅ ${r.algebra} · signature ${r.signature}` : 'loading the stored checks'}</span></h4>
          {r && <Readout data={{ 'data-row': n }} items={[
            ['ψ', `${r.psi_components} real`, { 'data-psi': r.psi_components }],
            ['one Dirac spinor', r.J_exists ? `${r.dirac_real_dim} real` : '—', { 'data-dirac': r.J_exists ? r.dirac_real_dim : '' }],
            ['ψ ÷ Dirac', r.J_exists ? r.psi_over_dirac : '—', { 'data-ratio': r.J_exists ? r.psi_over_dirac : '' }],
            ['J', r.J_exists ? `${labelIn(L, r.J_label, { n, kind: 'st' })} (${r.J_count})` : 'none', { 'data-j': `${r.J_label},${r.J_count}` }],
            ['current grades', r.current_grades.join(' + '), { 'data-grades': r.current_grades.join(',') }],
            ['terms per equation', termsPerEquation(r), { 'data-terms': termsPerEquation(r) }],
          ]} />}
          {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`⊂ Cl(1,${TOP - 1})`, n === TOP ? 'top' : restr[n] ? '✓ every sign the same' : '✗', { 'data-restricts': n === TOP ? 'top' : String(restr[n]) }]]} />}
        </div>
        <div className="g7-card" data-identities-at={n}>
          <h4>exact identities<span className="g7-sub">{`n = ${n}`}</span></h4>
          {id ? <Readout items={CP_IDENTITIES.map(([k, nm]) => [nm, <Mark v={id[k]} />, { 'data-id': `${k},${id[k]}` }])} /> : S ? <NotStored /> : null}
        </div>
        <div className="g7-card" data-matrix-at={n}>
          <h4>matrix check (numpy)<span className="g7-sub">{`n = ${n}`}</span></h4>
          {mx ? <Readout items={[['largest error', String(mx.err), { 'data-err': mx.err }], ['real rank of ψ ↦ ψu', String(mx.rank), { 'data-rank': mx.rank }], mx.cur && ['current', curText(mx.cur), { 'data-current': JSON.stringify(mx.cur) }]]} /> : S ? <NotStored /> : null}
          {sh && <Readout data={{ 'data-shell': n }} items={[['mass shell', `${sh.kernel_real_dim} real (half of ψ: ${sh.half_of_psi})`, { 'data-kernel': sh.kernel_real_dim }]]} />}
        </div>
        {lensView && <View v={lensView} lens n={n} />}
      </div>
      <div className="g7-wide">
        {r && (
          <Fold id="views" title={`Every view at n = ${n}`}>
            <div className="fig-panels">{views.map(v => <View key={v.key} v={v} lens={lensView === v} n={n} />)}</div>
          </Fold>
        )}
        {S && (
          <Fold id="ladder" title="The ladder n = 1 … 8">
            <table className="g7-table" data-table="ladder">
              <thead><tr>{['n', 'algebra', 'ψ (real components)', 'one Dirac spinor', 'ψ ÷ Dirac', 'complex structure J', 'current grades', 'terms per equation'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{order.map(v => { const x = S.cp.ladder[String(v)]; return (
                <tr key={v} className={v === n ? 'is-on' : ''} data-param="n" data-ladder={v} onClick={() => pick(v)}>
                  <td className="g7-n">{v}</td><td>{x.algebra}</td><td className="g7-n">{x.psi_components}</td><td className="g7-n">{x.J_exists ? x.dirac_real_dim : '—'}</td>
                  <td className="g7-n">{x.J_exists ? x.psi_over_dirac : '—'}</td><td>{x.J_exists ? `${labelIn(L, x.J_label, { n: v, kind: 'st' })} (${x.J_count})` : 'none'}</td>
                  <td>{x.current_grades.join(' + ')}</td><td className="g7-n">{termsPerEquation(x)}</td>
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {S && (
          <Fold id="identities" title="Exact identities (random polynomial fields)">
            <p className="g7-readout"><Tex katex={katex} tex={DEF.tex} plain={DEF.plain} /></p>
            <table className="g7-table" data-table="identities">
              <thead><tr><th>n</th>{CP_IDENTITIES.map(([k, nm, tex, plain]) => <th key={k}>{nm}<br /><Tex katex={katex} tex={tex} plain={plain} /></th>)}</tr></thead>
              <tbody>{order.map(v => { const x = S.cp.identities[String(v)]; return (
                <tr key={v} className={(v === n ? 'is-on' : '') + (x ? '' : ' is-ns')} data-identities={v}>
                  <td className="g7-n">{v}</td>{x ? CP_IDENTITIES.map(([k]) => <td key={k} data-id={`${v},${k},${x[k]}`}><Mark v={x[k]} /></td>) : <td colSpan={CP_IDENTITIES.length}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {S && (
          <Fold id="matrix" title="Independent check with matrices (numpy, Jordan–Wigner)">
            <p className="g7-readout"><Tex katex={katex} tex={MAP.tex} plain={MAP.plain} /></p>
            <table className="g7-table" data-table="matrix">
              <thead><tr>{['n', 'largest error', 'real rank of ψ ↦ ψu', 'current'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{order.map(v => { const k = String(v), on = k in S.cpm.max_error; return (
                <tr key={v} className={(v === n ? 'is-on' : '') + (on ? '' : ' is-ns')} data-matrix={v}>
                  <td className="g7-n">{v}</td>{on ? <><td className="g7-n">{S.cpm.max_error[k]}</td><td className="g7-n">{S.cpm.rank_real[k]}</td><td>{curText(S.cpm.current[k])}</td></> : <td colSpan={3}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
            <Readout data={{ 'data-controls': Object.keys(S.cpm.controls).length }} items={[['wrong versions', ''], ...Object.entries(S.cpm.controls).map(([k, v]) => ['', `${words(k)}: ${v}`, { 'data-control': k }]), ['status', S.cpm.status]]} />
          </Fold>
        )}
        <p className="g7-conv" data-convention="1"><span className="g7-k">inputs:</span> J = γ₂γ₁ on the blade {axName(6)} (label 6, INP-031) · the coupling e, a free constant (INP-028) · signature 1 + (n − 1)</p>
      </div>
    </div>
  );
}
CouplingLadder.meta = { id: 'coupling-ladder', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: false };
CouplingLadder.params = [{}, { n: 1 }, { n: 5 }, { n: 8 }, { n: 3, top: true }];
/** the numbers the figure draws come from the stored table; data() gives the kernel's part: the rungs, the restrictions from the top, the coupling counts */
CouplingLadder.data = (p = {}) => {
  const n = intIn(p.n, COUPLING_NS, p.top === true ? TOP : 4), C = couplingCell(n);
  return { n, top: p.top === true, rungs: COUPLING_NS, restricts: COUPLING_NS.map(v => (v < TOP ? restricts('coupling', v, TOP) : null)), counts: C.counts, newEdges: C.newEdges, simplex: C.simplex };
};
