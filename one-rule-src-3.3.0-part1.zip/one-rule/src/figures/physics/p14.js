// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p14.js — round 17 (proofs pass 13a, docs/round17/PROOFS_ROUND13A.md) registers its two figures here (id → component): clock-walk
// (caption row LAB-026) and dragon-blades (caption row LAB-027), both in the section clock of the page clock by their caption rows. Seeds in
// content/physics/figures.p14.json; the engine engines/physics/clockWalk.js; the test tests/physics/p14.test.mjs. src/figures/physics/index.js spreads
// this registry, so the figures ride in dist/figures-extra.js (D47).
import ClockWalk from './ClockWalk.jsx';
import DragonBlades from './DragonBlades.jsx';
export const P14_FIGURES = { 'clock-walk': ClockWalk, 'dragon-blades': DragonBlades };
