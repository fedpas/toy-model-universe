// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure forque-lines (step 14; caption row EQN-016; docs/PHYSICS_AUDIT.md FQ1, FQ5, D37): the four lines of the dynamics (Table 2.1 of the paper: Motion,
// Momentum, Forque, Dynamics), each with the rows of the matrix that check it, and the numerical cross-check. The first drawing is the ladder of the
// cells Cl(d,0,1) the rows were checked in (their stored dimensions, forque.json), from the lowest d up (D37; or "from the top"): a column per rung
// with its pseudoscalar I = ε·O in the labels of the page's lens (clifford: the paper's names e0123; simplex, cube, demicube, prime) and the squares
// I² and O² by the kernel in the paper's signature (bit 0 null, bits 1 … d square +1: the stored conventions), a row per line, a mark per cell (all its
// rows checked there filled, some half, none dashed and "not stored"). Then each line's rows as lines of the matrix (paper ↔ bit rule; rows FRQ-M…,
// statements once their texts are merged). The second drawing is forque_matrix.json on a logarithmic scale: the errors of the equation as printed
// (dots: free and heavy top, momentum, the spherical and symmetric tops, the pose and the motor manifold) against the three wrong versions (crosses:
// no Coriolis term, wrong sign, wrong factor), and the tennis-racket rate, predicted (recomputed by forquePhysics.predictedRate for the run's
// inertias 5, 3, 1) and measured. Control: the switch "from the top" (D37). Research level only.
import React, { useEffect, useMemo, useState } from 'react';
import { linesLadder, matrixCheck, racketRate, pgaName, pgaSquares, FORQUE_LINES } from '../../../engines/physics/forquePhysics2.js';
import { D37_LENSES } from '../../../engines/physics/spinPhysics.js';
import { label, popcount } from '../../../engines/bitrule.js';
import { FigSvg, Controls, Toggle, r1 } from '../kit.jsx';
import { MatrixLines, StatusGlyph } from './TranslationMatrix.jsx';
import { useStoredP6, STATUS_WORDS, sci } from './p6kit.jsx';
import './translation.css';

const lensOf = l => (D37_LENSES.includes(l) ? l : 'clifford');
/** a PGA mask (bit 0 = e0) in the labels of a D37 lens */
export function pgaLabel(mask, lens, d) {
  const eps = pgaSquares(d);
  switch (lens) {
    case 'simplex': { const s = []; for (let i = 0; i <= d; i++) if (Math.floor(mask / 2 ** i) % 2) s.push(i); return `{${s.join(',')}}`; }
    case 'cube': return label(mask, 'bits', eps);
    case 'demicube': return `${label(mask, 'bits', eps)}${popcount(mask) % 2 === 0 ? ' even' : ' odd'}`;
    case 'prime': return label(mask, 'primes', eps);
    default: return pgaName(mask);
  }
}
const sq = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');
const SUPS = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
const pow10 = e => (e === 0 ? '1' : e === 1 ? '10' : `10${String(e).split('').map(c => SUPS[c]).join('')}`);

export default function ForqueLines({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const [top, setTop] = useState(params.top === true);
  useEffect(() => { setTop(params.top === true); }, [params.top]);
  const S = useStoredP6(params), lk = lensOf(lens);
  const L = useMemo(() => linesLadder(S ? S.forque.rows : [], { top }), [S, top]);
  const M = useMemo(() => matrixCheck(S ? S.forque_matrix : null), [S]), R = racketRate(S ? S.forque_matrix : null);
  const lineRows = id => (S ? S.derived.forqueLines.filter(l => FORQUE_LINES.find(x => x.key === id).rows.includes(l.id)).map(l => ({ id: l.id, left: l.left, right: l.right, badgeRow: l.row, status: l.status })) : []);
  // the ladder
  const W = 440, lx = 118, colW = (W - lx - 8) / Math.max(1, L.rungs.length || 3), hy = 30, rowH = 28, top0 = hy + 58, H1 = top0 + FORQUE_LINES.length * rowH + 14;
  // the cross-check: one row per check on a logarithmic scale 1e−16 … 1e1, the equation as printed (dots) and the three wrong versions (crosses)
  const marks = [...M.pass.map(p => ({ ...p, kind: 'pass' })).sort((a, b) => a.value - b.value), ...M.fail.map(f => ({ ...f, kind: 'fail' })).sort((a, b) => a.value - b.value)];
  const W2 = 440, ax0 = 186, ax1 = 430, lo = -16, hi = 1, r0 = 34, rh = 15, ay = r0 + marks.length * rh + 4, H2 = ay + 74;
  const X = v => ax0 + ((ax1 - ax0) * (Math.log10(Math.max(v, 1e-17)) - lo)) / (hi - lo);
  return (
    <div className="fig fig-forque-lines" data-lens={lk} data-top={top ? 1 : 0}>
      <FigSvg id="forque-lines" row={row} viewBox={`0 0 ${W} ${H1}`}>
        <text x={8} y={16} className="t-small">{top ? `the four lines, from the top: d = ${L.dMax ?? '—'} down` : `the four lines in the cells Cl(d,0,1), d = ${L.dMin ?? '—'} up`}</text>
        {!L.rungs.length ? <text x={8} y={hy + 20} className="t-tiny t-muted">no stored row loaded</text> : null}
        {L.rungs.map((g, j) => {
          const x = lx + j * colW + colW / 2;
          return (
            <g key={g.d} data-rung={g.d} data-i={g.I} data-sq-i={g.squareI} data-sq-o={g.squareO} data-rows={g.rows.length}>
              <text x={x} y={hy + 4} textAnchor="middle" className="t-mono t-small">{`d = ${g.d}`}</text>
              <text x={x} y={hy + 17} textAnchor="middle" className="t-mono t-tiny" data-label={lk}>{`I = ${pgaLabel(g.I, lk, g.d)}`}</text>
              <text x={x} y={hy + 28} textAnchor="middle" className="t-mono t-micro t-muted">{`I² = ${sq(g.squareI)} · O² = ${sq(g.squareO)}`}</text>
              <text x={x} y={hy + 38} textAnchor="middle" className="t-mono t-micro t-muted">{`${g.rows.length} rows checked`}</text>
              {g.lines.map((ln, i) => {
                const y = top0 + i * rowH;
                return (
                  <g key={ln.key} data-cell={`${g.d},${ln.key}`} data-at={ln.at.join(',')}>
                    <title>{`${ln.name} in d = ${g.d}: ${ln.at.length ? ln.at.join(', ') : 'not stored'}`}</title>
                    {ln.stored ? <StatusGlyph shape={ln.all ? 'filled' : 'half'} x={x - 22} y={y} s={10} /> : <StatusGlyph shape="dash" x={x - 22} y={y} s={10} />}
                    <text x={x - 12} y={y + 3.5} className="t-mono t-micro">{ln.stored ? ln.at.join(' ') : 'not stored'}</text>
                  </g>);
              })}
            </g>
          );
        })}
        {FORQUE_LINES.map((ln, i) => <text key={ln.key} x={8} y={top0 + i * rowH + 4} className="t-small" data-line={ln.key}>{ln.name}</text>)}
        <g transform={`translate(8, ${H1 - 8})`}>
          {[['filled', 'all its rows checked'], ['half', 'some'], ['dash', 'not stored']].map(([s, w], i) => <g key={s}><StatusGlyph shape={s} x={i * 140 + 5} y={-4} s={9} /><text x={i * 140 + 14} y={0} className="t-tiny">{w}</text></g>)}
        </g>
      </FigSvg>
      {research && (
        <Controls label="ladder">
          <Toggle label={top ? 'from the top: on' : 'from the top'} on={top} onChange={setTop} param="top" />
        </Controls>
      )}
      {research && S ? (
        <div className="p6-lines">
          {FORQUE_LINES.map(ln => (
            <div key={ln.key} className="p6-line" data-four={ln.key}>
              <h4>{ln.name}</h4>
              <span className="p6-jumps">{ln.rows.join(' · ')}</span>
              <MatrixLines rows={lineRows(ln.key)} level={level} lens={lens} mode={mode} figId={`forque-lines-${ln.key}`} statusWords={STATUS_WORDS} />
            </div>
          ))}
        </div>
      ) : null}
      <FigSvg id="forque-lines" row={row} part="the numerical cross-check" viewBox={`0 0 ${W2} ${H2}`}>
        <text x={8} y={16} className="t-small">the numerical cross-check (forque_matrix_check.py)</text>
        <line x1={ax0} y1={ay} x2={ax1} y2={ay} className="hair" />
        {[-15, -12, -9, -6, -3, 0].map(e => <g key={e}><line x1={r1(X(10 ** e))} y1={r0 - 6} x2={r1(X(10 ** e))} y2={ay + 3} className="hair-2" /><text x={r1(X(10 ** e))} y={ay + 14} textAnchor="middle" className="t-mono t-micro t-muted">{pow10(e)}</text></g>)}
        {marks.map((m, i) => {
          const x = X(m.value), y = r0 + i * rh, right = x > ax1 - 60;
          return (
            <g key={m.key} data-check={m.key} data-kind={m.kind} data-value={m.value}>
              <title>{`${m.name}, ${m.what}: ${m.value}`}</title>
              <text x={8} y={y + 3.5} className="t-tiny">{`${m.name} · ${m.what}`}</text>
              <line x1={ax0} y1={y} x2={r1(x)} y2={y} className="hair-2" />
              <StatusGlyph shape={m.kind === 'pass' ? 'dot' : 'cross'} x={x} y={y} s={m.kind === 'pass' ? 12 : 8} />
              <text x={r1(right ? x - 8 : x + 8)} y={y + 3.5} textAnchor={right ? 'end' : 'start'} className="t-mono t-micro">{sci(m.value)}</text>
            </g>);
        })}
        <g transform={`translate(8, ${ay + 32})`} data-legend="pass"><StatusGlyph shape="dot" x={5} y={-4} s={12} /><text x={14} y={0} className="t-tiny">{`the equation as printed: worst error ${M.worst === null ? '—' : sci(M.worst)}`}</text></g>
        <g transform={`translate(8, ${ay + 47})`} data-legend="fail"><StatusGlyph shape="cross" x={5} y={-4} s={8} /><text x={14} y={0} className="t-tiny">{`a wrong version: smallest error ${M.leastWrong === null ? '—' : sci(M.leastWrong)}`}</text></g>
        <text x={8} y={ay + 64} className="t-mono t-tiny" data-rate-predicted={R.predicted} data-rate-stored={R.storedPredicted ?? ''} data-rate-measured={R.measured ?? ''}>
          {`tennis racket, inertias 5, 3, 1: rate ${R.predicted.toFixed(6)} predicted · ${Number.isFinite(R.measured) ? R.measured.toFixed(6) : '—'} measured`}
        </text>
      </FigSvg>
    </div>
  );
}
ForqueLines.meta = { id: 'forque-lines', lenses: D37_LENSES, learner: false };
ForqueLines.data = (params = {}) => {
  const S = params.stored || null, L = linesLadder(S ? S.forque.rows : [], { top: params.top === true });
  return { ladder: L.rungs.map(g => ({ d: g.d, I: g.I, squareI: g.squareI, squareO: g.squareO, lines: g.lines.map(l => ({ line: l.key, at: l.at })) })), check: matrixCheck(S ? S.forque_matrix : null), racket: racketRate(S ? S.forque_matrix : null) };
};
ForqueLines.params = [{}, { top: true }];
