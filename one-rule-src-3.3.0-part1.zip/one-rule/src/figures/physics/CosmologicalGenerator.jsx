// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure cosmological-generator (step 10, GRV-007; docs/PHYSICS_AUDIT.md E3): the cosmological term as one more generator. The n frame axes round a circle (a filled
// node squares to +1, a hollow one to −1), the extra generator e in the middle (filled for e² = +1, hollow for −1), a spoke P_a = γ_a e for each axis with its
// square; the spokes of t and x are drawn heavy and the chord between them is their commutator, [P_t, P_x] = −2s γ_t γ_x, with the constant computed by the kernel
// (engines/physics/gravity.js cosmological). Half of it is k = −s, the coefficient of e∧e in the curvature R + k e∧e; the torsion keeps the coefficient μ = 1.
// Beside it the table of what gravity_selfcheck.py stored (exact, gravity.json desitter, n = 3, 4) and gravity_matrix_check.py (numpy, gravity_matrix.json
// desitter, n = 3 … 5), a rung the exact check did not run marked "not stored" (D37), and the wrong version the matrix check runs (the extra square flipped:
// k changes sign). Research level only, as the table of the de Sitter term was (inside "For older readers"). The chips are the rows of that table; "from the
// top" (D37) starts at n = 5 and shows each lower n inside it.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, r1, pick, isIn } from '../kit.jsx';
import { cosmological } from '../../../engines/physics/gravity.js';
import { useStored, peekStored, Tex, useKatex, printing, printLabel, TopToggle, Table, Fold, Loading, D37_LENSES, signed } from './p8kit.jsx';

const NSC = [3, 4, 5], SS = [-1, 1], TOP = 5, C = [130, 112], RAD = 84;
const sq = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');

export default function CosmologicalGenerator({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner', how = printing(lens, mode, level);
  const init = () => ({ n: pick(params.n, isIn(NSC), 4), s: pick(params.s, isIn(SS), -1), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.n, params.s, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { n, s, top } = st, set = p => setSt(x => ({ ...x, ...p }));
  const katex = useKatex(research), S = useStored(), shown = top ? TOP : n, K = cosmological(shown, s), own = cosmological(n, s);
  const pos = k => [C[0] + RAD * Math.cos((-90 + 360 * k / shown) * Math.PI / 180), C[1] + RAD * Math.sin((-90 + 360 * k / shown) * Math.PI / 180)];
  const nm = k => printLabel(1 << k, how, shown), key = `${n},${s < 0 ? 'dS' : 'AdS'}`, ex = S ? S.gv.desitter[key] : null, mx = S ? S.gvm.desitter[key] : null;
  return (
    <div className="fig fig-cosmological-generator">
      <FigSvg id="cosmological-generator" row={row} viewBox="0 0 420 236">
        <g data-n={n} data-s={s} data-top={top ? 1 : 0} data-coef={own.coef} data-k={own.k} data-mu={own.mu}>
          {K.squares.map((q, a) => {
            const p = pos(a), heavy = a < 2, off = a >= n, m = [(p[0] + C[0]) / 2, (p[1] + C[1]) / 2];
            return (
              <g key={'s' + a} className={off ? 'gp-faint' : undefined} data-spoke={a} data-spoke-square={q}>
                <title>{`P = γ e for ${nm(a)}: square ${sq(q)}`}</title>
                <line x1={r1(p[0])} y1={r1(p[1])} x2={C[0]} y2={C[1]} className="stroke-ink" style={{ strokeWidth: heavy ? 2.6 : 1.1 }} />
                <text x={r1(m[0] + 5)} y={r1(m[1] - 4)} className="t-mono t-tiny">{sq(q)}</text>
              </g>
            );
          })}
          {(() => { const p = pos(0), q = pos(1); return <g data-chord="0,1"><line x1={r1(p[0])} y1={r1(p[1])} x2={r1(q[0])} y2={r1(q[1])} className="stroke-ink" style={{ strokeWidth: 2, strokeDasharray: '6 3' }} /><text x={r1((p[0] + q[0]) / 2 + 6)} y={r1((p[1] + q[1]) / 2 - 6)} className="t-mono t-small t-bold">{`${signed(K.coef)} · ${printLabel(3, how, shown)}`}</text></g>; })()}
          {Array.from({ length: shown }, (_, a) => {
            const p = pos(a), right = p[0] >= C[0], plus = a === 0;
            return (
              <g key={'n' + a} className={a >= n ? 'gp-faint' : undefined} data-axis={a}>
                <circle cx={r1(p[0])} cy={r1(p[1])} r={7} className={plus ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} />
                <text x={r1(p[0] + (right ? 11 : -11))} y={r1(p[1] + 4)} textAnchor={right ? 'start' : 'end'} className="t-mono t-small">{nm(a)}</text>
              </g>
            );
          })}
          <circle cx={C[0]} cy={C[1]} r={9} className={s > 0 ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 2 }} data-extra={s} />
          <text x={C[0] + 10} y={C[1] + 20} className="t-mono t-small">e</text>
          <g transform="translate(250, 30)" className="t-small">
            <text x={0} y={0} className="t-bold">{K.group}</text>
            <text x={0} y={18} className="t-mono">{`e² = ${sq(s)} · k = −s = ${signed(own.k)}`}</text>
            <text x={0} y={36} className="t-mono">{`μ = ${own.mu} · ${own.generators} generators`}</text>
            <text x={0} y={54} className="t-mono">{`${own.curvature_components} curvature components`}</text>
            <circle cx={4} cy={80} r={5} className="ink" style={{ stroke: 'var(--fg)' }} /><text x={14} y={84} className="t-tiny">square +1</text>
            <circle cx={78} cy={80} r={5} className="on-panel" style={{ stroke: 'var(--fg)' }} /><text x={88} y={84} className="t-tiny">square −1</text>
            <line x1={0} y1={100} x2={22} y2={100} className="stroke-ink" style={{ strokeWidth: 2, strokeDasharray: '6 3' }} /><text x={28} y={104} className="t-tiny">the commutator of two spokes</text>
          </g>
        </g>
      </FigSvg>
      <Controls label="one more generator">
        <Chips label="n" items={NSC} value={n} onPick={v => set({ n: v })} param="n" mono />
        <Chips label="e²" items={SS} value={s} onPick={v => set({ s: v })} render={v => `${sq(v)} ${v < 0 ? 'de Sitter' : 'anti-de Sitter'}`} param="s" />
        <TopToggle on={top} onChange={v => set({ top: v })} research={research} top={TOP} />
      </Controls>
      <p className="gp-read" data-line="commutator"><Tex katex={katex} tex={`[P_a, P_b] = -2s\\,\\gamma_a\\gamma_b = ${own.coef}\\,\\gamma_a\\gamma_b`} text={`[P_a, P_b] = −2s γ_a γ_b = ${own.coef} γ_a γ_b`} /><Tex katex={katex} tex={`F = R + k\\,e\\wedge e,\\ k = -s = ${own.k},\\quad \\mu = ${own.mu}`} text={`F = R + k e∧e, k = −s = ${own.k} · μ = ${own.mu}`} /></p>
      {S ? (
        <>
          <Fold title={`The table, n = ${top ? '5 … 3' : '3 … 5'}: exact and with matrices`} name="desitter">
            <Table name="desitter" caption="gravity.json desitter (exact) · gravity_matrix.json desitter (numpy)" cols={[['n', 'n'], ['sq', 'e²'], ['g', 'group'], ['k', 'k'], ['mu', 'μ'], ['km', 'k (numpy)'], ['mm', 'μ (numpy)']]}
              rows={(top ? [...NSC].reverse() : NSC).flatMap(k => SS.map(v => { const kk = `${k},${v < 0 ? 'dS' : 'AdS'}`, e = S.gv.desitter[kk], m = S.gvm.desitter[kk]; return { key: kk, cur: k === n && v === s, cells: { n: k, sq: sq(v), g: e ? e.group : (v < 0 ? 'de Sitter' : 'anti-de Sitter'), k: e ? e.coefficient_of_e_wedge_e : null, mu: e ? e.coefficient_of_torsion : null, km: m ? m.k : null, mm: m ? m.mu : null } }; }))} />
          </Fold>
          <p className="gp-read" data-control={S.gvm.controls.extra_square_sign_flipped}><span className="gp-k">wrong version, the extra square flipped:</span> <b>{S.gvm.controls.extra_square_sign_flipped}</b> <span className="gp-k">{ex ? `stored here: k = ${ex.coefficient_of_e_wedge_e}` : mx ? `stored here (matrices): k = ${mx.k}` : ''}</span></p>
        </>
      ) : <Loading />}
    </div>
  );
}
CosmologicalGenerator.meta = { id: 'cosmological-generator', lenses: D37_LENSES, learner: false };
CosmologicalGenerator.params = [{}, { s: 1 }, { n: 3, s: 1 }, { n: 5, s: -1 }, { n: 3, top: true }];
/** the numbers the figure draws, for the frame's data download */
CosmologicalGenerator.data = (params = {}) => {
  const n = pick(params.n, isIn(NSC), 4), s = pick(params.s, isIn(SS), -1), S = peekStored(), key = `${n},${s < 0 ? 'dS' : 'AdS'}`;
  return { ...cosmological(n, s), stored: S ? { exact: S.gv.desitter[key] || null, matrices: S.gvm.desitter[key] || null } : null };
};
