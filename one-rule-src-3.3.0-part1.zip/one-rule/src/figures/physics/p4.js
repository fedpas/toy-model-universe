// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p4.js — owner P4 registers its figures here (id → component): maxwell-ladders (caption PAG-011, the ladders of Calibration 1).
// The other figure of P4's scope, charges, keeps its registration in src/figures/index.js.
import MaxwellLadders from './MaxwellLadders.jsx';
export const P4_FIGURES = { 'maxwell-ladders': MaxwellLadders };
