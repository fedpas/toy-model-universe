// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure rigid-matrix (step 16; caption row RIG-001; docs/PHYSICS_AUDIT.md RB5, D35): the 56 lines of the rigid body's matrix, v15's "The checks, one row at a
// time", drawn with the shared TranslationMatrix (P6). Each line is a row of the Atlas, RIG-M01 … RIG-M56 (content/physics/rows.p11.json, kind reading): its
// two columns are the claim and how it is checked, the author's words (texts.p11.json, "<claim> ↔ <how>"), printed from the row's text record once the rows are
// merged (P12; until then the line shows its id, data and status, and no words: no sentence without its record, D26); its badge is the row's computed status
// (it cites pgadyn_selfcheck, which ran). The data of each line is pgadyn.json's (content/stored_p11.json): the number of claims and whether all hold
// (rows[].checks, .ok), and the summary
// (56 rows, 110 claims, 110 hold). v15's classification of the lines is kept as it printed it (rigidCopy.js ROW_META, STATUS, CONTROLS): the rung it belongs to
// (the thread chips), the kind of check (checked, plausibility only, cross-checked, observation: the status chips and the strip's marks), standard or ours,
// and the negative controls. Research level only.
import React from 'react';
import TranslationMatrix from './TranslationMatrix.jsx';
import { useStoredP11, Ok, KV } from './rigidParts.jsx';

// v15's threads of step 16 in the page's order, named by the first words of their headings (short enough for the strip's label column)
export const THREADS = [['segment', 'The segment'], ['square', 'The square'], ['cube', 'The cube'], ['hang', 'Hang it'], ['frame', 'The frame'], ['top', 'The free top'], ['orbits', 'Moon and planets']];
const THREAD_OF = { segment: 'A6 B1 B2 B3 B4', square: 'C1 E9 N7', cube: 'A1 A2 A3 A4 A5 D1 D2 D3 D4 E1 E2 E3 E6 F1 F2 R1 R2', hang: 'E4 E5 E7 E8 E10 E11 E12 R3 R4 R5 R6', frame: 'A7 G1 G2 G3 G4 G5', top: 'T1 T2 T3 R7 R8', orbits: 'N1 N2 N3 N4 N5 N6 N8 N9 R9' };
const OURS = new Set('A1 A3 A5 B4 E11 G1 G2 G3 G4 G5 R8'.split(' '));
const CONTROLS = new Set('A5 B4 E2 E5 E11 E12 N1 N3 N4 T2'.split(' '));
const STATUS_OF = { N9: 'plaus', R1: 'ref', R2: 'ref', R3: 'ref', R4: 'ref', R5: 'ref', R6: 'ref', R7: 'ref', R9: 'ref', R8: 'obs' };
export const STATUS_WORDS = { ok: 'checked', plaus: 'plausibility only', ref: 'cross-checked', obs: 'observation' };
const nat = id => id.charCodeAt(0) * 100 + Number(id.slice(1));
/** the 56 lines in the order of the v15 page, each with its row id and v15's classification */
export const LINES = Object.entries(THREAD_OF).flatMap(([thread, ids]) => ids.split(' ').map(id => ({ id, thread }))).sort((a, b) => nat(a.id) - nat(b.id))
  .map((l, i) => ({ ...l, row: `RIG-M${String(i + 1).padStart(2, '0')}`, source: OURS.has(l.id) ? 'ours' : 'standard', status: STATUS_OF[l.id] || 'ok', control: CONTROLS.has(l.id) }));

/** the rows TranslationMatrix draws: v15's classification and the stored claims and verdict of each line (its words are its row's text record) */
export function matrixRows(S) {
  const stored = new Map((S && Array.isArray(S.rows) ? S.rows : []).map(l => [l.id, l]));
  return LINES.map(l => {
    const s = stored.get(l.id);
    return {
      id: l.id, badgeRow: l.row, status: l.status, group: l.thread, left: '', right: '',
      ref: s ? `${s.checks} ${s.checks === 1 ? 'claim' : 'claims'}` : undefined,
      detail: [['claims', s ? `${s.checks}, ${s.ok ? 'all hold ✓' : 'not all hold ✗'}` : null, 'claims'], ['source', l.source, 'source'], l.control ? ['negative control', 'yes', 'control'] : null].filter(Boolean),
    };
  });
}

export default function RigidMatrix({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const S = useStoredP11(), sum = S && S.summary;
  return (
    <div className="fig fig-rigid rg-mx">
      {sum ? (
        <p className="fig-readout rg-sum" data-rows={sum.rows} data-checks={sum.checks} data-ok={sum.ok}>
          <KV k="rows">{sum.rows}</KV><KV k="claims">{sum.checks}</KV><KV k="hold">{sum.ok}</KV><Ok ok={sum.ok === sum.checks} yes="all hold" no="not all hold" />
        </p>
      ) : null}
      <TranslationMatrix rows={matrixRows(S)} title="The checks, one row at a time" level={level} lens={lens} mode={mode} figId="rigid-matrix" row={row}
        columns={{ left: 'claim', right: 'how it is checked' }} statusWords={STATUS_WORDS} groups={THREADS.map(([key, name]) => ({ key, name }))}
        initial={{ status: params.status, group: params.thread, open: params.open, badges: params.badges }} />
    </div>
  );
}
RigidMatrix.meta = { id: 'rigid-matrix', lenses: [], learner: false };
RigidMatrix.params = [{}, { thread: 'frame', open: 'G5' }, { status: 'ref', badges: true }, { thread: 'top', status: 'obs', open: 'R8' }];
/** the lines the figure draws (the stored claims are content/stored_p11.json) */
RigidMatrix.data = () => ({ lines: LINES.map(l => ({ id: l.id, row: l.row, thread: l.thread, source: l.source, status: l.status, control: l.control })) });
