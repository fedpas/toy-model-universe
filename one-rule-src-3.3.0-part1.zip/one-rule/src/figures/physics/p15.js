// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p15.js — round 17 (proofs pass 13c, docs/round17/PROOFS_ROUND13C.md) registers its figure here (id → component): weil-index
// (caption row LAB-028), in the section clock of the page clock by its caption row. Seed in content/physics/figures.p15.json; the engine
// engines/physics/weilIndex.js; the test tests/physics/p15.test.mjs. src/figures/physics/index.js spreads this registry, so the figure rides in
// dist/figures-extra.js (D47).
import WeilIndex from './WeilIndex.jsx';
export const P15_FIGURES = { 'weil-index': WeilIndex };
