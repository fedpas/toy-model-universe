// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure maxwell-ladders (caption PAG-011; owner P4, docs/PHYSICS_AUDIT.md §2.1 MX6–MX10, decisions D29 and D37): the ladders of Calibration 1.
// The drawing is D37's ladder through the chosen cell: ten rungs, one to ten generators, from the lowest stored cell Cl(1,0) up the space line to Cl(1, d),
// then along time to Cl(k, d), then on (engines/physics/maxwellLadders.js chainOf). Each rung shows the cell the store holds there (a cell of maxwell.json or
// a row of its two ladders) with two bars: the components of F by role (E filled, T grey, B an outline: shape and word, never colour alone) and the equations
// of ∇F = J (δF = J filled, dF = 0 dashed), every number as stored; a rung the store lacks is drawn empty and marked "not stored". The lens picker of the
// frame (Clifford, simplex, cube, demicube, prime labels) reads every rung in its lens (the algebra and its blades, the simplex, the cube's corners, the even
// and odd halves, the primes: lensCounts, through the kernel). "From the top" starts at the highest stored rung and reads each lower rung as what the top
// keeps on its generators (keptOf; tests/physics/p4.test.mjs checks that it is the lower cell as stored). Beside the drawing, at research level, the strip of
// the chosen cell (MX6: algebra, generators, blades, I², central, split, the wave operator's class, read from the store and recomputed through the kernel),
// F written out (KaTeX), what the step adds with ★ on the new equations (MX7, MX3), the lines of six and seven generators (MX8), and, folded, the two
// stored ladders with the chosen row lit and the period (MX9); at learner level the same counts in words, the step as a readout and "period 8 · grid × 16"
// (MX10; the 8 is dictionary.json's why8, read from content/stored_p4.json). No sentence that no row states; the controls are v15's time and space chips
// and D37's switch.
import React, { useEffect, useState } from 'react';
import { chainOf, topOf, keptOf, stepTo, kernelAlgebra, storedCell, lensCounts, ladderRows, periodOf, algebraLabel, RUNGS } from '../../../engines/physics/maxwellLadders.js';
import { cellPhysics, roleName, nameAt, parseTerms, texName } from '../../../engines/maxwellPhysics.js';
import { bitsOf } from '../../../engines/labels.js';
import { useKatex, texToHtml } from '../../app/math.js';
import { useTable } from '../../app/content.js';
import { FigSvg, Controls, Toggle, r1, sub } from '../kit.jsx';
import { useCell, CellChips, cellOfParams } from '../MaxwellEquations.jsx';
import '../maxwell.css';
import './p4.css';

const subM = s => s.replace(/M(\d+)/g, (_, m) => 'M' + sub(m));
/** the algebra as printed: M₂(ℍ), M₄(ℝ) ⊕ M₄(ℝ), ℝ ⊕ ℝ */
const alg = al => subM(algebraLabel(al));
const pm = v => (v > 0 ? '+1' : '−1');
const yesNo = v => (v ? 'yes' : 'no');
/** a page lens as this figure reads it (the label lenses go with their shapes) */
const LENS = { clifford: 'clifford', simplex: 'simplex', cube: 'cube', bits: 'cube', demicube: 'demicube', prime: 'prime', primes: 'prime' };
/** the words of the two bars in a lens: [the components of F, the equations] */
const LENS_WORDS = {
  clifford: { research: ['bivectors, grade 2', 'vectors and trivectors, grades 1 and 3'], learner: ['two switches each', 'one or three switches'] },
  simplex: { research: ['edges', 'vertices and triangles'], learner: ['lines', 'dots and triangles'] },
  cube: { research: ['corners with two 1s', 'corners with one or three 1s'], learner: ['corners with two 1s', 'corners with one or three 1s'] },
  demicube: { research: ['even corners, two 1s', 'odd corners, one or three 1s'], learner: ['even corners, two 1s', 'odd corners, one or three 1s'] },
  prime: { research: ['products of two primes', 'primes and products of three'], learner: ['products of two primes', 'primes and products of three'] },
};
const LENS_NAME = { clifford: 'Clifford', simplex: 'simplex', cube: 'cube', demicube: 'demicube', prime: 'prime labels' };
const simplexName = n => ['point', 'segment', 'triangle', 'tetrahedron'][n - 1] || `${n - 1}-simplex`;
const cubeName = n => ['segment', 'square', 'cube'][n - 1] || `${n}-cube`;
const FIELD_WORD = { R: 'real', R2: 'real', C: 'complex', H: 'quaternion', H2: 'quaternion' };
/** the algebra in words (learner): "2 × 2 quaternion grid", "two 8 × 8 real grids", "two real numbers" */
function algebraWords(al) {
  const two = /2$/.test(al.type), w = FIELD_WORD[al.type], N = al.matrix_size;
  if (N === 1) return `${two ? 'two ' : ''}${w} number${two ? 's' : ''}`;
  return `${two ? 'two ' : ''}${N} × ${N} ${w} grid${two ? 's' : ''}`;
}
const cellName = (r, research) => (research ? `Cl(${r.k},${r.d})` : `${r.k} time · ${r.d} space`);

/** the reading of a stored rung in a lens (the second line of the rung), and its long form for the tooltip */
export function readingOf(lens, r, level) {
  const research = level !== 'learner', L = lensCounts(r.k, r.d), al = r.S.algebra, A = alg(al), last = L.primes[L.primes.length - 1];
  switch (lens) {
    case 'clifford': return { short: research ? `≅ ${A} · ${L.corners} blades` : algebraWords(al), long: `${L.corners} blades: ${L.plus} of square +1, ${L.minus} of square −1` };
    case 'simplex': return { short: research ? simplexName(r.n) : r.n === 1 ? '1 dot' : `${r.n} dots, all joined`, long: `${simplexName(r.n)}: ${L.vertices} vertices · ${L.edges} edges · ${L.triangles} triangles` };
    case 'cube': return { short: research ? `${cubeName(r.n)} · ${L.corners} corners` : `${L.corners} corners`, long: `${cubeName(r.n)}: layers ${L.layers.join(' ')}` };
    case 'demicube': return { short: `${L.even} even · ${L.odd} odd`, long: `${L.even} even corners · ${L.odd} odd corners` };
    case 'prime': return { short: research ? (r.n <= 4 ? L.primes.join('·') : `primes 2 … ${last}`) : r.n === 1 ? 'prime 2' : `primes 2 to ${last}`, long: `${L.primes.join('·')} = ${L.product}` };
    default: return { short: research ? `≅ ${A}` : '', long: research ? `Cl(${r.k},${r.d}) ≅ ${A}` : algebraWords(al) };
  }
}

// ---------------------------------------------------------------- the ladder
const W = 440, RH = 30, HEAD = 30, X = { n: 6, cell: 34, bars: 150, BW: 146, num: 302, step: 362 };
const H = HEAD + RUNGS * RH + 6;
function Bar({ y, parts, s, x0 = X.bars }) {
  let x = x0;
  return parts.map(([v, cls, key]) => { const w = v * s, el = w > 0 ? <rect key={key} x={r1(x)} y={r1(y)} width={r1(Math.max(w, 1))} height={7} className={cls} data-part={key} data-n={v} /> : null; x += w; return el; });
}
function Ladder({ chain, top, cur, lens, level, row, fromTop }) {
  const research = level !== 'learner', T = chain[top], s = X.BW / Math.max(1, T.S.total), yOf = n => HEAD + (RUNGS - n) * RH;
  const yTop = yOf(T.n) + 15, yBot = yOf(1) + 15;
  return (
    <FigSvg id="maxwell-ladders" row={row} part={`the ladder through Cl(${chain[cur].k},${chain[cur].d}), ${fromTop ? `from the top, Cl(${T.k},${T.d}), down` : 'from Cl(1,0) up'}${lens ? `, in the ${LENS_NAME[lens]} lens` : ''}`} viewBox={`0 0 ${W} ${H}`}>
      <text x={X.n} y={18} className="t-small t-muted">{research ? 'n' : 'in all'}</text>
      <text x={research ? X.cell : X.cell + 8} y={18} className="t-small t-muted">{research ? 'cell' : 'time · space'}</text>
      <text x={X.bars} y={18} className="t-small t-muted">{research ? 'F · ∇F = J' : 'field pieces · equations'}</text>
      <text x={X.step} y={18} className="t-small t-muted">step</text>
      <line x1={26} y1={yBot} x2={26} y2={yTop} className="p4-rail" />
      <path d={fromTop ? `M26 ${r1(yBot + 6)} l-4 -7 h8 z` : `M26 ${r1(yTop - 6)} l-4 7 h8 z`} className="ink" data-direction={fromTop ? 'down' : 'up'} />
      {chain.map((r, i) => {
        const y = yOf(r.n), S = r.S, isCur = i === cur, isTop = i === top, below = i < top;
        const K = fromTop && S ? keptOf(T, r) : null, V = K || S, prev = i > 0 ? chain[i - 1].S : null, rd = S ? readingOf(lens, r, level) : null;
        const stepWord = fromTop ? (isTop ? 'top' : below && chain[i + 1] ? (research ? `− ${chain[i + 1].gen || chain[i + 1].kind}` : `−1 ${chain[i + 1].kind}`) : '')
          : (i === 0 ? 'start' : research ? `+ ${r.gen || r.kind}` : `+1 ${r.kind}`);
        const title = !S ? `${research ? `Cl(${r.k},${r.d})` : `${r.k} time, ${r.d} space`}: not stored`
          : research ? `Cl(${r.k},${r.d}) ≅ ${alg(S.algebra)} · F ${S.F} = ${S.E} E + ${S.T} T + ${S.B} B · ∇F = J ${S.vector} + ${S.trivector} = ${S.total}${lens ? ` · ${rd.long}` : ''}`
            : `${r.k} time, ${r.d} space · ${S.F} field pieces · ${S.total} equations${lens ? ` · ${rd.long}` : ''}`;
        const data = S ? { 'data-f': S.F, 'data-e': S.E, 'data-t': S.T, 'data-b': S.B, 'data-vec': S.vector, 'data-tri': S.trivector, 'data-eqs': S.total } : {};
        const kept = K ? { 'data-kept': [K.F, K.E, K.T, K.B, K.vector, K.trivector, K.total].join(','), 'data-dropped': K.dropped.join(' ') } : {};
        return (
          <g key={r.n} data-rung={r.n} data-cell={`${r.k},${r.d}`} data-stored={S ? S.from : 'none'} {...data} {...kept} data-current={isCur ? 1 : undefined} data-top={isTop ? 1 : undefined} data-lens-reading={rd ? rd.short : undefined}>
            <title>{title}</title>
            {isCur ? <rect x={2} y={r1(y + 1)} width={W - 4} height={RH - 2} rx={4} className="p4-cur" /> : null}
            <text x={X.n} y={r1(y + 19)} className={'t-mono' + (isCur ? ' t-bold' : '')}>{r.n}</text>
            <text x={X.cell} y={r1(y + 12)} className={'t-mono' + (S ? '' : ' t-muted') + (isCur ? ' t-bold' : '')} style={{ fontSize: research ? '11.5px' : '10.5px' }}>{cellName(r, research)}</text>
            {rd && rd.short ? <text x={X.cell} y={r1(y + 25)} className="t-muted" style={{ fontSize: '9.5px' }}>{rd.short}</text> : null}
            {S ? (
              <g data-bars={r.n}>
                {fromTop && below ? <><rect x={X.bars} y={r1(y + 5)} width={r1(Math.max(1, T.S.F * s))} height={7} className="p4-ghost" /><rect x={X.bars} y={r1(y + 16)} width={r1(T.S.total * s)} height={7} className="p4-ghost" /></> : null}
                <Bar y={y + 5} s={s} parts={[[V.E, 'p4-e', 'E'], [V.T, 'p4-t', 'T'], [V.B, 'p4-b', 'B']]} />
                <Bar y={y + 16} s={s} parts={[[V.vector, 'p4-v', 'vec'], [V.trivector, 'p4-w', 'tri']]} />
                {!fromTop && prev && prev.F > 0 ? <line x1={r1(X.bars + prev.F * s)} y1={r1(y + 3)} x2={r1(X.bars + prev.F * s)} y2={r1(y + 14)} className="p4-tick" /> : null}
                {!fromTop && prev ? <line x1={r1(X.bars + prev.total * s)} y1={r1(y + 14)} x2={r1(X.bars + prev.total * s)} y2={r1(y + 25)} className="p4-tick" /> : null}
                <text x={X.num} y={r1(y + 12)} className="t-mono" style={{ fontSize: '10px' }}>{fromTop && below ? `${V.F} of ${T.S.F}` : String(V.F)}</text>
                <text x={X.num} y={r1(y + 24)} className="t-mono" style={{ fontSize: '10px' }}>{fromTop && below ? `${V.total} of ${T.S.total}` : String(V.total)}</text>
              </g>
            ) : (
              <g data-empty={r.n}>
                <rect x={X.bars} y={r1(y + 4)} width={X.BW} height={RH - 8} rx={3} className="p4-empty" />
                <text x={X.bars + X.BW / 2} y={r1(y + 19)} textAnchor="middle" className="t-muted p4-ns">not stored</text>
              </g>
            )}
            {S ? <text x={X.step} y={r1(y + 12)} className="t-mono" style={{ fontSize: '10px' }} data-step={stepWord}>{stepWord}</text> : null}
            {S && !fromTop && prev ? <text x={X.step} y={r1(y + 24)} className="t-mono t-muted" style={{ fontSize: '9.5px' }} data-add={`${S.F - prev.F},${S.total - prev.total}`}>{`+${S.F - prev.F} · +${S.total - prev.total}`}</text> : null}
          </g>
        );
      })}
    </FigSvg>
  );
}

/** the legend of the bars, by mark and word, in the lens's words */
function Legend({ chain, top, lens, level, fromTop }) {
  const research = level !== 'learner', S = chain.filter(r => r.S).map(r => r.S), has = f => S.some(x => x[f] > 0), Lw = lens ? LENS_WORDS[lens][research ? 'research' : 'learner'] : null;
  const key = (cls, dash) => <svg className="p4-key" viewBox="0 0 22 9" aria-hidden="true">{dash ? <line x1={11} y1={0} x2={11} y2={9} className="p4-tick" /> : <rect x={0.5} y={1} width={21} height={7} className={cls} />}</svg>;
  const items = [
    has('E') && ['E', key('p4-e'), research ? 'E' : null, roleName('E', level)],
    has('T') && ['T', key('p4-t'), research ? 'T' : null, roleName('T', level)],
    has('B') && ['B', key('p4-b'), research ? 'B' : null, roleName('B', level)],
    ['vec', key('p4-v'), research ? 'δF = J' : null, research ? 'with a source' : 'equations with a charge or a current'],
    has('trivector') && ['tri', key('p4-w'), research ? 'dF = 0' : null, research ? 'zero on the right' : 'equations with zero'],
    fromTop ? ['ghost', key('p4-ghost'), null, `${research ? `Cl(${chain[top].k},${chain[top].d})` : 'the top'}, kept on fewer generators`] : ['tick', key(null, true), null, research ? 'the rung below' : 'one step down'],
  ].filter(Boolean);
  return (
    <ul className="mx-legend p4-legend" aria-label={research ? 'the marks of the ladder' : 'what the marks mean'} data-legend-lens={lens || ''}>
      {items.map(([k, icon, b, w]) => <li key={k} data-key={k}>{icon}{b ? <b>{b}</b> : null}<span>{w}</span></li>)}
      {Lw ? <li data-key="lens" data-lens-words={`${Lw[0]} | ${Lw[1]}`}><span>{`${LENS_NAME[lens]}: ${research ? 'F' : 'field pieces'} = ${Lw[0]} · ${research ? '∇F = J' : 'equations'} = ${Lw[1]}`}</span></li> : null}
    </ul>
  );
}

// ---------------------------------------------------------------- the card of the chosen cell
function Tex({ tex, text, katex }) {
  const html = katex ? texToHtml(tex) : null;
  return html ? <span className="p4-tex" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span className="p4-tex mx-plain" data-tex={tex}>{text}</span>;
}
/** F of the stored convention, as TeX: F = E_{x}\,\gamma_{0}\gamma_{1} + … (the convention is an input: INP-011) */
export const texF = C => 'F = ' + parseTerms(C.conventions.F).map((t, i) => (i ? (t.sign > 0 ? ' + ' : ' - ') : t.sign > 0 ? '' : '-') + `${texName(t.label)}\\,${bitsOf(t.mask).map(b => `\\gamma_{${b}}`).join('')}`).join('');
const OPS = { contract: { research: 'δF = J · grade 1 · drop a vertex', learner: 'with a charge or a current' }, wedge: { research: 'dF = 0 · grade 3 · add a vertex', learner: 'with zero' } };
function Stars({ st, level }) {
  const research = level !== 'learner';
  return (
    <div className="p4-star" data-star={st.star.map(e => e.id).join(' ')}>
      {['contract', 'wedge'].map(op => { const list = st.star.filter(e => e.op === op); return list.length ? (
        <p key={op} data-star-op={op}><span className="p4-op">{`★ ${OPS[op][research ? 'research' : 'learner']}`}</span>{list.map(e => <span key={e.id} className="p4-eq" data-star-eq={e.id}>{nameAt(e, level)}</span>)}</p>
      ) : null; })}
    </div>
  );
}
function Card({ k, d, level, katex, stored }) {
  const research = level !== 'learner', S = storedCell(k, d), A = kernelAlgebra(k, d), st = stepTo(k, d), C = cellPhysics(k, d), n = k + d, al = S.algebra, sy = S.symbol;
  const why8 = stored && stored.dictionary && stored.dictionary.why8, per = periodOf(), M = storedCell(d, k), mi = C.mirror;
  const big = n >= 6 ? ['2,4', '3,3', '4,2', '3,4', '4,3'].map(x => storedCell(...x.split(',').map(Number))) : [];
  if (!research) {
    return (
      <div className="p4-card" data-card={`${k},${d}`}>
        <p data-learner-head={`${n},${2 ** n},${S.F},${S.total}`}>{`${n} directions: ${k} time, ${d} space · ${2 ** n} corners · ${S.F} field pieces · ${S.total} equations`}</p>
        <p data-learner-step={`${st.blades.join(',')},${st.F.join(',')},${st.eqs.join(',')}`}>{`new: one more ${st.kind} direction · corners ${st.blades[0]} → ${st.blades[1]} · field pieces ${st.F[0]} → ${st.F[1]} · equations ${st.eqs[0]} → ${st.eqs[1]}`}</p>
        <Stars st={st} level={level} />
        {why8 && per ? <p data-period={`${why8.minimal_period},${per.ratio}`}>{`period ${why8.minimal_period} · grid × ${per.ratio}`}</p> : null}
        {k !== d ? <p data-learner-mirror={`${mi.vector_equations_factor},${mi.triple_equations_factor}`}>{`mirror: ${d} time, ${k} space · charge side: ${mi.vector_equations_factor < 0 ? 'sign flipped' : 'unchanged'} · zero side: ${mi.triple_equations_factor < 0 ? 'sign flipped' : 'unchanged'}`}</p> : null}
        <p data-learner-signs={C.conventions.found}>{`sign choices that work: ${C.conventions.found}, differing by an overall sign`}</p>
      </div>
    );
  }
  const strip = `Cl(${k},${d}) ≅ ${alg(al)} · ${n} generators · ${2 ** n} blades · I² = ${pm(al.pseudoscalar_square)} · central: ${yesNo(al.pseudoscalar_central)}${al.splits_in_two ? ' · splits in two, (1 ± I)/2' : ''} · ${sy.class}${sy.well_posed_along ? `, well posed along ${sy.well_posed_along} (PAG-034)` : ''}`;
  const roles = [st.add.E ? `${st.add.E} E` : null, st.add.T ? `${st.add.T} T` : null, st.add.B ? `${st.add.B} B` : null].filter(Boolean).join(', ');
  return (
    <div className="p4-card" data-card={`${k},${d}`}>
      <p className="p4-strip" data-strip={[al.type, al.matrix_size, al.pseudoscalar_square, al.pseudoscalar_central, al.splits_in_two, sy.class, sy.well_posed_along || ''].join(',')} data-kernel={[A.type, A.matrixSize, A.I2, A.central, A.splits, A.class, A.wellPosedAlong || ''].join(',')}>{strip}</p>
      <details data-fold="F">
        <summary>F written out <span className="mx-tag">convention · INP-011</span></summary>
        <div className="fig-scroll p4-f"><Tex tex={texF(C)} text={`F = ${C.conventions.F}`} katex={katex} /></div>
      </details>
      <div className="p4-step" data-step-card={`${st.from.join(',')}>${k},${d}`}>
        <h4 className="mx-eqhead">what this step adds</h4>
        <p data-step-gen={`${st.gen},${st.kind},${st.square}`}>{`new generator ${st.gen}: ${st.kind} (square ${pm(st.square)}) · from Cl(${st.from[0]},${st.from[1]})`}</p>
        <p data-step-counts={[...st.blades, ...st.F, st.add.E, st.add.T, st.add.B, ...st.eqs, st.addEq.vector, st.addEq.trivector].join(',')}>{`blades ${st.blades[0]} → ${st.blades[1]} · F ${st.F[0]} → ${st.F[1]} (+${st.F[1] - st.F[0]}: ${roles}) · ∇F = J ${st.eqs[0]} → ${st.eqs[1]} (+${st.eqs[1] - st.eqs[0]}: ${st.addEq.vector} δF = J, ${st.addEq.trivector} dF = 0)`}</p>
        <p data-step-algebra={`${st.I2.join(',')},${st.cls.map(c => c || '').join(',')}`}>{`${subM(st.algebra[0])} → ${subM(st.algebra[1])} · I² ${pm(st.I2[0])} → ${pm(st.I2[1])} · ${st.cls[0] || 'class not stored'} → ${st.cls[1]}`}</p>
        <Stars st={st} level={level} />
      </div>
      {big.length ? (
        <div className="p4-big" data-big={`${k},${d}`}>
          <p data-big-counts={[S.F, S.E, S.T, S.B, S.vector, S.trivector, S.total, S.incidences].join(',')}>{`F: ${S.F} = ${S.E} E + ${S.T} T + ${S.B} B · ∇F = J: ${S.vector} + ${S.trivector} = ${S.total} equations · ${S.incidences} incidences`}</p>
          {k === d ? <p data-big-mirror="self">{`mirror: Cl(${k},${d}) itself`}</p>
            : <p data-big-mirror={`${M.algebra.type},${M.algebra.pseudoscalar_square},${M.algebra.pseudoscalar_central},${M.algebra.splits_in_two}`}>{`Cl(${k},${d}): ${al.splits_in_two ? 'splits in two' : 'does not split'} · mirror Cl(${d},${k}) ≅ ${alg(M.algebra)} · I² = ${pm(M.algebra.pseudoscalar_square)} · central: ${yesNo(M.algebra.pseudoscalar_central)} · ${M.algebra.splits_in_two ? 'splits in two' : 'does not split'}`}</p>}
          <p data-big-class={[...new Set(big.map(x => x.symbol.class))].join(',')}>{`wave operator of the ${big.length} stored cells with 6 or 7 generators: ${[...new Set(big.map(x => x.symbol.class))].join(', ')}`}</p>
        </div>
      ) : null}
    </div>
  );
}

// ---------------------------------------------------------------- the two stored ladders (research, folded)
function Tables({ k, d, why8 }) {
  const T = ladderRows('time'), S = ladderRows('space'), per = periodOf();
  const i2 = r => `${pm(r.I2)}${r.central ? ' central' : ''}${r.splits ? ' · splits in two' : ''}`;
  return (
    <div className="mx-more p4-more">
      <details data-fold="time">
        <summary>the ladder along time: Cl(k, 1), k = 1 … 9</summary>
        <div className="mx-body">
          <div className="fig-scroll">
            <table className="mx-table" data-ladder="time">
              <thead><tr><th>k</th><th>Cl(k,1)</th><th>mirror Cl(1,k)</th><th>I²</th><th>F = E + T</th><th>∇F</th><th>step adds F / eqs</th><th>wave operator</th></tr></thead>
              <tbody>{T.map(r => { const cur = d === 1 && r.k === k; return (
                <tr key={r.k} className={cur ? 'mx-cur' : undefined} aria-current={cur ? 'true' : undefined} data-row={[r.k, r.algebra, r.mirror, r.I2, r.central, r.splits, r.F, r.E, r.T, r.vector, r.trivector, r.total, r.stepF, r.stepEq, r.cls, r.along || ''].join('|')}>
                  <td>{r.k}</td><td>{subM(r.algebra)}</td><td>{subM(r.mirror)}</td><td>{i2(r)}</td><td>{`${r.F} = ${r.E} + ${r.T}`}</td><td>{`${r.vector} + ${r.trivector} = ${r.total}`}</td><td>{r.k === 1 ? '·' : `+${r.stepF} / +${r.stepEq}`}</td><td>{`${r.cls}${r.along ? ` (${r.along})` : ''}`}</td>
                </tr>); })}</tbody>
            </table>
          </div>
          {per ? <p className="mx-counts" data-period={`${why8 ? why8.minimal_period : ''},${per.from},${per.to},${per.type.join(',')},${per.size.join(',')},${per.ratio}`}>{`period${why8 ? ` ${why8.minimal_period}` : ''}: Cl(${per.from},1) ≅ ${subM(per.algebra[0])} → Cl(${per.to},1) ≅ ${subM(per.algebra[1])}, ${per.steps} steps apart · the same type, the matrix × ${per.ratio} · checked to k = 11 (MAP-006)`}</p> : null}
        </div>
      </details>
      <details data-fold="space">
        <summary>the ladder along space: Cl(1, d), d = 0 … 8</summary>
        <div className="mx-body">
          <div className="fig-scroll">
            <table className="mx-table" data-ladder="space">
              <thead><tr><th>d</th><th>Cl(1,d)</th><th>I²</th><th>F = E + B</th><th>∇F</th></tr></thead>
              <tbody>{S.map(r => { const cur = k === 1 && r.d === d; return (
                <tr key={r.d} className={cur ? 'mx-cur' : undefined} aria-current={cur ? 'true' : undefined} data-row={[r.d, r.algebra, r.I2, r.central, r.splits, r.F, r.E, r.B, r.vector, r.trivector, r.total, r.cl08].join('|')}>
                  <td>{r.d}</td><td>{`${subM(r.algebra)}${r.cl08 ? ' = Cl(0,8) as algebras' : ''}`}</td><td>{i2(r)}</td><td>{`${r.F} = ${r.E} + ${r.B}`}</td><td>{`${r.vector} + ${r.trivector} = ${r.total}`}</td>
                </tr>); })}</tbody>
            </table>
          </div>
        </div>
      </details>
    </div>
  );
}

// ---------------------------------------------------------------- the figure
export default function MaxwellLadders({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const cell = useCell(params);
  const [fromTop, setTop] = useState(params.top === true);
  useEffect(() => { setTop(params.top === true); }, [params.top]);
  const katex = useKatex(research);
  const [stored] = useTable('stored_p4');
  const L = LENS[lens] || null, chain = chainOf(cell.k, cell.d), top = topOf(chain), cur = cell.k + cell.d - 1;
  const why8 = stored && stored.dictionary ? stored.dictionary.why8 : null;
  return (
    <div className="fig fig-p4 p4-ladders" data-cell={`${cell.k},${cell.d}`} data-from-top={fromTop ? 1 : 0} data-lens={L || ''} data-top-cell={`${chain[top].k},${chain[top].d}`}>
      <Ladder chain={chain} top={top} cur={cur} lens={L} level={level} row={row} fromTop={fromTop} />
      <Legend chain={chain} top={top} lens={L} level={level} fromTop={fromTop} />
      <Controls label="Maxwell: the ladder">
        <CellChips cell={cell} research={research} />
        <Toggle label="from the top" on={fromTop} onChange={setTop} param="top" />
      </Controls>
      <Card k={cell.k} d={cell.d} level={level} katex={katex} stored={stored} />
      {research ? <Tables k={cell.k} d={cell.d} why8={why8} /> : null}
    </div>
  );
}
MaxwellLadders.meta = { id: 'maxwell-ladders', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
/** the parameter sets tests/figures.render.test.mjs renders (a spread of the 15 cells, both directions of D37) */
MaxwellLadders.params = [{}, { k: 2, d: 2 }, { k: 3, d: 1, top: true }, { k: 1, d: 4 }, { k: 4, d: 3, top: true }, { k: 2, d: 4 }];
/** the numbers the figure draws, for the frame's data download */
MaxwellLadders.data = (params = {}) => {
  const [k, d] = cellOfParams(params), chain = chainOf(k, d), top = topOf(chain), st = stepTo(k, d);
  return {
    cell: [k, d], fromTop: params.top === true, top: [chain[top].k, chain[top].d],
    rungs: chain.map(r => ({ n: r.n, cell: [r.k, r.d], stored: r.S ? r.S.from : null, ...(r.S ? { F: r.S.F, E: r.S.E, T: r.S.T, B: r.S.B, vector: r.S.vector, trivector: r.S.trivector, total: r.S.total, algebra: algebraLabel(r.S.algebra) } : {}) })),
    algebra: kernelAlgebra(k, d), step: { ...st, star: st.star.map(e => e.name) }, period: periodOf(),
  };
};
