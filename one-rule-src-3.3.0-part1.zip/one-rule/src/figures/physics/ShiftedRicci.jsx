// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure shifted-ricci (Calibration 3, step 7 of `shifted`; caption ATY-052, states ATY-052, ATY-010 and ATY-053; docs/round14/STORY_ROUND.md §6.3, owner
// B3): the three shifted Ricci operators of (3.3a–c), with the Weitzenböck formula D² + ∇² = Ricci, are Ricci + Σⱼ cⱼD^{2j}, the cⱼ exact polynomials in
// κ and τ (se.SER, c₀ … c₃ drawn); at the lowest order Ricci = −c₀ = −κ², κ², 0, and each holds on one space only: anti-de Sitter, de Sitter, flat
// (se.LOW); read on an Einstein metric the roots move by a first-order correction 2μ (μ = κτ) for the first two and not at all for the third (se.ZERO).
// Drawn: the terms up to the order picked, the lowest order with the space it selects (a saddle, a sphere, a plane, with its name), the stored root series.
// The coefficients, the pairing and the roots are the stored ones (content/stored_shifted.json ser, low, zero, loaded on demand: D34); Ricci = −c₀ and
// the correction 2μ (minus the coefficient of κτ in c₁) are computed by engines/physics/shifted.js ricciData and shown beside the stored ratio.
// Controls: the operator (chips), the order of the series (stepper). The learner level names the terms and the spaces in words, without formulas.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Stepper, pick, tx } from '../kit.jsx';
import { Loading } from './fureyKit.jsx';
import { useShifted, peekShifted } from './ShiftedQuarterTurn.jsx';
import { ricciData, poly, polyStr, toQ, qneg } from '../../../engines/physics/shifted.js';

const OPS = ['++', '+-', 'ss'];
const WAY = { '++': 'way 1', '+-': 'way 2', ss: 'way 3' };
const ROWS_LEARN = ['the main term', 'a first correction', 'a second correction', 'a third correction'];
const SPACE_LEARN = { 'anti-de Sitter': 'a saddle-shaped space', 'de Sitter': 'a sphere-like space', 'flat space': 'a flat space' };
/** the stored root series λ/κ² = c₀ + c₁μ + …, as the log prints its coefficients, written out (μ for κτ) */
function seriesStr(cs) {
  return cs.map((c, j) => {
    const q = toQ(c), neg = q.n < 0n, a = neg ? qneg(q) : q, mu = j ? `μ${j > 1 ? `^{${j}}` : ''}` : '';
    const body = a.d === 1n ? `${a.n === 1n && j ? '' : a.n}${mu}` : `${a.n === 1n && j ? '' : a.n}${mu}/${a.d}`;
    return j === 0 ? `${neg ? '−' : ''}${body}` : `${neg ? ' − ' : ' + '}${body}`;
  }).join('') + ' + …';
}
/** a small drawing of the space: a saddle (two sections bending opposite ways), a sphere (with its equator), a plane (a tilted sheet) */
function SpaceIcon({ space, x, y }) {
  if (space === 'anti-de Sitter') {
    // z = u² − v² seen from above and aside: three sections along u (bending up) and three along v (bending down)
    const P = (u, v) => `${(x + 24 * u - 14 * v).toFixed(1)},${(y - 4 + 6 * u + 6 * v - 11 * (u * u - v * v)).toFixed(1)}`;
    const line = f => Array.from({ length: 9 }, (_, i) => f(-1 + i / 4)).join(' ');
    return (
      <g data-icon="saddle">
        {[-1, 0, 1].map(v => <polyline key={'u' + v} points={line(u => P(u, v))} className={v ? 'stroke-muted' : 'stroke-ink'} strokeWidth={v ? 1 : 1.4} />)}
        {[-1, 0, 1].map(u => <polyline key={'v' + u} points={line(v => P(u, v))} className={u ? 'stroke-muted' : 'stroke-ink'} strokeWidth={u ? 1 : 1.4} />)}
      </g>
    );
  }
  if (space === 'de Sitter') return (
    <g data-icon="sphere">
      <circle cx={x} cy={y - 4} r={24} className="stroke-ink" strokeWidth={1.4} />
      <ellipse cx={x} cy={y - 4} rx={24} ry={7} className="stroke-muted" />
    </g>
  );
  return <g data-icon="plane"><path d={`M${x - 40} ${y + 10} L${x - 16} ${y - 18} L${x + 40} ${y - 18} L${x + 16} ${y + 10} Z`} className="stroke-ink" strokeWidth={1.4} /></g>;
}

export default function ShiftedRicci({ params = {}, level = 'research', row }) {
  const research = level !== 'learner';
  const [op, setOp] = useState(pick(params.op, v => OPS.includes(v), '++'));
  const [order, setOrder] = useState(pick(params.order, v => [0, 1, 2, 3].includes(v), 0));
  useEffect(() => { setOp(pick(params.op, v => OPS.includes(v), '++')); setOrder(pick(params.order, v => [0, 1, 2, 3].includes(v), 0)); }, [params.op, params.order]);
  const T = useShifted(params), all = T ? ricciData(T) : null, O = all ? all.find(x => x.op === op) : null;
  const pair = O && O.pair, root = O && O.root, lam = pair && pair.Lambda ? polyStr(poly(pair.Lambda)) : null;
  return (
    <div className="fig fig-shifted-ricci">
      <FigSvg id="shifted-ricci" row={row} viewBox="0 0 460 262">
        <text x={4} y={14} className="t-small t-bold">{research ? 'three shifted Ricci operators, as series in D²' : 'three ways to shift the rule of gravity'}</text>
        {O ? (
          <g data-op={op} data-order={order}>
            <text x={4} y={34} className="t-small">{research ? tx(`${O.name} = ${O.of} + ∇² = Ricci + Σ_j c_j D^{2j}`) : `${WAY[op]}: a main term and corrections`}</text>
            {O.terms.map((t, j) => {
              const shown = j <= order, y = 54 + j * 28;
              return (
                <g key={j} data-term={j} data-shown={shown ? 1 : 0} data-c={O.c[j]}>
                  <rect x={4} y={y} width={272} height={22} rx={4} className="on-panel" style={{ stroke: shown ? 'var(--fg)' : 'var(--line)', strokeDasharray: shown ? undefined : '4 3' }} />
                  <text x={12} y={y + 15} className={'t-tiny' + (shown ? '' : ' t-muted')}>
                    {research ? (shown ? tx(`c_${j}${j ? ` D^${2 * j}` : ''}: ${t}`) : tx(`c_${j}: beyond the order shown`)) : shown ? ROWS_LEARN[j] : `${ROWS_LEARN[j]} (not shown)`}
                  </text>
                </g>
              );
            })}
            <g data-ricci={O.ricci} data-space={pair ? pair.space : ''} data-eq={pair ? pair.eq : ''} data-lambda={pair && pair.Lambda ? pair.Lambda : ''}>
              <rect x={290} y={54} width={166} height={106} rx={6} className="on-panel" style={{ stroke: 'var(--fg)' }} />
              <text x={298} y={70} className="t-tiny t-muted">{research ? 'at the lowest order' : 'the main term picks'}</text>
              <text x={298} y={86} className="t-small t-bold">{research ? tx(`Ricci = ${O.ricci} (${pair ? pair.eq : '?'})`) : pair ? SPACE_LEARN[pair.space] : ''}</text>
              {pair && <SpaceIcon space={pair.space} x={373} y={124} />}
              {pair && <text x={373} y={154} textAnchor="middle" className="t-tiny">{research ? (lam ? tx(`${pair.space}, Λ = ${lam}`) : pair.space) : pair.space}</text>}
            </g>
            <g data-root={root ? root.key : ''} data-correction={root && root.correction ? root.correction : ''} data-stored-correction={root && root.storedCorrection ? root.storedCorrection : ''}>
              <text x={4} y={186} className="t-tiny t-muted">{research ? 'its root on an Einstein metric (Ricci = λ), the zero-mode reading, μ = κτ' : 'and how the delay moves the answer'}</text>
              <text x={4} y={204} className="t-small">
                {root && root.key === 'c' ? (research ? tx('λ_c = 0 to every order computed') : 'this way gets no correction at all')
                  : root ? (research ? tx(`λ/κ^2 = ${seriesStr(root.coefficients)}`) : 'a small correction that grows with the delay') : ''}
              </text>
              {root && root.key !== 'c' && (
                <text x={4} y={222} className="t-tiny" data-value={root.correction}>
                  {research ? tx(`the first correction is ${root.correction}μ: minus the coefficient of κτ in c_1 (the stored ratio of the first two coefficients: ${root.storedCorrection})`)
                    : `the first correction is ${root.correction} times the delay times the strength`}
                </text>
              )}
              <text x={4} y={244} className="t-micro t-muted">{research ? 'Λ keeps its size and sign as inputs; the shift moves them from c to k (our reading, ATY-010)' : 'which way nature takes stays open; its size is an input'}</text>
            </g>
          </g>
        ) : <Loading x={4} y={54} w={452} h={60} what="stored results" />}
      </FigSvg>
      <Controls label="shifted Ricci">
        <Chips label={research ? 'operator' : 'way'} items={OPS} value={op} onPick={setOp} param="op" render={o => (research ? { '++': 'Ricci₊₊', '+-': 'Ricci₊₋', ss: 'Ricciₛₛ' }[o] : WAY[o])} />
        <Stepper label={research ? 'order' : 'terms'} value={order} min={0} max={3} onChange={setOrder} param="order" display={v => String(research ? v : v + 1)} />
      </Controls>
    </div>
  );
}
ShiftedRicci.meta = { id: 'shifted-ricci', lenses: [], learner: true };
ShiftedRicci.params = [{}, { op: '+-', order: 1 }, { op: 'ss', order: 3 }, { order: 2 }];
/** the numbers the figure draws, for the frame's data download */
ShiftedRicci.data = (params = {}) => {
  const T = peekShifted(params), op = OPS.includes(params.op) ? params.op : '++';
  if (!T) return { loading: true, op };
  const O = ricciData(T).find(x => x.op === op);
  return { op, c: O.c, ricci: O.ricci, pair: O.pair, root: O.root };
};
