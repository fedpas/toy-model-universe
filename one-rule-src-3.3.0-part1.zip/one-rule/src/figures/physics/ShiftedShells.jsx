// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure shifted-shells (Calibration 3, step 4 of `shifted`; caption ATY-005, states ATY-005 and ATY-009; docs/round14/STORY_ROUND.md §6.3, owner B3):
// plane waves of the shifted equation exist exactly on the lattice Eτ = (n + ½)π, where the factor e^{JEτ} is ±J, with E = m + (−1)ⁿκ and
// τ = (2n + 1)λ_C/4; none where the factor has a scalar part (τ = 0, λ_C/2, λ_C, the rational point (3/5, 4/5)); for κ > m a second branch on the
// other half. Drawn: the circle of the factor with the lattice and the empty marks (each point read off the kernel's J powers, engines/physics/shifted.js
// emptyMarks), the ladder of the rungs n = 0 … 3 (D37: from the lowest rung up, or from the top; a rung the table does not store is drawn empty, "not
// stored"), and the shell of the rung with a dot for each wave vector shd·QNT stores on it. The energies are computed (E = m + (−1)ⁿκ with the kernel's
// sign) and shown beside the stored ones (content/stored_shifted.json qnt, loaded on demand: D34). Controls: the stored case (chips), the rung (stepper,
// D37), from the top (toggle, D37). Tokens only; marks by shape and word.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Stepper, Toggle, pick, r1, tx } from '../kit.jsx';
import { Rungs, Loading } from './fureyKit.jsx';
import { useShifted, peekShifted } from './ShiftedQuarterTurn.jsx';
import { shellRungs, emptyMarks, shellCases } from '../../../engines/physics/shifted.js';

const CASES = ['3,2', '1,4'], NS = [0, 1, 2, 3];
const piText = ph => { const [a] = String(ph).split('/'); return `${a === '1' ? '' : a}π/2`; };
const kNorm = k => Math.hypot(k[1], k[2], k[3]);
const TAU = { 0: '0', '1/2': 'λ_C/2', 1: 'λ_C' }, TAU_WORDS = { 0: 'no delay', '1/2': 'half a wave', 1: 'a whole wave' };
/** the empty marks grouped by their point on the circle (τ = 0 and τ = λ_C fall on the same point), the off-shell quarter turn left out */
function marksByPoint(M) {
  const out = new Map();
  for (const m of M) {
    if (m.kind === 'off-shell') continue;
    const key = m.point.join(','), g = out.get(key) || { key, kind: m.kind, point: m.point, cs: m.cs, taus: [] };
    if (m.kind === 'tau' && !g.taus.includes(m.tau)) g.taus.push(m.tau);
    out.set(key, g);
  }
  return [...out.values()].map(g => ({ ...g, taus: g.taus.sort((a, b) => fracValue(a) - fracValue(b)) }));
}
const fracValue = t => { const [a, b] = String(t).split('/'); return +a / (+b || 1); };

export default function ShiftedShells({ params = {}, level = 'research', row }) {
  const research = level !== 'learner';
  const [cs, setCs] = useState(pick(params.case, v => CASES.includes(v), '3,2'));
  const [dir, setDir] = useState(params.from === 'top' ? 'top' : 'low');
  const [n, setN] = useState(pick(params.n, v => NS.includes(v), params.from === 'top' ? 3 : 0));
  useEffect(() => { const top = params.from === 'top'; setCs(pick(params.case, v => CASES.includes(v), '3,2')); setDir(top ? 'top' : 'low'); setN(pick(params.n, v => NS.includes(v), top ? 3 : 0)); }, [params.case, params.n, params.from]);
  const flip = on => { setDir(on ? 'top' : 'low'); setN(on ? 3 : 0); };
  const T = useShifted(params), ci = CASES.indexOf(cs);
  const C = T ? shellCases(T)[ci] : null, R = T ? shellRungs(T, ci) : null, M = T ? emptyMarks(T) : null, r = R ? R[n] : null;
  const cx = 104, cy = 98, RR = 58;
  const P = ([c, s]) => [r1(cx + RR * c), r1(cy - RR * s)];
  const rows = R ? R.map(x => ({ key: String(x.n), title: research ? `n = ${x.n}: Eτ = ${piText(x.phase)}` : `rung ${x.n}`, detail: x.stored ? (research ? tx(`E = ${x.stored.E}${x.stored.second ? `, ${x.stored.second}` : ''}, τ = ${x.tau} λ_C`) : `a wave, energy ${x.stored.E}`) : '', empty: !x.stored })) : [];
  // the shell of the rung: k₀ against |k| (k₀ = ±√(E² + |k|²)), the stored wave vectors as dots
  const sx = v => r1(48 + v * 28), sy = v => r1(294 - (v + 6) * 4.1), E = r && r.stored ? r.stored.E : null, E2 = r && r.stored ? r.stored.second : null;
  const branch = (e, sgn, kmax = 13) => Array.from({ length: 2 * kmax + 1 }, (_, i) => { const k = i / 2; return `${sx(k)},${sy(sgn * Math.sqrt(e * e + k * k))}`; }).join(' ');
  return (
    <div className="fig fig-shifted-shells">
      <FigSvg id="shifted-shells" row={row} viewBox="0 0 460 300">
        <text x={4} y={14} className="t-small t-bold">{research ? tx('the factor e^{JEτ} on its circle') : 'where a delay allows a wave'}</text>
        <line x1={cx - RR - 12} y1={cy} x2={cx + RR + 12} y2={cy} className="hair" />
        <line x1={cx} y1={cy - RR - 12} x2={cx} y2={cy + RR + 12} className="hair" />
        <circle cx={cx} cy={cy} r={RR} className="stroke-muted" />
        <text x={cx + RR + 14} y={cy + 4} className="t-tiny">1</text>
        <text x={cx + 5} y={cy - RR - 6} className="t-tiny">{research ? 'J' : 'a quarter turn'}</text>
        <text x={cx + 5} y={cy + RR + 16} className="t-tiny">{research ? '−J' : 'the other quarter'}</text>
        {R && R.map(x => {
          const [px, py] = P(x.point), on = x.n === n, found = !!x.stored;
          return <g key={x.n} data-lattice={x.n} data-point={x.point.join(',')} data-sign={x.sign}>{on && <circle cx={px} cy={py} r={8} className="stroke-ink" strokeWidth={2} />}{found ? <circle cx={px} cy={py} r={3.5} className="ink" /> : null}</g>;
        })}
        {M ? marksByPoint(M).map(g => {
          const [px, py] = P(g.point), rational = g.kind === 'rational', inside = g.point[0] < 0 ? 'start' : 'end';
          const lbl = rational ? (research ? `(${g.cs.join(', ')})` : 'in between') : research ? tx(`τ = ${g.taus.map(t => TAU[t]).join(', ')}`) : g.taus.map(t => TAU_WORDS[t]).join(', or ');
          return (
            <g key={g.key} data-empty={rational ? g.cs.join(',') : g.taus.map(t => `tau:${t}`).join(' ')} data-point={g.point.join(',')}>
              <circle cx={px} cy={py} r={4.5} className="on-panel" style={{ stroke: 'var(--fg)' }} />
              <text x={r1(rational ? px + 8 : px + (inside === 'start' ? 8 : -8))} y={r1(rational || inside === 'start' ? py - 6 : py + 14)} textAnchor={rational ? 'start' : inside} className="t-micro">{lbl}</text>
            </g>
          );
        }) : <Loading x={cx - 70} y={cy - 12} w={140} h={24} what="stored results" />}
        <text x={4} y={184} className="t-tiny t-muted">{research ? '● a wave on the lattice · ○ none (shd·QNT)' : '● a wave · ○ no wave'}</text>
        {R ? <Rungs x={230} y={30} w={226} rows={rows} on={n} dir={dir} step={36} h={24} param="n"
          up={() => (research ? tx('τ + λ_C/2: the factor changes sign') : 'half a wave more')} down={() => (research ? tx('the rung below: τ − λ_C/2') : 'half a wave less')} />
          : <Loading x={230} y={30} w={226} h={130} what="stored results" />}
        <g data-case={cs} data-rung={n} data-e={r && r.E != null ? r.E : ''} data-second={r && r.second != null ? r.second : ''} data-stored-e={E == null ? '' : E} data-stored-second={E2 == null ? '' : E2} data-tau={r ? r.tau : ''}>
          {r && (
            <text x={4} y={200} className="t-tiny">
              {research ? (r.stored ? tx(`E = m + (−1)^n κ = ${C.m} ${r.sign > 0 ? '+' : '−'} ${C.kappa} = ${r.E}${E2 ? `; second branch κ − m = ${E2}` : ''}`) : tx(`computed E = ${r.E == null ? 'none' : r.E}: not stored`))
                : r.stored ? `a wave of energy ${E}${E2 ? `, and one of energy ${E2} on the other half` : ''}` : 'this rung is not stored'}
            </text>
          )}
        </g>
        <g data-shell={E == null ? '' : E}>
          <line x1={sx(0)} y1={sy(0)} x2={sx(13.5)} y2={sy(0)} className="hair" />
          <line x1={sx(0)} y1={sy(-6)} x2={sx(0)} y2={sy(14)} className="hair" />
          <text x={sx(13.5)} y={sy(0) + 12} textAnchor="end" className="t-micro t-muted">{research ? '|k|' : 'momentum'}</text>
          <text x={sx(0) - 4} y={sy(14) + 6} textAnchor="end" className="t-micro t-muted">{research ? tx('k_0') : 'energy'}</text>
          {E != null && <polyline points={branch(E, 1)} className="stroke-ink" />}
          {E != null && r.stored.k.some(k => k[0] < 0) && <polyline points={branch(E, -1, Math.floor(2 * Math.sqrt(Math.max(0, 36 - E * E))) / 2)} className="stroke-ink" />}
          {E2 != null && <polyline points={branch(E2, 1)} className="stroke-muted" strokeDasharray="4 3" />}
          {E != null && r.stored.k.map((k, i) => <circle key={i} cx={sx(kNorm(k))} cy={sy(k[0])} r={3.2} className="ink" data-k={k.join(',')} />)}
          {T && E == null && <text x={sx(6.5)} y={sy(5)} textAnchor="middle" className="t-tiny t-muted">not stored</text>}
          {E != null && <text x={sx(13) - 6} y={sy(Math.sqrt(E * E + 169)) - 2} textAnchor="end" className="t-micro">{research ? `E = ${E}` : `energy ${E}`}</text>}
          {E2 != null && <text x={sx(13) + 4} y={sy(Math.sqrt(E2 * E2 + 169)) + 16} textAnchor="end" className="t-micro t-muted">{research ? `E = ${E2}, the other half` : `energy ${E2}, other half`}</text>}
        </g>
      </FigSvg>
      <Controls label="shells">
        <Chips label={research ? 'case (m, κ)' : 'case'} items={CASES} value={cs} onPick={setCs} param="case" render={c => (research ? `(${c.replace(',', ', ')})` : c === '3,2' ? 'mass 3, strength 2' : 'mass 1, strength 4')} />
        <Stepper label={research ? 'rung n' : 'rung'} value={n} min={0} max={3} onChange={setN} param="n" />
        <Toggle label="from the top" on={dir === 'top'} onChange={flip} param="from" />
      </Controls>
    </div>
  );
}
ShiftedShells.meta = { id: 'shifted-shells', lenses: [], learner: true };
ShiftedShells.params = [{}, { case: '1,4' }, { n: 1 }, { from: 'top' }, { case: '3,2', n: 2 }];
/** the numbers the figure draws, for the frame's data download */
ShiftedShells.data = (params = {}) => {
  const T = peekShifted(params), ci = Math.max(0, CASES.indexOf(params.case));
  if (!T) return { loading: true, case: CASES[ci] };
  return { case: CASES[ci], rungs: shellRungs(T, ci).map(x => ({ n: x.n, phase: x.phase, tau: x.tau, sign: x.sign, E: x.E, second: x.second, stored: x.stored })), empty: emptyMarks(T) };
};
