// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p13.js — round 14, owner B4 registers its figure here (id → component): fibre-base, Calibration 2 recomposed, the section fur-fibre of
// matter (docs/round14/STORY_ROUND.md §6.3, D62). Seed in content/physics/figures.p13.json; the engine engines/physics/fibreBase.js (the kernel alone);
// the test tests/physics/p13.test.mjs. src/figures/physics/index.js spreads this registry (B2's line), so the figure rides in dist/figures-extra.js (D47).
import FibreBase from './FibreBase.jsx';
export const P13_FIGURES = { 'fibre-base': FibreBase };
