// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure fibre-base (round 14, owner B4; docs/round14/STORY_ROUND.md §6.3, D62; caption row FUR-011): fibre and base on the labels. The ten generators
// of Cl(1,3) ⊗̂ Cl(0,6) = Cl(1,9) in two blocks, the base (bits 0–3, spacetime) and the fibre (bits 4–9, Furey's Cl(0,6)), with their squares; I, ω₆ and
// Γ = +I·ω₆ as brackets over the blocks; the product, graded or ungraded, with its type and the 24 cross pairs of a base and a fibre vector (anticommuting
// in the graded product, commuting in the ungraded one; the 6 + 15 bivectors commute in both: FUR-013); below, the two halves of the minimal ideal cut
// by Γ, each state a dot, each pair of states that I exchanges drawn with two arrows, I solid and ω₆ dashed, from the state each takes to + its partner:
// on the half Γ = +1 they point opposite ways (I = −ω₆), on Γ = −1 the same way (I = +ω₆): the chirality as the relative sign of the two complex
// structures (FUR-011). Every number and sign from engines/physics/fibreBase.js (the kernel alone; tests/physics/p13.test.mjs ties it to the fb.CHI,
// fb.TY and fb.DIR lines of fibre_base.log). Chips: the signature of the base (1,3)/(3,1) and of the fibre (0,6)/(6,0), the stored cases of fb.TY; the
// product; the half. Lenses clifford, bits, primes and cube print every label with the kernel's printer (D8); without a lens the research level names
// them e₀ … e₉ as the rows do, and the learner level draws switches and words, no formula (D5). Tokens only, no stylesheet of its own (D63).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, r1, labelLens, arrowHead } from '../kit.jsx';
import { fibreBase, nameOf, typeName, concatEps, BASES, FIBRES, PRODUCTS, NB, NF, I_MASK, W_MASK, G_MASK, BIV_BASE, BIV_FIBRE } from '../../../engines/physics/fibreBase.js';
import { label } from '../../../engines/bitrule.js';

export const FB_LENSES = ['clifford', 'bits', 'primes', 'cube'];
const HALVES = [1, -1];
const cellName = key => `Cl(${key})`;
const pm = x => (x > 0 ? `+${x}` : x < 0 ? `−${-x}` : '0');
const relWord = rel => (rel === -1 ? 'I = −ω₆' : rel === 1 ? 'I = +ω₆' : 'I ≠ ±ω₆');
/** the chips' state from the figure's params: { base, fibre, product, half } */
export function stateOf(p = {}) {
  return { base: p.base in BASES ? p.base : '1,3', fibre: p.fibre in FIBRES ? p.fibre : '0,6', product: PRODUCTS.includes(p.product) ? p.product : 'graded', half: HALVES.includes(p.half) ? p.half : 1 };
}
/** the printed name of a label: the kernel's printer in the active lens (clifford, bits, primes; cube prints the bits), else e₀ … e₉ at research level */
export function printedName(mask, lens, level, eps) {
  const L = labelLens(lens);
  if (L && FB_LENSES.includes(lens)) return label(mask, L, eps);
  return level === 'learner' ? null : nameOf(mask);
}

const CW = 48, CH = 36, GAP = 6, X0 = 8, XF = 240, YC = 22;                  // the generator cells: base from X0, fibre from XF
const cellX = bit => (bit < NB ? X0 + bit * (CW + GAP) : XF + (bit - NB) * (CW + GAP));
const GX = 590, GY = 44, GS = 22;                                          // the cross-pair grid: 4 rows (base) × 6 columns (fibre)
const small = t => (t && t.length > 6 ? 't-micro' : 't-tiny');

/** the two blocks, the brackets I, ω₆ and Γ, the product and its cross pairs */
function Blocks({ F, st, nm, research, row }) {
  const right = XF + NF * (CW + GAP) - GAP, baseRight = X0 + NB * (CW + GAP) - GAP;
  const bracket = (x1, x2, y, text, data) => (
    <g {...data}>
      <path d={`M${x1} ${y - 5} V${y} H${x2} V${y - 5}`} className="stroke-muted" />
      <text x={r1((x1 + x2) / 2)} y={y + 13} textAnchor="middle" className="t-small">{text}</text>
    </g>
  );
  const sq = x => (research ? pm(x) : x > 0 ? 'plus' : 'minus');
  const prodLine = research
    ? (st.product === 'graded' ? `${cellName(st.base)} ⊗ ${cellName(st.fibre)} graded = Cl(${F.p},${F.q}) ≅ ${typeName(F.type)}` : `${cellName(st.base)} ⊗ ${cellName(st.fibre)} ungraded ≅ ${typeName(F.type)}`)
    : (st.product === 'graded' ? 'one cell of ten switches' : 'two cells side by side');
  return (
    <FigSvg id="fibre-base" row={row} part={research ? 'the two blocks and their product' : 'the switches of space and time and the inner switches'} viewBox="0 0 760 186" className="fig-svg-wide"
      data-product={st.product} data-type={typeName(F.type)} data-siw={F.sIW} data-cross-anti={F.crossAnti} data-biv-cross={`${F.bivCross},${F.bivPairs}`}>
      <text x={X0} y={12} className="t-head">{research ? `base ${cellName(st.base)}` : `space and time: ${NB} switches`}</text>
      <text x={XF} y={12} className="t-head">{research ? `fibre ${cellName(st.fibre)}` : `inside: ${NF} switches`}</text>
      {F.gens.map(g => {
        const x = cellX(g.bit), name = nm(g.mask);
        return (
          <g key={g.bit} data-gen={g.bit} data-block={g.block} data-square={g.square}>
            <rect x={x} y={YC} width={CW} height={CH} rx={4} className="hair" style={{ fill: 'var(--panel)' }} />
            {name != null && <text x={x + CW / 2} y={YC + 15} textAnchor="middle" className={`${small(name)} t-mono`} data-label={name}>{name}</text>}
            <text x={x + CW / 2} y={YC + (name != null ? 30 : 23)} textAnchor="middle" className="t-tiny t-muted" data-sq={g.square}>{sq(g.square)}</text>
          </g>
        );
      })}
      {bracket(X0, baseRight, 72, research ? `I = ${nm(I_MASK)} · I² = ${pm(F.squares.I)}` : 'turn of space and time', { 'data-bracket': 'I', 'data-mask': I_MASK, 'data-square': F.squares.I, 'data-label': nm(I_MASK) ?? '' })}
      {bracket(XF, right, 72, research ? `ω₆ = ${nm(W_MASK)} · ω₆² = ${pm(F.squares.w6)}` : 'turn of the inner switches', { 'data-bracket': 'w6', 'data-mask': W_MASK, 'data-square': F.squares.w6, 'data-label': nm(W_MASK) ?? '' })}
      {bracket(X0, right, 106, research ? `Γ = ${F.sIW > 0 ? '+' : '−'}I·ω₆ = ${nm(G_MASK)} · Γ² = ${pm(F.squares.G)}` : 'the two turns together tell the hand', { 'data-bracket': 'G', 'data-mask': G_MASK, 'data-square': F.squares.G, 'data-label': nm(G_MASK) ?? '' })}
      <text x={X0} y={142} className="t-small" data-product-line={st.product}>{prodLine}</text>
      <text x={X0} y={160} className="t-small t-muted" data-biv={`${F.bivCross},${F.bivPairs}`}>
        {research ? `the ${BIV_BASE.length} + ${BIV_FIBRE.length} bivectors: ${F.bivCross} of ${F.bivPairs} cross pairs commute` : 'the turns inside each block never feel the other block'}
      </text>
      <text x={GX} y={12} className="t-head">{research ? 'base × fibre vectors' : 'switches across'}</text>
      <text x={GX} y={24} className="t-tiny t-muted" data-cross-summary={F.crossAnti}>{research ? `${F.crossAnti} of ${F.cross.length} anticommute` : (F.crossAnti ? 'they swap with a minus' : 'they swap freely')}</text>
      <text x={GX} y={36} className="t-micro t-muted">{research ? 'filled: anticommute · ring: commute' : 'filled: with a minus; ring: freely'}</text>
      {F.cross.map(x => (
        <rect key={`${x.i},${x.a}`} x={GX + 32 + (x.a - NB) * GS} y={GY + x.i * GS} width={GS - 6} height={GS - 6} rx={x.anti ? 2 : 8} className={x.anti ? 'ink' : 'stroke-ink'} data-cross={`${x.i},${x.a},${x.anti ? 1 : 0}`} />
      ))}
      {[...Array(NB).keys()].map(i => { const t = nm(1 << i); return t == null ? null : <text key={`r${i}`} x={GX + 28} y={GY + i * GS + 12} textAnchor="end" className="t-micro t-mono" data-label={t}>{t}</text>; })}
      {[...Array(NF).keys()].map(j => {
        const t = nm(1 << (NB + j)); if (t == null) return null;
        const x = GX + 32 + j * GS + (GS - 6) / 2, y = GY + NB * GS + 4, vertical = t.length > 3;
        return <text key={`c${j}`} x={r1(x + (vertical ? -3 : 0))} y={y + (vertical ? 0 : 8)} textAnchor={vertical ? 'start' : 'middle'} transform={vertical ? `rotate(90 ${r1(x - 3)} ${y})` : undefined} className="t-micro t-mono" data-label={t}>{t}</text>;
      })}
    </FigSvg>
  );
}

/** one half of the minimal ideal: its states as dots, each pair that I exchanges with its two arrows (I solid, ω₆ dashed) */
function Half({ h, st, nm, research, row }) {
  const names = h.pairs.flatMap(x => [nm(x.from), nm(x.to)]), long = names.some(t => t && t.length > 6);
  const labelled = names.some(t => t != null), RH = labelled ? 50 : 38;
  const cols = long ? 2 : 4, colW = 360 / cols, rows = Math.ceil(h.pairs.length / cols), H = 32 + rows * RH;
  const selected = st.half === h.gamma;
  const arrow = (x1, x2, y, sgn, dashed, key) => {
    const [a, b] = sgn > 0 ? [x1 + 6, x2 - 6] : [x2 - 6, x1 + 6];
    return (
      <g key={key} data-arrow={dashed ? 'w6' : 'I'} data-sign={sgn}>
        <line x1={r1(a)} y1={y} x2={r1(b)} y2={y} className="stroke-ink" style={dashed ? { strokeDasharray: '3 2' } : undefined} />
        <path d={arrowHead(a, y, b, y, 5)} className="ink" />
      </g>
    );
  };
  const title = research
    ? `Γ = ${pm(h.gamma)} · ${relWord(h.rel)}`
    : `${h.gamma > 0 ? 'first' : 'second'} half: ${h.rel === -1 ? 'the two turns go opposite ways' : h.rel === 1 ? 'the two turns go the same way' : 'the two turns are not tied'}`;
  return (
    <div className="fig-panel" data-half={h.gamma} data-dim={h.dim} data-rel={h.rel ?? ''} data-selected={selected ? 'true' : 'false'}>
      <FigSvg id="fibre-base" row={row} part={research ? `the half Γ = ${pm(h.gamma)}` : `the ${h.gamma > 0 ? 'first' : 'second'} half`} viewBox={`0 0 360 ${H}`}>
        {selected && <rect x={1} y={1} width={358} height={H - 2} rx={6} style={{ fill: 'var(--hi)', fillOpacity: 0.35 }} data-highlight="1" />}
        <text x={8} y={16} className="t-small t-bold">{title}</text>
        <text x={352} y={16} textAnchor="end" className="t-small t-muted" data-states={h.dim}>{`${h.dim} states`}</text>
        {h.pairs.map((x, k) => {
          const cx = colW / 2 + (k % cols) * colW, cy = 44 + Math.floor(k / cols) * RH, xl = cx - (long ? 40 : 24), xr = cx + (long ? 40 : 24), nl = nm(x.from), nr = nm(x.to);
          return (
            <g key={x.from} data-pair={`${x.from},${x.to},${x.sI},${x.sW}`}>
              {arrow(xl, xr, cy - 8, x.sI, false, 'I')}
              {arrow(xl, xr, cy + 8, x.sW, true, 'w')}
              <circle cx={r1(xl)} cy={cy} r={3.4} className="ink" data-state={x.from}><title>{nl ?? (research ? '' : 'a state')}</title></circle>
              <circle cx={r1(xr)} cy={cy} r={3.4} className="ink" data-state={x.to}><title>{nr ?? (research ? '' : 'a state')}</title></circle>
              {nl != null && <text x={r1(xl)} y={cy + 22} textAnchor="middle" className={`${small(nl)} t-mono`} data-label={nl} data-of={x.from}>{nl}</text>}
              {nr != null && <text x={r1(xr)} y={cy + 22} textAnchor="middle" className={`${small(nr)} t-mono`} data-label={nr} data-of={x.to}>{nr}</text>}
            </g>
          );
        })}
      </FigSvg>
    </div>
  );
}

export default function FibreBase({ params = {}, lens = null, level = 'research', theme, row }) {   // eslint-disable-line no-unused-vars
  const research = level !== 'learner';
  const [st, setSt] = useState(() => stateOf(params));
  useEffect(() => { setSt(stateOf(params)); }, [params.base, params.fibre, params.product, params.half]);   // eslint-disable-line react-hooks/exhaustive-deps
  const F = fibreBase(st), eps = concatEps(st.base, st.fibre);
  const nm = mask => printedName(mask, lens, level, eps);
  const set = k => v => setSt(s => ({ ...s, [k]: v }));
  const [hp, hm] = F.halves, pick = F.halves.find(h => h.gamma === st.half) || hp;
  const way = rel => (rel === -1 ? 'opposite ways' : rel === 1 ? 'the same way' : 'no one way');
  return (
    <div className="fig fig-fibre-base" data-base={st.base} data-fibre={st.fibre} data-product={st.product} data-half={st.half} data-lens={FB_LENSES.includes(lens) ? lens : ''}>
      <div className="fig-scroll"><Blocks F={F} st={st} nm={nm} research={research} row={row} /></div>
      <div className="fig-panels">{F.halves.map(h => <Half key={h.gamma} h={h} st={st} nm={nm} research={research} row={row} />)}</div>
      <p className="fig-note" data-legend="arrows">
        {research
          ? 'I (solid) and ω₆ (dashed) take the state at the tail of an arrow to the state at its head, and the head to minus the tail.'
          : `Solid arrows: the turn of space and time. Dashed arrows: the turn of the inner switches. On the first half they point ${way(hp.rel)}, on the second ${way(hm.rel)}.`}
      </p>
      <Controls label={research ? 'fibre and base' : 'space and the inner switches'}>
        <Chips label={research ? 'base' : 'space and time'} items={Object.keys(BASES)} value={st.base} param="base" mono={research} render={k => (research ? cellName(k) : k === '1,3' ? 'one plus, three minus' : 'three plus, one minus')} onPick={set('base')} />
        <Chips label={research ? 'fibre' : 'inside'} items={Object.keys(FIBRES)} value={st.fibre} param="fibre" mono={research} render={k => (research ? cellName(k) : k === '0,6' ? 'six minus' : 'six plus')} onPick={set('fibre')} />
        <Chips label={research ? 'product' : 'across the blocks'} items={PRODUCTS} value={st.product} param="product" render={k => (research ? k : k === 'graded' ? 'with a minus' : 'freely')} onPick={set('product')} />
        <Chips label="half" items={HALVES} value={st.half} param="half" render={g => (research ? `Γ = ${pm(g)}` : g > 0 ? 'first' : 'second')} onPick={set('half')} />
      </Controls>
      <dl className="fig-readout" data-readout="fibre-base">
        {research ? (
          <>
            <div data-ideal={`${F.ideal.m},${hp.dim},${hm.dim}`}><dt>minimal ideal</dt><dd>{`${F.ideal.m} = ${hp.dim} + ${hm.dim} (${F.ideal.k} commuting labels, Γ among them)`}</dd></div>
            <div data-pick={`${pick.gamma},${pick.rel}`}><dt>{`on Γ = ${pm(pick.gamma)}`}</dt><dd>{relWord(pick.rel)}</dd></div>
            <div data-base-rel={F.baseRel ?? ''}><dt>boosts</dt><dd>{`e₀eₖ = ${F.baseRel < 0 ? '−' : '+'}I Rₖ (k = 1, 2, 3)`}</dd></div>
          </>
        ) : (
          <>
            <div data-ideal={`${F.ideal.m},${hp.dim},${hm.dim}`}><dt>states</dt><dd>{`${hp.dim} in each half`}</dd></div>
            <div data-pick={`${pick.gamma},${pick.rel}`}><dt>{`${pick.gamma > 0 ? 'first' : 'second'} half`}</dt><dd>{`the two turns go ${way(pick.rel)}`}</dd></div>
          </>
        )}
      </dl>
    </div>
  );
}
FibreBase.meta = { id: 'fibre-base', lenses: FB_LENSES, learner: true };
FibreBase.params = [{}, { half: -1 }, { product: 'ungraded' }, { base: '3,1' }, { fibre: '6,0', half: -1 }, { base: '3,1', fibre: '6,0', product: 'ungraded', half: -1 }];
/** the numbers the figure draws, from the kernel: the configuration, the squares, Γ's sign, the types, the cross pairs, the ideal, each half with its pairs */
FibreBase.data = (p = {}) => {
  const st = stateOf(p), F = fibreBase(st);
  return { ...st, eps: F.eps, p: F.p, q: F.q, squares: F.squares, sIW: F.sIW, type: typeName(F.type), typeGraded: typeName(F.typeGraded), typeUngraded: typeName(F.typeUngraded),
    crossAnti: F.crossAnti, bivCross: F.bivCross, bivPairs: F.bivPairs, baseRel: F.baseRel, ideal: F.ideal.m,
    halves: F.halves.map(h => ({ gamma: h.gamma, dim: h.dim, rel: h.rel, pairs: h.pairs.map(x => [x.from, x.to, x.sI, x.sW]) })) };
};
