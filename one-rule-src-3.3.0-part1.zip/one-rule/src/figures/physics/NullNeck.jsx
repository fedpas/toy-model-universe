// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure null-neck (step 13, caption NUL-002; docs/PHYSICS_AUDIT.md NS1): horizon or throat — Schwarzschild (r_S = 1) beside the Ellis wormhole (throat radius 1),
// the same state in v15's three lenses of the neck. Clifford: |n·n| (solid) and |g^rr| (dashed) against r = 1 … 2 — one curve in Schwarzschild (T R = 1), two in
// Ellis, where n·n = −1 down to the throat while g^rr → 0. Null: the two spacetimes in null coordinates, Kruskal (X, T) and (ℓ, t), with the script's own rows
// (null.json figs.f1, from content/stored_p9.json: the slices r = const, the rows inside, the surface r = 1, a photon, the neck) and the slice at the chosen r drawn
// live (X² − T² = (r − 1)eʳ, ℓ = ±√(r² − 1)). Flow: dr/dv (solid) and dℓ/dv (dashed) along an ingoing photon, with the script's points (figs.f2) on the curves.
// Readouts at r: T, n·n = −T and g^rr for each, the rates in the flow lens. Every number is engines/nullEngine.js's (through engines/physics/nullPhysics.js) or the
// stored json's; tests/physics/p9.test.mjs ties them. Controls, as in v15 NeckWidget: the radius r (a slider, research level) and the lens chips clifford / null /
// flow. Marks by stroke and word (solid, dashed, heavy, an arrow for the photon), tokens only. Port of v15 NullWidgets.NeckWidget.
import React, { useState, useEffect, useMemo } from 'react';
import { useTable } from '../../app/content.js';
import { NECK, NECK_VIEWS, neckAt, neckCurves, neckSlice } from '../../../engines/physics/nullPhysics.js';
import { FigSvg, Controls, Chips, Range, r1, arrowHead, pick, isIn } from '../kit.jsx';
import { storedNull, Key, hx } from './p9kit.jsx';
import './p9.css';

const VIEW_NAME = { clifford: 'Clifford', null: 'Null', flow: 'Flow' };
const fx = (v, d = 4) => (Math.abs(v) < 5 * 10 ** -(d + 1) ? '0' : String(+v.toFixed(d)).replace('-', '−'));
const rOf = v => (Number.isFinite(v) && v >= NECK.min && v <= NECK.max ? Math.round(v * 100) / 100 : NECK.start);

const W = 620, H = 272, TOP = 30, FH = 196, FW = 252, X0 = [46, 346], NAMES = ['Schwarzschild', 'Ellis wormhole'];
const px = (i, r) => X0[i] + (r - 1) * FW, py = (v, vmax) => TOP + FH - (v / vmax) * FH;
const poly = (pts, i, vmax) => pts.map(([r, v]) => `${r1(px(i, r))},${r1(py(Math.min(v, vmax * 1.04), vmax))}`).join(' ');

function Frames({ vmax }) {
  return X0.map((x, i) => (
    <g key={i}>
      <rect x={x} y={TOP} width={FW} height={FH} className="p9-frame" />
      <text x={x + FW / 2} y={TOP - 10} textAnchor="middle" className="t-small t-bold">{NAMES[i]}</text>
      <text x={x} y={TOP + FH + 14} className="t-tiny t-muted">r = 1</text>
      <text x={x + FW} y={TOP + FH + 14} textAnchor="end" className="t-tiny t-muted">r = 2</text>
      <text x={x - 4} y={TOP + 8} textAnchor="end" className="t-tiny t-muted">{fx(vmax, 2)}</text>
      <text x={x - 4} y={TOP + FH} textAnchor="end" className="t-tiny t-muted">0</text>
    </g>
  ));
}

// the null lens: two charts, Kruskal (X, T) and Ellis (ℓ, t), ±3 on both axes
const CX = [168, 470], CY = 138, U = 34, MIR = [{ sx: 1, sy: 1 }, { sx: -1, sy: 1 }, { sx: 1, sy: -1 }];
const KIND_STYLE = {
  static: { className: 'stroke-muted', style: { strokeWidth: 1 } },
  interior: { className: 'stroke-muted', style: { strokeWidth: 1, strokeDasharray: '4 3' } },
  surface: { className: 'stroke-ink', style: { strokeWidth: 3 } },
  photon: { className: 'stroke-ink', style: { strokeWidth: 1.8 } },
};
function NullCharts({ f1, slice }) {
  const box = c => <g key={'b' + c}><rect x={c - 3.3 * U} y={CY - 3.3 * U} width={6.6 * U} height={6.6 * U} className="p9-frame" /><line x1={c - 3.3 * U} y1={CY} x2={c + 3.3 * U} y2={CY} className="hair" /><line x1={c} y1={CY - 3.3 * U} x2={c} y2={CY + 3.3 * U} className="hair" /></g>;
  const rows = f1 ? f1.flatMap((q, k) => MIR.map(m => {
    if ((m.sx < 0 && q.mx !== 1) || (m.sy < 0 && q.my !== 1) || q.kind === 'neck' || !KIND_STYLE[q.kind]) return null;
    const c = q.p === 'k' ? CX[0] : CX[1], x1 = c + U * m.sx * q.a1, y1 = CY - U * m.sy * q.b1, x2 = c + U * m.sx * q.a2, y2 = CY - U * m.sy * q.b2, st = KIND_STYLE[q.kind];
    return (
      <g key={k + ':' + m.sx + m.sy} data-row-kind={q.kind} data-chart={q.p} data-src="stored">
        <title>{q.s}</title>
        <line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className={st.className} style={st.style} strokeLinecap="round" />
        {q.kind === 'photon' && m.sx === 1 && m.sy === 1 ? <path d={arrowHead(x1, y1, x2, y2, 7)} className="ink" /> : null}
      </g>
    );
  })).filter(Boolean) : [];
  const necks = f1 ? f1.filter(q => q.kind === 'neck').map(q => <circle key={'n' + q.p} cx={q.p === 'k' ? CX[0] : CX[1]} cy={CY} r={4.2} className="ink" data-row-kind="neck" data-chart={q.p} data-src="stored"><title>{q.s}</title></circle>) : [];
  const live = s => slice.kruskal.map(([X, T]) => `${r1(CX[0] + U * s * X)},${r1(CY - U * T)}`).join(' ');
  return (
    <g data-view="null" data-stored-rows={f1 ? f1.length : 0}>
      {CX.map(box)}
      <text x={CX[0] - 3.3 * U} y={CY - 3.3 * U - 8} className="t-small t-bold">Schwarzschild: Kruskal (X, T)</text>
      <text x={CX[1] - 3.3 * U} y={CY - 3.3 * U - 8} className="t-small t-bold">Ellis: (ℓ, t)</text>
      <text x={CX[0] + 3.3 * U - 4} y={CY - 4} textAnchor="end" className="t-tiny t-muted">X</text>
      <text x={CX[0] + 4} y={CY - 3.3 * U + 10} className="t-tiny t-muted">T</text>
      <text x={CX[1] + 3.3 * U - 4} y={CY - 4} textAnchor="end" className="t-tiny t-muted">ℓ</text>
      <text x={CX[1] + 4} y={CY - 3.3 * U + 10} className="t-tiny t-muted">t</text>
      {rows}{necks}
      <g data-live="slice">
        {[1, -1].map(s => <polyline key={s} points={live(s)} className="p9-accent" style={{ strokeWidth: 2.4, strokeDasharray: '7 3' }} />)}
        {[1, -1].map(s => <line key={'e' + s} x1={r1(CX[1] + U * s * slice.ellisL)} y1={r1(CY - 3.3 * U)} x2={r1(CX[1] + U * s * slice.ellisL)} y2={r1(CY + 3.3 * U)} className="p9-accent" style={{ strokeWidth: 2.4, strokeDasharray: '7 3' }} />)}
      </g>
    </g>
  );
}

export default function NullNeck({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [T0] = useTable('stored_p9');
  const figs = storedNull(params, T0);
  const [view, setView] = useState(pick(params.view, isIn(NECK_VIEWS), 'clifford'));
  const [r, setR] = useState(rOf(params.r));
  useEffect(() => { setView(pick(params.view, isIn(NECK_VIEWS), 'clifford')); setR(rOf(params.r)); }, [params.view, params.r]);
  const A = neckAt(r), C = useMemo(() => neckCurves(40), []), S = neckSlice(r);
  const f2 = figs ? figs.f2.filter(q => q.r2 <= 2 + 1e-9) : [];
  const vmax = view === 'flow' ? 0.55 : 1;
  return (
    <div className="fig p9 fig-null-neck">
      <FigSvg id="null-neck" row={row} viewBox={`0 0 ${W} ${H}`}>
        <g data-view={view} data-r={r.toFixed(2)}>
          {view !== 'null' && <Frames vmax={vmax} />}
          {view === 'clifford' && (
            <g data-view="clifford">
              <polyline points={poly(C.schw.nn, 0, 1)} className="stroke-ink" style={{ strokeWidth: 2.6 }} data-curve="nn" data-s="schw" />
              <polyline points={poly(C.schw.grr, 0, 1)} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: '5 4' }} data-curve="grr" data-s="schw" />
              <polyline points={poly(C.ellis.nn, 1, 1)} className="stroke-ink" style={{ strokeWidth: 2.6 }} data-curve="nn" data-s="ellis" />
              <polyline points={poly(C.ellis.grr, 1, 1)} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: '5 4' }} data-curve="grr" data-s="ellis" />
              <circle cx={r1(px(0, r))} cy={r1(py(-A.schw.nn, 1))} r={4.5} className="ink" data-mark="nn" />
              <circle cx={r1(px(1, r))} cy={r1(py(-A.ellis.nn, 1))} r={4.5} className="ink" data-mark="nn" />
              <circle cx={r1(px(1, r))} cy={r1(py(-A.ellis.grr, 1))} r={4.5} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} data-mark="grr" />
            </g>
          )}
          {view === 'flow' && (
            <g data-view="flow">
              <polyline points={poly(C.schw.dr, 0, vmax)} className="stroke-ink" style={{ strokeWidth: 2.6 }} data-curve="dr" data-s="schw" />
              <polyline points={poly(C.schw.dl, 0, vmax)} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: '5 4' }} data-curve="dl" data-s="schw" />
              <polyline points={poly(C.ellis.dr, 1, vmax)} className="stroke-ink" style={{ strokeWidth: 2.6 }} data-curve="dr" data-s="ellis" />
              <polyline points={poly(C.ellis.dl, 1, vmax)} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: '5 4' }} data-curve="dl" data-s="ellis" />
              {f2.map((q, k) => { const i = q.cs === 'Schwarzschild' ? 0 : 1; return <circle key={'s' + k} cx={r1(px(i, q.r2))} cy={r1(py(q.v2, vmax))} r={1.7} className="ink" data-stored-f2={`${q.cs},${q.q},${q.r2},${q.v2}`}><title>{`${q.cs} ${q.q} at r = ${q.r2}: ${q.v2} (null.json f2)`}</title></circle>; })}
              {[[0, A.schw.dr, 'ink'], [0, A.schw.dl, 'on-panel'], [1, A.ellis.dr, 'ink'], [1, A.ellis.dl, 'on-panel']].map(([i, v, c], k) => <circle key={'m' + k} cx={r1(px(i, r))} cy={r1(py(v, vmax))} r={4.5} className={c} style={c === 'on-panel' ? { stroke: 'var(--fg)', strokeWidth: 1.5 } : undefined} data-mark={k % 2 ? 'dl' : 'dr'} />)}
            </g>
          )}
          {view === 'null' && <NullCharts f1={figs ? figs.f1 : null} slice={S} />}
        </g>
      </FigSvg>
      <ul className="p9-legend">
        {view === 'clifford' && <><li><Key kind="solid" />|n·n|, norm of the normal</li><li><Key kind="dashed" />|g<sup>rr</sup>|</li></>}
        {view === 'null' && <><li><Key kind="heavy" />r = 1: horizon (null), throat (timelike)</li><li><Key kind="arrow" />a photon crossing it</li><li><Key kind="live" />the slice at the chosen r</li><li><Key kind="thin" />r = const</li><li><Key kind="thin-dashed" />r &lt; 1</li></>}
        {view === 'flow' && <><li><Key kind="solid" />dr/dv along an ingoing photon</li><li><Key kind="dashed" />dℓ/dv, proper length</li>{f2.length ? <li><Key kind="dot" />null.json f2</li> : null}</>}
      </ul>
      <div className="p9-readout">
        <p data-schw-t={fx(A.schw.T)} data-schw-nn={fx(A.schw.nn)} data-schw-grr={fx(A.schw.grr)}>{hx(`Schwarzschild: T = ${fx(A.schw.T)} · n·n = −T = ${fx(A.schw.nn)} · g^{rr} = ${fx(A.schw.grr)}`)}</p>
        <p data-ellis-nn={fx(A.ellis.nn)} data-ellis-grr={fx(A.ellis.grr)}>{hx(`Ellis wormhole: T = 1 · n·n = −1 · g^{rr} = ${fx(A.ellis.grr)}`)}</p>
        {view === 'flow' && <p data-rates={[A.schw.dr, A.schw.dl, A.ellis.dr, A.ellis.dl].map(v => fx(v)).join(',')}>{`dr/dv = ${fx(A.schw.dr)}, dℓ/dv = ${fx(A.schw.dl)} (Schwarzschild) · dr/dv = ${fx(A.ellis.dr)}, dℓ/dv = ${fx(A.ellis.dl)} (Ellis wormhole)`}</p>}
        {view === 'null' && <p data-slice={`${fx(A.schw.X0 ** 2)},${fx(A.ellis.l)}`}>{hx(`X² − T² = (r − 1)e^r = ${fx(A.schw.X0 ** 2)} · ℓ = ±√(r² − 1) = ±${fx(A.ellis.l)}`)}</p>}
      </div>
      <Controls label="the neck">
        <Chips label="lens" items={NECK_VIEWS} value={view} onPick={setView} render={k => VIEW_NAME[k]} param="view" />
        {research && <Range label="radius r" value={r} min={NECK.min} max={NECK.max} step={NECK.step} onChange={v => setR(rOf(v))} display={v => `r = ${v.toFixed(2)}`} param="r" />}
      </Controls>
    </div>
  );
}
NullNeck.meta = { id: 'null-neck', lenses: [], learner: false };
NullNeck.params = [{}, { view: 'null', r: 1.02 }, { view: 'flow', r: 2 }, { view: 'clifford', r: 1.5 }];
/** the numbers the figure draws, for the frame's data download */
NullNeck.data = (params = {}) => ({ view: pick(params.view, isIn(NECK_VIEWS), 'clifford'), ...neckAt(rOf(params.r)) });
