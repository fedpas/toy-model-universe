// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure dragon-blades (round 17, proofs pass 13a; caption row LAB-027): Duvall and Keesling's count of the boundary of the Lévy dragon, on the labels.
// Left, the path of Cl(0,n) (n ≤ 16) turned onto its chord, each step the long side of one triangle of their F^n(T₀); the interior labels (the 15 triangles
// of the star all on the path) filled in ink, and ringed while they are few: none for n ≤ 13, 8 at n = 14, 44 at 15, 172 at 16. Right, the share of the
// labels on the boundary for n = 0 … 120: counted on the labels for n ≤ 16 (the band), by their Proposition 5.1 beyond, the current n marked; each n
// carries its value as a tooltip. The readout: the counts at n, the 752 types of the rule, λ (the largest root of the nonic P) and 2 log₂ λ, the dimension
// their Theorem 4.5 gives (read, not re-proved). Every number from engines/physics/clockWalk.js; tests/physics/p14.test.mjs ties them to the cw.DK and
// cw.LAM lines of clock_walk.log. Research level only (learner: false). Tokens only, no stylesheet of its own (D63).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Stepper, r1 } from '../kit.jsx';
import { dragonBlades, triangleOf, boundaryRule, lambda, dimOf, N_BLADES, N_SHARE } from '../../../engines/physics/clockWalk.js';
import { pathOf } from './ClockWalk.jsx';

const N_MIN = 2, RINGS = 12;                       // the stepper's range is N_MIN … N_BLADES; rings while at most RINGS labels are interior
const DW = 400, DH = 300, DP = 18;                 // the dragon's panel
const CW = 400, CH = 300, X0 = 46, X1 = 386, Y0 = 26, Y1 = 250;   // the chart's panel and plot area
const r3 = x => Math.round(x * 1000) / 1000;
const pct = x => `${(100 * x).toFixed(x > 0.9995 && x < 1 ? 3 : 1)} %`;
const group = k => String(k).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');   // 16 384
/** the first k decimals of x, cut (not rounded): the digits printed before an ellipsis are the number's own */
export const cut = (x, k) => (Math.floor(x * 10 ** k) / 10 ** k).toFixed(k);
const okN = n => Number.isInteger(n) && n >= N_MIN && n <= N_BLADES;
export const stateOf = (params = {}) => ({ n: okN(params.n) ? params.n : 14 });

/** the dragon: the walk of Cl(0,n) turned onto its chord (its end, (1 − i)ⁿ, to the right), the interior triangles filled, rings around them while few */
function Dragon({ B, research, row }) {
  const W = B.walk, theta = Math.atan2(W.end[1], W.end[0]), cs = Math.cos(theta), sn = Math.sin(theta);
  const rot = (x, y) => [x * cs + y * sn, -x * sn + y * cs];
  let minX = 0, maxX = 0, minY = 0, maxY = 0;
  for (let k = 0; k < W.xs.length; k++) { const [u, v] = rot(W.xs[k], W.ys[k]); if (u < minX) minX = u; if (u > maxX) maxX = u; if (v < minY) minY = v; if (v > maxY) maxY = v; }
  const w = Math.max(maxX - minX, 1), h = Math.max(maxY - minY, 1), s = Math.min((DW - 2 * DP) / w, (DH - 2 * DP - 14) / h);
  const ox = DP + ((DW - 2 * DP) - w * s) / 2 - s * minX, oy = DP + ((DH - 2 * DP - 14) - h * s) / 2 + s * maxY;
  const at = (x, y) => { const [u, v] = rot(x, y); return [r1(ox + s * u), r1(oy - s * v)]; };
  const transform = `translate(${r3(ox)} ${r3(oy)}) scale(${r3(s)} ${r3(-s)}) rotate(${r3((-theta * 180) / Math.PI)})`;
  const lw = r1(Math.min(1.6, Math.max(0.5, s * 0.55)));
  const ringed = B.interior.length <= RINGS;
  const [ex, ey] = at(W.end[0], W.end[1]), [zx, zy] = at(0, 0);
  return (
    <FigSvg id="dragon-blades" row={row} part={research ? `the path of Cl(0,${B.n}) on its chord` : null} viewBox={`0 0 ${DW} ${DH}`}
      data-n={B.n} data-interior={B.interior.join(',')} data-boundary={B.boundary} data-distinct={B.distinct ? 1 : 0} data-angle={r3((theta * 180) / Math.PI)}>
      <g transform={transform}>
        <path d={pathOf(W, 0, B.N)} className="stroke-muted" vectorEffect="non-scaling-stroke" style={{ strokeWidth: lw, strokeLinejoin: 'round' }} data-walk={B.n} />
        {B.interior.map(m => { const t = triangleOf(B, m); return <path key={m} d={`M${t[0][0]} ${t[0][1]}L${t[1][0]} ${t[1][1]}L${t[2][0]} ${t[2][1]}Z`} className="ink" data-blade={m} />; })}
      </g>
      {B.interior.map(m => { const t = triangleOf(B, m), [cx, cy] = at((t[0][0] + t[1][0] + t[2][0]) / 3, (t[0][1] + t[1][1] + t[2][1]) / 3); return ringed
        ? <circle key={m} cx={cx} cy={cy} r={7} className="stroke-ink" style={{ strokeWidth: 1.5 }} data-ring={m}><title>{`label ${m}`}</title></circle>
        : <circle key={m} cx={cx} cy={cy} r={1.7} className="ink" data-dot={m} />;
      })}
      <circle cx={zx} cy={zy} r={2.4} className="ink" />
      <circle cx={ex} cy={ey} r={2.4} className="ink" />
      {research && <>
        <text x={zx} y={r1(zy + 14)} textAnchor="middle" className="t-mono t-tiny t-muted">0</text>
        <text x={ex} y={r1(ey + 14)} textAnchor="middle" className="t-mono t-tiny t-muted">1</text>
        <text x={DP} y={DH - 6} className="t-small" data-count={`${B.interior.length},${B.N}`}>{`Cl(0,${B.n}): ${group(B.interior.length)} of ${group(B.N)} labels interior`}</text>
      </>}
    </FigSvg>
  );
}

/** the share of the labels on the boundary, n = 0 … 120: the band n ≤ 16 counted on the labels, the rest by Proposition 5.1; the current n marked */
function Share({ R, n, research, row }) {
  const X = k => r1(X0 + ((X1 - X0) * k) / N_SHARE), Y = v => r1(Y1 - (Y1 - Y0) * v);
  const pts = R.share.map((v, k) => `${X(k)},${Y(v)}`).join(' ');
  // the three marked n, each text where the curve leaves room (below it on the left, above it on the right) with a leader to its point
  const notes = [[14, 'first interior labels', 19, 0.42], [24, pct(R.share[24]), 36, 0.99], [64, pct(R.share[64]), 70, 0.64]];
  return (
    <FigSvg id="dragon-blades" row={row} part={research ? 'the share of the labels on the boundary' : null} viewBox={`0 0 ${CW} ${CH}`}
      data-shares={R.share.map(v => v.toFixed(6)).join(',')} data-current={`${n},${R.share[n].toFixed(6)}`}>
      <rect x={X0} y={Y0} width={r1(X(N_BLADES) - X0)} height={Y1 - Y0} style={{ fill: 'var(--line-2)' }} data-band={N_BLADES} />
      {[0, 0.25, 0.5, 0.75, 1].map(v => (
        <g key={v}>
          <line x1={X0} y1={Y(v)} x2={X1} y2={Y(v)} className="hair-2" />
          <text x={X0 - 6} y={r1(Y(v) + 3.5)} textAnchor="end" className="t-mono t-tiny t-muted">{`${100 * v}`}</text>
        </g>
      ))}
      {[0, 20, 40, 60, 80, 100, 120].map(k => <text key={k} x={X(k)} y={Y1 + 14} textAnchor="middle" className="t-mono t-tiny t-muted">{k}</text>)}
      <line x1={X0} y1={Y1} x2={X1} y2={Y1} className="hair" />
      <line x1={X0} y1={Y0} x2={X0} y2={Y1} className="hair" />
      {research && <>
        <text x={r1((X0 + X1) / 2)} y={CH - 6} textAnchor="middle" className="t-small t-muted">n, the generators of Cl(0,n)</text>
        <text x={12} y={r1((Y0 + Y1) / 2)} textAnchor="middle" transform={`rotate(-90 12 ${r1((Y0 + Y1) / 2)})`} className="t-small t-muted">% of the labels on the boundary</text>
        <text x={r1(X(N_BLADES / 2) + 3)} y={Y1 - 6} transform={`rotate(-90 ${r1(X(N_BLADES / 2) + 3)} ${Y1 - 6})`} className="t-micro t-muted" data-band-label="labels">counted on the labels</text>
        <text x={r1(X(N_BLADES) + 5)} y={Y1 - 6} className="t-micro t-muted" data-band-label="rule">by Proposition 5.1</text>
      </>}
      <polyline points={pts} className="stroke-ink" style={{ strokeWidth: 2, strokeLinejoin: 'round' }} data-curve={N_SHARE} />
      {research && notes.map(([k, t, nx, ny]) => (
        <g key={k} data-note={k}>
          <line x1={X(k)} y1={Y(R.share[k])} x2={X(nx)} y2={r1(Y(ny) + (ny < R.share[k] ? -9 : 3))} className="stroke-muted" style={{ strokeWidth: 1 }} />
          <circle cx={X(k)} cy={Y(R.share[k])} r={2.5} className="ink" />
          <text x={r1(X(nx) + 2)} y={Y(ny)} className="t-tiny">{`n = ${k}: ${t}`}</text>
        </g>
      ))}
      <circle cx={X(n)} cy={Y(R.share[n])} r={8} style={{ fill: 'var(--hi)' }} />
      <circle cx={X(n)} cy={Y(R.share[n])} r={4} className="ink" data-at={n} />
      {R.share.map((v, k) => (
        <rect key={k} x={r1(X(k) - (X1 - X0) / N_SHARE / 2)} y={Y0} width={r1((X1 - X0) / N_SHARE)} height={Y1 - Y0} style={{ fill: 'none', pointerEvents: 'all' }} data-n={k}>
          <title>{`n = ${k}: ${pct(v)} of the 2^${k} labels on the boundary`}</title>
        </rect>
      ))}
    </FigSvg>
  );
}

export default function DragonBlades({ params = {}, lens = null, level = 'research', theme, row }) {   // eslint-disable-line no-unused-vars
  const research = level !== 'learner';
  const [st, setSt] = useState(() => stateOf(params));
  useEffect(() => { setSt(stateOf(params)); }, [params.n]);   // eslint-disable-line react-hooks/exhaustive-deps
  const B = useMemo(() => dragonBlades(st.n), [st.n]);
  const R = boundaryRule(), lam = lambda();
  const first = useMemo(() => { for (let k = 0; k <= N_BLADES; k++) if (dragonBlades(k).interior.length) return k; return null; }, []);
  return (
    <div className="fig fig-dragon-blades" data-n={st.n}>
      <div className="fig-panels">
        <div className="fig-panel"><Dragon B={B} research={research} row={row} /></div>
        <div className="fig-panel"><Share R={R} n={st.n} research={research} row={row} /></div>
      </div>
      {research && (
        <Controls label="the boundary of the dragon">
          <Stepper label="n" value={st.n} min={N_MIN} max={N_BLADES} onChange={v => setSt({ n: v })} param="n" />
        </Controls>
      )}
      {research && (
        <dl className="fig-readout" data-readout="dragon-blades">
          <div data-interior={B.interior.length}><dt>interior</dt><dd>{`${group(B.interior.length)} of ${group(B.N)} labels`}</dd></div>
          <div data-boundary={B.boundary}><dt>boundary</dt><dd>{`${group(B.boundary)} (${pct(B.boundary / B.N)})`}</dd></div>
          <div data-types={`${R.types[R.stableFrom]},${R.stableFrom}`}><dt>types</dt><dd>{`${R.types[R.stableFrom]} from n = ${R.stableFrom} on`}</dd></div>
          <div data-lambda={cut(lam, 10)}><dt>λ</dt><dd>{`${cut(lam, 10)}…`}</dd></div>
          <div data-dim={cut(dimOf(lam), 10)}><dt>2 log₂ λ</dt><dd>{`${cut(dimOf(lam), 10)}…`}</dd></div>
        </dl>
      )}
      {research && (
        <p className="fig-note" data-legend="blades" data-first={first ?? ''}>
          {`Left: the path of Cl(0,n) divided by (1 − i)ⁿ, so that it runs from 0 to 1; each step is the long side of one triangle, and a label whose star of 15 triangles lies on the path is interior: ${B.interior.length > RINGS ? 'marked with a dot' : 'filled and ringed'}${first != null ? ` (none before n = ${first})` : ''}. Right: the share of the labels on the boundary for n up to ${N_SHARE}, counted on the labels in the band (n ≤ ${N_BLADES}) and by Duvall and Keesling's Proposition 5.1 beyond; the current n marked. The readout gives λ, the rate at which the boundary labels grow, and 2 log₂ λ.`}
        </p>
      )}
    </div>
  );
}
DragonBlades.meta = { id: 'dragon-blades', lenses: [], learner: false };
DragonBlades.params = [{}, { n: 13 }, { n: 15 }, { n: 16 }, { n: 2 }, { n: 10 }];
/** the numbers the figure draws: the interior labels at n, the counts, the shares of the rule, the types, λ and 2 log₂ λ */
DragonBlades.data = (params = {}) => {
  const { n } = stateOf(params), B = dragonBlades(n), R = boundaryRule(), lam = lambda();
  return { n, labels: B.N, interior: B.interior, boundary: B.boundary, distinct: B.distinct, shares: R.share.map(v => +v.toFixed(6)), types: R.types[R.stableFrom], stableFrom: R.stableFrom, lambda: +lam.toFixed(12), dim: +dimOf(lam).toFixed(12) };
};
