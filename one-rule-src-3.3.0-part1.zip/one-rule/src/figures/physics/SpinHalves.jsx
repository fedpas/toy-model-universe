// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-halves (step 5; caption row EQN-017; docs/PHYSICS_AUDIT.md SP4): Spin(2) keeps the halves, Spin(3) mixes them. In Cl(3,0) the all-plus spinor
// Φ₊ = B + I (the lecture's construction, i = I) is turned by a rotor: the plane rotor cos t + B sin t only gives it a phase (it stays in S⁺), the rotor
// with the extra reflection w, cos t + sin t · w v, moves part of it into S⁻ (equal at 45°, all in S⁻ at 90°, −Φ₊ at 180°). The weights of R Φ₊ in S⁺
// and S⁻ (the split by w X w⁻¹) are computed with the kernel (engines/physics/spinPhysics.js halvesAt, through spinEngine.spinors): two bars (S⁺ filled,
// S⁻ outlined) and the curve of the S⁻ weight over a full turn with the current t marked. Controls (v15 MixHalves): the rotor chips, the slider t in
// steps of 15°, play. Research level only.
import React, { useEffect, useMemo, useState } from 'react';
import { halvesAt, STEP_DEG } from '../../../engines/physics/spinPhysics.js';
import { FigSvg, Controls, Chips, Range, PlayButton, useReducedMotion, r1 } from '../kit.jsx';
import { f3 } from './p6kit.jsx';
import './translation.css';

const KINDS = { B: 'plane rotor (Spin 2)', w: 'with the extra reflection w (Spin 3)' };
const MAX = 48;
const okN = v => Number.isInteger(v) && v >= 0 && v <= MAX;

export default function SpinHalves({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okKind = v => v === 'B' || v === 'w';
  const [kind, setKind] = useState(okKind(params.rotor) ? params.rotor : 'w'), [n, setN] = useState(okN(params.t) ? params.t : 3), [playing, setPlaying] = useState(false), reduced = useReducedMotion();
  useEffect(() => { setKind(okKind(params.rotor) ? params.rotor : 'w'); }, [params.rotor]);
  useEffect(() => { setN(okN(params.t) ? params.t : 3); }, [params.t]);
  useEffect(() => {
    if (!playing) return undefined;
    if (reduced) { setPlaying(false); return undefined; }
    const id = setInterval(() => setN(x => (x >= MAX ? 0 : x + 1)), 110);
    return () => clearInterval(id);
  }, [playing, reduced]);
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => setN(x => (x >= MAX ? 0 : x + 1)) };
  const h = halvesAt(kind, n);
  const curve = useMemo(() => Array.from({ length: 25 }, (_, i) => halvesAt(kind, i)), [kind]);
  const W = 440, H = 196, bx = 92, bw = 300, cx0 = 40, cx1 = 420, cy0 = 112, cy1 = 166;
  const X = i => cx0 + ((cx1 - cx0) * i) / 24, Y = v => cy1 - (cy1 - cy0) * v;
  const nm = n % 24;
  return (
    <div className="fig fig-spin-halves" data-rotor={kind} data-t={n}>
      <FigSvg id="spin-halves" row={row} viewBox={`0 0 ${W} ${H}`}>
        <text x={8} y={16} className="t-small">{`R Φ₊ in Cl(3,0), Φ₊ = B + I · ${KINDS[kind]} · t = ${h.deg}°`}</text>
        <g data-half="plus" data-weight={f3(h.even)}>
          <text x={8} y={42} className="t-mono t-small">S⁺ (even)</text>
          <rect x={bx} y={31} width={bw} height={14} className="hair" />
          <rect x={bx} y={31} width={r1(bw * Math.min(1, h.even))} height={14} className="ink" />
          <text x={bx + bw + 6} y={42} className="t-mono t-tiny">{f3(h.even)}</text>
        </g>
        <g data-half="minus" data-weight={f3(h.odd)}>
          <text x={8} y={68} className="t-mono t-small">S⁻ (odd)</text>
          <rect x={bx} y={57} width={bw} height={14} className="hair" />
          <rect x={bx + 0.7} y={57.7} width={r1(Math.max(0, bw * Math.min(1, h.odd) - 1.4))} height={12.6} className="stroke-ink" style={{ strokeWidth: 1.4 }} />
          <text x={bx + bw + 6} y={68} className="t-mono t-tiny">{f3(h.odd)}</text>
        </g>
        <text x={8} y={92} className="t-mono t-tiny" data-verdict={h.mixes ? 'mixes' : 'keeps'}>{`${h.mixes ? 'mixes S⁺ and S⁻' : 'stays in S⁺'}${h.minus ? ' · R Φ₊ = −Φ₊' : h.plus ? ' · R Φ₊ = Φ₊' : ''}`}</text>
        {/* the S⁻ weight over a full turn, t = 0° … 360° */}
        <line x1={cx0} y1={cy1} x2={cx1} y2={cy1} className="hair" /><line x1={cx0} y1={cy0} x2={cx1} y2={cy0} className="hair-2" />
        <text x={cx0 - 4} y={cy0 + 3} textAnchor="end" className="t-mono t-micro t-muted">1</text><text x={cx0 - 4} y={cy1 + 3} textAnchor="end" className="t-mono t-micro t-muted">0</text>
        <polyline points={curve.map((c, i) => `${r1(X(i))},${r1(Y(c.odd))}`).join(' ')} className="stroke-ink" style={{ strokeWidth: 1.4 }} data-curve={curve.map(c => f3(c.odd)).join(',')} />
        {[0, 6, 12, 18, 24].map(i => <text key={i} x={r1(X(i))} y={cy1 + 12} textAnchor="middle" className="t-mono t-micro t-muted">{`${i * STEP_DEG}°`}</text>)}
        <circle cx={r1(X(nm))} cy={r1(Y(curve[nm].odd))} r={4} className="ink" data-now={nm} />
        <text x={cx1} y={cy0 - 6} textAnchor="end" className="t-tiny t-muted">S⁻ weight over a full turn</text>
      </FigSvg>
      {research && (
        <Controls label="rotor">
          <Chips label="rotor" items={['B', 'w']} value={kind} onPick={setKind} render={k => KINDS[k]} param="rotor" />
          <Range label="t" value={n} min={0} max={MAX} step={1} onChange={setN} display={v => `${v * STEP_DEG}°`} param="t" />
          <PlayButton player={player} />
        </Controls>
      )}
    </div>
  );
}
SpinHalves.meta = { id: 'spin-halves', lenses: [], learner: false };
SpinHalves.data = (params = {}) => { const kind = params.rotor === 'B' ? 'B' : 'w', n = okN(params.t) ? params.t : 3; return { rotor: kind, at: halvesAt(kind, n), turn: Array.from({ length: 25 }, (_, i) => halvesAt(kind, i)).map(c => ({ t: c.deg, even: c.even, odd: c.odd })) }; };
SpinHalves.params = [{}, { rotor: 'B', t: 6 }, { t: 6 }, { t: 12 }];
