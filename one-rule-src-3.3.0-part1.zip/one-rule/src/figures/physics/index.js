// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/index.js — the figures of the physics restoration (docs/PHYSICS_AUDIT.md, owners P4–P11), one registry file per owner; and those of
// the two calibrations of round 14 (docs/round14/STORY_ROUND.md §4.12, §6.3): p12 the shifted view (B3), p13 fibre and base (B4); and p14 the path of the
// clock sum and the boundary of the Lévy dragon (round 17, proofs pass 13a); and p15 Weil's index beside the clock walk (round 17, proofs pass 13c), so that
// they ride in the figures chunk (D47, D63).
import { P4_FIGURES } from './p4.js';
import { P5_FIGURES } from './p5.js';
import { P6_FIGURES } from './p6.js';
import { P7_FIGURES } from './p7.js';
import { P8_FIGURES } from './p8.js';
import { P9_FIGURES } from './p9.js';
import { P10_FIGURES } from './p10.js';
import { P11_FIGURES } from './p11.js';
import { P12_FIGURES } from './p12.js';
import { P13_FIGURES } from './p13.js';
import { P14_FIGURES } from './p14.js';
import { P15_FIGURES } from './p15.js';
export const PHYS_FIGURES = { ...P4_FIGURES, ...P5_FIGURES, ...P6_FIGURES, ...P7_FIGURES, ...P8_FIGURES, ...P9_FIGURES, ...P10_FIGURES, ...P11_FIGURES, ...P12_FIGURES, ...P13_FIGURES, ...P14_FIGURES, ...P15_FIGURES };
