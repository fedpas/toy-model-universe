// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure null-pair-moves (step 11, PRJ-003; docs/PHYSICS_AUDIT.md PR3–PR6): the null pair and the moves it makes mirrors of. Left: the plane of the null pair, e_m
// (square +1) across, e_p (square −1) up, and its two null diagonals ε = e_p + e_m (solid) and o = (e_m − e_p)/2 (dashed). Right: the points P(x) = o + x − ½x²ε
// of the first space axis at x = 0 … 3 and the table P(x)·P(y) = ½(x − y)² — every number a kernel product (engines/physics/projective.js nullPair). Beside it:
// the moves as products of mirrors (translation 1 + ½tε, rotation ab, dilation 1 + u e_p e_m, inversion in P(c) − ½r²ε, reflection in m + δε, and two parallel
// planes, two concentric spheres), each applied by its sandwich to the rational point (1, 2) and compared with the map it should be; the conformal generators
// T_i = e_iε, K_i = e_io, D = e_pe_m with [D, T] = 2T and [D, K] = −2K (kernel commutators); and what projective_selfcheck.py stored (projective.json: the null
// pair, the motors, the conformal algebra, the counts n = 2 … 8, the doubling Cl(k, k) = M_{2^k}(ℝ), the table of what was checked), read from
// content/stored_p8.json, a rung it lacks marked "not stored" (D37). The base and n are the chips of the step (v15 ProjectiveSection.jsx); "from the top" (D37)
// runs the moves at n = 8 and shows the images at n as the same. Learner level: the plane and the points in words, the moves by the mirrors they take.
import React, { useState, useEffect, useMemo } from 'react';
import { FigSvg, Controls, Chips, r1, pick, isIn, tx } from '../kit.jsx';
import { nullPair, moves, conformal, doubling } from '../../../engines/physics/projective.js';
import { PROJECTIVE } from '../../../engines/stored.js';
import { useStored, peekStored, Tex, useKatex, printing, printLabel, TopToggle, Table, Fold, Loading, D37_LENSES, tick, AXES } from './p8kit.jsx';

const NSN = [2, 3, 4, 5, 6, 7, 8], KINDS = ['space', 'lorentz'], TOP = 8;
const frac = v => { const h = Math.round(v * 2); return h % 2 ? `${h}/2` : String(h / 2); };
/** a point of the base by its non-zero coordinates, each named by its axis */
const num = v => String(+v.toFixed(3)).replace('-', '−');
const pt = (a, ax) => a.map((v, i) => (Math.abs(v) > 1e-9 ? `${ax(i)} = ${num(v)}` : null)).filter(Boolean).join(', ') || 'the origin';
/** the moves: research name, versor (TeX, plain), mirrors, learner words, the stored flag that names the pair of mirrors */
const MOVES = {
  translation: ['translation by t', '1 + \\tfrac12 t\\,\\varepsilon', '1 + ½tε', '2 parallel planes', 'slide · 2 parallel walls', 'translation_is_two_parallel_planes'],
  rotation: ['rotation', 'a\\,b', 'ab', '2 planes through a point', 'turn · 2 walls through a point', null],
  dilation: ['dilation', '1 + u\\,e_pe_m', '1 + u e_p e_m', '2 concentric spheres', 'grow or shrink · 2 balls, one centre', 'dilation_is_two_concentric_spheres'],
  inversion: ['inversion in a sphere', 'P(c) - \\tfrac12 r^2\\varepsilon', 'P(c) − ½r²ε', '1 sphere', 'turn inside out · 1 ball', null],
  plane: ['reflection in a plane', 'm + \\delta\\varepsilon', 'm + δε', '1 plane', 'mirror · 1 wall', null],
  'two-planes': ['two parallel planes', '(m + \\delta_2\\varepsilon)(m + \\delta_1\\varepsilon)', '(m + δ₂ε)(m + δ₁ε)', 'a translation', 'two walls · a slide', null],
  'two-spheres': ['two concentric spheres', 'S_2 S_1', 'S₂S₁', 'a dilation', 'two balls · grow or shrink', null],
};

export default function NullPairMoves({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner', how = printing(lens, mode, level);
  const init = () => ({ kind: pick(params.kind, isIn(KINDS), 'space'), n: pick(params.n, isIn(NSN), 3), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.kind, params.n, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { kind, n, top } = st, set = p => setSt(x => ({ ...x, ...p }));
  const katex = useKatex(research), S = useStored();
  const NP = useMemo(() => nullPair(kind, n), [kind, n]), MV = useMemo(() => moves(kind, n), [kind, n]), CF = useMemo(() => conformal(kind, n), [kind, n]);
  const MT = useMemo(() => (top ? moves(kind, TOP) : null), [kind, top]);
  const key = `${kind},${n}`, np = S ? S.pj.null_pair[key] : null, cf = S ? S.pj.conformal[key] : null, mo = S ? S.pj.motors[key] : null, cnt = S ? S.pj.counts[n] : null;
  const axOf = i => (how === 'letters' ? AXES[kind === 'space' ? i + 1 : i] : printLabel(1 << i, how, n)), axName = axOf(NP.axis), em = how === 'letters' ? 'eₘ' : printLabel(1 << n, how, n + 2), ep = how === 'letters' ? 'eₚ' : printLabel(1 << (n + 1), how, n + 2);
  const X = v => 236 + v * 44, TX = 240, TY = 40, CW = 40, RH = 22;
  const sameTop = MT ? MV.moves.every((m, i) => m.image && MT.moves[i].image && m.image.slice(0, 2).every((v, j) => Math.abs(v - MT.moves[i].image[j]) < 1e-9)) : null;
  return (
    <div className="fig fig-null-pair-moves gp-split">
      <FigSvg id="null-pair-moves" row={row} viewBox="0 0 420 230">
        <g transform="translate(18, 22)" data-null-pair={key} data-eps-square={NP.epsSquare} data-o-square={NP.oSquare} data-eps-dot-o={NP.epsDotO}>
          <line x1={0} y1={90} x2={170} y2={90} className="hair" /><line x1={85} y1={185} x2={85} y2={0} className="hair" />
          <line x1={20} y1={165} x2={150} y2={15} className="stroke-ink" style={{ strokeWidth: 2.4 }} data-diagonal="eps" />
          <line x1={20} y1={15} x2={150} y2={165} className="stroke-ink" style={{ strokeWidth: 2.4, strokeDasharray: '7 4' }} data-diagonal="o" />
          <text x={154} y={16} className="t-head">{research ? 'ε' : 'length 0'}</text>
          <text x={154} y={174} className="t-head">{research ? 'o' : 'length 0'}</text>
          <text x={170} y={84} textAnchor="end" className="t-mono t-small">{research ? `${em}² = +1` : '+1'}</text>
          <text x={90} y={10} className="t-mono t-small">{research ? `${ep}² = −1` : '−1'}</text>
        </g>
        <g data-points={NP.points.map(p => p.x).join(',')}>
          <text x={TX} y={14} className="t-small t-bold">{research ? 'P(x)·P(y)' : 'points 0 … 3'}</text>
          {[0, 1, 2, 3].map(j => <text key={'h' + j} x={TX + 20 + j * CW + CW / 2} y={TY - 8} textAnchor="middle" className="t-mono t-tiny">{j}</text>)}
          {NP.table.map((r, i) => (
            <g key={i}>
              <text x={TX + 12} y={TY + i * RH + 15} textAnchor="middle" className="t-mono t-tiny">{i}</text>
              {r.map((v, j) => <g key={j} data-dot={`${i},${j}`} data-value={v}><rect x={TX + 20 + j * CW + 1} y={TY + i * RH + 1} width={CW - 2} height={RH - 2} rx={2} className={v === 0 ? 'on-panel' : 'ink'} style={v === 0 ? { stroke: 'var(--line)' } : { fillOpacity: Math.min(0.1 + v / 9, 0.6) }} /><text x={TX + 20 + j * CW + CW / 2} y={TY + i * RH + 15} textAnchor="middle" className="t-mono t-tiny">{frac(v)}</text></g>)}
            </g>
          ))}
          <line x1={X(0) - 8} y1={160} x2={X(3) + 14} y2={160} className="hair" />
          {NP.points.map(p => <g key={p.x} data-point={p.x} data-square={p.square} data-eps-coef={p.eps}><circle cx={X(p.x)} cy={160} r={4.5} className="ink" /><text x={X(p.x)} y={176} textAnchor="middle" className="t-mono t-tiny">{research ? `P(${p.x})` : p.x}</text></g>)}
          <text x={X(3) + 18} y={163} className="t-mono t-tiny">{axName}</text>
          <text x={TX} y={200} className="t-tiny t-muted">{research ? tx(`P(x) = o + x e_{${axName}} + ½x²ε · all null`) : 'each point has length 0'}</text>
        </g>
      </FigSvg>
      <Controls label={research ? 'one more pair of generators' : 'two more directions'}>
        <Chips label={research ? 'base' : 'directions'} items={KINDS} value={kind} onPick={v => set({ kind: v })} render={k => (research ? k : k === 'space' ? 'space only' : 'space and time')} param="kind" />
        <Chips label="n" items={NSN} value={n} onPick={v => set({ n: v })} param="n" mono />
        <TopToggle on={top} onChange={v => set({ top: v })} research={research} top={TOP} />
      </Controls>
      <div className="gp-side">
        {research ? (
          <>
            <p className="gp-read" data-line="null"><Tex katex={katex} tex={`\\varepsilon = e_p + e_m,\\ o = \\tfrac12(e_m - e_p):\\ \\varepsilon^2 = ${NP.epsSquare},\\ o^2 = ${NP.oSquare},\\ \\varepsilon\\cdot o = ${NP.epsDotO}`} text={`ε = e_p + e_m, o = ½(e_m − e_p): ε² = ${NP.epsSquare}, o² = ${NP.oSquare}, ε·o = ${NP.epsDotO}`} /></p>
            <p className="gp-read" data-line="points" data-points-tested={np ? np.points_tested : ''}><Tex katex={katex} tex={'P(x)\\cdot P(y) = \\tfrac12 (x-y)^2'} text="P(x)·P(y) = ½(x − y)²" /> <span className="gp-k">points tested (stored)</span> <b>{np ? np.points_tested : S ? 'not stored' : '…'}</b></p>
          </>
        ) : null}
        <p className="gp-read" data-mirrors={cnt ? cnt.planes_to_move_a_point : ''} data-motors={mo ? String(mo.at_most_n_plus_1) : ''}>
          <span className="gp-k">{research ? `plane mirrors for any isometry of ℝ${n > 9 ? n : '⁰¹²³⁴⁵⁶⁷⁸⁹'[n]}: at most` : 'walls for any move that keeps distances: at most'}</span> <b>{cnt ? cnt.planes_to_move_a_point : '…'}</b>
          {research ? <><span className="gp-k">products tested</span> <b>{mo ? `${mo.products_tested} ${tick(mo.at_most_n_plus_1)}` : S ? 'not stored' : '…'}</b></> : null}
        </p>
        {top ? <p className="gp-read" data-same-top={sameTop ? 1 : 0}><span className="gp-k">{research ? `the same moves at n = ${TOP}: images` : `inside ${TOP} directions: the same`}</span> <b>{tick(sameTop)}</b></p> : null}
        {research
          ? <p className="gp-read" data-on-t={CF.onT} data-on-k={CF.onK} data-stored-t={cf ? cf.dilation_eigenvalue_on_T : ''} data-stored-k={cf ? cf.dilation_eigenvalue_on_K : ''}><Tex katex={katex} tex={`D = e_pe_m,\\ T_i = e_i\\varepsilon,\\ K_i = e_io:\\ [D, T_i] = ${CF.onT}\\,T_i,\\ [D, K_i] = ${CF.onK}\\,K_i`} text={`[D, T] = ${CF.onT} T, [D, K] = ${CF.onK} K`} /> <span className="gp-k">conformal, stored</span> <b>{cf ? `${cf.generators} = J ${cf.rotations} + P ${cf.translations} + K ${cf.special_conformal} + D ${cf.dilation} · Killing (${cf.killing.positive}, ${cf.killing.negative}, ${cf.killing.zero})` : S ? 'not stored' : '…'}</b></p>
          : <p className="gp-read" data-conformal={cf ? cf.generators : ''}><span className="gp-k">moves</span> <b>{cf ? `${cf.generators} = ${cf.rotations} rotations + ${cf.translations} translations + ${cf.special_conformal} special moves + ${cf.dilation} dilatation` : S ? 'not stored' : '…'}</b></p>}
        {!S ? <Loading /> : null}
        {research && S ? (
          <>
            <Fold title={`The counts, n = ${top ? '8 … 2' : '2 … 8'}`} name="counts">
              <Table name="pj-counts" caption="projective.json counts (projective_selfcheck.py)" cols={[['n', 'n'], ['g', 'generators C(n+1,2)'], ['e', 'Euclid or Poincaré'], ['c', 'conformal C(n+2,2)'], ['p', 'PGA dimension'], ['cg', 'CGA dimension'], ['m', 'plane mirrors for any isometry']]}
                rows={(top ? [...NSN].reverse() : NSN).map(k => { const c = S.pj.counts[k]; return { key: k, cur: k === n, cells: c ? { n: k, g: c.ladder_generators, e: c.euclid_generators, c: c.conformal_generators, p: c.pga_dimension, cg: c.cga_dimension, m: c.planes_to_move_a_point } : { n: k } }; })} />
            </Fold>
            <Fold title="Two more generators: Cl(k, k)" name="doubling">
              <Table name="pj-doubling" caption="projective.json doubling · the algebra from the clock" cols={[['k', 'pairs k'], ['a', 'algebra Cl(k,k)'], ['m', 'matrix size'], ['d', 'dimension'], ['f', 'all real matrices']]}
                rows={Object.entries(S.pj.doubling).map(([kk, v]) => { const k = +kk.split(',')[0]; return { key: kk, cells: { k, a: `Cl(${k},${k}) = ${doubling(k).algebra}`, m: v.matrix_size, d: v.algebra_dimension, f: tick(v.is_full_matrix_algebra_over_R) } }; })} />
            </Fold>
            <Fold title="What was checked, and where" name="checked">
              <Table name="pj-checked" caption="projective.json, both bases" cols={[['n', 'n'], ['l', 'ladder s = 0, ±1'], ['p', 'null pair, points'], ['mv', 'the five moves'], ['g', 'PGA inside CGA'], ['mi', 'plane mirrors ≤ n + 1'], ['c', 'conformal algebra']]}
                rows={[2, 3, 4].map(k => { const both = KINDS, g = (grp, kd) => S.pj[grp][`${kd},${k}`]; return { key: k, cur: k === n, cells: {
                  n: k, l: tick(both.every(kd => [-1, 0, 1].every(sv => PROJECTIVE.ladder[`${kd},${k},${sv}`].jacobi) && S.pj.contraction[`${kd},${k}`])),
                  p: tick(both.every(kd => g('null_pair', kd).points_tested === 12)),
                  mv: tick(both.every(kd => g('null_pair', kd).translation_is_two_parallel_planes && g('null_pair', kd).dilation_is_two_concentric_spheres)),
                  g: k <= 3 ? tick(both.every(kd => g('pga', kd).homomorphism && g('pga', kd).injective)) : null,
                  mi: k <= 3 ? tick(both.every(kd => g('motors', kd).at_most_n_plus_1)) : null,
                  c: tick(both.every(kd => g('conformal', kd).jacobi && g('conformal', kd).dilation_eigenvalue_on_T === '2' && g('conformal', kd).dilation_eigenvalue_on_K === '-2')) } }; })} />
            </Fold>
          </>
        ) : null}
      </div>
      <div className="gp-wide">
          <div className="fig-scroll">
            <table className={research ? 'gp-table' : 'gp-table gp-words'} data-table="moves">
              <caption>{research ? `moves as products of mirrors, applied to the point ${pt(MV.point, axOf)} · ${kind} base, n = ${n}` : 'moves made of mirrors'}</caption>
              <thead><tr>{(research ? ['move', 'versor', 'mirrors', 'image', 'kernel', 'stored'] : ['move', 'checked']).map(h => <th key={h} scope="col">{h}</th>)}</tr></thead>
              <tbody>{MV.moves.map(m => { const M = MOVES[m.id], flag = M[5] ? (np ? np[M[5]] : null) : null; return (
                <tr key={m.id} data-move={m.id} data-ok={m.ok ? 1 : 0} data-image={m.image ? m.image.map(v => +v.toFixed(9)).join(',') : ''} data-flag={flag === null ? '' : String(flag)}>
                  {research ? <><td>{M[0]}</td><td><Tex katex={katex} tex={M[1]} text={M[2]} /></td><td>{M[3]}</td><td>{m.image ? pt(m.image, axOf) : '—'}</td><td>{tick(m.ok)}</td><td>{M[5] ? (np ? tick(flag) : 'not stored') : ''}</td></>
                    : <><td>{M[4]}</td><td>{tick(m.ok)}</td></>}
                </tr>); })}</tbody>
            </table>
          </div>
      </div>
    </div>
  );
}
NullPairMoves.meta = { id: 'null-pair-moves', lenses: D37_LENSES, learner: true };
NullPairMoves.params = [{}, { kind: 'lorentz', n: 2 }, { n: 4 }, { kind: 'lorentz', n: 6 }, { n: 8, top: true }, { kind: 'lorentz', n: 3, top: true }];
/** the numbers the figure draws, for the frame's data download */
NullPairMoves.data = (params = {}) => {
  const kind = pick(params.kind, isIn(KINDS), 'space'), n = pick(params.n, isIn(NSN), 3), S = peekStored(), k = `${kind},${n}`;
  return { kind, n, nullPair: nullPair(kind, n), moves: moves(kind, n).moves.map(({ id, mirrors, image, expect, ok }) => ({ id, mirrors, image, expect, ok })), conformal: conformal(kind, n), stored: S ? { null_pair: S.pj.null_pair[k] || null, conformal: S.pj.conformal[k] || null, motors: S.pj.motors[k] || null, counts: S.pj.counts[n] || null } : null };
};
