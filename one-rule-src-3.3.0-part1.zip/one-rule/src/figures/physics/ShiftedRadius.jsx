// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure shifted-radius (Calibration 3, step 8 of `shifted`; caption ATY-054, states ATY-054 and ATY-055; docs/round14/STORY_ROUND.md §6.3, owner B3): the
// radius φ = e^σ of the fifth direction on a de Sitter base of rate H obeys (4.3); its homogeneous solutions are e^{rt} with r² + 3Hr = εκ², the base's
// friction 3Hr included, where the paper prints e^{±√ε κt} (4.4), the case H = 0. Drawn on a log scale (each rate a straight line): the two rates of each
// stored setting (H, εκ²) of se.DS5, r = −pH from the stored exponents p of φ = (−η)^p, each checked against the equation (engines/physics/shifted.js
// radiusData) and the root that solves the whole five-dimensional equation marked; dashed, the printed (4.4) where its rate is real (its exponents
// printed only where the log states them). Below, the numbers of se.TIME as stored: ħ/kc, the paper's value and the ratio, the e-folding times, numbers
// only (the coincidence with the age of the universe is the paper's remark). Stored table: content/stored_shifted.json ds5, time (loaded on demand: D34).
// Control: the setting (chips). The learner level speaks of the size growing and shrinking, and gives the times in billions of years. Tokens only.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, pick, r1, tx } from '../kit.jsx';
import { Loading } from './fureyKit.jsx';
import { useShifted, peekShifted } from './ShiftedQuarterTurn.jsx';
import { radiusData, timeData } from '../../../engines/physics/shifted.js';

const SETTINGS = ['1,4', '1,10', '1,-2', '1/2,1'];
const keyOf = s => `${s.H},${s.ek2}`;
const X0 = 44, X1 = 232, TMAX = 1.5, Y0 = 100, YS = 17.5, LMAX = 4;
const X = t => r1(X0 + ((X1 - X0) * t) / TMAX), Y = l => r1(Y0 - YS * l);
/** a line ln φ = r t from t = 0 until it leaves the frame (|ln φ| ≤ 4) or t = 1.5 */
const seg = r => { const t = Math.min(TMAX, r === 0 ? TMAX : LMAX / Math.abs(r)); return { t, x2: X(t), y2: Y(r * t) }; };
const minus = s => String(s).replace(/-/g, '−');
/** "3.3356e+17" → "3.3356 × 10^{17}" for kit.tx */
const sci = s => { const [m, e] = String(s).split('e'); return `${m} × 10^{${minus(String(Number(e)))}}`; };
/** "1.0570e+10" (years) → "10.570" (billions of years), by moving the decimal point of the printed mantissa (no rounding) */
function billions(s) {
  const [m, e] = String(s).split('e'), shift = Number(e) - 9, [a, b = ''] = m.split('.'), digits = a + b, at = a.length + shift;
  return at >= digits.length ? digits.padEnd(at, '0') : `${digits.slice(0, at)}.${digits.slice(at)}`;
}

export default function ShiftedRadius({ params = {}, level = 'research', row }) {
  const research = level !== 'learner';
  const [set, setSet] = useState(pick(params.setting, v => SETTINGS.includes(v), '1,4'));
  useEffect(() => { setSet(pick(params.setting, v => SETTINGS.includes(v), '1,4')); }, [params.setting]);
  const T = useShifted(params), all = T ? radiusData(T) : null, S = all ? all.find(x => keyOf(x) === set) : null, TM = T ? timeData(T) : null;
  const idx = SETTINGS.indexOf(set) + 1;
  return (
    <div className="fig fig-shifted-radius">
      <FigSvg id="shifted-radius" row={row} viewBox="0 0 460 270">
        <text x={4} y={14} className="t-small t-bold">{research ? 'the radius of the fifth direction on a de Sitter base' : 'the size of a fifth direction, over time'}</text>
        <line x1={X0} y1={Y(LMAX)} x2={X0} y2={Y(-LMAX)} className="hair" />
        <line x1={X0} y1={Y0} x2={X1} y2={Y0} className="hair" />
        <text x={X0 - 4} y={Y(LMAX) + 6} textAnchor="end" className="t-micro t-muted">{research ? 'ln φ' : 'size'}</text>
        <text x={X0 - 4} y={Y(-LMAX)} textAnchor="end" className="t-micro t-muted">{research ? '' : '(log)'}</text>
        <text x={X0 + 6} y={Y(-LMAX) + 4} className="t-micro t-muted">{research ? 'time t →' : 'time →'}</text>
        {S ? (
          <g data-setting={set} data-h={S.H} data-ek2={S.ek2} data-rates={S.roots.map(x => x.r).join(',')} data-p={S.roots.map(x => x.p).join(',')} data-solves={S.roots.every(x => x.solves) ? 1 : 0} data-einstein={S.roots.filter(x => x.einstein).map(x => x.r).join(',')}>
            {S.roots.map((x, i) => { const g = seg(x.rNum); return (
              <g key={i} data-rate={x.r}>
                <line x1={X(0)} y1={Y(0)} x2={g.x2} y2={g.y2} className="stroke-ink" strokeWidth={x.einstein ? 2.4 : 1.6} />
                <text x={g.x2 + 4} y={g.y2 + 4} className="t-tiny" data-value={x.r}>{research ? `r = ${minus(x.r)}${x.einstein ? ' (5D)' : ''}` : x.rNum > 0 ? 'grows' : 'shrinks'}</text>
              </g>
            ); })}
            {S.printed.real && S.printed.rates.map((r, i) => { const g = seg(r); return (
              <g key={'p' + i} data-printed-rate={S.printed.stored ? S.printed.stored[i] : ''}>
                <line x1={X(0)} y1={Y(0)} x2={g.x2} y2={g.y2} className="stroke-muted" strokeDasharray="5 3" strokeWidth={1.4} />
                {i === 0 && <text x={g.x2 - 4} y={g.y2 - 4} textAnchor="end" className="t-micro t-muted">{research ? (S.printed.stored ? tx(`printed e^{±${S.printed.stored[0]}t}`) : 'printed (4.4)') : 'as printed'}</text>}
              </g>
            ); })}
          </g>
        ) : <Loading x={X0} y={Y0 - 16} w={X1 - X0} h={32} what="stored results" />}
        {S && (
          <g>
            <rect x={292} y={28} width={164} height={142} rx={6} className="on-panel" style={{ stroke: 'var(--fg)' }} />
            <text x={300} y={46} className="t-small t-bold">{research ? tx(`H = ${S.H}, εκ^2 = ${minus(S.ek2)}`) : `setting ${idx} of 4`}</text>
            {research ? [
              tx(`φ = (−η)^p, p = ${S.roots.map(x => minus(x.p)).join(', ')} (stored)`),
              tx(`e^{rt}, r = −pH = ${S.roots.map(x => minus(x.r)).join(', ')}`),
              tx(`r^2 + 3Hr = εκ^2: ${S.roots.every(x => x.solves) ? 'both hold' : 'fails'}`),
              S.roots.some(x => x.einstein) ? tx(`r = ${S.roots.filter(x => x.einstein).map(x => x.r).join(', ')} solves all 25 components`) : 'the 44 component only',
              S.printed.real ? tx('dashed: (4.4), e^{±√ε κt}, H = 0') : tx('(4.4) has no real rate here (ε = −1)'),
            ].map((t, i) => <text key={i} x={300} y={66 + i * 18} className="t-tiny">{t}</text>)
              : ['solid: computed on the labels,', 'with the drag of the', 'expanding base', S.printed.real ? 'dashed: as the paper prints it,' : 'the paper’s form gives no', S.printed.real ? 'without that drag' : 'growth or decay here']
                .map((t, i) => <text key={i} x={300} y={66 + i * 16} className="t-tiny">{t}</text>)}
          </g>
        )}
        {TM ? (
          <g data-time={TM.stored.years}>
            <text x={4} y={198} className="t-tiny" data-seconds={TM.stored.seconds} data-years={TM.stored.years} data-paper={TM.stored.paper.years} data-ratio={TM.stored.paper.ratio}>
              {research ? tx(`ħ/kc for k/ħ = ${sci(TM.stored.k)} cm^{−1}: ${sci(TM.stored.seconds)} s = ${sci(TM.stored.years)} years; the paper's ${sci(TM.stored.paper.years)}, ratio ${TM.stored.paper.ratio}`)
                : `the time scale of the paper's constant: ${billions(TM.stored.years)} billion years`}
            </text>
            <text x={4} y={216} className="t-tiny" data-efold={TM.stored.efold.map(e => `${e.r}:${e.years}`).join(',')}>
              {research ? tx(`e-folding times ${TM.stored.efold.map(e => `${sci(e.years)} years (r = ${e.r.includes('/') ? `κ/${e.r.split('/')[1]}` : `${e.r}κ`})`).join(' and ')}`)
                : `the size grows e-fold in ${TM.stored.efold.map(e => billions(e.years)).join(' or ')} billion years`}
            </text>
            <text x={4} y={234} className="t-micro t-muted">{research ? 'numbers only: the paper sets this time beside the age of the universe; that comparison is not computed' : 'numbers only: the paper compares this time with the age of the universe'}</text>
          </g>
        ) : null}
      </FigSvg>
      <Controls label="radius">
        <Chips label="setting" items={SETTINGS} value={set} onPick={setSet} param="setting" render={s => (research ? `(${minus(s.replace(',', ', '))})` : `setting ${SETTINGS.indexOf(s) + 1}`)} />
      </Controls>
    </div>
  );
}
ShiftedRadius.meta = { id: 'shifted-radius', lenses: [], learner: true };
ShiftedRadius.params = [{}, { setting: '1,10' }, { setting: '1,-2' }, { setting: '1/2,1' }];
/** the numbers the figure draws, for the frame's data download */
ShiftedRadius.data = (params = {}) => {
  const T = peekShifted(params), set = SETTINGS.includes(params.setting) ? params.setting : '1,4';
  if (!T) return { loading: true, setting: set };
  const S = radiusData(T).find(x => keyOf(x) === set);
  return { setting: set, H: S.H, ek2: S.ek2, roots: S.roots.map(({ p, r, solves, einstein }) => ({ p, r, solves, einstein })), printed: { real: S.printed.real, stored: S.printed.stored }, time: timeData(T).stored };
};
