// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure coupling-ring (step 6, hero of steps/coupling; audit CP1, CP4): one equation of the coupled Dirac–Maxwell system D = ∇ψJ − eAψ − mψγ₀ = 0 on
// Cl(1, n−1), drawn at the odd blade t (its γ₀ component). Around t, the inner ring: its n even neighbours, which carry the coupling terms A_k ψ (one per axis, a
// filled dot; the time one, a double mark, also carries the mass term mψγ₀); the outer ring: the same neighbours moved by J = γ₂γ₁ (the bits xy, mask 6), which
// carry the derivative terms ∂_k ψ (a ring). Every blade and sign is the kernel's (engines/physics/gauge.js couplingRing, the generalisation of diracPic); the
// counts beside it are the stored ones (content/stored_p7.json cp.ladder, coupling_selfcheck.py), which tests/physics/p7.test.mjs recomputes through the kernel.
// n = 1, 2 have no J, so no charged equation and no ring (v15 drew none). Port of v15 CouplingSection.jsx Ring, with its chips n = 1 … 8. D37: the chips run from the
// lowest stored cell up; "from the top" draws the ring of Cl(1,7) and the chosen n as its restriction (the terms of the first n axes, the others faint). Lenses:
// clifford, simplex, cube, demicube, prime print the blades in their base; simplex draws the corner simplex of the coupling terms (our reading, CPL-010), cube names
// the cube edge of each spoke, demicube draws the J moves as demicube edges. Learner level: words only (the push of the field, the change along each direction).
import React, { useEffect, useMemo, useState } from 'react';
import { couplingRing, labelIn, restricts, axName, COUPLING_NS } from '../../../engines/physics/gauge.js';
import { FigSvg, Controls, r1 } from '../kit.jsx';
import { useStored, lensKey, intIn, Tex, Rungs, TopSwitch, Readout, Legend, useKatexAt } from './GaugeKit.jsx';

const TOP = 8, C = 180, R1 = 74, R2 = 134;
const sgn = s => (s < 0 ? '−' : '+');
/** the equation at t as TeX and as plain text: the derivative terms, then −e times the coupling terms, then the mass term, each with the kernel's sign */
export function ringEquation(R) {
  const nm = axName;
  const join = (terms, tex) => terms.map((t, i) => (i === 0 ? (t.sign < 0 ? (tex ? '-' : '−') : '') : t.sign < 0 ? (tex ? ' - ' : ' − ') : ' + ') + (tex ? t.tex : t.plain)).join('');
  const d = R.outer.map(t => ({ sign: t.sign, tex: `\\partial_{${t.axis}}\\psi_{${nm(t.blade)}}`, plain: `∂${t.axis} ψ_${nm(t.blade)}` }));
  const a = R.inner.map(t => ({ sign: t.sign, tex: `A_{${t.axis}}\\psi_{${nm(t.blade)}}`, plain: `A${t.axis} ψ_${nm(t.blade)}` }));
  const mTex = `${R.mass.sign < 0 ? '+' : '-'} m\\,\\psi_{${nm(R.mass.blade)}}`, mPlain = `${R.mass.sign < 0 ? '+' : '−'} m ψ_${nm(R.mass.blade)}`;
  return { tex: `${join(d, true)} - e\\,(${join(a, true)}) ${mTex} = 0`, plain: `${join(d, false)} − e (${join(a, false)}) ${mPlain} = 0` };
}

export default function CouplingRing({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => ({ n: intIn(params.n, COUPLING_NS, params.top === true ? TOP : 4), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.n, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { n, top } = st, drawN = top ? TOP : n;
  const R = useMemo(() => couplingRing(drawN), [drawN]), Rn = useMemo(() => couplingRing(n), [n]);
  const restr = useMemo(() => (top && n < TOP ? restricts('coupling', n, TOP) : null), [top, n]);
  const lad = S ? S.cp.ladder[String(n)] : null;
  const name = m => labelIn(L, m, { n: drawN, kind: 'st' });
  const ang = k => ((-90 + (360 * k) / drawN) * Math.PI) / 180, P = (k, r) => [C + r * Math.cos(ang(k)), C + r * Math.sin(ang(k))];
  const live = k => !top || (Rn.J.exists && k < n), drawRing = R.J.exists;
  const fs = drawN > 6 ? 't-tiny' : 't-small';
  const eqn = Rn.J.exists ? ringEquation(Rn) : null;
  const termsOf = kd => (kd === 'A' ? Rn.inner.length : kd === 'd' ? Rn.outer.length : 1);
  return (
    <div className="fig fig-coupling-ring g7-split" data-n={n} data-top={top ? 'true' : 'false'} data-lens={L || ''}>
      <div className="g7-left">
        <FigSvg id="coupling-ring" row={row} viewBox="0 0 360 360" data-drawn={drawN} data-terms={Rn.terms}>
          {!drawRing && <circle cx={C} cy={C} r={R1} className="g7-hair g7-dash" data-empty="1" />}
          {drawRing && L === 'simplex' && R.inner.flatMap((a, i) => R.inner.slice(i + 1).map(b => (
            <g key={`s${a.k}-${b.k}`} className={live(a.k) && live(b.k) ? '' : 'g7-faint'} data-simplex={`${a.blade},${b.blade}`}>
              <line x1={r1(P(a.k, R1)[0])} y1={r1(P(a.k, R1)[1])} x2={r1(P(b.k, R1)[0])} y2={r1(P(b.k, R1)[1])} className="g7-line" />
              <line x1={r1(P(a.k, R2)[0])} y1={r1(P(a.k, R2)[1])} x2={r1(P(b.k, R2)[0])} y2={r1(P(b.k, R2)[1])} className="g7-hair" />
            </g>
          )))}
          {drawRing && R.inner.map(t => {
            const o = R.outer[t.k], [x1, y1] = P(t.k, R1), [x2, y2] = P(t.k, R2), on = live(t.k);
            return (
              <g key={'k' + t.k} className={on ? '' : 'g7-faint'} data-axis={t.k} data-live={on ? 1 : 0}>
                <line x1={C} y1={C} x2={r1(x1)} y2={r1(y1)} className="g7-line is-lit" />
                <line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className={'g7-line' + (L === 'demicube' ? ' is-lit' : ' g7-dash')} data-jmove={`${t.blade},${o.blade}`} />
                {L === 'cube' && <text x={r1(C + (x1 - C) * 0.5)} y={r1(C + (y1 - C) * 0.5 + 3)} textAnchor="middle" className="t-micro t-mono g7-halo" data-edge={t.k}>{t.axis}</text>}
              </g>
            );
          })}
          {drawRing && R.inner.map(t => {
            const o = R.outer[t.k], [x1, y1] = P(t.k, R1), [x2, y2] = P(t.k, R2), on = live(t.k), [lx, ly] = P(t.k, R2 + (drawN > 6 ? 19 : 17));
            const px = -Math.sin(ang(t.k)), py = Math.cos(ang(t.k)), ix = x1 + px * 13, iy = y1 + py * 13 + 3.5, side = px > 0.3 ? 1 : px < -0.3 ? -1 : 0;   // beside the node, on the clockwise side of its spoke
            return (
              <g key={'n' + t.k} className={on ? '' : 'g7-faint'}>
                <g data-term="A" data-axis={t.k} data-blade={t.blade} data-sign={t.sign} {...(t.k === 0 ? { 'data-mass': R.mass.blade, 'data-mass-sign': R.mass.sign } : {})}>
                  {t.k === 0 && <circle cx={r1(x1)} cy={r1(y1)} r={8.2} className="g7-ring" />}
                  <circle cx={r1(x1)} cy={r1(y1)} r={t.k === 0 ? 4.4 : 5.4} className="g7-dot" />
                  <title>{research ? `A${t.axis} ψ_${name(t.blade)} (${sgn(t.sign)})${t.k === 0 ? ` and m ψ_${name(R.mass.blade)} (${sgn(R.mass.sign)})` : ''}` : `push of the field along ${t.axis}${t.k === 0 ? ', and the mass' : ''}`}</title>
                </g>
                <text x={r1(ix)} y={r1(iy)} textAnchor={side > 0 ? 'start' : side < 0 ? 'end' : 'middle'} className={`${fs} t-mono g7-halo`} data-label={t.blade}>{name(t.blade)}</text>
                <g data-term="d" data-axis={o.k} data-blade={o.blade} data-sign={o.sign}>
                  <circle cx={r1(x2)} cy={r1(y2)} r={4.6} className="g7-ring" />
                  <title>{research ? `∂${o.axis} ψ_${name(o.blade)} (${sgn(o.sign)})` : `change along ${o.axis}`}</title>
                </g>
                <text x={r1(lx)} y={r1(ly + 3.5)} textAnchor="middle" className={`${fs} t-mono`} data-label={o.blade}>{name(o.blade)}</text>
              </g>
            );
          })}
          <circle cx={C} cy={C} r={11} className="g7-ring" data-center={1} style={{ strokeWidth: 2 }} />
          <text x={C} y={C + 4} textAnchor="middle" className="t-small t-mono t-bold" data-label={1}>{name(1)}</text>
          {!drawRing && <text x={C} y={C + R1 + 22} textAnchor="middle" className="t-small t-muted" data-noj="1">{research ? 'J: none' : 'no ring'}</text>}
        </FigSvg>
        <Legend items={research
          ? [['dot', <>coupling term A<sub>k</sub>ψ</>], ['double', 'the time corner: also the mass term mψγ₀'], ['ring', <>derivative term ∂<sub>k</sub>ψ</>], [L === 'demicube' ? 'solid' : 'dash', 'moved by J = γ₂γ₁ (the bits xy)'], L === 'simplex' && ['solid', 'corner simplex: our reading (CPL-010)']]
          : [['dot', 'push of the field'], ['double', 'and the mass'], ['ring', 'change along each direction']]} />
        <Controls label="coupling ring">
          <Rungs label={research ? 'n' : 'directions'} values={COUPLING_NS} value={n} top={top} param="n" onPick={v => setSt(s => ({ ...s, n: v }))} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ top: on, n: on ? TOP : s.n }))} />
        </Controls>
      </div>
      <div className="g7-right">
        {research ? (
          <>
            <Readout data={{ 'data-readout': 'cell' }} items={[
              [`Cl(1,${n - 1})`, `≅ ${lad ? lad.algebra : '…'}`, { 'data-algebra': lad ? lad.algebra : '' }],
              ['J', Rn.J.exists ? `γ₂γ₁ · label ${lad ? lad.J_label : '…'}` : 'none', { 'data-j': lad ? `${lad.J_label},${lad.J_count}` : '' }],
              ['bivectors with J² = −1 that commute with γ₀', lad ? String(lad.J_count) : '…'],
              ['terms at t', Rn.J.exists ? `${Rn.terms} = ${termsOf('d')} ∂ + ${termsOf('A')} A + 1 m` : '—', { 'data-ring-terms': Rn.J.exists ? Rn.terms : '' }],
            ]} />
            <Readout data={{ 'data-readout': 'counts' }} items={[
              ['equations', lad ? String(lad.odd_corners) : '…', { 'data-equations': lad ? lad.odd_corners : '' }],
              ['incidences', lad ? (lad.incidences_total == null ? '—' : `${lad.incidences_total} = ${lad.derivative_edges} ∂ + ${lad.coupling_edges} A + ${lad.mass_edges} m`) : '…',
                { 'data-incidences': lad ? [lad.incidences_total, lad.derivative_edges, lad.coupling_edges, lad.mass_edges].join(',') : '' }],
            ]} />
            {eqn && (
              <div className="g7-card" data-equation="t">
                <h4>the equation at {name(1)}<span className="g7-sub">the γ₀ component of <Tex katex={katex} tex={'D=\\nabla\\psi J-eA\\psi-m\\psi\\gamma_0'} plain="D = ∇ψJ − eAψ − mψγ₀" /></span></h4>
                <div className="g7-eq"><Tex katex={katex} tex={eqn.tex} plain={eqn.plain} /></div>
                <p className="g7-idle">ψ with the blade of each component as subscript (1: the scalar) · signs from the kernel</p>
              </div>
            )}
            {L === 'simplex' && Rn.J.exists && <Readout data={{ 'data-readout': 'simplex' }} items={[['corner simplex', lad ? (lad.coupling_terms_are_corner_simplex ? '✓ stored' : '✗') : '…', { 'data-simplex-stored': lad ? String(lad.coupling_terms_are_corner_simplex) : '' }], ['', 'our reading (CPL-010)']]} />}
            {L === 'demicube' && Rn.J.exists && <Readout data={{ 'data-readout': 'demicube' }} items={[['even blades on the ring', String(2 * n)], ['J moves (two bits)', String(n)]]} />}
            {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`Cl(1,${n - 1}) ⊂ Cl(1,${TOP - 1})`, n === TOP ? 'top' : restr ? '✓ every sign the same' : '✗', { 'data-restricts': n === TOP ? 'top' : String(restr) }], ['terms kept', Rn.J.exists ? `${Rn.terms} of ${R.terms}` : `0 of ${R.terms}`, { 'data-kept': `${Rn.J.exists ? Rn.terms : 0},${R.terms}` }]]} />}
            <p className="g7-conv" data-convention="1"><span className="g7-k">the complex structure, an input (INP-031):</span> J = γ₂γ₁</p>
          </>
        ) : (
          <Readout data={{ 'data-readout': 'learner' }} items={[
            ['', `${n} direction${n === 1 ? '' : 's'}`],
            Rn.J.exists ? ['', `${Rn.terms} pieces: ${termsOf('A')} push · ${termsOf('d')} change · 1 mass`, { 'data-ring-terms': Rn.terms }] : ['', 'no ring'],
            top && ['', n === TOP ? 'the top' : `part of ${TOP} directions`],
          ]} />
        )}
      </div>
    </div>
  );
}
CouplingRing.meta = { id: 'coupling-ring', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
CouplingRing.params = [{}, { n: 1 }, { n: 2, top: true }, { n: 3 }, { n: 8 }, { n: 5, top: true }];
/** the numbers the figure draws: the ring of the chosen n (blades and kernel signs), its equation, and the restriction to it from the top */
CouplingRing.data = (p = {}) => {
  const n = intIn(p.n, COUPLING_NS, p.top === true ? TOP : 4), R = couplingRing(n);
  return { n, top: p.top === true, ring: R, equation: R.J.exists ? ringEquation(R).plain : null, restricts: p.top === true && n < TOP ? restricts('coupling', n, TOP) : null };
};
