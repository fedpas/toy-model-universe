// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p10.js — owner P10 registers its figures here (id → component): Calibration 2 (Furey), docs/PHYSICS_AUDIT.md §2.17 FU1–FU6.
import FureyCharges from './FureyCharges.jsx';
import FureyComposites from './FureyComposites.jsx';
import FureyRoom from './FureyRoom.jsx';
import FureyTrialities from './FureyTrialities.jsx';
export const P10_FIGURES = { 'furey-charges': FureyCharges, 'furey-composites': FureyComposites, 'furey-room': FureyRoom, 'furey-trialities': FureyTrialities };
