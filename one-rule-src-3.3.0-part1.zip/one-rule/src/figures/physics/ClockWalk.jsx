// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure clock-walk (round 17, proofs pass 13a; caption row LAB-026): the path of the clock sum. The steps i^w(a) of the labels of Cl(p,q), n = p + q ≤ 12,
// added head to tail in counting order a = 0, 1, …, 2ⁿ − 1 or in Gray-code order (each label one generator away from the one before): the labels without the
// last generator in the muted ink, those with it in the full ink, so that the doubling is seen (counting: the first half turned by a quarter turn, Lévy's
// construction; Gray: the first half retraced backwards, turned about its end, the Heighway dragon); the milestones after 2^k labels as dots numbered k,
// on the dashed spiral (1 ± i)^t when every generator has one sign; the end (1 + i)^p (1 − i)^q as the arrow of the clock's colour with its printed c = n.
// Frame: the plane of the sum, or the chord turned onto [0, 1] (the walk divided by its end: for Cl(0,n) Duvall and Keesling's F^n([0,1])). Every step
// from engines/physics/clockWalk.js (w through engines/labels.js w4 and the kernel); tests/physics/p14.test.mjs ties it to clock_walk.log. Research level
// only (learner: false), as the figure gauss-sum. Tokens only, no stylesheet of its own (D63).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Chips, Stepper, clockVar, arrowHead, r1 } from '../kit.jsx';
import { clockWalk, gaussEnd, spiralPoint, N_WALK, ORDERS, FRAMES } from '../../../engines/physics/clockWalk.js';

const SIZE = 340, PAD = 26, FOOT = 30;
const r3 = x => Math.round(x * 1000) / 1000;
const okCell = (p, q) => Number.isInteger(p) && Number.isInteger(q) && p >= 0 && q >= 0 && p + q <= N_WALK;
/** the chips' state from the figure's params: { p, q, order, frame } */
export function stateOf(params = {}) {
  const [p, q] = okCell(params.p, params.q) ? [params.p, params.q] : [0, 8];
  return { p, q, order: ORDERS.includes(params.order) ? params.order : 'counting', frame: FRAMES.includes(params.frame) ? params.frame : 'plane' };
}
/** a Gaussian integer as printed: 16, −8 + 8i, −4i */
export function gaussText([x, y]) {
  const m = v => (v < 0 ? `−${-v}` : String(v));
  if (!y) return m(x);
  const im = Math.abs(y) === 1 ? 'i' : `${Math.abs(y)}i`;
  if (!x) return y < 0 ? `−${im}` : im;
  return `${m(x)} ${y < 0 ? '−' : '+'} ${im}`;
}
/** the path of steps dirs[from … to − 1] from the point (x, y), in lattice units: h and v moves of one unit (runs merged) */
export function pathOf(W, from, to) {
  let d = `M${W.xs[from]} ${W.ys[from]}`, k = from;
  while (k < to) {
    const dir = W.dirs[k]; let run = 1; while (k + run < to && W.dirs[k + run] === dir) run++;
    d += dir === 0 ? `h${run}` : dir === 1 ? `v${run}` : dir === 2 ? `h-${run}` : `v-${run}`;
    k += run;
  }
  return d;
}
/** the drawing's geometry: the turn of the frame, the scale and the offsets that fit the walk (and the spiral) in a box SIZE wide, as tall as it needs */
function frameOf(W, frame, spiral) {
  const theta = frame === 'chord' ? Math.atan2(W.end[1], W.end[0]) : 0, cs = Math.cos(theta), sn = Math.sin(theta);
  const rot = (x, y) => [x * cs + y * sn, -x * sn + y * cs];
  let minX = 0, maxX = 0, minY = 0, maxY = 0;
  const take = (x, y) => { const [u, v] = rot(x, y); if (u < minX) minX = u; if (u > maxX) maxX = u; if (v < minY) minY = v; if (v > maxY) maxY = v; };
  for (let k = 0; k < W.xs.length; k++) take(W.xs[k], W.ys[k]);
  for (const [x, y] of spiral) take(x, y);
  const w = Math.max(maxX - minX, 1), h = Math.max(maxY - minY, 1), inner = SIZE - 2 * PAD;
  const s = Math.min(inner / w, inner / h), height = Math.max(150, Math.ceil(h * s + 2 * PAD));
  const ox = PAD + (inner - w * s) / 2 - s * minX, oy = (height - h * s) / 2 + s * maxY;
  const at = (x, y) => { const [u, v] = rot(x, y); return [r1(ox + s * u), r1(oy - s * v)]; };
  return { theta, s, ox, oy, at, height, transform: `translate(${r3(ox)} ${r3(oy)}) scale(${r3(s)} ${r3(-s)}) rotate(${r3((-theta * 180) / Math.PI)})` };
}
const HALO = { paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3, strokeLinejoin: 'round' };

export default function ClockWalk({ params = {}, lens = null, level = 'research', theme, row }) {   // eslint-disable-line no-unused-vars
  const research = level !== 'learner';
  const [st, setSt] = useState(() => stateOf(params));
  useEffect(() => { setSt(stateOf(params)); }, [params.p, params.q, params.order, params.frame]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { p, q, order, frame } = st, n = p + q;
  const W = useMemo(() => clockWalk(p, q, order), [p, q, order]);
  const hand = n && !q ? 1 : n && !p ? -1 : 0;   // one sign for every generator: the milestones lie on (1 + i)^t or (1 − i)^t
  const spiral = useMemo(() => (hand ? Array.from({ length: n * 16 + 1 }, (_, j) => spiralPoint(j / 16, hand)) : []), [n, hand]);
  const F = frameOf(W, frame, spiral);
  const N = 1 << n, half = N >> 1, lw = r1(Math.min(2, Math.max(0.6, F.s * 0.5)));
  const [ex, ey] = F.at(W.end[0], W.end[1]), [zx, zy] = F.at(0, 0);
  const turnDeg = W.turn ? (W.turn[1] > 0 ? 90 : -90) : 0;   // counting: the second half is the first turned by i^w(e) = ±i
  const set = k => v => setSt(s => ({ ...s, [k]: v }));
  // the printed c = n beside the arrow of the end: of the places beside it (three along it, both sides, two distances), the one with the fewest points
  // of the walk around it, so that a dense walk leaves it readable
  const label = useMemo(() => {
    const dx = ex - zx, dy = ey - zy, L = Math.hypot(dx, dy) || 1, nx0 = -dy / L, ny0 = dx / L, pts = [];
    for (let k = 0; k < W.xs.length; k++) pts.push(F.at(W.xs[k], W.ys[k]));
    let best = null;
    for (const t of [0.5, 0.35, 0.65]) for (const d of [14, 24]) for (const s of [-1, 1]) {
      const nx = s * nx0, ny = s * ny0, x = zx + dx * t + nx * d, y = zy + dy * t + ny * d;
      if (x < 24 || x > SIZE - 24 || y < 12 || y > F.height - 8) continue;
      let crowd = 0; for (const [px, py] of pts) if (Math.abs(px - x) < 22 && Math.abs(py - y) < 9) crowd++;
      if (!best || crowd < best.crowd) best = { crowd, x: r1(x), y: r1(y + 4), anchor: nx < -0.3 ? 'end' : nx > 0.3 ? 'start' : 'middle' };
    }
    return best || { x: r1(zx + dx * 0.5), y: r1(zy + dy * 0.5 - 10), anchor: 'middle' };
  }, [W, F.transform, F.height, ex, ey, zx, zy]);   // eslint-disable-line react-hooks/exhaustive-deps
  // the milestones' numbers: one where it stands clear of the last one numbered (the first few crowd the origin)
  const named = new Set(); { let last = null; for (const m of W.milestones) { const [x, y] = F.at(m.x, m.y); if (!last || Math.hypot(x - last[0], y - last[1]) >= 14) { named.add(m.k); last = [x, y]; } } }
  return (
    <div className="fig fig-clock-walk" data-cell={`${p},${q}`} data-order={order} data-frame={frame}>
      <FigSvg id="clock-walk" row={row} part={research ? `Cl(${p},${q}) in ${order === 'gray-code' ? 'Gray-code' : 'counting'} order` : null} viewBox={`0 0 ${SIZE} ${F.height + FOOT}`}
        data-n={n} data-end={W.end.join(',')} data-c={W.c} data-angle={r3((F.theta * 180) / Math.PI)} data-dirs={Array.from(W.dirs).join('')}>
        <g transform={F.transform} data-lattice="1">
          {n === 0
            ? <path d={pathOf(W, 0, 1)} className="stroke-ink" vectorEffect="non-scaling-stroke" style={{ strokeWidth: lw, strokeLinecap: 'round' }} data-half="1" data-from="0" />
            : <>
              <path d={pathOf(W, 0, half)} className="stroke-muted" vectorEffect="non-scaling-stroke" style={{ strokeWidth: lw, strokeLinecap: 'round', strokeLinejoin: 'round' }} data-half="1" data-from="0" />
              <path d={pathOf(W, half, N)} className="stroke-ink" vectorEffect="non-scaling-stroke" style={{ strokeWidth: lw, strokeLinecap: 'round', strokeLinejoin: 'round' }} data-half="2" data-from={half} />
            </>}
        </g>
        {hand !== 0 && <polyline points={spiral.map(([x, y]) => F.at(x, y).join(',')).join(' ')} className="stroke-muted" style={{ strokeWidth: 1, strokeDasharray: '4 3' }} data-spiral={hand} />}
        <line x1={zx} y1={zy} x2={ex} y2={ey} style={{ stroke: clockVar(W.c), strokeWidth: 2.5, strokeLinecap: 'round' }} data-sum={W.end.join(',')} />
        <path d={arrowHead(zx, zy, ex, ey, 9)} style={{ fill: clockVar(W.c) }} />
        {W.milestones.map(m => { const [x, y] = F.at(m.x, m.y); return (
          <g key={m.k} data-k={m.k} data-xy={`${m.x},${m.y}`}>
            <circle cx={x} cy={y} r={3.6} className="ink" style={{ stroke: 'var(--panel)', strokeWidth: 1.5 }} />
            {research && named.has(m.k) && <text x={r1(x + 6)} y={r1(y - 6)} className="t-mono t-tiny t-muted" style={HALO}>{m.k}</text>}
          </g>
        ); })}
        <text x={label.x} y={label.y} textAnchor={label.anchor} className="t-mono t-small t-bold" style={HALO}>{`c = ${W.c}`}</text>
        <circle cx={zx} cy={zy} r={2.6} className="ink" />
        {research && <text x={SIZE / 2} y={F.height + 18} textAnchor="middle" className="t-mono t-small">{`Cl(${p},${q}) · ${N} labels · Σ iʷ = ${gaussText(W.end)}${frame === 'chord' ? ' · on its chord' : ''}`}</text>}
      </FigSvg>
      {research && (
        <Controls label="the path of the clock sum">
          <Stepper label="p" value={p} min={0} max={N_WALK - q} onChange={v => set('p')(v)} param="p" />
          <Stepper label="q" value={q} min={0} max={N_WALK - p} onChange={v => set('q')(v)} param="q" />
          <Chips label="order" items={ORDERS} value={order} param="order" render={k => (k === 'gray-code' ? 'Gray code' : 'counting')} onPick={set('order')} />
          <Chips label="frame" items={FRAMES} value={frame} param="frame" render={k => (k === 'chord' ? 'chord to [0, 1]' : 'plane')} onPick={set('frame')} />
        </Controls>
      )}
      {research && (
        <dl className="fig-readout" data-readout="clock-walk">
          <div data-sum={W.end.join(',')}><dt>Σ iʷ</dt><dd>{`${gaussText(W.end)} = (1 + i)${supOf(p)}(1 − i)${supOf(q)}`}</dd></div>
          <div data-clock={W.c}><dt>clock</dt><dd>{`c = ${W.c}`}</dd></div>
          <div data-norm={W.end[0] * W.end[0] + W.end[1] * W.end[1]}><dt>|Σ|²</dt><dd>{`2${supOf(n)} = ${N}`}</dd></div>
          {n > 0 && <div data-turn={order === 'gray-code' ? -turnDeg : turnDeg}><dt>second half</dt><dd>{order === 'gray-code' ? `the first, backwards, turned ${turnDeg > 0 ? '−' : '+'}90° about its end` : `the first, turned ${turnDeg > 0 ? '+' : '−'}90°`}</dd></div>}
        </dl>
      )}
      {research && (
        <p className="fig-note" data-legend={order}>
          {order === 'gray-code'
            ? 'Gray-code order: each label is one generator away from the one before. The labels with the last generator (the stronger line) go back over the first half in reverse, rotated a quarter turn about the point where it ends: the Heighway dragon. The end is the same in both orders: the cell fixes it.'
            : `Counting order a = 0, 1, …, 2ⁿ − 1. The labels with the last generator (the stronger line) step as the earlier ones times i^w = ±i: each generator adds a copy of the whole path turned by a quarter turn, Lévy's construction.${hand < 0 ? ' Divided by (1 − i)ⁿ (the chord frame) this is Duvall and Keesling\'s F^n([0,1]).' : hand > 0 ? ' Its mirror image, the path of Cl(0,n) divided by (1 − i)ⁿ, is Duvall and Keesling\'s F^n([0,1]).' : ''} Dots: the sums after 2^k labels${hand ? ', on the dashed spiral' : ''}.`}
        </p>
      )}
    </div>
  );
}
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
function supOf(k) { return String(k).replace(/\d/g, d => SUP[d]); }
ClockWalk.meta = { id: 'clock-walk', lenses: [], learner: false };
ClockWalk.params = [{}, { p: 8, q: 0 }, { p: 0, q: 12, order: 'gray-code' }, { p: 3, q: 1, frame: 'chord' }, { p: 0, q: 0 }, { p: 5, q: 5, order: 'gray-code', frame: 'chord' }, { p: 0, q: 10, frame: 'chord' }];
/** the numbers the figure draws: the cell, the order, the frame, the steps (w of each label read, in order), the end, the clock, the milestones */
ClockWalk.data = (params = {}) => {
  const st = stateOf(params), W = clockWalk(st.p, st.q, st.order);
  return { ...st, n: W.n, c: W.c, end: W.end, endByFormula: gaussEnd(st.p, st.q), dirs: Array.from(W.dirs).join(''), milestones: W.milestones, turn: W.turn };
};
