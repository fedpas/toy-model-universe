// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure shifted-quarter-turn (Calibration 3, the hero of `shifted`; caption ATY-009, states ATY-005 and ATY-009; docs/round14/STORY_ROUND.md §6.3, owner B3):
// the right factor of the shift at the quantized delay, Eτ = (n + ½)π, is e^{JEτ} = J^{2n+1} = (−1)ⁿJ — a quarter turn of the wave ψ — and its frame
// ψγ_kψ̃ turns by half: the current (γ₀) and the spin (γ₃) are kept, γ₁ and γ₂ reversed. Drawn: the frame before and after (in the wave's rest frame, each
// arrow with the kernel's verdict), the factor on its circle (1 and J), the rational point of shd·BIL where no wave exists, and the sheet: on the waves
// e^{−Jk·x} the factor is the translation by τ along k/E (a retard), on e^{+Jk·x} by −τ (an advance). Every product is the kernel's
// (engines/physics/shifted.js heroData: J = γ₂γ₁, the boost of the stored wave, the reverse); the waves and the rational point are the stored ones
// (content/stored_shifted.json bil, qnt, loaded on demand: D34); a rung the table does not store draws the frame at rest, marked "not stored" (D37).
// Controls: the rung n (chips 0–3) and the sheet. Lenses: the generators by the kernel's printer (clifford, bits, primes). Tokens only; marks by shape
// and word, never by colour alone. Also exported: useShifted and peekShifted, the stored table for the five figures of Calibration 3.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, pick, r1, tx, arrowHead, labelLens } from '../kit.jsx';
import { useTable } from '../../app/content.js';
import { peekTable } from '../../app/store.js';
import { okStored, heroData, MASK_J, bladeLabel } from '../../../engines/physics/shifted.js';

/** the stored table of Calibration 3: params.stored (a test's copy), else the loaded content table, else null while it loads */
export function useShifted(params) {
  const [T] = useTable('stored_shifted');
  return params && okStored(params.stored) ? params.stored : okStored(T) ? T : null;
}
/** the same, outside React (the figures' data() for the frame's download) */
export const peekShifted = params => (params && okStored(params.stored) ? params.stored : okStored(peekTable('stored_shifted')) ? peekTable('stored_shifted') : null);

const NS = [0, 1, 2, 3], SHEETS = ['retarded', 'advanced'];
const SUBS = '₀₁₂₃';
/** the name of γ_k: the physics name, or the kernel's label of its bit in the lens (D8) */
const genName = (k, lens) => { const L = labelLens(lens); return L ? bladeLabel(1 << k, L) : `γ${SUBS[k]}`; };
const jName = lens => { const L = labelLens(lens); return L ? `−${bladeLabel(MASK_J, L)}` : 'γ₂γ₁'; };
const LEARN = ['where it goes', 'arrow 1', 'arrow 2', 'spin'];
const ROLE = ['current', '', '', 'spin'];
// the rest-frame drawing: γ₁ toward the reader (lower left), γ₂ to the right, γ₃ up
const AX = [null, [-30, 20], [56, 0], [0, -56]];
const at = (cx, cy, k, s) => [cx + s * AX[k][0], cy + s * AX[k][1]];

/** one frame: the time arrow (the current) at the side and the three space arrows, each with the kernel's verdict after the factor */
function Frame({ cx, cy, signs, verdicts, lens, research, title }) {
  const tx0 = verdicts ? 612 : 28, anchor = verdicts ? 'end' : 'start';   // the time arrow (the current): at the outer edge of each frame
  return (
    <g data-frame={verdicts ? 'after' : 'before'}>
      <text x={cx - 52} y={18} className="t-small t-bold">{title}</text>
      <line x1={tx0} y1={cy + 44} x2={tx0} y2={cy - 18} className="stroke-ink" strokeWidth={1.8} data-arrow={0} />
      <path d={arrowHead(tx0, cy + 44, tx0, cy - 18)} className="ink" />
      <text x={tx0} y={cy + 58} textAnchor={anchor} className="t-tiny">{research || lens ? genName(0, lens) : LEARN[0]}{research ? ` ${ROLE[0]}` : ''}</text>
      {verdicts && <text x={tx0} y={cy + 70} textAnchor={anchor} className="t-micro t-muted">kept</text>}
      {verdicts && (
        <g data-half-turn="3">
          <polyline points={Array.from({ length: 13 }, (_, i) => { const t = (Math.PI * i) / 12, c = 0.42 * Math.cos(t), s = 0.42 * Math.sin(t); return `${r1(cx + c * AX[1][0] + s * AX[2][0])},${r1(cy + c * AX[1][1] + s * AX[2][1])}`; }).join(' ')} className="stroke-muted" />
          <path d={arrowHead(cx + 0.42 * (Math.cos(Math.PI * 11 / 12) * AX[1][0] + Math.sin(Math.PI * 11 / 12) * AX[2][0]), cy + 0.42 * (Math.cos(Math.PI * 11 / 12) * AX[1][1] + Math.sin(Math.PI * 11 / 12) * AX[2][1]), cx - 0.42 * AX[1][0], cy - 0.42 * AX[1][1], 5)} className="ink-muted" />
        </g>
      )}
      {[1, 2, 3].map(k => {
        const s = signs[k], [x2, y2] = at(cx, cy, k, s), turned = verdicts && verdicts[k] === 'reversed';
        return (
          <g key={k} data-arrow={k} data-sign={s}>
            <line x1={cx} y1={cy} x2={r1(x2)} y2={r1(y2)} className="stroke-ink" strokeWidth={k === 3 ? 1.8 : 1.2} strokeDasharray={turned ? '5 3' : undefined} />
            <path d={arrowHead(cx, cy, x2, y2)} className="ink" />
            <text x={r1(x2 + (AX[k][0] * s > 0 ? 4 : AX[k][0] * s < 0 ? -4 : 5))} y={r1(y2 + (AX[k][1] * s > 0 ? 12 : -4))} textAnchor={AX[k][0] * s < 0 ? 'end' : 'start'} className="t-tiny">
              {research || lens ? genName(k, lens) : LEARN[k]}{research && ROLE[k] ? ` ${ROLE[k]}` : ''}
            </text>
            {verdicts && <text x={r1(x2 + (AX[k][0] * s < 0 ? -4 : 4))} y={r1(y2 + (AX[k][1] * s > 0 ? 22 : 8))} textAnchor={AX[k][0] * s < 0 ? 'end' : 'start'} className="t-micro t-muted">
              {verdicts[k] === 'kept' ? 'kept' : research ? 'reversed' : 'turned round'}</text>}
          </g>
        );
      })}
    </g>
  );
}

export default function ShiftedQuarterTurn({ params = {}, lens = null, level = 'research', row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, v => NS.includes(v), 0));
  const [sheet, setSheet] = useState(pick(params.sheet, v => SHEETS.includes(v), 'retarded'));
  useEffect(() => { setN(pick(params.n, v => NS.includes(v), 0)); setSheet(pick(params.sheet, v => SHEETS.includes(v), 'retarded')); }, [params.n, params.sheet]);
  const T = useShifted(params), H = heroData(T, { n, sheet });
  const before = [1, 1, 1, 1], after = H.status.map(x => (x === 'kept' ? 1 : -1));
  const cx = 320, cy = 96, R = 44, up = H.factor.sign > 0, py = up ? cy - R : cy + R;
  const quarter = `M${cx + R} ${cy} A${R} ${R} 0 0 ${up ? 0 : 1} ${cx} ${py}`;
  const rat = H.rational, rp = rat ? rat.cs.map(x => { const [a, b] = String(x).split('/'); return +a / (+b || 1); }) : null;
  const tauText = research ? tx(`τ = ${H.rung.tau} λ_C`) : `${2 * n + 1} quarter${n ? 's' : ''} of a wavelength`;
  const minus = v => v.map(x => String(x).replace('-', '−')).join(', ');
  const dx = H.dir * 120, x0 = cx - dx;
  return (
    <div className="fig fig-shifted-quarter-turn">
      <FigSvg id="shifted-quarter-turn" row={row} viewBox="0 0 640 290">
        <Frame cx={140} cy={112} signs={before} lens={lens} research={research} title={research ? 'ψ and its frame' : 'before the shift'} />
        <Frame cx={500} cy={112} signs={after} verdicts={H.status} lens={lens} research={research} title={research ? 'after the factor' : 'after the shift'} />
        <g data-factor={H.factor.power} data-sign={H.factor.sign} data-scalar={H.factor.scalar} data-only-j={H.factor.onlyJ ? 1 : 0}>
          <line x1={cx - R - 10} y1={cy} x2={cx + R + 10} y2={cy} className="hair" />
          <line x1={cx} y1={cy - R - 10} x2={cx} y2={cy + R + 10} className="hair" />
          <circle cx={cx} cy={cy} r={R} className="stroke-muted" />
          <text x={cx + R + 12} y={cy + 4} className="t-tiny">1</text>
          <text x={cx + 4} y={cy - R - 12} className="t-tiny">{research ? 'J' : 'quarter turn'}</text>
          {[cy - R, cy + R].map(y => <circle key={y} cx={cx} cy={y} r={3} className="ink" />)}
          <path d={quarter} className="stroke-ink" strokeWidth={2} />
          <path d={arrowHead(cx + 6, up ? py - 1 : py + 1, cx, py)} className="ink" />
          <circle cx={cx} cy={py} r={6} className="stroke-ink" strokeWidth={2} />
          {rat && (
            <g data-rational={rat.cs.join(',')} data-cos2={rat.cos2} data-stored-cos2={rat.storedCos2} data-turn={rat.turn} data-stored-turn={rat.storedTurn}>
              <circle cx={r1(cx + R * rp[0])} cy={r1(cy - R * rp[1])} r={4} className="on-panel" style={{ stroke: 'var(--fg)' }} />
              <text x={r1(cx + R * rp[0] + 7)} y={r1(cy - R * rp[1] - 4)} className="t-micro">{research ? `(${rat.cs.join(', ')}): no wave` : 'no wave here'}</text>
              {research && <text x={r1(cx + R * rp[0] + 7)} y={r1(cy - R * rp[1] + 6)} className="t-micro t-muted">{`frame by ${String(rat.turn).replace('-', '−')}θ, cos 2θ = ${rat.cos2.replace('-', '−')}`}</text>}
            </g>
          )}
          <text x={cx} y={cy + R + 26} textAnchor="middle" className="t-small t-bold" data-rung={n} data-phase={H.rung.phase}>
            {research ? tx(`× e^{JEτ}, Eτ = ${H.rung.phase === '1/2' ? '' : H.rung.phase.split('/')[0]}π/2`) : `rung ${n}: a quarter turn ${up ? 'one way' : 'the other way'}`}
          </text>
          {research && <text x={cx} y={cy + R + 40} textAnchor="middle" className="t-small" data-power={H.factor.power}>{tx(`= J^${H.factor.power} = ${up ? '+' : '−'}J,  J = ${jName(lens)}`)}</text>}
          <text x={cx} y={cy + R + (research ? 54 : 40)} textAnchor="middle" className="t-tiny t-muted">{research ? 'a quarter turn of ψ, a half turn of its frame' : 'a quarter turn of the wave, a half turn of its arrows'}</text>
        </g>
        <g data-sheet={sheet} data-dir={H.dir} data-tau={H.rung.tau}>
          <line x1={40} y1={236} x2={600} y2={236} className="stroke-muted" />
          <path d={arrowHead(40, 236, 604, 236)} className="ink-muted" />
          <text x={604} y={250} textAnchor="end" className="t-micro t-muted">{research ? 'along the wave, k/E' : 'along the wave'}</text>
          <circle cx={x0} cy={236} r={4} className="on-panel" style={{ stroke: 'var(--fg)' }} />
          <circle cx={cx} cy={236} r={4} className="ink" />
          <path d={`M${x0} 226 L${cx} 226`} className="stroke-ink" strokeWidth={1.6} />
          <path d={arrowHead(x0, 226, cx, 226)} className="ink" />
          <text x={(x0 + cx) / 2} y={218} textAnchor="middle" className="t-tiny" data-value={H.rung.tau}>{tauText}</text>
          <text x={cx} y={256} textAnchor="middle" className="t-tiny">
            {research ? tx(sheet === 'retarded' ? 'on the waves e^{−Jk·x} the factor is the translation by τ along k/E: a retard' : 'on the waves e^{+Jk·x} the factor is the translation by −τ along k/E: an advance')
              : sheet === 'retarded' ? 'this sheet waits: the shift looks one delay back along the wave' : 'this sheet looks ahead: the shift takes the wave one delay forward'}
          </text>
        </g>
        <g data-wave={H.wave ? H.wave.k.join(',') : ''} data-e={H.wave ? H.wave.E : ''} data-from={H.wave ? H.wave.from : ''} data-off-shell={H.wave && H.wave.offShell ? 1 : undefined} data-stored={H.rung.stored == null ? '' : H.rung.stored}>
          {T ? (
            <text x={4} y={276} className="t-tiny">
              {H.wave ? (research ? tx(`the stored wave k = (${H.wave.k.join(', ')}), E = ${H.wave.E} (m = ${H.wave.m}, κ = ${H.wave.kappa}; ${H.wave.from})`) : `a stored wave of this rung, energy ${H.wave.E}`)
                : (research ? `rung ${n}: not stored; the frame at rest (the identity holds for any even ψ)` : `rung ${n} is not stored: the arrows of a wave at rest`)}
            </text>
          ) : <text x={4} y={276} className="t-tiny t-muted" data-loading="stored results">loading the stored results</text>}
          {research && (
            <text x={4} y={288} className="t-micro t-mono" data-before={H.before.map(v => v.join(',')).join(';')} data-after={H.after.map(v => v.join(',')).join(';')} data-status={H.status.join(',')}>
              {H.before.map((v, k) => `${genName(k, lens)} (${minus(v)})${H.status[k] === 'kept' ? '' : ` → (${minus(H.after[k])})`}`).join(' · ')}
            </text>
          )}
        </g>
      </FigSvg>
      <Controls label="quarter turn">
        <Chips label={research ? 'rung n' : 'rung'} items={NS} value={n} onPick={setN} param="n" />
        <Chips label="sheet" items={SHEETS} value={sheet} onPick={setSheet} param="sheet" render={s => (research ? s : s === 'retarded' ? 'waits back' : 'looks ahead')} />
      </Controls>
    </div>
  );
}
ShiftedQuarterTurn.meta = { id: 'shifted-quarter-turn', lenses: ['clifford', 'bits', 'primes'], learner: true };
ShiftedQuarterTurn.params = [{}, { n: 1, sheet: 'advanced' }, { n: 2 }, { n: 3, sheet: 'advanced' }];
/** the numbers the figure draws, for the frame's data download */
ShiftedQuarterTurn.data = (params = {}) => {
  const H = heroData(peekShifted(params), { n: NS.includes(params.n) ? params.n : 0, sheet: SHEETS.includes(params.sheet) ? params.sheet : 'retarded' });
  return { n: H.n, sheet: H.sheet, factor: H.factor, wave: H.wave, rung: H.rung, before: H.before, after: H.after, status: H.status, rational: H.rational };
};
