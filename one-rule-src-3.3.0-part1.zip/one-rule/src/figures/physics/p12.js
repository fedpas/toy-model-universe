// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p12.js — owner B3 registers the figures of Calibration 3, the shifted view (round 14, docs/round14/STORY_ROUND.md §6.3, D62) here
// (id → component); seeds in content/physics/figures.p12.json, engine engines/physics/shifted.js, stored table content/stored_shifted.json. The line that
// spreads this registry into src/figures/physics/index.js (and so into the figures chunk, D47) is B2's.
import ShiftedQuarterTurn from './ShiftedQuarterTurn.jsx';
import ShiftedShells from './ShiftedShells.jsx';
import ShiftedBeat from './ShiftedBeat.jsx';
import ShiftedRicci from './ShiftedRicci.jsx';
import ShiftedRadius from './ShiftedRadius.jsx';
export const P12_FIGURES = { 'shifted-quarter-turn': ShiftedQuarterTurn, 'shifted-shells': ShiftedShells, 'shifted-beat': ShiftedBeat, 'shifted-ricci': ShiftedRicci, 'shifted-radius': ShiftedRadius };
