// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure weil-index (round 17, proofs pass 13c; caption row LAB-028): Weil's index of the cell's real form beside the clock walk. On the unit circle with
// its eight eighth roots of unity in the clock's colours (the tick k at e^{iπk/4}, numbered k): the real side, the integral of e^{2πiλQ} over ℝⁿ damped
// by e^{−πs|x|²} and multiplied by (2|λ|)^{n/2}, as s runs from ∞ to 0 (the stronger line, in the colour of the root it ends at, with an arrow); the
// labels' side, the clock walk of Cl(p,q) (counting order) shrunk by 2^{n/2} (the thin line, its end ringed). For λ > 0 the two ends are one point; for
// λ < 0 the real side ends at the conjugate (the mirror cell's root). Every point from engines/physics/weilIndex.js (the walk through
// engines/physics/clockWalk.js and the kernel); tests/physics/p15.test.mjs checks it against the identities of the wi.DEF and wi.REAL lines of
// weil_index.log and a quadrature of its own. Research level only (learner: false), as clock-walk. Tokens only, no stylesheet of its own (D63).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Chips, Stepper, clockVar, arrowHead, r1 } from '../kit.jsx';
import { pathOf } from './ClockWalk.jsx';
import { hx } from './p9kit.jsx';
import { weilIndex, N_INDEX, SIGNS } from '../../../engines/physics/weilIndex.js';

const SIZE = 340, PAD = 18, FOOT = 30, TICK = 1.16;
const r3 = x => Math.round(x * 1000) / 1000;
const okCell = (p, q) => Number.isInteger(p) && Number.isInteger(q) && p >= 0 && q >= 0 && p + q <= N_INDEX;
/** the controls' state from the figure's params: { p, q, sign } */
export function stateOf(params = {}) {
  const [p, q] = okCell(params.p, params.q) ? [params.p, params.q] : [0, 8];
  return { p, q, sign: SIGNS.includes(params.sign) ? params.sign : 'positive' };
}
/** the eighth root ζ^k, ζ = e^{iπ/4}, as printed: 1, i, −1, −i, or e with its exponent (principal argument) */
export const ROOT = ['1', ['', 'iπ/4'], 'i', ['', '3iπ/4'], '−1', ['', '−3iπ/4'], '−i', ['', '−iπ/4']];
export const rootText = k => (typeof ROOT[k] === 'string' ? ROOT[k] : `e^(${ROOT[k][1]})`);
const RootHtml = ({ k }) => (typeof ROOT[k] === 'string' ? <>{ROOT[k]}</> : <>e<sup>{ROOT[k][1]}</sup></>);
const RootSvg = ({ k }) => (typeof ROOT[k] === 'string' ? <tspan>{ROOT[k]}</tspan> : <><tspan>e</tspan><tspan dy="-5" fontSize="75%">{ROOT[k][1]}</tspan><tspan dy="5"> </tspan></>);
/** m π / 4 as printed: 0, π, −2π, 3π/4, −7π/2 … */
export function piText(m) {
  if (!m) return '0';
  const g = m % 4 === 0 ? 4 : m % 2 === 0 ? 2 : 1, a = Math.abs(m) / g, d = 4 / g, s = m < 0 ? '−' : '';
  return `${s}${a === 1 ? '' : a}π${d === 1 ? '' : `/${d}`}`;
}
/** the plane's frame: the box of the walk and the circle (with room for the ticks' numbers) in a drawing SIZE wide */
function frameOf(D) {
  const [x0, y0, x1, y1] = D.box, minX = Math.min(x0, -TICK - 0.08), maxX = Math.max(x1, TICK + 0.08), minY = Math.min(y0, -TICK - 0.08), maxY = Math.max(y1, TICK + 0.08);
  const w = maxX - minX, h = maxY - minY, inner = SIZE - 2 * PAD, R = Math.min(inner / w, inner / h);
  const cx = PAD + (inner - w * R) / 2 - R * minX, height = Math.ceil(h * R + 2 * PAD), cy = PAD + R * maxY;
  return { R, cx, cy, height, at: (x, y) => [r1(cx + R * x), r1(cy - R * y)] };
}
const HALO = { paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3, strokeLinejoin: 'round' };

export default function WeilIndex({ params = {}, lens = null, level = 'research', theme, row }) {   // eslint-disable-line no-unused-vars
  const research = level !== 'learner';
  const [st, setSt] = useState(() => stateOf(params));
  useEffect(() => { setSt(stateOf(params)); }, [params.p, params.q, params.sign]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { p, q, sign } = st, n = p + q, pos = sign === 'positive';
  const D = useMemo(() => weilIndex(p, q, sign), [p, q, sign]);
  const F = frameOf(D), N = 1 << n, sw = F.R * D.scale;
  const { k, turn } = D.real, c = D.labels.c, m = Math.round(turn * 8);   // the argument of the damped integral runs from 0 to m π / 4
  const pts = D.curve.map(([x, y]) => F.at(x, y));
  const [ex, ey] = pts[pts.length - 1], [bx, by] = pts[Math.max(0, pts.length - 7)];
  const [lx, ly] = F.at(D.labels.z[0], D.labels.z[1]), [zx, zy] = F.at(0, 0);
  const set = key => v => setSt(s => ({ ...s, [key]: v }));
  return (
    <div className="fig fig-weil-index" data-cell={`${p},${q}`} data-sign={sign}>
      <FigSvg id="weil-index" row={row} part={research ? `Cl(${p},${q}), λ ${pos ? '>' : '<'} 0` : null} viewBox={`0 0 ${SIZE} ${F.height + FOOT}`}
        data-n={n} data-k={k} data-c={c} data-frame={`${F.cx},${F.cy},${F.R}`}>
        <line x1={r1(F.cx - F.R * TICK)} y1={r1(F.cy)} x2={r1(F.cx + F.R * TICK)} y2={r1(F.cy)} className="stroke-muted" style={{ strokeWidth: 0.6 }} data-axis="re" />
        <line x1={r1(F.cx)} y1={r1(F.cy - F.R * TICK)} x2={r1(F.cx)} y2={r1(F.cy + F.R * TICK)} className="stroke-muted" style={{ strokeWidth: 0.6 }} data-axis="im" />
        <circle cx={r1(F.cx)} cy={r1(F.cy)} r={r1(F.R)} className="stroke-muted" style={{ fill: 'none', strokeWidth: 1 }} data-unit="1" />
        <g transform={`translate(${r3(F.cx)} ${r3(F.cy)}) scale(${r3(sw)} ${r3(-sw)})`} data-lattice="1">
          <path d={pathOf(D.walk, 0, N)} className="stroke-muted" vectorEffect="non-scaling-stroke" style={{ fill: 'none', strokeWidth: 1, strokeLinecap: 'round', strokeLinejoin: 'round' }} data-walk={n} />
        </g>
        {Array.from({ length: 8 }, (_, j) => { const [x, y] = F.at(Math.cos((Math.PI * j) / 4), Math.sin((Math.PI * j) / 4)), [tx, ty] = F.at(TICK * Math.cos((Math.PI * j) / 4), TICK * Math.sin((Math.PI * j) / 4)); return (
          <g key={j} data-tick={j}>
            <circle cx={x} cy={y} r={j === k ? 4.6 : 3.4} style={{ fill: clockVar(j), stroke: 'var(--panel)', strokeWidth: 1.4 }} />
            <text x={tx} y={r1(ty + 4)} textAnchor="middle" className="t-mono t-tiny t-muted" style={HALO}>{j}</text>
          </g>
        ); })}
        {n > 0 && <polyline points={pts.map(pt => pt.join(',')).join(' ')} style={{ fill: 'none', stroke: clockVar(k), strokeWidth: 2.4, strokeLinejoin: 'round', strokeLinecap: 'round' }} data-curve={sign} />}
        {n > 0 && (ex !== bx || ey !== by) && <path d={arrowHead(bx, by, ex, ey, 9)} style={{ fill: clockVar(k) }} data-arrow={k} />}
        <circle cx={lx} cy={ly} r={6.5} className="stroke-ink" style={{ fill: 'none', strokeWidth: 1.4 }} data-labels-end={D.labels.sum.join(',')} />
        <circle cx={zx} cy={zy} r={2.6} className="ink" />
        {research && <text x={SIZE / 2} y={F.height + 18} textAnchor="middle" className="t-mono t-small" style={HALO}>{`Cl(${p},${q}) · λ ${pos ? '>' : '<'} 0 · γ = `}<RootSvg k={k} /></text>}
      </FigSvg>
      {research && (
        <Controls label="Weil's index of the cell">
          <Stepper label="p" value={p} min={0} max={N_INDEX - q} onChange={v => set('p')(v)} param="p" />
          <Stepper label="q" value={q} min={0} max={N_INDEX - p} onChange={v => set('q')(v)} param="q" />
          <Chips label="λ" items={SIGNS} value={sign} param="sign" render={x => (x === 'positive' ? 'λ > 0' : 'λ < 0')} onPick={set('sign')} />
        </Controls>
      )}
      {research && (
        <dl className="fig-readout" data-readout="weil-index">
          <div data-labels={c}><dt>walk's end</dt><dd>Σ iʷ / 2<sup>{n}/2</sup> = <RootHtml k={c} />{` (c = ${c})`}</dd></div>
          <div data-real={k}><dt>{`γ for λ ${pos ? '>' : '<'} 0`}</dt><dd><RootHtml k={k} />{D.agree ? ', the same point' : `, the point of the mirror cell Cl(${q},${p})`}</dd></div>
          <div data-turn={m}><dt>argument on the way</dt><dd>{`0 → ${piText(m)} (${pos ? '' : '−'}(p − q)π/4)`}</dd></div>
        </dl>
      )}
      {research && (
        <p className="fig-note" data-legend={sign}>
          {hx('Stronger line: over ℝⁿ, Q(x) = Σ εⱼxⱼ² the cell\'s form, the integral of e^{2πiλQ} with the damping e^{−πs|x|²}, times (2|λ|)^{n/2}, followed as s falls from ∞ to 0; for s = 2|λ| cot φ it equals (sin φ)^{n/2} e^{iσ(p−q)φ/2}, σ the sign of λ, and it stops on the circle at Weil\'s index for χ(t) = e^{2πiλt}. Thin line: the labels\' clock walk divided by 2^{n/2}, ringed where it ends, at the scalar that relation (9) picks up on the labels. With λ > 0 both stop at one root; with λ < 0 the integral stops at the complex conjugate, the root of the mirror cell. Along the way the argument turns by σ(p − q)π/4, so the turn holds the signature p − q itself, while each end keeps only p − q mod 8.')}
        </p>
      )}
    </div>
  );
}
WeilIndex.meta = { id: 'weil-index', lenses: [], learner: false };
WeilIndex.params = [{}, { p: 3, q: 1 }, { p: 2, q: 9, sign: 'negative' }, { p: 0, q: 0 }, { p: 1, q: 0, sign: 'negative' }, { p: 6, q: 6 }, { p: 12, q: 0 }];
/** the numbers the figure draws: the cell, the sign, the two roots, the turn of the damped integral, its end, the walk's end and its scale */
WeilIndex.data = (params = {}) => {
  const st = stateOf(params), D = weilIndex(st.p, st.q, st.sign);
  return { ...st, n: D.n, k: D.real.k, c: D.labels.c, agree: D.agree, turn: D.real.turn, curveEnd: D.curve[D.curve.length - 1], labelsEnd: D.labels.z, sum: D.labels.sum, scale: D.scale };
};
