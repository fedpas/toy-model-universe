// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-pointor (step 5; caption row SPN-003; docs/PHYSICS_AUDIT.md SP3, D37): which sums keep a point fixed. A pointor ψ satisfies ψOψ̃ = λO.
// The drawing is the ladder of the cells spin_selfcheck.py stores (spin.json pointors and theorem3, through content/stored_p6.json), from the lowest
// stored dimension up (D37; or "from the top": the highest stored cell first, each lower one as its restriction): one rung per d, a mark per stored
// signature Cl(p,q), its shape the stored tally of "the sum is a pointor" (6 of 6 filled, some half, none hollow), the point O = b₁ … b_k of the rung
// in the labels of the page's lens (clifford, simplex, cube, demicube, prime: the frame's lens chips), and a rung with no stored cell drawn dashed,
// "not stored". Under it, the table of the rungs: the squares b_j² and O² by the kernel (= spin.json torus_algebra where stored) and the stored
// tallies. Then v15's live test in Cl(4,0), O = e₁₂₃₄: one ψ of the chosen kind (seeded), the verdict ψOψ̃ = λO, and the pointors among 12 samples
// of each kind (spinEngine.pointorSample; the kernel). Controls: the kind chips and the new-sample button (v15 PointorTest), the switch "from the top"
// (D37). Research level only.
import React, { useEffect, useMemo, useState } from 'react';
import { pointorLadder, pointorSampleOf, pointorTally, POINTOR_KINDS, lensLabel, D37_LENSES } from '../../../engines/physics/spinPhysics.js';
import { FigSvg, Controls, Chips, Toggle, r1 } from '../kit.jsx';
import { StatusGlyph } from './TranslationMatrix.jsx';
import { useStoredP6, f3, TexLabel } from './p6kit.jsx';
import './translation.css';

const KINDS = { flatland: 'ρ₋r + ρ₊R (one plane)', vR: '(α + βv)R', unrelated: 'αR + βP, P unrelated', versor: 'R alone' };
const T3 = [['(alpha+beta v)R', '(α + βv)R'], ['alpha R + beta P (P unrelated)', 'αR + βP, P unrelated'], ['cross term formula', 'cross term formula']];
/** the shape of a stored tally "a/b": all filled, some half, none hollow */
const tallyShape = t => { const m = /^(\d+)\/(\d+)$/.exec(String(t || '')); if (!m) return 'dash'; return +m[1] === +m[2] ? 'filled' : +m[1] === 0 ? 'hollow' : 'half'; };
const lensOf = l => (D37_LENSES.includes(l) ? l : 'clifford');
const sq = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');

export default function SpinPointor({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okKind = v => POINTOR_KINDS.includes(v), okSeed = v => Number.isInteger(v) && v >= 1;
  const [kind, setKind] = useState(okKind(params.kind) ? params.kind : 'vR'), [seed, setSeed] = useState(okSeed(params.seed) ? params.seed : 1), [top, setTop] = useState(params.top === true);
  useEffect(() => { setKind(okKind(params.kind) ? params.kind : 'vR'); }, [params.kind]);
  useEffect(() => { setSeed(okSeed(params.seed) ? params.seed : 1); }, [params.seed]);
  useEffect(() => { setTop(params.top === true); }, [params.top]);
  const S = useStoredP6(params);
  const L = useMemo(() => pointorLadder(S ? S.spin : null, { top }), [S, top]);
  const tally = useMemo(() => pointorTally(12), []), sample = pointorSampleOf(kind, seed), lk = lensOf(lens);
  const W = 440, rowH = 38, y0 = 30, H = y0 + Math.max(1, L.rungs.length) * rowH + 30, xCells = 96, cellW = 74;
  return (
    <div className="fig fig-spin-pointor" data-lens={lk} data-top={top ? 1 : 0}>
      <FigSvg id="spin-pointor" row={row} viewBox={`0 0 ${W} ${H}`} className="p6-draw">
        <text x={8} y={16} className="t-small">{top ? `from the top: d = ${L.dMax ?? '—'} down, each cell restricted` : `the stored cells, d = ${L.dMin ?? '—'} up`}</text>
        {!L.rungs.length ? <text x={8} y={y0 + 16} className="t-tiny t-muted">no stored cell loaded</text> : null}
        {L.rungs.map((g, i) => {
          const y = y0 + i * rowH + 14;
          return (
            <g key={g.d} data-rung={g.d} data-stored={g.stored ? 1 : 0} data-o={g.O}>
              <text x={8} y={y + 4} className="t-mono t-small">{`d = ${g.d}`}</text>
              <text x={8} y={y + 16} className="t-mono t-micro t-muted">{g.k ? `k = ${g.k}` : ''}</text>
              <line x1={xCells - 14} y1={y} x2={W - 8} y2={y} className="hair-2" style={g.stored ? undefined : { strokeDasharray: '3 3' }} />
              {g.stored ? g.cells.map((c, j) => {
                const t = c.pointors ? c.pointors.sum_is_pointor : null, x = xCells + j * cellW;
                return (
                  <g key={c.key} data-cell={c.key} data-tally={t || ''}>
                    <title>{`Cl(${c.p},${c.q}): the sum is a pointor ${t || '—'}`}</title>
                    <StatusGlyph shape={tallyShape(t)} x={x} y={y} s={11} />
                    <text x={x + 10} y={y + 4} className="t-mono t-tiny">{`Cl(${c.p},${c.q})`}</text>
                    <text x={x + 10} y={y + 15} className="t-mono t-micro t-muted">{t || '—'}</text>
                  </g>);
              }) : <text x={xCells} y={y - 4} className="t-tiny t-muted" data-not-stored={g.d}>not stored</text>}
              <text x={W - 8} y={y - 5} textAnchor="end" className="t-tiny" data-label={lk}>{`O = ${lensLabel(top ? g.restricted.O : g.O, lk, g.d)}`}</text>
            </g>
          );
        })}
        <g transform={`translate(8, ${H - 12})`}>
          <text x={0} y={0} className="t-tiny t-muted">the sum is a pointor in</text>
          {[['filled', 'all 6 samples'], ['half', 'some'], ['hollow', 'none']].map(([s, w], i) => <g key={s}><StatusGlyph shape={s} x={130 + i * 92 + 5} y={-4} s={9} /><text x={130 + i * 92 + 14} y={0} className="t-tiny">{w}</text></g>)}
        </g>
      </FigSvg>
      {research && (
        <>
          <Controls label="pointor test">
            <Chips label="kind of ψ" items={POINTOR_KINDS} value={kind} onPick={setKind} render={k => KINDS[k]} param="kind" />
            <button type="button" className="fig-btn" data-param="seed" onClick={() => setSeed(s => s + 1)}>new sample</button>
            <Toggle label={top ? 'from the top: on' : 'from the top'} on={top} onChange={setTop} param="top" />
          </Controls>
          <div className="p6-out">
            <p data-sample={`${sample.kind},${sample.seed}`} data-pointor={sample.pointor ? 1 : 0}>
              <span className="k">{`Cl(4,0), O = e₁₂₃₄ · sample ${sample.seed}`}</span>
              <span className="v">{`ψ = ${sample.text}`}</span>
              <span className="v"><TexLabel tex={'\\psi O\\tilde\\psi'} alt="ψOψ̃" level={level} />{sample.pointor ? ` = ${f3(sample.lambda)}·O: a pointor` : ' is not a multiple of O: not a pointor'}</span>
            </p>
          </div>
          <div className="p6-scroll">
            <table className="p6-tab" data-tally={POINTOR_KINDS.map(k => `${k}:${tally[k]}`).join(',')}>
              <thead><tr><th>kind of ψ</th><th>pointors among 12 samples</th></tr></thead>
              <tbody>{POINTOR_KINDS.map(k => <tr key={k} data-kind={k}><td>{KINDS[k]}</td><td className="m">{`${tally[k]}/12`}</td></tr>)}</tbody>
            </table>
          </div>
          {L.rungs.length ? (
            <div className="p6-scroll">
              <table className="p6-tab" data-ladder={L.rungs.map(g => g.d).join(',')}>
                <thead><tr><th>cell</th><th>b_j²</th><th>O²</th><th>the sum is a pointor</th><th>even part versor-like</th>{T3.map(([, n]) => <th key={n}>{n}</th>)}</tr></thead>
                <tbody>{L.rungs.flatMap(g => (g.stored ? g.cells.map(c => (
                  <tr key={c.key} data-row-cell={c.key} data-squares={`${c.squares.b.join(',')}|${c.squares.O}`}>
                    <td className="m">{`d = ${g.d} · Cl(${c.p},${c.q})`}</td>
                    <td className="m">{c.squares.b.map(sq).join(', ')}</td><td className="m">{sq(c.squares.O)}</td>
                    <td className="m">{c.pointors ? c.pointors.sum_is_pointor : 'not stored'}</td><td className="m">{c.pointors ? c.pointors.even_part_is_versor_like : 'not stored'}</td>
                    {T3.map(([k]) => <td key={k} className="m">{c.theorem3 ? c.theorem3[k] : 'not stored'}</td>)}
                  </tr>)) : [<tr key={'d' + g.d} data-row-cell={`${g.d},none`}><td className="m">{`d = ${g.d}`}</td><td colSpan={7}>not stored</td></tr>]))}</tbody>
              </table>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
SpinPointor.meta = { id: 'spin-pointor', lenses: D37_LENSES, learner: false };
SpinPointor.data = (params = {}) => {
  const kind = POINTOR_KINDS.includes(params.kind) ? params.kind : 'vR', seed = Number.isInteger(params.seed) && params.seed >= 1 ? params.seed : 1;
  const L = pointorLadder(params.stored ? params.stored.spin : null, { top: params.top === true });
  return { sample: pointorSampleOf(kind, seed), tally: pointorTally(12), ladder: L.rungs.map(g => ({ d: g.d, stored: g.stored, cells: g.cells.map(c => ({ key: c.key, squares: c.squares, pointors: c.pointors, theorem3: c.theorem3 })) })) };
};
SpinPointor.params = [{}, { kind: 'unrelated', seed: 2 }, { top: true }, { kind: 'flatland' }];
