// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-hestenes (step 5; caption row EQN-017; docs/PHYSICS_AUDIT.md SP2): Hestenes spinors in Cl(1,3) (bit 0 = γ₀, bits 1–3 = γ₁ γ₂ γ₃). The drawing:
// the chirality ψ ↦ IψJ (J = γ₂γ₁, the complex structure taken as an input) on the 8 even blades, each blade joined to its image, the mask x ⊕ 9, with the
// sign the kernel gives (engines/physics/spinPhysics.js chiralityXor): four pairs, so two eigenspaces of dimension 4. Research level, under it: one
// even element ψ (random, or an even versor; seeded) with ψψ̃ = a + b·I and the pointor test, exactly when b = 0 (spinEngine.hestenes); over 24 random
// even elements, "pointor" and "b = 0" agree in 24; and the free plane waves of the Dirac step as spin.json stores them (mass, momentum, energy:
// kernel dimension 4, b = 0, the sign of a; off shell, kernel dimension 0). Controls (v15 HestenesSlice): the kind chips and the new-sample button.
import React, { useEffect, useMemo, useState } from 'react';
import { chiralityXor, hestenesSample, hestenesAgreement, I13 } from '../../../engines/physics/spinPhysics.js';
import { FigSvg, Controls, Chips, r1 } from '../kit.jsx';
import { useStoredP6, f3, TexLabel } from './p6kit.jsx';
import './translation.css';

const KINDS = { generic: 'random even element', versor: 'even versor' };
const SUBS = '₀₁₂₃';
/** a mask of Cl(1,3) by Hestenes' names: 9 → γ₀γ₃, 0 → 1 */
export const gammaName = m => { let s = ''; for (let i = 0; i < 4; i++) if (Math.floor(m / 2 ** i) % 2) s += 'γ' + SUBS[i]; return s || '1'; };
/** "m=3 p=(0, 0, 4) E=5" → { m: 3, p: [0, 0, 4], E: 5 }; an off-shell key → { off: true, label } */
export function parseWave(key) {
  const k = /^m=(\d+) p=\(([^)]*)\) E=(-?\d+)$/.exec(key);
  if (k) return { m: +k[1], p: k[2].split(',').map(s => +s.trim()), E: +k[3] };
  const o = /^off shell \(E=(-?\d+), p=\(([^)]*)\), m=(\d+)\)$/.exec(key);
  return o ? { off: true, E: +o[1], p: o[2].split(',').map(s => +s.trim()), m: +o[3] } : { off: true };
}

export default function SpinHestenes({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okKind = v => v === 'generic' || v === 'versor', okSeed = v => Number.isInteger(v) && v >= 1;
  const [kind, setKind] = useState(okKind(params.kind) ? params.kind : 'generic'), [seed, setSeed] = useState(okSeed(params.seed) ? params.seed : 1);
  useEffect(() => { setKind(okKind(params.kind) ? params.kind : 'generic'); }, [params.kind]);
  useEffect(() => { setSeed(okSeed(params.seed) ? params.seed : 1); }, [params.seed]);
  const T = useMemo(() => chiralityXor(), []), agree = useMemo(() => hestenesAgreement(24), []), h = hestenesSample(kind, seed);
  const S = useStoredP6(params);
  const waves = S ? Object.entries(S.spin.free_waves).map(([k, v]) => ({ key: k, ...parseWave(k), ...v })) : [];
  const pairs = T.filter(t => t.x < t.m);
  const W = 440, H = 170, x0 = 60, dx = 100, yTop = 52, yBot = 118;
  return (
    <div className="fig fig-spin-hestenes">
      <FigSvg id="spin-hestenes" row={row} viewBox={`0 0 ${W} ${H}`}>
        <text x={8} y={18} className="t-small">{`ψ ↦ IψJ on the 8 even blades: e_x ↦ ± e_(x ⊕ 9)`}</text>
        <text x={8} y={yTop + 4} className="t-mono t-tiny t-muted">x</text>
        <text x={8} y={yBot + 4} className="t-mono t-tiny t-muted">x ⊕ 9</text>
        {pairs.map((t, i) => {
          const x = x0 + i * dx;
          return (
            <g key={t.x} data-pair={`${t.x},${t.m}`} data-sign={t.s} data-xor={t.xor} data-ok={t.ok ? 1 : 0}>
              <title>{`${gammaName(t.x)} ↦ ${t.s < 0 ? '−' : '+'}${gammaName(t.m)} (mask ${t.x} ⊕ 9 = ${t.m})`}</title>
              <line x1={x} y1={yTop + 8} x2={x} y2={yBot - 12} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: t.s < 0 ? '4 3' : undefined }} />
              <circle cx={x} cy={yTop} r={4} className="ink" /><circle cx={x} cy={yBot} r={4} className="stroke-ink" style={{ strokeWidth: 1.4 }} />
              <text x={x + 8} y={yTop + 4} className="t-mono t-small">{gammaName(t.x)}</text>
              <text x={x + 8} y={yBot + 4} className="t-mono t-small">{gammaName(t.m)}</text>
              <text x={x + 6} y={r1((yTop + yBot) / 2 + 3)} className="t-mono t-tiny">{t.s < 0 ? '− (dashed)' : '+'}</text>
            </g>
          );
        })}
        <text x={8} y={H - 10} className="t-mono t-tiny t-muted" data-halves={`${pairs.length},${pairs.length}`}>{`${pairs.length} pairs · eigenspaces of dimension ${pairs.length} and ${pairs.length} · I = ${gammaName(I13)}, J = γ₂γ₁`}</text>
      </FigSvg>
      {research && (
        <>
          <Controls label="sample">
            <Chips label="kind of ψ" items={Object.keys(KINDS)} value={kind} onPick={setKind} render={k => KINDS[k]} param="kind" />
            <button type="button" className="fig-btn" data-param="seed" onClick={() => setSeed(s => s + 1)}>new sample</button>
          </Controls>
          <div className="p6-out">
            <p data-sample={`${h.kind},${h.seed}`} data-a={h.a} data-b={h.b} data-pointor={h.pointor ? 1 : 0}>
              <span className="k">{`sample ${h.seed}`}</span>
              <span className="v"><TexLabel tex={'\\psi\\tilde\\psi'} alt="ψψ̃" level={level} />{` = ${f3(h.a)} ${h.b < 0 ? '−' : '+'} ${f3(Math.abs(h.b))}·I${h.other ? ' (+ other grades)' : ''}`}</span>
              <span>{h.pointor ? 'a pointor' : 'not a pointor'}</span>
            </p>
            <p data-agree={`${agree.agree}/${agree.of}`}><span className="k">pointor exactly when b = 0</span><span className="v">{`${agree.agree} of ${agree.of} random even elements`}</span></p>
          </div>
          {waves.length ? (
            <div className="p6-scroll">
              <table className="p6-tab" data-waves={waves.length}>
                <thead><tr><th>free plane wave</th><th>kernel dimension</th><th>b</th><th>sign of a</th></tr></thead>
                <tbody>{waves.map(w => (
                  <tr key={w.key} data-wave={w.key} data-kernel={w.kernel_dim}>
                    <td className="m nw">{`${w.off ? 'off shell: ' : ''}m = ${w.m}, p = (${(w.p || []).join(', ')}), E = ${String(w.E).replace('-', '−')}`}</td>
                    <td className="m">{w.kernel_dim}</td><td className="m">{w.b === undefined ? '—' : w.b}</td><td className="m">{w.a_sign === undefined ? '—' : w.a_sign > 0 ? '+' : '−'}</td>
                  </tr>))}</tbody>
              </table>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
SpinHestenes.meta = { id: 'spin-hestenes', lenses: [], learner: false };
SpinHestenes.data = (params = {}) => {
  const kind = params.kind === 'versor' ? 'versor' : 'generic', seed = Number.isInteger(params.seed) && params.seed >= 1 ? params.seed : 1;
  return { chirality: chiralityXor().map(t => ({ x: t.x, image: t.m, sign: t.s })), sample: hestenesSample(kind, seed), agreement: hestenesAgreement(24) };
};
SpinHestenes.params = [{}, { kind: 'versor', seed: 3 }, { seed: 5 }];
