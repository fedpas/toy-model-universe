// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p7.js — owner P7 registers its figures here (id → component): steps 6–8, coupling, Yang–Mills and charged matter (docs/PHYSICS_AUDIT.md
// §2.6–2.8). Seeds in content/physics/figures.p7.json; the stored check data in content/stored_p7.json (D34); the engine engines/physics/gauge.js; the test
// tests/physics/p7.test.mjs.
import CouplingRing from './CouplingRing.jsx';
import CouplingLadder from './CouplingLadder.jsx';
import YmGraph from './YmGraph.jsx';
import YmLadder from './YmLadder.jsx';
import MatterHalves from './MatterHalves.jsx';
import MatterLadder from './MatterLadder.jsx';
export const P7_FIGURES = {
  'coupling-ring': CouplingRing,
  'coupling-ladder': CouplingLadder,
  'ym-graph': YmGraph,
  'ym-ladder': YmLadder,
  'matter-halves': MatterHalves,
  'matter-ladder': MatterLadder,
};
