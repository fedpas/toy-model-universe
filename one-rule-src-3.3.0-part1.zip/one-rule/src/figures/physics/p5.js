// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p5.js — owner P5 registers its figures here (id → component): comm-ladder (step 2, the commutators by n; docs/PHYSICS_AUDIT.md CM3).
// The other gaps of P5 (CM1, CM2, DI1–DI6) are closed in the figures comm-graph and dirac-pic (src/figures/CommGraph.jsx, src/figures/DiracPic.jsx).
import CommLadder from './CommLadder.jsx';
export const P5_FIGURES = { 'comm-ladder': CommLadder };
