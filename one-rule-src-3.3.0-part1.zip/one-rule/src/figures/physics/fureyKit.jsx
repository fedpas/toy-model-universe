// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/fureyKit.jsx — what the Furey figures of owner P10 share: the stored table content/stored_p10.json (D34: loaded on demand with
// useTable, or given as params.stored by a test), the frame drawn while it loads, and the ladder of D37 (the Atlas method): rungs drawn from the lowest up,
// the rung shown marked by shape and word, the step between two rungs named in the direction read (up from the lowest, or from the top, each lower rung
// as the one above restricted), a rung the data lacks drawn empty and marked "not stored". Tokens only; marks by shape and word.
import React from 'react';
import { useTable } from '../../app/content.js';
import { peekTable } from '../../app/store.js';
import { okStored } from '../../../engines/physics/furey.js';
import { r1 } from '../kit.jsx';

/** the stored table of P10: params.stored (a test's copy), else the loaded content table, else null while it loads */
export function useStored(params) {
  const [T] = useTable('stored_p10');
  return params && okStored(params.stored) ? params.stored : okStored(T) ? T : null;
}
/** the same, outside React (the figures' data() for the frame's download) */
export const peekStored = params => (params && okStored(params.stored) ? params.stored : okStored(peekTable('stored_p10')) ? peekTable('stored_p10') : null);

/** the frame of a panel whose stored numbers have not loaded yet */
export function Loading({ x, y, w, h, what = 'stored numbers' }) {
  return (
    <g data-loading={what}>
      <rect x={x} y={y} width={w} height={h} rx={6} className="on-panel" style={{ stroke: 'var(--line)', strokeDasharray: '4 3' }} />
      <text x={x + w / 2} y={y + h / 2 + 4} textAnchor="middle" className="t-small t-muted">{`loading the ${what}`}</text>
    </g>
  );
}

/** a small triangle pointing right: the rung or the item shown */
export const Pointer = ({ x, y, s = 6 }) => <path d={`M${r1(x)} ${r1(y - s / 2)} L${r1(x + s)} ${r1(y)} L${r1(x)} ${r1(y + s / 2)} Z`} className="ink" />;

/**
 * The ladder of D37: rows[0] is the lowest rung; drawn bottom to top from (x, y) (y = the top of the highest rung). Each rung: an outlined bar with its title
 * and its detail; the rung `on` carries the pointer, a heavier outline and bold type; an empty rung (row.empty) is dashed and says "not stored".
 * Between two rungs, the step in the direction read: dir 'low' (up from the lowest) names the step up (up(i) for rung i − 1 → i), dir 'top' names the step
 * down (down(i) for rung i → i − 1: the lower rung as the restriction of the one above).
 */
export function Rungs({ x, y, w, rows, on, dir = 'low', step = 26, h = 20, up = () => '', down = () => '', param = 'rung' }) {
  const top = rows.length - 1, Y = i => y + (top - i) * step;
  return (
    <g data-ladder={param} data-dir={dir} data-rungs={rows.length}>
      {rows.map((row, i) => {
        const yy = Y(i), sel = i === on;
        return (
          <g key={row.key} data-rung={row.key} data-on={sel ? 1 : 0} data-empty={row.empty ? 1 : undefined}>
            <rect x={x + 14} y={yy} width={w - 14} height={h} rx={4} className="on-panel"
              style={{ stroke: row.empty ? 'var(--muted)' : 'var(--fg)', strokeWidth: sel ? 2 : 0.8, strokeDasharray: row.empty ? '4 3' : undefined }} />
            {sel && <Pointer x={x + 2} y={yy + h / 2} />}
            <text x={x + 20} y={yy + h / 2 + 4} className={'t-small' + (sel ? ' t-bold' : '')}>{row.title}</text>
            <text x={x + w - 6} y={yy + h / 2 + 4} textAnchor="end" className={'t-tiny' + (row.empty ? ' t-muted' : '')}>{row.empty ? 'not stored' : row.detail}</text>
          </g>
        );
      })}
      {rows.slice(1).map((row, k) => {
        const i = k + 1, yHi = Y(i) + h, yLo = Y(i - 1), mid = (yHi + yLo) / 2, t = dir === 'top' ? down(i) : up(i);
        return (
          <g key={'s' + i} data-step-between={`${rows[i - 1].key}|${row.key}`}>
            <path d={dir === 'top' ? `M${x + 24} ${r1(yHi + 1)} L${x + 24} ${r1(yLo - 1)} M${x + 21} ${r1(yLo - 4)} L${x + 24} ${r1(yLo - 1)} L${x + 27} ${r1(yLo - 4)}`
              : `M${x + 24} ${r1(yLo - 1)} L${x + 24} ${r1(yHi + 1)} M${x + 21} ${r1(yHi + 4)} L${x + 24} ${r1(yHi + 1)} L${x + 27} ${r1(yHi + 4)}`} className="stroke-muted" />
            {t ? <text x={x + 32} y={r1(mid + 3)} className="t-micro t-muted">{t}</text> : null}
          </g>
        );
      })}
    </g>
  );
}
