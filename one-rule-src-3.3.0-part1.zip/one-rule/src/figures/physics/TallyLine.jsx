// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/TallyLine.jsx — the tally line (owner P11; docs/PHYSICS_AUDIT.md §2.18 TL1). The fifteen summary rows EQN-006 … EQN-020 of the step pages
// are v15's tally table (TallySection.jsx), one line each: their research text is the four cells of the line joined by " · ". At research level this component
// renders such a row as a Statement whose text is set in those four cells under v15's column names (equation · where · components · incidences: connective
// words, data-connective), so that the counts are named; the text record is unchanged: the .statement__text holds the four cells and the three joiners in
// order (the joiners are hidden from the eye, kept for screen readers), byte for byte the record, as tests/coverage.test.mjs reads every statement. Everything
// else is Statement's: one badge from the computed status, the row's lens reading, the fold of a long text, the "›" to its drawer, the glossary terms (each in
// the cell where its first occurrence lies). At learner level, or when a text does not split into four cells, it renders the Statement itself.
// Used by src/components/Section.jsx for the rows of TALLY_ROWS; the hero of a page renders its row through Hero.jsx (light and steps/dirac today).
import { Fragment, useContext, useState } from 'react';
import { useSettings, textFor, statusOf } from '../../app/content.js';
import { useRoute } from '../../app/router.js';
import { PageContext } from '../../components/PageContext.js';
import Statement from '../../components/Statement.jsx';
import RichText from '../../components/RichText.jsx';
import Badge from '../../components/Badge.jsx';
import LensReading from '../../components/LensReading.jsx';
import { Chevron } from '../../components/Icons.jsx';
import './rigid.css';

/** the tally rows: Maxwell (Calibration 1) and the steps, EQN-006 … EQN-020 */
export const TALLY_ROWS = Array.from({ length: 15 }, (_, i) => `EQN-${String(i + 6).padStart(3, '0')}`);
/** v15's column names (equationsCopy.js t.cols, without its status column) */
export const TALLY_COLUMNS = ['equation', 'where', 'components', 'incidences'];
export const TALLY_JOIN = ' · ';
export const isTallyRow = id => TALLY_ROWS.includes(id);
/** the four cells of a tally text, or null when it does not split into four */
export function tallyCells(text) {
  if (typeof text !== 'string') return null;
  const cells = text.split(TALLY_JOIN);
  return cells.length === TALLY_COLUMNS.length && cells.every(c => c.trim()) ? cells : null;
}
const LONG = { body: 700, hero: 520 };

export default function TallyLine({ id, variant = 'body' }) {
  const s = useSettings();
  const ctx = useContext(PageContext);
  const route = useRoute();
  const [expanded, setExpanded] = useState(false);
  const text = textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register: 'full' });
  const cells = s.level === 'learner' ? null : tallyCells(text);
  if (!cells) return <Statement id={id} variant={variant} />;
  const st = statusOf(id);
  const terms = ctx.gloss ? ctx.gloss.get(id) : null;
  // each glossary term goes to the cell that holds its first occurrence in the whole text (as RichText would mark it in one piece)
  const starts = cells.reduce((acc, c, i) => [...acc, i ? acc[i - 1] + cells[i - 1].length + TALLY_JOIN.length : 0], []);
  const termsOf = i => (terms || []).filter(t => { const m = new RegExp(t.re.source, t.re.flags.replace('g', '')).exec(text); return m && m.index >= starts[i] && m.index < starts[i] + cells[i].length; });
  const foldable = text.length > (LONG[variant] || LONG.body);
  const canOpen = ctx.openEvidence && ctx.hasDrawer(id);
  const cls = ['statement', `statement--${variant}`, 'statement--tally'];
  if (foldable && !expanded) cls.push('statement--folded');
  if (route.at === id) cls.push('is-target');
  const textId = `txt-${variant}-${id}`;
  return (
    <div className={cls.join(' ')} data-row={id} data-register="full" data-tally={id} id={`row-${id}`}>
      <div className="tally">
        <span className="tally__names" aria-hidden="true">
          {TALLY_COLUMNS.map(c => <span key={c} className="tally__name" data-connective="tally-column" data-col={c}>{c}</span>)}
        </span>
        <p className="statement__text tally__cells" id={textId}>
          {cells.map((c, i) => (
            <Fragment key={i}>
              {i ? <span className="tally__join">{TALLY_JOIN}</span> : null}
              <span className="tally__cell" data-col={TALLY_COLUMNS[i]}><RichText text={c} level={s.level} terms={termsOf(i)} uid={`${variant}-${id}`} /></span>
            </Fragment>
          ))}
        </p>
      </div>
      <LensReading id={id} />
      <div className="statement__meta">
        {st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null}
        {foldable ? <button type="button" className="statement__more" aria-expanded={expanded} aria-controls={textId} onClick={() => setExpanded(x => !x)}>{expanded ? 'Show less' : 'Show all'}</button> : null}
        {canOpen ? (
          <button type="button" className="statement__ev" aria-label={`Evidence and more for this statement (${id})`} title="Evidence and more" onClick={() => ctx.openEvidence(id)}>
            <Chevron />
          </button>
        ) : null}
      </div>
    </div>
  );
}
