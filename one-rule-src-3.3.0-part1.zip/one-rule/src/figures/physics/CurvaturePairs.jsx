// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure curvature-pairs (step 9, GRV-004; docs/PHYSICS_AUDIT.md G1–G3): the table of curvature components of Cl(1, n−1), n = 2 … 8. Each cell is an unordered pair of
// planes (a b | c d), drawn by its class — a filled square for the same plane, a dot where the planes share one axis (their bivectors do not commute: the kernel
// commutator of engines/physics/gravity.js; the edges of the commutator graph of step 2), a hollow square where they share none (they commute) — with the planes
// printed in the base of the page lens (D37). The class chips light one class; four axes (n ≥ 4) light the three cells that one first-Bianchi relation
// R(ab|cd) + R(ac|db) + R(ad|bc) = 0 ties (in the simplex lens drawn as the three pairs of opposite edges of their tetrahedron, our reading GRV-001b). "From the top"
// (D37) draws the table of n = 8 and lights the table of n as its restriction (the planes of the first n axes, ordered so that they come first). Beside it: the
// counts that gravity_selfcheck.py stored (gravity.json ladder: the classes, the relations, the independent components), the ladder n = 2 … 8 and the matrix
// check of gravity_matrix_check.py (gravity_matrix.json) — read from content/stored_p8.json and tied, number by number, to the kernel in tests/physics/p8.test.mjs.
// Learner level: the same picture with the classes in words and the counts as readouts. Port of v15 GravitySection.jsx PairGrid and its tables.
import React, { useState, useEffect, useMemo } from 'react';
import { FigSvg, Controls, Chips, r1, pick, isIn } from '../kit.jsx';
import Badge from '../../components/Badge.jsx';
import { pairGrid, quadsOf, bianchiTriple, restriction, storedAlgebra, NS } from '../../../engines/physics/gravity.js';
import { useStored, peekStored, Tex, useKatex, printing, printLabel, TopToggle, Table, Fold, Loading, D37_LENSES } from './p8kit.jsx';

const CLS = ['all', 'diagonal', 'one', 'disjoint'], TOP = 8;
const WORD = {
  research: { all: 'all', diagonal: 'same plane', one: 'one axis shared', disjoint: 'no axis shared' },
  learner: { all: 'all', diagonal: 'same plane', one: 'sharing one direction', disjoint: 'sharing none' },
};
const GLYPH = { diagonal: '■', one: '●', disjoint: '□' };
const KEY = { diagonal: 'diagonal', one: 'share_one_index', disjoint: 'disjoint' };
const quadMask = q => q.reduce((m, i) => m | (1 << i), 0);

/** a cell's mark: the same plane a filled square, one axis shared a dot, none a hollow square */
function Mark({ cls, x, y, s }) {
  const p = Math.max(0.6, s * 0.12);
  if (cls === 'diagonal') return <rect x={r1(x + p)} y={r1(y + p)} width={r1(s - 2 * p)} height={r1(s - 2 * p)} className="ink" />;
  if (cls === 'one') return <circle cx={r1(x + s / 2)} cy={r1(y + s / 2)} r={r1(s * 0.3)} className="ink" />;
  return <rect x={r1(x + 1.4 * p)} y={r1(y + 1.4 * p)} width={r1(s - 2.8 * p)} height={r1(s - 2.8 * p)} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: Math.max(0.7, s * 0.07) }} />;
}

/** the tetrahedron of four axes with its three pairs of opposite edges, each pair one cell of the relation (our reading GRV-001b) */
function Tetra({ q, how, n, x0, y0 }) {
  const P = [[0, 0], [70, 8], [26, 62], [52, 40]].map(([a, b]) => [x0 + a, y0 + b]), dash = ['', '5 3', '1.5 2.5'];
  const pairs = [[[0, 1], [2, 3]], [[0, 2], [1, 3]], [[0, 3], [1, 2]]];
  return (
    <g data-tetra={q.join('')}>
      {pairs.map((pp, k) => pp.map(([i, j]) => <line key={`${k}${i}${j}`} x1={P[i][0]} y1={P[i][1]} x2={P[j][0]} y2={P[j][1]} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: dash[k] || undefined }} data-pair={k} />))}
      {P.map((p, i) => <g key={i}><circle cx={p[0]} cy={p[1]} r={3.2} className="ink" /><text x={p[0] + 5} y={p[1] - 4} className="t-mono t-tiny">{printLabel(1 << q[i], how, n)}</text></g>)}
    </g>
  );
}

export default function CurvaturePairs({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner', W = WORD[research ? 'research' : 'learner'], how = printing(lens, mode, level);
  const init = () => ({ n: pick(params.n, isIn(NS), 4), cls: pick(params.cls, isIn(CLS), 'all'), sub: Number.isInteger(params.sub) ? params.sub : null, top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.n, params.cls, params.sub, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { n, cls, top } = st, quads = useMemo(() => quadsOf(n), [n]), sub = st.sub !== null && st.sub < quads.length ? st.sub : null;
  const set = p => setSt(s => ({ ...s, ...p }));
  const katex = useKatex(research), S = useStored();
  const shown = top ? TOP : n, G = useMemo(() => pairGrid(shown), [shown]), own = useMemo(() => pairGrid(n), [n]);
  const order = [...G.planes].sort((a, b) => a - b), at = new Map(order.map((m, i) => [m, i])), lim = 1 << n;
  const tie = sub !== null ? bianchiTriple(quads[sub]) : null, tieKey = tie ? new Set(tie.map(([a, b]) => `${Math.min(a, b)},${Math.max(a, b)}`)) : null;
  // the grid in the middle of a fixed frame, a cell at most 44 units wide (a small n stays small); its labels follow it
  const P = order.length, s = Math.min(44, 368 / P), L = 44 + (368 - P * s) / 2, fs = P > 15 ? 7.2 : P > 6 ? 8.5 : 10;
  const lit = c => (c.A < lim && c.B < lim) && (tieKey ? tieKey.has(`${Math.min(c.A, c.B)},${Math.max(c.A, c.B)}`) : cls === 'all' || cls === c.cls);
  const L_ = S ? S.gv.ladder[n] : null, CS = S ? S.gv.curvature_space : null, rel = L_ ? L_.first_bianchi_constraints : null;
  const counts = own.counts, cells = own.cells.length, demi = lens === 'demicube', simp = lens === 'simplex';
  const R = top ? restriction(n, TOP) : null;
  const cellName = (a, b) => `${printLabel(a, how, n)}|${printLabel(b, how, n)}`;
  return (
    <div className="fig fig-curvature-pairs gp-split">
      <FigSvg id="curvature-pairs" row={row} viewBox="0 0 420 420">
        <g data-n={n} data-shown={shown} data-top={top ? 1 : 0} data-printing={how}>
          {order.map((m, i) => {
            const on = m < lim, x = L + i * s + s / 2;
            return (
              <g key={m} className={on ? undefined : 'gp-faint'} data-plane={m}>
                <text transform={`translate(${r1(x + fs * 0.35)}, ${L - 4}) rotate(-90)`} className="t-mono" style={{ fontSize: `${fs}px` }}>{printLabel(m, how, shown)}</text>
                <text x={L - 4} y={r1(L + i * s + s / 2 + fs * 0.35)} textAnchor="end" className="t-mono" style={{ fontSize: `${fs}px` }}>{printLabel(m, how, shown)}</text>
              </g>
            );
          })}
          {top && <rect x={L} y={L} width={r1(own.planes.length * s)} height={r1(own.planes.length * s)} className="stroke-ink" style={{ strokeWidth: 1.6, strokeDasharray: '5 3' }} data-restriction={n} />}
          {G.cells.map(c => {
            const i = at.get(c.A), j = at.get(c.B), x = L + Math.max(i, j) * s, y = L + Math.min(i, j) * s, on = lit(c);
            return (
              <g key={`${c.A},${c.B}`} className={on ? undefined : 'gp-faint'} data-cell={`${Math.min(c.A, c.B)},${Math.max(c.A, c.B)}`} data-class={c.cls} data-dist={c.dist} data-lit={on ? 1 : 0}>
                <title>{`(${cellName(c.A, c.B)}) ${W[c.cls]}${demi ? ` · distance ${c.dist}` : ''}`}</title>
                <Mark cls={c.cls} x={x} y={y} s={s} />
              </g>
            );
          })}
        </g>
      </FigSvg>
      <Controls label={research ? 'curvature components' : 'how space bends'}>
        <Chips label={research ? 'n' : 'directions'} items={NS} value={n} onPick={v => set({ n: v, sub: null })} param="n" mono />
        <Chips label={research ? 'class' : 'boxes'} items={CLS} value={tie ? null : cls} onPick={v => set({ cls: v, sub: null })} render={k => (k === 'all' ? W.all : `${GLYPH[k]} ${W[k]}`)} param="cls" />
        {n >= 4 ? (
          <label className="fig-group" data-param="sub">
            <span className="fig-group-label">{research ? 'four axes' : 'four directions'}</span>
            <select className="fig-select" data-param="sub" value={sub === null ? '' : String(sub)} onChange={e => set({ sub: e.target.value === '' ? null : +e.target.value })}>
              <option value="">none</option>
              {quads.map((q, i) => <option key={i} value={String(i)}>{printLabel(quadMask(q), how, n)}</option>)}
            </select>
          </label>
        ) : null}
        <TopToggle on={top} onChange={v => set({ top: v })} research={research} top={TOP} />
      </Controls>
      <div className="gp-side">
        <p className="gp-read" data-counts={`${counts.diagonal},${counts.one},${counts.disjoint}`}>
          {['diagonal', 'one', 'disjoint'].map(k => <span key={k}>{`${GLYPH[k]} ${W[k]} `}<b data-count={k} data-stored={L_ ? L_.pair_classes[KEY[k]] : ''}>{L_ ? L_.pair_classes[KEY[k]] : counts[k]}</b></span>)}
          <span><span className="gp-k">{research ? 'cells' : 'boxes'}</span> <b data-cells={cells}>{cells}</b></span>
        </p>
        {S ? (
          <p className="gp-read" data-relations={rel} data-from-classes={L_.riemann_from_classes} data-independent={L_.riemann_independent}>
            {research
              ? <><span className="gp-k">first Bianchi, one relation per four axes:</span> <b>{rel}</b> <Tex katex={katex} tex={`${cells} - ${rel} = ${L_.riemann_from_classes} = \\tfrac{n^2(n^2-1)}{12}\\big|_{n=${n}}`} text={`${cells} − ${rel} = ${L_.riemann_from_classes} = n²(n²−1)/12 at n = ${n}`} /></>
              : <><span className="gp-k">relations</span> <b>{rel}</b> <span className="gp-k">free</span> <b>{L_.riemann_from_classes}</b></>}
          </p>
        ) : <Loading />}
        {tie ? (
          <p className="gp-read" data-quad={quads[sub].join('')} data-tie={tie.map(([a, b]) => `${a},${b}`).join(';')}>
            <span className="gp-k">{research ? `axes ${printLabel(quadMask(quads[sub]), how, n)}:` : `directions ${printLabel(quadMask(quads[sub]), how, n)}:`}</span>
            {research ? (() => { const [a, b, c, d] = quads[sub].map(i => printLabel(1 << i, 'letters', n)); return <Tex katex={katex} tex={`R_{${a}${b}\\,${c}${d}} + R_{${a}${c}\\,${d}${b}} + R_{${a}${d}\\,${b}${c}} = 0`} text={`R(${a}${b}|${c}${d}) + R(${a}${c}|${d}${b}) + R(${a}${d}|${b}${c}) = 0`} />; })()
              : <span>{tie.map(([x, y]) => `${printLabel(x, how, n)} with ${printLabel(y, how, n)}`).join(' · ')}</span>}
          </p>
        ) : null}
        {simp && sub !== null ? <FigSvg id="curvature-pairs" row={row} part={`four axes ${printLabel(quadMask(quads[sub]), how, n)} as a tetrahedron`} viewBox="0 0 120 92" className="gp-tetra"><Tetra q={quads[sub]} how={how} n={n} x0={18} y0={14} /></FigSvg> : null}
        {demi || simp ? <p className="gp-read" data-reading={lens}><span className="gp-k">{demi ? (research ? 'the classes as distances on the demicube: 0, 2, 4' : 'steps apart on the half-cube: 0, 2, 4') : (research ? 'four axes: one tetrahedron, its 3 pairs of opposite edges' : 'four directions: one tetrahedron')}</span><Badge kind="ours" level={level} /></p> : null}
        {top ? <p className="gp-read" data-restricted={R.cells}><span className="gp-k">{research ? `the table of n = ${n} inside n = ${TOP}:` : `inside ${TOP} directions:`}</span> <b>{R.cells}</b> <span className="gp-k">{`of ${G.cells.length}`}</span></p> : null}
        {research && S ? (
          <Fold title={`The ladder, n = ${top ? `${NS[NS.length - 1]} … ${NS[0]}` : `${NS[0]} … ${NS[NS.length - 1]}`}`} name="ladder">
            <Table name="grav1-ladder" caption="gravity.json ladder and curvature_space (gravity_selfcheck.py)" cols={[['n', 'n'], ['alg', 'frame algebra'], ['biv', 'bivectors (boosts + rotations)'], ['om', 'ω'], ['e', 'e'], ['R', 'R'], ['T', 'T'], ['ind', 'independent R'], ['rel', 'first-Bianchi relations'], ['rw', 'Ricci + Weyl']]}
              rows={(top ? [...NS].reverse() : NS).map(k => { const x = S.gv.ladder[k], cs = CS[k]; return { key: k, cur: k === n, cells: { n: k, alg: `Cl(1,${k - 1}) ≅ ${storedAlgebra(x.frame_algebra)}`, biv: `${x.bivectors} (${x.boosts} + ${x.rotations})`, om: x.omega_components, e: x.tetrad_components, R: x.curvature_components, T: x.torsion_components, ind: x.riemann_independent, rel: x.first_bianchi_constraints, rw: cs ? `${cs.ricci_rank} + ${cs.weyl_dimension}` : null } }; })} />
          </Fold>
        ) : null}
        {research && S ? (
          <Fold title="Independent check with matrices" name="matrix">
            <Table name="grav1-matrix" caption="gravity_matrix.json (gravity_matrix_check.py, numpy)" cols={[['n', 'n'], ['sc', 'structure constants'], ['cc', 'constant connections, error'], ['svd', 'curvature space by SVD: dimension, pair symmetric, Ricci rank']]}
              rows={NS.map(k => { const g = S.gvm, cs = g.curvature_space[k]; return { key: k, cur: k === n, cells: { n: k, sc: g.structure_constants[k] ?? null, cc: g.constant_connection_error[k] ?? null, svd: cs ? `${cs.dimension}, ${cs.pair_symmetric ? 'yes' : 'no'}, ${cs.ricci_rank}` : null } }; })} />
            <dl className="gp-kv" data-controls="gvm">
              <dt>wrong γ square</dt><dd>{S.gvm.controls.wrong_gamma_square}</dd>
              <dt>first Bianchi dropped</dt><dd data-dropped={S.gvm.controls.first_Bianchi_dropped}>{S.gvm.controls.first_Bianchi_dropped}</dd>
            </dl>
          </Fold>
        ) : null}
      </div>
    </div>
  );
}
CurvaturePairs.meta = { id: 'curvature-pairs', lenses: D37_LENSES, learner: true };
CurvaturePairs.params = [{}, { n: 2 }, { n: 3, cls: 'one' }, { n: 5, sub: 2 }, { n: 6, top: true }, { n: 8, cls: 'disjoint' }, { n: 4, sub: 0, top: true }];
/** the numbers the figure draws, for the frame's data download */
CurvaturePairs.data = (params = {}) => {
  const n = pick(params.n, isIn(NS), 4), G = pairGrid(n), S = peekStored();
  return { n, planes: G.planes, squares: G.squares, cells: G.cells.map(c => ({ A: c.A, B: c.B, cls: c.cls, dist: c.dist })), counts: G.counts, relations: quadsOf(n).length, stored: S ? { ladder: S.gv.ladder[n], curvature_space: S.gv.curvature_space[n] || null } : null };
};
