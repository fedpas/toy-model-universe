// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure furey-trialities (Furey, her papers; caption PAG-014; PHYSICS_AUDIT FU5): the numbers of her papers that furey_papers_check.py rebuilds. Left, one
// generation as numbers: the spectrum of Y, Q or B−L on the 16 states of Ψ_L (roadmap spectra_on_PsiL), with the total, the sum and the sum of cubes computed
// exactly (all three 0, as stored); for Y each value carries the Standard Model field of the engine's six types it is. Right, the three spaces of
// Trialities, Ψ⁺, Ψ⁻ and V: the hypercharge spectrum of each (32 real dimensions), the su(3) and su(2) ranks, the 14 derivations of 𝕆 (8 fix e₇, 6 move it).
// Below, the ladder ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 (D37: one more bit a rung, drawn from the lowest up, with the "from the top" switch that reads each lower rung as the one
// above with its top bit off): the labels of each rung in the lens (kernel label: Clifford words, bits, primes, vertex sets, the demicube's even labels),
// tri(𝕂) as stored, the octonion rung's sign marked as imported (INP-087), and the dimension arithmetic of e₇ and e₈ (133 and 248, as stored). Controls:
// v15's charge chips (FureyWidgets.jsx Spectra) and space chips (Triality), D37's rung stepper and switch.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Toggle, Stepper, r1, pick } from '../kit.jsx';
import { Sc } from '../FureyBoard.jsx';
import * as E from '../../../engines/fureyPapersEngine.js';
import { popcount } from '../../../engines/bitrule.js';
import { psiL, spectrum, leftHanded, freudenthal, divLadder, lensKey, labelIn, sum } from '../../../engines/physics/furey.js';
import { useStored, peekStored, Loading, Pointer } from './fureyKit.jsx';

const CH = { Y: ['Y', 'the weak force charge'], Q: ['Q', 'electric charge'], BL: ['B−L', 'quarks minus leptons'] };
const SP = { '+': ['Ψ⁺', 'Box A'], '-': ['Ψ⁻', 'Box B'], V: ['V', 'Box C'] };
const DIVN = { R: ['ℝ', 'real numbers'], C: ['ℂ', 'complex numbers'], H: ['ℍ', 'quaternions'], O: ['𝕆', 'octonions'] };
const LH = leftHanded();

/** bars of a spectrum in a box (x, base, width), heights against `max` */
function Bars({ S, x0, base, width, max, names = null, tag }) {
  const n = S.bars.length, slot = width / n, bw = Math.min(40, slot - 8);
  return S.bars.map((b, i) => {
    const x = x0 + (i + 0.5) * slot, h = r1((96 * b.count) / max), nm = names ? names(b) : null;
    return (
      <g key={b.k} {...{ [`data-${tag}-value`]: b.k, 'data-count': b.count }}>
        <rect x={r1(x - bw / 2)} y={base - h} width={r1(bw)} height={h} rx={2} className="ink" style={{ fillOpacity: 0.72 }} />
        <text x={r1(x)} y={base - h - 4} textAnchor="middle" className="t-tiny t-bold t-mono">{b.count}</text>
        <text x={r1(x)} y={base + 12} textAnchor="middle" className="t-tiny t-mono">{E.fmtY(b.y6)}</text>
        {nm ? <text x={r1(x)} y={base + 25} textAnchor="middle" className="t-micro t-muted"><Sc s={nm} /></text> : null}
      </g>
    );
  });
}

export default function FureyTrialities({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [charge, setCharge] = useState(pick(params.charge, v => v in CH, 'Y'));
  const [space, setSpace] = useState(pick(params.space, v => v in SP, '+'));
  const [dir, setDir] = useState(params.from === 'top' ? 'top' : 'low');
  const [rung, setRung] = useState(pick(params.rung, v => Number.isInteger(v) && v >= 0 && v <= 3, params.from === 'top' ? 3 : 0));
  useEffect(() => {
    setCharge(pick(params.charge, v => v in CH, 'Y')); setSpace(pick(params.space, v => v in SP, '+')); setDir(params.from === 'top' ? 'top' : 'low');
    setRung(pick(params.rung, v => Number.isInteger(v) && v >= 0 && v <= 3, params.from === 'top' ? 3 : 0));
  }, [params.charge, params.space, params.from, params.rung]);
  const flip = on => { setDir(on ? 'top' : 'low'); setRung(on ? 3 : 0); };
  const T = useStored(params), P = psiL(charge), key = lensKey(lens, level), D = divLadder(T ? T.fp.trialities : null);
  const tri = T ? T.fp.trialities : null, S = tri ? spectrum(tri.spectra[space].y) : null, F = tri ? freudenthal(tri) : null;
  const yName = b => (charge === 'Y' && research ? (LH.find(f => f.y6 === b.y6) || {}).name || null : null);
  return (
    <div className="fig fig-furey-trialities">
      <FigSvg id="furey-trialities" row={row} viewBox="0 0 760 452">
        <g data-spec-charge={charge} data-total={P.total} data-sum6={P.sum6} data-cubes216={P.cubes216}>
          <text x={4} y={14} className="t-small t-muted">{research ? <>{`${CH[charge][0]} on the 16 states of one generation (`}<Sc s="Ψ_L" />)</> : 'the 16 members of one family'}</text>
          <line x1={8} y1={150} x2={356} y2={150} className="stroke-ink" style={{ strokeOpacity: 0.5 }} />
          <Bars S={P} x0={8} base={150} width={348} max={Math.max(...P.bars.map(b => b.count))} names={yName} tag="spec" />
          <text x={4} y={196} className="t-small">{research ? `states ${P.total} · sum ${E.fmtY(P.sum6)} · sum of cubes ${P.cubes216 ? P.cubes216 + '/216' : '0'}` : `members ${P.total} · all added up ${E.fmtY(P.sum6)} · cubes added up ${P.cubes216 ? P.cubes216 + '/216' : '0'}`}</text>
        </g>
        <g>
          <text x={392} y={14} className="t-small t-muted">{research ? `the hypercharge spectrum of ${SP[space][0]} (Trialities)` : `the three boxes: ${SP[space][1]}`}</text>
          {!S ? <Loading x={392} y={30} w={364} h={160} what="trialities" /> : (
            <g data-space={space} data-real={S.total} data-rank-su3={tri.rank_su3} data-rank-su2={tri.rank_su2[space]} data-g2={F.g2.join(',')}>
              <line x1={396} y1={150} x2={756} y2={150} className="stroke-ink" style={{ strokeOpacity: 0.5 }} />
              <Bars S={S} x0={396} base={150} width={360} max={12} tag="tri" />
              <text x={392} y={196} className="t-small">{research ? `real dimensions ${S.total} · su(3) rank ${tri.rank_su3} · su(2) rank ${tri.rank_su2[space]}` : `places ${S.total}`}</text>
              {research && <text x={392} y={212} className="t-tiny">{`g₂: ${F.g2[0]} derivations of 𝕆 · ${F.g2[1]} fix e₇ · ${F.g2[2]} move it`}</text>}
            </g>
          )}
        </g>
        <g transform="translate(0, 228)" data-ladder="rung" data-dir={dir} data-lens={key}>
          <text x={4} y={12} className="t-small t-muted">{research ? 'one more bit a rung: ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆, their labels and tri(𝕂)' : 'numbers with 1, 2, 4 and 8 parts'}</text>
          {D.map((d, i) => {
            const y = 24 + (3 - i) * 38, sel = i === rung;
            return (
              <g key={d.key} data-tri-rung={d.key} data-bits={d.bits} data-labels={d.labels} data-tri={d.tri === null ? undefined : d.tri} data-on={sel ? 1 : 0} data-imported={d.imported ? 1 : 0} data-squares={d.squares ? d.squares.join(',') : undefined}>
                <rect x={14} y={y} width={742} height={26} rx={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: sel ? 2 : 0.7 }} />
                {sel && <Pointer x={2} y={y + 13} />}
                <text x={22} y={y + 17} className={'t-small' + (sel ? ' t-bold' : '')}>{research ? `${DIVN[d.key][0]}  ${d.cell || 'sign imported (INP-087)'}` : DIVN[d.key][1]}</text>
                {d.masks.map((m, j) => {
                  const lab = labelIn(m, key, d.bits), even = key === 'demicube' && popcount(m) % 2 === 0;
                  return (
                    <g key={m} data-label={lab} data-even={key === 'demicube' ? (even ? 1 : 0) : undefined}>
                      <rect x={176 + j * 62} y={y + 4} width={58} height={18} rx={3} className="on-panel" style={{ stroke: 'var(--line-2)', strokeWidth: even ? 1.8 : 0.7 }} />
                      <text x={205 + j * 62} y={y + 17} textAnchor="middle" className={'t-tiny t-mono' + (even ? ' t-bold' : '')}>{lab}</text>
                    </g>
                  );
                })}
                <text x={750} y={y + 17} textAnchor="end" className="t-tiny">{d.tri === null ? '' : research ? `tri = ${d.tri}` : `${d.labels} part${d.labels > 1 ? 's' : ''}`}</text>
              </g>
            );
          })}
          {D.slice(1).map((d, k) => {
            const i = k + 1, yHi = 24 + (3 - i) * 38 + 26, yLo = 24 + (3 - (i - 1)) * 38, down = dir === 'top';
            return (
              <g key={'s' + d.key} data-step-between={`${D[i - 1].key}|${d.key}`}>
                <path d={down ? `M24 ${yHi + 1} L24 ${yLo - 1} M21 ${yLo - 4} L24 ${yLo - 1} L27 ${yLo - 4}` : `M24 ${yLo - 1} L24 ${yHi + 1} M21 ${yHi + 4} L24 ${yHi + 1} L27 ${yHi + 4}`} className="stroke-muted" />
                <text x={32} y={r1((yHi + yLo) / 2 + 3)} className="t-micro t-muted">{down ? (research ? 'restricted: the top bit off' : 'one switch fewer') : (research ? 'one more bit' : 'one switch more')}</text>
              </g>
            );
          })}
          {key === 'demicube' && <text x={176} y={178} className="t-micro">{research ? 'bold: the even labels (the demicube)' : 'bold: an even number of switches on'}</text>}
          {F ? (
            <text x={4} y={198} className="t-tiny" data-e7={[...F.e7, sum(F.e7)].join(',')} data-e8={[...F.e8, sum(F.e8)].join(',')} data-sum39={[...F.sum39, sum(F.sum39)].join(',')} data-stored={`${tri.e7},${tri.e8}`}>
              {research ? `tri(ℂ) + tri(ℍ) + tri(𝕆) = ${F.sum39.join(' + ')} = ${sum(F.sum39)} · e₇: ${F.e7[0]} + ${F.e7[1]} + 3·(${F.H}·${F.O}) = ${sum(F.e7)} · e₈: ${F.e8[0]} + ${F.e8[1]} + 3·(${F.O}·${F.O}) = ${sum(F.e8)}`
                : `sizes of two famous shapes: ${F.e7[0]} + ${F.e7[1]} + ${F.e7[2]} = ${sum(F.e7)} · ${F.e8[0]} + ${F.e8[1]} + ${F.e8[2]} = ${sum(F.e8)}`}
            </text>
          ) : <text x={4} y={198} className="t-tiny t-muted">loading the stored numbers</text>}
        </g>
      </FigSvg>
      <Controls label="spectra and trialities">
        <Chips label="charge" items={['Y', 'Q', 'BL']} value={charge} onPick={setCharge} param="charge" render={c => CH[c][research ? 0 : 1]} />
        <Chips label={research ? 'space' : 'box'} items={['+', '-', 'V']} value={space} onPick={setSpace} param="space" render={c => SP[c][research ? 0 : 1]} />
        <Stepper label="rung" value={rung} min={0} max={3} onChange={setRung} param="rung" display={i => DIVN[D[i].key][0]} />
        <Toggle label="from the top" on={dir === 'top'} onChange={flip} param="from" />
      </Controls>
    </div>
  );
}
FureyTrialities.meta = { id: 'furey-trialities', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
FureyTrialities.params = [{}, { charge: 'BL', space: 'V', from: 'top' }, { charge: 'Q', space: '-', rung: 2 }];
/** the numbers the figure draws, for the frame's data download */
FureyTrialities.data = (params = {}) => {
  const T = peekStored(params), tri = T ? T.fp.trialities : null;
  return {
    psiL: Object.fromEntries(['Y', 'Q', 'BL'].map(c => { const s = psiL(c); return [c, { bars: s.bars.map(b => [b.k, b.count]), total: s.total, sum6: s.sum6, cubes216: s.cubes216 }]; })),
    trialities: tri ? { spectra: Object.fromEntries(['+', '-', 'V'].map(k => [k, spectrum(tri.spectra[k].y).bars.map(b => [b.k, b.count])])), rank_su3: tri.rank_su3, rank_su2: tri.rank_su2, ...freudenthal(tri) } : null,
    ladder: divLadder(tri).map(d => ({ key: d.key, bits: d.bits, labels: d.labels, tri: d.tri, imported: !!d.imported })),
  };
};
