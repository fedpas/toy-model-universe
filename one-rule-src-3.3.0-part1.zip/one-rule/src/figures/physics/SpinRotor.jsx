// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure spin-rotor (step 5; caption row SPN-002; docs/PHYSICS_AUDIT.md SP1): the rotor and the double cover. In Cl(2,0) with u = e₁, v = e₂ and B = uv,
// the rotor R = cos t + B sin t turns the vector v into R v R̃ (left dial, the kernel's product: engines/physics/spinPhysics.js rotorAt) while the rotor
// itself is the point (cos t, sin t) of its own dial (right): the vector turns by 2t while R turns by t, so at t = 180° every vector is back and R = −1;
// only t = 360° gives R = +1. The four quarter points of the rotor's dial carry their names (+1, B, −1, −B); the vector's start is dashed. Research
// level: the readout t, R = a + b·B, R v R̃ = x·u + y·v with the turn 2t, the state, and the two lines of the matrix this figure draws (S02, S03: rows
// SPN-M02, SPN-M03, as statements once their texts are merged). Learner level: the dial and the arrow, the readout in words ("dial 90° · arrow 180°").
// Controls (v15 RotorDial): research, the slider t in steps of 15° (interactive entry t); learner, chips of t (entry dial); both, play (data-play).
import React, { useEffect, useState } from 'react';
import { rotorAt, ROTOR_STEPS, STEP_DEG, vecName } from '../../../engines/physics/spinPhysics.js';
import { FigSvg, Controls, Chips, Range, PlayButton, useReducedMotion, arrowHead, r1 } from '../kit.jsx';
import { MatrixLines } from './TranslationMatrix.jsx';
import { useStoredP6, STATUS_WORDS, f3 } from './p6kit.jsx';
import './translation.css';

const LEARNER_STEPS = [0, 3, 6, 9, 12, 18, 24];          // 0°, 45°, 90°, 135°, 180°, 270°, 360°
const okN = v => Number.isInteger(v) && v >= 0 && v <= ROTOR_STEPS;
const STATE_WORDS = { '+1': 'dial shows +1', '-1': 'dial shows −1', B: 'dial a quarter round', '-B': 'dial three quarters round' };
const vecText = ([x, y]) => `${f3(x)}·u ${y < 0 ? '−' : '+'} ${f3(Math.abs(y))}·v`;
const nameText = n => (n ? n.replace('-', '−') : null);

export default function SpinRotor({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const n0 = okN(params.t) ? params.t : 6;
  const [n, setN] = useState(n0), [playing, setPlaying] = useState(false), reduced = useReducedMotion();
  useEffect(() => { setN(okN(params.t) ? params.t : 6); }, [params.t]);
  useEffect(() => {
    if (!playing) return undefined;
    if (reduced) { setPlaying(false); return undefined; }
    const id = setInterval(() => setN(x => (x >= ROTOR_STEPS ? 0 : x + 1)), 110);
    return () => clearInterval(id);
  }, [playing, reduced]);
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => setN(x => (x >= ROTOR_STEPS ? 0 : x + 1)) };
  const r = rotorAt(n), [a, b] = r.R, [vx, vy] = r.vec;
  const S = useStoredP6(params);
  const lines = S && research ? S.derived.spinLines.filter(l => l.id === 'S02' || l.id === 'S03').map(l => ({ id: l.id, left: l.left, right: l.right, badgeRow: l.row, status: l.status })) : [];
  const W = 440, H = 214, R0 = 70, L = { x: 110, y: 104 }, Rc = { x: 330, y: 104 };
  const tip = [L.x + R0 * vx, L.y - R0 * vy], rot = [Rc.x + R0 * a, Rc.y - R0 * b];
  const quarter = [['+1', Rc.x + R0 + 14, Rc.y + 4], ['B', Rc.x, Rc.y - R0 - 8], ['−1', Rc.x - R0 - 16, Rc.y + 4], ['−B', Rc.x, Rc.y + R0 + 16]];
  const readout = research
    ? [`t = ${r.deg}°`, `R = ${f3(a)} + ${f3(b)}·B`, `R v R̃ = ${vecText(r.vec)}${vecName(r.vec) ? ` = ${nameText(vecName(r.vec))}` : ''}`, `turn ${r.vecDeg}°`, r.state ? `R = ${nameText(r.state)}` : null, r.back ? 'vector back at v' : null]
    : [`dial ${r.deg}°`, `arrow ${2 * r.deg}°`, r.back ? 'arrow back home' : null, r.state ? STATE_WORDS[r.state] : null];
  return (
    <div className="fig fig-spin-rotor" data-t={n}>
      <FigSvg id="spin-rotor" row={row} viewBox={`0 0 ${W} ${H}`}>
        {[L, Rc].map((c, i) => <g key={i}><circle cx={c.x} cy={c.y} r={R0} className="hair-2" /><line x1={c.x - R0 - 8} y1={c.y} x2={c.x + R0 + 8} y2={c.y} className="hair-2" /><line x1={c.x} y1={c.y - R0 - 8} x2={c.x} y2={c.y + R0 + 8} className="hair-2" /></g>)}
        {/* the vector: its start v dashed, R v R̃ solid with an arrowhead */}
        <line x1={L.x} y1={L.y} x2={L.x} y2={L.y - R0} className="stroke-muted" style={{ strokeWidth: 1.4, strokeDasharray: '4 3' }} data-start="v" />
        <g data-vec={`${r1(vx)},${r1(vy)}`} data-turn={r.vecDeg}>
          <line x1={L.x} y1={L.y} x2={r1(tip[0])} y2={r1(tip[1])} className="stroke-ink" style={{ strokeWidth: 2.4 }} />
          <path d={arrowHead(L.x, L.y, tip[0], tip[1], 8)} className="ink" />
        </g>
        <text x={L.x - R0 - 4} y={18} className="t-small">{research ? 'R v R̃ in the plane of u, v' : 'the arrow'}</text>
        {research && <><text x={L.x + R0 + 6} y={L.y - 4} className="t-mono t-tiny t-muted">u</text><text x={L.x + 4} y={L.y - R0 - 6} className="t-mono t-tiny t-muted">v</text></>}
        {/* the rotor: the point (cos t, sin t), its quarter points named */}
        <line x1={Rc.x} y1={Rc.y} x2={r1(rot[0])} y2={r1(rot[1])} className="stroke-ink" style={{ strokeWidth: 1.6 }} />
        <circle cx={r1(rot[0])} cy={r1(rot[1])} r={5} className="ink" data-rotor={`${f3(a)},${f3(b)}`} data-state={r.state || ''} />
        {(research ? quarter : quarter.filter(q => q[0] === '+1' || q[0] === '−1')).map(([t, x, y]) => <text key={t} x={x} y={y} textAnchor="middle" className="t-mono t-tiny t-muted">{t}</text>)}
        <text x={Rc.x - R0 - 4} y={18} className="t-small">{research ? 'R = cos t + B sin t' : 'the dial'}</text>
        <text x={8} y={H - 8} className="t-mono t-tiny" data-readout={research ? 'research' : 'learner'}>{readout.filter(Boolean).join(' · ')}</text>
      </FigSvg>
      <Controls label="rotor angle">
        {research
          ? <Range label="t" value={n} min={0} max={ROTOR_STEPS} step={1} onChange={setN} display={v => `${v * STEP_DEG}°`} param="t" />
          : <Chips label="dial" items={LEARNER_STEPS} value={n} onPick={setN} render={v => `${v * STEP_DEG}°`} param="dial" />}
        <PlayButton player={player} />
      </Controls>
      {lines.length ? <MatrixLines rows={lines} level={level} lens={lens} mode={mode} figId="spin-rotor" statusWords={STATUS_WORDS} /> : null}
    </div>
  );
}
SpinRotor.meta = { id: 'spin-rotor', lenses: [], learner: true };
SpinRotor.data = (params = {}) => { const n = okN(params.t) ? params.t : 6, r = rotorAt(n); return { t: r.deg, R: r.R, vector: r.vec, turn: r.vecDeg, state: r.state, back: r.back }; };
SpinRotor.params = [{}, { t: 12 }, { t: 24 }, { t: 3 }];
