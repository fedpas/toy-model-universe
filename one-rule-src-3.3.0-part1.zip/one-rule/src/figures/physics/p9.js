// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p9.js — owner P9 registers its figures here (id → component): step 13, null surfaces (null-neck, null-criterion) and step 15, the spring
// (spring-oscillator, spring-faces, spring-table); seeds in content/physics/figures.p9.json, docs/PHYSICS_AUDIT.md §2.13 and §2.15.
import NullNeck from './NullNeck.jsx';
import NullCriterion from './NullCriterion.jsx';
import SpringOscillator from './SpringOscillator.jsx';
import SpringFaces from './SpringFaces.jsx';
import SpringTable from './SpringTable.jsx';

export const P9_FIGURES = {
  'null-neck': NullNeck,
  'null-criterion': NullCriterion,
  'spring-oscillator': SpringOscillator,
  'spring-faces': SpringFaces,
  'spring-table': SpringTable,
};
