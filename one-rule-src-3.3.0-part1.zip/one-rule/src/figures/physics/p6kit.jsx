// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p6kit.jsx — what P6's figures (spin and forque) share: the stored table content/stored_p6.json (D34, loaded on demand; a test
// passes it as the non-enumerable params.stored), the status words and threads of the two matrices (v15's), and the number formats.
import React from 'react';
import { useTable } from '../../app/content.js';
import { useKatex, texToHtml } from '../../app/math.js';

/** the stored table of P6: params.stored when a test gives it, else content/stored_p6.json (null while it loads) */
export function useStoredP6(params) {
  const [T] = useTable('stored_p6');
  const S = params && params.stored ? params.stored : T;
  return S && S.spin && S.forque ? S : null;
}
/** a parameter set that carries the stored table without printing it (as the render test does for the matrix figures) */
export const withStored = (o, stored) => Object.defineProperty({ ...o }, 'stored', { value: stored, enumerable: false });

/** the stored status of a matrix line (spin.json, forque.json: "ok", "note", "not checked") in v15's words */
export const STATUS_WORDS = { ok: 'agrees exactly', note: 'printed line differs', nc: 'not checked' };
/** the six threads of the spin matrix (spin.json matrix.threads; the test ties the two) */
export const SPIN_THREADS = ['reflect', 'labels', 'unit', 'spaces', 'pointor', 'states'];
/** v15's words for the source of a spin line (spinCopy labels.src) */
export const SPIN_SRC = { paper: 'paper only', lecture: 'lecture only', both: 'paper and lecture', ours: 'ours' };
/** v15's words for a finding (spin: authKind; forque: authKind) */
export const FINDING_WORDS = { spin: { slip: 'reads differently', remark: 'our reading' }, forque: { slip: 'reads differently', remark: 'remark' } };

const SUP = { '-': '⁻', 0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹' };
/** 4.4364e-13 → "4.4·10⁻¹³" (one decimal); a number ≥ 0.01 and < 1000 as it is to 2 decimals */
export function sci(v, digits = 1) {
  if (!Number.isFinite(v)) return '—';
  if (v === 0) return '0';
  const a = Math.abs(v);
  if (a >= 0.01 && a < 1000) return String(+v.toFixed(2)).replace('-', '−');
  const e = Math.floor(Math.log10(a)), m = v / 10 ** e;
  return `${String(+m.toFixed(digits)).replace('-', '−')}·10${String(e).split('').map(c => SUP[c]).join('')}`;
}
/** a signed number with a true minus sign, to three decimals (v15's f3) */
export const f3 = x => { const r = Math.abs(x) < 5e-7 ? 0 : Math.round(x * 1000) / 1000; return String(r).replace('-', '−'); };

/** a short formula of a readout (ψOψ̃, ψψ̃): typeset by KaTeX at research level once it is loaded, the plain characters before */
export function TexLabel({ tex, alt, level = 'research' }) {
  const research = level !== 'learner';
  const k = useKatex(research);
  const html = k && research ? texToHtml(tex) : null;
  return html ? <span className="math" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span>{alt}</span>;
}
