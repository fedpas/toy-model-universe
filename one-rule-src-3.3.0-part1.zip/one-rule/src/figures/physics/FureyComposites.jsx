// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure furey-composites (Furey, three generations; caption FUR-002, the physics twin of the audit's FUR-002b, which is shown in mathematics mode only;
// PHYSICS_AUDIT FU2): the irreps Fig. 1 lacks for a third set as tensor products of
// irreps it has — the three pairs of furey_papers.json composites (b_R ⊗ h ∋ Q_L, b_R ⊗ τ_R† ∋ u_R, h ⊗ (ν_τ, τ)_L ∋ ν_R), each product computed by
// engines/fureyPapersEngine.js product (exact colour, isospin and hypercharge arithmetic, shown term by term) and tied to the stored result in
// tests/physics/p10.test.mjs; at research level any two irreps of the cells can be multiplied (v15's free choice). Quantum numbers only, as the stored
// note says. Controls: v15's pair chips and the two selects of the free choice (FureyWidgets2.jsx Composites). The target is marked by a heavier outline
// and the word, never by colour alone.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, pick } from '../kit.jsx';
import { Sc } from '../FureyBoard.jsx';
import * as E from '../../../engines/fureyPapersEngine.js';
import { compositePairs, composite, irrepName } from '../../../engines/physics/furey.js';
import { useStored, peekStored } from './fureyKit.jsx';

const CN = { '3b': '3̄', '6b': '6̄' };
const cname = c => CN[c] || c;
const WORDS = { Q_L: ['bottom quark, Higgs pair', 'left-handed quarks'], u_R: ['bottom quark, anti tau', 'right-handed up quark'], nu_R: ['Higgs pair, tau and neutrino', 'right-handed neutrino'] };
/** a name with underscores as HTML with <sub> (for the chips) */
const Hsc = ({ s }) => { const out = []; let last = 0, m; const re = /_([^\s,()†]+)/g; while ((m = re.exec(s))) { out.push(s.slice(last, m.index), <sub key={m.index}>{m[1]}</sub>); last = m.index + m[0].length; } out.push(s.slice(last)); return <>{out}</>; };

export default function FureyComposites({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okPair = v => [0, 1, 2].includes(v) || (v === 'free' && research), okIx = v => Number.isInteger(v) && v >= 0 && v < E.CELL_IRREPS.length;
  const [sel, setSel] = useState(pick(params.pair, okPair, 0));
  const [ia, setIa] = useState(pick(params.a, okIx, 0)), [ib, setIb] = useState(pick(params.b, okIx, 1));
  useEffect(() => { setSel(pick(params.pair, okPair, 0)); setIa(pick(params.a, okIx, 0)); setIb(pick(params.b, okIx, 1)); }, [params.pair, params.a, params.b, research]);   // eslint-disable-line react-hooks/exhaustive-deps
  const T = useStored(params), pairs = compositePairs(T), free = sel === 'free' && research;
  const p = free ? null : pairs[sel], a = free ? E.CELL_IRREPS[ia] : p.a, b = free ? E.CELL_IRREPS[ib] : p.b;
  const X = composite(a, b, free ? null : p.target), n = X.prod.length, w = (376 - (n - 1) * 8) / n;
  const nameA = free ? irrepName(a) : p.names[0], nameB = free ? irrepName(b) : p.names[1];
  const note = T ? T.fp.composites_note.split(':')[0] : null;
  return (
    <div className="fig fig-furey-composites">
      <FigSvg id="furey-composites" row={row} viewBox="0 0 420 200">
        <text x={4} y={14} className="t-small t-muted">{research ? 'products of irreps' : 'multiplying two pieces'}</text>
        <g data-pair={free ? 'free' : sel} data-a={E.fmt(a)} data-b={E.fmt(b)} data-product={X.prod.map(E.fmt).join('+')} data-target={X.target || ''} data-found={X.found === null ? '' : X.found ? 1 : 0}>
          {research ? [[a, nameA, 8], [b, nameB, 220]].map(([r, nm, x], i) => (
            <g key={i}>
              <rect x={x} y={24} width={184} height={46} rx={7} className="on-panel" style={{ stroke: 'var(--fg)' }} />
              <text x={x + 92} y={44} textAnchor="middle" className="t-small t-bold t-mono">{E.fmtShow(r)}</text>
              {nm ? <text x={x + 92} y={61} textAnchor="middle" className="t-tiny t-muted"><Sc s={nm} /></text> : null}
            </g>
          )) : (
            <g>
              <rect x={8} y={24} width={396} height={46} rx={7} className="on-panel" style={{ stroke: 'var(--fg)' }} />
              <text x={206} y={52} textAnchor="middle" className="t-small">{WORDS[p.target][0]}</text>
            </g>
          )}
          {research && <text x={206} y={53} textAnchor="middle" className="t-head">⊗</text>}
          <text x={14} y={117} textAnchor="middle" className="t-head">=</text>
          {research ? X.prod.map((r, i) => {
            const hit = X.target && E.same(r, E.SM[X.target]), x = 28 + i * (w + 8), nm = irrepName(r);
            return (
              <g key={i} data-result={E.fmt(r)} data-hit={hit ? 1 : 0}>
                {hit && <text x={x + w / 2} y={88} textAnchor="middle" className="t-tiny t-bold">target</text>}
                <rect x={x} y={92} width={w} height={46} rx={7} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: hit ? 2.6 : 0.8 }} />
                <text x={x + w / 2} y={112} textAnchor="middle" className="t-small t-mono">{E.fmtShow(r)}</text>
                <text x={x + w / 2} y={129} textAnchor="middle" className="t-tiny t-muted">{nm ? <Sc s={nm} /> : '—'}</text>
              </g>
            );
          }) : (
            <g data-result={E.fmt(E.SM[p.target])} data-hit={1}>
              <rect x={28} y={92} width={376} height={46} rx={7} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 2.6 }} />
              <text x={216} y={120} textAnchor="middle" className="t-small t-bold">{WORDS[p.target][1]}</text>
            </g>
          )}
          {research ? (
            <text x={4} y={162} className="t-tiny t-mono" data-colour={X.colours.join(',')} data-isospin={X.isospins.join(',')} data-y6={X.y6.join(',')} data-dims={`${X.dim},${X.dims}`}>
              {`colour ${cname(a.c)} ⊗ ${cname(b.c)} = ${X.colours.map(cname).join(' ⊕ ')} · isospin ${a.i} ⊗ ${b.i} = ${X.isospins.join(' ⊕ ')} · Y ${E.fmtY(a.y)} ${b.y < 0 ? '−' : '+'} ${E.fmtY(Math.abs(b.y), false)} = ${E.fmtY(a.y + b.y)} · ${E.dimOf(a)} × ${E.dimOf(b)} = ${X.dims}`}
            </text>
          ) : null}
          <text x={4} y={research ? 182 : 164} className="t-small" data-found-line={X.found === null ? '' : X.found ? 1 : 0}>
            {research ? (X.target ? `${X.found ? 'in the product' : 'not in the product'}: ` : 'free choice of two irreps of the cells') : (X.found ? 'it appears' : 'it does not appear')}
            {research && X.target ? <><Sc s={X.target.replace('nu_', 'ν_')} />{` ${E.fmtShow(E.SM[X.target])}`}</> : null}
          </text>
          {note && <text x={416} y={research ? 182 : 164} textAnchor="end" className="t-tiny t-muted" data-note={note}>{research ? note : 'charges only'}</text>}
        </g>
      </FigSvg>
      <Controls label="products">
        <Chips label="pair" items={research ? [0, 1, 2, 'free'] : [0, 1, 2]} value={sel} onPick={setSel} param="pair"
          render={k => (k === 'free' ? 'free' : research ? <><Hsc s={pairs[k].names[0]} />{' ⊗ '}<Hsc s={pairs[k].names[1]} /></> : WORDS[pairs[k].target][0])} />
        {free && [['a', ia, setIa, 'first'], ['b', ib, setIb, 'second']].map(([k, v, set, lab]) => (
          <label key={k} className="fig-group" data-param={k}><span className="fig-group-label">{lab}</span>
            <select className="fig-select" data-param={k} value={v} onChange={e => set(+e.target.value)}>
              {E.CELL_IRREPS.map((r, i) => <option key={i} value={i}>{`${E.fmtShow(r)}${irrepName(r) ? ' = ' + irrepName(r) : ''}`}</option>)}
            </select>
          </label>
        ))}
      </Controls>
    </div>
  );
}
FureyComposites.meta = { id: 'furey-composites', lenses: [], learner: true };
FureyComposites.params = [{}, { pair: 2 }, { pair: 1 }, { pair: 'free', a: 2, b: 3 }];
/** the numbers the figure draws, for the frame's data download */
FureyComposites.data = (params = {}) => {
  const pairs = compositePairs(peekStored(params));
  return { pairs: pairs.map(p => { const X = composite(p.a, p.b, p.target); return { a: E.fmt(p.a), b: E.fmt(p.b), names: p.names, product: X.prod.map(E.fmt), target: p.target, found: X.found, stored: p.stored }; }) };
};
