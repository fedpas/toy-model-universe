// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure matter-ladder (step 8, section of steps/matter; audit MT2–MT5): what matter_selfcheck.py and matter_matrix_check.py store about matter charged under so(m)
// (content/stored_p7.json mt and mtm, D34). The ladder drawn first (D37): a rung per m = 2 … 8 from the lowest stored cell up, a column per block of stored data —
// the ladder at space-time 1 + 3, the space-time table (m = 3), the exact identities, the numpy matrix check — an empty dashed box where a block has no data;
// "from the top" starts at Cl(0,8) and marks every lower Cl(0,m) as its restriction (the kernel's signs). Beside it the chosen rung; under it, in folds, the ladder
// with the module and the standard names (D29 standard), the space-time table at m = 3 with the current's corner masks (printed in the lens) and distances, the
// identities on the grid of (m, n) (KaTeX, ✓ where stored) and the matrix check with its four wrong versions. Every number is the stored one; tests/physics/
// p7.test.mjs recomputes the counts n(G + 1) + 1, the module and the masks through the kernel (engines/physics/gauge.js) and ties the identities and the numpy
// results to the file only (D11). Port of v15 MatterSection.jsx (the table, the space-time table, the identities, the matrix check), with its chips m. Research only.
import React, { useEffect, useMemo, useState } from 'react';
import { labelIn, restricts, axName, GAUGE_MS, MATTER_KNOWN, AXES } from '../../../engines/physics/gauge.js';
import { Controls } from '../kit.jsx';
import { useStored, lensKey, intIn, Tex, Rungs, TopSwitch, Readout, Legend, Mark, NotStored, Fold, LadderSvg, MiniTable, useKatexAt } from './GaugeKit.jsx';

const TOP = 8, NS = [3, 4, 5, 6];
export const MT_IDENTITIES = [
  ['commutator_identity', '[D, D]Ψ = gFΨ', '[D_\\mu,D_\\nu]\\Psi=gF_{\\mu\\nu}\\Psi', '[D_μ, D_ν]Ψ = gF_μνΨ', '[D, D]'],
  ['gauge_covariance_of_E_first_order', 'equation covariant (first order)', '\\Psi\\to\\Psi-g\\lambda\\Psi,\\ A\\to A+D\\lambda:\\ \\delta E=-g\\lambda E', 'Ψ → Ψ − gλΨ, A → A + Dλ: δE = −gλE', 'covariant'],
  ['conserved_on_shell', 'D·j = 0 on shell', 'E=0\\ \\Rightarrow\\ D^\\nu j^a_\\nu=0', 'E = 0 ⇒ D^ν j^a_ν = 0', 'D·j = 0'],
  ['adjoint_covariance', 'j in the adjoint', '\\delta j^a=-g\\lambda^b f_{ab}{}^{c}j^c', 'δj^a = −gλ^b f_ab^c j^c', 'adjoint'],
  ['abelian_current_equals_step3_X', 'the J-generator gives step 6', 'j_\\nu[\\,\\cdot J\\,]=-\\langle\\tilde\\Psi\\gamma^\\nu\\Psi\\gamma_0\\rangle_0', 'j_ν[·J] = −⟨Ψ̃γ^νΨγ₀⟩₀', 'step 6'],
  ['current_is_not_zero', 'the current is not zero', 'j^a_\\nu\\neq0', 'j^a_ν ≠ 0', 'j ≠ 0'],
];
const EQ = { tex: 'E=\\gamma^\\mu(D_\\mu\\Psi)J-m\\Psi\\gamma_0,\\quad D_\\mu=\\partial_\\mu+gA^a_\\mu B_a,\\quad j^a_\\nu=\\textstyle\\sum_T\\langle\\tilde\\Psi_T\\gamma^\\nu(B_a\\Psi)_T\\gamma_0J\\rangle_0', plain: 'E = γ^μ(D_μΨ)J − mΨγ₀, D_μ = ∂_μ + gA^a_μ B_a, j^a_ν = Σ_T ⟨Ψ̃_T γ^ν (B_aΨ)_T γ₀ J⟩₀' };
const MAP = { tex: 'E\\ \\mapsto\\ i\\gamma^\\mu(\\partial_\\mu+gA^a_\\mu L_a)\\Psi-m\\Psi,\\quad j^a_\\nu=\\pm\\,\\mathrm{Im}\\,\\Psi^\\dagger\\gamma_0\\gamma^\\nu L_a\\Psi', plain: 'E ↦ iγ^μ(∂_μ + gA^a_μ L_a)Ψ − mΨ, j^a_ν = ± Im Ψ†γ₀γ^ν L_a Ψ' };
const words = k => k.replace(/_/g, ' ');
/** the stored pairs (n, m) of the gauge rung m in a block keyed "n,m": [[n, record]] */
export const pairsAt = (block, m) => Object.entries(block).filter(([k]) => k.split(',')[1] === String(m)).map(([k, v]) => [Number(k.split(',')[0]), v]).sort((a, b) => a[0] - b[0]);
export const moduleText = x => `${x.minimal_module_real_dim} × ${x.copies_of_each_module}${x.summands === 2 ? ' (×2)' : ''}`;
const nums = o => Object.keys(o).map(Number).sort((a, b) => a - b);

export default function MatterLadder({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner', L = lensKey(lens), S = useStored(), katex = useKatexAt(research);
  const init = () => ({ m: intIn(params.m, GAUGE_MS, params.top === true ? TOP : 3), top: params.top === true });
  const [st, setSt] = useState(init);
  useEffect(() => { setSt(init()); }, [params.m, params.top]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { m, top } = st, pick = v => setSt(s => ({ ...s, m: v }));
  const order = top ? [...GAUGE_MS].reverse() : GAUGE_MS;
  const restr = useMemo(() => Object.fromEntries(GAUGE_MS.map(v => [v, v < TOP ? restricts('internal', v, TOP) : null])), []);
  const T = S ? S.mt : null, M = S ? S.mtm : null;
  const blocks = [
    { key: 'ladder', name: 'ladder', sub: '1 + 3', mark: 'square', has: v => (T ? !!T.ladder[String(v)] : null) },
    { key: 'spacetime', name: 'space-time', sub: 'n = 3 … 6', mark: 'triangle', has: v => (T ? v === 3 && !!T.spacetime : null) },
    { key: 'identities', name: 'identities', sub: 'exact', mark: 'check', has: v => (T ? pairsAt(T.identities, v).length > 0 : null) },
    { key: 'matrix', name: 'matrix', sub: 'numpy', mark: 'diamond', has: v => (M ? pairsAt(M.max_error_equation, v).length > 0 : null) },
  ];
  const r = T ? T.ladder[String(m)] : null, ids = T ? pairsAt(T.identities, m) : [], mx = M ? pairsAt(M.max_error_equation, m) : [];
  const mask = v => (L ? labelIn(L, v, { n: 6, kind: 'st' }) : `${v} (${axName(v)})`);
  return (
    <div className="fig fig-matter-ladder g7-split" data-m={m} data-top={top ? 'true' : 'false'} data-lens={L || ''}>
      <div className="g7-left">
        <LadderSvg id="matter-ladder" row={row} rungs={GAUGE_MS} rungLabel={v => `Cl(0,${v})`} blocks={blocks} value={m} onPick={pick} top={top} param="m" restricts={v => restr[v]} />
        <Legend items={[['box', 'stored'], ['empty', 'not stored'], top && ['solid', `each lower Cl(0,m) ⊂ Cl(0,${TOP}): every sign the same`]]} />
        <Controls label="matter ladder">
          <Rungs label="m" values={GAUGE_MS} value={m} top={top} param="m" onPick={pick} />
          <TopSwitch on={top} onChange={on => setSt(s => ({ top: on, m: on ? TOP : s.m }))} />
        </Controls>
      </div>
      <div className="g7-right">
        <div className="g7-card" data-rung-card={m}>
          <h4>{`Cl(0,${m})`}<span className="g7-sub">{r ? `≅ ${r.internal_cell} · ${MATTER_KNOWN[m]}` : 'loading the stored checks'}</span></h4>
          {r && <Readout data={{ 'data-row': m }} items={[
            ['internal blades', String(r.internal_dim), { 'data-dim': r.internal_dim }],
            ['components of Ψ', String(r.components), { 'data-components': r.components }],
            ['terms in each equation', `${r.terms_per_equation} = ${r.derivative_terms_per_equation} + ${r.gauge_terms_per_equation} + ${r.mass_terms_per_equation}`, { 'data-terms': `${r.terms_per_equation},${r.derivative_terms_per_equation},${r.gauge_terms_per_equation},${r.mass_terms_per_equation}` }],
            ['generators', String(r.gens), { 'data-gens': r.gens }],
            ['module (real dimension × copies)', moduleText(r), { 'data-module': `${r.minimal_module_real_dim},${r.copies_of_each_module},${r.summands}` }],
          ]} />}
          {top && <Readout data={{ 'data-readout': 'restriction' }} items={[[`⊂ Cl(0,${TOP})`, m === TOP ? 'top' : restr[m] ? '✓ every sign the same' : '✗', { 'data-restricts': m === TOP ? 'top' : String(restr[m]) }]]} />}
        </div>
        <div className="g7-card" data-identities-at={m}>
          <h4>exact identities<span className="g7-sub">{`m = ${m}`}</span></h4>
          {ids.length ? <MiniTable heads={MT_IDENTITIES.map(([k, nm, , , short]) => short)} titles={MT_IDENTITIES.map(([k, nm]) => nm)} rows={ids.map(([ns, v]) => ({ key: ns, label: `n = ${ns}`, data: { 'data-pair': `${ns},${m}` }, cells: MT_IDENTITIES.map(([k]) => ({ v: v[k], data: { 'data-id': `${k},${v[k]}` } })) }))} /> : T ? <NotStored /> : null}
        </div>
        <div className="g7-card" data-matrix-at={m}>
          <h4>matrix check (numpy)<span className="g7-sub">{`m = ${m}`}</span></h4>
          {mx.length ? mx.map(([ns, err]) => { const c = M.current[`${ns},${m}`]; return <Readout key={ns} data={{ 'data-pair': `${ns},${m}` }} items={[[`n = ${ns}`, ''], ['largest error', String(err), { 'data-err': err }], c && ['current', `${c.equals_part_of_spinor_bilinear === 'im' ? 'Im' : 'Re'} part · |constant| ${c.abs_constant}`, { 'data-current': `${c.equals_part_of_spinor_bilinear},${c.abs_constant}` }]]} />; }) : M ? <NotStored /> : null}
        </div>
      </div>
      <div className="g7-wide">
        {T && (
          <Fold id="ladder" title="The ladder (space-time 1 + 3)">
            <table className="g7-table" data-table="ladder">
              <thead><tr>{['m', 'internal blades', 'components of Ψ', 'terms in each equation', 'of them gauge terms', 'internal algebra Cl(0,m)', 'module (real dimension × copies)', 'known as'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{order.map(v => { const x = T.ladder[String(v)]; return (
                <tr key={v} className={v === m ? 'is-on' : ''} data-param="m" data-ladder={v} onClick={() => pick(v)}>
                  <td className="g7-n">{v}</td><td className="g7-n">{x.internal_dim}</td><td className="g7-n">{x.components}</td><td className="g7-n">{x.terms_per_equation}</td><td className="g7-n">{x.gauge_terms_per_equation}</td>
                  <td>{x.internal_cell}</td><td>{moduleText(x)}</td><td>{MATTER_KNOWN[v]}</td>
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {T && (
          <Fold id="spacetime" title="Space-time dimension, at m = 3">
            <table className="g7-table" data-table="spacetime">
              <thead><tr>{['space-time n', 'components of Ψ', 'terms in each equation', 'of them gauge terms', 'the current: corner masks, one for each direction', 'corner distances'].map(h => <th key={h}>{h}</th>)}</tr></thead>
              <tbody>{(top ? [...NS].reverse() : NS).map(v => { const x = T.spacetime[String(v)]; return (
                <tr key={v} className={x ? '' : 'is-ns'} data-spacetime={v}>
                  <td className="g7-n">{v}</td>
                  {x ? <><td className="g7-n">{x.components}</td><td className="g7-n">{x.terms_per_equation}</td><td className="g7-n">{x.gauge_terms_per_equation}</td>
                    <td data-masks={nums(x.current_corner_masks).map(nu => x.current_corner_masks[nu]).join(',')}>{nums(x.current_corner_masks).map(nu => `${AXES[nu]} ${mask(x.current_corner_masks[nu])}`).join(' · ')}</td>
                    <td data-distances={nums(x.current_corner_distance).map(nu => x.current_corner_distance[nu]).join(',')}>{nums(x.current_corner_distance).map(nu => x.current_corner_distance[nu]).join(', ')}</td></> : <td colSpan={5}><NotStored /></td>}
                </tr>); })}</tbody>
            </table>
          </Fold>
        )}
        {T && (
          <Fold id="identities" title="Exact identities, on the grid of (m, n)">
            <p className="g7-readout"><Tex katex={katex} tex={EQ.tex} plain={EQ.plain} /></p>
            <Readout items={MT_IDENTITIES.map(([k, nm, tex, plain], i) => [`${i + 1}: ${nm}`, <Tex katex={katex} tex={tex} plain={plain} />])} />
            <table className="g7-table" data-table="identities">
              <thead><tr><th>gauge m \ space-time n</th>{NS.map(v => <th key={v}>{v}</th>)}</tr></thead>
              <tbody>{order.map(v => (
                <tr key={v} className={v === m ? 'is-on' : ''} data-identities={v}>
                  <td className="g7-n">{v}</td>
                  {NS.map(ns => { const x = T.identities[`${ns},${v}`]; return <td key={ns} data-cell={`${ns},${v}`}>{x ? MT_IDENTITIES.map(([k], i) => <span key={k} data-id={`${k},${x[k]}`}>{i + 1}<Mark v={x[k]} /> </span>) : <NotStored />}</td>; })}
                </tr>))}</tbody>
            </table>
          </Fold>
        )}
        {M && (
          <Fold id="matrix" title="Independent check with matrices (numpy, Jordan–Wigner)">
            <p className="g7-readout"><Tex katex={katex} tex={MAP.tex} plain={MAP.plain} /></p>
            <table className="g7-table" data-table="matrix">
              <thead><tr><th>gauge m \ space-time n</th>{NS.map(v => <th key={v}>{v}</th>)}</tr></thead>
              <tbody>{order.map(v => (
                <tr key={v} className={v === m ? 'is-on' : ''} data-matrix={v}>
                  <td className="g7-n">{v}</td>
                  {NS.map(ns => { const k = `${ns},${v}`, on = k in M.max_error_equation, c = M.current[k]; return <td key={ns} data-cell={k}>{on ? `error ${M.max_error_equation[k]}${c ? ` · ${c.equals_part_of_spinor_bilinear === 'im' ? 'Im' : 'Re'}, |c| ${c.abs_constant}` : ''}` : <NotStored />}</td>; })}
                </tr>))}</tbody>
            </table>
            <Readout data={{ 'data-controls': Object.keys(M.controls).length }} items={[['wrong versions', ''], ...Object.entries(M.controls).map(([k, v]) => ['', `${words(k)}: ${v}`, { 'data-control': k }]), ['status', M.status]]} />
          </Fold>
        )}
        <p className="g7-conv" data-convention="1"><span className="g7-k">inputs:</span> Ψ carries an internal blade of Cl(0,m) (INP-038) · left multiplication (INP-039) · the coupling κ of D<sup>μ</sup>F<sub>μν</sub> = κ j<sub>ν</sub> (INP-040) · J = γ₂γ₁ (INP-042)</p>
      </div>
    </div>
  );
}
MatterLadder.meta = { id: 'matter-ladder', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: false };
MatterLadder.params = [{}, { m: 2 }, { m: 4 }, { m: 8 }, { m: 3, top: true }];
/** the kernel's part of what the figure draws: the rungs and the restrictions from the top */
MatterLadder.data = (p = {}) => {
  const m = intIn(p.m, GAUGE_MS, p.top === true ? TOP : 3);
  return { m, top: p.top === true, rungs: GAUGE_MS, restricts: GAUGE_MS.map(v => (v < TOP ? restricts('internal', v, TOP) : null)) };
};
