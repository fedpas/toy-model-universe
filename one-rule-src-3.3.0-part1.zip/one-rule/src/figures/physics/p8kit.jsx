// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/physics/p8kit.jsx — what the figures of steps 9–12 share (owner P8): the stored table content/stored_p8.json read on demand (D34: useTable, never
// bundled; null while it loads, and then the figure draws what the kernel gives and says the stored part is loading), a formula through KaTeX at research level
// (the plain string while KaTeX loads; learner level never asks for it), a label printed in the base the page lens asks for (D37: clifford e-words, simplex
// digits, cube and demicube bits, prime the product of the primes; the axis letters otherwise), the D37 switch "from the top", a cell the data lacks ("not
// stored", never extrapolated), and the small tables of the ladders. Tokens only (p8.css); marks by shape and word.
import React from 'react';
import { useTable } from '../../app/content.js';
import { peekTable } from '../../app/store.js';
import { useKatex, texToHtml } from '../../app/math.js';
import { label, PRIMES } from '../../../engines/bitrule.js';
import { bitsOf } from '../../../engines/labels.js';
import { Toggle } from '../kit.jsx';
import './p8.css';

export const AXES = ['t', 'x', 'y', 'z', 'u', 'v', 'w', 's'];
/** the lenses of D37, at every rung: FigureFrame draws them as its lens chips */
export const D37_LENSES = ['clifford', 'simplex', 'cube', 'demicube', 'prime'];
const okStored = S => !!S && !!S.gv && !!S.gvm && !!S.pj;
/** the stored table (content/stored_p8.json), or null while it loads */
export function useStored() { const [S] = useTable('stored_p8'); return okStored(S) ? S : null; }
/** the same, outside React (a figure's data()): what is loaded, else null */
export const peekStored = () => { const S = peekTable('stored_p8'); return okStored(S) ? S : null; };
export { useKatex };

/** a formula: KaTeX HTML when the engine is there (research level), else its plain string */
export function Tex({ tex, text, katex, className = '' }) {
  const html = katex ? texToHtml(tex) : null;
  return html ? <span className={'gp-tex ' + className} data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span className={'gp-tex gp-plain ' + className} data-tex={tex}>{text}</span>;
}

/** how a page lens prints a label (D37): 'clifford' e-words, 'simplex' the generators counted from 1, 'cube' and 'demicube' bits, 'prime'/'primes' the product of
 *  the k-th primes; otherwise the axis letters (physics) or the e-words (mathematics, research) and the digits (mathematics, learner) */
export function printing(lens, mode = 'phys', level = 'research') {
  if (lens === 'cube' || lens === 'demicube' || lens === 'bits') return 'bits';
  if (lens === 'prime' || lens === 'primes') return 'primes';
  if (lens === 'clifford') return 'clifford';
  if (lens === 'simplex') return 'digits';
  if (mode === 'math') return level === 'learner' ? 'digits' : 'clifford';
  return 'letters';
}
/** a label (bit mask) of n generators in one printing */
export function printLabel(m, how, n) {
  const eps = Array(n).fill(-1);
  if (how === 'bits') return label(m, 'bits', eps);
  if (how === 'clifford') return label(m, 'clifford', eps);
  if (how === 'primes') return String(bitsOf(m).reduce((p, i) => p * PRIMES[i], 1));
  if (how === 'digits') return bitsOf(m).map(i => i + 1).join('');
  return bitsOf(m).map(i => AXES[i]).join('');
}

/** D37: the switch that starts at the highest stored rung and shows each lower one as its restriction */
export function TopToggle({ on, onChange, research, top }) {
  return <Toggle label={research ? `from the top (n = ${top})` : 'from the top'} on={on} onChange={onChange} param="top" />;
}
/** a cell the stored data lacks (D37) */
export const NotStored = ({ what = 'not stored' }) => <span className="gp-none" data-not-stored="1">{what}</span>;
/** while the stored table loads */
export const Loading = () => <p className="gp-read gp-none" data-loading="stored_p8">loading the stored results</p>;

/** a small table: cols [[key, head]], rows [{ key, cells: {key: content}, cur }] */
export function Table({ caption, cols, rows, name }) {
  return (
    <div className="fig-scroll">
      <table className="gp-table" data-table={name}>
        {caption ? <caption>{caption}</caption> : null}
        <thead><tr>{cols.map(([k, h]) => <th key={k} scope="col">{h}</th>)}</tr></thead>
        <tbody>{rows.map(r => (
          <tr key={r.key} className={r.cur ? 'gp-cur' : undefined} aria-current={r.cur ? 'true' : undefined} data-row-key={r.key}>
            {cols.map(([k]) => <td key={k} data-col={k}>{r.cells[k] === undefined || r.cells[k] === null ? <NotStored /> : r.cells[k]}</td>)}
          </tr>
        ))}</tbody>
      </table>
    </div>
  );
}
/** a fold of the data (closed: the reader opens it) */
export const Fold = ({ title, name, children, open = false }) => <details className="gp-fold" data-fold={name} open={open}><summary>{title}</summary><div className="gp-body">{children}</div></details>;
export const tick = v => (v === true ? '✓' : v === false ? '✗' : '—');
export const signed = v => (v > 0 ? `+${v}` : v < 0 ? `−${-v}` : '0');
const SUBD = '₀₁₂₃₄₅₆₇₈₉';
export const subs = s => String(s).replace(/\d/g, d => SUBD[d]);
