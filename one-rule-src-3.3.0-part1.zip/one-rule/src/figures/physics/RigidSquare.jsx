// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure rigid-square (step 16, the second rung; caption row RIG-002; docs/PHYSICS_AUDIT.md RB2): a free square in R(2,0,1), the first rotation. Top, the square
// in the world, each corner with its label in bits, the even corners (00, 11: the rotor part, no e₀) filled, the odd ones (01, 10: the translation part, with e₀)
// hollow, and the path of the centre dashed; below, the velocity as the body sees it, (b₀₁, b₀₂) on its circle. The run is engines/pgaEngine.js stepRK4 (the
// kernel's signs). The readouts are v15's (RigidWidgets.jsx SquareFree): the largest change of the world momentum M A(B) M̃ over the run, and the rate at which
// the body-frame velocity turns against −b₁₂; and, under D29, the rate of row C1 that pgadyn.json stores (exact series through t¹⁰: the pair turns as e^(−iωt) at
// ω = b₁₂ = 2). The controls are v15's: the two velocity components in the body, the spin, the time and Play; they start at the first case of C1.
// Research level only (no L: in the audit).
import React, { useEffect, useMemo, useState } from 'react';
import { alg, unitC, stepRK4, verticesFrame } from '../../../engines/pgaEngine.js';
import { popcount } from '../../../engines/bitrule.js';
import { FigSvg, Controls, Range, PlayButton, useReducedMotion, r1, f2 } from '../kit.jsx';
import { useStoredP11, Ok, KV } from './rigidParts.jsx';

const H = 0.01, T = 8, SIZE = [1.3, 0.8];
const f3 = x => (Math.abs(x) < 5e-5 ? '0' : String(Math.round(x * 1000) / 1000).replace('-', '−'));
const bits2 = v => v.toString(2).padStart(2, '0');
const okInt = (v, lo, hi, d) => (Number.isInteger(v) && v >= lo && v <= hi ? v : d);
/** the state from the parameters (v15's sliders: b₀₁, b₀₂ = value / 10 in −2 … 2, b₁₂ = value / 10 in 0 … 4; t = value / 100 of the run) */
export function squareState(params = {}) {
  return { b01: okInt(params.b01, -20, 20, 10), b02: okInt(params.b02, -20, 20, 20), b12: okInt(params.b12, 0, 40, 20), t: okInt(params.t, 0, 100, 20) };
}
/** the run: every fifth step the corners, the centre, the body velocity and the world momentum M A(B) M̃; its largest change and the measured rate of turning */
export function squareRun({ b01, b02, b12 }) {
  const A = alg(2), c = unitC(A), W = b12 / 10;
  let st = { M: A.motor([0, 0], []), B: A.z() }; st.B[0b011] = b01 / 10; st.B[0b101] = b02 / 10; st.B[0b110] = W;
  const out = [];
  for (let i = 0; i <= Math.round(T / H); i++) {
    if (i % 5 === 0) out.push({ V: verticesFrame(A, st.M, SIZE), cen: A.pos(A.sand(st.M, A.point([0, 0]))), b: [st.B[0b011], st.B[0b101], st.B[0b110]], P: A.sand(st.M, A.Amap(st.B, c)).slice() });
    st = stepRK4(A, st, c, null, H);
  }
  const drift = Math.max(...out.map(q => Math.max(...q.P.map((v, j) => Math.abs(v - out[0].P[j])))));
  const ang = q => Math.atan2(q.b[1], q.b[0]);
  let tot = 0; for (let j = 1; j < out.length; j++) { const d = ang(out[j]) - ang(out[j - 1]); tot += Math.atan2(Math.sin(d), Math.cos(d)); }
  const speed = Math.hypot(b01 / 10, b02 / 10);
  return { out, drift, rate: speed > 0.05 ? tot / ((out.length - 1) * 5 * H) : null, speed, W };
}

export default function RigidSquare({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const p0 = squareState(params);
  const [b01, setB01] = useState(p0.b01), [b02, setB02] = useState(p0.b02), [b12, setB12] = useState(p0.b12), [tt, setTt] = useState(p0.t), [playing, setPlaying] = useState(false);
  useEffect(() => { const p = squareState(params); setB01(p.b01); setB02(p.b02); setB12(p.b12); setTt(p.t); }, [params.b01, params.b02, params.b12, params.t]);   // eslint-disable-line react-hooks/exhaustive-deps
  const reduced = useReducedMotion(), S = useStoredP11();
  useEffect(() => { if (!playing || reduced) return undefined; const id = setInterval(() => setTt(x => (x + 1) % 101), 33); return () => clearInterval(id); }, [playing, reduced]);
  const run = useMemo(() => squareRun({ b01, b02, b12 }), [b01, b02, b12]);
  const i = Math.round(tt / 100 * (run.out.length - 1)), r = run.out[i], tm = i * 5 * H;
  // the world panel follows the centre (40 px a unit, the scale of v15's largest drawing): a grid of unit squares moves under the body, the path of the centre is
  // drawn where it crosses the panel
  const sc = 40, [cx, cy] = r.cen, P = ([x, y]) => [180 + sc * (x - cx), 124 - sc * (y - cy)], inPanel = ([x, y]) => x >= 0 && x <= 360 && y >= 20 && y <= 226;
  const grid = [];
  for (let gx = Math.ceil(cx - 4.5); gx <= cx + 4.5; gx++) { const [x] = P([gx, cy]); if (x >= 0 && x <= 360) grid.push(<line key={'x' + gx} x1={r1(x)} y1={20} x2={r1(x)} y2={226} className="hair-2" />); }
  for (let gy = Math.ceil(cy - 2.5); gy <= cy + 2.5; gy++) { const [, y] = P([cx, gy]); if (y >= 20 && y <= 226) grid.push(<line key={'y' + gy} x1={0} y1={r1(y)} x2={360} y2={r1(y)} className="hair-2" />); }
  let pathD = '', pen = false;
  for (const q of run.out) { const pt = P(q.cen); if (inPanel(pt)) { pathD += (pen ? 'L' : 'M') + r1(pt[0]) + ' ' + r1(pt[1]); pen = true; } else pen = false; }
  const poly = [0, 1, 3, 2].map(v => P(r.V[v]).map(r1).join(',')).join(' ');
  const rad = 38 * Math.min(1, run.speed / 2.2), dot = run.speed > 0.05 ? [110 + rad * r.b[0] / run.speed, 294 - rad * r.b[1] / run.speed] : null;
  const storedRate = S && S.square ? S.square.rate : null;
  const player = { playing, reduced, play: () => setPlaying(p => !p), step: () => setTt(x => (x + 5) % 101) };
  return (
    <div className="fig fig-rigid rg-sq" data-b01={b01} data-b02={b02} data-b12={b12}>
      <FigSvg id="rigid-square" row={row} viewBox="0 0 360 344">
        <text x={8} y={14} className="t-tiny t-muted">in the world (grid: unit squares)</text>
        {grid}
        {pathD ? <path d={pathD} className="stroke-muted" style={{ strokeDasharray: '3 3' }} data-path="centre" /> : null}
        <polygon points={poly} className="stroke-ink" style={{ strokeWidth: 1.6, fill: 'var(--accent-soft)' }} />
        {r.V.map((p, v) => { const [x, y] = P(p), even = popcount(v) % 2 === 0; return (
          <g key={v} data-vertex={bits2(v)} data-part={even ? 'rotor' : 'translation'}>
            <circle cx={r1(x)} cy={r1(y)} r={3.6} className={even ? 'ink' : 'stroke-ink'} style={even ? undefined : { strokeWidth: 1.4, fill: 'var(--panel)' }} />
            <text x={r1(x + 5)} y={r1(y - 5)} className="t-tiny t-mono">{bits2(v)}</text>
          </g>); })}
        {(() => { const [x, y] = P(r.cen); return <circle cx={r1(x)} cy={r1(y)} r={2.4} className="ink-muted" data-centre={`${f3(r.cen[0])},${f3(r.cen[1])}`} />; })()}
        <g transform="translate(8 236)"><circle cx={4} cy={-3} r={3.4} className="ink" /><text x={12} y={0} className="t-tiny">even corner: rotor part</text>
          <circle cx={150} cy={-3} r={3.4} className="stroke-ink" style={{ strokeWidth: 1.4, fill: 'var(--panel)' }} /><text x={158} y={0} className="t-tiny">odd corner: translation part (e₀)</text></g>
        <line x1={0} y1={248} x2={360} y2={248} className="hair-2" />
        <text x={8} y={262} className="t-tiny t-muted">in the body frame</text>
        <circle cx={110} cy={294} r={r1(Math.max(2, rad))} className="hair" />
        <line x1={60} y1={294} x2={160} y2={294} className="hair-2" /><line x1={110} y1={254} x2={110} y2={338} className="hair-2" />
        <text x={162} y={297} className="t-tiny">b₀₁</text><text x={114} y={262} className="t-tiny">b₀₂</text>
        {dot ? <circle cx={r1(dot[0])} cy={r1(dot[1])} r={5} className="ink" data-body-velocity={`${f3(r.b[0])},${f3(r.b[1])}`} /> : null}
        <text x={196} y={284} className="t-small t-mono">{`b = (${f2(r.b[0])}, ${f2(r.b[1])})`}</text>
        <text x={196} y={302} className="t-small t-mono" data-b12-now={r.b[2]}>{`b₁₂ = ${f2(r.b[2])}`}</text>
        <text x={196} y={320} className="t-small t-mono">{`t = ${f2(tm)}`}</text>
      </FigSvg>
      {research ? (
        <div className="fig-note rg-note">
          <p data-drift={run.drift}><KV k="largest change of the world momentum M A(B) M̃ over the run">{run.drift.toExponential(1)}</KV><Ok ok={run.drift < 1e-6} yes="constant" no="not constant" /></p>
          <p data-rate={run.rate == null ? '' : run.rate} data-predicted={-run.W}>{run.rate == null
            ? <KV k="body-frame velocity">0</KV>
            : <><KV k="the body-frame velocity turns by">{`${f3(run.rate)} per unit time`}</KV><KV k="−b₁₂">{f3(-run.W)}</KV><Ok ok={Math.abs(run.rate + run.W) < 1e-3} /></>}</p>
          <p data-stored-rate={storedRate == null ? '' : storedRate}><KV k="row C1, exact series through t¹⁰ (stored)">{storedRate == null ? '…' : `the pair turns as e^(−iωt), ω = b₁₂ = ${storedRate}`}</KV>
            {storedRate != null && run.W === storedRate ? <Ok ok={run.rate != null && Math.abs(run.rate + storedRate) < 1e-3} yes="this run" no="this run differs" /> : null}</p>
        </div>
      ) : null}
      <Controls label="the square">
        {research && <Range label="velocity b₀₁" value={b01} min={-20} max={20} step={1} onChange={setB01} display={v => f2(v / 10)} param="b01" />}
        {research && <Range label="velocity b₀₂" value={b02} min={-20} max={20} step={1} onChange={setB02} display={v => f2(v / 10)} param="b02" />}
        {research && <Range label="spin b₁₂" value={b12} min={0} max={40} step={1} onChange={setB12} display={v => f2(v / 10)} param="b12" />}
        {research && <Range label="time" value={tt} min={0} max={100} step={1} onChange={setTt} display={() => f2(tm)} param="t" />}
        <PlayButton player={player} />
      </Controls>
    </div>
  );
}
RigidSquare.meta = { id: 'rigid-square', lenses: [], learner: false };
RigidSquare.params = [{}, { b01: -10, b02: 5, b12: 15, t: 60 }, { b01: 0, b02: 0, b12: 30 }, { b01: 20, b02: -20, b12: 0, t: 100 }];
/** the numbers the figure draws */
RigidSquare.data = (params = {}) => { const s = squareState(params), r = squareRun(s); return { b01: s.b01 / 10, b02: s.b02 / 10, b12: r.W, rate: r.rate, predicted: -r.W, momentumDrift: r.drift }; };
