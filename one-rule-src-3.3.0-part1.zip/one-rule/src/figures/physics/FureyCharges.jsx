// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure furey-charges (Furey, her 2026 model; caption FUR-003; PHYSICS_AUDIT FU1): Y or Q on the eight complex dimensions of V, one bar per dimension
// (the vertices o … r of the dictionary), grouped by the five complex blocks; the sum over the eight and the mean 3/8, and the bars with 3/8 subtracted
// (Y₀, Q₀: traceless). Beside them the blocks of the complex board (size, irrep, the charges of its states; 16 cells on the diagonal, 48 off it), and
// under them the Witt torus whose 16 joint eigenspaces are the axes: the seven Fano-line blades of Cl(0,8) and their products, the 16 faces of dictionary.json code, printed in the lens
// (Clifford words, bits, primes, vertex sets, the demicube's even labels), with what the kernel recomputes (the line blades commute and square to +1;
// four are independent, so 16 joint eigenspaces; ω = 123 has grade 6 and squares to −1; 128 labels commute with it). At research level the formulas of
// Y and Q are shown as the input they are (her eqs. 44, 45: INP-092). The values are engines/fureyPapersEngine.js BLOCKS (exact), tied to the stored
// dictionary states and fig1 blocks in tests/physics/p10.test.mjs. Controls: v15's charge chips Y / Q and the subtract-3/8 checkbox (FureyWidgets.jsx
// Charges); the blocks from Peirce, the axes from Axes. Marks by shape and word: a negative value is drawn below the line, outlined and dashed.
import React, { useState, useEffect } from 'react';
import { FigSvg, Controls, Chips, Toggle, r1, pick } from '../kit.jsx';
import { Sc } from '../FureyBoard.jsx';
import { useKatex, texToHtml } from '../../app/math.js';
import * as E from '../../../engines/fureyPapersEngine.js';
import { chargeBars, fmt24, blockTable, chargeTex, torus, lensKey, labelIn } from '../../../engines/physics/furey.js';
import { useStored, peekStored, Loading } from './fureyKit.jsx';

const X0 = 24, BW = 36, GAP = 8, GGAP = 22, Z = 132, PX = 4;   // bars: left edge, width, gaps, the zero line, pixels per 1/24
const barX = (() => { const xs = []; let x = X0, prev = -1; for (const b of [0, 1, 1, 1, 2, 2, 3, 4]) { if (prev >= 0) x += b === prev ? GAP : GGAP; xs.push(x); x += BW; prev = b; } return xs; })();
const WORD = { Y: 'weak force charge', Q: 'electric charge' };
/** a label in a tile, squeezed to the tile's width when it is long (the eight primes of the full face, the eight Clifford letters) */
const FitText = ({ x, y, s, max }) => <text x={x} y={y} textAnchor="middle" className="t-tiny t-mono" {...(s.length > 13 ? { textLength: max, lengthAdjust: 'spacingAndGlyphs' } : {})}>{s}</text>;

function Formula({ tex }) {
  const html = texToHtml(tex);
  const plain = () => tex.replace(/\\tfrac\{(\d+)\}\{(\d+)\}/g, '$1/$2 ').replace(/\\mathbb\{(\w)\}/g, (m, c) => ({ O: '𝕆', H: 'ℍ', C: 'ℂ' }[c] || c)).replace(/\\mathrm\{(\w+)\}/g, '$1').replace(/[{}\\]/g, '');
  return html ? <span className="fig-mono" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span className="fig-mono" data-tex={tex}>{plain()}</span>;
}

export default function FureyCharges({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const okW = v => v === 'Y' || v === 'Q';
  const [which, setWhich] = useState(pick(params.which, okW, 'Y'));
  const [shift, setShift] = useState(params.shift === true);
  useEffect(() => { setWhich(pick(params.which, okW, 'Y')); setShift(params.shift === true); }, [params.which, params.shift]);
  const T = useStored(params);
  useKatex(research && !!T);   // the formulas of the note re-render once KaTeX has loaded
  const C = chargeBars(which, shift), B = blockTable(), key = lensKey(lens, level), tor = T ? torus(T.dic.code, T.dic.omega) : null;
  const ttl = research ? `${which}${shift ? ' − 3/8' : ''} on the eight complex dimensions` : `${WORD[which]} of each lane${shift ? ', 3/8 taken away' : ''}`;
  const H = 392;
  return (
    <div className="fig fig-furey-charges">
      <FigSvg id="furey-charges" row={row} viewBox={`0 0 720 ${H}`}>
        <text x={4} y={14} className="t-small t-muted">{ttl}</text>
        <line x1={X0 - 8} y1={Z} x2={barX[7] + BW + 8} y2={Z} className="stroke-ink" style={{ strokeOpacity: 0.6 }} />
        {C.lanes.map((l, i) => {
          const v = C.vals[i], h = Math.abs(v) * PX, x = barX[i], up = v >= 0, y = up ? Z - h : Z;
          return (
            <g key={l.v} data-state={l.v} data-block={l.block} data-value={v} data-y6={l.y6} data-q3={l.q3}>
              {v === 0 ? <line x1={x} y1={Z} x2={x + BW} y2={Z} className="stroke-ink" style={{ strokeWidth: 2.5 }} />
                : <rect x={x} y={r1(y)} width={BW} height={r1(h)} rx={2} className={up ? 'ink' : 'on-panel'} style={up ? { fillOpacity: 0.78 } : { stroke: 'var(--fg)', strokeDasharray: '4 2' }} />}
              <text x={x + BW / 2} y={r1(up ? Z - h - 5 : Z + h + 12)} textAnchor="middle" className="t-small t-mono">{fmt24(v)}</text>
              <text x={x + BW / 2} y={198} textAnchor="middle" className="t-tiny">{research ? l.v : String(i + 1)}</text>
            </g>
          );
        })}
        {B.rows.map(rw => {
          const xs = C.lanes.map((l, i) => (l.block === rw.b ? barX[i] : null)).filter(x => x !== null), x1 = xs[0], x2 = xs[xs.length - 1] + BW;
          return (
            <g key={rw.b} data-bracket={rw.b}>
              <path d={`M${x1} 204 L${x1} 208 L${x2} 208 L${x2} 204`} className="stroke-muted" />
              {research && <text x={(x1 + x2) / 2} y={221} textAnchor="middle" className="t-tiny"><Sc s={rw.name} /></text>}
            </g>
          );
        })}
        <text x={4} y={242} className="t-small" data-trace={C.sum} data-mean={C.mean} data-which={which} data-shift={shift ? 1 : 0}>
          {research ? `sum over the 8 states: ${fmt24(C.sum)}${shift ? '' : ` · mean ${fmt24(C.mean)}`}` : `all eight added up: ${fmt24(C.sum)}`}
        </text>

        <g transform="translate(470, 0)" data-blocks={B.rows.length}>
          <text x={0} y={14} className="t-small t-muted">{research ? 'the blocks of the complex board' : 'small board, 8 by 8'}</text>
          {research && <text x={0} y={34} className="t-micro t-muted">{'block · size · irrep (colour, isospin, Y) · Q of its states'}</text>}
          {B.rows.map((rw, i) => (
            <g key={rw.b} data-block-row={rw.b} data-n={rw.n} data-irrep={E.fmt(rw.irrep)} data-charges={rw.q3.join(',')}>
              <rect x={0} y={42 + i * 24} width={18 + rw.n * 12} height={18} rx={3} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 0.8 }} />
              <text x={9 + rw.n * 6} y={55 + i * 24} textAnchor="middle" className="t-tiny t-bold">{rw.n}</text>
              {research ? (
                <text x={66} y={55 + i * 24} className="t-tiny"><Sc s={rw.name} /><tspan>{`  ${E.fmtShow(rw.irrep)}  Q: ${[...new Set(rw.q3)].map(q => E.fmtQ(q)).join(', ')}`}</tspan></text>
              ) : <text x={66} y={55 + i * 24} className="t-tiny">{`square ${i + 1} · ${rw.n} lane${rw.n > 1 ? 's' : ''}`}</text>}
            </g>
          ))}
          <text x={0} y={178} className="t-small" data-board-diag={B.diag} data-board-off={B.off} data-board-n={B.N}>
            {research ? `${B.N} × ${B.N}: ${B.diag} cells on the diagonal · ${B.off} off it` : `on the diagonal ${B.diag} · off the diagonal ${B.off}`}
          </text>
          {!research && <text x={0} y={196} className="t-small">{`squares: ${B.rows.map(r => r.n).join(', ')}`}</text>}
        </g>

        <g transform="translate(0, 262)">
          <text x={4} y={10} className="t-small t-muted">{research ? 'the Witt torus: the seven Fano-line blades of Cl(0,8) and their products' : '16 corners: the 7 marked ones and their combinations'}</text>
          {!tor ? <Loading x={8} y={18} w={704} h={64} what="axes" /> : (
            <g data-axes={tor.axes} data-lens={key}>
              {tor.faces.map((f, i) => {
                const x = 8 + (i % 8) * 88, y = 18 + Math.floor(i / 8) * 32;
                return (
                  <g key={f.N} data-axis-face={f.N} data-grade={f.grade} data-line={f.line ? 1 : 0} data-label={labelIn(f.N, key, 8)}>
                    <rect x={x} y={y} width={84} height={26} rx={4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: f.line ? 2 : 0.7 }} />
                    {f.line && <path d={`M${x + 7} ${y + 8} L${x + 11} ${y + 13} L${x + 7} ${y + 18} L${x + 3} ${y + 13} Z`} className="ink" />}
                    <FitText x={x + 47} y={y + 17} s={labelIn(f.N, key, 8)} max={70} />
                    {research && <text x={x + 81} y={y + 9} textAnchor="end" className="t-micro t-muted">{`g${f.grade}`}</text>}
                  </g>
                );
              })}
              <path d="M12 92 L16 97 L12 102 L8 97 Z" className="ink" />
              <text x={22} y={101} className="t-tiny">{research ? `Fano-line blade (${tor.lines.length})${key === 'demicube' ? ` · all ${tor.faces.length} even: demicube corners` : ''}` : `marked corner (${tor.lines.length})`}</text>
              {research && (
                <text x={4} y={120} className="t-tiny" data-commute={tor.commute ? 1 : 0} data-squares={tor.squares.join(',')} data-rank={tor.rank} data-omega={tor.omega} data-omega-grade={tor.omegaGrade} data-omega-square={tor.omegaSquare} data-with-omega={tor.withOmega}>
                  {`line blades: ${tor.commute ? 'commute' : 'do not commute'}, square ${tor.squares.every(s => s === 1) ? '+1' : tor.squares.join(' ')} · ${tor.rank} independent → ${tor.axes} joint eigenspaces, the axes · ω = ${labelIn(tor.omega, key === 'demicube' ? 'bits' : key, 8)}: grade ${tor.omegaGrade}, square ${tor.omegaSquare < 0 ? '−1' : '+1'} · ${tor.withOmega} labels commute with ω`}
                </text>
              )}
            </g>
          )}
        </g>
      </FigSvg>
      {research && T && (
        <div className="fig-note" data-input="INP-092">
          <p><span style={{ color: 'var(--muted)' }}>her eqs. 44, 45, an input (INP-092):</span><Formula tex={chargeTex(T.fp.fig1.blocks).Y} /><span style={{ color: 'var(--muted)' }}>·</span><Formula tex={chargeTex(T.fp.fig1.blocks).Q} /></p>
        </div>
      )}
      <Controls label="charges">
        <Chips label={research ? 'charge' : 'which'} items={['Y', 'Q']} value={which} onPick={setWhich} render={w => (research ? w : WORD[w])} param="which" />
        <Toggle label={research ? 'subtract 3/8' : 'take 3/8 away from every lane'} on={shift} onChange={setShift} param="shift" />
      </Controls>
    </div>
  );
}
FureyCharges.meta = { id: 'furey-charges', lenses: ['clifford', 'simplex', 'cube', 'demicube', 'prime'], learner: true };
FureyCharges.params = [{}, { which: 'Q', shift: true }, { shift: true }];
/** the numbers the figure draws, for the frame's data download */
FureyCharges.data = (params = {}) => {
  const which = params.which === 'Q' ? 'Q' : 'Y', C = chargeBars(which, params.shift === true), B = blockTable(), T = peekStored(params), tor = T ? torus(T.dic.code, T.dic.omega) : null;
  return { which, shift: C.shift, states: C.lanes.map((l, i) => ({ state: l.v, block: l.block, value24: C.vals[i] })), sum24: C.sum, mean24: C.mean, blocks: B.rows.map(r => ({ name: r.name, n: r.n, irrep: E.fmt(r.irrep), q3: r.q3 })), board: { diag: B.diag, off: B.off }, axes: tor ? { faces: tor.faces.map(f => f.N), lines: tor.lines, axes: tor.axes, omega: tor.omega } : null };
};
