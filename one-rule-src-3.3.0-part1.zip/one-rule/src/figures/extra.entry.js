// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/extra.entry.js — the entry of the figures chunk dist/figures-extra.js (BUILD_CONTRACTS interface 34, D47): the figures under
// src/figures/physics/ (the physics wave, one registry per owner) and src/figures/explore/ (the leaves and the lens explorers). tools/build_extra.mjs
// builds it as a classic script (IIFE) in which React and the stateful modules of the app are read from window.__ONE_RULE_BRIDGE__ (src/app/lazyFigures.js);
// when it runs in the page it registers its figures in window.__ONE_RULE_FIGURES_EXTRA__ and dispatches "one-rule:figures". A new figure is extra when
// its file is under one of the two folders and its registry (physics/p<k>.js, explore/lens/index.js, explore/leaf/index.js) names it: nothing else changes.
// src/figures/index.js spreads the same two registries into the full registry (core + extra) that the tests and server rendering import.
import { EXPLORE_FIGURES } from './explore/index.js';
import { PHYS_FIGURES } from './physics/index.js';

export const EXTRA_FIGURES = { ...EXPLORE_FIGURES, ...PHYS_FIGURES };

// in the page (app.js has filled the bridge): register and announce. Nothing happens where this module is only imported (node, the tests).
if (typeof window !== 'undefined' && window.__ONE_RULE_BRIDGE__) {
  window.__ONE_RULE_FIGURES_EXTRA__ = EXTRA_FIGURES;
  const Ev = window.CustomEvent || (typeof CustomEvent === 'function' ? CustomEvent : null);
  if (Ev && typeof window.dispatchEvent === 'function') window.dispatchEvent(new Ev('one-rule:figures', { detail: { ids: Object.keys(EXTRA_FIGURES) } }));
}
