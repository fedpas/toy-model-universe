// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/index.js — FIGURES: figure id (content/figures.json) → React component taking { params, lens, level, theme, row } (docs/BUILD_CONTRACTS.md, interface 2).
// The full registry (interface 34, D47): the core figures of src/figures/*.jsx (./core.js) and the extra ones under src/figures/explore/ and
// src/figures/physics/ (the registries src/figures/extra.entry.js spreads into the chunk dist/figures-extra.js). The tests and server rendering import this
// module, so every suite sees every figure; the browser bundle imports ./core.js and loads the extra figures on demand (src/app/lazyFigures.js).
// Each component draws inline SVG with the design tokens only, starts paused when animated, and carries Component.meta = { id, lenses, learner }.
// A's FigureFrame renders the caption, the "what this draws" line and the lens chips from the caption row; a figure draws and never writes a caption.
// The stylesheets come with the modules that import them (./figures.css through ./core.js, first), so that a bundle of this registry carries every figure's
// styles into its stylesheet: build.sh keeps that stylesheet as dist/app.css.
import { CORE_FIGURES } from './core.js';
import { EXPLORE_FIGURES } from './explore/index.js';
import { PHYS_FIGURES } from './physics/index.js';

export const FIGURES = {
  ...CORE_FIGURES,
  ...EXPLORE_FIGURES,
  ...PHYS_FIGURES,
};
export { CORE_FIGURES };
export { Lattice, ClockWheel, FourViews, GaussSum, Trinity, BivectorLab, PetrieOrthoplex, CommGraph, DiracPic, FourViewsMaxwell, MaxwellEquations, MaxwellComponents, MirrorsCube, SpinFourI, CubeCategory, SignFlux, EinsteinFormIdentity, KerrSchildF, FiveBits, TennisRacket, SpringCube, GossetPlane, Zonogon, E8Ladder, KeplerTrio, ExtraGenerator, Rain, RiemannSplit, GolayRing, OQF2, Ladders, FureyBoard, DictionaryBoards, NullFigures, PgaOrbits, HangIt, FreeTop, OneTable, Bands, SignedNetwork, Charges, HorizonFirstLaw, ConnectionForms, BianchiCheck, MatrixHeatmap, SchullerChain } from './core.js';
export default FIGURES;
