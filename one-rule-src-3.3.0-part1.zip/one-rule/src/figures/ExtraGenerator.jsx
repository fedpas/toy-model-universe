// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure extra-generator (step 11): one more generator e with e² = s (0, −1 or +1) beside n base axes. Left: the base axes round a circle (a filled node squares to
// +1, a hollow one to −1), e in the middle (dashed when it is null), and a spoke for each plane B_a = e_a e with its square printed, −e_a² e² — the kernel's sign of
// the two-bit blade (engines/labels.js extraGenerator), equal to projective.json's extra_squares; the spokes are dashed when s = 0. Right: the plane of the null pair,
// e_m (square +1) across, e_p (square −1) up, and the two null diagonals ε and o. Under them, at research level, what projective_selfcheck.py stored for this choice
// (the group, the dimension, the Killing counts). The three choices are v15's chips: the kind of base, s, and n = 2 … 6. Port of v15 ProjectiveSection.LadderPic and NullPic.
// Under the drawing at research level (docs/PHYSICS_AUDIT.md PR1): [B_an, B_bn] = −2s B_ab with the constant the kernel gives (engines/physics/projective.js
// extraAlgebra, equal to the stored commutator_coefficient), k = −s, the coefficient of e∧e in the curvature of step 10 (the stored curvature_coefficient), and the
// signature and Killing counts stored. At learner level (PR2) words only: the geometry each choice names (the stored group), its number of moves in n directions,
// and the null pair as two directions of length 0.
import React, { useState, useEffect, useMemo } from 'react';
import { extraGenerator } from '../../engines/labels.js';
import { PROJECTIVE } from '../../engines/stored.js';
import { FigSvg, Controls, Chips, r1, pick, isIn } from './kit.jsx';
import { extraAlgebra } from '../../engines/physics/projective.js';
import { Tex, useKatex, useStored } from './physics/p8kit.jsx';

const AXN = ['t', 'x', 'y', 'z', 'u', 'v', 'w'];
const NS = [2, 3, 4, 5, 6], SS = [0, -1, 1], KINDS = ['space', 'lorentz'];
const sgn = v => (v > 0 ? '+1' : v < 0 ? '−1' : '0');
/** the learner's words for the choices (v15 ProjectiveSection, the plain version) and the stored group as it is printed */
const KIND_WORD = { space: 'space only', lorentz: 'space and time' }, S_WORD = { 0: 'flat', '-1': 'curved like a ball', 1: 'curved like a saddle' };
export const groupName = g => (g === 'Poincare' ? 'Poincaré' : g);
export const ladderKey = (kind, n, s) => `${kind},${n},${s}`;

export default function ExtraGenerator({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [kind, setKind] = useState(pick(params.kind, isIn(KINDS), 'lorentz'));
  const [s, setS] = useState(pick(params.s, isIn(SS), -1));
  const [n, setN] = useState(pick(params.n, isIn(NS), 4));
  useEffect(() => { setKind(pick(params.kind, isIn(KINDS), 'lorentz')); setS(pick(params.s, isIn(SS), -1)); setN(pick(params.n, isIn(NS), 4)); }, [params.kind, params.s, params.n]);
  const X = useMemo(() => extraGenerator(kind, n, s), [kind, n, s]), rec = PROJECTIVE.ladder[ladderKey(kind, n, s)], A = useMemo(() => extraAlgebra(kind, n, s), [kind, n, s]);
  const katex = useKatex(research), S = useStored(), contraction = S ? S.pj.contraction[`${kind},${n}`] : undefined;
  const C = [130, 112], R = 82, pos = k => [C[0] + R * Math.cos((-90 + 360 * k / n) * Math.PI / 180), C[1] + R * Math.sin((-90 + 360 * k / n) * Math.PI / 180)];
  const dash = s === 0 ? '4 3' : undefined, H = research ? 250 : 226;
  return (
    <div className="fig fig-extra-generator">
      <FigSvg id="extra-generator" row={row} viewBox={`0 0 420 ${H}`}>
        <g data-kind={kind} data-n={n} data-s={s}>
          {X.planes.map(p => { const q = pos(p.a), m = [(q[0] + C[0]) / 2, (q[1] + C[1]) / 2];
            return (
              <g key={'s' + p.a} data-plane={p.a} data-square={p.square}>
                <title>{`B = e${AXN[kind === 'lorentz' ? p.a : p.a + 1]} e squares to ${sgn(p.square)}`}</title>
                <line x1={r1(q[0])} y1={r1(q[1])} x2={C[0]} y2={C[1]} className="stroke-ink" style={{ strokeWidth: 1.8, strokeDasharray: dash }} />
                <text x={r1(m[0] + 5)} y={r1(m[1] - 4)} className="t-mono t-small">{sgn(p.square)}</text>
              </g>
            ); })}
          {X.planes.map(p => { const q = pos(p.a), right = q[0] >= C[0];
            return (
              <g key={'n' + p.a} data-axis={p.a} data-axis-square={p.axisSquare}>
                <circle cx={r1(q[0])} cy={r1(q[1])} r={7} className={p.axisSquare > 0 ? 'ink' : 'on-panel'} style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} />
                <text x={r1(q[0] + (right ? 11 : -11))} y={r1(q[1] + 4)} textAnchor={right ? 'start' : 'end'} className="t-mono t-small">{AXN[kind === 'lorentz' ? p.a : p.a + 1]}</text>
              </g>
            ); })}
          <circle cx={C[0]} cy={C[1]} r={9} className={s === 0 ? 'on-panel' : 'ink'} style={{ stroke: 'var(--fg)', strokeWidth: 2, strokeDasharray: s === 0 ? '3 2' : undefined }} data-extra={s} />
          <text x={6} y={14} className="t-mono t-small" data-geometry={research ? undefined : rec && rec.group}>{research ? `e² = ${sgn(s)}` : rec ? groupName(rec.group) : ''}</text>
        </g>
        <g transform="translate(272, 20)" data-null-pair="1">
          <line x1={0} y1={90} x2={140} y2={90} className="hair" /><line x1={70} y1={180} x2={70} y2={0} className="hair" />
          <line x1={14} y1={160} x2={126} y2={20} className="stroke-ink" style={{ strokeWidth: 2.2 }} />
          <line x1={14} y1={20} x2={126} y2={160} className="stroke-ink" style={{ strokeWidth: 2.2, strokeDasharray: '6 3' }} />
          <text x={research ? 130 : 96} y={research ? 20 : 12} className={research ? 't-head' : 't-small'}>{research ? 'ε' : 'length 0'}</text><text x={research ? 130 : 96} y={research ? 168 : 178} className={research ? 't-head' : 't-small'}>{research ? 'o' : 'length 0'}</text>
          <text x={142} y={86} className="t-mono t-small" textAnchor="end">{research ? 'eₘ' : '+1'}</text><text x={75} y={10} className="t-mono t-small">{research ? 'eₚ' : '−1'}</text>
        </g>
        {research && rec && (
          <text x={6} y={H - 10} className="t-mono t-tiny t-muted" data-group={rec.group} data-dimension={rec.dimension}>
            {`${kind}, n = ${n}, s = ${sgn(s)}: ${rec.group} · dimension ${rec.dimension} · Killing (${rec.killing.positive}, ${rec.killing.negative}, ${rec.killing.zero})`}
          </text>
        )}
        {!research && rec && <text x={6} y={H - 10} className="t-small" data-moves={rec.dimension} data-directions={n}>{`${groupName(rec.group)}: ${rec.dimension} moves in ${n} directions`}</text>}
      </FigSvg>
      <Controls label={research ? 'one more generator' : 'one more direction'}>
        <Chips label={research ? 'base' : 'directions'} items={KINDS} value={kind} onPick={setKind} render={k => (research ? k : KIND_WORD[k])} param="kind" />
        <Chips label={research ? 's' : 'setting'} items={SS} value={s} onPick={setS} render={v => (research ? sgn(v) : S_WORD[v])} param="s" mono={research} />
        <Chips label="n" items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
      {research && rec && A.coef !== null && (
        <p className="gp-read" data-coef={A.coef} data-stored-coef={rec.commutator_coefficient} data-k={A.k} data-stored-k={rec.curvature_coefficient}>
          <Tex katex={katex} tex={`[B_{an}, B_{bn}] = -2s\\,B_{ab} = ${A.coef}\\,B_{ab},\\quad k = -s = ${A.k}`} text={`[B_an, B_bn] = −2s B_ab = ${A.coef} B_ab · k = −s = ${A.k}`} />
          <span className="gp-k">coefficient of e∧e, step 10</span>
          <span className="gp-k">signature</span> <b>{`(+${rec.signature_plus_minus[0]}, −${rec.signature_plus_minus[1]})`}</b>
          {s === 0 ? <><span className="gp-k">zero directions of the Killing form</span> <b data-killing-zero={rec.killing.zero}>{`${rec.killing.zero} = n, the translations`}</b></> : null}
          {contraction !== undefined ? <><span className="gp-k">contraction to s = 0</span> <b data-contraction={String(contraction)}>{contraction ? '✓' : '✗'}</b></> : null}
        </p>
      )}
    </div>
  );
}
ExtraGenerator.meta = { id: 'extra-generator', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
ExtraGenerator.data = (params = {}) => { const kind = pick(params.kind, isIn(KINDS), 'lorentz'), n = pick(params.n, isIn(NS), 4), s = pick(params.s, isIn(SS), -1), X = extraGenerator(kind, n, s); return { kind, n, s, base: X.base, planes: X.planes, stored: PROJECTIVE.ladder[ladderKey(kind, n, s)] }; };
