// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure dirac-pic: the Dirac equation ∇ψJ = mψγ₀ in the even subalgebra of Cl(1,3) as incidences (engines/spinEngine.js diracPic; every sign from the kernel, the 40
// incidences compared with checks/selfcheck/equations.json by tests/engines.test.mjs). The 8 even blades (the components of ψ) are the rows on the left, the 8 odd blades
// (the equations) the rows on the right, in the order of the v15 picture; the five kinds of term (∂t, ∂x, ∂y, ∂z and the mass term m) are drawn side by side as five
// panels over the same rows, so every panel is a one-to-one map from the even to the odd blades (v15 told the kinds apart by colour; the design keeps colour for the clock).
// Research level: a term with sign −1 is dashed. Lenses: hestenes prints the blades as γ-words (γ₀₁ = γ₀γ₁), cube / bits as bit strings, prime / primes as products of
// primes, clifford as e-words; the default is the v15 naming by axes (t, x, y, z). The control is v15's: pick an equation (an odd blade on the right; interactive entry
// hot) and its terms stand out, with their kinds listed under the panels. Port of v15 EquationsSection.DiracPic.
// The physics restoration (owner P5, docs/PHYSICS_AUDIT.md DI1–DI6), the readouts under the panels, every number from the kernel or the stored checks:
//   DI1  the counts (engines/physics/dirac.js counts: 8 components, 8 equations, 40 incidences = 32 derivative + 8 mass, 4 + 1 per equation), both levels;
//   DI2  in the hestenes lens the six bivector rows carry the names of Calibration 1 (Ex … Bz, engines/maxwellPhysics.js through dirac.js maxwellLink) and the line
//        "Maxwell 24 · Dirac 40";
//   DI3  the covariance identity as stored (KaTeX) with ✓ × 6; learner: "keeps its form under all 6 turns and boosts ✓" (RSN-027 states it);
//   DI4  the determinant (p² − m²)⁴ at the 7 stored points, the solution spaces 4 / 4 / 0 and the free waves at ±E; learner: the mass-shell readout;
//   DI5  the numpy cross-check (200 trials, largest error 0, the two wrong versions and their errors), J² = −1 and Jγ₀ = γ₀J by the kernel; learner: the readout;
//   DI6  in the cube lens the cube reading of the counts, marked as our reading (equations.json lists it as ours).
// DI3–DI5 read the stored table content/stored_p5.json (D34: loaded on demand) and sit in folds at research level; tests/physics/p5.test.mjs ties every printed
// number to the stored json and recomputes the counts, the 7 determinants, the ranks and the covariance through the kernel.
import React, { useMemo, useState, useEffect } from 'react';
import { diracPic } from '../../engines/spinEngine.js';
import { label, sigVec } from '../../engines/labels.js';
import { counts, cubeReading, maxwellLink, jFacts } from '../../engines/physics/dirac.js';
import { useTable } from '../app/content.js';
import { useKatex, texToHtml } from '../app/math.js';
import { FigSvg, sub, r1, labelLens } from './kit.jsx';

const EPS13 = sigVec(1, 3);
const AX = ['t', 'x', 'y', 'z'];
const HEAD = { dt: ['∂t', 't'], dx: ['∂x', 'x'], dy: ['∂y', 'y'], dz: ['∂z', 'z'], m: ['m', 'mass'] };
const pc = m => { let c = 0; for (let x = m; x; x &= x - 1) c++; return c; };

/** the name of a blade of Cl(1,3) in the current lens (bit 0 = t) */
export function bladeName(m, lens, research = true) {
  if (lens === 'hestenes') return m ? 'γ' + sub([0, 1, 2, 3].filter(i => (m >> i) & 1).join('')) : '1';
  const L = labelLens(lens);
  if (L === 'bits' || L === 'primes' || L === 'set' || L === 'sigword' || L === 'bitsq' || L === 'clifford') return label(m, L, EPS13);
  return m ? AX.filter((_, i) => (m >> i) & 1).join('') : '1';
}
/** the stored identity "D_p(B psi) = B D_p(psi) - D'_{[B,p]}(psi)" as TeX (and back: tests/physics/p5.test.mjs) */
export const identityTex = s => String(s).replace(/psi/g, '\\psi').replace(/B D_p/g, 'B\\,D_p');
const DET_TEX = '\\det = (p^2 - m^2)^4';

function Dot({ x, y, m, side }) {
  const g = pc(m);
  if (side === 'L' && (g === 0 || g === 4)) return <rect x={r1(x - 3.4)} y={r1(y - 3.4)} width={6.8} height={6.8} className="ink" />;
  if (side === 'R' && g === 3) return <circle cx={x} cy={y} r={3.4} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.2 }} />;
  return <circle cx={x} cy={y} r={3.4} className="ink" />;
}
/** a formula: KaTeX when it has loaded, else the text */
function Tex({ tex, text, katex }) {
  const html = katex ? texToHtml(tex) : null;
  return html ? <span className="mx-tex" data-tex={tex} dangerouslySetInnerHTML={{ __html: html }} /> : <span className="mx-tex mx-plain" data-tex={tex}>{text}</span>;
}
const f1 = x => (Math.round(x * 10) / 10).toFixed(1), tick = v => (v === true ? '✓' : '✗');
/** a fold of the readouts (closed at first: the numbers behind the counts, D29) and a list of name–value rows */
const Fold = ({ id, title, children }) => <details data-fold={id}><summary>{title}</summary><div className="mx-body">{children}</div></details>;
const kv = rows => rows.map(([t, v, a], i) => <React.Fragment key={i}><dt>{t}</dt><dd {...a}>{v}</dd></React.Fragment>);
/** a stored number or fraction for display, with the typographic minus (the data attributes keep the stored text) */
const mn = v => String(v).replace(/^-/, '−');

/** the readouts under the panels: DI1 always; DI2 / DI6 in their lens (research); DI3–DI5 from the stored table, folded at research level */
function Readouts({ D, lens, research, nm }) {
  const [S] = useTable('stored_p5');
  const katex = useKatex(research);
  const C = useMemo(() => counts(D), [D]), per = C.perEquation || { derivative: '?', mass: '?' };
  const cnt = [C.components, C.equations, C.incidences, C.derivative, C.mass, per.derivative, per.mass].join(',');
  const d = S && S.dirac, dm = S && S.dirac_matrix, fw = S && S.free_waves;
  const cov = d && d.covariance, ss = d && d.solution_space, ctrl = dm ? Object.entries(dm.negative_controls_fail_with_error || {}) : [];
  const waves = fw ? Object.entries(fw) : [], on = waves.filter(([k]) => !/^off/.test(k)), off = waves.filter(([k]) => /^off/.test(k));
  const onDims = [...new Set(on.map(([, v]) => v.kernel_dim))].join('/'), offDims = off.map(([, v]) => v.kernel_dim).join('/');
  const signE = on.filter(([k, v]) => Math.sign(Number((/E=(-?\d+)/.exec(k) || [])[1])) === v.a_sign).length, fwLine = `${onDims},${on.length},${offDims},${signE}`;
  const ready = !!(d && dm && fw && cov && ss);
  if (!research) {
    return (
      <>
        <p className="mx-words" data-counts={cnt} data-readout="counts">{`${C.components} numbers, ${C.equations} equations, ${C.incidences} links: ${per.derivative} for change, ${per.mass} for the mass`}</p>
        {ready ? (
          <ul className="mx-legend" aria-label="what is checked">
            <li data-readout="covariance" data-generators={cov.bivector_generators} data-verified={String(cov.verified)}>{`keeps its form under all ${cov.bivector_generators} turns and boosts ${tick(cov.verified)}`}</li>
            <li data-readout="shell" data-shell={`${ss.massive_shell_real_dim},${ss.massless_shell_real_dim},${ss.off_shell_real_dim}`}>{`solutions: only on the mass shell · there, ${ss.massive_shell_real_dim / 2} spin states`}</li>
            <li data-readout="numpy" data-trials={dm.trials} data-worst={dm.worst_error} data-wrong={ctrl.length}>{`a second program: ${dm.worst_error === 0 ? dm.trials : '?'} of ${dm.trials} tries agree · ${ctrl.length} wrong versions fail`}</li>
          </ul>
        ) : null}
      </>
    );
  }
  const ML = lens === 'hestenes' ? maxwellLink(D) : null, CR = labelLens(lens) === 'bits' ? cubeReading(D) : null, JF = jFacts(D);
  return (
    <>
      <p className="mx-head" data-counts={cnt} data-readout="counts">{`ψ: ${C.components} components · ${C.equations} equations · ${C.incidences} incidences = ${C.derivative} derivative + ${C.mass} mass · ${per.derivative} + ${per.mass} per equation`}</p>
      {ML ? <p className="mx-counts" data-maxwell-link={`${ML.maxwell},${ML.dirac}`} data-names={Object.entries(ML.names).map(([m, l]) => `${m}:${l}`).join(',')}>{`Calibration 1, Cl(1,3): ${Object.entries(ML.names).map(([m, l]) => `${l} = ${nm(+m)}`).join(' · ')} · incidences: Maxwell ${ML.maxwell} · Dirac ${ML.dirac}`}</p> : null}
      {CR ? <p className="mx-counts" data-cube={`${CR.derivative},${CR.cubeEdges},${CR.allCubeEdges},${CR.mass},${CR.timeEdges}`} data-even-to-odd={String(CR.evenToOdd)} data-shift={String(CR.shiftByJ)}>{`cube lens: ∂ terms ${CR.derivative} along ${CR.cubeEdges} of the ${CR.allCubeEdges} edges of the 4-cube, even → odd, then the shift by J (${nm(D.J.mask)}) · mass terms ${CR.mass} along the ${CR.timeEdges} time edges `}<span className="mx-tag">our reading</span></p> : null}
      <div className="mx-more">
        {ready ? (
          <>
            <Fold id="covariance" title={`Covariance under the ${cov.bivector_generators} bivectors`}>
              <p className="mx-math" data-identity={cov.identity}><Tex tex={identityTex(cov.identity)} text={cov.identity} katex={katex} /></p>
              <p className="mx-counts" data-generators={cov.bivector_generators} data-verified={String(cov.verified)}>{`${tick(cov.verified)} × ${cov.bivector_generators} · B = ${D.even.filter(m => pc(m) === 2).map(nm).join(' ')} on the left · D′ without the mass term · exact`}</p>
            </Fold>
            <Fold id="momentum" title="Momentum space: the determinant and the solutions">
              <p className="mx-math"><Tex tex={DET_TEX} text="det = (p² − m²)⁴" katex={katex} /></p>
              <div className="fig-scroll">
                <table className="mx-table" data-dispersion={d.dispersion.length}>
                  <caption>{`exact at ${d.dispersion.length} points`}</caption>
                  <thead><tr>{['p', 'm', 'p²', '|det|'].map(x => <th key={x}>{x}</th>)}</tr></thead>
                  <tbody>{d.dispersion.map((r, i) => <tr key={i} data-p={r.p.join(',')} data-m={r.m} data-p2={r.p2} data-det={r.det_abs}>{[`(${r.p.map(mn).join(', ')})`, mn(r.m), mn(r.p2), mn(r.det_abs)].map((x, j) => <td key={j}>{x}</td>)}</tr>)}</tbody>
                </table>
              </div>
              <dl className="mx-kv" data-shell={`${ss.massive_shell_real_dim},${ss.massless_shell_real_dim},${ss.off_shell_real_dim}`} data-free={fwLine}>{kv([
                ['on the shell p² = m²', `${ss.massive_shell_real_dim} real dimensions = ${ss.massive_shell_real_dim / 2} complex: the two spin states`],
                ['on the shell, m = 0', `${ss.massless_shell_real_dim} real dimensions`],
                ['off the shell', String(ss.off_shell_real_dim)],
                ['free waves at ±E', `kernel ${onDims} at ${on.length} points · sign ⟨ψψ̃⟩₀ = sign E at ${signE} · off the shell ${offDims}`],
              ])}</dl>
            </Fold>
            <Fold id="numpy" title="Independent check: 4 × 4 gamma matrices (numpy)">
              <dl className="mx-kv" data-trials={dm.trials} data-worst={dm.worst_error} data-bijection={dm.bijection_rank} data-s={dm.J_u_equals_s_i_u.s} data-controls={ctrl.map(([, v]) => v).join(',')}>{kv([
                ['Ψ = ψu', `u = (1, 0, 0, 0) · γ₀u = u ${tick(dm.gamma0_u_equals_u)} · Ju = s·iu, s = ${dm.J_u_equals_s_i_u.s} · rank ${dm.bijection_rank}`],
                ['trials', `${dm.trials} · largest error ${dm.worst_error}`],
                ...ctrl.map(([k, v]) => ['wrong version', `${k}: error ${f1(v)}`, { 'data-control': k }]),
                ['J (kernel)', `J = ${JF.coef < 0 ? '−' : ''}${nm(JF.mask)}: J² = ${mn(JF.square)} · Jγ₀ ${JF.commutesWithG0 ? '=' : '≠'} γ₀J`, { 'data-j': `${JF.coef * JF.mask},${JF.square},${JF.commutesWithG0}` }],
              ])}</dl>
            </Fold>
          </>
        ) : <p className="mx-counts" data-loading="stored_p5">loading the stored checks</p>}
      </div>
    </>
  );
}

export default function DiracPic({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const D = useMemo(() => diracPic(), []);
  const okHot = v => D.odd.includes(v), [hot, setHot] = useState(okHot(params.hot) ? params.hot : null);
  useEffect(() => { setHot(okHot(params.hot) ? params.hot : null); }, [params.hot]);   // eslint-disable-line react-hooks/exhaustive-deps
  const used = hot == null ? [] : D.incidences.filter(e => e.to === hot), pickHot = m => setHot(h => (h === m ? null : m));
  const he = lens === 'hestenes', names = useMemo(() => (he ? maxwellLink(D).names : {}), [he, D]);
  const W = he ? 450 : 420, top = 40, rh = 24, x0 = he ? 84 : 54, pw = 60, gap = 4, H = top + 8 * rh + (research ? 30 : 12) + (hot != null ? 18 : 0);
  const yl = new Map(D.even.map((m, i) => [m, top + rh * (i + 0.5)])), yr = new Map(D.odd.map((m, i) => [m, top + rh * (i + 0.5)]));
  const nm = m => bladeName(m, lens, research), xr = x0 + 5 * pw + 4 * gap + 6;
  return (
    <div className="fig fig-dirac-pic">
      <FigSvg id="dirac-pic" row={row} viewBox={`0 0 ${W} ${H}`}>
        {research && <text x={x0 - 8} y={18} textAnchor="end" className="t-tiny t-muted">ψ</text>}
        {research && <text x={xr} y={18} className="t-tiny t-muted">equation</text>}
        {D.even.map(m => (
          <text key={'l' + m} x={x0 - 8} y={r1(yl.get(m) + 3.5)} textAnchor="end" className="t-mono t-small" data-maxwell={names[m] || undefined}>
            {names[m] ? <tspan className="t-bold">{names[m] + ' '}</tspan> : null}{nm(m)}
          </text>
        ))}
        {D.odd.map(m => (
          <g key={'r' + m} role="button" tabIndex={0} aria-pressed={hot === m} aria-label={`equation ${nm(m)}`} data-param="hot" data-equation={m} className="fig-cell"
            onClick={() => pickHot(m)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pickHot(m); } }}>
            <rect x={xr - 4} y={r1(yr.get(m) - rh / 2 + 2)} width={W - xr} height={rh - 4} rx={3} className="hit" />
            {hot === m && <rect x={xr - 4} y={r1(yr.get(m) - rh / 2 + 2)} width={W - xr} height={rh - 4} rx={3} className="ink" style={{ fillOpacity: 0.1 }} />}
            <text x={xr} y={r1(yr.get(m) + 3.5)} className={'t-mono t-small' + (hot === m ? ' t-bold' : '')}>{nm(m)}</text>
          </g>
        ))}
        {D.kinds.map((k, j) => {
          const px = x0 + j * (pw + gap), a = px + 8, b = px + pw - 8, inc = D.incidences.filter(e => e.kind === k);
          return (
            <g key={k} data-kind={k}>
              <title>{`${HEAD[k][0]}: ${inc.length} terms`}</title>
              <rect x={px} y={top - 6} width={pw} height={8 * rh + 12} rx={4} className="hair-2" />
              <text x={px + pw / 2} y={top - 12} textAnchor="middle" className={'t-small' + (research ? ' t-mono' : '')}>{HEAD[k][research ? 0 : 1]}</text>
              {inc.map(e => (
                <line key={e.from} x1={a} y1={r1(yl.get(e.from))} x2={b} y2={r1(yr.get(e.to))} className="stroke-ink" data-from={e.from} data-to={e.to} data-sign={e.sign}
                  style={{ strokeWidth: hot === e.to ? 2 : 1.2, strokeOpacity: hot == null ? 0.85 : hot === e.to ? 1 : 0.12, strokeDasharray: research && e.sign < 0 ? '3 2.5' : undefined }}>
                  <title>{`${HEAD[k][0]}: ${nm(e.from)} → ${nm(e.to)}${research ? ` (${e.sign > 0 ? '+' : '−'})` : ''}`}</title>
                </line>
              ))}
              {D.even.map(m => <Dot key={'a' + m} x={a} y={r1(yl.get(m))} m={m} side="L" />)}
              {D.odd.map(m => <Dot key={'b' + m} x={b} y={r1(yr.get(m))} m={m} side="R" />)}
            </g>
          );
        })}
        {research && (
          <g transform={`translate(${x0}, ${top + 8 * rh + 22})`}>
            <line x1={0} y1={-4} x2={18} y2={-4} className="stroke-ink" style={{ strokeWidth: 1.2 }} /><text x={22} y={0} className="t-tiny">+</text>
            <line x1={40} y1={-4} x2={58} y2={-4} className="stroke-ink" style={{ strokeWidth: 1.2, strokeDasharray: '3 2.5' }} /><text x={62} y={0} className="t-tiny">−</text>
            <text x={5 * pw + 4 * gap} y={0} textAnchor="end" className="t-mono t-tiny t-muted">{`J = ${D.J.sign < 0 ? '−' : ''}${nm(D.J.mask)} · ${D.incidences.length} terms`}</text>
          </g>
        )}
        {hot != null && <text x={x0} y={H - 6} className="t-mono t-tiny" data-hot={hot} data-terms={used.length}>{`${nm(hot)}: ${used.length} terms — ${used.map(e => HEAD[e.kind][research ? 0 : 1] + (research ? ` ${nm(e.from)}${e.sign < 0 ? ' (−)' : ''}` : '')).join(', ')}`}</text>}
      </FigSvg>
      <Readouts D={D} lens={lens} research={research} nm={nm} />
    </div>
  );
}
DiracPic.meta = { id: 'dirac-pic', lenses: ['hestenes', 'cube', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, for the frame's data download */
DiracPic.data = () => { const D = diracPic(); return { cell: [1, 3], even: D.even, odd: D.odd, J: D.J, incidences: D.incidences, counts: counts(D), cube: cubeReading(D), maxwell: maxwellLink(D) }; };
