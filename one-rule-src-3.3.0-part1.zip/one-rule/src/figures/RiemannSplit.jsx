// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure riemann-split (step 12): the independent components of the curvature in n dimensions, Riemann n²(n² − 1)/12 = Ricci n(n + 1)/2 + Weyl
// n(n + 1)(n + 2)(n − 3)/12 for n ≥ 3 (engines/labels.js curvature; gravity_selfcheck.py found the same dimensions by linear algebra, gravity.json curvature_space,
// n = 2 … 7). One bar per n = 2 … 8: the Ricci part solid, the Weyl part hollow, the total printed; at n = 2 the one component is the bar (the three Ricci
// components are fixed by it). The dashed line marks where Weyl starts, n = 4. The chips n = 2 … 8 are v15's (interactive entry n). Port of v15 LabelsWidgets.Curvature.
// Under the drawing at research level (docs/PHYSICS_AUDIT.md GG2): the grades of B² for a bivector with every component non-zero, by the kernel product
// (engines/physics/gravity.js bivectorSquare: a scalar for n ≤ 3, a scalar and a 4-vector from n = 4, where Weyl starts), and at n = 4 the line 20 = 10 + 10 with
// the Weyl part as 5 complex numbers. At learner level (GG3) the parts in words: all the bend, the bend fixed by matter, the bend not fixed by matter.
import React, { useState, useEffect } from 'react';
import { curvature } from '../../engines/labels.js';
import { FigSvg, Controls, Chips, r1, pick, isIn } from './kit.jsx';
import { bivectorSquare } from '../../engines/physics/gravity.js';

const NS = [2, 3, 4, 5, 6, 7, 8];
const ROWS = NS.map(curvature), MAX = ROWS[ROWS.length - 1].riemann;
/** the parts in the learner's words (v15 LabelsWidgets.Curvature) */
const LW = { ricci: 'the bend fixed by matter', weyl: 'the bend not fixed by matter', riemann: 'all the bend' };
/** the highest n of gravity.json curvature_space (the linear algebra of gravity_selfcheck.py): above it a bar is the formula only (D37: marked, not extrapolated) */
const STORED_TOP = 7;

export default function RiemannSplit({ params = {}, lens = null, level = 'research', theme, row }) {
  const research = level !== 'learner';
  const [n, setN] = useState(pick(params.n, isIn(NS), 4));
  useEffect(() => { setN(pick(params.n, isIn(NS), 4)); }, [params.n]);
  const sc = 262 / MAX, x0 = 50, cur = curvature(n), B2 = bivectorSquare(n);
  return (
    <div className="fig fig-riemann-split">
      <FigSvg id="riemann-split" row={row} viewBox="0 0 420 262">
        {ROWS.map((r, i) => {
          const y = 8 + i * 30, wr = Math.max(2, (r.n === 2 ? 1 : r.ricci) * sc), ww = r.weyl * sc, on = r.n === n;
          return (
            <g key={r.n} data-n={r.n} data-riemann={r.riemann} data-ricci={r.n === 2 ? 1 : r.ricci} data-weyl={r.weyl}>
              <title>{!research ? `${r.n} directions: ${LW.riemann} ${r.riemann}, ${LW.weyl} ${r.weyl}` : r.n === 2 ? 'n = 2: Riemann 1, Weyl 0' : `n = ${r.n}: Riemann ${r.riemann} = Ricci ${r.ricci} + Weyl ${r.weyl}`}</title>
              {on && <rect x={0} y={y - 4} width={420} height={28} className="ink" style={{ fillOpacity: 0.06 }} data-selected={r.n} />}
              <text x={6} y={y + 15} className={'t-mono t-small' + (on ? ' t-bold' : '')}>{research ? `n = ${r.n}` : String(r.n)}</text>
              <rect x={x0} y={y} width={r1(wr)} height={20} className="ink" style={{ fillOpacity: 0.8 }} data-part="ricci" />
              {ww > 0 && <rect x={r1(x0 + wr)} y={y} width={r1(ww)} height={20} className="on-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1 }} data-part="weyl" />}
              <text x={r1(x0 + wr + ww + 6)} y={y + 15} className="t-mono t-small">{r.n === 2 ? '1' : research ? `${r.riemann} = ${r.ricci} + ${r.weyl}` : String(r.riemann)}</text>
              {research && r.n > STORED_TOP && <text x={r1(x0 + wr + ww + 6)} y={y + 3} className="t-tiny t-muted" data-not-stored={r.n}>formula · linear algebra not stored</text>}
            </g>
          );
        })}
        <line x1={40} y1={8 + 2 * 30 - 5} x2={415} y2={8 + 2 * 30 - 5} className="stroke-ink" style={{ strokeDasharray: '4 3' }} />
        <g transform="translate(50, 226)">
          <rect x={0} y={-9} width={12} height={10} className="ink" style={{ fillOpacity: 0.8 }} /><text x={17} y={0} className="t-small" data-part-word="ricci">{research ? 'Ricci' : LW.ricci}</text>
          <rect x={research ? 70 : 0} y={research ? -9 : 7} width={12} height={10} className="on-panel" style={{ stroke: 'var(--fg)' }} /><text x={research ? 87 : 17} y={research ? 0 : 16} className="t-small" data-part-word="weyl">{research ? 'Weyl' : LW.weyl}</text>
          <text x={research ? 140 : 190} y={0} className="t-small t-muted" data-part-word="riemann">{research ? 'Riemann = Ricci + Weyl' : LW.riemann}</text>
          {research && <text x={0} y={20} className="t-mono t-tiny" data-cur={n}>{n === 2 ? 'n = 2: Riemann 1 · Weyl 0' : `n = ${n}: Riemann ${cur.riemann} = Ricci ${cur.ricci} + Weyl ${cur.weyl}`}</text>}
        </g>
      </FigSvg>
      <Controls label={research ? 'dimension' : 'directions'}>
        <Chips label={research ? 'n' : 'directions'} items={NS} value={n} onPick={setN} param="n" mono />
      </Controls>
      {research && (
        <p className="gp-read" data-bsq={B2.grades.join(',')} data-bsq-n={n}>
          <span className="gp-k">{`B² of a bivector, n = ${n}:`}</span> <b>{B2.grades.length > 1 ? 'a scalar + a 4-vector' : 'a scalar'}</b> <span className="gp-k">{`(grades ${B2.grades.join(', ')})`}</span>
          {n === 4 ? <><span className="gp-k">n = 4:</span> <b data-at4={`${cur.riemann},${cur.ricci},${cur.weyl}`}>{`${cur.riemann} = ${cur.ricci} + ${cur.weyl}`}</b> <span className="gp-k">{`Weyl as ${cur.weyl / 2} complex numbers`}</span></> : null}
        </p>
      )}
    </div>
  );
}
RiemannSplit.meta = { id: 'riemann-split', lenses: [], learner: true };
/** the numbers the figure draws, for the frame's data download */
RiemannSplit.data = () => ({ rows: ROWS });
