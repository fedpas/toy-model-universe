// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/index.js — the Explore figures: the three lens explorers (X3) and the leaf pictures (X6).
import { LENS_FIGURES } from './lens/index.js';
import { LEAF_FIGURES } from './leaf/index.js';
export const EXPLORE_FIGURES = { ...LENS_FIGURES, ...LEAF_FIGURES };
