// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-cube (shelf, under leaf 6): the front of the Octavo leaf "cube" redrawn with the V2 kit. A ladder of three spacetimes — points in 2D (space across,
// time up, the light lines dashed), a square in 3D (time up), a cube in 4D (x, y, z drawn, the time of each corner written beside it) — and beside the picture the
// half-cube of the rung as the chooser of the plane of the move: the corner 1, the plane corners (a turn plane a ring, a boost plane a diamond, the colour of the
// move repeating the mark) and, in 4D, the 4-volume. Two mirrors make the move (engines/explore/leaves/cube.logic.js frontView: mirrorsOf, moveOf, imageOf through
// the kernel); its two weights are bars on the corner 1 and on the plane. Controls (ports of the Octavo face, D24: chips, never a slider): the rung, a tap on a
// plane corner, the amount (one row of nine chips: an angle for a turn plane, a speed for a boost plane), one mirror or two, and the names of the corners
// (bits | numbers | primes, names.js through nameIn).
// Readouts: the plane, its kind and the amount; the interval of a pair of points before and after; the new times. At research level the back of the Octavo leaf:
// in mode math the corners of the 16-cell multiplied by the plane of the front (productView: the kernel's sign, the name of the product), in mode phys the cube
// seen by someone passing at four speeds (passView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, backOf, Back, nf } from './leafKit.jsx';

const SLUG = 'cube', ID = 'leaf-cube';
const NEEDS = ['START', 'RUNG_NS', 'RUNG_CHIPS', 'ANGLE_CHIPS', 'SPEED_CHIPS', 'MIRROR_CHOICE', 'frontView', 'setRung', 'pickPlane', 'setOnce', 'planeOf', 'kindOf',
  'nameIn', 'halfCube', 'letters', 'productView', 'passView', 'passProject', 'PASS_VIEW', 'PASS_SHOW', 'CUBE_EDGES', 'CHOOSER', 'CHOOSER_ASPECT', 'WMAX', 'BACK_N'];
const NAMES = ['bits', 'numbers', 'primes'];
const FORM = { 2: 't² − x²', 3: 't² − x² − y²', 4: 't² − x² − y² − z²' };
const namesOf = (params, lens) => (NAMES.includes(params.names) ? params.names : lens === 'primes' || lens === 'prime' ? 'primes' : 'bits');
function startOf(L, params) {
  let s = L.START;
  if (L.RUNG_NS.includes(params.n)) s = L.setRung(s, params.n);
  if (Number.isInteger(params.plane)) s = L.pickPlane(s, params.plane);
  // the amount chip k: the k-th angle of a turn and the k-th speed of a boost
  if (Number.isInteger(params.amount) && params.amount >= 0 && params.amount < L.ANGLE_CHIPS.length) s = { ...s, deg: L.ANGLE_CHIPS[params.amount], sv: L.SPEED_CHIPS[params.amount] };
  if (typeof params.once === 'boolean') s = L.setOnce(s, params.once);
  return s;
}
const degText = d => nf(d, 0) + '°', speedText = v => nf(v / 100, 1);

export default function LeafCube(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Cube L={L} {...props} />;
}

function Cube({ L, params = {}, level = 'research', mode = 'phys', lens = null, row }) {
  const [s, setS] = useState(() => startOf(L, params));
  const [names, setNames] = useState(() => namesOf(params, lens));
  useEffect(() => { setS(startOf(L, params)); }, [params.n, params.plane, params.amount, params.once]);   // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setNames(namesOf(params, lens)); }, [params.names, lens]);                                         // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.frontView(s), n = v.n, turn = v.kind === 'turn', back = backOf(level, mode);
  const ink = v.once ? 'var(--fg)' : v.color, w400 = 'leaf-pic leaf-w400';
  return (
    <div className="fig leaf leaf-cube">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part={n === 2 ? 'three points of a ruler in 2D spacetime' : n === 3 ? 'a square in 3D spacetime, time up' : 'a cube in 4D spacetime, its times written at the corners'} viewBox={v.vb} className={w400} style={{ maxWidth: 440 }} data-rung={n} data-plane={v.m} data-kind={v.kind} data-once={String(v.once)}>
          {v.axes.map(a => <line key={'a' + a.name} x1={r1(a.x1)} y1={r1(a.y1)} x2={r1(a.x2)} y2={r1(a.y2)} className="ln-l" />)}
          {v.axes.map(a => <text key={'l' + a.name} x={r1(a.lx + (a.name === 't' || a.name === 'z' ? 8 : 6))} y={r1(a.ly + (a.name === 't' || a.name === 'z' ? 12 : -6))} className="lt-math t-muted" style={{ fontStyle: 'italic' }}>{a.name}</text>)}
          {v.light.map((l, i) => <line key={'c' + i} x1={r1(l.x1)} y1={r1(l.y1)} x2={r1(l.x2)} y2={r1(l.y2)} className="ln-m ln-dash" style={{ strokeWidth: 2 }} data-light={i} />)}
          {v.lightLabel ? <text x={r1(v.lightLabel.x)} y={r1(v.lightLabel.y)} className="lt-s t-muted">light</text> : null}
          {v.mirrors.map((l, i) => (
            <g key={'m' + i} data-mirror={i + 1}>
              <line x1={r1(l.x1)} y1={r1(l.y1)} x2={r1(l.x2)} y2={r1(l.y2)} className="ln ln-round" style={{ strokeWidth: 2.5 }} />
              <text x={r1(l.x2 + (l.anchor === 'end' ? -6 : 6))} y={r1(l.y2 + 4)} textAnchor={l.anchor} className="lt-s t-bold">{l.name}</text>
            </g>
          ))}
          <g style={{ stroke: v.color, fill: 'none', strokeWidth: 1.5, opacity: 0.5 }}>{v.curves.map((d, i) => <path key={'p' + i} d={d} />)}</g>
          {v.drops.map((d, i) => <line key={'d' + i} x1={r1(d.x1)} y1={r1(d.y1)} x2={r1(d.x2)} y2={r1(d.y2)} className="ln-m ln-dash" />)}
          {n === 3 ? <polygon points={v.P0.map(q => r1(q[0]) + ',' + r1(q[1])).join(' ')} className="ln-m ln-dash" /> : null}
          {n === 3 ? <polygon points={v.P1.map(q => r1(q[0]) + ',' + r1(q[1])).join(' ')} style={{ fill: ink, fillOpacity: 0.2, stroke: ink, strokeWidth: 3, strokeLinejoin: 'round' }} /> : null}
          {n !== 3 ? v.segs.map(([a, b], i) => <line key={'g' + i} x1={r1(v.P0[a][0])} y1={r1(v.P0[a][1])} x2={r1(v.P0[b][0])} y2={r1(v.P0[b][1])} className="ln-m ln-dash" />) : null}
          {n !== 3 ? v.segs.map(([a, b], i) => <line key={'s' + i} x1={r1(v.P1[a][0])} y1={r1(v.P1[a][1])} x2={r1(v.P1[b][0])} y2={r1(v.P1[b][1])} className="ln-round" style={{ stroke: ink, strokeWidth: n === 2 ? 4 : 2.5 }} />) : null}
          {v.P0.map((q, i) => <circle key={'o' + i} cx={r1(q[0])} cy={r1(q[1])} r="4.5" className="disc" style={{ stroke: 'var(--muted)' }} />)}
          {v.P1.map((q, i) => <circle key={'q' + i} cx={r1(q[0])} cy={r1(q[1])} r={n === 2 ? 7 : 5} style={{ fill: ink, stroke: 'var(--fg)', strokeWidth: 2 }} data-t={v.imgs[i][0]} />)}
          {v.times.map((t, i) => <text key={'t' + i} x={r1(t.x)} y={r1(t.y)} textAnchor="middle" className="t-mono lt-s" data-corner={i}>{t.text}</text>)}
        </FigSvg>
        <div className="leaf-side">
          <Chooser L={L} v={v} names={names} row={row} onPick={m => setS(x => L.pickPlane(x, m))} />
          <Weights L={L} v={v} row={row} />
          <p className="leaf-readout" aria-live="polite" data-plane={v.planeName} data-kind={v.kind} data-amount={v.amountText}>
            {v.once ? `${v.planeName} · one mirror · ${L.letters(1 << v.mir.flip)} ↦ −${L.letters(1 << v.mir.flip)}` : `${v.planeName} · ${v.kind} · ${v.amountText}`}
          </p>
          <p className="leaf-readout muted" data-before={v.interval.before} data-after={v.interval.after}>{`${FORM[n]}: ${nf(v.interval.before, 2)} → ${nf(v.interval.after, 2)}`}</p>
          {n > 2 && !turn && !v.once ? <p className="leaf-readout muted" data-tmin={v.tspan.min} data-tmax={v.tspan.max}>{`new t: ${nf(v.tspan.min, 2)} … ${nf(v.tspan.max, 2)}`}</p> : null}
        </div>
      </div>
      <Controls label="the spacetime">
        <span className="fig-group" role="group" aria-label="the rung of the ladder" data-param="n">
          {L.RUNG_CHIPS.map(c => <button key={c.id} type="button" className="fig-btn" data-param="n" aria-pressed={s.n === c.id} onClick={() => setS(x => L.setRung(x, c.id))}>{c.big}<span className="t-muted">{c.small}</span></button>)}
        </span>
      </Controls>
      <Controls label="the move">
        <span className="fig-group" role="group" aria-label={turn ? 'the angle of the turn' : 'the speed of the boost'} data-param="amount">
          <span className="fig-group-label">{turn ? 'angle' : 'speed'}</span>
          {(turn ? L.ANGLE_CHIPS : L.SPEED_CHIPS).map(x => (
            <button key={x} type="button" className="fig-btn fig-mono" data-param="amount" aria-pressed={turn ? s.deg === x : s.sv === x} onClick={() => setS(y => (turn ? { ...y, deg: x } : { ...y, sv: x }))}>{turn ? degText(x) : speedText(x)}</button>
          ))}
        </span>
        <span className="fig-group" role="group" aria-label="the mirrors" data-param="once">
          {L.MIRROR_CHOICE.map(c => <button key={c.id} type="button" className="fig-btn" data-param="once" aria-pressed={(c.id === 'once') === s.once} onClick={() => setS(x => L.setOnce(x, c.id === 'once'))}>{c.label}</button>)}
        </span>
      </Controls>
      <Controls label="the names of the corners">
        <span className="fig-group" role="group" aria-label="the names of the corners" data-param="names">
          <span className="fig-group-label">names</span>
          {NAMES.map(x => <button key={x} type="button" className="fig-btn fig-mono" data-param="names" aria-pressed={names === x} onClick={() => setNames(x)}>{x}</button>)}
        </span>
      </Controls>
      {back === 'math' ? <ProductsBack L={L} a={v.m} names={names} row={row} /> : back === 'phys' ? <PassBack L={L} row={row} /> : null}
    </div>
  );
}

/** the half-cube of the rung: its corners at the logic's places (CHOOSER, in percent), the edges out of the corner 1 bold, the edge to the picked plane in the colour of the move */
function Chooser({ L, v, names, row, onPick }) {
  const n = v.n, W = 240, H = Math.round(W / L.CHOOSER_ASPECT[n]), X = x => r1(x / 100 * W), Y = y => r1(y / 100 * H), c = v.chooser, pad = 26;
  // a corner's name sits under it on the segment (2D), else outside the shape, away from the middle of the corners, clear of the edges
  const mx = c.corners.reduce((a, k) => a + X(k.x), 0) / c.corners.length, my = c.corners.reduce((a, k) => a + Y(k.y), 0) / c.corners.length;
  const nameAt = k => { const x = X(k.x), y = Y(k.y); if (n === 2) return [x, r1(y + 37)]; const dx = x - mx, dy = y - my, d = Math.hypot(dx, dy) || 1; const k2 = n === 4 ? 42 : 36; return [r1(x + k2 * dx / d), r1(y + k2 * dy / d + 4)]; };
  return (
    <FigSvg id={ID} row={row} part={`the half-cube of ${n}D spacetime: ${c.counts.corners} corners, ${c.counts.edges} ${c.counts.edges === 1 ? 'edge' : 'edges'}`} viewBox={`${-pad} ${-pad} ${W + 2 * pad} ${H + 2 * pad + 14}`} style={{ maxWidth: 320 }} data-corners={c.counts.corners} data-edges={c.counts.edges}>
      {c.edges.map(e => <line key={e.a + '-' + e.b} x1={X(e.x1)} y1={Y(e.y1)} x2={X(e.x2)} y2={Y(e.y2)} className={e.on ? '' : e.bold ? 'ln' : 'ln-l'} style={e.on ? { stroke: v.color, strokeWidth: 5 } : { strokeWidth: e.bold ? 2.2 : 1 }} data-edge={e.a + '-' + e.b} />)}
      {c.corners.map(k => {
        const x = X(k.x), y = Y(k.y), label = L.nameIn(k.m, names, n), d = 23;
        const body = k.isPlane
          ? <g className={`mv mv-${k.kind}${k.on ? ' is-on' : ''}`}>{k.kind === 'turn' ? <circle cx={x} cy={y} r="19" /> : <path d={`M${x} ${r1(y - d)} L${r1(x + d)} ${y} L${x} ${r1(y + d)} L${r1(x - d)} ${y} Z`} />}</g>
          : <circle cx={x} cy={y} r={k.m ? 21 : 17} className="disc" />;
        const words = <>
          <text x={x} y={y} textAnchor="middle" className={'lt-math lt-mid' + (k.on ? ' t-bold' : '')} style={{ fontSize: k.m && !k.isPlane ? 13 : 16 }}>{k.name}</text>
          <text x={nameAt(k)[0]} y={nameAt(k)[1]} textAnchor="middle" className="t-mono lt-s t-muted" data-name={label}>{label}</text>
        </>;
        return k.isPlane
          ? <g key={k.m} {...pickProps('plane', `the plane ${k.name}, a ${k.kind} plane`, k.on, () => onPick(k.m))} data-corner={k.m} data-kind={k.kind}><circle cx={x} cy={y} r="25" className="pick-hit" />{body}{words}</g>
          : <g key={k.m} data-corner={k.m}>{body}{words}</g>;
      })}
    </FigSvg>
  );
}

/** the two weights of the move: bars on the corner 1 and on the plane, from −WMAX to WMAX around a zero line */
function Weights({ L, v, row }) {
  const x0 = 48, bw = 200;
  return (
    <FigSvg id={ID} row={row} part="the weights of the move on the corner 1 and on the plane" viewBox="0 0 300 80" style={{ maxWidth: 320 }} data-rest={v.rest}>
      {v.weights.map((w, i) => (
        <g key={w.m} data-weight={w.m} data-w={w.w}>
          <text x="8" y={r1(26 + 34 * i)} className="lt-math lt-mid">{w.name}</text>
          <rect x={x0} y={r1(17 + 34 * i)} width={bw} height="18" rx="9" className="fill-panel" style={{ stroke: 'var(--line)', strokeWidth: 1.2 }} />
          <rect x={r1(x0 + w.left / 100 * bw)} y={r1(20 + 34 * i)} width={r1(w.width / 100 * bw)} height="12" rx="5" className={w.kind ? '' : 'fill-muted'} style={w.kind ? { fill: v.color } : undefined} />
          <line x1={x0 + bw / 2} y1={r1(13 + 34 * i)} x2={x0 + bw / 2} y2={r1(39 + 34 * i)} className="ln" style={{ strokeWidth: 2 }} />
          <text x="294" y={r1(26 + 34 * i)} textAnchor="end" className="t-mono lt-s lt-mid">{w.text}</text>
        </g>
      ))}
    </FigSvg>
  );
}

const Eb = ({ m }) => (m === '1' ? '1' : <>e<sub>{m}</sub></>);
/** the Mathematician's back (Octavo's Say): the 16-cell of the even labels of 4D spacetime, each corner with its letters and its name, the plane of the front marked,
 *  and the products of that plane with every corner: the kernel's sign, the corner they land on, the name of the product from the names (productView) */
function ProductsBack({ L, a, names, row }) {
  const n = L.BACK_N, corners = L.halfCube(n).corners, rows = corners.map(b => L.productView({ a, b, names })), p0 = rows[0], S = 300, X = x => r1(x / 100 * S), pad = 30;
  return (
    <Back who="math" way="algebra">
      <FigSvg id={ID} row={row} part="the corners of the 16-cell and the products of one plane" viewBox={`${-pad} ${-pad} ${S + 2 * pad} ${S + 2 * pad}`} style={{ maxWidth: 380 }} data-a={a} data-names={names}>
        {p0.edges.map(e => <line key={e.a + '-' + e.b} x1={X(e.x1)} y1={X(e.y1)} x2={X(e.x2)} y2={X(e.y2)} className={e.a === a || e.b === a ? 'ln' : 'ln-l'} style={{ strokeWidth: e.a === a || e.b === a ? 1.8 : 1 }} />)}
        {p0.corners.map(k => (
          <g key={k.m} data-corner={k.m} data-label={k.label}>
            {k.kind ? <g className={`mv mv-${k.kind}${k.first ? ' is-on' : ''}`}>{k.kind === 'turn' ? <circle cx={X(k.x)} cy={X(k.y)} r="21" /> : <path d={`M${X(k.x)} ${r1(X(k.y) - 25)} L${r1(X(k.x) + 25)} ${X(k.y)} L${X(k.x)} ${r1(X(k.y) + 25)} L${r1(X(k.x) - 25)} ${X(k.y)} Z`} />}</g>
              : <circle cx={X(k.x)} cy={X(k.y)} r="21" className={k.first ? 'sel' : 'disc'} />}
            <text x={X(k.x)} y={r1(X(k.y) - 4)} textAnchor="middle" className="lt-math lt-mid" style={{ fontSize: k.m === 15 ? 12 : 15 }}>{k.name}</text>
            <text x={X(k.x)} y={r1(X(k.y) + 11)} textAnchor="middle" className="t-mono lt-mid" style={{ fontSize: 11.5 }}>{k.label}</text>
          </g>
        ))}
      </FigSvg>
      {rows.map(p => (
        <p key={p.b} className="leaf-readout" data-b={p.b} data-c={p.c} data-sign={p.sign} data-kinds={p.kinds.join(',')}>
          <span className="lt-math"><Eb m={p.left[0]} /> <Eb m={p.left[1]} /> = {p.signText}<Eb m={p.right} /></span>{' · '}<span>{p.nameLine}</span>
        </p>
      ))}
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): a cube of side 1 at rest and the same cube at one moment of someone passing along x, at the speeds PASS_SHOW (passView) */
function PassBack({ L, row }) {
  const V = L.PASS_VIEW, views = L.PASS_SHOW.map(sp => L.passView(sp)), step = 118, W = step * views.length + 14, H = 170;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="a cube at rest and passed at three speeds" viewBox={`0 0 ${W} ${H}`} style={{ maxWidth: 560 }}>
        {views.map((p, k) => {
          // the logic's oblique view of the cube (passProject), drawn at 0.82 of its size about the cube's front bottom corner
          const o = [16 + step * k, 140], Q = p.corners.map(c => L.passProject(o, p.v ? c.at : c.rest)).map(([x, y]) => [o[0] + 0.82 * (x - o[0]), o[1] + 0.82 * (y - o[1])]);
          return (
            <g key={k} data-speed={p.v} data-length={p.len} data-gamma={p.gamma}>
              <text x={r1(o[0] + 40)} y="22" textAnchor="middle" className="t-mono lt-l">{p.v ? 'v ' + p.valueText : 'at rest'}</text>
              {L.CUBE_EDGES.map(([a, b], i) => <line key={i} x1={r1(Q[a][0])} y1={r1(Q[a][1])} x2={r1(Q[b][0])} y2={r1(Q[b][1])} className="ln-round" style={{ stroke: p.v ? 'var(--boost)' : 'var(--fg)', strokeWidth: 2.4 }} />)}
            </g>
          );
        })}
      </FigSvg>
      {views.map(p => <p key={p.v} className="leaf-readout" data-v={p.v}>{`v ${p.valueText} · ${p.cells.map(([k, x]) => `${k} ${x}`).join(' · ')}`}</p>)}
    </Back>
  );
}

LeafCube.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the rung, the plane and its kind, the amount, the moved points, the weights, the interval kept, the names of the chooser's corners */
LeafCube.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.frontView(s), names = namesOf(params, null);
  return {
    n: v.n, plane: v.m, kind: v.kind, once: v.once, amount: v.amountText, points: v.imgs, weights: v.weights.map(w => ({ corner: w.m, weight: w.w })),
    interval: v.interval, names, corners: v.chooser.corners.map(k => ({ corner: k.m, letters: k.name, name: L.nameIn(k.m, names, v.n), kind: k.kind }))
  };
};
LeafCube.ready = () => !!logicOf(SLUG, NEEDS);
