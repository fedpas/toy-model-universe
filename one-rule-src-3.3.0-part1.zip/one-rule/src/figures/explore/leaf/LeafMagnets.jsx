// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-magnets (Explore, shelf, under leaf 4): the front of the Octavo leaf "magnets" redrawn with the V2 kit. A beam that comes in pointing up goes
// through three magnets that point up, right, down or left (engines/explore/leaves/magnets.logic.js frontView: the part each magnet passes, 2⟨ρP⟩₀ by the
// kernel's product in Cl(3,0), how much of the beam is left after it and where it then points). The beam after each magnet is a band of dots as wide as the
// part that is left (eight lanes for the whole beam), with its percentage above and its direction below; the dots move when Play is pressed. Controls (ports of
// the Octavo face): each magnet is a pick, a tap turns it a quarter turn clockwise and the arrow keys point it; Play (paused at first). Readouts: the part each
// magnet passes and the part that gets through, as percentages from the logic. At research level in mode phys, the back of the Octavo leaf: two magnets in
// the two orders, what gets through and the products of their projectors (ordersView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, PlayButton, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, useTicker, backOf, Back } from './leafKit.jsx';

const SLUG = 'magnets', ID = 'leaf-magnets';
const NEEDS = ['START', 'DIRS', 'DEG', 'LANES', 'frontView', 'setDir', 'turn', 'advance', 'pct', 'ordersView', 'bladeText'];
const KEYS = { ArrowUp: 'up', ArrowRight: 'right', ArrowDown: 'down', ArrowLeft: 'left' };
function startOf(L, params) {
  let s = L.START;
  ['m1', 'm2', 'm3'].forEach((m, i) => { if (L.DIRS.includes(params[m]) && params[m] !== s.dirs[i]) s = L.setDir(s, i, params[m]); });
  return s;
}
/** an arrow that points up, turned by deg clockwise, centred at (x, y), of half-length h */
const Arrow = ({ x, y, h, deg, w = 3.2, cls = 'ln', turnable = false }) => (
  <g transform={`translate(${r1(x)} ${r1(y)})`}>
    <g className={turnable ? 'leaf-turnable' : undefined} style={{ transform: `rotate(${deg}deg)` }}>
      <path d={`M0 ${h} V${-h} M${-h * 0.6} ${-h * 0.4} L0 ${-h} L${h * 0.6} ${-h * 0.4}`} className={cls + ' ln-round'} style={{ strokeWidth: w }} />
    </g>
  </g>
);

export default function LeafMagnets(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Magnets L={L} {...props} />;
}

function Magnets({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.m1, params.m2, params.m3]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [phase, setPhase] = useState(0);
  const player = useTicker(dt => setPhase(x => L.advance(x, dt)), 0.2);
  const v = L.frontView(s), W = 360, MW = 56, PW = (W - 3 * MW) / 4, CY = 98, LANE = 9, TOP = 46, BOT = 152;
  const xOfPiece = j => j * (PW + MW), xOfMagnet = i => PW + i * (PW + MW);
  return (
    <div className="fig leaf leaf-magnets">
      <FigSvg id={ID} row={row} part="a beam through three magnets" viewBox={`0 0 ${W} 200`} className="leaf-pic" style={{ maxWidth: 620, margin: '0 auto' }}>
        {v.segs.map(g => {
          const x0 = xOfPiece(g.j), x1 = x0 + PW, rows = Math.round(g.lanes), h = rows * LANE, dots = [];
          for (let a = 0; a < rows; a++) for (let c = -1; c * LANE < PW + LANE; c++) { const x = x0 + (c + phase) * LANE + LANE / 2; if (x > x0 + 2 && x < x1 - 2) dots.push([x, CY - h / 2 + a * LANE + LANE / 2]); }
          return (
            <g key={g.j} data-piece={g.j} data-amount={g.amount} data-lanes={g.lanes}>
              <text x={r1(x0 + PW / 2)} y="28" textAnchor="middle" className="t-mono lt-s t-bold">{g.pct}</text>
              {rows > 0
                ? <><rect x={r1(x0)} y={r1(CY - h / 2)} width={r1(PW)} height={h} className="fill-soft" />{dots.map(([x, y], k) => <circle key={k} cx={r1(x)} cy={r1(y)} r="2.4" className="fill-ink" />)}</>
                : <line x1={r1(x0 + 3)} y1={CY} x2={r1(x1 - 3)} y2={CY} className="ln-m ln-dash" />}
              {g.dir ? <Arrow x={x0 + PW / 2} y={176} h={8} deg={L.DEG[g.dir]} w={2.6} cls="ln-m" /> : null}
            </g>
          );
        })}
        {v.magnets.map(m => {
          const x = xOfMagnet(m.i), param = 'm' + (m.i + 1);
          const turnIt = () => setS(x2 => L.turn(x2, m.i));
          return (
            <g key={m.i} {...pickProps(param, `magnet ${m.i + 1} points ${m.d}; a tap turns it a quarter turn, the arrow keys point it`, null, turnIt,
              { onKeyDown: e => { const d = KEYS[e.key]; if (d) { e.preventDefault(); setS(x2 => L.setDir(x2, m.i, d)); } else if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); turnIt(); } } })} data-magnet={m.i + 1} data-dir={m.d}>
              <rect x={r1(x + 3)} y={TOP} width={MW - 6} height={BOT - TOP} rx="11" className="pick-ring" />
              <text x={r1(x + MW / 2)} y={TOP + 17} textAnchor="middle" className="t-mono lt-s t-muted">{m.i + 1}</text>
              <Arrow x={x + MW / 2} y={CY + 2} h={15} deg={m.deg} turnable />
              <text x={r1(x + MW / 2)} y={BOT - 10} textAnchor="middle" className="lt-s t-bold">{m.d}</text>
            </g>
          );
        })}
      </FigSvg>
      <p className="leaf-readout" aria-live="polite" data-total={v.total} data-parts={v.steps.map(t => t.part).join(',')}>
        {research
          ? <>{`passed: ${v.steps.map(t => L.pct(t.part)).join(' · ')}`}<span className="muted">{` · through: ${L.pct(v.total)}`}</span></>
          : `through: ${L.pct(v.total)}`}
      </p>
      <Controls label="the beam">
        <span className="fig-group-label">{research ? 'a tap on a magnet turns it' : 'tap a magnet to turn it'}</span>
        <PlayButton player={player} />
      </Controls>
      {backOf(level, mode) === 'phys' ? <OrdersBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Physicist's back (Octavo's Say): a beam pointing up through two magnets, up then right and right then up, with what is left after each, and the
 *  products of their two projectors, the first magnet on the right (magnets.logic.js ordersView: the parts by 2⟨ρP⟩₀, the products by the kernel's mul;
 *  diff: the blade where the two products differ) */
function OrdersBack({ L, row }) {
  const o = L.ordersView('up'), PW = 64, MW = 46, H = 84;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="two magnets in the two orders" viewBox={`0 0 360 ${2 * H}`}>
        {o.rows.map((rw, i) => {
          const y0 = i * H, cy = y0 + 50;
          return (
            <g key={i} data-order={i} data-total={rw.total}>
              <text x="4" y={y0 + 16} className="lt-s t-bold">{rw.label}</text>
              {rw.segs.map((g, j) => { const x0 = 70 + j * (PW + MW), h = g.amount * 28; return (
                <g key={j} data-amount={g.amount}>
                  <text x={x0 + PW / 2} y={cy - 18} textAnchor="middle" className="t-mono lt-s">{g.pct}</text>
                  {h > 0 ? <rect x={x0} y={cy - h / 2 + 6} width={PW} height={h} className="fill-soft" style={{ stroke: 'var(--fg)', strokeWidth: 1 }} /> : <line x1={x0} y1={cy + 6} x2={x0 + PW} y2={cy + 6} className="ln-m ln-dash" />}
                </g>); })}
              {rw.magnets.map((mg, j) => { const x = 70 + PW + j * (PW + MW) + 4, w = MW - 8; return (
                <g key={j} data-dir={mg.d}>
                  <rect x={x} y={cy - 18} width={w} height="48" rx="8" className="disc" />
                  <g transform={`translate(${x + w / 2} ${cy + 6})`}><g style={{ transform: `rotate(${mg.deg}deg)` }}><path d="M0 11 V-11 M-7 -4 L0 -11 L7 -4" className="ln ln-round" style={{ strokeWidth: 2.6 }} /></g></g>
                </g>); })}
            </g>
          );
        })}
      </FigSvg>
      {o.rows.map((rw, i) => <p key={i} className="leaf-readout" data-product={rw.expr}>{`${rw.label}: ${rw.pct} · ${rw.expr}`}</p>)}
      <p className="leaf-readout muted" data-diff={o.diff.join(',')}>{o.diff.length ? `different term: ${o.diff.map(L.bladeText).join(', ')}` : 'different term: none'}</p>
    </Back>
  );
}

LeafMagnets.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the part each magnet passes and what is left after it (magnets.logic.js frontView) */
LeafMagnets.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.frontView(s);
  return { dirs: s.dirs, steps: v.steps.map(t => ({ dir: t.d, part: t.part, left: t.left, out: t.out })), total: v.total };
};
LeafMagnets.ready = () => !!logicOf(SLUG, NEEDS);
