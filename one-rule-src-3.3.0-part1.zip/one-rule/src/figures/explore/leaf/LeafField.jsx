// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-field (shelf, under leaf 6): the front of the Octavo leaf "field" redrawn with the V2 kit. The tetrahedron of the four switches t, x, y, z in simple
// perspective, each of its six edges as thick as the part of the field it carries and numbered (engines/explore/leaves/field.logic.js: F in Cl(1,3) from the table
// of the cell 1,3, the observer's field R F R̃ by the kernel's product, frontView: the parts, the widths, the pills, F² = (E² − B²) − 2 (E·B) e_txyz). The kind of
// plane of an edge is told by mark and word (the square of the plane, +1 a boost, −1 a turn): a pointed pill for a boost (the diamond of +1), a round pill for a
// turn (the ring of −1), the legend with the two marks; its colour repeats the mark (--boost, --turn). The edge drawn behind another is dashed. Controls (ports of
// the Octavo face): the chips of the three fields, a stepper for the observer's speed along x (Octavo's slider −0.95 … 0.95, here −0.9 … 0.9 by 0.1) and a tap
// on an edge (Octavo's edge chips of the Mathematician, here on the front at both levels). Readouts: E² − B², E·B, the speed and the picked edge. At research
// level, the back of the Octavo leaf: in mode math the Mathematician's steps of ∇F = J from the picked edge to two corners and two triangles on the
// tetrahedron drawn flat (mathView); in mode phys the Physicist's arrows of E and B across the motion before and after the boost (physView), at his
// starting speed 0.6 of light (Octavo's slider 0 … 0.8: the controls of a leaf are offered at both levels, and the backs are drawn at research level only).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, Stepper, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, pickProps, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'field', ID = 'leaf-field';
const NEEDS = ['START', 'PRESETS', 'EDGES', 'CORNERS', 'CORNER_R', 'VIEW', 'PILL_FS', 'PILL_H', 'frontView', 'presetOf', 'canSet', 'mathView', 'physView', 'FLAT', 'FLAT_AT', 'AXES', 'OUTSIDE_SPOT', 'PHYS_VIEW', 'PHYS', 'vec', 'START_EDGE', 'START_PHYS'];
const STEP = 10;                                    // the stepper moves the speed by 0.1 of light (10 hundredths)
const col = move => `var(--${move})`;
const dashOf = w => `${r1(Math.max(6, 1.6 * w))} ${r1(Math.max(7, 1.4 * w + 4))}`;
/** a pill on an edge: pointed at both ends for a boost plane (the diamond of +1), round for a turn plane (the ring of −1) */
function Pill({ e, h, on }) {
  const { x0, y0, x1, y1 } = e.pill, cy = (y0 + y1) / 2, k = h / 2;
  const style = { fill: on ? 'var(--hi)' : 'var(--panel)', stroke: col(e.move), strokeWidth: on ? 3.2 : 2 };
  return e.move === 'boost'
    ? <path d={`M${r1(x0 - 4)} ${r1(cy)} L${r1(x0 + k - 4)} ${r1(y0)} H${r1(x1 - k + 4)} L${r1(x1 + 4)} ${r1(cy)} L${r1(x1 - k + 4)} ${r1(y1)} H${r1(x0 + k - 4)} Z`} style={style} />
    : <rect x={r1(x0)} y={r1(y0)} width={r1(x1 - x0)} height={h} rx={k} style={style} />;
}
function startOf(L, params) {
  const field = L.presetOf(params.field) ? params.field : L.START.field;
  const v = typeof params.v === 'number' && L.canSet(field, Math.round(params.v * 100)) && Math.round(params.v * 100) % STEP === 0 ? Math.round(params.v * 100) : L.START.v;
  return { field, v, edge: L.EDGES.some(e => e.id === params.edge) ? params.edge : L.START_EDGE };
}

export default function LeafField(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Field L={L} {...props} />;
}

function Field({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.field, params.v, params.edge]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.frontView(s), V = L.VIEW, back = backOf(level, mode);
  const hidden = v.edges.filter(e => e.hidden), front = v.edges.filter(e => !e.hidden), sel = v.edges.find(e => e.id === s.edge);
  return (
    <div className="fig leaf leaf-field">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the six parts of the field on the edges of the tetrahedron t, x, y, z" viewBox={`${V.x} ${V.y} ${V.w} ${V.h}`} className="leaf-pic leaf-w400" style={{ maxWidth: 400 }} data-field={s.field} data-speed={s.v}>
          <line x1={r1(sel.x1)} y1={r1(sel.y1)} x2={r1(sel.x2)} y2={r1(sel.y2)} strokeWidth={r1(sel.width + 16)} strokeLinecap="round" style={{ stroke: 'var(--hi)' }} data-picked={sel.id} />
          {hidden.map(e => <line key={e.id} x1={r1(e.x1)} y1={r1(e.y1)} x2={r1(e.x2)} y2={r1(e.y2)} strokeWidth={r1(e.width)} strokeDasharray={dashOf(e.width)} style={{ stroke: col(e.move) }} data-edge={e.id} data-move={e.move} data-hidden="1" />)}
          {front.map(e => <line key={'h' + e.id} x1={r1(e.x1)} y1={r1(e.y1)} x2={r1(e.x2)} y2={r1(e.y2)} strokeWidth={r1(e.width + 9)} strokeLinecap="round" style={{ stroke: e.id === sel.id ? 'var(--hi)' : 'var(--panel)' }} />)}
          {front.map(e => <line key={e.id} x1={r1(e.x1)} y1={r1(e.y1)} x2={r1(e.x2)} y2={r1(e.y2)} strokeWidth={r1(e.width)} strokeLinecap="round" style={{ stroke: col(e.move) }} data-edge={e.id} data-move={e.move} />)}
          {L.CORNERS.map(c => (
            <g key={c.name} data-corner={c.name}>
              <circle cx={r1(c.x)} cy={r1(c.y)} r={L.CORNER_R} className="disc" style={{ strokeWidth: 2 }} />
              <text x={r1(c.x)} y={r1(c.y)} textAnchor="middle" className="lt-l lt-math lt-mid" style={{ fontStyle: 'italic' }}>{c.name}</text>
            </g>
          ))}
          {v.edges.map(e => (
            <g key={'p' + e.id} {...pickProps('edge', `the edge ${e.letters.split('').join(' ')}, ${e.kind} ${e.comp}: ${e.text}`, e.id === sel.id, () => setS(x => ({ ...x, edge: e.id })))} data-pill={e.id} data-value={e.value}>
              <line x1={r1(e.x1)} y1={r1(e.y1)} x2={r1(e.x2)} y2={r1(e.y2)} strokeWidth="26" style={{ stroke: 'var(--panel)', strokeOpacity: 0 }} />
              <Pill e={e} h={L.PILL_H} on={e.id === sel.id} />
              <text x={r1(e.px)} y={r1(e.py)} textAnchor="middle" className="t-mono t-bold lt-mid" style={{ fontSize: L.PILL_FS }}>{e.text}</text>
            </g>
          ))}
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="the two kinds of edge" viewBox="0 0 300 64">
            <MoveMark cls={1} x={14} y={18} s={8} word="boost" />
            <text x={150} y={23} className="lt-m t-bold">E</text>
            <MoveMark cls={-1} x={14} y={48} s={8} word="turn" />
            <text x={150} y={53} className="lt-m t-bold">B</text>
            <path d="M178 18 L186 8 H226 L234 18 L226 28 H186 Z" style={{ fill: 'var(--panel)', stroke: col('boost'), strokeWidth: 2 }} />
            <rect x="178" y="38" width="56" height="20" rx="10" style={{ fill: 'var(--panel)', stroke: col('turn'), strokeWidth: 2 }} />
            <line x1="246" y1="18" x2="292" y2="18" strokeWidth="6" strokeLinecap="round" style={{ stroke: col('boost') }} />
            <line x1="246" y1="48" x2="292" y2="48" strokeWidth="6" strokeLinecap="round" style={{ stroke: col('turn') }} />
          </FigSvg>
          <p className="leaf-readout leaf-readout-big" aria-live="polite" data-square={v.inv.s} data-dot={v.inv.p}>{`E² − B² = ${v.sText}`}<span className="muted">{` · E·B = ${v.pText}`}</span></p>
          <p className="leaf-readout" data-edge={sel.id}>{`${sel.letters.split('').join(' ')} · `}{sel.kind}<sub>{sel.comp}</sub>{` = ${sel.text}`}</p>
          <p className="leaf-readout muted" data-moving={v.moving ? 1 : 0}>{`observer: ${v.speed}`}</p>
        </div>
      </div>
      <Controls label="the field and the observer">
        <Chips label="field" items={L.PRESETS.map(p => p.id)} value={s.field} onPick={field => setS(x => ({ ...x, field }))} render={id => L.presetOf(id).label} param="field" />
        <Stepper label="observer's speed (c: light)" value={s.v / STEP} min={-9} max={9} onChange={k => setS(x => ({ ...x, v: k * STEP }))} display={k => (k === 0 ? '0' : nf(k / 10, 1))} param="v" />
      </Controls>
      {back === 'math' ? <StepsBack L={L} edge={sel.id} pick={edge => setS(x => ({ ...x, edge }))} row={row} /> : back === 'phys' ? <ObserverBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the tetrahedron drawn flat, t in the middle and the triangle x y z all of the outside; a picked edge and its four
 *  steps of ∇F = J, the two drops (solid, to its two corners) and the two adds (dashed, to the triangles on either side), each named by its equation
 *  (field.logic.js mathView; the counts 4 × 3 + 4 × 3 = 24) */
function StepsBack({ L, edge, pick, row }) {
  const sel = edge, setSel = pick;
  const m = L.mathView(sel), F = L.FLAT, P = L.FLAT_AT, c = m.counts;
  const outside = `M0 0H${F.w}V${F.h}H0Z M${[1, 2, 3].map(a => `${r1(P[a].x)} ${r1(P[a].y)}`).join(' L')}Z`;
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part={`the steps of ∇F = J from the edge ${m.e.letters}`} viewBox={`0 0 ${F.w} ${F.h}`} className="leaf-w400" style={{ maxWidth: 420 }} data-edge={sel}>
        <rect x="0.75" y="0.75" width={F.w - 1.5} height={F.h - 1.5} rx="14" className="fill-bg" style={{ stroke: 'var(--line)' }} />
        {m.lit.has(m.rim) ? <path d={outside} fillRule="evenodd" style={{ fill: 'var(--hi)', fillOpacity: 0.55 }} data-face={m.rim} /> : null}
        {m.faces.filter(f => !f.outside && m.lit.has(f.mask)).map(f => <polygon key={f.mask} points={f.points} style={{ fill: 'var(--hi)', fillOpacity: 0.6 }} data-face={f.mask} />)}
        {L.EDGES.filter(e => e.id === sel).map(e => <line key="sel" x1={r1(P[e.ends[0]].x)} y1={r1(P[e.ends[0]].y)} x2={r1(P[e.ends[1]].x)} y2={r1(P[e.ends[1]].y)} strokeWidth="20" strokeLinecap="round" style={{ stroke: 'var(--hi)' }} />)}
        {L.EDGES.map(e => <line key={e.id} x1={r1(P[e.ends[0]].x)} y1={r1(P[e.ends[0]].y)} x2={r1(P[e.ends[1]].x)} y2={r1(P[e.ends[1]].y)} strokeWidth={e.id === sel ? 8 : 5} strokeLinecap="round" style={{ stroke: col(e.move) }} />)}
        {L.EDGES.map(e => (
          <g key={'hit' + e.id} {...pickProps('edge', `the edge ${e.letters}, ${e.kind} ${e.comp}`, e.id === sel, () => setSel(e.id))}>
            <line x1={r1(P[e.ends[0]].x)} y1={r1(P[e.ends[0]].y)} x2={r1(P[e.ends[1]].x)} y2={r1(P[e.ends[1]].y)} strokeWidth="24" style={{ stroke: 'var(--panel)', strokeOpacity: 0 }} />
          </g>
        ))}
        <text x={L.OUTSIDE_SPOT.x} y={L.OUTSIDE_SPOT.y} textAnchor="middle" className="lt-m lt-math lt-mid t-muted" style={{ fontStyle: 'italic' }}>{m.outsideName}</text>
        <g className="ln ln-round" style={{ strokeWidth: 2.5 }}>
          {m.arrows.map(a => <line key={a.axis} x1={r1(a.x1)} y1={r1(a.y1)} x2={r1(a.x2)} y2={r1(a.y2)} strokeDasharray={a.dashed ? '5 5' : undefined} data-step={a.op} />)}
        </g>
        {m.arrows.map(a => <polygon key={'h' + a.axis} points={a.head} className="fill-ink" />)}
        {P.map((p, a) => (
          <g key={a}>
            <circle cx={r1(p.x)} cy={r1(p.y)} r={F.r} className={m.lit.has(1 << a) ? 'sel' : 'disc'} style={{ strokeWidth: 2 }} />
            <text x={r1(p.x)} y={r1(p.y)} textAnchor="middle" className="lt-l lt-math lt-mid" style={{ fontStyle: 'italic' }}>{L.AXES[a]}</text>
          </g>
        ))}
      </FigSvg>
      <div className="leaf-readout" aria-live="polite" data-steps={m.lines.length}>{m.lines.map(l => <div key={l}>{l}</div>)}</div>
      <div className="leaf-readout muted" data-total={c.total}>
        <div>{`∇F = J · ${c.corners} × ${c.perCorner} + ${c.triangles} × ${c.perTriangle} = ${c.total} steps`}</div>
        <div>{`${c.perEdge} from each of the ${c.edges} edges`}</div>
      </div>
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): one field with parts along and across x, seen along x (y to the right, z up): E and B at rest (faint, dashed) and as an
 *  observer moving along x sees them (solid); E′, B′, the parts along x and the two numbers of F² (field.logic.js physView) */
function ObserverBack({ L, row }) {
  const pv = L.START_PHYS, p = L.physView(pv), W = L.PHYS_VIEW;
  const arrowOf = (a, move, rest) => (
    <g style={rest ? { opacity: 0.4 } : undefined}>
      <line x1={r1(a.x1)} y1={r1(a.y1)} x2={r1(a.x2)} y2={r1(a.y2)} strokeWidth={rest ? 3 : 4.5} strokeLinecap="round" strokeDasharray={rest ? '6 5' : undefined} style={{ stroke: col(move) }} />
      <polygon points={a.head} style={{ fill: col(move) }} />
    </g>
  );
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="E and B across the motion, at rest and moving" viewBox={`0 0 ${W.w} ${W.h}`} style={{ maxWidth: 340 }} data-pv={pv}>
        <rect x="0.75" y="0.75" width={W.w - 1.5} height={W.h - 1.5} rx="14" className="fill-bg" style={{ stroke: 'var(--line)' }} />
        <line x1="14" y1={W.cy} x2={W.w - 14} y2={W.cy} className="ln-l" />
        <line x1={W.cx} y1={W.h - 12} x2={W.cx} y2="12" className="ln-l" />
        <text x={W.w - 22} y={W.cy + 22} className="lt-m lt-math t-muted" style={{ fontStyle: 'italic' }}>y</text>
        <text x={W.cx + 9} y="26" className="lt-m lt-math t-muted" style={{ fontStyle: 'italic' }}>z</text>
        {p.moving ? <>{arrowOf(p.eRest, 'boost', true)}{arrowOf(p.bRest, 'turn', true)}</> : null}
        {arrowOf(p.eNow, 'boost', false)}
        {arrowOf(p.bNow, 'turn', false)}
        <circle cx={W.cx} cy={W.cy} r="10" className="disc" style={{ strokeWidth: 2 }} />
        {p.moving ? <circle cx={W.cx} cy={W.cy} r="3.5" className="fill-ink" /> : null}
        <text x={r1(p.eLab.x)} y={r1(p.eLab.y)} textAnchor="middle" className="lt-l lt-math" style={{ fontStyle: 'italic' }}>E</text>
        <text x={r1(p.bLab.x)} y={r1(p.bLab.y)} textAnchor="middle" className="lt-l lt-math" style={{ fontStyle: 'italic' }}>B</text>
      </FigSvg>
      <div className="leaf-readout" data-speed={p.v}>
        <div className="muted">{`at rest: E = ${L.vec(L.PHYS.E)}`}</div>
        <div className="muted">{`at rest: B = ${L.vec(L.PHYS.B)}`}</div>
        <div>{`speed along x: ${p.speed}`}</div>
        <div>{p.eLine}</div>
        <div>{p.bLine}</div>
      </div>
      <div className="leaf-readout muted">
        <div>{'E′⊥ = γ (E + v × B)⊥'}</div>
        <div>{'B′⊥ = γ (B − v × E)⊥'}</div>
        <div>{p.alongText}</div>
        <div>{p.invText}</div>
      </div>
    </Back>
  );
}

LeafField.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the field and the speed, the six parts on the edges, E² − B² and E·B (field.logic.js frontView) */
LeafField.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.frontView(s);
  return { field: s.field, speed: v.v, edge: s.edge, parts: Object.fromEntries(v.edges.map(e => [e.id, e.value])), moves: Object.fromEntries(v.edges.map(e => [e.id, e.move])), square: v.inv.s, dot: v.inv.p };
};
LeafField.ready = () => !!logicOf(SLUG, NEEDS);
