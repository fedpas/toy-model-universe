// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-clock (Explore, leaf 1): the front of the Octavo leaf "clock" redrawn with the V2 kit. p plus switches and q minus switches; the hand stands at
// the hour the logic gives (engines/explore/leaves/clock.logic.js front: the hour c of wedderburn(p, q), the eight hours with the letter of their kind ℝ ℂ ℍ,
// a pair of tables with a double ring), and beside the dial the table that hour names, k × k cells once or twice (k, copies, type from the logic). The hour
// discs carry the clock colour --c0 … --c7 with the hour printed next to them. Controls (ports of the Octavo face): the steppers p and q (the logic's limits),
// a tap on an hour (tapHour: the smallest box at that hour), the button that adds or removes 8 plus switches (eight) and the swap of plus and minus (swapSigns).
// Readouts are numbers and names only: p, q, the hour, the algebra M_k(D) and the kind's name from the logic. At research level in mode math, the back of the
// Octavo leaf: the votes i^(plus lit − minus lit) of the corners of the cube and their sum, pointing at the same hour (voteView, gaussSum).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Stepper, clockVar, r1, sub, arrowHead } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, intIn, backOf, Back } from './leafKit.jsx';

const SLUG = 'clock', ID = 'leaf-clock';
const NEEDS = ['START', 'canMove', 'move', 'tapHour', 'swapSigns', 'eight', 'front', 'canVote', 'voteView', 'BACK_TOTAL'];
const LETTER = { R: 'ℝ', R2: 'ℝ', C: 'ℂ', H: 'ℍ', H2: 'ℍ' };

function startOf(L, params) {
  if (Number.isInteger(params.hour) && params.hour >= 0 && params.hour <= 7) return L.tapHour(L.START, params.hour);
  const p = intIn(params.p, 0, 20, L.START.p), q = intIn(params.q, 0, 20, L.START.q);
  return L.canMove(p, q) && (p !== L.START.p || q !== L.START.q) ? L.move(L.START, p, q) : L.START;
}
const algebraText = w => { const D = LETTER[w.type], one = w.k === 1 ? D : `M${sub(w.k)}(${D})`; return w.copies === 2 ? `${one} ⊕ ${one}` : one; };

export default function LeafClock(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Clock L={L} {...props} />;
}

function Clock({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.p, params.q, params.hour]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.front(s), w = v.w, e8 = L.eight(s), D = 360, C = D / 2;
  const at = pos => [pos.left * D / 100, pos.top * D / 100];
  const letter = LETTER[w.type];
  return (
    <div className="fig leaf leaf-clock">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the dial" viewBox={`0 0 ${D} ${D}`} className="leaf-pic">
          <circle cx={C} cy={C} r={126} className="ln-l ln-dash" />
          {v.hours.map(h => { const [x, y] = at(h.num); return <text key={'n' + h.h} x={r1(x)} y={r1(y)} textAnchor="middle" className="t-mono lt-s t-muted lt-mid">{h.h}</text>; })}
          <g className="leaf-hand" style={{ transform: `rotate(${v.handDeg}deg)`, transformOrigin: `${C}px ${C}px` }}>
            <line x1={C} y1={C} x2={C + 96} y2={C} className="ln ln-round" style={{ strokeWidth: 4.5 }} />
          </g>
          {v.hours.map(h => {
            const [x, y] = at(h.pos), two = h.type === 'R2' || h.type === 'H2';
            return (
              <g key={h.h} {...pickProps('hour', `hour ${h.h}: ${LETTER[h.type]}${two ? ', two tables' : ''}`, h.on, () => setS(L.tapHour(s, h.h)))} data-hour={h.h} data-type={h.type}>
                <circle cx={r1(x)} cy={r1(y)} r={25} className="pick-hit" />
                {two ? <circle cx={r1(x)} cy={r1(y)} r={25} className="ln" style={{ strokeWidth: 1.3 }} /> : null}
                <circle cx={r1(x)} cy={r1(y)} r={21} className="pick-ring" />
                <circle cx={r1(x)} cy={r1(y)} r={21} style={{ fill: clockVar(h.h), fillOpacity: h.on ? 0.42 : 0.16, stroke: 'none', pointerEvents: 'none' }} />
                <text x={r1(x)} y={r1(y)} textAnchor="middle" className="lt-l lt-mid lt-math">{LETTER[h.type]}</text>
              </g>
            );
          })}
          <circle cx={C} cy={C} r={40} className="disc" style={{ strokeWidth: 2 }} />
          <text x={C} y={C - 14} textAnchor="middle" className="lt-s t-muted">hour</text>
          <text x={C} y={C + 14} textAnchor="middle" className="lt-xl" data-clock-hour={v.hour}>{v.hour}</text>
        </FigSvg>
        <div className="leaf-side">
          <TableBox w={w} letter={letter} row={row} />
          <p className="leaf-readout" aria-live="polite" data-p={s.p} data-q={s.q} data-c={v.hour} data-k={w.k} data-copies={w.copies} data-type={w.type}>
            {research
              ? <>{`Cl(${s.p},${s.q}) ≅ ${algebraText(w)}`}<span className="muted">{` · c = ${v.hour}`}</span></>
              : <>{`${s.p} plus · ${s.q} minus → hour ${v.hour}`}</>}
          </p>
          <p className="leaf-readout muted">{v.line1 && v.line2 ? `${v.line1} ${v.line2}` : `${w.copies === 2 ? '2 × ' : ''}${w.k} × ${w.k} · ${letter}`}</p>
        </div>
      </div>
      <Controls label="switches">
        <Stepper label="plus" value={s.p} min={v.pMinusOff ? s.p : s.p - 1} max={v.pPlusOff ? s.p : s.p + 1} onChange={p => setS(L.move(s, p, s.q))} param="p" />
        <Stepper label="minus" value={s.q} min={v.qMinusOff ? s.q : s.q - 1} max={v.qPlusOff ? s.q : s.q + 1} onChange={q => setS(L.move(s, s.p, q))} param="q" />
        {e8 ? <button type="button" className="fig-btn" data-param="eight" onClick={() => setS(e8.next)}>{e8.next.p > s.p ? '+ 8 plus' : '− 8 plus'}</button> : null}
        <button type="button" className="fig-btn" data-param="swap" onClick={() => setS(L.swapSigns(s))}>swap + and −</button>
      </Controls>
      {backOf(level, mode) === 'math' ? <VotesBack L={L} s={s} row={row} /> : null}
    </div>
  );
}

const gaussText = (re, im) => (im === 0 ? `${re < 0 ? '−' : ''}${Math.abs(re)}` : `${re === 0 ? '' : `${re < 0 ? '−' : ''}${Math.abs(re)} ${im < 0 ? '−' : '+'} `}${re === 0 && im < 0 ? '−' : ''}${Math.abs(im) === 1 ? '' : Math.abs(im)}i`);
/** the Mathematician's back (Octavo's Say): every corner of the cube of p + q switches votes i^(plus lit − minus lit); the bars count the votes for 1, i, −1, −i
 *  and the arrow is their sum, on a dial of the eight hours (clock.logic.js voteView, gaussSum; drawn while canVote, up to BACK_TOTAL switches) */
function VotesBack({ L, s, row }) {
  if (!L.canVote(s.p, s.q)) return <Back who="math" way="counting"><p className="leaf-readout muted">{`the votes are drawn up to ${L.BACK_TOTAL} switches`}</p></Back>;
  const vv = L.voteView(s.p, s.q), K = 0.75, C = [348, 130], R = 92, out = (x, y) => [r1(x * K), r1(y * K)];
  const hours = Array.from({ length: 8 }, (_, h) => { const a = h * Math.PI / 4; return { h, x: C[0] + R * Math.cos(a), y: C[1] - R * Math.sin(a), lx: C[0] + (R + 21) * Math.cos(a), ly: C[1] - (R + 21) * Math.sin(a) }; });
  return (
    <Back who="math" way="counting">
      <FigSvg id={ID} row={row} part="the votes of the corners" viewBox="0 0 360 192">
        <g transform={`scale(${K})`}>
          <line x1="6" y1="205" x2="200" y2="205" className="ln" />
          {vv.bars.map((b, j) => <rect key={j} x={r1(b.x)} y={r1(b.y)} width="34" height={r1(b.h)} rx="4" className="fill-ink" style={{ fillOpacity: 0.82 }} data-vote={j} data-count={b.n} />)}
          <circle cx={C[0]} cy={C[1]} r={R} className="ln-l" />
          <line x1={C[0] - R} y1={C[1]} x2={C[0] + R} y2={C[1]} className="ln-l" style={{ strokeWidth: 1 }} />
          <line x1={C[0]} y1={C[1] - R} x2={C[0]} y2={C[1] + R} className="ln-l" style={{ strokeWidth: 1 }} />
          {hours.map(h => <circle key={h.h} cx={r1(h.x)} cy={r1(h.y)} r="3" className="fill-ink" />)}
          <circle cx={r1(vv.tip.x)} cy={r1(vv.tip.y)} r="9" className="sel" />
          <line x1={C[0]} y1={C[1]} x2={r1(vv.end.x)} y2={r1(vv.end.y)} className="ln ln-round" style={{ strokeWidth: 3 }} />
          <path d={arrowHead(C[0], C[1], vv.end.x, vv.end.y, 10)} className="fill-ink" />
        </g>
        {vv.bars.map((b, j) => { const [x, y] = out(b.x + 17, 228), yc = r1((b.y - 8) * K); return <g key={j}><text x={x} y={y} textAnchor="middle" className="lt-m">{['1', 'i', '−1', '−i'][j]}</text><text x={x} y={yc} textAnchor="middle" className="t-mono lt-s t-bold">{b.n}</text></g>; })}
        {hours.map(h => { const [x, y] = out(h.lx, h.ly); return <text key={h.h} x={x} y={y} textAnchor="middle" className={'t-mono lt-s lt-mid ' + (h.h === vv.hour ? 't-bold' : 't-muted')}>{h.h}</text>; })}
      </FigSvg>
      <p className="leaf-readout" data-votes={vv.cnt.join(',')} data-sum={`${vv.g.re},${vv.g.im}`} data-hour={vv.hour}>{`votes for 1, i, −1, −i: ${vv.cnt.join(' · ')} · sum ${gaussText(vv.g.re, vv.g.im)} → hour ${vv.hour}`}</p>
    </Back>
  );
}

/** the table a box is: k × k cells (at most 6 × 6 drawn, fading when k > 4), once or twice side by side */
function TableBox({ w, letter, row }) {
  const two = w.copies === 2, n = w.k <= 4 ? w.k : 6, W = 360, H = 220, gap = 3, room = two ? 156 : 216, cellMax = two ? 46 : 70;
  const size = Math.min(room, n * cellMax + gap * (n - 1)), cell = (size - gap * (n - 1)) / n, fade = w.k > 4;
  const x0s = two ? [W / 2 - 18 - size, W / 2 + 18] : [(W - size) / 2], y0 = (H - size) / 2;
  return (
    <FigSvg id={ID} row={row} part="the table of the hour" viewBox={`0 0 ${W} ${H}`}>
      {x0s.map((x0, g) => (
        <g key={g} data-grid={g}>
          {Array.from({ length: n * n }, (_, i) => {
            const a = i % n, b = Math.floor(i / n), op = fade ? Math.max(0.12, 1 - Math.max(0, (a + b) / (2 * (n - 1)) - 0.4) / 0.6) : 1;
            return (
              <g key={i} style={{ opacity: op }}>
                <rect x={r1(x0 + a * (cell + gap))} y={r1(y0 + b * (cell + gap))} width={r1(cell)} height={r1(cell)} rx={3} className="cell-box" />
                {cell >= 21 ? <text x={r1(x0 + a * (cell + gap) + cell / 2)} y={r1(y0 + b * (cell + gap) + cell / 2)} textAnchor="middle" className={(cell >= 34 ? 'lt-m' : 'lt-s') + ' lt-mid lt-math'}>{letter}</text> : null}
              </g>
            );
          })}
        </g>
      ))}
      {two ? <text x={W / 2} y={H / 2} textAnchor="middle" className="lt-l lt-mid">⊕</text> : null}
    </FigSvg>
  );
}

LeafClock.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws (the frame's data download): the hour, the box and the eight hours, as the logic gives them */
LeafClock.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.front(s);
  return { p: s.p, q: s.q, hour: v.hour, box: { type: v.w.type, k: v.w.k, copies: v.w.copies }, hours: v.hours.map(h => ({ h: h.h, type: h.type })) };
};
LeafClock.ready = () => !!logicOf(SLUG, NEEDS);
