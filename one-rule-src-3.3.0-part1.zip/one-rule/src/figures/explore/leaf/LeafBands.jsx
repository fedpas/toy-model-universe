// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-bands (Explore shelf, under leaf 2; on the Atlas page steps/schuller, section sc-bands): the front of the Octavo leaf "bands" redrawn with the V2 kit.
// A wave above a row of eight steps, all from engines/explore/leaves/bands.logic.js (view: one period as the kernel's product of its three pieces in Cl(2,0), its
// square X² and the verdict band / gap / edge; waveOf: the solution that matters along the row; stopsOf: the stops of the energy). Under it the strip of the
// energies 0 … 30: bands (turns: filled, a ring), gaps (boosts: hatched, a diamond), edges (slides: a bar), each stretch a pick. The class is told by mark, word and
// dash, its colour only repeats them (--turn --slide --boost). Controls (ports of the Octavo face, D24: no slider): the energy stepper (halves of a unit and
// every band edge: Octavo's slider "Energy", which snapped to an edge), a tap on a stretch of the strip (Octavo's strip under the slider), the height stepper
// 0 … 8 (Octavo's slider "Height of the step"), Play (paused at first; Step under reduced motion). Readouts: the energy and the class; at research level
// ½ tr M and X². At research level the back of the Octavo leaf: in mode math the map of moves of leaf 2 with the period's point, its trail over the strip and
// the moves of the three pieces (mapView, trail); in mode phys the band diagram, the energy upright, and |λ|, what each repeat keeps of the wave (physView).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Stepper, PlayButton, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, pickProps, useTicker, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'bands', ID = 'leaf-bands';
const NEEDS = ['startOf', 'view', 'waveOf', 'stopsOf', 'stepEnergy', 'pickStretch', 'setHeight', 'wavePath', 'envPath', 'FRONT', 'SPEED', 'H_STEPS', 'E_MAX', 'fx',
  'mapView', 'trail', 'travelled', 'MAP', 'physView', 'BAND', 'ROW_PHYS', 'MOVE_OF'];
const SIGN = { band: -1, edge: 0, gap: 1 };                                    // the sign class of X²: a ring (−1), a bar (0), a diamond (+1)
const DASH = { band: 'none', edge: '2 6', gap: '9 6' };                        // the wave's line: whole in a band, dotted at an edge, dashed in a gap
const STRIP = { w: 300, h: 40 };                                               // the strip, one unit a tenth of energy
const MIN_HIT = 12;                                                            // a tap target on the strip is at least 1.2 units of energy wide
const tok = cls => `var(--${cls === 'band' ? 'turn' : cls === 'gap' ? 'boost' : 'slide'})`;

export default function LeafBands(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Bands L={L} {...props} />;
}

function Bands({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => L.startOf(params));
  useEffect(() => { setS(L.startOf(params)); }, [params.E, params.h, params.stretch]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [phi, setPhi] = useState(0);
  const player = useTicker(dt => setPhi(x => (x + dt * L.SPEED) % (2 * Math.PI)));
  const v = useMemo(() => L.view(s), [L, s]), w = useMemo(() => L.waveOf(v.E, s.h), [L, v.E, s.h]);
  const F = L.FRONT, cls = v.cls, x = E => (STRIP.w * E) / L.E_MAX;
  const at = v.stop.stretch;
  return (
    <div className="fig leaf leaf-bands">
      {/* the drawing as one block (a wide frame puts it first, then the controls): the marks, the wave over the steps, the strip of energies, the readouts */}
      <div className="leaf-row leaf-bands-draw" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr)', justifyContent: 'stretch', alignItems: 'stretch', gap: 10 }}>
        <FigSvg id={ID} row={row} part="band, edge and gap" viewBox="0 0 410 30" style={{ maxWidth: 430, justifySelf: 'center', alignSelf: 'center' }} data-class={SIGN[cls]}>
          {['band', 'edge', 'gap'].map((c, i) => <MoveMark key={c} cls={SIGN[c]} x={14 + 135 * i} y={15} s={7} on={c === cls} label={research} word={research ? `${c} · ${L.MOVE_OF[c]}` : c} />)}
        </FigSvg>
        <FigSvg id={ID} row={row} part="a wave along a row of steps" viewBox={`0 0 ${F.w} ${F.h}`} preserveAspectRatio="none" style={{ height: 'clamp(150px, 26vw, 300px)' }}>
          <line x1="4" y1={F.mid} x2={F.w - 4} y2={F.mid} className="ln-l ln-dash" vectorEffect="non-scaling-stroke" />
          <path d={L.envPath(w, F.x0, F.unit, F.mid, F.amp)} className="fill-soft" />
          {v.rects.map((r, i) => (r.hh > 0 ? <rect key={i} x={r1(r.x)} y={r1(r.y)} width={r1(r.w)} height={r1(r.hh)} className="ln" style={{ fill: 'var(--line-2)' }} vectorEffect="non-scaling-stroke" /> : null))}
          <line x1="4" y1={F.ground} x2={F.w - 4} y2={F.ground} className="ln" style={{ strokeWidth: 2 }} vectorEffect="non-scaling-stroke" />
          <path d={L.wavePath(w, phi, F.x0, F.unit, F.mid, F.amp)} className="ln ln-round" style={{ strokeWidth: 3, strokeDasharray: DASH[cls] }} vectorEffect="non-scaling-stroke" data-class={SIGN[cls]} data-keep={w.keep} />
        </FigSvg>
        <div className="leaf-bands-strip" style={{ display: 'grid', gap: 2 }}>
          <FigSvg id={ID} row={row} part="the strip of energies 0 to 30: bands, gaps and edges" viewBox={`0 0 ${STRIP.w} ${STRIP.h}`} preserveAspectRatio="none" style={{ height: 44 }}>
            <defs>
              <pattern id="leaf-bands-hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="5" style={{ stroke: 'var(--boost)', strokeWidth: 2 }} /></pattern>
            </defs>
            {v.strip.stretches.map((t, k) => (
              <rect key={k} x={r1(x(t.lo))} y="4" width={r1(x(t.hi) - x(t.lo))} height={STRIP.h - 8} style={t.cls === 'band' ? { fill: 'var(--turn)', fillOpacity: 0.38 } : { fill: 'url(#leaf-bands-hatch)' }} data-stretch={k} data-cls={t.cls} />
            ))}
            <rect x="0" y="4" width={STRIP.w} height={STRIP.h - 8} className="ln" style={{ fill: 'none' }} vectorEffect="non-scaling-stroke" />
            {v.strip.edges.map((e, i) => <line key={i} x1={r1(x(e.e))} y1="0" x2={r1(x(e.e))} y2={STRIP.h} style={{ stroke: 'var(--slide)', strokeWidth: 5 }} vectorEffect="non-scaling-stroke" data-edge={e.e} />)}
            {[...v.strip.stretches.entries()].sort((a, b) => (b[1].hi - b[1].lo) - (a[1].hi - a[1].lo)).map(([k, t]) => {
              const wd = Math.max(MIN_HIT, x(t.hi) - x(t.lo)), x0 = Math.min(STRIP.w - wd, Math.max(0, (x(t.lo) + x(t.hi)) / 2 - wd / 2));
              const label = `${t.cls === 'band' ? 'band' : 'gap'} from ${nf(t.lo, 2)} to ${nf(t.hi, 2)}: put the energy in it`;
              return <g key={'p' + k} {...pickProps('stretch', label, at === k, () => setS(z => L.pickStretch(z, k)), { className: 'leaf-bands-pick', style: { cursor: 'pointer' } })} data-stretch={k}><rect x={r1(x0)} y="0" width={r1(wd)} height={STRIP.h} className="pick-hit" /></g>;
            })}
            <line x1={r1(x(v.E))} y1="0" x2={r1(x(v.E))} y2={STRIP.h} className="ln" style={{ strokeWidth: 3 }} vectorEffect="non-scaling-stroke" data-e={v.E} data-class={SIGN[cls]} />
          </FigSvg>
          <div aria-hidden="true" style={{ position: 'relative', height: 18, fontSize: 13, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
            {v.strip.ticks.map((t, i, all) => <span key={t.t} style={{ position: 'absolute', left: `${t.left}%`, transform: i === 0 ? 'none' : i === all.length - 1 ? 'translateX(-100%)' : 'translateX(-50%)' }}>{t.t}</span>)}
          </div>
        </div>
        <p className="leaf-readout leaf-readout-big" aria-live="polite" data-e={v.E} data-h={s.h} data-class={cls}>
          {`E = ${v.eText}`}<span className="muted">{` · height ${nf(s.h, 0)}`}</span>{` → ${cls}`}
        </p>
        {research ? <p className="leaf-readout muted" data-half={v.g} data-square={v.X2}>{`½ tr M = ${L.fx(v.g)} · X² = ${L.fx(v.X2)} · ${v.move}`}</p> : null}
      </div>
      <Controls label="the wave and the steps">
        <Stepper label="energy" value={v.stop.i} min={0} max={v.stops - 1} onChange={j => setS(z => L.stepEnergy(z, j - v.stop.i))} display={() => v.eText} param="E" />
        <Stepper label="height of the step" value={s.h} min={L.H_STEPS[0]} max={L.H_STEPS[L.H_STEPS.length - 1]} onChange={h => setS(z => L.setHeight(z, h))} display={h => nf(h, 0)} param="h" />
        <PlayButton player={player} label="Play the wave" />
      </Controls>
      {backOf(level, mode) === 'math' ? <MapBack L={L} s={s} fine={v.fine} row={row} /> : null}
      {backOf(level, mode) === 'phys' ? <BandBack L={L} s={s} fine={v.fine} phi={phi} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the map of moves of leaf 2, b e₂ + c e₁₂ squeezed toward the middle (r drawn at R r / (r + 1), which keeps every
 *  point in its wedge): turns above and below, boosts left and right, slides on the diagonals; the period of the cell at the chosen energy as a point, its trail
 *  as the energy runs over the strip (faint, and in the colour of its move up to the chosen energy), the edges as dots; the moves of its three pieces */
function MapBack({ L, s, fine, row }) {
  const edges = useMemo(() => L.view(s).strip.edges.map(e => e.e), [L, s]);
  const parts = useMemo(() => L.trail(s.h), [L, s.h]);
  const m = L.mapView(s.E, fine, edges, s.h), done = L.travelled(parts, s.E), { cx, cy } = L.MAP;
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part="one period as a point on the map of moves" viewBox={`0 0 ${L.MAP.w} ${L.MAP.h}`} style={{ maxWidth: 420 }}>
        <rect x="0.5" y="0.5" width={L.MAP.w - 1} height={L.MAP.h - 1} rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        <polygon points={`${cx},${cy} 20,10 340,10`} style={{ fill: 'var(--turn)', fillOpacity: 0.12 }} />
        <polygon points={`${cx},${cy} 340,330 20,330`} style={{ fill: 'var(--turn)', fillOpacity: 0.12 }} />
        <polygon points={`${cx},${cy} 340,10 340,330`} style={{ fill: 'var(--boost)', fillOpacity: 0.12 }} />
        <polygon points={`${cx},${cy} 20,330 20,10`} style={{ fill: 'var(--boost)', fillOpacity: 0.12 }} />
        <line x1="12" y1={cy} x2="348" y2={cy} className="ln-l" />
        <line x1={cx} y1="6" x2={cx} y2="334" className="ln-l" />
        <line x1="20" y1="10" x2="340" y2="330" style={{ stroke: 'var(--slide)', strokeWidth: 3 }} />
        <line x1="20" y1="330" x2="340" y2="10" style={{ stroke: 'var(--slide)', strokeWidth: 3 }} />
        <MoveMark cls={-1} x={150} y={58} s={7} word={L.MOVE_OF.band} />
        <MoveMark cls={-1} x={150} y={300} s={7} word={L.MOVE_OF.band} />
        <MoveMark cls={1} x={262} y={150} s={7} word={L.MOVE_OF.gap} />
        <MoveMark cls={1} x={34} y={150} s={6} word={L.MOVE_OF.gap} />
        <MoveMark cls={0} x={258} y={84} s={7} word={L.MOVE_OF.edge} />
        <text x="342" y={cy + 18} textAnchor="end" className="lt-m t-muted">b</text>
        <text x={cx + 8} y="24" className="lt-m t-muted">c</text>
        <g style={{ fill: 'none' }}>
          {parts.map((t, i) => (t.pts.length > 1 ? <path key={'a' + i} d={t.d} className="ln-m" style={{ strokeWidth: 1.5, opacity: 0.45 }} /> : null))}
          {done.map((t, i) => (t.pts.length > 1 ? <path key={'b' + i} d={t.d} className="ln ln-round" style={{ strokeWidth: 3, strokeDasharray: DASH[t.cls] }} data-class={SIGN[t.cls]} /> : null))}
        </g>
        {m.dots.map((d, i) => <circle key={i} cx={r1(d.x)} cy={r1(d.y)} r="4.5" style={{ fill: 'var(--slide)', stroke: 'var(--fg)', strokeWidth: 1.5 }} />)}
        <circle cx={r1(m.pt.x)} cy={r1(m.pt.y)} r="12" className="disc" style={{ strokeWidth: 2.5 }} data-b={m.b} data-c={m.c} data-class={SIGN[m.cls]} />
        <MoveMark cls={SIGN[m.cls]} x={m.pt.x} y={m.pt.y} s={5} label={false} on />
      </FigSvg>
      <p className="leaf-readout" data-half={m.g} data-square={m.X2} data-class={m.cls}>{`${m.readout} → ${m.move}`}</p>
      <p className="leaf-readout muted" data-pieces={m.pieces.map(q => q.move).join(',')}>{`pieces ${m.pieces.map(q => `${nf(q.l, 1)} at ${nf(q.V, 0)}: ${q.move}`).join(' · ')} → period: ${m.move}`}</p>
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): the energy upright over four repeats of the steps; the allowed energies (bands) shaded, the edges as lines, the chosen
 *  energy as a dashed line with the wave drawn on it; |λ|, what each repeat keeps of the size of the wave: 1 in a band and at an edge, less in a gap (physView) */
function BandBack({ L, s, fine, phi, row }) {
  const edges = useMemo(() => L.view(s).strip.edges.map(e => e.e), [L, s]);
  const q = useMemo(() => L.physView(s.E, fine, edges, s.h), [L, s, fine, edges]), B = L.BAND;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="allowed energies over a row of steps" viewBox={`0 0 ${B.w} ${B.h}`} style={{ maxWidth: 420 }}>
        <defs>
          <pattern id="leaf-bands-hatch-back" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" style={{ stroke: 'var(--boost)', strokeWidth: 1.5, strokeOpacity: 0.7 }} /></pattern>
        </defs>
        <rect x="0.5" y="0.5" width={B.w - 1} height={B.h - 1} rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        <rect x={B.x0} y={B.y1} width={B.x1 - B.x0} height={B.y0 - B.y1} style={{ fill: 'url(#leaf-bands-hatch-back)' }} />
        {q.bands.map((b, i) => <g key={i} data-band={`${b.lo},${b.hi}`}><rect x={B.x0} y={r1(b.y)} width={B.x1 - B.x0} height={r1(b.hh)} className="fill-panel" /><rect x={B.x0} y={r1(b.y)} width={B.x1 - B.x0} height={r1(b.hh)} style={{ fill: 'var(--turn)', fillOpacity: 0.26 }} /></g>)}
        {q.edgeYs.map((y, i) => <line key={i} x1={B.x0} y1={r1(y)} x2={B.x1} y2={r1(y)} style={{ stroke: 'var(--slide)', strokeWidth: 2 }} />)}
        {q.rects.map((r, i) => (r.hh > 0 ? <rect key={'r' + i} x={r1(r.x)} y={r1(r.y)} width={r1(r.w)} height={r1(r.hh)} className="ln" style={{ fill: 'var(--line-2)' }} /> : null))}
        <line x1={B.ax} y1={B.y0} x2={B.x1} y2={B.y0} className="ln" style={{ strokeWidth: 2 }} />
        <line x1={B.ax} y1={B.y0} x2={B.ax} y2={B.y1 - 8} className="ln" />
        {q.ticks.map(t => <g key={t.t}><line x1={B.ax - 4} y1={r1(t.y)} x2={B.ax} y2={r1(t.y)} className="ln" /><text x={B.ax - 7} y={r1(t.y)} textAnchor="end" className="lt-s t-muted t-mono lt-mid">{t.t}</text></g>)}
        <text x={B.ax + 6} y="16" className="lt-s t-muted">energy</text>
        <line x1={B.x0} y1={r1(q.y)} x2={B.x1} y2={r1(q.y)} className="ln ln-dash" />
        <path d={L.envPath(q.w, B.x0, B.unit, q.y, B.amp)} className="fill-soft" />
        <path d={L.wavePath(q.w, phi, B.x0, B.unit, q.y, B.amp)} className="ln ln-round" style={{ strokeWidth: 2.5, strokeDasharray: DASH[q.cls] }} data-class={SIGN[q.cls]} />
      </FigSvg>
      <p className="leaf-readout" data-keep={q.keep} data-class={q.cls}>{`E = ${q.eText} → ${q.cls} · |λ| = ${nf(q.w.keep, 2)}`}</p>
    </Back>
  );
}

LeafBands.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the state, the verdict of one period, its half trace and square, the edges and the stretches of the strip (bands.logic.js view) */
LeafBands.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = L.startOf(params), v = L.view(s);
  return { E: v.E, h: s.h, cls: v.cls, move: v.move, half: v.g, square: v.X2, stop: v.stop.kind, edges: v.strip.edges.map(e => e.e), stretches: v.strip.stretches.map(t => ({ lo: t.lo, hi: t.hi, cls: t.cls })) };
};
LeafBands.ready = () => !!logicOf(SLUG, NEEDS);
