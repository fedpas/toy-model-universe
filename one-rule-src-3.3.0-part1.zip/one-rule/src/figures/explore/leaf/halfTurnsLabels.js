// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/leaf/halfTurnsLabels.js — where the picture of leaf 4, half-turns (LeafHalfTurns.jsx), puts its names: the word "home" of the arrow's
// dial, the names R and −R on the square of pairs, and the names 1, R and 1 + R of the two halves. The labels are the picture's, not the logic's: the logic
// (engines/explore/leaves/half-turns.logic.js, passed in as L) gives the points, the paths and the dials; this file only chooses free places for the words,
// and tests/explore/leaves.half-turns.test.mjs checks over every turn that no name sits on a line, an edge, a disc or another name. Plain functions, no React.

// ---- the front: the dashed line from the arrow's pivot runs out of its dial, and the word "home" stands under its end, between the two dials, where neither
// the arrow's trail (inside radius trail0) nor the arrow (inside its dial) nor the spinor's disc (on its circle, radius 11 and a 3 unit line) reaches: the
// gap between the dials is narrowest on the line through their centres, so the word sits a little below it
export const FRONT_SIZE = { title: 21, home: 17, mark: 23 };          // type sizes in picture units (viewBox 500 × 278: at least 11 px on a 390 px phone)
export function homeLine(L) { const D = L.DIAL; return { x1: D.ax, x2: D.ax + D.r + 10, y: D.cy }; }
/** the word "home": its anchor point (start, on the base line) and the box its glyphs take (0.62 em a letter, 0.74 em above the base line, 0.24 em below) */
export function homeLabel(L) {
  const D = L.DIAL, size = FRONT_SIZE.home, x = D.ax + D.r + 1.5, top = D.cy + 24, y = top + 0.74 * size, w = 4 * 0.62 * size;
  return { x, y, size, anchor: 'start', box: { x0: x, x1: x + w, y0: top, y1: y + 0.24 * size } };
}

// ---- the square of pairs: R and −R each get a name on a free side of their disc
export const TAG_SIZE = 17;
const TAG_W = { R: 12, '−R': 23 };                                   // the width of each name at TAG_SIZE (the box runs 13 above the line and 2 below)
const boxOf = (t, text) => { const w = TAG_W[text], x0 = t.anchor === 'end' ? t.x - w : t.anchor === 'middle' ? t.x - w / 2 : t.x; return { x0: x0 - 1, x1: x0 + w + 1, y0: t.y - 13, y1: t.y + 2 }; };
export const tagBox = boxOf;
const inBox = (p, b) => p.x > b.x0 && p.x < b.x1 && p.y > b.y0 && p.y < b.y1;
const overlap = (a, b) => a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1;
/** what a name on the square must keep off: points of the two laps of the line (up = across/2 and 180 + across/2), of the four edges and of the vertical guide
 *  under R, and the boxes of the tick names around the square */
export function squareGuards(L, guideX) {
  const S = L.SQUARE, pts = [];
  for (let a = 0; a <= 360; a += 1) for (const lap of [0, 1]) pts.push(L.toXY({ across: a, up: lap * 180 + a / 2 }));
  for (let t = 0; t <= S.s; t += 1) pts.push({ x: S.x, y: S.y + t }, { x: S.x + S.s, y: S.y + t }, { x: S.x + t, y: S.y }, { x: S.x + t, y: S.y + S.s });
  if (guideX != null) for (let y = S.y; y <= S.y + S.s; y += 1) pts.push({ x: guideX, y });
  const X0 = S.x, X1 = S.x + S.s, Y0 = S.y, Y1 = S.y + S.s, YM = (Y0 + Y1) / 2;
  const boxes = [
    ...[Y1, YM, Y0].map(y => ({ x0: X0 - 12 - 22, x1: X0 - 12, y0: y + 6 - 13, y1: y + 6 + 2 })),            // +1, −1, +1 on the left
    ...[X0, (X0 + X1) / 2, X1].map(x => ({ x0: x - 18, x1: x + 18, y0: Y1 + 24 - 11, y1: Y1 + 24 + 3 })),    // 0°, 180°, 360° under the square
    { x0: X0 - 12 - 40, x1: X0 - 12, y0: Y0 - 16 - 11, y1: Y0 - 16 + 3 }                                  // the word rotor over the left edge
  ];
  return { pts, boxes };
}
/** the ring of a disc of radius r around c, as points */
export const ring = (c, r) => Array.from({ length: 36 }, (_, i) => ({ x: c.x + r * Math.cos(i * Math.PI / 18), y: c.y + r * Math.sin(i * Math.PI / 18) }));
/** whether a name's box is free: inside the picture (380 × 350), off every guard point and box, off the rings given and off the boxes of names already placed */
export function freeBox(b, guards, rings = [], taken = []) {
  return b.x0 > 0 && b.x1 < 380 && b.y0 > 0 && b.y1 < 350 && !guards.pts.some(p => inBox(p, b)) && !guards.boxes.some(g => overlap(g, b)) && !rings.some(p => inBox(p, b)) && !taken.some(t => overlap(t, b));
}
// the places tried around a disc, in this order: the upper left and the lower right first (the line climbs from the lower left to the upper right, so those
// sides are free most of the time), then right, left, the other two corners, above and below, each at two distances
const AROUND = [[-1, -1, 'end'], [1, 1, 'start'], [1, 0, 'start'], [-1, 0, 'end'], [1, -1, 'start'], [-1, 1, 'end'], [0, -1, 'middle'], [0, 1, 'middle']];
const placeAt = (c, [dx, dy, anchor], k) => ({ x: c.x + dx * 13 * k, y: c.y + (dy < 0 ? -9 - 6 * (k - 1) : dy > 0 ? 21 + 6 * (k - 1) : 6) + (dx === 0 ? dy * 6 * k : 0), anchor });
/** the names of R and −R on the square for the view tv = L.torusView(φ): { R: { x, y, anchor }, mR: { x, y, anchor } } — R first, then −R off it */
export function torusTags(L, tv) {
  const guards = squareGuards(L, tv.p.x), out = {}, taken = [];
  for (const [key, text, c, other, rOther] of [['R', 'R', tv.p, tv.o, 9], ['mR', '−R', tv.o, tv.p, 10]]) {
    const rings = [...ring(other, rOther), ...ring(c, key === 'R' ? 10 : 9)];
    let pick = null;
    for (const k of [1, 1.6, 2.2]) { for (const a of AROUND) { const t = placeAt(c, a, k); if (freeBox(boxOf(t, text), guards, rings, taken)) { pick = t; break; } } if (pick) break; }
    out[key] = pick || placeAt(c, AROUND[0], 1);
    taken.push(boxOf(out[key], text));
  }
  return out;
}

// ---- the physicist's picture: the name 1 of the half that is not turned on the side away from the turned half, R beyond the tip of the turned half, and 1 + R
// beside the middle of the dashed sum on the side away from the two arrows (a sum too short to carry it goes without)
export function glowLabels(L, gv) {
  const [a, b] = gv.rotor, P = L.PH, up = b > L.EPS, { p0, p1, p2 } = gv;
  const r = { x: p1.x + (P.u + 17) * a, y: p1.y - (P.u + 17) * b + 5 };
  const one = { x: (p0.x + p1.x) / 2, y: up ? p0.y + 24 : p0.y - 12 };
  const sx = p2.x - p0.x, sy = p2.y - p0.y, len = Math.hypot(sx, sy);
  let sum = null;
  if (len >= 40) { let nx = -sy / len, ny = sx / len; if (nx * (p1.x - (p0.x + sx / 2)) + ny * (p1.y - (p0.y + sy / 2)) > 0) { nx = -nx; ny = -ny; } sum = { x: p0.x + sx / 2 + 20 * nx, y: p0.y + sy / 2 + 20 * ny + 5 }; }
  return { one, r, sum };
}
