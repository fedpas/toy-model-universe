// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-hung (Explore, shelf, under leaf 2): the front of the Octavo leaf "hung" redrawn with the V2 kit. The pull of the spring against its stretch,
// drawn going down from the ceiling beside a cube hung by one corner on the same scale; the weight as a vertical line; where the two meet, the balances
// (engines/explore/leaves/hung.logic.js seeView: the size of the join by the kernel in the flat, round and saddle spaces, the rest, the second balance of the
// sphere, the hook, the spring, the cube). A balance wears the mark of its move (leafKit MoveMark): the rest a ring (a turn), the one that tips a diamond (a
// boost), the meeting of the two at the top of the hump a bar (a slide). Controls (ports of the Octavo face): the chips Flat | Round | Saddle and a stepper for
// the weight from 0 to 2 k in tenths of k. Readouts: the rest of each space, as the logic gives it. At research level, the backs of the Octavo leaf: in mode
// math the slice of the three spaces with the point of each at its rest, on the line where the size of the join is m g / k (lawView); in mode phys the
// energy of spring and weight with its valley and, on the sphere, its hill, and a ball nudged at each (valley, physView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, Stepper, arrowHead, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, nf, intIn, backOf, Back } from './leafKit.jsx';

const SLUG = 'hung', ID = 'leaf-hung';
const NEEDS = ['SPACES', 'NAMES', 'START', 'W_MAX', 'W_STEP', 'K', 'FR', 'fx', 'fy', 'TOP', 'AXIS', 'PULL_PATHS', 'FACE_SHADE', 'seeView', 'weightOf', 'MA', 'mx', 'my', 'SLICE_PATHS', 'SLICE_LABEL', 'FORM', 'lawView', 'PE', 'valley', 'physView', 'energy', 'PHYS_FORM', 'BALL_R', 'fate'];
const CLS = { turn: -1, slide: 0, boost: 1 };
const WORD = { turn: 'rest', boost: 'tips', slide: 'only just' };
const HALO = { paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 4, strokeLinejoin: 'round' };
function startOf(L, params) {
  const space = L.SPACES.includes(params.space) ? params.space : L.START.space;
  const weight = intIn(params.weight, 0, L.W_MAX / L.W_STEP, L.START.wv / L.W_STEP);
  return { space, weight };
}

export default function LeafHung(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Hung L={L} {...props} />;
}

function Hung({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const [st, setSt] = useState(() => startOf(L, params));
  useEffect(() => { setSt(startOf(L, params)); }, [params.space, params.weight]);   // eslint-disable-line react-hooks/exhaustive-deps
  const wv = st.weight * L.W_STEP, v = L.seeView(st.space, wv), F = L.FR;
  const bottom = L.fy(Math.PI), right = L.fx(F.pmax), back = backOf(level, mode);
  const kinds = [...new Set(v.marks.map(m => m.kind))];
  return (
    <div className="fig leaf leaf-hung">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the pull of the spring against its stretch, and a cube hung from it" viewBox={`0 0 ${F.w} ${F.h}`} className="leaf-pic" style={{ maxWidth: 470 }}
          data-space={st.space} data-weight={st.weight} data-falls={v.falls ? 'yes' : 'no'}>
          <defs><clipPath id="leaf-hung-plot"><rect x={F.x0 - 2} y={F.y0 - 2} width={r1(right - F.x0 + 4)} height={r1(bottom - F.y0 + 4)} /></clipPath></defs>
          {/* the axes: the pull across the top (the ceiling's level: no stretch), the stretch going down */}
          <line x1={F.x0} y1={F.y0} x2={r1(right)} y2={F.y0} className="ln-m" />
          <line x1={F.x0} y1={F.y0} x2={F.x0} y2={r1(bottom)} className="ln-m" />
          <text x={F.x0} y="18" className="lt-s t-muted">{`${L.AXIS.pull} →`}</text>
          {L.AXIS.ticks.map(([t, p]) => (
            <g key={t}>
              <line x1={r1(L.fx(p))} y1={F.y0 - 4} x2={r1(L.fx(p))} y2={F.y0 + 4} className="ln-m" />
              <text x={r1(L.fx(p))} y={F.y0 - 9} textAnchor="middle" className="lt-math">{t}</text>
            </g>
          ))}
          {L.AXIS.depth.map(d => (
            <g key={d}>
              <line x1={F.x0 - 4} y1={r1(L.fy(d))} x2={F.x0 + 4} y2={r1(L.fy(d))} className="ln-m" />
              <text x={F.x0 - 9} y={r1(L.fy(d) + 4.5)} textAnchor="end" className="lt-s t-muted">{d}</text>
            </g>
          ))}
          <text transform={`translate(18 ${r1(L.fy(1.6))}) rotate(90)`} textAnchor="middle" className="lt-s t-muted">{`${L.AXIS.stretch} →`}</text>
          {/* the pull of the three spaces, the chosen one strong */}
          <g clipPath="url(#leaf-hung-plot)">
            {L.SPACES.filter(s => s !== st.space).map(s => <path key={s} d={L.PULL_PATHS[s]} className="ln-l ln-round" style={{ strokeWidth: 2 }} data-pull={s} />)}
            <path d={L.PULL_PATHS[st.space]} className="ln ln-round" style={{ strokeWidth: 3.5 }} data-pull={st.space} />
          </g>
          {v.topLine ? <line x1={r1(v.topLine.x)} y1={F.y0} x2={r1(v.topLine.x)} y2={r1(v.topLine.y)} className="ln-m ln-dot" /> : null}
          {/* the weight */}
          <line x1={r1(v.wx)} y1={F.y0} x2={r1(v.wx)} y2={r1(bottom)} className="ln-m ln-dash" style={{ strokeWidth: 2 }} />
          <text x={r1(Math.min(Math.max(v.wx, F.x0 + 26), right - 26))} y={r1(bottom + 19)} textAnchor="middle" className="lt-s t-bold">{L.AXIS.weight}</text>
          {v.guide ? <line x1={r1(v.guide.x1)} y1={r1(v.guide.y)} x2={r1(v.guide.x2)} y2={r1(v.guide.y)} className="ln-l ln-dot" /> : null}
          {/* the ceiling, the spring and the cube */}
          <line x1={F.xc - F.ceil} y1={F.y0} x2={F.xc + F.ceil} y2={F.y0} className="ln ln-round" style={{ strokeWidth: 4 }} />
          {Array.from({ length: 8 }, (_, i) => { const x = F.xc - F.ceil + 6 + i * 10; return <line key={i} x1={x} y1={F.y0 - 3} x2={x + 7} y2={F.y0 - 11} className="ln-m" />; })}
          {v.spring ? <path d={v.spring} className={'ln ln-round' + (v.falls ? ' ln-dash' : '')} style={{ strokeWidth: 2.5 }} /> : null}
          <g opacity={v.falls ? 0.45 : 1} data-hook={r1(v.hookD * 100) / 100}>
            {v.cube.map(f => <polygon key={f.axis} points={f.pts} style={{ fill: 'var(--fg)', fillOpacity: L.FACE_SHADE[f.axis], stroke: 'var(--fg)', strokeWidth: 2, strokeLinejoin: 'round' }} />)}
            <circle cx={F.xc} cy={r1(v.hookY)} r="4" className="fill-ink" />
          </g>
          {v.falls ? (
            <g>
              <line x1={F.xc + 44} y1={r1(v.hookY + 6)} x2={F.xc + 44} y2={r1(v.hookY + 46)} className="ln" style={{ strokeWidth: 2.5 }} />
              <path d={arrowHead(F.xc + 44, v.hookY + 6, F.xc + 44, v.hookY + 54, 9)} className="fill-ink" />
              <text x={F.xc - 16} y={r1((F.y0 + v.hookY) / 2)} textAnchor="end" className="t-bold" style={HALO}>{L.AXIS.fall}</text>
            </g>
          ) : null}
          {/* the balances on the weight line, with the mark of their move */}
          {v.marks.map((m, i) => <g key={i} data-balance={m.kind} data-d={r1(m.d * 1000) / 1000}><MoveMark cls={CLS[m.kind]} x={m.x} y={m.y} s={7} label={false} on={i === 0 && m.kind === 'turn'} /></g>)}
          {v.marks.map((m, i) => <text key={'w' + i} x={r1(m.lx)} y={r1(m.ly)} className="t-bold" style={{ ...HALO, fill: 'var(--fg)' }}>{WORD[m.kind]}</text>)}
        </FigSvg>
        <div className="leaf-side">
          <p className="leaf-readout" aria-live="polite" data-rests={v.parts.map(p => (p.at === null ? 'none' : nf(p.at, 2))).join(',')}>
            {v.parts.map((p, i) => (
              <React.Fragment key={p.s}>
                {i ? <span className="muted">{' · '}</span> : null}
                <span className={p.on ? 't-bold' : 'muted'} style={p.on ? { fontWeight: 700 } : undefined}>{`${p.s} ${p.at === null ? 'no rest' : nf(p.at, 2) + (p.edge ? ' (only just)' : '')}`}</span>
              </React.Fragment>
            ))}
          </p>
          <p className="leaf-readout muted">{v.wText}</p>
          {kinds.length ? (
            <FigSvg id={ID} row={row} part={`the marks of the balances: ${kinds.map(k => WORD[k]).join(', ')}`} viewBox={`0 0 300 ${kinds.length * 30 + 6}`} style={{ maxWidth: 300 }}>
              {kinds.map((k, i) => (
                <g key={k}>
                  <MoveMark cls={CLS[k]} x={16} y={18 + 30 * i} s={7} label={false} />
                  <text x={38} y={23 + 30 * i} className="lt-s">{WORD[k]}</text>
                </g>
              ))}
            </FigSvg>
          ) : null}
        </div>
      </div>
      <Controls label="the space and the weight">
        <Chips label="space" items={L.SPACES} value={st.space} onPick={s => setSt(x => ({ ...x, space: s }))} render={s => L.NAMES[s]} param="space" />
        <Stepper label="weight" value={st.weight} min={0} max={L.W_MAX / L.W_STEP} onChange={w => setSt(x => ({ ...x, weight: w }))} display={w => `${nf(L.weightOf(w * L.W_STEP), 1)} k`} param="weight" />
      </Controls>
      {back === 'math' ? <LawBack L={L} wv={wv} space={st.space} row={row} /> : back === 'phys' ? <ValleyBack L={L} wv={wv} space={st.space} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say, geometry): a slice of each space through O and P — the line w = 1, the circle w² + x² = 1, the hyperbola w² − x² = 1 —
 *  with the point Q of each at its rest d_s along its curve; the size of the join of P and Q is how far Q stands from the line OP, so the three Q stand on one
 *  vertical line, where that size is m g / k (hung.logic.js lawView); on the sphere a weight above k leaves the circle short of the line */
function LawBack({ L, wv, space, row }) {
  const m = L.lawView(wv), A = L.MA;
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part="the three spaces in one slice, and the point of each at its rest" viewBox={`0 0 ${A.w} ${A.h}`} data-law={nf(m.size, 2)}>
        <defs><clipPath id="leaf-hung-slice"><rect x="0" y="0" width={A.w} height={A.h} /></clipPath></defs>
        <g clipPath="url(#leaf-hung-slice)">
          <line x1="0" y1={r1(L.my(0))} x2={A.w} y2={r1(L.my(0))} className="ln-l" />
          <line x1={r1(L.mx(0))} y1="0" x2={r1(L.mx(0))} y2={A.h} className="ln-m" />
          {L.SPACES.map(s => <path key={s} d={L.SLICE_PATHS[s]} className={s === space ? 'ln' : 'ln-m'} style={{ strokeWidth: s === space ? 2.4 : 1.6 }} data-curve={s} />)}
          {m.lineIn ? <line x1={r1(m.lineX)} y1="0" x2={r1(m.lineX)} y2={A.h} className="ln ln-dash" style={{ strokeWidth: 1.6 }} /> : null}
          {m.pts.filter(p => p.d !== null && p.d > 0).map(p => <path key={'a' + p.s} d={p.arc} className="ln ln-round" style={{ strokeWidth: p.s === space ? 4.5 : 2.5, opacity: p.s === space ? 1 : 0.55 }} data-arc={p.s} />)}
          {m.pts.filter(p => p.d !== null && p.inside).map(p => <line key={'h' + p.s} x1={r1(L.mx(0))} y1={r1(p.Y)} x2={r1(p.X)} y2={r1(p.Y)} className="ln-m ln-dot" />)}
          {m.pts.filter(p => p.d !== null && p.inside).map(p => <circle key={'q' + p.s} cx={r1(p.X)} cy={r1(p.Y)} r={p.s === space ? 7 : 5.5} className={p.s === space ? 'sel' : 'disc'} data-q={p.s} />)}
        </g>
        {L.SPACES.map(s => <text key={s} x={r1(L.SLICE_LABEL[s][0])} y={r1(L.SLICE_LABEL[s][1])} className="lt-s t-muted" style={HALO}>{s}</text>)}
        <circle cx={r1(L.mx(0))} cy={r1(L.my(0))} r="4" className="fill-ink" />
        <circle cx={r1(L.mx(0))} cy={r1(L.my(1))} r="6" className="disc-ink" />
        <text x={r1(L.mx(0) - 10)} y={r1(L.my(0) + 18)} textAnchor="end" className="lt-m lt-math" style={HALO}>O</text>
        <text x={r1(L.mx(0) - 10)} y={r1(L.my(1) - 8)} textAnchor="end" className="lt-m lt-math" style={HALO}>P</text>
        {m.lineIn ? <text x={r1(m.size > 1.4 ? m.lineX - 6 : m.lineX + 6)} y="20" textAnchor={m.size > 1.4 ? 'end' : 'start'} className="lt-math" style={HALO}>{'m g / k'}</text> : null}
      </FigSvg>
      <p className="leaf-readout" data-sizes={m.pts.map(p => (p.d === null ? 'none' : nf(p.size, 2))).join(',')}>
        {m.pts.map((p, i) => `${i ? ' · ' : ''}${p.s} ${p.d === null ? 'no rest' : `${L.FORM[p.s]} = ${nf(p.size, 2)} at d = ${nf(p.d, 2)}`}`).join('')}
      </p>
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): the energy of spring and weight against the stretch (hung.logic.js valley: Simpson's rule on the pull, zero at no
 *  stretch), the chosen space strong; its balances with the marks of their moves; a ball nudged a quarter of a unit away from each balance, with the push of
 *  the slope (physView); the curvature V″ of each valley floor as a readout */
function ValleyBack({ L, wv, space, row }) {
  const P = L.PE, vals = L.SPACES.map(s => L.valley(s, wv)), own = vals.find(x => x.space === space);
  // the frame: from the lowest point of the curve to the highest balance (or no stretch), with a margin; the steep rest of the curve is clipped
  const tops = [0, ...own.bal.map(b => L.energy(space, L.K, own.mg, b.d) / L.K)], vmax = Math.max(...tops), rng = Math.max(0.3, vmax - own.lo);
  const hi = vmax + 0.35 * rng, lo = own.lo - 0.15 * rng, H = P.h - 42 - P.top, S = H / (hi - lo);
  const X = d => P.x0 + P.u * d, Y = e => P.top + (hi - e) * S;
  const toPath = pts => pts.map(([d, e], i) => `${i ? 'L' : 'M'}${r1(X(d))} ${r1(Y(e))}`).join(' ');
  // the ball at the rest is nudged toward less stretch (more when the rest is near zero or only just holds), the one on the hilltop toward more (less near
  // the far point π): the two stay apart, and each nudge stays on the stretches 0 … π
  const rest = own.bal[0] || null, top = own.bal[1] || null;
  const valleyBall = rest ? L.physView(space, rest.kind !== 'slide' && rest.d >= 0.25 ? -5 : 5, wv).valley : null;
  const hillBall = top ? L.physView(space, top.d + 0.25 <= Math.PI ? 5 : -5, wv).hill : null;
  const balls = [valleyBall, hillBall].filter(Boolean);
  const pv = L.physView(space, 0, wv);
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="the energy of the spring and the weight against the stretch" viewBox={`0 0 ${P.w} ${P.h}`} data-floor={pv.floor.map(f => (f.c === null ? 'none' : nf(f.c, 2))).join(',')}>
        <defs><clipPath id="leaf-hung-energy"><rect x={P.x0} y="8" width={P.w - P.x0 - 4} height={P.h - 46} /></clipPath></defs>
        <line x1={P.x0} y1={r1(Y(0))} x2={P.w - 6} y2={r1(Y(0))} className="ln-l" />
        <line x1={P.x0} y1="10" x2={P.x0} y2={P.h - 40} className="ln-m" />
        <text x={P.x0 + 8} y="22" className="lt-s t-muted">energy</text>
        {[0, 1, 2, 3].map(t => <line key={t} x1={r1(X(t))} y1={P.h - 40} x2={r1(X(t))} y2={P.h - 33} className="ln-m" />)}
        {[0, 1, 2].map(t => <text key={t} x={r1(X(t))} y={P.h - 14} textAnchor="middle" className="lt-s t-muted">{t}</text>)}
        <text x={P.w - 8} y={P.h - 14} textAnchor="end" className="lt-s t-muted">stretch →</text>
        <g clipPath="url(#leaf-hung-energy)">
          {vals.filter(x => x.space !== space).map(x => <path key={x.space} d={toPath(x.pts)} className="ln-l ln-round" style={{ strokeWidth: 2 }} />)}
          <path d={toPath(own.pts)} className="ln ln-round" style={{ strokeWidth: 3.5 }} data-energy={space} />
        </g>
        {own.bal.map((b, i) => <g key={'m' + i} data-balance={b.kind}><MoveMark cls={CLS[b.kind]} x={X(b.d)} y={Y(L.energy(space, L.K, own.mg, b.d) / L.K)} s={5.5} label={false} /></g>)}
        {balls.map((b, i) => {
          const tx = P.u, ty = -S * b.slope, n = Math.hypot(tx, ty) || 1, ux = tx / n, uy = ty / n, cx = X(b.d) + L.BALL_R * uy, cy = Y(b.v) - L.BALL_R * ux;
          const len = b.push ? 34 : 0, ax = b.push * ux, ay = b.push * uy, r0 = L.BALL_R + 4;
          return (
            <g key={'b' + i} data-fate={L.fate(b)}>
              {b.push ? <line x1={r1(cx + ax * r0)} y1={r1(cy + ay * r0)} x2={r1(cx + ax * (r0 + len))} y2={r1(cy + ay * (r0 + len))} className="ln" style={{ strokeWidth: 2.5 }} /> : null}
              {b.push ? <path d={arrowHead(cx + ax * r0, cy + ay * r0, cx + ax * (r0 + len + 6), cy + ay * (r0 + len + 6), 8)} className="fill-ink" /> : null}
              <circle cx={r1(cx)} cy={r1(cy)} r={L.BALL_R} className="disc" style={{ strokeWidth: 2.2 }} />
              <text x={r1(Math.min(P.w - 50, Math.max(P.x0 + 50, cx)))} y={r1(cy - L.BALL_R - 10)} textAnchor="middle" className="lt-s t-bold" style={HALO}>{L.fate(b)}</text>
            </g>
          );
        })}
      </FigSvg>
      <p className="leaf-readout">{`${pv.form} · ${L.weightOf(wv) ? 'm g = ' + nf(L.weightOf(wv), 2) + ' k' : 'no weight'}`}</p>
      <p className="leaf-readout muted">{`V″ at the rest: ${pv.floor.map(f => `${f.s} ${f.c === null ? '—' : nf(f.c, 2) + ' k'}`).join(' · ')}`}</p>
    </Back>
  );
}

LeafHung.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the space, the weight in tenths of k, the rest of each space (null: none), the balances of the chosen space and their moves */
LeafHung.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const st = startOf(L, params), v = L.seeView(st.space, st.weight * L.W_STEP);
  return { space: st.space, weight: st.weight, mg: v.mg, rests: Object.fromEntries(v.parts.map(p => [p.s, p.at])), balances: v.bal.map(b => ({ d: b.d, kind: b.kind })), falls: v.falls };
};
LeafHung.ready = () => !!logicOf(SLUG, NEEDS);
