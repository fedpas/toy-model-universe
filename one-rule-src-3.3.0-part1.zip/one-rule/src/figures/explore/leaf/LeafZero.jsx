// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-zero (Explore, leaf 5): the front of the Octavo leaf "zero" redrawn with the V2 kit. Three switches, each squaring to +1, −1 or 0, and the cube of
// their eight corners (engines/explore/leaves/zero.logic.js front: the corners with their names e₁₃ …, which ones hold a zero switch, the edges along each
// switch, the product of the two corners in the tray by the kernel's bladeMul, a sign or 0). A corner that holds a zero switch is drawn dashed, the edges of a
// zero switch dashed; the two factors wear the selection, the product a thick ring. Controls (ports of the Octavo face): the three switches (a tap turns + into
// −, − into 0, 0 into +), a tap on a corner (the first factor, then the second: tapCorner), and the two factor buttons a and b of the readout, which say which
// factor the next tap on a corner replaces. Readouts: the product a × b as names and a sign, the zero switches and the number of dashed corners. At
// research level in mode math, the back of the Octavo leaf: the corners of Cl(p,q,r) of these three switches in layers by their zero switches (layerView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, backOf, Back } from './leafKit.jsx';

const SLUG = 'zero', ID = 'leaf-zero';
const NEEDS = ['START', 'N', 'BOX', 'front', 'tapSwitch', 'tapCorner', 'nameOf', 'canLayers', 'layerView', 'TOWER'];
const okEps = e => Array.isArray(e) && e.length === 3 && e.every(x => x === 1 || x === -1 || x === 0);
const okCorner = c => Number.isInteger(c) && c >= 0 && c < 8;
function startOf(L, params) {
  const eps = okEps(params.eps) ? params.eps.slice() : L.START.eps.slice();
  const a = okCorner(params.a) ? params.a : L.START.tray[0], b = okCorner(params.b) ? params.b : L.START.tray[1];
  return { ...L.START, eps, tray: [a, b] };
}

export default function LeafZero(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Zero L={L} {...props} />;
}

function Zero({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [JSON.stringify(params.eps), params.a, params.b]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.front(s), next = s.tray.length === 1 ? 'b' : 'a', W = L.BOX.w, H = L.BOX.h, pw = 54, ph = 40;
  const pr = v.product, [a, b] = s.tray;
  const result = pr ? (pr.s === 0 ? (research ? '0' : 'nothing') : (pr.s < 0 ? '−' : '') + L.nameOf(pr.c)) : '…';
  const zs = v.switches.filter(w => w.e === 0).map(w => w.name);
  return (
    <div className="fig leaf leaf-zero">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the cube of three switches" viewBox={`0 0 ${W} ${H}`} className="leaf-pic leaf-w400">
          {v.edges.map((e, i) => <line key={i} x1={r1(e.x1)} y1={r1(e.y1)} x2={r1(e.x2)} y2={r1(e.y2)} className={e.zero ? 'ln ln-dash' : 'ln-l'} style={{ strokeWidth: e.zero ? 2.2 : 2 }} data-edge={e.i} data-zero={e.zero ? 1 : 0} />)}
          {v.corners.map(c => (
            <g key={c.c} {...pickProps(next, `corner ${L.nameOf(c.c)}${c.zero ? ', holds a zero switch' : ''}`, c.picked, () => setS(L.tapCorner(s, c.c)))} data-corner={c.c} data-zero={c.zero ? 1 : 0}>
              <rect x={r1(c.x - pw / 2)} y={r1(c.y - ph / 2)} width={pw} height={ph} rx={ph / 2} className="pick-ring" style={{ ...(c.picked ? {} : { fill: c.zero ? 'var(--bg)' : 'var(--panel)' }), strokeDasharray: c.zero ? '5 4' : undefined }} />
              {c.result ? <rect x={r1(c.x - pw / 2 - 5)} y={r1(c.y - ph / 2 - 5)} width={pw + 10} height={ph + 10} rx={ph / 2 + 5} className="ln" style={{ strokeWidth: 3 }} /> : null}
              <text x={r1(c.x)} y={r1(c.y)} textAnchor="middle" className="lt-l lt-mid lt-math">{c.name}</text>
            </g>
          ))}
        </FigSvg>
        <div className="leaf-side">
          <p className="leaf-readout leaf-readout-big" aria-live="polite" data-a={a ?? ''} data-b={b ?? ''} data-product={pr ? `${pr.s},${pr.c}` : ''}>
            <button type="button" className={'fig-btn' + (next === 'a' ? ' leaf-next' : '')} data-param="a" aria-label="the first factor: the next tap on a corner replaces it" onClick={() => setS({ ...s, tray: [] })}>{a === undefined ? '…' : L.nameOf(a)}</button>
            {' × '}
            <button type="button" className={'fig-btn' + (next === 'b' ? ' leaf-next' : '')} data-param="b" aria-label="the second factor: the next tap on a corner replaces it" onClick={() => setS({ ...s, tray: a === undefined ? [] : [a] })}>{b === undefined ? '…' : L.nameOf(b)}</button>
            {` = ${result}`}
          </p>
          <p className="leaf-readout muted" data-zero-switches={v.r} data-dashed={v.held}>
            {research
              ? `zero switches: ${zs.length ? zs.join(', ') : 'none'} · dashed corners: ${v.held}`
              : `zero: ${zs.length ? zs.join(', ') : 'none'} · dashed: ${v.held}`}
          </p>
        </div>
      </div>
      <Controls label="the three switches">
        <span className="fig-group-label">{research ? 'squares' : 'each switch squared'}</span>
        {v.switches.map(w => (
          <button key={w.i} type="button" className={'fig-btn leaf-switch' + (w.e === 0 ? ' is-zero' : '')} data-param="eps" aria-label={`switch ${L.nameOf(1 << w.i)} squares to ${w.sq}; change it`} onClick={() => setS(L.tapSwitch(s, w.i))}>
            <span className="leaf-switch-name">{w.name}</span><span className="fig-mono leaf-switch-sq">{w.sq}</span>
          </button>
        ))}
      </Controls>
      {backOf(level, mode) === 'math' ? <LayersBack L={L} eps={s.eps} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the corners of the cell of the three switches, Cl(p,q,r) with p, q, r their numbers of squares +1, −1 and 0, stacked
 *  by how many zero switches they hold (zero.logic.js layerView: the layers, their counts, TOWER); a dot of a layer with a zero switch is dashed */
function LayersBack({ L, eps, row }) {
  const p = eps.filter(e => e === 1).length, q = eps.filter(e => e === -1).length, r = eps.filter(e => e === 0).length;
  if (!L.canLayers(p, q, r)) return null;
  const lv = L.layerView(p, q, r), T = L.TOWER;
  return (
    <Back who="math" way="algebra">
      <FigSvg id={ID} row={row} part="the corners in layers by their zero switches" viewBox={`0 0 ${T.w} ${r1(lv.h)}`}>
        {lv.rows.map(rw => (
          <g key={rw.k} data-layer={rw.k} data-count={rw.count}>
            <rect x={r1(rw.band.x)} y={r1(rw.band.y)} width={r1(rw.band.w)} height={r1(rw.band.h)} rx="10" className="fill-panel" style={{ stroke: 'var(--line)' }} />
            <text x="6" y={r1(rw.mid)} className="lt-s lt-mid t-muted">{`k = ${rw.k}`}</text>
            <text x={T.w - 6} y={r1(rw.mid)} textAnchor="end" className="lt-m lt-mid t-bold">{rw.count}</text>
            {rw.dots.map(d => <circle key={d.c} cx={r1(d.x)} cy={r1(d.y)} r={T.dot} className={rw.zero ? 'disc-dash' : 'fill-ink'} />)}
          </g>
        ))}
      </FigSvg>
      <p className="leaf-readout" data-layers={lv.counts.join(',')}>{`Cl(${p},${q},${r}) · corners by zero switches: ${lv.counts.join(' · ')} · ${lv.total} in all`}</p>
    </Back>
  );
}

LeafZero.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the squares, the corners that hold a zero switch, the product of the pair (zero.logic.js front) */
LeafZero.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.front(s);
  return { eps: s.eps, pair: s.tray, product: v.product, zeroCorners: v.corners.filter(c => c.zero).map(c => c.c), dashed: v.held };
};
LeafZero.ready = () => !!logicOf(SLUG, NEEDS);
