// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-springs (Explore, shelf, under leaf 2): the front of the Octavo leaf "springs" redrawn with the V2 kit. Unit masses on the eight corners of the
// cube of three switches and unit springs on its twelve edges; each mass moves up and down (engines/explore/leaves/springs.logic.js frontView: the motion
// x'' = −Lx solved through the labels, a label's pattern of signs, the coils of the springs, the energy in the springs and in the motion). A mass marked +
// is filled, one marked − a ring; a plucked corner wears the selection. Under the cube the energy as a bar: the springs' part solid, the motion's hatched.
// Controls (ports of the Octavo face): the chips of the eight labels 000 … 111 grouped by their number of 1s (pickLabel), the toggle "pluck a corner", a tap
// on a corner (pluckAt) and Play (paused at first). Readouts: the label, ω² (omega2), the speed (speedShort) and the energy, as the logic gives them. At
// research level in mode math, the back of the Octavo leaf: the labels stacked by their number of 1s at ω², and the eigenvalues of nI − A (mathView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Toggle, PlayButton, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, useTicker, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'springs', ID = 'leaf-springs';
const NEEDS = ['START', 'N', 'VIEW', 'SPEED', 'frontView', 'pickLabel', 'pluckAt', 'advance', 'omega2', 'speedShort', 'bits', 'mathView', 'MATH'];
const okC = c => Number.isInteger(c) && c >= 0 && c < 8;
function startOf(L, params) {
  let st = L.START;
  if (okC(params.label)) st = L.pickLabel(st, params.label);
  if (okC(params.corner)) st = { ...st, v: params.corner };
  if (params.pluck === true) st = L.pluckAt(st, st.v);
  return st;
}

export default function LeafSprings(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Springs L={L} {...props} />;
}

function Springs({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [st, setSt] = useState(() => startOf(L, params));
  useEffect(() => { setSt(startOf(L, params)); }, [params.label, params.corner, params.pluck]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = useTicker(dt => setSt(x => L.advance(x, dt * L.SPEED)), 0.2);
  const v = L.frontView(st), E = v.energy, pluck = st.view === 'pluck', w2 = L.omega2(st.s), BW = 276;
  return (
    <div className="fig leaf leaf-springs">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="a cube of springs" viewBox={`0 0 ${L.VIEW.w} ${L.VIEW.h}`} className="leaf-pic" style={{ maxWidth: 420 }}>
          {v.corners.map(c => (
            <g key={'r' + c.c}>
              <line x1={r1(c.rx)} y1={r1(c.ry - 40)} x2={r1(c.rx)} y2={r1(c.ry + 30)} className="ln-l ln-dot" />
              <line x1={r1(c.rx - 9)} y1={r1(c.ry)} x2={r1(c.rx + 9)} y2={r1(c.ry)} className="ln-m" style={{ strokeWidth: 2 }} />
            </g>
          ))}
          {v.lines.map(l => <polyline key={l.a + '-' + l.b} points={l.pts} className="ln-m ln-round" style={{ strokeWidth: l.depth === 2 ? 1.6 : 2.1, opacity: l.depth === 2 ? 0.55 : l.depth === 1 ? 0.8 : 1 }} />)}
          {v.order.map(c => (
            <g key={c.c} {...pickProps('corner', `pluck the corner ${L.bits(c.c, L.N)}`, c.plucked, () => setSt(x => L.pluckAt(x, c.c)))} data-corner={c.c} data-sign={c.mark}>
              <circle cx={r1(c.cx)} cy={r1(c.cy)} r={c.r + 8} className="pick-hit" />
              {c.plucked ? <circle cx={r1(c.cx)} cy={r1(c.cy)} r={c.r + 6} className="sel" /> : null}
              <circle cx={r1(c.cx)} cy={r1(c.cy)} r={c.r} className={c.plus ? 'disc-ink' : 'disc'} style={{ strokeWidth: c.plucked ? 3 : 2 }} />
              {c.mark ? <text x={r1(c.cx)} y={r1(c.cy)} textAnchor="middle" className={(c.back ? 'lt-m' : 'lt-l') + ' lt-mid t-bold'} style={c.plus ? { fill: 'var(--panel)' } : undefined}>{c.mark}</text> : null}
            </g>
          ))}
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="the energy in the springs and in the motion" viewBox="0 0 300 78">
            <defs>
              <pattern id="leaf-springs-hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="6" className="ln" style={{ strokeWidth: 2 }} />
              </pattern>
              <clipPath id="leaf-springs-bar"><rect x="12" y="26" width={BW} height="18" rx="9" /></clipPath>
            </defs>
            <text x="12" y="16" className="lt-s t-bold">energy</text>
            <text x="288" y="16" textAnchor="end" className="t-mono lt-s" data-energy={E.total}>{nf(E.total, 2)}</text>
            <rect x="12" y="26" width={BW} height="18" rx="9" className="fill-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} />
            <g clipPath="url(#leaf-springs-bar)">
              {E.springs > 0 ? <rect x="12" y="26" width={r1(BW * E.springs)} height="18" className="fill-muted" data-share-springs={E.springs} /> : null}
              {E.motion > 0 ? <rect x={r1(12 + BW * E.springs)} y="26" width={r1(BW * E.motion)} height="18" style={{ fill: 'url(#leaf-springs-hatch)' }} data-share-motion={E.motion} /> : null}
            </g>
            <rect x="12" y="26" width={BW} height="18" rx="9" className="ln" />
            <rect x="12" y="56" width="14" height="14" rx="3" className="fill-muted" />
            <text x="32" y="67" className="lt-s t-muted">springs</text>
            <rect x="150" y="56" width="14" height="14" rx="3" style={{ fill: 'url(#leaf-springs-hatch)', stroke: 'var(--fg)' }} />
            <text x="170" y="67" className="lt-s t-muted">motion</text>
          </FigSvg>
          <p className="leaf-readout" aria-live={player.playing ? 'off' : 'polite'} data-view={st.view} data-label={st.s} data-corner={st.v} data-omega2={w2}>
            {pluck
              ? `corner ${L.bits(st.v, L.N)} plucked`
              : (research ? `label ${L.bits(st.s, L.N)} · ω² = ${w2}` : `label ${L.bits(st.s, L.N)} · speed ${L.speedShort(w2)}`)}
          </p>
          {research ? <p className="leaf-readout muted">{`springs ${Math.round(100 * E.springs)}% · motion ${Math.round(100 * E.motion)}%`}</p> : null}
        </div>
      </div>
      <Controls label="the labels">
        <span className="fig-group" role="group" aria-label="the eight labels" data-param="label">
          {v.groups.map(g => (
            <React.Fragment key={g.j}>
              <span className="fig-group-label" data-level={g.j}>{g.caption}</span>
              {g.chips.map(ch => <button key={ch.s} type="button" className="fig-btn fig-mono" data-param="label" aria-pressed={!!ch.on} aria-label={`label ${ch.text}`} onClick={() => setSt(x => L.pickLabel(x, ch.s))}>{ch.text}</button>)}
            </React.Fragment>
          ))}
        </span>
      </Controls>
      <Controls label="the motion">
        <Toggle label="pluck a corner" on={pluck} onChange={on => setSt(x => (on ? L.pluckAt(x, x.v) : L.pickLabel(x, x.s)))} param="pluck" />
        <PlayButton player={player} />
      </Controls>
      {backOf(level, mode) === 'math' ? <LevelsBack L={L} label={pluck ? null : st.s} row={row} /> : null}
    </div>
  );
}

const eig = x => (Math.abs(x - Math.round(x)) < 1e-9 ? String(Math.round(x) + 0) : nf(x, 2));
/** the Mathematician's back (Octavo's Say): the eight labels of the cube stacked by their number of 1s at their ω², and the eigenvalues of nI − A computed
 *  from the matrix itself (springs.logic.js mathView(N): levels, MATH, eigenvalues by Jacobi rotations); the label of the front wears the selection */
function LevelsBack({ L, label, row }) {
  const m = L.mathView(L.N), M = L.MATH, top = Math.max(0, Math.floor(m.top));
  return (
    <Back who="math" way="counting">
      <FigSvg id={ID} row={row} part="the labels by their number of 1s" viewBox={`0 ${top} ${M.w} ${M.h + 22 - top}`}>
        <line x1={M.x0 - 24} y1={M.base} x2={M.x1 + 24} y2={M.base} className="ln" />
        {m.cols.map(c => (
          <g key={c.j} data-level={c.j} data-count={c.count} data-w2={c.w2}>
            <text x={r1(c.x)} y={r1(c.countY)} textAnchor="middle" className="t-mono lt-m t-bold">{c.count}</text>
            {c.boxes.map(b => (
              <g key={b.s} data-label={b.s}>
                <rect x={r1(b.x)} y={r1(b.y)} width={r1(b.w)} height={r1(b.h)} rx="5" className={b.s === label ? 'sel' : 'disc'} style={{ strokeWidth: 1.4 }} />
                <text x={r1(b.x + b.w / 2)} y={r1(b.y + b.h / 2)} textAnchor="middle" className="t-mono lt-s lt-mid">{b.text}</text>
              </g>
            ))}
            <line x1={r1(c.x)} y1={M.base} x2={r1(c.x)} y2={M.base + 6} className="ln" />
            <text x={r1(c.x)} y={M.base + 22} textAnchor="middle" className="t-mono lt-s t-muted">{`ω² = ${c.w2}`}</text>
          </g>
        ))}
      </FigSvg>
      <p className="leaf-readout" data-eigenvalues={m.ev.map(eig).join(',')}>{`eigenvalues of ${L.N}I − A: ${m.ev.map(eig).join(', ')} · labels by their 1s: ${m.cols.map(c => c.count).join(' · ')}`}</p>
    </Back>
  );
}

LeafSprings.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the label or the plucked corner, ω² of the label, the corners' signs and the energy at t = 0 (springs.logic.js frontView) */
LeafSprings.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const st = startOf(L, params), v = L.frontView(st);
  return { view: st.view, label: st.s, corner: st.v, omega2: L.omega2(st.s), signs: v.corners.map(c => c.mark), energy: v.energy };
};
LeafSprings.ready = () => !!logicOf(SLUG, NEEDS);
