// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-half-turns (leaf 4, half-turns; the top of steps/spin): the front of the Octavo leaf redrawn with the V2 kit. Two dials side by side: the arrow,
// turned by φ with the coil of its trail, and the spinor, the rotor R = cos(φ/2) + sin(φ/2) B as a point of its circle that moves at half the speed, from
// engines/explore/leaves/half-turns.logic.js (frontView: every point through the kernel). The spinor's sign is told by its disc — filled on the side of +1,
// open on the side of −1, half filled exactly halfway — and by the values under the picture, never by colour alone; the trails wear the colour of a turn.
// Controls: the chips of the turn, every quarter turn from 0° to 720° (Octavo's slider ran from 0 to 720 by 5), and Play (paused at first; under reduced
// motion Step goes from chip to chip); the turn rests at 360° and at 720° as Octavo's did. At research level the back of the Octavo leaf for the mode:
// the mathematician's square of pairs (where the arrow points, where the rotor is; opposite edges glued) with the lifted path, R and −R and the laps
// (torusView), or the physicist's two halves of a wave in the rotor model, one turned by φ, their sum 1 + R and |1 + R|² against the turn (glowView).
// Every name in the drawings is placed by halfTurnsLabels.js, off the lines; every value is the logic's.
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, PlayButton } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, useTicker, nf, backOf, Back } from './leafKit.jsx';
import { FRONT_SIZE, TAG_SIZE, homeLabel, homeLine, torusTags, glowLabels } from './halfTurnsLabels.js';

const SLUG = 'half-turns', ID = 'leaf-half-turns';
const NEEDS = ['CHIPS', 'STILL', 'MAX', 'DIAL', 'SQUARE', 'PH', 'PLOT', 'EPS', 'GRAPH', 'GLOW_PATH', 'ENDS', 'ACROSS_TICKS', 'frontView', 'torusView', 'glowView',
  'advance', 'setTurn', 'stepOn', 'markText', 'lapsText', 'degText', 'glowText', 'glow', 'rotor', 'bPart', 'toXY'];
const phiOf = (L, params) => (L.CHIPS.includes(params.phi) ? params.phi : L.STILL.phi);
const startOf = (L, params) => L.setTurn(phiOf(L, params));
const signText = s => (s > 0 ? '+1' : '−1');
/** a readout: its items joined by " · ", each item kept on one line (no-break spaces inside it), so that a phone breaks the line between items only */
const readoutOf = items => items.filter(Boolean).map(t => t.replace(/ /g, '\u00a0')).join(' · ');
/** a name in a drawing: its size in picture units, the math face for symbols, the muted ink for axes (figures.css sets the type of every <text>, so the
 *  style sits on the element itself) */
function Txt({ x, y, size, anchor, math = false, muted = false, weight, color, children }) {
  return <text x={x} y={y} textAnchor={anchor} style={{ fontSize: `${size}px`, fill: color || (muted ? 'var(--muted)' : 'var(--fg)'), fontFamily: math ? 'var(--font-math)' : 'var(--font-body)', ...(weight ? { fontWeight: weight } : {}) }}>{children}</text>;
}

export default function LeafHalfTurns(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <HalfTurns L={L} {...props} />;
}

/** the spinor's disc: filled on the side of +1, open on the side of −1, its right half filled when it stands exactly halfway */
function Disc({ x, y, side, r = 11 }) {
  if (side !== 0) return <circle cx={x} cy={y} r={r} strokeWidth="3" style={{ fill: side > 0 ? 'var(--fg)' : 'var(--panel)', stroke: 'var(--fg)' }} data-side={side} />;
  return (
    <g data-side="0">
      <circle cx={x} cy={y} r={r} strokeWidth="3" style={{ fill: 'var(--panel)', stroke: 'var(--fg)' }} />
      <path d={`M${x} ${y - r} A ${r} ${r} 0 0 1 ${x} ${y + r} Z`} style={{ fill: 'var(--fg)' }} />
    </g>
  );
}
/** an arrow: the shaft stops under the head (arrowHead of the logic); an arrow too short for a head is a plain line */
function Arrow({ from, to, head, width, color }) {
  return (
    <g>
      <line x1={from.x} y1={from.y} x2={head ? head.stop.x : to.x} y2={head ? head.stop.y : to.y} strokeWidth={width} strokeLinecap="round" style={{ stroke: color }} />
      {head ? <polygon points={head.pts} strokeLinejoin="round" strokeWidth="1.5" style={{ fill: color, stroke: color }} /> : null}
    </g>
  );
}

function HalfTurns({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.phi]);   // eslint-disable-line react-hooks/exhaustive-deps
  const ticker = useTicker(dt => setS(x => L.advance(x, dt)));
  const player = { ...ticker, step: () => setS(x => L.stepOn(x)) };
  const v = L.frontView(s.phi), D = L.DIAL, H = homeLabel(L), hl = homeLine(L);
  const onChip = L.CHIPS.includes(v.d) && Math.abs(s.phi - v.d) < 1e-9 ? v.d : null;
  const Rd = L.rotor(v.d), a = Rd[0], b = L.bPart(Rd);
  const rText = v.home ? signText(v.says) : `${nf(a, 2)} ${b < 0 ? '−' : '+'} ${Math.abs(b).toFixed(2)} B`;
  const readout = research
    ? readoutOf([`φ = ${v.d}°`, `arrow ${L.degText(v.arrowDeg)}°`, `spinor ${L.degText(v.rotorDeg)}°`, `R = ${rText}`])
    : readoutOf([`turned ${v.d}°`, v.home ? 'arrow home' : `arrow at ${L.degText(v.arrowDeg)}°`, v.home ? `spinor ${signText(v.says)}` : `spinor at ${L.degText(v.rotorDeg)}°`]);
  const back = backOf(level, mode);
  return (
    <div className="fig leaf leaf-half-turns">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the arrow and the spinor" viewBox="0 0 500 278" className="leaf-pic">
          <Txt x={D.ax} y="28" size={FRONT_SIZE.title} anchor="middle" weight={600}>arrow</Txt>
          <Txt x={D.sx} y="28" size={FRONT_SIZE.title} anchor="middle" weight={600}>spinor</Txt>
          <circle cx={D.ax} cy={D.cy} r={D.r} fill="none" strokeWidth="2" style={{ stroke: 'var(--line-2)' }} />
          <line x1={hl.x1} y1={hl.y} x2={hl.x2} y2={hl.y} strokeWidth="2" strokeDasharray="5 5" style={{ stroke: 'var(--muted)' }} />
          <Txt x={H.x} y={H.y} size={H.size} muted>home</Txt>
          <path d={v.trail} fill="none" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" style={{ stroke: 'var(--turn)' }} />
          <Arrow from={{ x: D.ax, y: D.cy }} to={v.tip} head={v.head} width="6" color="var(--fg)" />
          <circle cx={D.ax} cy={D.cy} r="6" style={{ fill: 'var(--fg)' }} />
          <circle cx={D.sx} cy={D.cy} r={D.r} fill="none" strokeWidth="2" style={{ stroke: 'var(--line-2)' }} />
          <path d={v.arc} fill="none" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" opacity="0.6" style={{ stroke: 'var(--turn)' }} />
          <g strokeWidth="3" style={{ stroke: 'var(--fg)' }}>
            <line x1={D.sx + D.r - 10} y1={D.cy} x2={D.sx + D.r + 10} y2={D.cy} />
            <line x1={D.sx - D.r - 10} y1={D.cy} x2={D.sx - D.r + 10} y2={D.cy} />
          </g>
          <Txt x={D.sx + D.r - 20} y={D.cy + 8} size={FRONT_SIZE.mark} anchor="end" math>{L.markText(0)}</Txt>
          <Txt x={D.sx - D.r + 20} y={D.cy + 8} size={FRONT_SIZE.mark} math>{L.markText(180)}</Txt>
          <Disc x={v.spot.x} y={v.spot.y} side={v.side} />
        </FigSvg>
      </div>
      <p className="leaf-readout" aria-live="polite" data-phi={v.d} data-home={v.home ? 1 : 0} data-says={v.says}>{readout}</p>
      <Controls label="the turn">
        <Chips label="turned" items={L.CHIPS} value={onChip} onPick={d => { ticker.stop(); setS(L.setTurn(d)); }} render={d => `${d}°`} param="phi" mono />
        <PlayButton player={player} />
      </Controls>
      {back === 'math' ? <SquareBack L={L} phi={s.phi} row={row} /> : back === 'phys' ? <HalvesBack L={L} phi={s.phi} row={row} /> : null}
    </div>
  );
}

/** the mathematician's back (Octavo's Say, topology): the square of pairs (across, where the arrow points; up, where the rotor is), opposite edges glued;
 *  the line of all pairs (dashed), the path lifted from (0°, +1) up to this turn, R and −R over the same turn, and the laps of the arrow and the rotor */
function SquareBack({ L, phi, row }) {
  const tv = L.torusView(phi), S = L.SQUARE, tags = torusTags(L, tv);
  const X0 = S.x, X1 = S.x + S.s, Y0 = S.y, Y1 = S.y + S.s, XM = (X0 + X1) / 2, YM = (Y0 + Y1) / 2;
  const line = readoutOf([`arrow ${L.lapsText(tv.arrowLaps)}`, `rotor ${L.lapsText(tv.rotorLaps)}`, tv.home ? `R = ${signText(tv.says)}` : null]);
  return (
    <Back who="math" way="topology">
      <FigSvg id={ID} row={row} part="the square of pairs, its edges glued" viewBox="0 0 380 350">
        <rect x="0.5" y="0.5" width="379" height="349" rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        <rect x={X0} y={Y0} width={S.s} height={S.s} fill="none" strokeWidth="1.5" style={{ stroke: 'var(--muted)' }} />
        <g fill="none" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ stroke: 'var(--muted)' }}>
          <path d={`M${X0 - 7} ${Y1 - 58} L${X0} ${Y1 - 66} L${X0 + 7} ${Y1 - 58} M${X1 - 7} ${Y1 - 58} L${X1} ${Y1 - 66} L${X1 + 7} ${Y1 - 58}`} />
          <path d={`M${XM - 8} ${Y0 - 7} L${XM} ${Y0} L${XM - 8} ${Y0 + 7} M${XM + 2} ${Y0 - 7} L${XM + 10} ${Y0} L${XM + 2} ${Y0 + 7} M${XM - 8} ${Y1 - 7} L${XM} ${Y1} L${XM - 8} ${Y1 + 7} M${XM + 2} ${Y1 - 7} L${XM + 10} ${Y1} L${XM + 2} ${Y1 + 7}`} />
        </g>
        <Txt x={X0 - 12} y={Y1 + 6} size={17} anchor="end" math>{L.markText(0)}</Txt>
        <Txt x={X0 - 12} y={YM + 6} size={17} anchor="end" math>{L.markText(180)}</Txt>
        <Txt x={X0 - 12} y={Y0 + 6} size={17} anchor="end" math>{L.markText(360)}</Txt>
        {L.ACROSS_TICKS.map((t, i) => <Txt key={t} x={[X0, XM, X1][i]} y={Y1 + 24} size={14} anchor="middle" muted>{t}</Txt>)}
        <Txt x={XM} y={Y1 + 45} size={14} anchor="middle" muted>where the arrow points</Txt>
        <Txt x={X0 - 12} y={Y0 - 16} size={14} anchor="end" muted>rotor</Txt>
        <path d={L.GRAPH} fill="none" strokeWidth="2" strokeDasharray="4 5" style={{ stroke: 'var(--muted)' }} />
        <line x1={tv.p.x} y1={Y0} x2={tv.p.x} y2={Y1} strokeWidth="1.5" style={{ stroke: 'var(--line-2)' }} />
        <path d={tv.path} fill="none" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" style={{ stroke: 'var(--turn)' }} />
        <circle cx={tv.o.x} cy={tv.o.y} r="8" strokeWidth="2.5" style={{ fill: 'var(--panel)', stroke: 'var(--fg)' }} />
        <circle cx={tv.p.x} cy={tv.p.y} r="9" strokeWidth="2.5" style={{ fill: 'var(--fg)', stroke: 'var(--fg)' }} />
        <Txt x={tags.R.x} y={tags.R.y} size={TAG_SIZE} anchor={tags.R.anchor} math>R</Txt>
        <Txt x={tags.mR.x} y={tags.mR.y} size={TAG_SIZE} anchor={tags.mR.anchor} math>−R</Txt>
      </FigSvg>
      <p className="leaf-readout" data-arrow-laps={tv.arrowLaps} data-rotor-laps={tv.rotorLaps} data-says={tv.says}>{line}</p>
    </Back>
  );
}

/** the physicist's back (Octavo's Say): in the rotor model a wave is split in two halves, one turned by φ (it carries R), the other not; their sum is 1 + R,
 *  and |1 + R|² is drawn against the turn from 0° to 720°, with the mark at this turn */
function HalvesBack({ L, phi, row }) {
  const gv = L.glowView(phi), P = L.PLOT, nm = glowLabels(L, gv), PM = (P.x0 + P.x1) / 2, d = Math.round(phi);
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="two halves of a wave and their sum" viewBox="0 0 420 236">
        <rect x="0.5" y="0.5" width="419" height="235" rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        <line x1={gv.p0.x} y1={gv.p0.y} x2={gv.p2.x} y2={gv.p2.y} strokeWidth="3" strokeDasharray="7 6" strokeLinecap="round" style={{ stroke: 'var(--fg-2)' }} />
        <Arrow from={gv.p0} to={gv.p1} head={gv.h1} width="5" color="var(--fg)" />
        <Arrow from={gv.p1} to={gv.p2} head={gv.h2} width="5" color="var(--turn)" />
        <circle cx={gv.p0.x} cy={gv.p0.y} r="4" style={{ fill: 'var(--fg)' }} />
        <Txt x={nm.one.x} y={nm.one.y} size={17} anchor="middle" math>1</Txt>
        <Txt x={nm.r.x} y={nm.r.y} size={17} anchor="middle" math>R</Txt>
        {nm.sum ? <Txt x={nm.sum.x} y={nm.sum.y} size={17} anchor="middle" math color="var(--fg-2)">1 + R</Txt> : null}
        <line x1={P.x0} y1={P.y0} x2={P.x1} y2={P.y0} strokeWidth="1.5" style={{ stroke: 'var(--muted)' }} />
        <line x1={P.x0} y1={P.y0} x2={P.x0} y2={P.y1 - 6} strokeWidth="1.5" style={{ stroke: 'var(--muted)' }} />
        <line x1={PM} y1={P.y0} x2={PM} y2={P.y1} strokeWidth="1.5" strokeDasharray="3 5" style={{ stroke: 'var(--line-2)' }} />
        <Txt x={P.x0} y={P.y1 - 16} size={15} math muted>|1 + R|²</Txt>
        <Txt x={P.x0 - 13} y={P.y1 + 5} size={15} anchor="end" muted>{P.top}</Txt>
        <Txt x={P.x0 - 13} y={P.y0 + 5} size={15} anchor="end" muted>0</Txt>
        {L.ENDS.map((t, i) => <Txt key={t} x={[P.x0, PM, P.x1][i]} y={P.y0 + 22} size={15} anchor={i === 2 ? 'end' : 'middle'} muted>{t}</Txt>)}
        <path d={L.GLOW_PATH} fill="none" strokeWidth="3" strokeLinejoin="round" style={{ stroke: 'var(--fg)' }} />
        <line x1={gv.dot.x} y1={P.y0} x2={gv.dot.x} y2={gv.dot.y} strokeWidth="1.5" strokeDasharray="3 4" style={{ stroke: 'var(--fg)' }} />
        <circle cx={gv.dot.x} cy={gv.dot.y} r="7" strokeWidth="2.5" style={{ fill: 'var(--hi)', stroke: 'var(--fg)' }} />
      </FigSvg>
      <p className="leaf-readout" data-glow={L.glow(d)}>{readoutOf([`φ = ${d}°`, `|1 + R|² = ${L.glowText(L.glow(d))}`])}</p>
    </Back>
  );
}

LeafHalfTurns.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the turn, where the arrow points and where the spinor sits, whether the arrow is home and the spinor's sign there, the rotor,
 *  the laps and |1 + R|² (half-turns.logic.js frontView, torusView, glowView) */
LeafHalfTurns.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const phi = phiOf(L, params), v = L.frontView(phi), t = L.torusView(phi), R = L.rotor(phi);
  return { phi, arrow: v.arrowDeg, spinor: v.rotorDeg, home: v.home, says: v.says, rotor: [R[0], L.bPart(R)], laps: [t.arrowLaps, t.rotorLaps], sum: L.glow(phi) };
};
LeafHalfTurns.ready = () => !!logicOf(SLUG, NEEDS);
