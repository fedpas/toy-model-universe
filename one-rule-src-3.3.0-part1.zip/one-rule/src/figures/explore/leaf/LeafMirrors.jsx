// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-mirrors (leaf 3, the top of steps/mirrors): the front of the Octavo leaf "mirrors" redrawn with the V2 kit. Two mirror lines through one point,
// a flag, its image in the first mirror (a dashed outline) and its image after both mirrors (the colour of a turn), the wedge between the mirrors and the arc
// of the turn, all from engines/explore/leaves/mirrors.logic.js (frontView: the mirror −a x a⁻¹ of the kernel, applied twice). Controls: the angle between
// the mirrors, 0° to 90° by 5° (a stepper: Octavo's slider) and Swap the mirrors (Octavo's button). Readouts: the angle apart and the turn, as the logic
// gives them. At research level the backs of the Octavo leaf, without controls of their own (a control of a leaf is offered at both levels): in mode math
// the eight corners of the cube of three plus switches in columns by the number of mirrors, each with the signs it puts on the three axes and its
// determinant (cornerView); in mode phys a corner of three mirrors and a beam traced through its bounces (beamView at the starting slope).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Stepper, Toggle, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, backOf, Back, nf } from './leafKit.jsx';

const SLUG = 'mirrors', ID = 'leaf-mirrors';
const NEEDS = ['START', 'SPREAD', 'C', 'frontView', 'setSpread', 'swapped', 'CORNERS', 'EDGES', 'CUBE', 'COLUMN_HEADS', 'LAYERS', 'PARITY', 'cornerView', 'START_BEAM', 'beamView', 'WALLS', 'proj', 'ROOM'];
const WAY = { 1: 'anticlockwise', '-1': 'clockwise' };
function startOf(L, params) {
  let s = L.START;
  if (params && params.deg !== undefined) s = L.setSpread(s, params.deg);
  if (params && params.swap === true) s = L.swapped(s);
  return s;
}
const TURN = { stroke: 'var(--turn)' };

export default function LeafMirrors(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Mirrors L={L} {...props} />;
}

/** a flag of the front: the start (ink), its image in the first mirror (a dashed outline) or its image after both mirrors (the colour of a turn) */
function Flag({ f, kind }) {
  if (kind === 'ghost') return (
    <g className="ln-m" style={{ strokeWidth: 2.5, strokeDasharray: '7 5', strokeLinejoin: 'round', strokeLinecap: 'round', fill: 'none' }} data-flag="ghost">
      <line {...f.pole} /><path d={f.pennant} />
    </g>
  );
  const c = kind === 'last' ? 'var(--turn)' : 'var(--fg)';
  return (
    <g style={{ strokeLinejoin: 'round', strokeLinecap: 'round' }} data-flag={kind}>
      <line {...f.pole} style={{ stroke: c, strokeWidth: 5 }} />
      <path d={f.pennant} style={{ fill: c, stroke: c, strokeWidth: 2 }} />
    </g>
  );
}
/** the three flags of the key, upright: the first image has its pennant on the other side */
function KeyFlag({ kind }) {
  const ghost = kind === 'ghost', c = kind === 'last' ? 'var(--turn)' : ghost ? 'var(--muted)' : 'var(--fg)';
  return (
    <svg width="30" height="32" viewBox="0 0 34 36" aria-hidden="true" focusable="false" className="leaf-key-flag">
      <line x1="17" y1="33" x2="17" y2="3" style={{ stroke: c, strokeWidth: ghost ? 2.2 : 3.5, strokeLinecap: 'round', strokeDasharray: ghost ? '5 3.5' : 'none' }} />
      <path d={ghost ? 'M17 3 L17 17 L3 10 Z' : 'M17 3 L17 17 L31 10 Z'} style={{ fill: ghost ? 'none' : c, stroke: c, strokeWidth: ghost ? 2 : 1.5, strokeLinejoin: 'round', strokeDasharray: ghost ? '5 3.5' : 'none' }} />
    </svg>
  );
}
const KEY = [['start', 'the flag'], ['ghost', 'after mirror 1'], ['last', 'after mirrors 1 and 2']];

function Mirrors({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.deg, params.swap]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.frontView(s), t = v.t, back = backOf(level, mode);
  return (
    <div className="fig leaf leaf-mirrors">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="two mirrors and a flag" viewBox="0 0 400 400" className="leaf-pic leaf-w400" data-deg={s.deg} data-swap={s.swap ? 1 : 0} data-turn={t.sweep}>
          {v.mirrors.map((m, i) => <line key={'g' + i} {...m.line} className="ln-l" style={{ strokeWidth: 11, strokeLinecap: 'round' }} />)}
          {v.mirrors.map((m, i) => <line key={'m' + i} {...m.line} className="ln" style={{ strokeWidth: 3, strokeLinecap: 'round' }} data-mirror={m.label} />)}
          {v.wedge ? <path d={v.wedge} className="ln-m" style={{ strokeWidth: 2 }} /> : null}
          {v.arc ? <path d={v.arc} style={{ ...TURN, fill: 'none', strokeWidth: 3.5, strokeLinecap: 'round' }} data-arc={t.sweep} /> : null}
          {v.head ? <path d={v.head} style={{ fill: 'var(--turn)' }} /> : null}
          <Flag f={v.flag} kind="start" />
          <Flag f={v.ghost} kind="ghost" />
          <Flag f={v.last} kind="last" />
          <circle cx={L.C} cy={L.C} r="5" className="disc-ink" />
          {v.mirrors.map((m, i) => (
            <g key={'l' + i}>
              <circle cx={r1(m.at[0])} cy={r1(m.at[1])} r="14" className="disc" style={{ strokeWidth: 2 }} />
              <text x={r1(m.at[0])} y={r1(m.at[1]) + 5.5} textAnchor="middle" className="lt-m" style={{ fontWeight: 700 }}>{m.label}</text>
            </g>
          ))}
        </FigSvg>
        <div className="leaf-side">
          <ul className="leaf-key" style={{ listStyle: 'none', margin: 0, padding: 0, display: 'grid', gap: 6 }}>
            {KEY.map(([k, w]) => <li key={k} style={{ display: 'flex', alignItems: 'center', gap: 10 }}><KeyFlag kind={k} /><span>{w}</span></li>)}
          </ul>
        </div>
      </div>
      <p className="leaf-readout" aria-live="polite" data-deg={s.deg} data-turn={t.size} data-dir={t.dir}>
        {`mirrors ${v.apart} apart · turn ${v.turnText}${t.dir ? ' ' + WAY[t.dir] : ''}`}
      </p>
      <Controls label="the two mirrors">
        <Stepper label="angle between the mirrors" value={s.deg / L.SPREAD.step} min={L.SPREAD.min / L.SPREAD.step} max={L.SPREAD.max / L.SPREAD.step} onChange={i => setS(x => L.setSpread(x, i * L.SPREAD.step))} display={i => `${i * L.SPREAD.step}°`} param="deg" />
        <Toggle label="Swap the mirrors" on={s.swap} onChange={() => setS(L.swapped)} param="swap" />
      </Controls>
      {back === 'math' ? <CornersBack L={L} row={row} /> : back === 'phys' ? <BeamBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the corners of the cube of three plus switches in columns by the number of mirrors; each corner with the signs
 *  it puts on the three axes; a solid ring for determinant +1, a dashed ring for −1; lines join corners one mirror apart (mirrors.logic.js cornerView) */
function CornersBack({ L, row }) {
  const views = new Map(L.CORNERS.map(c => [c.S, L.cornerView(c.S)]));
  return (
    <Back who="math" way="algebra">
      <FigSvg id={ID} row={row} part="the corners of the cube as products of mirrors" viewBox="0 0 400 270" className="leaf-w400">
        {L.EDGES.map(e => <line key={e.a + '-' + e.b} x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2} className="ln-l" style={{ strokeWidth: 2 }} />)}
        {L.COLUMN_HEADS.map((h, k) => <text key={k} x={L.CUBE.cols[k]} y={L.CUBE.head} textAnchor="middle" className="lt-s t-muted">{h}</text>)}
        {L.CORNERS.map(c => {
          const cv = views.get(c.S);
          return (
            <g key={c.S} data-corner={c.S} data-det={cv.det}>
              <circle cx={c.x} cy={c.y} r="19" className="disc" style={cv.even ? { ...TURN, strokeWidth: 3 } : { strokeWidth: 2, strokeDasharray: '4 3' }} />
              <text x={c.x} y={c.y + 5} textAnchor="middle" className="lt-m lt-math">{c.name}</text>
              <text x={c.x} y={c.y + 36} textAnchor="middle" className="lt-s t-mono" data-signs={cv.d.join(',')}>{cv.d.map(x => (x > 0 ? '+' : '−')).join(' ')}</text>
            </g>
          );
        })}
      </FigSvg>
      <p className="leaf-readout" data-layers={L.LAYERS.join(',')}>{`${L.LAYERS.join(', ')} corners · solid ring: det = +1 (${L.PARITY.even}) · dashed: det = −1 (${L.PARITY.odd})`}</p>
      <p className="leaf-readout">x ↦ −a x a⁻¹ · k mirrors: det = (−1)ᵏ</p>
    </Back>
  );
}

/** the Physicist's back: a corner of a room whose floor, back wall and left wall are mirrors, and a beam traced through its bounces (mirrors.logic.js
 *  beamView at the starting slope); the readout gives the direction in and out */
function BeamBack({ L, row }) {
  const b = L.START_BEAM, bv = L.beamView(b), SIZE = [L.ROOM.W, L.ROOM.H, L.ROOM.D];
  // each wall's name where the beam does not pass: the floor and the left wall near their front corners, the back wall in its middle (fractions of the room)
  const LABEL_AT = { floor: [0.86, 0, 0.8], back: [0.5, 0.5, 0], left: [0, 0.1, 0.55] };
  const labelAt = id => L.proj(LABEL_AT[id].map((f, j) => f * SIZE[j]));
  const dir = d => `(${d.map(x => nf(x, 2)).join(', ')})`;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="a corner of three mirrors and a beam of light" viewBox="0 0 400 330" className="leaf-w400" data-mirrors={b.n} data-returns={bv.back ? 1 : 0}>
        <rect x="0.5" y="0.5" width="399" height="329" rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        {bv.walls.map(w => <polygon key={w.id} points={w.pts} className={w.on ? 'fill-soft' : 'ln-l'} style={{ stroke: 'var(--muted)', strokeWidth: w.on ? 2 : 1.5, strokeDasharray: w.on ? 'none' : '5 5', strokeLinejoin: 'round', fillOpacity: w.on ? w.shade : 0 }} data-wall={w.id} />)}
        {bv.walls.map(w => { const p = labelAt(w.id); return <text key={'t' + w.id} x={r1(p[0])} y={r1(p[1])} textAnchor="middle" className="lt-s t-muted">{w.name}</text>; })}
        <polyline points={bv.beam} className="ln" style={{ strokeWidth: 3.5, strokeLinejoin: 'round', strokeLinecap: 'round' }} />
        <polygon points={bv.arrowIn} style={{ fill: 'var(--fg)' }} />
        <polygon points={bv.arrowOut} style={{ fill: 'var(--fg)' }} />
        {bv.bounces.map((p, i) => <circle key={i} cx={p[0]} cy={p[1]} r="5" className="disc" style={{ strokeWidth: 2 }} />)}
      </FigSvg>
      <p className="leaf-readout" data-flipped={bv.flipped.join(',')}>{`direction in ${dir(bv.tr.dIn)} · out ${dir(bv.tr.dOut)} · ${bv.tr.hits.length} bounces`}</p>
    </Back>
  );
}

LeafMirrors.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the two mirrors, the turn they make (its matrix, size and way), the corners with their determinants, the beam of the back */
LeafMirrors.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), t = L.frontView(s).t, bv = L.beamView(L.START_BEAM);
  return {
    deg: s.deg, swap: s.swap, first: t.first, second: t.second, matrix: t.M, turn: t.size, dir: t.dir,
    corners: L.CORNERS.map(c => { const cv = L.cornerView(c.S); return { corner: c.name, mirrors: cv.k, signs: cv.d, det: cv.det }; }),
    beam: { mirrors: L.START_BEAM.n, slope: L.START_BEAM.aim, in: bv.tr.dIn, out: bv.tr.dOut, back: bv.back }
  };
};
LeafMirrors.ready = () => !!logicOf(SLUG, NEEDS);
