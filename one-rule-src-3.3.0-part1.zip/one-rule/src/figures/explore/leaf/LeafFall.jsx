// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-fall (Explore, leaf 7): the front of the Octavo leaf "fall" redrawn with the V2 kit. Distance r (in units of 2M) across, time up: a drop let go
// far away falls through the light cones (engines/explore/leaves/fall.logic.js frontView: g = pgG(r), the cones and the rays of light from the drop by pgRays and
// a Runge–Kutta trace, the drop's own clock rainT, the class of X = e_r + g e_t by pgClass). Cones outside the horizon are open outlines, the horizon's dashed,
// those inside shaded; the light sent outward from the drop is solid, inward dashed. Beside it the gauge of g from 0 to 1 and the zone past it, and the three
// places with Octavo's marks: the way the outward light goes (up and out, straight up, up and in). Controls: the chips r = 0.4 … 3 (Octavo's slider) and Play
// (paused at first). Readouts: r, g and the name of the place, as the logic gives them. At research level in mode math, the back of the Octavo leaf: the vector
// X = e_r + g e_t for the drop's g and its square on a number line, marked by its sign (mathView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, PlayButton, r1, tx } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, useTicker, nf, MoveMark, backOf, Back } from './leafKit.jsx';

const SLUG = 'fall', ID = 'leaf-fall';
const NEEDS = ['START', 'STATES', 'FIG', 'CONES', 'RAIN_PATH', 'DIAL', 'DIAL_TICKS', 'ZONE_ANG', 'px', 'py', 'conePts', 'dialAng', 'dialPt', 'dialArc', 'arrowTip', 'advance', 'setDistance', 'frontView', 'mathView', 'MP', 'mx', 'my', 'sqX', 'SPACE_WEDGE', 'TIME_WEDGE', 'LIGHT_END'];
const RS = [0.4, 0.6, 0.8, 1, 1.2, 1.5, 2, 2.5, 3];
function startOf(L, params) { return RS.includes(params.r) ? L.setDistance(Math.round(params.r * 20)) : L.START; }
// Octavo's marks of the three places: the way light sent outward goes (up and out, straight up, up and in), in a 22 × 22 box
const MARKS = { out: [[5, 17], [16, 6]], still: [[11, 19], [11, 4]], in: [[17, 17], [6, 6]] };

export default function LeafFall(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Fall L={L} {...props} />;
}

function PlaceMark({ L, m, x, y }) {
  const [p, q] = MARKS[m], tip = [q[0] + (q[0] - p[0]) * 0.18, q[1] + (q[1] - p[1]) * 0.18];
  return (
    <g transform={`translate(${x - 11} ${y - 11})`} data-mark={m}>
      <line x1={p[0]} y1={p[1]} x2={q[0]} y2={q[1]} className="ln ln-round" style={{ strokeWidth: 2.4 }} />
      <polygon points={L.arrowTip(p, tip, 8, 4.5)} className="fill-ink" />
    </g>
  );
}

function Fall({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.r]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = useTicker(dt => setS(x => L.advance(x, dt)), 0.2);
  const v = L.frontView(s), F = L.FIG, D = L.DIAL, px = L.px, py = L.py;
  const pts = arr => arr.map(p => `${r1(px(p[0]))},${r1(py(p[1]))}`).join(' ');
  const rChip = RS.find(x => Math.round(x * 20) === v.v) ?? null;
  const zoneP = L.dialPt(L.ZONE_ANG, D.R);
  return (
    <div className="fig leaf leaf-fall">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="rain falling through the light cones" viewBox={`0 0 ${F.w} ${F.h}`} className="leaf-pic leaf-w400">
          <defs><clipPath id="leaf-fall-plot"><rect x={F.x0} y={F.top} width={F.right - F.x0} height={F.axis - F.top} /></clipPath></defs>
          <rect x={px(0)} y={F.top} width={px(1) - px(0)} height={F.axis - F.top} className="fill-faint" />
          <g clipPath="url(#leaf-fall-plot)">
            {L.CONES.map((k, i) => (
              <g key={i} data-cone-class={k.cls}>
                <polygon points={L.conePts(k)} className="fill-soft" style={{ fillOpacity: k.cls > 0 ? 0.3 : 0.1 }} />
                <polyline points={pts([k.inn, k.o, k.out])} className="ln-m ln-round" style={{ strokeWidth: 1.6, strokeDasharray: k.cls === 0 ? '4 3' : undefined }} />
              </g>
            ))}
            <line x1={px(1)} y1={F.top} x2={px(1)} y2={F.axis} className="ln ln-dash" style={{ strokeWidth: 2.2 }} />
            <path d={L.RAIN_PATH} className="ln-m ln-round" style={{ strokeWidth: 2.6 }} />
            <polygon points={v.probePts} className="fill-soft" style={{ fillOpacity: 0.3 }} />
            <path d={v.innPath} className="ln ln-round" style={{ strokeWidth: 1.8, strokeDasharray: '6 4' }} />
            <path d={v.outPath} className="ln ln-round" style={{ strokeWidth: 2.6 }} />
            {v.outTip ? <polygon points={v.outTip} className="fill-ink" /> : null}
            {v.innTip ? <polygon points={v.innTip} className="fill-ink" /> : null}
            <polyline points={pts([v.probe.inn, v.probe.o, v.probe.out])} className="ln ln-round" style={{ strokeWidth: 3.2 }} />
            <circle cx={r1(v.drop[0])} cy={r1(v.drop[1])} r="8.5" className="disc-ink" style={{ opacity: v.op, stroke: 'var(--panel)', strokeWidth: 2.5 }} data-r={v.r} />
          </g>
          <line x1={F.x0} y1={F.axis} x2={F.right} y2={F.axis} className="ln" />
          <line x1={F.x0} y1={F.axis} x2={F.x0} y2={F.top} className="ln" />
          {[0, 1, 2, 3].map(r => <text key={r} x={px(r)} y={F.axis + 20} textAnchor="middle" className="t-mono lt-s t-muted">{r}</text>)}
          <text x={F.right} y={F.axis + 38} textAnchor="end" className="lt-s t-muted">{research ? 'distance r / 2M →' : 'distance r →'}</text>
          <text x={F.x0 + 6} y={F.top + 16} className="lt-s t-muted">↑ time</text>
          <text x={px(1) + 7} y={F.top + 16} className="lt-s t-bold">horizon</text>
          <text x={px(2.62)} y={py(0.62)} className="lt-s t-muted">rain</text>
        </FigSvg>
        <FigSvg id={ID} row={row} part="the gauge of g and the three places" viewBox={`0 0 ${D.w} 306`} className="leaf-pic" style={{ maxWidth: 330 }}>
          <path d={L.dialArc(Math.PI, L.dialAng(1))} className="ln-l" style={{ strokeWidth: 14 }} />
          <path d={L.dialArc(L.dialAng(1), 0)} className="ln-m" style={{ strokeWidth: 14, strokeDasharray: '4 3', opacity: v.cls > 0 ? 1 : 0.45 }} />
          {v.cls <= 0 ? <path d={v.fillArc} className="ln" style={{ strokeWidth: 14 }} /> : null}
          {L.DIAL_TICKS.map(t => <line key={t.s} x1={r1(t.p[0])} y1={r1(t.p[1])} x2={r1(t.q[0])} y2={r1(t.q[1])} className="ln" style={{ strokeWidth: t.s === 1 ? 3 : 1.5 }} />)}
          <text x={r1(L.dialPt(Math.PI, D.R)[0])} y={D.cy + 22} textAnchor="middle" className="t-mono lt-s t-muted">0</text>
          <text x={r1(L.dialPt(L.dialAng(0.5), D.R + 27)[0])} y={r1(L.dialPt(L.dialAng(0.5), D.R + 27)[1] + 5)} textAnchor="middle" className="lt-s t-muted">½</text>
          <text x={r1(L.dialPt(L.dialAng(1), D.R + 27)[0])} y={r1(L.dialPt(L.dialAng(1), D.R + 27)[1] + 2)} textAnchor="middle" className="t-mono lt-s t-bold">1</text>
          <text x={r1(zoneP[0] + 4)} y={D.h - 4} textAnchor="middle" className="lt-s t-muted">inside</text>
          <line x1={D.cx} y1={D.cy} x2={r1(v.needleEnd[0])} y2={r1(v.needleEnd[1])} className="ln ln-round" style={{ strokeWidth: 4, strokeDasharray: v.cls > 0 ? '5 5' : undefined }} data-g={v.g} />
          <circle cx={D.cx} cy={D.cy} r="7" className="fill-ink" />
          <text x={D.cx} y={D.cy + 32} textAnchor="middle" className="lt-l t-mono">{v.cls > 0 ? 'g > 1' : `g = ${v.speedText}`}</text>
          {L.STATES.map((st, i) => {
            const on = st.cls === v.cls, y = 202 + 34 * i;
            return (
              <g key={st.cls} data-place={st.cls} aria-current={on ? 'true' : undefined}>
                <rect x="6" y={y - 15} width={D.w - 12} height="30" rx="8" className={on ? 'sel' : 'ln-l'} style={on ? undefined : { fill: 'none' }} />
                <PlaceMark L={L} m={st.mark} x={28} y={y} />
                <text x="50" y={y} className={'lt-mid ' + (on ? 't-bold' : '')}>{st.where}</text>
              </g>
            );
          })}
        </FigSvg>
      </div>
      <p className="leaf-readout" aria-live={player.playing ? 'off' : 'polite'} data-r={v.r} data-g={v.g} data-class={v.cls}>
        {`r = ${v.rText} · g = ${v.speedText} · ${v.st.where.toLowerCase()}`}
      </p>
      <Controls label="the distance">
        <Chips label={research ? 'r / 2M' : 'distance r'} items={RS} value={rChip} onPick={r => { player.stop(); setS(L.setDistance(Math.round(r * 20))); }} render={r => String(r)} param="r" mono />
        <PlayButton player={player} />
      </Controls>
      {backOf(level, mode) === 'math' ? <VectorBack L={L} g={v.g} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the vector X = e_r + g e_t of Cl(1,1) for the drop's g, tipping over the light line as g passes 1, and its square
 *  X² on a number line, marked by its sign (fall.logic.js mathView with the logic's own g, MP, mx, my, sqX, the wedges and the light line) */
function VectorBack({ L, g, row }) {
  const m = L.mathView(20 * g), MP = L.MP, o = [L.mx(0), L.my(0)], le = L.LIGHT_END;
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part="the vector X and its square" viewBox={`0 0 ${MP.w} ${MP.h}`}>
        <polygon points={L.SPACE_WEDGE} className="fill-faint" />
        <polygon points={L.TIME_WEDGE} className="fill-soft" />
        <line x1={o[0]} y1={o[1]} x2={MP.right} y2={o[1]} className="ln-m" />
        <line x1={o[0]} y1={o[1]} x2={o[0]} y2={MP.top} className="ln-m" />
        <line x1={o[0]} y1={o[1]} x2={r1(le[0])} y2={r1(le[1])} className="ln-m ln-dash" style={{ strokeWidth: 3 }} />
        <line x1={L.mx(1)} y1={L.my(0)} x2={L.mx(1)} y2={L.my(2)} className="ln-l ln-dot" />
        <line x1={o[0]} y1={o[1]} x2={r1(m.tip[0])} y2={r1(m.tip[1])} className="ln ln-round" style={{ strokeWidth: 4 }} data-g={m.g} />
        <polygon points={m.xTip} className="fill-ink" />
        <text x={MP.right - 4} y={o[1] + 22} textAnchor="end" className="lt-m">{tx('e_r')}</text>
        <text x={o[0] + 8} y={MP.top + 14} className="lt-m">{tx('e_t')}</text>
        <text x={r1(m.tip[0] + 10)} y={r1(Math.max(MP.top + 12, m.tip[1] + 6))} className="lt-m t-bold">X</text>
        <text x={r1(le[0] + 6)} y={r1(le[1] + 14)} className="lt-s t-bold">light</text>
        <line x1={MP.lx0} y1={MP.ly} x2={MP.lx1} y2={MP.ly} className="ln" style={{ strokeWidth: 2 }} />
        <line x1={L.sqX(0)} y1={MP.ly - 9} x2={L.sqX(0)} y2={MP.ly + 9} className="ln" style={{ strokeWidth: 3 }} />
        {[-1, 0, 1, 2, 3].map(t => <text key={t} x={r1(L.sqX(t))} y={MP.ly + 26} textAnchor="middle" className="t-mono lt-s t-muted">{t < 0 ? '−' + -t : t}</text>)}
        <text x={MP.lx0 - 4} y={MP.ly - 14} className="lt-m">X²</text>
        <MoveMark cls={m.cls} x={Math.min(MP.lx1, Math.max(MP.lx0, m.dot))} y={MP.ly} s={7} label={false} on />
      </FigSvg>
      <p className="leaf-readout" data-square={m.X2} data-class={m.cls}>{typeof m.readout === 'string' && m.readout ? m.readout : `g = ${nf(m.g, 2)} · X² = g² − 1 = ${nf(m.X2, 2)}`}</p>
    </Back>
  );
}

LeafFall.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: r, g = pgG(r), the class of X = e_r + g e_t (pgClass) and the light cone at the drop (fall.logic.js frontView) */
LeafFall.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const v = L.frontView(startOf(L, params));
  return { r: v.r, g: v.g, cls: v.cls, place: v.st.where, rainClock: v.t, cone: { tip: v.probe.o, out: v.probe.out, inward: v.probe.inn } };
};
LeafFall.ready = () => !!logicOf(SLUG, NEEDS);
