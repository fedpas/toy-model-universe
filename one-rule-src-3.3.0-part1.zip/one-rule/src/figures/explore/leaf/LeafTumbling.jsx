// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-tumbling (shelf, under leaf 2): the front of the Octavo leaf "tumbling" redrawn with the V2 kit. A book (a uniform box 1.0 × 0.7 × 0.2) spun about
// one of its three sides, in perspective, moved by the rigid-body engine (engines/explore/leaves/tumbling.logic.js: newRun, advance, bookView), and beside it the
// ball on which the spin L, seen from inside the book, runs: its closed path (orbit), the trail and the dot (frontView). The poles of the ball wear the mark of
// what a push does about that side: a ring (−1, a turn) or a diamond (+1, a boost), the sign of μ; the spin arrow of the book wears the mark's colour.
// Controls (ports of the Octavo face): the chips "spin about" long | middle | short side (newRun), the chips of the first push 1° … 30° (Octavo's slider, D24),
// Play (paused at first) and Restart. Readouts: the side, its move, the flips so far (and μ at research level), as the logic gives them. At research level the
// backs of the Octavo leaf: in mode math the mathematician's sphere of the book with its curves of constant energy, the saddle at the middle poles and μ of
// each axis (mathView, mathTrack); in mode phys the physicist's book beside the arrow of L, which stays upright, with |L| and the energy (physView).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Chips, PlayButton, PlayAction, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, MOVE_WORD, useTicker, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'tumbling', ID = 'leaf-tumbling';
const NEEDS = ['newRun', 'advance', 'orbit', 'sphereView', 'frontView', 'poleLabels', 'mathView', 'mathTrack', 'physView', 'BOOK_MATH', 'PUSH_CHIPS', 'PUSH_START',
  'SIDE_NAMES', 'BOOK_BOX', 'FRONT_SPHERE', 'MATH_SPHERE', 'PHYS_BOX', 'sideKinds', 'muOf', 'I_BOOK', 'lArrow'];
const okAxis = a => Number.isInteger(a) && a >= 0 && a <= 2;
function startOf(L, params) {
  const a = okAxis(params.axis) ? params.axis : 1, d = L.PUSH_CHIPS.includes(params.push) ? params.push : L.PUSH_START;
  return L.newRun(a, d);
}
const MOVE = k => (k < 0 ? 'turn' : k > 0 ? 'boost' : 'slide');
const FACE = { cover: { fill: 'var(--muted)', fillOpacity: 0.3, stroke: 'var(--fg)' }, spine: { fill: 'var(--fg)', fillOpacity: 0.72, stroke: 'var(--fg)' }, pages: { fill: 'var(--panel)', stroke: 'var(--fg)' } };

export default function LeafTumbling(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Tumbling L={L} {...props} />;
}

/** the mark of a move inside a chip (a hidden icon: the chip's word says the same) */
function ChipMark({ k }) {
  const st = { stroke: `var(--${MOVE(k)})`, strokeWidth: 2.4, fill: 'var(--panel)' };
  return (
    <svg aria-hidden="true" className="fig-icon" width="18" height="18" viewBox="-9 -9 18 18" style={{ overflow: 'visible' }}>
      {k < 0 ? <circle r="6" style={st} /> : k > 0 ? <path d="M0 -7.5 L7.5 0 L0 7.5 L-7.5 0 Z" style={st} /> : <rect x="-7.5" y="-2.6" width="15" height="5.2" rx="1.5" style={{ fill: 'var(--slide)', stroke: 'var(--slide)' }} />}
    </svg>
  );
}

/** the book: the far half of its spin arrow, the faces that face the camera with the lines of the pages, the near half of the arrow and its head */
function Book({ b, kind, children }) {
  const arrow = { strokeWidth: 4, strokeLinecap: 'round', style: { stroke: `var(--${MOVE(kind)})` } };
  return (
    <g>
      {children}
      <line x1={r1(b.far.x1)} y1={r1(b.far.y1)} x2={r1(b.far.x2)} y2={r1(b.far.y2)} {...arrow} />
      {!b.headNear ? <polygon points={b.head} style={{ fill: `var(--${MOVE(kind)})` }} /> : null}
      {b.faces.map(f => <polygon key={f.key} points={f.pts} strokeWidth="2" strokeLinejoin="round" style={FACE[f.kind]} data-face={f.kind} />)}
      {b.lines.length ? <path d={b.lines.join(' ')} className="ln-l" style={{ strokeWidth: 1.2 }} /> : null}
      <line x1={r1(b.near.x1)} y1={r1(b.near.y1)} x2={r1(b.near.x2)} y2={r1(b.near.y2)} {...arrow} />
      {b.headNear ? <polygon points={b.head} style={{ fill: `var(--${MOVE(kind)})` }} /> : null}
    </g>
  );
}

/** a ball: its rim, the far half of a path and a trail, the far poles, the near halves, the near poles, the names of the poles, the dot */
function Ball({ g, path, trail, poles, labels, dot, fs = 13 }) {
  const P = front => poles.filter(p => p.front === front).map(p => <g key={p.i + '' + p.sg} opacity={front ? 1 : 0.45} data-pole={p.i} data-kind={p.kind}><MoveMark cls={p.kind} x={p.x} y={p.y} s={front ? 6 : 4.6} label={false} /></g>);
  return (
    <>
      <circle cx={g.cx} cy={g.cy} r={g.r} className="fill-bg" style={{ stroke: 'var(--line-2)', strokeWidth: 1.5 }} />
      {path ? <path d={path.far} className="ln-m ln-dot" /> : null}
      {trail ? <path d={trail.far} className="ln ln-round" style={{ strokeWidth: 2.4, opacity: 0.4 }} /> : null}
      {P(false)}
      {path ? <path d={path.near} className="ln-m ln-dash" /> : null}
      {trail ? <path d={trail.near} className="ln ln-round" style={{ strokeWidth: 3 }} /> : null}
      {P(true)}
      <g style={{ fontSize: fs }}>{labels.map(l => <text key={l.i} x={r1(l.x)} y={r1(l.y)} textAnchor={l.anchor} className="t-bold" style={{ paintOrder: 'stroke', stroke: 'var(--bg)', strokeWidth: 4, strokeLinejoin: 'round' }}>{l.text}</text>)}</g>
      {dot ? <circle cx={r1(dot.x)} cy={r1(dot.y)} r="7.5" className="fill-ink" style={{ stroke: 'var(--panel)', strokeWidth: 2.5, opacity: dot.front ? 1 : 0.5 }} /> : null}
    </>
  );
}

function Tumbling({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.axis, params.push]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = useTicker(dt => setS(x => L.advance(x, dt)), 0.25);
  const orb = useMemo(() => L.orbit(s.a, s.deg), [L, s.a, s.deg]), V = useMemo(() => L.sphereView(s.a, orb.ring), [L, s.a, orb.ring]);
  const v = L.frontView(s, orb, V), g = L.FRONT_SPHERE, B = L.BOOK_BOX, kinds = v.kinds, side = L.SIDE_NAMES[s.a];
  const restart = (a, d) => setS(L.newRun(a, d));
  return (
    <div className="fig leaf leaf-tumbling">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="a book spun about one of its sides" viewBox={`0 0 ${B.w} ${B.h}`} className="leaf-pic" style={{ maxWidth: 440 }}
          data-axis={s.a} data-push={s.deg} data-pointing={v.pointing}>
          <Book b={v.book} kind={v.cls} />
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="the spin seen from inside the book, on a ball" viewBox={`0 0 ${g.w} ${g.h}`} style={{ maxWidth: 260, justifySelf: 'center' }}
            data-ring={v.ring} data-at={v.at}>
            <Ball g={g} path={v.path} trail={v.trail} poles={v.poles} labels={L.poleLabels(v.poles, g)} dot={v.dot} />
          </FigSvg>
          <p className="leaf-readout" aria-live={player.playing ? 'off' : 'polite'} data-flips={v.count} data-kind={v.cls} data-mu={v.mu}>
            {`${side} side · ${research ? `μ = ${v.mu > 1e-9 ? '+' : ''}${nf(v.mu, 2)} b² · ` : ''}${MOVE_WORD[v.cls]} · flips ${v.count}`}
          </p>
        </div>
      </div>
      <Controls label="the spin">
        <Chips label="spin about" items={[0, 1, 2]} value={s.a} onPick={a => restart(a, s.deg)} render={a => <><ChipMark k={kinds[a]} /><span>{`${L.SIDE_NAMES[a]} side`}</span></>} param="axis" />
      </Controls>
      <Controls label="the first push">
        <Chips label="first push" items={L.PUSH_CHIPS} value={s.deg} onPick={d => restart(s.a, d)} render={d => `${d}°`} param="push" mono />
        <PlayButton player={player} />
        <PlayAction label="Restart" kind="reset" onClick={() => restart(s.a, s.deg)} />
      </Controls>
      {backOf(level, mode) === 'math' ? <SphereBack L={L} s={s} orb={orb} row={row} /> : null}
      {backOf(level, mode) === 'phys' ? <KeptBack L={L} s={s} orb={orb} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the sphere of the book's angular momentum, seen from outside, with its curves of constant energy — loops round the
 *  poles of the smallest and the largest moment (turns), the two great circles that cross at the middle poles (the saddle: a boost) — the run's path and dot,
 *  and μ of each axis with its move (tumbling.logic.js mathView of the book's moments, mathTrack) */
function SphereBack({ L, s, orb, row }) {
  const m = L.mathView(...L.BOOK_MATH), t = L.mathTrack(s, orb), G = L.MATH_SPHERE;
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part="the sphere of the spin with its curves of constant energy" viewBox={`0 0 ${G.w} ${G.h}`} style={{ maxWidth: 380 }} data-saddle={m.saddle.join(',')}>
        <circle cx={G.cx} cy={G.cy} r={G.r} className="fill-bg" style={{ stroke: 'var(--line-2)', strokeWidth: 1.5 }} />
        <g opacity="0.22">
          {m.loops.map((l, i) => <path key={'lf' + i} d={l.far} data-class="-1" style={{ fill: 'none', strokeWidth: 1.3 }} />)}
          {m.cross.map((c, i) => <path key={'cf' + i} d={c.far} data-class="1" style={{ fill: 'none', strokeWidth: 2 }} />)}
        </g>
        {m.poles.filter(p => !p.front).map(p => <g key={p.i + '' + p.sg} opacity="0.45"><MoveMark cls={p.kind} x={p.x} y={p.y} s={5} label={false} /></g>)}
        {m.loops.map((l, i) => <path key={'ln' + i} d={l.near} data-class="-1" style={{ fill: 'none', strokeWidth: 1.6, opacity: 0.85 }} />)}
        {m.cross.map((c, i) => <path key={'cn' + i} d={c.near} data-class="1" className="ln-dash" style={{ fill: 'none', strokeWidth: 3 }} />)}
        <path d={t.trail.near} className="ln ln-round" style={{ strokeWidth: 3 }} />
        {m.poles.filter(p => p.front).map(p => <g key={p.i + '' + p.sg} data-pole={p.i} data-kind={p.kind}><MoveMark cls={p.kind} x={p.x} y={p.y} s={7.5} label={false} /></g>)}
        <g className="lt-math" style={{ fontSize: 18 }}>{L.poleLabels(m.poles, G, 18, 20).map(l => <text key={l.i} x={r1(l.x)} y={r1(l.y)} textAnchor={l.anchor} style={{ paintOrder: 'stroke', stroke: 'var(--bg)', strokeWidth: 5, strokeLinejoin: 'round' }}>{l.text}</text>)}</g>
        <circle cx={r1(t.dot.x)} cy={r1(t.dot.y)} r="7.5" className="fill-ink" style={{ stroke: 'var(--panel)', strokeWidth: 2.5, opacity: t.dot.front ? 1 : 0.5 }} />
      </FigSvg>
      <FigSvg id={ID} row={row} part="μ of each axis and its move" viewBox="0 0 360 104">
        {m.rows.map((r, i) => (
          <g key={r.a} data-axis={r.a} data-mu={r.mu} data-kind={r.kind}>
            <MoveMark cls={r.kind} x={18} y={22 + 32 * i} s={7} label={false} />
            <text x={40} y={27 + 32 * i} className="lt-math">{r.axis}</text>
            <text x={78} y={27 + 32 * i} className="t-mono lt-s">{r.moment}</text>
            <text x={178} y={27 + 32 * i} className="t-mono lt-s">{r.muText}</text>
            <text x={352} y={27 + 32 * i} textAnchor="end" className="t-bold">{r.name}</text>
          </g>
        ))}
      </FigSvg>
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): the book again, bigger, beside the arrow of L, which stays upright in space; the length of L and the energy, now, at the
 *  start and how far they moved; the flips so far and, when the spin flips, the beat between two flips on the screen's clock (tumbling.logic.js physView) */
function KeptBack({ L, s, orb, row }) {
  const p = L.physView(s, orb), B = L.PHYS_BOX, a = p.arrow;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="the book beside the arrow of its angular momentum" viewBox={`0 0 ${B.w} ${B.h}`} className="leaf-w400" style={{ maxWidth: 420 }} data-lw={p.Lw.map(x => x.toFixed(6)).join(',')}>
        <Book b={p.book} kind={L.sideKinds()[s.a]}>
          <line x1={r1(a.x1)} y1={r1(a.y1)} x2={r1(a.x2)} y2={r1(a.y2)} className="ln" style={{ strokeWidth: 3.5, strokeLinecap: 'round' }} />
          <polygon points={a.head} className="fill-ink" />
          <text x={r1(a.label.x)} y={r1(a.label.y)} className="lt-math lt-l" style={{ fontStyle: 'italic' }}>L</text>
        </Book>
      </FigSvg>
      <FigSvg id={ID} row={row} part="the length of L and the energy" viewBox="0 0 400 124" className="leaf-w400">
        {p.meters.map((x, i) => (
          <g key={x.name} data-meter={i} data-now={x.now} data-moved={x.moved}>
            <text x={8} y={22 + 60 * i} className="t-bold">{x.name}</text>
            <text x={392} y={22 + 60 * i} textAnchor="end" className="t-mono lt-m">{x.now}</text>
            <text x={8} y={46 + 60 * i} className="t-mono lt-s t-muted">{`start ${x.start} · moved ${x.moved}`}</text>
          </g>
        ))}
      </FigSvg>
      <p className="leaf-readout" data-count={p.count} data-beat={p.beat}>{orb.flips ? `flips ${p.count} · one every ${nf(p.beat, 2)} s` : `flips ${p.count}`}</p>
    </Back>
  );
}

LeafTumbling.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the side and the push of the start, the moments of the book, μ of each side and its move, the closed path's period, the pole it
 *  rings and whether it flips (tumbling.logic.js) */
LeafTumbling.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const st = startOf(L, params), o = L.orbit(st.a, st.deg);
  return { axis: st.a, push: st.deg, moments: L.I_BOOK, mu: [0, 1, 2].map(a => L.muOf(L.I_BOOK, a)), kinds: L.sideKinds(), period: o.period, ring: o.ring, flips: o.flips, energy: st.E0 };
};
LeafTumbling.ready = () => !!logicOf(SLUG, NEEDS);
