// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-electron (the page top of steps/dirac; the Octavo loose leaf "electron", under leaf 6): the front of the Octavo leaf redrawn with the V2 kit.
// Energy E up, momentum k across: the curve E = √(k² + m²) that (P − m)(P + m) leaves (engines/explore/leaves/electron.logic.js: the product by the kernel in
// Cl(1,3,1), energy, curvePath, front), the dashed light lines E = |k|, the dot with its drop line; beside it, the same energy against the momentum k₀ along the
// zero switch: a flat line, the dot sliding on it. Controls (ports of the Octavo sliders): the steppers mass m (0 … 2 by 0.1), momentum k (−3 … 3 by 0.5) and
// zero-switch momentum k₀ (−3 … 3 by 1); the word "light" on a side is left out while the dot's drop line crosses it (|k| ≥ 2.2). Readouts: the sum E² = k² + m² and E, and E at k₀ and at k₀ = 0. At research level, the backs of the Octavo leaf at the
// front's state: in mode math the Mathematician's table of P × P (its mixed cells in pairs of opposite signs, the squares on the diagonal) and the formulas of
// the twin and of the determinant; in mode phys the Physicist's curve with the tangent at the dot, its slope k/E, the slow guess m + k²/2m and the fast guess |k|.
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Stepper, tx, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'electron', ID = 'leaf-electron';
const NEEDS = ['START', 'MV', 'KV', 'WV', 'canSet', 'front', 'curvePath', 'LIGHT_PATH', 'K_TICKS', 'LABELS', 'VIEW', 'O', 'twin', 'TABLE', 'NAMES', 'MATH', 'SIZES', 'cancelPairs', 'diagonal', 'physAt', 'physPaths', 'PO', 'PVIEW', 'P_TICKS', 'PHYS_LABELS', 'pX', 'pY'];
const S = 0.6;                       // the front is drawn in the logic's 600 × 400 units, at 0.6: a 360 × 240 picture whose words stay 13.5 units
const PS = 360 / 440;                // the physicist's picture: the logic's 440 × 420 units at 360 wide
// the markup of the logic's formulas (_{…} below the line, ^{…} above it) as HTML
const mk = s => String(s).split(/(_\{[^}]*\}|\^\{[^}]*\})/).map((p, i) => (p.startsWith('_{') ? <sub key={i}>{p.slice(2, -1)}</sub> : p.startsWith('^{') ? <sup key={i}>{p.slice(2, -1)}</sup> : p));

function startOf(L, params) {
  const s = { ...L.START };
  if (typeof params.m === 'number') s.mv = Math.round(params.m * 10);
  if (typeof params.k === 'number') s.kv = 5 * Math.round(params.k * 2);
  if (typeof params.k0 === 'number') s.wv = 10 * Math.round(params.k0);
  return L.canSet(s) ? s : { ...L.START };
}

export default function LeafElectron(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Electron L={L} {...props} />;
}

function Electron({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.m, params.k, params.k0]);   // eslint-disable-line react-hooks/exhaustive-deps
  const set = patch => setS(x => { const n = { ...x, ...patch }; return L.canSet(n) ? n : x; });
  const v = L.front(s), off = s.wv === 0 ? v : L.front({ ...s, wv: 0 }), b = v.box;
  const pct = (p, W, H) => [r1(p.left * W / 100), r1(p.top * H / 100)];
  const back = backOf(level, mode);
  const lab = (p, side = 'start', extra = {}) => { const [x, y] = pct(p, 360, 240); return { x, y, textAnchor: side === 'end' ? 'end' : side === 'middle' ? 'middle' : 'start', dominantBaseline: 'central', ...extra }; };
  const by = r1(2.4 * b.top), bx = r1(2 * b.left);
  return (
    <div className="fig leaf leaf-electron">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="energy against momentum" viewBox="0 0 360 240" className="leaf-pic" style={{ maxWidth: 560 }} data-e={v.E} data-m={v.m} data-k={v.k}>
          <rect x="0.75" y="0.75" width="358.5" height="238.5" rx="10" className="fill-panel" style={{ stroke: 'var(--line)', strokeWidth: 1.5 }} />
          <g transform={`scale(${S})`}>
            <line x1="12" y1={L.O.y} x2={L.VIEW.w - 12} y2={L.O.y} className="ln-m" style={{ strokeWidth: 2.2 }} />
            <line x1={L.O.x} y1="12" x2={L.O.x} y2={L.O.y} className="ln-m" style={{ strokeWidth: 2.2 }} />
            {L.K_TICKS.map(t => <line key={t.t} x1={t.x} y1={L.O.y} x2={t.x} y2={L.O.y + 9} className="ln-m" style={{ strokeWidth: 2.2 }} />)}
            <path d={L.LIGHT_PATH} className="ln-m ln-dash" style={{ strokeWidth: 3, strokeDasharray: '12 10' }} />
            {v.mMark ? <line x1={L.O.x} y1={r1(v.mMark.y)} x2={r1(v.mMark.x2)} y2={r1(v.mMark.y)} className="ln-m ln-dot" style={{ strokeWidth: 3.4, strokeDasharray: '1 9' }} /> : null}
            <path d={L.curvePath(s.mv)} className="ln ln-round" style={{ strokeWidth: 6 }} data-curve={s.mv} />
            <line x1={r1(v.dot.x)} y1={r1(v.dot.y)} x2={r1(v.dot.x)} y2={L.O.y} className="ln-m ln-dash" style={{ strokeWidth: 3, strokeDasharray: '6 7' }} />
            <circle cx={r1(v.dot.x)} cy={r1(v.dot.y)} r="15" className="sel" style={{ strokeWidth: 4 }} />
          </g>
          <text {...lab(L.LABELS.energy)} className="lt-s t-muted">energy E</text>
          <text {...lab(L.LABELS.k, 'middle')} className="lt-math" style={{ fontStyle: 'italic' }}>k</text>
          {v.k > -2.2 ? <text {...lab(L.LABELS.lightL)} className="lt-s t-muted">light</text> : null}
          {v.k < 2.2 ? <text {...lab(L.LABELS.lightR, 'end')} className="lt-s t-muted">light</text> : null}
          {L.K_TICKS.map(t => <text key={t.t} {...lab(t, 'middle')} className="lt-s t-muted">{t.text}</text>)}
          {v.mMark ? <text {...lab(v.mMark, 'end')} className="lt-math lt-m" style={{ fontStyle: 'italic' }}>m</text> : null}
          {v.eLab ? <text {...lab(v.eLab, v.eLab.side)} className="lt-math lt-m" style={{ fontStyle: 'italic' }}>E</text> : null}
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="energy against the momentum along a zero switch" viewBox="0 0 200 240" style={{ width: '100%', maxWidth: 'min(240px, 44vw)', justifySelf: 'center' }} data-same={String(v.same)}>
            <rect x="0.75" y="0.75" width="198.5" height="238.5" rx="10" className="fill-panel" style={{ stroke: 'var(--line)', strokeWidth: 1.5 }} />
            <line x1="6" y1="216" x2="194" y2="216" className="ln-m" />
            <line x1="100" y1="7" x2="100" y2="216" className="ln-m" />
            <line x1="2" y1={by} x2="198" y2={by} className="ln ln-round" style={{ strokeWidth: 3.4 }} />
            <line x1={bx} y1={by} x2={bx} y2="216" className="ln-m ln-dash" style={{ strokeWidth: 1.6 }} />
            <circle cx={bx} cy={by} r="9" className="sel" style={{ strokeWidth: 2.4 }} />
            <text x="106" y="18" className="lt-math" style={{ fontStyle: 'italic' }}>E</text>
            {b.ticks.map(t => <text key={t.t} x={r1(2 * t.left)} y="230" textAnchor="middle" className="lt-s t-muted">{t.text}</text>)}
            <text x="194" y="206" textAnchor="end" className="lt-math" style={{ fontStyle: 'italic' }}>{tx('k_0')}</text>
            <text x={b.lab.side === 'left' ? 10 : 190} y={r1(by + (b.lab.below ? 18 : -10))} textAnchor={b.lab.side === 'left' ? 'start' : 'end'} className="lt-math lt-s">{`E = ${v.eText}`}</text>
          </FigSvg>
          <p className="leaf-readout" aria-live="polite" data-e={v.E} data-e2={v.E2} data-same={String(v.same)}>
            {research ? v.sum : `k ${v.kText} · m ${v.mText} → E ${v.eText}`}
          </p>
          <p className="leaf-readout muted" data-zero={v.w}>
            {research ? (s.wv === 0 ? `E at k₀ = 0: ${v.eText}` : `E at k₀ = ${nf(v.w, 0)}: ${v.eText} · at k₀ = 0: ${off.eText}`) : `k₀ ${nf(v.w, 0)} → E ${v.eText}`}
          </p>
        </div>
      </div>
      <Controls label="mass and momenta">
        <Stepper label="mass m" value={s.mv} min={L.MV[0]} max={L.MV[1]} onChange={mv => set({ mv })} display={x => nf(x / 10, 1)} param="m" />
        <Stepper label="momentum k" value={Math.round(s.kv / 5)} min={L.KV[0] / 5} max={L.KV[1] / 5} onChange={x => set({ kv: 5 * x })} display={x => nf(x / 2, 1)} param="k" />
        <Stepper label="zero-switch momentum k₀" value={Math.round(s.wv / 10)} min={L.WV[0] / 10} max={L.WV[1] / 10} onChange={x => set({ wv: 10 * x })} display={x => nf(x, 0)} param="k0" />
      </Controls>
      {back === 'math' ? <TableBack L={L} v={v} row={row} /> : back === 'phys' ? <SpeedBack L={L} v={v} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say, way in: algebra): the table of P × P, row a and column b holding e_a e_b with its sign (the kernel's), the squares on
 *  the diagonal and the mixed cells in pairs (a, b), (b, a) of opposite signs; then P, the squares, the twin, what it forces, and the determinant with its
 *  power on the two modules (electron.logic.js TABLE, MATH, SIZES, cancelPairs), and the twin's number at the front's dot */
function TableBack({ L, v, row }) {
  const n = L.NAMES.length, x0 = 40, y0 = 30, cw = 55, ch = 36;
  const tw = L.twin([v.E, v.k, 0, 0, v.w], v.m);
  return (
    <Back who="math" way="algebra">
      <FigSvg id={ID} row={row} part="the table of P times P" viewBox={`0 0 320 ${y0 + n * ch + 8}`}>
        <text x="20" y={y0 - 12} textAnchor="middle" className="lt-math lt-m t-muted">×</text>
        {L.NAMES.map((nm, b) => <text key={'c' + b} x={x0 + cw * b + cw / 2} y={y0 - 12} textAnchor="middle" className="lt-math lt-m">{tx(`e_${nm}`)}</text>)}
        {L.TABLE.map((cells, a) => (
          <g key={a}>
            <text x="20" y={y0 + ch * a + ch / 2 + 5} textAnchor="middle" className="lt-math lt-m">{tx(`e_${L.NAMES[a]}`)}</text>
            {cells.map(c => (
              <g key={c.b} data-cell={`${a},${c.b}`} data-sign={c.sign} data-mask={c.mask}>
                <rect x={x0 + cw * c.b + 2} y={y0 + ch * a + 2} width={cw - 4} height={ch - 4} rx="8" className={c.diag ? 'disc' : 'cell-box'} style={c.diag ? { strokeWidth: 2.2, strokeDasharray: c.sign === 0 ? '4 3' : undefined } : { stroke: 'var(--line)' }} />
                <text x={x0 + cw * c.b + cw / 2} y={y0 + ch * a + ch / 2 + 5} textAnchor="middle" className={'lt-math lt-m' + (c.diag ? '' : ' t-muted')}>{tx(c.text)}</text>
              </g>
            ))}
          </g>
        ))}
      </FigSvg>
      <p className="leaf-readout">{mk(L.MATH.P)}</p>
      <p className="leaf-readout muted">{mk(L.MATH.squares)}</p>
      <p className="leaf-readout" data-pairs={L.cancelPairs()}>{`mixed pairs of opposite signs: ${L.cancelPairs()} · P² = `}{mk(L.diagonal())}</p>
      <p className="leaf-readout">{mk(L.MATH.twin)}</p>
      <p className="leaf-readout">{mk(L.MATH.forces)}</p>
      <p className="leaf-readout" data-twin={tw.scalar} data-rest={tw.rest}>{`at the dot: E² − k² − m² = ${nf(tw.scalar, 2)}`}</p>
      <p className="leaf-readout">{mk(L.MATH.det)}{' · '}{L.SIZES.map(z => `N = ${z.N}: power ${z.power}`).join(' · ')}</p>
    </Back>
  );
}

/** the Physicist's back (Octavo's Say): the curve of the front's mass with the tangent at the dot (momentum |k| of the front), its slope k/E as the speed, the
 *  slope triangle, the light line and the slow guess m + k²/2m dotted; readouts E, the speed, the two guesses and how far each is from E (electron.logic.js
 *  physAt, physPaths) */
function SpeedBack({ L, v, row }) {
  const p = L.physAt(Math.abs(v.k), v.m), paths = L.physPaths(v.m), W = 360, H = r1(L.PVIEW.h * PS);
  const at = q => [r1(q.left * W / 100), r1(q.top * H / 100)];
  const slowEnd = paths.slow ? paths.slow.split(/\s*L\s*/).slice(-1)[0].replace(/^M/, '').trim().split(/\s+/).map(Number) : null;
  const [ex, ey] = at(L.PHYS_LABELS.energy), [mx, my] = at(L.PHYS_LABELS.momentum), [lx, ly] = at(L.PHYS_LABELS.light);
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="the slope of the curve" viewBox={`0 0 ${W} ${H}`} style={{ maxWidth: 460 }} data-speed={p.v === null ? '' : p.v}>
        <rect x="0.75" y="0.75" width={W - 1.5} height={H - 1.5} rx="10" className="fill-panel" style={{ stroke: 'var(--line)', strokeWidth: 1.5 }} />
        <g transform={`scale(${PS.toFixed(5)})`}>
          <line x1={L.PO.x - 10} y1={L.PO.y} x2={L.PVIEW.w - 10} y2={L.PO.y} className="ln-m" style={{ strokeWidth: 1.8 }} />
          <line x1={L.PO.x} y1="10" x2={L.PO.x} y2={L.PO.y + 10} className="ln-m" style={{ strokeWidth: 1.8 }} />
          {L.P_TICKS.map(t => <g key={t.t}><line x1={t.x} y1={L.PO.y} x2={t.x} y2={L.PO.y + 8} className="ln-m" style={{ strokeWidth: 1.8 }} /><line x1={L.PO.x - 8} y1={t.y} x2={L.PO.x} y2={t.y} className="ln-m" style={{ strokeWidth: 1.8 }} /></g>)}
          <path d={paths.light} className="ln-m ln-dash" style={{ strokeWidth: 2.6, strokeDasharray: '9 8' }} />
          {paths.slow ? <path d={paths.slow} className="ln-m ln-dot" style={{ strokeWidth: 3.4, strokeDasharray: '0.1 8' }} /> : null}
          <path d={paths.curve} className="ln ln-round" style={{ strokeWidth: 5 }} />
          {p.triangle && p.triangle.show ? <polyline points={p.triangle.pts} className="ln-m" style={{ strokeWidth: 2.2, strokeLinejoin: 'round' }} /> : null}
          {p.tangent ? <line x1={r1(p.tangent.x1)} y1={r1(p.tangent.y1)} x2={r1(p.tangent.x2)} y2={r1(p.tangent.y2)} className="ln ln-round" style={{ strokeWidth: 3 }} /> : null}
          <circle cx={r1(p.dot.x)} cy={r1(p.dot.y)} r="12" className="sel" style={{ strokeWidth: 3.4 }} />
        </g>
        <text x={ex} y={ey} className="lt-s t-muted" dominantBaseline="central">energy E</text>
        <text x={mx} y={my} textAnchor="end" className="lt-s t-muted" dominantBaseline="central">momentum k</text>
        <text x={lx} y={ly} textAnchor="start" className="lt-s t-muted" dominantBaseline="central">light</text>
        {slowEnd ? <text x={r1(slowEnd[0] * PS + 6)} y={r1(slowEnd[1] * PS + 14)} className="lt-s t-muted">slow guess</text> : null}
        {L.P_TICKS.map(t => { const [kx, ky] = at(t.k), [qx, qy] = at(t.e); return <g key={t.t}><text x={kx} y={ky} textAnchor="middle" className="lt-s t-muted" dominantBaseline="central">{t.text}</text><text x={qx} y={qy} textAnchor="end" className="lt-s t-muted" dominantBaseline="central">{t.text}</text></g>; })}
        {p.triangle && p.triangle.show ? (() => { const [rx, ry] = at(p.triangle.run), [sx, sy] = at(p.triangle.rise); return <g><text x={rx} y={ry} textAnchor="middle" className="lt-s" dominantBaseline="central">1</text><text x={sx} y={sy} className="lt-s" dominantBaseline="central">{p.triangle.vText}</text></g>; })() : null}
      </FigSvg>
      <p className="leaf-readout" data-e={p.E} data-v={p.v === null ? '' : p.v}>{p.line1}</p>
      <p className="leaf-readout" data-slow={p.slow === null ? '' : p.slow}>{p.slow === null ? 'slow guess m + k²/2m: none at m = 0' : `slow guess m + k²/2m = ${nf(p.slow, 2)} (${p.slowMiss.text})`}</p>
      <p className="leaf-readout" data-fast={p.fast}>{`fast guess |k| = ${nf(p.fast, 2)} (${p.fastMiss.text})`}</p>
    </Back>
  );
}

LeafElectron.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the state, the energy read from (P − m)(P + m) and that product at the dot, the speed and the two guesses (electron.logic.js
 *  front, twin, physAt) */
LeafElectron.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.front(s), tw = L.twin([v.E, v.k, 0, 0, v.w], v.m), p = L.physAt(Math.abs(v.k), v.m);
  return { m: v.m, k: v.k, k0: v.w, E: v.E, E2: v.E2, zeroAddsNothing: v.zeroAddsNothing, same: v.same, twin: tw.scalar, rest: tw.rest, speed: p.v, slow: p.slow, fast: p.fast };
};
LeafElectron.ready = () => !!logicOf(SLUG, NEEDS);
