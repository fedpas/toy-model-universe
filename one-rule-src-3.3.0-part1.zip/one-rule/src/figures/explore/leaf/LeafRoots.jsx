// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-roots (Explore, leaf 8): the front of the Octavo leaf "roots" redrawn with the V2 kit. Eight switches give 240 arrows, each a list of eight numbers
// (engines/explore/leaves/roots.logic.js: ROOTS, 112 with two switches at ±1 and 128 with all eight at ±½ and an even number of minus signs; their shadow on the
// Coxeter plane, shadow(): rings of h marks; seeView: what is shown, lit and picked). A mark on two switches is a dot, a half-cube corner a ring. When the family
// changes the marks light up as they are counted (a short count started by the chip, at once under reduced motion). Controls (ports of the Octavo face): the
// chips two switches / half-cube corners / all, and the pick of one arrow (a tap picks the nearest mark, the arrow keys go round a ring or out and in).
// Readouts: the eight numbers of the picked arrow (cellText), its |r|² (dotTrue), the counts (COUNT) and the rings (shadow), as the logic gives them. At
// research level in mode math, the back of the Octavo leaf: the tree of E8 and the E-series with determinants and root counts (stopView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, useReducedMotion, r1, arrowHead } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, backOf, Back } from './leafKit.jsx';

const SLUG = 'roots', ID = 'leaf-roots';
const NEEDS = ['START', 'ROOTS', 'COUNT', 'CX', 'CY', 'MARK', 'shadow', 'seeView', 'pick', 'tick', 'tapAt', 'stepSel', 'dotTrue', 'inFam', 'stopView'];
const FAMS = ['two', 'half', 'all'];
const FAM_NAME = { two: 'two switches', half: 'half-cube corners', all: 'all' };   // used when the logic carries no FAMS labels
const KEYS = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'];
function startOf(L, params) {
  let s = L.START;
  if (FAMS.includes(params.fam) && params.fam !== s.fam) s = L.pick(s, params.fam, true);
  if (Number.isInteger(params.root) && params.root >= 0 && params.root < L.ROOTS.length && L.inFam(params.root, s.fam)) s = { ...s, sel: params.root };
  return s;
}

export default function LeafRoots(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Roots L={L} {...props} />;
}

function Roots({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const reduced = useReducedMotion();
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.fam, params.root]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.seeView(s), sh = L.shadow(), r = L.ROOTS[s.sel], CX = L.CX, CY = L.CY;
  // the count that a chip starts: the marks light up over the logic's COUNT_TIME (tick), then it stops
  useEffect(() => {
    if (v.done || typeof window === 'undefined' || !window.requestAnimationFrame) return undefined;
    let id = 0, last = null;
    const loop = ts => { const dt = last === null ? 0 : Math.min(0.05, (ts - last) / 1000); last = ts; setS(x => L.tick(x, dt)); id = window.requestAnimationFrame(loop); };
    id = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(id);
  }, [v.done, s.fam]);   // eslint-disable-line react-hooks/exhaustive-deps
  const tap = e => {
    const svg = e.currentTarget.ownerSVGElement; if (!svg || !svg.createSVGPoint || !svg.getScreenCTM()) return;
    const pt = svg.createSVGPoint(); pt.x = e.clientX; pt.y = e.clientY; const p = pt.matrixTransform(svg.getScreenCTM().inverse());
    setS(x => L.tapAt(x, p.x, p.y));
  };
  const key = e => { if (KEYS.includes(e.key)) { e.preventDefault(); setS(x => L.stepSel(x, e.key)); } else if (e.key === 'Enter' || e.key === ' ') e.preventDefault(); };
  const a = v.arrow, two = r.kind === 'two';
  return (
    <div className="fig leaf leaf-roots">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="the 240 arrows on a plane" viewBox="0 0 400 400" className="leaf-pic leaf-w400">
          {v.rings.map((rr, k) => <circle key={k} cx={CX} cy={CY} r={r1(rr)} className="ln-l" style={{ strokeWidth: 1 }} />)}
          <g data-shown={v.marks.filter(m => m.show).length} data-lit={v.marks.filter(m => m.lit).length}>
            {v.marks.map(m => (!m.show ? null : m.kind === 'two'
              ? <circle key={m.id} cx={r1(m.x)} cy={r1(m.y)} r={L.MARK} className="fill-ink" style={{ opacity: m.lit ? 1 : 0.2 }} data-root={m.id} data-kind="two" />
              : <circle key={m.id} cx={r1(m.x)} cy={r1(m.y)} r={L.MARK - 0.6} className="disc" style={{ strokeWidth: 1.3, opacity: m.lit ? 1 : 0.2 }} data-root={m.id} data-kind="half" />))}
          </g>
          <line x1={r1(a.x1)} y1={r1(a.y1)} x2={r1(a.x2)} y2={r1(a.y2)} className="ln ln-round" style={{ strokeWidth: 2.4 }} />
          <path d={arrowHead(a.x1, a.y1, a.x2, a.y2, 8)} className="fill-ink" />
          <circle cx={CX} cy={CY} r="3.6" className="fill-ink" />
          <circle cx={r1(v.sel.x)} cy={r1(v.sel.y)} r="8.6" className="sel" />
          {two ? <circle cx={r1(v.sel.x)} cy={r1(v.sel.y)} r="3.9" className="fill-ink" /> : <circle cx={r1(v.sel.x)} cy={r1(v.sel.y)} r="3.4" className="disc" style={{ strokeWidth: 1.5 }} />}
          <text x="8" y="38" className="lt-xl" data-counter={v.counter}>{v.counter}</text>
          <text x="10" y="60" className="lt-s t-muted">{v.counterWord}</text>
          <g role="button" tabIndex={0} data-param="root" className="leaf-pick" aria-label="pick an arrow: a tap picks the nearest mark, the arrow keys go round a ring or out and in" onClick={tap} onKeyDown={key}>
            <rect x="0" y="0" width="400" height="400" className="pick-hit" />
          </g>
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="the eight numbers of the picked arrow" viewBox="0 0 320 76">
            {v.cells.map((c, k) => (
              <g key={k} data-cell={k} data-value={r.v[k]}>
                <text x={14 + 38 * k + 17} y="14" textAnchor="middle" className="t-mono lt-s t-muted">{k + 1}</text>
                <rect x={14 + 38 * k} y="24" width="34" height="42" rx="7" className={c.zero ? 'ln-l' : 'disc'} style={c.zero ? { fill: 'var(--panel)' } : undefined} />
                <text x={14 + 38 * k + 17} y="45" textAnchor="middle" className={'lt-m lt-mid ' + (c.zero ? 't-muted' : 't-bold')}>{c.t}</text>
              </g>
            ))}
          </FigSvg>
          <p className="leaf-readout" aria-live="polite" data-root={s.sel} data-kind={r.kind} data-norm={L.dotTrue(r.v, r.v)}>
            {research
              ? `${v.list} · |r|² = ${L.dotTrue(r.v, r.v)}`
              : (two ? `switches ${r.on[0] + 1} and ${r.on[1] + 1}` : `minus signs: ${r.minus}`)}
          </p>
          <p className="leaf-readout muted" data-two={L.COUNT.two} data-half={L.COUNT.half} data-all={L.COUNT.all} data-rings={sh.radii.length} data-h={sh.h}>
            {research
              ? `${L.COUNT.two} dots + ${L.COUNT.half} rings = ${L.COUNT.all} · ${sh.radii.length} rings · h = ${sh.h}`
              : `dots ${L.COUNT.two} · rings ${L.COUNT.half} · all ${L.COUNT.all}`}
          </p>
        </div>
      </div>
      <Controls label="the arrows">
        <Chips label="show" items={FAMS} value={s.fam} onPick={f => setS(x => L.pick(x, f, reduced))} render={f => { const F = (L.FAMS || []).find(x => x.id === f); return F && F.label ? F.label.toLowerCase() : FAM_NAME[f]; }} param="fam" />
      </Controls>
      {backOf(level, mode) === 'math' ? <SeriesBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the tree of E8 and the E-series from E3 to E9, each with the determinant of its Cartan matrix and its number of
 *  roots (roots.logic.js stopView(8): exact determinants by Bareiss elimination, roots by closing the simple roots under their mirrors; ∞ once it never ends) */
function SeriesBack({ L, row }) {
  const sv = L.stopView(8);
  return (
    <Back who="math" way="counting">
      <FigSvg id={ID} row={row} part="the E-series" viewBox="0 0 360 192">
        <g transform="translate(20 0)">
          {sv.edges.map((e, k) => <line key={k} x1={r1(e.a.x)} y1={r1(e.a.y)} x2={r1(e.b.x)} y2={r1(e.b.y)} className="ln" style={{ strokeWidth: 2 }} />)}
          {sv.nodes.map(nd => <circle key={nd.id} cx={r1(nd.x)} cy={r1(nd.y)} r="10" className={nd.last ? 'sel' : 'disc'} data-node={nd.id} />)}
        </g>
        <g transform="translate(0 104)">
          <text x="4" y="45" className="lt-s t-muted">det</text>
          <text x="4" y="71" className="lt-s t-muted">roots</text>
          {sv.strip.map((c, k) => { const x = 76 + 38 * k; return (
            <g key={c.n} data-n={c.n} data-det={c.det} data-roots={c.roots}>
              {c.on ? <rect x={x - 18} y="2" width="36" height="78" rx="7" className="sel" /> : null}
              <text x={x} y="20" textAnchor="middle" className="lt-m">{c.name}</text>
              {c.zero ? <circle cx={x} cy="40" r="12" className="ln" /> : null}
              <text x={x} y="45" textAnchor="middle" className="t-mono lt-m t-bold">{c.det}</text>
              <text x={x} y="71" textAnchor="middle" className={'t-mono ' + (c.roots === '∞' ? 'lt-l' : 'lt-s')}>{c.roots}</text>
            </g>); })}
        </g>
      </FigSvg>
      <p className="leaf-readout" data-det={sv.det} data-roots={sv.roots}>{`E₈: det ${sv.det} · ${sv.roots} roots · det from E₃ to E₉: ${sv.strip.map(c => c.det).join(', ')}`}</p>
    </Back>
  );
}

LeafRoots.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the counts, the rings of the shadow, the picked arrow (roots.logic.js COUNT, shadow, ROOTS) */
LeafRoots.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), sh = L.shadow(), r = L.ROOTS[s.sel];
  return { counts: L.COUNT, rings: sh.radii.length, h: sh.h, family: s.fam, root: { id: r.id, kind: r.kind, numbersTimesTwo: r.v, norm: L.dotTrue(r.v, r.v) } };
};
LeafRoots.ready = () => !!logicOf(SLUG, NEEDS);
