// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-charge (Explore, shelf, under leaf 6): the front of the Octavo leaf "charge" redrawn with the V2 kit. A charge seen from above in E (up the page)
// and B (out of the page) (engines/explore/leaves/charge.logic.js: the field F of Cl(1,3) from the stored cell table, the force as the grade-1 part of F u by
// the kernel's product, the run frontRun integrated by Runge–Kutta in proper time, frontView: where the charge is at time t and its speed; square: F² = E² − B²
// for crossed fields, and its class −1, 0, +1). The class is told by mark and word (a ring "−1" turn, a bar "0" slide, a diamond "+1" boost) and by the line of
// the path (solid, dotted, dashed), never by colour. Rings with a dot show B, arrows show E, darker when stronger. Controls (ports of the Octavo face): the
// steppers E and B (0 … 2 by 0.1), the quick fields B only / E = B / E only, and Play (paused at first). Readouts: E, B, E² − B², the class name and the speed.
// At research level in mode phys, the back of the Octavo leaf: a circle, a drift and the speed limit, each from a run and from its closed form (circleRun,
// driftRun, limitRun).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Stepper, Chips, PlayButton, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, useTicker, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'charge', ID = 'leaf-charge';
const NEEDS = ['START', 'K_MAX', 'W', 'H', 'PRESETS', 'MOVES', 'frontRun', 'pathOf', 'advance', 'setField', 'frontView', 'glyphs', 'presetOf', 'square', 'crossed', 'speedText', 'circleRun', 'driftRun', 'limitRun', 'KV_START', 'KR_START'];
const LINE = { '-1': undefined, 0: '2 5', 1: '9 6' };
function startOf(L, params) {
  const pre = L.PRESETS.find(p => p.id === params.preset);
  let kE = pre ? pre.kE : L.START.kE, kB = pre ? pre.kB : L.START.kB;
  if (typeof params.E === 'number' && params.E >= 0 && params.E <= L.K_MAX / 10) kE = Math.round(params.E * 10);
  if (typeof params.B === 'number' && params.B >= 0 && params.B <= L.K_MAX / 10) kB = Math.round(params.B * 10);
  return L.setField(L.START, kE, kB);
}

export default function LeafCharge(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Charge L={L} {...props} />;
}

function Charge({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.E, params.B, params.preset]);   // eslint-disable-line react-hooks/exhaustive-deps
  const run = useMemo(() => L.frontRun(s.kE, s.kB), [L, s.kE, s.kB]), path = useMemo(() => L.pathOf(run), [L, run]);
  const player = useTicker(dt => setS(x => L.advance(x, run, dt)), 0.25);
  const v = L.frontView(s, run, path), g = L.glyphs(s.kE, s.kB), sq = L.square(L.crossed(run.E, run.B)).scalar;
  const set = (kE, kB) => setS(x => L.setField(x, kE, kB));
  const k = 360 / L.W, Hs = L.H * k, top = 30, dash = LINE[v.cls];
  return (
    <div className="fig leaf leaf-charge">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="a charge in E and B" viewBox={`0 0 360 ${r1(top + Hs + 4)}`} className="leaf-pic" style={{ maxWidth: 560 }}>
          {[-1, 0, 1].map((c, i) => <MoveMark key={c} cls={c} x={20 + 118 * i} y={14} s={7} on={c === v.cls} word={L.MOVES[c + 1]} />)}
          <g transform={`translate(0 ${top}) scale(${k.toFixed(5)})`}>
            <rect x="0.75" y="0.75" width={L.W - 1.5} height={r1(L.H - 1.5)} rx="18" className="fill-panel" style={{ stroke: 'var(--line)', strokeWidth: 1.5 }} />
            {g.b > 0 ? g.at.map(([x, y], i) => <g key={'b' + i} style={{ opacity: g.b }}><circle cx={x} cy={y} r="7" className="ln-m" /><circle cx={x} cy={y} r="2" className="fill-muted" /></g>) : null}
            {g.e > 0 ? g.at.filter(([x, y]) => x < L.W - 40 && y < L.H - 40).map(([x, y], i) => { const X = x + 31, Y = y + 31, h = g.len / 2; return <path key={'e' + i} d={`M${X} ${r1(Y + h)}V${r1(Y - h)}M${X - 4} ${r1(Y - h + 5)}L${X} ${r1(Y - h)}L${X + 4} ${r1(Y - h + 5)}`} className="ln-m ln-round" style={{ strokeWidth: 1.6, opacity: g.e }} />; }) : null}
            <circle cx={r1(v.SX)} cy={r1(v.SY)} r="7" className="ln-m" style={{ strokeDasharray: '3 3' }} />
            <path d={path.d} className="ln-m ln-round" style={{ strokeWidth: 2.4, opacity: 0.45, strokeDasharray: dash }} />
            <path d={v.trail} className="ln ln-round" style={{ strokeWidth: 4, strokeDasharray: dash }} data-class={v.cls} />
            <g transform={`translate(${r1(v.X)} ${r1(v.Y)})`} style={{ opacity: v.op }}>
              <circle r="11" className="disc" style={{ strokeWidth: 2.5 }} />
              <path d="M-5 0H5M0-5V5" className="ln ln-round" style={{ strokeWidth: 2.2 }} />
            </g>
          </g>
          {v.zoomText ? <text x="352" y={r1(top + Hs - 8)} textAnchor="end" className="lt-s t-muted">{research ? v.zoomText : `×${nf(run.zoom, 1)}`}</text> : null}
        </FigSvg>
        <div className="leaf-side">
          <FigSvg id={ID} row={row} part="the speed of the charge" viewBox="0 0 300 62">
            <text x="10" y="16" className="lt-s t-bold">speed</text>
            <text x="290" y="16" textAnchor="end" className="t-mono lt-s" data-speed={v.speed}>{v.speedText}</text>
            <defs><clipPath id="leaf-charge-bar"><rect x="10" y="26" width="276" height="14" rx="7" /></clipPath></defs>
            <rect x="10" y="26" width="276" height="14" rx="7" className="fill-panel" style={{ stroke: 'var(--fg)', strokeWidth: 1.5 }} />
            <rect x="10" y="26" width={r1(276 * Math.min(1, Math.max(0, v.gauge / 100)))} height="14" className="fill-ink" clipPath="url(#leaf-charge-bar)" />
            <rect x="286" y="20" width="3" height="26" rx="1.5" className="fill-ink" />
            <text x="10" y="56" className="t-mono lt-s t-muted">0</text>
            <text x="290" y="56" textAnchor="end" className="lt-s t-muted">light</text>
          </FigSvg>
          <p className="leaf-readout" aria-live={player.playing ? 'off' : 'polite'} data-e={run.E} data-b={run.B} data-square={sq} data-class={v.cls}>
            {research
              ? `E = ${nf(run.E, 1)} · B = ${nf(run.B, 1)} · E² − B² = ${nf(sq, 2)} → ${v.name}`
              : `E ${nf(run.E, 1)} · B ${nf(run.B, 1)} → ${v.name}`}
          </p>
        </div>
      </div>
      <Controls label="the fields">
        <Stepper label="E" value={s.kE} min={0} max={L.K_MAX} onChange={kE => set(kE, s.kB)} display={x => nf(x / 10, 1)} param="E" />
        <Stepper label="B" value={s.kB} min={0} max={L.K_MAX} onChange={kB => set(s.kE, kB)} display={x => nf(x / 10, 1)} param="B" />
        <Chips label="quick fields" items={L.PRESETS.map(p => p.id)} value={L.presetOf(s.kE, s.kB)} onPick={id => { const p = L.PRESETS.find(q => q.id === id); set(p.kE, p.kB); }} render={id => (L.PRESETS.find(p => p.id === id) || {}).label || id} param="preset" />
        <PlayButton player={player} />
      </Controls>
      {backOf(level, mode) === 'phys' ? <RunsBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Physicist's back (Octavo's Say): three runs, each read against its closed form: the circle in B alone (its radius from the run, from γmv/(qB), and
 *  Newton's mv/(qB) dashed), the drift from rest in crossed fields with B winning (its mean speed over one turn and E/B), and the speed in E alone at proper
 *  time 3 (from the run, from tanh(qEτ/m), and Newton's straight line) (charge.logic.js circleRun, driftRun, limitRun at their starting values) */
function RunsBack({ L, row }) {
  const c = L.circleRun(L.KV_START), d = L.driftRun(L.KR_START), l = L.limitRun(), f3 = x => nf(x, 3);
  return (
    <Back who="phys">
      <div className="leaf-back-row">
        <FigSvg id={ID} row={row} part={c.title} viewBox="0 0 150 120">
          <rect x="0.5" y="0.5" width="149" height="119" rx="10" className="fill-panel" style={{ stroke: 'var(--line)' }} />
          <circle cx={r1(c.nc[0])} cy={r1(c.nc[1])} r={r1(c.nr)} className="ln-m" style={{ strokeDasharray: '4 3', strokeWidth: 1.8 }} />
          <path d={c.path} className="ln" style={{ strokeWidth: 3 }} />
          <circle cx={c.start[0]} cy={c.start[1]} r="4.5" className="fill-ink" />
        </FigSvg>
        <FigSvg id={ID} row={row} part={d.title} viewBox="0 0 150 120">
          <rect x="0.5" y="0.5" width="149" height="119" rx="10" className="fill-panel" style={{ stroke: 'var(--line)' }} />
          <path d={d.path} className="ln ln-round" style={{ strokeWidth: 3 }} />
          <circle cx={r1(d.start[0])} cy={r1(d.start[1])} r="4.5" className="fill-ink" />
        </FigSvg>
        <FigSvg id={ID} row={row} part={l.title} viewBox="0 0 150 120">
          <rect x="0.5" y="0.5" width="149" height="119" rx="10" className="fill-panel" style={{ stroke: 'var(--line)' }} />
          <line x1={r1(l.axis[0])} y1={r1(l.axis[1])} x2={r1(l.axis[2])} y2={r1(l.axis[3])} className="ln-m" />
          <line x1={r1(l.light[0])} y1={r1(l.light[1])} x2={r1(l.light[2])} y2={r1(l.light[3])} className="ln ln-dash" style={{ strokeWidth: 1.6 }} />
          <line x1={r1(l.newtonLine[0])} y1={r1(l.newtonLine[1])} x2={r1(l.newtonLine[2])} y2={r1(l.newtonLine[3])} className="ln-m ln-dot" style={{ strokeWidth: 2 }} />
          <path d={l.path} className="ln ln-round" style={{ strokeWidth: 3 }} />
        </FigSvg>
      </div>
      <p className="leaf-readout" data-measured={c.measured} data-formula={c.formula}>{`${c.title} (v = ${nf(c.v, 2)}): radius ${f3(c.measured)} from the run · γmv/(qB) = ${f3(c.formula)} · mv/(qB) = ${f3(c.newton)}`}</p>
      <p className="leaf-readout" data-measured={d.measured === null ? '' : d.measured} data-formula={d.formula}>{d.measured === null ? `${d.title}: E/B = ${f3(d.formula)}` : `${d.title} (E/B = ${nf(d.r, 2)}): mean speed ${f3(d.measured)} from the run · E/B = ${f3(d.formula)}`}</p>
      <p className="leaf-readout" data-measured={l.measured} data-formula={l.formula}>{`${l.title} (τ = 3): speed ${f3(l.measured)} from the run · tanh(qEτ/m) = ${f3(l.formula)} · qEt/m = ${nf(l.newton, 1)}`}</p>
    </Back>
  );
}

LeafCharge.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the fields, F² = E² − B² and its class, the run's speeds and turns (charge.logic.js frontRun, square) */
LeafCharge.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), run = L.frontRun(s.kE, s.kB), sq = L.square(L.crossed(run.E, run.B));
  return { E: run.E, B: run.B, square: sq.scalar, cls: run.cls, steps: run.steps, turns: run.turns, topSpeed: run.top, periodic: run.periodic, zoom: run.zoom };
};
LeafCharge.ready = () => !!logicOf(SLUG, NEEDS);
