// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-seats (Explore, shelf, under leaf 5): the front of the Octavo leaf "seats" redrawn with the V2 kit. Three seats, each empty or full, and the eight
// patterns as the corners of a cube in layers by particles (engines/explore/leaves/seats.logic.js: the moves "add one" and "take one away" as elements of
// Cl(3,3) multiplied by the kernel, moveOn, particles, COUNTS; frontView: the seats, the corners and edges, the arrow of the last move, the layers). A move that
// gives nothing leaves the pattern and shakes its seat (not under reduced motion). The three names of a pattern (bits | numbers | primes, nameIn) are the
// switch of the face; the lenses bits and primes set its default. Controls (ports of the Octavo face): a tap on a seat, the chips add / take away (the Octavo
// seat buttons "add one" and "Take away"), the names chips. Readouts: the pattern's name, its particles, the move as the logic writes it (readout().math) or
// "→ 0" when the move gives nothing. At research level in mode math, the back of the Octavo leaf: the 8 × 8 table of "add one" to the seat of the last
// move on the patterns, and the entries of its square (mathView).
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, r1, arrowHead } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, backOf, Back } from './leafKit.jsx';

const SLUG = 'seats', ID = 'leaf-seats';
const NEEDS = ['START', 'MODES', 'NODE', 'COUNTS', 'PATTERNS', 'press', 'rename', 'readout', 'frontView', 'particles', 'longName', 'mathView'];
const OPS = ['add', 'take'];
const namesOf = (params, lens, L) => (L.MODES.includes(params.names) ? params.names : lens === 'primes' || lens === 'prime' ? 'primes' : 'bits');
function startOf(L, params, lens) { return L.rename(L.START, namesOf(params, lens, L)); }

export default function LeafSeats(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Seats L={L} {...props} />;
}

function Seats({ L, params = {}, lens = null, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params, lens));
  const [op, setOp] = useState(OPS.includes(params.op) ? params.op : 'add');
  useEffect(() => { setS(x => L.rename(x, namesOf(params, lens, L))); }, [params.names, lens]);   // eslint-disable-line react-hooks/exhaustive-deps
  const v = L.frontView(s), N = L.NODE, ro = L.readout(s), ev = s.ev;
  const moveText = !ev ? null : ev.to !== null ? ro.math : `seat ${ev.k + 1} ${ev.op === 'add' ? 'full' : 'empty'} → 0`;
  return (
    <div className="fig leaf leaf-seats">
      <div className="leaf-row">
        <div className="leaf-side" style={{ maxWidth: 420 }}>
          <FigSvg id={ID} row={row} part="three seats" viewBox="0 0 360 152">
            {v.seats.map((seat, i) => {
              const x = 30 + 110 * i, cx = x + 44, cy = 52;
              return (
                <g key={seat.k} {...pickProps('seat', `${op === 'add' ? 'add one to' : 'take one away from'} seat ${seat.n}, ${seat.full ? 'full' : 'empty'}`, null, () => setS(x2 => L.press(x2, seat.k, op)))} data-seat={seat.n} data-full={seat.full ? 1 : 0}>
                  <rect x={x} y="8" width="88" height="88" rx="22" className="pick-ring" style={{ strokeWidth: 2 }} />
                  <g key={seat.shake ? 'shake' + v.shakeKey : 'still'} className={seat.shake ? 'leaf-shake' : undefined}>
                    <circle cx={cx} cy={cy} r="23" className={seat.full ? 'ln' : 'ln-m'} style={{ strokeWidth: 2, strokeDasharray: seat.full ? undefined : '5 4' }} />
                    {seat.full ? <circle cx={cx} cy={cy} r="16" className="fill-ink" /> : <path d={`M${cx} ${cy - 8} V${cy + 8} M${cx - 8} ${cy} H${cx + 8}`} className="ln-m ln-round" style={{ strokeWidth: 2.5 }} />}
                  </g>
                  <text x={cx} y="118" textAnchor="middle" className="lt-s t-bold">{`seat ${seat.n}`}</text>
                  <text x={cx} y="142" textAnchor="middle" className={'t-mono lt-m ' + (seat.full ? 't-bold' : 't-muted')}>{seat.unit}</text>
                </g>
              );
            })}
          </FigSvg>
          <p className="leaf-readout leaf-readout-big" aria-live="polite" data-pattern={s.a} data-particles={v.pattern.n}>
            {`${research ? 'pattern ' : ''}${v.pattern.long}`}<span className="muted">{` · ${v.pattern.n} particle${v.pattern.n === 1 ? '' : 's'}`}</span>
          </p>
          <p className="leaf-readout muted" data-move={ev ? `${ev.k},${ev.op},${ev.to === null ? 'none' : ev.to}` : ''}>{moveText || ' '}</p>
        </div>
        <FigSvg id={ID} row={row} part="the eight patterns as the corners of a cube" viewBox="0 0 340 292" className="leaf-pic" style={{ maxWidth: 400 }}>
          <text x="2" y="17" className="lt-s t-muted">particles</text>
          <text x="338" y="17" textAnchor="end" className="lt-s t-muted">patterns</text>
          {v.layers.map(l => (
            <g key={l.j} data-layer={l.j} data-count={l.count}>
              {l.dots.length ? l.dots.map(x => <circle key={x} cx={r1(x)} cy={l.y} r="5.5" className="fill-muted" />) : <circle cx="26" cy={l.y} r="6.5" className="ln-m" style={{ strokeDasharray: '3 2.5' }} />}
              <text x="310" y={l.y + 6} textAnchor="middle" className="lt-l t-bold">{l.count}</text>
            </g>
          ))}
          <line x1="290" y1="264" x2="330" y2="264" className="ln" />
          <text x="310" y="285" textAnchor="middle" className="lt-l t-bold" data-total={v.total}>{v.total}</text>
          {v.edges.map((e, i) => <line key={i} x1={e.x1} y1={e.y1} x2={e.x2} y2={e.y2} className="ln-l" data-edge={`${e.from},${e.to}`} />)}
          {v.arrow ? <g><line x1={r1(v.arrow.x1)} y1={r1(v.arrow.y1)} x2={r1(v.arrow.x2)} y2={r1(v.arrow.y2)} className="ln ln-round" style={{ strokeWidth: 3 }} /><path d={arrowHead(v.arrow.x1, v.arrow.y1, v.arrow.x2, v.arrow.y2, 9)} className="fill-ink" /></g> : null}
          {v.corners.map(c => (
            <g key={c.a} data-corner={c.a} data-name={c.name}>
              <rect x={c.x - N.w / 2} y={c.y - N.h / 2} width={N.w} height={N.h} rx={N.h / 2} className={c.on ? 'sel' : 'disc'} />
              <text x={c.x} y={c.y} textAnchor="middle" className="t-mono lt-m lt-mid">{c.name}</text>
            </g>
          ))}
        </FigSvg>
      </div>
      <Controls label="the seats">
        <Chips label="a tap on a seat" items={OPS} value={op} onPick={setOp} render={o => (o === 'add' ? 'adds one' : 'takes one away')} param="op" />
        <Chips label="names" items={L.MODES} value={s.mode} onPick={m => setS(x => L.rename(x, m))} param="names" mono />
      </Controls>
      {backOf(level, mode) === 'math' ? <TableBack L={L} k={ev ? ev.k : 0} names={s.mode} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the 8 × 8 table of "add one to seat k" acting on the eight patterns, for the seat of the last move (seat 1 at first):
 *  each entry +1 (filled) or −1 (a ring), the columns of the patterns where seat k is already full hatched and empty; and the count of the entries of its
 *  square (seats.logic.js mathView: the products of Cl(3,3) read in the basis of the patterns) */
function TableBack({ L, k, names, row }) {
  const m = L.mathView({ k, mode: names }), N = L.PATTERNS, C = 30, X0 = 50, Y0 = 44, neg = m.cells.filter(c => c.v < 0).length;
  return (
    <Back who="math" way="algebra">
      <FigSvg id={ID} row={row} part={`the table of adding one to seat ${m.n}`} viewBox={`0 0 ${X0 + C * N + 8} ${Y0 + C * N + 8}`}>
        <defs>
          <pattern id="leaf-seats-hatch" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="7" className="ln-l" style={{ strokeWidth: 2.5 }} /></pattern>
        </defs>
        <text x={X0} y="14" className="lt-s t-muted">from →</text>
        <text x="4" y="38" className="lt-s t-muted">to ↓</text>
        {m.fullCols.map(a => <rect key={a} x={X0 + C * a} y={Y0} width={C} height={C * N} style={{ fill: 'url(#leaf-seats-hatch)' }} data-full={a} />)}
        {Array.from({ length: N + 1 }, (_, i) => <line key={'v' + i} x1={X0 + C * i} y1={Y0} x2={X0 + C * i} y2={Y0 + C * N} className="ln-l" style={{ strokeWidth: 1 }} />)}
        {Array.from({ length: N + 1 }, (_, i) => <line key={'h' + i} x1={X0} y1={Y0 + C * i} x2={X0 + C * N} y2={Y0 + C * i} className="ln-l" style={{ strokeWidth: 1 }} />)}
        {m.names.map((t, a) => <text key={'c' + a} x={X0 + C * a + C / 2} y={Y0 - 8} textAnchor="middle" className="t-mono lt-s">{t}</text>)}
        {m.names.map((t, b) => <text key={'r' + b} x={X0 - 6} y={Y0 + C * b + C / 2} textAnchor="end" className="t-mono lt-s lt-mid">{t}</text>)}
        {m.cells.map(c => (
          <g key={c.to + '-' + c.from} data-entry={`${c.to},${c.from}`} data-value={c.v}>
            <circle cx={X0 + C * c.from + C / 2} cy={Y0 + C * c.to + C / 2} r="12" className={c.v > 0 ? 'disc-ink' : 'disc'} style={{ strokeWidth: 2 }} />
            <text x={X0 + C * c.from + C / 2} y={Y0 + C * c.to + C / 2} textAnchor="middle" className="lt-s lt-mid t-bold" style={c.v > 0 ? { fill: 'var(--panel)' } : undefined}>{c.text}</text>
          </g>
        ))}
      </FigSvg>
      <p className="leaf-readout" data-entries={m.cells.length} data-negative={neg} data-square-entries={m.sqCells.length}>{`add one to seat ${m.n}: ${m.cells.length} entries, ${neg} of them −1 · added twice: ${m.sqCells.length} entries`}</p>
    </Back>
  );
}

LeafSeats.meta = { id: ID, lenses: ['bits', 'primes'], learner: true };
/** the numbers the figure draws: the patterns by particles, the names of the eight corners in the chosen naming (seats.logic.js COUNTS, frontView) */
LeafSeats.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params, null), v = L.frontView(s);
  return { pattern: s.a, particles: L.particles(s.a), counts: L.COUNTS, names: s.mode, corners: v.corners.map(c => ({ pattern: c.a, particles: c.j, name: c.name })) };
};
LeafSeats.ready = () => !!logicOf(SLUG, NEEDS);
