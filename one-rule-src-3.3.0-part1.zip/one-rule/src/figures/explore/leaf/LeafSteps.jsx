// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-steps (shelf, under leaf 6; the section "ladders" of light): the front of the Octavo leaf "steps" redrawn with the V2 kit. One step of a piece of
// F along one direction, drawn three ways (engines/explore/leaves/steps.logic.js front: the kernel's product e_a e_S, its sign and target): on the tetrahedron
// whose corners are t, x, y, z (the piece is an edge; a drop runs to a corner, an add to a shaded triangle), on the labels 0 to 15 (source and target lit;
// even labels round, odd ones square) and on the 4-cube of the labels (one bit flips; the even half, the half-cube, ringed). The names switch renames the
// labels and the rule under the pictures: bits | numbers | primes (engines/explore/names.js). Step again shows the two roads of a second step of the same
// kind, + and −. Controls (ports of the Octavo face): the piece chips, the direction chips, drop | add, Step again, the names chips. Readouts: the rule, the
// key of the naming, the step as names (and, at research level, its term of ∇F = J and the equation it belongs to). At research level the back of the leaf:
// in mode math the Mathematician's way in, chosen by the page lens (geometry: the two roads of the piece; algebra: the sixteen terms e_a e_b, the twins of
// the two roads lit; topology: the two triangles of the edge walking it opposite ways, the table ∂∂ and 4 − 6 + 4 = 2; category: the cube of arrows with
// their signs); in mode phys the Physicist's line of charge in one space direction (Play), with the charge in a box and its change.
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Chips, PlayButton, r1, arrowHead, tx } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, useTicker, backOf, Back } from './leafKit.jsx';

const SLUG = 'steps', ID = 'leaf-steps';
const NEEDS = ['START', 'PIECES', 'AXES', 'MODES', 'front', 'setPiece', 'setDir', 'setOp', 'stepAgain', 'keyText', 'TETRA', 'CUBE', 'CUBE_EDGES', 'cubeAt', 'placeOf',
  'outward', 'geometry', 'algebra', 'topology', 'category', 'phys', 'START_PHYS', 'advanceTime', 'WAVE', 'eulerLine', 'CAT_COUNT', 'LINE', 'PHYS', 'roads', 'sgn', 'letters', 'ARROWS', 'CAT'];
const WAY = { geo: 'geometry', alg: 'algebra', top: 'topology', cat: 'category' };
const halo = { paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 4, strokeLinejoin: 'round' };

function startOf(L, params) {
  const pi = L.PIECES.findIndex(p => p.id === params.piece), a = L.AXES.indexOf(params.dir);
  return {
    s: { ...L.START, ...(pi >= 0 ? { pi } : {}), ...(a >= 0 ? { a } : {}), ...(params.op === 'drop' || params.op === 'add' ? { op: params.op } : {}), two: params.two === true },
    mode: L.MODES.includes(params.names) ? params.names : 'numbers'
  };
}
const subHtml = t => { const [a, b] = String(t).split('_'); return b ? <span>{a}<sub>{b}</sub></span> : <span>{a}</span>; };
/** a formula readout with its subscripts set low: e_t e_x, ∂_t², E_x */
const subs = t => String(t).split(/_([a-z]+)/).map((x, i) => (i % 2 ? <sub key={i}>{x}</sub> : x));
/** the term of ∇F = J a step is, typeset: +∂_y E_x */
const termHtml = (L, c) => { const P = L.PIECES[c.pi]; return <>{c.sign > 0 ? '+' : '−'}∂<sub>{L.AXES[c.a]}</sub>{P.kind}<sub>{P.axis}</sub></>; };
const arrowLine = (a, b, g0, g1) => { const dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L; return [a[0] + ux * g0, a[1] + uy * g0, b[0] - ux * g1, b[1] - uy * g1]; };

export default function LeafSteps(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Steps L={L} {...props} />;
}

/** the tetrahedron: corners t, x, y, z; the chosen edge thick and named (the electric edges meet at t, the magnetic ones make the opposite triangle; the
 *  piece chips name them all); the arrows of the step (drop: beside the edge to a corner; add: dashed into a shaded triangle) */
function Tetra({ L, d, walks = null, row, part }) {
  return (
    <FigSvg id={ID} row={row} part={part} viewBox="-18 -14 280 262" className="leaf-pic" style={{ flex: '1 1 165px', maxWidth: 330, minWidth: 0 }}>
      {d.shaded.map(t => <polygon key={'s' + t.to} points={t.pts.map(p => p.map(r1).join(',')).join(' ')} style={{ fill: 'var(--hi)', fillOpacity: 0.8 }} />)}
      {d.edges.map(e => <line key={e.i} x1={e.a[0]} y1={e.a[1]} x2={e.b[0]} y2={e.b[1]} data-piece={e.id} data-on={e.on ? 1 : 0} style={{ stroke: `var(--${e.move})`, strokeWidth: e.on ? 7 : 3.2, strokeLinecap: 'round', strokeDasharray: e.back && !e.on ? '3 5' : undefined, opacity: e.back && !e.on ? 0.8 : 1 }} />)}
      {walks ? walks.map(w => w.legs.map((l, j) => { const [x1, y1, x2, y2] = arrowLine(l.from, l.to, 3, 3); return <g key={w.tri + ':' + j}><line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="ln" style={{ strokeWidth: l.shared ? 3 : 1.6 }} /><path d={arrowHead(x1, y1, x2, y2, 8)} className="fill-ink" /></g>; })) : null}
      {d.arrows.map(a => {
        if (a.drop) { const o = [a.along[0] * 13, a.along[1] * 13], [x1, y1, x2, y2] = arrowLine([a.from[0] + o[0], a.from[1] + o[1]], [a.to[0] + o[0], a.to[1] + o[1]], 2, 7); return <g key={'a' + a.target} data-arrow="drop"><line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="ln" style={{ strokeWidth: 2.6 }} /><path d={arrowHead(x1, y1, x2, y2, 10)} className="fill-ink" /></g>; }
        const [x1, y1, x2, y2] = arrowLine(a.from, a.to, 6, 8);
        return <g key={'a' + a.target} data-arrow="add"><line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="ln ln-dash" style={{ strokeWidth: 2.6 }} /><path d={arrowHead(x1, y1, x2, y2, 10)} className="fill-ink" /><circle cx={r1(a.to[0])} cy={r1(a.to[1])} r="4" className="fill-ink" /></g>;
      })}
      {d.corners.map(c => <circle key={'c' + c.a} cx={c.at[0]} cy={c.at[1]} r={c.lit ? 8 : 5.5} className={c.lit ? 'sel' : 'disc'} />)}
      {d.corners.map(c => <text key={'n' + c.a} x={r1(c.at[0] + c.out[0] * 19)} y={r1(c.at[1] + c.out[1] * 19)} textAnchor="middle" className="lt-math lt-mid" style={{ fontSize: 20, fontStyle: 'italic' }}>{c.name}</text>)}
      {d.edge ? <text x={r1(d.edge.at[0] + d.edge.out[0] * 30)} y={r1(d.edge.at[1] + d.edge.out[1] * 30)} textAnchor="middle" className="lt-math lt-mid" style={{ fontSize: 20, fontWeight: 700, ...halo }}>{tx(d.edge.name)}</text> : null}
      {d.arrows.filter(a => a.tag).map(a => { const p = a.drop ? [a.to[0] + a.along[0] * 32, a.to[1] + a.along[1] * 32] : [a.to[0], a.to[1] - 15]; return <text key={'t' + a.target} x={r1(p[0])} y={r1(p[1])} textAnchor="middle" className="lt-mid" data-road={a.tag} style={{ fontSize: 19, fontWeight: 700, ...halo }}>{a.tag}</text>; })}
    </FigSvg>
  );
}

/** the labels 0 to 15, four to a row: an even label in a round cell, an odd one in a square cell; source and target lit */
function Grid({ L, v, mode, row }) {
  const C = 44, fs = mode === 'bits' ? 14 : 17;
  return (
    <FigSvg id={ID} row={row} part="the labels 0 to 15" viewBox={`-4 -4 ${4 * C + 8} ${4 * C + 8}`} className="leaf-pic" style={{ flex: '0 1 146px', maxWidth: 230, minWidth: 0 }}>
      {v.grid.map(g => {
        const x = g.col * C, y = g.row * C, cls = g.lit ? 'sel' : 'cell-box';
        return (
          <g key={g.v} data-label={g.v} data-lit={g.lit ? 1 : 0} data-even={g.even ? 1 : 0}>
            {g.even ? <circle cx={x + C / 2} cy={y + C / 2} r={C / 2 - 3} className={cls} style={g.from ? { strokeWidth: 3.6 } : undefined} />
              : <rect x={x + 3} y={y + 3} width={C - 6} height={C - 6} rx="6" className={cls} style={g.from ? { strokeWidth: 3.6 } : undefined} />}
            <text x={x + C / 2} y={y + C / 2} textAnchor="middle" className={'lt-mid' + (mode === 'bits' ? ' t-mono' : '')} style={{ fontSize: fs, fontWeight: g.lit ? 700 : 500, fontFamily: mode === 'bits' ? 'var(--font-mono)' : undefined }}>{g.text}</text>
          </g>
        );
      })}
    </FigSvg>
  );
}

/** the 4-cube of the labels: 32 thin edges, the even half ringed, the step's path, the lit labels named (bits: the flipped bit boxed) */
function Cube({ L, v, mode, row }) {
  const lit = v.cube.labels, cx = lit.reduce((s, l) => s + l.at[0], 0) / lit.length, cy = lit.reduce((s, l) => s + l.at[1], 0) / lit.length;
  const W = L.CUBE.w, H = L.CUBE.h, cw = mode === 'bits' ? 9 : 8.6, fs = 14.5;
  return (
    <FigSvg id={ID} row={row} part="the 4-cube of the labels" viewBox={`-22 -26 ${W + 44} ${H + 64}`} className="leaf-pic" style={{ flex: '1 1 300px', maxWidth: 440 }}>
      {L.CUBE_EDGES.map(([a, b]) => { const A = L.cubeAt(a), B = L.cubeAt(b); return <line key={a + '-' + b} x1={A[0]} y1={A[1]} x2={B[0]} y2={B[1]} style={{ stroke: 'var(--line-2)', strokeWidth: 1.1 }} />; })}
      {v.cube.path.map(([a, b]) => { const [x1, y1, x2, y2] = arrowLine(L.cubeAt(a), L.cubeAt(b), 8, 10); return <g key={'p' + a + '-' + b}><line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className="ln" style={{ strokeWidth: 2.6 }} /><path d={arrowHead(x1, y1, x2, y2, 8)} className="fill-ink" /></g>; })}
      {v.cube.dots.map(d => (
        <g key={d.v} data-label={d.v} data-even={d.even ? 1 : 0}>
          {d.even ? <circle cx={d.at[0]} cy={d.at[1]} r={d.lit ? 11 : 7} className="ln-m" style={{ strokeWidth: 1.4 }} /> : null}
          <circle cx={d.at[0]} cy={d.at[1]} r={d.lit ? 6.5 : 3.2} className={d.lit ? 'sel' : 'fill-muted'} style={d.lit ? { strokeWidth: 2 } : undefined} />
        </g>
      ))}
      {lit.map(l => {
        const dx = l.at[0] - cx, dy = l.at[1] - cy, n = Math.hypot(dx, dy) || 1, half = l.text.length * cw / 2;
        const px = Math.min(W + 20 - half, Math.max(-20 + half, l.at[0] + dx / n * 24)), py = Math.min(H + 12, Math.max(-14, l.at[1] + dy / n * 19));
        return (
          <g key={'l' + l.v} data-role={l.role}>
            {l.box >= 0 ? <rect x={r1(px - half + l.box * cw - 1.5)} y={r1(py - fs * 0.66)} width={r1(cw + 3)} height={r1(fs * 1.32)} rx="2.5" className="ln" style={{ strokeWidth: 1.6 }} data-flipped-bit={l.box} /> : null}
            {l.text.split('').map((ch, i) => <text key={i} x={r1(px - half + (i + 0.5) * cw)} y={r1(py)} textAnchor="middle" className="lt-mid" style={{ fontSize: fs, fontWeight: l.role === 'from' ? 700 : 600, fontFamily: mode === 'bits' ? 'var(--font-mono)' : undefined, ...halo }}>{ch}</text>)}
          </g>
        );
      })}
      <g className="fill-muted" style={{ fontSize: 13.5 }}>
        <circle cx={-12} cy={H + 26} r="6.5" className="ln-m" style={{ strokeWidth: 1.4 }} /><circle cx={-12} cy={H + 26} r="3" />
        <text x={-1} y={H + 26} className="lt-mid">even</text>
        <circle cx={48} cy={H + 26} r="3" /><text x={56} y={H + 26} className="lt-mid">odd</text>
      </g>
    </FigSvg>
  );
}

function Steps({ L, params = {}, lens = null, level = 'research', mode: pageMode = 'phys', row }) {
  const research = level !== 'learner';
  const [st, setSt] = useState(() => startOf(L, params));
  useEffect(() => { setSt(startOf(L, params)); }, [params.piece, params.dir, params.op, params.two, params.names]);   // eslint-disable-line react-hooks/exhaustive-deps
  const { s, mode } = st, set = f => setSt(x => ({ ...x, s: f(x.s) }));
  const v = L.front(s, mode), P = L.PIECES[s.pi], c = v.c;
  const opWord = s.op === 'drop' ? 'drop' : 'add';
  const step = !c.ok ? <>{subHtml(P.id)} · {opWord} {L.AXES[s.a]} · no step</>
    : !v.two ? <>{subHtml(P.id)} · {opWord} {L.AXES[s.a]} → {L.letters(c.to)} · {c.kind}</>
      : <>{subHtml(P.id)} · {v.R.list.map(r => `${L.letters(r.mid)} ${L.sgn(r.sign)}`).join(' · ')} → {L.letters(v.R.end)} · {v.R.total === 0 ? '0' : L.sgn(v.R.total)}</>;
  const back = backOf(level, pageMode);
  return (
    <div className="fig leaf leaf-steps">
      <div className="leaf-row" style={{ alignItems: 'center', columnGap: 14 }}>
        <Tetra L={L} d={v.tetra} row={row} part="the step on the tetrahedron" />
        <Grid L={L} v={v} mode={mode} row={row} />
        <Cube L={L} v={v} mode={mode} row={row} />
      </div>
      <p className="leaf-readout leaf-readout-big" aria-live="polite" data-rule={v.rule} data-ok={c.ok ? 1 : 0} data-two={v.two ? 1 : 0}>{v.rule}</p>
      <p className="leaf-readout muted" data-key={mode}>{L.keyText(mode)}</p>
      <p className="leaf-readout" data-step={c.ok ? c.to : 'none'}>{step}{research && c.ok && !v.two ? <> · {termHtml(L, c)} · {v.eq.name}</> : null}</p>
      <Controls label="the step">
        <span className="fig-group" role="group" aria-label="piece" data-param="piece">
          {L.PIECES.map((p, i) => <button key={p.id} type="button" className="fig-btn" data-param="piece" data-move={p.move} aria-pressed={s.pi === i} onClick={() => set(x => L.setPiece(x, i))} style={{ padding: '0 9px' }}><span style={{ borderBottom: `3px solid var(--${p.move})`, lineHeight: 1.25 }}>{subHtml(p.id)}</span></button>)}
        </span>
        <Chips label="direction" items={L.AXES.map((_, a) => a)} value={s.a} onPick={a => set(x => L.setDir(x, a))} render={a => L.AXES[a]} param="dir" />
        <Chips items={['drop', 'add']} value={s.op} onPick={op => set(x => L.setOp(x, op))} render={o => (o === 'drop' ? 'Drop' : 'Add')} param="op" aria="drop or add" />
        <button type="button" className="fig-btn" data-param="two" aria-pressed={v.two} disabled={v.againOff} onClick={() => set(x => L.stepAgain(x))}>Step again</button>
        <Chips label="names" items={L.MODES} value={mode} onPick={m => setSt(x => ({ ...x, mode: m }))} param="names" mono />
      </Controls>
      {back === 'math' ? <MathBack L={L} s={s} lens={lens} row={row} /> : back === 'phys' ? <PhysBack L={L} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back: the way in is the page lens (geometry, the default; algebra; topology; category) */
function MathBack({ L, s, lens, row }) {
  const way = WAY[lens] || 'geometry';
  if (way === 'algebra') {
    const R = L.roads(s.pi, s.op), [a, b] = L.front(s, 'numbers').two ? [R.list[0].first, R.list[0].second] : [s.a, s.a], al = L.algebra(a, b), C = 52, X0 = 34, Y0 = 30;
    return (
      <Back who="math" way={way}>
        <FigSvg id={ID} row={row} part="the sixteen terms of ∇∇" viewBox={`0 0 ${X0 + 4 * C + 6} ${Y0 + 4 * C + 6}`} style={{ maxWidth: 340 }}>
          {L.AXES.map((t, j) => <text key={'h' + j} x={X0 + j * C + C / 2} y={16} textAnchor="middle" className="lt-math">{'e'}<tspan dy="0.3em" style={{ fontSize: '72%' }}>{t}</tspan></text>)}
          {L.AXES.map((t, i) => <text key={'r' + i} x={14} y={Y0 + i * C + C / 2} textAnchor="middle" className="lt-math lt-mid">{'e'}<tspan dy="0.3em" style={{ fontSize: '72%' }}>{t}</tspan></text>)}
          {al.cells.map(x => (
            <g key={x.a + ',' + x.b} data-cell={x.a + ',' + x.b} data-on={x.on ? 1 : 0}>
              <rect x={X0 + x.b * C + 2} y={Y0 + x.a * C + 2} width={C - 4} height={C - 4} rx="9" className={x.on ? 'sel' : 'cell-box'} style={x.diag ? { strokeWidth: 3 } : undefined} />
              <text x={X0 + x.b * C + C / 2} y={Y0 + x.a * C + C / 2} textAnchor="middle" className="lt-math lt-mid" style={{ fontSize: 15 }}>{tx(x.text)}</text>
            </g>
          ))}
        </FigSvg>
        <p className="leaf-readout" data-formula="1">{subs(al.formula)}</p>
        <p className="leaf-readout">{subs(L.WAVE)}</p>
      </Back>
    );
  }
  if (way === 'topology') {
    const tp = L.topology(s.pi);
    return (
      <Back who="math" way={way}>
        <div className="leaf-back-row">
          <Tetra L={L} d={tp.drawing} walks={tp.walks} row={row} part="the two triangles of the edge" />
          <FigSvg id={ID} row={row} part="the table of ∂∂" viewBox="0 0 190 150" style={{ flex: '0 1 200px', maxWidth: 230 }}>
            <text x={18} y={18} textAnchor="middle" className="lt-math">∂∂</text>
            {tp.table.cols.map((cName, j) => <text key={'c' + j} x={52 + j * 36} y={18} textAnchor="middle" className="lt-math lt-s">{cName}</text>)}
            {tp.table.rows.map((rName, i) => <text key={'r' + i} x={18} y={44 + i * 28} textAnchor="middle" className="lt-math lt-mid">{rName}</text>)}
            {tp.table.cells.map((r, i) => r.map((x, j) => <text key={i + ':' + j} x={52 + j * 36} y={44 + i * 28} textAnchor="middle" className="lt-mid" data-zero={x === 0 ? 1 : 0}>{x}</text>))}
          </FigSvg>
        </div>
        <p className="leaf-readout">{L.eulerLine}</p>
      </Back>
    );
  }
  if (way === 'category') {
    const cg = L.category(0), q = cg.arrows;
    return (
      <Back who="math" way={way}>
        <FigSvg id={ID} row={row} part="the cube of arrows and their signs" viewBox={`-26 -26 ${L.CAT.w + 52} ${L.CAT.h + 52}`} style={{ maxWidth: 360 }}>
          {q.map(r => { const [x1, y1, x2, y2] = arrowLine(r.a, r.b, 22, 24); return <g key={r.from + ':' + r.i} data-road={r.road}><line x1={r1(x1)} y1={r1(y1)} x2={r1(x2)} y2={r1(y2)} className={r.road ? 'ln' : 'ln-m'} style={{ strokeWidth: r.road ? 3 : 1.6 }} /><path d={arrowHead(x1, y1, x2, y2, 8)} className={r.road ? 'fill-ink' : 'fill-muted'} /></g>; })}
          {q.map(r => { const mx = (r.a[0] + r.b[0]) / 2, my = (r.a[1] + r.b[1]) / 2, dx = r.b[0] - r.a[0], dy = r.b[1] - r.a[1], n = Math.hypot(dx, dy) || 1; return <text key={'s' + r.from + ':' + r.i} x={r1(mx + dy / n * 12)} y={r1(my - dx / n * 12)} textAnchor="middle" className="lt-mid" style={{ fontSize: 16, fontWeight: 700, ...halo }}>{r.tag}</text>; })}
          {cg.corners.map(k => <g key={'k' + k.v}><circle cx={k.at[0]} cy={k.at[1]} r="17" className="disc" /><text x={k.at[0]} y={k.at[1]} textAnchor="middle" className="lt-math lt-mid" style={{ fontSize: 13.5 }}>{k.name.replace(/ /g, '')}</text></g>)}
        </FigSvg>
        <p className="leaf-readout">{`${cg.roadTags.map(t => `${t.via} ${t.tag}`).join(' · ')} · ${cg.good} of ${L.CAT_COUNT.squares} squares · ${L.CAT_COUNT.cancelling} of ${L.CAT_COUNT.signings}`}</p>
      </Back>
    );
  }
  const g = L.geometry(s.pi, s.op === 'drop' ? 'down' : 'up');
  return (
    <Back who="math" way={way}>
      <Tetra L={L} d={g.drawing} row={row} part="the two roads of the edge" />
      <p className="leaf-readout">{g.R.list.map(r => `${L.letters(r.mid)} ${L.sgn(r.sign)}`).join(' · ') + ` → ${L.letters(g.R.end)} · ${g.cancel} of ${g.pieces}`}</p>
    </Back>
  );
}

/** the Physicist's back: one line of space, the hump of E moving along it, the charge in each cell (bars), the current (arrows), a box with its charge */
function PhysBack({ L, row }) {
  const [ps, setPs] = useState(L.START_PHYS);
  const player = useTicker(dt => setPs(x => L.advanceTime(x, dt)), 0.2);
  const p = L.phys(ps), X = L.PHYS.X, X0 = X(0), X1 = X(L.LINE.L), H = L.PHYS.h;
  return (
    <Back who="phys">
      <FigSvg id={ID} row={row} part="one line of space: the field, the charge, the current" viewBox={`0 0 ${L.PHYS.w} ${H}`} style={{ maxWidth: 520 }}>
        <rect x={r1(p.box.x)} y="8" width={r1(p.box.w)} height={H - 16} style={{ fill: 'var(--hi)', fillOpacity: 0.55 }} />
        <line x1={r1(p.box.x)} y1="8" x2={r1(p.box.x)} y2={H - 8} className="ln" style={{ strokeWidth: 2 }} />
        <line x1={r1(p.box.x + p.box.w)} y1="8" x2={r1(p.box.x + p.box.w)} y2={H - 8} className="ln" style={{ strokeWidth: 2 }} />
        <line x1={X0} y1={L.PHYS.eY + L.PHYS.eH} x2={X1} y2={L.PHYS.eY + L.PHYS.eH} style={{ stroke: 'var(--line-2)', strokeWidth: 1.2 }} />
        <path d={p.curve} className="ln ln-round" style={{ strokeWidth: 2.6 }} />
        <line x1={X0} y1={L.PHYS.qY} x2={X1} y2={L.PHYS.qY} style={{ stroke: 'var(--line-2)', strokeWidth: 1.2 }} />
        {p.bars.map(b => (b.h > 0.3 ? <rect key={b.i} x={r1(b.x)} y={r1(b.y)} width={r1(b.w)} height={r1(b.h)} className={b.q >= 0 ? 'fill-muted' : 'cell-box'} style={{ stroke: 'var(--muted)', strokeWidth: 1.4 }} data-charge={b.q >= 0 ? '+' : '−'} /> : null))}
        <line x1={X0} y1={L.PHYS.jY} x2={X1} y2={L.PHYS.jY} style={{ stroke: 'var(--line-2)', strokeWidth: 1.2 }} />
        {p.arrows.map(a => (Math.abs(a.len) > 1.5 ? <g key={a.k}><line x1={r1(a.x - a.len / 2)} y1={L.PHYS.jY} x2={r1(a.x + a.len / 2)} y2={L.PHYS.jY} className="ln" style={{ strokeWidth: a.end ? 3.4 : 2.2 }} /><path d={arrowHead(a.x - a.len / 2, L.PHYS.jY, a.x + a.len / 2, L.PHYS.jY, Math.min(8, Math.abs(a.len) / 2))} className="fill-ink" /></g> : null))}
        <text x={X0} y={L.PHYS.eY - 8} className="lt-mid lt-math fill-muted" style={{ fontSize: 18, ...halo }}>E</text>
        <text x={X0} y={L.PHYS.qY - 52} className="lt-mid lt-math fill-muted" style={{ fontSize: 18, ...halo }}>ρ</text>
        <text x={X0} y={L.PHYS.jY - 22} className="lt-mid lt-math fill-muted" style={{ fontSize: 18, ...halo }}>J</text>
      </FigSvg>
      <p className="leaf-readout" aria-live={player.playing ? 'off' : 'polite'}>{`t = ${p.tText} · ${p.qText} · ${p.balance}`}</p>
      <Controls label="the line"><PlayButton player={player} /></Controls>
    </Back>
  );
}

LeafSteps.meta = { id: ID, lenses: ['geo', 'alg', 'top', 'cat'], learner: true };
/** the numbers the figure draws: the piece, the direction, the step (its target, sign, kind), the two roads, the rule in the chosen names */
LeafSteps.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const { s, mode } = startOf(L, params), v = L.front(s, mode), c = v.c;
  return { piece: L.PIECES[s.pi].id, dir: L.AXES[s.a], op: s.op, two: v.two, names: mode, step: c.ok, from: c.from, to: c.to, sign: c.sign, kind: c.kind, term: v.term, roads: v.R ? v.R.list.map(r => ({ via: r.mid, end: r.end, sign: r.sign })) : null, rule: v.rule };
};
LeafSteps.ready = () => !!logicOf(SLUG, NEEDS);
