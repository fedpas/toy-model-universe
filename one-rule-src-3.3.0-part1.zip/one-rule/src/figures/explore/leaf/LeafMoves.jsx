// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-moves (Explore, leaf 2): the front of the Octavo leaf "moves" redrawn with the V2 kit. A ball on a spring of strength k and its path in the plane
// of position and speed, both from engines/explore/leaves/moves.logic.js (frontView: the move X of the spring, its square X² by the kernel, its class −1, 0, +1;
// the ball's position and speed from exp(tX); orbitPts and the three faint paths GHOST of k = 1, 0, −1). The class is told by mark and word: a ring "−1" (turn),
// a bar "0" (slide), a diamond "+1" (boost); the ball and the legend wear the mark. Controls: the chips k = −2 … 2 by 0.5 (Octavo's slider) and Play (paused
// at first; Step under reduced motion). Readouts: k, X² and the class name, as the logic gives them. At research level in mode math, the back of the Octavo
// leaf: the plane of the moves b e₂ + c e₁₂ by the sign of their square, with the spring of strength k at its point (mapView).
import React, { useEffect, useMemo, useState } from 'react';
import { FigSvg, Controls, Chips, PlayButton, r1 } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, MoveMark, useTicker, nf, backOf, Back } from './leafKit.jsx';

const SLUG = 'moves', ID = 'leaf-moves';
const NEEDS = ['START', 'MOVES', 'SPEED', 'GHOST', 'frontView', 'advance', 'setStrength', 'orbitPts', 'toPath', 'spring', 'mapView', 'MAP_ORIGIN'];
const KS = [-2, -1.5, -1, -0.5, 0, 0.5, 1, 1.5, 2];
const kvOf = params => (KS.includes(params.k) ? Math.round(params.k * 10) : null);
function startOf(L, params) { const kv = kvOf(params); return kv === null ? L.START : L.setStrength(L.START, kv); }
const GHOST_STYLE = [{ strokeDasharray: 'none' }, { strokeDasharray: '2 5', strokeLinecap: 'round' }, { strokeDasharray: '8 6' }];   // turn, slide, boost

export default function LeafMoves(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Moves L={L} {...props} />;
}

function Moves({ L, params = {}, level = 'research', mode = 'phys', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.k]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = useTicker(dt => setS(x => L.advance(x, dt * L.SPEED)));
  const v = L.frontView(s), k = s.kv / 10;
  const path = useMemo(() => L.toPath(L.orbitPts(s.kv / 10)), [L, s.kv]);
  // a mark on each faint path, at a point of it inside the picture (turn, slide, boost: k = 1, 0, −1)
  const ghostMarks = useMemo(() => [1, 0, -1].map((kk, i) => {
    const pts = L.orbitPts(kk).map(p => [150 + 50 * p[0], 150 - 50 * p[1]]).filter(([x, y]) => x > 24 && x < 276 && y > 24 && y < 276);
    const p = pts.length ? pts[Math.floor(pts.length * [0.3, 0.8, 0.75][i])] : null;
    return p ? { cls: [-1, 0, 1][i], x: p[0], y: p[1] } : null;
  }).filter(Boolean), [L]);
  return (
    <div className="fig leaf leaf-moves">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="a ball on a spring" viewBox="0 0 360 128" className="leaf-pic">
          {[-1, 0, 1].map((c, i) => <MoveMark key={c} cls={c} x={22 + 118 * i} y={15} s={7} on={c === v.cls} word={L.MOVES[c + 1]} />)}
          <g transform="translate(0 1) scale(0.75)">
            <line x1="26" y1="62" x2="26" y2="128" className="ln ln-round" style={{ strokeWidth: 4 }} />
            <line x1="18" y1="132" x2="470" y2="132" className="ln" style={{ strokeWidth: 2 }} />
            <line x1="250" y1="76" x2="250" y2="140" className="ln-m ln-dash" />
            {v.hasSpring ? <polyline points={v.spring} className="ln ln-round" style={{ strokeWidth: 2.5, strokeDasharray: v.dash }} /> : null}
            <g style={{ opacity: v.op }}>
              <circle cx={r1(v.bx)} cy="112" r="19" className="disc" style={{ strokeWidth: 2.5 }} />
              <MoveMark cls={v.cls} x={v.bx} y={112} s={7} label={false} />
            </g>
          </g>
          <text x="187.5" y="122" textAnchor="middle" className="lt-s t-muted">rest</text>
        </FigSvg>
        <FigSvg id={ID} row={row} part="position against speed" viewBox="0 0 300 300" className="leaf-pic" style={{ maxWidth: 340 }}>
          <defs><clipPath id="leaf-moves-clip"><rect x="0" y="0" width="300" height="300" /></clipPath></defs>
          <rect x="0.5" y="0.5" width="299" height="299" rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
          <line x1="0" y1="150" x2="300" y2="150" className="ln-l" />
          <line x1="150" y1="0" x2="150" y2="300" className="ln-l" />
          <text x="156" y="18" className="lt-s t-muted">speed</text>
          <text x="292" y="168" textAnchor="end" className="lt-s t-muted">position</text>
          <g clipPath="url(#leaf-moves-clip)">
            {L.GHOST.map((d, i) => <path key={i} d={d} className="ln-m" style={{ strokeWidth: 1.6, opacity: 0.55, ...GHOST_STYLE[i] }} />)}
            <path d={path} className="ln ln-round" style={{ strokeWidth: 3.5, ...GHOST_STYLE[v.cls + 1] }} data-class={v.cls} />
          </g>
          {ghostMarks.map(m => <MoveMark key={m.cls} cls={m.cls} x={m.x} y={m.y} s={5.5} label={false} on={m.cls === v.cls} />)}
          <circle cx={r1(v.dot.x)} cy={r1(v.dot.y)} r="7.5" className="disc-ink" style={{ opacity: v.op }} />
        </FigSvg>
      </div>
      <p className="leaf-readout" aria-live="polite" data-k={v.k} data-square={v.X2} data-class={v.cls}>
        {research ? `k = ${nf(v.k, 1)} · X² = ${nf(v.X2, 2)} → ${v.name}` : `k = ${nf(v.k, 1)} → ${v.name}`}
      </p>
      <Controls label="the spring">
        <Chips label="spring strength k" items={KS} value={k} onPick={kk => setS(x => L.setStrength(x, Math.round(kk * 10)))} render={kk => nf(kk, kk % 1 ? 1 : 0)} param="k" mono />
        <PlayButton player={player} />
      </Controls>
      {backOf(level, mode) === 'math' ? <MapBack L={L} kv={s.kv} row={row} /> : null}
    </div>
  );
}

/** the Mathematician's back (Octavo's Say): the plane of the moves b e₂ + c e₁₂; their square b² − c² is negative in the top and bottom wedges (turns), positive
 *  in the side wedges (boosts) and zero on the two diagonals (slides); the springs lie on the dashed line, the spring of strength k at its point
 *  (moves.logic.js mapView, MAP_ORIGIN: b across, c up) */
function MapBack({ L, kv, row }) {
  const m = L.mapView(kv), O = L.MAP_ORIGIN, X = b => O.x + O.unit * b, Y = c => O.y - O.unit * c, P = pts => pts.map(([b, c]) => `${r1(X(b))},${r1(Y(c))}`).join(' ');
  return (
    <Back who="math" way="geometry">
      <FigSvg id={ID} row={row} part="the map of the moves" viewBox="0 0 360 340">
        <rect x="0.5" y="0.5" width="359" height="339" rx="12" className="fill-panel" style={{ stroke: 'var(--line)' }} />
        <polygon points={P([[0, 0], [-1, 1], [-1, 2], [2, 2]])} className="fill-soft" />
        <polygon points={P([[0, 0], [1, -1], [-1, -1]])} className="fill-soft" />
        <line x1="20" y1={Y(0)} x2="340" y2={Y(0)} className="ln-l" />
        <line x1={X(0)} y1="20" x2={X(0)} y2="335" className="ln-l" />
        <line x1={X(-1)} y1={Y(2)} x2={X(2)} y2={Y(-1)} className="ln-m ln-dash" style={{ strokeWidth: 2 }} />
        <line x1={X(-1)} y1={Y(-1)} x2={X(2)} y2={Y(2)} className="ln" style={{ strokeWidth: 3 }} />
        <line x1={X(-1)} y1={Y(1)} x2={X(1)} y2={Y(-1)} className="ln" style={{ strokeWidth: 3 }} />
        <MoveMark cls={-1} x={150} y={70} s={7} word={L.MOVES[0]} />
        <MoveMark cls={-1} x={84} y={312} s={7} word={L.MOVES[0]} />
        <MoveMark cls={1} x={248} y={212} s={7} word={L.MOVES[2]} />
        <MoveMark cls={1} x={36} y={242} s={6} word={L.MOVES[2]} />
        <MoveMark cls={0} x={268} y={98} s={7} word={L.MOVES[1]} />
        <text x="44" y="46" className="lt-s t-muted">springs</text>
        <text x="334" y="250" textAnchor="end" className="lt-m t-muted">b</text>
        <text x="138" y="22" className="lt-m t-muted">c</text>
        <circle cx={r1(m.x)} cy={r1(m.y)} r="12" className="disc" style={{ strokeWidth: 2.5 }} data-b={m.b} data-c={m.c} />
        <MoveMark cls={m.cls} x={m.x} y={m.y} s={5} label={false} />
      </FigSvg>
      <p className="leaf-readout" data-square={m.X2} data-class={m.cls}>{typeof m.line === 'string' && m.line ? m.line : `b = ${nf(m.b, 2)}, c = ${nf(m.c, 2)}, X² = ${nf(m.X2, 2)} · ${m.name}`}</p>
    </Back>
  );
}

LeafMoves.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the move of the spring, its square and its class (moves.logic.js spring) */
LeafMoves.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const sp = L.spring(startOf(L, params).kv);
  return { k: sp.k, move: [sp.a, sp.b, sp.c], square: sp.X2, cls: sp.cls, name: sp.name };
};
LeafMoves.ready = () => !!logicOf(SLUG, NEEDS);
