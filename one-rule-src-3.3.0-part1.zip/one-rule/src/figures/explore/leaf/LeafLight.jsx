// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure leaf-light (Explore, leaf 6): the front of the Octavo leaf "light" redrawn with the V2 kit. p plus switches and q minus switches (2 ≤ p + q ≤ 5); one
// switch is called time (the one that stands alone, else the first) and ripples are sent every way from the middle of a pond (engines/explore/leaves/light.logic.js
// frontView: the squares of the switches by the kernel, the speed of the ripple heading each way, the crests at time t, the shape they reach at t = 1, the kind
// of wave by schullerEngine.waveKind). A crest on the cone (speed 1) is a filled dot, another speed a ring; a ripple that does not travel stays in the middle.
// Beside the pond: the row of switches with the one called time, the mark of the kind (a ring, a dot or two lobes: a shape, never a colour), and the map of
// every count of switches (CELLS), Lorentzian cells with a thick edge. Controls (ports of the Octavo face): the steppers p and q, a tap on a cell of the map,
// and Play (paused at first). Readouts: the cell, the switch called time, the kind's name and t.
import React, { useEffect, useState } from 'react';
import { FigSvg, Controls, Stepper, PlayButton, r1, sub } from '../../kit.jsx';
import { logicOf, LeafPlaceholder, pickProps, useTicker, intIn, nf } from './leafKit.jsx';

const SLUG = 'light', ID = 'leaf-light';
const NEEDS = ['START', 'POND', 'CELLS', 'MARK_PATH', 'MAX_EACH', 'canSet', 'setCounts', 'advance', 'frontView'];
function startOf(L, params) {
  let p = intIn(params.p, 0, 5, L.START.p), q = intIn(params.q, 0, 5, L.START.q);
  if (typeof params.cell === 'string' && /^\d,\d$/.test(params.cell)) [p, q] = params.cell.split(',').map(Number);
  return L.canSet(p, q) ? { ...L.START, p, q } : L.START;
}
/** the mark of a kind of wave in a 24 × 24 box (the logic's MARK_PATH), placed at (x, y) with side s */
function KindMark({ L, mark, x, y, s = 24, on = false }) {
  const k = s / 24;
  return (
    <g transform={`translate(${r1(x - s / 2)} ${r1(y - s / 2)}) scale(${k})`} className="leaf-kind" data-mark={mark}>
      <path d={L.MARK_PATH[mark]} className={mark === 'dot' ? 'fill-ink' : 'ln ln-round'} style={{ strokeWidth: 2.4 / k * (on ? 1.15 : 1) }} />
    </g>
  );
}

export default function LeafLight(props) {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return <LeafPlaceholder id={ID} row={props.row} slug={SLUG} needs={NEEDS} />;
  return <Light L={L} {...props} />;
}

function Light({ L, params = {}, level = 'research', row }) {
  const research = level !== 'learner';
  const [s, setS] = useState(() => startOf(L, params));
  useEffect(() => { setS(startOf(L, params)); }, [params.p, params.q, params.cell]);   // eslint-disable-line react-hooks/exhaustive-deps
  const player = useTicker(dt => setS(x => L.advance(x, dt)), 0.2);
  const v = L.frontView(s), set = (p, q) => setS(x => L.setCounts(x, p, q));
  const { cx, cy, U } = L.POND, one = v.n === 2;
  const nameOf = i => 'e' + sub(i + 1);
  const ROLE = { time: 'time', across: '→', up: '↑' };
  const G = 46, mx0 = 64, my0 = 150, nums = Array.from({ length: L.MAX_EACH + 1 }, (_, i) => i);
  return (
    <div className="fig leaf leaf-light">
      <div className="leaf-row">
        <FigSvg id={ID} row={row} part="ripples in a pond" viewBox="0 0 400 400" className="leaf-pic leaf-w400">
          {one ? (
            <g>
              <rect x={cx - U - 16} y={cy - 30} width={2 * U + 32} height="60" rx="30" className="fill-faint ln-l" style={{ fill: 'var(--panel)' }} />
              <line x1={cx - U - 6} y1={cy} x2={cx + U + 6} y2={cy} className="ln-l ln-dash" />
              <circle cx={cx + U + 2} cy={cy - 56} r="15" className="disc" />
              <text x={cx + U + 2} y={cy - 56} textAnchor="middle" className="lt-l lt-mid">{v.axisSigns[0]}</text>
            </g>
          ) : (
            <g>
              <circle cx={cx} cy={cy} r={U + 12} className="ln-l" style={{ fill: 'var(--panel)' }} />
              <line x1={cx - U - 12} y1={cy} x2={cx + U + 12} y2={cy} className="ln-l ln-dash" />
              <line x1={cx} y1={cy - U - 12} x2={cx} y2={cy + U + 12} className="ln-l ln-dash" />
              <circle cx={cx + U + 26} cy={cy} r="15" className="disc" />
              <text x={cx + U + 26} y={cy} textAnchor="middle" className="lt-l lt-mid">{v.axisSigns[0]}</text>
              <circle cx={cx} cy={cy - U - 26} r="15" className="disc" />
              <text x={cx} y={cy - U - 26} textAnchor="middle" className="lt-l lt-mid">{v.axisSigns[1]}</text>
              {v.guide ? <path d={v.guide} className="ln-m ln-dot" style={{ strokeWidth: 2 }} /> : null}
            </g>
          )}
          <circle cx={cx} cy={cy} r="6" className="ln-m" style={{ strokeWidth: 2 }} />
          {v.stuck ? <g style={{ opacity: v.op }} data-stuck="1"><circle cx={cx} cy={cy} r="16" className="ln ln-dash" style={{ strokeWidth: 2 }} /><circle cx={cx} cy={cy} r="9" className="fill-ink" /></g> : null}
          {v.dots.map(d => <circle key={d.deg} cx={r1(d.x)} cy={r1(d.y)} r={one ? 10 : 6.5} className={d.onCone ? 'disc-ink' : 'disc'} style={{ opacity: v.op }} data-on-cone={d.onCone ? 1 : 0} />)}
          <text x="10" y="22" className="t-mono lt-s t-muted">{v.tText}</text>
        </FigSvg>
        <FigSvg id={ID} row={row} part="the switches and the map of every count" viewBox="0 0 360 432" className="leaf-pic" style={{ maxWidth: 400 }}>
          {v.switches.map((sw, i) => (
            <g key={sw.i} data-switch={sw.i} data-role={sw.role || 'none'}>
              <circle cx={30 + 52 * i} cy={28} r={17} className="disc" style={{ strokeWidth: sw.alone ? 3.5 : 1.6 }} />
              <text x={30 + 52 * i} y={28} textAnchor="middle" className="lt-l lt-mid">{sw.sign}</text>
              <text x={30 + 52 * i} y={64} textAnchor="middle" className={sw.role === 'time' ? 'lt-s t-bold' : 'lt-s t-muted'}>{ROLE[sw.role] || ''}</text>
            </g>
          ))}
          <KindMark L={L} mark={v.K.mark} x={26} y={96} s={26} on />
          <text x={48} y={96} className="lt-m lt-mid t-bold" data-kind={v.kind}>{research ? v.kind : v.K.id}</text>
          <text x={mx0 + G * 3} y={my0 - 26} textAnchor="middle" className="lt-s t-muted">plus →</text>
          <text x={12} y={my0 + G * 3} textAnchor="middle" className="lt-s t-muted" transform={`rotate(90 12 ${my0 + G * 3})`}>minus →</text>
          {nums.map(i => <text key={'h' + i} x={mx0 + G * i} y={my0 - 8} textAnchor="middle" className="t-mono lt-s t-muted">{i}</text>)}
          {nums.map(i => <text key={'v' + i} x={36} y={my0 + G * i + G / 2} textAnchor="middle" className="t-mono lt-s t-muted lt-mid">{i}</text>)}
          {L.CELLS.map(c => {
            const on = c.p === s.p && c.q === s.q, x = mx0 + G * c.p, y = my0 + G * c.q + G / 2;
            return (
              <g key={c.p + ',' + c.q} {...pickProps('cell', `${c.p} plus, ${c.q} minus: ${c.K.id}`, on, () => set(c.p, c.q))} data-cell={`${c.p},${c.q}`} data-light={c.light ? 1 : 0}>
                <rect x={x - 20} y={y - 20} width="40" height="40" rx="8" className="pick-ring" style={on ? undefined : { strokeWidth: c.light ? 3 : 1.2, stroke: c.light ? 'var(--fg)' : 'var(--line)' }} />
                <KindMark L={L} mark={c.K.mark} x={x} y={y} s={22} />
              </g>
            );
          })}
        </FigSvg>
      </div>
      <p className="leaf-readout" aria-live="polite" data-p={s.p} data-q={s.q} data-time={v.time} data-alone={v.alone ? 1 : 0}>
        {research
          ? `Cl(${s.p},${s.q}) · time ${nameOf(v.time)}${v.alone ? '' : ' (none alone)'} · ${v.kind} · ${v.tText}`
          : `${s.p} plus · ${s.q} minus · ${v.K.id}`}
      </p>
      <Controls label="the switches">
        <Stepper label="plus" value={s.p} min={v.pMinusOff ? s.p : s.p - 1} max={v.pPlusOff ? s.p : s.p + 1} onChange={p => set(p, s.q)} param="p" />
        <Stepper label="minus" value={s.q} min={v.qMinusOff ? s.q : s.q - 1} max={v.qPlusOff ? s.q : s.q + 1} onChange={q => set(s.p, q)} param="q" />
        <PlayButton player={player} />
      </Controls>
    </div>
  );
}

LeafLight.meta = { id: ID, lenses: [], learner: true };
/** the numbers the figure draws: the squares of the switches, the one called time, the speed of each heading (null: it does not travel), the kind */
LeafLight.data = (params = {}) => {
  const L = logicOf(SLUG, NEEDS);
  if (!L) return { leaf: SLUG, logic: 'missing' };
  const s = startOf(L, params), v = L.frontView(s);
  return { p: s.p, q: s.q, squares: v.sq, time: v.time, alone: v.alone, kind: v.kind, headings: v.headings.map(h => ({ deg: h.deg, speed: h.speed })) };
};
LeafLight.ready = () => !!logicOf(SLUG, NEEDS);
