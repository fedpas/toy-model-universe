// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/leaf/leafKit.jsx — what the ten leaf pictures share. The ported leaf logic is looked up by slug in LEAF_LOGIC
// (engines/explore/index.js, interface 16): every number a leaf picture prints comes from it, a picture only draws and formats. While a logic
// is missing, a leaf is not registered (index.js) and LeafPlaceholder names what is missing. The three moves are told by mark and word, never by
// colour: turn = a ring with "−1", slide = a bar with "0", boost = a diamond with "+1" (classes mv-turn, mv-slide, mv-boost). useTicker is the
// clock of a moving picture: paused until Play, and under reduced motion it never runs by itself (Play becomes Step).
import React, { useEffect, useRef, useState } from 'react';
import { LEAF_LOGIC } from '../../../../engines/explore/index.js';
import { FigSvg, useReducedMotion, r1 } from '../../kit.jsx';

/** the logic module of a leaf when it exports every name in needs, else null */
export function logicOf(slug, needs = []) {
  const L = LEAF_LOGIC ? LEAF_LOGIC[slug] : null;
  return L && needs.every(k => L[k] !== undefined) ? L : null;
}
/** the names in needs that the logic of a leaf does not export (all of them when the module is missing) */
export function missingOf(slug, needs = []) {
  const L = LEAF_LOGIC ? LEAF_LOGIC[slug] : null;
  return L ? needs.filter(k => L[k] === undefined) : needs.slice();
}

/** what a leaf draws while its logic is missing: the figure id and the names it waits for (no number, no claim) */
export function LeafPlaceholder({ id, row, slug, needs }) {
  const miss = missingOf(slug, needs);
  return (
    <div className="fig leaf leaf-missing">
      <FigSvg id={id} row={row} part="not drawn yet" viewBox="0 0 360 120">
        <rect x="2" y="2" width="356" height="116" rx="8" className="leaf-ph" />
        <text x="180" y="50" textAnchor="middle" className="t-head">{id}</text>
        <text x="180" y="74" textAnchor="middle" className="t-muted">the logic of this leaf is not ported yet</text>
        <text x="180" y="96" textAnchor="middle" className="t-mono t-muted">{miss.slice(0, 4).join(', ')}{miss.length > 4 ? ' …' : ''}</text>
      </FigSvg>
    </div>
  );
}

/** the props of a pick drawn in SVG (a <g> that acts as a button): marked with data-param, reachable by Tab, Enter and Space; pressed null for an action */
export function pickProps(param, label, pressed, onPick, extra = {}) {
  return {
    role: 'button', tabIndex: 0, 'aria-label': label, ...(pressed === null ? {} : { 'aria-pressed': !!pressed }), 'data-param': param, className: 'leaf-pick' + (pressed ? ' is-on' : ''),
    onClick: onPick, onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(); } }, ...extra,
  };
}

export const MOVE_WORD = { '-1': 'turn', 0: 'slide', 1: 'boost' };
export const signText = cls => (cls < 0 ? '−1' : cls > 0 ? '+1' : '0');
/** the mark of a sign class cls ∈ {−1, 0, +1}: a ring (−1), a bar (0), a diamond (+1), with the sign printed at its right when label */
export function MoveMark({ cls, x, y, s = 8, on = false, label = true, word = null }) {
  const k = cls < 0 ? 'turn' : cls > 0 ? 'boost' : 'slide', d = s * 1.3;
  return (
    <g className={`mv mv-${k}${on ? ' is-on' : ''}`} transform={`translate(${r1(x)} ${r1(y)})`}>
      {cls < 0 ? <circle cx="0" cy="0" r={s} />
        : cls > 0 ? <path d={`M0 ${r1(-d)} L${r1(d)} 0 L0 ${r1(d)} L${r1(-d)} 0 Z`} />
          : <rect x={r1(-d)} y={r1(-s * 0.42)} width={r1(2 * d)} height={r1(s * 0.84)} rx="1.5" />}
      {label ? <text x={r1(d + 5)} y="4.5" className="t-mono mv-sign">{signText(cls)}</text> : null}
      {word ? <text x={r1(d + 5 + (label ? 22 : 0))} y="4.5" className="mv-word">{word}</text> : null}
    </g>
  );
}

/** the clock of a moving picture: tick(dt) on each animation frame while playing (dt in seconds, at most 0.05); paused at first; under reduced motion
 *  it never runs by itself and step() advances by stepDt. The returned object fits the kit's PlayButton ({ playing, reduced, play, step }). */
export function useTicker(tick, stepDt = 0.25) {
  const reduced = useReducedMotion();
  const [playing, setPlaying] = useState(false);
  const ref = useRef(tick);
  ref.current = tick;
  useEffect(() => {
    if (!playing || reduced || typeof window === 'undefined' || !window.requestAnimationFrame) return undefined;
    let id = 0, last = null;
    const loop = ts => { if (last !== null) ref.current(Math.min(0.05, Math.max(0, (ts - last) / 1000))); last = ts; id = window.requestAnimationFrame(loop); };
    id = window.requestAnimationFrame(loop);
    return () => window.cancelAnimationFrame(id);
  }, [playing, reduced]);
  useEffect(() => { if (reduced) setPlaying(false); }, [reduced]);
  return { playing, reduced, play: () => setPlaying(p => !p), step: () => ref.current(stepDt), stop: () => setPlaying(false) };
}

/** which back of the Octavo leaf a picture adds at research level: the Mathematician's (mode math) or the Physicist's (mode phys, the default);
 *  none at learner level, where Explore is played on the front (EXPLORE_PLAN §0: front / back = learner / research; interface 18) */
export const backOf = (level, mode) => (level === 'learner' ? null : mode === 'math' ? 'math' : 'phys');
/** the panel of a back picture: who draws it and, for the Mathematician, the way in (a name, never a claim) */
export function Back({ who, way, children }) {
  return (
    <section className="leaf-back" data-back={who}>
      <p className="leaf-back-who">{who === 'math' ? 'Mathematician' : 'Physicist'}{way ? <span className="leaf-back-way">{` · ${way}`}</span> : null}</p>
      {children}
    </section>
  );
}

/** a number with a true minus sign and d decimals (−0 printed as 0) */
export const nf = (x, d = 1) => { const t = Math.abs(x).toFixed(d); return (x < 0 && Number(t) !== 0 ? '−' : '') + t; };
/** the integer param v when it is one of the allowed values, else the default */
export const intIn = (v, lo, hi, d) => (Number.isInteger(v) && v >= lo && v <= hi ? v : d);
/** the params of figures.json without their non-enumerable members (the data download wants plain JSON) */
export const plain = x => JSON.parse(JSON.stringify(x, (k, v) => (typeof v === 'number' && !Number.isFinite(v) ? null : v)));
