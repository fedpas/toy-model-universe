// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/lens/index.js — the three lens explorers (owner X3): lens-simplex-maxwell (A), lens-demicube-moves (B), lens-cube-maxwell (C), with their
// stylesheet (bundled into dist/app.css by build.sh; the render test loads .css as empty). Seeds: content/explore/figures.lens.json; numbers: engines/explore/lens.js.
import './lens.css';
import SimplexMaxwell from './SimplexMaxwell.jsx';
import DemicubeMoves from './DemicubeMoves.jsx';
import CubeMaxwell from './CubeMaxwell.jsx';

export const LENS_FIGURES = {
  'lens-simplex-maxwell': SimplexMaxwell,
  'lens-demicube-moves': DemicubeMoves,
  'lens-cube-maxwell': CubeMaxwell,
};
