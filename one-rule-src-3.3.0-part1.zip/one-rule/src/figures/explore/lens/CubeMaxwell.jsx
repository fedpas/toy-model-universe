// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure lens-cube-maxwell (Explore, lens explorer C; docs/EXPLORE_PLAN.md §2.6 C, §1 (c); round 5: the physics, D29 and interface 24): the n-cube of the labels of
// Cl(k, d), n = k + d = 2…7 with k, d <= 4 (the 15 stored splits of maxwell.json), in columns by grade (an oblique projection of the cube for n <= 4): layer 1 = the
// sources (ρ, Jx …; ρ filled, J ring), layer 2 = the components of F by role (Ex, Bz, T12 …; E filled, B ring, T square), layer 3 = the identities (Faraday z, no
// monopole, dF t1 t2 x …: the stored names of the equations whose targets they are) — each corner with its stored name and, under it, its label in the printing the
// lens asks for (every corner up to n = 4; at n = 5 the sources and components; above, the picked corner and its partners; every corner as a tooltip). The moves that leave layer 2 are the
// terms of the equations: solid down to layer 1 (a contraction), dashed up to layer 3 (a wedge); picking a corner lists its equations (a component: the equations
// it appears in, with the sign of its term; a source or an identity: its own equation — KaTeX at research level, words at learner level: physics.jsx PhysicsNote)
// and draws their terms heavier. The picked axis b shows the step e_b e_a = ± e_{a xor b} with the kernel's sign. Numbers from engines/explore/lens.js cubeMaxwell /
// stepOf (tests/explore/lens.test.mjs: all 15 cells; counts 2, 9, 24, 50, 90, 147; the edge signs the Jordan–Wigner string); names from cellPhysics
// (tests/explore/physics.test.mjs). F stays at grade 2: there is no layer picker. Lens chips keep the names: simplex (explorer A's view of the same split), demicube
// (the move crosses from one half to the other), orthoplex (a move crosses one ridge); bits and primes print the labels. Controls: n chips, k chips (only the stored
// splits enabled), the corner a (pick), the axis b (chips). The ladder of counts stays under the drawing.
import React, { useState, useEffect, useMemo } from 'react';
import { Controls, Chips } from '../../kit.jsx';
import { popcount, PRIMES } from '../../../../engines/bitrule.js';
import { CUBE_NS, cubeMaxwell, stepOf, splitOk, nameOf, printingOf, primeName } from '../../../../engines/explore/lens.js';
import { signTxt } from './parts.jsx';
import { physicsOf, eqWords, PhysSimplex, PhysCube, PhysDemicube, PhysOrthoplex, PhysicsNote } from './physics.jsx';

const ID = 'lens-cube-maxwell';
const LENS_PANEL = { simplex: 'simplex', demicube: 'demicube', orthoplex: 'orthoplex' };
const OPWORD = { contract: 'drop', wedge: 'add' };
const rng = n => Array.from({ length: n }, (_, i) => i);
const kRange = n => [Math.max(1, n - 4), Math.min(4, n - 1)];
const clampK = (n, k) => { const [lo, hi] = kRange(n); return Math.min(hi, Math.max(lo, Number.isInteger(k) ? k : 1)); };
function init(params = {}) {
  const n = CUBE_NS.includes(params.n) ? params.n : 4, k = clampK(n, params.k);
  const a = Number.isInteger(params.a) && params.a >= 0 && params.a < 1 << n ? params.a : 3, b = Number.isInteger(params.b) && params.b >= 0 && params.b < n ? params.b : Math.min(2, n - 1);
  return { n, k, a, b };
}
const parity = m => (popcount(m) % 2 === 0 ? 'even' : 'odd');

/** the k chips: a split is offered only when it is stored (1 <= k, d <= 4) */
function KChips({ label, n, value, onPick }) {
  return (
    <span className="fig-group" role="group" aria-label={label} data-param="k">
      <span className="fig-group-label">{label}</span>
      {[1, 2, 3, 4].map(k => <button key={k} type="button" className="fig-btn fig-mono lx-chip" data-param="k" aria-pressed={k === value} disabled={!splitOk(k, n - k)} onClick={() => onPick(k)}>{k}</button>)}
    </span>
  );
}

export default function CubeMaxwell({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const [st, setSt] = useState(() => init(params));
  useEffect(() => { setSt(init(params)); }, [params.n, params.k, params.a, params.b]);   // eslint-disable-line react-hooks/exhaustive-deps
  const C = useMemo(() => cubeMaxwell(st.k, st.n - st.k), [st.k, st.n]);
  const n = C.n, a = st.a < 1 << n ? st.a : 3, b = st.b < n ? st.b : n - 1, step = stepOf(C.eps, a, b);
  const how = printingOf(lens, mode, level), nm = m => nameOf(m, how, C.axes, C.eps), view = LENS_PANEL[lens] || null;
  const roleOf = m => C.corners[m].role, layerRole = m => (popcount(m) >= 1 && popcount(m) <= 3 ? roleOf(m) : null);
  const ph = physicsOf(C.k, C.d), phys = m => ph.nameOf(m), into = ph.eqOf(step.to), ga = popcount(a);
  // the terms of the picked corner's equations: a component's own moves (to the targets of its equations), or the moves into a source or an identity
  const hotMoves = ga === 2 ? C.leaving.filter(x => x.from === a) : ga === 1 || ga === 3 ? C.leaving.filter(x => x.to === a) : [];
  const hot = ga === 2 ? hotMoves.map(x => x.to) : hotMoves.map(x => x.from);
  const pickA = m => () => setSt(s => ({ ...s, a: m }));
  const cornerLabel = m => (phys(m) ? `${phys(m)}, ${nm(m)}` : `corner ${nm(m)}`);
  const common = { id: ID, row, N: n, phys, base: nm, step };
  const panels = [];
  if (view === 'simplex') panels.push(<PhysSimplex key="simplex" {...common} part="simplex view" isLens slots={rng(n)} vertexRole={g => roleOf(1 << g)} edgeMark={m => ({ role: roleOf(m) })} faces={n <= 5}
    sel={popcount(a) === 2 ? a : null} lit={popcount(a) >= 3 ? [a] : []} hot={hot} pickOf={pickA} pickLabel={cornerLabel} />);
  if (view === 'demicube') panels.push(<PhysDemicube key="demi" {...common} part="demicube view" isLens research={research} sel={a} cornerRole={roleOf} pickOf={pickA} pickLabel={cornerLabel} />);
  if (view === 'orthoplex') panels.push(<PhysOrthoplex key="ortho" id={ID} row={row} part="orthoplex view" N={n} isLens research={research} phys={phys} base={nm} pole={(i, plus) => (plus ? '+' : '−') + nm(1 << i)} facets={[{ m: a, cls: 'sel' }, { m: step.to, cls: 'to' }]} ridge={[a, step.to]} />);
  panels.push(<PhysCube key="cube" {...common} part="cube view" isLens={lens === 'cube'} research={research} sel={a} cornerRole={layerRole} incidences={C.leaving} hotMoves={hotMoves} hot={hot} pickOf={pickA} pickLabel={cornerLabel} />);
  const c = C.counts, word = OPWORD[step.op], axisName = nm(1 << b), primes = how === 'primes';
  return (
    <div className="fig fig-lens fig-lens-cube" data-cell={`${C.k},${C.d}`} data-n={n}>
      <div className={'fig-panels' + (panels.length === 1 ? ' lx-one' : '')}>{panels}</div>
      <div className="lx-readout">
        <p data-counts={`${c.corners},${c.F},${c.incidences},${c.down},${c.up}`} data-layers={c.layers.join(',')}>
          <span>{research ? `Cl(${C.k},${C.d})` : `${c.corners} corners`}</span>
          <span><span className="lx-k">layers</span> {c.layers.join(' ')}</span>
          {research ? <span><span className="lx-k">F</span> {`${c.F} (E ${c.E} · B ${c.B} · T ${c.T})`}</span> : <span><span className="lx-k">layer 2</span> {c.F}</span>}
          <span><span className="lx-k">{research ? 'incidences' : 'moves'}</span> {`${c.incidences} (${c.down} down · ${c.up} up)`}</span>
        </p>
        <p data-step={`${step.from},${step.axis},${step.to},${step.op},${step.s}`}>
          {primes
            ? <span>{`${primeName(a)} ${step.op === 'contract' ? '÷' : '×'} ${PRIMES[b]} = ${primeName(step.to)}`}</span>
            : research && how !== 'clifford'
              ? <span>e<sub>{axisName}</sub> e<sub>{nm(a)}</sub> = {step.s < 0 ? '−' : '+'}e<sub>{nm(step.to)}</sub></span>
              : research ? <span>{`${axisName} ${nm(a)} = ${step.s < 0 ? '−' : '+'}${nm(step.to)}`}</span>
                : <span>{`${nm(a)} → ${nm(step.to)}`}</span>}
          <span>{research ? `${step.op === 'contract' ? 'contraction' : 'wedge'} · ${word} ${axisName}` : `${word} ${axisName}`}</span>
          {into && <span data-into={into.id}>{research ? `→ ${into.name}` : `in ${eqWords(into.name)}`}</span>}
          <span>{`${parity(a)} → ${parity(step.to)}`}</span>
          <span><span className="lx-k">sign</span> {signTxt(step.s)}</span>
        </p>
      </div>
      <PhysicsNote ph={ph} m={a} level={level} base={nm} />
      <Controls label="cube">
        <Chips label="n" items={CUBE_NS} value={n} onPick={v => setSt(s => ({ n: v, k: clampK(v, s.k), a: s.a < 1 << v ? s.a : 3, b: Math.min(s.b, v - 1) }))} param="n" mono />
        <KChips label={research ? 'time k' : 'time'} n={n} value={C.k} onPick={v => setSt(s => ({ ...s, k: clampK(s.n, v) }))} />
        <Chips label="axis" items={rng(n)} value={b} onPick={v => setSt(s => ({ ...s, b: v }))} render={g => nm(1 << g)} param="b" mono />
      </Controls>
    </div>
  );
}
CubeMaxwell.meta = { id: ID, lenses: ['simplex', 'cube', 'demicube', 'orthoplex', 'bits', 'primes'], learner: true };
/** the numbers and names the figure draws, for the frame's data download: the stored names of layers 1–3, the equations of the picked corner */
CubeMaxwell.data = (params = {}) => {
  const s = init(params), C = cubeMaxwell(s.k, s.n - s.k), step = stepOf(C.eps, s.a, s.b), ph = physicsOf(C.k, C.d);
  const names = Object.fromEntries(C.corners.filter(x => ph.nameOf(x.m)).map(x => [x.m, ph.nameOf(x.m)]));
  const eqs = popcount(s.a) === 2 ? ph.eqsOf(s.a) : ph.eqOf(s.a) ? [ph.eqOf(s.a)] : [];
  return { cell: [C.k, C.d], axes: C.axes, layers: C.counts.layers, counts: C.counts, F: C.F, leaving: C.leaving, step, names,
    equations: eqs.map(e => ({ id: e.id, name: e.name, eq: e.eq, term: e.term === undefined ? null : e.term, sign: e.sign === undefined ? null : e.sign })) };
};
