// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/lens/physics.jsx — the physics on the lens explorers (BUILD_CONTRACTS round 5, D29, interface 24): the names v15 gave the blades and the
// equations of ∇F = J, read through engines/explore/lens.js (cellPhysics, equationsOf, roleName of engines/maxwellPhysics.js: interface 23, maxwell.json), printed
// on the shapes of the labels. A vertex carries its source (ρ, Jx …), an edge its field component (Ex, Bz, B12, T12, E1x …), a triangle the identity it carries
// (the stored name of the equation whose target it is: Faraday z, no monopole, Bianchi 123, dF t1 t2 x …); under each name the label in the printing the lens asks
// for (letters, e-words, digits, bits, primes), so that the lens changes the drawing and the label, never the physics name. The four panels (simplex, cube, demicube,
// orthoplex) keep the layouts, marks and data attributes of parts.jsx and add the names; a note lists the equations of a picked component with their signs (KaTeX at
// research level, words at learner level), or the equation of a picked source or identity. Nothing here computes a sign: the signs are the stored terms, which
// tests/explore/physics.test.mjs recomputes through the kernel; the move signs come from stepOf. Marks by shape and word, tokens only.
import React, { useMemo } from 'react';
import { FigSvg, r1 } from '../../kit.jsx';
import { hull } from '../../FourViews.jsx';
import { popcount } from '../../../../engines/bitrule.js';
import { bitsOf } from '../../../../engines/labels.js';
import { cellPhysics, equationsOf, roleName, orthoplexOf, facetOf, ridgeOf, demicubeEdges } from '../../../../engines/explore/lens.js';
import { useKatex, texToHtml } from '../../../app/math.js';
import { VW, VH, simplexXY, cubeXY, halfXY, petrieXY, RoleMark, MoveMark, ParityDot, Pick, MoveArrow, focusRule } from './parts.jsx';

const rng = n => Array.from({ length: n }, (_, i) => i);
const pts = P => P.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ');
const mean = P => [P.reduce((s, p) => s + p[0], 0) / P.length, P.reduce((s, p) => s + p[1], 0) / P.length];
const evenLabel = m => popcount(m) % 2 === 0;
const panelClass = isLens => 'fig-panel' + (isLens ? ' is-lens' : '');
const stepData = st => ({ 'data-step': `${st.from},${st.axis},${st.to},${st.op},${st.s}` });
const MUTED = { color: 'var(--muted)' };
/** the halo that keeps a muted label readable over a line (tokens only) */
const HALO = { fill: 'var(--muted)', paintOrder: 'stroke', stroke: 'var(--panel)', strokeWidth: 3, strokeLinejoin: 'round' };
/** a name underlined: a target of the picked component's equations (the term is underlined in each equation of the note too) */
const UNDER = { textDecoration: 'underline' };

// ---------------------------------------------------------------- the physics of a cell, as the panels and notes read it
const MODELS = new Map();
/** the stored physics of Cl(k, d) with the lookups the drawings need: the name of a label (a source or field component: its blade label; a grade-3 label: the name
 *  of the equation whose target it is; anything else: null), its role, the equation whose target it is, the equations a field component appears in */
export function physicsOf(k, d) {
  const key = `${k},${d}`;
  if (MODELS.has(key)) return MODELS.get(key);
  const P = cellPhysics(k, d);
  if (!P) return null;
  const byTarget = new Map(P.equations.map(e => [e.target, e]));
  const nameOf = m => { const b = P.blades[m]; if (!b || b.grade < 1 || b.grade > 3) return null; if (b.grade < 3) return b.label; const e = byTarget.get(m); return e ? e.name : b.label; };
  const model = { ...P, key, byTarget, nameOf, roleOf: m => (P.blades[m] || {}).role, eqOf: m => byTarget.get(m) || null, eqsOf: m => equationsOf(k, d, m) };
  MODELS.set(key, model);
  return model;
}

// ---------------------------------------------------------------- an equation as stored, read term by term (for KaTeX and for the words)
/** the textbook equation of maxwell.json, "∂t Ex − ∂y Bz + ∂z By = −Jx", as { lhs: [{ s: ±1, axis: 't', label: 'Ex' }], rhs: { s: ±1, label } | null (0) } */
export function eqParts(eq) {
  const [left, right] = String(eq).split(' = '), lhs = [];
  let s = 1;
  const toks = left.split(' ').filter(Boolean);
  for (let i = 0; i < toks.length; i++) {
    let t = toks[i];
    if (t === '+' || t === '−') { s = t === '−' ? -1 : 1; continue; }
    if (t.startsWith('−')) { s = -s; t = t.slice(1); }
    lhs.push({ s, axis: t.slice(1), label: toks[i + 1] });
    i++; s = 1;
  }
  const r = String(right || '').trim();
  const rhs = r === '0' ? null : r.startsWith('−') ? { s: -1, label: r.slice(1) } : { s: 1, label: r };
  return { lhs, rhs };
}
/** the TeX of a label as stored: the letter, then its subscript (ρ → \rho, Ex → E_{x}, T12 → T_{12}, E1x → E_{1x}) */
const texLabel = l => { const [h, ...t] = [...String(l)]; return (h === 'ρ' ? '\\rho' : h) + (t.length ? `_{${t.join('')}}` : ''); };
const texAxis = a => { const m = /^([a-z])(\d*)$/.exec(a); return m ? (m[2] ? `${m[1]}_{${m[2]}}` : m[1]) : a; };
/** the TeX of a stored equation, the term at index `hi` underlined (the component picked); the same symbols in the same order as the stored string */
export function eqTex(eq, hi = -1) {
  const { lhs, rhs } = eqParts(eq);
  const term = (t, i) => { const body = `\\partial_{${texAxis(t.axis)}} ${texLabel(t.label)}`; return i === hi ? `\\underline{${body}}` : body; };
  const left = lhs.map((t, i) => (i === 0 ? (t.s < 0 ? '-' : '') : t.s < 0 ? ' - ' : ' + ') + term(t, i)).join('');
  return `${left} = ${rhs ? (rhs.s < 0 ? '-' : '') + texLabel(rhs.label) : '0'}`;
}
/** the stored names of the equations in words (learner level): Gauss → Gauss’s law, Ampère x → Ampère’s law for x, dF t1 t2 x → the Faraday-like rule for t1 t2 x */
const EQ_WORDS = [
  [/^Gauss(?: (.+))?$/, m => `Gauss’s law${m[1] ? ` for ${m[1]}` : ''}`],
  [/^Ampère (.+)$/, m => `Ampère’s law for ${m[1]}`],
  [/^Faraday (.+)$/, m => `Faraday’s law for ${m[1]}`],
  [/^no monopole(?: (.+))?$/, m => `the no-monopole law${m[1] ? ` for ${m[1]}` : ''}`],
  [/^Bianchi (.+)$/, m => `the Bianchi identity for ${m[1]}`],
  [/^dF (.+)$/, m => `the Faraday-like rule for ${m[1]}`],
];
export function eqWords(name) { for (const [re, f] of EQ_WORDS) { const m = re.exec(name); if (m) return f(m); } return name; }
/** a source or field component in words: its role (roleName, learner) and the axis its stored label names (Ex → the electric field along x), else the label */
export function componentWords(ph, m) {
  const b = ph.blades[m], sub = String(b.label).slice(1), role = roleName(b.role, 'learner');
  return `the ${role}${!sub ? '' : /^[a-z]$/.test(sub) && ph.axes.includes(sub) ? ` along ${sub}` : ` ${b.label}`}`;
}
const cap = s => s.charAt(0).toUpperCase() + s.slice(1);
const listIn = xs => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', in ')} and in ${xs[xs.length - 1]}`);
const listAnd = xs => (xs.length <= 1 ? xs.join('') : `${xs.slice(0, -1).join(', ')} and ${xs[xs.length - 1]}`);
/** the learner sentence of a label: a field component and the laws it appears in; a source and its law; an identity and the components in it; '' for the rest */
export function learnerLine(ph, m) {
  const b = ph.blades[m];
  if (!b) return '';
  if (b.grade === 2) { const eqs = ph.eqsOf(m); return `${cap(componentWords(ph, m))}; it appears in ${listIn(eqs.map(e => eqWords(e.name)))}.`; }
  const e = ph.eqOf(m);
  if (!e) return '';
  const inIt = listAnd(eqParts(e.eq).lhs.map(t => t.label));
  return b.grade === 1 ? `${cap(componentWords(ph, m))}; its law is ${eqWords(e.name)}, where ${inIt} appear.` : `${cap(eqWords(e.name))}: ${inIt} appear in it.`;
}

// ---------------------------------------------------------------- names placed beside their marks (a deterministic greedy placer: no tag on a mark or another tag)
const tw = (s, px, mono) => [...String(s)].length * px * (mono ? 0.62 : 0.6) + 3;
const BOX = { x0: 2, y0: 3, x1: VW - 2, y1: VH - 3 };
const TURNS = [0, 20, -20, 40, -40, 60, -60, 80, -80, 100, -100, 120, -120, 140, -140, 160, -160, 180], REACH = [0, 4, 8, 12, 18, 26];
/** the spots tried around a mark, by preference: [turn from the side preferred (radians), extra distance, rank] */
const CANDIDATES = TURNS.flatMap((t, ti) => REACH.map((r, di) => [t * Math.PI / 180, r, ti * 3 + di * 5])).sort((a, b) => a[2] - b[2]);
const area = (a, b) => Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
/** is the point well inside the triangle (each barycentric weight at least 0.12)? */
function within([[x1, y1], [x2, y2], [x3, y3]], x, y) {
  const D = (y2 - y3) * (x1 - x3) + (x3 - x2) * (y1 - y3);
  if (Math.abs(D) < 1e-9) return true;
  const l1 = ((y2 - y3) * (x - x3) + (x3 - x2) * (y - y3)) / D, l2 = ((y3 - y1) * (x - x3) + (x1 - x3) * (y - y3)) / D;
  return l1 >= 0.12 && l2 >= 0.12 && 1 - l1 - l2 >= 0.12;
}
/** items: { kind, m, at: [x, y], dir: angle in radians (the side preferred), gap, inside (a face: the name centred near the anchor), lines: [{ text, px, mono }] };
 *  marks: [x, y, r] to keep clear. Returns each item with the box centre (cx, cy), width and height, inside the drawing. */
export function placeTags(items, marks = []) {
  const placed = [], obs = marks.map(([x, y, r]) => [x - r, y - r, x + r, y + r]);
  return items.map(it => {
    const w = Math.max(...it.lines.map(l => tw(l.text, l.px, l.mono))), h = it.lines.reduce((s, l) => s + l.px + 1.5, 0);
    let best = null;
    for (const [turn, more, rank] of CANDIDATES) {   // in the order of preference: the first spot that touches nothing wins
      if (it.inside && !it.tri && more > 12) continue;   // a facet's name stays near its centre
      const a = it.dir + turn, ux = Math.cos(a), uy = Math.sin(a), reach = it.inside ? more : (it.gap || 0) + more + Math.abs(ux) * w / 2 + Math.abs(uy) * h / 2;
      let cx = it.at[0] + ux * reach, cy = it.at[1] + uy * reach;
      if (it.tri && !within(it.tri, cx, cy)) continue;   // a face's name stays on its face
      const out = Math.max(0, BOX.x0 - (cx - w / 2)) + Math.max(0, cx + w / 2 - BOX.x1) + Math.max(0, BOX.y0 - (cy - h / 2)) + Math.max(0, cy + h / 2 - BOX.y1);
      cx = Math.min(BOX.x1 - w / 2, Math.max(BOX.x0 + w / 2, cx)); cy = Math.min(BOX.y1 - h / 2, Math.max(BOX.y0 + h / 2, cy));
      const bx = [cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], pad = [bx[0] - 2, bx[1] - 1.5, bx[2] + 2, bx[3] + 1.5];
      let hit = out * 60;
      for (const p of placed) hit += area(pad, p) * 4;
      for (const o of obs) hit += area(pad, o) * 2;
      if (!best || hit + rank < best.score) best = { score: hit + rank, cx, cy, bx };
      if (hit === 0) break;
    }
    if (!best) best = { cx: it.at[0], cy: it.at[1], bx: [it.at[0] - w / 2, it.at[1] - h / 2, it.at[0] + w / 2, it.at[1] + h / 2] };
    placed.push(best.bx);
    return { ...it, cx: best.cx, cy: best.cy, w, h };
  });
}
/** one placed tag: the physics name (bold, with a halo) and under it the label in the lens's printing (smaller, muted); a tag of one line without a name is the
 *  label alone (mono, as parts.jsx prints labels) */
export function PlacedTag({ t }) {
  let y = t.cy - t.h / 2;
  const one = t.lines.length === 1 && t.lines[0].mono;
  return (
    <g data-phys={t.kind} data-of={t.m} data-name={one ? '' : t.lines[0].text} data-label={one ? t.lines[0].text : t.lines[1] ? t.lines[1].text : ''}>
      {t.lines.map((l, i) => {
        y += l.px + (i ? 1.5 : 0);
        const cls = l.mono ? 'lx-name' : i ? 'lx-s' : l.px < 11 ? 'lx-s lx-tag' : 'lx-tag';
        return <text key={i} x={r1(t.cx)} y={r1(y - 1.5)} textAnchor="middle" className={cls} style={i ? HALO : t.hot ? UNDER : undefined} data-hot={!i && t.hot ? 'true' : undefined}>{l.text}</text>;
      })}
    </g>
  );
}
const Tag = PlacedTag;
const linesOf = (name, label, px = 11) => (name == null || name === '' ? [{ text: label, px: 12, mono: true }] : label != null && label !== '' ? [{ text: name, px }, { text: label, px: 10 }] : [{ text: name, px }]);
const angleOf = (p, q) => Math.atan2(p[1] - q[1], p[0] - q[0]);

// ---------------------------------------------------------------- the simplex: generators at the vertices, labels of two generators on the edges, of three on the triangles
/** The simplex whose vertices are the N generators (slots: the generator of each vertex, slot 0 on top), as parts.jsx SimplexPanel draws it, with the names:
 *  phys(m) the physics name of a label or null, base(m) its label in the lens's printing; vertexRole(g) / edgeMark(m) the marks; faces: the grade-3 faces drawn;
 *  sel: the picked edge; step: the picked move (an arrow, the target shaded); hot: the targets of the picked component's equations (a vertex ringed, a face outlined
 *  dashed); names: which elements are named ('all', or only the vertices and the picked edge when the shape is too large to name every edge and face). */
export function PhysSimplex({ id, row, part, N, slots, phys, base, vertexRole = () => null, edgeMark = () => null, faces = true, sel = null, step = null, lit = [], hot = [], pickOf = () => null, pickLabel = String, isLens }) {
  const S = simplexXY(N, 150, 132), at = new Map(slots.map((g, s) => [g, S[s]])), C = mean(S);
  const posOf = m => mean(bitsOf(m).map(g => at.get(g)));
  const edges = [], tris = [];
  for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) edges.push((1 << i) | (1 << j));
  for (let m = 0; m < 1 << N; m++) if (popcount(m) === 3) tris.push(m);
  const markAt = m => { const [g, h] = bitsOf(m), P = at.get(g), Q = at.get(h), t = N === 6 ? 0.42 : 0.5; return [P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t]; };
  const face = m => { const V = bitsOf(m).map(g => at.get(g)); return V.length >= 3 ? hull(V) : V; };
  const shaded = [...lit.filter(m => popcount(m) >= 3), ...(step && popcount(step.to) >= 3 ? [step.to] : [])];
  const ends = step ? [step.from, step.to] : [];
  // which elements carry their name in the drawing: every vertex; every edge up to 5 vertices; every face up to 4 vertices, and at 5 the faces the picked
  // component's equations land on (the centre of the 4-simplex holds ten faces); a face carries its name alone from 4 vertices on (its label is its corners');
  // every element carries name and label as a tooltip
  const namedEdge = m => N <= 5 || m === sel || lit.includes(m), namedFace = m => faces && (N <= 4 || (N === 5 && (hot.includes(m) || shaded.includes(m))));
  const tags = useMemo(() => {
    const items = [], marks = [...S.map(([x, y]) => [x, y, 7]), ...edges.map(m => [...markAt(m), 5.5])];
    if (step && step.from && step.to) {
      const p = posOf(step.from), q = posOf(step.to), dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, c = Math.min(11, L / 3);
      for (let t = c; t <= L - c; t += 6) marks.push([p[0] + ux * t - uy * 7, p[1] + uy * t + ux * 7, 4]);
      marks.push([q[0] - ux * c - uy * 7 - uy * 12, q[1] - uy * c + ux * 7 + ux * 12, 8]);
    }
    slots.forEach((g, s) => { const m = 1 << g; items.push({ kind: 'vertex', m, at: S[s], dir: angleOf(S[s], C), gap: 8, lines: linesOf(phys(m), base(m)) }); });
    for (const m of tris) if (namedFace(m)) { const nm = phys(m); if (!nm) continue; const P = mean(bitsOf(m).map(g => at.get(g))), far = Math.hypot(P[0] - C[0], P[1] - C[1]) > 3; items.push({ kind: 'face', m, at: P, dir: far ? angleOf(P, C) : Math.PI / 2, inside: true, tri: bitsOf(m).map(g => at.get(g)), lines: linesOf(nm, N === 3 ? base(m) : null, 10) }); }
    for (const m of edges) if (namedEdge(m)) { const nm = phys(m); if (!nm) continue; const P = markAt(m), [g, h] = bitsOf(m), A = at.get(g), B = at.get(h), nx = -(B[1] - A[1]), ny = B[0] - A[0], away = (P[0] - C[0]) * nx + (P[1] - C[1]) * ny >= 0 ? 1 : -1; items.push({ kind: 'edge', m, at: P, dir: Math.atan2(ny * away, nx * away), gap: 6, lines: linesOf(nm, base(m)) }); }
    return placeTags(items, marks).map(t => ({ ...t, hot: hot.includes(t.m) }));
  }, [N, slots.join(), sel, step && `${step.from},${step.to}`, hot.join(), lit.join(), faces, [...edges, ...tris, ...slots.map(g => 1 << g)].map(m => `${phys(m)}|${base(m)}`).join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const tip = m => <title>{[phys(m), base(m)].filter(Boolean).join(' · ')}</title>;
  return (
    <div className={panelClass(isLens)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {faces && tris.map(m => <polygon key={'f' + m} points={pts(face(m))} className="lx-face" data-tri={m}>{tip(m)}</polygon>)}
        {shaded.map((m, i) => <polygon key={'L' + i} points={pts(face(m))} className="lx-face-on" data-lit={m} />)}
        {edges.map(m => {
          const [g, h] = bitsOf(m), P = at.get(g), Q = at.get(h), info = edgeMark(m), on = sel === m, dash = lit.includes(m) && !on, [mx, my] = markAt(m), handler = pickOf(m);
          const body = (
            <g key={'e' + m} data-piece={m} data-role={info && info.role ? info.role : undefined}>
              {handler && <line x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className="lx-hit" />}
              <line x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className={on || dash ? 'lx-edge is-sel' : 'lx-edge'} style={dash ? { strokeDasharray: '5 3' } : undefined} />
              {info && info.role && <RoleMark x={mx} y={my} role={info.role} r={on ? 5.6 : 4.6} />}
              {info && info.kind && <MoveMark x={mx} y={my} kind={info.kind} r={8} sel={on} />}
              {tip(m)}
            </g>
          );
          return handler ? <Pick key={'p' + m} param="a" on={on} label={pickLabel(m)} onPick={handler}>{body}</Pick> : body;
        })}
        {step && step.from && step.to ? <MoveArrow p={posOf(step.from)} q={posOf(step.to)} op={step.op} s={step.s} data={stepData(step)} /> : null}
        {slots.map((g, s) => { const [x, y] = S[s], role = vertexRole(g); return (
          <g key={'v' + g} data-vertex={g} data-slot={s}>
            {role ? <RoleMark x={x} y={y} role={role} r={6} /> : <circle cx={r1(x)} cy={r1(y)} r={4} className="lx-mark-fill" />}
            {ends.includes(1 << g) ? <circle cx={r1(x)} cy={r1(y)} r={10} className="lx-ring-sel" /> : hot.includes(1 << g) ? <circle cx={r1(x)} cy={r1(y)} r={10} className="lx-ring-lit" data-hot={1 << g} /> : null}
            {tip(1 << g)}
          </g>); })}
        {tags.map(t => <Tag key={t.kind + t.m} t={t} />)}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the cube: the labels in columns by grade (parts.jsx cubeXY), layers 1–3 named
const CUBE_BOX = { x0: 26, x1: 274 };
/** The N-cube in columns by grade, as parts.jsx CubePanel draws it, with the names of the corners that have one (phys(m)): every such corner up to N = 4, the
 *  ringed ones (the pick, the step, hot) above; every corner carries its name and label as a tooltip. incidences: the moves leaving layer 2 (data-inc), those of
 *  `hotMoves` drawn heavier: the terms of the picked corner's equations. */
export function PhysCube({ id, row, part, N, phys, base, cornerRole = () => null, incidences = [], hotMoves = [], step = null, sel = null, lit = [], hot = [], pickOf = () => null, pickLabel = String, focusOf = focusRule(N), isLens, research, allEdges = N <= 5 }) {
  const P = cubeXY(N), cols = rng(N + 1), dx = (CUBE_BOX.x1 - CUBE_BOX.x0) / Math.max(1, N), r = N >= 6 ? 2.6 : N === 5 ? 3.4 : 5, bw = Math.min(14, dx / 2 - 2);
  const cubeEdges = []; if (allEdges) for (let m = 0; m < 1 << N; m++) for (const i of rng(N)) if (!bitsOf(m).includes(i)) cubeEdges.push([m, m | (1 << i)]);
  const ringed = new Set([sel, ...(step ? [step.from, step.to] : []), ...lit].filter(x => x !== null && x !== undefined));
  const hotSet = new Set(hotMoves.map(x => `${x.from},${x.axis}`));
  const layer = g => rng(1 << N).filter(m => popcount(m) === g).length;
  // named in the drawing: every corner with a name up to N = 4; at 5 the sources and the components (the name alone, the label in the tooltip: a column holds ten
  // corners) and the identities that are picked or partners; above, only the pick, the step and its partners. Every corner carries name and label as a tooltip.
  const partner = m => ringed.has(m) || hot.includes(m);
  const named = m => phys(m) && (N <= 4 || partner(m) || (N === 5 && popcount(m) <= 2)), full = m => N <= 4 || partner(m);
  const tags = useMemo(() => {
    const marks = [...rng(1 << N).map(m => [...P[m], r + 2]), ...(research ? cols.flatMap(g => [[CUBE_BOX.x0 + dx * g, 12, 7], [CUBE_BOX.x0 + dx * g, 238, 7]]) : [])], items = [];
    const order = rng(1 << N).filter(named).sort((a, b) => (full(b) ? 1 : 0) - (full(a) ? 1 : 0));
    for (const m of order) items.push({ kind: 'corner', m, at: P[m], dir: popcount(m) === 0 ? Math.PI : popcount(m) >= N ? 0 : popcount(m) === 3 && N === 5 ? 0 : N === 5 ? Math.PI : -Math.PI / 2, gap: r + 2, lines: linesOf(phys(m), full(m) ? base(m) : null, popcount(m) === 3 ? 10 : 11) });
    return placeTags(items, marks).map(t => ({ ...t, hot: hot.includes(t.m) }));
  }, [N, research, sel, step && step.to, lit.join(), hot.join(), rng(1 << N).map(m => named(m) ? `${phys(m)}|${base(m)}` : '').join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className={panelClass(isLens)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {cols.filter(g => g % 2 === 0).map(g => <rect key={'b' + g} x={r1(CUBE_BOX.x0 + dx * g - bw)} y={24} width={r1(2 * bw)} height={202} rx={6} className="lx-band" data-even-layer={g} />)}
        {research && cols.map(g => <text key={'h' + g} x={r1(CUBE_BOX.x0 + dx * g)} y={16} textAnchor="middle" className="lx-s lx-muted">{g}</text>)}
        {cubeEdges.map(([a, b]) => <line key={a + '-' + b} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} className="lx-hair" />)}
        {incidences.map(x => { const heavy = hotSet.has(`${x.from},${x.axis}`); return <line key={'i' + x.from + ',' + x.axis} x1={r1(P[x.from][0])} y1={r1(P[x.from][1])} x2={r1(P[x.to][0])} y2={r1(P[x.to][1])} className={heavy ? 'lx-edge' : 'lx-inc'} style={x.op === 'wedge' ? { strokeDasharray: heavy ? '4 3' : '3 2.5' } : undefined} data-inc={`${x.from},${x.axis},${x.to},${x.op},${x.s}`} data-hot={heavy ? 'true' : undefined} />; })}
        {step && <line x1={r1(P[step.from][0])} y1={r1(P[step.from][1])} x2={r1(P[step.to][0])} y2={r1(P[step.to][1])} className="lx-edge is-sel" style={step.op === 'wedge' ? { strokeDasharray: '5 3' } : undefined} {...stepData(step)} />}
        {rng(1 << N).map(m => {
          const [x, y] = P[m], role = cornerRole(m), on = ringed.has(m), handler = pickOf(m), main = m === sel || (step && m === step.from), nm = phys(m);
          const body = (
            <g key={'c' + m} data-corner={m} data-grade={popcount(m)}>
              {handler && <circle cx={r1(x)} cy={r1(y)} r={Math.max(7, r + 3)} className="hit" />}
              {role ? <RoleMark x={x} y={y} role={role} r={r} /> : <ParityDot x={x} y={y} even={evenLabel(m)} r={Math.max(2, r - 1.5)} />}
              {on ? <circle cx={r1(x)} cy={r1(y)} r={r + 4.5} className={main ? 'lx-ring-sel' : 'lx-ring-lit'} /> : hot.includes(m) ? <circle cx={r1(x)} cy={r1(y)} r={r + 3.5} className="lx-ring-lit" data-hot={m} /> : null}
              <title>{[nm, base(m)].filter(Boolean).join(' · ')}</title>
              {!nm && (N <= 3 || on) && <text x={r1(x)} y={r1(y - r - 6)} textAnchor="middle" className="lx-s">{base(m)}</text>}
            </g>
          );
          return handler ? <Pick key={'p' + m} param="a" on={m === sel} label={pickLabel(m)} onPick={handler} focusable={focusOf(m)}>{body}</Pick> : body;
        })}
        {tags.map(t => <Tag key={t.kind + t.m} t={t} />)}
        {research && cols.map(g => <text key={'n' + g} x={r1(CUBE_BOX.x0 + dx * g)} y={242} textAnchor="middle" className="lx-s lx-bold" data-layer={`${g},${layer(g)}`}>{layer(g)}</text>)}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the demicube: the even half and the odd half of the cube (parts.jsx halfXY), named
/** The two halves of the N-cube, as parts.jsx DemicubePanel draws them (even labels left, odd right, each half a demicube with its edges for N <= 5), with the names
 *  of the corners that have one (all of them up to N = 4, the ringed ones above). The picked move always crosses from one half to the other. */
export function PhysDemicube({ id, row, part, N, phys, base, cornerRole = () => null, step = null, sel = null, lit = [], pickOf = () => null, pickLabel = String, focusOf = focusRule(N), isLens, research }) {
  const Lp = halfXY(N, { x0: 16, x1: 134, y0: 48, y1: 208 }), Rp = halfXY(N, { x0: 166, x1: 284, y0: 48, y1: 208 }, true);
  const place = m => (evenLabel(m) ? Lp[m] : Rp[m]);
  const evens = rng(1 << N).filter(evenLabel), odds = rng(1 << N).filter(m => !evenLabel(m));
  const showEdges = N <= 5, r = N >= 6 ? 2.6 : N === 5 ? 3.2 : 5;
  const ringed = new Set([sel, ...(step ? [step.from, step.to] : []), ...lit].filter(x => x !== null && x !== undefined));
  const named = m => (N <= 4 || ringed.has(m)) && (phys(m) || ringed.has(m));
  const tags = useMemo(() => {
    const marks = rng(1 << N).map(m => [...place(m), r + 2]), items = [];
    const ctr = m => (evenLabel(m) ? [75, 128] : [225, 128]);
    for (const m of rng(1 << N).filter(named).sort((a, b) => (ringed.has(b) ? 1 : 0) - (ringed.has(a) ? 1 : 0))) {
      const p = place(m), c = ctr(m), far = Math.hypot(p[0] - c[0], p[1] - c[1]) > 3;
      items.push({ kind: 'corner', m, at: p, dir: far ? angleOf(p, c) : -Math.PI / 2, gap: r + 2, lines: linesOf(phys(m), base(m), popcount(m) === 3 ? 10 : 11) });
    }
    return placeTags(items, marks);
  }, [N, sel, step && step.to, lit.join(), rng(1 << N).map(m => named(m) ? `${phys(m)}|${base(m)}` : '').join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const dot = m => {
    const [x, y] = place(m), role = popcount(m) === 2 ? cornerRole(m) : null, on = ringed.has(m), handler = pickOf(m), main = m === sel || (step && m === step.from);
    const body = (
      <g key={'c' + m} data-corner={m} data-half={evenLabel(m) ? 'even' : 'odd'}>
        {handler && <circle cx={r1(x)} cy={r1(y)} r={Math.max(7, r + 3)} className="hit" />}
        {role ? <RoleMark x={x} y={y} role={role} r={r} /> : <ParityDot x={x} y={y} even={evenLabel(m)} r={evenLabel(m) ? r : Math.max(2, r - 1)} />}
        {on && <circle cx={r1(x)} cy={r1(y)} r={r + 4.5} className={main ? 'lx-ring-sel' : 'lx-ring-lit'} />}
        <title>{[phys(m), base(m)].filter(Boolean).join(' · ')}</title>
        {!named(m) && N <= 3 && <text x={r1(x)} y={r1(y - r - 6)} textAnchor="middle" className="lx-s">{base(m)}</text>}
      </g>
    );
    return handler ? <Pick key={'p' + m} param="a" on={m === sel} label={pickLabel(m)} onPick={handler} focusable={focusOf(m)}>{body}</Pick> : body;
  };
  const edgeLine = (a, b, cls, key, data) => <line key={key} x1={r1(place(a)[0])} y1={r1(place(a)[1])} x2={r1(place(b)[0])} y2={r1(place(b)[1])} className={cls} {...data} />;
  return (
    <div className={panelClass(isLens)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        <text x={75} y={16} textAnchor="middle" className="lx-name">even</text>
        <text x={225} y={16} textAnchor="middle" className="lx-name lx-muted">odd</text>
        <line x1={150} y1={26} x2={150} y2={228} className="lx-hair" style={{ strokeDasharray: '2 4' }} />
        {showEdges && demicubeEdges(evens).map(([a, b]) => edgeLine(a, b, 'lx-hair-2', 'E' + a + '-' + b, { 'data-edge': `${a},${b}` }))}
        {showEdges && demicubeEdges(odds.map(o => o ^ 1)).map(([a, b]) => edgeLine(a ^ 1, b ^ 1, 'lx-hair', 'O' + a + '-' + b, {}))}
        {step ? <MoveArrow p={place(step.from)} q={place(step.to)} op={step.op} s={step.s} side={0} cut={9} data={stepData(step)} /> : null}
        {evens.map(dot)}{odds.map(dot)}
        {tags.map(t => <Tag key={t.kind + t.m} t={t} />)}
        {research && <text x={150} y={246} textAnchor="middle" className="lx-s lx-muted">{`${evens.length} even · ${odds.length} odd`}</text>}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the orthoplex: a label is a facet; the facets drawn carry their names
/** The N-orthoplex on its Petrie polygon, as parts.jsx OrthoplexPanel draws it (poles ±e_i, facets [{ m, cls }] through their N poles, the shared ridge ringed),
 *  with the physics name and label of every facet drawn, at its centre. */
export function PhysOrthoplex({ id, row, part, N, pole, phys, base, facets = [], ridge = null, isLens, research }) {
  const O = orthoplexOf(N), P = petrieXY(N), C = [150, 130];
  const poly = m => { const vs = facetOf(m, N).map(v => P[v]); return vs.length >= 3 ? hull(vs) : vs; };
  const common = ridge ? ridgeOf(ridge[0], ridge[1], N) : [];
  const tags = useMemo(() => {
    const marks = P.map(([x, y]) => [x, y, 8]), items = [];
    for (const f of facets) { const vs = facetOf(f.m, N).map(v => P[v]), c = mean(vs), far = Math.hypot(c[0] - C[0], c[1] - C[1]) > 3; items.push({ kind: 'facet', m: f.m, at: c, dir: far ? angleOf(c, C) : Math.PI / 2, inside: true, lines: linesOf(phys(f.m), base(f.m)) }); }
    return placeTags(items, marks);
  }, [N, facets.map(f => `${f.m}|${phys(f.m)}|${base(f.m)}`).join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <div className={panelClass(isLens)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {O.edges.map(([u, v]) => <line key={u + '-' + v} x1={r1(P[u][0])} y1={r1(P[u][1])} x2={r1(P[v][0])} y2={r1(P[v][1])} className="lx-hair" />)}
        {facets.map(f => { const vs = poly(f.m), data = { 'data-facet': `${f.m},${f.cls}` }; return vs.length >= 3
          ? <polygon key={f.cls + f.m} points={pts(vs)} className={'lx-facet lx-facet-' + f.cls} {...data} />
          : <line key={f.cls + f.m} x1={r1(vs[0][0])} y1={r1(vs[0][1])} x2={r1(vs[vs.length - 1][0])} y2={r1(vs[vs.length - 1][1])} className={'lx-facet lx-facet-' + f.cls} {...data} />; })}
        {O.poles.map(p => { const [x, y] = P[p.v], dx = x - C[0], dy = y - C[1], L = Math.hypot(dx, dy) || 1; return (
          <g key={'v' + p.v} data-pole={`${p.axis},${p.plus ? '+' : '-'}`}>
            <circle cx={r1(x)} cy={r1(y)} r={4.4} className={p.plus ? 'lx-mark-fill' : 'lx-mark-ring'} />
            {common.includes(p.v) && <circle cx={r1(x)} cy={r1(y)} r={8.5} className="lx-ring-lit" data-ridge={p.v} />}
            {N <= 5 && <text x={r1(x + dx / L * 18)} y={r1(y + dy / L * 18 + 4)} textAnchor="middle" className="lx-s">{pole(p.axis, p.plus)}</text>}
          </g>); })}
        {tags.map(t => <Tag key={t.kind + t.m} t={t} />)}
        {research && <text x={8} y={16} className="lx-s lx-muted">{`${2 * N} poles · ${O.edges.length} edges · ${O.facets} facets`}</text>}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the note under the drawing: the equations of the picked label
/** an equation as stored: KaTeX at research level (the picked term underlined), the stored string while KaTeX loads */
function Eq({ eq, hi, katex }) {
  const html = katex ? texToHtml(eqTex(eq, hi)) : null;
  if (html) return <span className="lx-eq" data-tex={eqTex(eq, hi)} dangerouslySetInnerHTML={{ __html: html }} />;
  const { lhs } = eqParts(eq), [left, right] = String(eq).split(' = ');
  if (hi < 0 || !lhs[hi]) return <span className="lx-eq fig-mono">{eq}</span>;
  const t = lhs[hi], piece = `∂${t.axis} ${t.label}`, at = left.indexOf(piece);
  return <span className="lx-eq fig-mono">{left.slice(0, at)}<u>{piece}</u>{left.slice(at + piece.length)}{` = ${right}`}</span>;
}
/** The note of a picked label of the cell: a field component (grade 2) lists the equations it appears in, each with the sign of its term (KaTeX at research
 *  level, the term underlined; one sentence of words at learner level); a source (grade 1) or an identity (grade 3) shows its own equation; any other label
 *  shows nothing. At research level the sign convention follows, an input (INP-011). */
export function PhysicsNote({ ph, m, level = 'research', base = () => '' }) {
  const research = level !== 'learner';
  const katex = useKatex(research);
  if (!ph || !ph.blades[m]) return null;
  const b = ph.blades[m], name = ph.nameOf(m);
  if (!name) return null;
  if (!research) return <div className="fig-note lx-phys" data-blade={m} data-name={name}><p data-words={m}>{learnerLine(ph, m)}</p></div>;
  const rows = b.grade === 2
    ? ph.eqsOf(m).map(e => { const parts = eqParts(e.eq).lhs, hi = parts.findIndex(t => t.label === b.label && t.axis === ph.axes[e.axis]); return { e, hi, s: hi >= 0 ? parts[hi].s : 0 }; })
    : ph.eqOf(m) ? [{ e: ph.eqOf(m), hi: -1, s: 0 }] : [];
  return (
    <div className="fig-note lx-phys" data-blade={m} data-name={name}>
      <p>
        <strong>{name}</strong>
        {b.grade !== 3 && <span style={MUTED}>{base(m)}</span>}
        <span>{roleName(b.role)}</span>
        {b.grade === 2 && <span style={MUTED}>{`in ${rows.length} equations`}</span>}
      </p>
      <ul className="fig-scroll">
        {rows.map(({ e, hi, s }) => (
          <li key={e.id} data-eq={e.id} data-target={e.target} data-op={e.op} data-sign={hi >= 0 ? s : undefined} data-term={b.grade === 2 ? e.term : undefined}>
            <span style={MUTED}>{`${e.name}: `}</span><Eq eq={e.eq} hi={hi} katex={katex} />
          </li>
        ))}
      </ul>
      <p data-convention style={MUTED}>{`the sign convention, an input (INP-011): F = ${ph.conventions.F}; J = ${ph.conventions.J}`}</p>
    </div>
  );
}
