// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure lens-demicube-moves (Explore, lens explorer B; docs/EXPLORE_PLAN.md §2.6 B, §1 (b); round 5: the physics, D29; round 5, wave 2: the motion, D30): the even labels of
// Cl(1, n−1), n = 2, 3, 4, as the corners of the n-demicube — a segment {0, 3}, a tetrahedron {0, 3, 5, 6}, the 16-cell on an octagon (the corner 1 on top, the
// 4-volume at the bottom, the three boost planes facing the three turn planes, the edges out of the corner 1 bold); each plane corner marked by the sign of its square
// (diamond "+1": a boost acts in that plane; ring "−1": a rotation does; a legend gives both words) and named as the component of F it is in the stored cell Cl(1, n−1)
// of maxwell.json (in Cl(1,3) the equator of the 16-cell: Ex, Ey, Ez and Bz, By, Bx, each over its plane's label; MAP-013, EQN-002) — names only, no sentence.
// Beside it, the motion (motion.jsx): what the even element of the picked plane, R = a₂a₁ of the two mirrors the amount places, does as the sandwich R x R̃ to an
// event, a rod with a clock at its middle, a square (n = 3) and a cube (n = 4): the spacetime view of a boost (world lines, the tick's new time, the rod's length at one
// moment, the event's path) or the plane of a turn, and the space view at one moment; Play grows the amount from 0. Its two weights (on the corner 1 and on the plane)
// are bars on those corners; a second plane shows the corner the product lands on, with its sign, and the two moves composed (R_b R_a: its boost and the rotation
// left), captioned by the rows MIR-007 and MIR-008. Every number from engines/explore/lens.js (demicubeMoves, motionBy, composeBy, moveView, productOf) through the
// kernel (tests/explore/lens.test.mjs, motion.test.mjs: the textbook boost and rotation matrices, the stored examples of mirrors.json; physics.test.mjs: the names).
// Lens chips keep the names: cube (all 2^n corners, even filled, odd hollow), simplex (the planes as edges of the (n−1)-simplex), orthoplex (the facets of the
// labels); primes and bits print the labels (products of prime names as a·b/gcd²). Controls: n chips, the plane a (pick a corner), the amount (chips, and Play),
// a second plane b (chips).
import React, { useState, useEffect, useMemo } from 'react';
import { Controls, Chips, FigSvg, r1, f2 } from '../../kit.jsx';
import { popcount } from '../../../../engines/bitrule.js';
import { MOVE_NS, AMOUNTS, demicubeMoves, motionOf, composeOf, moveView, productOf, nameOf, printingOf, primeProduct, det } from '../../../../engines/explore/lens.js';
import { VW, VH, halfXY, MoveMark, Pick, signTxt } from './parts.jsx';
import { physicsOf, placeTags, PlacedTag, PhysSimplex, PhysCube, PhysOrthoplex } from './physics.jsx';
import { motionPanels, MotionReadout, MotionRows, MotionPlay, useMotionPlayer, useMotionScene } from './motion.jsx';

const ID = 'lens-demicube-moves';
const LENS_PANEL = { cube: 'cube', simplex: 'simplex', orthoplex: 'orthoplex' };
const rng = n => Array.from({ length: n }, (_, i) => i);
const planesOf = n => demicubeMoves(n).planes.map(p => p.m);
function init(params = {}) {
  const n = MOVE_NS.includes(params.n) ? params.n : 4, P = planesOf(n);
  return { n, a: P.includes(params.a) ? params.a : 3, k: Number.isInteger(params.amount) && params.amount >= 0 && params.amount < 5 ? params.amount : 3, b: P.includes(params.b) ? params.b : null };
}

// ---------------------------------------------------------------- the demicube of the moves (the explorer's own view), with the weights of the move as a strip of bars
/** the kind of a plane corner in words, beside its mark: a boost acts in a plane whose square is +1, a rotation in one whose square is −1 */
const KIND_WORD = { boost: 'boost', turn: 'rotation' };
function MovesPanel({ M, a, b, mv, prod, nm, phys, pickA, isLens, row }) {
  const n = M.n, P = halfXY(n, { x0: 40, x1: 260, y0: 30, y1: 172 }), C = [150, 101], kind = m => (M.planes.find(p => p.m === m) || {}).kind;
  const radial = (m, far) => { const [x, y] = P[m], dx = x - C[0], dy = y - C[1], L = Math.hypot(dx, dy) || 1; return [x + dx / L * far, y + dy / L * far]; };
  const tags = useMemo(() => placeTags(M.corners.map(m => {
    const [x, y] = P[m], far = Math.hypot(x - C[0], y - C[1]) > 3, nmP = kind(m) ? phys(m) : null;
    return { kind: 'corner', m, at: [x, y], dir: far ? Math.atan2(y - C[1], x - C[0]) : -Math.PI / 2, gap: kind(m) ? 17 : 7, lines: nmP ? [{ text: nmP, px: 11 }, { text: nm(m), px: 10 }] : [{ text: nm(m), px: 12, mono: true }] };
  }), [...M.corners.map(m => [...P[m], kind(m) ? 17 : 7]), ...[16, 38].flatMap(y => [14, 32, 48, 64, 80].map(x => [x, y, 8]))]), [n, M.corners.map(m => `${phys(m)}|${nm(m)}`).join()]);   // eslint-disable-line react-hooks/exhaustive-deps
  const bar = (m, w, row2) => { const y = 222 + row2 * 18, x0 = 136, len = 46 * Math.abs(w); return (
    <g key={'w' + m} data-weight={`${m},${+w.toFixed(6)}`}>
      <text x={60} y={y + 4} textAnchor="end" className="lx-name">{nm(m)}</text>
      <line x1={70} y1={y} x2={202} y2={y} className="lx-axis" />
      <line x1={x0} y1={y - 6} x2={x0} y2={y + 6} className="lx-bar-base" />
      <rect x={r1(w < 0 ? x0 - len : x0)} y={y - 4} width={r1(Math.max(0.6, len))} height={8} rx={2} className="lx-bar" />
      <text x={244} y={y + 4} textAnchor="end" className="lx-s lx-bold">{f2(w)}</text>
    </g>); };
  const glyph = (k, y) => (
    <g key={k} data-legend={k}>
      {k === 'boost' ? <polygon points={`14,${y - 8} 22,${y} 14,${y + 8} 6,${y}`} className="lx-mark-ring" /> : <circle cx={14} cy={y} r={7} className="lx-mark-ring" />}
      <text x={28} y={y + 4} className="lx-s">{`${k === 'boost' ? '+1' : '−1'} ${KIND_WORD[k]}`}</text>
    </g>);
  return (
    <div className={'fig-panel' + (isLens ? ' is-lens' : '')}>
      <FigSvg id={ID} row={row} part="demicube view" viewBox={`0 0 ${VW} ${VH}`}>
        {M.edges.map(([u, v]) => <line key={u + '-' + v} x1={r1(P[u][0])} y1={r1(P[u][1])} x2={r1(P[v][0])} y2={r1(P[v][1])} className={u === 0 && v === a ? 'lx-edge is-sel' : u === 0 ? 'lx-edge is-bold' : 'lx-hair-2'} data-edge={`${u},${v}`} />)}
        {[...new Set(M.planes.map(p => p.kind))].sort().map((k, i) => glyph(k, 16 + 22 * i))}
        {M.corners.map(m => {
          const [x, y] = P[m], knd = kind(m);
          const body = (
            <g key={'c' + m} data-corner={m}>
              {knd ? <><circle cx={r1(x)} cy={r1(y)} r={14} className="hit" /><MoveMark x={x} y={y} kind={knd} r={10} sel={m === a} /></> : <circle cx={r1(x)} cy={r1(y)} r={5.5} className="lx-mark-fill" />}
              {m === a && <circle cx={r1(x)} cy={r1(y)} r={16.5} className="lx-ring-sel" />}
              {prod && m === b && <circle cx={r1(x)} cy={r1(y)} r={16.5} className="lx-ring-lit" />}
              <title>{[knd ? phys(m) : null, nm(m), knd ? KIND_WORD[knd] : null].filter(Boolean).join(' · ')}</title>
            </g>
          );
          return knd ? <Pick key={'p' + m} param="a" on={m === a} label={`plane ${nm(m)}, ${phys(m)}, square ${knd === 'boost' ? '+1' : '−1'}, ${KIND_WORD[knd]}`} onPick={pickA(m)}>{body}</Pick> : body;
        })}
        {tags.map(t => <PlacedTag key={'t' + t.m} t={t} />)}
        {prod && (() => { const [x, y] = P[prod.to], [sx, sy] = radial(prod.to, -26); return <g data-product={`${prod.a},${prod.b},${prod.to},${prod.s}`}><circle cx={r1(x)} cy={r1(y)} r={19.5} className="lx-ring-prod" /><text x={r1(sx)} y={r1(sy + 4)} textAnchor="middle" className="lx-s lx-tag">{signTxt(prod.s)}</text></g>; })()}
        <line x1={14} y1={206} x2={286} y2={206} className="lx-hair" />
        {bar(0, mv.weights.one, 0)}{bar(a, mv.weights.plane, 1)}
      </FigSvg>
    </div>
  );
}

export default function DemicubeMoves({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const [st, setSt] = useState(() => init(params));
  useEffect(() => { setSt(init(params)); }, [params.n, params.a, params.amount, params.b]);   // eslint-disable-line react-hooks/exhaustive-deps
  const M = useMemo(() => demicubeMoves(st.n), [st.n]), n = M.n, planes = M.planes.map(p => p.m);
  const a = planes.includes(st.a) ? st.a : 3, b = planes.includes(st.b) ? st.b : null, k = st.k;
  // the motion of the frame Play has reached (the drawing starts complete, at the chip): every number below is the sandwich R x R̃ of that frame (motion.jsx)
  const player = useMotionPlayer(`${n}|${a}|${k}|${b}`), scene = useMotionScene(n, a, k, player.frame, b), mv = scene.mo;
  const prod = b === null ? null : productOf(n, a, b);
  const how = printingOf(lens, mode, level), nm = m => nameOf(m, how, M.axes, M.eps), view = LENS_PANEL[lens] || null;
  const ph = physicsOf(1, n - 1), phys = m => (popcount(m) === 2 && ph ? ph.blades[m].label : null);
  const pickA = m => () => setSt(s => ({ ...s, a: m }));
  const kindOf = m => (M.planes.find(p => p.m === m) || {}).kind;
  const lit = prod ? [b, prod.to] : [];
  const planeLabel = m => `plane ${nm(m)}, ${phys(m)}`;
  const primes = how === 'primes', ew = m => (research && how !== 'clifford' && !primes ? <>e<sub>{nm(m)}</sub></> : nm(m));
  const panels = [];
  if (view === 'cube') panels.push(<PhysCube key="cube" id={ID} row={row} part="cube view" N={n} phys={phys} base={nm} isLens research={research} sel={a} lit={lit} pickOf={m => (planes.includes(m) ? pickA(m) : null)} pickLabel={planeLabel} />);
  if (view === 'simplex') panels.push(<PhysSimplex key="simplex" id={ID} row={row} part="simplex view" N={n} slots={rng(n)} phys={phys} base={nm} isLens edgeMark={m => ({ kind: kindOf(m) })} faces={false} sel={a} lit={lit.filter(m => popcount(m) >= 2)} pickOf={pickA} pickLabel={planeLabel} />);
  if (view === 'orthoplex') panels.push(<PhysOrthoplex key="ortho" id={ID} row={row} part="orthoplex view" N={n} isLens research={research} phys={phys} base={nm} pole={(i, plus) => (plus ? '+' : '−') + nm(1 << i)} facets={[{ m: a, cls: 'sel' }, ...(prod ? [{ m: b, cls: 'lit' }, { m: prod.to, cls: 'to' }] : [])]} />);
  panels.push(<MovesPanel key="moves" M={M} a={a} b={b} mv={mv} prod={prod} nm={nm} phys={phys} pickA={pickA} isLens={lens === 'demicube'} row={row} />);
  panels.push(...motionPanels(scene, { research, row }));
  const [i, j] = mv.axes, mat = mv.matrix, c = M.counts, turn = mv.kind === 'turn';
  const pp = prod ? primeProduct(prod.a, prod.b) : null;
  return (
    <div className="fig fig-lens fig-lens-demicube" data-n={n} data-plane={a} data-amount={k} data-frame={scene.frame}>
      <div className="fig-panels">{panels}</div>
      <div className="lx-readout">
        <p data-square={mv.square} data-kind={mv.kind}>
          <span>{research && how !== 'clifford' && !primes ? <>plane e<sub>{nm(a)}</sub></> : `plane ${nm(a)}`}</span>
          {phys(a) && <span data-phys-plane={phys(a)}>{phys(a)}</span>}
          <span><span className="lx-k">square</span> {signTxt(mv.square)}</span>
          <span data-kind-word={KIND_WORD[mv.kind]}>{mv.name}</span>
        </p>
        <MotionReadout scene={scene} research={research} nm={nm} ew={ew} />
        {research && <p data-matrix={[mat[i][i], mat[i][j], mat[j][i], mat[j][j]].map(x => +x.toFixed(6)).join(',')}>
          <span className="lx-k">{`matrix (${M.axes[i]}, ${M.axes[j]})`}</span><span>{`${f2(mat[i][i])} ${f2(mat[i][j])} · ${f2(mat[j][i])} ${f2(mat[j][j])}`}</span>
          <span><span className="lx-k">det</span> {f2(det(mat))}</span>
        </p>}
        {prod && <p data-product={`${prod.a},${prod.b},${prod.to},${prod.s}`}>
          {primes
            ? <span>{research ? `${pp.A} × ${pp.B}${pp.g > 1 ? ` ÷ ${pp.g}²` : ''} = ${pp.K}` : `${pp.A} × ${pp.B} → ${pp.K}`}</span>
            : research && how !== 'clifford'
              ? <span>e<sub>{nm(a)}</sub> e<sub>{nm(b)}</sub> = {prod.s < 0 ? '−' : '+'}{prod.to ? <>e<sub>{nm(prod.to)}</sub></> : '1'}</span>
              : <span>{research ? `${nm(a)} ${nm(b)} = ${prod.s < 0 ? '−' : '+'}${nm(prod.to)}` : `${nm(a)} × ${nm(b)} → ${nm(prod.to)}`}</span>}
          <span><span className="lx-k">sign</span> {signTxt(prod.s)}</span>
        </p>}
        {research && <p data-counts={`${c.corners},${c.edges},${c.degree},${c.boosts},${c.turns}`}>
          <span><span className="lx-k">corners</span> {c.corners}</span><span><span className="lx-k">edges</span> {c.edges}</span><span><span className="lx-k">degree</span> {c.degree}</span>
          <span><span className="lx-k">boost planes</span> {c.boosts}</span><span><span className="lx-k">turn planes</span> {c.turns}</span>
        </p>}
      </div>
      <MotionRows />
      <Controls label="moves">
        <Chips label="n" items={MOVE_NS} value={n} onPick={v => setSt(s => { const P = planesOf(v); return { ...s, n: v, a: P.includes(s.a) ? s.a : 3, b: P.includes(s.b) ? s.b : null }; })} param="n" mono />
        <Chips label={turn ? 'angle' : 'speed'} items={[0, 1, 2, 3, 4]} value={k} onPick={v => setSt(s => ({ ...s, k: v }))} render={x => (turn ? `${AMOUNTS.turn[x]}°` : String(AMOUNTS.boost[x]))} param="amount" mono />
        <MotionPlay player={player} />
        <Chips label="second plane" items={[null, ...planes]} value={b} onPick={v => setSt(s => ({ ...s, b: v }))} render={x => (x === null ? 'none' : nm(x))} param="b" mono />
      </Controls>
    </div>
  );
}
DemicubeMoves.meta = { id: ID, lenses: ['simplex', 'cube', 'demicube', 'orthoplex', 'bits', 'primes'], learner: true };
/** the numbers the figure draws, the planes' names (the components of F in Cl(1, n−1)) and the motion of the chip (the sandwich R x R̃), for the frame's data download */
DemicubeMoves.data = (params = {}) => {
  const s = init(params), M = demicubeMoves(s.n), mv = moveView(s.n, s.a, s.k), ph = physicsOf(1, M.n - 1), mo = motionOf(s.n, s.a, s.k), co = s.b === null ? null : composeOf(s.n, s.a, s.b, s.k);
  const motion = { name: mo.name, speed: mo.speed, rapidity: mo.rapidity, gamma: mo.gamma, angle: mo.angle, rotor: mo.R, event: mo.event, rod: { before: mo.rod.before, after: mo.rod.after }, tick: mo.tick.time, sides: mo.squareBody ? mo.squareBody.sides : mo.cubeBody ? mo.cubeBody.sides : null };
  const composed = co && { planes: [co.a, co.b], rotor: co.R, speed: co.speed, gamma: co.gamma, direction: co.direction, rotationLeft: co.angle, plane: co.planeName, signedAngle: co.signedAngle };
  return { n: M.n, corners: M.corners, edges: M.edges, planes: M.planes.map(p => ({ ...p, name: ph.blades[p.m].label })), counts: M.counts, plane: s.a, kind: mv.kind, amount: mv.value, weights: mv.weights, matrix: mo.matrix, det: mv.det, onceDet: mv.onceDet, points: mv.pts, images: mv.images, product: s.b === null ? null : productOf(s.n, s.a, s.b), motion, composed };
};
