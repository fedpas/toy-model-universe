// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/lens/parts.jsx — what the three lens explorers share: the layouts of the shapes of the labels (simplex, cube, demicube, orthoplex), the marks,
// the pick (a drawn element that is a control: role="button", keyboard reachable, data-param), and the four panels the lens chips switch between. Every count, sign
// and label a panel prints comes from engines/explore/lens.js (through the kernel) or is a name the caller passes; this file only places them. Tokens only (lens.css).
// Marks: E, ρ and a trivector with a time index filled; B, J and one without a ring; T (two time indices) a square; a boost plane a diamond with "+1", a turn plane a
// ring with "−1"; a contraction solid, a wedge dashed; the selection thicker and in --accent (never by colour alone); even corners filled, odd ones hollow.
import React from 'react';
import { FigSvg, r1, arrowHead } from '../../kit.jsx';
import { hull } from '../../FourViews.jsx';
import { popcount } from '../../../../engines/bitrule.js';
import { bitsOf } from '../../../../engines/labels.js';
import { orthoplexOf, facetOf, ridgeOf, demicubeEdges } from '../../../../engines/explore/lens.js';

export const VW = 300, VH = 252;
const rng = n => Array.from({ length: n }, (_, i) => i);
const pts = P => P.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ');
const mean = P => [P.reduce((s, p) => s + p[0], 0) / P.length, P.reduce((s, p) => s + p[1], 0) / P.length];
const evenLabel = m => popcount(m) % 2 === 0;
export const signTxt = s => (s > 0 ? '+1' : s < 0 ? '−1' : '0');
const panelClass = (isLens, wide) => 'fig-panel' + (isLens ? ' is-lens' : '') + (wide ? ' lx-wide' : '');

// ---------------------------------------------------------------- layouts
/** the vertices of the simplex with N vertices, slot 0 on top: a segment, a triangle, a tetrahedron seen from the front, then regular polygons */
export function simplexXY(N, cx = 150, cy = 130, R = 94) {
  if (N <= 1) return [[cx, cy]];
  if (N === 2) return [[cx, cy - R * 0.9], [cx, cy + R * 0.9]];
  if (N === 4) return [[cx, cy - R], [cx - R * 0.98, cy + R * 0.64], [cx + R * 0.98, cy + R * 0.64], [cx + R * 0.3, cy + R * 0.04]];
  return rng(N).map(s => [cx + R * Math.cos(-Math.PI / 2 + 2 * Math.PI * s / N), cy + R * Math.sin(-Math.PI / 2 + 2 * Math.PI * s / N)]);
}
// the oblique projection of the cube for N <= 4: corner m at (its grade, Σ v_i over its generators) — a parallel projection in which the layers are columns
const OBL = { 1: [0], 2: [-1, 1], 3: [-1, 0, 1], 4: [-3, -2, 1, 4] };
const CUBE_BOX = { x0: 26, x1: 274, y0: 50, y1: 214 };
/** the corners of the N-cube in columns by grade (left to right); for N <= 4 an oblique projection of the cube, for N >= 5 each column spaced evenly */
export function cubeXY(N, box = CUBE_BOX) {
  const { x0, x1, y0, y1 } = box, dx = (x1 - x0) / Math.max(1, N), mid = (y0 + y1) / 2, P = new Array(1 << N);
  if (OBL[N]) {
    const v = OBL[N], h = m => bitsOf(m).reduce((s, i) => s + v[i], 0), span = Math.max(1, ...rng(1 << N).map(m => Math.abs(h(m)))), sy = (y1 - y0) / 2 / span;
    for (let m = 0; m < 1 << N; m++) P[m] = [x0 + dx * popcount(m), mid + sy * h(m)];
  } else {
    for (let g = 0; g <= N; g++) {
      const col = rng(1 << N).filter(m => popcount(m) === g), step = col.length > 1 ? Math.min(24, (y1 - y0) / (col.length - 1)) : 0;
      col.forEach((m, j) => { P[m] = [x0 + dx * g, mid + (j - (col.length - 1) / 2) * step]; });
    }
  }
  return P;
}
// the 16-cell on an octagon: the corner 1 on top, the 4-volume at the bottom, the three planes holding generator 1 on the left facing their complements on the right
const OCT = { 0: 90, 3: 135, 5: 180, 9: 225, 15: 270, 12: 315, 10: 0, 6: 45 };
/** labels of one parity placed in a box: a segment (N = 2), a tetrahedron (N = 3), the octagon of the 16-cell (N = 4) — the even labels, an odd label o where o xor 1
 *  would sit —, and for N >= 5 columns by grade */
export function halfXY(N, box, odd = false) {
  const { x0, x1, y0, y1 } = box, cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, R = Math.min(x1 - x0, y1 - y0) / 2, E = {};
  if (N >= 5) {
    const grades = rng(N + 1).filter(g => g % 2 === (odd ? 1 : 0)), dx = (x1 - x0) / Math.max(1, grades.length - 1), P = {};
    grades.forEach((g, c) => { const col = rng(1 << N).filter(m => popcount(m) === g), step = col.length > 1 ? Math.min(22, (y1 - y0) / (col.length - 1)) : 0; col.forEach((m, j) => { P[m] = [x0 + dx * c, cy + (j - (col.length - 1) / 2) * step]; }); });
    return P;
  }
  if (N <= 1) E[0] = [cx, cy];
  else if (N === 2) { E[0] = [cx - R * 0.78, cy]; E[3] = [cx + R * 0.78, cy]; }
  else if (N === 3) { E[0] = [cx, cy - R * 0.88]; E[3] = [cx - R * 0.9, cy + R * 0.34]; E[5] = [cx, cy + R * 0.88]; E[6] = [cx + R * 0.9, cy + R * 0.34]; }
  else for (const [m, deg] of Object.entries(OCT)) E[m] = [cx + R * 0.9 * Math.cos(deg * Math.PI / 180), cy - R * 0.9 * Math.sin(deg * Math.PI / 180)];
  if (!odd) return E;
  const O = {}; for (const [m, p] of Object.entries(E)) O[Number(m) ^ 1] = p;
  return O;
}
/** the 2N poles of the N-orthoplex on its Petrie polygon: +e_i at 90° − 180°·i/N, −e_i opposite */
export function petrieXY(N, cx = 150, cy = 130, R = 90) {
  return rng(2 * N).map(v => { const i = v >> 1, ang = Math.PI / 2 - Math.PI * i / N + (v % 2 ? Math.PI : 0); return [cx + R * Math.cos(ang), cy - R * Math.sin(ang)]; });
}

// ---------------------------------------------------------------- marks, the pick, the arrow
const FILLED = new Set(['E', 'rho', 'Faraday']);
/** the mark of a role: E, ρ and a trivector with a time index filled; T a square; the others a ring */
export function RoleMark({ x, y, role, r = 5 }) {
  if (role === 'T') return <rect x={r1(x - r)} y={r1(y - r)} width={r1(2 * r)} height={r1(2 * r)} rx={1.2} className="lx-mark-t" />;
  return <circle cx={r1(x)} cy={r1(y)} r={r} className={FILLED.has(role) ? 'lx-mark-fill' : 'lx-mark-ring'} />;
}
/** a plane corner by the sign of its square: a boost plane (+1) a diamond, a turn plane (−1) a ring, the sign printed inside */
export function MoveMark({ x, y, kind, r = 10, sel = false }) {
  const cls = (kind === 'boost' ? 'mv-boost' : 'mv-turn') + (sel ? ' is-sel' : '');
  const shape = kind === 'boost'
    ? <polygon points={pts([[x, y - r * 1.2], [x + r * 1.2, y], [x, y + r * 1.2], [x - r * 1.2, y]])} />
    : <circle cx={r1(x)} cy={r1(y)} r={r} />;
  return <g className={cls} data-square={kind === 'boost' ? 1 : -1}>{shape}<text x={r1(x)} y={r1(y + 3.6)} textAnchor="middle" className="lx-s">{kind === 'boost' ? '+1' : '−1'}</text></g>;
}
/** a dot for a corner without a role mark: filled when even, hollow when odd */
export function ParityDot({ x, y, even, r = 3 }) { return <circle cx={r1(x)} cy={r1(y)} r={r} className={even ? 'lx-mark-fill' : 'lx-mark-ring'} />; }
/** a drawn element that is a control: role="button", keyboard reachable, marked with the param of its interactive entry */
export function Pick({ param, on, label, onPick, children, focusable = true, data = {} }) {
  const key = e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); onPick(); } };
  return <g role="button" tabIndex={focusable || on ? 0 : -1} aria-pressed={!!on} aria-label={label} data-param={param} className={'fig-cell lx-pick' + (on ? ' is-on' : '')} onClick={onPick} onKeyDown={key} {...data}>{children}</g>;
}
/** which picks of a big shape stay in the tab order: all of them up to 32 corners, else the corners of grade 1 and 2 (every corner can still be clicked) */
export const focusRule = N => m => N <= 5 || popcount(m) <= 2;
/** an arrow from p to q, shortened at both ends and moved sideways by `side`; solid (a contraction) or dashed (a wedge), the sign printed near its head */
export function MoveArrow({ p, q, op, s, side = 7, cut = 11, data = {} }) {
  const dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy) || 1, ux = dx / L, uy = dy / L, ox = -uy * side, oy = ux * side, c = Math.min(cut, L / 3);
  const a = [p[0] + ux * c + ox, p[1] + uy * c + oy], b = [q[0] - ux * c + ox, q[1] - uy * c + oy], tx = b[0] - uy * 12, ty = b[1] + ux * 12;
  return (
    <g className="lx-arrow" {...data}>
      <line x1={r1(a[0])} y1={r1(a[1])} x2={r1(b[0])} y2={r1(b[1])} style={op === 'wedge' ? { strokeDasharray: '4 3' } : undefined} />
      <path d={arrowHead(a[0], a[1], b[0], b[1], 7)} />
      <text x={r1(tx)} y={r1(ty + 4)} textAnchor="middle" className="lx-s lx-bold">{signTxt(s)}</text>
    </g>
  );
}
const stepData = st => ({ 'data-step': `${st.from},${st.axis},${st.to},${st.op},${st.s}` });

// ---------------------------------------------------------------- the simplex panel
/** The simplex whose vertices are the N generators (slots: the generator of each vertex, slot 0 on top). names(m): the label printer; vertexRole(g): a role mark or
 *  null; edgeMark(m): { role } or { kind } (a plane) or null; faces: the grade-3 faces drawn faintly; sel: the picked edge; step { from, axis, to, op, s }: an arrow
 *  between the centroids of the two labels; lit: masks drawn lit (an edge dashed thick, a face shaded); pickOf(m): the handler of the edge m, or null. */
export function SimplexPanel({ id, row, part, N, slots, names, vertexRole = () => null, edgeMark = () => null, faces = true, sel = null, step = null, lit = [], pickOf = () => null, pickLabel = String, isLens, wide }) {
  const S = simplexXY(N), at = new Map(slots.map((g, s) => [g, S[s]])), C = mean(S);
  const posOf = m => mean(bitsOf(m).map(g => at.get(g)));
  const edges = [], tris = [];
  for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) edges.push((1 << i) | (1 << j));
  for (let m = 0; m < 1 << N; m++) if (popcount(m) === 3) tris.push(m);
  const markAt = m => { const [g, h] = bitsOf(m), P = at.get(g), Q = at.get(h), t = N === 6 ? 0.42 : 0.5; return [P[0] + (Q[0] - P[0]) * t, P[1] + (Q[1] - P[1]) * t]; };
  const face = m => { const V = bitsOf(m).map(g => at.get(g)); return V.length >= 3 ? hull(V) : V; };
  const shaded = [...lit.filter(m => popcount(m) >= 3), ...(step && popcount(step.to) >= 3 ? [step.to] : [])];
  const dashed = lit.filter(m => popcount(m) === 2 && m !== sel), ends = step ? [step.from, step.to] : [];
  return (
    <div className={panelClass(isLens, wide)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {faces && tris.map(m => <polygon key={'f' + m} points={pts(face(m))} className="lx-face" data-tri={m} />)}
        {shaded.map((m, i) => <polygon key={'L' + i} points={pts(face(m))} className="lx-face-on" data-lit={m} />)}
        {edges.map(m => {
          const [g, h] = bitsOf(m), P = at.get(g), Q = at.get(h), info = edgeMark(m), on = sel === m, [mx, my] = markAt(m), handler = pickOf(m);
          const body = (
            <g key={'e' + m} data-piece={m} data-role={info && info.role ? info.role : undefined}>
              {handler && <line x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className="lx-hit" />}
              <line x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className={on || dashed.includes(m) ? 'lx-edge is-sel' : 'lx-edge'} style={dashed.includes(m) ? { strokeDasharray: '5 3' } : undefined} />
              {info && info.role && <RoleMark x={mx} y={my} role={info.role} r={on ? 5.6 : 4.6} />}
              {info && info.kind && <MoveMark x={mx} y={my} kind={info.kind} r={8} sel={on} />}
            </g>
          );
          return handler ? <Pick key={'p' + m} param="a" on={on} label={pickLabel(m)} onPick={handler}>{body}</Pick> : body;
        })}
        {step && step.from && step.to ? <MoveArrow p={posOf(step.from)} q={posOf(step.to)} op={step.op} s={step.s} data={stepData(step)} /> : null}
        {slots.map((g, s) => { const [x, y] = S[s], role = vertexRole(g), dx = x - C[0], dy = y - C[1], L = Math.hypot(dx, dy) || 1; return (
          <g key={'v' + g} data-vertex={g} data-slot={s}>
            {role ? <RoleMark x={x} y={y} role={role} r={6} /> : <circle cx={r1(x)} cy={r1(y)} r={4} className="lx-mark-fill" />}
            {ends.includes(1 << g) && <circle cx={r1(x)} cy={r1(y)} r={10} className="lx-ring-sel" />}
            <text x={r1(x + dx / L * 18)} y={r1(y + dy / L * 18 + 4)} textAnchor="middle" className="lx-name">{names(1 << g)}</text>
          </g>); })}
        {sel ? (() => { const [mx, my] = markAt(sel), dx = mx - C[0], dy = my - C[1], L = Math.hypot(dx, dy) || 1, near = L < 8; return <text x={r1(near ? mx + 12 : mx + dx / L * 15)} y={r1(near ? my - 9 : my + dy / L * 15 + 4)} textAnchor={near ? 'start' : 'middle'} className="lx-s lx-tag">{names(sel)}</text>; })() : null}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the cube panel
/** The N-cube in columns by grade, the even columns on a band. names(m): the printer; cornerRole(m): a role mark (layers 1–3) or null (a parity dot);
 *  incidences: moves drawn thin (solid down, dashed up); step: the picked move, thick; sel / lit: corners ringed; pickOf(m): the handler of the corner m, or null. */
export function CubePanel({ id, row, part, N, names, cornerRole = () => null, incidences = [], step = null, sel = null, lit = [], pickOf = () => null, pickLabel = String, focusOf = focusRule(N), isLens, wide, research, allEdges = N <= 5, labelAll = N <= 3 }) {
  const P = cubeXY(N), cols = rng(N + 1), dx = (CUBE_BOX.x1 - CUBE_BOX.x0) / Math.max(1, N), r = N >= 6 ? 2.6 : N === 5 ? 3.4 : 5, bw = Math.min(14, dx / 2 - 2);
  const cubeEdges = []; if (allEdges) for (let m = 0; m < 1 << N; m++) for (const i of rng(N)) if (!bitsOf(m).includes(i)) cubeEdges.push([m, m | (1 << i)]);
  const ringed = new Set([sel, ...(step ? [step.from, step.to] : []), ...lit].filter(x => x !== null && x !== undefined));
  const layer = g => rng(1 << N).filter(m => popcount(m) === g).length;
  return (
    <div className={panelClass(isLens, wide)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {cols.filter(g => g % 2 === 0).map(g => <rect key={'b' + g} x={r1(CUBE_BOX.x0 + dx * g - bw)} y={24} width={r1(2 * bw)} height={202} rx={6} className="lx-band" data-even-layer={g} />)}
        {research && cols.map(g => <text key={'h' + g} x={r1(CUBE_BOX.x0 + dx * g)} y={16} textAnchor="middle" className="lx-s lx-muted">{g}</text>)}
        {cubeEdges.map(([a, b]) => <line key={a + '-' + b} x1={r1(P[a][0])} y1={r1(P[a][1])} x2={r1(P[b][0])} y2={r1(P[b][1])} className="lx-hair" />)}
        {incidences.map(x => <line key={'i' + x.from + ',' + x.axis} x1={r1(P[x.from][0])} y1={r1(P[x.from][1])} x2={r1(P[x.to][0])} y2={r1(P[x.to][1])} className="lx-inc" style={x.op === 'wedge' ? { strokeDasharray: '3 2.5' } : undefined} data-inc={`${x.from},${x.axis},${x.to},${x.op},${x.s}`} />)}
        {step && <line x1={r1(P[step.from][0])} y1={r1(P[step.from][1])} x2={r1(P[step.to][0])} y2={r1(P[step.to][1])} className="lx-edge is-sel" style={step.op === 'wedge' ? { strokeDasharray: '5 3' } : undefined} {...stepData(step)} />}
        {rng(1 << N).map(m => {
          const [x, y] = P[m], role = cornerRole(m), on = ringed.has(m), handler = pickOf(m), main = m === sel || (step && m === step.from);
          const body = (
            <g key={'c' + m} data-corner={m} data-grade={popcount(m)}>
              {handler && <circle cx={r1(x)} cy={r1(y)} r={Math.max(7, r + 3)} className="hit" />}
              {role ? <RoleMark x={x} y={y} role={role} r={r} /> : <ParityDot x={x} y={y} even={evenLabel(m)} r={Math.max(2, r - 1.5)} />}
              {on && <circle cx={r1(x)} cy={r1(y)} r={r + 4.5} className={main ? 'lx-ring-sel' : 'lx-ring-lit'} />}
              {(labelAll || on) && <text x={r1(x)} y={r1(y - r - 6)} textAnchor="middle" className="lx-s">{names(m)}</text>}
            </g>
          );
          return handler ? <Pick key={'p' + m} param="a" on={m === sel} label={pickLabel(m)} onPick={handler} focusable={focusOf(m)}>{body}</Pick> : body;
        })}
        {research && cols.map(g => <text key={'n' + g} x={r1(CUBE_BOX.x0 + dx * g)} y={242} textAnchor="middle" className="lx-s lx-bold" data-layer={`${g},${layer(g)}`}>{layer(g)}</text>)}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the demicube panel: the even half and the odd half of the cube side by side
/** The two halves of the N-cube: the even labels on the left (filled; grade-2 corners with their role mark), the odd labels on the right (hollow), each half a demicube
 *  with its edges (N <= 5); an odd label o sits where o xor 1 sits on the left. step: the picked move, which always crosses from one half to the other. */
export function DemicubePanel({ id, row, part, N, names, cornerRole = () => null, step = null, sel = null, lit = [], pickOf = () => null, pickLabel = String, focusOf = focusRule(N), isLens, wide, research }) {
  const Lp = halfXY(N, { x0: 16, x1: 134, y0: 48, y1: 208 }), Rp = halfXY(N, { x0: 166, x1: 284, y0: 48, y1: 208 }, true);
  const place = m => (evenLabel(m) ? Lp[m] : Rp[m]);
  const evens = rng(1 << N).filter(evenLabel), odds = rng(1 << N).filter(m => !evenLabel(m));
  const showEdges = N <= 5, r = N >= 6 ? 2.6 : N === 5 ? 3.2 : 5;
  const ringed = new Set([sel, ...(step ? [step.from, step.to] : []), ...lit].filter(x => x !== null && x !== undefined));
  const dot = m => {
    const [x, y] = place(m), role = popcount(m) === 2 ? cornerRole(m) : null, on = ringed.has(m), handler = pickOf(m), main = m === sel || (step && m === step.from);
    const body = (
      <g key={'c' + m} data-corner={m} data-half={evenLabel(m) ? 'even' : 'odd'}>
        {handler && <circle cx={r1(x)} cy={r1(y)} r={Math.max(7, r + 3)} className="hit" />}
        {role ? <RoleMark x={x} y={y} role={role} r={r} /> : <ParityDot x={x} y={y} even={evenLabel(m)} r={evenLabel(m) ? r : Math.max(2, r - 1)} />}
        {on && <circle cx={r1(x)} cy={r1(y)} r={r + 4.5} className={main ? 'lx-ring-sel' : 'lx-ring-lit'} />}
        {(N <= 3 || on) && <text x={r1(x)} y={r1(y - r - 6)} textAnchor="middle" className="lx-s">{names(m)}</text>}
      </g>
    );
    return handler ? <Pick key={'p' + m} param="a" on={m === sel} label={pickLabel(m)} onPick={handler} focusable={focusOf(m)}>{body}</Pick> : body;
  };
  const edgeLine = (a, b, cls, key, data) => <line key={key} x1={r1(place(a)[0])} y1={r1(place(a)[1])} x2={r1(place(b)[0])} y2={r1(place(b)[1])} className={cls} {...data} />;
  return (
    <div className={panelClass(isLens, wide)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        <text x={75} y={22} textAnchor="middle" className="lx-name">even</text>
        <text x={225} y={22} textAnchor="middle" className="lx-name lx-muted">odd</text>
        <line x1={150} y1={32} x2={150} y2={224} className="lx-hair" style={{ strokeDasharray: '2 4' }} />
        {showEdges && demicubeEdges(evens).map(([a, b]) => edgeLine(a, b, 'lx-hair-2', 'E' + a + '-' + b, { 'data-edge': `${a},${b}` }))}
        {showEdges && demicubeEdges(odds.map(o => o ^ 1)).map(([a, b]) => edgeLine(a ^ 1, b ^ 1, 'lx-hair', 'O' + a + '-' + b, {}))}
        {step ? <MoveArrow p={place(step.from)} q={place(step.to)} op={step.op} s={step.s} side={0} cut={9} data={stepData(step)} /> : null}
        {evens.map(dot)}{odds.map(dot)}
        {research && <text x={150} y={244} textAnchor="middle" className="lx-s lx-muted">{`${evens.length} even · ${odds.length} odd`}</text>}
      </FigSvg>
    </div>
  );
}

// ---------------------------------------------------------------- the orthoplex panel
/** The N-orthoplex on its Petrie polygon: the poles ±e_i (pole(i, plus) names them; + filled, − hollow), its edges faint, and facets [{ m, cls: 'sel' | 'to' | 'lit' }]
 *  drawn through their N poles (facetOf); ridge [a, b]: the poles the two facets share are ringed (labels one generator apart share N − 1 of them). */
export function OrthoplexPanel({ id, row, part, N, pole, facets = [], ridge = null, isLens, wide, research }) {
  const O = orthoplexOf(N), P = petrieXY(N), C = [150, 130];
  const poly = m => { const vs = facetOf(m, N).map(v => P[v]); return vs.length >= 3 ? hull(vs) : vs; };
  const common = ridge ? ridgeOf(ridge[0], ridge[1], N) : [];
  return (
    <div className={panelClass(isLens, wide)}>
      <FigSvg id={id} row={row} part={part} viewBox={`0 0 ${VW} ${VH}`}>
        {O.edges.map(([u, v]) => <line key={u + '-' + v} x1={r1(P[u][0])} y1={r1(P[u][1])} x2={r1(P[v][0])} y2={r1(P[v][1])} className="lx-hair" />)}
        {facets.map(f => { const vs = poly(f.m), data = { 'data-facet': `${f.m},${f.cls}` }; return vs.length >= 3
          ? <polygon key={f.cls + f.m} points={pts(vs)} className={'lx-facet lx-facet-' + f.cls} {...data} />
          : <line key={f.cls + f.m} x1={r1(vs[0][0])} y1={r1(vs[0][1])} x2={r1(vs[vs.length - 1][0])} y2={r1(vs[vs.length - 1][1])} className={'lx-facet lx-facet-' + f.cls} {...data} />; })}
        {O.poles.map(p => { const [x, y] = P[p.v], dx = x - C[0], dy = y - C[1], L = Math.hypot(dx, dy) || 1; return (
          <g key={'v' + p.v} data-pole={`${p.axis},${p.plus ? '+' : '-'}`}>
            <circle cx={r1(x)} cy={r1(y)} r={4.4} className={p.plus ? 'lx-mark-fill' : 'lx-mark-ring'} />
            {common.includes(p.v) && <circle cx={r1(x)} cy={r1(y)} r={8.5} className="lx-ring-lit" data-ridge={p.v} />}
            {N <= 5 && <text x={r1(x + dx / L * 18)} y={r1(y + dy / L * 18 + 4)} textAnchor="middle" className="lx-s">{pole(p.axis, p.plus)}</text>}
          </g>); })}
        {research && <text x={8} y={16} className="lx-s lx-muted">{`${2 * N} poles · ${O.edges.length} edges · ${O.facets} facets`}</text>}
      </FigSvg>
    </div>
  );
}
