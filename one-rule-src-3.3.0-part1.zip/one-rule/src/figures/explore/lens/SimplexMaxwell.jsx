// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figure lens-simplex-maxwell (Explore, lens explorer A; docs/EXPLORE_PLAN.md §2.6 A, §1 (a); round 5: the physics, D29 and interface 24): the n-simplex of Cl(1, n),
// n = 1…4 — every vertex carries its source (ρ, Jx, Jy …), every edge its field component (Ex … Bz, B12 …: the labels maxwell.json stores; E filled, B ring, T
// square), every triangle the identity whose target it is (Faraday z, no monopole, Bianchi 123 …: the stored equation names); under each name the label in the
// printing the lens asks for. Picking an edge lists the equations its component appears in, with the sign of its term (KaTeX at research level, words at learner
// level: physics.jsx PhysicsNote), and lights their targets; the picked axis b lights one move e_b e_a = ± e_{a xor b}: a contraction (solid arrow to the end of the
// edge, "drop b") or a wedge (dashed arrow into the triangle, "add b"), with the kernel's sign. Every number from engines/explore/lens.js simplexMaxwell / stepOf
// (tests/explore/lens.test.mjs: equal to maxwell.json cells 1,1 … 1,4 and their mirrors; counts 2, 9, 24, 50); every name from cellPhysics
// (tests/explore/physics.test.mjs: equal to the stored json, every listed equation recomputed through the kernel). Lens chips redraw the same data and keep the
// names: cube (the labels as corners of the (n+1)-cube, F = layer 2, the move an edge to the flipped corner), demicube (F among the even corners, the move leaves the
// half), orthoplex (a label is the facet with + poles on its generators, a move crosses one ridge); bits and primes print the labels under the names (a drop divides
// by the axis prime, an add multiplies). Controls: n chips, the piece a (pick an edge), the axis b (chips), the mirror (k, d) → (d, k) (four-views-maxwell).
import React, { useState, useEffect, useMemo } from 'react';
import { Controls, Chips } from '../../kit.jsx';
import { popcount, PRIMES } from '../../../../engines/bitrule.js';
import { bitsOf } from '../../../../engines/labels.js';
import { SIMPLEX_NS, simplexMaxwell, stepOf, nameOf, printingOf, primeName } from '../../../../engines/explore/lens.js';
import { signTxt } from './parts.jsx';
import { physicsOf, eqWords, PhysSimplex, PhysCube, PhysDemicube, PhysOrthoplex, PhysicsNote } from './physics.jsx';

const ID = 'lens-simplex-maxwell';
const LENS_PANEL = { cube: 'cube', demicube: 'demicube', orthoplex: 'orthoplex' };
const OPWORD = { contract: 'drop', wedge: 'add' };
const isPiece = (m, N) => Number.isInteger(m) && m > 0 && m < 1 << N && popcount(m) === 2;
function init(params = {}) {
  const n = SIMPLEX_NS.includes(params.n) ? params.n : 3, N = n + 1;
  const a = isPiece(params.a, N) ? params.a : 3, b = Number.isInteger(params.b) && params.b >= 0 && params.b < N ? params.b : Math.min(2, N - 1);
  return { n, mir: params.mirror === true && n > 1, a, b };
}
/** a label of one cell carried to another through the drawing slots (the generator at each vertex), so that a picked edge stays where it is drawn */
function carry(m, from, to) {
  const gens = bitsOf(m);
  return from.vertices.filter(v => gens.includes(v.g) && v.slot < to.N).reduce((out, v) => out | (1 << to.vertices[v.slot].g), 0);
}

export default function SimplexMaxwell({ params = {}, lens = null, level = 'research', theme, row, mode = 'phys' }) {
  const research = level !== 'learner';
  const [st, setSt] = useState(() => init(params));
  useEffect(() => { setSt(init(params)); }, [params.n, params.a, params.b, params.mirror]);   // eslint-disable-line react-hooks/exhaustive-deps
  const S = useMemo(() => simplexMaxwell(st.n, st.mir), [st.n, st.mir]);
  const a = isPiece(st.a, S.N) ? st.a : 3, b = st.b < S.N ? st.b : S.N - 1, step = stepOf(S.eps, a, b);
  const how = printingOf(lens, mode, level), nm = m => nameOf(m, how, S.axes, S.eps), view = LENS_PANEL[lens] || null;
  const change = next => setSt(prev => {
    const from = simplexMaxwell(prev.n, prev.mir), to = simplexMaxwell(next.n, next.mir), ca = carry(prev.a, from, to), slotB = from.vertices.findIndex(v => v.g === prev.b);
    return { ...next, a: isPiece(ca, to.N) ? ca : (1 << to.vertices[0].g) | (1 << to.vertices[1].g), b: slotB >= 0 && slotB < to.N ? to.vertices[slotB].g : to.vertices[Math.min(2, to.N - 1)].g };
  });
  const ph = physicsOf(S.k, S.d), phys = m => ph.nameOf(m), hot = ph.eqsOf(a).map(e => e.target), into = ph.eqOf(step.to);
  const pickA = m => () => setSt(s => ({ ...s, a: m }));
  const pieceLabel = m => `${phys(m)}, ${nm(m)}`;
  const common = { id: ID, row, N: S.N, phys, base: nm, step, sel: a };
  const panels = [];
  if (view === 'cube') panels.push(<PhysCube key="cube" {...common} part="cube view" isLens research={research} cornerRole={m => (popcount(m) >= 1 && popcount(m) <= 3 ? S.roles[m] : null)} incidences={S.incidences} hotMoves={S.incidences.filter(x => x.from === a)} hot={hot} pickOf={m => (popcount(m) === 2 ? pickA(m) : null)} pickLabel={pieceLabel} />);
  if (view === 'demicube') panels.push(<PhysDemicube key="demi" {...common} part="demicube view" isLens research={research} cornerRole={m => S.roles[m]} pickOf={m => (popcount(m) === 2 ? pickA(m) : null)} pickLabel={pieceLabel} />);
  if (view === 'orthoplex') panels.push(<PhysOrthoplex key="ortho" id={ID} row={row} part="orthoplex view" N={S.N} isLens research={research} phys={phys} base={nm} pole={(i, plus) => (plus ? '+' : '−') + nm(1 << i)} facets={[{ m: a, cls: 'sel' }, { m: step.to, cls: 'to' }]} ridge={[a, step.to]} />);
  panels.push(<PhysSimplex key="simplex" {...common} part="simplex view" isLens={lens === 'simplex'} slots={S.vertices.map(v => v.g)} vertexRole={g => S.roles[1 << g]} edgeMark={m => ({ role: S.roles[m] })} hot={hot} pickOf={pickA} pickLabel={pieceLabel} />);
  const c = S.counts, word = OPWORD[step.op], axisName = nm(1 << b);
  const primes = how === 'primes', P = primeName(a), p = PRIMES[b], T = primeName(step.to);
  return (
    <div className={`fig fig-lens fig-lens-simplex`} data-cell={`${S.k},${S.d}`} data-n={S.n} data-mirror={S.mirrored ? 'true' : 'false'}>
      <div className={'fig-panels' + (panels.length === 1 ? ' lx-one' : '')}>{panels}</div>
      <div className="lx-readout">
        <p data-counts={`${c.pieces},${c.sources},${c.triangles},${c.incidences}`}>
          <span>{`Cl(${S.k},${S.d})`}</span>
          <span><span className="lx-k">{research ? 'pieces' : 'edges'}</span> {c.pieces}</span>
          <span><span className="lx-k">{research ? 'sources' : 'corners'}</span> {c.sources}</span>
          <span><span className="lx-k">triangles</span> {c.triangles}</span>
          <span><span className="lx-k">{research ? 'incidences' : 'moves'}</span> {c.incidences}</span>
        </p>
        <p data-step={`${step.from},${step.axis},${step.to},${step.op},${step.s}`}>
          {primes
            ? <span>{`${P} ${step.op === 'contract' ? '÷' : '×'} ${p} = ${T}`}</span>
            : research && how !== 'clifford'
              ? <span>e<sub>{axisName}</sub> e<sub>{nm(a)}</sub> = {step.s < 0 ? '−' : '+'}e<sub>{nm(step.to)}</sub></span>
              : research ? <span>{`${axisName} ${nm(a)} = ${step.s < 0 ? '−' : '+'}${nm(step.to)}`}</span>
                : <span>{`${nm(a)} → ${nm(step.to)}`}</span>}
          <span>{research ? `${step.op === 'contract' ? 'contraction' : 'wedge'} · ${word} ${axisName}` : `${word} ${axisName}`}</span>
          {into && <span data-into={into.id}>{research ? `→ ${into.name}` : `in ${eqWords(into.name)}`}</span>}
          <span><span className="lx-k">sign</span> {signTxt(step.s)}</span>
        </p>
      </div>
      <PhysicsNote ph={ph} m={a} level={level} base={nm} />
      <Controls label="simplex">
        <Chips label="n" items={SIMPLEX_NS} value={S.n} onPick={v => change({ ...st, n: v, mir: st.mir && v > 1 })} param="n" mono />
        <Chips label="axis" items={S.vertices.map(v => v.g)} value={b} onPick={v => setSt(s => ({ ...s, b: v }))} render={g => nm(1 << g)} param="b" mono />
        {S.n > 1 && <button type="button" className="fig-btn" data-param="mirror" aria-pressed={S.mirrored} onClick={() => change({ ...st, mir: !st.mir })}>{`mirror Cl(${S.d},${S.k})`}</button>}
      </Controls>
    </div>
  );
}
SimplexMaxwell.meta = { id: ID, lenses: ['simplex', 'cube', 'demicube', 'orthoplex', 'bits', 'primes'], learner: true };
/** the numbers and names the figure draws, for the frame's data download: the stored names of the vertices, edges and triangles, the equations of the picked edge */
SimplexMaxwell.data = (params = {}) => {
  const s = init(params), S = simplexMaxwell(s.n, s.mir), step = stepOf(S.eps, s.a, s.b < S.N ? s.b : S.N - 1), ph = physicsOf(S.k, S.d);
  const names = Object.fromEntries([...S.vertices.map(v => v.m), ...S.pieces.map(p => p.m), ...S.triangles.map(t => t.m)].map(m => [m, ph.nameOf(m)]));
  return { cell: [S.k, S.d], axes: S.axes, vertices: S.vertices, pieces: S.pieces, triangles: S.triangles, incidences: S.incidences, counts: S.counts, step, names,
    equations: ph.eqsOf(s.a).map(e => ({ id: e.id, name: e.name, eq: e.eq, term: e.term, sign: e.sign })) };
};
