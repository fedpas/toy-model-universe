// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/figures/explore/lens/motion.jsx — the motion on the demicube explorer (BUILD_CONTRACTS round 5, wave 2, owner P2b; D30): what the even element of the picked
// plane corner — the product R = a₂a₁ of the two mirrors the amount places — does to things, every image the sandwich R x R̃ through the kernel
// (engines/explore/lens.js motionBy, composeBy). Two panels beside the demicube:
//   the spacetime view of a boost: the plane (t, its space axis), the two mirrors, the dashed lines of speed 1, the clock at the origin with its first tick before and
//   after (the tick's new time printed), the rod of length 1 — its two world lines at rest and moved, and its length at the moment t = 2 —, the event E and where it
//   goes, with its path while the amount grows; of a turn: its plane, the two mirrors, the rod turned with its angle, the event and (n = 3) the square;
//   the space view at the moment t = 2 (n = 3, 4): the square or the cube at rest and moved, its sides printed; for a turn at n = 4, the cube turned.
// Play grows the amount from 0 to the chip in 24 steps (the drawing starts complete; under reduced motion Step jumps by a quarter); the button carries the param of the
// amount chips. The readout prints the move by the plane it acts in, v/c, φ, γ, θ, the event's new coordinates, the rod and the tick; with a second plane picked, the
// two moves composed (R_b R_a: its weights, its boost, the rotation left), captioned by the rows MIR-007 and MIR-008 (Statement: their own words and badges).
// At learner level the same drawing, and words built from the same numbers. No sentence here states a law; tests/explore/motion.test.mjs ties every number to the
// textbook matrices and formulas and to mirrors.json. Marks by shape and word: E a ring, its image a filled diamond; ticks dots; at rest dashed, moved solid.
import React, { useMemo } from 'react';
import { FigSvg, f2, r1, usePlayer, arrowHead } from '../../kit.jsx';
import { motionBy, composeBy, moveView, amountOf, MOMENT, SQUARE, CUBE, CUBE_EDGES } from '../../../../engines/explore/lens.js';
import Statement from '../../../components/Statement.jsx';
import { VW, VH } from './parts.jsx';

export const FRAMES = 24;
/** the rows that caption the motion and the composition (D30): A24, two mirrors make a boost (computation); A22, the demicube read as the moves of spacetime (reading) */
export const MOTION_ROWS = ['MIR-007', 'MIR-008'];
const BOX = { x0: 18, x1: 288, y0: 14, y1: 238 };
const rng = n => Array.from({ length: n }, (_, i) => i);
const deg = x => x * 180 / Math.PI;
const n6 = x => +(Math.abs(x) < 5e-13 ? 0 : x).toFixed(6);
const trim = s => (s.includes('.') ? s.replace(/0+$/, '').replace(/\.$/, '') : s);
/** an angle in degrees with at most d decimals, the minus sign typeset */
export const fdeg = (x, d = 2) => `${trim((Math.abs(x) < 0.5 * 10 ** -d ? 0 : x).toFixed(d)).replace('-', '−')}°`;

// ---------------------------------------------------------------- the frames: fixed per rung, kind and axis, holding every position the amounts reach
const RANGES = {
  boost: { u: [-1.0, 2.6], v: [-0.5, 2.5] },         // the space axis of the boost across, t up (the keys below the axis, on the right)
  turn: { u: [-1.0, 1.0], v: [-1.0, 1.0] },          // the plane of the turn
  space3: { u: [-0.8, 2.3], v: [-0.9, 0.9] },        // n = 3, a boost: its axis across, the other up
  space4: { u: [-0.9, 2.35], v: [-0.85, 0.85] },     // n = 4, a boost: its axis across, the second back, the third up
  turn4: { u: [-1.05, 1.05], v: [-1.0, 1.0] },       // n = 4, a turn: x across, y back, z up
};
function frameOf(R, box = BOX) {
  const W = box.x1 - box.x0, H = box.y1 - box.y0, du = R.u[1] - R.u[0], dv = R.v[1] - R.v[0], K = Math.min(W / du, H / dv);
  const ox = box.x0 + (W - du * K) / 2 - R.u[0] * K, oy = box.y0 + (H - dv * K) / 2 + R.v[1] * K;
  return { K, R, at: (u, v) => [ox + K * u, oy - K * v] };
}
/** the part of the line through P with direction d inside the rectangle of the range, shrunk by m (Liang–Barsky), or null */
function clipLine(P, d, R, m = 0.04) {
  let t0 = -1e9, t1 = 1e9;
  for (const [p, q] of [[-d[0], P[0] - R.u[0] - m], [d[0], R.u[1] - m - P[0]], [-d[1], P[1] - R.v[0] - m], [d[1], R.v[1] - m - P[1]]]) {
    if (Math.abs(p) < 1e-12) { if (q < 0) return null; continue; }
    const r = q / p; if (p < 0) t0 = Math.max(t0, r); else t1 = Math.min(t1, r);
  }
  return t0 < t1 ? [[P[0] + t0 * d[0], P[1] + t0 * d[1]], [P[0] + t1 * d[0], P[1] + t1 * d[1]]] : null;
}
const clampX = x => Math.min(BOX.x1 - 4, Math.max(BOX.x0 + 4, x)), clampY = y => Math.min(BOX.y1 + 10, Math.max(BOX.y0 + 8, y));

// ---------------------------------------------------------------- the scene: everything the panels draw and the readout prints, for one frame of the animation
/** the amount of a frame: the chip's amount at the last frame, a share of it before */
export const amountAt = (full, frame, total = FRAMES) => (frame >= total ? full : full * frame / total);
/**
 * motionScene(n, a, k, frame, b): the motion of chip k in the plane corner a at the frame (0 … 24; 24 is the chip), and, with a second plane corner b, the two moves
 * composed (each plane reads the chip as its own amount). → { n, a, k, frame, kind, mo (motionBy), co (composeBy or null), view (moveView of the chip: the events the
 * spacetime view draws moved and their paths), panels: [{ part, frame, ... coordinates }] }. Pure: the tests call it for every frame.
 */
export function motionScene(n, a, k, frame = FRAMES, b = null) {
  const view = moveView(n, a, k), nn = view.n, kind = view.kind, full = amountOf(kind, view.k), amt = amountAt(full, frame);
  const mo = motionBy(nn, a, amt), axes = mo.axisNames, [i, j] = mo.axes;
  const co = b === null || b === undefined ? null : composeBy(nn, a, b, amt, amountAt(amountOf(motionBy(nn, b, 0).kind, view.k), frame));
  const steps = Math.min(FRAMES, Math.max(0, Math.round(frame)));
  const panels = [kind === 'boost' ? boostPanel(mo, view, steps, axes, i, j) : turnPanel(mo, view, steps, axes, i, j)];
  if (nn === 3 && kind === 'boost') panels.push(space3Panel(mo, axes, j));
  if (nn === 4) panels.push(kind === 'boost' ? space4Panel(mo, axes, j) : turn4Panel(mo, axes));
  return { n: nn, a, k: view.k, frame: steps, kind, amount: amt, full, mo, co, view, panels };
}

/** the spacetime view of a boost in the plane (t, j): u = x_j across, v = t up */
function boostPanel(mo, view, steps, axes, i, j) {
  const F = frameOf(RANGES.boost), R = F.R, at = F.at, top = 2.45, u = mo.u, g = mo.gamma;
  const P = p => [p[j], p[0]];   // an event (t, x, …) in the plane of the move
  const line = (A, d) => { const c = clipLine(A, d, R); return c ? c.map(([x, y]) => at(x, y)) : null; };
  const worldOf = c => { const p0 = mo.act([0, ...c]), s0 = -p0[0] / u[0], s1 = (top - p0[0]) / u[0]; return [at(p0[j] + s0 * u[j], 0), at(p0[j] + s1 * u[j], top)]; };
  const moved = mo.rod.ends.map(worldOf);
  const meas = mo.rod.at.map(c => c[j - 1]);
  const ticks = [1, 2].map(tau => ({ tau, rest: at(0, tau) }));   // the clock at rest ticks at t = 1 and 2 (the scale of the time axis)
  const E = P(mo.event.at), E1 = P(mo.event.to), path = view.paths[0].slice(0, steps + 1).map(p => at(...P(p)));
  return {
    part: 'spacetime view', kind: 'boost', frame: F,
    axes: [{ from: at(R.u[0] + 0.05, 0), to: at(R.u[1] - 0.05, 0), name: axes[j] }, { from: at(0, R.v[0] + 0.05), to: at(0, R.v[1] - 0.05), name: 't' }],
    light: [[1, 1], [-1, 1]].map(d => line([0, 0], d)).filter(Boolean),
    mirrors: mo.mirrorLines.map(([dt, dj], w) => ({ w, seg: line([0, 0], [dj, dt]) })).filter(x => x.seg),
    legend: { from: at(1.42, -0.42), to: at(1.74, -0.42), text: at(1.8, -0.42) },
    mirrorKey: { solid: [at(1.42, -0.22), at(1.56, -0.22)], dashed: [at(1.6, -0.22), at(1.74, -0.22)], text: at(1.8, -0.22) },
    restRod: { worlds: [-0.5, 0.5].map(x => [at(x, 0), at(x, top)]), seg: [at(-0.5, 0), at(0.5, 0)], label: at(-0.6, 0) },
    movedRod: { worlds: moved, band: [moved[0][0], moved[0][1], moved[1][1], moved[1][0]] },
    measure: { seg: [at(meas[0], MOMENT), at(meas[1], MOMENT)], label: at(meas[1] + 0.07, MOMENT - 0.17), value: mo.rod.after, data: meas },
    clock: { world: [at(0, 0), at(top * u[j] / u[0], top)], ticks, tick: at(u[j], u[0]), time: g, dotted: [at(0, u[0]), at(u[j], u[0])], label: at(u[j] + 0.12, u[0] - 0.1) },
    event: { rest: at(...E), to: at(...E1), path, label: at(E1[0] + (E1[0] > 1.7 ? -0.12 : 0.1), E1[1] + 0.12), anchor: E1[0] > 1.7 ? 'end' : 'start' },
  };
}
/** the plane (i, j) of a turn: the rod, its angle, the event and, at n = 3, the square */
function turnPanel(mo, view, steps, axes, i, j) {
  const F = frameOf(RANGES.turn), R = F.R, at = F.at, P = p => [p[i], p[j]];
  const line = (A, d) => { const c = clipLine(A, d, R); return c ? c.map(([x, y]) => at(x, y)) : null; };
  const th = mo.angle, arc = rng(17).map(q => at(0.3 * Math.cos(th * q / 16), 0.3 * Math.sin(th * q / 16)));
  const ends = mo.rod.to.map(P), E = P(mo.event.at), E1 = P(mo.event.to), path = view.paths[0].slice(0, steps + 1).map(p => at(...P(p)));
  const sq = mo.n === 3 ? { rest: SQUARE.map(c => at(c[0], c[1])), to: SQUARE.map(c => { const p = mo.act([0, ...c]); return at(p[1], p[2]); }) } : null;
  return {
    part: 'plane of the turn', kind: 'turn', frame: F,
    axes: [{ from: at(R.u[0] + 0.05, 0), to: at(R.u[1] - 0.05, 0), name: axes[i] }, { from: at(0, R.v[0] + 0.05), to: at(0, R.v[1] - 0.05), name: axes[j] }],
    mirrors: mo.mirrorLines.map(([di, dj], w) => ({ w, seg: line([0, 0], [di, dj]) })).filter(x => x.seg),
    mirrorKey: { solid: [at(-0.95, -0.9), at(-0.82, -0.9)], dashed: [at(-0.78, -0.9), at(-0.65, -0.9)], text: at(-0.6, -0.9) },
    restRod: [at(-0.5, 0), at(0.5, 0)], rod: ends.map(p => at(...p)), arc, arcLabel: at(0.44 * Math.cos(th / 2), 0.44 * Math.sin(th / 2)), angle: th,
    event: { rest: at(...E), to: at(...E1), path, label: at(E1[0] + (E1[0] < 0 || E1[0] > 0.6 ? -0.1 : 0.1), E1[1] + (E1[1] > 0.55 ? -0.17 : 0.1)), anchor: E1[0] < 0 || E1[0] > 0.6 ? 'end' : 'start' }, square: sq,
  };
}
/** the space view of a boost at n = 3 at the moment t = 2: the square at rest and moved, its axis across, the other axis up */
function space3Panel(mo, axes, j) {
  const F = frameOf(RANGES.space3), at = F.at, sj = j - 1, sk = 1 - sj, P = c => at(c[sj], c[sk]);
  const rest = mo.squareBody.rest.map(P), now = mo.squareBody.at.map(P), side = mo.squareBody.sides[sj], cx = mo.squareBody.at.reduce((s, c) => s + c[sj], 0) / 4;
  return {
    part: 'space view at one moment', kind: 'space', frame: F,
    axes: [{ from: at(F.R.u[0] + 0.05, 0), to: at(F.R.u[1] - 0.05, 0), name: axes[j] }, { from: at(0, F.R.v[0] + 0.05), to: at(0, F.R.v[1] - 0.05), name: axes[sk + 1] }],
    rest, now, edges: [[0, 1], [1, 2], [2, 3], [3, 0]], sides: { rest: 1, now: side, at: [at(0, -0.72), at(cx, -0.72)] },
    arrow: mo.speed > 1e-9 ? [at(cx, 0.68), at(cx + 0.7 * mo.speed, 0.68)] : null, moment: at(F.R.u[0] + 0.05, F.R.v[1] - 0.12),
  };
}
/** the oblique drawing of a place (x, y, z): the axis `a` across, `b` back, `c` up */
const oblique = (at, a, b, c) => p => at(p[a] + 0.42 * p[b], p[c] + 0.3 * p[b]);
/** the space view of a boost at n = 4 at the moment t = 2: the cube at rest and moved, its axis across */
function space4Panel(mo, axes, j) {
  const F = frameOf(RANGES.space4), sj = j - 1, others = [0, 1, 2].filter(q => q !== sj), O = oblique(F.at, sj, others[0], others[1]);
  const cx = mo.cubeBody.at.reduce((s, c) => s + c[sj], 0) / 8;
  const ax = (q, to) => ({ from: O([0, 0, 0]), to: O([0, 1, 2].map(r => (r === q ? to : 0))), name: axes[q + 1] });
  return {
    part: 'space view at one moment', kind: 'space', frame: F,
    axes: [ax(sj, 2.25), ax(others[0], 0.82), ax(others[1], 0.78)],
    rest: mo.cubeBody.rest.map(O), now: mo.cubeBody.at.map(O), edges: CUBE_EDGES, sides: { rest: 1, now: mo.cubeBody.sides[sj], at: [O([0, -0.62, -0.62].map((x, r) => (r === sj ? 0 : x))), O([0, -0.62, -0.62].map((x, r) => (r === sj ? cx : x)))] },
    arrow: mo.speed > 1e-9 ? [O([0, 0.62, 0.62].map((x, r) => (r === sj ? cx : x))), O([0, 0.62, 0.62].map((x, r) => (r === sj ? cx + 0.5 * mo.speed : x)))] : null,
    moment: F.at(F.R.u[0] + 0.05, F.R.v[1] - 0.12),
  };
}
/** the cube turned (n = 4): x across, y back, z up */
function turn4Panel(mo, axes) {
  const F = frameOf(RANGES.turn4), O = oblique(F.at, 0, 1, 2);
  return {
    part: 'space view', kind: 'space', frame: F,
    axes: [0, 1, 2].map(q => ({ from: O([0, 0, 0]), to: O([0, 1, 2].map(r => (r === q ? 0.95 : 0))), name: axes[q + 1] })),
    rest: CUBE.map(O), now: CUBE.map(c => O(mo.act([0, ...c]).slice(1))), edges: CUBE_EDGES, sides: null, arrow: null, moment: null,
  };
}

// ---------------------------------------------------------------- the words of the learner level, built from the numbers (no claim of their own)
/** the speed in words: the fraction of the speed of the dashed lines (speed 1) */
export const speedWords = v => `speed ${f2(v)}`;
export function motionWords(scene) {
  const mo = scene.mo, ax = mo.axisNames;
  if (scene.kind === 'boost') {
    if (mo.speed < 1e-9) return `Not pushed: the rod keeps its length 1 and its clock ticks at 1.`;
    return `Pushed along ${ax[mo.axes[1]]} to ${speedWords(mo.speed)}: the rod is shorter, 1 becomes ${f2(mo.rod.after)}; its clock runs slower, one tick lasts ${f2(mo.tick.time)}.`;
  }
  return `Turned by ${fdeg(deg(mo.angle), 0)} in the ${ax[mo.axes[0]]}${ax[mo.axes[1]]} plane: the rod keeps its length ${f2(mo.rod.after)} and the event its time ${f2(mo.event.to[0])}.`;
}
export function eventWords(scene) {
  const mo = scene.mo, ax = mo.axisNames, to = mo.event.to;
  return `The event at time ${f2(mo.event.at[0])} goes to time ${f2(to[0])}, ${ax.slice(1).map((x, q) => `${x} ${f2(to[q + 1])}`).join(', ')}.`;
}
export function composeWords(scene) {
  const co = scene.co, ax = scene.mo.axisNames;
  if (!co) return '';
  const second = co.second, how = second.kind === 'boost' ? `pushed along ${ax[second.axes[1]]}` : `turned in the ${ax[second.axes[0]]}${ax[second.axes[1]]} plane`;
  const parts = [];
  if (co.speed > 1e-9) parts.push(`one push to ${speedWords(co.speed)}`);
  if (co.angle > 1e-9) parts.push(`a turn of ${fdeg(deg(co.angle), 1)}${co.planeName ? ` in the ${co.planeName} plane` : ''}`);
  return `Then ${how} as well; together: ${parts.length ? parts.join(' and ') : 'no move'}.`;
}

// ---------------------------------------------------------------- the panels
const L = (P, Q, cls, key, style, data) => <line key={key} x1={r1(P[0])} y1={r1(P[1])} x2={r1(Q[0])} y2={r1(Q[1])} className={cls} style={style} {...data} />;
const pts = Ps => Ps.map(([x, y]) => `${r1(x)},${r1(y)}`).join(' ');
const ACCENT = { stroke: 'var(--accent)', strokeWidth: 2.4, fill: 'none', strokeLinecap: 'round' };
const BAND = { fill: 'var(--accent)', fillOpacity: 0.12, stroke: 'none' };
const THICK = { strokeWidth: 3 };
const DOTTED = { stroke: 'var(--muted)', strokeWidth: 1, strokeDasharray: '1.5 2.5', fill: 'none' };
const txt = (P, s, cls = 'lx-s', anchor = 'start', key, data) => <text key={key} x={r1(clampX(P[0]))} y={r1(clampY(P[1]))} textAnchor={anchor} className={cls} {...data}>{s}</text>;
const diamond = (P, r = 5) => pts([[P[0], P[1] - r], [P[0] + r, P[1]], [P[0], P[1] + r], [P[0] - r, P[1]]]);
/** the data the tests read off an image event: its coordinates (data-at) and its time (data-time), in the order of moveView's events */
const evData = (p, q) => ({ 'data-at': p.map(n6).join(','), 'data-time': String(n6(p[0])), 'data-point': q });

/** the key of the two mirror lines: mirror 1 solid, mirror 2 dashed */
function MirrorKey({ k }) {
  return <g data-legend-mirrors="1,2">{L(k.solid[0], k.solid[1], 'lx-mirror')}{L(k.dashed[0], k.dashed[1], 'lx-mirror', 'd', { strokeDasharray: '6 3' })}{txt([k.text[0], k.text[1] + 3.5], 'mirrors 1, 2', 'lx-s lx-muted')}</g>;
}
function Axes({ axes }) {
  return axes.map((x, q) => <g key={'ax' + q}>{L(x.from, x.to, 'lx-axis')}{txt([x.to[0] + 4, x.to[1] - 3], x.name, 'lx-name lx-muted')}</g>);
}
function BoostView({ p, scene, research, row }) {
  const mo = scene.mo, images = scene.view.images;
  return (
    <div className="fig-panel" data-motion-panel="spacetime">
      <FigSvg id="lens-demicube-moves" row={row} part={p.part} viewBox={`0 0 ${VW} ${VH}`}>
        <Axes axes={p.axes} />
        {p.light.map((s, q) => L(s[0], s[1], 'lx-light', 'li' + q))}
        <g data-legend-speed="1">{L(p.legend.from, p.legend.to, 'lx-light')}{txt([p.legend.text[0], p.legend.text[1] + 3.5], 'speed 1', 'lx-s lx-muted')}</g>
        <MirrorKey k={p.mirrorKey} />
        {p.mirrors.map(({ w, seg }) => { const E = seg[0][1] < seg[1][1] ? seg[0] : seg[1]; return <g key={'m' + w} data-mirror={w + 1}>{L(seg[0], seg[1], 'lx-mirror', 'l', w ? { strokeDasharray: '6 3' } : undefined)}{txt([E[0] + (w ? 4 : -4), E[1] + 11], String(w + 1), 'lx-s lx-bold', w ? 'start' : 'end')}</g>; })}
        <polygon points={pts(p.movedRod.band)} style={BAND} />
        {p.restRod.worlds.map((s, q) => L(s[0], s[1], 'lx-body-before', 'rw' + q))}
        {L(p.restRod.seg[0], p.restRod.seg[1], 'lx-body-before', 'rs', THICK)}
        {txt([p.restRod.label[0], p.restRod.label[1] + 3.5], '1', 'lx-s lx-tag', 'end')}
        {p.movedRod.worlds.map((s, q) => L(s[0], s[1], 'lx-body', 'mw' + q))}
        <g data-measure={p.measure.data.map(n6).join(',')}>{L(p.measure.seg[0], p.measure.seg[1], 'lx-body', 'ms', { ...ACCENT, strokeWidth: 3.4 })}{txt(p.measure.label, f2(p.measure.value), 'lx-s lx-tag')}</g>
        {L(p.clock.world[0], p.clock.world[1], null, 'cw', ACCENT, { 'data-world': n6(mo.speed) })}
        {p.clock.ticks.map(t => <g key={'tr' + t.tau}>{L([t.rest[0] - 4, t.rest[1]], [t.rest[0] + 4, t.rest[1]], 'lx-edge')}{txt([t.rest[0] - 7, t.rest[1] + 3.5], String(t.tau), 'lx-s lx-muted', 'end')}</g>)}
        {L(p.clock.dotted[0], p.clock.dotted[1], null, 'cd', DOTTED)}
        {p.event.path.length > 1 && <polyline points={pts(p.event.path)} className="lx-path" style={{ strokeDasharray: '2 2' }} />}
        <circle cx={r1(p.event.rest[0])} cy={r1(p.event.rest[1])} r={4} className="lx-before" />
        <polygon points={diamond(p.event.to)} className="lx-after" {...evData(images[0], 0)} />
        {txt(p.event.label, 'event', 'lx-s lx-tag', p.event.anchor)}
        <circle cx={r1(p.clock.tick[0])} cy={r1(p.clock.tick[1])} r={4} className="lx-after" {...evData(images[1], 1)} />
        <g data-tick={n6(p.clock.time)}>{txt(p.clock.label, f2(p.clock.time), 'lx-s lx-tag')}</g>
      </FigSvg>
    </div>
  );
}
function TurnView({ p, scene, row }) {
  const images = scene.view.images;
  return (
    <div className="fig-panel" data-motion-panel="turn">
      <FigSvg id="lens-demicube-moves" row={row} part={p.part} viewBox={`0 0 ${VW} ${VH}`}>
        <Axes axes={p.axes} />
        {p.mirrors.map(({ w, seg }) => { const E = seg[0][1] < seg[1][1] ? seg[0] : seg[1]; return <g key={'m' + w} data-mirror={w + 1}>{L(seg[0], seg[1], 'lx-mirror', 'l', w ? { strokeDasharray: '6 3' } : undefined)}{txt([E[0] + (w ? 4 : -4), E[1] + 11], String(w + 1), 'lx-s lx-bold', w ? 'start' : 'end')}</g>; })}
        <MirrorKey k={p.mirrorKey} />
        {p.square && <polygon points={pts(p.square.rest)} className="lx-body-before" />}
        {p.square && <polygon points={pts(p.square.to)} style={BAND} />}
        {p.square && <polygon points={pts(p.square.to)} className="lx-body" />}
        {L(p.restRod[0], p.restRod[1], 'lx-body-before', 'rr', THICK)}
        {L(p.rod[0], p.rod[1], null, 'rt', { ...ACCENT, strokeWidth: 3.4 })}
        {p.angle > 1e-9 && <polyline points={pts(p.arc)} className="lx-path" />}
        {p.angle > 1e-9 && txt([p.arcLabel[0], p.arcLabel[1] + 3.5], fdeg(deg(p.angle), 0), 'lx-s lx-tag', 'middle')}
        {p.event.path.length > 1 && <polyline points={pts(p.event.path)} className="lx-path" style={{ strokeDasharray: '2 2' }} />}
        <circle cx={r1(p.event.rest[0])} cy={r1(p.event.rest[1])} r={4} className="lx-before" />
        <polygon points={diamond(p.event.to)} className="lx-after" {...evData(images[0], 0)} />
        {p.rod.map((P, q) => <circle key={'re' + q} cx={r1(P[0])} cy={r1(P[1])} r={3.4} className="lx-after" {...evData(images[q + 1], q + 1)} />)}
        {txt(p.event.label, 'event', 'lx-s lx-tag', p.event.anchor)}
      </FigSvg>
    </div>
  );
}
function SpaceView({ p, scene, research, row }) {
  const poly = (P, edges, cls, key, style) => <g key={key}>{edges.map(([x, y], q) => L(P[x], P[y], cls, q, style))}</g>;
  return (
    <div className="fig-panel" data-motion-panel="space">
      <FigSvg id="lens-demicube-moves" row={row} part={p.part} viewBox={`0 0 ${VW} ${VH}`}>
        <Axes axes={p.axes} />
        {p.edges.length === 4 && <polygon points={pts(p.now)} style={BAND} />}
        {poly(p.rest, p.edges, 'lx-body-before', 'rest')}
        {poly(p.now, p.edges, 'lx-body', 'now')}
        {p.arrow && <g data-velocity={n6(scene.mo.speed)}>{L(p.arrow[0], p.arrow[1], null, 'v', ACCENT)}<path d={arrowHead(p.arrow[0][0], p.arrow[0][1], p.arrow[1][0], p.arrow[1][1], 6)} style={{ fill: 'var(--accent)', stroke: 'none' }} /></g>}
        {p.sides && <g data-sides={`${p.sides.rest},${n6(p.sides.now)}`}>{txt(p.sides.at[0], '1', 'lx-s lx-tag', 'middle')}{txt(p.sides.at[1], f2(p.sides.now), 'lx-s lx-tag', 'middle')}</g>}
        {p.moment && txt(p.moment, research ? `t = ${MOMENT}` : `at time ${MOMENT}`, 'lx-s lx-muted')}
      </FigSvg>
    </div>
  );
}
/** the motion panels of a scene (after the demicube) */
export function motionPanels(scene, { research, row }) {
  return scene.panels.map((p, q) => (p.kind === 'boost' ? <BoostView key={'mp' + q} p={p} scene={scene} research={research} row={row} />
    : p.kind === 'turn' ? <TurnView key={'mp' + q} p={p} scene={scene} row={row} /> : <SpaceView key={'mp' + q} p={p} scene={scene} research={research} row={row} />));
}

// ---------------------------------------------------------------- the readout of the motion and of the composition, and the rows that caption them
const coords = p => `(${p.map(f2).join(', ')})`;
const sub = s => <sub>{s}</sub>;
/** the learner's sentences in the body font (the readout is set in the mono font of numbers) */
const WORDS = { fontFamily: 'var(--font-body)' };
const signed = (w, first) => (first ? (w < 0 ? '−' : '') : w < 0 ? ' − ' : ' + ') + f2(Math.abs(w));
/**
 * The lines of the readout after the plane's line: the even element (research: R = a₂a₁ with its weights, R R̃, the sandwich; learner: the weights), the amounts
 * (v/c, φ, γ or θ; learner: the speed or the angle), the event's new coordinates, the rod and the tick (learner: the same numbers in words), and, with a second plane,
 * the composition R_b R_a: its weights on the corners, its boost and the rotation left. ew(m) prints a label as an e-word (or the label the lens asks for).
 */
export function MotionReadout({ scene, research, nm, ew }) {
  const mo = scene.mo, co = scene.co, boost = scene.kind === 'boost', w = mo.weights;
  const weights = `${n6(w.one)},${n6(w.plane)}`;
  return (
    <>
      {research
        ? <p data-weights={weights} data-rotor={mo.R.map(([m, c]) => `${m}:${n6(c)}`).join(',')}>
            <span className="lx-k">R = a{sub('2')}a{sub('1')}</span><span>{signed(w.one, true)}{signed(w.plane, false)} {ew(mo.m)}</span>
            <span><span className="lx-k">R R̃</span> {f2(mo.norm)}</span><span className="lx-k">x ↦ R x R̃</span>
          </p>
        : <p data-weights={weights}><span className="lx-k">weights</span><span>{`${f2(w.one)} on 1`}</span><span>{`${f2(w.plane)} on ${nm(mo.m)}`}</span></p>}
      <p data-motion={`${mo.name}|${n6(mo.speed)}|${n6(mo.rapidity)}|${n6(mo.gamma)}|${n6(deg(mo.angle))}`}>
        {boost && (research
          ? <><span><span className="lx-k">v/c</span> {f2(mo.speed)}</span><span><span className="lx-k">φ</span> {f2(mo.rapidity)}</span><span><span className="lx-k">γ</span> {f2(mo.gamma)}</span></>
          : <span><span className="lx-k">speed</span> {f2(mo.speed)}</span>)}
        {!boost && <span><span className="lx-k">{research ? 'θ' : 'angle'}</span> {fdeg(deg(mo.angle), 0)}</span>}
      </p>
      {research ? (
        <>
          <p data-event={`${mo.event.at.map(n6).join(',')};${mo.event.to.map(n6).join(',')}`}>
            <span className="lx-k">{`event (${mo.axisNames.join(', ')})`}</span><span>{coords(mo.event.at)}</span><span>→</span><span>{coords(mo.event.to)}</span>
          </p>
          <p data-rod={`${n6(mo.rod.before)},${n6(mo.rod.after)}`} data-tick={n6(mo.tick.time)}>
            <span className="lx-k">{boost ? `rod at t = ${MOMENT}` : 'rod'}</span><span>{`1 → ${f2(mo.rod.after)}`}</span>
            <span className="lx-k">tick</span><span>1 → t′ {f2(mo.tick.time)}</span>
            {mo.squareBody && <><span className="lx-k">{boost ? `square at t = ${MOMENT}` : 'square'}</span><span>{mo.squareBody.sides.map(f2).join(' × ')}</span></>}
            {mo.cubeBody && <><span className="lx-k">{boost ? `cube at t = ${MOMENT}` : 'cube'}</span><span>{mo.cubeBody.sides.map(f2).join(' × ')}</span></>}
          </p>
        </>
      ) : (
        <>
          <p data-words="motion" style={WORDS}>{motionWords(scene)}</p>
          <p data-words="event" style={WORDS}>{eventWords(scene)}</p>
        </>
      )}
      {co && (research ? (
        <p data-compose={`${co.b}|${co.R.map(([m, c]) => `${m}:${n6(c)}`).join(',')}|${n6(co.speed)}|${n6(co.gamma)}|${n6(deg(co.angle))}|${co.planeName || ''}|${co.signedAngle === null ? '' : n6(deg(co.signedAngle))}`}>
          <span className="lx-k">then {ew(co.b)}: R{sub('b')}R{sub('a')}</span>
          <span>{co.R.filter(([, c]) => Math.abs(c) > 5e-13).map(([m, c], q) => <React.Fragment key={m}>{signed(c, q === 0)}{m ? <> {ew(m)}</> : ''}</React.Fragment>)}</span>
          {co.speed > 1e-9 && <span><span className="lx-k">boost v/c</span> {f2(co.speed)}{co.direction ? ` along (${co.direction.map(f2).join(', ')})` : ''}</span>}
          <span><span className="lx-k">rotation left</span> {fdeg(deg(co.signedAngle === null ? co.angle : co.signedAngle))}{co.planeName ? ` in ${co.planeName}` : ''}</span>
        </p>
      ) : <p data-words="compose" data-compose={`${co.b}|${n6(co.speed)}|${n6(deg(co.angle))}`} style={WORDS}>{composeWords(scene)}</p>)}
    </>
  );
}
/** the rows MIR-007 and MIR-008, each in its own words with its own badge (Statement); nothing when the texts are not loaded */
export function MotionRows() {
  return <div className="lx-rows" data-motion-rows={MOTION_ROWS.join(',')}>{MOTION_ROWS.map(id => <Statement key={id} id={id} variant="compact" evidence={false} />)}</div>;
}

// ---------------------------------------------------------------- Play: the amount grows from 0 to the chip
/** the player of the motion: 24 frames, paused until Play, started complete; it starts again when the plane, the chip or the second plane changes */
export function useMotionPlayer(resetKey) { return usePlayer(FRAMES, { ms: 70, stops: [6, 12, 18, 24], resetKey }); }
/** the Play button: an animation control (data-play) of the amount chips (data-param="amount"); Step under reduced motion. The icon is drawn, never an emoji. */
export function MotionPlay({ player }) {
  const { playing, reduced, play, step } = player;
  const icon = playing
    ? <svg className="fig-icon" viewBox="0 0 12 12" aria-hidden="true"><rect x="2" y="2" width="3" height="8" /><rect x="7" y="2" width="3" height="8" /></svg>
    : <svg className="fig-icon" viewBox="0 0 12 12" aria-hidden="true"><path d="M3 2 L10 6 L3 10 Z" /></svg>;
  if (reduced) return <button type="button" className="fig-btn" data-play="step" data-param="amount" onClick={step}>{icon}<span>Step</span></button>;
  return <button type="button" className="fig-btn" data-play="play" data-param="amount" aria-pressed={playing} onClick={play}>{icon}<span>{playing ? 'Pause' : 'Play'}</span></button>;
}
/** the scene of the current frame, memoised */
export function useMotionScene(n, a, k, frame, b) { return useMemo(() => motionScene(n, a, k, frame, b), [n, a, k, frame, b]); }
