// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PageTop.jsx — the top of every page that has a hero (docs/round7/PLAN.md R7-4, interfaces 36–37: the classes .top .top-lead .top-hero
// .top-try .top-notes .top-note, then TwoWays): the intro's lead (and its learner paragraphs and folded details) → the hero figure, wide when its seed
// says so (a leaf of the map anchored at the page top: pages.json `top`), with its controls and the captions that read it → the try line (an
// instruction, the page's connective "top-notes") → the three notes, numbered 1 to 3 (the rows of the reserved section top-notes: the learner text at
// learner level, its short register when the row has one, the research text otherwise) → the two ways (the hero row by mode) → at learner level the
// hero's "How do we know?" line → the drawer of the top's rows. Every sentence is a text record of its row; the words of this file are labels.
// The section carries id="sec-top", so a link with at=top (the door's cards) lands on it; the hero figure's box keeps id="hero".
import { useSettings } from '../app/content.js';
import { howWeKnow } from '../app/queries.js';
import { TOP_WORDS } from '../app/vocab.js';
import Statement from './Statement.jsx';
import FigureFrame from './FigureFrame.jsx';
import { Caption } from './Lead.jsx';
import TwoWays from './TwoWays.jsx';
import { registerOf } from './LeafNotes.jsx';
import '../styles/top.css';

export default function PageTop({ model, lead = null, aside = null, rowIds = [], children = null }) {
  const s = useSettings();
  const top = model && model.top;
  if (!top) return null;
  const learner = s.level === 'learner';
  const heroId = top.hero.row;
  const figId = aside ? null : top.hero.figure;
  const wide = !aside && top.hero.wide;
  const captions = !aside && figId && model.hero ? model.hero.captions || [] : [];
  const how = learner && heroId && model.hero ? howWeKnow(heroId) : null;
  const notes = top.notes || [];
  return (
    <section className={`top${top.fromMap ? ' top--leaf' : ''}`} id="sec-top" data-top={top.leaf || undefined} aria-labelledby="page-title">
      {lead ? <div className="top-lead">{lead}</div> : null}
      {aside || figId ? (
        <div className={`top-hero${wide ? ' top-hero--wide' : ''}`} id="hero" data-size={wide ? 'wide' : undefined} data-figure={figId || undefined}>
          {aside || <FigureFrame id={figId} />}
          {captions.length ? <div className="hero__caps top-hero__caps" data-captions={figId}>{captions.map(id => <Caption key={id} id={id} />)}</div> : null}
        </div>
      ) : null}
      {top.tryLine ? (
        <p className="top-try" data-connective="try">
          <span className="top-try__label">{TOP_WORDS.try}</span>
          <span className="top-try__text">{top.tryLine}</span>
        </p>
      ) : null}
      {notes.length ? (
        <ol className="top-notes" aria-label={TOP_WORDS.notes}>
          {notes.map((id, i) => (
            <li className="top-note" key={id} data-note={i + 1} data-row={id}>
              <Statement id={id} register={registerOf(id, s)} />
            </li>
          ))}
        </ol>
      ) : null}
      <TwoWays top={top} register={model.hero ? model.hero.register : 'full'} rowIds={rowIds} />
      {how ? <p className="hero__how top-how" data-connective="how-we-know" data-row={heroId}>{how}</p> : null}
      {children}
    </section>
  );
}
