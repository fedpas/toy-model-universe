// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/TwoWays.jsx — the two ways of a page top (docs/round7/PLAN.md R7-3, R7-4, interfaces 36–37): the hero row said the physicist's way and the
// mathematician's way, side by side at every level — its text records with mode phys and mode math at this level (the page model's top.ways), each in
// a panel `.top-way` (`.top-way-phys`, `.top-way-math`) under its eyebrow ("The physicist's way", "The mathematician's way · geometry"). When the row has
// one text for both modes the two sides are one record and the panel is drawn once (`.top-ways--one`, no eyebrow). The mathematician's panel (or the
// one panel) carries the chip that reads the page in its way in (`.top-way-lens`: the leaf's lens, else the first branch lens with readings on the
// page; at research level only, LeafLensChip).
// Every word of a panel is the row's text record: in the current mode a Statement (a tally row a TallyLine, as the hero draws it); in the other
// mode the same frame with that mode's record, marked data-mode so tests/coverage.test.mjs reads it as that record.
import { useContext } from 'react';
import { useSettings, useTable, statusOf } from '../app/content.js';
import { lensesByKey } from '../app/store.js';
import { lensCounts } from '../app/queries.js';
import { TOP_WORDS, WAY_IN } from '../app/vocab.js';
import { PageContext } from './PageContext.js';
import Statement from './Statement.jsx';
import RichText from './RichText.jsx';
import Badge from './Badge.jsx';
import LeafLensChip from './LeafLensChip.jsx';
import { Chevron } from './Icons.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';

const BRANCHES = ['geo', 'alg', 'top', 'cat', 'comb'];

/** the hero row in a mode other than the page's: its record's words, its badge and its "›", as Statement draws a statement */
function OtherMode({ id, record, register }) {
  const s = useSettings();
  const ctx = useContext(PageContext);
  const st = statusOf(id);
  const canOpen = ctx.openEvidence && ctx.hasDrawer(id);
  return (
    <div className="statement statement--hero statement--way" data-row={id} data-register={register} data-mode={record.mode}>
      <p className="statement__text"><RichText text={record.body} level={s.level} terms={ctx.gloss ? ctx.gloss.get(id) : null} uid={`way-${record.mode}-${id}`} /></p>
      <div className="statement__meta">
        {st ? <Badge status={st.status} badge={st.badge} level={s.level} /> : null}
        {canOpen ? <button type="button" className="statement__ev" aria-label={`Evidence and more for this statement (${id})`} title="Evidence and more" onClick={() => ctx.openEvidence(id)}><Chevron /></button> : null}
      </div>
    </div>
  );
}

/** the words of one way: the current mode's record through Statement (or TallyLine), another mode's through OtherMode */
function WayText({ id, record, register, current }) {
  if (!record) return null;
  if (current) return isTallyRow(id) && register === 'full' ? <TallyLine id={id} variant="hero" /> : <Statement id={id} register={register} variant="hero" />;
  return <OtherMode id={id} record={record} register={register} />;
}

/** the lens of the mathematician's way: the leaf's, else the first branch lens with a reading or a text on the page (research level) */
function useWayLens(lens, rowIds) {
  const s = useSettings();
  const [readings] = useTable(s.level === 'learner' || lens ? 'version' : 'lens_readings');
  if (lens || s.level === 'learner') return lens || null;
  if (!readings) return null;
  const counts = lensCounts(rowIds || [], s.level);
  return BRANCHES.find(k => lensesByKey()?.has(k) && (counts.get(k) || 0) > 0) || null;
}

export default function TwoWays({ top, register, rowIds }) {
  const s = useSettings();
  const lens = useWayLens(top && top.ways ? top.ways.lens : null, rowIds);
  if (!top || !top.hero || !top.hero.row || !top.ways || (!top.ways.phys && !top.ways.math)) return null;
  const id = top.hero.row, { phys, math, one } = top.ways;
  const chip = lens ? <div className="top-way-lens"><LeafLensChip lens={lens} rowIds={rowIds} /></div> : null;
  if (one) {
    return (
      <div className="top-ways top-ways--one" data-row={id}>
        <section className="top-way" data-mode="both" aria-label={`${TOP_WORDS.phys}, ${TOP_WORDS.math.charAt(0).toLowerCase()}${TOP_WORDS.math.slice(1)}`}>
          <WayText id={id} record={phys} register={register} current />
          {chip}
        </section>
      </div>
    );
  }
  const way = WAY_IN[lens] || null;
  // the panel whose record is the current mode's is drawn by Statement; the other one by OtherMode (the two records differ, so exactly one is current)
  const cur = s.mode === 'math' ? math : phys;
  return (
    <div className="top-ways" data-row={id}>
      {phys ? (
        <section className="top-way top-way-phys" data-mode="phys" aria-labelledby={`way-phys-${id}`}>
          <p className="top-way__eyebrow" id={`way-phys-${id}`}>{TOP_WORDS.phys}</p>
          <WayText id={id} record={phys} register={register} current={phys === cur} />
        </section>
      ) : null}
      {math ? (
        <section className="top-way top-way-math" data-mode="math" aria-labelledby={`way-math-${id}`}>
          <p className="top-way__eyebrow" id={`way-math-${id}`}>{way ? `${TOP_WORDS.math} · ${way}` : TOP_WORDS.math}</p>
          <WayText id={id} record={math} register={register} current={math === cur} />
          {chip}
        </section>
      ) : null}
    </div>
  );
}
