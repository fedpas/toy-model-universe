// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Part.jsx — a part of a chapter page (docs/STORY_PLAN.md §2.1 item 5, §2.4): an h2 heading (a name, a connective) over the sections
// it groups, whose titles are h3. The heading joins the page's outline ("On this page").
export default function Part({ id, title, children }) {
  return (
    <div className="part" id={`part-${id}`} role="group" aria-labelledby={title ? `hp-${id}` : undefined} data-part={id}>
      {title ? <h2 className="part__title" id={`hp-${id}`} data-outline={title}>{title}</h2> : null}
      {children}
    </div>
  );
}
