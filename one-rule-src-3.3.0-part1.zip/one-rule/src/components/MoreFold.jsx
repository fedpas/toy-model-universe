// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/MoreFold.jsx — "More statements (n)" (docs/STORY_PLAN.md §2.2; D40: `detail` outside the Logbook means "More statements"): a closed
// <details> under a section's key results that holds the other results, then its detail rows, each a Statement (a tally row a TallyLine). The summary
// is a connective (a label and a count, no row's words). The same fold, with the section's name as its label, holds a section kept out of the
// reading (the reserved part "drawer") and the second paragraphs of a page's intro. `children` follow the rows (a drawer).
import Statement from './Statement.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';
import { ChevronDown } from './Icons.jsx';
import { STORY_WORDS } from '../app/vocab.js';

export default function MoreFold({ rows, id, label = STORY_WORDS.more, open = false, onToggle, kind = 'more', children = null }) {
  if (!rows || !rows.length) return null;
  return (
    <details className={`more more--${kind}`} id={id} data-fold={kind} open={!!open} onToggle={e => onToggle && onToggle(e.currentTarget.open)}>
      <summary className="more__summary">
        <span className="more__caret" aria-hidden="true"><ChevronDown /></span>
        <span className="more__label">{`${label} (${rows.length})`}</span>
      </summary>
      <div className="more__body">
        {rows.map(r => (isTallyRow(r) ? <TallyLine key={r} id={r} /> : <Statement key={r} id={r} />))}
        {children}
      </div>
    </details>
  );
}
