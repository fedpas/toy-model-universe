// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafLensChip.jsx — "Read it in <lens>" (EXPLORE_PLAN §2.2): at research level one chip sets the page lens to the leaf's
// way in for the mathematician (explore.lens: geo | alg | top | cat | comb), so that the lens readings show under the statements; pressed
// again, it clears the lens. Greyed with "no readings yet" when no row of the page has a reading or a text in that lens at this level,
// counted as the lens picker counts them. Nothing at learner level.
import { useSettings, useTable } from '../app/content.js';
import { lensesByKey } from '../app/store.js';
import { lensCounts } from '../app/queries.js';

function Chip({ lens, rowIds }) {
  const s = useSettings();
  useTable('lens_readings'); // the readings are counted once their table is loaded (it is not a core table)
  const n = lensCounts(rowIds || [], s.level).get(lens.key) || 0;
  const on = s.lens === lens.key;
  return (
    <p className="leaf-lens">
      <button type="button" className={`chip chip--lens leaf-lens__chip${n ? '' : ' is-empty'}`} aria-pressed={on} disabled={!n && !on}
        onClick={() => s.set({ lens: on ? null : lens.key })}>
        <span>Read it in {lens.name.toLowerCase()}</span>
        <span className="chip__n">{n ? `${n} on this page` : 'no readings yet'}</span>
      </button>
    </p>
  );
}

export default function LeafLensChip({ lens: key, rowIds }) {
  const s = useSettings();
  const lens = key ? lensesByKey()?.get(key) : null;
  if (!lens || s.level === 'learner') return null;
  return <Chip lens={lens} rowIds={rowIds} />;
}
