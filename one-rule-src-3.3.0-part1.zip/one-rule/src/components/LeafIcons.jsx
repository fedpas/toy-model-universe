// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafIcons.jsx — the small pictures of the leaves on the door's cards (round 7, docs/round7/PLAN.md §4 ARCH, ported from Octavo's
// icons.jsx): line drawings in the ink of the page (currentColor); the three moves keep their three colours through the tokens --turn, --slide and
// --boost (each falls back to the ink where a theme does not define it). Decorative: the card names the leaf (aria-hidden). LeafIcon picks the picture
// of a slug and draws nothing for a slug it does not know.

const base = { viewBox: '0 0 64 64', fill: 'none', stroke: 'currentColor', strokeLinecap: 'round', 'aria-hidden': true, focusable: 'false', className: 'leaf-icon' };
const DOT8 = [[56, 32], [49, 15], [32, 8], [15, 15], [8, 32], [15, 49], [32, 56], [49, 49]];
const MOVE = { turn: { stroke: 'var(--turn, currentColor)' }, slide: { stroke: 'var(--slide, currentColor)' }, boost: { stroke: 'var(--boost, currentColor)' } };

export const IconClock = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5"><circle cx="32" cy="32" r="24" /><g fill="currentColor" stroke="none">{DOT8.map(([x, y]) => <circle key={`${x}-${y}`} cx={x} cy={y} r="3.4" />)}</g><path d="M32 32 V15" /></svg>
);
export const IconMoves = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3"><circle cx="22" cy="22" r="12" style={MOVE.turn} /><path d="M6 38 H58" style={MOVE.slide} /><path d="M30 60 C 38 46, 48 38, 60 34" style={MOVE.boost} /></svg>
);
export const IconMirrors = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5"><path d="M10 56 L50 10" /><path d="M10 56 L60 42" /><path d="M38.9 47.9 A 30 30 0 0 0 29.7 33.4" /><path d="M29.7 33.4 l2.6 7.6 M29.7 33.4 l7.8 1.5" /></svg>
);
export const IconHalfTurns = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5" strokeLinejoin="round"><path d="M32 8 A 24 24 0 1 1 11 44" /><path d="M10 34 L11 45 L21 42" /><text x="32" y="39" textAnchor="middle" fontSize="18" fill="currentColor" stroke="none" className="leaf-icon__math">−1</text></svg>
);
export const IconZero = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5"><rect x="6" y="22" width="52" height="20" rx="10" /><circle cx="32" cy="32" r="7" fill="currentColor" /><path d="M12 32 H20 M44 32 H52" strokeDasharray="1 5" /></svg>
);
export const IconLight = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5"><path d="M32 54 L8 12 M32 54 L56 12" /><path d="M20 34 H44" strokeDasharray="3 4" /><circle cx="32" cy="54" r="3.4" fill="currentColor" stroke="none" /></svg>
);
export const IconFall = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5" strokeLinejoin="round"><circle cx="32" cy="32" r="8" fill="currentColor" /><circle cx="32" cy="32" r="19" strokeDasharray="3 5" /><path d="M32 3 V14 M29 10 L32 14 L35 10" /><path d="M3 32 H14 M10 29 L14 32 L10 35" /><path d="M61 32 H50 M54 29 L50 32 L54 35" /></svg>
);
export const IconRoots = ({ size = 64 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2" strokeLinejoin="round"><polygon points="56,32 49,15 32,8 15,15 8,32 15,49 32,56 49,49" /><path d="M32 32 L56 32 M32 32 L49 15 M32 32 L32 8 M32 32 L15 15 M32 32 L8 32 M32 32 L15 49 M32 32 L32 56 M32 32 L49 49" /><circle cx="32" cy="32" r="3" fill="currentColor" /></svg>
);
export const IconSeats = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinecap="butt"><rect x="4" y="24" width="14" height="16" rx="2" /><rect x="25" y="24" width="14" height="16" rx="2" fill="currentColor" /><rect x="46" y="24" width="14" height="16" rx="2" /></svg>
);
export const IconMagnets = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3"><path d="M4 32 H60" /><path d="M18 14 V50 M32 14 V50 M46 14 V50" strokeWidth="5" /></svg>
);
export const IconCharge = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3"><circle cx="20" cy="34" r="8" /><path d="M20 30 V38 M16 34 H24" strokeWidth="2.5" /><path d="M30 34 C 38 10, 58 14, 56 34 C 54 52, 38 54, 36 40" /></svg>
);
export const IconElectron = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3"><path d="M4 32 C 12 8, 20 8, 28 32 S 44 56, 52 32 S 58 20, 60 24" /></svg>
);
export const IconSprings = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5" strokeLinejoin="round"><rect x="30" y="8" width="26" height="26" rx="2" /><path d="M30 8 L38 2 L64 2 M56 8 L62 2 M56 34 L62 28 L62 2" strokeWidth="2" /><path d="M4 50 H12 L16 42 L22 58 L28 42 L34 58 L40 46 H46" /></svg>
);
export const IconBands = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><path d="M4 46 H14 V26 H26 V46 H38 V26 H50 V46 H60" /></svg>
);
export const IconTumbling = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><rect x="14" y="22" width="36" height="22" rx="3" transform="rotate(-18 32 33)" /><path d="M6 54 C 20 62, 44 62, 58 52 M52 56 L58 52 L56 46" strokeWidth="2.5" /></svg>
);
export const IconHung = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><path d="M8 6 H56" /><path d="M32 6 V12 L24 16 L40 22 L24 28 L40 34 L32 38 V42" /><rect x="22" y="42" width="20" height="16" rx="2" fill="currentColor" /></svg>
);
export const IconField = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><path d="M32 8 L8 50 H56 Z" /><path d="M32 36 L32 8 M32 36 L8 50 M32 36 L56 50" /><g fill="currentColor" stroke="none"><circle cx="32" cy="8" r="3.4" /><circle cx="8" cy="50" r="3.4" /><circle cx="56" cy="50" r="3.4" /><circle cx="32" cy="36" r="3.4" /></g></svg>
);
export const IconSteps = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><path d="M6 52 H20 V40 H34 V28 H48 V16 H58" /><circle cx="27" cy="33" r="3.6" fill="currentColor" stroke="none" /></svg>
);
export const IconCube = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><rect x="8" y="26" width="30" height="30" rx="1.5" /><path d="M8 26 L24 10 H54 L38 26 M54 10 V40 L38 56" /><path d="M24 10 V40 H54 M24 40 L8 56" strokeWidth="2" strokeDasharray="3 4" /></svg>
);
/** the three lens explorers (not in Octavo's set): the simplex (a triangle with its vertices), the demicube (a tetrahedron in a cube), the cube's layers */
export const IconSimplex = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3" strokeLinejoin="round"><path d="M32 8 L8 54 H56 Z" /><g fill="currentColor" stroke="none"><circle cx="32" cy="8" r="3.6" /><circle cx="8" cy="54" r="3.6" /><circle cx="56" cy="54" r="3.6" /></g></svg>
);
export const IconDemicube = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="2.5" strokeLinejoin="round"><rect x="8" y="14" width="40" height="40" rx="1.5" strokeDasharray="3 4" strokeWidth="2" /><path d="M8 54 L48 54 L28 14 Z M8 54 L56 6 M48 54 L56 6 M28 14 L56 6" /></svg>
);
export const IconCubeLayers = ({ size = 48 }) => (
  <svg {...base} width={size} height={size} strokeWidth="3"><g fill="currentColor" stroke="none"><circle cx="10" cy="32" r="3.6" /><circle cx="32" cy="12" r="3.6" /><circle cx="32" cy="32" r="3.6" /><circle cx="32" cy="52" r="3.6" /><circle cx="54" cy="32" r="3.6" /></g><path d="M10 32 L32 12 M10 32 L32 32 M10 32 L32 52 M32 12 L54 32 M32 32 L54 32 M32 52 L54 32" strokeWidth="2" /></svg>
);

/** the door's mark: a ring of eight dots with a hand (Octavo's mark: the clock that counts the leaves) */
export const DoorMark = ({ size = 30 }) => (
  <svg width={size} height={size} viewBox="0 0 30 30" aria-hidden="true" focusable="false" className="door-mark"><circle cx="15" cy="15" r="11" fill="none" stroke="currentColor" strokeWidth="1.5" /><g fill="currentColor"><circle cx="26" cy="15" r="1.9" /><circle cx="22.8" cy="7.2" r="1.9" /><circle cx="15" cy="4" r="1.9" /><circle cx="7.2" cy="7.2" r="1.9" /><circle cx="4" cy="15" r="1.9" /><circle cx="7.2" cy="22.8" r="1.9" /><circle cx="15" cy="26" r="1.9" /><circle cx="22.8" cy="22.8" r="1.9" /></g><path d="M15 15 L22.8 7.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>
);
/** the lock of the door to the full Atlas */
export const IconLock = ({ size = 30 }) => (
  <svg width={size} height={size} viewBox="0 0 30 30" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden="true" focusable="false" className="leaf-icon"><rect x="5" y="13" width="20" height="13" rx="3" /><path d="M9 13 L9 9 A6 6 0 0 1 21 9 L21 13" /></svg>
);

/** the picture of each leaf, by its slug (content/explore/registry.json) */
export const ICONS = {
  clock: IconClock, moves: IconMoves, mirrors: IconMirrors, 'half-turns': IconHalfTurns, zero: IconZero, light: IconLight, fall: IconFall, roots: IconRoots,
  seats: IconSeats, magnets: IconMagnets, charge: IconCharge, electron: IconElectron, springs: IconSprings, bands: IconBands, tumbling: IconTumbling, hung: IconHung,
  field: IconField, steps: IconSteps, cube: IconCube, 'simplex-maxwell': IconSimplex, 'demicube-moves': IconDemicube, 'cube-maxwell': IconCubeLayers,
};

export default function LeafIcon({ slug, size }) {
  const I = ICONS[slug];
  return I ? <I size={size} /> : null;
}
