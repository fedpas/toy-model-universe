// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/Chain.jsx — one chain of a section (docs/round14/STORY_ROUND.md §4.6; D52–D57): a story of the rows of the section, in chain order,
// never sorted by mode or lens.
//   title line  the chain's title (h3, or h4 inside a part; data-chain), then a line of labels: at research level its shape (line, fork, cycle, ladder)
//               and its weakest link as a status word (data-connective="chain-status": "Weakest link: our reading"; nothing when every link is
//               proved, D56: a word, not a badge); at both levels "Continues from <chain>" when it has joins, a link to each chain it continues
//   research    the lead (Lead, variant chain), then ol.chain__list: each position after the first preceded by the connective word of its link
//               (span.chain__rel[data-connective="chain"], src/app/vocab.js chainWord), a told position a statement of the body variant (its anchor
//               row-<id>, its "›" opening the section's drawer), a mention the compact statement "Told in <section>"
//   learner     a storied chain as one paragraph (ChainStory); an unstoried one as the same list without connective words, each row in its own learner
//               text (D54's fallback), its lead first
// An open position stays in place with its badge (D57). A tally row (EQN-006 … EQN-020) is drawn by TallyLine in a list, as among the key results.
// The figures, the key results and the folds of the section are not the chain's (Section.jsx).
// Props: chain (src/app/queries.js chainModel), h (3 or 4: the level of the title), sid (the section's id: its drawer lists the told positions).
import { useSettings } from '../app/content.js';
import { useRoute } from '../app/router.js';
import { CHAIN_LABELS, chainWord } from '../app/vocab.js';
import Statement from './Statement.jsx';
import Lead from './Lead.jsx';
import Link from './Link.jsx';
import ChainStory from './ChainStory.jsx';
import TallyLine, { isTallyRow } from '../figures/physics/TallyLine.jsx';
import '../styles/chains.css';

/** the labels under a chain's title: its shape and weakest link (research level), the chains it continues from (both levels) */
function ChainLine({ chain, research, path }) {
  const shape = research ? CHAIN_LABELS.shape[chain.shape] : null;
  const weak = research && chain.word ? `${CHAIN_LABELS.weakest} ${chain.word}` : null;
  const joins = chain.joins || [];
  if (!shape && !weak && !joins.length) return null;
  return (
    <p className="chain__line">
      {shape ? <span className="chain__shape" data-connective="chain-shape">{shape}</span> : null}
      {weak ? <span className="chain__status" data-connective="chain-status">{weak}</span> : null}
      {joins.length ? (
        <span className="chain__joins">
          <span data-connective="chain-joins">{CHAIN_LABELS.continues}</span>
          {joins.map(j => <span className="chain__join" key={j.id}><Link to={path} at={j.id} data-connective="chain-join">{j.title}</Link></span>)}
        </span>
      ) : null}
    </p>
  );
}

export default function Chain({ chain, h = 3, sid = null }) {
  const s = useSettings();
  const route = useRoute();
  const research = s.level !== 'learner';
  const H = h >= 4 ? 'h4' : 'h3';
  const story = !research && chain.storied;
  return (
    <div
      className="chain" id={`chain-${chain.id}`} data-chain={chain.id} data-shape={chain.shape} data-status={chain.status || undefined}
      data-storied={chain.storied ? 'true' : 'false'} role="group" aria-labelledby={`hc-${chain.id}`}
    >
      <div className="chain__head">
        <H className="chain__title" id={`hc-${chain.id}`} data-chain={chain.id}>{chain.title}</H>
        <ChainLine chain={chain} research={research} path={route.path} />
      </div>
      {story ? <ChainStory chain={chain} sid={sid} /> : (
        <>
          {chain.lead ? <Lead id={chain.lead} variant="chain" /> : null}
          <ol className="chain__list" data-chain={chain.id}>
            {chain.positions.map(p => (
              <li className="chain__item" key={p.n} data-position={p.n} data-mention={p.mention ? '' : undefined}>
                {research && p.link ? <span className="chain__rel" data-connective="chain" data-rel={p.link.rel}>{chainWord(p.link)}</span> : null}
                {p.mention
                  ? <Statement id={p.id} variant="mention" chain={chain.id} toldIn={p.toldIn} />
                  : isTallyRow(p.id) ? <TallyLine id={p.id} /> : <Statement id={p.id} chain={chain.id} told anchor={p.anchor} drawer={sid} />}
              </li>
            ))}
          </ol>
        </>
      )}
    </div>
  );
}
