// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafNotes.jsx — the register of a leaf's words (EXPLORE_PLAN §2.2, interface 15; round 7: the notes of a page top and the lines of the
// door's cards): a note is a row, rendered by Statement in the short register of its learner text when it has one and the level is learner, else in
// the full register; research level is always full. The notes themselves are drawn by PageTop (.top-notes), numbered 1 to 3.
import { textFor } from '../app/content.js';

/** does the row have a learner text in the short register at these settings (mode, lens) */
export const hasShort = (id, s) => s.level === 'learner' && textFor(id, { mode: s.mode, level: s.level, lens: s.lens, register: 'short' }) != null;
/** the register a note (or a card's line) is shown in: short at learner level when the row has a short text, else full */
export const registerOf = (id, s) => (hasShort(id, s) ? 'short' : 'full');
