// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PageRecord.jsx — the record of a page (docs/round7/PLAN.md R7-4, interfaces 36 and 38): a closed fold at the end of every page, before
// the links to the previous and next page, titled "The record of this page (n statements · m scripts)" ("For researchers and agents" at learner
// level). Open, it shows every row placed on the page — its id, kind, status word (Badge draws it), its scripts (each once, with the number of its
// checks the row names) with their last run, how many rows it
// rests on, how many lens readings it has, its address — and links the same record as a file, content/records/<route>.json, which
// tools/page_records.mjs writes at build from the same function (pageRecord of src/app/queries.js). The counts of the closed fold come from the
// records' index (content/records.json, written with the files) and from the rows; the tables the open fold needs (the checks, their runs, the lens
// readings) load when it opens. No row's words are shown here: the page shows them. A page that places no row shows no fold (its file is written).
import { useState } from 'react';
import { useSettings, useTable } from '../app/content.js';
import { pageRecord, placedRows, recordFile } from '../app/queries.js';
import { pagesByRoute } from '../app/store.js';
import { STATUS_PLAIN, TOP_WORDS } from '../app/vocab.js';
import Badge from './Badge.jsx';
import Link from './Link.jsx';
import { ChevronDown } from './Icons.jsx';
import '../styles/record.css';

const plural = (n, one, many) => `${n} ${n === 1 ? one : many || one + 's'}`;
const base = p => String(p || '').split('/').pop();

/** a row's evidence by script: each script once, with the number of its checks the row names and its last run (a run of the script before a reading
 *  of it); an entry without a script, by its check */
function byScript(evidence) {
  const out = [], seen = new Map();
  for (const e of evidence) {
    const key = e.script || `check:${e.check}`;
    if (!seen.has(key)) { const g = { key, e, n: 0 }; seen.set(key, g); out.push(g); }
    const g = seen.get(key);
    g.n++;
    if (g.e.mode === 'read' && e.mode !== 'read') g.e = e;
  }
  return out;
}
/** the last run of a script, in words: passed (ok/total when the run counts them), failed, read only, or no run recorded */
function runWord(e) {
  if (e.mode === 'read') return 'read';
  const r = e.lastRun;
  if (!r) return 'no run';
  const n = r.ok != null && r.fail != null ? ` ${r.ok}/${r.ok + r.fail}` : '';
  return r.passed === true ? `passed${n}` : r.passed === false ? `failed${n}` : 'run';
}

function StatusWord({ row, level }) {
  if (row.badge) return <Badge status={row.status} badge={row.badge} level={level} />;
  const w = STATUS_PLAIN[row.status];
  return <span className="record-status">{w ? w[level === 'learner' ? 'learner' : 'research'] : row.status || '—'}</span>;
}

/** the open fold: the download link and the table of the record (exported for tests/record.test.mjs, which renders it on the server) */
export function RecordBody({ route }) {
  const s = useSettings();
  const [checks] = useTable('checks');
  const [runs] = useTable('check_runs');
  const [readings] = useTable('lens_readings');
  if (!checks || !runs || !readings) return <p className="record-loading" role="status">Loading the record…</p>;
  const rec = pageRecord(route);
  if (!rec) return null;
  return (
    <div className="record-body">
      <p className="record-links"><a className="record-download" href={`./${recordFile(route)}`} download>{TOP_WORDS.download}</a></p>
      <div className="record-scroll">
        <table className="record-table" data-rows={rec.rows.length}>
          <thead>
            <tr><th scope="col">Row</th><th scope="col">Kind</th><th scope="col">Status</th><th scope="col">Scripts and their last run</th><th scope="col">Rests on</th><th scope="col">Readings</th><th scope="col">Address</th></tr>
          </thead>
          <tbody>
            {rec.rows.map(r => (
              <tr className="record-row" key={r.id} data-row={r.id}>
                <th scope="row" className="record-row__id"><Link to={route} at={r.id}>{r.id}</Link></th>
                <td className="record-row__kind">{[r.kind, r.stage].filter(Boolean).join(' · ')}</td>
                <td className="record-row__status"><StatusWord row={r} level={s.level} /></td>
                <td className="record-row__scripts">
                  {r.evidence.length ? (
                    <ul className="record-scripts">
                      {byScript(r.evidence).map(g => (
                        <li key={g.key} data-script={g.e.script || undefined}>
                          <span className="record-script">{g.e.script ? base(g.e.script) : g.e.check}</span>
                          {g.n > 1 ? <span className="record-run">{` · ${g.n} checks`}</span> : null}
                          {' '}<span className="record-run">{runWord(g.e)}</span>
                        </li>
                      ))}
                    </ul>
                  ) : '—'}
                </td>
                <td className="record-row__n">{r.depends.length}</td>
                <td className="record-row__n">{r.readingsCount}</td>
                <td className="record-row__address">{r.address || '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default function PageRecord({ route }) {
  const s = useSettings();
  const [open, setOpen] = useState(false);
  const [index] = useTable('records');
  if (!pagesByRoute()?.has(route)) return null;
  const n = placedRows(route).length;
  if (!n) return null;   // a page that places no row (the glossary) has no record to show; its file exists all the same
  const entry = index && index.routes ? index.routes[route] : null;
  const m = entry && Number.isInteger(entry.scripts) ? entry.scripts : null;
  const label = s.level === 'learner' ? TOP_WORDS.recordLearner : TOP_WORDS.record;
  return (
    <details className="record" id="sec-record" data-route={route} data-record-rows={n} open={open} onToggle={e => setOpen(e.currentTarget.open)}>
      <summary className="record-head">
        <span className="record-head__caret" aria-hidden="true"><ChevronDown /></span>
        <span className="record-head__label">{label}</span>
        <span className="record-head__n">{` (${plural(n, 'statement')}${m != null ? ` · ${plural(m, 'script')}` : ''})`}</span>
      </summary>
      {open ? <RecordBody route={route} /> : null}
    </details>
  );
}
