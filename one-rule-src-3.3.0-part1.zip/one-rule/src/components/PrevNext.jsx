// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PrevNext.jsx — the previous and next page in the order of pages.json, each page followed by its sub-pages (entries whose `parent`
// it is, interface 29), so a calibration's tabs are walked in their order; above the links, the page's `next` line (a story row of its intro,
// v15's "after", docs/STORY_PLAN.md §2.1 item 8), at learner level in its learner words.
import { useSettings } from '../app/content.js';
import { peekTable } from '../app/store.js';
import { pageLabel } from '../app/queries.js';
import Link from './Link.jsx';
import Lead from './Lead.jsx';

const EXPLORE_KINDS = ['explore-home', 'leaf', 'explorer'];
let orderMemo = null;
/** the pages in reading order: pages.json's, each page followed by its sub-pages (depth first) */
export function readingOrder() {
  const all = peekTable('pages') || [];
  if (orderMemo && orderMemo.all === all) return orderMemo.list;
  const pages = all.filter(p => !EXPLORE_KINDS.includes(p.kind));
  const routes = new Set(pages.map(p => p.route));
  const seen = new Set(), list = [];
  const add = p => {
    if (seen.has(p.route)) return;
    seen.add(p.route); list.push(p);
    for (const c of pages) if (c.parent === p.route) add(c);
  };
  for (const p of pages) if (!p.parent || !routes.has(p.parent)) add(p);
  for (const p of pages) add(p);
  orderMemo = { all, list };
  return list;
}

export default function PrevNext({ route, next = null }) {
  const s = useSettings();
  const pages = readingOrder();
  const i = pages.findIndex(p => p.route === route);
  const line = next ? <Lead id={next} variant="next" /> : null;
  if (i < 0) return line ? <div className="pn-block">{line}</div> : null;
  const prev = pages[i - 1], nxt = pages[i + 1];
  return (
    <div className="pn-block">
      {line}
      <nav className="pn" aria-label="Previous and next page">
        {prev ? (
          <Link to={prev.route} className="pn__link pn__link--prev" rel="prev">
            <span className="pn__dir">Previous</span>
            <span className="pn__title">{pageLabel(prev.route, s)}</span>
          </Link>
        ) : <span />}
        {nxt ? (
          <Link to={nxt.route} className="pn__link pn__link--next" rel="next">
            <span className="pn__dir">Next</span>
            <span className="pn__title">{pageLabel(nxt.route, s)}</span>
          </Link>
        ) : <span />}
      </nav>
    </div>
  );
}
