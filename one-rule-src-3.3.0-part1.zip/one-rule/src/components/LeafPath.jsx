// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/LeafPath.jsx — the map of the leaves as the door and the search read it (content/explore/registry.json, through LEAVES of
// src/app/router.js; docs/round7/PLAN.md R7-3): the path of eight leaves in reading order, the shelf, the lens explorers; whether a leaf is drawn (its
// figure has a seed in figures.json); the row a leaf's card shows (the caption row of its figure, the leaf's hero row; a leaf not drawn yet has none).
// Names only: nothing here states anything.
import { LEAVES } from '../app/router.js';
import { figuresById } from '../app/store.js';

/** the leaves of the path, by their number 1 … 8 */
export const pathLeaves = () => LEAVES.filter(e => e.kind === 'path').sort((a, b) => (a.n ?? 0) - (b.n ?? 0));
/** the leaves of the shelf, in the registry's order */
export const shelfLeaves = () => LEAVES.filter(e => e.kind === 'shelf');
/** the lens explorers */
export const lensLeaves = () => LEAVES.filter(e => e.kind === 'lens');
/** the path leaf of number n, or null */
export const pathLeaf = n => pathLeaves().find(e => e.n === n) || null;
/** is a leaf drawn: it names a figure that figures.json seeds */
export const isDrawn = e => !!(e && e.figure && figuresById()?.has(e.figure));
/** the name of a leaf (the registry's: a name, never a claim) */
export const leafName = e => (e && (e.name || e.slug)) || '';
/** the row a leaf's card shows: the caption row of its figure (the leaf's hero row); a leaf not drawn yet has none (its card says "coming") */
export function leafRow(e) {
  if (!e) return null;
  const seed = e.figure ? figuresById()?.get(e.figure) : null;
  return (seed && seed.captionRow) || null;
}
