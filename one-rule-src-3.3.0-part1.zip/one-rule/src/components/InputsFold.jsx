// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/InputsFold.jsx — "What this page takes from outside (n)" (docs/STORY_PLAN.md §2.1 item 7; 06: inputs render as a compact list): the
// page's inputs, the rows of its needs sections, as one closed fold at the end of the page with their badges, in place of a body section titled
// "Needs". Its lead (or, at learner level, v15's plain needs strip as learner rows) comes first; one drawer for the inputs (its Needs tab names
// their kinds, as the needs section's drawer did). The fold is not a section of the body (no class "sec").
import Statement from './Statement.jsx';
import Lead from './Lead.jsx';
import Drawer from './Drawer.jsx';
import { BadgeIcon } from './Icons.jsx';
import { STORY_WORDS } from '../app/vocab.js';

export default function InputsFold({ inputs, open = false, onToggle, drawers = true, drawer, onDrawer }) {
  if (!inputs) return null;
  const rows = inputs.rows || [], learnerRows = inputs.learnerRows || [];
  if (!rows.length && !learnerRows.length) return null;
  return (
    <details className="fold fold--inputs" id="sec-inputs" data-outline={STORY_WORDS.inputs} open={!!open} onToggle={e => onToggle && onToggle(e.currentTarget.open)}>
      <summary className="fold__summary">
        <span className="fold__icon fold__icon--input"><BadgeIcon kind="input" size={14} /></span>
        <span className="fold__title">{`${STORY_WORDS.inputs} (${rows.length})`}</span>
      </summary>
      <div className="fold__body">
        {inputs.lead ? <Lead id={inputs.lead} variant="inputs" /> : null}
        {learnerRows.map(id => <Lead key={id} id={id} variant="inputs" />)}
        {rows.length ? <div className="fold__group">{rows.map(id => <Statement key={id} id={id} />)}</div> : null}
        {drawers && rows.length ? (
          <Drawer sid="__inputs" rows={[]} details={rows} open={drawer && drawer.open} focus={drawer && drawer.focus} onToggle={o => onDrawer && onDrawer('__inputs', o)} />
        ) : null}
      </div>
    </details>
  );
}
