// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/SubNav.jsx — the tab strip of a page that has sub-pages (docs/STORY_PLAN.md §2.5; BUILD_CONTRACTS interface 29: pages.json `parent`
// and `tab`): on the parent and on each of its sub-pages, one row of links under the page header — the parent first (its short name, as the sub-page's
// eyebrow reads it: "Calibration 2"), then the sub-pages in the order of pages.json (Furey's five tabs in v15's order) — the page shown marked
// aria-current="page". The labels are the pages' own titles (`tab`, else the title, at the reader's level); the links carry the reader's settings.
// A page that is neither a parent nor a sub-page draws nothing. The words of this file are labels; no statement.
import { useSettings } from '../app/content.js';
import { pagesByRoute } from '../app/store.js';
import { parentLabel, subPagesOf, titleIn, pageTitle } from '../app/queries.js';
import Link from './Link.jsx';
import '../styles/subnav.css';

/**
 * The strip of a route at these settings: { parent, items: [{ route, label, current, parent }] }, the parent first and then its sub-pages in the
 * order of pages.json; null for a page with no parent and no sub-page (or while the pages table loads).
 */
export function subNavOf(route, s) {
  const pages = pagesByRoute();
  const def = pages ? pages.get(route) : null;
  if (!def) return null;
  const parent = def.parent != null && pages.has(def.parent) ? def.parent : subPagesOf(route).length ? route : null;
  if (parent == null) return null;
  const tabs = subPagesOf(parent).filter(r => pages.has(r));
  if (!tabs.length) return null;
  const tabLabel = r => titleIn(pages.get(r).tab, s) || pageTitle(r, s);
  return {
    parent,
    items: [
      { route: parent, label: parentLabel(parent, s), current: route === parent, parent: true },
      ...tabs.map(r => ({ route: r, label: tabLabel(r), current: route === r, parent: false })),
    ],
  };
}

export default function SubNav({ route }) {
  const s = useSettings();
  const nav = subNavOf(route, s);
  if (!nav) return null;
  return (
    <nav className="subnav" aria-label={`${nav.items[0].label}, page by page`} data-subnav={nav.parent}>
      <ol className="subnav__list">
        {nav.items.map(it => (
          <li key={it.route} className="subnav__item">
            <Link
              to={it.route}
              className={`subnav__link${it.parent ? ' subnav__link--parent' : ''}`}
              data-route={it.route}
              aria-current={it.current ? 'page' : undefined}
            >
              {it.label}
            </Link>
          </li>
        ))}
      </ol>
    </nav>
  );
}
