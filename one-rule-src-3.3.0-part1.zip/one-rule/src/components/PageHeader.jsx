// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// src/components/PageHeader.jsx — "Step k of 20 · stage", the title for the mode and level, and the needs chips linking to the pages
// this one needs. Step numbers come from steps.json, never typed. A sub-page (interface 29) reads "<parent> · <tab>" in its eyebrow, the
// parent's name a link back to it ("Calibration 2 · Her papers").
import { useSettings } from '../app/content.js';
import { pagesByRoute } from '../app/store.js';
import { pageHeading, pageLabel } from '../app/queries.js';
import Link from './Link.jsx';

export default function PageHeader({ route, heading, needs, children }) {
  const s = useSettings();
  const h = heading || pageHeading(route, s);
  const list = (needs || (pagesByRoute()?.get(route)?.needs) || []).filter(r => pagesByRoute()?.has(r));
  return (
    <header className="ph">
      {h.parent ? (
        <p className="ph__eyebrow" data-parent={h.parent.route}>
          <Link to={h.parent.route} className="ph__parent">{h.parent.label}</Link>
          <span className="ph__tab">{` · ${h.parent.tab}`}</span>
        </p>
      ) : h.eyebrow ? <p className="ph__eyebrow">{h.eyebrow}</p> : null}
      <h1 className="ph__title" id="page-title">{h.title}</h1>
      {h.deck ? <p className="ph__deck">{h.deck}</p> : null}
      {children}
      {list.length ? (
        <nav className="ph__needs" aria-label="This page builds on">
          <span className="ph__needs-label">Builds on</span>
          <ul className="chips">
            {list.map(r => <li key={r}><Link to={r} className="chip">{pageLabel(r, s)}</Link></li>)}
          </ul>
        </nav>
      ) : null}
    </header>
  );
}
