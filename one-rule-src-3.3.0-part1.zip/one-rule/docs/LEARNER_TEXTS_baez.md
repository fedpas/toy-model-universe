<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of the Baez chapter (step 19)

`content/texts_learner_baez.json` holds **246 learner drafts**, one for every row of the Baez-papers chapter: the rows `LNB-*` of the 23 `bz-*` sections in the `lenses` group of `content/learner_backlog.json`, none of which had a learner text. **No row is left out.** Each draft translates its row's research text (`texts.json`, level research, lens null, mode both) under `docs/09_TRANSLATION_PROTOCOL.md` §2: the same statement in plain words, no formula, no new claim, every number, scope and status word kept. The records have the shape of `content/texts_learner.json` (`status: "draft"`, `source: "translator:learner@2026-10-10"`); `termsUsed` and `keptNumbers` come from `node tools/check_learner_texts.mjs --fix`, never typed.

Pipeline, all passing with these drafts merged:

- `node tools/check_learner_texts.mjs --file content/texts_learner_baez.json`: PASS, all 13 rules, 246 records; the default run over every `content/texts_learner*.json` file together also passes (no row drafted twice).
- `node tools/merge_learner_texts.mjs`, then `node tools/build_content.mjs`: 0 errors. The 224 warnings are all row-level (dependencies and evidence ids not found); none comes from a learner text (no Greek letter, no symbolic equation).
- `node tests/coverage.test.mjs`: PASS. `steps/baez` renders 246 statements at learner level in physics mode and 235 in mathematics mode, the same numbers as at research level, with no KaTeX node.
- `node tests/logbook.test.mjs`: PASS (535 of 535 checks).

## Drafts by section

| section | rows | drafts | left out | length (characters) |
|---|---|---|---|---|
| bz-top (with the page hero LNB-001) | 19 | 19 | 0 | 84–760 |
| bz-papers | 12 | 12 | 0 | 54–493 |
| bz-generation | 20 | 20 | 0 | 121–556 |
| bz-ladder | 8 | 8 | 0 | 165–761 |
| bz-ring | 8 | 8 | 0 | 128–524 |
| bz-more | 12 | 12 | 0 | 181–968 |
| bz-which | 7 | 7 | 0 | 134–517 |
| bz-ten | 7 | 7 | 0 | 190–754 |
| bz-kepler | 15 | 15 | 0 | 97–1173 |
| bz-periodic | 6 | 6 | 0 | 60–547 |
| bz-numbers | 5 | 5 | 0 | 159–381 |
| bz-gaps | 10 | 10 | 0 | 57–202 |
| bz-persp | 17 | 17 | 0 | 85–538 |
| bz-questions | 8 | 8 | 0 | 114–285 |
| bz-notes | 2 | 2 | 0 | 185–538 |
| bz-honest | 12 | 12 | 0 | 44–217 |
| bz-w-family | 10 | 10 | 0 | 69–401 |
| bz-w-which | 7 | 7 | 0 | 76–331 |
| bz-w-ladder | 6 | 6 | 0 | 128–211 |
| bz-w-kepler | 8 | 8 | 0 | 51–632 |
| bz-w-papers | 34 | 34 | 0 | 43–406 |
| bz-w-ring | 7 | 7 | 0 | 87–501 |
| bz-w-madelung | 6 | 6 | 0 | 67–265 |
| **total** | **246** | **246** | **0** | median 207 |

Three drafts are longer than 900 characters, inside the 1.5 × limit of their long research texts: LNB-018 (968, research 693), LNB-023d (1118, research 772), LNB-023e (1173, research 792). All drafts have one to five sentences (113 one, 78 two, 41 three, 12 four, 2 five).

## Rows left out, and why

None. No rule of the checker rejected a faithful text in a way that forced a row out; where a rule shaped the wording, the choice is listed under "Renderings forced by the checker" below.

## The register

The drafts follow the chapter's own plain layer (the v15 Young Learner lines, which are rows here too: LNB-053 to LNB-065, LNB-107 to LNB-110, LNB-129 to LNB-131, LNB-134, LNB-135, LNB-153 to LNB-165, LNB-170 to LNB-172, LNB-176 to LNB-178) and the drafts of `docs/LEARNER_TEXTS.md`:

- a generator or a bit is a **switch** (plus, minus or zero switch); a label is a **pattern** of switches; an even label is a pattern with an even number of switches on; XOR with 11111 is **flipping all five switches**; the popcount is the number of switches that are on; the Hamming distance is the number of switches in which two patterns differ; the bit rule is **the switch rule**;
- a blade is a **piece**, a bivector a **plane** or a piece made of two switches, the commutator **the order-matters product**, the pseudoscalar the piece made of all the switches, M₃₂(ℝ) the 32 by 32 grids of real numbers;
- the Kepler bivectors L and M are **the two kinds of moves** (rotations, and the planes joining a space switch to the fourth); ε is **the square of the fourth switch** ("the fourth square"); s of step 11 is the extra square;
- h₂(ℂ), h₃(ℂ), h₂(𝕆), h₃(𝕆) are the 2 by 2 or 3 by 3 hermitian complex or octonion matrices (the Albert algebra where the row says so); a₅(ℂ) the 5 by 5 skew complex matrices; M₃,₂(ℂ) the 3 by 2 complex matrices; projections onto the plane P are **shadows**; ℂ⁴, ℂ¹⁰ are four or ten complex dimensions;
- Lie algebras keep their names (so(4,2), su(3), E7, F4, G2, sl(3), A2, D6); "3-graded" is graded in three layers; the Peirce eigenvalue is the Peirce value; formulas are said in words ("one minus a quarter of the number of switches in which the two patterns differ", "half the number of weak switches on, minus a third of the number of colour switches on").

Identifiers are dropped, as in the drafts of `docs/LEARNER_TEXTS.md`, since the drawer shows the evidence: check ids (baez·…, bzw·…, bd·…, core·…, fibre·…, bridge·…), theorem ids (Thm T4 and so on, said "a theorem of the atlas" where the row leans on it), finding and question ids (J1–J10, P4–P8, QA4, N4), matrix row ids (K.8, C.2) and the list labels B.1–B.10. A reference to a finding that carries content is said by its content (LNB-024 "the shell sizes 2n² of J8" becomes "the shell sizes, twice the square of the shell number"; LNB-024b "the structure of J1 and J2" becomes "the structure of the five-switch findings"). Equation, table, lemma and section numbers of the papers stay. Names of people appear only where the row's research text (or its parent's) has them.

## Renderings forced by the checker

- **3̄** is written **3-bar** (the combining macron is a formula mark, R4); **D III** is written **D-III** (a lone capital D is a single-letter variable, R4); **K₀** is **K-zero**; the Gosset polytope **2₂₁** is **2-21** (subscripts, R4).
- LNB-011b keeps the citation **hep-th/9807127**: R6 requires the number 9807127, because the checker's arXiv pattern covers only new-style numbers.
- LNB-016h, LNB-023i, LNB-030, LNB-030b keep **Section 5.2** and **Section 5.1** ("Section" is not among the identifier words, so 5.1 and 5.2 are required decimals).
- LNB-012c keeps the paper's citation as printed, **(Prop. 1, Lemmas 2 to 4, Prop. 5 and Thm. 12)**: the numbers are required (plural "Lemmas" and "Thm." with a dot are not identifiers), and "Proposition" spelled out would be a new capitalised word (R12).
- LNB-125 says **the eccentricity vector** for e: the row does not name the Runge–Lenz vector and has no parent row, so the name would be new (R12). Its sibling rows LNB-023b to LNB-023k may use the name through their parent LNB-023.
- A number said in a hyphenated word does not count for R6 ("three-dimensional" is not 3), so a few drafts say "a space of three dimensions" or "(3-manifolds)".

## Three examples

**LNB-001** (bz-top, the hero of the page).
Research: "The 16 even five-bit labels, sorted by weak and colour bits, fall into exactly the six Peirce pieces of one generation of the Jordan-pair paper (1, 1, 6, 3, 3, 2); hypercharge Y = a/2 − b/3 and charge Q are bit counts, and the anomaly sums are 0 (baez·H1a–H2d)."
Learner: "The 16 patterns of five switches with an even number of switches on, sorted by how many weak and how many colour switches are on, fall into exactly the six Peirce pieces of one generation of particles in the Jordan-pair paper, of sizes 1, 1, 6, 3, 3 and 2. The hypercharge (half the number of weak switches on, minus a third of the number of colour switches on) and the charge are counts of switches, and the anomaly sums are zero."

**LNB-014c** (bz-generation, a formula said in words).
Research: "Hypercharge is linear in the bit counts, Y = a/2 − b/3 (a weak bits and b colour bits set), with the six values 0, +1, +1/6, +1/3, −2/3, −1/2 of multiplicities 1, 1, 6, 3, 3, 2; the charge is Q = (first weak bit) − b/3, and Q = T₃ + Y (baez·H2b, baez·H2c)."
Learner: "The hypercharge depends linearly on the counts of switches: half the number of weak switches that are on, minus a third of the number of colour switches that are on. It takes the six values 0, +1, +1/6, +1/3, −2/3 and −1/2, on 1, 1, 6, 3, 3 and 2 patterns. The charge is one if the first weak switch is on, minus a third for each colour switch that is on, and it equals the third component of the weak isospin plus the hypercharge."

**LNB-011c** (bz-top, a scope kept: a pointer to a source not read).
Research: "B.10 Over ℤ the triangle count on the Eisenstein 10-tuples is an even unimodular form (integral, even diagonal, determinant 1) of real signature (2,18): its lattice is II₂,₁₈ = U ⊕ U ⊕ E₈ ⊕ E₈ (bd·str·19; that the signature fixes an indefinite even unimodular lattice: pointer, source unread)."
Learner: "Over the whole numbers, the triangle count on lists of 10 Eisenstein integers is an even unimodular form (whole-number entries, even diagonal, determinant 1) of real signature (2,18): its lattice is the even unimodular lattice of that signature, made of two hyperbolic planes and two copies of E8. That the signature fixes an indefinite even unimodular lattice is a pointer to a source we have not read."

## Unclear research texts, and points for the author

- **LNB-017d** uses Φ₀ and β_k, defined in neither the row nor its neighbours (the check script defines them: Φ₀ the roots whose shadow is 0, β_k the root of A₂ orthogonal to w_k). The draft says "the 30 roots whose shadow is at the centre" and "one root of A2"; the "32 at inner product +1" is read as inner product with that root.
- **LNB-023h** "V_j ⊗ V_j has 4A² + 1 = n²": A is the first su(2) and A² its Casimir (as in the check K2b); the draft says "four times the spin squared of one copy, plus one, is the square of the shell number".
- **LNB-022d** does not say what the vectors v_j in Σ|v_j|² are; the draft says "the vectors".
- **LNB-025d** "the null part Λ(ℝ^r) is one, in super vector spaces": "one" can mean a commutative algebra in the super sense or a commutative Frobenius monoid; the draft keeps the same ambiguity ("is one, in super vector spaces").
- **LNB-046** "εM or εL?" uses ε for the Levi-Civita symbol, while ε is the fourth square everywhere else in the chapter; the draft asks "The other generators, or the angular momentum?".
- **LNB-060** "its groups and charges are counts that sum to zero": only the charges (and the anomaly sums) sum to zero; the draft keeps the wording.
- **LNB-023** names the Hamiltonian and the unscaled vector A ("the energy", "the unscaled vector") instead of spelling out their formulas in words, to stay inside 900 characters; the identities themselves are all said.
- **LNB-059** ends with a colon: it introduces the nine gap topics of the plain list in the author's package, which are not rows (LNB-028 to LNB-028d are four formal gap rows). The draft keeps the colon, so the learner page shows a lead-in with no list after it, as the research page does.
- **Repeated statements at learner level.** The chapter's plain v15 lines are rows of their own, so at learner level several pairs say the same thing twice: LNB-047 and LNB-060, LNB-048 and LNB-061, LNB-049 and LNB-062, LNB-050 and LNB-063, LNB-051 and LNB-064, LNB-052 and LNB-065, and the widget captions LNB-101 to LNB-106 beside LNB-107 to LNB-110 (likewise in the Kepler, ring and Madelung captions). The author may prefer to make each plain row the human learner text of its formal row and hide it at research level.
- For the plain rows the drafts are light rewordings of the research text, since it is already in plain words.
