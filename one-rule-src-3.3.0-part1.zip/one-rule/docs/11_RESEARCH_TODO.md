# 11 — What remains to research or decide

## 1. Question 2, with sources — DONE: see `docs/Q2_SOURCES.md` (web-sourced 10 Oct 2026; summary below kept as the reading it confirmed)

The question: "Is this bit rule and the code that supports it any different from current standard ways? Find similar coding results online, similar to how the Atlas handles gravity in its Python scripts." My reading from the package alone, to be confirmed with sources (one web-research session; prompt below):

- The engine (`researchers_checks/bitrule_A.py`, `clC.py`, the JS kernels) is the standard **bitmap representation** of a Clifford algebra: blades as bit masks, product by XOR, sign by the reordering parity times the metric of the shared bits. Expected sources: Dorst–Fontijne–Mann, *Geometric Algebra for Computer Science* (the implementation chapter on bitmap blades); Fontijne's Gaigen; ganja.js (De Keninck); the Python packages `clifford` (layout sign tables), `kingdon`, `galgebra`; Garamon (Breuils–Nozick–Fuchs); Gaalop; Versor. Degenerate generators as extra bits (PGA, exterior algebra) are standard in ganja.js and in the PGA literature. Exact rational arithmetic and the "forms are the null bit rule" framing are a presentation choice, not a new algorithm.
- The **ℤ₄ form w = π + 2Q, the clock as a Brown invariant, the mod-8 periodicity**: the specialist readings inside the package already say this is standard and under-claimed (Arf–Brown–Kervaire invariant of a Pin⁻ enhancement = Brauer–Wall class of ℝ = signature mod 8 = Fidkowski–Kitaev ℤ₈ = KO-degree). Expected sources: Wall (1964) on the graded Brauer group; Kirby–Taylor on Pin structures and the Brown invariant; Debray–Gunningham on the Arf–Brown–Kervaire invariant; Fidkowski–Kitaev (2010/2011) on the ℤ₈ classification; Wood (1993) on doubly-even self-dual codes as Lagrangians of (𝔽₂ⁿ, weight mod 4); van der Blij's lemma. The thing to establish is whether any source states the formula "clock of Cl(p,q) = Brown invariant of π + 2Q on the labels" in those words; the readings suggest the ingredients are all in print and the sentence is the Atlas's.
- **Gravity computed in Clifford algebra**: prior art to compare with the twice-computed gravity scripts (tetrad, ω, R = dω + ¼[ω,ω], Einstein form, Einstein–Cartan action, Kerr/RN/FRW checks against a Christoffel route): Lasenby–Doran–Gull, "Gravity, gauge theories and geometric algebra" (1998); Doran–Lasenby, *Geometric Algebra for Physicists* (the GTG chapters); Hestenes, "Gauge theory gravity with geometric calculus"; Francis–Kosowsky, "Geometric algebra techniques for general relativity"; Snygg; Hsu–Barker–Hobson–Lasenby on horizons; computer-algebra implementations (GAlgebra's curvature examples, SymPy/`clifford` notebooks, Mathematica GA packages, EinsteinPy/xAct for the Christoffel route); De Keninck–Dorst's PGA dynamics and Gunn's thesis for the rigid-body steps. What is expected to be the Atlas's own: computing every statement twice (engine and an independent route), with controls and an eight-fault mutation table, exact arithmetic on random polynomial fields with a stated false-pass bound, shipped logs. No published GA gravity code known to me does the second route and the mutation table systematically; confirm.
- **Labels in other bases**: Gödel-style prime labelling of basis elements (precedents in computer algebra?), base-3 signature words (GA software's metric arrays), Gray-code orderings of blades. Expected: none of these changes the algebra; a base is a notation (a lens), which is the Atlas's own point and is correct.

Prompt for the research session (any model with web access; output `labelling/out/q2_sources.md`, every claim with a URL that was opened; five sections: bitmap representation in software; the ℤ₄ form, the clock and mod 8; gravity in Clifford/GA with a table "Atlas feature → closest prior art → same/different"; other bases; a ten-line verdict: what is standard and where, what is a known result in an unusual language, what is the Atlas's own, what prior work it should cite and does not).

## 2. Labelling passes — DONE: all ten passes validated, merged and judged (`docs/labelling/`: `labels_merged.json`, `graph.json`, `labelling_stats.md`, `JUDGE_LOG.md`, `judge_overrides.json`, the ten outlines). Remaining: T2.4 (turn the missing pieces into `CAND-*` rows) and the author's review of the 14 contradictions and the review notes in `docs/COVERAGE.md`.

## 3. The v16 merge the coordinator still owes

Two rows receive text from two leads and need one wording: `RIG-002` (L10b: free-fall forces; L14: hung body elliptic/hyperbolic) and `GRV-011` (L9bA removes Belinfante and Hehl–Datta from the Not-built list; L9bB inserts the k = ±1 off-origin series, the exponential potential and the Einstein–Dirac series and keeps a shorter Not-built list). The README sentence on H2/H6 and the 13 L7 patches (`d_sign_probe`) are to be applied by the author to `checks/selfcheck/gravity/`.

## 4. Contradictions and review notes found so far (for the author)

From the finished labelling passes and the specialist readings (`notes/reports_analyses_leads.md` §2.8–2.10):
- `LNB-013`, `LNB-050`: evidence says "ran" but the only check (`baez·R1`) was skipped and the text itself says "standard, not checked" → should compute as `cited`/`standard`, not `proved-by-atlas`.
- The six Peirce piece sizes are listed in two orders across rows (`LNB-001/014` vs `LNB-053/101/107`): same multiset; pick one order.
- `LNB-059` is an unfinished sentence; `LNB-027/028/052/059/065` state the same gap five times (one row, four links in V2).
- Two `contradicts` edges declared by the physicist in the category chunk (`graph.json` lists them after the merge).
- The readings' wording requests (not applied; `review` notes): GEN-009/ATL-023 (five M₁₆(ℝ) cells, three with clock 0); LAB-017/018 and QD2 (the clock is standard: retag); T17(b) (totally null planes in Cl(2,2)); T18(f) (r = 0 scope); T14 "not in print" (Wood); F3 "Jacobi holds" (automatic); CPL-005/MAT-005/GRV-011 (the source sign fixed by one action); SPR-004 (Majorana/π-flux); INP-072/026/033/045 vs INP-022/030/044/073 (double-counted inputs); Conventions row 13/H3 (the frame-free triple forgets min(p,q)); ATL-008 (SL(2,ℝ), not SL(2,ℂ), for the unit even versors of Cl(1,2)); LAB-006 (the unit −M/(2r³) in the Weyl eigenvalues).
- Vocabulary to settle once: Calibration vs Warm-up; label 0 vs null; trio vs trinity; three spellings of a cell address; R(n,0,1) / Cl(0,n,1) / Cl(n,0,1); κ vs κ_H vs κ_G; base/fibre in three senses; "lens" in six senses (V2 fixes the last by the registry).

## 5. Decisions for the author (defaults taken by this book)

| decision | default taken |
|---|---|
| the app's name | ONE RULE (alternatives: MOD EIGHT; CELLS & CLOCKS; THE EMPTY LABEL) |
| licence of the new code | the same PolyForm Noncommercial notice as v15 on copied files; new files carry it too until told otherwise |
| the 25 cards' old role names | kept as an off-by-default convention lens `role-names` |
| the Genesis three.js tour | not ported; the Zero page's four-views figure takes its place; the nine stages can become rows if wanted |
| the Italian texts | not migrated; `lang` keeps the door open |
| "admit an action as one named input" (the readings' MB4/group 10) | not applied; a `review` note on CPL-005, MAT-005, GRV-011, INP-027/028/041, CPL-009 |
| the γ0 wording (involution + time direction vs a right reference and a time orientation) | v15 wording kept; the TOR table shown in the clock page's drawer; `review` note |
| whether drafts (model-written texts) may ship | yes, marked `draft` in the drawer and counted in the Method tab, until reviewed |
| the two groups of order 1344 | one `review` note on the Furey and groups rows; no change |
| five agents instead of two for the labelling | two first; topology and combinatorics personas later, for the missing pieces |

## 6. What this book does not cover

The hosting account, the chat model's keys and spend limits, the domain name, and whether the author's repository history should be kept or the V2 started as a new repository (recommended: new repository, with the v15 package archived beside it).
