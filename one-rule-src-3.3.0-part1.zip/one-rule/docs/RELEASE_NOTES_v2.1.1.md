<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# ONE RULE 2.1.1 — release notes

ONE RULE, *an atlas of cells, clocks and lenses*, shows how one labelling — blades of a Clifford algebra as bit masks, products by XOR with a sign — reaches, step by step and with a check at every step, the cells of the algebra, their clock, light, matter, gravity, mechanics, and the languages of several branches of mathematics and of several researchers. Release 2.1.1 is the physics layer of Calibration 1. The Light page and the lens explorers print what the checks of Maxwell's equation compute — the equations by name, the components of the field by role, the sources, cell by cell — as checked output of the Atlas (D29), and the large figures take the width of the page (D31).

## What it holds

<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->
- **Release** 2.1.1 · content: the version the build carries (`content/version.json`, printed in the footer).
- **Statements**: 1,015 rows (the 789 rows of the author's package, with 224 more where a row held several lines, and 2 rows the Explore overlay adds), each with a research text (the author's words, or a draft for review for a row the overlay adds).
- **Texts**: 1,903 in all — 1,013 research texts and 32 learner texts by the author, 2 research drafts and 856 learner drafts waiting for review (drafts by file: texts_learner.json 209, texts_learner_2.json 166, texts_learner_baez.json 246, texts_learner_explore.json 63, texts_learner_schuller.json 172).
- **Status**, computed from the evidence and the labelling: proved by the Atlas 523 · standard 37 · not yet proved here (cited) 31 · our reading 113 · needs an input 93 · open 127 · about the Atlas itself 91.
- **Lenses**: 34, with 973 dictionary entries; 1,901 lens readings on 435 rows in 10 lenses; 982 readings in the readings table.
- **Checks**: 250 scripts with 319 recorded runs; the gravity checks: 5,569 pass, 0 fail.
- **Figures**: 59 drawn, 0 of the 59 seeds shown as labelled placeholders.
- **Candidates**: 150 missing pieces named by the labelling passes, kept in the Logbook until the author accepts them as rows.
- **Pages and tables**: 45 routes; 20 theorems; 34 questions (15 answered); 26 sources; 16 glossary terms; 8 wave-3 leads with 28 proposed edits on 26 rows.
- **Explore**: 14 pages — the home, 10 leaves (6 of the 8 on the path, 4 on the shelf) and 3 lens explorers; not drawn yet: Mirrors, Half-turns; 90 placements of rows of the Atlas; 13 figures; 63 learner drafts (24 in the full register, 39 in the short one); 2 new rows.
- **Build**: `dist/app.js` 1018.0 kB, 320.0 kB gzipped (budget 340 kB, D20); `dist/app.css` 80.6 kB (budget 96 kB).
- **Validation** (docs/COVERAGE.md): 0 errors.
<!-- end of the counts -->

## What the reader sees

- **The equations of light, per cell.** The Light page opens on Maxwell's equation ∇F = J in the cell the reader picks: one of the 15 cells Cl(k, d) the script `maxwell_selfcheck.py` stores, with k directions of time and d of space (k, d ≤ 4, k + d ≤ 7). Each equation carries its name as the script gives it — Gauss, Ampère x, Faraday z, no monopole; with more directions of time a Gauss equation for each (Gauss t1, Gauss t2) and the equations of the extra components (dF t1 t2 x …) — and its terms, each marked by the role of the component it holds. The mirror button turns (k, d) into (d, k). Folded under the equations: the ladders of the equation counts, the sign convention (an input of the Atlas, INP-011, shown as one) and the checks the script ran on the cell. At learner level the same equations are read in words.
- **The components of the field.** In the Maxwell section the field F of the cell is laid out as a grid of its components: E where one index is a time, B where none is, and T where both are (the components a cell with more than one direction of time adds); under it the sources, ρ for each time and J for each space direction. A tap on a component lists the equations it enters, with the sign of its term.
- **The four views by component.** The Clifford, simplex, cube and prime views of Maxwell name each row by its field component (Ex, Bz, T12 …) with the textbook sign of every move; the name of the blade in the active lens is the second line of the row.
- **The physics on the explorers.** On the simplex and cube explorers every vertex, edge and triangle carries its name — a source (ρ, Jx …), a field component (Ex, Bxy …), or the equation whose target it is — in every lens: the lens changes the shape and the label, never the physics name. Picking an element lists its equations; at learner level the same in words. Where a drawing is dense, some names are tooltips only (A37).
- **Motion on the demicube.** The demicube explorer draws what the move of a picked plane corner does: for a boost, the spacetime diagram with the two mirrors that make it, a clock's tick before and after, a rod of length 1 at rest and moved, an event and where it goes, and the square or the cube in motion at one moment; for a turn, the turned rod, square or cube. Play grows the amount step by step from rest. A second plane composes two moves. Two rows the explorer shows, "two mirrors make a boost" (MIR-007, a computation the mirrors check ran) and "the demicube as the picture of motion" (MIR-008, a reading), carry the badges they compute to (D30).
- **Wide figures.** On screens of 1100 px and more, a large figure takes the full width of the page: under the statement it belongs to when it is a page's hero, under its section's title otherwise, with its controls under the drawing and its readouts beside it. Seventeen figures are wide: the Maxwell figures, the four views, the lattice, the three lens explorers and the large figures of the steps. Below 1100 px every figure keeps its column.

## How it is tested

- `tests/maxwell.test.mjs`: every one of the 15 stored cells recomputed through the kernel — the blades with their roles and names, every incidence with its sign, every equation with its terms, the counts — equals `checks/selfcheck/maxwell.json`; broken copies of the convention, the signature and the kernel are caught; the three Maxwell figures print the stored equations term by term at both levels.
- `tests/explore/physics.test.mjs`: every name, equation and sign the explorers print is the stored output, every printed equation recomputed through the kernel, in every cell, lens, level and mode; broken copies of the drawings are caught.
- `tests/explore/motion.test.mjs`: every move the demicube draws, as the sandwich R x R̃ through the kernel, against routes that do not use the bit rule — the textbook boost and rotation matrices, the formulas of speed, rapidity and time dilation, the polar decomposition of a product of two moves — and the stored examples of `checks/selfcheck/mirrors.json`; every frame of Play; broken copies caught.
- `tests/coverage.test.mjs`: a figure is marked wide exactly when its seed says so, and a hero exactly when its own figure is; `tests/ui/smoke.test.mjs`: at 1920 and 1366 px the hero's figure on the Light page and on the simplex explorer spans the page column and no element of the page is wider, its controls stand under its drawing, the wide figures of the Light page's sections span the column; at 1024 px the hero's figure keeps its column.
- The release notes name no date: the content version is the one the build carries (`tests/shipped.test.mjs`, rule 1).
- The budgets: `dist/app.js` within 340 kB gzipped (D20); `dist/app.css` within 96 kB, raised from 80 kB for the notes of the physics and the wide figures. The sizes of this build are in the counts above.

## What is still open

- **The physics audit** (`docs/PHYSICS_AUDIT.md`): 85 `must` gaps — physics v15 showed and a check proves — by page: Light 16 (MX1–MX5 and MX17 are closed by this release; MX6–MX10 are to be ticked against the new figures before the wave starts), commutators 3, Dirac 5, spin 5, coupling 5, Yang–Mills 6, charged matter 5, gravity I 3, gravity II 3, one more generator 6, gauge gravity 3, null surfaces 4, forque 4, the spring 6, the rigid body 4, Calibration 2 (Furey) 6, the tally 1. The wave P4–P11 of the audit closes them, one brief per group of pages (D32).
- **The story round** (`docs/STORY_PLAN.md`): it follows this release (D32).
- The review of the learner drafts, the author's questions A1–A37 and the leaves not drawn: `docs/HANDOVER.md` §3 and `docs/DECISIONS.md`.
