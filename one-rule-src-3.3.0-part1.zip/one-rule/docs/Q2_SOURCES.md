# Q2 sources: is the Atlas bit rule (and its code) different from current standard practice?

Research date: 2026-10-10. Read-only on the package; this is the only file written outside the scratchpad.
Question: "Is this bit rule, and the code that supports it, any different from current standard ways? Find similar coding results online, similar to how the Atlas handles gravity in its Python scripts."

## 0. Reading notes

- Every URL below was opened on 2026-10-10 (each entry repeats "o:2026-10-10"). Pages were read with WebFetch, which returns an extractor-model summary. Quotes are therefore short (<=125 chars), exact for source code, and marked (OCR) for scans with garbled maths. "x2" = fetched twice with the same content. Search-result titles alone are never used as evidence.
- "own check" / "own reading" = my own arithmetic, a short (about 35-line) script run today in the scratchpad (no Atlas code imported), or my reading of a local Atlas row against a source. It is not a web claim and is labelled each time.
- NOT opened, so never used as evidence: ScienceDirect (ABS original) and JSTOR (Brown 1972 original) [permission not granted; the ENS PDF and the Ravenel OCR scan were used instead]; the Springer chapter "A binary index notation for Clifford algebras" [JavaScript wall]; HAL Garamon record and Reading CentAUR "The group of squarefree integers" [Anubis bot wall]; Project Euclid Spector [Incapsula; the Exeter mirror abstract was used]; the Gaigen 2 PDF gpce32-fontijne.pdf [fetch error]; Fontijne thesis chapter 3 [the text returned for the PDF stops in section 2.10]; bivector.net/PGAdyn.pdf [binary]; Ranicki's klausthesis.pdf [proxy rate limit 429, not retried]; raw.githubusercontent.com [egress 403, not routed around]; einsteinpy.org and the geometricalgebra.org root [permission not granted]; GluCat index_set.tcc [fetch error]. Wall 1964 and van der Blij 1959 were not found open.

### 0.1 Negative results (searched, not found)

- Hsu-Barker-Hobson-Lasenby paper on horizons: five searches plus the arXiv author list, nothing ([S3.6]). Li-Ding free-top paper: one search, nothing ([S3.14]).
- A source stating the label-level identity "clock of Cl(p,q) = Brown invariant of (blades, pi + 2Q)": six searches (five of them in extended mode), nothing (see 2.2).
- Prime, Gray-code or base-3 labellings of blades in GA or computer-algebra software: five searches, plus one that surfaced a paper I could not open, nothing usable (section 4).
- Differential forms computed as null generators inside a GA package for gravity; engine-vs-independent-route checking with wrong-version controls in GA or GR code: several searches (sections 1.5 and 3), nothing.

### 0.2 What the Atlas does (local files, read 2026-10-10)

- researchers_checks/bitrule_A.py: blade = bit mask; `e_a e_b = s(a,b) e_{a xor b}`; `s(a,b) = (-1)^{#(i in a, j in b, j<i)} * prod_{i in a&b} eps_i`, eps_i in {+1,-1,0}; multivector = dict mask -> Fraction/int; exact rank over Q.
- selfcheck/core_check.py: Q(a) = [e_a^2 = -1], pi(a) = |a| mod 2, w = pi + 2Q. B1: w(a+b)-w(a)-w(b) = 2 x popcount(a AND b) mod 4 (n<=5). B2: |a&P| - |a&Q| = w(a) mod 4 (n<=6). B3: sum_a i^{w(a)} = (1+i)^p (1-i)^q exactly, so the clock p-q mod 8 is the Brown invariant of (V,w) (n<=8); with r = 1,2 null bits the sum is 2^r times that of Cl(p,q).
- selfcheck/gravity/README.md (lines 1-40): every gravity statement is computed twice, by the bit-rule engine (forms = the same bit rule with every generator null; exact Fractions) and by a standard route that never touches the engine (metric + Christoffel, so(p,q) matrices, gamma matrices, numpy/scipy). Log tags [bit] [std] [std2] [bit==std] [ctl] [cmp]; [ctl] = a wrong version that must fail. Random polynomial test fields with fixed seeds; gravity_selfcheck.py quotes a Schwartz-Zippel bound.

## 1. The bitmap representation of Clifford algebras in software

### 1.1 Where the sign rule is stated (words, formulas, code comments)

- Albuquerque-Majid, Prop. 2.1 [S1.15]: `F(x,y) = (-1)^{sum_{j<i} x_i y_j} * prod_i q_i^{x_i y_i}` on Z_2^n, q_i = +-1. Identical to the Atlas `s(a,b)`.
- Ovsienko, Prop. 3.1 [S1.16]: `e_x . e_y = (-1)^{f(x,y)} e_{x+y}`, `f(x,y) = sum_{1<=j<i<=n} x_i y_j + sum_{p+1<=i<=n} x_i y_i`.
- Dorst-Fontijne-Mann reference code [S1.2], comment: "Count the number of basis vector flips required to get a and b into canonical order."
- Antanovskii [S1.14], in words: "Move each factor ejq ... to the left by swapping it with the immediate left neighbour eip while ip > jq."
- kingdon [S1.6], code: `sign = -1 if swaps % 2 else 1`, then `sign *= self.signature[...]` per eliminated pair.

### 1.2 Sources: software and implementation papers

**[S1.1] Dorst-Fontijne-Mann, Geometric Algebra for Computer Science (2007), table of contents**
- URL: https://www.educate.elsevier.com/book/details/9780123694652 (o:2026-10-10)
- Part III "Implementing Geometric Algebra": Ch. 18 "Implementation Issues"; Ch. 19 "Basis Blades and Operations", described on the page as covering "representing unit basis blades with bitmaps" and the outer, geometric, inner and commutator products of basis blades. I did not find the book text open; its authors' code is [S1.2].

**[S1.2] Book reference implementation, BasisBlade.java (D. Fontijne, (c) 2005-2007, GPL)**
- URL: https://geometricalgebra.org/ga_ref_impl/subspace/basis/BasisBlade.java.html (o:2026-10-10, x2)
- Field comment: "This bitmap specifies what basis vectors are present in this basis blade". Code, condensed from the segments returned, in page order:
```java
public static double canonicalReorderingSign(int a, int b) {
  // Count the number of basis vector flips required to get a and b into canonical order.
  a >>= 1; int sum = 0;
  while (a != 0) { sum += subspace.util.Bits.bitCount(a & b); a >>= 1; }
  return ((sum & 1) == 0) ? 1.0 : -1.0; }          // (the page's comment says "return 1" twice: a typo)
// gp_op:   int bitmap = a.bitmap ^ b.bitmap;   double sign = canonicalReorderingSign(a.bitmap, b.bitmap);
// geometricProduct(a, b, double[] m):  int bitmap = a.bitmap & b.bitmap;   // "bitmap of annihilated vectors"
//          while (bitmap != 0) { if ((bitmap & 1) != 0) result.scale *= m[i]; i++; bitmap = bitmap >> 1; }
```
- This is the Atlas rule: the sum over right shifts of popcount((a>>k) & b) counts #{(i in a, j in b): j<i}; XOR gives the blade; the metric entries m[i] multiply over the shared bits.

**[S1.3] Fontijne, PhD thesis "Efficient Implementation of Geometric Algebra" (UvA 2007) and Gaigen 2**
- URL: https://pure.uva.nl/ws/files/4375498/52687_fontijne.pdf (o:2026-10-10); record https://dare.uva.nl/id/627c5dcb-1b7d-4501-ba81-8c5a97db2749 (o:2026-10-10, 229 pp., award date 2007-10-16); mirror https://softbank.iust.ac.ir/MathBooks/f/Fontijne%20-%20Efficient%20implementation%20of%20geometric%20algebra.pdf (o:2026-10-10, text also ends before chapter 3).
- Section 3.1.2 itself was not read. The front matter lists "3.1 The Basis and Operations on Basis Blades" p. 69, "Table 3.1 Bitmap representation of basis blades" p. 71, "Figure 3.1 Function canonicalReorderingSign(int a, int b)" p. 73, "Figure 3.2 Function gp_op(BasisBlade a, BasisBlade b, boolean outer)" p. 74; section 2.4.8: "We will return to this idea in Section 3.1.2, where we use it to form for the bitmap representation of basis blades."
- Null vectors in the 2007 text: section 2.5.2 "this is inconvenient in geometric algebra because of non-invertibility of the pseudoscalar of such spaces"; section 2.5.6 lifts null vectors to a Euclidean-metric algebra. (Degenerate metrics became routine later with PGA, see [S1.4]-[S1.6], [S3.14].)
- Gaigen 2, GPCE 2006, pp. 141-151: https://dare.uva.nl/id/a95a2f1a-5537-4a87-98ae-ba5a16d0c2fd (o:2026-10-10; record only, PDF not read). Third-party description of Gaigen's storage, no bitmap statement: https://dspace5old.zcu.cz/bitstream/11025/894/1/Charneau.pdf (o:2026-10-10).

**[S1.4] clifford (pygae), Python**
- URLs: https://clifford.readthedocs.io/en/latest/_modules/clifford/_layout_helpers.html and https://clifford.readthedocs.io/en/latest/_modules/clifford/_layout.html (o:2026-10-10, both); API https://clifford.readthedocs.io/en/latest/api/clifford.Cl.html (o:2026-10-10); README https://github.com/pygae/clifford (o:2026-10-10: "a numerical Geometric Algebra (a.k.a. Clifford algebra) package for python").
```python
def canonical_reordering_sign_euclidean(bitmap_a, bitmap_b):   # "assuming a euclidean metric"
    a = bitmap_a >> 1;  sum_value = 0
    while a != 0: sum_value = sum_value + count_set_bits(a & bitmap_b); a = a >> 1
    return 1 if (sum_value & 1) == 0 else -1
# _layout.py  canonical_reordering_sign(bitmap_a, bitmap_b, metric): bitmap = bitmap_a & bitmap_b;
#   output_sign = canonical_reordering_sign_euclidean(...);  for each set bit i:  output_sign *= metric[i]
# gmt_element:  output_sign = canonical_reordering_sign(bitmap_a, bitmap_b, sig_array);  output_bitmap = bitmap_a^bitmap_b
# docstring: "The implementation used here is described in :cite:`ga4cs` chapter 19."
```
- BasisBladeOrder docstring: "Bitmaps represent which basis vectors are present in a basis blade ... the basis blade e_xz is represented with 0b1010."
- Null generators: `Cl(p, q, r, sig=None, ...)`, "r: number of zero-signature basis vectors"; `_from_Cl` builds `[0]*r + [+1]*p + [-1]*q` (null bits LOW; the Atlas puts them high).

**[S1.5] ganja.js (S. De Keninck), JavaScript**
- URLs: https://github.com/enkimute/ganja.js/blob/master/ganja.js (o:2026-10-10, x2); https://github.com/enkimute/ganja.js/blob/master/README.md (o:2026-10-10).
- Two paths: a string path (bubble sort of basis names, each swap `sign*=-1`) for non-graded algebras up to 6 dimensions, and a bit path ("graded: automatic for +6D"). Comment: "As an alternative to the string fiddling, one can also bit-fiddle. In this case the basisvectors are represented by integers with 1 bit per generator set."
- Code: `var n=p2||(p+q+r),t=0,ab=A&B,res=A^B; if (ab&((1<<r)-1)) return [0,0];` ... `t^=t>>4; return [1-2*(27030>>(t&15)&1),res];` (27030 = 0x6996 is the 16-entry parity table: own arithmetic).
- README: "Supports any metric (positive,negative,zero)"; "PGA3D = Algebra(3,0,1)"; "a single zero dimension will get generator name e0" (null generators first). The README never mentions bitmasks.

**[S1.6] kingdon (M. Roelfs), Python**
- URLs: paper https://ar5iv.labs.arxiv.org/html/2503.10451 and https://arxiv.org/abs/2503.10451 (o:2026-10-10; submitted 2025-03-13); source https://github.com/tBuLi/kingdon/blob/master/kingdon/algebra.py (o:2026-10-10).
- Paper section 4: "The keys of a multivector are the binary representations of the basis blades,"; "The basis blades are ordered first by grade, and then lexicographic." Table 1 for Algebra(2,0,1): key 001 = e0, 011 = e01.
- Source: `Algebra._prepare_signs` -> `_compute_sign` -> `bin2canon` -> `_swap_blades` (counts swaps; `sign = -1 if swaps % 2 else 1`); metric: `sign *= self.signature[...]` per eliminated pair, so a null (0) generator gives sign 0; a bit-mask variant `_swap_blades_bin` exists, marked "Not currently used"; for d > 6 signs are computed lazily (`DefaultKeyDict`). Coefficients may be NumPy, PyTorch or SymPy objects (abstract).

**[S1.7] galgebra (pygae), Python/SymPy**
- URL: https://galgebra.readthedocs.io/en/latest/_modules/galgebra/ga.html (o:2026-10-10).
- Not bitmaps: blades are sorted index tuples (`Ga.indexes`, from `combinations`) mapped to non-commutative SymPy symbols. `Ga.blade_reduce` is an insertion sort, each swap flips the sign, a repeated index returns zero in the exterior case; in the orthogonal geometric product repeated indices give `result *= self._ga.g[i, i]`. Non-orthogonal or symbolic metrics go through `reduce_basis` (rule e_i e_j = 2 g_ij - e_j e_i). Same sign rule (swap parity x metric of repeats), more general metric, different data structure, exact symbolic arithmetic via SymPy.

**[S1.8] Garamon (Breuils, Nozick, Fuchs), C++ generator**
- URLs: paper copy https://www.academia.edu/127784116/Garamon_A_Geometric_Algebra_Library_Generator (o:2026-10-10; Adv. Appl. Clifford Algebras 29(4), 2019); README https://github.com/vincentnozick/garamon (o:2026-10-10; no representation details).
- Section 5.1: "a 1-bit at a position i indicates the presence of the basis vector ei in the basis blade" (e1^e3^e4 -> 1101); section 7.1: "the indexes of the basis blades are represented with a binary label"; section 11.4: "the computation of the sign is performed by a constant time operation". The sign is propagated by recursion over a prefix tree (algorithm 8: `sign x complement`, `diagMetric(i)`), not by a popcount loop: same bitmap labels, different sign algorithm.

**[S1.9] Gaalop (Hildenbrand, Schwinn, Stock, Koch), "Gaalop 2.0"**
- URL: https://www.academia.edu/31224739/Gaalop_2_0_A_Geometric_Algebra_Algorithm_Compiler (o:2026-10-10).
- No bitmask statement. Blades are indexed through a canonical table (Table 2); products are delegated to Maple's CLIFFORD ("using the &c operator for the geometric product"); the output "has no more Geometric Algebra operations". Library overview: https://bivector.net/lib.html (o:2026-10-10: kingdon, Clifford, GAALOP, Ganja.js, Garamon, Clados "up to 15 generators and a specifiable metric", Klein, numga, Versor).

**[S1.10] Versor (P. Colapinto), C++**
- URL: https://github.com/wolftype/versor (o:2026-10-10). "supports arbitrary dimensions and metrics", code generated "at compile-time through template metaprogramming". The README does not say how blades are represented (not established).

**[S1.11] GluCat (P. C. Leopardi), C++**
- URLs: https://glucat.sourceforge.net/ and https://github.com/penguian/glucat/blob/master/glucat/index_set.h (o:2026-10-10, both).
- "The class index_set<LO,HI> is based on std::bitset<HI-LO+1>"; header "copyright : (C) 2001-2012 by Paul C. Leopardi", "begin : Sun 2001-12-09"; declaration "// Sign of geometric product of two Clifford basis elements" (`sign_of_mult`). Function bodies not read. A bitset-labelled Clifford library dating from 2001.

**[S1.12] CliffordNumbers.jl, Julia**
- URLs: https://docs.juliahub.com/General/CliffordNumbers/stable/api/indexing.html and https://docs.juliahub.com/General/CliffordNumbers/stable/metrics.html (o:2026-10-10, both).
- `BitIndex`; wedge checks use "bitwise AND"; `sign_of_mult` "carries the sign associated with the multiplication of two basis blades"; "In degenerate metrics, the sign may not matter, since the product can be zero." Signature = array "with the elements constrained to be equal to +1, 0, or -1" (ternary); `Metrics.PGA(3)`.

**[S1.13] Sage and OSCAR (exact Clifford algebras)**
- URLs: https://doc.sagemath.org/html/en/reference/algebras/sage/algebras/clifford_algebra.html and https://docs.oscar-system.org/dev/Experimental/CliffordAlgOrd/clifford_algebras/ (o:2026-10-10, both).
- Sage: basis indexed by subsets ("Rewrite basis indexing using FrozenBitset"); examples over QQ and ZZ; the exterior algebra is the Q = 0 case ("The most degenerate case (the exterior algebra)"; `ExteriorAlgebra` subclasses `CliffordAlgebra`).
- OSCAR: basis elements "enumerated in increasing order of the integer represented by the characteristic vectors of subsets", read "as a binary number with the first entry being the least significant bit"; exact over the rationals and number fields.

**[S1.14] Index-set (non-bitmap) implementations**
- Antanovskii, DSTO-TR-3021 (2014), https://apps.dtic.mil/sti/pdfs/ADA615302.pdf (o:2026-10-10): sorted index subsets, sign by the swapping procedure quoted in 1.1, e23 e12 = -e13, signs hard-coded per product routine.
- Ablamowicz-Fauser, arXiv:1206.3683, https://arxiv.org/pdf/1206.3683 (o:2026-10-10; CLIFFORD/Bigebra): basis `e_I`, `I = (i_1 < ... < i_l)`, product through interior/exterior products; no binary representation in the text read.
- CLICAL manual, https://users.aalto.fi/~ppuska/mirror/Lounesto/CLICAL.htm (o:2026-10-10): computes in matrix images; no indexing scheme stated.

### 1.3 Papers on the cocycle and the binary labelling

**[S1.15] Albuquerque-Majid, "Clifford algebras obtained by twisting of group algebras", arXiv:math/0011040**
- URLs: https://arxiv.org/abs/math/0011040 , https://arxiv.org/pdf/math/0011040 and https://ar5iv.labs.arxiv.org/html/math/0011040 (o:2026-10-10, all three; formula confirmed x2: "F(x,y)=(-1)^{\sum_{j<i}x_{i}y_{j}}\prod_{i=1}^{n}q_{i}^{x_{i}y_{i}}", "C(r,s) denotes the algebra with r of the {q_i} equal to +1 and s equal to -1").
- Abstract: "namely as a twisting of group algebras of Z_2^n by a cocycle"; "We obtain in particular the periodicity properties and a new construction of spinors in terms of left and right multiplication in the Clifford algebra."
- Section 2, Prop. 2.1: the cocycle quoted in 1.1. Section 1.1: C(0,2) = H, C(2,0) = C(1,1) = M_2(k). Section 3, eq. (10): `C(0,n+2) = C(n,0) (x) H`, `C(n+2,0) = C(0,n) (x) M_2(k)`; "H (x) H = M_4(k) then gives the usual table with period 8".

**[S1.16] Ovsienko, "Real Clifford algebras and quadratic forms over F_2: two old problems become one", arXiv:1601.07664**
- URLs: https://arxiv.org/abs/1601.07664 , https://arxiv.org/pdf/1601.07664 and https://ar5iv.labs.arxiv.org/html/1601.07664 (o:2026-10-10, all three; formula confirmed x2: "e_{x}\cdot{}e_{y}:=(-1)^{f(x,y)}e_{x+y}", "f(x,y)=\sum_{1\leq{}j<i\leq{}n}x_{i}y_{j}+\sum_{p+1\leq{}i\leq{}n}x_{i}y_{i}").
- Prop. 3.1 (formula in 1.1); "Define the 'diagonal' quadratic form alpha(x) := f(x,x)" (the Atlas's Q). Theorem 1: twisted algebras are isomorphic exactly when their diagonal forms are equivalent. Arf(q0) = 0, Arf(q1) = 1; q2 on F_2^{2k+1} <-> Mat(2^k, C). The paper does not state p-q mod 8 through Arf or rank (Bott periodicity is in an appendix) and has no Z_4-valued forms, Brown invariant or Gauss sums.

**[S1.17] Elduque and Rodrigo-Escudero, "Clifford algebras as twisted group algebras and the Arf invariant", arXiv:1801.07002**
- URLs: https://arxiv.org/abs/1801.07002 and https://arxiv.org/pdf/1801.07002 (o:2026-10-10, both; Thm. 14 and Cor. 15 fetched x2).
- Cl_{p,q}(R) is the twisted group algebra R^sigma C_2^N with sigma(q,q) = mu(q) (Prop. 8, Thm. 13); the F_2-form q_{p,q} (Example 7) has polar form depending only on N = p+q. Their Arf invariant takes values in {1,0,-1} (Def. 6: compare the number of zeros and ones of q).
- Thm. 14: "Arf(mu_{p,q}) = sign(cos((p-q)pi/4) + sin((p-q)pi/4))", i.e. 1 if p-q+1 = 1,2,3; 0 if p-q+1 = 0,4; -1 if p-q+1 = 5,6,7 (mod 8). Cor. 15 (N = p+q): N even: M_{2^{N/2}}(R) if p-q+1 = 1,3, M_{2^{(N-2)/2}}(H) if p-q+1 = 5,7; N odd: R x R blocks if p-q+1 = 2, M(C) if p-q+1 = 0,4, H x H blocks if p-q+1 = 6 (mod 8). (Own cross-check: this agrees with the table KIND = [R, R2, R, C, H, H2, H, C] indexed by (p-q) mod 8 in gravity_selfcheck.py.) No Z_4-valued forms, Brown invariant, Gauss sums or Brauer-Wall group in the text read.

**[S1.18] Binary integers and XOR**
- Budinich, "On Clifford algebras and binary integers", arXiv:1605.07062, https://arxiv.org/pdf/1605.07062 (o:2026-10-10): Extended Fock Basis elements indexed by pairs of binary signatures (row and column of the matrix algebra); "many algebra properties depend on integers modulo 8, thus meaning that just the three least significant bits of integer n are relevant"; neutral spaces R^{m,m} only; no XOR product rule or popcount sign.
- Courchesne-Tremblay, arXiv:2509.23369, https://arxiv.org/abs/2509.23369 (o:2026-10-10): "Using a binary representation for basis elements of an algebra ... a connection has been established ... and the XOR componentwise operation"; "covers both multicomplex and Clifford algebras of any dimension".
- Ablamowicz, arXiv:1610.03583, https://arxiv.org/abs/1610.03583 (o:2026-10-10): Cl_{p,q} as twisted group rings (Albuquerque-Majid) and as images of group algebras of 2-groups (Chernov); "periodicity of eight" as "a direct consequence of the central product structure of Salingaros vee groups".

### 1.4 The Jordan-Wigner / Fock side (labels as occupation strings, phases mod 4)

**[S1.19]**
- Bravyi-Kitaev, "Fermionic quantum computation", arXiv:quant-ph/0003137, https://arxiv.org/pdf/quant-ph/0003137 (o:2026-10-10): Fock space of m modes "spanned by 2^m basis vectors |n_0, ..., n_{m-1}>"; Majorana operators `c_{2k} = sigma^x[k] prod_{j<k} sigma^z[j]`, `c_{2k+1} = sigma^y[k] prod_{j<k} sigma^z[j]` (eq. 24) with `c_j c_k + c_k c_j = 2 delta_jk`, "known as complex Clifford algebra".
- Aaronson-Gottesman, arXiv:quant-ph/0406196, https://arxiv.org/pdf/quant-ph/0406196 (o:2026-10-10): Pauli operators as bit vectors with a phase tracked through `g(x1,z1,x2,z2)`, "the exponent to which i is raised (either 0, 1, or -1)", the sum checked mod 4.
- Debray-Gunningham Lemma 6.13 ([S2.7]): Majorana operators generate an algebra "noncanonically isomorphic to Cl_{n,n}".

### 1.5 Paragraph: what is standard, and what the Atlas adds in the engine

The rule in bitrule_A.py is the standard bitmap implementation, line for line: XOR for the blade, the parity of #{(i in a, j in b, j<i)} for the reordering sign, the product of the metric entries over a&b [S1.2, S1.4]. Other software re-implements it with other sign algorithms (ganja.js, kingdon, Garamon, GluCat [S1.5, S1.6, S1.8, S1.11]) or with sorted index sets and the same swap-parity x g[i,i] rule (galgebra, Antanovskii, Sage [S1.7, S1.13, S1.14]). Mathematically it is the twisted group algebra of Z_2^n with the cocycle printed in [S1.15] and [S1.16]. What the Atlas adds in the engine itself is small. (i) Degenerate generators as extra bits with eps = 0 (PGA): standard in current software (ganja.js `if (ab&((1<<r)-1)) return [0,0]`, kingdon sign 0, clifford `Cl(p,q,r)`, CliffordNumbers.jl, and Gunn's thesis, which builds PGA on dual projectivized Grassmann algebras [S3.14]), although Fontijne's 2007 thesis calls null metrics inconvenient and lifts null vectors to a Euclidean-metric algebra [S1.3]; the Atlas's own twist is to use the same eps = 0 bits for differential forms (dx^mu squares to 0) inside the gravity engine, and I found no GA package doing this (Sage has the exterior algebra only as the Q = 0 case of CliffordAlgebra [S1.13]). (ii) Exact rational arithmetic: not special (Sage and OSCAR over QQ/ZZ, galgebra and kingdon with SymPy objects); clifford describes itself as "numerical" [S1.4]; the Atlas choice is "standard library only". (iii) The Jordan-Wigner reading (blade label = occupation string; doubling by L_i and twisted R_i generating Cl(n,n) on Cl(V)): standard, see the [S1.15] abstract ("spinors in terms of left and right multiplication in the Clifford algebra"), [S1.19], [S1.18] and [S2.7]. Convention difference worth knowing: ganja.js and clifford put the null generators at the low bits, the Atlas at the high bits.

## 2. The Z4 refinement, the clock and mod-8 periodicity

**[S2.1] Twisted group algebras of (Z_2)^n:** [S1.15] (Prop. 2.1; periodicity from H (x) H = M_4), [S1.16] (f, alpha), [S1.17] (R^sigma C_2^N, Arf in {1,0,-1}, Thm. 14), [S1.18] Ablamowicz (period eight from Salingaros vee groups). Also Bales, arXiv:1107.1375, https://arxiv.org/abs/1107.1375 (o:2026-10-10; abstract only: "The effect of some properties of twisted groups on the associated algebras, particularly Cayley-Dickson and Clifford algebras").

**[S2.2] Atiyah-Bott-Shapiro, "Clifford modules" (1964)**
- URL: https://www.math.ens.fr/~benoist/refs/ABS.pdf (o:2026-10-10, OCR).
- Introduction: "The basic algebraic periodicity (8 in the real case, 2 in the complex case) appears at this stage." Section 4: "C_8 = R(16), whence if C_k = F(m) then C_{k+8} = F(16m)". C_k is the Clifford algebra of a negative definite form (e_i^2 = -1), i.e. Cl(0,k) in the Atlas convention. Table 1: R, C, H, H+H, H(2), C(4), R(8), R(8)+R(8), R(16).

**[S2.3] Brauer-Wall group of R = Z/8 (Wall 1964)**
- URL: https://en.wikipedia.org/wiki/Brauer%E2%80%93Wall_group (o:2026-10-10; secondary, Wall's paper not opened).
- "BW(R) is isomorphic to Z/8Z", linked there to "Bott periodicity of period 8"; a map from the Witt-Grothendieck ring to BW "obtained by sending a quadratic space to its Clifford algebra" that "factors through the Witt group"; cites Wall, "Graded Brauer groups", J. reine angew. Math. 213 (1964) 187-199. The page does not say "signature mod 8".

**[S2.4] Brown's Z_8 invariant and Gauss sums**
- Brown, "Generalizations of the Kervaire invariant", https://www.sas.rochester.edu/mth/sites/doug-ravenel/otherpapers/brown-ocr.pdf (o:2026-10-10, OCR; formula illegible; the scan text does not print the journal, Annals of Math. 1972 is the usual citation). Quadratic functions P: V -> Z_4 with P(u+v) = P(u) + P(v) + j(u.v), j the homomorphism "sending 1 to 2" (Lemma 1.4); an invariant o(P) in Z_8 with (vii) "for P = j.phi, o(P) is the Arf invariant of phi" (value 0 or 4) and (viii) "for a symmetric unimodular form over the integers, o(P) is the signature mod 8".
- Taylor, "Gauss Sums in Algebra and Topology", https://webhomes.maths.ed.ac.uk/~v1ranick/papers/taylorg.pdf (o:2026-10-10): "G(psi) = N(psi) . e^{2 pi i beta(psi)}", beta in Z/8; Brown's theorem beta(psi_B) = sigma(B)/8 (the Milgram formula); "An element omega in T is characteristic provided b(x,x) = b(omega,x) for all x"; "2 beta(psi) = psi(omega) in Z/4Z". No Clifford algebras in the text.

**[S2.5] Kirby-Taylor, "Pin structures on low-dimensional manifolds"**
- URL: https://webhomes.maths.ed.ac.uk/~v1ranick/papers/kirbytaylorpin.pdf (o:2026-10-10, x2, OCR).
- Def. 3.1: quadratic enhancement q with q(x+y) = q(x) + q(y) + 2(x.y) in Z/4. "Theorem 3.2. There is a canonical 1-1 correspondence between Pin- structures on a surface F and quadratic enhancements of the intersection form." Lemma 3.6: Gauss sum A_q = |H^1(F;Z/2)| e^{2 pi i beta(q)/8}, beta in Z/8, an isomorphism with Pin- bordism; "Rp2 generates" with beta = +-1. Pin+-(V) is defined inside the Clifford algebra Cl+-(V) following [ABS]. The text does not connect beta to Clifford algebras beyond that.

**[S2.6] Wood 1993 and the code side**
- Wood, "Witt's extension theorem for mod four valued quadratic forms" (Trans. AMS 1993), https://webhomes.maths.ed.ac.uk/~v1ranick/papers/woodj.pdf (o:2026-10-10, x2, OCR). Abstract: "The mod 4 valued quadratic forms defined by E. H. Brown, Jr. are studied. A classification theorem is proven which states that these forms are determined by two things: whether or not their associated bilinear form is alternating, and the [Brown] invariant". Section 5: "Q(u) = wt(u) mod 4"; "Then there exists a Q-isotropic subspace W of V which is self-dual (i.e., W = W-perp) if and only if a(Q) = 0 mod 8" (a(Q) is the Brown invariant; the OCR letter is garbled); the exponential sum with weights i^{Q(u)} gives a(Q) = n mod 8 for the weight form. Wood says "maximal isotropic" and "self-dual", not "Lagrangian"; no Clifford algebras in the text (spinor groups only in the bibliography).
- Nebe-Rains-Sloane, "The invariants of the Clifford groups", arXiv:math/0001038, https://arxiv.org/abs/math/0001038 (o:2026-10-10): "There are analogues of all these results for the complex group CC_m, with 'doubly-even self-dual code' instead of 'self-dual code'."

**[S2.7] Debray-Gunningham, "The Arf-Brown TQFT of Pin- surfaces", arXiv:1803.11183**
- URLs: https://adebray.github.io/papers/arf_brown.pdf (o:2026-10-10, x2); https://arxiv.org/abs/1803.11183 (o:2026-10-10).
- Abstract: "an 8th root of unity associated to a surface equipped with a pin- structure", "whose partition function is the Arf-Brown invariant", "the low energy effective theory of the Majorana chain". Def. 3.9, eq. (3.11): `q(x+y) = q(x) + q(y) + 2 . I_2(x,y)`; Def. 3.13: AB(Sigma) = normalised sum of exp(2 pi i q(x)/4) (formula garbled in the extraction). Example 4.5 / Prop. 5.1: "ZAB(pt) = Cl_1, the first Clifford algebra". Lemma 6.13: the algebra generated by the Majorana operators is "noncanonically isomorphic to Cl_{n,n}".
- **Remark 5.3: "Some physics-based classifications of these SPTs [FK2, GJF] are rooted in real superalgebra, tying the Z/8 classification to the 8-fold periodicity of Morita equivalence classes of real Clifford algebras."**

**[S2.8] Fidkowski-Kitaev, arXiv:0904.2197 (Phys. Rev. B 81, 134509)**
- URLs: https://arxiv.org/abs/0904.2197 and https://arxiv.org/pdf/0904.2197 (o:2026-10-10, both).
- Abstract: "The topological invariant for the free fermion classification is an integer," and "it becomes well defined only modulo 8". Section I: "this symmetry is described by one positive Clifford generator"; "we can use non-trivial quartic interactions to gap out the dangling Majorana modes for the case of 8 Majorana chains"; 8 Majoranas give "a direct sum of two spinor representations, 8+ and 8-, of so(8)". The paper does not derive the 8 from Clifford periodicity; it defers to its refs [9-11].

**[S2.9] van der Blij's lemma and context**
- https://ncatlab.org/nlab/show/van+der+Blij+lemma (o:2026-10-10): for a symmetric unimodular form Q on Z^n a characteristic element c satisfies "Q(c,c) = sigma(Q) mod 8" (even forms: sigma = 0 mod 8). The page cites Scorpan (2005) only; van der Blij's 1959 paper was not opened; no Gauss sum or Brown invariant on that page. Its finite counterpart is Brown's "2 beta = psi(omega)" in [S2.4].
- Rovi, arXiv:1507.08328, https://arxiv.org/abs/1507.08328 (o:2026-10-10): "The Z_8-valued Brown-Kervaire invariant of Z_4-valued quadratic forms is used to prove ...". Lattice ABK papers (o:2026-10-10, both): arXiv:2603.09354 https://arxiv.org/html/2603.09354 says "The appearance of the Z_8 reflects an eightfold classification of fermionic SPT phases with the reflection symmetry" (refs. to Fidkowski-Kitaev) and arXiv:2512.11424 https://arxiv.org/html/2512.11424v2 mentions the Majorana chain; neither mentions Clifford algebras or a Gauss sum of a Z_4 form.

### 2.1 Table: Atlas Z4 statements -> closest published statement

| Atlas row (core_check) | Closest published statement | Same / different |
|---|---|---|
| B1: w = pi + 2Q, w(a+b)-w(a)-w(b) = 2 x popcount(a AND b) mod 4 | Brown's law with j(u.v) [S2.4]; Kirby-Taylor Def. 3.1 [S2.5]; Debray-Gunningham (3.11) [S2.7] | Same law. The Atlas's content is that Q+pi of the Clifford sign cocycle [S1.15, S1.16] is such a form (own reading) |
| B2: popcount(a AND P) - popcount(a AND Q) equals w(a) mod 4 | none found (elementary) | own |
| B3: sum_a i^w = (1+i)^p (1-i)^q; clock p-q mod 8 = Brown invariant | Gauss-sum definition of Brown's invariant [S2.4, S2.5]; ABS period 8 [S2.2]; BW(R) = Z/8 [S2.3] | Each half is known; the identity on Clifford labels was not found (see 2.2); multiplicativity over the summands <+1>, <-1> is an own reading |
| B6c/B18: (V,Q,pi) isomorphic iff p-q same mod 8 (r = 0) | Wood's classification theorem [S2.6] (non-alternating polar form: fixed by dimension and Brown's invariant) | Same theorem specialised (own reading) |
| B6c: Q alone isometric for more pairs (Cl(2,0), Cl(1,1)) | Ovsienko Thm. 1 [S1.16]; C(2,0) = C(1,1) = M_2(k) [S1.15] | Same |
| B10: doubling, blade labels = spinor weights | Albuquerque-Majid abstract [S1.15]; Bravyi-Kitaev Fock basis [S1.19] | Same idea; the n = 8 / E8 statement (B10c) not searched |
| B11: Furey's axes = Lagrangian of Q_Cl(0,8) (Hamming [8,4,4]) | Wood section 5 [S2.6]; Nebe-Rains-Sloane [S2.6] | Same criterion (doubly-even self-dual = isotropic and self-dual); the Furey/[8,4,4] application not searched |
| B13: Gauss-Milgram phase of the E_n discriminant form = signature mod 8 | Taylor: Milgram formula beta(psi_L) = sigma(B)/8 [S2.4]; van der Blij [S2.9] | Same theorem |

### 2.2 Which sources state something equivalent to "the clock of Cl(p,q) is the Brown invariant of w = pi + 2Q on the labels"?

None of the pages I opened states it in those words. The ladder of near-equivalents:
1. Same labels, same sign function, same Q: [S1.15] Prop. 2.1, [S1.16] f and alpha, [S1.17] q_{p,q}. (Q(a) = [e_a^2 = -1] = C(|a|,2) + |a & Q-bits| mod 2.)
2. The F_2-valued form and its three-valued Arf invariant classify Cl_{p,q} by p-q+1 mod 8 and the parity of N: [S1.17] Thm. 14, Cor. 15. Own check (scratchpad script, n <= 8, all p+q = n, 2026-10-10): sum_a (-1)^{Q(a)} = Re S + Im S = 2^{n/2}(cos t + sin t), t = pi(p-q)/4, where S = sum_a i^{w(a)} = (1+i)^p (1-i)^q (Re S = even blades, Im S = odd blades). So the Arf of [S1.17] is the real shadow (Re S + Im S) of the Atlas's complex sum. Arf plus the parity of N fixes the algebra type; the phase of S fixes p-q mod 8 itself, because the Z_4 lift keeps Re S and Im S apart (own reading).
3. The Z_4 lift and its Gauss sum: B1 is Brown's law [S2.4] and Kirby-Taylor Def. 3.1 [S2.5]; the phase of the Gauss sum is Brown's invariant [S2.4, S2.5].
4. The all-positive cell is Wood's example: own check (n <= 8): for Cl(n,0), w(a) = |a| mod 4 on every blade, exactly Wood's "Q(u) = wt(u) mod 4", whose Brown invariant is n mod 8 [S2.6]. With Brown's additivity over orthogonal sums (Kirby-Taylor: beta "induces an isomorphism between Witt equivalence classes of quadratic forms and Z/8Z" [S2.5]) and core B2, which makes (V,w) the sum of p copies of <+1> and q copies of <-1>, Cl(p,q) gives p-q (own reading).
5. van der Blij-type congruence (own derivation): the characteristic element of the dot product on F_2^n is the all-ones vector, the top blade; by core B2 (local) w(top) = p-q mod 4, which is Taylor's "2 beta(psi) = psi(omega)" [S2.4].
6. The two Z_8's are linked only in words: BW(R) = Z/8 [S2.3] and ABS period 8 [S2.2]; Debray-Gunningham Remark 5.3 ties the Z/8 of the Arf-Brown theory to "the 8-fold periodicity of Morita equivalence classes of real Clifford algebras", with ZAB(pt) = Cl_1 [S2.7]; Fidkowski-Kitaev Z -> Z_8 [S2.8]; Pin+-(V) inside Cl+-(V) [S2.5].

Not found: a source that writes the Brown invariant of (the Z_2-span of the blades, pi + 2Q) as the class of Cl(p,q) in BW(R) = Z/8, nor the 2^r rule for null generators (core B3, r = 1, 2).

## 3. Gravity computed in Clifford / geometric algebra, and by computer algebra

Closest matches in spirit to the Atlas's gravity scripts, in order: the Cadabra Schwarzschild notebook (two Riemann routes), the Mathematica CARTAN notebook (tetrad Schwarzschild/Kerr checks, Bianchi identity), the SageManifolds notebook (nabla g = 0 check), the galgebra Christoffel example (no comparison), then the analytic GA papers. None runs a GA engine against an independent route with wrong-version controls.
For each source: what it computes | computes twice (engine + independent route)? | exact arithmetic?

### 3.1 Geometric-algebra gravity (analytic literature)

**[S3.1] Lasenby-Doran-Gull, "Gravity, gauge theories and geometric algebra" (Phil. Trans. R. Soc. A 356, 487-582, 1998), arXiv:gr-qc/0405033**
- URLs: https://arxiv.org/abs/gr-qc/0405033 ; https://arxiv.org/pdf/gr-qc/0405033 (x2; text returned covers sections 1-4.5) ; https://geometry.mrao.cam.ac.uk/?p=170 (o:2026-10-10, all three).
- Computes: gauge theory gravity (GTG); "A gauge is found which reduces the physics to a set of essentially Newtonian equations"; "The Dirac equation is studied in a black hole background and provides a quick derivation of the Hawking temperature"; "This alters the physical picture of the properties of a horizon around a black hole." Section 4.3: `H(a) = h-bar(grad ^ h-bar^{-1}(a))` (4.49; overdots mark that the derivative acts on h-bar^{-1}, garbled in the extraction) and the torsion-free connection in closed form `omega(a) = -H(a) + 1/2 a . (d_b ^ H(b))` (4.53, quoted x2); section 4.2, eq. (4.36): `G(a) - Lambda a = kappa T(a)`.
- Twice: no second route stated in the text read. Exact: analytic (hand derivation); no computer algebra or code link mentioned.

**[S3.2] Doran-Lasenby, Geometric Algebra for Physicists (CUP 2003), contents**
- URL: https://assets.cambridge.org/97805214/80222/toc/9780521480222_toc.pdf (o:2026-10-10).
- Ch. 13 "Symmetry and gauge theory" (13.4 gauge principles for gravitation, 13.5 gravitational field equations, 13.6 Riemann tensor); Ch. 14 "Gravitation" (14.1 solving the field equations, 14.2 spherically-symmetric systems, 14.3 Schwarzschild black holes, 14.4 quantum mechanics in a black hole background, 14.5 cosmology, 14.6-14.7 cylindrical and axial symmetry). No computing section. Twice: not indicated. Exact: analytic.

**[S3.3] Hestenes, "Gauge theory gravity with geometric calculus", Found. Phys. 35 (2005)**
- URL: https://davidhestenes.net/geocalc/pdf/GTG.w.GC.FP.pdf (o:2026-10-10).
- Einstein's equation as G(a) = kappa T(a) in geometric calculus; Riemann curvature as a bivector-valued function built from the connexion bivector; the gauge tensor h determines the connexion; Schwarzschild: the black-hole curvature in compact form, the standard gauge tensor and two alternative gauges, Kerr-Schild and "Newtonian"; Mercury's perihelion (extractor summary). Twice: no. Exact: coordinate-free hand calculation; no computer algebra mentioned.

**[S3.4] Francis-Kosowsky, "Geometric algebra techniques for general relativity" (Ann. Phys. 311, 2004), arXiv:gr-qc/0311007**
- URLs: https://arxiv.org/abs/gr-qc/0311007 and https://ar5iv.labs.arxiv.org/html/gr-qc/0311007 (o:2026-10-10, both; the text read ends in section II).
- "We focus our attention on orthonormal frames and the associated connection bivector"; eq. (8) `Gamma_a(e_mu, e_nu) = Omega(a) . (e_mu ^ e_nu)`; derives Schwarzschild and Kerr and the Petrov types. Twice: no. Exact: analytic; none of "Mathematica, Maple, computer, symbolic, package, program, code, verify, check" occurs in the part read.

**[S3.5] Snygg**
- Clifford Algebra: A Computational Tool for Physicists (OUP 1997), https://academic.oup.com/book/52803 (o:2026-10-10): the page calls Clifford algebra "an indispensable tool for physicists" and does not confirm any general-relativity content.
- A New Approach to Differential Geometry using Clifford's Geometric Algebra (Birkhauser 2012), https://link.springer.com/book/10.1007/978-0-8176-8283-5 (o:2026-10-10): "Presents a significant portion of general relativity without reference to such Newtonian terms as 'force', 'momentum', or 'energy'"; no software mentioned. Twice: not indicated.

**[S3.6] Horizons and waves in GTG; the Hsu-Barker-Hobson-Lasenby item**
- Setiawan, arXiv:physics/0412070, https://arxiv.org/abs/physics/0412070 (o:2026-10-10): Unruh effect, Dirac and Klein-Gordon equations in de Sitter, Rindler, spherically and axially symmetric black holes, "We rederive the Hawking temperature for all cases".
- Lasenby, arXiv:1912.05960, https://arxiv.org/abs/1912.05960 (o:2026-10-10): "noting the simplicity that GA affords in both writing the solutions, and checking some of their properties"; preferred gauge for plane waves (Brinkmann).
- Banon Perez-DeKieviet, arXiv:2404.19682, https://arxiv.org/abs/2404.19682 (o:2026-10-10): step-by-step GA general relativity, no software mentioned. Trindade-Pinto-Floquet, arXiv:1807.09587, https://arxiv.org/pdf/1807.09587v1 (o:2026-10-10): Cl(1,3) and Cl(0,6) building on Lasenby-Doran-Gull, Dirac equation in a Schwarzschild background. All analytic; none states a second route.
- **Hsu-Barker-Hobson-Lasenby on horizons: not located.** Five searches (author names with horizon / gauge theory gravity / Poincare gauge / geometric algebra) and the arXiv author list https://arxiv.org/a/barker_w_1 (o:2026-10-10: 24 papers, 7 with Hobson and/or Lasenby, no Hsu, none on horizons plus geometric algebra) found nothing, so it cannot be cited from here.

### 3.2 Computer-algebra implementations

**[S3.7] GAlgebra**
- https://galgebra.readthedocs.io/en/latest/generated/galgebra.metric.html (o:2026-10-10): `Metric.Christoffel_symbols(mode=1)` ("Christoffel symbols of the first kind", mode 2 the second kind); no curvature, Riemann or Ricci functions listed in that module.
- https://github.com/pygae/galgebra/blob/v0.5.2/examples/LaTeX/colored_christoffel_symbols.py (o:2026-10-10): Christoffel symbols of the unit sphere embedded in 3D (`g3.sm(...)`, `Christoffel_symbols(mode=1)` and `mode=2`, `sp2.grad`); no comparison with an independent route. Twice: no. Exact: symbolic (SymPy).
- https://galgebra.readthedocs.io/en/latest/module-components.html (o:2026-10-10): no text on curvature, Riemann, Ricci, Einstein or Schwarzschild (the page says it "may no longer reflect the current state of the library"). So the "GAlgebra curvature examples" were not found; only Christoffel symbols and gradients on manifolds.

**[S3.8] clifford and kingdon:** no gravity or curvature example found in the documentation pages and papers opened ([S1.4], [S1.6]); one search for a clifford/SymPy general-relativity notebook returned none.

**[S3.9] Mathematica GA package:** Aragon-Camarasa et al., "Clifford Algebra with Mathematica", arXiv:0810.2412, https://arxiv.org/abs/0810.2412 (o:2026-10-10): clifford.m, 3D visualisation; the page "does not discuss any application to gravity".

**[S3.10] The Christoffel route in tensor computer algebra (the "independent route" tools)**
- Cadabra notebook, https://cadabra.science/notebooks/schwarzschild.html (o:2026-10-10): Christoffel symbols -> Riemann by two routes ("a second route that expands the Riemann tensor fully in terms of the metric first") -> Ricci = 0, Kretschmann K = 48M^2/r^6.
- SageManifolds notebook (Megias, Ruiz-Lorenzo), https://landau.unex.es/~sphinx/juan/GC/DiffGeo_d2.pdf (o:2026-10-10): inverse metric, Christoffel, Riemann, Ricci, Einstein, Kretschmann and a check of "nabla g = 0", on a 2D polar metric.
- EinsteinPy, https://einsteinpy-rtd.readthedocs.io/en/stable/api/symbolic/ricci.html (o:2026-10-10): `RicciTensor` from Riemann, Christoffel or metric (SymPy). pystein, https://pystein.readthedocs.io/en/latest/api/pystein.curvature.html (o:2026-10-10): `christoffel_symbol_component`, `riemann_tensor_component`, `ricci_tensor_component`, `ricci_scalar`, `einstein_tensor_component` (SymPy). xAct, http://www.xact.es/ (o:2026-10-10): "a suite of free packages for tensor computer algebra in the Wolfram Language" (xTensor, xCoba, xPert, xTerior for exterior calculus).
- Soleng, Mathematica CARTAN notebook, https://publ.nr.no/rask/old/cartan.nb.pdf (o:2026-10-10): Schwarzschild with a tetrad (Ricci-flat, Kretschmann 48M^2/r^6), flat FLRW "checking the Bianchi identity", Kerr "verifying the vacuum equations". Survey: Birkandan et al., arXiv:1703.09738, https://arxiv.org/abs/1703.09738 (o:2026-10-10): SageManifolds, Maxima/ctensor, Python/GraviPy; none Clifford-based.
- Twice: Cadabra's two Riemann routes and the CARTAN checks sit inside one CAS from the same metric; no wrong-version controls are described on the pages. Exact: yes (symbolic).

**[S3.11] First-order (Cartan) forms, (A)dS, and the random-testing lemma**
- Kummer-Schutz, arXiv:gr-qc/0410017, https://ar5iv.arxiv.org/html/gr-qc/0410017 (o:2026-10-10): Hilbert-Palatini action `S = (1/2) int R^{AB} ^ e^C ^ e^D epsilon_{ABCD}` (eq. 1); Einstein equations as a 3-form with the hat operator `F-hat_{AB} = (1/2) epsilon_{ABCD} F^{CD}` (eqs. 5, 8); varying omega gives the torsion relation (eq. 10); surface terms neglected.
- Wise, "MacDowell-Mansouri gravity and Cartan geometry", arXiv:gr-qc/0611154, https://arxiv.org/abs/gr-qc/0611154 (o:2026-10-10): Cartan geometry with Minkowski, de Sitter and anti-de Sitter model spacetimes (the page does not mention the cosmological constant or SO(4,1)).
- Schwartz-Zippel, https://rjlipton.com/2009/11/30/the-curious-history-of-the-schwartz-zippel-lemma/ (o:2026-10-10): probability <= d/|S| for a nonzero polynomial of total degree d; Schwartz 1980, Zippel 1979, DeMillo-Lipton 1978. No source found that applies it to gravity or tensor identities (one search).

### 3.3 Rigid bodies in PGA (the Atlas's forque_gunn_check)

**[S3.12] Gunn, "Projective geometric algebra: a new framework for doing Euclidean geometry", arXiv:1901.05873**
- URLs: https://arxiv.org/abs/1901.05873 and https://arxiv.org/pdf/1901.05873 (o:2026-10-10, both; section 7).
- "When one applies this framework to calculating the motion of the free top one obtains the following Euler equations of motion: `g-dot = g Omega_c`, `Omega_c-dot = 2 A^{-1}(A(Omega_c) x Omega_c)`", A the inertia tensor; "Normalizing the computed rotor g brings one directly back to the solution space"; the abstract lists "native support for automatic differentiation". Twice: no independent check described in the part read. Exact: not stated.

**[S3.13] Dorst and De Keninck, "May the Forque Be with You!", n-dimensional rigid body dynamics in PGA**
- URL: https://bivector.net/PGADYN.html (o:2026-10-10).
- "we apply the lessons from PGA to the problem of Rigid Body Dynamics", "valid in any number of dimensions", "unifies linear and angular aspects completely", open-source ganja.js examples; no validation described on the page (the PDF returned binary data). Twice: not stated. Exact: not stated.

**[S3.14] Gunn, PhD thesis (TU Berlin 2011), "Geometry, Kinematics, and Rigid Body Mechanics in Cayley-Klein Geometries"**
- URL: https://www.doi.org/10.14279/DEPOSITONCE-3058 -> https://depositonce.tu-berlin.de/items/12ff6379-bed1-451f-a2d6-0483bec32619 (o:2026-10-10; abstract only).
- Geometries "realized as real Clifford algebras constructed on the dual projectivized Grassmann algebras", the inertia tensor "represented as a separate Clifford algebra", Euler equations from energy and momentum conservation. Li and Ding (eqs. 7-13, named in the Atlas README): paper not located (one search). Context: https://en.wikipedia.org/wiki/Plane-based_geometric_algebra (o:2026-10-10) mentions rigid body dynamics only briefly and calls the thesis a "master's thesis", whereas DepositOnce says doctoral.

### 3.4 Table: Atlas gravity feature -> closest prior art -> same / different

| Atlas feature (script) | Closest prior art | Same / different |
|---|---|---|
| Torsion-free connection as an explicit function of the frame: omega(e) = inverse of the torsion map, T = 0 (a3_closed_form, gravity_new_checks) | Lasenby-Doran-Gull (4.49)/(4.53) [S3.1]; Hestenes [S3.3]; Francis-Kosowsky eqs. (8)-(9) [S3.4] | Same statement (closed-form omega from the tetrad). Different: all n = 2..8, exact, random polynomial frames, and a second route (tetrad postulate / Christoffel); none of the GA papers read reports a second route |
| Einstein form E_a = s_n (G - Lambda_n) Theta for any frame (a4_einstein_tensor) | Kummer-Schutz eqs. (1), (5), (8) [S3.11]; LDG (4.36) [S3.1] | Same equation in forms/GA language. Different: general n, E_a compared with Riemann by two exact routes |
| First variation of the Einstein-Cartan action as an exact polynomial identity dL = de^E + domega^Theta + d(domega^Y) (b1_first_variation) | Kummer-Schutz: variation in e and omega, "surface terms neglected" [S3.11] | Same variation. Different: the boundary term is kept and checked exactly on random jets; no machine-checked prior version found |
| Newtonian limit from E_0, Phi_t = Phi_s, free fall (d1_newtonian_limit) | LDG abstract "essentially Newtonian equations" [S3.1]; Hestenes "Newtonian" gauge [S3.3] | Same result; the Atlas derives it inside the engine and compares with the linearised Riemann and the geodesic |
| Sign chain of the extra generator k = -s in seven places; k = I^2 (h3_sign_chain, h3_pseudoscalar) | Wise: dS/AdS/Minkowski model spacetimes [S3.11]; LDG (4.36) cosmological term [S3.1] | Same physics ((A)dS extension <-> cosmological term). The statement "k = I^2 at n = 4 in both conventions": no source found |
| Birkhoff in the radial Kerr-Schild class, f = M/rho + (c/2) rho^2 (c1_birkhoff) | Hestenes: Schwarzschild in Kerr-Schild and Newtonian gauges [S3.3] | Same family (Schwarzschild-(A)dS in KS form). The uniqueness statement as a scripted exact computation: no prior art located (Birkhoff's theorem itself not opened) |
| E_a = 0 on the KS Schwarzschild frame inside, on and outside r = 2M (gravity_new_checks) | Cadabra and CARTAN Schwarzschild notebooks [S3.10] | Same check type (Ricci-flat Schwarzschild, K = 48M^2/r^6). Different: engine + Christoffel route, frame regular across the horizon; the notebooks use one CAS and metric components |
| Exact plane wave; Schwarzschild-(A)dS cosmological term; surface gravity 1/(4M) from the solved omega (gravity_moves) | Lasenby 2019 [S3.6]; Setiawan and LDG (Hawking temperature) [S3.6, S3.1] | Same results; different method (exact engine vs Christoffel/Kretschmann) |
| Free top: Gunn and Li-Ding equations as exact series in t (forque_gunn_check) | Gunn section 7 [S3.12]; Gunn thesis [S3.14]; Dorst-De Keninck [S3.13] | Same equations. The exact-series comparison with the step-14 body was not found in the pages read; Li-Ding paper not located |
| Two-route discipline: [bit] vs [std] with [ctl] controls, fixed-seed random polynomial jets, Schwartz-Zippel bound, Fractions | Cadabra two-Riemann-routes notebook [S3.10]; Schwartz-Zippel lemma [S3.11] | The components exist separately; the combination (engine vs independent route with controls, in GA/GR) was not found in any source opened |

## 4. Labelling by other bases

**Prime (Godel-style) labelling of basis elements.**
- Concept: https://en.wikipedia.org/wiki/G%C3%B6del_numbering (o:2026-10-10): "the Godel encoding of the sequence is the product of the first n primes raised to their corresponding values"; unique factorisation recovers the sequence; 1931.
- Physics instance that is exactly a prime labelling of fermionic basis states, the primon gas: https://en.wikipedia.org/wiki/Primon_gas (o:2026-10-10): Hilbert space basis "labelled by the prime numbers p"; "the Pauli exclusion principle prohibits multi-particle states which include squares of primes"; "the Mobius function is positive for bosons, negative for fermions, and zero on exclusion-principle-prohibited states". Julia, "Statistical theory of numbers" (Springer Proc. Phys. 47, 1990, pp. 276-293), https://empslocal.ex.ac.uk/people/staff/mrwatkin/zeta/Julia.htm (o:2026-10-10): primes as "partons" with energy log p; fermions give |mu(n)|. Spector, "Supersymmetry and the Mobius inversion function", Commun. Math. Phys. 127 (1990) 239-252, https://empslocal.ex.ac.uk/people/staff/mrwatkin/zeta/spector1.htm (o:2026-10-10): "the Mobius inversion function ... can be interpreted as the operator (-1)^F".
- Anderson, "Notes on fermionic Fock space for number theorists", https://swc-math.github.io/aws/2000/00AndersonN.pdf (o:2026-10-10): exterior algebra basis `e_I` indexed by finite subsets, Clifford algebra C(E,q), the anticommutation relations (no primes in the excerpt read).
- In computer-algebra or GA software: none found; every implementation in section 1 labels blades by bitmaps, sorted index sets or tuples. Own remark, not sourced: with squarefree labels the XOR becomes n*m/gcd(n,m)^2 and the bit mask becomes the set of prime divisors, so the Atlas bit mask and the Julia-Spector dictionary are the same bijection. One search for "the group of squarefree integers" found a Reading paper that I could not open (bot wall).

**Base 3: signature words and metric arrays.**
- Standard and ternary per generator: `Cl(p,q,r)` / `sig` lists in clifford [S1.4], `Algebra(p,q,r)` in ganja.js and kingdon [S1.5, S1.6], "elements constrained to be equal to +1, 0, or -1" in CliffordNumbers.jl [S1.12], Gram matrices in Sage and OSCAR [S1.13]. None treats the signature word, or the blade labels, as a base-3 numeral, and I found no source indexing the algebras Cl(p,q,r) by a ternary integer.
- A genuine base-N analogue of the bit rule is the generalized Clifford algebra with generators `e_j^{N_j} = 1` and `e_j e_k = omega_jk e_k e_j` (roots of unity): Jagannathan, arXiv:1005.4300, https://ar5iv.arxiv.org/html/1005.4300 (o:2026-10-10; relations read, the N^n-dimensional monomial basis was not in the text returned). Categorical treatment: Cheng-Huang-Yang, arXiv:1510.04408, https://arxiv.org/abs/1510.04408 (o:2026-10-10; abstract only).

**Gray-code orderings of blades.**
- None found for Clifford/GA blades. Orderings actually used: grade then lexicographic (ganja.js README "grouped by rank and numerically sorted" [S1.5]; kingdon [S1.6]), increasing binary integer (OSCAR [S1.13]; clifford's `BasisBladeOrder` [S1.4]), grade order (Antanovskii [S1.14]).
- A Gray-code ordering of basis states does appear in quantum simulation: Di Matteo et al., "Improving Hamiltonian encodings with the Gray code", arXiv:2008.05012, https://arxiv.org/abs/2008.05012 (o:2026-10-10): "a Hamiltonian that acts on the basis states in Gray code order", fewer qubits, shallower circuits. That is prior art for Gray-labelled basis states, not for blades. A search combining "Gray code" with Clifford/GA basis ordering returned only hypercube and Gray-code surveys (not opened).

## 5. Verdict in ten lines

(URLs as in sections 1-4; all opened 2026-10-10.)
1. Standard: "blades as bit masks, product by XOR, sign = reordering parity x metric of shared bits" is the textbook implementation: DFM reference code (geometricalgebra.org/ga_ref_impl/subspace/basis/BasisBlade.java.html), clifford (clifford.readthedocs.io/en/latest/_modules/clifford/_layout_helpers.html), ganja.js bit path, kingdon, Garamon, GluCat, OSCAR; index-set versions with the same rule in galgebra, Sage, Antanovskii.
2. The cocycle is printed in the literature: F(x,y) = (-1)^{sum_{j<i} x_i y_j} prod q_i^{x_i y_i} (Albuquerque-Majid Prop. 2.1, arxiv.org/abs/math/0011040) and f(x,y) in Ovsienko Prop. 3.1 (arxiv.org/abs/1601.07664); the Atlas's Q is Ovsienko's alpha.
3. Standard too: null generators as bits with eps = 0 (ganja.js, kingdon, clifford Cl(p,q,r), CliffordNumbers.jl, Gunn's thesis; Fontijne's 2007 thesis still avoided them), exact coefficients (Sage/OSCAR over QQ, galgebra/kingdon with SymPy), and the Jordan-Wigner/Fock reading (Bravyi-Kitaev eq. 24, Albuquerque-Majid spinors by left/right multiplication, Debray-Gunningham Cl_{n,n}); only "differential forms as null bits inside the GR engine" had no GA-package precedent in what I opened.
4. Known results in an unusual language: w = pi + 2Q is Brown's Z_4 law (Brown; Kirby-Taylor Def. 3.1, webhomes.maths.ed.ac.uk/~v1ranick/papers/kirbytaylorpin.pdf); B3 is the Brown/Gauss-sum phase; for Cl(n,0) w is exactly Wood's weight-mod-4 form with a(Q) = n mod 8; B6c/B18 is Wood's classification theorem; B11 is Wood's doubly-even-self-dual = isotropic criterion; B13 is Milgram/van der Blij (webhomes.maths.ed.ac.uk/~v1ranick/papers/woodj.pdf, taylorg.pdf).
5. The F_2 shadow is published: Elduque-Rodrigo-Escudero Thm. 14/Cor. 15 (arxiv.org/abs/1801.07002) classify Cl_{p,q} by the three-valued Arf invariant of the same form (with the parity of N), which is Re S + Im S of the Atlas sum (own check); the phase of the Z_4 sum is what gives p-q mod 8 itself.
6. Not found stated anywhere I opened: the label-level identity "sum of i^{pi+2Q} over the blades = (1+i)^p (1-i)^q, hence class of Cl(p,q) in BW(R) = Z/8 = Brown invariant of the labels", with the 2^r rule for null bits. The two Z_8's are linked only in words (Debray-Gunningham Remark 5.3, adebray.github.io/papers/arf_brown.pdf; Fidkowski-Kitaev; ABS Prop. 4.2): this bridge is the Atlas's own as far as the web shows, as an explicit computation, not as a new theorem.
7. Gravity: the statements I could map each have a published counterpart: closed-form omega(h) (LDG 4.53, arxiv.org/pdf/gr-qc/0405033), the Einstein 3-form (Kummer-Schutz eq. 8, ar5iv.arxiv.org/html/gr-qc/0410017), Newtonian and Kerr-Schild gauges (Hestenes 2005, davidhestenes.net/geocalc/pdf/GTG.w.GC.FP.pdf), Hawking temperature in GTG (Setiawan, arxiv.org/abs/physics/0412070), Gunn's free-top Euler equations (arxiv.org/abs/1901.05873). Not mapped to any source: "k = I^2", the radial Kerr-Schild uniqueness as a scripted computation, the exact-series free-top comparison.
8. The GA gravity papers I could read are analytic and report no second route; computer-algebra work (Cadabra, SageManifolds, CARTAN, EinsteinPy, xAct) is Christoffel-route, exact, one CAS, no wrong-version controls (cadabra.science/notebooks/schwarzschild.html has two Riemann routes). Engine-vs-independent-route with [ctl] controls, n = 2..8, fixed-seed polynomial jets and a Schwartz-Zippel bound was not found anywhere: that discipline, not the bit rule, is what the web does not show.
9. Prime, base-3 and Gray labellings: prime labelling exists as physics (primon gas, Julia/Spector 1990: primes = fermionic modes, squarefree n = states) and as Godel numbering, never as a blade labelling in software; ternary signature arrays are universal but not used as numerals; generalized Clifford algebras are the base-N cousin; Gray-coded basis states exist only in qubit encodings (arxiv.org/abs/2008.05012); none found for blades.
10. Worth citing (I read three Atlas files only and did not audit its reference list; its README already names Gunn arXiv:1901.05873 and Li-Ding): Albuquerque-Majid 2002, Ovsienko 2016, Elduque-Rodrigo-Escudero 2018, Brown 1972, Kirby-Taylor 1990, Wood 1993, Debray-Gunningham 2018, Fidkowski-Kitaev 2010, ABS 1964, Dorst-Fontijne-Mann 2007 and Fontijne 2007 for the bitmap rule, Lasenby-Doran-Gull 1998 and Hestenes 2005 for gravity, Julia/Spector 1990 for any prime-label remark.
