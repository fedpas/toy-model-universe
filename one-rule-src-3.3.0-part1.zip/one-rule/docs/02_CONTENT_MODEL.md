# 02 — Content model

All content lives in `content/` as JSON (one file per table; arrays of records; UTF-8; stable ids; sorted by id on write so diffs are readable). The app never reads v15 modules; a build step turns `content/` into per-page chunks (`08_BUILD_TEST.md`). The tables below are the whole model. Field names are final; add fields only with a schema change and a migration note.

## 1. `rows.json` — the statements

```jsonc
{
  "id": "GRV-012",                      // stable; v15 ids kept; new rows: "<GROUP>-<3 digits>" above the v15 range, candidates "CAND-<3 digits>"
  "group": "GRV",                       // v15 group code (28 groups) — kept for the register, not used for layout
  "kind": "theorem",                    // mathematician's kind: definition|construction|lemma|theorem|range|classification|invariant|example|counterexample|computation|reduction|reading|conjecture|question|dead-end|pointer|meta
  "stage": "D",                         // physicist's stage: A algebra | K kinematics | F fields | D dynamics | O observation | M method
  "ptype": "solution",                  // physicist's type: postulate|definition|derivation|identity|solution|limit|symmetry|observable|calibration|reading|open|negative
  "phenomena": ["gravity","black-hole"],// physicist's phenomena (0..n)
  "fields": ["geometry","analysis"],    // mathematician's fields (0..n): algebra|geometry|topology|category|combinatorics|analysis
  "cells": ["(1,3,0)"],                 // the algebra cell(s) the statement is about; "all n", "row 8", "(p,q,1)" allowed; [] if none
  "notions": ["cnx","sol","s-geo","i-chart","i-act"],   // the label: subset of the 29 notion codes (04_LABELLING.md)
  "homePhys": "Birkhoff's theorem",     // the name physics gives it, or ""
  "homeMath": "uniqueness of spherically symmetric vacuum solutions", // the name mathematics gives it, or ""
  "standardRef": "…",                   // v15 standardRef, verbatim (author and title; the author's read/unread note kept)
  "evidence": [                         // what proves it here (see §5); [] allowed
    {"check": "C1", "script": "selfcheck/gravity/c1_birkhoff.py", "mode": "ran"},
    {"check": "gravity_new_checks", "script": "selfcheck/gravity/gravity_new_checks.py", "mode": "ran"}
  ],
  "depends": [                          // logical relations (04_LABELLING.md §4)
    {"id": "GRV-010", "rel": "derives"}, {"id": "INP-056", "rel": "uses-input"}, {"id": "T18", "rel": "instance"}
  ],
  "links": ["L5", "S3-schuller"],       // translation-matrix row uids and report finding ids (kept from v15 `links`)
  "lensTags": ["CLF","GRV"],            // v15 lens codes (kept; informational)
  "shownOn": [{"page": "steps/grav2", "section": "solutions", "order": 3, "role": "result"}],  // where it renders; a row may render in several places
  "visibleTo": ["phys","math"],         // modes in which it renders (both by default)
  "legacyFlags": ["standard","checked","input"],  // v15 flags, kept read-only for the register and for migration tests
  "legacyLines": 2,                     // number of v15 lines merged into this row's texts
  "since": "v15",                       // "v15" | "v16" | "v2.1" | "v2.2" | "v2.4" | "v2.4.2" | "v2.4.3" | "v2.5" | "v2.6" | "v2.7" | "v2.8" | "v2.9" | "v2.10" | "v2.11" | "v2.12" | "v2.13" | "v2.14" | "v2.15" (the release that added the row; the badge "new" follows it: from 2.15.0 "new" is the latest release only, A60 — before, D22's range v16 … v2.14)
  "status": null                        // computed at build; never stored by hand (see §4)
}
```

Rules: `id` unique; `notions` non-empty for every row except `kind = meta` rows which carry exactly `["i-meta"]`; `shownOn` non-empty for every row that is not `meta` or `candidate`; every `depends.id` exists (a row, a theorem `T1`–`T20`, or a question id); `evidence.check` exists in `checks.json`.

**Splitting v15 rows.** A v15 row has one to several *lines* (theorem line, reading line, learner line …). In V2 each line that states something different becomes its own row (`GRV-012` stays for the first line; further lines become `GRV-012b`, `GRV-012c` … with `since: "v15"` and a `depends` of kind `equiv` or `derives` to the first). Lines that are the same statement in plain words become learner *texts* of the same row, not new rows. The migration script does the mechanical part (`03_MIGRATION.md` §2); the author reviews the split in the register.

## 2. `texts.json` — the words

```jsonc
{
  "row": "GRV-012",
  "lang": "en",                         // only "en" at launch; the field exists so a language is a dimension, not a fork
  "mode": "both",                       // both | phys | math
  "level": "research",                  // research | learner
  "lens": null,                         // null = the Atlas's own words; else a lens key
  "register": "full",                   // full | short (one line, for cards and heroes) | caption (for a figure) | span (one statement inside a chain's story, with `chain` and `span`: §11.2)
  "body": "In the radial Kerr–Schild class the Einstein form vanishes only for f = M/ρ + (c/2)ρ²: Schwarzschild and Schwarzschild–(anti-)de Sitter.",
  "status": "human",                    // human (the author's words) | draft (a model's words, not yet reviewed) | reviewed (a model's words the author accepted)
  "source": "gravityCopy.js#GRAV2.points[4][1]"   // where the words come from (a v15 locator, a lead's RESULT.md, "translator:<persona>@<date>", or "pass<k>:<name>" for the research draft of a row a proofs pass adds, "pass<k><part>:<name>" when the pass runs in parts, as pass8a and pass8b)
}
```

Formulas inside `body` use the author's inline notation (`Cl(1,3)`, `E_a`, `ρ²`, `e₁₂₃`) and `$…$` for KaTeX where needed; learner texts contain no `$`, no `=` with symbols, no Greek letters used as variables (a build test enforces this).

**Lookup order** (the only fallback the app performs): `(lang, mode, level, lens)` → `(lang, both, level, lens)` → `(lang, mode, level, null)` → `(lang, both, level, null)`. If nothing is found: research level renders the row in the Atlas's own words with a drawer note "no <lens> reading yet"; learner level does not render the row at all and the page's coverage report counts it. Inside a chain at learner level the span of (row, chain) comes first, through the same order, then the row's learner `full` text (D54, §11.2).

**The key** of a text record is (row, lang, level, mode, lens, register), and a span's chain (§11.2): a record without `chain` keys as it always did.

## 3. `lenses.json` — the registry of ways of looking

```jsonc
{
  "key": "cat",
  "name": "Category theory",
  "kind": "branch",                     // branch | shape | researcher | labels | convention
  "short": "category",
  "describes": "monoidal and super categories, Morita classes, Frobenius algebras, nerves",
  "ordering": "kind",                   // how rows reorder inside a section under this lens: none | kind | stage | grade | custom:<fn>
  "dictionary": [                       // the atlas element → the lens term (from reports/lens_dictionary.json + the readings)
    {"atlas": "clock c = p − q mod 8", "term": "Brauer–Wall class; central charge of Sem^p ⊠ Sem̄^q", "match": "exact", "evidence": ["bd·cat·9"], "rows": ["LAB-017","LAB-018"]}
  ],
  "matrixColumn": "category",           // key of the translation-matrix source whose rows this lens explains, or null
  "figures": ["cube-category","sign-flux"],  // figure ids this lens can redraw
  "translator": "persona:cat",          // id of the translation persona (09_TRANSLATION_PROTOCOL.md) or null
  "conventions": {}                     // for convention lenses: {"spaceSquare": "+1"|"-1", "time": "first"|"last", "signature": "(1,3)"|"(3,1)"}
}
```

Launch registry (keys): `alg geo top cat comb` (branches); `clifford simplex cube prime orthoplex demicube gosset` (shapes); `furey baez schuller hestenes pga roelfs tian majkic pumplun hbhl atiyah` (researchers; `atiyah` is built from Atiyah's Collected Works vol. 7 and Hitchin's account, `docs/round8/ATIYAH.md`); `bits primes sigword bitsq` (labels); `space-plus time-plus cl13 cl31` (conventions). Dictionaries: branches and the six languages come from `reports/lens_dictionary.json` (80 rows × up to 6 terms) and the 982 reading rows; researchers from the three translation matrices and the report dictionaries (`matrix/analyses_dictionaries.json` has them keyed by source).

## 4. Status — computed, never typed

Inputs: the row's `notions`, `evidence`, `kind`, `ptype`, `since`, and `checks.json` (which checks ran and passed in the last recorded run). Algorithm (the same as `labelling/merge_labels.py`, which is the reference implementation):

```
p = #notions with square +1; q = #notions with square −1; r = #notions with square 0
if kind == meta or notions == ["i-meta"]:            status = meta
elif kind in {question, conjecture, dead-end, pointer} or ptype == open:   status = open
elif row is a candidate (id starts with CAND-):      status = proved-by-atlas if a ran check passed, else candidate
elif evidence has an entry with mode "ran" whose check passed in the last run:   status = proved-by-atlas
elif evidence names a script or source with mode "read" only:                   status = cited      # "not yet proved by the Atlas"
elif kind == reading or ptype == reading:            status = ours
elif r > 0 and the row is an input (group INP) :      status = input
elif q > 0 and a standardRef was read:               status = standard
else:                                                status = ours
new = (since == latest release) or (a text of the row has status draft/reviewed newer than the previous release)
```

Notes: `input` rows (the 94 of group INP, plus any row whose only content is a choice) carry a badge naming the kind of input; rows that *use* inputs but are proved keep `proved-by-atlas` and show the inputs in the drawer, not as a badge. `cited` is the v15 "checked, script read" case the author asked to flag as not yet proved. `proved-by-atlas` requires a check that **passed in the recorded run** (`checks.json.lastRun`); a failing or missing run demotes the row to `cited` automatically.

## 5. `checks.json` and `check_runs.json` — the evidence

`checks.json` (seeded from `matrix/checks.json`): one record per script with `family`, `script`, `ids` (check ids with their one-line statements where the script prints them), `method`, `independentRoute`, `controls`, `deps`, `storedResult` (the `selfcheck/*.json` file), `rowsNaming` (row ids whose evidence names it). `check_runs.json`: one record per run of a script: `script`, `date`, `machine` (free text, no paths), `ok`, `fail`, `lastLine`, `passed` (bool), `ids` (per-id pass/fail when the script prints ids). The build computes `lastRun` per script. V2 ships with the author's shipped logs imported as the first run (gravity `logs/SUMMARY.txt`; bridges stored json; core 28/28; T-scripts and page scripts as re-run on 10 Oct 2026).

## 6. `figures.json` — drawings that state something

```jsonc
{
  "id": "clock-wheel",
  "engine": "engines/labels.js#clockWheel",   // module#function of the ported engine
  "params": {"nMax": 8},                      // defaults; the figure may expose controls
  "inputs": ["content/data/core.json#B3"],    // stored results it reads (never computed numbers typed in)
  "captionRow": "LAB-017",                    // the row whose texts caption it (research and learner captions come from that row's texts)
  "statesRows": ["LAB-017","LAB-018","ATL-004"],  // rows the figure makes visible (for the coverage test)
  "lenses": ["clifford","simplex","cube","prime","alg","cat"],  // lens keys it can redraw in (notation or vocabulary)
  "learner": true,                            // renders at learner level (with the learner caption)
  "interactive": ["n","signature"]            // controls exposed
}
```

## 7. `pages.json` — pages are queries plus layout

```jsonc
{
  "route": "steps/grav2",
  "title": {"phys": "Gravity II: the Einstein form", "math": "The Einstein form as a variation", "learner": "Gravity, part 2: Einstein's equation"},
  "stepNo": 10,                               // for the twenty steps; null elsewhere
  "needs": ["steps/grav1"],                   // the dependency map (from v15 needs strips + labelling)
  "hero": {"row": "GRV-010", "figure": "einstein-form-identity"},
  "sections": [
    {"id": "identities", "title": {"phys": "What the engine proves", "math": "Exact identities"}, "query": {"shownOn.section": "identities"}, "orderBy": {"phys": "shownOn.order", "math": "kind"}, "drawer": ["evidence","needs","depends","readings","scripts"]},
    {"id": "solutions", "…": "…"}
  ],
  "connective": {"identities": "Each identity below is checked twice: by the engine and by a route that never touches it."}  // ≤ 240 characters per section, no claim
}
```

`query` selects rows by `shownOn` (and may add `status != open` for the body; open rows render in the section's "open" fold). `role` in `shownOn`: `hero` (one per page), `result` (body), `detail` (drawer), `evidence` (drawer, under "numbers"); the story overlay adds `lead`, `caption`, `learner` and `next` (interface 26), the page top `note` (interface 37), and round 14 adds `chain`, a story row that leads a chain, drawn only by its chain (§11.3). A section may carry `chains` (its chains in order, written by the merge, never typed: §11.3); a top-level page an overlay adds carries `after`, `needs`, `learnerFrame` and its try lines in `connective`, the top's under `"top-notes"`.

## 8. Other tables (seeded straight from v15)

`theorems.json` (T1–T20 as in `researchersData.js`, plus `rowsUsing`), `questions.json` (34), `sources.json` (26, with `read` true/false), `matrix.json` (131 rows × 22 columns, E/S/A, notes), `inputs.json` (the 94 input lines with their eleven kinds and the tab they belong to), `steps.json` (the twenty steps: id, no, names in both modes and learner, stage), `glossary.json` (16 terms + the labelling vocabulary, research and learner definitions), `analyses.json` (17 entries of `reports/analyses/index.json`), `reports.json` (6 + note + tutorial), `tutorials.json` (the 8 tutorials of `#/tutorials`: hand fields and the fields `tools/tutorials/registry.mjs` computes from each source, docs/round8/TUTORIALS.md), `leads.json` (the wave-3 leads: id, status, scripts, rows changed, proposed wording with source), `readings.json` (the 982 dictionary rows), `map.json` (the 63 nodes of v15's tree, kept for the Logbook's "where things were").

`notes.json` — the notes to researchers (kind view: no row, no status, nothing of the Atlas is stated here that a row does not state; the pages `#/notes` and `#/notes/<key>` and the Logbook's Notes tab, docs/06_PAGES.md §/notes). The shape: `{ title, line, about, notes: [ { key, to: [names], work, lead, rows: [row ids], sections: [ { head, text: [paragraphs], rows?: [row ids], figure?: <figure id> | null, svg?: "<course>/<file>.svg" (a tutorial figure at reports/tutorials/src/<course>/figs/<file>.svg), links?: [ { to: <route>, at?: <row or section>, label } | { href: <relative path>, label } ] } ], question, thanks, earlier?: { date, text: [paragraphs] } } ] }`. The counts a note shows (its rows by status) are computed from the tables through `statusOf`, never stored. Its text fields obey the shipped rules (no history word, English, no contact detail: names only); a paragraph never copies a row's words (the row's card states them). A note is a view, so the tuning export (`tools/export_tuning.mjs`) does not export it: an agent reads the rows it names. It ships to `dist/content/` with the other tables (`tools/build_chunks.mjs` copies every table of `content/`).

## 9. The address of a row (04_LABELLING.md)

Computed, shown in the drawer and the register, never typed: `cell · (p,q,r) · stage/kind · prime`, e.g. `(1,3,0) · (2,1,2) · D/theorem · 37·43·71·89·103`. The bit mask (29 bits) and the prime product are stored in the built chunks for search and for the "neighbours" navigation (rows one notion away).

## 10. Validation (run at build; fails the build)

- ids unique across `rows.json`; every reference resolves (`depends`, `evidence.check`, `shownOn.page` exists in `pages.json`, `captionRow` exists, lens keys exist).
- every row that is not `meta`/`candidate` has at least one `research` text; every page has at least its hero row with a `learner` text.
- learner texts contain no `$`, no `\\(`, no `=` between symbols, no Greek variable letters; research texts with `$` parse in KaTeX.
- `notions` ⊆ the 29 codes; `kind`, `stage`, `ptype`, `fields`, `phenomena` within their enums.
- no e-mail address, phone number or filesystem path in any content file; no history words (the v15 list, `08_BUILD_TEST.md` §4).
- the coverage invariant: every `<Statement>` in the rendered app has a row id; connective prose per section ≤ 240 characters; the rendered text of every statement equals a text record byte for byte.
- counts after migration equal the numbers in `03_MIGRATION.md`.
- round 14 (§11): every chain of `chains.json` names a page and a section of `pages.json` that lists it in its `chains`, rows that exist and a lead that is a story row; every span names a chain of `chains.json` and that chain's position (or its twin) at its number, at learner level in the register `span` (`tools/build_content.mjs`).

## 11. Chains (round 14: `chains.json`, the spans, the overlay files, the retire book)

The learner level tells chains of statements, not single rows: a chain is a part of the story a page tells, its sentences the learner texts of its rows (the owner's direction of round 14; `docs/round14/STORY_ROUND.md`, D51–D64). The research level shows the same chains as statements in chain order with the relation word of each link; the agents' view (the page records, the tuning export) carries them beside the rows. Nothing here changes a row, a status or a home: a chain is an order over rows that exist, and a span is one more text record of its row.

### 11.1 The chain record — `content/chains.json` (interface 40)

The shipped table, written by `tools/merge_chains.mjs` (inside `tools/merge_story.mjs`, D59) from the owners' files (§11.5), sorted by page, section and order.

```jsonc
{
  "id": "matter.fur-next.open",          // <page key>.<section>.<slug>; the page key is the route with "/" as "-" ("steps-coupling"); a slug, never a position
  "page": "matter", "section": "fur-next",// a section of the page after the merge (never intro, top-notes or an inputs section)
  "order": 1,                             // its place among the section's chains, unique in the section (V8)
  "title": { "phys": "…", "math": "…", "learner": "A choice, a reading and four open questions" },  // names: ≤ 60 characters, no claim word, no final period, no formula mark at learner level (V7)
  "lead": null,                           // a story row of role chain placed in the same section, whose restates name rows of the chain (V4), or null
  "rows": ["INP-011", "FUR-014", "FUR-034", "FUR-038", "FUR-005", "FUR-039", "FUR-026", "FUR-040"],   // the positions, in story order
  "mention": ["FUR-034", "FUR-026"],      // positions told in another chain of the same page (V2: a row is told at most once per page)
  "twins": { "FUR-005": "FUR-005b" },     // a position's row → the b-row split from it and visible only in the other mode (V5)
  "joins": [{ "from": "FUR-020", "to": "FUR-038", "rel": "derives" }],   // depends edges from a row told in an earlier chain of the page: "Continues from"
  "links": [{ "rel": "uses-input" }, { "rel": "uses-input", "from": "INP-011" }, { "rel": "derives" }, { "rel": "order" }, "…"],  // rows.length − 1 links
  "shape": "fork",                        // line | fork | cycle | ladder (V6)
  "extracted": { "tool": "extract_chains", "component": 2, "departures": ["mention FUR-034 (told in matter.fur-sixteen.weights)", "…"] },
  "story": "draft"                        // none | draft | reviewed: written by the merge, never typed
}
```

- **Links** (V3). `derives`, `instance`, `uses-input`, `equiv`, `cycle`: each backed by a `depends` edge between the two positions, or between the later position and `from` (an earlier position: a branch, the shape `fork`); `dir: "back"` when the earlier position rests on the later (an input placed after the row that uses it). `continues`: backed by `splitFrom`, a line split from the previous position's row. `order`: adjacent, no edge. `contrasts`: no edge, a `note` naming what is set against what. `contradicts` never stands in a chain (A6).
- **Shape**, in this order: `cycle` when a `cycle` edge of `depends` joins two positions; `ladder` when the largest n = p + q + r of every position's cells climbs or descends strictly (three positions or more); `fork` when a link has `from`; `line` otherwise.
- **Status** is not stored: `chainStatus(chain)` (`src/app/queries.js`) is the weakest computed status among the rows and twins, open > not yet proved here (cited) > ours > input > standard and proved by the Atlas; the title line names it as a word ("Weakest link: …"), never as a badge (D56).
- **story** is the merge's: `draft` when every position and twin has its span and the lead its learner text, `reviewed` when all those texts are reviewed or human, else `none`.
- **extracted** keeps the mechanical draft the composer started from (`tools/story/extract_chains.mjs`, rules E1–E9: the induced `depends` graph of a section, split lines joined to their first line by `continues`, a path cover with at most 8 positions per chain, singletons attached by a shared parent or a labelling neighbour) and every change the composer made (`--diff` lists them).

### 11.2 The span (interface 41)

A text record of its row (§2) with two more fields:

```jsonc
{ "row": "ATY-011", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "span",
  "chain": "shifted.sv-3.shift", "span": 4, "body": "…", "status": "draft", "source": "storyteller@<date>" }
```

- `span` is the 1-based position in the chain; `mode` is `both`, or the mode of a twin's row (C11: the two spans of a position share its number).
- A told span obeys R1–R13 of `tools/check_learner_texts.mjs` (40 to 900 characters, or 1.5 × its research text when that is longer); a mention's span the short register's rules (20 to 300 characters, no number its row lacks: C8). A told position whose row has a human learner text takes that text verbatim (`status: "human"`, the human text's `source`: C10).
- The learner file's `termsUsed` and `keptNumbers` are the checker's (`--fix`) and are not merged. The lead's learner text is the lead story row's own learner `full` text, the story's first sentence; no other sentence of a story stands outside a span (C9).
- **Two kinds of learner full text** (D68, round 16). A row's learner `full` text (register `full`, mode `both`, lens none, no `chain`) is either the translator's draft (`source: "translator:learner@…"`, `content/texts_learner*.json`) or the storyteller's text (`source: "storyteller@<date>"`, `content/chains/learner/<page key>.json`: the learner text of a story row, or the full text of a side note or of a told row that had none). The checker's R3 lets one of each kind stand under the same key, never two of one kind; the merge writes the learner drafts first (`tools/merge_learner_texts.mjs`) and the storyteller's records after them (`tools/merge_story.mjs` step 2), so `texts.json` holds the storyteller's text where both exist — it supersedes the draft, which the next release's retire moves to the book (§11.6). From wave 3 on every side note of a storied page has the storyteller's full text (`docs/round16/PLAN.md` §1), so a page's drawer and its "More statements" read the storyteller's words wherever a story has reached.
- **textFor**(row, { mode, level, lens, register, chain }): at learner level with `chain`, the span of (row, chain) through §2's mode and lens order, then the row's learner `full` text, then nothing (D54); at research level `chain` is ignored. `textFor` never crosses levels.
- The text key holds `chain` wherever a key is built: `src/app/store.js`, `tools/merge_story.mjs`, `merge_learner_texts.mjs`, `merge_explore.mjs`, `merge_physics.mjs`, the R3 key of the checker; `tools/build_content.mjs` keeps spans out of a row's research and learner text.

### 11.3 The section field `chains` and the role `chain` (interface 42)

- `pages.json` sections gain `"chains": [ids]`, the section's chains in order, written by the merge from the chain records (a typed one is removed with a warning). A section with chains keeps its `query`, `lead`, `figure` and `key`. The page draws lead → figure blocks (captions, try line) → chains → key results → "More statements"; a section with two chains or more lists their titles under its lead.
- `ROLES` (`tools/build_content.mjs`, `tools/merge_story.mjs`, `src/app/vocab.js`) gain `chain`: a story row that leads a chain, drawn only by its chain, never among key results, in "More statements" or under Ask's "Where to read about it".
- An added top-level page (an overlay entry whose route is not in `pages.json`) takes `after` (the route it follows in the reading order, after that page and its tabs), `needs`, `stepNo: null`, `learnerFrame` and `connective` (its try lines, research and learner, the top's under `"top-notes"`). A later file's entry for a page that exists replaces its `title`, `tab`, `parent` and `learnerFrame`, and merges its entry-level `connective` line by line.

### 11.4 The story rows and the statement rows of round 14 (interface 43)

- **Story rows** (D60): kind `story`, notions `["i-meta"]`, no evidence, `since: "v2.15"` (the section leads of wave 2 `"v2.16"`, those of waves 3–5 `"v2.17"`: `SINCES` of `tools/merge_chains.mjs`), one placement, ids of the page's group: 701–709 the page level (the page lead, intro paragraphs, the next line), 711–749 the section leads (role `lead`, order 0), 751–799 the chain leads (role `chain`) and the paper cards of `matter/papers` (role `result`); an id that `content/story/ids.json` or `pending.json` reserves is refused (V9). The research text is the page builder's or the composer's draft (`source: "round14:<owner>"`, `"round15:C<k>"`, `"round16:C<k>"`), the learner text the storyteller's; each passes the story test T1–T5 (`STORY_PLAN.md` §1.4) against the rows of its chain, its section or (the intro) its page, with `restates` naming them. Status meta, no badge, never new. 40 at 2.15.0: ATY-701 … 703, ATY-711 … 722 and ATY-751 … 758 on `shifted`; FUR-701, 702, 711 … 716, 751, 752 on `matter`; FUR-717 and the cards FUR-761 … 766 on `matter/papers`; 45 at 2.16.0 with the five section leads of wave 2; 63 at 2.17.0 with the eighteen of waves 3–5 (SPN-711, CPL-711, YM-711 … 713, MAT-711, FUR-718, FUR-719, GRV-711, GRV-712, PRJ-711, PRJ-712, LAB-713 … 715, NUL-711, FRQ-711, SPR-711).
- **Statement rows** (D61): where a calibration's last section names a reading or an open item no row states, a row of kind `reading` (status ours) or `question` (status open), `since: "v2.15"`, no evidence, `depends` on what it rests on, one placement (its home, the calibration page), its research text the locator's words edited only to stand alone, with the locator as `source` (`"shifted_view.md#step-6c.taken-forward.1"`). 13 at 2.15.0: ATY-056 … ATY-065 and FUR-038 … FUR-040, drafts for the author (A59).

### 11.5 The overlay files and who writes them

| file | holds | written by |
|---|---|---|
| `content/chains.json` | the merged chain records (shipped) | `tools/merge_chains.mjs` |
| `content/chains/pilot/chains.json` | the chains of `rule` · ideas, `cells` · cards, `steps/coupling` · eq-coupling, `steps/baez` · bz-generation | the pilot's composer |
| `content/chains/<owner>/{chains,rows,texts}.json` | a page's chains, its round-14 rows and their research texts (`shifted`, `matter`) | the page's builder |
| `content/chains/<owner>/page.json` | `{ "pages": [page entries], "layout": [placements of its told rows] }` | the page's builder |
| `content/story/furey.json` | the entries `matter` and `matter/papers` recomposed, and their layout | the Furey builder |
| `content/chains/learner/<page key>.json` | the spans and the learner texts of the round-14 rows, one file per page | the storyteller |
| `content/chains/retired.json` | the retire book (§11.6) | `tools/merge_chains.mjs --retire` |
| `content/story/depends_<pass>.json` | a labelling overlay of `depends` (round 15: `depends_a62.json`): `{ _about, edges }`, each entry `{ row, id, rel, op?, from, note, verdict, why }`, applied at step 0 of the story merge where the judge accepted it (§11.6) | the labeller, the judge's verdicts |
| `content/stored_shifted.json` | the stored blocks of the shifted figures (interface 44) | `tools/story/stored_shifted.mjs` |
| `content/physics/figures.p12.json` · `figures.p13.json` | the seeds of the five shifted figures · of `fibre-base` | the page builders |

Precedence of page entries: `content/story/sections.json` → `chapters.json` → `furey.json` → `content/chains/*/page.json` (folders sorted); later wins. Placements: a told row on a page that is not its home gets a layout entry with `add: true`, role `result` and an order above every home (on `shifted` 2000 + 100·k + i, k the section, i the position), so no home moves (D51: an added placement at or below the home's order is refused); a row moved into a chain's section on its own page keeps its order (no row is renumbered); a mention has no placement.

**The stored table** (interface 44): `content/stored_shifted.json`, blocks `qnt`, `bil`, `beat`, `ser`, `low`, `zero`, `ds5`, `time`, each `{ check, log, script, header, lines, values }`: the `ok` lines of `checks/selfcheck/proofs/logs/shifted_{dirac,energy,einstein}.log` verbatim and the values parsed from them by one explicit pattern per block; `node tools/story/stored_shifted.mjs --check` exits 1 when the table differs from the logs. The figures read it through `useTable('stored_shifted')`, loaded on demand (D34, D62).

### 11.6 The merge, the checks and the retire book

- `npm run content` runs `tools/check_learner_texts.mjs` (R1–R13 on every learner record, C1–C11 on every chain), then `node tools/merge_chains.mjs --check`, the learner, Explore and physics merges, `tools/merge_story.mjs` (the chains merged in one book with the story overlay, refused on V1–V10) and `tools/build_content.mjs` (the references of every chain and span; `docs/COVERAGE.md` lists chains, storied chains, spans and side notes per page). A second run writes the same bytes.
- **Step 0 of the story merge: the labelling overlays of `depends`** (round 15, A62; `docs/round15/A62_APPLIED.md` §1). Before everything else, `tools/merge_story.mjs` reads every `content/story/depends_<pass>.json` (files sorted) and applies each entry with `verdict: "accept"` by its op: add (no `op`: the edge `{ id, rel }` appended to the row's `depends` when the row lacks it), `drop`, `set-cycle` (the edge's relation becomes `cycle`, in place), `turn` (removed, and added to the other row the other way round); a verdict `"turn"` or `{ rel }` changes an added edge's direction or relation; `"reject"` and `null` apply nothing. An entry on a row or target that is not a row, or with an op, relation or verdict outside its record, refuses the merge; an entry whose edge already stands as it leaves it is a warning. The rows carry no provenance per edge, so the pass is booked: `content/story/merged.json` → `depends`, one entry per changed row, `{ orig, wrote, ops }`, restored by the base like every other write of the merge, so the chains (step 5b), `merge_chains --check` and a re-migration read the labelled graph and the next run applies it again. At 2.16.0: 35 accepted entries of `depends_a62.json`, 26 add, 8 drop, 1 set-cycle on 34 rows (`MIGRATION_COUNTS.json` → `storyMerge.dependsOverlays`); `tests/chains.test.mjs` C checks that every accepted entry holds and that the book's `orig` is the base's.
- **The retire book.** `node tools/merge_chains.mjs --retire "<wave>"` moves the translator drafts (`source: "translator:…"`, level learner, register `full`, status draft or reviewed) of the rows whose every placement is a told position, or its twin, of a storied chain from `content/texts_learner*.json` to `content/chains/retired.json`, each as `{ wave, from, …the record }`, sorted by row; it never deletes. Human texts never move, nor a short or caption draft (no span replaces those: they serve the page top, the cards and the figures; the hero of `shifted` shows ATY-005's short learner text). **A hero keeps its words** (D66, round 15): the full draft of a page's hero (`pages.json` `hero.row`) that has no short learner text stays, since the page top draws the hero's short register when the row has one, else its full text, and no span reaches the top; the CLI names the heroes it keeps. **A superseded draft goes whatever its row** (D68, round 16): a row whose learner full text the storyteller has written (§11.2: a record of `content/chains/learner/*.json`, register `full`, mode `both`, lens none, source `storyteller@…`) is superseded, told or side note, hero or not, and its translator full draft moves with the wave; D66 keeps only drafts that nothing replaces. The next `npm run content` drops the moved drafts from `texts.json` (`tools/merge_learner_texts.mjs` reads the book; `MIGRATION_COUNTS.json` → `learnerDrafts.retired` counts the records of retired keys that run dropped: after a retire under D68 that count settles from the second run on at the number of superseded rows, since the storyteller's texts share the retired drafts' keys, leave `texts.json` at that step and come back at the story merge; every other byte is the same from the first run on). A second `--retire` moves nothing. At 2.15.0 the book holds 26 drafts of 26 rows, all of wave 2.15.0: ATY-004 … 009, ATY-011, ATY-028, ATY-037 … 047, CAND-003, GEN-010, GEN-012 … 016. The other 34 rows told only in storied chains had no translator draft to move (the ten statement rows of `shifted`, GEN-001 … 009, the GEN rows of 2.12.0 to 2.14.0 told on `rule` and `cells`, CAND-019 and CAND-071): their spans are their only learner words. At 2.16.0 the book holds 96 drafts of 96 rows: the 26 of wave 2.15.0 and 70 of wave 2.16.0 (the ATL cards and their lines, the clock's rows, the views and ladders of `light`, EQN-001, EQN-002, MIR-001, MIR-011, LAB-003 among them, from six files); of the 141 rows told only in storied chains at 2.16.0, 96 gave their translator full drafts to the book, ATL-001 and EQN-003, heroes without a short learner text, keep theirs (D66), and 43 had no translator full draft (their spans, and for some a reviewed text or a full text of the storyteller, are their learner words). At 2.17.0 the book holds 263 drafts of 263 rows: 167 of wave 2.17.0 from eight files (`texts_learner.json` 73, `texts_learner_2.json` 19, `texts_learner_aty.json` 22, `texts_learner_b3.json` 12, `texts_learner_explore.json` 9, `texts_learner_pass8.json` 5, `texts_learner_proofs2.json` 14, `texts_learner_proofs3.json` 13), 109 of them the drafts of told rows of waves 3–5 whose every placement is told (ATY-010 and ATY-051 … ATY-053, told on `shifted` since 2.15.0 and on `steps/grav2` now, FUR-002b, FUR-003b, FUR-004b and CAND-102, told on `matter` and on its tab, among them) and 58 the drafts of side notes superseded by the storyteller's full texts (D68); the heroes without a short learner text keep theirs (ATL-001, EQN-003, CPL-001, YM-001, MAT-001, GRV-003, GRV-010, PRJ-002, NUL-001), and the rows whose placements are not all told keep theirs too (LAB-007, NUL-010, SPR-003, RIG-041 … RIG-043, MIR-002, MIR-007, MIR-008 among them). At 3.0.0, the close of the round (D70), the book holds 752 drafts of 752 rows (26 of wave 2.15.0, 70 of 2.16.0, 167 of 2.17.0, 426 of 2.18.0 — the three pages of wave 6 — and 63 of 3.0.0, the drafts the sweep's full texts supersede), and `content/texts_learner*.json` are two things at once: the sources of the book for every draft a story or a storyteller's text replaced, and the sources of the merge for the 413 translator drafts that nothing replaces, each the only learner words of its row — `texts_learner_matrix.json` (the 149 matrix lines, D35), `texts_learner_story.json` (the 125 learner versions of the author's narration rows in no chain, D40), the short texts of the page tops, cards and captions, the full drafts of the eleven heroes without a short text (D66), and the side notes no wave's list assigned, listed by page in `docs/round16/LEARNER_TEXTS_close.md` §3. A row never loses its learner words to the retire: a draft leaves its file only when a storyteller's text or a story replaces it.
