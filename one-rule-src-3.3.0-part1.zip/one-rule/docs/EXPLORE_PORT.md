<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Explore port: the Octavo leaf logics on the kernel

Round 4, agent X2 (`docs/EXPLORE_PLAN.md` §2.5, §2.7, §3 X2; `docs/BUILD_CONTRACTS.md` Round 4, interface 16). The ten leaf logics of Octavo V₀
(clock, moves, zero, light, fall, roots, seats, magnets, springs, charge), its `names.js` and `shared.js` now live in `engines/explore/`, re-pointed to the
kernel; their tests live in `tests/explore/`; fixtures in `engines/explore/leaves/stored/` hold every number to what Octavo returned. The pictures are X6's
(`src/figures/explore/leaf/`), drawn from the API of §4.

## 1. In one table

| leaf | Octavo test, as run on the hand-off | Octavo-only checks removed | kept verbatim | V2 checks | mutants (Octavo → V2, all caught) | Octavo fixture: cases, values bit-identical |
|---|---|---|---|---|---|---|
| clock | 3,581 / 0 failures | 0 | 3,217 | 3,878 | 7 → 7 | 9 cases, 23,369 values |
| moves | none (never written) | — | — | 583 (new test) | — → 9 | 13 cases, 10,742 values |
| zero | 28,950 / 1 (the face's `built` flag) | 12 | 24,647 | 28,838 | 13 → 14 | 14 cases, 55,870 values |
| light | 3,065 / 1 (the face's `built` flag) | 15 | 2,848 | 3,143 | 10 → 10 | 21 cases, 43,540 values |
| fall | 2,001 / 0 | 2 | 1,596 | 2,109 | 15 → 15 | 19 cases, 66,765 values |
| roots | 6,443 / 0 | 5 | 5,696 | 6,249 | 10 → 11 | 21 cases, 384,723 values |
| seats | 4,238 / 0 | 7 | 3,065 | 4,186 | 14 → 14 | 17 cases, 27,445 values |
| magnets | 13,679 / 0 | 9 | 11,934 | 14,632 | 14 → 14 | 12 cases, 35,097 values |
| springs | 1,621 / 0 | 8 | 1,560 | 1,845 | 16 → 16 | 13 cases, 46,438 values |
| charge | 14,518 / 1 (the face's `built` flag) | 9 | 11,872 | 14,173 | 11 → 14 | 20 cases, 133,800 values |
| names | none | — | — | 66 (each over the whole domain) | — → 8 | all outputs over the domain (sha256 of 422,784 characters) |

- **Octavo test**: Octavo's `test_octavo_<slug>.mjs` run on a copy of the hand-off's base (v16) with the unfinished leaves laid over it. The three failures are
  the face files' `built` flags (the faces of those leaves were never finished); no logic check failed.
- **Octavo-only checks removed** (67 in all): the COPY limits and notes (headlines, three notes of at most 26 words, the try line, the panel headlines, the
  lens), the registry, the face file (`.jsx`: header, colours, `built`, its research words) and the word budgets. Where a COPY note carried a fact (springs:
  "each 1 stretches four more springs", "111 is faster than 100"; roots: 112 = 4·C(8,2), 128 = 2⁷; seats; charge), the fact is checked on the logic's data.
- **kept verbatim**: the assertions whose message is the same in both runs (the two runs' messages compared as multisets). The rest of Octavo's checks are
  the Octavo-only ones above and the checks of sentences the logic no longer returns (§3), rewritten as checks of the data that replaced them (the message
  then changes: "the line under the picture: …" becomes "the parts as words …"); a few messages were reworded only ("the colour of its place" → "the mark of
  its place").
- **mutants**: Octavo's broken copies, all ported; those whose patch text vanished with a sentence were rewritten with the same meaning (§5). Added: zero —
  the reverse taken from `reorderSign` with the wrong sign; roots — the product in Cl(7,1); charge — a sign of the copied cell table, the reverse forgotten,
  Cl(3,1) for Cl(1,3); moves — nine of its own.
- **No number changed under the kernel**: 827,789 values in 159 cases are bit-identical (`Object.is`), with no zero of the other sign bit.

## 2. The kernel

Every product and every sign goes through `engines/labels.js` (the v15 API on the kernel) or `engines/bitrule.js`; the imports of `labelsEngine.js` are
re-pointed to `engines/labels.js` (the Octavo base engines are byte-identical to the v15 files V2 already pins, so the outputs stay bit-identical). Local
sign code was replaced:

| module | Octavo | V2 |
|---|---|---|
| zero | `reverse`: `popcount(m) % 4 >= 2 ? -v : v` | `reorderSign(m, m) < 0 ? -v : v` |
| charge | `reverse` from `popcount(m)·(popcount(m) − 1)/2`; the squares and the table read from `maxwellData.js` cells["1,3"] | `reorderSign(m, m)`; `SQ = square(1 << i, cell(1, 3))`; the table copied as `CELL13` (V2's `engines/maxwellData.js` carries only the charges block) and compared with `checks/selfcheck/maxwell.json` cells["1,3"] by the test |
| springs | `sign = (s, x) => popcount(x & s) & 1 ? -1 : 1` | `sign = walsh` (`engines/springEngine.js`); `bits` from `names.js` |
| seats | `signByName`: a loop over the primes below seat k | `reorderSign(1 << k, labelOfName(name))` |
| roots | `product`: a cache of `bladeMul` with its own sign table | the kernel's `mul` on Maps |
| names | `v.toString(2).padStart(n)`, factors by a filter, `ones()` | `label(v, 'bits', cell(n, 0))`, `label(v, 'primes')`, `maskFromPrimes`, `popcount` |

`tests/explore/tkit.mjs` `discipline()` runs the patterns of `tests/shipped.test.mjs` rule 4 on the code of every ported file (comments and strings blanked),
and checks its imports (`labels.js`, `bitrule.js`, `shared.js`, `names.js`, `schullerEngine.js`, `springEngine.js` only), its header and that it uses no
randomness, clock, storage, network or hex colour.

## 3. No sentence in the logic

The printing rule (`EXPLORE_PLAN.md` §1: what the rows do not state is not printed; §2.2: no component writes a sentence that states a law; §2.3: readouts
are computed by the logic and tested) leaves the logic no sentence to return. The port therefore removes, beyond `COPY` and the constant sentences of
interface 16, every prose field (screen-reader texts, status lines, captions, notes, reasons), and keeps names, values and formula readouts. Where a
sentence carried a computed fact, the fact is returned as data. This is the one place where the return shapes differ from Octavo's: the sentence keys are
gone; every other key is Octavo's, value for value.

| module | exports removed | keys removed (at any depth) | keys added or changed |
|---|---|---|---|
| clock | `COPY` | `note` (move), `label` (eight), `aria`, `alt`, `dialAlt`, `say`, `flip` | `kind` (the button the state came from), `op` (`'add'` or `'drop'`), `mirror` ({ p, q, hour, algebra, self }) |
| moves | `COPY` | `ballAlt`, `phaseAlt`, `alt`, planetView `line` | `status` is now the readout `k = … · X² = … · <move>`; `conic` and `CONICS` (ellipse, parabola, hyperbola) |
| zero | `COPY`, `DUAL_INTRO`, `SLIDE_INTRO`, `SLIDE_NOTE` | `key`, `why`, `alt`, `aria`, `line` | `zeros`, `shared` (front); `readout` (dualView: det Lₓ, 1/x, x²) |
| light | `COPY`, `LABELS` | `tag` (KINDS), `status`, `alt`, `switchAlt`, `aria`, `line`, `stAlt` | — (kind, alone, time, sameSpeed, side, miss, twice carry the facts) |
| fall | `COPY`, `MATH_CAP`, `PHYS_CAP` | `say` (STATES), `status`, `alt`, `dialAlt`, `dialSmall`, `line` | `readout` (mathView: g and X²; physView: M and 2M) |
| roots | `COPY`, `arrowLine`, `statusOf`, `formulaDet`, `stopWords`, `PICK_HINT`, `PHYS_INTRO`, `physCap` | `line`, `status`, `alt`, `capTwo`, `capHalf`, `stripAlt`, `say` | `FAMS` (the chip ids, labels and marks COPY held) |
| seats | `COPY`, `namesCaption`, `ruleLine`, `TRACE_LINE`, `EXCLUSION_LINE` | `note`, `caption`, `alt`, `addLabel`, `takeLabel`, `land`, `rule`, `sqAlt`, `line`, `countsLine` | `readout()` returns `{ math }` (the event is in the state) |
| magnets | `COPY`, `HINT`, `BALL_CAP`, `MODEL_LINE`, `ORDER_CAP` | `line` (front, orders), `alt`, `aria` | `words`, `stop` (front); `sign31` (orders); `rEnds` keeps its numbers only |
| springs | `COPY`, `INTRO`, `UNITS`, `statusOf`, `altOf` | `aria`, `status`, `alt`, `caption` | — (onesText, speedText, fracOf, coeffs, pitches carry the facts) |
| charge | `COPY`, `LABELS`, `MATH_LINES` | `say`, `alt`, `gaugeAlt`, `cap`, `line` (runs) | `lead` is now the formula `E² − B² = …`; `FIELD_LINE` keeps the field, not the sentence after it; `LEGEND` keeps `{ cls, name }`; `CELL13` |
| shared | `tableAlt` | the hex colours of the table grids | `fade` (a flag where the colour was) |
| names | — | — | `labelOfName` (the kernel's `maskFromPrimes`) |

Readouts kept as they were (values with their formula or name; X5's coverage test reads them as figure text): clock `sumLine` ("3 − 1 = 2 → hour 2."),
`line1`/`line2` (the type of the cell), voteView `line` (the votes, the net sum, its length and hour); moves mapView `line`; zero `eq`; magnets ballView
`line` (v·u and p), the products `expr`; springs `eigenLine`, `formula`, the chip captions (`still`, `speed 2`); charge mapView `line`, `zoomText`,
`speedText`; the `eText`/`bText`/`rText`/`thText` values of the controls.

## 4. The API (for X3 and X6)

`engines/explore/index.js` exports `LEAF_LOGIC = { clock, moves, zero, light, fall, roots, seats, magnets, springs, charge }`; each value is the module.
All functions are pure (no React, no randomness, no clock); a state goes in, a new state or a view model comes out. The main entry points and the keys
they return:

- **clock** — `move(s, p, q, kind)` → `{ p, q, ang, kind }`; `eight(s)` → `{ op, next }` or null; `tapHour`, `swapSigns`, `canMove`, `canVote`; `front(s)` →
  `{ w, hour, hours, handDeg, sumLine, line1, line2, pMinusOff, qMinusOff, pPlusOff, qPlusOff }`; `votes(p, q)`, `voteView(p, q)` → `{ g, cnt, n, bars,
  hour, tip, end, line }`; `FRIENDS` (`{ name, p, q }`), `pickFriend`, `friendView({ f, angF })` → `{ list, dots, w, hour, handDeg, head, mirror }`.
  Constants `MAX_EACH, MAX_TOTAL, BACK_EACH, BACK_TOTAL, START, START_VOTES, START_FRIEND`.
- **moves** — `spring(k)` → `{ k, a, b, c, X2, cls, name }`; `setStrength`, `advance`, `stateAt`, `orbitPts`, `toPath`; `frontView(s)` → `{ k, a, b, c, X2,
  cls, name, x, v, op, bx, hasSpring, spring, dash, dot, kText, status }`; `mapView(k)` → `{ …, x, y, kText, line }`; the planet: `setEnergy`,
  `advancePlanet`, `conic`, `startPhi`, `rOf`, `conicPath`, `planetView(s)` → `{ E, e, kind, name, conic, op, x, y, eText }`. Constants `MOVES, CONICS,
  SYMMETRY, START, START_PLANET, KV_MIN, KV_MAX, EV_MIN, EV_MAX, …`.
- **zero** — `tapSwitch`, `tapCorner`, `times(a, b, eps)`, `front(s)` → `{ corners, edges, switches, r, held, zeros, shared, eq, product }`;
  `canLayers`, `layersOf`, `powersOf`, `layerView(p, q, r)` → `{ rows, counts, total, loewy, h }`; `dualView(av, bv)` → `{ a, b, x2, det, can, inv, near,
  dot, readout, aText, bText }`; `translator`, `reverse`, `point`, `placeOf`, `sandwich`, `slideView({ a, b })` → `{ a, b, Ta, Tb, M, from, to, d, motor,
  motorParts, arrows, ticks, aText, bText, rod0, rod, ends }`; `undo`, `lin`, `nb`, `exact2`. Constants `START, START_LAYERS, START_DUAL, START_SLIDES, …`.
- **light** — `canSet`, `setCounts`, `advance`, `square`, `dot`, `world(p, q)` → `{ p, q, n, S, sq, plus, minus, time, alone, axes, tt, headings, shape,
  kind, K, switches, sameSpeed, axisSigns }`; `frontView(s)` → world plus `{ t, dots, stuck, guide, op, tText, … }`; `coneView(si, ki)` → `{ p, q, name, w,
  S, time, axes, alone, beta, deg, theta, Qt, side, lines, cone, miss, twice, tip, tail, o, labels, axisEnds }`; `roots`, `proj`, `sigLabel`, `pluck`,
  `height`, `stringView(t10)` → `{ t, c, tText, path, centres, now }`. Constants `KINDS` (`{ id, mark }` by kind), `CELLS`, `START, START_CONE,
  START_T10, …`.
- **fall** — `setDistance`, `advance`, `stateOf`, `gOf`, `rOfV`, `vOfR`, `frontView(s)` → `{ r, g, cls, t, st, v, op, drop, probe, …, rText, speedText,
  dialBig }`; `mathView(g)` → `{ g, X2, T2, cls, xt, tip, ttip, xTip, tTip, dot, readout }`; `physView(M)` → `{ M, edge, rain, newton, end, rainPath,
  newtonPath, endXY, edgeX, readout }`. Constants `STATES` (`{ cls, where, mark }`), `START, …`.
- **roots** — `ROOTS` (240 arrows), `idOf`, `product`, `mirror`, `coxeter`, `shadow`, `pick`, `tick`, `stepSel`, `seeView(s)` → `{ marks, rings, counter,
  counterWord, done, arrow, sel, cells, list, kind }`; `choose`, `countView(pair)` → `{ nodes, chords, signs, pair, pairs, perPair, two, free, corners,
  power }`; `cartanE`, `detE`, `rootCount`, `eSeries`, `canN`, `stopView(n)` → `{ n, det, roots, endless, nodes, edges, strip }`; `ballOf`, `nextWall`,
  `setBall`, `rollOn`, `wallTally`, `billiardView(b)` → `{ kind, wall, ball, out, d, angle, legs, tags, pos, fade, tally, arcs, … chips }`. Constants
  `FAMS, COUNT, DET_TOP, START, START_SEL, START_N, START_BALL, …`.
- **seats** — `press(s, k, op)`, `rename`, `moveOn`, `particles`, `isFull`, `readout(s, …)` → `{ math }`; `frontView(s)` → `{ seats, corners, edges, arrow,
  layers, total, shakeKey, pattern, readout }`; the names: `stepByName`, `signByName`, `nameIn`, `longName`; `mathView(s)` → `{ k, n, names, cells, sqCells,
  fullCols }`; `commutatorDiag`, `table01`, `nextTable`, `traceView(s)` → `{ n, a, d, sum, tr1, lines }`; `lowestFor`, `canAddAny`, `atomMore`, `atomLess`,
  `atomView(s)` → `{ k, ways, thumbs, dots, minusOff }`. Constants `MODES, SEAT_PRIMES, START, START_MATH, START_TRACE, START_ATOM, …`.
- **magnets** — `setDir`, `turn`, `advance`, `chain`, `state`, `projector`, `passPart`, `through`, `frontView(s)` → `{ segs, total, steps, words, stop,
  magnets }`; `canBall`, `ballView({ th, rv })` → `{ …, p, dot, tip, ruler, thText, rText, thEnds, rEnds, line }` or null outside the ball;
  `ordersView(inDir)` → `{ rows, diff, sign31 }`, rows `{ a, b, label, segs, total, pct, K, names, expr, magnets }`; `mvText`, `bladeText`. Constants
  `DIRS, ARROW, DEG, IN_DIR, LANES, START, START_BALL, START_IN, IN_CHOICES, …`.
- **springs** — `pickLabel`, `pluckAt`, `advance`, `startOf`, `motion`, `coeffs`, `groups(st)` → `[{ j, caption, chips }]`; `frontView(st)` → `{ corners,
  order, lines, energy, groups, plucking }`; `mathView(n)` → `{ n, cols, ev, top, eigenLine }`; `pitches()`, `physView(j)` → `{ P, lines, trace, part,
  total, formula, options }`; `bits`, `onesText`, `speedText`, `speedShort`, `speedSym`, `fracOf`, `cornerName`. Constants `N, SIZES, AMP, START, PASCAL,
  GEO, VIEW, MATH, PHYS, PLUCKED, PITCH_START`.
- **charge** — `crossed(E, B)`, `classOf`, `square`, `force`, `frontRun(kE, kB)` → `{ kE, kB, E, B, cls, view, zoom, pts, last, steps, turns, top, low, dt,
  tEnd, periodic, left }`; `pathOf(run)`, `advance(s, run, dt)`, `setField`, `frontView(s, run, path)` → `{ cls, lead, name, x, y, X, Y, SX, SY, op, speed,
  speedText, gauge, trail, zoomText, eText, bText }`; `sayField(kE, kB)` → `{ cls, lead }`; `presetOf`, `trackE`, `trackB`, `glyphs`; `mapView(kE, kB)` →
  `{ E, B, cls, name, x, y, path, dots, alone, EB, eText, bText, line }`; `circleRun(kv)`, `driftRun(kr)`, `limitRun()` (measured, formula, newton, path,
  title, …). Constants `MOVES, PRESETS, LEGEND, START, MAP, MAP_START, OBSERVERS, KV, KR_MAX, FIELD_LINE, CELL13, …`.
- **names** — `SWITCH_PRIMES` (= `PRIMES.slice(0, 8)`), `NAME_MODES`, `primeName`, `primeFactors`, `primeOf`, `labelOfName`, `combineNames`, `bitsOf`,
  `nameOf(v, 'bits' | 'numbers' | 'primes', n)`, `nameLong`, `canDrop`, `canAdd`, `stepLabel`, `stepName`, `grade`, `isEven`, `namesOf`. Domain: v < 256,
  and v < 2ⁿ for the bits naming (there the kernel's bits label and Octavo's padded binary agree digit for digit).
- **shared** — `KIND`, `DOUBLED`, `kindLine`, `ringShadow`, `fmt`, `num`, `sub`, `algebra`, `smallest`, `hourPos`, `hourStep`, `tableLayout` (grid cells
  carry `fade`), `box`, `track`.

## 5. The tests

`tests/explore/tkit.mjs` carries Octavo's helpers onto the V2 tree (`tally`, `seeded`, `mutant(rel, patches)` with `rel` from the repository root and a
patch that must apply exactly once, `catches`, `typeByInvariants`, `TEXTBOOK`, `engineKind`, `sameType`, `eigenvaluesSymmetric`, `signatureOf`,
`killingForm`) plus `fixtures(slug, M, T)` and `discipline(rel, T)`. Each `tests/explore/leaves.<slug>.test.mjs` names its engine route and its standard
routes in its header (textbook matrices, closed forms, independent integrators, stored check results), runs `check(M, ok)` on the port, then the Octavo
fixture and the discipline (outside `check`, so that the standard routes alone must catch the broken copies), then the mutants. `WHY=1` prints, for each
broken copy, how many assertions failed and the first of them.

- **moves** has a new test: the 2 × 2 matrices of Cl(2,0) and the Taylor series of exp against `expTX`; the sign of X² against `trinityClass`; the closed
  forms (cos, linear, cosh) and RK4 against x″ = −kx; an adaptive RK4 Kepler orbit against the conic e² = 1 + 2pE, the energy, equal areas (r²φ′ = √p) and
  the Runge–Lenz vector; Poisson brackets for so(4), e(3), so(3,1). Nine mutants.
- **charge** compares `CELL13` and `SQ` with `checks/selfcheck/maxwell.json` cells["1,3"] (order, signs, blades) and its numeric rows (cyclotron, drift,
  hyperbolic) as Octavo did with `maxwellData.js`; `FIELD_LINE` against the cell's own `F` string.
- **roots** reads the Coxeter plane from `engines/stored.js` (`GOSSET`, checks/selfcheck/gosset.json) where Octavo read `gossetData.js`.
- **names** recomputes the three namings by plain integer arithmetic over the whole domain (bits by `toString(2)`, names by trial division, Möbius and
  Liouville, the divisors of 2·3·…·19, the gcd rule for all 65,536 pairs) against `label()`, `PRIMES`, `maskFromPrimes` and `dictionary.json`
  (`ladder[8].prime_names`), and holds every output to Octavo's (the sha256 of 422,784 characters recorded from Octavo's `names.js`, file sha256
  7ee870170de394e8…).
- Mutants rewritten with the same meaning where the text they patched left with a sentence: clock (eight's room test → `op: 'add'`; the friends' signs),
  zero (the reasons → `shared`), fall (outside and inside swapped in `where`), seats (the sign from the seats above: `reorderSign(labelOfName(name), 1 << k)`),
  springs (the wrong parity: `walsh(x | s, x | s)`), magnets (the sign of e₃e₁: `sign31`).

Run one: `node tests/explore/leaves.<slug>.test.mjs` (charge takes about 45 s, roots 17 s, the others a few seconds); all: X5's runner
`node tests/explore.test.mjs` (wave 3), or `for f in tests/explore/*.test.mjs; do node "$f" || echo "FAILED $f"; done`.

## 6. The fixtures

`engines/explore/leaves/stored/`: `cases.mjs` lists, per leaf, the fixed inputs (the whole state space the controls reach, seeded walks from the round-2
`prng`) as `[id, fn, { drop, add }]`; `drop` names the keys of Octavo's output the port does not carry, `add` the keys the port returns instead (a key in
both is a readout whose words changed, compared by the leaf's own test). `make_octavo.mjs` ran the cases through Octavo's modules and wrote
`<slug>_octavo.json` (3 to 15 kB each): an output whose encoded form is at most 4,000 characters is stored whole, a longer one as its sha256 and size
(88 of the 159 cases). Each file records the sha256 of the Octavo module it came from, and `fixtures()` checks that it differs from the ported file (the
fixture was not written from the port). `codec.mjs` compares with `Object.is` (a zero of the other sign bit is counted, never hidden; there are none).

To regenerate (only to re-record Octavo, never from the port): lay `wip/HANDOFF_OCTAVO/wip/<slug>/` over a copy of the hand-off's `base/v16`, then
`node engines/explore/leaves/stored/make_octavo.mjs <that folder> [slug …]` (or `OCTAVO_DIR=<folder>`).

## 7. Not ported, and why

- The face files (`<slug>.jsx`) and their checks: the pictures are X6's, drawn with V2's kit from the API above.
- The 67 Octavo-only checks of §1 and the checks of the sentences removed in §3 (their facts are checked as data).
- The other Octavo leaves (bands, cube, electron, field, half-turns, hung, mirrors, steps, tumbling): no passing mutant test exists for them (D25; plan A30).
- Nothing else: every logic function of the ten modules is ported, and none of their numbers changed.
