<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# ONE RULE 2.8.0 — release notes

The proofs round's sixth pass: the three themes of the Atiyah lens's map that pass five left (Berry–Robbins, the Einstein obstructions of the edge-cone corollaries, the shifted equation on a curved frame) and the gauge half of the instanton count (`docs/round8/PROOFS_ROUND6.md`; the lens page `#/lenses/atiyah` and its analysis, section 9, items 11 to 14).

## What the reader sees

- **Three new statements** (group ATY, badge "new"), each placed as a detail after the row it extends: Atiyah's determinant of a configuration of points on the labels of Cl(3,0), with the Berry–Robbins lift as the bit-rule product (1 + u·e)f₀ (ATY-035, on the projective page after CAND-030); the Einstein obstructions of the edge-cone corollaries on named pairs and the paper's family of self-dual Einstein cones with its curvature and its integrals in closed form (ATY-036, on the second gravity page after ATY-025); the shifted Dirac equation on the frame of a weak static field, where the quantization follows proper time and the paper's equivalence-principle term is a quarter turn of the wave, not a real energy (ATY-037, on the coupling page after ATY-011).
- **One statement completed**: ATY-034, the conformal zero modes of the BPST instanton, says of the ten fields that fix the density that they are gauge transformations, with their gauge parameters written down and checked identically.
- **The Atiyah lens**: three more dictionary entries (83), the analysis page's map with its three last proposals marked done, section 9 with items 11 to 14 and a rewritten list of what is not done, three sources read on the web added.

## What the tables gain

- Four scripts under `checks/selfcheck/proofs/` (bpst_stabiliser, atiyah_config, cone_obstructions, shifted_weakfield): 55 check lines, every one with a bit-rule route, a standard route and controls; 14 `--fault` runs each exiting 1; logs and fault logs beside them; four check records and four run records.
- A negative result kept as it came out: the paper's (2.12), T₀₀ = E₀(1 − μ(−1)ⁿ), is not reproduced from the printed operator; the control that reads the quarter turn as a scalar is what gives it.

## Counts

<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->
- **Release** 2.8.0 · content: the version the build carries (`content/version.json`, printed in the footer).
- **Statements**: 1,770 rows (the 789 rows of the author's package, with 224 more where a row held several lines, 2 rows the Explore overlay adds, 513 rows of the translation matrices the physics overlay adds (D35), 28 rows of the leaves, 88 rows the proofs round adds (a candidate becomes a row when a check decides it), 25 rows of the Atiyah readings (group ATY), 60 rows of the partly checkable candidates and the lines split from open questions (a candidate becomes a row when a check decides it) and 12 rows of the Atiyah map round (group ATY, the checks the lens's map asked for, themes 15 to 17 included)), each with a research text (the author's words, or a draft for review for a row an overlay adds).
- **Texts**: 3,309 in all — 1,295 research texts and 415 learner texts by the author, 179 research drafts and 1,101 learner drafts waiting for review, 9 reviewed learner texts (drafts by file: texts_learner.json 153, texts_learner_2.json 132, texts_learner_b3.json 15, texts_learner_baez.json 169, texts_learner_explore.json 101, texts_learner_matrix.json 149, texts_learner_proofs.json 4, texts_learner_proofs2.json 58, texts_learner_proofs3.json 59, texts_learner_schuller.json 136, texts_learner_story.json 125).
- **Status**, computed from the evidence and the labelling: proved by the Atlas 938 · standard 37 · our reading 124 · needs an input 93 · open 119 · about the Atlas itself 459.
- **Lenses**: 35, with 1,056 dictionary entries; 2,494 lens readings on 594 rows in 11 lenses; 982 readings in the readings table.
- **Checks**: 355 scripts with 612 recorded runs; the gravity checks: 5,569 pass, 0 fail.
- **Figures**: 100 drawn (46 in `app.js`, 54 in the chunk `figures-extra.js`, loaded when a page needs one, D47), 0 of the 100 seeds shown as labelled placeholders.
- **Candidates**: 150 missing pieces named by the labelling passes; 145 of them are rows now, proved by the check that decided them; the rest are kept in the Logbook until a check decides them or the author accepts them as rows.
- **Pages and tables**: 36 routes; 20 theorems; 34 questions (16 answered); 26 sources; 17 glossary terms; 8 wave-3 leads with 28 proposed edits on 26 rows.
- **Physics** (the overlay `content/physics/`, D33): 32 figures of the wave P4–P11 (14 of them at learner level too, 23 wide); 513 rows of the translation matrices (spin 50, forque 54, spring 46, the rigid body 98, ATL 4, CPL 5, EQN 13, FUR 32, GEN 5, GOS 8, GRV 7, LAB 19, LNB 21, LNC 33, LNP 2, LNS 41, MAT 4, MIR 7, NUL 10, PAG 28, PRJ 9, SHP 13, YM 4), computed: proved by the Atlas 127 · our reading 22 · about the Atlas itself 364; placed on their step pages as details (151) and as numbers (22); 8 stored tables loaded on demand (`content/stored_p<k>.json`, 229.7 kB, D34).
- **Build**: `dist/app.js` 954.0 kB, 290.9 kB gzipped (budget 340 kB, D47); the figures chunk `dist/figures-extra.js` 721.3 kB, 244.1 kB gzipped (budget 260 kB, D47); `dist/app.css` 119.8 kB (budget 120 kB, D38).
- **Validation** (docs/COVERAGE.md): 0 errors.
<!-- end of the counts -->

## How it is tested

The suites of 2.7.0, unchanged: `npm test` (data, build, UI) and the release script's full list. The four new scripts run as `python3 -I -B selfcheck/proofs/<name>.py` from `checks/`, with their `--fault` options; their check lines are stored in `checks/selfcheck/proofs/logs/`.

## What is still open

What 2.7.0 left open except the three themes and the gauge half: the Atiyah–Bott–Shapiro paper read in the original (the expositions stand in for it); learner texts for the ATY rows. And from this pass: the Atiyah–Sutcliffe conjecture beyond n = 4 and beyond points; an Einstein edge-cone metric off the family of the paper; the energy-momentum tensor of the shifted theory, which the paper's page does not define, and wave packets.
