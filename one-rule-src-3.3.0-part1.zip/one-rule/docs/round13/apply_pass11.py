#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round13/apply_pass11.py -- applies passes 11a, 11b and 11c of round 13 (docs/round13/pass11a/apply.json, Furey's roadmap on the labels;
docs/round13/pass11b/apply.json, the spinors of the total cell: groups, pairings, jets, the current; docs/round13/pass11c/apply.json, the standard
routes closed, the covers' commutants, ABS's own map, the algebraic limit) to the tables, the layout of the story overlay and the Atiyah analysis
page, in the order 11a, 11c, 11b (FUR-034 of 11b derives from FUR-027 of 11a; the page's items in the order of their numbers: 34 is 11c's, 35 11b's),
and makes the release owner's text edits of docs/round13/PLAN.md (R6), recorded in the notes of the three apply.json files.

Modelled on docs/round12/apply_pass10.py. Idempotent: a second run writes the same bytes, also after npm run content. Every input is checked before
the first file is written. In order:
  1 content/rows.json        FUR-027 ... FUR-032 (11a) after FUR-026, GEN-027 ... GEN-032 (11c) after GEN-026 and FUR-033 ... FUR-037 (11b) after
                             FUR-032, since v2.14 (the seventeen ids are free: FUR-001 ... FUR-026 and GEN-001 ... GEN-026 stand, the FUR-5xx, FUR-6xx
                             and GEN-5xx ids are story rows; a row that holds one of the seventeen ids and is not an earlier copy of its pass stops the
                             script); every (page, order) of the three passes free page-wide (in the rows and in the story overlay's layout), each
                             section a section of its page; a row on cells, section cards, with a concrete first cell, n <= 8 (11c's six: (0,0,8),
                             (8,0,0) and (0,8,0)); no row of 11a or 11b on the cells page. 11b's orders on steps/coupling are 54 and 55, the owner's
                             (matter stays the home of FUR-036 and FUR-037: 52 and 53 are their least orders). An entry on a page the story overlay
                             adds (matter/model: the six of 11a and the five of 11b, all written in the passes' own rows) is not written here but by
                             tools/merge_story.mjs from step 1b, which appends it after the row's own entries and records it in its book
                             (content/story/merged.json); a row keeps it here once that book shows the merge wrote it, at the place the merge puts it.
                             Then the standardRef edits of step 2b
 1b content/story/furey.json the layout entries (add: true) of the eleven matter/model placements, after those of FUR-026 (11a: section axes, and
                             FUR-031 in edges, orders 1034 to 1039; 11b: section axes, 1040 to 1044); tools/migrate/verify_counts.mjs counts the
                             overlay's layout (987) and tests/story/furey.test.mjs lists the rows of that tab, both written with this release (R6)
  2 content/texts.json       their research texts (status draft; sources pass11a:furey-roadmap, pass11c:chain-closure, pass11b:spinor-pairings), each
                             after the texts of the row before it (the order tools/merge_learner_texts.mjs keeps: by row, then level)
 2b the text edits           (R6; each a minimal clause replacement of a research draft or a standardRef that keeps the claim and the scope):
                             (a) FUR-016: its three pairs read in the original (docs/round13/SOURCES.md (e)); (b) FUR-025 (11b's proposal): degree 2
                             constructed in FUR-036; (c) FUR-020 (11b's proposal): what relates the two readings, FUR-034; (d) GEN-019 and GEN-026:
                             Elliott's theorem as SOURCES.md (a) has it, Glimm (b) and Stacey 2011 (c) as read (in place of 11c's proposals); (e) every
                             text and standardRef that cites Slansky with "Table 48": "§6, p. 45" (SOURCES.md (i)); (f) the citations of arXiv:2209.13016:
                             each must mean the 2022 paper (its eqs. 17-22, 27, 28), none the roadmap of the R1-R5 checks (arXiv:2312.12377, SOURCES.md
                             (g)); nothing to change in the tables of 2.13.0
  3 content/checks.json      the check records of furey_roadmap.py (fr.*), chain_closure.py (cc.*) and spinor_pairings.py (sp.*), after null_stages.py
  4 content/check_runs.json  their run records: each stored log ends with the record's last line, its tagged check lines count the record's checks
                             and tags, and its fault log holds the pass's wrong versions in order, each exit 1, with as many FAIL lines as its own last
                             line counts (the counts of each RESULT.md)
  5 content/lenses.json      furey 31 -> 37 -> 39 (six entries of 11a, two of 11b), alg 142 -> 145 -> 149 -> 152 (three of 11a, four of 11c, three of
                             11b), atiyah 105 -> 106 -> 107 (11c's theme 1, 11b's theme 6), cat 155 -> 156 (11c), geo 78 -> 79 (11b); the blocks are
                             lens_<key>, a block found by its key; each entry with the keys, in their order, of its lens's own entries, appended after them
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence and by text)
  7 content/analyses.json    the check ids that the passes name for the entry atiyah (11c's cc.*, then 11b's sp.*; 11a names no analysis and has no
                             item on the page); the file is read again just before it is written and only that list is touched, as text
  8 public/reports/analyses/src/atiyah_lens.md   section 9: items 34 (11c) and 35 (11b) after item 33; the edits of the two passes, those that
                             find one sentence composed into one replacement in the order of the items (the numbering sentence, the scripts of the
                             sources, the sources of section 9, the learner texts of the list of what is not done), the clauses of the first paragraph
                             each at its own anchor (11c's after null_stages.py's rows, 11b's after branching_16.py's); theme 1 (11c) and theme 6 (11b),
                             *The Atlas.*; the list of what is not done (11c's two edits, with 11b's rows); the lens record (107 entries, 36 from the
                             checks of section 9, the readings counted from the regenerated table)
  9 node tools/make_analysis.mjs atiyah    renders the page
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round13/apply_pass11.py [--no-node]    --no-node skips steps 6 and 9 (and leaves the count of readings of step 8)
"""
import hashlib
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
said = []
pending = {}   # rel -> text: the tables are written together once every input is checked


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def stage(rel, data, newline):
    """the table's new text, written by flush() once every check of steps 1 to 5 has passed"""
    pending[rel] = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')


def flush():
    for rel, text in pending.items():
        old = open(path(rel), encoding='utf-8').read()
        if text != old:
            open(path(rel), 'w', encoding='utf-8').write(text)
            said.append(f'wrote {rel}')
        else:
            said.append(f'unchanged {rel}')
    pending.clear()


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


# ---- the three passes, in the order they apply: 11a, 11c, 11b (the page's items: 34 is 11c's, 35 is 11b's)
A = json.load(open(os.path.join(HERE, 'pass11a', 'apply.json'), encoding='utf-8'))
B = json.load(open(os.path.join(HERE, 'pass11b', 'apply.json'), encoding='utf-8'))
C3 = json.load(open(os.path.join(HERE, 'pass11c', 'apply.json'), encoding='utf-8'))
F = lambda a, b: [f'FUR-0{k}' for k in range(a, b + 1)]
G = lambda a, b: [f'GEN-0{k}' for k in range(a, b + 1)]
PASSES = [
    {'C': A, 'name': '11a', 'src': 'pass11a:furey-roadmap', 'group': 'FUR', 'after': 'FUR-026', 'n': None,
     'ids': F(27, 32), 'script': 'checks/selfcheck/proofs/furey_roadmap.py',
     'checks': ['fr.HC', 'fr.ALG', 'fr.WITT', 'fr.FOCK', 'fr.BIV', 'fr.HYP', 'fr.LINE'],
     'faults': [('NOI', 14), ('WRONGPAIR', 15), ('ODDPL', 2), ('VOLSIGN', 5), ('BITPERM', 4), ('INLINE', 6)],
     'tags': {'bit': 29, 'bit==std': 7, 'ctl': 7, 'std': 8}, 'last': 'furey_roadmap: 51 checks, 0 fail',
     'where': {'FUR-027': [('matter', 'furey', 43), ('matter/model', 'axes', 1034)],
               'FUR-028': [('matter', 'furey', 44), ('matter/model', 'axes', 1035)],
               'FUR-029': [('matter', 'furey', 45), ('steps/baez', 'bz-generation', 274), ('matter/model', 'axes', 1036)],
               'FUR-030': [('matter', 'furey', 46), ('steps/baez', 'bz-generation', 275), ('matter/model', 'axes', 1037)],
               'FUR-031': [('matter', 'furey', 47), ('steps/baez', 'bz-generation', 276), ('matter/model', 'edges', 1038)],
               'FUR-032': [('matter', 'furey', 48), ('matter/model', 'axes', 1039)]},
     'stage': {}, 'blocks': {'lens_furey': 'furey', 'lens_alg': 'alg', 'lens_schuller': 'schuller', 'lens_atiyah': 'atiyah'},
     'analyses': [], 'edits': []},
    {'C': C3, 'name': '11c', 'src': 'pass11c:chain-closure', 'group': 'GEN', 'after': 'GEN-026', 'n': 34,
     'ids': G(27, 32), 'script': 'checks/selfcheck/proofs/chain_closure.py',
     'checks': ['cc.COV', 'cc.LIFT', 'cc.STD', 'cc.REF', 'cc.LIM', 'cc.ABS', 'cc.C24'],
     'faults': [('COMMD', 2), ('WRONGINDEX', 1), ('OMEGA2', 3), ('COUNTQ', 2), ('CENTREEVEN', 2)],
     'tags': {'bit': 17, 'bit==std': 4, 'ctl': 6, 'std': 3}, 'last': 'chain_closure: 30 checks, 0 fail',
     'where': {f'GEN-0{27 + k}': ([('clock', 'clock', 1006)] if k == 4 else []) + [('rule', 'ideas', 39 + k), ('cells', 'cards', 77 + k)] for k in range(6)},
     'stage': {}, 'blocks': {'lens_atiyah': 'atiyah', 'lens_alg': 'alg', 'lens_cat': 'cat'},
     'analyses': ['atiyah'], 'edits': ['GEN-026', 'GEN-019']},
    {'C': B, 'name': '11b', 'src': 'pass11b:spinor-pairings', 'group': 'FUR', 'after': 'FUR-032', 'n': 35,
     'ids': F(33, 37), 'script': 'checks/selfcheck/proofs/spinor_pairings.py',
     'checks': ['sp.GRP', 'sp.CPX', 'sp.PAIR', 'sp.JET', 'sp.CUR'],
     'faults': [('KERNEL', 1), ('NOI', 1), ('SAMESCALAR', 1), ('JET4', 1), ('NOCROSS', 4)],
     'tags': {'bit': 15, 'bit==std': 6, 'ctl': 5, 'std': 6}, 'last': 'spinor_pairings: 32 checks, 0 fail',
     'where': {**{f'FUR-0{33 + k}': [('matter', 'furey', 49 + k), ('steps/baez', 'bz-generation', 278 + k), ('matter/model', 'axes', 1040 + k)] for k in range(3)},
               **{f'FUR-0{36 + k}': [('matter', 'furey', 52 + k), ('steps/coupling', 'eq-coupling', 54 + k), ('matter/model', 'axes', 1043 + k)] for k in range(2)}},
     'stage': {'FUR-036': 'F', 'FUR-037': 'F'},
     'blocks': {'lens_furey': 'furey', 'lens_alg': 'alg', 'lens_schuller': 'schuller', 'lens_atiyah': 'atiyah', 'lens_geo': 'geo'},
     'analyses': ['atiyah'], 'edits': ['FUR-025', 'FUR-020']},
]
P11A, P11C, P11B = PASSES
ALL_IDS = [i for P in PASSES for i in P['ids']]
ALL_CHECKS = [c for P in PASSES for c in P['checks']]
LENS_N0 = {'furey': 31, 'alg': 142, 'atiyah': 105, 'cat': 155, 'geo': 78}   # the dictionaries of 2.13.0
LENS_ADD = {'11a': {'furey': 6, 'alg': 3}, '11c': {'atiyah': 1, 'alg': 4, 'cat': 1}, '11b': {'furey': 2, 'alg': 3, 'atiyah': 1, 'geo': 1}}
CONCRETE = re.compile(r'^\((\d{1,2}),(\d{1,2}),(\d{1,2})\)$')
FIRST_CELL = {'GEN-027': '(0,0,8)', 'GEN-028': '(0,0,8)', 'GEN-029': '(8,0,0)', 'GEN-030': '(8,0,0)', 'GEN-031': '(0,8,0)', 'GEN-032': '(8,0,0)'}

for P in PASSES:
    C = P['C']
    assert C['pass'] == P['name'] and C['since'] == 'v2.14', (P['name'], C['pass'], C['since'])
    assert [r['id'] for r in C['rows']] == P['ids'], [r['id'] for r in C['rows']]
    assert [(e['row'], e['level']) for e in C['row_text_edits']] == [(x, 'research') for x in P['edits']], f"pass {P['name']}: its row_text_edits"
    assert C['files']['script'] == P['script'], C['files']['script']
    assert all(os.path.exists(path(C['files'][k])) for k in ('script', 'log', 'faultLog')), C['files']
    assert [a['id'] for a in C['analyses']] == P['analyses'] and all(a['checks_add'] == P['checks'] for a in C['analyses']), \
        f"pass {P['name']}: the analysis it names (atiyah, with its check ids) or none"
    assert {k: C[k]['key'] for k in C if k == 'lens' or k.startswith('lens_')} == P['blocks'], f"pass {P['name']}: the lens blocks"
said.append('checked the three apply.json files (11a, 11c, 11b)')

# ===================================================================================================================== 1 rows
rows, rows_nl = load('content/rows.json')


def pass_of(rid):
    return next(P for P in PASSES if rid in P['ids'])


def earlier_copy(r):
    P = pass_of(r['id'])
    return (r.get('since') == 'v2.14' and r.get('group') == P['group'] and bool(r.get('evidence'))
            and all(e.get('script') == P['script'] for e in r['evidence']))


clash = [r['id'] for r in rows if r['id'] in ALL_IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free id of its group')
rows = [r for r in rows if r['id'] not in ALL_IDS]
FUREY = 'content/story/furey.json'
fy, fy_nl = load(FUREY)
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])} | {(l['page'], l['order']) for l in fy['layout'] if l['row'] not in ALL_IDS}
mine = [(s['page'], s['order']) for P in PASSES for r in P['C']['rows'] for s in r['shownOn']]
assert len(mine) == len(set(mine)) and not set(mine) & taken, f'an order of the passes is taken (page-wide) or used twice: {sorted(set(mine) & taken)}'
sections = {p['route']: {s.get('id') for s in p.get('sections') or []} for p in json.load(open(path('content/pages.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        rid = r['id']
        assert r['since'] == 'v2.14' and r['group'] == P['group'], rid
        assert (r['kind'], r['stage']) == ('computation', P['stage'].get(rid, 'A')), (rid, r['kind'], r['stage'])
        assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == P['where'][rid], rid
        assert all(s['role'] == 'detail' and s['section'] in sections.get(s['page'], ()) for s in r['shownOn']), f'{rid}: a role or a section'
        homes = sorted(r['shownOn'], key=lambda s: s['order'])   # a row's home is its entry of least order (src/app/queries.js, rowHome)
        assert P['group'] != 'FUR' or (homes[0]['page'] == 'matter' and [s['page'] for s in r['shownOn']].count('matter/model') == 1), \
            f'{rid}: home on matter, and on its tab'
        assert P['group'] != 'GEN' or not any(s['page'].startswith('matter') for s in r['shownOn']), f'{rid}: a GEN row in the matter chapter'
        on_cards = any((s['page'], s['section']) == ('cells', 'cards') for s in r['shownOn'])
        assert on_cards == (rid in FIRST_CELL) and not any(s['page'] == 'cells' for s in r['shownOn'] if rid not in FIRST_CELL), f'{rid}: on the cells page or not'
        if on_cards:
            m = CONCRETE.match(r['cells'][0]) if r['cells'] else None
            assert m and sum(map(int, m.groups())) <= 8 and r['cells'][0] == FIRST_CELL[rid], f"{rid}: a card of the cells page needs a concrete first cell, n <= 8: {r['cells'][:1]}"
# An entry on a page the story overlay adds (content/story/furey.json: the five sub-pages of matter) goes through that file's layout
# (add: true, step 1b), as those of FUR-006, CAND-102, CAND-049 and FUR-007 ... FUR-026 do: tools/merge_story.mjs appends it after the row's own
# entries and records it in its book (content/story/merged.json, key "<row>|<page>|add|<index>", the sha1 digest of the entry), and the tables
# without the overlay (its baseTables) stay valid. Here a row keeps such an entry only once the book shows the merge wrote it, at the place the
# merge puts it.
OVERLAY = {p['route'] for p in fy['pages'] if 'page' in p}
assert OVERLAY == {'matter/dictionary', 'matter/papers', 'matter/model', 'matter/generations', 'matter/help'}, OVERLAY
book = json.load(open(path('content/story/merged.json'), encoding='utf-8')).get('entries', {})
digest = lambda so: hashlib.sha1(json.dumps(so, ensure_ascii=False, separators=(',', ':')).encode('utf-8')).hexdigest()[:20]
layout = []   # the layout entries of the passes, in the order of the rows
for P in PASSES:
    put = []
    for r in P['C']['rows']:
        own = [s for s in r['shownOn'] if s['page'] not in OVERLAY]
        over = [s for s in r['shownOn'] if s['page'] in OVERLAY]
        assert r['shownOn'] == own + over, f"{r['id']}: its overlay entry stands last, where the merge appends it"
        wrote = [(book.get(f"{r['id']}|{s['page']}|add|{len(own) + k}") or {}).get('wrote') == digest(s) for k, s in enumerate(over)]
        assert all(wrote) or not any(wrote), f"{r['id']}: the merge wrote some of its overlay entries and not the others: run npm run content"
        put.append({**r, 'shownOn': own + (over if all(wrote) else [])})
        layout += [{'row': r['id'], 'page': s['page'], 'section': s['section'], 'order': s['order'], 'role': s['role'], 'add': True} for s in over]
    at = next(i for i, r in enumerate(rows) if r['id'] == P['after'])
    rows[at + 1:at + 1] = put
ids = {r['id'] for r in rows}
thm = {t['id'] for t in json.load(open(path('content/theorems.json'), encoding='utf-8'))}
for P in PASSES:
    for r in P['C']['rows']:
        for d in r['depends']:
            assert d['id'] in ids or d['id'] in thm, f"{r['id']} depends on an unknown row {d['id']}"
        for e in r['evidence']:
            assert e['mode'] == 'ran' and e['script'] == P['script'] and e['check'] in P['checks'], r['id']
    assert sorted({e['check'] for r in P['C']['rows'] for e in r['evidence']}) == sorted(P['checks']), f"pass {P['name']}: every check id is some row's evidence"
assert [r['id'] for r in rows if r['id'] in ALL_IDS] == P11A['ids'] + P11B['ids'] + P11C['ids'], 'the seventeen rows, once each, in the order of the ids'
order = [r['id'] for r in rows]
assert order.index('FUR-026') + 1 == order.index('FUR-027') and order.index('FUR-032') + 1 == order.index('FUR-033') \
    and order.index('GEN-026') + 1 == order.index('GEN-027'), 'the rows after the rows they follow'

# ---- 1b the story overlay's layout: the entries of 11a and of 11b on its sub-page matter/model, after those of FUR-026 (pass 10b)
keep = [l for l in fy['layout'] if l['row'] not in ALL_IDS]
assert keep[-1]['row'] == 'FUR-026' and all(list(l.keys()) == list(keep[-1].keys()) for l in layout), 'the layout of the story overlay'
assert [l['row'] for l in layout] == P11A['ids'] + P11B['ids'] and all(l['page'] == 'matter/model' for l in layout), \
    'one entry per row of 11a and of 11b, none of 11c'
assert [(l['section'], l['order']) for l in layout] == [('axes', 1034), ('axes', 1035), ('axes', 1036), ('axes', 1037), ('edges', 1038), ('axes', 1039)] \
    + [('axes', 1040 + k) for k in range(5)], 'the sections and orders on matter/model'
fy['layout'] = keep + layout
assert len(fy['layout']) == 45 + 11, len(fy['layout'])
stage(FUREY, fy, fy_nl)

# ===================================================================================================================== 2 texts
texts, texts_nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine_t = {key(t) for P in PASSES for t in P['C']['texts']}
texts = [t for t in texts if key(t) not in mine_t]
assert not any(t['row'] in ALL_IDS for t in texts), 'another text of the seventeen rows stands in content/texts.json (no learner text this round: docs/round13/PLAN.md)'
for P in PASSES:
    C = P['C']
    assert [t['row'] for t in C['texts']] == P['ids'], f"pass {P['name']}: one research text per row, in the order of the rows"
    for t in C['texts']:
        assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == \
            ('draft', P['src'], 'research', None, 'both', 'full', 'en'), t['row']
        assert not re.search(r'/home/|/Users/|@[\w-]+\.\w', t['body']), f"{t['row']}: a machine path or a contact detail"
    # after the last text of the row before the pass; a row's research text after its own learner texts (by row, then level)
    at = start = max(i for i, t in enumerate(texts) if t['row'] == P['after']) + 1
    for t in C['texts']:
        while at < len(texts) and texts[at]['row'] == t['row']:
            at += 1
        texts.insert(at, t)
        at += 1
    assert texts[start - 1]['row'] < P['ids'][0] and (at == len(texts) or texts[at]['row'] > P['ids'][-1]), f"pass {P['name']}: the texts out of row order"

# ===================================================================================================================== 3 the check records
checks, checks_nl = load('content/checks.json')
cids = [c['id'] for P in PASSES for c in P['C']['checks']]
checks = [c for c in checks if c['id'] not in cids]
assert checks[-1]['id'] == 'selfcheck/proofs/null_stages.py', checks[-1]['id']
assert not any(x['id'] in ALL_CHECKS for c in checks for x in c.get('ids') or []), 'an fr.*, cc.* or sp.* id in another record'
form = list(checks[-1].keys())
for P in PASSES:
    C = P['C']
    assert len(C['checks']) == 1
    for c in C['checks']:
        assert list(c.keys()) == form and c['id'] == P['script'][len('checks/'):] and c['since'] == 'v2.14', c['id']
        assert c['script'] == P['script'] and c['log'] == C['files']['log'], c['id']
        assert [x['id'] for x in c['ids']] == P['checks'] and c['rowsNaming'] == P['ids'], c['id']
        total = sum(P['tags'].values())
        assert f"{total} checks ({', '.join(f'{k} {v}' for k, v in P['tags'].items())})" in c['notes'], (c['id'], c['notes'][:120])
    checks += C['checks']
stage('content/checks.json', checks, checks_nl)

# ===================================================================================================================== 4 the run records
# the stored log: its tagged check lines (all ok) count the record's checks and tags, and its last line is the record's; the fault log: the
# pass's wrong versions in order, each "--fault X: exit 1", with as many FAIL lines as its own "last:" line counts (RESULT.md of each pass)
runs, runs_nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine_r = {rk(r) for P in PASSES for r in P['C']['check_runs']}
runs = [r for r in runs if rk(r) not in mine_r]
run_form = list(runs[-1].keys())
TAG = re.compile(r'^  (ok|FAIL) +\[(bit|bit==std|ctl|std)\] ')
for P in PASSES:
    C = P['C']
    name = os.path.basename(P['script'])[:-len('.py')]
    total = sum(P['tags'].values())
    log = open(path(C['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
    hits = [m for m in map(TAG.match, log) if m]
    tags = {k: sum(1 for m in hits if m.group(2) == k) for k in P['tags']}
    assert all(m.group(1) == 'ok' for m in hits) and len(hits) == total and tags == P['tags'], (P['name'], tags)
    assert log[-1] == P['last'] == f'{name}: {total} checks, 0 fail', log[-1]
    tagword = ', '.join(f'{k} {v}' for k, v in P['tags'].items())
    assert len(C['check_runs']) == 1
    for r in C['check_runs']:
        assert r['script'] == P['script'] and r['source'] == C['files']['log'] and list(r.keys()) == run_form, r['script']
        assert r['passed'] is True and r['ok'] == total and r['fail'] == 0 and r['lastLine'] == log[-1], r['script']
        assert f'tags {tagword}' in r['status'] and f"{len(P['faults'])} --fault runs each exit 1" in r['status'], r['status']
    got = []
    for b in re.split(r'^(?=--fault )', open(path(C['files']['faultLog']), encoding='utf-8').read(), flags=re.M):
        if not b.strip():
            continue
        head = re.match(r'--fault (\w+): exit 1\n', b)
        last = re.search(rf'^last: {name}: (\d+) checks, (\d+) fail$', b, re.M)
        nfail = len(re.findall(r'^  FAIL +\[', b, re.M))
        assert head and last and int(last.group(1)) == total and int(last.group(2)) == nfail >= 1, (P['name'], b[:80])
        got.append((head.group(1), nfail))
    assert got == P['faults'], (P['name'], got)
    for txt in (open(path(C['files']['log']), encoding='utf-8').read(), open(path(C['files']['faultLog']), encoding='utf-8').read()):
        assert not re.search(r'(?<![\w.~%-])/(home|Users)/[\w.-]', txt), f"pass {P['name']}: a machine path in a stored log"
    runs += C['check_runs']
    said.append(f"{P['script']}: {log[-1]} (tags {tagword}); faults {', '.join(f'{f} {k}' for f, k in got)}, each exit 1")
stage('content/check_runs.json', runs, runs_nl)

# ===================================================================================================================== 5 the lenses
# a block is found by its key; each entry has the keys of its lens's own entries, in their order, and is appended after them, the passes in the
# order they apply (11a, 11c, 11b); each lens's dictionary is recounted after each pass
lenses, lenses_nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
adds = {}
for P in PASSES:
    for blk, lkey in P['blocks'].items():
        for e in P['C'][blk]['dictionary_add']:
            assert e['evidence'] and set(e['evidence']) <= set(P['checks']) and e['rows'] and set(e['rows']) <= set(P['ids']), (lkey, e['atlas'][:40])
            assert e['flags'] == ['checked'] and e['from'].endswith(f"(pass {P['name']})") and e['matrixRows'] == [], (lkey, e['from'])
            adds.setdefault(lkey, []).append((P['name'], e))
    got = {}
    for blk, lkey in P['blocks'].items():
        got[lkey] = len(P['C'][blk]['dictionary_add'])
    assert {k: v for k, v in got.items() if v} == LENS_ADD[P['name']], (P['name'], got)
all_add = [e for v in adds.values() for _, e in v]
for lkey, add in adds.items():
    lens = next(x for x in lenses if x['key'] == lkey)
    form_l = list(lens['dictionary'][0].keys())
    assert all(list(e.keys()) == form_l for e in lens['dictionary'] + [e for _, e in add]), f'{lkey}: an entry in another form than the lens keeps'
    keep_l = [e for e in lens['dictionary'] if not any(same(e, f) for f in all_add)]
    assert len(keep_l) == LENS_N0[lkey], (lkey, len(keep_l))
    lens['dictionary'] = keep_l
    steps_n = [LENS_N0[lkey]]
    for P in PASSES:
        lens['dictionary'] = lens['dictionary'] + [e for n, e in add if n == P['name']]
        if any(n == P['name'] for n, _ in add):
            steps_n.append(len(lens['dictionary']))
    said.append(f"the lens {lkey}: {' -> '.join(map(str, steps_n))} dictionary entries")
assert {k: len(next(x for x in lenses if x['key'] == k)['dictionary']) for k in LENS_N0} == {'furey': 39, 'alg': 152, 'atiyah': 107, 'cat': 156, 'geo': 79}
stage('content/lenses.json', lenses, lenses_nl)
aty_dict = next(x for x in lenses if x['key'] == 'atiyah')['dictionary']

# ===================================================================================================================== 2b the text edits (R6)
# Each a minimal clause replacement of a research draft (never an author's text) or of a standardRef, the claim and its scope kept, recorded in the
# notes of the apply.json of the pass it answers: (a) and (f) 11a's, (b), (c) and (e) 11b's, (d) 11c's
row_by = {r['id']: r for r in rows}
EDITED = []   # (row, field, what), in the order of the edits


def research_of(rid):
    t = [x for x in texts if x['row'] == rid and x['level'] == 'research' and x['lens'] is None]
    assert len(t) == 1 and t[0]['status'] == 'draft' and re.match(r'^pass\d+[a-z]?:[a-z][a-z0-9-]*$', t[0]['source']), f'{rid}: one research draft of a pass'
    return t[0]


def edit_text(rid, find, repl, what):
    t = research_of(rid)
    t['body'] = swap(t['body'], find, repl, f'the research text of {rid} ({what})')
    assert t['body'].count(repl) == 1, (rid, what)
    EDITED.append((rid, 'research text', what))


def edit_ref(rid, find, repl, what):
    r = row_by[rid]
    assert rid not in ALL_IDS, rid
    r['standardRef'] = swap(r['standardRef'], find, repl, f'the standardRef of {rid} ({what})')
    assert r['standardRef'].count(repl) == 1, (rid, what)
    EDITED.append((rid, 'standardRef', what))


# (a) FUR-016 (pass 10a's draft; 11a's notes): its pairs (5,4), (3,1), (6,2), with the signs of the α's, and the vacuum ωω†, read in the original
# (docs/round13/SOURCES.md (e): Phys. Lett. B 742 (2015) 195-199, §2 and §4, eqs. 10, 12); the claim (the CAR on the labels) and its scope unchanged
edit_text('FUR-016', 'and, recalled, of arXiv:1603.04078 on the six units.',
          'and, read in the original, of arXiv:1603.04078 on the six units (Phys. Lett. B 742 (2015) 195–199, §2, with the same signs).',
          '(a) the pairs read in the original')
edit_ref('FUR-016', 'C. Furey, Charge quantization from a number operator (arXiv:1603.04078), §2: α₁ = ½(−e₅ + ie₄), α₂ = ½(−e₃ + ie₁), '
                    'α₃ = ½(−e₆ + ie₂) and the idempotent ν = α₁α₂α₃α₃†α₂†α₁† (recalled, not read)',
         'C. Furey, Charge quantization from a number operator, Phys. Lett. B 742 (2015) 195–199 (arXiv:1603.04078), §2: α₁ = ½(−e₅ + ie₄), '
         'α₂ = ½(−e₃ + ie₁), α₃ = ½(−e₆ + ie₂), and §4, eqs. (10), (12): the idempotent ν = α₁α₂α₃α₃†α₂†α₁†, her vacuum ωω† (read in the original, '
         'docs/round13/SOURCES.md (e))', '(a) the pairs read in the original')
# (b) FUR-025 and (c) FUR-020 (pass 10b's drafts): 11b's two proposals, accepted as written: FUR-036 constructs the degree-2 amplitudes as derivatives
# along the shell; FUR-034 says what relates the two readings (the complexification) and that the physics is the signature (an input)
for e, tag in zip(B['row_text_edits'], ('(b) degree 2 constructed in FUR-036', '(c) the two readings related in FUR-034')):
    edit_text(e['row'], e['find'], e['replace'], tag)
# (d) GEN-026 (pass 10c's draft) and GEN-019 (pass 9b's): Elliott's theorem as docs/round13/SOURCES.md (a) has it -- stated for unital ultramatricial
# algebras over a field, in the form of Goodearl's Thm 15.26, read in secondary sources (the original not reached), so that as stated it covers the chains
# with D = ℝ and D = ℂ and those with D = ℍ only by a reading of its hypotheses (11c's caveat, GEN-030) --, Glimm 1960 for the complex C*-case (read
# in the original, Thm 1.12, SOURCES.md (b)) and Stacey 2011, Thm 13, for the real UHF algebra of type 2^∞ (read in the original, SOURCES.md (c)); in
# place of 11c's proposals, at their anchors; the claims (the limit and its completion not computed, the classifications cited, not taken) kept
GEN26 = ("Elliott's classification of AF algebras by the ordered K₀ with unit and Glimm's of UHF algebras by the supernatural number (2^∞), both stated "
         "for complex C*-algebras, are cited and set beside it, not taken for it.",
         "Elliott's classification by the ordered K₀ with unit, stated for unital ultramatricial algebras over a field (G. A. Elliott, J. Algebra 38 (1976) "
         "29–44, in the form of K. R. Goodearl, Von Neumann Regular Rings, Thm 15.26; read in secondary sources, the original not reached), which as "
         "stated covers the chains with D = ℝ and D = ℂ and those with D = ℍ only by a reading of its hypotheses (their stages are matrix algebras over ℍ, "
         "not over a field: GEN-030), Glimm's of complex UHF C*-algebras by the supernatural number (2^∞; Trans. Amer. Math. Soc. 95 (1960), Thm 1.12, "
         "read in the original) and Stacey's theorem that a real C*-algebra whose complexification is the UHF algebra of type 2^∞ is the real UHF algebra "
         "of that type (Trans. Amer. Math. Soc. 363 (2011), Thm 13, read in the original) are cited and set beside it, not taken for it; the algebraic "
         "direct limit itself is built on the labels in GEN-030.")
GEN19 = ("Not computed here: the limit of the chain and its completion (the ordered group of the limit, the inductive limit of the stages' K₀, is computed "
         "on the finite side in GEN-026); Elliott's classification of AF algebras by the dimension group and Glimm's of UHF algebras by the supernatural "
         "number (2^∞), both stated for complex C*-algebras, are cited.",
         "Not computed here: the limit of the chain and its completion (the ordered group of the limit, the inductive limit of the stages' K₀, is computed "
         "on the finite side in GEN-026, and the algebraic direct limit of the stages is built on the labels in GEN-030); Elliott's classification by the "
         "dimension group, stated for unital ultramatricial algebras over a field (in the form of Goodearl's Thm 15.26, read in secondary sources), which "
         "as stated covers the chains with D = ℝ and D = ℂ and those with D = ℍ only by a reading of its hypotheses, Glimm's of complex UHF C*-algebras by "
         "the supernatural number (2^∞; Thm 1.12, read in the original) and Stacey's theorem on the real UHF algebra of type 2^∞ (Thm 13, read in the "
         "original) are cited.")
assert [(e['row'], e['find']) for e in C3['row_text_edits']] == [('GEN-026', GEN26[0]), ('GEN-019', GEN19[0])], "11c's anchors"
edit_text('GEN-026', *GEN26, "(d) Elliott's theorem as SOURCES.md (a) has it")
edit_text('GEN-019', *GEN19, "(d) Elliott's theorem as SOURCES.md (a) has it")
edit_ref('GEN-026', 'the dimension group (ordered K₀ with order unit) of an AF algebra and its classification by it: G. A. Elliott, J. Algebra 38 (1976); '
                    'UHF algebras by the supernatural number: J. Glimm, Trans. Amer. Math. Soc. 95 (1960); Bratteli diagrams: O. Bratteli, Trans. Amer. Math. '
                    'Soc. 171 (1972); all stated for complex C*-algebras, cited, not read;',
         'the dimension group (ordered K₀ with order unit) and the classification by it of unital ultramatricial algebras over a field: G. A. Elliott, '
         'J. Algebra 38 (1976) 29–44, in the form of K. R. Goodearl, Von Neumann Regular Rings, Thm 15.26 (secondary; docs/round13/SOURCES.md (a)); complex '
         'UHF C*-algebras by the supernatural number: J. Glimm, Trans. Amer. Math. Soc. 95 (1960) 318–340, Thm 1.12 (read; SOURCES.md (b)); the real UHF '
         'algebra of type 2^∞: P. J. Stacey, Trans. Amer. Math. Soc. 363 (2011) 6439–6452, Thm 13 (read; SOURCES.md (c)); Bratteli diagrams: O. Bratteli, '
         'Trans. Amer. Math. Soc. 171 (1972) (cited, not read);', "(d) Elliott's theorem as SOURCES.md (a) has it")
edit_ref('GEN-019', 'O. Bratteli, Trans. Amer. Math. Soc. 171 (1972); G. A. Elliott, J. Algebra 38 (1976) (AF algebras classified by the dimension group); '
                    'J. Glimm, Trans. Amer. Math. Soc. 95 (1960) (UHF algebras by the supernatural number); all cited, not read;',
         'O. Bratteli, Trans. Amer. Math. Soc. 171 (1972) (cited, not read); G. A. Elliott, J. Algebra 38 (1976) 29–44 (unital ultramatricial algebras '
         'over a field classified by the dimension group with its unit, in the form of K. R. Goodearl, Von Neumann Regular Rings, Thm 15.26; secondary, '
         'docs/round13/SOURCES.md (a)); J. Glimm, Trans. Amer. Math. Soc. 95 (1960) 318–340, Thm 1.12 (complex UHF C*-algebras by the supernatural number; '
         'read, SOURCES.md (b)); P. J. Stacey, Trans. Amer. Math. Soc. 363 (2011) 6439–6452, Thm 13 (the real UHF algebra of type 2^∞; read, SOURCES.md (c));',
         "(d) Elliott's theorem as SOURCES.md (a) has it")
# (e) Slansky's "Table 48": the table number was not verified, the page was read (docs/round13/SOURCES.md (i): §6, p. 45, 16 = (2,1,4) + (1,2,4̄)); every
# research text and standardRef that cites Slansky with "Table 48" cites "§6, p. 45" instead, its other words (recalled, cited, not read) as they stand
SLANSKY_ROWS, SLANSKY_TEXTS = ['FUR-012', 'FUR-020', 'FUR-021', 'FUR-022'], ['FUR-012', 'FUR-020', 'FUR-021']
for r in rows:
    if 'Slansky' in (r.get('standardRef') or '') and 'Table 48' in r['standardRef']:
        assert r['id'] in SLANSKY_ROWS, r['id']
        edit_ref(r['id'], 'Table 48', '§6, p. 45', '(e) Slansky §6, p. 45')
for t in texts:
    if 'Slansky' in t['body'] and 'Table 48' in t['body']:
        assert t['row'] in SLANSKY_TEXTS and t['level'] == 'research', t['row']
        edit_text(t['row'], 'Table 48', '§6, p. 45', '(e) Slansky §6, p. 45')
assert all('Slansky' in row_by[i]['standardRef'] and '§6, p. 45' in row_by[i]['standardRef'] for i in SLANSKY_ROWS) \
    and all('Slansky' in research_of(i)['body'] and '§6, p. 45' in research_of(i)['body'] for i in SLANSKY_TEXTS), '(e): the rows of the sweep'
assert not any('Table 48' in v for r in rows for v in r.values() if isinstance(v, str)) and not any('Table 48' in t['body'] for t in texts), \
    '(e): a "Table 48" left in the rows or the texts'
# (f) arXiv:2209.13016 is Furey and Hughes's 2022 paper (docs/round13/SOURCES.md (g3)); the roadmap of the R1-R5 checks is arXiv:2312.12377 ((g1)). Every
# citation of 2209.13016 in the rows, the texts and the lenses names an equation of the 2022 paper (its eqs. 17-22, 27, 28): none means the roadmap,
# so the sweep changes nothing (the tables of 2.13.0 held no citation of 2209.13016; pass 11a's are the 2022 paper's)
occ = []


def scan(v, where):
    if isinstance(v, str):
        occ.extend((where, v[m.end():m.end() + 30]) for m in re.finditer(r'2209\.13016', v))
    elif isinstance(v, list):
        for x in v:
            scan(x, where)
    elif isinstance(v, dict):
        for x in v.values():
            scan(x, where)


for r in rows:
    scan(r, r['id'])
for t in texts:
    scan(t['body'], f"text {t['row']}")
for l in lenses:
    scan(l.get('dictionary') or [], f"lens {l['key']}")
assert all(re.match(r'\)?(, eq\. \(?(27|28)\)?|, eqs\. 17–22|\): Y := )', after) for _, after in occ) and len(occ) == 7 \
    and {w for w, _ in occ} == {'FUR-027', 'FUR-031', 'text FUR-027', 'lens furey'}, ('(f)', occ)
said.append(f"(f) arXiv:2209.13016: {len(occ)} citations, each the 2022 paper (eqs. 17-22, 27, 28), none the roadmap of R1-R5: nothing changed")
said.append('text edits: ' + '; '.join(f'{rid} {field} {what}' for rid, field, what in EDITED))

# ===================================================================================================================== 1, 2: the rows and the texts staged
stage('content/rows.json', rows, rows_nl)
stage('content/texts.json', texts, texts_nl)
flush()   # every input of steps 1 to 5 checked: the six tables written together

# ===================================================================================================================== 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ===================================================================================================================== 7 the analyses registry
# the check ids of the entry atiyah, as text (read again now, written back at once): the ids of the passes that name it, 11c's cc.*, then 11b's sp.*
NAMED = [c for P in PASSES if P['analyses'] for c in P['checks']]
assert NAMED == P11C['checks'] + P11B['checks'], NAMED
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
text = raw
m = re.search(r'\n(\s*)"id": "atiyah",', text)
assert m, 'the entry atiyah of content/analyses.json'
c = text.index('"checks": [', m.end())
end = text.index(']', c)
body = text[c + len('"checks": ['):end]
have = json.loads('[' + body + ']')
want = [x for x in NAMED if x not in have]
if want:
    ind = re.search(r'\n(\s*)"', body).group(1)
    stripped = body.rstrip()
    new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
    text = text[:c] + '"checks": [' + new_body + text[end:]
if text != raw:
    after = json.loads(text)
    a_old = next(x for x in before if x.get('id') == 'atiyah')
    a_new = next(x for x in after if x.get('id') == 'atiyah')
    assert a_new['checks'] == a_old['checks'] + want and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') != 'atiyah'] == [x for x in before if x.get('id') != 'atiyah']
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (atiyah gains {len(want)} check ids)')
else:
    said.append(f'unchanged {rel}')
aty_checks = next(a for a in json.loads(text) if a.get('id') == 'atiyah')['checks']
assert aty_checks[-len(NAMED):] == NAMED and not any(x in aty_checks for x in P11A['checks']), 'cc.* then sp.* last on the entry atiyah, no fr.*'

# ===================================================================================================================== 8 the Atiyah page
rel = 'public/reports/analyses/src/atiyah_lens.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md
AN = {}
for P in (P11C, P11B):   # in the order of the items: 34 (11c), 35 (11b)
    an = P['C']['analyses'][0]
    assert an['source'] == rel and an['section9_numbering'].startswith(f"R6: {{n}} = {P['n']},"), an['section9_numbering']
    AN[P['name']] = (an, (lambda n: lambda s: s.replace('{n}', str(n)))(P['n']))

# section 9's items 34 (11c) and 35 (11b), after item 33
items = []
for P in (P11C, P11B):
    an, fill = AN[P['name']]
    its = [fill(s) for s in an['section9_items']]
    assert len(its) == 1 and its[0].startswith(f"{P['n']}. ") and '\n' not in its[0] and '{n}' not in its[0], P['name']
    items += its
lines = md.split('\n')
i33 = next(i for i, l in enumerate(lines) if l.startswith('33. *The branching of the 16*'))
if lines[i33 + 1:i33 + 1 + len(items)] != items:
    assert not any(l.startswith(('34. ', '35. ')) for l in lines), 'an item 34 or 35 stands elsewhere'
    lines[i33 + 1:i33 + 1] = items
md = '\n'.join(lines)

# the edits, 11c's seven and 11b's five. Where both passes find one sentence of 2.13.0 (the numbering sentence, the scripts of the sources, the sources
# of section 9) the two are composed into one replacement, in the order of the items (11c's clause, then 11b's), which a second run finds in place;
# the clauses of the first paragraph have their own anchors (11c's after the rows of null_stages.py, 11b's after those of branching_16.py); the list of
# what is not done takes 11c's two edits, the learner texts' with 11b's rows added (11b leaves that paragraph to the release owner)
WHERE_C = ['section 5, theme 1, *The Atlas.*', 'section 9, first paragraph', 'section 9, first paragraph', 'section 9, the list of what is not done',
           'section 9, the list of what is not done', 'Sources, the Atlas', 'Sources, section 9']
WHERE_B = ['section 5, theme 6, *The Atlas.*', 'section 9, first paragraph', 'section 9, first paragraph', 'Sources, the Atlas', 'Sources, section 9']
(ec, fill_c), (eb, fill_b) = AN['11c'], AN['11b']
assert [e['where'] for e in ec['edits']] == WHERE_C and [e['where'] for e in eb['edits']] == WHERE_B
c1, c2, c3, c4, c5, c6, c7 = [(e['find'], fill_c(e['replace'])) for e in ec['edits']]
b1, b2, b3, b4, b5 = [(e['find'], fill_b(e['replace'])) for e in eb['edits']]
# the numbering sentence: "32 pass 10c, 33 pass 10b." -> ", 34 pass 11c" (11c), then ", 35 pass 11b" before the full stop (11b's note)
assert c3[0] == b3[0] == '32 pass 10c, 33 pass 10b.' and c3[1] == c3[0][:-1] + ', 34 pass 11c.' and b3[1] == b3[0][:-1] + ', 35 pass 11b.', (c3, b3)
numbering = (c3[0], c3[1][:-1] + b3[1][len(b3[0]) - 1:])
# the learner texts not written: the rows of items 30 to 35 (11c's edit names items 30 to 33 and 34; 11b's rows FUR-033 to FUR-037 join them)
OLD_ND = ('learner texts for the rows of items 30 to 33 (GEN-017 to GEN-026, FUR-007 to FUR-014 and FUR-020 to FUR-026;',
          'learner texts for the rows of items 30 to 35 (GEN-017 to GEN-032, FUR-007 to FUR-014, FUR-020 to FUR-026 and FUR-033 to FUR-037;')
assert OLD_ND[0].startswith(c5[0]) and c5[1] == 'learner texts for the rows of items 30 to 33 and 34 (GEN-017 to GEN-032,', c5
not_done = OLD_ND
# the scripts of the sources: both passes add their script after branching_16.py
assert c6[0] == b4[0] and c6[1] == c6[0].replace('`branching_16.py` with', '`branching_16.py`, `chain_closure.py` with') \
    and b4[1] == b4[0].replace('`branching_16.py` with', '`branching_16.py`, `spinor_pairings.py` with'), (c6, b4)
scripts = (c6[0], c6[0].replace('`branching_16.py` with', '`branching_16.py`, `chain_closure.py`, `spinor_pairings.py` with'))
# the sources of section 9: both passes extend the sentence that ends with Fulton and Harris, 11c's clause (item 34) first
F9 = c7[0]
assert F9 == b5[0] and F9.endswith('.') and c7[1].startswith(F9[:-1] + '; for item 34,') and b5[1].startswith(F9[:-1] + '; for item 35,') \
    and c7[1].endswith('.') and b5[1].endswith('.'), (c7, b5)
sources9 = (F9, F9[:-1] + c7[1][len(F9) - 1:-1] + b5[1][len(F9) - 1:])
plan = [('theme 1 (11c)', *c1), ('theme 6 (11b)', *b1), ('section 9, first paragraph (11c)', *c2), ('section 9, first paragraph (11b)', *b2),
        ('section 9, the numbering (11c, 11b)', *numbering), ('section 9, not done: the paper of ABS (11c)', *c4),
        ('section 9, not done: the learner texts (11c, with 11b)', *not_done), ('Sources, the Atlas (11c, 11b)', *scripts),
        ('Sources, section 9 (11c, 11b)', *sources9)]
for where, find, repl in plan:
    assert '{n}' not in repl and not re.search(r'\bR[2-6]:', repl), where
    md = swap(md, find, repl, where)

# section 7, the lens record: the entries of the dictionary, those from the checks of section 9 (their source names a pass), the readings
n_dict = len(aty_dict)
n_sec9 = sum(1 for e in aty_dict if re.search(r'\(pass [^)]*\)$', e['from']))
assert (n_dict, n_sec9) == (107, 36), (n_dict, n_sec9)
assert md.count('28 entries from the narrative and the map above, 43 from the five readings,') == 1 and 28 + 43 + n_sec9 == n_dict
for pat in (r'carries a dictionary of \d+ entries', r'\d+ from the checks of section 9\.', r'The result is \d+ readings on \d+ rows\.'):
    assert len(re.findall(pat, md)) == 1, pat
md = re.sub(r'carries a dictionary of \d+ entries', f'carries a dictionary of {n_dict} entries', md)
md = re.sub(r'\d+ from the checks of section 9\.', f'{n_sec9} from the checks of section 9.', md)
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')

# section 9, what is not done: the learner texts not written are those of the rows of items 30 to 35, deferred to the story round (docs/round13/PLAN.md:
# no learner texts this round); the rows ATY-001 ... ATY-055 and GEN-010 ... GEN-016 have learner drafts
learner = {t['row'] for t in texts if t['level'] == 'learner'}
aty = sorted(i for i in ids if i.startswith('ATY-'))
assert aty == [f'ATY-{k:03d}' for k in list(range(1, 48)) + list(range(51, 56))], 'the ATY rows the sentence names'
assert all(i in learner for i in aty + [f'GEN-0{k}' for k in range(10, 17)]), 'a row the sentence says has a learner draft has none'
item_rows = G(17, 32) + [f'FUR-0{k:02d}' for k in range(7, 15)] + F(20, 26) + F(33, 37)
assert not any(i in learner for i in item_rows + P11A['ids']), 'a row of items 30 to 35 (or of pass 11a) has a learner text: the sentence must say so'

for must in items + [p[2] for p in plan] + ['32 pass 10c, 33 pass 10b, 34 pass 11c, 35 pass 11b.', f'carries a dictionary of {n_dict} entries',
                                            f'{n_sec9} from the checks of section 9.', 'learner texts for the rows of items 30 to 35 (GEN-017 to GEN-032,']:
    assert md.count(must) == 1, must[:90]
assert md.count('section 9 item 34)') == 1 and md.count('section 9 item 35)') == 1, 'theme 1 points to item 34, theme 6 to item 35'
assert md.index('(six rows, GEN-021 to GEN-026)') < md.index('(six rows, GEN-027 to GEN-032)') < md.index('(seven rows, FUR-020 to FUR-026)') \
    < md.index('(five rows, FUR-033 to FUR-037)') < md.index('Items 1 to 10 are pass five'), 'the clauses in item order'
assert md.index('\n33. *The branching of the 16*') < md.index('\n34. *The standard routes closed') < md.index('\n35. *The spinors of the total cell*') \
    < md.index('\nNot done: '), 'items 34 and 35 after item 33, before the list of what is not done'
assert not any(p in md for p in ('{n}', 'R6:', 'R5:', 'R4:', 'R2:', 'N readings on M rows', 'furey_cl6.py', 'furey_roadmap.py')), \
    'a placeholder, a note of the passes, or pass 10a or 11a on the page'
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 9 the page
if not NO_NODE:
    out = subprocess.run(['node', 'tools/make_analysis.mjs', 'atiyah'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
