<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# A shifted view, read on the labels

Atiyah and Moore's *A shifted view of fundamental physics* (2010), followed step by step with the Atlas's computations.

> **For the owner: from this text to a paper of his own.** The text below is the Atlas's analysis page `public/reports/analyses/src/shifted_view.md` as it ships (rendered to `public/reports/analyses/shifted_view.html` by `tools/make_analysis.mjs`), kept here as a repository document. It becomes a paper of the owner's own when every sentence is sorted into one of four kinds. **The Atlas's computation** is every result cited with a row whose status is *proved by the Atlas* (ATY-004 to ATY-010, ATY-037 to ATY-041, with EQN-008, MAP-018 and LNS-017e): such a result can be stated as a result, within the scope its row prints, with `shifted_dirac.py`, `shifted_weakfield.py` and `shifted_energy.py` and their logs as the evidence any reader can run again. **His reading** is everything marked *our reading* (ATY-011; the quarter turn as the mechanism of the quantization; the shift as a clock; the scalar part of the energy as the physical energy; $D_s$ as the variant that chirality would need; the cosmological constant as an input moved from $c$ to $k$; the lattice $\cos E\tau = 0$ seen three times as one structure): the Atlas proposes these and claims none, so in a paper each one becomes a claim only where the owner writes it, in his words and under his name, or it stays marked as a proposal. **What he must still decide:** whether the paper rewrites Atiyah and Moore's, keeping their nine steps with his results in each, or stands on its own and cites theirs; how to present the result against (2.12)–(2.14), as the rows state it (the coupling equals the Noether energy; per unit density the deviation is a $J$ part), and whether to ask Moore first what an equivalence-principle test of a shifted fermion would weigh; what physical meaning, if any, he gives to a $J$-valued energy and to the Hermitian half's mode of negative number; whether the magnitudes and the measured inputs (MICROSCOPE, KATRIN) belong in the paper at all, since the Atlas computes none of them; which open items to compute before writing (the tensor for fields that depend on space, a potential with a gradient); and the title. **Where his co-author's voice goes:** Atiyah and Moore's paper has two voices, a prologue in the first person signed by Atiyah and a joint body; a paper of the owner's can keep that shape, with step 1 as a prologue in the voice of the author who writes it, a closing note in the co-author's own voice if the co-author wants one, and steps 2 to 9 with the three questions in a joint "we" in which every sentence either cites a row or is marked as the authors' reading. Atiyah's reasoning, step by step, is in `docs/round9/SHIFTED_VIEW_NARRATIVE.md`, and the literature with its verified addresses in `docs/round9/SHIFTED_VIEW_SOURCES.md`. The Atlas writes no claim in his name.

**What this page is.** Michael Atiyah and Gregory Moore propose relativistic delay equations: the Dirac operator is exponentiated, so that one equation retards one sign of frequency and advances the other. This page follows the paper's own reasoning, in its order, in nine steps, and sets the Atlas's computations beside each step. Each step has three parts. *The move* is the paper's reasoning at that step, in the Atlas's words: why it follows from the step before, and what kind of argument it is. *On the labels* is what the Atlas computes at that step: the rows, their status, the numbers they carry and the checks. Where the labels give something other than the printed page, this page gives what the paper prints and what the labels give, and keeps both. *Taken forward* is what the labels add that the paper does not state, each item marked as a reading or as open, never as a claim. The paper's three closing questions follow, answered as far as the rows go; then the work that cites the paper, and what this reading does not do.

**How to read the references.** Equation numbers such as (2.12) and page numbers are the paper's, as printed on its arXiv version. A row id such as ATY-005 is a statement of the Atlas, with its research text in the Atlas's tables. A check id such as `shd·QNT` is a line of one of three scripts under `checks/selfcheck/proofs/`: `shifted_dirac.py` (`shd·…`), `shifted_weakfield.py` (`wf.…`) and `shifted_energy.py` (`en.…`), with their logs and fault logs in `checks/selfcheck/proofs/logs/`. Each script has three kinds of lines: a route on the labels, a standard route that never touches them (complex Dirac matrices and scipy), and wrong versions that must fail (each `--fault` option ends its run with exit 1).

**Status words.** In each part *On the labels*, and in each of the three questions, a row carries its status at its first mention: *proved by the Atlas* (a recorded run of the row's checks passed), *our reading* (a reading the Atlas proposes, not a result), *needs an input* (a choice or datum the labels do not supply), *open* (not established). Every ATY row cited here carries the badge *new*. ATY-038 to ATY-041 are the rows of `shifted_energy.py`, whose recorded run passed (62 checks, 0 fail). A fact marked *recalled* or *standard* is taken from textbooks, not checked here.

**Notation.** The Atlas computes in the labels of $\mathrm{Cl}(1,3)$, with $J = \gamma_2\gamma_1$ in the place of the paper's $i$ (MAP-018, proved by the Atlas), in units $\hbar = c = 1$, with the shift $\tau$ for the paper's $r$, the strength $\kappa$ for its $k$, and $\mu = \kappa\tau$ for its $kr/\hbar$. On even spinors the paper's $D$ becomes $𝐃\psi = (\nabla\psi)\gamma_0$ (written bD in the rows), and its equation (2.2) reads

$$𝐃\psi J - m\psi + \kappa\,\bigl(e^{-\tau𝐃}\psi\bigr)J = 0 .$$

The paper's one-dimensional equations keep its own letters $k$, $r$ and $\mu = kr$.

## The steps at a glance

| Step | The paper | On the labels |
|---|---|---|
| 1. Where new ideas come from | section 1, pp. 1–2: the licence to speculate | nothing to compute |
| 2. One simple equation | section 2, p. 3: (2.1), its data, its roots | the energy of (2.1); its oscillation at odd quarter periods (ATY-038, ATY-041) |
| 3. Relativity forces the Dirac operator | section 2, pp. 3–4: (2.2), (2.3) | the shift as a right factor, a retard and an advance (ATY-005, ATY-006, ATY-041) |
| 4. What the plane waves say | section 2, pp. 4–5 and 8: (2.5)–(2.9) | the quantization, exactly; the quarter turn (ATY-004, ATY-005, ATY-009) |
| 5. A deviation to measure | section 2, pp. 5–6: (2.10)–(2.15) | proper time on a frame; the energy equals the coupling; (2.12) not reproduced (ATY-037, ATY-038, ATY-039) |
| 6a. The formal family | section 2.1, pp. 6–7: (2.3), (2.16) | the variants; the formal series; two halves of one operator (ATY-007, ATY-010, ATY-039) |
| 6b. The mixed equation | section 2.2, pp. 7–8: (2.17), (2.18) | (2.17) as the cosh part; its roots; the beat (ATY-038, ATY-040, ATY-041) |
| 6c. What was not tried | section 2.3, p. 8 | gauge covariance in a constant potential (ATY-008) |
| 7. Shift the Einstein equations | section 3, pp. 8–11: (3.1)–(3.11) | the constant terms behind the cosmological constant; the magnitudes not computed (ATY-010) |
| 8. Einstein–Maxwell by Kaluza–Klein | section 4, pp. 11–12: (4.1)–(4.4) | a match of structure only (ATY-010, LNS-017e) |
| 9. Two constants, two ends; three questions | section 5, p. 13: (5.1)–(5.4) | the quantization exact; the magnitudes not computed |

## Step 1. Where new ideas come from

*Section 1, pp. 1–2.*

### The move

The paper opens with a prologue in Atiyah's own voice, and the prologue does two jobs before any equation. It places the reader in a history: a geometric line from Newton through Maxwell to Einstein, a quantum theory far from geometry, and a fusion of geometry and physics to which Singer and Atiyah belong. It names the problem of the age: general relativity and quantum mechanics apart. It grants string theory its gifts to mathematics and notes how thin its contact with experiment is. It names two challenges from astronomy: dark matter, and a dark energy with a very small cosmological constant. Then it asks who can afford radical ideas, and answers: not the young, whose careers the weight of orthodoxy would punish, but the old, who have little to lose. The step earns the licence to speculate, and it plants the target that the paper reaches at its end, a small cosmological constant.

*The kind of argument:* a historical framing and an argument from the speaker's situation, not from physics; a declaration of genre (speculation, offered as a birthday present to Singer); the precedent of Einstein's long dispute with Bohr.

### On the labels

The Atlas computes nothing here. In place of a licence to speculate it states its objective and its reach. It reads this paper because its labels carry the Dirac operator exactly, as the equation $\nabla\psi J = m\psi\gamma_0$ (EQN-008, proved by the Atlas), so a shift of the Dirac operator can be computed on them exactly. Its method: write down first what its own rows lead it to expect, then read the paper with background knowledge set to noise; give every claim a route on the labels, a standard route and controls that must fail; keep a negative result as one. From its rows alone the Atlas expects that a shift acts on a plane wave as a phase on the right, that a retarded term alone puts the plane waves on a lattice of quarter turns, and that an advanced term beside it makes the factor real; steps 3 and 4 check these expectations. What the labels cannot reach is named at each step: packets of more than two frequencies, frames beyond a constant potential, the Weitzenböck identity as a theorem, the magnitudes of the paper's estimates. The Atlas does not speculate in its own voice; a reading is marked *our reading*.

### Taken forward

- *Our reading.* The licence to speculate becomes, on this page, a rule in three parts: the paper's move, the result on the labels, and what stays open.
- *Our reading.* The prologue's implicit question, whether a geometric idea rather than a quantum one can join the two theories, is the paper's third question (step 9).
- *Open.* The prologue's two challenges, dark matter and dark energy: the Atlas computes neither.

## Step 2. One simple equation

*Section 2, p. 3.*

### The move

With the licence granted, the paper takes a minimal instance of the idea, one linear equation with one delay:

$$\dot x(t) + k\,x(t-r) = 0. \tag{2.1}$$

Rescaling time leaves one dimensionless number, $\mu = kr$. Two properties follow. The data that fix a solution are a whole function on an interval of length $r$, an infinite-dimensional space, $L^2[0,r]$; the paper sees in this a likeness to quantum mechanics and does not pursue it. And the exponential solutions $x = x_0e^{-zt/r}$ need $z = \mu e^z$, an equation with infinitely many roots whose real parts are, in general, not zero, so that solutions blow up in the far past or the far future. The paper keeps the likeness as a motive and parks the defect. The step ends on the question that drives the rest: can such an equation make sense in relativity, where no direction of time is preferred?

*The kind of argument:* a worked toy example, an analogy (data like a Hilbert space) and a named defect. The paper credits the theory of delay equations to engineers and mathematicians, and names three origins in physics: Feynman's thesis, Bjorken and Drell (a granular spacetime would call for such equations) and Raju (such equations in quantum mechanics), with a contribution of Atiyah's to the Solvay conference of 1984.

### On the labels

- **The energy of (2.1)** (ATY-038, proved by the Atlas; `en.DELAY`). With an auxiliary field $y$ that obeys the advanced adjoint equation $\dot y = k\,y(t+r)$, the Lagrangian $L = y\,\bigl(\dot x + k\,x(t-r)\bigr)$ has a Noether energy with a local part and a bilocal part over the delay interval:

  $$E = -k\,y(t)x(t-r) - k\int_{t-r}^{t} y(s+r)\dot x(s)\,ds.$$

  It is constant exactly on 12 piecewise polynomial solutions built by the method of steps ($\mu = 1/2, 3/2, -2/3, 3/2$). On exponential solutions it is $(z/r)(z-1)$ per root (20 roots by scipy lambertw), with zero cross terms between two roots. On smooth data integrated by solve_ivp it is constant to $10^{-12}$. The local part alone is not constant: a control that fails.
- **When (2.1) oscillates** (ATY-041, proved by the Atlas; `en.OSC`). A wave $x = e^{-J\omega t}$ solves (2.1) exactly when $\cos\omega r = 0$, with $k = (-1)^n\omega$ at $\omega r = (n+\tfrac12)\pi$, that is at $\mu = (-1)^n(n+\tfrac12)\pi$: exact in the plane of $J$ at the eight quarter turns. The roots of $z = \mu e^z$ are $z = -W(-\mu)$ on the branches of Lambert's function (standard), and scipy lambertw finds the pair $z = \pm i(n+\tfrac12)\pi$ at $\mu = \pi/2, -3\pi/2, 5\pi/2$. At $\mu = 1, 2, \pi/2 \pm 0.05$ and $-1$, where the delay is not an odd quarter period, every root on the branches $-3,\dots,3$ has $|\mathrm{Re}\,z| \ge 0.022$. So the defect has exact exceptions: at these values of $\mu$ a solution neither grows nor decays.
- **The data space.** The Atlas computes nothing on the likeness of $L^2[0,r]$ to a space of quantum states.

### Taken forward

- *Our reading.* The quarter-period condition: (2.1) has a solution that neither grows nor decays exactly when its delay is an odd number of quarter periods, $\cos\omega r = 0$ (ATY-041). This is the form of the paper's quantization of step 4, read on its one-dimensional equation; the paper names the defect, not the exception. It ties step 2 to step 4.
- *Our reading.* The delay equation has a conserved energy with a term spread over the delay interval (ATY-038): the shape that step 5 finds for the shifted Dirac action and step 6b for Feynman's equation.
- *Open.* Whether the infinite-dimensional data have anything to do with quantum states; the runaway roots at a generic $\mu$.

## Step 3. Relativity forces the Dirac operator

*Section 2, pp. 3–4.*

### The move

To delay in Minkowski space the paper needs a form of the translation in time that no frame singles out. It writes the translation by $r$ as the exponential of its generator, $\exp(-r\,d/dt)$. The question becomes: what is the relativistic form of $d/dt$, a first-order operator invariant under the Lorentz group? That is Dirac's own question, and its answer is the Dirac operator. So the shift is the exponential of the Dirac operator, it acts on spinors, and the relativistic form of (2.1) is

$$\bigl(i\hbar D - mc + ik\,e^{-rD}\bigr)\psi = 0. \tag{2.2}$$

The paper then defends its meaning. A field slower than light is a sum of plane waves, and on each the exponential delays the wave by $r$ along the wave's own direction of time; a wave at the speed of light admits no delay, by continuity or by clocks. And since spinors carry both signs of frequency, the same operator delays one sign and advances the other. Hence the neutral name "shifted", and four variants $D_+$, $D_-$, $D_s$, $D_c$ (2.3), of which the paper follows $D_+ = D + (k/\hbar)\,e^{-rD}$.

*The kind of argument:* a symmetry requirement met by a choice the paper presents as forced; an analogy borrowed from Dirac's own motive; an argument from physical meaning on plane waves.

### On the labels

- **The shift is a right factor** (ATY-005, proved by the Atlas). The even operator $𝐃$ squares to $-Q(k)$ on every plane-wave sector, at $n = 3, 4, 5$, for timelike, spacelike and null $k$ (`shd·OP`); so on a frequency with $Q(k) = E^2 > 0$,

  $$e^{-\tau𝐃} = \cos E\tau - \frac{\sin E\tau}{E}\,𝐃,$$

  and scipy expm agrees to $4.6\cdot10^{-14}$. The ordinary equation has its plane waves exactly on the shell $Q = m^2$, $2^{n-2}$ real dimensions per sector (`shd·ORD`). On the ordinary solutions of mass $E$,

  $$e^{-\tau𝐃}\psi = \psi\,e^{JE\tau},$$

  the translation by $\tau$ along $k/E$ for the waves $e^{-Jk\cdot x}$ and by $-\tau$ for the waves $e^{+Jk\cdot x}$ (`shd·OWN`; Dirac matrices agree in 24 cases to $1.7\cdot10^{-15}$). A retard and an advance in one space of solutions: the paper's claim, exactly.
- **No delay at the speed of light** (ATY-005; `shd·NUL`). At a null frequency $𝐃^2 = 0$ and $e^{-\tau𝐃} = 1 - \tau𝐃$, a Jordan block, the identity on the massless solutions only. There is no plane wave of the shifted equation unless $m = \kappa = 0$.
- **A device bound to no frame** (ATY-006, proved by the Atlas; `shd·COV`). The covariant shift of the whole mass term, $iD\psi = m\,e^{-\tau D}\psi$, has exactly the ordinary solutions of mass $m$ at one Compton period, $\tau = 2\pi/m$, exactly those of mass $-m$ at half a period, and none at $\tau = \pi/(2m)$ or at a rational point of the circle, in each of four frames tried ($m = 4$). A fixed time shift by one Compton period keeps the rest wave and loses the moving wave $k = (5,3,0,0)$: a fixed shift vector is bound to a frame.
- **At rest, half and half** (ATY-041, proved by the Atlas; `en.REST`). On fields of the frame time alone,

  $$e^{-\tau𝐃}P = P_+(t-\tau) + P_-(t+\tau)$$

  exactly: the half of $P$ that commutes with $\gamma_0$ is retarded and the half that anticommutes is advanced, for every field of $t$, not only for plane waves (9 polynomial fields of degree 5; Dirac matrices with scipy expm on a three-frequency field agree to $3\cdot10^{-15}$). With $X = P_+e^{Jmt}$ the $P_+$ half of the paper's equation at rest is $\dot X + \kappa e^{Jm\tau}X(t-\tau) = 0$, which is (2.1) with $k = \kappa$ when $m\tau \in 2\pi\mathbb{Z}$; the $P_-$ half is the advanced equation $\dot X = \kappa e^{Jm\tau}X(t+\tau)$, the adjoint of (2.1) (exact in $\mathbb{Q}[\pi]$ at three settings of $(m,\tau,\kappa)$).
- **A second reason** (ATY-011, our reading). Not in the paper and not computed: a translation is unitary and its adjoint is the opposite translation (recalled), so a shifted term in an action brings both; and the orthochronous Lorentz group alone does not force the pairing, since time reversal swaps the two sheets of $a^2 = \tau^2$.

### Taken forward

- *Our reading.* The shift is a phase on the right, $e^{JE\tau}$, and the sign of the frequency decides whether it retards or advances (ATY-005). The paper's remark that its retarded equation is also an advanced one becomes, at rest, a statement about the two halves of one spinor: the half that commutes with $\gamma_0$ is retarded, the other half advanced (ATY-041).
- *Our reading.* The toy (2.1) is more than an analogy: it is the $P_+$ half of $D_+$ at rest, and its advanced adjoint is the $P_-$ half (ATY-041).
- *Open.* What $e^{-\tau D}$ means on fields that are neither plane waves nor fields of time alone, where its series runs over a spectrum of both signs; which variant, if any, describes a particle.

## Step 4. What the plane waves say

*Section 2, pp. 4–5, with remark 3 of section 2.3, p. 8.*

### The move

A new equation is tested first on plane waves. On a plane wave the shift becomes a phase, and the equation (2.5) splits into a real part and an imaginary part; since $k$ and $r$ are real, the imaginary part forces $\cos(rE_0/\hbar c) = 0$. The delay is quantized, (2.6)–(2.7):

$$\frac{rE_0}{\hbar c} = \Bigl(n+\frac12\Bigr)\pi, \qquad r = \frac{2n+1}{4}\,\lambda_C .$$

The half-integer excludes $r = 0$, which the paper reads as the reason for the factor $i$ in (2.2); replacing $n$ by $n-1$ is the same as changing the sign of $k$, so both signs count; a massless fermion admits no solution. Then a choice: one delay per fermion, which makes the interaction of different fermions awkward, or one universal delay. The paper takes the universal one and draws its consequences. The delay is at least a quarter of the Compton wavelength of every stable fermion, so the lightest neutrino sets the bound; with a mass of 1 eV this gives $r \gtrsim 10^{-5}\,\mathrm{cm}$ (2.8), a scale the paper finds large, so that neutrino's integer is of order one. The rest energy is

$$E_0 = mc^2 + (-1)^n kc, \tag{2.9}$$

which the paper reads as the link between the inertial rest energy and the parameters of the equation, not as a departure from Einstein's relation. Among the later remarks: the Compton wavelengths of any two stable fermions stand in the ratio of two odd integers, which neutrino masses might one day test.

*The kind of argument:* a calculation of one line; a choice between interpretations guided by consistency (fermions must interact); an estimate set by the neutrino scale; a speculation in a footnote (the half-integer and the zero-point energy of an oscillator).

### On the labels

- **The quantization, exactly** (ATY-005, proved by the Atlas; `shd·QNT`). Plane waves of the shifted equation exist exactly when

  $$\cos E\tau = 0, \qquad E = m + \kappa\sin E\tau ,$$

  so $E\tau = (n+\tfrac12)\pi$, $E = m + (-1)^n\kappa$ and $\tau = (2n+1)\lambda_C/4$ with $\lambda_C = 2\pi/E$: the paper's (2.6), (2.7) and (2.9). They are the ordinary solutions of mass $E$, $2^{n-2}$ real dimensions per sector at $n = 3, 4, 5$ ($m = 3$, $\kappa = 2$: $E = 5$ at $E\tau = \pi/2$, $E = 1$ at $E\tau = 3\pi/2$). There are none at $\tau = 0$, at $\tau = \lambda_C/2$ or $\lambda_C$, or at rational points of the circle; $n \to n-1$ is $\kappa \to -\kappa$; for $\kappa > m$ a second branch $E = \kappa\sin E\tau - m$ lies on the other half ($m = 1$, $\kappa = 4$: $E = 3$). Without the factor $i$ there is no solution at the quantized point and there is one at $\tau = 0$: a control that fails, and on the labels the role of the $i$, which moves the lattice by a quarter turn and excludes $\tau = 0$.
- **The quarter turn** (ATY-009, proved by the Atlas; `shd·BIL`). At the quantized shift $E\tau = \pi/2$ the shifted solution is $\psi J$. The current $\psi\gamma_0\tilde\psi$ and the spin vector $\psi\gamma_3\tilde\psi$ are unchanged; $\psi\gamma_1\tilde\psi$ and $\psi\gamma_2\tilde\psi$ change sign: a quarter turn of $\psi$ and a half turn of its frame ($m = 3$, $\kappa = 2$, $E = 5$, $k = (13,12,0,0)$; at the rational point $(3/5, 4/5)$ the frame turns by $-2\theta$; the products of Dirac matrices agree to $1.4\cdot10^{-14}$). The mechanism in one line: at $E\tau = (n+\tfrac12)\pi$ the right factor is $e^{JE\tau} = (-1)^nJ$, so the shift term $\kappa\bigl(e^{-\tau𝐃}\psi\bigr)J = (-1)^n\kappa\,\psi J^2 = -(-1)^n\kappa\,\psi$ is a real mass term, and the equation is the ordinary one of mass $m + (-1)^n\kappa$.
- **The whole mass term shifted** (ATY-004, proved by the Atlas; `shd·RET`, `shd·SYM`). Shifting the whole mass term by a fixed vector instead, $\nabla\psi J = m\,\psi(x-a)\gamma_0$, puts the plane waves on the lattice $\theta = k\cdot a \in (\pi/2)\mathbb{Z}$: the ordinary solutions at $\theta = 0$, those of mass $-m$ at $\theta = \pi$, a spacelike shell $Q = -m^2$ at the odd quarter turns, none at rational points of the circle (72 cases). With the advanced term beside it, $(m/2)\bigl(\psi(x-a) + \psi(x+a)\bigr)$, the factor is $\cos\theta$, a real number, and the solutions fill the shell $Q = m^2\cos^2\theta$.
- **The estimates.** The Atlas computes nothing here: the bound (2.8) and the odd-integer ratios rest on measured masses, which are inputs and not outputs of the labels. A check would take the masses as inputs and bound the integers. The input of (2.8), as its source states it: KATRIN reports $m_\nu < 0.45\ \mathrm{eV}$ at 90 % confidence, and a quarter of the Compton wavelength at that mass is $hc/(4\times0.45\ \mathrm{eV}) \approx 6.9\times10^{-5}\,\mathrm{cm}$, so with that input the paper's estimate reads $r \gtrsim 7\times10^{-5}\,\mathrm{cm}$ (the arithmetic of the literature survey, not a result of the Atlas).

### Taken forward

- *Our reading.* The quarter turn: the quantization is the condition that the shift act on the solution as a quarter turn, $e^{JE\tau} = \pm J$; the label $J$ that turns the wave plays the part of the paper's $i$, and the factor $i$ turns the quarter turn back into a real mass (ATY-005, ATY-009). The lattice of quarter turns returns when the whole mass term is shifted by a fixed vector (ATY-004), and in one dimension as the delays at which (2.1) oscillates (ATY-041, step 2).
- *Our reading.* The second branch $E = \kappa\sin E\tau - m$ for $\kappa > m$ lies on the other half of the spinor; the paper does not discuss it (ATY-005).
- *Open.* Each fermion's integer $n$; the meaning of the half-integer; the size of $r$; the odd-integer ratios against measured masses.

## Step 5. A deviation to measure

*Section 2, pp. 5–6.*

### The move

A modified equation must depart from known physics somewhere, and the paper looks where measurement is precise: the equivalence principle. It writes the action

$$\int \mathrm{vol}\;\bar\psi\,\bigl(i\hbar D_+ - mc\bigr)\psi, \tag{2.10}$$

says that the energy-momentum tensor follows from it, and places it in a weak static field, $ds^2 = -(1-2\Phi)\,dt^2 + dx^i dx^i$ (2.11), where the Dirac operator is, to first order, $\gamma\cdot\partial + S$ with $S = \Phi\gamma^0\partial_0 + \tfrac12\gamma_i\partial_i\Phi$. It reads the coefficient of the Newtonian potential $\Phi$ on the rest solutions as the gravitational rest energy, (2.12), with the constant (2.13):

$$T_{00} = E_0\bigl(1 - \mu(-1)^n\bigr), \qquad \mu = \frac{kr}{\hbar}.$$

So the gravitational and the inertial rest energy differ by the fraction $(-1)^{n+1}\mu$ (2.14). The limit on violations of the equivalence principle, about $10^{-13}$, bounds $\mu$; with the $r$ of step 4 it bounds $k/\hbar$ below $10^{-8}\,\mathrm{cm}^{-1}$ (2.15). The paper then makes $\mu$ a fundamental constant of its theory, binding the shift and the strength through Planck's constant.

*The kind of argument:* a calculation announced by its result, with no intermediate step printed; an experimental bound; dimensional bookkeeping. What the step leaves: the tensor of a nonlocal action, said to be derivable and not written.

### On the labels

- **The frame, and proper time** (ATY-037, proved by the Atlas; `wf.FRAME`, `wf.CONN`). The orthonormal coframe of $(1-2\Phi)\,dt^2 - dx^2$ is $e^0 = N\,dt$, $e^i = dx^i$ with $N = \sqrt{1-2\Phi}$, and the Dirac operator of the metric is $D_g = N^{-1/2}D'N^{1/2}$ with $D' = N^{-1}\gamma^0\partial_t + \gamma^i\partial_i$. The connection term is the second term of the paper's $S$, removed by the conjugation (its sign a matter of conventions); the frame factor $a = 1/N$ is the first (exact on 12 random fields; the vierbein formula in numpy agrees to $10^{-13}$). For a constant $\Phi$ the shifted equation on a plane wave is the flat one at the frame frequency. With $1 - 2\Phi = (p/q)^2$ and $a = 2, 5/3, 5/4, 8/7, 4/5$ its plane waves sit at the coordinate rest frequency $E\sqrt{1-2\Phi}$, with $E\tau = (n+\tfrac12)\pi$ in proper time; there are none at the coordinate frequency $E$ or $aE$, and none with the shift read in coordinate time; the ordinary equation is redshifted by the same factor. The quantization follows proper time, and the coordinate rest energy is $E_0\sqrt{1-2\Phi}$ for every $n$: the redshift of any clock.
- **The coefficient of $\Phi$** (ATY-037; `wf.WEIGHT`, `wf.STD`). On the 16 basis solutions of the quantized rest waves the coefficient of $\Phi$ in the paper's operator is exactly

  $$E_0\,P\,\bigl(1 - (-1)^n\mu J\bigr).$$

  Its part along $P$ is $E_0$, for $n$ even and odd alike. The paper's deviation $(-1)^{n+1}\mu E_0$ is its part along the quarter turn $PJ$, which has no scalar part. Dirac matrices with scipy expm give $E_0\bigl(1 - i(-1)^n\mu\bigr)u$, to $10^{-10}$. Reading the $J$ part as a scalar gives (2.12) exactly; that reading is the control READREAL, and it fails as it must. So (2.12) is not reproduced from the printed operator, and the page prints no step from (2.10) to it.
- **The energy** (ATY-038, proved by the Atlas; `en.NOETHER`). The paper writes no energy-momentum tensor. On fields of the frame time alone the shift is a delay (step 3), so the action $\langle Q\,O[P]\rangle_S$, with $O[P] = 𝐃(P)J - mP + \kappa\bigl(e^{-\tau𝐃}P\bigr)J$, $Q$ the conjugate field and $\langle\cdot\rangle_S$ the part in the span of $1$ and $J$, is a Lagrangian with a delayed and an advanced argument. Noether's procedure gives its energy: the canonical part minus a bilocal (Wronskian) integral over the delay interval. Off shell,

  $$\frac{dE}{dt} = -\langle \dot Q\,O[P]\rangle_S - \langle Y\dot P\rangle_S$$

  exactly, on 30 pairs of polynomial fields and for five operators (the paper's, its two halves, $D_c$ and $D_s$), so the energy is conserved wherever the equation and its adjoint $Y = 0$ hold. On the quantized rest modes ($m = 3$, $\kappa = 2$: $E_0 = 5$ at $\tau = \pi/10$, $E_0 = 1$ at $\tau = 3\pi/2$; both sectors) $Q = \tilde P$ solves the adjoint and

  $$E = \rho E_0\bigl(1 - (-1)^n\mu J\bigr), \qquad \rho = \langle\tilde PP\rangle_0 ,$$

  for instance $E = 5 - \pi J$ per unit $\rho$ at $E_0 = 5$, $\mu = \pi/5$. Dirac matrices with quad agree to $2\cdot10^{-15}$. The energy is defined at rest, up to improvement terms.
- **The energy equals the coupling** (ATY-039, proved by the Atlas; `en.HERM`, `en.GRAV`). The paper's operator splits into a Hermitian half and an anti-Hermitian half,

  $$\begin{aligned} iD_+ - m &= H + A, \\ H &= i\bigl(D - \kappa\sinh\tau D\bigr) - m, \\ A &= i\kappa\cosh\tau D, \end{aligned}$$

  where $H$ is $D_s$ with $\kappa \to -\kappa$. The coefficient of $\Phi$ in the action equals the Noether energy on every mode tried, exactly in $\mathbb{Q}[\pi]$, for the paper's operator and for $H$ and $A$ separately: the coupling to a uniform potential is the conserved energy, with ratio 1 (Dirac matrices with central differences and quad agree to $2\cdot10^{-10}$). The scalar part $\rho E_0$ is the energy of $H$. The $J$ part $-(-1)^n\mu\rho E_0$ is the energy of $A$, all of it from the bilocal term: the local part of $A$, $\kappa\cos(E_0\tau)\rho$, vanishes by the same condition $\cos E_0\tau = 0$ that quantizes. Per unit local density the coupling is $E_0\bigl(1 - (-1)^n\mu J\bigr)$, and read with $J$ as a real number this is (2.12). So (2.12) is reached only if the $J$ part is read as a real number and the coupling is compared with $E_0\rho$ instead of with the Noether energy; compared with the Noether energy there is no deviation. The Hermitian half alone has real energies $\rho E\,(1 - \mu\cos E\tau)$ on all its modes, each equal to its coupling; at $\mu = \pi/2$ it has a third rest mode $E = m$ whose Noether number $(1 - \pi/2)|P|^2$ is negative at a positive frequency, outside the paper's range (at $\mu = 0.1, 0.5, 0.9$ and $-0.9$ a scan finds one root; for $|\mu| < 1$ the slope $1 - \mu\cos E\tau$ is positive).
- **The bound.** The Atlas computes nothing about experiments. As its source states it, the final result of MICROSCOPE is $\eta(\mathrm{Ti},\mathrm{Pt}) = [-1.5 \pm 2.3\,(\text{stat}) \pm 1.5\,(\text{syst})]\times10^{-15}$; read as the paper reads (2.14), it would push $\mu$ below about $10^{-15}$. Whether such a test weighs the Noether energy, where the labels find no deviation, or the coupling per unit local density, where they find a $J$ part, is open.

### Taken forward

- *Our reading.* Proper-time quantization: the universal shift is a proper time, not a coordinate time. On a frame the shifted particle's rest energy is redshifted like any clock, for every $n$ (ATY-037): the shift behaves as a clock.
- *Our reading.* The energy equal to the coupling: what the paper calls $T_{00}$ is, on the labels, the conserved Noether energy of its action, and the coupling to a uniform potential equals that energy mode by mode (ATY-038, ATY-039). The paper's deviation (2.14) is the bilocal part of the particle number: a $J$ part, an imaginary number, in the paper's complex theory, and zero at the quantized points of its Hermitian half. That the scalar part, the Hermitian half's energy, is the physical energy is itself a reading.
- *Our reading, not computed.* Why the two agree: on a mode $e^{-J\omega t}$ a time translation is a phase rotation, so the Noether energy is $\omega$ times the Noether number; the coefficient of $\Phi$ dilates every derivative, the shift included, and is $\omega$ times the $\omega$-derivative of the symbol, which the bilocal formula makes equal to the number. The script checks the agreement, not this argument.
- *Open.* The energy-momentum tensor for fields that depend on space, and its Lorentz-covariant bilocal form; how an experiment weighs a $J$-valued term; a potential with a gradient, where the connection term of the frame does not vanish.

## Step 6a. The formal family

*Section 2.1, with remark 1 of section 2.2, pp. 6–7.*

### The move

With one equation in hand, the paper enlarges the family to see what is robust. $D_-$ gives the same results with particles and antiparticles exchanged. $D_s$ and $D_c$ have no quantization, only a transcendental relation among $E_0$, $m$, $k$ and $r$; $D_s$ with $m = 0$ admits massless waves and $D_c$ does not; the equivalence-principle effect is similar for all four. A shifted Klein–Gordon operator is $D_+D_-$, a series in $D^2$ (2.16). Coupled to forms, $d + \delta$ can be exponentiated but does not keep the degree of a form, so Maxwell's equations wait for step 8. Supersymmetry and superspace are flagged. And (2.1) is a skew-adjoint operator plus a unitary one: an element of an "affine operator group", a degenerate form of a semisimple group, as the Poincaré group is a contraction of one.

*The kind of argument:* a catalogue, and a structural analogy (Wigner's contraction).

### On the labels

- **The variants** (ATY-007, proved by the Atlas; `shd·VAR`). Read uniformly as $D_x = D + \kappa f(\tau D)$: $D_-$ has the same plane waves as $D_+$ at the 10 test points, so the exchange of particles and antiparticles is not visible on free plane waves. $D_s$ has solutions of mass $E$ whenever $E = m - \kappa\sin E\tau$, at every point tried, at rest and moving: no quantization; with $m = 0$ it keeps the massless solutions. $D_c$ as printed in (2.3d), with its factor $i$, has solutions exactly where $E = m + \kappa\cos E\tau$ at the points tried: a relation, not a quantization, so the paper's remark holds as printed. Read as $D + \kappa\cosh(\tau D)$, without the $i$, it would carry a quantization, $\cos E\tau = 0$ with $E = m$. Neither reading of $D_c$ has a massless solution.
- **The products as formal series** (ATY-010, proved by the Atlas; `shd·SER`). In one commuting variable $D$, exactly to order 12 at $(\tau,\kappa) = (2/3, 5/7)$ and $(-3/4, 11/2)$:

  $$D_+D_- = D^2 - 2\kappa D\sinh(\tau D) - \kappa^2,$$

  $$(D_+^2)_{\text{even}} = D^2 - 2\kappa D\sinh(\tau D) + \kappa^2\cosh(2\tau D),$$

  $$D_s^2 = D^2 + 2\kappa D\sinh(\tau D) + \kappa^2\sinh^2(\tau D),$$

  with constant terms $-\kappa^2$, $\kappa^2$ and $0$. The first is the paper's Klein–Gordon candidate (2.16).
- **Two halves of one operator** (ATY-039, proved by the Atlas; `en.REST`, `en.HERM`). $D_+$ is the sum of a Hermitian half, the sinh variant with $\kappa \to -\kappa$, and an anti-Hermitian half, the cosh term (step 5): the split holds exactly on polynomial fields at rest, and Dirac matrices give $\gamma^0H^\dagger\gamma^0 = H$ and $\gamma^0A^\dagger\gamma^0 = -A$ to $10^{-15}$.
- **The affine operator group, supersymmetry, $d + \delta$.** The Atlas computes nothing here. A check of the first would need the group generated by $d/dt$ and the shift, and its representations.

### Taken forward

- *Our reading.* The variants are more than alternatives: the paper's operator is the sum of a Hermitian half, built like $D_s$ with the opposite sign of $\kappa$, which carries the energy, and an anti-Hermitian half, the cosh term of $D_c$, which carries the paper's deviation (ATY-039). The paper's remark that the equivalence-principle effect is similar for all four reads, on the labels: for $D_+$ and for each half the coupling equals the conserved energy, and a deviation appears only against $E$ times the local density, as a $J$ part for $D_+$ and as the real factor $1 - \mu\cos E\tau$ for the Hermitian half (ATY-039). $D_-$ and $D_c$ are not computed this way.
- *Our reading.* The constant term $-\kappa^2$ of the Klein–Gordon candidate is the seed of the cosmological term of step 7 (ATY-010).
- *Open.* The affine operator group and its representations; supersymmetry; which variant.

## Step 6b. The mixed equation, and the way toward quantum theory

*Remarks 2 to 4 of section 2.2, pp. 7–8.*

### The move

The relativistic equation is retarded and advanced at once, so the paper returns to one dimension to see what having both does:

$$\dot x(t) + k\bigl(x(t-r) + x(t+r)\bigr) = 0. \tag{2.17}$$

It is not an evolution equation, and the paper finds its theory barely developed. It again has infinitely many exponential solutions, from

$$z = \mu\bigl(e^z + e^{-z}\bigr), \tag{2.18}$$

again with nonzero real parts. Three ways out are glimpsed. As $\mu \to \infty$ the real parts tend to zero and the solutions become anti-periodic with period $2r$, so for large $\mu$ a finite family of acceptable oscillations exists, at least for a while; small and large $\mu$ might be related by a duality, as small and large $r$ are in Fourier theory. For a similar equation, a particle and its virtual image, the paper recalls that Feynman finds a conserved energy. And for the shifted Dirac operator the difficulty comes from mixing the two signs of frequency under external forces, which in quantum field theory is what forces Fock space; so a link to quantum theory would not surprise.

*The kind of argument:* a worked toy again, a limiting argument, an analogy (Fourier duality), a precedent (Feynman) and a conjectured link.

### On the labels

- **(2.17) is the cosh part of the shift** (ATY-041, proved by the Atlas; `en.REST`). On the $P_+$ half at rest, $D_c$ read as $D + \kappa\cosh(\tau D)$ is (2.17) with $k = \kappa/2$ when $m\tau \in 2\pi\mathbb{Z}$; $D_c$ as printed gives the same with the coefficient $(\kappa/2)J$ acting on the right; $D_s$ gives the difference equation $\dot X + (\kappa/2)\bigl(X(t+\tau) - X(t-\tau)\bigr) = 0$.
- **The lattice is the kernel of the symmetric shift** (ATY-041; `en.MIXED`). On rest modes $e^{-JEt}$, $E = 0,\dots,12$, the symmetric shift $\kappa\cosh(\tau𝐃)$ vanishes exactly when $\cos E\tau = 0$, at $\tau = \pi/2, 3\pi/2, 5\pi/2$: the quantization lattice of step 4 is its kernel. On the quarter turns (2.17) has no oscillating solution; the difference equation of $D_s$ has one.
- **The roots and their limit** (ATY-041; `en.MIXED`). Newton's method from a grid ($|\mathrm{Re}\,z| \le 8$, $|\mathrm{Im}\,z| \le 40$) finds 26 roots of (2.18) at each of $\mu = 0.05, 0.3, 1, 5, 50, 500$, none on the imaginary axis (the smallest $|\mathrm{Re}\,z|$ is $0.10$, $0.81$, $0.63$, $0.15$, $1.6\cdot10^{-2}$, $1.6\cdot10^{-3}$): the paper's remark holds at these $\mu$. As $\mu$ grows the roots nearest $i(j+\tfrac12)\pi$ approach it,

  $$\mathrm{Re}\,z = (-1)^j\,\frac{(j+\tfrac12)\pi}{2\mu}\,\bigl(1 + O(\mu^{-2})\bigr)$$

  ($\mu = 50, 500, 5000$; $j = 0,\dots,4$), and $|e^{-2z} + 1| = 0.25$, $0.028$, $0.0028$: the solutions become anti-periodic with period $2r$, at the frequencies $(j+\tfrac12)\pi/r$ of the quantization lattice. Control: the antisymmetric equation $z = \mu(e^z - e^{-z})$ has roots on the imaginary axis ($\mu = 5$).
- **A conserved energy for (2.17)** (ATY-041; `en.MIXED`). The doubled Lagrangian $y\,\bigl(\dot x + k(x(t-r) + x(t+r))\bigr)$ has a Noether energy with two bilocal terms, constant on sums of two roots to $5\cdot10^{-12}$, with zero cross terms. Feynman's conserved energy for his mirror action, as the literature survey reads his thesis (section II.3), needs the motion over a whole window from $t - T_0$ to $t + T_0$: the structure of these bilocal terms. The script does not read the thesis.
- **Two frequencies at one shift** (ATY-038, ATY-040, proved by the Atlas; `en.CONS2`, `en.BEAT`). On two quantized modes at one shift ($(m,\kappa,\tau) = (4,1,\pi/2)$, $(2,-1,\pi/2)$, $(2,1,3\pi/2)$; both sectors) the local energy beats at $E_1 - E_2$ and the bilocal term cancels the beat exactly: the energy is constant, the sum of the two modes' values. Two quantized rest energies $m \pm \kappa$ of one species at one shift force

  $$\kappa\tau = (n_1 - n_2)\,\frac{\pi}{2},$$

  an odd multiple of $\pi/2$ (441 pairs, exact): such a packet needs $|\mu| \ge \pi/2$, and in the paper's range $|\mu| < 10^{-13}$ a species has one quantized rest energy at a given shift. Where the packet exists ($m = 4$, $\kappa = 1$, $\tau = \pi/2$: $E = 5$ and $E = 3$), on four frames of a constant potential ($a = 5/3, 5/4, 2, 4/5$) its density beats at $2\kappa$ per unit proper time, $2\kappa/a$ per unit coordinate time; the beat term changes sign over each shift, $(E_1 - E_2)\tau = (n_1 - n_2)\pi$; and the Noether energy with the volume factor is constant and redshifted by $\sqrt{1-2\Phi}$. The Fourier peak of the sampled density (64 beat periods) lies at $2/a$ within one bin.
- **Fock space.** The Atlas computes nothing here: mixing the two signs of frequency needs a potential with a gradient, where the shifted equation is not computed, or a quantized field with the shifted operator, which this reading does not build.

### Taken forward

- *Our reading.* (2.17) is $D_c$: the paper's mixed toy is the cosh part of its own operator at rest (ATY-041). The lattice $\cos E\tau = 0$ appears three times on the labels: as the condition for plane waves of $D_+$ (step 4), as the kernel of the symmetric shift, and as the limit of the roots of (2.18) as $\mu$ grows. The anti-periodic limit of the paper's remark lands on the quantization of step 4.
- *Our reading.* The beat: two quantized modes of one species beat at $2\kappa$ per unit proper time, a clock that changes sign over each shift; the shift is an odd number of half beat periods (ATY-040). This lies outside the paper's range of $\mu$.
- *Our reading.* At rest the two signs of frequency are the retarded half and the advanced half of one spinor (ATY-041), and on the quantized modes the energy is $\omega$ times the Noether number for the wave $e^{-J\omega t}$ (ATY-038), so the two halves carry energies of opposite sign per unit number. These are the halves that the paper's Fock-space remark would mix under external forces.
- *Open.* The theory of (2.17) on spinors (a mathematical theory of mixed equations exists; see the work since 2010); packets of more than two frequencies; the duality of small and large $\mu$; the link to Fock space.

## Step 6c. What was not tried

*Section 2.3, p. 8.*

### The move

With the family and the toys in hand, the paper measures the distance between its equation and the Standard Model. It has no nontrivial electromagnetic background and no quantum interactions, so none of the successes of quantum electrodynamics (Bhabha and Compton scattering, the Lamb shift, the anomalous magnetic moment) is checked, though interacting string field theories give hope that interactions can be included. It has no massless fermions, so chiral representations of the gauge group and the Higgs mechanism have no obvious place. And it proposes the odd-integer ratios of step 4 as a test.

*The kind of argument:* a statement of what is missing, with one proposed test.

### On the labels

- **A constant potential** (ATY-008, proved by the Atlas; `shd·GAU`). With $m = 3$, $e = 1$, $k = (7,4,0,0)$, $A = 2\gamma_0$ and a gauge change $\lambda = (1,2,0,0)$ with $\lambda\cdot a = \pi/2$: a fixed shift of the mass term has 4 real dimensions of plane waves in one gauge and 0 in the other, so it is not gauge covariant; with the transport factor $\exp(-JeA\cdot a)$ it has 4 in both. The paper's coupled operator $e^{-\tau𝐃_A}$ depends on $k - eA$ only: the same 4 dimensions in both gauges ($m = 2$, $\kappa = 1$, $E = 3$ at $E\tau = \pi/2$). The shifted operator is gauge covariant in the simplest background.
- **The massless sector** (ATY-005 and ATY-007, both proved by the Atlas). $D_+$ has no massless plane wave (`shd·NUL`); $D_s$ keeps the massless solutions at $m = 0$ (`shd·VAR`).
- **Quantum electrodynamics and the Higgs mechanism.** The Atlas computes nothing here. A check would need interacting quantized fields with the shifted operator, which this reading does not build.

### Taken forward

- *Our reading.* If chiral fermions are to be shifted at all, $D_s$ is the variant that admits them (ATY-007).
- *Open.* The processes of quantum electrodynamics; the Higgs mechanism; the odd-integer test.

## Step 7. Shift the Einstein equations

*Section 3, pp. 8–11.*

### The move

Setting aside the link to quantum mechanics, the paper asks whether gravity itself can be shifted. Gravity's operator is of second order, so a bridge from Dirac to Ricci is needed, and the Weitzenböck identity is that bridge: on 1-forms the Hodge Laplacian minus the Bochner Laplacian is the Ricci tensor (3.1), and with $d + \delta$ read as a Dirac operator, $D^2 + \nabla^2 = \mathrm{Ricci}$ (3.2). The vacuum equations then say that two Laplacians agree, and shifting $D$ shifts Ricci. Of the ten ways the paper keeps three (3.3): the square of $D_+$ compressed back onto 1-forms (3.4), since it does not keep the degree; $D_+D_-$; and $D_s^2$. The shifted Einstein equations (3.5) follow. Their meaning is not clear, the paper says, and it proposes to read them as series in $D^2$, that is, as expansions at low energy. At leading order (3.6)

$$\mathrm{Ricci} = -\frac{k^2}{\hbar^2}, \qquad \mathrm{Ricci} = +\frac{k^2}{\hbar^2}, \qquad \mathrm{Ricci} = 0 .$$

That is a cosmological constant $\Lambda = \pm k^2/\hbar^2$, or none. The sign follows from the choice of operator, and the paper grants that this is no success of the approach. The size, matched to the observed $\Lambda \sim 10^{-56}\,\mathrm{cm}^{-2}$ (3.7), fixes $k/\hbar \sim 10^{-28}\,\mathrm{cm}^{-1}$ (3.8), far below the bound of step 5, and with the $r$ of step 4 gives $\mu \gtrsim 10^{-33}$ (3.9). Three readings of (3.5) follow: a series in $r^2\Delta$, which should make sense on 1-forms even beyond perturbation; a restriction to 1-forms that solve the wave equation, which fails because $\Delta$ need not commute with Ricci, though it might work order by order in $\mu$; and an equation for the pair $(g,\phi)$ on the Hilbert space of 1-forms (3.11), which recalls Einstein-aether theory. Last, a remote link: exponentials of $\alpha'\nabla^2$ in string field theory, and Witten's speculation that string theory will revise quantum mechanics.

*The kind of argument:* a transfer through an identity; a choice under ambiguity; a leading-order expansion; a dimensional match to observation; a plain statement of what is not understood; analogies.

### On the labels

- **The constant terms** (ATY-010, proved by the Atlas; `shd·SER`). The formal series of step 6a are exact to order 12, and numpy closed forms at three points agree to $2.2\cdot10^{-16}$. Their constant terms are $-\kappa^2$ for $D_+D_-$, $\kappa^2$ for the even part of $D_+^2$ and $0$ for $D_s^2$. With the Weitzenböck formula, standard and recalled but not checked on the engine, the leading equations are $\mathrm{Ricci} = \kappa^2$, $-\kappa^2$ and $0$ respectively: the paper's (3.6b), (3.6a) and (3.6c), a cosmological term of either sign or none, of size $\kappa^2 = (k/\hbar)^2$.
- **Size and sign as inputs** (ATY-010, our reading). The Atlas's own cosmological term $c$ has a sign that is minus the square of a generator (INP-049, needs an input), and its size and sign stay inputs. The shift moves the input from $c$ to $k$; it does not derive it.
- **The magnitudes (3.7)–(3.9).** The Atlas computes nothing here. A check would need the observed $\Lambda$, the neutrino mass and the equivalence-principle bound as inputs, and none of the three is an output of the labels.
- **The Weitzenböck identity and the three readings of (3.5).** The Atlas computes nothing here. A check of the identity would build the Hodge and the Bochner Laplacian on the 1-forms of a curved metric of the gravity engine; the shifted Ricci operators themselves are not built.

### Taken forward

- *Our reading.* The constant terms behind the cosmological constant are exact; the constant they give is an input moved from $c$ to $k$ (ATY-010).
- *Open.* What (3.5) means; which shifted Ricci tensor, if any, an argument would select; the sign; the magnitudes.

## Step 8. Einstein–Maxwell by Kaluza–Klein

*Section 4, pp. 11–12.*

### The move

Maxwell's operator cannot be shifted directly, since the exponential of $d + \delta$ does not keep the degree of forms (step 6a). So the paper reaches it through gravity: shift Einstein's equations in five dimensions, on a circle bundle over spacetime with the metric $e^{2\sigma}\Theta^2 + d\bar s^2$ (4.2), and reduce, which gives shifted Einstein–Maxwell equations in four. A by-product: with no electromagnetic field the radius of the circle obeys

$$-\bar\nabla^2 e^\sigma = \epsilon\,\frac{k^2}{\hbar^2}\,e^\sigma, \qquad \epsilon = \pm1, \tag{4.3}$$

an eigenfunction of the four-dimensional Laplacian; in de Sitter space its homogeneous solutions grow or decay exponentially on the time $\hbar/kc$ (4.4). That looks fatal, until the $k$ of step 7 makes the time about the age of the universe: the paper finds about $(3\pi)^{-1}\times10^{11}$ years against $1.4\times10^{10}$ years, and turns the coincidence problem of cosmology into an asset. It adds that a massless scalar with couplings of gravitational strength meets the bounds of fifth-force experiments, that the zero-mode approximation fails once the growth matters, and three closing remarks: Yang–Mills fields by reduction on larger isometry groups; shifting geometric operators as a process akin to geometric quantization, one that includes gravity; and the reliance on spinors, the Dirac operator and Kaluza–Klein theory as a pointer to supergravity and strings.

*The kind of argument:* a structural reduction that sidesteps an obstacle; a short calculation; a coincidence of orders of magnitude; a stated caveat; an analogy.

### On the labels

- **A match of structure** (ATY-010 and LNS-017e, both proved by the Atlas). In the five-dimensional Einstein form with a cosmological term $c$, with every field independent of the extra direction, the scalar of the circle obeys $\Box\phi = 4c\phi + (\epsilon/4)\phi^3F_{ab}F^{ab}$; at $F = 0$ this is $\Box\phi = 4c\phi$, the structure of the paper's (4.3). The constants are not compared.
- **The growth, its time scale and the fifth force.** The Atlas computes nothing here. A check would need the shifted Einstein equations in five dimensions built on the engine, not only their formal series, and the observed $\Lambda$ as an input for the time scale.

### Taken forward

- *Our reading.* The paper's radius equation and the Atlas's five-dimensional scalar equation share one structure, a Laplacian eigenvalue set by one constant; on the Atlas's side that constant is the input $c$ (LNS-017e), as in step 7 (ATY-010).
- *Open.* The constants compared; the dilaton against fifth-force bounds; the extension to Yang–Mills fields; the relation of shifting to geometric quantization, the paper's one pointer from gravity to its third question.

## Step 9. Two constants, two ends; three questions

*Section 5, p. 13.*

### The move

The paper gathers itself into one sentence: operators that shift, retarding or advancing, the basic operators of mathematical physics (Dirac, Maxwell, Ricci), with two physical parameters. The shift $r$ is fixed at the atomic end, by a quantization in Compton wavelengths that carries Planck's constant: $r \gtrsim 10^{-5}\,\mathrm{cm}$ (5.1) and $r = (2n+1)\lambda_C/4$ (5.3). The strength $k$ is fixed at the cosmological end, by the cosmological constant: $k/\hbar \sim 10^{-28}\,\mathrm{cm}^{-1}$ (5.2). They meet in the dimensionless $\mu = kr/\hbar \gtrsim 10^{-33}$ (5.4). The paper finds this a satisfactory situation, close to ideas of Banks. Then, in place of conclusions, three questions, left to others and to the future, with the remark that both sides carry philosophical and mathematical difficulties.

*The kind of argument:* a synthesis by estimates, and an explicit hand-over.

### On the labels

- **The relation (5.3)** is exact on the labels (ATY-005, proved by the Atlas; `shd·QNT`), and on a frame it holds in proper time (ATY-037, proved by the Atlas).
- **One number.** On the labels $\mu = \kappa\tau$ enters every result computed here: the coefficient of $\Phi$, $E_0\bigl(1 - (-1)^n\mu J\bigr)$ (ATY-037); the Noether energy $\rho E_0\bigl(1 - (-1)^n\mu J\bigr)$ (ATY-038, ATY-039); the condition $\kappa\tau = (n_1 - n_2)\pi/2$ for two quantized energies at one shift (ATY-040); the values $\mu = (-1)^n(n+\tfrac12)\pi$ at which (2.1) oscillates (ATY-041). All five rows are proved by the Atlas.
- **The magnitudes (5.1), (5.2), (5.4).** The Atlas computes nothing here. A check would need the neutrino mass and the observed $\Lambda$ as inputs; with the KATRIN bound of step 4 the input of (5.1) reads $r \gtrsim 7\times10^{-5}\,\mathrm{cm}$, as the literature survey computes it.

### Taken forward

- *Our reading.* The paper's two constants meet on the labels in one number: $\mu$ is the size of the deviation, a $J$ part per unit density (ATY-039), and $|\mu| \ge \pi/2$ is the threshold for two quantized energies of one species at one shift (ATY-040).
- *Our reading.* The hand-over becomes a list of computations, each a check the Atlas can run: the one-dimensional table of equations against the variants (ATY-041), carried to the spin-½ constraint of 2+1 gravity found by Schroers and Wilhelm; what an equivalence-principle test weighs, the Noether energy or the coupling per unit density (ATY-039); a potential with a gradient on the engine, where the shift must follow a proper time that varies in space (ATY-037); the energy-momentum tensor for fields that depend on space, Feynman's window in four dimensions (ATY-038).
- *Open.* The three questions themselves, answered as far as the rows go in the next section.

## The three questions

The paper ends on three questions. Each is answered here as far as the rows go, and no further.

**Q1. The meaning of the shifted Einstein equations (3.5).** The formal series behind (3.5) are exact to order 12 (ATY-010, proved by the Atlas). With the Weitzenböck formula, recalled and not checked, their constant terms give a cosmological term $\kappa^2$, $-\kappa^2$ or $0$. Its size and sign stay inputs, moved from the Atlas's $c$ to the paper's $k$ (ATY-010, our reading; INP-049, needs an input). The meaning of the operator equations themselves, as a series in $r^2\Delta$, as a restriction to solutions of the wave equation, or as an equation for the pair $(g,\phi)$, is open.

**Q2. A coherent model, compatible with the Standard Model and with cosmology.**

- *Particles.* $D_+$ has no massless shifted fermion (ATY-005, proved by the Atlas), so chiral fermions cannot be shifted as $D_+$; $D_s$ keeps massless solutions (ATY-007, proved by the Atlas), the variant chirality would need (our reading). The shifted operator is gauge covariant in a constant potential (ATY-008, proved by the Atlas). If the lightest neutrino is massless, which oscillation data allow since they fix only differences of squared masses (recalled), $D_+$ cannot describe it.
- *The equivalence principle.* The coupling to a uniform potential equals the conserved Noether energy (ATY-039, proved by the Atlas), and per unit local density the paper's deviation is a $J$ part, not a real energy (ATY-037, proved by the Atlas, and ATY-039). Whether the paper's bound (2.15) applies depends on what a test weighs; that is open, and the Atlas evaluates no bound.
- *The spectrum.* In the paper's range of $\mu$ a species has one quantized rest energy at a given shift (ATY-040, proved by the Atlas).
- *Cosmology.* The Atlas computes nothing; the cosmological constant is an input (ATY-010, our reading).
- *Open.* The processes of quantum electrodynamics, the Higgs mechanism, the magnitudes and their inputs, the dilaton.

**Q3. How shifted equations relate to quantum mechanics.**

- At the quantized shift the shifted wave is the wave turned by a quarter, $\psi J$ (ATY-009, proved by the Atlas), exactly at $\cos E\tau = 0$ (ATY-005, proved by the Atlas), and on a frame the quantization follows proper time (ATY-037, proved by the Atlas): the shift behaves as a clock (our reading).
- The shifted theory has a conserved energy, Noether's, with a bilocal term over the delay interval (ATY-038, proved by the Atlas), equal to its coupling to a uniform potential (ATY-039, proved by the Atlas); two quantized modes beat at $2\kappa$ per unit proper time (ATY-040, proved by the Atlas).
- At rest the two signs of frequency are the retarded half and the advanced half of one spinor (ATY-041, proved by the Atlas), and they carry energies of opposite sign per unit number (ATY-038): the halves that the paper's Fock-space remark would mix (our reading).
- The Hermitian half has, at $\mu = \pi/2$, a mode of negative Noether number at a positive frequency (ATY-039), outside the paper's range.
- *Open.* The infinite-dimensional data of (2.1) as a space of states; wave packets; Fock space; the Hilbert space of 1-forms; the relation of shifting to geometric quantization.

## What others did since 2010

**How the works are found.** A literature survey accompanies this page in the repository. It reads three citation indexes through their public interfaces (INSPIRE, Semantic Scholar, OpenAlex), which together hold fifteen distinct works that cite the paper; Google Scholar and NASA ADS refuse automated reading, so their lists are not seen. Every address below is verified, opened with its title and authors matching, unless the entry says otherwise.

**On the shifted equations themselves.**

- F. Härlin, *Retardation effects in fundamental physics*, bachelor thesis, Uppsala University (2011); its record: <https://api.openalex.org/works/W1509913360>. It restates the paper at an undergraduate level, argues that one retardation constant must serve all fermions, and derives a shifted Klein–Gordon equation from (2.16). It is the one work found that computes with the shifted equations themselves; its full text is not readable by the tools, so the summary rests on the record's abstract.

**The exponentiated Dirac operator in 2+1 gravity.**

- B. J. Schroers and M. Wilhelm, *Towards non-commutative deformations of relativistic wave equations in 2+1 dimensions*, SIGMA 10 (2014) 053: <https://arxiv.org/abs/1402.7039>. In 2+1 dimensions gravity makes momenta elements of a group, and for spin ½ the constraint becomes the exponential of the Dirac operator, $e^{-(\lambda/2)\gamma^a\partial_a}$, with $\lambda$ set by Newton's constant. They name the operator of Atiyah and Moore and leave the link as a direction; no quantization of the shift appears, and the mass ranges over a bounded interval, as an angle does.
- S. Inglima and B. J. Schroers, *Non-commutative waves for gravitational anyons*, Lett. Math. Phys. 109 (2019) 1433–1471: <https://arxiv.org/abs/1804.05782>. Anyons of 2+1 gravity carried to Minkowski space with an internal circle, where the mass and spin constraints become exponentials of first-order operators. The passage that cites the paper lies outside the part of the text the tools can read.
- B. J. Schroers, *Michael Atiyah and Physics: the Later Years* (2019): <https://arxiv.org/abs/1910.10630>. A memoir of Atiyah's last decade by his Edinburgh collaborator, whose conversations with him start from the place where the shifted equations arise naturally, three-dimensional quantum gravity. It records Atiyah's motives: a doubt that any linear theory is fundamental, a dislike of the collapse of the wave function, a challenge to the habit of initial-value problems, and the Dirac operator as a bridge between geometry and quantum theory.

**Atiyah's own later use.**

- M. F. Atiyah, *Geometric models of helium*, Mod. Phys. Lett. A (2017): <https://arxiv.org/abs/1703.02532>. Helium-4 and helium-3 as complex algebraic surfaces; curved versions would describe helium in a weak gravitational field, the gravity of the universe raising the atom's mass slightly, which he calls a version of Mach's philosophy. He names no equation; the link to the coupling of (2.12) is the survey's reading, and ATY-039 bears on it.

**Functional differential equations.**

- D.-X. Kong and C. Zhang, *A new kind of functional differential equations* (2014): <https://arxiv.org/abs/1402.3084>. Equations whose deviating argument is a fraction of the time, such as $x'(t) = x(t/2)$, motivated by the paper; there is no advanced term and no mixed equation. With a delay proportional to the time a single number fixes the solution, so the infinite-dimensional data of step 2 do not arise (the survey's reading).
- C.-S. Liu, *Basic theory of a class of linear functional differential equations with multiplication delay* (2016 to 2018): <https://arxiv.org/abs/1605.06734>. The pantograph equations $y'(x) = y(\alpha x)$ and their entire solutions. Its introduction cites the mixed equation (2.17) and notes that elementary exponentials solve it.

**Delays in cosmology.**

- D. Choudhury, D. Ghoshal and A. A. Sen, *Standard cosmology delayed*, JCAP 02 (2012) 046: <https://arxiv.org/abs/1106.6231>. A delay put by hand on the density in the Friedmann equation gives a brief accelerated expansion without a scalar field. Only retarded terms appear, and the delay is a few hundred Planck times at most.
- C. J. Palpal-latoc, R. C. Bernardo and I. Vega, *Testing time-delayed cosmology*, Eur. Phys. J. C (2022): <https://arxiv.org/abs/2111.10742>. The same delayed Friedmann equation at late times, with the cosmological constant kept, fitted to expansion-rate and growth data. The fitted delay is about 0.11 Gyr with wide intervals, and the Bayes factor neither favours nor excludes it.
- A. Paliathanasis, *Cosmological solutions with time-delay*, Mod. Phys. Lett. A (2022): <https://arxiv.org/abs/2207.11023>. A bulk viscosity that depends on the delayed Hubble rate: at a critical delay the de Sitter points change stability, a Hopf bifurcation. The expansion then oscillates about de Sitter, with an equation of state oscillating about $-1$.

**Mentions.** A. Jenkins, *Self-oscillation*, Physics Reports (<https://arxiv.org/abs/1109.6640>), and Z. K. Silagadze, *Analytical solution of the Sommerfeld–Page equation*, Am. J. Phys. (2024) (<https://arxiv.org/abs/2309.03205>), cite the paper in passing; Silagadze writes the roots of a simple delay equation with Lambert's function, as step 2 does. M. Szydłowski and A. Krawiec (2021, <https://link.springer.com/chapter/10.1007/978-3-030-56160-4_6>), V. Pasquarella (a PhD thesis, 2024, <https://arxiv.org/abs/2406.11964>, the record verified, the citation not found in the readable part of the text) and N. Hitchin's bibliography of Atiyah (2020, not verified) complete the fifteen.

**Lines that carry retarded and advanced equations without citing the paper.**

- *Raju's programme.* C. K. Raju, *The electrodynamic 2-body problem and the origin of quantum mechanics*, Found. Phys. 34 (2004) 937–962: <https://arxiv.org/abs/quant-ph/0511235>; a series in *Physics Education*, for instance <https://physedu.in/pub/Jan-Mar-2016/PE16-03-369>; *Retarded gravitation theory*: <https://arxiv.org/abs/1102.2945v3>. It claims a route from mixed functional differential equations to quantum mechanics, and from retardation to a problem of the dark sector, without the Dirac operator. Its claims are not checked here.
- *The Wheeler–Feynman equations as mathematics.* R. D. Driver, *Can the future influence the present?*, Phys. Rev. D 19 (1979) 1098: <https://digitalcommons.uri.edu/math_facpubs/16>; G. Bauer, D.-A. Deckert and D. Dürr: <https://arxiv.org/abs/1009.3103>; D.-A. Deckert, D. Dürr and N. Vona: <https://arxiv.org/abs/1212.6285>. For two charges on a line the mixed equations have a unique solution from point data when the separation is large enough, and solutions exist on any finite interval once the trajectories outside it are prescribed. A mixed problem can need far less data than the function's worth of step 2.
- *Delays with Dirac particles.* M. Lienert: <https://arxiv.org/abs/1801.00060v3>; M. Lienert and M. Nöth: <https://arxiv.org/abs/1903.06020>. Two Dirac particles interacting with a time delay have a unique dynamics on a spacetime cut off before $t = 0$, with Cauchy data on the initial cut only. They bear on Q3 with Dirac particles and delays, through integral equations rather than a shifted operator.
- *Quantization from a delay.* J. Giné: <https://arxiv.org/abs/physics/0505181>; R. A. H. Farias and E. Recami: <https://arxiv.org/abs/quant-ph/9706059v2>. A retarded central force adds a torque proportional to $\sin\omega\tau$, so that stationary orbits need the delay to be a whole number of half periods; a minimal time gives retarded, symmetric and advanced forms of quantum mechanics. Both tie a delay to a period, as step 4 ties the shift to a quarter period.
- *The theory of mixed equations.* A. Rustichini (1989): <https://link.springer.com/article/10.1007/BF01047828>; J. Mallet-Paret (1999), listed at <https://memoriam.cse.umn.edu/sell/jdde/1999.html>; W. M. Schouten-Straatman and H. J. Hupkes: <https://arxiv.org/abs/2001.11257>. A mathematical theory of functional differential equations of mixed type exists: spectra, semigroups, a Fredholm alternative, exponential dichotomies. It gives the function spaces in which (2.17) on spinors could be posed.
- *Time-nonlocal gravity.* S. Deser and R. P. Woodard: <https://arxiv.org/abs/0706.2151>; M. Maggiore and M. Mancarella: <https://arxiv.org/abs/1402.0448>; F. W. Hehl and B. Mashhoon: <https://arxiv.org/abs/0812.1059>. Terms nonlocal in time give a late acceleration or effects like dark matter, without a shifted Dirac operator. In each the scale is an input, as the Atlas reads the paper's $k$ (ATY-010).

**Two measured inputs, as their sources state them.**

- P. Touboul et al., *MICROSCOPE mission: final results of the test of the Equivalence Principle*, Phys. Rev. Lett. 129 (2022) 121102: <https://arxiv.org/abs/2209.15487>. $\eta(\mathrm{Ti},\mathrm{Pt}) = [-1.5 \pm 2.3\,(\text{stat}) \pm 1.5\,(\text{syst})]\times10^{-15}$; read as the paper reads (2.14), this would push $\mu$ below about $10^{-15}$, two orders under the $10^{-13}$ it uses.
- M. Aker et al. (KATRIN), *Direct neutrino-mass measurement based on 259 days of KATRIN data*, Science: <https://arxiv.org/abs/2406.13516v1>. $m_\nu < 0.45\ \mathrm{eV}$ at 90 % confidence; a quarter of the Compton wavelength at that mass is about $6.9\times10^{-5}\,\mathrm{cm}$, so the paper's $r \gtrsim 10^{-5}\,\mathrm{cm}$ reads $r \gtrsim 7\times10^{-5}\,\mathrm{cm}$.

**The verdict.** No work found carries the shifted Dirac and Einstein equations forward in print beyond the free plane waves of the paper: the one thesis that computes with them restates them and adds a Klein–Gordon equation, and no paper answers or sharpens any of the three questions. Two qualifications. The exponentiated Dirac operator itself is carried forward by Schroers and his collaborators, as an object that 2+1 quantum gravity produces, though they stop at naming the link. And retarded-and-advanced equations as such are carried forward, before and after 2010, by communities that do not cite the paper. No work found reads the step from (2.10) to (2.12), constructs the energy-momentum tensor of a shifted action, or treats (2.17) on spinors. On the labels ATY-037 and ATY-039 read the first, ATY-038 builds the energy at rest (not the tensor), and ATY-041 places (2.17) on spinors at rest, as the cosh part of $D_c$, each within the scope it prints.

## What this reading does not do

- **No experiment.** The Atlas evaluates no bound, neither the $10^{-13}$ the paper uses nor the $10^{-15}$ of MICROSCOPE, and it says nothing on how an experiment would weigh a $J$-valued term.
- **No claim about nature.** The Atlas does not say that a shifted equation describes a particle, which variant would, which sign the cosmological term has, or that gravity follows from the labels. The magnitudes (2.8), (2.15), (3.7)–(3.9), (4.4) and (5.1)–(5.4) are the paper's and are not computed.
- **The tensor for fields that depend on space.** The energy is defined and checked for fields of the frame time alone; a moving wave enters only through the $k$-derivative of the symbol, on Dirac matrices. The Lorentz-covariant bilocal current is not built.
- **Belinfante.** The symmetric form of the energy-momentum tensor is not attempted; the energy is the canonical one of the delay formula, defined up to improvement terms.
- **The complex equation off its modes.** Away from the quantized modes $Q = \tilde P$ does not solve the adjoint, and the meaning of the energy for the solutions of the paper's complex equation that do not oscillate is not explored; the identity off shell holds for every pair $(P,Q)$.
- **The Einstein–Maxwell sector.** The shifted Ricci operators and the shifted Einstein–Maxwell equations are not built: only formal series in one commuting variable, the Weitzenböck formula recalled, and the radius equation matched in structure.
- **And further:** packets of more than two frequencies; the second branch $E = \kappa - m$ in the energy; potentials that are not constant; the processes of quantum electrodynamics; Fock space. Feynman's thesis is read by the literature survey, not by the scripts.

## Sources

- **The paper.** M. Atiyah and G. W. Moore, *A shifted view of fundamental physics*, arXiv:1009.3176 [hep-th] (2010): <https://arxiv.org/abs/1009.3176>. The opening article of *Perspectives in Mathematics and Physics: Essays Dedicated to Isadore Singer's 85th Birthday*, edited by T. Mrowka and S.-T. Yau, Surveys in Differential Geometry XV (International Press, 2010), table of contents at <https://archive.intlpress.com/site/pub/files/preview/bookpubs/00000369.pdf>; DOI 10.4310/SDG.2010.v15.n1.a1 (the DOI link not opened). Read whole; pages and equation numbers as printed on the arXiv version. The idea is also the first half of Atiyah's guest lecture at the Collège de France (2011): <https://www.college-de-france.fr/en/agenda/guest-lecturer/surveyor-explores-the-universe>.
- **The rows.** ATY-004, ATY-005, ATY-006, ATY-007, ATY-008, ATY-009, ATY-010, ATY-011, ATY-037, ATY-038, ATY-039, ATY-040, ATY-041; EQN-008, MAP-018, INP-049, LNS-017e. Their research texts are in the Atlas's tables.
- **The checks.** `checks/selfcheck/proofs/shifted_dirac.py`: `shd·OP`, `shd·ORD`, `shd·RET`, `shd·SYM`, `shd·OWN`, `shd·COV`, `shd·QNT`, `shd·NUL`, `shd·VAR`, `shd·GAU`, `shd·BIL`, `shd·SER` (64 checks, 0 fail; nine wrong versions, each ending with exit 1). `checks/selfcheck/proofs/shifted_weakfield.py`: `wf.FRAME`, `wf.WEIGHT`, `wf.CONN`, `wf.STD` (14 checks, 0 fail; five wrong versions). `checks/selfcheck/proofs/shifted_energy.py`: `en.DELAY`, `en.OSC`, `en.REST`, `en.NOETHER`, `en.CONS2`, `en.HERM`, `en.GRAV`, `en.BEAT`, `en.MIXED` (62 checks, 0 fail; seven wrong versions). The logs and fault logs are in `checks/selfcheck/proofs/logs/`.
- **The roots the paper names.** R. P. Feynman, *The Principle of Least Action in Quantum Mechanics* (thesis, 1942), in *Feynman's Thesis: A New Approach to Quantum Theory*, edited by L. M. Brown (World Scientific, 2005): <https://search.worldcat.org/oclc/62332166>; the scan the survey reads: <https://faculty.washington.edu/seattle/physics541/2012-path-integrals/feynman-thesis.pdf>. J. A. Wheeler and R. P. Feynman, Rev. Mod. Phys. 17 (1945) 157: <https://journals.aps.org/rmp/abstract/10.1103/RevModPhys.17.157>, and Rev. Mod. Phys. 21 (1949) 425: <https://authors.library.caltech.edu/48015>. J. D. Bjorken and S. D. Drell, *Relativistic Quantum Fields* (McGraw-Hill, 1965), section 11.1: the record <https://archive.org/details/relativisticquan0000bjor_c5q0> (the passage not verified). C. K. Raju, *Time: Towards a Consistent Theory* (Kluwer, 1994): <https://link.springer.com/doi/10.1007/978-94-015-8376-3>. M. F. Atiyah, *Topology and physics*, Proceedings of the XVIIIth Solvay Conference (North-Holland, 1984), pp. 203–206 (not verified). The paper's other references used in its argument: C. M. Will, *Resource Letter PTG-1: Precision tests of gravity*: <https://arxiv.org/abs/1008.0296>; T. Banks, *TASI lectures on holographic space-time, SUSY and gravitational effective field theory*: <https://arxiv.org/abs/1007.4001>; N. Arkani-Hamed, H. Georgi and M. D. Schwartz, *Effective field theory for massive gravitons and gravity in theory space*: <https://arxiv.org/abs/hep-th/0210184>.
- **The work since 2010.** The works and addresses of the section above, and the citation lists the survey reads: INSPIRE, <https://inspirehep.net/api/literature?q=refersto%3Arecid%3A868570&size=100&fields=titles,authors.full_name,arxiv_eprints,publication_info,dois,earliest_date>; Semantic Scholar, <https://api.semanticscholar.org/graph/v1/paper/arXiv:1009.3176/citations?fields=title,authors,year,venue,externalIds&limit=1000>; OpenAlex, <https://api.openalex.org/works?filter=cites:W2156483004&per-page=100&select=id,display_name,authorships,publication_year,primary_location,doi>.
