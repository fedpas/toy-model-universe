#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round9/pass7/apply_pass7.py -- applies pass seven (the energy of the shifted theory, docs/round9/pass7/apply.json) to the tables.

Idempotent: a second run writes the same bytes. In order:
  1 content/rows.json        the rows ATY-038 ... ATY-041 (group ATY, since v2.9), placed in the file after ATY-037
  2 content/texts.json       their research texts (status draft, source pass7:shifted-energy), after the text of ATY-037
  3 content/checks.json      the check record of checks/selfcheck/proofs/shifted_energy.py (the nine check ids en.*)
  4 content/check_runs.json  its run record
  5 content/lenses.json      four entries of the dictionary of the lens atiyah
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence)
  7 content/analyses.json    the check ids en.* join the Atiyah page's list; the file is read again just before it is written and only the
                             Atiyah entry's list is touched, as text, so every other entry (a page another owner registers meanwhile) keeps its bytes
  8 public/reports/analyses/src/atiyah_lens.md   section 9 items 15 to 18, its first paragraph and its list of what is not done (as RESULT.md
                             section 8 says), the limits of paper 177 in section 6, the lens record of section 7 (its counts from the regenerated
                             readings), the sources
  9 node tools/make_analysis.mjs atiyah    renders the page
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round9/pass7/apply_pass7.py [--no-node]    --no-node skips steps 6 and 9 (and leaves the counts of step 8)
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..', '..'))
A = json.load(open(os.path.join(HERE, 'apply.json'), encoding='utf-8'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
NEW_IDS = [r['id'] for r in A['rows']]
SOURCE = 'pass7:shifted-energy'
said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def save(rel, data, newline):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')
    old = open(path(rel), encoding='utf-8').read()
    if text != old:
        open(path(rel), 'w', encoding='utf-8').write(text)
        said.append(f'wrote {rel}')
    else:
        said.append(f'unchanged {rel}')


# ---- 1 rows: out with any earlier copy of the four, in again after ATY-037
rows, nl = load('content/rows.json')
rows = [r for r in rows if r['id'] not in NEW_IDS]
at = next(i for i, r in enumerate(rows) if r['id'] == 'ATY-037')
for k, r in enumerate(A['rows']):
    assert r['since'] == A['since'] == 'v2.9' and r['group'] == 'ATY' and r['kind'] == 'computation', r['id']
    assert [s['order'] for s in r['shownOn']] == [1783 + k] and r['shownOn'][0]['page'] == 'steps/coupling' and r['shownOn'][0]['role'] == 'detail', r['id']
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])}
assert not any((s['page'], s['order']) in taken for r in A['rows'] for s in r['shownOn']), 'an order of the pass is taken'
rows[at + 1:at + 1] = A['rows']
ids = {r['id'] for r in rows}
for r in A['rows']:
    for d in r['depends']:
        assert d['id'] in ids, f"{r['id']} depends on an unknown row {d['id']}"
save('content/rows.json', rows, nl)

# ---- 2 texts: the research texts, after the text of ATY-037
texts, nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine = {key(t) for t in A['texts']}
texts = [t for t in texts if key(t) not in mine]
for t in A['texts']:
    assert t['status'] == 'draft' and t['source'] == SOURCE and t['row'] in NEW_IDS and t['level'] == 'research', t['row']
at = max(i for i, t in enumerate(texts) if t['row'] == 'ATY-037')
texts[at + 1:at + 1] = A['texts']
save('content/texts.json', texts, nl)

# ---- 3 the check record (the last record of the file, after shifted_weakfield.py)
checks, nl = load('content/checks.json')
cid = A['checks'][0]['id']
checks = [c for c in checks if c['id'] != cid] + A['checks']
assert [i['id'] for i in A['checks'][0]['ids']] and all(path(A['checks'][0][k]) and os.path.exists(path(A['checks'][0][k])) for k in ('script', 'log'))
save('content/checks.json', checks, nl)

# ---- 4 the run record
runs, nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine = {rk(r) for r in A['check_runs']}
runs = [r for r in runs if rk(r) not in mine] + A['check_runs']
save('content/check_runs.json', runs, nl)

# ---- 5 the lens atiyah: four dictionary entries
lenses, nl = load('content/lenses.json')
lens = next(l for l in lenses if l['key'] == A['lens']['key'])
add = A['lens']['dictionary_add']
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows']
lens['dictionary'] = [e for e in lens['dictionary'] if not any(same(e, f) for f in add)] + add
assert len(lens['dictionary']) == 87, len(lens['dictionary'])
save('content/lenses.json', lenses, nl)

# ---- 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ---- 7 the analyses registry: the Atiyah entry's check ids, as text (read again now, written back at once)
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
m = re.search(r'\n(\s*)"id": "atiyah",', raw)
assert m, 'the Atiyah entry of content/analyses.json'
c = raw.index('"checks": [', m.end())
end = raw.index(']', c)
body = raw[c + len('"checks": ['):end]
have = json.loads('[' + body + ']')
want = [x for x in A['analyses']['checks_add'] if x not in have]
if want:
    ind = re.search(r'\n(\s*)"', body).group(1)
    stripped = body.rstrip()
    new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
    text = raw[:c] + '"checks": [' + new_body + raw[end:]
    after = json.loads(text)
    a_old = next(x for x in before if x.get('id') == 'atiyah')
    a_new = next(x for x in after if x.get('id') == 'atiyah')
    assert a_new['checks'] == a_old['checks'] + want and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') != 'atiyah'] == [x for x in before if x.get('id') != 'atiyah']
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (the Atiyah entry gains {len(want)} check ids)')
else:
    said.append(f'unchanged {rel}')

# ---- 8 the analysis page's source
rel = A['analyses']['source']
md = open(path(rel), encoding='utf-8').read()
md0 = md


def edit(find, repl, what):
    global md
    if repl in md and (find not in md or find in repl):
        return
    assert md.count(find) == 1, f'{what}: the phrase to replace is not there once'
    md = md.replace(find, repl)


NOT_DONE_WHERE = 'section 9, the "Not done" paragraph'
for e in A['analyses']['edits']:
    if 'find' not in e or 'readings on' in e['replace'] or e['where'] == NOT_DONE_WHERE:
        continue   # the items go in below; the counts of the readings come from the table; the list of what is not done is rewritten below
    edit(e['find'], e['replace'], e['where'])
# items 15 to 18, after item 14 (one line each, as the items before them)
lines = md.split('\n')
i14 = next(i for i, l in enumerate(lines) if l.startswith('14. *Shifted equations on a frame*'))
items = A['analyses']['section9_items']
if lines[i14 + 1:i14 + 1 + len(items)] != items:
    assert not any(l.startswith(('15. ', '16. ', '17. ', '18. ')) for l in lines), 'items 15 to 18 stand elsewhere'
    lines[i14 + 1:i14 + 1] = items
md = '\n'.join(lines)
# the list of what is not done: S1's phrase for the tensor and the packets, with the rest of RESULT.md section 8
NOT_DONE_OLD = next(e['find'] for e in A['analyses']['edits'] if e['where'] == NOT_DONE_WHERE)
NOT_DONE = ("the energy-momentum tensor of the shifted theory for fields that depend on space (its energy at rest is defined and computed, items 15 "
            "and 16), with its Lorentz-covariant bilocal current and its symmetric (Belinfante) form (the energy of items 15 and 16 is the canonical one "
            "of the delay formula, defined up to improvement terms); the paper's complex equation away from its quantized modes, where Q = P̃ does not "
            "solve the adjoint; packets of more than two frequencies, the second branch E = κ − m (κ > m) and potentials that are not constant; "
            "Feynman's thesis, which the paper cites for a conserved energy with retardation (item 18 cites it as the literature pass reports it); "
            "any claim about experiments (the 10⁻¹³ limit is not re-evaluated, and nothing is said on how an experiment would weigh a J-valued term);")
edit(NOT_DONE_OLD, NOT_DONE, 'the list of what is not done')
# the sources: the paper as pass seven read it, after the line of pass six
SRC6 = '- For section 9, pass six: '
SRC7 = ("- For section 9, pass seven: M. F. Atiyah and G. W. Moore, *A shifted view of fundamental physics* (arXiv:1009.3176, pages 3–8 read: "
        "section 2 with the remarks 2.2.2–2.2.4); the conserved energy of R. P. Feynman's thesis (section II.3, the mirror action) as the literature "
        "pass reports it; the thesis itself is not read here.")
if SRC7 not in md:
    lines = md.split('\n')
    j = next(i for i, l in enumerate(lines) if l.startswith(SRC6))
    lines[j + 1:j + 1] = [SRC7]
    md = '\n'.join(lines)
# the lens record: the counts of the readings of the lens atiyah, from the regenerated table
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')
for must in ('carries a dictionary of 87 entries', '16 from the checks of section 9.', '15 to 18 pass seven.', 'ATY-038 to ATY-041); each has',
             '`shifted_weakfield.py`, `shifted_energy.py` with their logs and fault logs.', '*Done (pass seven): ATY-038 to ATY-041', NOT_DONE, SRC7):
    assert md.count(must) == 1, must
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 9 the page
if not NO_NODE:
    out = subprocess.run(['node', 'tools/make_analysis.mjs', 'atiyah'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
