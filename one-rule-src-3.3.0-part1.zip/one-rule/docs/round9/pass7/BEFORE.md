<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass seven, before the script: the energy of the shifted theory

Written before `checks/selfcheck/proofs/shifted_energy.py` ran. What the Atlas's rows say about the objective, then a prediction with the rows it starts from. The hand algebra behind the predictions is the Atlas's own (the labels of Cl(1,3), the conventions of `shifted_dirac.py`); nothing here is a result until the script prints it.

## The objective

The paper (Atiyah and Moore, section 2, pages 3–8 read) writes the action ∫ vol ψ̄(iħ𝔻₊ − mc)ψ (2.10), says that one "can derive the energy-momentum tensor T_μν" from it, and states, from the Φ-coefficient in the weak field (2.11), T₀₀ = E₀(1 − μ(−1)ⁿ) (2.12) and the deviation (2.14). No T_μν is written on the page. The objective of this pass: define an energy of the shifted theory by Noether's procedure on the nonlocal action, check that it is conserved where the plane-wave reading cannot see it (two frequencies at once), evaluate it on the quantized solutions and set it beside the gravitational coupling; then the two-frequency packet and the mixed equation (2.17).

## What the rows say

- **ATY-005** (`shd·QNT`, `shd·OWN`): on the ordinary solutions of mass E, exp(−τbD) is the right factor e^{JEτ}, a retard by τ in sector −1 and an advance in sector +1; plane waves exactly at cos Eτ = 0, E = m + (−1)ⁿκ. Only plane waves of one frequency.
- **ATY-007** (`shd·VAR`): D_s = D + κ sinh(τD) has no quantization (E = m − κ sin Eτ for every θ); D_c as printed (with i) none; read uniformly, one with E = m.
- **ATY-009** (`shd·BIL`): at the quantized shift the shifted solution is ψJ, a quarter turn.
- **ATY-011** (a reading): the adjoint of a translation is the opposite translation, so a shifted term in an action brings both directions; not computed.
- **ATY-037** (`wf.WEIGHT`): the Φ-coefficient of the operator on the quantized rest solutions is E₀P(1 − (−1)ⁿμJ); its scalar part E₀, the deviation along PJ; (2.12) not reproduced; "no energy-momentum tensor of the shifted theory is built here, and wave packets are out of scope".
- **CPL-011** (the action): covariance and conservation from the symmetries of the action, checked for gravity, scalar and Maxwell; "for the matter currents the Noether statement is still a pointer". **MAP-018**: the current ψγ₀ψ̃ conserved on solutions of the local equation. **CAND-126**: at rest the solutions are the 4 real dimensions of the even Pauli part.
- The notion `var` of the labelling scheme (Euler–Lagrange forms, Noether identities, currents) has not been used on a nonlocal action anywhere in the Atlas.

So the Atlas has the operator, its plane waves, its Φ-coefficient as an operator; it has no action-level object for the shifted theory, no conserved quantity, nothing with two frequencies.

## Prediction

(a) **The energy.** On fields of the frame's time alone the operator exp(−τbD) is a power series in bD with bD² = ∂_t², so it should split exactly: the retard P₊(t − τ) on the half that commutes with γ₀ and the advance P₋(t + τ) on the half that anticommutes (ATY-005 extended from plane waves to every field of t). The rest-frame action is then a Lagrangian with a delayed and an advanced argument, and for such a Lagrangian the Noether energy of time translation is the canonical h = ṗq − L minus, for each shifted argument, an integral over the delay interval of the pairing between the conjugate field at one end and the shifted field's derivative at the other. For the one-dimensional model (2.1), with an auxiliary field y (the "ψ̄" of the model, which then obeys the advanced equation ẏ = ky(t + r)), the energy should be E = −ky(t)x(t − r) − k∫_{t−r}^{t} y(s + r)ẋ(s) ds; on x = e^{−zt/r}, y = e^{zt/r} with z = μe^z it should be (z/r)(z − 1), and between two different roots exactly 0.

(b) **Two modes.** Two quantized rest energies of one species at one τ need E₁ = m + κ (n₁ even) and E₂ = m − κ (n₂ odd) with E₁τ = (n₁ + ½)π and E₂τ = (n₂ + ½)π, so κτ = (n₁ − n₂)π/2: an odd multiple of π/2. The examples: (m, κ, τ) = (4, 1, π/2) with E = 5, 3; (2, −1, π/2) with E = 1, 3; (2, 1, 3π/2) with E = 3, 1. On ψ = Ae^{−JE₁t} + Be^{−JE₂t} the local part of the energy should beat at E₁ − E₂ and the bilocal part should cancel the beat exactly: the cross terms of the Noether energy vanish, not merely stay constant.

(c) **The value and the coupling.** Expected on a quantized rest mode, with ρ = ⟨P̃P⟩₀: Noether energy ρE₀(1 − (−1)ⁿμJ), the same expression as the Φ-coefficient of ATY-037 paired with P̃, so that the gravitational coupling equals the Noether energy and the paper's deviation is the bilocal part of the Noether number. The paper's operator splits as iD₊ − m = H + A, H = i(D − κ sinh τD) − m Hermitian (D_s with κ → −κ, ATY-007) and A = iκ cosh τD anti-Hermitian; H alone should have a real Noether energy ρE(1 − μ cos Eτ) on each of its modes, equal to its Φ-coefficient, ρE₀ at the quantized points; A should carry the J part, from its bilocal term only (its local part is κ cos E₀τ = 0 there). If the expectation fails the result is kept.

(d) **The beat.** On the frame of a constant potential (ATY-037: the shift follows proper time, the coordinate frequency is E/a), the two modes of (b) should give a density beating at (E₁ − E₂)/a in coordinate time, E₁ − E₂ = 2κ in proper time, and (E₁ − E₂)τ = (n₁ − n₂)π in every frame: the beat counts the shift in half beat periods. In the paper's range (|μ| < 10⁻¹³) no such packet exists for one species.

(e) **The mixed equation.** At rest cosh(τbD) is the symmetric shift (P(t + τ) + P(t − τ))/2 on both halves and sinh(τbD) the antisymmetric one with a γ₀ twist; so (2.17) should be the uniform-reading D_c at rest on P₊ = Xe^{−Jmt} with mτ ∈ 2πℤ, with k = κ/2, and (2.1) the P₊ half of D₊ with k = κe^{Jmτ}. The roots of (2.18) should stay off the imaginary axis for every μ and approach i(j + ½)π as μ → ∞, which is the quantization lattice of (2.6): the kernel of the symmetric shift.

## What would count against the prediction

A non-zero cross term in the Noether energy of a two-mode sum (the bilocal formula is then wrong or the modes are not solutions of both Euler–Lagrange equations); a J part in the Noether energy of H; a Φ-coefficient different from the Noether energy on any mode; a root of (2.18) on the imaginary axis.
