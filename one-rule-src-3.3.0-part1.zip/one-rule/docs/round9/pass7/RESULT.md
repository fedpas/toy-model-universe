<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass seven, the result: the energy of the shifted theory

Script `checks/selfcheck/proofs/shifted_energy.py`: 62 checks (bit 31, bit==std 9, ctl 6, std 16), 0 fail, about 13 s; seven `--fault` options, each run ending with its FAILS line and exit 1. Logs `checks/selfcheck/proofs/logs/shifted_energy.log` and `shifted_energy.faults.log`. Run from `checks/` as `python3 -I -B selfcheck/proofs/shifted_energy.py`; from the script's own folder and from the package root the check lines are byte for byte the same. Every sentence below prints the scope that ran.

## 1. Predicted (BEFORE.md, written before the script ran)

(a) At rest the shift should be a delay, retard on P₊ and advance on P₋, and the Noether energy the canonical part minus a bilocal integral over the delay interval; for (2.1) E = −ky(t)x(t − r) − k∫_{t−r}^{t} y(s + r)ẋ(s) ds, (z/r)(z − 1) per root, 0 between roots. (b) Two quantized energies of one species at one τ only for κτ an odd multiple of π/2; the cross terms of the energy vanish, the local part beats. (c) Noether energy ρE₀(1 − (−1)ⁿμJ) on a quantized mode, equal to the Φ-coefficient of ATY-037 paired with P̃; the Hermitian half real, ρE(1 − μ cos Eτ), ρE₀ at the quantized points; the J part from the anti-Hermitian half's bilocal term. (d) A beat at 2κ per unit proper time, redshifted by √(1 − 2Φ), with (E₁ − E₂)τ = (n₁ − n₂)π. (e) (2.17) = D_c read uniformly at rest with k = κ/2; (2.1) the P₊ half of D₊; the roots of (2.18) off the imaginary axis, tending to i(j + ½)π.

All of it came out. One check was added after these results, at the coordinator's request on a pointer from the literature pass, and is not part of BEFORE.md: en.OSC, the expectation that (2.1) oscillates without growth exactly when its delay is an odd number of quarter periods (cos ωr = 0, the form of the paper's quantization) and that the one-dimensional equations with a mass term sort as D₊, D_c and D_s do; it came out as expected. Three things came out that the prediction did not say, and one that it said wrongly: the Hermitian half has, at μ = π/2, a third rest mode with a negative Noether number; the P₋ half of the paper's equation at rest is exactly the adjoint (advanced) equation of (2.1); the Φ-coefficient equals the Noether energy for the paper's complex operator too, not only for its Hermitian half; and the approach of the roots of (2.18) to the lattice is O(1/μ²) in relative terms, not O(1/μ) as written in BEFORE.md (the real parts themselves fall like 1/μ).

## 2. The paper (pages 3–8 read)

The action (2.10) is written, "from which one can derive the energy-momentum tensor T_μν"; the page then extracts "the coefficient of Φ to obtain the gravitational rest energy" from the weak field (2.11) and, "using on-shell spinor wavefunctions for a particle at rest", states T₀₀ = E₀(1 − μ(−1)ⁿ) (2.12), a deviation (−1)ⁿ⁺¹μ (2.14). No T_μν is written; no normalisation of the wavefunction is said. Remark 2.2.2 writes the mixed equation (2.17) and its exponential solutions with z = μ(e^z + e^{−z}) (2.18); remark 2.2.3: the roots have non-zero real parts, which tend to zero as μ → ∞ "since the solutions plainly become anti-periodic with period 2r", and Feynman found "surprisingly" a conserved energy for a similar equation. Remark 2.2.4 places the difficulty in the mixing of positive and negative frequencies.

## 3. Where they meet

- **The energy exists, and it is Noether's** (ATY-038). On fields of the frame's time alone the paper's exp(−τbD) is exactly P₊(t − τ) + P₋(t + τ), so the action is a delay Lagrangian and Noether's procedure gives an energy with a bilocal (Wronskian) term. Off shell dE/dt = −⟨Q̇ O[P]⟩_S − ⟨YṖ⟩_S holds exactly as a polynomial identity (30 field pairs, five operators), so the energy is conserved wherever the equation and its adjoint hold. On the quantized modes Q = P̃ solves the adjoint and E = ρE₀(1 − (−1)ⁿμJ). On two modes at one shift the local energy beats at E₁ − E₂ and the bilocal term cancels the beat exactly. This is the kind of conserved energy the paper's remark 2.2.3 attributes to Feynman for a similar equation; the conservation for (2.17) is computed here too (std). The literature pass (L1) points to Feynman's thesis, section II.3, the mirror action, where the conserved energy of a mixed advanced-and-retarded equation needs the motion over a whole window from t − T₀ to t + T₀ (https://faculty.washington.edu/seattle/physics541/2012-path-integrals/feynman-thesis.pdf): the template of the bilocal term. This pass did not read the thesis; the rows cite it as the literature pass reports it.
- **The coupling is the energy** (ATY-039). The Φ-coefficient of the action on every mode tried equals the Noether energy, exactly, for the paper's operator and for each half: the coupling to a uniform potential is the conserved energy, ratio 1. Per unit local density it is E₀(1 − (−1)ⁿμJ): E₀ times the Noether number per unit density. The paper's (2.12) is that expression with J read as a real number. So the deviation (2.14) is the bilocal part of the particle number, and in the paper's complex theory it is a J part (an imaginary number), not a real energy; in the Hermitian half it is −μ cos E₀τ, zero at the quantized points. The paper's (2.12) is reproduced only if the J part is read as a real number and the coupling is compared with E₀ times the local density instead of with the Noether energy.
- **Retarded and advanced at once** (ATY-041). (2.1) itself oscillates without growth exactly when cos ωr = 0, μ = (−1)ⁿ(n + ½)π: its delay is then an odd number of quarter periods, which is the paper's quantization condition cos Eτ = 0 read on the one-dimensional equation; with the mass term the halves at rest sort as the operators of ATY-007 do (D₊ and D_c read uniformly oscillate only on the lattice, H, D_s and D_c as printed off it too). The paper's "it is also an advanced equation" is, at rest, a statement about the two halves of P: the P₊ half of D₊ is (2.1) with k = κe^{Jmτ} and the P₋ half is the advanced adjoint equation, the y-equation of the one-dimensional Lagrangian. The cosh part of the shift is (2.17): D_c read uniformly is (2.17) at rest with k = κ/2, and the quantization lattice cos Eτ = 0 is the kernel of the symmetric shift; the anti-periodic limit of remark 2.2.3 lands on that same lattice.
- **The packet** (ATY-040). Two quantized rest energies of one species at one shift force κτ = (n₁ − n₂)π/2. In the paper's range |μ| < 10⁻¹³ there is no such packet for one species; where it exists, the beat runs at 2κ per unit proper time, is redshifted like any clock on the frame, and changes sign over each shift.

A reading (ours), not a computation: on a mode e^{−Jωt} a time translation is a phase rotation, so the Noether energy is ω times the Noether number, and the Φ-coefficient (a time dilation of every derivative, inside the shift too) is ω times the ω-derivative of the symbol, which the bilocal formula makes equal to the number. That is why the two agree mode by mode; the script checks the agreement, not this argument.

## 4. What ran

| section | what | route | scope |
|---|---|---|---|
| (1) en.DELAY | (2.1) from L = y(ẋ + kx(t − r)) | exact piecewise polynomials, method of steps; lambertw + quad; solve_ivp | 12 exact runs (μ = 1/2, 3/2, −2/3, 3/2); 20 roots; one smooth history |
| (1) en.OSC | when (2.1) oscillates; the toys with a mass term | exact in the J-plane and on the halves at rest; lambertw; complex Newton on a grid, 4 × 4 symbols | eight quarter turns; μ = π/2, −3π/2, 5π/2 and five control values; five toys at τ = π/2 (E = 0 … 9) and τ = 1.3 |
| (2) en.REST | exp(−τbD), cosh, sinh at rest; O = H + A; (2.1), its adjoint and (2.17) as halves | exact Fractions and ℚ[π] on the labels; expm on Fourier modes | 9 polynomial fields of degree 5; 6 polynomial X at three (m, τ, κ) |
| (3) en.NOETHER | the energy and the number; the off-shell identities; values on modes | exact; Dirac matrices with quad | 30 field pairs; (m, κ) = (3, 2), E₀ = 5 at τ = π/10, E₀ = 1 at τ = 3π/2, both sectors |
| (4) en.CONS2 | two modes at one shift | exact; quad and least squares | (4, 1, π/2), (2, −1, π/2), (2, 1, 3π/2), both sectors |
| (5) en.HERM | the Hermitian half | exact; Hermiticity of the symbols, root scan, quad | (4, 1, π/2), (8, 1, π/2); scan at μ = 0.1, 0.5, 0.9, −0.9 |
| (6) en.GRAV | Φ-coefficient against the energy | exact; central differences in Φ and in k | the modes of (3), (5), (4); one moving wave (13, 12, 0, 0) and one H-mode at τ = 0.37 |
| (7) en.BEAT | the arithmetic of a packet; the beat on four frames | exact; FFT of the sampled density, quad | 441 pairs; a = 5/3, 5/4, 2, 4/5 |
| (8) en.MIXED | (2.17), (2.18) | exact lattice statements; Newton from a grid, quad | μ = 0.05 … 500 (roots), 50, 500, 5000 (limit), 0.3 and 2 (energy) |

Numbers worth quoting from the log: E = 5 − πJ and N = 1 − (π/5)J for the unit rest mode of (3, 2) at E₀ = 5 (μ = π/5); at (4, 1, π/2) the H-modes E = 3, 4, 5 carry 3ρ, 4(1 − π/2)ρ, 5ρ; the roots of (2.18) satisfy |2μ Re z/((j + ½)π) − (−1)^j| = 3.4·10⁻³, 3.4·10⁻⁵, 3.4·10⁻⁷ at μ = 50, 500, 5000 and |e^{−2z} + 1| = 0.25, 0.028, 0.0028; min |Re z| over the 26 roots in the box is 0.10, 0.81, 0.63, 0.15, 1.6·10⁻², 1.6·10⁻³ at μ = 0.05, 0.3, 1, 5, 50, 500.

## 5. Controls

Six `[ctl]` lines in the main run (the local part of the energy is not conserved, in (1) exactly and numerically and in (4); a delay that is not an odd quarter period gives roots off the imaginary axis; the coupling per unit density is not E₀; the antisymmetric equation has imaginary roots). Seven wrong versions, each a `--fault` option, each exiting 1 through the FAILS line (`logs/shifted_energy.faults.log`): NOBILOCAL (22 fail lines), SAMETIME (22), NOTWIST (10), READREAL (4, the paper's reading of (2.12)), SINHSIGN (15), COORDSHIFT (4), MIXSIGN (5). In the first fault runs four options (NOBILOCAL, SAMETIME, NOTWIST, COORDSHIFT) ended in an exception when a later step met a non-constant energy or an empty kernel; those steps are guarded, and every fault run now reaches its FAILS line.

## 6. The standard route

Never the labels: complex 4 × 4 Dirac matrices in the Dirac representation, ψ̄ = ψ†γ⁰; scipy `expm`, `quad`, `solve_ivp`, `lambertw`, `brentq`; SVD null spaces; central differences; numpy FFT; Newton's method from a grid for (2.18). Agreement with the exact values: 2·10⁻¹⁵ for the energies by quad, 2·10⁻¹⁰ for the Φ-derivatives by central differences, 10⁻⁹ for the k-derivatives of a moving wave; (2.1) on generic smooth data conserves E to a spread of 10⁻¹².

## 7. Proposed rows (apply.json)

| id | title | evidence | status |
|---|---|---|---|
| ATY-038 | The energy of the shifted theory: Noether's, with a bilocal term; conserved on two-mode fields | en.DELAY, en.NOETHER, en.CONS2 | computation, ran |
| ATY-039 | The energy on the quantized solutions equals the gravitational coupling; (2.12) only with J read as a real number | en.HERM, en.GRAV | computation, ran (a negative result against (2.12) kept) |
| ATY-040 | Two quantized modes at one shift: κτ an odd multiple of π/2; the beat | en.BEAT | computation, ran |
| ATY-041 | Atiyah's one-dimensional equations as the rest-frame halves of the shifted operators; when (2.1) oscillates; (2.17) and (2.18) | en.REST, en.MIXED, en.OSC | computation, ran |

All four as details after ATY-037 on `steps/coupling` (orders 1783–1786), `since: "v2.9"`, depending on ATY-005, ATY-007, ATY-009, ATY-010, ATY-011, ATY-037, CPL-011 and MAP-018 as given in apply.json.

## 8. Not done

- No energy-momentum tensor for fields that depend on space: the energy is defined and checked for fields of the frame's time alone; a moving wave enters only through the k-derivative of the symbol on Dirac matrices. The Lorentz-covariant bilocal current (a generating-function form of the Noether current for exp(−τD)) is not built.
- The symmetric (Belinfante) form is not attempted; the energy is the canonical one of the delay formula, defined up to improvement terms.
- The paper's complex equation away from its quantized modes: there Q = P̃ does not solve the adjoint, and the meaning of the energy for its non-oscillating solutions is not explored (the off-shell identity holds for every pair (P, Q)).
- Feynman's thesis, which the paper cites for a conserved energy with retardation, is not read.
- No claim about experiments: the 10⁻¹³ limit is not re-evaluated, and nothing is said on how an experiment would weigh a J-valued term.
- Packets of more than two frequencies, the second branch E = κ − m (κ > m), and potentials that are not constant.
