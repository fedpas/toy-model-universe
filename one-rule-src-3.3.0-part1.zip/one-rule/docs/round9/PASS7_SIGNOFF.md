<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 7 signed off: the title, the start page in the door, ten panels, the notes (2.9.0-pre.1)

The interface pass of round 9 (the helper's brief, four changes: "Atlas" as the title with "one rule" as its subtitle; the page `#/atlas` merged into the door with the stats at its bottom; four more panels of the door's comic; the notes to researchers at `#/notes`, `#/notes/<key>` and the Logbook's tab Notes) applied on the 2.8.0 tree; its one failing suite fixed by content; every suite run; the acceptance points checked in the built app; a pre-release build packed.

## 1. The files applied

The overlay holds 29 files at their paths in the package. Each was compared with its 2.8.0 file, then copied in.

- **New (3):** `content/notes.json`, `src/components/StageCards.jsx`, `src/pages/Notes.jsx`.
- **Changed (24):** `content/story/door.json`; `docs/02_CONTENT_MODEL.md`, `docs/06_PAGES.md`, `docs/round7/PLAN.md`; `index.html`; `src/app/App.jsx`, `src/app/router.js`; `src/components/Footer.jsx`, `Shell.jsx`, `Statement.jsx`; `src/logbook/LogbookPage.jsx`; `src/pages/Door.jsx`; `src/styles/components.css`, `door.css`, `explore.css`; `tests/coverage.test.mjs`, `door.test.mjs`, `logbook.test.mjs`, `record.test.mjs`, `shipped.test.mjs`, `story/landing.test.mjs`, `ui/explore.smoke.test.mjs`, `ui/fixtures/round7_top.html`, `ui/look.test.mjs`.
- **Identical to 2.8.0 (2, nothing to copy):** `content/pages.json`, `content/story/landing.json` (the page record `atlas` is kept as the data holder that the door draws).

Read against the rules before the run. The test changes follow what they pin, changed by design: the route `atlas` renders the door, the closing strip opens `#/steps`, the contents have no entry "The Atlas", the strip has ten panels, the brand reads "Atlas". Each keeps its self-check and gains one where it reads something new: the door test a seventh broken input (a row placed on the start page where the door does not draw it), the record test a sixth (a statement a page shows whose row its record does not hold), the shipped test's rule 1 a planted note under every text key of `content/notes.json`. The logbook test pins the Notes tab's counts as computed from `derived/status.json`. The record test reads a panel of the door's strip (`statement--bubble`) as it reads a card: a way to another page. `explore.css` drops the rules of the leaf pages (`.xp`, `.leaf-dots`, `.leaf-notes`, `.leaf-hang`, `.leaf-nav`, …), none of which a component draws. `src/pages/Zero.jsx` stays in the tree but nothing imports it: `#/atlas` renders the door.

## 2. The content fix: `content/notes.json`, note `hitchin`

The coverage rule "no row's words outside a Statement" failed 48 times: three paragraphs at the 16 settings of `#/notes/hitchin`. Each paragraph held a run of a row's research text. Exactly those three sentences are rephrased. The note keeps its shape: keys, rows, sections, figures, links, question and thanks are unchanged. The rows they quoted were already in each section's `rows`, so they speak as cards there.

| paragraph | the run it held (row, length) | the sentence now |
|---|---|---|
| `sections[1].text[0]`, "Where the papers and the Atlas met" | "two lines meet exactly when their blades commute" (ATY-030, 49) | "… the 35 lines of PG(3,2) are the blades of square +1, and lines that meet are blades that commute." |
| `sections[2].text[0]`, "What went against the printed page, and was kept" | "The Appendix example of Atiyah and Segal" (ATY-003, 40) | "The example in the Appendix of Atiyah and Segal gives the pages 18, 10, 8 of the spectral sequence where the paper prints 18, 14, 10." |
| `sections[3].text[0]`, "Edge cones, the part closest to your own theorem" | the list of bounds "ℂP² with a line admits only β ≤ 4, with a conic β ≤ 3/2, with a cubic β² ≤ 4/3; a cubic in ℂP² blown up at k points needs k/9 ≤ β² ≤ (12 + 5k)/9" (ATY-036, 145) | "The obstructions it gives are computed exactly on named pairs (ATY-036): a line, a conic or a cubic in ℂP² bounds the cone angle from above, a cubic in ℂP² blown up at k points bounds it from both sides, and K3 with a (−2)-sphere admits no cone angle but 2π." The bounds themselves are the card's. |

A stricter test than the suite's: no run of 40 characters of any text body of `content/texts.json`, at any offset, appears in any of the 19 text strings of `notes.json`. The longest shared run left is 39 characters: the ring ℤ[η, α, β]/(2η, η³, ηα, α² − 4β), shared with ATY-026, in `sections[1]`. **For N1:** keep these three sentences as they read here, or any wording that passes `node tests/coverage.test.mjs`. At learner level the note draws no card, because the ATY rows have no learner text, so the paragraphs speak alone there.

## 3. One more test follows the merge: `tests/ui/smoke.test.mjs`

This file was not in the overlay, and the merge made it fail by design: its screenshots loaded `#/atlas` and wanted the page `atlas`. Now `#/atlas` (shots `door-atlas-*`) must show the door, with the address replaced by `#/?…&at=atlas` (the settings kept) and `#sec-atlas` in view. `#/notes` joins the screenshots (390 and 1366 px, both themes). The phone-width pass reads `#/notes`, every `#/notes/<key>` of `dist/content/notes.json` and `#/logbook/notes`, which is the coverage that `docs/06_PAGES.md` already states. Nothing it checked is dropped. The `zero-*` screenshots it no longer writes were removed.

## 4. The suites

The order: `npm run content` (errors 0, warnings 0), `node tools/migrate/verify_counts.mjs` (all counts as expected), `sh build.sh`, then every suite. The tallies below come from the run at 2.8.0 with the fixed note.

| suite | tally |
|---|---|
| kernel | 376,395 of 376,395 checks |
| engines | 1,090 of 1,090 |
| figures.render | 102,421 of 102,421 (100 figures) |
| logbook | 564 of 564 (the Notes tab among them) |
| maxwell | 215 of 215 |
| physics | 10 of 10 test files |
| story | 5 of 5 test files (the landing test among them) |
| tutorials | PASS, 906 checks |
| explore --data | 24 of 24 tests, 116,192 checks |
| coverage | PASS: 6,367 renders of 101 routes, 244,567 statements (48 problems before the fix) |
| shipped | 69 of 69, 1 warning (the banned phrases of README.md, docs/HANDOVER.md and docs/DECISIONS.md, reported and not failed) |
| chunk | 32 of 32 |
| door | PASS: 2,638 checks, 7 broken inputs caught |
| record | PASS: 39,848 checks, 6 broken inputs caught |
| ui/smoke | PASS (29 screenshots) |
| ui/tutorials.smoke | PASS, 355 checks |
| ui/story.smoke | PASS |
| ui/look | PASS, 7 of 7 injected faults caught |
| explore --ui | 730 checks, 0 failing |
| export --ui | 172 checks, 68 of 68 broken inputs caught |

At 2.9.0-pre.1, the build that is packed: shipped holds 68 of 69. Rule 8 (release files) fails by design on a pre-release with three offenders: "package.json version "2.9.0-pre.1" is not a release number", "docs/RELEASE_NOTES_v2.9.md is missing" and "CHANGELOG.md has no heading naming the version 2.9.0-pre.1". Every other rule holds. Chunk 32 of 32, export 172 checks with 68 of 68 broken inputs caught, smoke PASS, coverage PASS, door PASS and record PASS at that version as well.

## 5. The acceptance points, in the built app over file://

A one-off Playwright script (Chromium; it is not kept in the tree) ran 126 checks, and all 126 hold:

- **The brand.** The `<title>` is "Atlas — one rule". The header reads "Atlas" with "one rule" beside it; at 390 px the subtitle is hidden, as the brief allows. The footer reads "Atlas" · "one rule · cells, clocks and lenses". The door's mark reads "Atlas" over "one rule", above the line "Eight ways into the Atlas."
- **`#/atlas`.** `#/atlas?l=research&m=math` becomes `#/?l=research&m=math&at=atlas`, checked at 1100 px light and dark and at 390 px light. It shows the door with `#sec-atlas` in view: the rows PAG-001, PAG-002 and PAG-503 at research level, then the steps by stage (Algebra, Kinematics, Fields, Dynamics, Observation, Calibrations, each with its counts), "20 steps · all steps · the cells · the lenses", and the record fold of `atlas`. The closing strip opens `#/steps`, with the guide for agents, the tutorials and the notes beside it.
- **The four panels.** Topology (LNC-056), category theory (LNC-030), finite groups (LAB-009) and quantum computing (LNS-021c) are drawn at both levels in both modes. Each "Open →" lands on its page with the row in view: `#/steps/category?at=LNC-056`, `#/steps/category?at=LNC-030`, `#/steps/groups?at=LAB-009`, `#/steps/schuller?at=LNS-021c`.
- **The notes.** `#/notes` and `#/notes/hitchin` were checked at 1100 and 390 px, light and dark, both levels: no overflow, no console error, no KaTeX. The list card reads "16 statements of the Atlas come from this work: 14 proved by the Atlas, 2 our readings" (learner: "14 worked out by a computer, 2 our ideas"). The note shows five sections and the question, six paragraphs (none marked as a row), ten row cards at research level and both tutorial figures loaded.
- **The Logbook's tab "Notes".** `#/logbook/notes` lists the note and opens it.

The screenshots are `tests/ui/shots/pass7-*.png`, 37 files: header and footer at 1100 and 390 px; the door's top at both widths, the whole door and its stats at 1100 px; `#/atlas` at 1100 px light and dark and at 390 px; each new panel at both levels (8); each panel's landing (4); `#/notes` at both widths and themes; `#/notes/hitchin` at both widths, themes and levels (8); the Logbook's tab at 1100 px light and 390 px dark.

## 6. Seen, not changed

- **The strip's height.** The strip is as tall as its tallest bubble. At learner level that bubble is LAB-009 (398 characters, no short register), which makes the strip about 150 px taller at 390 px and 80 px taller at 1100 px than with six panels. A short learner register for LAB-009 would bring it back; that is a text of the tables, outside this pass.
- **Where `#/atlas` lands.** The part lands 192 px below the top: the root's scroll padding (120 px) and the door parts' scroll margin (72 px, `door.css`) add up. It is in view at every width, and one of the two would do.
- **Indices in research texts.** The research texts of LNC-030, LAB-009 and LNS-021c write indices as `e_{F}`, `E_{n}`, `e_i`. They print as typed, in a bubble as on their pages.
- **What `dist/checks/` carries.** It holds the checks folder as it stood at build time, including S1's script in progress (`checks/selfcheck/proofs/shifted_energy.py`, which no row cites yet).

## 7. Not done here

- The release notes of 2.9 and a CHANGELOG heading for the version belong to R1 (wave 2). Until they exist, shipped rule 8 fails at a pre-release number.
- The notes beyond the sample note belong to N1.

## 8. The build packed

`package.json` is at version 2.9.0-pre.1. `sh build.sh` gives `dist/`: 849 files, 47.66 MB; app.js 294.8 kB gzipped, figures-extra.js 244.1 kB gzipped, app.css 116.8 kB; `dist/content/version.json` appVersion 2.9.0-pre.1. The archive `release/one-rule-v2.9.0-pre.1.zip` holds the site with `index.html` at the top, plus `README.md`, `LICENSE`, `docs/RELEASE_NOTES_v2.8.md` and this file. Its size and sha256 are given with the archive, not here, because this file is inside it.
