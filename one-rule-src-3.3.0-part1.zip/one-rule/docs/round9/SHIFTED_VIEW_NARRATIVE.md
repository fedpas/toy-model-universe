<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# A shifted view: how Atiyah reasons, step by step

This file is for the authors of the rewrite (W1, *A shifted view, read on the labels*) and of the notes to researchers (N1). It reads M. Atiyah and G. W. Moore, *A shifted view of fundamental physics* (arXiv:1009.3176, pages as printed on that version) for its reasoning, not its words. For each step it gives the move (why the step follows the one before), the kind of argument, what is taken from others and what is his, the question left open there, and what the labels compute at that step: row ids with *computed* (a recorded run of the row's checks passed), *reading* (ours) or *open* (not computed). Then come the shape of the paper as a whole, how a rewrite keeps that shape, and a short account of how he worked. Words in quotation marks are names of things, never sentences of the paper. The literature, with verified links, is in `SHIFTED_VIEW_SOURCES.md` beside this file.

## The nine steps, checked against the paper

The nine steps of `docs/round9/PLAN.md` follow the paper's own order, and they keep their numbers so that every text of the round can cite them. Read against the paper, they need these refinements, each carried into the step below.

1. Step 1 also plants the paper's target: among the challenges the prologue names is dark energy with a very small cosmological constant, the quantity the paper produces at its end.
2. Step 2 also names the idea's origins (Feynman's thesis, Bjorken and Drell, Raju, and Atiyah's own earlier attempt) and gains a fact the paper does not state (ours, a three-line calculation): the toy equation has a solution that neither grows nor decays exactly when the delay is a quarter period, which ties step 2 to step 4.
3. Step 3 includes the paper's defence of meaning: the shift makes sense on fields slower than light, and a wave at the speed of light cannot be delayed.
4. Step 4: the odd-integer consequence concerns ratios (the Compton wavelengths of any two stable fermions stand in the ratio of two odd integers), not each wavelength; and the step includes the explicit choice between one delay per fermion and one universal delay.
5. Step 5 includes the bound on k (2.15) and the promotion of μ to the theory's fundamental constant; the paper prints no step from (2.10) to (2.12).
6. Step 6 holds three different moves and is cut into 6a (the formal family), 6b (the mixed equation and the way toward quantum theory) and 6c (what was not tried, the seed of the second question).
7. Step 7 includes the paper's three readings of its own equations and its remote link to string field theory.
8. Step 8 includes the fifth-force caveat and the three closing remarks of section 4, one of which (shifting as a process akin to geometric quantization) is the paper's only pointer from gravity to the third question.
9. Step 9 opens with the synthesis that precedes the questions, two constants fixed at the two ends of nature, and is retitled to say so.

## Step 1. Where new ideas come from (section 1, pp. 1–2)

**The move.** The paper opens in the first person, and the opening does two jobs before any equation. It places the reader in a history: a classical line from Newton through Maxwell to Einstein that was geometric, a quantum break that left geometry behind, and a recent fusion of geometry and physics in which Atiyah and Singer took part. It then states the problem of the age, general relativity and quantum mechanics still apart; grants string and M-theory their harvest in mathematics while noting how slender their contact with experiment is; and names what astronomy demands, dark matter and a dark energy with a very small cosmological constant. Only then comes the question that licenses the rest: if radical ideas are needed, who can afford them? Not the young, whose careers the weight of orthodoxy would punish, but the old, who have little to lose. The step earns the right to speculate and, quietly, sets the target the paper will reach at its end.

**The kind of argument.** A historical framing and an argument from the speaker's situation, not from physics; a declaration of genre (speculation, offered as a birthday present to Singer); an appeal to precedent (Einstein's refusal to concede to Bohr).

**Taken, and his own.** Taken: the history of the fusion; the list of string theory's gifts to mathematics (moduli of Riemann surfaces, the Jones polynomial and Witten's invariants, Donaldson and Seiberg–Witten theory, mirror symmetry); the astronomers' two problems; a physicist friend's verdict that string theory is poetry. His own: the diagnosis that the new idea must come from outside the orthodoxy, and the claim that age gives licence.

**Left open.** Nothing technical. The implicit question, whether a geometric idea rather than a quantum one can join the two theories, becomes the third question at the end.

**On the labels.** Nothing to compute. The Atlas's counterpart of this step is its statement of objective and of reach: why it reads this paper (its labels carry the Dirac operator exactly, so a shift of the Dirac operator can be computed on them), and what the labels cannot reach (general wave packets, curved frames beyond a constant potential, the Weitzenböck identity as a theorem, the magnitudes). The Atlas does not speculate in its own voice; its readings are marked *ours*.

## Step 2. One simple equation (section 2, p. 3)

**The move.** With licence granted, he takes the smallest instance of the idea: one linear equation with one delay, (2.1). Rescaling time leaves a single dimensionless number, μ = kr. Two properties are drawn from it. The data that fix a solution are a whole function on an interval, an infinite-dimensional space (L²[0, r]): he calls this an encouraging likeness to quantum mechanics and deliberately does not pursue it. And the exponential solutions are governed by a transcendental equation (z = μe^z) with infinitely many roots which in general have nonzero real parts, so solutions blow up in the far past or the far future. He keeps the likeness as motivation and parks the defect. The step ends on the question that drives the paper: can such an equation make sense in relativity, where there is no preferred time in which to delay?

**The kind of argument.** A worked toy example; an analogy (a space of data like a Hilbert space); a named defect.

**Taken, and his own.** Taken: the theory of delay equations, which he credits to engineers and mathematicians, and three origins in physics: Feynman's thesis (retarded interactions), Bjorken and Drell (a granular spacetime would call for such equations) and Raju (such equations in quantum mechanics); also his own earlier attempt, reported at a Solvay conference. His own: the choice of (2.1) as the germ, and the likeness of its data to a space of quantum states.

**Left open.** Whether the infinite-dimensional data have anything to do with quantum states; whether the runaway roots can be tamed.

**On the labels.** No row yet. S1's computation (`checks/selfcheck/proofs/shifted_energy.py`, in progress) begins with the energy of (2.1). A refinement, ours (three lines, not in the paper, not yet checked on the labels): the roots are z = −W_k(−μ) over the branches of Lambert's function (Silagadze writes the same characteristic equation with it, `SHIFTED_VIEW_SOURCES.md` §2.6), and the paper's "in general" has exact exceptions. Equation (2.1) has the solution x = cos kt, which neither grows nor decays, exactly when kr = (4j + 1)π/2, a delay of a quarter period plus whole periods; for k < 0 the other odd quarter periods, |kr| = (4j + 3)π/2. A generic delay admits only growing or decaying exponentials; the delays that admit a pure oscillation are quarter periods, the one-dimensional shadow of step 4.

## Step 3. Relativity forces the Dirac operator (section 2, pp. 3–4)

**The move.** To delay in Minkowski space he needs a frame-free version of translating by r in time. He first writes the time translation as the exponential of its generator, exp(−r d/dt); the problem then becomes: what is the relativistic version of d/dt, a first-order operator invariant under the Lorentz group? That is the question Dirac answered, so the shift is the exponential of Dirac's operator and acts on spinors, and the relativistic analogue of (2.1) is (2.2), whose delay term carries a factor i. He then defends its meaning. A field moving slower than light is a superposition of plane waves, and on each the exponential delays the wave by r along its own time direction; for waves at the speed of light, continuity, or clocks, forbid any delay. Since spinor fields carry both signs of frequency, the same operator delays one and advances the other: hence the neutral word "shifted", and four natural variants, D₊, D₋, D_s and D_c, of which he follows D₊.

**The kind of argument.** A symmetry requirement (Lorentz invariance) met by what he calls a natural and essentially unique choice; an analogy (d/dt to D) borrowed from Dirac's own motive; a physical-meaning argument on plane waves.

**Taken, and his own.** Taken: Dirac's operator and the reason for it; the exponential of a generator. His own: the exponential of the Dirac operator as the relativistic delay, and the observation that it is retarded and advanced at once.

**Left open.** What e^{−rD} means beyond plane waves (a series in an operator whose spectrum has both signs); the massless limit; which variant, if any, nature uses.

**On the labels.** *Computed* (ATY-005): on the ordinary solutions of mass E the operator e^{−τbD} is the right factor e^{JEτ}, a translation by τ along k/E for the waves e^{−Jk·x} and by −τ for the waves e^{+Jk·x}: a retard and an advance within one solution space, the paper's claim exactly. At a null frequency bD² = 0 and e^{−τbD} = 1 − τbD, a Jordan block, and there is no plane wave unless m = κ = 0, the labels' form of "no delay at the speed of light" (ATY-005). *Computed* (ATY-006, ATY-004): the covariant shift of the whole mass term keeps its plane waves in every frame tried, while a fixed time shift loses the moving wave; a fixed shift vector is bound to a frame. *Reading, ours* (ATY-011): a second reason for retarded and advanced to come together, the adjoint of a translation being the opposite translation, and time reversal swapping the two sheets of the mass shell.

## Step 4. What the plane waves say (section 2, pp. 4–5, with remark 3 of section 2.3, p. 8)

**The move.** A new equation is tested first on its simplest solutions. On a plane wave the shift becomes a phase, and the equation splits into a real part and an imaginary part; since k and r are real, the imaginary part forces cos(rE₀/ħc) = 0. The delay is quantized, an odd number of quarter Compton wavelengths, (2.6)–(2.7). The value r = 0 is excluded by the half-integer, which he says explains the factor i (and, in a footnote, wonders whether it is the zero-point energy of an oscillator); replacing n by n − 1 is the same as changing the sign of k, so both signs count; a massless fermion cannot be delayed. Then a choice: one delay per fermion, which makes the interaction of different fermions awkward, or one universal delay. He takes the universal one and draws its consequences. The delay is at least a quarter of the largest Compton wavelength among the stable fermions, the lightest neutrino's; with an optimistic 1 eV this gives r ≳ 10⁻⁵ cm, uncomfortably large, so that neutrino's integer is of order one (2.8). The rest energy is E₀ = mc² + (−1)ⁿkc (2.9), which he insists is not a departure from Einstein's relation but the link between the inertial rest energy and the equation's parameters. And, placed among the later remarks, the Compton wavelengths of any two stable fermions are in the ratio of two odd integers: large integers for the electron and the proton, perhaps not for the neutrinos, whose masses could one day test it.

**The kind of argument.** A calculation of one line; a choice between interpretations guided by consistency (fermions must interact); an estimate set by the neutrino scale; a speculation in a footnote.

**Taken, and his own.** Taken: Compton wavelengths and the neutrino mass range of the time. His own: the quantization, its reading as one universal delay, the odd-integer ratios.

**Left open.** Each fermion's integer; the meaning of the half-integer; the size of r; the massless case, which returns in step 6c.

**On the labels.** *Computed* (ATY-005): plane waves exist exactly when cos Eτ = 0 and E = m + κ sin Eτ, so Eτ = (n + ½)π, E = m + (−1)ⁿκ and τ = (2n + 1)λ_C/4, and they are the ordinary solutions of mass E; there are none at τ = 0, λ_C/2 or λ_C, none at rational points of the circle, and for κ > m a second branch appears. *Computed* (ATY-009): at the quantized shift the shifted solution is ψJ, a quarter turn of the spinor and a half turn of its frame; the current and the spin are unchanged and the other two bilinears change sign. This is the mechanism in one line: the label J is the paper's i, and the quarter turn of the shift turns the imaginary term back into a real mass. *Computed* (ATY-004): shifting the whole mass term by a fixed vector instead puts the plane waves on the lattice θ ∈ (π/2)ℤ, the quarter turn again. For the rewrite: the inputs of (2.8) have moved, and `SHIFTED_VIEW_SOURCES.md` §4.8 gives the current neutrino bound, which raises r to at least about 7 × 10⁻⁵ cm.

## Step 5. A deviation to measure (section 2, pp. 5–6)

**The move.** A modified equation must depart from known physics somewhere, and the departure should be sought where measurements are sharpest. He writes the action (2.10), says that the energy-momentum tensor follows from it, puts the action in a weak static gravitational field (2.11), and reads the coefficient of the Newtonian potential on the rest solutions as the gravitational rest energy, T₀₀ = E₀(1 − μ(−1)ⁿ) (2.12). Gravitational and inertial rest energies then differ by the fraction (−1)ⁿ⁺¹μ (2.14); the limit on violations of the equivalence principle, about 10⁻¹³, bounds μ, and with the r of step 4 it bounds k/ħ below 10⁻⁸ cm⁻¹ (2.15). He promotes μ = kr/ħ to the fundamental constant of the theory, binding its two dimensional parameters through Planck's constant.

**The kind of argument.** A calculation announced by its result, with no intermediate step printed; an experimental bound; dimensional bookkeeping.

**Taken, and his own.** Taken: the weak-field metric and the first-order Dirac operator in it; Will's review for the bound. His own: the Φ-coefficient read as T₀₀; μ as the constant of the theory; the remark (step 6a) that the violation is similar for all four variants.

**Left open.** The energy-momentum tensor of a nonlocal action, said to be derivable and not written; the steps from (2.10) to (2.12).

**On the labels.** *Computed* (ATY-037): on the orthonormal frame of a constant potential the shifted equation is the flat one at the frame frequency; the quantization holds in proper time, and the coordinate rest energy is E₀√(1 − 2Φ) for every n, the redshift of any clock. The coefficient of Φ in the paper's operator on the rest solutions is E₀P(1 − (−1)ⁿμJ): its scalar part is E₀ for n even and odd alike, and the paper's deviation sits on the quarter turn PJ, which has no scalar part. Reading that coordinate as a scalar gives (2.12) exactly, and that reading is the control that must fail; so (2.12) is not reproduced from the printed operator. *Open:* the energy-momentum tensor. S1 computes the Noether energy of the action and its Φ-coefficient, which is what an equivalence-principle test of a shifted fermion would measure.

## Step 6. Remarks: the family, the mixed equation, what was not tried (sections 2.1–2.3, pp. 6–8)

The paper gathers its remarks in three lists. They are three different moves, and the rewrite and the notes should keep them apart.

### 6a. The formal family (section 2.1, and remark 1 of section 2.2)

**The move.** With one equation in hand, he enlarges the family to see what is robust. D₋ gives the same results with particles and antiparticles exchanged; D_s and D_c have no quantization, only a transcendental relation among E₀, m, k and r; D_s with m = 0 admits massless waves and D_c does not; the equivalence-principle effect is similar in all four. A shifted Klein–Gordon operator is D₊D₋, a series in D² (2.16). Coupled to forms, d + δ can be exponentiated but does not keep the degree, so Maxwell is postponed to step 8. Supersymmetry and superspace are flagged. And the toy (2.1) is a skew-adjoint operator plus a unitary one, an element of an "affine operator group", a degenerate form of a semisimple group, as the Poincaré group is a contraction of one.

**The kind of argument.** A catalogue; a structural analogy (Wigner's contraction).

**Taken, and his own.** Taken: Klein–Gordon from Dirac, Hodge's d + δ, Wigner's contractions. His own: the four variants and the affine-group reading.

**Left open.** Which variant; the representation theory of the affine operator group; supersymmetry.

**On the labels.** *Computed* (ATY-007): D₋ has the same plane waves as D₊ at the ten test points, so the exchange of particles and antiparticles is not visible on free plane waves; D_s has solutions whenever E = m − κ sin Eτ, with no quantization, and keeps the massless solutions; D_c as printed, with its factor i, has solutions exactly where E = m + κ cos Eτ at the points tried, a relation and not a quantization, so the paper's remark holds as printed, while read without the i it would be quantized. *Computed* (ATY-010): the products as formal series in one commuting D are exact to order 12, with constant terms −κ², κ², 0.

### 6b. The mixed equation, and the way toward quantum theory (remarks 2 to 4 of section 2.2)

**The move.** The relativistic equation is retarded and advanced at once, so he returns to one dimension to see what having both does. The mixed equation (2.17) is no longer an evolution equation and, he says, its theory has hardly been developed; it again has infinitely many exponential solutions, now from z = μ(e^z + e^{−z}) (2.18), again with nonzero real parts. Then three ways out are glimpsed. In the limit μ → ∞ the real parts vanish and the solutions become anti-periodic with period 2r, so for large μ there is a finite family of acceptable oscillations, at least for a while; small and large μ might be related by a duality, as small and large r are in Fourier theory. Feynman had studied a similar equation, a particle and its virtual image, and found, against expectation, a conserved energy. And for the shifted Dirac operator the trouble will come from mixing the two signs of frequency under external forces, which in quantum field theory is exactly what forces Fock space: an operator easy to define with profound consequences, whose link to quantum theory would not surprise.

**The kind of argument.** A worked toy again; a limiting argument; an analogy (Fourier duality); a precedent (Feynman); a conjectured link.

**Taken, and his own.** Taken: Feynman's thesis; Fourier duality; Fock space. His own: the mixed toy, the large-μ limit, and the reading of frequency mixing as the door to quantum theory.

**Left open.** The theory of mixed equations (a mathematical theory exists, `SHIFTED_VIEW_SOURCES.md` §4.5); the energy; the Fock-space link, which is the third question in embryo.

**On the labels.** *Open*, in progress with S1: the Noether energy of the shifted action, its conservation on two-mode superpositions and the beat, the mixed equation on the labels. Feynman's conserved energy is the template, a local part plus an integral over the window from t − τ to t + τ (sources §3). A refinement, ours (one line each, on plane waves x = e^{iωt}; not on the labels): add a mass-like term imx to the toys. The retarded toy, ẋ + imx + kx(t − r) = 0, gives cos ωr = 0 and ω = −m ± k: quantized, with the mass shifted, as D₊. The mixed toy with the paper's sign, ẋ + imx + k(x(t − r) + x(t + r)) = 0, gives cos ωr = 0 and ω = −m: quantized with the mass unshifted, as D_c read without its i. With a factor i on the shifted terms it gives ω + m + 2k cos ωr = 0 for every r: no quantization, as D_c as printed. The sinh form, ẋ + imx + k(x(t − r) − x(t + r)) = 0, gives ω + m = 2k sin ωr for every r: no quantization, as D_s. Without the mass term, the paper's own toys: (2.1) oscillates exactly when kr = (4j + 1)π/2 (step 2), and (2.17) never does, in line with the paper's remark that its roots always have nonzero real parts. The one-dimensional toys sort the variants as the labels do (ATY-005, ATY-007).

### 6c. What was not tried (section 2.3)

**The move.** An inventory of the distance between the equation and the Standard Model: no nontrivial electromagnetic background and no quantum interactions, so none of the successes of quantum electrodynamics (Bhabha and Compton scattering, the Lamb shift, the anomalous magnetic moment) has been checked, though interacting string field theories give hope that interactions can be included; no massless fermions, so chiral representations and the Higgs mechanism have no obvious place; and the odd-integer ratios as a test.

**The kind of argument.** A confession of what is missing, with one proposed test.

**Taken, and his own.** Taken: the Standard Model's checklist. His own: the test by neutrino masses.

**Left open.** The second question, in its particle half.

**On the labels.** *Computed* (ATY-008): in a constant potential a fixed shift of the mass term is gauge covariant only with a transport factor exp(−JeA·a), while e^{−τbD_A} depends on k − eA alone, so the shifted operator is gauge covariant in the simplest background. *Computed* (ATY-005): no massless plane wave for D₊. *Reading, ours:* D_s keeps massless solutions (ATY-007), so if chiral fermions are to be shifted at all, D_s is the variant that admits them. *Open:* the processes of quantum electrodynamics; the Higgs mechanism.

## Step 7. Shift the Einstein equations (section 3, pp. 8–11)

**The move.** Setting aside the link to quantum mechanics, he asks whether gravity itself can be shifted. Gravity's operator is of second order, so he needs a bridge from Dirac to Ricci, and the Weitzenböck identity is that bridge: on 1-forms the Hodge Laplacian minus the Bochner Laplacian is the Ricci tensor, and with d + δ read as a Dirac operator D, D² + ∇² = Ricci (3.2). The vacuum equations then say that two Laplacians agree, and shifting D shifts Ricci. There are ten ways to do it; he keeps three, compressing the square of D₊ back onto 1-forms because it does not keep the degree (3.3)–(3.4), and writes the shifted Einstein equations (3.5). He confesses that their meaning is not clear, and proposes to read them as series in D², that is, as low-energy expansions. At leading order Ricci = −k²/ħ², +k²/ħ² or 0 (3.6): a cosmological constant Λ = ±k²/ħ², or none. The sign is a choice, which he calls hardly a triumph; the size, matched to the observed Λ ~ 10⁻⁵⁶ cm⁻², fixes k/ħ ~ 10⁻²⁸ cm⁻¹, far below the bound of step 5, and with the r of step 4 gives μ ≳ 10⁻³³ (3.7)–(3.9). Then three readings of (3.5): a series in r²Δ, which should make sense on 1-forms even beyond perturbation; a restriction to 1-forms solving the wave equation, which fails because Δ need not commute with Ricci, though it might work order by order in μ; and an equation for the pair (g, φ) on the Hilbert space of 1-forms (3.11), reminiscent of Einstein-aether theories. Last, a remote link: exponentials of α′∇² in string field theory, and Witten's speculation that string theory will revise quantum mechanics.

**The kind of argument.** A transfer through an identity (Weitzenböck); a choice under ambiguity; a leading-order expansion; a dimensional match to observation; a confession of ignorance; analogies (aether theories, string field theory).

**Taken, and his own.** Taken: the Weitzenböck formula and Bochner's vanishing argument; a colleague's check of the signs; the observed vacuum energy; Einstein-aether theory; Witten's speculation. His own: the replacement of D by shifted operators inside the Weitzenböck identity; the compression; Λ = ±k²/ħ² and the reading of k as a cosmological parameter.

**Left open.** The first question itself: what (3.5) means; which shifted Ricci tensor, if any, a logical argument would select; why the observed sign.

**On the labels.** *Computed* (ATY-010): D₊D₋ = D² − 2κD sinh(τD) − κ², the even part of D₊² is D² − 2κD sinh(τD) + κ² cosh(2τD), and D_s² = D² + 2κD sinh(τD) + κ² sinh²(τD), exact to order 12, with constant terms −κ², κ², 0; with the Weitzenböck formula (recalled, not checked) these give the paper's Ricci = κ², −κ², 0. *Reading, ours* (ATY-010): as for the Atlas's own cosmological term c, whose sign is minus the square of a generator (INP-049), size and sign stay inputs; the shift moves the input from c to k and does not derive it. *Open:* the Weitzenböck identity on the engine; the magnitudes (3.7)–(3.9), which the Atlas has not computed.

## Step 8. Einstein–Maxwell by Kaluza–Klein (section 4, pp. 11–12)

**The move.** Maxwell's operator cannot be shifted directly, since the exponential of d + δ does not keep the degree of forms (step 6a). So he obtains it from gravity: shift Einstein's equations in five dimensions on a circle bundle over spacetime and reduce, which gives shifted Einstein–Maxwell equations in four. The by-product he calls amusing: with no electromagnetic field the radius of the circle obeys −∇²e^σ = ε(k/ħ)²e^σ (4.3), an eigenfunction of the four-dimensional Laplacian, and in de Sitter space its homogeneous solutions grow or decay exponentially on the time ħ/kc (4.4). That looks potentially devastating, until the k of step 7 makes the time about the age of the universe; the coincidence problem of cosmology, that we live just when the cosmological constant turns from negligible to dominant, becomes a blessing rather than a curse. He adds that a massless scalar coupled with gravitational strength is a problem for fifth-force experiments, that the zero-mode approximation fails once the growth matters, and three closing remarks: non-abelian Yang–Mills fields by reduction on larger isometry groups; shifting geometric operators as a natural process akin to geometric quantization, one that includes gravity, which quantization has not reached; and the reliance on spinors, the Dirac operator and Kaluza–Klein theory as a pointer to supergravity and strings.

**The kind of argument.** A structural reduction that sidesteps a direct obstacle; a short calculation; an order-of-magnitude coincidence of the kind Dirac's large numbers made famous; a confession (the fifth force); an analogy (geometric quantization).

**Taken, and his own.** Taken: Kaluza–Klein reduction; de Sitter space; the coincidence problem; fifth-force tests. His own: shifting in five dimensions; reading the growth time as the age of the universe; the comparison with geometric quantization.

**Left open.** The dilaton against fifth-force bounds; the non-abelian extension; the relation between shifting and geometric quantization, the paper's one pointer from gravity to the third question.

**On the labels.** *Computed in part* (ATY-010): the radius equation has the structure of □φ = 4cφ at F = 0 in the five-dimensional Einstein form with a cosmological term (LNS-017e, its script re-run); the constants are not compared. *Open:* the magnitudes; the fifth-force question.

## Step 9. Two constants, two ends; three questions (section 5, p. 13)

**The move.** He gathers the paper into one sentence: operators that shift, retarding or advancing, the basic operators of mathematical physics (Dirac, Maxwell, Ricci), with two physical parameters. The delay r is fixed at the atomic end, by a quantization in Compton wavelengths that carries Planck's constant; the strength k at the cosmological end, by the cosmological constant. He calls this a satisfactory situation, reminiscent of Banks's ideas, and records the dimensionless μ = kr/ħ ≳ 10⁻³³ (5.1)–(5.4). Then, in place of conclusions, three questions: the meaning of (3.5); whether the ideas can make a coherent model compatible with the Standard Model and with cosmology; how shifted equations relate to quantum mechanics. They are left to others and to the future, with the remark that both sides carry philosophical and mathematical difficulties.

**The kind of argument.** A synthesis by estimates; an explicit hand-over.

**Taken, and his own.** Taken: Banks's holographic picture, as a resonance. His own: the synthesis and the questions.

**Left open.** The three questions.

**On the labels, question by question.**

*Q1, the meaning of (3.5).* The formal series are exact (ATY-010, computed); the cosmological constant they give is an input moved from c to k (ATY-010, reading); the meaning of the operator equations stays open.

*Q2, the Standard Model and cosmology.* D₊ has no massless shifted fermion (ATY-005, computed), so chiral fermions cannot be shifted as D₊; D_s keeps massless solutions (ATY-007, computed), the variant chirality would need (reading); the shifted operator is gauge covariant in a constant potential (ATY-008, computed); the equivalence-principle term is a quarter turn, not a real energy (ATY-037, computed), so whether the paper's bound applies stays open until the Φ-coefficient of the Noether energy is known (S1). The magnitudes are the paper's, not computed, and their inputs have moved (sources §4.8).

*Q3, quantum mechanics.* At the quantized shift the shifted wave is the wave turned by a quarter (ATY-009, computed), exactly at cos Eτ = 0 (ATY-005, computed), and the quantization follows proper time on a frame (ATY-037, computed): the shift behaves as a clock. The energy of the nonlocal action, its conservation and the two-mode beat are S1's, in progress; the Fock-space and Hilbert-space readings stay open.

## The shape of the whole

Read as a structure, the paper has six features worth keeping.

1. **A prologue in the first person** that earns the right to speculate and plants the target: a very small cosmological constant, named as one of astronomy's two challenges, is what the paper produces at its end.
2. **A toy** that shows both the promise and the defect: an infinite-dimensional space of data, like quantum states, and runaway roots.
3. **A chain of moves, each presented as the natural or essentially unique choice:** d/dt becomes D; delayed becomes shifted, because spinors have both frequencies; plane waves give the quantization; one delay serves all fermions; the action gives T₀₀ and the equivalence-principle test; D² becomes Ricci through Weitzenböck; Maxwell comes through Kaluza–Klein.
4. **A difficulty named and parked at every link,** rather than solved: a formal equation, an unphysical divergence, an uncomfortably large delay, equations whose meaning is not clear, a sign that is no triumph, a potentially devastating growth, a fifth force. The parked difficulties are the paper's honesty, and its open questions grow from them.
5. **Estimates that pin the two constants from the two ends of nature:** the lightest neutrino's Compton wavelength fixes r, the cosmological constant fixes k, their product over ħ is a pure number near 10⁻³³, and a coincidence of times (ħ/kc against the age of the universe) is claimed as a virtue.
6. **Questions as the conclusion,** handed to others.

Beneath these, the paper alternates between matter (the Dirac equation, steps 2 to 6) and geometry (Ricci and Kaluza–Klein, steps 7 and 8), and travels from the smallest object (one function of one variable) to the largest (the universe), then comes back down, in its conclusion, to two numbers. The Atlas's own rule of work, going up from the lowest cell and then coming down from the highest object it can grasp (D37), has the same rhythm; a note may say so.

## Keeping the shape: the rewrite and the notes

**For the rewrite (W1).** Keep the order and the six features; replace each speculative link by what the labels compute, and keep every parked difficulty as an *open* mark.

- *The prologue.* Replace the licence to speculate by the Atlas's objective and reach: why the Atlas reads this paper (its labels carry the Dirac operator, and the shift is computable on them exactly), the method (objectives first, background set to noise, the bit rule against a standard route with controls that must fail), and what the labels cannot reach (step 1). The Atlas does not speculate in its own voice; where it reads, it says *ours*.
- *The toy.* Keep (2.1) first, with its data space and its runaway roots, and add, once checked on the labels, the quarter-period oscillation that ties it to the quantization (step 2), and S1's energy of the toy.
- *Each natural choice.* State the paper's move in the Atlas's words, never quoting its sentences; then the result with row ids and status; then what stays open. Where the labels give something other than the printed page, say what the page prints and what the labels give, and keep both: (2.12) against the quarter turn (ATY-037); D_c with and without its i (ATY-007); the exchange of particles and antiparticles, not visible on free plane waves (ATY-007).
- *The estimates.* Keep them as the paper's, marked *not computed*. Where an input has moved since 2010 (the neutrino mass, the equivalence-principle bound), give the current value from `SHIFTED_VIEW_SOURCES.md` §4.8 as its source states it, never as an Atlas result.
- *The questions.* End with the three questions, each answered as far as the labels go (step 9), the rest marked open. The paper's hand-over to others and to the future becomes the four directions of `SHIFTED_VIEW_SOURCES.md` §6.4, each a computation the Atlas can run.
- *The literature.* Cite the sources where they meet a step: the 2+1 gravity origin of the exponentiated Dirac operator at step 3; Feynman's window energy and the theory of mixed equations at step 6b; MICROSCOPE and KATRIN at steps 4 and 5; the delayed cosmologies and time-nonlocal gravity at steps 7 and 8.

**For the notes (N1).** A note follows the skeleton objective → what the Atlas said first → where it met the work → what it could not reach → one question, and the paper's shape maps onto it.

- *Objective:* step 1 rewritten as the Atlas's aim, the relativistic shift of the Dirac operator computed on the labels.
- *What the Atlas said first:* the predictions written before the paper was read (the Atlas's analysis page, paper 177): a retarded term alone puts the plane waves on a lattice θ ∈ (π/2)ℤ; a condition in whole or half periods; a fixed shift vector is bound to a frame; advanced plus retarded makes the factor real and gives back a continuous shell; a fixed shift is gauge covariant only with a transport factor; a small Λ needs a second constant, an input, with its sign a choice.
- *Where it met the work:* steps 3 to 5 (ATY-005, ATY-009, ATY-037): the exact retard and advance, the quantization, the quarter turn, the proper-time clock.
- *What it could not reach:* the Weitzenböck identity as a theorem, the magnitudes, the energy-momentum tensor until S1's computation lands, wave packets, Fock space.
- *One question:* for instance, to Moore, whether an equivalence-principle test of a shifted fermion measures the operator's Φ-coefficient or the Noether energy's; to Schroers, whether the 2+1 constraint, e^{−(λ/2)D}φ = e^{λm/2}φ in our transcription, carries a quantization of its own. Rows appear as cards, never quoted in the free text.

## How he worked

From Schroers's memoir (attached; arXiv:1910.10630) and from the Atlas's account of the masters' method (`public/reports/analyses/src/atiyah_lens.md`, sections 3 and 4, recorded in `docs/round8/ATIYAH.md`).

**The intentional physicist.** His early influence on physics came without his intending it: he and Singer met the Dirac operator again from the side of mathematics. In his Edinburgh years he took up physics on purpose, aiming at its foundations, with three projects running together: the conjecture on configurations of points, the difference-differential equations of this paper, and the geometric models of matter. The conversations with Schroers began because the shifted equations arise naturally in three-dimensional quantum gravity.

**What he wanted.** He doubted that any linear theory could be fundamental, disliked the collapse of the wave function, and thought that physicists had never questioned the habit of solving initial-value problems; the shifted equation, which drops that habit and admits non-locality, appealed to him for exactly those reasons, and his lectures said so. The Dirac operator was his bridge between nonlinear geometry and linear quantum theory. Gauge theory seemed to him to demand too many arbitrary choices, four-dimensional geometry fewer. Division algebras and Bohm's explicitly nonlocal mechanics stayed in his conversation without reaching his papers.

**How ideas came and went.** Into his eighties he came to his office nearly every day, produced ideas at a great rate, announced them with enthusiasm and dropped them without regret when a better road opened. The ideas were mathematical even when the questions came from physics. He needed partners, or at least listeners, and kept several conversations going at once. He trusted his instinct, and great minds: Maxwell, Einstein and Dirac above all, including the later work of Einstein and Dirac that others set aside, in which he saw his own late years. His last advice to the young was passion, persistence, risk and the search for beauty. In his collected works he calls this paper the wildest of his late ones and a first step in the dark (as the Atlas's analysis page records, section 1).

**The masters' method, as the Atlas's analysis records it.** Listen, then reformulate in one's own terms; wait for the right question; take the physicists' examples and give them the mathematician's structure; insist on the proof that explains; hold on to the finite model as the only rigorous grip. In this paper the method is visible: the simplest example first, (2.1); transfers along identities (d/dt to D, D² to Ricci, five dimensions to four); estimates from both ends of nature; difficulties named and parked; questions at the end.

**The Atlas's method beside it.** Objectives first: read the title, the abstract and the first page, write down what the Atlas's own primitives predict, then read the rest, with background knowledge set to noise. Start at the lowest cell, cross-check every lens, go up, then come down from the highest object grasped; a rung the data lack is marked not stored, never extrapolated (D37). Every claim has a bit-rule route, a standard route and controls that must fail, and a negative result is kept as one. Where the two methods meet: the toy example and the finite model; two routes to one result; structure before detail. Where the Atlas is stricter: it gives nothing to beauty, turns each natural choice into a check or a marked reading, and keeps (2.12) as not reproduced rather than smoothing it over. Where Atiyah would push the Atlas: his questions live in the infinite-dimensional (wave packets, Fock space, the Hilbert space of 1-forms), and the Atlas's open marks are where its next checks go.
