<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Notes to researchers: the list, the method, the checks

This pass (owner N1 of the round) delivers four files:

- `content/notes.json`: 27 notes to 37 researchers, the Hitchin note as its owner (I1) wrote it and 26 written here. It is a shipped table of kind view (docs/02_CONTENT_MODEL.md §8), rendered by `src/pages/Notes.jsx` at `#/notes` and `#/notes/<key>`.
- `docs/round9/outreach/EMAILS_v4.md`: one short e-mail for each note, not shipped.
- `tools/check_notes.mjs`: the checks of the notes and of the e-mails (11 rules, below). It reads only.
- this file.

Nothing else in the repository was changed.

## The notes

Every note has four sections in the order of the Atlas's own reasoning, the structure that docs/round9/PLAN.md and the Atiyah analysis follow (the structure, not their words): what the labels said before the reading, where the work and the Atlas met, what the labels add, what the Atlas cannot reach; then one question only the authors can answer, and one line of thanks. The Hitchin note keeps its owner's five headings. The rows are the union of the cards of the note's sections, counted by the status the tables compute (derived/status.json).

| key | to | rows | by status |
|---|---|---|---|
| lundholm-svensson | Douglas Lundholm, Lars Svensson | 9 | 8 proved, 1 about the Atlas |
| hestenes | David Hestenes | 13 | 11 proved, 2 input |
| roelfs-eelbode-de-keninck | Martin Roelfs, David Eelbode, Steven De Keninck | 11 | 6 proved, 2 ours, 2 open, 1 about the Atlas |
| wise | D. K. Wise | 10 | 6 proved, 1 ours, 3 input |
| gunn | Charles Gunn | 8 | 7 proved, 1 standard |
| lasenby-doran-gull | Anthony Lasenby, Chris Doran, Stephen Gull | 8 | 6 proved, 1 ours, 1 input |
| hsu-barker-hobson-lasenby | Hsu, Barker, Hobson, Lasenby | 11 | 9 proved, 1 input, 1 about the Atlas |
| dorst-de-keninck | Leo Dorst, Steven De Keninck | 14 | 11 proved, 1 input, 1 open, 1 about the Atlas |
| ablamowicz | Rafał Abłamowicz | 9 | 7 proved, 1 standard, 1 open |
| tian | Yin Tian | 8 | 5 proved, 1 standard, 2 open |
| majkic | Zoran Majkić | 12 | 10 proved, 2 ours |
| pumplun | Susanne Pumplün | 4 | 4 proved |
| baez | John C. Baez | 12 | 8 proved, 1 ours, 3 open |
| baez-schwahn | John C. Baez, Paul Schwahn | 9 | 7 proved, 1 standard, 1 about the Atlas |
| baez-bokor-boyle | John C. Baez, Endre Bokor, Latham Boyle | 12 | 8 proved, 1 standard, 2 ours, 1 open |
| baez-pumplun | John C. Baez, Susanne Pumplün | 8 | 7 proved, 1 about the Atlas |
| furey | N. Furey | 11 | 8 proved, 2 input, 1 open |
| schuller | Frederic P. Schuller | 14 | 10 proved, 1 standard, 2 ours, 1 open |
| schuller-closure | Maximilian Düll, Frederic P. Schuller, Nadine Stritzelberger, Florian Wolz | 15 | 11 proved, 1 standard, 1 input, 2 open |
| hitchin (I1) | Nigel Hitchin | 16 | 14 proved, 2 ours |
| segal | Graeme Segal | 5 | 5 proved |
| moore | Gregory W. Moore | 16 | 14 proved, 1 ours, 1 input |
| sutcliffe | Paul Sutcliffe | 8 | 7 proved, 1 ours |
| manton | Nicholas S. Manton | 9 | 9 proved |
| schroers | Bernd J. Schroers | 7 | 7 proved |
| lebrun | Claude LeBrun | 10 | 8 proved, 2 ours |
| eastwood-norbury | Michael Eastwood, Paul Norbury | 1 | 1 proved |

In all: 270 row citations (a row counted once per note) over 235 distinct rows: 214 proved by the Atlas, 7 standard, 17 our reading, 12 needs an input, 14 open, 6 about the Atlas.

Who is included: a researcher, or a group of co-authors, whose work the Atlas read (in full or in the parts its reading names) and computed from, and who can answer. Each note is addressed to the authors of one work or of one set of works read together. A person who wrote several of the works has several notes (Baez four, Pumplün two, De Keninck two, Lasenby two, Schuller two).

## Left out, and why

- M. F. Atiyah: his late papers are the subject of the Atiyah lens, read through Hitchin's account and through the notes to his co-authors (Segal, Moore, Sutcliffe, Manton, Schroers, LeBrun) and to Eastwood and Norbury, who proved his conjecture for four points. R. Bott and A. Shapiro likewise: the Atlas reads their Clifford modules through D. Chua's exposition.
- D. Chua: an exposition read for a recalled table (ATY-001); no result of its own is tested. A note could thank it; the owner decides.
- R. Dijkgraaf: co-author of paper 176 of the Collected Works and of the Dijkgraaf–Witten count recalled in ATY-031; no row computes from that paper alone, and the Hitchin note covers the account.
- Oliveira and Meluccio: second sources, with Wise, for the published form of the gravity action and the convention Λ = 3c (INP-044, INP-048, INP-049, GRV-007, GRV-010). Their own results are not tested; a note would carry one convention. Candidates if the owner wants one note each.
- Huang: the signed hypercube with D² = n·I is checked on the labels and read as the Clifford relation (SPR-002, SPR-004, SPR-M17, SPR-M19, SPR-M20), but the rows cite the statement and do not record the paper as read. A good candidate once the owner confirms the reading.
- Li and Ding: their inertial form is one of the references the free top is compared with (EQN-019, PAG-024, PRJ-005); the Atlas holds no first names for them, and a note would carry one comparison. Candidate.
- M. J. Hughes: co-author of Three generations and a trio of trialities, named in the work line of the Furey note; the rows of that note rest on the paper on nested embeddings. The owner decides whether he is addressed too.
- S. Rea and R. Dadhley: the note-takers of Schuller's lectures, named in the work line of the Schuller note; the notes transcribe the lectures, so the note is addressed to the lecturer.
- Vollick (abstract only) and Vishveshwara (Appendix B only): partial reads; the question of the null-surface note asks the authors about Vollick.
- Jancewicz: cited for one count, 36 = 20 + 15 + 1 (LNS-013).
- Hitzer, Nitta and Kuroe (one survey, PRJ-004); Bojowald, Duque and Shah, Bagchi, and Duval, Gibbons and Horváthy (abstracts only, LNS-014); Engel and Smillie (cited by Baez, not read); Dechant and Holmer (named as not read in FRQ-005); C. Brown (co-author of a Pumplün paper the report cites but does not read).
- The textbooks and monographs that stand as the standard reference of a row (Lawson and Michelsohn, Lounesto, Peskin, Weinberg, Wald, Jackson, Sakurai, Bourbaki, Coxeter, Humphreys, Kac, Loos, Lam, Serre, Sharpe, Eastham, Reed and Simon, Skowroński and Yamagata, Năstăsescu and Van Oystaeyen, Bass, Wall), and the classical results recalled rather than read (Kramers, Dyson, Bethe, McKay, Douglas and Moore, Albuquerque and Majid, Dokuchaev and Khrypchenko, Kitaev, Inönü and Wigner, Bacry and Lévy-Leblond, Gerstenhaber, Hawking, Eguchi, Gilkey and Hanson, Singer and Thorpe, Kibble, Hehl and Datta, Kogut and Susskind, Williamson, Lawvere, Brown, Kirby and Taylor, Schwartz, Zippel, Okniński): the Atlas recalls or points to them and computes nothing against their own text.

## Method

1. The reading of each work: the rows a note may cite are those of the work's reading. A row belongs to it when its standard reference or its research text names the work, when it stands on the page that reads the work, or when the reading's own file (a report, the Atiyah analysis, the sources table) names the row or the object it computes. `tools/check_notes.mjs` writes this out note by note (its table READING) and rule D checks every row.
2. The sections: the first section holds the rows the Atlas stands on before the work; the second where the work and the Atlas meet, agreeing or not; the third what the labels add that the work does not have; the fourth the limits, from the rows that say what is not computed. The question is the one point that only the authors can settle: a reading to confirm, a sign convention, a printed line the Atlas computes otherwise, a page it could not read.
3. The words: the paragraphs narrate and the cards state. A paragraph is plain text in the Atlas's register: short sentences, present tense, no history words, no superlatives, nothing the rows of the note do not state. A number appears in a paragraph only when a card of the same section shows it. No free string holds a run of 40 characters of any text record of the Atlas, at any offset: stricter than the coverage test, which compares windows taken every 40 characters. Badges stay on the cards; a paragraph says "the Atlas's reading" where a row is ours, and "is an input" where a row needs one.
4. Pictures and links: a section shows at most one picture, an engine figure of `content/figures.json` or a tutorial figure under `public/reports/tutorials/src/<course>/figs/`, and links to the page or the report that reads the work.
5. The file's header: the `line` describes the four sections; the `about` keeps I1's sentence on what "proved by the Atlas" and "our reading" mean and adds one: a note is a view of the Atlas and changes no row.
6. The e-mails: written in the owner's voice to a peer, each opening with one result the Atlas reproduced or where it differs, with one link to the note, one picture of the note, the note's question, and a closing line; at most 120 words. The 12 that should wait for the owner's judgement carry a line "Hold:" with the row that goes against the printed page.

### How the owner fills `earlier`

When a letter has already gone to a researcher, the owner adds it to that note as `"earlier": { "date": "YYYY-MM-DD", "text": ["first paragraph", "second paragraph"] }`, the date the letter was sent and its paragraphs as sent, one string each. The page shows it folded, under "What the first letter said", after the thanks. The paragraphs are free text like the others: rule 1 of `tests/shipped.test.mjs` reads them for history words, the coverage test forbids 40 characters of a row's text in them, and `node tools/check_notes.mjs` checks both, with the shape. A letter that quotes a row is shortened to a reference to the row's card instead. The date field is not read for history words.

## Checks run

`node tools/check_notes.mjs` (with `--list` for every offender): 11 of 11 rules pass on the file as installed.

- A shape: 27 notes, unique plain keys, each with names, work, lead, sections, question and thanks; `about` says that a note is a view of the Atlas and changes no row; no note has an earlier letter yet.
- B order: 26 notes in the four sections of the narrative; the Hitchin note (I1's) keeps five headings of its own, reported and not failed.
- C rows: 235 distinct rows, each in `content/rows.json` with a research text; every note's `rows` is the union of its sections' rows, except the Hitchin note (reported: 16 rows listed, 10 on its cards).
- D reading: every cited row belongs to the reading of its note's work: 195 citations by the standard reference, 27 by the research text, 10 by the page that reads the work, 38 by an anchor in the reading's own file.
- E pictures: 16 figure ids, all in `content/figures.json`; 24 tutorial figures, all on disk.
- F links: 63 links, every route one the router renders, every href a file of `public/`.
- G words: 430 free strings, no run of 40 characters of any of the 3314 text records at any offset.
- H numbers: 329 numbers in 147 paragraphs, each shown by a card of its section (the Hitchin note reported: three, a cell name and two row ids in its prose).
- I history: no banned history phrase (families P1–P9 of the shipped test, every date banned), no superlative, no flattery, no claim the Atlas never makes.
- J contact: no e-mail address, web address, telephone number, user path or postal address in the 1138 strings of the notes (names included), in the e-mails or in this file; the licence comment is the Required Notice and is not read as a contact.
- K e-mails: 27 e-mails, 2805 words in all, each under 120 words with a subject, one link to its note, one picture of the note, one question, nothing on who wrote it; 12 held.

`tests/coverage.test.mjs` passes on the tree with the 27 notes installed: 6783 renders of 127 routes (among them `#/notes`, the 27 notes and a key no note has, in the four settings), 248383 statements checked, no row's words outside a Statement. `tests/shipped.test.mjs` reads the 430 strings of the notes without a banned phrase, finds the licence lines on `tools/check_notes.mjs` and no contact detail in the files of this pass. Its two failures are not the notes': `dist/content/notes.json` is older than the notes (the build is to be run again, `sh build.sh`), and 2.9.0-pre.1 is not a release number (rule 8).

## What the owner must decide

1. Names and forms of address. The `to` names follow the Atlas's own reports where they print them (the by-lines of the category, Baez and Furey reports, the Atiyah analysis, the spin step); these first names are recalled and should be checked: Paul Sutcliffe, Nicholas S. Manton (the analysis says Nick Manton), Bernd J. Schroers, Claude LeBrun, Michael Eastwood, Paul Norbury, Gregory W. Moore (the analysis has G. W. Moore and Greg Moore), Anthony Lasenby, Chris Doran, Stephen Gull, Charles Gunn, Rafał Abłamowicz (the sources table writes Ablamowicz), Frederic P. Schuller, Maximilian Düll, Nadine Stritzelberger, Florian Wolz. The null-surface paper is addressed by surnames, as the Atlas cites it; the reference list of the Hestenes and gauge-gravity report gives initials (among them "A. Barker") that should be checked against the paper. N. Furey and D. K. Wise are named as their papers print them; the e-mails say "Dr Furey" and "Dr Wise". Titles and forms of address in the e-mails are the owner's to set.
2. The 12 held e-mails: roelfs-eelbode-de-keninck (Theorem 2 with independent angles, SPN-M21), hsu-barker-hobson-lasenby (the conditions on g_tt = 0, NUL-003; the paper's own Ellis metric, NUL-002), dorst-de-keninck (the free-top example's inertia map, RIG-M52), majkic (no associative extension with a free weight, LNC-062), pumplun (the points P1–P6 of the dictionary report), baez (a bracket of the Kepler paper, LNB-046), schuller (the printed Dirac operator, ATL-012), schuller-closure (the sign of the curvature scalar, LNS-010h), segal (the pages of the Appendix, ATY-003), moore ((2.12) only with the part along J read as a real number, ATY-037 and ATY-039; the remark on the other sign, ATY-007), sutcliffe (the instanton family and the pion mass, ATY-014), schroers (a factor four against the text extraction, ATY-017: the print is to be checked first).
3. People with several notes: Baez (four notes), Pumplün (two), De Keninck (two), Lasenby (two), Schuller (two), and the pairs that read one paper twice (Manton and Schroers; Sutcliffe and Eastwood–Norbury on the configurations of points). One e-mail per person with several links, or the e-mails spaced out.
4. The Hitchin note (I1's): its `rows` lists 16 rows and its sections show 10 (ATY-002, ATY-012, ATY-016, ATY-019, ATY-022 and ATY-025 are listed only), so the card on `#/notes` counts 16 statements where the note shows 10; its owner aligns the two. Its headings differ from the four of the other notes; the file's `line` describes the four.
5. RSN-015 attributes the phrase "photon that stands still" to the null-surface paper, while NUL-001 says the phrase is the Atlas's and the paper's words differ. The null-surface note leaves RSN-015 out for that reason; one of the two rows needs the owner's correction.
6. The rows of the energy of the shifted theory (ATY-038 to ATY-041) reached the tables while this pass ran, and the Moore note cites them: ATY-038 and ATY-039 where the work and the Atlas meet (the Noether energy of the action, equal to the coupling to a uniform potential; (2.12) only with the part along J read as a real number), ATY-040 and ATY-041 among what the labels add (the beat of two modes; the one-dimensional equations as the two halves of one operator at rest). If those rows change before the release, `node tools/check_notes.mjs` names every note they touch; the owner of the energy rows checks the Moore note and its e-mail against them.
7. Candidates for more notes: Huang, Li and Ding, Oliveira, Meluccio, Chua, and Hughes as an addressee of the Furey note.
8. The order of the notes follows the steps of the Atlas (the rule, the Dirac and spin steps, gravity, the projective and gauge steps, the null surfaces, the rigid body, the groups, the category step, the Baez step, matter, the Schuller step), then the Atiyah lens with the Hitchin note at its head.
