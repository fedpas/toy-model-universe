<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Outreach drafts, set 4: one short e-mail for each note to a researcher

The owner's earlier letters were not available to this pass; each e-mail is written to be the first or a follow-up alike.

Not shipped. One e-mail for each note of `content/notes.json`, in the order of that file, under the note's key. Each e-mail has a subject, the picture it points to (a figure id or a tutorial svg that the note shows), a line "Hold:" when it should wait for the owner's judgement (the Atlas's result goes against a printed page, or the point needs the print checked first), and a body of at most 120 words with one link and one question, the note's own. `<site>` stands for the address where the owner publishes the Atlas; `[name]` for the owner's signature. Salutations use the names of the notes (docs/round9/NOTES.md lists the first names that are recalled rather than read); the owner sets titles and forms of address. `node tools/check_notes.mjs` checks this file with the notes (docs/round9/NOTES.md).

Held for the owner's judgement: roelfs-eelbode-de-keninck, hsu-barker-hobson-lasenby, dorst-de-keninck, majkic, pumplun, baez, schuller, schuller-closure, segal, moore, sutcliffe, schroers (12 of 27).

## lundholm-svensson
Subject: Your combinatorial Clifford algebra as the one rule of an atlas
Picture: `zero/sign_cl20.svg`

Dear Douglas Lundholm and Lars Svensson,

My atlas of physics rests on one rule: blades as bit patterns, multiplied by exclusive or with a sign. It is the combinatorial Clifford algebra of your KTH notes, and on it I recomputed your classification, the graded tensor product, the even subalgebra and the mother algebra; all agree. The note shows each statement as a card, with the sign table of Cl(2,0) as its first picture:

<site>/#/notes/lundholm-svensson

The atlas uses a closed formula for the sign, the reorder sign times the squares of the shared generators, where your notes prove associativity by recursion. Is a closed formula of this kind in the notes, or in a source they cite?

With thanks,
[name]

---

## hestenes
Subject: The real Dirac equation on a bit-labelled Cl(1,3)
Picture: `dirac-pic`

Dear David Hestenes,

On a model of Cl(1,3) built from bit labels, your real form of the Dirac equation runs as written: expanded in 1/c it gives the Pauli equation with g = 2, and parity, time reversal and charge conjugation act as exact operator identities on the even spinor. The note collects these results as cards, with the model's picture of the Dirac equation:

<site>/#/notes/hestenes

In the model, J = γ₂γ₁ is an input. Does the physics single out this bivector, the plane of the spin along γ₃, or is the choice of the plane a convention the equation carries with it?

With thanks,
[name]

---

## roelfs-eelbode-de-keninck
Subject: Pointors and the invariant decomposition on bit labels, and Theorem 2
Picture: `spin-pointor`
Hold: the exact check of Theorem 2 with independent angles goes against the statement as read (sources S20, row SPN-M21); the owner judges before sending.

Dear colleagues,

I recomputed your invariant decomposition and your pointors on a Clifford model built from bit labels, by exact arithmetic: every line I could check agrees, two after a small adjustment. One point differs. With independent angles, the sum in Theorem 2 is not a pointor for two factors in my check, while with one common rotor it is. The note sets the results out as cards, with a picture of the pointor test:

<site>/#/notes/roelfs-eelbode-de-keninck

Does the theorem assume a common rotor, or have I misread its hypotheses?

With thanks,
[name]

---

## wise
Subject: MacDowell–Mansouri gravity on a finite Clifford engine, and the sign of Λ
Picture: `cosmological-generator`

Dear Dr Wise,

Building first-order gravity on bit labels as a Cartan connection, I find that εFF splits as d CS + 8c L_R + 24c² vol(e), with Λ = 3c in four dimensions, and that de Sitter or anti-de Sitter is the sign of the square of one extra generator. With space squaring +1, as in your paper, this gives c = −Λ/3; the action itself I take from your paper and two others. The note has the cards:

<site>/#/notes/wise

An action linear in F gives another Λ for the same F. In your reading, is the sign of Λ fixed by the model group, so(1,4) or so(2,3), or by the action chosen on it?

With thanks,
[name]

---

## gunn
Subject: Your top in the three plane-based algebras, run with one engine
Picture: `free-top`

Dear Charles Gunn,

With one engine, and the square of the extra generator set to −1, 0 or +1, the free top of your thesis runs in the Euclidean, elliptic and hyperbolic plane-based algebras, and its flow equals your compact equations and your printed inertia matrix as exact series in time. A spring law that reads the same in the three spaces takes the size of the join, d, sin d or sinh d, as an input. The note has the cards and the top:

<site>/#/notes/gunn

In the elliptic and hyperbolic cases, is the size of the join the spring law you would choose, or does the thesis point to another?

With thanks,
[name]

---

## lasenby-doran-gull
Subject: The Newtonian-gauge point mass as one shear, checked on a finite model
Picture: `rain`

Dear Anthony Lasenby, Chris Doran and Stephen Gull,

Your point mass in the Newtonian gauge, one shear of the frame with a nilpotent part, runs on a Clifford model of bit labels: the metric is vacuum, free fall gives Newton's law with your conserved energy, and the periastron moves on by 6πM/p per orbit. I derive the Schwarzschild family only inside the radial Kerr–Schild class. The note shows the cards and a falling raindrop:

<site>/#/notes/lasenby-doran-gull

In your field equations, does the Newtonian gauge condition alone single out the one shear of the point mass, so that a check could start from the gauge rather than from that class?

With thanks,
[name]

---

## hsu-barker-hobson-lasenby
Subject: The four claims of your paper on null surfaces, computed on a finite model
Picture: `null-figures`
Hold: the criterion g_tt = 0 holds on the Atlas only under conditions the paper does not state (NUL-003), and the paper's own Ellis metric differs from the wormhole of the check (NUL-002).

Dear colleagues,

I computed the four claims of your paper on null surfaces with a Clifford model and its gravity engine. Each holds where its conditions hold; the criterion g_tt = 0 needs a regular level set and a finite norm of the derivative, conditions I add and list in the note, with the ways it fails without them:

<site>/#/notes/hsu-barker-hobson-lasenby

Its figures show the null cone and the tangent algebra. I tell a horizon from a throat by the norm of the normal covector, n·n = −T. Is this test already in Vollick's paper, which I know only by its abstract?

With thanks,
[name]

---

## dorst-de-keninck
Subject: The forque paper checked line by line, and one inertia map in the code
Picture: `tennis-racket`
Hold: the inertia map of the repository's free-top example differs from the box of the paper (RIG-M52).

Dear Leo Dorst and Steven De Keninck,

I checked the equations of your forque paper on a Clifford model of bit labels: of 41 rows, 27 agree exactly and 9 after a small adjustment, and ganja.js fed with dyadic inputs gives the same motor derivative as my exact engine. The tennis-racket flip comes out with its rate in closed form. The note has the cards:

<site>/#/notes/dorst-de-keninck

One point: in the repository's free-top example the printed inertia map swaps the moments of the first and third axes of the box. Is that intended, or should the moments follow the sizes as the box of the paper does?

With thanks,
[name]

---

## ablamowicz
Subject: Finite groups of Clifford algebras on a bit-labelled model
Picture: `o-q-f2`

Dear Rafał Abłamowicz,

On a Clifford model built from bit labels I compute, for every cell, the order of the orthogonal group of the quadratic form over two elements, and the binary polyhedral groups in the even part of Cl(3,0), with the affine E₈ diagram from the icosahedral one. Conjugation by a blade turns out to be a Walsh character. The note compares these with your paper in general terms, not line by line:

<site>/#/notes/ablamowicz

I read the bit rule as a twisted group algebra of the group of labels, tied to Walsh functions and the Gray code. Is that link made in your paper, or in the work of Chernov that it cites?

With thanks,
[name]

---

## tian
Subject: Your Clifford relations as paired nulls on a finite model
Picture: `cat/fig16_cube_signs.svg`

Dear Yin Tian,

The relations of your categorification are realised faithfully on the exterior algebra of a few sites, and the form behind them has signature (⌊k/2⌋, ⌊k/2⌋, k mod 2): even truncations are full matrix algebras, odd ones carry one null direction. Your nilpotent generators are paired nulls, and your sorting sign is the sign of the bit rule I build on. The note shows the cards and the signed cube:

<site>/#/notes/tian

Is there an object of your DG category, or a class in its K₀, that gives the radical vector of a truncation to an odd number of generators?

With thanks,
[name]

---

## majkic
Subject: Your partial sum and additive norm on the cube category
Picture: `cube-category`
Hold: with a free additive weight no associative algebra extends the printed product (LNC-062); the owner judges how to put it.

Dear Zoran Majkić,

The partial sum, the norm law and the monoid axioms of your categorial geometry hold exactly on bit labels with the disjoint sum and the bit count; the arrows form the cube category, and the comma-propagation levels are categories of commuting cubes. With a free additive weight, however, I find no associative algebra extending the printed product; with the planar length the products stay inside Cl(2,0). The note has the cards:

<site>/#/notes/majkic

Which weight do you intend for the arrows of the Cat-algebra?

With thanks,
[name]

---

## pumplun
Subject: A dictionary between a sign cochain and your skew polynomial algebras
Picture: `top/sign_cochain.svg`
Hold: the dictionary report lists points where its numbers differ from printed statements (its points P1–P6); the owner judges which to raise.

Dear Susanne Pumplün,

I wrote a dictionary between the sign cochain of my Clifford model, a twisted group algebra of the labels, and the skew polynomial constructions of your paper, and re-ran your main statements by brute force over small finite fields. Most agree; the report lists where my numbers differ from the printed statements, each possibly a misreading on my side. The note links it:

<site>/#/notes/pumplun

One example: read with the condition of its proof, that the product of the factors divides the bound on the right, Theorem 4.1 agrees with every case over 𝔽₈. Is that condition part of the intended statement?

With thanks,
[name]

---

## baez
Subject: Five of your papers read on bit labels, and one bracket in the Kepler paper
Picture: `kepler-trio`
Hold: LNB-046 asks whether a printed bracket of the Kepler paper is a misprint.

Dear John Baez,

I read five of your papers on a Clifford model of bit labels: the tenfold way through the clock p − q mod 8, the ladder of E₈ with its counts 56, 27, 16, 10 and 6, and the Kepler symmetries as so(4), e(3) and so(3,1) as one generator squares to +1, 0 or −1. The note has the cards and the three algebras:

<site>/#/notes/baez

In the Kepler paper, is the third line of the brackets in equation (12), {M_j, M_k} = ε_jkℓ M_ℓ, meant as printed, or should it read ε_jkℓ L_ℓ, as the half-sums of equation (13) need?

With thanks,
[name]

---

## baez-schwahn
Subject: The Standard Model algebra in the Albert algebra, recomputed on octonion labels
Picture: `alg/f18_albert.svg`

Dear John Baez and Paul Schwahn,

On octonions built from three-bit labels, the Albert algebra splits as 27 = 1 + 16 + 10 under one idempotent, and the stabilisers of your paper come out at the level of Lie algebras, ending in su(2) + su(3) + u(1). Compared on the roots, your copy lies in a Spin(9) inside Spin(10), while the copy of the E₇ paper lies in none; the su(3)s are conjugate, the su(2)s are not. The note has the cards:

<site>/#/notes/baez-schwahn

Do you regard the two as different embeddings, or as one seen through an automorphism the roots do not show?

With thanks,
[name]

---

## baez-bokor-boyle
Subject: One generation on five bits: the Peirce rule as a Hamming distance
Picture: `five-bits`

Dear John Baez, Endre Bokor and Latham Boyle,

With two weak and three colour bits on five-bit labels, the Peirce eigenvalue of a label is 1 − d/4, with d the Hamming distance, and the 16 even labels fall into exactly the six pieces of your paper; hypercharge is a/2 − b/3 in the bit counts, and the anomaly sums vanish. Taking the Hamming distance as the reason is my reading, not yours. The note has the cards:

<site>/#/notes/baez-bokor-boyle

Is the eigenvalue 1 − d/4, written through the Hamming distance, already in the literature on Jordan pairs that your paper draws on?

With thanks,
[name]

---

## baez-pumplun
Subject: Octonions, split octonions and Zorn's product on eight labels
Picture: `alg/f07_octonions.svg`

Dear John Baez and Susanne Pumplün,

On eight three-bit labels, three Cayley–Dickson doublings give the octonions, the only real division algebra among the sign cochains there, and the derivations that fix one unit give su(3) acting complex-linearly on its complement: your ℂ ⊕ ℂ³. Zorn's product on the exterior algebra of a three-space composes, and ordinary, split and null octonions form one family on the doubling bit. The note has the cards:

<site>/#/notes/baez-pumplun

The complement of a label, with a sign set by its grade, is an automorphism of Zorn's algebra. Does it correspond to a map in your construction of the split octonions from a volume form?

With thanks,
[name]

---

## furey
Subject: The 20 labels of your board, checked against the Peirce edges
Picture: `furey-board`

Dear Dr Furey,

Rebuilding the blocks of your paper on the nested embeddings from the octonion units, I find each of the 20 labels and charges of your first figure equal to the irrep carried by the Peirce edge of its cell. Counting one direction of each edge, the board carries one full Standard Model set of 16 complex dimensions and 8 more beyond it. The note has the cards and the board:

<site>/#/notes/furey

Are those eight complex dimensions beyond one generation meant as states of the model, or as room the construction leaves unused?

With thanks,
[name]

---

## schuller
Subject: Your lectures on a bit-labelled Clifford model, and one printed Dirac operator
Picture: `schuller-chain`
Hold: ATL-012 reads the Dirac operator printed in the quantum notes as belonging to the opposite convention.

Dear Frederic Schuller,

On bit labels, the exterior algebra of your chapter on forms is the rule with every square zero; with squares ±1 the same labels give Cl(p,q). On that model the spin Casimir 3/4, the fermionic Fock space, Stern–Gerlach and the bands of the quantum notes come out exactly. The note has the cards:

<site>/#/notes/schuller

One point: the quantum notes print the Dirac operator as iγ·∂ − m with η = diag(−1,1,1,1), a form that belongs to the convention where time squares to +1. Is that form the choice of the lecture, or of the note-takers?

With thanks,
[name]

---

## schuller-closure
Subject: The closure of Klein–Gordon evaluated on a finite model, and one sign
Picture: `phys/wave_types.svg`
Hold: LNS-010h finds the two printed actions equal only under a sign of the curvature scalar that the paper does not state.

Dear colleagues,

On a Clifford model of bit labels, the hyperbolicity filter of your closure paper holds exactly: a quadratic principal polynomial is hyperbolic if and only if the cell is Lorentzian. The printed Klein–Gordon solution satisfies the six closure equations that are not identically zero, and your remark that the Lagrangian is the 3+1 decomposition of the four-dimensional action holds when the curvature scalar is minus the usual Ricci scalar of the mainly-minus metric. The note has the cards:

<site>/#/notes/schuller-closure

Is that the sign you intend?

With thanks,
[name]

---

## hitchin
Subject: Atiyah's late papers rebuilt on a finite Clifford model, with your account as guide
Picture: `top/abs_clock.svg`

Dear Nigel Hitchin,

With your account of Atiyah as a guide, I rebuilt parts of his late papers on a finite Clifford model built from bit labels. The graded Clifford modules give the groups ℤ, ℤ₂, ℤ₂, 0, ℤ, 0, 0, 0 by the clock alone, and the edge-cone defects of Atiyah and LeBrun are exact on the gravity engine. The note sets this out, with the clock as its first picture:

<site>/#/notes/hitchin

Is the finite shadow of the index that the model computes, a Koszul complex on the labels, an index at all, or only a count?

With thanks,
[name]

---

## segal
Subject: The Appendix of Twisted K-theory and cohomology, recomputed on a finite model
Picture: `top/ss_pages.svg`
Hold: ATY-003 gives pages 18, 10, 8 where the Appendix prints 18, 14, 10.

Dear Graeme Segal,

I recomputed the example in the Appendix of your paper with Atiyah on its model, Λ(x, y, z) ⊗ ℝ[t]/t³ with H = xt. The pages of the degree filtration come out as 18, 10 and 8, with twisted cohomology (4, 4), where the Appendix prints 18, 14 and 10; the printed 14 is the dimension of the cycles of the third differential. The twisted operator d − H squares to zero exactly when H is closed. The note has the cards and the pages:

<site>/#/notes/segal

Is the printed sequence computed on another model, or on another filtration?

With thanks,
[name]

---

## moore
Subject: The shifted Dirac equation on a finite model, and the T₀₀ of (2.12)
Picture: `phys/shift_lattice.svg`
Hold: ATY-037 and ATY-039 give (2.12) only when the part of the energy along J is read as a real number, and ATY-007 finds the remark on the other sign not visible on free plane waves.

Dear Gregory Moore,

Your shifted Dirac equation with Atiyah runs on the plane waves of a finite Clifford model: solutions exist exactly at your quantization condition, with your shifted rest energy. I also computed the Noether energy of your action (2.10): with a bilocal term over the delay it is conserved, and the coupling of a quantized mode to a uniform potential equals it exactly. The deviation in (2.12) appears only when the part of that energy along the quarter turn J is read as a real number. The note has the cards:

<site>/#/notes/moore

Is T₀₀ meant per unit density with that part read as real, or as the energy of the action?

With thanks,
[name]

---

## sutcliffe
Subject: Instanton holonomies and the pion mass: β stays at most 1
Picture: `geo/toroidal_skyrme.svg`
Hold: ATY-014 finds the instanton family improving with the pion mass only up to a mass between 1 and 2.

Dear Paul Sutcliffe,

Building the Skyrme field of the instanton as a holonomy along lines and circles on quaternion labels, I get your profiles (3.4) and (3.9), and a bound: every instanton holonomy has β at most 1. Within that family the approximation at m = 2 and 3 is worse than without mass; with β free it improves, at β = 1.32 and 1.64. The note has the cards and the profiles:

<site>/#/notes/sutcliffe

Was β left free in your first figure, or is there an instanton family I have not read?

With thanks,
[name]

---

## manton
Subject: Skyrmions from instantons and geometric models of matter on bit labels
Picture: `phys/bpst_skyrme.svg`

Dear Nicholas Manton,

On quaternion labels the holonomy of the instanton along lines is the hedgehog, with degree equal to the instanton number; recomputed by a standard route, the minimum of the line family lies 0.95 % above the massless Skyrmion. For the geometric models of matter, the signatures and Gauss sums of the manifolds come out on the lattices of the cells, and S⁴ and CP² give 2, 0 and 3, 1 on the gravity engine. The note has the cards:

<site>/#/notes/manton

Does the 0.95 % agree with the minimum in your paper with Atiyah, which I know only through the accounts of others?

With thanks,
[name]

---

## schroers
Subject: Geometric models of matter on lattices, and the Taub–NUT curvature norm
Picture: `top/taubnut_weyl.svg`
Hold: ATY-017 finds a factor four against the text extraction of the paper; the print is to be checked first.

Dear Bernd Schroers,

The four-manifolds of your paper with Atiyah and Manton sit on the frame lattices of a finite Clifford model: signatures, determinants and Gauss sums come out exactly, and the baryon number read mod 8 is the clock. On the gravity engine Taub–NUT is Ricci-flat with self-dual curvature, but its curvature norm, 24m²/(r + m)⁶, is four times the density of your formulas as my text extraction reads them. The note has the cards:

<site>/#/notes/schroers

Does the printed paper normalise the norm differently, or is the factor in my extraction?

With thanks,
[name]

---

## lebrun
Subject: Edge-cone defects and your self-dual Einstein cones, exact on a finite engine
Picture: `phys/cone_defects.svg`

Dear Claude LeBrun,

Theorems 2.1 and 2.2 of your paper with Atiyah hold exactly on the curvature forms of a finite gravity engine, on S⁴, on S² times a football and on CP², and the self-dual Einstein cones (5.4)–(5.6) come out in closed form for every β, with your Einstein constant and (5.7). On the obstruction table, a cubic in CP² blown up at k points needs k/9 ≤ β² ≤ (12 + 5k)/9. The note has the cards:

<site>/#/notes/lebrun

Is that window, bounded below as well as above, how you read Corollary 4.2?

With thanks,
[name]

---

## eastwood-norbury
Subject: Atiyah's configurations of points on a spinor of bit labels
Picture: `geo/null_sphere.svg`

Dear Michael Eastwood and Paul Norbury,

Following your proof, I ran Atiyah's construction on a finite Clifford model: the lift of a direction to a spinor is a product in the minimal left ideal of Cl(3,0), and the determinant is exact wherever the distances are rational. The formula for three points holds on Heronian triangles, and at four points Re D ≥ 15/16 at every configuration tried. The note has the cards:

<site>/#/notes/eastwood-norbury

I lift the reverse direction to σ(w) = (−w̄₂, w̄₁); without it the determinant vanishes for two points. Is this the convention your proof uses?

With thanks,
[name]

---
