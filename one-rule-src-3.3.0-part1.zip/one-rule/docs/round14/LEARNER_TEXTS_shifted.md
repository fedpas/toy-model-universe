<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 14, T3s: the storyteller's words for `shifted` (Calibration 3)

The learner texts of `#/shifted`, written under `docs/round14/STORY_ROUND.md` §7 (the storyteller), §2.2 (the span record), §3.2 (C1–C11) and §6.1 (the page), from the chain records of `content/chains/shifted/chains.json`, the research texts of the rows and of `content/chains/shifted/texts.json`, the learnerFrame of `content/chains/shifted/page.json` and the reasoning of `docs/round9/SHIFTED_VIEW_NARRATIVE.md`. One file: `content/chains/learner/shifted.json`, 95 records, every one `status: "draft"`, `source: "storyteller@2026-10-17"`, waiting for the owner's review.

## 1. What was written

| what | records | rows |
|---|---:|---|
| spans of the 17 chains (register `span`) | 60 | 38 told positions and 22 mentions, one span per position in chain order |
| learner texts of the chain leads (register `full`) | 8 | ATY-751 … ATY-758 (each at most 300 characters, no number) |
| learner texts of the page rows and section leads (`full`) | 15 | ATY-701 (page lead), ATY-702 (detail), ATY-703 (next), ATY-711 … ATY-722 |
| learner full texts of told rows that had none anywhere (`full`) | 12 | MAP-018, INP-049, ATY-056 … ATY-065 (their status words kept: input, open, our reading) |

All 17 chains are storied: none was rejected by the checker, none rejected twice, none left unstoried. The page has no side notes (every row placed on `shifted` is told in a chain), so no side-note text was needed. No told row of the page has a human learner text (ATY-005's short hero text is a translator draft), so C10 did not apply and no span is a human text. ATY-701 and ATY-703 are written from their research texts and the learnerFrame (its sentences kept, with the name the row does not carry left out, R12).

The stories, chain by chain (lead and spans against C7's budget of 0.8 × the research texts of the positions):

| chain | positions (mentions in parentheses) | lead | story / budget |
|---|---|---|---:|
| `sv-1.labels` | EQN-008, MAP-018 | — | 229 / 232 |
| `sv-2.toy` | (ATY-041), (ATY-038) | — | 260 / 5280 |
| `sv-3.shift` | ATY-004, (ATY-005), ATY-006, ATY-011, ATY-041 | — | 4491 / 6358 |
| `sv-4.lattice` | ATY-005, ATY-009 | — | 1793 / 1817 |
| `sv-5.clock` | ATY-037, ATY-038, ATY-039 | ATY-751 | 5438 / 6453 |
| `sv-5.tensor` | ATY-042, ATY-043, ATY-044 | ATY-752 | 4195 / 5258 |
| `sv-6a.family` | ATY-007, (ATY-039), ATY-010 | — | 2528 / 3899 |
| `sv-6b.mixed` | (ATY-041), ATY-045, ATY-040 | — | 3517 / 6506 |
| `sv-6c.massless` | (ATY-005), (ATY-007) | ATY-753 | 440 / 2286 |
| `sv-6c.potential` | ATY-008, ATY-046 | ATY-754 | 2924 / 2980 |
| `sv-7.ricci` | ATY-051, (ATY-010), ATY-052, ATY-053 | — | 4729 / 6667 |
| `sv-8.radius` | ATY-054, LNS-017e, ATY-055 | — | 3605 / 3612 |
| `sv-9.mu` | (ATY-005), (ATY-037), (ATY-039), (ATY-040), ATY-065 | — | 933 / 7265 |
| `sv-open.q1` | INP-049, (ATY-052), (ATY-053), ATY-056, ATY-057 | ATY-755 | 2497 / 6330 |
| `sv-open.q2` | (ATY-007), ATY-058, (ATY-039), ATY-059, (ATY-040), ATY-060 | ATY-756 | 1879 / 5286 |
| `sv-open.q3` | (ATY-009), (ATY-037), ATY-061, (ATY-041), ATY-062, (ATY-046), ATY-047, ATY-063 | ATY-757 | 3060 / 9788 |
| `sv-open.numbers` | (ATY-055), ATY-064 | ATY-758 | 707 / 1849 |

**The words.** One set of plain names runs through the page, so that a reader meets each once and keeps it: *the strength* (κ), *the delay* or *the shift* (τ), *the strength times the delay* (μ, the paper's one number), *the quarter turn* (J, the element of the labels that squares to minus one, in the place of the imaginary unit), *the rung* (n; "every number of quarter turns" where a row says for every n), *switches* (generators), *the electron's equation* (the Dirac equation), *the minus variant*, *the difference variant* (delay and advance with opposite signs, D_s) and *the sum variant* (D_c), *the Hermitian half* and *the anti-Hermitian half*, *arrow fields* (1-forms), *a table of energy and momentum* (the tensor), *the part spread over the delay* (the bilocal term), *the particle count* (the Noether number), *redshifted like any clock*. The paper's moves are told as moves ("the paper takes", "asks", "reads"), the labels' results as results, the status words as the rows give them; nothing says that nature has the shift.

## 2. The rules that bit, and how they were met

No piece failed the checker once written; these rules shaped the words before the checker saw them, and the coverage test bit once after the first merge.

- **C7, the budget.** Four chains run close to it: `sv-1.labels` (229 of 232: EQN-008's research text is 46 characters, so the two spans tell the 8 numbers and 40 links, then MAP-018's current, its parts and its counts in one sentence; the complete MAP-018 is in its full text), `sv-4.lattice` (1793 of 1817), `sv-6c.potential` (2924 of 2980), `sv-8.radius` (3605 of 3612). Where the budget would not hold a minor clause, the full statement stays in the row's research text and drawer.
- **R6, every number.** A precision printed with a superscript exponent counts as its digits (3·10⁻¹⁵ asks for 3 and 10), and "3e-15" in a learner text would be a number the row lacks (R7): such precisions are written "3 times 10 to the minus 15" (A64: they stay in the spans). Numbers inside equation labels count unless parenthesised alone, so the paper's 2.2.3, 2.2.4, 2.3d, 3.3a to 3.3c, 3.5a to 3.5c and 3.6 are written without parentheses. The densest spans keep 21 and 22 numbers (ATY-045, ATY-041).
- **R4, no symbol.** No Greek letter or single letter: μ, κ, τ, J, n, E, m become the names of §1; "e" in "e-folding" is told as "growth times".
- **R8 and C5, the status words.** "For every n" needs "every number" (not "every rung"). A proved row's span carries no *input*, *a choice*, *open* or *ours* unless its research text does: ATY-010, ATY-052 and ATY-053 keep "our reading", "inputs" and "open" because theirs do; ATY-046 keeps "not settled". Each weak link says its word: INP-049 *input* ("a choice of sign convention: an input"), ATY-011, ATY-047, ATY-058, ATY-061, ATY-062, ATY-065 *our reading*, ATY-056, ATY-057, ATY-059, ATY-060, ATY-063, ATY-064 *open*.
- **R12, names.** A name inside a sentence must be in the row's research text: "Dirac" is not in ATY-010's or ATY-052's, so they say "the unshifted operator"; "Compton" is not in ATY-005's ("quarter wavelengths of the particle"); "Furey" is not in ATY-701's, so the learnerFrame's first sentence reads "Warm-up 2 counted families of particles on the labels".
- **R5, history words.** "correction" is banned (P2): ATY-052's "first-order correction 2μ" reads "a first-order change of twice that number", ATY-051's connection "no extra term for the curving frame"; "no longer" is avoided in ATY-717.
- **C4, the openers.** `derives`: So, Then, Hence, From the; `instance` (ATY-041 in `sv-3`): For instance; `cycle` back (ATY-010 in `sv-7`): Behind this; `equiv` back (LNS-017e): This rests on; `uses-input` (ATY-052 in `q1`): Given that input; `order` links open freely and never with a derivation or contrast word: "Beside it" (MAP-018), "The paper writes" (ATY-038), "Their products" (ATY-010), "Two quantized waves" (ATY-040), "Alongside" (ATY-040 in `q2`), "At rest" (ATY-041 in `q3`).
- **C6, the leads.** No digit and no claim word of T2 (exactly, holds, never, cannot …), so T1–T5 find nothing to test and each lead passes; each is at most 284 characters.
- **The words rule of `tests/coverage.test.mjs`.** The first full run failed 16 renders of `#/notes/moore`: the ATY-038 span of `sv-5.clock` shared 75 characters with a note of `content/notes.json` that the page prints outside a statement ("… time alone the shift delays one half of the field and advances the other, …"). That sentence was rephrased in ATY-038 and in both spans of ATY-041 (`sv-3.shift`, `sv-open.q3`), and every record was then scanned against the strings that pages print outside statements; seven more runs of 40 to 62 shared characters were rephrased before they could bite (the atiyah lens dictionary of `content/lenses.json`: ATY-046, ATY-047, INP-049 span and full text, ATY-056 full text; `content/stored_shifted.json`: ATY-055, ATY-064 span and full text). Only the learnerFrame of `content/pages.json` still shares words with ATY-701 and ATY-703; no component prints it. The second run passed.
- **The fold of a long statement.** A body statement longer than 700 characters renders folded behind "Show all" (`src/components/Statement.jsx`, `LONG.body`): seven leads (ATY-702, ATY-711, ATY-713, ATY-714, ATY-716, ATY-719, ATY-720) were cut to 673–699 characters, so every lead of the page reads whole at learner level.

## 3. The commands run, and their last lines

| command | last line |
|---|---|
| `node tools/check_learner_texts.mjs --file content/chains/learner/shifted.json --fix` (after each of the 11 pieces and each edit) | `PASS: all 24 rules hold for every record` (95 records) |
| `node tools/check_learner_texts.mjs` (all learner files together, R3 across files) | `PASS: all 24 rules hold for every record` (1449 records; spans of shifted 60) |
| `node tools/merge_chains.mjs --check` | `merge_chains --check: 41 chains on 6 page(s), 41 storied (0 reviewed), 196 spans; round-14 rows: 40 story rows, 13 statement rows` |
| `npm run content` | `errors 0, warnings 0; see docs/COVERAGE.md` (merge_story: `chains 41 (41 storied, 196 spans; …)`); the 95 records are in `content/texts.json` verbatim |
| `node tests/coverage.test.mjs` | `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` |
| `node tests/story/shifted.test.mjs` | `PASS shifted: Calibration 3 after Calibration 2 (12 sections in 4 parts, 17 chains, 38 told positions and 22 mentions, 23 story rows through T4/T5, 10 new rows), …; 18 of 18 broken copies caught` |
| `sh build.sh` | `export_tuning: 1,892 records, 3,779 texts, 367 checks and 624 runs, 35 lenses, 7.32 MB in dist/content/tuning/` |
| Playwright on `dist/`, `#/shifted?l=learner` at 1366 px light and dark, 390 px light | 17 story paragraphs, 68 statements (60 spans, 8 chain leads), no `ol.chain__list`, every lead whole, 0 console errors, 0 horizontal overflow |
| `node tests/ui/chains.smoke.test.mjs` | `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: …` (308 checks) |

## 4. Notes for the other owners

- `tests/chains.test.mjs` stops in part D (`ENOENT … /tmp/one-rule-chains-*/docs/COVERAGE.md`): the test copies `content/` without `content/chains/pilot/` but with `content/chains/learner/`, so the pilot spans fail C1 in the copy's first step and the pipeline never writes `docs/COVERAGE.md`. No failure in that copy involves a `shifted` span (checked on a copy). For B1.
- `tests/story/shifted.test.mjs` prints "38 told rows … wait for their learner texts": its learner-level parse reads `ol.chain__list` items only, and a storied chain renders as `p.chain__story`; all 38 are drawn as spans ("0 story rows wait"). For B3.
- At learner level the spans carry the badge "new" (`NEW_SINCE` still covers v16 … v2.15); A60's single-version rule is R7's change and will leave only the badges of what is not proved.
