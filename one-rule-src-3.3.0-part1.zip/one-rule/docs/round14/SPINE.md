<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The story spine of the pilot pages (round 14)

The order in which the Atlas tells each pilot page, chain by chain: the map the storyteller writes from (`docs/round14/STORY_ROUND.md` §7) and the page builders compose over (§6, §9). Every chain below is made of rows of the tables; every relation is a `depends` edge of the rows, or `order` where the rows are only adjacent. Nothing here is a claim of physics or mathematics.

**How it was made.** The extraction of STORY_ROUND.md §3.1 (rules E1–E9) ran as a prototype with node, read-only, on `content/rows.json` of 17 Oct, 15:50 (1,839 rows, 364 of them story rows; the rows FUR-027 … FUR-037 and GEN-027 … GEN-032 of 2.14.0 present), with `pages.json`, `check_runs.json` and `derived/status.json` of the same build (R6's build of the 2.14.0 tables: those seventeen rows proved by the Atlas); the counts are the same as on the snapshot of 15:12. The prototype is `extract_chains_split.mjs` in A2's scratch directory; B1 rebuilds it as `tools/story/extract_chains.mjs`. For the two calibrations the chains are composed by the paper's reasoning and by the owner's five groups, and each link is recomputed from `depends`; for the other pilot sections the mechanical draft is given, with a proposed composition where the draft cuts across the story. The ids of the proposed rows (ATY-056 …, FUR-038 …, the story rows ATY-7xx and FUR-7xx) are the next free ones on 17 Oct; B1 re-runs the extraction with `--diff` once 2.14.0 ships.

**How to read a chain.** `A —derives→ B`: B rests on A (a `depends` edge, B on A). `—derives·X→ B`: B rests on X, an earlier position than the previous one (a branch or a join). `—uses-input→`, `—instance→`, `—equiv→`, `—cycle→`: the relation of the edge. `—order→`: adjacent only, no edge (the storyteller may not open with "so" there, C4). `(A)`: a mention, told in another chain of the page. `A/Ab`: a position with its twin (the mathematics twin, visible in mathematics mode only). After each chain: its shape (line, fork, cycle, ladder), its weakest link (the weakest computed status of its rows: open > not yet proved here > our reading > needs an input > proved by the Atlas), its counts, and a working title, physics · learner.

| | sections | chains | told | mentions | story rows | new rows |
|---|---:|---:|---:|---:|---:|---:|
| `shifted` (§2) | 12 | 17 | 38 | 22 | 23 | 10 |
| `matter` (§3) | 6 + the inputs fold | 7 | 47 | 2 | 9 (+ 8 on `matter/papers`) | 3 |
| pilot sections (§4) | 4 | 17 (12 mechanical) | 85 (+ 3 side notes) | 2 | — | — |

---

## 1. What the extraction found, in one paragraph

Inside a section the `depends` graph is thin: of the 1,098 placements of the story pages (the Logbook, Ask and the glossary apart, the inputs sections and the 149 matrix lines apart), 558 are singletons (51 %) on `depends` alone, and 24 sections of three rows or more hold no chain at all. A third of that is bookkeeping: 248 rows are lines split from a longer row (`splitFrom`) and carry no edge to it; with the rule E2b (a split line `continues` its first line) the extraction gives 189 chains holding 739 placements (36 more attached), 312 side notes, 348 singletons (32 %) and 14 sections without a chain. The rest is mostly the cut of the sections, not the lack of links: of the `depends` edges between rows placed on the story pages, 656 stay inside a section, 874 join two sections of the same page and 381 two pages (and 1,191 lead to rows no story page places: theorems, inputs, the Logbook's rows). Seven directed cycles remain in `derives`, `instance` and `uses-input`. The two calibrations are the exception: their rows were written as chains (each ATY row of the shifted view rests on the ones before it, each FUR row of 2.12.0 to 2.14.0 on its predecessors), and the composition below follows them closely. The findings, row by row, are in §5; the counts, page by page, in §6.

---

## 2. `shifted` — Calibration 3: the shifted view (Atiyah and Moore)

Twelve sections: the nine steps of `docs/round9/SHIFTED_VIEW_NARRATIVE.md` (6a, 6b and 6c apart) and a last section of the readings and open items. Each step's lead is the paper's move, a story row written by B3 from "The move" of `public/reports/analyses/src/shifted_view.md`; its told rows are the rows "On the labels" of that step in the analysis page; a row told at one step and needed at another is a mention there. The parts: Prologue (sv-1), The shifted Dirac equation (sv-2 … sv-6c), Gravity shifted (sv-7, sv-8), Two constants and three questions (sv-9, sv-open).

### 2.1 The nine steps

**sv-1 · Step 1. Where new ideas come from** (section 1, pp. 1–2). *The move:* a prologue in the author's voice earns the licence to speculate and plants the target, a very small cosmological constant; in its place the Atlas states its objective and its reach. *On the labels:* nothing to compute; the reason to read the paper: the labels carry the Dirac operator exactly, with J in the place of the paper's i. Lead ATY-711.
- `shifted.sv-1.labels` · line · weakest proved by the Atlas · 2 told — "What the labels carry" · "What the switches can carry": EQN-008 —order→ MAP-018 (the two share MAP-017 and rest on nothing of each other).

**sv-2 · Step 2. One simple equation** (section 2, p. 3). *The move:* one linear equation with one delay, (2.1); its data a whole function on an interval; its exponential solutions with roots off the imaginary axis, blowing up in the far past or future; the question that drives the paper: can a delay make sense in relativity? *On the labels:* (2.1) oscillates without growth exactly when the delay is an odd number of quarter periods, its roots by Lambert's function (ATY-041, `en.OSC`); its Noether energy has a term spread over the delay interval (ATY-038, `en.DELAY`). Both are clauses of rows told later (A61). Lead ATY-712.
- `shifted.sv-2.toy` · line · proved · 0 told, 2 mentions — "A delay that neither grows nor decays" · "A delay that keeps ringing": (ATY-041) —derives→ (ATY-038).

**sv-3 · Step 3. Relativity forces the Dirac operator** (section 2, pp. 3–4). *The move:* the delay written as the exponential of the time derivative; Lorentz invariance makes that derivative Dirac's operator; on spinors one shift retards one sign of frequency and advances the other; hence "shifted", and four variants. *On the labels:* a translation acts on a plane wave as a right factor; the retarded shift of the whole mass term alone puts the waves on quarter turns; a fixed shift vector is bound to a frame (ATY-004); on the ordinary solutions the operator's shift is the right factor, a retard and an advance, and no wave is delayed at the speed of light (ATY-005); the covariant shift keeps its waves in every frame tried (ATY-006); a second reason for the pairing, a reading (ATY-011); at rest one half retarded, the other advanced, and (2.1) is the first half (ATY-041). Lead ATY-713.
- `shifted.sv-3.shift` · fork · weakest **our reading** (ATY-011) · 4 told, 1 mention — "One shift: a retard and an advance" · "One delay that waits forward and backward": ATY-004 —derives→ (ATY-005) —derives→ ATY-006 —derives·ATY-005→ ATY-011 —instance→ ATY-041.

**sv-4 · Step 4. What the plane waves say** (section 2, pp. 4–5, and p. 8). *The move:* on a plane wave the shift is a phase; the imaginary part forces the cosine to vanish: the delay is an odd number of quarter Compton wavelengths; one universal delay, set by the lightest neutrino; the rest energy m ± k; the odd-integer ratios. *On the labels:* the quantization exactly, the paper's (2.6), (2.7) and (2.9), none at rational points, a second branch for κ > m (ATY-005); at the quantized shift the wave is turned by a quarter and its frame by a half, the current and the spin kept (ATY-009). Lead ATY-714; figure `shifted-shells`; the hero's figure `shifted-quarter-turn` draws this chain too.
- `shifted.sv-4.lattice` · line · proved · 2 told — "The quarter-turn lattice" · "Only quarter turns allow a wave": ATY-005 —derives→ ATY-009.

**sv-5 · Step 5. A deviation to measure** (section 2, pp. 5–6). *The move:* the action in a weak static field; the coefficient of the potential read as the gravitational rest energy; the equivalence-principle bound on μ; μ made the constant of the theory. *On the labels:* proper time on the frame of a constant potential, the coefficient of Φ with its quarter-turn part, (2.12) not reproduced from the printed operator (ATY-037); the Noether energy at rest (ATY-038); the coupling equal to that energy, the J part from the anti-Hermitian half (ATY-039); the tensor with its bilocal term, packets, Lorentz currents and Belinfante (ATY-042 … ATY-044). Lead ATY-715; two chains, leads ATY-751 and ATY-752.
- `shifted.sv-5.clock` · line · proved · 3 told — "A clock, an energy and a coupling" · "A clock, an energy, and the pull of gravity": ATY-037 —order→ ATY-038 —derives→ ATY-039 (ATY-039 rests on ATY-037 too: a join the consecutive links do not show).
- `shifted.sv-5.tensor` · fork · proved · 3 told — "Four currents with a bilocal term" · "How energy and momentum flow": ATY-042 —derives→ ATY-043 —derives·ATY-042→ ATY-044.

**sv-6a · Step 6a. The formal family** (section 2.1, pp. 6–7). *The move:* the family enlarged to see what is robust: D₋, D_s, D_c; the Klein–Gordon candidate D₊D₋; d + δ, which does not keep the degree; an affine operator group. *On the labels:* the variants read uniformly, D_c with and without its i (ATY-007); the products as formal series with constant terms −κ², κ², 0 (ATY-010); the paper's operator as a Hermitian and an anti-Hermitian half (ATY-039). Lead ATY-716.
- `shifted.sv-6a.family` · line · proved · 2 told, 1 mention — "Four variants, two halves" · "Four cousins, two halves": ATY-007 —derives→ (ATY-039) —order→ ATY-010.

**sv-6b · Step 6b. The mixed equation and quantum theory** (section 2.2, pp. 7–8). *The move:* the mixed equation (2.17) and its roots (2.18); the limit of large μ; Feynman's conserved energy; the mixing of the two signs of frequency, the door to Fock space. *On the labels:* (2.17) is the cosh part of the operator at rest, the lattice its kernel, the roots approach it as μ grows (ATY-041); the roots of the spinor equation by Lambert's W, each growing on one half (ATY-045); two quantized modes at one shift and their beat (ATY-040). Lead ATY-717; figure `shifted-beat`.
- `shifted.sv-6b.mixed` · line · proved · 2 told, 1 mention — "The mixed equation and its roots" · "Looking both ways: roots and a beat": (ATY-041) —derives→ ATY-045 —order→ ATY-040.

**sv-6c · Step 6c. What was not tried** (section 2.3, p. 8). *The move:* no electromagnetic background and no interactions, so none of the successes of quantum electrodynamics; no massless fermions, so no chirality and no Higgs mechanism; the odd-integer ratios as a test. *On the labels:* no massless plane wave for D₊, while D_s keeps the massless solutions (ATY-005, ATY-007); gauge covariance in a constant potential (ATY-008); a potential with a gradient: the shift mixes the two halves in the operator, the solutions are those of the ordinary equation to first order (ATY-046). Lead ATY-718; two chains, leads ATY-753 and ATY-754.
- `shifted.sv-6c.massless` · line · proved · 0 told, 2 mentions — "No massless shifted wave, but in one variant" · "Waves without mass": (ATY-005) —derives→ (ATY-007). The contrast (none for D₊, kept by D_s) is in the statements; the link is `derives`, so the span opens with a derivation word, not with "but".
- `shifted.sv-6c.potential` · line · proved · 2 told — "A potential, constant and with a gradient" · "The delayed wave in a field": ATY-008 —derives→ ATY-046.

**sv-7 · Step 7. Shift the Einstein equations** (section 3, pp. 8–11). *The move:* the Weitzenböck identity as the bridge from Dirac's operator to Ricci; three of ten shifted Ricci operators; read as series, the leading order gives a cosmological constant of either sign or none; the magnitudes; three readings of (3.5). *On the labels:* the Weitzenböck formula with its signs at points of twelve frames (ATY-051); the constant terms of the series (ATY-010); the operators as series on 1-forms, the lowest order selecting anti-de Sitter, de Sitter and flat space, a correction 2μ (ATY-052); de Sitter order by order, the paper's doubt computed (ATY-053). Lead ATY-719; figure `shifted-ricci`.
- `shifted.sv-7.ricci` · **cycle** · proved · 3 told, 1 mention — "From the Dirac operator to Ricci" · "From the electron's rule to gravity": ATY-051 —cycle→ (ATY-010) —derives→ ATY-052 —derives→ ATY-053 (ATY-051 and ATY-010 support each other: the formula checked on the labels and the series it turns into Ricci).

**sv-8 · Step 8. Einstein–Maxwell by Kaluza–Klein** (section 4, pp. 11–12). *The move:* Maxwell reached through gravity in five dimensions on a circle; the radius obeys an eigenvalue equation (4.3); on de Sitter it grows or decays on the time ħ/kc (4.4), which the paper sets beside the age of the universe; the fifth force; three closing remarks. *On the labels:* the reduction and (4.3) with its constant, 4c = εκ², a constant radius only for D_s² (ATY-054), the Atlas's own □φ = 4cφ (LNS-017e); on a de Sitter base the friction of the base, (4.4) not reproduced, the time scale as a number (ATY-055). Lead ATY-720; figure `shifted-radius`.
- `shifted.sv-8.radius` · fork · proved · 3 told — "The fifth generator and the radius" · "A fifth direction and its size": ATY-054 —equiv→ LNS-017e —derives·ATY-054→ ATY-055.

**sv-9 · Step 9. Two constants, two ends** (section 5, p. 13). *The move:* the paper in one sentence: shifted basic operators with two parameters, the delay fixed at the atomic end, the strength at the cosmological end, their product over ħ a pure number; then three questions in place of conclusions. *On the labels:* (5.3) exact (ATY-005) and in proper time (ATY-037); μ in the deviation (ATY-039) and in the threshold for two quantized energies (ATY-040); the reading that the two constants meet in one number (ATY-065, proposed). Lead ATY-721.
- `shifted.sv-9.mu` · fork · weakest **our reading** (ATY-065) · 1 told, 4 mentions — "Two constants meet in one number" · "Two numbers, one meeting point": (ATY-005) —derives→ (ATY-037) —derives→ (ATY-039) —derives·ATY-037→ (ATY-040) —derives→ ATY-065.

### 2.2 The last section: three questions, and where the labels stop

**sv-open · Three questions, and where the labels stop.** *The lead (ATY-722):* the paper ends on three questions; each is answered here as far as the rows go, with the readings the Atlas proposes and the items that stay open; the paper's numbers, which the labels do not compute, come last. Four chains, leads ATY-755 … ATY-758; their weakest links are open, and their badges stand where the story is weakest (D57).

- `shifted.sv-open.q1` · fork · weakest **open** · 3 told, 2 mentions — "Q1: what the shifted Einstein equations mean" · "What do the shifted gravity equations mean?": INP-049 —uses-input→ (ATY-052) —derives→ (ATY-053) —derives→ ATY-056 —derives·ATY-053→ ATY-057. The badges: INP-049 "needs an input: sign convention" (the sign of the cosmological term, minus the square of a generator); ATY-056 and ATY-057 "open".
- `shifted.sv-open.q2` · fork · weakest **open** · 3 told, 3 mentions — "Q2: a model with particles and a cosmos" · "Could it describe real particles?": (ATY-007) —derives→ ATY-058 —derives·ATY-007→ (ATY-039) —derives→ ATY-059 —order→ (ATY-040) —derives·ATY-058→ ATY-060. The badges: ATY-058 "our reading" (D_s for chiral fermions), ATY-059 and ATY-060 "open".
- `shifted.sv-open.q3` · fork · weakest **open** · 4 told, 4 mentions — "Q3: shifted equations and quantum theory" · "What has it to do with quantum physics?": (ATY-009) —derives→ (ATY-037) —derives→ ATY-061 —order→ (ATY-041) —derives→ ATY-062 —derives·ATY-041→ (ATY-046) —derives→ ATY-047 —derives→ ATY-063. The badges: ATY-061, ATY-062, ATY-047 "our reading" (the clock, the halves the Fock-space remark would mix, the reweighted ordinary theory), ATY-063 "open" (Fock space, localized packets, the data of (2.1) as states).
- `shifted.sv-open.numbers` · line · weakest **open** · 1 told, 1 mention — "The paper's numbers, not computed here" · "The paper's big numbers": (ATY-055) —derives→ ATY-064 (the time scale ħ/kc is a number the labels give; the magnitudes and the coincidence with the age of the universe are the paper's).

### 2.3 The proposed rows of the last section (D61, question A59)

Ten rows, `since: "v2.15"`, no evidence, at home on `shifted`; each research text is the locator's words in `shifted_view.md`, edited only to stand alone (B3 writes them; the owner accepts them before 2.15.0).

| id | kind · badge | stage | what it says (B3 words it from the locator) | depends | locator in `shifted_view.md` |
|---|---|---|---|---|---|
| ATY-056 | question · open | O | what the shifted Einstein equations (3.5) mean — a series in r²Δ, a restriction to 1-forms that solve the wave equation, or an equation for the pair (g, φ) — and which shifted Ricci operator an argument would select | ATY-052, ATY-053, ATY-010 | Step 7, Taken forward, "Open"; The three questions, Q1 |
| ATY-057 | question · open | O | the equation (3.11) for the pair (g, φ) on the Hilbert space of 1-forms is not built | ATY-053, ATY-051 | Step 7, Taken forward, "Open"; What this reading does not do, "The meaning of the shifted Einstein equations" |
| ATY-058 | reading · our reading | F | if chiral fermions are to be shifted at all, D_s is the variant that admits them: D₊ has no massless plane wave, D_s keeps the massless solutions | ATY-007, ATY-005 | Step 6c, Taken forward, "Our reading" |
| ATY-059 | question · open | O | what an equivalence-principle test of a shifted fermion weighs — the Noether energy, where the labels find no deviation, or the coupling per unit local density, where they find a J part — and how a J-valued term is weighed | ATY-039, ATY-037 | Step 5, Taken forward, "Open"; Q2, "The equivalence principle" |
| ATY-060 | question · open | F | the processes of quantum electrodynamics, the Higgs mechanism and the odd-integer test with shifted operators are not computed | ATY-008, ATY-046, ATY-058 | Step 6c, Taken forward, "Open" |
| ATY-061 | reading · our reading | F | the shift behaves as a clock: at the quantized shift the wave is turned by a quarter, exactly where cos Eτ = 0, and on a frame the quantization follows proper time | ATY-009, ATY-005, ATY-037 | Step 5, Taken forward, "Our reading"; Q3, first item |
| ATY-062 | reading · our reading | F | at rest the two signs of frequency are the retarded and the advanced half of one spinor and carry energies of opposite sign per unit number: the halves that the paper's Fock-space remark would mix | ATY-041, ATY-038 | Step 6b, Taken forward, "Our reading"; Q3, third item |
| ATY-063 | question · open | F | a quantized field with the shifted operator (Fock space), localized wave packets and the infinite-dimensional data of (2.1) as a space of states are not built | ATY-062, ATY-046, ATY-047 | Q3, "Open"; Step 6b, Taken forward, "Open" |
| ATY-064 | question · open | O | the magnitudes (2.8), (2.15), (3.7)–(3.9) and (5.1)–(5.4) are the paper's and are not computed; their inputs (the lightest neutrino's mass, the bound on violations of the equivalence principle, the observed cosmological constant) are inputs, given as their sources state them; the coincidence of ħ/kc with the age of the universe is the paper's remark | ATY-055, ATY-052, ATY-037 | What this reading does not do, "No claim about nature"; Step 9, On the labels, "The magnitudes" |
| ATY-065 | reading · our reading | O | the paper's two constants meet on the labels in one number, μ = κτ: the size of the deviation, a J part per unit density, and the threshold for two quantized energies of one species at one shift | ATY-039, ATY-040, ATY-052 | Step 9, Taken forward, "Our reading" |

### 2.4 Where each row is told, and the placements

| row | told in | mentioned in | order on `shifted` | home (unchanged) |
|---|---|---|---:|---|
| EQN-008 · MAP-018 | sv-1 | — | 2101 · 2102 | `steps/dirac` 5 · `logbook` 20 |
| ATY-004 · ATY-006 · ATY-011 · ATY-041 | sv-3 | ATY-041 in sv-2, sv-6b, q3 | 2301 … 2304 | `steps/coupling` 1774 … 1786 |
| ATY-005 · ATY-009 | sv-4 | ATY-005 in sv-3, sv-6c, sv-9; ATY-009 in q3 | 2401 · 2402 | `steps/coupling` 1775 · 1779 |
| ATY-037 · ATY-038 · ATY-039 · ATY-042 · ATY-043 · ATY-044 | sv-5 | ATY-037 in sv-9, q3; ATY-038 in sv-2; ATY-039 in sv-6a, sv-9, q2 | 2501 … 2506 | `steps/coupling` 1782 … 1789 |
| ATY-007 · ATY-010 | sv-6a | ATY-007 in sv-6c, q2; ATY-010 in sv-7 | 2601 · 2602 | `steps/coupling` 1777 · `steps/grav2` 1787 |
| ATY-045 · ATY-040 | sv-6b | ATY-040 in sv-9, q2 | 2701 · 2702 | `steps/coupling` 1790 · 1785 |
| ATY-008 · ATY-046 | sv-6c | ATY-046 in q3 | 2801 · 2802 | `steps/coupling` 1778 · 1791 |
| ATY-051 · ATY-052 · ATY-053 | sv-7 | ATY-052, ATY-053 in q1 | 2901 … 2903 | `steps/grav2` 1036 … 1038 |
| ATY-054 · LNS-017e · ATY-055 | sv-8 | ATY-055 in numbers | 3001 … 3003 | `steps/projective` 1040 · `steps/schuller` 98 · `steps/projective` 1041 |
| INP-049 · ATY-047 | sv-open | — | 3201 · 3209 | `steps/grav2` 14 · `steps/coupling` 1792 |
| ATY-056 … ATY-065 (new) | sv-open, ATY-065 in sv-9 | — | 3202 … 3211, 3101 | `shifted` |

The 24 ATY rows of the shifted view are told once each; 22 mentions; every existing row keeps its home (its lowest order is elsewhere and below 2000).

---

## 3. `matter` — Calibration 2, recomposed

### 3.1 The mechanical draft of the section `furey`, for comparison

The 44 rows of today's single section (FUR-001 … FUR-037, the twins FUR-001b … FUR-005b, CAND-049, CAND-102), extracted with MAX = 8: six chains and one side note; the extraction breaks one directed cycle (FUR-003 ↔ FUR-006, §5).

- C1 · fork · weakest open: FUR-001/FUR-001b —derives→ FUR-002/FUR-002b —derives→ FUR-005/FUR-005b —order→ FUR-007 —derives·FUR-001→ FUR-008 —derives→ FUR-009 —derives→ FUR-010 —derives→ FUR-011 —derives→ FUR-012 —derives·FUR-011→ FUR-014
- C2 · fork · proved: FUR-021 —equiv→ FUR-022 —derives·FUR-021→ FUR-028 —derives→ FUR-029 —derives→ FUR-030 —derives→ FUR-031 —derives·FUR-022→ FUR-033
- C3 · fork · proved: FUR-015 —derives→ FUR-016 —derives→ FUR-017 —derives→ FUR-018 —derives·FUR-017→ FUR-019 —derives·FUR-015→ FUR-027 —derives·FUR-019→ FUR-032 —derives·FUR-027→ FUR-034
- C4 · fork · proved: FUR-013 —derives→ FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037
- C5 · fork · proved: CAND-102 —derives→ FUR-003/FUR-003b —derives→ FUR-004/FUR-004b —derives·FUR-003→ FUR-006
- C6 · line · proved: FUR-020 —derives→ FUR-023 —derives→ FUR-035
- side note: CAND-049

The draft mixes the owner's groups (C1 runs from her board through fibre and base to a reading). The composition below keeps the owner's five groups as five sections, each one story, and gathers the readings, inputs and open items in a sixth.

### 3.2 The five chains and the last section (composed)

Section leads FUR-711 … FUR-716; the overview's lead FUR-701 and next line FUR-702 (STORY_ROUND.md §6.2).

- **fur-model** — `matter.fur-model.rebuilt` · fork · proved · 6 positions (10 rows with the twins) — "Her model, rebuilt on the labels" · "Her big board, rebuilt switch by switch": FUR-001/FUR-001b —derives→ FUR-002/FUR-002b —order→ CAND-102 —derives→ FUR-003/FUR-003b —derives→ FUR-004/FUR-004b —derives·FUR-003→ FUR-006. Side note: CAND-049. FUR-001 is also the page's hero (the top shows the headline; the chain tells it in place).
- **fur-fibre** — `matter.fur-fibre.fibre-base` · fork · proved · 7 — "Fibre and base: two products, one chirality" · "Space and the inner switches": FUR-007 —order→ FUR-008 —derives→ FUR-009 —derives→ FUR-010 —derives→ FUR-011 —derives→ FUR-012 —derives·FUR-010→ FUR-013. Figure `fibre-base` (FUR-011: the chirality as the relative sign of the two complex structures).
- **fur-labels** — two chains, leads FUR-751 and FUR-752:
  - `matter.fur-labels.cl6` · fork · proved · 6 — "Her ℂl(6): ladder operators, states and charges" · "Three ladders and their charges": FUR-015 —derives→ FUR-016 —derives→ FUR-017 —derives→ FUR-018 —derives·FUR-017→ FUR-019 —derives→ FUR-032 (FUR-019 rests on FUR-017, a branch beside FUR-018; FUR-032, the four Fano-line blades outside the image of ℂ ⊗ Cl(0,6), rests on FUR-019: moved here from the roadmap's group, where it rests on nothing).
  - `matter.fur-labels.roadmap` · line · proved · 5 — "The roadmap's five modes as five bits" · "Five ladders as five switches": FUR-027 —order→ FUR-028 —derives→ FUR-029 —derives→ FUR-030 —derives→ FUR-031.
- **fur-sixteen** — `matter.fur-sixteen.weights` · fork · proved · 7 — "The 16: weights, real structure, mass terms" · "One family of sixteen": FUR-020 —order→ FUR-021 —equiv→ FUR-022 —derives·FUR-020→ FUR-023 —derives·FUR-022→ FUR-033 —derives·FUR-020→ FUR-034 —derives·FUR-023→ FUR-035.
- **fur-fields** — `matter.fur-fields.mass` · fork · proved · 5 — "A fibre momentum is a mass" · "Waves whose inner motion is a mass": FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037.
- **fur-next** — `matter.fur-next.open` · fork · weakest **open** · 6 told positions (7 rows with FUR-005b), 2 mentions — "What stays a reading, an input or open" · "What we chose, what we read, what is next": INP-011 —uses-input→ FUR-014 —uses-input·INP-011→ (FUR-034) —derives→ FUR-038 —order→ FUR-005/FUR-005b —derives→ FUR-039 —uses-input·INP-011→ (FUR-026) —derives→ FUR-040. The badges: INP-011 "needs an input: sign convention" (which product, split or signature nature uses), FUR-014 "our reading", FUR-038, FUR-005/b, FUR-039, FUR-040 "open".

Each of the 44 rows of `furey` is told once (CAND-049 as a side note); INP-011 gains a placement (order 1100); the mentions FUR-034 and FUR-026 are told in `fur-sixteen` and `fur-fields`.

### 3.3 The proposed rows of `fur-next` (D61, question A59)

| id | kind · badge | stage | what it says (B4 words it from the locator) | depends | locator |
|---|---|---|---|---|---|
| FUR-038 | question · open | O | what would relate the Lorentz so(4, ℂ) of Cl(1,9) to the su(2)_L ⊕ su(2)_R of Pati and Salam beyond their common complexification: on the labels the two real forms differ by the signature of the first four generators (FUR-034), which is an input | FUR-034, FUR-020, INP-011 (uses-input) | `docs/round13/PLAN.md` §1, item 9; "What is still open" of the 2.14.0 notes |
| FUR-039 | question · open | O | three generations: what the labels would need for three complete sets, beyond the board's one complete set (two with every cell doubled) and the copies Furey and Hughes construct | FUR-005, PAG-015, FUR-027 | `docs/round13/PLAN.md` §1, item 4; PAG-015, PAG-016 |
| FUR-040 | question · open | F | the spectrum of fibre momenta: the labels give a field one mass per fibre momentum and say nothing about which momenta occur | FUR-026, LNS-120, INP-011 (uses-input) | FUR-026; `docs/round13/PLAN.md` §1, item 22 |

They are at home on `matter` (`fur-next`, orders 60 … 62) and on one tab, `matter/help` · `questions` (added, 1002 … 1004), as the Furey test's home rule asks.

### 3.4 The papers sub-page

`matter/papers` gains the section `read` ("Read since, rebuilt on the labels"), lead FUR-717, and six cards, story rows of role `result`, each restating the rows that rebuilt its paper: FUR-761 Furey (2015) → FUR-015, FUR-016, FUR-017; FUR-762 Furey (2016) → FUR-008, FUR-012, FUR-015, FUR-017, FUR-019; FUR-763 Furey (2018) → FUR-018, FUR-027, FUR-030, FUR-031; FUR-764 Furey and Hughes (2022) → FUR-027, FUR-031; FUR-765 Roadmap I (2023) → FUR-028, FUR-029, FUR-030, PAG-014; FUR-766 Furey and Hughes (2024) → FUR-027, FUR-039. Cards, not a chain: the papers follow one another in time and no card derives from another.

---

## 4. The pilot sections

The four sections wave 1 converts beside the two calibrations (STORY_ROUND.md §8), each restricted to the rows of its groups (E1 with `--groups`). For each: the mechanical draft (MAX = 8), then the composition B1 commits to `content/chains/pilot/chains.json`, every change from the draft recorded in `extracted.departures`. The other rows of those sections wait for their wave (§6). Titles are working titles, physics · learner; B1 adds the mathematics title.

### 4.1 `rule` · ideas — thirty GEN rows

The nine nodes of the genesis (GEN-001 … GEN-009, rows of v15 with human research texts and no learner text yet: their spans are the first learner words they get) and the twenty-one detail rows of 2.11.0 to 2.14.0 (GEN-010, GEN-013 … GEN-032).

*Mechanical draft:* 3 chains (26 rows, 2 attached), 2 side notes.
- C1 · cycle · weakest our reading: GEN-009 —order→ GEN-010 —derives→ GEN-013 —derives→ GEN-014 —derives→ GEN-016 —cycle→ GEN-019 —derives→ GEN-024 —equiv·GEN-019→ GEN-025 —derives→ GEN-029 —derives·GEN-024→ GEN-032
- C2 · fork · proved: GEN-017 —derives→ GEN-018 —derives→ GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —derives→ GEN-026 —derives·GEN-021→ GEN-027 —equiv·GEN-023→ GEN-028 —equiv·GEN-017→ GEN-031
- C3 · fork · weakest our reading: GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —derives·GEN-003→ GEN-015 —derives→ GEN-020 —derives→ GEN-030; attached GEN-002 (shares T2), GEN-007 (shares SHP-002)
- side notes: GEN-001, GEN-008

The draft cuts the genesis in four (GEN-001 and GEN-008 alone, GEN-009 at the head of C1, the rest under the CAR algebra): six of the eight steps of the ladder have no edge (§5.3).

*Composed:* 6 chains, 30 told, 1 mention, no side note.
- `rule.ideas.genesis` · **ladder** (n = 0 … 8) · weakest **our reading** (GEN-006) · 9 told — "From the empty label to the block of eight" · "From no switch to eight switches": GEN-001 —order→ GEN-002 —order→ GEN-003 —derives→ GEN-004 —derives·GEN-003→ GEN-005 —derives→ GEN-006 —order→ GEN-007 —order→ GEN-008 —order→ GEN-009. Six `order` links: the story climbs one generator at a time without an unearned "so" (C4) until A62 settles the ladder's edges.
- `rule.ideas.blocks` · fork · proved · 5 told — "Eight more generators: the periodicity as a map" · "Eight more switches, and the pattern repeats": GEN-010 —derives→ GEN-013 —equiv→ GEN-017 —equiv→ GEN-031 —derives·GEN-017→ GEN-018. Joins: GEN-009 → GEN-013, GEN-017 (equiv).
- `rule.ideas.car` · line · proved · 2 told, 1 mention — "Pairs of generators as creation and annihilation" · "Switch pairs that create and remove": (GEN-003) —derives→ GEN-015 —derives→ GEN-020. Joins: GEN-010 → GEN-015. GEN-020 rests on GEN-014 too, told in a later chain: the one edge of the section that runs against the order of its chains.
- `rule.ideas.null` · fork · proved · 5 told — "The cells with a null generator" · "Switches that square to zero": GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —equiv→ GEN-028 —derives·GEN-021→ GEN-027. Joins: GEN-018 → GEN-021, GEN-022; GEN-017 → GEN-023.
- `rule.ideas.limit` · cycle · weakest **our reading** (GEN-016) · 7 told — "The chain of blocks and what its limit keeps" · "Blocks without end, and what is left": GEN-014 —derives→ GEN-019 —derives→ GEN-024 —derives→ GEN-032 —derives·GEN-019→ GEN-026 —equiv→ GEN-030 —cycle→ GEN-016. Ten joins, from the genesis, the blocks, the CAR algebra and the null cells (GEN-009, GEN-013 → GEN-014 and GEN-016; GEN-017 → GEN-019; GEN-010, GEN-017 → GEN-024; GEN-020, GEN-023 → GEN-026; GEN-020 → GEN-030). The reading closes the section, its badge at the end of the story.
- `rule.ideas.routes` · line · proved · 2 told — "The same results by the standard routes" · "The same answers without the labels": GEN-025 —derives→ GEN-029. Joins (equiv): GEN-017, GEN-018, GEN-019 → GEN-025 and GEN-029; GEN-024 → GEN-029.

### 4.2 `cells` · cards — seventeen GEN rows

The section is the lattice of the 65 ATL cards (wave 2) with seventeen GEN detail rows, fifteen of them told on `rule` too: a row told on two pages has a span in each chain (the text key carries the chain).

*Mechanical draft:* 2 chains (15 rows, 1 attached), 1 side note.
- C1 · cycle · weakest our reading: GEN-012 —order→ GEN-016 —order→ GEN-020 —derives·GEN-012→ GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —derives→ GEN-026 —derives·GEN-021→ GEN-027 —equiv·GEN-023→ GEN-028 —equiv·GEN-026→ GEN-030; attached GEN-031 (shares GEN-013)
- C2 · fork · proved: GEN-019 —derives→ GEN-024 —equiv·GEN-019→ GEN-025 —derives→ GEN-029 —derives·GEN-024→ GEN-032
- side note: GEN-011

*Composed:* 3 chains, 15 told, 2 side notes; the null cells, the limit and the routes of §4.1 with the rows the cards place.
- `cells.cards.null` · fork · proved · 6 told — "The cells with a null generator" · "Switches that square to zero": GEN-012 —derives→ GEN-021 —derives→ GEN-022 —derives·GEN-021→ GEN-023 —equiv→ GEN-028 —derives·GEN-021→ GEN-027 (GEN-012, the null cells as Grassmann algebras, opens it here; GEN-023 rests on GEN-019 too, told in the next chain).
- `cells.cards.limit` · cycle · weakest **our reading** (GEN-016) · 7 told — "The chain of blocks and what its limit keeps" · "Blocks without end, and what is left": GEN-020 —order→ GEN-019 —derives→ GEN-024 —derives→ GEN-032 —derives·GEN-019→ GEN-026 —equiv→ GEN-030 —cycle→ GEN-016. Joins: GEN-012 → GEN-032; GEN-023 → GEN-026.
- `cells.cards.routes` · line · proved · 2 told — as on `rule`: GEN-025 —derives→ GEN-029. Joins: GEN-019 → GEN-025, GEN-029; GEN-024 → GEN-029.
- side notes: GEN-011 (the ungraded product beside the graded one: its parents GEN-010 and T4 are not placed here), GEN-031 (the two-step maps of Atiyah, Bott and Shapiro: GEN-013, GEN-017 and GEN-010 are not placed here).

### 4.3 `steps/coupling` · eq-coupling — twenty-four ATY and FUR rows

The home of eighteen rows of the shifted view (ATY-010 lives on `steps/grav2`, ATY-051 … ATY-055 on `steps/grav2` and `steps/projective`) and of six FUR rows of the fibre momentum. On `shifted` the ATY rows are told in the paper's order (§2); here in the coupling step's own, from the plane waves to the energy and the tensor. The other nineteen rows of the section (CAND-013 … CAND-110, CPL-001 … CPL-012) wait for wave 3.

*Mechanical draft:* 4 chains (24 rows), no side note.
- C1 · fork · proved: FUR-013 —derives→ FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037
- C2 · fork · weakest our reading: ATY-004 —derives→ ATY-005 —derives→ ATY-006 —derives·ATY-005→ ATY-007 —derives·ATY-004→ ATY-008 —derives·ATY-005→ ATY-011 —instance→ ATY-041 —derives→ ATY-038 —derives→ ATY-043 —derives·ATY-041→ ATY-046
- C3 · fork · weakest our reading: ATY-039 —derives→ ATY-042 —derives→ ATY-044 —derives·ATY-039→ ATY-045 —instance→ ATY-047
- C4 · line · proved: ATY-009 —derives→ ATY-037 —derives→ ATY-040

The draft runs the shift, the energy and the tensor together in one chain of ten (C2) and leaves the quarter turn and the clock apart (C4).

*Composed:* 5 chains, 24 told, 1 mention, no side note.
- `steps-coupling.eq-coupling.shift-waves` · fork · weakest **our reading** (ATY-011) · 7 told — "The shift on plane waves" · "A delayed wave, turned by a quarter": ATY-004 —derives→ ATY-005 —derives→ ATY-009 —derives·ATY-005→ ATY-006 —derives·ATY-005→ ATY-007 —derives·ATY-004→ ATY-008 —derives·ATY-005→ ATY-011 (a star around ATY-005: the exact quantization, then what each row draws from it).
- `steps-coupling.eq-coupling.shift-energy` · fork · proved · 5 told — "Proper time, energy and a beat" · "A clock, an energy, and a beat": ATY-037 —order→ ATY-041 —derives→ ATY-038 —derives→ ATY-039 —derives·ATY-038→ ATY-040. Eleven joins from `shift-waves` (ATY-005, ATY-007, ATY-009, ATY-011); ATY-039 rests on ATY-037 too.
- `steps-coupling.eq-coupling.shift-tensor` · fork · proved · 3 told — "Energy and momentum with a bilocal term" · "How energy and momentum flow": ATY-042 —derives→ ATY-043 —derives·ATY-042→ ATY-044.
- `steps-coupling.eq-coupling.off-modes` · fork · weakest **our reading** (ATY-047) · 3 told, 1 mention — "Off the quantized modes" · "Between the allowed waves": (ATY-041) —derives→ ATY-045 —derives·ATY-041→ ATY-046 —derives→ ATY-047 (ATY-047 is an instance of ATY-045 too).
- `steps-coupling.eq-coupling.fibre-mass` · fork · proved · 6 told — "A fibre momentum is a mass" · "Waves whose inner motion is a mass": the mechanical C1 unchanged; on `matter` the same rows without FUR-013 form `matter.fur-fields.mass`.

### 4.4 `steps/baez` · bz-generation — seventeen ATY, FUR and CAND rows

Baez's generation on five bits, with the FUR rows of 2.12.0 to 2.14.0 placed here as details. The other fourteen rows (LNB-014 and LNB-015 with six split lines each) wait for wave 6: two chains with E2b, fourteen side notes without it.

*Mechanical draft:* 3 chains (15 rows), 2 side notes.
- C1 · fork · proved: FUR-011 —derives→ FUR-012 —derives→ FUR-020 —derives·FUR-012→ FUR-021 —derives·FUR-020→ FUR-023 —derives→ FUR-030 —derives→ FUR-031 —derives·FUR-021→ FUR-033 —derives·FUR-020→ FUR-034
- C2 · line · proved: CAND-003 —derives→ ATY-028 —derives→ FUR-035
- C3 · line · proved: CAND-019 —derives→ FUR-022 —derives→ FUR-029
- side notes: CAND-071, CAND-062

*Composed:* 3 chains, 16 told, 1 side note, in an order no edge runs against: the weights of the 32 first, the anomalies and the mass terms on them, then the generation on five Fock bits, which rests on both.
- `steps-baez.bz-generation.weights` · fork · proved · 6 told — "The 32 of Cl(1,9): weights and two real forms" · "Thirty-two states and their weights": FUR-011 —derives→ FUR-012 —derives→ FUR-020 —derives·FUR-012→ FUR-021 —derives·FUR-020→ FUR-023 —derives·FUR-020→ FUR-034.
- `steps-baez.bz-generation.no-mass` · line · proved · 3 told — "Anomalies, the sign of chirality and mass terms" · "One hand, two hands, and mass": CAND-003 —derives→ ATY-028 —derives→ FUR-035. Joins: FUR-011, FUR-023 → FUR-035.
- `steps-baez.bz-generation.fock` · fork · proved · 7 told — "One generation on five Fock bits" · "One family on five switches": CAND-019 —derives→ FUR-022 —derives→ FUR-029 —derives→ FUR-030 —derives→ FUR-031 —order→ CAND-071 —derives·FUR-022→ FUR-033. Nine joins from the two chains before it (CAND-003 → FUR-022, FUR-031; FUR-020, FUR-021 → FUR-022, equiv; FUR-021, FUR-023 → FUR-030; FUR-011, FUR-020, FUR-021 → FUR-033).
- side note: CAND-062 (the Hodge star exchanges the 16 and the 16̄ and negates the weights; it has no `depends`: a `contrasts` link with a note is T3's call, not the extraction's).

### 4.5 The pilot in numbers

| section (groups) | rows | mechanical: chains · rows in chains (+ attached) · side notes | composed: chains · told · mentions · side notes | weakest links of the composition |
|---|---:|---|---|---|
| `rule` · ideas (GEN) | 30 | 3 · 26 (+ 2) · 2 | 6 · 30 · 1 · 0 | genesis, limit: our reading |
| `cells` · cards (GEN) | 17 | 2 · 15 (+ 1) · 1 | 3 · 15 · 0 · 2 | limit: our reading |
| `steps/coupling` · eq-coupling (ATY, FUR) | 24 | 4 · 24 · 0 | 5 · 24 · 1 · 0 | shift-waves, off-modes: our reading |
| `steps/baez` · bz-generation (ATY, FUR, CAND) | 17 | 3 · 15 · 2 | 3 · 16 · 0 · 1 | all proved |
| **pilot** | **88** | **12 · 80 (+ 3) · 5** | **17 · 85 · 2 · 3** | |

With the two calibrations, wave 1 tells 41 chains: 170 told rows (the five twins of `matter` included) and 26 mentions, about 200 spans for T3 (`shifted` 60, `matter` 49 with the five twins, the pilot 87).

---

## 5. Findings, row by row

**5.1 Where `depends` is too thin.** On `depends` alone 558 of the 1,098 placements are singletons and 24 sections of three rows or more hold no chain; with E2b (§5.5), 348 and 14. The fourteen: `rule` · conventions (5 rows), `clock` · clock-trinity (4), `steps/nullsurf` · eq-nullsurf (10) and · summary (3), `steps/forque` · eq-forque (5), `steps/spring` · eq-spring (5), `steps/category` · cat-deadends (7), `steps/baez` · bz-honest (6), · bz-persp (20) and · bz-questions (8), `steps/schuller` · sc-quantum (6), · sc-honest (7), · sc-notes (3) and · sc-thm (5). Seven are lists by their names (the conventions, the summary of `steps/nullsurf`, the dead ends, the two honest notes, the notes, the questions): their rows stay side notes, told in no order. The other seven (clock-trinity, eq-nullsurf, eq-forque, eq-spring, bz-persp, sc-quantum, sc-thm) are the labelling pass of A62, `steps/nullsurf` and `bz-persp` first.

**5.2 The cut of the sections.** Of the `depends` edges between rows the story pages place, 656 stay inside a section, 874 join two sections of one page and 381 two pages; 1,191 lead to rows no story page places (theorems, inputs, the Logbook's rows). `joins` (E9) keeps the 874 visible as "Continues from" while chains stay inside their sections. `steps/nullsurf` is the extreme: no edge inside any of its six sections, six across them (NUL-001 and NUL-004 → EQN-020, NUL-001 → NUL-003, NUL-004 → NUL-011), 71 off the page. Its results sit in sections of their own (`nl-res-1` … `nl-res-4`), its equations in `eq-nullsurf`, and both rest on theorems and inputs rather than on each other. E2b joins NUL-001 to its five split lines, the step's one chain.

**5.3 The genesis has no ladder in `depends`.** GEN-001 … GEN-009 climb n = 0 … 8, one generator per node, in the owner's text and in their cells. Their edges go to the theorems and the cells (ATL-001, ATL-015, ATL-023, T2, T4, T7, T20, SHP-002, two inputs), and only GEN-004 and GEN-005 (on GEN-003) and GEN-006 (on GEN-005) rest on a node. `rule.ideas.genesis` keeps the ladder with six `order` links (§4.1). A62 asks the owner whether each node rests on the one before it and by which relation; with those edges the storyteller may say "so" on every rung.

**5.4 Seven directed cycles** in `derives`, `instance` and `uses-input` (strongly connected sets over all rows; the extraction breaks each at its earliest row and reports it):

| rows | edges | where they are placed |
|---|---|---|
| FUR-003, FUR-006 | each `derives` from the other | `matter` · furey and `matter/model` · axes (the pilot) |
| LNB-029c, LNB-179 | each `derives` from the other | `steps/baez` · bz-gaps |
| LNB-015, LNB-106 | LNB-106 derives from LNB-015, which uses LNB-106 as an input | `steps/baez` · bz-generation (LNB-106 unplaced) |
| GRV-012, INP-056 | INP-056 derives from GRV-012, which uses it | `steps/grav2` |
| GRV-011, MAT-007, INP-050 | MAT-007 on GRV-011 on INP-050 on MAT-007 | `steps/grav2`, `steps/matter` |
| EQN-012, GRV-006, GRV-010, INP-044, INP-045, INP-048 | INP-044 derives from GRV-006 and INP-045 from GRV-010, rows that use INP-045 and INP-048, and INP-048 uses INP-044, which EQN-012 uses | `steps/grav1`, `steps/grav2` |
| CPL-010, PAG-023, YM-008 | PAG-023 derives from CPL-010 and from YM-008, each recorded as an instance of PAG-023 | `steps/coupling`, `light`, `steps/ym` |

Four close through a `uses-input` edge, three of them through an INP row that rests on a row using it. A62 records each set as `cycle` or `equiv`, or turns an edge round; until then the composed chains avoid them (`matter.fur-model.rebuilt` tells FUR-003 before FUR-006 and links them by `derives` from FUR-003 only).

**5.5 Split lines carry no edge.** 248 rows are lines split from a longer row (`splitFrom`); none has the `equiv` or `derives` edge to its first line that 02 §1 asks for. E2b reads `splitFrom` as `continues`: 49 chains more (140 → 189), 210 singletons fewer (558 → 348), ten sections fewer without a chain (24 → 14). Writing the 248 edges into `depends` instead is a table change for a release owner (A62).

**5.6 Rows that hold several steps.** On `shifted`, ATY-005, ATY-039 and ATY-041 are mentioned in three chains each, ATY-007, ATY-037 and ATY-040 in two, seven more rows in one (22 mentions): their research texts cover several of the paper's steps (ATY-005 the exact quantization, the paper's (2.6), (2.7) and (2.9), the second branch and the massless case). They are told once and mentioned where the paper needs them; A61 asks whether to split ATY-005, ATY-010, ATY-038 and ATY-041 into per-step lines.

**5.7 Hubs link nothing.** The rows most placed rows rest on: T4 (106 edges), T18 (51), T20 (45), T2 and T17 (35 each), T3 (31), T10 (30), T16 (28), T5 (27), LNB-021 (26). A shared hub links nothing (E8); otherwise every section would collapse into one chain around its theorem. A shared input links nothing either (LABELLING_SCHEME §2).

**5.8 Contradictions stay apart.** Fifteen `contradicts` edges: GEN-002 with ATL-002 and ATL-002b; CPL-002 with INP-029; NUL-002 and NUL-003 with INP-060; LNB-058 with LNB-158; T8 with LNC-010, LNC-054 and LNC-083; LNS-024 with GRV-005 and LNS-032; T15 with LNS-025, LNS-037 and RSN-011; LNS-122 with LNS-125. None is ever a link (V3); they stay in the record fold until A6 resolves them. One touches the pilot: GEN-002 (`rule.ideas.genesis`) against ATL-002, a card of `cells` (wave 2), so no chain holds both.

---

## 6. Counts

### 6.1 The rest of the Atlas, page by page

The mechanical extraction (E1–E9, MAX = 8) on every story page of today, with E2b; the last two columns without it. "Rows" are the placements of statement rows in roles result and detail: the story rows, leads, captions and notes, the Logbook, Ask, the glossary, the inputs sections and the 149 matrix lines apart; a row placed on two pages counts on each (the 44 FUR rows on `matter` and on `matter/model`). `shifted` is not here (a new page); `matter` is today's single section.

| page | step | sections | rows | chains | rows in chains (+ attached) | side notes | singletons | sections of ≥ 3 rows without a chain | matrix lines apart | chains without E2b | singletons without E2b |
|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|
| `rule` | — | 2 | 35 | 3 | 26 (+ 2) | 7 | 9 | 1 | 0 | 3 | 9 |
| `cells` | — | 1 | 82 | 22 | 64 (+ 3) | 15 | 18 | 0 | 0 | 6 | 58 |
| `clock` | 1 | 3 | 27 | 2 | 15 (+ 1) | 11 | 12 | 1 | 0 | 2 | 12 |
| `light` | — | 4 | 26 | 6 | 21 (+ 1) | 4 | 5 | 0 | 0 | 6 | 5 |
| `steps/comm` | 2 | 2 | 5 | 1 | 2 (+ 1) | 2 | 3 | 0 | 0 | 1 | 3 |
| `steps/mirrors` | 3 | 2 | 20 | 6 | 13 (+ 1) | 6 | 7 | 0 | 0 | 6 | 7 |
| `steps/dirac` | 4 | 2 | 3 | 0 | 0 | 3 | 3 | 0 | 0 | 0 | 3 |
| `steps/spin` | 5 | 11 | 10 | 2 | 4 | 6 | 6 | 0 | 30 | 2 | 6 |
| `steps/coupling` | 6 | 2 | 44 | 8 | 35 (+ 1) | 8 | 9 | 0 | 0 | 8 | 9 |
| `steps/ym` | 7 | 3 | 20 | 5 | 16 | 4 | 4 | 0 | 0 | 3 | 9 |
| `steps/matter` | 8 | 2 | 10 | 3 | 7 | 3 | 3 | 0 | 0 | 2 | 5 |
| `steps/grav1` | 9 | 3 | 14 | 2 | 11 | 3 | 3 | 0 | 0 | 2 | 3 |
| `steps/grav2` | 10 | 2 | 28 | 4 | 18 | 10 | 10 | 0 | 0 | 4 | 11 |
| `steps/projective` | 11 | 4 | 13 | 3 | 10 | 3 | 3 | 0 | 0 | 3 | 4 |
| `steps/gauge` | 12 | 2 | 7 | 3 | 7 | 0 | 0 | 0 | 0 | 3 | 0 |
| `steps/nullsurf` | 13 | 6 | 23 | 1 | 6 | 17 | 17 | 2 | 0 | 0 | 23 |
| `steps/forque` | 14 | 3 | 9 | 0 | 0 | 9 | 9 | 1 | 41 | 0 | 9 |
| `steps/spring` | 15 | 9 | 6 | 0 | 0 | 6 | 6 | 1 | 22 | 0 | 6 |
| `steps/rigid` | 16 | 10 | 19 | 3 | 7 (+ 7) | 5 | 12 | 0 | 56 | 3 | 12 |
| `steps/groups` | 17 | 2 | 13 | 2 | 5 (+ 2) | 6 | 8 | 0 | 0 | 2 | 8 |
| `steps/category` | 18 | 23 | 182 | 33 | 108 (+ 8) | 66 | 74 | 1 | 0 | 26 | 92 |
| `steps/baez` | 19 | 16 | 223 | 34 | 158 (+ 5) | 52 | 57 | 3 | 0 | 24 | 132 |
| `steps/schuller` | 20 | 18 | 160 | 30 | 109 (+ 3) | 48 | 51 | 4 | 0 | 18 | 113 |
| `shapes` | — | 3 | 27 | 3 | 17 | 10 | 10 | 0 | 0 | 3 | 10 |
| `matter` | — | 1 | 44 | 6 | 43 | 1 | 1 | 0 | 0 | 6 | 1 |
| `matter/dictionary` | — | 2 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `matter/papers` | — | 3 | 2 | 0 | 0 | 2 | 2 | 0 | 0 | 0 | 2 |
| `matter/model` | — | 4 | 44 | 7 | 37 (+ 1) | 3 | 4 | 0 | 0 | 7 | 4 |
| `matter/generations` | — | 2 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 1 |
| `matter/help` | — | 1 | 1 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 1 |
| **30 pages** | | **148** | **1,098** | **189** | **739 (+ 36)** | **312** | **348** | **14** | **149** | **140** | **558** |

1,098 = 739 rows in chains (the twins with their positions) + 36 attached + 312 side notes + 11 mathematics twins beside their side notes (8 in `steps/baez` · bz-persp, 3 in `matter/model`).

### 6.2 The waves

The same extraction with the pilot rows cut out of their four sections (wave 1) and each section's remainder extracted on its own; brackets: without E2b. These are mechanical sizes, before composition: on the pilot, composition turned 12 chains and 5 side notes into 17 chains and 3 side notes (§4.5). Spans to write ≈ the rows in chains and attached; side notes keep, or get, a learner `full` text.

| wave · release | what | sections | rows | chains | rows in chains (+ attached) | side notes | sections of ≥ 3 rows without a chain | matrix lines apart | spans, about |
|---|---|---:|---:|---|---|---|---|---:|---:|
| 1 · 2.15.0 | `shifted` (new), `matter`, the four pilot sections (composed: §2–§4) | 12 + 6 + 4 | 38 + 48 + 88 | 41 (17 + 7 + 17) | 170 told, 26 mentions | 4 (CAND-049; GEN-011, GEN-031, CAND-062) | 0 | 0 | 200 |
| 2 · 2.16.0 | `rule` · conventions, `cells` (the ATL cards), `clock`, `light`, steps 2–4 | 16 | 151 | 35 [19] | 100 (+ 6) [60 (+ 12)] | 45 [79] | 2 [2] | 0 | 106 |
| 3 · 2.17.0 | steps 5–8 (eq-coupling's other 19 rows), the five Furey tabs | 30 | 108 | 20 [17] | 75 (+ 2) [68 (+ 4)] | 28 [33] | 0 [0] | 30 | 77 |
| 4 · 2.18.0 | steps 9–13 | 17 | 85 | 13 [12] | 52 [44 (+ 2)] | 33 [39] | 2 [3] | 0 | 52 |
| 5 · 2.19.0 | steps 14–17, `shapes` | 27 | 74 | 8 [8] | 29 (+ 9) [29 (+ 9)] | 36 [36] | 2 [2] | 119 | 38 |
| 6 · 2.20.0 | steps 18–20 (bz-generation's other 14 rows) | 57 | 548 | 94 [64] | 359 (+ 16) [202 (+ 27)] | 165 [311] | 8 [18] | 0 | 375 |
| waves 2–6 | | 147 | 966 | 170 [120] | 615 (+ 33) [403 (+ 54)] | 307 [498] | 14 [25] | 149 | 648 |

Wave 1's rows: on `shifted` 28 existing rows and 10 new, all told; on `matter` the 44 rows of `furey` with INP-011 and FUR-038 … FUR-040, 47 told (the five twins included) and the side note CAND-049. If wave 6 ships as two releases: `steps/category` 23 sections, 182 rows, 33 chains (108 + 8), 66 side notes, one section without a chain; `steps/baez` and `steps/schuller` 34 sections, 366 rows, 61 chains (251 + 8), 99 side notes, seven sections without a chain. Without E2b one section more lacks a chain across the waves (25, not 24) because bz-generation's fourteen LNB lines, cut from the pilot, are all split lines.
