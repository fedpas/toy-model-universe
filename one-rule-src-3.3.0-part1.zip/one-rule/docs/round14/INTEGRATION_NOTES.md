<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 14, wave 1: the integration list for R7 (collected by the lead from the builders' reports)

Everything below was left by one builder for the release owner; each line names who found it. The design is `STORY_ROUND.md`, the owner's answers `OWNER_ANSWERS.md`, B1's implementation notes `B1_NOTES.md`.

## Budgets and constants
- `tests/shipped.test.mjs`: `BUDGET.extraJsGz` 260 → 300 kB (D63; the chunk is 262.3 kB gz with the six figures of p12 and p13) — B1, B2, B3, B4.
- A60: `NEW_SINCE` in `tools/build_content.mjs` becomes the current version only (`v2.15`), the logbook test's "new" count follows; the `shifted` page shows 45 "new" badges until then — B3.
- `package.json` `test:ui`: add `node tests/ui/chains.smoke.test.mjs` — B2.

## Merges and manifests
- `engines/MANIFEST.json`: merge `engines/physics/MANIFEST.p12.json` (B3) and `MANIFEST.p13.json` (B4); the physics test's manifest check fails until then — B3, B4.
- `tools/merge_story.mjs`: an added page gets `connective: {}` — the research try lines of sv-4, sv-6b, sv-7, sv-8 and the top's lines of `shifted` (in `content/chains/shifted/page.json`) never reach `pages.json`; fix `connective: d.connective ? clone(d.connective) : {}` — B3. The same tool does not apply an existing page's `learnerFrame` or entry-level `connective` on recomposition: `furey.json`'s `learnerFrame.after` and its research try lines for the top notes and fur-fibre are not in `pages.json` (only the tryLearner line is) — B4.
- `tools/merge_explore.mjs` / `tools/merge_physics.mjs`: their `textKey` lacks `chain`; merge_story writes the spans back so the pipeline stays idempotent; a one-line fix makes it clean — B1.
- At the release: `node tools/merge_chains.mjs --retire "2.15.0"` (D54: the old drafts of the storied rows retire to `content/chains/retired.json`) — B1.

## Tests
- `tests/chains.test.mjs` section D: its copy of the tables keeps T3's `content/chains/learner/rule.json` after it removes the pilot, so the checker fails 9 times on rule.ideas.genesis and the test stops on ENOENT; the copy must drop the pilot's spans too — B4 found it.
- Tests that compare learner statements with `textFor` must pass `data-chain` once spans exist (the furey and landing tests); `story.smoke`'s keyboard check then runs on real spans — B2.
- `tests/story/migration.test.mjs` F failed on B1's interim state (build_content's chain check without the overlay) — B2; B1 reports it green after its fix: confirm.
- `tutorials` needs `NODE_PATH=/opt/npm-tools/node_modules` (the shell's global folder lacks markdown-it) — B3.
- The coverage leaks found by B1/B2 (ATY-064's words in ShiftedRadius; FUR-762 against a furey lens term) were fixed by B3 (reworded notes, ATY-715/717/758) — confirm coverage is green on the final tables; if the FUR-762 leak persists, reword the card, not the lens.

## Docs for R7 to write
- `docs/02_CONTENT_MODEL.md` §11 (chains, spans, the section field `chains`, the role `chain`) from B1_NOTES §2; `docs/09_TRANSLATION_PROTOCOL.md` §2 → the storyteller (STORY_ROUND §7); `docs/DECISIONS.md` D51–D64 and A59–A65 as taken; `docs/BUILD_CONTRACTS.md` interfaces 40–44; `docs/HANDOVER.md`; `docs/LEARNER_TEXTS_chains.md` consolidating the three storytellers' records (`docs/LEARNER_TEXTS_chains.md` by T3 for the pilot pages, `docs/round14/LEARNER_TEXTS_shifted.md`, `docs/round14/LEARNER_TEXTS_matter.md`); the release notes `docs/RELEASE_NOTES_v2.15.md`, `CHANGELOG.md`, `README.md`'s state line, `package.json` 2.15.0, `tools/release.sh` (RECORDS → `docs/round14/STORY_ROUND.md`, `SPINE.md`, `OWNER_ANSWERS.md`, `LEARNER_TEXTS_*`, this file; the Statements sentence for the v2.15 rows: 13 statement rows and the story rows).
- A new release-notes section "What the reader sees" must say: Calibration 3 at `#/shifted`; Furey's page recomposed; the chains at learner level on six pages; which chains are storied and which rows still show their old drafts (D54).

## From the storytellers' runs (added as they report)
- T3 (pilot pages): 17 of 17 chains storied, 87 spans; GEN-031 got a learner full text; four spans reworded against the notes (ATY-038, 041, 046, 047). Confirms the `tests/chains.test.mjs` part D defect: the copy must empty `content/chains/learner/` before adding the fixture's spans (one line).
- Text edit for R7 (the owner's point, T3): GEN-016's research text still says the union of the stages is not computed, while GEN-030 (2.14.0) builds it on the finite side — add a pointer clause to GEN-016 as R6 did for GEN-019 ("… the union of the stages, computed on the finite side in GEN-030; its completion is not"), claim unchanged, recorded in the release notes.
- GEN-030's research text holds the path `docs/round13/SOURCES.md`, which the number rule reads as a "13": leave the text, the span says "Stacey's theorem 13" (the real number) — nothing to do unless the owner wants the path out of the text.
- T3m (matter, matter/papers): 7 of 7 chains storied, 49 spans (5 human verbatim), 17 story rows' learner texts, 35 full texts (FUR-007 … 040, CAND-049); five chains end within 1 % of the 0.8 budget (method detail compressed, every number and status word kept; the record lists each cut) — an owner's choice later: 0.9 for the dense proof rows.
- T3s (shifted): 17 of 17 chains storied, 60 spans, 23 story rows' learner texts, 12 full texts (MAP-018, INP-049, ATY-056 … 065); nine records reworded against notes/lens/stored tables for the coverage words rule.
- `tests/story/shifted.test.mjs`: its note "38 told rows wait for their learner texts" is a false alarm — the parser reads `ol.chain__list`, storied chains render as `p.chain__story`; fix the parser (B3's file, for R7).
- Final state before R7: `merge_chains --check`: 41 chains on 6 pages, 41 storied, 196 spans; round-14 rows: 40 story rows, 13 statement rows; `check_learner_texts`: 1449 records, PASS; `npm run content`: 0 errors; coverage PASS; furey/shifted/landing story tests PASS; chains.smoke PASS (308). Failing: shipped (the chunk budget), chains.test.mjs part D (the copy's learner files), physics manifest check (p12/p13 not merged).
