<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 14: the owner's answers to §11 of STORY_ROUND.md (17 Oct, 16:35)

The owner took the architect's first option on every question. For the builders, the storyteller and the release owner, this is what it fixes:

- **A59 (a)**: the thirteen rows the end-sections need are accepted as drafts for the author — ATY-056 … ATY-065 (ten readings and questions of the shifted view) and FUR-038 … FUR-040 (three questions of Calibration 2); their texts come from the analysis page `shifted_view` and the release notes, each with its status (ours, open or input) and the badge that status gives; `since: "v2.15"`, source `story:round14`.
- **A60 (a)**: the badge "new" is shown for the rows of the latest release only (A45's option): NEW_SINCE keeps a single version, the current one; the stories then carry only the badges of what is not proved. R7 changes `tools/build_content.mjs` NEW_SINCE to the current version and the logbook test's "new" count with it.
- **A61 (a)**: the rows that hold several steps of the paper (ATY-005, ATY-010, ATY-038, ATY-041) are told once and mentioned where they recur; no split this round.
- **A62 (a)**: a labelling pass on `depends` (the genesis ladder GEN-001 → GEN-002 → …, the fourteen sections of three rows or more without a chain, the seven directed cycles, the 248 split lines' edge to their first line) is scheduled before wave 2 (2.16.0), not in this release; this round E2b reads `splitFrom`.
- **A63 (a)**: a told row with a human learner text keeps its human words as its span (D6); the storyteller writes the neighbouring spans to carry the connection.
- **A64 (a)**: the precisions of the standard routes (tolerances, sample counts) stay in the spans, as R6 asks.
- **A65 (a)**: the titles as proposed: "Calibration 3: the shifted view (Atiyah and Moore)" · math "Calibration 3: shifted operators (Atiyah and Moore)" · learner "Warm-up 3: Atiyah's delayed waves"; the step titles of §6.1 as written.

Decisions D51 … D64 of §1 stand as the round's decisions; R7 records them in `docs/DECISIONS.md` with A59 … A65 as taken.
