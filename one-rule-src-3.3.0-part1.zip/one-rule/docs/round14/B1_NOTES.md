<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 14, B1: the content model, the tools and the tests — notes

What B1 built for `docs/round14/STORY_ROUND.md` (§2, §3, §5; D52–D61), how the interfaces 40 (the chain record) and 41 (the span) are implemented, where the extraction's counts differ from `SPINE.md` and why, and what is left to the other owners. The shapes of §2.1 and §2.2 are unchanged.

## 1. The files

| file | what it does |
|---|---|
| `tools/story/extract_chains.mjs` | E1–E9; `--page`, `--section`, `--groups`, `--max`, `--json`, `--into`, `--diff`, `--counts` (SPINE.md §6.1 and §6.2); deterministic |
| `tools/merge_chains.mjs` | the overlay reader, `mergeChains(tables, overlay)` (V1–V10, the section fields, the table `content/chains.json` with `story`), `--check`, `--retire "<wave>"` |
| `tools/merge_story.mjs` | calls the chain overlay at steps 1, 2, 3, 4 and after 5 (D59: one merge, one book); the text key holds `chain`; `ROLES` gains `chain`; an added page takes `after`, `needs`, `learnerFrame`; writes `content/chains.json` and `MIGRATION_COUNTS.json` → `chainMerge` |
| `tools/check_learner_texts.mjs` | reads `content/chains/learner/*.json` with the texts_learner files; R1–R13 with the span changes of §3.2; C1–C11; `--explain <chain id>` (the worksheet); `--chains` for a fixture; the chain self-test |
| `tools/merge_learner_texts.mjs` | its key holds `chain`; drafts listed in `content/chains/retired.json` leave `texts.json` |
| `tools/build_content.mjs` | §3.4: the references of `content/chains.json` and of every span; span records skipped by the research and learner maps; `ROLES` with `chain`; `NEW_SINCE` with `v2.15`; a chains section in `docs/COVERAGE.md` |
| `tools/export_tuning.mjs`, `content/tuning/schema.json` | `chains.jsonl` (each chain with its computed status); a span text carries `chain` and `span`; the schema gains the file, `definitions.chain`, the register `span` and the placement role `chain` (the schema is the export's own spec, edited because §9's export change needs it) |
| `content/chains/pilot/chains.json` | the 17 pilot chains of SPINE.md §4, composed; links, shapes and joins computed from `depends`; `story: "none"`, no lead |
| `tests/chains.test.mjs`, `tests/chains/fixture/` | §5 (parts A–G below); the fixture: three chains on real rows (`rule` · ideas: GEN-001 … GEN-006, a mention, a lead GEN-751; `matter/model` · axes: FUR-003/FUR-003b → FUR-004/FUR-004b, twins with human words), good and broken spans, the extraction's eleven synthetic cases |
| tests edited | `coverage`, `story/migration`, `logbook`, `shipped` (rules 1, 6, 7), `export`; `tools/migrate/verify_counts.mjs`; `package.json` (`content` runs `merge_chains.mjs --check`; `test:data` runs `tests/chains.test.mjs`) |

## 2. The interfaces as implemented

- **Chain record (40).** As §2.1. The owners' `story` is not read: the merge writes it (`none`; `draft` when every position and twin has its span and the lead its learner text; `reviewed` when all those texts are reviewed or human). `extracted.component` is the number k of the draft chain Ck the composed chain shares most told rows with (what `--diff` prints); `extracted.departures` are `--diff`'s strings. The merged table keeps `extracted`, as §2.1 shows it. `joins` target told positions only (a mention's edges are joined where it is told) and count an undirected edge from either side.
- **Span (41).** As §2.2. In `texts.json` a span is `{ row, lang, mode, level, lens, register: "span", chain, span, body, status, source }` (the learner file's `termsUsed` and `keptNumbers` are not merged, as for every learner text). A C10 span is the row's human text, `status: "human"`, its `source`.
- **Section field (§2.3).** Written by the merge from the records, in `order`; a typed `chains` is removed with a warning.
- **Shapes.** `ladder` needs three positions or more (as the prototype): two rows with climbing cells stay a line.
- **`--into`** writes empty titles: V7 refuses an untitled chain, so a mechanical draft never ships before its composer has named it.

## 3. Rules added where the design left a gap

- **D51 refused, not repaired.** merge_story's step 5 repairs a moved home by lowering the home entry's order, which re-sorts the home section silently. For the chain overlay's placements (`content/chains/<owner>/page.json`) the merge refuses instead: an added placement must sit above the order of the row's home; a move on the row's own page keeps its order (§2.7).
- **V9, the learner text of a round-14 story row** is a warning while missing (the design lists it among V9's requirements; B3 and B4 merge before T3 writes, and D54 lets an unstoried page render).
- **V4.** Every `restates` of a chain's lead names a row of that chain (a position or a twin).
- **V3.** An `order` link where `depends` has an edge between the two rows is a warning (the storyteller may say "so" there once the composer names the relation).
- **The layout** never gives an existing row the role `chain` (only a story row leads a chain).

## 4. The extraction against SPINE.md

The four pilot drafts of §4 are reproduced exactly (chains, links, shapes, attached rows, side notes), and the 17 composed chains are §4's link for link (tested in `tests/chains.test.mjs` B). §6.1 on the tables SPINE.md read (2.14.0 with the pilot merged, before the pages of B3 and B4: `--counts` on the merged tables also reads `shifted` and the recomposed `matter`, 31 pages and 166 sections), against SPINE.md's: 30 pages, 148 sections, 1,098 rows, 149 matrix lines and 36 attached rows are the same; three rules of the design, applied as written, move the rest:

| cause | where | effect |
|---|---|---|
| V5's twin: visible only in the other mode (the prototype took any b-row visible in one mode whose first line's visibility differs) | LNB-030b … LNB-037b (`steps/baez` · bz-persp: phys only, their first lines in both modes), LNC-050b (`steps/category` · cat-cube: math only, its first line in both) | positions, not twins: B2 swaps a twin in by `visibleTo`, which would hide a first line shown in the twin's mode |
| E2b for every split line (the prototype skipped a split line whose first line has a twin) | LNB-033c, LNB-034b, LNB-035c | with the line above: 8 chains in bz-persp (19 rows), 11 side notes fewer; bz-persp leaves §5.1's list of sections without a chain (13, not 14) |
| E4's tie by the earliest start in shownOn order (the prototype took the first in its topological order) | `light` · views: PAG-023 → CPL-010 and CPL-001 → CPL-010 | one chain more (CPL-001 alone) |

Totals: 198 chains (189 + 8 + 1), 758 rows in chains (739 + 19), 301 side notes (312 − 11), 337 singletons (348 − 11), 13 sections without a chain (14 − 1); without E2b 141 chains (140 + 1) and 567 singletons (558 + 8 + 1); 3 twins beside side notes (11 − 8). §6.2 (`--counts` prints it): waves 4 and 5 are the same; waves 2 and 6 differ by the causes above; wave 3 also holds the three rows B4 adds on `matter/help` · questions (FUR-038 … FUR-040: one section, three rows, three side notes, one section without a chain more). Joins: `rule.ideas.limit` and `cells.cards.limit` count GEN-023 → GEN-019 (an `equiv` recorded on GEN-023), 11 and 3 joins where SPINE.md §4 lists 10 and 2.

## 5. Left to the other owners

- **R7.** The budgets of D63 in `tests/shipped.test.mjs` (§9: after B1). `sh build.sh` before the dist comparisons: `tests/shipped.test.mjs` (content copies) and `tests/export.test.mjs` (the tuning folder now has `chains.jsonl`) fail on a `dist/` older than the content. `merge_chains.mjs --retire "2.15.0"` at the release (it moves drafts to `content/chains/retired.json`; the next `npm run content` drops them from `texts.json`). 02 §11 can be written from §2 of this file.
- **The owners of `tools/merge_explore.mjs` and `tools/merge_physics.mjs`.** Their text keys lack `chain`: between two merges, two spans of one row in two chains collapse in their output, and merge_story writes them back, so the pipeline stays idempotent (`tests/chains.test.mjs` D runs it twice with GEN-003 in two chains). Adding `+ (t.chain != null ? '|' + t.chain : '')` to their `textKey` makes it clean.
- **B3.** `src/figures/physics/ShiftedRadius.jsx` (with `content/stored_shifted.json`) prints 40 characters of ATY-064's research text outside a statement on `#/shifted` (the words rule of `tests/coverage.test.mjs`).
- **B4.** FUR-762's research text repeats 40 characters of the `furey` lens dictionary, which `#/lenses/furey` prints outside a statement (the same rule).
- **T3.** `node tools/check_learner_texts.mjs --explain <chain id>` is the worksheet; spans go in `content/chains/learner/<page key>.json`, one record per span plus the lead's learner text (§7's prompt). A chain with one span needs them all (C2, and V10 refuses a partial story).
- **B2.** The render checks of `tests/chains.test.mjs` F read the markup of `Chain.jsx` and `ChainStory.jsx` as they stand (`div.chain[data-chain]`, `ol.chain__list > li.chain__item`, `span.chain__rel[data-connective="chain"]`, `p.chain__story`, a mention's `statement--mention` with `a.statement__told`); `tests/coverage.test.mjs` exempts a statement marked `data-mention` from the lens reading line (D7: on the told position only).
