<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of Calibration 2: the storyteller on `matter` and `matter/papers` (round 14)

The storyteller of `docs/round14/STORY_ROUND.md` §7 (T3m) wrote the learner words of Furey's recomposed overview and of its papers sub-page, on B4's chain records (`content/chains/matter/chains.json`), story rows and research texts (`content/chains/matter/{rows,texts}.json`) and on the page entries of `content/story/furey.json`. **All seven chains of `matter` are storied; none is left out** (D54 applies to none). Every record has the shape of §2.2 (`lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@2026-10-17"`; the five human spans `status: "human"` with their human source, C10); `termsUsed` and `keptNumbers` are computed by the checker's own functions (`termsIn`, `requiredNumbers`), never typed.

| file | records | what |
|---|---:|---|
| `content/chains/learner/matter.json` | 94 | 49 spans of the 7 chains (47 told positions with the five twins, 2 mentions; 5 of them the human words of FUR-001 … FUR-005, C10); the chain leads FUR-751, FUR-752; the page lead FUR-701, the next line FUR-702, the section leads FUR-711 … FUR-716; 35 learner `full` texts: FUR-007 … FUR-037, the questions FUR-038 … FUR-040, the side note CAND-049 |
| `content/chains/learner/matter-papers.json` | 7 | the lead of the section `read`, FUR-717, and the six cards FUR-761 … FUR-766 |

INP-011 already has a learner `full` text (a translator draft) and gets none here (a second record would be R3's duplicate); its span in `fur-next` carries the status word its draft lacks ("inputs we bring in", C5). The twins FUR-001b … FUR-005b keep their translator drafts as their `full` texts (on `matter/model`); their spans are new words. FUR-006 has a *reviewed* learner text (`lead:L7-10`): not human, so C10 does not bind it; its span is those reviewed words shortened to fit the chain's budget (C7 left 4516 characters for ten records), and the reviewed text stays its `full` text everywhere else.

## The chains

| chain | shape | positions | mentions | lead | links (in order) | spans (human) | story / budget (C7) |
|---|---|---:|---:|---|---|---|---|
| `matter.fur-model.rebuilt` | fork | 6 + 4 twins | 0 | — | derives, order, derives, derives, derives·FUR-003 | 10 (4) | 4515 / 4516 |
| `matter.fur-fibre.fibre-base` | fork | 7 | 0 | — | order, derives, derives, derives, derives, derives·FUR-010 | 7 | 8484 / 8498 |
| `matter.fur-labels.cl6` | fork | 6 | 0 | FUR-751 | derives, derives, derives, derives·FUR-017, derives | 6 | 9540 / 9544 |
| `matter.fur-labels.roadmap` | line | 5 | 0 | FUR-752 | order, derives, derives, derives | 5 | 7676 / 7685 |
| `matter.fur-sixteen.weights` | fork | 7 | 0 | — | order, equiv, derives·FUR-020, derives·FUR-022, derives·FUR-020, derives·FUR-023 | 7 | 12384 / 12452 |
| `matter.fur-fields.mass` | fork | 5 | 0 | — | derives, derives·FUR-024, derives·FUR-025, derives·FUR-024 | 5 | 5958 / 6716 |
| `matter.fur-next.open` | fork | 8 + 1 twin | 2 | — | uses-input, uses-input·INP-011, derives, order, derives, uses-input·INP-011, derives | 9 (1) | 3890 / 5571 |

The openings follow C4 exactly: "So", "From the same …", "From the eight states …" on `derives` links; "The same sixteen …" on the one `equiv` link (FUR-022); "Given …", "Taking …" on the `uses-input` links of `fur-next` (FUR-014 and the two mentions); free openings with no derivation or contrast word on the five `order` links ("Under the blocks lies a finer grid", CAND-102; "Beside it, her fibre", FUR-008; "Beside them, the roadmap's algebra", FUR-028; "Beside it stands the compact cell", FUR-021; "Also not settled", FUR-005b). The weak links say their status in the span (C5): INP-011 an input ("inputs we bring in"), FUR-014 our reading, FUR-038, FUR-005b, FUR-039 and FUR-040 open ("stays open", "not settled", "not known here"). The human words of FUR-001 … FUR-005 stand verbatim (A63); the spans beside them carry the links (CAND-102 introduces the seven line blades and the 16 axes that FUR-003's "16 lanes" then names; FUR-006 continues "From the same seven blades"). The two mentions recall in one sentence, with no number: FUR-034 ("the turns of space and time and the compact turns become one algebra only once made complex") and FUR-026 ("two fibre momenta are two masses … which masses occur is an input").

The leads FUR-751 and FUR-752 hold no digit and no claim word, so they pass T1–T5 against their chains as narration (C6), at 250 and 292 characters.

## The story rows

- **FUR-701**, the page lead, in three movements from its research text and the stored learnerFrame: her results ("Furey reads one family of the Standard Model in the four number systems … her reading, recalled"), the Atlas's proven results ("On the switches the Atlas rebuilds her board …, her three ladders …, the five modes of her roadmap as five switches, space beside the inner switches, where the hand is a relative sign between two quarter-turns, the family of 16 …, waves whose inner motion is a mass"), the next steps ("What comes next is an input or open: which way of joining nature uses, how the turns of space and time meet the weak force, three families, and which inner motions occur"). It never says which product or split nature uses.
- **FUR-702**, the next line: the five tabs, then "Warm-up 3 follows: the delayed waves of Atiyah and Moore." (the learner name of Calibration 3 opens its sentence: R12 refuses "Warm-up" inside one, the research text naming "Calibration 3").
- **FUR-711 … FUR-716**, the section leads, each the research lead in the section's learner words, the status words kept (FUR-711 and FUR-714 "an input", FUR-716 "an input", "our reading", "open").
- **FUR-717 and the cards FUR-761 … FUR-766**: each card names the paper by its author(s) and year in parentheses and its arXiv number, says read in the original or "recalled, not read" (FUR-762, the thesis), what the paper builds in plain words, and what the switches rebuilt, naming the rows as other learner texts do ("(row FUR-015)"). The journal reference of FUR-761, "Phys. Lett. B 742", becomes "journal volume 742" (the lone letter B is a variable for R4, "Physics Letters" a new name for R12; the number is kept, R6); the script of FUR-765 is "her papers' check" (R13). The cards' order is the papers' order (2015, 2016, 2018, 2022, 2023, 2024).

## The full texts

FUR-007 … FUR-037 sit on `matter/model` (and some on `steps/coupling`, `steps/baez`, `steps/schuller`) outside a storied chain, and had no learner text anywhere: each `full` text is its span made to stand alone (the chain's opening replaced, e.g. "So her hand is the parity of a label." → "Her hand is the parity of a label.") with the clauses the chain's budget had left out put back (FUR-007, 009, 012, 015, 016, 019, 020). FUR-038 … FUR-040 begin "Open:" as their research texts do. CAND-049 (the doublet and the masses of the weak bosons) is the side note of `fur-model`, drawn under "More statements".

## The voice

The names of the earlier story round on these pages: the big board, its blocks, links and lanes (axes), the special key (her complex structure, a quarter-turn), switches (generators), labels, cells, grids (matrix algebras: "real 8 by 8 grids"), planes (bivectors), turns (the Lie algebras), the hand (chirality), ladders, the count (number operator), the vacuum, paired switches (Witt pairs), "her reading" for Furey's identifications, "recalled" and "not computed" where the rows say so. "Box" is left to the board's squares (the human texts' word) and not used for a cell, as the pilot pages do. No formula, no symbol as a variable, no Greek letter; cell and algebra names (Cl(1,9), so(10), su(3)) stay as names. The word "new" is not used (A60).

## What the budget cost

C7 (the story at most 0.8 of the research texts) and R6 (every number kept) together bound the dense rows of 2.12.0–2.14.0: five chains end within 1 % of their budgets. Every number, scope and status word of every told row is in its span; the results are all told; what was compressed is method detail, and a few clauses restated from a neighbouring row: the matrix cross-checks to "complex Pauli matrices agree" and the like; in FUR-012 the restated "each half is a complex 8, 2 times 4" (told in FUR-011); in FUR-019 "neither the vacuum with the single states nor the double states with the top state is kept"; in FUR-016 the sign of the other dagger; in FUR-028 the parenthesis on the other unit ("not −R_{ε₂}, which is −Γ₁₀"; "as the paper's v1 prints its eq. 27" stays) and the images of the volume element and of the complex unit; in FUR-034 the counts of pairs written as powers of two ("all pairs", "exactly the pairs whose labels both hold bit 0"). The `full` texts carry most of these back. FUR-032 keeps "the embedding of pass 10a", the only way to keep its number 10 (R6). If the owner wants every clause in the spans, the budget of these chains would need 0.9 (A64's spirit applied to C7).

## Verification

| step | result |
|---|---|
| `node tools/check_learner_texts.mjs` after each of the four pieces (chains 1–2; 3–4; 5–7 with the section leads; the story rows, cards and full texts) | PASS each time, at the first run, all 24 rules (R1–R13, C1–C11); last: 1449 records, "spans of matter 49" |
| `node tools/merge_chains.mjs --check` | 41 chains on 6 pages, 41 storied, 196 spans; no warning left on a matter row |
| `npm run content` | errors 0, warnings 0; chains 41 (41 storied, 196 spans), round-14 rows 53, learner texts 88 |
| `node tests/story/furey.test.mjs` | PASS (17 story rows through T4/T5, 3 questions, 20 of 20 broken copies caught) |
| `node tests/coverage.test.mjs` | PASS (2952 story paragraphs of statements only; no row words outside a statement) |
| `sh build.sh`, then Playwright on `#/matter?l=learner` (physics and mathematics), `#/matter/papers?l=learner`, 1366 px light and 390 px dark | 7 story paragraphs on `matter` (the twins' spans in mathematics), the 7 records of `read` on `matter/papers`; no horizontal overflow, no console error |
| `node tests/ui/chains.smoke.test.mjs` (B2) | PASS, 308 checks (part 4: every page with chains, `matter` among them, at both levels, 390 and 1366 px) |

Drafting ran the checker's own functions on these records alone before each write (C7 overruns on five chains, and single failures fixed in the drafts: R4 a brace in FUR-019, R7 a digit 15 that FUR-013's research writes as a word, R8 "not read" in FUR-001b, R12 "Warm-up" inside a sentence in FUR-702, C4 two openings on `derives` links in FUR-013 and FUR-036, C6 a lead of 305 characters in FUR-752); the written pieces were never rejected. `tests/chains.test.mjs` stops in part D on the defect INTEGRATION_NOTES.md records (the copy keeps the learner files), after parts A–C.
