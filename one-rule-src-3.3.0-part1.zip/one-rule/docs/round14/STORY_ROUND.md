<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Round 14: the story round — chains, the storyteller, two calibrations (release 2.15.0 and the waves after it)

The architect's design (A2) for the round that follows 2.14.0. Builders implement it after 2.14.0 ships; nothing here changes a table. The story spine of the pilot pages, extracted from the tables, is in `docs/round14/SPINE.md` beside this file.

**The owner's direction (17 Oct), followed exactly.**

1. "The Atiyah report on Shifted View should go in the Atlas to be browsed, as a section on its own, could be a step or could be a calibration." The lead's choice: a **calibration**, "Calibration 3: the shifted view (Atiyah and Moore)", route `shifted`, beside "Calibration 2: matter (Furey)" (`matter`): a calibration is a physics theory read through the Atlas; the steps are the mathematical ladder. "Follow the structure we thought before but with the latest results in mind … we follow the Atiyah paper's reasoning and we take it from there to all our proven results, adding also in the end the speculative readings not yet proven."
2. "Can't be a list of statements (these are important for an agentic AI), but must be a coherent logical story ('Octavo' view for human interface) … From the learner's stories, the mathematics and the physics behind should hold logically, not just as one statement alone but as chains of statements (chain of statements = a part of the story)." Hence a new content object, the **chain**, a story per chain whose sentences are the rows' learner texts, and the persona rewritten as the **storyteller**.
3. "The first page of Furey's calibration is the up-to-date view of the Atlas with her results, the Atlas proven results and the next steps readings." Hence `matter` recomposed as lead → picture → chains → fold.

**What was read, to design on what exists.** `docs/02_CONTENT_MODEL.md`, `09_TRANSLATION_PROTOCOL.md`, `LABELLING_SCHEME.md`, `DECISIONS.md` (D1–D50, A1–A58), `STORY_PLAN.md` (S1–S5, SL1–SL8), `STORY_REVIEW.md`, `LEARNER_TEXTS_story.md`, `07_ENGINES_FIGURES.md`; `docs/round9/SHIFTED_VIEW_NARRATIVE.md`, `docs/round12/PLAN.md` ("Not this round"), `docs/round13/PLAN.md` and `pass11a/`, `pass11b/` (FUR-027 … FUR-037); `public/reports/analyses/src/shifted_view.md` and `atiyah_lens.md`; `content/rows.json` (1,839 rows on 17 Oct 15:12, the rows of 2.14.0 included), `texts.json`, `pages.json`, `figures.json`, `lenses.json` (the `atiyah` lens: 107 dictionary entries, 302 readings), `check_runs.json`, `derived/status.json`, `story_frames.json`, `content/story/*.json` (rows, texts, layout, sections, chapters, landing, door, furey, ids, pending, review, merged); `tools/merge_story.mjs`, `merge_learner_texts.mjs`, `merge_physics.mjs`, `build_content.mjs`, `check_learner_texts.mjs` (R1–R13), `make_analysis.mjs`, `page_records.mjs`, `tools/migrate/story_from_v15.mjs` (the test T0–T5: `testBlock`, `testRow`); `src/pages/Page.jsx`, `PageView.jsx`, `Cells.jsx`, `Cell.jsx`; `src/components/Statement.jsx`, `Section.jsx`, `Lead.jsx`, `MoreFold.jsx`, `OpenFold.jsx`, `Hero.jsx`, `PageHeader.jsx`; `src/app/queries.js` (`buildPageModel`, `pageLead`, `cellCards`), `content.js` (`textFor`), `store.js` (`textKey`, `textRecord`), `vocab.js`, `lazyFigures.js`; `src/figures/index.js`, `extra.entry.js`, `physics/*`; `tests/coverage.test.mjs`, `shipped.test.mjs`, `logbook.test.mjs`, `figures.render.test.mjs`, `tests/story/*.test.mjs`, `tests/ui/story.smoke.test.mjs`; the logs of `checks/selfcheck/proofs/shifted_*.py` and `fibre_base.py`. Measured on `dist/` of 2.13.0: `app.js` 294.8 kB gzipped (budget 340), `figures-extra.js` 244.1 kB gzipped (budget 260), `app.css` 116.8 kB (budget 120), `dist/` 57.96 MB (budget 58); on R6's build of 2.14.0 (17 Oct, 15:50) the same, `dist/` 57.97 MB of a budget raised to 60 MB.

---

## 1. Decision record

Numbered after D50, the last taken; each is a proposal until the lead records it in `docs/DECISIONS.md` (R7 does, at the release). The owner's questions are §11.

| # | decision | where it is enforced |
|---|---|---|
| D51 | **A calibration, not a step.** The shifted view is "Calibration 3: the shifted view (Atiyah and Moore)", route `shifted`, after Calibration 2 and its five tabs in the reading order. Its rows keep their homes on the step pages (ATY-004 … ATY-011 and ATY-037 … ATY-047 on `steps/coupling`, ATY-010 and ATY-051 … ATY-053 on `steps/grav2`, ATY-054 and ATY-055 on `steps/projective`) and gain a placement on `shifted` with an order of 2000 or more, above every order of the tables (1792 on 17 Oct), so that no home moves. | `content/chains/shifted/page.json`, `tools/merge_story.mjs` (a moved home is refused), `tests/story/shifted.test.mjs` |
| D52 | **The chain is the unit of story.** A chain is an ordered set of *positions* of one page section, with a link between consecutive positions (its relation, taken from the rows' `depends` and `docs/LABELLING_SCHEME.md` §4, or `continues` from a split line's `splitFrom`, or `order` when the rows are only adjacent, or `contrasts`), a shape (line, fork, cycle, ladder), a status (its weakest link, computed), a title and an optional lead. A position is **told** (the row is placed in the section, and this is the one place on the page where it is told in full) or a **mention** (a row told in another chain of the same page, recalled here). A row is told at most once per page. | `content/chains.json` (merged), `tools/merge_chains.mjs` (V1–V10), `tests/chains.test.mjs` |
| D53 | **One story per chain, made of spans.** The learner-level story of a chain is its lead's learner text followed by one *span* per position; a span is a text record of its row with the fields `chain` and `span` (register `span`), so the coverage invariant — every rendered statement is a text record of its row — holds unchanged. A told span obeys R1–R13; a mention's span obeys the short register's rules (D21: it may say less than its row, never more). No sentence of a story lies outside a span except the chain's lead, which is a story row. | `content/chains/learner/*.json`, `tools/check_learner_texts.mjs` (C1–C11), `tests/coverage.test.mjs` |
| D54 | **The old learner drafts stay until a story replaces them.** `textFor` gains `chain`: at learner level inside a chain it looks for the span of (row, chain), then falls back to the row's learner `full` text, then to nothing (02 §2's fallback is unchanged within each register). A chain whose story is not complete renders as the list of its rows, each in its old words. A wave retires the drafts of the rows whose every placement is told in a storied chain (moved to `content/chains/retired.json`, never deleted). The human learner texts (v15's and the story round's paired ones) are never retired: a told span of a row with a human learner text *is* that text (§3.2, C10). | `src/app/content.js`, `src/app/store.js`, `tools/merge_chains.mjs --retire` |
| D55 | **What the research level shows.** A chain renders its statements in chain order — never sorted by mode or lens inside a chain — each preceded by the connective word of its link (vocab `CHAIN_WORDS`, ≤ 24 characters, in the connective budget); a mention as a compact folded statement with "told in <section>"; the chain title as a small heading; the lead story row first. Rows of the section in no chain follow as today (key results, "More statements"). The page record and the tuning export carry the chains (positions, links, shapes, statuses) beside the rows: the agent's view keeps every statement, the reader's view tells the story. | `src/components/Chain.jsx`, `src/app/queries.js`, `tools/page_records.mjs` (through `pageRecord`) |
| D56 | **Badges unchanged.** Status stays computed, never typed; one badge at most per statement, spans included (a span carries its row's badge inline, exactly where the status has one); `proved-by-atlas`, `standard` and `meta` carry none. The chain's weakest link is named in its title line as a status word, not as a badge. | `tests/coverage.test.mjs` (unchanged rule, applied to spans) |
| D57 | **An open link stays in its chain.** An open row inside a chain renders in place with its badge (the chain is a logical unit and its status says so); the page's open fold lists the open rows in no chain and names by title the chains whose weakest link is open. | `src/components/OpenFold.jsx`, `src/app/queries.js` |
| D58 | **The persona is the storyteller** (09 §2 rewritten, §7 here): it knows the spine and writes chains, not rows; its words are drafts (`source: "storyteller@<date>"`), checked by R1–R13 per span and C1–C11 per chain, reviewed by the owner (`reviewed`), never produced live. | `docs/09_TRANSLATION_PROTOCOL.md` §2 (R7 edits), `tools/check_learner_texts.mjs` |
| D59 | **One merge, one bookkeeping.** The chains overlay (`content/chains/`) is merged inside `tools/merge_story.mjs`, through the module `tools/merge_chains.mjs`, and recorded in the same `content/story/merged.json`. Two merges that each restore and re-write the same pages drift (each sees the other's writes as its base); one book does not. `merge_chains.mjs` keeps a CLI (`--check`, `--retire`). | `tools/merge_story.mjs`, `tools/merge_chains.mjs`, `package.json` |
| D60 | **The story rows of round 14** (page leads, intro paragraphs, next lines, section leads, chain leads, the paper cards of `matter/papers`): kind `story`, notions `["i-meta"]`, no evidence, `since: "v2.15"`, ids `<GROUP>-701 … 799` of the page's group (ATY for `shifted`, FUR for the Furey pages, the row group for the pilot chains), one placement; their research and learner texts are drafts; each passes the story test T1–T5 (`STORY_PLAN.md` §1.4) against the rows of its chain (a chain lead) or of its section (a section lead; the page for the intro), with `restates` naming them. The v15 story rows keep every rule of §1.6 (`since: "v2.2"`, the human record of their locator). | `tools/merge_chains.mjs`, `tests/chains.test.mjs`, `tests/story/migration.test.mjs` (part C scoped to v15 story rows) |
| D61 | **Readings and open items a fold must badge are rows.** Where a calibration's last section names a reading or an open item no row states, it becomes a row of kind `reading` (status ours) or `question` (status open): ATY-056 … ATY-065 for `shifted`, FUR-038 … FUR-040 for `matter` (SPINE.md §2.3, §3.3), `since: "v2.15"`, no evidence, `depends` on the rows it rests on, its research text taken near-verbatim from `shifted_view.md` ("Taken forward", "The three questions", "What this reading does not do") or from "What is still open" of the release notes, with that locator as `source`. The owner accepts them before 2.15.0 ships (the D45 gate; question A59). | `content/chains/shifted/rows.json`, `content/chains/matter/rows.json` |
| D62 | **Six figures, their data.** Five for `shifted` and one for `matter` (§6.3). The shifted scripts write no json, so their stored output is their logs (D11): `tools/story/stored_shifted.mjs` writes `content/stored_shifted.json` from the `ok` lines of `checks/selfcheck/proofs/logs/shifted_{dirac,energy,einstein}.log` (each value with its check id and its line, verbatim), tested equal to the logs, loaded on demand (D34's pattern extended to logs). The fibre-and-base figure is drawn from the kernel alone and tied in a test to `fibre_base.py`'s `fb.CHI` lines. Seeds in `content/physics/figures.p12.json` (B3) and `figures.p13.json` (B4), registries `src/figures/physics/p12.js` and `p13.js`, merged by `tools/merge_physics.mjs` unchanged. | `tools/story/stored_shifted.mjs`, `tests/physics/p12.test.mjs`, `p13.test.mjs` |
| D63 | **Budgets** (measured on 2.13.0 and again on R6's build of 2.14.0, the same sizes, §10): `figures-extra.js` has 15.9 kB gzipped left and six figures need about 15–20 kB: raise its budget to 300 kB (D47 amended), the calibrations' own chunk deferred to wave 2; `app.css` has 3.2 kB left: the chain styles stay under 2.5 kB and the six figures add no stylesheet (else raise to 128 kB); `dist/` holds 57.97 MB of the 60 MB that 2.14.0 sets, and the round adds about 0.7 MB: no raise in wave 1 (62 MB when a later wave needs it). `app.js` keeps 340 kB (45 kB left; the chain components cost about 5 kB). | `tests/shipped.test.mjs` (`BUDGET`) |
| D64 | **Staging.** Wave 1 (2.15.0): the machinery, the two calibrations, the pilot chains. Waves 2–6 (2.16.0 … 2.20.0): the steps 1–20 chapter by chapter, each converting its chapters and retiring their drafts. The last wave is 3.0.0: no learner text in a chain falls back to an old draft, every side note has the storyteller's text, the old translator persona is retired. | §8 |

What does not change: D1 (one kernel), D2 (statements are rows; a span is a row's text record), D3/D4 (status computed; read is not ran), D5 (no formula at learner level), D7 (lens readings are shown under a statement, never in its place — at learner level inside a story too, on the told position only), D11 (checks unchanged), D26/D29 (the printing rule and the physics names), D37 (the Atlas method on every figure with a ladder), D40–D50 (the story overlay, its roles, its gate). No row changes status, no home moves, no existing text is edited.

---

## 2. The content model additions

02 gains §11 "Chains" (R7 writes it from this section); §1, §2 and §7 gain the fields below. **The chain record (§2.1), the span record (§2.2) and the section field (§2.3) are the interface between all the builders of §9**: none of them changes a field name without a new version of this document.

### 2.1 `content/chains.json` — the chain record

The shipped table, written by `tools/merge_chains.mjs` from the owners' files (§2.6), sorted by page, section, order; fetched as a table like `pages` (about 25 kB for wave 1).

```jsonc
{
  "id": "shifted.sv-3.shift",          // <page key>.<section>.<slug>; page key = the route with "/" as "-" ("steps-coupling"); a slug, never a position, so a reorder keeps the spans
  "page": "shifted",
  "section": "sv-3",                   // a section of the page after the merge (never intro, top-notes or an inputs section)
  "order": 1,                          // its place among the section's chains (1, 2, …), unique in the section
  "title": {                           // a name: ≤ 60 characters, no claim word of T2, no final period; learner: no formula mark (R4)
    "phys": "One shift: a retard and an advance",
    "math": "The exponential of the Dirac operator as a right factor",
    "learner": "One delay that waits forward and backward"
  },
  "lead": null,                        // a story row of role "chain" placed in the same section (§2.4), or null
  "rows": ["ATY-004", "ATY-005", "ATY-006", "ATY-011", "ATY-041"],   // the positions, in story order
  "mention": ["ATY-005"],              // the positions told in another chain of the same page (here: shifted.sv-4.lattice)
  "twins": {},                         // a position's row → its twin, the b-row split from it and visible in the other mode only ({"FUR-001": "FUR-001b"})
  "joins": [],                         // edges from a row of an earlier chain of the same page to a position here ({"from": "ATY-005", "to": "ATY-011", "rel": "derives"}): "continues from"
  "links": [                           // rows.length − 1 links; links[i] joins rows[i] and rows[i+1]
    { "rel": "derives" },              // ATY-005 rests on ATY-004 (dir "fwd", the default: the later position rests on the earlier)
    { "rel": "derives" },              // ATY-006 rests on ATY-005
    { "rel": "derives", "from": "ATY-005" },   // ATY-011 rests on ATY-005, not on ATY-006: a branch
    { "rel": "instance" }              // ATY-041 is an instance of ATY-011
  ],
  "shape": "fork",                     // line | fork | cycle | ladder
  "extracted": { "tool": "extract_chains", "component": 2, "departures": ["mention ATY-005 added"] },   // the mechanical draft it came from, and every change the composer made
  "story": "draft"                     // none | draft | reviewed — written by merge_chains: "draft" when every position has a span and the lead a learner text
}
```

| field | rule |
|---|---|
| `links[].rel` | from `depends` (LABELLING_SCHEME §4): `derives`, `instance`, `uses-input`, `equiv`, `cycle`, each backed by a `depends` edge between the two positions, or between the later position and `from`; `continues`, backed by `splitFrom`: a line split from the previous position's row (02 §1 asked for an `equiv` or `derives` edge to the first line; the migration recorded only `splitFrom`, on all 248 split lines); or chain-only: `order` (adjacent, no edge: the rows sit side by side, nothing derives) and `contrasts` (no edge; `note` required, naming what is set against what). `contradicts` never stands in a chain (A6: it is to be resolved). |
| `links[].dir` | `fwd` (default): the later position rests on the earlier, or on `from`; `back`: the earlier rests on the later (an input placed after the row that uses it). |
| `links[].from` | an earlier position than the previous one, on which the later rests: the link is a branch (a fork) or a join. |
| `joins` | optional, default `[]`: `depends` edges from a row told in an earlier chain of the same page (another section included) to a position of this chain, as the extraction finds them (E9); each backed by an edge (V3). The chain's title line then says "Continues from <that chain's title>" (a connective link). On the pages of today more `depends` edges join two sections of one page (874) than stay inside a section (656): `joins` keeps those links visible while chains stay inside their section. |
| `shape` | in this order: `cycle` when a `cycle` edge of `depends` joins two of its positions (a link or not); `ladder` when every position's row has a cell (p,q,r) and the largest n = p + q + r among each row's `cells` climbs, or descends, strictly along the chain, whatever its links (the rhythm of D37; today only the genesis, SPINE.md §4.1); `fork` when a link has `from`; `line` otherwise (an `order` link keeps a line). Checked against `depends` and the links (V6). |
| status | **not stored**: `chainStatus(chain)` is the weakest computed status among its rows and twins, in the order open > cited (not yet proved here) > ours > input > standard and proved-by-atlas (LABELLING_SCHEME §6's badge priority); a pure function in `src/app/queries.js`, tested against `content/derived/status.json`. |

### 2.2 The span — a text record with `chain` and `span`

```jsonc
{ "row": "ATY-011", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "span",
  "chain": "shifted.sv-3.shift", "span": 4,
  "body": "From the same shift comes a second reason, our reading and not computed: a move in space and time is undone by the same move backwards (recalled), so a delayed term in an action brings an advanced one with it.",
  "status": "draft", "source": "storyteller@2026-10-20", "termsUsed": [], "keptNumbers": [] }
```

- `register: "span"` is the fourth register of 02 §2 (full | short | caption | span); `span` is the 1-based position in the chain; `mode` is `both`, or the mode of a twin's row.
- **The text key** becomes (row, lang, level, mode, lens, register, chain) wherever a key is built: `src/app/store.js` `textKey`, `tools/merge_story.mjs` `textKey`, `tools/merge_learner_texts.mjs` `key`, the R3 key of `tools/check_learner_texts.mjs`, `tools/build_content.mjs` (its research and learner maps skip span records). A record without `chain` keys as before, so no existing record changes key.
- The span of a mention is `register: "span"` too; the checker reads from the chain record that the position is a mention (C8).
- The lead's learner text is the lead story row's own learner `full` text; it is the story's first sentence.

### 2.3 The page section field `chains`

`pages.json` sections gain `"chains": ["shifted.sv-3.shift", …]` (the section's chains in order), written by `merge_chains` from the chain records and never typed in a page entry; a section with chains still has its `query`, `lead`, `figure`, `key`. An added top-level page (the overlay entry's `page`, for a route not in `pages.json`) gains `after` (the route it follows in the reading order; today an added page without a parent lands at the end), `needs`, `stepNo: null` and `learnerFrame`. `ROLES` (`tools/build_content.mjs`, `tools/merge_story.mjs`, `src/app/vocab.js`) gains `chain`: a story row that leads a chain, drawn only by its chain, never among key results or in "More statements".

### 2.4 The story row as the chain's lead, and the other round-14 story rows

```jsonc
{ "id": "ATY-751", "group": "ATY", "kind": "story", "stage": "M", "ptype": null, "notions": ["i-meta"],
  "fields": [], "phenomena": [], "cells": [], "homePhys": "", "homeMath": "", "standardRef": null, "evidence": [],
  "depends": [{ "id": "ATY-037", "rel": "restates" }, { "id": "ATY-038", "rel": "restates" }, { "id": "ATY-039", "rel": "restates" }],
  "links": [], "lensTags": [], "legacyFlags": [], "legacyLines": 0, "legacyLabel": "story", "legacyKnown": false,
  "since": "v2.15", "tabV15": null, "anchorV15": null, "source": "round14:B3",
  "shownOn": [{ "page": "shifted", "section": "sv-5", "order": 1, "role": "chain" }],
  "visibleTo": ["phys", "math"], "review": null, "notesPersona": [], "theorems": [], "readingRefs": 0, "v16": [], "splitFrom": null, "labelFrom": null }
```

Ids: `<GROUP>-701 … 709` page level (the page lead, intro paragraphs, the next line), `711 … 749` section leads (role `lead`, order 0), `751 … 799` chain leads (role `chain`) and the paper cards of `matter/papers` (role `result`). Free on 17 Oct: ATY-501 … 999 (no ATY story row exists), FUR-641 … 999 (FUR-501 … 640 taken by v15 locators), GEN-522 …, CPL-510 …, LNB-550 …; `merge_chains` refuses an id that `content/story/ids.json` or `pending.json` reserves. Texts: a research `full` text (status `draft`, `source: "round14:<owner>"`, written by the page's builder) and a learner `full` text (status `draft`, `source: "storyteller@<date>"`, written by T3).

### 2.5 The new statement rows (D61)

The shape of 02 §1, `since: "v2.15"`, `evidence: []`, `kind` reading or question, `stage` and `ptype` of their topic (`reading` or `open`), `notions` labelled by the builder under LABELLING_SCHEME §1 (an item that rests on an input carries its `i-…` notion), `depends` (`derives` to the rows it rests on, `uses-input` to an input row), `cells` of the rows it rests on, `homePhys`/`homeMath` "", `standardRef` the paper where one is named, one placement (its home: the calibration page). The research text is the locator's words, edited only to stand alone, with `source` the locator (`"shifted_view.md#step-6c.taken-forward.1"`, `"RELEASE_NOTES_v2.14.md#still-open.9"`). Status computed: `ours` (badge "our reading") or `open` (badge "open"). `NEW_SINCE` gains `v2.15` (no badge "new" shows on them: open and ours take priority).

### 2.6 The overlay files and who writes them

| file | holds | owner |
|---|---|---|
| `content/chains.json` | the merged chain records (shipped) | generated by `merge_chains` |
| `content/chains/pilot/chains.json` | the chains of `rule` · ideas, `cells` · cards, `steps/coupling` · eq-coupling (ATY, FUR), `steps/baez` · bz-generation (ATY, FUR, CAND) | B1 |
| `content/chains/shifted/{chains,rows,texts}.json` | the 17 chains; the story rows ATY-701 … and the rows ATY-056 … ATY-065; their research texts | B3 |
| `content/chains/shifted/page.json` | `{ "pages": [the shifted entry], "layout": [the placements of its told rows] }` | B3 |
| `content/chains/matter/{chains,rows,texts}.json` | the 7 chains; the story rows FUR-701 … (paper cards included) and FUR-038 … FUR-040; their research texts | B4 |
| `content/story/furey.json` | the entries `matter` and `matter/papers` recomposed, and their layout | B4 |
| `content/chains/learner/<page key>.json` | the spans and the learner texts of the round-14 rows, one file per page | T3 |
| `content/chains/retired.json` | the learner drafts a wave retired, with the wave | R7 (`merge_chains --retire`) |
| `content/stored_shifted.json` | the stored blocks of the shifted figures (D62) | B3 (`tools/story/stored_shifted.mjs`) |
| `content/physics/figures.p12.json` · `figures.p13.json` | the seeds of the five shifted figures · of `fibre-base` | B3 · B4 |

Precedence of page entries: `content/story/sections.json` → `chapters.json` → `furey.json` → `content/chains/*/page.json` (folders sorted), later wins, as `STORY_PLAN.md` §3.2.

### 2.7 Placements

- A told row on a page that is not its home: a layout entry with `add: true`, `role: "result"`, order ≥ 2000. The orders of `shifted` are 2000 + 100·k + i (k the section, i the position): above 1792, the highest order of the tables, so the home (the entry of lowest order) never moves.
- A told row moved into a chain's section on its own page (the FUR rows of `matter`): a layout entry on the same page, **its order unchanged**, the new section: chains carry their own order, so no row is renumbered (renumbering FUR-013 on `matter` from 29 to above 30 would move its home to `steps/coupling`).
- A mention: no placement; the chain record names it.
- Story rows and the new rows carry their own `shownOn`.

### 2.8 The figure seeds

```jsonc
{ "id": "shifted-shells", "engine": "engines/physics/shifted.js#shells", "params": { "m": 3, "kappa": 2 },
  "inputs": ["content/stored_shifted.json#qnt"], "captionRow": "ATY-005", "statesRows": ["ATY-005", "ATY-009"],
  "lenses": [], "learner": true, "size": "wide",
  "interactive": [
    { "param": "case", "control": "chips", "values": "the stored cases of shd·QNT: (m, κ) = (3, 2), (1, 4)", "default": 0, "levels": ["research", "learner"], "from": "round 14: the stored cases of the quantization" },
    { "param": "n", "control": "stepper", "values": [0, 1, 2, 3], "default": 0, "levels": ["research", "learner"], "from": "D37" } ],
  "portFrom": null, "portOrder": null }
```

`from` names the origin of a control (`figures.render.test.mjs` accepts `D37` or a description of more than five characters); no slider at learner level (D18); a figure prints only numbers its stored block or the kernel gives (D26, D29). The six seeds are listed in §6.3.

---

## 3. The tools

### 3.1 `tools/story/extract_chains.mjs` — the mechanical extraction (B1)

A prototype ran for this design (read-only; its output is `docs/round14/SPINE.md`). The rules:

| # | rule |
|---|---|
| E1 | The rows of a page section: its `shownOn` entries of role `result` or `detail` (story rows and the roles lead, caption, next, learner, evidence, note left out; the sections intro, top-notes and the inputs sections left out; the 149 translation-matrix lines left out, D35: a table is not a story), in `shownOn` order, then by id. A math twin (a b-row split from a row of the section and visible only in the other mode) rides with its parent as one position (`twins`). `--groups ATY,FUR` restricts the rows (the pilot). |
| E2 | The induced subgraph of `depends`: an edge d → r when r depends on d by `derives`, `instance` or `uses-input`; `equiv`, `cycle` and `contradicts` undirected. **E2b**: a line split from a row of the section (`splitFrom`, a twin apart) is joined to it by `continues`, undirected. Without E2b, 558 of the 1,098 placements are singletons; with it, 348 (SPINE.md §1). |
| E3 | Weakly connected components; in each, the transitive reduction H of the directed edges. A directed cycle (seven exist in the tables, SPINE.md §5) is broken at its earliest row and reported. |
| E4 | A greedy path cover of H: the longest path (ties: the earliest start in `shownOn` order) is a chain, its rows leave, repeat. A path longer than MAX (8) is cut into ⌈length / MAX⌉ nearly equal pieces, never into MAX and a stub. A remainder of the cover of one or two rows joins the chain it hangs from, as a branch, while that chain stays within MAX + 2. |
| E5 | The link between consecutive positions: the relation of the edge between them (`dir` fwd or back), else the relation to the nearest earlier position the later one rests on (`from`), else `order`. |
| E6 | The shape: cycle, ladder, fork or line by §2.1's rule. |
| E7 | The status: the weakest computed status of the chain (§2.1); `content/derived/status.json`, else the build's rule for a row it lacks. |
| E8 | A singleton (a component of one row) is attached to a chain of the section that shares with it a dependency outside the section — never an input (a shared input does not link, LABELLING_SCHEME §2) and never a hub (a row the section's rows depend on more than three times: T4 links nothing) — else to a chain holding a labelling neighbour (Hamming distance 1, `status.json` neighbours), else it is a side note. |
| E9 | The joins: the edges of H between two chains of a section ("hangs from"), printed for the composer. |

Usage: `node tools/story/extract_chains.mjs --page <route> [--section <id>] [--groups A,B] [--max 8] [--json]` prints the draft chains; `--into content/chains/<owner>/chains.json` adds the draft chains of the sections that have none yet (a composed chain is never overwritten); `--diff content/chains/<owner>/chains.json` lists every departure of the composed chains from the mechanical draft (a position added, removed or moved, a mention, a link changed from `order` to `contrasts`, a title), which the composer records in `extracted.departures` and the owner can review; `--counts` prints the table of SPINE.md §6. Deterministic: two runs give the same bytes.

### 3.2 The storyteller's rules, in `tools/check_learner_texts.mjs` (B1)

The checker also reads `content/chains/learner/*.json` and the chain records of `content/chains/*/chains.json` (with the rows and their statuses), and applies R1–R13 to every record with these changes: R1 accepts a span (the keys of R1 plus `chain` and `span`, `register: "span"`, `source: "storyteller@…"`) and a learner text of a round-14 row (`register: "full"`, `source: "storyteller@…"`); R2 lets a span stand beside a human learner text (another key; C10 decides its words); R3's key holds `chain`; a mention's span takes the short register's rules (R6 replaced by R7, R9 20 to 300 characters). Then the chain rules:

| # | rule |
|---|---|
| C1 | **chain** — `chain` names a chain of the owners' files and `span` one of its positions; the record's row is that position's row or its twin. |
| C2 | **coverage** — a chain with one span has a span for every position and every twin, and its lead a learner text: no partial story. |
| C3 | **order** — the spans of a chain are numbered 1 … n with its positions, one per position (one per twin), no gap and no duplicate. |
| C4 | **connective** — span i ≥ 2 opens with a word of its link's set: `derives` *so, hence, thus, therefore, this means, it follows, from this, from the, because of this, as a result, which gives, which is why*; `instance` *for instance, for example, in one case, a case of this, take*; `equiv` *in other words, put another way, the same, that is, equally*; `uses-input` *given, once we choose, if we choose, with the input, taking*; `cycle` *and back, in turn, closing the loop*; `continues` *and, also, more precisely, in the same statement*; `contrasts` *but, by contrast, on the other hand, yet, unlike*; a `back` link *this rests on, that needs, it comes from, behind this*. An `order` link opens freely but never with a word of the `derives` or `contrasts` sets: **no unearned "so"** — the story's logical words are the `depends` graph's. "Then" is a sequence word, not a derivation word (the lead's ruling of round 15, D65): an `order` link may open with "then" or "next", a `derives` link may not. |
| C5 | **status at the weak links** — a span of a row whose status is `ours`, `open`, `cited` or `input` carries the learner word of that status (*our reading* / *ours*; *open* / *not known yet* / *not settled*; *not yet proved here*; *input* / *needs an input* / *a choice*); a span of a proved row carries none of these words unless its research text does (no status moves in either direction). |
| C6 | **lead** — the lead's learner text is at most 300 characters, holds no number in digits that no position's research text holds, and passes T1–T5 (`testBlock` of `tools/migrate/story_from_v15.mjs`) against the chain's rows. |
| C7 | **budget** — the story (lead and spans) is at most 0.8 × the summed research texts of its positions (told and mentioned); a told span keeps R9 (40 to 900 characters, or 1.5 × its research text when that is longer). |
| C8 | **mention** — a mention's span (20 to 300 characters) holds no number in digits that its row lacks and keeps its row's status word (C5). |
| C9 | **no sentence outside** — no span for a row outside its chain, no learner record with `chain` and without `span`. |
| C10 | **human words** — a told position whose row has a human learner text takes that text verbatim as its span (status `human`, the human text's `source`); C4 is waived there and the neighbouring spans carry the connection. A new span in its place needs the owner's choice (A63). |
| C11 | **twins** — a twin's span has its row's mode; the two spans of a position share its number. |

The self-test plants one failure per C-rule (a missing span, two spans out of order, an unearned "So" on an `order` link, "our reading" dropped at a reading, a mention with a new number, a lead with a number of its own, a story over budget, a span for a row outside the chain, a twin without its span, a human text paraphrased) and a good chain that passes, as `selftest()` does for R1–R13. `--explain <chain id>` prints, per position, its link, the words C4 allows, the status word C5 asks for and the numbers R6 asks for: the storyteller's worksheet.

### 3.3 `tools/merge_chains.mjs` — chains into rows, texts and pages (B1)

A module, `mergeChains(tables, overlay) → { rows, texts, pages, chains, errors, warnings }`, which `tools/merge_story.mjs` calls inside `mergeStory` (D59): after its story rows (step 1) it adds the round-14 rows; after its texts (step 2) the research drafts, the spans and the learner texts; its page entries and layout join the files of step 4 as the last precedence; after step 4 it validates the chains and writes each section's `chains`; its writes enter the same book (`content/story/merged.json`), so a second run restores and gives the same bytes. Its CLI:

- `node tools/merge_chains.mjs --check` — what a merge would do, exit 1 on an error; `npm run content` runs it right after `check_learner_texts.mjs`.
- `node tools/merge_chains.mjs --retire "<wave>"` — moves the translator drafts (status draft or reviewed, `source: "translator:…"`) of the rows whose every placement is a told position of a storied chain from `content/texts_learner*.json` into `content/chains/retired.json`, with the wave; human texts untouched; idempotent. R7 runs it at a wave's release.

Refused (nothing written), each with its record:

| # | rule |
|---|---|
| V1 | a chain id unique and of the form of §2.1; its page and section exist after the page entries; not intro, top-notes or an inputs section |
| V2 | every told position placed in its (page, section) with role result or detail; every mention told in another chain of the same page; a row told in at most one chain per page |
| V3 | links: one fewer than the positions; a relation of §2.1; a `depends` relation backed by an edge in the stated direction (or from `from`, an earlier position); `continues` backed by `splitFrom`; `contrasts` with a `note`; no `contradicts` |
| V4 | the lead null, or a story row of role `chain` in the same section, whose `restates` name rows of the chain |
| V5 | a twin is the b-row split from its position's row, visible only in the other mode |
| V6 | the shape agrees with the links |
| V7 | the title a name (phys and learner present; ≤ 60 characters, no claim word, no final period; no formula mark at learner level) |
| V8 | the orders unique in a section |
| V9 | a round-14 story row: D60's record (kind, notions, no evidence, `since: "v2.15"`, an id 701–799 of its group not reserved by `ids.json` or `pending.json`, one placement, research and learner texts, T4/T5 against its chain or section); a new statement row: §2.5's record; a moved home refused (merge_story's rule) |
| V10 | spans: C2, C3 and C11 again (a partial story is never merged); a span of a human-text row equal to that text (C10) |

### 3.4 `tools/build_content.mjs` (B1)

Validation: the references of `content/chains.json` (rows, pages, sections, leads) and of every text record with `chain` (an existing chain and position); `ROLES` with `chain`; `NEW_SINCE` with `v2.15`. The coverage report (`docs/COVERAGE.md`) gains per page: chains, storied chains, spans, side notes.

### 3.5 `tools/story/stored_shifted.mjs` (B3, D62)

Writes `content/stored_shifted.json`: blocks `qnt` (`shd·QNT`), `bil` (`shd·BIL`), `beat` (`en·BEAT`), `ser`, `low`, `zero` (`se.SER`, `se.LOW`, `se.ZERO`), `ds5`, `time` (`se.DS5`, `se.TIME`), each `{ check, log, lines: [the ok lines, verbatim], values }` with the values parsed by an explicit pattern per block (no general parser: an unparsed line fails the tool); `--check` exits 1 when the table differs from the logs. The figures import neither the logs nor the kernel's signs (D1); they read the table through `useTable('stored_shifted')` and draw "loading the stored results" meanwhile (D34).

---

## 4. The renderer (B2)

One new component family, a chain-aware `textFor`, and the section's slot for chains; **nothing else moves** (the page top, the hero and its "How do we know?", the two ways, "At a glance", the inputs fold, the record fold, PrevNext, SubNav, the door, Ask).

1. **Data.** `src/app/store.js`: `textKey` with `chain`; the text index keys spans by chain; `chainsById()` and `chainsOf(route, section)` from the table `chains`, which the app loads with `pages`, `rows`, `texts` and `derived_status`.
2. **`textFor(rowId, { mode, level, lens, register, chain })`** (`src/app/content.js`): at learner level with `chain`, the span of (row, chain) through 02 §2's mode and lens fallback, then the row's learner `full` text, then null (D54); at research level `chain` is ignored. The fallback is the only one; `textFor` still never crosses levels.
3. **The page model** (`src/app/queries.js`, `buildPageModel`): per section `chains: [{ id, title, lead, positions: [{ id, mention, link, twinOf }], shape, status, storied }]` — a twin swapped in by `visibleTo`, a position not visible in the mode skipped with its link handed on; the told rows leave `key`, `more`, `body` and the open rows of the section; `rowSection` and `place` register the told positions (deep links and drawers), never the mentions; `chainStatus(chain)` (§2.1); `storied` when every visible position has its span and the lead its learner text; `open` gains `openChains` (D57); `pageRecord(route)` gains `chains` (id, title, rows, mention, links, shape, status) — the agents' view (D55). Chains are placed by role and never sorted; `sortEntries` is untouched.
4. **`src/app/vocab.js`**: `CHAIN_WORDS` (research connectives, each ≤ 24 characters): derives "So" · derives from an earlier position "From ATY-005" (the id) · instance "A case of it" · equiv "Equivalently" · uses-input "With an input" · cycle "And back" · continues "And" · contrasts "By contrast" · order "Beside it" · back "It rests on"; `CHAIN_LABELS`: "Told in", "Continues from", and the title line's status word "Weakest link:" followed by the computed badge word of the weakest row ("open", "not yet proved here", "our reading", "needs an input"; nothing when every link is proved).
5. **`src/components/Statement.jsx`**: a prop `chain` (passed to `textFor`, written as `data-chain`); `variant="span"` — inline markup (`span.statement.statement--span` with `span.statement__text` and an inline `statement__meta`), focusable, Enter or a click opens the row's drawer where `ctx.hasDrawer(id)`, the anchor `row-<id>` only on a told position, the badge as now, a lens reading (D7) inside the span's element, after its text, as a small inline chip; `variant="mention"` — the compact statement folded to two lines ("Show all"), with a link "Told in <section label>" to `at=<id>`, no anchor. The badge rule and the "no children" rule are unchanged.
6. **`src/components/Chain.jsx`** (new): the title line (`h3`, or `h4` inside a part; `data-chain`; the weakest-link word as `[data-connective="chain-status"]`; "Continues from <title>" as a connective link when the chain has `joins`); at research level the lead (`Lead` variant `chain`) then `ol.chain__list`, each item `span.chain__rel[data-connective="chain"]` + a block `Statement` (a mention: the mention variant); at learner level `ChainStory` when `storied`, else the same list without connective words, each row in its learner `full` text (D54's fallback).
7. **`src/components/ChainStory.jsx`** (new): one `p.chain__story[data-chain]` holding, in order, the lead's learner text and the spans, each a `Statement variant="span"`; no other text node in the paragraph.
8. **`src/components/Section.jsx`**: a composed section draws lead → figure blocks (captions, try line) → **chains** → key results → "More statements"; a section with two chains or more shows their titles under its lead as anchors (`.sec__chains`, a connective line: the path through the section); a custom section (the cells' lattice) draws its body, then its chains, then its drawer. The drawer lists the told positions with the other statements.
9. **`src/components/OpenFold.jsx`**: the open rows in no chain, as now, and one line per chain whose weakest link is open ("<title> · <section>", a link).
10. **`src/pages/PageView.jsx`**: the reading order (the glossary's first-use rule) walks the chains in place; `at=<row>` scrolls to the told position.
11. **`src/styles/chains.css`** (new, under 2.5 kB, tokens only, light and dark through the tokens): `.chain`, `.chain__title`, `.chain__status`, `.chain__list`, `.chain__rel`, `.chain__story`, `.statement--span`, `.statement--mention`, `.sec__chains`.
12. **The chunk** (D63): the six figures register in `src/figures/physics/p12.js` (B3) and `p13.js` (B4); B2 adds the two lines to `src/figures/physics/index.js`, so they ride in `figures-extra.js`.

At learner level a section reads: learner title → its lead (the paper's move, in plain words) → the picture with its learner captions and try line → each chain: its learner title, then its story as one paragraph, the badges inline at the weak links, every sentence opening the drawer of its row → the side notes (rows in no chain, in their own learner words) → "More statements (n)". At research level: title → lead → figure → each chain: title and weakest-link word, its lead, its statements in order with their connectives → side notes as key results → "More statements (n)" → the drawer.

---

## 5. The tests

| test | owner | what it asserts |
|---|---|---|
| `tests/coverage.test.mjs` (edit) | B1 | a statement with `data-chain` is the record `textFor(row, { mode, level, lens, register, chain })`; spans and mentions are statements like any other (one badge exactly where the status has one; no KaTeX at learner level); `[data-connective="chain"]` ≤ 24 characters and `"chain-status"` ≤ 60, both in the connective count; a `p.chain__story` holds no text outside its statements; chain titles fall under the words rule (no 40 characters of a record); `shifted` is rendered at every (mode, level) and in every lens like every page |
| `tests/chains.test.mjs` (new, in `npm run test:data`) | B1 | on the merged tables: V1–V10 again; every storied chain's spans cover its positions in order and are text records; rendered server-side (the pilot pages, `shifted`, `matter`, at phys/math × research/learner and under the lenses cat, geo and furey): at research level the `data-row` order of each `ol.chain__list` equals the chain's positions in both modes (no sorting), each connective is `CHAIN_WORDS` of its link, a mention is the compact statement with its "Told in" link; at learner level a storied chain is one paragraph whose statements are the lead's learner text and the spans in order, an unstoried one falls back to the rows' learner full texts in chain order; no home moved against `baseTables`; the extraction run twice gives the same bytes and its fixture (`tests/chains/fixture/`: a line, a fork, a cycle, a ladder, twins, a singleton attached by a shared parent, a hub that links nothing, a shared input that links nothing, a contradicts pair kept apart, a directed cycle broken) gives its expected chains; ten mutants (a span missing, two out of order, an unearned "So", a status word dropped, a mention not told on the page, a link without an edge, a told row not placed, a lead that is not a story row, a moved home, a chain sorted by kind at research level in mathematics) each caught |
| `tests/story/migration.test.mjs` (edit) | B1 | part C applies to the v15 story rows (those of `content/story/rows.json`); part B accepts 701–799 for round-14 rows of the page's group; part F counts the `shifted` placements among the unchanged homes |
| `tests/logbook.test.mjs` · `tests/shipped.test.mjs` (edit) | B1 | the register's counts with the round-14 story rows and the 13 new rows, `NEW_SINCE` with `v2.15`; rule 1 reads the strings of `content/chains/` and of `content/chains.json` (titles, notes, page entries); rule 5 the budgets of D63; rule 6 the route `shifted`; rule 7 every section a chain names |
| `tests/story/composition.test.mjs` (edit) | B2 | the order slot lead → figure → captions → chains → key → More; the title rule (≤ 60, no claim word, no final period) applied to chain titles too |
| `tests/ui/story.smoke.test.mjs` (edit) · `tests/ui/chains.smoke.test.mjs` (new) · `tests/chunk.test.mjs` · `tests/record.test.mjs` (edit) | B2 | `#/shifted`, `#/shifted?l=learner`, `#/matter?l=learner` at 390 and 1366 px, light and dark: no overflow, no console error; a span is focusable, Enter opens its row's drawer where the row cites a script and Escape closes it; a mention's link scrolls to the told position; the six figures in `figures-extra.js`, none in `app.js`; the record of a page with chains lists them |
| `tests/story/shifted.test.mjs` (new) · `tests/story/landing.test.mjs` (edit) | B3 | the page, its parts and sections in SPINE.md's order and titles; the 24 ATY rows and EQN-008, MAP-018, LNS-017e, INP-049 each told exactly once on `shifted` (orders ≥ 2000) with their homes unchanged; the 17 chains as SPINE.md §2 lists them; the 23 story rows and their `restates`; the fold's rows with their badges; each figure placed once and drawn at both levels; the learnerFrame stored; the door's chapters with `shifted` after `matter` |
| `tests/physics/p12.test.mjs` (new) | B3 | S the table equals the logs; E the engine's numbers equal the stored values (the shells E = m + (−1)ⁿκ at Eτ = (n + ½)π for the stored cases; the beat 2κ per proper time and 2κ/a on the four frames; c₀ … c₃ of the three operators; the roots of r² + 3Hr = εκ² at the four stored settings; 3.3356e+17 s and 1.0570e+10 years); K the quarter turn through the kernel (in Cl(1,3) J = γ₂γ₁ gives Jγ_kJ̃ = +γ_k for k = 0, 3 and −γ_k for k = 1, 2, and e^{JEτ} = (−1)ⁿJ on the lattice: the current and the spin kept, the other two reversed); R every printed number carries a data attribute equal to its stored or kernel value, no TeX at learner level; M a wrong stored number, a shell of the wrong sign, the friction dropped, each caught; D licence headers, tokens only, no stored file imported by a figure |
| `tests/physics/p13.test.mjs` (new) · `tests/story/furey.test.mjs` (edit) | B4 | `fibre-base` through the kernel on the 1,024 labels of Cl(1,9) (bits 0–3 of squares +, −, −, −; bits 4–9 of square −): I and ω₆ square to −1 and commute, Γ = +I·ω₆, so I = −ω₆ on Γ = +1 and I = +ω₆ on Γ = −1, equal to the `fb.CHI` lines of `fibre_base.log`; base and fibre vectors anticommute in the graded product and commute in the ungraded one, the 21 bivectors commute in both (FUR-013); every label printed by the kernel's printer in the active lens (D8); mutants. The Furey test: the overview's lead FUR-701 and next FUR-702, its sections, `fibre-base` assigned on `matter` only, `matter/papers` with the section `read`, FUR-038 … FUR-040 at home on `matter` and on one tab (`matter/help`) |

Unchanged in their invariants and expected green: coverage (every statement a record; one badge; no KaTeX at learner level; connectives within budget; no row's words outside a statement), the story tests (homes; every FUR row at home on `matter` and on exactly one tab), figures.render (interface 13 for the six seeds), the door and explore tests, Ask (a round-14 section lead has role `lead` and may stand under "Where to read about it"; a chain lead has role `chain` and does not).

---

## 6. The two pages, composed

The chains of both pages, position by position with their links, shapes and statuses, are in SPINE.md §2 and §3; this section fixes the pages around them.

### 6.1 `shifted` — Calibration 3

| field | value |
|---|---|
| route · place | `shifted`, an added top-level page with `page.after: "matter/help"` (after Calibration 2 and its tabs, before `lenses`); in the door's chapters after `matter` (`content/story/landing.json`, B3) |
| title | phys "Calibration 3: the shifted view (Atiyah and Moore)" · math "Calibration 3: shifted operators (Atiyah and Moore)" · learner "Warm-up 3: Atiyah's delayed waves" |
| needs | `steps/coupling`, `steps/grav2`, `steps/projective` |
| hero | row ATY-005 (its short learner text exists: the hero shows it, D21) · figure `shifted-quarter-turn` (wide); no notes in the top (the chains hold the rows). The hero row is also told in its chain (sv-4): chains are exempt from the top's claim on its rows, the top shows the headline and the chain tells it in place |
| intro | lead ATY-701 (what the paper proposes and how the page reads it: the paper's move at each of the nine steps, then what the labels compute, then what stays open, the readings and open items at the end); a second paragraph ATY-702 (role detail: the shape of the paper — prologue, toy, chain of natural moves, a difficulty parked at every link, two constants from two ends, questions — kept on this page: `SHIFTED_VIEW_NARRATIVE.md` "The shape of the whole"); next ATY-703 (the lenses page next; the rows live on steps 6, 10 and 11) |
| parts | `p-prologue` "Prologue" · learner "Before the equations": sv-1 · `p-dirac` "The shifted Dirac equation" · "The shifted electron": sv-2 … sv-6c · `p-gravity` "Gravity shifted" · "Shifted gravity": sv-7, sv-8 · `p-end` "Two constants and three questions" · "What is left": sv-9, sv-open (the narrative's observation: the paper alternates between matter, steps 2–6, and geometry, steps 7–8, then comes back to two numbers) |
| learnerFrame (stored, as the other calibrations carry it; the storyteller writes ATY-701's and ATY-703's learner texts from it) | h "Warm-up 3: Atiyah's delayed waves" · before "Warm-up 2 counted Furey's families of particles on the labels. Here a famous mathematician's last idea meets the same test: an equation that looks a little into the past and a little into the future at once." · after "What is left is three questions. Next: ways of looking, the lenses page." · tags [] |

The sections (titles phys · math · learner; the lead is the paper's move, a story row written by B3 from "The move" of `shifted_view.md` and `SHIFTED_VIEW_NARRATIVE.md`, short enough to pass T4/T5 against the section's rows):

| section | title | lead | figure | chains | told rows |
|---|---|---|---|---|---|
| `sv-1` | Step 1. Where new ideas come from · same · 1. Where new ideas come from | ATY-711 | — | `labels` | EQN-008, MAP-018 |
| `sv-2` | Step 2. One simple equation · Step 2. A delay equation and its roots · 2. One simple equation | ATY-712 | — | `toy` (two mentions) | — |
| `sv-3` | Step 3. Relativity forces the Dirac operator · Step 3. The exponential of the Dirac operator · 3. A delay with no special clock | ATY-713 | — | `shift` | ATY-004, ATY-006, ATY-011, ATY-041 |
| `sv-4` | Step 4. What the plane waves say · Step 4. Plane waves and the quantization · 4. Only quarter turns work | ATY-714 | `shifted-shells` | `lattice` | ATY-005, ATY-009 |
| `sv-5` | Step 5. A deviation to measure · Step 5. The weak field and the energy · 5. Does it fall like everything else? | ATY-715 | — | `clock`, `tensor` (leads ATY-751, ATY-752) | ATY-037, ATY-038, ATY-039, ATY-042, ATY-043, ATY-044 |
| `sv-6a` | Step 6a. The formal family · Step 6a. Four variants and their products · 6a. Four cousins of one equation | ATY-716 | — | `family` | ATY-007, ATY-010 |
| `sv-6b` | Step 6b. The mixed equation and quantum theory · Step 6b. Mixed delays and their roots · 6b. Looking both ways at once | ATY-717 | `shifted-beat` | `mixed` | ATY-045, ATY-040 |
| `sv-6c` | Step 6c. What was not tried · same · 6c. What was left untried | ATY-718 | — | `massless`, `potential` (leads ATY-753, ATY-754) | ATY-008, ATY-046 |
| `sv-7` | Step 7. Shift the Einstein equations · Step 7. Shifted Ricci operators · 7. Shifting gravity | ATY-719 | `shifted-ricci` | `ricci` | ATY-051, ATY-052, ATY-053 |
| `sv-8` | Step 8. Einstein–Maxwell by Kaluza–Klein · Step 8. Reduction on a circle · 8. A fifth direction | ATY-720 | `shifted-radius` | `radius` | ATY-054, LNS-017e, ATY-055 |
| `sv-9` | Step 9. Two constants, two ends · same · 9. Two numbers from the two ends of nature | ATY-721 | — | `mu` (four mentions) | ATY-065 (new) |
| `sv-open` | Three questions, and where the labels stop · same · Three questions left open | ATY-722 | — | `q1`, `q2`, `q3`, `numbers` (leads ATY-755 … ATY-758) | INP-049, ATY-047, ATY-056 … ATY-064 (new) |

Counts: 38 told positions (the 24 ATY rows, EQN-008, MAP-018, LNS-017e, INP-049, and the ten new rows ATY-056 … ATY-065), 22 mentions, 17 chains, 23 story rows (ATY-701 … 703, ATY-711 … 722, ATY-751 … 758). Every one of the 24 ATY rows of the shifted view is told exactly once; the existing rows are placed with `add: true` at orders 2101 … 3209 (2000 + 100·k + i, k = 1 … 12 the section in page order, i the position; SPINE.md §2.4 lists them); the new rows carry the same orders in their own `shownOn`. The figures sit in their sections (interface 28: explicit, never placed by their caption rows); the analysis page `public/reports/analyses/shifted_view.html` stays the long reading, named in the drawer's sources as today.

**Connectives** (the try lines under the figures, ≤ 240 characters, no claim; research · learner): top "Pick the rung n and the sheet: the wave and its frame before and after the shift." · "Pick a rung and a sheet, and watch the wave before and after the shift."; `sv-4` "Pick a stored case and a rung: a dot for each plane wave the labels find, an empty mark where they find none." · "Pick a case and a rung to see which delays allow a wave."; `sv-6b` "Pick one of the four frames, and proper or coordinate time." · "Pick a frame and watch the two waves beat."; `sv-7` "Pick one of the three operators and an order of its series." · "Pick one of the three ways and see which kind of universe it picks."; `sv-8` "Pick a stored setting: the computed radius beside the printed one." · "Pick a setting and compare the two curves."

### 6.2 `matter` — Calibration 2, recomposed

| field | value |
|---|---|
| kept | the titles; the hero FUR-001 with `furey-board`; "At a glance" PAG-013 … PAG-016; the calibration sentence once (`fc.ui.calib`); the five tabs and their order; the inputs fold (`needs`) |
| intro | lead FUR-701 in three movements — her results (one generation from the division algebras; her latest model's board), the Atlas's proven results (her board, blocks, axes and edges rebuilt; her ℂl(6), ladder operators and charges; the roadmap's five modes as five bits; fibre and base, the chirality as a relative sign; the 16, its weights, its real structure, no mass term for one chirality; fields whose fibre momentum is a mass), the next steps (which product nature uses, the Lorentz algebra against weak isospin, three generations, the spectrum of fibre momenta); next FUR-702 (the five tabs, then Calibration 3). v15's `does` lede stays held in `pending.json` (D45). |
| sections | `fur-model` "Her model, rebuilt on the labels" · learner "Her big board, rebuilt switch by switch" · `fur-fibre` "Fibre and base" · math "Cl(1,3) ⊗̂ Cl(0,6) and its two halves" · learner "Space and the inner switches", figure `fibre-base` · `fur-labels` "Her ladder operators and her roadmap on the labels" · learner "Her ladders, one switch at a time" · `fur-sixteen` "The 16: weights, real structure, mass terms" · learner "One family of sixteen" · `fur-fields` "Fields: a fibre momentum is a mass" · learner "Waves whose inner motion is a mass" · `fur-next` "Readings, inputs and next steps" · learner "What we chose, what we read, what is next" · `needs` (inputs fold) |
| section leads | FUR-711 … FUR-716; chain leads FUR-751, FUR-752 (the two chains of `fur-labels`) |
| chains | `matter.fur-model.rebuilt` (FUR-001 … FUR-006 with CAND-102 and the twins FUR-001b … FUR-004b) · `matter.fur-fibre.fibre-base` (FUR-007 … FUR-013) · `matter.fur-labels.cl6` (FUR-015 … FUR-019, FUR-032) · `matter.fur-labels.roadmap` (FUR-027 … FUR-031) · `matter.fur-sixteen.weights` (FUR-020 … FUR-023, FUR-033 … FUR-035) · `matter.fur-fields.mass` (FUR-024 … FUR-026, FUR-036, FUR-037) · `matter.fur-next.open` (FUR-014, INP-011, FUR-034 mentioned, FUR-038, FUR-005 with FUR-005b, FUR-039, FUR-026 mentioned, FUR-040); side note CAND-049 in `fur-model` |
| placements | the 44 rows of section `furey` move to the new sections by layout entries of `content/story/furey.json`, **orders unchanged** (homes kept; FUR-013 stays at 29 on `matter`, below 30 on `steps/coupling`); `furey` leaves the entry; INP-011 gains an added entry on `matter` · `fur-next` (order 1100; its home stays `light`); FUR-038 … FUR-040 at home on `matter` · `fur-next` and on `matter/help` · `questions` (added, 1002 …) |
| new figure | `fibre-base` (§6.3), assigned on `matter` · `fur-fibre` only |

Counts: 7 chains, 47 told positions (the 44 rows of `furey` but CAND-049, INP-011, the three new rows), 2 mentions, 9 story rows on the overview (FUR-701, 702, 711 … 716, 751, 752).

**The papers sub-page** (`matter/papers`) gains the section `read`, after `fit` and before `needs`: "Read since, rebuilt on the labels" · learner "Her other papers, rebuilt here"; lead FUR-717; six paper cards, story rows of role `result` that name each paper by its citation (years in parentheses, so that R6 reads them as identifiers) and restate the rows that rebuilt it (T4 against the rows of the parent page): FUR-761 Furey (2015), Phys. Lett. B 742, arXiv:1603.04078 → FUR-015, FUR-016, FUR-017 · FUR-762 Furey (2016), thesis, arXiv:1611.09182 → FUR-008, FUR-012, FUR-015, FUR-017, FUR-019 · FUR-763 Furey (2018), Eur. Phys. J. C 78, arXiv:1806.00612 → FUR-018, FUR-027, FUR-030, FUR-031 · FUR-764 Furey and Hughes (2022), Phys. Lett. B 827, arXiv:2209.13016 → FUR-027, FUR-031 · FUR-765 Furey, Roadmap I (2023), arXiv:2312.12377 → FUR-028, FUR-029, FUR-030, with the numpy route of `furey_papers_check.py` (PAG-014) · FUR-766 Furey and Hughes (2024), arXiv:2409.17948 → FUR-027 and the question FUR-039. Cards, not a chain: papers follow one another in time, and nothing derives one card from another.

### 6.3 The figures

| id | where | draws | data | interactive |
|---|---|---|---|---|
| `shifted-quarter-turn` | `shifted` hero, wide | the even spinor ψ and its frame (ψγ_kψ̃) before and after the shift, on the sheet retarded along k/E (waves e^{−Jk·x}) and the sheet advanced (e^{+Jk·x}); at Eτ = (n + ½)π the right factor e^{JEτ} = (−1)ⁿJ: a quarter turn of ψ, a half turn of its frame, the current and the spin kept (ATY-005, ATY-009) | **the kernel** (products in Cl(1,3), J = γ₂γ₁, any even ψ: the identity is the kernel's) and the stored example of `shd·BIL`, `shd·QNT` (m = 3, κ = 2, E = 5, k = (13, 12, 0, 0); the rational point (3/5, 4/5), where the frame turns by −2θ and no wave exists) | chips n (0–3) and sheet; lenses clifford, bits, primes |
| `shifted-shells` | `sv-4` | the lattice Eτ = (n + ½)π, the two shells E = m + κ (n even) and m − κ (n odd), τ = (2n + 1)λ_C/4; the empty marks (τ = 0, λ_C/2, λ_C, rational points); the second branch for κ > m (ATY-005) | **a stored table** (`qnt`: (3, 2) gives E = 5 at π/2 and E = 1 at 3π/2; (1, 4) gives E = 3) | chips case; stepper n (D37: from the lowest rung up, and from the top) |
| `shifted-beat` | `sv-6b` | two quantized modes, E = 5 and 3 at (m, κ, τ) = (4, 1, π/2): the density's beat at 2κ per unit proper time and 2κ/a per unit coordinate time on the frames a = 5/3, 5/4, 2, 4/5, its sign change over each shift, the energy without beat (ATY-040) | **a stored table** (`beat`) | chips frame; toggle proper / coordinate time |
| `shifted-ricci` | `sv-7` | the three operators (3.3a–c) as series in D²: c₀ … c₃, exact in κ and τ; the lowest order Ricci = −κ², κ², 0 and the space it selects (anti-de Sitter, de Sitter, flat); the correction 2μ of the roots (ATY-052) | **a stored table** (`ser`, `low`, `zero`) | chips operator; stepper order 0–3 |
| `shifted-radius` | `sv-8` | the radius on a de Sitter base: the rates r of r² + 3Hr = εκ² beside the printed e^{±√ε κt}, at the four stored settings; the time scale ħ/kc = 1.0570 × 10¹⁰ years and the e-folding times 2.11 × 10¹⁰ and 2.31 × 10¹⁰ years, as numbers (ATY-054, ATY-055) | **a stored table** (`ds5`, `time`) | chips setting |
| `fibre-base` | `matter` · `fur-fibre`, wide | the ten bits of Cl(1,9) = Cl(1,3) ⊗̂ Cl(0,6), base bits 0–3 (squares +, −, −, −) and fibre bits 4–9 (−); I = e₀e₁e₂e₃, ω₆ = e₄ ⋯ e₉, Γ = +I·ω₆; the half Γ = +1 where I = −ω₆ and the half Γ = −1 where I = +ω₆: the chirality as the relative sign of two complex structures; the switch graded / ungraded: which cross pairs anticommute, which commute (FUR-011, FUR-013) | **the kernel alone** (tied in the test to `fb.CHI` of `fibre_base.log`) | chips half, product; lenses clifford, bits, primes, cube |

Engines `engines/physics/shifted.js` (B3) and `engines/physics/fibreBase.js` (B4), pure, reading the stored table or calling `engines/bitrule.js`; components under `src/figures/physics/`; seeds in `figures.p12.json` and `figures.p13.json` (captionRow ATY-009, ATY-005, ATY-040, ATY-052, ATY-054, FUR-011; `learner: true`; `size: "wide"` for the hero and `fibre-base`).

---

## 7. The persona, rewritten: the storyteller

`docs/09_TRANSLATION_PROTOCOL.md` §2 keeps the lens translators and replaces the learner persona by the storyteller (R7 writes it from this section). The owner's words of round 12 are its brief: one story per piece — what the piece is, why it is there, what it links to and what was checked — in plain words, the numbers and the status words kept, no formula; and of round 14: chains of statements, each a part of the story the Atlas tells.

**What it knows.** All from the tables, never from memory: SPINE.md for its page (the spine: the sections in reading order, their leads, the chains with their working titles); for each chain, its page and section title, the section's lead (research text, and learner text when written), the chain's title and shape, and per position: the row's research text, kind, stage, computed status and badge word, its link to the previous position with the opening words C4 allows, the numbers R6 asks it to keep, the status words R8 and C5 ask for, whether it is a mention (and where the row is told), its twin; the glossary entries its words touch; the learner texts already written on the page (the voice); for a page lead, the page's learnerFrame. It does not know the analysis pages, the papers or anything outside the rows: what no row states, it does not say.

**How it writes a chain.**

1. Read the chain from its first position to its last, with the links. If the chain has a lead, say in one sentence what the chain shows (≤ 300 characters, no number of its own: C6).
2. One span per position, in order: open with a connective of the link (C4: "so" only where the row is derived; "for instance" where it is an instance; "but" only where the composer marked a contrast; never a derivation word on an `order` link); say what the statement is in plain words, and, from the link, why it comes here; keep every number and every status or scope word of the row (R6, R8); no formula, no symbol used as a variable, no Greek letter (R4); present tense, no history word, no date (R5); no name its row does not name (R12).
3. At a weak link — a statement that is our reading, open, not yet proved here, or needs an input — say so in plain words in that span (C5): a story is as honest as its weakest link, and says where it is.
4. A mention: one short sentence that recalls what the statement showed where it is told (20 to 300 characters), with no new number (C8).
5. A row with a human learner text: its words, verbatim (C10); the neighbouring spans carry the connection.
6. Run `node tools/check_learner_texts.mjs --explain <chain id>` before writing and the full check after; a chain the checker rejects goes back once with its failures; a second rejection is listed in `docs/LEARNER_TEXTS_chains.md` for the owner, and that chain stays unstoried (D54: its rows keep their old words).

**The prompt** (verbatim; the brackets are filled from the tables):

> You are the Atlas's storyteller. You tell one chain of statements of the Atlas, as one paragraph, to a reader before university. The chain is "[chain title, learner]", a part of the page "[page title, learner]", section "[section title, learner]", which opens with: [the section lead's learner text]. Its statements, in order, each with how it follows from the one before: [for each position: "n. ([link] — open with one of: [C4 words]) [research text] — status: [status word or none]; keep the numbers: [R6 list]; keep the words: [R8/C5 list][; mention: told in [section], one short sentence, no new number]"]. Write one span per statement, in this order, each opening as allowed. Do not add, strengthen, weaken or drop a claim, a number, a scope or a status word. Where the link says "order", do not use a word of derivation such as so, hence, therefore or it follows. No formula, no symbol as a variable, no Greek letter; no date, no narration of earlier states, none of the words corrected, withdrawn, superseded, formerly, previously, re-worded, now proved; no name of a person that the statement does not name. The paragraph is shorter than the statements together. Output exactly one JSON array: one record per span, `{"row": "[id]", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "span", "chain": "[chain id]", "span": n, "body": "…", "status": "draft", "source": "storyteller@[date]", "termsUsed": […], "keptNumbers": […]}`, then, when the chain has a lead, `{"row": "[lead id]", …, "register": "full", "body": "…"}` without `chain` and `span`.

**The budget.** A chain's story (lead and spans) is at most 0.8 × the summed research texts of its positions (C7); a told span 40 to 900 characters, or 1.5 × its row when that is longer (R9, D15); a mention 20 to 300; a lead at most 300. Every number and status word is kept, no formula, the lead sentence a story row, the relation words the links' (C4).

**Who writes what.** The research texts of the round-14 story rows — a calibration's section leads (the paper's move at that step), the page leads, the next lines, the paper cards — are narration in the Atlas's research voice, written by the page's builder (B3, B4) and checked by T4/T5; the storyteller writes their learner texts, the spans, and the learner text of every side note (a row in no chain) that has none on a storied page (the rows of 2.12.0 to 2.14.0 have none). The old learner persona of 09 §2 writes nothing new from this round on; its drafts stay until a story replaces them (D54) and are retired at 3.0.0.

---

## 8. The staging

| wave · release | what | size (SPINE.md §6; mechanical chains, before composition) |
|---|---|---|
| 1 · **2.15.0** | the machinery (B1, B2); `shifted` (B3); `matter` and `matter/papers` (B4); the pilot chains: `rule` · ideas (GEN), `cells` · cards (GEN), `steps/coupling` · eq-coupling (ATY, FUR), `steps/baez` · bz-generation (ATY, FUR, CAND); their stories (T3); the drafts of the rows told in storied chains on all their pages retired (R7) | shifted 17 chains (38 told, 22 mentions); matter 7 chains (47 told, 2 mentions) and 6 paper cards; pilot 17 chains as composed in SPINE.md §4 (12 mechanical): rule 6 (30 rows, 1 mention), cells 3 (15 GEN rows + 2 side notes), coupling 5 (24, 1 mention), Baez 3 (16 + 1 side note); about 200 spans and 40 story rows |
| 2 · 2.16.0 | the rule (conventions), the cells (the ATL cards: their chains under the lattice), the clock (step 1), light (Calibration 1), steps 2–4 | 151 rows, 35 chains (100 rows + 6 attached), 45 side notes |
| 3 · 2.17.0 | steps 5–8 (spin, the rest of coupling, Yang–Mills, matter) and the five Furey tabs | 108 rows, 20 chains (75 + 2), 28 side notes; the 30 spin matrix lines keep their matrix texts (D48) |
| 4 · 2.18.0 | steps 9–13 (gravity I and II, projective, gauge, null surfaces) | 85 rows, 13 chains (52), 33 side notes; `steps/nullsurf` keeps 17 of its 23 rows as side notes (no edge stays inside one of its sections, six cross them, 71 lead off the page: A62 or a recomposition first) |
| 5 · 2.19.0 | steps 14–17 (forque, spring, rigid body, groups) and shapes | 74 rows, 8 chains (29 + 9), 36 side notes; 119 matrix lines apart |
| 6 · 2.20.0 | steps 18–20 (category, Baez, Schuller) — may ship as two releases (category; Baez and Schuller) | 548 rows, 94 chains (359 + 16), 165 side notes, 8 sections of three rows or more without a chain |
| last · **3.0.0** | every page storied; inside a chain `textFor` no longer falls back to a translator draft; the remaining translator learner drafts retired to `content/chains/retired.json`; the old learner persona removed from 09; the coverage test asks that every learner statement inside a chain is a span or its lead | — |

Each wave: B1 runs the extraction into the owners' files (`--into`), the page owners compose (titles, mentions, contrasts, leads; `--diff` lists the departures), T3 writes the stories, `check_learner_texts.mjs` and `tests/chains.test.mjs` gate, R7 retires the drafts and releases. Wave 1's retirement is narrow by D54's rule: the ATY rows are told in storied chains on both their pages (`shifted`, `steps/coupling`) and retire their drafts; the GEN rows on `rule` and `cells` likewise; the FUR rows also sit on `matter/model`, unstoried until wave 3, and keep whatever old words they have (the rows of 2.12.0 and after have none).

---

## 9. The work breakdown

Disjoint file ownership; a file has one owner per wave. **The chain record (§2.1), the span record (§2.2), the section field and role (§2.3), the round-14 story row (§2.4) and the stored table (§3.5) are the interfaces** — 40 to 44 after interface 39 (the tuning export); R7 numbers them in `docs/BUILD_CONTRACTS.md`.

| owner | creates | edits | inputs → outputs | order |
|---|---|---|---|---|
| **B1** content model, tools, tests | `tools/story/extract_chains.mjs`, `tools/merge_chains.mjs`, `content/chains/pilot/chains.json`, `content/chains/learner/` (empty), `tests/chains.test.mjs`, `tests/chains/fixture/*` | `tools/merge_story.mjs` (calls `mergeChains`; text key with `chain`; role `chain`; an added page's `after`, `needs`, `learnerFrame`; §1.6 kept for v15 story rows, D60's rules for round-14 rows), `tools/check_learner_texts.mjs` (R-changes, C1–C11, `--explain <chain>`), `tools/merge_learner_texts.mjs` (key), `tools/build_content.mjs` (§3.4), `tools/export_tuning.mjs` (`chains.jsonl`, `chain` on span texts), `tests/coverage.test.mjs`, `tests/story/migration.test.mjs`, `tests/logbook.test.mjs`, `tests/shipped.test.mjs`, `tests/export.test.mjs`, `package.json` scripts (`content`: `node tools/merge_chains.mjs --check` after the checker; `test:data`: `node tests/chains.test.mjs`) | §2, §3, §5 and the tables after 2.14.0 → the merge, the checker and the extraction green on empty overlays and on the fixture; the pilot chains composed with SPINE.md §4's titles; SPINE.md §6's counts reproduced or each difference explained | first |
| **B2** renderer, UI smoke | `src/components/Chain.jsx`, `ChainStory.jsx`, `src/styles/chains.css`, `tests/ui/chains.smoke.test.mjs` | `src/app/store.js`, `content.js`, `queries.js`, `vocab.js`, `ssr.jsx`, the table list the app loads (`chains`), `src/components/Statement.jsx`, `Section.jsx`, `OpenFold.jsx`, `src/pages/PageView.jsx`, `src/figures/physics/index.js` (the lines of p12 and p13), `tests/story/composition.test.mjs`, `tests/ui/story.smoke.test.mjs`, `tests/chunk.test.mjs`, `tests/record.test.mjs` (and `tools/build_extra.mjs`, `src/app/lazyFigures.js` if D63's chunk is chosen) | §2 (the interface), §4; B1's fixture chains → the renderer of §4, composition, coverage and smoke green on the fixture and the pilot | after B1's §2 interface and fixture (may start on the fixture while B1 finishes the merge) |
| **B3** `shifted` and its figures | `content/chains/shifted/{chains,rows,texts,page}.json`, `tools/story/stored_shifted.mjs`, `content/stored_shifted.json`, `engines/physics/shifted.js`, `engines/physics/MANIFEST.p12.json`, `src/figures/physics/{ShiftedQuarterTurn,ShiftedShells,ShiftedBeat,ShiftedRicci,ShiftedRadius}.jsx`, `src/figures/physics/p12.js`, `content/physics/figures.p12.json`, `tests/story/shifted.test.mjs`, `tests/physics/p12.test.mjs` | `content/story/landing.json` (chapters), `tests/story/landing.test.mjs` (the chapter list) | SPINE.md §2, `shifted_view.md`, `SHIFTED_VIEW_NARRATIVE.md`, the logs → the page merged and drawn (in old words until T3), the 23 story rows with research texts, the ten new rows with research texts and their locators, the five figures | after B1; beside B2 and B4 |
| **B4** `matter`, its figure, the papers | `content/chains/matter/{chains,rows,texts}.json`, `engines/physics/fibreBase.js`, `engines/physics/MANIFEST.p13.json`, `src/figures/physics/FibreBase.jsx`, `src/figures/physics/p13.js`, `content/physics/figures.p13.json`, `tests/physics/p13.test.mjs` | `content/story/furey.json` (the entries `matter` and `matter/papers`, their layout), `tests/story/furey.test.mjs` | SPINE.md §3, the release notes' open list, `docs/round13/PLAN.md` triage (items 4, 9, 22) → the overview recomposed, the 17 story rows (paper cards included) and the three new rows with research texts, `fibre-base` | after B1; beside B2 and B3 |
| **T3** the storyteller | `content/chains/learner/{shifted,matter,matter-papers,rule,cells,steps-coupling,steps-baez}.json`, `docs/LEARNER_TEXTS_chains.md` | — | SPINE.md, the chain records once V1–V10 pass, §7 → the stories of the pilot chains, the learner texts of the round-14 story rows and of the side notes of storied sections, all through R1–R13 and C1–C11 | after the chain records of a page freeze (page by page) |
| **R7** integration, release | — | `docs/02_CONTENT_MODEL.md` (§1, §2, §7, §11), `docs/09_TRANSLATION_PROTOCOL.md` (§2), `docs/DECISIONS.md` (D51–D64 as taken, the A-questions answered), `docs/BUILD_CONTRACTS.md` (interfaces 40–44), `docs/HANDOVER.md` ("Add a chain"), `docs/RELEASE_NOTES_v2.15.md`, `CHANGELOG.md`, `README.md` (state line), `package.json` (version, after B1), `tools/release.sh` (the round's records: `docs/round14/*.md`), `content/chains/retired.json` (through `--retire`), the budget constants of D63 in `tests/shipped.test.mjs` (after B1 has landed: one owner at a time) | everything above → `npm run content`, `sh build.sh`, `npm test` green; `npm run release` → `release/one-rule-v2.15.0.zip` | last |

---

## 10. The risks

| risk | measure | what we do |
|---|---|---|
| **the coverage test's render budget** | 36 pages × 35 lenses × 4 settings ≈ 5,040 lens renders today; `shifted` adds 144 (about 3 %); the 22 mentions of `shifted` and the chains' items add DOM | the generic rule stays in coverage; the chain assertions live in `tests/chains.test.mjs` on the pilot pages at four settings and three lenses |
| **`app.js` 340 kB and the chunk** | `app.js` 294.8 kB gzipped (+≈ 5 kB for the chain code); `figures-extra.js` 244.1 of 260 kB, the six figures ≈ 15–20 kB (comparable figures weigh 3.5–5 kB gzipped as source); `app.css` 116.8 of 120 kB; `dist/` 57.97 of 60 MB (2.14.0's budget), the round adds ≈ 0.7 MB (`chains.json`, the spans in `texts.json`, `stored_shifted.json`, each with its `.js` twin, and the record of `shifted`) | D63: the chunk to 300 kB (or a calibrations chunk), chains.css under 2.5 kB and no figure stylesheet (else 128 kB), `dist/` unchanged in wave 1 |
| **the connective budget** | ≈ 60 research connectives on `shifted`, each one or three words | single words of `CHAIN_WORDS` (≤ 24 characters), each backed by a `depends` edge (V3) so that "So" is never a claim of its own; the learner connectives are words of the spans, governed by C4, not connectives |
| **the story tests' home rule** | every FUR row must keep its home on `matter` and sit on exactly one tab; FUR-013 sits at 29 on `matter` and 30 on `steps/coupling` | moves keep their orders (§2.7); FUR-038 … FUR-040 at home on `matter` and on `matter/help`; the `shifted` placements at 2000 or more; `merge_story` refuses a moved home; B4 updates `ON_TAB` and `FIG_PAGES` in the same change |
| **the old drafts' retirement** | a row on two pages, one storied and one not, still needs its old words on the second | retire only a row whose every placement is told in a storied chain; human texts never; the retired drafts kept in `content/chains/retired.json` |
| **the learner titles** | step and chain titles carry formulas at research level (ℂl(6), Cl(1,9), ⊗̂) | V7 and the composition test: learner titles are names in plain words, no formula mark |
| **rows that span several steps** | ATY-005, ATY-010, ATY-038, ATY-041 hold clauses of two to four steps; step 2 of `shifted` has only mentions | mentions now; A61 asks for a split into per-step b-rows (02 §1) |
| **"new" on almost every span** | `NEW_SINCE` covers v16 … v2.14: 22 of the 24 ATY spans (the two readings carry "our reading") and nearly every FUR span would carry "new" inside a paragraph | badges unchanged (D56); A60 asks for A45's option ("new" for the latest release only) |
| **thin `depends`** | 558 of 1,098 placements (51 %) are singletons, 348 (32 %) once split lines continue their first line (E2b); 14 sections of three rows or more still have no chain; more edges join two sections of a page (874) than stay in one (656); the genesis climbs n = 0 … 8 but six of its eight steps have no edge: GEN-001 (the empty label, the zero the owner always starts from), GEN-002, GEN-007, GEN-008 and GEN-009 have none to their neighbours | E2b; `joins` across sections; side notes, or `order` links where no edge exists (C4 forbids an unearned "so"): the genesis is told as a ladder with six `order` links (SPINE.md §4.1); A62 asks for a labelling pass before wave 2 |
| **directed cycles** | seven strongly connected sets in derives, instance and uses-input (SPINE.md §5.4), four of them closing through a `uses-input` edge, one on a pilot page (FUR-003 ↔ FUR-006) | broken at the earliest row and reported by the extraction; A62 records each as `cycle` or `equiv` |
| **two merges drifting** | a second merge that restores and re-writes the pages of the first sees the first's writes as its base | D59: one merge, one book |
| **the new rows wait for the owner** | 13 rows (ATY-056 … ATY-065, FUR-038 … FUR-040) | A59 before 2.15.0; if declined, B3 and B4 drop those positions and the folds keep their existing rows |
| **2.14.0 is still being built** | the spine read the tables of 17 Oct 15:12 and again at 15:50 (R6's build of 2.14.0; the same counts) | after 2.14.0 B1 re-runs the extraction with `--diff`; B3 and B4 renumber a new id 2.14.0 took |
| **dense spans** | R6 keeps every number of a row: ATY-041 asks 22, ATY-005 six with two precisions (1.7e-15, 4.6e-14) | C7's budget holds (the research texts are long); A64 asks whether precisions may live in the drawer |
| **the storyteller's load** | about 200 spans and 40 learner texts of story rows in wave 1, then 106, 77, 52, 38 and 375 spans in waves 2–6 (SPINE.md §6.2) (the story round of 2.3.0 drafted 125) | page by page, checker first; an unstoried chain still renders (D54) |

---

## 11. Questions for the owner

| # | question | options (recommendation first) |
|---|---|---|
| A59 | The 13 rows the folds need (D61; SPINE.md §2.3, §3.3): ten readings and questions of the shifted view, three questions of Calibration 2 | **(a)** accept as listed, their texts from the analysis page and the release notes; (b) drop them: the folds keep INP-049, ATY-047, FUR-014, FUR-005 and INP-011 |
| A60 | The badge "new" inside the stories | **(a)** "new" for the latest release only (A45's option): the stories then carry the badges of what is not proved; (b) keep D22's range (v16 … v2.14) |
| A61 | The rows that hold several steps of the paper (ATY-005, ATY-010, ATY-038, ATY-041) | **(a)** mentions for now; (b) split them into per-step b-rows with the check ids of each clause (`en.OSC`, `en.REST`, `en.MIXED` …), a labelling pass |
| A62 | A labelling pass on `depends`: the ladder of the genesis rows (GEN-001 → GEN-002 → GEN-003 …), the 14 sections of three rows or more still without a chain once E2b runs (`steps/nullsurf` first), the seven directed cycles, and the 248 split lines' edge to their first line in `depends` (else E2b keeps reading `splitFrom`) (SPINE.md §5) | **(a)** before wave 2; (b) leave: those rows stay side notes |
| A63 | A told row with a human learner text | **(a)** its human words are its span (D6); (b) the storyteller may write a new span in the chain, the human text kept for the row elsewhere |
| A64 | The precisions of the standard routes (tolerances, sample counts) in a span | **(a)** kept, as R6 asks; (b) carried by the "How do we know?" line, R6 relaxed for them |
| A65 | The titles: "Calibration 3: the shifted view (Atiyah and Moore)", "Warm-up 3: Atiyah's delayed waves", and the step titles of §6.1 | **(a)** as proposed; (b) yours |
