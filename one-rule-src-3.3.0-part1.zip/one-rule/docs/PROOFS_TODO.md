<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# PROOFS_TODO — the statements that wait for a check

Written by `node tools/proofs_todo.mjs` from the tables of `content/` (rows, texts, derived status, checks, runs, candidates, theorems, pages, leads). Do not edit it by hand: change a table, or the notes at the end of the tool, and run the tool again. `node tools/proofs_todo.mjs --check` fails when this file, the notes or the tables disagree.

## 0. What is listed, and how it is ranked

A statement is **missing its proof** (decision R7-8) when its computed status is `cited` (a script is named, no passing run is recorded), or `ours` with a kind that states something checkable (not `reading`), or `open` as a question or conjecture whose answer a finite computation gives, or when it is a candidate that the personas marked checkable "yes". A fifth class is the story: for every page, the chain lead → key results is complete when every key result is `proved-by-atlas` or `standard`.

**Ranking.** Statements that would be false as printed if wrong come first; then the cost of the check, S before M before L (S: an afternoon's script; M: a day; L: more, or a source the package does not hold); then the number of rows that depend on the statement (the `depends` edges into it); then the id. Every statement carries one kind of work: **wire** (the check exists and passes; the row only has to name it (a data edit, no new computation)); **extend** (a check covers part of the sentence; add the missing lines to it); **new** (a new script: bit route, standard route, controls); **derive** (a written derivation first, then the finite check that pins it); **edit** (the row, not the mathematics, is to change (status, kind, wording)); **source** (the answer lies in a text the package does not hold).

**Method of a lead** (`$SP/leads3/COMMON_LEADS3.md` §2–§3): the sentence under test and its wording on pass and on fail are written before the script; a `[bit]` route through the bit rule; a `[std]` route that never touches the engine; controls that must fail; the mutation run where the gravity engine applies. A `wire` item needs only the first and last of these: read the sentence against the script, name the script, and show that a changed number in the sentence would make an assert fail.

## 1. The counts

| class | in the class (by status or table) | on the ranked list | not on it, and why |
|---|---|---|---|
| cited | 0 rows | 0 | none; 0 would be false as printed if wrong |
| ours | 124 rows (90 of kind reading, left out by R7-8) | 0 | 34 of the 34 non-reading rows are not missing proofs: 34 retag; see section 5 |
| open | 119 rows | 0 | 14 reading, 9 mislabel, 34 research, 4 lab, 24 scope, 29 source, 3 input, 2 plan; see section 6 |
| candidates | 5 (yes 0, partly 1, no 4; 145 more are rows now) | 0 | ; "partly" and "no" are outside R7-8 |
| story chains | 32 pages with key results at research level, 33 at learner level | 1 + 1 incomplete | 31 + 32 complete; see section 8 |

In all, **0** statements are ranked. Rows of the other statuses are not on the list: `proved-by-atlas` 938 (each has a ran check whose last recorded run passed), `standard` 37 (a textbook statement carrying its source), `input` 93 (a choice of the model), `meta` 459 (narration and statements about the Atlas).

### What the reading of the tables shows

1. **Most of the work is naming a check that already passes.** Of the 0 cited rows, 0 are decided by a script of `checks/` whose last recorded run passed (0 more in part, 0 are descriptions); the row's evidence names an exploratory printout that is not shipped (the four Furey tests), a check id without a script, or nothing. Of the 0 checkable candidates 0 are already checked in the bridges, the report scripts or the theorem scripts, and 0 more in part. In all 0 of the 0 ranked statements are `wire`; the clauses were matched to the scripts' docstrings and check ids, and the lead re-reads each against the asserts.
2. **The ours class is mostly readings.** 34 of the 34 non-reading `ours` rows say "ours" or "our reading" in their own words; the v15 line split gave the second line the kind of the first. Only 0 have a check to attach or write.
3. **The open class has 0 computable questions**, in 0 groups of work (for example the Baez embeddings, the non-abelian action, the Standard Model labels, the closure of the area metric); the other 119 open rows are names, stated limits, questions to print, or questions of meaning.
4. **20 open rows also state a checked result** (a legacy "checked" line with a passing run on its evidence): the status of the question around the sentence hides the proof of the sentence. Section 6 lists them.
5. **1 of 32 page chains are incomplete at research level** (1 of 33 at learner level). The 1 key results that break them: 1 open. Only the "missing proof" ones can be mended by a check.

### What a passing check changes in a row

The status is computed (`tools/build_content.mjs`), never typed. A passing check turns a ranked row into `proved-by-atlas` only through data edits that the check itself does not make: the evidence entry `{ "check", "script", "mode": "ran" }`; the legacy flag `checked` where the row has legacy flags without it; and, for a row of kind question, conjecture or pointer or of ptype open, a split that makes the checked sentence a result line of its own (a row of that kind stays `open` whatever it has run). Candidates are not rows: one becomes a `CAND-` row when the author accepts it, and the script is its evidence.

| after a passing check the row needs | rows | ids |
|---|---|---|
| the evidence entry only | 0 |  |
| the evidence entry and the flag `checked` | 0 |  |
| the evidence entry and a split of the line (kind, ptype) | 0 |  |
| all three | 0 |  |

## 2. The top twenty

One line each: rank, id, class, page, cost · work, the number of rows that rest on it, the lead that takes it, and what a check computes. Each would be false as printed if wrong; the ranking among them is by cost and by how many rows rest on the statement.


The first 0 ranked statements would be false as printed if wrong; from rank 1 on, a wrong statement would be a missing claim, not a false one. The first twenty are all of cost S.

## 3. The leads

A lead groups the statements that one script, or one reading of a few scripts, closes. The eight briefs are in `docs/round7/leads/`, in the order of the best-ranked statement each holds. The prime lab has its own brief (`$SP/v16_briefs/agent_prime_lab.md`) and is listed here, not briefed again.

| lead | title | model | size | statements | ids | best rank |
|---|---|---|---|---|---|---|
| L7-01 | The step checks behind the Logbook lines | Sonnet | S to M | 0 |  | — |
| L7-02 | Furey: the asserting script, its bit-rule second route, the sentences | Sonnet | M | 0 |  | — |
| L7-03 | The category and report-lens rows | Sonnet | S to M | 0 |  | — |
| L7-04 | Standard Model labels: charges, anomalies, the 16 and the 27 | Sonnet | S to M | 0 |  | — |
| L7-05 | The non-abelian action: stationarity, stress, classical solutions | Opus | M | 0 |  | — |
| L7-06 | Pauli groups, quadrics and Fock encodings | Sonnet | M | 0 |  | — |
| L7-07 | Candidates that a passing check already decides | Sonnet | M | 0 |  | — |
| L7-08 | Exact identities of the gravity and Maxwell engines | Opus | M | 0 |  | — |
| L7-11 | Solid state on the cube: Lieb, Hubbard, Kramers, double groups, the tenfold way | Sonnet | M | 0 |  | — |
| L7-12 | Ranges to theorems: symbolic in n where a closed form exists | Sonnet | S to M | 0 |  | — |
| L7-13 | The Dirac–Hestenes equation: limits, symmetries, the massless conformal clause | Opus | M | 0 |  | — |
| L7-14 | The E-series ladder: embeddings and branchings to the top (the Baez questions) | Opus | L | 0 |  | — |
| L7-15 | The area metric and the constitutive tensor: decompositions and the closure | Opus | L | 0 |  | — |
| L7-16 | Categories, posets, small lattices, kinematical algebras, the rigid body, T17 | Sonnet | M | 0 |  | — |

Groups of work without a brief yet: none. A lead whose statements are all proved keeps its brief as the record of the closing (its statements are no longer listed).

## 4. Class A — cited (0)

Status `cited`: the v15 flag "checked" survived; the evidence names no script that ran and passed. The evidence of the Furey rows names `peirce_test.py`, `witt_test.py`, `z2_test.py` and `family_test.py`; none of the four is in `checks/` (the recorded runs of the first three only print tables, that of `family_test.py` passed). The script that asserts the Peirce structure is `run_all.py`, which imports a `model.py` that is not in `checks/` either (it sits in `checks/reports/furey/`), so it runs from that folder and not from `checks/`.

| # | id | page | statement (at most 20 words) | a check would compute | bit route | cell | standard route | cost · work | depends on | rest on it | false if wrong | lead |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

Evidence to add (`content/rows.json`, mode `ran`): for a `wire` note the script named in its `via` list, as `{ "check": <file name without extension>, "script": <path under checks/>, "mode": "ran" }`. All the cited rows carry the legacy flag `checked`, so the evidence entry alone turns them into `proved-by-atlas` (rule of `tools/build_content.mjs`): the last recorded run of each of those scripts passed, and the tool refuses a `via` that has no passing recorded run.

## 5. Class B — ours, kind not reading (34 of 124)

R7-8 leaves out the 90 ours rows of kind reading. Of the 34 others, 0 have a checkable core and are ranked here:

| # | id | page | statement (at most 20 words) | a check would compute | bit route | cell | standard route | cost · work | depends on | rest on it | false if wrong | lead |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

The other 34 are not missing proofs. 34 retag: the reasons are one line each.

| id | page | statement (at most 20 words) | class | why, when the class does not say |
|---|---|---|---|---|
| ATL-006b | cells#cards | Reading these three generators as the directions of space on the base is the atlas’s Spatial reading (ours). | retag |  |
| ATL-010b | cells#cards | Which of Cl(3,1) and Cl(1,3) is called spacetime is a convention; naming this cell “Minkowski” and reading +1 as space … | retag |  |
| ATL-017b | cells#cards | Placing electromagnetism at this cell of the atlas (the card name “EM Maxwell”) is ours; no link to Furey’s model … | retag |  |
| ATL-023b | cells#cards | The name “cosmic horizon” is ours: no horizon, Hubble constant or cosmological boundary follows from this cell; period 8 is … | retag |  |
| GRV-010b | steps/grav2#eq-grav2 | The pictures and the bit-rule reading of this form are ours. | retag |  |
| LNB-001b | steps/baez#bz-top | Calling those labels one generation, and the bits weak and colour, is our reading: the labels model the paper’s pieces … | retag |  |
| LNB-005b | steps/baez#bz-top | B.4 (reading) Taking these classes as the reason why exactly six pieces occur is ours. | retag |  |
| LNB-010b | steps/baez#bz-top | B.9 (reading) Identifying this lattice with the lattice of the triangulation note is ours. | retag | the identification of the two lattices is called ours; the lattices themselves are checked by baez.T1a, baez.T1b and baez.E3a |
| LNB-014f | steps/baez#bz-generation | On the labels the Peirce value is 1 − d/4, so the six non-empty classes are the six pieces; taking … | retag |  |
| LNB-015g | steps/baez#bz-generation | All of this is standard; what is ours is only that each statement comes out of one operator rule on … | retag |  |
| LNB-016g | steps/baez#bz-ladder | Reading the ladder as the generation assembled rung by rung is ours: the split of each rung by the subalgebra … | retag | the split of each rung is a computation that baez.E1a-E2d checked (a passing run); what is called ours is the reading of the ladder as a generation built rung by rung |
| LNB-017e | steps/baez#bz-ring | The tie to the triangulation note is ours and is only the identification of the lattice: the two papers do … | retag | the tie to the triangulation note is called ours; the enumeration for the stated embedding is checked (baez.E3a-E3d), other embeddings are the open row LNB-045 |
| LNB-023f | steps/baez#bz-kepler | The comparison with the spring is ours: the spring’s signs are the squares of bivectors, a different thing from the … | retag |  |
| LNB-023k | steps/baez#bz-kepler | That one author uses so(4,2) for hydrogen and so(6,ℂ) for matter, in two papers, is our remark, not a theorem. | retag |  |
| LNB-024b | steps/baez#bz-periodic | In the paper’s second quantisation a state of N electrons is a set of N orbitals: N set bits among … | retag |  |
| LNB-026c | steps/baez#bz-numbers | An example it does not carry: the 16 even labels of a generation are tied to that 16 only by … | retag | the open example of the same dead end; the question behind it (real 10 against complex 10) is the research row LNB-022f |
| LNB-053f | steps/baez#bz-generation | The six groups and their charges are in the paper and in textbooks. What the switches add is that the … | retag |  |
| LNB-055c | steps/baez#bz-kepler | Seeing the spring’s signs (turn, slide, stretch) in the three orbits is our reading. | retag |  |
| LNB-056c | steps/baez#bz-ring | That this floor is the triangle floor of another of Baez’s papers is our observation; the two papers do not … | retag |  |
| LNB-057c | steps/baez#bz-periodic | Seeing each electron as a switch turned on is our reading. | retag |  |
| LNB-058b | steps/baez#bz-numbers | Ten is the sharpest case. One paper counts triangles with a rule that has one plus direction and nine minus … | retag | the learner line of LNB-026c; no formula, no check |
| LNS-010e | steps/schuller#sc-chain | Reading the atlas as running his chain the other way is ours: its steps 9 and 10 start from the … | retag |  |
| LNS-011d | steps/schuller#sc-table | The notes go from chapter 12 (forms) to chapter 15 (SL(2,ℂ)) without naming a Clifford algebra; one table could sit … | retag | a statement about what the lecture notes contain (no Clifford algebra between chapters 12 and 15) and a suggestion; the notes are not in the package |
| LNS-012e | steps/schuller#sc-hyper | Drawing the filter as a map of cells is ours. | retag |  |
| LNS-014d | steps/schuller#sc-deform | This is a frozen flat 1+1 model, not his equations (48)–(50), whose structure functions depend on the phase space. Reading … | retag | a statement about what his equations (48)-(50) are, and a reading of the signs; the frozen 1+1 model is checked, the rest is source and reading |
| LNS-016c | steps/schuller#sc-fibre | That the fibre of the physical Lorentz base is this commutant, and what lives in it, is a reading and … | retag | the row says the reading "is not tested"; the isomorphism of the commutant is checked by fibre.G3a and G3e |
| LNS-017f | steps/schuller#sc-fibre | Reading the mass as coming from the descent of F11 is ours; nothing here says which direction a physical mass … | retag |  |
| LNS-019g | steps/schuller#sc-fock | Linking that (2,2) to the first ultrahyperbolic cell of the hyperbolicity map is ours. | retag |  |
| LNS-022e | steps/schuller#sc-bands | Grouping band, edge and gap (the sign of X², the square of an element) with the other places of the … | retag |  |
| LNS-031b | steps/schuller#sc-persp | Bit label = occupation pattern is our reading. | retag |  |
| MAP-001b | logbook#map | Taking three starting ideas (A a null seed, n² = 0; B polarization, an extra datum: a conjugate pair gives … | retag |  |
| RSN-018b | logbook#notes | That Weyl’s first appearance and the 4-vector part of B² share a cause is a reading, not a theorem. | retag | the row says "a reading, not a theorem"; the theorem half (B^B = b(B.B), dimensions) is CAND-087 on this list |
| RSN-028c | logbook#notes | Calling the slice b = 0 the pointors of Roelfs, Eelbode and De Keninck, and writing the chirality as XOR … | retag |  |
| SRC-001b | logbook#researchers | v2: a dead end as written (not a Clifford algebra of a vector space); our quiver-form reading survives, tagged ours … | retag | the first sentences are a verdict on a source (a dead end as written) and our quiver-form reading; the v3 correspondence is checked by bd.mjc.1, mjc.2, mjc.12 and bd.mjp.30 (sibling row SRC-001 computes proved) |

The proposed edit for the `retag` rows is a data decision of the owner (set `kind` to `reading`, which moves the row out of this list and leaves its text unchanged); it is not made here.

## 6. Class C — open (119)

0 open rows have a computable answer and are ranked. Several are one computation (the Baez embeddings: LNB-021g, LNB-035, LNB-035b, LNB-038, LNB-045, LNB-117; the three label spaces: LNB-033, LNB-033b, LNB-039; the closure constants: LNS-013g, LNS-030, LNS-048; the area-metric map: LNS-028d, LNS-045).

| # | id | page | statement (at most 20 words) | a check would compute | bit route | cell | standard route | cost · work | depends on | rest on it | false if wrong | lead |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

The other 119 open rows, each with its reason:

| id | page | statement (at most 20 words) | class | why, when the class does not say |
|---|---|---|---|---|
| INP-033b | steps/ym#needs | The action of this step: the Yang–Mills action of so(m) with a source (pointer, source unread). | input | the pointer to the Yang-Mills action with a source (source unread); the action itself is INP-033, derived by ym_action.py |
| INP-037b | steps/matter#needs | The action of this step: the Dirac action of Ψ with ∂ replaced by D (pointer, source unread). | input | the pointer to the Dirac action with the covariant derivative (source unread); the action itself is INP-037, derived by ym_matter_gravity.py |
| MAT-005b | steps/matter#eq-matter | The size of the coupling is a free parameter. | input | the size of the coupling is a free parameter of the model: a choice, not a statement a check can prove |
| ATL-019 | cells#cards | The cell is Cl(5,3)≅M₁₆(ℝ) at [8,+2]. | mislabel | the cell Cl(5,3) = M16(R) is a computed type (T4, groups_check.py ran); the row is open only by its ptype |
| ATL-022 | cells#cards | Two +1 and six −1 generators give Cl(2,6)≅M₈(ℍ) (cell [8,−4]). Two counting facts hold: an 8-vertex simplex has 70 four-vertex … | mislabel | Cl(2,6) = M8(H) and the counts 70 and 1120 are computed (shapes_selfcheck.py ran); the row is open only by its ptype |
| CPL-007 | steps/coupling#eq-coupling | What the extra components of ψ do from n = 5, and where the grade-5 part of the current goes. | mislabel | answered at n = 5 by CPL-007b (checked: the extra components are a second Dirac field, the grade-5 part on each half); what stays open is CPL-007c; the question line stays as the lead of the pair |
| GOS-006 | shapes#sh-gosset | Mod 2 the same lattice shows why E_n/2E_n carries the label form of Cl(n,0) (T9 (a)): E_n/2E_n is the set … | mislabel | answered by GOS-006b (checked for I_(p,q), p + q <= 12, and E_n, n = 3..11); what stays open is GOS-006c (lattices that are not I_(p,q)); the question line stays as the lead of the pair |
| LNB-034b | steps/baez#bz-persp | The 4 + 7 + 4 grading already exists on the real form: with the null pair on the Lorentz … | mislabel | the 4 + 7 + 4 grading of so(4,2) with ad D eigenvalues +1, 0, -1 is exact at n = 4 (h5l_conformal.py ran); the row is a question only by its kind |
| LNB-046b | steps/baez#bz-notes | Equations, lemmas and tables are cited by the numbers printed in the papers; page numbers are not given, because the … | mislabel | a note on how the papers are cited (equation numbers, no page numbers); it states nothing a check decides |
| LNS-028 | steps/schuller#sc-persp | For quadratic P the first condition is the (k,d) map of F2. | mislabel | "for quadratic P the first condition is the (k,d) map of F2" is computed (bridge.B1, qm.Q10); the row is a question by its kind |
| LNS-028b | steps/schuller#sc-persp | For real amplitudes, product states are the null cone of det on M₂(ℝ), signature (2,2); over ℂ the condition is … | mislabel | the null cone of det on M2(R) has signature (2,2) is textbook and checked (qm.Q10a, Q10b); the row is a question by its kind |
| PAG-034 | light#intro | a hyperbolic symbol gives a well-posed initial-value problem | mislabel | Gårding hyperbolicity is a textbook theorem (standard); the row is open by its kind pointer |
| ATL-022b | cells#cards | The value 210 = 2·3·5·7 is not derived: the lattice budget 2⁸ = 256 has no odd prime factor, and … | lab | the number 210, the odd primes and the prime names are checks P1-P8 of the prime lab; the rest of the row (the map from irreps to cells, continuous parameters) is research |
| ATL-024b | cells#cards | The odd primes outside the group orders of step 17, the continuous parameters, a map from irreps to cells (it … | lab | the number 210, the odd primes and the prime names are checks P1-P8 of the prime lab; the rest of the row (the map from irreps to cells, continuous parameters) is research |
| FUR-005 | matter#furey | A map from irreps to cells (until one is defined the top quark has no cell: three cells have been … | lab | the number 210, the odd primes and the prime names are checks P1-P8 of the prime lab; the rest of the row (the map from irreps to cells, continuous parameters) is research |
| FUR-005b | matter#furey | A map from irreps to cells (until one is defined the top quark has no cell: three cells have been … | lab | the number 210, the odd primes and the prime names are checks P1-P8 of the prime lab; the rest of the row (the map from irreps to cells, continuous parameters) is research |
| ATL-003b | cells#cards | Reading that phase as the electromagnetic phase (the “clock” of the fiber) is ours and open; nothing here yields electromagnetism. | reading |  |
| ATL-005b | cells#cards | In Furey’s construction su(2)_L comes from the quaternion multiplication algebra; reading this cell as weak isospin is that model’s choice, … | reading |  |
| ATL-007b | cells#cards | The name “quark” for this cell is ours and open: B=2, F=1 ↦ 2/3 is only the ratio B/(B+F), not … | reading |  |
| ATL-008b | cells#cards | Reading this cell as the home of charged-lepton spinors (its name “lepton”) is ours and open, not a result. | reading |  |
| ATL-011b | cells#cards | Calling it an electroweak core is an interpretation, and open: Furey’s su(2)_L comes from the quaternion multiplication algebra Cl(0,2) at … | reading |  |
| ATL-013b | cells#cards | Reading this cell as the frame behind maximal parity violation is ours and open: parity violation is a weak-interaction fact … | reading |  |
| ATL-014d | cells#cards | The name “confinement” is ours and open: colour confinement is a physical statement that does not follow from this cell. | reading |  |
| ATL-015b | cells#cards | A central split of this kind has a standard reading elsewhere: the two ideals carry the two signs of a … | reading |  |
| ATL-016b | cells#cards | The name “chiral parity” is ours and open: parity is a reflection (the grade involution of the spatial algebra), a … | reading |  |
| ATL-018d | cells#cards | Reading S as a gravitational strain (the card name “Gravity Strain”) is only a reading of ours, and open. The … | reading |  |
| ATL-020c | cells#cards | The ratio 4/17 is an internal count of neutral paths, not a weak mixing angle. | reading | the ratio 4/17 is an internal count of neutral paths, not a weak mixing angle: the row's own reading |
| ATL-021b | cells#cards | Reading its passive role as a sterile-neutrino state and its active role as the Higgs VEV operator is our interpretation: … | reading |  |
| LNS-028c | steps/schuller#sc-persp | The link of that (2,2) to hyperbolicity is ours. | reading |  |
| PAG-006b | cells#intro | the other names given to cells, and the role names in the card titles (quark, lepton, confinement, electroweak, cosmic horizon, … | reading |  |
| MAP-034 | logbook#map | Start with L = ½\|ẋ\|² − ½xᵀLx, then put energy on faces (lattice Maxwell: an edge field A with F … | plan |  |
| MAP-035 | logbook#map | Doran and Lasenby (action, rotor mechanics), Roelfs and De Keninck (exponentials in any signature), the lecture video itself, then Lasenby, … | plan |  |
| CPL-006 | steps/coupling#eq-coupling | n = 1 and 2: no J, so no charged field. A neutral form was not built. | scope |  |
| GOS-006d | shapes#sh-gosset | For an odd unimodular lattice L that is neither I_{p,q} nor E₈ ⊕ ℤ, k^⊥/2k^⊥ = (L_even/2L, x·x/2 mod 2) … | scope | an odd unimodular lattice that is neither I_(p,q) nor E8 + Z has no cell in the Atlas (GOS-006c is answered for E8 + Z, lat·9): closing it is attaching lattices to cells, a feature, not a check |
| LAB-012 | steps/groups#ln-groups | groups of Lie type over more than two elements, the exceptional families, most sporadic groups; the exact statement of Cartan–Dieudonné … | scope |  |
| LAB-016 | clock#clock | Pin⁺ and Pin⁻ as symmetry classes of neutral fermions are not treated, and the primordial ideas are not settled (each … | scope |  |
| LNB-037 | steps/baez#bz-persp | Shared wires as contracted bits, with the three squares +1, −1, 0 as three behaviours of a wire (J10). If … | scope |  |
| LNB-037b | steps/baez#bz-persp | Could the Frobenius forms of label algebras serve as a finite test case for statements about open systems? | scope |  |
| LNC-076 | steps/category#cat-p6 | Majkić’s version 2 construction and Tian’s DG category stay in the report: the first is not a Clifford algebra as … | scope |  |
| LNP-004 | lenses#intro | closure equations and an action principle for Schuller’s chain (not rebuilt); groups, chirality, masses and why three generations for the … | scope |  |
| LNS-023 | steps/schuller#sc-stops | Gluing. Topology, bundles and connections as sections over a manifold: the atlas is pointwise algebra and finite combinatorics, its fields … | scope |  |
| LNS-024 | steps/schuller#sc-stops | An action principle. No Lagrangian and no variation, so no closure equations: rows C7 and C8 are not rebuilt, and … | scope |  |
| LNS-025 | steps/schuller#sc-stops | Infinite dimensions. Banach and Hilbert spaces, the spectral theorem and the bosonic Fock space (row M2); measurement and mixed states … | scope |  |
| LNS-026 | steps/schuller#sc-stops | Analysis. Chapter 20 is reached only through its one-period matrix, not through the spectrum of the Schrödinger operator. | scope |  |
| LNS-036 | steps/schuller#sc-persp | A local algebraic counterpart of his bundles: the plain right action is a commuting fibre of the same type, the … | scope |  |
| LNS-036b | steps/schuller#sc-persp | Does a global version exist? That is what row L4 leaves open. | scope |  |
| LNS-050 | steps/schuller#sc-questions | Is there a global version of base and fibre as left and right actions (P10, row L4)? | scope |  |
| LNS-057 | steps/schuller#sc-honest | His gravity equations need gluing and an action; we did not rebuild them (rows C7, C8; L4). The closure equations … | scope |  |
| LNS-068 | steps/schuller#sc-stops | His gravity equations need many small pieces of space glued into a whole, and a rule that picks the motion; … | scope |  |
| LNS-069 | steps/schuller#sc-stops | Our rule works at one point at a time, with a finite number of switches; spaces with endless directions are … | scope |  |
| LNS-076 | steps/schuller#sc-honest | His gravity equations need gluing pieces of space together and a rule that picks the motion; we did not rebuild … | scope |  |
| LNS-103 | steps/schuller#sc-chain | His gravity equations need pieces our rule does not have; we did not rebuild them. We did evaluate his printed … | scope |  |
| MAT-006 | steps/matter#eq-matter | Which representation the model uses. Left multiplication on Cl(0,m) is the spinor-type one; the commutator action gives tensor-type ones, and … | scope |  |
| PAG-016 | matter#intro | which edge is lepton and which Higgs, what the doubling means, chirality, the top-quark irreps as states, the Z₂ parallel | scope |  |
| PAG-032 | rule#conventions | Pin⁺ and Pin⁻ as symmetry classes of neutral fermions are not treated, and the primordial ideas are not settled (each … | scope |  |
| YM-007c | steps/ym#eq-ym | A non-abelian source of gravity with Λ = 0 (for example an asymptotically flat Einstein–Yang–Mills solution) is not built. | scope | a non-abelian source with Lambda = 0 (an asymptotically flat Einstein-Yang-Mills solution, numerical in the literature) is not built: a feature of the gravity engine, not a check |
| FRQ-005 † | steps/forque#eq-forque | The paper has no conformal dynamics, and we have not read the other authors working on this subject (Dechant, Roelfs, … | source | the full text of the conformal-dynamics talk is absent; the third batch (lead L14) rewords this row, so it is listed again after the apply |
| LNB-025e | steps/baez#bz-more | The cospan paper was read at overview level; the atlas has no categories, no Petri nets and no rates, and … | source |  |
| LNB-035c | steps/baez#bz-persp | The Jordan-pair paper says in words that the two subalgebras act on the 27 in different ways, and the E7 … | source | why the E7 paper prefers its embedding, and its non-regular embeddings: the papers' own choices, not in the package |
| LNB-040 | steps/baez#bz-questions | The atlas sees each V_k as the Fock module of Cl(5,5) (J2), not through the adjoint of e₇: is that … | source | asks whether the authors of the E7 paper would accept the Fock reading |
| LNB-044 | steps/baez#bz-questions | Is the Hamming-distance form of the Peirce rule, 1 − d/4, already in Loos’s Jordan theory? | source | Loos's Jordan theory is not in the package |
| LNB-046 | steps/baez#bz-notes | Kepler paper, eq. (12), third line, as we read version 5: {M_j, M_k} = ε_jkℓ M_ℓ, while the half-sums of … | source | the printed equation (12) of the Kepler paper, version 5; the Atlas computes [M,M] = eps L (baez.K1b, bd.kep.1) and cannot read the print |
| LNC-054 | steps/category#cat-bottom | Whether k B₃ is tame, and derived equivalent to the tubular algebra of type (3,3,3), is open (QT2, QB4). | source | the T8 note records the answer in print over an algebraically closed field (Wang, arXiv:2407.11363, Prop. 3.1, read); the row still asks it |
| LNC-069 | steps/category#cat-deadends | Tian’s DG category, whose K₀ is the ℤ-form of the algebra, has no counterpart in the atlas and was not … | source |  |
| LNC-077 | steps/category#cat-questions | The complement mask pairs a with a ⊕ 1…1 and is a Frobenius pairing for every signature. Ungraded, it is … | source |  |
| LNC-078 | steps/category#cat-questions | In Cl(3,0) the trace is the top-blade form up to the central pseudoscalar, and it gives the Bloch ball and … | source |  |
| LNC-079 | steps/category#cat-questions | The largest set of commuting blades with square +1 spans a split algebra of dimension 2^{w}, w the Witt index … | source |  |
| LNC-082 | steps/category#cat-questions | E_{n}/2E_{n} carries the label form of Cl(n,0) for every n ≥ 3 and A_{n}/2A_{n} that of Cl(0,n); the two coincide … | source |  |
| LNC-083 | steps/category#cat-questions | The cube category at n = 3 has Coxeter polynomial (x − 1)²(x² + x + 1)³ and a positive … | source | the T8 note records the answer in print over an algebraically closed field (Wang, arXiv:2407.11363, Prop. 3.1, read); the row still asks it |
| LNC-085 | steps/category#cat-questions | Among label-homogeneous gradings the universal grading group is ℤ₂^{p+q} × ℤ^{r}; for arbitrary gradings the rank can exceed r (M₂(ℝ)). … | source |  |
| LNC-088 | steps/category#cat-questions | Tian’s odd truncations have a radical vector a₁ − a₃ + a₅ − …, the half of the last hyperbolic … | source |  |
| LNC-097 | steps/category#cat-honest | Does the Nakayama twist of Cl(3,0,1), which no unit implements, matter for the complement-based dual of projective geometric algebra (QA4)? | source |  |
| LNC-098 | steps/category#cat-honest | Is the unpaired null of a null hypersurface, which every state ignores (Thm T15 with T18), the pointwise shadow of … | source |  |
| LNC-098c | steps/category#cat-honest | Is the Carroll structure of a null hypersurface, as a field with its connection, and the reading of its unpaired … | source | the Carroll structure of a null hypersurface as a field with its connection is the literature on Carrollian horizons, not in the package; the pointwise algebra is checked (LNC-098b, kpg·13 to 15) |
| LNC-123 | steps/category#cat-moves | Complement, in physics: the dual map of projective geometric algebra is built on the complement; whether the Nakayama twist of … | source |  |
| LNS-013g | steps/schuller#sc-area | Whether the eleven or more integration constants of his closure of general linear electrodynamics (“at least 11”: the constructive-gravity article, … | source | the integration constants need the closure paper's equations, not in the package (L7-15: the package stops at the 17 canonical variables, placed in LNS-030) |
| LNS-028e | steps/schuller#sc-persp | For a general area metric, beyond the cells and the one non-metric example of the package, the question stays open: … | source | the 23 algebraic classes of area metrics of the closure paper are not in the package |
| LNS-030b | steps/schuller#sc-persp | The number eleven is a lower bound of the constructive-gravity article (p. 18), not a count of the closure paper … | source | the closure constants need the closure paper's equations, not in the package; the 17 canonical variables are placed (LNS-030) |
| LNS-033b | steps/schuller#sc-persp | Only the lecture video would show whether the printed form is the lecturer’s or the transcript’s; optional. | source | only the lecture video would settle it (optional) |
| LNS-045b | steps/schuller#sc-questions | For r ≥ 1 the quadratic principal polynomial is at best weakly hyperbolic and its gradient misses the null directions: … | source | the closure paper, Sect. II (pointer, source unread): whether the dual polynomial is defined for a quadratic P with a kernel |
| LNS-045c | steps/schuller#sc-questions | For a general area metric the map is not computed here: the closure paper states that the three conditions hold … | source | the seven of 23 classes that pass the three conditions are the closure paper's classification, not in the package |
| LNS-048b | steps/schuller#sc-questions | Do the closure constants of general linear electrodynamics respect the invariant split of the 21, and can a closure keep … | source | the closure constants are not examined in the package; the invariant split of the 21 is computed (CAND-090) |
| LNS-106 | steps/schuller#sc-chain | Third condition (energy-distinguishing): a gap (row C12), a harmless one for the quadratic P of the atlas with r = … | source | the closure paper (p. 35) states the energy-distinguishing condition; no number of ours connects the null-energy check to it |
| SPN-004 | steps/spin#eq-spin | Not checked: 6 rows, the 5 items (Theorem 1 in general, PGA points and the geometric gauge, the announced real … | source | the printed Theorem 1, the announced real idempotent and the complex lambda need the paper of Roelfs, Eelbode and De Keninck; the Cl(3,0) probability rule is computed (T15) |
| SPN-005 | steps/spin#eq-spin | We have not read the two papers the authors cite for the decomposition, and we have seen the lecture only … | source |  |
| ATL-019b | cells#cards | A conserved baryon number is a conjecture: no grading or symmetry carrying it has been found. | research |  |
| CPL-007c | steps/coupling#eq-coupling | What the copies of the Dirac field from n = 5 stand for (a flavour or taste reading); and, on … | research | what the copies of the Dirac field from n = 5 stand for (a flavour or taste reading) is a question of physics, not of the labels; the grade-5 part on one copy is computed at n = 6, 7, 8 (CPL-007d, emd·CUR); whether it vanishes at some psi != 0 of a copy at n = 7, 8, and what it is for n >= 9, is not decided |
| LNB-011d | steps/baez#bz-top | B.10 (open) The link between the (1,9) of the triangulation form and the ℝ^{1,9} of h₂(𝕆) remains numerology: real 10 … | research |  |
| LNB-022f | steps/baez#bz-ten | Open, and honest: real 10 vs complex 10. The 10 of h₂(𝕆) is a real dimension (ℝ⁹ plus time); the … | research |  |
| LNB-033c | steps/baez#bz-persp | Whether the three label spaces can be made one space V ⊗ ℂ³ by a construction outside e₇ is open. | research | a construction outside e7 that makes the three label spaces one V x C^3: no finite computation names it |
| LNB-034 | steps/baez#bz-persp | The complexification of so(4,2), so(6,ℂ) = 4 + 7 + 4, is the Lie algebra of the triple M₂,₂(ℂ) (type … | research |  |
| LNB-034c | steps/baez#bz-persp | Could hydrogen be read as a Jordan-pair quantum system, with M₂,₂(ℂ) one row below the M₃,₂(ℂ) of the Standard Model? | research |  |
| LNB-036 | steps/baez#bz-persp | The clock says what (1,9) is as an algebra (real Majorana–Weyl, J7; baez·T4), and with the even part it gives … | research |  |
| LNB-036b | steps/baez#bz-persp | Is there any mechanism behind the (1,9) of the triangulation form? Real 10 vs complex 10: we found none. | research |  |
| LNB-041 | steps/baez#bz-questions | Hydrogen as the Jordan pair M₂,₂(ℂ) inside M₃,₂(ℂ): is there physics in the inclusion? (P5) | research |  |
| LNB-042 | steps/baez#bz-questions | The signature (1,9): the atlas adds that (1,9), (5,5) and (9,1) carry real Majorana–Weyl spinors, Hull’s signatures from the even … | research |  |
| LNB-051 | steps/baez#bz-honest | Baez asked whether the triangle count’s likeness to ten-dimensional space-time is a coincidence; we found no reason: real 10 vs … | research |  |
| LNB-064 | steps/baez#bz-honest | Baez asked whether the triangle count’s likeness to ten-dimensional space-time is a coincidence. We found no reason. | research |  |
| LNB-144 | steps/baez#bz-papers | Whether the three complex 3-spaces of one and the three generations of the other are related is open. | research |  |
| LNB-152 | steps/baez#bz-papers | Baez asks whether the likeness to ten-dimensional space-time is a coincidence; we find no mechanism: the 10 of h₂(𝕆) is … | research |  |
| LNB-159 | steps/baez#bz-papers | Whether that link means anything is open. | research |  |
| LNB-165 | steps/baez#bz-papers | Papers 1 and 6 both meet the pattern of one time direction and nine space directions. Baez asked whether that … | research |  |
| LNC-076c | steps/category#cat-p6 | Which class sits at which clock value needs T² and C² as input; whether a null generator has a place … | research |  |
| LNC-080 | steps/category#cat-questions | The fermionic and the bosonic ladders satisfy the same relations once the commutator is a super-commutator; the super-dimension of the … | research |  |
| LNC-081 | steps/category#cat-questions | The eight clock values and the two complex classes match the ten symmetry classes of free-fermion matter (Kitaev’s periodic table, … | research |  |
| LNC-084 | steps/category#cat-questions | The exterior algebra Λ(k^{r}) has finite representation type for r ≤ 1, tame for r = 2 and wild for … | research |  |
| LNC-086 | steps/category#cat-questions | The labels of Cl(p,q,r) with the product “zero when two labels share a null bit” form a monoid with zero, … | research |  |
| LNC-096 | steps/category#cat-honest | Does a null generator have a place among the ten kinds of matter? Why does the cube category first show … | research |  |
| LNS-014e | steps/schuller#sc-deform | P3: in 1+1 both deformations are functions on a line; for d > 1, Witt ⊗ A_ε is not literal. … | research |  |
| LNS-029 | steps/schuller#sc-persp | In the frozen 1+1 model ε is the sign class of the constant c = (deg P − 1)p¹¹, and … | research |  |
| LNS-038 | steps/schuller#sc-quantum | 2. Chapters 8–11, the finite shadow of the spectral theorem (commuting blades of square +1 and their projectors): the counts … | research |  |
| LNS-039 | steps/schuller#sc-quantum | 3. Chapter 16, the fermionic oscillator against the bosonic ladder: the relations agree once the commutator is a super-commutator (the … | research |  |
| LNS-046 | steps/schuller#sc-questions | P cannot separate Cl(1,3) from Cl(3,1), yet a real (Majorana) Dirac operator exists in Cl(3,1) (Thm T16(3)). Would Majorana matter … | research |  |
| LNS-047 | steps/schuller#sc-questions | Beyond 1+1, is there a family in the sign ε of the frozen deformation algebra with Euclidean, Carroll-type and Lorentzian … | research |  |
| LNS-049 | steps/schuller#sc-questions | Does the sign of Λ follow the square s of the extra generator, Λ ~ −s·κ² (P8)? Ours; neither confirmed … | research |  |
| PAG-012 | light#intro | any link to Furey’s model | research |  |
| RSN-004b | logbook#notes | Whether this A2 acts on generations in another model of the atlas (three copies of the 16, or the 27) … | research | whether the generation A2 acts on another model of the atlas (three copies of the 16, or the 27): a construction to choose first; the 16-dimensional model gives no su(3) (GOS-003) |
| SHP-005b | shapes#sh-orth | n = 5, reading. The orthoplex language (facets as particles) is ours; that this 16 is one Standard Model generation … | research |  |
| YM-006b | steps/ym#eq-ym | Which gauge algebra, if any, the model uses. so(p,q) is what grade 2 gives. | research | which gauge algebra, if any, the model uses: so(p,q) is what grade 2 gives; no finite computation decides the choice |

Classes: **mislabel** (the sentence is computed or textbook, but the row carries the status of the question around it; the fix is a data edit); **lab** (taken by the prime lab (its own brief, $SP/v16_briefs/agent_prime_lab.md); listed there, not briefed again here); **reading** (a name or an interpretation that the row marks as ours and open; there is nothing to compute); **plan** (a note of work to do, not a statement); **scope** (a stated limit of the Atlas (what is not built); closing it is building a feature, not running a check); **source** (the answer lies in a text the package does not hold, or the question is "is this known?"); **research** (an open question with no known finite computation that decides it).

**Open rows that also state a checked result** (20): ATL-019, ATL-022, FRQ-005, GOS-006, LAB-016, LNB-034b, LNB-036, LNP-004, LNS-024, LNS-028, LNS-028b, LNS-038, LNS-039, LNS-045b, LNS-057, LNS-068, LNS-076, LNS-103, LNS-106, SPN-004. Each has the legacy flag "checked" and a ran check whose last run passed. Their status is open because the row's kind is a question or its ptype is open; the clause that was checked is part of the same text. Splitting such a row, as the migration split v15 lines into `a` and `b` rows, lets each part carry its own status. The data edits for the `mislabel` rows above are the same kind of change.

## 7. Class D — candidates marked checkable "yes" (0 of 5)

From `content/candidates.json` (docs/labelling/CANDIDATES.md). A candidate is a standard result the rows use without stating it; it becomes a `CAND-` row when a check decides it (the proofs round, docs/round7/PROOFS_ROUND2.md: 145 are rows now, with the evidence they earned, and are counted in the classes above by their status) or when the author accepts it. "Rest on it" is the number of rows the personas linked to it. The `page` column is the candidate's field.

| # | id | page | statement (at most 20 words) | a check would compute | bit route | cell | standard route | cost · work | depends on | rest on it | false if wrong | lead |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

The candidates marked "partly" (1) and "no" (4) are outside R7-8; their checkNote in the table says which part a check can reach.

## 8. Class E — story chains

The page model of `src/app/queries.js` (`buildPageModel`) selects, for every body section, the section's lead and its first N result rows (five at research level, three at learner level, the section's own `key` overriding; the learner rows of the section first at learner level; open rows go to the open fold). The top of the page contributes the hero row and the "at a glance" results (its notes, role note, are pointers and are not counted). A page chain is the lead followed by all these key results. It is **complete** when every key result is `proved-by-atlas` or `standard` (a `meta` row is narration and is skipped). The lead of a story row restates only rows that are proved or standard (the test of the story round guarantees it), so a chain breaks at a key result, never at a lead.

Pages outside the story (not counted): the 0 Explore pages (R7-3 folds them into the Atlas pages) and logbook, ask, glossary (they list tables and have no story).

At research level 31 of 32 pages are complete; 1 of the 259 key results break a chain (1 open). At learner level 32 of 33 are complete; 1 of 145 (1 open).

| page | lead | key results | sections broken | the links that break the chain (research level) | learner level |
|---|---|---|---|---|---|
| matter/help | — | 1 in 1 sections | 1 of 1 | PAG-016 (open) @top | PAG-016 |

The complete pages at research level: atlas, rule, cells, clock, light, steps, steps/comm, steps/mirrors, steps/dirac, steps/spin, steps/coupling, steps/ym, steps/matter, steps/grav1, steps/grav2, steps/projective, steps/gauge, steps/nullsurf, steps/forque, steps/spring, steps/rigid, steps/groups, steps/category, steps/baez, steps/schuller, shapes, matter, matter/papers, matter/model, matter/generations, lenses.

Rows that break chains, with the pages they break, and whether a check can mend them:

| row | status | class of break | pages | levels |
|---|---|---|---|---|
| PAG-016 | open | open | matter/help | research + learner |

Reading the classes: **missing proof** is a cited row or an ours row with a checkable core (a check can mend it: sections 4 and 5); **mislabel** is an ours row whose sentence already has a passing check (a data edit); **open** is a stated unknown; **input** is a choice of the model; **reading** is an ours row that is a reading (no check decides it; its place among the key results is a layout choice, the owner's).

## 9. Supplement — theorems with a declared gap

Not rows, so outside the five classes; listed because many rows rest on them (`theorems.json`: status other than `proved`, or a verifier note "gaps"). Not ranked.

| theorem | title | status · verifier | rows using it | what is missing | cost · work |
|---|---|---|---|---|---|
| T2 | Radical, Loewy layers, super-centre and graded structure of Cl(p,q,r) | proved · gaps | 7 | the checks GL and GRA test nothing (tautologies) and LOE does not terminate on a non-nilpotent radical: rewrite the three items so that each can fail; the universal grading group for arbitrary gradings (torsion included) is not determined (LNC-085) | S · extend |
| T4 | The mod-8 type table from the bit rule; five ungraded types, eight graded pairs; Gauss sum; Frobenius–Schur count | reduced · gaps | 32 | the eight pairs are shown distinct, not shown to be the graded Morita classes forming Z8: Wall's theorem is recalled (CAND-004); a check of graded Morita equivalence classes for p + q <= 8 | L · source |
| T6 | The cube of labels: the sign is unique up to gauge, the Koszul complex, H²(ℤ₂ⁿ; 𝔽₂) = quadratic forms, the octonion cochain | reduced · verified | 1 | part (d) is reduced to Hurwitz's theorem (recalled) and the Albuquerque-Majid framing is recalled: CAND-070 and CAND-094 give the finite parts | S · wire |
| T8 | Representation type of the cube category (the incidence algebra of the Boolean lattice) | reduced · gaps | 0 | the TITS loop at n = 3 does not terminate on some false inputs (fix the loop, then it can fail); wild for n >= 4 rests on de la Peña's theorem (recalled, over an algebraically closed field) | S · extend |
| T12 | Reflections over 𝔽₂: Cartan–Dieudonné in characteristic 2 | range · gaps | 5 | no hand proof of the O+4(2) exception (the exhaustive count is the proof) and no general length formula; generation for general n rests on Dieudonné's theorem (recalled): CAND-059 and bd.en.5 (to n = 200) | M · derive |
| T17 | Bivector squares and the rotation / boost / translation trichotomy (D3) | proved · gaps | 11 | the isoclinic case lambda1 = lambda2 and the invariant decomposition for general n are not proved (Roelfs-De Keninck); CAND-076 states it | M · derive |

## 10. How this file is made

Command: `node tools/proofs_todo.mjs` (write), `--check` (compare), `--selftest` (plant broken inputs), `--json` (the model). The tool reads `content/rows.json`, `texts.json`, `derived/status.json`, `checks.json`, `check_runs.json`, `candidates.json`, `theorems.json`, `pages.json`, `leads.json`, nothing else, and writes nothing else.

What the tool computes: the classes and counts; the page of a row (the placement of lowest order outside the Explore pages); the statement in at most twenty words (the short research text if there is one, else the full text cut at twenty words); the rows that depend on a statement (distinct rows with a `derives`, `equiv`, `instance`, `uses-input` or `restates` edge into it); the chains; the ranking; the column "cell" (the field `cells` of the row, the Clifford cells Cl(p,q,r) written (p,q,r), or for a candidate the cell written in the notes); this file. What a reader decided, once per id, lives in the notes at the end of the tool: what a check would compute, the bit route, the standard route, the cost, whether a wrong statement would leave the printed sentence false, and the lead. The tool checks the notes: every id of every class has one; a note names only files that exist; a `wire` note names a script whose last recorded run passed; every ranked statement has a cell; the first eight leads by rank are the eight briefs, and the list of statements printed inside each brief is written by the tool.

A row that enters a class later (a new status, a new open question, a new candidate) is printed without a note and `--check` fails until a note is written.

### The routes named in the tables

| as written in the tables | what it is |
|---|---|
| bitrule_A.py BR(eps) | checks/researchers_checks/bitrule_A.py: the reference bit rule, blades as masks, multivectors as dicts, exact integers or Fractions, any cell, no import from the atlas |
| engines/bitrule.js | engines/bitrule.js (bladeMul, cell, clockOf): the kernel of the pages, tested against bitrule_A.py |
| bitcliff.py Alg + regular_matrix | checks/selfcheck/steps15_17/bitcliff.py: Alg(p,q,r), regular matrices, rank, a pure-Python Schreier-Sims |
| clC.py Alg | checks/researchers_checks/clC.py: Alg with exact Fractions, exp_mv, det_frac, int_mat |
| f2lib.py (F2 quadrics, Schreier-Sims) | checks/researchers_checks/f2lib.py: F2 vectors, the label form of Cl(p,q), quadric counts, transvections, Schreier-Sims |
| gravity_selfcheck.py Forms/Lie/Grav with b1lib.py | checks/selfcheck/gravity_selfcheck.py (Forms, Lie, Grav: exact Fractions, differential forms as the bit rule with null generators) with checks/selfcheck/gravity/b1lib.py (head, chk, finish, frames, jets) |
| forque_selfcheck.py Alg(d), pgadyn_selfcheck.py | checks/selfcheck/forque_selfcheck.py (Alg(d, sp, eps_sq): Cl(d,0,1) as the bit rule) and checks/selfcheck/pgadyn_selfcheck.py (rigid bodies from the segment to the tesseract) |
| equations_selfcheck.py, yangmills_selfcheck.py | checks/selfcheck/equations_selfcheck.py (bivector commutators, so(p,q)) and checks/selfcheck/yangmills_selfcheck.py (gauge algebra of Cl(0,m)) |
| the page script (own bit rule, exact) | the page scripts of checks/selfcheck/*_selfcheck.py, each with its own copy of the bit rule and exact Fractions |
| exhaustive enumeration, no engine | integer enumeration with no engine and no sign loop of the bit rule |
| numpy matrices of an explicit representation | explicit matrices (Pauli, Dirac, octonion, Gell-Mann) in numpy; no bit product |
| root-system enumeration in doubled integer coordinates (check_T13.py model) | the doubled integer coordinates of D8+ (240 roots of E8) as in checks/researchers_checks/check_T13.py |
| metric and Christoffel symbols | the metric from the frame, Christoffel symbols, the textbook curvature (numpy or exact) |
| the textbook formula in exact rationals | the textbook formula, evaluated in exact rationals |

A script name without a folder is found under `checks/`, `checks/selfcheck/`, `checks/selfcheck/gravity/`, `checks/selfcheck/bridges/`, `checks/selfcheck/reports/`, `checks/researchers_checks/` or `checks/reports/*/`; the tool resolves every name it prints. `bd.<field>.<n>` is a bridge check id, `cat.`, `baez.`, `fibre.`, `bridge.`, `qm.` and `bzw.` those of the report scripts, `core.B<n>` those of `core_check.py`.

