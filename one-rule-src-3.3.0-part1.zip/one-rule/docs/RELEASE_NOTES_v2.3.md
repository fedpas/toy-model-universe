<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# ONE RULE 2.3.0 — release notes

The story round. The narration v15 printed on its pages — page and section leads, figure captions, learner-only lines — lives as story rows (`content/story/`, kind `story`, status meta, no badge), merged after the Explore and physics overlays; a page is composed as intro → hero → "at a glance" → parts and sections (lead → figure → captions → key results, 3 at learner level and 5 at research level → "More statements (n)") → open items grouped → "What this page takes from outside (n)" → next line; the three chapters (Baez, Schuller, category) are laid out in their v15 parts and sections; Ask shows "Where to read about it" (story leads) before the statements; the physics and Explore figures load from a second file on demand (`figures-extra.js`); the 149 lines of the translation matrices carry learner texts.

## The review

Every held paragraph and proposed statement of `docs/STORY_REVIEW.md` has a proposed choice with a reason naming rows and checks (`content/story/review_proposed_a.json`, `_b.json`; `tools/accept_review.mjs`; `docs/REVIEW_GUIDE.md`). The choices accepted by rule (`story`, `same-as`, `drop`: 386) are recorded in `content/story/review.json`; a `story` choice reaches a page only where the test of `docs/STORY_PLAN.md` §1.4 clears the paragraph in its section. The 38 choices that make a claim (`hold`, `statement`) wait for the author (`docs/round7/REVIEW_DIGEST.md`).

## Counts

364 story rows; 348 paragraphs held; 99 proposed statements; 931 layout entries; 33 pages composed.
