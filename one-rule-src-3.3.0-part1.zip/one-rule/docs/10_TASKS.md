# 10 — The work list

Tasks are ordered; each names what it depends on, what it produces, and how it is accepted. "Agent session" = one focused run of a coding agent with the relevant files of this book in context; a human developer would take roughly the hours given. Stop points (★) are where the author should look before the next phase starts. Nothing here requires a decision that this book has not already taken; decisions for the author are collected in `docs/DECISIONS.md` as they are met.

## Phase 0 — Repository and content skeleton (≈ 1 day)

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T0.1 | Create the repository per `08 §1`; pin the toolchain; copy this book to `docs/` | — | `package.json`, `vite.config.js`, empty `content/`, `docs/` | `npm run build` produces an empty app that renders the shell |
| T0.2 | Write the JSON schemas of `02` (`content/schema/*.json`) and `tools/build_content.mjs` step 1 (validation only) | T0.1 | schemas, validator | validator rejects a hand-made bad record for each rule of `02 §10` (one fixture per rule) |
| T0.3 | Copy `checks/` from v15 and the 14 wave-3 scripts with their logs (`03 §2.5–2.6`); write `checks/RUNBOOK.md`; run `core_check.py`, `check_T1.py`, `maxwell_selfcheck.py` as a smoke test | T0.1 | `checks/` | the three scripts print their pass lines unchanged from the shipped logs |

## Phase 1 — Migration of the content (≈ 3–4 days) ★ stop point after T1.9

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T1.1 | `rows_from_v15.mjs` (`03 §2.1`) | T0.2 | `rows.json`, `texts.json` (research), `learner_backlog.json`, `MIGRATION_COUNTS.json` | counts recorded; every v15 id present; every row has one research text; validator passes |
| T1.2 | `tables_from_v15.mjs` (`03 §2.4`) | T0.2 | theorems, questions, sources, matrix, lenses (skeleton + dictionaries), readings, map, steps, analyses, reports, glossary | counts of `03 §2.9` |
| T1.3 | `inputs_from_v15.mjs` (`03 §2.3`) | T1.1 | `inputs.json`, needs per page | 94 inputs joined to INP rows; 31 tabs; 11 kinds |
| T1.4 | `checks_from_v15.py` (`03 §2.5`) + `import_runs.py` | T0.3 | `checks.json` (250), `check_runs.json` | every row's `evidence.check` resolves; gravity 69 rows, 5,569 ok, 0 fail imported |
| T1.5 | `pages_from_v15.mjs` (`03 §2.8`) with the explicit re-pointing table | T1.1, T1.3 | `pages.json`; every row's `shownOn` resolves | no row without a page except meta/candidate; the re-pointing table reviewed by eye (print it) |
| T1.6 | `learner_from_v15.mjs` (`03 §2.2`) | T1.1, T1.5 | learner texts; the backlog shrinks | every page lists its learner gaps; `STORY_YL` frames attached to heroes |
| T1.7 | `leads_v16.mjs` (`03 §2.6`) | T1.1, T1.4 | 26 rows with `new`, 14 scripts, 14 runs, `leads.json` | the two merge-needed rows flagged; the SHIP_NOTES `checkedBy` texts attached as evidence |
| T1.8 | `figures_from_v15.mjs`: engines copied to `engines/`, `figures.json` seeds | T0.1 | `engines/*.js` (v15 copies, untouched), `figures.json` | every engine imports in node; manifest written |
| T1.9 | `verify_counts.mjs`; `docs/COVERAGE.md` first version | T1.1–T1.8 | counts green; coverage report | ★ the author reads `COVERAGE.md` and the re-pointing table |

## Phase 2 — Labelling (≈ 2 days of model runs + 1 day of judging) ★ stop point after T2.4

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T2.1 | Run the nine remaining persona passes + the chunk-C physicist outline (`04 §3`) | — (uses `labelling/`) | `labelling/out/*.jsonl|.md` | `validate_labels.py` prints 0 problems for all ten files |
| T2.2 | `merge_labels.py`; read `labelling_stats.md` | T2.1 | `labels_merged.json`, `graph.json`, stats | 789 rows labelled; cycles and contradictions listed |
| T2.3 | The judge's step (`04 §5`) → `JUDGE_LOG.md`; apply to `rows.json` (`notions`, `kind`, `stage`, `ptype`, `fields`, `phenomena`, `homes`, `depends`) via `tools/migrate/apply_labels.py` | T2.2, T1.1 | labelled `rows.json` | validator passes; status recomputed; `docs/COVERAGE.md` shows the status counts (expect ≈ 160–200 cited/ours/open badges in total, none on proved rows) |
| T2.4 | Candidates: section C of every outline → `CAND-*` rows (status candidate; linked rows; checkability) | T2.3 | candidate rows in the Logbook | ★ the author reads the candidates and the contradictions |

## Phase 3 — Engines, kernel, figures (≈ 5–7 days)

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T3.1 | `engines/bitrule.js` + `numeric.js`; `kernel.test.mjs` against tables generated from `bitrule_A.py` | T0.3 | the kernel | tests green for all signatures n ≤ 5 |
| T3.2 | Re-point the five v15 product implementations to the kernel; delete duplicates; `engines/MANIFEST.json`; `engines.test.mjs` | T3.1, T1.8 | one kernel, 12 engines | every engine's numbers equal the stored json (ports of v15 engine tests) |
| T3.3 | Figures 1–5 of `07 §3` (four views, lattice + wheel, charges, PGA trio, Furey boards) as `src/figures/*` with `FigureFrame` | T3.2, T4.1 | five figures | render in both themes and at phone width; data download works; tests compare shown numbers with stored json |
| T3.4 | Figures 6–10 (null figures with lens chips, E8/Gosset/Petrie/zonogon, Dirac/comm pictures, category cubes, matrix heatmap) | T3.3 | five figures | same |
| T3.5 | The remaining figures of `07 §3` | T3.4 | all figures | same |

## Phase 4 — Shell, components, Logbook (≈ 5 days) ★ stop point after T4.6

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T4.1 | `tokens.css`, `base.css`; `Shell` with the three switches, theme, search, settings in the address; hash router | T0.1 | the frame | UI test: switches change `data-mode/data-level/data-lens` on `html`; deep links reproduce the view |
| T4.2 | `Statement`, `Badge`, `GlossaryTerm`, `OpenFold`, `PageHeader`, `Hero`; the connective-prose budget | T0.2 | components | `coverage.test` passes on a fixture page |
| T4.3 | `Drawer` with the six tabs; `DependencyMap` | T4.2, T2.3 | drawer | evidence tab lists the runs; rests-on/leads-to from `depends`; address shown |
| T4.4 | `build_content.mjs` steps 2–5 (status, address, neighbours, chunks, coverage, persona) | T2.3, T1.* | `src/content/*` | deterministic; `counts.test` green |
| T4.5 | Logbook: Register (port the "Cascade Atlas Matrix" prototype), Theorems, Questions, Sources, Checks, Reports, Analyses, Leads, Candidates, Replication & bench, Method, Dependency map | T4.3, T4.4 | `/logbook` | every tab renders its table; filters work; the register's row drawer equals the page drawer |
| T4.6 | Glossary page and tooltips | T4.2 | `/glossary` | ★ the author sees the register and the Logbook with the real data |

## Phase 5 — Pages (≈ 6–8 days) ★ stop point after T5.5

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T5.1 | `/`, `/rule`, `/cells`, `/cells/p,q`, `/clock` (`06`) | T4.*, T3.3 | five pages | page acceptance criteria of `06`; UI tests |
| T5.2 | `/light`, `/shapes`, `/matter` | T5.1, T3.4 | three pages | same |
| T5.3 | `/steps` index and the generic step page; steps 2–10 | T5.1 | nine step pages | same; the gravity drawer shows the 66+14 scripts and the mutation table |
| T5.4 | steps 11–20 (including the three lens chapters as steps 18–20) | T5.3 | ten step pages | same |
| T5.5 | `/lenses`, `/lenses/<key>`; the lens picker's counts from `coverage.json` | T5.4 | lens rooms | ★ the author walks the four journeys of `01` |

## Phase 6 — Learner texts and translations (≈ 3 days of model runs + review)

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T6.1 | Learner texts for every page hero and result lacking one (`09 §2` learner persona; checker) | T5.5 | drafts in `texts.json` | `coverage.test`: every page has a learner hero and ≥ 3 learner results, or the notice |
| T6.2 | Mathematics-mode variants where `homeMath` differs | T6.1 | drafts | the mode switch shows them |
| T6.3 | Branch lenses alg, geo, top, cat, comb for the rows with a dictionary entry; then furey, baez, schuller, hestenes, pga | T6.1 | drafts | the lens rooms show the counts; no silent fallback |
| T6.4 | Author review pass on drafts (mark reviewed / edit) | T6.3 | statuses updated | `COVERAGE.md` draft count falls |

## Phase 7 — Ask, routes, release (≈ 2 days)

| id | task | depends | produces | accepted when |
|---|---|---|---|---|
| T7.1 | `build_persona.mjs`, `persona.test.mjs`; port `api/` and `lib/` with env settings | T4.4 | `/ask` | the test pins every core sentence to a row; the guard limits of v15 kept |
| T7.2 | `no_history`, `no_contact`, `license`, `imports` tests; CI workflow running data tests and UI tests (skip when no browser) | T0.1 | `tests/`, CI | green |
| T7.3 | Performance pass (`08 §5`): budgets measured in CI | T5.5 | report | within budget |
| T7.4 | `docs/HANDOVER.md` (add a row / a check / a lens, with the `PRJ-005` v16 walk-through), `docs/DECISIONS.md`, `docs/COVERAGE.md` final | all | docs | the author can add a row following the doc alone |

Total: roughly 25–30 developer days, or a few dozen agent sessions; the model-run phases (2 and 6) are token-bound, not time-bound.

## What to do if credit runs out midway

Each phase leaves the repository usable: after Phase 1 the content is a clean dataset anyone can read; after Phase 2 the labelling is complete and the Logbook could be a static table; after Phase 4 the Logbook is a working research tool even without the reading pages; after Phase 5 the app is complete at research level; Phase 6 adds the learner and lens texts page by page. Commit after every task; never leave `content/` failing validation.
