# ONE RULE 2.0.0 — release notes

ONE RULE, *an atlas of cells, clocks and lenses*, is a web atlas that shows how one labelling — blades of a Clifford algebra as bit masks, products by XOR with a sign — reaches, step by step and with a check at every step, the cells of the algebra, their clock, two known pieces of physics (light, and one generation of matter), gravity, mechanics, and the languages of several branches of mathematics and of several researchers. It starts at ℝ = Cl(0,0,0), the empty label, and never claims more than its scripts recompute. A reader sees results; a researcher opens the drawer and finds every check, source and open question behind them. Release 2.0.0 is the Cascade Atlas in this form: the author's content, moved table by table with every count verified, behind a site with three switches (physics or mathematics, research or learner, a lens) and a Logbook that holds the evidence.

## What it holds

<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->
- **Release** 2.0.0 · content 2026-10-10.
- **Statements**: 1,013 rows (the 789 rows of the author's package, with 224 more where a row held several lines), each with a research text in the author's words.
- **Texts**: 1,838 in all — 1,013 research texts and 32 learner texts by the author, 793 learner drafts waiting for review (drafts by file: texts_learner.json 209, texts_learner_2.json 166, texts_learner_baez.json 246, texts_learner_schuller.json 172).
- **Status**, computed from the evidence and the labelling: proved by the Atlas 522 · standard 37 · not yet proved here (cited) 31 · our reading 112 · needs an input 93 · open 127 · about the Atlas itself 91.
- **Lenses**: 34, with 973 dictionary entries; 1,901 lens readings on 435 rows in 10 lenses; 982 readings in the readings table.
- **Checks**: 250 scripts with 319 recorded runs; the gravity checks: 5,569 pass, 0 fail.
- **Figures**: 44 drawn, 0 of the 44 seeds shown as labelled placeholders.
- **Candidates**: 150 missing pieces named by the labelling passes, kept in the Logbook until the author accepts them as rows.
- **Pages and tables**: 31 routes; 20 theorems; 34 questions (15 answered); 26 sources; 16 glossary terms; 8 wave-3 leads with 28 proposed edits on 26 rows.
- **Validation** (docs/COVERAGE.md): 0 errors.
<!-- end of the counts -->

Every statement on a page is a row with a text record; nothing that states a law is typed into a component. The status of a row is computed from its evidence and its labelling, and a row carries at most one badge: open, not yet proved here, our reading, needs an input, or new. Standard and recomputed statements carry none.

## What is a draft

The learner texts written by a translator are drafts. Each one says what its row's research text says, in plain words: no formula, every number and every status or scope word kept, no new claim. Each passes the thirteen rules of `tools/check_learner_texts.mjs` before it is merged into `content/texts.json` with the status `draft`. A draft is shown at learner level under the row's own badge and never changes a row's status. The author reviews a draft in its `content/texts_learner*.json` file — sets its status to `reviewed`, or edits its body — and runs `npm run content`. A row without a learner text is not shown at learner level; a section without any shows one notice instead.

## What is open

The questions left to the author are listed in `docs/DECISIONS.md` under "Left to the author" (A1–A14), each with its options and the default this release takes. In short:

- how lens readings are attached (through a whole script name or through single check ids; a third link where a reading names a row) and which fields map to which lens (A1–A3);
- the rows whose plain-words version is longer than the learner limit, the page heroes among them (A4);
- research texts that are unclear in themselves, and the contradictions between the two labelling personas, kept as review notes (A5, A6);
- figure choices: the labels of the Maxwell four views, the Schuller chain, the interactions each figure offers, the charges figure that needs a data file the package does not have (A7–A9, A11);
- the stored benchmark timings, the learner definitions of the glossary, the questions a candidate answers, and the pinned migration counts (A10, A12–A14).

## How to run it

Unzip the archive and open `index.html` in a browser: the site runs from the file system, and every view has an address such as `index.html#/steps/grav2?m=math&l=learner&lens=cat`. Or serve the unzipped folder with any static server (for example `python3 -m http.server`, then the address it prints). No network is needed: KaTeX is in `katex/`, and without the web fonts the pages use the system fonts. The check scripts are in `checks/`, the reports and analyses in `reports/`.

## How to verify it

In the repository, with the offline modules (`export NODE_PATH=/opt/npm-tools/node_modules`; no `npm install`):

- `npm test` runs the migration counts, the kernel against the Python reference, every engine against its recorded fixture, every figure at both levels, both themes and every lens it declares, the Logbook counts, the coverage invariant (every statement on a page is a text record of its row; no formula at learner level) and the browser smoke test;
- `node tests/shipped.test.mjs` checks what ships: no history words in a shipped text, the licence header on every source file, no contact details or user paths, a closed import graph with one kernel for every blade sign, the size budget, the routes and the rows each page shows;
- `npm run release` runs the content pipeline, the build and all of the suites, stops at the first failure, and writes `release/one-rule-v2.0.0.zip` with its size and sha256.

## Licence

PolyForm Noncommercial License 1.0.0 (`LICENSE`): free for noncommercial use, not for commercial use. Required Notice: Copyright (c) 2026 the Cascade Atlas authors. Every source file carries the three-line notice; the author's check scripts carry their own.
