<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Pass 8c, the result: the chain of Cl(8)'s on the labels

Script `checks/selfcheck/proofs/chain_blocks.py`: 58 checks (bit 42, bit==std 4, ctl 6, std 6), 0 fail, about 50 s; nine `--fault` options, each run ending with its FAILS line and exit 1. Logs `checks/selfcheck/proofs/logs/chain_blocks.log` and `chain_blocks.faults.log`. Run from `checks/` as `python3 -I -B selfcheck/proofs/chain_blocks.py`; from the script's own folder the check lines are the same (only the timing lines differ). The kernel is `researchers_checks/bitrule_A.py` (imported by a path from `__file__`, as `chain_fock.py` does); the type table is `core_check.TYPE` and the cell's signs `core_check.sig`, imported from `selfcheck/core_check.py`.

## 1. Predicted (BEFORE.md, written before the script ran)

(1) s(a,b) = (−1)^{|a₂||b₁|} s₁ s₂ on every pair of cells with n₁ + n₂ ≤ 8; the ungraded table differs where |a₂|, |b₁| are odd. (2) The ungraded and graded products agree exactly when one clock is 0 or 4 mod 8; on the page only (4,0) ⊗ (0,4) among the non-trivial splits. (3) Cl(0,0,n) has a nilpotent radical of dimension 2ⁿ − 1 and quotient ℝ; Cl(0,0,8) is not M₁₆(ℝ); the null splits are Grassmann again. (4) e_iΩ is a commuting copy of Cl(p,q,r) for every cell; f_jω_n only for even n without nulls; stable invariants equal; the clock-2 blocks give the mirror. (5) The CAR, the vacuum projector of rank 2ⁿ, the Grassmann Fock space of `chain_fock.py`, the prefix chain.

All of it came out. What the prediction did not say: the counts. The ungraded table differs on 12 065 610 of the 99 507 561 entries of the 3003 pairs, exactly a quarter for each of the 406 pairs of non-empty non-degenerate cells; the two products agree for 235 of the 495 non-degenerate pairs; the brief's construction f_jω_n works in 36 of 114 cases (12 of them with ω_n² = −1, where the copy is the mirrored block), anticommutes in the 18 with odd n and is nilpotent in the 60 with a null generator; with a clock-2 block of row 8 the type moves in 20 of 30 non-degenerate cases; the polar form of the square on J/J² of the ungraded product of (0,0,k) and (0,0,8−k) has 0, 7, 12, 15, 16, 15, 12, 7, 0 non-zero entries (k(8 − k)). And one thing on page 1 that nobody asked: the cells (p,q,0) of even n ≤ 8 that the page does not list are exactly the balanced (1,1,0), (2,2,0), (3,3,0), (4,4,0), whose types M_{2^m}(ℝ) are the column headers.

## 2. The pages

Page 1 (`owner_sketch_period_table.jpg`, our reading, column by column, the null cell first, then the real half, the marker "↓ ℍ", the quaternionic half): n = 0: (0,0,0); n = 2: (0,0,2), (2,0,0) | (0,2,0); n = 4: (0,0,4), (3,1,0) | (4,0,0), (1,3,0), (0,4,0); n = 6: (0,0,6), (4,2,0), (0,6,0) | (6,0,0), (5,1,0), (2,4,0), (1,5,0); n = 8: (0,0,8), (8,0,0), (0,8,0), (1,7,0), (5,3,0) | (7,1,0), (6,2,0), (3,5,0), (2,6,0). The fourth entry of the n = 8 column is written over; we read (1,7,0).

Page 2 (`owner_sketch_chain_splits.jpg`): the nineteen splits of `PAGE2` in the script, "16 × 16" (3,1) ⊗ (1,3), (4,0) ⊗ (0,4), (0,0,4) ⊗ (0,0,4); "2 × 128" (1,0) ⊗ (3,4), (0,1) ⊗ (4,3), (0,0,1) ⊗ (0,0,7); "4 × 64" (2,0) ⊗ (2,4), (0,2) ⊗ (4,2), (0,0,2) ⊗ (0,0,6); "8 × 32" (3,0) ⊗ (1,4), (0,3) ⊗ (4,1), (0,0,3) ⊗ (0,0,5), (2,1) ⊗ (2,3), (1,2) ⊗ (3,2), (2,0,1) ⊗ (1,3,1), (0,2,1) ⊗ (3,1,1); "1 × 256" Cl(0) ⊗ Cl(8,0,0), Cl(0) ⊗ Cl(0,8,0), Cl(0) ⊗ Cl(0,0,8). The second factor of (2,0,1) ⊗ … is over-written; (1,3,1) is our reading, by the symmetry with the line below it. The page writes the types of the factors beside each split: the sixteen written for non-null factors are the label types (`cb.UT`); the four written for null factors (M₄(ℝ) for (0,0,4), M₂(ℝ) for (0,0,2), M₈(ℝ) for (0,0,6), M₁₆(ℝ) for (0,0,8)) are not (`cb.NUL`).

## 3. The question marks, answered on the labels

- **"Cl(0) ⊗ Cl(0,0,8) ⇔ ℝ ⊗ M₁₆(ℝ) ?"** No. Cl(0,0,8) is the Grassmann algebra Λ(ℝ⁸): a nilpotent radical of dimension 255 and the quotient ℝ; M₁₆(ℝ) has no radical. Same dimension, no common structure.
- **"? (0,0,1) ⊗ (0,0,7)"** (and every null split): the graded product is Cl(0,0,8) = Λ(ℝ⁸) again, entry by entry, for every k; the ungraded product of two null cells is a different local algebra.
- **"… ⊗ M₁₆(ℝ) ⊗ M₁₆(ℝ) ⊗ … ⇕ ? … ⊗ M₂₅₆(ℝ) ⊗ …"**: the same finite stages, the second chain read every second step (the prefix of 16k bits is the prefix of 8 · 2k bits; Cl(16) = Cl(8) ⊗ M₁₆(ℝ) = M₂₅₆(ℝ) on the labels). That the completions are one algebra is Glimm's classification (supernatural number 2^∞): cited, not computed.
- **"M₁₆^m(ℝ) ? M_{2^{4k}}(ℝ), k = 0, ¼, ½, ¾, … / k = 0, 1, 2, …"**: M₁₆(ℝ)^{⊗m} = Cl(4m,4m) = M_{2^{4m}}(ℝ), so the integer k = m are the blocks; the fractional k = j/4 are the steps Cl(j,j) = M_{2^j}(ℝ) of the CAR chain between them, each one factor M₂(ℝ) = Cl(1,1).
- **"M₁₆²(ℝ) ⇕ M₁₆¹(ℝ) ⊗ M₁₆(ℝ)"**: yes, explicitly: the prefix Cl(8) of Cl(16) has a commutant of 256 blades, a copy of M₁₆(ℝ).
- **The splits from "16 × 16" to "1 × 256"**: every one is its sum cell as a graded product (Cl(4,4) = M₁₆(ℝ) for the ten non-null splits of Cl(4,4), Cl(3,3,2) for the two mixed, Λ(ℝ⁸) for the five null); as ungraded products only (4,0) ⊗ (0,4) and the 1 × 256 splits are M₁₆(ℝ): (3,1) ⊗ (1,3), (2,0) ⊗ (2,4), (0,2) ⊗ (4,2) give M₈(ℍ), the six with an odd factor M₈(ℂ) ⊕ M₈(ℂ).
- **Page 1's null cells**: none has its column's type except (0,0,0) = ℝ (radical 2⁰ − 1 = 0).

## 4. What ran

| id | what | route | scope |
|---|---|---|---|
| cb.GT | concatenation = graded tensor product; canonical relabelling; the ungraded control | the vectorised kernel formula, equal to `BR.s` on every entry (all ε ∈ {−1,0,1}^N, N ≤ 4; the 45 cells of n = 8) and on 48 048 sampled entries; exact int8 tables | 3003 pairs of cells, n₁ + n₂ ≤ 8, 99 507 561 entries; the 19 splits of page 2 |
| cb.UT | the type of the ungraded and of the graded product | the label type: central blades, their squares, the count Σ e_a² (the sign of the type, cat·K4c), dimension; against `core_check.TYPE` and the multiplication of division algebras | 495 pairs of non-degenerate cells; the page's splits listed |
| cb.NUL | the radical of the null cells; the question marks; page 1 | the two-sided ideal of blades by closure; its powers; the radical of the trace form tr(L_{xy}); the wedge table; the polar form of x ↦ x² mod J³ on J/J² | Cl(0,0,n), n ≤ 8; all 165 cells n ≤ 8; the null splits k = 0..8 |
| cb.P8 | Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) as a map | signed blades with `BR.s`; the block's idempotent in `Fraction`s | 35 cells n ≤ 4 and the three row-8 cells × the blocks (8,0,0), (0,8,0), (4,4,0): 114 cases |
| cb.ST | clock, type, radical, ABS class at n and n + 8 | label types up to 18 generators (the count by the kernel formula, the central blades by the reordering counts); the ABS class from the types, the swap checked on the labels | 165 cells × 3 blocks = 495 cases; the ABS class on the 45 cells (p,q,0), 135 shifted cases; (0,k), k ≤ 16 |
| cb.CH | prefixes Cl(8) ⊂ Cl(16) ⊂ Cl(24); Cl(j,j) | prefix products; commutants by the reordering counts (BR on samples); the count of Cl(24) from the graded diagonal (BR on 2000 labels) | 9 + 5 cells of n = 16; Cl(8,8) ⊂ Cl(24) with each block; j ≤ 8 |
| cb.CAR | Witt basis, vacuum, Fock module, prefix chain | `BR.mul` with `Fraction`s; the Fock matrices by matching ± basis states | n = 1..5 (the chain n ≤ 4); fock_encodings' order n ≤ 5 (tables n ≤ 4) |

## 5. Controls

Six `[ctl]` lines in the main run: the ungraded table differs exactly where predicted and its cross-block generators commute (`cb.GT`); the ungraded Kronecker construction gives the ungraded table and breaks the relations at all 210 cross pairs of the nineteen splits; the ungraded product of two null cells is not Λ(ℝ⁸); a cell with one generator of square ±1 among nulls has the smaller radical 2ⁿ − 2 and quotient ℝ ⊕ ℝ or ℂ; the clock-2 cells Cl(5,3), Cl(1,7) are M₁₆(ℝ) but their top blade squares to −1, the copy is the mirror and the type moves in 20 of 30 cases. Nine `--fault` options put a wrong version in the main lines; each exits 1 through its FAILS line (`logs/chain_blocks.faults.log`): UNGRADED (no cross sign), CROSSORDER ((−1)^{|a₁||b₂|}), HH (ℍ ⊗ ℍ = ℍ), NULLTYPE (the page's reading of the null cell: no radical), NOOMEGA (e_i′ = e_i), OMEGAFIRST (the brief's f_jω_n for every cell), CLOCK2 (the block (5,3,0)), NOSWAP (the restriction to a two-summand cell without the swap: ℤ ⊕ ℤ₂ where ℤ stands), WITT (f_i² = +1).

## 6. The standard route

Never the labels: real 2 × 2 matrices X, J, X + J (squares +1, −1, 0) on one site per generator with Z strings, Kronecker products; the graded tensor product of two representations as (g ⊗ 1, Z⋯Z ⊗ g′) and the ungraded one as (g ⊗ 1, 1 ⊗ g′). The sign tables read from the products (whole matrices for n₁ + n₂ ≤ 5, the images of |0…0⟩ with the relations checked generator by generator at n = 8); the types from the signature of the trace form Tr(W_aW_b), the centre as a null space (random projections at n = 8), the summands from the eigenvalues of a random central element; the three blocks as 16 × 16 matrices (the four-shift) whose 256 words have rank 256; γ ⊗ Ω, 1 ⊗ g as Cl(n+8); Jordan–Wigner σ⁻ with Z strings for the CAR. Agreement: `bit==std` on 462 + 19 tables, 95 types, the Fock matrices for n ≤ 5.

## 7. Proposed rows (apply.json)

| id | title | evidence | placed |
|---|---|---|---|
| GEN-010 | The concatenation is the graded tensor product, every pair to n = 8 | cb.GT | rule, ideas, 24 |
| GEN-011 | The ungraded product beside the graded one: types, and the page's splits | cb.UT | cells, cards, 66 |
| GEN-012 | The null cells are Grassmann algebras: the radical, the question marks, page 1 | cb.NUL | cells, cards, 67 |
| GEN-013 | Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) as a map on the labels, and the stable invariants | cb.P8, cb.ST | rule, ideas, 25 |
| GEN-014 | The chain of blocks as prefixes of the label | cb.CH | rule, ideas, 26 |
| GEN-015 | The CAR algebra on the labels | cb.CAR | rule, ideas, 27 |
| GEN-016 | The finite block is all the limit keeps (ours, reading) | cb.ST, cb.CH, cb.P8 | rule, ideas, 28; cells, cards, 68 |

All `since: "v2.11"`, group GEN, kind computation (GEN-016 reading), research texts in `apply.json` with status draft. GEN-0xx continues GEN-009 (the GEN-5xx ids are the story block; GEN-010 and above are unused anywhere in the repository).

## 8. Not done

- The limit: the union of the stages, its completion, the CAR algebra as a C*-algebra; Glimm's classification is cited for the identification of the two chains' completions, not proved or computed.
- The explicit isomorphism is checked for cells with n ≤ 4 and the three row-8 cells; for 5 ≤ n ≤ 8 the invariants are checked (`cb.ST`), not the map. The Kronecker route checks the relations for n ≤ 4 and the full rank only for n ≤ 1. At n = 24 the commutant and the count are computed through the parity reduction and the graded diagonal, each checked against the kernel on samples, not by enumerating the 2^24 labels.
- The ABS class at n + 8 is computed from the label types and the swap, not from minimal left ideals as in `abs_ring.py` and ATY-001; the two agree where they overlap (ATY-001's list for p + q ≤ 7, abs.R1 along (0,k)).
- The Atiyah–Bott–Shapiro construction of the periodicity (their own map) is not reproduced; the map here is e_i ↦ e_iΩ.
- The ungraded type of the degenerate splits is that of their semisimple quotients; the radical of the ungraded product is counted, its structure not compared beyond the square on J/J² for the null cells.
- Which split a physical system uses (fibre and base, left and right, the owner's words): an input, as the signature is (INP-011); nothing here says that nature is finite or discrete.
