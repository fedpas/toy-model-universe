#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round10/apply_pass8c.py -- applies pass 8c of the proofs round (docs/round10/pass8c/apply.json, the chain of Cl(8)'s on the labels) to the
tables and the Atiyah analysis page.

Modelled on docs/round10/apply_pass8.py. Idempotent: a second run writes the same bytes. In order:
  1 content/rows.json        GEN-010 ... GEN-016 after GEN-009, group GEN, since v2.11 (the seven ids are free: GEN-001 ... GEN-009 and the story
                             rows GEN-5xx stand; a row that holds one of the seven ids and is not an earlier copy of this pass stops the script)
  2 content/texts.json       their research texts (status draft, source pass8c:chain-blocks) after the last text of GEN-009 (the order by row)
  3 content/checks.json      the check record of checks/selfcheck/proofs/chain_blocks.py (cb.GT ... cb.CAR), after shifted_einstein.py
  4 content/check_runs.json  its run record (the stored log's last two lines and the nine fault runs of the fault log are checked against it)
  5 content/lenses.json      two entries of the dictionary of the lens atiyah (98 -> 100) and four of the lens alg (128 -> 132)
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence)
  7 content/analyses.json    the seven check ids cb.* join the list of the entry atiyah; the file is read again just before it is written and only
                             that list is touched, as text, so every other entry keeps its bytes
  8 public/reports/analyses/src/atiyah_lens.md   section 9: item 29 after item 28, the clause of its first paragraph, the passes of the items;
                             theme 1, *The Atlas.* (with the scope of the explicit map, as item 29 prints it); paper 175, *Limits.*; the sources (the
                             script, Glimm's paper); the lens record (100 entries, 29 from the checks of section 9, the readings counted from the
                             regenerated table); the learner texts that the list of what is not done names (the rows of item 29 among them)
  9 node tools/make_analysis.mjs atiyah    renders the page
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round10/apply_pass8c.py [--no-node]    --no-node skips steps 6 and 9 (and leaves the count of readings of step 8)
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
C = json.load(open(os.path.join(HERE, 'pass8c', 'apply.json'), encoding='utf-8'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
IDS = [r['id'] for r in C['rows']]
SRC = 'pass8c:chain-blocks'
SCRIPT = C['files']['script']
CB = ['cb.GT', 'cb.UT', 'cb.NUL', 'cb.P8', 'cb.ST', 'cb.CH', 'cb.CAR']
FAULTS = ['UNGRADED', 'CROSSORDER', 'HH', 'NULLTYPE', 'NOOMEGA', 'OMEGAFIRST', 'CLOCK2', 'NOSWAP', 'WITT']
N = 29   # the number of the item of section 9: after pass 8b's items 24 to 28
said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def save(rel, data, newline):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')
    old = open(path(rel), encoding='utf-8').read()
    if text != old:
        open(path(rel), 'w', encoding='utf-8').write(text)
        said.append(f'wrote {rel}')
    else:
        said.append(f'unchanged {rel}')


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


assert C['pass'] == 'round10/pass8c' and C['since'] == 'v2.11'
assert IDS == [f'GEN-0{k}' for k in range(10, 17)], IDS
assert not C['row_text_edits'], 'pass 8c proposes no edit of a research text'
assert C['files']['script'] == 'checks/selfcheck/proofs/chain_blocks.py'

# ---- 1 rows: the seven ids must be free (or hold an earlier copy of this pass); out with that copy, in again after GEN-009
rows, nl = load('content/rows.json')


def earlier_copy(r):
    return r.get('since') == 'v2.11' and r.get('group') == 'GEN' and bool(r.get('evidence')) and all(e.get('script') == SCRIPT for e in r['evidence'])


clash = [r['id'] for r in rows if r['id'] in IDS and not earlier_copy(r)]
if clash:
    sys.exit(f'the ids {clash} are taken by other rows of content/rows.json: renumber the pass from the next free GEN id')
rows = [r for r in rows if r['id'] not in IDS]
WHERE = {'GEN-010': [('rule', 'ideas', 24)], 'GEN-011': [('cells', 'cards', 66)], 'GEN-012': [('cells', 'cards', 67)],
         'GEN-013': [('rule', 'ideas', 25)], 'GEN-014': [('rule', 'ideas', 26)], 'GEN-015': [('rule', 'ideas', 27)],
         'GEN-016': [('rule', 'ideas', 28), ('cells', 'cards', 68)]}
for r in C['rows']:
    assert r['since'] == 'v2.11' and r['group'] == 'GEN', r['id']
    assert r['kind'] == ('reading' if r['id'] == 'GEN-016' else 'computation'), r['id']
    assert [(s['page'], s['section'], s['order']) for s in r['shownOn']] == WHERE[r['id']] and all(s['role'] == 'detail' for s in r['shownOn']), r['id']
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])}
assert not any((s['page'], s['order']) in taken for r in C['rows'] for s in r['shownOn']), 'an order of the pass is taken'
at = next(i for i, r in enumerate(rows) if r['id'] == 'GEN-009')
rows[at + 1:at + 1] = C['rows']
ids = {r['id'] for r in rows}
thm = {t['id'] for t in json.load(open(path('content/theorems.json'), encoding='utf-8'))}
for r in C['rows']:
    for d in r['depends']:
        assert d['id'] in ids or d['id'] in thm, f"{r['id']} depends on an unknown row {d['id']}"
    for e in r['evidence']:
        assert e['mode'] == 'ran' and e['script'] == SCRIPT and e['check'] in CB, r['id']
save('content/rows.json', rows, nl)

# ---- 2 texts: the research texts of the seven, after the last text of GEN-009
texts, nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine = {key(t) for t in C['texts']}
texts = [t for t in texts if key(t) not in mine]
assert sorted(t['row'] for t in C['texts']) == IDS, 'one research text per row'
for t in C['texts']:
    assert (t['status'], t['source'], t['level'], t['lens'], t['mode'], t['register'], t['lang']) == ('draft', SRC, 'research', None, 'both', 'full', 'en'), t['row']
    assert not re.search(r'/home/|@[\w-]+\.\w', t['body']), f"{t['row']}: a machine path or a contact detail"
assert not any(t['row'] in IDS for t in texts), 'another text of the seven rows stands in content/texts.json'
at = max(i for i, t in enumerate(texts) if t['row'] == 'GEN-009')
texts[at + 1:at + 1] = sorted(C['texts'], key=lambda t: IDS.index(t['row']))
save('content/texts.json', texts, nl)

# ---- 3 the check record (after the last record, shifted_einstein.py)
checks, nl = load('content/checks.json')
cids = [c['id'] for c in C['checks']]
checks = [c for c in checks if c['id'] not in cids]
assert checks[-1]['id'] == 'selfcheck/proofs/shifted_einstein.py', checks[-1]['id']
assert not any(x['id'] in CB for c in checks for x in c.get('ids') or []), 'a cb.* id in another record'
for c in C['checks']:
    assert c['since'] == 'v2.11' and c['script'] == SCRIPT and [x['id'] for x in c['ids']] == CB and c['rowsNaming'] == IDS, c['id']
    assert all(os.path.exists(path(c[k])) for k in ('script', 'log')) and os.path.exists(path(C['files']['faultLog'])), c['id']
checks += C['checks']
save('content/checks.json', checks, nl)

# ---- 4 the run record: the stored log ends with the record's last line and its tally; the fault log holds the nine wrong versions, each exit 1
runs, nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine = {rk(r) for r in C['check_runs']}
runs = [r for r in runs if rk(r) not in mine] + C['check_runs']
log = open(path(C['files']['log']), encoding='utf-8').read().rstrip('\n').split('\n')
assert log[-2] == '58 checks (bit 42, bit==std 4, ctl 6, std 6), 0 FAIL', log[-2]
for r in C['check_runs']:
    assert r['script'] == SCRIPT and r['source'] == C['files']['log'], r['script']
    assert r['passed'] is True and r['ok'] == 58 and r['fail'] == 0 and r['lastLine'] == log[-1] == 'FAILS (CHAIN-BLOCKS): none', r['script']
flog = open(path(C['files']['faultLog']), encoding='utf-8').read()
assert re.findall(r'^--fault (\w+): exit 1$', flog, re.M) == FAULTS, 'the fault log: the nine wrong versions, each exit 1'
save('content/check_runs.json', runs, nl)

# ---- 5 the lenses: atiyah (two entries) and alg (four)
lenses, nl = load('content/lenses.json')
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows'] and e['atlas'] == f['atlas']
for blk, n0 in ((C['lens'], 98), (C['lens_alg'], 128)):
    lens = next(x for x in lenses if x['key'] == blk['key'])
    add = blk['dictionary_add']
    for e in add:
        assert set(e['evidence']) <= set(CB) and set(e['rows']) <= set(IDS) and e['flags'] == ['checked'], (blk['key'], e['atlas'][:40])
    keep = [e for e in lens['dictionary'] if not any(same(e, f) for f in add)]
    assert len(keep) == n0, (blk['key'], len(keep))
    lens['dictionary'] = keep + add
    said.append(f"the lens {blk['key']}: {n0} -> {len(lens['dictionary'])} dictionary entries")
save('content/lenses.json', lenses, nl)
aty_dict = next(x for x in lenses if x['key'] == 'atiyah')['dictionary']

# ---- 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ---- 7 the analyses registry: the check ids of the entry atiyah, as text (read again now, written back at once)
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
assert C['analyses'][0]['id'] == 'atiyah' and C['analyses'][0]['checks_add'] == CB
text = raw
m = re.search(r'\n(\s*)"id": "atiyah",', text)
assert m, 'the entry atiyah of content/analyses.json'
c = text.index('"checks": [', m.end())
end = text.index(']', c)
body = text[c + len('"checks": ['):end]
have = json.loads('[' + body + ']')
want = [x for x in CB if x not in have]
if want:
    ind = re.search(r'\n(\s*)"', body).group(1)
    stripped = body.rstrip()
    new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
    text = text[:c] + '"checks": [' + new_body + text[end:]
if text != raw:
    after = json.loads(text)
    a_old = next(x for x in before if x.get('id') == 'atiyah')
    a_new = next(x for x in after if x.get('id') == 'atiyah')
    assert a_new['checks'] == a_old['checks'] + want and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') != 'atiyah'] == [x for x in before if x.get('id') != 'atiyah']
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (atiyah gains {len(want)} check ids)')
else:
    said.append(f'unchanged {rel}')

# ===================================================================================================================== 8 the Atiyah page
P = C['analyses'][0]
rel = P['source']
assert rel == 'public/reports/analyses/src/atiyah_lens.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md
fill = lambda s: s.replace('{n}', str(N))
assert P['section9_numbering'].startswith('R2: {n} = 29,')

# section 9's item 29, after item 28
items = [fill(s) for s in P['section9_items']]
assert len(items) == 1 and items[0].startswith(f'{N}. ') and '\n' not in items[0] and '{n' not in items[0]
lines = md.split('\n')
i28 = next(i for i, l in enumerate(lines) if l.startswith('28. *The radius on de Sitter*'))
if lines[i28 + 1:i28 + 1 + len(items)] != items:
    assert not any(l.startswith(f'{N}. ') for l in lines), f'an item {N} stands elsewhere'
    lines[i28 + 1:i28 + 1] = items
md = '\n'.join(lines)

# the six sentences of the pass, each in its place (every phrase to replace occurs once); theme 1's map gets the scope item 29 prints
WHERE_ED = ['section 5, theme 1, *The Atlas.*', 'section 6, paper 175, *Limits.*', 'section 9, first paragraph', 'section 9, first paragraph',
            'Sources, the Atlas', 'Sources, section 9']
assert [e['where'] for e in P['edits']] == WHERE_ED
MAP = 'so Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) explicitly, and clock'
MAP_SCOPED = 'so Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) explicitly (the map checked for the cells with n ≤ 4 and the three row-8 cells, each with the three blocks), and clock'
for e in P['edits']:
    repl = fill(e['replace'])
    if e['where'] == 'section 5, theme 1, *The Atlas.*':
        assert repl.count(MAP) == 1
        repl = repl.replace(MAP, MAP_SCOPED)
    md = swap(md, e['find'], repl, e['where'])

# section 7, the lens record: the entries of the dictionary, those from the checks of section 9 (their source names a pass), the readings
n_dict = len(aty_dict)
n_sec9 = sum(1 for e in aty_dict if re.search(r'\(pass [^)]*\)$', e['from']))
assert (n_dict, n_sec9) == (100, 29), (n_dict, n_sec9)
assert md.count('28 entries from the narrative and the map above, 43 from the five readings,') == 1 and 28 + 43 + n_sec9 == n_dict
md = re.sub(r'carries a dictionary of \d+ entries', f'carries a dictionary of {n_dict} entries', md)
md = re.sub(r'\d+ from the checks of section 9\.', f'{n_sec9} from the checks of section 9.', md)
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')

# section 9, what is not done: the learner texts not written, the rows of item 29 among them
md = swap(md, 'learner texts for the rows of items 19 to 28 (ATY-042 to ATY-047, ATY-051 to ATY-055; the rows ATY-001 to ATY-041 have learner drafts).',
          f'learner texts for the rows of items 19 to {N} (ATY-042 to ATY-047, ATY-051 to ATY-055, GEN-010 to GEN-016; the rows ATY-001 to ATY-041 '
          'have learner drafts).', 'the learner texts not written')

for must in (items[0], f'24 to 28 pass 8b, {N} pass 8c.', '(seven rows, GEN-010 to GEN-016); each has', MAP_SCOPED, f'(`chain_blocks.py`, section 9 item {N}).',
             'with the map Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) on the labels (GEN-013, section 9 item 29).', '`shifted_einstein.py`, `chain_blocks.py` with their logs',
             f'for item {N}, J. Glimm, *On a certain class of operator algebras*', f'carries a dictionary of {n_dict} entries',
             f'{n_sec9} from the checks of section 9.', f'items 19 to {N} (ATY-042 to ATY-047, ATY-051 to ATY-055, GEN-010 to GEN-016;'):
    assert md.count(must) == 1, must
assert md.count(f'section 9 item {N})') == 2, 'theme 1 and paper 175 point to item 29'
assert not any(p in md for p in ('{n}', 'R2:', 'N readings on M rows')), 'a placeholder or a note of the passes left on the page'
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 9 the page
if not NO_NODE:
    out = subprocess.run(['node', 'tools/make_analysis.mjs', 'atiyah'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout)
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
