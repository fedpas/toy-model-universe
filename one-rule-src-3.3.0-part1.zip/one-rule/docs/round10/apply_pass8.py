#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""docs/round10/apply_pass8.py -- applies passes 8a and 8b of the proofs round (docs/round10/pass8a/apply.json, the energy of the shifted theory
completed; docs/round10/pass8b/apply.json, the shifted Einstein equations and the fifth generator) to the tables and the two analysis pages.

Modelled on docs/round9/pass7/apply_pass7.py. Idempotent: a second run writes the same bytes. In order:
  1 content/rows.json        ATY-042 ... ATY-047 (8a) after ATY-041 and ATY-051 ... ATY-055 (8b) after ATY-047, group ATY, since v2.10
  2 content/texts.json       their research texts (status draft; sources pass8a:shifted-tensor and pass8b:shifted-einstein), each pass after the
                             last text of the row before it (the order tools/merge_learner_texts.mjs keeps: by row); the two edits of 8b's
                             row_text_edits to the research text of ATY-010 (each says "not checked" or "not compared" where a new row checks or
                             compares: an addition of scope that ATY-051 and ATY-054 prove, the claim of ATY-010 unchanged), and the same two
                             places of ATY-010's learner draft (content/texts_learner_aty.json and its merged copy in texts.json), so that the
                             learner text keeps translating its research text
  3 content/checks.json      the check records of checks/selfcheck/proofs/shifted_tensor.py (st.*) and shifted_einstein.py (se.*), after shifted_energy.py
  4 content/check_runs.json  their run records
  5 content/lenses.json      eleven entries of the dictionary of the lens atiyah (87 -> 98)
  6 node tools/migrate/lens_readings.mjs   regenerates content/lens_readings.json (the readings attach by evidence, and ATY-047's by its phrase)
  7 content/analyses.json    the 25 check ids st.* and se.* join the lists of the entries atiyah and shifted_view; the file is read again just before it
                             is written and only those two lists are touched, as text, so every other entry keeps its bytes
  8 public/reports/analyses/src/atiyah_lens.md     section 9: items 19 to 23 (8a) and 24 to 28 (8b, numbered here), its first paragraph with
                             both scripts, the list of what is not done rewritten to what both passes leave; the limits of paper 177 (both passes);
                             what the paper says on (4.3) (8b); the lens record (98 entries, 27 from section 9, the readings counted from the
                             regenerated table); the sources
  9 public/reports/analyses/src/shifted_view.md    steps 5, 6b, 6c (8a), steps 7 and 8 (8b), the glance table, "What this reading does not do",
                             the references, the status words, Q1 (8b), the sources; the sentences that both passes edit are merged here into one,
                             and the few sentences elsewhere on the page that the two passes leave behind (a computation named as not run that now
                             ran) are brought into line
 10 node tools/make_analysis.mjs atiyah, shifted_view    renders both pages
Each table keeps its own JSON form (indent 1, UTF-8, with or without the final newline it had).
Usage (from anywhere): python3 docs/round10/apply_pass8.py [--no-node]    --no-node skips steps 6 and 10 (and leaves the counts of step 8)
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, '..', '..'))
A = json.load(open(os.path.join(HERE, 'pass8a', 'apply.json'), encoding='utf-8'))
B = json.load(open(os.path.join(HERE, 'pass8b', 'apply.json'), encoding='utf-8'))
NM = os.environ.get('NODE_MODULES') or '/opt/npm-tools/node_modules'
NO_NODE = '--no-node' in sys.argv
IDS_A = [r['id'] for r in A['rows']]
IDS_B = [r['id'] for r in B['rows']]
SRC_A, SRC_B = 'pass8a:shifted-tensor', 'pass8b:shifted-einstein'
said = []


def path(rel):
    return os.path.join(ROOT, rel)


def load(rel):
    raw = open(path(rel), encoding='utf-8').read()
    return json.loads(raw), raw.endswith('\n')


def save(rel, data, newline):
    text = json.dumps(data, ensure_ascii=False, indent=1) + ('\n' if newline else '')
    old = open(path(rel), encoding='utf-8').read()
    if text != old:
        open(path(rel), 'w', encoding='utf-8').write(text)
        said.append(f'wrote {rel}')
    else:
        said.append(f'unchanged {rel}')


def swap(text, find, repl, what):
    """replace the one occurrence of find by repl; a second run finds repl in place and changes nothing"""
    if repl in text and (find not in text or find in repl):
        return text
    assert text.count(find) == 1, f'{what}: the phrase to replace is not there once ({text.count(find)} times): {find[:90]!r}'
    return text.replace(find, repl)


assert A['since'] == B['since'] == 'v2.10'

# ---- 1 rows: out with any earlier copy of the eleven, in again after ATY-041 (8a) and after ATY-047 (8b)
rows, nl = load('content/rows.json')
rows = [r for r in rows if r['id'] not in IDS_A + IDS_B]
for k, r in enumerate(A['rows']):
    assert r['since'] == 'v2.10' and r['group'] == 'ATY' and r['kind'] in ('computation', 'reading'), r['id']
    assert [(s['page'], s['section'], s['order'], s['role']) for s in r['shownOn']] == [('steps/coupling', 'eq-coupling', 1787 + k, 'detail')], r['id']
WHERE_B = {'ATY-051': ('steps/grav2', 'eq-grav2', 1036), 'ATY-052': ('steps/grav2', 'eq-grav2', 1037), 'ATY-053': ('steps/grav2', 'eq-grav2', 1038),
           'ATY-054': ('steps/projective', 'eq-projective', 1040), 'ATY-055': ('steps/projective', 'eq-projective', 1041)}
for r in B['rows']:
    assert r['since'] == 'v2.10' and r['group'] == 'ATY' and r['kind'] == 'computation', r['id']
    assert [(s['page'], s['section'], s['order'], s['role']) for s in r['shownOn']] == [WHERE_B[r['id']] + ('detail',)], r['id']
taken = {(s['page'], s['order']) for r in rows for s in (r.get('shownOn') or [])}
assert not any((s['page'], s['order']) in taken for r in A['rows'] + B['rows'] for s in r['shownOn']), 'an order of the passes is taken'
at = next(i for i, r in enumerate(rows) if r['id'] == 'ATY-041')
rows[at + 1:at + 1] = A['rows']
at = next(i for i, r in enumerate(rows) if r['id'] == 'ATY-047')
rows[at + 1:at + 1] = B['rows']
ids = {r['id'] for r in rows}
for r in A['rows'] + B['rows']:
    for d in r['depends']:
        assert d['id'] in ids, f"{r['id']} depends on an unknown row {d['id']}"
    for e in r['evidence']:
        assert e['mode'] == 'ran' and e['script'] in (A['files']['script'], B['files']['script']), r['id']
save('content/rows.json', rows, nl)

# ---- 2 texts: the research texts of the eleven, each pass after the last text of the row before it
texts, nl = load('content/texts.json')
key = lambda t: (t['row'], t['lang'], t['mode'], t['level'], t['lens'], t['register'])
mine = {key(t) for t in A['texts'] + B['texts']}
texts = [t for t in texts if key(t) not in mine]
for P, src, new in ((A, SRC_A, IDS_A), (B, SRC_B, IDS_B)):
    assert sorted(t['row'] for t in P['texts']) == sorted(new), 'one research text per row'
    for t in P['texts']:
        assert t['status'] == 'draft' and t['source'] == src and t['level'] == 'research' and t['lens'] is None and t['mode'] == 'both', t['row']
at = max(i for i, t in enumerate(texts) if t['row'] == 'ATY-041')
texts[at + 1:at + 1] = A['texts']
at = max(i for i, t in enumerate(texts) if t['row'] == 'ATY-047')
texts[at + 1:at + 1] = B['texts']
# ATY-010, research: the two places that 8b's rows answer (the Weitzenboeck formula checked in ATY-051, the constants compared in ATY-054)
r010 = [t for t in texts if t['row'] == 'ATY-010' and t['level'] == 'research' and t['lens'] is None and t['mode'] == 'both' and t['register'] == 'full']
assert len(r010) == 1
for e in B['row_text_edits']:
    assert e['row'] == 'ATY-010' and e['level'] == 'research'
    r010[0]['body'] = swap(r010[0]['body'], e['find'], e['replace'], 'ATY-010 research text')
# ATY-010, learner: the same two places in the draft's words (no row id, no formula: R4, R13 of tools/check_learner_texts.mjs)
L010 = [('(operator squared plus squared covariant derivative is Ricci; recalled, not checked here)',
         '(operator squared plus squared covariant derivative is Ricci; checked on the labels with its signs)'),
        ('(re-run: 91 pass); the constants are not compared.',
         '(re-run: 91 pass); the constants are compared: 4 times that term is that sign times kappa squared.')]   # within 1.5 x the research text (R9)


def learner010(t):
    for f, r in L010:
        t['body'] = swap(t['body'], f, r, 'ATY-010 learner draft')


l010 = [t for t in texts if t['row'] == 'ATY-010' and t['level'] == 'learner' and t['lens'] is None and t['register'] == 'full']
assert len(l010) == 1 and l010[0]['status'] == 'draft'
learner010(l010[0])
save('content/texts.json', texts, nl)
drafts, dnl = load('content/texts_learner_aty.json')
d010 = [t for t in drafts if t['row'] == 'ATY-010' and t['register'] == 'full']
assert len(d010) == 1
learner010(d010[0])
assert d010[0]['body'] == l010[0]['body'], 'the draft file and its merged copy agree'
save('content/texts_learner_aty.json', drafts, dnl)

# ---- 3 the check records (after the last record, shifted_energy.py)
checks, nl = load('content/checks.json')
cids = [c['id'] for c in A['checks'] + B['checks']]
checks = [c for c in checks if c['id'] not in cids]
assert checks[-1]['id'] == 'selfcheck/proofs/shifted_energy.py', checks[-1]['id']
for c in A['checks'] + B['checks']:
    assert c['since'] == 'v2.10' and c['ids'] and all(os.path.exists(path(c[k])) for k in ('script', 'log')), c['id']
checks += A['checks'] + B['checks']
save('content/checks.json', checks, nl)

# ---- 4 the run records
runs, nl = load('content/check_runs.json')
rk = lambda r: (r['script'], r['date'], r.get('source'))
mine = {rk(r) for r in A['check_runs'] + B['check_runs']}
runs = [r for r in runs if rk(r) not in mine] + A['check_runs'] + B['check_runs']
for r in A['check_runs'] + B['check_runs']:
    assert r['passed'] is True and r['fail'] == 0 and r['lastLine'].endswith(': none'), r['script']
save('content/check_runs.json', runs, nl)

# ---- 5 the lens atiyah: eleven dictionary entries
lenses, nl = load('content/lenses.json')
lens = next(l for l in lenses if l['key'] == 'atiyah')
assert A['lens']['key'] == B['lens']['key'] == 'atiyah'
add = A['lens']['dictionary_add'] + B['lens']['dictionary_add']
same = lambda e, f: e['from'] == f['from'] and e['rows'] == f['rows']
lens['dictionary'] = [e for e in lens['dictionary'] if not any(same(e, f) for f in add)] + add
assert len(lens['dictionary']) == 98, len(lens['dictionary'])
save('content/lenses.json', lenses, nl)

# ---- 6 the lens readings
if not NO_NODE:
    out = subprocess.run(['node', 'tools/migrate/lens_readings.mjs'], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
    sys.stdout.write(out.stdout[-1500:])
    if out.returncode:
        sys.stderr.write(out.stderr)
        sys.exit('lens_readings.mjs failed')
    said.append('ran tools/migrate/lens_readings.mjs')

# ---- 7 the analyses registry: the check ids of both entries, as text (read again now, written back at once)
rel = 'content/analyses.json'
raw = open(path(rel), encoding='utf-8').read()
before = json.loads(raw)
assert A['analyses'][0]['checks_add'] == A['analyses'][1]['checks_add'] and B['analyses'][0]['checks_add'] == B['analyses'][1]['checks_add']
ADD = A['analyses'][0]['checks_add'] + B['analyses'][0]['checks_add']
assert len(ADD) == 25 == len(set(ADD))
text, gained = raw, {}
for aid in ('atiyah', 'shifted_view'):
    m = re.search(r'\n(\s*)"id": "%s",' % aid, text)
    assert m, f'the entry {aid} of content/analyses.json'
    c = text.index('"checks": [', m.end())
    end = text.index(']', c)
    body = text[c + len('"checks": ['):end]
    have = json.loads('[' + body + ']')
    want = [x for x in ADD if x not in have]
    if want:
        ind = re.search(r'\n(\s*)"', body).group(1)
        stripped = body.rstrip()
        new_body = stripped + ''.join(f',\n{ind}{json.dumps(x, ensure_ascii=False)}' for x in want) + body[len(stripped):]
        text = text[:c] + '"checks": [' + new_body + text[end:]
    gained[aid] = want
if text != raw:
    after = json.loads(text)
    for aid in ('atiyah', 'shifted_view'):
        a_old = next(x for x in before if x.get('id') == aid)
        a_new = next(x for x in after if x.get('id') == aid)
        assert a_new['checks'] == a_old['checks'] + gained[aid] and {k: v for k, v in a_new.items() if k != 'checks'} == {k: v for k, v in a_old.items() if k != 'checks'}
    assert [x for x in after if x.get('id') not in ('atiyah', 'shifted_view')] == [x for x in before if x.get('id') not in ('atiyah', 'shifted_view')]
    if open(path(rel), encoding='utf-8').read() != raw:
        sys.exit(f'{rel} changed while this step read it: run again')
    open(path(rel), 'w', encoding='utf-8').write(text)
    said.append(f'wrote {rel} (atiyah gains {len(gained["atiyah"])} check ids, shifted_view {len(gained["shifted_view"])})')
else:
    said.append(f'unchanged {rel}')

# ===================================================================================================================== 8 the Atiyah page
rel = A['analyses'][0]['source']
assert rel == B['analyses'][0]['source'] == 'public/reports/analyses/src/atiyah_lens.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md
EA = {e['where'] + '|' + e['find']: e for e in A['analyses'][0]['edits']}
EB = {e['where'] + '|' + e['find']: e for e in B['analyses'][0]['edits']}
ea = lambda where, start='': next(e for e in A['analyses'][0]['edits'] if e['where'] == where and e['find'].startswith(start))
eb = lambda where, start='': next(e for e in B['analyses'][0]['edits'] if e['where'] == where and e['find'].startswith(start))
done = set()


def take(e):
    done.add(id(e))
    return e


# section 9's items: 19 to 23 (8a) after item 18, then 8b's five numbered 24 to 28
items_a = A['analyses'][0]['section9_items']
N0 = 19 + len(items_a)
items_b = [s.replace('{n}', str(N0 + k), 1) for k, s in enumerate(B['analyses'][0]['section9_items'])]
assert all(s.startswith(f'{19 + k}. ') for k, s in enumerate(items_a)) and all(s.startswith(f'{N0 + k}. ') for k, s in enumerate(items_b))
assert not any('\n' in s or '{n' in s for s in items_a + items_b), 'one line per item, every number filled'
N1, N5 = N0, N0 + len(items_b) - 1
assert (N1, N5) == (24, 28)
fill = lambda s: s.replace('{n1}', str(N1)).replace('{n5}', str(N5))
lines = md.split('\n')
i18 = next(i for i, l in enumerate(lines) if l.startswith('18. *The one-dimensional equations at rest*'))
items = items_a + items_b
if lines[i18 + 1:i18 + 1 + len(items)] != items:
    assert not any(l.startswith(tuple(f'{k}. ' for k in range(19, 29))) for l in lines), 'items 19 to 28 stand elsewhere'
    lines[i18 + 1:i18 + 1] = items
md = '\n'.join(lines)

# section 9, first paragraph: both scripts in one sentence, both ranges of items
s1a, s1b = take(ea('section 9, first paragraph', 'and a twelfth')), take(eb('section 9, first paragraph', 'and a twelfth'))
assert s1a['find'] == s1b['find']
md = swap(md, s1a['find'],
          'and a twelfth carries the shifted theory past the map (four rows, ATY-038 to ATY-041), which `shifted_tensor.py` completes with the tensor for '
          'fields of space and time, its symmetric form, the complex modes and a gradient (six rows, ATY-042 to ATY-047), while `shifted_einstein.py` '
          'computes sections 3 and 4 of paper 177, the shifted Einstein equations and the fifth generator (five rows, ATY-051 to ATY-055); each has',
          'section 9, first paragraph')
r1a, r1b = take(ea('section 9, first paragraph', 'Items 1 to 10')), take(eb('section 9, first paragraph', 'Items 1 to 10'))
assert r1a['find'] == r1b['find']
md = swap(md, r1a['find'], f'Items 1 to 10 are pass five, 11 to 14 pass six, 15 to 18 pass seven, 19 to 23 pass 8a, {N1} to {N5} pass 8b.', 'the passes of the items')

# section 6, paper 177: what the paper says (8b) and the limits (8a, then 8b)
e = take(eb('section 6, paper 177, What the paper says'))
md = swap(md, e['find'], e['replace'], e['where'])
e = take(ea('section 6, paper 177, Limits'))
md = swap(md, e['find'], e['replace'], e['where'])
e = take(eb('section 6, paper 177, Limits'))
md = swap(md, e['find'], e['replace'], e['where'])

# section 9, what is not done: rewritten to what both passes leave (8a's part, 8b's part, and the learner texts: T1 drafted ATY-001 ... ATY-041)
na, nb = take(ea('section 9, the "Not done" paragraph')), take(eb('section 9, the "Not done" paragraph'))
NOT_DONE_OLD = ('Not done: the Atiyah–Bott–Shapiro paper in the original (the expositions stand in for it); the Atiyah–Sutcliffe conjecture beyond n = 4 and '
                'beyond points; an Einstein edge-cone metric off the family (5.6), and the ℂP² # k cones themselves; ' + na['find'] +
                " Feynman's thesis, which the paper cites for a conserved energy with retardation (item 18 cites it as the literature pass reports it); " +
                nb['find'] + ' learner texts for the ATY rows.')
NOT_DONE = ('Not done: the Atiyah–Bott–Shapiro paper in the original (the expositions stand in for it); the Atiyah–Sutcliffe conjecture beyond n = 4 and '
            'beyond points; an Einstein edge-cone metric off the family (5.6), and the ℂP² # k cones themselves; ' + na['replace'] +
            " Feynman's thesis, which the paper cites for a conserved energy with retardation (item 18 cites it as the literature pass reports it); " +
            fill(nb['replace']) + f' learner texts for the rows of items 19 to {N5} (ATY-042 to ATY-047, ATY-051 to ATY-055; the rows ATY-001 to ATY-041 '
            'have learner drafts).')
assert '{n1}' not in NOT_DONE and '{n5}' not in NOT_DONE
md = swap(md, NOT_DONE_OLD, NOT_DONE, 'the list of what is not done')

# section 7, the lens record: 87 + 6 + 5 entries, 16 + 6 + 5 of them from section 9
for w, f in (('section 7, the lens record', 'carries a dictionary'), ('section 7, the lens record', '16 from')):
    x, y = take(ea(w, f)), take(eb(w, f))
    assert x['find'] == y['find']
md = swap(md, 'carries a dictionary of 87 entries', 'carries a dictionary of 98 entries', 'the lens record, entries')
md = swap(md, '16 from the checks of section 9.', '27 from the checks of section 9.', 'the lens record, section 9')
take(eb('section 7, the lens record', 'The result is'))   # the counts: from the regenerated table, below

# the sources: both scripts; the paper as each pass read it
x, y = take(ea('Sources, the Atlas')), take(eb('Sources, the Atlas'))
assert x['find'] == y['find']
md = swap(md, x['find'], '`shifted_energy.py`, `shifted_tensor.py`, `shifted_einstein.py` with their logs and fault logs.', 'the sources, the Atlas')
e = take(ea('Sources, section 9'))
md = swap(md, e['find'], e['replace'], e['where'])
SRC7 = '- For section 9, pass seven and pass 8a: M. F. Atiyah and G. W. Moore,'
SRC8B = ('- For section 9, pass 8b: M. F. Atiyah and G. W. Moore, *A shifted view of fundamental physics* (arXiv:1009.3176, pages 8–12 read: '
         'sections 3 and 4, with (3.1)–(3.11) and (4.1)–(4.4)); the Weitzenböck formula on 1-forms and the warped-product reduction of the Ricci '
         'tensor are recalled and checked on the labels, not read from a source.')
if SRC8B not in md:
    lines = md.split('\n')
    j = next(i for i, l in enumerate(lines) if l.startswith(SRC7))
    lines[j + 1:j + 1] = [SRC8B]
    md = '\n'.join(lines)
left = [e for e in A['analyses'][0]['edits'] + B['analyses'][0]['edits'] if id(e) not in done]
assert not left, [e['where'] for e in left]

# the lens record: the counts of the readings of the lens atiyah, from the regenerated table
if not NO_NODE:
    lr = json.load(open(path('content/lens_readings.json'), encoding='utf-8'))
    a = [r for r in lr if r['lens'] == 'atiyah']
    n_read, n_rows = len(a), len({r['row'] for r in a})
    md = re.sub(r'The result is \d+ readings on \d+ rows\.', f'The result is {n_read} readings on {n_rows} rows.', md)
    said.append(f'the lens atiyah: {n_read} readings on {n_rows} rows')
for must in ('carries a dictionary of 98 entries', '27 from the checks of section 9.', f'19 to 23 pass 8a, {N1} to {N5} pass 8b.', 'ATY-051 to ATY-055); each has',
             '*Done (pass 8a): ATY-042 to ATY-046', '*Done (pass 8b): ATY-051 checks', 'pass 8b maps the constants, 4c = εκ²', NOT_DONE, SRC8B,
             '`shifted_energy.py`, `shifted_tensor.py`, `shifted_einstein.py` with their logs and fault logs.'):
    assert md.count(must) == 1, must
assert not any(p in md for p in ('{n}', '{n1}', '{n5}', 'R2:', 'N readings on M rows')), 'a placeholder or a note of the passes left on the page'
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ===================================================================================================================== 9 the page shifted_view
SA, SB = A['analyses'][1], B['analyses'][1]
rel = SA['source']
assert rel == SB['source'] == 'public/reports/analyses/src/shifted_view.md'
md = open(path(rel), encoding='utf-8').read()
md0 = md


def section(md, head, nxt):
    """the text of a step from its heading to the next heading of the same level"""
    i = md.index(head)
    j = md.index(nxt, i + len(head))
    return i, j


def part(md, step_head, next_head, name):
    """the bullets of the part '### <name>' of a step: (start, end) of the block between the part's heading and the next heading"""
    i, j = section(md, step_head, next_head)
    h = md.index(f'### {name}\n\n', i)
    assert h < j
    s = h + len(f'### {name}\n\n')
    e = md.index('\n\n###', s) if md.find('\n\n###', s, j) >= 0 else j - 2
    return s, e


def insert_before(md, anchor, bullets, what):
    block = '\n'.join(bullets) + '\n'
    if block + anchor in md:
        return md
    assert md.count(anchor) == 1 and not any(b in md for b in bullets), what
    return md.replace(anchor, block + anchor)


# -- step 5 (8a): the tensor, packets, Lorentz currents and Belinfante, the energy off the modes; the energy's last sentence; taken forward
md = insert_before(md, SA['step5_on_the_labels_add']['insert_before'], SA['step5_on_the_labels_add']['bullets'], 'step 5, on the labels')
ED = {e['where']: e for e in SA['step_edits']}
for w in ('step 5, On the labels, the energy', 'step 5, Taken forward', 'step 6c, Taken forward'):
    md = swap(md, ED[w]['find'], ED[w]['replace'], w)
# -- step 6b (8a): the roots of the spinor equation (the row's status at its first mention in the part), the Fock-space bullet
b6b = [b.replace('(ATY-045; `st.SYMB`', '(ATY-045, proved by the Atlas; `st.SYMB`', 1) for b in SA['step6b_on_the_labels_add']['bullets']]
assert b6b != SA['step6b_on_the_labels_add']['bullets']
md = insert_before(md, SA['step6b_on_the_labels_add']['insert_before'], b6b, 'step 6b, on the labels')
e = ED['step 6b, On the labels, Fock space']
md = swap(md, e['find'], e['replace'].replace('(ATY-046, step 6c)', '(ATY-046, proved by the Atlas; step 6c)'), e['where'])
# -- step 6c (8a): a potential with a gradient
md = insert_before(md, SA['step6c_on_the_labels_add']['insert_before'], SA['step6c_on_the_labels_add']['bullets'], 'step 6c, on the labels')

# -- step 7 (8b): the list "On the labels" in 8b's order, the bullets kept from the page as they stand (with 8b's edit of the constant terms),
#    the bullet that said the identity is not computed taken out; "Taken forward" as 8b writes it
OB = {e['where']: e for e in SB['other_edits']}
H7, H8, H9 = '## Step 7. Shift the Einstein equations', '## Step 8. Einstein–Maxwell by Kaluza–Klein', '## Step 9. Two constants, two ends; three questions'
s, t = part(md, H7, H8, 'On the labels')
cur = md[s:t].split('\n')
assert all(l.startswith('- **') for l in cur), 'step 7: one line per bullet'
gone = OB['step 7, On the labels']['find']
c010 = OB['step 7, On the labels, the constant terms']
new7 = []
for b in SB['step7_on_the_labels']:
    old = [l for l in cur if l.startswith('- ' + b)]
    if old:
        new7.append(swap(old[0], c010['find'], c010['replace'], 'step 7, the constant terms') if old[0].startswith('- **The constant terms**') else old[0])
    else:
        b = b.replace('to order $D^{12}$ ($c_0 = ', 'to order $D^{12}$ (in the order of (3.3a–c), $c_0 = ', 1)   # the order of the three, as the move lists them
        new7.append('- ' + b)
assert all(l in new7 or l == gone or l.startswith('- **The constant terms**') for l in cur), 'step 7: a bullet of the page that 8b does not place'
assert any('in the order of (3.3a–c)' in l for l in new7) and c010['replace'] in '\n'.join(new7) and gone not in new7
md = md[:s] + '\n'.join(new7) + md[t:]
s, t = part(md, H7, H8, 'Taken forward')
md = md[:s] + '\n'.join('- ' + b for b in SB['step7_taken_forward']) + md[t:]
# -- step 8 (8b): the reduction and the radius, the radius on de Sitter, the fifth force; taken forward
s, t = part(md, H8, H9, 'On the labels')
b8 = [('- ' + b).replace('the Atlas\'s $\\Box\\phi = 4c\\phi$ (LNS-017e)', 'the Atlas\'s $\\Box\\phi = 4c\\phi$ (LNS-017e, proved by the Atlas)', 1)
      for b in SB['step8_on_the_labels']]
assert sum('(LNS-017e, proved by the Atlas)' in b for b in b8) == 1
md = md[:s] + '\n'.join(b8) + md[t:]
s, t = part(md, H8, H9, 'Taken forward')
md = md[:s] + '\n'.join('- ' + b for b in SB['step8_taken_forward']) + md[t:]

# -- the glance table (8a: steps 5, 6b, 6c; 8b: steps 7, 8)
for e in SA['glance_table'] + SB['glance_table']:
    md = swap(md, e['find'], e['replace'], 'the glance table')

# -- what this reading does not do: 8a's four bullets and 8b's two, as one list; the leftovers of both passes in "And further"
for e in SA['what_this_reading_does_not_do'] + SB['what_this_reading_does_not_do']:
    repl = e['replace']
    if e['find'].startswith('- **And further:**'):
        repl = repl.replace('; solutions in a field other than the ordinary ones of the quantized masses;',
                            '; solutions in a field other than the ordinary ones of the quantized masses; the Weitzenböck square on forms of degree '
                            'two and higher (the Dirac operator is checked on every grade, its square on 1-forms);', 1)
        assert repl != e['replace']
    md = swap(md, e['find'], repl, 'what this reading does not do')

# -- the references, the status words, Q1, the sources: the sentences both passes edit, merged
for e in SA['other_edits'] + SB['other_edits']:
    assert e['where'] in ('How to read the references', 'Status words', 'Sources, the rows', 'Sources, the checks', 'step 7, On the labels',
                          'step 7, On the labels, the constant terms', 'The three questions, Q1'), e['where']
md = swap(md, 'is a line of one of three scripts under', 'is a line of one of five scripts under', 'the references, the count')
md = swap(md, '(`wf.…`) and `shifted_energy.py` (`en.…`), with their logs and fault logs',
          '(`wf.…`), `shifted_energy.py` (`en.…`), `shifted_tensor.py` (`st.…`) and `shifted_einstein.py` (`se.…`), with their logs and fault logs',
          'the references, the scripts')
md = swap(md, 'a standard route that never touches them (complex Dirac matrices and scipy)',
          'a standard route that never touches them (complex Dirac matrices, or the metric by finite differences, with numpy and scipy)',
          'the references, the standard route')
md = swap(md, 'ATY-038 to ATY-041 are the rows of `shifted_energy.py`, whose recorded run passed (62 checks, 0 fail).',
          'ATY-038 to ATY-041 are the rows of `shifted_energy.py`, whose recorded run passed (62 checks, 0 fail); ATY-042 to ATY-046 those of '
          '`shifted_tensor.py` (40 checks, 0 fail) and ATY-051 to ATY-055 those of `shifted_einstein.py` (35 checks, 0 fail); ATY-047 is a reading.',
          'the status words')
md = swap(md, 'ATY-038, ATY-039, ATY-040, ATY-041; EQN-008, MAP-018, INP-049, LNS-017e.',
          'ATY-038, ATY-039, ATY-040, ATY-041, ATY-042, ATY-043, ATY-044, ATY-045, ATY-046, ATY-047, ATY-051, ATY-052, ATY-053, ATY-054, ATY-055; '
          'EQN-008, MAP-018, INP-049, LNS-017e, PRJ-006.', 'the sources, the rows')
ca = next(e for e in SA['other_edits'] if e['where'] == 'Sources, the checks')
cb = next(e for e in SB['other_edits'] if e['where'] == 'Sources, the checks')
assert ca['find'] == cb['find']
TAIL = ' The logs and fault logs are in `checks/selfcheck/proofs/logs/`.'
HEAD = ca['find'][:-len(TAIL)]
assert ca['find'].endswith(TAIL) and ca['replace'].endswith(TAIL) and cb['replace'].endswith(TAIL)
assert ca['replace'].startswith(HEAD + ' `checks/selfcheck/proofs/shifted_tensor.py`') and cb['replace'].startswith(HEAD + ' `checks/selfcheck/proofs/shifted_einstein.py`')
md = swap(md, ca['find'], ca['replace'][:-len(TAIL)] + ' ' + cb['replace'][len(HEAD) + 1:], 'the sources, the checks')
q1 = OB['The three questions, Q1']
assert q1['replace'].count('or flat space (ATY-052);') == 1
md = swap(md, q1['find'], q1['replace'].replace('or flat space (ATY-052);', 'or flat space (ATY-052, proved by the Atlas);', 1), 'Q1')
md = swap(md, 'or as an equation for the pair $(g,\\phi)$, is open.',
          'or as an equation for the pair $(g,\\phi)$, is open. The paper\'s doubt about the restriction is computed: on a frame that is not '
          'Einstein the wave operator does not commute with Ricci, and the restriction fails at order $\\mu^3$; on de Sitter it is consistent to '
          'every order (ATY-053).', 'Q1, the doubt')

# -- the sentences elsewhere on the page that named as not run what the two passes ran
md = swap(md, 'What the labels cannot reach is named at each step: packets of more than two frequencies, frames beyond a constant potential, the '
              'Weitzenböck identity as a theorem, the magnitudes of the paper\'s estimates.',
          'What the labels cannot reach is named at each step: fields that are not finite sums of plane waves, a potential beyond the first order of '
          'its gradient, the Weitzenböck identity as a theorem (it is checked at points of twelve frames), the magnitudes of the paper\'s estimates.',
          'step 1, what the labels cannot reach')
md = swap(md, '- *Open.* The theory of (2.17) on spinors (a mathematical theory of mixed equations exists; see the work since 2010); packets of more '
              'than two frequencies; the duality of small and large $\\mu$; the link to Fock space.',
          '- *Open.* The theory of (2.17) on spinors (a mathematical theory of mixed equations exists; see the work since 2010); the duality of small '
          'and large $\\mu$; the link to Fock space.', 'step 6b, open')
md = swap(md, 'a potential with a gradient on the engine, where the shift must follow a proper time that varies in space (ATY-037); the '
              'energy-momentum tensor for fields that depend on space, Feynman\'s window in four dimensions (ATY-038).',
          'a potential with a gradient beyond first order, where the shift must follow a proper time that varies in space (ATY-037, ATY-046); the '
          'shifted equations in five dimensions beyond their lowest order, where the shift would change the radius equation (ATY-054). Two items of '
          'the list have run: the energy-momentum tensor for fields of space and time, Feynman\'s window in four dimensions (ATY-042), and a potential '
          'with a gradient to first order (ATY-046).', 'step 9, the hand-over')
md = swap(md, '- *Cosmology.* The Atlas computes nothing; the cosmological constant is an input (ATY-010, our reading).',
          '- *Cosmology.* The cosmological constant is an input (ATY-010, our reading). With $\\Lambda = \\kappa^2$ the shifted equation (3.5b) holds '
          'on de Sitter at the lowest order and not at the next (ATY-053, proved by the Atlas); on a de Sitter base the radius of the fifth dimension '
          'grows or decays at rates that include the friction of the base, which the paper\'s (4.4) leaves out (ATY-055, proved by the Atlas).',
          'Q2, cosmology')
md = swap(md, '- The Hermitian half has, at $\\mu = \\pi/2$, a mode of negative Noether number at a positive frequency (ATY-039), outside the paper\'s range.',
          '- The Hermitian half has, at $\\mu = \\pi/2$, a mode of negative Noether number at a positive frequency (ATY-039), outside the paper\'s range.\n'
          '- In a potential with a gradient the shift mixes the two halves in the operator, while the quantized solutions are, to first order, those '
          'of the ordinary equation of each quantized mass (ATY-046, proved by the Atlas): on its quantized solutions the shifted theory reads as the '
          'ordinary Dirac theory of each quantized mass, weighted by $1 - (-1)^n\\mu J$ (ATY-047, our reading).', 'Q3, the gradient')
md = swap(md, '- *Open.* The infinite-dimensional data of (2.1) as a space of states; wave packets; Fock space;',
          '- *Open.* The infinite-dimensional data of (2.1) as a space of states; localized wave packets; Fock space;', 'Q3, open')
md = swap(md, 'ATY-038 builds the energy at rest (not the tensor), and ATY-041 places',
          'ATY-038 builds the energy at rest and ATY-042 the tensor for fields of space and time, and ATY-041 places', 'the verdict')
# Q1 after 8b's sentence: the pronoun of the next sentence names its noun again
md = swap(md, '(ATY-053, proved by the Atlas). Its size and sign stay inputs, moved from the Atlas\'s $c$ to the paper\'s $k$',
          '(ATY-053, proved by the Atlas). The size and sign of the cosmological term stay inputs, moved from the Atlas\'s $c$ to the paper\'s $k$', 'Q1, the inputs')
# step 9: the results that mu enters, the two passes' among them
md = swap(md, '- **One number.** On the labels $\\mu = \\kappa\\tau$ enters every result computed here: the coefficient of $\\Phi$, $E_0\\bigl(1 - (-1)^n\\mu J\\bigr)$ '
              '(ATY-037); the Noether energy $\\rho E_0\\bigl(1 - (-1)^n\\mu J\\bigr)$ (ATY-038, ATY-039); the condition $\\kappa\\tau = (n_1 - n_2)\\pi/2$ for '
              'two quantized energies at one shift (ATY-040); the values $\\mu = (-1)^n(n+\\tfrac12)\\pi$ at which (2.1) oscillates (ATY-041). All five rows '
              'are proved by the Atlas.',
          '- **One number.** On the labels $\\mu = \\kappa\\tau$ enters these results: the coefficient of $\\Phi$, $E_0\\bigl(1 - (-1)^n\\mu J\\bigr)$ (ATY-037); '
          'the Noether energy $\\rho E_0\\bigl(1 - (-1)^n\\mu J\\bigr)$ (ATY-038, ATY-039), and the same factor on the whole energy-momentum tensor and on its '
          'symmetric form (ATY-042, ATY-044); the condition $\\kappa\\tau = (n_1 - n_2)\\pi/2$ for two quantized energies at one shift (ATY-040); the values '
          '$\\mu = (-1)^n(n+\\tfrac12)\\pi$ at which (2.1) oscillates (ATY-041); the first corrections to the shifted Einstein equations, of order $\\mu$ '
          '(ATY-052, ATY-053). All nine rows are proved by the Atlas.', 'step 9, one number')
# step 6a: d + delta, which step 7 now computes
md = swap(md, '- **The affine operator group, supersymmetry, $d + \\delta$.** The Atlas computes nothing here. A check of the first would need the group '
              'generated by $d/dt$ and the shift, and its representations.',
          '- **The affine operator group and supersymmetry.** The Atlas computes nothing here. A check of the first would need the group generated by '
          '$d/dt$ and the shift, and its representations.\n'
          '- **$d + \\delta$.** Computed at step 7: on the labels it is the Dirac operator on the full algebra of a frame, and it maps 1-forms to forms of '
          'degree 0 and 2 (ATY-051 and ATY-052, both proved by the Atlas).', 'step 6a, d + delta')
# the status words: the two readings carry the badge "our reading", the other ATY rows "new"
md = swap(md, 'Every ATY row cited here carries the badge *new*.',
          'Every ATY row cited here carries the badge *new*, except the two readings ATY-011 and ATY-047, which carry *our reading*.', 'the badges')

for must in ('- **The tensor** (ATY-042', '- **The roots of the spinor equation** (ATY-045, proved by the Atlas', '- **A potential with a gradient** (ATY-046',
             '- **The Weitzenböck bridge** (ATY-051', '- **De Sitter, order by order** (ATY-053', '- **The radius on de Sitter** (ATY-055',
             '- **Fields beyond plane waves.**', '- **The meaning of the shifted Einstein equations.**', 'one of five scripts',
             'de Sitter order by order; the paper\'s doubt computed (ATY-010, ATY-051 to ATY-053) |', '(ATY-052, proved by the Atlas);',
             '(LNS-017e, proved by the Atlas)', '(in the order of (3.3a–c), $c_0 = ', 'With the Weitzenböck formula (ATY-051) the leading equations are'):
    assert md.count(must) == 1, must
for gone in ('The Weitzenböck identity and the three readings of (3.5).', 'standard and recalled but not checked on the engine', 'recalled and not checked',
             'packets of more than two frequencies', 'The tensor for fields that depend on space.', '- **Belinfante.**', 'R2:'):
    assert gone not in md, gone
if md != md0:
    open(path(rel), 'w', encoding='utf-8').write(md)
    said.append(f'wrote {rel}')
else:
    said.append(f'unchanged {rel}')

# ---- 10 the pages
if not NO_NODE:
    for aid in ('atiyah', 'shifted_view'):
        out = subprocess.run(['node', 'tools/make_analysis.mjs', aid], cwd=ROOT, env={**os.environ, 'NODE_PATH': NM}, capture_output=True, text=True)
        sys.stdout.write(out.stdout)
        if out.returncode:
            sys.stderr.write(out.stderr)
            sys.exit('make_analysis.mjs failed')

print('\n'.join(said))
