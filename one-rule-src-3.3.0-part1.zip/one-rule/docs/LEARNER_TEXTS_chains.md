<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of the chains: the storyteller's runs (round 14, wave 1, release 2.15.0; round 15, wave 2, release 2.16.0; round 16, waves 3–5, release 2.17.0, wave 6, release 2.18.0, and the close, 3.0.0)

The storyteller of `docs/round14/STORY_ROUND.md` §7 (`docs/09_TRANSLATION_PROTOCOL.md` §2.2) told every chain of wave 1 in three runs, the pilot pages (T3), Calibration 3 at `#/shifted` (T3s) and Calibration 2 at `#/matter` with its papers sub-page (T3m), every chain of wave 2 in two, `cells` · cards, `clock` and `light` (T4a) and steps 2–4 with the pilot's leftovers (T4b), and every chain of waves 3, 4 and 5 in six, two storytellers per wave on disjoint pages (T5a, T5b; T6a, T6b; T7a, T7b), each writing the spans, the leads' learner texts and, from wave 3 on, the full text of every side note of its pages (`docs/round16/PLAN.md` §1). This record keeps each wave-1 run's section as its storyteller wrote it (§1 to §3; the records of the two calibrations also stand on their own, `docs/round14/LEARNER_TEXTS_shifted.md` and `docs/round14/LEARNER_TEXTS_matter.md`); the two records of wave 2 (`docs/round15/LEARNER_TEXTS_wave2_a.md`, `docs/round15/LEARNER_TEXTS_wave2_b.md`; §4 and §5) and the six of waves 3–5 (`docs/round16/LEARNER_TEXTS_wave3_a.md` … `wave5_b.md`; §6 to §11) stand on their own beside it. The totals first, then what bit, then the releases' own edits.

## The totals

**At the close (3.0.0): 186 chains on 26 pages, 185 storied, 806 spans; 547 full texts of the storyteller.** Wave 6 (release 2.18.0, §12 below) added 69 chains on `steps/category`, `steps/baez` and `steps/schuller` — 325 spans, 20 section leads, 191 side notes' full texts — and left one chain out by the budget rule C7 (`steps-baez.bz-papers.seven`, D54: its rows keep the translator's words); the close (§13) added no chain and 136 full texts: the sweep of the side notes of the wave-1 and wave-2 pages (91) and the inputs of the step pages (45). The paragraph and the table that follow are the record at 2.17.0, kept as written.

**117 chains on 24 pages, all storied** (wave 1: 41 on `rule`, `cells`, `steps/coupling`, `steps/baez`, `shifted`, `matter`; wave 2: 34 on `cells`, `clock`, `light`, `steps/comm`, `steps/mirrors`; wave 3: 14 on `steps/spin`, `steps/coupling`, `steps/ym`, `steps/matter`, `matter/model`; wave 4: 15 on `steps/grav1`, `steps/grav2`, `steps/projective`, `steps/gauge`, `steps/nullsurf`; wave 5: 13 on `steps/forque`, `steps/spring`, `steps/rigid`, `steps/groups`, `shapes`): no written piece was rejected twice by the checker, so none stays unstoried and D54's fallback (the rows in the translator's words) applies to none; one chain, `shapes.sh-gosset.views`, is reviewed by construction (four human texts). **481 spans**: 441 told positions, 8 mathematics twins, 32 mentions; 467 drafts of the storyteller and 14 human texts (C10, A63: FUR-001 … FUR-005, PAG-023, GOS-001; FUR-002, FUR-003, FUR-004 on the tab; GOS-001 … GOS-004 on `shapes`). Every record has the shape of STORY_ROUND §2.2: `lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@<date>"` (the human spans `status: "human"` with their human source); `termsUsed` and `keptNumbers` are the checker's, never typed.

| wave · run | files (`content/chains/learner/`) | chains | spans: told + twins + mentions | human spans | learner texts of story rows (chain leads) | learner full texts of rows that had none | records |
|---|---|---:|---|---:|---|---|---:|
| 1 · pilot pages (T3) | `rule`, `cells`, `steps-coupling`, `steps-baez` | 17 | 87: 85 + 0 + 2 | 0 | 0 (no pilot chain has a lead) | 1: GEN-031, a side note of `cells` | 88 |
| 1 · `shifted` (T3s) | `shifted` | 17 | 60: 38 + 0 + 22 | 0 | 23 (ATY-751 … ATY-758) | 12: MAP-018, INP-049, ATY-056 … ATY-065 | 95 |
| 1 · `matter`, `matter/papers` (T3m) | `matter`, `matter-papers` | 7 | 49: 42 + 5 + 2 | 5: FUR-001 … FUR-005 | 17 (FUR-751, FUR-752) | 35: FUR-007 … FUR-040, CAND-049 | 101 |
| **wave 1** | 7 files | **41** | **196: 165 + 5 + 26** | **5** | **40 (10)** | **48** | **284** |
| 2 · `cells`, `clock`, `light` (T4a) | `cells` (added to the pilot's), `clock`, `light` | 30 | 99: 96 + 0 + 3 | 1: PAG-023 | 4 section leads (ATL-711, LAB-711, LAB-712, PAG-711) | 3: ATL-001b, ATL-002b, CAND-086 | 106 |
| 2 · steps 2–4 and the leftovers (T4b) | `steps-comm`, `steps-mirrors`, `steps-coupling` (added) | 4 | 15: 15 + 0 + 0 | 1: GOS-001 | 1 section lead (MIR-711) | 6: CAND-013, CAND-084, CPL-007c, CPL-007d, CAND-002, MIR-005 | 22 |
| 2 · the inputs of `light` (R8, under the storyteller's rules) | `light` (added) | — | — | — | — | 9: INP-001, INP-002, INP-003, INP-005, INP-006, INP-009, INP-010, INP-012, CAND-115 | 9 |
| **wave 2** | 5 files more, 3 added to | **34** | **114: 111 + 0 + 3** | **2** | **5 (0)** | **18** | **137** |
| 3 · steps 5–8 (T5a) | `steps-spin`, `steps-ym`, `steps-matter`, `steps-coupling` (added) | 12 | 38: 37 + 0 + 1 | 0 | 6 section leads (SPN-711, CPL-711, YM-711, YM-712, YM-713, MAT-711) | 21 side notes (18 beside translator drafts, D68) | 65 |
| 3 · the Furey tabs and the leftovers (T5b) | `matter-model`; `matter`, `cells`, `rule` (added) | 2 | 16: 13 + 3 + 0 | 3: FUR-002, FUR-003, FUR-004 | 2 section leads (FUR-718, FUR-719) | 6: FUR-001b, FUR-005b, FUR-041, FUR-042, GEN-033, GEN-034 | 24 |
| 4 · steps 9–10 (T6a) | `steps-grav1`, `steps-grav2` | 7 | 38: 37 + 0 + 1 | 0 | 2 section leads (GRV-711, GRV-712) | 5: ATY-017, ATY-018, EQN-012, CAND-118, EQN-013 | 45 |
| 4 · steps 11–13 (T6b) | `steps-projective`, `steps-gauge`, `steps-nullsurf` | 8 | 28: 28 + 0 + 0 | 0 | 5 section leads (PRJ-711, PRJ-712, LAB-713, LAB-714, NUL-711) | 15: EQN-015 and the 14 side notes of `steps/nullsurf` | 48 |
| 5 · steps 14–16 (T7a) | `steps-forque`, `steps-spring`, `steps-rigid` | 4 | 15: 15 + 0 + 0 | 0 | 2 section leads (FRQ-711, SPR-711) | 19: the notes of the two matrices, the tallies, SPR-001, CAND-034, CAND-036, CAND-132 | 36 |
| 5 · step 17 and `shapes` (T7b) | `steps-groups`, `shapes` | 9 | 36: 35 + 0 + 1 | 4: GOS-001 … GOS-004 | 1 section lead (LAB-715) | 5: LAB-011, LAB-012, CAND-008, CAND-116, MAP-022 | 42 |
| **waves 3–5** | 14 files more, 4 added to | **42** | **171: 165 + 3 + 3** | **7** | **18 (0)** | **71** | **260** |
| **all** | 25 files | **117** | **481: 441 + 8 + 32** | **14** | **63 (10)** | **137** | **681** |

- **The leads**: ten chains have a lead story row (ATY-751 … ATY-758 on `shifted`, FUR-751 and FUR-752 on `matter`), each learner text at most 300 characters, with no number and no claim word of T2, so T1–T5 pass it as narration (C6). The other 53 learner texts of story rows are the page leads, the next lines and the section leads of the two calibrations (ATY-701 … 703, ATY-711 … 722; FUR-701, FUR-702, FUR-711 … 716), the papers sub-page (FUR-717 and the six cards FUR-761 … 766), the five section leads of wave 2 (ATL-711, LAB-711, LAB-712, PAG-711, MIR-711) and the eighteen of waves 3–5 (SPN-711, CPL-711, YM-711 … 713, MAT-711, FUR-718, FUR-719; GRV-711, GRV-712, PRJ-711, PRJ-712, LAB-713, LAB-714, NUL-711; FRQ-711, SPR-711, LAB-715), each at most 300 characters, no digit.
- **The full texts**: in waves 1 and 2, 66 rows told in a chain, standing as a side note or in an inputs fold had no learner text anywhere (the rows of 2.12.0 to 2.14.0 among them); each `full` text of a told row is its span made to stand alone, with the clauses the chain's budget left out put back where they fit. From wave 3 on every side note of a storied page has the storyteller's full text (PLAN §1): 71 in waves 3–5, a story of one piece each — what it is, why it is on its page, what it links to and what was checked, the numbers and status words kept, no formula —, 58 of them written beside a translator draft of the same key and winning at the merge (D68), the draft moved to the book at 2.17.0; 13 are first learner words.
- **The checker at the close of 2.17.0**: `node tools/check_learner_texts.mjs` passes all 24 rules (R1–R13, C1–C11) on 1,583 records (the 167 translator drafts the retire of 2.17.0 moved to the book no longer among them); `node tools/merge_chains.mjs --check`: 117 chains on 24 pages, 117 storied (1 reviewed), 481 spans; round-14 rows: 63 story rows, 13 statement rows.

## What bit, across the runs

- **C7 with R6.** The story is at most 0.8 × the research texts of its positions, and every number of a row stays: the chains of short rows dense with symbols (the genesis: 2578 of 2581 characters) and the dense proof rows of 2.12.0 to 2.14.0 (five chains of `matter` end within 1 % of their budgets) were met by compressing method detail, listed in §3, never a number, a scope or a status word. Whether the dense proof rows get 0.9 is the owner's question (`docs/HANDOVER.md` §3).
- **R6's reading of numbers.** Digit groups keep their spaces ("99 507 561"); scientific numbers stay verbatim ("1.7e-15"); a precision printed with a superscript is written in words ("3 times 10 to the minus 15", A64); equation labels lose their parentheses; a number after "stage", "step", "part", "idea", "table" or "figure" is an identifier, so a span never leans on one; GEN-030's folder path in its research text asks a 13, which its span keeps as Stacey's theorem 13.
- **R4 and R12.** No Greek letter, formula mark or lone letter: κ is "the strength", τ "the delay", μ "the strength times the delay", J "the quarter turn", a lone "B" of a journal "journal volume 742"; no name the row does not name ("Compton", "Dirac", "Atiyah", "Furey", or "Warm-up" inside a sentence).
- **R5.** No history word in any sense ("correction" refused even in its mathematical sense, "no longer" avoided); present tense.
- **C4 and C5.** A derivation word only on a `derives` link; free openings on the `order` links ("Beside it", "Alongside", "At rest", "Under the blocks lies a finer grid"); the status word at every weak link (our reading, open, input), none added at a proved row.
- **The words rules.** The coverage test reads 40-character windows of every record at offsets of 40 against the strings drawn outside statements; spans that shared a run with a note of `content/notes.json`, an entry of the `atiyah` or `furey` lens dictionaries or `content/stored_shifted.json` were rephrased by their storytellers (four on the pilot pages, nine on `shifted`). `node tools/check_notes.mjs` (rule G) reads the notes at every offset and found two more at the release (below).
- **The fold of long statements** (700 characters): seven leads of `shifted` were cut to read whole at learner level.
- **Wave 2** (the two records, §4 and §5): C7 on the short card rows and on the symbol-dense rows of the trinity and of `light` (six chains end within 1 % of their budgets, four exactly at it); "then" a sequence word, not a derivation word (C4 since the lead's ruling of round 15, D65: an `order` link may open with it, a `derives` link may not; the genesis spans re-opened "So …" and "From the pairing, …" on the links A62 turned into derivations); R6 on numbers inside identifiers ("(683)" read as an equation number); R12 on names ("Kepler" in neither LNB-023c's text nor its parent's); the 40-character screens against the strings drawn outside statements, eighteen runs rephrased before any write.
- **Waves 3–5** (the six records, §6 to §11): C7 on nearly every chain — 33 of the 42 end at 99 % or more of their budgets, the dense rows of the gravity steps, the Furey tab and `shapes` among them (`matter-model.edges.charges` 6620 of 6649, `shapes.sh-gosset.lattices` 4710 of 4720), every number, scope and status word kept and the method detail compressed listed per chain; R3 under D68 (a storyteller's full text beside the translator's draft of a side note, from the first page of wave 3 on); R6's identifier rule, which read "the spin (… to 1e-6)" as a group name (T6a wrote GRV-011 with commas; the rule is fixed at the release, D69); R6's number words ("two-switch" is not one: YM-003 says "2-switch"; "2.5 × 10³" asks its 10; a year inside a citation without its parenthesis is a number); R8 on the leads' own research texts (YM-711's "textbook") and on "our translation", "our phrase" as answers to ours; R12 on names a row does not carry (Einstein in CPL-008 and GRV-008, Ricci, Euler, Weyl, Hooke, Brillouin, Smarr, de Sitter, Atiyah in ATY-054); C5's trap on SPR-003 (proved, no status word in its text: the span may not say ours, the lead does); the 40-character screens against the notes, the chain titles, the lens dictionaries, the Logbook's tables and the leaves' own strings (about 120 windows rephrased before any write; the windows of RIG-005 and EQN-019 against INP-076's research text left, as a statement's text).

## The releases' own edits

### R7, 2.15.0

Each under the checker's rules, with the claim, its numbers and its status words kept; the checker passes all 24 rules after them.

- **ATY-038**, its span in `steps-coupling.eq-coupling.shift-energy`, shared 40 characters with the Moore note ("no energy-momentum tensor for fields th…", rule G of `check_notes`): it takes its research text's words back, "and no energy-momentum tensor is built for fields that depend on space" (the story 9513 of 10872 characters).
- **FUR-003b**, its span in `matter.fur-model.rebuilt`, shared 40 characters with the Furey note ("is an input, not forced by Witt pairing"): one comma less, "the split is an input not forced by Witt pairing" (the story 4514 of 4516 characters).
- The defects each run reported in the tests are fixed: `tests/chains.test.mjs` part D empties `content/chains/learner/` in its copy before it adds the fixture's spans (and draws D54's fallback on the fixture, since every chain of the tables is storied); `tests/story/shifted.test.mjs` reads the spans of `p.chain__story` as well as the items of `ol.chain__list`.
- After the retire of wave 2.15.0 (`docs/02_CONTENT_MODEL.md` §11.6) the 26 translator drafts of the rows told only in storied chains stand in the retire book; on the six pages every told row speaks through its span.

### R8, 2.16.0

Each under the checker's rules, with the claim, its numbers and its status words kept; the checker passes all 24 rules after them (`docs/RELEASE_NOTES_v2.16.md`).

- **The spans of three rows whose research texts pass 12a edited** (`docs/round15/PROOFS_ROUND12A.md` §1; `docs/round15/apply_pass12.py`, step 2c), where a claim word moved: GEN-026 in `rule.ideas.limit` and `cells.cards.limit` (span 5): "…covering the quaternion case only by a reading of its hypotheses" + ", though their union is also that of a chain of real grids, to which it applies as stated"; GEN-030 there (span 6): "…not, as stated, for the quaternions;" + " for the quaternion chains the union is also that of a chain of real grids, to which it applies as stated;" (its "Stacey's theorem 13" kept: the folder path left GEN-030's research text, and its "round 13" still asks the 13); FUR-039 in `matter.fur-next.open` (span 6) and its learner full text: "(arXiv:2409.17948, read, not computed)." → "(arXiv:2409.17948, read; the finite part, their charges on the 32 states, is computed in row FUR-042, not their third family)." (R6 asks the 32 of its research text). The three chains stay within C7 (the research texts grew with them).
- **The nine rows of `light`'s inputs fold** (INP-001, INP-002, INP-003, INP-005, INP-006, INP-009, INP-010, INP-012, CAND-115), which drew nothing at learner level (T4a's record §5): learner full texts written by R8 under the storyteller's rules (R1–R13; `source: "storyteller@2026-10-18"`, status draft), in the voice of `light` (switches, boxes, pieces, the field's equation): each INP row says "an input", the status its badge names ("needs an input"); CAND-115, proved, keeps "exactly" and "recalled" and its numbers, the 4 of its Coulomb field's 4π as "the charge over four pi times the distance squared", its precisions in words (A64). `node tools/check_notes.mjs` (rule G) and `tests/coverage.test.mjs` pass with them.
- **The retire of 2.16.0** (`docs/02_CONTENT_MODEL.md` §11.6, D54, D66): 70 translator full drafts of 70 rows told only in storied chains moved to the book (96 drafts in all, 26 of 2.15.0), LAB-003's among them (its draft said "ours" where the row is proved); the heroes ATL-001 (`cells`) and EQN-003 (`steps/comm`), told in chains and without a short learner text, keep their full drafts, which the page tops draw (D66); MIR-001 and LAB-017, heroes with a short learner text, give theirs up.

### R9, 2.17.0

Each under the checker's rules, with the claim, its numbers and its status words kept; the checker passes all 24 rules after them (`docs/RELEASE_NOTES_v2.17.md`).

- **The checker's identifier rule** (D69, found by T6a): "group, algebra or binomial" read a lowercase prose word before a space and a parenthesis as a group name and stripped the parenthesis, so a number inside it was neither required nor credited; the lowercase names now take their parenthesis only when it follows at once, the capitalised names keep the space, and the self-test holds the case. Two spans moved under it, each already saying its numbers: MAT-005 in `steps-matter.eq-matter.coupling` (`keptNumbers` [] → 2, 3, 4: "checked for 2 to 4 gauge directions, couplings 3 and plus or minus a half") and CAND-015 in `steps-grav2.eq-grav2.conservation` (1e-6 added: "the half to 1e-6"); no wording changed. MAT-005's translator draft, which lacked the 4, left with the retire as a told row's draft.
- **The retire of 2.17.0** (`docs/02_CONTENT_MODEL.md` §11.6, D54, D66, D68): 167 translator full drafts of 167 rows moved to the book (263 in all) — 109 of told rows whose every placement is told in a storied chain and 58 of side notes whose storyteller full text replaces them; the heroes without a short learner text keep theirs (ATL-001, EQN-003, CPL-001, YM-001, MAT-001, GRV-003, GRV-010, PRJ-002, NUL-001); the storytellers' lists of eligible drafts agree with the run row for row (T7b's 25 are the 26 its list names).
- **The renderer's fixture** (`tests/ui/fixtures/chains/texts.json`): the learner full texts of SHP-001, SHP-003, SHP-007 and SHP-004 (the words those rows showed before the retire) for D54's fallback of the unstoried case, which found no translator draft in the content once the retire had moved them; no content touched.

## 1. The pilot pages (T3)

The storyteller of `docs/round14/STORY_ROUND.md` §7 wrote the stories of the **17 pilot chains** of `docs/round14/SPINE.md` §4: one span per position, in chain order, in the record shape of §2.2 (`register: "span"`, `chain`, `span`, `status: "draft"`, `source: "storyteller@2026-10-17"`), and the learner text of the one side note of a storied section that had none. **Every chain is storied; none is left out** (D54 applies to none). The calibrations `shifted` and `matter` are the second run, after their builders.

| file | page · section | chains | spans (told + mentions) | side notes written |
|---|---|---:|---:|---|
| `content/chains/learner/rule.json` | `rule` · ideas | 6 | 31 (30 + 1) | — |
| `content/chains/learner/cells.json` | `cells` · cards | 3 | 15 (15 + 0) | GEN-031 (learner `full`) |
| `content/chains/learner/steps-coupling.json` | `steps/coupling` · eq-coupling | 5 | 25 (24 + 1) | — |
| `content/chains/learner/steps-baez.json` | `steps/baez` · bz-generation | 3 | 16 (16 + 0) | — |
| all | | **17** | **87** (85 + 2) | **1** |

No pilot chain has a lead (`lead: null` in `content/chains/pilot/chains.json`), so no lead text was written; no pilot row has a human learner text, so C10 kept no human words. The side notes GEN-011 (`cells`) and CAND-062 (`steps/baez`) already have learner drafts (`translator:learner@…`), which stand; a second full record would be a duplicate (R3). The termsUsed and keptNumbers of every record are the checker's (`--fix`, run on the one file), never typed.

### The chains, position by position

| chain | shape | positions | mentions | links (in order) | story / budget (C7) |
|---|---|---:|---:|---|---|
| `rule.ideas.genesis` | ladder | 9 | 0 | order, order, derives, derives·GEN-003, derives, order, order, order | 2578 / 2581 |
| `rule.ideas.blocks` | fork | 5 | 0 | derives, equiv, equiv, derives·GEN-017 | 5783 / 7451 |
| `rule.ideas.car` | line | 3 | 1 | derives, derives | 1469 / 1924 |
| `rule.ideas.null` | fork | 5 | 0 | derives, derives·GEN-021, equiv, derives·GEN-021 | 6022 / 7416 |
| `rule.ideas.limit` | cycle | 7 | 0 | derives, derives, derives, derives·GEN-019, equiv, cycle (back) | 9216 / 10698 |
| `rule.ideas.routes` | line | 2 | 0 | derives | 3291 / 3549 |
| `cells.cards.null` | fork | 6 | 0 | derives, derives, derives·GEN-021, equiv, derives·GEN-021 | 7257 / 8391 |
| `cells.cards.limit` | cycle | 7 | 0 | order, derives, derives, derives·GEN-019, equiv, cycle (back) | 8865 / 10580 |
| `cells.cards.routes` | line | 2 | 0 | derives | 3272 / 3549 |
| `steps-coupling.eq-coupling.shift-waves` | fork | 7 | 0 | derives, derives, derives·ATY-005, derives·ATY-005, derives·ATY-004, derives·ATY-005 | 5265 / 5310 |
| `steps-coupling.eq-coupling.shift-energy` | fork | 5 | 0 | order, derives, derives, derives·ATY-038 | 9504 / 10872 |
| `steps-coupling.eq-coupling.shift-tensor` | fork | 3 | 0 | derives, derives·ATY-042 | 4838 / 5258 |
| `steps-coupling.eq-coupling.off-modes` | fork | 4 | 1 | derives, derives·ATY-041, derives | 5839 / 8448 |
| `steps-coupling.eq-coupling.fibre-mass` | fork | 6 | 0 | derives, derives, derives·FUR-024, derives·FUR-025, derives·FUR-024 | 7385 / 8005 |
| `steps-baez.bz-generation.weights` | fork | 6 | 0 | derives, derives, derives·FUR-012, derives·FUR-020, derives·FUR-020 | 8629 / 9440 |
| `steps-baez.bz-generation.no-mass` | line | 3 | 0 | derives, derives | 2397 / 2962 |
| `steps-baez.bz-generation.fock` | fork | 7 | 0 | derives, derives, derives, derives, order, derives·FUR-022 | 9513 / 10399 |

The weak links say what they are, in the span of the row (C5): GEN-006 (the five-switch rung read as node 3 again), GEN-016 (the finite block is all the limit keeps), ATY-011 (why delayed and advanced terms come together) and ATY-047 (the shifted theory as a reweighted ordinary one) each say "our reading", the last at the end of its chain. GEN-012 is proved but its research text says "our reading" of the boxes the period table does not list, and its span keeps it.

**The voice.** The words of the human learner texts of `rule` and `cells` (GEN-518: "one lonely switch, then two that hold hands", ATL-501, PAG-001 …): a generator is a switch (plus, minus or zero switch by its square), a cell a box, a blade a piece, an address a label, M₁₆(ℝ) "the 16 by 16 grids of real numbers"; the quotient of a box with zero switches "the plain box", its radical "the zero part"; on the coupling and Baez pages a quarter period "a quarter turn", κ "the strength", μ "the strength times the delay", the frame factor by its name. Tolerances keep their value, said as the existing drafts say them ("to 10 to the minus 13"; A64). The genesis tells the ladder one switch at a time, each rung opening with its count ("One lonely switch …", "Two zero switches …", "So three switches …"), so the six `order` links carry no "so".

### The checker: first runs, returns, second runs

Each chain went to the checker once written (`node tools/check_learner_texts.mjs --file <page file> --fix`). Four chains came back once; each passed on its second run. **No chain was rejected twice**, so none is left unstoried.

| chain | first run | what went back | second run |
|---|---|---|---|
| `rule.ideas.genesis` | C7: 2930 characters, more than 0.8 × 3227 (2581) | every span tightened, each number, status word and opening kept (the short genesis rows are dense with symbols, which plain words lengthen) | PASS, 2578 / 2581 |
| `rule.ideas.null` | R5 (P2): "correction" in GEN-028's span ("without the correction", the research text's mathematical sense) | "without the extra term" | PASS |
| `rule.ideas.limit` | R6: GEN-030's "691" missing — "the first two stages (691 587 labels)" reads as a stage number for the identifier rule (`[Ss]tages?\s+\(?\d+`) and is stripped | "the first two stages, 691 587 labels in all" | PASS |
| `steps-baez.bz-generation.weights` | R7: "16" in FUR-034's span ("the multiset of the 16"), a number its research text does not hold | the multiset named by its patterns: "(2,1) with a 4 and (1,2) with the conjugate 4" | PASS |

The other thirteen chains passed on their first run. Two faults were caught before a first run, by measuring the story against the worksheet's budget and reading the spans against its lists: `shift-waves` measured 5410 of 5310 characters and was trimmed first; ATY-007's span had dropped the "3" of the point (3/5, 4/5).

**After the checker, the coverage gate.** `tests/coverage.test.mjs` (after `cells` and `steps/coupling`) found 16 renders of `#/notes/moore` holding 40 characters of ATY-038's span outside a statement: the span's window "lds of the frame's time alone the shift " is in the Moore note of `content/notes.json`. A screen of every span's record windows (offsets 0, 40, 80 …, as the test takes them) against the strings drawn outside statements (`notes.json`, `pages.json`, `figures.json`, `lenses.json`, `glossary.json`, `src/`) found three more: ATY-041's mention against the same note (masked in the test by ATY-038's earlier window), ATY-046 and ATY-047 against two entries of the `atiyah` lens dictionary. The four spans were rephrased ("When the fields depend on the frame's time only, …", "a delay for one half of each field and an advance for the other", "the ordinary equation's first-order solution", "is, for each quantized mass, the ordinary Dirac theory …"), the file passed the checker again, and the screen finds no window. Last, the word "new" (A60: not a story word) was taken out where it was descriptive ("the new block", "the new mode" → "the added …"; ATY-047's "not a new dynamics" → "not a different dynamics"); the three files passed again.

### The rules that bit, and how they were met

- **C7, the budget**, binds the chains of short rows (the genesis, `no-mass`, `shift-waves`): a research text of symbols is shorter than its plain words. Every number and status word stays; explanations are compressed, never a number dropped. The chains of long rows (`limit`, `shift-energy`, `fock`) stay inside their budget with room to spare.
- **R6, every number.** ATY-041 asks for 22 numbers, GEN-017 for 20, FUR-029 for 18, FUR-035 for 17; all are kept. Digit groups are copied with their spaces ("99 507 561", "1 048 576", "14 278 656": R6 reads each group); scientific numbers verbatim ("1e-8", "1.7e-15", "4.6e-14"); "3·10⁻¹⁵" as "3 times 10 to the minus 15". Citation volumes and pages that sit outside parentheses are numbers for R6: Elliott's "J. Algebra 38 (1976) 29–44" becomes "volume 38, pages 29 to 44" (a "J." is a lone letter for R4), Glimm's and Stacey's "volume 95", "volume 363"; GEN-028's "Springer GTM 131" is kept. GEN-030 asks for a "13" that comes only from the folder name `docs/round13/SOURCES.md` in its research text; the span keeps "Stacey's theorem 13", the theorem's own number (lowercase "theorem" is not an identifier for R6). Citation years outside parentheses (Pati and Salam 1974, Slansky 1981, Furey 2015, Furey 2018) are kept with their page or section ("page 45", "section 3.6").
- **R6's identifier rule** strips a number after "stage", "step", "part", "idea", "table" or "figure" (see GEN-030 above); spans avoid putting a number to keep there.
- **R4, no symbol.** No Greek letter, formula mark or lone letter: "T. Y. Lam" becomes "Lam's book, A First Course in Noncommutative Rings (Springer GTM 131)"; the barred 4̄ (a combining accent) becomes "the conjugate 4"; "S xor 3" is said as "flips both weak bits"; the fibre momentum's length "m" is "its length" (FUR-013), κ "the strength". Representation patterns such as (2,1) and points such as (3/5, 4/5) and (13, 12, 0, 0) are numbers and stay.
- **R12, names.** A span names only whom its row names: ATY-005's span cannot say "Compton" (only ATY-004 and ATY-006 do), ATY-038's and ATY-045's cannot say "Atiyah" ("the one-dimensional delay equation"); "Standard Model" is allowed (it names no authority).
- **R5, history.** "Correction" is refused in any sense (above); GEN-029's title "where the bit route stood alone" becomes "the remaining results of the label route"; GEN-024's "did not finish" is present tense, "does not finish"; references to other statements say "the map's own statement", "another statement", never a word that places a statement in time.
- **R8 and C5, the status words.** "Our reading" at the four readings; "input" kept on the proved rows whose research text has it (GEN-008, FUR-020, FUR-026, FUR-034: the signature or the masses are inputs); "cited", "not read" and "checked" on GEN-028; "not settled" on ATY-046 (allowed: its research text says it); "for every n" as "for every number of half turns" (ATY-037); "floats" as "numerical", "numeric" or "floating-point"; "unread" as "not read".
- **C4, the openings.** Derived links open with "So", "Hence", "From the …"; equivalences with "The same", "Put another way", "In other words"; the back cycle link of GEN-016 with "Behind this"; the `order` links open with no derivation or contrast word ("One lonely switch", "Atiyah's one-dimensional equations …", "The chain of blocks can be followed stage by stage too", "Beside them, …").
- **C8, the mentions.** GEN-003 in `car` ("On the ladder, two zero switches hold hands, and their pairing is the rule of creating and removing.") and ATY-041 in `off-modes` (one sentence each, no number: 100 and 196 characters).
- **R10, the glossary.** "base / fibre" is listed wherever "base" or "fibre" occurs (the coupling and Baez pages use the Atlas's own words for the two factors); "label 0", "trio", "mirror", "bit rule" where they occur.
- **A cell's spans on two pages.** The rows told on `rule` and on `cells` have a span in each chain (the text key carries the chain). The `cells` spans are the `rule` ones with the opening their link asks (GEN-021 opens "So" after GEN-012; GEN-019 sits on an `order` link on `cells`) and with no reference to a chain `cells` does not tell ("the map that adds a block of eight", not "the map of the blocks").

### For the owner

- **GEN-016 and GEN-030 disagree.** GEN-016's research text says the limit is not computed, "neither the union of the stages nor its completion"; GEN-030, in the same chain, builds the union as the algebraic direct limit on the labels. GEN-016's span says "This reading does not compute the limit itself, neither the union of the stages nor its completion", scoped to the reading; the research text of GEN-016 may want the owner's update.
- **GEN-030's research text holds a machine path** (`docs/round13/SOURCES.md`), which makes R6 ask a learner text for the number 13.
- **The 40-character rule and the notes.** A storyteller's span can collide with a note or a lens dictionary entry that repeats a row's words; the screen above (`notes.json`, `lenses.json`) before `npm run content` saves a coverage round.
- **Rows of the pilot sections outside the pilot's groups** have no learner text and were not written (they wait for their wave, SPINE.md §4.2–§4.3): ATL-001b, ATL-002b, CAND-086 on `cells` · cards (wave 2), CAND-013, CAND-084, CPL-007c, CPL-007d on `steps/coupling` · eq-coupling (wave 3). None is a row of 2.12.0 to 2.14.0.

### Verification

| step | last lines |
|---|---|
| `node tools/check_learner_texts.mjs --explain <chain id>`, for each of the 17 chains | the worksheets (budget, links and C4 words, C5 words, R6 numbers, R8 words), read before each chain was written |
| `node tools/check_learner_texts.mjs --file content/chains/learner/<page>.json --fix`, after each chain (four chains twice, above) | rule, cells, steps-coupling, steps-baez: `PASS: all 24 rules hold for every record` |
| `node tools/check_learner_texts.mjs` (every learner file together, the self-tests first) | `PASS: all 24 rules hold for every record` (1253 records at the last merge; the spans of cells 15, rule 31, steps-baez 16, steps-coupling 25) |
| `npm run content` (after `rule`; after `cells` and `steps/coupling`; after `steps/baez`; once more after the last edits) | `merge_chains --check: 41 chains on 6 page(s), 17 storied (0 reviewed), 87 spans; round-14 rows: 40 story rows, 13 statement rows` · `validation errors 0, warnings 0` · `errors 0, warnings 0; see docs/COVERAGE.md`; `texts.json` holds the 87 spans, every pilot chain `story: "draft"` in `content/chains.json` |
| `node tests/coverage.test.mjs` (after each merge; the run after `cells` and `steps/coupling` failed on the 40-character windows, above) | `chains (round 14): … 23904 statements of chains read with their chain, 10800 connective words within 24 characters, 864 status lines within 60, 1224 story paragraphs of statements only, 5544 chain titles free of row words` · `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` |
| `sh build.sh` | `dist: 871 files, 52.09 MB — app.js 976.4 kB (298.9 kB gzipped), app.css 118.8 kB, …` |
| `node tests/ui/chains.smoke.test.mjs` | `chains.smoke: 308 checks; 6 screenshots (…)` · `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: … learner stories of spans only, each told row once, …` (part 4 walks every page the merged chains name, the four pilot pages among them) |
| a look at learner level (Playwright on `dist/`, 1366 px: `#/rule?l=learner` · genesis, `#/steps/coupling?l=learner` · off-modes) | each chain one paragraph of its spans in order, the mention dotted, the badge "our idea" inline at GEN-006 and at ATY-047; no console error |
| `node tests/chains.test.mjs` (B1's; not a gate of this brief) | **fails in part D**, before its summary: the test copies `content/` (with `content/chains/learner/`) to a temporary folder, removes `content/chains/pilot/` and adds its fixture, so the pilot spans name chains that are gone (C1 on the 87 spans, R6 and R8 on the ATY-041 mention) and the pipeline stops at its first step (`ENOENT … docs/COVERAGE.md`). Run on a scratch copy with one line added (part D also removes the four pilot span files from its temporary copy), parts A–C and E–G pass, and part D fails once more, on "the pipeline keeps the eleven spans": 34, the other 23 from `content/chains/learner/shifted.json`, another run's file. The fix is B1's: part D empties `content/chains/learner/` in its copy before adding the fixture's spans. |

## 2. `shifted`, Calibration 3 (T3s)

The learner texts of `#/shifted`, written under `docs/round14/STORY_ROUND.md` §7 (the storyteller), §2.2 (the span record), §3.2 (C1–C11) and §6.1 (the page), from the chain records of `content/chains/shifted/chains.json`, the research texts of the rows and of `content/chains/shifted/texts.json`, the learnerFrame of `content/chains/shifted/page.json` and the reasoning of `docs/round9/SHIFTED_VIEW_NARRATIVE.md`. One file: `content/chains/learner/shifted.json`, 95 records, every one `status: "draft"`, `source: "storyteller@2026-10-17"`, waiting for the owner's review.

### 2.1 What was written

| what | records | rows |
|---|---:|---|
| spans of the 17 chains (register `span`) | 60 | 38 told positions and 22 mentions, one span per position in chain order |
| learner texts of the chain leads (register `full`) | 8 | ATY-751 … ATY-758 (each at most 300 characters, no number) |
| learner texts of the page rows and section leads (`full`) | 15 | ATY-701 (page lead), ATY-702 (detail), ATY-703 (next), ATY-711 … ATY-722 |
| learner full texts of told rows that had none anywhere (`full`) | 12 | MAP-018, INP-049, ATY-056 … ATY-065 (their status words kept: input, open, our reading) |

All 17 chains are storied: none was rejected by the checker, none rejected twice, none left unstoried. The page has no side notes (every row placed on `shifted` is told in a chain), so no side-note text was needed. No told row of the page has a human learner text (ATY-005's short hero text is a translator draft), so C10 did not apply and no span is a human text. ATY-701 and ATY-703 are written from their research texts and the learnerFrame (its sentences kept, with the name the row does not carry left out, R12).

The stories, chain by chain (lead and spans against C7's budget of 0.8 × the research texts of the positions):

| chain | positions (mentions in parentheses) | lead | story / budget |
|---|---|---|---:|
| `sv-1.labels` | EQN-008, MAP-018 | — | 229 / 232 |
| `sv-2.toy` | (ATY-041), (ATY-038) | — | 260 / 5280 |
| `sv-3.shift` | ATY-004, (ATY-005), ATY-006, ATY-011, ATY-041 | — | 4491 / 6358 |
| `sv-4.lattice` | ATY-005, ATY-009 | — | 1793 / 1817 |
| `sv-5.clock` | ATY-037, ATY-038, ATY-039 | ATY-751 | 5438 / 6453 |
| `sv-5.tensor` | ATY-042, ATY-043, ATY-044 | ATY-752 | 4195 / 5258 |
| `sv-6a.family` | ATY-007, (ATY-039), ATY-010 | — | 2528 / 3899 |
| `sv-6b.mixed` | (ATY-041), ATY-045, ATY-040 | — | 3517 / 6506 |
| `sv-6c.massless` | (ATY-005), (ATY-007) | ATY-753 | 440 / 2286 |
| `sv-6c.potential` | ATY-008, ATY-046 | ATY-754 | 2924 / 2980 |
| `sv-7.ricci` | ATY-051, (ATY-010), ATY-052, ATY-053 | — | 4729 / 6667 |
| `sv-8.radius` | ATY-054, LNS-017e, ATY-055 | — | 3605 / 3612 |
| `sv-9.mu` | (ATY-005), (ATY-037), (ATY-039), (ATY-040), ATY-065 | — | 933 / 7265 |
| `sv-open.q1` | INP-049, (ATY-052), (ATY-053), ATY-056, ATY-057 | ATY-755 | 2497 / 6330 |
| `sv-open.q2` | (ATY-007), ATY-058, (ATY-039), ATY-059, (ATY-040), ATY-060 | ATY-756 | 1879 / 5286 |
| `sv-open.q3` | (ATY-009), (ATY-037), ATY-061, (ATY-041), ATY-062, (ATY-046), ATY-047, ATY-063 | ATY-757 | 3060 / 9788 |
| `sv-open.numbers` | (ATY-055), ATY-064 | ATY-758 | 707 / 1849 |

**The words.** One set of plain names runs through the page, so that a reader meets each once and keeps it: *the strength* (κ), *the delay* or *the shift* (τ), *the strength times the delay* (μ, the paper's one number), *the quarter turn* (J, the element of the labels that squares to minus one, in the place of the imaginary unit), *the rung* (n; "every number of quarter turns" where a row says for every n), *switches* (generators), *the electron's equation* (the Dirac equation), *the minus variant*, *the difference variant* (delay and advance with opposite signs, D_s) and *the sum variant* (D_c), *the Hermitian half* and *the anti-Hermitian half*, *arrow fields* (1-forms), *a table of energy and momentum* (the tensor), *the part spread over the delay* (the bilocal term), *the particle count* (the Noether number), *redshifted like any clock*. The paper's moves are told as moves ("the paper takes", "asks", "reads"), the labels' results as results, the status words as the rows give them; nothing says that nature has the shift.

### 2.2 The rules that bit, and how they were met

No piece failed the checker once written; these rules shaped the words before the checker saw them, and the coverage test bit once after the first merge.

- **C7, the budget.** Four chains run close to it: `sv-1.labels` (229 of 232: EQN-008's research text is 46 characters, so the two spans tell the 8 numbers and 40 links, then MAP-018's current, its parts and its counts in one sentence; the complete MAP-018 is in its full text), `sv-4.lattice` (1793 of 1817), `sv-6c.potential` (2924 of 2980), `sv-8.radius` (3605 of 3612). Where the budget would not hold a minor clause, the full statement stays in the row's research text and drawer.
- **R6, every number.** A precision printed with a superscript exponent counts as its digits (3·10⁻¹⁵ asks for 3 and 10), and "3e-15" in a learner text would be a number the row lacks (R7): such precisions are written "3 times 10 to the minus 15" (A64: they stay in the spans). Numbers inside equation labels count unless parenthesised alone, so the paper's 2.2.3, 2.2.4, 2.3d, 3.3a to 3.3c, 3.5a to 3.5c and 3.6 are written without parentheses. The densest spans keep 21 and 22 numbers (ATY-045, ATY-041).
- **R4, no symbol.** No Greek letter or single letter: μ, κ, τ, J, n, E, m become the names of §1; "e" in "e-folding" is told as "growth times".
- **R8 and C5, the status words.** "For every n" needs "every number" (not "every rung"). A proved row's span carries no *input*, *a choice*, *open* or *ours* unless its research text does: ATY-010, ATY-052 and ATY-053 keep "our reading", "inputs" and "open" because theirs do; ATY-046 keeps "not settled". Each weak link says its word: INP-049 *input* ("a choice of sign convention: an input"), ATY-011, ATY-047, ATY-058, ATY-061, ATY-062, ATY-065 *our reading*, ATY-056, ATY-057, ATY-059, ATY-060, ATY-063, ATY-064 *open*.
- **R12, names.** A name inside a sentence must be in the row's research text: "Dirac" is not in ATY-010's or ATY-052's, so they say "the unshifted operator"; "Compton" is not in ATY-005's ("quarter wavelengths of the particle"); "Furey" is not in ATY-701's, so the learnerFrame's first sentence reads "Warm-up 2 counted families of particles on the labels".
- **R5, history words.** "correction" is banned (P2): ATY-052's "first-order correction 2μ" reads "a first-order change of twice that number", ATY-051's connection "no extra term for the curving frame"; "no longer" is avoided in ATY-717.
- **C4, the openers.** `derives`: So, Then, Hence, From the; `instance` (ATY-041 in `sv-3`): For instance; `cycle` back (ATY-010 in `sv-7`): Behind this; `equiv` back (LNS-017e): This rests on; `uses-input` (ATY-052 in `q1`): Given that input; `order` links open freely and never with a derivation or contrast word: "Beside it" (MAP-018), "The paper writes" (ATY-038), "Their products" (ATY-010), "Two quantized waves" (ATY-040), "Alongside" (ATY-040 in `q2`), "At rest" (ATY-041 in `q3`).
- **C6, the leads.** No digit and no claim word of T2 (exactly, holds, never, cannot …), so T1–T5 find nothing to test and each lead passes; each is at most 284 characters.
- **The words rule of `tests/coverage.test.mjs`.** The first full run failed 16 renders of `#/notes/moore`: the ATY-038 span of `sv-5.clock` shared 75 characters with a note of `content/notes.json` that the page prints outside a statement ("… time alone the shift delays one half of the field and advances the other, …"). That sentence was rephrased in ATY-038 and in both spans of ATY-041 (`sv-3.shift`, `sv-open.q3`), and every record was then scanned against the strings that pages print outside statements; seven more runs of 40 to 62 shared characters were rephrased before they could bite (the atiyah lens dictionary of `content/lenses.json`: ATY-046, ATY-047, INP-049 span and full text, ATY-056 full text; `content/stored_shifted.json`: ATY-055, ATY-064 span and full text). Only the learnerFrame of `content/pages.json` still shares words with ATY-701 and ATY-703; no component prints it. The second run passed.
- **The fold of a long statement.** A body statement longer than 700 characters renders folded behind "Show all" (`src/components/Statement.jsx`, `LONG.body`): seven leads (ATY-702, ATY-711, ATY-713, ATY-714, ATY-716, ATY-719, ATY-720) were cut to 673–699 characters, so every lead of the page reads whole at learner level.

### 2.3 The commands run, and their last lines

| command | last line |
|---|---|
| `node tools/check_learner_texts.mjs --file content/chains/learner/shifted.json --fix` (after each of the 11 pieces and each edit) | `PASS: all 24 rules hold for every record` (95 records) |
| `node tools/check_learner_texts.mjs` (all learner files together, R3 across files) | `PASS: all 24 rules hold for every record` (1449 records; spans of shifted 60) |
| `node tools/merge_chains.mjs --check` | `merge_chains --check: 41 chains on 6 page(s), 41 storied (0 reviewed), 196 spans; round-14 rows: 40 story rows, 13 statement rows` |
| `npm run content` | `errors 0, warnings 0; see docs/COVERAGE.md` (merge_story: `chains 41 (41 storied, 196 spans; …)`); the 95 records are in `content/texts.json` verbatim |
| `node tests/coverage.test.mjs` | `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` |
| `node tests/story/shifted.test.mjs` | `PASS shifted: Calibration 3 after Calibration 2 (12 sections in 4 parts, 17 chains, 38 told positions and 22 mentions, 23 story rows through T4/T5, 10 new rows), …; 18 of 18 broken copies caught` |
| `sh build.sh` | `export_tuning: 1,892 records, 3,779 texts, 367 checks and 624 runs, 35 lenses, 7.32 MB in dist/content/tuning/` |
| Playwright on `dist/`, `#/shifted?l=learner` at 1366 px light and dark, 390 px light | 17 story paragraphs, 68 statements (60 spans, 8 chain leads), no `ol.chain__list`, every lead whole, 0 console errors, 0 horizontal overflow |
| `node tests/ui/chains.smoke.test.mjs` | `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: …` (308 checks) |

### 2.4 Notes for the other owners

- `tests/chains.test.mjs` stops in part D (`ENOENT … /tmp/one-rule-chains-*/docs/COVERAGE.md`): the test copies `content/` without `content/chains/pilot/` but with `content/chains/learner/`, so the pilot spans fail C1 in the copy's first step and the pipeline never writes `docs/COVERAGE.md`. No failure in that copy involves a `shifted` span (checked on a copy). For B1.
- `tests/story/shifted.test.mjs` prints "38 told rows … wait for their learner texts": its learner-level parse reads `ol.chain__list` items only, and a storied chain renders as `p.chain__story`; all 38 are drawn as spans ("0 story rows wait"). For B3.
- At learner level the spans carry the badge "new" (`NEW_SINCE` still covers v16 … v2.15); A60's single-version rule is R7's change and will leave only the badges of what is not proved.

## 3. `matter` and `matter/papers`, Calibration 2 (T3m)

The storyteller of `docs/round14/STORY_ROUND.md` §7 (T3m) wrote the learner words of Furey's recomposed overview and of its papers sub-page, on B4's chain records (`content/chains/matter/chains.json`), story rows and research texts (`content/chains/matter/{rows,texts}.json`) and on the page entries of `content/story/furey.json`. **All seven chains of `matter` are storied; none is left out** (D54 applies to none). Every record has the shape of §2.2 (`lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@2026-10-17"`; the five human spans `status: "human"` with their human source, C10); `termsUsed` and `keptNumbers` are computed by the checker's own functions (`termsIn`, `requiredNumbers`), never typed.

| file | records | what |
|---|---:|---|
| `content/chains/learner/matter.json` | 94 | 49 spans of the 7 chains (47 told positions with the five twins, 2 mentions; 5 of them the human words of FUR-001 … FUR-005, C10); the chain leads FUR-751, FUR-752; the page lead FUR-701, the next line FUR-702, the section leads FUR-711 … FUR-716; 35 learner `full` texts: FUR-007 … FUR-037, the questions FUR-038 … FUR-040, the side note CAND-049 |
| `content/chains/learner/matter-papers.json` | 7 | the lead of the section `read`, FUR-717, and the six cards FUR-761 … FUR-766 |

INP-011 already has a learner `full` text (a translator draft) and gets none here (a second record would be R3's duplicate); its span in `fur-next` carries the status word its draft lacks ("inputs we bring in", C5). The twins FUR-001b … FUR-005b keep their translator drafts as their `full` texts (on `matter/model`); their spans are new words. FUR-006 has a *reviewed* learner text (`lead:L7-10`): not human, so C10 does not bind it; its span is those reviewed words shortened to fit the chain's budget (C7 left 4516 characters for ten records), and the reviewed text stays its `full` text everywhere else.

### The chains

| chain | shape | positions | mentions | lead | links (in order) | spans (human) | story / budget (C7) |
|---|---|---:|---:|---|---|---|---|
| `matter.fur-model.rebuilt` | fork | 6 + 4 twins | 0 | — | derives, order, derives, derives, derives·FUR-003 | 10 (4) | 4515 / 4516 |
| `matter.fur-fibre.fibre-base` | fork | 7 | 0 | — | order, derives, derives, derives, derives, derives·FUR-010 | 7 | 8484 / 8498 |
| `matter.fur-labels.cl6` | fork | 6 | 0 | FUR-751 | derives, derives, derives, derives·FUR-017, derives | 6 | 9540 / 9544 |
| `matter.fur-labels.roadmap` | line | 5 | 0 | FUR-752 | order, derives, derives, derives | 5 | 7676 / 7685 |
| `matter.fur-sixteen.weights` | fork | 7 | 0 | — | order, equiv, derives·FUR-020, derives·FUR-022, derives·FUR-020, derives·FUR-023 | 7 | 12384 / 12452 |
| `matter.fur-fields.mass` | fork | 5 | 0 | — | derives, derives·FUR-024, derives·FUR-025, derives·FUR-024 | 5 | 5958 / 6716 |
| `matter.fur-next.open` | fork | 8 + 1 twin | 2 | — | uses-input, uses-input·INP-011, derives, order, derives, uses-input·INP-011, derives | 9 (1) | 3890 / 5571 |

The openings follow C4 exactly: "So", "From the same …", "From the eight states …" on `derives` links; "The same sixteen …" on the one `equiv` link (FUR-022); "Given …", "Taking …" on the `uses-input` links of `fur-next` (FUR-014 and the two mentions); free openings with no derivation or contrast word on the five `order` links ("Under the blocks lies a finer grid", CAND-102; "Beside it, her fibre", FUR-008; "Beside them, the roadmap's algebra", FUR-028; "Beside it stands the compact cell", FUR-021; "Also not settled", FUR-005b). The weak links say their status in the span (C5): INP-011 an input ("inputs we bring in"), FUR-014 our reading, FUR-038, FUR-005b, FUR-039 and FUR-040 open ("stays open", "not settled", "not known here"). The human words of FUR-001 … FUR-005 stand verbatim (A63); the spans beside them carry the links (CAND-102 introduces the seven line blades and the 16 axes that FUR-003's "16 lanes" then names; FUR-006 continues "From the same seven blades"). The two mentions recall in one sentence, with no number: FUR-034 ("the turns of space and time and the compact turns become one algebra only once made complex") and FUR-026 ("two fibre momenta are two masses … which masses occur is an input").

The leads FUR-751 and FUR-752 hold no digit and no claim word, so they pass T1–T5 against their chains as narration (C6), at 250 and 292 characters.

### The story rows

- **FUR-701**, the page lead, in three movements from its research text and the stored learnerFrame: her results ("Furey reads one family of the Standard Model in the four number systems … her reading, recalled"), the Atlas's proven results ("On the switches the Atlas rebuilds her board …, her three ladders …, the five modes of her roadmap as five switches, space beside the inner switches, where the hand is a relative sign between two quarter-turns, the family of 16 …, waves whose inner motion is a mass"), the next steps ("What comes next is an input or open: which way of joining nature uses, how the turns of space and time meet the weak force, three families, and which inner motions occur"). It never says which product or split nature uses.
- **FUR-702**, the next line: the five tabs, then "Warm-up 3 follows: the delayed waves of Atiyah and Moore." (the learner name of Calibration 3 opens its sentence: R12 refuses "Warm-up" inside one, the research text naming "Calibration 3").
- **FUR-711 … FUR-716**, the section leads, each the research lead in the section's learner words, the status words kept (FUR-711 and FUR-714 "an input", FUR-716 "an input", "our reading", "open").
- **FUR-717 and the cards FUR-761 … FUR-766**: each card names the paper by its author(s) and year in parentheses and its arXiv number, says read in the original or "recalled, not read" (FUR-762, the thesis), what the paper builds in plain words, and what the switches rebuilt, naming the rows as other learner texts do ("(row FUR-015)"). The journal reference of FUR-761, "Phys. Lett. B 742", becomes "journal volume 742" (the lone letter B is a variable for R4, "Physics Letters" a new name for R12; the number is kept, R6); the script of FUR-765 is "her papers' check" (R13). The cards' order is the papers' order (2015, 2016, 2018, 2022, 2023, 2024).

### The full texts

FUR-007 … FUR-037 sit on `matter/model` (and some on `steps/coupling`, `steps/baez`, `steps/schuller`) outside a storied chain, and had no learner text anywhere: each `full` text is its span made to stand alone (the chain's opening replaced, e.g. "So her hand is the parity of a label." → "Her hand is the parity of a label.") with the clauses the chain's budget had left out put back (FUR-007, 009, 012, 015, 016, 019, 020). FUR-038 … FUR-040 begin "Open:" as their research texts do. CAND-049 (the doublet and the masses of the weak bosons) is the side note of `fur-model`, drawn under "More statements".

### The voice

The names of the earlier story round on these pages: the big board, its blocks, links and lanes (axes), the special key (her complex structure, a quarter-turn), switches (generators), labels, cells, grids (matrix algebras: "real 8 by 8 grids"), planes (bivectors), turns (the Lie algebras), the hand (chirality), ladders, the count (number operator), the vacuum, paired switches (Witt pairs), "her reading" for Furey's identifications, "recalled" and "not computed" where the rows say so. "Box" is left to the board's squares (the human texts' word) and not used for a cell, as the pilot pages do. No formula, no symbol as a variable, no Greek letter; cell and algebra names (Cl(1,9), so(10), su(3)) stay as names. The word "new" is not used (A60).

### What the budget cost

C7 (the story at most 0.8 of the research texts) and R6 (every number kept) together bound the dense rows of 2.12.0–2.14.0: five chains end within 1 % of their budgets. Every number, scope and status word of every told row is in its span; the results are all told; what was compressed is method detail, and a few clauses restated from a neighbouring row: the matrix cross-checks to "complex Pauli matrices agree" and the like; in FUR-012 the restated "each half is a complex 8, 2 times 4" (told in FUR-011); in FUR-019 "neither the vacuum with the single states nor the double states with the top state is kept"; in FUR-016 the sign of the other dagger; in FUR-028 the parenthesis on the other unit ("not −R_{ε₂}, which is −Γ₁₀"; "as the paper's v1 prints its eq. 27" stays) and the images of the volume element and of the complex unit; in FUR-034 the counts of pairs written as powers of two ("all pairs", "exactly the pairs whose labels both hold bit 0"). The `full` texts carry most of these back. FUR-032 keeps "the embedding of pass 10a", the only way to keep its number 10 (R6). If the owner wants every clause in the spans, the budget of these chains would need 0.9 (A64's spirit applied to C7).

### Verification

| step | result |
|---|---|
| `node tools/check_learner_texts.mjs` after each of the four pieces (chains 1–2; 3–4; 5–7 with the section leads; the story rows, cards and full texts) | PASS each time, at the first run, all 24 rules (R1–R13, C1–C11); last: 1449 records, "spans of matter 49" |
| `node tools/merge_chains.mjs --check` | 41 chains on 6 pages, 41 storied, 196 spans; no warning left on a matter row |
| `npm run content` | errors 0, warnings 0; chains 41 (41 storied, 196 spans), round-14 rows 53, learner texts 88 |
| `node tests/story/furey.test.mjs` | PASS (17 story rows through T4/T5, 3 questions, 20 of 20 broken copies caught) |
| `node tests/coverage.test.mjs` | PASS (2952 story paragraphs of statements only; no row words outside a statement) |
| `sh build.sh`, then Playwright on `#/matter?l=learner` (physics and mathematics), `#/matter/papers?l=learner`, 1366 px light and 390 px dark | 7 story paragraphs on `matter` (the twins' spans in mathematics), the 7 records of `read` on `matter/papers`; no horizontal overflow, no console error |
| `node tests/ui/chains.smoke.test.mjs` (B2) | PASS, 308 checks (part 4: every page with chains, `matter` among them, at both levels, 390 and 1366 px) |

Drafting ran the checker's own functions on these records alone before each write (C7 overruns on five chains, and single failures fixed in the drafts: R4 a brace in FUR-019, R7 a digit 15 that FUR-013's research writes as a word, R8 "not read" in FUR-001b, R12 "Warm-up" inside a sentence in FUR-702, C4 two openings on `derives` links in FUR-013 and FUR-036, C6 a lead of 305 characters in FUR-752); the written pieces were never rejected. `tests/chains.test.mjs` stops in part D on the defect INTEGRATION_NOTES.md records (the copy keeps the learner files), after parts A–C.

## 4. `cells` · cards, `clock`, `light` (T4a, wave 2)

The record stands on its own: `docs/round15/LEARNER_TEXTS_wave2_a.md`. In short: the 30 chains of `docs/round15/SPINE_wave2.md` §4–§6, all storied at the first write of each piece; 99 spans (96 told positions, 3 mentions: LAB-017, MAP-003 and ATL-017), PAG-023's human words verbatim at the head of `light.views.cube` (C10); the learner texts of the four section leads (ATL-711, LAB-711, LAB-712, PAG-711); the full texts of ATL-001b, ATL-002b and CAND-086, which waited for their wave. The card rows, short and dense with symbols, met C7 at 188 of 192 characters (`cells.cards.phase`) and four chains end exactly at their budgets; what the budget cost is listed there (§4), never a number, a scope or a status word. Its notes for the owner (§5): PAG-023's human words are a fragment of a v15 tag; LAB-003's translator draft said "ours" where the row is proved (that draft is in the retire book since 2.16.0); the inputs fold of `light` drew nothing at learner level (written by R8 in this release, above); 0.9 for the card rows would let the compressions back in.

## 5. Steps 2–4 and the pilot's leftovers (T4b, wave 2)

The record stands on its own: `docs/round15/LEARNER_TEXTS_wave2_b.md`. In short: the four chains of `steps/comm` and `steps/mirrors`, each passing the checker at its first run; 15 spans (14 drafts and GOS-001's human words, C10); the learner text of the section lead MIR-711; the full texts of the pilot's leftovers CAND-013, CAND-084, CPL-007c and CPL-007d (side notes of `steps/coupling`) and of CAND-002 and MIR-005, told rows of `steps-mirrors.eq-mirrors.pin` that had no learner text. Every told row of the four chains is proved, so no story carries a badge. Its notes for the lead (§8): the retire would have taken the full draft of EQN-003, the hero of `steps/comm` without a short text (kept since 2.16.0 by D66); the spans of GEN-026, GEN-030 and FUR-039 needed the checker again once pass 12a's edits were applied (done by R8, above).

## 6. Steps 5–8 (T5a, wave 3)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave3_a.md`. In short: the 12 chains of `docs/round16/SPINE_wave3.md` §3–§6 on `steps/spin`, `steps/coupling` (three chains after the pilot's five), `steps/ym` and `steps/matter`, each passing the checker at its first write; 38 spans (37 told positions and the mention of CAND-124 that opens the Skyrme chain); the learner texts of the six section leads (SPN-711, CPL-711, YM-711, YM-712, YM-713, MAT-711); the full texts of the 21 side notes of the four pages (the matrix's verdict and honest notes of `steps/spin`, the tallies, the dead end CPL-006, the Wilson plaquettes, the Cartan curvature …), 18 of them beside translator drafts under D68. Every chain ends at 98–100 % of its budget; what the budget cost is listed there (§4), never a number, a scope or a status word. Its notes for the owner (§8): EQN-009's 72 and 24; YM-007b told without a full text; SPN-001's full text as the page-top line of `steps/spin`.

## 7. The Furey tabs and the leftovers (T5b, wave 3)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave3_b.md`. In short: the two chains of `matter/model` (`edges.charges`, `axes.states`), 16 spans, FUR-002, FUR-003 and FUR-004 in their human words and their twins in mathematics (C10, C11); the learner texts of FUR-718 and FUR-719; the full texts of FUR-001b and FUR-005b (the mathematics twins beside the human side notes), of the leftovers FUR-041 and FUR-042 (on `matter` and the tab) and of GEN-033 and GEN-034 (on `rule` and `cells`); `edges` ends within 0.5 % of its budget. Its notes (§7): FUR-001b's text folds behind "Show all"; `cells` · cards draws no side note in its body, so GEN-033 and GEN-034 show on `rule` and in the cards' drawer.

## 8. Gravity I and II (T6a, wave 4)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave4_a.md`. In short: the seven chains of `steps/grav1` and `steps/grav2`, 38 spans (37 told, the mention of GRV-012), the leads GRV-711 and GRV-712, the full texts of ATY-017, ATY-018, EQN-012, CAND-118 and EQN-013; twelve told rows speak at learner level for the first time; four chains end within 0.6 % of their budgets (GRV-011 alone has 9,773 characters of research text). Its notes (§7): the identifier trap of the checker (the rule fixed at the release, D69); ATY-017's control h, given as the row gives it; 40 windows rephrased against the Logbook's ledger and the inputs.

## 9. The projective step, gauge gravity and null surfaces (T6b, wave 4)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave4_b.md`. In short: the eight chains of `steps/projective`, `steps/gauge` and `steps/nullsurf`, 28 spans, every position proved (no weak link; the status words of the research texts kept), NUL-001 told on `steps/gauge` and on `steps/nullsurf` with a span in each; the leads PRJ-711, PRJ-712, LAB-713, LAB-714, NUL-711; the full texts of EQN-015 and of the fourteen side notes of `steps/nullsurf` (the three other results of the paper, the honest notes saying what stays open, the links, the tally, CAND-016, CAND-085); seven chains end within 1 % of their budgets. Its notes (§7): eight full texts fold behind "Show all"; `surface-gravity` is the tightest chain of the wave.

## 10. Forque, the spring and the rigid body (T7a, wave 5)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave5_a.md`. In short: the four chains of `steps/forque`, `steps/spring` and `steps/rigid` (two of them, `hung` and `tumbling`, in the top notes' words as well), 15 spans at 99.5–99.9 % of their budgets; the leads FRQ-711 and SPR-711; the full texts of the 19 side notes — the notes of the two translation matrices (FRQ-001 … FRQ-005, RIG-001 … RIG-007), the tallies (EQN-016, EQN-018, EQN-019 with all its 40 numbers), SPR-001, CAND-034, CAND-036, CAND-132; FRQ-001 and RIG-001 as the page-top lines of their pages. Its notes (§7): SPR-003's span may not say "ours" (the lead SPR-711 does); SPR-001's top keeps its short draft; the screen hits left on purpose against INP-076's research text.

## 11. Finite groups and the shapes page (T7b, wave 5)

The record stands on its own: `docs/round16/LEARNER_TEXTS_wave5_b.md`. In short: the nine chains of `steps/groups` and `shapes`, 36 spans (32 drafts and the four human texts of GOS-001 … GOS-004, which make `shapes.sh-gosset.views` the first chain reviewed by construction; the mention of SHP-001 opens `sizes`); the lead LAB-715; the full texts of LAB-011, LAB-012, CAND-008, CAND-116 and MAP-022; the densest rows of the Atlas (`lattices`, `del-pezzo`) at 99.6–99.8 % of their budgets, with the clauses left to the drawer listed. Its notes (§7): 0.9 would let those clauses back; eleven spans and one full text fold behind "Show all".

## 12. Category, Baez and Schuller (T8a … T8e, T9a, T9b, wave 6)

The records stand on their own: `docs/round16/LEARNER_TEXTS_wave6_t8a.md` and `_t8b.md` (`steps/category`, in two halves: 23 chains, 94 told positions, 88 side notes, the leads LNC-711 … LNC-718), `_t8c.md`, `_t8d.md` and `_t8e.md` (`steps/baez`, in three: 31 chains beside the pilot's three, 145 told positions with five mentions, 47 side notes, the leads LNB-711 … LNB-716; T8d's record written by the lead from the tables), `_t9a.md` and `_t9b.md` (`steps/schuller`, in two: 15 chains, 88 told positions, 72 side notes, the leads LNS-711 … LNS-716). The spines: `docs/round16/SPINE_wave6_category.md`, `SPINE_wave6_baez.md`, `SPINE_wave6_schuller.md`; the hand-back: `docs/round16/INTEGRATION_NOTES.md`; the release: `docs/RELEASE_NOTES_v2.18.md`.

## 13. The close (T10a, T10b, T10c, the lead; 3.0.0)

The records stand on their own: `docs/round16/LEARNER_TEXTS_sweep_T10a.md` (`rule`, `cells`, `clock`, `light`: 30 full texts), `_T10b.md` (`steps/comm`, `steps/mirrors`, `steps/dirac`, `steps/coupling`: 31), `_T10c.md` (`matter`, the Baez generation: 30) — every side note of the wave-1 and wave-2 pages whose learner text was still the translator's draft or missing, each a story of one piece under R1–R13 — and `docs/round16/LEARNER_TEXTS_close.md` (the lead: the three input rows of `steps/baez` and the 42 input rows of the step pages that had no learner words, `content/chains/learner/close.json`; the retire of 3.0.0 and what stays, D70). The release: `docs/RELEASE_NOTES_v3.0.md`.
