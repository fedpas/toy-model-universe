<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts of the story rows: the drafts of the story persona

`content/texts_learner_story.json` holds **125 learner drafts**, one for each story row (kind `story`) that has a research text and no learner text in `content/texts.json` after the merges; **no row is left out**. With them every one of the 364 story rows has a learner text: 239 are the author's v15 Young Learner words (status `human`, paired by the migration, `docs/STORY_PLAN.md` §1.5), 125 are these drafts. A story row without a learner text is not shown at learner level, so these drafts bring 125 narration paragraphs (29 section leads, 43 captions, 32 results, 19 details, 2 next lines) to the learner pages; sections whose rows have no other learner text (the rungs of `steps/rigid`, the oscillator of `steps/spring`) appear at that level through them.

Each record has the shape of `texts.json` and the two derived fields of the checker, computed by it (`node tools/check_learner_texts.mjs --fix`), never typed:

```json
{ "row": "RIG-516", "lang": "en", "mode": "both", "level": "learner", "lens": null, "register": "full",
  "body": "What is the simplest body that can move, and how many different kinds of motion can one spring give it?",
  "status": "draft", "source": "translator:story@2026-10-12", "termsUsed": [], "keptNumbers": [] }
```

The persona is the story variant of the learner persona (`docs/09_TRANSLATION_PROTOCOL.md` §2, `docs/STORY_PLAN.md` §1.5): *one narration paragraph of the Atlas rewritten for a reader before university: plain words, no formula, no symbol as a variable, no Greek letter; no number and no claim the paragraph does not make; every number, scope and status word it has kept.* A caption stays a caption, a question (the leads of the rigid, spring and spin threads) stays a question, an instruction ("Click a line …", "Pick the dimension …") stays an instruction. The checker's rules R1–R13 apply unchanged; R1 accepts the source `translator:story@…` beside `translator:learner@…`.

The same round drafts the **eight matrix lines** whose research text writes one half as `\tfrac12` (FRQ-M11, FRQ-M13, FRQ-M25, FRQ-M26, SPN-M09, SPN-M11, SPN-M14, SPN-M16) in `content/texts_learner_matrix.json`, with the matrix persona of `docs/LEARNER_TEXTS_matrix.md` and the source `translator:learner@2026-10-12`; the matrices then have a learner text for all 149 lines.

## Drafts by page

| page | drafts | roles |
|---|---|---|
| `steps/rigid` | 34 | 7 lead, 12 caption, 12 result, 2 detail, 1 next |
| `steps/spring` | 14 | 6 lead, 5 caption, 2 result, 1 next |
| `steps/spin` | 13 | 4 lead, 1 caption, 6 result, 2 detail |
| `steps/category` | 12 | 4 lead, 2 result, 6 detail |
| `steps/baez` | 11 | 4 lead, 2 caption, 1 result, 4 detail |
| `steps/schuller` | 10 | 4 lead, 2 caption, 1 result, 3 detail |
| `light` | 7 | 7 caption |
| `steps/nullsurf` | 6 | 6 caption |
| `steps/forque` | 5 | 2 caption, 1 result, 2 detail |
| `clock` | 5 | 4 caption, 1 result |
| `shapes` | 3 | 3 result |
| `steps/gauge` | 2 | 1 caption, 1 result |
| `matter/dictionary` | 1 | 1 caption |
| `rule` | 1 | 1 result |
| `steps/projective` | 1 | 1 result |
| all | 125 | 29 lead, 43 caption, 32 result, 19 detail, 2 next |

Lengths run from 56 to 754 characters (median 147). No draft repeats its research text word for word.

## Verification

| step | result |
|---|---|
| `node tools/check_learner_texts.mjs` (every `texts_learner*.json` together, its self-test first) | PASS: 985 records, all 13 rules; no row drafted twice |
| `node tools/check_learner_texts.mjs --file content/texts_learner_story.json` | PASS: 125 records |
| `npm run content` | 0 errors and 224 warnings, the warnings of the base tables (none about a text); `texts.json` gains 133 records (125 story drafts and 8 matrix lines) and loses or changes none; `rows.json`, `pages.json` and `derived/status.json` byte for byte unchanged (status comes from evidence and label only); a second run writes the same bytes |
| `node tests/story.test.mjs` | 4 of 4 test files pass (the migration test also with the v15 package: 14869 checks) |
| `node tests/physics/matrix_learner.test.mjs` | 478 of 478 checks hold: spin 30 of 30, forque 41 of 41, spring 22 of 22, rigid body 56 of 56 |
| `node tests/physics.test.mjs` | 10 of 10 test files pass |
| `node tests/logbook.test.mjs` | 554 of 554 checks hold (the register's facet "learner text" counts the drafts) |
| `node tests/coverage.test.mjs` (under the browser lock) | PASS: 6139 renders of 96 routes, 203527 statements checked; every statement is the text record of its row, no KaTeX node at learner level, no row words outside a statement (75077 texts) |

A planted fault in a copy of each kind is caught: a dropped status word (R8), a scientific number written out (R6), a lone letter or a person's initial (R4), a new name (R12), a new number in digits (R7), a history phrase (R5), a script name (R13).

After a fresh migration (`tools/migrate/run_all.sh`) run `npm run content` once: the merge of the drafts runs before the story merge there, when the story rows are not yet rows, so the drafts of story rows land on the next `npm run content`, as every other run of the content pipeline does.

## The rules that bit

Copied as its own learner text, the research text of these 125 rows would fail **R4 (formula) in 44 rows**, R5 (history) in one (LAB-506, the author's "no longer") and R13 (contact) in one (RIG-567, a library file name). The formula marks are the notation of the research voice: lone letters used as variables (n, k, T, J, N, B, i, x, the legend letters H, e, u), Greek letters, ℝ and 𝔽₂, sub- and superscripts, the middle dot of the check ids, equals signs, brackets of commutators. Each is said in words or, for an identifier the reader does not need (a check id, an arXiv number, a script name), dropped, since the row drawer shows the evidence.

- **R6 numbers** (18 drafts keep numbers): a scientific number is kept verbatim (RIG-567: 1e-11, 1e-13); "version 3" becomes "the third version", because the history family P8 refuses "version 3 of"; "chapter 12" is kept, since R6 does not read "ch." as a section number.
- **R7 new numbers**: no digit the paragraph lacks: "a power of two", not "of 2", where the research text has no 2.
- **R8 status words** (24 drafts): open 5, checked 8, exact 11, ours 8, standard 3, not claimed 1, not checked 1. "Open" is kept even where it is the verb ("click a line to open …"), "checked" where R8 asks for it although the learner face avoids the word elsewhere.
- **R12 names**: no initials (LNS-503 names Schuller, Düll, Stritzelberger and Wolz without them: a lone capital is a variable for R4); no "Atlas" with a capital inside a sentence; no name the paragraph does not have (SPR-548 says "one of its counts" for b₂, not a person's number).
- **R10 terms**: a glossary term listed exactly where it occurs (null 9, label 0 2, mirror 1); where a word would be read as a glossary term in another sense it is avoided: "basis", not "base" (the term base / fibre), "reflections", not "mirrors" (the convention mirror), "acting from one side", not "the action" (the action of gravity, SPN-528 and SPN-532), "pure tone", not "mode" (the Walsh mode), "corner", not "vertex".
- **R1 shape**: the source `translator:story@…` of the story persona, which R1 accepts beside `translator:learner@…`.

## The ten hardest, and why

| row | page | why |
|---|---|---|
| NUL-503 | `steps/nullsurf` | three brackets of K1, K2 and J with the time square T, every one a formula, and J and T lone letters: J is named by its corner (corner 6, the piece of the two sphere switches) and T "the time factor", as the learner drafts of the gauge step call it |
| LAB-506 | `clock` | the radical, nilpotency and the super-centre in one paragraph, with the author's "no longer" (R5): "from 4 directions on … is not enough" says the same without a history word |
| RIG-567 | `steps/rigid` | five numbers to keep, two of them scientific (1e-11, 1e-13, kept verbatim and read as eleven and thirteen decimal places), line names R1–R6, R7, R9, N9, and a library file name that R13 refuses |
| LNS-503 | `steps/schuller` | four initials (lone capitals for R4) and the sign rule as a formula, said as the product of two pieces giving a sign times the piece where exactly one of the two has a switch on |
| PRJ-509 | `steps/projective` | six scopes of the number of directions, a binomial with a variable inside, the sign flip with the symbol of the sign, and two glossary traps (base, mirror) |
| LAB-518 | `clock` | a phase-plane caption that is a formula: the three coefficients of the piece are said as amounts, "half of one minus the stiffness", and the square as minus the stiffness |
| LNS-530 | `steps/schuller` | the exterior algebra written as a formula, its swap sign as a power of minus 1, and the chapter number that R6 requires while the theorem number is an identifier |
| LNC-568 | `steps/category` | an arXiv number, a version number that P8 reads as history in "version 3 of", and two operations given by symbols |
| LNS-537 | `steps/schuller` | the legend letters H, e and u of the figure, lone letters for R4: "each marked by the first letter of its kind" keeps the meaning without printing them |
| SPN-536 | `steps/spin` | four kinds of imaginary unit told apart only by the letters b, B, i and I: they become the paper's plane, the lecture's plane, the lecture's imaginary unit and the piece of all the switches |

## The register

The words of the other learner drafts (`docs/LEARNER_TEXTS.md`) and of the author's v15 strips on the same pages: a generator is a **switch** (plus, minus, zero switch; in the physics steps a **direction**), a blade a **piece**, a bivector a **plane piece** or "a piece made of two switches" (on the clock page a **twist**, as the author's strip there says), the volume element **the piece of all the switches**, the bit rule **the switch rule**, i **the imaginary unit**, a vertex a **corner**, a mass a **weight** (on the spring and rigid pages, as the strips have it), a normal mode a **pure tone**, a row of a table a **line**, a script **the program**, a claim a **statement**. Names of researchers appear only where the paragraph names them; a cell keeps its name where the paragraph gives one (R(2,0,1), so(1,2), E8, D8).

## Points for the author

1. **Words for symbols.** Where the paragraph has only a symbol, the draft names it after its page: T in NUL-503 and NUL-520 is "the time factor"; J in NUL-503 is "the piece made of the two sphere switches" (its corner, 6); N in LNS-547 is "the number operator" (LNS-019b), not "the particle number", which LNS-019d marks as our reading; "E cells" in LNB-509 stays "the E-cells". A word in the research texts would settle each.
2. **Glosses.** A few drafts explain a word in passing: a simplex (FUR-524), an isometry (LAB-531), zero modes (RIG-506, SPR-509), a well-posed initial-value problem (PAG-546), dyadic numbers and the two tolerances (RIG-567), a frozen 1+1 model as one time and one space direction (LNS-502). Each gloss says what the word means and adds no claim; the author may prefer the bare word.
3. **GOS-509 and GOS-510** say "the corners have length 1" and "length 2", reading the paragraph's "length" as the length of the half-cube's corners, which GOS-518 (the author's strip) describes.
4. **The research-level words of three legends** (LNC-539, LNS-537, LNS-553) are short labels; their drafts are full sentences, so a reader at learner level reads the legend in words but not the letters the figure prints.
