# Physicist's labelling of chunk E (176 rows)

Chunk E holds the Furey calibration (FUR-001..005, PAG-013..016, INP-087..094), the Map page (PAG-025..027, MAP-001..035), the Ask row (PAG-028), the Schuller chapter of the lenses page (LNS-001..076, LNS-101..135) and the For-researchers rows (THM-001..006, SRC-001..003). The labels are in `out/phys_E.jsonl`: 176 rows, each once; `validate_labels.py` reports 0 problems.

Stage counts: A 31, K 39, F 25, D 22, O 30, M 29.

Conventions used here: "X -> Y" means Y rests on X (Y lists X with `derives`). In-degree counts every relation that points at a node.

---

## A. How physics would organise these rows

Physics builds from the algebra to kinematics, then fields, then motion and solutions, then comparison with observation. Method rows come last.

### A1. The algebra (stage A, 31 rows)

1. **The rule as a deformed exterior algebra.** MAP-001, THM-001, LNS-001, LNS-011, LNS-051, LNS-070, LNS-108, LNS-109. Everything starts here: the product is the wedge plus a contraction by the squares (Chevalley), and the squares are the only signature data.
2. **Duality and integration.** LNS-058, LNS-110. The top-blade (Berezin-type) functional exists for every cell. The Hodge star exists only for r = 0.
3. **Even part, type table, clock.** MAP-013, MAP-002, MAP-006, MAP-011. These come before spinors: the spin group lives in the even part, and the clock fixes whether spinors are real, complex or quaternionic.
4. **Products, mirror, commutants.** LNS-006, LNS-015, LNS-113, LNS-114, LNS-007, LNS-016, LNS-053, LNS-072, LNS-111, LNS-112. How one cell acts on another: graded products (Brauer–Wall), the mirror as the inverse, the double centraliser. LNS-114 records the failure for r ≥ 1.
5. **Sign cohomology, positivity, the cube category.** THM-003, THM-002, THM-004, SRC-001, SRC-002, SRC-003. The sign as a cocycle (the Jordan–Wigner string with π flux), bases with non-negative structure constants, the incidence algebra, and the two Majkić comparisons.
6. **The Fano blades of Cl(0,8).** FUR-003. The label algebra under the Furey calibration. Its physics conclusion, that the partition is a gauge choice, is negative.

### A2. Kinematics (stage K, 39 rows)

1. **Lorentz algebra, versors, Klein geometries, boosts.** MAP-016, MAP-022, MAP-023, THM-005.
2. **Signature selected by hyperbolicity (causal structure).** LNS-002, LNS-012, LNS-052, LNS-060, LNS-064, LNS-071, LNS-102, LNS-105, LNS-116, LNS-118. The degenerate case is LNS-045. LNS-028 is a digest.
3. **Spin.** LNS-020, LNS-004, MAP-025.
4. **Fermionic Fock space and qubits.** LNS-005, LNS-019, LNS-031, LNS-062, LNS-129, LNS-130, LNS-131, LNS-132, LNS-133, LNS-066, THM-006. Also CAR against CCR (LNS-039) and commuting observables (LNS-038).
5. **Local bundle structure (base and fibre).** LNS-036, LNS-115, LNS-050.
6. **Lattices and root systems.** MAP-012, MAP-014, LNS-009, LNS-018.

### A3. Fields and their equations (stage F, 25 rows)

1. **Electromagnetism.** MAP-003, MAP-004. Premetric media and the area metric: LNS-013, LNS-030, LNS-048.
2. **The Dirac field.** MAP-017, LNS-003, LNS-059, LNS-117, LNS-119. The Majorana question is LNS-046.
3. **Coupled systems and gauge fields.** MAP-018 (Maxwell–Dirac), MAP-019 (Yang–Mills), MAP-020 (matter currents).
4. **Gravity.** MAP-021 (structure equations, Einstein form). LNS-032 (Einstein–Cartan with spin). LNS-017, LNS-120, LNS-121 (Kaluza–Klein).
5. **Constructive gravity (closure).** LNS-010, LNS-014, LNS-029, LNS-047, LNS-049, LNS-106.

### A4. Dynamics and solutions (stage D, 22 rows)

1. **A charged particle in a field.** MAP-005.
2. **Rigid bodies and frameworks.** MAP-024, MAP-027, MAP-033.
3. **Springs, transfer matrices, bands.** MAP-026, LNS-008, LNS-022, LNS-061, LNS-124, LNS-125, LNS-126, LNS-127, LNS-122, LNS-035. The trio readings are LNS-056, LNS-067, LNS-075, LNS-123, LNS-128.
4. **Gravitational solutions.** MAP-028 (horizons), LNS-034 and LNS-107 (Schwarzschild–(anti-)de Sitter).

### A5. Observation and calibration (stage O, 30 rows)

1. **Standard Model content (Furey).** The inputs INP-087..094 come first. Then FUR-001, FUR-002, FUR-004, FUR-005, PAG-014, PAG-015, PAG-016, MAP-007, MAP-008, MAP-009, MAP-010.
2. **Quantum measurement.** LNS-021, LNS-134, LNS-135, LNS-037, LNS-055, LNS-074.
3. **Conventions and errata of the sources.** LNS-042, LNS-033, LNS-040, LNS-043, LNS-044.

### A6. Method and scope (stage M, 29 rows)

1. **What the rule cannot reach.** LNS-023, LNS-024, LNS-025, LNS-026, LNS-069, LNS-057, LNS-068, LNS-076, LNS-103.
2. **How well the Atlas matches Schuller's chain.** LNS-063, LNS-101, LNS-104. The perspective rows are LNS-027 and LNS-041.
3. **Names.** LNS-054, LNS-065, LNS-073.
4. **Page and Ask rows.** PAG-013, PAG-025, PAG-026, PAG-027, PAG-028, MAP-015, MAP-029, MAP-030, MAP-031, MAP-032, MAP-034, MAP-035.

### Where the page order and the physics order differ

- **The Schuller tab mixes all six stages.** Its page order is: first findings, chain, table, hyperbolicity, area metric, deformation, fibre, Fock, spin, total, bands, stops, perspective, quantum, notes, questions, honest, theorems, then the widget copies. Physics would put the table (LNS-011, LNS-109) first. Then would come spin and Fock (K), then hyperbolicity, Dirac and media (K/F), then bands and solutions (D), with closure and the stops last.
- **About two thirds of the 111 LNS rows restate or digest another row** in a second register (honest, learner, widget, theorem and perspective copies). Each copy should hang off one parent row, as the content model of V2 intends.
- **The Map tree puts the Furey/Standard Model node next to the shapes and Maxwell nodes.** In physics it is the last calibration layer. It needs fermions (MAP-017) and gauge fields (MAP-019, MAP-020) first, and Peirce blocks are only meaningful once those exist.
- **The For-researchers rows (THM, SRC) sit at the end but are the foundation.** THM-001 is Chevalley's theorem behind MAP-001 and LNS-001. THM-006 is the input behind every number-operator claim (LNS-005, LNS-062, LNS-130).
- **The Schuller page pairs rows that belong to different sections.** Pauli exclusion and Stern–Gerlach (LNS-055, LNS-074) are Fock kinematics (K) and measurement (O). Kaluza–Klein sits under "fibre" (algebra) but is a field-theory statement (F). The bands sit beside the deformation algebra as a "trio", but they are dynamics (D) while the deformation algebra is gravity kinematics (F).

---

## B. Chains, classes and loops

### Chains (ordered by `derives`)

1. **The gauge and gravity spine.** T1 -> MAP-001 -> MAP-016 -> MAP-019 -> MAP-020. MAP-016 -> MAP-021 -> LNS-032 (spin sources torsion). MAP-021 + MAP-023 -> LNS-034 -> LNS-049 (Λ and the square of the extra generator).
2. **The Maxwell–Dirac spine.** MAP-001 -> MAP-013 -> MAP-017 -> MAP-018 -> MAP-034 (the lattice plan). MAP-013 -> MAP-003 -> MAP-018.
3. **From the Dirac symbol to Kaluza–Klein.** T16 -> LNS-003 -> LNS-012 -> LNS-017. T16 + T18 -> LNS-120 -> LNS-121.
4. **Hyperbolicity.** T18 -> LNS-002 / LNS-012 -> LNS-045 (degenerate symbols, QT10).
5. **Constructive gravity.** LNS-002 + LNS-003 + LNS-014 + MAP-021 -> LNS-010 -> LNS-034 and LNS-106. MAP-001 -> LNS-014 -> LNS-029 and LNS-047.
6. **Media.** MAP-003 + MAP-016 + MAP-021 + T17 -> LNS-013 -> LNS-030, LNS-045, LNS-048.
7. **Bands.** T19 -> LNS-022 -> LNS-026 and LNS-043. T19 -> LNS-122, LNS-124, LNS-125, LNS-126.
8. **Springs and bodies.** T17 + T19 -> MAP-026 -> MAP-033 and MAP-034. MAP-023 -> MAP-024, MAP-027, MAP-033.
9. **Fock space and measurement.** T20 -> LNS-005 / LNS-019 -> LNS-055, and T15 -> LNS-021 -> LNS-055. T20 -> THM-006 -> (input to) LNS-062, LNS-066, LNS-130.
10. **Base and fibre.** LNS-015 -> LNS-016 -> LNS-036, which is equivalent to LNS-050.
11. **Furey.** INP-087..094 -> FUR-001 -> FUR-002 -> FUR-005, PAG-015, PAG-016, MAP-007, MAP-009. FUR-001 -> FUR-003 -> FUR-004 -> FUR-005.
12. **Sign cohomology.** T6 -> THM-003 -> SRC-001. T2 -> LNS-114. T8 -> THM-002, THM-004, THM-006, SRC-001, SRC-002, SRC-003.

### Classes (closed under `equiv`)

- **Deformed exterior algebra:** LNS-001, LNS-011, LNS-051, LNS-070, LNS-108, LNS-109, THM-001 (MAP-001 joins through LNS-011).
- **Frobenius form and Hodge star:** LNS-058, LNS-110 (with T3).
- **Brauer–Wall and the mirror:** LNS-006, LNS-015, LNS-113.
- **Double centraliser:** LNS-007, LNS-016, LNS-053, LNS-072, LNS-111, LNS-112.
- **Hyperbolicity selects Lorentzian signature:** LNS-002, LNS-012, LNS-052, LNS-060, LNS-064, LNS-071, LNS-102, LNS-105, LNS-116, LNS-118, plus the first line of LNS-028 (with T18 f).
- **Dirac symbol:** MAP-017, LNS-003, LNS-059, LNS-117, LNS-119 (with T16).
- **The F9 sign convention:** LNS-033, LNS-040, LNS-042 (with the second line of LNS-003 and the reading in MAP-001).
- **Kaluza–Klein:** LNS-017, LNS-120. LNS-121 hangs off them as a reading.
- **Fock space:** LNS-005, LNS-019, LNS-031, LNS-062, LNS-129, LNS-130, LNS-131, LNS-132, LNS-133, LNS-066 (with T20).
- **Bands:** LNS-008, LNS-022, LNS-035, LNS-061, LNS-124, LNS-125, LNS-126, LNS-127 (with T19).
- **The −1, 0, +1 trio as a reading:** LNS-056, LNS-067, LNS-075, LNS-123, LNS-128.
- **Stop at the action principle:** LNS-024, LNS-057, LNS-068, LNS-076, LNS-103, plus the back half of LNS-010.
- **Gluing and infinite dimensions:** LNS-023, LNS-025, LNS-050, LNS-069, plus the open half of LNS-036.
- **Λ:** LNS-034 and LNS-107 define the scale ℓ. LNS-049 and LNS-056 hold the reading, as does line 7 of LNS-010.
- **The signature-family question:** LNS-029, LNS-047, and line 5 of LNS-014.
- **Area-metric closure:** LNS-030, LNS-048. LNS-048 also shares question P6 with LNS-032.
- **Stern–Gerlach:** LNS-021, LNS-134, LNS-135. **Pauli exclusion with Stern–Gerlach:** LNS-055, LNS-074.
- **Assessments of the match:** LNS-063, LNS-101, LNS-104.
- **Names:** LNS-054, LNS-065, LNS-073, LNS-115.
- **Furey summaries:** FUR-002, PAG-014, MAP-007, MAP-008, MAP-009, MAP-010, PAG-015.
- **Duplicated inputs:** INP-087 = INP-089, INP-088 = INP-091, INP-093 = INP-094, INP-090 = FUR-003.
- **Map and page rows:** MAP-015 = MAP-029, MAP-030 = PAG-025, PAG-027 = MAP-032. Also MAP-003 = MAP-004, MAP-024 = MAP-027, and MAP-021 = MAP-023 (the extra-generator reading).

### Loops

- **The only explicit `cycle`: MAP-003 and MAP-005.** The overall sign of the source is fixed only together with the force law, through positive field energy.
- **Implicit loops that should be made explicit:**
  - **MAP-003, MAP-018, MAP-020.** A source must be conserved for ∇F = J to be consistent, and conservation follows from ∇F = J (C3 below). Today only the edge MAP-018 -> MAP-020 is recorded.
  - **MAP-001, LNS-042, LNS-033, LNS-040.** Which sign is time is a convention, fixed by asking for the physical mass shell.
  - **LNS-010, LNS-034, LNS-049.** The closure leaves Λ/κ free. The frames define ℓ. The sign link between Λ and s holds only once the square of space is fixed.
  - **FUR-003 and INP-090.** The partition is a datum because only 616 of 18480 commuting quadruples diagonalise its projectors, and that datum is what the computation uses.

### Hubs (in-degree over all 176 rows)

| Node | In-degree |
|---|---|
| T4 | 16 |
| T20 | 15 |
| MAP-001 | 13 |
| T18 | 12 |
| T19 | 12 |
| T16 | 11 |
| LNS-012 | 9 |
| LNS-003 | 9 |
| FUR-002 | 8 |
| MAP-016 | 8 |
| T1 | 7 |
| LNS-022 | 7 |
| LNS-015 | 7 |
| MAP-023 | 7 |

Among the chunk's own rows the hubs are MAP-001 (the rule and the signature convention), LNS-012 (hyperbolicity), LNS-003 (the Dirac symbol), FUR-002 (the Standard Model count) and MAP-016 (the Lorentz algebra).

### Leaves (nothing in the chunk rests on them; 43 rows)

PAG-013, PAG-014, PAG-016, PAG-026, PAG-028, MAP-007, MAP-008, MAP-010, MAP-011, MAP-014, MAP-022, MAP-025, MAP-028, MAP-030, MAP-033, MAP-034, MAP-035, LNS-026, LNS-037, LNS-038, LNS-039, LNS-040, LNS-041, LNS-043, LNS-044, LNS-046, LNS-070, LNS-075, LNS-102, LNS-106, LNS-108, LNS-114, LNS-119, LNS-122, LNS-127, LNS-129, THM-001, THM-002, THM-004, THM-005, SRC-001, SRC-002, SRC-003.

Most leaves are open questions, readings, node summaries or learner copies. Five are physics that nothing uses yet:

- **MAP-028:** κ_H is computed, but no row turns it into a temperature (C11).
- **LNS-106:** the null energy condition is checked, but no focusing follows (C10).
- **THM-005:** Galilean and Carroll boosts, with no non-relativistic limit built on them (C4, C7).
- **MAP-033:** Maxwell–Calladine counting, not linked to topological mechanics.
- **LNS-046:** Majorana matter (C13).

### Contradictions and status conflicts

- **LNS-037 contradicts T15 (`contradicts` edge).** LNS-037 says mixed states and the trace rule are "open" in other signatures, while T15, the theorem its own check cites, settles them for every Cl(p,q,r) (QE1 says so). The same stale wording is in LNS-025.
- **LNS-122 contradicts LNS-125 (`contradicts` edge).** The learner text says "at zero is the edge". M = ±I has X² = 0 and is not an edge.
- **Finding F6 and the figure list the stone grades in different orders** (E, S, E… against S, E, E…), as recorded in LNS-104. The figure is kept, so F6 is the entry to correct.
- **Conventions that collide:**
  - LNS-032 uses two pseudoscalar conventions (γ5 with an i, and the real I).
  - LNS-049's κ in "Λ ~ −s·κ²" is not the coupling κ of LNS-010 and LNS-032. LNS-034 shows that the sign link between Λ and s flips with the square of space.
  - MAP-001 says the cards and the Dirac and Maxwell steps use opposite signatures.
- **Statuses that look off:**
  - THM-002 marks as open whether ℂ and ℍ have a basis with non-negative structure constants. That has a two-line negative answer.
  - LNS-038's contextuality link is already proved by T11(4).
  - LNS-053 says "graded product of base and fibre", which holds for the undressed complement, not for the commutant it calls the fibre.
  - LNS-046 cites T16(3) where the type table (T4) is what is needed.
  - LNS-066 and LNS-133 badge as "ours" the textbook occupation-number basis.
  - LNS-121 badges as "ours" the textbook Kaluza–Klein mass.
  - THM-006 counts only m!·2^m Witt pairings. The full input is an O(m) family of Lagrangian splits (Bogoliubov transformations).

---

## C. Missing pieces

Ordered by consequence. "Check" says whether a script could compute it with the Atlas's engine.

1. **Lovelock's theorem.**
   - **Statement:** In four dimensions the only symmetric, divergence-free 2-tensor built from the metric and its first two derivatives is aG_ab + bg_ab. Equivalently, the only second-order metric Lagrangian is Einstein–Hilbert with a cosmological term.
   - **Source:** D. Lovelock, "The Einstein tensor and its generalizations" and "The four-dimensionality of space and the Einstein tensor" (J. Math. Phys.).
   - **Links:** LNS-010, MAP-021, LNS-024, LNS-057, LNS-034. It makes Schuller's "closure gives Einstein–Hilbert" and the Atlas's "tetrad gives the Einstein form" meet: one answer from either end, so the one-way chain becomes two-way.
   - **Check:** partly. The divergence-free property and candidate tensors can be evaluated on jets; uniqueness is a proof, not a computation.

2. **Birkhoff's theorem.**
   - **Statement:** Every spherically symmetric vacuum solution, with Λ, is locally Schwarzschild–(anti-)de Sitter, and static outside the horizon.
   - **Source:** G. D. Birkhoff, Relativity and Modern Physics; S. W. Hawking and G. F. R. Ellis, The Large Scale Structure of Space-Time.
   - **Links:** MAP-021 to MAP-028, LNS-034, LNS-107. It closes the gap between the field equation and its solutions: the Atlas checks the solutions it is given, and Birkhoff says they are the only ones.
   - **Check:** partly. The Einstein form on a general spherically symmetric ansatz reduces to ODEs in one chart; the chart is an input.

3. **Charge conservation as the integrability condition of ∇F = J.**
   - **Statement:** ∇F = J implies ∇·J = 0 (dJ = dd⋆F = 0). Conversely, a source must be conserved for the field equation to be consistent, which is why minimal coupling uses the conserved current.
   - **Source:** J. D. Jackson, Classical Electrodynamics; D. Hestenes, Space-Time Algebra.
   - **Links:** MAP-003, MAP-018, MAP-020, MAP-019 (covariant version). It makes MAP-018 -> MAP-020 two-way.
   - **Check:** yes. Apply ∇ twice to a general F symbolically.

4. **The electron's magnetic moment, g = 2 (Pauli limit of Dirac).**
   - **Statement:** The non-relativistic limit of the minimally coupled Dirac equation is the Pauli equation, with μ = g(e/2m)S and g = 2.
   - **Source:** J. J. Sakurai, Advanced Quantum Mechanics; C. Doran and A. Lasenby, Geometric Algebra for Physicists.
   - **Links:** MAP-017 and MAP-018 to LNS-004 and LNS-020 (spin ½), and to LNS-021, LNS-134 and LNS-135 (Stern–Gerlach, which needs a magnetic moment no row derives). The phenomenon is approached but not derived.
   - **Check:** yes. Expand the Hestenes equation with coupling to order 1/c on the even part of Cl(1,3).

5. **Radiation from an accelerated charge.**
   - **Statement:** An accelerated charge radiates the Larmor power P = (2/3)q²a²/(4πε₀c³), from the Liénard–Wiechert field. Its recoil is the Abraham–Lorentz–Dirac force.
   - **Source:** Jackson; F. Rohrlich, Classical Charged Particles; P. A. M. Dirac, "Classical theory of radiating electrons".
   - **Links:** MAP-005, which lists "its own field and radiation" as open, and MAP-003. The phenomenon is electromagnetic radiation and radiation reaction.
   - **Check:** partly. The retarded field of a given worldline (the hyperbolic motion of MAP-005) and its flux are computable; ALD needs a regularisation, which is an input.

6. **Gauge anomaly cancellation.**
   - **Statement:** A chiral gauge theory is consistent only if its anomaly coefficients vanish. For one Standard Model generation, ΣY = ΣY³ = 0 and the mixed SU(3)²U(1) and SU(2)²U(1) sums vanish.
   - **Source:** A. Bilal, "Lectures on Anomalies" (arXiv:0802.0634); S. Weinberg, The Quantum Theory of Fields II.
   - **Links:** FUR-002, FUR-005, PAG-015, PAG-016, MAP-009, INP-092, INP-093. It tests whether the 8ℂ beyond one generation is anomaly-free.
   - **Check:** yes. These are exact rational sums over the edge irreps, once chirality labels are given (an input from Fig. 1).

7. **The signature sign in the hypersurface deformation algebra.**
   - **Statement:** The bracket of two Hamiltonian constraints is ε times the momentum constraint, in every dimension. ε is −1 or +1 for Lorentzian or Euclidean signature (conventions vary), and ε = 0 is the zero-signature (Carroll) limit. Hojman, Kuchař and Teitelboim derive GR from representations of this algebra.
   - **Source:** S. Hojman, K. Kuchař, C. Teitelboim, "Geometrodynamics regained" (Ann. Phys.); C. Teitelboim, "How commutators of constraints reflect the spacetime structure" (Ann. Phys.); M. Henneaux, "Geometry of zero signature space-times".
   - **Links:** LNS-014, LNS-029, LNS-047 (question P3), LNS-010, THM-005. P3 has a literature answer to compare with.
   - **Check:** partly. The brackets with ε can be evaluated on jets for d = 2, 3, as in the 1+1 model.

8. **MacDowell–Mansouri / Cartan gravity: the sign of Λ comes from the model space.**
   - **Statement:** Gravity as an so(1,4) or so(2,3) Cartan connection gives Einstein–Hilbert with Λ = ±3/ℓ². The sign is fixed by the de Sitter or anti-de Sitter model, and ℓ is its radius.
   - **Source:** S. W. MacDowell and F. Mansouri, "Unified geometric theory of gravity and supergravity" (Phys. Rev. Lett.); D. K. Wise, "MacDowell–Mansouri gravity and Cartan geometry" (Class. Quantum Grav.).
   - **Links:** MAP-021, MAP-023, LNS-034, LNS-107, LNS-049, LNS-056. The sign half of the "ours" reading becomes standard in a fixed convention; only a magnitude tie to κ would be new.
   - **Check:** yes. The extended curvature on the (anti-)de Sitter frames already exists (h5l_frames.py).

9. **Gårding: hyperbolicity is well-posedness.**
   - **Statement:** A constant-coefficient operator has a well-posed Cauchy problem in direction h if and only if its principal polynomial is hyperbolic in h, with lower-order (Levi) conditions in the weakly hyperbolic case.
   - **Source:** L. Gårding, "Linear hyperbolic partial differential equations with constant coefficients" (Acta Math.); L. Hörmander, The Analysis of Linear Partial Differential Operators II.
   - **Links:** LNS-002, LNS-012, LNS-052, LNS-060, LNS-116, LNS-045. It explains why the filter matters physically (predictive evolution), and what r ≥ 1 costs.
   - **Check:** partly. Plane-wave growth rates per cell are computable; the theorem is analytic.

10. **The Raychaudhuri equation and focusing.**
    - **Statement:** For a null congruence, dθ/dλ = −θ²/2 − σ² + ω² − R_ab k^a k^b. With the null energy condition, converging generators focus.
    - **Source:** A. K. Raychaudhuri (Phys. Rev., 1955); R. M. Wald, General Relativity.
    - **Links:** LNS-106 (null energy checked on Reissner–Nordström), MAP-028, LNS-034. It turns a checked inequality into its consequence (the area theorem, the singularity theorems).
    - **Check:** partly. Expansion and shear of radial null congruences on the engine's frames are computable; the global theorems are not.

11. **Horizon temperature and the first law.**
    - **Statement:** A Killing horizon of surface gravity κ has temperature T = κ/2π. With entropy A/4, dM = TdS + ΩdJ + ΦdQ. The Kottler metric has two horizons with different temperatures.
    - **Source:** S. W. Hawking, "Particle creation by black holes"; J. M. Bardeen, B. Carter, S. W. Hawking, "The four laws of black hole mechanics"; G. W. Gibbons and S. W. Hawking, "Cosmological event horizons, thermodynamics, and particle creation".
    - **Links:** MAP-028 (κ_H on five horizons), LNS-034, LNS-107. The phenomenon is approached but not derived: Hawking radiation and horizon thermodynamics.
    - **Check:** partly. κ and the Euclidean periodicity (no conical singularity) are algebra; the emission itself is not.

12. **Spin–statistics.**
    - **Statement:** In a Lorentz-covariant local QFT with positive energy, integer-spin fields obey the CCR and half-integer-spin fields the CAR.
    - **Source:** W. Pauli, "The connection between spin and statistics" (Phys. Rev.); R. F. Streater and A. S. Wightman, PCT, Spin and Statistics, and All That.
    - **Links:** LNS-004 and LNS-020 (spin ½) with LNS-005, LNS-019, LNS-055 and LNS-039 (CAR, exclusion). The rows state both halves and never connect them.
    - **Check:** no. It needs locality and infinite dimensions (the stop in LNS-025).

13. **Majorana spinors and charge conjugation.**
    - **Statement:** Real 4-component spinors exist when the algebra of the chosen signature is a real matrix algebra, Cl(3,1) = M₄(ℝ). In Cl(1,3) = M₂(ℍ) a Majorana condition needs complexification and a charge conjugation.
    - **Source:** H. B. Lawson and M.-L. Michelsohn, Spin Geometry; P. Lounesto, Clifford Algebras and Spinors.
    - **Links:** LNS-046, LNS-118, LNS-042, MAP-017, MAP-025.
    - **Check:** yes. The type table plus an explicit real 4×4 representation and the real Dirac operator.

14. **Lieb's flux-phase theorem.**
    - **Statement:** For half-filled hopping on planar bipartite lattices, the ground-state energy is minimised by flux π through every square plaquette.
    - **Source:** E. H. Lieb, "Flux phase of the half-filled band" (Phys. Rev. Lett.).
    - **Links:** THM-003 (the bit-rule sign is a Jordan–Wigner string with flux −1 per square), MAP-026 (signed network, π per face, Kogut–Susskind phases), T19(4). It gives the sign an energetic role, not only a gauge role.
    - **Check:** yes. Finite spectra on the cube with flux 0 against π.

15. **Wilson's lattice gauge theory.**
    - **Statement:** Gauge fields live on links and the action is Σ over plaquettes of (1 − Re tr U_plaquette), with Yang–Mills as its continuum limit. Staggered (Kogut–Susskind) fermions live on the sites.
    - **Source:** K. G. Wilson, "Confinement of quarks" (Phys. Rev. D); J. Kogut and L. Susskind, "Hamiltonian formulation of Wilson's lattice gauge theories" (Phys. Rev. D).
    - **Links:** MAP-034 (the plan), MAP-026, MAP-019, MAP-018, THM-003.
    - **Check:** yes. Finite algebra on the n-cube.

16. **Energy–momentum conservation and Belinfante–Rosenfeld.**
    - **Statement:** Diffeomorphism and local Lorentz invariance give the Noether identities ∇_a T^ab = (spin–torsion terms) and T^[ab] = div(spin). The Belinfante–Rosenfeld tensor is symmetric and equals the metric stress.
    - **Source:** F. J. Belinfante (Physica, 1940); L. Rosenfeld (1940); F. W. Hehl, P. von der Heyde, G. D. Kerlick, J. M. Nester, "General relativity with spin and torsion" (Rev. Mod. Phys.).
    - **Links:** LNS-032, MAP-020, MAP-021, and item 3.
    - **Check:** yes. The stress and spin forms are already computed (e2s4_dirac_stress.py).

17. **Chern–Weil theory, the local half of gluing.**
    - **Statement:** Characteristic classes are represented by closed invariant polynomials in the curvature. The densities are local; their integrals are topological.
    - **Source:** T. Eguchi, P. B. Gilkey, A. J. Hanson, "Gravitation, gauge theories and differential geometry" (Phys. Rep.); M. Nakahara, Geometry, Topology and Physics.
    - **Links:** LNS-023, LNS-050, LNS-036, MAP-021, MAP-019, and LNS-013, whose axion term F∧F stays out of the wave operator because it is a total derivative.
    - **Check:** partly. The densities and their closedness are computable; the integrals need the global manifold.

18. **The Higgs mechanism.**
    - **Statement:** A doublet (1,2,+½) with a vacuum value breaks SU(2)×U(1)_Y to U(1)_em, with Q = T₃ + Y/2. W, Z and fermion masses follow from Yukawa couplings.
    - **Source:** S. Weinberg, "A model of leptons" (Phys. Rev. Lett.); M. E. Peskin and D. V. Schroeder, An Introduction to Quantum Field Theory.
    - **Links:** PAG-016 ("which edge is lepton and which Higgs"), FUR-002 (the doublet appears three times), INP-092, MAP-010.
    - **Check:** partly. The charges and the unbroken generator are algebra; the potential is an input.

19. **Chirality from the volume element.**
    - **Statement:** Chirality is the eigenvalue of the pseudoscalar γ5. Standard Model fermions are left-handed doublets and right-handed singlets, so a model must tie chirality to the pseudoscalar rather than to labels.
    - **Source:** Peskin and Schroeder; Lounesto.
    - **Links:** PAG-016, FUR-002 (chirality "from her labels"), MAP-025 (the XOR 9 reading), LNS-032.
    - **Check:** yes. The base pseudoscalar acting on the edge spaces, once the base is fixed.

20. **The Peres–Mermin square proves contextuality.**
    - **Statement:** The 3×3 square of two-qubit Pauli observables gives a state-independent Kochen–Specker proof.
    - **Source:** N. D. Mermin, "Simple unified form for the major no-hidden-variables theorems" (Phys. Rev. Lett.); A. Peres, "Incompatible results of quantum measurements" (Phys. Lett. A).
    - **Links:** LNS-038, T11(4), LNS-132.
    - **Check:** yes. T11(4) already proves it; only LNS-038's wording needs to change.

21. **Exact bosonization (higher-dimensional Jordan–Wigner).**
    - **Statement:** Lattice fermions in d ≥ 2 map to a ℤ₂ gauge theory whose flux and constraints carry the fermion signs.
    - **Source:** Y.-A. Chen, A. Kapustin, Đ. Radičević, "Exact bosonization in two spatial dimensions and a new class of lattice gauge theories" (Ann. Phys.).
    - **Links:** THM-003, LNS-019, LNS-132, MAP-026.
    - **Check:** partly. The constraints on the cube's 2-skeleton are finite.

22. **The Kaluza–Klein tower and charge quantisation.**
    - **Statement:** On a circle of radius R, p₅ = n/R, which gives masses |n|/R and charges proportional to n.
    - **Source:** O. Klein, "Quantentheorie und fünfdimensionale Relativitätstheorie" (Z. Phys.); J. M. Overduin and P. S. Wesson, "Kaluza–Klein gravity" (Phys. Rep.).
    - **Links:** LNS-017, LNS-120, LNS-121.
    - **Check:** partly. The shell of each mode is exact; the period is an input.

23. **Bogoliubov transformations and the choice of vacuum.**
    - **Statement:** Different Lagrangian splits (complex structures) of the Majorana modes give different vacua and number operators, related by Bogoliubov transformations. Fermion parity is invariant.
    - **Source:** F. A. Berezin, The Method of Second Quantization.
    - **Links:** THM-006, LNS-062, LNS-066, LNS-130, LNS-133.
    - **Check:** yes. Sample the O(m) family of splits for small m and compare the number operators.

24. **Fermionic composite systems.**
    - **Statement:** For fermions the tensor product is graded and physical states commute with parity, which changes what entanglement means compared with qubits.
    - **Source:** M. C. Bañuls, J. I. Cirac, M. M. Wolf, "Entanglement in fermionic systems" (Phys. Rev. A).
    - **Links:** LNS-037, LNS-025, LNS-019 (product states as det = 0), QT4.
    - **Check:** partly. The states on a graded product of two cells are finite-dimensional; the right positivity notion is the question.
