# Chunk B (the equations page: steps 2–16 and the tally): the mathematician's labelling

172 rows labelled in `math_B.jsonl` (validator: 0 problems). Kinds: 56 definition, 29 computation, 16 lemma, 16 meta, 11 reading, 10 reduction, 9 range, 7 theorem, 5 example, 4 question, 4 pointer, 2 counterexample, 1 dead-end, 1 classification, 1 invariant. Relations drawn: 127 `derives`, 107 `equiv`, 73 `uses-input`, 5 `instance`, 4 `cycle`, 3 `contradicts`.

The chunk has four layers. The **step rows** (EQN-001…004, CPL, YM, MAT, GRV, MIR, PRJ, NUL, FRQ, SPN, SPR, RIG, LAB) carry the statements. The **tally rows** (EQN-006…020) restate each step in one line; I recorded them as `equiv` to the step rows, and their five flags are the union over the step, not the status of the line. The **page strips** (PAG-021…024) are digests. The **input rows** (INP-018…078, 61 rows, 35 % of the chunk) are the conventions, actions and data; most are `definition`. Several step rows are compounds of four to six statements of different kinds (LAB-005, GRV-004, GRV-011, NUL-001, NUL-004, EQN-019); the `note` field says so row by row.

---

## A. How mathematics would organise these rows

The page follows the physicist's pipeline (Maxwell → Dirac → coupling → Yang–Mills → matter → gravity → extra generator → horizons → mechanics). A mathematician would order by the object: first the conventions, then the Lie algebra of bivectors and the reflection group, then the degenerate algebras, then modules, then connections and curvature (one theorem for gauge fields and gravity), then variational identities, then Lorentzian geometry and exact solutions, then mechanics on Lie groups and spectral graph theory. Topology and category theory are nearly absent from this chunk (A.4).

### A.0 Conventions and inputs (definitions that hide a choice)

- **Signature and mirror conventions**: INP-025, INP-047, INP-051, INP-057, INP-063, INP-018. Mathematically one fact: the mirror Cl(p,q,r) ↔ Cl(q,p,r) fixes r and the even subalgebra; Cl(1,3) ≇ Cl(3,1), but every system on this page lives in an even part or a Lie algebra, where the two agree.
- **Time orientation**: INP-020, INP-023, INP-030, INP-043, INP-059, INP-070 (the two sheets of the timelike hyperboloid; the positive involution γ₀x̃γ₀ is a genuine datum).
- **Complex structure J**: INP-024, INP-031, INP-042, INP-067, INP-068 (one Spin⁺-orbit for n ≥ 4, a datum at n = 3; true for every n ≥ 4, not only up to 6).
- **Reversion against Clifford conjugation**: INP-019, INP-065, INP-073, INP-078. These are no choice where they are used: on even elements (ψ, motors, rotors) the two anti-involutions coincide (missing piece C.2).
- **Grade assignments**: INP-022, INP-029, INP-038, INP-046. INP-029 contradicts CPL-002 for the current X (B.4).
- **Charts, frames, derivatives**: INP-026, INP-032, INP-036, INP-041, INP-045, INP-055, INP-064, INP-069, INP-074, INP-077.
- **Actions and postulated laws**: INP-021, INP-027, INP-033, INP-037, INP-044, INP-048, INP-053, INP-061, INP-071, INP-075.
- **Constants**: INP-028, INP-035, INP-040, INP-050, INP-072.
- **Gauge algebra and representation**: INP-034, INP-039.
- **Borrowed metrics**: INP-054, INP-056, INP-058 (two of them are partly derived: GRV-012).
- **Outside tables and papers**: INP-052, INP-060, INP-062, INP-066, INP-076.
- **An invariant, not a convention**: INP-049 (the sign of the model-space curvature; k = −s is the convention-bound part).

Several input rows carry checked identities (INP-044: seven; INP-045, INP-048, INP-058). Mathematics would keep the input (the action, the frame) and move the identities to the rows they prove.

### A.1 Algebra

**A.1.1 The Lie algebra of bivectors.** Structure constants [B_ab, B_bc] = 2ε_b B_ac from T1 (EQN-007) → the identification Λ²V ≅ so(V,Q) (EQN-003) → the support graph is the triangular graph T(n) = L(K_n) (EQN-001, EQN-006; instance n = 4 as the octahedral equator of the 16-cell, EQN-002) → its triangles are of two kinds (YM-001) and it is the weight-2 layer of the halved cube (YM-003) → degree counts (YM-002) → a rotation is two reflections (MIR-002) → subalgebras u(n), g₂ ⊃ su(3), so(6) ≅ su(4), so(10) (YM-006) → the spinor representation on Cl(0,m) (MAT-001). Each graph statement is true for every n with non-null squares; the ranges add no generality.

**A.1.2 Reflections.** Cartan–Dieudonné and the sign subgroup ℤ₂ⁿ ⊂ Bₙ (EQN-014, MIR-001), E₈ = D₈⁺ closed under its reflections (MIR-003), reflections only in anisotropic vectors (MIR-006, NUL-009), Euclidean and conformal isometries as products of reflections (PRJ-003), time reversal as a reflection (MIR-005). Mathematics puts this section before A.1.1 (quadratic space → reflections → Pin, Spin → Lie algebra); the page has bivectors (step 2) before mirrors (step 3).

**A.1.3 One extra generator: contractions.** The algebra Cl(p,q,1) and the hyperbolic plane (PRJ-001, a theorem by T1–T2) → the contraction family so(1,4) → iso(1,3) ← so(2,3) and the conformal so(2,4) with its 3-grading (EQN-015, PRJ-002) → Cayley–Klein geometries (PRJ-004) → the celestial sphere as projectivised null cone (NUL-008) → Galilei and Carroll as the two degenerate limits (NUL-012, RIG-007, EQN-021). Mathematically one section, "Inönü–Wigner contractions"; the page spreads it over steps 11, 13 and 16.

**A.1.4 The radical and degenerate algebras.** An isotropic vector spans the radical of its orthogonal complement (LAB-007), the horizon algebra Cl(0,n−2,1) with radical J and quotient Cl(0,n−2) (NUL-004, a theorem by T2 + T18), three embeddings of ℍ (NUL-011), the complement as a Frobenius pairing (FRQ-002, T3), PGA as Cl(d,0,1) (FRQ-003).

**A.1.5 Clifford modules, spinors, states.** Grades of the current (CPL-002, one line for every n), grade orthogonality ⟨AX⟩₀ = A·⟨X⟩₁ (CPL-009), the even algebra against one Dirac spinor, ratio 2^(⌈n/2⌉−2) (CPL-003), no complex structure on Cl⁺(1,1) (CPL-006), the extra components (CPL-007, question), the spinor paper (EQN-017), states and the Born rule (SPN-004, from T15), the central pseudoscalar exists only for odd n (SPN-005).

### A.2 Geometry

**A.2.1 Connections and curvature.** Bianchi identities and covariance for every n (GRV-002), of which the Yang–Mills case (YM-004, EQN-010) is the instance with gauge algebra so(m) and no solder form; the first Bianchi identity and the dimension n²(n²−1)/12 (GRV-001, EQN-012); the fundamental lemma, ω as a function of e by the Koszul formula (GRV-006, a theorem by the locality argument); E_a depends on R and e only (GRV-009); curvature on spinors and Lichnerowicz (GRV-003). The page states the Bianchi identity twice (step 7 and step 9); mathematics states it once for a Cartan connection (C.1).

**A.2.2 Variational identities and field equations.** First variation of Einstein–Cartan and MacDowell–Mansouri (GRV-005), the contracted Bianchi identity as Noether's second theorem (GRV-008, EQN-013), the tetrad Einstein tensor E_a = −(G − Λg)·⋆e_a (GRV-010, a range n = 3–5), the Dirac line, coupling and matter equations (EQN-008, EQN-009, EQN-011, CPL-001, CPL-004, CPL-005), covariant conservation of currents (MAT-002, MAT-003, MAT-004), the matter action and representation (MAT-005, MAT-006), sources of gravity (GRV-011).

**A.2.3 Cartan geometry and the sign of Λ.** GRV-007, GRV-004, PRJ-006 (with INP-049). Mathematically: (A)dS Cartan geometries; Cartan flatness; the normal conformal Cartan connection.

**A.2.4 Exact solutions and Killing horizons.** Classification in the radial Kerr–Schild ansatz (GRV-012) → Schwarzschild, perihelion (LAB-005) → tidal tensor and Petrov D (LAB-006); Reissner–Nordström (MAT-007 = YM-007 = CPL-008); surface gravity and horizons (NUL-001), g^rr = 0 is not a null test (NUL-002), the Killing identity κ² = −½∇ξ·∇ξ (NUL-003), characteristics and focusing (NUL-010), first law and Smarr (LAB-008, EQN-020).

### A.3 Analysis: mechanics and spectra

**A.3.1 Mechanics on Lie groups.** Euler–Poincaré equations on the motor group (EQN-016), Euler–Arnold tops on so(4), se(3), so(3,1) (PRJ-005, with a conjecture inside), the rigid body and its gravity couplings (EQN-019, RIG-002), rigidity counts (RIG-006), comparison with an ephemeris (RIG-005). This block depends only on A.1.3 and A.1.1, not on gravity; the page puts it last.

**A.3.2 Spectral graph theory on the cube.** Hypercube Laplacian and Huang's signed matrix (EQN-018, SPR-002, from T19), the Majorana and staggered-fermion form of the signed network (SPR-004, from T20).

### A.4 Topology and category

No row of the chunk is about topology or category as its main content. They appear only as a flavour: Chern–Simons transgression (INP-044, INP-048, GRV-010), the Frobenius form (FRQ-002), Pin± (INP-018), the flux π as a gauge class (SPR-003, via T6). C.4, C.11, C.12 and C.16 are the links that would make this section exist.

### A.5 Readings

PAG-023, CPL-010, MAT-008, YM-008, SPR-003, RIG-003, SPN-003 (and the reading lines inside MIR-001, MIR-005, NUL-012, FRQ-003, GRV-001, GRV-010, PRJ-001). Three of them are standard mathematics filed as "ours": the n + 1 sandwiches are the outermorphism property (PAG-023), "labels as normal modes" is the character basis of ℤ₂ⁿ (SPR-003), "a walk of single-bit changes" is a Gray code (RIG-003). Two are checked elsewhere as facts: the cube edges of CPL-010 are CPL-001, the demicube edges of MAT-008 and YM-008 are MAT-001 and YM-001/YM-003.

### A.6 Open rows and meta

PAG-021, PAG-022, PAG-024, EQN-004, YM-005, MIR-004, NUL-005, NUL-006, NUL-007, FRQ-001, FRQ-004, FRQ-005, SPN-001, SPN-002, SPR-001, RIG-001, RIG-004.

---

## B. Chains, classes and loops

### B.1 Chains (ordered by `derives`; left = the row that is rested on)

1. **Lie chain.** T1 → EQN-007 → EQN-001 → EQN-002; EQN-007 → YM-001 → YM-002; YM-001 → YM-003 → YM-008 → PAG-023; EQN-007 → MAT-001 → MAT-008; EQN-007 → EQN-010 → EQN-011; EQN-007 → MIR-002; EQN-007 → EQN-015 → NUL-008; EQN-015 → GRV-004; EQN-003 → YM-006.
2. **Bianchi chain.** T1 → GRV-002 → GRV-005 → GRV-008 → GRV-009; GRV-002 → GRV-003; GRV-001 (an instance of GRV-002) → GRV-003; T1 → EQN-012 → EQN-013.
3. **Einstein-form chain.** GRV-006 → GRV-010 → GRV-012 → LAB-005 → LAB-006; LAB-005 → LAB-007; LAB-005 → INP-075; GRV-010 → GRV-011 → GRV-003; GRV-011 → CPL-008; GRV-011 → EQN-019; GRV-010 → GRV-007; GRV-010 → GRV-004; GRV-010 → NUL-010; GRV-006 → NUL-001 → NUL-003.
4. **Horizon chain.** T18 → NUL-001; T18 → NUL-002 and T18 → LAB-005 (instances); T2 + T18 → NUL-004; T2 + T18 → LAB-007; T16 + T18 → NUL-010; T2 → EQN-020.
5. **Dirac and coupling chain.** T16 → EQN-008 → EQN-009 (with EQN-006 → EQN-009); EQN-008 → EQN-011; CPL-002 → CPL-009; {CPL-002, CPL-003} → CPL-007 (half answered by CPL-009); T4 → CPL-003 → CPL-004; MAT-003 → MAT-002; MAT-003 → MAT-004.
6. **Radical chain.** T1 + T2 → PRJ-001 → FRQ-003.
7. **Cube-spectrum chain.** T19 + T17 → EQN-018; T19 + T17 → SPR-002; T19 + T6 → SPR-003; T20 + T19 + T6 → SPR-004; T19 → INP-072.
8. **Reading chains.** CPL-001 → CPL-010 → PAG-023; RIG-001 → RIG-003 → PAG-023.

The longest chains have five or six rows: T1 → EQN-007 → YM-001 → YM-003 → YM-008 → PAG-023 (ending in readings), T1 → GRV-002 → GRV-005 → GRV-008 → GRV-009, and GRV-006 → GRV-010 → GRV-012 → LAB-005 → LAB-006.

### B.2 Classes (`equiv`: one statement in two places or two lengths)

- **Tally line = step rows**: {EQN-007, EQN-003}; {EQN-001, EQN-006}; {EQN-009, CPL-004}; {EQN-010, YM-004}; {EQN-011, MAT-003, MAT-004}; {EQN-012, GRV-001, GRV-002}; {EQN-013, GRV-008, GRV-010}; {EQN-014, MIR-001}; {EQN-015, PRJ-002, PRJ-006}; {EQN-016, FRQ-001, INP-061}; {EQN-017, SPN-001}; {EQN-018, SPR-001}; {EQN-019, RIG-001, RIG-002, RIG-005, LAB-006, INP-076}; {EQN-020, NUL-001, NUL-004, LAB-007, LAB-008}.
- **Reissner–Nordström, one check in four rows**: {MAT-007, CPL-008, YM-007, INP-050}; Lichnerowicz {GRV-003, CPL-008}.
- **Checks restated in input rows**: {GRV-002, GRV-005, INP-044}; {GRV-005, GRV-010, INP-048}; {GRV-012, INP-054, INP-056}.
- **Sign of Λ**: {GRV-007, PRJ-002, EQN-015, PRJ-006, GRV-004}, closed by the loop through INP-049 (B.3).
- **Mirrors and null vectors**: {MIR-006, NUL-009, PRJ-003}; {YM-003, EQN-002}.
- **Galilei and Carroll**: {NUL-012, RIG-007, EQN-021}.
- **Mechanics**: {PRJ-005, FRQ-005}; {PRJ-004, INP-052}.
- **Pointers and open items stated twice**: {YM-005, INP-035, EQN-004}; {MAT-005, INP-040}; {MAT-006, INP-039}; {YM-006, INP-034}; {NUL-005, INP-060}; {SPN-002, INP-066}; {PAG-023, RIG-004}.
- **Conventions repeated per step**: J {INP-024, INP-031, INP-042, INP-067}; time orientation {INP-020, INP-023, INP-030, INP-043, INP-070}; signature {INP-025, INP-047, INP-051, INP-057}; anti-involution {INP-019, INP-030, INP-065, INP-073, INP-078}; frames {INP-045, INP-055}; the time parameter {INP-064, INP-074, INP-077}; the gauge derivative {INP-036, INP-041}.

About 60 of the 172 rows restate another row. The 61 input rows hold about 30 distinct inputs; a V2 that stores one input per class and lets each step cite it would cut the input list in half, and the four anti-involution rows disappear altogether (C.2).

### B.3 Loops (`cycle`)

1. **The sign of the cosmological term**: INP-049 ↔ GRV-007 ↔ PRJ-002. The convention k = −s (c = Λ/3 with space squaring −1) is fixed by the very checks that use it. Only r = sign H², the sign of the model-space curvature, is convention-free; the page should state that invariant and present k = −s as the convention it is.
2. **The gravitational constant**: INP-050 ↔ GRV-011 ↔ INP-075. κ = 8πG is calibrated against Newton's law (shell theorem); the Einstein form with this κ then gives Newtonian free fall, which step 16 takes as an input. The 1/r² shape (and the 6πM/p advance) is derived; the constant is not. "Newton's law is reached from the Einstein form" removes the shape from the inputs, not G.

Rejected candidates: the sign of the F² term fixed by positive energy (CPL-005) lives inside one row; the reversion against Clifford conjugation rows are not a loop but a non-choice (C.2).

### B.4 Hubs, leaves and contradictions

**Hubs inside the chunk** (rows rested on through `derives`, `instance` or `uses-input`): **EQN-007** (8; the bivector structure constants), **GRV-006** (7; ω as a function of e), **GRV-010** (7; the tetrad Einstein identity), **INP-022** (6; ψ is even), **GRV-002** (5; the Bianchi identities) and INP-021 (5; the Dirac action); then GRV-011 (4) and EQN-008, EQN-015, LAB-005 (3 each). Counting every relation, GRV-010 leads (10), then EQN-007 (9), GRV-002 and GRV-006 (7). **Hubs outside**: T18 (8), T19 (6), T1 and T2 (5), T17 (4), T4 (3), T6, T15 and T16 (2), T3, T5, T10, T20 (1).

**Sources** (no dependency): the inputs INP-018, 020, 022, 024, 028, 033, 046, 053, 059, 062, 064, 071; the self-contained count RIG-006; the meta rows PAG-022, MIR-004, NUL-006, NUL-007, FRQ-004.

**Leaves** (nothing rests on them), 51 rows: the digests PAG-021, 022, 024; the open and meta rows EQN-004, MIR-004, NUL-005, 006, 007, FRQ-004, SPN-004, SPN-005, CPL-007; the readings MAT-008, SPN-003, SPR-003; the end results LAB-008, CPL-004, CPL-005, CPL-006, CPL-009, GRV-004, GRV-009, MAT-002, MAT-004, MIR-002, MIR-003, MIR-005, PRJ-003, YM-002, NUL-008, NUL-010, NUL-011, FRQ-002, FRQ-003, SPR-002, SPR-004, RIG-006; and the inputs INP-018, 030, 038, 042, 043, 053, 057, 063, 068, 069, 073, 074, 077, 078.

**Contradictions recorded** (`contradicts`): INP-029 against CPL-002 (the current X is called an assigned vector, but in Cl(1,3) it is a vector by the grade argument, and for n ≥ 5 CPL-009 shows the action selects ⟨X⟩₁); INP-060 against NUL-002 and NUL-003 (the paper's criteria are "taken as given", while those rows refute g^rr = 0 and qualify g_tt = 0).

**Tensions noted without `contradicts`**: PAG-021 records thirteen step scripts as "ran, all pass", while twelve of them (all but equations_selfcheck.py) are recorded as "read" in their own step rows; SPN-004 calls the probability reading open outside Cl(3,0) although T15 gives the state space of every Cl(p,q,r); PRJ-006 says "its only physical reading" and then gives a second (Kaluza–Klein); the cube and demicube pictures are "checked" in CPL-001, MAT-001, YM-001/003 and "ours" in CPL-010, MAT-008, YM-008; GRV-010 is labelled "theorem" but is a range n = 3–5; PRJ-001 is a theorem by T1–T2 but flagged only "standard"; INP-019, INP-065, INP-073, INP-078 call reversion against Clifford conjugation a choice where the arguments are even.

---

## C. Missing pieces

Standard mathematics the chunk uses without stating, or that would turn a range into a theorem, or that links rows the Atlas keeps apart. Most consequential first. "Check" says whether the Atlas's engine could compute it.

1. **Cartan connections: one Bianchi identity for gauge fields and gravity.**
   Statement: a Cartan connection A valued in g = h ⊕ g/h has curvature F = dA + ½[A, A], with D_A F = 0 (from the Jacobi identity) and F ↦ Ad(g⁻¹)F under gauge transformations. With h = so(1,n−1) and g = so(1,n−1) ⋉ ℝⁿ, so(1,n) or so(2,n−1), the h-part of F is R + c e∧e and the g/h-part is the torsion; with g = so(m) and no g/h part it is Yang–Mills.
   Source: R. W. Sharpe, *Differential Geometry: Cartan's Generalization of Klein's Erlangen Program*; D. K. Wise, *MacDowell–Mansouri gravity and Cartan geometry* (Class. Quantum Grav. 27, 2010).
   Links: GRV-002, YM-004, EQN-010, EQN-012, GRV-001, GRV-004 (D_A F = 0 on so(2,4)), GRV-007, PRJ-006, INP-044. Field: geometry. Check: yes — one script with g as a parameter replaces the separate Bianchi checks of steps 7, 9 and 11, and the plain-text lemma chains become a two-line proof for every n.

2. **Reversion and Clifford conjugation coincide on the even subalgebra.**
   Statement: Clifford conjugation is x̄ = α(x̃), α the grade involution, so x̄ = x̃ for every even x. Hence MM̃ = MM̄ for motors and rotors, and ψγ₀ψ̃, ψψ̃ for even ψ are the same with either. The two anti-involutions can be conjugate under an automorphism only if their fixed spaces have equal dimension, Σ_{k≡1 (4)} C(n,k) = Σ_{k≡3 (4)} C(n,k), that is Im (1+i)ⁿ = 0, that is 4 | n.
   Source: P. Lounesto, *Clifford Algebras and Spinors* (the chapter on involutions); I. R. Porteous, *Clifford Algebras and the Classical Groups*.
   Links: INP-019, INP-030, INP-065, INP-073, INP-078. The positive involution γ₀x̃γ₀ (INP-023, INP-070, T15) stays a genuine datum. Field: algebra. Check: yes — one line on the engine; the necessity of 4 | n for every n is the Gauss-sum count of T4 (iii). Four "choices" leave the input list.

3. **Noether's second theorem.**
   Statement: if an action is invariant under transformations that depend on arbitrary functions (diffeomorphisms, local Lorentz or gauge transformations), its Euler–Lagrange expressions satisfy one differential identity per arbitrary function. For Einstein–Cartan these are D E_a = (i_a T^b)∧E_b + (i_a R^{bc})∧Θ_bc and the antisymmetric-stress identity; conservation of each source follows from the matter Noether identity.
   Source: E. Noether, *Invariante Variationsprobleme* (1918); Y. Kosmann-Schwarzbach, *The Noether Theorems*; F. W. Hehl, P. von der Heyde, G. D. Kerlick, J. M. Nester, *General relativity with spin and torsion* (Rev. Mod. Phys. 48, 1976).
   Links: GRV-008, EQN-013, GRV-009, GRV-011 (conservation "as a consequence"), MAT-002, MAT-003, CPL-005. Field: analysis, geometry. Check: partly — the identities are already checked on random fields; the theorem turns the n = 3–5 range of GRV-008 into a statement for every n.

4. **Chern–Weil theory and characteristic classes.**
   Statement: Ad-invariant polynomials give closed characteristic forms P(F) whose difference for two connections is exact (transgression to Chern–Simons forms). On so(1,3), whose complexification is sl₂ ⊕ sl₂, the invariant quadratic forms span a 2-dimensional space (trace form and Pfaffian), so tr R∧R and εR∧R are the only quadratic ones, and adding them to an action changes no field equation (Pontryagin and Euler classes; Gauss–Bonnet–Chern).
   Source: S.-S. Chern and J. Simons, *Characteristic forms and geometric invariants* (Ann. of Math. 99, 1974); S. Kobayashi and K. Nomizu, *Foundations of Differential Geometry*, vol. II (ch. XII).
   Links: INP-044 ("the only two within the ansatz tested"), INP-048, GRV-005, GRV-010, GRV-004 (the duality rotation e^{tI} is the complex structure of so(1,3)). Field: topology, geometry. Check: yes — the invariant forms are a finite linear-algebra computation on the engine's structure constants, for every so(p,q). This is the link from the gravity rows to topology that the Atlas does not draw.

5. **Lichnerowicz–Weitzenböck and the one-third rule for skew torsion.**
   Statement: for the Levi-Civita spin connection D̸² = ∇*∇ + R/4 (sign by convention) in every dimension; for a metric connection with totally skew torsion T, the Dirac operator built with T/3 squares to a Laplacian plus terms of order zero.
   Source: H. B. Lawson and M.-L. Michelsohn, *Spin Geometry* (ch. II, the Weitzenböck formula); J.-M. Bismut, *A local index theorem for non-Kähler manifolds* (Math. Ann. 284, 1989); I. Agricola and T. Friedrich, *On the holonomy of connections with skew-symmetric torsion* (Math. Ann. 328, 2004).
   Links: GRV-003, CPL-008, GRV-011 (the axial torsion of the spin source), GRV-001 (first Bianchi). Field: geometry, analysis. Check: partly — the engine checks at points; the all-n proof is a Clifford contraction plus the first Bianchi identity, which the engine could verify symbolically in the jets.

6. **Characteristics and hyperbolicity; counting the gravitational polarisations.**
   Statement: the principal symbol of a Dirac-type operator at ξ is Clifford multiplication by ξ, with σ(ξ)² = Q(ξ), so its characteristic variety is the null cone and the system is hyperbolic exactly for Lorentzian Q. For linearised gravity the gauge orbit has dimension n + C(n,2) at every covector (diffeomorphisms and local Lorentz), the de Donder symbol is −½|k|² times the identity, and n(n−3)/2 modes propagate at a null covector.
   Source: R. Courant and D. Hilbert, *Methods of Mathematical Physics*, vol. II (characteristics); L. Hörmander, *The Analysis of Linear Partial Differential Operators* (hyperbolic operators); R. M. Wald, *General Relativity* (ch. 4).
   Links: NUL-010, T16, T18 (f), EQN-008, CPL-005. Field: analysis. Check: yes — σ(ξ)² = Q(ξ) is the bit rule itself, so the determinant formula of NUL-010 holds for every n, not only n = 3–5.

7. **Smarr from Euler's theorem on homogeneous functions.**
   Statement: on the Kerr–Newman family M has weight 1 under (A, J, Q) ↦ (λ²A, λ²J, λQ); Euler's relation with ∂M/∂A = κ_H/8π, ∂M/∂J = Ω_H, ∂M/∂Q = Φ_H gives M = κ_H A/4π + 2Ω_H J + Φ_H Q for every member, and the first law is the differential of the same function.
   Source: L. Smarr, *Mass formula for Kerr black holes* (Phys. Rev. Lett. 30, 1973); J. M. Bardeen, B. Carter, S. W. Hawking, *The four laws of black hole mechanics* (Commun. Math. Phys. 31, 1973); R. M. Wald, *General Relativity* (ch. 12).
   Links: LAB-008, NUL-001 (its fourth line), EQN-020. Field: geometry, analysis. Check: yes — one symbolic identity in the closed-form parameters replaces the 84 directions and 29 horizons, and the constants "fitted from three cases" become derived.

8. **Birkhoff's theorem and the linearity of Kerr–Schild metrics.**
   Statement: every spherically symmetric vacuum solution with a cosmological constant is locally Schwarzschild–(anti-)de Sitter or of Nariai type; for g = η − 2f ℓℓ with ℓ null and geodesic, the mixed Einstein tensor is linear in f.
   Source: G. D. Birkhoff, *Relativity and Modern Physics* (1923); S. W. Hawking and G. F. R. Ellis, *The Large Scale Structure of Space-Time*; H. Stephani et al., *Exact Solutions of Einstein's Field Equations* (the Kerr–Schild chapter).
   Links: GRV-012, INP-054, INP-056, INP-058, LAB-005. Field: geometry. Check: partly — linearity in f, yes (symbolic); Birkhoff in general, no (an argument on the symmetry orbits).

9. **The even Clifford algebra as a sum of spinor modules.**
   Statement: Cl⁺(1,n−1) ≅ Cl(n−1,0) (T5) is one or two matrix algebras over ℝ, ℂ or ℍ fixed by the clock (T4); as a left module over itself it is N copies of the irreducible spinor module, and right multiplication by the commutant acts on the N-dimensional multiplicity space. The "extra components" from n = 5 are that multiplicity space, and the right actions of J and γ₀ belong to it.
   Source: H. B. Lawson and M.-L. Michelsohn, *Spin Geometry* (ch. I, §5); P. Lounesto, *Clifford Algebras and Spinors*.
   Links: CPL-003, CPL-007, INP-022, MAT-006, SPN-005, T4, T5. Field: algebra. Check: yes — the minimal left ideals and their commutant follow from T4 and T5 for every n; this answers the first half of CPL-007.

10. **Inönü–Wigner contractions, little groups, and Galilei against Carroll.**
    Statement: so(1,n) and so(2,n−1) contract to iso(1,n−1) as the square of the extra generator goes to 0; contracting the Lorentz algebra along time gives the Galilei algebra (it keeps dt), along space the Carroll algebra (it keeps ∂_t), and the two are dual; the stabiliser of a null vector in so(1,3) is iso(2), whose representations with trivial translations are labelled by helicity.
    Source: E. İnönü and E. P. Wigner, *On the contraction of groups and their representations* (Proc. Natl. Acad. Sci. 39, 1953); J.-M. Lévy-Leblond, *Une nouvelle limite non-relativiste du groupe de Poincaré* (Ann. Inst. H. Poincaré A 3, 1965); E. P. Wigner, *On unitary representations of the inhomogeneous Lorentz group* (Ann. of Math. 40, 1939); C. Duval, G. W. Gibbons, P. A. Horváthy, P.-M. Zhang, *Carroll versus Newton and Galilei: two dual non-Einsteinian concepts of time* (Class. Quantum Grav. 31, 2014).
    Links: EQN-015, PRJ-002, PRJ-004, NUL-004, RIG-007, NUL-012, EQN-021, T17. Field: algebra, geometry. Check: yes — contractions are limits of the engine's structure constants. The three appearances of iso(2) (horizon tube, little group, plane PGA) are one algebra, which the Atlas does not say.

11. **Pin± structures and the twisted adjoint representation.**
    Statement: the twisted adjoint x ↦ α(a) x a⁻¹ makes Pin(p,q) a double cover of O(p,q); Pin(p,q) and Pin(q,p) differ (a reflection's unit vector squares to +1 in one and −1 in the other); on a manifold the obstructions to Pin⁺ and Pin⁻ structures are w₂ and w₂ + w₁²; on fermions, time reversal squares to ±1 according to the Pin group.
    Source: M. F. Atiyah, R. Bott, A. Shapiro, *Clifford modules* (Topology 3, 1964); R. C. Kirby and L. R. Taylor, *Pin structures on low-dimensional manifolds* (LMS Lecture Notes 151).
    Links: INP-018, MIR-005 (time reversal as a reflection), INP-020, EQN-014; outside the chunk QD4 (Pin⁻ surfaces and the clock). Field: topology, algebra. Check: partly — which reflections square to ±1 under each convention, yes; the characteristic classes, no. This is the link from the mirror rows to topology.

12. **Frobenius algebras, the regressive product, and two-dimensional field theories.**
    Statement: a Frobenius form λ on A gives an isomorphism of A-modules A → A*, a ↦ λ(a ·); on Λ(V) it is the metric-free Poincaré duality into Λ^top, and the regressive (join) product is the exterior product transported along it; commutative Frobenius algebras classify 2D closed topological field theories and symmetric ones the open sector, with the Nakayama automorphism measuring the failure of symmetry.
    Source: J. Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories*; A. D. Lauda and H. Pfeiffer, *Open–closed strings: two-dimensional extended TQFTs and Frobenius algebras* (Topology Appl. 155, 2008); M. Barnabei, A. Brini, G.-C. Rota, *On the exterior calculus of invariant theory* (J. Algebra 96, 1985).
    Links: FRQ-002, T3, INP-051, PRJ-004, RIG-002 (the energy as a pairing). Field: category, algebra. Check: yes — the duality and the join are already engine operations and T3 has the Nakayama twist. Here the mechanics rows meet category theory.

13. **Euler–Arnold equations and the stability of steady rotations.**
    Statement: rigid motion is the geodesic flow of a left-invariant metric on a Lie group G and reduces to ṁ = ad*_{I⁻¹m} m on g*; Casimirs (Π·Π and Π∧Π on so(4)) are conserved; a relative equilibrium is linearly stable or unstable according to the spectrum of the linearised flow, and the energy–Casimir method gives nonlinear stability; the tennis-racket instability is the middle-axis case.
    Source: V. I. Arnold, *Mathematical Methods of Classical Mechanics* (appendix 2); J. E. Marsden and T. S. Ratiu, *Introduction to Mechanics and Symmetry* (the rigid-body chapters).
    Links: PRJ-005 (the instability rule, a conjecture on three bodies), EQN-016, FRQ-001, EQN-019, INP-061, RIG-002. Field: analysis, geometry. Check: yes — the linearisation at a steady rotation is a finite matrix on the engine, so "unstable iff another eigenvalue of Jη lies between the two of the plane" can be proved for every body rather than tested on three.

14. **Invariant decomposition and normal forms of skew operators.**
    Statement: every bivector of a non-degenerate Cl(p,q) is a sum of at most ⌊n/2⌋ mutually commuting simple bivectors, unique when the eigenvalues of the associated skew operator are distinct; in indefinite signature the normal forms are Williamson's.
    Source: M. Roelfs and S. De Keninck, *Graded symmetry groups: plane and simple* (Adv. Appl. Clifford Algebras 33, 2023); J. Williamson, *On the algebraic problem concerning the normal forms of linear dynamical systems* (Amer. J. Math. 58, 1936).
    Links: EQN-017, SPN-002, SPN-005, T17 (c); outside the chunk QT5. Field: algebra. Check: yes — the eigen-decomposition of the skew operator on the engine, for every n.

15. **The celestial sphere: SO⁺(1,3) ≅ PSL(2,ℂ) acting by Möbius maps.**
    Statement: the projectivised null cone of ℝ^{1,3} is S² = ℂP¹, parametrised by P(x) = o + x − ½x²ε; the restricted Lorentz group acts on it as the Möbius group, which is generated by inversions, and its point stabilisers are the little groups of item 10.
    Source: R. Penrose and W. Rindler, *Spinors and Space-Time*, vol. 1 (ch. 1).
    Links: NUL-008, EQN-015, NUL-004, PRJ-003, NUL-012. Field: geometry. Check: yes — the identification holds for every null vector, so the 96-vector check of NUL-008 becomes a proof.

16. **Staggered fermions and the doubling theorem.**
    Statement: the naive lattice Dirac operator in n dimensions has 2ⁿ zeros in the Brillouin zone; the Kogut–Susskind phases η_μ(x) reorganise them as 2^{⌊n/2⌋}-component spinors in 2^{⌈n/2⌉} tastes; no local, translation-invariant, hermitian, chirally symmetric lattice operator avoids doubling (Nielsen–Ninomiya, a topological argument).
    Source: J. Kogut and L. Susskind, *Hamiltonian formulation of Wilson's lattice gauge theories* (Phys. Rev. D 11, 1975); H. B. Nielsen and M. Ninomiya, *Absence of neutrinos on a lattice* (Nucl. Phys. B 185, 1981).
    Links: SPR-004, SPR-003, T19, T20. Field: topology, analysis. Check: partly — zero modes and taste counts, yes (done for n = 2–4); the no-go theorem, no.

17. **Maxwell–Calladine counting and infinitesimal rigidity.**
    Statement: a bar framework with V joints and E bars in ℝᵈ has dim(mechanisms) − dim(self-stresses) = dV − E − C(d+1,2); in the plane, generic rigidity is decided by Laman's count.
    Source: C. R. Calladine, *Buckminster Fuller's "tensegrity" structures and Clerk Maxwell's rules for the construction of stiff frames* (Int. J. Solids Struct. 14, 1978); G. Laman, *On graphs and rigidity of plane skeletal structures* (J. Eng. Math. 4, 1970).
    Links: RIG-006, SPR-004 (vector displacements), RIG-007 (the C(n+1,2) rigid motions are the PGA bivectors). Field: combinatorics, geometry. Check: yes — the rank of the rigidity matrix of the n-cube; with no self-stress the count n·2^(n−1) − C(n+1,2) holds for every n.

18. **Utiyama's theorem: gauge-invariant Lagrangians and one coupling.**
    Statement: a Lagrangian of a connection and a matter field invariant under local gauge transformations depends on the connection only through its curvature and the covariant derivative; the Yang–Mills–Dirac action then ties the coupling of the field equation to that of the covariant derivative and fixes the sign of the source.
    Source: R. Utiyama, *Invariant theoretical interpretation of interaction* (Phys. Rev. 101, 1956).
    Links: MAT-005, INP-033, INP-037, INP-040, YM-005, CPL-005 (the abelian case, already rebuilt from an action). Field: geometry, analysis. Check: yes — the engine varied the abelian action (bd·phy·18); the same variation for so(m) turns two pointers into checked rows.

19. **The Schwartz–Zippel lemma as an evidence class.**
    Statement: a nonzero polynomial of total degree d vanishes at a uniformly random point of Sⁿ with probability at most d/|S|, and independent trials multiply the bound.
    Source: J. T. Schwartz, *Fast probabilistic algorithms for verification of polynomial identities* (J. ACM 27, 1980); R. Zippel, *Probabilistic algorithms for sparse polynomials* (1979).
    Links: GRV-001, GRV-002, GRV-005, GRV-006, GRV-008, GRV-010, EQN-012, EQN-013, INP-044, INP-048. Field: combinatorics. Check: yes (already in use). Stated once as a definition, it gives the scheme a missing evidence class between `range` and `theorem` — "identity, randomized, failure ≤ ε" — which ten rows of this chunk need.

**One-line theorems already recorded in the notes** (no separate entry needed): the triangular-graph degree 2(m − 2) (EQN-001, YM-002); grades ≡ 1 mod 4 of an odd reversion-symmetric element (CPL-002); the ratio 2^(⌈n/2⌉−2) (CPL-003); one J-orbit for every n ≥ 4 (INP-024); the closed formula for I² (PRJ-002); Walsh modes as characters (SPR-003); the outermorphism behind the n + 1 sandwiches (PAG-023); the Gray code (RIG-003); a central pseudoscalar only for odd n (SPN-005); parity of odd multipoles (RIG-002).
