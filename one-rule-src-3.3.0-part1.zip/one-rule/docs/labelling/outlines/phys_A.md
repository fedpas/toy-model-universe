# Physicist's labelling of chunk A (142 rows)

Scope: the Rule page, the atlas cards (ATL), the Genesis ladder (GEN), the page claim strips (PAG), the Conventions and Clock tabs (LAB), the Maxwell calibration, the Shapes page (SHP, GOS), the step-6 coupling row (CPL-011), the researcher notes (RSN) and the input rows (INP). Labels are in `phys_A.jsonl`. The scripts' results are taken as given; nothing was re-run.

---

## A. How physics would organise these rows

Physics builds in this order: the algebra, then kinematics (signature, frames, symmetry generators, spinors), then fields and their equations, then solutions and motion, then comparison with what is observed. The method rows come last.

### 0. The algebra (stage A)

| section | rows | why here |
|---|---|---|
| A1 Rule and labels | PAG-002, PAG-005, PAG-003, ATL-001 ≡ GEN-001 | T1 gives every algebra from the bit rule. Nothing physical yet. |
| A2 Cell types (the mod-8 menu) | PAG-004, ATL-024, ATL-002, ATL-003, ATL-004, ATL-005, ATL-009, ATL-007, ATL-016, ATL-019, ATL-020 (type line), ATL-021, ATL-022, ATL-023 ≡ GEN-009, LAB-001, RSN-029 | Each card is an instance of T4. Physics reads them only as the list of algebras on offer. |
| A3 The clock as an invariant | LAB-017 ≡ RSN-029 ≡ LAB-023, LAB-022, LAB-025, LAB-024, INP-017, RSN-030, RSN-031 | The clock is the one number that physics meets again later (Bott periodicity, the Fidkowski–Kitaev ℤ₈). |
| A4 Null generators and pairing | GEN-002, GEN-003, GEN-004, GEN-005, INP-013, SHP-002, RSN-016 | The radical and Witt pairs. A physicist first meets "null" as fermion creation and annihilation operators (CAR, Fock space). |

### 1. Kinematics (stage K)

| section | rows | why here |
|---|---|---|
| K1 Signature convention, chart, observer | INP-011 ≡ INP-005 ≡ INP-017 ≡ INP-086, INP-003, INP-009, ATL-010, ATL-012 (cell line), ATL-006, ATL-008 | Time, the chart and the observer are chosen before any field. |
| K2 Bivectors: rotation, boost, translation | PAG-031 ≡ LAB-015, LAB-003, LAB-004 ≡ RSN-014, RSN-010, RSN-013, ATL-011, RSN-007 ≡ RSN-023, RSN-018 | The generators of the Lorentz and Poincaré groups. T17 is the hub. |
| K3 Spinors and pinors | ATL-015 ≡ GEN-008, RSN-028, RSN-012, INP-080, ATL-025 | The representation content that the fields will carry. |
| K4 Geometries from one extra generator | RSN-008 ≡ RSN-022, ATL-013, ATL-014 | Cayley–Klein geometries, de Sitter and anti-de Sitter, the conformal group. |
| K5 Hyperbolicity and causality | PAG-011, PAG-034, INP-012 | What makes a signature a spacetime: a well-posed initial-value problem. |
| K6 Lattices and root systems | SHP-001, SHP-007, SHP-004, SHP-006 ≡ GOS-002, GOS-001, GOS-005 ≡ GOS-007, GOS-006, PAG-017, PAG-018, PAG-020, INP-016 | Kinematic data for unification groups (E8, so(16), so(10)). |

### 2. Fields and their equations (stage F)

| section | rows | why here |
|---|---|---|
| F1 Maxwell | INP-004, INP-006, INP-001 ≡ PAG-010, INP-002, RSN-025 ≡ PAG-008, ATL-017, PAG-019, GOS-004 | Postulates, then the equation, then its consequences (wave equation, charge conservation). |
| F2 Dirac | RSN-027, ATL-012 (mass-shell line), SHP-003 | The first-order equation and its square. |
| F3 Actions, Noether identities, gravity | CPL-011, ATL-018, INP-085 | Field equations as stationarity conditions; covariance of the Einstein form. |

### 3. Dynamics and solutions (stage D)

| section | rows | why here |
|---|---|---|
| D1 Charges in given fields | INP-007, INP-008, INP-010, PAG-009 ≡ RSN-026 | The force law, initial data and prescribed fields. |
| D2 Rigid bodies | RSN-005, RSN-006, RSN-024 | Euler's equations in PGA; the free top; Kepler. |
| D3 Point mass and horizons | RSN-017, RSN-015 ≡ RSN-019, RSN-020, RSN-021 | An exact solution, then the geometry of its horizon. |
| D4 Interacting Majorana chains | LAB-021 | A model computation (ground-state degeneracy). |

### 4. Observation and calibration (stage O)

| section | rows | why here |
|---|---|---|
| O1 The clock as known physics | LAB-018 | Pin⁻ bordism, the Fidkowski–Kitaev ℤ₈, KO-theory. |
| O2 Standard Model content | SHP-005, INP-014, RSN-001, RSN-002, RSN-003, INP-015, GEN-006, GEN-007, ATL-020, INP-083 | One generation, its charges and the comparison with Furey's model. |
| O3 Generations and E8 | GOS-003 ≡ RSN-004, INP-082 | The 3 of E8 ⊃ E6 × A2; open. |
| O4 Other comparisons | PAG-006, PAG-012, INP-084 | Textbook identifications; the Madelung rule. |

### 5. Method and meta (stage M)

PAG-001, PAG-003, PAG-007, PAG-029 ≡ LAB-013, PAG-030 ≡ LAB-014, LAB-002, PAG-033, EQN-005, RSN-009, RSN-011, INP-081, and the open list PAG-032 ≡ LAB-016.

### Where the Atlas's page order differs from the physics order

- **Role names.** The atlas page puts physics names (quark, lepton, electroweak core, confinement, cosmic horizon, baryon, sterile neutrino, Higgs VEV) on the A2 cards. Physics would leave the cards as the stage-A menu and move every role name to O, as readings. Most card rows already deny their own name.
- **Two field rows are hidden among the cards.** ATL-017 (Maxwell) belongs in F1. ATL-018 (covariance and linearisation of the Einstein form) belongs in F3, next to CPL-011.
- **Genesis comes too early.** GEN builds cells by pairing nulls before any kinematics. Physics meets the same content later, as Fock space and the CAR (SHP-002), after spinors.
- **The Clock tab mixes stages.** Algebra (LAB-017, LAB-022, LAB-025) sits beside condensed matter (LAB-018, the FK ℤ₈; LAB-021, the junction). Physics splits them into A3, O1 and D4.
- **Hyperbolicity is on the wrong page.** The Maxwell page holds PAG-011 and PAG-034. Physics puts hyperbolicity in K5, before any field equation, because it is what selects the signature.
- **The Shapes page mixes three stages.** Lattices (K6) sit beside one Standard Model generation (SHP-005, O2) and lattice fermions (SHP-003, F2).
- **One convention is stated in many places.** The time and sign convention is stated in four INP rows on three pages, plus ATL-010 and ATL-012. The physics rows (Dirac, gravity, conformal, Kaluza–Klein) all use time-positive Cl(1,3), but ATL-010 and ATL-017 call Cl(3,1) the Atlas's "Minkowski" and EM card. Physics fixes one convention once, at the start of K1.

---

## B. Chains, classes and loops

### Chains (by `derives` or `instance`)

1. **T1 → PAG-002, PAG-005.** The rule gives the data of each cell.
2. **T4 → 27 rows.** The cell cards are instances of T4. One chain continues: T4 → LAB-017 → LAB-018 → LAB-021 (algebra → invariant → known physics → a model).
3. **LAB-017 → LAB-022 → LAB-024, LAB-025.** The additive ℤ₄ charge, its weights and its frame.
4. **T20 → GEN-003 → GEN-004, GEN-005 → GEN-006; T20 → SHP-002 → GEN-005, GEN-007, SHP-005.** Pairing → Fock space → one generation.
5. **T17 → LAB-003, LAB-015 ≡ PAG-031, RSN-010, RSN-013, RSN-014 ≡ LAB-004, RSN-018.** ATL-011 is an instance.
6. **T18 → PAG-011 → INP-012.** Also T18 → INP-011; T18 → RSN-015 → RSN-020; T18 → RSN-016, RSN-021. RSN-017 is an instance of T18(d).
7. **T10 → GOS-005 → GOS-006, PAG-020; T10 → SHP-006 ≡ GOS-002 → PAG-018, GOS-004.**
8. **Maxwell.** INP-003, INP-004 → INP-001 → RSN-025 → ATL-017 → GOS-004, and RSN-025 → INP-010 (instance). INP-007 enters RSN-025, PAG-009 and RSN-026 from outside: it is one-way.
9. **Dirac.** T16 → RSN-027 → RSN-028; T16 → ATL-010, ATL-012, SHP-003.
10. **Gravity.** INP-001 → CPL-011 → ATL-018, RSN-017.
11. **Mechanics.** RSN-005 → RSN-006; RSN-005 → RSN-024 (instance).
12. **Standard Model.** INP-015 → RSN-002 ≡ ATL-025 → RSN-003; INP-014 → SHP-005.

### Classes (`equiv`)

| class | what it is |
|---|---|
| {ATL-001, GEN-001} | the empty label as the vacuum origin |
| {ATL-015, GEN-008} | the central split into two pinor classes |
| {ATL-023, GEN-009} | the Bott repeat at row 8 |
| {PAG-029, LAB-013}, {PAG-030, LAB-014}, {PAG-031, LAB-015}, {PAG-032, LAB-016} | verbatim duplicates: keep one of each pair |
| {LAB-017, RSN-029, LAB-023} | the clock as the phase of a Gauss sum, also written as a product over modes |
| {INP-005, INP-011, INP-017, INP-086} | one sign convention, stated in four places |
| {RSN-008, RSN-022} | Cayley–Klein geometries from one extra generator |
| {RSN-007, RSN-023} | Cartan–Dieudonné on the cube |
| {RSN-015, RSN-019} | the four null-surface claims (RSN-019 is the summary) |
| {GOS-003, RSN-004, QT8} | the generation A2 inside E8 |
| {SHP-006, GOS-002} | E8 = D8 roots + one half-spinor |
| {GOS-005, GOS-007} | E_n as k⊥ in I_{1,n}, also as the del Pezzo lattice |
| {LAB-004, RSN-014} | the conformal translator as a null rotation |
| {ATL-025, RSN-002} | the Peirce blocks of End(V) |
| {PAG-009, RSN-026}, {PAG-008, RSN-025}, {PAG-010, INP-001}, {PAG-004, ATL-024, T4} | page strips and the rows they restate |

### Loops (`cycle`)

- **{PAG-008, CPL-011}.** The relative sign of source and force is fixed by requiring positive field energy: a convention fixed by consistency.
- **Near-loop {INP-011, T18, PAG-011}.** "Time is the minority sign" is chosen so that the wave operator is hyperbolic, and hyperbolicity is then cited as what selects the Lorentzian split. It is encoded one-way (INP-011 derives from T18), but the pages read it both ways.

### Contradictions as worded

- **ATL-002 against GEN-002.** ATL-002's reading says a lone null generator cannot turn into the cell Cl(1,0). GEN-002 says it can, by deformation (e² = t). Fix: add "by pairing" to ATL-002.
- **RSN-011 against T15.** RSN-011 says the probability reading is open beyond Cl(3,0). T15 proves the states and the Born rule for every Cl(p,q,r). RSN-011 is stale.

### Hubs and leaves

**Hubs** (number of rows that rest on them):

| hub | dependants |
|---|---|
| T4 | 27 |
| T17 | 9 |
| T18 | 9 |
| core·B14 | 8 |
| T10, INP-011 | 6 each |
| INP-001, INP-004 | 5 each |
| T5 | 5 |
| T16, T20, LAB-017, INP-003, INP-015 | 4 each |

Among the rows of this chunk, the hubs are the inputs (the time convention, the action, the grade assignment, the chart, Furey's model) and LAB-017.

**Leaves** (nothing rests on them): most cell cards (ATL-002 to 005, 007, 009 to 011, 013, 016, 018 to 022, 024); GEN-004, GEN-006, GEN-007; all meta strips; PAG-002, 003, 005, 006, 010, 012, 017 to 020, 034; LAB-001 to 003, LAB-021, LAB-023 to 025; SHP-003 to 007; GOS-001, 004, 006, 007; RSN-001, 003, 006, 009 to 013, 016 to 021, 023, 024, 028, 030, 031; INP-006, 009, 010, 012, 014, 017, 080 to 086.

The physics leaves (ATL-018, RSN-017, RSN-026, LAB-021, SHP-005) are where the missing pieces in section C would attach.

### Status issues seen while labelling

These are details for the status computation; each affected row also has a note in the jsonl file.

- **Checked, but the script was only read.** Rows flagged checked whose scripts were only read, or whose mode is unspecified: LAB-001 to LAB-016, the SHP and GOS rows, RSN-006, RSN-014 (which says "ran"), RSN-024, RSN-030, RSN-031, PAG-018 (the E-diagram part), PAG-029 ("confirmed").
- **Standard, but the source was unread.** PAG-034 and PAG-011 cite the same Gårding paper; PAG-011 calls it a pointer, source unread, while PAG-034 is flagged standard. LAB-018 contains the Atiyah–Bott–Shapiro KO identification as an unread pointer. RSN-030 rests on unread pointers.
- **Inputs used but not flagged.** SHP-002 (the vacuum), SHP-005 (the charge formulas) and GOS-002 (the E8 bracket) use inputs but carry no input flag. RSN-005, RSN-011, RSN-017, RSN-020 and RSN-027 are flagged input but name no input.
- **Wrong kind of label.** GOS-007 calls a classical fact "ours". GOS-006 ends with a conjecture labelled as a reading. GOS-004 is flagged "standard, open" but states a definite negative. EQN-005 is not a statement.
- **QT8.** questions.json marks QT8 as answered, but GOS-003 and RSN-004 still say open.
- **Rows to split.** CPL-011 holds at least six claims. ATL-012, ATL-018, ATL-020 and GEN-009 mix stages.

---

## C. Missing pieces

Ordered by consequence, most consequential first. "Check" says whether a script on the Atlas's engine could compute it.

### 1. Maxwell stress-energy and the Lorentz force from conservation

- **Statement.** The field's stress-energy T(a) = −½ F a F has divergence F·J whenever ∇F = J. Conservation of total energy-momentum then gives the Lorentz force density on the sources.
- **Source.** D. Hestenes, *Space-Time Algebra*; C. Doran and A. Lasenby, *Geometric Algebra for Physicists*; J. D. Jackson, *Classical Electrodynamics*.
- **Links.** INP-007, RSN-025, PAG-008, PAG-009, RSN-026, CPL-011. It makes the one-way chain INP-007 → RSN-025 two-way: the force law follows from the field equation plus conservation.
- **Check.** Yes: ∇·T(a) is a finite polynomial identity.

### 2. The gauge principle (minimal coupling)

- **Statement.** Requiring invariance of the Dirac Lagrangian under a local phase rotation of ψ forces a connection A, with ∇ → ∇ − eA and A → A + ∇θ/e. The U(1) then belongs to the field ψ, not to the cell Cl(0,1).
- **Source.** H. Weyl, "Elektron und Gravitation" (1929); C. N. Yang and R. Mills, "Conservation of isotopic spin and isotopic gauge invariance" (1954); Doran and Lasenby.
- **Links.** ATL-003 (whose open reading it would replace by a derivation), CPL-011 (the Dirac–Maxwell coupling), RSN-027, ATL-017, INP-001.
- **Check.** Yes: covariance of the coupled Dirac operator under a local rotor is an exact identity.

### 3. Retarded Green's function and the Liénard–Wiechert fields

- **Statement.** ∇F = J is solved by the retarded potential. For a point charge on any worldline this gives the Liénard–Wiechert field, whose static limit is the Coulomb field that INP-010 puts in by hand.
- **Source.** Jackson, *Classical Electrodynamics*; Doran and Lasenby.
- **Links.** INP-010, RSN-025, ATL-017, RSN-026. It closes the gap between the field equation and its solutions.
- **Check.** Yes off the worldline (∇F = 0 for the closed form); partly for the distributional source.

### 4. Gravitational waves

- **Statement.** The linearised vacuum equation E⁽¹⁾ = 0 has plane waves with k² = 0 and two physical polarisations in TT gauge. These are exactly the n(n−3)/2 = 2 kernel modes at null covectors that ATL-018 already computes at n = 4. Their energy flux gives the quadrupole formula.
- **Source.** M. Fierz and W. Pauli (1939); C. Misner, K. Thorne and J. Wheeler, *Gravitation*; M. Maggiore, *Gravitational Waves*, vol. 1.
- **Links.** ATL-018, CPL-011, RSN-017.
- **Phenomenon approached, not derived:** gravitational waves.
- **Check.** Yes for the polarisations; partly for the quadrupole formula.

### 5. Conservation of matter from the Bianchi identity, and geodesic motion

- **Statement.** The diffeomorphism (Bianchi) identity forces ∇·T = 0 on any source. For dust this is the geodesic equation, so free fall follows from the field equation instead of being assumed.
- **Source.** A. Einstein, L. Infeld and B. Hoffmann, "The gravitational equations and the problem of motion" (1938); R. Wald, *General Relativity*.
- **Links.** CPL-011 (its Noether identity), RSN-017 (free fall d²r/dτ² = −M/r²), ATL-018. It closes the gap between the field equation and motion.
- **Check.** Yes: add dust, T = ρ u⊗u, to the identity already checked.

### 6. The Pauli term and g = 2

- **Statement.** Squaring the coupled Dirac operator gives the covariant wave operator plus a spin term e F acting on ψ. This is the gyromagnetic ratio g = 2.
- **Source.** P. A. M. Dirac, "The quantum theory of the electron" (1928); J. J. Sakurai, *Advanced Quantum Mechanics*.
- **Links.** SHP-003 ("the second-order equation appears only after squaring"), T16, RSN-027, CPL-011.
- **Phenomenon approached, not derived:** the electron's magnetic moment.
- **Check.** Yes: a finite symbolic identity on the even ψ of Cl(1,3).

### 7. The Noether current of the Dirac field

- **Statement.** Global phase invariance gives a conserved current ψγ₀ψ̃. ∂·J = 0 is the integrability condition of ∇F = J.
- **Source.** E. Noether, "Invariante Variationsprobleme" (1918); M. Peskin and D. Schroeder, *An Introduction to Quantum Field Theory*.
- **Links.** CPL-011 (where the matter currents are still a pointer), RSN-025, RSN-027. It makes RSN-025 ↔ RSN-027 two-way.
- **Check.** Yes.

### 8. The spacetime split

- **Statement.** With a chosen γ₀, the bivectors σ_k = γ_kγ₀ of Cl(1,3) generate the Pauli algebra. E and B are the relative-vector and relative-bivector parts of F.
- **Source.** Hestenes, *Space-Time Algebra* (1966); Doran and Lasenby.
- **Links.** ATL-006, ATL-008, ATL-012, INP-009, ATL-017. Today ATL-006 and ATL-012 are separate cards; this links them.
- **Check.** Yes.

### 9. Wigner's little groups

- **Statement.** In Spin(1,3), the stabiliser of a timelike momentum is SU(2) (spin) and that of a null momentum is E(2) (helicity). Spin at rest is then derived from the mass shell.
- **Source.** E. Wigner, "On unitary representations of the inhomogeneous Lorentz group" (1939); S. Weinberg, *The Quantum Theory of Fields*, vol. 1.
- **Links.** ATL-010, ATL-012 and T16 (the mass shell); ATL-005 and ATL-006 (SU(2), Pauli); ATL-008; RSN-028.
- **Check.** Yes: compute the even versors that commute with p.

### 10. Dirac–Coulomb fine structure

- **Statement.** The Dirac equation in a Coulomb field has exact bound states with the Sommerfeld–Dirac energy formula.
- **Source.** C. G. Darwin (1928); W. Gordon (1928); J. Bjorken and S. Drell, *Relativistic Quantum Mechanics*.
- **Links.** RSN-027, INP-010, ATL-012, RSN-026 (its classical analogue, the Sommerfeld precession). It closes the gap between the Dirac equation and its solutions.
- **Check.** Partly: verify that the closed form solves the radial equation.

### 11. Hydrogen from so(4) and so(4,2)

- **Statement.** For bound Kepler orbits, the Runge–Lenz vector and the angular momentum close on so(4). The Casimir gives E_n = −1/(2n²) with degeneracy n². so(4,2) is the spectrum-generating algebra.
- **Source.** V. Fock, "Zur Theorie des Wasserstoffatoms" (1935); V. Bargmann, "Zur Theorie des Wasserstoffatoms" (1936); A. Barut and H. Kleinert (1967).
- **Links.** ATL-014 (so(4,2) as hydrogen's algebra), RSN-006 (the Runge–Lenz vector, exact), INP-084 (the Madelung rule, taken as given).
- **Phenomenon approached, not derived:** the hydrogen spectrum and its shell structure.
- **Check.** Yes for the algebra; partly for the spectrum, which needs quantisation.

### 12. sin²θ_W = 3/8 from the charges of the 16

- **Statement.** Over a complete SU(5) multiplet, Tr T₃² / Tr Q² = 3/8: the unification value of the weak mixing angle. On the 16 of SHP-005 it is a sum of bit counts.
- **Source.** H. Georgi and S. Glashow, "Unity of all elementary-particle forces" (1974); H. Georgi, H. Quinn and S. Weinberg, "Hierarchy of interactions in unified gauge theories" (1974).
- **Links.** ATL-020 (whose negative would become a calibration: the right number from the right formula), SHP-005, INP-014, RSN-001.
- **Check.** Yes.

### 13. Full anomaly cancellation and the uniqueness of hypercharge

- **Statement.** All six anomaly conditions (SU(3)²Y, SU(2)²Y, Y³, grav²Y, SU(3)³, Witten's SU(2)) vanish for one generation. Together with the Yukawa terms they fix the hypercharges up to normalisation.
- **Source.** C. Q. Geng and R. Marshak (1989); J. Minahan, P. Ramond and R. Warner (1990).
- **Links.** SHP-005 (which checks only ΣY and ΣY³), INP-014 (it would become partly derived), GEN-006, RSN-001.
- **Check.** Yes: sums and a small search over the bit counts.

### 14. Charge conjugation and CPT as the anti-involution

- **Statement.** Charge conjugation is an antilinear map on Dirac spinors, and the CPT theorem fixes the combined operation. This is the standard input that would turn the two pinor classes, or the complement labels, into particle and antiparticle.
- **Source.** G. Lüders (1954); W. Pauli (1955); R. Streater and A. Wightman, *PCT, Spin and Statistics, and All That*.
- **Links.** ATL-015 ≡ GEN-008 (the unnamed anti-involution), RSN-028 (β = π for negative energy), SHP-005, INP-080.
- **Check.** Yes: C, P and T act as versor maps on the even ψ.

### 15. The Hawking temperature T = κ/2π

- **Statement.** A Killing horizon with surface gravity κ radiates at T = κ/2π. Equivalently, the Euclidean section is regular only for an imaginary-time period of 2π/κ. With S = A/4 this gives the first law of black-hole mechanics.
- **Source.** S. Hawking, "Particle creation by black holes" (1975); G. Gibbons and S. Hawking, "Action integrals and partition functions in quantum gravity" (1977).
- **Links.** RSN-015 (κ is computed there), RSN-017, RSN-021.
- **Phenomenon approached, not derived:** black-hole thermodynamics.
- **Check.** Partly: the Euclidean period yes, the radiation no.

### 16. The Kerr–Schild double copy

- **Statement.** The Kerr–Schild form of Schwarzschild, g = η + (2M/r) k⊗k, maps to the Coulomb potential A = (Q/r) k with the same null k.
- **Source.** R. Monteiro, D. O'Connell and C. White, "Black holes and the double copy" (2014).
- **Links.** RSN-017, INP-010, ATL-017. It joins the Maxwell page to the gravity rows.
- **Check.** Yes: both sides are already on the engine.

### 17. Covariant conservation for Yang–Mills

- **Statement.** Gauge invariance of the Yang–Mills action gives D⋆F = J with D·J = 0 (Noether's second theorem). The Bianchi identity DF = 0 is the Jacobi identity, already checked.
- **Source.** Yang and Mills (1954); R. Utiyama, "Invariant theoretical interpretation of interaction" (1956).
- **Links.** CPL-011 (where it is still a pointer), ATL-014.
- **Check.** Yes: the engine has the so(p,q) tables.

### 18. Pin± and T² = ±1

- **Statement.** Fermions whose time reversal satisfies T² = (−1)^F or T² = 1 need Pin⁺ or Pin⁻ structures. The Pin⁻ bordism group ℤ₈ is the Fidkowski–Kitaev classification.
- **Source.** A. Kapustin, R. Thorngren, A. Turzillo and Z. Wang (2015); E. Witten, "Fermion path integrals and topological phases" (2016).
- **Links.** PAG-032 ≡ LAB-016 (which says this is not treated), LAB-018, LAB-021.
- **Check.** Partly: the bit rule reads the square of the reflection generator; the bordism is recalled.

### 19. The Higgs mechanism

- **Statement.** A scalar doublet with a VEV breaks SU(2)×U(1)_Y to U(1)_em and gives m_W = m_Z cos θ_W. The VEV belongs to a field in a non-trivial representation, not to the identity element.
- **Source.** P. Higgs (1964); F. Englert and R. Brout (1964); S. Weinberg, "A model of leptons" (1967).
- **Links.** ATL-021, ATL-011, ATL-005, ATL-020.
- **Check.** Partly: the group theory yes; the masses need couplings as inputs.

### 20. The exceptional curves of del Pezzo surfaces (a credit)

- **Statement.** The (−1)-curves of dP_n number 6, 10, 16, 27, 56 and 240, and they are the vertices of the Gosset polytopes. This is classical.
- **Source.** H. S. M. Coxeter, "The polytope 2₂₁ whose twenty-seven vertices correspond to the lines on the general cubic surface" (1940); Y. Manin, *Cubic Forms*.
- **Links.** GOS-007 (its "ours" should become standard), GOS-005, T13.
- **Check.** Yes: the counts are already done; only the credit changes.

### 21. Spin and statistics

- **Statement.** Half-integer spin fields are quantised with anticommutators (the CAR), integer spin fields with commutators.
- **Source.** W. Pauli, "The connection between spin and statistics" (1940); Streater and Wightman.
- **Links.** GEN-003 and SHP-002 (the CAR and Fock space), ATL-012 and RSN-027 (spinors).
- **Check.** No: it needs the axioms of relativistic quantum field theory.
