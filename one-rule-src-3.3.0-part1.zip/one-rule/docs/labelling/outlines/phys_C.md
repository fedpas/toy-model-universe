# phys_C: the physicist's organisation of chunk C

Chunk C has 156 rows: the finite-groups step (LAB-009, -010, -011, -012, -019, -020 and INP-079), the category lens of step 18 (LNC-001 to LNC-145) and the lenses page strip (LNP-001 to LNP-004). The row labels are those of `phys_C.jsonl`, which this file does not change. Every count in §B was taken by hand from the `depends` field of that file. Theorem ids T1–T20 count as nodes.

Conventions used here:
- A chain is written in logical order, premise → consequence. This is the `derives` edge of the jsonl read backwards.
- A row "rests on" a node when it has a `derives`, `instance` or `uses-input` edge to that node. `equiv` and `cycle` edges are reported separately.

**Stage tally (jsonl).** A 91 · K 36 · F 0 · D 0 · O 7 · M 22.

**Phenomena.** qm 32 · lattice 20 · gravity 6 (black-hole 5) · electron 2 · light 2 · matter 1 · gauge, cosmology and mechanics 0.

The chunk contains only algebra and kinematics. It stops before the first field equation, and the rows say so themselves: LNC-001 ("nothing here is about … dynamics") and LNC-093 ("nothing is conserved: that would need a Hamiltonian").

---

## A. How physics would organise these rows

The sections below follow the order in which physics builds the material: first the algebra of one mode, then many modes, then pairings, kinematics and observation. Appendices and readings come last. Every row of the chunk appears exactly once.

**A0. Preface: scope, provenance, frontier (M).** LNC-001, LNC-023, LNC-103, LNP-001, LNP-002, LNP-004.
These rows talk about the chapter, not about nature. LNP-004 lists what is not rebuilt (closure equations, generations, a null among the ten classes). That frontier belongs in the preface, not among the results.

**A1. One, zero and the nilpotent (vacuum and exclusion).** LNC-011, LNC-012, LNC-013, LNC-145.
Physics starts from three objects and keeps them apart: the identity (the Fock vacuum, the empty occupation pattern), the zero vector, and a nilpotent θ² = 0 (Pauli exclusion as nilpotency). LNC-145 checks the separation on Majkić's zero.

**A2. Exchange signs as a gauge choice (statistics).** LNC-050, LNC-056, LNC-010, LNC-140, LNC-137, LNC-086.
- The Jordan–Wigner string is the fermion sign.
- It is unique up to a ℤ₂ gauge, with π flux through every face.
- Every planar picture of it is pure gauge.
- Associativity holds; the octonion associator is the counterexample.

Every later row uses these signs, so physics fixes them first.

**A3. Fock space: occupation numbers, CAR, number operator.** LNC-099, LNC-100, LNC-138, LNC-139, LNC-142, LNC-144, LNC-060, LNC-080, LNC-024, LNC-134.
- Labels are occupation patterns and the popcount is the particle number.
- Creation operators and projectors are the matrix units of Cl(n,n) = End Λ.
- Two generators of opposite square give one CAR pair (c, c†).
- The section also holds hard-core bosons against fermions, and CAR against CCR (QE3).

**A4. The Grassmann sector: null generators, radical, ghost number.** LNC-002, LNC-014, LNC-016, LNC-017, LNC-105, LNC-015, LNC-102, LNC-106, LNC-101, LNC-089, LNC-003, LNC-020, LNC-093, LNC-084, LNC-085, LNC-133, LNC-135, LNC-026, LNC-040, LNC-136, LNC-071.
- Cl(p,q) ⊗̂ Λ(ℝʳ) is a fermion algebra with Grassmann (Berezin) variables, nilpotent of order r + 1.
- The ℤ-lift of parity is ghost number or particle number.
- A Grassmann generator is half of a Witt pair whose partner was dropped (the mother algebra).

LNC-071 is the editorial anchor of the section.

**A5. Pairings, traces and duality (Berezin integral, supertrace, Hodge star).** LNC-004, LNC-028, LNC-111, LNC-029, LNC-112, LNC-109, LNC-030, LNC-064, LNC-090, LNC-110, LNC-031, LNC-113, LNC-033, LNC-039, LNC-072, LNC-114, LNC-032, LNC-066, LNC-077, LNC-097, LNC-123.
- The top-blade form is the Berezin integral.
- Its Nakayama twist is the Koszul sign, which is the cyclicity of the supertrace.
- The ordinary trace is blind to the odd sector.
- Maxwell's ⋆F needs an invertible top blade.

QA4 asks what this means for the dual of projective geometric algebra (PGA). Physics needs the pairings before it can define states (A8).

**A6. Subsystems, composites and spinors (kinematics).** LNC-035, LNC-117, LNC-120, LNC-007, LNC-036, LNC-063, LNC-091, LNC-037, LNC-121, LNC-038, LNC-118, LNC-141, LNC-041, LNC-073, LNC-115, LNC-119.
- Join is the composite of fermion systems (the Koszul sign is the exchange sign).
- Halving gives the even subalgebra, which carries the spinors: Spin⁺(1,3) ≅ SL(2,ℂ).
- Restrict gives subsystems; dropping modes is an algebra map only for Grassmann modes.
- Functoriality is the covariance of the gamma algebra under isometries.

**A7. Causal structure: null vectors and null hypersurfaces.** LNC-021, LNC-025, LNC-070, LNC-075, LNC-098, LNC-108.
This section sets two nulls against each other:
- the light-cone pair of the (t,r) plane, a paired null of the non-degenerate Cl(1,1);
- the degenerate tangent algebra Cl(0,n−2,1) of a horizon, which has an unpaired null.

The Carroll structure is the open lead (LNC-098).

**A8. States and measurement.** LNC-005, LNC-019, LNC-065, LNC-122, LNC-034, LNC-078, LNC-059, LNC-079.
- Positive functionals are density elements.
- No state sees the Grassmann sector, and the Berezin form is not a state.
- The section also holds the trace of the Pauli algebra with the Born rule, Peres–Mermin contextuality, and the open question of composite systems.

**A9. Classification: the clock, the Brown invariant, the tenfold way.** LNC-006, LNC-018, LNC-107, LAB-019, LNC-055, LNC-061, LNC-076, LNC-081, LNC-096.
- The Bott clock is a Gauss sum. It is forced, not a convention, and it is blind to null directions.
- The types ℝ/ℂ/ℍ carry the Frobenius–Schur counts +1, 0, −2.
- Wall's ℤ₈ and Kitaev's ten classes are quoted, not computed.
- QC3 asks whether a null has a place in the tenfold way.

Physics ends its algebra with this section, because it is where a calibration against known matter would enter.

**A10. Appendix: root lattices, Weyl groups, codes and finite groups.** LNC-008, LNC-042, LNC-043, LNC-044, LNC-092, LNC-124, LNC-127, LNC-047, LNC-048, LNC-125, LNC-129, LNC-009, LNC-045, LNC-087, LNC-130, LNC-082, LNC-049, LNC-131, LAB-009, LAB-020, LAB-011, LAB-012, LAB-010, INP-079, LNC-046, LNC-128.
No phenomenon is derived here, and LNC-046/128 forbid reading E₁₀ and E₁₁ as spacetimes. Physics knows these objects (U-duality, double groups, moonshine), but the Atlas uses them as finite combinatorics of the labels.

**A11. Appendix: comparisons with no physics home.** LNC-051, LNC-052, LNC-054, LNC-058, LNC-083, LNC-027, LNC-057, LNC-067, LNC-069, LNC-088, LNC-062, LNC-068, LNC-143.
These rows cover the representation type of the cube category, Tian's categorification and Majkić's constructions. LNC-027/057 stay here for now, although a Majorana chain in a hyperbolic basis has a physics reading (C1).

**A12. Readings ("ours").** LNC-022, LNC-104, LNC-053, LNC-094, LNC-116, LNC-126, LNC-132, LNC-074, LNC-095, LNP-003.
These are interpretations. Physics keeps them out of the derivation and shows them as readings.

### Where the Atlas order and the physics order differ

1. **Finite groups and the E_n ladder.** The page opens with the finite groups (LAB-009 to LAB-020) and puts the E_n ladder (cat-top, LNC-042 to 049) in the middle of the chapter. Physics moves both to an appendix (A10).
2. **Radical before signs.** The chapter opens with the radical (cat-first, cat-label0). Physics fixes the exchange signs first: in the Atlas they come late, at cat-cube and cat-more after the E_n ladder (LNC-050/056). Physics then builds the Fock picture and reads the radical afterwards, as the Grassmann sector.
3. **The Fock rows are scattered.** The CAR pair is at cat-twozeros (LNC-024), the ladder at cat-more (LNC-060), and the creation processes and hard-core bosons sit in the Majkić block at the very end (LNC-099/100/142/144). In physics they are the core of the cube category, and A3 gathers them.
4. **States are spread over seven anchors:** cat-first (005), cat-label0 (019), cat-more (060), cat-deadends (065), cat-w-label0 (108), cat-w-moves (122), cat-questions (078). Physics gathers them in A8, after the pairings that define them.
5. **Repeated statements.** The clock is stated four times (LNC-006, 018, 055, 107) and the radical five times (LNC-002, 014, 016/017, 105, 089/101). Physics states each once.
6. **The widget block repeats the chapter.** The widget rows (LNC-101 to 136) restate earlier rows. Physics keeps one row per statement and shows the widget as its picture. The widget copies whose checks ran (LNC-105, 107, 111, 112, 127, 136) should lend that "ran" status to the whole class (§B3).
7. **No F or D rows.** Nothing in the chapter is a field equation or a dynamical statement. Physics would close A3, A6, A7 and A9 with first equations: a Majorana chain, the Weyl equation, Raychaudhuri, a Noether charge (§C).

---

## B. Chains, classes and loops

### B1. Edge census

| relation | count | notes |
|---|---|---|
| `derives` | 200 | 131 point to a theorem, 69 to a row |
| `instance` | 5 | all point to theorems |
| `uses-input` | 1 | LAB-010 → INP-079 |
| `equiv` | 221 entries | 136 distinct pairs |
| `cycle` | 3 pairs | |
| `contradicts` | 2 | LNC-054 → T8 and LNC-083 → T8 |

Two thirds of the derivations go straight from a row to a theorem. The chunk is therefore a star around T2, T3, T10, T4, T5, T9 and T15, with short row-to-row chains; the longest has 4 edges.

### B2. Chains (premise → consequence, longest first)

| # | chain | one phrase |
|---|---|---|
| 1 | T6 → LNC-140 → LNC-099 → LNC-138 → LNC-142 | exact cube signs → occupation patterns as a partial monoid → one additive charge per mode, an interaction U breaks additivity → the least-weight cone is the limit; summed over orderings, creation products give 0 for fermions and n! for hard-core bosons |
| 2 | T2 → LNC-135 → LNC-024 → LNC-070 → LNC-071 (T20 also → LNC-024) | a lone null generates the radical → a paired null is a CAR pair → the horizon page has both kinds → one place that defines a null generator |
| 3 | T2 → LNC-002 → LNC-005 → LNC-078, and LNC-005 → LNC-071 (T15 also → LNC-005) | radical → no state sees it → composite systems and entanglement stay open (QE1/QA5) |
| 4 | T4 → LNC-018 → LNC-040 → LNC-041 | the clock ignores null bits → the mother algebra keeps the clock → Cl is a functor |
| 5 | T10 → LNC-044 → LNC-046 → LNC-074 | Kac types → E₁₀ and E₁₁ are not spacetimes → proposal P4 with its guards |
| 6 | T7 → LNC-057 → LNC-069 → LNC-076 | Tian's algebra = Cl(m,m) in a hyperbolic basis → the DG category was not tested → it stays in the report (P6). Valid only once the back-edge LNC-057 → LNC-069 is dropped (B4) |
| 7 | T3 → LNC-030 → {LNC-077, LNC-097}; T3 → LNC-039 → LNC-123 | a symmetric form exists only for n odd or r = 0 → QA4 on the PGA dual. As labelled, LNC-039 also derives from LNC-077 (B4) |
| 8 | T3 → {LNC-029, LNC-030, LNC-033} → LNC-072 | Nakayama twist, symmetric-form criterion, Hodge against complement → proposal P2 |
| 9 | T4 → LNC-006 → {LAB-019, LNC-047, LNC-095} | the Gauss-sum clock → the Brown invariant (Wood); the 8 of the E series is van der Blij's, not Bott's; the three squares as one sorting (ours) |
| 10 | {T4, T2} → LNC-055 → LNC-081 | the clock is forced, plus Wall's ℤ₈ → QC3. Labelled as a 2-cycle (B4) |
| 11 | T8 → LNC-052 → {LNC-053, LNC-054, LNC-083}; T8 → LNC-058 → LNC-096 | Euler and Tits forms → the label-0 reading, and a tameness "open" that T8 contradicts (B5) |
| 12 | T11 → LNC-059 → LNC-079 | Peres–Mermin grid → is this the polar-space picture? (QE2). Labelled as a 2-cycle |
| 13 | T18 → LNC-021 → {LNC-022, LNC-098} | the normal of a null hypersurface spans the radical → the "label 0" reading and the Carroll lead |
| 14 | {T20, T15, T3} → LNC-060 → {LNC-078, LNC-080} | CAR ladder, Bloch ball and trace → composite states; the CAR → CCR limit |
| 15 | T9 → LNC-087 → LNC-082; T9 → LNC-009 → {LNC-074, LNC-082} | W(E_n) mod 2 = O(q) → only "what does it mean through E₉ … E₁₁" stays open |
| 16 | {T5, T9} → LAB-020 → LAB-009 | S_{n+1} acts by isometries → the groups strip |
| 17 | T1 → {LNC-011, LNC-013} (loop with LNC-012) → LNC-145 | unit, nothing, nilpotent → Majkić's zero is the element 0 |

Chains with one intermediate row:
- T2 → LNC-014 → {LNC-015, LNC-016}
- T2 → LNC-105 → LNC-106
- T2 → LNC-003 → LNC-085
- T2 → LNC-002 → {LNC-004, LNC-084}
- {T2, T4, T5} → LNC-117 → LNC-120
- {T2, T15} → LNC-038 → {LNC-041, LNC-141}
- T6 → LNC-056 → LNC-086
- T7 → LNC-027 → LNC-088
- T18 → LNC-024 → {LNC-025, LNC-133}
- INP-079 → LAB-010

Most chains end in a question, a reading, a proposal or a guard; the others end in an algebraic identity (LNC-041, LNC-142). No chain reaches a field equation or a dynamical statement.

### B3. Classes (`equiv`)

**The raw closure is not usable as it stands.** Taken transitively, the 136 equiv pairs give:
- 5 large components, of 29, 21, 18, 11 and 10 rows;
- 13 smaller classes holding 40 rows;
- 27 rows in no class.

The large components are not single statements. Each is held together by a few multi-statement or reading-list rows, and these are the same rows that the jsonl notes flag as "several results in one row":

| component | rows | rows that hold it together |
|---|---|---|
| halving … Tian | 29 | LNC-117, LNC-115, LNC-119, LNC-116, LNC-094, LNP-003, LNC-053, LNC-058, LNC-010 |
| Frobenius … QA4 | 21 | LNC-004, LNC-109, LNC-112, LNC-113, LNC-114, LNC-039 |
| radical … clock … tenfold way | 18 | LNC-089, LNC-101, LNC-055 |
| states … horizon | 11 | LNC-108, LNC-122 |
| Pauli trace … Majkić v2 | 10 | LNC-060, LNC-100, LNC-144, LNC-062 |

`equiv` was used to mean "overlaps", and overlap is not transitive. Before classes are used to merge texts, split these rows or add a `part-of` relation.

**Cores (true restatements).** In the table, "+" marks a row that belongs only in part. "ran" marks the copy whose check actually ran.

| class | rows | one phrase |
|---|---|---|
| Q1 radical | LNC-002, 014, 016, 017, 105 (ran) | Grassmann ideal; layers C(r,k)·2^{p+q}; super-centre Λ(ℝʳ) |
| Q2 face picture | LNC-015, 102, 106 | J is a face only for r = 1 |
| Q3 grading | LNC-003, 020, 093 | ghost or particle number lifts parity |
| Q4 doubling | LNC-026, 040, 133, 135, 136 (ran) | a Grassmann generator is half of a dropped Witt pair |
| Q5 CAR pair | LNC-024, 134 | two generators of opposite square give c, c† |
| Q6 Berezin form | LNC-028, 111 (ran), +004, +109 | λ is non-degenerate for every signature |
| Q7 Koszul twist | LNC-029, 112 (ran), +004, +109 | Nakayama twist = Koszul sign = supertrace cyclicity |
| Q8 symmetric trace | LNC-030, 064, 090, 110, +112 | an ungraded trace exists iff n is odd or r = 0 |
| Q9 Hodge vs complement | LNC-033, 039, 072, 113, +031, +114 | the Hodge star needs an invertible top blade |
| Q10 torsor | LNC-032, 066, 114 | the Frobenius forms are λ(u·) |
| Q11 QA4 | LNC-077, 097, 123 | does the twist matter for the PGA dual? |
| Q12 states | LNC-005, 019, 065, 122 | no state sees J; λ is not a state |
| Q13 restrict | LNC-038, 118, 122 | quotient by the Grassmann sector |
| Q14 two nulls | LNC-021, 025, 070, 075, +108 | light-cone pair against degenerate horizon |
| Q15 clock | LNC-006, 018, 107 (ran) | Gauss-sum clock, blind to null bits |
| Q16 QC3 | LNC-076, 081, 096, +LNP-004 | a null among the ten classes? |
| Q17 halving | LNC-007, 036, 063, 091 | the even part; fails only for pure Grassmann with r ≥ 3 |
| Q18 join | LNC-035, 117, 120 | composite fermions; Koszul sign = exchange sign |
| Q19 functor | LNC-041, 073, 115, 119 | covariance of Cl |
| Q20 spinors | LNC-037, 121 | Spin⁺(1,3) ≅ SL(2,ℂ) |
| Q21 Fock | LNC-099, 100, 140, 142, 144, +060 | occupation patterns, CAR, number operator |
| Q22 Pauli trace | LNC-034, 060 | trace = top-blade form up to ω; Born rule |
| Q23 Majkić | LNC-062, 068, 137 | v2 is not a Clifford algebra; v3 read on the labels |
| Q24 JW sign | LNC-010, 050, 056 | unique up to gauge |
| Q25 Tian | LNC-027, 057, 061, 067 | a Majorana-type chain in a hyperbolic basis |
| Q26 cube category | LNC-051, 052, 058, +053 | Euler and Tits forms |
| Q27 tameness of kB₃ | LNC-054, 083 | both contradicted by T8 (3) |
| Q28 Tian DG category | LNC-069, 088 | open in the paper; not tested here |
| Q29 E_n form | LNC-008, 042, 043, 044, 092, 124, 127 (ran) | finite, affine, hyperbolic, Lorentzian |
| Q30 why 8 | LNC-047, 048, 125, 129 | van der Blij, not Bott |
| Q31 E_n mod 2 | LAB-009, LNC-009, 045, 087, 130 | W(E_n) → O(q) is onto |
| Q32 null root mod 2 | LNC-049, 131 | the null root δ maps to the label 1…1 |
| Q33 guard | LNC-046, 128 | E₁₀ and E₁₁ are not spacetimes |
| Q34 range | LNC-023, 103 | one statement with two ranges (n ≤ 5 and n ≤ 6) |
| Q35 label-0 reading | LNC-022, 104 | |
| (not a class) | LNC-094, 116, 126, 132, 074, 095, LNP-003 | different readings glued together by list rows |

### B4. Loops

**Declared (`cycle`).** LNC-011 ⟲ LNC-012 ⟲ LNC-013. One, nothing and the nilpotent are defined against each other, and LNC-145 rests on all three.

**Genuine but undeclared.** LNC-135 → LNC-024 → LNC-133 ≡ LNC-135. Paired and unpaired nulls explain each other: a lone null is a pair whose partner was dropped, and a pair is two nulls with uv + vu ≠ 0. This should be marked as a `cycle` set.

**Labelling defects.** These are edge directions in the jsonl. The merge should fix them; the row labels stay as they are.
- Three `derives` 2-cycles: LNC-055 ⇄ LNC-081, LNC-057 ⇄ LNC-069, LNC-059 ⇄ LNC-079. In each pair a result row also carries the sentence of its own question. Keep only the edge question → result.
- LNC-039 (checked) derives from LNC-077 (open), while LNC-123 derives from LNC-039 and LNC-077 ≡ LNC-123. A checked statement then rests on an open one: reverse the edge.
- Three pairs carry `derives` one way and `equiv` the other: LNC-072/033, LNC-099/140, LNC-123/039.

### B5. Contradictions

**As `contradicts` edges.** LNC-054 and LNC-083 call the tameness of kB₃ open. T8 (3) states that kB₃ is tame and derived equivalent to the canonical (3,3,3) algebra (Wang; Ladkani), and questions.json marks QT2 and QB4 answered. The same stale "open" also appears in LNC-010, LNC-058 and LNC-096.

**Recorded in the notes, not as edges:**
- **LNC-055.** "r is not a second coordinate of the class" sits next to "the graded Morita classes form the monoid ℤ₈ × ℕ". The two statements are over different base rings (Λ(ℝʳ) and ℝ), but as worded they read as a contradiction.
- **T18 (a), carried into LNC-021 and LNC-108.** It writes the form as (n−2, 0, 1) and the cell as Cl(0, n−2, 1): two signature conventions in one sentence.
- **Open flags whose questions are marked answered.** LNC-077/097/123 (QA4), LNC-080 (QE3), LNC-081/096 (QC3), LNC-082 (QD1, QT6), LNC-086 (QB2).

### B6. Hubs

**One-way in-degree** (rows resting on the node):

| nodes | rows resting |
|---|---|
| T2 | 22 |
| T3 | 20 |
| T10 | 13 |
| T4 | 11 |
| T5, T9, T15 | 10 each |
| T20 | 7 |
| T1, T6, T7 | 6 each |
| T18 | 5 |
| LNC-099 | 5 |
| T8 | 4 (plus 2 `contradicts`) |
| LNC-002 | 4 |
| LNC-006, LNC-024, LNC-030, LNC-052 | 3 each |
| T11, T12, T14 | 2 each |
| LNC-003, 005, 009, 014, 021, 038, 060, 069, 140 | 2 each |
| T13, T16, T17, T19 | 0 |

**Counting `equiv` edges as well** (rows only): LNC-002 8, LNC-099 8, LNC-030 7, LNC-005 6, LNC-006 6, LNC-008 6, LNC-009 6, LNC-058 5.

**Reading.**
- The hubs of the chunk are:
  - T2 (radical and graded structure);
  - T3 (the Frobenius form);
  - T10 (the E series);
  - T4 (clock and types);
  - then a tie between T5, T9 and T15 (halving, E_n mod 2, states).
- Among the rows, almost every path passes through LNC-002 (the radical) or LNC-099 (occupation patterns).

### B7. Leaves

**Counts.**
- 110 of the 156 rows have nothing resting on them.
- The other 46 are rested on: LAB-020, INP-079, LNC-002, 003, 005, 006, 008, 009, 011, 012, 013, 014, 018, 021, 024, 027, 029, 030, 033, 035, 036, 038, 039, 040, 044, 046, 052, 055, 056, 057, 058, 059, 060, 062, 069, 070, 077, 079, 081, 087, 099, 105, 117, 135, 138, 140.

**19 leaves are also in no class:** LAB-010, LAB-011, LAB-012, LAB-019, LNC-001, LNC-071, LNC-078, LNC-080, LNC-082, LNC-084, LNC-085, LNC-086, LNC-098, LNC-139, LNC-141, LNC-143, LNC-145, LNP-001, LNP-002.

**3 rows have no edge at all:** LNC-001, LNP-001 and LNP-002. These are scope and provenance statements; in V2 they belong in the chapter's drawer.

**The physics content is terminal.** Every row that carries a physics identification is either a leaf or rested on only by a question or a proposal:
- LNC-037/121 (SL(2,ℂ) spinors);
- LNC-120 (the exchange sign);
- LNC-144 (Fock creation processes);
- LNC-034 (Pauli trace and Born rule);
- LNC-059 (Peres–Mermin);
- LNC-113, and LNC-033, which only proposal P2 rests on (the Hodge star);
- LNC-098/108 (the horizon);
- LNC-061/076 (the tenfold way).

Nothing downstream uses them, because the chunk has no F or D row. §C lists what would.

---

## C. Missing pieces

These are standard results of physics that the Atlas does not state, ordered by consequence (most consequential first). Each item gives the statement, the source (author and title only), the rows it would link, and whether the engine could check it.

The three kinds the persona file requires:
- **Making a one-way chain two-way:** C1–C7, C13, C16, C18.
- **Closing a gap between a field equation and its solution:** C1, C4, C9, C11, C13.
- **A phenomenon the rows approach but do not derive:** named in each item.

**C1. Kitaev's Majorana chain, unpaired end modes, and the Fidkowski–Kitaev ℤ₈.**
- **Statement.** In the dimerised chain H = i t Σ_j γ_{2j}γ_{2j+1} (Majoranas, γ² = 1), the end operators γ_1 and γ_{2N} drop out of H, so the ground state is twofold degenerate. Kitaev's Majorana number, the sign of a Pfaffian, distinguishes this phase. With interactions, the ℤ classification of such chains in class BDI collapses to ℤ₈: eight chains can be gapped together. This is the ℤ₈ of the Brown invariant, of Pin⁻ bordism and of the clock.
- **Sources.**
  - A. Yu. Kitaev, "Unpaired Majorana fermions in quantum wires".
  - L. Fidkowski and A. Kitaev, "Effects of interactions on the topological classification of free fermion systems".
  - A. Kapustin, R. Thorngren, A. Turzillo and Z. Wang, "Fermionic symmetry protected topological phases and cobordisms".
- **Links.**
  - LNC-027, 057, 088: Tian's "half of the last pair whose partner is missing" is the dangling end of a dimerised chain.
  - LNC-133/135: the lone partner.
  - LNC-050/056: the Jordan–Wigner sign.
  - LNC-055, 076, 081, 096: the tenfold way and QC3. The answer the chain suggests is that the end mode is an unpaired Majorana of square +1, not a null; the null appears only as the missing partner in a hyperbolic basis.
  - LAB-019: Brown and Arf–Brown–Kervaire.
  - LNC-006/018: the clock.
- **Check: yes.** The k dangling Majoranas at one end generate Cl(k,0). For k = 1 … 8 the engine can test whether some real, parity-even (T-invariant) Hamiltonian on the irreducible module has a non-degenerate ground state; the answer should be yes only at k = 8. Both dimerisations can be diagonalised exactly for N ≤ 8.
- **Phenomenon:** Majorana zero modes of topological superconducting wires.
- **Kind:** two-way (clock ↔ end-mode count); field equation ↔ solution (lattice Hamiltonian ↔ ground state).

**C2. The Altland–Zirnbauer classes at the clock values, with T² and C² as input.**
- **Statement.** The ten symmetry classes of free-fermion Hamiltonians are fixed by T² and C² (each ±1 or absent) together with the chiral symmetry S. The eight real classes AI, BDI, D, DIII, AII, CII, C, CI occupy successive values of the real Bott clock, and A and AIII the complex one. Kitaev obtains the periodic table by asking which Clifford algebra the symmetry operators and the Hamiltonian generate (the extension problem Cl(p,q) → Cl(p,q+1)).
- **Sources.**
  - A. Altland and M. R. Zirnbauer, "Nonstandard symmetry classes in mesoscopic normal-superconducting hybrid structures".
  - A. Kitaev, "Periodic table for topological insulators and superconductors".
  - S. Ryu, A. P. Schnyder, A. Furusaki and A. W. W. Ludwig, "Topological insulators and superconductors: tenfold way and dimensional hierarchy".
- **Links.** LNC-055, 076, 081, 096, LNP-004 (the quote and QC3); LNC-006/018/107 (the clock); LNC-061 (Baez). It also needs a new INP row for (T², C²), which the rows use without recording.
- **Check: partly.** For each pair (T², C²), the engine can build the Clifford algebra generated by the symmetry generators and J = i, and read off its clock. That turns "quoted" into "computed". The homotopy of the classifying spaces stays recalled.
- **Phenomenon:** topological insulators and superconductors.
- **Kind:** two-way (the quote LNC-076 becomes a computed match).

**C3. Carroll boosts are null translations.**
- **Statement.** A null hypersurface carries a Carroll structure: a degenerate metric whose kernel is spanned by the null generator ξ. Its homogeneous Carroll algebra consists of rotations and Carroll boosts, with [K_i, K_j] = 0, and is iso(n−2). That is exactly the bivector algebra so(n−2) ⋉ ℝ^{n−2} of the tangent algebra Cl(0,n−2,1):
  - the bivectors e_i e_0 are T17's "translation" kind of unipotent bivector;
  - the rotor exp(a e_i e_0) acts as e_i ↦ e_i + 2a e_0 with e_0 fixed, which is the Carroll boost;
  - the same algebra gives the translations (motors) of PGA Cl(n−2,0,1).

  So the two "label 0" occurrences, step 11 and step 13, have the same Lie algebra, and in either signature convention.
- **Sources.**
  - J.-M. Lévy-Leblond, "Une nouvelle limite non-relativiste du groupe de Poincaré".
  - C. Duval, G. W. Gibbons, P. A. Horváthy and P.-M. Zhang, "Carroll versus Newton and Galilei: two dual non-Einsteinian concepts of time".
  - L. Donnay and C. Marteau, "Carrollian physics at the black hole horizon".
- **Links.**
  - LNC-021 and LNC-022: the "ours" reading "one object, label 0" would become a standard statement.
  - LNC-025, 070, 098 (the Carroll question), 108.
  - T17 (b), T18 (a).
- **Check: yes.** Compute the bivector Lie algebras of Cl(0,2,1) and Cl(2,0,1), show that both are iso(2), and verify the action of the rotor exactly.
- **Phenomenon:** Carrollian (frozen) dynamics on horizons, the membrane picture.
- **Kind:** two-way (a reading turned into a theorem, linking steps 11 and 13).

**C4. Rigging and focusing: from the null hypersurface to the horizon.**
- **Statement.** A null hypersurface is ruled by null geodesics with tangent k. A transverse null "rigging" vector l with k·l = −1 restores the partner that the tangent algebra lacks: the ambient pair (k, l) is the paired null of Cl(1,1). The expansion of the generators obeys Raychaudhuri's equation, dθ/dλ = −θ²/(n−2) − σ² − R_ab k^a k^b. Through Einstein's equation the null energy condition makes the generators focus. A Killing horizon has θ = σ = 0 and ∇_k k = κk, and the area theorem follows.
- **Sources.**
  - A. K. Raychaudhuri, "Relativistic cosmology. I".
  - E. Gourgoulhon and J. L. Jaramillo, "A 3+1 perspective on null hypersurfaces and isolated horizons".
  - S. W. Hawking, "Gravitational radiation from colliding black holes".
- **Links.**
  - The pointwise horizon algebra: LNC-021, 025, 070, 098, 108.
  - The paired null: LNC-024/134.
  - The mother algebra, whose partner f⁺ + f⁻ plays the role of the rigging: LNC-026/040/136.
  - Outside the chunk: the Atlas's horizon and surface-gravity rows (T18 (c), the `sol` rows).
- **Check: partly.** On the engine's Kerr–Schild frames (Schwarzschild, Kerr), k, l, θ = 0 and κ on the horizon can be computed. The area theorem is global and cannot be.
- **Phenomenon:** focusing and black-hole horizons.
- **Kind:** field equation ↔ solution (Einstein plus the null energy condition → horizon); two-way (unpaired ↔ paired null; it closes the loop of B4).

**C5. Kramers degeneracy and Dyson's threefold way.**
- **Statement.** An antiunitary T with T² = −1 forces every level to be at least doubly degenerate (Kramers). Dyson showed that the commutant of the symmetries is ℝ, ℂ or ℍ, and that this selects the orthogonal, unitary or symplectic ensemble of random Hamiltonians (level-repulsion exponent β = 1, 2, 4).
- **Sources.**
  - H. A. Kramers, "Théorie générale de la rotation paramagnétique dans les cristaux".
  - F. J. Dyson, "The threefold way. Algebraic structure of symmetry groups and ensembles in quantum mechanics".
- **Links.**
  - LNC-006, 018, 107: the type as the sign of Σ e_a², with Frobenius–Schur counts +1, 0, −2.
  - LNC-055: five ungraded types. LNC-061: Baez.
  - LNC-076/081: the T² input. LAB-009: double groups.
- **Check: yes.** For each cell, build the commutant of the minimal module, exhibit the ℍ-structure for clock values 4, 5, 6, and check that every operator commuting with it has doubly degenerate eigenvalues. Random-matrix statistics cannot be checked.
- **Phenomenon:** Kramers doublets and level statistics.
- **Kind:** two-way (the type table becomes observable).

**C6. Fermionic superselection and composite states.**
- **Statement.** Physical states and observables of fermions are parity-even (univalence superselection). On a graded tensor product A ⊗̂ B, two states extend to a product state when at least one of them is even. The state of a subsystem is the restriction to its graded subalgebra, so fermionic entanglement must be defined under the parity rule.
- **Sources.**
  - G. C. Wick, A. S. Wightman and E. P. Wigner, "The intrinsic parity of elementary particles".
  - H. Araki and H. Moriya, "Joint extension of states of subsystems for a CAR system".
  - M.-C. Bañuls, J. I. Cirac and M. M. Wolf, "Entanglement in fermionic systems".
- **Links.** LNC-035/117/120 (join), LNC-038/118/122 (restrict), LNC-005/019 (states), LNC-078 (QE1/QA5), and QT4.
- **Check: yes.** On Cl(p,q) ⊗̂ Cl(p′,q′) with n ≤ 6:
  - test positivity of product functionals, and show that it can fail when both factors have odd parts;
  - compute reduced states;
  - check whether the radical of a product with null generators is seen (QT4).
- **Phenomenon:** entanglement of fermions.
- **Kind:** two-way (restrict, until now one-way, becomes subsystem ↔ composite).

**C7. The Jordan–Wigner isomorphism between the graded and the ungraded composite.**
- **Statement.** n fermionic modes and n qubits have the same algebra: Cl(n,n) = Cl(1,1)^{⊗̂n} ≅ M₂(ℝ)^{⊗n}, via c_j = (Π_{k<j} Z_k) σ_j⁻. The string Π Z_k is the non-local price of turning the graded product into the ordinary one. Fermion bilinears stay local only between neighbours in the chosen order.
- **Sources.**
  - P. Jordan and E. Wigner, "Über das Paulische Äquivalenzverbot".
  - E. Lieb, T. Schultz and D. Mattis, "Two soluble models of an antiferromagnetic chain".
- **Links.** LNC-035/117/120 (join = graded ⊗), LNC-050/056/010 (the string, unique up to gauge), LNC-144 (Cl(n,n) = End Λ), LNC-100/142 (hard-core bosons are qubits).
- **Check: yes.** Map the generators and verify all relations exactly for n ≤ 6.
- **Kind:** two-way (join ↔ the Jordan–Wigner sign).

**C8. The top-blade form as the Berezin integral: Gaussians give Pfaffians.**
- **Statement.** λ is the Berezin integral ∫dθ_n…dθ_1. On the Grassmann cell, the top coefficient of exp(Σ_{i<j} A_ij θ_iθ_j) is Pf(A). With sources the same integral gives Wick's theorem. Free-fermion partition functions and Kitaev's ℤ₂ Majorana number are values of this integral.
- **Sources.**
  - F. A. Berezin, "The Method of Second Quantization".
  - J. Zinn-Justin, "Quantum Field Theory and Critical Phenomena".
  - A. Yu. Kitaev (as in C1).
- **Links.** LNC-004, 028, 111 (λ), LNC-029/112 (Koszul), LNC-031/113 (the trace is blind), LNC-065 (λ is not a state), T16 (Dirac determinants), T17 (c) (Pf(B) at n = 4), C1.
- **Check: yes.** Compute λ(exp B) on Cl(0,0,n) against Pf(A) exactly for n ≤ 10. In other cells, use the wedge exponential, because exp B there uses squares.
- **Phenomenon:** fermionic path integrals and Pfaffian invariants.

**C9. Maxwell's equations, the duality rotation, and their degenerate limits.**
- **Statement.** In the spacetime algebra Maxwell's equations read ∇F = J, and the Hodge star on F is multiplication by the pseudoscalar I, with I² = −1 in Cl(1,3). F ↦ e^{Iθ}F is therefore the electric–magnetic duality of the source-free equations, and it rotates their plane-wave solutions. When the metric degenerates (c → ∞ or c → 0) no invertible top blade is left, and electromagnetism splits into two inequivalent limits, the electric and magnetic Galilean or Carrollian theories.
- **Sources.**
  - D. Hestenes, "Space-Time Algebra".
  - M. Le Bellac and J.-M. Lévy-Leblond, "Galilean electromagnetism".
  - Duval, Gibbons, Horváthy and Zhang (as in C3).
- **Links.** LNC-033, 113, 072 (Hodge needs r = 0), LNC-039 (the complement dual), LNC-077/097/123 (QA4), LNC-021/098 (Carroll).
- **Check: partly.** The engine can verify I² = −1, show that e^{Iθ} commutes with ∇ on bivector fields, and show that e_F² = 0 once a generator is null. Reading the two limits as physics remains a reading of the contraction.
- **Phenomenon:** light; electric–magnetic duality.
- **Kind:** field equation ↔ solution.

**C10. Spin and statistics: the 2π rotor and the exchange sign.**
- **Statement.** A rotation by 2π acts as −1 on spinors (exp(π e₁₂) = −1). The spin–statistics theorem says that fields of half-integer spin anticommute: the Koszul sign of the graded tensor product is the 2π sign of the spinor representation. Finkelstein and Rubinstein give a topological version.
- **Sources.**
  - W. Pauli, "The connection between spin and statistics".
  - R. F. Streater and A. S. Wightman, "PCT, Spin and Statistics, and All That".
  - D. Finkelstein and J. Rubinstein, "Connection between spin, statistics, and kinks".
- **Links.** LNC-037/121 (SL(2,ℂ)), LNC-120 (Koszul = exchange), LNC-035/117, LNC-050/056, LNC-142 (the fermionic sum over orderings vanishes).
- **Check: partly.** The sign of the 2π rotor and the double cover can be computed exactly. The theorem itself needs locality and positive energy.
- **Phenomenon:** the fermion statistics of electrons (Pauli exclusion).
- **Kind:** two-way (spinor rows ↔ statistics rows).

**C11. Weyl spinors, chirality and the Weyl equation.**
- **Statement.** The complexified even part, Cl⁰(1,3) ⊗ ℂ ≅ M₂(ℂ) ⊕ M₂(ℂ), has two inequivalent irreducible modules: the left- and right-handed Weyl spinors, which parity exchanges. The Weyl equation σ̄^μ∂_μψ_L = 0 has plane-wave solutions of definite helicity, and a mass term couples ψ_L to ψ_R in the Dirac equation.
- **Sources.**
  - H. Weyl, "Elektron und Gravitation. I".
  - R. Penrose and W. Rindler, "Spinors and Space-Time, Vol. 1".
  - M. E. Peskin and D. V. Schroeder, "An Introduction to Quantum Field Theory".
- **Links.** LNC-037, 121, LNC-007/036 (halving), T16 (symbol determinants), LNP-004 (chirality is open for the Baez embeddings).
- **Check: yes.** Build the module of Cl⁰(1,3), check det(σ·k) = k² (as in T16), and compute the helicity ±½ for a null k.
- **Phenomenon:** helicity of the electron and the neutrino.
- **Kind:** field equation ↔ solution.

**C12. Null vectors as spinor bilinears.**
- **Statement.** Every future null vector is k = λλ̄, a rank-one hermitian 2×2 matrix. The null directions therefore form the celestial sphere ℂP¹, on which SL(2,ℂ) acts by Möbius maps. A null tetrad is built from two spinors λ, μ with ⟨λμ⟩ ≠ 0, and the pair λλ̄, μμ̄ is the paired null of the (t,r) plane.
- **Sources.**
  - R. Penrose and W. Rindler, "Spinors and Space-Time, Vol. 1".
  - E. T. Newman and R. Penrose, "An approach to gravitational radiation by a method of spin coefficients".
- **Links.** LNC-037/121 (SL(2,ℂ)) ↔ LNC-024/025/070 (paired nulls, the horizon vector); LNC-021 (the generator); C4 (the rigging is the second spinor).
- **Check: yes.** Map the vectors of Cl(1,3) to hermitian 2×2 matrices through the even part; check det = k² and that the rank is 1 exactly when k is null.
- **Phenomenon:** massless momenta and the light cone.
- **Kind:** two-way (spinors ↔ null vectors).

**C13. A grading is a conserved charge only once there is a Hamiltonian (Noether; the Hubbard U).**
- **Statement.** A ℤ-grading with generator N is conserved by e^{−iHt} if and only if [H, N] = 0. For lattice fermions:
  - H = −t Σ c_i†c_j + U Σ n_i n_j conserves N, a U(1) symmetry;
  - pairing terms Δ c_i c_j break it down to the parity ℤ₂, which is the BdG and Kitaev case;
  - interactions break the additivity of one-body charges but not the conservation of N.
- **Sources.**
  - E. Noether, "Invariante Variationsprobleme".
  - J. Hubbard, "Electron correlations in narrow energy bands".
- **Links.** LNC-003, 020, 093 ("nothing is conserved: that would need a Hamiltonian"), LNC-085 (QA3), LNC-138 (U breaks additivity), LNC-144 ([N, A] = |T∖S|A), LNC-060 ([N_i, a_j]).
- **Check: yes.** Build H on Cl(n,n) = End Λ and compute [H, N] and [H, (−1)^N] for n ≤ 6.
- **Phenomenon:** conservation of particle number and charge; superconducting pairing.
- **Kind:** field equation ↔ solution (this would be the chapter's first D row); two-way (grading ↔ conservation law).

**C14. The Pauli group as a symplectic polar space: stabilizers and the Clifford group.**
- **Statement.** Modulo phases, the n-qubit Pauli group is 𝔽₂^{2n}, with the commutator as symplectic form:
  - maximal commuting sets are maximal totally isotropic subspaces, which are the stabilizer groups;
  - there are 2^n Π_{k=1}^{n}(2^k + 1) stabilizer states;
  - the Clifford group modulo the Paulis is Sp(2n, 2), generated by transvections.

  The Atlas's label quadric is a quadratic refinement of this symplectic form. For n = 2 its singular points (square +1) form the 3×3 Peres–Mermin grid inside the 15-point generalized quadrangle W(3,2).
- **Sources.**
  - D. Gottesman, "Stabilizer codes and quantum error correction".
  - A. R. Calderbank, E. M. Rains, P. W. Shor and N. J. A. Sloane, "Quantum error correction via codes over GF(4)".
  - M. Saniga and M. Planat, "Multiple qubits as symplectic polar spaces of order two".
- **Links.** LNC-059, 079 (QE2), LNC-024/144 (Cl(n,n) as n modes), T11 (quadric counts), T12 (transvections), LAB-011 ("finite shadow of a translation"), LAB-009/010 (the Golay code, which gives a quantum code by the CSS construction).
- **Check: yes.** Count points, lines and maximal isotropic subspaces of both forms exactly for n ≤ 4 (for n = 2: 60 stabilizer states).
- **Phenomenon:** contextuality and quantum error correction.

**C15. The Witten index: super-dimension 0 is Tr(−1)^F.**
- **Statement.** The Witten index Tr(−1)^F counts bosonic minus fermionic states. Each fermionic mode pairs |0⟩ with |1⟩, so Λ(ℝⁿ) has index 0, which is the super-dimension of T20 (d). In supersymmetric quantum mechanics (H = {Q, Q†}) only zero-energy states contribute, so the index is invariant under deformations.
- **Source.** E. Witten, "Constraints on supersymmetry breaking".
- **Links.** LNC-060, 080 (QE3), LNC-029/112 (cyclicity of the supertrace), LNC-030/110 (a supertrace exists for every signature), T20 (d).
- **Check: yes.** Compute str 1 = Σ_a (−1)^{|a|} = 0, and the index of a small supersymmetric Hamiltonian under deformation, for n ≤ 6.
- **Phenomenon:** supersymmetric pairing of states.

**C16. From the fermionic to the bosonic ladder (Wielandt; Holstein–Primakoff).**
- **Statement.** [a, a†] = 1 has no bounded solution, in particular no finite-dimensional one: taking a trace would give 0 = dim. Bosons arise from finite systems only in a limit. Collective spin or pair operators of N modes satisfy su(2), and as the spin S grows, J⁻/√(2S) → a contracts su(2) to the Heisenberg algebra.
- **Sources.**
  - H. Wielandt, "Über die Unbeschränktheit der Operatoren der Quantenmechanik".
  - T. Holstein and H. Primakoff, "Field dependence of the intrinsic domain magnetization of a ferromagnet".
  - E. Inönü and E. P. Wigner, "On the contraction of groups and their representations".
- **Links.** LNC-080 (QE3), LNC-060, LNC-144, T20 (d) and (f): the bivectors of Cl(m,m) are so(m,m), which contains the collective su(2).
- **Check: partly.** For m ≤ 6, build the collective su(2) from bilinears on Cl(m,m) and show [J⁻, J⁺]/2S → 1 on the lowest states as m grows. The limit itself is analytic.
- **Kind:** two-way (it closes the one-way statement CAR versus CCR).

**C17. Lieb's flux phase: the bit-rule sign as π flux.**
- **Statement.** For half-filled free fermions hopping on a planar bipartite lattice, π flux through every square plaquette minimises the ground-state energy (Lieb). The bit-rule signs are a π-flux ℤ₂ gauge field on the n-cube. The signed hopping D = Σ L_{e_i} has the flat spectrum ±√n (T19 (4)), and half filling gives −2^{n−1}√n, below the zero-flux value: −2√2 against −2 at n = 2, −4√3 against −6 at n = 3. Lieb's theorem is planar, so on the cube the comparison is a computation.
- **Source.** E. H. Lieb, "Flux phase of the half-filled band".
- **Links.** LNC-050, 056 (π flux on every face, unique up to gauge), LNC-144 (flux −1 per face), LNC-140 (exactness), T19 (4).
- **Check: yes.** Compare the half-filled energies of both fluxes exactly from the two known spectra, for any n.
- **Phenomenon:** a gauge phenomenon (ℤ₂ flux; flux phases of lattice fermions).

**C18. The McKay correspondence: the marks of Ẽ₈ are the irreps of the binary icosahedral group.**
- **Statement.** Take a finite subgroup Γ ⊂ SU(2). Under tensoring with its 2-dimensional spinor representation, the irreducible representations of Γ form an affine ADE diagram, and the marks of the null root are the dimensions of the irreps. For Γ = 2.A₅ this is Ẽ₈, with marks 1, 2, 3, 4, 5, 6, 4, 2, 3 (sum 30), the same multiset as the Atlas's (3; 2,4,6,5,4,3,2,1). For 2.A₄ it is Ẽ₆. In physics the same graph is the quiver gauge theory of D-branes at ℂ²/Γ.
- **Sources.**
  - J. McKay, "Graphs, singularities, and finite groups".
  - M. R. Douglas and G. Moore, "D-branes, quivers, and ALE instantons".
- **Links.** LAB-009 (the Pin lifts 2.A₄ and 2.A₅) ↔ LNC-043 (the null root of E₉ = Ẽ₈), LNC-049/131 (the null root mod 2 is the label 1…1), LNC-008/042.
- **Check: yes.** Build 2.A₅, the 120 unit quaternions in the even part of Cl(3,0); compute its character table and the McKay graph of the spinor representation; compare with the marks.
- **Kind:** two-way (LAB-009 ↔ LNC-043). No phenomenon (its physics home is string theory).

**C19. Gibbs states and Fermi–Dirac occupations on the labels.**
- **Statement.** For H = Σ ε_i n_i the Gibbs state e^{−β(H−μN)}/Z is a state in the sense of T15. Its partition function is Z = Π(1 + e^{−β(ε_i−μ)}) and its occupations are ⟨n_i⟩ = 1/(e^{β(ε_i−μ)} + 1). Hard-core bosons on decoupled sites have the same occupations; the difference in statistics appears only with hopping, through the Jordan–Wigner strings.
- **Sources.**
  - E. Fermi, "Sulla quantizzazione del gas perfetto monoatomico".
  - P. A. M. Dirac, "On the theory of quantum mechanics".
  - R. Haag, N. M. Hugenholtz and M. Winnink, "On the equilibrium states in quantum statistical mechanics".
- **Links.** LNC-099/100 (occupation patterns; the popcount is N), LNC-142 (hard-core bosons against fermions), LNC-144, LNC-005/019 (states), LNC-060 (density elements).
- **Check: yes.** Exact on the labels for n ≤ 8.
- **Phenomenon:** Fermi–Dirac statistics. It would be the first O-stage observable for the Fock rows.

**C20. BRST and the quartet mechanism: paired nulls cancel, unpaired nulls are invisible.**
- **Statement.** A nilpotent BRST charge Q (Q² = 0) defines the physical states as ker Q / im Q. Ghosts and unphysical gauge modes come in quartets of zero-norm states that cancel from the physical space (Kugo–Ojima), and ghost (Grassmann) variables have zero expectation in physical states.
- **Sources.**
  - C. Becchi, A. Rouet and R. Stora, "Renormalization of gauge theories".
  - I. V. Tyutin, "Gauge invariance in field theory and statistical physics in operator formalism".
  - T. Kugo and I. Ojima, "Local covariant operator formalism of non-abelian gauge theories and quark confinement problem".
- **Links.** LNC-056/140 (the Koszul boundary squares to 0 and is exact), LNC-003/020/093 (the ghost-number grading), LNC-024/134 (paired nulls as zero-norm pairs), LNC-005/019/065 (states vanish on J), LNC-135.
- **Check: partly.** The Koszul complex, its exactness and its layers are already computed (T6 (b)). The gauge-theory content is not on the engine.
- **Phenomenon:** a gauge phenomenon (ghost decoupling).

**C21. Bethe's double groups.**
- **Statement.** Half-integer angular momentum in a crystal field transforms under the double cover of the point group inside SU(2) = Spin(3), for example 2.A₄, 2.A₅ or the binary octahedral group. The extra spinor irreps give the Kramers-degenerate splittings of ions with an odd number of electrons.
- **Source.** H. Bethe, "Termaufspaltung in Kristallen".
- **Links.** LAB-009 (the Pin lifts), LNC-121 (Spin), C5 (Kramers), C18 (McKay).
- **Check: yes.** The double groups are subgroups of the even part of Cl(3,0); their characters and the splittings of j = ½ and 3/2 are exact.
- **Phenomenon:** crystal-field splitting of spin-½ ions.

**C22. Signature conventions as an input row (the lens of conventions).**
- **Statement.** The physics does not depend on the convention (+,−,−,−) or (−,+,+,+), but the algebras do:
  - Cl(1,3) ≅ M₂(ℍ) while Cl(3,1) ≅ M₄(ℝ), so real (Majorana) spinors in the γ^μγ^ν + γ^νγ^μ = 2η^{μν} convention exist for only one sign;
  - the even parts agree, Cl⁰(1,3) ≅ Cl⁰(3,1) ≅ M₂(ℂ), so Lorentz spinors are convention-free;
  - the tangent algebra of a null hypersurface is Cl(0,n−2,1) in the time-positive convention and Cl(n−2,0,1) in the space-positive one (C3 shows that the Carroll algebra is the same in both).

  This is the "researcher's lens" of the project: one invariant content read through two conventions.
- **Source.** C. W. Misner, K. S. Thorne and J. A. Wheeler, "Gravitation" (its table of sign conventions).
- **Links.** LNC-021, 108 (T18 (a) mixes the two conventions), LNC-037/121, LNC-070. A new INP row (`i-time`) should record the convention.
- **Check: yes.** Clock and type of both cells and of both even parts, computed exactly.

**C23. The E series in physics (a pointer only; the rows deliberately stay out).**
- **Statement.**
  - Reducing eleven-dimensional supergravity on a torus to 11 − n dimensions gives the global symmetry E_{n(n)} for n ≤ 8, and the affine E₉ in two dimensions (the analogue of the Geroch group).
  - Near a spacelike singularity the BKL oscillations become a billiard in the Weyl chamber of E₁₀, chaotic because E₁₀ is hyperbolic.
  - Separately, the transverse-field Ising chain, which is a Majorana chain by Jordan–Wigner, has eight particles with E₈ mass ratios (m₂/m₁ = 2cos(π/5)) once a longitudinal field is added; this was observed in CoNb₂O₆.
- **Sources.**
  - E. Cremmer and B. Julia, "The SO(8) supergravity".
  - V. A. Belinsky, I. M. Khalatnikov and E. M. Lifshitz, "Oscillatory approach to a singular point in the relativistic cosmology".
  - T. Damour, M. Henneaux and H. Nicolai, "Cosmological billiards".
  - A. B. Zamolodchikov, "Integrals of motion and S-matrix of the (scaled) T = T_c Ising model with magnetic field".
  - R. Coldea et al., "Quantum criticality in an Ising chain: experimental evidence for emergent E₈ symmetry".
- **Links.** LNC-008/042/044 ("hyperbolic only at 10"), LNC-043 (affine null root), LNC-046/128 (the guards, which must stay), LNC-050 (Jordan–Wigner).
- **Check: partly.** Hyperbolicity is already T10 (3), and the Perron–Frobenius vector of the E₈ diagram is exact on the engine. The billiard dynamics and the field theory cannot be checked.
- **Phenomena:** BKL cosmological chaos; the E₈ spectrum of a quantum magnet.

