# Chunk C (groups strip LAB-009…020 and INP-079; category lens LNC-001…145; lenses strip LNP-001…004): the mathematician's labelling

156 rows labelled in `math_C.jsonl`. Kinds: 50 theorem, 19 question, 15 range, 13 reading, 11 meta, 10 lemma, 9 example, 8 counterexample, 7 reduction, 5 definition, 4 computation, 3 construction, 1 pointer, 1 classification. Relations: 207 `derives`, 45 `equiv`, 12 `instance`, 2 `contradicts`, 0 `uses-input`, 0 `cycle`.

Conventions I used, so that the chunk reads consistently:

- The chunk states most results three or four times: a research summary (LNC-002…010, 055…060), the step rows (LNC-011…054), the widget rows (LNC-101…136, research and learner text) and the honest list (LNC-089…098). The **step rows are the atomic statements and the hubs**; summaries `derive` from their parts; same-content restatements are `equiv`.
- Readings that are credit lines ("… is ours") carry their content notions plus `i-meta`. Pure scope, check-range and page-plan rows are `["i-meta"]` / `meta`.
- The rows filed as **dead ends (LNC-063…068) are proved negative results**, so I gave them kind `counterexample`, not `dead-end`. SCHEME §6 maps `dead-end` to the badge `open`, which would mark settled theorems as open. Only LNC-069 (Tian's untested DG category) is open, and it is a `pointer`.
- A question row that a theorem or questions.json answers gets a note. `contradicts` is used only where a row *asserts* that something is open and a theorem asserts the answer (LNC-010, LNC-054 against T8).

---

## A. How mathematics would organise these rows

Mathematics would start with the quadratic space and its Witt decomposition, apply the Clifford functor, and read everything else off it: the radical, the moves, the Frobenius structure, the states, the clock. The E_n rungs and the cube category are two separate appendices, lattice theory and representation theory of incidence algebras. Neither is category theory. Only LNC-041, 099…100 and 137…145 are category theory proper.

### A.0 Definitions and conventions (some hide a choice)

- **LNC-011** the unit e_∅ (it conflates the unit element with the monoidal unit Cl(0,0,0) = ℝ); **LNC-012** no zero element or zero object is used; **LNC-013** label 0 = a nilpotent generator, Cl(0,0,1) = dual numbers.
- **LNC-070** the two meanings of "null" (isotropic in a hyperbolic pair vs radical). This is the Witt decomposition, which the chunk never names (C.2).
- **LNC-021, 025, 108**: the tangent algebra Cl(0,n−2,1) of a null hypersurface uses the time-positive convention (`i-time`), a hidden choice.
- **LNC-051** the cube category kB_n; **LNC-099** the labels as a partial monoid with translation category B_n.
- Used and never defined in the chunk: radical of a quadratic form, hyperbolic pair, state for an involution, graded (super-)centre, Euler and Tits forms, universal grading group (C.20).

### A.1 Algebra: the structure of Cl(p,q,r)

1. **Splitting and radical.** T2 → LNC-135 (radical vectors generate J) → LNC-014 (J = Jacobson radical, Cl/J = Cl(p,q)) → LNC-016 (Loewy layers) → LNC-017 (super-centre, graded-simple iff r = 0). Picture: LNC-015 ≡ 102 ≡ 106. Summaries: LNC-002 ≡ 105, LNC-089 ≡ 101. Check scope: LNC-023, 103 (meta). *Order differs:* the splitting Cl(p,q) ⊗̂ Λ(ℝ^r) (T2 (1)) comes first in mathematics. On the page it appears only as the "join" move (LNC-035), after the radical.
2. **Gradings.** LNC-003 ≡ 020 ≡ 093 (universal group ℤ₂^{p+q} × ℤ^r among label-homogeneous gradings; M₂(ℝ) as counterexample); question LNC-085.
3. **The moves as one functor.** LNC-041 (Cl is a symmetric monoidal functor) first; then join LNC-035 (≡ the join part of 117; physics LNC-120), halve LNC-036 ≡ 007 ≡ 091 with its negative LNC-063 (physics LNC-037 ≡ 121), restrict and quotient LNC-038 ≡ 118 (physics LNC-122), mother LNC-026 ≡ 040 ≡ 136 (with LNC-133). *Order differs:* the page goes move by move and only at the end says they are functorial (LNC-041, 073, 119).
4. **Frobenius structure.** LNC-028 ≡ 111 (λ is Frobenius for every (p,q,r)) → LNC-029 (Nakayama = id or α) → LNC-030 ≡ 110 ≡ 064 (symmetric iff n odd or r = 0) → LNC-090. In parallel: LNC-031 (ranks) → LNC-033 (Hodge star only for r = 0) → LNC-113; LNC-032 ≡ 066 (torsor) → LNC-034 (Cl(3,0) example); LNC-039 ≡ 114 (A ≅ A*). Compounds: LNC-004, 109, 112. Questions: LNC-077 ≡ 097 ≡ 123 (QA4).
5. **States.** LNC-019 ≡ 005 (states vanish on J), LNC-122, LNC-108; the negative LNC-065 (λ is never a state); LNC-060 (Bloch ball, trace = λ(ω·), CAR and super-dimension 0); questions LNC-078 (QA5/QE1) and LNC-080 (QE3).
6. **Clock and Brauer–Wall.** LNC-018 ≡ 006 ≡ 107 (the clock of a degenerate cell is the clock of its quotient and of its mother, and is forced); LAB-019 (classification of (V,Q,π) by n and the clock, via Wood); LNC-055 (Morita monoid ℤ₈ × ℕ, Wall recalled, Hochschild range, Kitaev quoted). Questions: LNC-081 ≡ 076 ≡ 096 (QC3). Reading: LNC-095.
7. **Paired vs unpaired nulls.** LNC-024 ≡ 134 (Cl(1,1)), LNC-135, LNC-133, LNC-025, LNC-021; Tian: LNC-027 ≡ 067, LNC-057, questions LNC-088, LNC-069 (pointer).

### A.2 Combinatorics: lattices, finite groups, incidence algebras

1. **The E_n chain (real forms).** T10 → LNC-042 (det = 9 − n, inertia) → LNC-048 (det = 0 only at n = 9) → LNC-043 (null root of Ẽ₈, marks summing to 30) → LNC-044 (Kac types, names recalled) → LNC-047 ≡ 129 ≡ 125 (why the series stops; van der Blij). Instances: LNC-092 ≡ 124. Compounds: LNC-008 ≡ 127. Guards: LNC-046 ≡ 128. Readings: LNC-126 ≡ 132, 094, 074. *Order differs:* the page puts this "top" rung ladder inside the category lens, but it is lattice theory.
2. **The E_n chain mod 2.** T9 → LNC-009 ≡ 045 ≡ 130 (E_n/2E_n ≅ the label form of Cl(n,0); W onto O(q) for n ≤ 20) → LNC-049 ≡ 131 (null root ↦ 1…1) → LNC-087 (all n through transvections; the argument is marked ours) → question LNC-082 (QD1). Groups strip: LAB-020 (S_{n+1} ⊂ O(Q), an instance of T9 (d)), LAB-009 (bundle), LAB-010 ≡ INP-079 (quoted), LAB-011 (reading), LAB-012 (open list).
3. **Quadrics and polar spaces.** LNC-059 (Witt index, Peres–Mermin, Q⁻(5,2)) → question LNC-079 (QE2).
4. **Representation theory of the cube category.** LNC-051 (definition) → LNC-052 (Euler form = Möbius; finite, not finite, wild) → LNC-058 (signatures n = 0…5) → reading LNC-053; LNC-054 ≡ 083 (tame? answered in T8); LNC-096.

### A.3 Topology

LNC-050 → LNC-056: the edge sign of the cube is unique up to gauge because H¹(cube; 𝔽₂) = 0; the Koszul complex is exact; H²(ℤ₂ⁿ; 𝔽₂) = quadratic forms; the octonion cochain. LNC-140 (the nerve triangulates the cube; the proper part is S^{n−2}; Hall's theorem; ∂² = 0). LNC-138 (additive weights as classes in H¹ of the nerve). LNC-141 (the cell as a sheaf on the Alexandrov space of B_n). Question LNC-086 (monoid cohomology, QB2). *Order differs:* LNC-050/056 is the topological reason the bit-rule sign is canonical (it underlies T1 and every row of A.1), yet the page places it after the E_n rungs.

### A.4 Category theory

LNC-041 (Clifford functor; natural isomorphism for halving). LNC-099 → LNC-137 (partiality is not non-associativity), LNC-139 (Lawvere metric), LNC-142 (limits = AND, colimits = OR; least-weight cones), LNC-143 (comma propagation = Fun(B_k, C)). LNC-100 (⊕ is the wedge of the null cell). LNC-144 (the incidence algebra of B_n inside Cl(n,n) = End Λ). LNC-145 (Majkić's zero vs null vs unit). Sources: LNC-061 (LS, Baez, Tian), LNC-062 ≡ 068 (Majkić v2/v3). LNC-010 is a compound.

### A.5 Geometry

LNC-021, 025, 070, 108 (the tangent algebra of a null hypersurface; e₀ of PGA; its conformal image f⁺ − f⁻). LNC-033 (Hodge star vs Frobenius duality). LNC-037 ≡ 121 (Spin⁺(1,3) ≅ SL(2,ℂ)). Question LNC-098 (Carroll structure; sources unread).

### A.6 Not mathematics

Meta: LNC-001, 023, 071, 072, 075, 103, LNP-001, LNP-002 (LNC-046/128 are guards). Readings: LAB-011, LNC-022, 053, 073, 074, 094, 095, 104, 116, 119, 126, 132, LNP-003. Open lists: LAB-012, LNP-004.

*Other order differences.* (1) The page opens with unit, zero and label 0 (LNC-011…013); mathematics opens with the quadratic space and its Witt decomposition. (2) The dead ends belong beside their positive companions as the "only if" halves: LNC-063 with 036, 064 with 030, 065 with 019, 066 with 032, 067 with 027, 068 with 062.

---

## B. Chains, classes and loops

### B.1 Chains (`derives`, left = rests on)

1. T2 → LNC-014 → LNC-016 → LNC-089 (≡ 101): radical, Loewy length, honest summary.
2. T2 → LNC-014 → LNC-019 → LNC-065 → LNC-078: states kill J; λ is not a state; the QA5 question.
3. T2 → LNC-014 → LNC-031 → LNC-033 → LNC-113: ranks → Hodge star needs r = 0.
4. T3 → LNC-028 → LNC-029 → LNC-030 → LNC-077 (→ 097, 123): Frobenius → Nakayama → symmetric iff → QA4.
5. T3 → LNC-028 → LNC-032 → LNC-034 → LNC-060 → LNC-080: torsor → Cl(3,0) trace → Bloch ball and ladder → QE3.
6. T5 → LNC-036 → LNC-037 (≡ 121): halving → spinors.
7. LNC-038 → LNC-041 → {LNC-073, 094, 116, 119}: moves → functor → the "up and down" readings.
8. LNC-026 (≡ 040) → LNC-018 → LNC-055 → LNC-081 (→ 076): mother cell → forced clock → Morita monoid → QC3.
9. T10 → LNC-042 → LNC-043 → LNC-049 (≡ 131): inertia → null root → null root ↦ 1…1 (with T9).
10. T10 → LNC-042 → LNC-048 → LNC-126 (≡ 132): det = 0 only at 9 → "rung 9 is the border" (reading).
11. T10 → LNC-042 → LNC-044 → LNC-046 (≡ 128): Kac types → E₁₀/E₁₁ guard.
12. T9 → LNC-009 → LNC-087 → LNC-082: mod-2 isometry → all-n via transvections → QD1.
13. T6 → LNC-050 → LNC-056 → LNC-099 → {LNC-137, 139, 142, 143}: cube sign → Boolean lattice → partial monoid → Majkić rows.
14. LNC-056 → LNC-140 → LNC-138 → LNC-142: nerve → weights as H¹ classes → least-weight limits.
15. T8 → LNC-051 → LNC-052 → LNC-058 → {LNC-053, 083, 096}: kB_n → Euler form → signatures → reading and questions.
16. T7 → LNC-027 → LNC-057 → LNC-088 (with LNC-069): Tian = Cl(m,m) / Cl(m−1,m−1,1) → radical vector → QB5.
17. T18 → LNC-021 → {LNC-022 (reading), 108 (instance)}; LNC-024 → LNC-025 (instance) → LNC-070 → LNC-075.
18. {LNC-012, 013} → LNC-145; LNC-038 → LNC-141.

### B.2 Classes (`equiv`: one statement in two lengths or two languages)

| class | rows |
|---|---|
| radical (compound) | LNC-002, 105 |
| radical as a face of the cube | LNC-015, 102, 106 |
| honest radical summary | LNC-089, 101 |
| forced clock of a degenerate cell | LNC-006, 018, 107 |
| universal grading group | LNC-003, 020, 093 |
| states vanish on J | LNC-005, 019 |
| halving (and its failure for r ≥ 3) | LNC-007, 036, 063, 091 |
| mother algebra | LNC-026, 040, 136 |
| λ is Frobenius | LNC-028, 111 |
| symmetric iff n odd or r = 0 | LNC-030, 064, 110 |
| torsor of Frobenius forms | LNC-032, 066 |
| A ≅ A* | LNC-039, 114 |
| restrict to a face | LNC-038, 118 |
| paired null in Cl(1,1) | LNC-024, 134 |
| Tian's generators are paired nulls | LNC-027, 067 |
| halving in physics | LNC-037, 121 |
| E_n compound | LNC-008, 127 |
| E₉/E₁₀/E₁₁ inertia | LNC-092, 124 |
| why the finite series stops | LNC-047, 125, 129 |
| E₁₀/E₁₁ are not spacetimes | LNC-046, 128 |
| E_n/2E_n and W onto O(q) | LNC-009, 045, 130 |
| null root ↦ 1…1 | LNC-049, 131 |
| rung 9 as boundary (reading) | LNC-126, 132 |
| Majkić v2 | LNC-062, 068 |
| QA4 | LNC-077, 097, 123 |
| QC3 | LNC-076, 081, 096 |
| QT2 | LNC-054, 083 |
| Golay/Monster quotes | LAB-010, INP-079 |
| two refinements | LNC-070, 075 |

### B.3 Loops

I drew none. Two places fit the scheme's `cycle` and were drawn as chains, because the Atlas proves one direction:
- The definition "J = span of the labels with a null bit" and the theorem "J is the radical" (LNC-014 with LNC-135). This is a definition justified by a theorem.
- The "forced clock" (LNC-018). Giving a null bit the exponent 0 is a convention fixed by consistency (any other admissible value kills the Gauss sum). Brown's theory makes it a lemma (C.3).

### B.4 Contradictions and stale rows

- **LNC-010 and LNC-054** say that the tameness of kB₃ is open. T8 (3) records kB₃ as tame and derived equivalent to the canonical (3,3,3) algebra (Wang; Ladkani, recalled). Both are `contradicts` edges to T8. LNC-083 (the same question) and LNC-058/096 ("why the null directions appear is open", QB4) are stale in the same way; T8 (1) identifies those directions as the Coxeter-fixed vectors.
- **Questions marked answered in questions.json but shown open in the rows:** QA4 (LNC-039, 077, 097, 123), QC3 (LNC-076, 081, 096, LNP-004, the end of LNC-055), QD1 (LNC-082), QT2/QB4 (LNC-054, 083, 058, 096), QB2 (LNC-086), QE3 (LNC-080).
- **LNC-055**, within one row, says r is "not a second coordinate of the class" and then gives the graded Morita monoid ℤ₈ × ℕ = (clock, r). Both hold, over different base rings (Λ(ℝ^r) vs ℝ), but the row does not say so.
- **LNC-050** line 3 calls the classes of anticommuting edge signs H²(ℤ₂ⁿ; 𝔽₂). Those edge signs form one gauge class (line 1); H² classifies the group cocycles s(a,b).
- **LNC-131** calls the null-root ↦ 1…1 statement a "candidate". LNC-049 states it, and it follows from T9 (a).

### B.5 Hubs and leaves

- **Hubs** (in-degree in this labelling): T2, T3, T9 (10 each); **LNC-036** halving (9); **LNC-014** radical and **LNC-042** E_n inertia (8 each); T10 and **LNC-028** λ Frobenius (7 each); T4, T15, **LNC-030** (6 each); LNC-018, 019, 029, 035, 038, 099 and T1, T6, T7, T8 (5 each). As five concept hubs: radical (T2 → LNC-014), top-blade Frobenius form (T3 → LNC-028/030), halving (T5 → LNC-036), E_n Cartan form (T10 → LNC-042), E_n mod 2 (T9 → LNC-009/045/130).
- **Leaves** (82 rows, nothing rests on them): all readings and meta rows, most questions, the widget restatements, the strip rows LAB-009/011/012/019 and LNP-001…004, the compounds LNC-004…007 and 010, and the category rows LNC-137, 139, 141…145. Those last ones are leaf **theorems**: the incidence algebra inside Cl(n,n) (LNC-144), Fun(B_k, C) (LNC-143) and the Alexandrov sheaf (LNC-141) are not yet used by any other row. C.4 and C.13 would connect them.

---

## C. Missing pieces

Most consequential first. "Check" says whether the Atlas's engine could compute it.

1. **Untwisting by the volume element.** If q is non-degenerate of even dimension, Cl(q ⊥ q′) ≅ Cl(q) ⊗ Cl(δ·q′) as ungraded algebras (δ = ω², the square of the volume element). Hence Cl(p,q,r) ≅ Cl(p,q) ⊗ Λ(ℝ^r) = M_N(D ⊗ Λ(ℝ^r)) for p + q even, which is Morita equivalent to D ⊗ Λ(ℝ^r) and has the representation type of Λ(ℝ^r): finite for r ≤ 1, tame for r = 2, wild for r ≥ 3. For p + q odd with a generator of square +1, one more factor Cl(1,0,r) = Λ(ℝ^r) ⋊ ℤ₂ remains, a skew group algebra with the same representation type (Reiten–Riedtmann). *Source:* T. Y. Lam, *Introduction to Quadratic Forms over Fields* (the chapter on Clifford algebras); I. Reiten, C. Riedtmann, *Skew group algebras in the representation theory of Artin algebras*. *Links:* LNC-084 (answers the second half of QA2), LNC-017, LNC-035, LNC-055. *Field:* algebra. *Check:* yes (z′_j = e_F z_j satisfies the relations; verify by products).
2. **Witt decomposition.** Every quadratic space splits as V = V_an ⊥ H^m ⊥ rad(Q): anisotropic part, hyperbolic planes, radical. "Paired null" means isotropic in a hyperbolic plane. "Unpaired null / label 0" means a radical vector. The mother algebra embeds rad into hyperbolic planes (rad ⊂ H^r). This one definition replaces the two meanings of "null" (LNC-070) and states LNC-024, 025, 026, 027, 067, 133…135 in one line. *Source:* Lam, *Introduction to Quadratic Forms over Fields*. *Links:* those rows, T7, T18 (d), T20 (e). *Field:* algebra, geometry. *Check:* yes.
3. **Brown invariant of degenerate ℤ₄-forms.** A ℤ₄-valued quadratic refinement takes only the values 0 and 2 on the radical of its bilinear form. Its Gauss sum is non-zero iff it vanishes there, and then the Brown invariant is that of the induced form on V/rad. With the label exponent |a∩P| − |a∩Q|, the radical of the polar form is spanned by the null generators. The "forced, not a convention" clause of LNC-006/018/107 is therefore this lemma, and the clock of Cl(p,q,r) is the Brown invariant of its quotient. The same invariant links the H² rows (LNC-050/056: a class is a quadratic form) to the clock rows. *Source:* E. H. Brown, *Generalizations of the Kervaire invariant*; R. Kirby, L. Taylor, *Pin structures on low-dimensional manifolds*. *Links:* LNC-006, 018, 107, 055, LAB-019, LNC-050, 056. *Field:* topology, algebra. *Check:* yes.
4. **Generation by transvections in characteristic 2.** For a non-degenerate quadratic form over 𝔽₂, O(Q) is generated by orthogonal transvections, except O⁺₄(2). Reflections in roots reduce to transvections, so "every non-singular class of E_n/2E_n is a root mod 2" plus this theorem would make LNC-087 (now a range n ≤ 20 with an argument marked ours) a theorem for all n. It also settles the "exact statement of Cartan–Dieudonné in characteristic 2" listed as open in LAB-012. *Source:* J. Dieudonné, *La géométrie des groupes classiques*; D. E. Taylor, *The Geometry of the Classical Groups*. *Links:* LAB-012, LNC-087, 009, 045, 130, T12, T9 (e). *Field:* algebra, combinatorics. *Check:* yes (transvection closure is already computed to n = 200).
5. **B_n = B₁ⁿ.** The Boolean lattice is a product of n copies of the 2-chain. So the incidence algebra is (kA₂)^{⊗n} (T8's Kronecker formulas), the nerve has (k+2)ⁿ k-simplices, the Möbius function is a product, and Fun(B_k, C) is an iterated arrow category (exponential law). Its object counts over 𝟐 are the Dedekind numbers 2, 3, 6, 20, 168. This turns the ranges of LNC-099, 100, 140, 143, 144 (n ≤ 4, 5, 6) into theorems. *Source:* R. P. Stanley, *Enumerative Combinatorics, Vol. 1*; G.-C. Rota, *On the foundations of combinatorial theory I: theory of Möbius functions*. *Links:* LNC-099, 100, 140, 142, 143, 144, 051, 052, 058, T8. *Field:* combinatorics, category. *Check:* yes.
6. **Symmetric ⇔ inner Nakayama automorphism; exterior algebras.** A Frobenius algebra has a symmetric Frobenius form iff its Nakayama automorphism is inner. For Λ(V) the Nakayama automorphism is (−1)^{(n−1)·deg}, so Λ(V) is symmetric iff dim V is odd. This is the conceptual reason behind "n odd or r = 0" (α is inner by e_F when r = 0) and answers the exterior-algebra half of QA4. *Source:* A. Skowroński, K. Yamagata, *Frobenius Algebras I*; T. Y. Lam, *Lectures on Modules and Rings*. *Links:* LNC-029, 030, 064, 072, 090, 110, 112, 077, 097, 123. *Field:* algebra. *Check:* yes.
7. **The Clifford functor induces Witt → Brauer–Wall.** Cl: (Quad_ℝ, ⊥) → (sAlg_ℝ, ⊗̂) is symmetric monoidal and sends a hyperbolic plane to M₂(ℝ), which is graded-Morita trivial. So it induces W(ℝ) ≅ ℤ (signature) → BW(ℝ) ≅ ℤ₈: the clock is the signature mod 8. This is the category-to-algebra link the page does not draw between LNC-041 (functor) and LNC-055 / LAB-019 (classes). *Source:* C. T. C. Wall, *Graded Brauer groups*; Lam, *Introduction to Quadratic Forms over Fields* (Clifford invariant). *Links:* LNC-041, 035, 117, 055, 018, LAB-019. *Field:* category, algebra. *Check:* yes (the clock is already additive under join).
8. **Graded Morita invariants.** The graded centre and the semisimple quotient A/J are graded-Morita invariants. Together with C.1 this proves LNC-055's monoid ℤ₈ × ℕ = (clock, r), which the row asserts without proof. *Source:* C. Năstăsescu, F. Van Oystaeyen, *Methods of Graded Rings*; H. Bass, *Algebraic K-Theory*. *Links:* LNC-055, 017, 014. *Field:* algebra, category. *Check:* partly.
9. **Separable algebras have vanishing Hochschild cohomology in degrees ≥ 1, and separability survives base change.** Cl(p,q) is graded-separable, so Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝ^r) has HH^{≥1} = 0 relative to Λ(ℝ^r). This replaces LNC-055's "pointer, source unread" and its small-range HH¹/HH² computation. *Source:* F. DeMeyer, E. Ingraham, *Separable Algebras over Commutative Rings*; G. Hochschild, *On the cohomology groups of an associative algebra*. *Links:* LNC-055. *Field:* algebra. *Check:* partly (the low cases are already computed).
10. **Positive functionals kill nilpotent ideals; Frobenius forms kill no non-zero ideal.** By Cauchy–Schwarz, a state vanishes on every nilpotent *-ideal, and J is preserved by every involution. A non-degenerate form cannot vanish on a non-zero ideal. So for r ≥ 1 no state is a Frobenius form, which is the whole "dichotomy" of QA5 in two lines. *Source:* G. J. Murphy, *C*-Algebras and Operator Theory* (positive functionals). *Links:* LNC-019, 005, 065, 078, 122, T15. *Field:* analysis, algebra. *Check:* yes.
11. **W(E_n) mod 2 in the literature.** Coble's correspondence between point sets in the plane and theta characteristics studies the reduction mod 2 of W(E_n). I recall that it treats the surjectivity onto the orthogonal or symplectic group of E_n/2E_n; I have not checked which n are covered. *Source:* I. Dolgachev, D. Ortland, *Point sets in projective spaces and theta functions*. *Links:* LNC-082 (QD1), 087, 009, T9. *Field:* algebra, geometry. *Check:* partly (the group side yes, the geometry no).
12. **Signs on a cube of resolutions; the order complex of the Boolean lattice.** Sign assignments making every face anticommute exist and are unique up to vertex gauge because H¹ of the cube vanishes. The order complex of B_n is the Freudenthal triangulation of [0,1]ⁿ, its proper part is the sphere S^{n−2}, and μ(∅, F) is its reduced Euler characteristic (P. Hall). *Source:* M. Khovanov, *A categorification of the Jones polynomial*; Rota, as in C.5. *Links:* LNC-050, 056, 140, T6. *Field:* topology. *Check:* yes.
13. **The Euler characteristic of a category.** For a finite poset, Leinster's Euler characteristic is the Möbius sum and equals the Euler characteristic of the order complex. This links the representation-theory rows (LNC-052: the Euler form is the Möbius form) with the topology rows (LNC-140: the Möbius number) and the Lawvere metric (LNC-139, through magnitude). The page keeps them apart. *Source:* T. Leinster, *The Euler characteristic of a category*. *Links:* LNC-052, 058, 138, 139, 140. *Field:* category, topology. *Check:* yes.
14. **Hyperbolic criterion.** An indecomposable generalized Cartan matrix of indefinite type is hyperbolic iff every proper connected subdiagram is of finite or affine type. E₁₀ = T_{2,3,7} qualifies; E₁₁ does not, since it contains E₁₀. This makes "hyperbolic only at 10" (LNC-044, a recalled name) a computed statement. *Source:* V. Kac, *Infinite-dimensional Lie algebras*. *Links:* LNC-044, 046, 128, 008, 127. *Field:* algebra, combinatorics. *Check:* yes (subdiagram signatures are already computed).
15. **Fine gradings of matrix algebras.** The gradings of M_N(D) and their universal groups are classified. For r = 0 this answers LNC-085 (QA3), leaving only r ≥ 1 open. *Source:* Y. Bahturin, M. Zaicev, *Group gradings on matrix algebras*; A. Elduque, M. Kochetov, *Gradings on Simple Lie Algebras*. *Links:* LNC-003, 020, 085, 093. *Field:* algebra. *Check:* partly.
16. **Pauli groups as polar spaces.** The n-qubit Pauli group modulo its centre is the symplectic polar space W(2n−1, 2). Real Hermitian elements give quadrics, and Mermin–Peres configurations are subgeometries. This is the frame for LNC-059 and QE2. *Source:* M. Saniga, M. Planat, *Multiple qubits as symplectic polar spaces of order two*; H. Havlicek, B. Odehnal, M. Saniga, *Factor-group-generated polar spaces and (multi-)qudits*. *Links:* LNC-059, 079, T11. *Field:* combinatorics. *Check:* yes.
17. **Partial cohomology and contracted semigroup algebras.** Cl(p,q,r) is a twisted contracted semigroup algebra of a monoid with zero. Partial cohomology is the theory that QB2 asks for. *Source:* M. Dokuchaev, M. Khrypchenko, *Partial cohomology of groups*; J. Okniński, *Semigroup Algebras*. *Links:* LNC-086, 100, T1. *Field:* algebra, topology. *Check:* partly (low-degree cocycle spaces).
18. **Carrollian structure of null hypersurfaces.** A null hypersurface carries a degenerate metric whose kernel is spanned by the normal: a Carroll structure. *Source:* C. Duval, G. W. Gibbons, P. A. Horvathy, P.-M. Zhang, *Carroll versus Newton and Galilei: two dual non-Einsteinian concepts of time*; L. Donnay, C. Marteau, *Carrollian physics at the black hole horizon* (both pointers in LNC-098, unread). *Links:* LNC-021, 025, 098, 108, T18. *Field:* geometry. *Check:* partly (the pointwise algebra yes; the structure along a hypersurface needs charts).
19. **The tenfold way as twisted equivariant K-theory.** The tenfold way arises from twisted equivariant K-theory, where the eight real and two complex classes appear through Brauer–Wall groups. This is the frame QC3 needs, and the row already names it as a pointer. *Source:* D. S. Freed, G. W. Moore, *Twisted equivariant matter*. *Links:* LNC-055, 076, 081, 096, LNP-004. *Field:* topology. *Check:* no (needs T², C² as input and K-theory beyond the engine).
20. **Definitions the rows use without stating.** State for an involution (positive normalised functional), graded centre, Euler form Σ(−1)^i dim Ext^i and Tits form, universal grading group, radical of a quadratic form (C.2). Each belongs in A.0 before the rows that use it. *Source:* I. Assem, D. Simson, A. Skowroński, *Elements of the Representation Theory of Associative Algebras 1* (Euler and Tits forms); Elduque–Kochetov (universal group). *Links:* LNC-019, 017, 051, 052, 003, 013. *Field:* algebra. *Check:* not applicable.
