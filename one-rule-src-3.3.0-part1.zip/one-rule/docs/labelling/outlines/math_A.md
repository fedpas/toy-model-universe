# Chunk A (rule page, atlas cards, Conventions and Clock tabs, Maxwell calibration, Shapes page, lens-tab inputs): the mathematician's labelling

142 rows, labelled in `math_A.jsonl` (validator: 0 problems). Kinds: example 31, definition 23 (all input rows but INP-012, INP-081), computation 16, meta 14, range 12, theorem 10, reading 7, reduction 6, lemma 5, construction 5, classification 4, question 3, dead-end 2, counterexample 2, pointer 1, conjecture 1. Edges: derives 87, instance 40, equiv 26, uses-input 24, cycle 5, contradicts 1.

Notation: notions are the SCHEME §1 codes; "X → Y" below means "Y rests on X" (foundation on the left).

## A. How mathematics would organise these rows

### A.0 Inputs and conventions (data the algebra does not supply)

- **Charts, units, frames:** INP-003 (flat chart, ∇), INP-006 (units), INP-008 (initial data), INP-009 (observer split), LAB-024 (the frame of the addresses is data).
- **Which sign is time; mirrors:** INP-005, INP-011, INP-017, INP-086. GEN-003 is the reason these are conventions: ñ ↦ −ñ is an anti-isometry, not an automorphism.
- **Grades, involutions, complex structures, vacua:** INP-004 (grades assigned), INP-080 (the dagger), INP-013 (Witt split and vacuum); PAG-019 is a heuristic built on INP-004.
- **Postulated equations, actions, given fields:** INP-001 (Maxwell action), INP-002 (constitutive map), INP-007 (Lorentz force), INP-010 (Coulomb field, plane wave), INP-085 (Schuller's matter action); PAG-010 is the credit line for INP-001.
- **Outside tables:** INP-014 (BBB charge formulas), INP-015 (Furey's 16), INP-016 (Cartan matrices), INP-082 (octonion table), INP-083 (3 vs 3̄), INP-084 (Madelung).
- **Method:** INP-081 (what is recalled rather than rebuilt).

Six input rows carry a result inside them (INP-001: the E–L lemma; INP-003, INP-009, INP-013: checked orbit and component counts; INP-011: T18 (f); INP-080: an elementary lemma). INP-012 is a dead-end (no time-domain realisation of extra time generators), not an input. Two imports are removable with tools the engine already has: INP-016 (the E₈ bracket needs only a sign cocycle on the root lattice, C1) and INP-082 (T6 (d) builds 𝕆 on the labels; only the index convention is input).

### A.1 Algebra I: the rule, its structure theorems, the classification

1. **Definitions.** The empty label GEN-001 ≡ ATL-001; the null seed (dual numbers, common contraction of ℂ and ℝ⊕ℝ) GEN-002; the hyperbolic plane (a Witt pair from an input pairing) GEN-003; orthogonal sums of hyperbolic planes are split GEN-005.
2. **Structure.** The rule is a twisted group algebra of ℤ₂ⁿ, its sign unique up to gauge, its class a quadratic form: PAG-002 (T1, T6). Scalars are central: ATL-021 (a lemma for all n, filed among the n = 8 cards). Centre and ω²: PAG-005 (range; the closed form is missing, C4). Even subalgebra and graded embedding: PAG-018, LAB-001, RSN-029 (T5).
3. **Classification.** PAG-004 (T4, reduced to the recalled table), ATL-024 (the real form is finer than its 𝔽₂ triple), Bott periodicity ATL-023 ≡ GEN-009. LAB-002 is only a heading.
4. **Examples of T4 by dimension** (the cell cards): n = 0 ATL-001; n = 1 ATL-002, ATL-003; n = 2 ATL-004, ATL-005; n = 3 ATL-006, ATL-007, ATL-008, and the degenerate GEN-004; n = 4 ATL-009, ATL-010, ATL-011, ATL-012, GEN-005; n = 5 ATL-013, ATL-016, degenerate GEN-006; n = 6 ATL-014, GEN-007; n = 7 ATL-015; n = 8 ATL-019, ATL-020, ATL-022, ATL-023, GEN-009, ATL-025.
5. **Central splitting and the two Pin modules:** GEN-008 ≡ ATL-015 (odd n with ω² = +1 splits; ω² = 0 once r ≥ 1 splits nothing); ATL-007 is an instance.
6. **Bivectors, spin groups, rotors:** ATL-008 (Spin⁺(1,3) ≅ SL(2,ℂ)), ATL-011 (so(2,2)), ATL-014 (so(4,2) ≅ so(2,4)), GEN-007 (so(3,3) ≅ sl(4,ℝ)); the trichotomy PAG-031 ≡ LAB-015 with LAB-003 (T17); RSN-010, RSN-013, RSN-014, LAB-004.
7. **Modules:** Fock space SHP-002 (T20); Peirce blocks ATL-025 ≡ RSN-002 → RSN-003; half-spin modules GOS-002, SHP-005; Dirac–Hestenes spinors RSN-027 → RSN-028; a complex structure from a central pseudoscalar RSN-012.

Where the page order differs: the atlas page orders its cards by board position and role name, so n jumps (ATL-021, a statement for all n, sits between n = 8 cards), and two cards are not cells: ATL-017 is the Maxwell construction (A.5) and ATL-018 a tetrad-covariance range check (A.4). Every card bundles a checked type line with a naming reading; mathematics would split each card into an example of T4 and a separate reading row. The degenerate cells (r ≥ 1) appear in this chunk only on the Genesis ladder, ordered by a story (seed, pair, spectator) rather than by T2 (Cl(p,q,r) = Cl(p,q) ⊗̂ Λ(ℝʳ)).

### A.2 Algebra II and topology: ℤ₄-forms and the clock

Proof order: LAB-022 (w = π + 2Q is a ℤ₄ charge, additive on disjoint addresses) → LAB-023 (the clock sum factorises as Π(1 + i^{ε_j})) → LAB-017 (Gauss sum (1+i)^p(1−i)^q; clock = Brown invariant; a null generator doubles the sum), with RSN-029 its r = 0 restatement → LAB-018 (four ℤ₈'s identified: Pin⁻ bordism of #ⁿℝP², lattice signature mod 8, Fidkowski–Kitaev, KO-degree) → LAB-025 (integer weights), LAB-021 (a model instance), PAG-020 (the "two 8s"). LAB-024 (frames) hangs off LAB-022; INP-017 is the sign convention.

The tab states LAB-017 and LAB-018 first and the lemmas they rest on afterwards. LAB-022, LAB-023, LAB-025 are stated as ranges but have proofs of two lines for all n (C3). Topology enters this chunk only here and in the open strip PAG-032 ≡ LAB-016.

### A.3 Combinatorics: polytopes, lattices, codes, finite groups

1. **Polytopes and posets:** SHP-001 (cube / cross-polytope duality) → SHP-007 (the face poset as the cube category), SHP-002 (faces as occupation constraints), SHP-003 (lattice stencils), SHP-004 (24-cell; triality unnamed, C6); ATL-022 (f-vectors); PAG-017 summarises.
2. **Root systems:** SHP-006 (E₈ = D₈⁺), GOS-001 (Gosset k₂₁ and demicubes), GOS-002 (the e₈ dimension count), GOS-004 (dead end), PAG-018 (ADE).
3. **The E_n series:** GOS-005 (E_n = k^⊥ in I_{1,n}; T10) → GOS-006 (mod 2: the even part; T9; its general sentence is provable, C5) and GOS-007 (del Pezzo; classical, C13); PAG-020.
4. **Branching:** GOS-003 ≡ RSN-004 (E₈ ⊃ E₆ × A₂; T13).
5. **Finite groups and codes:** RSN-030 (O(Q), W(E_n) mod 2), RSN-031 (Golay, M₂₄, Leech; its tie to the label form, T14 (4), is unstated), RSN-007 ≡ RSN-023 (real Cartan–Dieudonné, B_n, D_n; the 𝔽₂ failure is T12), LAB-024 (O(V,w)).

### A.4 Geometry

1. **Spacetime algebra and conventions:** ATL-010 ⟲ ATL-012, INP-011, INP-086; PAG-006 summarises six textbook identifications.
2. **Projective and conformal models:** ATL-013 (CGA), ATL-014 (conformal Cartan connection, Bianchi = Jacobi), RSN-008 ≡ RSN-022 (Cayley–Klein from one extra generator; PGA ⊂ CGA), LAB-004 (translators as null rotations), RSN-014 (Mozzi–Chasles, rotor logarithms), PAG-032 ≡ LAB-016 (Pin± open).
3. **Tetrads, curvature, actions:** ATL-018 (strain, local Lorentz covariance, Fierz–Pauli symbol), RSN-018 (curvature counts; the Bianchi map, C11), CPL-011 (Noether identities, Kaluza–Klein signs, MacDowell–Mansouri).
4. **Null hypersurfaces and horizons:** RSN-015 (T18, the theorem) ≡ RSN-019 (its summary); RSN-020 and RSN-021 (counterexamples to g^{rr} = 0 and g_tt = 0 as criteria); RSN-016 (reading); RSN-017 (Painlevé–Gullstrand construction; Birkhoff inside an ansatz).
5. **Algebraic geometry:** GOS-007.

### A.5 Analysis: field equations, hyperbolicity, mechanics

1. **Hyperbolicity:** PAG-011 (T18 (f), proved); PAG-034 (Gårding, a pointer, needs "strictly", C10); INP-012 (dead end).
2. **Maxwell:** INP-001…INP-010 → RSN-025 (Cl(k,d) in general) → ATL-017 (n = 4); RSN-025 ≡ PAG-008 (a calibration range whose sign is fixed by CPL-011).
3. **Charges and orbits:** PAG-009 ≡ RSN-026.
4. **Rigid bodies in PGA:** RSN-005, RSN-006 (RSN-024 is their list).
5. **Dirac:** T16 → RSN-027 → RSN-028.

### A.6 Category

Only SHP-007 is stated as category theory (the poset category of 2^[n]). The phrase "one graded algebra" (GEN-009) and the Brauer–Wall reading behind LAB-017, LAB-018 and INP-017 are category statements used without a definition (C2). The Peirce rows ATL-025, RSN-002, RSN-003 are Morita statements in disguise (C18).

### A.7 Not mathematics

- **Readings:** GEN-006, PAG-003, PAG-019, LAB-003 (a proved trichotomy filed as reading), RSN-012, RSN-016, SHP-003.
- **Meta:** PAG-001, PAG-007, PAG-029 ≡ LAB-013, PAG-030 ≡ LAB-014, PAG-033, LAB-002, EQN-005, RSN-009, RSN-011, RSN-019, RSN-024, INP-081.
- **Physics comparisons:** RSN-001, RSN-003, and the reading lines of the ATL cards (role names, Furey, Weinberg angle).

## B. Chains, classes and loops

### B.1 Chains (ordered by `derives`; foundation on the left)

1. **Clock:** LAB-022 → LAB-023 → LAB-017 → LAB-018 → LAB-025; LAB-018 → LAB-021 (instance); LAB-018 → PAG-020. T4 enters at LAB-017; LAB-022 → LAB-024.
2. **E_n lattices:** T10 → GOS-005 → GOS-006 (with T9, T5); GOS-005 → GOS-007.
3. **Exceptional roots:** T10 → GOS-002 → GOS-004 (dead end); T10 → SHP-006, GOS-001; T13 → GOS-003 ≡ RSN-004.
4. **Genesis:** T20 → GEN-003 → GEN-005; T7 → GEN-004, GEN-005, GEN-006, GEN-007; T2 → GEN-002, GEN-004, GEN-006.
5. **Polytopes:** SHP-001 → SHP-002 (with T20, INP-013), SHP-003, SHP-004 (instance), SHP-007.
6. **Peirce:** ATL-025 ≡ RSN-002 → RSN-003 (input INP-015).
7. **Maxwell:** INP-003, INP-004, INP-007 → RSN-025 → ATL-017 (instance); RSN-025 ≡ PAG-008; INP-001 → CPL-011 → PAG-008.
8. **Dirac:** T16 → RSN-027 → RSN-028; T16 → ATL-010, ATL-012.
9. **Bivectors:** T17 → LAB-001, LAB-003, PAG-031 ≡ LAB-015, RSN-010, RSN-013, RSN-014, RSN-018, ATL-011; T17 → LAB-004 → PAG-032 ≡ LAB-016.
10. **Null hypersurfaces:** T18 → RSN-015 ≡ RSN-019; T18 → RSN-016, RSN-017, RSN-020, RSN-021; T18 → PAG-011, INP-011, INP-012, ATL-010, ATL-024.
11. **Types:** T4 → twenty cell cards (instance), PAG-004, ATL-024, RSN-029, LAB-017; core·B14 → GEN-008 ≡ ATL-015 → ATL-007; core·B14 → PAG-005; core·B20 → ATL-023 ≡ GEN-009 → ATL-020.
12. **Even part:** T5 → ATL-008, PAG-018, LAB-001, RSN-029, GOS-006.
13. **Finite groups:** T9 → RSN-030 → ATL-022; T14 → RSN-031.
14. **A summary strip:** ATL-005, ATL-006, ATL-008, ATL-012, ATL-013, ATL-014 → PAG-006.

### B.2 Classes (`equiv`)

- The Genesis ladder restates three cards: {ATL-001, GEN-001} the empty label; {ATL-015, GEN-008} the chirality split; {ATL-023, GEN-009} row 8.
- {ATL-025, RSN-002} Peirce blocks of End(V); {GOS-003, RSN-004} E₈ ⊃ E₆ × A₂; {RSN-008, RSN-022} Cayley–Klein from one extra generator; {RSN-007, RSN-023} Cartan–Dieudonné and B_n; {RSN-025, PAG-008} Maxwell on Cl(k,d); {PAG-009, RSN-026} the six charge situations; {RSN-015, RSN-019} null surfaces; {LAB-004, RSN-014 (its translator clause)}.
- Identical texts on two pages: {PAG-029, LAB-013}, {PAG-030, LAB-014}, {PAG-031, LAB-015}, {PAG-032, LAB-016}. One of each pair should be a pointer to the other: today PAG-031 has evidence "unspecified" and LAB-015 "read", so one statement would get two statuses.

### B.3 Loops (`cycle`)

- {ATL-010, ATL-012}: which mirror of the Lorentzian pair is "spacetime" is fixed by consistency with T16 (γ·∂ − m in Cl(3,1), ∇ψJ = mψγ₀ in Cl(1,3) both give the physical shell); INP-011 and INP-086 are the conventions.
- {INP-005, CPL-011}, with PAG-008: the overall sign of J is a convention fixed by positivity of the field energy (bd·sol·17).
- {INP-017, LAB-017}: the sign of the clock and the theorem that makes it the Brown invariant of w = π + 2Q with Q = [e_a² = −1].
- {INP-080, T15}: the dagger is the datum because T15 makes the scalar part a faithful state for it.
- Not drawn as an edge: GEN-003 is why INP-011 is a convention (ñ ↦ −ñ is an anti-isometry).

### B.4 Hubs and leaves

- **Hubs** (number of rows of this chunk resting on them): T4 (27), T17 (10), T18 (10), T10 (7), T5 (5); then T7, T20, SHP-001, INP-015 (4); LAB-018, LAB-022, LAB-004, INP-004, INP-007, INP-011, core·B14, T2, T16 (3). The structural hub among chunk rows is LAB-018: the clock read as four standard ℤ₈'s.
- **Leaves** (nothing in this chunk rests on them; 86 rows): every meta row; the reading rows; most cell cards (ATL-002–004, 007, 009, 011, 016–022, 024); GEN-002, GEN-004–007; SHP-002–007 and GOS-001, 004, 006, 007; most RSN rows; the inputs INP-002, 006, 009, 010, 012, 017, 080–085, which serve rows of other chunks.

### B.5 Contradictions and status anomalies

- **Contradicts:** RSN-011 ("the probability reading … open for the other cells") against T15, which proves the state space for every Cl(p,q,r) (QE1). Possibly stale: GOS-003 and RSN-004 call the A₂ question open, while questions.json marks QT8 answered.
- **Wrong or missing theorem tags:** T14 (codes) on PAG-029, PAG-030, LAB-013, LAB-014; T4 on ATL-018, ATL-021, ATL-025; T11 on ATL-011; T12 on RSN-007, which checks the real statement T12 says fails over 𝔽₂. ATL-010 lacks T18 for "hyperbolic"; ATL-012 lacks T16 for its mass-shell sentences.
- **Ranges that are theorems** (a short proof for all n exists): PAG-005, LAB-001 (T5 (b)), LAB-017, LAB-022, LAB-023, LAB-024 (the n! part), LAB-025, SHP-001, SHP-007, RSN-023, and the general sentence of GOS-006 (flagged "ours", provable, C5).
- **Bundles to split:** CPL-011 (at least six statements), ATL-014 (three cells), ATL-024 (classification, range and an open list), RSN-014 (four examples), and every ATL card (type line plus reading).
- **Precision:** PAG-034 ("a hyperbolic symbol gives a well-posed problem") needs "strictly hyperbolic"; T18 (f) shows null generators give only non-strict hyperbolicity, where lower-order terms decide.

## C. Missing pieces

Most consequential first. "Script" says whether a check could compute it on the Atlas's engine.

1. **The Frenkel–Kac sign cocycle (the bracket of E₈).** For an even lattice L choose a bimultiplicative ε: L × L → {±1} with ε(α,α) = (−1)^{α·α/2}; then 𝔥 ⊕ ⊕_{α·α=2} ℝe_α with [e_α, e_β] = ε(α,β) e_{α+β} when α+β is a root, and [e_α, e_{−α}] = ε(α,−α) α, is the simply-laced Lie algebra of L. ε factors through L/2L and its diagonal is q(x) = x·x/2 mod 2, which for E₈ is the label form of Cl(8,0) (T9); since a class in H²(ℤ₂ⁿ;𝔽₂) is its quadratic form (T6 (c)), the E₈ cocycle is, up to gauge, the bit-rule sign of Cl(8,0) carried to E₈/2E₈. Source: Frenkel and Kac, "Basic representations of affine Lie algebras and dual resonance models"; Kac, *Infinite-dimensional Lie Algebras*. Links: INP-016, GOS-002, GOS-004, SHP-006, GOS-006, PAG-002, T6, T9. Field: algebra. Script: **yes**, ε is a bit-rule sign on L/2L ≅ 𝔽₂⁸, so the engine can build e₈ and check Jacobi; it removes the import of INP-016.
2. **Wall's theorem, BW(ℝ) ≅ ℤ₈ (the definition of "graded Morita class").** Graded central simple ℝ-algebras up to graded Morita equivalence form a group under ⊗̂, cyclic of order 8, generated by Cl(1,0), with [Cl(p,q)] = p − q. Source: Wall, "Graded Brauer groups"; Lam, *Introduction to Quadratic Forms over Fields*. Links: GEN-009 ("one graded algebra"), ATL-023, PAG-004, INP-017, INP-081, LAB-017, LAB-018 (and QT1). Field: algebra, category. Script: **partly**, graded tensor products and the (type, even type) pair are computable; Morita equivalence needs bimodules.
3. **ℤ₄-enhancements: additivity, factorisation, the Brown homomorphism (ranges → theorems).** (i) π + 2Q′ adds on disjoint addresses iff the polar form of Q′ is the Clifford one, b′(e_i, e_j) = 1 for i ≠ j; (ii) hence Σ_a i^{w(a)} = Π_j (1 + i^{ε_j}); (iii) the Brown invariant is additive on orthogonal sums and is read off the Gauss sum; (iv) Σ_{j∈a} k_j mod 4 refines the dot product iff every k_j is odd. Source: Brown, "Generalizations of the Kervaire invariant"; Kirby and Taylor, "Pin structures on low-dimensional manifolds". Links: LAB-022, LAB-023, LAB-025, LAB-024, LAB-017, LAB-018, RSN-029. Field: algebra, topology. Script: **yes**, each is a symbolic identity in n.
4. **Closed form of ω² and of the centre (range → theorem).** ω² = (−1)^{n(n−1)/2 + q} for r = 0 and ω² = 0 for r ≥ 1; the centre is ℝ for even n and ℝ ⊕ ℝω for odd n (the super-centre Λ(ℝʳ) of T2 when r ≥ 1). Source: Lounesto, *Clifford Algebras and Spinors*; Lawson and Michelsohn, *Spin Geometry*. Links: PAG-005, ATL-021, ATL-023, GEN-008, ATL-015, ATL-016. Field: algebra. Script: **yes**, the reordering sign of the top label is a popcount.
5. **Characteristic vectors and the even sublattice mod 2 (GOS-006's "ours" sentence as a lemma).** For an odd unimodular lattice L with characteristic vector k, k^⊥ is saturated of rank n − 1 and lies in L_even = {x : x·x even}, so k^⊥/2k^⊥ ≅ (L_even/2L, x·x/2 mod 2); for L = I_{p,q} this is the label form of the even part Cl⁰(p,q) (T5). It gives T9 (a) for E_n and A_n at once. Source: Serre, *A Course in Arithmetic*; Conway and Sloane, *Sphere Packings, Lattices and Groups*. Links: GOS-006, GOS-005, RSN-030, PAG-018. Field: combinatorics, algebra. Script: **yes**.
6. **Triality of Spin(8).** The outer automorphisms S₃ of D₄ permute the vector and the two half-spin representations: their weight sets are the three 16-cells of the 24-cell, and over 𝔽₂ the singular points and the two families of solids of the quadric of Cl(8,0) (T11: three sets of 135). Source: Adams, *Lectures on Exceptional Lie Groups*; Baez, "The Octonions". Links: SHP-004, SHP-006, GOS-002, INP-082, QE5. Field: algebra, geometry. Script: **yes**, permute sign-vector weight sets and quadric families.
7. **Cartan's two families and pure spinors.** On a split quadratic space of dimension 2k the maximal isotropic subspaces form two families, exchanged by reflections and preserved by Spin; each is the line of a pure spinor in one half-spin space. Source: Chevalley, *The Algebraic Theory of Spinors*; Cartan, *The Theory of Spinors*. Links: INP-013 ("one bit remains under Spin"), SHP-002, GOS-002, T11. Field: algebra, geometry. Script: **yes**.
8. **The Hodge–Dirac operator d + δ (used by the Maxwell rows, never stated).** Through the symbol map Λ ≅ Cl, ∇ = d + δ on forms and ∇² is the wave operator in a flat chart; in a curved frame Weitzenböck adds curvature. Source: Lawson and Michelsohn, *Spin Geometry*; Kähler, "Der innere Differentialkalkül". Links: ATL-017, RSN-025, PAG-008, INP-002, INP-004. Field: geometry, analysis. Script: **yes** in flat charts (done term by term), **partly** in curved frames.
9. **Noether's second theorem.** Local symmetries of an action give identities among its Euler–Lagrange expressions (gauge and Bianchi identities). Source: Noether, "Invariante Variationsprobleme"; Olver, *Applications of Lie Groups to Differential Equations*. Links: CPL-011, ATL-018, INP-001, ATL-014. Field: geometry, analysis. Script: **partly**, the identities are checked; the theorem turns the probabilistic checks of CPL-011 into instances.
10. **Strict hyperbolicity and lower-order terms.** For constant coefficients, every lower-order perturbation keeps the Cauchy problem well posed iff the principal symbol is strictly hyperbolic; with multiple characteristics, well-posedness depends on the lower-order terms (Gårding's condition on the full polynomial). Source: Gårding, Acta Math. 85 (as cited); Hörmander, *The Analysis of Linear Partial Differential Operators*. Links: PAG-034, PAG-011, INP-011, INP-012, ATL-010, QT10. Field: analysis. Script: **partly**, characteristic roots yes, well-posedness no.
11. **Algebraic curvature tensors and the Bianchi map.** Sym²(Λ²V) = ker b ⊕ Λ⁴V with b(α·β) = α∧β; ker b splits into Ricci and Weyl parts, dim Weyl = n(n+1)(n+2)(n−3)/12. So B∧B = b(B·B), the half of RSN-018's reading that is a theorem. Source: Besse, *Einstein Manifolds*; Singer and Thorpe, "The curvature of 4-dimensional Einstein spaces". Links: RSN-018, T17, ATL-018. Field: geometry, algebra. Script: **yes**.
12. **Face posets of cube and cross-polytope (ranges → theorems; a category link).** The face poset of the n-cube is the poset of intervals of 2^[n]; polar duality reverses it onto the cross-polytope's; f-vectors 2^{n−k}C(n,k) and 2^{k+1}C(n,k+1); the poset category of 2^[n] has a contractible nerve and Möbius function (−1)^{|T∖S|}. Source: Ziegler, *Lectures on Polytopes*; Stanley, *Enumerative Combinatorics*, Vol. 1. Links: SHP-001, SHP-007, SHP-002, ATL-022, PAG-017, T8. Field: combinatorics, category, topology. Script: **yes**.
13. **Exceptional curves on del Pezzo surfaces.** On dP_n (n ≤ 8) the exceptional curves are the classes with x² = −1, K·x = −1, permuted transitively by W(E_n); at n = 6 they are the 27 lines, with the intersection graph of T13 (4). Source: Manin, *Cubic Forms*; Demazure, "Surfaces de del Pezzo". Links: GOS-007, GOS-005, T13, RSN-004. Field: geometry. Script: **partly**, counts and graphs yes, surfaces no.
14. **Killing horizons.** For a hypersurface-orthogonal Killing field ξ, the set ξ² = 0 is a Killing horizon where ξ is regular; for stationary non-static metrics the ergosurface ξ² = 0 and the horizon differ. Source: Vishveshwara, "Generalization of the 'Schwarzschild surface' to arbitrary static and stationary metrics"; Carter, "Killing horizons and orthogonally transitive groups in space-time". Links: RSN-015, RSN-021, RSN-020, RSN-017. Field: geometry. Script: **partly**, the criterion on given metrics yes.
15. **Low-dimensional spin isomorphisms as one table.** Spin(3) ≅ SU(2), Spin(1,2) ≅ SL(2,ℝ), Spin⁺(1,3) ≅ SL(2,ℂ), Spin(2,2) ≅ SL(2,ℝ)×SL(2,ℝ), Spin(3,3) ≅ SL(4,ℝ), Spin(2,4) ≅ SU(2,2), Spin(1,5) ≅ SL(2,ℍ) (identity components). Source: Harvey, *Spinors and Calibrations*; Lounesto, *Clifford Algebras and Spinors*. Links: ATL-005, ATL-008, ATL-011, ATL-014, GEN-007, PAG-006. Field: algebra, geometry. Script: **yes**, from even-part types and bivector algebras.
16. **Kitaev's periodic table.** The eight real symmetry classes sit at the clock values through Clifford extension problems and KO-theory, the two complex classes at the complex Clifford algebras; interactions reduce BDI from ℤ to ℤ₈ (Fidkowski–Kitaev). Source: Kitaev, "Periodic table for topological insulators and superconductors"; Fidkowski and Kitaev (as cited). Links: LAB-018, LAB-021, PAG-032, INP-080, QC3. Field: topology, algebra. Script: **partly**, the extension classes yes, the K-theory no.
17. **Pin± structures and time reversal.** Pin⁺ and Pin⁻ correspond to T² = ±1 for fermions; Ω₂^{Pin⁻} ≅ ℤ₈ is the clock, Ω₄^{Pin⁺} ≅ ℤ₁₆ classifies the 3+1-dimensional interacting class DIII. Source: Kirby and Taylor, "Pin structures on low-dimensional manifolds"; Kapustin, Thorngren, Turzillo and Wang, "Fermionic symmetry protected topological phases and cobordisms". Links: PAG-032, LAB-016, LAB-018, INP-080. Field: topology. Script: **no** for bordism, **partly** for which generators square to ±1.
18. **Peirce decompositions as Morita contexts.** For orthogonal idempotents e_i summing to 1, A = ⊕ e_iAe_j with off-diagonal pieces as e_iAe_i–e_jAe_j bimodules; for a full idempotent e, A is Morita equivalent to eAe. Source: Jacobson, *Basic Algebra II*; Lam, *Lectures on Modules and Rings*. Links: ATL-025, RSN-002, RSN-003, GEN-006. Field: category, algebra. Script: **yes**.
19. **Contractions and deformations.** ℝ[e]/(e² − t), and the Cayley–Klein family of an extra generator of square s, are one-parameter deformations; t → 0 is a contraction, and Hochschild cohomology classifies such deformations. Source: Inönü and Wigner, "On the contraction of groups and their representations"; Gerstenhaber, "On the deformation of rings and algebras". Links: GEN-002, RSN-008, RSN-022, ATL-002, ATL-003. Field: algebra, category. Script: **yes**, the Hochschild check bd·hh·5 exists.
20. **Even unimodular lattices only in rank ≡ 0 mod 8; Construction A.** The Gauss–Milgram sum gives the signature mod 8, so a positive definite even unimodular lattice has rank ≡ 0 mod 8; a doubly-even self-dual code C of length n gives such a lattice (C + 2ℤⁿ)/√2, which ties RSN-031 (Golay, Leech) to E₈ and to T14 (4). Source: Milnor and Husemoller, *Symmetric Bilinear Forms*; Conway and Sloane, *Sphere Packings, Lattices and Groups*. Links: PAG-020, RSN-031, GOS-005, LAB-018. Field: combinatorics, topology. Script: **yes** for given lattices and codes, **no** for the existence statement.
