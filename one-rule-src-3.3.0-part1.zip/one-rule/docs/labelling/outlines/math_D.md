# Chunk D (the Baez chapter, LNB-001…065 and LNB-101…178): the mathematician's labelling

143 rows labelled in `math_D.jsonl`. Kinds: 57 computation, 24 meta, 23 reading, 21 question, 6 example, 5 reduction, 3 lemma, 2 theorem, 2 dead-end. Relations drawn: 119 `derives`, 86 `equiv`, 7 `instance`, 2 `uses-input`, 0 `cycle`, 0 `contradicts`.

The chunk has three layers of the same statements: the widget rows (LNB-101…178) are the atomic statements; the research rows (LNB-014…025) are compounds of five to ten lines; the B.1–B.10 rows (LNB-002…011), the "honest" rows (LNB-047…052, 060…065) and the learner rows (LNB-053…059, 107…110, 129…131, 134…135, 153…165, 170…172, 176…178) restate them. I made the atomic rows the hubs and recorded the compounds as `derives` from their parts and the restatements as `equiv`.

---

## A. How mathematics would organise these rows

Mathematics would put the conventions first, then the algebra (octonions, Clifford, Jordan, Lie), then the lattice combinatorics as lemmas for the Lie theory, and only at the end the dictionary to one generation of fermions, which is where the page begins. The Kepler block is a self-contained appendix on real forms of so(4,ℂ) and so(6,ℂ). The physics recalls and the meta rows are not mathematics and go in a last section.

### A.0 Conventions and inputs (definitions that hide a choice)

- **LNB-106** — the names 3 and 3̄ for the colour weights (1,0) and (0,1): a choice of positive roots (input `i-J`). LNB-121, LNB-122 and line 6 of LNB-015 use it.
- **LNB-101** — the names "weak" and "colour" for the five bits and the coefficients 1/2, −1/3 in Y: an outside table (input `i-tab`). Every generation row rests on it.
- **LNB-125** — the normalisation M = e/√|2E| that makes ε = −sign E: a definition, not a result.
- **LNB-173** — the Madelung (n + ℓ) rule: an empirical rule recalled from physics; mathematics has no theorem here.

### A.1 Algebra

**A.1.1 Twisted group algebras of ℤ₂³: octonions, Zorn, the μ-family.** Definition of the product on labels (LNB-002, LNB-018 line 1), the associator as a coboundary and its count on the 168 independent triples (LNB-002, LNB-018 line 2), uniqueness of the division-algebra cochain up to gauge (LNB-018 line 1), the derivation algebra g₂ ⊃ su(3) and 𝕆 = ℂ ⊕ ℂ³ (LNB-137, LNB-018 line 3), Zorn's algebra on Λ(ℝ³) (LNB-018 line 4), the complement automorphism and its counterexample (LNB-019 line 1, LNB-029 line 1), the family CD(ℍ, μ), μ = −1, +1, 0 (LNB-019 line 2). LNB-020 is a cross-reference. Mathematical order = page order here, except that the μ-family (LNB-019 line 2) is the most general statement and would come first as the definition of which the octonions, split octonions and null octonions are the three instances.

**A.1.2 The Clifford algebra Cl(5,5), Fock space and the CAR.** Theorem for all n (LNB-147, from T20) → the instance n = 5 with the D III 3-grading of so(5,5) and the triple product of skew matrices (LNB-015) → summary (LNB-006) → the reading of states as subsets and of the number operator as the popcount (LNB-175, LNB-024 line 2) → readings and questions (LNB-040, LNB-148, LNB-162, LNB-033). The page states the instance (LNB-015) in the generation chapter and the theorem (LNB-147) in the papers widget; mathematics reverses that.

**A.1.3 Jordan algebras and triples.** The Albert algebra on the XOR octonions, its Peirce split 1 + 16 + 10, Der = f₄, the stabilisers so(8), su(3)+su(3), spin(9), so(3)+so(6) and the 12-dimensional su(2)+su(3)+u(1) (LNB-021) → consequences LNB-113, LNB-116 → the spin factor h₂(𝕆) with det of signature (1,9) and Cl(9,0) = M₁₆(ℝ)² (LNB-022 lines 1–2, LNB-151) → the recalled fact spin(9) ↷ Peirce-½ = spinors (LNB-026 line 2). Jordan data (r, a, b) and Loos's dimension formula (LNB-004, LNB-016 line 4). The Peirce value on five-bit labels, 1 − d/4 (LNB-102 → LNB-014, LNB-005, LNB-030, LNB-044). The inclusion M₂,₂ ⊂ M₃,₂ (LNB-034, LNB-041). The page scatters these over four tabs ("which", "ten", "ladder", "generation"); mathematically they are one section, Jordan structure theory, with LNB-021 as its first proposition.

**A.1.4 Lie algebras: the E₈ Levi chain, gradings, branching, conjugacy.** Root counts of the chain (LNB-118, from T10) → 3- against 5-grading (LNB-119) → the content of each rung under sl₃ ⊕ sl₂ (LNB-121) → the 16 and the eleven by Casimir class (LNB-115) → non-conjugacy of the two Standard-Model subalgebras (LNB-111, cross-checked by LNB-112) → restatements (LNB-008, LNB-139, LNB-155) and the regular/stabiliser distinction (LNB-116). The 27 as grade-1 piece of E₇ and as complex Albert algebra (LNB-141, LNB-142, LNB-143). Compounds: LNB-016, LNB-003. Questions: LNB-031, LNB-035/038/117, LNB-043, LNB-045. The page order (ladder, then "which SM") is the mathematical order; what is missing is the link from LNB-142 to LNB-021 (same 27), which the page files under "ours".

**A.1.5 The Lie algebras of the Kepler problem.** Bivector algebras and Killing counts for the squares (+,+,+,ε) (LNB-124, from T17) → so(4) = so(3) ⊕ so(3) (LNB-126) → the (j,j) shells and n² (LNB-127) → so(4,2) ⊃ so(4) and the 4 + 7 + 4 grading (LNB-145, LNB-034 line 2) → the contraction family and Fock's projection (LNB-125) → the compound (LNB-023) and summary (LNB-009). Readings: LNB-049/062/131 (spring's signs), LNB-128 (the correction), LNB-146/161. The misprint question LNB-046. Mathematically this block is "real forms and contractions of so(4,ℂ), and the 3-grading of so(6,ℂ)"; it does not depend on anything else in the chunk.

### A.2 Combinatorics, lattices, finite structures

**A.2.1 Root systems and polytopes.** LNB-118 (Levi counts), LNB-123 (the Gosset-graph route), LNB-007 (srg(27,10,1,5) and Schläfli, from T13), LNB-004 (Peirce counts from root inner products).

**A.2.2 The Eisenstein lattice.** Theta series (LNB-166) → the bound argument (LNB-168) → projection of the 126 roots (LNB-167, from T13(5)) → the identification with the triangulation lattice (LNB-169) → compound (LNB-017), summaries (LNB-010, LNB-032) and restatements (LNB-149/150/163/164/170/171/172, LNB-056). The page makes this a chapter ("the empty ring"); mathematically it is a lemma inside A.1.4 (E₇ ⊃ A₂ × A₅).

**A.2.3 The 5-cube.** The six classes and Y, Q as bit counts (LNB-101) → the sums (LNB-103) → the complement map (LNB-104, LNB-048, LNB-061) → its reading as charge conjugation (LNB-105) → learner restatements (LNB-107, LNB-108).

**A.2.4 Even unimodular lattices.** II₂,₁₈ from the triangulation form (LNB-011 line 3, LNB-022 line 4): a computation (even, unimodular, signature) plus a pointer to an unread classification theorem.

**A.2.5 Counting with the Madelung rule.** LNB-173 → LNB-174 → LNB-024, LNB-057, LNB-177/178; the reading LNB-175/176.

### A.3 Geometry

Fock's projection onto S³, ℝ³, H³ and the hodographs as geodesics (LNB-125, LNB-023 line 5); the spin factor of signature (1,9) (LNB-022, LNB-151); the conformal grading of so(2,4) (LNB-034 line 2). Everything else geometric in the sources (Thurston's moduli space, the 3-manifold applications) is a declared gap (LNB-028 line 2, LNB-012 lines 4 and 6).

### A.4 Topology

Only cohomological algebra: the octonion sign as a 2-cochain on ℤ₂³ whose coboundary is the associator 3-cocycle (LNB-018 line 1, LNB-002; T6(d)). No bordism, no manifolds. The algebra → topology link that the chunk gestures at (cochain/cocycle) is stated in LNB-018 but never as a theorem; see C.9.

### A.5 Category theory

The Frobenius forms of label algebras (LNB-025, from T3): scalar-part form non-degenerate iff r = 0, top form always; Λ(ℝ^r) a commutative, non-special Frobenius monoid in sVec; the reading of cospans as contracted bits; the question LNB-037. Declared gaps: LNB-028 line 1, LNB-012 line 7.

### A.6 Not mathematics: physics recalls and meta rows

Physics recalled or compared: anomaly sums (LNB-103), vector-like real representations (LNB-114), conics by energy (LNB-129), the Madelung rule (LNB-173, LNB-177), Hull's signature lists with the input "32 real supercharges" (LNB-011 line 2), charge conjugation (LNB-105). Meta (credit, citations, counts, gaps): LNB-012, 013, 020, 027, 028, 050, 052, 054, 059, 063, 065, 109, 120, 132–136, 138, 140, 153, 154, 156, 157. Open: LNB-033/039, 034/041, 035/038/117, 036/042/051/064/152/165, 037, 040, 043, 044, 045, 046, 144/159; dead ends LNB-026, LNB-058.

**Where the page order and the mathematical order differ, in one sentence each.** (1) The page opens with the physics headline (LNB-001, LNB-014) that mathematics reaches last. (2) The theorem Cl(n,n) = End Λ (LNB-147) sits in the last widget while its instance (LNB-015) sits in the second chapter. (3) The Jordan rows are split over four tabs. (4) "The empty ring" is a lemma for the E₇ branching, not a chapter. (5) The ten summary rows B.1–B.10 and the two honest lists duplicate the widgets; a mathematician would keep the widgets as the rows and generate the summaries from them. (6) The gap rows (LNB-027/028/052/059/065) say the same thing five times.

---

## B. Chains, classes and loops

### B.1 Chains (ordered by `derives`, left to right = "rests on")

1. **Fock chain.** T20 → LNB-147 → LNB-015 → LNB-006; LNB-015 → LNB-175 → LNB-024; LNB-015 → LNB-033; LNB-015 → LNB-040.
2. **Kepler chain.** T17 → LNB-124 → LNB-126 → LNB-127 → LNB-174 → LNB-024; LNB-126 → LNB-145 → LNB-146; LNB-124 → LNB-125 → LNB-023 → LNB-046; LNB-124 → LNB-049; LNB-124 → LNB-128.
3. **Ladder chain.** T10 → LNB-118 → LNB-119 → LNB-016; LNB-118 → LNB-121 → LNB-115 → LNB-111 → LNB-035 → LNB-045; LNB-121 → LNB-043; LNB-118 → LNB-004 → LNB-016; LNB-118 → LNB-141; LNB-118 → LNB-142 → LNB-143.
4. **Octonion → Jordan → clock chain.** T6 → LNB-002 → LNB-137 → LNB-018 → LNB-019; LNB-002 → LNB-021 → LNB-022 → LNB-036 → LNB-026; LNB-021 → LNB-113 → LNB-114 → LNB-001; LNB-021 → LNB-116 → LNB-008; LNB-021 → LNB-111.
5. **Eisenstein chain.** LNB-166 → LNB-168; LNB-166 → LNB-167 → LNB-169 → LNB-032; LNB-167 → LNB-017 → LNB-033; T13 → LNB-167.
6. **Generation chain.** LNB-101 → LNB-102 → LNB-030; LNB-102 → LNB-044; LNB-101 → LNB-103; LNB-101 → LNB-104 → LNB-105; LNB-101 → LNB-106 →(uses-input) LNB-121 and LNB-015; {LNB-101, 102, 103, 104} → LNB-014 → LNB-001.
7. **Ten chain.** T4 → LNB-022 → LNB-011 → LNB-036 → LNB-042; LNB-022 → LNB-151.
8. **Frobenius chain.** T3 → LNB-025 → LNB-037.
9. **Madelung chain.** LNB-173 → LNB-174 → LNB-178; LNB-173 → LNB-175 → LNB-176.
10. **srg / Gosset chain.** T13 → LNB-007 → LNB-016; T13 → LNB-123.

The longest chains are five rows long (T17 → LNB-124 → LNB-126 → LNB-127 → LNB-174 → LNB-024, and T10 → LNB-118 → LNB-121 → LNB-115 → LNB-111 → LNB-035 → LNB-045).

### B.2 Classes (`equiv`: the same statement in two languages or two lengths)

- One generation on five bits: {LNB-014, LNB-005, LNB-047, LNB-053}; {LNB-047, LNB-110}; {LNB-101, LNB-107}; {LNB-104, LNB-048, LNB-061, LNB-108}.
- Fock: {LNB-015, LNB-006}.
- Octonions: {LNB-002, LNB-018}; {LNB-019 line 1, LNB-029 line 1}.
- Ladder: {LNB-118, LNB-003, LNB-119, LNB-123}.
- Which Standard Model: {LNB-111, LNB-008, LNB-139, LNB-155, LNB-112, LNB-021 line 4}; {LNB-116, LNB-029 line 2}; {LNB-035, LNB-038, LNB-117}.
- Kepler: {LNB-124, LNB-009, LNB-055, LNB-130}; {LNB-049, LNB-062, LNB-131}; {LNB-125, LNB-129}; {LNB-145, LNB-034 line 2, LNB-160}; {LNB-146, LNB-161}; {LNB-148, LNB-162}.
- Eisenstein: {LNB-167, LNB-010, LNB-149, LNB-171, LNB-056}; {LNB-166, LNB-170}; {LNB-169, LNB-032, LNB-150, LNB-172, LNB-017 line 5}.
- Ten: {LNB-036, LNB-042, LNB-051, LNB-064, LNB-152, LNB-165, LNB-058 line 2}.
- Periodic table: {LNB-173, LNB-177}; {LNB-174, LNB-178, LNB-057}; {LNB-175, LNB-176}.
- Citations and map: {LNB-013, LNB-050, LNB-063, LNB-132, LNB-133, LNB-134, LNB-135, LNB-054}; instances {LNB-136, LNB-153}, {LNB-138, LNB-154}, {LNB-140, LNB-156}.
- Gaps: {LNB-027, LNB-028, LNB-052, LNB-059, LNB-065}.
- Others: {LNB-033, LNB-039}; {LNB-034, LNB-041}; {LNB-143, LNB-158}; {LNB-144, LNB-159}; {LNB-026, LNB-058}.

Of 143 rows, 57 are pure restatements (`equiv` only) of another row, and a further dozen are summaries that only combine rows. A V2 that stores one row per class and renders the three registers (research, learner, honest) from it would cut this chunk to about 75 rows.

### B.3 Loops

None. Two candidates were considered and rejected: the 3/3̄ naming (LNB-106 against LNB-121, LNB-122, LNB-015 line 6) is a convention consumed one way (`uses-input`), and ε = −sign E (LNB-125) is a definition of M chosen so that [M, M] = εL matches {A, A} = −2μH L; neither is a set of rows that support each other.

### B.4 Hubs and leaves

Hubs inside the chunk (rows most rested on): **LNB-118** (9: the E₈ Levi counts), **LNB-124** (9: the Kepler Killing counts), **LNB-166** (8: the Eisenstein theta series), **LNB-101** (8: the six classes and Y, Q on five bits), **LNB-167** (7: the 126 roots on the Eisenstein lattice); then LNB-013 (7, the citation map, a meta hub), LNB-111 and LNB-121 and LNB-169 (6 each), LNB-021, LNB-173, LNB-036 (5 each). Hubs outside the chunk: T17 (6), T13 (5), T20, T6, T10 (3 each), T4 (2), T3 (1).

Rows with no dependency at all (sources of the graph): LNB-101, LNB-166, LNB-173 (the three genuine starting points), LNB-012, LNB-013, LNB-028, LNB-109, LNB-120 (meta), LNB-144 (a question with no premise).

Leaves (nothing rests on them), 70 rows: the summaries LNB-001, 003, 005, 006, 008, 009, 010, 016, 024; the learner and honest restatements LNB-053–065, 107–110, 129–131, 134–135, 153–165, 170–172, 176–178; the readings LNB-105, 122, 128, 141, 151, 157; the questions LNB-037, 040, 042, 043, 044, 045, 046, 117; and LNB-020, 029, 030, 031, 032, 112, 123.

---

## C. Missing pieces

Standard mathematics the chunk uses without stating, or that would turn a range into a theorem, or that links rows the Atlas keeps apart. Most consequential first. "Check" says whether the Atlas's engine could compute it.

1. **ℤ-gradings by a simple coroot and the marks of the highest root.**
   Statement: deleting the node α_i of a simple root system grades the Lie algebra by the α_i-coefficient; the grading has 2m_i + 1 pieces where m_i is the coefficient of α_i in the highest root; it is 3-graded iff m_i = 1 (cominuscule node) and 5-graded iff m_i = 2. For E₈ the mark of α₈ is 2 and the marks of α₇ in E₇, α₆ in E₆, α₅ in D₅, α₄ in A₄ are 1.
   Source: V. Kac, *Infinite-dimensional Lie algebras* (the chapter on gradings and Kac coordinates); N. Bourbaki, *Lie Groups and Lie Algebras, Chapters 4–6* (the planches with the highest-root coefficients).
   Links: LNB-119, LNB-003, LNB-016 line 2, LNB-118. Turns "the first step is 5-graded, the others 3-graded" from a computed fact into a line read off a table. Field: algebra. Check: yes (the marks are in the enumerated roots).

2. **E₆ ⊃ D₅ ⊕ u(1): 27 = 1 + 10 + 16.**
   Statement: under the Levi so(10) of e₆ (delete α₆) the 27 splits as singlet + vector + half-spinor; under sl₃ ⊕ sl₂ ⊂ sl₅ ⊂ so(10) the 10 is 5 ⊕ 5̄ = (3,1)+(1,2)+(3̄,1)+(1,2) and the 1 is (1,1).
   Source: R. Slansky, *Group theory for unified model building* (Physics Reports 79, the branching tables); J. F. Adams, *Lectures on Exceptional Lie Groups*.
   Links: LNB-043, LNB-016 line 8, LNB-121, LNB-115. It answers the Atlas's suggested check: the eleven extra states are exactly the 10 + 1 of so(10), and the (3,1)+(3̄,1)+2(1,2)+(1,1) of LNB-016 line 6 is their decomposition. Field: algebra. Check: yes (sort the 27 enumerated roots by their α₆-coefficient inside E₆).

3. **E₇ ⊃ A₂ × A₅ and E₇ ⊃ A₁ × D₆ branching of the adjoint.**
   Statement: 133 = (8,1) + (1,35) + (3,15) + (3̄,15̄) under sl₃ ⊕ sl₆, and 133 = (3,1) + (1,66) + (2,32) under sl₂ ⊕ so(12); the Atlas already has the companion 56 = (3,6) + (3̄,6̄) + (1,20) in T13(5). The 90 = (3,15) ⊕ (3̄,15̄) is 3 ⊗ 15 ⊕ 3̄ ⊗ 15̄ with the generation sl₃ acting on the 3; the three V_k are its weight spaces for a Cartan element of that sl₃, each completed to 32 by two root vectors of the sl₃ (3 × 32 = 90 + 6, the count of LNB-017 line 4).
   Source: Slansky, as above; W. G. McKay and J. Patera, *Tables of dimensions, indices, and branching rules for representations of simple Lie algebras*.
   Links: LNB-017 line 4 (the A₅/D₆ profiles and 133 = 35 + 2 + 3·32), LNB-033/039 (P4), LNB-144. It is the structure P4 asks for, with a precise limit: the 30 non-singlet states of each V_k do form one label space (Λ²ℂ⁶ ⊕ Λ⁴ℂ⁶ = 15 ⊕ 15̄) tensored with the 3 of the generation sl₃, while the two extra states per V_k are sl₃ root vectors and do not fit the tensor pattern. Field: algebra. Check: yes (weights from the enumerated roots).

4. **The 27 of E₆ is the complex Albert algebra (Chevalley–Schafer; Freudenthal).**
   Statement: e₆(ℂ) is the Lie algebra of linear maps of h₃(𝕆)⊗ℂ preserving the cubic norm det; it equals Der ⊕ {multiplications by traceless elements} = f₄ ⊕ 26; f₄ is the derivation algebra and the 27 restricts to 1 + 26.
   Source: C. Chevalley and R. D. Schafer, *The exceptional simple Lie algebras F₄ and E₆*; H. Freudenthal, *Lie groups in the foundations of geometry*; J. Baez, *The Octonions* (the sections on F₄ and E₆); T. A. Springer and F. D. Veldkamp, *Octonions, Jordan Algebras and Exceptional Groups*.
   Links: LNB-142, LNB-143, LNB-158 (filed as "ours", in fact standard), LNB-021 line 4 ("the 27 of e₆ restricts to h₃(𝕆) = 1 + 26 under f₄"), LNB-111. It is the bridge between the Jordan rows (A.1.3) and the Lie rows (A.1.4). Field: algebra. Check: partly (build f₄ ⊕ h₃⁰ on the XOR Albert algebra and test closure numerically: yes; the identification with the root-built e₆ needs an isomorphism, which is a finite computation too).

5. **Λ^ev ℂ⁵ as the 16 of Spin(10) and the Standard Model group S(U(2) × U(3)).**
   Statement: the half-spin representation of so(10) is Λ^ev ℂ⁵; restricted to sl₅ ⊂ so(10) and then to s(u(2) × u(3)) it is one generation, with hypercharge the u(1) weight; the full Λℂ⁵ = 16 ⊕ 16̄ is a generation plus its antiparticles; the group is S(U(2) × U(3)) = (SU(2) × SU(3) × U(1))/ℤ₆.
   Source: J. Baez and J. Huerta, *The algebra of grand unified theories* (Bull. AMS 47); F. Wilczek and A. Zee, *Families from spinors*.
   Links: LNB-101, LNB-014, LNB-047, LNB-015 (Cl(5,5) on the 32), LNB-104, LNB-021 line 7 and LNB-028 line 4 (groups and the ℤ₆ quotient, declared untested). It is the standard home of the whole generation block and it links the label rows to the Clifford rows (the 16 is a Clifford module of Cl(10)). Field: algebra. Check: partly (Lie-algebra level: yes, already done; the ℤ₆ quotient: a finite matrix computation).

6. **The complement map as the Hodge star and as charge conjugation.**
   Statement: on Λℂⁿ the map e_S ↦ ±e_{S̄} is the Hodge star; for odd n it exchanges Λ^ev and Λ^odd, i.e. the two half-spin representations 16 and 16̄ of so(10), and negates every weight of the Cartan subalgebra of sl₅, hence Y and Q.
   Source: H. B. Lawson and M.-L. Michelsohn, *Spin Geometry* (Chapter I, the exterior algebra as a Clifford module); Baez–Huerta as above.
   Links: LNB-104, LNB-048, LNB-061, LNB-105, LNB-014 line 5, LNB-019 line 1 (the signed complement of the Zorn algebra is the same map on Λℝ³). Turns a `lemma` checked at n = 5 into the general statement, and makes the reading "charge conjugation" standard. Field: algebra, geometry. Check: yes (for all n with the engine's complement move).

7. **Loos's Peirce decomposition for tripotents and frames; the classification of simple Hermitian Jordan triples by (r, a, b).**
   Statement: a tripotent e splits V into Peirce spaces V₀, V_½, V₁; a frame of r orthogonal minimal tripotents splits V into joint Peirce spaces V_ij, 0 ≤ i ≤ j ≤ r, of dimensions 1 (i = j ≥ 1), a (0 < i < j), b (i = 0 < j), giving dim V = r + a·r(r−1)/2 + b·r; the simple types are listed with their (r, a, b).
   Source: O. Loos, *Bounded Symmetric Domains and Jordan Pairs* (lecture notes, Irvine 1977); O. Loos, *Jordan Pairs* (Lecture Notes in Mathematics 460).
   Links: LNB-004, LNB-016 line 4, LNB-102, LNB-044, LNB-030, LNB-014. Definitions the rows use without stating: tripotent, Peirce space, colinear tripotents. The question LNB-044 ("is 1 − d/4 in Loos?") is the question whether the joint Peirce grid of two colinear tripotents, read on the Fock labels, is the Hamming-distance formula; the definition above is where to look. Field: algebra. Check: partly (the dimension identities yes; the structure theory is recalled).

8. **The Kantor–Koecher–Tits construction and Hermitian symmetric spaces.**
   Statement: a Jordan pair (V⁺, V⁻) gives a 3-graded Lie algebra V⁻ ⊕ str(V) ⊕ V⁺ and every 3-graded simple Lie algebra arises so; the simple real cases are the Hermitian symmetric spaces of Cartan's list (A III, BD I, C I, D III, E III, E VII), with so(2m)/u(m) = D III for skew matrices and su(2,2) ≅ so(4,2) = A III(2,2) ≅ BD I(4,2).
   Source: I. Satake, *Algebraic Structures of Symmetric Domains*; S. Helgason, *Differential Geometry, Lie Groups, and Symmetric Spaces* (the chapter on Hermitian symmetric spaces); Loos, as above.
   Links: LNB-015 lines 3–4 (D III and the skew triple product), LNB-119 (why the 3-graded steps are the Jordan triples), LNB-034, LNB-041, LNB-145 (A III = BD I at n = 4), LNB-016 line 3. It is the theorem behind the whole "chain of triples = chain of Levi factors" correspondence, which the page treats as two parallel tables. Field: algebra. Check: partly (the gradings yes; the equivalence is a theorem).

9. **Albuquerque–Majid: the octonions as a twisted group algebra of ℤ₂³ in a braided monoidal category.**
   Statement: 𝕆 = ℂ_F[ℤ₂³] for a 2-cochain F whose coboundary dF = (−1)^{det(a,b,c)} is a non-trivial 3-cocycle; the algebra is associative in the monoidal category of ℤ₂³-graded spaces with associator dF, and the Clifford algebras are the case of a cocycle (dF = 1).
   Source: H. Albuquerque and S. Majid, *Quasialgebra structure of the octonions* (J. Algebra 220).
   Links: LNB-002, LNB-018 line 1 (which states the coboundary but not the categorical content), LNB-020 ("a finding of the category lens"), T6(d), QB3. This is the algebra → category and algebra → topology (H³(ℤ₂³; ℤ₂)) link the Atlas names but does not draw as a row. Field: category, topology. Check: yes (T6(d) already computes the finite part; the 3-cocycle condition on dF is a 4096-entry check).

10. **Composition algebras, alternativity and Hurwitz's theorem; Zorn's vector-matrix algebra.**
   Statement: a unital composition algebra over ℝ has dimension 1, 2, 4 or 8 and is ℝ, ℂ, ℍ, 𝕆 or a split form; composition algebras are alternative; the split octonions are Zorn's vector matrices with the product written through the cross product, i.e. join and meet on Λℝ³.
   Source: Springer–Veldkamp, as above (the first chapters); R. D. Schafer, *An Introduction to Nonassociative Algebras*; J. H. Conway and D. A. Smith, *On Quaternions and Octonions*.
   Links: LNB-018 (uses "alternative", "normed", "composition" without definition and checks them numerically), LNB-019 (null octonions: Schafer's "degenerate" Cayley–Dickson case), LNB-002. Field: algebra. Check: yes (exact rational checks replace the random-vector ones).

11. **Spin(9) acts on the Peirce-½ space of h₂(𝕆) ⊂ h₃(𝕆) as on its 16-dimensional real spinor module.**
   Statement: the stabiliser of h₂(𝕆) in F₄ is Spin(9), and h₃(𝕆) = h₂(𝕆) ⊕ 𝕆² ⊕ ℝ with 𝕆² = ℝ¹⁶ the real spinor representation of Spin(9); the 9-dimensional traceless part of h₂(𝕆) is the vector representation.
   Source: Baez, *The Octonions* (the section on F₄); F. R. Harvey, *Spinors and Calibrations*.
   Links: LNB-022 line 2, LNB-026 line 2 (recalled, not computed), LNB-021 (stabiliser 36 and Peirce 16 computed separately). Field: algebra. Check: yes (compare the computed 36-dimensional stabiliser's action on the 16 with the Cl(9,0) spinor module by Casimir or by an explicit intertwiner).

12. **Majorana–Weyl spinors exist exactly when p − q ≡ 0 mod 8.**
   Statement: Cl(p,q) with p + q = 2k even is M_{2^k}(ℝ) iff p − q ≡ 0, 2 mod 8, and the volume element squares to +1 iff p − q ≡ 0, 1 mod 4; both hold iff p − q ≡ 0 mod 8, and then the real spinor module splits into two real half-spin modules of dimension 2^{k−1}.
   Source: Lawson–Michelsohn, *Spin Geometry* (Chapter I, the classification tables); P. Lounesto, *Clifford Algebras and Spinors*.
   Links: LNB-011 line 1, LNB-022 line 5, LNB-036, LNB-042. The Atlas reads the three signatures off a table (`range` over eleven cases); T4 plus the volume-element sign gives the theorem for all (p,q). Field: algebra, geometry. Check: yes.

13. **Classification of indefinite even unimodular lattices.**
   Statement: an even unimodular lattice of signature (r,s) with r, s ≥ 1 exists iff r ≡ s mod 8 and is then unique up to isometry: II_{r,s} ≅ U^{⊕ min(r,s)} ⊕ E₈(±1)^{⊕ |r−s|/8}.
   Source: J.-P. Serre, *A Course in Arithmetic* (Chapter V); J. Milnor and D. Husemoller, *Symmetric Bilinear Forms*.
   Links: LNB-011 line 3, LNB-022 line 4 ("pointer, source unread"), LNB-036. Turns the pointer into a standard result; the Atlas computes even, unimodular and signature (2,18) and the theorem does the rest. Field: algebra, combinatorics. Check: partly (the hypotheses yes; uniqueness is the theorem).

14. **Representation numbers of the Eisenstein norm form.**
   Statement: the number of (x, y) ∈ ℤ² with x² − xy + y² = N is r(N) = 6 Σ_{d | N} χ₋₃(d), χ₋₃ the character mod 3; in particular r(N) = 0 whenever N ≡ 2 mod 3, and the theta series of the hexagonal lattice is 1 + 6q + 6q³ + 6q⁴ + 12q⁷ + ….
   Source: J. H. Conway and N. J. A. Sloane, *Sphere Packings, Lattices and Groups* (Chapter 4, the hexagonal lattice and its theta series); D. A. Cox, *Primes of the Form x² + ny²*.
   Links: LNB-166 (a `range`, N ≤ 7), LNB-168, LNB-170, LNB-032. Turns "nothing at N = 2" into a theorem for all N ≡ 2 mod 3 and gives every ring size. Field: combinatorics. Check: yes (count up to any N and compare with the divisor sum).

15. **The weight lattice of A₂ is the hexagonal lattice; the root lattice is its index-3 sublattice.**
   Statement: the weight lattice of A₂ with the Killing-normalised form (fundamental weights of squared length 2/3, roots of squared length 2) is, after scaling by 3/2, the Eisenstein lattice ℤ[ω] with norm x² − xy + y²; the roots are the norm-3 vectors, the weights ±w_k the norm-1 vectors.
   Source: Conway–Sloane, as above (A₂ and its dual lattice A₂*); Bourbaki, *Lie Groups and Lie Algebras, Chapters 4–6* (planche for A₂).
   Links: LNB-169, LNB-032, LNB-150, LNB-172, LNB-017 line 5 (all "ours"). The identification is standard; only the pairing of the two papers is the Atlas's. Field: combinatorics, algebra. Check: yes.

16. **Thurston's moduli space of flat spheres with 12 cone points and the complex hyperbolic signature (1,9).**
   Statement: the triangulations of the sphere with at most 6 triangles at each vertex correspond to lattice points of a hermitian Eisenstein lattice of signature (1,9); the moduli space of such flat metrics is a complex hyperbolic orbifold ℂH⁹/Γ with Γ ⊂ PU(1,9; ℤ[ω]); the number of triangles is the hermitian norm.
   Source: W. P. Thurston, *Shapes of polyhedra and triangulations of the sphere* (Geometry & Topology Monographs 1).
   Links: LNB-012 line 6, LNB-022 lines 3–4, LNB-028 line 2, LNB-036/042/051/064/152/165 (the open "real 10 vs complex 10"). Mathematics puts the (1,9) in PU(1,9) (complex hyperbolic geometry), not in SO(1,9) (Lorentzian geometry); the real form of the lattice is II₂,₁₈ with isometry group O(2,18), which is where the Atlas's own computation already points. This reframes the open question rather than answering it. Field: geometry. Check: no (moduli space); partly (the form, already done).

17. **Fock's theorem and Moser's regularisation.**
   Statement: at fixed energy E < 0 the Kepler flow in momentum space is, after stereographic projection, the geodesic flow on S³ up to reparametrisation; for E > 0 on H³ and for E = 0 on ℝ³; the Runge–Lenz and angular-momentum vectors generate the isometry algebra of the target.
   Source: V. Fock, *Zur Theorie des Wasserstoffatoms* (Z. Phys. 98); J. Moser, *Regularization of Kepler's problem and the averaging method on a manifold* (Comm. Pure Appl. Math. 23); V. Guillemin and S. Sternberg, *Variations on a Theme by Kepler*.
   Links: LNB-125, LNB-023 line 5 ("Fock and Moser: pointers, sources unread"). The sources make the Atlas's numerical checks bd·kep·3–6 instances of a theorem. Field: geometry, analysis. Check: partly (the isometry and the hodograph → geodesic are already checked numerically).

18. **Inönü–Wigner contraction; the Killing form of a non-semisimple algebra.**
   Statement: so(4) and so(3,1) contract to e(3) as the parameter c → 0; the Killing form of e(3) is degenerate with radical the translations, so "signature (0,3,3)" is the signature of a degenerate form.
   Source: E. Inönü and E. P. Wigner, *On the contraction of groups and their representations* (PNAS 39); R. Gilmore, *Lie Groups, Lie Algebras, and Some of Their Applications*.
   Links: LNB-124, LNB-125, LNB-009, LNB-049, LNB-055, LNB-130 (definitions used without statement: Killing form, contraction). Field: algebra. Check: yes (already done; the definition is what is missing).

19. **so(4,2) ≅ su(2,2): the conformal algebra of Minkowski space and the dynamical algebra of hydrogen.**
   Statement: so(4,2) is the Lie algebra of the conformal group of ℝ^{1,3}, 3-graded by the dilatation (4 + 7 + 4); it contains the compact so(4) = su(2) ⊕ su(2) of the bound Kepler problem, and the bound states of hydrogen form a single unitary irreducible representation of it.
   Source: A. O. Barut and R. Rączka, *Theory of Group Representations and Applications*; A. O. Barut and H. Kleinert, *Transition probabilities of the hydrogen atom from noncompact dynamical groups* (Phys. Rev. 156).
   Links: LNB-145, LNB-034, LNB-041, LNB-160, LNB-023 line 8. The "hydrogen as a Jordan-pair system" question (P5) is, at the Lie-algebra level, the known dynamical-group picture. Field: algebra. Check: yes (the grading is done; the irreducibility on the shells is a finite check per n).

20. **Dynkin's classification of regular subalgebras and the conjugacy problem.**
   Statement: regular subalgebras of a simple Lie algebra are classified by subsets of extended Dynkin diagrams (Borel–de Siebenthal, Dynkin); two subalgebras with different branching of a faithful representation are not conjugate; equal branching ("linear equivalence") does not imply conjugacy.
   Source: E. B. Dynkin, *Semisimple subalgebras of semisimple Lie algebras* (Mat. Sbornik 1952; AMS Translations series 2, vol. 6); A. N. Minchenko, *The semisimple subalgebras of exceptional Lie algebras*.
   Links: LNB-045 (the table it asks for exists in these sources), LNB-111 (the test used), LNB-116, LNB-035/038/117. Field: algebra. Check: partly (regular embeddings from the roots: yes; the non-regular sl₃ ⊕ sl₂ in so(10): no).

21. **Branchings e₆ ⊃ f₄ and f₄ ⊃ su(3) ⊕ su(3).**
   Statement: 27 → 1 + 26 under f₄; 26 → (8,1) + (3,3) + (3̄,3̄) under su(3) ⊕ su(3) ⊂ f₄, so 27 → (1,1) + (1,8) + (3,3) + (3̄,3̄) (the two su(3) factors are exchanged by the conventions of LNB-112).
   Source: Slansky, as above; Adams, *Lectures on Exceptional Lie Groups*.
   Links: LNB-021 line 4, LNB-112, LNB-111, LNB-008. Makes the recalled decomposition of Lemma 4 a table entry and lets the two Casimir tables be derived rather than computed. Field: algebra. Check: yes.

22. **Gosset polytopes, the E_n root graphs and strongly regular graphs.**
   Statement: the vertex figures of the Gosset polytopes 4₂₁ ⊃ 3₂₁ ⊃ 2₂₁ ⊃ 1₂₁ ⊃ 0₂₁ have 56, 27, 16, 10, 6 vertices, the W(E_n)-orbits of a fundamental weight; the graph of 2₂₁ is the Schläfli graph srg(27,16,10,8). Definition used without statement: srg(v,k,λ,μ).
   Source: H. S. M. Coxeter, *Regular Polytopes* and *The polytope 2₂₁, whose twenty-seven vertices correspond to the lines on the general cubic surface* (Amer. J. Math. 62); A. E. Brouwer and H. Van Maldeghem, *Strongly Regular Graphs*.
   Links: LNB-123, LNB-118, LNB-007, LNB-016 line 5, T10(5), T13. Field: combinatorics. Check: yes (done at range level).

23. **Frobenius algebras in sVec and 2-dimensional TQFTs; special against non-special.**
   Statement: commutative Frobenius algebras in a symmetric monoidal category are the same as 2d TQFTs valued in it; the algebra is special (m∘Δ = id) iff it is separable; Λ(ℝ^r) with the Berezin integral as counit is the standard commutative, non-semisimple, non-special example in sVec.
   Source: J. Kock, *Frobenius Algebras and 2D Topological Quantum Field Theories*; L. Abrams, *Two-dimensional topological quantum field theories and Frobenius algebras*.
   Links: LNB-025 lines 2–4, LNB-037, T3 (sVec clause), QA4, QA5. The link from the algebra rows (T3, LNB-025) to the category rows that the Atlas does not draw: "the top-label form on Λ(ℝ^r) is a 2d TQFT in sVec with m∘Δ nilpotent". Field: category. Check: partly (the finite identities yes; the correspondence is a theorem).

24. **Structured cospans and the Frobenius law of wires.**
   Statement: for a functor L: A → X with a left adjoint, structured cospans L(a) → x ← L(b) form a symmetric monoidal double category; in a category of relations or corelations the "identify variables" composition is governed by a special commutative Frobenius algebra on each object (the Frobenius law of Carboni–Walters).
   Source: J. Baez and K. Courser, *Structured cospans* (Theory and Applications of Categories 35); B. Fong, *Decorated cospans* (TAC 30); A. Carboni and R. F. C. Walters, *Cartesian bicategories I* (J. Pure Appl. Algebra 49).
   Links: LNB-025 line 1 (the contraction reading), LNB-037, LNB-028 line 1, LNB-012 line 7. It says precisely which Frobenius structure the cospan paper means (special, on wires), and so why the Atlas's non-special Λ(ℝ^r) is not that structure, as LNB-025 line 4 suspects. Field: category. Check: no.

25. **Anomaly freedom of the 16 of Spin(10).**
   Statement: the cubic trace tr(T_a{T_b, T_c}) vanishes on every representation of a Lie algebra with no independent cubic Casimir; so(10) has none, so every subgroup representation obtained by restricting the 16 is anomaly-free, which is the reason the five sums over the 16 labels vanish.
   Source: H. Georgi and S. L. Glashow, *Gauge theories without anomalies* (Phys. Rev. D 6); S. Okubo, *Gauge groups without triangular anomaly* (Phys. Rev. D 16).
   Links: LNB-103, LNB-014 line 4, LNB-053 line 4, LNB-001. Turns five computed sums into one representation-theoretic sentence. Field: algebra. Check: yes (the sums are computed; the cubic Casimir statement is a table fact).

**Definitions used without statement, collected:** tripotent and Peirce space (7); Levi subalgebra and ℤ-grading (1); Killing form and contraction (18); strongly regular graph (22); theta series (14); composition algebra, alternative, normed (10); Casimir class as used for branching (20, 21); Majorana–Weyl (12); Frobenius algebra, special, sVec (23); hermitian lattice of signature (1,9) (16).

**Ranges that the items above turn into theorems:** LNB-166 (14), LNB-011 line 1 / LNB-022 line 5 (12), LNB-119 (1), LNB-104 (6), LNB-025 line 2 (already T3), LNB-123 (22), LNB-167 (already T13(5); 15 for the Eisenstein reading).

**Links across fields that the Atlas does not draw:** algebra → category/topology through the octonion cochain (9); algebra → category through the TQFT reading of the top-label form (23, 24); Jordan rows → Lie rows through the complex Albert algebra (4) and the Kantor–Koecher–Tits construction (8); label rows → Clifford rows through the spinor 16 (5, 6); lattice rows → Lie rows through the A₂ weight lattice (15) and the branchings (2, 3).
