# Chunk B labelled by the physicist (equations page, steps 2–16 and the tally)

172 rows labelled in `phys_B.jsonl` (validator: 0 problems). Stages: K 59, F 53, D 27, M 21, O 10, A 2. Types: identity 37, definition 36, postulate 23, open 16, calibration 15, reading 14, derivation 12, symmetry 7, solution 6, negative 5, observable 1. Most used notions: biv 62, i-act 54, cnx 43, i-chart 39, src 37, mod 33, nul 32, s-phy 32, i-J 31. Phenomena: gravity 45, electron 40, mechanics 35, light 26, gauge 26, black-hole 22, matter 16, cosmology 13, lattice 6, qm 2.

## A. How physics would organise these rows

Physics builds this chunk in eight layers, from the frame algebra down to data. The Atlas's order (steps 2, 3, 4, 5, 6, 7, 8, 9–10, 11, 12, 13, 14, 15, 16) is close, with four differences, listed after the outline.

**A1. Conventions of the frame (stage K, all inputs).** You fix these before writing any equation, and most are restated once per step.
- Signature and which generator is time: INP-025, INP-047, INP-057 (one class with INP-086); PGA signature INP-051, kinetic sign INP-063.
- Time orientation and the positive involution: INP-020, INP-023, INP-030, INP-043, INP-070 (one datum, five restatements).
- Reversion versus Clifford conjugation, Pin±: INP-018, INP-019, INP-065, INP-073, INP-078.
- The complex structure J (the Dirac i): INP-024, INP-031, INP-042, INP-067, INP-068.
- Grades assigned to fields: INP-022, INP-029, INP-038, INP-046.
- Time parameter and flat chart: INP-064, INP-074, INP-077; INP-026 (with INP-003).

**A2. Kinematic groups (stage K).** Lie algebras, reflections, spinors and null structure: everything that needs no field equation.
- Lorentz algebra from bivectors: EQN-007, EQN-003, EQN-002; so(3) triangles YM-001, YM-003.
- Reflections and versors: EQN-014, MIR-001, MIR-002, MIR-003, MIR-005, MIR-006, NUL-009, PRJ-003.
- One extra generator, a family of kinematic groups (Poincaré, de Sitter, anti-de Sitter; Euclid, elliptic, hyperbolic), conformal so(2,4): PRJ-001, PRJ-002, EQN-015, PRJ-004, NUL-008.
- Galilei and Carroll as contractions; proper time: RIG-007, NUL-012, EQN-021.
- Spinors and the kinds of i: EQN-017, SPN-001, INP-066, CPL-003, NUL-011.
- Null hypersurfaces and the little group: NUL-004, LAB-007, NUL-002.

**A3. Free fields and their characteristics (stage F).** EQN-001, EQN-006 (Maxwell); EQN-008, INP-021, INP-069 (Dirac); NUL-010 (principal symbols: wavefronts on null surfaces, n(n−3)/2 graviton modes).

**A4. Interactions (stage F).** In this order: the action principle (CPL-011, outside the chunk), then abelian, non-abelian and matter.
- Abelian coupling: INP-027, INP-028, INP-032, EQN-009, CPL-001, CPL-002, CPL-009, CPL-005, CPL-004, CPL-006, CPL-007.
- Yang–Mills: INP-033, INP-034, INP-035, INP-036, EQN-010, YM-002, YM-004, YM-005; which algebra: YM-006.
- Charged matter: INP-037–INP-041, EQN-011, MAT-001, MAT-003, MAT-002, MAT-004, MAT-005, MAT-006.

**A5. Gravity as a gauge theory (stage F).** Physics puts the action first: geometry, then action, then field equation, then its identities.
- Geometry: EQN-012, GRV-001, GRV-002, GRV-006, GRV-009; the frame as gauge: INP-044, INP-045, INP-055.
- Action and field equation: GRV-005, INP-048, GRV-010, EQN-013; Bianchi identity as a Noether identity: GRV-008.
- Cosmological constant and the extra generator: GRV-007, INP-049, PRJ-006; conformal/Cartan geometry: GRV-004.
- Matter sources and spin: GRV-011, INP-050, GRV-003, CPL-008.

**A6. Exact solutions, horizons, tides (stage D).** GRV-012, INP-054, INP-056 (Schwarzschild–(anti-)de Sitter in a class); INP-058 (Kerr checked); MAT-007, YM-007 (Reissner–Nordström); LAB-005 (Newtonian limit, perihelion); LAB-006 (deviation, tidal tensor, Weyl); NUL-001, NUL-003, LAB-008, EQN-020, INP-059, INP-060 (surface gravity, first law, Smarr, Komar).

**A7. Mechanics as the weak-field end (stage D).** Newton–Euler: INP-061, INP-062, EQN-016, FRQ-001, FRQ-002. Free top in three geometries: PRJ-005, FRQ-005. Springs and lattices: INP-071, INP-072, EQN-018, SPR-001, SPR-003, SPR-004, RIG-006. Rigid bodies in gravity: INP-075, EQN-019, RIG-001, RIG-002.

**A8. Observation and calibration (stage O).** κ = 8πG: INP-050. The ephemeris comparison: RIG-005, INP-076. Textbook systems recovered: CPL-004, YM-004, MAT-004. The Born rule in Cl(3,0): SPN-004. The Standard Model's chirality: MAT-006.

**A9. Method rows (stage M).** PAG-021, PAG-022, PAG-023, PAG-024, MIR-004, SPN-002, SPN-003, SPN-005, SPR-002, RIG-003, RIG-004, CPL-010, YM-008, MAT-008, FRQ-003, FRQ-004, NUL-005, NUL-006, NUL-007, EQN-004.

**Where the Atlas's order and the physics order differ.**
1. **Step 11 (projective) is kinematics.** It belongs straight after step 3 (mirrors), as A2 does. Only its Λ reading (PRJ-006) needs step 10.
2. **Step 5 (spin) comes before step 4 (Dirac) in physics.** Spinors are kinematics; the Dirac equation is a field equation built on them.
3. **The gravity action comes after its identities in the Atlas.** GRV-005, flagged open, follows the curvature identities. Physics states the action first and reads the Bianchi identity as its Noether identity (GRV-008). GRV-011 holds five topics that physics teaches as separate sections: the Newtonian limit, scalar and Maxwell sources, FRW, Einstein–Cartan–Dirac with the contact term, the Dirac stress.
4. **Steps 14–16 (mechanics) are the weak-field end of gravity.** In the "algebra down to dynamics" order they come after A6. The Atlas already joins them through EQN-019 (the weight line from the Einstein form) and INP-075, but it keeps Newton's law as an input of step 16. Step 12 (the gauge tab: LAB-005–LAB-008) and step 13 (null surfaces) are solutions and belong together in A6.

## B. Chains, classes and loops

**Chains (`derives`, read right to left: each row rests on the next).**
- **The gravity spine, the longest chain (10 rows):** T1 → EQN-012 (structure equations, Bianchi) → GRV-006 (ω as a function of e) → GRV-010 (E_a is the Einstein tensor) → GRV-012 (Schwarzschild–(anti-)de Sitter in the radial Kerr–Schild class) → GRV-007 (Λ = 3c, Cartan flatness at c = H²) → GRV-004 (Weyl and Petrov machinery) → LAB-006 (tidal tensor) → EQN-019 / RIG-002 (multipole forque of an extended body) → PAG-024.
- **Its branches:** GRV-012 → LAB-005 (Newtonian limit, perihelion) → LAB-007, MIR-005, INP-075. GRV-012 → MAT-007 (Reissner–Nordström) → CPL-008, YM-007, INP-050. GRV-007 → PRJ-006 (Λ sign; Kaluza–Klein sign). GRV-010 → GRV-011 (matter sources) → EQN-019, INP-075, CPL-008. GRV-010 → NUL-010, INP-045, INP-058, EQN-013.
- **Horizons:** T18 + GRV-006 → NUL-001 (surface gravity, first law) → NUL-003 (κ² = −½∇ξ·∇ξ), EQN-020, LAB-008.
- **Identities:** T1 → GRV-002 → GRV-008 (Noether identity) → GRV-009. GRV-001 + GRV-002 → GRV-003 (Lichnerowicz).
- **Gauge:** T1 → EQN-007 → YM-001 → MAT-001, YM-004. EQN-010 → MAT-003 → MAT-002, MAT-004. EQN-007 + EQN-014 → MIR-002.
- **Coupling:** EQN-008 → CPL-001. EQN-009 → CPL-002 → CPL-009. CPL-002 + CPL-003 → CPL-007. CPL-003 → CPL-004.
- **Projective and mechanics:** T1 + T2 → PRJ-001 → PRJ-004 → PRJ-005 → FRQ-005. PRJ-001 → NUL-008, FRQ-003. PRJ-002 → EQN-015 → GRV-004, PRJ-006. EQN-016 → PRJ-005, RIG-002.
- **Springs:** T19 (with T17, T20) → EQN-018, SPR-001, SPR-003, SPR-004, INP-072.
- **Galilei/Carroll:** EQN-021 + RIG-007 + T17 → NUL-012.

**Every chain is one-way.** No `derives` edge returns from dynamics to the algebra. The places where physics would make a chain two-way are items C1, C2, C4 and C5 of section C.

**Classes (`equiv`).**
- **The same step stated on three or four pages** (tally row, map row, step row, report row). 16 classes:
  - EQN-007 / EQN-003 / MAP-016
  - EQN-006 / MAP-003 / PAG-008
  - EQN-008 / MAP-017
  - EQN-009 / MAP-018 / CPL-004
  - EQN-010 / MAP-019 / YM-004
  - EQN-011 / MAP-020 / MAT-004
  - EQN-012 / MAP-021 / GRV-002
  - EQN-014 / MAP-022 / RSN-007
  - EQN-015 / MAP-023
  - EQN-016 / MAP-024 / FRQ-001 / RSN-005
  - EQN-017 / MAP-025 / SPN-001 / RSN-011
  - EQN-018 / MAP-026 / SPR-001
  - EQN-019 / MAP-027 / RIG-001 / RSN-006
  - EQN-020 / MAP-028
  - plus the report twins GRV-001 / RSN-018, MIR-001 / RSN-023, PRJ-002 / RSN-022, NUL-001 / RSN-015, NUL-002 / RSN-020, NUL-003 / RSN-021, LAB-005 / RSN-017, RIG-006 / MAP-033.
  
  These classes are where V2 can keep one row and several renderings.
- **The same fact twice within the chunk:**
  - LAB-007 / NUL-004 (one null in two algebras)
  - MIR-006 / NUL-009 (no mirror in a null vector)
  - GRV-012 / INP-054 (Schwarzschild derived in a class)
  - INP-045 / INP-055 (frame gauge)
  - INP-060 / NUL-005
  - INP-066 / SPN-002
  - GRV-007 / LNS-034 (Λ and the extra generator)
- **One datum restated per step:**
  - time orientation (INP-020, INP-023, INP-030, INP-043, INP-070)
  - signature (INP-025, INP-047, INP-057, INP-086)
  - J (INP-024, INP-031, INP-042, INP-067)
  - reversion (INP-065, INP-073, INP-078)
  - time parameter (INP-064, INP-074, INP-077)
  - flat chart (INP-003, INP-026)
  - covariant derivative (INP-036, INP-041)
  
  Each should be one input row cited by every step.

**Loops (`cycle`).**
- INP-049 ↔ GRV-007: which sign of c is de Sitter is a convention fixed by consistency across the static, cosmological and Cartan-curvature routes.
- INP-050 ↔ GRV-011: the size and sign of κ are an input that the Newtonian limit calibrates (κ = 8πG, attraction).
- Two more loops are implicit and not written as edges: CPL-005 with PAG-008 (positive field energy fixes the relative sign of source and force), and GRV-005 → GRV-008 → GRV-011 (the action gives the field equation, whose Noether identity forces the matter equation: conservation is a consequence, not an input).

**Hubs (most dependants, all relations).**
- Outside the chunk: T18 (10: all null-surface rows, LAB-005, LAB-007, EQN-020), CPL-011 (9 instances: every action row), T1 (5), T19 (5).
- In the chunk: GRV-010 (7), GRV-006 (6), GRV-011 (6), GRV-012 (5), INP-050 (5, input).
- Next: LAB-005, GRV-002, EQN-012, and the inputs INP-021, INP-024, INP-026, INP-027, INP-033, INP-039, INP-044, INP-046, INP-049 (4 each).

**Leaves (78 rows nothing rests on).**
- The meta and reading rows (A9).
- The tally rows EQN-001, EQN-002, EQN-011, EQN-013, EQN-017, EQN-020.
- The open rows CPL-006, CPL-007, YM-005, YM-006, MAT-005, MAT-006, SPN-004, FRQ-004, FRQ-005.
- Physically substantive leaves, where V2 should look for missing links: NUL-010 (characteristics), NUL-003, PRJ-006, RIG-002, RIG-006, SPR-004, CPL-009, NUL-012.

**Rows that hold several statements** (they distort any graph and should be split before V2 renders them): GRV-011, GRV-004, NUL-001, NUL-004, LAB-005, LAB-006, EQN-019, PRJ-006, SPR-004, CPL-008, INP-044, INP-048, INP-049, INP-050.

## C. Missing pieces

Most consequential first. "Script" says whether the Atlas's engine (bit-rule frames, exact jets, power series, the PGA integrator) could compute it.

**C1. Geodesic motion from the conservation law.**
- **Statement:** For pressureless dust, D τ_a = 0 (forced by the Bianchi/Noether identity once E_a = κτ_a holds) is equivalent to u·∇u = 0: matter moves on geodesics because the field equation forces conservation. This makes free fall a consequence of the field equation, not an extra postulate.
- **Source:** Einstein, Infeld and Hoffmann, *The gravitational equations and the problem of motion*; Weinberg, *Gravitation and Cosmology*.
- **Links:** GRV-008, GRV-011 (free fall from the solved ω), LAB-005, INP-075, EQN-019.
- **Script:** yes. The dust stress on the engine's frame and the Noether identity of GRV-008 are already there.

**C2. The Lorentz force from conservation of the total stress.**
- **Statement:** With ∇F = J, the divergence of the Maxwell stress T(a) = −½FaF is the force density J·F, with its sign fixed by the conventions. So conservation of field plus matter stress gives the Lorentz force density, and on the Dirac current it gives the force on the charge.
- **Why it matters:** this turns the postulated force law of the Maxwell page (INP-007) into a derived one.
- **Source:** Jackson, *Classical Electrodynamics* (Maxwell stress tensor, conservation of momentum); Hestenes, *Space-Time Algebra*.
- **Links:** CPL-005, GRV-011 (stress −½FaF by variation), MAT-007, EQN-009, INP-007.
- **Script:** yes. It is an exact identity on the engine.

**C3. The non-relativistic (Pauli) limit of the Dirac–Hestenes equation, with g = 2.**
- **Statement:** The space-time split by γ₀ reduces ∇ψJ − eAψ = mψγ₀ to the Pauli equation in Cl(3,0), with magnetic moment g = 2. The Foldy–Wouthuysen expansion adds the Darwin and spin–orbit terms.
- **Phenomenon approached:** the electron's magnetic moment.
- **Source:** Hestenes, *Space-Time Algebra*; Doran and Lasenby, *Geometric Algebra for Physicists*; Bjorken and Drell, *Relativistic Quantum Mechanics*.
- **Links:** EQN-008, EQN-009, CPL-004, SPN-004 (Born rule in Cl(3,0)), ATL-006, INP-023.
- **Script:** yes. The split and the expansion in 1/m are algebraic.

**C4. Lovelock's theorem.**
- **Statement:** In four dimensions, the only divergence-free symmetric 2-tensors built from the metric and its first two derivatives are a G_μν + b g_μν.
- **Why it matters:** with GRV-008 (Einstein form ⇒ conserved), this makes the link two-way (conserved and second order ⇒ Einstein form), and it answers why E_a is the field equation.
- **Source:** Lovelock, *The Einstein tensor and its generalizations*.
- **Links:** GRV-009, GRV-010, GRV-008, EQN-013, INP-048.
- **Script:** partly. Uniqueness within a polynomial ansatz in the curvature tables is computable at n = 4, as INP-044 already did for the topological terms.

**C5. Birkhoff's theorem in full.**
- **Statement:** Every spherically symmetric vacuum solution (with Λ) is static and is Schwarzschild–(anti-)de Sitter.
- **Why it matters:** it closes the gap between the field equation and its solution that GRV-012 leaves (one function, one congruence) and that INP-054 and LAB-005 inherit.
- **Source:** Birkhoff, *Relativity and Modern Physics*; Hawking and Ellis, *The Large Scale Structure of Space-Time*.
- **Links:** GRV-012, INP-054, INP-056, LAB-005.
- **Script:** partly. A two-function ansatz f(t, ρ) in the radial Kerr–Schild class can be pushed through the engine's E_a.

**C6. Linearised gravity, gravitational waves and the quadrupole formula.**
- **Statement:** The linearised E_a admits transverse-traceless waves with two polarisations of helicity ±2, sourced at leading order by the second time derivative of the mass quadrupole. The radiated power is (G/5)⟨d³Q/dt³ : d³Q/dt³⟩.
- **Phenomenon approached:** gravitational radiation. The chunk has the symbol (NUL-010) and an exact plane wave (NUL-004), but no source.
- **Source:** Misner, Thorne and Wheeler, *Gravitation*; Maggiore, *Gravitational Waves, Vol. 1*.
- **Links:** NUL-010, NUL-004, GRV-010, EQN-019 (the planets as a quadrupole source).
- **Script:** partly. The linearised operator is computed; the retarded solution is not.

**C7. Einstein–Infeld–Hoffmann (1PN) equations of motion.**
- **Statement:** The 1PN N-body accelerations follow from the field equations to order (v/c)². In the two-body limit they give 6πGM/(c²a(1 − e²)).
- **Why it matters:** this would make the "recalled first post-Newtonian term, integrated outside the Atlas" of RIG-005 and EQN-019 an Atlas result, and it would join the geodesic perihelion of LAB-005 to the ephemeris comparison.
- **Source:** Einstein, Infeld and Hoffmann (as C1); Will, *Theory and Experiment in Gravitational Physics*.
- **Links:** LAB-005, GRV-011, INP-075, RIG-005, EQN-019.
- **Script:** partly. The one-body Schwarzschild 1PN term is computable now; the N-body metric is not.

**C8. Yang–Mills and gauged Dirac actions rebuilt, with the Yang–Mills stress.**
- **Statement:** Varying −¼ tr F² + ψ̄(iD̸ − m)ψ gives D^μF_μν = g j_ν (one coupling, fixed sign), and varying the frame gives T_μν = tr(F_μαF_ν^α − ¼g_μν F²), conserved on shell.
- **Why it matters:** this settles the pointer actions and the open Einstein–Yang–Mills source.
- **Source:** Peskin and Schroeder, *An Introduction to Quantum Field Theory*; Weinberg, *The Quantum Theory of Fields II*.
- **Links:** INP-033, INP-037, INP-040, MAT-005, YM-005, YM-007, EQN-010, EQN-011.
- **Script:** yes. bd·phy·18 and bd·phy·19 already do this for U(1).

**C9. Classical Yang–Mills solutions.**
- **Statement:** The BPST instanton is a self-dual so(4) = su(2) ⊕ su(2) connection on Euclidean ℝ⁴ with integer topological charge. The Wu–Yang monopole is a static so(3) solution.
- **Why it matters:** both close the gap between field equation and solution in step 7, where no solution is computed (YM-005).
- **Source:** Belavin, Polyakov, Schwarz and Tyupkin, *Pseudoparticle solutions of the Yang–Mills equations*; Wu and Yang, *Some solutions of the classical isotopic gauge field equations*.
- **Links:** YM-005, EQN-010, YM-001, YM-004.
- **Script:** yes. These are exact rational checks of F = ⋆F and D⋆F = 0 at points (signature (4,0)).

**C10. The Belinfante–Rosenfeld tensor and the Hehl–Datta equation.**
- **Statement:** The canonical stress plus the divergence of the spin gives the symmetric, conserved Belinfante tensor, equal to the metric (Hilbert) stress. Eliminating the axial torsion gives the cubic Hehl–Datta equation iγ·∇ψ − mψ = −(3κ/8)(ψ̄γ₅γ_μψ)γ₅γ^μψ.
- **Why it matters:** GRV-011 lists both as "not built".
- **Source:** Belinfante, *On the current and the density of the electric charge, the energy, the linear momentum and the angular momentum of arbitrary fields*; Hehl and Datta, *Nonlinear spinor equation and asymmetric connection in general relativity*.
- **Links:** GRV-011, GRV-003, CPL-008.
- **Script:** yes. Every ingredient (τ_a, S_ab, the contact term) is on the engine.

**C11. Kerr from the Kerr–Schild ansatz.**
- **Statement:** For g = η − 2f l l with l null, geodesic and shear-free, the field equations become linear in f; the stationary axisymmetric solution is Kerr, and with Maxwell it is Kerr–Newman.
- **Why it matters:** INP-058 checks Kerr at points but takes it as input.
- **Source:** Kerr and Schild, *Some algebraically degenerate solutions of Einstein's gravitational field equations*; Debney, Kerr and Schild, *Solutions of the Einstein and Einstein–Maxwell equations*.
- **Links:** INP-058, GRV-012, NUL-001, EQN-020.
- **Script:** partly. The radial-class code generalises; the congruence stays a choice.

**C12. Frame dragging and geodetic precession of a gyroscope.**
- **Statement:** Fermi–Walker transport of a spin bivector along an orbit gives the de Sitter (geodetic) and Lense–Thirring (frame-dragging) precessions; Gravity Probe B measured both.
- **Phenomenon approached:** gravitomagnetism. The chunk has Kerr frames, J = Ma and Ω_H (NUL-001) and a free top (PRJ-005), but never joins them.
- **Source:** Schiff, *Possible new experimental test of general relativity theory*; Misner, Thorne and Wheeler, *Gravitation*.
- **Links:** INP-058, NUL-001, PRJ-005, RIG-002, LAB-006.
- **Script:** yes. Transporting B with the engine's ω along a geodesic is an exact series.

**C13. The Mathisson–Papapetrou–Dixon equations.**
- **Statement:** These are the covariant equations of motion of a spinning extended body: the force and torque are the body's multipole moments contracted with the Riemann tensor and its covariant derivatives.
- **Why it matters:** they are the relativistic home of the multipole forque of RIG-002 and EQN-019, and they explain why the coordinate derivatives of the tidal tensor agree with the covariant ones only at first order in M (LAB-006).
- **Source:** Dixon, *Dynamics of extended bodies in general relativity*; Papapetrou, *Spinning test-particles in general relativity*.
- **Links:** LAB-006, RIG-002, EQN-019, PRJ-005.
- **Script:** partly. The quadrupole order is computable with the engine's curvature.

**C14. Hawking temperature and the area theorem.**
- **Statement:** A horizon with surface gravity κ radiates at T = κ/2π (quantum fields on the background). With the null energy condition, the horizon area never decreases.
- **Phenomenon approached:** Hawking radiation and black-hole thermodynamics. NUL-001 and LAB-008 compute κ and the first law and explicitly do not claim T or the area theorem.
- **Source:** Hawking, *Particle creation by black holes*; Gibbons and Hawking, *Action integrals and partition functions in quantum gravity*; Hawking, *Gravitational radiation from colliding black holes*.
- **Links:** NUL-001, LAB-008, EQN-020, NUL-010 (focusing).
- **Script:** partly. The Euclidean period 2π/κ that removes the conical singularity is a classical computation; the quantum statement and the global area theorem are not.

**C15. C, P, T and CPT on the Dirac–Hestenes equation.**
- **Statement:** Charge conjugation (a right multiplication that flips J and the sign of e), parity (ψ ↦ γ₀ψ(x̄)γ₀) and time reversal (a two-sided map with γ₀ and the pseudoscalar) each map solutions to solutions of the transformed equation, and their product CPT is a symmetry. Conventions as in Doran and Lasenby.
- **Why it matters:** these join the J datum of INP-024 and INP-031, time reversal as a mirror (MIR-005) and the Pin± choice (INP-018).
- **Source:** Hestenes, *Real spinor fields*; Doran and Lasenby, *Geometric Algebra for Physicists*; Streater and Wightman, *PCT, Spin and Statistics, and All That*.
- **Links:** INP-024, INP-031, MIR-005, INP-018, INP-020, EQN-008.
- **Script:** yes. These are exact checks on solutions.

**C16. Chirality, the Weyl equations, V − A coupling and the Higgs mechanism.**
- **Statement:** The chirality projectors split ψ into Weyl halves; the electroweak su(2) acts on the left half only; fermion and gauge-boson masses then need a scalar doublet with a vacuum expectation value.
- **Phenomenon approached:** parity violation and mass generation. MAT-006 and YM-006 name the gap.
- **Source:** Peskin and Schroeder (as C8); Weinberg, *A model of leptons*; Higgs, *Broken symmetries and the masses of gauge bosons*.
- **Links:** MAT-006, YM-006, INP-068, INP-039, SPN-003.
- **Script:** partly. The chiral projections and a left-acting su(2) are algebraic; the Higgs potential and its vacuum are an input.

**C17. The Dirac–Coulomb problem (hydrogen fine structure).**
- **Statement:** The coupled equation of step 6 in the Coulomb field of a point charge has bound states with Sommerfeld's energies E = m[1 + (Zα)²/(n − k + √(k² − (Zα)²))²]^(−1/2).
- **Why it matters:** it closes the gap between field equation and solution in the coupling step, which has no solution, and it meets so(4,2) (ATL-014).
- **Source:** Bjorken and Drell, *Relativistic Quantum Mechanics*; Doran and Lasenby, *Geometric Algebra for Physicists*.
- **Links:** EQN-009, CPL-004, INP-010, ATL-014.
- **Script:** partly. The separated radial equations as exact series are feasible; the spectrum needs a quantisation condition.

**C18. Conformal invariance of the massless field equations.**
- **Statement:** Maxwell's equations, the massless Dirac equation and Yang–Mills in four dimensions are covariant under the conformal group SO(2,4) (Bateman–Cunningham).
- **Why it matters:** INP-053 cites this; the engine already has so(2,4) (EQN-015, GRV-004).
- **Source:** Bateman, *The transformation of the electrodynamical equations*; Cunningham, *The principle of relativity in electrodynamics and an extension thereof*.
- **Links:** INP-053, EQN-015, GRV-004, EQN-006, EQN-008.
- **Script:** yes. Check the special conformal generators K_a on exact solutions.

**C19. Kaluza–Klein: Einstein–Maxwell from five-dimensional gravity.**
- **Statement:** With g_{μ5} = A_μ and fields independent of the fifth coordinate, the five-dimensional Einstein–Hilbert action reduces to Einstein–Maxwell plus a scalar. Charge is momentum along the fibre.
- **Why it matters:** PRJ-006 checks the sign of the Maxwell energy; LNS-120 checks the mass shell.
- **Source:** Kaluza, *Zum Unitätsproblem der Physik*; Klein, *Quantentheorie und fünfdimensionale Relativitätstheorie*; Overduin and Wesson, *Kaluza–Klein gravity*.
- **Links:** PRJ-006, GRV-010, EQN-006, INP-049.
- **Script:** yes. The n = 5 frames already run.

**C20. A rigid-body action (Euler–Poincaré reduction) and its Noether charges.**
- **Statement:** The Lagrangian ½⟨B, A(B)⟩ on the motor group, reduced by left invariance, gives the Euler equation of step 14. Noether's theorem gives the conserved momentum and angular momentum that EQN-019 observes numerically.
- **Why it matters:** this answers "no action principle" in FRQ-004, PAG-024 and SPR-004, and makes CPL-011 cover mechanics.
- **Source:** Marsden and Ratiu, *Introduction to Mechanics and Symmetry*; Holm, Schmah and Stoica, *Geometric Mechanics and Symmetry*.
- **Links:** FRQ-004, EQN-016, PAG-024, SPR-004, EQN-019.
- **Script:** yes. It is a first-variation identity, like GRV-005.

**C21. The continuum limit of the spring lattice (phonons) and Wilson's lattice gauge action.**
- **Statement:** On the translated cube the graph Laplacian gives ω² = 2Σ_μ(1 − cos k_μ), sound waves at small k. Edge fields with plaquette energy give lattice Maxwell (Wilson); the π flux of SPR-003 is a plaquette holonomy.
- **Phenomenon approached:** sound and phonons, and gauge fields on a lattice.
- **Source:** Ashcroft and Mermin, *Solid State Physics*; Wilson, *Confinement of quarks*.
- **Links:** SPR-003, SPR-004, EQN-018, RIG-006, EQN-010.
- **Script:** yes.

**C22. The fermion doubling theorem.**
- **Statement:** A local, translation-invariant, hermitian lattice Dirac operator with chiral symmetry has equal numbers of left- and right-handed zero modes.
- **Why it matters:** it explains the 2^⌈n/2⌉ tastes of the staggered reading in SPR-004.
- **Source:** Nielsen and Ninomiya, *Absence of neutrinos on a lattice*.
- **Links:** SPR-004, T20, CPL-007.
- **Script:** partly. Counting zeros of the Bloch Hamiltonian is computable; the topological argument is not.

**C23. Friedmann cosmology beyond one local series.**
- **Statement:** The two Friedmann equations, the equation of state w = p/ρ, the acceleration condition ρ + 3p < 0, the de Sitter attractor and slow-roll inflation.
- **Phenomenon approached:** cosmic acceleration and inflation. GRV-011 solves one Einstein–scalar FRW system locally, "no late-time or attractor statement", and GRV-007 reads Λ as a fluid with p = −ρ.
- **Source:** Weinberg, *Cosmology*; Mukhanov, *Physical Foundations of Cosmology*.
- **Links:** GRV-011, GRV-007, INP-050, PAG-024.
- **Script:** partly. The Friedmann–Klein–Gordon recursion exists; attractor behaviour is a numerical statement.

**C24. The Λ correction to the perihelion advance, compared with print.**
- **Statement:** In Schwarzschild–de Sitter the periastron advance per orbit gains πΛa³√(1 − e²)/(GM) = 3πH²a³√(1 − e²)/M at Newtonian order. This is the formula GRV-007 found, "not compared with a printed source".
- **Source:** Kerr, Hauck and Mashhoon, *Standard clocks, orbital precession and the cosmological constant*.
- **Links:** GRV-007, LAB-005.
- **Script:** yes. It is already computed; only the comparison is missing.
