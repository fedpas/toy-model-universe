# Chunk D (Baez chapter, 143 rows): the physicist's labelling

Labels are in `phys_D.jsonl` (validator: 0 problems). Relation counts: 76 derives, 87 equiv, 7 instance, 21 uses-input, 1 contradicts, 0 cycle. Stages: A 9, K 55, F 0, D 9, O 39, M 31.

## A. How physics would organise these rows

Physics builds from the algebra, through kinematics (modules, Lie algebras, lattices), to fields, dynamics and finally contact with known physics. In that order this chunk reads as follows.

**1. The algebra on labels (stage A).**
- *Octonions and their relatives on three-bit labels:* LNB-018 (hub), LNB-002, LNB-019, LNB-137, LNB-020, LNB-029 (line 1). Products on a label set, before any physics: the octonion sign as a non-cocycle, Zorn, split and null octonions, G₂ ⊃ SU(3).
- *Peirce values on labels:* LNB-102, LNB-044, LNB-004. Jordan-triple data read on bits.
- *Frobenius forms:* LNB-025, LNB-037. The top-label pairing (physically the Berezin integral) and the scalar part.

**2. Kinematics: modules, Lie algebras, lattices (stage K).**
- *Fock space as the label set:* LNB-147 (any n), LNB-015 (n = 5), LNB-006, LNB-148, LNB-162, and the open LNB-033, LNB-039, LNB-040. The Jordan–Wigner modes, Cl(5,5) = M₃₂(ℝ), and so(5,5) graded 10 + 25 + 10 by particle number.
- *The Kepler symmetry algebra as bivectors:* LNB-124 (hub of its class), LNB-009, LNB-126, LNB-128, LNB-130, LNB-131, LNB-145, LNB-160. so(4), e(3) and so(3,1) from one fourth generator, and the 4 + 7 + 4 grading of so(4,2).
- *The exceptional ladder:* LNB-016 (hub), LNB-003, LNB-007, LNB-118, LNB-119, LNB-123, LNB-157, LNB-142, LNB-143, LNB-144, LNB-159, LNB-043. Root counts and the gradings E₈ → E₇ → E₆ → D₅ → A₄ → A₂ + A₁.
- *E₇ shadows and the hexagonal lattice:* LNB-017 (hub), LNB-010, LNB-149, LNB-163, LNB-166, LNB-167, LNB-168, LNB-170, LNB-171, LNB-056, with the readings LNB-150, LNB-164, LNB-169, LNB-172, LNB-032.
- *Ten dimensions and spinors:* LNB-022 (hub), LNB-011, LNB-151, LNB-026, and the open LNB-036, LNB-042, LNB-051, LNB-064, LNB-152, LNB-165. h₂(𝕆) as a spin factor, Cl(9,0), the clock of (1,9), and Thurston's form.
- *Representation facts:* LNB-113 (the 27 is real) and LNB-116 (regular versus stabiliser embeddings).

**3. Fields and their equations (stage F): empty.** The chapter has no Lagrangian, no field equation and no wave equation. The Weyl equation on ℝ × S³, which the Kepler paper uses, is listed as a gap (LNB-028).

**4. Dynamics (stage D).** The Kepler problem: LNB-023 (hub), LNB-125, LNB-129, LNB-049, LNB-055, LNB-062, LNB-046, and the open LNB-034 and LNB-041. These cover the Runge–Lenz brackets, the Inönü–Wigner family, the Fock projection and the opposite sign conventions of step 11.

**5. Observation and calibration (stage O).**
- *One generation on five bits:* LNB-014 (hub), LNB-001, LNB-005, LNB-047, LNB-053, LNB-060, LNB-101, LNB-103, LNB-106, LNB-107, LNB-108; conjugation LNB-104, LNB-048, LNB-061 and the reading LNB-105.
- *Which Standard Model:* LNB-021 (hub), LNB-008, LNB-111, LNB-112, LNB-114, LNB-115, LNB-139, LNB-155, and the open LNB-035, LNB-038, LNB-045, LNB-117.
- *The GUT chain:* LNB-121, LNB-141, and the reading LNB-122.
- *Atoms:* LNB-127 (hydrogen shells), LNB-024, LNB-057, LNB-173, LNB-174, LNB-177, LNB-178, and the readings LNB-175, LNB-176.
- *Literature as given:* LNB-012.

**6. Method and meta (stage M).**
- *Citations and the map of papers:* LNB-013, LNB-050, LNB-054, LNB-063, LNB-132 to LNB-136, LNB-138, LNB-140, LNB-146, LNB-153, LNB-154, LNB-156, LNB-161.
- *Gaps:* LNB-027, LNB-028, LNB-052, LNB-059, LNB-065.
- *Credits:* LNB-109, LNB-110, LNB-120.
- *Perspectives:* LNB-030, LNB-031, LNB-032.
- *Numerology and dead ends:* LNB-026, LNB-058, LNB-029.

**Where the page order and the physics order differ.**
- The page opens with the generation (LNB-014, a calibration) before the Fock space (LNB-015) whose labels and number operator it rests on.
- The octonions (LNB-018, under "bz-more") come after the ladder and the ring, although the Albert algebra of "Which Standard Model?" (LNB-021) is built on them.
- The ten-dimensional section (LNB-022) depends on LNB-021 but is placed as a separate topic.
- Kepler before atoms matches the physics order.
- The widget and learner rows (LNB-053 to LNB-065, LNB-101 to LNB-178) repeat the research rows in plain words. In a physics outline they are equivalences attached to their research row, not separate sections.

## B. Chains, classes and loops

**Chains (ordered by `derives`, root first).**
1. T6 → LNB-018 → LNB-021 → LNB-022 → LNB-151 → LNB-152. The longest chain: the octonion cochain leads to the Albert algebra, then to h₂(𝕆) as ℝ^{9,1}, then to the two (1,9)s, and ends in the open numerology.
2. T6 → LNB-018 → LNB-019 → LNB-029: the octonion family and the complement that needs a sign.
3. LNB-018 → LNB-021 → LNB-113 → LNB-114: the Albert-algebra SM algebra acts on a real 27, so it is vector-like (a negative result for chirality).
4. INP-014 → LNB-014 → LNB-030, with LNB-101 → LNB-103 (anomalies) and LNB-101 → LNB-104 → LNB-105 (the flip, then its naming as charge conjugation).
5. T20 → LNB-015 → LNB-106: Fock modes give the irreps (3,2), (3̄,1)², (1,2), (1,1)². T20 → LNB-147 → LNB-148, and LNB-147 → LNB-175.
6. T10, T13, GOS-001 → LNB-016 → LNB-121 → LNB-122. Also LNB-016 → LNB-142 → LNB-143 → LNB-144, LNB-016 → LNB-043, and (LNB-016, LNB-021) → LNB-115.
7. T13 → LNB-017 → LNB-033 / LNB-040; LNB-166 → LNB-168 and LNB-166 → LNB-169.
8. INP-075, PRJ-001, ATL-014 → LNB-023 → LNB-034 and LNB-023 → LNB-145. Separately, LNB-124 → LNB-126 → LNB-127 → LNB-024: bivectors give so(3) + so(3), then the shells n², then the periodic table.
9. T4 → LNB-022 → LNB-036; T3 → LNB-025 → LNB-037; INP-084 → LNB-173 → LNB-174 → LNB-175.

**Classes (`equiv`: the same statement at two levels or in two places).**
- Generation: {LNB-014, 005, 047, 053, 060, 101, 102, 107, 108, 109}. Conjugation: {LNB-104, 048, 061}.
- Which SM: {LNB-021, 008, 111, 112, 139, 155}. Open relation of the two embeddings: {LNB-035, 038, 117}.
- Ladder: {LNB-016, 003, 004, 007, 118, 119, 120, 121, 123, 141, 157}.
- Shadows and rings: {LNB-017, 010, 056, 149, 163, 166, 167, 170, 171, GOS-003}. Ring reading: {LNB-150, 164, 169, 172}.
- Octonions: {LNB-018, 002, 137}. Fock: {LNB-015, 006} and {LNB-147, SHP-002}. Fock reading: {LNB-148, 162}.
- Kepler bivectors: {LNB-124, 009, 049, 062, 130}. Kepler dynamics: {LNB-023, 055, 125, 129, 146, 161}. Naming by squares: {LNB-128, 131, LAB-003}.
- Ten: {LNB-022, 011}. Open (1,9) questions: {LNB-036, 042}, {LNB-051, 064}, {LNB-152, 165}.
- Atoms: {LNB-173, 177}, {LNB-174, 024, 178, 057}, {LNB-175, 176}.
- Meta: citations {LNB-013, 050, 054, 063, 132, 133, 134, 135}; arrows {136, 153}, {138, 154}, {140, 156}; gaps {LNB-027, 052, 059, 065}.

**Loops.** No `cycle` edge was needed. Three places come close, each with two independent routes to one number:
- LNB-021 and LNB-112: the stabiliser computed, and the paper's Lemma 4 branched, both give 2, 4, 3, 6, 12.
- LNB-118 and LNB-123: Levi deletion, and common neighbours of a root chain, both give 56, 27, 16, 10, 6.
- LNB-166 and LNB-168: enumeration of the rings, and Lemma 2's bound.

These are recorded as `equiv` or `derives`.

**Contradiction (1).** LNB-158 against LNB-058.
- LNB-058 says "we kept a link only where a computation stands behind it".
- LNB-158 keeps the 27-to-27 link of the map with "both papers have a set of 27 things" as its stated ground.
- The research twins (LNB-026 against LNB-142 and LNB-143) are softer, because one side of the 27 is computed.
- The Tits–Kantor–Koecher construction (C3) would give the link a mechanism and remove the conflict.

**Hubs (most rows rest on them).**
- LNB-021 (11 dependants)
- LNB-016 (11)
- LNB-014 (9)
- LNB-017 (8)
- LNB-023 (7), together with LNB-013 (7, meta)
- Next come LNB-124 (6) and LNB-015, LNB-018, LNB-022 (5 each).
- Outside the chunk: INP-082 (7: Baez's octonion table, embeddings and Loos's multiplicities) and T13 (5).

**Leaves (nothing derives from them).** 79 rows.
- Most are restatements: appendix rows LNB-002 to 010, learner rows LNB-053 to 065, widget rows. Their `equiv` edge points at the hub, so they are leaves only in one direction.
- The logically terminal leaves are the open questions LNB-039, 041 to 046, 117, 144, 152, 159, 165 and the readings LNB-105, 122, 131, 164, 172, 176.
- Also terminal: the negatives LNB-114 and LNB-155, and the credits LNB-110 and LNB-120.

## C. Missing pieces

Most consequential first. "Script" says whether the Atlas's engine could compute it.

1. **Spin(10) and SU(5) on Λℂ⁵; hypercharge as an element of u(5).**
   - *Statement:* The 16 even labels of five bits are the chiral spinor 16 of Spin(10), and the 32 labels are Λℂ⁵ = 16 ⊕ 16̄. The number-conserving bilinears a_i⁺a_j span u(5), which is exactly the degree-0 part (25) of the Atlas's own 10 + 25 + 10 grading. Y = diag(½, ½, −⅓, −⅓, −⅓) is an element of it, so Y is linear in the bit counts.
   - *Two-way chain:* this turns LNB-015 → LNB-014 into a derivation, and turns the 'ours' of LNB-014, 053 and 105 into 'standard'.
   - *Source:* Baez and Huerta, "The Algebra of Grand Unified Theories"; Fritzsch and Minkowski, "Unified interactions of leptons and hadrons".
   - *Links:* LNB-014, 015, 006, 101, 104, 105, 147.
   - *Script:* yes. Take the degree-0 part of the already computed so(5,5) and find Y in it.

2. **E₆ ⊃ SO(10) × U(1): 27 = 16 ⊕ 10 ⊕ 1.**
   - *Statement:* Under SO(10) the 27 of E₆ is a spinor 16, a vector 10 = 5 + 5̄ of SU(5), and a singlet.
   - *Effect:* this answers the open LNB-043 and the open line of LNB-016, and explains LNB-115's (1, 4, 0, 6, 0) for the eleven extra states.
   - *Source:* Slansky, "Group theory for unified model building"; Gürsey, Ramond and Sikivie, "A universal gauge theory model based on E6".
   - *Links:* LNB-016, 043, 115, 121, 122.
   - *Script:* yes, with the same root grading as E1a–c.

3. **The Tits–Kantor–Koecher construction.**
   - *Statement:* e₇ = J ⊕ (e₆ ⊕ ℝ) ⊕ J̄ with J = h₃(𝕆). The grade-1 pieces of the ladder are Jordan triples. The 27 of e₇'s grade 1 is h₃(𝕆)⊗ℂ, the 27 of E₆, and so the h₃(𝕆_ℂ) of the geometry paper.
   - *Effect:* this solidifies the dashed link of LNB-142 and 143, answers LNB-159, and resolves the contradiction LNB-158 against LNB-058.
   - *Source:* Tits, "Une classe d'algèbres de Lie en relation avec les algèbres de Jordan"; Koecher, "Imbedding of Jordan algebras into Lie algebras I".
   - *Links:* LNB-016, 004, 021, 142, 143, 158, 159.
   - *Script:* partly. The Albert algebra exists in the engine; building str(J) and the TKK bracket is finite linear algebra.

4. **Pauli's algebraic hydrogen spectrum.** (Closes a field equation against its solution: Schrödinger–Coulomb.)
   - *Statement:* From so(4) = su(2) ⊕ su(2) with equal Casimirs j(j + 1) and L·A = 0, the bound energies are E_n = −μk²/(2n²) with n = 2j + 1. The Atlas derives the degeneracy n² (LNB-127) but not the Balmer levels. This is the phenomenon approached but not derived: the hydrogen spectrum.
   - *Source:* Pauli, "Über das Wasserstoffspektrum vom Standpunkt der neuen Quantenmechanik".
   - *Links:* LNB-023, 124, 126, 127, 024.
   - *Script:* yes, an exact Casimir identity on top of K1c and K2b.

5. **Complete anomaly conditions, and why the 16 is automatically free of them.**
   - *Statement:* Besides the U(1) sums, a generation must satisfy the SU(3)³ condition and Witten's global SU(2) condition (an even number of doublets: here 4). Any complete Spin(10) representation is anomaly-free because so(10) has no cubic invariant (d-symbol).
   - *Effect:* the zero sums of LNB-103 then follow from LNB-001 and LNB-015 instead of being a coincidence on labels.
   - *Source:* Georgi and Glashow, "Gauge theories without anomalies"; Witten, "An SU(2) anomaly"; Bouchiat, Iliopoulos and Meyer, "An anomaly-free version of Weinberg's model".
   - *Links:* LNB-014, 053, 103, 015.
   - *Script:* yes. Count the doublets, sum the SU(3)³ contributions, and check that the d-symbol vanishes on so(5,5).

6. **sin²θ_W = 3/8 at unification, from the labels.** (Phenomenon approached: gauge-coupling unification and the weak mixing angle.)
   - *Statement:* Over the 16 labels, Tr T₃² / Tr Q² = 2 / (16/3) = 3/8, the SU(5)/SO(10) prediction at the unification scale. It is an exact bit count.
   - *Source:* Georgi, Quinn and Weinberg, "Hierarchy of interactions in unified gauge theories"; Georgi and Glashow, "Unity of all elementary-particle forces".
   - *Links:* LNB-014, 101, 103; contrast with the Furey 3/8 row of chunk A.
   - *Script:* yes, exact rationals.

7. **h₂(𝕆) ≅ ℝ^{9,1} and supersymmetry from the division algebras.**
   - *Statement:* det on h₂(𝕆) is the Minkowski norm. 𝕆² = ℝ¹⁶ carries the Majorana–Weyl spinors of Spin(9,1), and Spin(9) acts on the Peirce-½ space 16 as on its spinor. The 3-ψ identity holds exactly in dimensions 3, 4, 6 and 10.
   - *Effect:* the recalled fact in LNB-022 and 026 becomes a computation, and the real 10 of h₂(𝕆) gets its physical meaning.
   - *Source:* Kugo and Townsend, "Supersymmetry and the division algebras"; Baez and Huerta, "Division algebras and supersymmetry I"; Sudbery, "Division algebras, (pseudo)orthogonal groups and spinors".
   - *Links:* LNB-022, 011, 026, 036, 151.
   - *Script:* yes for the spin(9) action and the 3-ψ identity, both finite.

8. **Majorana–Weyl spinors exist iff s − t ≡ 0 mod 8.**
   - *Statement:* For signature (s, t), real chiral spinors exist exactly when s − t ≡ 0 mod 8. This is the clock-0 condition, so "clock 0 ⇔ Majorana–Weyl" becomes two-way and attaches to T4.
   - *Source:* Van Proeyen, "Tools for supersymmetry"; Kugo and Townsend (as in item 7).
   - *Links:* LNB-011, 022, 042, T4.
   - *Script:* yes; it is T4 plus the pseudoscalar square.

9. **E₇ ⊃ SU(3) × SU(6) branching.**
   - *Statement:* 133 = (8,1) + (1,35) + (3,15) + (3̄,15̄), which gives 6 + 30 + 90 shadows for every A₂ ⊂ E₇ (T13(5)), not only for the one embedding enumerated.
   - *Effect:* the "one embedding, by enumeration" caveat of LNB-017 and LNB-167 becomes a theorem.
   - *Source:* Slansky (as in item 2).
   - *Links:* LNB-017, 010, 149, 167, T13.
   - *Script:* yes.

10. **Fock's quantum statement.**
    - *Statement:* Bound-state momentum wavefunctions of hydrogen are hyperspherical harmonics on S³, carried there by the same projection F_c; level n is the harmonic polynomials of degree n − 1, of dimension n².
    - *Effect:* the classical Fock map (LNB-125) and the shell count (LNB-127) become one chain instead of two checks.
    - *Source:* Fock, "Zur Theorie des Wasserstoffatoms"; Bargmann, "Zur Theorie des Wasserstoffatoms: Bemerkungen zur gleichnamigen Arbeit von V. Fock".
    - *Links:* LNB-023, 125, 127, 129.
    - *Script:* yes, exact dimension count.
11. **SO(4,2) as the spectrum-generating algebra of hydrogen.**
    - *Statement:* All bound states form one unitary irrep of SO(4,2). The degree ±1 parts of the 4 + 7 + 4 grading change the principal quantum number.
    - *Effect:* gives physical content to LNB-034's question (hydrogen as a Jordan-pair system).
    - *Source:* Barut and Kleinert, "Transition probabilities of the hydrogen atom from noncompact dynamical groups"; Malkin and Man'ko, "Symmetry of the hydrogen atom".
    - *Links:* LNB-023, 034, 041, 145, ATL-014.
    - *Script:* partly. The algebra and grading yes; the unitary infinite-dimensional irrep no.

12. **Relativistic Kepler: fine structure.** (Phenomenon approached: fine structure.)
    - *Statement:* For the Dirac–Coulomb problem the Runge–Lenz vector is replaced by the Johnson–Lippmann operator, and levels depend on n and j only. The Atlas's 2n² = n(n + 1) + n(n − 1) (LNB-127) is exactly the split into j = l ± ½, which this would explain. The chain would run from the Dirac rows of other chunks to these shells.
    - *Source:* Johnson and Lippmann, "Relativistic Kepler problem"; Dirac, "The quantum theory of the electron".
    - *Links:* LNB-127, 023, and the Dirac rows (EQN) of the equations page.
    - *Script:* partly. The operator algebra is finite; the spectrum needs analysis.

13. **Scattering states and Rutherford scattering.** (Phenomenon approached: Coulomb/Rutherford scattering.)
    - *Statement:* For E > 0 the hidden symmetry is so(3,1), and the scattering states carry its unitary representations. The classical deflection follows from the Runge–Lenz vector, and the S-matrix phases from the representation theory. The Atlas has the hyperbolic orbits and so(3,1) (LNB-124, 125, 129) but not the cross-section.
    - *Source:* Bander and Itzykson, "Group theory and the hydrogen atom (I) and (II)".
    - *Links:* LNB-023, 124, 125, 129.
    - *Script:* partly. The classical deflection angle is exact; the quantum phases no.

14. **How the two Standard Models meet: Spin(9) ⊂ Spin(10), Pati–Salam ∩ SU(5).**
    - *Statement:* Inside Spin(10), G_SM = SU(5) ∩ (Spin(4) × Spin(6)) up to the finite quotient. Krasnov characterises G_SM inside Spin(9), the stabiliser of A = h₂(𝕆) (the 36 of LNB-021). Together they are the standard frame for the open question "through Spin(9) ⊂ Spin(10)?".
    - *Source:* Pati and Salam, "Lepton number as the fourth 'color'"; Baez and Huerta, "The Algebra of Grand Unified Theories"; Krasnov, "SO(9) characterisation of the Standard Model gauge group".
    - *Links:* LNB-021, 035, 038, 045, 117, 022.
    - *Script:* partly. Lie-algebra intersections yes; groups and quotients no (the gap of LNB-028).

15. **C versus CP for Weyl multiplets.**
    - *Statement:* The complement map 16 → 16̄ sends left-handed states to the conjugate representation. On Weyl fields that is CP; C alone would require the opposite chirality.
    - *Effect:* the naming in LNB-014 and 105 should change.
    - *Source:* Peskin and Schroeder, "An Introduction to Quantum Field Theory" (discrete symmetries).
    - *Links:* LNB-104, 105, 048, 061, ATL-015.
    - *Script:* no, a naming fact; it needs a time orientation input to state.

16. **Compact versus split real form (unitarity).**
    - *Statement:* Physics uses compact SO(10) acting unitarily on a complex 16. Cl(5,5) gives the split so(5,5) acting on a real 32, non-unitarily. Branching rules agree after complexification (Weyl's unitary trick), but unitarity needs the compact form from Cl(10,0) or Cl(0,10) with a chosen complex structure.
    - *Source:* Georgi, "Lie Algebras in Particle Physics".
    - *Links:* LNB-006, 015, 147, INP-013.
    - *Script:* yes. The bivectors of Cl(0,10) and the complex 32 with J chosen.

17. **Bogoliubov transformations: pairing as the degree ±2 parts.** (Phenomenon approached: superconducting pairing, BCS.)
    - *Statement:* exp of the degree ±2 bivectors (pair creation and annihilation) are the Bogoliubov transformations. They preserve the CAR and mix particle numbers by two. Spin(2n) acting on the Fock space is the Bogoliubov group.
    - *Source:* Bogoliubov, "On a new method in the theory of superconductivity"; Blaizot and Ripka, "Quantum Theory of Finite Systems".
    - *Links:* LNB-006, 015, 147, 034.
    - *Script:* yes, on the 32 labels.

18. **The real lattice II₂,₁₈ and U(1,9) ⊂ O(2,18).**
    - *Statement:* The complex (1,9) form over ℤ[ω] has underlying real lattice II₂,₁₈. U(1,9) embeds in O(2,18), and Thurston's complex-hyperbolic moduli space sits inside the Hermitian symmetric domain of O(2,18). This is a precise relation between "complex 10" and "real 20", although not one with Minkowski ℝ^{1,9}. II₂,₁₈ is also the Narain lattice of the heterotic string on T², a coincidence of name the page should not overread.
    - *Source:* Thurston, "Shapes of polyhedra and triangulations of the sphere"; Narain, "New heterotic string theories in uncompactified dimensions < 10".
    - *Links:* LNB-011, 022, 036, 042, 151.
    - *Script:* partly. The embedding U(1,9) ⊂ O(2,18) is linear algebra; moduli no.

19. **Berezin integral, 2D TQFT and super-dimension 0.**
    - *Statement:* The top-label form on Λ(ℝ^r) is the Berezin integral. A commutative Frobenius algebra is a 2D TQFT, whose torus amplitude is the trace of the handle element m∘Δ. In sVec this is the super-dimension, 0 for Λ(ℝ^r), which is T20(d).
    - *Effect:* LNB-025's 'not special, m∘Δ nilpotent' and T20(d) become one statement.
    - *Source:* Abrams, "Two-dimensional topological quantum field theories and Frobenius algebras"; Berezin, "The Method of Second Quantization".
    - *Links:* LNB-025, 037, T3, T20.
    - *Script:* yes, exact.

20. **The origin of the Madelung order and its exceptions.**
    - *Statement:* The n + l ordering follows approximately from the screened (Thomas–Fermi) central potential. Its exceptions (Cr, Cu, many lanthanides and actinides) come from interactions beyond the central field. The Atlas takes the order as input (INP-084), and Baez's "modified Hamiltonian" is recalled only (LNB-012, line 5).
    - *Source:* Thomas, "The calculation of atomic fields"; Fermi, "Un metodo statistico per la determinazione di alcune proprietà dell'atomo".
    - *Links:* LNB-024, 173, 174, 177, 012.
    - *Script:* partly. Solve the Thomas–Fermi equation numerically and order the levels; no exceptions without interactions.
