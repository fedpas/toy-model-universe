# Chunk E as a mathematician labels it (176 rows)

Rows: the Schuller chapter of the Lenses page (LNS-001 to 076 in the research tabs, LNS-101 to 135 in the widget/learner tab), the Furey calibration (FUR-001 to 005, PAG-013 to 016, INP-087 to 094), the Map page (MAP-001 to 035, PAG-025 to 027), the For-researchers remarks on theorems (THM-001 to 006) and sources (SRC-001 to 003), and the Ask row (PAG-028). Labels: `math_E.jsonl` (validator: 176 rows, 0 problems).

Profile of the labels. Kinds: 39 computation, 35 theorem, 24 question, 19 range, 18 reading, 11 meta, 9 definition, 6 lemma, 5 example, 2 reduction, 2 counterexample, 2 classification, and one each of pointer, invariant, construction, conjecture. Edges: 171 equiv, 132 derives, 15 uses-input, 7 instance, 4 contradicts, 0 cycle.

---

## A. How mathematics would organise these rows

**How this differs from the page order.** The Schuller chapter follows its source (his chapters, then the seven stones of his pipeline) and says most things four times: in the first look (LNS-001 to 009), in the research tabs (LNS-010 to 062), in the honest summary (LNS-051 to 057 and 070 to 076) and in the widget tab (LNS-101 to 135). Mathematics would order the rows by object instead: exterior and Clifford algebra, then modules and Fock space, then graded products and Brauer–Wall, then symbols and hyperbolicity, then SL(2,ℝ), then geometry. It would keep **one canonical row per theorem** and store the other registers as translations of it. Today T18(f) takes nine rows (LNS-002, 012, 052, 060, 064, 071, 102, 105, 116), T20 seven and T19 seven. The first-look rows also state theorems before the chunk defines what they need (hyperbolic polynomial, principal polynomial, commutant, graded central simple algebra are never defined).

### A.0 Not mathematics: meta rows and inputs
- **Meta** (about the Atlas): PAG-013, PAG-025, PAG-026, PAG-027, PAG-028, MAP-015, MAP-029, MAP-030, MAP-031, MAP-032, LNS-041. MAP-035 is a reading list (pointer).
- **Inputs**: INP-087 (octonion table and the flag ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆), INP-088 = INP-091 (ω = L_{e₇}), INP-089 (her constructions), INP-090 (the block partition), INP-092 (the formulas for Y and Q), INP-093 and INP-094 (Fig. 1 labels). In mathematical terms these give a structured space (V, ω, a Lagrangian, an idempotent decomposition), and the Furey rows compute with it.

### A.1 Algebra: definitions and constructions (these should come first)
1. *The filtration lemma*, THM-001: gr Cl = Λ, and the Clifford product is wedge plus contraction. It justifies everything in item 2.
2. *Exterior algebra as the all-null rule, Clifford algebra as its deformation*: LNS-001, LNS-011, LNS-051, LNS-108, LNS-109 (LNS-070 is the learner version).
3. *Fock space defined as Λ(H)*: LNS-031. LNS-133 and LNS-066 are readings of it (labels as occupation patterns).
4. *Graded tensor product, and left and right actions*: LNS-015 is the construction; LNS-113 and LNS-114 are its consequences for r = 0 and r ≥ 1.
5. *Peirce decomposition of End(V) on Furey's data*: FUR-001, MAP-010.

### A.2 Algebra: theorems proved for all n in the Atlas
- Frobenius structure (T3): LNS-058, LNS-110, and the Hodge-star clause of LNS-001 and LNS-011.
- Symbol determinant (T16): LNS-003, LNS-059, LNS-117, LNS-119. Lemmas: LNS-120 (Kaluza–Klein mass) and LNS-033 = LNS-040 (Dirac sign conventions).
- Fock space (T20): LNS-005, LNS-019, LNS-062, LNS-130. Lemma: LNS-131 (a paired null is not a null generator). Example: LNS-129.
- Even subalgebra (T5): MAP-013. Example: LNS-020 (Spin⁺(1,3) ≅ SL(2,ℂ)).
- Null generators are super-central (T2): LNS-114.

### A.3 Algebra: ranges that are standard theorems (candidates for promotion)
- Wall (A ⊗̂ A^op ≅ End A): LNS-006, LNS-015, LNS-113.
- Double centraliser: LNS-007, LNS-016, LNS-053, LNS-072, LNS-111, LNS-112.
- Chevalley: THM-001.
- Incidence algebras and cohomology: THM-002, THM-003, THM-004, THM-006.
- One-line identities with closed forms: MAP-016 (the so(p,q) structure constants) and MAP-033 (Maxwell–Calladine). MAP-006 (periodicity, which T4 proves) and MAP-021 (Cartan identities, claimed for all n by a plain-text chain) belong here too.

### A.4 Classifications and invariants
- MAP-002: the mod-8 table. The ungraded part is proved; the graded part is recalled.
- LNS-118: the ungraded type separates Cl(1,3) from Cl(3,1), which the quadratic form cannot do.
- LNS-127: the conjugacy classes of SL(2,ℝ).
- The Petrov part of LNS-013.
- MAP-014: the E-series types. Its headline is a reduction to van der Blij's lemma.

### A.5 Analysis and geometry
- *Hyperbolicity* (one theorem, T18(f)). Canonical row: LNS-012. LNS-002 is its r = 0 instance. Restatements: LNS-052, 060, 064, 071, 102, 105, 116. Questions: LNS-028, 045, 046, 106.
- *Floquet–Bloch* (T19). Canonical row: LNS-022. Restatements: LNS-008, 061, 122, 124, 125. Example: LNS-126. Corrections to the notes: LNS-043 (a reading), LNS-044 (a reduction). Question: LNS-026.
- *Kaluza–Klein*: LNS-017 (computation), LNS-120 (lemma), LNS-121 (reading).
- *Gravity and Λ*: MAP-021; LNS-032 (Einstein–Cartan, computed at sample points); LNS-034 = LNS-107 (Λ on Schwarzschild–(anti-)de Sitter frames); LNS-049 (conjecture).
- *Area metrics*: LNS-013 (a bundle of computations); LNS-030 and LNS-048 (questions).
- *The frozen deformation algebra*: LNS-014 (example); LNS-029 = LNS-047 (questions). LNS-010 is the evaluation of the whole pipeline.
- *Null surfaces and boosts*: MAP-028 (= T18(a),(e)) and THM-005 (Carroll and Galilei).

### A.6 Combinatorics
- *The E₈ descent*: LNS-009 = LNS-018. These are computations, and T10(5) identifies the subsystems they find. Also MAP-012, MAP-014, MAP-022.
- *Hypercube spectra and frameworks*: MAP-026 (T19(3),(4)), MAP-033, MAP-034 (question).
- *Furey counting*: FUR-002; FUR-003 (an extended Hamming Lagrangian, not named as such); FUR-004 (counterexample); PAG-015, MAP-007, MAP-009. Question: FUR-005 = PAG-016.
- *Pauli strings*: LNS-132 (computation), LNS-038 (question).
- *Majkić*: SRC-001 (positive additive weights); SRC-003 (the counts are the Dedekind numbers, not named as such).

### A.7 Category theory and topology
- Results: THM-003 (cohomology of ℤ₂ⁿ, of the partial monoid and of the nerve of Bₙ); THM-004 (incidence algebra and Hochschild groups); SRC-002 (the area cocycle is a coboundary); SRC-003 (Fun(Bₖ, C)); LNS-039 (super-dimension); LNS-006 and LNS-015 (Brauer–Wall, read as a group of graded Morita classes).
- Gaps that are really topology: LNS-023 (gluing); LNS-036 and LNS-050 (a global base and fibre); LNS-025 and LNS-069 (infinite dimensions).

### A.8 Calibrations against sources (computations of a source's own statements)
- Schuller's notes: LNS-021, LNS-055, LNS-074, LNS-134, LNS-135 (spin and Stern–Gerlach); LNS-004 (Casimir); LNS-042 (a counterexample: the printed Dirac sign); LNS-010 (his printed closure equations, evaluated).
- Map nodes of the Equations steps: MAP-003 to 006 and MAP-016 to 028. Each is equivalent to its EQN tally row.

### A.9 Readings (ours)
LNS-027, 035, 043, 054, 056, 063, 065, 066, 067, 073, 075, 101, 104, 115, 121, 123, 128, 133. Most are naming choices (base and fibre, outside and inside, seats) or the sign trio −1/0/+1 (LNS-056 and its four restatements). They rest on theorems and add no new statement.

### A.10 Open
- Questions: LNS-023 to 026, 028 to 030, 036, 038, 039, 045 to 048, 050, 057, 068, 069, 076, 103, 106; FUR-005; PAG-016; MAP-034.
- Conjecture: LNS-049.
- Pointer: MAP-035.

**The Map page.** It mixes theorem-level statements (MAP-001, 013, 026, 028), page descriptions and machine timings (MAP-027). Mathematics would keep the Map as a table of contents pointing to canonical rows by equiv edges, as the labels do, and move timings and counts into meta rows.

---

## B. Chains, classes and loops

### Chains (by `derives`)
1. T1 → THM-001 → LNS-011 → LNS-027. Forms and Clifford algebras share one table; LNS-027 adds a reading.
2. T16 → LNS-003 → LNS-012 ← T18; then LNS-012 → LNS-028 and LNS-046. LNS-002 is an instance of LNS-012. This is the hyperbolicity chain.
3. T16 → LNS-003 → LNS-042 (the printed Dirac sign fails), and T16 → LNS-033 (≡ LNS-040).
4. T16 and T18 → LNS-120 → LNS-121 (≡ LNS-017). The Kaluza–Klein chain.
5. T19 → LNS-022 → LNS-026, LNS-035, LNS-043, LNS-056; T19 → LNS-124 → LNS-123, LNS-128; T19 → LNS-044. The band chain.
6. T20 → LNS-019 → LNS-055, LNS-132; T20 → LNS-131 → LNS-129. The Fock chain.
7. T2 → LNS-015 → LNS-036 → LNS-050, and LNS-015 → LNS-053; T2 → LNS-114. From the graded product to the gluing question.
8. T4 → LNS-016 → LNS-036, LNS-115; T4 → LNS-118. The commutant chain.
9. GRV-007 → LNS-034 → LNS-049, and GRV-010 → LNS-032. The sign of Λ, ending in a conjecture.
10. LNS-002, LNS-003, LNS-014 → LNS-010 → LNS-024, LNS-057. Schuller's pipeline to "where the Atlas stops". LNS-014 → LNS-029.
11. FUR-001 → FUR-002 → FUR-005, PAG-014, PAG-015, MAP-007, MAP-009; T6 → FUR-003 → FUR-004 → FUR-005. The Furey chain.
12. T6 and LNC-140 → THM-003 → SRC-002; T8 → THM-002, THM-004, THM-006. The cohomology and incidence chain.
13. T10 → LNS-009, LNS-018, MAP-012, MAP-014; core·B13 → MAP-014. The E-series chain.
14. GRV-004 → LNS-013 → LNS-030 (≡ LNS-048). The area-metric chain.

### Classes (by `equiv`)
- K1, one table for forms and cells: LNS-001, 011, 051, 070, 108, 109, with THM-001 as the lemma behind them.
- K2, hyperbolic iff Lorentzian (T18(f)): LNS-012, 052, 060, 064, 071, 102, 105, 116 and PAG-011. LNS-002 is the r = 0 instance.
- K3, the Dirac symbol (T16): LNS-003, 059, 117, 119.
- K4, Dirac sign conventions: LNS-033, 040, 042, and the convention clause of MAP-001.
- K5, Fock space (T20): LNS-005, 019, 031, 062, 130, 133. LNS-129 is an instance and LNS-066 a reading.
- K6, Wall: LNS-006, 015, 113.
- K7, the double centraliser slider: LNS-007, 016, 053, 072, 111, 112.
- K8, the SL(2,ℝ) trio (T19): LNS-008, 022, 061, 122, 124, 126, 127. The readings LNS-035, 056, 067, 075, 123, 128 form a parallel class for one reading.
- K9, Kaluza–Klein: LNS-017, 120.
- K10, Λ from the extra generator: LNS-034, 107. LNS-049 is a conjecture, not an equivalent statement.
- K11, the E₈ descent: LNS-009, 018 and LNB-016.
- K12, spin and Stern–Gerlach: LNS-021, 134, 135, and separately LNS-055 ≡ LNS-074.
- K13, the names: LNS-054, 065, 073, 115.
- K14, the stops: LNS-057, 068, 076, 103. LNS-024 says the same as worded but contradicts other rows (see below).
- K15, grades of Schuller's stones: LNS-010, 063, 101, 104.
- Open pairs: LNS-028 ≡ LNS-045 (≡ QT10); LNS-029 ≡ LNS-047; LNS-030 ≡ LNS-048; LNS-036 ≡ LNS-050.
- Furey: FUR-001 ≡ MAP-010 ≡ RSN-002 ≡ ATL-025; FUR-003 ≡ INP-090; INP-088 ≡ INP-091; FUR-005 ≡ PAG-016; PAG-014 ≡ PAG-015 ≡ MAP-007.
- Map and Equations, one class per step: MAP-003 ≡ EQN-006 ≡ PAG-008; MAP-016 ≡ EQN-007; MAP-017 ≡ EQN-008; MAP-018 ≡ EQN-009; MAP-019 ≡ EQN-010; MAP-020 ≡ EQN-011; MAP-021 ≡ EQN-012/013; MAP-022 ≡ EQN-014; MAP-023 ≡ EQN-015; MAP-024 ≡ EQN-016; MAP-025 ≡ EQN-017; MAP-026 ≡ EQN-018; MAP-027 ≡ EQN-019; MAP-028 ≡ EQN-020; MAP-033 ≡ RIG-006.
- Meta: PAG-025 ≡ MAP-030; PAG-027 ≡ MAP-032; PAG-028 ≡ MAP-031; LNS-041 ≡ QE4.
- Across chunks: LNS-001 and LNS-110 ≡ LNC-028 and LNC-033; LNS-037 ≡ LNC-078; LNS-039 ≡ LNC-080; SRC-001 ≡ LNC-099, LNC-138, LNC-068; SRC-003 ≡ LNC-143; LNS-020 ≡ ATL-008 and LNC-037; MAP-014 ≡ PAG-020 and LNC-047.

### Loops
None are recorded. The nearest candidate is the convention set MAP-001, LNS-033, LNS-042, LNS-118: which generator is called time is fixed by making the Dirac sign agree with the cell type. It is recorded as equiv edges plus an `i-time` input, because nothing in it is derived in a circle.

### Contradictions
- LNS-024 says "No Lagrangian and no variation". It contradicts GRV-005 (an action varied exactly), CPL-005 (Euler–Lagrange equations from a stated L) and LNS-032 (the stress obtained from the tetrad).
- LNS-037 and LNS-025 call states in other signatures open. T15 proves them for every Cl(p,q,r).
- Wording conflicts flagged in notes:
  - LNS-053 says "graded product of base and fibre", but its fibre is the ungraded commutant.
  - LNS-106 calls the C12 gap harmless, which holds only for r = 0.
  - MAP-001 uses "real Dirac operator" in two senses: Hestenes' form in Cl(1,3), γ·∂ − m in Cl(3,1).
  - LNS-104 records that finding F6 of the Atlas's Schuller report disagrees with the report's own Fig. 1.
- Status mismatches:
  - FUR-001 to 004 are flagged checked, but their scripts are listed as "read", so their derived status is cited.
  - PAG-014 and PAG-015 have no check id.
  - PAG-013 and most MAP rows carry a default standardRef (Lundholm–Svensson; Lawson–Michelsohn) that has nothing to do with them.
  - MAP-009 has T13 attached, but its text does not use it.

### Hubs and leaves
- **Hubs** (how many rows of this chunk rest on them):
  - Theorems: T18 (12), T16 (11), T4 (11), T20 (10), T19 (9), T1 (6).
  - Rows: LNS-022 (7), LNS-012 (6), LNS-019 (6), FUR-002 (6), then LNS-016, LNS-010, LNS-003 (5 each).
- **Leaves** (nothing in the chunk rests on them):
  - most Map nodes;
  - the learner and widget restatements (most of LNS-065 to 075 and LNS-101 to 135);
  - all the readings;
  - the questions LNS-026, 038, 039, 046, 050;
  - THM-002, THM-004, THM-005, and all three SRC rows.
  
  Within the chunk, only SRC-002 rests on a For-researchers remark (THM-003).

---

## C. Missing pieces

**Definitions used without being stated.** Each should be a `definition` row of its own:
- the hyperbolic polynomial and its hyperbolicity cone (the LNS-002 family);
- the principal polynomial and its reduction (LNS-003, 010, 117);
- the graded central simple algebra and graded Morita equivalence (LNS-006, 015, 113);
- the commutant and double commutant (LNS-007, 016);
- a Lagrangian, i.e. a maximal totally singular subspace (INP-090, FUR-003);
- a polarization, or Witt pairing (THM-006, LNS-131);
- the area metric (LNS-013);
- the up-set and the direct category (SRC-001, SRC-003).

**Missing pieces, most consequential first.** "Engine" says whether a check script could compute the piece with the Atlas's engine.

1. **Wall's theorem in label form (the graded Brauer group of ℝ).**
   - Statement: for a ℤ₂-graded central simple real algebra A, A ⊗̂ A^op ≅ End(A) as graded algebras. The graded Morita classes form BW(ℝ) ≅ ℤ₈, generated by Cl(1,0).
   - Source: C. T. C. Wall, "Graded Brauer groups" (1964).
   - Links: LNS-006, LNS-015, LNS-113, LNS-114 (where it fails for r ≥ 1), MAP-002, T4, QT1.
   - Field: algebra, category.
   - Engine: partly. The isomorphism Cl(p,q) ⊗̂ Cl(q,p) ≅ Cl(n,n) can be checked for each n; the proof for all n is structural. It turns three range rows and the graded half of MAP-002 into theorems.
2. **Chevalley's filtration theorem.**
   - Statement: Cl(V,Q) is filtered by degree with gr Cl(V,Q) ≅ Λ(V). The quantisation map Λ(V) → Cl(V,Q) is a linear isomorphism, and v·x = v∧x + v⌋x.
   - Source: C. Chevalley, "The Algebraic Theory of Spinors" (1954).
   - Links: THM-001, LNS-001, LNS-011, LNS-051, LNS-109, MAP-005.
   - Field: algebra.
   - Engine: yes. It is the sign formula of T1 restricted to disjoint labels, and it turns THM-001's range into a theorem.
3. **The double centraliser theorem over ℝ.**
   - Statement: for a central simple subalgebra B ⊂ End(V), the commutant C is central simple, C(C) = B, B ⊗ C ≅ End(V), and [C] = [B]⁻¹ = [B] in Br(ℝ) ≅ ℤ₂. When the centre of B is ℂ or ℝ², the map B ⊗ C(B) → End(V) is not injective.
   - Source: N. Jacobson, "Basic Algebra II".
   - Links: LNS-007, LNS-016, LNS-053 (fixes its wording), LNS-072, LNS-111, LNS-112.
   - Field: algebra.
   - Engine: yes.
4. **Gårding hyperbolicity: the definition, the cone and its dual.**
   - Statement: a homogeneous P is hyperbolic in the direction h if P(h) ≠ 0 and t ↦ P(q + th) has only real roots for every q. The hyperbolicity cone is convex, and P is hyperbolic for every h in it. For quadratic forms this happens exactly for Lorentzian signature.
   - Source: L. Gårding, "An inequality for hyperbolic polynomials" (1959).
   - Links: LNS-002, LNS-012, LNS-116, LNS-028, LNS-045, LNS-106, PAG-011, PAG-034, QT10.
   - Field: analysis, geometry.
   - Engine: partly. The quadratic and degenerate quadratic cases can be computed; what the dual of a degenerate P should be is a question of definition, and stating it settles the scope of LNS-106.
5. **The extended Hamming code behind Furey's sixteen axes.**
   - Statement: the seven Fano-line blades g_ag_bg_cg₈ and their products are the 15 non-zero words of RM(1,3), the extended Hamming code [8,4,4] (14 words of weight 4, one of weight 8). Together they form a Lagrangian of the label form of Cl(0,8), and its joint eigenbasis is the axis basis. Every non-identity element has exactly eight −1 eigenvalues, which explains FUR-004.
   - Source: F. J. MacWilliams, N. J. A. Sloane, "The Theory of Error-Correcting Codes" (Reed–Muller codes); the Atlas's own T14(1).
   - Links: FUR-003, FUR-004, INP-090, MAP-010, T14, T11.
   - Field: combinatorics, algebra.
   - Engine: yes (compare the 15 masks with RM(1,3)).
6. **The stabiliser formalism.**
   - Statement: N-qubit Pauli operators modulo phases form 𝔽₂^{2N} with the commutation form. Maximal commuting subgroups are its Lagrangians, and there are ∏_{i=1}^{N}(2^i + 1) of them. The square of a blade is the quadratic refinement.
   - Source: D. Gottesman, "Stabilizer Codes and Quantum Error Correction" (PhD thesis, 1997).
   - Links: LNS-019, LNS-132, LNS-038, FUR-003, INP-090 (the count of 616 out of 18 480), T11.
   - Field: combinatorics.
   - Engine: yes.
7. **Gerstenhaber–Schack: Hochschild cohomology of incidence algebras.**
   - Statement: for a finite poset P, HH•(kP) ≅ H•(Δ(P); k), the cohomology of its order complex. Bₙ has a least and a greatest element, so HH• = k, in degree 0, for every n. Also gl.dim (kA₂)^{⊗n} = n.
   - Source: M. Gerstenhaber, S. D. Schack, "Simplicial cohomology is Hochschild cohomology" (1983).
   - Links: THM-004, THM-002, T8, LNC-140.
   - Field: algebra, category, topology.
   - Engine: partly. It turns THM-004's range into a theorem.
8. **The nerve of a category with an initial object is contractible.**
   - Statement: if C has an initial object, its nerve is contractible, so H^k(C; A) = 0 for k ≥ 1. Every 2-cocycle on Bₙ is therefore a coboundary for every n: both the bit-rule sign (its primitive is the Jordan–Wigner string) and the area cocycle of SRC-002.
   - Source: D. Quillen, "Higher algebraic K-theory: I" (1973).
   - Links: THM-003, SRC-002, LNC-140, T6.
   - Field: topology, category.
   - Engine: yes.
9. **A global base and fibre: bundles of Clifford modules, and spin and Pin structures.**
   - Statement: a module bundle over the tangent Clifford bundle exists exactly when the structure group lifts. Spin needs w₁ = w₂ = 0; the two Pin groups are obstructed by w₂ and by w₂ + w₁² respectively. The commutant of the local module becomes a twisting bundle (as in Spin^c).
   - Sources: H. B. Lawson, M.-L. Michelsohn, "Spin Geometry"; R. C. Kirby, L. R. Taylor, "Pin structures on low-dimensional manifolds".
   - Links: LNS-023, LNS-036, LNS-050, LNS-015, LNS-016, LAB-018.
   - Field: topology, geometry.
   - Engine: no (it needs manifolds; at most local examples of transition functions).
10. **Fermion-to-qubit encodings as gauges of the cube sign.**
    - Statement: every anticommuting sign on the cube is a gauge transform of the Jordan–Wigner string (T6(a)). The Jordan–Wigner and Bravyi–Kitaev encodings are different gauges, or orderings, of the same CAR algebra.
    - Source: S. Bravyi, A. Kitaev, "Fermionic quantum computation" (2002).
    - Links: LNS-019, LNS-132, THM-003, LNC-056, T6, T20.
    - Field: combinatorics, category.
    - Engine: yes.
11. **One generation from two Peirce decompositions.**
    - Statement: Furey's Peirce edges of End(V) and the Baez–Bokor–Boyle Peirce pieces of the bi-Cayley triple (1, 1, 6, 3, 3, 2) both cut out one generation. One statement in Jordan-pair language (the Peirce spaces of colinear tripotents) would make the Furey page and the Baez chapter one row.
    - Sources: J. C. Baez, J. Bokor, L. Boyle, "Jordan pair quantum theory and the Standard Model"; O. Loos, "Jordan Pairs" (1975).
    - Links: FUR-001, FUR-002, LNB-014, LNB-030, GEN-006, RSN-002.
    - Field: algebra.
    - Engine: partly (both sides are computed; the map between them is not).
12. **Positive bases (forms over ℝ≥0).**
    - Statement: if a basis has non-negative structure constants, the simplicial cone it spans is closed under products and contains no line. A non-real element of ℂ or ℍ inside that cone has powers whose directions are dense on a circle, which would force a line into the cone. So ℂ and ℍ have no such basis, which answers the open item of THM-002. Separately, e_ie_j = −e_je_i gives every cell with n ≥ 2 a negative constant under any re-signing.
    - Source: elementary (no source read).
    - Links: THM-002, T8.
    - Field: algebra.
    - Engine: no for the proof; the existing checks remain as illustrations.
13. **Direct categories and additive weights.**
    - Statement: a finite category has a strictly positive additive weight iff it is direct (no non-identity endomorphism, no isomorphism between distinct objects). One direction: finite hom-sets force f^a = f^b, so the weight of f would be 0. The other: a linear extension φ gives the weight φ(cod) − φ(dom).
    - Source: M. Hovey, "Model Categories" (direct and Reedy categories).
    - Links: SRC-001, LNC-138.
    - Field: category, combinatorics.
    - Engine: yes. It replaces the "888 categories" range with a theorem.
14. **The exponential law for functor categories.**
    - Statement: Cat is cartesian closed, Fun(A × B, C) ≅ Fun(A, Fun(B, C)). With Bₖ₊₁ = Bₖ × B₁ this gives Majkić's levels C_{k+1} = Fun(Bₖ, C) for every C.
    - Source: S. Mac Lane, "Categories for the Working Mathematician".
    - Links: SRC-003, LNC-143.
    - Field: category.
    - Engine: yes for finite C.
15. **Dedekind numbers.**
    - Statement: the number of up-sets of Bₖ (equivalently, monotone Boolean functions of k variables) is the Dedekind number M(k) = 2, 3, 6, 20, 168, 7581, 7828354, … These are exactly the object counts in SRC-003.
    - Source: R. Dedekind, "Über Zerlegungen von Zahlen durch ihre grössten gemeinsamen Teiler" (1897).
    - Links: SRC-003, LNC-143.
    - Field: combinatorics.
    - Engine: yes.
16. **The Hill discriminant and the Floquet–Bloch spectrum.**
    - Statement: for −ψ″ + Vψ with periodic V, the spectrum is {E : |Δ(E)| ≤ 2} with Δ(E) = ψ₁(a) + ψ₂′(a). It is a union of closed bands whose edges are periodic or antiperiodic eigenvalues.
    - Sources: M. S. P. Eastham, "The Spectral Theory of Periodic Differential Equations"; M. Reed, B. Simon, "Methods of Modern Mathematical Physics IV".
    - Links: LNS-022, LNS-026, LNS-043, LNS-044, LNS-125, T19.
    - Field: analysis.
    - Engine: partly (Δ yes, the spectral side no).
17. **Contractions and the Cayley–Klein family.**
    - Statement: the algebras with structure constants depending on s ∈ {−1, 0, +1} form one Inönü–Wigner contraction family. The possible kinematical algebras, Carroll and Galilei among them, are classified.
    - Sources: E. Inönü, E. P. Wigner, "On the contraction of groups and their representations" (1953); H. Bacry, J.-M. Lévy-Leblond, "Possible kinematics" (1968).
    - Links: MAP-023, LNS-014, LNS-029, LNS-047, THM-005, PRJ-002.
    - Field: algebra, geometry.
    - Engine: yes.
18. **Petrov classification, all types.**
    - Statement: the self-dual Weyl tensor, written as a complex symmetric trace-free 3 × 3 matrix Q, has Jordan types I, II, D, III, N, O. The Atlas exhibits D, N, O and I, so II and III are missing test cases.
    - Source: H. Stephani, D. Kramer, M. MacCallum, C. Hoenselaers, E. Herlt, "Exact Solutions of Einstein's Field Equations".
    - Links: LNS-013, MAP-021, MAP-028.
    - Field: geometry.
    - Engine: yes (it needs one frame of type II and one of type III).
19. **Irreducible decomposition of the constitutive tensor.**
    - Statement: the 36 components split as principal 20, skewon 15 and axion 1 under GL(4), and the principal part splits further under the Lorentz group. This is the frame-independent replacement for the 6 + 12 + 3 picture of LNS-013.
    - Source: F. W. Hehl, Yu. N. Obukhov, "Foundations of Classical Electrodynamics: Charge, Flux, and Metric" (2003).
    - Links: LNS-013, LNS-030, LNS-048.
    - Field: geometry, algebra.
    - Engine: yes.
20. **Kaluza–Klein reduction formulas.**
    - Statement: with g₅ = g₄ + φ²(dy + A)², the 5D Einstein–Hilbert action reduces to 4D Einstein–Maxwell–dilaton, and a constant φ is consistent only if F² = 0 (or the flux is balanced by a cosmological term).
    - Source: J. M. Overduin, P. S. Wesson, "Kaluza–Klein gravity" (1997).
    - Links: LNS-017, LNS-120, LNS-121.
    - Field: geometry.
    - Engine: yes, symbolically rather than at sample points.
21. **Einstein–Cartan theory with Dirac matter.**
    - Statement: the torsion is fixed algebraically by the axial spin current. Eliminating it gives the Hehl–Datta four-fermion term, and Belinfante–Rosenfeld symmetrises the canonical stress.
    - Source: F. W. Hehl, P. von der Heyde, G. D. Kerlick, J. M. Nester, "General relativity with spin and torsion" (1976).
    - Links: LNS-032, LNS-024 (its wording), GRV-010.
    - Field: geometry.
    - Engine: yes, as a symbolic version of the sampled checks.
22. **Maxwell–Calladine for the n-cube framework, in closed form.**
    - Statement: the axis-parallel n-cube framework has no self-stress, because the n bars at a vertex are independent. It therefore has n·2ⁿ⁻¹ − C(n+1,2) internal mechanisms for every n.
    - Source: C. R. Calladine, "Buckminster Fuller's 'tensegrity' structures and Clerk Maxwell's rules for the construction of stiff frames" (1978).
    - Links: MAP-033, RIG-006, SPR-004.
    - Field: combinatorics, geometry.
    - Engine: yes.
23. **Van der Blij and Milgram inside the Atlas.**
    - Statement: for an even unimodular lattice, σ ≡ 0 mod 8 follows from the Gauss sum (Milgram's formula), the same kind of Gauss sum that gives the clock (T4(iii)). A short proof in the Atlas would make MAP-014 a theorem instead of a reduction.
    - Source: J. Milnor, D. Husemoller, "Symmetric Bilinear Forms" (1973).
    - Links: MAP-014, PAG-020, GOS-005, LNC-047, LAB-018, core·B13.
    - Field: algebra, topology.
    - Engine: partly.
24. **The finite spectral theorem.**
    - Statement: a commuting family of diagonalisable operators has a joint eigenbasis. For commuting blades of square +1, the 2^w joint projectors are the minimal idempotents of a maximal split commutative subalgebra, where w is the Witt index. This is the "finite shadow" of LNS-038.
    - Source: P. R. Halmos, "Finite-Dimensional Vector Spaces".
    - Links: LNS-038, LNS-025, LNC-059, T11.
    - Field: algebra, analysis.
    - Engine: yes.

**Two groups of the items above:**
- Links from algebra or geometry to category theory or topology that the Atlas does not draw: items 1, 7, 8, 9, 10, 13, 14.
- Theorems that would turn a stated range into a theorem: items 1, 2, 3, 7, 8, 12, 13, 22, 23.
