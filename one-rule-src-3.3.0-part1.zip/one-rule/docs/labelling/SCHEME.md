# The row-labelling scheme of the Atlas (draft 1, 10 Oct 2026)

The Atlas labels blades by bit masks: a blade is the set of generators it contains, the product of two blades is the XOR of their sets with a sign, the sign depends on the squares of the shared generators (+1, −1, 0), the grade is the popcount, and the cell Cl(p,q,r) is fixed by how many generators square to +1, −1 and 0. Everything starts at Cl(0,0,0) = ℝ, the empty label.

This scheme labels the **statements** of the Atlas (its matrix rows) the same way. It is a labelling, not a theorem about statements: its purpose is to organise the rows so that a reader, a page, or an agent can find what a statement rests on, what it needs from outside, and which statements are its neighbours.

## 1. The generators: the primitive notions of the Atlas

A statement is labelled by the **set of primitive notions it uses**. Each notion is a generator with an intrinsic square:

- **ε = +1, notions the rule supplies.** The Atlas can compute with them from the bit rule alone. Invertible: from the rule you reach the statement, from the statement you read the rule.
- **ε = −1, notions imported from the literature.** Standard results that are recalled or compared, not re-derived here (the Atlas's own phrase: "reduced", "recalled", "pointer, source unread"). They are checkable but face the other way: the statement rests on a source.
- **ε = 0, inputs.** Choices and data the algebra does not supply (a chart, a time orientation, a complex structure, an action, an outside table). Nilpotent: you cannot invert them back into the rule, and a link that passes only through a shared input is not a derivation.

The list below is ordered from Cl(0,0,0) outward, so that the grade of a statement grows with its distance from ℝ. Codes are the bit names used in the data; the prime is the Gödel name for the prime view (see §5).

| bit | code | ε | prime | the notion |
|---|---|---|---|---|
| 0 | `lbl` | +1 | 2 | labels as bit masks, XOR, popcount, the group ℤ₂ⁿ, blades as subsets, the Cube/Simplex/Prime views of a label |
| 1 | `sgn` | +1 | 3 | the sign cocycle s(a,b), reordering parity, associativity, the gauge of the sign, cochains that are not cocycles (octonion sign) |
| 2 | `sq` | +1 | 5 | the squares ε of the generators, the signature (p,q,r), the cell Cl(p,q,r), Spatial/Temporal convention, which generator is "space" or "time" as algebra |
| 3 | `grd` | +1 | 7 | grade, parity π, the even subalgebra, filtration, Λ as associated graded, pseudoscalar/volume element |
| 4 | `qf` | +1 | 11 | the label form Q and its polar form, O(Q) over 𝔽₂, isometry classes of triples (V,Q,π), Witt index, totally singular subspaces |
| 5 | `clk` | +1 | 13 | the ℤ₄ form w = π + 2Q, the Gauss sum, the clock c = p − q mod 8, the type table ℝ/ℂ/ℍ and doubled types, Brown invariant, Frobenius–Schur count |
| 6 | `mir` | +1 | 17 | the mirror Cl(p,q) ↔ Cl(q,p), reversion, Clifford conjugation, the dagger, the top-blade Frobenius form, states/positivity |
| 7 | `nul` | +1 | 19 | null generators, the radical J, Loewy layers, super-centre, exterior algebra, forms and d as the null bit rule, paired nulls vs null generators |
| 8 | `tns` | +1 | 23 | doubling, graded tensor product, periodicity, Cl(n,n) = End(Λ), Morita/Azumaya, base change to Λ(ℝʳ), halving/face/complement moves |
| 9 | `mod` | +1 | 29 | modules, spinors, ideals, Peirce idempotents, Fock space and CAR, ladder operators, projectors, the Born rule |
| 10 | `biv` | +1 | 31 | bivectors, commutators, Lie algebras so(p,q) and their subalgebras, rotors/versors, the trinity of bivector squares (rotation/boost/translation), Cartan–Dieudonné, invariant decomposition |
| 11 | `cnx` | +1 | 37 | connection, curvature, torsion, Bianchi identities, covariant derivative, the Einstein form, local Lorentz covariance, the extra generator (projective/conformal reading), horizon generators |
| 12 | `var` | +1 | 41 | Euler–Lagrange forms, first variation, Noether identities, stress and spin forms, currents, charge conservation (computed by the engine once an action is given) |
| 13 | `sol` | +1 | 43 | exact solutions and series computed on the engine: Kerr–Schild frames, FRW series, plane waves, surface gravity, Komar/Smarr, weak-field limit, perihelion, deviation |
| 14 | `lat` | +1 | 47 | lattices and root systems: I_{p,q}, E_n = k^⊥, Gosset polytopes, orthoplex/demicube/cube counts, W(E_n) mod 2, van der Blij |
| 15 | `fin` | +1 | 53 | finite structures: codes (Hamming, Golay), Steiner systems, O(Q)(𝔽₂) as a group, transvections, quadrics, Peres–Mermin, label symmetry groups |
| 16 | `div` | +1 | 59 | division algebras on labels: octonions as a cochain, Fano plane, G₂, triality, Cayley–Dickson, composition |
| 17 | `dyn` | +1 | 61 | mechanics on the engine: forque, rigid bodies, PGA flows, springs and Walsh modes, signed networks, Floquet bands, Kepler through Fock |
| 18 | `s-alg` | −1 | 67 | standard algebra recalled or compared: Brauer–Wall (Wall), Hurwitz, Wood, Dieudonné, Nakayama/Skowroński–Yamagata, Lundholm–Svensson type table, representation type (Wang, Ladkani), Hochschild |
| 19 | `s-geo` | −1 | 71 | standard geometry and relativity: the Christoffel route, Schwarzschild/Kerr/RN/KN/FRW, Birkhoff, first law, Petrov, Weyl, MacDowell–Mansouri, Cartan geometry, Wald's identity, Pin⁻ bordism / ABK |
| 20 | `s-phy` | −1 | 73 | standard physics: Maxwell, Lorentz force, Dirac, Yang–Mills, Einstein–Cartan, Belinfante, Hehl–Datta, the Standard Model content, Floquet–Bloch, Kitaev / Fidkowski–Kitaev classes, Wigner's little group |
| 21 | `s-cat` | −1 | 79 | standard category theory and topology: sVec, Frobenius algebras, monoidal categories, nerves, incidence algebras, simplicial complexes, cohomology H², Koszul sign |
| 22 | `src` | −1 | 83 | a specific researcher's text compared line by line: Furey, Baez, Schuller, Hestenes / Lasenby–Doran–Gull, Dorst / De Keninck / Gunn, Roelfs–Eelbode, Tian, Majkić, Pumplün, Hsu–Barker–Hobson–Lasenby, Vollick |
| 23 | `i-chart` | 0 | 89 | a chart, coordinates, a frame class, the flat derivative ∇, units and constants with dimensions |
| 24 | `i-time` | 0 | 97 | a time orientation / which generator is time / the sign convention of the signature taken as a datum / the direction of a flow |
| 25 | `i-J` | 0 | 101 | a complex structure J, the "i", an involution chosen, a Witt split or vacuum chosen, the grade a field lives in |
| 26 | `i-act` | 0 | 103 | a postulated equation or action (Maxwell, Dirac, coupling, Yang–Mills, matter, gravity, a force law), the coupling κ, the sign of the source, Λ, the constitutive relation |
| 27 | `i-tab` | 0 | 107 | an outside table or labelling: the octonion multiplication table, SM labels and hypercharges, Furey's partition, a paper's positions or Fig. 1, JPL ephemerides, the role names of the cards |
| 28 | `i-meta` | 0 | 109 | nothing of the algebra: the statement is about the Atlas itself (its pages, scripts, counts, method, credit, open lists) |

A statement's **label** is the subset of these 29 generators it uses; its **grade** is the popcount; its **cell** is the signature (p,q,r) = (number of +1 notions, number of −1 notions, number of inputs). A statement at (0,0,0) uses nothing: it is ℝ, the starting point. A statement with r = 0 rests on the rule and the literature alone. A statement with p = 0 is not about the rule.

## 2. Composition (what the XOR of two statements means)

Two statements A and B share the notions in A ∧ B and differ in A xor B. The sign of their product is the product of the squares of the shared notions:

- shared rule notions (+1): a derivation can pass through them; the two statements are **linkable** by what they share;
- shared imported notions (−1): the link passes through the literature; it is a **reduced** link, valid but oriented by a source;
- a shared input (0): the product vanishes; a shared chart, convention or table **does not link** two statements.

Hamming distance 1 (one notion more or less) defines the **neighbours** of a statement; the pages of V2 navigate along these neighbourhoods. This is a rule for organisation and navigation; logical dependence is recorded separately (§4).

## 3. The two axes the specialists add

**The physicist's axis (stage; Schuller's "grade falls from algebra to dynamics")**

| stage | code | what the statement is about |
|---|---|---|
| 0 | `A` | the algebra itself: the rule, the cells, the clock, the mirror, the null part |
| 1 | `K` | kinematics and space: signatures, frames, spinors, bivectors, hyperbolicity, lattices |
| 2 | `F` | fields and their equations: Maxwell, Dirac, Yang–Mills, matter, the field equations of gravity |
| 3 | `D` | dynamics and solutions: motion, conservation, exact solutions, horizons, bands, rigid bodies |
| 4 | `O` | observation and calibration: comparison with known physics or data (Maxwell as known, Furey's model, planets, the Standard Model content) |
| 5 | `M` | method and meta: how the Atlas checks, counts, credits, what is open |

Physicist's **type**: `postulate` (a law taken as given), `definition`, `derivation` (follows from earlier rows), `identity` (an exact relation checked), `solution`, `limit` (weak-field, Newtonian, n → …), `symmetry` (covariance, conservation), `observable`, `calibration` (reproduces a known result), `reading` (our interpretation), `open`, `negative` (a result that something fails or is absent).

Physicist's **phenomenon** (zero or more): `light` (electromagnetism), `electron` (Dirac, spin), `gauge` (non-abelian forces), `matter` (charged matter, generations), `gravity`, `black-hole`, `cosmology`, `mechanics` (rigid bodies, springs, forque), `lattice` (bands, chains, solid state), `qm` (states, measurement, contextuality).

**The mathematician's axis (field and kind)**

Field (zero or more): `algebra`, `geometry`, `topology`, `category`, `combinatorics` (counting, codes, lattices, finite groups), `analysis` (series, ODEs, convergence).

Kind: `definition`, `construction`, `lemma`, `theorem` (proved for all n in the Atlas), `range` (proved by exhaustive computation on a stated range), `classification`, `invariant`, `example`, `counterexample`, `computation` (a number or table), `reduction` (rests on a recalled standard theorem), `reading` (ours), `conjecture`, `question`, `dead-end`, `pointer` (source unread), `meta`.

Both personas also give the **standard home** of the statement in their field when they know one: the name under which their field states it (e.g. "Brauer–Wall group", "Arf–Brown–Kervaire invariant", "Fidkowski–Kitaev ℤ₈", "tetrad postulate", "Birkhoff's theorem", "Jordan–Wigner transformation").

## 4. Logical relations between rows

For each row the personas list the rows it depends on, with the relation:

- `derives` — A follows from B (one way; B does not follow from A);
- `equiv` — A and B say the same thing in two languages or two generalities (two ways);
- `instance` — A is a special case or an example of B;
- `uses-input` — A needs B where B is an input row (INP-…) or a convention;
- `cycle` — A and B belong to a set of rows that support each other (a convention fixed by consistency; a definition and the theorem that justifies it);
- `contradicts` — A and B cannot both stand as worded (to be resolved).

Sets of rows that are linearly ordered by `derives` are **chains**; sets closed under `equiv` are **classes**; `cycle` sets are **loops**.

## 5. Bases as lenses on the labels

- **Base 2.** The label is the subset: 29 bits. Composition is XOR.
- **Base 3.** When a notion's role varies with the statement (the frame is derived in "ω is a function of e" and chosen in "the Kerr–Schild frame class"), the per-generator digit is the role in that statement: 0 absent, + used as supplied by the rule, − used as a datum. The scheme avoids this by splitting such notions into two generators (`cnx` vs `i-chart`), so base 2 suffices; base 3 is the lens that shows the role.
- **Base 6 = 2 × 3.** One digit per generator: (present or not) × (its square). It is what the Atlas already does for blades in a cell: the subset and the signature in one word.
- **Primes.** The k-th generator is named by the k-th prime; a statement's label is the product of its primes (square-free). "Uses the notion p" is "p divides the label"; the shared notions are the gcd; the XOR is lcm/gcd. Primes make labels order-free and extensible: a new notion is a new prime, and no existing label changes. This is the Prime view of the Rule page carried over to statements.

None of these changes what a statement says. A base is a lens: a way of writing the same label that makes one property easy to read (membership in base 2, role in base 3, extensibility with primes).

## 6. Derived status (replaces typed flags)

The five flags of v15 are kept as vocabulary but **computed** from the label and the evidence attached to the row:

| status | rule |
|---|---|
| `meta` | the row is about the Atlas itself (kind meta, notions = {i-meta}); Logbook only, no badge |
| `proved-by-atlas` | a script ran and its check id or log is attached (the v15 `checked` with "ran / pass"); shown without a badge |
| `standard` | q > 0 with a source that was read; shown without a badge |
| `cited` | the row names a script or a source as "read", not "ran": **not yet proved by the Atlas**; badge |
| `input` | r > 0 (the row needs a datum); badge naming the input |
| `ours` | kind = reading; badge |
| `open` | kind ∈ {question, conjecture, pointer}; badge. A `dead-end` or `counterexample` is a settled negative result and takes the status its evidence gives it (no `open` badge) |
| `new` | the row entered or changed in the latest wave (v16: the 26 rows of the wave-3 leads); badge until the next release |

A row shows at most one badge in the default view, in this priority: open > cited > ours > input > new. The full status lives in the row's drawer.
