# Judge's log — the two labellings merged into one (10 Oct 2026)

Inputs: ten persona passes (five chunks × physicist, mathematician), all validated with 0 problems (`validate_labels.py`). Merge: `merge_labels.py` (union of notions with provenance; union of relations; derived status). Agreement between the two personas on the 789 v15 rows: mean Jaccard of the notion sets 0.72; 228 rows with identical sets. Relations after the merge: 966 `derives`, 833 `equiv`, 204 `uses-input`, 113 `instance`, 25 declared loops, 14 `contradicts`.

## Decisions applied (`judge_overrides.json`)

1. **Cycles in `derives` (9 found) → 0.** Restatement pairs became `equiv` (PRJ-004/005; LNB-023 with LNB-125 and LNB-145; LNC-018/040); result/question pairs keep only "the question rests on the result" (LNC-055/081, 057/069, 059/079); a checked row cannot rest on an open one (LNC-039 → LNC-077 removed); the clock, its Gauss sum and the ℤ₄ form (LAB-017, LAB-022, LAB-023) are a **declared loop**: they define each other, which is the definition of the clock, not a circular proof.
2. **Contradictions (14) kept and annotated** as `review` notes on the rows, never resolved by changing a text: eight are stale "open" wordings against theorems the Atlas has since proved (T15 for states and the Born rule in every cell: RSN-011, LNS-025, LNS-037, SPN-004; T8 (3) for the tameness of kB₃: LNC-010, LNC-054, LNC-083); two are scope (ATL-002 vs GEN-002: pairing vs deformation; LNS-024 vs GRV-005/LNS-032: Schuller's chapter vs the Atlas); two are inputs that overstate (INP-029: the current's grade is derived; INP-060: the criteria are tested, not taken as given); one is a kept link without a computation (LNB-158 vs LNB-058).
3. **Status rule changed**: `dead-end` and `counterexample` are settled negative results and take the status their evidence gives; only questions, conjectures and pointers are `open` (SCHEME §6).
4. **Evidence mismatches** recorded as review notes, not fixed: PAG-021 says 13 step scripts "ran" while the step rows say "read" (31 rows stay "not yet proved here" until a run is attached); LNB-013/050 cite a skipped check; GOS-003 and RSN-004 call answered question QT8 open.
5. **Rows to split before rendering** (noted by both personas): CPL-011 (about six statements), GRV-011, GRV-004, NUL-001, NUL-004, LAB-005, LAB-006, EQN-019, PRJ-006; every ATL card bundles a checked type line with a naming reading (already split into `…b` rows by the migration).
6. **Both axes kept.** Physicist's stage/type/phenomena and mathematician's field/kind are two orderings of the same rows (the mode switch); where they disagree on the character of a row (physicist `derivation` vs mathematician `reading`), the more cautious word decides the status.

## What the merged labelling shows

- Hubs: T4 (41 rows rest on it), T18 (37), T2 (32), T20 (29), T10 (28), T17 (25), T3 (24), T1 (21); among rows: MAP-001, GRV-010, EQN-007, LNB-021, LNC-014, GRV-006.
- The longest chain runs ten rows from the rigid-body planets back to associativity: RIG-002 → LAB-006 → GRV-004 → GRV-007 → GRV-012 → GRV-010 → GRV-006 → EQN-012 → T1.
- 110 equivalence classes of restatements (largest 62 rows: the Baez chapter's summaries, honest lists and learner cards of one result) — the duplication V2 shows once.
- Notions most used: `src` 297 (the lens chapters compare papers line by line), `lbl` 266, `sq` 262, `nul` 219, `s-phy` 196, `mod` 192, `biv` 188, `grd` 175; inputs: `i-act` 126, `i-tab` 110, `i-chart` 78, `i-J` 74, `i-time` 67.
- Status after the merge (1,013 rows): proved-by-atlas 522, open 127, ours 112, input 93, meta 91, standard 37, cited 31.

## Candidates (missing pieces) — to become `CAND-*` rows (T2.4)

The ten outlines in `outlines/` list about 200 missing pieces. The ones named most often, across personas: Wall's theorem BW(ℝ) = ℤ₈ as a theorem on the labels; the Frenkel–Kac cocycle = the Cl(8,0) sign (so the engine can build e₈); Lovelock's theorem (why the Einstein form is the field equation); Birkhoff in full; the Lorentz force and geodesic motion from conservation (two postulated inputs become derived); the gauge principle; reversion = Clifford conjugation on even elements (four inputs disappear); the Pauli limit g = 2; Chern–Weil and Noether's second theorem (ranges → theorems); Kitaev's chain and the Fidkowski–Kitaev ℤ₈ as computed rows; Carroll boosts as null translations; the Spin(10) spinor and SU(5) in the five-bit labels (sin²θ_W = 3/8 from the labels); E₆ ⊃ D₅ branching 27 = 16 + 10 + 1; Tits–Kantor–Koecher; Witt decomposition as the one definition of the two nulls; Gårding hyperbolicity as a stated definition.
