<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# ONE RULE 2.1.0 — release notes

ONE RULE, *an atlas of cells, clocks and lenses*, shows how one labelling — blades of a Clifford algebra as bit masks, products by XOR with a sign — reaches, step by step and with a check at every step, the cells of the algebra, their clock, light, matter, gravity, mechanics, and the languages of several branches of mathematics and of several researchers. Release 2.1.0 adds **Explore**, its playable layer: the author's trial Octavo V₀ ("the Atlas in eight leaves") brought under the rules of the Atlas. A leaf is one live picture with three notes; a lens explorer redraws one piece of physics in the shapes of the labels. Nothing on an Explore page is typed as fact: every sentence is the text record of a row, every number a picture prints is computed by the kernel and tested against a standard route or a stored check result, and every badge is computed.

## What it holds

<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->
- **Release** 2.1.0 · content: the version the build carries (`content/version.json`, printed in the footer).
- **Statements**: 1,013 rows (the 789 rows of the author's package, with 224 more where a row held several lines), each with a research text in the author's words.
- **Texts**: 1,899 in all — 1,013 research texts and 32 learner texts by the author, 854 learner drafts waiting for review (drafts by file: texts_learner.json 209, texts_learner_2.json 166, texts_learner_baez.json 246, texts_learner_explore.json 61, texts_learner_schuller.json 172).
- **Status**, computed from the evidence and the labelling: proved by the Atlas 522 · standard 37 · not yet proved here (cited) 31 · our reading 112 · needs an input 93 · open 127 · about the Atlas itself 91.
- **Lenses**: 34, with 973 dictionary entries; 1,901 lens readings on 435 rows in 10 lenses; 982 readings in the readings table.
- **Checks**: 250 scripts with 319 recorded runs; the gravity checks: 5,569 pass, 0 fail.
- **Figures**: 57 drawn, 0 of the 57 seeds shown as labelled placeholders.
- **Candidates**: 150 missing pieces named by the labelling passes, kept in the Logbook until the author accepts them as rows.
- **Pages and tables**: 45 routes; 20 theorems; 34 questions (15 answered); 26 sources; 16 glossary terms; 8 wave-3 leads with 28 proposed edits on 26 rows.
- **Explore**: 14 pages — the home, 10 leaves (6 of the 8 on the path, 4 on the shelf) and 3 lens explorers; not drawn yet: Mirrors, Half-turns; 88 placements of rows of the Atlas; 13 figures; 61 learner drafts (22 in the full register, 39 in the short one); 0 new rows.
- **Build**: `dist/app.js` 942.1 kB, 298.1 kB gzipped (budget 340 kB, D20); `dist/app.css` 74.0 kB.
- **Validation** (docs/COVERAGE.md): 0 errors.
<!-- end of the counts -->

## Explore

Open `#/explore` from the Contents menu or from the start page. Explore opens at learner level — plain words, no formula; the level switch turns a page to research level, where the drawers, the lens readings and, in the pictures, the Mathematician's or the Physicist's view appear.

- **The path of eight leaves**: 1 the clock, 2 three moves, 3 mirrors, 4 half-turns, 5 zero, 6 light, 7 fall, 8 roots. Mirrors and half-turns are quiet cards that say "not drawn yet": their logic has no passing test (A30).
- **The shelf**: seats (it hangs under leaf 5), magnets (under leaf 4), charge (under leaf 6), springs (under leaf 2). The shelf shows only the leaves that are drawn.
- **The lens explorers**: the simplex view of Maxwell, the demicube view of moves, the cube view of Maxwell.

A leaf page shows where the leaf sits on the path; its picture, first and wide, with one row of controls (animations start paused); its hero row; three notes; the try line, which says what to do with the controls; the two ways (the rows of the Physicist and of the Mathematician, in the order of the mode); the open fold; the loose leaves that hang there; and "Connect to the full Atlas", which opens the page of the row the leaf rests on, with that row targeted.

| page | where | what the controls change | hero row | rests on |
|---|---|---|---|---|
| The clock | path 1 | the plus and the minus switches; an hour of the dial; the eight and the swap buttons | LAB-017 | LAB-017 (`clock`) |
| Three moves | path 2 | the strength of the spring, from −2 to 2 | LAB-015 | LAB-015 (`clock`) |
| Zero | path 5 | the square of each of three switches (+1, −1, 0); two corners and their product | LNC-101 | LNC-101 (`steps/category`) |
| Light | path 6 | the plus and the minus switches, or a cell of the map | LNS-102 | PAG-011 (`light`) |
| Fall | path 7 | the distance, in nine steps from far out to close in | LAB-005 | LAB-005 (`steps/gauge`) |
| Roots | path 8 | the family of arrows shown; one arrow | SHP-006 | SHP-006 (`shapes`) |
| Seats | shelf, under 5 | a seat; add or take; the names in bits, numbers or primes | LNS-129 | LNS-129 (`steps/schuller`) |
| Magnets | shelf, under 4 | each of three magnets, a quarter turn at a time | LNS-134 | LNS-134 (`steps/schuller`) |
| Springs | shelf, under 2 | a label from 000 to 111; a plucked corner | EQN-018 | EQN-018 (`steps/spring`) |
| Charge | shelf, under 6 | the electric and the magnetic field; three quick fields | PAG-009 | PAG-009 (`light`) |
| Simplex view of Maxwell | explorer | one to four space directions with one time; an edge and an axis; the mirror | MAP-004 | EQN-006 (`light`) |
| Demicube view of moves | explorer | two to four directions; a plane corner and an amount; a second plane corner | MIR-001 | MIR-001 (`steps/mirrors`) |
| Cube view of Maxwell | explorer | two to seven directions and how many are time; a corner and an axis | MAP-003 | EQN-006 (`light`) |

The lens explorers redraw the same labels with the lens chips simplex, cube, demicube and orthoplex; at research level the labels print in bits or in primes.

## What the pictures print

A picture prints names, values and formula readouts that the leaf's logic computes (D28: the logics return data, never sentences). Each number is tied in a test to a standard route that does not use the bit rule's sign — textbook matrices, closed forms, independent integrators — or to a stored check result of `checks/selfcheck/`. What no row states is not printed (D26): the lines of Octavo that no row carries are listed in `docs/EXPLORE_CONTENT.md` as "dropped: no row", and the explorers stop where the stored cells stop (the simplex at four space directions with one time, the cube at seven directions). Turn, boost and slide are told by a mark and a word — a ring with −1, a diamond with +1, a bar with 0 — never by colour alone.

## How Explore is tested

- **The leaf logics**: every number recomputed through the kernel and by a standard route, over the whole state space the controls reach; the outputs of Octavo's modules held value for value; 132 deliberately broken copies of the logics and of the names, each caught by the checks.
- **The lens explorers**: every incidence, sign, target and count against `maxwell.json`; the corners and the 16-cell against `mirrors.json` and `shapes.json`; the product of two mirrors against the textbook boost and rotation matrices; 13 broken copies caught.
- **The pages**: the registry, the hero rows and their figures, at least three notes with texts at both levels, the try lines, the placements, the controls in each picture and the quiet cards, rendered on the server; every Explore page in the coverage invariant at both levels, both modes and every lens; every Explore figure at both levels, both themes, both modes and every lens it declares; the browser smoke test at 390 and 1366 px, light and dark, and from `file://`.

`node tests/explore.test.mjs` runs all of them and prints their checks.

## What is a draft

- The learner texts of Explore are drafts (counted above): the full register for the rows Explore shows that had no learner text, the short register (20 to 200 characters) for the notes and the heroes. A short text says less than its row, never more, and keeps its status and scope words (D21). Each draft passes the checker's rules before it is merged; the author reviews them in `content/texts_learner_explore.json`.
- At learner level a hero prefers its short text, so five pages of the full Atlas open with a shorter hero (A34).
- No new row is merged. Three rows are drafted for the author in `docs/EXPLORE_CONTENT.md` §6 (A22, A24, A28).

## What the author decides

The questions are in `docs/DECISIONS.md` under "Left to the author", each with its options; this release takes the first option of each.

- **A22** "The demicube is the picture of motion in spacetime": left unsaid (the explorer shows it), or one row of kind reading with the badge "our reading" (draft MIR-008).
- **A23** Octavo's facts that only the leaf tests compute (moves on the edges of the demicube, the 16 labels as divisors of 210, the Jordan–Wigner sign as a count of lower primes, Möbius): figures only, or an Atlas check family for the leaf tests, after which they can become rows.
- **A24** "Two mirrors make a boost": stored in `mirrors.json`, stated by no row: numbers only, or one computation row (draft MIR-007).
- **A25** RSN-025 (∇∇F = □F and charge conservation) cites no evidence although `maxwell.json` stores both as true: it shows "not yet proved here", or its evidence gains the Maxwell check.
- **A26** Rows of kind reading that a run check makes proved by the Atlas (LAB-003, MIR-001, NUL-012, SHP-003, SPR-003): kept so, or the reading part as a row of its own.
- **A27** "n-Maxwell": the cube explorer reads it as Maxwell with n generators; a field of another grade would need rows.
- **A28** The prime names: labels only, or one computation row for the rule name(a xor b) = name(a)·name(b)/gcd² (draft LAB-026); 210 is never commented.
- **A29** The Monster guess stays out of every page.
- **A30** The leaves not drawn (mirrors, half-turns, field, steps, cube, electron, bands, tumbling, hung) wait for their tests to pass.
- **A31** The name of the section: "Explore", or the author's "Octavo" (one field of `content/explore/pages.json`).
- **A32** The glossary has no learner definitions, so nothing is underlined at learner level.
- **A33** The E/B/T role marks of the lens explorers for two or more time generators are stored labels without physics words: kept, or hidden.
- **A34** The five learner heroes of the full Atlas that a short text changes (`clock`, `steps/gauge`, `steps/mirrors`, `shapes`, `steps/spring`): kept, or the short text deleted.
- **A35** Magnets hangs under half-turns, which has no page: kept, or hung under a drawn leaf.
- **A36** PAG-003 ("prime labels are notation only") cannot be limited to the primes lens, so the cube explorer does not show it.

## How to run it

Unzip the archive and open `index.html` in a browser: the site runs from the file system, and every view has an address such as `index.html#/explore/clock?l=learner` or `index.html#/steps/grav2?m=math&l=learner&lens=cat`. Or serve the unzipped folder with any static server (for example `python3 -m http.server`, then the address it prints). No network is needed: KaTeX is in `katex/`, and without the web fonts the pages use the system fonts. The check scripts are in `checks/`, the reports and analyses in `reports/`. The notes of each minor release are in `docs/`.

## How to verify it

In the repository, with the offline modules (`export NODE_PATH=/opt/npm-tools/node_modules`; no `npm install`):

- `npm test` runs the migration counts, the kernel against the Python reference, every engine against its recorded fixture, every figure at both levels, both themes and every lens it declares (the Explore figures in both modes too), the Logbook counts, every Explore test, the coverage invariant and the two browser smoke tests;
- `node tests/explore.test.mjs` runs the Explore tests alone (`--data` without the browser);
- `node tests/shipped.test.mjs` checks what ships: no history words in a shipped text, the licence header on every source file, no contact details or user paths, a closed import graph with one kernel for every blade sign, the size budget, the routes and the rows each page shows;
- `npm run release` runs the content pipeline, the build and all of the suites, stops at the first failure, and writes `release/one-rule-v2.1.0.zip` with its size and sha256.

## Licence

PolyForm Noncommercial License 1.0.0 (`LICENSE`): free for noncommercial use, not for commercial use. Required Notice: Copyright (c) 2026 the Cascade Atlas authors. Every source file carries the three-line notice; the author's check scripts carry their own.
