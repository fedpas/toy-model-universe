<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Learner texts of wave 6, part d: `steps/baez`, bz-ladder to bz-periodic (T8d, round 16, for release 2.18.0)

The storyteller T8d of wave 6 wrote under `docs/round16/PLAN.md` §1, §4, §8 and §9, `docs/round14/STORY_ROUND.md` §7 and §3.2 (C1–C11 with D65), on the chains of `docs/round16/SPINE_wave6_baez.md` §5 to §9 (`content/chains/steps-baez/chains.json`; the leads LNB-712, LNB-713 and LNB-714), the wave-6 brief of 19 October (the Baez page cut in three: T8c bz-top and bz-papers, T8d these five sections, T8e bz-ring to bz-notes). The storyteller finished its file and its checks in its copy; this record was drawn up by the lead from the tables when the storyteller's run ended before it wrote its own (the counts and the commands below are read from the file and the copy's logs, not recalled).

**All 10 chains of the five sections are storied; no chain is left out.** Every record has the shape of STORY_ROUND.md §2.2 (`lang: "en"`, `mode: "both"`, `level: "learner"`, `lens: null`, `source: "storyteller@2026-10-19"`, `status: "draft"`, or `human` with the human text's source for the verbatim spans); `termsUsed` and `keptNumbers` are the checker's own. No chain has a chain lead (the three section leads are story rows with plain `full` learner texts).

## 1. What was written

| file (`content/chains/learner/`) | records | what |
|---|---:|---|
| `steps-baez-2.json` (new) | 64 | the 61 spans of the 10 chains of bz-ladder, bz-which, bz-ten, bz-kepler and bz-periodic (2 human verbatim, 5 mentions among them); the learner texts of the section leads LNB-712, LNB-713, LNB-714 |

In all: **61 spans**, **3 lead texts**, no side-note full text due in these sections (SPINE §14: bz-periodic's LNB-057c is human). The translator drafts of the told rows are superseded by the spans (D54) and retire at the release.

## 2. The chains, position by position

| chain · learner title | shape | positions and links (status where weak) | story / budget (C7) |
|---|---|---|---:|
| `steps-baez.bz-ladder.rungs` · "Climbing down from the biggest symmetry, rung by rung" | fork | LNB-016 —order→ CAND-052 —derives→ LNB-016b —order→ CAND-022 —continues·LNB-016→ LNB-016c —continues·LNB-016→ LNB-016d —order→ CAND-066 | 2908 / 2908 |
| `steps-baez.bz-ladder.pieces` · "The rungs as switch patterns, and a family put together" | fork | LNB-016 —order→ CAND-109 —derives→ LNB-016e —continues·LNB-016→ LNB-016f —order→ CAND-020 —derives→ LNB-016h —continues·LNB-016→ LNB-016g (our reading) —continues·LNB-016→ LNB-016i (our reading) — mentions: LNB-016 | 1776 / 1777 |
| `steps-baez.bz-which.stabilisers` · "The algebra that fixes a qubit and a qutrit, and its twin" | fork | LNB-021 —continues→ LNB-021b —continues·LNB-021→ LNB-021c —continues·LNB-021→ LNB-021d —derives·LNB-021→ LNB-111 —continues·LNB-021→ LNB-021e —continues·LNB-021→ LNB-021f | 1641 / 1642 |
| `steps-baez.bz-which.spin9` · "Where the two placements sit inside a bigger symmetry" | line | LNB-021 —continues→ LNB-021g —order→ CAND-133 —order→ CAND-081 — mentions: LNB-021 | 2166 / 2169 |
| `steps-baez.bz-ten.spin-factor` · "A ten-part algebra and the sixteen it carries" | line | LNB-022 —continues→ LNB-022b | 610 / 614 |
| `steps-baez.bz-ten.two-tens` · "A count of triangles, a clock reading, and an open end" | fork | LNB-022 —continues→ LNB-022c —continues·LNB-022→ LNB-022d —order→ CAND-032 —order→ CAND-024 —instance→ LNB-022e —continues·LNB-022→ LNB-022g —continues·LNB-022→ LNB-022f (open) — mentions: LNB-022 | 2129 / 2132 |
| `steps-baez.bz-kepler.orbits` · "Loop, escape or fly-past: three orbits, three sets of moves" | fork | LNB-023 —continues→ LNB-023b —continues·LNB-023→ LNB-023c —order→ CAND-131 —continues·LNB-023→ LNB-023d | 2253 / 2262 |
| `steps-baez.bz-kepler.fock` · "Orbits bent onto a sphere, and a spring beside them" | fork | LNB-023 —continues→ LNB-023e —order→ CAND-029 —continues·LNB-023→ LNB-023f (our reading) —equiv·LNB-023→ LNB-055c (human, our reading) — mentions: LNB-023 | 1829 / 1911 |
| `steps-baez.bz-kepler.shells` · "Shells of the atom, and the symmetry behind them" | fork | LNB-023 —continues→ LNB-023g —continues·LNB-023→ LNB-023h —order→ CAND-041 —continues·LNB-023→ LNB-023i —continues·LNB-023→ LNB-023j —continues·LNB-023→ LNB-023k (our reading) — mentions: LNB-023 | 2329 / 2336 |
| `steps-baez.bz-periodic.madelung` · "Seating electrons in order, as switches turned on" | fork | LNB-173 —derives→ LNB-174 —derives→ LNB-175 (our reading) —equiv→ LNB-176 (human, our reading) —derives·LNB-175→ LNB-024 —continues→ LNB-024b (our reading) —continues·LNB-024→ LNB-024c —order→ CAND-143 | 1978 / 1979 |

**The openings (C4, D65).** `order`: CAND-052 "Then the layers: the first deletion …"; CAND-022 "Then the pair construction: two copies …"; CAND-066 "Then frames: for a frame of …"; CAND-109 "Then the first-layer roots again: 56, …"; CAND-020 "Then a finer split: by the …"; CAND-133 "Then in so(10), split 4 plus …"; …. `derives`: LNB-016b "So from E7 down every step …"; LNB-016e "So the root graphs are models …"; LNB-016h "So the eleven extra states are …"; LNB-111 "From this the map's line: the …"; LNB-174 "So the rows close at 2, …"; LNB-175 "From this, reading a ground state …"; …. `continues`: LNB-016c "And in the papers: the chain …"; LNB-016d "And read as Jordan data, the …"; LNB-016f "And under the E7 paper's su(3) …"; LNB-016g "And reading the ladder as the …"; LNB-016i "And in our reading: the E7 …"; LNB-021b "And the paper's stabilisers as Lie …"; …. `instance`: LNB-022e "For instance (1,9) by the clock: …".

**The weak links (C5).** pieces · 7, LNB-016g (our reading); pieces · 8, LNB-016i (our reading); two-tens · 8, LNB-022f (open); fock · 4, LNB-023f (our reading); fock · 5, LNB-055c (our reading); shells · 7, LNB-023k (our reading); madelung · 3, LNB-175 (our reading); madelung · 4, LNB-176 (our reading); madelung · 6, LNB-024b (our reading). The proved rows keep the status and scope words their research texts carry and no other.

**Human words (C10).** LNB-055c, LNB-176, taken verbatim as their spans with the human text's source; C4 waived there, the neighbouring spans carry the connection.

**Mentions (C8).** (LNB-016) in `pieces`; (LNB-021) in `spin9`; (LNB-022) in `two-tens`; (LNB-023) in `fock`; (LNB-023) in `shells`: one short sentence each, no new number, the row's status word kept.

**First learner words.** CAND-022, CAND-029, CAND-032, CAND-041, CAND-066, CAND-081, CAND-131, CAND-133, CAND-143, LNB-016d, LNB-021: told rows with no learner text before this wave; their spans are their first learner words (D54).

## 3. The commands, in the storyteller's copy (`$SP/v4_agents/t8d`)

- `node tools/check_learner_texts.mjs`: PASS, all 24 rules hold for every record (the shared repository after the hand-back: 2,119 records, PASS).
- `npm run content`: errors 0, warnings 0 (the leads of wave 6 "no learner text yet" on the way, before the other storytellers' files).
- `node tools/merge_chains.mjs --check`: green in the copy; in the shared repository after every hand-back: 186 chains on 26 pages, 185 storied (1 reviewed), 806 spans.
- `node tests/chains.test.mjs`: PASS (14,073 checks); `node tests/coverage.test.mjs`: PASS (the copy, 14 m 38 s).

## 4. For the release owner

- The retire of 2.18.0 moves the translator drafts of the told rows of these five sections (D54/D68); the human texts LNB-055c, LNB-176 and LNB-057c stay.
- Nothing is left out; no checker rule refused a piece twice.

