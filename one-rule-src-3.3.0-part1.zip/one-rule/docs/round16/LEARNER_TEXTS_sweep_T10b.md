<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Learner texts of the sweep, part b: steps/comm, steps/mirrors, steps/dirac, steps/coupling (T10b, round 16, for release 3.0.0)

The sweep storyteller T10b wrote under `docs/round16/PLAN.md` §1 and §5 (the close: every side note of a wave-1 or wave-2 page whose learner text is still the translator's draft, or that has none, gets the storyteller's full text; D68: the text goes into the page file beside the draft it supersedes and wins at the merge), `docs/round14/STORY_ROUND.md` §7 (the voice: one story per piece — what the piece is, why it is on its page, what it links to and what was checked — in plain words, the numbers and the status words kept, no formula), the R-rules R1–R13 as `tools/check_learner_texts.mjs` prints them, and the sweep brief of 19 October (`SWEEP_BRIEF.md` §0–§2; the wave-6 storytellers' brief §0 and §1 for the setup and the locks), with `content/chains/learner/steps-grav2.json` and `docs/round16/LEARNER_TEXTS_wave4_a.md` §3, `LEARNER_TEXTS_wave5_a.md` §1 and §3 as the models. T10a (rule, cells, clock, light) and T10c (matter, steps/baez · bz-generation) wrote at the same time; no file of theirs, and no file of wave 6's storytellers, was touched. No span, no row, no table and no chain file changed: the pages' chains are told, and the spans in `steps-comm.json`, `steps-mirrors.json` and `steps-coupling.json` stand exactly as they were (checked record by record against the shared repository).

**31 full texts written, none refused by the checker, none left out for a rule.** Every record has the shape of §2.2: `lang: "en"`, `mode: "both"`, `level: "learner"`, `lens: null`, `register: "full"`, `status: "draft"`, `source: "storyteller@2026-10-19"`; `termsUsed` and `keptNumbers` are the checker's own (`deriveFields`), never typed. One row of the assignment, **LNS-003**, is written but held back as a spare (§4): its full text on `steps/schuller` · sc-first is T9a's by `SPINE_wave6_schuller.md` §9, and a row has one full text.

## 1. What was written

| file (`content/chains/learner/`) | records | what |
|---|---:|---|
| `steps-comm.json` (3 spans kept, 2 appended) | 5 | the full texts of EQN-004 (eq-comm) and EQN-007 (summary) |
| `steps-mirrors.json` (15 records kept, 12 appended) | 27 | ATL-008, MIR-004, MIR-006, MIR-007, MIR-008 (eq-mirrors); INP-018, INP-019, INP-020, CAND-054 (needs); EQN-014 (summary); MIR-009, MIR-010 (top-notes) |
| `steps-dirac.json` (new) | 11 | EQN-030, LNS-017c (top-notes); LNS-117, EQN-031 (dirac-xref); EQN-008 (summary); INP-021 … INP-026 (needs) |
| `steps-coupling.json` (48 records kept, 6 appended) | 54 | INP-027 … INP-032 (needs) |

In all **31 full texts**: steps/comm 2, steps/mirrors 12, steps/dirac 11, steps/coupling 6. **18 supersede a translator draft** (D68; after `npm run content`, `content/texts.json` holds exactly one learner full text per row, the storyteller's) and **13 are first learner words** (INP-019, INP-021 … INP-026, INP-027 … INP-032: the input rows of the three pages, drawn at learner level for the first time). LAB-015, a side note of eq-mirrors, is T10a's (its one full text on the clock serves every page), as the brief says.

## 2. The rows, by page and section

| row | page · section | status (badge) | characters (R9 limit; the 700 fold) | draft superseded, or first words | numbers kept (R6) |
|---|---|---|---:|---|---|
| EQN-004 | steps/comm · eq-comm | meta | 575 (900; whole) | supersedes the draft of texts_learner.json (112) | — |
| EQN-007 | steps/comm · summary | proved | 524 (900; whole) | supersedes the draft of texts_learner.json (148) | 2, 4, 6, 8, 12 |
| ATL-008 | steps/mirrors · eq-mirrors | proved | 854 (900; folded) | supersedes the full draft of texts_learner.json (578); its short draft stays (the cells cards) | — |
| MIR-004 | steps/mirrors · eq-mirrors | meta | 525 (900; whole) | supersedes the draft of texts_learner.json (212) | — |
| MIR-006 | steps/mirrors · eq-mirrors | standard | 505 (900; whole) | supersedes the draft of texts_learner.json (109) | — |
| MIR-007 | steps/mirrors · eq-mirrors | proved | 755 (900; folded) | supersedes the draft of texts_learner_explore.json (273) | 2, 3, 4, 5, 8 |
| MIR-008 | steps/mirrors · eq-mirrors | ours (our reading) | 692 (900; whole) | supersedes the draft of texts_learner_explore.json (193) | — |
| INP-018 | steps/mirrors · needs | input (sign convention) | 511 (900; whole) | supersedes the draft of texts_learner_explore.json (174) | — |
| INP-019 | steps/mirrors · needs | input (involution) | 760 (900; folded) | first learner words | 4, 8 |
| INP-020 | steps/mirrors · needs | input (time direction) | 799 (900; folded) | supersedes the draft of texts_learner_explore.json (261) | — |
| CAND-054 | steps/mirrors · needs | proved | 830 (900; folded) | supersedes the draft of texts_learner_proofs3.json (871) | 2, 4, 6, 20, 28, 940 |
| EQN-014 | steps/mirrors · summary | proved | 636 (900; whole) | supersedes the draft of texts_learner.json (225) | 2, 4, 8, 16 |
| MIR-009 | steps/mirrors · top-notes | proved | 602 (900; whole) | supersedes the draft of texts_learner_explore.json (277) | 2, 5 |
| MIR-010 | steps/mirrors · top-notes | proved | 579 (900; whole) | supersedes the draft of texts_learner_explore.json (333) | 2, 5, 90 |
| EQN-030 | steps/dirac · top-notes | proved | 826 (900; folded) | supersedes the full draft of texts_learner_explore.json (441); its short draft stays (the top note) | 2, 3 |
| LNS-017c | steps/dirac · top-notes | proved | 410 (900; whole) | supersedes the draft of texts_learner_schuller.json (78) | — |
| LNS-117 | steps/dirac · dirac-xref | proved | 654 (900; whole) | supersedes the draft of texts_learner_schuller.json (320) | 2, 5, 20 |
| EQN-031 | steps/dirac · dirac-xref | proved | 810 (900; folded) | supersedes the draft of texts_learner_explore.json (486) | 2, 3 |
| EQN-008 | steps/dirac · summary | proved | 631 (900; whole) | supersedes the draft of texts_learner.json (139) | 8, 40 |
| INP-021 | steps/dirac · needs | input (the action) | 747 (900; folded) | first learner words | — |
| INP-022 | steps/dirac · needs | input (grade of a field) | 465 (900; whole) | first learner words | 8 |
| INP-023 | steps/dirac · needs | input (time direction) | 654 (900; whole) | first learner words | — |
| INP-024 | steps/dirac · needs | input (complex structure) | 503 (900; whole) | first learner words | 3, 4, 6 |
| INP-025 | steps/dirac · needs | input (sign convention) | 410 (900; whole) | first learner words | — |
| INP-026 | steps/dirac · needs | input (chart and ∇) | 420 (900; whole) | first learner words | — |
| INP-027 | steps/coupling · needs | input (the action) | 890 (900; folded) | first learner words | — |
| INP-028 | steps/coupling · needs | input (imported data) | 443 (900; whole) | first learner words | — |
| INP-029 | steps/coupling · needs | input (grade of a field) | 460 (900; whole) | first learner words | — |
| INP-030 | steps/coupling · needs | input (time direction) | 736 (900; folded) | first learner words | — |
| INP-031 | steps/coupling · needs | input (complex structure) | 630 (900; whole) | first learner words | 3, 4, 5, 6 |
| INP-032 | steps/coupling · needs | input (chart and ∇) | 385 (900; whole) | first learner words | — |

**The status words kept.** MIR-008 (ours): "this is our reading, a picture we try and not a result" (R8's ours). Every input row (status `input`, badge "needs an input: …") says "is an input" in its first sentence, and INP-018 ends "a choice of convention, not a result" (the brief: "needs an input" or "a choice" where the badge says so); INP-021 keeps "checked" (its text: "Checked: the incidences, the determinant and the covariance"). CAND-054 keeps "checked", "exactly" and "for every number of switches" (R8's "for every n"); MIR-009 "checked exactly"; EQN-031 and LNS-117 "exact"/"exactly". MIR-006 is told as "a standard remark" (its status), EQN-004 as what the page "does not show" and "does not claim" (meta; its text has no status word). Rows told on other pages keep their spans there untouched: ATL-008 (`cells.cards.even-spacetime`), MIR-007 and MIR-008 (`steps-rigid.rg-square.two-mirrors`), EQN-008 (`shifted.sv-1.labels`), LNS-117 (`steps-schuller.sc-hyper.symbol`, T9a) and LNS-017c (`steps-schuller.sc-fibre.mass`, T9b); their full texts here agree with those spans in substance (the same numbers, the same plain names).

**The rows refused twice and left out: none.** Every text passed the checker's 24 rules at its first run in the page file; the drafts were checked beforehand in a scratch harness (the checker's own `check`, `checkChains` and `deriveFields` on every learner file of the copy with the drafts in place), where one R12 failure was caught and mended before writing (INP-025's "the Conventions page": "Conventions" is no name of its row; now "the page of conventions").

## 3. The voice, and the rules that bit

The words are those of the pages' human lines and spans: a generator **a switch** (plus, minus or zero switch), a vector **an arrow** (the coupling page's word) or **a direction**, a blade **a piece**, the scalar **the plain number**, the demicube **the half cube**, a rotation **a turn**, a boost **a boost** or **a change of speed**, the Dirac equation **the electron's rule**, ψ **the field** or **the electron's field**, γ₀ **the time direction**, J = γ₂γ₁ **the quarter turn**, reversion **the reverse**, Clifford conjugation **the conjugate** (named once in full where the row names it), the matrices **grids**, the bit rule **the bit rule** (the glossary's term), Cl(p,q) **the cell** with its name kept. A check id (bd·tor·7, scw·P1, …) is "a stored check" (R4 bans the middle dot); a script is never named (R13); formulas are read out in words (the mirror "minus the direction times the thing reflected times the inverse of the direction", the action of the Dirac step "the plain-number part of the derivative of the field times the volume piece times the third space switch times the reverse of the field", 2^(n−1) "2 to the number of switches less one", (p²)⁴ "the fourth power of the momentum squared"); degrees are written out (MIR-010); −1 and −3 stay as signed digits. "Atlas" is written "the atlas" in a sentence (R12 reads a capital as a name; LNS-003's research text has it lowercase); the word "new" is used nowhere; no date, no history word.

- **R12, names**: EQN-007 cannot say Lorentz or Maxwell ("the equations of light", "the turning algebras"); CAND-054 cannot say Dirac ("the current of an even field"); INP-021, INP-023 and INP-027 cannot say Dirac or Maxwell ("the electron's rule", "the one for light"); INP-025 cannot say "Conventions" ("the page of conventions"); row ids are never written (R12 reads them as names), so a linked statement is described ("the check beside this input", "the theorem about the symbol").
- **R7, no new number**: INP-022 drops "6 planes" ("the planes"); INP-029 says "with few directions … with more directions" where CPL-002's 4 and 5 are not its own; EQN-007 does not count 16 corners or 3 + 3 + 6 lines (not in its text).
- **R6/R8**: every number of every row is in digits ("2 by 2", "8 by 8", "2 to 8 directions", "940 elements in all"); CAND-054's "for every n" as "for every number of switches".
- **The words screen** (40-character windows at every offset of every text against `content/*.json` — notes, lenses, lens readings, pages, steps, figures, glossary, story frames, tutorials, the stored tables, the chain titles, and `src/`, `engines/`, `public/`; the Logbook's tables as warnings; the research texts and the other learner records as a sanity screen): before writing, 14 windows that copied a research sentence were rephrased — the row's own in ATL-008 (twice), CAND-054, MIR-004, MIR-008, MIR-009, MIR-010, INP-018, INP-024, EQN-030 (twice), EQN-031 and LNS-003 (MIR-009, INP-018 and INP-024 are quoted by the tutorials pages and the inputs table too), and in MIR-008 the phrase "is our reading: an idea we try, not a result" that the research texts of CPL-010, MAT-008 and YM-008 share — and LNS-017c's "the momentum along the zero switch changes" (a check statement of `checks.json`). After the rewrite no window of any text meets a string drawn outside statements; the remaining windows are shared with learner records only (translator drafts that retire, and the spans of CPL-012, MIR-007), which are statements. `tests/coverage.test.mjs` passes with no warning.

## 4. For the lead and the release owner of 3.0.0

- **LNS-003** (dirac · top-notes 1) is also a side note of `steps/schuller` · sc-first, and `SPINE_wave6_schuller.md` §9 lists it among T9a's 40 full texts (the twelve headlines of sc-first). A row has one full text (D68, R3: two storyteller texts of one key are a duplicate at the merge), and 2.18.0 ships first, so T9a's text stands and none is written here. A spare text that passes every rule is kept outside the repository, in `$SP/v4_agents/t10b/work/spare_LNS-003.json` (856 characters; 8 kept; theorem T16 named as its row names it): if T9a's text is missing at the close, it can be appended to `steps-dirac.json` as it is.
- **The retire of 3.0.0** moves the 18 translator full drafts these texts supersede (§2): EQN-004, EQN-007, ATL-008, MIR-004, MIR-006, MIR-007, MIR-008, INP-018, INP-020, CAND-054, EQN-014, MIR-009, MIR-010, EQN-030, LNS-017c, LNS-117, EQN-031, EQN-008. The **short** drafts of ATL-008 and EQN-030 stay (nothing replaces a short text, D66): EQN-030's short draft is what the top note of `steps/dirac` shows at learner level (`LeafNotes.registerOf`), its storyteller full text the full register's; the top notes MIR-009, MIR-010 and LNS-017c have no short text, so their storyteller full texts are the notes the page top shows at learner level, and they are written to read there ("the mirrors in the picture", "the small panel of the picture").
- **The inputs are first learner words** (13 rows): the input sections of `steps/mirrors` (INP-019), `steps/dirac` (all six) and `steps/coupling` (all six) are drawn at learner level for the first time at 3.0.0; each text says what the input is, where it enters and that the bit rule does not supply it, with the stored checks of its research text named as "a stored check", never by id.
- **Nothing else changed by hand**: no span, no row, no table, no chain file, no tool, no test; `content/texts_learner*.json` untouched, and `content/texts.json` only as `npm run content` rewrites it (D68). The files to copy back are the four learner files of §1 and this record, nothing else. The shared repository moved on after this copy was taken (04:03): `tools/build_content.mjs` (NEW_SINCE v2.18), `tools/merge_learner_texts.mjs` (the retire of a superseded draft under D68) and `tests/logbook.test.mjs` are the release owner's newer versions there; the checks above ran on the copy's tools, and the hand-back runs them again in the shared repository.

## 5. The commands, and their last lines (in the copy `$SP/v4_agents/t10b/one-rule`)

| command | last line |
|---|---|
| `node tools/check_learner_texts.mjs` (after each file) | `PASS: all 24 rules hold for every record` (1585, 1597, 1608 and 1614 records) |
| `flock … npm run content` | `errors 0, warnings 0; see docs/COVERAGE.md` (the only warnings on the way: wave 6's leads LNB-711 …, LNC-711 …, LNS-711 … "no learner text yet", not this sweep's) |
| `flock … node tools/merge_chains.mjs --check` | `merge_chains --check: 186 chains on 26 page(s), 117 storied (1 reviewed), 481 spans; round-14 rows: 83 story rows, 13 statement rows` |
| `flock … node tests/coverage.test.mjs` | `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; connectives within budget; …` (7 m 23 s; no warning) |
| `flock … node tests/story.test.mjs` | `story: 6 of 6 test files pass` |
| `node tools/check_notes.mjs` | `check_notes: 11 of 11 rules pass` |

No build and no browser, as the brief says; the release owner builds and looks at the four pages.
