<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# The story spine of wave 3 (round 16, composer C3)

The chains of the pages of wave 3 (`docs/round16/PLAN.md` §2): `steps/spin` (step 5), `steps/coupling` (step 6: the nineteen rows of eq-coupling outside the pilot, cp-checks, summary), `steps/ym` (step 7), `steps/matter` (step 8), and the five Furey tabs `matter/dictionary`, `matter/papers` (its sections other than `read`, told since 2.15.0), `matter/model`, `matter/generations`, `matter/help`, composed as `docs/round15/SPINE_wave2.md` composed wave 2. It is the map the storytellers write from (T5a: spin, coupling, ym, the matter step; T5b: the five tabs and the leftovers FUR-041, FUR-042, GEN-033, GEN-034) and what the release owner records for 2.17.0, which ships after wave 5 (PLAN §7: waves 3–5 in one release, every new row `since: "v2.17"`). Every chain is made of rows of the tables; every relation is a `depends` edge, `continues` (a split line and its first line) or `order` (adjacent only). Nothing here is a claim of physics or mathematics.

**How to read a chain** (as SPINE.md and SPINE_wave2.md): `A —derives→ B`: B rests on A. `—derives·X→ B`: B rests on X, an earlier position than the previous one (a branch). `—order→`: no edge, the rows only sit side by side (the storyteller may not open with a derivation word there, C4; it may open with "then", D65). `(A)`: a mention, told in another chain of the page. `A/Ab`: a position with its twin. After each chain: its shape, its weakest link (the weakest computed status of its rows: open > not yet proved here > our reading > needs an input > proved), its counts, and its titles, physics · mathematics · learner.

**The files.** `content/chains/{steps-spin,steps-coupling,steps-ym,steps-matter,matter-model}/chains.json` (14 chain records, interface 40: links, shape, joins and `extracted` computed by `tools/story/extract_chains.mjs` from the positions, `story: "none"`, `lead: null`); the eight section leads in the same folders' `rows.json` (D60's record, `since: "v2.17"`, `source: "round16:C3"`, one placement of role `lead` at order 0, no `restates`) with their research texts in `texts.json`. `content/chains/pilot/chains.json` is untouched: the pilot's five eq-coupling chains keep orders 1–5 and the three of this wave take 6–8. `matter/dictionary`, `matter/papers`, `matter/generations` and `matter/help` stay lists and have no file. No row moved: no placement, order or home changed; the sections' `chains` fields are the merge's. `node tools/story/extract_chains.mjs --diff content/chains/<key>/chains.json` reproduces every `extracted` (14 of 14).

**Tools touched** (the lead's go-ahead, 18 Oct; one line each, for the release owner of 2.17.0 to carry; the composers of waves 4 and 5 use the same `v2.17` and `round16:C<k>`):

1. `tools/merge_chains.mjs` — `SINCES` gains `'v2.17'` (V9 refused a story row since v2.17).
2. `tests/story/migration.test.mjs` — part C accepts `v2.17` for a round-14 story row (wave 3), beside v2.15 and v2.16.
3. `tests/logbook.test.mjs` — the drafts' source pattern accepts `^round16:C\d+$` (the composer of wave 3), and its message names round 16; line 84 (exactly five story rows since v2.16) is unchanged: the leads of wave 3 are since v2.17.
4. `tests/chains.test.mjs` — part D's "pipeline twice on a copy" drops `content/chains/matter-model` from the copy beside the pilot: the fixture composes `matter-model.axes.fixture-axes` (FUR-003/b → FUR-004/b, order 1) on the section this wave composes, and the copy's merge refused the pair (V8, V2). Every other part merges the fixture in place of the overlay.

`NEW_SINCE` (`tools/build_content.mjs`) is the release owner's (v2.17 at 2.17.0): a story row is never "new" either way.

## 1. The counts

| page · section | rows | mechanical: chains · in chains (+ attached) · side notes | composed: chains · told · mentions · side notes | section lead |
|---|---:|---|---|---|
| `steps/spin` · sp-reflect | 2 | 1 · 2 · 0 | 1 · 2 · 0 · 0 | SPN-711 (new) |
| `steps/spin` · eq-spin | 6 (+ 30 matrix lines apart) | 1 · 2 · 4 | 0 · 0 · 0 · 6 (a list) | — (the caption SPN-557 stays) |
| `steps/spin` · summary | 2 | 0 · 0 · 2 | 0 · 0 · 0 · 2 (a list) | — |
| `steps/spin` · sp-weave, sp-labels, sp-unit, sp-spaces, sp-pointor, sp-states, sp-conv, sp-num | 0 (v15 narration only) | — | — | SPN-533, SPN-568, SPN-569, SPN-550 (v15, kept: sp-unit, sp-spaces, sp-pointor, sp-states) |
| `steps/coupling` · eq-coupling (the 19 rows outside the pilot) | 19 | 3 · 11 (+ 1) · 7 | 3 · 12 · 0 · 7 | CPL-711 (new; the section had none) |
| `steps/coupling` · summary | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| `steps/coupling` · cp-checks | 0 (the figure coupling-ladder) | — | — | — |
| `steps/ym` · eq-ym | 11 | 3 · 10 · 1 | 3 · 10 · 0 · 1 | YM-711 (new) |
| `steps/ym` · ym-checks | 4 | 1 · 4 · 0 | 1 · 4 · 1 · 0 | YM-712 (new) |
| `steps/ym` · summary | 5 | 1 · 2 · 3 | 1 · 2 · 0 · 3 | YM-713 (new) |
| `steps/matter` · eq-matter | 9 | 3 · 7 · 2 | 3 · 7 · 0 · 2 | MAT-711 (new) |
| `steps/matter` · summary | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 (a list) | — |
| `steps/matter` · mt-checks | 0 (the figure matter-ladder) | — | — | — |
| `matter/dictionary` · fy-stages, fy-dict | 0 (v15 narration only) | — | — | — |
| `matter/papers` · timeline | 2 | 0 · 0 · 2 | 0 · 0 · 0 · 2 (a list) | — |
| `matter/papers` · checkpoints, fit | 0 (v15 narration only) | — | — | — |
| `matter/model` · blocks | 2 (FUR-001 and its twin) | 0 · 0 · 1 | 0 · 0 · 0 · 1 | — |
| `matter/model` · edges | 6 (5 positions, a twin) | 1 · 3 (+ 1, with its twin) · 1 | 1 · 5 (+ a twin) · 0 · 0 | FUR-718 (new) |
| `matter/model` · axes | 36 (34 positions, two twins) | 6 · 36 · 0 | 1 · 8 (+ 2 twins) · 0 · 26 | FUR-719 (new) |
| `matter/model` · open | 2 (FUR-005 and its twin) | 0 · 0 · 1 | 0 · 0 · 0 · 1 (the open part) | — |
| `matter/generations` · count | 1 | 0 · 0 · 1 | 0 · 0 · 0 · 1 | — |
| `matter/help` · questions | 4 | 0 · 0 · 4 | 0 · 0 · 0 · 4 (a list) | — |
| **wave 3** | **113** | **20 · 77 (+ 2) · 31** | **14 · 50 (+ 3 twins) · 1 · 58 (+ 2 twins)** | **8 new** |

113 = 50 told positions + 3 told twins + 58 side notes + 2 twins beside them (a row placed on two pages counts on each, as in SPINE.md §6). Mechanical: `node tools/story/extract_chains.mjs --page <route>` (eq-coupling with `--groups CPL,CAND`, its ATY and FUR rows being the pilot's), 20 chains as `--counts` gives for wave 3 (unchanged by the composition: 31 sections, 113 rows, 20 [17] chains, 77 (+ 2) [70 (+ 4)] rows in chains, 31 [36] side notes, one section of three rows or more without a chain, 30 matrix lines apart).

Per page: `steps/spin` 1 chain, 2 told, 0 mentions, 8 side notes, 1 story row; `steps/coupling` (this wave's part) 3 chains, 12 told, 0 mentions, 8 side notes, 1 story row; `steps/ym` 5 chains, 16 told, 1 mention, 4 side notes, 3 story rows; `steps/matter` 3 chains, 7 told, 0 mentions, 3 side notes, 1 story row; `matter/dictionary` nothing to tell; `matter/papers` 2 side notes; `matter/model` 2 chains, 13 told (+ 3 twins), 0 mentions, 28 side notes (+ 2 twins), 2 story rows; `matter/generations` 1 side note; `matter/help` 4 side notes.

Spans to write: 54 (50 told positions, 3 twins, 1 mention) and the learner texts of the 8 leads. The **lists** (nine sections): `steps/spin` · eq-spin (the verdict and the honest notes of the matrix, §2.3) and · summary, `steps/coupling` · summary, `steps/matter` · summary, `matter/papers` · timeline (the tags of the calibration), `matter/model` · blocks (one position) and · open (the open part), `matter/generations` · count (one row), `matter/help` · questions (the questions). Their rows are side notes, told in no order. Two sections of three rows or more are left without a chain: `steps/spin` · eq-spin (a list by its texts) and `matter/help` · questions (a list by its name); the mechanical draft left only the second.

## 2. The method and the choices

1. **Extract, read, compose.** Per section the mechanical draft (`--page/--section`, MAX = 8), then every research text, cell, status and edge of its rows; the chains are composed where the texts make one argument, every link recomputed from `depends` by `chainRecord`, every join by `joinsOf` on the whole page (the pilot's chains of `steps/coupling` included), every `extracted` by `diffChains` (what `--diff` lists). The script that built the records is the composer's scratch; the files are its output, and a second run writes the same bytes.
2. **`matter/model`: the decision.** The tab holds the 44 FUR rows (the five twins included) with CAND-049 and CAND-102, all of them told once on `matter` already but CAND-049, FUR-041 and FUR-042, side notes there. PLAN §2's default, a chain per section telling the rows in the tab's order, is kept where the tab sees the board block by block, and dropped where a chain would only be the mirror of one of `matter`'s:
   - **blocks** holds one position (FUR-001 with its twin): a side note, in its human words.
   - **edges** is not a mirror (its rows come from three chains of `matter` and a side note there): one chain tells where the charges carried by the edges come from on the labels, `matter-model.edges.charges`, a composition the overview does not have.
   - **axes** holds 34 positions. Its own subject, the sixteen axes, is one chain, `matter-model.axes.states`: the axes rows of `matter.fur-model.rebuilt` (CAND-102 → FUR-003 → FUR-004 → FUR-006), then her cell, her ladder operators and her eight states on pairs of axes (FUR-015, FUR-016, FUR-019, FUR-032 of `matter.fur-labels.cl6`), again a composition of the tab's own. The other 26 rows are the mirrors of `matter.fur-fibre.fibre-base` (FUR-007 … FUR-013, same rows, same order), `matter.fur-sixteen.weights` (FUR-020 … FUR-023, FUR-033 … FUR-035), `matter.fur-fields.mass` (FUR-024 … FUR-026, FUR-036, FUR-037) and `matter.fur-labels.roadmap` without FUR-031 (FUR-027 … FUR-030), with FUR-014 (told in `matter.fur-next.open`), FUR-041 and FUR-042 (side notes on `matter`). A chain there would tell the overview's story a second time, on a section whose subject is the axes, one tab away from where it is told; it adds no argument the tab's reader needs. Those 26 stay side notes, and 24 of them already carry the storyteller's full texts (`storyteller@2026-10-17`): in "More statements", a click away, each in its own words. FUR-041 and FUR-042 are the leftovers T5b writes.
   - **open** (FUR-005 with its twin, the open part) and **charges** (no statement row: the figure furey-charges) are not composed.
   - Mentions are not possible across pages (V2: a mention is told in another chain of the same page), so "recalling" the overview's rows on the tab would have to be side notes anyway.
3. **`steps/spin` · eq-spin is a list.** Its six statement rows are the matrix's verdict and honest notes: SPN-001 (every agreeing row reproduced by exact arithmetic, the hero), SPN-002 (whose equations), SPN-003 (the side-by-side reading is ours), SPN-004 (not checked), SPN-005 (not read), and a detail, CAND-017 (the Weyl halves). PLAN §3 keeps honest notes as lists, as wave 2 kept MIR-004, MIR-006 and PAG-019; the mechanical C1 (SPN-001 → SPN-003) is left. A first draft told SPN-001 → SPN-003 —order→ CAND-017 (CAND-017 names the chirality of SPN-003); besides the reading of the texts, it collided with the composition test's own fixture, which moves SPN-003 into the intro of `steps/spin` ("at a glance"; `tests/story/fixture/layout.json`), so that the row was drawn twice. If the lead wants the chain, the fixture's glance row (three references in `tests/story/fixture/{layout,rows}.json` and `tests/story/composition.test.mjs` line 388) must be another row first.
4. **`steps/coupling` · eq-coupling, the 19 rows outside the pilot** (the lead's answer of 18 Oct: composed this wave). Three chains, orders 6–8 after the pilot's five (`pilot/chains.json` untouched), seven side notes. Two `depends` edges of the section run against the order of its chains: ATY-004 and ATY-005 (`shift-waves`, order 1) rest on CPL-003 (`copies`, order 7), the cost of keeping the pilot's orders; putting the step's own chains first would renumber the pilot's (its owner's file). CAND-013, CAND-084, CPL-007c and CPL-007d carry full learner texts of T4b (storyteller drafts): CPL-007c and CPL-007d are told here (their spans are the new words, the full texts stay for the drawer), CAND-013 and CAND-084 stay side notes with those texts.
5. **A tally with a chain.** `steps/ym` · summary holds the tally EQN-010 and four computations placed beside it; CAND-124 (the BPST instanton) and ATY-034 (its conformal zero modes) make one argument and share an edge: one chain, `steps-ym.summary.instanton`, and the section's lead YM-713. The other three stay side notes. The summaries of `steps/spin`, `steps/coupling` and `steps/matter` stay lists (no edge between their rows, or one row). If the lead keeps every tally a list, dropping the chain and YM-713 leaves CAND-124 and ATY-034 side notes and the mention of §5.2 goes with them.
6. **A forward mention.** `steps-ym.ym-checks.skyrme` opens with (CAND-124), told in the summary section below it: the Skyrme fields are built from that instanton, and the mention lets the story start from it (as `shifted.sv-2.toy` mentions rows told in later steps).
7. **The section leads** are story rows of the page's group (SPN, CPL, YM, MAT, FUR), `since: "v2.17"`, ids `<GROUP>-711 …` (FUR-718, FUR-719: FUR-711 … 717 are taken), in the Atlas's research voice: what the section shows, no claim of its own; their texts hold no formula, no number in digits, no claim word and no history word, so T4/T5 clear them against their sections without restating a row, and none holds 40 characters of a research text or of a text printed outside a Statement (the coverage test caught "joint eigenspaces of the seven Fano-line blades" of the `furey` lens dictionary in a first FUR-719: rephrased). A section with a v15 lead keeps it (the four threads of `steps/spin`); a list section gets none. eq-coupling, which had no lead, gets CPL-711, which names the pilot's five chains and the three new ones in their order. Their learner texts are the storytellers'; `merge_chains --check` warns while they are missing (eight warnings).
8. **Twins.** FUR-002b, FUR-003b and FUR-004b ride with their positions on `matter/model` (spans in the mode of the twin, C11); FUR-001b and FUR-005b ride beside their side notes.
9. **Orders and backward edges.** A section's chains follow its rows' page order (eq-ym: views, algebras, gravity; eq-matter: action, current, coupling). On `matter/model` the sections keep v15's order (blocks, charges, edges, axes), so FUR-017 (edges) is told before FUR-016 (axes), on which it rests: the one edge of the tab that runs against the order of its chains; FUR-017's text names its states and number operator itself. The join FUR-017 → FUR-019 shows the other direction ("Continues from").
10. **A told row is drawn once in the body** (D52, `tests/story/composition.test.mjs`): green on the real content and the fixtures. The heroes CPL-001, YM-001 and MAT-001 are told in their chains (the top shows the headline); SPN-001, the hero of `steps/spin`, is a side note.

## 3. `steps/spin` — Step 5: pointors and the three kinds of i

Eleven sections hold placements; three hold statement rows. The 30 lines of the translation matrix (SPN-M01 … SPN-M30, D35) are numbers in the table of eq-spin and stay apart, with their translator drafts.

### 3.1 sp-reflect — one chain

- `steps-spin.sp-reflect.two-rotors` · line · proved · 2 told — "A turn of the plane and its two rotors" · "Rotors of Cl(2,0) as the double cover of SO(2)" · "A full turn that needs a second turn": SPN-006 —derives→ SPN-007 (the mechanical C1: the rotor is minus one after one full turn and the loop closes only after two; then the two halves of a wave, one turned, whose sum fades after one turn and comes back after two).
- lead **SPN-711**: "A turn of the plane followed on its rotors: after one full turn the rotor stands at minus one, and only a second full turn brings it back, so every turn of the plane has two rotors. The same double cover is then seen on a wave cut into two halves, one turned and one left alone: their sum fades after one full turn and comes back whole after two."

### 3.2 eq-spin — a list (§2.3)

Side notes, under the figure spin-matrix and its caption SPN-557: SPN-001 (the verdict: every row marked as agreeing reproduced by exact arithmetic, 22 exactly and 2 after a small adjustment; the page's hero), SPN-002 (the equations are the authors' and the lecturer's), SPN-003 (the side-by-side reading is ours, our reading), CAND-017 (the even part of the spacetime cell, complexified, as two halves told apart by chirality: the Weyl halves, the mass term coupling them), SPN-004 (not checked: 6 rows and the probability reading, open beyond Cl(3,0)), SPN-005 (what was not read, open). Departure from the draft: C1 (SPN-001 → SPN-003) left, both rows side notes.

### 3.3 summary — a list

EQN-017 (the tally of the step: 30 statements, 22 agree exactly, 2 after a small adjustment, 6 not checked) and CAND-076 (the splitting of bivectors in the cells of two to six generators): side notes, no edge between them.

### 3.4 The other eight sections

sp-weave, sp-labels, sp-unit, sp-spaces, sp-pointor, sp-states, sp-conv and sp-num hold v15 narration only (results, details, captions and learner lines of the six threads; the leads SPN-533, SPN-568, SPN-569, SPN-550 of sp-unit, sp-spaces, sp-pointor and sp-states stay); sp-hest holds the figure spin-hestenes and no row. Nothing to compose.

## 4. `steps/coupling` — Step 6: Maxwell meets Dirac

### 4.1 eq-coupling — three chains after the pilot's five

*Mechanical draft of the 19 rows outside the pilot* (`--groups CPL,CAND`): C1 · line `CPL-001 —derives→ CPL-010`; C2 · fork `CPL-012 —derives→ CPL-002 —derives→ CPL-007 —derives·CPL-002→ CPL-009 —continues·CPL-007→ CPL-007b —continues·CPL-007→ CPL-007c —continues·CPL-007→ CPL-007d` (hangs from CPL-003); C3 · line `CPL-003 —derives→ CPL-004`, CAND-069 attached (a labelling neighbour of CPL-003); side notes CAND-013, CPL-005, CPL-006, CAND-039, CPL-008, CAND-084, CAND-110.

*Composed:* 3 chains, 12 told, 7 side notes, the lead CPL-711 for the whole section. The pilot's `shift-waves`, `shift-energy`, `shift-tensor`, `off-modes`, `fibre-mass` (orders 1–5, storied since 2.15.0) are unchanged.

- `steps-coupling.eq-coupling.cube` (order 6) · line · weakest **our reading** (CPL-010) · 2 told — "Maxwell's cube reused for the coupling" · "The coupling as a factor on the edges of the cube" · "The same cube, with one more factor": CPL-001 —derives→ CPL-010 (C1; both rows are told on `light` too, in `light.views.cube`: a span in each chain).
- `steps-coupling.eq-coupling.copies` (order 7) · fork · proved · 3 told — "How many Dirac spinors one field carries" · "The even algebra as copies of a minimal left ideal" · "How many electron fields hide in one": CPL-003 —order→ CAND-069 —derives·CPL-003→ CPL-004. The count first (one Dirac spinor only for three and four generators, the ratios 2, 2, 4, 4 for five to eight), then why (CAND-069: the even algebra as copies of a minimal left ideal, the extra components the copies split off by right multiplications, 2, 2, 4, 4 Dirac fields), then the verdict (the known Dirac–Maxwell system in Hestenes' form with the standard spinor dimensions). CAND-069 is threaded by its text, which states CPL-003's ratios as copies (an `order` link); the draft attached it at the end.
- `steps-coupling.eq-coupling.grade-five` (order 8) · fork · weakest **open** (CPL-007, CPL-007c) · 7 told — "A grade-five current with no slot in the field equation" · "The grades of the current beyond four generators" · "A part of the flow the field has no room for": CPL-012 —derives→ CPL-002 —derives→ CPL-009 —derives·CPL-002→ CPL-007 —continues→ CPL-007b —continues·CPL-007→ CPL-007d —continues·CPL-007→ CPL-007c. The current's grades (a vector up to four generators, a grade-five part from five), the field equation with no slot for it, the coupling that sees only the vector current (no projection chosen by hand), then the card CPL-007 with its lines: the open question, the second Dirac field at five generators, the grade-five part on one copy for six to eight, and the open questions last. Joins: CPL-003 → CPL-007, CPL-007b, CPL-007d, CPL-007c (derives, from `copies`).
- side notes: CAND-013 (closed Coulomb bound states with the Sommerfeld–Dirac energies), CPL-005 (the size of e free, the sign of the source fixed by the action), CPL-006 (one and two generators: no complex structure, no charged field; a dead end, open), CAND-039 (the stress of the field and the Lorentz force), CPL-008 (what this step does not draw, and what a curved frame does to its Dirac operator), CAND-084 (the squares of the Dirac operator in a curved frame, with torsion), CAND-110 (the characteristic variety of the Dirac-type symbol, the null cone). CPL-008 and CAND-084 share the square of the curved Dirac operator; CPL-008 is chiefly the step's note of what it leaves to steps 7 to 10, so both stay side notes.
- departures (`--diff`): CPL-009 moved (before CPL-007, on which it does not rest, after CPL-002, on which it does); CPL-007d moved (before CPL-007c: the computation the open question follows); CAND-069 moved (second); the titles.
- lead **CPL-711**: "Each view of the coupling teaches the others something. Atiyah's shift is followed on the plane waves, through proper time, energy and a beat, into the flow of energy and momentum and off the quantized modes, and a momentum along the fibre turns into a mass. Then the step's own views: the cube of Maxwell's equation reused for the coupling, the count of spinor components and the copies of the Dirac field it hides, and the part of the current for which the field equation has no room."

### 4.2 summary — a list; cp-checks

EQN-009 (the tally of the step): a side note. cp-checks holds the figure coupling-ladder and no statement row.

## 5. `steps/ym` — Step 7: Yang–Mills

### 5.1 eq-ym — three chains

- `steps-ym.eq-ym.views` · fork · weakest **our reading** (YM-008) · 5 told — "Graph, incidences and demicube: the gauge algebra" · "The structure constants of so(m) from the commutator graph" · "Three earlier pictures of the many-charge force": YM-001 —derives→ YM-002 —derives·YM-001→ YM-003 —derives→ YM-008 —derives·YM-001→ YM-004. Step 2's graph as the structure of the gauge algebra (the hero), Maxwell's incidences as the case of two generators with the commutator terms new, the demicube's edges as the terms of the commutator, the drawing on the demicube (our reading, right after the row it draws), and the textbook system rebuilt last.
- `steps-ym.eq-ym.algebras` · line · weakest **open** (YM-006b) · 2 told — "Other gauge algebras, each from one datum" · "u(n), su(3) and the Standard Model algebra as centralisers" · "Other kinds of force, each from one more choice": YM-006 —continues→ YM-006b (a split row and its line: the algebras that one datum gives, and which one a model uses, open).
- `steps-ym.eq-ym.gravity` · fork · weakest **open** (YM-007c) · 3 told — "The gauge field as a source of gravity" · "Reissner–Nordström, the Wu–Yang stress and the meron" · "When the force field bends space and time": YM-007 —continues→ YM-007b —continues·YM-007→ YM-007c (the abelian and the Wu–Yang sources on one frame, the meron on the Einstein static universe, a source with no cosmological term not built, open).
- side note: YM-005 (the coupling g stays free; the action and two solutions computed; meta).
- departures: YM-008 moved (before YM-004); the titles.
- lead **YM-711**: "Each earlier step teaches the equations of many charges something: the commutator graph gives the structure of the gauge algebra, Maxwell's incidences are the case of two generators, and the edges of the demicube count the terms of the commutator; the system is the textbook one, and its drawing on the demicube is a reading. Then the other algebras that one more datum brings, and the field as a source of gravity."

### 5.2 ym-checks — one chain, one mention

- `steps-ym.ym-checks.skyrme` · fork · weakest **our reading** (ATY-015) · 4 told, 1 mention — "Skyrme fields from an instanton, on lines and circles" · "Holonomies of the BPST instanton along lines and circles" · "A knot of the field read along lines and circles": (CAND-124) —derives→ ATY-012 —derives→ ATY-013 —derives→ ATY-014 —derives·ATY-013→ ATY-015. The instanton (a mention: told in §5.3), the Skyrme field along lines, the same on hyperbolic space along circles, the paper's numbers for one Skyrmion by a standard route (the improvement with the pion mass holds for the instanton family only up to a mass between 1 and 2), and what is read in Atiyah and Sutcliffe and not run (our reading).
- departures: the mention CAND-124 (told in `steps-ym.summary.instanton`); the title.
- lead **YM-712**: "The figure lays out the system for two to eight generators, with its identities checked on random polynomial fields. Beside it, one instanton read along lines, after Atiyah and Manton, and along circles, after Atiyah and Sutcliffe: a Skyrme field in flat space and another in hyperbolic space, the energies of one Skyrmion computed again by a standard numerical route, and what is read in the second paper and not run."

### 5.3 summary — a tally with a chain (§2.5)

- `steps-ym.summary.instanton` · line · proved · 2 told — "The instanton and the deformations that change it" · "BPST self-duality and the conformal zero modes" · "A knot of the field and the ways it can move": CAND-124 —derives→ ATY-034 (the BPST connection self-dual with instanton number 1, the Wu–Yang monopole; then the fifteen conformal fields split 10 + 5 on it: five zero modes, ten pure gauge).
- side notes: EQN-010 (the tally of the step), CAND-047 (Wilson's plaquette action on the cube), CAND-027 (the curvature of a Cartan connection; Yang–Mills as its case without a quotient part).
- lead **YM-713**: "The tally of the step, and the computations set beside it: the instanton and the deformations that change it, the lattice action on the plaquettes of the cube, and the curvature of a Cartan connection, of which the field of many charges is one case."

## 6. `steps/matter` — Step 8: matter charged under so(m)

### 6.1 eq-matter — three chains, the mechanical draft kept

- `steps-matter.eq-matter.action` · line · weakest **our reading** (MAT-008) · 2 told — "The gauge algebra acting on the internal blades" · "so(m) on Cl(0,m) along the internal demicube" · "How the force reaches the inner switches": MAT-001 —derives→ MAT-008 (step 7 to matter: the gauge algebra acts on the internal blades along the demicube's edges, the hero; the drawing, our reading).
- `steps-matter.eq-matter.current` · fork · proved · 3 told — "A conserved source for every generator" · "Covariant conservation of the currents of so(m)" · "Each kind of charge keeps its balance": MAT-003 —derives→ MAT-002 —derives·MAT-003→ MAT-004 (the source conserved covariantly whenever the matter equation holds; step 6's current as its case of one generator; the standard Dirac field in a representation, rebuilt).
- `steps-matter.eq-matter.coupling` · line · weakest **open** (MAT-005b) · 2 told — "One action, one coupling for source and force" · "The source coupling tied to the gauge coupling" · "One number sets both sides of the force": MAT-005 —continues→ MAT-005b (one action fixes the source's coupling by the potential's; the size of the coupling free, open).
- side notes: MAT-006 (which representation the model uses; chiral coupling not treated, open), MAT-007 (solutions in general: gravity is drawn in steps 9–10; one solution with a source checked, Reissner–Nordström). The two views of the step (action, current) share no root and stay two chains.
- departures: the titles only.
- lead **MAT-711**: "Each earlier step teaches charged matter something: the gauge algebra acts on the internal blades along the edges of the internal demicube, and drawing it so is our reading; the source of the gauge field is conserved whenever the matter equation is satisfied, the current of the coupling step is its case of one charge, and the matter field is the textbook one. Then one action ties the coupling of the source to the coupling of the potential."

### 6.2 summary — a list; mt-checks

EQN-011 (the tally of the step): a side note. mt-checks holds the figure matter-ladder and no statement row.

## 7. `matter/dictionary` — nothing to tell

Its two sections with placements, fy-stages and fy-dict, hold v15 narration only (learner lines and the captions of dictionary-boards); fy-cartan and fy-fano hold none; INP-087 and INP-088 sit in the inputs fold. No chain, no side note, no lead.

## 8. `matter/papers` — the sections other than `read`

timeline holds the two tags of the calibration placed on this tab, PAG-013 (her six papers, the tab's hero) and PAG-014 (her papers rebuilt from the start, the 30 checks): a list, two side notes in their human words (no edge between them). checkpoints and fit hold v15 narration only; cascade, spectra and triality hold figures (ladders, furey-trialities) and no row. `read` keeps its lead FUR-717 and its six cards (told since 2.15.0, not a chain: the papers follow one another in time).

## 9. `matter/model` — Her 2026 model, block by block (the decision: §2.2)

### 9.1 blocks — a side note

FUR-001 with its twin FUR-001b (the projectors of her board, its blocks and ranks, the complex structure fusing the two blocks of rank one): one position, a side note in its human words (the twin has a translator draft). It is told on `matter` in `matter.fur-model.rebuilt`.

### 9.2 edges — one chain, a composition of the tab

*Mechanical draft:* C1 · line `FUR-017 —derives→ FUR-018 —derives→ FUR-031`, FUR-002/FUR-002b attached (they share FUR-001); side note CAND-049.

- `matter-model.edges.charges` · line · proved · 5 told (+ the twin FUR-002b) — "Where the charges on the edges come from" · "Number operator, colour, hypercharge and the doublet" · "Where the charges on the links come from": FUR-002/FUR-002b —order→ FUR-017 —derives→ FUR-018 —derives→ FUR-031 —order→ CAND-049. The ten edges and the representations of colour, isospin and hypercharge they carry; then where those charges come from on the labels: the charges of her eight states from a number operator, the colour su(3) and the u(1) beside her ladder operators, hypercharge and the weak su(2) on five bits; then the doublet whose vacuum leaves Q = T₃ + Y unbroken, the masses of W and Z and the Yukawa couplings (CAND-049, whose script `jordan_sm.py` is the one FUR-031's text names: an `order` link). FUR-017 rests on FUR-016, told in §9.3 after it (§2.9).
- departures: FUR-002 moved (first: the edges before their charges); CAND-049 added from the side notes; the titles.
- lead **FUR-718**: "The ten edges of the board carry the colour, the isospin and the hypercharge of the Standard Model. Then, where those charges come from on the labels: the charges of her eight states from a number operator, the colour turns beside her ladder operators, hypercharge and the weak turns on five bits, and the doublet whose vacuum leaves the electric charge unbroken."

On `matter`, FUR-002 is told in `matter.fur-model.rebuilt`, FUR-017 and FUR-018 in `matter.fur-labels.cl6`, FUR-031 in `matter.fur-labels.roadmap` (and on `steps/baez` in `steps-baez.bz-generation.fock`), and CAND-049 is a side note: a span in each chain.

### 9.3 axes — one chain for the axes, the mirrors as side notes

*Mechanical draft:* C1 · fork `FUR-007 —order→ FUR-008 —derives→ FUR-009 —derives→ FUR-010 —derives→ FUR-011 —derives→ FUR-012 —derives·FUR-011→ FUR-014 —order→ FUR-022 —derives→ FUR-033`; C2 · line `FUR-021 —derives→ FUR-028 —derives→ FUR-029 —derives→ FUR-030 —derives→ FUR-042`; C3 · fork `CAND-102 —derives→ FUR-003/FUR-003b —derives→ FUR-004/FUR-004b —derives·FUR-003→ FUR-006 —derives→ FUR-019 —derives→ FUR-032`; C4 · fork `FUR-013 —derives→ FUR-024 —derives→ FUR-025 —derives·FUR-024→ FUR-026 —derives·FUR-025→ FUR-036 —derives·FUR-024→ FUR-037`; C5 · line `FUR-020 —derives→ FUR-023 —derives→ FUR-035 —derives→ FUR-041`; C6 · fork `FUR-015 —derives→ FUR-016 —derives·FUR-015→ FUR-027 —derives→ FUR-034`. The draft runs the overview's stories into one another (C1 fibre and base into the 16, C6 her cell into the roadmap).

- `matter-model.axes.states` · fork · proved · 8 told (+ the twins FUR-003b, FUR-004b) — "The Fano-line blades, and her states on the axes" · "The Hamming code, the axes and the image of ℂ ⊗ Cl(0,6)" · "Her eight states laid on pairs of lanes": CAND-102 —derives→ FUR-003/FUR-003b —derives→ FUR-004/FUR-004b —derives·FUR-003→ FUR-006 —order→ FUR-015 —derives→ FUR-016 —derives→ FUR-019 —derives→ FUR-032. The seven Fano-line blades and their code, the sixteen axes as their joint eigenspaces (the partition an input, not forced by the Witt pairing), the second complex structure that no torus generator reaches, the group of 32 they generate; then her cell ℂ ⊗ Cl(0,6) on the labels (an `order` link: FUR-019's text embeds that cell in the Cl(0,8) of FUR-003 and FUR-006), her ladder operators and vacuum, her eight states on pairs of axes, and the four other line blades that split each pair into the sixteen axis idempotents. Join: FUR-017 → FUR-019 (derives, from `edges`).
- departures: FUR-015 and FUR-016 added from C6; the titles (C3 is otherwise kept).
- side notes (26), each with the chain of `matter` that tells it: FUR-007 … FUR-013 (`matter.fur-fibre.fibre-base`, the same rows in the same order), FUR-014 (`matter.fur-next.open`; what left and right change, our reading), FUR-020 … FUR-023, FUR-033 … FUR-035 (`matter.fur-sixteen.weights`), FUR-041 (a side note on `matter` too: the pairings in the split and the compact cells of ten generators), FUR-024 … FUR-026, FUR-036, FUR-037 (`matter.fur-fields.mass`), FUR-027 … FUR-030 (`matter.fur-labels.roadmap`, whose FUR-031 is told in §9.2), FUR-042 (a side note on `matter` too: Furey and Hughes's three copies on the roadmap's labels).
- lead **FUR-719**: "The sixteen axes of the board, each a common eigenspace of the seven commuting line blades of the Fano plane; the code and the group those blades form, the second complex structure that no torus generator reaches, and then her complex cell, her ladder operators and her eight states laid on pairs of axes, with the four other line blades splitting each pair. Beside them the rows of the overview's other stories keep their own words here: fibre and base, the sixteen in three cells, the fields whose fibre momentum is a mass, and the roadmap's modes as bits."

### 9.4 open, charges

open (the open part) holds FUR-005 with its twin FUR-005b (a map from irreps to cells, the origin of 210, odd primes and continuous parameters, whether the extra edges are physical: open): a side note in its human words, listed in the open fold; it is told on `matter` in `matter.fur-next.open`. charges holds the figure furey-charges and no statement row.

## 10. `matter/generations` — one side note

count holds PAG-015 (the board holds one complete Standard Model set, two with every cell doubled; three need at least 14 complex dimensions in blocks of this kind), a side note in its human words; composite holds v15 narration (the caption and a learner line of furey-composites); board, room and whole hold figures and no row.

## 11. `matter/help` — the questions, a list

questions (the open part) holds PAG-016 (the questions her model leaves: which edge is lepton and which Higgs, the doubling, chirality, the top quark, the ℤ₂ parallel) and FUR-038, FUR-039, FUR-040 (the three questions of round 14, at home on `matter` and told there in `matter.fur-next.open`): four side notes, all with learner texts (PAG-016 human, the three questions the storyteller's of 17 Oct). results and score hold no row.

## 12. For the storytellers (T5a, T5b) and the release owner (2.17.0, after wave 5)

- **Worksheets.** `node tools/check_learner_texts.mjs --explain <chain id>` for each of the 14 chains; the spans go in `content/chains/learner/<page key>.json` (`steps-spin`, `steps-ym`, `steps-matter`, and the existing `steps-coupling.json` beside the pilot's spans: T5a, 38 spans; `matter-model`: T5b, 16 spans), the leads' learner texts beside them (SPN-711, CPL-711, YM-711, YM-712, YM-713, MAT-711: T5a; FUR-718, FUR-719: T5b).
- **C10.** FUR-002 (`matter-model.edges.charges` · 1), FUR-003 and FUR-004 (`matter-model.axes.states` · 2 and 3) have human learner texts: their spans are those texts, verbatim, status human; their twins FUR-002b, FUR-003b, FUR-004b take spans of their own in mathematics mode (C11).
- **C7, the budgets** (0.8 × the research texts of the positions, twins and mentions included): the tight ones `steps-coupling.eq-coupling.cube` 254 characters for two spans, `steps-matter.eq-matter.action` 356, `steps-matter.eq-matter.current` 522, `steps-spin.sp-reflect.two-rotors` 531, `steps-matter.eq-matter.coupling` 552, `steps-ym.eq-ym.algebras` 575 (R9: 40 at least each); the longest `matter-model.axes.states` 8,897, `matter-model.edges.charges` 6,649, `steps-ym.ym-checks.skyrme` 5,160.
- **The mention.** (CAND-124) in `steps-ym.ym-checks.skyrme` · 1: one short sentence that recalls the instanton told in the summary below, 20 to 300 characters, no new number (C8).
- **Order links** (open freely, never with a derivation or contrast word; "then" allowed): `steps-coupling.eq-coupling.copies` · 2; `matter-model.edges.charges` · 2 and 5; `matter-model.axes.states` · 5.
- **Weak links** (C5's status words in the span): `steps-coupling.eq-coupling.cube` · 2 (our reading); `steps-coupling.eq-coupling.grade-five` · 4 and 7 (open); `steps-ym.eq-ym.views` · 4 (our reading); `steps-ym.eq-ym.algebras` · 2 (open); `steps-ym.eq-ym.gravity` · 3 (open); `steps-ym.ym-checks.skyrme` · 5 (our reading); `steps-matter.eq-matter.action` · 2 (our reading); `steps-matter.eq-matter.coupling` · 2 (open).
- **Rows told on two pages** have a span in each chain: CPL-001 and CPL-010 (`light`, `steps/coupling`); every row told on `matter/model` is told on `matter` too (and FUR-031 on `steps/baez`): the overview's spans may guide the tab's, the links being the tab's own.
- **Side notes' full texts due** (PLAN §1, the storyteller's voice; human texts stay). T5a, 21: SPN-001, SPN-002, SPN-003, CAND-017, SPN-004, SPN-005, EQN-017, CAND-076; CPL-005, CPL-006, CAND-039, CPL-008, CAND-110, EQN-009 (CAND-013 and CAND-084 carry T4b's texts); YM-005, EQN-010, CAND-047, CAND-027; MAT-006, MAT-007, EQN-011. T5b: FUR-001b and FUR-005b (twins beside side notes whose first lines are human) and the leftovers FUR-041, FUR-042 (side notes on `matter` and on the tab), GEN-033, GEN-034 (on `rule` and `cells`); the 24 other side notes of the tab's axes carry the storyteller's texts of 17 Oct, PAG-013 … PAG-016 are human, FUR-038 … FUR-040 carry the storyteller's.
- **For the release owner.** The four tools touched (above); NEW_SINCE; at the retire, the told heroes without a short learner text (CPL-001, YM-001, MAT-001) keep their full drafts (D66), and the told rows with storyteller full texts (CPL-007c, CPL-007d, the tab's FUR rows) keep them (the retire moves translator drafts only). Three choices the owner may revert, each named above: eq-spin a list (§2.3), the tally of `steps/ym` with a chain (§2.5), the mirrors of `matter/model` as side notes (§2.2); and the order of eq-coupling's chains (§2.4), a renumbering in `pilot/chains.json` and `steps-coupling/chains.json` if the step's own views should come first.

## 13. Validation

After `npm run content` (0 errors; 89 chains, 1,909 rows; a second run writes the same bytes):

- `node tools/merge_chains.mjs --check` — 89 chains on 14 pages, 75 storied (0 reviewed), 310 spans; round-14 rows: 53 story rows, 13 statement rows; eight warnings, one per new lead without a learner text yet.
- `node tools/story/extract_chains.mjs --counts` — unchanged by the composition (wave 3: 31 sections, 113 rows, 20 [17] chains, 77 (+ 2) [70 (+ 4)] rows in chains, 31 [36] side notes, 1 [1] section without a chain, 30 matrix lines apart); `--diff` reproduces the 14 `extracted`.
- `node tools/check_learner_texts.mjs` — PASS, all 24 rules (no wave-3 span yet).
- `node tests/chains.test.mjs` — PASS (8,986 checks; 17 pilot chains, 89 merged; 144 renders, 1,088 chains drawn: 544 lists, 1,600 connectives, 216 mentions, 512 stories, 32 fallbacks).
- `node tests/story/*.test.mjs` — PASS, 6 of 6 (ask, composition, furey with the tab lists and the home rule and 20 of 20 broken copies, landing, migration, shifted); `node tests/coverage.test.mjs` — PASS; `node tests/logbook.test.mjs` — fail 0.
- Not run here (the release owner's): `sh build.sh` and the suites on `dist/`, `sh tools/release.sh`.
