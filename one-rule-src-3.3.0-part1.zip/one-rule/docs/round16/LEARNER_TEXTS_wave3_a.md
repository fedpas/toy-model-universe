<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0 · Required Notice: Copyright (c) 2026 the Cascade Atlas authors · Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
# Learner texts of wave 3, part a: steps 5–8 (T5a, round 16, for release 2.17.0)

The storyteller T5a of wave 3 wrote under `docs/round16/PLAN.md` §1 and §4 (a page is storied when its chains are told and every side note has a storyteller full text; the matrix lines stay apart), `docs/round14/STORY_ROUND.md` §7 (the prompt and the budget) and §3.2 (C1–C11, with D65: "then" may open an `order` link; so, hence, therefore, thus, it follows open a `derives` link), on the chains of `docs/round16/SPINE_wave3.md` §3–§6 and §12 (`content/chains/{steps-spin,steps-coupling,steps-ym,steps-matter}/chains.json`), with `docs/round14/OWNER_ANSWERS.md` (A60, A63, A64), `docs/round14/B1_NOTES.md`, the voice of `docs/LEARNER_TEXTS_chains.md` and `docs/09_TRANSLATION_PROTOCOL.md` §2.2. T5b wrote the five Furey tabs at the same time; the composer of wave 4 composed its pages beside them; no file of theirs was touched here.

**All 12 chains of this wave on the four pages are storied (with the pilot's five of `eq-coupling`, the four pages' 17 chains are all storied); none went back to the checker after a write, none was rejected twice, none is left out** (D54's fallback applies to none). Every record has the shape of §2.2: `lang: "en"`, `level: "learner"`, `lens: null`, `status: "draft"`, `source: "storyteller@2026-10-18"`; `termsUsed` and `keptNumbers` are the checker's own (`deriveFields`), never typed. No told row of these chains has a human learner text (C10 kept no human words; CPL-012's learner text is *reviewed*, `lead:L7-10`, not human, so its span shortens those reviewed words). The 30 matrix lines of `steps/spin` (SPN-M01 … SPN-M30) have no record here (PLAN §1, D35).

## 1. What was written

| file (`content/chains/learner/`) | records | what |
|---|---:|---|
| `steps-spin.json` (new) | 11 | the 2 spans of `steps-spin.sp-reflect.two-rotors`; the learner text of the section lead SPN-711; the full texts of the 8 side notes SPN-001, SPN-002, SPN-003, CAND-017, SPN-004, SPN-005, EQN-017, CAND-076 |
| `steps-coupling.json` (wave 1's and wave 2's, appended) | 29 + 19 | the 12 spans of `cube`, `copies`, `grade-five` (CPL-007c and CPL-007d told: their spans are words of their own, T4b's full texts stay); the learner text of CPL-711; the full texts of the 6 side notes CPL-005, CPL-006, CAND-039, CPL-008, CAND-110, EQN-009 (CAND-013 and CAND-084 keep T4b's); the 29 records before them unchanged, byte for byte (`diff`: additions only) |
| `steps-ym.json` (new) | 24 | the 17 spans of `views`, `algebras`, `gravity`, `skyrme` (one mention) and `instanton`; the learner texts of YM-711, YM-712, YM-713; the full texts of the 4 side notes YM-005, EQN-010, CAND-047, CAND-027 |
| `steps-matter.json` (new) | 11 | the 7 spans of `action`, `current`, `coupling`; the learner text of MAT-711; the full texts of the 3 side notes MAT-006, MAT-007, EQN-011 |

In all: **38 spans** (37 told positions, 1 mention), **6 lead texts**, **21 full texts** of side notes (SPINE §12's list, every one). 18 of the 21 side notes had a translator draft of the same key; the coordinator's D68 (`tools/check_learner_texts.mjs` and `tools/merge_chains.mjs`, on disk 18 Oct 02:55) lets a storyteller full text stand beside a translator draft: it supersedes the draft at the merge (checked: `content/texts.json` holds the 21 storyteller texts after `npm run content`), and the draft retires at the release. CAND-017, YM-005 and CAND-027 had no learner text at all.

## 2. The chains, position by position

| chain · learner title | shape | positions and links | story / budget (C7) |
|---|---|---|---:|
| `steps-spin.sp-reflect.two-rotors` · "A full turn that needs a second turn" | line | SPN-006 —derives→ SPN-007 | 522 / 531 |
| `steps-coupling.eq-coupling.cube` · "The same cube, with one more factor" | line | CPL-001 —derives→ CPL-010 (our reading) | 253 / 254 |
| `steps-coupling.eq-coupling.copies` · "How many electron fields hide in one" | fork | CPL-003 —order→ CAND-069 —derives·CPL-003→ CPL-004 | 1115 / 1120 |
| `steps-coupling.eq-coupling.grade-five` · "A part of the flow the field has no room for" | fork | CPL-012 —derives→ CPL-002 —derives→ CPL-009 —derives·CPL-002→ CPL-007 (open) —continues→ CPL-007b —continues·CPL-007→ CPL-007d —continues·CPL-007→ CPL-007c (open) | 2622 / 2622 |
| `steps-ym.eq-ym.views` · "Three earlier pictures of the many-charge force" | fork | YM-001 —derives→ YM-002 —derives·YM-001→ YM-003 —derives→ YM-008 (our reading) —derives·YM-001→ YM-004 | 911 / 912 |
| `steps-ym.eq-ym.algebras` · "Other kinds of force, each from one more choice" | line | YM-006 —continues→ YM-006b (open) | 571 / 575 |
| `steps-ym.eq-ym.gravity` · "When the force field bends space and time" | fork | YM-007 —continues→ YM-007b —continues·YM-007→ YM-007c (open) | 1471 / 1472 |
| `steps-ym.ym-checks.skyrme` · "A knot of the field read along lines and circles" | fork | (CAND-124) —derives→ ATY-012 —derives→ ATY-013 —derives→ ATY-014 —derives·ATY-013→ ATY-015 (our reading) | 5159 / 5160 |
| `steps-ym.summary.instanton` · "A knot of the field and the ways it can move" | line | CAND-124 —derives→ ATY-034 | 1504 / 1522 |
| `steps-matter.eq-matter.action` · "How the force reaches the inner switches" | line | MAT-001 —derives→ MAT-008 (our reading) | 354 / 356 |
| `steps-matter.eq-matter.current` · "Each kind of charge keeps its balance" | fork | MAT-003 —derives→ MAT-002 —derives·MAT-003→ MAT-004 | 517 / 522 |
| `steps-matter.eq-matter.coupling` · "One number sets both sides of the force" | line | MAT-005 —continues→ MAT-005b (open) | 548 / 552 |

(The pilot's five chains of `eq-coupling`, orders 1–5, are unchanged: 29 records before mine.)

**The leads.** No chain of these pages has a chain lead (`lead: null`); the six section leads (role `lead`) have their learner texts: SPN-711 276 characters, CPL-711 295, YM-711 298, YM-712 298, YM-713 239, MAT-711 300; none holds a digit; each passes `testBlock` (T1–T5) against the rows of its section as narration, as its research text does (not a gate for a section lead; checked to be sure). R8 reads them as it reads every record: YM-711 keeps "textbook" and "our reading", MAT-711 "our reading" and "textbook", as their research texts carry them. None repeats 40 characters of a chain title (YM-712 and YM-713 first did, below).

**The openings (C4).** `derives`: "So" (most), "Hence" (CPL-009), "From the same graph" (YM-003), "From the same circles" (ATY-015); the branch links read back to the position they rest on ("So, from Dirac to Maxwell", CPL-002 after CPL-012; "So the system is the textbook Yang–Mills one", YM-004 back to YM-001; CPL-004 back to the count of CPL-003). `continues`: "More precisely" (CPL-007b), "Also" (CPL-007d, YM-007b), "And" (CPL-007c, YM-006b, YM-007c, MAT-005b). The one `order` link (CAND-069 in `copies`) opens "Then the same ratios as copies": a sequence word (D65), no derivation or contrast word. The mention (CAND-124 in `skyrme`) is one sentence of 94 characters, no number but its row's 1: "The instanton told in the summary below, self-dual with instanton number 1, starts this story."

**The status words (C5, R8).** Every weak link says its word in its span: CPL-010, YM-008, ATY-015, MAT-008 "our reading"; CPL-007, CPL-007c, YM-006b, YM-007c, MAT-005b "open". No proved row's span carries "open", "input", "a choice" or "our reading" unless its research text does (YM-001 keeps the "open triangles" of its own text; CPL-009 says "no projection chosen by hand", not "a choice"). The scope words kept: exact, checked, at points, recalled, floats (ATY-014, ATY-034 "in floats"; YM-007b "numerically"), textbook / standard (YM-004, YM-006 by "Standard Model", CPL-004, MAT-004), not checked.

## 3. The voice

The step pages' own human lines (SPN-501 … 508, CPL-501 … 506, YM-501 … 506, MAT-503 … 506) and the reviewed learner text of CPL-012: a generator is a **direction** ("from 5 directions on"), a gauge generator a **gauge direction**, a grade a **number of switches** ("a part with 5 switches"), the vector part **the arrow**, the scalar part **the plain part**, the pseudoscalar **the top piece**, J **the quarter turn** (wave 1's word), γ₀ **the time direction**, a minimal left ideal **a smallest left ideal**, the commutator **the order matters** ("planes whose order matters"), so(m) **the turns** (of the gauge directions), the coupling **the push** (CPL-504's word) and its size "how strong the push is", conservation **balances** (MAT-503's word), Yang–Mills at learner level **the force of many charges** (the page's learner title), the instanton **a knot of the field** (the composer's learner titles), the demicube **the demicube** in the tight chains and **the half cube** in the leads, the rotor **the rotor** (SPN-711's word). Names stay names: Cl(2,0), Cl(1,3), so(3), su(3), Spin(10), SO(5). Straight apostrophes, as in the earlier files.

## 4. What the budget cost (C7 with R6)

Every chain ends at 98–100 % of its budget; the first drafts measured cube 263 / 254, copies 1502 / 1120, grade-five 3452 / 2622, views 1025 / 912, algebras 609 / 575, gravity 1628 / 1472, skyrme 5511 / 5160, instanton 1709 / 1522, matter's coupling 607 / 552. Every number, scope and status word of every told row is in its span (R6, R8, A64: the precisions and sample counts stay, "3 times 10 to the minus 8", "1e-9", "1200 steps"); what was compressed is method detail and formulas, listed here so the owner can see it, and kept in the research texts and the drawers:

- `two-rotors`: the rotor's formula and the sandwich of the turn; "the loop of turns closes on the rotors only after going round twice" told as "followed from one … comes back only after two".
- `cube`: "the n cube edges" as "the cube edges at each corner"; CPL-010's "an idea we try" (said by the page's human line CPL-506) shortened to "not a result".
- `copies`: CAND-069's algebras M₂(ℂ), M₂(ℍ), M₂(ℍ) ⊕ M₂(ℍ), M₄(ℍ), M₈(ℂ) as "complex or quaternion grids", the commutants ℂ, ℍ, ℍ, ℍ, ℂ, the isomorphism with the cell of one direction fewer (T5), the dimension of the even spatial labels that commute with J, "Cl(n−1,0) computed by the same routine".
- `grade-five`: CPL-012's "C(n,5) of grade 5" as "every such blade occurs"; CPL-009's formula of the coupling term; CPL-007b's commutant ℍ, the two named ideals Cl⁺(1 ± γ₀γ₁)/2, Cl⁺(1 ± γ₀γ₄)/2 ("the other smallest ideals tried"), the identity's formula and the polarisation, "kills the other" half; CPL-007d's sign s of the simple factor, "t = ±1, ±2, ±½" as "small weights".
- `views`: YM-002's per-equation count of commutator terms, 2(m − 2)(n − 1) (the per-part count and the total (n − 1)(2m − 3) are kept); YM-004's "Nothing here is new" (A60) as "the textbook".
- `algebras`: YM-006's "centre spanned by J, derived algebra su(n)", "as the derived algebra of the centraliser of J", "inside su(5)", "not computed" (its "recalled" kept).
- `gravity`: YM-007's "(= 1/g, with g = 1 in this normalisation)"; YM-007b's list of tried multiples (as "from zero to 3/2"), the rescaled values and the residual relation, "hyperspherical coordinates", "with the coupling at R = 2".
- `skyrme`: ATY-012's formulas of the field and of the hedgehog profile, the orientation convention, the Chern–Simons formula (its value minus 4 kept); ATY-013's metric and integrand formulas, the circle's two points, "where pq is a square"; ATY-014's routine names, the scale relation (as "as printed"), the figure numbers (as "the first", "the third"); ATY-015's equation numbers and "by g(∞)", "by g along the circle" (as "turns both holonomies").
- `instanton`: ATY-034's two routes of the star (the bit rule's and the tensor of signs), the explicit gauge parameters and their degree bound, the script name (R13).
- `current`, `coupling` (matter): MAT-002's identity as "divergence minus twice a plain part"; MAT-005's normalisation formula and the script that names its current (R13).

Whether chains like these get 0.9 is the owner's open question (`docs/HANDOVER.md` §3); at 0.9 every item above would fit.

## 5. The full texts of the side notes

Each tells one piece: what it is, why it is on its page, what it links to (from its `depends`: the verdict and its cases, the tally and its count, the chain it stands beside), what was checked, the numbers and status words kept. R9 bounds each (900, or 1.5 × the research text); none needs a C7 budget.

| row | page · section | status | characters | note |
|---|---|---|---:|---|
| SPN-001 | `steps/spin` · eq-spin | meta | 372 | the verdict; the page's hero with no short learner text, so this is the learner page-top line (D66); 22 and 2, exact |
| SPN-002 | eq-spin | meta | 347 | whose equations; textbook |
| SPN-003 | eq-spin | our reading | 438 | the side-by-side reading; "our work", "our reading"; the 9 of the exclusive or |
| CAND-017 | eq-spin | proved | 1347 | the Weyl halves; names row SPN-003 as its research text does; 2, 3, 5; exact |
| SPN-004 | eq-spin | open | 713 | not checked, input, open; 5 and 6 |
| SPN-005 | eq-spin | open | 416 | not read, not tested, open |
| EQN-017 | `steps/spin` · summary | proved | 492 | the tally; 30, 22, 2, 6; exact, not checked |
| CAND-076 | summary | proved | 2055 | the splitting of planes; all 15 numbers; checked, exact, recalled |
| CPL-005 | `steps/coupling` · eq-coupling | proved | 648 | what stays free and what is fixed; exact |
| CPL-006 | eq-coupling | open (dead end) | 257 | 1 or 2 directions; "that stays open" |
| CAND-039 | eq-coupling | proved | 537 | stress and Lorentz force; checked, exact, textbook |
| CPL-008 | eq-coupling | proved | 2114 | what the step leaves to steps 7 to 10 and what it draws; 3, 4, 7, 8, 16; "the field equation of gravity" (its row does not name Einstein, R12) |
| CAND-110 | eq-coupling | proved | 636 | the null cone; 2, 5; checked, exact |
| EQN-009 | `steps/coupling` · summary | proved | 448 | the tally; 3, 4, 6, 8, 24, 72 (the 24 read as the field equation's terms, as EQN-006 counts them) |
| YM-005 | `steps/ym` · eq-ym | meta | 425 | the coupling stays free; checked |
| EQN-010 | `steps/ym` · summary | proved | 383 | the tally; 2, 3, 4, 8, 18, 216 |
| CAND-047 | summary | proved | 1569 | Wilson's plaquettes; checked, exact, floats, not checked |
| CAND-027 | summary | proved | 1312 | the Cartan curvature, Yang–Mills its case; checked, exact |
| MAT-006 | `steps/matter` · eq-matter | open | 657 | which representation; input, standard, unread |
| MAT-007 | eq-matter | proved | 915 | the one solution checked; 4, 7, 16; checked, standard, exact |
| EQN-011 | `steps/matter` · summary | proved | 322 | the tally; 2, 3, 4, 8, 64, 1088 |

## 6. The rules that bit

- **C7**, on every chain (§4).
- **R6**: "two-switch" is not one of the checker's number words (a hyphenated pair counts only when both halves are number words), so YM-003 says "edges between 2-switch corners".
- **R8**: the section leads are full records and R8 reads their research texts: YM-711 needed "textbook"; ATY-034 lost "checked" in a trim and took it back ("explicit gauge parameters checked on the same grid").
- **R12**: CPL-008's research text does not name Einstein ("the field equation of gravity with this source"); "Atlas" only where the row names it (ATY-014).
- **R4**: lone letters ("i", "n", "m") and so(m), Cl(n−1,0) avoided: "the imaginary unit", "the gauge count", "the turns of the gauge directions".
- **R13**: no script name (MAT-005's current, ATY-034's stabiliser script).
- **A60**: no "new" anywhere ("the only addition", "beyond the textbook").
- **The words screens** (09 §2.2): every record's 40-character windows, at every offset, against the strings drawn outside statements (`notes.json`, `pages.json`, `figures.json`, `lenses.json`, `glossary.json`, the stored tables, the chain titles, the Logbook's tables, `src/`). Caught before any write: three runs of a note (`tools/check_notes.mjs` rule G) — CPL-007b "the extra components are a second Dirac field", CPL-005 "the sign of the source relative to the", ATY-014 "… Skyrmion are recomputed by a standard …"; two chain titles — YM-712 repeated "knot of the field read along lines and circles" (at an offset of 120: the coverage test would have failed), YM-713 "knot of the field and the ways it can move"; and runs of Logbook tables (theorems, questions, sources, candidates, leads, checks), of `glossary.json` (CPL-005) and of `content/story/pending.json`. All rephrased; the screen finds no window.
- **The glossary**: "the action" is a glossary term (the physical action); MAT-008 and MAT-006 meant the action of the gauge algebra and say "the gauge action", "the commutator action", so R10 does not attach the term there.

## 7. The checker, the commands and their last lines

Four pieces, one per page, the checker on the file after each; **each passed on its first write**. Before each write the drafts went through the checker's own functions (`check`, `checkChains` with `testBlock`, `deriveFields`) on all the learner files with the candidate in place, in a scratch harness outside the repository (as T3m and T4b drafted), and through the words screen; they caught the C7 overruns of §4, the R6 of YM-003 and the R8 of YM-711 and ATY-034.

| command | last line |
|---|---|
| `node tools/check_learner_texts.mjs --explain <chain id>`, for the 12 chains | the worksheets (budgets 531, 254, 1120, 2622, 912, 575, 1472, 5160, 1522, 356, 522, 552; links and C4 words; C5 words at the weak links; R6 and R8 lists; no human text) |
| `node tools/check_learner_texts.mjs --file content/chains/learner/<page>.json` (steps-spin, steps-coupling, steps-ym, steps-matter) | `PASS: all 24 rules hold for every record` (11, 48, 24 and 11 records) |
| `node tools/check_learner_texts.mjs` (every learner file together) | `PASS: all 24 rules hold for every record` (1641 records at the last run, the other storytellers' included) |
| `npm run content` (after each page) | `errors 0, warnings 0; see docs/COVERAGE.md` (last: chains 117, 97 storied, 394 spans) |
| `node tools/merge_chains.mjs --check` | `merge_chains --check: 117 chains on 24 page(s), 97 storied (0 reviewed), 394 spans; round-14 rows: 63 story rows, 13 statement rows` (no warning left on SPN-711, CPL-711, YM-711, YM-712, YM-713, MAT-711; the 17 chains of the four pages `story: "draft"` in `content/chains.json`) |
| `node tests/coverage.test.mjs` (after each page) | `PASS: every statement is a text record of its row; no KaTeX at learner level; badges as computed; …` |
| `node tests/story.test.mjs` (after each page) | `story: 6 of 6 test files pass` |
| `node tools/check_notes.mjs` | `check_notes: 11 of 11 rules pass` |
| `sh build.sh` (after each page; a look, not a release) | `export_tuning: 1,919 records, 3,951 texts, 368 checks and 625 runs, 35 lenses, 7.49 MB in dist/content/tuning/` |
| `node tests/ui/chains.smoke.test.mjs` (after each build) | `PASS: the chains render at both levels, in both themes, at 390 and 1366 px, without overflow or console error: …` |
| a look at learner level (Playwright on `dist/`, `#/steps/spin`, `#/steps/coupling`, `#/steps/ym`, `#/steps/matter` with `?l=learner`, 1366 and 390 px) | each chain one paragraph of its spans in order (17 paragraphs, no `ol.chain__list`), the mention dotted, the badges inline at the open rows; the section leads under their titles; the 21 side notes in their storyteller words; SPN-001 on the page top of `steps/spin`; 0 console errors, 0 px overflow |

## 8. For the lead and the owner

- **R3 and the side notes.** The brief's item (c) met R3 on the first try (a storyteller full text beside the translator draft of its key); the coordinator's D68 resolved it before any page file held such a pair, and all 21 full texts are in the page files. The retire of 2.17.0 moves the 18 translator drafts (SPN-001, SPN-002, SPN-003, SPN-004, SPN-005, EQN-017, CAND-076, CPL-005, CPL-006, CAND-039, CPL-008, CAND-110, EQN-009, EQN-010, CAND-047, MAT-006, MAT-007, EQN-011).
- **YM-007b**, told in `steps-ym.eq-ym.gravity`, has no learner full text anywhere (its span is its only learner record); the drawer reads a row's full text. Not written: outside the brief's list.
- **EQN-009's tally** "72 + 24 in 4D" is told as 72 plus 24 terms, "the 24 being those of the field's own equation" (EQN-006 counts 24 for Maxwell in four dimensions); the owner may want the 72 named in the row itself.
- **SPN-001**, the hero of `steps/spin`, has no short learner text, so its full text is the learner page-top line; the storyteller's text is written to read there.
- **One run overlapped.** Another agent's `npm run content` ran at the same time as the one after `steps/coupling`; the pipeline was run again alone and gave the same counts.
