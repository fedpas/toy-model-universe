<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Lens readings

A **reading** of a row in a lens is the lens's term for an element the row states (BUILD_CONTRACTS, interface 7). It shows under the statement, in small muted type, when that lens is active, and never in place of the statement. The readings live in `content/lens_readings.json`; `node tools/migrate/lens_readings.mjs` writes that file from `rows.json`, `texts.json`, `lenses.json`, `readings.json` and `checks.json` (for the check ids each script lists), and from nothing else. No record is written by hand: after a change to one of those tables, run the script; the same tables always give the same file.

## A record

`{ lens, row, atlas, term, match, evidence, via, source }`. `atlas`, `term` and `match` are copied from the dictionary entry (`atlas`, `term`, `match`) or from the reading (`atlas_element`, `field_term`, `grade_or_status`). `via` names the link that attached it. `evidence` lists the check ids of that link: the ids the entry shares with the row when `via` is `evidence`; when `via` is `text`, the entry's own check ids that some row cites (often none). The file is sorted by (lens, row, atlas).

## How a reading reaches a row

Two sources and two links, nothing else.

1. **The dictionaries of the lens registry** (`lenses.json`: 973 entries in 12 lenses). An entry is attached
   - *via evidence* to every row whose `evidence[].check` shares an id with the entry's `evidence` list (ids compared trimmed; a script path or `x.py` counts as its base name `x`);
   - *via text* to every row whose research text contains the entry's atlas phrase (below).
2. **The specialist readings** (`readings.json`: the 982 entries of the specialist analyses) whose `field` has a lens in the table `FIELD_LENS` at the top of the script. A reading is attached
   - *via evidence* through the check ids it names in its note and in its atlas element:
     - single checks written out, with the author's shorthand expanded (`bd·mja·3, 19, 21` gives three ids; likewise `core·B7–B9`, `core·B10b/c`, `cat·K1a–e`, `bd·mjg·1, ·7`), a group name standing for its members (`fibre·G5` for `fibre·G5a`, `fibre·G5b` …), and a check named after its script (`` `baez_check.py` T4 ok `` gives `baez·T4`, through the ids `checks.json` lists for that script);
     - whole scripts (`gtg_check`, `check_T4.py`) only when written in the note's evidence clause (`evidence: …` or `checks: …`, up to `; flag`), and only when no single check of the reading links any row: the most specific shared check wins. A script mentioned in running prose ("a check of that identification is not in baez_check.py") is not evidence.
   - *via text*, as for the dictionary entries.

**The atlas phrase.** The entry's atlas element with its `$…$` formulas, backticks and bold marks taken out, white space collapsed and the punctuation at its two ends trimmed. It must keep at least 12 characters and occur in the row's research text (research level, no lens; formulas and markup taken out the same way) verbatim up to case and as whole words: "generator square" does not match "generator squares".

**One record per (lens, row, term).** When several links give the same term to the same row in the same lens, the record kept is a link by evidence before a link by text, and the registry's entry before the reading; it carries the check ids of all the links of its kind.

## Counts

| lens | records | rows | via evidence | via text | from the dictionary | from the readings |
|---|---|---|---|---|---|---|
| Algebra (`alg`) | 299 | 172 | 285 | 14 | 152 | 147 |
| Geometry (`geo`) | 393 | 180 | 387 | 6 | 129 | 264 |
| Category theory (`cat`) | 259 | 106 | 250 | 9 | 109 | 150 |
| String theory (`str`) | 313 | 200 | 312 | 1 | 77 | 236 |
| Solid state (`sol`) | 192 | 104 | 181 | 11 | 118 | 74 |
| Field theory (`fld`) | 192 | 111 | 179 | 13 | 152 | 40 |
| Baez (`baez`) | 43 | 32 | 43 | 0 | 0 | 43 |
| Schuller (`schuller`) | 10 | 10 | 10 | 0 | 0 | 10 |
| Majkić (`majkic`) | 199 | 36 | 188 | 11 | 11 | 188 |
| Pumplün (`pumplun`) | 1 | 1 | 0 | 1 | 1 | 0 |
| **all** | **1,901** | **435** | **1,835** | **66** | **749** | **1,152** |

The 435 rows read in some lens sit on 29 pages. Of the links by evidence, 1,557 go through single checks and 278 through a whole script. 190 of the 973 dictionary entries and 405 of the 889 mapped readings reach at least one row. A row has at most 17 readings in one lens; one term reaches at most 57 rows (the string-theory reading of the type table, through `check_T4`). The other 24 lenses have no reading: `top`, `comb`, the seven shapes, `furey`, `hestenes`, `pga`, `roelfs`, `tian`, `hbhl`, the four label lenses and the five conventions. The same counts are in `content/MIGRATION_COUNTS.json` under `lensReadings`.

## Fields and lenses

| field of `readings.json` | readings | lens |
|---|---|---|
| mathematics: algebra | 102 | `alg` |
| mathematics: geometry and topology | 93 | `geo` |
| mathematics: category theory | 87 | `cat` |
| category lens (KTH notes, Tenfold Way, Tian, Majkic v2) | 81 | `cat` |
| physics: string theory | 68 | `str` |
| physics: solid state | 82 | `sol` |
| physics: field theory | 46 | `fld` |
| Schuller lectures (mathematics for physics) | 113 | `schuller` |
| Baez: octonions, Jordan algebras, Standard Model | 70 | `baez` |
| Hestenes / Lasenby-Doran-Gull (…) | 23 | `hestenes` |
| Furey (…) | 20 | `furey` |
| Pumplun (…) | 14 | `pumplun` |
| Majkic paper (merged, four lanes); algebra, category theory, geometry, physics (Majkic reading) | 23 + 14 + 19 + 18 + 16 | `majkic` |
| physics: theoretical physics (all) | 48 | left out |
| mathematics: whole mathematics | 36 | left out |
| merge agreement (physics x mathematics) | 9 | left out |

The three fields left out have no obvious counterpart among the lenses; the script prints them. The registry files the first under `fld` and the second under `alg`, but there their entries carry no evidence ids, so they reach no row.

## Where readings show

- **Under a statement**, when a lens is active: `In the <lens> lens: <term> <match>`, the first two readings (links by evidence, the registry's entries and exact matches first) and `+n`, a button that opens the rest. At learner level only the terms without a formula (no `$`, `\`, `^`, `_` or `=`). With no lens active nothing is added to the statement.
- **The lens room** (`/lenses/<key>`): the number of rows read in the lens and of their pages, "Pages with readings", and "Rows read in this lens" (the first 12, each row id linking to its place, with its first term; "Show all").
- **The lens index**: "N rows read" on each card. **The Logbook**: "Readings by lens" in a row's drawer (lens → term, match, link).
- **Tests**: `tests/coverage.test.mjs` checks the table (known rows, no empty term, every link holds, sorted, one record per lens, row and term) and every reading line rendered against it, with every lens on every page and with `cat`, `geo` and the lens with most readings after them on every route; with no lens, no line may render.

## A new lens

A lens gets readings when its dictionary entries carry `evidence` (check ids that rows cite in their evidence) or atlas phrases that the research texts say word for word. For a new analysis in `readings.json`, name the checks in the note's evidence clause as the analyses do (`evidence: core·B3, bd·cat·12; flag: …`) and add one line for its `field` to `FIELD_LENS`. Then run `node tools/migrate/lens_readings.mjs`; the coverage test fails on any record whose link does not hold.

**The Atiyah lens** (`atiyah`, `docs/round8/ATIYAH.md`) is a lens built this way from scratch: every dictionary entry names either check ids that rows cite (the five scripts of the Atiyah readings, cited by the ATY rows and by CAND-124, GOS-005 and LNS-013d; or an existing check such as `sm16·D1` or `bd·str·5`) or an atlas phrase taken verbatim from the research text of the row it reads, so that the generator attaches it there and nowhere else by hand. Its 71 entries give 252 records on 150 rows; a reading on an ATY row comes by evidence, a reading on an older row by its phrase.

## Decisions for the author

1. **Whole-script links.** 278 records come from a reading and a row that cite the same script (`gtg_check`, `check_T4`, `check_T18`, `maxwell_selfcheck`, `equations_selfcheck` …). They are on topic but coarse: on step 2 the geometry reading "Λ²V ≅ 𝔰𝔬(V)" sits under all five statements. Keep them, or attach through single checks only (about 1,620 records).
2. **Readings that name their row.** 185 mapped readings name a row id in their atlas element or note ("translation = null rotation (LAB-004)"), and 213 of those 232 (reading, row) pairs are attached by neither link. A third link, "the reading names the row" (the rule behind `rows.readingRefs`), would attach them exactly; it needs a line in interface 7.
3. **Topology, Furey, Hestenes.** The analysis "geometry and topology" maps to `geo` only, as the registry does, so `top` has no reading. The Furey and Hestenes readings name checks of their reports (`B1`, `H1`) that no row cites, so those two lenses have none either.
4. **The two "(all)" fields.** Map "theoretical physics (all)" to `fld` and "whole mathematics" to `alg` as the registry does (one line each in `FIELD_LENS`), or keep them out.
