<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->

# Learner texts, part 2 (J1): the long rows and the category lens

`content/texts_learner_2.json` holds **166 learner drafts**, one per row, and no row of the assignment is left out:

- the **33 rows** that the first pass (`docs/LEARNER_TEXTS.md`) left out for length or form: GRV-002, GRV-003, GRV-004c, GRV-004d, GRV-005, GRV-006, GRV-007, GRV-008, GRV-010, GRV-011, GRV-012, NUL-001, NUL-001b, NUL-001d, NUL-003, NUL-004, NUL-010, PRJ-002, PRJ-005, PRJ-006, LAB-005, LAB-006, EQN-019, EQN-020, CPL-008, CPL-011, SPR-004, RIG-002, RIG-005, PAG-013, PAG-021, PAG-024, FUR-002b;
- the **133 rows** of the backlog's `lenses` group with an id starting `LNC` (123, the category lens chapter, step 18), `LNP` (4, the lenses page) and `LAB` (6, the groups chapter, step 17) that had no learner text. None of them had one; the 32 human learner texts of the chapter (LNC-011 … LNC-096) are the author's and are not touched.

Every draft is a translation of its row's research text (`texts.json`, level research, lens null, mode both) under `docs/09_TRANSLATION_PROTOCOL.md` §2: the same statement in plain words, no formula, no new claim, every number, scope and status word kept. Records have the shape of `texts.json` plus `termsUsed` and `keptNumbers`, both recomputed by `node tools/check_learner_texts.mjs --fix --file content/texts_learner_2.json`.

## Verification

| step | result |
|---|---|
| `node tools/check_learner_texts.mjs --file content/texts_learner_2.json` | PASS, 166 records, all 13 rules |
| `node tools/check_learner_texts.mjs` (every `texts_learner*.json` together) | PASS, 793 records; no duplicate across the four draft files |
| `node tools/merge_learner_texts.mjs` | 793 drafts merged; `texts.json` holds 1838 texts, 825 learner (32 human, 793 draft); no human text replaced |
| `node tools/build_content.mjs` | 0 errors; the 224 warnings are row dependencies and evidence ids (`core·B14`, `bzw·P4`, `cat·22` …), none about texts |
| `node tests/coverage.test.mjs` | PASS (learner level renders every statement from its text record, no KaTeX) |
| `node tests/logbook.test.mjs` | PASS (535 of 535) |

`tests/shipped.test.mjs` finds no banned phrase in any text body (rule 1 holds); its other failures belong to other owners' files, and its "content copies" check asks for `sh build.sh` after the merge (the build in `dist/` predates the merged `texts.json`).

## Drafts by page

Each row of this pass is shown on one route.

| route | drafts | hero row drafted |
|---|---|---|
| `steps/category` (step 18, the category lens) | 123 | LNC-001 |
| `steps/groups` (step 17) | 6 | LAB-009 |
| `lenses` | 4 | LNP-001 |
| `steps` (the equations overview) | 2 | PAG-021 |
| `steps/grav1` | 6 | GRV-003 |
| `steps/grav2` | 5 | GRV-010 |
| `steps/nullsurf` | 7 | NUL-001 |
| `steps/projective` | 3 | PRJ-002 |
| `steps/gauge` | 2 | LAB-005 |
| `steps/rigid` | 3 | |
| `steps/coupling` | 1 | |
| `steps/spring` | 1 | |
| `matter` (Calibration 2, the Furey section) | 2 | |
| `rule` (conventions, the glossary entry “the action”) | 1 | |

By backlog group: lenses 133, equations 30, furey 2, conventions 1. With this pass every page hero listed by the first pass as lacking a learner text has one (`steps`, `steps/grav1`, `steps/grav2`, `steps/projective`, `steps/gauge`, `steps/nullsurf`), and so do the heroes of `steps/category`, `steps/groups` and `lenses`. Lengths run from 44 to 9531 characters (median 442).

## Rows left out

None. The checker now allows a learner text up to 1.5 × the research text when that is longer than 900 characters, so the long rows are translated whole. Twenty drafts sit at or within 1 % of that cap, so an edit that lengthens one of them will fail R9: LAB-005, EQN-020, GRV-004c, GRV-005, GRV-007, GRV-010, GRV-011, GRV-012, NUL-001, NUL-001b, NUL-001d, NUL-003, NUL-010, LNC-002, LNC-004, LNC-006, LNC-057, LNC-060, LNC-087, LNC-143. To fit, a few definitions written inside formulas are named rather than spelled out (see the points below); no claim, number, scope or status word is dropped.

## The register

- **Category chapter (LNC):** the vocabulary of the author's 32 human learner texts of that chapter: a cell is a **box**, a label is a **corner** of the cube, a generator a **switch** (**plus**, **minus**, **zero switch**), the E-series steps are **rungs** and its Cartan matrix the **dot-and-line picture**, a symmetric Frobenius form is a pairing **fair both ways**, a state is a **way of giving probabilities**, the moves are **join**, **halve**, **forget the zero** and **opposite**. The research texts write cells with letters (Cl(p,q), Cl(0,n−2,1)); the checker reads such letters as variables, so these cells are described in words (“the box with one zero switch and as many minus switches as spacetime has directions, minus two”).
- **Physics rows (GRV, NUL, PRJ, LAB-005/006, CPL, SPR, RIG, EQN):** as in the first pass: a generator is a **direction** (“with 4 directions”), and frame, connection, curvature, torsion, the Einstein form and the engine keep their names; Greek letters are named by their object (the surface gravity, the cosmological constant, the coupling); the PPN parameters, which have no plain name, are written gamma and beta.
- **Strip lines** (bare phrases whose v15 strip carried a tag) start with the tag of the row's `legacyFlags`, as in the first pass: LAB-009, LAB-019, LAB-020, PAG-021 “Checked”; LAB-010, LNP-002, RIG-002 “Standard”; LAB-011, LNP-003 “Ours”; LAB-012, LNP-004, PAG-024 “Open”.
- Identifiers are dropped (check ids, question ids such as QA4, script names); theorem numbers (T2, T9 …), arXiv numbers, section and equation numbers of a cited paper are kept.

## Three examples

**LNC-040** (category lens, a construction).
Research: “A fifth map, the mother algebra: Cl(p,q,r) ↪ Cl(p+r,q+r), each null generator to f^{+} − f^{−}; a label with k null bits goes to 2^{k} labels, and the clock is the same.”
Learner: “A fifth map, the mother algebra: each box sits inside the box with one more plus and one more minus switch for each zero switch, each zero switch going to a new plus switch minus a new minus switch. A corner with some zero switches goes to 2 to the power of that number of corners, and the clock stays the same.”

**PAG-013** (matter, a source list).
Research: “Furey’s papers, December 2023 to July 2026 (arXiv 2312.12377, 2312.12799, 2312.14207, 2409.17948, 2607.18450)”
Learner: “Furey’s papers, five of them, listed by their arXiv numbers from the first to the last: 2312.12377, 2312.12799, 2312.14207, 2409.17948 and 2607.18450.”

**GRV-012** (grav2, a set of formulas said in words).
Research: “Solutions. T = 0 is solved for ω in closed form (the Cartan–Koszul inverse; see the row of step 9 on ω as a function of e), and pointwise as a square linear system of full rank, so uniquely, for generic tetrads n = 3, 4, 5 and for the step-12 Kerr–Schild frame. The Einstein form is solved in one class: Kerr–Schild frames with the radial null direction and any f(ρ), where the mixed Einstein tensor is linear in the 2-jet of f (G^t_t = 2(ρf)′/ρ², G^t_i = 0, G^i_j = (2f/ρ²)x̂_i x̂_j + (2f′/ρ)δ_ij + f″(δ_ij − x̂_i x̂_j)) and the Einstein form with a cosmological term c reduces to (ρf)′ = (3/2)cρ² (the tangential equation (ρf)″/ρ = 3c is its derivative); its solutions are f = M/ρ + (c/2)ρ², that is g_tt = 1 − 2M/ρ − cρ²: Schwarzschild and Schwarzschild–(anti-)de Sitter are derived in this class, not borrowed (28 (point, jet) samples in all 16 components; in a Laurent ansatz ρ⁻³…ρ³ with unknown c the null space has dimension exactly two). The class is restricted (one function, one null congruence): this is not the general Birkhoff theorem. Step 12 takes the Schwarzschild solution from the literature, in its Painlevé–Gullstrand and Kerr–Schild forms, as shears of the frame and rebuilds its metric from the frame; the Painlevé–Gullstrand form and Kerr are still put in.”
Learner: “Solutions. Zero torsion is solved for the connection in closed form (the Cartan–Koszul inverse), and point by point as a square system of full rank, so uniquely, for general frames with 3, 4 and 5 directions and for the Kerr–Schild frame of step 12. The Einstein form is solved in one class: Kerr–Schild frames along the radial null direction, with any profile of the radius. There the mixed Einstein tensor is linear in the profile and its first two derivatives: in time, twice the slope of the radius times the profile, over the radius squared; zero between time and space; in space, twice the profile over the radius squared along the radius, plus twice the slope of the profile over the radius in all directions, plus its second derivative across the radius. With a cosmological term the Einstein form reduces to one equation: the slope of the radius times the profile is three halves of the constant times the radius squared (the tangential equation, the second derivative of that product over the radius equal to 3 times the constant, is its derivative). Its solutions: the profile is the mass over the radius plus half the constant times the radius squared, so the time–time metric entry is one minus twice the mass over the radius minus the constant times the radius squared. Schwarzschild and Schwarzschild–de Sitter or anti-de Sitter are derived in this class, not borrowed (28 samples of a point and its derivatives, all 16 components; in a trial sum of powers of the radius from the inverse cube to the cube, the constant unknown, the solutions span exactly two dimensions). The class is narrow (one function, one null bundle): this is not the general Birkhoff theorem. Step 12 takes the Schwarzschild solution from the literature, in its Painlevé–Gullstrand and Kerr–Schild forms, as shears of the frame, and rebuilds its metric from the frame; the Painlevé–Gullstrand form and Kerr are still put in.”

## Points for the author: research texts that are unclear, or that the checker forces into a choice

1. **LAB-011** names two readings without stating them (“the finite shadow of a translation; the Klein link at n = 4”). Any explanation would add a claim, so the learner text repeats the two phrases (“Ours: the finite shadow of a translation, and the Klein link with 4 switches.”). The row needs one sentence per reading before a plain version can say more.
2. **LNC-061** begins “Their combinatorial Clifford algebra” with no named authors in the row (the cat-papers section supplies them; LNC-026 and LNC-136 name Lundholm and Svensson). R12 accepts only names of the row's own research text, so the learner text keeps “Their”. Naming the authors in the research text would let the learner text name them.
3. **GRV-008** and **NUL-004** write the Einstein form only as a symbol, and **GRV-011** never spells out the Einstein–Cartan action or the Laplacian; R12 then refuses those names in the learner text, which says “the form of the field equation”, “the field form”, “the gravity action” and “the sum of the second derivatives”. Using the names in the research texts would make the plain versions closer.
4. **Dates.** A learner text carries no date (R5). PAG-013's range “December 2023 to July 2026” is not carried: the five arXiv numbers are kept, in order, with the count five (the v15 Young Learner strip says “six papers”; the research text lists five). In EQN-019, RIG-005 and PAG-024 the planets table's date, the hour of its JPL rows and the month of the 31 daily rows become “dated to one day”, “at midnight TDB” and “31 daily rows a month long, 8.7 years later”; every number of the data is kept.
5. **Definitions inside formulas.** GRV-004c does not spell out the generators of so(2,4) as half a direction times a member of the null pair, and NUL-001b names the Boyer–Lindquist pieces (Δ, Σ, A) as “a form built from radius, mass, spin and angle”; the claims (the gradings, the curvature parts, the exact match at 40 points, A not the horizon area) are kept. NUL-001d's “these are dM = κ_H dA/8πG + Ω dJ + Φ dq and the Smarr relation” is said as “these take their usual forms”.
6. **Lone letters.** The checker treats a lone capital as a variable, so “Weyl type D” (GRV-004c, GRV-004d) is written “type-D”, and the case labels (b), (c), (d) of NUL-003 become “Second”, “Third”, “Fourth” (and (1), (2) of LNC-070/LNC-070b “First”, “Second”).
7. **PRJ-005**: “engine mass μ/(1 + κ_G q²)” does not say what q is; the learner text says “the square of its position”. A word in the research text would remove the guess.
8. **NUL-003** starts “Yes, …”: it answers the question of its section heading, which the row does not repeat; the learner text keeps the “Yes”.
9. **LNC-118**: “(catw·P1, every choice of squares with n ≤ 4)” is read as a check and rendered “(checked for every choice of squares, up to 4 switches)”.
10. **LNP-004** carries the flag `checked` but is a list of open items (the persona notes say so); its learner text starts “Open:”.
11. The glossary still has no learner definitions; `termsUsed` names research-level glossary terms, as in the first pass: “null” (30 drafts), “base / fibre” (6), “the action” (4), “clock value” (4), “address” and “label 0” (1 each). “Base” is matched also where it means a base ring, a base category or a Lorentz base, words the research texts use in the same places.
