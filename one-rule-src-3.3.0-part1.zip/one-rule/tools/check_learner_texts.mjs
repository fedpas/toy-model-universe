#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/check_learner_texts.mjs — the mechanical checker of docs/09_TRANSLATION_PROTOCOL.md §3, applied to the learner drafts of
// content/texts_learner*.json (BUILD_CONTRACTS interface 8), and to the storyteller's words of round 14 (docs/round14/STORY_ROUND.md §3.2, §7):
// content/chains/learner/*.json, the spans of the chains of content/chains/*/chains.json and the learner texts of round-14 rows and side notes.
// A learner text is a translation of its row's research text: the same statement in plain words, with no formula, no history wording, every number
// and every status or scope word of the research text kept. A span is that text inside one chain: it also opens with the connective of its link
// (the depends graph's own logic: no unearned "so"), says the status of a weak link, and the chain's spans tell one story.
//
// Usage (from the repository root):
//   node tools/check_learner_texts.mjs                 check every content/texts_learner*.json and content/chains/learner/*.json together; exit 1 on any
//                                                      failure, with a table of failures by rule
//   node tools/check_learner_texts.mjs --fix           first recompute the two derived fields of every record (termsUsed, keptNumbers) from its body
//   node tools/check_learner_texts.mjs --explain ID    print what the checker reads in the research text of row ID (numbers to keep, status words)
//   node tools/check_learner_texts.mjs --explain CHAIN the storyteller's worksheet of a chain (an id <page key>.<section>.<slug>): per position its link,
//                                                      the words C4 allows, the status word C5 asks for, the numbers R6 asks for
//   node tools/check_learner_texts.mjs --file PATH [--chains PATH]   check another file of the same shape (spans against the chains of --chains, else
//                                                      of content/chains/*/chains.json)
//
// The rules (each failure names its rule):
//   R1  shape       a record has exactly the keys row, lang "en", mode "both", level "learner", lens null, register "full"|"short", body, status "draft"|"reviewed",
//                   (a "short" record is the few-words register of 02 §2 — Explore notes and heroes; it may say less than its row, never more: R6 is replaced by R7 for it, R9 is 20 to 200 characters)
//                   source "translator:learner@…" (or "translator:story@…", the story variant of the persona, STORY_PLAN §1.5; or "storyteller@…", round 14),
//                   termsUsed [strings], keptNumbers [strings]; a span adds chain and span, register "span", source "storyteller@…", mode "both" or its
//                   twin's mode (C11), status "human" only for a row's human words (C10)
//   R2  row         the row exists in content/rows.json (or among the round-14 rows of content/chains/), has a research text (level research, lens null,
//                   mode both) and, unless the record is a span (C10 decides its words), no human learner text
//   R3  duplicate   no two records of one kind with the same (row, mode, level, lens, register, chain); a storyteller's learner text may stand
//                   beside the translator's draft of its key and supersedes it (D68, round 16)
//   R4  formula     no formula marks: $ \ ^ _ { } = < > | ~, no operator or arrow (≡ ⊗ ∧ ∂ ∇ ∑ ∫ ⟨ ⟩ → ↦ ≅ ≤ ≥ ± × · …), no superscript or subscript
//                   character, no Greek letter, no blackboard or script letter (ℝ ℂ ℍ 𝕆 ℓ …), no vulgar fraction (½), no letter/letter fraction,
//                   no single-letter variable (a lone letter other than a, A, I)
//   R5  history     no word of the banned families: the list of BUILD_CONTRACTS (corrected, withdrawn, superseded, formerly, previously, re-worded,
//                   now proved, historically, used to, no longer), the English families P1–P6, P8, P9 of v15's test_no_history.mjs (reused below),
//                   and no date
//   R6  numbers     every number of the research text is in the learner text: every integer ≥ 2 (in digits, or as a number word: "two",
//                   "twelve", "second", "half" for 2 …) and every decimal or scientific number verbatim ("116.6", "3e-5"); numbers that belong to an
//                   identifier are not required (see IDENTIFIERS: Cl(1,3), cell addresses [4,−2], group names so(4,2), e1/E8/T18-style names,
//                   row and check ids, step, figure and equation numbers, script names, arXiv numbers, dates, digits under ^ or _);
//                   a check count "5569/5569" is kept by "5569 of 5569"; a mention's span takes the short register's rule (R7 only)
//   R7  new number  no number written in digits in the learner text that is absent from the research text (0 and 1 excepted)
//   R8  status      each status or scope word of the research text is in the learner text (open, input, checked, conjecture, ours / our reading,
//                   not proved, textbook / standard, exact, at points, floats, cited, recalled, unread, untested, not checked, not claimed,
//                   not derived, by hand, regression, for every n): see STATUS
//   R9  length      40 to 900 characters, or up to 1.5 × the length of the research text when that is longer (long rows are translated whole, not split);
//                   a mention's span 20 to 300
//   R10 terms       termsUsed lists glossary terms (content/glossary.json) that occur in the body, and every glossary term that occurs in the body
//                   (the three context-bound terms form, vertex, mode excepted, as in src/app/glossary.js)
//   R11 kept        keptNumbers lists exactly the numbers R6 requires
//   R12 names       a capitalised word inside a sentence (a name) occurs in the research text of the row or of its parent row: no new authority
//   R13 contact     no e-mail address, link, script name or machine path
// The chain rules (round 14, §3.2), on the spans read with their chain records (owners' files), the rows and their computed statuses:
//   C1  chain       chain names a chain of the owners' files and span one of its positions; the record's row is that position's row or its twin
//   C2  coverage    a chain with one span has a span for every position, and its lead a learner text: no partial story
//   C3  order       the spans are numbered 1 … n with the positions, one per position (one per twin), no gap and no duplicate
//   C4  connective  span i ≥ 2 opens with a word of its link's set (CONNECTIVES: derives so, hence, …; instance for instance, …; a back link this
//                   rests on, …); an order link opens freely but never with a word of the derives or contrasts sets: no unearned "so". "Then" is a
//                   sequence word, not a derivation word (round 15, A62 ruling (ii)): an order link may open with it, a derives link may not
//   C5  status      the span of a row whose status is ours, open, cited or input carries that status's learner word (STATUS_WORDS); the span of a
//                   proved row carries none of them unless its research text does
//   C6  lead        the lead's learner text is at most 300 characters, holds no number in digits that no position's research text holds, and passes
//                   T1–T5 of the story test (tools/migrate/story_from_v15.mjs testBlock) against the chain's rows
//   C7  budget      the story (lead and spans) is at most 0.8 × the summed research texts of its positions (told, mentioned, twins)
//   C8  mention     a mention's span is 20 to 300 characters, holds no number in digits its row lacks and keeps its row's status word (C5)
//   C9  outside     no span for a row outside its chain; no learner record with chain and without span, or with span and without chain
//   C10 human       a told position whose row has a human learner text takes that text verbatim as its span (status human, the human text's source);
//                   C4 is waived there
//   C11 twins       a twin has its span, with its row's mode and the number of its position
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { makeTables, statusOf, toldOf } from './story/extract_chains.mjs';
// (testBlock and testRow of tools/migrate/story_from_v15.mjs, for C6, are loaded in main by a dynamic import: that module reads IDENTIFIERS of this
// one when it loads, so a static import here would read it before it exists)

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content');
const readJSON = f => JSON.parse(fs.readFileSync(f, 'utf8'));

// ---------------------------------------------------------------------------------------------------------------------------- R4 formula
const FORMULA = [
  ['dollar, backslash, caret, underscore, brace', /[$\\^_{}]/],
  ['equals, comparison, bar or tilde sign', /[=<>|~]/],
  ['operator or arrow', /[≡⊗∧∨∂∇∑Σ∏∫⟨⟩→←↦⇒⇔⇐↔≅≃≈≠≤≥±∓⊕⊖⊂⊃⊆⊇∈∉∪∩√∞×·⋅⋆∘′″‖⊞⊠♭♯∗†‡∝∅∀∃⊥∥∠°]/],
  ['superscript or subscript character', /[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾ⁿⁱ₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎ₐₑₒₓₔₕₖₗₘₙₚₛₜᵀᴬ-ᵪ]/],
  ['combining accent', /[̀-ͯ⃐-⃿]/],
  ['Greek letter', /[Ͱ-Ͽἀ-῿]/],
  ['blackboard or script letter', /[ℂℍℕℙℚℝℤℓℏℒℱℋℐ℘\u{1d400}-\u{1d7ff}]/u],
  ['vulgar fraction', /[¼½¾⅓⅔⅕⅖⅗⅘⅙⅚⅛⅜⅝⅞]/],
  ['letter over letter (a symbolic fraction)', /\p{L}\s*\/\s*[\p{L}(]/u],
];
const LONE_OK = new Set(['a', 'A', 'I']);
export function formulaHits(body) {
  const out = [];
  for (const [name, re] of FORMULA) { const m = body.match(re); if (m) out.push(`${name}: “${m[0]}”`); }
  // a lone letter, not inside a word or a name with digits (E8, 4D), not an apostrophe ending (Hestenes’), not a name before "(" (U(1)), is a variable
  const lone = [...body.matchAll(/(?<![\p{L}\p{N}’'\-])(\p{L})(?![\p{L}\p{N}’'\-(])/gu)].map(m => m[1]).filter(ch => !LONE_OK.has(ch));
  if (lone.length) out.push(`single-letter variable: “${[...new Set(lone)].join('”, “')}”`);
  return out;
}

// ---------------------------------------------------------------------------------------------------------------------------- R5 history
// The list of BUILD_CONTRACTS Round 2 and of the translator prompt (09 §2), then the English families of v15's test_no_history.mjs
// (P1–P6, P8, P9: the regexes are copied from that file; P7 is its Italian family and does not apply). Dates are not used in a learner text.
const HISTORY = [
  ['banned word (BUILD_CONTRACTS)', /\b(corrected|withdrawn|superseded|formerly|previously|re-?worded|now proved|historically|used to|no longer)\b/i],
  ['P1 ids of a list of notes', /\berrat(a|um)\b|\bE-\d{3}\b|\bfinding E-/i],
  ['P2 a note that a wording was fixed', /\bcorrected (on|in|after|before|by|6|5)\b|\bcorrections? (of|applied|block|section)\b|\bnow corrected\b|\bwas corrected\b|\bcorrected after a check\b|\bcorrigend|\bthe correction of F\d+|\bsee the corrections\b|\bcorrection\b/i],
  ['P3 taken back, crossed out', /\bwithdrawn\b|\bretract(ed|ion)\b|\bretired\b|\bstruck( through| out)?\b|\bsuperseded\b|\bobsolete\b|\bstale\b|\bdiscarded wording\b/i],
  ['P4 first-draft narrative', /\b(was|were|is|are) (wrong|too strong|too weak|a mistake|mistaken)\b(?! (for|in|when|if|only|here|on)\b)|\b(was|were|is|are) false\b(?! (for|in|when|if|only|here|on)\b)|\bas first (written|stated|printed|said)\b|\bfirst (guess|draft|version|reading|explanation|wording)\b|\bour (own )?(first|earlier|previous|old) (guess|reading|explanation|claim|sentence|wording|version|statement)\b|\b(earlier|previous|former|old) (draft|version|wording|claim|statement|sentence|reading|analysis|release|report)s?\b|\b(we|it) (once|previously|used to|had) (said|thought|claimed|believed|written|read)\b|\bused to (say|read|claim|be called)\b|\bformerly\b|\bpreviously\b|\bno longer (said|claimed|true|a mistake|stated)\b|\bto say what we said\b/i],
  ['P5 over-statement narrative', /\boverstate[sd]?\b|\boverclaim|\btoo strong\b|\bwe (had )?misread\b|\bwas (misread|misstated)\b|\bour (own )?(error|errors|slip|slips|mistake|mistakes)\b|\bmisinterpret/i],
  ['P6 version, date of a fix, round', /\bv(7|8|9)(\.\d+)?\b|\bv10(\.[01])?\b|\bv1\.[01]\b|\baudit round( [12])?\b|\bround (1|2|two|one)\b|\bsecond (round|pass)\b|\bchangelog\b|\bsince the last (report|release|version)\b|\bwhat('| i)s new\b|\bwork[- ]in[- ]progress\b/i],
  ['P8 the working of the package, told', /\bREADME_update_|\blane [A-D]\b|\brelabell?ed from\b|\boriginal (label|wording|sentence|text|claim|name)\b|\bfirst assumed\b|\bre-?worded\b|\bwe (have |had )?(replaced|renamed|rewrote|reworded)\b|\bhad been\b|\bhad to be (pulled|taken|split|set|separated|fixed|changed|replaced|rewritten)\b|\bfound (it |them |this )?late\b|\bmet on the way\b|\bnow (proved|proven|exists?|stands?|holds?|states|covers|includes?|carries|stated|written|shown|listed|given|a theorem|T\d+)\b|\band now\b|\(corrections?\b|\bafter an? (noted |small |one-line |written-down )?correction\b|\ba correction we (wrote|noted|made)\b|\bthe new (widget|report|reports|script|scripts|tab|tabs|chapter|chapters)\b|\b(older|previously known as|formerly called) (word|wording|term|name|text|sentence|label)\b|\bin (this|that|the|a) (working )?session\b|\b(this|the) (line|page|sentence|paragraph|text|README|brief|row) (said|called|read|claimed|stated|gave)\b|\bfound by an independent\b|\((first|second|third|fourth|fifth|sixth|seventh) note\b|\b(of|saw|see|under|uses?|used) version [1-9]\b(?![.\d])|\bversion [1-9] (of|gave|fixes)\b|\(version [1-9]:/i],
  ['P9 release number or date as a time word', /\b(up to|until|since|predates?|before|prior to|new in|added in|introduced in|fixed in|changed in|(?:as )?it did in|unchanged from) v?\d+\.\d+\.\d+\b|\bv1\.\d+|\bv1[12345]\.\d+|\b(in|since|new in|added in|changed in|of|for|after|before|from|than) v1[12345]\b/i],
  ['a date', /\b20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b|\b\d{1,2} (January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)\b|\b(January|February|March|April|May|June|July|August|September|October|November|December) (\d{1,2},? )?(19|20)\d\d\b/i],
];
const historyHits = body => HISTORY.filter(([, re]) => re.test(body)).map(([name, re]) => `${name}: “${body.match(re)[0]}”`);

// ---------------------------------------------------------------------------------------------------------------------------- R6, R7, R11 numbers
// Spans whose digits name something (they are not quantities the statement asserts); their numbers are not required in the learner text.
const MONTH = '(?:January|February|March|April|May|June|July|August|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)';
export const IDENTIFIERS = [
  ['script or file name', /[\w.-]+\.(?:py|mjs|js|jsx|json|md|txt|csv)\b/g],
  ['arXiv number', /\b(?:arXiv:?\s*)?\d{4}\.\d{4,5}(?:\s*v\d+)?\b/gi],
  ['date', new RegExp(`\\b\\d{1,2}\\s+${MONTH}\\b\\.?(?:\\s+\\d{4})?|\\b${MONTH}\\.?\\s+\\d{4}\\b|\\b\\d{4}-\\d{2}-\\d{2}\\b|\\b\\d{1,2}:\\d{2}\\b`, 'g')],
  ['year of a citation', /\(\s*(?:1[89]|20)\d\d\s*\)|,\s*(?:1[89]|20)\d\d\s*\)/g],
  ['row id', /\b[A-Z]{2,4}-\d{3}[a-z]?\b/g],
  ['check id', /\p{L}[\p{L}\d]*(?:·[\p{L}\d–-]+)+/gu],
  ['cell name', /Cl[⁰⁺⁻0]?\s*\([^()]*\)/g],
  ['cell address', /\[\s*\d+\s*,\s*[+−\-±]?\s*\d+\s*\]/g],
  // a lowercase name takes its parenthesis only when it follows at once (so(3), spin(10), e(3)): "the spin (… to 1e-6)" or "the same g (checked, m = 2, 3, 4)"
  // is prose, whose numbers R6 requires and R7 credits (round 16, found by T6a); the capitalised names keep the space (Spin (10), M (2))
  ['group, algebra or binomial', /\b(?:(?:so|su|sp|sl|gl|spin|pin|iso|u|o|e|g)\(|(?:SO|SU|Sp|SL|GL|PSL|Spin|Pin|U|O|M|C|R|W|End|Hom|Der|Aut|Sym)\s*\()\s*[^()]*\)/g],
  ['letter-and-digit name', /\b[A-Za-z]{1,3}\d+(?:\.\d+)*[a-z]?\b/g],
  ['polytope name', /[−-]?\d+[₀-₉]+/g],
  ['step, figure, equation or section number', /\b(?:[Ss]teps?|[Ss]tages?|[Cc]alibration|[Ff]ig\.?|[Ff]igures?|[Ee]qs?\.?|Algorithm|Theorem|Thm|Lemma|Table|[Ii]dea|[Pp]art|[Ww]arm-up)\s+\(?\d+(?:\.\d+)*\)?(?:\s*(?:,|and|to|–|-|or)\s*\(?\d+(?:\.\d+)*\)?)*/g],
  ['step number', /\bsteps?-\d+(?:\/\d+)?\b/g],
  ['equation number', /\(\s*\d+(?:\.\d+)?\s*\)(?:\s*[–-]\s*\(\s*\d+(?:\.\d+)?\s*\))?/g],
  ['digits under ^ or _', /[\^_]\s*(?:\{[^{}]*\}|\([^()]*\)|[−-]?[\p{L}\d.]+)/gu],
];
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹', SUB = '₀₁₂₃₄₅₆₇₈₉';
const scriptsToAscii = s => s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+|[₀₁₂₃₄₅₆₇₈₉]+/g, m => ' ' + [...m].map(ch => (SUP.includes(ch) ? SUP.indexOf(ch) : SUB.indexOf(ch))).join('') + ' ');
export function stripIdentifiers(text) {
  let t = text;
  for (const [, re] of IDENTIFIERS) t = t.replace(re, ' ');
  return t;
}
const NUMBER = /(?<![\d.])\d+(?:\.\d+)?(?:e[-−+]?\d+)?(?![\d])/g;
const normNum = s => s.replace('−', '-').replace(/^0+(?=\d)/, '');
const isInt = s => /^\d+$/.test(s);
// LaTeX shorthand fractions (\tfrac12, \frac34, \dfrac12) are two one-digit numbers, not one two-digit number: read them as "1/2"
const FRAC_SHORT = /\\[dt]?frac\s*(\d)\s*(\d)/g;
export function numbersOf(text) { return [...String(text).replace(FRAC_SHORT, ' $1/$2 ').matchAll(NUMBER)].map(m => normNum(m[0])); }
/** the numbers of a research text that a translation keeps: integers ≥ 2 and every decimal or scientific number, outside identifiers */
export function requiredNumbers(research) {
  const out = new Set();
  for (const n of numbersOf(stripIdentifiers(research))) if (!isInt(n) || Number(n) >= 2) out.add(isInt(n) ? String(Number(n)) : n);
  return [...out].sort((a, b) => (isInt(a) && isInt(b) ? Number(a) - Number(b) : isInt(a) ? -1 : isInt(b) ? 1 : a < b ? -1 : 1));
}
const WORDS = {
  two: 2, three: 3, four: 4, five: 5, six: 6, seven: 7, eight: 8, nine: 9, ten: 10, eleven: 11, twelve: 12, thirteen: 13, fourteen: 14, fifteen: 15,
  sixteen: 16, seventeen: 17, eighteen: 18, nineteen: 19, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90,
  hundred: 100, thousand: 1000, second: 2, third: 3, fourth: 4, fifth: 5, sixth: 6, seventh: 7, eighth: 8, ninth: 9, tenth: 10, eleventh: 11, twelfth: 12,
  twentieth: 20, half: 2, halves: 2, halved: 2, twice: 2, double: 2, doubled: 2, doubles: 2, thrice: 3, triple: 3, quarter: 4, quarters: 4,
};
/** the numbers a learner text states: digits outside identifiers, and number words (twenty-four counts as 24) */
export function numbersIn(body) {
  const set = new Set(numbersOf(stripIdentifiers(body)).map(n => (isInt(n) ? String(Number(n)) : n)));
  const words = String(body).toLowerCase().match(/[a-z]+(?:-[a-z]+)?/g) || [];
  for (const w of words) {
    if (WORDS[w] != null) set.add(String(WORDS[w]));
    const [a, b] = w.split('-');
    if (b && WORDS[a] != null && WORDS[b] != null && WORDS[a] >= 20 && WORDS[a] % 10 === 0 && WORDS[b] < 10) set.add(String(WORDS[a] + WORDS[b]));
    if (b && WORDS[a] != null && WORDS[b] != null) { set.add(String(WORDS[a])); set.add(String(WORDS[b])); }
  }
  return set;
}
const missingNumbers = (research, body) => { const have = numbersIn(body); return requiredNumbers(research).filter(n => !have.has(n)); };
function newNumbers(research, body) {
  const allowed = new Set(numbersOf(scriptsToAscii(research)).map(n => (isInt(n) ? String(Number(n)) : n)));
  return [...new Set(numbersOf(stripIdentifiers(body)).map(n => (isInt(n) ? String(Number(n)) : n)))].filter(n => n !== '0' && n !== '1' && !allowed.has(n));
}

// ---------------------------------------------------------------------------------------------------------------------------- R8 status and scope words
// [name, what in the research text calls for it, what in the learner text answers it]
export const STATUS = [
  ['open', /\bopen\b/i, /\bopen\b/i],
  ['input', /\binputs?\b/i, /\binputs?\b/i],
  ['checked', /\bchecked\b/i, /\bcheck(ed|s|ing)?\b/i],
  ['conjecture', /\bconjectur/i, /\bconjectur/i],
  ['ours', /\bours\b|\bour (reading|interpretation|name|naming|phrase|translation|work|idea|choice)s?\b|\bof ours\b/i, /\bours\b|\bour (own )?(reading|interpretation|name|naming|phrase|translation|work|idea|way|choice|proposal|guess)s?\b/i],
  ['not proved', /\bnot (yet )?prov(ed|en)\b|\bunproved\b/i, /\bnot (yet )?prov(ed|en)\b|\bunproved\b/i],
  ['textbook / standard', /\btextbook\b|\bstandard\b/i, /\btextbook\b|\bstandard\b|\bwell[- ]known\b/i],
  ['exact', /\bexact(ly)?\b/i, /\bexact(ly)?\b/i],
  ['at points', /\bat (the )?(checked |rational |random |numeric |sample )?points\b/i, /\bpoints?\b/i],
  ['floats', /\bfloats?\b|\bfloating[- ]point\b|\bnumerically\b|\bnumpy\b/i, /\bfloat|\bfloating[- ]point\b|\bnumeric|\bnumpy\b/i],
  ['cited', /\bcited\b/i, /\bcited\b|\bquoted\b/i],
  ['recalled', /\brecalled\b/i, /\brecalled\b|\bfrom memory\b/i],
  ['unread', /\bunread\b|\bnot read\b/i, /\bunread\b|\bnot (been )?read\b|\bhave not read\b/i],
  ['untested', /\buntested\b|\bnot tested\b/i, /\buntested\b|\bnot tested\b/i],
  ['not checked', /\bnot checked\b/i, /\bnot checked\b|\bunchecked\b/i],
  ['not claimed', /\bnot claimed\b/i, /\bnot claimed\b|\bdo(es)? not claim\b|\bno claim\b/i],
  ['not derived', /\bnot derived\b/i, /\bnot derived\b|\bnot worked out\b/i],
  ['by hand', /\bplain-text derivation\b|\bhand derivation\b|\bnot a machine-checked proof\b/i, /\bby hand\b|\bin plain text\b|\bnot (a )?machine-checked\b/i],
  ['regression', /\bregression\b/i, /\bregression\b|\bguard\b/i],
  ['for every n', /\bfor (every|all|any) n\b/i, /\b(every|all|any) (number|n)\b|\bany size\b|\bevery size\b/i],
];
const missingStatus = (research, body) => STATUS.filter(([, inR, inL]) => inR.test(research) && !inL.test(body)).map(([name]) => name);

// ---------------------------------------------------------------------------------------------------------------------------- R10 terms
const CONTEXT_BOUND = new Set(['form', 'vertex', 'mode']);
const esc = t => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const termRegexes = term => term.split(/\s*\/\s*/).map(v => v.trim()).filter(v => v.length >= 3).map(v => new RegExp(`(?<![\\p{L}\\p{N}])${esc(v)}(?![\\p{L}\\p{N}])`, 'iu'));
export const termOccurs = (term, body) => termRegexes(term).some(re => re.test(body));
/** the glossary terms a body uses: every term that occurs, the context-bound ones only when already listed */
export function termsIn(body, glossary, listed = []) {
  return glossary.map(g => g.term).filter(t => termOccurs(t, body) && (!CONTEXT_BOUND.has(t) || listed.includes(t)));
}

// ---------------------------------------------------------------------------------------------------------------------------- R12 names
const NAME_OK = new Set(['I', 'Cl', 'Standard', 'Model']); // the pronoun, the cell prefix, and "Standard Model", which names no authority
function newNames(body, sourceText) {
  const out = new Set();
  for (const m of body.matchAll(/(?<![\p{L}\p{N}’'])(\p{Lu}[\p{L}’'\-]*)/gu)) {
    const w = m[1].replace(/[’']s?$/, '').replace(/-$/, '');
    const before = body.slice(0, m.index).replace(/[\s“”"‘’()]+$/, '');
    if (!before || /[.!?:;]$/.test(before)) continue; // the first word of a sentence or of a clause after a colon
    if (NAME_OK.has(w) || w.length < 2) continue;
    const parts = w.split('-').filter(p => /^\p{Lu}/u.test(p));
    for (const p of parts) if (!new RegExp(`(?<![\\p{L}])${esc(p)}`, 'u').test(sourceText)) out.add(p);
  }
  return [...out];
}

// ---------------------------------------------------------------------------------------------------------------------------- R13 contact
const CONTACT = /\b[\w.+-]+@[\w-]+\.[\w.]+\b|https?:\/\/|www\.|\/home\/|\/tmp\/|\/opt\/|[A-Z]:\\|\.(py|mjs|jsx?|json|sh)\b/;

// ---------------------------------------------------------------------------------------------------------------------------- the tables
/**
 * The tables the checker reads: the rows, their research texts, the human learner texts, the glossary; with round 14 the chains overlay's rows and
 * research texts as if merged (a first merge of a new page needs them), the chain records of the owners' files (content/chains/*\/chains.json, or the
 * list `chains` a caller passes), the computed statuses (content/derived/status.json, else the build's rule) and the learner full texts (leads, C6).
 */
export function loadTables({ chains = null, content = C } = {}) {
  const rd = (f, fb) => (fs.existsSync(f) ? readJSON(f) : fb);
  const rows = rd(path.join(content, 'rows.json'), []);
  const texts = rd(path.join(content, 'texts.json'), []);
  const glossary = rd(path.join(content, 'glossary.json'), []);
  const backlog = rd(path.join(content, 'learner_backlog.json'), {});
  const dir = path.join(content, 'chains'), owners = fs.existsSync(dir) ? fs.readdirSync(dir).sort().filter(n => n !== 'learner' && fs.statSync(path.join(dir, n)).isDirectory()) : [];
  const ids = new Set(rows.map(r => r.id));
  for (const n of owners) {
    for (const r of rd(path.join(dir, n, 'rows.json'), [])) if (r && r.id && !ids.has(r.id)) { rows.push(r); ids.add(r.id); }
    for (const t of rd(path.join(dir, n, 'texts.json'), [])) if (t && t.row) texts.push({ lens: null, mode: 'both', register: 'full', ...t });
  }
  const chainList = chains || owners.flatMap(n => rd(path.join(dir, n, 'chains.json'), []));
  const rowById = new Map(rows.map(r => [r.id, r]));
  const research = new Map(), humanLearner = new Set(), humanText = new Map(), learnerFull = new Map();
  for (const t of texts) {
    const span = t.chain != null || t.register === 'span';
    if (span) continue;
    if (t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full' && !research.has(t.row)) research.set(t.row, t.body);
    if (t.level === 'learner' && t.lens == null && t.status === 'human') { humanLearner.add(t.row); if ((t.register || 'full') === 'full' && !humanText.has(t.row)) humanText.set(t.row, t); }
    if (t.level === 'learner' && t.lens == null && (t.register || 'full') === 'full' && (t.mode || 'both') === 'both') learnerFull.set(t.row, t);
  }
  const pageOf = new Map();
  for (const [grp, secs] of Object.entries(backlog)) for (const [sec, ids2] of Object.entries(secs)) for (const id of ids2) pageOf.set(id, { group: grp, section: sec });
  const XT = makeTables({ rows, pages: [], runs: rd(path.join(content, 'check_runs.json'), []), status: rd(path.join(content, 'derived', 'status.json'), {}) });
  return { rows, rowById, research, humanLearner, humanText, learnerFull, glossary, backlog, pageOf,
    chains: new Map(chainList.filter(c => c && typeof c.id === 'string').map(c => [c.id, c])), statusOf: id => statusOf(XT, id) };
}
export const SOURCE = 'translator:learner@2026-10-10';
/** the two derived fields of a record, from its body and its row's research text */
export function deriveFields(rec, T) {
  const research = T.research.get(rec.row) || '';
  return { termsUsed: termsIn(rec.body || '', T.glossary, rec.termsUsed || []), keptNumbers: requiredNumbers(research) };
}

// ---------------------------------------------------------------------------------------------------------------------------- the check
const KEYS = ['row', 'lang', 'mode', 'level', 'lens', 'register', 'body', 'status', 'source', 'termsUsed', 'keptNumbers'];
const SPAN_KEYS = [...KEYS, 'chain', 'span'];
export const RULES = {
  R1: 'shape', R2: 'row', R3: 'duplicate', R4: 'formula', R5: 'history', R6: 'numbers', R7: 'new number', R8: 'status',
  R9: 'length', R10: 'terms', R11: 'kept', R12: 'names', R13: 'contact',
  C1: 'chain', C2: 'coverage', C3: 'order', C4: 'connective', C5: 'status', C6: 'lead', C7: 'budget', C8: 'mention', C9: 'outside', C10: 'human', C11: 'twins',
};
export const STORYTELLER = /^storyteller@\d{4}-\d{2}-\d{2}$/;
/** a record of the storyteller's kind: a span (register span, or chain or span among its keys) */
export const isSpanRecord = r => !!r && (r.register === 'span' || 'chain' in r || 'span' in r);
/** the chain record and the position of a span, or nulls */
function spanPlace(r, T) {
  const c = T.chains && T.chains.get(r.chain), p = c && Number.isInteger(r.span) ? (c.rows || [])[r.span - 1] : null;
  return { c: c || null, p: p || null, mention: !!(c && p && (c.mention || []).includes(p)) };
}
export function check(records, T) {
  const fails = [];
  const F = (rule, row, msg) => fails.push({ rule, row, msg });
  if (!Array.isArray(records)) { F('R1', '—', 'the file is not an array'); return fails; }
  const glossaryTerms = new Set(T.glossary.map(g => g.term));
  const seen = new Map();
  for (const [i, r] of records.entries()) {
    const id = r && typeof r.row === 'string' ? r.row : `#${i}`;
    if (!r || typeof r !== 'object' || Array.isArray(r)) { F('R1', id, 'not an object'); continue; }
    const span = isSpanRecord(r), human = span && r.status === 'human';
    const keys = Object.keys(r), want = span ? SPAN_KEYS : KEYS;
    const missing = want.filter(k => !keys.includes(k)), extra = keys.filter(k => !want.includes(k));
    if (missing.length) F(span && (missing.includes('span') || missing.includes('chain')) ? 'C9' : 'R1', id, `missing key(s): ${missing.join(', ')}${span ? ' (a span has chain and span)' : ''}`);
    if (extra.length) F('R1', id, `unknown key(s): ${extra.join(', ')}`);
    if (r.lang !== 'en') F('R1', id, `lang is ${JSON.stringify(r.lang)}, not "en"`);
    if (span ? !['both', 'phys', 'math'].includes(r.mode) : r.mode !== 'both') F('R1', id, `mode is ${JSON.stringify(r.mode)}, not "both"${span ? ' (or a twin\'s mode)' : ''}`);
    if (r.level !== 'learner') F('R1', id, `level is ${JSON.stringify(r.level)}, not "learner"`);
    if (r.lens !== null) F('R1', id, `lens is ${JSON.stringify(r.lens)}, not null`);
    if (span ? r.register !== 'span' : r.register !== 'full' && r.register !== 'short') F('R1', id, `register is ${JSON.stringify(r.register)}, not ${span ? '"span"' : '"full" or "short"'}`);
    if (!(r.status === 'draft' || r.status === 'reviewed' || human)) F('R1', id, `status is ${JSON.stringify(r.status)}, not "draft" or "reviewed"${span ? ' (or "human": a row\'s own words, C10)' : ''}`);
    if (!human && (typeof r.source !== 'string' || !(span ? STORYTELLER.test(r.source) : /^translator:(learner|story)@/.test(r.source) || STORYTELLER.test(r.source)))) F('R1', id, `source is ${JSON.stringify(r.source)}, not ${span ? '"storyteller@<date>"' : '"translator:learner@…", "translator:story@…" or "storyteller@<date>"'}`);
    if (span && (typeof r.chain !== 'string' || !Number.isInteger(r.span) || r.span < 1)) F('R1', id, 'chain is a chain id and span a position number 1, 2, …');
    if (typeof r.body !== 'string' || !r.body.trim()) { F('R1', id, 'body is empty or not a string'); continue; }
    if (r.body !== r.body.trim() || /\s{2,}|\n/.test(r.body)) F('R1', id, 'body has leading, trailing, doubled or line-break whitespace');
    if (!Array.isArray(r.termsUsed) || r.termsUsed.some(x => typeof x !== 'string')) F('R1', id, 'termsUsed is not a list of strings');
    if (!Array.isArray(r.keptNumbers) || r.keptNumbers.some(x => typeof x !== 'string')) F('R1', id, 'keptNumbers is not a list of strings');
    const key = [r.row, r.mode, r.level, r.lens, r.register, span ? r.chain : ''].join('|');
    // R3 with D68 (round 16): a storyteller's learner text (source storyteller@…) may stand beside the translator's draft of the same key — it supersedes
    // it at the merge (tools/merge_story.mjs puts the storyteller's record last) and the draft retires at the release (merge_chains --retire); two
    // records of one kind (two drafts, two storyteller texts, two spans of one chain) are still a duplicate
    const kind = span ? 'span' : STORYTELLER.test(String(r.source || '')) ? 'storyteller' : 'translator';
    if (seen.has(key)) {
      const kinds = seen.get(key);
      if (kind === 'span' || kinds.has(kind) || kinds.has('span')) F('R3', id, `a second record with the same (row, mode, level, lens, register${span ? ', chain' : ''})`);
      kinds.add(kind);
    } else seen.set(key, new Set([kind]));
    const row = T.rowById.get(r.row);
    const research = T.research.get(r.row);
    if (!row) { F('R2', id, 'no such row in content/rows.json'); continue; }
    if (!research) { F('R2', id, 'the row has no research text (level research, lens null, mode both)'); continue; }
    if (!span && T.humanLearner.has(r.row) && (r.register || 'full') === 'full') F('R2', id, 'the row has a human learner text in texts.json: the merge keeps it, so this draft would never ship');
    if (human) continue;   // the author's words (C10): they are checked as verbatim, not translated
    const body = r.body;
    const mention = span && spanPlace(r, T).mention;
    for (const h of formulaHits(body)) F('R4', id, h);
    for (const h of historyHits(body)) F('R5', id, h);
    const isShort = r.register === 'short' || mention;
    const miss = isShort ? [] : missingNumbers(research, body);
    if (miss.length) F('R6', id, `number(s) of the research text missing: ${miss.join(', ')}`);
    const neu = newNumbers(research, body);
    if (neu.length) F(mention ? 'C8' : 'R7', id, `number(s) in digits that the research text does not have: ${neu.join(', ')}${mention ? ' (a mention says no new number)' : ''}`);
    const st = mention ? [] : missingStatus(research, body);   // a mention keeps its row's status word (C8 through C5), not every scope word
    if (st.length) F('R8', id, `status or scope word(s) of the research text missing: ${st.join(', ')}`);
    if (mention) { if (body.length < 20 || body.length > 300) F('C8', id, `${body.length} characters (a mention's span: 20 to 300)`); }
    else if (isShort) { if (body.length < 20 || body.length > 200) F('R9', id, `${body.length} characters (short register: 20 to 200)`); }
    else { const lim = Math.max(900, Math.ceil(1.5 * research.length)); if (body.length < 40 || body.length > lim) F('R9', id, `${body.length} characters (40 to ${lim}: 900, or 1.5 × the research text when that is longer)`); }
    if (Array.isArray(r.termsUsed)) {
      for (const t of r.termsUsed) {
        if (!glossaryTerms.has(t)) F('R10', id, `termsUsed has “${t}”, not a glossary term`);
        else if (!termOccurs(t, body)) F('R10', id, `termsUsed has “${t}”, which the body does not use`);
      }
      const want2 = termsIn(body, T.glossary, r.termsUsed);
      const unlisted = want2.filter(t => !r.termsUsed.includes(t));
      if (unlisted.length) F('R10', id, `glossary term(s) in the body but not in termsUsed: ${unlisted.join(', ')}`);
    }
    if (Array.isArray(r.keptNumbers)) {
      const want2 = requiredNumbers(research);
      const a = [...new Set(r.keptNumbers)].sort().join(' '), b = [...want2].sort().join(' ');
      if (a !== b || r.keptNumbers.length !== want2.length) F('R11', id, `keptNumbers is [${r.keptNumbers.join(', ')}], the research text asks for [${want2.join(', ')}]`);
    }
    const parent = row.splitFrom ? (T.research.get(row.splitFrom) || '') : '';
    const names = newNames(body, `${research}\n${parent}`);
    if (names.length) F('R12', id, `name(s) not in the research text: ${names.join(', ')}`);
    const c = body.match(CONTACT);
    if (c) F('R13', id, `contact detail, link, script name or path: “${c[0]}”`);
  }
  return fails;
}

// ---------------------------------------------------------------------------------------------------------------------------- C1–C11 the chains
/** C4: the opening words a span may use, by the relation of its link (a link with dir back takes the back set; an order link opens freely). "then" is
 *  not a derivation word (A62 ruling (ii), docs/round15/JUDGE_A62.md §2): a sequence word, it may open an order link */
export const CONNECTIVES = {
  derives: ['so', 'hence', 'thus', 'therefore', 'this means', 'it follows', 'from this', 'from the', 'because of this', 'as a result', 'which gives', 'which is why'],
  instance: ['for instance', 'for example', 'in one case', 'a case of this', 'take'],
  equiv: ['in other words', 'put another way', 'the same', 'that is', 'equally'],
  'uses-input': ['given', 'once we choose', 'if we choose', 'with the input', 'taking'],
  cycle: ['and back', 'in turn', 'closing the loop'],
  continues: ['and', 'also', 'more precisely', 'in the same statement'],
  contrasts: ['but', 'by contrast', 'on the other hand', 'yet', 'unlike'],
  back: ['this rests on', 'that needs', 'it comes from', 'behind this'],
};
/** C5: the learner words of the weak statuses, and what in a research text allows them on a proved row */
export const STATUS_WORDS = {
  ours: { words: 'our reading / ours', learner: /\bour (own )?reading\b|\bours\b/i, research: /\bours\b|\bour (reading|interpretation|name|naming|phrase|translation|work|idea|choice)s?\b|\bof ours\b/i },
  open: { words: 'open / not known yet / not settled', learner: /\bopen\b|\bnot known yet\b|\bnot settled\b/i, research: /\bopen\b|\bnot known\b|\bnot settled\b/i },
  cited: { words: 'not yet proved here', learner: /\bnot yet proved here\b/i, research: /\bnot (yet )?prov(ed|en)\b|\bcited\b/i },
  input: { words: 'input / needs an input / a choice', learner: /\binputs?\b|\bneeds an input\b|\ba choice\b/i, research: /\binputs?\b|\bchoices?\b|\bchoose\b/i },
};
const PROVED = new Set(['proved-by-atlas', 'standard']);
const opening = body => String(body).replace(/^[\s"“‘'(]+/, '').toLowerCase();
export const opensWith = (body, w) => { const b = opening(body); return b.startsWith(w) && !/[\p{L}\p{N}]/u.test(b.charAt(w.length) || ' '); };
/** the C4 set of a link: { allow: [words] | null (free), ban: [words] } */
export function linkWords(l) {
  if (!l) return { allow: null, ban: [] };
  if (l.dir === 'back') return { allow: CONNECTIVES.back, ban: [] };
  if (l.rel === 'order') return { allow: null, ban: [...CONNECTIVES.derives, ...CONNECTIVES.contrasts] };
  return { allow: CONNECTIVES[l.rel] || null, ban: [] };
}
/**
 * The chain rules on a list of learner records (spans, and learner texts of leads), with T's chain records (loadTables): a list of failures
 * { rule, row, msg }. `tb` is { testBlock, testRow } of tools/migrate/story_from_v15.mjs (C6); without it C6 checks the length and the numbers only.
 */
export function checkChains(records, T, tb = null) {
  const fails = [];
  const F = (rule, row, msg) => fails.push({ rule, row, msg });
  const spans = (Array.isArray(records) ? records : []).filter(r => r && isSpanRecord(r) && typeof r.chain === 'string' && Number.isInteger(r.span));
  const byChain = new Map();
  for (const r of spans) {
    const c = T.chains.get(r.chain);
    if (!c) { F('C1', r.row, `chain ${r.chain} is not a chain of the owners' files (content/chains/*/chains.json)`); continue; }
    const p = (c.rows || [])[r.span - 1], twins = c.twins || {};
    if (!p) { F('C1', r.row, `span ${r.span}: ${c.id} has ${(c.rows || []).length} positions`); continue; }
    const at = (c.rows || []).findIndex(x => x === r.row || twins[x] === r.row);
    if (at < 0) { F('C9', r.row, `a span for a row outside its chain ${c.id}`); continue; }
    if (r.row !== p && r.row !== twins[p]) { F('C3', r.row, `span ${r.span} of ${c.id} is position ${at + 1}'s row: the spans follow the positions`); continue; }
    if (!byChain.has(c.id)) byChain.set(c.id, []);
    byChain.get(c.id).push(r);
  }
  const leadText = id => (Array.isArray(records) ? records : []).find(r => r && r.row === id && !isSpanRecord(r) && r.register === 'full') || T.learnerFull.get(id) || null;
  const researchLen = id => (T.research.get(id) || '').length;
  for (const [cid, list] of byChain) {
    const c = T.chains.get(cid), twins = c.twins || {}, mention = new Set(c.mention || []);
    // C2, C3, C11: one span per position and per twin
    (c.rows || []).forEach((p, i) => {
      const mine = list.filter(r => r.span === i + 1 && r.row === p), tw = twins[p], theirs = tw ? list.filter(r => r.span === i + 1 && r.row === tw) : [];
      if (!mine.length) F('C2', p, `${cid}: no span ${i + 1} (a chain with one span has a span for every position)`);
      if (mine.length > 1) F('C3', p, `${cid}: ${mine.length} spans numbered ${i + 1}`);
      if (tw) {
        const mode = ((T.rowById.get(tw) || {}).visibleTo || [])[0];
        if (!theirs.length) F('C11', tw, `${cid}: the twin of position ${i + 1} has no span`);
        if (theirs.length > 1) F('C3', tw, `${cid}: ${theirs.length} spans of the twin numbered ${i + 1}`);
        for (const r of theirs) if (r.mode !== mode) F('C11', tw, `${cid}: the twin's span has mode ${r.mode}, its row's mode is ${mode}`);
      }
      for (const r of mine) if (r.mode !== 'both' && !((T.rowById.get(p) || {}).visibleTo || []).includes(r.mode)) F('C11', p, `${cid}: span ${i + 1} has mode ${r.mode}, a mode its row is not shown in`);
    });
    const lead = c.lead ? leadText(c.lead) : null;
    if (c.lead && !lead) F('C2', c.lead, `${cid}: the lead has no learner text (no partial story)`);
    for (const r of list) {
      const i = r.span - 1, p = c.rows[i], told = !mention.has(p), research = T.research.get(r.row) || '';
      const human = T.humanText.get(r.row);
      // C10: a told position with human words takes them verbatim
      if (told && human && (r.body !== human.body || r.status !== 'human' || r.source !== human.source)) { F('C10', r.row, `${cid}: the row has a human learner text: its span is that text verbatim (status human, source ${human.source})`); continue; }
      if (r.status === 'human') { if (!human || r.body !== human.body) F('C10', r.row, `${cid}: status human, but the body is not the row's human learner text`); continue; }
      // C4: the opening words of the link
      if (i >= 1) {
        const l = (c.links || [])[i - 1], { allow, ban } = linkWords(l);
        if (allow && !allow.some(w => opensWith(r.body, w))) F('C4', r.row, `${cid}: span ${r.span} (${l.rel}${l.dir === 'back' ? ', back' : ''}${l.from ? ' from ' + l.from : ''}) opens with “${r.body.split(/\s+/).slice(0, 3).join(' ')}”, not one of: ${allow.join(', ')}`);
        const b = ban.find(w => opensWith(r.body, w));
        if (b) F('C4', r.row, `${cid}: span ${r.span} opens with “${b}” on an order link: no unearned ${b === 'so' ? '"so"' : 'derivation or contrast'}`);
      }
      // C5: the status word at a weak link, none at a proved one
      const st = T.statusOf ? T.statusOf(r.row) : null;
      if (STATUS_WORDS[st] && !STATUS_WORDS[st].learner.test(r.body)) F(told ? 'C5' : 'C8', r.row, `${cid}: the row's status is ${st}: its span says ${STATUS_WORDS[st].words}`);
      if (PROVED.has(st)) for (const [k, w] of Object.entries(STATUS_WORDS)) if (w.learner.test(r.body) && !w.research.test(research)) F('C5', r.row, `${cid}: the row is ${st}, but its span says “${r.body.match(w.learner)[0]}” (${k}) and its research text does not`);
    }
    // C6: the lead
    if (lead) {
      const body = String(lead.body || '');
      if (body.length > 300) F('C6', c.lead, `${cid}: the lead's learner text has ${body.length} characters (at most 300)`);
      const allowed = new Set([...(c.rows || []), ...Object.values(twins)].flatMap(id => numbersOf(scriptsToAscii(T.research.get(id) || '')).map(n => (isInt(n) ? String(Number(n)) : n))));
      const own = [...new Set(numbersOf(stripIdentifiers(body)).map(n => (isInt(n) ? String(Number(n)) : n)))].filter(n => n !== '0' && n !== '1' && !allowed.has(n));
      if (own.length) F('C6', c.lead, `${cid}: the lead holds number(s) no position's research text holds: ${own.join(', ')}`);
      if (tb) {
        const pool = [...(c.rows || []), ...Object.values(twins)].filter(id => T.research.has(id)).map(id => tb.testRow(id, T.research.get(id), T.statusOf ? T.statusOf(id) : null));
        const res = tb.testBlock(body, { rows: pool });
        if (res.outcome !== 'story') F('C6', c.lead, `${cid}: the lead fails T1–T5 against the chain's rows: ${[...res.uncovered.map(u => `uncovered ${u}`), ...res.missingStatus.map(x => `status word missing for ${x}`)].join('; ') || res.signals.join(', ')}`);
      }
    }
    // C7: the budget of the whole story
    const story = list.reduce((n, r) => n + String(r.body || '').length, 0) + (lead ? String(lead.body || '').length : 0);
    const base = [...(c.rows || []), ...Object.values(twins)].reduce((n, id) => n + researchLen(id), 0);
    if (story > 0.8 * base) F('C7', cid, `the story has ${story} characters, more than 0.8 × the ${base} characters of its positions' research texts (${Math.floor(0.8 * base)})`);
  }
  return fails;
}
/** --explain <chain id>: the storyteller's worksheet (§7): per position the link, the words C4 allows, the status word C5 asks for, the numbers R6 asks for */
export function explainChain(id, T) {
  const c = T.chains.get(id);
  if (!c) return null;
  const twins = c.twins || {}, mention = new Set(c.mention || []), out = [];
  const base = [...(c.rows || []), ...Object.values(twins)].reduce((n, x) => n + (T.research.get(x) || '').length, 0);
  out.push(`${c.id} — “${(c.title || {}).learner || ''}” (physics: “${(c.title || {}).phys || ''}”) · ${c.page} · ${c.section} · ${c.shape} · ${(c.rows || []).length} positions${mention.size ? `, ${mention.size} mention(s)` : ''}`);
  out.push(`the story (lead and spans): at most ${Math.floor(0.8 * base)} characters, 0.8 × the ${base} of the research texts (C7)`);
  if (c.lead) out.push(`lead ${c.lead}: one sentence, at most 300 characters, no number of its own, every number and status word it uses from the rows below (C6)\n  research: ${T.research.get(c.lead) || '(no research text yet)'}`);
  else out.push('no lead: the story opens with span 1');
  (c.rows || []).forEach((p, i) => {
    const st = T.statusOf ? T.statusOf(p) : null, research = T.research.get(p) || '';
    const l = i ? (c.links || [])[i - 1] : null, { allow, ban } = linkWords(l);
    out.push(`${i + 1}. ${p}${mention.has(p) ? ' (a mention)' : ''} — status ${st || '?'}`);
    out.push(`   link: ${i === 0 ? 'the first span: it opens freely' : `${l.rel}${l.dir === 'back' ? ' (back: the earlier rests on this one)' : ''}${l.from ? ` from ${l.from}` : ''} — ${allow ? `open with one of: ${allow.join(', ')}` : `opens freely, never with: ${ban.join(', ')}`}${l.note ? ` (note: ${l.note})` : ''}`}`);
    out.push(`   status word (C5): ${STATUS_WORDS[st] ? STATUS_WORDS[st].words : PROVED.has(st) ? 'none (no status word unless the research text has it)' : 'none asked'}`);
    if (mention.has(p)) { const t = [...T.chains.values()].find(x => x !== c && x.page === c.page && toldOf(x).includes(p)); out.push(`   a mention: told in ${t ? t.id : '(no chain of the page)'}; one short sentence, 20 to 300 characters, no new number (C8)`); }
    else out.push(`   numbers to keep (R6): ${requiredNumbers(research).join(', ') || '(none)'}; scope words (R8): ${STATUS.filter(([, inR]) => inR.test(research)).map(([n]) => n).join(', ') || '(none)'}`);
    if (T.humanText.get(p) && !mention.has(p)) out.push(`   a human learner text: its words, verbatim, are the span (C10): “${T.humanText.get(p).body}”`);
    if (twins[p]) out.push(`   twin ${twins[p]} (mode ${((T.rowById.get(twins[p]) || {}).visibleTo || [])[0]}): its own span, number ${i + 1}, numbers ${requiredNumbers(T.research.get(twins[p]) || '').join(', ') || '(none)'} (C11)`);
    out.push(`   research: ${research}`);
  });
  return out.join('\n');
}

// ---------------------------------------------------------------------------------------------------------------------------- self-test
// A test of the test, run before every check: on a synthetic row (not the content, so an edit of the content cannot break it), one good
// record must pass every rule and one planted record per rule must be caught by that rule.
export function selftest() {
  const research = 'Checked exactly at points: the value 210 is open, and Cl(1,3) has 16 parts (step 4; core·B3); reading it as a mirror is ours.';
  const T = {
    rowById: new Map([['TST-001', { id: 'TST-001', splitFrom: null }], ['TST-002', { id: 'TST-002', splitFrom: null }]]),
    research: new Map([['TST-001', research], ['TST-002', research]]),
    humanLearner: new Set(['TST-002']),
    glossary: [{ term: 'mirror' }, { term: 'form' }],
  };
  const good = { row: 'TST-001', lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full',
    body: 'Checked exactly at points: the number 210 is open, and the cell Cl(1,3) has 16 parts. Reading it as a mirror is ours.',
    status: 'draft', source: SOURCE, termsUsed: ['mirror'], keptNumbers: ['16', '210'] };
  const plant = (rule, patch) => [rule, { ...good, ...patch }];
  const PLANTS = [
    plant('R1', { status: 'human' }),
    plant('R1', { source: 'translator:storyline@2026-10-12' }),
    plant('R2', { row: 'TST-404' }),
    plant('R2', { row: 'TST-002' }),
    plant('R4', { body: good.body.replace('16 parts', 'n parts, with $x$ as 16') }),
    plant('R4', { body: good.body.replace('the number 210', 'the number α, 210,') }),
    plant('R5', { body: good.body.replace('is open', 'is open; this was corrected') }),
    plant('R5', { body: good.body.replace('is open', 'is open since 9 October 2026') }),
    plant('R6', { body: good.body.replace('the number 210 ', 'that number ') }),
    plant('R7', { body: good.body.replace('16 parts', '16 parts and 999 more') }),
    plant('R8', { body: good.body.replace(' is open,', ',') }),
    plant('R9', { body: 'Checked exactly at points: 210, 16, open, ours.'.slice(0, 30) }),
    plant('R10', { termsUsed: ['mirror', 'flux'] }),
    plant('R10', { termsUsed: [] }),
    plant('R11', { keptNumbers: ['16'] }),
    plant('R12', { body: good.body.replace('Reading it as a mirror', 'Reading it, as Einstein did, as a mirror') }),
    plant('R13', { body: good.body.replace('16 parts.', '16 parts (see check_x.py).') }),
  ];
  const bad = [];
  const g = check([good], T);
  if (g.length) bad.push(`the good record fails: ${g.map(f => `${f.rule} ${f.msg}`).join('; ')}`);
  if (check([{ ...good, source: 'translator:story@2026-10-12' }], T).length) bad.push('the good record with the story source fails');
  for (const [rule, rec] of PLANTS) if (!check([rec], T).some(f => f.rule === rule)) bad.push(`a planted ${rule} (${RULES[rule]}) record is not caught`);
  if (!check([good, good], T).some(f => f.rule === 'R3')) bad.push('a planted R3 (duplicate) pair is not caught');
  // D68: a translator draft and a storyteller learner text of one key stand together (the storyteller's supersedes); two of one kind do not
  { const tr = { ...good, source: 'translator:learner@2026-10-12' }, st = { ...good, source: 'storyteller@2026-10-20' };
    if (check([tr, st], T).some(f => f.rule === 'R3')) bad.push('a translator draft beside a storyteller text of the same key is refused (D68)');
    if (!check([tr, { ...tr }], T).some(f => f.rule === 'R3')) bad.push('two translator drafts of one key are not caught');
    if (!check([st, { ...st }], T).some(f => f.rule === 'R3')) bad.push('two storyteller texts of one key are not caught'); }
  // the identifier "group, algebra or binomial" (round 16, found by T6a): a prose word before a space and a parenthesis is no group name, so the numbers
  // inside the parenthesis are required (R6) and credited (R7); a lowercase name with its parenthesis at once, or a capitalised name, strips it
  { const req = s => requiredNumbers(s).join(' ');
    if (req('the spin (a fit to 1e-6)') !== '1e-6') bad.push('the number inside "the spin (a fit to 1e-6)" is not required (a prose word read as a group name)');
    if (req('the same g (checked, m = 2, 3, 4)') !== '2 3 4') bad.push('the numbers inside "the same g (checked, m = 2, 3, 4)" are not required');
    if (req('so(3), spin(10) and Spin (10)') !== '') bad.push('a group name with its parenthesis (so(3), spin(10), Spin (10)) asks a number');
    const spanR6 = check([{ ...good, body: good.body.replace('16 parts.', '16 parts; the spin (a fit to 1e-6) is exact.') }], { ...T, research: new Map([['TST-001', research + ' The spin (a fit to 1e-6) is exact.']]) });
    if (spanR6.some(f => f.rule === 'R6' || f.rule === 'R7')) bad.push('a learner text that keeps the 1e-6 of "the spin (a fit to 1e-6)" fails R6 or R7'); }
  return bad;
}

// The chain self-test: a synthetic chain of six positions (a derivation, an order link at a reading, a mention, a twin, a row with human words)
// and its lead; its good story passes every rule, and one planted failure per C-rule is caught by that rule.
export function chainFixture() {
  const R = {
    'TST-101': 'The cell of two generators has 4 blades and 2 of them are even, checked exactly on the labels by the kernel.',
    'TST-102': 'Its even part squares to minus one on the 2 even blades, checked exactly, so the even part behaves as a complex unit.',
    'TST-103': 'Reading the even part of the two-generator cell as a turning in the plane is ours: a picture, not a computation.',
    'TST-105': 'The blade count doubles with each generator added to the cell, a fact used on many pages of the labels and on every rung of the ladder.',
    'TST-104': 'For three generators the blades pair up into 4 pairs, one even and one odd blade in each pair of the cell.',
    'TST-104b': 'In the cell Cl(3,0) the 8 blades split into 4 pairs of an even and an odd blade, as the grade parity shows.',
    'TST-106': 'The two-generator cell is the smallest cell whose even part is not just the numbers, a fact the owner states on the first page of the labels.',
    'TST-107': 'A row of the same page outside the chain.',
    'TST-701': 'How the blades of a small cell grow.',
  };
  const rows = Object.keys(R).map(id => ({ id, splitFrom: id === 'TST-104b' ? 'TST-104' : null, visibleTo: id === 'TST-104' ? ['phys'] : id === 'TST-104b' ? ['math'] : ['phys', 'math'], kind: id === 'TST-701' ? 'story' : 'lemma' }));
  const human = { row: 'TST-106', lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: 'The cell with two switches is the smallest one whose even part is more than plain numbers.', status: 'human', source: 'Test.jsx#human' };
  const status = { 'TST-103': 'ours' };
  const chain = { id: 'test.sec.a', page: 'test', section: 'sec', order: 1, title: { phys: 'A small cell', math: 'A small cell', learner: 'A small cell' }, lead: 'TST-701',
    rows: ['TST-101', 'TST-102', 'TST-103', 'TST-105', 'TST-104', 'TST-106'], mention: ['TST-105'], twins: { 'TST-104': 'TST-104b' }, joins: [],
    links: [{ rel: 'derives' }, { rel: 'order' }, { rel: 'derives', from: 'TST-101' }, { rel: 'instance' }, { rel: 'order' }], shape: 'fork', story: 'none' };
  const T = { rowById: new Map(rows.map(r => [r.id, r])), research: new Map(Object.entries(R)), humanLearner: new Set(['TST-106']), humanText: new Map([['TST-106', human]]),
    learnerFull: new Map(), glossary: [], chains: new Map([[chain.id, chain]]), statusOf: id => status[id] || (id === 'TST-701' ? 'meta' : 'proved-by-atlas') };
  const S = (row, span, body, extra = {}) => ({ row, lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'span', chain: 'test.sec.a', span, body, status: 'draft', source: 'storyteller@2026-10-20', termsUsed: [], keptNumbers: requiredNumbers(R[row] || ''), ...extra });
  const good = [
    S('TST-101', 1, 'A cell with two switches has 4 blades and 2 of them are even, and this is checked exactly.'),
    S('TST-102', 2, 'So its even part squares to minus one on the 2 even blades, checked exactly: a complex unit.'),
    S('TST-103', 3, 'Seeing that even part as a turning in the plane is our reading, a picture.'),
    S('TST-105', 4, 'From the count of blades: each new switch doubles them.'),
    S('TST-104', 5, 'For instance, with three switches the blades pair up into 4 pairs, one even and one odd.'),
    S('TST-104b', 5, 'For instance, in the cell Cl(3,0) the 8 blades split into 4 pairs, even with odd.', { mode: 'math' }),
    { ...S('TST-106', 6, human.body), status: 'human', source: human.source, keptNumbers: [] },
    { row: 'TST-701', lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: 'How the blades of a small cell grow, and what we read into them.', status: 'draft', source: 'storyteller@2026-10-20', termsUsed: [], keptNumbers: [] },
  ];
  return { T, chain, good, S, human };
}
export function selftestChains(tb = null) {
  const { T, good, S } = chainFixture();
  const bad = [];
  const all = recs => [...check(recs, T), ...checkChains(recs, T, tb)];
  const g = all(good);
  if (g.length) bad.push(`the good chain fails: ${g.map(f => `${f.rule} ${f.row} ${f.msg}`).join('; ')}`);
  const swap = (i, rec) => good.map((r, k) => (k === i ? rec : r));
  const drop = i => good.filter((r, k) => k !== i);
  const PLANTS = [
    ['C1', 'a span of an unknown chain', swap(0, { ...good[0], chain: 'test.sec.zz' })],
    ['C2', 'a missing span', drop(2)],
    ['C3', 'two spans out of order', swap(0, { ...good[0], span: 2 })],
    ['C4', 'an unearned "So" on an order link', swap(2, { ...good[2], body: 'So seeing that even part as a turning in the plane is our reading, a picture.' })],
    ['C4', 'a "Then" on a derives link (a sequence word, A62 ruling (ii))', swap(1, { ...good[1], body: 'Then its even part squares to minus one on the 2 even blades, checked exactly: a complex unit.' })],
    ['C5', '"our reading" dropped at a reading', swap(2, { ...good[2], body: 'Seeing that even part as a turning in the plane is a picture we like to draw.' })],
    ['C6', 'a lead with a number of its own', swap(7, { ...good[7], body: 'How the 5 blades of a small cell grow, and what we read into them.' })],
    ['C7', 'a story over budget', swap(0, { ...good[0], body: good[0].body + ' ' + 'A cell with two switches has 4 blades and 2 of them are even, and this is checked exactly.'.repeat(5).replace(/\.A/g, '. A') })],
    ['C8', 'a mention with a new number', swap(3, { ...good[3], body: 'From the count of blades: each new switch doubles them, 16 for four.' })],
    ['C9', 'a span for a row outside the chain', [...good, S('TST-107', 3, 'Seeing a row outside the chain, which this story does not tell.')]],
    ['C9', 'a learner record with chain and without span', [...good.slice(0, 7).map((r, k) => (k === 1 ? (({ span, ...x }) => x)(r) : r)), good[7]]],
    ['C10', 'a human text paraphrased', swap(6, S('TST-106', 6, 'The cell with two switches is the smallest whose even part is more than numbers.'))],
    ['C11', 'a twin without its span', drop(5)],
    ['C11', 'a twin span in the wrong mode', swap(5, { ...good[5], mode: 'both' })],
  ];
  for (const [rule, what, recs] of PLANTS) if (!all(recs).some(f => f.rule === rule)) bad.push(`a planted ${rule} (${what}) is not caught`);
  // and the other side of A62 ruling (ii): an order link may open with "Then"
  const then = all(swap(2, { ...good[2], body: 'Then seeing that even part as a turning in the plane is our reading, a picture.' }));
  if (then.length) bad.push(`a "Then" on an order link fails: ${then.map(f => `${f.rule} ${f.msg}`).join('; ')}`);
  return bad;
}

// ---------------------------------------------------------------------------------------------------------------------------- main
async function main(argv) {
  const arg = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  let tb = null;
  try { const m = await import('./migrate/story_from_v15.mjs'); tb = { testBlock: m.testBlock, testRow: m.testRow }; } catch (e) { console.log(`check_learner_texts: the story test could not be loaded (${e.message}); C6 checks length and numbers only`); }
  const st = [...selftest(), ...selftestChains(tb)];
  if (st.length) { console.log(`check_learner_texts: SELF-TEST FAILED\n  ${st.join('\n  ')}`); return 2; }
  const chainsArg = arg('--chains');
  const T = loadTables(chainsArg ? { chains: readJSON(path.resolve(chainsArg)) } : {});
  const explain = arg('--explain');
  if (explain) {
    if (T.chains.has(explain)) { console.log(explainChain(explain, T)); return 0; }
    const research = T.research.get(explain);
    if (!research) { console.log(`${explain}: no research text${explain.includes('.') ? ', and no chain of that id in the owners\' files' : ''}`); return 1; }
    console.log(`${explain} research text (${research.length} characters):\n  ${research}\n`);
    console.log(`numbers to keep: ${requiredNumbers(research).join(', ') || '(none)'}`);
    console.log(`status and scope words to keep: ${STATUS.filter(([, inR]) => inR.test(research)).map(([n]) => n).join(', ') || '(none)'}`);
    console.log(`identifiers whose numbers are not required: ${IDENTIFIERS.flatMap(([name, re]) => (research.match(re) || []).map(m => `${m.trim()} (${name})`)).join('; ') || '(none)'}`);
    return 0;
  }
  // --file <one file>; by default every content/texts_learner*.json and content/chains/learner/*.json (sorted), checked together so that R3 catches a
  // row drafted twice
  const LD = path.join(C, 'chains', 'learner');
  const files = arg('--file') ? [path.resolve(arg('--file'))] : [
    ...fs.readdirSync(C).filter(n => /^texts_learner.*\.json$/.test(n)).sort().map(n => path.join(C, n)),
    ...(fs.existsSync(LD) ? fs.readdirSync(LD).filter(n => n.endsWith('.json')).sort().map(n => path.join(LD, n)) : []),
  ];
  if (!files.length || files.some(f => !fs.existsSync(f))) { console.log(`check_learner_texts: no content/texts_learner*.json file`); return 1; }
  const file = files.length === 1 ? path.relative(ROOT, files[0]) : `content/texts_learner*.json${fs.existsSync(LD) && fs.readdirSync(LD).some(n => n.endsWith('.json')) ? ' and content/chains/learner/*.json' : ''}`;
  let records = [];
  for (const f of files) {
    let recs = readJSON(f);
    if (argv.includes('--fix') && Array.isArray(recs)) {
      recs = recs.map(r => ({ ...r, ...deriveFields(r, T) }));
      fs.writeFileSync(f, JSON.stringify(recs, null, 1) + '\n');
      console.log(`--fix: termsUsed and keptNumbers recomputed for ${recs.length} records in ${path.relative(ROOT, f)}`);
    }
    if (!Array.isArray(recs)) { console.log(`check_learner_texts: ${path.relative(ROOT, f)} is not an array`); return 1; }
    records = records.concat(recs);
  }
  const fails = [...check(records, T), ...checkChains(records, T, tb)];
  const n = Array.isArray(records) ? records.length : 0;
  const byPage = {};
  for (const r of Array.isArray(records) ? records : []) { const g = r && isSpanRecord(r) ? `spans of ${String(r.chain).split('.')[0]}` : (T.pageOf.get(r && r.row) || { group: '(not in the backlog)' }).group; byPage[g] = (byPage[g] || 0) + 1; }
  console.log(`check_learner_texts: ${n} records in ${file} (${Object.entries(byPage).map(([k, v]) => `${k} ${v}`).join(', ')})`);
  if (!fails.length) { console.log(`PASS: all ${Object.keys(RULES).length} rules hold for every record`); return 0; }
  const by = {};
  for (const f of fails) (by[f.rule] ||= []).push(f);
  console.log(`\nFAIL: ${fails.length} failure(s) in ${new Set(fails.map(f => f.row)).size} record(s)\n`);
  console.log('rule  name         failures  rows');
  for (const k of Object.keys(RULES)) if (by[k]) console.log(`${k.padEnd(5)} ${RULES[k].padEnd(12)} ${String(by[k].length).padStart(8)}  ${[...new Set(by[k].map(f => f.row))].slice(0, 8).join(', ')}${new Set(by[k].map(f => f.row)).size > 8 ? ', …' : ''}`);
  console.log('');
  for (const k of Object.keys(RULES)) for (const f of by[k] || []) console.log(`${f.rule} ${f.row}: ${f.msg}`);
  return 1;
}
// no top-level await: tools/migrate/story_from_v15.mjs and tools/merge_chains.mjs import this module
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main(process.argv.slice(2)).then(code => process.exit(code), e => { console.log(e && e.stack ? e.stack : e); process.exit(1); });
