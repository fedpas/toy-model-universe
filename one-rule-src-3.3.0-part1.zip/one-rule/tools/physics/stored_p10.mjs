#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p10.mjs — writes content/stored_p10.json (D34): the blocks of the stored results of the three Furey scripts that ran
// (furey_papers_check.py, threegen_selfcheck.py, dictionary_selfcheck.py) that the figures of owner P10 read, copied as they are; the key paths are
// engines/physics/furey.js STORED_PATHS. The table is loaded on demand (useTable('stored_p10')), not bundled.
// A40 (D49, owner Q1): the block `fr`, the board numbers of Furey's model as checks/run_all.py (with model.py) writes them into checks/furey_results.json —
// the ranks of the six real blocks of the 16-dimensional model and their diagonal and off-diagonal counts, which blocks commute with ω, the ranks of the
// five complex blocks and their counts — copied as they are, with the file and the script named; furey-board prints them under D29.
//   node tools/physics/stored_p10.mjs            write the table
//   node tools/physics/stored_p10.mjs --check    exit 1 when the table differs from the files
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { SOURCES, STORED_PATHS, partsOf } from '../../engines/physics/furey.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const OUT = path.join(ROOT, 'content', 'stored_p10.json');
const table = { sources: SOURCES };
for (const [key, src] of Object.entries(SOURCES)) table[key] = partsOf(JSON.parse(fs.readFileSync(path.join(ROOT, src.split(' ')[0]), 'utf8')), STORED_PATHS[key]);
const FR = { file: 'checks/furey_results.json', script: 'checks/run_all.py', keys: ['real_blocks', 'real_diag', 'real_off', 'blocks_commuting_with_omega', 'complex_blocks', 'complex_diag', 'complex_off'] };
{ const fr = JSON.parse(fs.readFileSync(path.join(ROOT, FR.file), 'utf8')); table.fr = { file: FR.file, script: FR.script, ...Object.fromEntries(FR.keys.map(k => [k, fr[k]])) }; }
const text = JSON.stringify(table, null, 1) + '\n';
if (process.argv.includes('--check')) {
  const same = fs.existsSync(OUT) && fs.readFileSync(OUT, 'utf8') === text;
  console.log(same ? 'stored_p10: content/stored_p10.json equals the stored files' : 'stored_p10: content/stored_p10.json differs from the stored files: run node tools/physics/stored_p10.mjs');
  process.exit(same ? 0 : 1);
}
fs.writeFileSync(OUT, text);
console.log(`stored_p10: ${Object.keys(SOURCES).map(k => `${k} ${STORED_PATHS[k].length} blocks`).join(', ')}, fr ${FR.keys.length} blocks → content/stored_p10.json (${(text.length / 1024).toFixed(1)} kB)`);
