#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p9.mjs — the stored check data the figures of owner P9 read (decision D34): content/stored_p9.json, loaded on demand with
// useTable('stored_p9'), never bundled. Blocks are copied as they are from the files the check scripts wrote:
//   null.figs.f1 … f4   checks/selfcheck/null.json figs (null_selfcheck.py): the neck in null coordinates (f1), the rates along an ingoing photon (f2),
//                       Eq. (1) on three null surfaces (f3), the Kerr horizon and ergosurface in the meridian plane (f4);
//   spring              checks/selfcheck/spring.json (spring_selfcheck.py), whole: the oscillator, the cube n = 2 … 5, the series, the Clifford levels, the
//                       labels, the 22 rows and their summary.
// tests/physics/p9.test.mjs compares every block with its file. Usage: node tools/physics/stored_p9.mjs [--check]
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const J = f => JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8'));
export const SOURCES = { null: 'checks/selfcheck/null.json (null_selfcheck.py)', spring: 'checks/selfcheck/spring.json (spring_selfcheck.py)' };
export const NULL_FIGS = ['f1', 'f2', 'f3', 'f4'];

/** the table, built from the two files */
export function buildStored() {
  const nl = J('checks/selfcheck/null.json'), sr = J('checks/selfcheck/spring.json');
  return { sources: SOURCES, null: { figs: Object.fromEntries(NULL_FIGS.map(k => [k, nl.figs[k]])) }, spring: sr };
}

const OUT = path.join(ROOT, 'content', 'stored_p9.json');
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const text = JSON.stringify(buildStored(), null, 1);
  if (process.argv.includes('--check')) {
    const same = fs.existsSync(OUT) && fs.readFileSync(OUT, 'utf8') === text;
    console.log(same ? 'stored_p9: content/stored_p9.json equals the stored files' : 'stored_p9: content/stored_p9.json differs from the stored files (run node tools/physics/stored_p9.mjs)');
    process.exit(same ? 0 : 1);
  }
  fs.writeFileSync(OUT, text);
  const d = JSON.parse(text);
  console.log(`stored_p9: wrote content/stored_p9.json (${(text.length / 1024).toFixed(1)} kB): null figs ${NULL_FIGS.map(k => `${k} ${d.null.figs[k].length}`).join(', ')}; spring rows ${d.spring.rows.length}`);
}
