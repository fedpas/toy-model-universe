#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p4.mjs — the stored table of owner P4 (decision D34): the blocks of the checks' json that the figures charges and maxwell-ladders read,
// copied as they are into content/stored_p4.json, which the app loads on demand (useTable('stored_p4'); not bundled):
//   maxwell.charges   checks/selfcheck/maxwell.json (maxwell_selfcheck.py): the 14 checked rows of the force on a charge, their counts (exact, numeric), the
//                     numeric runs, the frame, the sign, the force tables of the three worlds;
//   dictionary.why8   checks/selfcheck/dictionary.json (dictionary_selfcheck.py): the minimal period 8 of the type table, with its companions.
// The ladders, the cells' algebra and symbol come through interface 23 (engines/maxwellPhysics.js), which bundles them already.
// tests/physics/p4.test.mjs checks that the table equals these blocks. Usage: node tools/physics/stored_p4.mjs [--check]   (--check: exit 1 if the table differs)
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const J = f => JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8'));
export const SOURCES = { maxwell: 'checks/selfcheck/maxwell.json', dictionary: 'checks/selfcheck/dictionary.json' };
/** the table, built from the checks' json */
export function buildStoredP4() {
  const mx = J(SOURCES.maxwell), dic = J(SOURCES.dictionary);
  return { owner: 'P4', decision: 'D34', maxwell: { file: SOURCES.maxwell, charges: mx.charges }, dictionary: { file: SOURCES.dictionary, why8: dic.why8 } };
}
const OUT = path.join(ROOT, 'content', 'stored_p4.json');
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const text = JSON.stringify(buildStoredP4(), null, 1) + '\n';
  if (process.argv.includes('--check')) {
    const same = fs.existsSync(OUT) && fs.readFileSync(OUT, 'utf8') === text;
    console.log(same ? 'stored_p4: content/stored_p4.json = the blocks of the checks' : 'stored_p4: content/stored_p4.json differs from the checks (run node tools/physics/stored_p4.mjs)');
    process.exit(same ? 0 : 1);
  }
  fs.writeFileSync(OUT, text);
  console.log(`stored_p4: wrote content/stored_p4.json (${text.length} bytes: maxwell.charges, dictionary.why8)`);
}
