#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p6.mjs — owner P6 (spin and forque; BUILD_CONTRACTS round 5 wave 3, D34, D35). Writes, from the checked output of
// checks/selfcheck/spin.json (spin_selfcheck.py), forque.json (forque_selfcheck.py) and forque_matrix.json (forque_matrix_check.py):
//   content/stored_p6.json          the blocks P6's figures read, copied as they are (spin: planar, pointors, theorem3, torus_algebra, hestenes, chirality,
//                                   free_waves, matrix; forque: the whole file; forque_matrix: the whole file), and a derived block: the lines of
//                                   the two translation matrices (left and right columns, status, thread) and the forque conventions as v15
//                                   printed them (its display replacements, ASCII_MATH below)
//   content/physics/rows.p6.json    one row per matrix line (D35): SPN-M01 … SPN-M30 (S01 … S30), FRQ-M00 … FRQ-M40 (F00 … F40, the same numbers),
//                                   kind "reading", evidence the check that verifies the line (a line that agrees exactly) or [] (a printed line
//                                   that differs, a line not checked: the status is then "ours"), placed as details of the matrix's section
//   content/physics/texts.p6.json   their research texts: the line's two columns joined by " ↔ " (status draft, source physics:P6)
// The lines are the author's words, ported verbatim from the stored rows: a formula in $…$ (KaTeX), the words of a line without a formula as stored.
// Spin: left = the paper's formula, the lecture's, or both (paper · lecture); a line with no formula of a source (not checked) shows the source's
// reference; the one line of ours alone (S12) shows "—". Right = the bit-rule formula; a line not checked shows its stored claim (as v15's column did).
// Forque: left = the paper's formula (a line not checked: the paper's words); right = the bit-rule formula (a line not checked: the note, as v15's
// column did, through v15's display replacements).
// The labels of a line (A44, decision D49: notions, stage, ptype, phenomena, fields, cells, depends, docs/LABELLING_SCHEME.md) are written by hand in
// content/physics/rows.p6.json; buildFromRepo keeps the labels of every line the file labels (a line with a stage), so that writing the file again changes
// only what the checks give (id, kind, evidence, placement, since); a line the file does not label gets the notions of its thread, as before.
// Usage: node tools/physics/stored_p6.mjs          write the three files
//        node tools/physics/stored_p6.mjs --check  compare the three files with what would be written; exit 1 if they differ
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const SOURCES = { spin: 'checks/selfcheck/spin.json', forque: 'checks/selfcheck/forque.json', forque_matrix: 'checks/selfcheck/forque_matrix.json' };
export const SPIN_BLOCKS = ['planar', 'pointors', 'theorem3', 'torus_algebra', 'hestenes', 'chirality', 'free_waves', 'matrix'];
export const JOIN = ' ↔ ';

// v15's display replacements of the stored ASCII mathematics (forqueRowsIt.js ASCII_MATH, English), the pairs that touch a string printed here:
// the notes of the lines not checked and the conventions. Each pair applies to at least one of them (tests/physics/p6.test.mjs).
export const ASCII_MATH = [
  ['B x I[B]', 'B × I[B]'], ['I[Bdot]', 'I[Ḃ]'],
  ['*O = eps, *(q I) = q, *E = -E I, *(eps e_k) = e_k I_d (F00); *^-1 is the inverse on masks', '⋆O = ε, ⋆(q I) = q, ⋆E = −E I, ⋆(ε e_k) = e_k I_d (F00); ⋆⁻¹ is the inverse on masks'],
  ['e0 = eps, eps^2 = 0', 'e₀ = ε, ε² = 0'], ['x . A = (x A - A^ x)/2;  A x B = (A B - B A)/2', 'x·A = (xA − Âx)/2;  A×B = (AB − BA)/2'],
  ['Hodge star: X (*X) = X X~_E I', 'Hodge star: X (⋆X) = X X̃_E I'], ['signed complement with (*B) ^ B = I', 'signed complement with (⋆B) ∧ B = I'],
  ['join A v B = *^-1(*A ^ *B); meet = ^', 'join A ∨ B = ⋆⁻¹(⋆A ∧ ⋆B); meet = ∧'], ['O = e1 ... ed,  I = eps O,  Q = O + q I', 'O = e1 ... ed,  I = ε O,  Q = O + q I'],
  ['plane p = n - delta eps; translation T = 1 - eps t/2; X -> M X M~', 'plane p = n − δ ε; translation T = 1 − ε t/2; X ↦ M X M̃'],
  ['motors exp(-B t/2); B_w = -2 Mdot M~; B_b = -2 M~ Mdot', 'motors exp(−B t/2); B_w = −2 Ṁ M̃; B_b = −2 M̃ Ṁ'],
  ['O = mask of bits 1..d; I = eps * O', 'O = mask of bits 1..d; I = ε·O'], ['their eps is minus the eps of [13]', 'their ε is minus the ε of [13]'], ['x . A is the left contraction', 'x·A is the left contraction'],
];
export const asciiMath = s => (typeof s === 'string' ? ASCII_MATH.reduce((t, [a, b]) => t.split(a).join(b), s) : s);

/** the stored status of a line as a key: ok (agrees exactly), note (the printed line differs), nc (not checked) */
export const statusKey = s => (s === 'not checked' ? 'nc' : s);
const math = t => `$${t}$`;
const has = t => typeof t === 'string' && t.trim() !== '';

/** a spin line (spin.json matrix.rows): { id, row, left, right, status, group, src } */
export function spinLine(r) {
  const P = r.paper || null, L = r.lecture || null, st = statusKey(r.status);
  const parts = [];
  if (P && has(P.tex)) parts.push(math(P.tex));
  if (L && has(L.tex)) parts.push(math(L.tex));
  let left = parts.join(' · ');
  if (!left) left = [P && P.ref, L && L.ref].filter(has).join(' · ') || '—';
  const right = st === 'nc' ? String(r.text || '') : math(r.ours);
  return { id: r.id, row: `SPN-M${r.id.slice(1)}`, left, right, status: st, group: r.thread, src: r.src };
}
/** a forque line (forque.json rows): { id, row, left, right, status } */
export function forqueLine(r) {
  const st = statusKey(r.status);
  const left = st === 'nc' ? String(r.paper || '') : math(r.paper);
  const right = st === 'nc' ? asciiMath(String(r.note || '')) : math(r.ours);
  return { id: r.id, row: `FRQ-M${r.id.slice(1)}`, left, right, status: st };
}

// the notions of a line (docs/labelling/SCHEME.md): spin by thread, forque by the part of the paper; src for a line of a source
const SPIN_NOTIONS = { reflect: ['lbl', 'sq', 'mir', 'biv'], labels: ['lbl', 'sgn', 'biv', 'mod'], unit: ['sq', 'biv', 'i-J'], spaces: ['grd', 'mod', 'biv', 'i-J'], pointor: ['grd', 'mir', 'mod', 'biv'], states: ['mod', 'i-J'] };
function forqueNotions(n, st) {
  if (st === 'nc') return ['dyn', 'src'];
  const base = n === 0 ? ['lbl', 'nul', 'mir', 'grd'] : n <= 10 ? ['lbl', 'nul', 'grd', 'biv'] : n <= 15 ? ['nul', 'mir', 'biv', 'dyn'] : n <= 23 ? ['nul', 'biv', 'dyn'] : n <= 27 ? ['nul', 'biv', 'dyn', 'i-act'] : ['nul', 'biv', 'dyn', 'sol', 'i-act'];
  return [...base, 'src'];
}
const SPIN_CHECK = { check: 'spin_selfcheck', script: 'selfcheck/spin_selfcheck.py', mode: 'ran' };
const FORQUE_CHECK = { check: 'forque_selfcheck', script: 'selfcheck/forque_selfcheck.py', mode: 'ran' };

/** everything the tool writes, from the three stored files */
export function build(sp, fq, fqm) {
  const spinLines = sp.matrix.rows.map(spinLine), forqueLines = fq.rows.map(forqueLine);
  const rows = [], texts = [];
  const add = (line, group, notions, evidence, page, section, order) => {
    rows.push({ id: line.row, group, kind: 'reading', notions, evidence, shownOn: [{ page, section, order, role: 'detail' }], since: 'v2.2' });
    texts.push({ row: line.row, lang: 'en', mode: 'both', level: 'research', lens: null, register: 'full', body: `${line.left}${JOIN}${line.right}`, status: 'draft', source: 'physics:P6' });
  };
  spinLines.forEach((l, i) => add(l, 'SPN', [...SPIN_NOTIONS[l.group], ...(l.src === 'ours' ? [] : ['src'])], l.status === 'ok' ? [{ ...SPIN_CHECK }] : [], 'steps/spin', 'eq-spin', 1000 + i));
  forqueLines.forEach((l, i) => add(l, 'FRQ', forqueNotions(Number(l.id.slice(1)), l.status), l.status === 'ok' ? [{ ...FORQUE_CHECK }] : [], 'steps/forque', 'eq-forque', 1000 + i));
  const stored = {
    about: 'P6 (spin, forque): blocks of checks/selfcheck/spin.json, forque.json and forque_matrix.json as they are; derived: the matrix lines (D35) and the forque conventions as printed',
    sources: SOURCES,
    spin: Object.fromEntries(SPIN_BLOCKS.map(k => [k, sp[k]])),
    forque: fq,
    forque_matrix: fqm,
    derived: {
      spinLines, forqueLines,
      conventions: fq.conventions.map(c => ({ theirs: asciiMath(c.theirs), ours: asciiMath(c.ours), note: asciiMath(c.note) })),
    },
  };
  return { stored, rows, texts };
}

const read = rel => JSON.parse(fs.readFileSync(path.join(ROOT, rel), 'utf8'));
/** the label keys of a line, in the order the file writes them after its kind */
export const LABELS = ['notions', 'stage', 'ptype', 'phenomena', 'fields', 'cells', 'depends'];
/** the rows built from the checks, each line the previous file labels (it has a stage) carrying those labels */
export function keepLabels(rows, prev) {
  const byId = new Map((Array.isArray(prev) ? prev : []).map(r => [r.id, r]));
  return rows.map(r => {
    const p = byId.get(r.id);
    if (!p || p.stage == null) return r;
    return { id: r.id, group: r.group, kind: r.kind, ...Object.fromEntries(LABELS.filter(k => k in p).map(k => [k, p[k]])), evidence: r.evidence, shownOn: r.shownOn, since: r.since };
  });
}
export const OUT = { stored: 'content/stored_p6.json', rows: 'content/physics/rows.p6.json', texts: 'content/physics/texts.p6.json' };
export function buildFromRepo() {
  const out = build(read(SOURCES.spin), read(SOURCES.forque), read(SOURCES.forque_matrix));
  return { ...out, rows: keepLabels(out.rows, fs.existsSync(path.join(ROOT, OUT.rows)) ? read(OUT.rows) : null) };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const out = buildFromRepo();
  const files = [[OUT.stored, out.stored], [OUT.rows, out.rows], [OUT.texts, out.texts]];
  if (process.argv.includes('--check')) {
    const off = files.filter(([rel, data]) => !fs.existsSync(path.join(ROOT, rel)) || fs.readFileSync(path.join(ROOT, rel), 'utf8') !== JSON.stringify(data, null, 1));
    console.log(off.length ? `stored_p6: differs: ${off.map(f => f[0]).join(', ')}` : 'stored_p6: the three files are up to date');
    process.exit(off.length ? 1 : 0);
  }
  for (const [rel, data] of files) fs.writeFileSync(path.join(ROOT, rel), JSON.stringify(data, null, 1));
  console.log(`stored_p6: ${out.rows.length} rows (spin ${out.stored.derived.spinLines.length}, forque ${out.stored.derived.forqueLines.length}), ${out.texts.length} texts; ${OUT.stored} ${(JSON.stringify(out.stored, null, 1).length / 1024).toFixed(1)} kB`);
}
