#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p5.mjs — the stored check data of steps 2 and 4 that the figures comm-ladder and dirac-pic read (decision D34: a content table,
// loaded on demand with loadTable('stored_p5'), not bundled). The blocks are copied as they are from checks/selfcheck/:
//   commutators   equations.json commutators (by_n: n = 2 … 8; roles: every signature p + q = n <= 6)
//   dirac         equations.json dirac (counts, covariance, dispersion, solution_space, incidences, even_blades, odd_blades, J_mask)
//   status        equations.json status (checked, standard, ours, open)
//   dirac_matrix  dirac_matrix.json (the numpy cross-check with 4 × 4 gamma matrices)
//   free_waves    spin.json free_waves (the plane waves at ±E and one point off the shell)
// tests/physics/p5.test.mjs asserts that every block equals its file.
//   node tools/physics/stored_p5.mjs            write content/stored_p5.json
//   node tools/physics/stored_p5.mjs --check    exit 1 when content/stored_p5.json differs from what it would write
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const J = f => JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8'));
export const SOURCES = { commutators: ['checks/selfcheck/equations.json', 'commutators'], dirac: ['checks/selfcheck/equations.json', 'dirac'], status: ['checks/selfcheck/equations.json', 'status'], dirac_matrix: ['checks/selfcheck/dirac_matrix.json', null], free_waves: ['checks/selfcheck/spin.json', 'free_waves'] };
export function build() {
  const out = { sources: Object.fromEntries(Object.entries(SOURCES).map(([k, [f, key]]) => [k, key ? `${f} ${key}` : f])) };
  for (const [k, [f, key]] of Object.entries(SOURCES)) out[k] = key ? J(f)[key] : J(f);
  return out;
}
const OUT = path.join(ROOT, 'content', 'stored_p5.json');
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const text = JSON.stringify(build(), null, 1) + '\n';
  if (process.argv.includes('--check')) {
    const same = fs.existsSync(OUT) && fs.readFileSync(OUT, 'utf8') === text;
    console.log(same ? 'stored_p5: content/stored_p5.json is up to date' : 'stored_p5: content/stored_p5.json differs; run node tools/physics/stored_p5.mjs');
    process.exit(same ? 0 : 1);
  }
  fs.writeFileSync(OUT, text);
  console.log(`stored_p5: wrote content/stored_p5.json (${(text.length / 1024).toFixed(1)} kB: ${Object.keys(SOURCES).join(', ')})`);
}
