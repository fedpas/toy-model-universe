#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p8.mjs — the content table content/stored_p8.json (decision D34): the blocks of the gravity and projective checks that the figures of
// steps 9–12 print (curvature-pairs, einstein-terms, cosmological-generator, null-pair-moves), copied as they are from the files the scripts wrote:
//   gv  ← checks/selfcheck/gravity.json (gravity_selfcheck.py): ladder, curvature_space, desitter, einstein_identities, einstein_tensor_ratio
//   gvm ← checks/selfcheck/gravity_matrix.json (gravity_matrix_check.py, numpy): the whole file
//   pj  ← checks/selfcheck/projective.json (projective_selfcheck.py): counts, conformal, null_pair, motors, pga, doubling, contraction
// Nothing is computed or edited here; tests/physics/p8.test.mjs compares every block with its file. The figures load the table on demand (useTable), so the
// blocks are not in the bundle. Run after a check is run again: node tools/physics/stored_p8.mjs
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const J = f => JSON.parse(fs.readFileSync(path.join(ROOT, f), 'utf8'));
/** what the table holds: block → [file, script, keys (null: the whole file)] */
export const PLAN = {
  gv: ['checks/selfcheck/gravity.json', 'gravity_selfcheck.py', ['ladder', 'curvature_space', 'desitter', 'einstein_identities', 'einstein_tensor_ratio']],
  gvm: ['checks/selfcheck/gravity_matrix.json', 'gravity_matrix_check.py', null],
  pj: ['checks/selfcheck/projective.json', 'projective_selfcheck.py', ['counts', 'conformal', 'null_pair', 'motors', 'pga', 'doubling', 'contraction']],
};
export function build() {
  const out = { sources: {} };
  for (const [b, [file, script, keys]] of Object.entries(PLAN)) {
    const whole = J(file);
    out.sources[b] = `${file} (${script})`;
    out[b] = keys ? Object.fromEntries(keys.map(k => { if (!(k in whole)) throw new Error(`${file} has no block ${k}`); return [k, whole[k]]; })) : whole;
  }
  return out;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const t = build(), f = path.join(ROOT, 'content', 'stored_p8.json');
  fs.writeFileSync(f, JSON.stringify(t, null, 1) + '\n');
  console.log(`stored_p8: ${Object.keys(PLAN).map(b => `${b} (${Object.keys(t[b]).length} blocks)`).join(', ')} → content/stored_p8.json, ${fs.statSync(f).size} bytes`);
}
