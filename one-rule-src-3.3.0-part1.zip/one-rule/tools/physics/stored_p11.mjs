#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p11.mjs — owner P11 (step 16, the rigid body). Writes content/stored_p11.json (D34): the blocks of checks/selfcheck/pgadyn.json the figures
// rigid-segment, rigid-square, rigid-frame-table and rigid-matrix read, copied as they are (segment, square, frame_table, bit_labels, labels, top, summary, rows).
// With --rows <folder of the author's v15 package> it first (re)writes content/physics/rows.p11.json and texts.p11.json, the 56 lines of the rigid body's matrix
// as rows RIG-M01 … RIG-M56 in the order of the v15 page (D35: kind reading, research text "<claim> ↔ <how it is checked>", the author's words of rigidRows.js
// verbatim, status draft, source physics:P11), with the labelling below (notions, stage, type, fields, cells, relations: docs/04_LABELLING.md). With --check it
// writes nothing and exits 1 when a file differs from what it would write.
//   node tools/physics/stored_p11.mjs [--rows <v15 folder>] [--check]
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL, fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const C = path.join(ROOT, 'content'), P = path.join(C, 'physics');
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const argv = process.argv.slice(2), CHECK = argv.includes('--check'), ROWS_FROM = argv.includes('--rows') ? argv[argv.indexOf('--rows') + 1] : null;
let differs = 0;
const write = (f, data) => {
  const text = JSON.stringify(data, null, 1) + '\n';
  if (CHECK) { if (!fs.existsSync(f) || fs.readFileSync(f, 'utf8') !== text) { differs++; console.log(`differs: ${path.relative(ROOT, f)}`); } return; }
  fs.writeFileSync(f, text); console.log(`wrote ${path.relative(ROOT, f)}`);
};
const PG = J(path.join(ROOT, 'checks/selfcheck/pgadyn.json'));
// the order of the v15 page (rigidCopy.js rowIds): by letter, then by number
const nat = id => id.charCodeAt(0) * 100 + Number(id.slice(1));
const IDS = PG.rows.map(r => r.id).sort((a, b) => nat(a) - nat(b));
const rowOf = id => `RIG-M${String(IDS.indexOf(id) + 1).padStart(2, '0')}`;
export const JOIN = ' ↔ ';

// ---------------------------------------------------------------- the labelling of the 56 lines (docs/04_LABELLING.md; kind "reading" by D35)
// id: [notions, stage, fields, cells as n of R(n,0,1) ("1-5", "2,3", "" for none)]
const LAB = {
  A1: ['lbl grd nul biv', 'A', 'algebra combinatorics', '1-5'], A2: ['lbl grd nul biv', 'A', 'algebra', '1-4'], A3: ['lbl grd nul biv', 'A', 'algebra combinatorics', '3'],
  A4: ['grd mir nul biv', 'A', 'algebra', '1-4'], A5: ['lbl grd mir nul biv src', 'A', 'algebra', '3'], A6: ['nul biv src', 'K', 'geometry', '1-4'],
  A7: ['lbl grd nul biv s-alg', 'K', 'algebra combinatorics', '1-6'],
  B1: ['nul biv', 'K', 'algebra geometry', '1'], B2: ['nul biv sol dyn', 'D', 'analysis', '1'], B3: ['nul biv sol dyn i-act', 'D', 'analysis', '1'],
  B4: ['nul biv sol dyn i-act', 'D', 'analysis algebra', '1'],
  C1: ['biv sol dyn', 'D', 'analysis geometry', '2'],
  D1: ['nul biv dyn src', 'D', 'geometry', '3'], D2: ['nul biv dyn src i-act', 'D', 'geometry', '3'], D3: ['biv dyn src', 'D', 'geometry', '2-4'], D4: ['nul biv dyn src', 'D', 'geometry', '3'],
  E1: ['mir nul biv dyn', 'D', 'geometry', '1-4'], E2: ['nul biv dyn', 'D', 'geometry', '1-4'], E3: ['biv dyn', 'D', 'geometry', '1-4'], E4: ['nul biv dyn i-act', 'D', 'geometry', '1-4'],
  E5: ['nul biv dyn i-act', 'D', 'geometry', '1-4'], E6: ['nul biv sol dyn', 'D', 'analysis', '3-4'], E7: ['nul biv sol dyn i-act', 'D', 'analysis', '2-4'],
  E8: ['nul biv sol dyn i-act', 'D', 'analysis', '2-4'], E9: ['biv sol dyn', 'D', 'analysis geometry', '1-4'], E10: ['nul biv dyn i-act', 'D', 'geometry', '1-4'],
  E11: ['lbl nul biv dyn i-act', 'D', 'geometry combinatorics', '1-3'], E12: ['nul biv dyn i-act', 'D', 'geometry', '2-4'],
  F1: ['lbl biv dyn', 'D', 'geometry', '1-4'], F2: ['biv dyn', 'D', 'geometry', ''],
  G1: ['lbl nul biv dyn', 'K', 'combinatorics geometry', '1-4'], G2: ['lbl nul biv dyn', 'K', 'combinatorics geometry', '1-4'], G3: ['lbl nul biv dyn src', 'K', 'combinatorics geometry', '1-4'],
  G4: ['lbl lat', 'K', 'combinatorics geometry', '2-4'], G5: ['lbl grd nul biv dyn', 'K', 'combinatorics', '1-5'],
  N1: ['nul biv dyn i-act', 'D', 'geometry', '2,3'], N2: ['nul biv dyn i-act', 'D', 'geometry', '2-4'], N3: ['sol dyn i-act', 'D', 'analysis', '2'], N4: ['sol dyn i-act', 'D', 'analysis', '2'],
  N5: ['nul sol dyn i-act', 'D', 'analysis', '2'], N6: ['nul sol dyn', 'D', 'analysis', ''], N7: ['mir nul biv dyn', 'D', 'algebra', '2'], N8: ['sol dyn src i-act i-tab', 'O', 'analysis', '2'],
  N9: ['dyn src i-tab', 'O', 'geometry', '3'],
  R1: ['nul biv dyn src', 'O', 'geometry', '1-4'], R2: ['nul biv dyn src', 'O', 'geometry', '1-4'], R3: ['nul biv dyn src i-act', 'O', 'geometry', '1-4'], R4: ['nul biv dyn src i-act', 'O', 'geometry', '1-4'],
  R5: ['nul biv dyn src i-act', 'O', 'geometry', '1-4'], R6: ['nul biv dyn src', 'O', 'geometry', '1-4'], R7: ['biv dyn src', 'O', 'geometry', '3'], R8: ['biv dyn src', 'O', 'geometry', '3'],
  R9: ['nul dyn src i-act', 'O', 'geometry', '2,3'],
  T1: ['biv dyn', 'D', 'geometry', '3'], T2: ['biv dyn', 'D', 'geometry analysis', '3'], T3: ['biv dyn src', 'D', 'geometry', '3'],
};
// the physicist's type of each line (the kind stays "reading", D35): an exact identity, a conservation (symmetry), an exact series (solution), a comparison with a
// printed formula or a reference run (calibration), an observation stated and not judged (observable)
const PTYPE = Object.assign(Object.fromEntries(['E2', 'E3', 'N1'].map(id => [id, 'symmetry'])), Object.fromEntries(['B2', 'B3', 'B4', 'C1', 'E6', 'E7', 'E8', 'E9', 'N3', 'N4', 'N5'].map(id => [id, 'solution'])),
  Object.fromEntries(['D1', 'D2', 'D3', 'D4', 'R1', 'R2', 'R3', 'R4', 'R5', 'R6', 'R7', 'R9', 'N8', 'N9'].map(id => [id, 'calibration'])), { R8: 'observable' });
const NOTION_ORDER = ['lbl', 'sgn', 'sq', 'grd', 'qf', 'clk', 'mir', 'nul', 'tns', 'mod', 'biv', 'cnx', 'var', 'sol', 'lat', 'fin', 'div', 'dyn', 's-alg', 's-geo', 's-phy', 's-cat', 'src', 'i-chart', 'i-time', 'i-J', 'i-act', 'i-tab', 'i-meta'];
const cellsOf = spec => {
  if (!spec) return [];
  const ns = spec.includes('-') ? (([a, b]) => Array.from({ length: b - a + 1 }, (_, i) => a + i))(spec.split('-').map(Number)) : spec.split(',').map(Number);
  return ns.map(n => `(${n},0,1)`);
};
const REF = { R1: 'ganja.js 1.0.189, the library of the listings', R2: 'ganja.js 1.0.189', R3: 'ganja.js 1.0.189', R4: 'ganja.js 1.0.189', R5: 'ganja.js 1.0.189', R6: 'ganja.js 1.0.189',
  R7: 'the free-top example of the repository', R8: 'the free-top example of the repository', R9: 'the planets and moon examples of the repository', N8: 'the moon example of the repository',
  N9: 'the planets example of the repository; JPL Horizons vectors (g3_vectors_compare.py)', D3: 'the SIGGRAPH notes of the PGA dynamics' };

async function writeRows(folder) {
  const url = f => pathToFileURL(path.resolve(folder, f)).href;
  const { ROWS } = await import(url('rigidRows.js'));
  const { ROW_META } = await import(url('rigidCopy.js'));
  const missing = IDS.filter(id => !ROWS[id] || !ROW_META[id] || !LAB[id]);
  if (missing.length || Object.keys(ROWS).length !== IDS.length) { console.error(`stored_p11: the v15 rows and pgadyn.json disagree (${missing.join(', ') || Object.keys(ROWS).length + ' rows'})`); process.exit(1); }
  const rows = [], texts = [];
  for (const id of IDS) {
    const [claim, how] = ROWS[id].en, [thread, src] = ROW_META[id], [notions, stage, fields, cells] = LAB[id];
    if (claim.includes(JOIN) || how.includes(JOIN)) { console.error(`stored_p11: line ${id} contains the joiner`); process.exit(1); }
    const ns = notions.split(' ').sort((a, b) => NOTION_ORDER.indexOf(a) - NOTION_ORDER.indexOf(b));
    const depends = [{ id: 'EQN-019', rel: 'instance' }, { id: src === 'ours' ? 'RIG-003' : 'RIG-002', rel: 'instance' }];
    if (ns.includes('i-act')) depends.push({ id: 'INP-075', rel: 'uses-input' });
    if (ns.includes('mir')) depends.push({ id: 'INP-078', rel: 'uses-input' });
    if (id === 'N9') depends.push({ id: 'INP-076', rel: 'uses-input' });
    const gravity = /gravit|newton|kepler|planet|moon/i.test(claim);
    rows.push({
      id: rowOf(id), group: 'RIG', standardRef: REF[id] ? `Dorst–De Keninck; ${REF[id]}` : 'Dorst–De Keninck; textbook mechanics', links: [], lensTags: ns.includes('lbl') ? ['CUB', 'DYN'] : ['DYN'],
      review: null, notesPersona: [], phenomena: gravity ? ['mechanics', 'gravity'] : ['mechanics'], tabV15: 'rigid', anchorV15: `rg-row-${id}`, theorems: [], readingRefs: 0, v16: [],
      since: 'v2.2', legacyLabel: null, legacyFlags: [], legacyKnown: false, legacyLines: 0, splitFrom: null, visibleTo: ['phys', 'math'], labelFrom: null,
      evidence: [{ check: 'pgadyn_selfcheck', script: 'selfcheck/pgadyn_selfcheck.py', mode: 'ran' }],
      depends, notions: ns, kind: 'reading', stage, ptype: PTYPE[id] || 'identity', fields: fields.split(' '), cells: cellsOf(cells), homePhys: null, homeMath: null, shownOn: [],
    });
    texts.push({ row: rowOf(id), lang: 'en', mode: 'both', level: 'research', lens: null, register: 'full', body: claim + JOIN + how, status: 'draft', source: 'physics:P11' });
  }
  write(path.join(P, 'rows.p11.json'), rows);
  write(path.join(P, 'texts.p11.json'), texts);
}

if (ROWS_FROM) await writeRows(ROWS_FROM);
const pick = k => { if (!(k in PG)) { console.error(`stored_p11: pgadyn.json has no block ${k}`); process.exit(1); } return PG[k]; };
write(path.join(C, 'stored_p11.json'), {
  source: 'checks/selfcheck/pgadyn.json (pgadyn_selfcheck.py)',
  segment: pick('segment'), square: pick('square'), frame_table: pick('frame_table'), bit_labels: pick('bit_labels'), labels: pick('labels'), top: pick('top'),
  summary: pick('summary'), rows: pick('rows'),
});
if (CHECK) { console.log(differs ? `stored_p11: ${differs} file(s) differ` : 'stored_p11: every file is as written'); process.exit(differs ? 1 : 0); }
