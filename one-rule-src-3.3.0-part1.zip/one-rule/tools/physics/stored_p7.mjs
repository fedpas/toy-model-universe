#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/physics/stored_p7.mjs — the stored check data of steps 6–8 as a content table (decision D34): content/stored_p7.json, loaded by the figures of
// owner P7 with useTable('stored_p7') and never bundled. The blocks are copied as the scripts wrote them, from checks/selfcheck/:
//   cp  = coupling.json (ladder n = 1 … 8, identities n = 3, 4, 5, shell n = 3 … 7)         cpm = coupling_matrix.json (numpy, n = 3 … 7)
//   ym  = yangmills.json (ladder m = 2 … 8, spacetime, identities, maxwell_reduction, so4_split) ymm = yangmills_matrix.json (numpy, m = 2 … 6)
//   mt  = matter.json (ladder m = 2 … 8, spacetime n = 3 … 6, identities)                    mtm = matter_matrix.json (numpy, five (n, m) pairs)
// The prose lists `status` of the three exact scripts (which items are checked, standard, ours, open) are left out: no figure prints them (the rows do);
// every other block is the file's own. tests/physics/p7.test.mjs checks the table against the files block by block.
//   node tools/physics/stored_p7.mjs           write content/stored_p7.json
//   node tools/physics/stored_p7.mjs --check   exit 1 if the table differs from what the files give
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const SC = path.join(ROOT, 'checks', 'selfcheck'), OUT = path.join(ROOT, 'content', 'stored_p7.json');
export const SOURCES = { cp: 'coupling.json', cpm: 'coupling_matrix.json', ym: 'yangmills.json', ymm: 'yangmills_matrix.json', mt: 'matter.json', mtm: 'matter_matrix.json' };
/** the blocks left out of a file: the prose status lists of the exact scripts (the matrix files keep their one-line status) */
export const LEFT_OUT = { cp: ['status'], ym: ['status'], mt: ['status'], cpm: [], ymm: [], mtm: [] };
export function buildStored() {
  const out = { sources: SOURCES };
  for (const [key, file] of Object.entries(SOURCES)) {
    const data = JSON.parse(fs.readFileSync(path.join(SC, file), 'utf8'));
    out[key] = Object.fromEntries(Object.entries(data).filter(([k]) => !LEFT_OUT[key].includes(k)));
  }
  return out;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const data = buildStored(), text = JSON.stringify(data, null, 1) + '\n';
  if (process.argv.includes('--check')) {
    const now = fs.existsSync(OUT) ? fs.readFileSync(OUT, 'utf8') : '';
    if (now !== text) { console.error('stored_p7: content/stored_p7.json differs from checks/selfcheck (run node tools/physics/stored_p7.mjs)'); process.exit(1); }
    console.log('stored_p7: content/stored_p7.json = checks/selfcheck, block by block');
  } else {
    fs.writeFileSync(OUT, text);
    console.log(`stored_p7: wrote content/stored_p7.json (${Object.keys(SOURCES).map(k => `${k} ${Object.keys(data[k]).length} blocks`).join(', ')}; ${text.length} bytes)`);
  }
}
