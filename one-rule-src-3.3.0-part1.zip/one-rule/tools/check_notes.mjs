#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/check_notes.mjs — the checks of the notes to researchers (content/notes.json, a shipped table of kind view, docs/02_CONTENT_MODEL.md §8)
// and of the outreach drafts beside them (docs/round9/outreach/EMAILS_v4.md, not shipped), written with them (docs/round9/NOTES.md):
//   A shape      the file's title, line and about (about says that a note is a view of the Atlas and changes no row); keys unique and plain;
//                each note with to, work, lead, sections, question and thanks; earlier, when present, is { date, text: [paragraphs] }
//   B order      the sections of a note are, in this order, "What the Atlas said first", "Where the work and the Atlas met", "What the labels
//                add", "What the Atlas cannot reach" (the question follows as its own field); the notes another owner writes are named in OWNED
//   C rows       every row id exists in content/rows.json and has a research text; a note's rows are the union of its sections' rows (reported
//                only for the notes in OWNED)
//   D reading    every row a note cites belongs to the reading of that note's work: its standard reference or its research text names the work,
//                or it stands on the page that reads the work, or the file of the reading (a report, an analysis, the sources table) names
//                the row or the object the row computes (READING below: one entry per note, each link written out)
//   E pictures   every figure id exists in content/figures.json; every svg is "<course>/<file>.svg" and the file is on disk under
//                public/reports/tutorials/src/<course>/figs/
//   F links      a link's route is a page of content/pages.json, a lens room, or a route the router knows beyond them; an href is a file of public/
//   G words      no free string of the file (title, line, about, work, lead, head, text, question, thanks, label, the paragraphs of an earlier
//                letter) holds a run of 40 characters of any text record of content/texts.json, at any offset (stricter than the coverage test,
//                which compares windows taken every 40 characters)
//   H numbers    every run of digits in a paragraph of a section is shown by a card beside it: it occurs in the research text of a row of that section
//   I history    no banned history phrase in a free string of the file or in the e-mails: the families P1–P9 of tests/shipped.test.mjs (every date
//                banned here, not only the dates other than the content version), and the words the brief of the notes adds
//   J contact    no e-mail address, web address, telephone number or user path in content/notes.json, the e-mails or docs/round9/NOTES.md
//                (the licence comment, one line that names the licence's own page, is the Required Notice and is not read as a contact)
//   K e-mails    the licence comment and the line on the earlier letters at the top; one e-mail per note, under "## <key>"; a subject; at most 120
//                words; exactly one link <site>/#/notes/<key>; one picture that is a figure or an svg of the note; one question; no line that
//                says who wrote it (an AI, a model); no flattery; the e-mails held for the owner's judgement marked with one line each
// Usage: node tools/check_notes.mjs [--notes <file>] [--emails <file>] [--list]
// Exit 1 on a failure. Reads only; writes nothing.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const opt = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
const LIST = argv.includes('--list');
const C = path.join(ROOT, 'content');
const NOTES_FILE = path.resolve(ROOT, opt('--notes') || 'content/notes.json');
const EMAILS_FILE = path.resolve(ROOT, opt('--emails') || 'docs/round9/outreach/EMAILS_v4.md');
const NOTES_DOC = path.join(ROOT, 'docs', 'round9', 'NOTES.md');
const readText = f => fs.readFileSync(f, 'utf8');
const readJSON = f => JSON.parse(readText(f));
const rel = f => path.relative(ROOT, f).split(path.sep).join('/');
const clip = (s, n = 140) => { const t = String(s).replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };

let checks = 0, bad = 0;
const out = [];
const say = m => { out.push(m); console.log(m); };
const rule = (name, offenders, what) => {
  checks++;
  if (!offenders.length) { say(`ok   ${name}: ${what}`); return true; }
  bad++;
  say(`FAIL ${name}: ${what} — ${offenders.length} offender(s)`);
  for (const o of LIST ? offenders : offenders.slice(0, 30)) say(`     ${o}`);
  if (!LIST && offenders.length > 30) say(`     … ${offenders.length - 30} more (--list prints them all)`);
  return false;
};

// ------------------------------------------------------------------ the tables
const ROWS = readJSON(path.join(C, 'rows.json'));
const TEXTS = readJSON(path.join(C, 'texts.json'));
const FIGURES = readJSON(path.join(C, 'figures.json'));
const PAGES = readJSON(path.join(C, 'pages.json'));
const LENSES = readJSON(path.join(C, 'lenses.json'));
const STATUS = readJSON(path.join(C, 'derived', 'status.json'));
const rowById = new Map(ROWS.map(r => [r.id, r]));
const research = new Map();
for (const t of TEXTS) if (t.level === 'research' && (t.lens == null) && typeof t.body === 'string') research.set(t.row, (research.get(t.row) || '') + ' ' + t.body);
const figureIds = new Set(FIGURES.map(f => f.id));
const pageRoutes = new Set(PAGES.map(p => p.route));
const lensKeys = new Set(LENSES.map(l => l.key));
const EXTRA_ROUTES = new Set(['', 'notes', 'tutorials', 'agents', 'ask', 'glossary', 'logbook', 'lenses', 'cells', 'steps']);
const routeOk = r => pageRoutes.has(r) || EXTRA_ROUTES.has(r) || /^lenses\/[\w-]+$/.test(r) && lensKeys.has(r.split('/')[1]) || /^logbook\/[\w-]+$/.test(r) || /^cells\/\d+,\d+(,\d+)?$/.test(r) || /^notes\/[\w-]+$/.test(r);

const NOTES = readJSON(NOTES_FILE);
const notes = Array.isArray(NOTES.notes) ? NOTES.notes : [];
console.log(`check_notes: ${rel(NOTES_FILE)} (${notes.length} notes), ${rel(EMAILS_FILE)}; ${ROWS.length} rows, ${TEXTS.length} text records`);

// the notes another owner writes: the structure rules B and H are reported for them, not failed (their words are theirs)
const OWNED = new Set(['hitchin']);
const HEADS = ['What the Atlas said first', 'Where the work and the Atlas met', 'What the labels add', 'What the Atlas cannot reach'];

// ------------------------------------------------------------------ D: the reading of each note's work
// refs: names the work in the standard reference; text: names it in the research text; pages: the page that reads it;
// anchors: { row: [file, phrase] } — the reading's own file names the row or the object it computes (the phrase must occur in the file)
const A = (file, phrase) => [file, phrase];
const ATY = 'public/reports/analyses/src/atiyah_lens.md', SRC = 'content/sources.json';
const HL = 'public/reports/html/hestenes_ldg_report.html', PU = 'public/reports/html/pumplun_dictionary_report.html';
const BZ = 'public/reports/html/baez_atlas_report.html', FU = 'public/reports/html/furey_report.html';
const READING = {
  hitchin: { refs: /Hitchin|Atiyah|Bott|LeBrun|Segal|Sutcliffe|Moore|Manton/, text: /Atiyah|Hitchin/ },
  segal: { refs: /Segal/, text: /Atiyah and Segal|Atiyah–Segal/, anchors: { 'CAND-116': A(ATY, 'CAND-116'), 'LNC-117': A(ATY, 'LNC-117') } },
  moore: { refs: /Moore/, text: /Atiyah and Moore/, anchors: { 'EQN-008': A(ATY, 'EQN-008'), 'INP-049': A(ATY, 'INP-049'), 'NUL-001': A(ATY, 'NUL-001') } },
  sutcliffe: { refs: /Sutcliffe/, text: /Atiyah and Sutcliffe|Atiyah–Sutcliffe/, anchors: { 'CAND-124': A(ATY, 'CAND-124'), 'ATL-005': A(ATY, 'ATL-005'), 'CAND-139': A(ATY, 'CAND-139') } },
  manton: { refs: /Manton/, text: /Atiyah and Manton|Atiyah, Manton and Schroers/, anchors: { 'CAND-124': A(ATY, 'CAND-124'), 'ATL-005': A(ATY, 'ATL-005'), 'GOS-005': A(ATY, 'GOS-005'), 'LAB-017': A(ATY, 'LAB-017') } },
  schroers: { refs: /Schroers/, text: /Atiyah, Manton and Schroers/, anchors: { 'GOS-005': A(ATY, 'GOS-005'), 'LAB-017': A(ATY, 'LAB-017'), 'LNS-013d': A(ATY, 'LNS-013d'), 'ATY-017': A(ATY, 'Rows ATY-016 to ATY-019') } },
  lebrun: { refs: /LeBrun/, text: /Atiyah and LeBrun/, anchors: { 'RSN-032': A(ATY, 'RSN-032'), 'LNS-013': A(ATY, 'LNS-013'), 'GRV-010': A(ATY, 'GRV-010') } },
  'eastwood-norbury': { refs: /Eastwood|Norbury/, text: /Eastwood and Norbury/ },
  'lundholm-svensson': { refs: /Lundholm(–| and )Svensson, KTH notes(?! \(rev\. 2016\), Thm 5\.5 and Table 5\.1; Lawson)|Lundholm–Svensson (KTH notes \(sig|Sect|Prop)|Lundholm–Svensson, KTH notes, Def|D\. Lundholm, L\. Svensson/, text: /Lundholm|KTH notes/,
    anchors: { 'MAP-001': A(SRC, 'Def. 2.4; Lemma 2.6 proves associativity'), 'PAG-002': A(SRC, 'Def. 2.4; Lemma 2.6 proves associativity'), 'RSN-029': A(SRC, 'the mod-8 table and the types from one Gauss sum') } },
  ablamowicz: { refs: /Ablamowicz|Abłamowicz/, text: /Ablamowicz|Abłamowicz/, pages: ['steps/groups'],
    anchors: { 'RSN-030': A(SRC, 'O(Q) per class, W(E_n) mod 2'), 'SPR-M22': A(SRC, 'tied to Walsh functions'), 'ATY-033': A(SRC, 'tied to Walsh functions') } },
  tian: { refs: /Tian/, text: /Tian/, anchors: { 'PRJ-001': A(SRC, 'they are paired nulls; only the radical vector of an odd truncation is a label 0'), 'GEN-005': A(SRC, 'in a hyperbolic basis') } },
  majkic: { refs: /Majki/, text: /Majki/, pages: ['steps/category'] },
  pumplun: { refs: /Pumpl/, text: /Pumpl/, anchors: { 'LNC-056': A(PU, 'gauge change'), 'CAND-094': A(PU, 'a quasialgebra in the sense of Albuquerque–Majid'), 'LNC-137': A(PU, 'Cayley–Dickson sign'), 'CAND-079': A(PU, 'twisted group ring') } },
  'baez-pumplun': { refs: /Baez–Pumplün|2609\.07538/, text: /geometry paper/, anchors: { 'CAND-094': A(SRC, 'non-associative sign') } },
  baez: { refs: /Baez, arXiv|Baez, Three Generations|Baez, Second Quantization|Baez, Triangulations|Baez, The Tenfold|Tenfold|2011\.14234|2608\.06271|2507\.11428|2606\.10072|2509\.22584/, text: /Baez|tenfold|Tenfold/,
    anchors: { 'LNC-055': A(SRC, 'the three types as the sign of one Gauss sum'), 'CAND-067': A(SRC, 'eight graded pairs') } },
  'baez-schwahn': { refs: /Schwahn/, text: /gauge-group paper|Albert-algebra paper/ },
  'baez-bokor-boyle': { refs: /Bokor|2607\.10833/, text: /Jordan-pair paper|Baez, Bokor and Boyle/, anchors: { 'LNB-044': A(BZ, 'the Hamming-distance Peirce rule') } },
  furey: { refs: /Furey/, text: /Furey/, pages: ['matter', 'matter/model', 'matter/papers', 'matter/generations', 'matter/dictionary', 'matter/help'], anchors: { 'RSN-003': A(FU, 'against the ten Peirce edges') } },
  hestenes: { refs: /Hestenes/, text: /Hestenes/ },
  wise: { refs: /Wise/, text: /Wise/ },
  'lasenby-doran-gull': { refs: /Lasenby, Doran|Doran and Lasenby|Lasenby, Doran and Gull/, text: /Lasenby, Doran and Gull|Newtonian gauge|Painlevé/, pages: ['steps/gauge'],
    anchors: { 'RSN-017': A(HL, 'gauge-theory gravity'), 'RSN-018': A(HL, 'Curvature counts by dimension'), 'RSN-018b': A(HL, 'Curvature counts by dimension'), 'CPL-005': A(HL, 'The free Dirac action gives Hestenes'), 'LNC-025': A(HL, 'not the label 0') } },
  'hsu-barker-hobson-lasenby': { refs: /Hsu/, text: /Hsu/, pages: ['steps/nullsurf'], anchors: { 'RSN-016': A(SRC, 'Four claims: the generator of a null surface'), 'RSN-020': A(SRC, 'Schwarzschild against the Ellis wormhole') } },
  'roelfs-eelbode-de-keninck': { refs: /Roelfs|Eelbode/, text: /Roelfs|Eelbode|pointor/, pages: ['steps/spin'] },
  'dorst-de-keninck': { refs: /Dorst|De Keninck/, text: /Dorst and De Keninck|the forque paper|ganja/, pages: ['steps/forque', 'steps/rigid'] },
  gunn: { refs: /Gunn/, text: /Gunn|SIGGRAPH/, anchors: { 'RSN-008': A(SRC, 'One extra generator of square s'), 'PRJ-001': A(SRC, 'One extra generator of square s') } },
  schuller: { refs: /Schuller|Rea|Dadhley/, text: /Schuller|quantum lectures|quantum notes|his geometry course/, pages: ['steps/schuller'] },
  'schuller-closure': { refs: /Düll|Stritzelberger|Wolz|closure paper/, text: /closure paper|his closure/, pages: ['steps/schuller'] },
};
function readingOf(key, id) {
  const spec = READING[key];
  if (!spec) return null;
  const r = rowById.get(id);
  if (!r) return null;
  const ref = r.standardRef || '', txt = research.get(id) || '';
  if (spec.refs && spec.refs.test(ref)) return 'standard reference';
  if (spec.text && spec.text.test(txt)) return 'research text';
  if (spec.pages && (r.shownOn || []).some(s => spec.pages.includes(s.page))) return 'page';
  const an = spec.anchors && spec.anchors[id];
  if (an) { const f = path.join(ROOT, an[0]); if (fs.existsSync(f) && readText(f).includes(an[1])) return `anchor ${an[0]}`; return null; }
  return null;
}

// ------------------------------------------------------------------ the free strings of the file: [where, text]
const TEXT_KEYS = ['work', 'lead', 'question', 'thanks'];
const freeStrings = [];
for (const k of ['title', 'line', 'about']) if (typeof NOTES[k] === 'string') freeStrings.push([k, NOTES[k]]);
for (const n of notes) {
  for (const k of TEXT_KEYS) if (typeof n[k] === 'string') freeStrings.push([`${n.key}.${k}`, n[k]]);
  (n.sections || []).forEach((s, i) => {
    if (typeof s.head === 'string') freeStrings.push([`${n.key}.sections[${i}].head`, s.head]);
    (Array.isArray(s.text) ? s.text : []).forEach((t, j) => freeStrings.push([`${n.key}.sections[${i}].text[${j}]`, t]));
    (s.links || []).forEach((l, j) => { if (typeof l.label === 'string') freeStrings.push([`${n.key}.sections[${i}].links[${j}].label`, l.label]); });
  });
  if (n.earlier && Array.isArray(n.earlier.text)) n.earlier.text.forEach((t, j) => freeStrings.push([`${n.key}.earlier.text[${j}]`, t]));
}

// ------------------------------------------------------------------ A shape
{
  const off = [];
  for (const k of ['title', 'line', 'about']) if (typeof NOTES[k] !== 'string' || !NOTES[k].trim()) off.push(`${k}: missing`);
  if (typeof NOTES.about === 'string' && !(/view of the Atlas/.test(NOTES.about) && /changes no row/.test(NOTES.about))) off.push('about: does not say that a note is a view of the Atlas and changes no row');
  if (!notes.length) off.push('notes: empty');
  const seen = new Set();
  for (const n of notes) {
    if (typeof n.key !== 'string' || !/^[a-z][a-z0-9-]*$/.test(n.key)) off.push(`key ${JSON.stringify(n.key)}: not a plain key`);
    else if (seen.has(n.key)) off.push(`key ${n.key}: twice`); else seen.add(n.key);
    if (!Array.isArray(n.to) || !n.to.length || !n.to.every(x => typeof x === 'string' && x.trim())) off.push(`${n.key}.to: no names`);
    for (const k of ['work', 'lead', 'question', 'thanks']) if (typeof n[k] !== 'string' || !n[k].trim()) off.push(`${n.key}.${k}: missing`);
    if (!Array.isArray(n.sections) || !n.sections.length) off.push(`${n.key}.sections: none`);
    if (n.earlier != null && !(typeof n.earlier === 'object' && typeof n.earlier.date === 'string' && Array.isArray(n.earlier.text))) off.push(`${n.key}.earlier: not { date, text: [paragraphs] }`);
    (n.sections || []).forEach((s, i) => { if (typeof s.head !== 'string' || !Array.isArray(s.text)) off.push(`${n.key}.sections[${i}]: needs a head and text: [paragraphs]`); });
  }
  rule('A shape', off, `the file's title, line and about; ${notes.length} notes with unique plain keys, names, work, lead, sections, question and thanks (${notes.filter(n => n.earlier).length} with an earlier letter)`);
}

// ------------------------------------------------------------------ B order
{
  const off = [], owned = [];
  for (const n of notes) {
    const heads = (n.sections || []).map(s => s.head);
    const okHeads = heads.length === HEADS.length && heads.every((h, i) => h === HEADS[i]);
    if (!okHeads) (OWNED.has(n.key) ? owned : off).push(`${n.key}: ${heads.join(' / ')}`);
  }
  rule('B order', off, `the four sections in the order of the narrative (${HEADS.join(' → ')}), then the question`);
  if (owned.length) say(`note B order: written by another owner, reported only: ${owned.join('; ')}`);
}

// ------------------------------------------------------------------ C rows
const allCited = new Map();
{
  const off = [], ownedC = [];
  for (const n of notes) {
    const union = [];
    for (const s of n.sections || []) for (const id of s.rows || []) if (!union.includes(id)) union.push(id);
    const listed = Array.isArray(n.rows) ? n.rows : [];
    if (new Set(listed).size !== listed.length) off.push(`${n.key}: a row listed twice in rows`);
    const a = [...new Set(listed)].sort().join(','), b = [...union].sort().join(',');
    if (a !== b) (OWNED.has(n.key) ? ownedC : off).push(`${n.key}: rows is not the union of its sections' rows (rows ${listed.length}, union ${union.length}; only in rows: ${listed.filter(x => !union.includes(x)).join(' ') || '–'}; only in sections: ${union.filter(x => !listed.includes(x)).join(' ') || '–'})`);
    for (const id of new Set([...listed, ...union])) {
      if (!rowById.has(id)) { off.push(`${n.key}: ${id} is not a row of content/rows.json`); continue; }
      if (!research.has(id)) off.push(`${n.key}: ${id} has no research text (its card would not show)`);
      if (!allCited.has(id)) allCited.set(id, new Set());
      allCited.get(id).add(n.key);
    }
  }
  rule('C rows', off, `${allCited.size} distinct rows cited by the notes exist, have a research text, and every note's rows are the union of its sections' rows`);
  if (ownedC.length) say(`note C rows: written by another owner, reported only: ${ownedC.join('; ')}`);
}

// ------------------------------------------------------------------ D reading
const viaCount = new Map();
{
  const off = [];
  for (const n of notes) {
    if (!READING[n.key]) { off.push(`${n.key}: no entry in READING (the reading of its work is not written out)`); continue; }
    for (const id of n.rows || []) {
      const via = readingOf(n.key, id);
      if (!via) off.push(`${n.key}: ${id} is not tied to the reading of this work (${clip(rowById.get(id)?.standardRef || 'no reference', 80)})`);
      else viaCount.set(via.startsWith('anchor') ? 'anchor in the reading' : via, (viaCount.get(via.startsWith('anchor') ? 'anchor in the reading' : via) || 0) + 1);
    }
  }
  rule('D reading', off, `every cited row belongs to the reading of its note's work (${[...viaCount].map(([k, v]) => `${v} by ${k}`).join(', ')})`);
}

// ------------------------------------------------------------------ E pictures
{
  const off = [];
  let figs = 0, svgs = 0;
  for (const n of notes) (n.sections || []).forEach((s, i) => {
    if (s.figure != null) { figs++; if (typeof s.figure !== 'string' || !figureIds.has(s.figure)) off.push(`${n.key}.sections[${i}].figure ${JSON.stringify(s.figure)}: not a figure of content/figures.json`); }
    if (s.svg != null) {
      svgs++;
      const m = typeof s.svg === 'string' ? /^([\w-]+)\/([\w-]+\.svg)$/.exec(s.svg) : null;
      if (!m) off.push(`${n.key}.sections[${i}].svg ${JSON.stringify(s.svg)}: not "<course>/<file>.svg"`);
      else if (!fs.existsSync(path.join(ROOT, 'public', 'reports', 'tutorials', 'src', m[1], 'figs', m[2]))) off.push(`${n.key}.sections[${i}].svg ${s.svg}: no such file under public/reports/tutorials/src/${m[1]}/figs/`);
    }
  });
  rule('E pictures', off, `${figs} figure ids and ${svgs} tutorial figures, every one on disk or in the figures table`);
}

// ------------------------------------------------------------------ F links
{
  const off = [];
  let n0 = 0;
  for (const n of notes) (n.sections || []).forEach((s, i) => (s.links || []).forEach(l => {
    n0++;
    if (typeof l.label !== 'string' || !l.label.trim()) off.push(`${n.key}.sections[${i}]: a link without a label`);
    if (typeof l.to === 'string') { if (!routeOk(l.to)) off.push(`${n.key}.sections[${i}]: route ${l.to} is not a page the router renders`); }
    else if (typeof l.href === 'string') { const f = path.join(ROOT, 'public', l.href.replace(/^\.?\//, '').split('#')[0]); if (!fs.existsSync(f)) off.push(`${n.key}.sections[${i}]: href ${l.href} is not a file of public/`); }
    else off.push(`${n.key}.sections[${i}]: a link with neither to nor href`);
  }));
  rule('F links', off, `${n0} links: every route a page the router renders, every href a file of public/`);
}

// ------------------------------------------------------------------ G words: no 40-character run of a text record, at any offset
const WIN = 40;
{
  const off = [];
  const wins = new Map();
  for (const [where, t] of freeStrings) for (let i = 0; i + WIN <= t.length; i++) { const w = t.slice(i, i + WIN); if (!wins.has(w)) wins.set(w, where); }
  const hits = new Map();
  for (const rec of TEXTS) {
    const b = String(rec.body || '');
    for (let i = 0; i + WIN <= b.length; i++) {
      const w = b.slice(i, i + WIN);
      const where = wins.get(w);
      if (where && !hits.has(where)) hits.set(where, `${where}: holds 40 characters of ${rec.row} (${rec.level}${rec.lens ? ', lens ' + rec.lens : ''}): «${w}»`);
    }
  }
  off.push(...hits.values());
  rule('G words', off, `${freeStrings.length} free strings hold no run of ${WIN} characters of any of the ${TEXTS.length} text records, at any offset`);
}

// ------------------------------------------------------------------ H numbers: a number in a paragraph is shown by a card of its section
{
  const off = [], owned = [];
  let paras = 0, nums = 0;
  const digitsOf = t => (t.match(/\d+(?:[.,]\d+)*/g) || []).map(x => x.replace(/,(?=\d{3}\b)/g, ''));
  for (const n of notes) (n.sections || []).forEach((s, i) => {
    const cards = (s.rows || []).map(id => research.get(id) || '').join(' ').replace(/(\d),(?=\d{3}\b)/g, '$1').replace(/(\d) (?=\d{3}\b)/g, '$1');
    for (const t of Array.isArray(s.text) ? s.text : []) {
      paras++;
      for (const d of digitsOf(t)) {
        nums++;
        const re = new RegExp(`(?<![\\d.])${d.replace(/\./g, '\\.')}(?![\\d])`);
        if (!re.test(cards)) (OWNED.has(n.key) ? owned : off).push(`${n.key}.sections[${i}] "${s.head}": ${d} is in the paragraph and in no card of the section`);
      }
    }
  });
  rule('H numbers', off, `${nums} numbers in ${paras} paragraphs, each shown by a card of its section`);
  if (owned.length) say(`note H numbers: written by another owner, reported only: ${owned.length} (${owned.slice(0, 6).join('; ')})`);
}

// ------------------------------------------------------------------ I history: the banned families, every date, and the brief's words
const MONTH_RE = 'January|February|March|April|May|June|July|August|September|October|November|December';
const P = {
  P1: [/\berrat(a|um)\b/i, /\bE-\d{3}\b/, /\bfinding E-/i],
  P2: [/\bcorrected\b/i, /\bcorrections? (of|applied|block|section)\b/i, /\bcorrigend/i, /\bsee the corrections\b/i],
  P3: [/\bwithdrawn\b/i, /\bretract(ed|ion)\b/i, /\bretired\b/i, /\bstruck( through| out)?\b/i, /\bsuperseded\b/i, /\bobsolete\b/i, /\bstale\b/i, /\bdiscarded wording\b/i],
  P4: [/\b(was|were|is|are) (wrong|too strong|too weak|a mistake|mistaken)\b(?! (for|in|when|if|only|here|on)\b)/i, /\b(was|were|is|are) false\b(?! (for|in|when|if|only|here|on)\b)/, /\bas first (written|stated|printed|said)\b/i, /\bfirst (guess|draft|version|reading|explanation|wording)\b/i,
    /\bour (own )?(first|earlier|previous|old) (guess|reading|explanation|claim|sentence|wording|version|statement)\b/i, /\b(earlier|previous|former|old) (draft|version|wording|claim|statement|sentence|reading|analysis|release|report)s?\b/i,
    /\b(we|it) (once|previously|used to|had) (said|thought|claimed|believed|written|read)\b/i, /\bused to (say|read|claim|be called)\b/i, /\bformerly\b/i, /\bpreviously\b/i, /\bno longer\b/i, /\bto say what we said\b/i],
  P5: [/\boverstate[sd]?\b/i, /\boverclaim/i, /\btoo strong\b/i, /\bwe (had )?misread\b/i, /\bwas (misread|misstated)\b/i, /\bour (own )?(error|errors|slip|slips|mistake|mistakes)\b/i, /\bmisinterpret/i],
  P6: [/\bv(7|8|9)(\.\d+)?\b/i, /\bv10(\.[01])?\b/i, /\bv1\.[01]\b/i, /\baudit round( [12])?\b/i, /\bround (\d+|one|two|three|four|five|six|seven|eight|nine)\b/i, /\bsecond (round|pass)\b/i, /\bchangelog\b/i, /\bsince the last (report|release|version)\b/i, /\bpass (\d+|six|seven|eight|nine)\b/i],
  P7: [/\berrata corrige\b/i, /\bcorrezion[ei]\b/i, /\bin passato\b/i, /\bavevamo (detto|pensato)\b/i],
  P8: [/\bREADME_update_/i, /\blane [A-D]\b/i, /\brelabell?ed from\b/i, /\boriginal (label|wording|sentence|text|claim|name)\b/i, /\bfirst assumed\b/i, /\bre-?worded\b/i, /\bwe (have |had )?(replaced|renamed|rewrote|reworded)\b/i, /\bhad been\b/i,
    /\bhad to be (pulled|taken|split|set|separated|fixed|changed|replaced|rewritten)\b/i, /\bfound (it |them |this )?late\b/i, /\bmet on the way\b/i, /\bnow (proved|proven|exists?|stands?|holds?|states|covers|includes?|carries|stated|written|shown|listed|given|a theorem|T\d+)\b/i, /\band now\b/i,
    /\(corrections?\b/i, /\bafter an? (noted |small |one-line |written-down )?correction\b/i, /\bthe new (widget|report|reports|script|scripts|tab|tabs|chapter|chapters|page|pages|row|rows|note|notes)\b/i, /\b(older|previously known as|formerly called) (word|wording|term|name|text|sentence|label)\b/i,
    /\bin (this|that|the|a) (working )?session\b/i, /\b(this|the) (line|page|sentence|paragraph|text|README|brief|row) (said|called|read|claimed|stated|gave)\b/i, /\b(of|saw|see|under|uses?|used) version [1-9]\b(?![.\d])|\bversion [1-9] (of|gave|fixes)\b|\(version [1-9]:/i],
  P9: [/\b(up to|until|since|predates?|before|prior to|new in|added in|introduced in|fixed in|changed in|unchanged from) v?\d+\.\d+(\.\d+)?\b/i, /\bv1\.\d+/i, /\bv1[12345]\.\d+/i, /\bv\d+\.\d+\.\d+\b/i,
    /\b20\d\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])\b/, new RegExp(`\\b(?:[1-9]|[12]\\d|3[01]) (${MONTH_RE}) 20\\d\\d\\b`, 'i'), new RegExp(`\\b(${MONTH_RE}) (?:[1-9]|[12]\\d|3[01]),? 20\\d\\d\\b`, 'i')],
  // the brief of the notes: no history words, no superlatives or flattery, nothing the Atlas never says
  NOTE: [/\bthis round\b/i, /\bnew in this\b/i, /\bnot yet\b/i, /\bat last\b/i, /\bfinally\b/i,
    /\b(best|greatest|finest|deepest|most beautiful|beautiful|elegant|brilliant|remarkable|stunning|striking|profound|groundbreaking|seminal|masterpiece|genius|pioneering|celebrated|famous|landmark|outstanding|wonderful|amazing|fascinating|admire|admiration)\b/i,
    /\bpredicts? (the|a|an|that)\b(?![^.]*\b(labels|Atlas)\b)/i, /\bderived from the bit rule\b/i, /\bproves? that (nature|physics)\b/i],
};
const ALL_P = Object.entries(P).flatMap(([g, l]) => l.map(re => [g, re]));
const historyHits = (where, t) => { const o = []; for (const [g, re] of ALL_P) { const m = re.exec(t); if (m) o.push(`${where}: ${g} «${m[0]}» in «${clip(t.slice(Math.max(0, m.index - 40), m.index + 60), 110)}»`); } return o; };
{
  const off = [];
  for (const [where, t] of freeStrings) off.push(...historyHits(where, t));
  rule('I history (notes)', off, `${freeStrings.length} free strings of the notes carry no banned history phrase, date, superlative or claim the Atlas never makes`);
}

// ------------------------------------------------------------------ J contact details
const CONTACT = [
  ['e-mail address', /[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,24}\b/],
  ['web address', /\bhttps?:\/\/|\bwww\.[a-z0-9-]+\./i],
  ['telephone number', /(?:\+\d{1,3}[ .-]?)?\(?\d{2,4}\)?[ .-]\d{3,4}[ .-]\d{3,4}\b/],
  ['user path', new RegExp(['(?<![\\w.~%-])\\', 'home\\', '[\\w.-]|(?<![\\w.~%-])\\', 'Users\\', '[\\w.-]'].join('/'))],
  ['drive-letter path', /\b[A-Z]:(?:\\{1,2}|\/)[A-Za-z][\w .-]*(?:\\{1,2}|\/)[A-Za-z]/],
  ['postal or office address', /\b(Street|Strasse|Straße|Road|Avenue|Postbox|P\.O\. Box|Zip code|postcode)\b/i],
];
// the licence comment at the top of a file names the licence's own page: that line is the Required Notice, not a contact detail
const LICENCE_LINE = /SPDX-License-Identifier: PolyForm-Noncommercial-1\.0\.0.*polyformproject\.org\/licenses\/noncommercial\/1\.0\.0/;
const contactHits = (file, text) => { const o = []; text.split('\n').forEach((l, i) => { if (LICENCE_LINE.test(l)) return; for (const [n, re] of CONTACT) { const m = re.exec(l); if (m) o.push(`${file}:${i + 1} ${n} «${clip(m[0], 60)}»`); } }); return o; };
{
  const off = [];
  const allStrings = [];
  const walkStrings = (v, p) => { if (typeof v === 'string') allStrings.push([p, v]); else if (Array.isArray(v)) v.forEach((x, i) => walkStrings(x, `${p}[${i}]`)); else if (v && typeof v === 'object') for (const k of Object.keys(v)) walkStrings(v[k], p ? `${p}.${k}` : k); };
  walkStrings(NOTES, '');
  for (const [p, s] of allStrings) for (const [n, re] of CONTACT) { const m = re.exec(s); if (m) off.push(`${rel(NOTES_FILE)} ${p}: ${n} «${clip(m[0], 60)}»`); }
  for (const f of [EMAILS_FILE, NOTES_DOC]) if (fs.existsSync(f)) off.push(...contactHits(rel(f), readText(f)));
  rule('J contact', off, `${allStrings.length} strings of the notes (names included), the e-mails and docs/round9/NOTES.md: no e-mail address, web address, telephone number or user path`);
}

// ------------------------------------------------------------------ K the e-mails
{
  const off = [];
  if (!fs.existsSync(EMAILS_FILE)) off.push(`${rel(EMAILS_FILE)}: missing`);
  else {
    const md = readText(EMAILS_FILE);
    const head = md.split('\n').slice(0, 12).join('\n');
    if (!/SPDX-License-Identifier: PolyForm-Noncommercial-1\.0\.0/.test(head) || !/Required Notice: Copyright \(c\) 2026 the Cascade Atlas authors/.test(head)) off.push('the licence comment is not at the top');
    if (!/earlier letters? (were|was) not available/i.test(head) || !/first or a follow-up/i.test(head)) off.push('the line on the earlier letters (not available; each e-mail first or follow-up alike) is not at the top');
    const parts = md.split(/^## /m).slice(1).map(p => { const nl = p.indexOf('\n'); return [p.slice(0, nl).trim(), p.slice(nl + 1)]; });
    const byKey = new Map(parts.map(([k, b]) => [k, b]));
    const keys = notes.map(n => n.key);
    for (const k of keys) if (!byKey.has(k)) off.push(`${k}: no e-mail`);
    for (const [k] of parts) if (!keys.includes(k)) off.push(`## ${k}: no note has this key`);
    let held = 0, words = 0;
    for (const n of notes) {
      const b = byKey.get(n.key);
      if (!b) continue;
      const lines = b.split('\n');
      const subj = lines.find(l => /^Subject: \S/.test(l));
      if (!subj) off.push(`${n.key}: no subject line`);
      const pic = lines.find(l => /^Picture: /.test(l));
      const pictures = new Set((n.sections || []).flatMap(s => [s.figure, s.svg]).filter(x => typeof x === 'string' && x));
      if (!pic) off.push(`${n.key}: no picture line`);
      else { const named = (/`([^`]+)`/.exec(pic) || [])[1]; if (!named || !pictures.has(named)) off.push(`${n.key}: the picture «${named || '?'}» is not a figure or an svg of the note`); }
      if (lines.some(l => /^Hold: /.test(l))) held++;
      const bodyStart = lines.findIndex(l => /^Dear /.test(l));
      const bodyEnd = lines.findIndex((l, i) => i > bodyStart && /^---\s*$/.test(l));
      if (bodyStart < 0) { off.push(`${n.key}: no salutation line ("Dear …")`); continue; }
      const body = lines.slice(bodyStart, bodyEnd < 0 ? undefined : bodyEnd).join('\n').trim();
      const wc = (body.match(/[\p{L}\p{N}][\p{L}\p{N}'’.,:;()\/#<>=+−–-]*/gu) || []).length;
      words += wc;
      if (wc > 120) off.push(`${n.key}: ${wc} words (at most 120)`);
      const links = body.match(/<site>\/#\/notes\/[\w-]+/g) || [];
      if (links.length !== 1 || links[0] !== `<site>/#/notes/${n.key}`) off.push(`${n.key}: ${links.length} links (one, to <site>/#/notes/${n.key})`);
      if (/https?:\/\//.test(body)) off.push(`${n.key}: a web address in the body`);
      const qs = (body.match(/\?/g) || []).length;
      if (qs !== 1) off.push(`${n.key}: ${qs} question marks (one question)`);
      // the names the note is addressed to are left out first (a researcher may be called Claude)
      const unnamed = (n.to || []).reduce((b, who) => b.split(who).join(' '), body);
      if (/\b(AI|A\.I\.|artificial intelligence|language model|Claude|Anthropic|chatbot|LLM)\b/.test(unnamed)) off.push(`${n.key}: the body says who wrote it`);
      off.push(...historyHits(`${n.key} (e-mail)`, subj ? body + '\n' + subj : body));
    }
    say(`note K e-mails: ${parts.length} e-mails, ${words} words in all, ${held} held for the owner's judgement`);
  }
  rule('K e-mails', off, `one e-mail per note: subject, at most 120 words, one link to its note, one picture of the note, one question, nothing on who wrote it, no flattery, no history word`);
}

// ------------------------------------------------------------------ the counts the report gives (by status, through the derived status table)
{
  const by = new Map();
  for (const n of notes) for (const id of new Set(n.rows || [])) { const st = (STATUS[id] && STATUS[id].status) || 'unknown'; by.set(st, (by.get(st) || 0) + 1); }
  say(`counts: ${notes.length} notes; ${new Set(notes.flatMap(n => n.to || [])).size} names; ${[...by].sort((a, b) => b[1] - a[1]).map(([k, v]) => `${v} ${k}`).join(', ')} (row citations, a row counted once per note)`);
}
say(`\ncheck_notes: ${checks - bad} of ${checks} rules pass`);
process.exit(bad ? 1 : 0);
