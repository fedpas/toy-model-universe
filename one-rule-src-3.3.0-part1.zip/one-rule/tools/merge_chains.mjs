#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/merge_chains.mjs — the chains overlay content/chains/ (docs/round14/STORY_ROUND.md §2 and §3.3, D52–D61; owner B1), merged inside
// tools/merge_story.mjs (D59: one merge, one bookkeeping — its writes enter content/story/merged.json with the story overlay's, so a second run restores
// and writes the same bytes). The files, by folder (folders sorted; a folder is an owner: pilot, shifted, matter, …):
//   <owner>/chains.json   the chain records (interface 40, §2.1): positions, mentions, twins, joins, links, shape, title, lead
//   <owner>/rows.json     the round-14 rows: story rows (D60: kind story, ids <GROUP>-701 … 799, since v2.15 or, wave 2, v2.16, or, waves 3–5 of round 16, v2.17, their own shownOn) and new statement rows
//                         (D61, §2.5: kind reading or question, since v2.15)                          → rows.json (merge_story step 1)
//   <owner>/texts.json    their research texts (drafts, source round14:<owner> or the locator)         → texts.json (step 2)
//   <owner>/page.json     { pages: [page entries], layout: [placements] }: the entries join content/story/{sections,chapters,furey}.json as the last
//                         precedence (step 4), the placements the layout (step 3; an added entry of order 2000 or more never moves a home)
//   learner/<page key>.json   the storyteller's words (T3): spans (interface 41, §2.2: register span, chain, span) and the learner texts of round-14
//                         rows and of side notes                                                      → texts.json (step 2)
//   retired.json          the learner drafts a wave retired (--retire), not merged
// In merge_story, after its step 5 (homes), mergeChains(tables, overlay) validates the chains on the merged tables (V1–V10 below), writes each page
// section's `chains` (the section's chain ids in order, §2.3; never typed in a page entry) and returns the merged table content/chains.json (sorted by
// page, section, order), each record with `story`: none, draft (every position and twin has its span, the lead its learner text) or reviewed (and
// every one of those texts is reviewed or human). Refused (merge_story writes nothing), each with its record:
//   V1  a chain id unique, of the form <page key>.<section>.<slug>; its page and section exist after the page entries; not intro, top-notes or an
//       inputs section
//   V2  every told position placed in its (page, section) with role result or detail; every mention told in another chain of the same page; a row
//       told in at most one chain per page; no position twice
//   V3  links: one fewer than the positions; a relation of §2.1; a depends relation backed by an edge in the stated direction (or from `from`, an
//       earlier position); continues backed by splitFrom; contrasts with a note; no contradicts; each join backed by an edge from a row told in an
//       earlier chain of the page to a told position (an order link where an edge exists is a warning)
//   V4  the lead null, or a story row of role chain in the same section, whose restates name rows of the chain
//   V5  a twin is the b-row split from its position's row, visible only in the other mode
//   V6  the shape agrees with the links (tools/story/extract_chains.mjs shapeOf)
//   V7  the title a name: phys and learner present, each part at most 60 characters, no claim word, no final period; no formula mark at learner level
//   V8  the orders positive integers, unique in a section
//   V9  a round-14 story row: D60's record (kind story, notions ["i-meta"], no evidence, since v2.15 (v2.16 for wave 2, v2.17 for waves 3–5), an id 701–799 of its group not reserved by
//       content/story/ids.json or pending.json, one placement, a research text, T4/T5 against its chain or its section; its learner text is the
//       storyteller's: a warning while it is missing); a new statement row: §2.5's record; a moved home is refused by merge_story's step 5
//   V10 spans: C2, C3 and C11 of tools/check_learner_texts.mjs again (a partial story is never merged); a span of a row with a human learner text is
//       that text (C10); every text with `chain` names a chain and one of its positions
// The CLI (merge_story runs the merge; npm run content runs --check right after tools/check_learner_texts.mjs):
//   node tools/merge_chains.mjs --check            what a merge would do (merge_story's dry run), exit 1 on an error
//   node tools/merge_chains.mjs --retire "<wave>"  moves the translator drafts (register full, status draft or reviewed, source translator:…) of the rows whose every
//                                                  placement is a told position of a storied chain from content/texts_learner*.json into
//                                                  content/chains/retired.json, with the wave; human texts untouched; a page's hero without a
//                                                  short learner text keeps its full draft (D66, round 15); idempotent (R7, at a release)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { testBlock, testRow, claimWords } from './migrate/story_from_v15.mjs';
import { formulaHits } from './check_learner_texts.mjs';
import { makeTables, statusOf, depsOf, shapeOf, isTwin, joinsOf, toldOf, pageKey, isInputsSection, CHAIN_RELS, DIRECTED } from './story/extract_chains.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content');
export const CHAINS_DIR = path.join(C, 'chains');
export const RETIRED = path.join(CHAINS_DIR, 'retired.json');
const readJSON = (f, fallback) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback);
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const rel = f => path.relative(ROOT, f).split(path.sep).join('/');

export const SINCE = 'v2.15';
/** the versions a row of the chains overlay may carry: v2.15 (round 14, wave 1), v2.16 (round 15, wave 2: the section leads of docs/round15/SPINE_wave2.md),
 *  v2.17 (round 16, waves 3–5, release 2.17.0: the eighteen section leads of docs/round16/SPINE_wave3.md, SPINE_wave4.md and SPINE_wave5.md),
 *  v2.18 (round 16, wave 6, release 2.18.0: the section leads of docs/round16/SPINE_wave6_category.md, SPINE_wave6_baez.md and SPINE_wave6_schuller.md) */
export const SINCES = new Set(['v2.15', 'v2.16', 'v2.17', 'v2.18']);
export const TITLE_MAX = 60;
const SLUG = /^[a-z0-9][a-z0-9-]*$/;
const TOLD_ROLES = new Set(['result', 'detail']);
const STORY_ID = /^([A-Z]{2,4})-(\d{3})$/;

// ------------------------------------------------------------------------------------------------------------------------------- the overlay
/**
 * The chains overlay as files hold it: { chains, rows, texts, learner, entries, layout } — each a list of { rec, file } — and the errors of its shape.
 * A test passes the same object in memory (merge_story's opts.chains).
 */
export function readChainOverlay(dir = CHAINS_DIR) {
  const ov = { chains: [], rows: [], texts: [], learner: [], entries: [], layout: [], errors: [] };
  if (!fs.existsSync(dir)) return ov;
  const list = (f, key) => { const v = readJSON(f, []); if (!Array.isArray(v)) { ov.errors.push(`${rel(f)}: not an array`); return; } for (const rec of v) ov[key].push({ rec, file: rel(f) }); };
  for (const name of fs.readdirSync(dir).sort()) {
    const d = path.join(dir, name);
    if (!fs.statSync(d).isDirectory()) continue;
    if (name === 'learner') { for (const n of fs.readdirSync(d).filter(n => n.endsWith('.json')).sort()) list(path.join(d, n), 'learner'); continue; }
    if (fs.existsSync(path.join(d, 'chains.json'))) list(path.join(d, 'chains.json'), 'chains');
    if (fs.existsSync(path.join(d, 'rows.json'))) list(path.join(d, 'rows.json'), 'rows');
    if (fs.existsSync(path.join(d, 'texts.json'))) list(path.join(d, 'texts.json'), 'texts');
    const pf = path.join(d, 'page.json');
    if (fs.existsSync(pf)) {
      const p = readJSON(pf, {});
      if (!p || typeof p !== 'object' || Array.isArray(p)) ov.errors.push(`${rel(pf)}: not { pages, layout }`);
      else { for (const e of p.pages || []) ov.entries.push({ rec: e, file: rel(pf) }); for (const l of p.layout || []) ov.layout.push({ rec: l, file: rel(pf) }); }
    }
  }
  return ov;
}
/** the same object from plain lists (a test's overlay in memory): { chains?, rows?, texts?, learner?, entries?, layout? } */
export function chainOverlayOf(lists = {}) {
  const ov = { chains: [], rows: [], texts: [], learner: [], entries: [], layout: [], errors: [] };
  for (const k of Object.keys(ov)) if (k !== 'errors' && Array.isArray(lists[k])) ov[k] = lists[k].map(rec => (rec && rec.rec && rec.file ? rec : { rec, file: `(memory) ${k}` }));
  return ov;
}
/** a text record as texts.json holds it: the keys of 02 §2, and chain and span for a span */
export function textRecord(t) {
  const rec = { row: t.row, lang: t.lang || 'en', mode: t.mode || 'both', level: t.level, lens: t.lens || null, register: t.register || 'full' };
  if (t.chain != null || t.span != null) { rec.chain = t.chain; rec.span = t.span; }
  return { ...rec, body: typeof t.body === 'string' ? t.body.trim() : t.body, status: t.status || 'draft', source: t.source };
}
export const isSpan = t => !!t && (t.register === 'span' || t.chain != null);

// ------------------------------------------------------------------------------------------------------------------------------- the merge
const RECORD_KEYS = ['id', 'page', 'section', 'order', 'title', 'lead', 'rows', 'mention', 'twins', 'joins', 'links', 'shape', 'extracted', 'story'];
const isResearch = t => t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full' && !isSpan(t);
const isLearnerFull = t => t.level === 'learner' && t.lens == null && (t.register || 'full') === 'full' && !isSpan(t);
/**
 * mergeChains(tables, overlay) — on the tables as merge_story has merged them through its step 5: { rows, texts, pages, status, runs, reserved (the ids
 * content/story/ids.json and pending.json reserve), r14 (a Set: the ids of the round-14 rows of the overlay) } and the overlay (readChainOverlay) →
 * { rows, texts, pages (the sections with chains carry them), chains (the table content/chains.json), touched (the routes whose sections changed),
 * errors, warnings, summary }. Pure: no file is read or written.
 */
export function mergeChains(tables, overlay) {
  const errors = [...(overlay.errors || [])], warnings = [];
  const E = (where, msg) => errors.push(`${where}: ${msg}`), Wn = (where, msg) => warnings.push(`${where}: ${msg}`);
  const { rows, texts } = tables;
  const T = makeTables({ rows, pages: tables.pages, runs: tables.runs || [], status: tables.status || {} });
  const byId = T.byId;
  const pages = tables.pages.map(p => ({ ...p, sections: (p.sections || []).map(s => ({ ...s })) }));
  const pageOf = route => pages.find(p => p.route === route);
  const sectionOf = (route, id) => ((pageOf(route) || {}).sections || []).find(s => s.id === id);
  const research = new Map(texts.filter(isResearch).map(t => [t.row, t]));
  const learnerFull = new Map(); for (const t of texts) if (isLearnerFull(t) && (t.mode || 'both') === 'both') learnerFull.set(t.row, t);
  const humanLearner = new Map(); for (const t of texts) if (isLearnerFull(t) && t.status === 'human' && !humanLearner.has(t.row)) humanLearner.set(t.row, t);
  const placedTold = (id, page, section) => ((byId.get(id) || {}).shownOn || []).some(so => so.page === page && so.section === section && TOLD_ROLES.has(so.role || 'result'));

  // ---- the records, one by one (V1, V4–V8; V2's placements; V3's links)
  const good = [], idSeen = new Set(), orderSeen = new Map(), tellerOf = new Map(); // `${page}|${row}` → the chain that tells it
  for (const { rec: c, file } of overlay.chains) {
    const at = `${file} ${c && c.id}`;
    if (!c || typeof c !== 'object' || typeof c.id !== 'string') { E(at, 'a chain record needs an id'); continue; }
    if (idSeen.has(c.id)) { E(at, 'a second chain with this id (V1)'); continue; }
    idSeen.add(c.id);
    const before = errors.length;
    const parts = c.id.split('.');
    if (parts.length !== 3 || parts[0] !== pageKey(c.page) || parts[1] !== c.section || !SLUG.test(parts[2])) E(at, `the id is <page key>.<section>.<slug>: ${pageKey(c.page)}.${c.section}.<a slug of a–z, 0–9 and -> (V1)`);
    if (!pageOf(c.page)) E(at, `page ${JSON.stringify(c.page)} is not a route after the page entries (V1)`);
    else if (!sectionOf(c.page, c.section)) E(at, `section ${JSON.stringify(c.section)} is not a section of ${c.page} (V1)`);
    if (['intro', 'top-notes'].includes(c.section) || isInputsSection(T, c.page, c.section)) E(at, 'a chain never stands in intro, top-notes or an inputs section (V1)');
    const list = Array.isArray(c.rows) ? c.rows : [];
    if (!list.length || list.some(x => typeof x !== 'string')) E(at, 'rows: the positions, a list of row ids');
    if (new Set(list).size !== list.length) E(at, 'a position twice (V2)');
    for (const id of list) if (!byId.has(id)) E(at, `${id} is not a row`);
    const mention = Array.isArray(c.mention) ? c.mention : null, twins = c.twins && typeof c.twins === 'object' && !Array.isArray(c.twins) ? c.twins : null;
    if (!mention || mention.some(id => !list.includes(id))) E(at, 'mention: a list of positions');
    if (!twins) E(at, 'twins: an object { position → its twin }');
    if (!Array.isArray(c.joins) || !Array.isArray(c.links)) E(at, 'joins and links: lists');
    if (!['none', 'draft', 'reviewed'].includes(c.story)) E(at, `story ${JSON.stringify(c.story)}: none, draft or reviewed (merge_chains writes it)`);
    // V8
    if (!Number.isInteger(c.order) || c.order < 1) E(at, `order ${JSON.stringify(c.order)}: 1, 2, … (V8)`);
    else { const k = `${c.page}|${c.section}|${c.order}`; if (orderSeen.has(k)) E(at, `order ${c.order} is also the order of ${orderSeen.get(k)} in ${c.section} (V8)`); orderSeen.set(k, c.id); }
    // V7
    const ti = c.title;
    if (!ti || typeof ti !== 'object') E(at, 'no title (V7)');
    else {
      for (const k of ['phys', 'learner']) if (typeof ti[k] !== 'string' || !ti[k].trim()) E(at, `no ${k} title (V7${k === 'phys' ? '; a draft of extract_chains --into: the composer titles it' : ''})`);
      for (const k of ['phys', 'math', 'learner']) {
        const s = ti[k]; if (s == null || s === '') continue;
        if (typeof s !== 'string') { E(at, `title.${k} is not a string (V7)`); continue; }
        if (s.length > TITLE_MAX) E(at, `title.${k} has ${s.length} characters (at most ${TITLE_MAX}, V7)`);
        const cw = claimWords(s); if (cw.length) E(at, `title.${k} holds the claim word(s) ${cw.join(', ')} (V7)`);
        if (/[.]\s*$/.test(s)) E(at, `title.${k} ends with a period (V7: a name)`);
      }
      if (typeof ti.learner === 'string') { const f = formulaHits(ti.learner); if (f.length) E(at, `the learner title holds a formula mark: ${f.join('; ')} (V7)`); }
    }
    if (errors.length > before) continue;
    // V5
    for (const [p, b] of Object.entries(twins)) if (!list.includes(p) || !isTwin(T, p, b)) E(at, `twin ${p} → ${b}: a twin is the b-row split from its position's row, visible only in the other mode (V5)`);
    // V2: told positions placed; one teller per row and page
    for (const id of toldOf(c)) {
      if (!placedTold(id, c.page, c.section)) E(at, `${id} is told here but not placed in ${c.page} · ${c.section} with role result or detail (V2)`);
      for (const x of [id, twins[id]].filter(Boolean)) { const k = `${c.page}|${x}`; if (tellerOf.has(k)) E(at, `${x} is told in ${tellerOf.get(k)} too: a row is told at most once per page (V2)`); else tellerOf.set(k, c.id); }
    }
    // V3: the links
    const links = c.links;
    if (links.length !== list.length - 1) E(at, `${links.length} links for ${list.length} positions (one fewer, V3)`);
    links.forEach((l, i) => {
      const a = list[i], b = list[i + 1], where = `${at} link ${i + 1} (${a} → ${b})`;
      if (!l || typeof l !== 'object' || typeof l.rel !== 'string') { E(where, 'a link is { rel[, dir][, from][, note] } (V3)'); return; }
      if (l.rel === 'contradicts') { E(where, 'contradicts never stands in a chain: it is to be resolved (A6, V3)'); return; }
      if (!CHAIN_RELS.has(l.rel)) { E(where, `rel ${JSON.stringify(l.rel)} is not a relation of §2.1 (V3)`); return; }
      if (l.dir != null && l.dir !== 'fwd' && l.dir !== 'back') E(where, `dir ${JSON.stringify(l.dir)}: fwd or back (V3)`);
      if (l.from != null && !(list.indexOf(l.from) >= 0 && list.indexOf(l.from) < i)) { E(where, `from ${l.from} is not a position before ${a} (V3)`); return; }
      const x = l.from || a, back = l.dir === 'back';
      if (l.rel === 'order' || l.rel === 'contrasts') {
        if (l.from) E(where, `an ${l.rel} link has no from (V3)`);
        if (l.rel === 'contrasts' && (typeof l.note !== 'string' || !l.note.trim())) E(where, 'a contrasts link needs a note naming what is set against what (V3)');
        const edge = [...depsOf(T, b, twins), ...depsOf(T, a, twins)].find(d => (d.id === a || d.id === b) && CHAIN_RELS.has(d.rel));
        if (edge) Wn(where, `an ${l.rel} link, but depends has an edge (${edge.rel}) between ${a} and ${b}: the link may name it`);
        return;
      }
      if (l.rel === 'continues') {
        const ok = back ? (byId.get(x) || {}).splitFrom === b : (byId.get(b) || {}).splitFrom === x;
        if (!ok) E(where, `continues needs ${back ? `${x} split from ${b}` : `${b} split from ${x}`} (splitFrom, V3)`);
        return;
      }
      const [later, earlier] = back ? [x, b] : [b, x];
      if (!depsOf(T, later, twins, { split: false }).some(d => d.id === earlier && d.rel === l.rel)) E(where, `no depends edge backs it: ${later} does not rest on ${earlier} by ${l.rel}${l.from ? ` (from ${l.from})` : ''} (V3)`);
    });
    // V6
    const want = shapeOf(T, list, links, twins);
    if (c.shape !== want) E(at, `shape ${JSON.stringify(c.shape)}, the links and the rows give ${want} (V6)`);
    if (errors.length > before) continue;
    good.push({ c, file, at });
  }
  // V2: mentions told in another chain of the same page; V3: joins backed by an edge from an earlier chain
  const computed = joinsOf(T, good.map(g => g.c));
  for (const { c, at } of good) {
    for (const id of c.mention) { const t = tellerOf.get(`${c.page}|${id}`); if (!t || t === c.id) E(at, `the mention ${id} is told in no other chain of ${c.page} (V2)`); }
    const can = computed.get(c.id) || [];
    for (const j of c.joins) if (!j || !can.some(x => x.from === j.from && x.to === j.to && x.rel === j.rel)) E(at, `the join ${j && j.from} → ${j && j.to} (${j && j.rel}) is not a depends edge from a row told in an earlier chain of ${c.page} to a told position (V3)`);
  }
  // V4: the leads
  const leadOf = new Map();
  for (const { c, at } of good) {
    if (c.lead == null) continue;
    const r = byId.get(c.lead), set = new Set([...c.rows, ...Object.values(c.twins)]);
    if (!r || r.kind !== 'story') { E(at, `the lead ${c.lead} is not a story row (V4)`); continue; }
    if (!(r.shownOn || []).some(so => so.page === c.page && so.section === c.section && so.role === 'chain')) E(at, `the lead ${c.lead} is not placed in ${c.page} · ${c.section} with role chain (V4)`);
    const rs = (r.depends || []).filter(d => d.rel === 'restates').map(d => d.id);
    if (rs.some(id => !set.has(id))) E(at, `the lead ${c.lead} restates ${rs.filter(id => !set.has(id)).join(', ')}, not rows of the chain (V4)`);
    if (leadOf.has(c.lead)) E(at, `the lead ${c.lead} leads ${leadOf.get(c.lead)} too (V4)`); else leadOf.set(c.lead, c.id);
  }
  for (const r of rows) if (r.kind === 'story' && (r.shownOn || []).some(so => so.role === 'chain') && !leadOf.has(r.id)) Wn(r.id, 'a story row of role chain that leads no chain: it is drawn nowhere');

  // V10: the spans (C1, C2, C3, C9, C10, C11 on the merged texts), then the story of each chain
  const byChain = new Map(good.map(g => [g.c.id, g.c]));
  const spansOf = new Map();
  for (const t of texts) {
    if (!isSpan(t)) continue;
    const c = byChain.get(t.chain), where = `span ${t.row} · ${t.chain} · ${t.span}`;
    if (t.register !== 'span' || t.chain == null || !Number.isInteger(t.span) || t.level !== 'learner') { E(where, 'a span is a learner text with register span, chain and span (V10)'); continue; }
    if (!c) { E(where, idSeen.has(t.chain) ? 'its chain was refused' : 'no chain of the owners\' files has this id (V10)'); continue; }
    const p = c.rows[t.span - 1];
    if (!p || (t.row !== p && t.row !== c.twins[p])) { E(where, `${t.row} is not position ${t.span} of ${c.id} or its twin (V10, C1)`); continue; }
    if (!spansOf.has(c.id)) spansOf.set(c.id, []);
    spansOf.get(c.id).push(t);
  }
  const story = new Map();
  for (const { c, at } of good) {
    const sp = spansOf.get(c.id) || [];
    const leadText = c.lead ? learnerFull.get(c.lead) : null;
    if (!sp.length) { story.set(c.id, 'none'); continue; }
    const before = errors.length;
    c.rows.forEach((p, i) => {
      for (const row of [p, c.twins[p]].filter(Boolean)) {
        const mine = sp.filter(t => t.span === i + 1 && t.row === row);
        const mode = row === p ? null : ((byId.get(row) || {}).visibleTo || [])[0];
        if (!mine.length) E(at, `no span ${i + 1} for ${row}: a chain with one span has them all (V10, C2)`);
        if (mine.length > 1) E(at, `${mine.length} spans ${i + 1} for ${row} (V10, C3)`);
        for (const t of mine) {
          if (mode && t.mode !== mode) E(at, `the span of the twin ${row} has mode ${t.mode}, its row's is ${mode} (V10, C11)`);
          if (!mode && t.mode !== 'both' && !((byId.get(row) || {}).visibleTo || []).includes(t.mode)) E(at, `the span ${i + 1} of ${row} has mode ${t.mode} (V10)`);
          const h = humanLearner.get(row);
          if (h && !c.mention.includes(p) && (t.body !== h.body || t.status !== 'human')) E(at, `${row} has a human learner text: its span is that text, verbatim, status human (V10, C10)`);
        }
      }
    });
    if (c.lead && !leadText) E(at, `the lead ${c.lead} has no learner text: no partial story (V10, C2)`);
    if (errors.length > before) continue;
    const all = [...sp, ...(leadText ? [leadText] : [])];
    story.set(c.id, all.every(t => t.status === 'reviewed' || t.status === 'human') ? 'reviewed' : 'draft');
  }

  // V9: the round-14 rows
  const status = id => statusOf(T, id);
  const reserved = tables.reserved || new Set();
  const sectionRows = (route, section) => {
    const p = pageOf(route) || {}, parent = p.parent;
    const list = rows.filter(r => r.kind !== 'story' && research.has(r.id) && (r.shownOn || []).some(so => (so.page === route && (section === 'intro' || so.section === section)) || (parent != null && so.page === parent)));
    const h = p.hero && p.hero.row; if (h && research.has(h) && !list.some(r => r.id === h)) list.push(byId.get(h));
    return list.filter(Boolean).map(r => testRow(r.id, research.get(r.id).body, status(r.id)));
  };
  let storyRows = 0, newRows = 0;
  for (const { rec: r0, file } of overlay.rows) {
    const r = r0 && byId.get(r0.id), at = `${file} ${r0 && r0.id}`;
    if (!r) continue;   // merge_story refused it (an id of the tables) or never added it
    const m = STORY_ID.exec(r.id), n = m ? Number(m[2]) : 0, t = research.get(r.id);
    if (!m || m[1] !== r.group) E(at, `an id <GROUP>-<3 digits> of its group ${r.group} (V9)`);
    if (!SINCES.has(r.since)) E(at, `since ${JSON.stringify(r.since)}, not ${[...SINCES].map(s => `"${s}"`).join(' or ')} (V9)`);
    if ((r.evidence || []).length) E(at, 'a round-14 row cites no evidence (V9)');
    if (!t) E(at, 'no research text (V9)');
    else if (typeof t.source !== 'string' || !t.source.trim()) E(at, 'its research text names its source (V9)');
    if (r.kind === 'story') {
      storyRows++;
      if (n < 701 || n > 799) E(at, 'a round-14 story row has an id 701–799 of its group (D60, V9)');
      if (reserved.has(r.id)) E(at, 'content/story/ids.json or pending.json reserves this id (V9)');
      if (!same(r.notions, ['i-meta'])) E(at, 'notions must be ["i-meta"] (V9)');
      if (r.stage !== 'M' || r.ptype != null) E(at, 'stage M and no ptype, as every story row (V9)');
      const so = r.shownOn || [];
      if (so.length !== 1) { E(at, `${so.length} placements (one, V9)`); continue; }
      if (!pageOf(so[0].page)) E(at, `page ${so[0].page} is not a route (V9)`);
      for (const d of r.depends || []) if (d.rel !== 'restates' || !byId.has(d.id) || (byId.get(d.id) || {}).kind === 'story') E(at, `depends ${d.id} ${d.rel}: only restates, of rows that are not narration (V9)`);
      if (!learnerFull.has(r.id)) Wn(at, 'no learner text yet (the storyteller writes it; the row is not drawn at learner level meanwhile)');
      if (t) {
        const led = so[0].role === 'chain' ? good.find(g => g.c.lead === r.id) : null;
        const pool = led ? [...led.c.rows, ...Object.values(led.c.twins)].filter(id => research.has(id)).map(id => testRow(id, research.get(id).body, status(id))) : sectionRows(so[0].page, so[0].section);
        const res = testBlock(t.body, { rows: pool });
        if (res.outcome !== 'story') E(at, `fails T4/T5 against ${led ? `its chain ${led.c.id}` : `${so[0].page} · ${so[0].section}`}: ${[...res.uncovered.map(u => `uncovered ${u}`), ...res.missingStatus.map(s => `status word missing for ${s}`)].join('; ') || res.signals.join(', ')} (V9)`);
      }
    } else {
      newRows++;
      if (!['reading', 'question'].includes(r.kind)) E(at, `kind ${r.kind}: a new statement row is a reading or a question (§2.5, V9)`);
      if (!Array.isArray(r.notions) || !r.notions.length || same(r.notions, ['i-meta'])) E(at, 'a new statement row is labelled (notions, §2.5)');
      if ((r.homePhys || '') !== '' || (r.homeMath || '') !== '') E(at, 'homePhys and homeMath "" (§2.5)');
      for (const d of r.depends || []) if (!['derives', 'uses-input', 'instance', 'equiv'].includes(d.rel)) E(at, `depends ${d.id} ${d.rel}: derives or uses-input (§2.5)`);
      if (!(r.shownOn || []).some(so => TOLD_ROLES.has(so.role || 'result'))) E(at, 'a new statement row has its home: a placement of role result or detail (§2.5)');
    }
  }

  // ---- the section fields (§2.3) and the merged table
  const touched = new Set();
  for (const p of pages) for (const s of p.sections) if ('chains' in s) { delete s.chains; touched.add(p.route); Wn(`${p.route} · ${s.id}`, 'a section field chains is written by merge_chains, never typed: removed'); }
  const secIndex = (route, id) => ((pageOf(route) || {}).sections || []).findIndex(s => s.id === id);
  const ok = good.filter(g => !errors.some(e => e.startsWith(g.at + ':'))).map(g => g.c);
  const table = ok.map(c => { const o = {}; for (const k of RECORD_KEYS) o[k] = k === 'story' ? story.get(c.id) || 'none' : c[k] === undefined ? (k === 'lead' ? null : c[k]) : c[k]; return o; })
    .sort((a, b) => cmpStr(a.page, b.page) || secIndex(a.page, a.section) - secIndex(b.page, b.section) || a.order - b.order);
  for (const c of table) { const s = sectionOf(c.page, c.section); if (!s) continue; s.chains = [...(s.chains || []), c.id]; touched.add(c.page); }
  const summary = { chains: table.length, storied: table.filter(c => c.story !== 'none').length, reviewed: table.filter(c => c.story === 'reviewed').length,
    spans: [...spansOf.values()].reduce((n, l) => n + l.length, 0), storyRows, newRows, pages: [...new Set(table.map(c => c.page))].length };
  return { rows, texts, pages, chains: table, touched: [...touched].sort(cmpStr), errors, warnings, summary };
}

// ------------------------------------------------------------------------------------------------------------------------------- --retire
/**
 * D54's retirement: the translator drafts (level learner, register full, status draft or reviewed, source translator:…) of the rows whose every placement
 * is a told position (or its twin) of a storied chain leave content/texts_learner*.json for content/chains/retired.json, each with its wave and its file;
 * human texts never move, nor a short or caption draft (no span replaces those: they serve the page top, the cards and the figures). Reads the merged tables (content/chains.json, rows.json). Idempotent: a draft already retired is no longer in a file.
 * D66 (round 15): a page's hero (content/pages.json, hero.row) that has no short learner text keeps its full draft: the page top draws the hero's short
 * register when the row has one, else its full text (src/components/Hero.jsx, PageTop.jsx), and no span reaches the top, so retiring that draft would
 * leave the top without learner words (EQN-003, the hero of steps/comm). A hero with a short learner text gives its full draft up as any told row.
 * Returns { rows (the rows retired), moved, files, heroes (the told heroes whose full drafts stay, each without a short learner text), superseded (the rows
 * whose storyteller full text replaces their translator draft, D68) }.
 */
export function retire(wave, { content = C } = {}) {
  if (typeof wave !== 'string' || !wave.trim()) throw new Error('merge_chains --retire "<wave>": name the wave (the release, 2.15.0)');
  const chains = readJSON(path.join(content, 'chains.json'), []), rows = readJSON(path.join(content, 'rows.json'), []);
  const pages = readJSON(path.join(content, 'pages.json'), []), texts = readJSON(path.join(content, 'texts.json'), []);
  const told = new Set();
  for (const c of chains) if (c.story === 'draft' || c.story === 'reviewed') for (const id of toldOf(c)) for (const x of [id, (c.twins || {})[id]].filter(Boolean)) told.add(`${c.page}|${c.section}|${x}`);
  const eligible = new Set(rows.filter(r => (r.shownOn || []).length && r.shownOn.every(so => told.has(`${so.page}|${so.section}|${r.id}`))).map(r => r.id));
  // D66: the heroes without a short learner text (any status, lens none, outside a chain) keep their full drafts
  const short = new Set(texts.filter(t => t && t.level === 'learner' && t.register === 'short' && t.lens == null && t.chain == null).map(t => t.row));
  const heroes = [...new Set(pages.map(p => p && p.hero && p.hero.row).filter(Boolean))].filter(id => eligible.has(id) && !short.has(id)).sort(cmpStr);
  // D68 (round 16): a row whose learner full text the storyteller has written (content/chains/learner/*.json, register full, lens none, mode both)
  // is superseded whether told or a side note, hero or not: its translator draft retires with it
  const learnerDir = path.join(content, 'chains', 'learner');
  const superseded = new Set();
  if (fs.existsSync(learnerDir)) for (const n of fs.readdirSync(learnerDir).filter(n => n.endsWith('.json')).sort()) {
    const recs = readJSON(path.join(learnerDir, n), []);
    if (Array.isArray(recs)) for (const r of recs) if (r && r.level === 'learner' && (r.register || 'full') === 'full' && r.lens == null && (r.mode || 'both') === 'both' && /^storyteller@/.test(r.source || '')) superseded.add(r.row);
  }
  const out = new Set([...[...eligible].filter(id => !heroes.includes(id)), ...superseded]);
  const retiredFile = path.join(content, 'chains', 'retired.json');
  const retired = readJSON(retiredFile, []);
  let moved = 0; const files = [];
  for (const n of fs.readdirSync(content).filter(n => /^texts_learner.*\.json$/.test(n)).sort()) {
    const f = path.join(content, n), recs = readJSON(f, []);
    if (!Array.isArray(recs)) continue;
    const keep = [], go = [];
    // the full register only: inside a chain a span replaces the row's learner full text (D54's fallback); a short or caption draft serves the page
    // top, a card or a figure outside the chains and stays (the hero of shifted shows ATY-005's short learner text, STORY_ROUND.md §6.1)
    for (const r of recs) (r && out.has(r.row) && r.level === 'learner' && (r.register || 'full') === 'full' && (r.status === 'draft' || r.status === 'reviewed') && /^translator:/.test(r.source || '') ? go : keep).push(r);
    if (!go.length) continue;
    for (const r of go) retired.push({ wave, from: `content/${n}`, ...r });
    fs.writeFileSync(f, JSON.stringify(keep, null, 1) + '\n');
    moved += go.length; files.push(n);
  }
  if (moved) {
    retired.sort((a, b) => cmpStr(a.row, b.row) || cmpStr(a.from, b.from) || cmpStr(a.register || 'full', b.register || 'full') || cmpStr(a.wave, b.wave));
    fs.mkdirSync(path.dirname(retiredFile), { recursive: true });
    fs.writeFileSync(retiredFile, JSON.stringify(retired, null, 1) + '\n');
  }
  return { rows: [...out].sort(cmpStr), moved, files, heroes: heroes.filter(id => !superseded.has(id)), superseded: [...superseded].sort(cmpStr) };
}
/** the keys (row, level, mode, lens, register) of the retired drafts: tools/merge_learner_texts.mjs drops them from texts.json */
export function retiredKeys(content = C) {
  return new Set(readJSON(path.join(content, 'chains', 'retired.json'), []).map(r => [r.row, r.level, r.mode || 'both', r.lens || '', r.register || 'full'].join('|')));
}

// ------------------------------------------------------------------------------------------------------------------------------- CLI
async function main(argv) {
  if (argv.includes('--retire')) {
    const wave = argv[argv.indexOf('--retire') + 1];
    try { const r = retire(wave); console.log(`merge_chains --retire ${wave}: ${r.moved} draft(s) of ${r.rows.length} row(s) told only in storied chains moved to ${rel(RETIRED)}${r.files.length ? ` (from ${r.files.join(', ')})` : ''}${r.heroes.length ? `; kept, heroes without a short learner text (D66): ${r.heroes.join(', ')}` : ''}; run npm run content`); return 0; }
    catch (e) { console.log(e.message); return 1; }
  }
  if (argv.includes('--check')) {
    const { mergeStory } = await import('./merge_story.mjs');
    const res = mergeStory();
    const mine = (res.chainWarnings || []);
    if (mine.length) console.log(mine.slice(0, 40).map(w => 'warning ' + w).join('\n'));
    const s = res.chainSummary || {};
    if (res.errors.length) { console.log(res.errors.slice(0, 80).map(e => 'ERROR ' + e).join('\n')); console.log(`merge_chains --check: ${res.errors.length} error(s) in the merge (merge_story would write nothing)`); return 1; }
    console.log(`merge_chains --check: ${s.chains || 0} chains on ${s.pages || 0} page(s), ${s.storied || 0} storied (${s.reviewed || 0} reviewed), ${s.spans || 0} spans; round-14 rows: ${s.storyRows || 0} story rows, ${s.newRows || 0} statement rows`);
    return 0;
  }
  console.log('merge_chains: --check, or --retire "<wave>" (the merge itself runs inside tools/merge_story.mjs)');
  return 1;
}
// no top-level await: merge_story imports this module, and --check imports merge_story back once this module has loaded
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main(process.argv.slice(2)).then(code => process.exit(code), e => { console.log(e && e.stack ? e.stack : e); process.exit(1); });
