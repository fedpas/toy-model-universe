#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""tools/tutorials/figs_zero.py -- the four figures of the tutorial "The rule from zero" (content/tutorials.json, id zero), drawn from the bit rule
of the Atlas: the products and signs come from Alg.blade_mul of checks/selfcheck/steps15_17/bitcliff.py, imported by path, never typed.

  cube_labels.svg     the labels at n = 1, 2, 3: every setting of the switches, by grade, an edge where one switch flips
  sign_cl20.svg       the sign table of Cl(2,0): each sign s(a,b) with its two ingredients, the swap count N(a,b) and the shared switches
  three_algebras.svg  the product tables at n = 2 for the squares (+,+), (-,-), (0,0), with the counts of zero products and of minus signs
  clock.svg           every Cl(p,q) with p + q <= 4 at the phase of its Gauss sum, the sum of i^w(a) over its blades (w from the blade squares)

It also checks the ten products that widgets/product.js stores for its self-test against the same rule, and fails if one differs.
The SVG is written by hand: text as text, no raster, the colours as the tutorial page's variables with a fallback, so that the page's light
and dark looks both read; deterministic (the same script gives the same bytes).
  python3 -I -B tools/tutorials/figs_zero.py [--out DIR]
The repository root is ATLAS_REPO when set, else ../../ from this file; the figures go to public/reports/tutorials/src/zero/figs/ (or DIR)."""
import importlib.util
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.environ.get('ATLAS_REPO') or os.path.join(HERE, '..', '..'))
SRC = os.path.join(ROOT, 'public', 'reports', 'tutorials', 'src', 'zero')
OUT = sys.argv[sys.argv.index('--out') + 1] if '--out' in sys.argv else os.path.join(SRC, 'figs')

_spec = importlib.util.spec_from_file_location('bitcliff', os.path.join(ROOT, 'checks', 'selfcheck', 'steps15_17', 'bitcliff.py'))
bitcliff = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(bitcliff)
Alg, sig = bitcliff.Alg, bitcliff.sig

SUB = str.maketrans('0123456789', '₀₁₂₃₄₅₆₇₈₉')
def blade(mask):
    on = [i + 1 for i in range(8) if mask >> i & 1]
    return 'e' + ''.join(str(i) for i in on).translate(SUB) if on else '1'
def pairs(a, b):
    """N(a,b): the pairs (i in a, j in b) with j < i, the swaps that sort the word ab"""
    return sum(1 for i in range(8) if a >> i & 1 for j in range(i) if b >> j & 1)
def shared(a, b):
    m = a & b
    return [i + 1 for i in range(8) if m >> i & 1]
def esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
def f(x):
    return ('%.1f' % x).rstrip('0').rstrip('.')

STYLE = ('.zf text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;fill:var(--ink,#1a1a19)}'
         '.zf .m{fill:var(--muted,#6b6b64)}.zf .b{font-weight:600}.zf .mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}'
         '.zf .ln{stroke:var(--line2,#c9c8c0);fill:none}.zf .bx{fill:var(--surf,#fff);stroke:var(--line2,#c9c8c0)}'
         '.zf .neg{fill:var(--tint,#f3f2ee);stroke:var(--line2,#c9c8c0)}.zf .zero{fill:none;stroke:var(--line2,#c9c8c0);stroke-dasharray:3 3}'
         '.zf .cell{fill:none;stroke:var(--line,#e3e2dc)}.zf .on{fill:var(--ink,#1a1a19)}.zf .off{fill:none;stroke:var(--muted,#6b6b64)}'
         '.zf .acc{fill:var(--acc,#184f95)}.zf .sacc{stroke:var(--acc,#184f95);fill:none}'
         '.zf .s1{stroke:#c8501a;fill:none;stroke-width:2}.zf .s2{stroke:#24875a;fill:none;stroke-width:2;stroke-dasharray:6 4}'
         '.zf .s3{stroke:var(--acc,#184f95);fill:none;stroke-width:2;stroke-dasharray:2 3}')

def svg(name, w, h, title, desc, body):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" class="zf" viewBox="0 0 {w} {h}" width="{round(w * 1.4)}" height="{round(h * 1.4)}" '
            f'role="img" aria-labelledby="{name}-t {name}-d"><title id="{name}-t">{esc(title)}</title><desc id="{name}-d">{esc(desc)}</desc>'
            f'<style>{STYLE}</style>{"".join(body)}</svg>\n')
def text(x, y, s, size=13, cls='', anchor='middle', extra=''):
    c = f' class="{cls}"' if cls else ''
    return f'<text x="{f(x)}" y="{f(y)}" font-size="{size}" text-anchor="{anchor}"{c}{extra}>{esc(s)}</text>'
def rect(x, y, w, h, cls, rx=0):
    return f'<rect x="{f(x)}" y="{f(y)}" width="{f(w)}" height="{f(h)}" rx="{rx}" class="{cls}"/>'
def line(x1, y1, x2, y2, cls):
    return f'<line x1="{f(x1)}" y1="{f(y1)}" x2="{f(x2)}" y2="{f(y2)}" class="{cls}"/>'

# ---------------------------------------------------------------- 1. the labels at n = 1, 2, 3
def node(x, y, mask, n):
    out = [rect(x - 30, y - 19, 60, 38, 'bx', 7), text(x, y - 2, blade(mask), 15)]
    for i in range(n):                                   # the switches, switch 1 first: filled when on
        sx = x - 7 * n + 3 + 14 * i
        out.append(rect(sx - 1, y + 6, 9, 9, 'on' if mask >> i & 1 else 'off', 1))
    return out
def lattice(n, cx, top, dy, dx):
    pos = {}
    for k in range(n + 1):
        masks = [m for m in range(1 << n) if bin(m).count('1') == k]
        for j, m in enumerate(masks):
            pos[m] = (cx + (j - (len(masks) - 1) / 2) * dx, top + (n - k) * dy)
    body = []
    for m in range(1 << n):
        for i in range(n):
            if not m >> i & 1:
                (x1, y1), (x2, y2) = pos[m], pos[m | 1 << i]
                body.append(line(x1, y1, x2, y2, 's%d' % (i + 1)))
    for m in range(1 << n):
        body += node(*pos[m], m, n)
    return body
def fig_cube():
    W, H = 380, 500
    b = [text(60, 22, 'n = 1 · 2 labels', 13, 'm'), text(250, 22, 'n = 2 · 4 labels', 13, 'm')]
    b += lattice(1, 60, 54, 76, 0)
    b += lattice(2, 250, 54, 62, 88)
    b += [text(190, 222, 'n = 3 · 8 labels', 13, 'm')]
    b += lattice(3, 190, 256, 64, 92)
    ly = 490
    for i, (x, w) in enumerate([(14, 'switch 1 flips'), (138, 'switch 2 flips'), (262, 'switch 3 flips')]):
        b += [line(x, ly - 4, x + 26, ly - 4, 's%d' % (i + 1)), text(x + 32, ly, w, 12, '', 'start')]
    return svg('zf1', W, H, 'The labels at n = 1, 2, 3',
               'Every setting of n switches is a label; the labels are drawn by the number of switches on, with an edge where one switch flips: '
               'a segment, a square and a cube.', b)

# ---------------------------------------------------------------- 2. the sign table of Cl(2,0), each sign with its swaps and shared switches
def fig_sign():
    alg, n = Alg(sig(2, 0)), 2
    W, H, x0, y0, cw, ch = 380, 318, 76, 64, 75, 60
    b = [text(x0 + 2 * cw, 18, 'b', 13, 'm b'), text(16, y0 + 2 * ch, 'a', 13, 'm b')]
    for j in range(4):
        b.append(text(x0 + j * cw + cw / 2, 44, blade(j), 15, 'b'))
        b.append(text(x0 - 22, y0 + j * ch + ch / 2 + 5, blade(j), 15, 'b'))
    for a in range(4):
        for c in range(4):
            s, _ = alg.blade_mul(a, c)
            x, y = x0 + c * cw, y0 + a * ch
            b.append(rect(x + 2, y + 2, cw - 4, ch - 4, 'neg' if s < 0 else 'cell', 6))
            b.append(text(x + cw / 2, y + 27, '−' if s < 0 else '+', 22, 'b'))
            sh = shared(a, c)
            b.append(text(x + cw / 2, y + 46, f'N={pairs(a, c)} · ' + ('{' + ','.join(map(str, sh)) + '}' if sh else '∅'), 10.5, 'm mono'))
    b.append(text(W / 2, H - 6, 'sign = (−1)^N × the squares of the shared switches', 11, 'm'))
    return svg('zf2', W, H, 'The sign table of Cl(2,0)',
               'Row a, column b: the sign s(a,b) of the product e_a e_b in Cl(2,0), with the swap count N(a,b) and the set of switches on in both; '
               'four of the sixteen signs are minus.', b)

# ---------------------------------------------------------------- 3. one rule, three algebras at n = 2
CASES = [((1, 1), 'squares (+,+)', 'Cl(2,0) ≅ M₂(ℝ)'), ((-1, -1), 'squares (−,−)', 'Cl(0,2) ≅ ℍ'), ((0, 0), 'squares (0,0)', 'Cl(0,0,2) = Λ(ℝ²)')]
def table_counts(eps):
    alg = Alg(eps)
    zero = sum(1 for a in range(4) for c in range(4) if alg.blade_mul(a, c)[0] == 0)
    minus = sum(1 for a in range(4) for c in range(4) if alg.blade_mul(a, c)[0] < 0)
    return zero, minus
def fig_three():
    W, H, cw, ch, top = 380, 500, 40, 26, 30
    b = []
    for k, (eps, head, name) in enumerate(CASES):
        alg = Alg(eps)
        y0 = top + k * 160
        x0 = 44
        b.append(text(4, y0 - 8, head, 13, 'b', 'start'))
        for j in range(4):
            b.append(text(x0 + j * cw + cw / 2, y0 + 14, blade(j), 13, 'm b'))
            b.append(text(x0 - 6, y0 + (j + 1) * ch + 17, blade(j), 13, 'm b', 'end'))
        for a in range(4):
            for c in range(4):
                s, m = alg.blade_mul(a, c)
                x, y = x0 + c * cw, y0 + (a + 1) * ch
                b.append(rect(x + 1, y + 1, cw - 2, ch - 2, 'neg' if s < 0 else 'zero' if s == 0 else 'cell', 4))
                b.append(text(x + cw / 2, y + 18, '0' if s == 0 else ('−' if s < 0 else '+') + blade(m), 13, 'm' if s == 0 else ''))
        zero, minus = table_counts(eps)
        tx = x0 + 4 * cw + 18
        b.append(text(tx, y0 + 40, name, 14, 'b', 'start'))
        b.append(text(tx, y0 + 64, f'{zero} of 16 products are 0', 12, '', 'start'))
        b.append(text(tx, y0 + 84, f'{minus} carr{"ies" if minus == 1 else "y"} a minus sign', 12, '', 'start'))
        sq = ', '.join(f'{blade(1 << i)}² = {"+1" if e > 0 else "−1" if e < 0 else "0"}' for i, e in enumerate(eps))
        b.append(text(tx, y0 + 104, sq, 12, 'm', 'start'))
    return svg('zf3', W, H, 'One rule, three algebras at n = 2',
               'The product tables of the bit rule on two switches for the squares (+,+), (−,−) and (0,0): the same labels and the same XOR, '
               'three algebras; the counts of zero products and of minus signs are printed beside each table.', b)

# ---------------------------------------------------------------- 4. the clock: the phase of the Gauss sum of every Cl(p,q) with p + q <= 4
TYPE = ['ℝ', 'ℝ ⊕ ℝ', 'ℝ', 'ℂ', 'ℍ', 'ℍ ⊕ ℍ', 'ℍ', 'ℂ']        # the matrix types at the eight positions (bitcliff.TYPES, the mod-8 table)
def gauss(p, q):
    """the Gauss sum of i^w over the 2^n blades of Cl(p,q), w = parity + 2 [e_a^2 = -1], as an exact Gaussian integer (re, im)"""
    alg = Alg(sig(p, q)); re_, im_ = 0, 0
    for a in range(1 << (p + q)):
        w = (bin(a).count('1') % 2 + (2 if alg.sq(a) < 0 else 0)) % 4   # w = parity + 2 Q, Q(a) = [e_a^2 = -1]
        dr, di = [(1, 0), (0, 1), (-1, 0), (0, -1)][w]
        re_, im_ = re_ + dr, im_ + di
    return re_, im_
def phase8(z):
    """the position 0..7 of a Gaussian integer on one of the eight directions (exact: the signs of re, im and whether |re| = |im|)"""
    re_, im_ = z
    dirs = {(1, 0): 0, (1, 1): 1, (0, 1): 2, (-1, 1): 3, (-1, 0): 4, (-1, -1): 5, (0, -1): 6, (1, -1): 7}
    sg = lambda v: (v > 0) - (v < 0)
    if re_ and im_ and abs(re_) != abs(im_):
        raise SystemExit(f'figs_zero: the Gauss sum {z} is on none of the eight directions')
    return dirs[(sg(re_), sg(im_))]
def cmul(z, u):
    return (z[0] * u[0] - z[1] * u[1], z[0] * u[1] + z[1] * u[0])
def fig_clock():
    import math
    cells = {}
    for n in range(5):
        for p in range(n + 1):
            q = n - p
            z = gauss(p, q)
            want = (1, 0)
            for _ in range(p): want = cmul(want, (1, 1))
            for _ in range(q): want = cmul(want, (1, -1))
            if z != want: raise SystemExit(f'figs_zero: the Gauss sum of Cl({p},{q}) is {z}, not (1+i)^p (1-i)^q = {want}')
            c = phase8(z)
            if c != (p - q) % 8: raise SystemExit(f'figs_zero: Cl({p},{q}) lands at {c}, not at p - q mod 8 = {(p - q) % 8}')
            cells.setdefault(c, []).append((p, q))
    W, H, cx, cy, r = 380, 400, 190, 196, 92
    b = [f'<circle cx="{cx}" cy="{cy}" r="{r}" class="ln"/>', line(cx - r, cy, cx + r, cy, 'ln'), line(cx, cy - r, cx, cy + r, 'ln')]
    for c in range(8):
        t = math.pi * c / 4
        px, py = cx + r * math.cos(t), cy - r * math.sin(t)
        b.append(line(cx, cy, px, py, 'sacc'))
        b.append(f'<circle cx="{f(px)}" cy="{f(py)}" r="12" class="bx"/>')
        b.append(text(px, py + 5, str(c), 13, 'b'))
        lx, ly = cx + (r + 44) * math.cos(t), cy - (r + 40) * math.sin(t)
        anchor = 'start' if math.cos(t) > 0.3 else 'end' if math.cos(t) < -0.3 else 'middle'
        if anchor == 'start': lx -= 14
        if anchor == 'end': lx += 14
        rows = [TYPE[c]] + [f'Cl({p},{q})' for p, q in sorted(cells.get(c, []), key=lambda x: (x[0] + x[1], x[0]))]
        y = ly - 8 * (len(rows) - 1) + 4
        for k, s in enumerate(rows):
            b.append(text(lx, y + 16 * k, s, 13 if k == 0 else 12, 'b' if k == 0 else '', anchor))
    b.append(text(W / 2, H - 6, 'position c: the phase of Σ i^w(a) is 45° × c from the real axis', 11, 'm'))
    return svg('zf4', W, H, 'The clock', 'Every cell Cl(p,q) with p + q at most 4, placed at the phase of its Gauss sum, the sum of i to the power w(a) over its blades; '
               'the eight positions carry the matrix types of the mod-8 table.', b), cells

# ---------------------------------------------------------------- the widget's stored products, checked against the same rule
def check_widget():
    wf = os.path.join(SRC, 'widgets', 'product.js')
    if not os.path.exists(wf):
        print('figs_zero: widgets/product.js not found; its stored products are not checked'); return 0
    m = re.search(r'const STORED = (\[[\s\S]*?\]);', open(wf, encoding='utf-8').read())
    if not m: raise SystemExit('figs_zero: widgets/product.js has no STORED list')
    stored = json.loads(m.group(1))
    for eps, a, b, s, c in stored:
        got = Alg(eps).blade_mul(a, b)
        if (got[0], got[1]) != (s, c): raise SystemExit(f'figs_zero: the widget stores {eps} {a}·{b} = {s}·e[{c}], the rule gives {got}')
    return len(stored)

if __name__ == '__main__':
    os.makedirs(OUT, exist_ok=True)
    clock, cells = fig_clock()
    figs = [('cube_labels.svg', fig_cube()), ('sign_cl20.svg', fig_sign()), ('three_algebras.svg', fig_three()), ('clock.svg', clock)]
    for name, s in figs:
        if len(s.encode('utf-8')) >= 80 * 1024: raise SystemExit(f'figs_zero: {name} is {len(s)} bytes, over 80 kB')
        with open(os.path.join(OUT, name), 'w', encoding='utf-8', newline='\n') as fh: fh.write(s)
    counts = {head: table_counts(eps) for eps, head, _ in CASES}
    print('figs_zero: ' + ', '.join(f'{n} ({len(s.encode("utf-8"))} bytes)' for n, s in figs))
    print('figs_zero: zero products and minus signs at n = 2: ' + '; '.join(f'{h} {z} and {m}' for h, (z, m) in counts.items()))
    print('figs_zero: the clock: ' + '; '.join(f'{c}: ' + ' '.join(f'Cl({p},{q})' for p, q in sorted(v)) for c, v in sorted(cells.items())))
    print(f'figs_zero: {check_widget()} stored products of widgets/product.js agree with bitcliff.Alg.blade_mul')
