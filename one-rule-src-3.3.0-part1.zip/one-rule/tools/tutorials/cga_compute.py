#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# cga_compute.py: the numbers of the tutorial "The conformal model on the bit rule". Every product is the Atlas's bit rule
# (checks/researchers_checks/bitrule_A.py of the repository, imported by path), in exact rationals. Deterministic.
#   python3 -I -B cga_compute.py          prints the lines the page quotes, each with its id (A1.1, B2.3 ...)
# The repository is found two folders up from this file (tools/tutorials/), or at $ATLAS_REPO.
import os, importlib.util, json, random
from fractions import Fraction as F
from itertools import combinations

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.environ.get('ATLAS_REPO') or os.environ.get('CGA_REPO') or os.path.normpath(os.path.join(HERE, '..', '..'))   # the repository: ATLAS_REPO, else two folders up


def _load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m


BA = _load('bitrule_A', os.path.join(REPO, 'checks', 'researchers_checks', 'bitrule_A.py'))
popc = BA.popcount

# ---- the cell (4,1): bits 0..4 are e1, e2, e3 (square +1), e+ (square +1), e- (square -1), the Atlas's order (p first, then q)
EPS = (1, 1, 1, 1, -1)
NAMES = ('1', '2', '3', '+', '-')
SUB = {'1': '₁', '2': '₂', '3': '₃', '+': '₊', '-': '₋'}
A = BA.BR(EPS)            # the geometric product: the bit rule
W = BA.BR((0,) * 5)       # the outer product: the same rule with every square 0 (the exterior algebra)
FULL = 31


def lab(a, names=NAMES):
    if a == 0:
        return '1'
    return 'e' + ''.join(SUB[names[i]] for i in range(len(names)) if (a >> i) & 1)


def clean(x): return {k: F(v) for k, v in x.items() if v != 0}
def add(x, y, c=1): return clean(A.add(x, y, c))
def scal(x, c): return clean(A.scal(x, F(c)))
def gp(x, y): return clean(A.mul(x, y))
def op(x, y): return clean(W.mul(x, y))
def s0(x): return x.get(0, F(0))
def grade(x, k): return {a: v for a, v in x.items() if popc(a) == k}
def grades(x): return sorted({popc(a) for a in x})
def rev(x): return {a: v * (-1 if (popc(a) * (popc(a) - 1) // 2) % 2 else 1) for a, v in x.items()}
def inv(x): return {a: v * (-1 if popc(a) % 2 else 1) for a, v in x.items()}


def lc(x, y):
    """left contraction: the bit rule kept on the label pairs with a inside b"""
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            if a & b == a:
                s = A.s(a, b)
                if s:
                    out[a ^ b] = out.get(a ^ b, 0) + s * ca * cb
    return clean(out)


def sp(x, y):
    """scalar product: the bit rule kept on equal labels"""
    return sum((A.s(a, a) * ca * y[a] for a, ca in x.items() if a in y), F(0))


I5 = {FULL: F(1)}
I5INV = scal(I5, -1)                       # I^2 = -1 (checked below), so I^-1 = -I
def dual(x): return gp(x, I5INV)           # the inner-product null space form of a blade
def undual(x): return gp(x, I5)
def meet(x, y): return undual(op(dual(x), dual(y)))


EP, EM = {8: F(1)}, {16: F(1)}
EINF = {8: F(1), 16: F(1)}                 # e_inf = e- + e+
EO = {8: F(-1, 2), 16: F(1, 2)}            # e_o = (e- - e+)/2
def vec(x, y, z=0): return clean({1: F(x), 2: F(y), 4: F(z)})
def P(x): return add(add(EO, vec(*x)), EINF, F(sum(F(t) * F(t) for t in x), 2))
def dot(u, v): return sp(u, v)
def eq(x, y): return clean(x) == clean(y)
def prop(x, y):
    """x = c y for one non-zero rational c (returns c, or None)"""
    x, y = clean(x), clean(y)
    if set(x) != set(y) or not x:
        return None
    k = next(iter(x)); c = x[k] / y[k]
    return c if all(x[a] == c * y[a] for a in x) else None


def loc(v):
    """the Euclidean point of a vector of the form w (e_o + x + ...)"""
    w = -dot(v, EINF)
    return tuple(v.get(m, F(0)) / w for m in (1, 2, 4))


def is_flat(X): return not op(X, EINF)
def center(X): return loc(gp(gp(X, EINF), X))
def radius2(X):
    """the square of the radius of a round blade X of any grade: X X^ / (e_inf ⌋ X)^2"""
    d = lc(EINF, X)
    return s0(gp(X, inv(X))) / s0(gp(d, d))


def pair_points(X):
    """the two points of a real point pair X: (X ± sqrt(X^2)) (e_inf ⌋ X), as floats"""
    x2 = float(s0(gp(X, X))); r = x2 ** 0.5; d = lc(EINF, X)
    out = []
    for sg in (1, -1):
        Y = add(X, {0: F(sg * r)}) if True else None
        v = {k: float(c) for k, c in gp({k: c for k, c in Y.items()}, d).items()}
        w = -(v.get(8, 0) * 1 + v.get(16, 0) * -1)      # -v . e_inf with e+^2 = 1, e-^2 = -1
        out.append(tuple(v.get(m, 0) / w for m in (1, 2, 4)))
    return out


def fmt(x, names=NAMES):
    x = clean(x)
    if not x:
        return '0'
    parts = []
    for a in sorted(x, key=lambda m: (popc(m), m)):
        c = x[a]; s = '-' if c < 0 else '+'; c = abs(c)
        cs = '' if (c == 1 and a) else str(c)
        parts.append(f'{s} {cs}{"" if not a else ("" if not cs else " ")}{lab(a, names) if a else ""}'.rstrip())
    out = ' '.join(parts)
    return out[2:] if out.startswith('+ ') else '-' + out[2:]


def tup(x): return '(' + ', '.join(ffr(v) for v in x) + ')'


def ffr(v):
    v = F(v)
    return str(v.numerator) if v.denominator == 1 else f'{v.numerator}/{v.denominator}'


# ---- the examples the page and the widget use (one place, so the figures and the text agree)
def ex_sphere(c, r2): return add(P(c), EINF, -F(r2) / 2)                 # dual sphere: P(c) - r^2/2 e_inf
def ex_plane(n, d): return add(vec(*n), EINF, F(d))                     # dual plane: n + d e_inf (the plane n.x = d)
def opns(*xs):
    out = {0: F(1)}
    for x in xs:
        out = op(out, x)
    return out


def rotor_rot(a, b):
    """R = a - b e12 (not normalised): R x R~ / (a^2 + b^2) turns the plane z = 0 by cos = (a^2-b^2)/(a^2+b^2), sin = 2ab/(a^2+b^2)"""
    return {0: F(a), 3: F(-b)}


def translator(t): return add({0: F(1)}, gp(vec(*t), EINF), F(-1, 2))  # T = 1 - t e_inf / 2


def sandwich(V, X):
    """V X V~ / (V V~) for an even V, and -V X V~ / (V V~) for an odd V (a vector mirror) applied to a blade"""
    nrm = s0(gp(V, rev(V)))
    odd = all(popc(a) % 2 for a in V)
    Y = gp(gp(V, X), rev(V))
    if odd:
        Y = inv(Y)
        Y = scal(Y, -1) if False else Y
    return scal(Y, F(1) / nrm)


# ---- PGA, the cell (3,0,1): bits 0..2 e1, e2, e3 (square +1), bit 3 e0 (square 0), the Atlas's order (the null generator last)
EPS_PGA = (1, 1, 1, 0)
PG = BA.BR(EPS_PGA)
PGA_NAMES = ('1', '2', '3', '0')
SUB['0'] = '₀'


def phi(m):
    """PGA label m -> its image in the cell (4,1): e_S -> e_S, e_S e0 -> e_S e_inf"""
    base = {m & 7: F(1)}
    return gp(base, EINF) if m & 8 else base


def main():
    out = []
    def pr(tag, s): out.append(f'{tag}  {s}')

    # ---------------------------------------------------------------- A1 the labels by grade, their squares
    sq = {a: A.s(a, a) for a in range(32)}
    for k in range(6):
        labs = [a for a in range(32) if popc(a) == k]
        pr('A1.%d' % (k + 1), f'grade {k}: {len(labs)} labels; squares: ' + ', '.join(f'{lab(a)} {"+" if sq[a] > 0 else "-"}' for a in labs))
    pos = sum(1 for a in sq if sq[a] > 0)
    pr('A1.7', f'{pos} labels square to +1 and {32 - pos} to -1 (none to 0: the cell has no null generator)')
    I2 = gp(I5, I5)
    central = all(eq(gp(I5, {1 << i: 1}), gp({1 << i: 1}, I5)) for i in range(5))
    pr('A1.8', f'the top label I = {lab(FULL)}: I^2 = {fmt(I2)}; I commutes with the five generators: {central}')

    # ---------------------------------------------------------------- A2 the row of five
    rows = []
    for p in range(5, -1, -1):
        q = 5 - p; e = (1,) * p + (-1,) * q; B = BA.BR(e)
        w2 = B.s(FULL, FULL)
        cen = all(B.mul({FULL: 1}, {1 << i: 1}) == B.mul({1 << i: 1}, {FULL: 1}) for i in range(5))
        rows.append((p, q, (p - q) % 8, w2, cen))
        pr('A2.%d' % (6 - p), f'cell ({p},{q}): clock (p - q) mod 8 = {(p - q) % 8}; top label squares to {w2:+d}; central: {cen}; centre span(1, I) is {"C (one simple algebra)" if w2 < 0 else "R + R (two ideals)"}')

    # ---------------------------------------------------------------- A3 the null pair
    E = op(EINF, EO)
    pr('A3.1', f'e_inf = {fmt(EINF)}, e_o = {fmt(EO)}')
    pr('A3.2', f'e_inf^2 = {fmt(gp(EINF, EINF))}, e_o^2 = {fmt(gp(EO, EO))}, e_o . e_inf = {ffr(dot(EO, EINF))}')
    pr('A3.3', f'e_inf e_o = {fmt(gp(EINF, EO))}; e_o e_inf = {fmt(gp(EO, EINF))}; E = e_inf ^ e_o = {fmt(E)}, E^2 = {fmt(gp(E, E))}')
    pr('A3.4', f'E e_inf = {fmt(gp(E, EINF))} (= -e_inf), E e_o = {fmt(gp(E, EO))} (= +e_o): the null pair are the two eigenvectors of E')
    pr('A3.5', f'e+ = {fmt(add(scal(EINF, F(1, 2)), EO, -1))} = e_inf/2 - e_o; e- = {fmt(add(scal(EINF, F(1, 2)), EO))} = e_inf/2 + e_o')

    # ---------------------------------------------------------------- A4 points
    for i, x in enumerate([(0, 0, 0), (1, 2, 2), (3, 4, 0)]):
        X = P(x)
        pr('A4.%d' % (i + 1), f'P{x} = {fmt(X)};  P^2 = {fmt(gp(X, X))}, P . e_inf = {ffr(dot(X, EINF))}')
    pairs = [((1, 2, 0), (4, 6, 0)), ((0, 0, 0), (1, 2, 2)), ((1, 1, 1), (-1, -1, -1)), ((F(1, 2), 0, 0), (0, F(1, 2), 0))]
    for i, (p, q) in enumerate(pairs):
        d2 = sum((F(a) - F(b)) ** 2 for a, b in zip(p, q))
        pr('A4.%d' % (i + 4), f'P{tup(p)} . P{tup(q)} = {ffr(dot(P(p), P(q)))};  -|p - q|^2 / 2 = {ffr(-d2 / 2)}')
    rng = random.Random(11); ok = 0; dist = []
    for _ in range(40):
        p = tuple(F(rng.randint(-6, 6), 2) for _ in range(3)); q = tuple(F(rng.randint(-6, 6), 2) for _ in range(3))
        d2 = sum((a - b) ** 2 for a, b in zip(p, q)); v = dot(P(p), P(q))
        ok += (v == -d2 / 2); dist.append((float(d2) ** 0.5, float(v)))
    pr('A4.8', f'40 random pairs with half-integer coordinates in [-3, 3]^3: P(p) . P(q) = -|p - q|^2 / 2 in {ok} of 40 (exact)')
    X = gp(P((1, 2, 0)), P((4, 6, 0)))
    pr('A4.9', f'P(1,2,0) P(4,6,0) = {fmt(X)}: scalar part -25/2 and a bivector, the point pair')

    # ---------------------------------------------------------------- B1 tests "x lies on it"
    S = dual(ex_sphere((0, 0, 0), 4)); S = undual(ex_sphere((0, 0, 0), 4))
    on, off = P((0, 0, 2)), P((1, 1, 1))
    pr('B1.1', f'sphere centre 0, radius 2: sigma = {fmt(ex_sphere((0, 0, 0), 4))}; its blade S = sigma I = {fmt(S)}')
    pr('B1.2', f'P(0,0,2) ^ S = {fmt(op(on, S))};  P(0,0,2) . sigma = {ffr(dot(on, ex_sphere((0, 0, 0), 4)))}  (on it)')
    pr('B1.3', f'P(1,1,1) ^ S = {fmt(op(off, S))};  P(1,1,1) . sigma = {ffr(dot(off, ex_sphere((0, 0, 0), 4)))}  (= -(|x - c|^2 - r^2)/2 = -(3 - 4)/2: inside)')
    chk = all(eq(dual(op(P(x), S)), lc(P(x), dual(S))) for x in [(0, 0, 2), (1, 1, 1), (3, -1, 2), (F(1, 2), 0, 5)])
    pr('B1.4', f'(P ^ S) I^-1 = P ⌋ (S I^-1) on four points: {chk}  (the two tests are one number)')

    # ---------------------------------------------------------------- B2 rounds
    a, b, c, d = P((2, 0, 0)), P((0, 2, 0)), P((-2, 0, 0)), P((0, 0, 2))
    PP = opns(a, b); C = opns(a, b, c); Sph = opns(a, b, c, d)
    pr('B2.1', f'point pair (2,0,0)^(0,2,0): grade {grades(PP)}, {len(PP)} labels; X^2 = {fmt(gp(PP, PP))}; radius^2 = {ffr(radius2(PP))}; centre {tup(center(PP))}')
    pr('B2.1b', f'   its blade: {fmt(PP)}')
    pts = pair_points(PP)
    pr('B2.2', 'its two points from (X ± sqrt(X^2)) (e_inf ⌋ X): ' + ', '.join('(' + ', '.join(f'{t + 0.0:.6g}'.replace('-0', '0') if abs(t) < 1e-12 else f'{t:.6g}' for t in p) + ')' for p in pts))
    pr('B2.3', f'circle through (2,0,0), (0,2,0), (-2,0,0): grade {grades(C)}, {len(C)} labels: {fmt(C)}')
    pr('B2.4', f'   radius^2 = {ffr(radius2(C))}, centre {tup(center(C))}; carrier C ^ e_inf = {fmt(op(C, EINF))}')
    pr('B2.5', f'sphere through those and (0,0,2): grade {grades(Sph)}: {fmt(Sph)}')
    sig = dual(Sph); w = -dot(sig, EINF)
    pr('B2.6', f'   its dual S I^-1 = {fmt(sig)} = {ffr(w)} (P(0) - 2 e_inf); radius^2 = sigma^2/(sigma.e_inf)^2 = {ffr(s0(gp(sig, sig)) / w ** 2)}; from the blade: {ffr(radius2(Sph))}')
    imag = ex_sphere((0, 0, 0), -4)
    pr('B2.7', f'the dual sphere P(0) + 2 e_inf has sigma^2 = {ffr(s0(gp(imag, imag)))}: radius^2 = -4, an imaginary sphere; P(x) . sigma = -(|x|^2 + 4)/2 < 0 for every x')

    # ---------------------------------------------------------------- B3 flats
    FP = op(P((1, 2, 3)), EINF); L = opns(P((0, 0, 0)), P((1, 1, 0)), EINF); Pl = opns(P((0, 0, 1)), P((1, 0, 1)), P((0, 1, 1)), EINF)
    pr('B3.1', f'flat point (1,2,3) ^ e_inf = {fmt(FP)}')
    pr('B3.2', f'line through (0,0,0) and (1,1,0): {fmt(L)}')
    pr('B3.3', f'plane through (0,0,1), (1,0,1), (0,1,1): {fmt(Pl)}; its dual = {fmt(dual(Pl))} = -(e3 + e_inf): the plane n.x = d with n = e3, d = 1')
    pr('B3.4', f'the flats contain e_inf: X ^ e_inf = {fmt(op(FP, EINF))}, {fmt(op(L, EINF))}, {fmt(op(Pl, EINF))}; radius^2 of a flat has a zero denominator (e_inf ⌋ X squares to {fmt(gp(lc(EINF, L), lc(EINF, L)))})')
    seq = []
    for k in (1, 2, 4, 8, 16, 32):
        Ck = opns(P((0, 0, 0)), P((2, 0, 0)), P((1, -k, 0)))
        seq.append((k, radius2(Ck), center(Ck)))
    pr('B3.5', 'circles through (0,0,0), (2,0,0), (1,-k,0): ' + '; '.join(f'k={k}: radius^2 {ffr(r)} centre ({ffr(cc[0])}, {ffr(cc[1])})' for k, r, cc in seq))
    lim = opns(P((0, 0, 0)), P((2, 0, 0)), EINF)
    Ck = opns(P((0, 0, 0)), P((2, 0, 0)), P((1, -32, 0))); sc = F(1) / F(1 + 32 * 32, 2)
    pr('B3.6', f'P(1,-k,0) / (k^2+1)/2 -> e_inf: the circle tends to the line {fmt(lim)}; at k = 32 the scaled circle differs from it by {max(abs(v) for v in add(scal(Ck, sc), lim, -1).values()) if add(scal(Ck, sc), lim, -1) else 0}')

    # ---------------------------------------------------------------- B4 weight, orientation, the support on the labels
    for name, X in [('point (1,2,3)', P((1, 2, 3))), ('point pair', PP), ('circle', C), ('sphere', Sph), ('flat point', FP), ('line', L), ('plane', Pl)]:
        kk = grades(X)[0]
        pr('B4.%d' % kk + ('f' if is_flat(X) and kk > 1 else 'r'), f'{name}: grade {kk}, {len(X)} of {sum(1 for m in range(32) if popc(m) == kk)} labels of the grade; flat: {is_flat(X)}; e_inf ⌋ X = {fmt(lc(EINF, X))}' + ('' if is_flat(X) or kk == 1 else f'; centre {tup(center(X))}, radius^2 {ffr(radius2(X))}; carrier X ^ e_inf = {fmt(op(X, EINF))}'))
    for name, X in [('point pair', PP), ('circle', C), ('sphere', Sph), ('line', L), ('plane', Pl)]:
        pr('B4.9' + name[:2], f'dual of the {name}: X I^-1 = {fmt(dual(X))}')
    pr('B4.9ch', f'the circle\'s dual against sphere ^ plane z = 0: {ffr(prop(dual(C), op(ex_sphere((0, 0, 0), 4), ex_plane((0, 0, 1), 0))) or 0)} (a multiple: {prop(dual(C), op(ex_sphere((0, 0, 0), 4), ex_plane((0, 0, 1), 0))) is not None})')
    rv = scal(P((1, 2, 3)), -1)
    pr('B4.8', f'-P(1,2,3) has the same null space; its weight -(-P) . e_inf = {ffr(-dot(rv, EINF))}: the sign is the orientation, the size the weight')

    # ---------------------------------------------------------------- C1 the products as filters on label pairs
    tot = 32 * 32; nz = sum(1 for a in range(32) for b in range(32) if A.s(a, b))
    neg = sum(1 for a in range(32) for b in range(32) if A.s(a, b) < 0)
    outer = sum(1 for a in range(32) for b in range(32) if a & b == 0)
    lcn = sum(1 for a in range(32) for b in range(32) if a & b == a)
    scn = 32
    pr('C1.1', f'geometric product: {nz} of {tot} label pairs non-zero, {neg} with sign -1')
    pr('C1.2', f'outer product (labels disjoint, a & b = 0): {outer} pairs = 3^5; left contraction (a inside b): {lcn} = 3^5; scalar product (a = b): {scn}; outer and contraction both: {sum(1 for a in range(32) for b in range(32) if a & b == 0 and a & b == a)} (a = 0)')
    chk = all(W.s(x, y) == (A.s(x, y) if x & y == 0 else 0) for x in range(32) for y in range(32))
    pr('C1.3', f'the all-null rule (every square 0) equals the bit rule of (4,1) on disjoint labels and is 0 elsewhere: {chk}')
    u, v = add(vec(1, 2, 0), EP), add(vec(0, 1, -1), EM, 2)
    pr('C1.4', f'for vectors u = {fmt(u)}, v = {fmt(v)}: uv = {fmt(gp(u, v))}; u.v = {ffr(dot(u, v))}; u^v = {fmt(op(u, v))}; uv = u.v + u^v: {eq(gp(u, v), add({0: dot(u, v)}, op(u, v)))}')

    # ---------------------------------------------------------------- C2 meets
    S1 = undual(ex_sphere((0, 0, 0), 4)); S2 = undual(ex_sphere((2, 0, 0), 4)); Pz = undual(ex_plane((0, 0, 1), 1))
    M = meet(S1, S2)
    pr('C2.1', f'sphere(0, r 2) v sphere((2,0,0), r 2) = circle: grade {grades(M)}, radius^2 {ffr(radius2(M))}, centre {tup(center(M))}, carrier normal from (M ^ e_inf) I^-1 = {fmt(dual(op(M, EINF)))}')
    M2 = meet(S1, Pz)
    pr('C2.2', f'sphere(0, r 2) v plane z = 1 = circle: grade {grades(M2)}, radius^2 {ffr(radius2(M2))}, centre {tup(center(M2))}')
    dd = op(ex_sphere((0, 0, 0), 4), ex_plane((0, 0, 1), 1))
    pr('C2.3', f'the dual way: sigma ^ pi = {fmt(dd)}; equal to (S v Pi) I^-1 up to the factor {ffr(prop(dd, dual(M2)))}')
    Px, Py = undual(ex_plane((1, 0, 0), 1)), undual(ex_plane((0, 1, 0), 1))
    Lm = meet(Px, Py)
    pr('C2.4', f'plane x = 1 v plane y = 1 = line: grade {grades(Lm)}, flat: {is_flat(Lm)}: {fmt(Lm)} (direction e3 through (1,1,0))')
    Ld = opns(P((0, 0, 0)), P((1, 1, 1)), EINF)
    Fp = meet(Pz, Ld)
    w = -Fp.get(24, F(0))
    pr('C2.5', f'plane z = 1 v line through 0 and (1,1,1) = flat point: grade {grades(Fp)}, {fmt(Fp)}; position (coef e_i+ / weight) = ({", ".join(ffr(Fp.get(m, 0) / w) for m in (9, 10, 12))})')
    Ls = opns(P((0, 0, 0)), P((1, 2, 2)), EINF)
    Pp = meet(S1, Ls)
    pr('C2.6', f'sphere(0, r 2) v line through 0 and (1,2,2) = point pair: grade {grades(Pp)}, radius^2 {ffr(radius2(Pp))}; points ' + ', '.join('(' + ', '.join(f'{t + 0.0:.6g}'.replace('-0', '0') if abs(t) < 1e-12 else f'{t:.6g}' for t in q) + ')' for q in pair_points(Pp)))
    Cz = opns(P((2, 0, 0)), P((0, 2, 0)), P((-2, 0, 0)))
    S3 = undual(ex_sphere((F(12, 5), 0, 0), 4))
    Pq = meet(Cz, S3)
    pr('C2.7', f'circle (centre 0, r 2, in z = 0) v sphere((12/5,0,0), r 2) = point pair: grade {grades(Pq)}; points ' + ', '.join('(' + ', '.join(f'{t + 0.0:.6g}'.replace('-0', '0') if abs(t) < 1e-12 else f'{t:.6g}' for t in q) + ')' for q in pair_points(Pq)))
    sc_ = meet(P((0, 0, 2)), S1); sc2 = meet(P((1, 1, 1)), S1)
    pr('C2.8', f'point v sphere is a scalar: P(0,0,2) v S = {fmt(sc_)}, P(1,1,1) v S = {fmt(sc2)} (the incidence test again)')
    pr('C2.9', f'join: P(2,0,0) ^ P(0,2,0) ^ P(-2,0,0) is the circle of B2.3: {eq(opns(a, b, c), C)}; P ^ P ^ e_inf is a line, P^P^P^e_inf a plane (B3)')

    # ---------------------------------------------------------------- C3 meets that vanish, imaginary and tangent ones
    L1 = opns(P((0, 0, 0)), P((1, 0, 0)), EINF); L2 = opns(P((0, 1, 0)), P((1, 2, 0)), EINF)
    J = {1 | 2 | 8 | 16: F(1)}
    pr('C3.1', f'two lines in the plane z = 0: full meet L1 v L2 = {fmt(meet(L1, L2))}; L1 ^ L2 = {fmt(op(L1, L2))}')
    J2 = gp(J, J); Jinv = scal(J, F(1) / s0(J2))
    def meetJ(x, y): return gp(op(gp(x, Jinv), gp(y, Jinv)), J)
    MJ = meetJ(L1, L2); wj = -MJ.get(24, F(0))
    pr('C3.2', f'inside J = {lab(1 | 2 | 8 | 16)} (the plane z = 0, the cell (3,1) inside (4,1); J^2 = {fmt(J2)}): L1 v_J L2 = {fmt(MJ)}: the flat point ({ffr(MJ.get(9, 0) / wj)}, {ffr(MJ.get(10, 0) / wj)})')
    pr('C3.3', f'the plane z = 0 as a blade: (e3) I = {fmt(undual({4: F(1)}))}, a multiple of J')
    C1 = opns(P((2, 0, 0)), P((0, 2, 0)), P((-2, 0, 0))); C2 = opns(P((F(22, 5), 0, 0)), P((F(12, 5), 2, 0)), P((F(2, 5), 0, 0)))
    MC = meetJ(C1, C2)
    pr('C3.4', f'two circles in z = 0 (centres 0 and (12/5,0), r 2): full meet {fmt(meet(C1, C2))}; inside J a point pair, points ' + ', '.join('(' + ', '.join(f'{t + 0.0:.6g}'.replace('-0', '0') if abs(t) < 1e-12 else f'{t:.6g}' for t in q) + ')' for q in pair_points(MC)))
    for i, (cx, nm) in enumerate([(4, 'touching'), (5, 'apart')]):
        Mi = meet(S1, undual(ex_sphere((cx, 0, 0), 4)))
        pr('C3.%d' % (5 + i), f'spheres (0, r 2) and ({cx},0,0), r 2, {nm}: circle radius^2 = {ffr(radius2(Mi))}, centre {tup(center(Mi))}')

    # ---------------------------------------------------------------- D versors
    t = (1, 2, 0); T = translator(t)
    pr('D1.1', f'T = 1 - t e_inf/2, t = {t}: T = {fmt(T)}; T T~ = {fmt(gp(T, rev(T)))}; (t e_inf)^2 = {fmt(gp(gp(vec(*t), EINF), gp(vec(*t), EINF)))}')
    okT = all(eq(sandwich(T, P(x)), P(tuple(F(x[i]) + t[i] for i in range(3)))) for x in [(0, 0, 0), (1, 2, 2), (-3, F(1, 2), 4)])
    pr('D1.2', f'T P(x) T~ = P(x + t) on three points: {okT}')
    R = rotor_rot(2, 1)
    okR = all(eq(sandwich(R, P(x)), P((F(3, 5) * x[0] - F(4, 5) * x[1], F(4, 5) * x[0] + F(3, 5) * x[1], x[2]))) for x in [(1, 0, 0), (1, 2, 2), (-3, F(1, 2), 4)])
    pr('D1.3', f'R = 2 - e12 (R R~ = {fmt(gp(R, rev(R)))}): R P(x) R~ / 5 = P(x turned by cos 3/5, sin 4/5 about the z axis): {okR}; e12^2 = {fmt(gp({3: 1}, {3: 1}))}')
    Dv = {0: F(3), 24: F(1)}
    img_inf = sandwich(Dv, EINF); img_o = sandwich(Dv, EO)
    pr('D1.4', f'D = 3 + e+- (D D~ = {fmt(gp(Dv, rev(Dv)))}, e+-^2 = {fmt(gp({24: 1}, {24: 1}))}): D e_inf D~ / 8 = {fmt(img_inf)} = {ffr(prop(img_inf, EINF))} e_inf, D e_o D~ / 8 = {ffr(prop(img_o, EO))} e_o')
    kD = loc(sandwich(Dv, P((1, 0, 0))))[0]
    okD = all(prop(sandwich(Dv, P(x)), P(tuple(kD * F(v) for v in x))) is not None for x in [(1, 0, 0), (1, 2, 2), (-3, F(1, 2), 4)])
    cD = prop(sandwich(Dv, P((1, 2, 2))), P(tuple(kD * F(v) for v in (1, 2, 2))))
    pr('D1.5', f'D P(x) D~ / 8 = {ffr(cD)} P({ffr(kD)} x) on three points: {okD} (a dilation by {ffr(kD)} about the origin)')
    sg = ex_sphere((0, 0, 0), 1)
    imgs = []
    for x in [(1, 2, 2), (3, 0, 4), (F(1, 2), 0, 0)]:
        n2 = sum(F(v) ** 2 for v in x); Y = sandwich(sg, P(x)); k = prop(Y, P(tuple(F(v) / n2 for v in x)))
        imgs.append((x, k))
    pr('D1.6', f'inversion in the unit sphere sigma = e_o - e_inf/2 (sigma^2 = {ffr(s0(gp(sg, sg)))}): -sigma P(x) sigma = c P(x/|x|^2): ' + '; '.join(f'x = {tup(x)}: c = {ffr(k)}' for x, k in imgs))
    pr('D1.7', 'the generators: t e_inf squares to 0, e12 to -1, e+- to +1: the three squares 0, -1, +1 of the rule, as three kinds of move')
    # products of two mirrors
    p1, p2 = ex_plane((1, 0, 0), 0), ex_plane((1, 0, 0), F(3, 2))
    V = gp(p2, p1)
    pr('D2.1', f'two parallel planes x = 0, x = 3/2: pi2 pi1 = {fmt(V)} = T for t = (3,0,0): {eq(V, translator((3, 0, 0)))}')
    q1, q2 = ex_plane((1, 0, 0), 0), ex_plane((F(4, 5), F(3, 5), 0), 0)
    V2 = gp(q2, q1)
    xr = (1, 2, 2); img = sandwich(V2, P(xr)); cth, sth = F(7, 25), F(24, 25)
    pr('D2.2', f'two planes through the z axis at angle phi (cos 4/5): pi2 pi1 = {fmt(V2)}; it turns by 2 phi (cos {ffr(cth)}, sin {ffr(sth)}): {eq(img, P((cth * 1 - sth * 2, sth * 1 + cth * 2, 2)))}')
    s1, s2 = ex_sphere((0, 0, 0), 1), ex_sphere((0, 0, 0), 4)
    V3 = gp(s2, s1)
    pr('D2.3', f'two spheres at 0 with radii 1 and 2: sigma2 sigma1 = {fmt(V3)}; it scales by 4: {prop(sandwich(V3, P((1, 2, 2))), P((4, 8, 8))) is not None}')
    # the conformal algebra: the ten bivectors
    biv = [m for m in range(32) if popc(m) == 2]
    pr('D3.1', f'{len(biv)} bivector labels = C(5,2); squares: ' + ', '.join(f'{lab(m)} {A.s(m, m):+d}' for m in biv))
    Tk = [gp(vec(*e), EINF) for e in [(1, 0, 0), (0, 1, 0), (0, 0, 1)]]
    Kk = [gp(vec(*e), EO) for e in [(1, 0, 0), (0, 1, 0), (0, 0, 1)]]
    Ed = op(EINF, EO)
    def com(x, y): return add(gp(x, y), gp(y, x), -1)
    eT = [prop(com(Ed, x), x) for x in Tk]; eK = [prop(com(Ed, x), x) for x in Kk]
    pr('D3.2', f'translations e_i e_inf (3), special conformal e_i e_o (3), rotations e12, e13, e23 (3), dilation E (1): 10; [E, e_i e_inf] = {eT[0]} e_i e_inf, [E, e_i e_o] = {eK[0]} e_i e_o')
    # Killing form of the bivector algebra, exact
    basis = [{m: F(1)} for m in biv]
    def coords(x): return [x.get(m, F(0)) for m in biv]
    ad = []
    for X in basis:
        ad.append([coords(com(X, Y)) for Y in basis])          # ad X as columns
    def mat(X): return [[ad[X][j][i] for j in range(10)] for i in range(10)]
    Ms = [mat(i) for i in range(10)]
    def tr_mm(Ma, Mb): return sum(Ma[i][k] * Mb[k][i] for i in range(10) for k in range(10))
    K = [[tr_mm(Ms[i], Ms[j]) for j in range(10)] for i in range(10)]
    # signature by exact symmetric elimination
    Mk = [row[:] for row in K]; pos_ = neg_ = zer = 0; n_ = 10; idx = list(range(10))
    while idx:
        piv = next((i for i in idx if Mk[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in idx for j in idx if i < j and Mk[i][j] != 0), None)
            if pair is None:
                zer += len(idx); break
            i, j = pair
            for k in range(10): Mk[i][k] += Mk[j][k]
            for k in range(10): Mk[k][i] += Mk[k][j]
            continue
        d_ = Mk[piv][piv]; pos_ += d_ > 0; neg_ += d_ < 0
        for i in idx:
            if i != piv and Mk[i][piv] != 0:
                f = Mk[i][piv] / d_
                for k in range(10): Mk[i][k] -= f * Mk[piv][k]
                for k in range(10): Mk[k][i] -= f * Mk[k][piv]
        idx.remove(piv)
    pr('D3.3', f'Killing form of the ten bivectors: {neg_} negative, {pos_} positive, {zer} zero (so(4,1): the six of so(4) negative)')

    # ---------------------------------------------------------------- E the PGA neighbour
    zero_p = sum(1 for x in range(16) for y in range(16) if PG.s(x, y) == 0)
    okhom = 0; zero_img = 0
    for x in range(16):
        for y in range(16):
            lhs = gp(phi(x), phi(y)); s = PG.s(x, y)
            rhs = scal(phi(x ^ y), s) if s else {}
            okhom += eq(lhs, rhs); zero_img += (not lhs)
    rank = BA.rank_fr([phi(m) for m in range(16)], 32)
    pr('E1.1', f'Cl(3,0,1): 16 labels, e0^2 = {PG.s(8, 8)}; {zero_p} of 256 products are 0 (the pairs sharing e0)')
    pr('E1.2', f'phi: e_S -> e_S, e_S e0 -> e_S e_inf: phi(x) phi(y) = s(x,y) phi(x xor y) on {okhom} of 256 pairs; {zero_img} image products are 0; the 16 images have rank {rank} (injective)')
    pr('E1.3', f'phi(e0) = e_inf = {fmt(phi(8))}: one PGA label goes to two labels of (4,1); phi(e12 e0) = {fmt(phi(11))}')
    # planes and the translator
    pi_p = {1: F(3, 5), 2: F(4, 5), 8: F(2)}           # PGA plane 3/5 x + 4/5 y = 2 as n + d e0 (vector)
    Tp = {0: F(1), 1 | 8: F(-1, 2) * 1, 2 | 8: F(-1, 2) * 2}  # 1 - t e0 / 2 with t = (1,2,0): -1/2 (e1 e0 + 2 e2 e0)
    Tp = clean({0: F(1), 9: F(-1, 2), 10: F(-1)})
    def pmul(x, y): return clean(PG.mul(x, y))
    def prev(x): return {a: v * (-1 if (popc(a) * (popc(a) - 1) // 2) % 2 else 1) for a, v in x.items()}
    img_p = pmul(pmul(Tp, pi_p), prev(Tp))
    def phim(x):
        out = {}
        for m, cf in x.items(): out = add(out, phi(m), cf)
        return out
    img_c = sandwich(phim(Tp), phim(pi_p))
    pr('E2.1', f'PGA: T = 1 - t e0/2 (t = (1,2,0)) = {fmt(Tp, PGA_NAMES)} sends the plane {fmt(pi_p, PGA_NAMES)} to {fmt(img_p, PGA_NAMES)} (the plane 3/5 x + 4/5 y = 2 + 11/5)')
    pr('E2.2', f'phi of both: the conformal translator {fmt(phim(Tp))} sends phi(plane) to {fmt(img_c)}; phi(PGA image) agrees: {eq(phim(img_p), img_c)}')
    # distance: PGA join of two points (FRQ-009 form: the complement of e0 + x), CGA inner product
    def comp(m):
        """right complement on the labels of Cl(3,0,1): e_m e_c(m) = e_1230 (the sign chosen so)"""
        cm = m ^ 15; s = BA.N_pairs(m, cm) & 1
        return cm, (-1 if s else 1)
    def cpl(x):
        out = {}
        for m, cf in x.items():
            cm, s = comp(m); out[cm] = out.get(cm, 0) + s * cf
        return clean(out)
    def ucpl(x):
        out = {}
        for m, cf in x.items():
            # inverse of comp: find k with comp(k) = (m, s)
            k = m ^ 15; cm, s = comp(k); out[k] = out.get(k, 0) + s * cf
        return clean(out)
    def pjoin(x, y):
        """regressive product by the complement: x v y = uc(c(x) ^ c(y))"""
        PW = BA.BR((0, 0, 0, 0))
        return ucpl(clean(PW.mul(cpl(x), cpl(y))))
    def ppoint(x): return cpl({8: F(1), 1: F(x[0]), 2: F(x[1]), 4: F(x[2])})
    pa, pb = ppoint((1, 2, 2)), ppoint((4, 6, 2))
    Lj = pjoin(pa, pb); size2 = s0(pmul(Lj, prev(Lj)))
    pr('E3.1', f'PGA points (1,2,2), (4,6,2) as complements of e0 + x: {fmt(pa, PGA_NAMES)}, {fmt(pb, PGA_NAMES)}')
    pr('E3.2', f'their join (the line) = {fmt(Lj, PGA_NAMES)}; scalar part of L L~ = {ffr(size2)}: size {ffr(size2) if size2 != 25 else 5}')
    pr('E3.3', f'the same two points in (4,1): P . Q = {ffr(dot(P((1, 2, 2)), P((4, 6, 2))))} = -5^2/2')
    pr('E3.4', f'counts: the PGA of R^3 has 16 labels and C(4,2) = 6 bivectors (rigid motions); the (4,1) cell has 32 labels and C(5,2) = 10 bivectors (conformal moves)')

    # ---------------------------------------------------------------- the stored products of the widgets' self-test
    picks = [(1, 2), (2, 1), (16, 16), (8, 16), (24, 24), (31, 31), (7, 7), (13, 22), (11, 28), (30, 17)]
    stored = [[x, y, A.s(x, y), x ^ y] for x, y in picks]
    pr('W.1', 'ten stored products [a, b, s, a xor b] (masks; bit 0 = e1 ... bit 4 = e-): ' + json.dumps(stored))
    pr('W.2', 'the same in labels: ' + '; '.join(f'{lab(x)} {lab(y)} = {"+" if s > 0 else "-"}{lab(k)}' for x, y, s, k in stored))
    return out


if __name__ == '__main__':
    for line in main():
        print(line)
