#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# figs_geo.py: the figures of the tutorial "Geometry on the bit rule", each drawn from an object of the Atlas.
#   python3 -I -B figs_geo.py [REPO]            writes figs/*.svg beside this file (REPO: the Atlas repository; default ../../v3/one-rule)
#   python3 -I -B figs_geo.py [REPO] --products prints the ten products the widgets store for their self-test, and writes nothing
# The rule is imported from REPO/checks/selfcheck/steps15_17/bitcliff.py; the join of the three plane-based algebras from
# REPO/checks/selfcheck/gravity/g1_force_line.py; the numbers of the curvature, Weyl, cone and Skyrme figures are parsed from the shipped
# logs and never typed here; the mirror examples come from REPO/checks/selfcheck/mirrors.json. Every figure asserts what it draws against
# the rule or the log it reads, and stops if they disagree. Deterministic: the same repository gives the same bytes.
import os, sys, re, json, math
from fractions import Fraction as Fr

HERE = os.path.dirname(os.path.abspath(__file__))
ARGS = [a for a in sys.argv[1:] if not a.startswith('--')]
REPO = os.path.abspath(ARGS[0]) if ARGS else os.path.abspath(os.environ.get('ATLAS_REPO') or os.path.join(HERE, '..', '..'))   # the repository: ATLAS_REPO, else two folders up from tools/tutorials/
CHK = os.path.join(REPO, 'checks')
sys.path.insert(0, os.path.join(CHK, 'selfcheck', 'steps15_17'))
import bitcliff as BC                                    # the bit rule: e_a e_b = s(a,b) e_{a xor b}
sys.path.insert(0, os.path.join(CHK, 'selfcheck', 'gravity'))
import g1_force_line as G1                               # the join of two points in Cl(3,0,1), Cl(4,0,0), Cl(3,1,0)
OUT = os.path.join(REPO, 'public', 'reports', 'tutorials', 'src', 'geo', 'figs')   # the figures, beside the tutorial's source


def need(ok, msg):
    if not ok:
        raise SystemExit('figs_geo: ' + msg)


def readlog(rel):
    with open(os.path.join(CHK, rel), encoding='utf8') as fh:
        return fh.read()


def frac(s):
    return Fr(s.replace(' ', ''))


# ------------------------------------------------------------------------------------------------ labels and SVG helpers
SUBD = str.maketrans('0123456789', '₀₁₂₃₄₅₆₇₈₉')
SUPD = str.maketrans('0123456789', '⁰¹²³⁴⁵⁶⁷⁸⁹')


def sub(s):
    return str(s).translate(SUBD)


def blab(a, base=1):
    """the blade of the label a: 1, e1, e12, ... (generators counted from base)"""
    return '1' if a == 0 else 'e' + ''.join(sub(i + base) for i in range(12) if a >> i & 1)


def esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def fm(v):
    if isinstance(v, Fr):
        v = float(v)
    if isinstance(v, int):
        return str(v)
    s = ('%.2f' % v).rstrip('0').rstrip('.')
    return '0' if s in ('-0', '', '-') else s


def frs(x):
    """a fraction as text with a true minus sign"""
    x = Fr(x)
    s = str(x.numerator) if x.denominator == 1 else '%d/%d' % (x.numerator, x.denominator)
    return s.replace('-', '−')


DARK = '--g1:#3987e5;--g2:#d95926;--g3:#199e70;--g4:#c98500;--g5:#d55181;--g7:#9085e9;--k0:#2e2e2b;--k1:#1d3557;--k2:#4f2a1a;--k3:#163f31;--k4:#46370f;--k5:#4a2233'
STYLE = ('<style>'
         '.gf text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;fill:var(--ink,#1a1a19)}'
         '.gf .t2{fill:var(--ink2,#46463f)}.gf .mu{fill:var(--muted,#6b6b64)}'
         '.gf .ln{stroke:var(--line2,#c9c8c0);fill:none}.gf .ax{stroke:var(--muted,#6b6b64);fill:none}.gf .ik{stroke:var(--ink,#1a1a19);fill:none}'
         '.gf .fi{fill:var(--ink,#1a1a19)}.gf .fm{fill:var(--muted,#6b6b64)}.gf .fs{fill:var(--surf,#fff)}.gf .sk{stroke:var(--surf,#fff)}'
         '.gf{--g1:#2a78d6;--g2:#eb6834;--g3:#1baf7a;--g4:#eda100;--g5:#e87ba4;--g7:#6250d6;'
         '--k0:#efeee9;--k1:#d9e7fa;--k2:#fbe0d3;--k3:#d3f0e4;--k4:#fbebc4;--k5:#f9dde8}'
         '@media (prefers-color-scheme:dark){:root:not([data-theme="light"]) .gf{' + DARK + '}}'
         ':root[data-theme="dark"] .gf{' + DARK + '}'
         + ''.join('.gf .c%d{stroke:var(--g%d)}.gf .f%d{fill:var(--g%d)}' % (i, i, i, i) for i in (1, 2, 3, 4, 5, 7))
         + ''.join('.gf .k%d{fill:var(--k%d)}' % (i, i) for i in range(6))
         + '</style>')


class Svg:
    def __init__(s, w, h, label, scale=1.3):
        s.w, s.h, s.label, s.scale, s.p = w, h, label, scale, []

    def add(s, x):
        s.p.append(x)

    def text(s, x, y, t, size=13, cls='', anchor='start', weight=None, rot=None, italic=False):
        a = ['x="%s" y="%s"' % (fm(x), fm(y))]
        if size != 13:
            a.append('font-size="%s"' % fm(size))
        if anchor != 'start':
            a.append('text-anchor="%s"' % anchor)
        if cls:
            a.append('class="%s"' % cls)
        if weight:
            a.append('font-weight="%s"' % weight)
        if italic:
            a.append('font-style="italic"')
        if rot is not None:
            a.append('transform="rotate(%s %s %s)"' % (fm(rot), fm(x), fm(y)))
        s.add('<text %s>%s</text>' % (' '.join(a), esc(t)))

    def line(s, x1, y1, x2, y2, cls='ax', w=1, dash=None, op=None):
        e = ' stroke-dasharray="%s"' % dash if dash else ''
        e += ' opacity="%s"' % op if op else ''
        s.add('<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s" stroke-width="%s"%s/>' % (fm(x1), fm(y1), fm(x2), fm(y2), cls, fm(w), e))

    def rect(s, x, y, w, h, cls, rx=0, stroke=None, sw=1):
        e = ' rx="%s"' % fm(rx) if rx else ''
        if stroke:
            e += ' class="%s %s" stroke-width="%s"' % (cls, stroke, fm(sw))
        else:
            e += ' class="%s"' % cls
        s.add('<rect x="%s" y="%s" width="%s" height="%s"%s/>' % (fm(x), fm(y), fm(w), fm(h), e))

    def circle(s, x, y, r, cls, sw=None, op=None):
        e = ' stroke-width="%s"' % fm(sw) if sw else ''
        e += ' opacity="%s"' % op if op else ''
        s.add('<circle cx="%s" cy="%s" r="%s" class="%s"%s/>' % (fm(x), fm(y), fm(r), cls, e))

    def poly(s, pts, cls, w=2, dash=None, op=None, close=False):
        e = ' stroke-dasharray="%s"' % dash if dash else ''
        e += ' opacity="%s"' % op if op else ''
        tag = 'polygon' if close else 'polyline'
        fill = '' if close else ' fill="none"'
        s.add('<%s points="%s" class="%s" stroke-width="%s"%s%s stroke-linejoin="round" stroke-linecap="round"/>' % (
            tag, ' '.join('%s,%s' % (fm(x), fm(y)) for x, y in pts), cls, fm(w), fill, e))

    def arrow(s, x1, y1, x2, y2, cls='ik', fcls='fi', w=1.6, head=7, dash=None, op=None):
        dx, dy = x2 - x1, y2 - y1
        L = math.hypot(dx, dy) or 1.0
        ux, uy = dx / L, dy / L
        bx, by = x2 - ux * head, y2 - uy * head
        s.line(x1, y1, bx, by, cls, w, dash, op)
        px, py = -uy * head * 0.45, ux * head * 0.45
        s.poly([(x2, y2), (bx + px, by + py), (bx - px, by - py)], fcls, 0, close=True, op=op)

    def badge(s, x, y, t, cls='k0', size=12, r=9, stroke='ln'):
        s.add('<circle cx="%s" cy="%s" r="%s" class="%s %s" stroke-width="1"/>' % (fm(x), fm(y), fm(r), cls, stroke))
        s.text(x, y + size * 0.36, t, size, anchor='middle', weight='600')

    def svg(s):
        W, H = s.w, s.h
        return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s">\n'
                '<title>%s</title>\n%s\n<g class="gf" font-size="13">\n%s\n</g>\n</svg>\n') % (
            W, H, round(W * s.scale), round(H * s.scale), esc(s.label), esc(s.label), STYLE, '\n'.join(s.p))


def pc(x):
    return bin(x).count('1')


SIGN_TINT = {1: 'k1', -1: 'k2', 0: 'k0'}
SIGN_GLYPH = {1: '+', -1: '−', 0: '0'}


# ------------------------------------------------------------------------------------------------ 1. n = 2: one rule, three algebras
def fig_n2():
    S = Svg(420, 382, 'The bit rule at n = 2: the labels of the products and the signs in three cells')
    order = [0, 1, 2, 3]
    hw, hh, cw, ch = 32, 22, 38, 28
    cases = [((1, 1), 'squares (+, +)', 'Cl(2,0) ≅ M₂(ℝ)'), ((-1, -1), 'squares (−, −)', 'Cl(0,2) ≅ ℍ'), ((0, 0), 'squares (0, 0)', 'Cl(0,0,2) = Λℝ²')]
    pos = [(8, 4), (214, 4), (8, 194), (214, 194)]

    def grid(x0, y0, title, subt, cell):
        S.text(x0, y0 + 14, title, 13, weight='600')
        S.text(x0, y0 + 31, subt, 11.5, 'mu')
        gy = y0 + 40
        for j, b in enumerate(order):
            S.text(x0 + hw + j * cw + cw / 2, gy + 15, blab(b), 12, 'mu', 'middle')
        for i, a in enumerate(order):
            S.text(x0 + hw - 6, gy + hh + i * ch + 19, blab(a), 12, 'mu', 'end')
            for j, b in enumerate(order):
                cell(x0 + hw + j * cw, gy + hh + i * ch, a, b)

    def labcell(x, y, a, b):
        S.rect(x + 1, y + 1, cw - 2, ch - 2, 'k0', 3)
        S.text(x + cw / 2, y + 19, blab(a ^ b), 12.5, anchor='middle')
    grid(*pos[0], 'the label: a ⊕ b', 'the same in the three cells', labcell)
    counts = []
    for (eps, title, name), (x0, y0) in zip(cases, pos[1:]):
        A = BC.Alg(eps)
        tab = {(a, b): A.blade_mul(a, b)[0] for a in order for b in order}
        neg = sum(1 for v in tab.values() if v == -1)
        zer = sum(1 for v in tab.values() if v == 0)
        counts.append((neg, zer))

        def sgncell(x, y, a, b, tab=tab):
            v = tab[(a, b)]
            S.rect(x + 1, y + 1, cw - 2, ch - 2, SIGN_TINT[v], 3)
            S.text(x + cw / 2, y + 19.5, SIGN_GLYPH[v], 15, anchor='middle', weight='600')
        grid(x0, y0, title + ': ' + name, '%d signs −, %d products 0' % (neg, zer), sgncell)
        # the rule against the textbook anticommutation e_i e_j + e_j e_i = 2 eps_i delta_ij
        for i in range(2):
            for j in range(2):
                s1, _ = A.blade_mul(1 << i, 1 << j)
                s2, _ = A.blade_mul(1 << j, 1 << i)
                need((s1 + s2 == 2 * eps[i]) if i == j else (s1 + s2 == 0), 'anticommutation at n = 2')
    return S.svg(), counts


# ------------------------------------------------------------------------------------------------ 2. the cells and their types
def cell_type(p, q):
    """the type of Cl(p,q) read off the squares of its 2^n labels: the counts N+ and N- of labels with square +1 and -1"""
    n = p + q
    A = BC.Alg(BC.sig(p, q))
    Np, Nm, _ = A.counts()
    if n % 2 == 0:
        kind = 'R' if Np > Nm else 'H'
    else:
        kind = 'C' if Np == Nm else ('R2' if Np > Nm else 'H2')
    N = {'R': 2 ** (n // 2), 'H': 2 ** ((n - 2) // 2) if n >= 2 else 1, 'C': 2 ** ((n - 1) // 2),
         'R2': 2 ** ((n - 1) // 2), 'H2': 2 ** ((n - 3) // 2) if n >= 3 else 1}[kind]
    dimD = {'R': 1, 'C': 2, 'H': 4, 'R2': 1, 'H2': 4}[kind] * (2 if kind in ('R2', 'H2') else 1)
    need(dimD * N * N == 2 ** n, 'dimension of Cl(%d,%d)' % (p, q))
    return kind, N


def cell_name(kind, N):
    base = {'R': 'ℝ', 'R2': 'ℝ', 'C': 'ℂ', 'H': 'ℍ', 'H2': 'ℍ'}[kind]
    s = base if N == 1 else 'M' + sub(N) + base
    return ('²' + s) if kind in ('R2', 'H2') else s


def log_name(kind, N):
    base = {'R': 'R', 'R2': 'R', 'C': 'C', 'H': 'H', 'H2': 'H'}[kind]
    if N == 1:
        return base + '+' + base if kind in ('R2', 'H2') else base
    return 'M%d(%s)' % (N, base) + ('^2' if kind in ('R2', 'H2') else '')


def check_types_against_log():
    """labels_check.log (sections 5 and 8) lists cells with their textbook types; the types read off the squares must agree"""
    txt = readlog('selfcheck/steps15_17/logs/labels_check.log')
    found = re.findall(r'(?<![0-9A-Za-z])Cl\((\d+), ?(\d+)\) ?= ?(M\d+\([RCH]\)(?:\^2)?|R\+R|H\+H|[RCH])(?![\w(+])', txt)
    need(len(found) >= 30, 'labels_check.log: too few cells listed (%d)' % len(found))
    for p, q, nm in found:
        k, N = cell_type(int(p), int(q))
        need(log_name(k, N) == nm, 'type of Cl(%s,%s): %s from the squares, %s in labels_check.log' % (p, q, log_name(k, N), nm))
    return len(found)


TYPE_TINT = {'R': 'k1', 'R2': 'k4', 'C': 'k3', 'H': 'k2', 'H2': 'k5'}
TYPE_LEGEND = [('R', 'Mₙ(ℝ)', 'c = 0, 2'), ('R2', '²Mₙ(ℝ)', 'c = 1'), ('C', 'Mₙ(ℂ)', 'c = 3, 7'), ('H', 'Mₙ(ℍ)', 'c = 4, 6'), ('H2', '²Mₙ(ℍ)', 'c = 5')]


def tri_grid(S, x0, y0, cs, nmax, cellfn):
    for p in range(nmax + 1):
        S.text(x0 + p * cs + cs / 2, y0 - 7, str(p), 12, 'mu', 'middle')
    for q in range(nmax + 1):
        S.text(x0 - 8, y0 + q * cs + cs / 2 + 4, str(q), 12, 'mu', 'end')
    for p in range(nmax + 1):
        for q in range(nmax + 1 - p):
            cellfn(x0 + p * cs, y0 + q * cs, p, q)


def fig_cells():
    nlog = check_types_against_log()
    S = Svg(420, 430, 'The cells Cl(p,q) with p + q ≤ 8, coloured by the type of algebra that the squares of the labels give')
    x0, y0, cs = 40, 50, 41
    S.text(x0, 16, 'p: generators with square +1 →', 12.5, 't2')
    S.text(14, y0 + 4 * cs, 'q: generators with square −1 →', 12.5, 't2', 'middle', rot=90)

    def cell(x, y, p, q):
        k, N = cell_type(p, q)
        S.rect(x + 1, y + 1, cs - 2, cs - 2, TYPE_TINT[k], 4)
        nm = cell_name(k, N)
        S.text(x + cs / 2, y + 19, nm, 12 if len(nm) <= 4 else 11, anchor='middle', weight='600')
        S.text(x + cs / 2, y + 33, 'c ' + str((p - q) % 8), 10, 'mu', 'middle')
    tri_grid(S, x0, y0, cs, 8, cell)
    lx, ly = 216, 272
    S.text(lx, ly, 'type, and its clocks', 12, 't2', weight='600')
    for i, (k, nm, cl) in enumerate(TYPE_LEGEND):
        yy = ly + 10 + i * 22
        S.rect(lx, yy, 16, 16, TYPE_TINT[k], 3)
        S.text(lx + 23, yy + 12.5, nm, 12)
        S.text(lx + 196, yy + 12.5, cl, 11.5, 'mu', 'end')
    S.text(lx, ly + 132, '²X = X ⊕ X;  c = p − q mod 8', 11.5, 'mu')
    S.text(lx, ly + 148, 'each diagonal keeps its type', 11.5, 'mu')
    return S.svg(), nlog


# ------------------------------------------------------------------------------------------------ 3. the clock as the phase of a Gauss sum
def gmul(x, y):
    return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])


IPOW = [(1, 0), (0, 1), (-1, 0), (0, -1)]


def gauss_sum(p, q):
    n = p + q
    P = (1 << p) - 1
    Q = ((1 << n) - 1) ^ P
    re_, im_ = 0, 0
    for a in range(1 << n):
        k = (pc(a & P) - pc(a & Q)) % 4
        re_ += IPOW[k][0]
        im_ += IPOW[k][1]
    closed = (1, 0)
    for _ in range(p):
        closed = gmul(closed, (1, 1))
    for _ in range(q):
        closed = gmul(closed, (1, -1))
    need((re_, im_) == closed, 'Gauss sum of Cl(%d,%d)' % (p, q))
    need(re_ * re_ + im_ * im_ == 2 ** n, 'modulus of the Gauss sum')
    c = round(math.atan2(im_, re_) / (math.pi / 4)) % 8
    need(c == (p - q) % 8, 'phase of the Gauss sum of Cl(%d,%d)' % (p, q))
    return (re_, im_), c


def fig_clock():
    S = Svg(420, 352, 'The clock: the phase of the Gauss sum of the labels of a cell, for the cells with p + q ≤ 5')
    cx, cy, r = 210, 186, 78
    by_c = {c: [] for c in range(8)}
    kinds = {}
    for n in range(6):
        for p in range(n + 1):
            q = n - p
            _, c = gauss_sum(p, q)
            by_c[c].append((p, q))
            k, _ = cell_type(p, q)
            need(kinds.setdefault(c, k) == k, 'one type per clock')
    S.circle(cx, cy, r, 'ln', 1.5)
    for c in range(8):
        th = math.pi * c / 4
        x, y = cx + r * math.cos(th), cy - r * math.sin(th)
        S.line(cx, cy, x, y, 'ln', 0.8, '2 3')
        S.circle(x, y, 7.5, TYPE_TINT[kinds[c]] + ' ik', 1.2)
        lx, ly = cx + (r + 16) * math.cos(th), cy - (r + 16) * math.sin(th)
        anchor = 'start' if math.cos(th) > 0.3 else ('end' if math.cos(th) < -0.3 else 'middle')
        lines = ['c = %d · %s' % (c, cell_name(kinds[c], 1)) ] + ['Cl(%d,%d)' % pq for pq in sorted(by_c[c], key=lambda t: (t[0] + t[1], t[0]))]
        if math.sin(th) > 0.3:
            ly0 = ly - 13 * (len(lines) - 1) - 2
        elif math.sin(th) < -0.3:
            ly0 = ly + 12
        else:
            ly0 = ly - 13 * (len(lines) - 1) / 2 + 4
        for i, t in enumerate(lines):
            S.text(lx, ly0 + 13 * i, t, 12 if i == 0 else 11.5, '' if i == 0 else 'mu', anchor, '600' if i == 0 else None)
    S.text(cx, cy - 14, 'Σₐ i^(pos(a) − neg(a))', 11.5, anchor='middle')
    S.text(cx, cy + 3, '= (1 + i)ᵖ (1 − i)^q', 11.5, anchor='middle')
    S.text(cx, cy + 20, '= 2^(n/2) e^(iπc/4)', 11.5, anchor='middle')
    S.text(8, 18, 'the type of each clock (the dot) is read off the squares', 11.5, 'mu')
    return S.svg(), {c: len(v) for c, v in by_c.items()}


# ------------------------------------------------------------------------------------------------ 4. the pseudoscalar: its square and whether it is central
def fig_pseudo():
    S = Svg(420, 430, 'The square of the pseudoscalar I = e1...en over the cells Cl(p,q), p + q ≤ 8, and whether I is central')
    x0, y0, cs = 40, 50, 41
    S.text(x0, 16, 'p: generators with square +1 →', 12.5, 't2')
    S.text(14, y0 + 4 * cs, 'q: generators with square −1 →', 12.5, 't2', 'middle', rot=90)
    stats = {'central': 0, 'anti': 0}

    def cell(x, y, p, q):
        n = p + q
        A = BC.Alg(BC.sig(p, q))
        top = (1 << n) - 1
        I2 = A.sq(top)
        need(I2 == (-1) ** (n * (n - 1) // 2 + q), 'I^2 of Cl(%d,%d)' % (p, q))
        comm = [A.comm_sign(top, 1 << i) for i in range(n)] if n else []
        central = all(c == 1 for c in comm)
        need(central == (n % 2 == 1 or n == 0), 'centrality of I in Cl(%d,%d)' % (p, q))
        need(n % 2 == 1 or all(c == -1 for c in comm), 'I anticommutes with the vectors for even n')
        stats['central' if central and n else 'anti'] += 1
        S.rect(x + 1, y + 1, cs - 2, cs - 2, SIGN_TINT[I2], 4)
        S.text(x + cs / 2, y + 25, ('+1' if I2 == 1 else '−1'), 13, anchor='middle', weight='600')
        if n % 2 == 1:
            S.circle(x + cs - 8, y + 8, 3.6, 'fi')
    tri_grid(S, x0, y0, cs, 8, cell)
    # the null case: one generator of square 0
    A0 = BC.Alg(BC.sig(2, 0, 1))
    need(A0.sq(7) == 0, 'I^2 = 0 with a null generator')
    lx, ly = 222, 280
    S.text(lx, ly, 'I² by the rule', 12, 't2', weight='600')
    S.rect(lx, ly + 10, 16, 16, 'k1', 3); S.text(lx + 22, ly + 23, '+1', 12)
    S.rect(lx + 60, ly + 10, 16, 16, 'k2', 3); S.text(lx + 82, ly + 23, '−1', 12)
    S.circle(lx + 8, ly + 45, 3.6, 'fi'); S.text(lx + 22, ly + 49, 'n odd: I commutes with all', 11.5)
    S.text(lx + 22, ly + 64, 'n even: I anticommutes with', 11.5)
    S.text(lx + 22, ly + 78, 'every vector', 11.5)
    S.text(lx, ly + 100, 'I² = (−1)^(n(n−1)/2) (−1)^q;', 11.5, 'mu')
    S.text(lx, ly + 115, 'a null generator gives I² = 0', 11.5, 'mu')
    return S.svg(), stats


# ------------------------------------------------------------------------------------------------ 5. the wedge: Cl(0,0,3)
def fig_wedge():
    S = Svg(420, 312, 'The products of the labels with all squares 0: the exterior algebra of R^3')
    A = BC.Alg((0, 0, 0))
    order = [0, 1, 2, 4, 3, 5, 6, 7]
    x0, y0, hw, cw, ch = 10, 66, 42, 45.5, 30
    nz = 0
    for j, b in enumerate(order):
        S.text(x0 + hw + j * cw + cw / 2, y0 - 8, blab(b), 12, 'mu', 'middle')
    for i, a in enumerate(order):
        S.text(x0 + hw - 6, y0 + i * ch + 19.5, blab(a), 12, 'mu', 'end')
        for j, b in enumerate(order):
            s, c = A.blade_mul(a, b)
            x, y = x0 + hw + j * cw, y0 + i * ch
            if s == 0:
                need(a & b, 'a zero product needs a shared generator')
                S.text(x + cw / 2, y + 19, '·', 12, 'mu', 'middle')
                continue
            nz += 1
            need(a & b == 0, 'a non-zero product needs disjoint labels')
            s2, _ = A.blade_mul(b, a)
            need(s2 == s * (-1) ** (pc(a) * pc(b)), 'graded commutativity (-1)^(|a||b|)')
            S.rect(x + 1.5, y + 1.5, cw - 3, ch - 3, SIGN_TINT[s], 3)
            S.text(x + cw / 2, y + 20, ('' if s == 1 else '−') + blab(c), 12, anchor='middle')
    need(nz == 27, 'the 27 = 3^3 non-zero products')
    S.text(x0, 18, 'Cl(0,0,3) = Λℝ³: %d = 3³ of the 64 products are not 0' % nz, 13, weight='600')
    S.text(x0, 36, 'row a, column b: the product; a dot: the product is 0', 11.5, 'mu')
    return S.svg(), nz


# ------------------------------------------------------------------------------------------------ 6. the Hodge star as the complement on the cube of labels
def cube_proj(ox, oy, L):
    def P(a):
        x, y, z = a & 1, a >> 1 & 1, a >> 2 & 1
        return (ox + L * x + 0.5 * L * z, oy - L * y - 0.36 * L * z)
    return P


CUBE_EDGES = [(a, a | 1 << i) for a in range(8) for i in range(3) if not a >> i & 1]


def draw_cube(S, P, labels=True):
    for a, b in CUBE_EDGES:
        S.line(*P(a), *P(b), 'ln', 1.2)
    cxm = sum(P(a)[0] for a in range(8)) / 8
    cym = sum(P(a)[1] for a in range(8)) / 8
    if labels:
        for a in range(8):
            cube_label(S, P, a, cxm, cym)
    return cxm, cym


def cube_label(S, P, a, cxm, cym, dot=True):
    x, y = P(a)
    if dot:
        S.circle(x, y, 3, 'fi')
    if a == 4:                       # e3: inside the outline, its free side is the left
        S.text(x - 8, y + 4.5, blab(a), 12.5, anchor='end')
        return
    if a == 3:                       # e12: inside the outline, its free side is up and left
        S.text(x - 7, y - 7, blab(a), 12.5, anchor='end')
        return
    dx, dy = x - cxm, y - cym
    L = math.hypot(dx, dy)
    S.text(x + 14 * dx / L, y + 14 * dy / L + 4.5, blab(a), 12.5, anchor='start' if dx > 6 else ('end' if dx < -6 else 'middle'))


def spread(P, segs, avoid, fr=(0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8)):
    """for each segment, the fraction along it whose point lies farthest from the vertices and the points already chosen"""
    chosen = []
    for (x1, y1), (x2, y2) in segs:
        best = max(fr, key=lambda t: min(math.hypot(x1 + t * (x2 - x1) - u, y1 + t * (y2 - y1) - v) for u, v in avoid + chosen))
        chosen.append((x1 + best * (x2 - x1), y1 + best * (y2 - y1)))
    return chosen


def fig_hodge():
    S = Svg(420, 262, 'The complement a -> a xor 111 on the cube of labels: the Hodge star of the exterior algebra, and multiplication by I in Cl(2,0,1)')
    sig = {}
    for a in range(8):
        sig[a] = BC.reorder_sign(a, 7 ^ a)
    # sigma(S) is the sign of the permutation (S, S-bar): the textbook sign (sm16_labels.py checks the same for n = 1..8)
    for a in range(8):
        perm = [i for i in range(3) if a >> i & 1] + [i for i in range(3) if not a >> i & 1]
        inv = sum(1 for i in range(3) for j in range(i + 1, 3) if perm[i] > perm[j])
        need(sig[a] == (-1) ** inv, 'sigma(S) = sign of the permutation (S, S-bar)')
    P = cube_proj(40, 214, 92)
    S.text(8, 18, '(a) ⋆e_S = σ(S) e_S̄ in Λℝ³', 13, weight='600')
    S.text(8, 34, 'σ(S): sign of the permutation (S, S̄)', 11.5, 'mu')
    draw_cube(S, P)
    segs = [(P(a), P(7 ^ a)) for a in (0, 1, 2, 4)]
    for a, (p1, p2) in zip((0, 1, 2, 4), segs):
        S.line(*p1, *p2, 'c1' if sig[a] == 1 else 'c2', 2.2)
    for a, (bx, by) in zip((0, 1, 2, 4), spread(P, segs, [P(v) for v in range(8)])):
        S.badge(bx, by, SIGN_GLYPH[sig[a]], SIGN_TINT[sig[a]], 13, 8.5)
    # (b) multiplication by the top blade in Cl(2,0,1): e3 null
    A = BC.Alg((1, 1, 0))
    Q = cube_proj(240, 214, 88)
    S.text(222, 18, '(b) eₐ ↦ I eₐ in Cl(2,0,1)', 13, weight='600')
    S.text(222, 34, 'e₃ null: 4 of 8 labels go to 0', 11.5, 'mu')
    cxm, cym = draw_cube(S, Q, labels=False)
    zero, arrows = 0, []
    for a in range(8):
        s_, c = A.blade_mul(7, a)
        need(c == 7 ^ a, 'I e_a has the complement label')
        if s_ == 0:
            zero += 1
            continue
        arrows.append((a, c, s_))
    need(zero == 4, 'multiplication by I reaches 2^(p+q) = 4 labels')
    segs = [(Q(a), Q(c)) for a, c, _ in arrows]
    for (a, c, s_), ((x1, y1), (x2, y2)) in zip(arrows, segs):
        S.arrow(x1 + 0.06 * (x2 - x1), y1 + 0.06 * (y2 - y1), x1 + 0.9 * (x2 - x1), y1 + 0.9 * (y2 - y1), 'c1' if s_ == 1 else 'c2', 'f1' if s_ == 1 else 'f2', 2)
    for (a, c, s_), (bx, by) in zip(arrows, spread(Q, segs, [Q(v) for v in range(8)])):
        S.badge(bx, by, SIGN_GLYPH[s_], SIGN_TINT[s_], 13, 8.5)
    for a in range(8):
        if A.blade_mul(7, a)[0] == 0:
            x, y = Q(a)
            S.badge(x, y, '0', 'k0', 11, 7.5, 'ax')
            cube_label(S, Q, a, cxm, cym, dot=False)
        else:
            cube_label(S, Q, a, cxm, cym)
    # Cl(3,0): I e_a = +- sigma(S) e_S-bar: the signs agree on grades 0, 1 and differ on grades 2, 3
    A3 = BC.Alg((1, 1, 1))
    agree = {k: set() for k in range(4)}
    for a in range(8):
        s_, c = A3.blade_mul(7, a)
        agree[pc(a)].add(s_ * sig[a])
    need(agree == {0: {1}, 1: {1}, 2: {-1}, 3: {-1}}, 'I e_a against sigma in Cl(3,0)')
    S.text(8, 254, '+ blue, − orange; a vertex marked 0: I eₐ = 0', 11.5, 'mu')
    return S.svg(), agree


# ------------------------------------------------------------------------------------------------ 7. two mirrors make a rotation, and a boost
def mv_vec(*xs):
    return {1 << i: Fr(x) for i, x in enumerate(xs) if x != 0}


def mirror(A, a, x):
    """x -> -a x a^-1, by the bit rule"""
    aa = A.mul(a, a)
    need(set(aa) <= {0} and aa.get(0, 0) != 0, 'a mirror needs a normal with a non-zero scalar square')
    ainv = {k: v / aa[0] for k, v in a.items()}
    return {k: -v for k, v in A.mul(A.mul(a, x), ainv).items()}


def compose_matrix(A, first, second):
    cols = []
    for i in range(2):
        e = {1 << i: Fr(1)}
        y = mirror(A, second, mirror(A, first, e))
        need(set(y) <= {1, 2}, 'a mirror keeps vectors vectors')
        cols.append([y.get(1, Fr(0)), y.get(2, Fr(0))])
    return [[cols[0][0], cols[1][0]], [cols[0][1], cols[1][1]]]


def fig_mirrors():
    ex = json.load(open(os.path.join(CHK, 'selfcheck', 'mirrors.json'), encoding='utf8'))['examples']
    S = Svg(420, 300, 'Two mirrors make a rotation in Cl(0,2) and a boost in Cl(1,1): the examples of the mirrors step, recomputed by the rule')
    out = {}
    for key, eps, ox, oyp in (('rotation_3_4_5', (-1, -1), 105, 150), ('boost_5_4_3_4', (1, -1), 315, 196)):
        A = BC.Alg(eps)
        n1, n2 = [[frac(c) for c in v] for v in ex[key]['mirror_normals']]
        Mst = [[frac(c) for c in row] for row in ex[key]['matrix']]
        a, b = mv_vec(*n1), mv_vec(*n2)
        nm = lambda v: '(' + ', '.join(map(frs, v)) + ')'
        orders = [(nm(n1) + ' then ' + nm(n2), a, b), (nm(n2) + ' then ' + nm(n1), b, a)]
        hit = [o for o in orders if compose_matrix(A, o[1], o[2]) == Mst]
        need(hit, 'the stored matrix of %s from the two mirrors' % key)
        label, first, second = hit[0]
        out[key] = label
        sc = 62 if eps == (-1, -1) else 50
        if eps == (-1, -1):
            to = lambda v: (ox + sc * float(v.get(1, 0)), oyp - sc * float(v.get(2, 0)))
            S.text(ox - 98, 18, 'a rotation in Cl(0,2)', 13, weight='600')
            x = mv_vec(Fr(6, 5), Fr(3, 5))
            for nrm, lab in ((first, 'mirror 1'), (second, 'mirror 2')):
                d = (-float(nrm.get(2, 0)), float(nrm.get(1, 0)))
                L = math.hypot(*d)
                d = (d[0] / L, d[1] / L)
                S.line(ox - 90 * d[0], oyp + 90 * d[1], ox + 90 * d[0], oyp - 90 * d[1], 'ax', 1.1, '5 3')
                S.badge(ox - 90 * d[0], oyp + 90 * d[1], lab[-1], 'k0', 11, 7.5, 'ax')
        else:
            to = lambda v: (ox + sc * float(v.get(2, 0)), oyp - sc * float(v.get(1, 0)))     # t up, x right
            S.text(ox - 98, 18, 'a boost in Cl(1,1)', 13, weight='600')
            x = mv_vec(Fr(1), Fr(0))
            for sg in (1, -1):
                S.line(ox - 1.5 * sc, oyp + sg * 1.5 * sc, ox + 1.5 * sc, oyp - sg * 1.5 * sc, 'ln', 1, '2 3')
            hyp = [(ox + sc * math.sinh(u), oyp - sc * math.cosh(u)) for u in [i / 20 for i in range(-18, 25)]]
            S.poly(hyp, 'ln', 1.4)
            S.text(ox + sc * math.sinh(0.75) + 5, oyp - sc * math.cosh(0.75) + 2, 't² − x² = 1', 10.5, 'mu', 'start')
            S.text(ox + 6, oyp - 2.35 * sc, 't', 12, 'mu')
            S.text(ox + 1.5 * sc + 4, oyp + 4, 'x', 12, 'mu')
            S.line(ox - 1.5 * sc, oyp, ox + 1.5 * sc, oyp, 'ax', 0.6)
            S.line(ox, oyp + 0.9 * sc, ox, oyp - 2.4 * sc, 'ax', 0.6)
            for nrm, lab in ((first, 'mirror 1'), (second, 'mirror 2')):
                d = (float(nrm.get(2, 0)), float(nrm.get(1, 0)))      # the Minkowski-orthogonal direction (t, x) = (n_x, n_t)
                L = math.hypot(*d)
                d = (d[0] / L, d[1] / L) if d[0] >= 0 else (-d[0] / L, -d[1] / L)
                S.line(ox - 0.9 * sc / d[0] * d[1], oyp + 0.9 * sc, ox + 2.3 * sc / d[0] * d[1], oyp - 2.3 * sc, 'ax', 1.1, '5 3')
                S.badge(ox - 0.9 * sc / d[0] * d[1], oyp + 0.9 * sc, lab[-1], 'k0', 11, 7.5, 'ax')
        x1 = mirror(A, first, x)
        x2 = mirror(A, second, x1)
        O = to({})
        S.arrow(*O, *to(x), 'ik', 'fi', 2)
        S.arrow(*O, *to(x1), 'ax', 'fm', 1.6, dash='4 3')
        S.arrow(*O, *to(x2), 'c1', 'f1', 2.4)
        for v, lab, cls in ((x, 'x', ''), (x1, 'x′', 'mu'), (x2, 'x″', '')):
            px, py = to(v)
            right = px >= O[0] - 1
            S.text(px + (7 if right else -7), py - 5, lab, 12.5, cls, 'start' if right else 'end', '600')
        M = Mst
        S.text(ox - 98, 270, 'x″ = M x, M = ((%s, %s), (%s, %s))' % (frs(M[0][0]), frs(M[0][1]), frs(M[1][0]), frs(M[1][1])), 11.5, 't2')
        S.text(ox - 98, 286, 'normals ' + label, 10.5, 'mu')
        if eps == (-1, -1):
            ang = math.degrees(math.atan2(float(M[1][0]), float(M[0][0])))
            out['angle'] = ang
            S.text(ox - 98, 36, 'mirrors %s° apart: a turn by %s°' % (fm(ang / 2), fm(ang)), 11.5, 'mu')
        else:
            out['rapidity'] = math.acosh(float(M[0][0]))
            S.text(ox - 98, 36, 'cosh = %s, sinh = %s: a boost' % (frs(M[0][0]), frs(M[1][0])), 11.5, 'mu')
    return S.svg(), out


# ------------------------------------------------------------------------------------------------ 8. the rotor of a turn is -1 after one full turn
def fig_rotor():
    S = Svg(420, 282, 'The rotor of a turn of the plane by phi, followed from phi = 0 to 720 degrees in steps of 5 degrees')
    A = BC.Alg((1, 1))
    sB, mB = A.blade_mul(2, 1)               # B = e2 e1
    need(mB == 3 and A.mul({3: sB}, {3: sB}) == {0: -1}, 'B = e2e1 squares to -1')
    rows = []
    for k in range(0, 145):
        ph = math.radians(5 * k)
        c, s = math.cos(ph / 2), math.sin(ph / 2)
        R = {0: c, 3: s * sB}
        Rr = {0: c, 3: -s * sB}                 # the reverse
        v = A.mul(A.mul(R, {1: 1.0}), Rr)
        ang = math.degrees(math.atan2(v.get(2, 0.0), v.get(1, 0.0)))
        rows.append((5 * k, R.get(0, 0.0), R.get(3, 0.0), v.get(1, 0.0), v.get(2, 0.0), ang))
    for k in range(73):
        a, b = rows[k], rows[k + 72]
        need(abs(a[1] + b[1]) < 1e-12 and abs(a[2] + b[2]) < 1e-12, 'R(phi + 360) = -R(phi)')
        need(abs(a[3] - b[3]) < 1e-12 and abs(a[4] - b[4]) < 1e-12, 'the same turn')
    need(abs(rows[72][1] + 1) < 1e-12 and abs(rows[144][1] - 1) < 1e-12, 'R(360) = -1, R(720) = 1')
    turn_sense = 1 if abs(((rows[18][5] - 90) + 180) % 360 - 180) < 1e-9 else -1
    x0, x1, yc, h = 46, 402, 146, 80
    X = lambda d: x0 + (x1 - x0) * d / 720
    Y = lambda v: yc - h * v
    for d in (0, 180, 360, 540, 720):
        S.line(X(d), yc - h - 6, X(d), yc + h + 6, 'ln', 0.8)
        S.text(X(d), yc + h + 34, '%d°' % d, 11.5, 'mu', 'middle')
    for v in (-1, 0, 1):
        S.line(x0, Y(v), x1, Y(v), 'ln', 0.8, None if v == 0 else '2 3')
        S.text(x0 - 6, Y(v) + 4, {1: '1', 0: '0', -1: '−1'}[v], 11.5, 'mu', 'end')
    S.poly([(X(r[0]), Y(r[3])) for r in rows], 'c2', 2)
    S.poly([(X(r[0]), Y(r[1])) for r in rows], 'c1', 2.4)
    for d in (0, 360, 720):
        r = rows[d // 5]
        S.circle(X(d), Y(r[1]), 4.5, 'f1 sk', 1.5)
        S.circle(X(d), Y(r[3]), 4.5, 'f2 sk', 1.5)
    S.text(x0, 18, 'scalar part of R = cos(φ/2) + sin(φ/2) B, B = e₂e₁, in Cl(2,0)', 12, weight='600')
    S.rect(x0, 30, 12, 3, 'f1'); S.text(x0 + 18, 36, 'the rotor: ⟨R⟩₀', 11.5)
    S.rect(x0 + 130, 30, 12, 3, 'f2'); S.text(x0 + 148, 36, 'the turned vector: x-part of R e₁ R̃', 11.5)
    S.text(X(360), Y(-1) + 20, 'R = −1', 12, anchor='middle', weight='600')
    S.text(X(360), Y(1) - 10, 'e₁ is home', 12, anchor='middle', weight='600')
    S.text(X(720), Y(1) - 10, 'R = +1', 12, anchor='end', weight='600')
    S.text(x1, yc + h + 50, 'φ, the angle of the turn', 11.5, 'mu', 'end')
    return S.svg(), {'steps': len(rows), 'turn_sense': turn_sense}


# ------------------------------------------------------------------------------------------------ 9. the null cone of R^{1,3} as a sphere; a boost acts by a Moebius map
def fig_null_sphere():
    txt = readlog('selfcheck/gravity/logs/gm_null_sphere.log')
    m = re.search(r'boost rotor (\d+/\d+) \+ (\d+/\d+) e_me_p \(B\^2 = 1, R R~ = 1\): \(a, b, c, d\) = \(([^)]*)\)', txt)
    need(m, 'gm_null_sphere.log: the boost along z')
    c0, c1 = frac(m.group(1)), frac(m.group(2))
    abcd = [frac(t) for t in m.group(3).split(',')]
    A = BC.Alg((1, -1, -1, -1))                 # generators e_m, e1, e2, e_p: t squares +1, space squares -1
    R = {0: c0, 9: c1}
    Rr = {0: c0, 9: -c1}
    need(A.mul(R, Rr) == {0: Fr(1)}, 'R R~ = 1')

    def P(x1, x2):
        r2 = x1 * x1 + x2 * x2
        return {1: (r2 + 1) / 2, 2: x1, 4: x2, 8: (r2 - 1) / 2}

    def zof(v):
        t, X, Y, Z = v.get(1, 0), v.get(2, 0), v.get(4, 0), v.get(8, 0)
        d = t - Z
        return (X / d, Y / d)
    pts = []
    DIRS = [(1, 0), (Fr(3, 5), Fr(4, 5)), (0, 1), (Fr(-4, 5), Fr(3, 5)), (-1, 0), (Fr(-3, 5), Fr(-4, 5)), (0, -1), (Fr(4, 5), Fr(-3, 5))]
    for ring in (Fr(4), Fr(1)):
        for c, s_ in DIRS:
            x1, x2 = ring * c, ring * s_
            v = P(x1, x2)
            need(A.mul(v, v) == {}, 'P(x) is null')
            w = A.mul(A.mul(R, v), Rr)
            need(A.mul(w, w) == {} and set(w) <= {1, 2, 4, 8}, 'the boost keeps the cone')
            pts.append(((x1, x2), zof(w)))
    a, b, c, d = abcd
    sense = None
    for (x1, x2), (y1, y2) in pts:
        z = complex(float(x1), float(x2))
        mob = (complex(float(a)) * z + complex(float(b))) / (complex(float(c)) * z + complex(float(d)))
        hit = abs(complex(float(y1), float(y2)) - mob) < 1e-12
        hit_inv = abs(complex(float(y1), float(y2)) - (complex(float(d)) * z - complex(float(b))) / (-complex(float(c)) * z + complex(float(a)))) < 1e-12
        s = 'map' if hit else ('inverse' if hit_inv else None)
        need(s is not None, 'the image is the Moebius map of the log, or its inverse')
        sense = sense or s
        need(s == sense, 'one sense for all points')
    S = Svg(420, 300, 'The projectivised null cone of R^{1,3} as a sphere; the boost 5/4 + 3/4 e_m e_p moves each null direction by a Moebius map')
    cx, cy, Rr_ = 138, 162, 112
    az, el = math.radians(28), math.radians(17)

    def proj(X, Y, Z):
        X1 = X * math.cos(az) - Y * math.sin(az)
        Y1 = X * math.sin(az) + Y * math.cos(az)
        sx = X1
        sy = -Y1 * math.sin(el) + Z * math.cos(el)
        dep = Y1 * math.cos(el) + Z * math.sin(el)
        return cx + Rr_ * sx, cy - Rr_ * sy, dep

    def sph(z1, z2):
        r2 = z1 * z1 + z2 * z2
        t = (r2 + 1) / 2
        return (z1 / t, z2 / t, (r2 - 1) / 2 / t)
    S.circle(cx, cy, Rr_, 'ln', 1.5)
    eq = [proj(math.cos(u), math.sin(u), 0) for u in [i * math.pi / 60 for i in range(121)]]
    run, runs = [eq[0]], []
    for q_ in eq[1:]:
        if (q_[2] >= 0) == (run[-1][2] >= 0):
            run.append(q_)
        else:
            runs.append(run); run = [run[-1], q_]
    runs.append(run)
    for rr in runs:
        S.poly([(x, y) for x, y, dd in rr], 'ax', 1.1, None if rr[-1][2] >= 0 else '3 3')
    for (x1, x2), (y1, y2) in pts:
        P0 = proj(*sph(float(x1), float(x2)))
        P1 = proj(*sph(float(y1), float(y2)))
        op = None if P0[2] >= 0 else '0.35'
        S.arrow(P0[0], P0[1], P1[0], P1[1], 'c2', 'f2', 1.3, 6, op=op)
        S.circle(P0[0], P0[1], 3.3, 'fs c1', 1.6, op)
        S.circle(P1[0], P1[1], 3.0, 'f1', None, op)
    N = proj(0, 0, 1)
    So = proj(0, 0, -1)
    S.circle(N[0], N[1], 4, 'fi'); S.text(N[0] + 8, N[1] - 6, 'ε: z = ∞', 12.5, weight='600')
    S.circle(So[0], So[1], 4, 'fi'); S.text(So[0] + 8, So[1] + 16, 'o: z = 0', 12.5, weight='600')
    lx = 266
    S.text(8, 18, 'null lines [P(x)], P(x) = o + x − ½x²ε, x ↔ z = x₁ + i x₂', 12, weight='600')
    S.circle(lx + 4, 58, 3.3, 'fs c1', 1.6); S.text(lx + 14, 62, 'the line [P(x)]', 11.5)
    S.circle(lx + 4, 78, 3.0, 'f1'); S.text(lx + 14, 82, 'its image R P(x) R̃', 11.5)
    tl = ['R = %s + %s eₘe_p:' % (frs(c0), frs(c1)), 'a boost along z;', 'on the plane', ('z ↦ (az + b)/(cz + d)' if sense == 'map' else 'z ↦ (dz − b)/(−cz + a)'),
          '(a, b, c, d) =', '(%s)' % ', '.join(frs(t) for t in abcd)]
    for i, t in enumerate(tl):
        S.text(lx, 108 + 15 * i, t, 11.5, 't2')
    for i, t in enumerate(['|z| = 4 goes to |z| = 1,', '|z| = 1 to |z| = 1/4:', 'toward o; dashed: the', 'back of the equator']):
        S.text(lx, 210 + 15 * i, t, 11.5, 'mu')
    return S.svg(), {'abcd': abcd, 'sense': sense, 'points': len(pts)}


# ------------------------------------------------------------------------------------------------ 10. the join of two points in the three plane-based algebras
def fig_joins():
    data = {}
    for kappa in (0, 1, -1):
        A = G1.eng_alg(kappa)
        O = G1.tri(A, 1, [0, 0, 0])
        rows = []
        for j in range(0, 33):
            if kappa == 0:
                d = Fr(j, 20)
                w, x = Fr(1), d
                exact = d * d
                df = float(d)
            elif kappa == 1:
                t = Fr(j, 32)
                w, x = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
                exact = x * x
                df = 2 * math.atan(float(t))
            else:
                t = Fr(j, 48)
                w, x = (1 + t * t) / (1 - t * t), 2 * t / (1 - t * t)
                exact = x * x
                df = 2 * math.atanh(float(t))
            need(G1.nsq(kappa, w, [x, 0, 0]) == 1, 'a normalised point')
            L = A.join(O, G1.tri(A, w, [x, 0, 0]))
            ll, simple = G1.jw2(A, L)
            need(simple and ll == exact, 'the join size by the rule')
            rows.append((df, math.sqrt(float(ll))))
        data[kappa] = rows
    S = Svg(420, 270, 'The size of the join of two points at distance d in the three plane-based algebras')
    x0, x1, y0, y1 = 44, 286, 236, 30
    dmax, smax = 1.65, 2.6
    X = lambda d: x0 + (x1 - x0) * d / dmax
    Y = lambda s: y0 - (y0 - y1) * s / smax
    for t in (0, 0.5, 1, 1.5):
        S.line(X(t), y0, X(t), y1, 'ln', 0.7)
        S.text(X(t), y0 + 16, fm(t), 11.5, 'mu', 'middle')
    for t in (0, 0.5, 1, 1.5, 2, 2.5):
        S.line(x0, Y(t), x1, Y(t), 'ln', 0.7)
        S.text(x0 - 6, Y(t) + 4, fm(t), 11.5, 'mu', 'end')
    S.line(X(math.pi / 2), y0, X(math.pi / 2), Y(1), 'ax', 0.8, '2 2')
    S.text(X(math.pi / 2), y0 - 4, 'π/2', 10.5, 'mu', 'end')
    style = {0: ('c1', 'f1', 'd · Cl(3,0,1), flat'), 1: ('c2', 'f2', 'sin d · Cl(4,0,0), S³'), -1: ('c3', 'f3', 'sinh d · Cl(3,1,0), H³')}
    for kappa in (0, 1, -1):
        cls, fcls, lab = style[kappa]
        rows = [r for r in data[kappa] if r[0] <= dmax + 1e-9]
        S.poly([(X(d), Y(s)) for d, s in rows], cls, 2.2)
        for d, s in rows[::4]:
            S.circle(X(d), Y(s), 2.6, fcls)
        dl, sl = rows[-1]
        S.text(x1 + 8, Y(sl) + 4, lab, 11.5, anchor='start')
    S.text(x0, 18, 'size of the join, √⟨L L̃⟩₀, against the distance d', 12, weight='600')
    S.text(x1, y0 + 32, 'd', 12, 'mu', 'end')
    S.text(x1 + 8, y0 + 32, 'dots: points by the rule', 11, 'mu')
    return S.svg(), {k: len(v) for k, v in data.items()}


# ------------------------------------------------------------------------------------------------ 11. the octahedron of the six planes
def fig_octahedron():
    txt = readlog('selfcheck/gravity/logs/aty_cone_defects.log')
    m = re.search(r"I\^2 by the bit rule: \{([^}]*)\}", txt)
    need(m, 'aty_cone_defects.log: I^2 line')
    logI2 = {k: int(v) for k, v in re.findall(r"'([^']+)': (-?\d+)", m.group(1))}
    need(len(logI2) == 4, 'four cells in the I^2 line')
    cells = {'Cl(4,0)': (1, 1, 1, 1), 'Cl(1,3)': (1, -1, -1, -1), 'Cl(0,4)': (-1, -1, -1, -1), 'Cl(3,1)': (1, 1, 1, -1)}
    for nm, eps in cells.items():
        need(BC.Alg(eps).sq(15) == logI2[nm], 'I^2 of %s against the log' % nm)
    planes = [a for a in range(16) if pc(a) == 2]
    edges = [(a, b) for i, a in enumerate(planes) for b in planes[i + 1:] if pc(a & b) == 1]
    anti = [(a, 15 ^ a) for a in planes if a < 15 ^ a]
    need(len(planes) == 6 and len(edges) == 12 and len(anti) == 3 and 6 + len(edges) + len(anti) == 21, 'octahedron counts')
    S = Svg(420, 292, 'The six coordinate planes of four generators as the vertices of an octahedron, with the complement as the antipodal map')
    cx, cy, R = 118, 150, 98
    lab = lambda a: blab(a, 0)
    posn = {0b0011: (cx, cy - R), 0b1100: (cx, cy + R), 0b0101: (cx - R, cy + 0.16 * R), 0b1010: (cx + R, cy - 0.16 * R),
            0b1001: (cx + 0.42 * R, cy + 0.36 * R), 0b0110: (cx - 0.42 * R, cy - 0.36 * R)}
    for a, b in edges:
        back = 0b0110 in (a, b)
        S.line(*posn[a], *posn[b], 'ax' if not back else 'ln', 1.3, '3 3' if back else None)
    for a, b in anti:
        S.line(*posn[a], *posn[b], 'c7', 1.6, '6 4')
    for a in planes:
        x, y = posn[a]
        S.circle(x, y, 15, 'k0 ik', 1.2)
        S.text(x, y + 4.5, lab(a), 12, anchor='middle', weight='600')
    tx = 238
    S.text(8, 18, 'planes e_ab: vertices; one shared index: an edge', 12, weight='600')
    S.text(8, 34, 'dashed through the centre: the complement, a disjoint plane', 11.5, 'mu')
    S.text(tx, 66, 'I e_ab by the rule', 12, 't2', weight='600')
    S.text(tx + 70, 84, 'Cl(4,0)', 11.5, 'mu', 'middle')
    S.text(tx + 140, 84, 'Cl(1,3)', 11.5, 'mu', 'middle')
    res = {}
    for i, a in enumerate(sorted(planes)):
        y = 104 + 19 * i
        S.text(tx, y, lab(a), 12)
        for j, nm in enumerate(('Cl(4,0)', 'Cl(1,3)')):
            s, c = BC.Alg(cells[nm]).blade_mul(15, a)
            need(c == 15 ^ a, 'I e_ab is the complementary plane')
            res[(nm, a)] = s
            S.text(tx + 70 + 70 * j, y, ('+' if s == 1 else '−') + lab(c), 12, anchor='middle')
    y = 104 + 19 * 6 + 8
    S.text(tx, y, 'J² = I²: ' + ('+1' if logI2['Cl(4,0)'] == 1 else '−1') + ' and ' + ('+1' if logI2['Cl(1,3)'] == 1 else '−1'), 11.5, 't2')
    S.text(tx, y + 16, 'real split 3 + 3 in Cl(4,0);', 11.5, 'mu')
    S.text(tx, y + 31, 'a complex structure in Cl(1,3)', 11.5, 'mu')
    S.text(8, 282, '21 pairs of planes = 6 vertices + 12 edges + 3 antipodal pairs', 11.5, 't2')
    return S.svg(), {'I2': logI2}


# ------------------------------------------------------------------------------------------------ 12. Riemann = Ricci + Weyl, by n (catw_lines.log)
def fig_counts():
    txt = readlog('selfcheck/proofs/logs/catw_lines.log')
    rows = [(int(n), int(k), int(r), int(w)) for n, k, r, w in re.findall(r'catl\.B1-B4 n=(\d+): the two routes give the same \(kernel, Ricci, Weyl\) = \((\d+), (\d+), (\d+)\)', txt)]
    need([r[0] for r in rows] == list(range(2, 9)), 'catw_lines.log: n = 2..8')
    o4 = readlog('selfcheck/proofs/logs/opened_4.log')
    m = re.search(r'Ricci \[([\d, ]+)\], Weyl \[([\d, ]+)\]', o4)
    need(m, 'opened_4.log: the stored counts')
    ric = [int(t) for t in m.group(1).split(',')]
    wey = [int(t) for t in m.group(2).split(',')]
    for i, (n, k, r, w) in enumerate(rows[:len(ric)]):
        need((r, w) == (ric[i], wey[i]), 'the two logs agree at n = %d' % n)
        need(k == r + w and k == n * n * (n * n - 1) // 12, 'Riemann = Ricci + Weyl = n^2(n^2-1)/12 at n = %d' % n)
    S = Svg(420, 278, 'The dimensions of the curvature tensors for n = 2 to 8: Riemann = Ricci part + Weyl part, from the Bianchi map')
    x0, x1, y0, rh = 40, 300, 50, 29
    kmax = max(r[1] for r in rows)
    X = lambda v: x0 + (x1 - x0) * v / kmax
    S.text(8, 18, 'dim of the curvature tensors = Ricci part + Weyl part', 12, weight='600')
    S.rect(x0, 26, 12, 10, 'f1'); S.text(x0 + 17, 35, 'Ricci n(n+1)/2', 11.5)
    S.rect(x0 + 120, 26, 12, 10, 'f2'); S.text(x0 + 137, 35, 'Weyl', 11.5)
    for i, (n, k, r, w) in enumerate(rows):
        y = y0 + i * rh
        S.text(x0 - 8, y + 15, 'n = %d' % n, 12, 'mu', 'end')
        S.rect(x0, y + 4, max(X(r) - x0, 1.5), 15, 'f1', 2)
        if w:
            S.rect(X(r) + 1.5, y + 4, max(X(r + w) - X(r) - 1.5, 1.5), 15, 'f2', 2)
        S.text(X(k) + 6, y + 16, '%d = %d + %d' % (k, r, w), 12, anchor='start')
    y = y0 + 7 * rh + 14
    S.text(x0, y, 'n = 2: the Ricci part is the scalar alone; Weyl starts at n = 4', 11.5, 'mu')
    return S.svg(), rows


# ------------------------------------------------------------------------------------------------ 13. the Weyl eigenvalues of S^4, CP^2 and Taub-NUT (aty_matter_models.log)
def fig_weyl():
    txt = readlog('selfcheck/gravity/logs/aty_matter_models.log')
    m = re.search(r'E_a\(0\) = 0 exactly, all 16 components, at the 8 points: ([^(]*)\(', txt)
    need(m, 'aty_matter_models.log: the Taub-NUT points')
    pts = []
    for part in m.group(1).strip().rstrip(';').split(';'):
        mm = re.match(r'\s*m = ([\d/]+) at r = (.*)', part)
        need(mm, 'a Taub-NUT point group')
        for r in mm.group(2).split(','):
            pts.append((frac(mm.group(1)), frac(r)))
    need(len(pts) == 8, 'eight Taub-NUT points')
    m2 = re.search(r'with eigenvalues \{double - mu\} x \(([-\d, ]+)\), mu = m/\(r \+ m\)\^3, and W- is type O, at the 8 points', txt)
    need(m2, 'aty_matter_models.log: the Taub-NUT eigenvalues')
    patt = [int(t) for t in m2.group(1).split(',')]
    m3 = re.search(r"W\+ type D \['double (-?\d+), simple (-?\d+)'\]; \|Rm\|\^2 = (\d+), \|W\+\|\^2 = (\d+)", txt)
    need(m3, 'aty_matter_models.log: CP2')
    cp_double, cp_simple = int(m3.group(1)), int(m3.group(2))
    need(re.search(r'S4: R_abcd = d_ac d_bd - d_ad d_bc exactly \(sectional curvature 1\) at 3 points, W\+ and W- type O', txt), 'aty_matter_models.log: S4')
    m4 = re.search(r'S4: the engine\'s E_a\(c\) = 0 exactly for c = (-?\d+)', txt)
    m5 = re.search(r'CP2: the engine\'s E_a\(c\) = 0 exactly for c = (-?\d+)', txt)
    need(m4 and m5, 'aty_matter_models.log: the Einstein constants')
    S = Svg(420, 318, 'The eigenvalues of the self-dual Weyl part W+ on S^4, CP^2 and Taub-NUT, from the gravity engine in the cell (4,0)')
    S.text(8, 18, 'the eigenvalues of W⁺ and W⁻, gravity engine, cell (4,0)', 12, weight='600')
    cols = [8, 112, 186, 262, 336, 362]
    heads = ['metric', 'point', 'μ', 'W⁺', 'W⁻', 'E_a(c)=0']
    for x, h in zip(cols, heads):
        S.text(x, 44, h, 11.5, 'mu')
    S.line(8, 50, 412, 50, 'ln', 1)
    rows = [('S⁴ (round)', '3 points', '', '0, 0, 0', '0', 'c = ' + m4.group(1).replace('-', '−')),
            ('CP² (Fubini–Study)', '3 points', '', '%s, %s, %s' % (frs(cp_simple), frs(cp_double), frs(cp_double)), '0', 'c = ' + m5.group(1).replace('-', '−'))]
    pat = ', '.join(('−' if k > 0 else '') + ('' if abs(k) == 1 else str(abs(k))) + 'μ' for k in patt)
    for mm_, r in pts:
        mu = mm_ / (r + mm_) ** 3
        ev = [-mu * k for k in patt]
        need(sum(ev) == 0, 'W+ is trace-free')
        rows.append(('Taub–NUT', 'm %s, r %s' % (frs(mm_), frs(r)), frs(mu), pat, '0', 'c = 0'))
    for i, row in enumerate(rows):
        y = 70 + 20 * i + (6 if i >= 2 else 0) + (4 if i >= 1 else 0)
        if i in (1, 2):
            S.line(8, y - 15, 412, y - 15, 'ln', 0.6)
        for j, (x, t) in enumerate(zip(cols, row)):
            if i >= 3 and j == 0:
                continue
            S.text(x, y, t, 11 if j == 2 else 11.5, '' if j != 1 else 't2')
    S.text(8, 306, 'μ = m/(r + m)³; W⁺ of type D on CP² and Taub–NUT, W⁻ = 0 on all three', 11.5, 'mu')
    return S.svg(), {'points': pts, 'pattern': patt, 'cp2': (cp_simple, cp_double)}


# ------------------------------------------------------------------------------------------------ 14. Gauss-Bonnet and the signature with an edge cone (aty_cone_defects.log)
def fig_cones():
    txt = readlog('selfcheck/gravity/logs/aty_cone_defects.log')
    s4 = [(frac(b), frac(e1), frac(e2)) for b, e1, e2 in re.findall(r'beta = ([\d/]+): Euler integral ([\d/]+) \(S\^4, vol [^)]*\) = [^;]*;\s+([\d/]+) \(S\^2 x football\)', txt)]
    cpe = [(frac(b), frac(v)) for b, v in re.findall(r'beta = ([\d/]+): \(1/32 pi\^2\) int eps R\^R = ([-\d/]+) exactly', txt)]
    cps = [(frac(b), frac(v)) for b, v in re.findall(r'beta = ([\d/]+): \(1/12 pi\^2\) int sum R\^ab R\^ab = ([-\d/]+) exactly', txt)]
    need(len(s4) == 5 and len(cpe) == 4 and len(cps) == 4, 'aty_cone_defects.log: the exact integrals')
    for b, e1, e2 in s4:
        need(e1 == 2 * b and e2 == 4 * b, 'chi - (1 - beta) chi(Sigma) on S^4 and S^2 x football')
    for b, v in cpe:
        need(v == 1 + 2 * b, '1 + 2 beta on CP^2')
    for b, v in cps:
        need(v == -(2 + b * b) / 3, 'tau (2 + beta^2)/3 on CP^2, tau = -1')
    S = Svg(420, 414, 'The Euler and signature integrals of metrics with an edge cone of angle 2 pi beta, against beta')
    x0, x1 = 46, 300
    bmax = 3.2
    X = lambda b: x0 + (x1 - x0) * b / bmax

    def axes(y0, y1, lo, hi, ticks):
        Y = lambda v: y0 - (y0 - y1) * (v - lo) / (hi - lo)
        for t in ticks:
            S.line(x0, Y(t), x1, Y(t), 'ln', 0.7)
            S.text(x0 - 6, Y(t) + 4, frs(t) if isinstance(t, Fr) else str(t).replace('-', '−'), 11.5, 'mu', 'end')
        for t in (0, 1, 2, 3):
            S.line(X(t), y0, X(t), y1, 'ln', 0.7)
            S.text(X(t), y0 + 16, str(t), 11.5, 'mu', 'middle')
        return Y
    S.text(8, 18, 'Euler integral (1/32π²)∫ε R∧R = χ(M) − (1 − β)χ(Σ)', 12, weight='600')
    Y = axes(220, 36, 0, 13, [0, 4, 8, 12])
    bs = [i / 20 for i in range(0, 61)]
    series = [('c1', 'f1', lambda b: 4 * b, [(b, e2) for b, _, e2 in s4], 'S² × football: 4β'),
              ('c2', 'f2', lambda b: 2 * b, [(b, e1) for b, e1, _ in s4], 'S⁴ ⊃ S²: 2β'),
              ('c3', 'f3', lambda b: 1 + 2 * b, cpe, 'CP² ⊃ CP¹: 1 + 2β')]
    for cls, fcls, fn, pts, lab in series:
        S.poly([(X(b), Y(fn(b))) for b in bs], cls, 2)
        for b, v in pts:
            S.circle(X(float(b)), Y(float(v)), 4, fcls + ' sk', 1.5)
        S.text(x1 + 6, Y(fn(3)) + 4, lab, 11.5)
    S.line(X(1), 220, X(1), 36, 'ax', 0.9, '3 3')
    S.text(X(1) + 4, 50, 'β = 1: smooth, χ(M)', 11, 'mu')
    S.text(8, 262, 'signature integral (1/12π²)∫Σ R^ab∧R^ab on CP² ⊃ CP¹', 12, weight='600')
    Y2 = axes(388, 290, -3.6, 0, [0, -1, -2, -3])
    S.poly([(X(b), Y2(-(2 + b * b) / 3)) for b in [i / 20 for i in range(0, 61)] if -(2 + b * b) / 3 >= -3.6], 'c7', 2)
    for b, v in cps:
        S.circle(X(float(b)), Y2(float(v)), 4, 'f7 sk', 1.5)
    cs_ = sorted(cps)
    S.text(8, 278, 'exact: %s at β = %s' % (', '.join(frs(v) for b, v in cs_), ', '.join(frs(b) for b, v in cs_)), 11.5, 't2')
    S.text(x1 + 6, Y2(-(2 + 2.9 ** 2) / 3) + 4, 'τ(2 + β²)/3,', 11.5)
    S.text(x1 + 6, Y2(-(2 + 2.9 ** 2) / 3) + 19, 'τ = −1', 11.5)
    S.text(x1 - 4, 408, 'β (the cone angle is 2πβ)', 11.5, 'mu', 'end')
    return S.svg(), {'s4': s4, 'cpe': cpe, 'cps': cps}


# ------------------------------------------------------------------------------------------------ 15. the circles of the toroidal coordinates and the Skyrme profiles (skyrme_holonomy.log)
def fig_toroidal():
    txt = readlog('selfcheck/proofs/logs/skyrme_holonomy.log')
    m = re.search(r"Pythagorean data \(r, rho\^2, theta/pi, f/pi\) = \[(.*?)\]: theta", txt)
    need(m, 'skyrme_holonomy.log: the line data')
    lines = [tuple(frac(x) for x in t) for t in re.findall(r"\('([\d/]+)', (\d+), '([\d/]+)', '([\d/]+)'\)", m.group(1))]
    need(len(lines) == 3, 'three line data')
    for r, rho2, th, f in lines:
        need(th * th == r * r / (r * r + rho2) and f == 1 - th, 'theta/pi = r/sqrt(r^2 + rho^2), f/pi = 1 - theta/pi')
    m = re.search(r"orthogonal to \|x\| = a: c\^2 - R\^2 = a\^2 for centre c = \(s \+ a\^2/s\)/2 and radius R = \(a\^2/s - s\)/2, data \(a\^2, rho\^2, s\) = \[(.*?)\]", txt)
    need(m, 'skyrme_holonomy.log: the circle data')
    circ = [tuple(frac(x) for x in t) for t in re.findall(r"\('([\d/]+)', '([\d/]+)', '([\d/]+)'\)", m.group(1))]
    need(len(circ) == 5, 'five circle data')
    m = re.search(r"rational where pq is a square: \[(.*?)\]\n", txt)
    need(m, 'skyrme_holonomy.log: the circle holonomies')
    theta = [(tuple(frac(x) for x in t[:3]), frac(t[3])) for t in re.findall(r"\(\('([\d/]+)', '([\d/]+)', '([\d/]+)'\), '([\d/]+)'\)", m.group(1))]
    need(len(theta) == 3, 'three circle holonomies')
    for (a2, rho2, s), Th in theta:
        a, rho = math.sqrt(a2), math.sqrt(rho2)
        beta = 2 * a * rho / (a2 + rho2)
        y = 2 * math.atanh(float(s) / a)
        need(abs(float(Th) - (1 - math.sinh(y) / math.sqrt(beta ** 2 + math.sinh(y) ** 2))) < 1e-12, "Theta/pi against the paper's (3.9)")
    for a2, rho2, s in circ:
        c, R = (s + a2 / s) / 2, (a2 / s - s) / 2
        need(c * c - R * R == a2, 'the circle is orthogonal to |x| = a')
    S = Svg(420, 420, 'The circles of the toroidal coordinates in the plane of n and e4, and the Skyrme profiles of the instanton holonomy along lines and circles')
    S.text(8, 18, '(a) the χ-circles in the plane of n and e₄ (units of a = 1/κ)', 12, weight='600')
    ox, oy, sc = 112, 118, 56
    S.line(ox - 100, oy, 410, oy, 'ax', 0.8)
    S.line(ox, oy - 86, ox, oy + 86, 'ax', 0.8)
    S.text(406, oy - 6, 'n', 12, 'mu', 'end')
    S.text(ox + 6, oy - 76, 'e₄', 12, 'mu')
    S.circle(ox, oy, sc, 'ln', 1.2)
    S.add('<circle cx="%s" cy="%s" r="%s" class="ax" stroke-width="1.2" stroke-dasharray="4 3" fill="none"/>' % (fm(ox), fm(oy), fm(sc)))
    S.text(ox - sc * 0.72, oy - sc * 0.72 - 5, '|x| = a', 11.5, 'mu', 'end')
    ratios = sorted(set(float(s) / math.sqrt(float(a2)) for a2, _, s in circ))
    ratios = [u for u in ratios if ox + sc / u <= 414]
    for k, u in enumerate(ratios):
        c, R = (u + 1 / u) / 2, (1 / u - u) / 2
        S.add('<circle cx="%s" cy="%s" r="%s" class="c%d" stroke-width="1.6" fill="none"/>' % (fm(ox + sc * c), fm(oy), fm(sc * R), 1 if k % 2 == 0 else 3))
        S.circle(ox + sc * u, oy, 2.6, 'fi')
    S.circle(ox + sc, oy, 4.2, 'f2')
    S.line(ox + sc, oy, 318, 186, 'ax', 0.8)
    S.text(322, 190, 'the 2-sphere', 11, 't2')
    S.text(322, 204, '|x| = a, x₄ = 0', 11, 't2')
    S.text(8, 222, 'each circle passes through s n (dot) and (a²/s) n; c² − R² = a²', 11, 'mu')
    # (b) the line profile
    S.text(8, 246, '(b) along lines: f/π', 12, weight='600')
    S.text(214, 246, '(c) along circles: Θ/π', 12, weight='600')
    def panel(px0, px1, py0, py1, xmax, curves, pts, xlab, offs=None):
        X = lambda v: px0 + (px1 - px0) * v / xmax
        Y = lambda v: py0 - (py0 - py1) * v
        for t in (0, 0.5, 1):
            S.line(px0, Y(t), px1, Y(t), 'ln', 0.7)
            S.text(px0 - 5, Y(t) + 4, fm(t), 11, 'mu', 'end')
        for t in range(0, int(xmax) + 1):
            S.line(X(t), py0, X(t), py1, 'ln', 0.7)
            S.text(X(t), py0 + 15, str(t), 11, 'mu', 'middle')
        for cls, fn in curves:
            S.poly([(X(v), Y(fn(v))) for v in [xmax * i / 80 for i in range(81)]], cls, 2)
        for k, (fcls, xv, yv, lab) in enumerate(sorted(pts, key=lambda t: t[1])):
            S.circle(X(xv), Y(yv), 4, fcls + ' sk', 1.5)
            dx, dy, an = offs[k] if offs else (7, -7, 'start')
            S.text(X(xv) + dx, Y(yv) + dy, lab, 11, 't2', an)
        S.text(px1, py0 + 30, xlab, 11, 'mu', 'end')
    panel(40, 196, 384, 262, 3, [('c2', lambda x: 1 - x / math.sqrt(1 + x * x))],
          [('f2', float(r / math.sqrt(rho2)), float(f), frs(f)) for r, rho2, th, f in lines], 'r/λ', [(-8, -3, 'end'), (8, 13, 'start'), (8, -7, 'start')])
    betas = []
    pts = []
    for (a2, rho2, s), Th in theta:
        a, rho = math.sqrt(float(a2)), math.sqrt(float(rho2))
        beta = 2 * a * rho / (float(a2) + float(rho2))
        y = 2 * math.atanh(float(s) / a)
        betas.append(beta)
        pts.append(('f1' if abs(beta - 1) < 1e-12 else 'f3', y, float(Th), frs(Th)))
    bset = sorted(set(round(b, 12) for b in betas), reverse=True)
    curves = [('c1' if abs(b - 1) < 1e-12 else 'c3', (lambda bb: (lambda y: 1 - math.sinh(y) / math.sqrt(bb * bb + math.sinh(y) ** 2) if y > 0 else 1.0))(b)) for b in bset]
    panel(244, 404, 384, 262, 3, curves, pts, 'κρ, the distance in H³')
    S.text(300, 290, 'β = 1', 11, 't2')
    S.text(300, 304, 'β = %s' % fm(min(bset)), 11, 't2')
    S.rect(288, 283, 9, 3, 'f1'); S.rect(288, 297, 9, 3, 'f3')
    return S.svg(), {'lines': lines, 'circles': circ, 'theta': theta, 'betas': bset}


# ------------------------------------------------------------------------------------------------ 16. the 3-cube: signed edges and the faces
def fig_cube_chains():
    txt = readlog('selfcheck/proofs/logs/reruns/cat_check.log')
    m = re.search(r'K1d: brute force on the 3-cube \(2\^12 sign assignments\): (\d+) have all six squares anticommuting', txt)
    need(m, 'cat_check.log: K1d')
    n_ok = int(m.group(1))
    # the edge sign of K1a/K1b: e_i e_a = (-1)^{#{j in a: j < i}} e_(a + i)
    A = BC.Alg((1, 1, 1))
    sgn = {}
    for a, b in CUBE_EDGES:
        i = (a ^ b).bit_length() - 1
        s, c = A.blade_mul(1 << i, a)
        need(c == b and s == (-1) ** pc(a & ((1 << i) - 1)), 'the edge sign is the bit-rule sign')
        sgn[(a, b)] = s
    squares = [(a, i, j) for a in range(8) for i in range(3) for j in range(i + 1, 3) if not a >> i & 1 and not a >> j & 1]
    need(len(squares) == 6, 'six squares')
    for a, i, j in squares:
        u, v, w = a | 1 << i, a | 1 << j, a | 1 << i | 1 << j
        prod = sgn[(a, u)] * sgn[(u, w)] * sgn[(a, v)] * sgn[(v, w)]
        need(prod == -1, 'every square anticommutes')
    # brute force, as K1d does: the sign assignments with all six squares anticommuting
    E = CUBE_EDGES
    cnt = 0
    for mask in range(1 << len(E)):
        s = {e: (-1 if mask >> k & 1 else 1) for k, e in enumerate(E)}
        if all(s[(a, a | 1 << i)] * s[(a | 1 << i, a | 1 << i | 1 << j)] * s[(a, a | 1 << j)] * s[(a | 1 << j, a | 1 << i | 1 << j)] == -1 for a, i, j in squares):
            cnt += 1
    need(cnt == n_ok, 'the count of anticommuting assignments against cat_check.log')
    S = Svg(420, 300, 'The cube of labels at n = 3: the signs of the rule on its 12 edges make all 6 squares anticommute; the faces of the cube')
    P = cube_proj(44, 244, 112)
    S.text(8, 18, 'edge a → a ∪ {i}: the sign of eᵢeₐ', 12, weight='600')
    S.text(8, 34, 'solid +, dashed −; every square: product −1', 11.5, 'mu')
    for (a, b), s in sgn.items():
        (x1, y1), (x2, y2) = P(a), P(b)
        S.line(x1, y1, x2, y2, 'c1' if s == 1 else 'c2', 2.4, None if s == 1 else '6 4')
    for a, i, j in squares:
        cs = [P(a), P(a | 1 << i), P(a | 1 << i | 1 << j), P(a | 1 << j)]
        x = sum(p[0] for p in cs) / 4
        y = sum(p[1] for p in cs) / 4
        S.text(x, y + 4, '−1', 10.5, 'mu', 'middle')
    for a in range(8):
        x, y = P(a)
        S.circle(x, y, 3.2, 'fi')
    cxm = sum(P(a)[0] for a in range(8)) / 8
    cym = sum(P(a)[1] for a in range(8)) / 8
    for a in range(8):
        cube_label(S, P, a, cxm, cym, dot=False)
    tx = 262
    faces = {}
    for S_ in range(8):
        for T_ in range(8):
            if S_ & ~T_ == 0:
                k = pc(T_ ^ S_)
                faces[k] = faces.get(k, 0) + 1
    need(faces == {0: 8, 1: 12, 2: 6, 3: 1} and sum(faces.values()) == 27, 'the 27 = 3^3 faces')
    S.text(tx, 70, 'faces = arrows S ⊆ T', 12, 't2', weight='600')
    for k, (nm, cnt_) in enumerate((('vertices', faces[0]), ('edges', faces[1]), ('squares', faces[2]), ('cube', faces[3]))):
        S.text(tx, 92 + 18 * k, nm, 12)
        S.text(tx + 130, 92 + 18 * k, str(cnt_), 12, anchor='end', weight='600')
    S.line(tx, 162, tx + 132, 162, 'ln', 1)
    S.text(tx, 178, 'together', 12)
    S.text(tx + 130, 178, '%d = 3³' % sum(faces.values()), 12, anchor='end', weight='600')
    for k, t in enumerate(['2¹² = 4096 edge signs:', '%d make all six' % n_ok, 'squares anticommute:', '2⁷, one gauge orbit', '(cat·K1d)']):
        S.text(tx, 210 + 15 * k, t, 11.5, 'mu')
    return S.svg(), {'anticommuting': cnt, 'faces': faces}


# ------------------------------------------------------------------------------------------------ the ten products the widgets store
def products():
    cases = [((1, 1, 1), 3, 6), ((1, 1, 1), 7, 2), ((-1, -1), 3, 3), ((1, -1, -1, -1), 15, 6), ((1, 1, 1, 1), 15, 5),
             ((1, 1, 0), 7, 4), ((1, 1, 0), 7, 3), ((0, 0, 0), 1, 6), ((0, 0, 0), 5, 2), ((1, -1, 1, -1), 11, 13)]
    out = []
    for eps, a, b in cases:
        s, c = BC.Alg(eps).blade_mul(a, b)
        out.append([list(eps), a, b, s, c])
    return out


FIGS = [('n2_tables', fig_n2), ('cells_lattice', fig_cells), ('clock_gauss', fig_clock), ('pseudoscalar', fig_pseudo),
        ('wedge_table', fig_wedge), ('hodge_cube', fig_hodge), ('two_mirrors', fig_mirrors), ('rotor_turns', fig_rotor),
        ('null_sphere', fig_null_sphere), ('three_joins', fig_joins), ('octahedron', fig_octahedron),
        ('curvature_counts', fig_counts), ('weyl_table', fig_weyl), ('cone_defects', fig_cones),
        ('toroidal_skyrme', fig_toroidal), ('cube_chains', fig_cube_chains)]

if __name__ == '__main__':
    if '--products' in sys.argv:
        print(json.dumps(products()))
        sys.exit(0)
    os.makedirs(OUT, exist_ok=True)
    for name, fn in FIGS:
        svg, info = fn()
        path = os.path.join(OUT, name + '.svg')
        with open(path, 'w', encoding='utf8', newline='\n') as fh:
            fh.write(svg)
        print('%-18s %6d bytes  %s' % (name, len(svg.encode('utf8')), str(info)[:150]))
