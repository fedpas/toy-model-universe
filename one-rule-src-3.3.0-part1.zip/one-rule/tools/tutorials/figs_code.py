#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""figs_code.py -- draws every figure of the coding tutorial (figs/*.svg) from the Atlas's own objects: the bit rule of
checks/researchers_checks/bitrule_A.py and the product of checks/selfcheck/spring_selfcheck.py (imported by path, never copied), the kernel
engines/bitrule.js, the records content/checks.json, content/check_runs.json, content/rows.json, content/derived/status.json, package.json,
the mutation logs checks/selfcheck/gravity/mut/*.mut.log, the check script checks/selfcheck/proofs/shifted_dirac.py with its log, and the
tutorial's own scripts/ and their logs.  The SVG is written by hand: text as text, colours as the page's variables with a fallback, no raster.
Deterministic: the same package gives the same bytes.  Run: python3 -I -B figs_code.py   (ATLAS_CHECKS=<the package's checks folder> when
this folder is not inside the package)."""
import os, sys, json, re, random, math
from fractions import Fraction as Fr
from itertools import combinations
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
def find_checks():
    d = os.environ.get('ATLAS_CHECKS')
    if d and os.path.isfile(os.path.join(d, 'researchers_checks', 'bitrule_A.py')): return os.path.abspath(d)
    d = HERE
    while os.path.dirname(d) != d:
        if os.path.isfile(os.path.join(d, 'checks', 'researchers_checks', 'bitrule_A.py')): return os.path.join(d, 'checks')
        d = os.path.dirname(d)
    raise SystemExit('the checks/ folder of the package is not found: set ATLAS_CHECKS')
CHECKS = find_checks(); ROOT = os.path.dirname(CHECKS)
sys.path.insert(0, os.path.join(CHECKS, 'researchers_checks')); sys.path.insert(0, os.path.join(CHECKS, 'selfcheck'))
from bitrule_A import BR, N_pairs, popcount, rank_fr
import spring_selfcheck as spring                                       # bmul and MV of the shipped tutorial's Part E
J = lambda p: json.load(open(os.path.join(ROOT, p), encoding='utf-8'))
TXT = lambda p: open(os.path.join(ROOT, p), encoding='utf-8').read()
SRC = os.path.join(ROOT, 'public', 'reports', 'tutorials', 'src', 'code')   # the tutorial's source folder: its figures and its scripts
OUT = os.path.join(SRC, 'figs'); os.makedirs(OUT, exist_ok=True)

# ------------------------------------------------------------------------------------------------ a small SVG writer
SANS = "system-ui, -apple-system, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif"; MONO = "ui-monospace, SFMono-Regular, Menlo, Consolas, monospace"
STYLE = ('.cf-t{fill:var(--ink,#1a1a19)}.cf-t2{fill:var(--ink2,#46463f)}.cf-mu{fill:var(--muted,#6b6b64)}.cf-acc{fill:var(--acc,#184f95)}'
         '.cf-box{fill:var(--tint,#f3f2ee);stroke:var(--line2,#c9c8c0);stroke-width:1}.cf-boxa{fill:var(--tint,#f3f2ee);stroke:var(--acc,#184f95);stroke-width:1.6}'
         '.cf-fr{fill:none;stroke:var(--line2,#c9c8c0);stroke-width:1}.cf-ln{stroke:var(--ink2,#46463f);stroke-width:1.2;fill:none}'
         '.cf-lna{stroke:var(--acc,#184f95);stroke-width:1.7;fill:none}.cf-fa{fill:var(--acc,#184f95)}.cf-fi{fill:var(--ink2,#46463f)}'
         '.cf-ok{fill:#3d8b4f}.cf-bad{fill:#b23a3a}.cf-or{fill:#c07a1a}.cf-gr{fill:#8a8a80}.cf-w{fill:#ffffff}'
         '.cf-sok{stroke:#3d8b4f}.cf-sbad{stroke:#b23a3a}.cf-sor{stroke:#c07a1a}.cf-sgr{stroke:#8a8a80}.cf-sacc{stroke:var(--acc,#184f95)}')
def esc(s): return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
def fmt(v): return ('%.1f' % v).rstrip('0').rstrip('.') if isinstance(v, float) else str(v)
class Svg:
    def __init__(s, name, w, h, label):
        s.name, s.w, s.h, s.label, s.items = name, w, h, label, []
    def rect(s, x, y, w, h, cls='cf-box', rx=4, op=None):
        s.items.append('<rect x="%s" y="%s" width="%s" height="%s" rx="%s" class="%s"%s/>' % (fmt(x), fmt(y), fmt(w), fmt(h), rx, cls, ' fill-opacity="%s"' % op if op is not None else ''))
    def text(s, x, y, t, cls='cf-t', size=13, anchor='start', weight=None, mono=False, italic=False):
        a = ' text-anchor="%s"' % anchor if anchor != 'start' else ''
        a += ' font-weight="%s"' % weight if weight else ''
        a += ' font-family="%s"' % MONO if mono else ''
        a += ' font-style="italic"' if italic else ''
        s.items.append('<text x="%s" y="%s" font-size="%s" class="%s"%s>%s</text>' % (fmt(x), fmt(y), fmt(size), cls, a, esc(t)))
    def line(s, x1, y1, x2, y2, cls='cf-ln', arrow=False, dash=None):
        s.items.append('<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s"%s%s/>' % (fmt(x1), fmt(y1), fmt(x2), fmt(y2), cls,
                       ' marker-end="url(#a-%s)"' % s.name if arrow else '', ' stroke-dasharray="%s"' % dash if dash else ''))
    def path(s, d, cls='cf-ln', arrow=False):
        s.items.append('<path d="%s" class="%s"%s/>' % (d, cls, ' marker-end="url(#a-%s)"' % s.name if arrow else ''))
    def circle(s, cx, cy, r, cls):
        s.items.append('<circle cx="%s" cy="%s" r="%s" class="%s"/>' % (fmt(cx), fmt(cy), fmt(r), cls))
    def save(s):
        head = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s" font-family="%s">'
                % (s.w, s.h, round(s.w * 1.3), round(s.h * 1.3), esc(s.label), SANS))
        defs = ('<style>%s</style><defs><marker id="a-%s" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                '<path d="M0,0 L10,5 L0,10 z" class="cf-fi"/></marker></defs>' % (STYLE, s.name))
        body = head + defs + ''.join(s.items) + '</svg>\n'
        open(os.path.join(OUT, s.name + '.svg'), 'w', encoding='utf-8').write(body)
        return len(body.encode('utf-8'))
def wrap(t, n):
    out, cur = [], ''
    for w in str(t).split(' '):
        if cur and len(cur) + 1 + len(w) > n: out.append(cur); cur = w
        else: cur = (cur + ' ' + w) if cur else w
    return out + [cur] if cur else out
def cut(t, n): t = str(t); return t if len(t) <= n else t[:n - 1] + '…'
SUB = '₀₁₂₃₄₅₆₇₈₉'
def blade(m, base=1):
    idx = [i for i in range(8) if m >> i & 1]
    return ''.join('e' + ''.join(SUB[int(d)] for d in str(i + base)) for i in idx) if idx else '1'
def cblade(m, base=1):
    idx = [i for i in range(8) if m >> i & 1]
    return 'e' + ''.join(SUB[i + base] for i in idx) if idx else '1'
def bits(m, n): return ''.join(str(m >> i & 1) for i in reversed(range(n)))
SIZES = {}

# ------------------------------------------------------------------------------------------------ 1. the three algebras of n = 2
def fig_n2():
    S = Svg('n2_tables', 360, 420, 'The products of the four blades of n = 2 for the squares (+,+), (-,-) and (0,0)')
    cases = [((1, 1), '(+,+): Cl(2,0) = M₂(ℝ)'), ((-1, -1), '(−,−): Cl(0,2) = ℍ'), ((0, 0), '(0,0): Λ(ℝ²)')]
    pos = [(5, 22), (188, 22), (5, 222)]; c = 33; counts = []
    for (eps, title), (x0, y0) in zip(cases, pos):
        A = BR(eps); z = mi = 0
        S.text(x0, y0 - 6, title, size=12.5, weight='600')
        for k in range(4):
            S.text(x0 + c * (k + 1) + c / 2, y0 + 21, cblade(k), cls='cf-t2', size=12.5, anchor='middle', weight='600')
            S.text(x0 + c / 2, y0 + c * (k + 1) + 21, cblade(k), cls='cf-t2', size=12.5, anchor='middle', weight='600')
        for a in range(4):
            for b in range(4):
                s = A.s(a, b); x, y = x0 + c * (b + 1), y0 + c * (a + 1)
                S.rect(x + 1, y + 1, c - 2, c - 2, 'cf-box' if s > 0 else 'cf-or' if s < 0 else 'cf-gr', rx=3, op=None if s > 0 else 0.28)
                S.text(x + c / 2, y + 21, ('+' if s > 0 else '−') + cblade(a ^ b) if s else '0', size=12, anchor='middle', mono=True)
                z += s == 0; mi += s < 0
        counts.append(('squares ' + title.split(':')[0], z, mi))
    x0, y0 = 196, 236
    S.text(x0, y0, 'row a, column b: e_a e_b', size=12.5, weight='600')
    S.text(x0, y0 + 20, '= s(a,b) e_(a XOR b)', size=12.5, mono=True)
    for i, (t, z, mi) in enumerate(counts):
        S.text(x0, y0 + 50 + 38 * i, t.replace('squares ', ''), size=12.5, weight='600')
        S.text(x0, y0 + 66 + 38 * i, '%d of 16 vanish, %d carry −' % (z, mi), cls='cf-t2', size=12.5)
    S.text(x0, y0 + 172, 'minus: orange; zero: grey', cls='cf-mu', size=11.5)
    SIZES[S.name] = S.save(); return counts

# ------------------------------------------------------------------------------------------------ 2. the sign of one product, the swaps drawn
def fig_swaps():
    eps, a, b = (1, -1, -1, -1), 0b1101, 0b0110; A = BR(eps); n = 4
    S = Svg('swaps', 360, 340, 'The sign of e1e3e4 times e2e3 in Cl(1,3): three swaps and one shared square')
    S.text(180, 18, 'e₁e₃e₄ · e₂e₃ in Cl(1,3), squares (+1, −1, −1, −1)', size=13, anchor='middle', weight='600')
    S.text(180, 38, 'each arc: a switch j of b passes a switch i > j of a', cls='cf-t2', size=12, anchor='middle')
    word = [('a', i) for i in range(n) if a >> i & 1] + [('b', j) for j in range(n) if b >> j & 1]
    xs, x = [], 34
    for k, (who, i) in enumerate(word):
        if k == 3: x += 18
        xs.append(x); x += 54
    yw = 160
    for (who, i), x in zip(word, xs):
        S.rect(x, yw, 46, 32, 'cf-boxa' if who == 'a' else 'cf-box', rx=5)
        S.text(x + 23, yw + 22, 'e' + SUB[i + 1], size=15, anchor='middle', weight='600')
        S.text(x + 23, yw + 50, who, cls='cf-mu', size=12, anchor='middle', italic=True)
    pairs = [(ka, kb) for ka, (wa, i) in enumerate(word) if wa == 'a' for kb, (wb, j) in enumerate(word) if wb == 'b' and j < i]
    assert len(pairs) == N_pairs(a, b)
    for h, (ka, kb) in enumerate(pairs):
        off = (h - 1) * 7; x1, x2 = xs[ka] + 23 + off, xs[kb] + 23 + off; top = yw - 28 - 30 * h
        S.path('M%s,%s C%s,%s %s,%s %s,%s' % (fmt(x2), yw - 2, fmt(x2), top, fmt(x1), top, fmt(x1), yw - 5), 'cf-lna', arrow=True)
        S.circle((x1 + x2) / 2, top + 22, 8, 'cf-boxa'); S.text((x1 + x2) / 2, top + 26, str(h + 1), cls='cf-acc', size=11, anchor='middle', weight='700')
    Np, sh = N_pairs(a, b), a & b; s = A.s(a, b); rs = -1 if Np & 1 else 1
    y = 236
    S.text(18, y, 'swaps   N = %d, so (−1)^N = %s' % (Np, '−1' if rs < 0 else '+1'), size=12.5, mono=True)
    S.text(18, y + 22, 'shared  a AND b = %s: %s' % (bits(sh, n), ', '.join('e%s² = %s' % (SUB[i + 1], '+1' if eps[i] > 0 else '−1' if eps[i] < 0 else '0') for i in range(n) if sh >> i & 1)), size=12.5, mono=True)
    S.text(18, y + 44, 'sign    s = %s · %s = %s' % ('−1' if rs < 0 else '+1', ' · '.join(('−1' if eps[i] < 0 else '+1' if eps[i] > 0 else '0') for i in range(n) if sh >> i & 1), '+1' if s > 0 else '−1' if s < 0 else '0'), size=12.5, mono=True)
    S.text(18, y + 66, 'label   %s XOR %s = %s → %s' % (bits(a, n), bits(b, n), bits(a ^ b, n), blade(a ^ b)), size=12.5, mono=True)
    S.rect(60, y + 78, 240, 26, 'cf-boxa', rx=6)
    S.text(180, y + 96, 'e₁e₃e₄ · e₂e₃ = %s%s' % ('+' if s > 0 else '−', blade(a ^ b)), size=14, anchor='middle', weight='700')
    SIZES[S.name] = S.save(); return Np, s, a ^ b

# ------------------------------------------------------------------------------------------------ 3. the kernel, JavaScript and Python line for line
def fig_kernel():
    js = TXT('engines/bitrule.js').split('\n'); py = TXT('checks/researchers_checks/bitrule_A.py').split('\n')
    find = lambda L, pat: next(i + 1 for i, l in enumerate(L) if re.search(pat, l))
    jsn = [('popcount', find(js, r'^export const popcount'), find(js, r'^export const popcount')),
           ('nPairs', find(js, r'^export function nPairs'), find(js, r'^export function nPairs') + 4),
           ('reorderSign', find(js, r'^export const reorderSign'), find(js, r'^export const reorderSign')),
           ('sign', find(js, r'^export function sign'), find(js, r'^export function sign') + 4)]
    pyn = [('popcount', find(py, r'^def popcount'), find(py, r'^def popcount')),
           ('N_pairs', find(py, r'^def N_pairs'), find(py, r'^def N_pairs') + 5),
           ('(inside s)', find(py, r'v = -1 if N_pairs'), find(py, r'v = -1 if N_pairs')),
           ('BR.s', find(py, r'def s\(self, a, b\)'), find(py, r'def s\(self, a, b\)') + 6)]
    code_lines = sum(1 for _, a, b in jsn for i in range(a, b + 1) if js[i - 1].strip() and not js[i - 1].strip().startswith(('/**', '//')))
    what = ['count the switches that are on', 'N(a,b): the pairs i in a, j in b, j < i', '(−1)^N: the sign of the swaps', 'times the shared squares; 0 at a null one']
    FX = json.loads(TXT('tests/fixtures/bitrule_reference.json'))
    S = Svg('kernel', 360, 384, 'The twelve lines of the kernel engines/bitrule.js and their Python twin bitrule_A.py')
    S.text(8, 18, 'engines/bitrule.js', size=12.5, weight='700', mono=True); S.text(352, 18, 'bitrule_A.py', size=12.5, weight='700', mono=True, anchor='end')
    for k, ((jn, ja, jb), (pn, pa, pb), w) in enumerate(zip(jsn, pyn, what)):
        y = 30 + 80 * k
        S.rect(4, y, 160, 46, 'cf-boxa', rx=5); S.rect(196, y, 160, 46, 'cf-box', rx=5)
        S.text(12, y + 19, jn, size=13, weight='700', mono=True); S.text(12, y + 37, 'lines %d–%d' % (ja, jb) if jb > ja else 'line %d' % ja, cls='cf-t2', size=12)
        S.text(204, y + 19, pn, size=13, weight='700', mono=True); S.text(204, y + 37, 'lines %d–%d' % (pa, pb) if pb > pa else 'line %d' % pa, cls='cf-t2', size=12)
        S.line(164, y + 23, 194, y + 23, 'cf-ln', arrow=True)
        S.text(40, y + 63, w, cls='cf-acc', size=12, italic=True)
        if k < 3: S.line(24, y + 46, 24, y + 78, 'cf-lna', arrow=True)
    yb = 30 + 80 * 4 + 4
    S.text(180, yb, '%d code lines; tests/kernel.test.mjs compares the two' % code_lines, size=12.5, anchor='middle', weight='600')
    S.text(180, yb + 18, 'on the fixture: %d cells, every pair of labels, %d products' % (len(FX['cells']), len(FX['products'])), cls='cf-t2', size=12, anchor='middle')
    SIZES[S.name] = S.save(); return code_lines, [(n, a, b) for n, a, b in jsn]

# ------------------------------------------------------------------------------------------------ 4. two laws and the controls of Part 2 (spring_selfcheck's bmul and MV)
def fig_controls():
    good = spring.bmul
    def run(bm):
        rng = random.Random(1); spring.bmul = bm
        def rand(sq): return spring.MV(sq, {a: rng.randint(-9, 9) for a in range(1 << len(sq))})
        def assoc(sq, trials=20): return all((x * y) * z == x * (y * z) for x, y, z in ((rand(sq), rand(sq), rand(sq)) for _ in range(trials)))
        def anti(sq):
            g = [spring.MV(sq, {1 << i: 1}) for i in range(len(sq))]
            return all(g[i] * g[j] == (g[j] * g[i]).scale(-1) for i in range(len(sq)) for j in range(len(sq)) if i != j)
        r = ([assoc(s) for s in SIGS], [anti(s) for s in SIGS]); spring.bmul = good; return r
    SIGS = [[1, 1], [-1, -1], [0, 0], [1, -1, -1, -1], [1, 1, -1, 0]]
    prods = [('the true product', good), ('no minus signs', lambda a, b, sq: (abs(good(a, b, sq)[0]), a ^ b)), ('OR for XOR', lambda a, b, sq: (good(a, b, sq)[0], a | b))]
    res = [(name, run(bm)) for name, bm in prods]
    S = Svg('controls', 360, 250, 'Associativity and anticommutation for the true product and two wrong ones, in five signatures')
    sig = ['++', '−−', '00', '+−−−', '++−0']
    S.text(8, 18, 'which law sees which wrong product', size=13, weight='600')
    S.text(8, 46, 'squares', cls='cf-mu', size=11)
    for j, t in enumerate(sig): S.text(140 + 44 * j, 46, t, cls='cf-t2', size=12, anchor='middle', mono=True)
    y = 58
    for name, (asc, ant) in res:
        S.text(8, y + 14, name, size=12.5, weight='600')
        for row, (lab, vals) in enumerate((('associative', asc), ('anticommute', ant))):
            yy = y + 22 + 22 * row
            S.text(16, yy + 14, lab, cls='cf-t2', size=12)
            for j, v in enumerate(vals):
                S.rect(124 + 44 * j, yy + 1, 32, 19, 'cf-ok' if v else 'cf-bad', rx=4, op=0.85)
                S.text(140 + 44 * j, yy + 15, 'yes' if v else 'no', cls='cf-w', size=11.5, anchor='middle', weight='700')
        y += 64
    SIZES[S.name] = S.save(); return res

# ------------------------------------------------------------------------------------------------ 5. the oscillator of Part 3: the exact series against the closed forms
def fig_oscillator():
    MV = spring.MV; N = 14
    def series(sq, x0, q0, w):
        u, v = MV(sq, {1: 1}), MV(sq, {2: 1}); B = u * v; terms = [u.scale(x0) + v.scale(q0)]
        for k in range(1, N + 1): terms.append((B * terms[-1]).scale(Fr(w, k)))
        return [t.get(1) for t in terms]
    cases = [([1, 1], 'B² = −1: 3 cos 2t + 5 sin 2t', lambda t: 3 * math.cos(2 * t) + 5 * math.sin(2 * t), 'cf-sacc'),
             ([1, -1], 'B² = +1: 3 cosh 2t − 5 sinh 2t', lambda t: 3 * math.cosh(2 * t) - 5 * math.sinh(2 * t), 'cf-sor'),
             ([0, 1], 'B² = 0: 3 + 10 t', lambda t: 3 + 10 * t, 'cf-sok')]
    S = Svg('oscillator', 360, 340, 'x(t) of the oscillator s prime = omega B s for the three squares of B: exact series and closed forms')
    X0, Y0, W, H, T = 44, 30, 300, 190, 1.5; lo, hi = -6, 13
    px = lambda t: X0 + W * t / T; py = lambda v: Y0 + H * (hi - v) / (hi - lo)
    S.rect(X0, Y0, W, H, 'cf-fr', rx=0)
    for v in (-5, 0, 5, 10): S.line(X0, py(v), X0 + W, py(v), 'cf-fr'); S.text(X0 - 6, py(v) + 4, str(v), cls='cf-mu', size=11, anchor='end')
    for t in (0, 0.5, 1, 1.5): S.text(px(t), Y0 + H + 16, fmt(float(t)), cls='cf-mu', size=11, anchor='middle')
    S.text(X0 + W / 2, Y0 + H + 32, 't', cls='cf-mu', size=12, anchor='middle', italic=True)
    dev = 0
    for k, (sq, lab, f, cls) in enumerate(cases):
        c = series(sq, 3, 5, 2); pts = []
        for i in range(61):
            t = T * i / 60; v = float(sum(ci * Fr(t).limit_denominator(10 ** 6) ** j for j, ci in enumerate(c)))
            if lo <= v <= hi: pts.append('%s,%s' % (fmt(px(t)), fmt(py(v))))
            if t <= 1: dev = max(dev, abs(v - f(t)) / max(1, abs(f(t))))
        S.path('M' + ' L'.join(pts), cls + ' cf-ln')
        for i in range(0, 61, 10):
            t = T * i / 60; v = f(t)
            if lo <= v <= hi: S.circle(px(t), py(v), 3, 'cf-fi')
        S.text(X0, Y0 + H + 52 + 16 * k, lab, size=12, cls={'cf-sacc': 'cf-acc', 'cf-sor': 'cf-or', 'cf-sok': 'cf-ok'}[cls], weight='600')
    S.text(X0, Y0 + H + 106, 'lines: the series to t^%d from the rule; dots: closed forms' % N, cls='cf-t2', size=11.5)
    SIZES[S.name] = S.save(); return [series(sq, 3, 5, 2)[:7] for sq, *_ in cases], dev

# ------------------------------------------------------------------------------------------------ 6. the anatomy of a check script (shifted_dirac.py)
def fig_check_anatomy():
    src = TXT('checks/selfcheck/proofs/shifted_dirac.py').split('\n')
    f = lambda pat, start=0: next(i + 1 for i in range(start, len(src)) if re.search(pat, src[i]))
    doc_end = f(r'^Run:|^       \(from the package root'); imp = f(r'^import os, sys'); hlp = f(r'^def chk\('); fin_def = f(r'^def finish\(')
    step = f(r"^STEP = "); fo = f(r"^def fault\(name\)"); first_head = f(r"^head\('"); last = len([l for l in src if l is not None]) - (1 if src[-1] == '' else 0)
    lastfin = max(i + 1 for i, l in enumerate(src) if l.startswith('finish(STEP)'))
    blocks = [
        ('1–4', 'the header', 'shebang, licence (SPDX), notice, terms', '#!/usr/bin/env python3'),
        ('5–%d' % doc_end, 'the docstring', 'statements (1)…(10) with their ids; [bit], [std], [ctl] and the --fault names; Scope; Run', src[19].strip()[:40]),
        ('%d–%d' % (imp, hlp - 2), 'imports by path', 'the engine from selfcheck/, found from __file__, never a copy', 'import coupling_selfcheck as cs'),
        ('%d–%d' % (hlp, fin_def + 3), 'chk, head, finish', 'one line per check; the count; the last line; exit 1 on a FAIL', "def chk(tag, cond, msg):"),
        ('%d–%d' % (step, fo), 'the step id and --fault', 'nine named wrong versions, each must end the run with FAILS', "FAULT_NAMES = ['NOI', 'SINSIGN', …]"),
        ('%d–%d' % (fo + 2, first_head - 1), 'the objects', 'class Alg: the labels as exact multivectors, J, the plane waves', 'class Alg:'),
        ('%d–%d' % (first_head, lastfin - 1), 'the parts', "head('(1) …'), then chk('bit' | 'std' | 'bit==std' | 'ctl', …)", "chk('bit==std', …)"),
        ('%d' % lastfin, 'finish(STEP)', 'prints checks: N ok, M FAIL and FAILS (SHIFTED-DIRAC): none', 'finish(STEP)')]
    S = Svg('check_anatomy', 360, 540, 'The anatomy of a check script: the regions of checks/selfcheck/proofs/shifted_dirac.py with their line numbers')
    S.text(8, 18, 'checks/selfcheck/proofs/shifted_dirac.py', size=12.5, weight='700', mono=True)
    S.text(8, 34, '%d lines, in eight regions' % last, cls='cf-mu', size=12)
    y = 44
    for k, (lines, name, what, code) in enumerate(blocks):
        h = 58
        S.rect(4, y, 352, h - 6, 'cf-boxa' if k in (3, 4, 6) else 'cf-box', rx=5)
        S.text(12, y + 18, name, size=13, weight='700'); S.text(348, y + 18, 'lines ' + lines, cls='cf-acc', size=12, anchor='end', weight='600')
        S.text(12, y + 34, cut(what, 56), cls='cf-t2', size=11.5)
        S.text(12, y + 47, cut(code, 50), cls='cf-mu', size=11, mono=True)
        y += h
    S.text(180, y + 16, 'framed: the discipline any new check copies', cls='cf-acc', size=12, anchor='middle', italic=True)
    SIZES[S.name] = S.save(); return blocks, last

# ------------------------------------------------------------------------------------------------ 7. the anatomy of a log (shifted_dirac.log)
def fig_log_anatomy():
    L = TXT('checks/selfcheck/proofs/logs/shifted_dirac.log').split('\n')
    head_ = next(l for l in L if l.startswith('(1)')); oks = [l for l in L if l.startswith('  ok   [')]
    pick = [head_] + [next(l for l in oks if '[%s]' % t in l) for t in ('bit', 'std', 'bit==std', 'ctl')]
    cnt = next(l for l in L if l.startswith('checks:')); lastl = [l for l in L if l.strip()][-1]
    tags = {t: sum(1 for l in oks if l.startswith('  ok   [%s]' % t)) for t in ('bit', 'std', 'bit==std', 'ctl')}
    nfail = sum(1 for l in L if l.startswith('  FAIL'))
    S = Svg('log_anatomy', 360, 440, 'The anatomy of a log: checks/selfcheck/proofs/logs/shifted_dirac.log')
    S.text(8, 18, 'checks/selfcheck/proofs/logs/shifted_dirac.log', size=12, weight='700', mono=True)
    notes = ['a heading: one part of the script, with its ids', '[bit]: computed on the labels, exact', '[std]: a route that never touches the labels',
             '[bit==std]: the two routes compared', '[ctl]: a wrong version, and the line is ok when it fails']
    y = 34
    for l, nt in zip(pick, notes):
        S.rect(4, y, 352, 52, 'cf-box', rx=5)
        S.text(10, y + 18, cut(l.strip(), 50), size=11.5, mono=True)
        S.text(10, y + 38, nt, cls='cf-acc', size=12, italic=True)
        y += 58
    S.text(10, y + 12, '…  %d check lines: %s' % (len(oks) + nfail, ', '.join('%d %s' % (v, k) for k, v in tags.items())), cls='cf-t2', size=12)
    y += 24
    S.rect(4, y, 352, 72, 'cf-boxa', rx=5)
    S.text(10, y + 20, cnt, size=12, mono=True); S.text(10, y + 40, lastl, size=12, mono=True, weight='700')
    S.text(10, y + 60, 'the last line: none, so the run exits 0', cls='cf-acc', size=12, italic=True)
    SIZES[S.name] = S.save(); return tags, nfail, cnt, lastl

# ------------------------------------------------------------------------------------------------ 8. the mutation table (checks/selfcheck/gravity/mut/*.mut.log)
def fig_mutation():
    D = os.path.join(CHECKS, 'selfcheck', 'gravity', 'mut'); rows = []
    for f in sorted(os.listdir(D)):
        if not f.endswith('.mut.log') or f.count('.') > 2: continue                 # the split runs (name.M1,M2.mut.log, name.only_M4.mut.log) are parts of a full table
        t = open(os.path.join(D, f), encoding='utf-8').read().split('\n'); i = next(k for k, l in enumerate(t) if l.startswith('TABLE'))
        cells = dict(re.findall(r'(M\d):(\S+)', t[i + 1])); base = re.search(r'baseline \(no fault\): (\d+) ok, (\d+) fail', '\n'.join(t))
        rows.append((f[:-8], [cells.get('M%d' % k, '?') for k in range(1, 9)], int(base.group(1)) if base else None))
    S = Svg('mutation', 360, 66 + 15 * len(rows) + 40, 'The mutation table: failing checks of each gravity script under the engine faults M1 to M8')
    S.text(8, 16, 'failing checks under each engine fault (0: not seen)', size=12.5, weight='600')
    X0, cw, rh, y0 = 148, 26, 15, 46
    for k in range(8): S.text(X0 + cw * k + cw / 2, y0 - 6, 'M%d' % (k + 1), size=11.5, anchor='middle', weight='700')
    seen = [0] * 8
    for r, (name, cells, base) in enumerate(rows):
        y = y0 + rh * r
        S.text(X0 - 6, y + 11.5, cut(name, 21), cls='cf-t2', size=10.5, anchor='end', mono=True)
        for k, v in enumerate(cells):
            n = int(re.sub(r'\D', '', v) or 0) if v != '?' else 0; e = v.startswith('E')
            if n or e:
                seen[k] += 1; op = 0.3 + 0.6 * min(1, math.log10(1 + n) / 2)
                S.rect(X0 + cw * k + 1, y + 1, cw - 2, rh - 2, 'cf-fa', rx=2, op=op)
                S.text(X0 + cw * k + cw / 2, y + 11, v, cls='cf-w' if op > 0.55 else 'cf-t', size=9.5, anchor='middle', weight='600')
            else:
                S.rect(X0 + cw * k + 1, y + 1, cw - 2, rh - 2, 'cf-fr', rx=2); S.text(X0 + cw * k + cw / 2, y + 11, '0', cls='cf-mu', size=9.5, anchor='middle')
    y = y0 + rh * len(rows) + 16
    S.text(X0 - 6, y, 'scripts that see it', cls='cf-t2', size=10.5, anchor='end')
    for k in range(8): S.text(X0 + cw * k + cw / 2, y, str(seen[k]), size=11, anchor='middle', weight='700')
    S.text(8, y + 20, '%d scripts; E: stopped on an exception (counts as seen)' % len(rows), cls='cf-mu', size=11)
    SIZES[S.name] = S.save(); return rows, seen

# ------------------------------------------------------------------------------------------------ 9. one check record, field by field (content/checks.json)
CHECKS_JSON = None
def fig_check_record():
    rec = next(r for r in CHECKS_JSON if r['script'] == 'checks/selfcheck/proofs/shifted_dirac.py')
    expl = {'id': 'the key: the script path under checks/', 'family': 'a group name for listings', 'script': 'the file that runs', 'what': 'what it checks, one line',
            'method': 'how: the engine route and the standard route', 'notes': 'the counts by tag, the faults', 'ids': 'the statement ids, each with its statement',
            'independentRoute': 'yes, and which: never the engine', 'controls': 'yes, and which wrong versions', 'deps': 'what it imports or needs',
            'storedResult': 'a stored file it compares with, or null', 'log': 'the shipped log', 'rowsNaming': 'the rows that cite it', 'since': 'the release that added it'}
    keys = [k for k in rec if k in expl]
    S = Svg('check_record', 360, 34 + 42 * len(keys) + 10, 'The check record of shifted_dirac.py in content/checks.json, field by field')
    S.text(8, 18, 'content/checks.json: the record of shifted_dirac.py', size=12.5, weight='700')
    y = 30
    for k in keys:
        v = rec[k]
        if k == 'ids': val = '%d ids: %s, %s, …' % (len(v), v[0]['id'], v[1]['id'])
        elif k == 'rowsNaming': val = '%d rows: %s … %s' % (len(v), v[0], v[-1])
        elif k == 'since': val = '(a release tag)'
        elif v is None: val = 'null'
        else: val = str(v)
        S.rect(4, y, 352, 38, 'cf-boxa' if k in ('id', 'ids', 'independentRoute', 'controls', 'log') else 'cf-box', rx=4)
        S.text(10, y + 15, k, size=12, weight='700', mono=True); S.text(352 - 6, y + 15, expl[k], cls='cf-acc', size=11, anchor='end', italic=True)
        S.text(10, y + 31, cut(val, 50), cls='cf-t2', size=11, mono=True)
        y += 42
    SIZES[S.name] = S.save(); return rec, keys

# ------------------------------------------------------------------------------------------------ 10. one run record (content/check_runs.json) and how the build reads it
RUNS = None
def fig_run_record():
    run = [r for r in RUNS if r['script'] == 'checks/selfcheck/proofs/shifted_dirac.py'][-1]
    expl = {'script': 'the script, as in checks.json', 'date': 'the day of the run', 'machine': 'who ran it, from which folder', 'passed': 'true: the exit code was 0',
            'status': 'how it ran (flags, folder, the faults)', 'seconds': 'wall time of the run', 'ok': 'the ok lines of the log', 'fail': 'the FAIL lines',
            'lastLine': 'the last line of the log', 'source': 'the log the counts come from', 'mode': 'plain, compare, mutation …'}
    keys = [k for k in expl if k in run]
    S = Svg('run_record', 360, 34 + 40 * len(keys) + 96, 'The run record of shifted_dirac.py in content/check_runs.json, and the rule that reads it')
    S.text(8, 18, 'content/check_runs.json: the run of shifted_dirac.py', size=12.5, weight='700')
    y = 30
    for k in keys:
        v = run[k]; val = '(a date)' if k == 'date' else '(who ran it), run from checks/' if k == 'machine' else json.dumps(v, ensure_ascii=False) if not isinstance(v, str) else v
        S.rect(4, y, 352, 36, 'cf-boxa' if k in ('passed', 'fail', 'lastLine') else 'cf-box', rx=4)
        S.text(10, y + 15, k, size=12, weight='700', mono=True); S.text(352 - 6, y + 15, expl[k], cls='cf-acc', size=11, anchor='end', italic=True)
        S.text(10, y + 30, cut(val, 50), cls='cf-t2', size=11, mono=True)
        y += 40
    y += 6
    S.rect(4, y, 352, 82, 'cf-box', rx=5)
    for i, l in enumerate(['lastRun[script] = the record with the latest date', 'runPassed(script) = a last run exists,', '  passed is not false, and fail is not > 0',
                           'tools/build_content.mjs, before the status']):
        S.text(12, y + 18 + 18 * i, l, size=11.5, mono=i < 3, cls='cf-t' if i < 3 else 'cf-mu', italic=i == 3)
    SIZES[S.name] = S.save(); return run

# ------------------------------------------------------------------------------------------------ 11. the status rule as a flow (tools/build_content.mjs), with the counts of the built status
def fig_status_flow(derived):
    from collections import Counter
    cnt = Counter(v['status'] for v in derived.values())
    first = [('kind story or meta; the notion i-meta alone; label note', 'meta'), ('the id starts with CAND- (a ran check that passed?)', 'proved / candidate'),
             ('the row has no legacy flags', 'see below')]
    flags = [('question, conjecture, pointer; ptype open; flag open without checked and standard', 'open'),
             ('flag checked, and a ran item whose script has a passing recorded run', 'proved-by-atlas'), ('flag checked, but no ran item, or every item read only', 'cited'),
             ('kind, ptype or label reading', 'ours'), ('group INP, or a null notion with input and not checked', 'input'), ('flag standard', 'standard'), ('flag ours', 'ours'), ('flag open', 'open'), ('nothing else', 'ours')]
    noflags = [('question, conjecture, pointer, or ptype open', 'open'), ('a ran item whose script has a passing run', 'proved-by-atlas'), ('a ran item without one, or every item read only', 'cited'),
               ('kind or ptype reading', 'ours'), ('group INP', 'input'), ('a notion of square −1 and a standard source read', 'standard'), ('nothing else', 'ours')]
    col = {'meta': 'cf-gr', 'open': 'cf-bad', 'proved-by-atlas': 'cf-ok', 'proved': 'cf-ok', 'cited': 'cf-or', 'ours': 'cf-or', 'input': 'cf-gr', 'standard': 'cf-fa', 'see': 'cf-acc'}
    rows_ = [('h', 'every row: first match wins, top to bottom')] + [('s', x) for x in first] + [('h', 'rows with legacy flags')] + [('s', x) for x in flags] + [('h', 'rows without flags')] + [('s', x) for x in noflags]
    H = sum(26 if k == 'h' else 38 for k, _ in rows_) + 64
    S = Svg('status_flow', 360, H, 'The status rule of tools/build_content.mjs as a flow, with the counts of the built status')
    y = 6
    for kind, x in rows_:
        if kind == 'h':
            S.text(6, y + 18, x, size=12.5, weight='700', cls='cf-acc'); y += 26; continue
        cond, out = x
        S.rect(4, y, 256, 33, 'cf-box', rx=5)
        ls = wrap(cond, 42)[:2]
        for i, l in enumerate(ls): S.text(10, y + (21 if len(ls) == 1 else 14 + 14 * i), l, size=11, cls='cf-t')
        word = out.split(' ')[0]
        S.rect(266, y + 6, 90, 21, col.get(word, 'cf-acc'), rx=10, op=0.9)
        S.text(311, y + 21, {'proved-by-atlas': 'proved', 'see': 'see below', 'proved': 'proved / cand.'}.get(word, word), cls='cf-w', size=10.5, anchor='middle', weight='700')
        y += 38
    S.text(6, y + 14, 'built status of the %d rows (proved = proved-by-atlas):' % len(derived), size=11.5, weight='600')
    items = sorted(cnt.items(), key=lambda kv: -kv[1]); half = (len(items) + 1) // 2
    for r_, part in enumerate((items[:half], items[half:])): S.text(6, y + 32 + 16 * r_, ', '.join('%s %d' % kv for kv in part), cls='cf-t2', size=11.5)
    SIZES[S.name] = S.save(); return cnt

# ------------------------------------------------------------------------------------------------ 12. the folders of the checks, with the counts of records and statement ids
def fig_folders():
    from collections import OrderedDict
    groups = OrderedDict()
    for r in CHECKS_JSON:
        p = r['script'] or ''
        d = os.path.dirname(p)
        if d.startswith('checks/selfcheck/bridges'): d = 'checks/selfcheck/bridges/'
        elif d.startswith('checks/reports'): d = 'checks/reports/'
        elif d.startswith('checks/') and d.count('/') >= 3: d = '/'.join(d.split('/')[:3])
        elif not d.startswith('checks'): d = d.split('/')[0] + '/' if d else '(none)'
        g = groups.setdefault(d, [0, 0]); g[0] += 1; g[1] += len(r.get('ids') or [])
    order = sorted(groups.items(), key=lambda kv: -kv[1][0])
    S = Svg('folders', 360, 50 + 34 * len(order) + 30, 'The folders of the check scripts with the number of check records and of statement ids in each')
    S.text(8, 18, 'content/checks.json: %d records, by folder' % len(CHECKS_JSON), size=12.5, weight='600')
    S.text(352, 18, 'records · ids', cls='cf-mu', size=11.5, anchor='end')
    mx = max(v[0] for _, v in order); y = 32
    for d, (nrec, nid) in order:
        name = d.replace('checks/', '') or d
        S.text(8, y + 13, cut(name, 30), size=11.5, mono=True)
        S.rect(8, y + 18, max(2, 260 * nrec / mx), 9, 'cf-fa', rx=2, op=0.85)
        S.text(352, y + 13, '%d · %d' % (nrec, nid), size=12, anchor='end', weight='600')
        y += 34
    S.text(8, y + 10, 'a record per script; its ids are the statements it decides', cls='cf-mu', size=11)
    SIZES[S.name] = S.save(); return order

# ------------------------------------------------------------------------------------------------ 13. from a row to its status: ATY-004
def fig_evidence(rows, derived):
    row = next(r for r in rows if r['id'] == 'ATY-004'); rec = next(r for r in CHECKS_JSON if r['script'] == row['evidence'][0]['script'])
    run = [r for r in RUNS if r['script'] == rec['script']][-1]; st = derived[row['id']]['status']
    S = Svg('evidence_path', 360, 420, 'From the row ATY-004 to its status: evidence, check record, run record, the rule')
    boxes = [('content/rows.json · ATY-004', ['kind %s · flags %s' % (row['kind'], ', '.join(row['legacyFlags'])), 'evidence: %d items, mode %s' % (len(row['evidence']), '/'.join(sorted({e['mode'] for e in row['evidence']})))]),
             ('evidence[0]', ['check  %s' % row['evidence'][0]['check'], 'script %s' % row['evidence'][0]['script'].replace('checks/selfcheck/', '…/')]),
             ('content/checks.json · the record', ['%d ids, among them %s' % (len(rec['ids']), ', '.join(i['id'] for i in rec['ids'][:3])), 'log %s' % rec['log'].replace('checks/selfcheck/', '…/')]),
             ('content/check_runs.json · the last run', ['passed %s · ok %d · fail %d' % (json.dumps(run['passed']), run['ok'], run['fail']), 'lastLine %s' % run['lastLine']]),
             ('tools/build_content.mjs · the rule', ['flag checked + a ran item + its run passed', '→ status %s' % st])]
    y = 8
    for k, (t, ls) in enumerate(boxes):
        S.rect(4, y, 352, 66, 'cf-boxa' if k in (0, 4) else 'cf-box', rx=6)
        S.text(12, y + 19, t, size=12.5, weight='700')
        for i, l in enumerate(ls): S.text(12, y + 38 + 17 * i, cut(l, 52), cls='cf-t2', size=11.5, mono=True)
        if k < len(boxes) - 1: S.line(180, y + 66, 180, y + 82, 'cf-lna', arrow=True)
        y += 84
    SIZES[S.name] = S.save(); return row, rec, run, st

# ------------------------------------------------------------------------------------------------ 14. the pipeline: content → build → tests → release
def fig_pipeline(rows, derived):
    pkg = J('package.json'); data_tests = [t for t in re.findall(r'node (tests/[\w./-]+\.test\.mjs)', pkg['scripts']['test:data'])]
    ui_tests = re.findall(r'node (tests/[\w./-]+\.test\.mjs)', pkg['scripts']['test:ui'])
    stages = [('content/', ['rows.json %d rows · texts.json' % len(rows), 'checks.json %d records · check_runs.json %d runs' % (len(CHECKS_JSON), len(RUNS))]),
              ('npm run content → tools/build_content.mjs', ['validates the tables; computes the status', '→ content/derived/status.json, docs/COVERAGE.md']),
              ('sh build.sh → dist/', ['the site, the content tables, the reports', 'tools/export_tuning.mjs → dist/content/tuning/']),
              ('npm test', ['test:data: %d suites (kernel, engines, …)' % len(data_tests), 'test:ui: %d suites in a browser' % len(ui_tests)]),
              ('sh tools/release.sh', ['content, counts, build, notes, every suite', '→ the zip of the release, its sha256'])]
    S = Svg('pipeline', 360, 8 + 84 * len(stages), 'The pipeline of the package: content, build, tests, release')
    y = 8
    for k, (t, ls) in enumerate(stages):
        S.rect(4, y, 352, 66, 'cf-boxa' if k in (1, 3) else 'cf-box', rx=6)
        S.text(12, y + 19, t, size=12.5, weight='700', mono=True)
        for i, l in enumerate(ls): S.text(12, y + 38 + 17 * i, cut(l, 54), cls='cf-t2', size=11.5)
        if k < len(stages) - 1: S.line(180, y + 66, 180, y + 82, 'cf-lna', arrow=True)
        y += 84
    SIZES[S.name] = S.save(); return data_tests, ui_tests

# ------------------------------------------------------------------------------------------------ 15. the template's skeleton (scripts/template_check.py) and the checklist
def fig_template():
    src = open(os.path.join(SRC, 'scripts', 'template_check.py'), encoding='utf-8').read().split('\n')
    nlines = len(src) - (1 if src[-1] == '' else 0)
    marks = [(i + 1, re.sub(r'^# -+ ', '', l)) for i, l in enumerate(src) if re.match(r'^# -{10,} \d\.', l)]
    doc_end = next(i + 1 for i, l in enumerate(src) if l.rstrip().endswith('"""') and i > 4)
    regions = [('1–4', 'the header', 'the licence lines of the package'), ('5–%d' % doc_end, 'the docstring', 'statement · [bit] · [std] · [ctl] · Scope · Run')]
    extra = {'3.': "head, then [bit], [std], [bit==std], [ctl] lines", '4.': 'finish(STEP): the count, the last line, the exit code'}
    for k, (ln, t) in enumerate(marks):
        end = marks[k + 1][0] - 1 if k + 1 < len(marks) else nlines
        num, rest = t.split(' ', 1); title, _, more = rest.partition(':') if ':' in rest else rest.partition(',')
        regions.append(('%d–%d' % (ln, end), num + ' ' + title.strip(), more.strip() or extra.get(num, '')))
    check = ['BEFORE: the statement, the wording on pass and on fail', 'two routes: [bit] exact, [std] never the engine', 'controls: a [ctl] line, a --fault per wrong version',
             'the log: the last line FAILS (STEP): none', 'the record: checks.json and check_runs.json', 'the words: present tense, the scope that ran']
    S = Svg('template', 360, 40 + 50 * len(regions) + 30 + 20 * len(check), 'The skeleton of scripts/template_check.py and the checklist before shipping')
    S.text(8, 18, 'scripts/template_check.py', size=12.5, weight='700', mono=True); S.text(352, 18, '%d lines' % nlines, cls='cf-mu', size=12, anchor='end')
    y = 28
    for ln, name, what in regions:
        S.rect(4, y, 352, 44, 'cf-boxa' if name[:2] in ('1.', '2.', '3.') else 'cf-box', rx=5)
        S.text(12, y + 18, cut(name, 36), size=12.5, weight='700'); S.text(348, y + 18, 'lines ' + ln, cls='cf-acc', size=11.5, anchor='end', weight='600')
        S.text(12, y + 36, cut(what, 56), cls='cf-t2', size=11.5)
        y += 50
    y += 12; S.text(8, y, 'the checklist before shipping', size=12.5, weight='700'); y += 6
    for i, c in enumerate(check):
        S.rect(8, y + 6 + 20 * i, 11, 11, 'cf-fr', rx=2); S.text(26, y + 16 + 20 * i, c, size=11.5, cls='cf-t2')
    SIZES[S.name] = S.save(); return regions

# ------------------------------------------------------------------------------------------------ 16. Maxwell: the kernel of F0 -> khat F0 on a grid of (omega, |k|)
def fig_maxwell():
    def ker(eps, k):
        A = BR(eps); kh = {1 << mu: k[mu] for mu in range(4) if k[mu]}; B = [m for m in range(16) if popcount(m) == 2]
        return 6 - rank_fr([A.mul(kh, {b: 1}) for b in B], 16)
    G = 6; cells = {}
    for name, eps in (('Cl(1,3)', [1, -1, -1, -1]), ('Cl(4,0)', [1, 1, 1, 1])):
        cells[name] = [[ker(eps, (w, kx, 0, 0)) for kx in range(G + 1)] for w in range(G + 1)]
    S = Svg('maxwell_kernel', 360, 250, 'Plane waves on the labels: the dimension of the kernel of F0 to khat F0 for omega and k from 0 to 6')
    c = 19
    for j, (name, grid) in enumerate(cells.items()):
        x0, y0 = 30 + 175 * j, 40
        S.text(x0 + c * (G + 1) / 2, 18, name, size=13, anchor='middle', weight='700')
        for w in range(G + 1):
            for kx in range(G + 1):
                v = grid[w][kx]; x, y = x0 + c * kx, y0 + c * (G - w)
                S.rect(x + 1, y + 1, c - 2, c - 2, 'cf-fa' if v == 2 else 'cf-gr' if v == 6 else 'cf-fr', rx=2, op=0.85 if v == 2 else 0.4 if v == 6 else None)
                S.text(x + c / 2, y + 13.5, str(v), cls='cf-w' if v == 2 else 'cf-t2', size=10, anchor='middle', weight='600')
        S.text(x0 + c * (G + 1) / 2, y0 + c * (G + 1) + 16, 'k (along x) →', cls='cf-mu', size=11, anchor='middle')
        S.text(x0 - 6, y0 + 10, 'ω', cls='cf-mu', size=12, anchor='end', italic=True)
    S.text(180, 222, 'kernel 2 exactly on ω = |k|: the light cone of Cl(1,3);', cls='cf-t2', size=11.5, anchor='middle')
    S.text(180, 238, 'none off the origin in Cl(4,0) (6 at k = 0, ω = 0)', cls='cf-t2', size=11.5, anchor='middle')
    SIZES[S.name] = S.save(); return cells

# ------------------------------------------------------------------------------------------------ 17. the clock: the type at p - q mod 8 from the bit rule's invariants
def fig_clock():
    def inv(p, q):
        A = BR([1] * p + [-1] * q); n = p + q; D = 1 << n
        z = sum(all(A.s(a, 1 << i) == A.s(1 << i, a) for i in range(n)) for a in range(D)); d = sum(A.s(a, a) for a in range(D))
        return ('R' if d > 0 else 'H') if z == 1 else ('C' if d == 0 else 'R2' if d > 0 else 'H2')
    per = {k: {} for k in range(8)}
    for n in range(9):
        for q in range(n + 1):
            p = n - q; t = inv(p, q); per[(p - q) % 8][t] = per[(p - q) % 8].get(t, 0) + 1
    name = {'R': 'ℝ', 'R2': 'ℝ⊕ℝ', 'C': 'ℂ', 'H': 'ℍ', 'H2': 'ℍ⊕ℍ'}
    S = Svg('clock', 360, 330, 'The clock p - q mod 8 and the type of Cl(p,q) computed from the centre and the squares, 45 cells')
    cx, cy, R = 180, 168, 112
    S.circle(cx, cy, R, 'cf-fr')
    for k in range(8):
        ang = math.pi / 2 - 2 * math.pi * k / 8; x, y = cx + R * math.cos(ang), cy - R * math.sin(ang)
        (t, n), = per[k].items()
        S.circle(x, y, 27, 'cf-boxa')
        S.text(x, y + 2, name[t], size=14, anchor='middle', weight='700'); S.text(x, y + 17, '%d cells' % n, cls='cf-mu', size=9.5, anchor='middle')
        xl, yl = cx + (R - 50) * math.cos(ang), cy - (R - 50) * math.sin(ang)
        S.text(xl, yl + 5, str(k), cls='cf-acc', size=14, anchor='middle', weight='700')
    S.text(cx, cy - 4, 'p − q mod 8', size=12.5, anchor='middle', weight='600'); S.text(cx, cy + 14, 'one type per hour', cls='cf-t2', size=11.5, anchor='middle')
    S.text(180, 318, 'the type of the matrix algebra, from the centre and the squares only', cls='cf-mu', size=11, anchor='middle')
    SIZES[S.name] = S.save(); return per

# ------------------------------------------------------------------------------------------------ 18. a vector times a bivector splits by grade (Cl(1,3))
def fig_grade_split():
    A = BR([1, -1, -1, -1]); B = [m for m in range(16) if popcount(m) == 2]
    S = Svg('grade_split', 360, 212, 'The products of the four vectors and the six bivectors of Cl(1,3), coloured by grade')
    sub0 = lambda m: cblade(m, base=0)
    cw, rh, x0, y0 = 51, 30, 50, 44
    S.text(8, 18, 'e_μ · e_B in Cl(1,3), e₀ time: grade 1 (blue) or 3', size=12.5, weight='600')
    for j, b in enumerate(B): S.text(x0 + cw * j + cw / 2, y0 - 6, sub0(b), size=11.5, anchor='middle', weight='700')
    n1 = n3 = 0
    for i in range(4):
        S.text(x0 - 8, y0 + rh * i + 19, 'e' + SUB[i], size=12.5, anchor='end', weight='700')
        for j, b in enumerate(B):
            s = A.s(1 << i, b); m = (1 << i) ^ b; g = popcount(m); n1 += g == 1; n3 += g == 3
            S.rect(x0 + cw * j + 1, y0 + rh * i + 1, cw - 2, rh - 2, 'cf-fa' if g == 1 else 'cf-box', rx=3, op=0.85 if g == 1 else None)
            S.text(x0 + cw * j + cw / 2, y0 + rh * i + 19, ('+' if s > 0 else '−') + sub0(m), cls='cf-w' if g == 1 else 'cf-t', size=10.5, anchor='middle', mono=True)
    S.text(8, y0 + rh * 4 + 20, '%d products of grade 1, %d of grade 3: ∇F = J splits into' % (n1, n3), cls='cf-t2', size=11.5)
    S.text(8, y0 + rh * 4 + 36, 'the vector equation and the trivector equation', cls='cf-t2', size=11.5)
    SIZES[S.name] = S.save(); return n1, n3

# ------------------------------------------------------------------------------------------------ run them all, print what the text quotes
if __name__ == '__main__':
    CHECKS_JSON = J('content/checks.json'); RUNS = J('content/check_runs.json'); rows = J('content/rows.json'); derived = J('content/derived/status.json')
    print('n2 counts (title, zero, minus):', fig_n2())
    print('swaps (N, sign, label):', fig_swaps())
    print('kernel (code lines, spans):', fig_kernel())
    print('controls:', fig_controls())
    co, dev = fig_oscillator(); print('oscillator coefficients t^0..t^6:', [[str(x) for x in c] for c in co], 'max relative deviation of the order-14 series on [0,1]: %.1e' % dev)
    b, last = fig_check_anatomy(); print('check anatomy: %d lines, regions %s' % (last, [x[0] for x in b]))
    print('log anatomy (tags, FAIL lines, count line, last line):', fig_log_anatomy())
    rows_m, seen = fig_mutation(); print('mutation: %d scripts, seen per fault %s, silent rows %s' % (len(rows_m), seen, [r[0] for r in rows_m if all(c == '0' for c in r[1])]))
    rec, keys = fig_check_record(); print('check record keys:', keys)
    run = fig_run_record(); print('run record:', {k: run[k] for k in ('passed', 'ok', 'fail', 'lastLine', 'seconds')})
    print('status counts:', dict(fig_status_flow(derived)))
    print('folders:', fig_folders())
    r, rc, rn, st = fig_evidence(rows, derived); print('evidence path ATY-004 ->', st)
    dt, ut = fig_pipeline(rows, derived); print('pipeline: %d data suites, %d ui suites' % (len(dt), len(ut)))
    print('template regions:', fig_template())
    mk = fig_maxwell(); print('maxwell grid diagonal Cl(1,3):', [mk['Cl(1,3)'][w][w] for w in range(7)], 'Cl(4,0) off origin max:', max(v for w, row in enumerate(mk['Cl(4,0)']) for k, v in enumerate(row) if (w, k) != (0, 0)))
    print('clock:', fig_clock())
    print('grade split (grade 1, grade 3):', fig_grade_split())
    big = {k: v for k, v in SIZES.items() if v >= 80000}
    print('figures: %d, largest %d bytes%s' % (len(SIZES), max(SIZES.values()), ', over 80 kB: %s' % big if big else ''))
