#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""figs_phys.py -- every figure of the tutorial "Physics on the bit rule: the four engines", drawn from the Atlas's own objects.

Run:   python3 -I -B figs_phys.py          writes figs/*.svg beside this file and prints one line per figure
       ATLAS_REPO=<package root> python3 -I -B figs_phys.py    when the package is not found by the search below
The package is found by walking up from this file's folder (a folder holding checks/selfcheck/steps15_17/bitcliff.py, or a v3/one-rule below
one). The bit rule is imported from checks/selfcheck/steps15_17/bitcliff.py; the products and tables of coupling_selfcheck.py, maxwell_selfcheck.py
and yangmills_selfcheck.py are imported and used as they stand (nothing of theirs is copied); the numbers the checks print are parsed from the
shipped logs under checks/. A number in a figure is computed here from the labels or parsed from a log; where it is both, the two are compared
(an assert), so a figure cannot drift from the log it cites. The SVGs carry their text as text, use the page's colour tokens (light and dark),
and are deterministic: no clock, no unseeded random number, the same bytes on every run."""
import os, sys, re, ast, math, random, itertools, importlib.util
from fractions import Fraction as Fr
from math import comb
sys.dont_write_bytecode = True

HERE = os.path.dirname(os.path.abspath(__file__))

def find_repo():
    env = os.environ.get('ATLAS_REPO'); cands = [env] if env else []; d = HERE
    for _ in range(9):
        cands += [d]; d = os.path.dirname(d)
    for c in cands:
        if c and os.path.isfile(os.path.join(c, 'checks', 'selfcheck', 'steps15_17', 'bitcliff.py')): return c
    raise SystemExit('figs_phys.py: the package (checks/selfcheck/steps15_17/bitcliff.py) is not found; set ATLAS_REPO')
REPO = find_repo(); CHK = os.path.join(REPO, 'checks')
OUT = os.path.join(REPO, 'public', 'reports', 'tutorials', 'src', 'phys', 'figs')   # the figures, beside the tutorial's source
def load(name, rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(CHK, rel)); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
bc = load('bitcliff', 'selfcheck/steps15_17/bitcliff.py')            # the bit rule: Alg(eps).blade_mul, reorder_sign, sig
cs = load('coupling_selfcheck', 'selfcheck/coupling_selfcheck.py')     # bmul, sqs, current_structure, ladder_row
mx = load('maxwell_selfcheck', 'selfcheck/maxwell_selfcheck.py')       # bprod, phys_spec, build_cell, symbol
ym = load('yangmills_selfcheck', 'selfcheck/yangmills_selfcheck.py')   # algebra(m): the structure constants of so(m) from the bit product
LOGS = {}
def log(rel):
    if rel not in LOGS: LOGS[rel] = open(os.path.join(CHK, rel), encoding='utf8').read()
    return LOGS[rel]
def need(pat, rel, flags=0):
    m = re.search(pat, log(rel), flags)
    assert m, 'not in %s: %s' % (rel, pat)
    return m
def ints(s): return [int(x) for x in re.findall(r'-?\d+', s)]

# ------------------------------------------------------------------------------------------------ SVG, with the page's tokens
STYLE = ('<style>svg.pf{--pf-c1:#2a78d6;--pf-c2:#eb6834;--pf-c3:#1baf7a;--pf-c4:#6250d6;--pf-c5:#e34948;'
         'font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}'
         '@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) svg.pf{--pf-c1:#3987e5;--pf-c2:#d95926;--pf-c3:#199e70;--pf-c4:#9085e9;--pf-c5:#e66767}}'
         ':root[data-theme="dark"] svg.pf{--pf-c1:#3987e5;--pf-c2:#d95926;--pf-c3:#199e70;--pf-c4:#9085e9;--pf-c5:#e66767}'
         'svg.pf .t{fill:var(--ink,#1a1a19);font-size:13px}svg.pf .t2{fill:var(--ink2,#46463f);font-size:12px}'
         'svg.pf .tm{fill:var(--muted,#6b6b64);font-size:11px}svg.pf .th{fill:var(--ink,#1a1a19);font-size:14px;font-weight:600}'
         'svg.pf .tb{fill:var(--ink,#1a1a19);font-size:13px;font-weight:600}svg.pf .mono{font-family:ui-monospace,Menlo,Consolas,monospace}'
         'svg.pf .ax{stroke:var(--line2,#c9c8c0);stroke-width:1;fill:none}svg.pf .gr{stroke:var(--line,#e3e2dc);stroke-width:1;fill:none}'
         'svg.pf .bx{fill:var(--tint,#f3f2ee);stroke:var(--line,#e3e2dc)}svg.pf .bg{fill:var(--surf,#fff)}'
         'svg.pf .s1{fill:var(--pf-c1)}svg.pf .s2{fill:var(--pf-c2)}svg.pf .s3{fill:var(--pf-c3)}svg.pf .s4{fill:var(--pf-c4)}svg.pf .s5{fill:var(--pf-c5)}'
         'svg.pf .l1{stroke:var(--pf-c1);stroke-width:2;fill:none}svg.pf .l2{stroke:var(--pf-c2);stroke-width:2;fill:none}'
         'svg.pf .l3{stroke:var(--pf-c3);stroke-width:2;fill:none}svg.pf .l4{stroke:var(--pf-c4);stroke-width:2;fill:none}'
         'svg.pf .ld{stroke:var(--muted,#6b6b64);stroke-width:1.2;fill:none;stroke-dasharray:4 3}svg.pf .lk{stroke:var(--ink2,#46463f);stroke-width:1.4;fill:none}'
         'svg.pf .p1{fill:var(--pf-c1);fill-opacity:.2}svg.pf .p2{fill:var(--pf-c2);fill-opacity:.22}svg.pf .p3{fill:var(--pf-c3);fill-opacity:.22}'
         'svg.pf .p4{fill:var(--pf-c4);fill-opacity:.2}svg.pf .z{fill:var(--tint,#f3f2ee)}svg.pf .ring{stroke:var(--surf,#fff);stroke-width:2}'
         'svg.pf .hol{fill:var(--surf,#fff);stroke:var(--muted,#6b6b64);stroke-width:1.2}</style>')
def esc(s): return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
def nm(v):
    if isinstance(v, Fr): v = float(v)
    if isinstance(v, float):
        s = ('%.1f' % v); s = s[:-2] if s.endswith('.0') else s
        return '0' if s == '-0' else s
    return str(v)
MINUS = '−'
def fs(q): return str(q).replace('-', MINUS)
SUBS = str.maketrans('0123456789', '₀₁₂₃₄₅₆₇₈₉')
def sub(s): return str(s).translate(SUBS)
def gname(m, letter='γ', base=0):
    idx = [i for i in range(12) if m >> i & 1]
    return letter + sub(''.join(str(i + base) for i in idx)) if idx else '1'
def bits(m, n): return ''.join(str(m >> (n - 1 - i) & 1) for i in range(n))

class Fig:
    def __init__(s, name, w, h, label, scale=1.3):
        s.name, s.w, s.h, s.label, s.el, s.scale, s.ymax = name, w, h, label, [], scale, 0
    def add(s, x): s.el.append(x)
    def tip(s, t): return '<title>%s</title>' % esc(t) if t else ''
    def text(s, x, y, t, c='t', a='start', tip=None, extra=''):
        an = '' if a == 'start' else ' text-anchor="%s"' % a; s.ymax = max(s.ymax, y + 5)
        s.add('<text x="%s" y="%s" class="%s"%s%s>%s%s</text>' % (nm(x), nm(y), c, an, extra, s.tip(tip), esc(t)))
    def para(s, x, y, t, c='t2', maxch=None, lh=None):
        k = c.split()[0]; maxch = maxch or {'t2': 58, 'tm': 64, 't': 54, 'th': 46, 'tb': 50}.get(k, 58); lh = lh or {'tm': 14, 'th': 18}.get(k, 16)
        out, line = [], ''
        for w in t.split(' '):
            if line and len(line) + 1 + len(w) > maxch: out.append(line); line = w
            else: line = (line + ' ' + w) if line else w
        if line: out.append(line)
        for i, l in enumerate(out): s.text(x, y + lh * i, l, c)
        return y + lh * len(out)
    def line(s, x1, y1, x2, y2, c='ax', tip=None):
        s.add('<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s">%s</line>' % (nm(x1), nm(y1), nm(x2), nm(y2), c, s.tip(tip)) if tip else
              '<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s"/>' % (nm(x1), nm(y1), nm(x2), nm(y2), c))
    def rect(s, x, y, w, h, c, rx=0, tip=None):
        r = ' rx="%s"' % nm(rx) if rx else ''
        body = '<rect x="%s" y="%s" width="%s" height="%s" class="%s"%s' % (nm(x), nm(y), nm(w), nm(h), c, r)
        s.add(body + ('>%s</rect>' % s.tip(tip) if tip else '/>'))
    def circ(s, x, y, r, c, tip=None):
        body = '<circle cx="%s" cy="%s" r="%s" class="%s"' % (nm(x), nm(y), nm(r), c)
        s.add(body + ('>%s</circle>' % s.tip(tip) if tip else '/>'))
    def path(s, d, c, tip=None):
        s.add('<path d="%s" class="%s"%s' % (d, c, ('>%s</path>' % s.tip(tip)) if tip else '/>'))
    def poly(s, pts, c, close=False, tip=None):
        d = 'M' + ' L'.join('%s,%s' % (nm(x), nm(y)) for x, y in pts) + (' Z' if close else '')
        s.path(d, c, tip)
    def arrow(s, x1, y1, x2, y2, c='lk', head=6):
        s.line(x1, y1, x2, y2, c); a = math.atan2(y2 - y1, x2 - x1)
        p = [(x2, y2), (x2 - head * math.cos(a - .4), y2 - head * math.sin(a - .4)), (x2 - head * math.cos(a + .4), y2 - head * math.sin(a + .4))]
        s.poly(p, 's0' if False else 'lk', close=True)
    def save(s):
        s.h = max(s.h, int(math.ceil(s.ymax + 6))); W = int(round(s.w * s.scale)); H = int(round(s.h * s.scale))
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" class="pf" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s">'
               % (s.w, s.h, W, H, esc(s.label)) + STYLE + ''.join(s.el) + '</svg>\n')
        os.makedirs(OUT, exist_ok=True)
        with open(os.path.join(OUT, s.name), 'w', encoding='utf8', newline='\n') as f: f.write(svg)
        n = len(svg.encode('utf8')); assert n < 80000, (s.name, n)
        print('  %-26s %6d bytes  %s' % (s.name, n, s.label[:90]))

def axes(F, x0, y0, w, h, xr, yr, xt, yt, xl='', yl='', fx=None, fy=None):
    (xa, xb), (ya, yb) = xr, yr
    X = lambda v: x0 + (float(v) - xa) / (xb - xa) * w
    Y = lambda v: y0 + h - (float(v) - ya) / (yb - ya) * h
    for v in yt:
        F.line(x0, Y(v), x0 + w, Y(v), 'gr'); F.text(x0 - 5, Y(v) + 4, (fy or fs)(v), 'tm', 'end')
    for v in xt:
        F.line(X(v), y0 + h, X(v), y0 + h + 4, 'ax'); F.text(X(v), y0 + h + 16, (fx or fs)(v), 'tm', 'middle')
    F.line(x0, y0 + h, x0 + w, y0 + h, 'ax'); F.line(x0, y0, x0, y0 + h, 'ax')
    if xl: F.text(x0 + w / 2, y0 + h + 31, xl, 't2', 'middle')
    if yl: F.text(x0, y0 - 8, yl, 't2')
    return X, Y
def curve(F, X, Y, f, a, b, c, n=160, ylim=None):
    segs, seg = [], []
    for i in range(n + 1):
        x = a + (b - a) * i / n; y = f(x)
        if ylim and not ylim[0] <= y <= ylim[1]:
            if len(seg) > 1: segs.append(seg)
            seg = []; continue
        seg.append((X(x), Y(y)))
    if len(seg) > 1: segs.append(seg)
    for sg in segs: F.poly(sg, c)
def legend(F, x, y, items):
    for i, (cls, t) in enumerate(items):
        F.line(x, y + 16 * i - 4, x + 18, y + 16 * i - 4, cls); F.text(x + 24, y + 16 * i, t, 't2')

FIGS = []
def figure(fn): FIGS.append(fn); return fn

# ------------------------------------------------------------------------------------------------ exact helpers on labels
def mv_mul(x, y, sq, mulf=None):
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            m, s = (mulf or cs.bmul)(a, b, sq)
            if s: out[m] = out.get(m, 0) + s * ca * cb
    return {k: v for k, v in out.items() if v}
def mv_lin(*terms):
    out = {}
    for c, a in terms:
        for m, v in a.items(): out[m] = out.get(m, 0) + Fr(c) * v
    return {k: v for k, v in out.items() if v}
def rank(cols):
    keys = sorted({m for c in cols for m in c}); M = [[Fr(c.get(r, 0)) for c in cols] for r in keys]; rk = 0; piv = []
    for j in range(len(cols)):
        p = next((i for i in range(rk, len(M)) if M[i][j] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][j]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][j] != 0:
                f = M[i][j]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(j); rk += 1
    return rk, piv, M
def kernel(basis, L):
    cols = [L({b: Fr(1)}) for b in basis]; rk, piv, M = rank(cols); out = []
    for f in [j for j in range(len(cols)) if j not in piv]:
        x = [Fr(0)] * len(cols); x[f] = Fr(1)
        for r, j in enumerate(piv): x[j] = -M[r][f]
        out.append({basis[j]: x[j] for j in range(len(cols)) if x[j] != 0})
    return out

# ================================================================================================ the opening: the cell row 2
@figure
def fig_n2():
    F = Fig('n2_three_algebras.svg', 400, 392, 'The three sign tables of the cell row 2, computed by the bit rule')
    names = ['1', 'e₁', 'e₂', 'e₁₂']
    cases = [((1, 1), '(+,+)', 'Cl(2,0) ≅ M₂(ℝ)'), ((-1, -1), '(−,−)', 'Cl(0,2) ≅ ℍ'), ((0, 0), '(0,0)', 'Cl(0,0,2) = Λℝ²')]
    pos = [(8, 6), (206, 6), (8, 200)]; counts = []
    for (eps, title, alg), (ox, oy) in zip(cases, pos):
        A = bc.Alg(eps); cw, ch, hx = 40, 25, 30; zero = minus = 0
        F.text(ox, oy + 14, 'squares ' + title, 'th'); F.text(ox, oy + 30, alg, 't2')
        y0 = oy + 40
        for j, b in enumerate(range(4)): F.text(ox + hx + cw * j + cw / 2, y0 + 16, names[b], 'tb', 'middle')
        for i, a in enumerate(range(4)):
            yy = y0 + ch * (i + 1); F.text(ox + hx - 6, yy + 17, names[a], 'tb', 'end')
            for j, b in enumerate(range(4)):
                s, c = A.blade_mul(a, b); zero += s == 0; minus += s < 0
                cls = 'z' if s == 0 else ('p1' if s > 0 else 'p2')
                F.rect(ox + hx + cw * j + 1, yy + 1, cw - 2, ch - 2, cls, 3, tip='%s · %s = %s' % (names[a], names[b], '0' if s == 0 else ('+' if s > 0 else MINUS) + names[c]))
                F.text(ox + hx + cw * j + cw / 2, yy + 17, '0' if s == 0 else ('+' if s > 0 else MINUS) + names[c], 't', 'middle')
        F.text(ox, y0 + ch * 5 + 18, '%d products zero, %d with a minus' % (zero, minus), 't2')
        counts.append((zero, minus))
    assert counts == [(0, 4), (0, 6), (7, 1)], counts            # the counts that Part 0 of the shipped tutorial states
    F.para(214, 262, 'row a, column b: eₐ e_b is the sign s(a,b) times the blade of the label a ⊕ b (XOR). Blue +, orange −, grey 0. One rule, three algebras: only the squares εᵢ change.', 't2', maxch=29)
    F.save()

# ================================================================================================ part 0: the frame
@figure
def fig_cl13():
    A = bc.Alg(bc.sig(1, 3)); n = 4
    F = Fig('cl13_labels.svg', 400, 300, 'The sixteen labels of Cl(1,3) by grade, with the square of each blade')
    cols = [[m for m in range(16) if bc.pc(m) == g] for g in range(5)]; cw = 78
    for g, col in enumerate(cols):
        x = 6 + cw * g; F.text(x + cw / 2 - 4, 18, 'grade %d · %d' % (g, len(col)), 'tb', 'middle')
        for i, m in enumerate(col):
            y = 30 + 40 * i + (40 * (6 - len(col)) / 2); sq = A.sq(m)
            F.rect(x, y, cw - 8, 34, 'p1' if sq > 0 else 'p2', 4, tip='%s (bits %s) squares to %s' % (gname(m), bits(m, n), '+1' if sq > 0 else MINUS + '1'))
            F.text(x + 6, y + 15, gname(m), 'tb'); F.text(x + cw - 14, y + 15, '+1' if sq > 0 else MINUS + '1', 't', 'end')
            F.text(x + 6, y + 29, bits(m, n), 'tm mono')
    p, q, r = A.counts(); assert (p, q, r) == (6, 10, 0)
    F.para(6, 282, 'Bit 0 is γ₀ (time, square +1), bits 1 to 3 are γ₁ γ₂ γ₃ (space, square −1). Blue: square +1 (%d labels, the boosts γ₀ᵢ among them); orange: square −1 (%d labels).' % (p, q), 't2')
    F.save()

@figure
def fig_wave_types():
    T18 = 'selfcheck/proofs/logs/check_T18.log'
    need(r'F: a hyperbolic direction exists only for signatures \(1, n-1\) and \(n-1, 1\)', T18)
    held = need(r'check_T18: (\d+) of (\d+) assertions hold', T18)
    F = Fig('wave_types.svg', 400, 396, 'The wave operator of every cell Cl(p,q) with p + q from 1 to 8: elliptic, hyperbolic or ultrahyperbolic')
    cw = 36; x0, y0 = 52, 40
    F.text(x0 + cw * 4.5, 16, 'p = number of generators of square +1', 't2', 'middle')
    F.text(8, y0 - 6, 'q', 'tb')
    cnt = {'elliptic': 0, 'hyperbolic': 0, 'ultrahyperbolic': 0}
    for p in range(9):
        F.text(x0 + cw * p + cw / 2, y0 - 6, str(p), 'tb', 'middle')
    for q in range(9):
        F.text(x0 - 10, y0 + cw * q + cw / 2 + 5, str(q), 'tb', 'end')
        for p in range(9):
            if not 1 <= p + q <= 8: continue
            A = bc.Alg(bc.sig(p, q)); diag = [A.sq(1 << i) for i in range(p + q)]       # the diagonal of nabla nabla: e_a e_a = eps_a
            plus, minus = diag.count(1), diag.count(-1); sym = mx.symbol(plus, minus); cl = sym['class']; cnt[cl] += 1
            assert (cl == 'hyperbolic') == (min(p, q) == 1)
            cls = {'elliptic': 'z', 'hyperbolic': 'p1', 'ultrahyperbolic': 'p2'}[cl]
            X, Yc = x0 + cw * p, y0 + cw * q
            F.rect(X + 1, Yc + 1, cw - 2, cw - 2, cls, 4, tip='Cl(%d,%d): %s, clock %d' % (p, q, cl, (p - q) % 8))
            F.text(X + cw / 2, Yc + 17, cl[0].upper(), 'tb', 'middle'); F.text(X + cw / 2, Yc + 30, '%d' % ((p - q) % 8), 'tm', 'middle')
            if (p, q) in ((1, 3), (3, 1)): F.rect(X + 2.5, Yc + 2.5, cw - 5, cw - 5, 'lk', 4)
    F.para(8, 372, 'E elliptic (one sign), H hyperbolic (one sign occurs once), U ultrahyperbolic; the small figure is the clock p − q mod 8. Framed: Cl(1,3) and its mirror Cl(3,1). check_T18.log: %s of %s assertions hold.' % (held.group(1), held.group(2)), 't2')
    assert cnt['hyperbolic'] == 2 * 7 - 1                     # n = 2: Cl(1,1); n = 3 ... 8: Cl(1,n-1) and Cl(n-1,1)
    F.save()

# ================================================================================================ part 1: Maxwell
def maxwell_cell():
    spec = mx.phys_spec(3); D = mx.build_cell(spec, random.Random(29)); return spec, D
@figure
def fig_views():
    spec, D = maxwell_cell(); A = bc.Alg(bc.sig(1, 3)); Fm = spec['Fmask']; ax = spec['axes']
    F = Fig('maxwell_views.svg', 400, 540, 'The field of Maxwell on the labels of Cl(1,3) in four views: algebra, simplex, cube, whole numbers')
    show = {f: spec['show'](f) for f in Fm}
    # (a) algebra
    F.text(6, 18, '(a) algebra', 'th')
    for i, f in enumerate(sorted(Fm, key=lambda f: Fm[f])):
        m = Fm[f]; sq = A.sq(m); y = 36 + 24 * i
        F.rect(6, y, 186, 20, 'p1' if sq > 0 else 'p2', 3, tip='%s = %s, square %s' % (show[f], gname(m), sq))
        F.text(12, y + 15, '%s  %s' % (gname(m), show[f]), 'tb'); F.text(186, y + 15, ('square +1' if sq > 0 else 'square −1'), 't2', 'end')
    F.para(6, 194, 'E: planes with t, square +1 (boosts); B: planes of space, square −1 (turns)', 't2', maxch=31, lh=15)
    # (b) simplex
    F.text(206, 18, '(b) simplex t x y z', 'th')
    P = {0: (300, 42), 1: (222, 186), 2: (382, 186), 3: (318, 140)}
    for f, m in Fm.items():
        i, j = [k for k in range(4) if m >> k & 1]; (x1, y1), (x2, y2) = P[i], P[j]
        F.line(x1, y1, x2, y2, 'l1' if i == 0 else 'l2', tip=show[f])
        ox, oy = {(0, 1): (-16, 0), (0, 2): (16, -2), (0, 3): (12, 6), (1, 2): (0, 15), (1, 3): (-6, -6), (2, 3): (14, -4)}[(i, j)]
        F.text((x1 + x2) / 2 + ox, (y1 + y2) / 2 + oy, show[f], 'tb', 'middle')
    for k, (x, y) in P.items():
        F.circ(x, y, 9, 'bg'); F.circ(x, y, 9, 'ax'); F.text(x, y + 4, ax[k], 'tb', 'middle')
    F.para(212, 214, 'E on the edges at t, B round the base x y z', 't2', maxch=30, lh=15)
    # (c) cube: grades
    F.text(6, 244, '(c) cube: the 16 labels by grade; F in grade 2', 'th')
    layer = [[m for m in range(16) if bc.pc(m) == g] for g in range(5)]
    xs = [30, 110, 200, 290, 370]
    for g, L in enumerate(layer):
        for i, m in enumerate(L):
            y = 300 - 9 * (len(L) - 1) + 18 * i
            F.circ(xs[g], y, 6, 's1' if g == 2 else ('s2' if g in (1, 3) else 'hol'), tip='%s (bits %s), grade %d' % (gname(m), bits(m, 4), g))
        F.text(xs[g], 362, 'grade %d · %d' % (g, len(L)), 't2', 'middle')
    drops = sum(1 for i in D['incidences'] if i['op'] == 'contract'); adds = sum(1 for i in D['incidences'] if i['op'] == 'wedge')
    assert drops == adds == 12 and len(D['incidences']) == 24
    F.arrow(185, 270, 125, 270); F.text(155, 263, 'drop: %d' % drops, 'tm', 'middle')
    F.arrow(215, 270, 275, 270); F.text(245, 263, 'add: %d' % adds, 'tm', 'middle')
    # (d) whole numbers
    F.text(6, 394, '(d) whole numbers: t, x, y, z = 2, 3, 5, 7', 'th')
    PR = [2, 3, 5, 7]; y = 414
    for f in sorted(Fm, key=lambda f: Fm[f]):
        m = Fm[f]; name = math.prod(PR[k] for k in range(4) if m >> k & 1)
        dr = ['÷%d→%d' % (PR[k], name // PR[k]) for k in range(4) if m >> k & 1]; ad = ['×%d→%d' % (PR[k], name * PR[k]) for k in range(4) if not m >> k & 1]
        F.text(10, y, show[f], 'tb'); F.text(44, y, str(name), 'tb'); F.text(84, y, '  '.join(dr), 't mono'); F.text(236, y, '  '.join(ad), 't mono')
        y += 18
    F.para(10, y + 6, 'A label is the product of its primes; a drop divides (and lands on a vector), an add multiplies (and lands on a trivector).', 't2')
    F.save()

@figure
def fig_terms():
    spec, D = maxwell_cell(); Fm = spec['Fmask']; show = {f: spec['show'](f) for f in Fm}
    SL = 'selfcheck/proofs/logs/step_lines.log'
    counts = ints(need(r'm = 2 is Maxwell: n C\(n,2\) terms for n = 2 to 7: the line prints \[([\d, ]+)\]', SL).group(1))
    assert counts == [n * comb(n, 2) for n in range(2, 8)]
    F = Fig('maxwell_terms.svg', 400, 420, 'The 24 terms of Maxwell’s equation in Cl(1,3), read off the products of the labels')
    fields = sorted(Fm, key=lambda f: Fm[f]); eqs = sorted(D['equations'], key=lambda e: (bc.pc(e['target']), e['target']))
    x0, cw, rh, y0 = 116, 47, 26, 30
    F.text(6, 16, 'equation', 'tb')
    for j, f in enumerate(fields): F.text(x0 + cw * j + cw / 2, 16, show[f], 'tb', 'middle')
    for i, e in enumerate(eqs):
        y = y0 + rh * i; g = bc.pc(e['target'])
        F.text(6, y + 17, e['name'], 'tb' if g == 1 else 't'); F.text(x0 - 6, y + 17, gname(e['target']), 'tm', 'end')
        for j, f in enumerate(fields):
            inc = [k for k in D['incidences'] if k['target'] == e['target'] and k['field'] == f]
            F.rect(x0 + cw * j + 1, y + 1, cw - 2, rh - 2, ('p1' if g == 1 else 'p3') if inc else 'z', 3,
                   tip=('%s: %s' % (e['name'], inc[0]['term'])) if inc else None)
            if inc:
                k = inc[0]; F.text(x0 + cw * j + cw / 2, y + 17, ('+' if k['sign'] > 0 else MINUS) + '∂' + k['axis_name'], 't', 'middle')
    yb = y0 + rh * len(eqs) + 10
    yy = F.para(6, yb + 6, 'Blue: the grade-1 rows (Gauss, Ampère); green: the grade-3 rows (Faraday, no monopole). Each cell: the sign and the derivative of the term.', 't2')
    yy = F.para(6, yy + 14, 'The terms of ∇F = J with n generators, n·C(n,2), as step_lines.log prints them', 'th')
    X, Y = axes(F, 40, yy + 8, 340, 90, (1.5, 7.5), (0, 160), range(2, 8), [0, 50, 100, 150], 'n')
    for n, c in zip(range(2, 8), counts):
        F.rect(X(n) - 14, Y(c), 28, Y(0) - Y(c), 's1', 3, tip='n = %d: %d terms' % (n, c)); F.text(X(n), Y(c) - 4, str(c), 't2', 'middle')
    F.save()

@figure
def fig_box():
    A = bc.Alg(bc.sig(1, 3)); ax = ['t', 'x', 'y', 'z']
    F = Fig('box_twins.svg', 400, 250, 'The sixteen products of two generators of Cl(1,3): twins cancel, the diagonal is the wave operator')
    x0, y0, cw, ch = 40, 26, 64, 40
    for j in range(4): F.text(x0 + cw * j + cw / 2, y0 - 8, 'e%s ∂%s' % (sub(j), ax[j]), 'tb', 'middle')
    twins = 0
    for i in range(4):
        F.text(x0 - 8, y0 + ch * i + 25, 'e%s' % sub(i), 'tb', 'end')
        for j in range(4):
            s, c = A.blade_mul(1 << i, 1 << j)
            if i != j:
                s2, c2 = A.blade_mul(1 << j, 1 << i); assert c2 == c and s2 == -s; twins += 1
            cls = ('p1' if s > 0 else 'p2') if i == j else 'p4'
            t = ('+1' if s > 0 else MINUS + '1') if i == j else ('+' if s > 0 else MINUS) + gname(c)
            F.rect(x0 + cw * j + 1, y0 + ch * i + 1, cw - 2, ch - 2, cls, 4, tip='e%d e%d = %s' % (i, j, t))
            F.text(x0 + cw * j + cw / 2, y0 + ch * i + 25, t, 't', 'middle')
    assert twins == 12
    F.text(x0 + 4 * cw + 10, y0 + 30, '12 off the', 't2'); F.text(x0 + 4 * cw + 10, y0 + 46, 'diagonal: six', 't2')
    F.text(x0 + 4 * cw + 10, y0 + 62, 'twin pairs of', 't2'); F.text(x0 + 4 * cw + 10, y0 + 78, 'opposite sign', 't2')
    F.text(x0 + 4 * cw + 10, y0 + 110, 'diagonal:', 't2'); F.text(x0 + 4 * cw + 10, y0 + 126, '+1 −1 −1 −1', 'tb')
    F.text(6, 214, '∇∇ = Σ eₐe_b ∂ₐ∂_b: twins cancel since ∂ₐ∂_b = ∂_b∂ₐ, so', 't2')
    F.text(6, 232, '∇∇ = ∂t² − ∂x² − ∂y² − ∂z² on every component (MAP-039)', 't2')
    F.save()

@figure
def fig_plane_wave():
    BIV = [m for m in range(16) if bc.pc(m) == 2]; spec = mx.phys_spec(3); show = {m: spec['show'](f) for f, m in spec['Fmask'].items()}
    def Lw(w, kz):
        N = {1: Fr(w), 8: Fr(-kz)}                                        # omega e_t - k e_z, the symbol of nabla on f(omega t - k z)
        return lambda P: mv_mul(N, P, None, lambda a, b, _: mx.bprod(a, b, 1))     # bprod gives (mask, sign), as bmul
    ws = [Fr(i, 8) for i in range(-16, 17)]; dims = [len(kernel(BIV, Lw(w, 1))) for w in ws]
    assert all((d == 2) == (abs(w) == 1) for w, d in zip(ws, dims)) and all(d in (0, 2) for d in dims)
    K = kernel(BIV, Lw(1, 1))
    F = Fig('plane_wave.svg', 400, 300, 'A plane wave on the labels: the kernel of F ↦ (ω e_t − k e_z)F on the six bivectors, for k = 1')
    X, Y = axes(F, 44, 30, 330, 120, (-2, 2), (0, 2.4), [-2, -1, 0, 1, 2], [0, 1, 2], 'ω (with k = 1)', 'dimension of the kernel')
    for w, d in zip(ws, dims):
        F.circ(X(w), Y(d), 4.5 if d else 3, 's1' if d else 'hol', tip='ω = %s: kernel %d' % (fs(w), d))
    F.text(X(1) + 8, Y(2) + 4, 'ω = k', 't2'); F.text(X(-1) - 8, Y(2) + 4, 'ω = −k', 't2', 'end')
    F.text(6, 214, 'At ω = k the kernel is spanned by', 'th')
    for i, P in enumerate(K):
        terms = ' '.join(('+ ' if v > 0 else MINUS + ' ') + ('' if abs(v) == 1 else fs(abs(v))) + '%s (%s)' % (gname(m), show[m]) for m, v in sorted(P.items()))
        F.text(14, 236 + 20 * i, terms.lstrip('+ '), 't')
    F.para(6, 286, 'Each has one E part and one B part of the same size, at right angles to each other and to z.', 't2')
    for P in K:
        assert len(P) == 2 and len({abs(v) for v in P.values()}) == 1 and sum(1 for m in P if m & 1) == 1
    F.save()

# ================================================================================================ part 2: Dirac and the coupling step
def dirac_op(k, sg, m):
    """the ordinary equation of the coupling step on a plane wave P exp(sg J k.x), as shifted_dirac.py writes it: bD(P) J - m P,
    bD(P) = (sg khat) P J gamma_0, with J = gamma_2 gamma_1 and the product bmul of coupling_selfcheck.py"""
    sq = cs.sqs(4); Jm, Js = cs.bmul(1 << 2, 1 << 1, sq); J = {Jm: Fr(Js)}; g0 = {1: Fr(1)}
    kh = {1 << mu: Fr(sg) * Fr(k[mu]) for mu in range(4) if k[mu]}
    def L(P):
        bD = mv_mul(mv_mul(mv_mul(kh, P, sq), J, sq), g0, sq)
        return mv_lin((1, mv_mul(bD, J, sq)), (-m, P))
    return L
EVEN4 = [m for m in range(16) if bc.pc(m) % 2 == 0]
@figure
def fig_dirac_shell():
    SD = 'selfcheck/proofs/logs/shifted_dirac.log'
    g = need(r'n = 4, m = (\d+): nabla psi J = m psi gamma_0 has a kernel of (\d+) real dimensions per sector at k = (.*?) \(Q = (\d+)\) and none at (.*?)\n', SD)
    m, kd = int(g.group(1)), int(g.group(2)); on = [tuple(ints(t)) for t in re.findall(r'\([-\d,]+\)', g.group(3))]
    off = [tuple(ints(t)) for t in re.findall(r'\([-\d,]+\)', g.group(5))]
    for k in on: assert all(len(kernel(EVEN4, dirac_op(k, sg, m))) == kd for sg in (-1, 1)), k
    for k in off: assert all(len(kernel(EVEN4, dirac_op(k, sg, m))) == 0 for sg in (-1, 1)), k
    F = Fig('dirac_shell.svg', 400, 380, 'Plane-wave solutions of the Dirac equation on the labels: the kernel dimension over the (k₁, k₀) plane, m = 3')
    X, Y = axes(F, 44, 30, 330, 270, (-8, 8), (-9, 9), [-8, -4, 0, 4, 8], [-9, -6, -3, 0, 3, 6, 9], 'k₁ (k₂ = k₃ = 0)', 'k₀')
    for br in (1, -1):
        F.poly([(X(x), Y(br * math.sqrt(x * x + m * m))) for x in [i / 10 for i in range(-80, 81)]], 'ld')
    nfull = 0
    for k0 in range(-9, 10):
        for k1 in range(-8, 9):
            d = [len(kernel(EVEN4, dirac_op((k0, k1, 0, 0), sg, m))) for sg in (-1, 1)]; assert d[0] == d[1]
            on_shell = k0 * k0 - k1 * k1 == m * m; assert (d[0] == kd) == on_shell and d[0] in (0, kd)
            if on_shell: nfull += 1; F.circ(X(k1), Y(k0), 5.5, 's1', tip='k = (%d, %d, 0, 0): kernel %d in each sector' % (k0, k1, d[0]))
            else: F.circ(X(k1), Y(k0), 1.6, 'hol')
    ts = [Fr(1, 5), Fr(1, 3), Fr(3, 5), Fr(2, 3)]; nrat = 0
    for t in ts + [-t for t in ts]:
        for br in (1, -1):
            k0, k1 = br * m * (1 + t * t) / (1 - t * t), 2 * m * t / (1 - t * t)
            if abs(k1) > 8 or abs(k0) > 9: continue
            d = len(kernel(EVEN4, dirac_op((k0, k1, 0, 0), -1, m))); assert d == kd; nrat += 1
            F.circ(X(k1), Y(k0), 4, 's3', tip='k = (%s, %s, 0, 0): kernel %d' % (fs(k0), fs(k1), d))
    F.para(6, 352, 'Blue: integer k on the shell k₀² − k₁² = 9 (kernel %d per sector, %d points); green: %d rational points of the shell; small rings: integer k off it (kernel 0). Both sectors give the same dimension; the dashed curve is the hyperbola.' % (kd, nfull, nrat), 't2')
    F.save()

@figure
def fig_current():
    O4 = 'selfcheck/proofs/logs/opened_4.log'
    lg = {int(a): ints(b) for a, b in re.findall(r'opn\.CUR n=(\d+), Cl\(1,\d+\): the grades of psi gamma_0 psi~ are \[([\d, ]+)\]', log(O4))}
    lb = {int(a): ints(b) for a, b in re.findall(r'opn\.CUR n=(\d+): every blade of these grades occurs: \[([\d, ]+)\] blades', log(O4))}
    assert sorted(lg) == list(range(1, 11))
    F = Fig('current_grades.svg', 400, 330, 'The grades of the current ψγ₀ψ̃ for n = 1 to 10, and the size of ψ in units of one Dirac spinor')
    hdr = ['n', 'grade 1', 'grade 5', 'grade 9', 'ψ even', 'Dirac', 'ratio']; xs = [8, 46, 108, 170, 234, 292, 350]
    for x, h in zip(xs, hdr): F.text(x, 18, h, 'tb')
    F.text(234, 34, '(real components)', 'tm')
    for n in range(1, 11):
        y = 40 + 24 * n - 18
        F.text(xs[0], y + 15, str(n), 'tb')
        if n <= 8:
            surv = cs.current_structure(n, 1); gr = sorted({bc.pc(b) for b in surv}); assert gr == lg[n]
            cnt = [sum(1 for b in surv if bc.pc(b) == g) for g in gr]; assert sorted(cnt) == sorted(lb[n]) and cnt == [comb(n, g) for g in gr]
        else: gr, cnt = lg[n], lb[n]
        for gi, gg in enumerate((1, 5, 9)):
            if gg in gr:
                c = cnt[gr.index(gg)]; F.rect(xs[1 + gi] - 4, y, 56, 20, 'p1' if gg == 1 else 'p2', 3, tip='n = %d: %d blades of grade %d' % (n, c, gg))
                F.text(xs[1 + gi] + 24, y + 15, str(c), 't', 'middle')
        if n <= 8:
            r = cs.ladder_row(n); ratio = Fr(r['psi_components'], r['dirac_real_dim'])
            F.text(xs[4] + 12, y + 15, str(r['psi_components']), 't', 'middle'); F.text(xs[5] + 14, y + 15, str(r['dirac_real_dim']), 't', 'middle')
            if ratio == 1: F.rect(xs[6] - 4, y, 40, 20, 'p3', 3, tip='n = %d: exactly one Dirac spinor' % n)
            F.text(xs[6] + 16, y + 15, fs(ratio), 'tb' if ratio == 1 else 't', 'middle')
    assert [Fr(cs.ladder_row(n)['psi_components'], cs.ladder_row(n)['dirac_real_dim']) for n in (5, 6, 7, 8)] == [2, 2, 4, 4]
    F.para(6, 304, 'Grades ≡ 1 mod 4, every blade present: C(n,5) of grade 5 (CPL-012). ψ is one Dirac spinor exactly at n = 3 and 4, green (CPL-003). Rows 9 and 10: opened_4.log.', 't2')
    F.save()

@figure
def fig_shift():
    SD = 'selfcheck/proofs/logs/shifted_dirac.log'
    g = need(r'n = 4, m = (\d+), kappa = (\d+): at E tau = pi/2, E = (\d+) .*? and at E tau = 3 pi/2, E = (\d+) ', SD)
    m, kap, E0, E1 = map(int, g.groups()); assert E0 == m + kap and E1 == m - kap
    need(r'no plane wave at: tau = lambda_C \(E tau = 2 pi\); tau = lambda_C/2; tau = 0', SD)
    r = need(r'kernel 4 per sector on Q = 9 for theta = 0, pi; on Q = -9 \(spacelike k\) for theta = pi/2, 3pi/2; 0 for \((\d+)/(\d+), (\d+)/(\d+)\), \((\d+)/(\d+), (\d+)/(\d+)\)', SD)
    rat = [(Fr(int(r.group(1)), int(r.group(2))), Fr(int(r.group(3)), int(r.group(4)))), (Fr(int(r.group(5)), int(r.group(6))), Fr(int(r.group(7)), int(r.group(8))))]
    F = Fig('shift_lattice.svg', 400, 470, 'The lattice of allowed shifts of the shifted Dirac equation, m = 3 and κ = 2, and the retarded shift on the circle')
    F.text(6, 16, '(a) (iD − m + iκe^(−τD))ψ = 0, m = %d, κ = %d' % (m, kap), 'th')
    X, Y = axes(F, 44, 44, 330, 200, (0, 5), (0, 6.5), [0, 1, 2, 3, 4, 5], [0, 1, 3, 5], 'τ', 'E')
    for j in range(8):
        c = (j + .5) * math.pi; a = c / 6.5
        if a < 5: curve(F, X, Y, lambda t, c=c: c / t, a, 5, 'gr' if j % 2 else 'gr')
    F.line(X(0), Y(E0), X(5), Y(E0), 'ld'); F.line(X(0), Y(E1), X(5), Y(E1), 'ld')
    F.text(X(5) - 2, Y(E0) - 5, 'E = m + κ', 'tm', 'end'); F.text(X(5) - 2, Y(E1) - 5, 'E = m − κ', 'tm', 'end')
    pts = []
    for j in range(12):
        E = m + (-1) ** j * kap
        if E > 0:
            tau = (j + .5) * math.pi / E
            if tau <= 5: pts.append((j, E, tau))
    for j, E, tau in pts:
        F.circ(X(tau), Y(E), 5.5, 's1', tip='Eτ = (%d + 1/2)π, E = %d, τ = %.3f' % (j, E, tau))
    for E, tau, why in [(m, 0, 'τ = 0'), (E0, 2 * math.pi / E0, 'Eτ = 2π'), (E0, math.pi / E0, 'Eτ = π')]:
        F.circ(X(tau), Y(E), 4.5, 'hol', tip='no plane wave: ' + why)
    yy = F.para(6, 294, 'Plane waves only on the blue dots (%d in view), where the grey curves Eτ = (j + 1/2)π, on which cos Eτ = 0, meet E = m + (−1)ʲκ. Rings: no plane wave (τ = 0, Eτ = π, Eτ = 2π, as the log lists).' % len(pts), 't2')
    F.text(6, yy + 14, '(b) a fixed shift of the mass term, θ = k·a', 'th')
    cx, cy, R = 96, yy + 96, 56
    F.circ(cx, cy, R, 'ax'); F.line(cx - R - 10, cy, cx + R + 10, cy, 'gr'); F.line(cx, cy - R - 10, cx, cy + R + 10, 'gr')
    for th, lab in [(0, 'θ = 0: shell Q = m²'), (math.pi / 2, 'π/2: Q = −m²'), (math.pi, 'π: mass −m'), (3 * math.pi / 2, '3π/2: Q = −m²')]:
        x, y = cx + R * math.cos(th), cy - R * math.sin(th); F.circ(x, y, 5.5, 's1', tip=lab)
    for c, s in rat:
        x, y = cx + R * float(c), cy - R * float(s); F.circ(x, y, 4.5, 'hol', tip='(%s, %s): no solution' % (c, s))
    F.para(178, cy - 40, 'Blue: θ in (π/2)ℤ, a kernel of 4 per sector (ATY-004). Rings: the rational points (%s, %s) and (%s, %s) of the circle, no solution. Data: shifted_dirac.log, shd·QNT and shd·RET (n = 4).' % (rat[0][0], rat[0][1], rat[1][0], rat[1][1]), 't2', maxch=34)
    F.save()

# ================================================================================================ part 3: Yang-Mills and matter
@figure
def fig_comm():
    gens, idx, f = ym.algebra(4); SL = 'selfcheck/proofs/logs/step_lines.log'
    nc = ints(need(r'the pairs that share one index: the line prints \[([\d, ]+)\]', SL).group(1))
    cm = ints(need(r'the other pairs \(share 0 or 2 indices\) commute: the line prints \[([\d, ]+)\]', SL).group(1))
    F = Fig('comm_graph.svg', 400, 300, 'The commutator graph of the six bivectors of Cl(0,4): an octahedron, with closed and open triangles')
    lab = {g: 'B' + sub(''.join(str(i) for i in range(4) if g >> i & 1)) for g in gens}
    outer = [g for g in gens if g & 1]; inner = [g ^ 15 for g in outer]          # B_0i outside, their complements inside
    cx, cy = 200, 168; Ro, Ri = 136, 36
    pos = {}
    for i, g in enumerate(outer):
        a = math.pi / 2 + 2 * math.pi * i / 3; pos[g] = (cx + Ro * math.cos(a), cy - Ro * math.sin(a))
        a2 = a + math.pi; pos[g ^ 15] = (cx + Ri * math.cos(a2), cy - Ri * math.sin(a2))
    edges = sorted({tuple(sorted((gens[a], gens[b]))) for (a, b) in f})
    assert len(edges) == 12 == nc[2]
    closed = [t for t in itertools.combinations(gens, 3) if all(tuple(sorted(p)) in edges for p in itertools.combinations(t, 2))]
    cl = [t for t in closed if all(set(f[(idx[a], idx[b])]) <= {idx[x] for x in t} for a, b in itertools.permutations(t, 2))]
    assert len(closed) == 8 and len(cl) == 4
    for t in cl:
        if set(t) != set(inner): F.poly([pos[g] for g in t], 'p3', close=True, tip='closed: ' + ' '.join(lab[g] for g in t) + ' = so(3)')
    F.poly([pos[g] for g in inner], 'p3', close=True, tip='closed: ' + ' '.join(lab[g] for g in inner) + ' = so(3)')
    for a, b in edges: F.line(*pos[a], *pos[b], 'lk', tip='%s and %s anticommute (one shared index)' % (lab[a], lab[b]))
    for g in outer: F.line(*pos[g], *pos[g ^ 15], 'ld', tip='%s and %s commute (no shared index)' % (lab[g], lab[g ^ 15]))
    for g, (x, y) in pos.items():
        F.circ(x, y, 15, 'bg'); F.circ(x, y, 15, 'ax'); F.text(x, y + 5, lab[g], 'tb', 'middle')
    yy = F.para(6, 274, 'Solid: the 12 anticommuting pairs (one shared index); dashed: the 3 commuting pairs. Green: the 4 closed triangles {B_ab, B_bc, B_ac}, each an so(3); the other 4 faces, the outer one {B₀₁, B₀₂, B₀₃} among them, are open (YM-001).', 't2')
    F.para(6, yy + 6, 'Pairs that anticommute, m = 2 … 8: %s; pairs that commute: %s (step_lines.log).' % (', '.join(map(str, nc)), ', '.join(map(str, cm))), 'tm')
    assert cm[2] == 3
    F.save()

@figure
def fig_bpst_skyrme():
    YS = 'selfcheck/gravity/logs/ym_solutions.log'; SK = 'selfcheck/proofs/logs/skyrme_holonomy.log'
    c96 = int(need(r'c \(x\^2 \+ rho\^2\)\^4 / rho\^4 = \[Fraction\((\d+), 1\)\]', YS).group(1))
    need(r'with the radial integral = 1/\(12 rho\^4\) exactly', YS)
    data = ast.literal_eval(need(r'Pythagorean data \(r, rho\^2, theta/pi, f/pi\) = (\[.*?\]):', SK).group(1))
    need(r'f/pi = 1 - \(1 \+ rho\^2/r\^2\)\^\(-1/2\) exactly', SK)
    F = Fig('bpst_skyrme.svg', 400, 470, 'The BPST instanton density and the Skyrme profile of its holonomy along lines')
    F.text(6, 16, '(a) BPST: radial density of F∧F, ρ = 1', 'th')
    q = lambda r: 2 * math.pi ** 2 * r ** 3 * c96 / (r * r + 1) ** 4 / (16 * math.pi ** 2)
    X, Y = axes(F, 44, 32, 330, 150, (0, 3), (0, 0.9), [0, 1, 2, 3], [0, .3, .6, .9], 'r/ρ', '', fy=lambda v: '%.1f' % v)
    pts = [(i * 3 / 200, q(i * 3 / 200)) for i in range(201)]
    F.poly([(X(0), Y(0))] + [(X(x), Y(y)) for x, y in pts] + [(X(3), Y(0))], 'p1', close=True, tip='area = 1: the instanton number')
    F.poly([(X(x), Y(y)) for x, y in pts], 'l1')
    area = sum((pts[i + 1][0] - pts[i][0]) * (pts[i + 1][1] + pts[i][1]) / 2 for i in range(200)) + (1 - 0)
    F.text(X(1.45), Y(.66), '2π²r³ · %dρ⁴/(r²+ρ²)⁴ / 16π²' % c96, 't2'); F.text(X(1.45), Y(.54), 'area = 1, the instanton number', 't2')
    F.text(6, 244, '(b) the holonomy along the lines x + t e₄', 'th'); F.text(6, 262, 'a hedgehog with f(r) = π(1 − (1 + ρ²/r²)^(−1/2))', 't2')
    X, Y = axes(F, 44, 290, 330, 150, (0, 3), (0, 1), [0, 1, 2, 3], [0, .5, 1], 'r/ρ', 'f/π', fy=lambda v: '%g' % v)
    fpi = lambda x: 1 - (1 + 1 / (x * x)) ** -.5 if x > 0 else 1
    curve(F, X, Y, fpi, 0.001, 3, 'l2')
    curve(F, X, Y, lambda x: min(1.0, .5 / (x * x)) if x > 0 else 1, 0.72, 3, 'ld')
    for r, rho2, th, fp in data:
        rho = math.isqrt(rho2); assert rho * rho == rho2; x = Fr(int(r), rho); fv = Fr(fp)
        assert abs(float(fv) - fpi(float(x))) < 1e-12 and fv == 1 - Fr(th)
        F.circ(X(x), Y(fv), 5.5, 's2', tip='r = %s, ρ² = %d: f/π = %s exactly (sky·LINE)' % (r, rho2, fp))
    for i, (r, rho2, th, fp) in enumerate(sorted(data, key=lambda d: Fr(int(d[0]), math.isqrt(d[1])))):
        F.text(X(1.25), Y(.92) + 15 * i, 'r/ρ = %s:  f/π = %s' % (Fr(int(r), math.isqrt(rho2)), fp), 'tm')
    F.para(6, 486, 'Dots: the three Pythagorean data of skyrme_holonomy.log, exact; dashed: the tail ρ²/(2r²). f runs from π at the centre to 0 at infinity: baryon number 1, the instanton number.', 't2')
    F.save()

@figure
def fig_cs():
    SK = 'selfcheck/proofs/logs/skyrme_holonomy.log'
    g = need(r'the field c A: Chern-Simons value 3c\^2 - 2c\^3 = (-?\d+) at c = 2 \((-?\d+) at c = 1, (-?\d+) at c = 0\) and holonomy baryon number c = 2', SK)
    cs2, cs1, cs0 = map(int, g.groups())
    cs_ = lambda c: 3 * c * c - 2 * c ** 3; assert (cs_(2), cs_(1), cs_(0)) == (cs2, cs1, cs0)
    an = need(r'the anti-instanton gives (-?\d+) with instanton number (-?\d+)', SK)
    F = Fig('chern_simons.svg', 400, 290, 'The field cA: its Chern–Simons value and the baryon number of its holonomy agree only at c = 0 and 1')
    X, Y = axes(F, 44, 30, 330, 190, (-0.5, 2.25), (-4.5, 2.5), [0, 1, 2], [-4, -2, 0, 2], 'c', '')
    curve(F, X, Y, cs_, -0.5, 2.25, 'l1', ylim=(-4.5, 2.5)); curve(F, X, Y, lambda c: c, -0.5, 2.25, 'l2')
    for c in (0, 1, 2):
        F.circ(X(c), Y(cs_(c)), 5, 's1', tip='Chern–Simons value at c = %d: %d' % (c, cs_(c)))
        F.circ(X(c), Y(c), 5, 's2', tip='holonomy baryon number at c = %d: %d' % (c, c))
    legend(F, 44, 270, [('l1', 'Chern–Simons value 3c² − 2c³'), ('l2', 'baryon number of the holonomy, c')])
    F.para(6, 310, 'c = 1 is the BPST instanton: both 1. At c = 2 they are %d and 2 (2A is no instanton). The anti-instanton gives %s and %s. Data: skyrme_holonomy.log, part 2.' % (cs2, fs(an.group(1)), fs(an.group(2))), 't2')
    F.save()

@figure
def fig_sm16():
    SM = 'selfcheck/proofs/logs/sm16_labels.log'
    sums = need(r'labels \(sums over the 16 even labels; triplets b = 1, antitriplets b = 2, doublets a = 1 in pairs \{x, x\^3\}\): (.*)\n', SM).group(1)
    tr = need(r'over the 16 even labels: Tr T3\^2 = (\S+), Tr Q\^2 = (\S+), ratio (\S+) \(exact\)', SM)
    table = need(r'textbook table (Q_L .*?) with T\(3\)', SM).group(1)
    multi = {}
    for name, d3, d2, y in re.findall(r'([\w^]+) \((3-bar|3|1),(\d),(-?[\d/]+)\)', table): multi[Fr(y)] = (name, d3, d2)
    assert len(multi) == 6
    SHOW = {'Q_L': 'Q_L', 'u_R^c': 'uᶜ', 'd_R^c': 'dᶜ', 'L': 'L', 'e_R^c': 'eᶜ', 'nu_R^c': 'νᶜ'}
    a_of = lambda x: bc.pc(x & 3); b_of = lambda x: bc.pc(x >> 2)            # weak bits 0, 1; colour bits 2, 3, 4 (sm16_labels.py)
    Y = lambda x: Fr(a_of(x), 2) - Fr(b_of(x), 3); Q = lambda x: (x & 1) - Fr(b_of(x), 3); T3 = lambda x: Fr((x & 1) - ((x >> 1) & 1), 2)
    EV = [x for x in range(32) if bc.pc(x) % 2 == 0]; assert len(EV) == 16
    got = {'SU(3)^3': Fr(sum(1 for x in EV if b_of(x) == 1) - sum(1 for x in EV if b_of(x) == 2), 3), 'U(1)^3': sum(Y(x) ** 3 for x in EV),
           'grav U(1)': sum(Y(x) for x in EV), 'doublets': Fr(len({frozenset((x, x ^ 3)) for x in EV if a_of(x) == 1}))}
    logd = {k.strip(): Fr(v) for k, v in re.findall(r'([A-Za-z()^0-9 ]+?) (-?[\d/]+)(?:,|$)', sums)}
    for k, v in got.items(): assert logd[k] == v, (k, v, logd)
    t3, q2 = sum(T3(x) ** 2 for x in EV), sum(Q(x) ** 2 for x in EV)
    assert (t3, q2, t3 / q2) == (Fr(tr.group(1)), Fr(tr.group(2)), Fr(tr.group(3)))
    assert all(Y(x ^ 31) == -Y(x) and Q(x ^ 31) == -Q(x) and bc.pc(x ^ 31) % 2 == 1 for x in EV)
    F = Fig('sm16.svg', 400, 560, 'One generation on the sixteen even labels of five bits, with hypercharge and charge')
    F.text(6, 16, 'a = weak bits on (bits 0, 1), b = colour bits on (2, 3, 4)', 'th')
    x0, y0, cw, ch = 40, 46, 118, 104
    for a in range(3): F.text(x0 + cw * a + cw / 2, y0 - 8, 'a = %d' % a, 'tb', 'middle')
    for b in range(4):
        F.text(x0 - 6, y0 + ch * b + 18, 'b = %d' % b, 'tb', 'end')
        for a in range(3):
            xs = [x for x in EV if a_of(x) == a and b_of(x) == b]; X0, Y0 = x0 + cw * a, y0 + ch * b
            if not xs: F.rect(X0 + 2, Y0 + 2, cw - 4, ch - 4, 'z', 5); continue
            y = Y(xs[0]); name, d3, d2 = multi[y]
            F.rect(X0 + 2, Y0 + 2, cw - 4, ch - 4, 'p1' if b in (1, 2) else 'p3', 5, tip='%s (%s, %s, %s): %d labels' % (name, d3, d2, y, len(xs)))
            F.text(X0 + 8, Y0 + 17, '%s  Y = %s' % (SHOW[name], fs(y)), 'tb')
            for i, x in enumerate(xs):
                F.text(X0 + 8, Y0 + 32 + 12 * i, '%s|%s  Q = %s' % (bits(x >> 2, 3), bits(x & 3, 2), fs(Q(x))), 'tm mono')
    yb = y0 + ch * 4 + 14
    F.text(6, yb, 'Sums over the 16 (sm16_labels.log, recomputed here):', 'th')
    F.text(6, yb + 18, sums.replace('^3', '³').replace('^2', '²').replace('-', MINUS), 't2')
    F.para(6, yb + 36, 'Tr T₃² = %s, Tr Q² = %s, ratio %s. The complement x ↦ x XOR 11111 sends each even label to an odd one with Y ↦ −Y and Q ↦ −Q: the 16 to the 16-bar (CAND-062). Blue: colour triplets and antitriplets; green: colour singlets.' % (tr.group(1), tr.group(2), tr.group(3)), 't2')
    F.save()

# ================================================================================================ part 4: gravity
@figure
def fig_curv_counts():
    O4 = 'selfcheck/proofs/logs/opened_4.log'; CW = 'selfcheck/proofs/logs/catw_lines.log'
    rows = [tuple(map(int, t)) for t in re.findall(r'\n\s+(\d)\s+(\d+)\s+(\d+)\s+(\d+)\s+\(', log(O4))]
    assert [r[0] for r in rows] == list(range(2, 9))
    sym = {int(n): (int(s), int(l4)) for n, s, l4 in re.findall(r'catl\.B2 n=(\d): dim Sym\^2 = (\d+) = dim ker b \+ (\d+)', log(CW))}
    F = Fig('curvature_counts.svg', 400, 330, 'Riemann = Ricci + Weyl, and the four-form part the Bianchi identity removes, for n = 2 to 8')
    x0, w = 52, 300
    F.text(6, 16, 'Sym²(Λ²) of the planes, n = 2 … 8, as shares', 'th')
    for i, (n, riem, ric, wey) in enumerate(rows):
        s = comb(comb(n, 2) + 1, 2); l4 = comb(n, 4); assert riem + l4 == s and riem == n * n * (n * n - 1) // 12 and ric + wey == riem
        if n in sym: assert sym[n] == (s, l4)
        y = 32 + 36 * i; F.text(x0 - 8, y + 16, 'n = %d' % n, 'tb', 'end'); xx = x0
        for val, cls, nmz in ((ric, 's1', 'Ricci'), (wey, 's2', 'Weyl'), (l4, 's4', 'Λ⁴ (removed by Bianchi)')):
            if val:
                ww = w * val / s; F.rect(xx, y, ww - 1.5, 22, cls, 2, tip='n = %d: %s %d of %d' % (n, nmz, val, s)); xx += ww
        F.text(x0 + w + 6, y + 16, '%d' % s, 't2')
        F.text(x0 + 4, y + 33, 'Riemann %d = Ricci %d + Weyl %d' % (riem, ric, wey) + ('' if not l4 else ';  Λ⁴ %d' % l4), 'tm')
    F.rect(6, 292, 12, 12, 's1', 2); F.text(22, 302, 'Ricci', 't2'); F.rect(70, 292, 12, 12, 's2', 2); F.text(86, 302, 'Weyl', 't2')
    F.rect(132, 292, 12, 12, 's4', 2); F.text(148, 302, 'Λ⁴: the part b removes', 't2')
    F.text(6, 322, 'Data: the table of opened_4.log (opn·WEYL) and catw_lines.log (catl·B2).', 'tm')
    F.save()

@figure
def fig_octahedron():
    AC = 'selfcheck/gravity/logs/aty_cone_defects.log'
    isq = ast.literal_eval(need(r'I\^2 by the bit rule: (\{.*?\})', AC).group(1))
    F = Fig('octahedron_planes.svg', 400, 300, 'The octahedron of the six planes of a four-space: 21 = 6 + 12 + 3 symmetric pairs, and the duality on its antipodes')
    planes = [m for m in range(16) if bc.pc(m) == 2]; I = 15; got = {}
    for p, q, name in ((4, 0, 'Cl(4,0)'), (0, 4, 'Cl(0,4)'), (1, 3, 'Cl(1,3)'), (3, 1, 'Cl(3,1)')):
        A = bc.Alg(bc.sig(p, q)); got[name] = A.sq(I)
        for m in planes:
            s, c = A.blade_mul(I, m); assert c == m ^ 15
    assert got == isq
    A = bc.Alg(bc.sig(1, 3)); lab = {m: 'γ' + sub(''.join(str(i) for i in range(4) if m >> i & 1)) for m in planes}
    cx, cy, Ro, Ri = 200, 160, 130, 36; outer = [m for m in planes if m & 1]; pos = {}
    for i, g in enumerate(outer):
        a = math.pi / 2 + 2 * math.pi * i / 3; pos[g] = (cx + Ro * math.cos(a), cy - Ro * math.sin(a))
        pos[g ^ 15] = (cx + Ri * math.cos(a + math.pi), cy - Ri * math.sin(a + math.pi))
    E = [(a, b) for a, b in itertools.combinations(planes, 2) if bc.pc(a & b) == 1]; Ant = [(a, a ^ 15) for a in outer]
    assert len(E) == 12 and len(Ant) == 3 and len(planes) + len(E) + len(Ant) == 21
    for a, b in E: F.line(*pos[a], *pos[b], 'lk', tip='%s with %s: one shared index (an edge)' % (lab[a], lab[b]))
    for a, b in Ant:
        s, c = A.blade_mul(I, a); F.line(*pos[a], *pos[b], 'l2', tip='I %s = %s%s in Cl(1,3); a term of F∧F' % (lab[a], '+' if s > 0 else MINUS, lab[b]))
    for g, (x, y) in pos.items():
        sq = A.sq(g); F.circ(x, y, 16, 'bg'); F.circ(x, y, 16, 'p1' if sq > 0 else 'p2', tip='%s: square %+d in Cl(1,3)' % (lab[g], sq))
        F.text(x, y + 5, lab[g], 'tb', 'middle')
    yy = F.para(6, 262, '6 vertices: a plane with itself; 12 edges: two planes sharing one index; 3 orange antipodes: two disjoint planes, the three cross terms of F∧F (LNS-013). 6 + 12 + 3 = 21.', 't2')
    yy = F.para(6, yy + 4, 'I = γ₀₁₂₃ maps each plane to its antipode; I² = %s1 in Cl(1,3), +1 in Cl(4,0) (aty_cone_defects.log): a complex structure (Q = E + iB, the Petrov types) against a real split 3 + 3 (W = W⁺ + W⁻).' % (MINUS if got['Cl(1,3)'] < 0 else '+'), 't2')
    F.para(6, yy + 4, 'Fill: the square of the plane in Cl(1,3), blue +1 (boosts), orange −1 (turns).', 'tm')
    F.save()

@figure
def fig_weyl():
    AM = 'selfcheck/gravity/logs/aty_matter_models.log'
    pts = [(Fr(m), [Fr(r) for r in rs.split(', ')]) for m, rs in re.findall(r'm = (\d+/?\d*) at r = ([\d/]+(?:, [\d/]+)*)', need(r'the engine\'s E_a\(0\) = 0 exactly, all 16 components, at the 8 points: (.*?) \(directions', AM).group(1))]
    assert sum(len(r) for _, r in pts) == 8
    sg = need(r'with eigenvalues \{double (-|\+) mu\} x \(1, 1, -2\), mu = m/\(r \+ m\)\^3', AM).group(1); dbl = -1 if sg == '-' else 1
    cp = need(r"W\+ type D \['double (-?\d+), simple (-?\d+)'\]; \|Rm\|\^2 = (\d+), \|W\+\|\^2 = (\d+)", AM)
    cd, csim = int(cp.group(1)), int(cp.group(2)); assert 2 * cd + csim == 0
    need(r'S4: R_abcd = d_ac d_bd - d_ad d_bc exactly \(sectional curvature 1\) at 3 points, W\+ and W- type O', AM)
    F = Fig('weyl_eigen.svg', 400, 430, 'The eigenvalues of W⁺ for Taub–NUT along r, and for CP² and S⁴, from the gravity engine')
    F.text(6, 16, '(a) Taub–NUT, V = 1 + m/r: m² × eigenvalues of W⁺, x = r/m', 'th')
    X, Y = axes(F, 44, 34, 330, 170, (0, 2), (-1.2, 2.2), [0, .5, 1, 1.5, 2], [-1, 0, 1, 2], 'x = r/m', '', fx=lambda v: '%g' % v, fy=lambda v: fs(v))
    mu = lambda x: (1 + x) ** -3
    curve(F, X, Y, lambda x: -dbl * -2 * mu(x) * -1 if False else -2 * dbl * mu(x), 0, 2, 'l2'); curve(F, X, Y, lambda x: dbl * mu(x), 0, 2, 'l1')
    for m, rs in pts:
        for r in rs:
            x = r / m; F.circ(X(x), Y(dbl * mu(float(x))), 4.5, 's1', tip='m = %s, r = %s: double eigenvalue %sμ, μ = %s' % (m, r, '−' if dbl < 0 else '+', m / (r + m) ** 3))
            F.circ(X(x), Y(-2 * dbl * mu(float(x))), 4.5, 's2', tip='m = %s, r = %s: simple eigenvalue %s2μ' % (m, r, '+' if dbl < 0 else '−'))
    legend(F, 230, 70, [('l2', 'simple: 2μ'), ('l1', 'double: −μ')])
    F.para(6, 252, 'μ = m/(r + m)³; dots: the 8 rational points of the log (m = 2, 1/2, 3), where the frame is Ricci-flat with W⁻ = 0 (type O) and W⁺ of type D (ATY-017).', 't2')
    F.text(6, 300, '(b) the compact models at their rational points', 'th')
    X2 = lambda v: 196 + 32 * v
    F.line(X2(-2.5), 380, X2(4.5), 380, 'ax')
    for v in range(-2, 5): F.line(X2(v), 380, X2(v), 384, 'ax'); F.text(X2(v), 397, fs(v), 'tm', 'middle')
    F.text(6, 334, 'CP², W⁺', 'tb'); F.text(6, 362, 'S⁴, W⁺ and W⁻', 'tb')
    for v, k in ((cd, 2), (csim, 1)):
        for j in range(k): F.circ(X2(v) + 7 * j, 330, 5.5, 's1' if v < 0 else 's2', tip='CP²: eigenvalue %d of W⁺ (%s)' % (v, 'double' if k == 2 else 'simple'))
    F.circ(X2(0), 358, 5.5, 's3', tip='S⁴: W⁺ = W⁻ = 0, conformally flat')
    F.para(6, 420, 'CP² with Ric = 6g: W⁺ has a double eigenvalue %s and a simple %d, |W⁺|² = %s; S⁴: W = 0 (ATY-018).' % (fs(cd), csim, cp.group(4)), 't2')
    F.save()

@figure
def fig_birkhoff():
    C1 = 'selfcheck/gravity/logs/c1_birkhoff.log'
    g = need(r'f = rho\^k, k = (-?\d)\.\.(-?\d), at 7 radii: P_tt = 2 \(k\+1\) rho\^\(k-2\), P_tan = k \(k\+1\) rho\^\(k-2\)', C1)
    need(r'radial eigenvalue = G\^t_t = 2 \(f0 \+ rho0 f1\)/rho0\^2 = 2 \(rho f\)\'/rho\^2', C1)
    need(r'the tangential eigenvalue \(every vector orthogonal to x\) is \(2 f1 \+ rho0 f2\)/rho0 = \(rho f\)\'\'/rho', C1)
    need(r'the null space is exactly span\{M/rho, \(c/2\) rho\^2\}', C1)
    ka, kb = int(g.group(1)), int(g.group(2))
    def coeffs(k):                                  # f = rho^k: (rho f)' = (k+1) rho^k, (rho f)'' = (k+1) k rho^(k-1)
        rad = 2 * (k + 1); tan = (k + 1) * k; return rad, tan
    F = Fig('birkhoff.svg', 400, 330, 'The Einstein tensor of the radial Kerr–Schild frames f = ρᵏ: radial and tangential coefficients of ρ^(k−2)')
    ks = list(range(ka, kb + 1))
    X, Y = axes(F, 44, 30, 330, 200, (ka - .7, kb + .7), (-5, 13), ks, [-4, 0, 4, 8, 12], 'k (f = ρᵏ)', 'coefficient of ρ^(k−2)')
    for k in ks:
        rad, tan = coeffs(k)
        for off, v, cls, w in ((-9, rad, 's1', 'radial 2(ρf)′/ρ²'), (9, tan, 's2', 'tangential (ρf)″/ρ')):
            y0, y1 = sorted((Y(0), Y(v)))
            if v: F.rect(X(k) + off - 7, y0, 14, y1 - y0, cls, 2, tip='k = %d: %s = %d ρ^(%d)' % (k, w, v, k - 2))
            F.text(X(k) + off, (Y(v) - 4) if v >= 0 else (Y(v) + 12), str(v).replace('-', MINUS), 'tm', 'middle')
    F.text(X(-1), Y(0) - 18, 'M/ρ', 'tb', 'middle'); F.text(X(2), Y(6) - 18, '(c/2)ρ²', 'tb', 'middle')
    F.rect(6, 268, 12, 12, 's1', 2); F.text(22, 278, 'radial: 2(ρf)′/ρ² = 2(k+1)ρ^(k−2)', 't2')
    F.rect(6, 286, 12, 12, 's2', 2); F.text(22, 296, 'tangential: (ρf)″/ρ = k(k+1)ρ^(k−2)', 't2')
    F.para(6, 318, 'k = −1: both 0, the vacuum M/ρ (Schwarzschild); k = 2: both 6, a constant, which the cosmological term 3c absorbs: (c/2)ρ². The log: the null space is exactly span{M/ρ, (c/2)ρ²}.', 't2')
    F.save()

@figure
def fig_cones():
    AC = 'selfcheck/gravity/logs/aty_cone_defects.log'
    s4 = [(Fr(b), Fr(e), Fr(f)) for b, e, f in re.findall(r'beta = (\S+): Euler integral (\S+) \(S\^4, vol [^)]*\) = chi\(S\^4\) - \(1 - beta\) chi\(S\^2\) = \S+;\s+(\S+) \(S\^2 x football\)', log(AC))]
    cpe = [(Fr(b), Fr(v)) for b, v in re.findall(r'beta = (\S+): \(1/32 pi\^2\) int eps R\^R = (\S+) exactly', log(AC))]
    cps = [(Fr(b), Fr(v)) for b, v in re.findall(r'beta = (\S+): \(1/12 pi\^2\) int sum R\^ab R\^ab = (\S+) exactly', log(AC))]
    assert len(s4) == 5 and len(cpe) == 4 == len(cps)
    for b, e, f in s4: assert e == 2 - (1 - b) * 2 and f == 4 - 4 * (1 - b)
    for b, v in cpe: assert v == 3 - (1 - b) * 2
    for b, v in cps: assert v == -1 - Fr(1, 3) * (1 - b * b) * (-1)
    F = Fig('cone_defects.svg', 400, 470, 'The Euler and signature integrals of three families of metrics with an edge cone of angle 2πβ')
    F.text(6, 16, '(a) (1/32π²)∫ε R∧R = χ(M) − (1 − β)χ(Σ)', 'th')
    X, Y = axes(F, 44, 34, 330, 160, (0, 3.2), (0, 13), [0, 1, 2, 3], [0, 4, 8, 12], 'β', '', fx=lambda v: '%g' % v)
    curve(F, X, Y, lambda b: 2 * b, 0, 3.2, 'l1'); curve(F, X, Y, lambda b: 4 * b, 0, 3.2, 'l2'); curve(F, X, Y, lambda b: 1 + 2 * b, 0, 3.2, 'l3')
    for b, e, f in s4:
        F.circ(X(b), Y(e), 4.5, 's1', tip='S⁴, cone along S², β = %s: %s' % (b, e)); F.circ(X(b), Y(f), 4.5, 's2', tip='S² × football, β = %s: %s' % (b, f))
    for b, v in cpe: F.circ(X(b), Y(v), 4.5, 's3', tip='CP², cone along a line, β = %s: %s' % (b, v))
    legend(F, 56, 50, [('l2', 'S² × football: 4β'), ('l3', 'CP²: 1 + 2β'), ('l1', 'S⁴ along S²: 2β')])
    F.text(6, 256, '(b) (1/12π²)∫Σ Rᵃᵇ∧Rᵃᵇ = τ(M) − (1/3)(1 − β²)[Σ]²', 'th')
    X, Y = axes(F, 44, 274, 330, 120, (0, 3.2), (-2.5, 0.5), [0, 1, 2, 3], [-2, -1, 0], 'β', '', fx=lambda v: '%g' % v)
    curve(F, X, Y, lambda b: -(2 + b * b) / 3, 0, 2.6, 'l3'); F.line(X(0), Y(0), X(3.2), Y(0), 'l1')
    cps.sort()
    for b, v in cps:
        F.circ(X(b), Y(v), 4.5, 's3', tip='CP², β = %s: %s' % (b, v))
        if b >= 1: F.text(X(b) + 8, Y(v) + 14, fs(v), 'tm')
    F.para(6, 444, 'CP² in the chart orientation, τ = [CP¹]² = −1: −(2 + β²)/3, exactly %s at β = %s; S⁴ and S² × football: 0. Dots: the exact integrals of aty_cone_defects.log (ATY-020, ATY-021).' % (', '.join(fs(v) for b, v in cps), ', '.join(str(b) for b, v in cps)), 't2')
    F.save()

def main():
    print('figs_phys.py: the package at <REPO> (%d figure functions)' % len(FIGS))
    for fn in FIGS: fn()
    names = sorted(os.listdir(OUT)); print('figs/: %d files' % len(names))
if __name__ == '__main__': main()
