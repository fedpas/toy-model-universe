#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""figs_top.py: draws every figure of figs/ for the tutorial "Topology on the bit rule" from the Atlas's objects.

    python3 -I -B figs_top.py          writes figs/*.svg (deterministic: the same run gives the same bytes) and prints what it computed

The repository is looked for at ../../v3/one-rule beside this folder (or at the path in ATLAS_REPO). What comes from where:
  the rule        checks/selfcheck/steps15_17/bitcliff.py (Alg.blade_mul, Alg.sq): every sign, square, Gauss sum and lattice below;
  the modules     checks/selfcheck/proofs/aty_twisted_k.py: build_cell, restrict, coker, smith, BitModel, pages, MODELS, loaded by name
                  (its checks are not run), with commutant_basis and classify of solid_cube.py, as that check imports them;
  Taub-NUT        checks/selfcheck/gravity/aty_matter_models.py, imported (its checks are not run): tn_frame, engine_eval, weyl_parts;
  the logs        what a figure computes is compared with the shipped log line that records it (an AssertionError stops the run when
                  they differ); the edge-cone integrals are read from logs/aty_cone_defects.log and checked against the two formulas.
Each SVG keeps its text as text, uses the page's ink colours (var(--ink) ...) and the reference categorical palette, light and dark."""
import os, sys, ast, io, re, math, cmath, contextlib, random, itertools
from fractions import Fraction as Fr
from math import gcd, comb

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = os.path.abspath(os.environ.get('ATLAS_REPO') or os.path.join(HERE, '..', '..'))   # the repository: ATLAS_REPO, else two folders up from tools/tutorials/
CH = os.path.join(REPO, 'checks')
SC = os.path.join(CH, 'selfcheck')
for p in (os.path.join(SC, 'steps15_17'), os.path.join(CH, 'researchers_checks'), os.path.join(SC, 'bridges'), SC, os.path.join(SC, 'proofs')):
    sys.path.insert(0, p)
from bitcliff import Alg, sig, pc
import numpy as np

OUT = os.path.join(REPO, 'public', 'reports', 'tutorials', 'src', 'top', 'figs')   # the figures, beside the tutorial's source
os.makedirs(OUT, exist_ok=True)
LOG_TWK = os.path.join(SC, 'proofs', 'logs', 'aty_twisted_k.log')
LOG_MAT = os.path.join(SC, 'gravity', 'logs', 'aty_matter_models.log')
LOG_CONE = os.path.join(SC, 'gravity', 'logs', 'aty_cone_defects.log')
LOG_TOP = os.path.join(SC, 'proofs', 'logs', 'reruns', 'mjg_topology.log')
LOG_CORE = os.path.join(SC, 'proofs', 'logs', 'reruns', 'core_check.log')
BRIDGES = os.path.join(SC, 'bridges', 'bridges_math.json')
SUMMARY = []
def note(s): SUMMARY.append(s)

def logline(path, pattern):
    """the first line of a shipped log that matches the pattern (an AssertionError when none does)"""
    rx = re.compile(pattern)
    with open(path, encoding='utf8') as f:
        for line in f:
            if rx.search(line): return line.rstrip('\n')
    raise AssertionError('no line /%s/ in %s' % (pattern, os.path.basename(path)))

def bridge_text(cid):
    import json
    for r in json.load(open(BRIDGES, encoding='utf8'))['rows']:
        if r['id'] == cid: return r['text']
    raise AssertionError('no stored text for ' + cid)

def load_defs(path, names, ns):
    """exec only the named top-level definitions of a check script into ns (its checks are not run)"""
    tree = ast.parse(open(path, encoding='utf8').read())
    keep, got = [], set()
    for node in tree.body:
        nm = node.name if isinstance(node, (ast.FunctionDef, ast.ClassDef)) else (
            node.targets[0].id if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) else None)
        if nm in names: keep.append(node); got.add(nm)
    assert got == set(names), set(names) - got
    exec(compile(ast.Module(body=keep, type_ignores=[]), path, 'exec'), ns)
    return ns

# ------------------------------------------------------------------------------------------------ SVG helpers
SUB = '₀₁₂₃₄₅₆₇₈₉'
def sub(k): return ''.join(SUB[int(c)] for c in str(k))
M = '−'
def esc(s): return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
def n1(x):
    s = '%.1f' % x
    return '0' if s in ('-0.0', '0.0') else (s[:-2] if s.endswith('.0') else s)
def frs(x):
    x = Fr(x)
    s = str(x.numerator) if x.denominator == 1 else '%d/%d' % (x.numerator, x.denominator)
    return s.replace('-', M)
def blade(a, n, base=1):
    return '1' if a == 0 else 'e' + ''.join(sub(i + base) for i in range(n) if a >> i & 1)

DARK = '--tt-s1:#3987e5;--tt-s2:#d95926;--tt-s3:#199e70;--tt-ng:#e66767;--tt-fp:#1d4f8c;--tt-fn:#7a2b2b;--tt-fz:#383835;--tt-fh:#5c3a1c'
STYLE = ('<style>.tt{--tt-s1:#2a78d6;--tt-s2:#eb6834;--tt-s3:#1baf7a;--tt-ng:#e34948;--tt-fp:#cde2fb;--tt-fn:#f9d2d1;--tt-fz:#f0efec;--tt-fh:#fde3cf}'
         '@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) .tt{' + DARK + '}}:root[data-theme="dark"] .tt{' + DARK + '}'
         '.tt text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;fill:var(--ink,#1a1a19)}'
         '.tt text.t2{fill:var(--ink2,#46463f)}.tt text.mu{fill:var(--muted,#6b6b64)}'
         '.tt .ln{stroke:var(--line2,#c9c8c0);fill:none}.tt .ax{stroke:var(--muted,#6b6b64);fill:none}.tt .k{stroke:var(--ink,#1a1a19);fill:none}'
         '.tt .s1{fill:var(--tt-s1)}.tt .s2{fill:var(--tt-s2)}.tt .s3{fill:var(--tt-s3)}.tt .ng{fill:var(--tt-ng)}'
         '.tt .s1k{stroke:var(--tt-s1);fill:none}.tt .s2k{stroke:var(--tt-s2);fill:none}.tt .s3k{stroke:var(--tt-s3);fill:none}.tt .ngk{stroke:var(--tt-ng);fill:none}'
         '.tt .fp{fill:var(--tt-fp)}.tt .fn{fill:var(--tt-fn)}.tt .fz{fill:var(--tt-fz)}.tt .fh{fill:var(--tt-fh)}.tt .bg{fill:var(--surf,#ffffff)}</style>')

class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.p = w, h, []
    def add(self, s): self.p.append(s)
    def text(self, x, y, s, size=12, anchor='start', cls='', weight=None, tip=None):
        a = ' text-anchor="%s"' % anchor if anchor != 'start' else ''
        c = ' class="%s"' % cls if cls else ''
        wt = ' font-weight="%s"' % weight if weight else ''
        t = '<title>%s</title>' % esc(tip) if tip else ''
        self.add('<text x="%s" y="%s" font-size="%s"%s%s%s>%s%s</text>' % (n1(x), n1(y), size, a, c, wt, t, esc(s)))
    def line(self, x1, y1, x2, y2, cls='ln', w=1, dash=None):
        d = ' stroke-dasharray="%s"' % dash if dash else ''
        self.add('<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s" stroke-width="%s"%s/>' % (n1(x1), n1(y1), n1(x2), n1(y2), cls, w, d))
    def rect(self, x, y, w, h, cls='ln', rx=0, sw=1, tip=None, extra=''):
        r = ' rx="%s"' % rx if rx else ''
        t = '<title>%s</title>' % esc(tip) if tip else ''
        self.add('<rect x="%s" y="%s" width="%s" height="%s" class="%s"%s stroke-width="%s"%s>%s</rect>' % (n1(x), n1(y), n1(w), n1(h), cls, r, sw, extra, t))
    def circle(self, x, y, r, cls='s1', sw=1, tip=None, extra=''):
        t = '<title>%s</title>' % esc(tip) if tip else ''
        self.add('<circle cx="%s" cy="%s" r="%s" class="%s" stroke-width="%s"%s>%s</circle>' % (n1(x), n1(y), n1(r), cls, sw, extra, t))
    def path(self, d, cls='ln', w=1, dash=None, tip=None, extra=''):
        ds = ' stroke-dasharray="%s"' % dash if dash else ''
        t = '<title>%s</title>' % esc(tip) if tip else ''
        self.add('<path d="%s" class="%s" stroke-width="%s"%s%s>%s</path>' % (d, cls, w, ds, extra, t))
    def poly(self, pts, cls='ln', w=1, close=True, dash=None, tip=None):
        d = 'M' + ' L'.join('%s %s' % (n1(x), n1(y)) for x, y in pts) + (' Z' if close else '')
        self.path(d, cls, w, dash, tip)
    def arrow(self, x1, y1, x2, y2, cls='k', w=1.2, head=6, dash=None, mid=False):
        self.line(x1, y1, x2, y2, cls, w, dash)
        ang = math.atan2(y2 - y1, x2 - x1)
        hx, hy = ((x1 + x2) / 2 + head / 2 * math.cos(ang), (y1 + y2) / 2 + head / 2 * math.sin(ang)) if mid else (x2, y2)
        pts = [(hx, hy), (hx - head * math.cos(ang - 0.42), hy - head * math.sin(ang - 0.42)), (hx - head * math.cos(ang + 0.42), hy - head * math.sin(ang + 0.42))]
        fill = cls[:-1] if cls.endswith('k') and cls != 'k' else None
        self.add('<path d="M%s %s L%s %s L%s %s Z"%s/>' % (
            n1(pts[0][0]), n1(pts[0][1]), n1(pts[1][0]), n1(pts[1][1]), n1(pts[2][0]), n1(pts[2][1]), ' class="%s"' % fill if fill else ' style="fill:var(--ink,#1a1a19)"'))
    def marker(self, shape, x, y, cls, tip=None):
        """a data mark with a shape (secondary encoding) and an ink ring"""
        if shape == 'c':
            self.circle(x, y, 5, cls, tip=tip); self.circle(x, y, 5, 'k', 1)
        elif shape == 's':
            self.rect(x - 4.5, y - 4.5, 9, 9, cls, sw=0, tip=tip); self.rect(x - 4.5, y - 4.5, 9, 9, 'k', sw=1)
        else:
            d = 'M%s %s L%s %s L%s %s L%s %s Z' % (n1(x), n1(y - 6.5), n1(x + 6.5), n1(y), n1(x), n1(y + 6.5), n1(x - 6.5), n1(y))
            self.path(d, cls, 0, tip=tip); self.path(d, 'k', 1)
    def save(self, name, title, desc, scale=1.3):
        W, H = round(self.w * scale), round(self.h * scale)
        s = ('<svg xmlns="http://www.w3.org/2000/svg" class="tt" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-labelledby="%s-t %s-d">'
             '<title id="%s-t">%s</title><desc id="%s-d">%s</desc>%s\n%s\n</svg>\n') % (
            self.w, self.h, W, H, name, name, name, esc(title), name, esc(desc), STYLE, '\n'.join(self.p))
        with open(os.path.join(OUT, name + '.svg'), 'w', encoding='utf8', newline='\n') as f: f.write(s)
        kb = len(s.encode('utf8')) / 1024
        assert kb < 80, (name, kb)
        note('%-22s %5.1f kB' % (name + '.svg', kb))

def cell_fill(s): return 'fp' if s > 0 else ('fn' if s < 0 else 'fz')

# ------------------------------------------------------------------------------------------------ the rule's small objects
def wform(alg, a):
    """w = pi + 2Q on a label of a non-degenerate cell: parity plus twice [e_a^2 = -1] (core·B1, core·B2)"""
    return (pc(a) % 2 + (2 if alg.sq(a) == -1 else 0)) % 4
def gauss(p, q, r=0):
    """the clock sum over all 2^n labels, i^(weight), weight 0 on the null bits (core·B3), as an exact Gaussian integer (re, im)"""
    n = p + q + r; D = (1 << (p + q)) - 1; Ad = Alg(sig(p, q)) if p + q else None
    cnt = [0, 0, 0, 0]
    for a in range(1 << n):
        cnt[wform(Ad, a & D) if Ad else 0] += 1
    return (cnt[0] - cnt[2], cnt[1] - cnt[3])
def gi_pow(z, k):
    out = (1, 0)
    for _ in range(k): out = (out[0] * z[0] - out[1] * z[1], out[0] * z[1] + out[1] * z[0])
    return out
def gi_mul(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def brown(z):
    """the argument of a non-zero Gaussian integer on the eight rays, in Z_8"""
    k = round(math.atan2(z[1], z[0]) / (math.pi / 4)) % 8
    return k

# ================================================================================================ F1: one rule, three algebras (n = 2)
def fig_n2():
    S = Svg(360, 536)
    S.text(180, 18, 'n = 2: one rule, three choices of squares', 13, 'middle', weight='600')
    S.text(180, 34, 'row a, column b: the product e_a e_b = s(a, b) e_(a xor b)', 11, 'middle', 'mu')
    cases = [((1, 1), '(+,+)', 'Cl(2,0) ≅ M₂(ℝ)'), ((-1, -1), '(' + M + ',' + M + ')', 'Cl(0,2) ≅ ℍ'), ((0, 0), '(0,0)', 'Cl(0,0,2) = Λ(ℝ²)')]
    y0, cw, ch, x0 = 44, 50, 22, 55
    stats = []
    for eps, lab, name in cases:
        A = Alg(eps); neg = zer = 0
        S.text(x0, y0 + 13, 'squares ' + lab + ':  ' + name, 12.5, weight='600')
        top = y0 + 20
        for j in range(4):
            S.rect(x0 + cw * (j + 1), top, cw, ch, 'fz', sw=0)
            S.text(x0 + cw * (j + 1.5), top + 16, blade(j, 2), 12, 'middle', 't2', weight='600')
            S.rect(x0, top + ch * (j + 1), cw, ch, 'fz', sw=0)
            S.text(x0 + cw / 2, top + ch * (j + 1) + 16, blade(j, 2), 12, 'middle', 't2', weight='600')
        for a in range(4):
            for b in range(4):
                s, c = A.blade_mul(a, b)
                neg += s < 0; zer += s == 0
                x, y = x0 + cw * (b + 1), top + ch * (a + 1)
                S.rect(x + 1, y + 1, cw - 2, ch - 2, cell_fill(s), rx=3, sw=0,
                       tip='%s %s = %s' % (blade(a, 2), blade(b, 2), '0' if s == 0 else ('' if s > 0 else M) + blade(c, 2)))
                S.text(x + cw / 2, y + 16, '0' if s == 0 else ('+' if s > 0 else M) + blade(c, 2), 12, 'middle')
        S.text(x0, top + 5 * ch + 15, '%d of 16 products carry a minus sign, %d vanish' % (neg, zer), 11.5, cls='t2')
        stats.append((lab, neg, zer))
        y0 = top + 5 * ch + 30
    S.text(180, 520, 'blue: +, red: ' + M + ', grey: 0; the same labels and XOR in all three', 11, 'middle', 'mu')
    assert [(n, z) for _, n, z in stats] == [(4, 0), (6, 0), (1, 7)], stats
    S.save('n2_tables', 'The three algebras of the cell row n = 2',
           'Three 4 by 4 sign tables computed with bitcliff.py: squares (+,+) give M2(R), (-,-) the quaternions, (0,0) the exterior algebra; 4, 6 and 1 minus signs, 0, 0 and 7 zeros.', 1.2)
    note('n2 tables: minus signs and zeros %s' % stats)

# ================================================================================================ F2: the discrete space and the Alexandrov space (Top1)
def downsets(n):
    N = 1 << n; cnt = 0
    for D in range(1 << N):
        ok = True
        for T in range(N):
            if D >> T & 1:
                for i in range(n):
                    if T >> i & 1 and not (D >> (T & ~(1 << i)) & 1): ok = False; break
            if not ok: break
        cnt += ok
    return cnt
def fig_alexandrov():
    S = Svg(360, 360)
    S.text(180, 18, 'B₃: the 8 opens of the discrete 3-point space', 13, 'middle', weight='600')
    S.text(180, 34, 'ordered by inclusion; each is a label (the points on)', 11, 'middle', 'mu')
    n = 3
    pos = {0: (180, 232), 1: (90, 172), 2: (180, 172), 4: (270, 172), 3: (90, 112), 5: (180, 112), 6: (270, 112), 7: (180, 52)}
    D = {0, 1, 2, 3, 4}          # the down-set generated by e12 and e3
    for T in range(8):
        for i in range(n):
            if T >> i & 1:
                (x1, y1), (x2, y2) = pos[T & ~(1 << i)], pos[T]
                both = (T in D) and (T & ~(1 << i)) in D
                S.line(x1, y1, x2, y2, 's1k' if both else 'ln', 2 if both else 1.2)
    for T, (x, y) in pos.items():
        S.circle(x, y, 17, 'fh' if T in D else 'bg', tip='label %s = the open set {%s}' % (blade(T, 3), ', '.join(str(i + 1) for i in range(3) if T >> i & 1)))
        S.circle(x, y, 17, 'k', 1)
        S.text(x, y + 4.5, blade(T, 3), 12, 'middle')
    S.text(300, 245, 'shaded: one open of', 11, 'middle', 't2')
    S.text(300, 259, 'the Alexandrov space', 11, 'middle', 't2')
    S.text(300, 273, '(a down-set)', 11, 'middle', 't2')
    rows = [('n', [0, 1, 2, 3, 4]), ('opens of the n points (labels) 2ⁿ', [1 << k for k in range(5)]),
            ('pairs with a ⊕ b defined, 3ⁿ', [sum(1 for a in range(1 << k) for b in range(1 << k) if a & b == 0) for k in range(5)]),
            ('opens of the Alexandrov space Bₙ', [downsets(k) for k in range(5)])]
    assert rows[3][1] == [2, 3, 6, 20, 168]
    assert '{0: 2, 1: 3, 2: 6, 3: 20, 4: 168}' in bridge_text('bd·mjc·25')
    assert '{0: 1, 1: 3, 2: 9, 3: 27, 4: 81' in bridge_text('bd·mjc·1')
    y = 292
    for k, (lab, vals) in enumerate(rows):
        S.text(8, y + 14 * k, lab, 11, cls='t2' if k else 'mu', weight='600' if k == 0 else None)
        for j, v in enumerate(vals):
            S.text(232 + 28 * j, y + 14 * k, str(v), 11.5, 'end' if False else 'middle', '' if k else 'mu', weight='600' if k == 0 else None)
    S.save('alexandrov', 'The opens of the n-point discrete space and of the Alexandrov space',
           'The Hasse diagram of B3 with one down-set shaded, and a table: 2^n labels, 3^n defined disjoint sums, 2, 3, 6, 20, 168 Alexandrov opens, counted by figs_top.py.', 1.25)
    note('Alexandrov opens 2, 3, 6, 20, 168 (= bd·mjc·25)')

# ================================================================================================ F3: the cube as a complex (Top2)
def rank_q(rows):
    """exact rank over Q of a list of integer rows (dicts col -> value)"""
    piv = {}
    rk = 0
    for r in rows:
        r = {k: Fr(v) for k, v in r.items() if v}
        while r:
            c = min(r)
            if c in piv:
                pr = piv[c]; f = r[c] / pr[c]
                for k, v in pr.items():
                    r[k] = r.get(k, 0) - f * v
                    if r[k] == 0: del r[k]
            else:
                piv[c] = r; rk += 1; break
    return rk
def rank_f2(rows):
    basis = {}
    rk = 0
    for r in rows:
        v = 0
        for k, x in r.items():
            if x % 2: v |= 1 << k
        while v:
            h = v.bit_length() - 1
            if h in basis: v ^= basis[h]
            else: basis[h] = v; rk += 1; break
    return rk
def cube_complex(n, drop_top=False, signed=True):
    """cells = arrows S -> T of B_n, dimension |T \\ S|; boundary with the bit-rule sign s({i}, T\\S\\{i}) (bd·mjg·24)"""
    A = Alg((1,) * n) if n else None
    cells = [[(S_, T) for T in range(1 << n) for S_ in range(1 << n) if S_ & ~T == 0 and pc(T & ~S_) == k] for k in range(n + 1)]
    if drop_top: cells[n] = [c for c in cells[n] if c != (0, (1 << n) - 1)]
    idx = [{c: i for i, c in enumerate(L)} for L in cells]
    bd = [[]]
    for k in range(1, n + 1):
        cols = []
        for S_, T in cells[k]:
            Af = T & ~S_; col = {}
            for i in range(n):
                if Af >> i & 1:
                    s = A.blade_mul(1 << i, Af & ~(1 << i))[0] if signed else 1
                    for c, sg in (((S_ | 1 << i, T), 1), ((S_, T & ~(1 << i)), -1)):
                        r = idx[k - 1][c]; col[r] = col.get(r, 0) + s * sg
            cols.append(col)
        bd.append(cols)
    sizes = [len(L) for L in cells]
    rq = [0] + [rank_q(bd[k]) for k in range(1, n + 1)] + [0]
    r2 = [0] + [rank_f2(bd[k]) for k in range(1, n + 1)] + [0]
    bq = [sizes[k] - rq[k] - rq[k + 1] for k in range(n + 1)]
    b2 = [sizes[k] - r2[k] - r2[k + 1] for k in range(n + 1)]
    d2 = True
    for k in range(2, n + 1):
        for col in bd[k]:
            acc = {}
            for r, v in col.items():
                for rr, vv in bd[k - 1][r].items(): acc[rr] = acc.get(rr, 0) + v * vv
            d2 &= all(v == 0 for v in acc.values())
    return sizes, bq, b2, d2
def cube_pos(T, n, ox, oy, L):
    v = [(L, 0), (0.42 * L, -0.34 * L), (0, -L)] if n == 3 else [(L, 0), (0, -L)]
    x, y = ox, oy
    for i in range(n):
        if T >> i & 1: x += v[i][0]; y += v[i][1]
    return x, y
def draw_cube(S, n, ox, oy, L, labels=True, diag=True, r=11, fs=11):
    for T in range(1 << n):
        for i in range(n):
            if T >> i & 1:
                (x1, y1), (x2, y2) = cube_pos(T & ~(1 << i), n, ox, oy, L), cube_pos(T, n, ox, oy, L)
                S.line(x1, y1, x2, y2, 'k', 1.3)
    if diag and n >= 2:
        (x1, y1), (x2, y2) = cube_pos(0, n, ox, oy, L), cube_pos((1 << n) - 1, n, ox, oy, L)
        S.line(x1, y1, x2, y2, 's2k', 1.6, dash='4 3')
    if labels:
        for T in range(1 << n):
            x, y = cube_pos(T, n, ox, oy, L)
            S.circle(x, y, r, 'bg'); S.circle(x, y, r, 'k', 1)
            S.text(x, y + 4, blade(T, n), fs, 'middle')
def fig_cube_complex():
    S = Svg(360, 484)
    S.text(180, 18, 'The n-cube as a complex: cells are the arrows S ⊆ T', 13, 'middle', weight='600')
    S.text(180, 34, 'dashed: the diagonal 1 → top, shared by the n! simplices of the nerve', 11, 'middle', 'mu')
    # n = 1 segment
    x1, y1 = 22, 150
    S.line(x1, y1, x1 + 52, y1, 'k', 1.3)
    for T, x in ((0, x1), (1, x1 + 52)):
        S.circle(x, y1, 11, 'bg'); S.circle(x, y1, 11, 'k', 1); S.text(x, y1 + 4, blade(T, 1), 11, 'middle')
    S.text(48, 184, 'n = 1', 12, 'middle', weight='600')
    draw_cube(S, 2, 104, 160, 72)
    S.text(140, 184, 'n = 2', 12, 'middle', weight='600')
    draw_cube(S, 3, 214, 166, 86, fs=10.5, r=12)
    S.text(275, 196, 'n = 3', 12, 'middle', weight='600')
    # the table of chain ranks, computed with the bit-rule boundary
    top = 222
    S.text(8, top, 'chain ranks f_k (cells of dimension k), from the arrows', 12, weight='600')
    S.text(8, top + 16, 'n', 11, cls='mu', weight='600'); S.text(30, top + 16, 'f₀  f₁  f₂ …', 11, cls='mu', weight='600')
    S.text(205, top + 16, '3ⁿ', 11, 'middle', 'mu', weight='600'); S.text(236, top + 16, 'χ', 11, 'middle', 'mu', weight='600')
    S.text(258, top + 16, 'Betti (ℚ, mod 2)', 11, cls='mu', weight='600')
    logtxt = open(LOG_TOP, encoding='utf8').read()
    unsigned_fails = []
    for n in range(1, 6):
        sizes, bq, b2, d2 = cube_complex(n)
        _, bqs, b2s, _ = cube_complex(n, drop_top=True)
        chi = sum((-1) ** k * f for k, f in enumerate(sizes))
        assert d2 and chi == 1 and sum(sizes) == 3 ** n and bq == b2 == [1] + [0] * n
        assert ('n=%d: d^2 = 0 True, cube Betti %s, boundary Betti %s' % (n, bq, bqs)) in logtxt, n
        assert sizes == [comb(n, k) * 2 ** (n - k) for k in range(n + 1)]
        y = top + 16 + 17 * n
        S.text(8, y, str(n), 11.5)
        S.text(30, y, '  '.join(str(f) for f in sizes), 11.5)
        S.text(205, y, str(sum(sizes)), 11.5, 'middle'); S.text(236, y, str(chi), 11.5, 'middle')
        S.text(258, y, ' '.join(str(b) for b in bq), 11.5)
        if n >= 2: unsigned_fails.append(not cube_complex(n, signed=False)[3])
    assert all(unsigned_fails)
    y = top + 16 + 17 * 6 + 6
    S.text(8, y, 'without the top cell (the boundary of the cube):', 11.5, cls='t2')
    for n in range(2, 6):
        _, bqs, _, _ = cube_complex(n, drop_top=True)
        S.text(8 + 88 * (n - 2), y + 16, 'n=%d: %s' % (n, ' '.join(str(b) for b in bqs)), 11.5)
    S.text(8, y + 36, 'Betti 1, 0, …, 0, 1: the sphere S^(n' + M + '1). With the sign', 11.5, cls='t2')
    S.text(8, y + 51, 'dropped, d² ≠ 0 for every n ≥ 2: the sign is the orientation.', 11.5, cls='t2')
    nerve = [math.factorial(n) for n in range(1, 6)]
    S.text(8, y + 70, 'nerve of Bₙ: %s maximal simplices (n = 1 … 5)' % ', '.join(map(str, nerve)), 11.5, cls='t2')
    assert '24 simplices' in logline(LOG_TOP, r'bd·mjg·22') and '120 simplices' in logline(LOG_TOP, r'bd·mjg·22')
    S.save('cube_complex', 'The n-cube complexes for n = 1, 2, 3 and their chain ranks',
           'The segment, the square and the cube with labels at the vertices; a table of the chain ranks C(n,k)2^(n-k), 3^n cells, Euler characteristic 1, Betti numbers of a point; the boundary is a sphere.', 1.25)
    note('cube complex: chain ranks, chi = 1, Betti of a point and of S^(n-1), as bd·mjg·24 logs')

# ================================================================================================ F4: the sign as a cochain on the cube (Top3)
def fig_sign_cochain():
    S = Svg(360, 372)
    S.text(180, 18, 'The bit-rule sign on the edges of B₃', 13, 'middle', weight='600')
    S.text(180, 34, 'c(S → S+i) = s(S, {i}), the sign of e_S e_i = c e_(S+i)', 11, 'middle', 'mu')
    n = 3; A = Alg((1, 1, 1)); ox, oy, L = 95, 250, 150
    def c(S_, i): return A.blade_mul(S_, 1 << i)[0]
    for T in range(8):
        for i in range(n):
            if T >> i & 1:
                S0 = T & ~(1 << i); s = c(S0, i)
                (x1, y1), (x2, y2) = cube_pos(S0, n, ox, oy, L), cube_pos(T, n, ox, oy, L)
                S.line(x1, y1, x2, y2, 's1k' if s > 0 else 'ngk', 2.2 if s > 0 else 2, dash=None if s > 0 else '5 3')
                mx, my = (x1 + x2) / 2, (y1 + y2) / 2
                S.circle(mx, my, 8, 'bg')
                S.text(mx, my + 4.5, '+' if s > 0 else M, 13, 'middle', weight='700', tip='c(%s → %s) = %+d' % (blade(S0, 3), blade(T, 3), s))
    for T in range(8):
        x, y = cube_pos(T, n, ox, oy, L)
        S.circle(x, y, 13, 'bg'); S.circle(x, y, 13, 'k', 1); S.text(x, y + 4, blade(T, 3), 11, 'middle')
    # the six squares and their fluxes
    faces = []
    for S0 in range(8):
        for i, j in ((0, 1), (0, 2), (1, 2)):
            if not (S0 >> i & 1) and not (S0 >> j & 1):
                fl = c(S0, i) * c(S0 | 1 << i, j) * c(S0, j) * c(S0 | 1 << j, i)
                faces.append((S0, i, j, fl))
    assert len(faces) == 6 and all(f == -1 for *_, f in faces)
    y = 302
    S.text(180, y - 6, 'the product of the four signs around each of the 6 squares', 11.5, 'middle', 't2')
    for k, (S0, i, j, fl) in enumerate(faces):
        x = 12 + 57 * k
        S.rect(x, y + 4, 44, 34, 'fz', rx=4, sw=0, tip='square at %s in the directions %d, %d: flux %d' % (blade(S0, 3), i + 1, j + 1, fl))
        S.text(x + 22, y + 26, M + '1', 14, 'middle', weight='700')
        S.text(x + 22, y + 52, '%s→%s' % (blade(S0, 3), blade(S0 | 1 << i | 1 << j, 3)), 10.5, 'middle', 'mu')
    S.save('sign_cochain', 'The bit-rule sign as a cochain on the cube B3',
           'The cube B3 with each edge marked by the sign s(S,{i}) of the bit rule, minus edges dashed, and the six squares, each with flux -1: every square anticommutes.', 1.25)
    note('B3: 12 edge signs, all 6 square fluxes -1')

# ================================================================================================ F5: RP^2, the connected sum, the polygon words (Top4)
def polygon_homology(word):
    """cellular chain complex of the polygon with edge word [(letter, +-1)]: vertices by identification, C2 -> C1 -> C0"""
    m = len(word); parent = list(range(m))
    def find(x):
        while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    tails, heads = {}, {}
    for k, (x, e) in enumerate(word):
        t, h = (k, (k + 1) % m) if e > 0 else ((k + 1) % m, k)
        for d, v in ((tails, t), (heads, h)):
            if x in d: parent[find(v)] = find(d[x])
            else: d[x] = v
    verts = sorted({find(v) for v in range(m)}); letters = sorted({x for x, _ in word})
    d2 = {letters.index(x): 0 for x in letters}
    for x, e in word: d2[letters.index(x)] += e
    d1 = [{verts.index(find(heads[x])): 1, verts.index(find(tails[x])): -1} if find(heads[x]) != find(tails[x]) else {} for x in letters]
    d1 = [{k: v for k, v in c.items()} for c in d1]
    sizes = [len(verts), len(letters), 1]
    rq1, rq2 = rank_q(d1), rank_q([d2]); r21, r22 = rank_f2(d1), rank_f2([d2])
    bq = [sizes[0] - rq1, sizes[1] - rq1 - rq2, sizes[2] - rq2]
    b2 = [sizes[0] - r21, sizes[1] - r21 - r22, sizes[2] - r22]
    tors = gcd(*[abs(v) for v in d2.values()]) if any(d2.values()) else 0
    return sizes, bq, b2, tors
def draw_polygon(S, cx, cy, R, word, names, start_angle):
    m = len(word)
    P = [(cx + R * math.cos(start_angle + 2 * math.pi * k / m), cy + R * math.sin(start_angle + 2 * math.pi * k / m)) for k in range(m)]
    S.poly(P, 'fh', 0)
    for k, (x, e) in enumerate(word):
        a, b = P[k], P[(k + 1) % m]
        if e < 0: a, b = b, a
        cls = ['s1k', 's2k', 's3k'][names.index(x) % 3]
        S.arrow(a[0], a[1], b[0], b[1], cls, 2.2, head=8, mid=True)
        mx, my = (P[k][0] + P[(k + 1) % m][0]) / 2, (P[k][1] + P[(k + 1) % m][1]) / 2
        dx, dy = mx - cx, my - cy; d = math.hypot(dx, dy)
        S.text(mx + 13 * dx / d, my + 13 * dy / d + 4, x, 12, 'middle', weight='600')
    for x, y in P:
        S.circle(x, y, 3, 'k', 1.2)
def fig_polygons():
    S = Svg(360, 330)
    S.text(180, 18, 'ℝP² and connected sums as polygons', 13, 'middle', weight='600')
    S.text(180, 34, 'equal letters are glued along the arrows', 11, 'middle', 'mu')
    cases = [('ℝP²', [('a', 1), ('b', 1), ('a', 1), ('b', 1)], ['a', 'b'], 1, 'abab'),
             ('ℝP² # ℝP²', [('a₁', 1), ('a₁', 1), ('a₂', 1), ('a₂', 1)], ['a₁', 'a₂'], 2, 'a₁a₁a₂a₂'),
             ('#³ℝP²', [('a₁', 1), ('a₁', 1), ('a₂', 1), ('a₂', 1), ('a₃', 1), ('a₃', 1)], ['a₁', 'a₂', 'a₃'], 3, 'a₁a₁a₂a₂a₃a₃')]
    res = []
    for k, (title, word, names, n, wtxt) in enumerate(cases):
        cx = 62 + 118 * k
        draw_polygon(S, cx, 108, 42, word, names, math.pi / 4 + (math.pi / 2 if len(word) == 4 else math.pi / 6))
        S.text(cx, 178, title, 12.5, 'middle', weight='600')
        S.text(cx, 193, wtxt, 11, 'middle', 'mu')
        sizes, bq, b2, tors = polygon_homology(word)
        chi = sizes[0] - sizes[1] + sizes[2]
        res.append((n, sizes, bq, b2, tors, chi))
        S.text(cx, 214, 'cells %d, %d, %d' % tuple(sizes), 11, 'middle', 't2')
        S.text(cx, 230, 'mod-2 Betti %d, %d, %d' % tuple(b2), 11, 'middle')
        S.text(cx, 246, 'ℚ-Betti %d, %d, %d' % tuple(bq), 11, 'middle')
        S.text(cx, 262, 'χ = %s' % frs(chi), 11, 'middle')
        S.text(cx, 278, 'H₁(ℤ) = %s' % (('ℤ%s ⊕ ' % ('' if bq[1] == 1 else '²³⁴⁵⁶⁷'[bq[1] - 2])) if bq[1] else '') + 'ℤ/%d' % tors, 11, 'middle')
    for n_ in range(1, 9):
        word = [(x, 1) for i in range(n_) for x in ('a%d' % i, 'a%d' % i)]
        sizes, bq, b2, tors = polygon_homology(word)
        assert b2 == [1, n_, 1] and bq == [1, n_ - 1, 0] and tors == 2 and sizes[0] - sizes[1] + sizes[2] == 2 - n_
    S.text(180, 302, 'the polygon a₁a₁ … aₙaₙ, n = 1 … 8: mod-2 Betti 1, n, 1, χ = 2 ' + M + ' n', 11, 'middle', 't2')
    S.text(180, 318, 'a crosscap per pair; the labels of n switches are H₁(#ⁿℝP²; ℤ₂)', 11, 'middle', 't2')
    S.save('polygons', 'RP2, the Klein bottle and #3RP2 as polygons with identifications',
           'Three polygons with their edge words abab, a1a1a2a2 and a1a1a2a2a3a3, and their cellular homology computed by figs_top.py: F2-Betti 1, n, 1, Euler characteristic 2 - n.', 1.25)
    note('polygons: F2-Betti (1,n,1), chi = 2-n, torsion Z/2 for n = 1..8')

# ================================================================================================ F6: which reflections square to +1 or -1 (Top5)
def fig_pin_table():
    S = Svg(360, 376)
    S.text(180, 18, 'Squares of the blades: reflections, half-turns, volume', 13, 'middle', weight='600')
    S.text(180, 34, 'e_i lifts the reflection in e_i (x ↦ ' + M + 'e_i x e_i⁻¹); its square is ε_i', 11, 'middle', 'mu')
    cols = [1, 2, 4, 3, 5, 6, 7]
    x0, cw, ch, top = 62, 34, 22, 80
    for j, a in enumerate(cols):
        S.text(x0 + cw * (j + 0.5), top - 6, blade(a, 3), 11.5, 'middle', 't2', weight='600')
    S.text(x0 + cw * 1.5, top - 22, 'grade 1', 11, 'middle', 'mu'); S.text(x0 + cw * 4.5, top - 22, 'grade 2', 11, 'middle', 'mu'); S.text(x0 + cw * 6.5, top - 22, '3', 11, 'middle', 'mu')
    S.text(x0 + cw * 7 + 8, top - 6, 'Pin', 11.5, cls='t2', weight='600')
    cells = [(1, 0), (0, 1), (2, 0), (1, 1), (0, 2), (3, 0), (2, 1), (1, 2), (0, 3)]
    y = top; flips = True
    for k, (p, q) in enumerate(cells):
        if k in (2, 5): y += 8
        n = p + q; A = Alg(sig(p, q)); B = Alg(tuple(-e for e in sig(p, q)))          # the mirror: every square negated
        S.text(x0 - 8, y + 15, 'Cl(%d,%d)' % (p, q), 11.5, 'end')
        for j, a in enumerate(cols):
            if a >> n: continue
            s = A.sq(a)
            flips &= (B.sq(a) == (s if pc(a) % 2 == 0 else -s))
            S.rect(x0 + cw * j + 1, y + 1, cw - 2, ch - 2, cell_fill(s), rx=3, sw=0, tip='(%s)² = %+d in Cl(%d,%d)' % (blade(a, 3), s, p, q))
            S.text(x0 + cw * (j + 0.5), y + 15.5, ('+1' if s > 0 else M + '1'), 11.5, 'middle')
        refl = {A.sq(1 << i) for i in range(n)}
        S.text(x0 + cw * 7 + 8, y + 15.5, 'Pin⁺(%d)' % n if refl == {1} else ('Pin⁻(%d)' % n if refl == {-1} else 'Pin(%d,%d)' % (p, q)), 11.5)
        y += ch
    assert flips
    S.text(8, y + 22, 'Each cell sits beside its mirror (p,q) ↔ (q,p): the odd grades', 11.5, cls='t2')
    S.text(8, y + 38, 'change sign, the even grades keep it (checked on these 9 cells).', 11.5, cls='t2')
    S.text(8, y + 56, 'Pin⁺ when every reflection squares to +1, Pin⁻ when to ' + M + '1', 11.5, cls='t2')
    S.text(8, y + 72, '(the Kirby–Taylor convention; recalled).', 11.5, cls='t2')
    S.save('pin_table', 'Which reflections square to +1 and which to -1',
           'The squares of the blades of grade 1, 2 and 3 for the nine cells with n at most 3, computed with bitcliff.py; Cl(n,0) has reflections of square +1 (Pin+), Cl(0,n) of square -1 (Pin-); the mirror flips the odd grades.', 1.25)
    note('pin table: mirror flips odd grades, keeps even (9 cells)')

# ================================================================================================ F7: the Pin- structures of RP^2 and of the Klein bottle (Top6)
def fig_enhancements():
    S = Svg(360, 312)
    S.text(180, 18, 'Pin⁻ structures as ℤ₄-forms w = π + 2Q', 13, 'middle', weight='600')
    S.text(180, 34, 'w on the classes of H₁(#ⁿℝP²; ℤ₂), one row per choice of squares', 11, 'middle', 'mu')
    x0 = 10
    heads1 = ['squares', '0', 'a₁', 'Σ i^w', 'β']
    xs1 = [x0, 120, 160, 230, 300]
    y = 64
    S.text(x0, y - 8, 'n = 1, ℝP²', 12, weight='600')
    for h, x in zip(heads1, xs1): S.text(x, y + 8, h, 11, 'start' if x == x0 else 'middle', 'mu', weight='600')
    y += 12
    rows_n1 = []
    for e in (1, -1):
        A = Alg((e,)); w = [wform(A, a) for a in range(2)]; G = gauss(1 if e > 0 else 0, 0 if e > 0 else 1)
        rows_n1.append((e, w, G, brown(G)))
        S.text(x0, y + 15, '(%s)  Cl(%d,%d)' % ('+' if e > 0 else M, 1 if e > 0 else 0, 0 if e > 0 else 1), 11.5)
        for k in range(2):
            S.rect(xs1[1 + k] - 15, y + 2, 30, 18, 'fh' if w[k] % 2 else 'fz', rx=3, sw=0)
            S.text(xs1[1 + k], y + 15, str(w[k]), 11.5, 'middle')
        S.text(xs1[3], y + 15, gi_str(G), 11.5, 'middle'); S.text(xs1[4], y + 15, str(brown(G)), 11.5, 'middle', weight='600')
        y += 22
    y += 18
    S.text(x0, y - 8, 'n = 2, ℝP² # ℝP² (the Klein bottle)', 12, weight='600')
    heads2 = ['squares', '0', 'a₁', 'a₂', 'a₁+a₂', 'Σ i^w', 'β']
    xs2 = [x0, 104, 136, 168, 210, 262, 312]
    for h, x in zip(heads2, xs2): S.text(x, y + 8, h, 11, 'start' if x == x0 else 'middle', 'mu', weight='600')
    y += 12
    ok = True; betas2 = []
    for eps in ((1, 1), (1, -1), (-1, 1), (-1, -1)):
        A = Alg(eps); w = [wform(A, a) for a in range(4)]
        ok &= all((w[a ^ b] - w[a] - w[b] - 2 * pc(a & b)) % 4 == 0 for a in range(4) for b in range(4))
        cnt = [0] * 4
        for a in range(4): cnt[w[a]] += 1
        G = (cnt[0] - cnt[2], cnt[1] - cnt[3]); betas2.append(brown(G))
        S.text(x0, y + 15, '(%s,%s)' % tuple('+' if e > 0 else M for e in eps), 11.5)
        for k in range(4):
            S.rect(xs2[1 + k] - 14, y + 2, 28, 18, 'fh' if w[k] % 2 else 'fz', rx=3, sw=0, tip='w(%s) = %d' % (['0', 'a1', 'a2', 'a1+a2'][k], w[k]))
            S.text(xs2[1 + k], y + 15, str(w[k]), 11.5, 'middle')
        S.text(xs2[5], y + 15, gi_str(G), 11.5, 'middle'); S.text(xs2[6], y + 15, str(brown(G)), 11.5, 'middle', weight='600')
        y += 22
    assert ok and betas2 == [2, 0, 0, 6] and [r[3] for r in rows_n1] == [1, 7]
    b3 = sorted({brown(gauss(p, 3 - p)) for p in range(4)})
    assert b3 == [1, 3, 5, 7]
    assert '(1, 2, [1, 7]), (2, 3, [0, 2, 6]), (3, 4, [1, 3, 5, 7])' in bridge_text('bd·geo·3')
    y += 12
    S.text(x0, y, 'In every row w(x + y) = w(x) + w(y) + 2 x·y mod 4.', 11, cls='t2')
    S.text(x0, y + 15, 'Shaded: the odd values, where π = w mod 2 = x·x is 1.', 11, cls='t2')
    S.text(x0, y + 30, 'n = 3: 8 structures with β = 1, 3, 5, 7.', 11, cls='t2')
    S.save('enhancements', 'The Pin- structures of RP2 and of the Klein bottle as Z4-forms',
           'Tables of w = pi + 2Q on H1 for n = 1 (two rows) and n = 2 (four rows), computed with bitcliff.py, with the Gauss sums and Brown invariants 1, 7 and 2, 0, 0, 6.', 1.25)
    note('enhancements: n=1 beta 1,7; n=2 beta 2,0,0,6; n=3 values 1,3,5,7')
def gi_str(z):
    a, b = z
    if b == 0: return frs(a)
    if a == 0: return ('' if b > 0 else M) + ('' if abs(b) == 1 else str(abs(b))) + 'i'
    return '%s %s %si' % (frs(a), '+' if b > 0 else M, '' if abs(b) == 1 else str(abs(b)))

# ================================================================================================ F8: the Brown invariant on the clock (Top7)
def fig_brown_clock():
    S = Svg(360, 410)
    S.text(180, 18, 'The cells on the clock: the Brown invariant β', 13, 'middle', weight='600')
    S.text(180, 34, 'ring n = p + q (n = 1 … 5); position β = arg(Σ i^w) / 45°', 11, 'middle', 'mu')
    cx, cy = 180, 208
    for n in range(1, 6):
        S.circle(cx, cy, 26 * n + 8, 'ln', 1, extra=' fill="none"')
    for k in range(8):
        ang = -math.pi / 2 + k * math.pi / 4
        S.line(cx + 16 * math.cos(ang), cy + 16 * math.sin(ang), cx + 148 * math.cos(ang), cy + 148 * math.sin(ang), 'ln', 0.8)
        S.text(cx + 156 * math.cos(ang), cy + 156 * math.sin(ang) + 4.5, str(k), 13, 'middle', weight='700')
    placed = {}
    for n in range(1, 6):
        for p in range(n, -1, -1):
            q = n - p; G = gauss(p, q); b = brown(G)
            assert b == (p - q) % 8 and G == gi_mul(gi_pow((1, 1), p), gi_pow((1, -1), q))
            placed.setdefault((n, b), []).append((p, q))
    for (n, b), lst in placed.items():
        ang = -math.pi / 2 + b * math.pi / 4; R = 26 * n + 8
        x, y = cx + R * math.cos(ang), cy + R * math.sin(ang)
        cls = 's1' if len(lst) == 1 else 's2'
        S.circle(x, y, 9 if len(lst) == 1 else 11, cls, tip='; '.join('Cl(%d,%d): beta = %d' % (p, q, b) for p, q in lst))
        S.circle(x, y, 9 if len(lst) == 1 else 11, 'k', 0.8)
    for (n, b), lst in placed.items():
        if n not in (1, 4, 5): continue
        ang = -math.pi / 2 + b * math.pi / 4; R = 26 * n + 8
        x, y = cx + R * math.cos(ang), cy + R * math.sin(ang)
        lab = ' '.join('%d,%d' % pq for pq in lst)
        off = 15 if math.cos(ang) >= -0.01 else -15
        if n == 1:
            S.text(x + off * 0.9, y - 9, lab, 11, 'start' if off > 0 else 'end', weight='600')
        elif len(lst) > 1:
            S.text(x + off, y + 4, lab, 11, 'start' if off > 0 else 'end', weight='600')
    S.text(8, 390, 'Cl(1,0) at 1 and Cl(0,1) at 7: ℝP² with its two Pin⁻ structures.', 11.5, cls='t2')
    S.text(8, 404, 'Orange: two cells with the same n and β, e.g. (4,0) and (0,4).', 11.5, cls='t2')
    S.save('brown_clock', 'The Brown invariant of every cell with n at most 5 on the clock',
           'A clock of eight positions with the cells Cl(p,q), n = 1 to 5, placed on ring n at the argument of their Gauss sum, which is p - q mod 8; cells with the same n and clock share a dot.', 1.2)
    note('brown clock: 20 cells, beta = p - q mod 8 from the Gauss sum')

# ================================================================================================ F9: the Gauss sums in the complex plane (Top7)
def fig_gauss_phases():
    S = Svg(360, 410)
    S.text(180, 18, 'The Gauss sum as a walk: one factor 1 + i^ε per switch', 13, 'middle', weight='600')
    S.text(180, 34, 'Σ_a i^w(a) = (1 + i)^p (1 ' + M + ' i)^q: each + switch turns', 11, 'middle', 'mu')
    S.text(180, 48, 'the hand by +45°, each ' + M + ' switch by ' + M + '45°, and scales by √2', 11, 'middle', 'mu')
    cx, cy, u = 180, 222, 19
    for n in range(0, 7):
        S.circle(cx, cy, u * 2 ** (n / 2), 'ln', 0.7, extra=' fill="none"')
    S.line(cx - 165, cy, cx + 165, cy, 'ax', 0.8); S.line(cx, cy - 165, cx, cy + 165, 'ax', 0.8)
    S.text(cx + 166, cy - 5, 'Re', 11, 'end', 'mu'); S.text(cx + 5, cy - 156, 'Im', 11, cls='mu')
    pts = {}
    for n in range(0, 7):
        for p in range(n, -1, -1):
            G = gauss(p, n - p)
            assert G == gi_mul(gi_pow((1, 1), p), gi_pow((1, -1), n - p))
            pts.setdefault(G, []).append((p, n - p))
    for G, lst in sorted(pts.items()):
        S.circle(cx + u * G[0], cy - u * G[1], 4, 'fp', tip='%s: %s' % ('; '.join('Cl(%d,%d)' % pq for pq in lst), gi_str(G)))
        S.circle(cx + u * G[0], cy - u * G[1], 4, 'ln', 1)
    walks = [((1, 1, 1, 1), 's1', 'Cl(4,0): ' + M + '4', -2.2), ((-1, -1, -1, -1), 's2', 'Cl(0,4): ' + M + '4', 2.2), ((1, -1, 1, -1), 's3', 'Cl(2,2): 4', 2.2)]
    ends = {}
    for eps, cls, lab, off in walks:
        z = (1, 0); path = [z]
        for e in eps:
            z = gi_mul(z, (1, e)); path.append(z)
        p = sum(1 for e in eps if e > 0)
        assert z == gauss(p, len(eps) - p)
        for a, b in zip(path, path[1:]):
            x1, y1, x2, y2 = cx + u * a[0], cy - u * a[1], cx + u * b[0], cy - u * b[1]
            L = math.hypot(x2 - x1, y2 - y1); ox, oy = -off * (y2 - y1) / L, off * (x2 - x1) / L
            S.arrow(x1 + ox, y1 + oy, x2 + ox, y2 + oy, cls + 'k', 2.2, head=8)
        ends[lab] = z
    S.circle(cx + u, cy, 4.5, 'k', 1.5)
    S.text(cx + u + 6, cy + 16, 'start: 1', 11, weight='600')
    S.text(cx + u * -4 - 8, cy - 22, 'Cl(4,0): ' + M + '4', 11.5, 'end', weight='600')
    S.text(cx + u * -4 - 8, cy + 30, 'Cl(0,4): ' + M + '4', 11.5, 'end', weight='600')
    S.text(cx + u * 4 + 6, cy - 10, 'Cl(2,2): 4', 11.5, weight='600')
    S.text(8, 400, 'Dots: all 28 cells with n ≤ 6 (circles |z| = 2^(n/2)); |Σ|² = 2ⁿ.', 11.5, cls='t2')
    assert ends == {'Cl(4,0): ' + M + '4': (-4, 0), 'Cl(0,4): ' + M + '4': (-4, 0), 'Cl(2,2): 4': (4, 0)}
    assert (8, 0) in pts and (3, 3) in pts[(8, 0)] and pts[(-4, 0)] == [(4, 0), (0, 4)]
    S.save('gauss_phases', 'The Gauss sum of a cell as a walk in the complex plane',
           'The values (1+i)^p (1-i)^q of the 28 cells with n at most 6 as dots on circles of radius 2^(n/2), and three walks of four steps, one per generator: Cl(4,0) and Cl(0,4) to -4 by opposite turns, Cl(2,2) to 4; computed with the squares of bitcliff.py.', 1.2)
    note('gauss walk: %d distinct values for 28 cells' % len(pts))

# ================================================================================================ the modules of aty_twisted_k.py (F10, F11)
def load_twk():
    with contextlib.redirect_stdout(io.StringIO()):
        argv = sys.argv; sys.argv = [argv[0]]
        try:
            from solid_cube import commutant_basis, classify
        finally:
            sys.argv = argv
    ns = {'gcd': gcd, 'Fr': Fr, 'random': random, 'np': np, 'Alg': Alg, 'sig': sig, 'commutant_basis': commutant_basis, 'classify': classify}
    return load_defs(os.path.join(SC, 'proofs', 'aty_twisted_k.py'),
                     ['_norm', 'echelon', 'rank_int', 'nullspace_int', 'matvec', 'smith', 'group_name', 'coker', 'comm_set', 'mprod', 'build_cell',
                      'restrict', 'clean', 'fadd', 'BitModel', 'pages', 'twisted_dims', 'MODELS'], ns)
def tname(cell):
    D = {'R': 'ℝ', 'C': 'ℂ', 'H': 'ℍ'}[cell['type']]; dimD = {'R': 1, 'C': 2, 'H': 4}[cell['type']]
    k = int(cell['summ']); N = int(round(math.sqrt((1 << cell['n']) / (k * dimD))))
    one = D if N == 1 else 'M%s(%s)' % (sub(N), D)
    return one if k == 1 else one + '⊕' + one
GNAME = {'Z': 'ℤ', 'Z2': 'ℤ₂', '0': '0'}
def fig_abs_clock(T):
    cells = {}
    def C(p, q):
        if (p, q) not in cells: cells[(p, q)] = T['build_cell'](p, q)
        return cells[(p, q)]
    graded, types = [], []
    for n in range(0, 10):
        small, big = C(1, n), C(1, n + 1)
        Mx, _ = T['restrict'](big, n + 1, small)
        graded.append(T['coker'](Mx)[0])
    for n in range(0, 8): types.append(tname(C(0, n)))
    want = logline(LOG_TWK, r'aty\.A2: graded, Cl\(0,n\) inside').split('n = 0..9: ')[1].split(';')[0].split()
    assert graded == want, (graded, want)
    S = Svg(360, 404)
    S.text(180, 18, 'Graded Clifford modules: KO⁻ⁿ(point) on the clock', 13, 'middle', weight='600')
    S.text(180, 34, 'inner: the algebra Cl(0,n); outer: the cokernel of the', 11, 'middle', 'mu')
    S.text(180, 48, 'graded Cl(0,n+1)-modules in the graded Cl(0,n)-modules', 11, 'middle', 'mu')
    cx, cy = 180, 206
    S.circle(cx, cy, 120, 'ln', 1, extra=' fill="none"')
    for n in range(8):
        ang = -math.pi / 2 + n * math.pi / 4
        g = graded[n]; cls = 's1' if g == 'Z' else ('s2' if g == 'Z2' else 'fz')
        x, y = cx + 120 * math.cos(ang), cy + 120 * math.sin(ang)
        S.circle(x, y, 18, cls, tip='n = %d: KO^-%d(point) = %s' % (n, n, g)); S.circle(x, y, 18, 'k', 0.8)
        S.text(x, y + 5, GNAME[g], 14, 'middle', weight='700')
        S.text(cx + 149 * math.cos(ang), cy + 149 * math.sin(ang) + 4, 'n=%d' % n, 10.5, 'middle', 'mu')
        tx, ty = cx + 76 * math.cos(ang), cy + 76 * math.sin(ang) + 4
        S.text(tx, ty, types[n], 10.5 if len(types[n]) > 6 else 11.5, 'middle', weight='600', tip='Cl(0,%d) = %s' % (n, types[n]))
    S.text(cx, cy - 4, 'the algebra', 10.5, 'middle', 'mu'); S.text(cx, cy + 10, 'Cl(0,n)', 10.5, 'middle', 'mu')
    S.text(8, 380, 'n = 8, 9 repeat n = 0, 1: %s, %s (period 8). Over ℂ: ℤ, 0, ℤ, 0, …' % (GNAME[graded[8]], GNAME[graded[9]]), 11.5, cls='t2')
    S.text(8, 396, 'blue ℤ, orange ℤ₂, grey 0; computed with build_cell and restrict.', 11.5, cls='t2')
    S.save('abs_clock', 'The groups KO^-n(point) from graded Clifford modules, on the clock',
           'Eight clock positions n = 0 to 7 with the algebra type of Cl(0,n) inside and the graded cokernel outside: Z, Z2, Z2, 0, Z, 0, 0, 0, computed with the functions of aty_twisted_k.py; n = 8, 9 repeat.', 1.2)
    note('ABS: graded cokernels %s; types %s' % (graded, types))
    return graded

def fig_ss_pages(T):
    name, k, m, dg, eta = [x for x in T['MODELS'] if x[0] == 'Y x CP^2'][0]
    bm = T['BitModel'](k, m, dg); D = bm.matrix(eta); top = max(bm.deg)
    pg = T['pages'](D, bm.deg, top + 2)
    line = logline(LOG_TWK, r'pages of Y x CP\^2 by degree')
    for r in (2, 4, 6, 8):
        assert ('E%d %s' % (r, pg[r])) in line, (r, pg[r], line)
    tw = T['twisted_dims'](D, bm.deg)
    tot = {r: sum(v) for r, v in pg.items()}
    assert (tot[2], tot[4], tot[6], tot[8]) == (18, 10, 8, 8) and tw == (4, 4)
    S = Svg(360, 382)
    S.text(180, 18, 'The twisted spectral sequence of Y × ℂP², H = xt', 13, 'middle', weight='600')
    S.text(180, 34, 'dimensions of the pages by degree (d₃, d₅ are the only differentials)', 11, 'middle', 'mu')
    x0, bw, unit = 46, 34, 13
    rows = [(2, 'E₂', 's1', 16), (4, 'E₄', 's2', 54), (6, 'E₆ = E∞', 's3', 16)]
    y = 60
    for r, lab, cls, gap in rows:
        base = y + 3 * unit + 8
        S.text(8, base - 14, lab if r != 6 else 'E₆', 12, weight='700')
        if r == 6: S.text(8, base - 1, '= E∞', 11, weight='600')
        for d in range(8):
            v = pg[r][d]
            if v: S.rect(x0 + bw * d + 4, base - v * unit, bw - 8, v * unit, cls, rx=2, sw=0, tip='%s, degree %d: %d' % (lab, d, v))
            S.text(x0 + bw * (d + 0.5), base - v * unit - 4, str(v), 11, 'middle')
        S.line(x0, base, x0 + bw * 8, base, 'ax', 0.8)
        S.text(x0 + bw * 8 + 6, base - 14, 'Σ %d' % tot[r], 12, weight='700')
        if r == 4:
            # d5 on E4: from degree 1 (y) to degree 6 (x z t^2), drawn under the axis
            xa, xb = x0 + bw * 1.5, x0 + bw * 6.5
            S.path('M%s %s C %s %s, %s %s, %s %s' % (n1(xa), n1(base + 3), n1(xa + 20), n1(base + 34), n1(xb - 20), n1(base + 34), n1(xb), n1(base + 5)), 'k', 1.3, dash='3 2')
            S.arrow(xb - 3, base + 12, xb, base + 4, 'k', 1.3, head=7)
            S.text(x0 + bw * 4, base + 44, 'd₅(y) = ' + M + 'xzt², rank 1', 11, 'middle', weight='600')
        y = base + gap
    for d in range(8): S.text(x0 + bw * (d + 0.5), y + 2, str(d), 11, 'middle', 'mu')
    S.text(x0 + bw * 4, y + 17, 'degree', 11, 'middle', 'mu')
    S.text(8, y + 40, 'model: 18 → 10 → 8; twisted cohomology (even, odd) = (%d, %d).' % tw, 11.5, cls='t2')
    S.text(8, y + 56, 'The printed Appendix: 18, 14, 10; 14 is the dimension of the', 11.5, cls='t2')
    S.text(8, y + 72, 'd₃-cycles and 10 that of E₄ (ATY-003 keeps both).', 11.5, cls='t2')
    S.save('ss_pages', 'The pages E2, E4, E6 of the twisted spectral sequence of Y x CP2',
           'Bar charts by degree 0 to 7 of the pages E2 (18), E4 (10) and E6 = E-infinity (8) of the degree filtration of D = d - xt on the 24-dimensional model, computed with BitModel and pages of aty_twisted_k.py; d5 of rank 1 from degree 1 to 6.', 1.2)
    note('pages E2 %s E4 %s E6 %s; twisted %s' % (pg[2], pg[4], pg[6], tw))

# ================================================================================================ lattices (F12, F13)
def frame_gram(p, q):
    """the frame lattice of Cl(p,q): G_ij = scalar part of (e_i e_j + e_j e_i)/2, from the bit rule"""
    A = Alg(sig(p, q)); n = p + q
    G = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            s1, c1 = A.blade_mul(1 << i, 1 << j); s2, c2 = A.blade_mul(1 << j, 1 << i)
            G[i][j] = Fr(s1 + s2, 2) if c1 == 0 else Fr(0)
    return [[int(x) for x in row] for row in G]
def ip(G, x, y): return sum(G[i][j] * x[i] * y[j] for i in range(len(x)) for j in range(len(y)) if G[i][j])
def vectors(n, sq, s):
    """integer vectors of length n with sum of squares sq and sum s"""
    out = []
    def rec(prefix, left, sm, rem):
        if rem == 0:
            if left == 0 and sm == s: out.append(tuple(prefix))
            return
        if (s - sm) ** 2 > rem * left: return
        b = int(math.isqrt(left))
        for v in range(-b, b + 1):
            rec(prefix + [v], left - v * v, sm + v, rem - 1)
    rec([], sq, 0, n)
    return out
def roots_kperp(n):
    """the norm -2 vectors of k^perp in the frame lattice I_(1,n) of Cl(1,n), k = (3; -1, ..., -1), |x0| <= 4 (bd·mat·13)"""
    G = frame_gram(1, n); k = [3] + [-1] * n
    out = []
    for x0 in range(-4, 5):
        for xs in vectors(n, x0 * x0 + 2, -3 * x0):
            x = (x0,) + xs
            assert ip(G, x, x) == -2 and ip(G, k, x) == 0
            out.append(x)
    return G, k, out
def signature_exact(G):
    """(positive, negative) by congruence diagonalisation over Q"""
    A = [[Fr(x) for x in row] for row in G]; n = len(A); pos = neg = 0
    for t in range(n):
        if A[t][t] == 0:
            j = next((j for j in range(t + 1, n) if A[t][j] != 0), None)
            if j is None: continue
            if A[j][j] != 0:
                A[t], A[j] = A[j], A[t]
                for row in A: row[t], row[j] = row[j], row[t]
            else:
                for c in range(n): A[t][c] += A[j][c]
                for r in range(n): A[r][t] += A[r][j]
        d = A[t][t]
        if d == 0: continue
        pos += d > 0; neg += d < 0
        for r in range(t + 1, n):
            f = A[r][t] / d
            if f:
                for c in range(t, n): A[r][c] -= f * A[t][c]
        for c in range(t + 1, n): A[t][c] = Fr(0)
        for r in range(t + 1, n): A[r][t] = Fr(0)
    return pos, neg
def det_exact(G):
    A = [[Fr(x) for x in row] for row in G]; n = len(A); d = Fr(1)
    for t in range(n):
        piv = next((r for r in range(t, n) if A[r][t] != 0), None)
        if piv is None: return Fr(0)
        if piv != t: A[t], A[piv] = A[piv], A[t]; d = -d
        d *= A[t][t]
        for r in range(t + 1, n):
            f = A[r][t] / A[t][t]
            for c in range(t, n): A[r][c] -= f * A[t][c]
    return d
def osum(*Gs):
    n = sum(len(G) for G in Gs); out = [[0] * n for _ in range(n)]; o = 0
    for G in Gs:
        for i in range(len(G)):
            for j in range(len(G)): out[o + i][o + j] = G[i][j]
        o += len(G)
    return out
def simple_roots(roots, n):
    rg = random.Random(5)
    f = [rg.randint(10 ** 6, 2 * 10 ** 6) for _ in range(n + 1)]
    pos = [r for r in roots if sum(a * b for a, b in zip(f, r)) > 0]
    pset = set(pos)
    simple = [r for r in pos if not any(tuple(a - b for a, b in zip(r, s)) in pset for s in pos if s != r)]
    return sorted(simple, key=lambda r: sum(a * b for a, b in zip(f, r)))
def e8_data():
    G, k, roots = roots_kperp(8)
    sr = simple_roots(roots, 8)
    assert len(roots) == 240 and len(sr) == 8
    gram = [[-ip(G, a, b) for b in sr] for a in sr]           # the Cartan matrix (B = minus the form on k^perp)
    assert all(gram[i][i] == 2 for i in range(8)) and det_exact(gram) == 1
    return G, k, roots, sr, gram
def fig_gram_forms(E8):
    G9, k, roots, sr, cart = E8
    negE8 = [[-x for x in row] for row in cart]
    H = [[0, 1], [1, 0]]
    forms = [('S⁴', [], 'cell (0,0)'), ('ℂP²', frame_gram(1, 0), 'cell (1,0)'), (M + 'ℂP²', frame_gram(0, 1), 'cell (0,1)'),
             ('S² × S²', H, 'H'), ('ℂP² # ' + M + 'ℂP²', frame_gram(1, 1), 'cell (1,1)'),
             ('ℂP² # 8(' + M + 'ℂP²)', frame_gram(1, 8), 'cell (1,8)'), ('K3', osum(H, H, H, negE8, negE8), '3H ⊕ 2(' + M + 'E₈)')]
    data = []
    for name, Gm, src in forms:
        b2 = len(Gm); sp, sn = signature_exact(Gm) if b2 else (0, 0)
        ev = np.linalg.eigvalsh(np.array(Gm, dtype=float)) if b2 else np.array([])
        assert (int((ev > 0).sum()), int((ev < 0).sum())) == (sp, sn)
        det = det_exact(Gm) if b2 else Fr(1)
        even = all(Gm[i][i] % 2 == 0 for i in range(b2))
        data.append((name, Gm, src, b2, sp - sn, 2 + b2, det, even))
    want = logline(LOG_MAT, r'unimodular \(det \+-1\), signatures')
    assert 'signatures 0, 1, -1, 0, 0, -16, -7' in want and 'Euler numbers 2, 3, 3, 4, 4, 24, 11' in want
    order = {d[0]: d for d in data}
    sig_list = [order[n][4] for n in ('S⁴', 'ℂP²', M + 'ℂP²', 'S² × S²', 'ℂP² # ' + M + 'ℂP²', 'K3', 'ℂP² # 8(' + M + 'ℂP²)')]
    chi_list = [order[n][5] for n in ('S⁴', 'ℂP²', M + 'ℂP²', 'S² × S²', 'ℂP² # ' + M + 'ℂP²', 'K3', 'ℂP² # 8(' + M + 'ℂP²)')]
    assert sig_list == [0, 1, -1, 0, 0, -16, -7] and chi_list == [2, 3, 3, 4, 4, 24, 11]
    S = Svg(360, 470)
    S.text(180, 18, 'Intersection forms as Gram matrices', 13, 'middle', weight='600')
    S.text(180, 34, 'blue +, red ' + M + ' (darker: ±2), grey 0; σ = b⁺ ' + M + ' b⁻, χ = 2 + b₂', 11, 'middle', 'mu')
    def mat(Gm, x, y, c, show_num):
        n = len(Gm)
        for i in range(n):
            for j in range(n):
                v = Gm[i][j]
                cls = 'fz' if v == 0 else ('fp' if v == 1 else ('s1' if v >= 2 else ('fn' if v == -1 else 'ng')))
                S.rect(x + c * j, y + c * i, c - (1 if c > 6 else 0.5), c - (1 if c > 6 else 0.5), cls, sw=0, tip=('(%d,%d) = %d' % (i + 1, j + 1, v)) if n <= 9 else None)
                if show_num: S.text(x + c * (j + 0.5), y + c * (i + 0.5) + 4.5, frs(v), 12, 'middle')
    small = data[:5]
    xs = [8, 76, 144, 212, 288]
    for (name, Gm, src, b2, sg, chi, det, even), x in zip(small, xs):
        if b2 == 0:
            S.rect(x + 6, 56, 26, 26, 'ln', sw=1, extra=' stroke-dasharray="3 2"')
            S.text(x + 19, 73, '∅', 12, 'middle', 'mu')
        else:
            mat(Gm, x + (0 if b2 == 2 else 6), 56, 26 if b2 == 1 else 24, True)
        S.text(x + 22, 122, name, 11, 'middle', weight='600')
        S.text(x + 22, 136, 'σ=%s χ=%d' % (frs(sg), chi), 10.5, 'middle')
        S.text(x + 22, 150, 'even' if even else 'odd', 10.5, 'middle', 'mu')
    name, Gm, src, b2, sg, chi, det, even = data[5]
    mat(Gm, 14, 184, 14, False)
    S.text(77, 324, name, 11.5, 'middle', weight='600')
    S.text(77, 339, 'I₁,₈ of the cell (1,8)', 11, 'middle', 'mu')
    S.text(77, 354, 'σ = %s, χ = %d, odd' % (frs(sg), chi), 11, 'middle')
    name, Gm, src, b2, sg, chi, det, even = data[6]
    mat(Gm, 156, 172, 8.8, False)
    S.text(253, 378, 'K3 = 3H ⊕ 2(' + M + 'E₈)', 11.5, 'middle', weight='600')
    S.text(253, 393, 'σ = %s, χ = %d, even, det %s' % (frs(sg), chi, frs(det)), 11, 'middle')
    S.text(8, 420, M + 'E₈ = minus the Gram matrix of the simple roots of k^⊥ in I₁,₈', 11.5, cls='t2')
    S.text(8, 436, '(k = (3; ' + M + '1⁸)); K3\'s form is recalled, its blocks computed.', 11.5, cls='t2')
    S.text(8, 456, 'det ±1 for all: unimodular.', 11.5, cls='t2')
    assert all(abs(d[6]) == 1 for d in data)
    S.save('gram_forms', 'The intersection forms of S4, CP2, -CP2, S2 x S2, CP2 # -CP2, the cell (1,8) and K3',
           'Gram matrices drawn as coloured grids with signature and Euler number: 0 and 2, 1 and 3, -1 and 3, 0 and 4, 0 and 4, -7 and 11, -16 and 24; the frame lattices come from the bit rule, the E8 blocks from the cell (1,8).', 1.2)
    note('forms: signatures %s, Euler %s' % (sig_list, chi_list))

def fig_e8(E8):
    G9, k, roots, sr, cart = E8
    counts = {n: len(roots_kperp(n)[2]) for n in range(3, 9)}
    dets = {n: ip(frame_gram(1, n), [3] + [-1] * n, [3] + [-1] * n) for n in range(3, 10)}
    assert counts == {3: 8, 4: 20, 5: 40, 6: 72, 7: 126, 8: 240} and all(dets[n] == 9 - n for n in dets)
    assert '{3: 8, 4: 20, 5: 40, 6: 72, 7: 126, 8: 240}' in bridge_text('bd·mat·13')
    # the Coxeter plane: c = s_1 ... s_8 in the ambient coordinates of I_(1,8); eigenvalue exp(2 pi i/30)
    Gm = np.array(G9, dtype=float)
    def refl(a):
        a = np.array(a, dtype=float); return np.eye(9) + np.outer(a, a @ Gm)          # x -> x + (x.a) a, since a.a = -2
    C = np.eye(9)
    for a in sr: C = C @ refl(a)
    w, V = np.linalg.eig(C)
    j = int(np.argmin(np.abs(w - np.exp(2j * np.pi / 30))))
    assert abs(w[j] - np.exp(2j * np.pi / 30)) < 1e-9
    v = V[:, j]
    B = lambda x, y: -(x @ Gm @ y)
    u1, u2 = np.real(v), np.imag(v)
    nrm = math.sqrt(B(u1, u1)); u1, u2 = u1 / nrm, u2 / nrm
    R = np.array(roots, dtype=float)
    P = np.array([[B(r, u1), B(r, u2)] for r in R])
    a0 = np.array(sr[0], dtype=float); ang0 = math.atan2(B(a0, u2), B(a0, u1))
    rot = np.array([[math.cos(-ang0), -math.sin(-ang0)], [math.sin(-ang0), math.cos(-ang0)]])
    P = P @ rot.T
    radii = sorted({round(float(np.hypot(*p)), 6) for p in P})
    assert len(radii) == 8 and all(sum(1 for p in P if abs(np.hypot(*p) - r) < 1e-5) == 30 for r in radii)
    order = np.lexsort((np.round(P[:, 1], 6), np.round(P[:, 0], 6)))
    S = Svg(360, 494)
    S.text(180, 18, 'E₈ inside the cell (1,8): its 240 roots', 13, 'middle', weight='600')
    S.text(180, 34, 'k^⊥ in I₁,₈, projected on the Coxeter plane: 8 rings of 30', 11, 'middle', 'mu')
    cx, cy, sc = 180, 192, 148 / max(radii)
    for r in radii: S.circle(cx, cy, r * sc, 'ln', 0.6, extra=' fill="none"')
    for idx in order:
        x, y = cx + sc * P[idx][0], cy - sc * P[idx][1]
        S.circle(x, y, 3.2, 's1', tip='(' + ', '.join(frs(t) for t in roots[idx]) + ')')
    top = 372
    S.text(8, top, 'roots of Eₙ = k^⊥ in I₁,ₙ (norm ' + M + '2), and k·k = 9 ' + M + ' n', 12, weight='600')
    bx, bw = 46, 50
    mx = 240
    for i, n in enumerate(range(3, 9)):
        h = 70 * counts[n] / mx
        S.rect(bx + bw * i + 8, top + 86 - h, bw - 16, h, 's1', rx=2, sw=0, tip='E%d: %d roots, k.k = %d' % (n, counts[n], dets[n]))
        S.text(bx + bw * (i + 0.5), top + 82 - h, str(counts[n]), 11, 'middle', weight='600')
        S.text(bx + bw * (i + 0.5), top + 100, 'E' + sub(n), 11.5, 'middle')
        S.text(bx + bw * (i + 0.5), top + 113, 'k·k=%d' % dets[n], 10.5, 'middle', 'mu')
    S.line(bx, top + 86, bx + bw * 6, top + 86, 'ax', 0.8)
    S.save('e8_roots', 'The 240 roots of E8 inside the frame lattice of the cell (1,8)',
           'The 240 norm -2 vectors orthogonal to k = (3; -1^8) in I(1,8), found by figs_top.py, projected on the Coxeter plane of their own reflection group (eight rings of 30), and the root counts 8, 20, 40, 72, 126, 240 of E3 to E8 with k.k = 9 - n.', 1.15)
    note('E_n roots %s; k.k = 9 - n; Coxeter plane rings %d' % (counts, len(radii)))

# ================================================================================================ F14: Taub-NUT on the engine (Top11)
def fig_taubnut():
    gdir = os.path.join(SC, 'gravity'); sys.path.insert(0, gdir)
    argv = sys.argv; sys.argv = [argv[0]]
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            import aty_matter_models as AM
    finally:
        sys.argv = argv
    pts = []
    for (m, r0, d) in AM.TN_PTS:
        e, info = AM.tn_frame(AM.tn_point(m, r0, d), m)
        Rl, Es = AM.engine_eval(e)
        C6 = AM.op6(AM.weyl_parts(Rl, AM.SQ)[0])
        t, inf = AM.ptype(AM.block3(C6, AM.BP)); tm, _ = AM.ptype(AM.block3(C6, AM.BM))
        assert t == 'D' and tm == 'O' and all(v == 0 for v in Es[0].values())
        dbl, sim = AM.qre(inf['double']), AM.qre(inf['simple'])
        mu = Fr(m) / (r0 + m) ** 3
        assert dbl == -mu and sim == 2 * mu
        pts.append((Fr(m), Fr(r0), dbl, sim, AM.norm2(Rl)))
    assert 'eigenvalues {double - mu} x (1, 1, -2), mu = m/(r + m)^3' in logline(LOG_MAT, r'W\+ \(3 x 3, self-dual basis\) is type D')
    S = Svg(360, 360)
    S.text(180, 18, 'Taub–NUT on the engine: the eigenvalues of W⁺', 13, 'middle', weight='600')
    S.text(180, 34, 'scaled by m², against ρ = r/m; W⁻ = 0 at every point', 11, 'middle', 'mu')
    x0, y0, W, H = 48, 56, 290, 220
    xm, ylo, yhi = 1.0, -1.2, 2.2
    X = lambda t: x0 + W * t / xm
    Y = lambda v: y0 + H * (yhi - v) / (yhi - ylo)
    for v in (-1, 0, 1, 2):
        S.line(x0, Y(v), x0 + W, Y(v), 'ln', 0.6)
        S.text(x0 - 6, Y(v) + 4, frs(v), 11, 'end', 'mu')
    for t in (0, 0.25, 0.5, 0.75, 1.0):
        S.text(X(t), y0 + H + 16, n1(t) if t not in (0.25, 0.75) else ('%.2f' % t), 11, 'middle', 'mu')
    S.text(x0 + W / 2, y0 + H + 32, 'ρ = r/m', 11.5, 'middle', 'mu')
    S.line(x0, Y(0), x0 + W, Y(0), 'ax', 1)
    for f, cls, lab, ly in ((lambda t: 2 / (1 + t) ** 3, 's1k', 'simple: 2/(1+ρ)³', 1.25), (lambda t: -1 / (1 + t) ** 3, 's2k', 'double: ' + M + '1/(1+ρ)³', -0.62)):
        d = 'M' + ' L'.join('%s %s' % (n1(X(t)), n1(Y(f(t)))) for t in [i / 100 for i in range(0, 101)])
        S.path(d, cls, 2)
        S.text(X(0.42), Y(ly), lab, 11.5, weight='600')
    shapes = {Fr(2): 'c', Fr(1, 2): 's', Fr(3): 'd'}
    for (m, r0, dbl, sim, nr) in sorted(pts, key=lambda t: (-t[0], t[1])):
        t = float(r0 / m)
        for v, cls, which in ((m * m * sim, 's1', 'simple'), (m * m * dbl, 's2', 'double')):
            S.marker(shapes[m], X(t), Y(float(v)), cls, tip='m = %s, r = %s: m^2 x %s eigenvalue = %s' % (frs(m), frs(r0), which, frs(v)))
    ly = y0 + H + 54
    S.marker('c', 20, ly - 4, 'bg'); S.text(30, ly, 'm = 2 (4 points)', 11.5)
    S.marker('s', 146, ly - 4, 'bg'); S.text(156, ly, 'm = 1/2', 11.5)
    S.marker('d', 232, ly - 4, 'bg'); S.text(242, ly, 'm = 3', 11.5)
    S.text(8, ly + 20, 'marks lie on top of each other where ρ agrees: the scaling', 11, cls='t2')
    S.save('taubnut_weyl', 'The Weyl eigenvalues of Taub-NUT at the eight rational points',
           'The self-dual Weyl block of Taub-NUT has eigenvalues -mu, -mu, 2 mu with mu = m/(r+m)^3; scaled by m^2 they fall on -1/(1+rho)^3 and 2/(1+rho)^3; the eight points are computed on the gravity engine through aty_matter_models.py.', 1.2)
    note('Taub-NUT: 8 points, W+ type D (-mu, -mu, 2mu), W- type O')

# ================================================================================================ F15: the octahedron of the six planes (Top12)
def perm_parity(seq):
    s = 1; seq = list(seq)
    for i in range(len(seq)):
        for j in range(i + 1, len(seq)):
            if seq[i] > seq[j]: s = -s
    return s
def fig_octahedron():
    planes = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    mask = lambda ab: (1 << ab[0]) | (1 << ab[1])
    I2 = {}
    for name, (p, q) in (('Cl(4,0)', (4, 0)), ('Cl(0,4)', (0, 4)), ('Cl(1,3)', (1, 3)), ('Cl(3,1)', (3, 1))):
        I2[name] = Alg(sig(p, q)).sq(15)
    assert I2 == {'Cl(4,0)': 1, 'Cl(0,4)': 1, 'Cl(1,3)': -1, 'Cl(3,1)': -1}
    assert "{'Cl(4,0)': 1, 'Cl(0,4)': 1, 'Cl(1,3)': -1, 'Cl(3,1)': -1}" in logline(LOG_CONE, r'I\^2 by the bit rule')
    sigma = {}
    for p, q in ((4, 0), (0, 4)):
        A = Alg(sig(p, q)); ss = set()
        for ab in planes:
            s, c = A.blade_mul(15, mask(ab))
            cd = tuple(i for i in range(4) if c >> i & 1)
            star = perm_parity(ab + cd)
            ss.add(s * star)
        assert len(ss) == 1; sigma[(p, q)] = ss.pop()
    assert sigma == {(4, 0): -1, (0, 4): -1}
    S = Svg(360, 424)
    S.text(180, 18, 'The six planes of a 4-space as an octahedron', 13, 'middle', weight='600')
    S.text(180, 34, 'antipodes are complementary planes: I e_ab = ' + M + '⋆e_ab', 11, 'middle', 'mu')
    cx, cy = 180, 190
    V = {(0, 1): (cx - 118, cy + 6), (2, 3): (cx + 118, cy - 6), (0, 2): (cx - 46, cy + 42), (1, 3): (cx + 46, cy - 42), (0, 3): (cx, cy - 122), (1, 2): (cx, cy + 122)}
    for a, b in itertools.combinations(planes, 2):
        if set(a) & set(b):
            S.line(*V[a], *V[b], 'ln', 1.2)
    for a, b in (((0, 1), (2, 3)), ((0, 2), (1, 3)), ((0, 3), (1, 2))):
        S.line(*V[a], *V[b], 's2k', 2.2, dash='6 4')
    for ab in planes:
        x, y = V[ab]
        S.circle(x, y, 21, 's1k', 2.2)
        S.circle(x, y, 15, 'bg'); S.circle(x, y, 15, 'k', 1)
        S.text(x, y + 4.5, 'e' + sub(ab[0]) + sub(ab[1]), 12, 'middle', weight='600')
    y = 352
    S.line(14, y, 40, y, 's2k', 2.2, dash='6 4')
    S.text(48, y + 4, 'complementary pair: ε_abcd R^ab ∧ R^cd (Euler)', 11.5)
    S.circle(27, y + 22, 8, 's1k', 2.2)
    S.text(48, y + 26, 'each plane with itself: Σ R^ab ∧ R^ab (signature)', 11.5)
    S.text(8, y + 48, 'I = e₀₁₂₃: I² = +1 in Cl(4,0), Cl(0,4); ' + M + '1 in Cl(1,3), Cl(3,1)', 11.5, cls='t2')
    S.text(8, y + 63, 'so the star splits the planes 3 + 3 only in a Euclidean cell.', 11.5, cls='t2')
    S.save('octahedron', 'The two pairings of the six planes on the octahedron',
           'An octahedron whose vertices are the six coordinate planes e01 ... e23; dashed diameters join complementary planes (the Euler 4-form), circles pair each plane with itself (the signature 4-form); I e_ab = -*e_ab in Cl(4,0) and Cl(0,4), computed with bitcliff.py.', 1.2)
    note('octahedron: I^2 = +1, +1, -1, -1; I e_ab = -*e_ab in both Euclidean cells')

# ================================================================================================ F16: the edge-cone defects (Top12), read from the log
def fig_cone():
    txt = open(LOG_CONE, encoding='utf8').read()
    e4, ef = {}, {}
    for b, a, c in re.findall(r'beta = (\S+): Euler integral (\S+) \(S\^4, vol [^)]*\) = chi\(S\^4\) - \(1 - beta\) chi\(S\^2\) = \S+;\s+(\S+) \(S\^2 x football\)', txt):
        e4[Fr(b)] = Fr(a); ef[Fr(b)] = Fr(c)
    ecp = {Fr(b): Fr(v) for b, v in re.findall(r'beta = (\S+): \(1/32 pi\^2\) int eps R\^R = (\S+) exactly', txt)}
    scp = {Fr(b): Fr(v) for b, v in re.findall(r'beta = (\S+): \(1/12 pi\^2\) int sum R\^ab R\^ab = (\S+) exactly', txt)}
    assert sorted(e4) == [Fr(1, 3), Fr(1, 2), Fr(2, 3), 2, 3] and sorted(ecp) == [Fr(1, 3), Fr(1, 2), 1, 2] and sorted(scp) == sorted(ecp)
    for b in e4: assert e4[b] == 2 - (1 - b) * 2 and ef[b] == 4 - (1 - b) * 4
    for b in ecp: assert ecp[b] == 3 - (1 - b) * 2 and scp[b] == -1 - Fr(1, 3) * (1 - b * b) * (-1)
    S = Svg(360, 506)
    S.text(180, 18, 'Curvature integrals with an edge cone of angle 2πβ', 13, 'middle', weight='600')
    S.text(180, 34, 'lines: the two theorems; dots: the exact integrals of the log', 11, 'middle', 'mu')
    def panel(top, H, ylo, yhi, yt, title, series):
        x0, W = 46, 296
        y0 = top + 12 + 15 * len(series)
        X = lambda b: x0 + W * b / 3.2
        Y = lambda v: y0 + H * (yhi - v) / (yhi - ylo)
        S.text(8, top, title, 12, weight='600')
        for k, (f, pts, cls, lab, shape) in enumerate(series):
            ly = top + 17 + 15 * k
            S.marker(shape, x0 + 12, ly - 4, cls); S.text(x0 + 24, ly, lab, 11, weight='600')
        for v in yt:
            S.line(x0, Y(v), x0 + W, Y(v), 'ln', 0.6); S.text(x0 - 6, Y(v) + 4, frs(v), 11, 'end', 'mu')
        for b in (0, 1, 2, 3): S.text(X(b), y0 + H + 15, str(b), 11, 'middle', 'mu')
        S.line(X(1), y0, X(1), y0 + H, 'ax', 0.8, dash='2 3'); S.text(X(1) + 4, y0 + H - 4, 'β = 1: smooth', 10.5, cls='mu')
        for f, pts, cls, lab, shape in series:
            bmax = 3.1
            d = 'M' + ' L'.join('%s %s' % (n1(X(b)), n1(Y(f(b)))) for b in [i * bmax / 100 for i in range(101)])
            S.path(d, cls + 'k', 2)
            for b, v in sorted(pts.items()):
                S.marker(shape, X(float(b)), Y(float(v)), cls, tip='%s, beta = %s: %s' % (lab, frs(b), frs(v)))
        S.text(x0 + W / 2, y0 + H + 30, 'β', 12, 'middle', 'mu')
    panel(58, 160, 0, 13, (0, 4, 8, 12), 'Euler: (1/32π²)∫ ε R∧R = χ(M) ' + M + ' (1 ' + M + ' β) χ(Σ)',
          [(lambda b: 4 * b, ef, 's2', 'S² × football: 4β', 's'),
           (lambda b: 1 + 2 * b, ecp, 's3', 'ℂP² ⊃ ℂP¹: 1 + 2β', 'd'),
           (lambda b: 2 * b, e4, 's1', 'S⁴ ⊃ S²: 2β', 'c')])
    panel(330, 92, -4, 0.5, (0, -1, -2, -3), 'Signature: (1/12π²)∫ Σ R∧R = τ(M) ' + M + ' (1/3)(1 ' + M + ' β²)[Σ]²',
          [(lambda b: -(2 + b * b) / 3, scp, 's3', 'ℂP² ⊃ ℂP¹: ' + M + '(2 + β²)/3, τ = ' + M + '1 here', 'd'),
           (lambda b: 0.0, {Fr(1, 3): Fr(0), Fr(1, 2): Fr(0), Fr(2, 3): Fr(0), Fr(2): Fr(0), Fr(3): Fr(0)}, 's1', 'S⁴ ⊃ S², S² × football: 0', 'c')])
    S.save('cone_defects', 'The Euler and signature integrals of edge-cone metrics against beta',
           'Two panels: the Euler integral 2 beta, 4 beta, 1 + 2 beta for S4 with a cone along S2, S2 times a football and CP2 with a cone along a line, and the signature integral -(2 + beta^2)/3 on CP2 in the chart orientation; the dots are the exact values of aty_cone_defects.log.', 1.2)
    note('cone: %d Euler points, %d signature points from the log, all on the two formulas' % (len(e4) + len(ef) + len(ecp), len(scp)))

# ================================================================================================ stored values for the widgets' self-tests
def widget_values():
    rg = random.Random(2026)
    prods = []
    for _ in range(10):
        n = rg.randint(3, 6); eps = tuple(rg.choice((1, 1, -1, -1, 0)) for _ in range(n)); a, b = rg.randrange(1, 1 << n), rg.randrange(1, 1 << n)
        prods.append((list(eps), a, b, Alg(eps).blade_mul(a, b)[0]))
    note('ten products for the widgets: %s' % prods)
    gs = [(p, q, r, gauss(p, q, r)) for p, q, r in ((1, 0, 0), (0, 1, 0), (2, 0, 0), (1, 3, 0), (3, 1, 0), (4, 4, 0), (2, 1, 1), (0, 3, 2))]
    note('Gauss sums for the widget: %s' % gs)

if __name__ == '__main__':
    fig_n2(); fig_alexandrov(); fig_cube_complex(); fig_sign_cochain(); fig_polygons(); fig_pin_table(); fig_enhancements()
    fig_brown_clock(); fig_gauss_phases()
    T = load_twk(); fig_abs_clock(T); fig_ss_pages(T)
    E8 = e8_data(); fig_gram_forms(E8); fig_e8(E8)
    fig_taubnut(); fig_octahedron(); fig_cone(); widget_values()
    print('\n'.join(SUMMARY))
