#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# figs_cga.py: draws every figure of figs/ for the tutorial "The conformal model on the bit rule" from the computations of
# cga_compute.py, whose products are the Atlas's bit rule (checks/researchers_checks/bitrule_A.py, imported by path).
#   python3 -I -B figs_cga.py        writes figs/*.svg (deterministic: the same script gives the same bytes)
import os, math, importlib.util, random
from fractions import Fraction as F

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location('cga_compute', os.path.join(HERE, 'cga_compute.py'))
C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
BA, popc, lab = C.BA, C.popc, C.lab
REPO = os.path.abspath(os.environ.get('ATLAS_REPO') or os.path.join(HERE, '..', '..'))   # the repository: ATLAS_REPO, else two folders up from tools/tutorials/
OUT = os.path.join(REPO, 'public', 'reports', 'tutorials', 'src', 'cga', 'figs')   # the figures, beside the tutorial's source; os.makedirs(OUT, exist_ok=True)

STYLE = ('<style>'
         '.cg text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif}'
         '.cg .i{fill:var(--ink,#1a1a19)}.cg .m{fill:var(--muted,#6b6b64)}.cg .a{fill:var(--acc,#184f95)}'
         '.cg .si{stroke:var(--ink,#1a1a19)}.cg .sm{stroke:var(--muted,#6b6b64)}.cg .sa{stroke:var(--acc,#184f95)}.cg .sl{stroke:var(--line2,#c9c8c0)}'
         '.cg .so{stroke:#d9822b}.cg .fo{fill:#d9822b}.cg .sg{stroke:#2f9154}.cg .fg{fill:#2f9154}.cg .sr{stroke:#d0543c}.cg .fr{fill:#d0543c}'
         '.cg .sp{stroke:#8e5bb5}.cg .fp{fill:#8e5bb5}'
         '.cg .pos{fill:#3d6fb0}.cg .neg{fill:#d0543c}.cg .zer{fill:var(--tint,#f3f2ee)}.cg .bg{fill:var(--surf,#ffffff)}'
         '.cg .ta{fill:var(--acc,#184f95);fill-opacity:.10}.cg .to{fill:#d9822b;fill-opacity:.12}.cg .tg{fill:#2f9154;fill-opacity:.12}'
         '</style>')


def n1(v): return ('%.1f' % v).rstrip('0').rstrip('.') if abs(v) >= 0.05 else '0'


class Svg:
    def __init__(self, w, h, label):
        self.w, self.h, self.label, self.items = w, h, label, []

    def add(self, s): self.items.append(s)

    def text(self, x, y, s, size=13, cls='i', anchor='start', bold=False, italic=False):
        st = (' font-weight="600"' if bold else '') + (' font-style="italic"' if italic else '')
        s = s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        self.add(f'<text x="{n1(x)}" y="{n1(y)}" font-size="{size}" class="{cls}" text-anchor="{anchor}"{st}>{s}</text>')

    def line(self, x1, y1, x2, y2, cls='si', w=1.2, dash=None):
        d = f' stroke-dasharray="{dash}"' if dash else ''
        self.add(f'<line x1="{n1(x1)}" y1="{n1(y1)}" x2="{n1(x2)}" y2="{n1(y2)}" class="{cls}" stroke-width="{w}"{d}/>')

    def poly(self, pts, cls='si', w=1.4, dash=None, closed=False, fill=None):
        if len(pts) < 2:
            return
        d = 'M' + ' L'.join(f'{n1(x)} {n1(y)}' for x, y in pts) + (' Z' if closed else '')
        da = f' stroke-dasharray="{dash}"' if dash else ''
        fl = f' class="{cls} {fill}"' if fill else f' class="{cls}" fill="none"'
        self.add(f'<path d="{d}"{fl} stroke-width="{w}"{da}/>')

    def circle(self, cx, cy, r, cls='si', w=1.4, fill=None, dash=None):
        da = f' stroke-dasharray="{dash}"' if dash else ''
        fl = f' class="{cls} {fill}"' if fill else f' class="{cls}" fill="none"'
        self.add(f'<circle cx="{n1(cx)}" cy="{n1(cy)}" r="{n1(r)}"{fl} stroke-width="{w}"{da}/>')

    def dot(self, x, y, r=3.2, cls='i'):
        self.add(f'<circle cx="{n1(x)}" cy="{n1(y)}" r="{n1(r)}" class="{cls}"/>')

    def rect(self, x, y, w, h, cls='zer', stroke=None, rx=0):
        st = f' class="{cls} {stroke}" stroke-width="1"' if stroke else f' class="{cls}"'
        r = f' rx="{rx}"' if rx else ''
        self.add(f'<rect x="{n1(x)}" y="{n1(y)}" width="{n1(w)}" height="{n1(h)}"{r}{st}/>')

    def cells(self, rects, cls):
        """many unit rectangles as one path"""
        if rects:
            self.add(f'<path class="{cls}" d="' + ''.join(f'M{n1(x)} {n1(y)}h{n1(w)}v{n1(h)}h-{n1(w)}z' for x, y, w, h in rects) + '"/>')

    def write(self, name):
        body = '\n'.join(self.items)
        lab_ = self.label.replace('&', '&amp;').replace('<', '&lt;')
        s = (f'<svg xmlns="http://www.w3.org/2000/svg" class="cg" viewBox="0 0 {self.w} {self.h}" width="{self.w}" height="{self.h}" role="img" aria-label="{lab_}">'
             f'<title>{lab_}</title>{STYLE}\n{body}\n</svg>\n')
        with open(os.path.join(OUT, name), 'w', encoding='utf8') as f:
            f.write(s)
        return len(s.encode('utf8'))


# ---------------------------------------------------------------- geometry read from blades (floats), as the widget reads it
def fl(x): return {k: float(v) for k, v in x.items()}
def circle_geom(X):
    c = [float(v) for v in C.center(X)]; r2 = float(C.radius2(X))
    pi = C.dual(C.op(X, C.EINF)); n = [float(pi.get(m, 0)) for m in (1, 2, 4)]; nn = math.sqrt(sum(t * t for t in n)) or 1
    return c, r2, [t / nn for t in n]
def line_geom(L):
    d = [float(L.get(m, 0)) for m in (25, 26, 28)]
    m12, m13, m23 = (float(L.get(m, 0)) for m in (11, 13, 14))
    Mv = [m23, -m13, m12]; dd = sum(t * t for t in d)
    p = [(d[1] * Mv[2] - d[2] * Mv[1]) / dd, (d[2] * Mv[0] - d[0] * Mv[2]) / dd, (d[0] * Mv[1] - d[1] * Mv[0]) / dd]
    nd = math.sqrt(dd)
    return p, [t / nd for t in d]
def plane_geom(Pl):
    pi = C.dual(Pl); n = [float(pi.get(m, 0)) for m in (1, 2, 4)]; dlt = float(pi.get(8, 0)); nn = math.sqrt(sum(t * t for t in n))
    return [t / nn for t in n], dlt / nn
def flat_point(Fp):
    w = -float(Fp.get(24, 0)); return [float(Fp.get(m, 0)) / w for m in (9, 10, 12)]


class View:
    """an orthographic view of R^3: azimuth and elevation in degrees, scale px per unit, origin on the page"""
    def __init__(self, az, el, s, ox, oy):
        a, e = math.radians(az), math.radians(el)
        self.ex = (math.cos(a), math.sin(a), 0.0)
        self.ey = (-math.sin(a) * math.sin(e), math.cos(a) * math.sin(e), math.cos(e))
        self.ez = (math.sin(a) * math.cos(e), -math.cos(a) * math.cos(e), math.sin(e))   # towards the viewer
        self.s, self.ox, self.oy = s, ox, oy
    def __call__(self, p):
        x = sum(u * v for u, v in zip(p, self.ex)); y = sum(u * v for u, v in zip(p, self.ey))
        return self.ox + self.s * x, self.oy - self.s * y
    def depth(self, p): return sum(u * v for u, v in zip(p, self.ez))


def perp_basis(n):
    n = [float(t) for t in n]; a = (1.0, 0, 0) if abs(n[0]) < 0.9 else (0, 1.0, 0)
    u = [a[1] * n[2] - a[2] * n[1], a[2] * n[0] - a[0] * n[2], a[0] * n[1] - a[1] * n[0]]; nu = math.sqrt(sum(t * t for t in u)); u = [t / nu for t in u]
    w = [n[1] * u[2] - n[2] * u[1], n[2] * u[0] - n[0] * u[2], n[0] * u[1] - n[1] * u[0]]
    return u, w


def circle3d(c, r, n, k=96):
    u, w = perp_basis(n)
    return [[c[i] + r * (math.cos(2 * math.pi * j / k) * u[i] + math.sin(2 * math.pi * j / k) * w[i]) for i in range(3)] for j in range(k + 1)]


def draw_circle3d(S, V, c, r, n, cls, w=1.8, back_dash='3 3', ref=None):
    """front half solid, back half dashed (back = away from the viewer, measured from ref, the centre of the solid it lies on)"""
    pts = circle3d(c, r, n); ref = ref or c
    front, back, cur, curf = [], [], [], None
    for p in pts:
        f = V.depth([p[i] - ref[i] for i in range(3)]) >= -1e-9
        if curf is None or f == curf:
            cur.append(V(p))
        else:
            (front if curf else back).append(cur); cur = [cur[-1], V(p)]
        curf = f
    (front if curf else back).append(cur)
    for seg in back: S.poly(seg, cls, w * 0.8, dash=back_dash)
    for seg in front: S.poly(seg, cls, w)


def draw_sphere(S, V, c, r, cls='sa', fill='ta'):
    cx, cy = V(c); S.circle(cx, cy, V.s * r, cls, 1.6, fill=fill)
    draw_circle3d(S, V, c, r, (0, 0, 1), cls, 1.0)


def draw_plane(S, V, n, d, half, cls='so', fill='to', centre=None):
    p0 = centre or [n[i] * d for i in range(3)]; u, w = perp_basis(n)
    corners = [[p0[i] + half * (a * u[i] + b * w[i]) for i in range(3)] for a, b in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    S.poly([V(p) for p in corners], cls, 1.2, closed=True, fill=fill)


def axes3d(S, V, L=2.6, labels=('x', 'y', 'z')):
    for i, nm in enumerate(labels):
        e = [0, 0, 0]; e[i] = L; x0, y0 = V((0, 0, 0)); x1, y1 = V(e)
        S.line(x0, y0, x1, y1, 'sl', 1.0)
        S.text(x1 + 3, y1 + 4, nm, 12, 'm')


# ================================================================ the figures
def label_order(n):
    return sorted(range(1 << n), key=lambda m: (popc(m), m))


def clip_runs(pts, box):
    """split a polyline of world points into the runs inside the box (x0, x1, y0, y1)"""
    runs, cur = [], []
    for x, y in pts:
        if box[0] <= x <= box[1] and box[2] <= y <= box[3]:
            cur.append((x, y))
        elif cur:
            runs.append(cur); cur = []
    if cur: runs.append(cur)
    return runs


def clip_line(p, d, box):
    """the segment of the line p + t d inside the box (Liang-Barsky)"""
    t0, t1 = -1e9, 1e9
    for pi, di, lo, hi in ((p[0], d[0], box[0], box[1]), (p[1], d[1], box[2], box[3])):
        if abs(di) < 1e-12:
            if pi < lo or pi > hi: return None
            continue
        a, b = (lo - pi) / di, (hi - pi) / di
        t0, t1 = max(t0, min(a, b)), min(t1, max(a, b))
    return None if t0 > t1 else ((p[0] + t0 * d[0], p[1] + t0 * d[1]), (p[0] + t1 * d[0], p[1] + t1 * d[1]))


def draw_blade2d(S, X, P2, cls, w=1.8, dash=None, box=(-3.4, 3.4, -3.4, 3.4)):
    """draw a blade of the plane z = 0 (a point, a circle or a line) on a 2D panel, clipped to the box"""
    g = C.grades(X)[0]
    if g == 1:
        x = C.loc(X)
        if box[0] <= x[0] <= box[1] and box[2] <= x[1] <= box[3]:
            S.dot(*P2(float(x[0]), float(x[1])), 3.8, 'i' if cls == 'si' else ('m' if cls == 'sm' else 'f' + cls[1:]))
        return
    if g == 3 and not C.is_flat(X):
        c, r2, n = circle_geom(X); r = math.sqrt(max(r2, 0))
        pts = [(c[0] + r * math.cos(2 * math.pi * t / 240), c[1] + r * math.sin(2 * math.pi * t / 240)) for t in range(241)]
        for run in clip_runs(pts, box): S.poly([P2(*q) for q in run], cls, w, dash=dash)
        return
    if g == 3:
        p, d = line_geom(X); seg = clip_line(p, d, box)
        if seg: S.line(*P2(*seg[0]), *P2(*seg[1]), cls, w, dash)


def panel2d(S, ox, oy, s, half):
    def P2(x, y): return ox + s * x, oy - s * y
    S.rect(ox - s * half, oy - s * half, 2 * s * half, 2 * s * half, 'zer', 'sl', 6)
    S.line(*P2(-half, 0), *P2(half, 0), 'sl', 0.8); S.line(*P2(0, -half), *P2(0, half), 'sl', 0.8)
    return P2


# ================================================================ the figures (each at most 440 wide, so that a phone shows its text at 10 px or more)
def fig_row2():
    S = Svg(420, 476, 'The three sign tables of the cell row 2')
    names = ['1', 'e₁', 'e₂', 'e₁₂']
    cases = [((1, 1), 'squares (+,+)', 'Cl(2,0) = M₂(ℝ)', 14, 52), ((-1, -1), 'squares (−,−)', 'Cl(0,2) = ℍ', 226, 52), ((0, 0), 'squares (0,0)', 'Cl(0,0,2) = Λ(ℝ²)', 120, 290)]
    cw, ch = 36, 30
    for eps, t1, t2, ox, oy in cases:
        B = BA.BR(eps)
        S.text(ox + 2.5 * cw, oy - 30, t1, 14, 'i', 'middle', bold=True); S.text(ox + 2.5 * cw, oy - 12, t2, 13, 'm', 'middle')
        zeros = neg = 0
        for a in range(4):
            S.text(ox + cw / 2, oy + (a + 1) * ch + 20, names[a], 13, 'm', 'middle')
            S.text(ox + (a + 1.5) * cw, oy + 20, names[a], 13, 'm', 'middle')
            for b in range(4):
                s = B.s(a, b); x, y = ox + (b + 1) * cw, oy + (a + 1) * ch
                S.rect(x + 1, y + 1, cw - 2, ch - 2, 'zer' if s == 0 else ('pos' if s > 0 else 'neg'))
                txt = '0' if s == 0 else (('' if s > 0 else '−') + names[a ^ b])
                S.text(x + cw / 2, y + 20, txt, 13, 'i' if s == 0 else 'bg', 'middle')
                zeros += s == 0; neg += s < 0
        S.text(ox + 2.5 * cw, oy + 5 * ch + 22, f'{zeros} zero, {neg} minus of 16', 13, 'm', 'middle')
    return S.write('fig_row2.svg')


def fig_labels():
    S = Svg(432, 404, 'The 32 labels of the cell (4,1) by grade, coloured by their square')
    cw = 70
    for k in range(6):
        labs = [a for a in range(32) if popc(a) == k]; x = 10 + k * cw
        S.text(x + 31, 20, f'grade {k}', 13, 'i', 'middle', bold=True); S.text(x + 31, 36, f'{len(labs)} label{"s" if len(labs) > 1 else ""}', 12, 'm', 'middle')
        npos = 0
        for j, a in enumerate(labs):
            s = C.A.s(a, a); npos += s > 0; y = 46 + j * 28
            S.rect(x, y, 62, 24, 'pos' if s > 0 else 'neg', rx=5)
            S.text(x + 31, y + 17, lab(a), 13, 'bg', 'middle')
        S.text(x + 31, 46 + 10 * 28 + 16, f'{npos}+ {len(labs) - npos}−', 13, 'm', 'middle')
    S.rect(60, 366, 16, 14, 'pos', rx=3); S.text(82, 378, 'square +1', 13, 'm')
    S.rect(200, 366, 16, 14, 'neg', rx=3); S.text(222, 378, 'square −1', 13, 'm')
    S.text(216, 398, 'switches e₁ e₂ e₃ e₊ e₋', 12, 'm', 'middle')
    return S.write('fig_labels.svg')


def fig_row5():
    S = Svg(420, 470, 'The six cells of row 5 on their clocks')
    types = {(5, 0): 'M₂(ℍ) ⊕ M₂(ℍ)', (4, 1): 'M₄(ℂ)', (3, 2): 'M₄(ℝ) ⊕ M₄(ℝ)', (2, 3): 'M₄(ℂ)', (1, 4): 'M₂(ℍ) ⊕ M₂(ℍ)', (0, 5): 'M₄(ℂ)'}
    for k, p in enumerate(range(5, -1, -1)):
        q = 5 - p; eps = (1,) * p + (-1,) * q; B = BA.BR(eps); w2 = B.s(31, 31); clock = (p - q) % 8
        col, row = k % 2, k // 2; cx, cy = 104 + col * 210, 76 + row * 140
        hi = (p, q) == (4, 1)
        if hi:
            S.rect(cx - 96, cy - 62, 196, 136, 'zer', 'sa', rx=10)
        S.circle(cx - 44, cy - 4, 32, 'sl', 1.2)
        for h in range(8):
            ang = math.pi / 2 - 2 * math.pi * h / 8; tx, ty = cx - 44 + 42 * math.cos(ang), cy - 4 - 42 * math.sin(ang) + 4
            S.text(tx, ty, str(h), 11, 'a' if h == clock else 'm', 'middle', bold=h == clock)
        ang = math.pi / 2 - 2 * math.pi * clock / 8
        S.line(cx - 44, cy - 4, cx - 44 + 25 * math.cos(ang), cy - 4 - 25 * math.sin(ang), 'sa', 2.6)
        S.dot(cx - 44, cy - 4, 2.5, 'a')
        S.text(cx + 10, cy - 30, f'({p},{q})', 15, 'i', bold=True)
        S.text(cx + 10, cy - 12, ''.join('+' if e > 0 else '−' for e in eps), 13, 'm')
        S.text(cx + 10, cy + 6, f'I² = {w2:+d}', 13, 'i')
        S.text(cx + 10, cy + 24, 'centre ℂ' if w2 < 0 else 'centre ℝ⊕ℝ', 13, 'i')
        S.text(cx + 4, cy + 62, types[(p, q)], 13, 'a' if hi else 'm', 'middle')
    S.text(210, 462, 'the hand points at (p − q) mod 8', 12, 'm', 'middle')
    return S.write('fig_row5.svg')


def fig_nullpair():
    S = Svg(440, 440, 'The plane of e+ and e-: the null pair and the boost of E')
    s, ox, oy = 68, 220, 240
    def P2(a, b): return ox + s * a, oy - s * b
    for t in range(-3, 4):
        S.line(*P2(t, -2.9), *P2(t, 2.9), 'sl', 0.5); S.line(*P2(-3.1, t), *P2(3.1, t), 'sl', 0.5)
    S.line(*P2(-3.1, 0), *P2(3.1, 0), 'sm', 1); S.line(*P2(0, -2.9), *P2(0, 2.9), 'sm', 1)
    S.text(*P2(3.1, 0.1), 'e₊', 14, 'm', 'end'); S.text(*P2(0.1, 2.75), 'e₋', 14, 'm')
    S.line(*P2(-2.9, -2.9), *P2(2.9, 2.9), 'sg', 1.4, '5 4'); S.line(*P2(-2.9, 2.9), *P2(2.9, -2.9), 'sg', 1.4, '5 4')
    S.text(*P2(1.6, 2.65), 'null: v² = 0', 13, 'fg')
    for sgn, nm in ((1, 'v² = +1'), (-1, 'v² = −1')):
        for br in (1, -1):
            pts = []
            for j in range(-40, 41):
                u = j / 20
                a, b = (br * math.cosh(u), math.sinh(u)) if sgn > 0 else (math.sinh(u), br * math.cosh(u))
                if abs(a) < 3.05 and abs(b) < 2.9: pts.append(P2(a, b))
            S.poly(pts, 'sm', 1.0)
        S.text(*(P2(1.9, 0.62) if sgn > 0 else P2(0.18, 1.62)), nm, 13, 'm')
    def coef(v): return float(v.get(8, 0)), float(v.get(16, 0))
    for v, nm, cls in [(C.EP, 'e₊', 'si'), (C.EM, 'e₋', 'si'), (C.EINF, 'e∞', 'sa'), (C.EO, 'eₒ', 'sa')]:
        a, b = coef(v); x1, y1 = P2(a, b); S.line(ox, oy, x1, y1, cls, 2.4); S.dot(x1, y1, 3.4, 'a' if cls == 'sa' else 'i')
        dx = 8 if a >= 0 else -10; S.text(x1 + dx, y1 - 6, nm, 15, 'a' if cls == 'sa' else 'i', 'start' if a >= 0 else 'end', bold=True)
    Dv = {0: F(3), 24: F(1)}
    for v, nm in ((C.EINF, '½ e∞'), (C.EO, '2 eₒ')):
        a, b = coef(C.sandwich(Dv, v)); x1, y1 = P2(a, b); S.dot(x1, y1, 4.4, 'fr')
        S.text(x1 + 12 if a > 0 else x1 - 10, y1 + 5 if a > 0 else y1 - 10, nm, 13, 'fr', 'start' if a > 0 else 'end', bold=True)
    E = C.op(C.EINF, C.EO)
    S.text(12, 22, f'E = e∞∧eₒ = {C.fmt(E)},  E² = {C.fmt(C.gp(E, E))}', 14, 'i')
    S.text(12, 42, f'eₒ·e∞ = {C.ffr(C.dot(C.EO, C.EINF))},  e∞² = eₒ² = 0', 14, 'i')
    S.text(12, 430, 'red: D = 3 + e₊₋ scales e∞ by ½ and eₒ by 2', 13, 'fr')
    return S.write('fig_nullpair.svg')


def fig_cone():
    S = Svg(440, 410, 'The null cone of e1, e+, e- and the parabola of the points P(x e1)')
    V = View(-28, 16, 46, 220, 296)
    def Q(a1, ap, am): return V((a1, ap, am))
    for h in (1.0, 2.0, 3.6):
        S.poly([Q(h * math.cos(t / 48 * 2 * math.pi), h * math.sin(t / 48 * 2 * math.pi), h) for t in range(49)], 'sl', 1.0)
    for t in range(0, 360, 30):
        a = math.radians(t); S.line(*Q(0, 0, 0), *Q(3.6 * math.cos(a), 3.6 * math.sin(a), 3.6), 'sl', 0.8)
    axes3d(S, V, 2.2, ('e₁', 'e₊', 'e₋'))
    band = [Q(-3, -1, 0), Q(3, -1, 0), Q(3, 2.8, 3.8), Q(-3, 2.8, 3.8)]
    S.add('<path d="M' + ' L'.join(f'{n1(x)} {n1(y)}' for x, y in band) + ' Z" class="fg" fill-opacity="0.07"/>')
    S.text(*Q(2.9, 2.8, 3.95), 'P·e∞ = −1', 13, 'fg', 'end')
    pts, ok = [], 0
    for j in range(-26, 27):
        x = F(j, 10); X = C.P((x, 0, 0)); ok += (C.gp(X, X) == {})
        pts.append(Q(float(X.get(1, 0)), float(X.get(8, 0)), float(X.get(16, 0))))
    S.poly(pts, 'sa', 2.4)
    for x in (-2, -1, 0, 1, 2):
        X = C.P((x, 0, 0)); px, py = Q(float(X.get(1, 0)), float(X.get(8, 0)), float(X.get(16, 0))); S.dot(px, py, 4, 'a')
        S.text(px + (8 if x >= 0 else -8), py - 6, f'P({x})', 13, 'a', 'start' if x >= 0 else 'end')
    a, b = Q(0, 0, 0), Q(0, 1.7, 1.7); S.line(*a, *b, 'sr', 2.4); S.text(b[0] + 6, b[1] - 4, 'e∞', 15, 'fr', bold=True)
    S.text(12, 22, 'P(x) = x e₁ + ½(x²−1) e₊ + ½(x²+1) e₋', 14, 'i')
    S.text(12, 42, f'P(x)² = 0 at {ok} of 53 points; cone: v² = 0', 13, 'm')
    return S.write('fig_cone.svg')


def fig_distance():
    S = Svg(440, 300, 'The inner product of two points against minus half their squared distance')
    ox, oy, sx, sy = 50, 36, 40, 5.4
    rng = random.Random(11); pts = []
    for _ in range(40):
        p = tuple(F(rng.randint(-6, 6), 2) for _ in range(3)); q = tuple(F(rng.randint(-6, 6), 2) for _ in range(3))
        d = math.sqrt(float(sum((a - b) ** 2 for a, b in zip(p, q)))); pts.append((d, float(C.dot(C.P(p), C.P(q)))))
    for k in range(0, 10):
        S.line(ox + k * sx, oy, ox + k * sx, oy + 45 * sy, 'sl', 0.5); S.text(ox + k * sx, oy + 45 * sy + 17, str(k), 13, 'm', 'middle')
    for v in range(0, -50, -10):
        y = oy - v * sy; S.line(ox, y, ox + 9 * sx, y, 'sl', 0.5); S.text(ox - 6, y + 4, str(v), 13, 'm', 'end')
    S.poly([(ox + (t / 20) * sx, oy + 0.5 * (t / 20) ** 2 * sy) for t in range(0, 181) if 0.5 * (t / 20) ** 2 <= 45], 'sa', 2)
    for d, v in pts:
        S.circle(ox + d * sx, oy - v * sy, 3.8, 'sr', 1.6)
    S.text(ox + 9 * sx / 2, oy + 45 * sy + 36, '|p − q|', 13, 'm', 'middle')
    S.text(ox + 12, oy + 172, 'line: −½|p − q|²', 13, 'a'); S.text(ox + 12, oy + 192, f'circles: P(p)·P(q), {len(pts)} pairs', 13, 'fr')
    S.text(ox - 40, oy - 14, 'P(p)·P(q)', 13, 'm')
    return S.write('fig_distance.svg')


def fig_tests():
    S = Svg(440, 220, 'The test x lies on it: the sign of P(x) against a dual sphere, a dual plane, an imaginary sphere')
    objs = [(C.ex_sphere((F(1, 2), 0, 0), 4), 'sphere, r 2'), (C.ex_plane((F(3, 5), F(4, 5), 0), 1), 'plane 3x + 4y = 5'), (C.ex_sphere((0, 0, 0), -1), 'r² = −1')]
    for k, (sig, title) in enumerate(objs):
        ox, oy, s = 12 + k * 146, 36, 10.4
        S.text(ox + 6 * s + 5, 22, title, 13, 'i', 'middle', bold=True)
        cnt = {1: 0, -1: 0, 0: 0}; rp, rn, rz = [], [], []
        for i in range(13):
            for j in range(13):
                x, y = F(i - 6, 2), F(6 - j, 2); v = C.dot(C.P((x, y, 0)), sig); sg = (v > 0) - (v < 0); cnt[sg] += 1
                cx, cy = ox + i * s + 5, oy + j * s + 5
                (rp if sg > 0 else rn if sg < 0 else rz).append((cx - 3.4, cy - 3.4, 6.8, 6.8))
        S.cells(rp, 'pos'); S.cells(rn, 'neg')
        for x, y, w, h in rz: S.circle(x + 3.4, y + 3.4, 4.2, 'si', 2.0)
        S.text(ox + 6 * s + 5, oy + 13 * s + 22, f'{cnt[1]} +  {cnt[-1]} −  {cnt[0]} on', 13, 'i', 'middle')
    S.text(220, 212, 'blue: P(x)·σ > 0, red: < 0, ring: = 0', 13, 'm', 'middle')
    return S.write('fig_tests.svg')


def fig_line_limit():
    S = Svg(440, 330, 'Circles through two points and a third point going to infinity tend to the line through e_inf')
    s, ox, oy = 42, 140, 108
    def P2(x, y): return ox + s * x, oy - s * y
    S.line(*P2(-3.2, 0), *P2(6.9, 0), 'sl', 0.6)
    for k in (1, 2, 4, 8):
        X = C.opns(C.P((0, 0, 0)), C.P((2, 0, 0)), C.P((1, -k, 0))); c, r2, n = circle_geom(X); r = math.sqrt(r2)
        pts = []
        for t in range(361):
            a = 2 * math.pi * t / 360; x, y = c[0] + r * math.cos(a), c[1] + r * math.sin(a)
            if -3.2 <= x <= 6.9 and -4.4 <= y <= 2.2: pts.append(P2(x, y))
            elif pts:
                S.poly(pts, 'sp', 1.2 + 0.25 * math.log2(k)); pts = []
        S.poly(pts, 'sp', 1.2 + 0.25 * math.log2(k))
        if k <= 2:
            q = P2(1, -k); S.dot(*q, 3, 'fp'); S.text(q[0] + 6, q[1] + 5, f'k = {k}: r² = {C.ffr(C.radius2(X))}', 13, 'fp')
    L = C.opns(C.P((0, 0, 0)), C.P((2, 0, 0)), C.EINF); p, d = line_geom(L)
    S.line(*P2(-3.2, p[1]), *P2(6.9, p[1]), 'sa', 2.6)
    for x in (0, 2): S.dot(*P2(x, 0), 4.2, 'i')
    S.text(*P2(-0.1, 0.25), 'a', 14, 'i', 'end', bold=True); S.text(*P2(2.1, 0.25), 'b', 14, 'i', bold=True)
    S.text(*P2(3.4, 0.25), 'a∧b∧e∞', 14, 'a', bold=True)
    S.text(12, 22, 'through a, b and (1, −k), k = 1, 2, 4, 8', 13, 'i')
    return S.write('fig_line_limit.svg')


def fig_signtable():
    S = Svg(400, 596, 'The sign table of the bit rule on the 32 labels of (4,1), and where the outer product and the contraction keep it')
    order = label_order(5); cw = 9.6; ox, oy = 36, 64
    rp, rn = [], []
    for i, a in enumerate(order):
        for j, b in enumerate(order):
            (rp if C.A.s(a, b) > 0 else rn).append((ox + j * cw, oy + i * cw, cw - 0.6, cw - 0.6))
    S.cells(rp, 'pos'); S.cells(rn, 'neg')
    starts = [0, 1, 6, 16, 26, 31, 32]
    for g in range(6):
        S.text(ox - 7, oy + (starts[g] + starts[g + 1]) / 2 * cw + 4, str(g), 12, 'm', 'end'); S.text(ox + (starts[g] + starts[g + 1]) / 2 * cw, oy - 6, str(g), 12, 'm', 'middle')
        if g: S.line(ox - 2, oy + starts[g] * cw - 0.3, ox + 32 * cw, oy + starts[g] * cw - 0.3, 'si', 0.8); S.line(ox + starts[g] * cw - 0.3, oy - 2, ox + starts[g] * cw - 0.3, oy + 32 * cw, 'si', 0.8)
    neg = sum(1 for a in range(32) for b in range(32) if C.A.s(a, b) < 0)
    S.text(ox, 22, 'the sign s(a,b): row a, column b, by grade', 14, 'i', bold=True)
    S.text(ox, 42, f'blue +1: {1024 - neg}, red −1: {neg} of 1024', 13, 'm')
    for k, (title, cond) in enumerate((('outer: a & b = 0', lambda a, b: a & b == 0), ('contraction: a ⊆ b', lambda a, b: a & b == a))):
        cw2 = 5.0; qx, qy = 36 + k * 182, 420
        keep, kp, kn = 0, [], []
        S.rect(qx - 0.5, qy - 0.5, 32 * cw2 + 0.5, 32 * cw2 + 0.5, 'zer')
        for i, a in enumerate(order):
            for j, b in enumerate(order):
                if cond(a, b):
                    keep += 1; (kp if C.A.s(a, b) > 0 else kn).append((qx + j * cw2, qy + i * cw2, cw2 - 0.3, cw2 - 0.3))
        S.cells(kp, 'pos'); S.cells(kn, 'neg')
        S.text(qx, qy - 22, title, 13, 'i', bold=True); S.text(qx, qy - 6, f'{keep} of 1024 pairs', 12, 'm')
    return S.write('fig_signtable.svg')


def fig_objects():
    S = Svg(440, 230, 'Which labels carry each object: the support of seven blades on the 32 labels')
    a, b, c, d = C.P((1, 2, 0)), C.P((-1, 1, 2)), C.P((2, -1, 1)), C.P((0, 1, -2))
    objs = [('point a', a), ('pair a∧b', C.opns(a, b)), ('circle a∧b∧c', C.opns(a, b, c)), ('sphere a∧b∧c∧d', C.opns(a, b, c, d)),
            ('flat point a∧e∞', C.op(a, C.EINF)), ('line a∧b∧e∞', C.opns(a, b, C.EINF)), ('plane a∧b∧c∧e∞', C.opns(a, b, c, C.EINF))]
    order = label_order(5); cw, ox, oy = 9.0, 142, 40
    starts = [0, 1, 6, 16, 26, 31, 32]
    S.text(ox - 8, oy - 8, 'grade', 12, 'm', 'end')
    for g in range(6):
        S.text(ox + (starts[g] + starts[g + 1]) / 2 * cw, oy - 8, str(g), 12, 'm', 'middle')
        if g: S.line(ox + starts[g] * cw - 0.5, oy - 4, ox + starts[g] * cw - 0.5, oy + 7 * 24, 'sl', 1)
    for i, (nm, X) in enumerate(objs):
        y = oy + i * 24
        S.text(ox - 8, y + 15, f'{nm} ({len(X)})', 12, 'i', 'end')
        rp, rn, rz = [], [], []
        for j, m in enumerate(order):
            v = X.get(m, 0); (rp if v > 0 else rn if v < 0 else rz).append((ox + j * cw + 0.8, y + 3, cw - 1.6, 18))
        S.cells(rz, 'zer'); S.cells(rp, 'pos'); S.cells(rn, 'neg')
    S.text(220, 222, 'blue > 0, red < 0, grey 0; (n) = labels used', 12, 'm', 'middle')
    return S.write('fig_objects.svg')


def fig_circle():
    S = Svg(440, 290, 'A circle as the meet of a sphere and a plane, and of two spheres')
    S1 = C.undual(C.ex_sphere((0, 0, 0), 4)); Pz = C.undual(C.ex_plane((0, 0, 1), 1)); S2 = C.undual(C.ex_sphere((2, 0, 0), 4))
    V = View(-30, 18, 38, 108, 160)
    draw_plane(S, V, (0, 0, 1), 1, 2.4)
    draw_sphere(S, V, (0, 0, 0), 2)
    M = C.meet(S1, Pz); c, r2, n = circle_geom(M); draw_circle3d(S, V, c, math.sqrt(r2), n, 'sg', 2.8, ref=(0, 0, 0))
    S.dot(*V(c), 3.4, 'fg')
    S.text(108, 22, 'sphere ∨ plane', 14, 'i', 'middle', bold=True)
    S.text(108, 262, f'r² = {C.ffr(C.radius2(M))}, centre ({", ".join(n1(t) for t in c)})', 13, 'fg', 'middle')
    S.text(108, 280, f'normal ({", ".join(n1(abs(t)) for t in n)})', 12, 'm', 'middle')
    V2 = View(-30, 18, 32, 300, 160)
    draw_sphere(S, V2, (0, 0, 0), 2); draw_sphere(S, V2, (2, 0, 0), 2, 'so', 'to')
    M2 = C.meet(S1, S2); c2, r22, n2 = circle_geom(M2); draw_circle3d(S, V2, c2, math.sqrt(r22), n2, 'sg', 2.8)
    S.dot(*V2(c2), 3.4, 'fg')
    S.text(330, 22, 'sphere ∨ sphere', 14, 'i', 'middle', bold=True)
    S.text(330, 262, f'r² = {C.ffr(C.radius2(M2))}, centre ({", ".join(n1(t) for t in c2)})', 13, 'fg', 'middle')
    S.text(330, 280, f'normal ({", ".join(n1(abs(t)) for t in n2)}): x = 1', 12, 'm', 'middle')
    return S.write('fig_circle.svg')


def fig_meets():
    S = Svg(440, 470, 'Four meets computed by the regressive product')
    V = [View(-30, 20, 30, 110, 120), View(-30, 20, 30, 330, 120), View(-30, 20, 30, 110, 352), View(-30, 20, 27, 312, 352)]
    Px, Py = C.undual(C.ex_plane((1, 0, 0), 1)), C.undual(C.ex_plane((0, 1, 0), 1)); Lm = C.meet(Px, Py); p, d = line_geom(Lm)
    draw_plane(S, V[0], (1, 0, 0), 1, 1.8, centre=[1, 0.4, 0]); draw_plane(S, V[0], (0, 1, 0), 1, 1.8, 'sa', 'ta', centre=[0.4, 1, 0])
    S.line(*V[0]([p[i] - 2.3 * d[i] for i in range(3)]), *V[0]([p[i] + 2.3 * d[i] for i in range(3)]), 'sg', 3)
    S.text(110, 22, 'plane ∨ plane = line', 13, 'i', 'middle', bold=True)
    S.text(110, 212, f'through ({", ".join(n1(t) for t in p)}) along e₃', 12, 'fg', 'middle')
    Pz = C.undual(C.ex_plane((0, 0, 1), 1)); Ld = C.opns(C.P((0, 0, 0)), C.P((1, 1, 1)), C.EINF); Fp = C.meet(Pz, Ld); x = flat_point(Fp)
    draw_plane(S, V[1], (0, 0, 1), 1, 1.8, centre=[0.6, 0.6, 1]); pl, dl = line_geom(Ld)
    S.line(*V[1]([pl[i] - 1.2 * dl[i] for i in range(3)]), *V[1]([pl[i] + 2.6 * dl[i] for i in range(3)]), 'sa', 2.2)
    S.dot(*V[1](x), 5, 'fg')
    S.text(330, 22, 'plane ∨ line = flat point', 13, 'i', 'middle', bold=True)
    S.text(330, 212, f'({", ".join(C.ffr(t) for t in [round(v, 9) for v in x])}) on z = 1', 12, 'fg', 'middle')
    S1 = C.undual(C.ex_sphere((0, 0, 0), 4)); Ls = C.opns(C.P((0, 0, 0)), C.P((1, 2, 2)), C.EINF); Pp = C.meet(S1, Ls); pts = C.pair_points(Pp)
    draw_sphere(S, V[2], (0, 0, 0), 2); pl, dl = line_geom(Ls)
    S.line(*V[2]([pl[i] - 2.9 * dl[i] for i in range(3)]), *V[2]([pl[i] + 2.9 * dl[i] for i in range(3)]), 'so', 2.2)
    for q in pts: S.dot(*V[2](q), 5, 'fg')
    S.text(110, 254, 'sphere ∨ line = point pair', 13, 'i', 'middle', bold=True)
    S.text(110, 444, '±(2/3, 4/3, 4/3)', 12, 'fg', 'middle')
    Cz = C.opns(C.P((2, 0, 0)), C.P((0, 2, 0)), C.P((-2, 0, 0))); S3 = C.undual(C.ex_sphere((F(12, 5), 0, 0), 4)); Pq = C.meet(Cz, S3); pts = C.pair_points(Pq)
    draw_sphere(S, V[3], (2.4, 0, 0), 2, 'so', 'to'); c, r2, n = circle_geom(Cz); draw_circle3d(S, V[3], c, math.sqrt(r2), n, 'sa', 2.2, back_dash=None)
    for q in pts: S.dot(*V[3](q), 5, 'fg')
    S.text(330, 254, 'circle ∨ sphere = point pair', 13, 'i', 'middle', bold=True)
    S.text(330, 444, '(6/5, ±8/5, 0)', 12, 'fg', 'middle')
    S.text(220, 464, 'green: X ∨ Y = ((XI⁻¹)∧(YI⁻¹))I', 12, 'm', 'middle')
    return S.write('fig_meets.svg')


def fig_versors():
    S = Svg(440, 586, 'The four moves applied by the sandwich to a point, a circle and a line')
    Cz = C.opns(C.P((F(3, 2), F(1, 2), 0)), C.P((1, 1, 0)), C.P((F(1, 2), F(1, 2), 0)))            # circle centre (1, 1/2), r 1/2
    Lz = C.opns(C.P((-2, -1, 0)), C.P((2, -1, 0)), C.EINF)                                           # the line y = -1
    pz = C.P((-1, 1, 0))
    moves = [
        ('translation', C.translator((F(1, 2), F(1, 2), 0)), 'T = 1 − ½ t e∞', '(t e∞)² = 0'),
        ('rotation', C.rotor_rot(2, 1), 'R = 2 − e₁₂', 'e₁₂² = −1'),
        ('dilation', {0: F(3), 24: F(-1)}, 'D = 3 − e₊₋', 'e₊₋² = +1'),
        ('inversion', C.ex_sphere((0, 0, 0), F(9, 4)), 'σ = eₒ − (9/8) e∞', 'σ² = 9/4, a mirror'),
    ]
    for k, (nm, V, t1, t2) in enumerate(moves):
        ox, oy = 112 + 216 * (k % 2), 152 + 282 * (k // 2); s = 28
        P2 = panel2d(S, ox, oy, s, 3.4)
        if nm == 'inversion':
            S.circle(ox, oy, 1.5 * s, 'sm', 1.2, dash='4 3')
        for X in (Cz, Lz, pz):
            draw_blade2d(S, X, P2, 'sm', 1.6)
        for X in (Cz, Lz, pz):
            draw_blade2d(S, C.sandwich(V, X), P2, 'sr', 2.4)
        S.text(ox, oy - 3.4 * s - 26, nm, 14, 'i', 'middle', bold=True)
        S.text(ox, oy - 3.4 * s - 8, t1, 13, 'i', 'middle')
        S.text(ox, oy + 3.4 * s + 19, t2, 13, 'fr', 'middle')
    S.text(220, 578, 'grey: before; red: V X Ṽ by the rule', 13, 'm', 'middle')
    return S.write('fig_versors.svg')


def fig_mirrors():
    S = Svg(440, 262, 'Two mirrors make a move: two parallel planes, two planes through an axis, two concentric spheres')
    cases = [
        ('parallel planes', (C.ex_plane((1, 0, 0), 0), C.ex_plane((1, 0, 0), F(3, 4))), 'translation'),
        ('planes through 0', (C.ex_plane((1, 0, 0), 0), C.ex_plane((F(4, 5), F(3, 5), 0), 0)), 'rotation by 2φ'),
        ('spheres at 0', (C.ex_sphere((0, 0, 0), F(1, 4)), C.ex_sphere((0, 0, 0), 1)), 'dilation by 4'),
    ]
    p0 = C.P((F(1, 4), F(1, 2), 0))
    for k, (title, (m1, m2), res) in enumerate(cases):
        ox, oy, s = 76 + 144 * k, 118, 26
        P2 = panel2d(S, ox, oy, s, 2.5)
        for m in (m1, m2):
            if C.dot(m, C.EINF) == 0:
                n = [float(m.get(b, 0)) for b in (1, 2)]; dlt = float(m.get(8, 0)); nn = math.hypot(*n); n = [t / nn for t in n]; dlt /= nn
                q = (n[0] * dlt, n[1] * dlt); u = (-n[1], n[0])
                S.line(*P2(q[0] - 2.5 * u[0], q[1] - 2.5 * u[1]), *P2(q[0] + 2.5 * u[0], q[1] + 2.5 * u[1]), 'sa', 2)
            else:
                w = -float(C.dot(m, C.EINF)); r = math.sqrt(float(C.s0(C.gp(m, m)))) / w
                S.circle(*P2(0, 0), r * s, 'sa', 2)
        p1 = C.sandwich(m1, p0); p2 = C.sandwich(m2, p1)
        for X, cl, nm in ((p0, 'i', 'x'), (p1, 'm', ''), (p2, 'fr', "x″")):
            x = C.loc(X); px, py = P2(float(x[0]), float(x[1])); S.dot(px, py, 4, cl)
            if nm: S.text(px + 6, py - 6, nm, 13, cl, bold=True)
        S.text(ox, 24, title, 13, 'i', 'middle', bold=True)
        S.text(ox, oy + 2.5 * s + 20, res, 13, 'fr', 'middle')
        xx = C.loc(p2); S.text(ox, oy + 2.5 * s + 38, f'x″ = ({C.ffr(xx[0])}, {C.ffr(xx[1])})', 12, 'm', 'middle')
    S.text(220, 254, 'x = (1/4, 1/2); grey dot: its image in the first mirror', 12, 'm', 'middle')
    return S.write('fig_mirrors.svg')


def fig_inversion():
    S = Svg(440, 470, 'A grid of lines inverted in a circle: every line becomes a circle through the centre')
    s, ox, oy = 56, 220, 252
    def P2(x, y): return ox + s * x, oy - s * y
    S.rect(ox - 3.4 * s, oy - 3.4 * s, 6.8 * s, 6.8 * s, 'zer', 'sl', 6)
    sig = C.ex_sphere((0, 0, 0), F(9, 4))
    S.circle(ox, oy, 1.5 * s, 'si', 1.6, dash='5 4')
    for k in (-3, -2, -1, 1, 2, 3):
        for L, cls in ((C.opns(C.P((k, 0, 0)), C.P((k, 1, 0)), C.EINF), 'sa'), (C.opns(C.P((0, k, 0)), C.P((1, k, 0)), C.EINF), 'so')):
            p, d = line_geom(L); seg = clip_line(p, d, (-3.4, 3.4, -3.4, 3.4))
            if seg: S.line(*P2(*seg[0]), *P2(*seg[1]), cls, 0.7, '2 3')
            Y = C.sandwich(sig, L); c, r2, n = circle_geom(Y)
            S.circle(*P2(c[0], c[1]), math.sqrt(r2) * s, cls, 1.6)
    S.dot(ox, oy, 3, 'i')
    Y = C.sandwich(sig, C.opns(C.P((1, 0, 0)), C.P((1, 1, 0)), C.EINF)); cc = C.center(Y)
    S.text(12, 22, 'the lines x = k, y = k (dotted) and their images', 13, 'i')
    S.text(12, 40, 'under the inversion in the circle r = 3/2 (dashed)', 13, 'm')
    S.text(12, 462, f'x = 1 → centre ({C.ffr(cc[0])}, {C.ffr(cc[1])}), r² = {C.ffr(C.radius2(Y))}', 13, 'm')
    return S.write('fig_inversion.svg')


def fig_pga():
    S = Svg(420, 270, 'The sign table of Cl(3,0,1) and of its image in (4,1) under e0 to e_inf')
    order = label_order(4); cw = 11.0
    for k in range(2):
        ox, oy = 26 + k * 206, 62
        rp, rn, rz = [], [], []
        for i, a in enumerate(order):
            for j, b in enumerate(order):
                if k == 0:
                    v = C.PG.s(a, b)
                else:
                    lhs = C.gp(C.phi(a), C.phi(b)); v = 0 if not lhs else C.prop(lhs, C.phi(a ^ b))
                (rp if v > 0 else rn if v < 0 else rz).append((ox + j * cw, oy + i * cw, cw - 0.8, cw - 0.8))
        S.cells(rz, 'zer'); S.cells(rp, 'pos'); S.cells(rn, 'neg')
        starts = [0, 1, 5, 11, 15, 16]
        for g in range(1, 5):
            S.line(ox - 2, oy + starts[g] * cw - 0.4, ox + 16 * cw, oy + starts[g] * cw - 0.4, 'si', 0.8)
            S.line(ox + starts[g] * cw - 0.4, oy - 2, ox + starts[g] * cw - 0.4, oy + 16 * cw, 'si', 0.8)
        S.text(ox + 8 * cw, 22, 'Cl(3,0,1)' if k == 0 else 'its image in (4,1)', 14, 'i', 'middle', bold=True)
        S.text(ox + 8 * cw, 42, f'{len(rp)} +   {len(rn)} −   {len(rz)} zero', 13, 'm', 'middle')
        for g in range(5):
            S.text(ox - 5, oy + (starts[g] + starts[g + 1]) / 2 * cw + 4, str(g), 11, 'm', 'end')
    S.text(210, 262, 'e₀ ↦ e∞ = e₊ + e₋; the tables agree entry by entry', 13, 'm', 'middle')
    return S.write('fig_pga.svg')


FIGS = [fig_row2, fig_labels, fig_row5, fig_nullpair, fig_cone, fig_distance, fig_tests, fig_line_limit, fig_signtable,
        fig_objects, fig_circle, fig_meets, fig_versors, fig_mirrors, fig_inversion, fig_pga]

if __name__ == '__main__':
    for f in FIGS:
        n = f()
        print(f'{f.__name__[4:]:12s} {n:6d} bytes')
