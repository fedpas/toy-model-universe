#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/tutorials/registry.mjs — the computed fields of content/tutorials.json, read from each tutorial's markdown source (public/<sources[0]>):
//   figures   the number of figure lines `![caption](figs/<file>.svg)` whose file exists beside the source (the lines tools/make_tutorial.mjs inlines);
//   widgets   the names of the widget lines `@@widget <name>`, in the order of the source, each once (widgets/<name>.js beside the source);
//   rows      the row ids the source cites, by ROW_RE of tools/make_tutorial.mjs (the ids the page links), sorted, each once;
//   checks    the check ids it cites that content/checks.json holds: an id with middle dots (aty·matter·1, core·B3, scw·P1c) or a dotted id of
//             checks.json (solid.K1, step_lines.MAP-021), as written; a family or a block of ids cited as a whole (gm·cym, sm16·A, aty·matter)
//             as each of its ids; a script name (core_check.py, checks/selfcheck/core_check.py) as the id of its record in checks.json; sorted,
//             each once. A middle dot whose left part is no family of checks.json (x·x, k·M_N: the prose's product sign) is not an id.
// The hand fields stay as they are: id, title, line, kind, part, html, sources, readers. It fails (exit 1, nothing written) on a row id that
// rows.json does not hold, an id with middle dots of a family of checks.json that it does not hold, a dotted id of a family of checks.json that it does not hold,
// a script path under checks/ that is no script of checks.json, a figure or widget file that is missing, or an entry without its source.
// `npm run content` does not run it: run it when a tutorial changes (its source, figures or widgets), then node tools/make_tutorial.mjs <id>;
// tests/tutorials.test.mjs fails while the registry differs from what the sources give.
//   node tools/tutorials/registry.mjs            writes the computed fields into content/tutorials.json (one-space JSON, as the tables are)
//   node tools/tutorials/registry.mjs --check    writes nothing; exit 1 when content/tutorials.json differs from what the sources give
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ROW_RE } from '../make_tutorial.mjs';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const readJSON = f => JSON.parse(fs.readFileSync(f, 'utf8'));
/** the order of the keys of an entry: the hand fields, then the computed ones, then readers */
export const KEYS = ['id', 'title', 'line', 'kind', 'part', 'html', 'sources', 'figures', 'widgets', 'rows', 'checks', 'readers'];
export const COMPUTED = ['figures', 'widgets', 'rows', 'checks'];
export const FIG_LINE = /^!\[([^\]]*)\]\((figs\/[A-Za-z0-9_./-]+\.svg)\)\s*$/;
export const WIDGET_LINE = /^@@widget\s+([a-z][a-z0-9_-]*)\s*$/;
// an id with middle dots: a family, then one or more parts (core·B3, bd·mjp·31, aty·matter·1)
const MID_RE = /(?<![\w·./-])([a-z][a-z0-9_]*(?:·[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*)+)(?![\w·])/g;
// a dotted id: a family, a dot, then parts (solid.K1, step_lines.MAP-021, leaves.field.test); file names are told apart by their extension
const DOT_RE = /(?<![\w·./-])([a-z][a-z0-9_]*(?:\.[A-Za-z0-9_]+(?:-[A-Za-z0-9_]+)*)+)(?![\w·-])/g;
const EXT = /\.(py|mjs|js|jsx|json|jsonl|log|md|svg|html|txt|css|sh|png|tsv|zip)$/;
// a script name: a path of words ending in .py, .mjs or .js
const SCRIPT_RE = /(?<![\w./-])((?:[\w-]+\/)*[\w-]+\.(?:py|mjs|js))(?![\w.-])/g;

/** the check index of content/checks.json: the ids with dots of every record, its records by id, script path and unique basename */
export function checkIndex(root = ROOT) {
  const checks = readJSON(path.join(root, 'content/checks.json'));
  const ids = new Set(), families = new Set(), midFamilies = new Set(), scripts = new Map(), base = new Map();
  for (const c of checks) {
    for (const x of c.ids || []) { ids.add(x.id); const d = /^([a-z][a-z0-9_]*)\.[A-Z0-9]/.exec(x.id); if (d && !x.id.includes('·')) families.add(d[1]); if (x.id.includes('·')) midFamilies.add(x.id.split('·')[0]); }
    for (const k of [c.id, c.script, String(c.script || '').replace(/^checks\//, '')]) if (k) scripts.set(k, c.id);
    const b = path.basename(String(c.script || c.id));
    base.set(b, base.has(b) && base.get(b) !== c.id ? null : c.id);
  }
  return { ids, families, midFamilies, scripts, base, records: new Set(checks.map(c => c.id)) };
}

/** what a source gives: { figures, widgets, rows, checks, problems } (problems: the reasons the registry cannot hold this source) */
export function sourceFacts(entry, { root = ROOT, rows = null, index = null } = {}) {
  const problems = [];
  const srcRel = entry && Array.isArray(entry.sources) ? entry.sources[0] : null;
  const srcFile = srcRel ? path.join(root, 'public', srcRel) : null;
  if (!srcFile || !fs.existsSync(srcFile)) return { figures: 0, widgets: [], rows: [], checks: [], problems: [`${entry && entry.id}: the source ${srcRel || '(none)'} is missing`] };
  const dir = path.dirname(srcFile), text = fs.readFileSync(srcFile, 'utf8');
  const rowIds = rows || new Set(readJSON(path.join(root, 'content/rows.json')).map(r => r.id));
  const ix = index || checkIndex(root);
  let figures = 0; const widgets = [];
  for (const line of text.split('\n')) {
    let m = FIG_LINE.exec(line);
    if (m) { if (fs.existsSync(path.join(dir, m[2]))) figures++; else problems.push(`${entry.id}: the figure ${m[2]} is missing`); continue; }
    m = WIDGET_LINE.exec(line);
    if (m) { if (!fs.existsSync(path.join(dir, 'widgets', m[1] + '.js'))) problems.push(`${entry.id}: the widget widgets/${m[1]}.js is missing`); if (!widgets.includes(m[1])) widgets.push(m[1]); }
  }
  const cited = new Set();
  for (const m of text.matchAll(new RegExp(ROW_RE.source, 'g'))) cited.add(m[1]);
  for (const id of cited) if (!rowIds.has(id)) problems.push(`${entry.id}: the row ${id} is not a row of content/rows.json`);
  const checks = new Set();
  for (const m of text.matchAll(MID_RE)) {
    const id = m[1], fam = id.split('·')[0];
    if (ix.ids.has(id)) { checks.add(id); continue; }
    if (!ix.midFamilies.has(fam)) continue;                                // a middle dot of the prose (x·x, k·M_N): its left part is no family of checks.json
    const block = [...ix.ids].filter(x => x.startsWith(id + '·') || (x.startsWith(id) && /^\d+$/.test(x.slice(id.length))));
    if (block.length) { for (const x of block) checks.add(x); continue; }  // a family or a block cited as a whole (gm·cym, sm16·A, aty·matter) cites each of its ids
    problems.push(`${entry.id}: the check id ${id} is not in content/checks.json`);
  }
  for (const m of text.matchAll(DOT_RE)) {
    const t = m[1];
    if (EXT.test(t)) continue;
    if (ix.ids.has(t)) { checks.add(t); continue; }
    const fam = /^([a-z][a-z0-9_]*)\.[A-Z0-9]/.exec(t);
    if (fam && ix.families.has(fam[1])) problems.push(`${entry.id}: the check id ${t} is not in content/checks.json (the family ${fam[1]} is)`);
  }
  for (const m of text.matchAll(SCRIPT_RE)) {
    const t = m[1];
    const id = ix.scripts.get(t) || ix.scripts.get(t.replace(/^checks\//, '')) || (t.includes('/') ? null : ix.base.get(t));
    if (id) checks.add(id);
    else if (/^checks\//.test(t)) problems.push(`${entry.id}: the script ${t} is not a script of content/checks.json`);
  }
  const sort = a => [...a].sort((x, y) => x.localeCompare(y, 'en'));
  return { figures, widgets, rows: sort([...cited].filter(id => rowIds.has(id))), checks: sort(checks), problems };
}

/** an entry with its computed fields from its source, its keys in the order of KEYS (unknown keys kept after them) */
export function filled(entry, facts) {
  const out = {};
  const all = { ...entry, figures: facts.figures, widgets: facts.widgets, rows: facts.rows, checks: facts.checks };
  for (const k of KEYS) if (k in all) out[k] = all[k];
  for (const k of Object.keys(entry)) if (!(k in out)) out[k] = entry[k];
  return out;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const check = process.argv.includes('--check');
  const file = path.join(ROOT, 'content/tutorials.json');
  const entries = readJSON(file);
  const rows = new Set(readJSON(path.join(ROOT, 'content/rows.json')).map(r => r.id)), index = checkIndex(ROOT);
  const problems = [], out = [];
  const seen = new Set();
  for (const e of entries) {
    if (!e || typeof e.id !== 'string' || !e.id) { problems.push('an entry without an id'); continue; }
    if (seen.has(e.id)) problems.push(`${e.id}: the id is used twice`);
    seen.add(e.id);
    const f = sourceFacts(e, { rows, index });
    problems.push(...f.problems);
    out.push(filled(e, f));
    console.log(`${e.id}: ${f.figures} figure(s), ${f.widgets.length} widget(s) (${f.widgets.join(', ') || 'none'}), ${f.rows.length} row id(s), ${f.checks.length} check id(s)`);
  }
  if (problems.length) { for (const p of problems) console.error('registry: ' + p); console.error(`registry: ${problems.length} problem(s); content/tutorials.json not ${check ? 'checked' : 'written'}`); process.exit(1); }
  const json = JSON.stringify(out, null, 1) + '\n';
  if (check) { const same = fs.readFileSync(file, 'utf8') === json; console.log(`${same ? 'current' : 'OUT OF DATE'}  content/tutorials.json (${out.length} entries)`); process.exit(same ? 0 : 1); }
  fs.writeFileSync(file, json);
  console.log(`registry: content/tutorials.json written (${out.length} entries)`);
}
