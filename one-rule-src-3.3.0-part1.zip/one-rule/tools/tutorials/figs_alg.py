#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""figs_alg.py: draws every figure in figs/ for the tutorial "Algebra on the bit rule".

    python3 -I -B figs_alg.py            (from any directory)

The repository is found by walking up from this file (or from ATLAS_REPO). The rule is the Atlas's own code:
checks/selfcheck/steps15_17/bitcliff.py (the bit rule e_a e_b = s(a,b) e_{a xor b}) and checks/selfcheck/proofs/composition_basis.py
(the Cayley-Dickson octonions). What this script does not recompute it reads from a shipped log (solid_cube.log, aty_twisted_k.log,
e_ladder.log, aty_matter_models.log, cat_check.log, check_T10.log, en_weyl.log); every recomputed number is checked against the log or the
row that states it, and the script stops if one disagrees. The SVG is written by hand: text as text, no raster, the same bytes on every run.
"""
import os, sys, math, re, importlib.util
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))



def find_repo():
    cands = [os.environ['ATLAS_REPO']] if os.environ.get('ATLAS_REPO') else []
    cands.append(os.path.join(HERE, '..', '..'))
    d = HERE
    for _ in range(10):
        cands.append(d)
        d = os.path.dirname(d)
    for c in cands:
        if os.path.isfile(os.path.join(c, 'checks', 'selfcheck', 'steps15_17', 'bitcliff.py')):
            return os.path.normpath(c)
    sys.exit('figs_alg.py: the repository (checks/selfcheck/steps15_17/bitcliff.py) was not found; set ATLAS_REPO')


REPO = find_repo()
OUT = os.path.join(REPO, 'public', 'reports', 'tutorials', 'src', 'alg', 'figs')   # the figures, beside the tutorial's source


def load(rel, name):
    spec = importlib.util.spec_from_file_location(name, os.path.join(REPO, rel))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


bc = load('checks/selfcheck/steps15_17/bitcliff.py', 'bitcliff')          # the bit rule
cb = load('checks/selfcheck/proofs/composition_basis.py', 'comp_basis')    # Cayley-Dickson octonions, Albuquerque-Majid cochain

LOGS = {'solid': 'checks/selfcheck/proofs/logs/solid_cube.log', 'atyk': 'checks/selfcheck/proofs/logs/aty_twisted_k.log',
        'elad': 'checks/selfcheck/proofs/logs/e_ladder.log', 'matter': 'checks/selfcheck/gravity/logs/aty_matter_models.log',
        'cat': 'checks/selfcheck/proofs/logs/reruns/cat_check.log', 'T10': 'checks/selfcheck/proofs/logs/reruns/check_T10.log',
        'T6': 'checks/selfcheck/proofs/logs/reruns/check_T6.log', 'enw': 'checks/selfcheck/proofs/logs/reruns/en_weyl.log',
        'comp': 'checks/selfcheck/proofs/logs/composition_basis.log'}
_logs = {}


def log(key):
    if key not in _logs:
        with open(os.path.join(REPO, LOGS[key]), encoding='utf-8') as fh:
            _logs[key] = fh.read()
    return _logs[key]


def grab(key, pattern):
    m = re.search(pattern, log(key))
    if not m:
        sys.exit('figs_alg.py: no line /%s/ in %s' % (pattern, LOGS[key]))
    return m


def ints(s):
    return [int(t) for t in re.findall(r'-?\d+', s)]


REPORT = []


def check(cond, what):
    if not cond:
        sys.exit('figs_alg.py: CHECK FAILED: ' + what)
    REPORT.append(what)


# ------------------------------------------------------------------ names and numbers
SUB = str.maketrans('0123456789', '₀₁₂₃₄₅₆₇₈₉')


def bname(a, base=1):
    if a == 0:
        return '1'
    return 'e' + ''.join(str(i + base) for i in range(16) if a >> i & 1).translate(SUB)


def pc(x):
    return bin(x).count('1')


def fm(x):
    s = '%.2f' % x
    s = s.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '', '-') else s


def markup(s):
    """escape, then _{x} as a subscript, ^{x} as a superscript, and the operators at a smaller size"""
    t = esc(s)
    t = re.sub(r'_\{([^{}]*)\}', r'<tspan class="sb" baseline-shift="sub">\1</tspan>', t)
    t = re.sub(r'\^\{([^{}]*)\}', r'<tspan class="sp" baseline-shift="super">\1</tspan>', t)
    return re.sub('([⊕⊗])', r'<tspan class="op">\1</tspan>', t)


def esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


SIGN = {1: '+', -1: '−', 0: '0'}
TYPE_CLS = {'R': 'fR', 'C': 'fC', 'H': 'fH'}
TYPE_SYM = {'R': 'ℝ', 'C': 'ℂ', 'H': 'ℍ'}

# ------------------------------------------------------------------ the SVG writer
STYLE = ('svg.ag{--agR:#2a78d6;--agC:#eb6834;--agH:#1baf7a;--agN:#8a8980}'
         '@media (prefers-color-scheme: dark){:root:not([data-theme="light"]) svg.ag{--agR:#3987e5;--agC:#d95926;--agH:#199e70;--agN:#8f8e86}}'
         ':root[data-theme="dark"] svg.ag{--agR:#3987e5;--agC:#d95926;--agH:#199e70;--agN:#8f8e86}'
         '.ag text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;font-size:13px;fill:var(--ink,#1a1a19)}'
         '.ag .t2{fill:var(--ink2,#46463f)}.ag .mu{fill:var(--muted,#6b6b64)}.ag .b{font-weight:600}.ag .it{font-style:italic}'
         '.ag .s10{font-size:10.5px}.ag .s11{font-size:11.5px}.ag .s12{font-size:12.5px}.ag .s14{font-size:14px}.ag .s15{font-size:15px}.ag .s17{font-size:17px}'
         '.ag .ln{stroke:var(--line2,#c9c8c0);fill:none}.ag .gr{stroke:var(--line,#e3e2dc);fill:none}.ag .lk{stroke:var(--ink2,#46463f);fill:none}'
         '.ag .bg{fill:var(--tint,#f3f2ee)}.ag .sf{fill:var(--surf,#ffffff)}.ag .ik{fill:var(--ink2,#46463f)}'
         '.ag .fR{fill:var(--agR)}.ag .fC{fill:var(--agC)}.ag .fH{fill:var(--agH)}.ag .fN{fill:var(--agN)}'
         '.ag .sR{stroke:var(--agR);fill:none}.ag .sC{stroke:var(--agC);fill:none}.ag .sH{stroke:var(--agH);fill:none}.ag .sN{stroke:var(--agN);fill:none}'
         '.ag .o1{fill-opacity:.14}.ag .o2{fill-opacity:.28}.ag .o3{fill-opacity:.45}.ag .o4{fill-opacity:.7}'
         '.ag .sb,.ag .sp{font-size:72%}.ag .op{font-size:64%}'
         '.ag .ol{fill:none;stroke:var(--ink,#1a1a19);stroke-width:1.8}.ag .w2{stroke-width:2}.ag .w3{stroke-width:3}.ag .da{stroke-dasharray:5 4}')


class SVG:
    def __init__(self, w, h, title, zoom=1.25):
        self.w, self.h, self.title, self.zoom = w, h, title, zoom
        self.items = []

    def add(self, s):
        self.items.append(s)

    def rect(self, x, y, w, h, cls='sf', rx=0):
        self.add('<rect x="%s" y="%s" width="%s" height="%s"%s class="%s"/>' % (fm(x), fm(y), fm(w), fm(h), ' rx="%s"' % fm(rx) if rx else '', cls))

    def text(self, x, y, s, cls='', anchor='middle'):
        a = '' if anchor == 'start' else ' text-anchor="%s"' % anchor
        self.add('<text x="%s" y="%s"%s%s>%s</text>' % (fm(x), fm(y), a, ' class="%s"' % cls if cls else '', markup(s)))

    def line(self, x1, y1, x2, y2, cls='ln'):
        self.add('<line x1="%s" y1="%s" x2="%s" y2="%s" class="%s"/>' % (fm(x1), fm(y1), fm(x2), fm(y2), cls))

    def circle(self, x, y, r, cls='sf'):
        self.add('<circle cx="%s" cy="%s" r="%s" class="%s"/>' % (fm(x), fm(y), fm(r), cls))

    def path(self, d, cls='ln'):
        self.add('<path d="%s" class="%s"/>' % (d, cls))

    def poly(self, pts, cls):
        self.add('<polygon points="%s" class="%s"/>' % (' '.join('%s,%s' % (fm(x), fm(y)) for x, y in pts), cls))

    def arrowhead(self, x, y, ang, cls='ik', size=7):
        # a small filled triangle at (x, y) pointing along the angle ang (radians)
        c, s = math.cos(ang), math.sin(ang)
        p1 = (x + size * c, y + size * s)
        p2 = (x - size * 0.6 * c + size * 0.55 * s, y - size * 0.6 * s - size * 0.55 * c)
        p3 = (x - size * 0.6 * c - size * 0.55 * s, y - size * 0.6 * s + size * 0.55 * c)
        self.poly([p1, p2, p3], cls)

    def render(self):
        W = min(round(self.w * self.zoom), 720)
        H = round(self.h * W / self.w)
        head = ('<svg xmlns="http://www.w3.org/2000/svg" class="ag" viewBox="0 0 %d %d" width="%d" height="%d" role="img" aria-label="%s">'
                % (self.w, self.h, W, H, esc(self.title)))
        return head + '<title>%s</title><style>%s</style>' % (esc(self.title), STYLE) + ''.join(self.items) + '</svg>\n'


WRITTEN = []


def save(name, svg):
    os.makedirs(OUT, exist_ok=True)
    data = svg.render().encode('utf-8')
    check(len(data) < 80000, '%s: %d bytes (< 80 kB)' % (name, len(data)))
    with open(os.path.join(OUT, name), 'wb') as fh:
        fh.write(data)
    WRITTEN.append((name, len(data)))


def sign_cell(s):
    return {1: ('+', 'fR o2'), -1: ('−', 'fC o3'), 0: ('0', 'bg')}[s]


def grid(S, x, y, cw, ch, rowlab, collab, cells, hw=None, hh=None, labcls='s11 t2', cellcls='s12'):
    """a table: header row and column, cells[i][j] = (text, fill class, outline?)"""
    hw = cw if hw is None else hw
    hh = ch if hh is None else hh
    for j, t in enumerate(collab):
        S.text(x + hw + j * cw + cw / 2, y + hh / 2 + 4, t, labcls)
    for i, t in enumerate(rowlab):
        S.text(x + hw / 2, y + hh + i * ch + ch / 2 + 4, t, labcls)
    for i, row in enumerate(cells):
        for j, cell in enumerate(row):
            t, fc = cell[0], cell[1]
            X, Y = x + hw + j * cw, y + hh + i * ch
            S.rect(X + 1, Y + 1, cw - 2, ch - 2, fc or 'sf', rx=3)
            if len(cell) > 2 and cell[2]:
                S.rect(X + 1.5, Y + 1.5, cw - 3, ch - 3, 'ol', rx=3)
            if t:
                S.text(X + cw / 2, Y + ch / 2 + 4.5, t, cellcls)
    return x + hw + len(collab) * cw, y + hh + len(rowlab) * ch


def legend(S, x, y, items, size=12):
    """items: (fill class, label); returns the x after the last item"""
    for cls, lab in items:
        S.rect(x, y - 10, 14, 14, cls, rx=3)
        S.text(x + 19, y + 1.5, lab, 's11 t2', 'start')
        x += 24 + 6.2 * len(lab)
    return x + 6


# ------------------------------------------------------------------ F1: one rule, three algebras at n = 2
def fig_three_n2():
    labs = [bname(a) for a in range(4)]
    cases = [((1, 1), 'squares (+,+): Cl(2,0) = M₂(ℝ)'), ((-1, -1), 'squares (−,−): Cl(0,2) = ℍ'), ((0, 0), 'squares (0,0): Cl(0,0,2) = Λ(ℝ²)')]
    counts = []
    S = SVG(396, 420, 'One rule, three algebras at n = 2: the label table and three sign tables')
    cw, ch, hw = 34, 25, 30
    # panel 0: the labels
    S.text(10, 18, 'label of eₐ e_{b}: a ⊕ b', 's12 b', 'start')
    S.text(10, 33, 'the same for all squares', 's11 mu', 'start')
    grid(S, 10, 40, cw, ch, labs, labs, [[(bname(a ^ b), 'bg') for b in range(4)] for a in range(4)], hw=hw)
    pos = [(206, 0), (10, 196), (206, 196)]
    for (eps, title), (px, py) in zip(cases, pos):
        A = bc.Alg(eps)
        sg = [[A.blade_mul(a, b)[0] for b in range(4)] for a in range(4)]
        neg = sum(s == -1 for r in sg for s in r)
        zer = sum(s == 0 for r in sg for s in r)
        counts.append((neg, zer))
        t1, t2 = title.split(': ')
        S.text(px, py + 18, t1, 's12 b', 'start')
        S.text(px, py + 33, t2, 's11 t2', 'start')
        grid(S, px, py + 40, cw, ch, labs, labs, [[sign_cell(s) for s in r] for r in sg], hw=hw, cellcls='s14 b')
        S.text(px, py + 40 + 5 * ch + 15, 'sign −: %d · zero: %d of 16' % (neg, zer), 's11 mu', 'start')
    check(counts == [(4, 0), (6, 0), (1, 7)], 'F1 n = 2: minus signs 4, 6, 1 and zeros 0, 0, 7 (Part 0 of the shipped tutorial, scw·P1c)')
    legend(S, 12, 408, [('fR o2', 'sign +'), ('fC o3', 'sign −'), ('bg', '0: the product vanishes')])
    save('f01_three_n2.svg', S)


# ------------------------------------------------------------------ F2: the cube of labels at n = 3 and the Jordan-Wigner signs
def fig_cube():
    A = bc.Alg((1, 1, 1))
    ox, oy = 52, 262
    vec = [(150, 0), (0, -150), (70, -62)]
    P = {a: (ox + sum(vec[i][0] for i in range(3) if a >> i & 1), oy + sum(vec[i][1] for i in range(3) if a >> i & 1)) for a in range(8)}
    S = SVG(340, 372, 'The cube of labels at n = 3, its edges signed by the bit rule')
    edges = []
    for a in range(8):
        for i in range(3):
            if not a >> i & 1:
                s, c = A.blade_mul(1 << i, a)
                check(c == a | 1 << i, 'F2 the label of e_i e_a is a xor i')
                check(s == (-1) ** pc(a & ((1 << i) - 1)), 'F2 the sign of e_i e_a is the Jordan-Wigner sign (T6 (a))')
                edges.append((a, a | 1 << i, i, s))
    # every square face anticommutes: an odd number of minus edges
    faces = 0
    for a in range(8):
        for i in range(3):
            for j in range(i + 1, 3):
                if not (a >> i & 1 or a >> j & 1):
                    sq = [s for (u, v, k, s) in edges if (u, v) in ((a, a | 1 << i), (a | 1 << i, a | 1 << i | 1 << j), (a, a | 1 << j), (a | 1 << j, a | 1 << i | 1 << j))]
                    check(len(sq) == 4 and sq[0] * sq[1] * sq[2] * sq[3] == -1, 'F2 a face of the cube has sign product -1')
                    faces += 1
    check(faces == 6, 'F2 six faces, each with sign product -1')
    check(sum(1 for e in edges if e[3] == -1) == 4 and len(edges) == 12, 'F2 12 edges, 4 of them minus')
    hidden = {(0, 4), (4, 5), (4, 6)}
    for (u, v, i, s) in sorted(edges, key=lambda e: (e[3], e[0], e[1])):
        (x1, y1), (x2, y2) = P[u], P[v]
        cls = ('sR w3' if s == 1 else 'sC w3 da') + ''
        S.line(x1, y1, x2, y2, cls)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        S.circle(mx, my, 9, 'sf')
        S.circle(mx, my, 9, 'sR' if s == 1 else 'sC')
        S.text(mx, my + 4.5, SIGN[s], 's14 b')
    for a in range(8):
        x, y = P[a]
        S.circle(x, y, 19, 'sf')
        S.circle(x, y, 19, 'lk')
        S.text(x, y + 4.5, bname(a), 's12 b')
    S.text(8, 300, 'edge a → a + i: the sign in eᵢ eₐ = ± e_{a+i}', 's11 t2', 'start')
    S.text(8, 316, '= (−1)^{N}, N = the number of j in a with j < i', 's11 t2', 'start')
    S.text(8, 336, 'each of the 6 faces carries an odd number of − edges:', 's11 t2', 'start')
    S.text(8, 352, 'eᵢ eⱼ = −eⱼ eᵢ. The 2⁷ = 128 sign choices that do this', 's11 t2', 'start')
    S.text(8, 368, 'are one gauge orbit (check_T6, H1).', 's11 t2', 'start')
    t6 = grab('T6', r'3-cube brute force: (\d+) = 2\^7 anticommuting assignments = one gauge orbit')
    check(int(t6.group(1)) == 128, 'F2 check_T6.log: 128 = 2^7 anticommuting sign choices on the 3-cube, one gauge orbit')
    save('f02_cube_signs.svg', S)


# ------------------------------------------------------------------ F3: Cl(2,0), its matrices, a gauge and its coboundary
def fig_cl20_gauge():
    A = bc.Alg((1, 1))
    labs = [bname(a) for a in range(4)]
    sg = [[A.blade_mul(a, b) for b in range(4)] for a in range(4)]
    # the matrices of Part 0: e1 = diag(1, -1), e2 = [[0, 1], [1, 0]]
    def mm(X, Y):
        return [[sum(X[i][k] * Y[k][j] for k in range(2)) for j in range(2)] for i in range(2)]
    M = {0: [[1, 0], [0, 1]], 1: [[1, 0], [0, -1]], 2: [[0, 1], [1, 0]]}
    M[3] = mm(M[1], M[2])
    for a in range(4):
        for b in range(4):
            s, c = sg[a][b]
            check(mm(M[a], M[b]) == [[s * t for t in r] for r in M[c]], 'F3 the 2 x 2 matrices multiply as the Cl(2,0) table')
    S = SVG(410, 384, 'Cl(2,0): its table, its matrices, a gauge and its coboundary')
    S.text(10, 17, 'Cl(2,0): row a, column b: eₐ e_{b}', 's12 b', 'start')
    cells = [[(('+' if s == 1 else '−') + bname(c), 'fR o2' if s == 1 else 'fC o3') for (s, c) in r] for r in sg]
    grid(S, 10, 24, 40, 26, labs, labs, cells, hw=30)
    # the matrices
    S.text(222, 17, 'in 2 × 2 matrices', 's12 b', 'start')
    for k, a in enumerate(range(4)):
        x0, y0 = 246 + (k % 2) * 86, 34 + (k // 2) * 62
        S.text(x0 + 2, y0 + 27, bname(a) + ' =', 's12', 'end')
        S.path('M%s %s h-4 v40 h4' % (fm(x0 + 10), fm(y0 + 2)), 'lk')
        S.path('M%s %s h4 v40 h-4' % (fm(x0 + 54), fm(y0 + 2)), 'lk')
        for i in range(2):
            for j in range(2):
                v = M[a][i][j]
                S.text(x0 + 22 + 20 * j, y0 + 17 + 19 * i, ('−' if v < 0 else '') + str(abs(v)), 's12')
    S.text(222, 166, 'four independent matrices:', 's11 t2', 'start')
    S.text(222, 181, 'Cl(2,0) = M₂(ℝ)', 's11 t2', 'start')
    # the gauge
    f = [1, 1, 1, -1]
    df = [[f[a] * f[b] * f[a ^ b] for b in range(4)] for a in range(4)]
    s2 = [[sg[a][b][0] * df[a][b] for b in range(4)] for a in range(4)]
    for a in range(4):
        check(s2[a][a] == sg[a][a][0], 'F3 the gauge keeps the square of every blade')
        for b in range(4):
            check(s2[a][b] * s2[b][a] == sg[a][b][0] * sg[b][a][0], 'F3 the gauge keeps every commutation sign')
    y = 198
    S.text(10, y, 'a gauge: e₁₂ ↦ −e₁₂ (f = +, +, +, −)', 's12 b', 'start')
    S.text(10, y + 16, 'its coboundary f(a) f(b) f(a ⊕ b)', 's11 t2', 'start')
    S.text(214, y + 16, 'the new signs: s · coboundary', 's11 t2', 'start')
    grid(S, 10, y + 22, 34, 25, labs, labs, [[sign_cell(v) for v in r] for r in df], hw=30, cellcls='s14 b')
    grid(S, 214, y + 22, 34, 25, labs, labs, [[sign_cell(v) + ((v != sg[i][j][0]),) for j, v in enumerate(r)] for i, r in enumerate(s2)], hw=30, cellcls='s14 b')
    changed = sum(s2[a][b] != sg[a][b][0] for a in range(4) for b in range(4))
    check(changed == 6, 'F3 the gauge e12 -> -e12 changes 6 of the 16 signs')
    S.text(214, y + 22 + 5 * 25 + 16, '%d entries change (outlined);' % changed, 's11 mu', 'start')
    S.text(214, y + 22 + 5 * 25 + 31, 'no square, no commutation sign', 's11 mu', 'start')
    # the same invariance at n = 3: 128 gauges, 8 choices of squares
    ok = 0
    for e in range(8):
        eps = tuple(-1 if e >> i & 1 else 1 for i in range(3))
        B = bc.Alg(eps)
        base = [[B.blade_mul(a, b)[0] for b in range(8)] for a in range(8)]
        for g in range(128):
            ff = [1] + [-1 if g >> (a - 1) & 1 else 1 for a in range(1, 8)]
            s3 = [[base[a][b] * ff[a] * ff[b] * ff[a ^ b] for b in range(8)] for a in range(8)]
            if all(s3[a][a] == base[a][a] for a in range(8)) and all(s3[a][b] * s3[b][a] == base[a][b] * base[b][a] for a in range(8) for b in range(8)):
                ok += 1
    check(ok == 8 * 128, 'F3 n = 3: all 128 gauges keep the squares and commutation signs, for all 8 choices of squares +-1')
    save('f03_cl20_gauge.svg', S)


# ------------------------------------------------------------------ the 36 cells of solid_cube.log and the pairs of cat_check.log
def solid_cells():
    pat = (r'solid\.K1: Cl\((\d),(\d)\), clock (\d): minimal module of real dimension (\d+) \(k = (\d+) idempotent factors\), '
           r'commutant of dimension (\d), type ([RCH]), simple summands (\d)')
    out = {}
    for m in re.finditer(pat, log('solid')):
        p, q, c, dim, k, cd, t, ns = m.groups()
        out[(int(p), int(q))] = dict(clock=int(c), dim=int(dim), k=int(k), cdim=int(cd), type=t, summands=int(ns))
    check(len(out) == 36, 'solid_cube.log solid.K1: 36 cells p + q <= 7')
    for (p, q), d in out.items():
        check(d['clock'] == (p - q) % 8, 'solid.K1 the clock is p - q mod 8')
    return out


def clock_pairs():
    m = grab('cat', r'C1: .*?c=0: (\w+)/(\w+); c=1: (\w+)/(\w+); c=2: (\w+)/(\w+); c=3: (\w+)/(\w+); c=4: (\w+)/(\w+); c=5: (\w+)/(\w+); c=6: (\w+)/(\w+); c=7: (\w+)/(\w+)')
    g = m.groups()
    return [(g[2 * c], g[2 * c + 1]) for c in range(8)]


def tname(t):
    return (TYPE_SYM[t[0]] + ' ⊕ ' + TYPE_SYM[t[0]]) if t.endswith('2') else TYPE_SYM[t]


# ------------------------------------------------------------------ F4: the clock wheel
def fig_clock_wheel():
    cells = solid_cells()
    pairs = clock_pairs()
    for (p, q), d in cells.items():
        t = pairs[d['clock']][0]
        check(d['type'] == t[0] and d['summands'] == (2 if t.endswith('2') else 1), 'F4 solid.K1 type and summands agree with cat·C1 at the clock')
        if q >= 1 and (p, q - 1) in cells:       # the even part of Cl(p,q) is Cl(p,q-1) (Thm T5 (a)): its type is the second entry of the pair
            e, te = cells[(p, q - 1)], pairs[d['clock']][1]
            check(e['type'] == te[0] and e['summands'] == (2 if te.endswith('2') else 1), 'F4 the even part Cl(p,q-1) of solid.K1 has the type cat·C1 lists second')
    S = SVG(404, 420, 'The clock: the type of Cl(p,q) and of its even part by c = p − q mod 8')
    cx, cy, R = 202, 214, 140
    S.circle(cx, cy, R, 'ln')
    S.circle(cx, cy, R - 62, 'gr')
    for c in range(8):
        ang = -math.pi / 2 + c * math.pi / 4
        x, y = cx + R * math.cos(ang), cy + R * math.sin(ang)
        t, te = pairs[c]
        two = t.endswith('2')
        S.circle(x, y, 33, 'sf')
        S.circle(x, y, 33, TYPE_CLS[t[0]] + (' o3' if two else ' o1'))
        if two:
            S.circle(x, y, 29, 'lk')
        S.text(x, y - 8, 'c = %d' % c, 's11 t2')
        S.text(x, y + 9, tname(t), 's14 b')
        ex = sorted([pq for pq, d in cells.items() if d['clock'] == c], key=lambda pq: (pq[0] + pq[1], pq[1]))[:2]
        S.text(x, y + 23, ', '.join('%d,%d' % pq for pq in ex), 's10 mu')
        xi, yi = cx + (R - 62) * math.cos(ang), cy + (R - 62) * math.sin(ang)
        S.rect(xi - 25, yi - 10, 50, 19, TYPE_CLS[te[0]] + ' o1', rx=9)
        S.text(xi, yi + 4, tname(te), 's11 t2')
    S.text(cx, cy - 6, 'outer: Cl(p,q)', 's12 b')
    S.text(cx, cy + 10, 'inner: its even part', 's11 t2')
    S.text(cx, cy + 25, 'small: (p,q) of two cells', 's10 mu')
    S.text(10, 18, 'add a generator of square +1: one step clockwise', 's11 t2', 'start')
    S.text(10, 34, 'add a generator of square −1: one step back', 's11 t2', 'start')
    lx = legend(S, 12, 410, [('fR o2', 'ℝ'), ('fC o2', 'ℂ'), ('fH o2', 'ℍ')])
    S.text(lx + 4, 411, 'double ring: two copies (c = 1, 5)', 's11 mu', 'start')
    save('f04_clock_wheel.svg', S)


# ------------------------------------------------------------------ F5: the clock's phase, the Gauss sum of the labels
def gmul(a, b):
    return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])


def gpow(z, k):
    out = (1, 0)
    for _ in range(k):
        out = gmul(out, z)
    return out


IPOW = [(1, 0), (0, 1), (-1, 0), (0, -1)]


def gauss_sum(p, q, r=0):
    A = bc.Alg(bc.sig(p, q, r))
    S1, S2 = (0, 0), (0, 0)
    for a in range(A.N):
        sq = A.sq(a)
        if sq != 0:
            w = (pc(a) % 2 + (2 if sq == -1 else 0)) % 4             # w = parity + 2 Q, Q = [e_a^2 = -1]
            S1 = (S1[0] + IPOW[w][0], S1[1] + IPOW[w][1])
        P = (1 << p) - 1
        Q = ((1 << q) - 1) << p
        e = (pc(a & P) - pc(a & Q)) % 4                              # the clock exponent of the Atlas, null bits weight 0
        S2 = (S2[0] + IPOW[e][0], S2[1] + IPOW[e][1])
    return S1, S2


def fig_gauss():
    S = SVG(380, 412, 'The Gauss sum of the labels on the complex plane: the clock is its phase')
    cx, cy, u = 190, 206, 23
    for n in range(1, 7):
        S.circle(cx, cy, u * n, 'gr')
    S.line(cx - 170, cy, cx + 170, cy, 'ln')
    S.line(cx, cy - 170, cx, cy + 170, 'ln')
    for c in range(8):
        ang = c * math.pi / 4
        x, y = cx + 158 * math.cos(ang), cy - 158 * math.sin(ang)
        S.text(x, y + 4, 'c = %d' % c, 's11 t2')
    spots = {}
    nchk = 0
    for n in range(1, 7):
        for q in range(n + 1):
            p = n - q
            S1, S2 = gauss_sum(p, q)
            closed = gmul(gpow((1, 1), p), gpow((1, -1), q))
            check(S1 == S2 == closed, 'F5 sum of i^w over the labels = (1+i)^p (1-i)^q')
            nchk += 1
            c = (p - q) % 8
            spots.setdefault((n, c), []).append((p, q))
    # null generators double the sum (r = 1, 2)
    for (p, q, r) in [(1, 0, 1), (0, 1, 1), (2, 1, 1), (1, 1, 2), (0, 2, 2)]:
        S1, S2 = gauss_sum(p, q, r)
        check(S2 == ((2 ** r) * gmul(gpow((1, 1), p), gpow((1, -1), q))[0], (2 ** r) * gmul(gpow((1, 1), p), gpow((1, -1), q))[1]),
              'F5 with r null generators the clock sum is 2^r (1+i)^p (1-i)^q (LAB-017)')
    cells = solid_cells()
    for (n, c), lst in sorted(spots.items()):
        ang = c * math.pi / 4
        x, y = cx + u * n * math.cos(ang), cy - u * n * math.sin(ang)
        t = cells[lst[0]]['type'] if lst[0] in cells else 'R'
        S.circle(x, y, 6.5, 'sf')
        S.circle(x, y, 6.5, TYPE_CLS[t] + ' o4')
        if len(lst) > 1:
            S.text(x + 8, y + 13, '×%d' % len(lst), 's10 mu', 'start')
    S.text(10, 18, 'Σₐ i^{w(a)} = (1 + i)^{p} (1 − i)^{q} = 2^{n/2} e^{iπ(p−q)/4}', 's12 b', 'start')
    S.text(10, 34, 'real axis across, imaginary up; the cells with n ≤ 6 at radius n', 's11 t2', 'start')
    S.text(10, 386, 'the circle n holds the cells of row n; ×2: two cells', 's11 mu', 'start')
    lx = legend(S, 12, 404, [('fR o4', 'ℝ'), ('fC o4', 'ℂ'), ('fH o4', 'ℍ')])
    S.text(lx, 405, 'the type of the cell', 's11 mu', 'start')
    check(nchk == 27, 'F5 27 cells with 1 <= n <= 6 checked')
    save('f05_gauss_phases.svg', S)


# ------------------------------------------------------------------ F6: the type table of the 36 cells
def fig_type_table():
    cells = solid_cells()
    S = SVG(392, 380, 'The 36 cells Cl(p,q), p + q ≤ 7: commutant type and module dimension')
    cw, ch, x0, y0 = 42, 33, 44, 58
    S.text(10, 17, 'row n = p + q, column q; the number: real dimension of the', 's11 t2', 'start')
    S.text(10, 32, 'minimal module; colour: its commutant (solid.K1)', 's11 t2', 'start')
    for q in range(8):
        S.text(x0 + q * cw + cw / 2, y0 - 4, 'q = %d' % q, 's10 mu')
    for n in range(8):
        S.text(x0 - 8, y0 + n * ch + ch / 2 + 4, 'n = %d' % n, 's10 mu', 'end')
        for q in range(n + 1):
            d = cells[(n - q, q)]
            X, Y = x0 + q * cw, y0 + n * ch
            S.rect(X + 1, Y + 1, cw - 2, ch - 2, TYPE_CLS[d['type']] + (' o3' if d['summands'] == 2 else ' o1'), rx=4)
            if d['summands'] == 2:
                S.rect(X + 3.5, Y + 3.5, cw - 7, ch - 7, 'lk', rx=3)
            S.text(X + cw / 2, Y + ch / 2 + 5, str(d['dim']) + ('²' if d['summands'] == 2 else ''), 's14 b')
    sizes = {}
    for d in cells.values():
        sizes[d['type']] = sizes.get(d['type'], 0) + 1
    m = grab('solid', r"solid\.K2: 36 cells, every clock value 0 \.\. 7 occurs; types found \{'C': (\d+), 'H': (\d+), 'R': (\d+)\}")
    check((sizes['C'], sizes['H'], sizes['R']) == tuple(int(t) for t in m.groups()), 'F6 types found C 10, H 13, R 13 (solid.K2)')
    S.text(10, 344, 'ℝ: %d cells, ℂ: %d, ℍ: %d. ² and a double frame: two simple' % (sizes['R'], sizes['C'], sizes['H']), 's11 t2', 'start')
    S.text(10, 359, 'summands (c = 1, 5); a diagonal q − p = const. is one clock.', 's11 t2', 'start')
    lx = legend(S, 230, 376, [('fR o1', 'ℝ'), ('fC o1', 'ℂ'), ('fH o1', 'ℍ')])
    save('f06_type_table.svg', S)
    return cells


# ------------------------------------------------------------------ F7: octonions on the labels of the plane over F_2
def octonion_table():
    T = cb.table(lambda x, y: cb.cd_mul(x, y, [-1, -1, -1]), 8)
    for (a, b), (s, c) in T.items():
        check(c == a ^ b and s in (1, -1), 'F7 the Cayley-Dickson octonions: e_a e_b = +-e_(a xor b)')
    return T


def fig_octonions():
    T = octonion_table()
    C03 = bc.Alg((-1, -1, -1))
    neg_assoc = 0
    for a in range(8):
        for b in range(8):
            for c in range(8):
                s1, ab = T[(a, b)]
                s2, abc = T[(ab, c)]
                s3, bc_ = T[(b, c)]
                s4, abc2 = T[(a, bc_)]
                phi = s1 * s2 * s3 * s4
                check(phi == (-1) ** cb.det3(a, b, c), 'F7 associator sign (-1)^det(a,b,c)')
                neg_assoc += phi == -1
    check(neg_assoc == 168, 'F7 the associator is -1 on 168 = 7 x 6 x 4 triples (T6 (d), LNB-002)')
    diff = sum(T[(a, b)][0] != C03.blade_mul(a, b)[0] for a in range(1, 8) for b in range(1, 8) if a != b)
    check(diff == 15, 'F7 the octonion signs differ from those of Cl(0,3) on 15 of the 42 products of distinct non-zero labels (LNB-002)')
    check(T[(7, 7)][0] == -1 and C03.blade_mul(7, 7)[0] == 1, 'F7 e111^2 = -1 in O and +1 in Cl(0,3)')
    lines = sorted({tuple(sorted((a, b, a ^ b))) for a in range(1, 8) for b in range(1, 8) if a != b})
    check(len(lines) == 7, 'F7 seven lines {a, b, a xor b}')
    S = SVG(452, 330, 'Octonions on the eight labels: the oriented lines of the plane over F2, and the sign table')
    # positions: corners e1, e2, e3, midpoints a xor b, centre 111
    Pt = {1: (30, 236), 2: (226, 236), 4: (128, 66)}
    for a, b in ((1, 2), (1, 4), (2, 4)):
        Pt[a ^ b] = ((Pt[a][0] + Pt[b][0]) / 2, (Pt[a][1] + Pt[b][1]) / 2)
    Pt[7] = ((Pt[1][0] + Pt[2][0] + Pt[4][0]) / 3, (Pt[1][1] + Pt[2][1] + Pt[4][1]) / 3)
    ccx, ccy = Pt[7]
    rr = math.dist(Pt[7], Pt[3])
    def orient(line):
        for x, y, z in ((line[0], line[1], line[2]), (line[1], line[2], line[0]), (line[2], line[0], line[1]),
                        (line[0], line[2], line[1]), (line[2], line[1], line[0]), (line[1], line[0], line[2])):
            if T[(x, y)] == (1, z):
                check(T[(y, z)] == (1, x) and T[(z, x)] == (1, y), 'F7 each line is a quaternion triple')
                return (x, y, z)
        sys.exit('F7: no orientation')
    for line in lines:
        x, y, z = orient(line)
        if line == (3, 5, 6):
            S.circle(ccx, ccy, rr, 'lk w2')
            angs = {v: math.atan2(Pt[v][1] - ccy, Pt[v][0] - ccx) for v in line}
            # the direction of travel x -> y on the circle: the shorter turn
            d = (angs[y] - angs[x]) % (2 * math.pi)
            sgn = 1 if d < math.pi else -1
            for v in line:
                a0 = angs[v] + sgn * math.pi / 3
                px, py = ccx + rr * math.cos(a0), ccy + rr * math.sin(a0)
                S.arrowhead(px, py, a0 + sgn * math.pi / 2, 'ik', 8)
            continue
        # the order of the three points along the segment
        pts = sorted(line, key=lambda v: (Pt[v][0], Pt[v][1]))
        ends = [pts[0], pts[2]] if math.dist(Pt[pts[0]], Pt[pts[2]]) >= max(math.dist(Pt[pts[0]], Pt[pts[1]]), math.dist(Pt[pts[1]], Pt[pts[2]])) else None
        # find the two end points: the pair at the largest distance
        pairs = sorted(((math.dist(Pt[u], Pt[v]), u, v) for u in line for v in line if u < v), reverse=True)
        _, e1, e2 = pairs[0]
        mid = [v for v in line if v not in (e1, e2)][0]
        S.line(Pt[e1][0], Pt[e1][1], Pt[e2][0], Pt[e2][1], 'lk w2')
        seq = [e1, mid, e2]
        cyc = [(x, y, z), (y, z, x), (z, x, y)]
        forward = any(tuple(seq) == c for c in cyc)
        if not forward:
            seq = seq[::-1]
        for u, v in ((seq[0], seq[1]), (seq[1], seq[2])):
            (x1, y1), (x2, y2) = Pt[u], Pt[v]
            S.arrowhead(x1 + 0.58 * (x2 - x1), y1 + 0.58 * (y2 - y1), math.atan2(y2 - y1, x2 - x1), 'ik', 8)
    for v in range(1, 8):
        x, y = Pt[v]
        S.circle(x, y, 16, 'sf')
        S.circle(x, y, 16, 'lk')
        S.text(x, y + 4.5, bname(v), 's11 b')
    S.text(8, 17, 'the 7 lines {a, b, a ⊕ b}; arrows a → b → c', 's11 t2', 'start')
    S.text(8, 32, 'mean eₐ e_{b} = +e_{c} (and e_{b} e_{c} = +eₐ)', 's11 t2', 'start')
    S.text(8, 274, 'every non-zero label squares to −1;', 's11 t2', 'start')
    S.text(8, 289, 'the associator is −1 on the 168', 's11 t2', 'start')
    S.text(8, 304, 'independent triples: (−1)^{det(a,b,c)}', 's11 t2', 'start')
    # the sign table, outlined where it differs from Cl(0,3)
    labs = [bname(a) for a in range(8)]
    cells = [[sign_cell(T[(a, b)][0]) + ((T[(a, b)][0] != C03.blade_mul(a, b)[0]),) for b in range(8)] for a in range(8)]
    S.text(258, 17, 'the sign of eₐ e_{b} in 𝕆', 's12 b', 'start')
    S.text(258, 32, 'outlined: not the sign of Cl(0,3)', 's11 t2', 'start')
    grid(S, 252, 40, 21, 24, labs, labs, cells, hw=30, labcls='s10 t2', cellcls='s12 b')
    S.text(258, 312, 'outlined: %d of the 42 products of' % diff, 's11 mu', 'start')
    S.text(258, 326, 'distinct labels, and e₁₂₃²', 's11 mu', 'start')
    save('f07_octonions.svg', S)


# ------------------------------------------------------------------ F8: minimal left ideals in Cl(3,1) and Cl(1,3)
def rank_rows(vecs, N):
    rows = [[Fraction(v.get(i, 0)) for i in range(N)] for v in vecs]
    r, col = 0, 0
    while r < len(rows) and col < N:
        piv = next((i for i in range(r, len(rows)) if rows[i][col] != 0), None)
        if piv is None:
            col += 1
            continue
        rows[r], rows[piv] = rows[piv], rows[r]
        for i in range(len(rows)):
            if i != r and rows[i][col] != 0:
                fct = rows[i][col] / rows[r][col]
                rows[i] = [x - fct * y for x, y in zip(rows[i], rows[r])]
        r += 1
        col += 1
    return r


def ideal(eps, gens):
    A = bc.Alg(eps)
    f = {0: Fraction(1)}
    for g in gens:
        check(A.sq(g) == 1, 'F8 an idempotent factor squares to +1')
        f = A.mul(f, {0: Fraction(1, 2), g: Fraction(1, 2)})
    check(A.mul(f, f) == f, 'F8 f is an idempotent')
    H = sorted(f.keys())
    reps = sorted({min(r ^ h for h in H) for r in range(A.N)})
    rows = []
    for R in reps:
        v = A.mul({R: Fraction(1)}, f)
        rows.append([(R ^ h, int(v[R ^ h] / abs(v[R ^ h]))) for h in H])
    dim_ideal = rank_rows([A.mul({a: 1}, f) for a in range(A.N)], A.N)
    dim_comm = rank_rows([A.mul(A.mul(f, {a: 1}), f) for a in range(A.N)], A.N)
    sf = {h: int(f[h] / abs(f[h])) for h in H}
    return rows, dim_ideal, dim_comm, sf


def fig_min_ideal():
    cells = solid_cells()
    S = SVG(430, 350, 'Minimal left ideals of Cl(3,1) and Cl(1,3): one basis vector per coset, a label with a sign in each place')
    specs = [((3, 1), (1, 0b1010), 'Cl(3,1) = M₄(ℝ), c = 2', 8, 54), ((1, 3), (1,), 'Cl(1,3) = M₂(ℍ), c = 6', 272, 54)]
    for (pq, gens, title, x0, cw) in specs:
        eps = bc.sig(*pq)
        rows, di, dc, sf = ideal(eps, gens)
        d = cells[pq]
        check(di == d['dim'] and dc == d['cdim'] and len(gens) == d['k'], 'F8 %s: ideal %d, commutant %d, %d factors (solid.K1)' % (title, di, dc, len(gens)))
        S.text(x0, 17, title, 's12 b', 'start')
        fstr = ' '.join(('+ ' if s > 0 else '− ') + bname(h) for h, s in sorted(sf.items()))
        fstr = fstr[2:] if fstr.startswith('+ ') else fstr
        S.text(x0, 34, 'f = (%s)/%d' % (fstr, 2 ** len(gens)), 's11 t2', 'start')
        ch = 25
        for i, row in enumerate(rows):
            Y = 46 + i * ch
            S.text(x0 + 2, Y + ch / 2 + 4, bname(row[0][0]) + 'f' if row[0][0] else 'f', 's11 mu', 'start')
            for j, (lab, s) in enumerate(row):
                X = x0 + 40 + j * cw
                S.rect(X + 1, Y + 1, cw - 2, ch - 2, 'fR o2' if s > 0 else 'fC o3', rx=3)
                S.text(X + cw / 2, Y + ch / 2 + 4.5, ('+' if s > 0 else '−') + bname(lab), 's12')
        n_copies = 16 // di
        S.text(x0, 46 + len(rows) * ch + 18, 'ideal: dimension %d; f Cl f: %d' % (di, dc), 's11 t2', 'start')
        S.text(x0, 46 + len(rows) * ch + 33, '16 = %d × %d: %d copies' % (n_copies, di, n_copies), 's11 t2', 'start')
    S.text(10, 302, 'Each row is a basis vector e_{R} f of the left ideal Cl·f (up to the factor', 's11 t2', 'start')
    S.text(10, 317, 'of f): the labels of one coset R ⊕ H, each with its sign. f is built from', 's11 t2', 'start')
    S.text(10, 332, 'commuting labels of square +1: e₁, e₂₄ in Cl(3,1); e₁ in Cl(1,3).', 's11 t2', 'start')
    save('f08_min_ideal.svg', S)


# ------------------------------------------------------------------ F9: the 72 cokernels (aty_twisted_k.log)
def fig_cokernels():
    m = grab('atyk', r'by the clock c = 0\.\.7 \(square -1 added\): ((?:Z2|Z|0)(?: (?:Z2|Z|0)){7})')
    by_clock = m.group(1).split()
    m2 = grab('atyk', r'aty\.A3: for all 36 cells, adding a generator of square -1 gives KO\^\(p-q\)\(point\) and of square \+1 gives KO\^\(q-p\)\(point\); 72 cokernels, mismatches \[\]')
    m3 = grab('atyk', r'graded, Cl\(0,n\) inside Cl\(0,n\+1\), n = 0\.\.9: ((?:Z2|Z|0)(?: (?:Z2|Z|0)){9}); the recalled KO\^\(-n\)\(point\): ((?:Z2|Z|0)(?: (?:Z2|Z|0)){9})')
    along = m3.group(1).split()
    check(m3.group(1) == m3.group(2), 'F9 aty.A2: graded Cl(0,n) groups = recalled KO^(-n)(point), n = 0..9')
    for nn in range(10):
        check(along[nn] == by_clock[(-nn) % 8], 'F9 aty.A2 along Cl(0,n) agrees with aty.A3 by the clock')
    sym = {'Z': ('ℤ', 'fR o3'), 'Z2': ('ℤ₂', 'fC o3'), '0': ('0', 'bg')}
    S = SVG(436, 300, 'The 72 graded cokernels of the cells p + q ≤ 7, by the clock')
    cw, ch = 22, 21
    count = 0
    for k, (sgn, title) in enumerate(((-1, 'add a square −1: KO^{p−q}'), (1, 'add a square +1: KO^{q−p}'))):
        x0, y0 = 36 + k * 210, 44
        S.text(x0 - 26, 17, title, 's12 b', 'start')
        S.text(x0 - 26, 32, 'row n = p + q, column q', 's11 mu', 'start')
        for n in range(8):
            if k == 0:
                S.text(x0 - 6, y0 + n * ch + ch / 2 + 4, str(n), 's10 mu', 'end')
            for q in range(n + 1):
                p = n - q
                c = (p - q) % 8 if sgn == -1 else (q - p) % 8
                t, cls = sym[by_clock[c]]
                X, Y = x0 + q * cw, y0 + n * ch
                S.rect(X + 1, Y + 1, cw - 2, ch - 2, cls, rx=3)
                S.text(X + cw / 2, Y + ch / 2 + 4, t, 's10')
                count += 1
    check(count == 72, 'F9 72 cokernels drawn')
    y = 236
    S.text(10, y, 'by the clock c = p − q (square −1 added):', 's11 t2', 'start')
    for c in range(8):
        t, cls = sym[by_clock[c]]
        X = 10 + c * 30
        S.rect(X, y + 8, 28, 22, cls, rx=3)
        S.text(X + 14, y + 23, t, 's11')
        S.text(X + 14, y + 44, str(c), 's10 mu')
    S.text(258, y + 23, '(aty.A3; mismatches: none)', 's11 mu', 'start')
    save('f09_cokernels.svg', S)


# ------------------------------------------------------------------ F10: the graded tensor product, the Koszul sign
def fig_koszul():
    eps = (1, 1, -1)                                  # Cl(1,0) on the first generator, Cl(1,1) on the other two
    A, A1, A2 = bc.Alg(eps), bc.Alg((1,)), bc.Alg((1, -1))
    labs = [bname(a) for a in range(8)]
    K, Sg, ordinary = [], [], []
    for a in range(8):
        rk, rs = [], []
        for b in range(8):
            s = A.blade_mul(a, b)[0]
            s1 = A1.blade_mul(a & 1, b & 1)[0]
            s2 = A2.blade_mul(a >> 1, b >> 1)[0]
            kos = (-1) ** (pc(a >> 1) * pc(b & 1))
            check(s == s1 * s2 * kos, 'F10 s(a,b) = s1 s2 (-1)^(|a2||b1|) for Cl(1,0) (x)^ Cl(1,1)')
            rk.append(kos)
            rs.append(s)
            ordinary.append(s1 * s2)
        K.append(rk)
        Sg.append(rs)
    # every split, every choice of squares, n <= 4
    tested = 0
    for n in range(2, 5):
        for code in range(3 ** n):
            e = []
            x = code
            for _ in range(n):
                e.append((1, -1, 0)[x % 3])
                x //= 3
            B = bc.Alg(tuple(e))
            for m in range(1, n):
                B1, B2 = bc.Alg(tuple(e[:m])), bc.Alg(tuple(e[m:]))
                lo = (1 << m) - 1
                for a in range(1 << n):
                    for b in range(1 << n):
                        if B.blade_mul(a, b)[0] != B1.blade_mul(a & lo, b & lo)[0] * B2.blade_mul(a >> m, b >> m)[0] * (-1) ** (pc(a >> m) * pc(b & lo)):
                            sys.exit('F10: the Koszul factorisation fails')
                tested += 1
    check(tested == 1 * 9 + 2 * 27 + 3 * 81, 'F10 the Koszul factorisation holds for every split and all 3^n squares, n = 2..4')
    S = SVG(446, 316, 'The graded tensor product Cl(1,0) ⊗̂ Cl(1,1): the Koszul sign and the bit rule')
    S.text(10, 17, 'Koszul sign (−1)^{|a₂||b₁|}', 's12 b', 'start')
    S.text(10, 32, 'a₁: the bit of e₁ (Cl(1,0));', 's11 mu', 'start')
    S.text(10, 46, 'a₂: the bits of e₂, e₃ (Cl(1,1))', 's11 mu', 'start')
    grid(S, 6, 54, 23, 24, labs, labs, [[sign_cell(v) for v in r] for r in K], hw=30, labcls='s10 t2', cellcls='s12 b')
    S.text(236, 17, 'the bit rule, squares (+, +, −)', 's12 b', 'start')
    S.text(236, 32, 'outlined: where the Koszul', 's11 mu', 'start')
    S.text(236, 46, 'sign is −1', 's11 mu', 'start')
    grid(S, 232, 54, 23, 24, labs, labs, [[sign_cell(v) + ((K[i][j] == -1),) for j, v in enumerate(r)] for i, r in enumerate(Sg)], hw=30, labcls='s10 t2', cellcls='s12 b')
    S.text(10, 296, 's(a,b) = s₁(a₁,b₁) · s₂(a₂,b₂) · (−1)^{|a₂||b₁|} on all 64 pairs;', 's11 t2', 'start')
    S.text(10, 311, 'the clocks add: 1 + 0 = 1, and Cl(2,1) = M₂(ℝ) ⊕ M₂(ℝ)', 's11 t2', 'start')
    save('f10_koszul.svg', S)


# ------------------------------------------------------------------ F11: the Frobenius pairing at n = 3
def fig_frobenius():
    labs = [bname(a) for a in range(8)]
    F = 7
    mats = set()
    for code in range(27):
        e, x = [], code
        for _ in range(3):
            e.append((1, -1, 0)[x % 3])
            x //= 3
        A = bc.Alg(tuple(e))
        lam = tuple(tuple(A.blade_mul(a, b)[0] if a ^ b == F else 0 for b in range(8)) for a in range(8))
        mats.add(lam)
        for a in range(8):
            check(sum(1 for b in range(8) if lam[a][b] != 0) == 1, 'F11 the top-label pairing has one non-zero entry per row')
    check(len(mats) == 1, 'F11 the top-label pairing is the same signed antidiagonal for all 27 choices of squares (LNC-028)')
    lam = next(iter(mats))
    A = bc.Alg((1, -1, 0))
    sc = [[A.blade_mul(a, b)[0] if a == b else 0 for b in range(8)] for a in range(8)]
    rk = sum(1 for a in range(8) if sc[a][a] != 0)
    check(rk == 4, 'F11 the scalar-part pairing of Cl(1,1,1) has rank 2^(p+q) = 4 (T3 (F4))')
    S = SVG(446, 300, 'The Frobenius pairing at n = 3: the top-label form and the scalar part')
    def cells(Mx):
        return [[(SIGN[v], 'fR o2' if v == 1 else 'fC o3') if v else ('', 'bg') for v in r] for r in Mx]
    S.text(10, 17, 'λ(eₐ e_{b}), λ = coefficient of e₁₂₃', 's12 b', 'start')
    S.text(10, 32, 'the same for all 27 choices of squares', 's11 mu', 'start')
    grid(S, 6, 40, 23, 24, labs, labs, cells(lam), hw=30, labcls='s10 t2', cellcls='s12 b')
    S.text(236, 17, '⟨eₐ e_{b}⟩₀ in Cl(1,1,1)', 's12 b', 'start')
    S.text(236, 32, 'squares (+, −, 0): rank 4', 's11 mu', 'start')
    grid(S, 232, 40, 23, 24, labs, labs, cells(sc), hw=30, labcls='s10 t2', cellcls='s12 b')
    S.text(10, 284, 'λ pairs a with its complement a ⊕ 111; the scalar part is blind to the null bit', 's11 t2', 'start')
    save('f11_frobenius.svg', S)


# ------------------------------------------------------------------ the lattice I_(1,n) of the cell Cl(1,n)
def frame_form(p, q):
    A = bc.Alg(bc.sig(p, q))
    return [A.sq(1 << i) for i in range(p + q)]          # the frame lattice: e_i . e_i = e_i^2 (aty·L1: diag(+1 x p, -1 x q))


def ip(form, x, y):
    return sum(g * a * b for g, a, b in zip(form, x, y))


def det_frac(M):
    M = [[Fraction(v) for v in r] for r in M]
    n, d = len(M), Fraction(1)
    for c in range(n):
        piv = next((i for i in range(c, n) if M[i][c] != 0), None)
        if piv is None:
            return Fraction(0)
        if piv != c:
            M[c], M[piv] = M[piv], M[c]
            d = -d
        d *= M[c][c]
        for i in range(c + 1, n):
            fct = M[i][c] / M[c][c]
            M[i] = [a - fct * b for a, b in zip(M[i], M[c])]
    return d


def fig_e8_in_I18():
    form = frame_form(1, 8)
    check(form == [1] + [-1] * 8, 'F12 the frame lattice of Cl(1,8) is I_(1,8) = diag(+1, -1 x 8)')
    k = [3] + [-1] * 8
    check(ip(form, k, k) == 1, 'F12 k = (3; -1^8) has k.k = 1 = 9 - 8')
    vs = [[1, 1, 1, 1, 0, 0, 0, 0, 0]]                    # h - e1 - e2 - e3 in coordinates (x0; x1..x8) of h, -e1.. (sign below)
    vs = [[1, -1, -1, -1, 0, 0, 0, 0, 0]]
    names = ['h−e₁−e₂−e₃']
    for i in range(1, 8):
        v = [0] * 9
        v[i], v[i + 1] = 1, -1
        vs.append(v)
        names.append(('e%d−e%d' % (i, i + 1)).translate(SUB))
    for v in vs:
        check(ip(form, v, v) == -2 and ip(form, k, v) == 0, 'F12 each simple root has norm -2 and is orthogonal to k')
    G = [[ip(form, u, v) for v in vs] for u in vs]
    check(det_frac(G) == 1, 'F12 the Gram matrix of the 8 roots has determinant 1')
    m = grab('matter', r'k = \(3; -1\^8\) has k\.k = 1; the 8 vectors h - e1 - e2 - e3, e_i - e_\(i\+1\) are orthogonal to k with norm -2, Gram determinant 1;.*?k\^perp has (\d+) vectors of norm -2')
    check(int(m.group(1)) == 240, 'F12 aty_matter_models.log L4: k^perp has 240 vectors of norm -2')
    edges = [(i, j) for i in range(8) for j in range(i + 1, 8) if G[i][j] != 0]
    check(all(G[i][j] == 1 for i, j in edges) and len(edges) == 7, 'F12 seven bonds, each with inner product +1: a tree, -Cartan(E8)')
    # layout: the chain e1-e2 ... e7-e8 and the node h-e1-e2-e3 above its neighbour
    S = SVG(400, 210, 'E8 inside the frame lattice I(1,8) of the cell Cl(1,8): the roots orthogonal to k')
    xs = {i: 30 + (i - 1) * 56 for i in range(1, 8)}
    nb = [j for (i, j) in edges if i == 0] + [i for (i, j) in edges if j == 0]
    check(len(nb) == 1, 'F12 h - e1 - e2 - e3 has one neighbour')
    P = {i: (xs[i], 150) for i in range(1, 8)}
    P[0] = (xs[nb[0]], 78)
    for i, j in edges:
        S.line(P[i][0], P[i][1], P[j][0], P[j][1], 'lk w2')
    for i in range(8):
        x, y = P[i]
        S.circle(x, y, 9, 'fR o4')
        S.text(x, y + 26 if i else y - 15, names[i], 's11 t2')
    S.text(10, 18, 'In I(1,8) = ⟨h, e₁ … e₈⟩ with h·h = +1, eᵢ·eᵢ = −1: k = 3h − e₁ − … − e₈', 's11 t2', 'start')
    S.text(10, 34, 'has k·k = 1; its orthogonal complement is −E₈ (240 roots).', 's11 t2', 'start')
    S.text(10, 200, 'Gram matrix = −Cartan(E₈), determinant 1 (computed by figs_alg.py)', 's11 mu', 'start')
    save('f12_e8_in_I18.svg', S)


# ------------------------------------------------------------------ F13: the Gauss sums of the forms (aty_matter_models.log)
def fig_forms_wheel():
    forms = []
    for m in re.finditer(r'^\s+(\S[^\n:]*?) ?(?:\(([^)]*)\))?: b2 = (\d+), det = (-?\d+), (even|odd), sigma = (-?\d+), chi = (\d+)', log('matter'), re.M):
        forms.append((m.group(1).strip(), int(m.group(6))))
    show = {'S4': 'S⁴', 'CP2': 'CP²', '-CP2': '−CP²', 'S2xS2': 'S²×S²', 'CP2#-CP2': 'CP² # −CP²', 'K3': 'K3', 'cell (1,8) = CP2 # 8': 'CP² # 8(−CP²)'}
    check(all(f[0] in show for f in forms), 'F13 the seven forms are S4, CP2, -CP2, S2xS2, CP2#-CP2, K3, cell (1,8)')
    forms = [(show[a], b) for a, b in forms]
    check(len(forms) == 7, 'F13 aty_matter_models.log L2: seven forms with their signatures')
    cellm = grab('matter', r'diag\(\+1 x p, -1 x q\) = I_\{p,q\} for the 10 cells ([^\n]*)')
    cellpq = [tuple(int(t) for t in pr) for pr in re.findall(r'\((\d+),(\d+)\)', cellm.group(1))]
    check(len(cellpq) == 10, 'F13 ten cells of aty·L1')
    for (p, q) in cellpq:
        S1, _ = gauss_sum(p, q)
        n = p + q
        # the lattice Gauss sum over L/2L with x.x mod 4: x in {0,1}^n, x.x = (number of +1 entries) - (number of -1 entries) on the support
        form = frame_form(p, q)
        G = (0, 0)
        for a in range(1 << n):
            w = sum(form[i] for i in range(n) if a >> i & 1) % 4
            G = (G[0] + IPOW[w][0], G[1] + IPOW[w][1])
        check(G == S1, 'F13 the clock sum of the cell equals the lattice Gauss sum of I_(p,q) (aty·L1)')
    S = SVG(420, 300, 'The phase of a lattice Gauss sum is the signature mod 8: cells and forms on one wheel')
    cx, cy, R = 172, 150, 92
    S.circle(cx, cy, R, 'ln')
    spots = {}
    for name, sg in forms:
        spots.setdefault(sg % 8, []).append('%s (σ = %d)' % (name, sg))
    spots.setdefault(8 % 8, []).append('E₈ (σ = 8)')
    cl = {}
    for (p, q) in cellpq:
        cl.setdefault((p - q) % 8, []).append('Cl(%d,%d)' % (p, q))
    for c in range(8):
        ang = c * math.pi / 4
        x, y = cx + R * math.cos(ang), cy - R * math.sin(ang)
        S.circle(x, y, 6, 'fR o4' if (c in spots) else 'bg')
        S.text(cx + (R - 20) * math.cos(ang), cy - (R - 20) * math.sin(ang) + 4, str(c), 's11 mu')
        lines = spots.get(c, []) + ([', '.join(cl[c])] if c in cl else [])
        if not lines:
            continue
        lx = cx + (R + 14) * math.cos(ang)
        ly = cy - (R + 14) * math.sin(ang)
        anchor = 'start' if math.cos(ang) > 0.3 else ('end' if math.cos(ang) < -0.3 else 'middle')
        dy = -13 * (len(lines) - 1) if math.sin(ang) > 0.3 else (0 if math.sin(ang) < -0.3 else -6.5 * (len(lines) - 1))
        for i, t in enumerate(lines):
            S.text(lx, ly + dy + 13 * i + 4, t, 's10 t2' if not t.startswith('Cl') else 's10 mu', anchor)
    S.text(10, 18, 'ζ₈^{σ}: the phase of the Gauss sum over L/2L', 's12 b', 'start')
    S.text(10, 278, 'dark: the forms of aty·L2, at σ mod 8; light: the cells Cl(p,q) of', 's10 t2', 'start')
    S.text(10, 291, 'aty·L1, at the clock p − q, whose label sum is the lattice sum', 's10 t2', 'start')
    save('f13_forms_wheel.svg', S)


# ------------------------------------------------------------------ F14: the 240 roots of E8, 112 + 128, on a Coxeter plane
def fig_e8_roots():
    import numpy as np
    roots = []
    for i in range(8):
        for j in range(i + 1, 8):
            for si in (1, -1):
                for sj in (1, -1):
                    v = [0.0] * 8
                    v[i], v[j] = float(si), float(sj)
                    roots.append((tuple(v), 112))
    for a in range(256):
        if pc(a) % 2 == 0:                               # the even labels of 8 bits
            roots.append((tuple(-0.5 if a >> i & 1 else 0.5 for i in range(8)), 128))
    check(len(roots) == 240 and sum(1 for r in roots if r[1] == 112) == 112, 'F14 240 roots: 112 from pairs of 8 bits, 128 from even labels')
    m = grab('elad', r'elad·1 (\d+) roots of E8 from bit labels \((\d+) from pairs of 8 bits, (\d+) from even labels\)')
    check(tuple(int(t) for t in m.groups()) == (240, 112, 128), 'F14 e_ladder.log elad·1: 240 = 112 + 128')
    R = np.array([r[0] for r in roots])
    G = R @ R.T
    check(set(np.round(np.diag(G), 6)) == {2.0}, 'F14 every root has norm 2')
    fvec = np.array([8, 7.1, 6.3, 5.2, 4.4, 3.3, 2.15, 1.07])          # a generic functional: no root is orthogonal to it
    check(float(min(abs(R @ fvec))) > 0.05, 'F14 the functional is generic')
    pos = [r for r in R if r @ fvec > 0]
    posset = {tuple(np.round(r, 6)) for r in pos}
    simple = [r for r in pos if not any(tuple(np.round(r - s, 6)) in posset for s in pos)]
    check(len(simple) == 8, 'F14 eight simple roots')
    W = np.eye(8)
    for s in simple:
        W = W @ (np.eye(8) - np.outer(s, s))           # reflections in roots of norm 2
    ev, vec = np.linalg.eig(W)
    k = int(np.argmin(np.abs(ev - np.exp(2j * np.pi / 30))))
    check(abs(ev[k] - np.exp(2j * np.pi / 30)) < 1e-6, 'F14 the Coxeter element has the eigenvalue exp(2 pi i / 30): Coxeter number 30')
    u = vec[:, k]
    b1, b2 = np.real(u), np.imag(u)
    b1 = b1 / np.linalg.norm(b1)
    b2 = b2 - (b2 @ b1) * b1
    b2 = b2 / np.linalg.norm(b2)
    xy = [(float(r @ b1), float(r @ b2)) for r in R]
    rad = sorted({round(math.hypot(x, y), 4) for x, y in xy})
    check(len(rad) == 8 and all(sum(1 for x, y in xy if abs(math.hypot(x, y) - r0) < 1e-3) == 30 for r0 in rad), 'F14 the projection: 8 rings of 30 roots')
    # turn the picture so that the first root of the 112 lies on the positive x axis (a fixed orientation)
    a0 = math.atan2(xy[0][1], xy[0][0])
    ca, sa = math.cos(-a0), math.sin(-a0)
    xy = [(x * ca - y * sa, x * sa + y * ca) for x, y in xy]
    S = SVG(380, 420, 'The 240 roots of E8 from labels, 112 + 128, projected on a Coxeter plane')
    cx, cy, sc = 190, 210, 168 / max(rad)
    for r0 in rad:
        S.circle(cx, cy, r0 * sc, 'gr')
    for (x, y), (_, fam) in sorted(zip(xy, roots), key=lambda t: t[1][1]):
        S.circle(cx + x * sc, cy - y * sc, 3.6, 'fR o4' if fam == 112 else 'fC o4')
    S.text(10, 18, '±eᵢ ± eⱼ: 112 (28 pairs of the 8 bits × 4 signs)', 's11 t2', 'start')
    S.text(10, 34, '½(±1, …, ±1), an even label: 128 (half-spin weights)', 's11 t2', 'start')
    lx = legend(S, 12, 408, [('fR o4', '112'), ('fC o4', '128')])
    S.text(lx, 409, '8 rings of 30; Coxeter number 30', 's11 mu', 'start')
    save('f14_e8_roots.svg', S)


# ------------------------------------------------------------------ F15: the Gosset descent in I_(1,n)
def count_vectors(n, norm, kdot):
    """vectors x of I_(1,n) with x.x = norm and k.x = kdot, k = (3; -1^n); x.x = x0^2 - sum xi^2, k.x = 3 x0 + sum xi"""
    total = 0
    for x0 in range(-7, 8):
        need_sq = x0 * x0 - norm          # sum of xi^2
        need_sum = kdot - 3 * x0          # sum of xi
        if need_sq < 0:
            continue
        def rec(i, sq, sm):
            if i == n:
                return 1 if sq == 0 and sm == 0 else 0
            c = 0
            r = int(math.isqrt(sq))
            for v in range(-r, r + 1):
                rest = sq - v * v
                # the remaining n - i - 1 coordinates must reach the sum sm - v with squares rest: |sum| <= sqrt(rest (n - i - 1))
                left = n - i - 1
                if (sm - v) ** 2 > rest * left and not (left == 0 and rest == 0 and sm == v):
                    continue
                c += rec(i + 1, rest, sm - v)
            return c
        total += rec(0, need_sq, need_sum)
    return total


def fig_gosset():
    ns = list(range(3, 9))
    roots = [count_vectors(n, -2, 0) for n in ns]
    verts = [count_vectors(n, -1, 1) for n in ns]
    m = grab('T10', r'norm-2 vectors = roots: ([0-9, ]+) \(positive')
    check(roots == ints(m.group(1)), 'F15 roots of E_n, n = 3..8: %s (check_T10.log, 6)' % roots)
    m2 = grab('enw', r'Gosset descent, n <= 8: roots of E_n = ([0-9, ]+) \(n = 2\.\.8\)')
    check(roots == ints(m2.group(1))[1:], 'F15 en_weyl.log bd·en·6: the same descent')
    m3 = grab('enw', r'the W\(E_n\)-orbit of e_n has ([0-9, ]+) elements')
    check(verts == ints(m3.group(1)), 'F15 classes with x.x = -1, k.x = 1: %s = the W(E_n)-orbit of e_n (en_weyl.log bd·en·6; GOS-005, GOS-007)' % verts)
    dets = []
    for n in ns:
        form = frame_form(1, n)
        k = [3] + [-1] * n
        dets.append(ip(form, k, k))
    check(dets == [9 - n for n in ns], 'F15 k.k = 9 - n (GOS-005)')
    names = {3: 'A₂×A₁', 4: 'A₄', 5: 'D₅', 6: 'E₆', 7: 'E₇', 8: 'E₈'}
    S = SVG(410, 300, 'The E-series in I(1,n): roots and Gosset vertices for n = 3 … 8')
    x0, bw = 116, 240
    S.text(10, 18, 'E_{n} = k^{⊥} in I(1,n), k = (3; −1, …, −1), det = k·k = 9 − n', 's11 t2', 'start')
    S.text(10, 44, 'n', 's11 mu', 'start')
    S.text(30, 44, 'E_{n}', 's11 mu', 'start')
    S.text(80, 44, 'det', 's11 mu', 'start')
    S.text(x0, 44, 'the counts, scaled to 240', 's10 mu', 'start')
    for i, n in enumerate(ns):
        y = 58 + i * 36
        S.text(10, y + 15, str(n), 's12', 'start')
        S.text(30, y + 15, names[n], 's12 b', 'start')
        S.text(84, y + 15, str(dets[i]), 's12', 'start')
        w1 = bw * roots[i] / 240
        w2 = bw * verts[i] / 240
        S.rect(x0, y, max(w1, 2), 12, 'fR o4', rx=3)
        S.text(x0 + max(w1, 2) + 5, y + 10.5, str(roots[i]), 's11', 'start')
        S.rect(x0, y + 15, max(w2, 2), 12, 'fC o4', rx=3)
        S.text(x0 + max(w2, 2) + 5, y + 25.5, str(verts[i]), 's11', 'start')
    lx = legend(S, 12, 290, [('fR o4', 'roots: x·x = −2, k·x = 0'), ('fC o4', 'Gosset vertices: x·x = −1, k·x = 1')])
    save('f15_gosset.svg', S)


# ------------------------------------------------------------------ F16: the commutator graph of the bivectors
def fig_commutator():
    S = SVG(430, 300, 'The commutator graph of the bivectors of Cl(3,0) and Cl(4,0): closed and open triangles')
    out = {}
    for m in (3, 4):
        A = bc.Alg((1,) * m)
        biv = [a for a in range(1 << m) if pc(a) == 2]
        adj = {(a, b) for a in biv for b in biv if a != b and A.comm_sign(a, b) == -1}
        tri = [(a, b, c) for i, a in enumerate(biv) for j, b in enumerate(biv) for c in biv[j + 1:] if i < j and (a, b) in adj and (b, c) in adj and (a, c) in adj]
        closed = [t for t in tri if (t[0] ^ t[1]) == t[2]]
        out[m] = (biv, adj, tri, closed)
    check(len(out[3][2]) == 1 and len(out[3][3]) == 1, 'F16 m = 3: one triangle, closed: so(3)')
    check(len(out[4][2]) == 8 and len(out[4][3]) == 4, 'F16 m = 4: 8 triangles, 4 closed (index triples), 4 open (YM-001)')
    for m in (3, 4):
        biv, adj, tri, closed = out[m]
        for t in closed:
            A = bc.Alg((1,) * m)
            for u, v, w in ((t[0], t[1], t[2]), (t[1], t[2], t[0]), (t[0], t[2], t[1])):
                s, c = A.blade_mul(u, v)
                check(c == w, 'F16 the commutator of two bivectors of a closed triangle is the third, times 2')
    # m = 3
    P3 = {3: (70, 70), 5: (25, 160), 6: (115, 160)}
    S.text(10, 18, 'Cl(3,0): 3 bivectors', 's12 b', 'start')
    S.poly([P3[3], P3[5], P3[6]], 'fR o2')
    for a, b in ((3, 5), (5, 6), (3, 6)):
        S.line(P3[a][0], P3[a][1], P3[b][0], P3[b][1], 'lk w2')
    for a, (x, y) in P3.items():
        S.circle(x, y, 17, 'sf')
        S.circle(x, y, 17, 'lk')
        S.text(x, y + 4.5, bname(a), 's12 b')
    S.text(10, 200, 'one closed triangle: so(3)', 's11 t2', 'start')
    # m = 4: the octahedron, outer triangle e12 e13 e23, inner e34 e24 e14 (each opposite its commuting partner)
    cx, cy = 300, 150
    outer = {3: 90, 5: 210, 6: 330}
    inner = {12: 270, 10: 30, 9: 150}
    P = {}
    for a, ang in outer.items():
        P[a] = (cx + 104 * math.cos(math.radians(ang)), cy - 104 * math.sin(math.radians(ang)))
    for a, ang in inner.items():
        P[a] = (cx + 46 * math.cos(math.radians(ang)), cy - 46 * math.sin(math.radians(ang)))
    for a in P:
        partner = [b for b in P if b != a and (a, b) not in out[4][1]]
        check(len(partner) == 1 and (partner[0] & a) == 0, 'F16 each bivector of Cl(4,0) commutes with its complement only')
    biv, adj, tri, closed = out[4]
    outer_t = tuple(sorted(outer))
    for t in tri:
        if tuple(sorted(t)) == outer_t:
            continue
        S.poly([P[v] for v in t], 'fR o2' if t in closed else 'fC o2')
    check(any(tuple(sorted(t)) == outer_t for t in closed), 'F16 the outer triangle e12 e13 e23 is closed')
    for a, b in ((3, 5), (5, 6), (3, 6)):
        S.line(P[a][0], P[a][1], P[b][0], P[b][1], 'sR w3')
    for (a, b) in sorted(adj):
        if a < b:
            S.line(P[a][0], P[a][1], P[b][0], P[b][1], 'lk')
    for a, (x, y) in P.items():
        S.circle(x, y, 17, 'sf')
        S.circle(x, y, 17, 'lk')
        S.text(x, y + 4.5, bname(a), 's12 b')
    S.text(186, 18, 'Cl(4,0): 6 bivectors', 's12 b', 'start')
    S.text(10, 33, 'an edge: the two anticommute', 's11 t2', 'start')
    S.text(10, 264, 'blue: the 4 closed triangles {B_{ab}, B_{bc}, B_{ac}}, each an so(3) (the', 's11 t2', 'start')
    S.text(10, 279, 'outer one drawn thick); orange: the 4 open ones {B_{ab}, B_{ac}, B_{ad}}', 's11 t2', 'start')
    save('f16_commutator.svg', S)


# ------------------------------------------------------------------ F17: the McKay graph of the binary icosahedral group
def fig_mckay():
    A = bc.Alg((1, 1, 1))
    even = [0, 3, 5, 6]
    def mul(x, y):
        z = A.mul(x, y)
        return {k: v for k, v in z.items() if abs(v) > 1e-12}
    i_, j_ = {6: 1.0}, {5: 1.0}
    k_ = mul(i_, j_)
    check(len(k_) == 1 and list(k_)[0] == 3, 'F17 i j is a multiple of e12')
    phi = (1 + 5 ** 0.5) / 2
    def comb(c0, ci, cj, ck):
        out = {0: c0}
        for unit, c in ((i_, ci), (j_, cj), (k_, ck)):
            for lab, v in unit.items():
                out[lab] = out.get(lab, 0) + c * v
        return {k: v for k, v in out.items() if abs(v) > 1e-12}
    g1 = comb(phi / 2, 1 / (2 * phi), 0.5, 0.0)
    g2 = comb(0.5, 0.5, 0.5, 0.5)
    key = lambda x: tuple(round(x.get(lab, 0.0) + 0.0, 7) for lab in even)
    grp = {key({0: 1.0}): {0: 1.0}}
    frontier = [{0: 1.0}]
    while frontier:
        nxt = []
        for x in frontier:
            for g in (g1, g2):
                y = mul(x, g)
                kk = key(y)
                if kk not in grp:
                    grp[kk] = y
                    nxt.append(y)
        frontier = nxt
    check(len(grp) == 120, 'F17 two unit rotors of the even part of Cl(3,0) generate 120 elements (elad·24)')
    vals = sorted({round(x.get(0, 0.0), 6) for x in grp.values()})
    sizes = [sum(1 for x in grp.values() if abs(x.get(0, 0.0) - v) < 1e-6) for v in vals]
    m = grab('elad', r'9 conjugacy classes of sizes \[([0-9, ]+)\]')
    check(sorted(sizes) == ints(m.group(1)), 'F17 class sizes %s (elad·24)' % sorted(sizes))
    exact = [next(x.get(0, 0.0) for x in grp.values() if abs(x.get(0, 0.0) - v) < 1e-6) for v in vals]   # a representative's scalar part
    th = [math.acos(max(-1.0, min(1.0, v))) for v in exact]
    def su2(d):
        return [float(d) if abs(t) < 1e-9 else (float(d) * (-1) ** (d - 1) if abs(t - math.pi) < 1e-9 else math.sin(d * t) / math.sin(t)) for t in th]
    def galois(ch):
        # sqrt5 -> -sqrt5 exchanges the classes with scalar part phi/2 and -1/(2 phi), and 1/(2 phi) and -phi/2
        swap = {round(phi / 2, 6): round(-1 / (2 * phi), 6), round(-1 / (2 * phi), 6): round(phi / 2, 6),
                round(1 / (2 * phi), 6): round(-phi / 2, 6), round(-phi / 2, 6): round(1 / (2 * phi), 6)}
        return [ch[vals.index(swap.get(v, v))] for v in vals]
    chars = {('%d' % d): su2(d) for d in range(1, 7)}
    chars["2'"] = galois(chars['2'])
    chars["3'"] = galois(chars['3'])
    chars["4'"] = [a * b for a, b in zip(chars['2'], chars["2'"])]
    names = ['1', '2', '3', '4', '5', '6', "2'", "3'", "4'"]
    def inner(a, b):
        return sum(s * x * y for s, x, y in zip(sizes, a, b)) / 120
    for a in names:
        for b in names:
            check(abs(inner(chars[a], chars[b]) - (1.0 if a == b else 0.0)) < 1e-9, 'F17 the nine characters are orthonormal')
    dims = [round(chars[a][vals.index(1.0)]) for a in names]
    m2 = grab('elad', r'the full character table, dimensions \[([0-9, ]+)\]')
    check(dims == ints(m2.group(1)), 'F17 dimensions %s (elad·24)' % dims)
    nmat = [[round(inner([x * y for x, y in zip(chars['2'], chars[a])], chars[b])) for b in names] for a in names]
    check(all(nmat[i][j] == nmat[j][i] in (0, 1) for i in range(9) for j in range(9)) and all(nmat[i][i] == 0 for i in range(9)), 'F17 McKay matrix symmetric, 0/1, zero diagonal')
    for i in range(9):
        check(sum(nmat[i][j] * dims[j] for j in range(9)) == 2 * dims[i], 'F17 2 - n kills the dimension vector: the marks of the null root')
    deg = [sum(r) for r in nmat]
    check(sorted(deg) == [1, 1, 1, 2, 2, 2, 2, 2, 3] and sum(deg) == 16, 'F17 a tree with one branch node: affine E8')
    mv = grab('elad', r'null vector \[([0-9, ]+)\]')
    check(sorted(ints(mv.group(1))) == sorted(dims), 'F17 the marks of the affine E8 null root are the dimensions (elad·25)')
    # layout: the branch node, its three arms
    b = deg.index(3)
    arms = []
    for j in range(9):
        if nmat[b][j]:
            arm, prev, cur = [j], b, j
            while True:
                nx = [t for t in range(9) if nmat[cur][t] and t != prev]
                if not nx:
                    break
                prev, cur = cur, nx[0]
                arm.append(cur)
            arms.append(arm)
    arms.sort(key=len)
    check([len(a) for a in arms] == [1, 2, 5], 'F17 arms of lengths 1, 2, 5: affine E8')
    S = SVG(400, 196, 'The McKay graph of the binary icosahedral group: affine E8, the dimensions as marks')
    sp, y0, xb = 44, 120, 36 + 5 * 44
    P = {b: (xb, y0)}
    for t, j in enumerate(arms[2]):
        P[j] = (xb - (t + 1) * sp, y0)
    for t, j in enumerate(arms[1]):
        P[j] = (xb + (t + 1) * sp, y0)
    P[arms[0][0]] = (xb, y0 - 62)
    for i in range(9):
        for j in range(i + 1, 9):
            if nmat[i][j]:
                S.line(P[i][0], P[i][1], P[j][0], P[j][1], 'lk w2')
    for i in range(9):
        x, y = P[i]
        S.circle(x, y, 15, 'sf')
        S.circle(x, y, 15, 'fR o2')
        S.text(x, y + 5, str(dims[i]), 's14 b')
        if y == y0:
            S.text(x, y + 32, 'χ' + names[i].replace("'", '′').translate(SUB), 's11 mu')
        else:
            S.text(x + 22, y + 5, 'χ' + names[i].replace("'", '′').translate(SUB), 's11 mu', 'start')
    S.text(10, 18, 'nodes: the 9 irreducible representations (their dimension);', 's11 t2', 'start')
    S.text(10, 34, 'an edge: χ₂ ⊗ χ contains the other one once', 's11 t2', 'start')
    S.text(10, 186, 'Σ dim² = %d = |2I|; each node: twice its dimension = the sum of its neighbours' % sum(d * d for d in dims), 's10 mu', 'start')
    save('f17_mckay.svg', S)


# ------------------------------------------------------------------ F18: the exceptional Jordan algebra h3(O), its Peirce spaces
def fig_albert():
    mo = lambda x, y: cb.cd_mul(x, y, [-1, -1, -1])
    conj = lambda x: [x[0]] + [-t for t in x[1:]]
    Z = [Fraction(0)] * 8
    def unit(k, c=1):
        v = [Fraction(0)] * 8
        v[k] = Fraction(c)
        return v
    # an element: 3 x 3 matrix of octonions, hermitian
    def basis():
        out = []
        for d in range(3):
            M = [[Z[:] for _ in range(3)] for _ in range(3)]
            M[d][d] = unit(0)
            out.append(('d%d' % (d + 1), M))
        for (i, j) in ((0, 1), (1, 2), (2, 0)):
            for k in range(8):
                M = [[Z[:] for _ in range(3)] for _ in range(3)]
                M[i][j] = unit(k)
                M[j][i] = conj(unit(k))
                out.append(('x%d%d' % (i + 1, j + 1), M))
        return out
    B = basis()
    check(len(B) == 27, 'F18 h3(O) has 27 coordinates: 3 real diagonal + 3 x 8')
    def mmul(X, Y):
        return [[[sum(t) for t in zip(*[mo(X[i][k], Y[k][j]) for k in range(3)])] for j in range(3)] for i in range(3)]
    def jordan(X, Y):
        P, Q = mmul(X, Y), mmul(Y, X)
        return [[[(a + b) / 2 for a, b in zip(P[i][j], Q[i][j])] for j in range(3)] for i in range(3)]
    E1 = B[0][1]
    counts = {}
    for name, X in B:
        Y = jordan(E1, X)
        lam = None
        for i in range(3):
            for j in range(3):
                for t in range(8):
                    if X[i][j][t] != 0:
                        l = Y[i][j][t] / X[i][j][t]
                        check(lam is None or lam == l, 'F18 each coordinate is an eigenvector of L(e1)')
                        lam = l
                    else:
                        check(Y[i][j][t] == 0, 'F18 L(e1) keeps the coordinate')
        counts.setdefault(name[:3] if name.startswith('x') else name, set()).add(lam)
        counts.setdefault(('L', lam), 0)
        counts[('L', lam)] += 1
    mult = {lam: counts[('L', lam)] for lam in (Fraction(1), Fraction(1, 2), Fraction(0))}
    check(mult == {Fraction(1): 1, Fraction(1, 2): 16, Fraction(0): 10}, 'F18 Peirce split for e1: 27 = 1 + 16 + 10 (LNB-021)')
    m = grab('elad', r'nullity exactly (\d+) .*?: f4; those preserving A = h2\(O\) \(diagonal 1, 2 and x12\): (\d+);.*?Peirce 1/2 space x23 \+ x31 \((\d+)\)')
    der, stab, half = (int(t) for t in m.groups())
    check((der, stab, half) == (52, 36, 16), 'F18 elad·21: Der h3(O) = 52 (f4), stabiliser of h2(O) = 36 (so(9)), Peirce 1/2 of e3 = 16')
    S = SVG(410, 300, 'The Albert algebra h3(O): 27 = 3 + 3 × 8 coordinates and the Peirce spaces of e1')
    x0, y0, cw, ch = 16, 52, 76, 56
    lamcls = {Fraction(1): 'fR o3', Fraction(1, 2): 'fC o3', Fraction(0): 'fH o3'}
    entry = {(0, 0): ('ξ₁', 'ℝ'), (1, 1): ('ξ₂', 'ℝ'), (2, 2): ('ξ₃', 'ℝ'), (0, 1): ('x₁₂', '𝕆'), (1, 2): ('x₂₃', '𝕆'), (0, 2): ('x̄₃₁', '𝕆'),
             (1, 0): ('x̄₁₂', '𝕆'), (2, 1): ('x̄₂₃', '𝕆'), (2, 0): ('x₃₁', '𝕆')}
    def lam_of(i, j):
        if i == j:
            return Fraction(1) if i == 0 else Fraction(0)
        return Fraction(1, 2) if 0 in (i, j) else Fraction(0)
    for i in range(3):
        for j in range(3):
            X, Y = x0 + j * cw, y0 + i * ch
            S.rect(X + 2, Y + 2, cw - 4, ch - 4, lamcls[lam_of(i, j)], rx=6)
            t, dom = entry[(i, j)]
            S.text(X + cw / 2, Y + 25, t, 's15 b')
            S.text(X + cw / 2, Y + 42, 'in ' + dom + (' (1)' if i == j else ' (8)'), 's10 t2')
    S.text(10, 18, 'X = X† with real ξᵢ and octonions x₁₂, x₂₃, x₃₁:', 's11 t2', 'start')
    S.text(10, 34, '3 + 3 × 8 = 27; X ∘ Y = (XY + YX)/2', 's11 t2', 'start')
    tx = 258
    S.text(tx, 66, 'e₁ = diag(1, 0, 0):', 's12 b', 'start')
    for k, (lam, lab) in enumerate(((Fraction(1), 'eigenvalue 1: 1'), (Fraction(1, 2), 'eigenvalue ½: 16'), (Fraction(0), 'eigenvalue 0: 10'))):
        S.rect(tx, 80 + k * 22, 14, 14, lamcls[lam], rx=3)
        S.text(tx + 20, 92 + k * 22, lab, 's11 t2', 'start')
    S.text(tx, 160, 'Derivations: %d (f₄)' % der, 's11 t2', 'start')
    S.text(tx, 176, 'fixing h₂(𝕆): %d (so(9))' % stab, 's11 t2', 'start')
    S.text(tx, 192, 'Peirce ½ of e₃: %d, the' % half, 's11 t2', 'start')
    S.text(tx, 208, 'spinor of Spin(9)', 's11 t2', 'start')
    S.text(10, 238, 'The colours: the eigenvalues of X ↦ e₁ ∘ X, computed by figs_alg.py with', 's11 t2', 'start')
    S.text(10, 254, 'the octonions of the Atlas (Cayley–Dickson on the labels); the', 's11 t2', 'start')
    S.text(10, 270, 'numbers at the right are those of e_ladder.log (elad·21, elad·22).', 's11 t2', 'start')
    save('f18_albert.svg', S)


# ------------------------------------------------------------------ F19: the radical of Cl(1,1,2), its layers
def fig_radical():
    eps = (1, -1, 0, 0)
    A = bc.Alg(eps)
    nullmask = 0b1100
    layer = lambda a: pc(a & nullmask)
    for a in range(16):
        for b in range(16):
            s, c = A.blade_mul(a, b)
            if s:
                check(layer(c) == layer(a) + layer(b), 'F19 a non-zero product adds the null bits')
    # J^3 = 0: three labels each with a null bit multiply to 0
    z = all(A.blade_mul(A.blade_mul(a, b)[1], c)[0] * A.blade_mul(a, b)[0] == 0 for a in range(16) for b in range(16) for c in range(16) if layer(a) and layer(b) and layer(c))
    check(z, 'F19 J^3 = 0 for r = 2 null generators (T2 (3))')
    dims = [sum(1 for a in range(16) if layer(a) == k) for k in range(3)]
    check(dims == [4, 8, 4], 'F19 layers C(2,k) 2^(p+q) = 4, 8, 4')
    S = SVG(420, 236, 'The radical of Cl(1,1,2): the labels in three layers by their null bits')
    rows = [[a for a in range(16) if layer(a) == k] for k in range(3)]
    titles = ['no null bit: the quotient Cl(1,1) (4)', 'one null bit: J / J² (8)', 'two null bits: J² (4)']
    cls = ['fR o2', 'fC o2', 'fH o2']
    for k, row in enumerate(rows):
        y = 40 + k * 64
        S.text(10, y - 6, titles[k], 's11 t2', 'start')
        w = 48
        for t, a in enumerate(row):
            X = 10 + t * w
            S.rect(X + 1, y, w - 3, 26, cls[k], rx=4)
            S.text(X + w / 2, y + 17.5, bname(a), 's11')
    S.text(10, 214, 'squares (+, −, 0, 0): e₃, e₄ null. e₁ · e₃ = e₁₃ and e₁₃ · e₄ = e₁₃₄ step down;', 's11 t2', 'start')
    S.text(10, 229, 'a product adds the null bits or vanishes: J³ = 0, dim J = 16 − 4 = 12', 's11 t2', 'start')
    save('f19_radical.svg', S)


def main():
    figs = [fig_three_n2, fig_cube, fig_cl20_gauge, fig_clock_wheel, fig_gauss, fig_type_table, fig_octonions, fig_min_ideal,
            fig_cokernels, fig_koszul, fig_frobenius, fig_e8_in_I18, fig_forms_wheel, fig_e8_roots, fig_gosset, fig_commutator,
            fig_mckay, fig_albert, fig_radical]
    for f in figs:
        f()
    print('figs_alg.py: %d figures, %d checks' % (len(WRITTEN), len(REPORT)))
    for name, size in WRITTEN:
        print('  %-24s %6d bytes' % (name, size))
    seen = []
    for r in REPORT:
        if r not in seen:
            seen.append(r)
    for r in seen:
        print('  ok  ' + r)


if __name__ == '__main__':
    main()
