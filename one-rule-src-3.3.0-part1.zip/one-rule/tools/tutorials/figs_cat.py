#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# figs_cat.py -- every figure of figs/ for the tutorial "Category theory on the bit rule", drawn from the Atlas's objects.
# Run:  python3 -I -B figs_cat.py [--repo DIR]   (DIR defaults to the repository v3/one-rule beside the folder tut/ of this file)
# The rule is the Atlas's own: checks/researchers_checks/bitrule_A.py of the repository, imported by path (no copy of it here).
# Every number drawn is computed below from that rule. Where a shipped log or page of the Atlas states the same number, the
# script builds the sentence from its own result and looks for it in that file: a difference stops the script.
# It also checks the self-test vectors stored in widgets/*.js against the same rule.
# Deterministic: no clock, no random number, the SVG is written by hand; the same script gives the same bytes.
import os, sys, re, math, importlib.util
from fractions import Fraction
from pathlib import Path
from itertools import permutations

HERE = Path(__file__).resolve().parent
REPO = Path(sys.argv[sys.argv.index('--repo') + 1]).resolve() if '--repo' in sys.argv else Path(os.environ['ATLAS_REPO']).resolve() if os.environ.get('ATLAS_REPO') else HERE.parents[1]   # the repository: --repo, ATLAS_REPO, else two folders up from tools/tutorials/
FIGS = REPO / 'public' / 'reports' / 'tutorials' / 'src' / 'cat' / 'figs'   # the figures, beside the tutorial's source
FIGS.mkdir(exist_ok=True)
_spec = importlib.util.spec_from_file_location('bitrule_A', REPO / 'checks' / 'researchers_checks' / 'bitrule_A.py')
_br = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_br)
BR, popcount, N_pairs, rank_fr = _br.BR, _br.popcount, _br.N_pairs, _br.rank_fr
LOG = 'checks/selfcheck/proofs/logs/'
AGREE, DONE = [], []


def agree(where, needle):
    """the sentence `needle`, built from a computed result, must occur in the shipped file `where` (path in the repository)"""
    text = (REPO / where).read_text(encoding='utf8')
    if needle not in text:
        raise SystemExit(f'figs_cat.py: {where} does not state "{needle}" (computed here)')
    AGREE.append((where, needle))


# ------------------------------------------------------------------------------------------------ names of labels
SUB = '₀₁₂₃₄₅₆₇₈₉'
MINUS = '−'
PRIMES = [2, 3, 5, 7, 11]


def en(a):
    return '1' if a == 0 else 'e' + ''.join(SUB[i + 1] for i in range(9) if a >> i & 1)


def bits(a, n):
    return ''.join('1' if a >> (n - 1 - i) & 1 else '0' for i in range(n))


def pn(a):
    v = 1
    for i in range(5):
        if a >> i & 1:
            v *= PRIMES[i]
    return v


def sg(s):
    return '+' if s > 0 else (MINUS if s < 0 else '0')


def lam(A, x):
    """the top-label form: the coefficient of the full label in x"""
    return x.get(A.M - 1, 0)


# ------------------------------------------------------------------------------------------------ SVG by hand
def esc(s):
    return str(s).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')


def fm(x):
    s = f'{x:.1f}'
    return s[:-2] if s.endswith('.0') else s


DK = ':root:not([data-theme="light"]) '
STYLE = ('<style>'
         '.cx text{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;fill:var(--ink,#1a1a19)}'
         '.cx .t2{fill:var(--ink2,#46463f)}.cx .mu{fill:var(--muted,#6b6b64)}'
         '.cx .ln{stroke:var(--line2,#c9c8c0);fill:none}.cx .ink{stroke:var(--ink2,#46463f);fill:none}'
         '.cx .bx{fill:var(--surf,#fff);stroke:var(--line2,#c9c8c0)}.cx .tn{fill:var(--tint,#f3f2ee)}'
         '.cx .pos{fill:#2a78d6;fill-opacity:.3}.cx .neg{fill:#e34948;fill-opacity:.32}.cx .nul{fill:var(--tint,#f3f2ee)}'
         '.cx .ac{stroke:var(--acc,#184f95);fill:none}.cx .acf{fill:var(--acc,#184f95)}.cx .mk{fill:var(--ink2,#46463f)}'
         '.cx .ev{fill:#1baf7a;fill-opacity:.3}.cx .od{fill:#eda100;fill-opacity:.36}'
         '.cx .s1{fill:#2a78d6}.cx .s2{fill:#eb6834}.cx .s3{fill:#1baf7a}'
         '@media (prefers-color-scheme:dark){' + DK + '.cx .pos{fill:#3987e5;fill-opacity:.42}' + DK + '.cx .neg{fill:#e66767;fill-opacity:.42}'
         + DK + '.cx .s1{fill:#3987e5}' + DK + '.cx .s2{fill:#d95926}' + DK + '.cx .s3{fill:#199e70}}'
         ':root[data-theme="dark"] .cx .pos{fill:#3987e5;fill-opacity:.42}:root[data-theme="dark"] .cx .neg{fill:#e66767;fill-opacity:.42}'
         ':root[data-theme="dark"] .cx .s1{fill:#3987e5}:root[data-theme="dark"] .cx .s2{fill:#d95926}:root[data-theme="dark"] .cx .s3{fill:#199e70}'
         '</style>')


class Fig:
    def __init__(self, name, w, h, label):
        self.name, self.w, self.h, self.label, self.el = name, w, h, label, []
        self.mid = 'cxm-' + name.split('_')[0]

    def t(self, x, y, s, size=13, anchor='middle', cls=None, bold=False, italic=False):
        a = [f'x="{fm(x)}"', f'y="{fm(y)}"', f'font-size="{size}"']
        if anchor != 'start':
            a.append(f'text-anchor="{anchor}"')
        if cls:
            a.append(f'class="{cls}"')
        if bold:
            a.append('font-weight="600"')
        if italic:
            a.append('font-style="italic"')
        self.el.append(f'<text {" ".join(a)}>{esc(s)}</text>')

    def r(self, x, y, w, h, cls, rx=0, sw=None):
        a = f'<rect x="{fm(x)}" y="{fm(y)}" width="{fm(w)}" height="{fm(h)}" class="{cls}"'
        if rx:
            a += f' rx="{fm(rx)}"'
        if sw:
            a += f' stroke-width="{sw}"'
        self.el.append(a + '/>')

    def l(self, x1, y1, x2, y2, cls='ln', sw=1, dash=None, arrow=False):
        a = f'<line x1="{fm(x1)}" y1="{fm(y1)}" x2="{fm(x2)}" y2="{fm(y2)}" class="{cls}" stroke-width="{sw}"'
        if dash:
            a += f' stroke-dasharray="{dash}"'
        if arrow:
            a += f' marker-end="url(#{self.mid})"'
        self.el.append(a + '/>')

    def p(self, d, cls='ln', sw=1, dash=None, arrow=False):
        a = f'<path d="{d}" class="{cls}" stroke-width="{sw}"'
        if dash:
            a += f' stroke-dasharray="{dash}"'
        if arrow:
            a += f' marker-end="url(#{self.mid})"'
        self.el.append(a + '/>')

    def c(self, x, y, rad, cls, sw=None):
        a = f'<circle cx="{fm(x)}" cy="{fm(y)}" r="{fm(rad)}" class="{cls}"'
        if sw:
            a += f' stroke-width="{sw}"'
        self.el.append(a + '/>')

    def node(self, x, y, s, w=46, h=22, cls='bx', size=13, bold=False):
        self.r(x - w / 2, y - h / 2, w, h, cls, rx=h / 2)
        self.t(x, y + size * 0.36, s, size=size, bold=bold)

    def arrow(self, x1, y1, x2, y2, d1=12, d2=13, **kw):
        L = math.hypot(x2 - x1, y2 - y1)
        ux, uy = (x2 - x1) / L, (y2 - y1) / L
        self.l(x1 + ux * d1, y1 + uy * d1, x2 - ux * d2, y2 - uy * d2, arrow=True, **kw)

    def save(self):
        defs = (f'<defs><marker id="{self.mid}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" '
                f'orient="auto-start-reverse"><path d="M0,1 L10,5 L0,9 z" class="mk"/></marker></defs>')
        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" class="cx" viewBox="0 0 {self.w} {self.h}" width="{self.w}" '
               f'height="{self.h}" role="img" aria-label="{esc(self.label)}">' + STYLE + defs + ''.join(self.el) + '</svg>\n')
        b = svg.encode('utf8')
        assert len(b) < 80000, (self.name, len(b))
        (FIGS / f'{self.name}.svg').write_bytes(b)
        DONE.append((self.name, len(b)))


def sign_cell(F, x, y, w, h, s, text=None, size=12):
    F.r(x + 1, y + 1, w - 2, h - 2, 'pos' if s > 0 else 'neg' if s < 0 else 'nul', rx=3)
    F.t(x + w / 2, y + h / 2 + size * 0.36, sg(s) if text is None else text, size=size)


def b3_pos(x0, y0, dx, dy):
    """positions of the labels of B_3: grade k on the line y0 - k dy; e1, e2, e3 and e12, e13, e23 from left to right"""
    P = {0: (x0, y0), 7: (x0, y0 - 3 * dy)}
    for k, a in enumerate([1, 2, 4]):
        P[a] = (x0 + (k - 1) * dx, y0 - dy)
    for k, a in enumerate([3, 5, 6]):
        P[a] = (x0 + (k - 1) * dx, y0 - 2 * dy)
    return P


def covers(n):
    return [(a, a | 1 << i) for a in range(1 << n) for i in range(n) if not a >> i & 1]


# ------------------------------------------------------------------------------------------------ exact linear algebra
def rank_f2(rows):
    basis, r = {}, 0
    for v in rows:
        while v:
            p = v.bit_length() - 1
            if p in basis:
                v ^= basis[p]
            else:
                basis[p] = v
                r += 1
                break
    return r


def inertia(M):
    """(positive, negative, zero) of a symmetric rational matrix, by congruence"""
    A = [[Fraction(x) for x in row] for row in M]
    n, pos, neg, idx = len(A), 0, 0, list(range(len(A)))
    while idx:
        piv = next((i for i in idx if A[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in idx for j in idx if i != j and A[i][j] != 0), None)
            if pair is None:
                break
            i, j = pair
            for k in range(n):
                A[i][k] += A[j][k]
            for k in range(n):
                A[k][i] += A[k][j]
            piv = i
        d = A[piv][piv]
        pos, neg = pos + (d > 0), neg + (d < 0)
        idx.remove(piv)
        for i in idx:
            if A[i][piv] != 0:
                f = A[i][piv] / d
                for k in range(n):
                    A[i][k] -= f * A[piv][k]
                for k in range(n):
                    A[k][i] -= f * A[k][piv]
    return pos, neg, n - pos - neg


def mat_rank(rows):
    return rank_fr([{j: v for j, v in enumerate(r) if v} for r in rows], len(rows[0]) if rows else 0)


# ================================================================================================ fig01: n = 2, three algebras
def fig01():
    F = Fig('fig01_n2_three_algebras', 440, 476, 'The sign tables of the bit rule at n = 2 for the squares (+,+), (−,−) and (0,0)')
    rows = [((1, 1), '(+,+)', 'Cl(2,0) = M₂(ℝ)'), ((-1, -1), '(' + MINUS + ',' + MINUS + ')', 'Cl(0,2) = ℍ'),
            ((0, 0), '(0,0)', 'Cl(0,0,2) = Λ(ℝ²)')]
    counts = []
    for k, (eps, sq, name) in enumerate(rows):
        A, y0, x0, cw, ch = BR(eps), 10 + k * 156, 58, 46, 27
        F.t(x0 - 8, y0 + 18, 'a \\ b', size=11, anchor='end', cls='mu')
        for b in range(4):
            F.t(x0 + b * cw + cw / 2, y0 + 18, en(b), cls='t2')
        for a in range(4):
            yy = y0 + 26 + a * ch
            F.t(x0 - 10, yy + 18, en(a), anchor='end', cls='t2')
            for b in range(4):
                s = A.s(a, b)
                sign_cell(F, x0 + b * cw, yy, cw, ch, s, '0' if s == 0 else ('' if s > 0 else MINUS) + en(a ^ b), 12.5)
        z = sum(A.s(a, b) == 0 for a in range(4) for b in range(4))
        m = sum(A.s(a, b) < 0 for a in range(4) for b in range(4))
        counts.append((z, m))
        tx = x0 + 4 * cw + 16
        F.t(tx, y0 + 46, 'squares ' + sq, anchor='start', bold=True)
        F.t(tx, y0 + 68, name, anchor='start')
        F.t(tx, y0 + 96, f'{z} of 16 products vanish', anchor='start', cls='t2')
        F.t(tx, y0 + 116, f'{m} carry a minus sign', anchor='start', cls='t2')
    F.save()
    (z1, m1), (z2, m2), (z3, m3) = counts
    agree('public/reports/html/bit_rule_tutorial.html', f'{z1}, {z2} and {z3} of the 16 products vanish and {m1}, {m2} and {m3} carry a minus sign')


# ================================================================================================ fig02: B3 as a poset and as a category
def fig02():
    F = Fig('fig02_b3_poset_category', 440, 576, 'The cube category B3: the Hasse diagram of the poset and the 27 arrows of the category')
    arrows = [(a, b) for a in range(8) for b in range(8) if a & b == a]
    pairs = sum(1 for (a, b) in arrows for (c, d) in arrows if c == b)
    cov = covers(3)
    comp2 = [(a, b) for (a, b) in arrows if popcount(b) - popcount(a) == 2]
    comp3 = [(a, b) for (a, b) in arrows if popcount(b) - popcount(a) == 3]
    assert (len(arrows), len(cov), len(comp2), len(comp3), pairs) == (27, 12, 6, 1, 64)
    F.t(14, 20, 'B₃ as a poset: a ⊆ b, the 12 covering relations', anchor='start', bold=True)
    P = b3_pos(220, 226, 92, 62)
    for (a, b) in cov:
        F.l(*P[a], *P[b], cls='ink', sw=1.2)
    for a in range(8):
        F.node(*P[a], en(a))
    F.t(14, 270, 'B₃ as a category: one arrow a → b for each a ⊆ b', anchor='start', bold=True)
    Q = b3_pos(220, 496, 92, 62)
    for (a, b) in cov:
        F.arrow(*Q[a], *Q[b], cls='ink', sw=1.2)
    for a in range(8):
        x, y = Q[a]
        F.p(f'M{fm(x - 23)},{fm(y - 5)} C{fm(x - 46)},{fm(y - 20)} {fm(x - 46)},{fm(y + 20)} {fm(x - 25)},{fm(y + 6)}', cls='ink', sw=1, arrow=True)
    bend = {(0, 5): 58, (2, 7): -58}
    for (a, b) in comp2:
        (x1, y1), (x2, y2) = Q[a], Q[b]
        if (a, b) in bend:
            cxp = (x1 + x2) / 2 + bend[(a, b)]
            F.p(f'M{fm(x1 + 8)},{fm(y1 - 11)} Q{fm(cxp)},{fm((y1 + y2) / 2)} {fm(x2 + (8 if bend[(a, b)] > 0 else -8))},{fm(y2 + 12)}',
                cls='ink', sw=1, dash='5 3', arrow=True)
        else:
            L = math.hypot(x2 - x1, y2 - y1)
            ux, uy = (x2 - x1) / L, (y2 - y1) / L
            F.l(x1 + ux * 14, y1 + uy * 14, x2 - ux * 16, y2 - uy * 16, cls='ink', sw=1, dash='5 3', arrow=True)
    (x1, y1), (x2, y2) = Q[0], Q[7]
    F.p(f'M{fm(x1 + 23)},{fm(y1)} C{fm(x1 + 196)},{fm(y1)} {fm(x2 + 196)},{fm(y2)} {fm(x2 + 25)},{fm(y2)}', cls='ink', sw=1, dash='1.5 3', arrow=True)
    for a in range(8):
        F.node(*Q[a], en(a))
    y = 532
    F.t(14, y, f'{len(arrows)} = 3³ arrows: 8 identities (loops), {len(cov)} covers (solid),', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 18, f'{len(comp2)} composites of length two (dashed), {len(comp3)} of length three (dotted);', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 36, f'{pairs} = 4³ composable pairs. At most one arrow between two objects: thin.', anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig03: chains
def chains_table(nmax=6):
    out = {}
    for n in range(nmax + 1):
        N = 1 << n
        weak = []
        cnt = [1] * N
        weak.append(sum(cnt))
        for k in range(1, 5):
            cnt = [sum(cnt[s] for s in range(N) if s & m == s) for m in range(N)]
            weak.append(sum(cnt))
        fub = [0] * N
        fub[0] = 1
        for m in range(1, N):
            fub[m] = sum(fub[s] for s in range(N) if s & m == s and s != m)
        maxi = [0] * N
        maxi[0] = 1
        for m in range(1, N):
            maxi[m] = sum(maxi[m & ~(1 << i)] for i in range(n) if m >> i & 1)
        out[n] = dict(simp=weak, fub=fub[N - 1], maxi=maxi[N - 1])
    return out


def fig03():
    F = Fig('fig03_chains', 440, 444, 'The six maximal chains of B3 and the counts of chains and simplices of the nerve of Bn')
    F.t(14, 20, 'The maximal chains 1 ⊂ eᵢ ⊂ eᵢⱼ ⊂ e₁₂₃ of B₃', anchor='start', bold=True)
    chains = []
    for perm in permutations(range(3)):
        ch, m = [0], 0
        for i in perm:
            m |= 1 << i
            ch.append(m)
        chains.append((perm, ch))
    for k, (perm, ch) in enumerate(chains):
        cx, by = 78 + (k % 3) * 142, 118 + (k // 3) * 132
        P = b3_pos(cx, by, 34, 28)
        for (a, b) in covers(3):
            F.l(*P[a], *P[b], cls='ln', sw=1)
        for j in range(3):
            F.l(*P[ch[j]], *P[ch[j + 1]], cls='ac', sw=3)
        for a in range(8):
            F.c(*P[a], 4.5 if a in ch else 3.5, 'acf' if a in ch else 'tn')
        F.t(cx, by + 22, 'switches ' + ', '.join(str(i + 1) for i in perm), size=12.5, cls='t2')
    T = chains_table(6)
    for n in range(2, 6):
        agree(LOG + 'reruns/mjc_labels.log', f'n={n}: {T[n]["simp"]}')
    y0, x0, cw = 326, 168, 38
    F.t(14, y0 - 22, 'Counts in Bₙ (computed by the script, n = 0 … 6)', anchor='start', bold=True)
    F.t(x0 - 8, y0, 'n', anchor='end', cls='mu', size=12.5)
    for n in range(7):
        F.t(x0 + n * cw + cw / 2, y0, str(n), cls='mu', size=12.5)
    rowsT = [('objects 2ⁿ', [T[n]['simp'][0] for n in range(7)]), ('arrows 3ⁿ', [T[n]['simp'][1] for n in range(7)]),
             ('composable pairs 4ⁿ', [T[n]['simp'][2] for n in range(7)]), ('maximal chains n!', [T[n]['maxi'] for n in range(7)]),
             ('chains 1 → top', [T[n]['fub'] for n in range(7)])]
    for j, (name, vals) in enumerate(rowsT):
        y = y0 + 22 + j * 21
        if j % 2 == 0:
            F.r(10, y - 15, 424, 21, 'tn', rx=3)
        F.t(x0 - 8, y, name, anchor='end', size=12.5, cls='t2')
        for n, v in enumerate(vals):
            F.t(x0 + n * cw + cw / 2, y, str(v), size=12.5)
    assert [T[n]['maxi'] for n in range(7)] == [math.factorial(n) for n in range(7)]
    F.save()
    return T


# ================================================================================================ fig04: the grade functor
def fig04():
    F = Fig('fig04_grade_functor', 440, 520, 'The grade as a functor from B3 to the monoid of natural numbers, and the table of 2|a AND b|')
    F.t(14, 20, 'The grade: a functor B₃ → (ℕ, +), a → b ↦ |b| − |a|', anchor='start', bold=True)
    P = b3_pos(170, 214, 70, 56)
    for k in range(4):
        y = 214 - k * 56
        F.t(30, y + 4.5, str(k), cls='mu', size=12.5)
        F.l(40, y, 52, y, cls='ln')
    F.t(30, 40, '|a|', cls='mu', size=12.5)
    for (a, b) in covers(3):
        F.arrow(*P[a], *P[b], cls='ink', sw=1.1)
    for a in range(8):
        F.node(*P[a], en(a), cls='ev' if popcount(a) % 2 == 0 else 'od')
    ox, oy = 368, 128
    F.c(ox, oy, 6, 'acf')
    F.t(ox, oy + 26, '★ = ℕ', size=12.5)
    for k, (dx, dy) in enumerate([(-30, -26), (0, -40), (30, -26)]):
        F.p(f'M{fm(ox - 3)},{fm(oy - 5)} C{fm(ox + dx - 18)},{fm(oy + dy - 14)} {fm(ox + dx + 18)},{fm(oy + dy - 14)} {fm(ox + 3)},{fm(oy - 5)}',
            cls='ink', sw=1)
        F.t(ox + dx * 1.15, oy + dy - 18, str(k + 1), size=12.5)
    F.p(f'M262,128 L330,128', cls='ac', sw=2, arrow=True)
    F.t(296, 118, '| |', size=13)
    F.t(ox, oy + 42, 'identities ↦ 0', size=12, cls='t2')
    F.t(300, 196, 'green: even grade', anchor='start', size=12, cls='t2')
    F.t(300, 214, 'amber: odd grade', anchor='start', size=12, cls='t2')
    F.t(300, 232, 'the parity: to ℤ₂', anchor='start', size=12, cls='t2')
    # the defect table
    y0, x0, c = 270, 52, 26
    F.t(14, y0 - 10, '|a| + |b| − |a ⊕ b| = 2|a ∧ b| on the 64 pairs of labels', anchor='start', bold=True)
    for b in range(8):
        F.t(x0 + b * c + c / 2, y0 + 14, en(b), size=11.5, cls='t2')
    zero = 0
    for a in range(8):
        y = y0 + 22 + a * c
        F.t(x0 - 6, y + 17, en(a), size=11.5, cls='t2', anchor='end')
        for b in range(8):
            d = popcount(a) + popcount(b) - popcount(a ^ b)
            assert d == 2 * popcount(a & b)
            zero += d == 0
            F.r(x0 + b * c + 1, y + 1, c - 2, c - 2, 'pos' if d == 0 else 'nul', rx=3)
            F.t(x0 + b * c + c / 2, y + 17.5, str(d), size=12)
    tx = x0 + 8 * c + 14
    lines = [f'{zero} = 3³ zeros: the disjoint', 'pairs, the arrows of B₃;', 'there the grade adds.', '',
             f'{64 - zero} = 4³ − 3³ pairs share', 'a switch: the grade drops', 'by an even number.', '',
             'So |a| is a functor on B₃', 'and a grading of Λ(ℝ³),', 'not of Cl(3,0); the parity', 'is a grading of every cell.']
    for k, s in enumerate(lines):
        F.t(tx, y0 + 40 + k * 18, s, anchor='start', size=12.5, cls='t2')
    assert zero == 27
    F.save()


# ================================================================================================ fig05: the super-sign table
def fig05():
    F = Fig('fig05_super_sign', 440, 560, 'The Koszul sign of super vector spaces against the swap sign of Cl(3,0) on the 64 pairs of labels')
    A = BR((1, 1, 1))
    x0, c = 52, 26
    diff = 0
    for panel in range(2):
        y0 = 12 + panel * 262
        F.t(14, y0 + 10, ['Koszul sign (−1)^(|a||b|): the braiding of sVec', 'Swap sign of Cl(3,0): eₐ e_b = σ e_b eₐ'][panel],
            anchor='start', bold=True)
        for b in range(8):
            F.t(x0 + b * c + c / 2, y0 + 34, en(b), size=11.5, cls='t2')
        for a in range(8):
            y = y0 + 42 + a * c
            F.t(x0 - 6, y + 17, en(a), size=11.5, cls='t2', anchor='end')
            for b in range(8):
                kz = -1 if popcount(a) * popcount(b) % 2 else 1
                sw = A.s(a, b) * A.s(b, a)
                assert sw == kz * (-1) ** popcount(a & b)
                v = kz if panel == 0 else sw
                sign_cell(F, x0 + b * c, y, c, c, v)
                if panel == 1 and sw != kz:
                    diff += 1
                    F.c(x0 + b * c + c / 2, y + c / 2, 10.5, 'ac', sw=1.4)
    tx = x0 + 8 * c + 14
    l1 = ['Rows a, columns b.', 'Blue +: the order does not', 'matter; red −: a sign.', '',
          'The parity |a| mod 2 is the', 'grading of super vector', 'spaces; their symmetry', 'v ⊗ w ↦ ± w ⊗ v carries', 'this sign.']
    l2 = [f'Ringed: the {diff} pairs where', 'the two signs differ, exactly', 'those with |a ∧ b| odd:', 'σ = (−1)^(|a||b| + |a ∧ b|).', '',
          'On the 27 disjoint pairs σ is', 'the Koszul sign for every', 'choice of squares; in Λ(ℝ³)', 'the other 37 products are 0.']
    for k, s in enumerate(l1):
        F.t(tx, 70 + k * 18, s, anchor='start', size=12.5, cls='t2')
    for k, s in enumerate(l2):
        F.t(tx, 332 + k * 18, s, anchor='start', size=12.5, cls='t2')
    assert diff == (4 ** 3 - 2 ** 3) // 2
    # every choice of squares: disjoint pairs swap with the Koszul sign, overlapping non-zero ones with the extra (-1)^|a and b|
    ok = all((A2.s(a, b) * A2.s(b, a) == (-1) ** (popcount(a) * popcount(b))) if a & b == 0 else
             (A2.s(a, b) == 0 or A2.s(a, b) * A2.s(b, a) == (-1) ** (popcount(a) * popcount(b) + popcount(a & b)))
             for A2 in [BR(e) for e in __import__('itertools').product((1, -1, 0), repeat=3)] for a in range(8) for b in range(8))
    assert ok
    agree(LOG + 'reruns/mja_exterior.log', 'disjoint blades satisfy e_a e_b = (-1)^{|a||b|} e_b e_a for every eps')
    agree(LOG + 'reruns/mja_exterior.log', 'overlapping pairs with nonzero product: exponent |a||b| + |a AND b|')
    F.save()


# ================================================================================================ fig06: a presheaf on B2
def restriction_is_algebra_map(eps, S):
    """pi_S on Cl(eps) (n = 2): e_a -> e_a if a is in S, else 0; an algebra map?"""
    A = BR(eps)
    for a in range(4):
        for b in range(4):
            s = A.s(a, b)
            lhs = s if (a ^ b) & ~S == 0 else 0
            rhs = s if (a & ~S == 0 and b & ~S == 0) else 0
            if lhs != rhs:
                return False
    return True


def yoneda_count(n):
    """natural transformations hom(-, T) => F with F(S) = subsets of S, F(S' in S)(x) = x and S', by brute force"""
    out = {}
    for T in range(1 << n):
        subs = [S for S in range(1 << n) if S & T == S]
        choices = [[x for x in range(1 << n) if x & S == x] for S in subs]
        count = 0

        def rec(i, pick):
            nonlocal count
            if i == len(subs):
                if all(pick[j] & subs[k] == pick[k] for j in range(len(subs)) for k in range(len(subs)) if subs[k] & subs[j] == subs[k]):
                    count += 1
                return
            for x in choices[i]:
                rec(i + 1, pick + [x])
        rec(0, [])
        out[T] = count
    return out


def fig06():
    F = Fig('fig06_presheaf_b2', 440, 488, 'The cell as a presheaf on B2: the spaces P(S) and the restrictions')
    F.t(14, 20, 'P(S) = span{eₐ : a ⊆ S}, a functor B₂ᵒᵖ → Vect', anchor='start', bold=True)
    pos = {3: (220, 62), 1: (100, 152), 2: (340, 152), 0: (220, 242)}
    content = {S: [a for a in range(4) if a & S == a] for S in range(4)}
    for S, (x, y) in pos.items():
        F.r(x - 66, y - 20, 132, 40, 'bx', rx=8)
        F.t(x, y - 4, 'P(' + ('∅' if S == 0 else '{' + ','.join(str(i + 1) for i in range(2) if S >> i & 1) + '}') + ')', size=12, cls='t2')
        F.t(x, y + 13, '⟨' + ', '.join(en(a) for a in content[S]) + '⟩', size=13)
    for (T, S, lx, ly, anc) in [(3, 1, 128, 102, 'end'), (3, 2, 312, 102, 'start'), (1, 0, 128, 206, 'end'), (2, 0, 312, 206, 'start')]:
        (x1, y1), (x2, y2) = pos[T], pos[S]
        F.arrow(x1 + (x2 - x1) * 0.18, y1 + 20, x2 - (x2 - x1) * 0.18, y2 - 20, d1=0, d2=2, cls='ink', sw=1.2)
        killed = [a for a in content[T] if a & S != a]
        F.t(lx, ly, ', '.join(en(a) for a in killed) + ' ↦ 0', anchor=anc, size=12, cls='t2')
    F.arrow(220, 82, 220, 222, d1=0, d2=2, cls='ink', sw=1, dash='5 3')
    F.t(226, 158, 'all but 1 ↦ 0', anchor='start', size=12, cls='t2')
    for (n, S) in [(2, 3)]:
        pass
    # which restrictions are algebra maps
    y0 = 300
    F.t(14, y0, 'Is the restriction P({1,2}) → P(S) an algebra map?', anchor='start', bold=True)
    cells = [((1, 1), 'Cl(2,0)'), ((1, 0), 'Cl(1,0,1)'), ((0, 0), 'Cl(0,0,2)')]
    for j, (_, name) in enumerate(cells):
        F.t(212 + j * 80, y0 + 24, name, size=12.5, cls='t2')
    for i, (S, lab) in enumerate([(1, 'to P({1}): drop e₂'), (2, 'to P({2}): drop e₁'), (0, 'to P(∅): drop both')]):
        y = y0 + 46 + i * 24
        F.t(150, y, lab, anchor='end', size=12.5, cls='t2')
        for j, (eps, _) in enumerate(cells):
            ok = restriction_is_algebra_map(eps, S)
            F.r(212 + j * 80 - 30, y - 15, 60, 21, 'pos' if ok else 'nul', rx=4)
            F.t(212 + j * 80, y, 'yes' if ok else 'no', size=12.5)
    yc = yoneda_count(2)
    y = y0 + 132
    F.t(14, y, 'Yes exactly when every dropped generator is null (e₂ of Cl(1,0,1)).', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 20, 'Yoneda, with F(S) = the subsets of S: the natural maps', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 40, 'hom(−, T) ⇒ F number ' + ', '.join(str(yc[T]) for T in [0, 1, 2, 3]) + ' = |F(T)| = 2^|T| for T = ∅, {1}, {2}, {1,2}.',
        anchor='start', size=12.5, cls='t2')
    assert [yc[T] for T in range(4)] == [1, 2, 2, 4] and all(v == 2 ** popcount(T) for T, v in yoneda_count(3).items())
    assert [restriction_is_algebra_map(e, S) for e in [(1, 1), (1, 0), (0, 0)] for S in [1, 2, 0]] == [False] * 3 + [True, False, False] + [True] * 3
    F.save()


# ================================================================================================ fig07: AND, OR, XOR with prime names
def fig07():
    F = Fig('fig07_and_or_xor', 440, 534, 'The labels of B3 as the divisors of 30: meet, join and the label of the product')
    F.t(14, 20, 'B₃ with prime names: e₁ = 2, e₂ = 3, e₃ = 5', anchor='start', bold=True)
    for n in (3, 4):
        for a in range(1 << n):
            for b in range(1 << n):
                pa, pb = pn(a), pn(b)
                g = math.gcd(pa, pb)
                assert pn(a & b) == g and pn(a | b) == pa * pb // g and pn(a ^ b) == pa * pb // (g * g)
                for c in range(1 << n):
                    assert ((c & a == c) and (c & b == c)) == (c & (a & b) == c)
                    assert ((a & c == a) and (b & c == b)) == ((a | b) & c == (a | b))
    P = b3_pos(200, 266, 104, 70)
    for (a, b) in covers(3):
        F.l(*P[a], *P[b], cls='ink', sw=1.1)
    A, B = 3, 6
    roles = {A: 'a', B: 'b', A & B: '∧', A | B: '∨', A ^ B: '⊕'}
    for m in range(8):
        x, y = P[m]
        if m in roles:
            F.r(x - 27, y - 15, 54, 30, 'ac', rx=15, sw=2.2)
        F.node(x, y, str(pn(m)), w=50, h=26, size=14, bold=m in roles)
        F.t(x, y + 30, en(m), size=11.5, cls='mu')
    for m, lab in roles.items():
        x, y = P[m]
        F.t(x + 30, y - 13, lab, anchor='start', size=14, bold=True)
    y0 = 332
    F.t(14, y0, f'The two labels a = {pn(A)} = {en(A)} and b = {pn(B)} = {en(B)}', anchor='start', bold=True)
    hdr = ['', 'bits', 'primes', 'in B₃']
    xs = [14, 138, 196, 300]
    for j, h in enumerate(hdr):
        F.t(xs[j], y0 + 26, h, anchor='start', size=12.5, cls='mu')
    rowsT = [('a ∧ b, AND, meet', f'{bits(A & B, 3)}', f'gcd = {pn(A & B)}', 'product (a limit)'),
             ('a ∨ b, OR, join', f'{bits(A | B, 3)}', f'lcm = {pn(A | B)}', 'coproduct (colimit)'),
             ('a ⊕ b, XOR', f'{bits(A ^ B, 3)}', f'ab/gcd² = {pn(A ^ B)}', 'no universal map'),
             ('a, b', f'{bits(A, 3)}, {bits(B, 3)}', f'{pn(A)}, {pn(B)}', '')]
    for i, row in enumerate(rowsT):
        y = y0 + 48 + i * 22
        if i % 2 == 0:
            F.r(8, y - 15, 426, 22, 'tn', rx=3)
        for j, s in enumerate(row):
            F.t(xs[j], y, s, anchor='start', size=12.5, cls=None if j else 't2')
    A2 = BR((1, 1, 1))
    s = A2.s(A, B)
    y = y0 + 146
    F.t(14, y, f'In a cell the product is eₐ e_b = s(a,b) e_(a ⊕ b): {en(A)} {en(B)} = ε₂ {en(A ^ B)},', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 20, f'the shared switch (the gcd {pn(A & B)}) is squared; in Cl(3,0) the sign is {sg(s)}1.', anchor='start', size=12.5, cls='t2')
    F.t(14, y + 40, 'Checked here on all 64 pairs of B₃ and 256 of B₄ (primes 2, 3, 5, 7).', anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig08: the graded tensor product as concatenation
def fig08():
    F = Fig('fig08_graded_tensor', 440, 330, 'The graded tensor product Cl(1,1) ⊗̂ Cl(1,0) computed two ways: it is the cell Cl(2,1) of the concatenated list')
    eA, eB = (1, -1), (1,)
    A, B, C = BR(eA), BR(eB), BR(eA + eB)
    agreeing, koz = 0, 0
    x0, y0, c = 52, 44, 24
    F.t(14, 20, '(+,−) followed by (+): the cell (+,−,+) = Cl(2,1)', anchor='start', bold=True)
    for k in range(8):
        F.t(x0 + k * c + c / 2, y0 - 6, en(k), size=11.5, cls='t2')
        F.t(x0 - 6, y0 + k * c + 17, en(k), size=11.5, cls='t2', anchor='end')
    for c1 in range(8):
        for c2 in range(8):
            a1, b1, a2, b2 = c1 & 3, c1 >> 2, c2 & 3, c2 >> 2
            kf = -1 if popcount(b1) * popcount(a2) % 2 else 1
            tens = kf * A.s(a1, a2) * B.s(b1, b2)
            assert (c1 ^ c2) == ((a1 ^ a2) | (b1 ^ b2) << 2)
            agreeing += tens == C.s(c1, c2)
            sign_cell(F, x0 + c2 * c, y0 + c1 * c, c, c, C.s(c1, c2))
            if kf < 0:
                koz += 1
                F.c(x0 + c2 * c + c - 6, y0 + c1 * c + 6, 2.6, 'acf')
    def clock(eps):
        re_, im_ = 0, 0
        for a in range(1 << len(eps)):
            if any(a >> i & 1 and eps[i] == 0 for i in range(len(eps))):
                continue
            k = sum(eps[i] for i in range(len(eps)) if a >> i & 1) % 4
            re_, im_ = re_ + [1, 0, -1, 0][k], im_ + [0, 1, 0, -1][k]
        return round(math.atan2(im_, re_) / (math.pi / 4)) % 8
    tx = x0 + 8 * c + 12
    lines = ['Sign of e(c₁) e(c₂) in Cl(2,1);', 'c = a | b, a a label of', 'Cl(1,1) (e₁, e₂), b of Cl(1,0)', '(e₃).', '',
             'The rule (a₁⊗b₁)(a₂⊗b₂) =', '(−1)^(|b₁||a₂|) a₁a₂ ⊗ b₁b₂', f'gives the same sign on {agreeing}', f'of 64 pairs. Dots: the {koz}',
             'pairs whose Koszul factor', 'is −1.', '', f'Clocks: {clock(eA)} + {clock(eB)} = {clock(eA + eB)} (mod 8).']
    for k, s in enumerate(lines):
        F.t(tx, y0 + 6 + k * 18, s, anchor='start', size=12.5, cls='t2')
    assert agreeing == 64 and koz == 16 and (clock(eA) + clock(eB)) % 8 == clock(eA + eB)
    agree(LOG + 'reruns/cat_check.log', 'concatenating two lists of generators gives exactly the graded tensor product with the Koszul sign')
    F.save()


# ================================================================================================ fig09: the clock as a homomorphism to Z8
def ctype(p, q):
    """type of Cl(p,q) from the squares of its labels (the sign of their sum) and the number of simple factors"""
    if p + q == 0:
        return 'ℝ'
    A = BR((1,) * p + (-1,) * q)
    s2 = sum(A.s(a, a) for a in range(A.M))
    t = 'ℝ' if s2 > 0 else 'ℂ' if s2 == 0 else 'ℍ'
    two = (p + q) % 2 == 1 and A.s(A.M - 1, A.M - 1) == 1
    return t + ('²' if two else '')


def gauss_clock(p, q, r=0):
    eps = (1,) * p + (-1,) * q + (0,) * r
    re_, im_ = 0, 0
    for a in range(1 << len(eps)):
        if any(a >> i & 1 and eps[i] == 0 for i in range(len(eps))):
            continue
        k = sum(eps[i] for i in range(len(eps)) if a >> i & 1) % 4
        re_, im_ = re_ + [1, 0, -1, 0][k], im_ + [0, 1, 0, -1][k]
    return re_, im_, round(math.atan2(im_, re_) / (math.pi / 4)) % 8


def fig09():
    F = Fig('fig09_clock_monoid', 440, 470, 'The clock p − q mod 8 read from the Gauss sum of the labels, with the type of each cell and of its even part')
    F.t(14, 20, 'The clock: S = Σₐ i^(|a∩P| − |a∩Q|) = (1+i)^p (1−i)^q', anchor='start', bold=True)
    by = {k: [] for k in range(8)}
    for n in range(0, 5):
        for p in range(n, -1, -1):
            q = n - p
            re_, im_, c = gauss_clock(p, q)
            assert (re_ + 1j * im_) == (1 + 1j) ** p * (1 - 1j) ** q and c == (p - q) % 8
            by[c].append(f'({p},{q})')
    pairs = {}
    for p in range(0, 9):
        for q in range(0, 9):
            if 1 <= p + q <= 8:
                c = (p - q) % 8
                ev = ctype(p, q - 1) if q >= 1 else ctype(q, p - 1)
                pairs.setdefault(c, set()).add(ctype(p, q) + ' / ' + ev)
    assert all(len(v) == 1 for v in pairs.values())
    ascii_ = {'ℝ': 'R', 'ℂ': 'C', 'ℍ': 'H', '²': '2'}
    log = '; '.join(f'c={c}: ' + ''.join(ascii_.get(ch, ch) for ch in next(iter(pairs[c]))).replace(' / ', '/') for c in range(8))
    agree(LOG + 'reruns/cat_check.log', log)
    cx, cy, R = 126, 186, 92
    F.c(cx, cy, R, 'ln', sw=1.2)
    for k in range(8):
        ang = math.pi / 2 - k * math.pi / 4
        x, y = cx + R * math.cos(ang), cy - R * math.sin(ang)
        F.c(x, y, 13, 'bx', sw=1.2)
        F.t(x, y + 4.7, str(k), size=13, bold=True)
        F.t(cx + (R - 36) * math.cos(ang), cy - (R - 36) * math.sin(ang) + 4, next(iter(pairs[k])), size=11.5, cls='t2')
    F.p(f'M{fm(cx + 24)},{fm(cy - R - 20)} A{R + 20},{R + 20} 0 0 1 {fm(cx + R + 18)},{fm(cy - 26)}', cls='ac', sw=1.6, arrow=True)
    F.t(cx, cy + 4, 'type / even', size=11.5, cls='mu')
    tx = 262
    F.t(tx, 54, 'c   cells (p,q), p + q ≤ 4', anchor='start', size=12.5, cls='mu')
    for k in range(8):
        y = 78 + k * 21
        if k % 2 == 0:
            F.r(tx - 6, y - 15, 180, 21, 'tn', rx=3)
        F.t(tx, y, str(k), anchor='start', size=12.5, bold=True)
        F.t(tx + 20, y, ' '.join(by[k]) if by[k] else '–', anchor='start', size=12.5)
    lines = ['Concatenation adds clocks:', 'Cl(1,0) ⊗̂ Cl(1,0) = Cl(2,0): 1 + 1 = 2;', 'Cl(1,0) ⊗̂ Cl(0,1) = Cl(1,1): 1 + 7 ≡ 0;',
             'eight plus generators come back to 0.', 'A null generator adds 0 (the Gauss sum', 'of Cl(p,q,r) is 2^r times that of Cl(p,q)).']
    for k, s in enumerate(lines):
        F.t(14, 336 + k * 20, s, anchor='start', size=12.5, cls='t2')
    F.t(14, 310, 'The hand moves +1 for each e² = +1 and −1 for each e² = −1.', anchor='start', size=12.5, cls='t2')
    for p, q, r in [(1, 0, 1), (2, 1, 2), (0, 3, 1)]:
        re0, im0, c0 = gauss_clock(p, q)
        eps = (1,) * p + (-1,) * q + (0,) * r
        re_, im_ = 0, 0
        for a in range(1 << len(eps)):
            k = sum(eps[i] for i in range(len(eps)) if a >> i & 1) % 4
            re_, im_ = re_ + [1, 0, -1, 0][k], im_ + [0, 1, 0, -1][k]
        assert (re_, im_) == (re0 * 2 ** r, im0 * 2 ** r)
    F.t(14, 460, 'Types from the squares: the sign of Σₐ eₐ² gives ℝ, ℂ, ℍ (cat·K4c).', anchor='start', size=12, cls='mu')
    F.save()


# ================================================================================================ fig10: the Frobenius pairing and the Nakayama sign
def pairing(eps):
    A = BR(eps)
    N = A.M
    return A, [[lam(A, A.mul({a: 1}, {b: 1})) for b in range(N)] for a in range(N)]


def fig10():
    F = Fig('fig10_frobenius', 440, 476, 'The top-label pairing of Cl(3,0) and of Cl(3,0,1), and the Nakayama sign of each label')
    F.t(14, 20, 'λ(eₐ e_b) = the coefficient of the full label in eₐ e_b', anchor='start', bold=True)
    specs = [((1, 1, 1), 'Cl(3,0), n = 3', 22, 30, 15), ((1, 1, 1, 0), 'Cl(3,0,1), n = 4', 194, 30, 14)]
    for (eps, name, x0, y0, c) in specs:
        A, M = pairing(eps)
        n, N = len(eps), A.M
        F.t(x0 + N * c / 2, y0 + 22, name, bold=True, size=12.5)
        top = y0 + 34
        for a in range(N):
            for b in range(N):
                v = M[a][b]
                assert (v != 0) == (b == a ^ (N - 1)) and abs(v) <= 1
                F.r(x0 + b * c + 0.5, top + a * c + 0.5, c - 1, c - 1, 'pos' if v > 0 else 'neg' if v < 0 else 'nul', rx=2)
        F.t(x0 - 4, top + 10, 'a', size=11.5, cls='mu', anchor='end')
        F.t(x0 + 4, top - 4, 'b →', size=11.5, cls='mu', anchor='start')
        assert mat_rank(M) == N
        ys = top + N * c + 14
        F.t(x0, ys + 4, 'Nakayama sign of b:', anchor='start', size=11.5, cls='mu')
        for b in range(N):
            nk = -1 if popcount(b) * (n - popcount(b)) % 2 else 1
            for a in range(N):
                assert M[a][b] == nk * M[b][a]
                assert M[a][b] == (-1) ** (popcount(a) * popcount(b)) * M[b][a]
            F.r(x0 + b * c + 0.5, ys + 12, c - 1, c - 1, 'pos' if nk > 0 else 'neg', rx=2)
        sym = all(M[a][b] == M[b][a] for a in range(N) for b in range(N))
        lines = (['all + : λ is symmetric', '(n odd: Nakayama = id)'] if sym else
                 ['(−1)^|b|: Nakayama = α,', 'the grade involution'])
        for k, s in enumerate(lines):
            F.t(x0, ys + 12 + c + 18 + k * 17, s, anchor='start', size=12, cls='t2')
    yb = 404
    for k, s in enumerate(['Each row has one entry ±1, at b = a ⊕ 1…1: the pairing is',
                           'non-degenerate for every signature, the null generator of',
                           'Cl(3,0,1) included. With the Koszul sign, λ(eₐ e_b) =',
                           '(−1)^(|a||b|) λ(e_b eₐ) on all pairs: super-symmetric in sVec.']):
        F.t(14, yb + k * 19, s, anchor='start', size=12.5, cls='t2')
    agree(LOG + 'reruns/check_T3.log', 'top-label pairing non-zero exactly on complementary pairs, values +-1: non-degenerate for all 119 signatures n <= 6')
    F.save()


# ================================================================================================ fig11: the pair of pants
def handle(eps):
    A = BR(eps)
    N, F_ = A.M, A.M - 1
    H = {}
    for a in range(N):
        v = lam(A, A.mul({a: 1}, {a ^ F_: 1}))
        dual = {a ^ F_: Fraction(1, v)}
        H = A.add(H, A.mul({a: 1}, dual))
    return A, H


def fig11():
    F = Fig('fig11_pair_of_pants', 440, 400, 'Unit, trace, multiplication, comultiplication and the handle of a Frobenius algebra, with the handle element of four cells')
    F.t(14, 20, 'The pictures of a Frobenius algebra (Atiyah’s axioms, recalled)', anchor='start', bold=True)

    def ell(x, y, rx=13, ry=4.5):
        F.el.append(f'<ellipse cx="{fm(x)}" cy="{fm(y)}" rx="{fm(rx)}" ry="{fm(ry)}" class="ink" stroke-width="1.2"/>')
    y1, y2 = 52, 128
    # unit: a cup closing a circle at the top (disc with boundary at the bottom)
    x = 46
    ell(x, y2)
    F.p(f'M{fm(x - 13)},{fm(y2)} C{fm(x - 13)},{fm(y1 + 18)} {fm(x + 13)},{fm(y1 + 18)} {fm(x + 13)},{fm(y2)}', cls='ink', sw=1.2)
    # trace: a cap below a circle
    x = 128
    ell(x, y1)
    F.p(f'M{fm(x - 13)},{fm(y1)} C{fm(x - 13)},{fm(y2 - 18)} {fm(x + 13)},{fm(y2 - 18)} {fm(x + 13)},{fm(y1)}', cls='ink', sw=1.2)
    # multiplication: two circles in, one out
    x = 220
    ell(x - 20, y1)
    ell(x + 20, y1)
    ell(x, y2)
    F.p(f'M{fm(x - 33)},{fm(y1)} C{fm(x - 33)},{fm(y1 + 38)} {fm(x - 13)},{fm(y2 - 34)} {fm(x - 13)},{fm(y2)}', cls='ink', sw=1.2)
    F.p(f'M{fm(x + 33)},{fm(y1)} C{fm(x + 33)},{fm(y1 + 38)} {fm(x + 13)},{fm(y2 - 34)} {fm(x + 13)},{fm(y2)}', cls='ink', sw=1.2)
    F.p(f'M{fm(x - 7)},{fm(y1)} C{fm(x - 7)},{fm(y1 + 30)} {fm(x + 7)},{fm(y1 + 30)} {fm(x + 7)},{fm(y1)}', cls='ink', sw=1.2)
    # comultiplication: one in, two out
    x = 312
    ell(x, y1)
    ell(x - 20, y2)
    ell(x + 20, y2)
    F.p(f'M{fm(x - 13)},{fm(y1)} C{fm(x - 13)},{fm(y1 + 34)} {fm(x - 33)},{fm(y2 - 38)} {fm(x - 33)},{fm(y2)}', cls='ink', sw=1.2)
    F.p(f'M{fm(x + 13)},{fm(y1)} C{fm(x + 13)},{fm(y1 + 34)} {fm(x + 33)},{fm(y2 - 38)} {fm(x + 33)},{fm(y2)}', cls='ink', sw=1.2)
    F.p(f'M{fm(x - 7)},{fm(y2)} C{fm(x - 7)},{fm(y2 - 30)} {fm(x + 7)},{fm(y2 - 30)} {fm(x + 7)},{fm(y2)}', cls='ink', sw=1.2)
    # handle: m after Delta, a torus with two boundary circles
    x = 400
    ell(x, y1, 11, 4)
    ell(x, y2, 11, 4)
    F.p(f'M{fm(x - 11)},{fm(y1)} C{fm(x - 11)},{fm(y1 + 14)} {fm(x - 26)},{fm(y1 + 18)} {fm(x - 26)},{fm((y1 + y2) / 2)} '
        f'C{fm(x - 26)},{fm(y2 - 18)} {fm(x - 11)},{fm(y2 - 14)} {fm(x - 11)},{fm(y2)}', cls='ink', sw=1.2)
    F.p(f'M{fm(x + 11)},{fm(y1)} C{fm(x + 11)},{fm(y1 + 14)} {fm(x + 26)},{fm(y1 + 18)} {fm(x + 26)},{fm((y1 + y2) / 2)} '
        f'C{fm(x + 26)},{fm(y2 - 18)} {fm(x + 11)},{fm(y2 - 14)} {fm(x + 11)},{fm(y2)}', cls='ink', sw=1.2)
    F.c(x, (y1 + y2) / 2, 6, 'ink', sw=1.2)
    labs = [(46, 'η: 1'), (128, 'ε = λ'), (220, 'm'), (312, 'Δ'), (400, 'm∘Δ')]
    for (x, s) in labs:
        F.t(x, y2 + 26, s, size=13, bold=True)
    subs = [(46, 'the unit'), (128, 'top coefficient'), (220, 'the product'), (312, 'dual of m'), (400, '× H')]
    for (x, s) in subs:
        F.t(x, y2 + 44, s, size=11.5, cls='mu')
    # the handle element of four cells, computed
    y0 = 214
    F.t(14, y0, 'The handle element H = Σₐ eₐ eᵃ (eᵃ the dual basis for λ), computed', anchor='start', bold=True)
    cols = [('cell', 14), ('H', 132), ('H²', 214), ('λ(1)', 290), ('λ(H)', 360)]
    for (s, x) in cols:
        F.t(x, y0 + 24, s, anchor='start', size=12.5, cls='mu')
    cells = [((1, 1), 'Cl(2,0)'), ((1, -1), 'Cl(1,1)'), ((1, 0), 'Cl(1,0,1)'), ((0, 0), 'Cl(0,0,2) = Λ(ℝ²)'), ((1, 1, 1), 'Cl(3,0)')]

    def show(x):
        if not x:
            return '0'
        return ' + '.join((str(v) if a == 0 else (('' if v == 1 else MINUS if v == -1 else str(v)) + en(a))) for a, v in sorted(x.items()))
    for i, (eps, name) in enumerate(cells):
        A, H = handle(eps)
        y = y0 + 46 + i * 22
        if i % 2 == 0:
            F.r(8, y - 15, 426, 22, 'tn', rx=3)
        H2 = A.mul(H, H)
        assert H == {A.M - 1: A.M} and ((not H2) == (0 in eps))
        F.t(14, y, name, anchor='start', size=12.5)
        F.t(132, y, show(H), anchor='start', size=12.5)
        F.t(214, y, show(H2).replace('-', MINUS), anchor='start', size=12.5)
        F.t(290, y, str(lam(A, {0: 1})), anchor='start', size=12.5)
        F.t(360, y, str(lam(A, H)), anchor='start', size=12.5)
    F.t(14, y0 + 172, 'H = 2ⁿ e_(1…1) in every cell; H² = 0 exactly when a generator is null.', anchor='start', size=12.5, cls='t2')
    agree(LOG + 'reruns/cat_frobenius.log', 'is exactly 2^n e_(1...1); it squares to 0 iff r >= 1')
    F.save()


# ================================================================================================ fig12: the super-dimension
def fig12():
    F = Fig('fig12_superdimension', 440, 300, 'The labels of the exterior algebra counted by grade: dimension 2^n, super-dimension 0')
    F.t(14, 20, 'Labels of Λ(ℝⁿ) by grade k: dim = Σ, sdim = Σ (−1)^k', anchor='start', bold=True)
    x0, y0, cw, ch = 46, 50, 30, 23
    for k in range(9):
        F.t(x0 + k * cw + cw / 2, y0 - 6, str(k), size=12, cls='mu')
    F.t(x0 - 8, y0 - 6, 'n \\ k', size=11, cls='mu', anchor='end')
    F.t(x0 + 9 * cw + 26, y0 - 6, 'dim', size=12, cls='mu')
    F.t(x0 + 9 * cw + 76, y0 - 6, 'sdim', size=12, cls='mu')
    for n in range(1, 9):
        y = y0 + (n - 1) * ch
        A = BR((0,) * n)
        by = [0] * (n + 1)
        for a in range(A.M):
            by[popcount(a)] += 1
        sdim = sum((-1) ** popcount(a) for a in range(A.M))
        assert sdim == 0 and sum(by) == 2 ** n
        F.t(x0 - 8, y + 16, str(n), size=12, cls='mu', anchor='end')
        for k in range(n + 1):
            F.r(x0 + k * cw + 1, y + 1, cw - 2, ch - 2, 'ev' if k % 2 == 0 else 'od', rx=3)
            F.t(x0 + k * cw + cw / 2, y + 16, str(by[k]), size=11.5)
        F.t(x0 + 9 * cw + 26, y + 16, str(sum(by)), size=12.5)
        F.t(x0 + 9 * cw + 76, y + 16, str(sdim), size=12.5, bold=True)
    for k, s in enumerate(['Green: even labels (bosonic), amber: odd (fermionic). Each mode pairs',
                           '|0⟩ with |1⟩, so the even and the odd labels are equal in number.']):
        F.t(14, 258 + k * 19, s, anchor='start', size=12.5, cls='t2')
    agree(LOG + 'fock_encodings.log', 'is 0 for n = 1..8 (each mode pairs |0> with |1>')
    F.save()


# ================================================================================================ fig13: the Koszul complex
def koszul(n):
    """d e_a = sum_{i in a} sigma(a - i, i) e_(a - i), sigma(b, i) = (-1)^{#{j in b : j < i}} (T6 (b)); returned as a dict of columns"""
    N = 1 << n
    D = {}
    for a in range(N):
        col = {}
        for i in range(n):
            if a >> i & 1:
                b = a & ~(1 << i)
                col[b] = col.get(b, 0) + (-1) ** popcount(b & ((1 << i) - 1))
        D[a] = col
    return D


def fig13():
    F = Fig('fig13_koszul_ranks', 440, 324, 'The Koszul complex on the labels of four generators: dimensions, ranks and exactness')
    F.t(14, 20, 'd eₐ = Σ_(i∈a) (−1)^#(j∈a, j<i) e_(a−i): degree k → k − 1', anchor='start', bold=True)
    totals = {}
    for n in range(1, 7):
        D = koszul(n)
        N = 1 << n
        # d^2 = 0, and d h + h d = id with h = wedge by the first generator (left multiplication by e_1 in the null cell)
        A = BR((0,) * n)
        for a in range(N):
            dd = {}
            for b, v in D[a].items():
                for c2, w in D[b].items():
                    dd[c2] = dd.get(c2, 0) + v * w
            assert all(v == 0 for v in dd.values())
            hd = {}
            for b, v in D[a].items():
                for c2, w in A.mul({1: 1}, {b: 1}).items():
                    hd[c2] = hd.get(c2, 0) + v * w
            for b, w in A.mul({1: 1}, {a: 1}).items():
                for c2, v in D[b].items():
                    hd[c2] = hd.get(c2, 0) + v * w
            assert {k: v for k, v in hd.items() if v} == {a: 1}
        rk = {}
        for k in range(1, n + 1):
            rows = [D[a] for a in range(N) if popcount(a) == k]
            rk[k] = rank_fr(rows, N)
            assert rk[k] == math.comb(n - 1, k - 1)
        totals[n] = sum(rk.values())
        assert totals[n] == 2 ** (n - 1)
    agree(LOG + 'reruns/check_T6.log', 'd^2 = 0 and dh + hd = id (h = wedge by e_0) on all labels for n <= 7; rank d = 2^{n-1} (exact) for n <= 6')
    n = 4
    xs = [36 + j * 92 for j in range(5)]
    y = 92
    for j, k in enumerate(range(4, -1, -1)):
        x = xs[j]
        dim = math.comb(n, k)
        F.r(x - 27, y - 36, 54, 72, 'bx', rx=8)
        F.t(x, y - 42, f'Λ{["⁰", "¹", "²", "³", "⁴"][k]}', size=13, bold=True)
        F.t(x, y + 6, str(dim), size=20, bold=True)
        F.t(x, y + 26, f'C(4,{k})', size=11.5, cls='mu')
        if j < 4:
            F.arrow(x + 27, y, xs[j + 1] - 27, y, d1=2, d2=2, cls='ink', sw=1.4)
            F.t((x + xs[j + 1]) / 2, y - 8, 'd', size=12.5, italic=True)
            F.t((x + xs[j + 1]) / 2, y + 20, str(math.comb(n - 1, k - 1)), size=12.5, bold=True)
    for k, s in enumerate(['Under the arrows: the rank of d. At each place the image of',
                           'the arrow in is the kernel of the arrow out: 1 = 1, 4 = 1 + 3,',
                           '6 = 3 + 3, 4 = 3 + 1, 1 = 1. The complex is exact; its total',
                           'rank is 2ⁿ⁻¹, its rank in degree k is C(n−1, k−1).']):
        F.t(14, 170 + k * 19, s, anchor='start', size=12.5, cls='t2')
    y0 = 262
    F.t(14, y0, 'n', anchor='start', size=12.5, cls='mu')
    F.t(14, y0 + 22, 'rank of d', anchor='start', size=12.5, cls='mu')
    F.t(14, y0 + 44, 'dim Λ = 2ⁿ', anchor='start', size=12.5, cls='mu')
    for n in range(1, 7):
        x = 130 + (n - 1) * 50
        F.t(x, y0, str(n), size=12.5, cls='mu')
        F.t(x, y0 + 22, str(totals[n]), size=12.5, bold=True)
        F.t(x, y0 + 44, str(2 ** n), size=12.5)
    F.save()


# ================================================================================================ fig14: the incidence algebra of B2
def fig14():
    F = Fig('fig14_incidence_b2', 440, 420, 'The incidence algebra of B2: its quiver, its nine matrix units, its Cartan matrix and its Euler form')
    n, N = 2, 4
    A = BR((0,) * n)
    cre = []
    for i in range(n):
        M = [[0] * N for _ in range(N)]
        for b in range(N):
            for c2, v in A.mul({1 << i: 1}, {b: 1}).items():
                M[c2][b] += v
        cre.append(M)
    proj = [[[1 if (r == S and c2 == S) else 0 for c2 in range(N)] for r in range(N)] for S in range(N)]

    def mm(X, Y):
        return [[sum(X[i][k] * Y[k][j] for k in range(N)) for j in range(N)] for i in range(N)]
    gens = cre + proj
    span = [g for g in gens]
    frontier = list(span)
    while frontier:
        new = []
        for X in frontier:
            for G in gens:
                for Y in (mm(X, G), mm(G, X)):
                    cand = span + [Y]
                    if mat_rank([sum(Z, []) for Z in cand]) > mat_rank([sum(Z, []) for Z in span]):
                        span.append(Y)
                        new.append(Y)
        frontier = new
    dim = mat_rank([sum(Z, []) for Z in span])
    support = {(r, c2) for Z in span for r in range(N) for c2 in range(N) if Z[r][c2]}
    assert dim == 9 and support == {(T, S) for T in range(N) for S in range(N) if S & T == S}
    rad = [(T, S) for (T, S) in support if S != T]
    J2 = {(T, U) for (T, S) in rad for (S2, U) in rad if S == S2}
    J3 = {(T, V) for (T, U) in J2 for (U2, V) in rad if U == U2}
    agree('checks/selfcheck/proofs/logs/reruns/mja_incidence.log', f'n=2: dim {dim}, radical {len(rad)}, J^k [{len(rad)}, {len(J2)}, {len(J3)}]')
    F.t(14, 20, 'The quiver: the Hasse diagram of B₂, one relation', anchor='start', bold=True)
    P = {0: (90, 170), 1: (40, 112), 2: (140, 112), 3: (90, 54)}
    for (a, b) in covers(2):
        F.arrow(*P[a], *P[b], d1=14, d2=15, cls='ink', sw=1.3)
    for a in range(4):
        F.node(*P[a], en(a), w=40)
    F.t(90, 116, '⟲', size=13, cls='mu')
    F.t(90, 204, 'the square commutes', size=12, cls='t2')
    x0, y0, c = 268, 66, 34
    F.t(x0 + 2 * c, 44, 'matrix units |T⟩⟨S|, S ⊆ T', size=12.5, bold=True)
    for S in range(N):
        F.t(x0 + S * c + c / 2, y0 - 4, en(S), size=12, cls='t2')
    for T in range(N):
        F.t(x0 - 6, y0 + T * c + c / 2 + 4, en(T), size=12, cls='t2', anchor='end')
        for S in range(N):
            on = (T, S) in support
            F.r(x0 + S * c + 1, y0 + T * c + 1, c - 2, c - 2, ('pos' if S == T else 'od') if on else 'nul', rx=4)
    F.t(x0 + 2 * c, y0 + 4 * c + 18, 'blue: the 4 idempotents; amber: the', size=11.5, cls='t2')
    F.t(x0 + 2 * c, y0 + 4 * c + 34, f'radical, {len(rad)} arrows; J² has {len(J2)}, J³ = 0', size=11.5, cls='t2')
    Cm = [[1 if S & T == S else 0 for T in range(N)] for S in range(N)]
    assert all(sum(Cm[i][k] * [[(-1) ** popcount(T & ~S) if S & T == S else 0 for T in range(N)] for S in range(N)][k][j] for k in range(N)) == (i == j) for i in range(N) for j in range(N))
    Mo = [[(-1) ** popcount(T & ~S) if S & T == S else 0 for T in range(N)] for S in range(N)]
    for (Mx, name, xm) in [(Cm, 'Cartan matrix [[1,1],[0,1]]^⊗2', 22), (Mo, 'Euler form = Möbius μ(S,T)', 238)]:
        F.t(xm, 262, name, anchor='start', size=12.5, bold=True)
        for i in range(N):
            for j in range(N):
                v = Mx[i][j]
                F.t(xm + 40 + j * 30, 290 + i * 22, (MINUS + '1') if v < 0 else str(v), size=13, anchor='end')
        F.p(f'M{xm + 6},{272} l-4,0 l0,{4 * 22 + 4} l4,0', cls='ink', sw=1)
        F.p(f'M{xm + 132},{272} l4,0 l0,{4 * 22 + 4} l-4,0', cls='ink', sw=1)
    Sym = [[Mo[i][j] + Mo[j][i] for j in range(N)] for i in range(N)]
    pos_, neg_, zer_ = inertia(Sym)
    F.t(14, 400, f'μ = C⁻¹. Symmetrised, the Euler form has signature ({pos_},{neg_},{zer_}).', anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig15: representation type of k B_n
def euler_tits(n):
    N = 1 << n
    E = [[(-1) ** popcount(T & ~S) if S & T == S else 0 for T in range(N)] for S in range(N)]
    Q = [[(-1) ** popcount(T & ~S) if (S & T == S and popcount(T & ~S) <= 2) else 0 for T in range(N)] for S in range(N)]
    sym = lambda M: [[M[i][j] + M[j][i] for j in range(N)] for i in range(N)]
    return inertia(sym(E)), inertia(sym(Q))


def fig15():
    F = Fig('fig15_rep_type', 440, 330, 'The symmetrised Euler form and the Tits form of the cube categories B0 to B5')
    F.t(14, 20, 'The cube category k Bₙ: Euler form and Tits form', anchor='start', bold=True)
    eu, ti = {}, {}
    for n in range(0, 6):
        eu[n], ti[n] = euler_tits(n)
    agree(LOG + 'reruns/check_T8.log', 'symmetrised signatures ' + ', '.join(f'n={n}: {eu[n]}' for n in range(6)))
    for n in (3, 4, 5):
        agree(LOG + 'reruns/check_T8.log', f'n={n}: Tits signature {ti[n]}')
    hdr = [('n', 14), ('Euler form (+,−,0)', 34), ('Tits form', 178), ('type', 330)]
    for (s, x) in hdr:
        F.t(x, 48, s, anchor='start', size=12.5, cls='mu')
    kinds = ['finite', 'finite', 'finite', 'tame (recalled)', 'wild (recalled)', 'wild (recalled)']
    for n in range(6):
        y = 74 + n * 30
        F.t(14, y + 4, str(n), anchor='start', size=13, bold=True)
        for (sig, x) in [(eu[n], 34), (ti[n], 178)]:
            tot = sum(sig)
            w = 70
            xx = x
            for part, cls in zip(sig, ('pos', 'neg', 'nul')):
                if part:
                    ww = w * part / tot
                    F.r(xx, y - 9, ww - (1 if ww > 2 else 0), 16, cls, rx=2)
                    xx += ww
            F.t(x + w + 6, y + 4, '(' + ','.join(map(str, sig)) + ')', anchor='start', size=12.5)
        F.t(330, y + 4, kinds[n], anchor='start', size=12.5, cls='t2')
    for k, s in enumerate(['Bars: shares of positive (blue), negative (red), null (grey).',
                           'Finite for n ≤ 2. From n = 3 the labels of grade 1 and 2 form',
                           'a hexagon (a crown), so the type is not finite; tame at n = 3',
                           'and wild from n = 4 are recalled (Wang; Ladkani; de la Peña).']):
        F.t(14, 264 + k * 18, s, anchor='start', size=12.5, cls='t2')
    F.save()
    return eu, ti


# ================================================================================================ fig16: the signed cube
def fig16():
    F = Fig('fig16_cube_signs', 440, 330, 'The Jordan-Wigner signs on the edges of the 3-cube of labels: every square anticommutes')
    F.t(14, 20, 'σ(a → a + eᵢ) = (−1)^#(j ∈ a, j < i) on the 12 edges', anchor='start', bold=True)
    def pos(a):
        x = 60 + (a & 1) * 110 + (a >> 2 & 1) * 52
        y = 252 - (a >> 1 & 1) * 110 - (a >> 2 & 1) * 52
        return x, y
    edges = covers(3)
    sig = {(a, b): (-1) ** popcount(a & ((b ^ a) - 1)) for (a, b) in edges}
    for (a, b), s in sig.items():
        F.l(*pos(a), *pos(b), cls='ink', sw=1.6 if s > 0 else 1.6, dash=None if s > 0 else '6 4')
    for a in range(8):
        F.node(*pos(a), en(a), w=44)
    faces = []
    for i in range(3):
        for j in range(i + 1, 3):
            for base in range(8):
                if not base >> i & 1 and not base >> j & 1:
                    a, b, c2, d = base, base | 1 << i, base | 1 << j, base | 1 << i | 1 << j
                    faces.append(((a, b, c2, d), sig[(a, b)] * sig[(b, d)] * sig[(a, c2)] * sig[(c2, d)]))
    assert len(faces) == 6 and all(f == -1 for _, f in faces)
    good = []
    for m in range(1 << 12):
        s = {e: (-1 if m >> k & 1 else 1) for k, e in enumerate(edges)}
        if all(s[(a, b)] * s[(b, d)] * s[(a, c2)] * s[(c2, d)] == -1 for (a, b, c2, d), _ in faces):
            good.append(s)
    gauge = set()
    for g in range(1 << 8):
        gauge.add(tuple(sig[e] * (-1 if g >> e[0] & 1 else 1) * (-1 if g >> e[1] & 1 else 1) for e in edges))
    assert len(good) == 128 and {tuple(s[e] for e in edges) for s in good} == gauge
    agree(LOG + 'reruns/check_T6.log', '3-cube brute force: 128 = 2^7 anticommuting assignments = one gauge orbit')
    tx = 262
    lines = ['Dashed edges: sign −1.', '', 'Each of the 6 squares has', 'an odd number of dashed', 'edges: it anticommutes.', '',
             'Of the 2¹² = 4096 ways to', f'sign the edges, {len(good)} make', 'every square anticommute:', 'exactly the 2⁸/2 = 128',
             'regaugings eₐ ↦ ±eₐ of', 'this one.']
    for k, s in enumerate(lines):
        F.t(tx, 62 + k * 18, s, anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig17: H^2 in three complexes
def h2_group(n):
    N = 1 << n
    var = lambda a, b: (a - 1) * (N - 1) + (b - 1)
    rows = []
    for a in range(1, N):
        for b in range(1, N):
            for c2 in range(1, N):
                v = (1 << var(b, c2)) ^ (1 << var(a, b))
                if a ^ b:
                    v ^= 1 << var(a ^ b, c2)
                if b ^ c2:
                    v ^= 1 << var(a, b ^ c2)
                rows.append(v)
    z = (N - 1) ** 2 - rank_f2(rows)
    brow = []
    for a in range(1, N):
        for b in range(1, N):
            v = (1 << (a - 1)) ^ (1 << (b - 1))
            if a ^ b:
                v ^= 1 << ((a ^ b) - 1)
            brow.append(v)
    return z - rank_f2(brow)


def h2_partial(n):
    N = 1 << n
    pairs = [(a, b) for a in range(1, N) for b in range(1, N) if a & b == 0]
    ix = {p: k for k, p in enumerate(pairs)}
    rows = []
    for a in range(1, N):
        for b in range(1, N):
            for c2 in range(1, N):
                if a & b or a & c2 or b & c2:
                    continue
                rows.append((1 << ix[(b, c2)]) ^ (1 << ix[(a ^ b, c2)]) ^ (1 << ix[(a, b ^ c2)]) ^ (1 << ix[(a, b)]))
    z = len(pairs) - rank_f2(rows)
    brow = [(1 << (a - 1)) ^ (1 << (b - 1)) ^ (1 << ((a ^ b) - 1)) for (a, b) in pairs]
    return z - rank_f2(brow)


def h_nerve(n):
    N = 1 << n
    lt = lambda a, b: a != b and a & b == a
    simp = {0: [(a,) for a in range(N)]}
    for k in range(1, 4):
        simp[k] = [s + (b,) for s in simp[k - 1] for b in range(N) if lt(s[-1], b)]
    ix = {k: {s: i for i, s in enumerate(simp[k])} for k in simp}

    def delta_rank(k):
        rows = []
        for s in simp[k + 1]:
            v = 0
            for i in range(k + 2):
                v ^= 1 << ix[k][s[:i] + s[i + 1:]]
            rows.append(v)
        return rank_f2(rows)
    r0, r1, r2 = delta_rank(0), delta_rank(1), delta_rank(2)
    return len(simp[1]) - r1 - r0, len(simp[2]) - r2 - r1


def fig17():
    F = Fig('fig17_h2_three', 440, 330, 'dim H2 with F2 coefficients for the label group, the partial monoid of disjoint labels and the cube category')
    F.t(14, 20, 'The sign as a class: dim H²( · ; 𝔽₂)', anchor='start', bold=True)
    G = {n: h2_group(n) for n in range(1, 5)}
    Pm = {n: h2_partial(n) for n in range(1, 6)}
    Nv = {n: h_nerve(n) for n in range(1, 5)}
    agree(LOG + 'reruns/mja_exterior.log', '; '.join(f'group n={n}: {G[n]}' for n in range(1, 5)) + '; '
          + '; '.join(f'partial monoid n={n}: {Pm[n]}' for n in range(1, 6)) + '; '
          + '; '.join(f'B_{n}: H1 {Nv[n][0]}, H2 {Nv[n][1]}' for n in range(1, 5)))
    assert all(G[n] == n * (n + 1) // 2 for n in G) and all(Pm[n] == math.comb(n, 2) for n in Pm)
    x0, yb, sc, gw = 60, 236, 17, 70
    for v in range(0, 11, 2):
        y = yb - v * sc
        F.l(x0 - 6, y, x0 + 5 * gw + 10, y, cls='ln', sw=0.8)
        F.t(x0 - 10, y + 4, str(v), anchor='end', size=11.5, cls='mu')
    series = [('s1', 'label group ℤ₂ⁿ', G), ('s2', 'partial monoid (⊕)', Pm), ('s3', 'category Bₙ', {n: Nv[n][1] for n in Nv})]
    bw = 16
    for n in range(1, 6):
        gx = x0 + (n - 1) * gw + 10
        F.t(gx + 1.5 * bw + 2, yb + 18, f'n = {n}', size=12, cls='mu')
        for j, (cls, _, D) in enumerate(series):
            if n not in D:
                continue
            v = D[n]
            h = v * sc
            x = gx + j * (bw + 2)
            if h > 0:
                F.p(f'M{fm(x)},{fm(yb)} L{fm(x)},{fm(yb - h + 3)} Q{fm(x)},{fm(yb - h)} {fm(x + 3)},{fm(yb - h)} L{fm(x + bw - 3)},{fm(yb - h)} '
                    f'Q{fm(x + bw)},{fm(yb - h)} {fm(x + bw)},{fm(yb - h + 3)} L{fm(x + bw)},{fm(yb)} Z', cls=cls)
            else:
                F.r(x, yb - 2, bw, 2, cls)
            F.t(x + bw / 2, yb - h - 5, str(v), size=11.5)
    for j, (cls, name, _) in enumerate(series):
        x = 14 + j * 144
        F.r(x, 272, 12, 12, cls, rx=2)
        F.t(x + 18, 282, name, anchor='start', size=12.5, cls='t2')
    F.t(14, 310, 'n(n+1)/2 on the group, C(n,2) on the partial monoid, 0 on the category.', anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig18: the index
def fig18():
    import numpy as np
    F = Fig('fig18_index', 440, 330, 'The Euler number of the truncated Koszul complexes, equal to the index Tr(−1)^F exp(−βH) for every β')
    F.t(14, 20, 'Tr (−1)^F e^(−βH) on Λ(ℝⁿ) cut at degree K', anchor='start', bold=True)
    table = {}
    worst = 0.0
    for n in range(1, 7):
        A = BR((0,) * n)
        N = A.M
        w = {1 << i: i + 1 for i in range(n)}
        Lw = [[0] * N for _ in range(N)]
        for b in range(N):
            for c2, v in A.mul(w, {b: 1}).items():
                Lw[c2][b] += v
        for K in range(0, n + 1):
            keep = [a for a in range(N) if popcount(a) <= K]
            Q = [[Lw[r][c2] if popcount(r) <= K else 0 for c2 in keep] for r in keep]
            deg = [popcount(a) for a in keep]
            dimH = {}
            for k in range(K + 1):
                cols_k = [j for j, a in enumerate(keep) if deg[j] == k]
                cols_km1 = [j for j, a in enumerate(keep) if deg[j] == k - 1]
                out_rank = mat_rank([[Q[i][j] for i in range(len(keep))] for j in cols_k]) if cols_k and k < K else 0
                in_rank = mat_rank([[Q[i][j] for i in range(len(keep))] for j in cols_km1]) if cols_km1 else 0
                dimH[k] = len(cols_k) - out_rank - in_rank
            chi = sum((-1) ** k * dimH[k] for k in dimH)
            assert chi == (-1) ** K * math.comb(n - 1, K)
            Qm = np.array(Q, dtype=float)
            H = Qm @ Qm.T + Qm.T @ Qm
            ev, U = np.linalg.eigh(H)
            par = np.diag([(-1.0) ** d for d in deg])
            for beta in (0.05, 0.5, 5.0):
                tr = float(np.trace(par @ U @ np.diag(np.exp(-beta * ev)) @ U.T))
                worst = max(worst, abs(tr - chi))
            table[(n, K)] = chi
    assert worst < 1e-9
    agree(LOG + 'fock_encodings.log', 'sum (-1)^k dim H^k = sum (-1)^k dim C^k = (-1)^K C(n-1,K), the same for every X, t and w')
    agree(LOG + 'fock_encodings.log', 'Tr (-1)^F e^(-beta H) for beta = 0.05, 0.5, 5 equals the exact Euler number in all 164 complexes')
    x0, y0, cw = 70, 58, 46
    F.t(x0 - 10, y0, 'n \\ K', anchor='end', size=11.5, cls='mu')
    for K in range(7):
        F.t(x0 + K * cw + cw / 2, y0, str(K), size=12.5, cls='mu')
    for n in range(1, 7):
        y = y0 + 8 + (n - 1) * 26
        F.t(x0 - 10, y + 17, str(n), anchor='end', size=12.5, cls='mu')
        for K in range(n + 1):
            v = table[(n, K)]
            F.r(x0 + K * cw + 1, y + 1, cw - 2, 24, 'pos' if v > 0 else 'neg' if v < 0 else 'nul', rx=3)
            F.t(x0 + K * cw + cw / 2, y + 17, (MINUS + str(-v)) if v < 0 else str(v), size=12.5)
    for k, s in enumerate(['Q: left multiplication by w = e₁ + 2e₂ + … in the null cell,',
                           'Q² = 0, cut at degree K; H = QQᵀ + QᵀQ. Each entry is',
                           'Σ (−1)ᵏ dim Hᵏ = (−1)^K C(n−1, K); the trace agrees with it at',
                           f'β = 0.05, 0.5 and 5 in all {len(table)} complexes (numpy, error < 1e−9).',
                           'K = n: the complex is exact; the index is 0, the super-dimension.']):
        F.t(14, 236 + k * 19, s, anchor='start', size=12.5, cls='t2')
    F.save()


# ================================================================================================ fig19: halving
def cname(eps):
    p, q, r = eps.count(1), eps.count(-1), eps.count(0)
    return f'Cl({p},{q}' + (f',{r})' if r else ')')


def loewy(A, basis):
    """Loewy length of the ideal spanned by the labels `basis` of the algebra A (the least L with J^L = 0), by products"""
    J = [{a: 1} for a in basis]
    cur, L = J, 1
    while cur:
        nxt = []
        for x in cur:
            for y in J:
                z = A.mul(x, y)
                if z and rank_fr(nxt + [z], A.M) > rank_fr(nxt, A.M):
                    nxt.append(z)
        cur, L = nxt, L + 1
    return L - 1


def fig19():
    F = Fig('fig19_halving', 440, 392, 'Halving: the even part of a cell is the cell with one generator fewer through f_i = e_i e_t, and what happens with only null generators')
    F.t(14, 20, 'Halve: fᵢ = eᵢ e_t (i ≠ t) generate the even part', anchor='start', bold=True)
    cols = [('cell', 14), ('t', 112), ('squares of the fᵢ', 150), ('even part ≅', 282), ('pairs', 386)]
    for (h, x) in cols:
        F.t(x, 46, h, anchor='start', size=12.5, cls='mu')
    cases = [((1, -1, -1, -1), 1), ((1, 1, 1), 0), ((1, 1, 1, 0), 0), ((1, 0, 0), 0)]
    for k, (eps, t) in enumerate(cases):
        A, n = BR(eps), len(eps)
        others = [i for i in range(n) if i != t]
        f = [A.mul({1 << i: 1}, {1 << t: 1}) for i in others]
        sq = []
        for j, fj in enumerate(f):
            s2 = A.mul(fj, fj)
            assert set(s2) <= {0}
            sq.append(s2.get(0, 0))
            for k2, fk in enumerate(f):
                if k2 != j:
                    assert not A.add(A.mul(fj, fk), A.mul(fk, fj))
        B = BR(tuple(sq))

        def fA(m):
            out = {0: 1}
            for j in range(n - 1):
                if m >> j & 1:
                    out = A.mul(out, f[j])
            return out
        imgs = [fA(m) for m in range(B.M)]
        assert all(popcount(a) % 2 == 0 for x in imgs for a in x)
        assert rank_fr(imgs, A.M) == B.M
        good = sum(A.mul(imgs[x], imgs[y]) == {k3: v * B.s(x, y) for k3, v in imgs[x ^ y].items()} if B.s(x, y) else not A.mul(imgs[x], imgs[y])
                   for x in range(B.M) for y in range(B.M))
        assert good == B.M ** 2
        y = 70 + k * 24
        if k % 2 == 0:
            F.r(8, y - 15, 426, 22, 'tn', rx=3)
        F.t(14, y, cname(eps), anchor='start', size=12.5)
        F.t(112, y, f'e{SUB[t + 1]} ({sg(eps[t])}1)', anchor='start', size=12.5)
        F.t(150, y, '(' + ','.join(sg(v) for v in sq) + ')', anchor='start', size=12.5)
        F.t(282, y, cname(tuple(sq)), anchor='start', size=12.5, bold=True)
        F.t(386, y, f'{good}', anchor='start', size=12.5)
    y0 = 186
    F.t(14, y0, 'Only null generators: no t; is Λᵉᵛ(ℝʳ) the cell Λ(ℝʳ⁻¹)?', anchor='start', bold=True)
    cols2 = [('r', 14), ('dim Λᵉᵛ', 50), ('radical', 130), ('Loewy length', 200), ('of Λ(ℝʳ⁻¹)', 300), ('a cell?', 386)]
    for (h, x) in cols2:
        F.t(x, y0 + 24, h, anchor='start', size=12.5, cls='mu')
    fails = []
    for r in range(1, 6):
        A = BR((0,) * r)
        ev = [a for a in range(A.M) if popcount(a) % 2 == 0]
        Lev = loewy(A, [a for a in ev if a]) + 1 if len(ev) > 1 else 1
        Bc = BR((0,) * (r - 1))
        Lc = loewy(Bc, list(range(1, Bc.M))) + 1 if Bc.M > 1 else 1
        ok = Lev == Lc and len(ev) == Bc.M
        if not ok:
            fails.append(r)
        y = y0 + 46 + (r - 1) * 22
        if r % 2 == 1:
            F.r(8, y - 15, 426, 22, 'tn', rx=3)
        for (v, x) in [(r, 14), (len(ev), 50), (len(ev) - 1, 130), (Lev, 200), (Lc, 300)]:
            F.t(x, y, str(v), anchor='start', size=12.5)
        F.t(386, y, 'yes' if ok else 'no', anchor='start', size=12.5, bold=not ok)
        assert Lev == r // 2 + 1 and Lc == r
    assert fails == [3, 4, 5]
    agree(LOG + 'reruns/cat_check.log', 'With only null generators it fails from 3 generators on (p = q = 0, r')
    for k, s in enumerate(['A square ±1 gives f_i² = −εᵢ ε_t: t² = −1 keeps the squares, t² = +1 flips them;',
                           'the map depends on t (natural on pointed spaces (V, t)). Loewy length here:',
                           'the number of layers of the radical, counted by products (1 = semisimple).']):
        F.t(14, 334 + k * 19, s, anchor='start', size=12.5, cls='t2')
    F.save()

# ================================================================================================ the widgets' stored vectors
def check_widgets():
    out = []
    for f in sorted((HERE / 'widgets').glob('*.js')) if (HERE / 'widgets').exists() else []:
        src = f.read_text(encoding='utf8')
        m = re.search(r'const EPS0 = \[([^\]]*)\];', src)
        s = re.search(r'const STORED = (\[\[.*?\]\]);', src, re.S)
        if not (m and s):
            out.append((f.name, 'no stored vectors'))
            continue
        eps = tuple(int(x) for x in m.group(1).replace(' ', '').split(','))
        A = BR(eps)
        vec = eval(s.group(1), {'__builtins__': {}})
        for row in vec:
            a, b, v = row[0], row[1], row[2]
            assert A.s(a, b) == v, (f.name, row)
            if len(row) > 3:
                assert pn(a ^ b) == row[3], (f.name, row)
        lm = re.search(r'const LAMBDA30 = \[([^\]]*)\];', src)
        if lm:
            A3, M = pairing((1, 1, 1))
            assert [M[a][a ^ 7] for a in range(8)] == [int(x) for x in lm.group(1).replace(' ', '').split(',')], f.name
        out.append((f.name, f'{len(vec)} stored products agree with the rule'))
    return out


if __name__ == '__main__':
    for fn in (fig01, fig02, fig03, fig04, fig05, fig06, fig07, fig08, fig09, fig10, fig11, fig12, fig13, fig14, fig15, fig16, fig17, fig18, fig19):
        fn()
    for name, size in DONE:
        print(f'wrote figs/{name}.svg ({size} bytes)')
    print(f'{len(AGREE)} computed statements found word for word in the shipped logs and pages:')
    for where, needle in AGREE:
        print(f'   {where}: "{needle[:110]}"')
    for name, msg in check_widgets():
        print(f'widget {name}: {msg}')
