#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/merge_explore.mjs — merges the overlay of the leaves (content/explore/*.json; docs/round7/PLAN.md R7-3, interfaces 37–38) into content/rows.json,
// texts.json, pages.json and figures.json, so that a re-migration from v15 keeps it (D23). A leaf (Octavo's live picture) has no page of its own: its
// figure is the top of the Atlas page it belongs to, or the figure of a section of that page, and its rows are placed there.
//
//   registry.json       the door's data: the path of 8, the shelf, the lens explorers; per leaf its figure (null: not drawn yet), its page and its
//                       anchor ("top": the page top, else a section of the page), its way in for the mathematician (lens) and its try line (try);
//                       a lens explorer may sit under a chip of its section (detail)
//                         → pages.json: page.top = { figure, leaf, lens, kind } for the leaf anchored at the top, page.slots = [{ section, figure,
//                           leaf, kind, try, detail }] for the leaves anchored at a section, page.connective["top-notes"] = the top leaf's try line
//   pages.json          the figures a page top displaces: [{ route, moves: [{ figure, section, captions }] }] (captions "intro": the caption rows of the
//                       page's intro go with the figure, which they describe)  → page.slots, kind "move"
//   placements.json     [{ row, page, section, order, role }]: the notes of a top leaf in the reserved section "top-notes" (role note, at most three),
//                       the other rows of a leaf in a section of the page (role result or detail); order 1000 and more, so no row's home moves
//                         → the rows' shownOn, each entry marked overlay "explore"
//   rows.json, texts.json   new rows (since "v2.1", or "v2.4" for the leaves of round 7, wave 2) and their research texts (source "explore:…")  → rows.json, texts.json
//   figures.leaf.json, figures.lens.json   the seeds leaf-*, lens-*  → figures.json
//
// Idempotent and deterministic. What the overlay wrote before is removed first: the pages of the earlier overlay (routes "explore" and "explore/…"), the
// fields top and slots and the connective "top-notes" of every page, every shownOn entry marked overlay "explore" (or on an "explore" route), the seeds
// leaf-* and lens-*, the rows the overlay added (MIGRATION_COUNTS.json, key "explore") and the texts of source "explore:". A page the overlay writes is
// taken as the story merge leaves it before it composes (baseTables of tools/merge_story.mjs: the page restored where it still holds what that merge wrote),
// so that the story merge, which runs after this one, keeps a base without its own earlier output (content/story/merged.json).
// Checked first (on an error nothing is written, exit 1): every leaf on one page and one anchor, a figure placed once; anchors and placement sections that
// are sections of the page (as the story overlay composes it: content/story/{sections,chapters,furey}.json); at most three notes a page, none of them its
// hero row; orders ≥ 1000; try lines of at most 240 characters; names that are names; seeds with a caption row.
// Run it after tools/migrate/figures_from_v15.mjs (run_all.sh) and before tools/merge_physics.mjs, tools/merge_story.mjs and tools/build_content.mjs
// (npm run content).
// Usage: node tools/merge_explore.mjs            merge and write
//        node tools/merge_explore.mjs --check    check the overlay against the tables and print what a merge would do; write nothing
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content'), X = path.join(C, 'explore'), S = path.join(C, 'story');
const readJSON = (f, fallback) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback);
const writeJSON = (f, d) => fs.writeFileSync(f, JSON.stringify(d, null, 1));
const clone = x => JSON.parse(JSON.stringify(x));
const CHECK = process.argv.includes('--check');

export const TOP_NOTES = 'top-notes';          // the reserved section of a page top's notes (interface 37)
export const OVERLAY = 'explore';              // the mark of the overlay's shownOn entries
const isOldRoute = r => r === 'explore' || String(r || '').startsWith('explore/');
const isOverlayFigure = id => /^(leaf|lens)-/.test(String(id || ''));
const isOverlayText = t => String(t.source || '').startsWith('explore:');
const textKey = t => [t.row, t.level, t.mode || 'both', t.lens || '', t.register || 'full'].join('|') + (t.chain != null ? '|' + t.chain : '');   // a span keys with its chain (round 14, §2.2)
const byText = (a, b) => a.row.localeCompare(b.row, 'en') || a.level.localeCompare(b.level) || String(a.lens || '').localeCompare(String(b.lens || ''));
const byId = (a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
const NEW_SINCE = new Set(['v2.1', 'v2.4']);   // the overlay's own rows: since v2.1 (round 4) or v2.4 (the leaves of round 7, wave 2)
const BRANCH_LENSES = new Set(['geo', 'alg', 'top', 'cat', 'comb']);
const CONNECTIVE_MAX = 240, TITLE_MAX = 40, PLACEMENT_MIN = 1000, NOTES_MAX = 3;
/** a card name is a name: no digit, at most 40 characters, not a sentence */
const nameProblem = t => (typeof t !== 'string' || !t.trim() ? 'empty' : /\d/.test(t) ? 'holds a digit' : t.length > TITLE_MAX ? `${t.length} characters` : /[.!?:;]$/.test(t.trim()) ? 'ends like a sentence' : null);

/**
 * The map of the leaves (pure, for the merge and the tests): every registry entry with its kind (path, shelf, lens), and per page its top and its slots.
 * → { entries: [{ ...entry, kind }], tops: Map route → { figure, leaf, lens, kind, try }, slots: Map route → [{ section, figure, leaf, kind, try, detail,
 *   captions }] } — the slots of a page in this order: the leaves of the path and the shelf, then the moved figures, then the lens explorers.
 */
export function leafMap(registry, movesOverlay) {
  const entries = [
    ...(registry.path || []).map(e => ({ ...e, kind: 'path' })),
    ...(registry.shelf || []).map(e => ({ ...e, kind: 'shelf' })),
    ...(registry.lenses || []).map(e => ({ ...e, kind: 'lens' })),
  ];
  const tops = new Map(), slots = new Map();
  const add = (route, slot) => { if (!slots.has(route)) slots.set(route, []); slots.get(route).push(slot); };
  for (const e of entries) {
    if (!e.figure || !e.page) continue;
    if (e.anchor === 'top') { if (!tops.has(e.page)) tops.set(e.page, { figure: e.figure, leaf: e.slug, lens: e.lens || null, kind: e.kind, try: e.try || null }); continue; }
    add(e.page, { section: e.anchor, figure: e.figure, leaf: e.slug, kind: e.kind === 'lens' ? 'lens' : 'leaf', try: e.try || null, detail: !!e.detail, captions: null });
  }
  for (const p of movesOverlay || []) for (const m of (p && p.moves) || []) add(p.route, { section: m.section, figure: m.figure, leaf: null, kind: 'move', try: null, detail: false, captions: m.captions || null });
  const rank = s => (s.kind === 'leaf' ? 0 : s.kind === 'move' ? 1 : 2);
  for (const [route, list] of slots) slots.set(route, list.map((s, i) => ({ s, i })).sort((a, b) => rank(a.s) - rank(b.s) || a.i - b.i).map(x => x.s));
  return { entries, tops, slots };
}

/** the sections a page has once the story overlay composes it: those of pages.json and those the story overlay files name for the route */
function sectionsAfterStory(pages) {
  const out = new Map(pages.map(p => [p.route, new Set((p.sections || []).flatMap(s => [s.id, s.query && s.query['shownOn.section']]).filter(Boolean))]));
  const files = ['sections.json', 'chapters.json'].map(n => readJSON(path.join(S, n), []));
  const fy = readJSON(path.join(S, 'furey.json'), []);
  files.push(Array.isArray(fy) ? fy : [...(fy.pages || []), ...(fy.sections || [])]);
  for (const list of files) for (const e of Array.isArray(list) ? list : []) {
    if (!e || typeof e.route !== 'string') continue;
    const route = e.route === '' ? '' : e.route;
    if (!out.has(route)) out.set(route, new Set());
    for (const s of e.sections || []) if (s && s.id) out.get(route).add(s.id);
  }
  return out;
}

async function main() {
  // ------------------------------------------------------------------------------------------------------------- the tables and the overlay
  const rows0 = readJSON(path.join(C, 'rows.json'), []);
  const texts0 = readJSON(path.join(C, 'texts.json'), []);
  const pages0 = readJSON(path.join(C, 'pages.json'), []);
  const figures0 = readJSON(path.join(C, 'figures.json'), []);
  const lenses = readJSON(path.join(C, 'lenses.json'), []);
  const countsFile = path.join(C, 'MIGRATION_COUNTS.json');
  const counts = readJSON(countsFile, {});

  const registry = readJSON(path.join(X, 'registry.json'), { path: [], shelf: [], lenses: [] });
  const xMoves = readJSON(path.join(X, 'pages.json'), []);
  const xPlacements = readJSON(path.join(X, 'placements.json'), []);
  const xRows = readJSON(path.join(X, 'rows.json'), []);
  const xTexts = readJSON(path.join(X, 'texts.json'), []);
  const xFigures = [...readJSON(path.join(X, 'figures.leaf.json'), []), ...readJSON(path.join(X, 'figures.lens.json'), [])];

  const errors = [], warnings = [];
  const E = (where, msg) => errors.push(`${where}: ${msg}`);
  const Wn = (where, msg) => warnings.push(`${where}: ${msg}`);
  for (const [name, v] of [['pages.json', xMoves], ['placements.json', xPlacements], ['rows.json', xRows], ['texts.json', xTexts]]) if (!Array.isArray(v)) E(`content/explore/${name}`, 'not an array');
  if (!registry || typeof registry !== 'object' || !Array.isArray(registry.path) || !Array.isArray(registry.shelf) || !Array.isArray(registry.lenses)) E('content/explore/registry.json', 'not { path: [], shelf: [], lenses: [] }');
  if (errors.length) { console.log(errors.join('\n')); return 1; }

  // ------------------------------------------------------------------------------------------------------------- rows
  const prevAdded = new Set((counts.explore && counts.explore.rows) || []);
  const xRowIds = new Set();
  for (const r of xRows) {
    const at = `content/explore/rows.json ${r && r.id}`;
    if (!r || typeof r.id !== 'string' || !/^[A-Z]{2,4}-\d{3}[a-z]?$/.test(r.id)) { E(at, 'a new row needs an id <GROUP>-<3 digits>'); continue; }
    if (xRowIds.has(r.id)) E(at, 'duplicate id in the overlay');
    xRowIds.add(r.id);
    if (!NEW_SINCE.has(r.since)) E(at, `since is ${JSON.stringify(r.since)}, not ${[...NEW_SINCE].map(v => `"${v}"`).join(' or ')}`);
    if (!Array.isArray(r.notions) || !r.notions.length) E(at, 'notions must be a non-empty list');
    for (const k of ['group', 'kind', 'stage', 'ptype']) if (typeof r[k] !== 'string' || !r[k]) E(at, `no ${k}`);
    if (!Array.isArray(r.evidence)) E(at, 'evidence must be a list (empty when the row has none)');
    if (r.legacyFlags && r.legacyFlags.length) E(at, 'a new row carries no v15 flags (its status is computed by 02 §4, D22)');
    const old = rows0.find(x => x.id === r.id);
    if (old && !NEW_SINCE.has(old.since)) E(at, 'the id is a row of the migration: an overlay row never replaces a v15 row');
    if (!xTexts.some(t => t.row === r.id && t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full')) E(at, 'no research text in content/explore/texts.json');
    if ((r.shownOn || []).some(so => isOldRoute(so.page))) E(at, 'a row of the overlay is shown on Atlas pages (the routes explore/… are gone)');
  }
  const stale = rows0.filter(r => prevAdded.has(r.id) && !xRowIds.has(r.id)).map(r => r.id);
  for (const r of rows0) if (NEW_SINCE.has(r.since) && !xRowIds.has(r.id) && !prevAdded.has(r.id)) Wn(r.id, `a row with since "${r.since}" that the overlay does not hold; kept`);
  const staleSet = new Set(stale);
  const strip = so => (so || []).filter(s => !isOldRoute(s.page) && s.overlay !== OVERLAY);
  const rows = rows0.filter(r => !staleSet.has(r.id) && !xRowIds.has(r.id)).map(r => ({ ...r, shownOn: strip(r.shownOn) }));
  for (const r of xRows) if (r && r.id) rows.push({ ...clone(r), shownOn: strip(r.shownOn) });
  rows.sort(byId);
  const rowById = new Map(rows.map(r => [r.id, r]));

  // ------------------------------------------------------------------------------------------------------------- pages: the earlier overlay out, the story base in
  let pages = pages0.filter(p => !isOldRoute(p.route));
  const lensKeys = new Set(lenses.map(l => l.key));
  const { entries, tops, slots } = leafMap(registry, xMoves);
  const written = new Set([...tops.keys(), ...slots.keys()]);
  // the story merge's base of the pages this overlay writes (and of every page that carries what it wrote before)
  const carries = p => p && (p.top !== undefined || p.slots !== undefined || (p.connective && p.connective[TOP_NOTES] !== undefined));
  const touch = new Set([...written, ...pages.filter(carries).map(p => p.route)]);
  let storeBase = null;
  try {
    const ms = await import(pathToFileURL(path.join(ROOT, 'tools', 'merge_story.mjs')).href);
    if (typeof ms.baseTables === 'function') storeBase = new Map(ms.baseTables({ rows: [], texts: [], pages: pages0.filter(p => !isOldRoute(p.route)) }).pages.map(p => [p.route, p]));
  } catch (e) { Wn('tools/merge_story.mjs', `its base could not be read (${String(e.message).split('\n')[0]}); the pages are taken as they are`); }
  let based = 0;
  pages = pages.map(p => {
    if (!touch.has(p.route)) return p;
    // a page the story merge added (absent from its base) that this overlay does not write keeps its try line: its "top-notes" is the story's
    // (round 14: shifted, content/chains/shifted/page.json), never a leftover of this overlay; taking it would leave the story's book without it
    if (storeBase && !storeBase.has(p.route) && !written.has(p.route)) return p;
    let q = storeBase && storeBase.has(p.route) ? clone(storeBase.get(p.route)) : clone(p);
    if (storeBase && storeBase.has(p.route) && JSON.stringify(storeBase.get(p.route)) !== JSON.stringify(p)) based++;
    delete q.top; delete q.slots;
    if (q.connective && typeof q.connective === 'object') { const c = { ...q.connective }; delete c[TOP_NOTES]; q.connective = c; }
    return q;
  });
  const pageOf = new Map(pages.map(p => [p.route, p]));
  const sectionsOf = sectionsAfterStory(pages0.filter(p => !isOldRoute(p.route)));
  const seedOf = new Map([...figures0.filter(f => !isOverlayFigure(f.id)), ...xFigures].filter(f => f && f.id).map(f => [f.id, f]));

  // ------------------------------------------------------------------------------------------------------------- the registry
  registry.path.forEach((p, i) => {
    const at = `content/explore/registry.json path[${i}]`;
    if (p.n !== i + 1) E(at, `n is ${p.n}, the path is numbered 1 to 8 in order`);
    if (!Array.isArray(p.needs) || p.needs.some(n => !Number.isInteger(n) || n < 1 || n >= p.n)) E(at, 'needs must list earlier path numbers');
  });
  if (registry.path.length && registry.path.length !== 8) E('content/explore/registry.json', `the path has ${registry.path.length} leaves, not 8`);
  registry.shelf.forEach((s, i) => { if (!Number.isInteger(s.under) || s.under < 1 || s.under > 8) E(`content/explore/registry.json shelf[${i}]`, 'under must be a path number 1 to 8'); if (!s.figure) E(`content/explore/registry.json shelf[${i}]`, 'the shelf lists only the leaves that are drawn (a figure)'); });
  registry.lenses.forEach((l, i) => { if (!l.figure) E(`content/explore/registry.json lenses[${i}]`, 'a lens explorer names its figure'); });
  const slugs = entries.map(x => x.slug);
  if (new Set(slugs).size !== slugs.length) E('content/explore/registry.json', 'a slug appears twice');
  const placed = new Map(); // figure → where
  const placeFig = (fig, where) => { if (placed.has(fig)) E(where, `the figure ${fig} is placed twice (also ${placed.get(fig)}): a leaf lives on one page`); else placed.set(fig, where); };
  for (const e of entries) {
    const at = `content/explore/registry.json ${e.kind} ${e.slug}`;
    const np = nameProblem(e.name); if (np) E(at, `name ${np}`);
    if (!/^[a-z][a-z-]*$/.test(String(e.slug || ''))) E(at, 'a slug is lower-case words joined by "-"');
    if (!pageOf.has(e.page)) { E(at, `page ${JSON.stringify(e.page)} is not a page of pages.json`); continue; }
    if (e.anchor !== 'top' && !(sectionsOf.get(e.page) || new Set()).has(e.anchor)) E(at, `anchor ${JSON.stringify(e.anchor)} is neither "top" nor a section of ${e.page}`);
    if (e.figure == null) { if (e.kind !== 'path') E(at, 'only a leaf of the path is listed before it is drawn'); if (e.lens || e.try) E(at, 'a leaf not drawn yet has no lens and no try line'); continue; }
    if (!isOverlayFigure(e.figure) || !xFigures.some(f => f && f.id === e.figure)) E(at, `figure ${e.figure} is not a seed of content/explore/figures.*.json`);
    placeFig(e.figure, `${e.page} ${e.anchor}`);
    if (e.lens != null && (!BRANCH_LENSES.has(e.lens) || !lensKeys.has(e.lens))) E(at, `lens ${JSON.stringify(e.lens)} is not a branch lens (geo, alg, top, cat, comb)`);
    if (e.try != null && (typeof e.try !== 'string' || !e.try.trim() || e.try.length > CONNECTIVE_MAX)) E(at, `the try line has ${String(e.try || '').length} characters (1 to ${CONNECTIVE_MAX})`);
    if (e.detail && (e.kind !== 'lens' || e.anchor === 'top')) E(at, 'only a lens explorer in a section sits under a chip (detail)');
  }
  for (const [route] of tops) { const n = entries.filter(e => e.page === route && e.anchor === 'top' && e.figure).length; if (n > 1) E(`page ${route}`, `${n} leaves anchored at its top (one)`); }
  for (const p of xMoves) {
    const at = `content/explore/pages.json ${p && p.route}`;
    if (!p || !pageOf.has(p.route)) { E(at, 'not a page of pages.json'); continue; }
    if (!tops.has(p.route)) E(at, 'a page moves a figure only when a leaf takes its top');
    for (const m of p.moves || []) {
      if (!seedOf.has(m.figure) || isOverlayFigure(m.figure)) E(at, `the moved figure ${m.figure} is not a seed of figures.json outside the overlay`);
      else placeFig(m.figure, `${p.route} ${m.section} (moved)`);
      if (!(sectionsOf.get(p.route) || new Set()).has(m.section)) E(at, `section ${m.section} is not a section of the page`);
      if (m.captions != null && m.captions !== 'intro') E(at, `captions ${JSON.stringify(m.captions)} (only "intro")`);
    }
  }
  // the story overlay may name a leaf figure in a section too: the map wins (the page model draws a mapped figure only where the map places it)
  for (const p of pages0.filter(q => !isOldRoute(q.route))) for (const s of p.sections || []) for (const f of (Array.isArray(s.figure) ? s.figure : s.figure ? [s.figure] : [])) {
    if (placed.has(f) && placed.get(f) !== `${p.route} ${s.id}`) Wn(`${p.route} · ${s.id}`, `the section names the figure ${f}, which the map places at ${placed.get(f)}; drawn there only`);
  }

  // ------------------------------------------------------------------------------------------------------------- placements
  const seenPl = new Set(), notesOn = new Map();
  for (const [i, pl] of xPlacements.entries()) {
    const at = `content/explore/placements.json #${i} (${pl && pl.row} · ${pl && pl.page})`;
    if (!pl || !rowById.has(pl.row)) { E(at, 'not a row'); continue; }
    const page = pageOf.get(pl.page);
    if (!page) { E(at, 'not a page of pages.json'); continue; }
    if (pl.section === TOP_NOTES) {
      if (pl.role !== 'note') E(at, `a note of the page top has role note (${JSON.stringify(pl.role)})`);
      if (!tops.has(pl.page)) E(at, 'notes of a page top on a page without a top leaf');
      notesOn.set(pl.page, (notesOn.get(pl.page) || 0) + 1);
    } else {
      if (!(sectionsOf.get(pl.page) || new Set()).has(pl.section)) E(at, `section ${pl.section} is not a section of the page`);
      if (pl.role !== 'result' && pl.role !== 'detail') E(at, `role ${JSON.stringify(pl.role)} (result or detail; note only in ${TOP_NOTES})`);
    }
    if (!Number.isInteger(pl.order) || pl.order < PLACEMENT_MIN) E(at, `order ${pl.order}: at least ${PLACEMENT_MIN}, so that no row's home moves`);
    if (page.hero && page.hero.row === pl.row) E(at, 'the hero row of the page is not placed again (the top shows it)');
    const k = `${pl.row}|${pl.page}`;
    if (seenPl.has(k)) E(at, 'the row is placed twice on the page');
    seenPl.add(k);
    if (rowById.get(pl.row).shownOn.some(so => so.page === pl.page) && pl.section !== TOP_NOTES) Wn(at, 'the row is on the page already; the page shows it once');
    rowById.get(pl.row).shownOn.push({ page: pl.page, section: pl.section, order: pl.order, role: pl.role, overlay: OVERLAY });
  }
  for (const [route, n] of notesOn) if (n > NOTES_MAX) E(`page ${route}`, `${n} notes at its top (at most ${NOTES_MAX})`);
  const homeOf = r => [...(r.shownOn || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
  for (const id of new Set(xPlacements.map(p => p && p.row))) { const r = rowById.get(id); const h = r && homeOf(r); if (r && h && h.overlay === OVERLAY && rows0.find(x => x.id === id && strip(x.shownOn).length)) E(id, `its home would move to ${h.page}`); }
  for (const r of rows) if ((r.shownOn || []).length === 0 && r.kind !== 'meta') Wn(r.id, 'no shownOn entry left');

  // ------------------------------------------------------------------------------------------------------------- texts
  const xKeys = new Set();
  for (const t of xTexts) {
    const at = `content/explore/texts.json ${t && t.row}`;
    if (!t || !xRowIds.has(t.row)) { E(at, 'a text of the overlay belongs to a new row of content/explore/rows.json'); continue; }
    if (t.level !== 'research') E(at, 'the overlay holds research texts only (learner drafts go to content/texts_learner_explore.json)');
    if (!isOverlayText(t)) E(at, 'source must start with "explore:"');
    if (t.status !== 'draft') E(at, `status ${JSON.stringify(t.status)}, not "draft"`);
    if (typeof t.body !== 'string' || !t.body.trim()) E(at, 'empty body');
    if (xKeys.has(textKey(t))) E(at, 'two texts with the same key');
    xKeys.add(textKey(t));
  }
  let keptHuman = 0, droppedStale = 0;
  const map = new Map();
  for (const t of texts0) {
    if (staleSet.has(t.row)) { droppedStale++; continue; }
    if (isOverlayText(t) && !xKeys.has(textKey(t))) continue;
    map.set(textKey(t), t);
  }
  for (const t of xTexts) {
    if (!t || !xRowIds.has(t.row)) continue;
    const rec = { row: t.row, lang: t.lang || 'en', mode: t.mode || 'both', level: t.level, lens: t.lens || null, register: t.register || 'full', body: String(t.body).trim(), status: t.status, source: t.source };
    const old = map.get(textKey(rec));
    if (old && old.status === 'human') { keptHuman++; continue; }
    map.set(textKey(rec), rec);
  }
  const texts = [...map.values()].sort(byText);

  // ------------------------------------------------------------------------------------------------------------- figures
  const seenFig = new Set();
  for (const f of xFigures) {
    const at = `figure seed ${f && f.id}`;
    if (!f || !isOverlayFigure(f.id)) { E(at, 'a seed id starts with leaf- or lens-'); continue; }
    if (seenFig.has(f.id)) E(at, 'duplicate seed');
    seenFig.add(f.id);
    if (!rowById.has(f.captionRow)) E(at, `captionRow ${f.captionRow} is not a row`);
    if (!Array.isArray(f.lenses) || f.lenses.some(l => !lensKeys.has(l))) E(at, 'lenses must be a list of lens keys of lenses.json');
    if (typeof f.learner !== 'boolean') E(at, 'learner must be true or false');
    if (f.size !== 'wide') E(at, 'a leaf or lens figure is wide (size "wide": the page top draws it across the page)');
  }
  const figures = [...figures0.filter(f => !isOverlayFigure(f.id)), ...xFigures.filter(f => f && isOverlayFigure(f.id)).map(clone)];
  for (const f of seenFig) if (!placed.has(f)) Wn(f, 'a seed that no leaf of the registry places');

  // ------------------------------------------------------------------------------------------------------------- the pages the overlay writes
  for (const p of pages) {
    const top = tops.get(p.route), sl = slots.get(p.route);
    if (top) {
      p.top = { figure: top.figure, leaf: top.leaf, lens: top.lens, kind: top.kind };
      if (top.try) p.connective = { ...(p.connective || {}), [TOP_NOTES]: top.try };
    }
    if (sl && sl.length) p.slots = sl.map(s => ({ section: s.section, figure: s.figure, leaf: s.leaf, kind: s.kind, try: s.try, detail: s.detail, captions: s.captions }));
  }

  // ------------------------------------------------------------------------------------------------------------- write
  const summary = { rows: rows.length, newRows: xRowIds.size, removedRows: stale.length, placements: xPlacements.length, tops: tops.size, slots: [...slots.values()].reduce((k, l) => k + l.length, 0), pagesFromStoryBase: based, removedPages: pages0.length - pages0.filter(p => !isOldRoute(p.route)).length, figures: figures.filter(f => isOverlayFigure(f.id)).length, overlayTexts: xKeys.size, keptHuman, textsOfRemovedRows: droppedStale, texts: texts.length, warnings: warnings.length, errors: errors.length };
  if (warnings.length) console.log(warnings.map(w => 'warning ' + w).join('\n'));
  if (errors.length) { console.log(errors.map(e => 'ERROR ' + e).join('\n')); console.log(`merge_explore: ${errors.length} error(s); nothing written`); return 1; }
  if (CHECK) { console.log(`merge_explore --check: ${JSON.stringify(summary)}`); return 0; }
  writeJSON(path.join(C, 'rows.json'), rows);
  writeJSON(path.join(C, 'texts.json'), texts);
  writeJSON(path.join(C, 'pages.json'), pages);
  writeJSON(path.join(C, 'figures.json'), figures);
  counts.explore = { rows: [...xRowIds].sort(), placements: xPlacements.length, tops: tops.size, slots: summary.slots, figures: summary.figures, texts: xKeys.size };
  writeJSON(countsFile, counts);
  console.log(`merge_explore: ${JSON.stringify(summary)}`);
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(await main());
