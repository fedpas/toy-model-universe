#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/proofs_todo.mjs — the statements that wait for a check, listed, classed and ranked (docs/round7/PLAN.md, decision R7-8).
//
// A row is "missing its proof" when its computed status is
//   cited      a script is named, no passing run is recorded for it;
//   ours       and its kind states something checkable (kind is not "reading");
//   open       and the question has a computable answer (a conjecture or a question, not a scope list, a name or a source to read);
// a candidate (content/candidates.json) is on the list when the personas marked it checkable "yes". The fifth class is the story: for every
// page, the chain  lead -> key results  (the rule of src/app/queries.js, buildPageModel: five key results per section at research level, three
// at learner level) is complete when every result in it is proved-by-atlas or standard.
//
// What the tables decide, the tool computes: the classes, the counts, the page of a row, the statement in at most twenty words, the rows that depend
// on it (the depends edges into it), the chains, the ranking and the file. What only a reader can decide (what a check would compute, the bit route, the
// standard route, the cost, whether a wrong statement would leave the printed sentence false) is written once, per id, in the notes at the end of this file. Every id
// of every class must have a note: a row that enters a class later is printed as "unannotated" and the check fails until it gets one.
//
// Ranking (R7-8): false-if-wrong first, then the cost S before M before L, then the number of rows that depend on the statement, then the id.
//
// Usage:  node tools/proofs_todo.mjs               write docs/PROOFS_TODO.md, and refresh the generated list of statements inside each of the eight
//                                                 briefs docs/round7/leads/L7-01.md ... L7-08.md (between their two marker lines; the rest of a brief is never touched)
//         node tools/proofs_todo.mjs --out FILE    write another file (the briefs are left alone)
//         node tools/proofs_todo.mjs --check       exit 1 when the notes miss an id, name a file or a run that does not exist, the file differs,
//                                                 or a brief is missing, has no markers, or carries a list that differs from the tables
//         node tools/proofs_todo.mjs --selftest    plant broken inputs; each must be caught (exit 1 when one is not)
//         node tools/proofs_todo.mjs --json        print the model as JSON
//         node tools/proofs_todo.mjs --row ID ...  print a row or candidate: status, kind, evidence, dependencies, its text, and the note of the list
//         node tools/proofs_todo.mjs --lead L7-01  print the generated list of statements of one lead
// Needs no module outside node. Deterministic: no date, no random number, no network.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const argv = process.argv.slice(2);
const opt = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };

// ============================================================================================================================ tables
const TABLES = {
  rows: 'rows.json', texts: 'texts.json', status: 'derived/status.json', checks: 'checks.json', runs: 'check_runs.json',
  candidates: 'candidates.json', theorems: 'theorems.json', pages: 'pages.json', leads: 'leads.json',
};
function loadTables(root = ROOT) {
  const T = {};
  for (const [k, f] of Object.entries(TABLES)) T[k] = JSON.parse(fs.readFileSync(path.join(root, 'content', f), 'utf8'));
  return T;
}

// ============================================================================================================================ small helpers
const ORDER_COST = { S: 0, M: 1, L: 2 };
const OK_STATUS = new Set(['proved-by-atlas', 'standard']);
const NEUTRAL_STATUS = new Set(['meta']);
const DEP_RELS = new Set(['derives', 'equiv', 'instance', 'uses-input', 'restates']);   // the edges that make one row rest on another
const KEY_RESULTS = { research: 5, learner: 3 };                                         // src/app/vocab.js
const STORYLESS = r => /^explore(\/|$)/.test(r) || ['logbook', 'ask', 'glossary'].includes(r);   // pages with no story chain (see section 8)
const clean = s => String(s ?? '').replace(/\s+/g, ' ').trim();
const esc = s => clean(s).replace(/\|/g, '\\|');
const words = (s, n) => { const w = clean(s).split(' '); return w.length <= n ? w.join(' ') : w.slice(0, n).join(' ') + ' …'; };
const uniq = a => [...new Set(a)];
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;

/** the last recorded run of a script, as build_content.mjs finds it (later entries win a tie of dates; a bare name is matched by its file name) */
function makeRunIndex(runs) {
  const last = {};
  for (const r of runs) if (r.script) { const k = r.script; if (!last[k] || r.date >= last[k].date) last[k] = r; }
  const runOf = s => {
    if (!s) return null;
    const k = s.startsWith('checks/') ? s : 'checks/' + s;
    return last[k] || Object.values(last).find(x => x.script.endsWith('/' + path.basename(s))) || null;
  };
  const passes = s => { const r = runOf(s); return !!r && r.passed !== false && !(Number(r.fail) > 0); };
  return { runOf, passes };
}

// ============================================================================================================================ analysis
/**
 * The model of the list, a pure function of the tables and the notes (the self-test calls it with broken tables).
 * notes = { cited: {id: note}, ours: {id: note|'retag'...}, open: {id: ...}, cand: {id: note}, theorems: {id: note} }
 */
function analyse(T, N) {
  const byId = new Map(T.rows.map(r => [r.id, r]));
  const status = id => (T.status[id] || {}).status || null;
  const runIdx = makeRunIndex(T.runs);

  // ---- texts: the research text of a row in the shortest form that is at most 20 words
  const textsOf = new Map();
  for (const t of T.texts) if (t.lens === null && t.lang === 'en') { if (!textsOf.has(t.row)) textsOf.set(t.row, []); textsOf.get(t.row).push(t); }
  const pickText = (id, level) => {
    const a = (textsOf.get(id) || []).filter(t => t.level === level);
    const pref = [['both', 'short'], ['phys', 'short'], ['both', 'full'], ['phys', 'full'], ['math', 'short'], ['math', 'full']];
    for (const [m, r] of pref) { const t = a.find(x => x.mode === m && x.register === r); if (t) return t.body; }
    return a.length ? a[0].body : '';
  };
  const statement = id => words(pickText(id, 'research'), 20);

  // ---- the rows that depend on a row (depends edges into it)
  const dependents = new Map();
  for (const r of T.rows) for (const d of r.depends || []) if (DEP_RELS.has(d.rel) && d.id !== r.id) {
    if (!dependents.has(d.id)) dependents.set(d.id, new Set());
    dependents.get(d.id).add(r.id);
  }
  const nDependents = id => (dependents.get(id) || new Set()).size;
  const dependsCell = r => {
    const ids = uniq((r.depends || []).filter(d => d.rel !== 'cycle' && d.rel !== 'contradicts').map(d => d.id));
    return ids.length > 5 ? ids.slice(0, 5).join(', ') + ` +${ids.length - 5}` : ids.join(', ');
  };

  // ---- the page of a row: the placement of lowest order that is not an Explore page (those are folded into the Atlas pages)
  const pageOf = r => {
    const all = (r.shownOn || []).slice().sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
    const real = all.filter(s => !/^explore(\/|$)/.test(s.page));
    const s = (real[0] || all[0]);
    return s ? s.page + (s.section ? '#' + s.section : '') : '—';
  };

  // ---- batch 3 (R7-6): the rows the leads of the third batch reword
  const b3 = new Map();
  for (const l of (T.leads.leads || [])) for (const id of l.rowsReworded || []) { if (!b3.has(id)) b3.set(id, []); b3.get(id).push(l.id); }

  // what a passing check does not do by itself (tools/build_content.mjs): a row with legacy flags becomes proved-by-atlas only with the flag "checked",
  // and a row of kind question, conjecture or pointer, or of ptype open, stays open whatever it has run
  const editsOf = r => {
    const fl = r.legacyFlags || [];
    const e = ['evidence'];
    if (fl.length && !fl.includes('checked')) e.push('flag');
    if (['question', 'conjecture', 'pointer'].includes(r.kind) || r.ptype === 'open') e.push('kind');
    return e;
  };
  const rowItem = (r, cls, note) => ({
    id: r.id, cls, row: r, page: pageOf(r), statement: statement(r.id), status: status(r.id), kind: r.kind, deps: dependsCell(r),
    nDep: nDependents(r.id), b3: b3.get(r.id) || null, note: note || null, edits: editsOf(r),
  });

  // ---- class A: cited
  const cited = T.rows.filter(r => status(r.id) === 'cited').map(r => rowItem(r, 'cited', N.cited[r.id]));

  // ---- class B: ours (all ours rows; those of kind reading are outside the list by R7-8)
  const oursAll = T.rows.filter(r => status(r.id) === 'ours');
  const oursReadings = oursAll.filter(r => r.kind === 'reading');
  const oursClaims = oursAll.filter(r => r.kind !== 'reading').map(r => rowItem(r, 'ours', N.ours[r.id]));

  // ---- class C: open
  const openAll = T.rows.filter(r => status(r.id) === 'open').map(r => rowItem(r, 'open', N.open[r.id]));

  // ---- class D: candidates marked checkable "yes"
  const candAll = T.candidates.filter(c => c.status !== 'row');            // a candidate that became a CAND- row is a row now: in a class by its status, not here
  const candRows = T.candidates.filter(c => c.status === 'row');
  const candYes = candAll.filter(c => c.checkable === 'yes').map(c => ({
    id: c.id, cls: 'cand', cand: c, page: c.field, statement: words(c.title + ': ' + c.statement, 20), status: 'candidate', kind: 'candidate',
    deps: uniq(c.linksRows).slice(0, 5).join(', ') + (c.linksRows.length > 5 ? ` +${c.linksRows.length - 5}` : ''), nDep: c.linksRows.length,
    b3: null, note: N.cand[c.id],
  }));

  // ---- the supplement: the theorems whose status is not "proved" or whose check has declared gaps
  const thmGaps = T.theorems.filter(t => t.status !== 'proved' || t.verifier === 'gaps').map(t => ({
    id: t.id, cls: 'thm', thm: t, title: t.title, status: t.status, verifier: t.verifier, nDep: nDependents(t.id), rowsUsing: (t.rowsUsing || []).length, note: N.theorems[t.id],
  }));

  // ---- rows whose status says "open" while their text also states a checked result (a passing run is on their evidence)
  const openWithChecked = T.rows.filter(r => status(r.id) === 'open' && (r.legacyFlags || []).includes('checked')
    && (r.evidence || []).some(e => e.mode === 'ran' && runIdx.passes(e.script || e.check))).map(r => r.id);

  // ---- story chains
  const chains = buildChains(T, byId, status);

  // the rows a note annotates that are proved now (a closed lead's record stays in the notes): no longer in a class, not orphans
  const closed = new Set(Object.keys(T.status).filter(id => status(id) === 'proved-by-atlas' || status(id) === 'meta'));
  return { byId, status, runIdx, cited, oursAll, oursReadings, oursClaims, openAll, candAll, candRows, candYes, thmGaps, openWithChecked, chains, b3, nDependents, statement, pageOf, closed };
}

// ============================================================================================================================ chains
/**
 * The chain  lead -> key results  of every page, as src/app/queries.js (buildPageModel) selects them for the physicist's mode:
 * the top of the page (the hero row and the "at a glance" results) and, for every body section, its lead and its first N result rows
 * (N = section.key, else 5 at research level and 3 at learner level; the section's learner rows come first at learner level).
 * Open rows go to the open fold and are not key results; the notes of the page top (role note) are pointers, not results. A chain is complete
 * when every key result is proved-by-atlas or standard (a "meta" row, narration or a statement about the Atlas, is no result and is skipped).
 */
function buildChains(T, byId, status) {
  const hasT = new Set();
  for (const t of T.texts) if (t.lens === null && t.lang === 'en') hasT.add(`${t.row}|${t.level}|${t.mode}|${t.register}`);
  const hasText = (id, level) => hasT.has(`${id}|${level}|phys|full`) || hasT.has(`${id}|${level}|both|full`);
  const entriesByPage = new Map();
  for (const r of T.rows) for (const so of r.shownOn || []) {
    if (!entriesByPage.has(so.page)) entriesByPage.set(so.page, []);
    entriesByPage.get(so.page).push({ row: r, so });
  }
  const roleOf = e => e.so.role || 'result';
  const visible = row => !Array.isArray(row.visibleTo) || !row.visibleTo.length || row.visibleTo.includes('phys');
  const byOrder = (a, b) => (a.so.order ?? 0) - (b.so.order ?? 0);
  const isOpen = id => status(id) === 'open';
  const keyOf = (sec, level) => {
    const k = sec.key;
    if (typeof k === 'number' && k >= 0) return { n: k, list: null };
    if (Array.isArray(k)) return { n: level === 'learner' ? KEY_RESULTS.learner : null, list: k };
    if (k && typeof k === 'object') return { n: typeof k[level] === 'number' ? k[level] : KEY_RESULTS[level], list: Array.isArray(k.rows) ? k.rows : null };
    return { n: KEY_RESULTS[level], list: null };
  };
  function sectionChains(def, level) {
    const all = (entriesByPage.get(def.route) || []).filter(e => visible(e.row));
    const heroId = def.hero && def.hero.row && byId.get(def.hero.row) && visible(byId.get(def.hero.row)) ? def.hero.row : null;
    const parts = Array.isArray(def.parts) ? def.parts.filter(p => p && p.id) : [];
    const partOf = new Map();
    for (const p of parts) for (const id of p.sections || []) if (!partOf.has(id)) partOf.set(id, p);
    for (const sec of def.sections || []) if (sec && sec.part && !partOf.has(sec.id)) { const p = parts.find(x => x.id === sec.part); if (p) partOf.set(sec.id, p); }
    const placementOf = sec => {
      const p = partOf.get(sec.id);
      if (p && p.id === 'open') return 'open';
      if (p && p.id === 'drawer') return 'reference';
      return sec.id === 'needs' || sec.inputs === true ? 'inputs' : 'body';
    };
    const introEntries = all.filter(e => e.so.section === 'intro');
    const claimed = new Set(introEntries);
    const groups = [];
    for (const sec of (def.sections || []).filter(x => x && x.id)) {
      if (sec.id === 'intro') continue;
      const key = (sec.query && sec.query['shownOn.section']) || sec.id;
      const entries = all.filter(e => !claimed.has(e) && (e.so.section === key || e.so.section === sec.id));
      entries.forEach(e => claimed.add(e));
      groups.push({ sec, id: sec.id, entries });
    }
    const extra = new Map();
    for (const e of all) if (!claimed.has(e)) { if (!extra.has(e.so.section)) extra.set(e.so.section, []); extra.get(e.so.section).push(e); }
    for (const [sid, entries] of extra) groups.push({ sec: { id: sid }, id: sid, entries });
    const has = id => hasText(id, level);
    const firstOf = (list, role) => { const e = list.find(x => roleOf(x) === role && has(x.row.id)); return e ? e.row.id : null; };
    const io = [...introEntries].filter(e => e.row.id !== heroId).sort(byOrder);
    const out = [];
    const introLead = def.intro && def.intro.lead && byId.get(def.intro.lead) && has(def.intro.lead) ? def.intro.lead : firstOf(io, 'lead');
    const glance = io.filter(e => roleOf(e) === 'result' && has(e.row.id)).map(e => e.row.id).filter(id => !isOpen(id));
    out.push({ sid: 'top', lead: introLead, keys: [...(heroId && has(heroId) ? [heroId] : []), ...glance] });
    for (const g of groups) {
      const sec = g.sec;
      if (placementOf(sec) !== 'body') continue;
      const entries = g.entries.filter(e => e.row.id !== heroId);
      const inOrder = [...entries].sort(byOrder);
      const lead = sec.lead && inOrder.some(e => e.row.id === sec.lead) && has(sec.lead) ? sec.lead : firstOf(inOrder, 'lead');
      const learnerRows = level === 'learner' ? inOrder.filter(e => roleOf(e) === 'learner' && has(e.row.id)).map(e => e.row.id) : [];
      const body = [];
      for (const e of inOrder) {
        const id = e.row.id, role = roleOf(e);
        if (['lead', 'caption', 'learner', 'next', 'evidence', 'detail', 'note'].includes(role)) continue;   // a note (the reserved section top-notes) is a pointer, not a result
        if (!has(id) || isOpen(id)) continue;
        body.push(id);
      }
      const k = keyOf(sec, level);
      const inList = k.list ? new Set(k.list) : null;
      const keyPool = inList ? body.filter(id => inList.has(id)) : body;
      const restPool = inList ? body.filter(id => !inList.has(id)) : [];
      const pool = [...learnerRows, ...keyPool, ...restPool];
      const n = level === 'learner' ? (k.n ?? KEY_RESULTS.learner) : (k.n == null ? keyPool.length : k.n);
      out.push({ sid: g.id, lead, keys: pool.slice(0, n) });
    }
    return out;
  }
  const result = { research: [], learner: [], skipped: [] };
  for (const def of T.pages) {
    if (STORYLESS(def.route)) { result.skipped.push(def.route); continue; }
    for (const level of ['research', 'learner']) {
      const secs = sectionChains(def, level);
      const withKeys = secs.filter(c => c.keys.length);
      if (!withKeys.length) continue;
      const links = withKeys.flatMap(c => c.keys.filter(id => !NEUTRAL_STATUS.has(status(id))).map(id => ({ id, sid: c.sid, status: status(id) })));
      const broken = links.filter(l => !OK_STATUS.has(l.status));
      const lead = def.intro && def.intro.lead && byId.get(def.intro.lead) ? def.intro.lead : (secs.find(c => c.sid === 'top') || {}).lead || null;
      result[level].push({ route: def.route, lead, sections: withKeys.length, sectionsBroken: withKeys.filter(c => c.keys.some(id => !NEUTRAL_STATUS.has(status(id)) && !OK_STATUS.has(status(id)))).length, links: links.length, broken, complete: broken.length === 0 });
    }
  }
  return result;
}

// ============================================================================================================================ routes (shared wording)
// A note writes "@br" for the bit route "bitrule_A.py ...": the same engine is named the same way everywhere.
const ROUTE = {
  // the bit rule (the engine side): short name in the tables, full description in the legend of section 10
  br: 'bitrule_A.py BR(eps)',
  brjs: 'engines/bitrule.js',
  cliff: 'bitcliff.py Alg + regular_matrix',
  clc: 'clC.py Alg',
  f2: 'f2lib.py (F2 quadrics, Schreier-Sims)',
  forms: 'gravity_selfcheck.py Forms/Lie/Grav with b1lib.py',
  pga: 'forque_selfcheck.py Alg(d), pgadyn_selfcheck.py',
  liealg: 'equations_selfcheck.py, yangmills_selfcheck.py',
  page: 'the page script (own bit rule, exact)',
  // the standard route (the side that never touches the engine)
  enum: 'exhaustive enumeration, no engine',
  numpy: 'numpy matrices of an explicit representation',
  roots: 'root-system enumeration in doubled integer coordinates (check_T13.py model)',
  christoffel: 'metric and Christoffel symbols',
  textbook: 'the textbook formula in exact rationals',
};
const ROUTE_LEGEND = {
  br: 'checks/researchers_checks/bitrule_A.py: the reference bit rule, blades as masks, multivectors as dicts, exact integers or Fractions, any cell, no import from the atlas',
  brjs: 'engines/bitrule.js (bladeMul, cell, clockOf): the kernel of the pages, tested against bitrule_A.py',
  cliff: 'checks/selfcheck/steps15_17/bitcliff.py: Alg(p,q,r), regular matrices, rank, a pure-Python Schreier-Sims',
  clc: 'checks/researchers_checks/clC.py: Alg with exact Fractions, exp_mv, det_frac, int_mat',
  f2: 'checks/researchers_checks/f2lib.py: F2 vectors, the label form of Cl(p,q), quadric counts, transvections, Schreier-Sims',
  forms: 'checks/selfcheck/gravity_selfcheck.py (Forms, Lie, Grav: exact Fractions, differential forms as the bit rule with null generators) with checks/selfcheck/gravity/b1lib.py (head, chk, finish, frames, jets)',
  pga: 'checks/selfcheck/forque_selfcheck.py (Alg(d, sp, eps_sq): Cl(d,0,1) as the bit rule) and checks/selfcheck/pgadyn_selfcheck.py (rigid bodies from the segment to the tesseract)',
  liealg: 'checks/selfcheck/equations_selfcheck.py (bivector commutators, so(p,q)) and checks/selfcheck/yangmills_selfcheck.py (gauge algebra of Cl(0,m))',
  page: 'the page scripts of checks/selfcheck/*_selfcheck.py, each with its own copy of the bit rule and exact Fractions',
  enum: 'integer enumeration with no engine and no sign loop of the bit rule',
  numpy: 'explicit matrices (Pauli, Dirac, octonion, Gell-Mann) in numpy; no bit product',
  roots: 'the doubled integer coordinates of D8+ (240 roots of E8) as in checks/researchers_checks/check_T13.py',
  christoffel: 'the metric from the frame, Christoffel symbols, the textbook curvature (numpy or exact)',
  textbook: 'the textbook formula, evaluated in exact rationals',
};
const expand = s => (typeof s === 'string' ? s.replace(/@(\w+)/g, (m, k) => { if (!(k in ROUTE)) throw new Error('unknown route key @' + k); return ROUTE[k]; }) : s);

// ============================================================================================================================ the notes
/** n(cost, work, wrongIsFalse, lead, w, bit, std, extra) — one note of the list; see the legend in the file */
const n = (cost, work, fw, lead, w, bit, std, extra = {}) => ({ cost, work, fw, lead, w, bit, std, ...extra });
/** s(skip, why) — a row that is in a class by its status but not on the ranked list, with the reason */
const s = (skip, why) => ({ skip, why });

const WORK = {
  wire: 'the check exists and passes; the row only has to name it (a data edit, no new computation)',
  extend: 'a check covers part of the sentence; add the missing lines to it',
  new: 'a new script: bit route, standard route, controls',
  derive: 'a written derivation first, then the finite check that pins it',
  edit: 'the row, not the mathematics, is to change (status, kind, wording)',
  source: 'the answer lies in a text the package does not hold',
};
const SKIP = {
  retag: 'a reading in the words of the row; no check can decide it; its kind should be reading',
  source: 'the answer lies in a text the package does not hold, or the question is "is this known?"',
  research: 'an open question with no known finite computation that decides it',
  scope: 'a stated limit of the Atlas (what is not built); closing it is building a feature, not running a check',
  reading: 'a name or an interpretation that the row marks as ours and open; there is nothing to compute',
  mislabel: 'the sentence is computed or textbook, but the row carries the status of the question around it; the fix is a data edit',
  plan: 'a note of work to do, not a statement',
  lab: 'taken by the prime lab (its own brief, $SP/v16_briefs/agent_prime_lab.md); listed there, not briefed again here',
  b3: 'taken by the third batch (R7-6); its script is in checks/selfcheck/gravity/ and its run is recorded when the ledger is applied',
  input: 'an input of the model (a choice, or a pointer to a source); it is not a statement a check can prove',
};

// ============================================================================================================================ ranking
function rankItems(M, N) {
  const items = [];
  const take = (arr, cls) => { for (const it of arr) { const nt = it.note; if (nt && !nt.skip && nt.cost) items.push(it); } };
  take(M.cited, 'cited'); take(M.oursClaims, 'ours'); take(M.openAll, 'open'); take(M.candYes, 'cand');
  const key = it => [it.note.fw ? 0 : 1, ORDER_COST[it.note.cost], -it.nDep];
  items.sort((a, b) => { const ka = key(a), kb = key(b); for (let i = 0; i < ka.length; i++) if (ka[i] !== kb[i]) return ka[i] - kb[i]; return a.id < b.id ? -1 : a.id > b.id ? 1 : 0; });
  items.forEach((it, i) => { it.rank = i + 1; });
  return items;
}

/** the leads in the order of the best-ranked item they hold */
function leadOrder(ranked) {
  const seen = [];
  for (const it of ranked) { const l = it.note.lead; if (l && l !== 'PRIME' && !seen.includes(l)) seen.push(l); }
  return seen;
}

// ============================================================================================================================ validation
const NOT_SHIPPED = new Set(['peirce_test.py', 'witt_test.py', 'z2_test.py', 'family_test.py']);   // named by rows, absent from checks/
const EXTERNAL = new Set(['ganja.js', 'mutate_pkg.py', 'scan_words.mjs', 'one_claim_v15.mjs']);   // a library named as the second route of a script, and tools kept outside the repository
const SEARCH_DIRS = ['', 'checks', 'checks/selfcheck', 'checks/selfcheck/proofs', 'checks/selfcheck/gravity', 'checks/selfcheck/bridges', 'checks/selfcheck/reports', 'checks/selfcheck/steps15_17',
  'checks/researchers_checks', 'checks/reports/furey', 'checks/reports/baez', 'checks/reports/category', 'checks/reports/hestenes', 'checks/reports/pumplun',
  'engines', 'engines/explore', 'content', 'tools', 'tests', 'docs', 'src/figures'];
function fileExists(token, root) {
  if (NOT_SHIPPED.has(token) || EXTERNAL.has(token)) return true;
  for (const d of SEARCH_DIRS) if (fs.existsSync(path.join(root, d, token))) return true;
  return false;
}
const FILE_RE = /[A-Za-z0-9_][A-Za-z0-9_./-]*\.(?:py|mjs|js|json)\b/g;

function validate(M, T, N, root = ROOT) {
  const problems = [];
  const P = m => problems.push(m);
  const need = (cls, items, notes) => {
    const ids = new Set(items.map(i => i.id));
    for (const it of items) if (!it.note) P(`unannotated ${cls} ${it.id}`);
    const asRow = new Set((M.candRows || []).map(c => c.id));   // a candidate that became a row keeps its note as a record
    for (const id of Object.keys(notes)) if (!ids.has(id) && !(M.closed && M.closed.has(id)) && !asRow.has(id)) P(`orphan note: ${id} is not in class ${cls}`);
  };
  need('cited', M.cited, N.cited); need('ours', M.oursClaims, N.ours); need('open', M.openAll, N.open); need('cand', M.candYes, N.cand);
  const thmIds = new Set(M.thmGaps.map(t => t.id));
  for (const t of M.thmGaps) if (!t.note) P(`unannotated theorem ${t.id}`);
  for (const id of Object.keys(N.theorems)) if (!thmIds.has(id)) P(`orphan note: ${id} is not a theorem gap`);
  const all = [...M.cited, ...M.oursClaims, ...M.openAll, ...M.candYes, ...M.thmGaps];
  for (const it of all) {
    const nt = it.note; if (!nt) continue;
    if (nt.skip) {
      if (!(nt.skip in SKIP)) P(`${it.id}: unknown skip class ${nt.skip}`);
      if (nt.why !== undefined && nt.why.length < 8) P(`${it.id}: a reason must say something`);
      if (it.cls === 'cited') P(`${it.id}: a cited row cannot be skipped`);
      continue;
    }
    if (it.cls === 'thm') continue;
    if (!(nt.cost in ORDER_COST)) P(`${it.id}: cost must be S, M or L`);
    if (!(nt.work in WORK)) P(`${it.id}: unknown work kind ${nt.work}`);
    if (typeof nt.fw !== 'boolean') P(`${it.id}: false-if-wrong must be true or false`);
    for (const f of ['w', 'bit', 'std']) if (typeof nt[f] !== 'string' || nt[f].length < 4) P(`${it.id}: note field ${f} is empty`);
    if (nt.lead && nt.lead !== 'PRIME' && !(nt.lead in PACKS)) P(`${it.id}: unknown group of work ${nt.lead}`);
    if (nt.work === 'wire' && !(nt.via && nt.via.length)) P(`${it.id}: a wire note names the script it wires to (via)`);
    if (it.cls === 'cand' && nt.fw) P(`${it.id}: a candidate is not printed, so a wrong one cannot be false as printed`);
    for (const v of nt.via || []) {
      if (!fs.existsSync(path.join(root, 'checks', v))) P(`${it.id}: via ${v} is not a file of checks/`);
      else if (!M.runIdx.passes(v)) P(`${it.id}: via ${v} has no passing recorded run`);
    }
    for (const f of ['w', 'bit', 'std']) for (const tok of expand(nt[f]).match(FILE_RE) || []) if (!fileExists(tok, root)) P(`${it.id}: ${f} names ${tok}, which is not in the repository`);
    if (!cellOf(it)) P(`${it.id}: the cell of the bit route is not named (rows.json cells, or CELL_CAND / CELL_ROW)`);
  }
  // the order of the leads
  const ranked = rankItems(M, N);
  const order = leadOrder(ranked);
  const want = LEAD_ORDER.filter(k => order.includes(k));   // a lead whose statements are all closed (proved) is no longer on the ranked list
  // the briefs are numbered by the rank their statements had when they were written; after closures the rank order may differ, the set of leads may not
  // a live lead (two or more ranked statements) without a brief is reported as a problem only through --check-leads; the file lists them in §3
  const liveLeads = new Set(order.filter(k => ranked.filter(it => it.note && it.note.lead === k).length >= 2));
  M.leadsWithoutBrief = [...liveLeads].filter(k => !LEADS[k]);
  for (const k of want) if (!LEADS[k]) P(`lead ${k} has no entry in LEADS`);
  // counts must add up
  const c = counts(M, N);
  if (c.cited.total !== M.cited.length) P('cited count');
  if (c.ours.core + c.ours.retag !== M.oursClaims.length) P('ours count does not add up');
  const openSum = c.open.computable + Object.values(c.open.skipped).reduce((a, b) => a + b, 0);
  if (openSum !== M.openAll.length) P(`open count does not add up (${openSum} of ${M.openAll.length})`);
  return problems;
}

// ============================================================================================================================ counts
function counts(M, N) {
  const isSkip = it => !!(it.note && it.note.skip);
  const c = { cited: { total: M.cited.length, fw: M.cited.filter(i => i.note && i.note.fw).length }, ours: {}, open: { skipped: {} }, cand: {}, chains: {} };
  c.ours.all = M.oursAll.length; c.ours.readings = M.oursReadings.length; c.ours.claims = M.oursClaims.length;
  c.ours.skipped = {}; for (const it of M.oursClaims) if (isSkip(it)) c.ours.skipped[it.note.skip] = (c.ours.skipped[it.note.skip] || 0) + 1;
  c.ours.retag = M.oursClaims.filter(isSkip).length; c.ours.core = c.ours.claims - c.ours.retag;
  c.open.total = M.openAll.length; c.open.computable = M.openAll.filter(i => i.note && !i.note.skip).length;
  for (const it of M.openAll) if (isSkip(it)) c.open.skipped[it.note.skip] = (c.open.skipped[it.note.skip] || 0) + 1;
  c.cand.all = M.candAll.length; c.cand.rows = M.candRows.length; c.cand.yes = M.candYes.length; c.cand.partly = M.candAll.filter(x => x.checkable === 'partly').length; c.cand.no = M.candAll.filter(x => x.checkable === 'no').length;
  c.cand.skipped = {}; for (const it of M.candYes) if (isSkip(it)) c.cand.skipped[it.note.skip] = (c.cand.skipped[it.note.skip] || 0) + 1;
  c.cand.nSkipped = M.candYes.filter(isSkip).length;
  for (const level of ['research', 'learner']) {
    const a = M.chains[level];
    c.chains[level] = { pages: a.length, complete: a.filter(x => x.complete).length, incomplete: a.filter(x => !x.complete).length,
      links: a.reduce((s, x) => s + x.links, 0), broken: a.reduce((s, x) => s + x.broken.length, 0) };
  }
  c.ranked = M.cited.length + M.oursClaims.filter(i => !isSkip(i)).length + M.openAll.filter(i => !isSkip(i)).length + M.candYes.filter(i => !isSkip(i)).length;
  return c;
}

// ---------------------------------------------------------------------------------------------------------------------------- A. cited (31)
// Why these rows are cited: the v15 flag "checked" survived, but the evidence names nothing that ran and passed (the four exploratory printouts of the
// Furey model, shipped nowhere; or a check id with no script; or nothing). For 29 of the 31 the check that decides the sentence is already in
// checks/ and its last recorded run passed: the work is to read the sentence against the script and to name the script. The note says which.
const FUREY_VIA = ['run_all.py'];
const CITED = {
  'FUR-001': n('S', 'wire', true, 'FUREY',
    'six real ranks (2,6,4,2,1,1), 62 + 194, complex ranks (1,3,2,1,1), 16 + 48, centraliser dimensions (32,20,8,2,1), dim Delta_SM = 31, Tr Y = 3 over 8: run_all.py asserts all of it; name run_all.py and ship model.py beside it',
    'second route: the 16 axes as joint eigenspaces of the seven Fano-line blades of Cl(0,8) in @br; block projectors as blade sums (grades 0, 4, 8), rank = axes in the block',
    'run_all.py: octonion model of model.py, 16 x 16 matrices (numpy allclose); furey_papers_check.py A1-A5 is a third',
    { via: FUREY_VIA }),
  'FUR-001b': n('S', 'extend', true, 'FUREY',
    'the same sentence plus the centraliser dimensions (32,20,8,2,1) and "the fusion of the two rank-1 blocks is derived from omega": run_all.py asserts 32, 20, 8 and the omega derivation; the values 2 and 1 for C and R are written in the script, not computed (two more cdim calls)',
    'as FUR-001', 'as FUR-001', { via: FUREY_VIA }),
  'FUR-002': n('S', 'extend', true, 'FUREY',
    'ten edges with their irreps; Q_L 1, u_R 1, doublet 3, triplet 2, charged singlet 2, neutral 1; 24C = 16C + 8C; run_all.py asserts the edges, the Standard Model matches and the 24; the multiplicity tally needs one line',
    '@br: edge = Q_a End Q_b, hypercharge difference y_a - y_b from five projectors, counted over the ten pairs',
    'run_all.py edge table (numpy ranks of Q_a X Q_b over a basis of End_C(V))',
    { via: FUREY_VIA }),
  'FUR-002b': n('S', 'extend', true, 'FUREY',
    'as FUR-002, plus sum 2 n_i n_j = 48 over the ten edges, maximum 2*3*2 = 12 and "only differences y_i - y_j matter" (run_all.py asserts the 48, the 12 and the ad_Y action piece by piece)',
    'as FUR-002', 'as FUR-002', { via: FUREY_VIA }),
  'FUR-004': n('S', 'extend', true, 'FUREY',
    'omega\' = -R_e7 equals omega D with D = -1 on exactly the axes {0,3,8,11}: asserted in run_all.py; "a Fano-line blade has eight -1 signs" follows from trace zero of an involution on 16 axes and needs one assert; the Z2 parallel was run by family_test.py (not shipped; its recorded run passed)',
    '@br: D as a diagonal involution on the 16 axes, compared with the eight-sign Fano-line blades', 'run_all.py (numpy, om2 = diag2(-Rk), D = solve(om, om2))',
    { via: FUREY_VIA }),
  'FUR-004b': n('S', 'extend', true, 'FUREY',
    'as FUR-004; the second sentence "no single torus generator relates omega and omega\'" is the eight-sign comparison',
    'as FUR-004', 'as FUR-004', { via: FUREY_VIA }),
  'RSN-002': n('S', 'wire', true, 'FUREY',
    'the ranks, 62 + 194, omega swapping the two rank-1 blocks (M8(C)), the six edges of one generation (Q_L 6, u_R 3, d_R 3, L 2, e_R 1, nu_R 1), the four of replica type (8) and the largest edge (12): run_all.py',
    'as FUR-001', 'as FUR-001', { via: FUREY_VIA }),
  'RSN-003': n('S', 'wire', true, 'FUREY',
    'Fig. 1 labels against the Peirce edges (furey_papers_check.py F1-F4), one set plus 8C, two sets with every cell doubled, End(V) = 128C (16 + 48 + 64, 32 exotic), 5,582 admissible blocks, three sets first at 14C (threegen_selfcheck.py, furey_papers_check.py N1-N2)',
    'threegen_selfcheck.py exact combinatorics over the admissible blocks',
    'furey_papers_check.py N1: a fast recount on 300 random structures',
    { via: ['selfcheck/furey_papers_check.py', 'selfcheck/threegen_selfcheck.py'] }),
  'MAP-007': n('S', 'wire', true, 'FUREY',
    'the 30 checks of furey_papers_check.py (A1-A5, R1-R11, T1-T5, F1-F4, C1-C2, P1, N1-N2), the board count and the 14 complex dimensions: name the two scripts',
    'furey_papers_check.py on the octonion table', 'N1 recount; reports/furey/mutate_furey.py (44 of 44 caught)',
    { via: ['selfcheck/furey_papers_check.py', 'selfcheck/threegen_selfcheck.py'] }),
  'MAP-008': n('S', 'edit', false, 'FUREY',
    'the line promises "exact tables" and states no number; dictionary_selfcheck.py holds the tables (Cl(0,8) as 16 x 16 matrices, hypercharges and charges of every state): name it or reword the line as a description',
    'dictionary_selfcheck.py: Cl(0,8) generators, blades as faces of the 7-simplex, prime names',
    'the same script against the Standard Model charge table (textbook, recalled)',
    { via: ['selfcheck/dictionary_selfcheck.py'] }),
  'MAP-010': n('S', 'wire', true, 'FUREY',
    'Peirce blocks (2,6,4,2,1,1) and (1,3,2,1,1), Y and Q from five projectors, the ten edges, the sixteen axes (FUR-003): run_all.py and furey_papers_check.py',
    'as FUR-001', 'as FUR-001', { via: [...FUREY_VIA, 'selfcheck/furey_papers_check.py'] }),
  'PAG-014': n('S', 'wire', true, 'FUREY',
    'the explicit algebra from the octonion table, the dimension ladders, the 20 cells of her Fig. 1 against the Peirce edges (30 checks): furey_papers_check.py',
    'furey_papers_check.py A-, R-, F-groups', 'N1 recount', { via: ['selfcheck/furey_papers_check.py'] }),
  'PAG-015': n('S', 'wire', true, 'FUREY',
    'one complete set, two with every cell doubled, three sets need at least 14 complex dimensions: threegen_selfcheck.py and furey_papers_check.py N1-N2',
    'threegen_selfcheck.py', 'furey_papers_check.py N1 (300 random structures)', { via: ['selfcheck/threegen_selfcheck.py', 'selfcheck/furey_papers_check.py'] }),

  'LNC-021': n('S', 'wire', true, 'CATW',
    'the normal of a null hypersurface spans the radical of the tangent algebra Cl(0,n-2,1) (n-2 spacelike, one null), n = 2..6 (check_T18.py, parts A and E); e0 of Cl(3,0,1) squares to 0 (projective_selfcheck.py)',
    '@br: radical of the induced form, exact rank', 'check_T18.py: random metrics of every signature, radical = g^-1 N',
    { via: ['researchers_checks/check_T18.py', 'selfcheck/projective_selfcheck.py'] }),
  'LNC-044': n('S', 'wire', true, 'CATW',
    'Kac type of E_n: finite to n = 8, affine at 9, hyperbolic only at 10, Lorentzian from 10; catw.P5 of lens_cat_check.py (Bareiss determinant 9 - n, exact inertia)',
    'lens_cat_check.py P5 (exact integers)', 'check_T10.py: determinants and inertia n = 3..20 by a second elimination',
    { via: ['selfcheck/reports/lens_cat_check.py'] }),
  'LNC-049': n('S', 'wire', true, 'CATW',
    'mod 2 the null root of E_9 spans the radical of E_9/2E_9 and the radical of the label form of Cl(9,0) is the full label; catw.P6 of lens_cat_check.py computes both radicals',
    'lens_cat_check.py P6 (exact integers, F2 rank)', 'check_T9.py (a): the isometry E_n/2E_n -> label form of Cl(n,0)',
    { via: ['selfcheck/reports/lens_cat_check.py', 'researchers_checks/check_T9.py'] }),

  'MAP-005': n('S', 'wire', true, 'STEPS',
    'the Lorentz force as the grade-1 part of F u in 2, 3 and 4 space dimensions, the circle, hyperbola, drift frame, invariants, E parallel B, point charge, light wave (9 exact rows) and the five RK4 rows: the charges block of maxwell_selfcheck.py',
    '@page (maxwell_selfcheck.py, exact polynomials)', 'closed forms in the script (cyclotron radius, hyperbolic motion, ExB drift); sol_maxwell_media.py bd.sol.14-17 is the independent bridge',
    { via: ['selfcheck/maxwell_selfcheck.py'] }),
  'MAP-011': n('S', 'edit', false, 'STEPS',
    'the line describes a page ("the same cube seen inside out, from its even half, and as a root series") and states nothing a check decides; make it a meta line, or wire it to the mirrors and shapes scripts it summarises',
    'mirrors_selfcheck.py (corners, even corners, E8 roots from the 8-demicube)', 'mirrors_matrix_check.py',
    { via: ['selfcheck/mirrors_selfcheck.py'] }),
  'MAP-016': n('S', 'wire', true, 'STEPS',
    'two bivectors anticommute exactly when they share one index; the commutator is +-2 times the bivector on the symmetric difference: part A of equations_selfcheck.py (so(p,q) from the bit product)',
    '@liealg', 'dirac_matrix_check.py: the same map against 4 x 4 complex gammas (checks.json independentRoute: yes)',
    { via: ['selfcheck/equations_selfcheck.py'] }),
  'MAP-018': n('S', 'wire', true, 'STEPS',
    'the current psi gamma0 psi~ sources grad F = eX; the complex structure J exists from n = 3 (counts 0,0,1,3,6); (2n+1)*2^(n-1) terms: coupling_selfcheck.py',
    '@page (coupling_selfcheck.py)', 'coupling_matrix_check.py (independent: yes)', { via: ['selfcheck/coupling_selfcheck.py'] }),
  'MAP-019': n('S', 'wire', true, 'STEPS',
    'gauge algebra = bivectors of Cl(0,m); Bianchi, first-order covariance and conservation exact; m = 2 is Maxwell: yangmills_selfcheck.py',
    '@liealg', 'yangmills_matrix_check.py (independent: yes)', { via: ['selfcheck/yangmills_selfcheck.py'] }),
  'MAP-020': n('S', 'wire', true, 'STEPS',
    'Psi = sum Psi_{S,T}, bivectors acting by left multiplication on the internal blade, the current j^a conserved on shell: matter_selfcheck.py',
    '@page (matter_selfcheck.py)', 'matter_matrix_check.py (independent: yes)', { via: ['selfcheck/matter_selfcheck.py'] }),
  'MAP-021': n('S', 'wire', true, 'STEPS',
    'R = d omega + 1/4 [omega, omega], T = de + omega e, Bianchi, the Einstein form; one extra generator gives so(1,n) or so(2,n-1): gravity_selfcheck.py and the ladder of projective_selfcheck.py',
    '@forms', 'gravity_matrix_check.py (algebra only); the 66 scripts of selfcheck/gravity/ are standard routes',
    { via: ['selfcheck/gravity_selfcheck.py', 'selfcheck/projective_selfcheck.py'] }),
  'MAP-024': n('S', 'wire', true, 'STEPS',
    'M\' = -MB/2, P = I[B], P\' = F; the 41-row translation matrix (27 agree, 9 after a small adjustment, 5 not checked), the tennis-racket rate, and the law of motion with space squares -1 (the script runs sq = [0,-1,..,-1] in d = 2, 3): forque_selfcheck.py and forque_matrix_check.py',
    '@pga', 'forque_matrix_check.py: numpy, no bit-mask product, Newton-Euler by RK4 (3 negative controls)',
    { via: ['selfcheck/forque_selfcheck.py', 'selfcheck/forque_matrix_check.py'] }),
  'MAP-025': n('S', 'wire', true, 'STEPS',
    'Roelfs-Eelbode-De Keninck: labels, master idempotent, pointors; 30 rows (22, 2, 6); four kinds of i; the four readings stay ours: spin_selfcheck.py',
    '@page (spin_selfcheck.py)', 'none in the script (checks.json: independentRoute no); the readings need none',
    { via: ['selfcheck/spin_selfcheck.py'] }),
  'MAP-027': n('S', 'wire', true, 'STEPS',
    'M\' = -MB/2 and B\' = A^-1 (F + 1/2 [B, A(B)]) from a segment to orbits: 56 rows, 110 exact claims (pgadyn_selfcheck.py); the timings are measurements of one run, not statements to prove',
    '@pga', 'ganja.js fixture (R rows) and g1/g2/g4 of selfcheck/gravity/ (independentRoute: partly)',
    { via: ['selfcheck/pgadyn_selfcheck.py'] }),
  'RSN-005': n('S', 'wire', true, 'STEPS',
    'M\' = -M B_b/2, P = I[B], F = f.Q and P\' = F <=> B\' = I^-1[B x I[B] + F] as exact series; the 41-row matrix; numpy 4 x 4 matrices against Newton-Euler',
    '@pga', 'forque_matrix_check.py (numpy RK4 against Newton-Euler)',
    { via: ['selfcheck/forque_selfcheck.py', 'selfcheck/forque_matrix_check.py'] }),
  'RSN-008': n('S', 'wire', true, 'STEPS',
    'one extra generator of square 0, -1, +1 gives Euclid, elliptic, hyperbolic (space squares -1); Poincare, de Sitter, anti-de Sitter on the Lorentz base; PGA embeds in the null-pair algebra: the ladder and the null-pair blocks of projective_selfcheck.py',
    '@page (projective_selfcheck.py, imports mirrors_selfcheck.py)', 'projective_matrix_check.py; h5l_conformal.py and h3_sign_chain.py of selfcheck/gravity/',
    { via: ['selfcheck/projective_selfcheck.py'] }),
  'RSN-018': n('S', 'extend', true, 'CATW',
    'Riemann n^2(n^2-1)/12, Ricci n(n+1)/2, Weyl first at n = 4 (20 = 10 + 10): gravity_selfcheck.py counts; B^B of a bivector square lives in Lambda^4 (check_T17.py); the clause "exactly the space the first Bianchi identity removes from Sym^2(Lambda^2)" is the computation of CAND-087 (the Bianchi map, exact ranks for n = 2..8): one script for both',
    '@forms (curvature_space, counts); @br for Lambda^4', 'check_T17.py (own helpers): B^2 has grades 0 and 4 only, B^B = 0 iff rank <= 2',
    { via: ['researchers_checks/check_T17.py', 'selfcheck/gravity_selfcheck.py'] }),
  'RSN-020': n('S', 'wire', true, 'CATW',
    'Schwarzschild and the Ellis wormhole both have g^rr = 0 at the surface of interest and only one is null: the three g^rr forms at five radii and the Ellis throat in check_T18.py; null_selfcheck.py',
    'null_selfcheck.py (own bit rule, exact)', 'check_T18.py: exact fractions at five radii; geo_lorentz.py',
    { via: ['researchers_checks/check_T18.py', 'selfcheck/null_selfcheck.py'] }),
  'RSN-025': n('S', 'wire', true, 'STEPS',
    'grad F = J with F a bivector in n = k + d generators, grade-1 and grade-3 equations, grad grad F = box F and charge conservation, the Lorentz force as the grade-1 part of F u: maxwell_selfcheck.py',
    '@page (maxwell_selfcheck.py)', 'sol_maxwell_media.py bd.sol.14-17 (independent bridge)', { via: ['selfcheck/maxwell_selfcheck.py'] }),
};

// ---------------------------------------------------------------------------------------------------------------------------- B. ours, kind not "reading" (48)
// R7-8 lists the ours rows whose kind states something checkable. Read against their own words, 41 of the 48 are readings ("is ours", "our reading"):
// the split of a v15 line into a formal row and a "b" row gave the second the kind of the first. They are listed here, not ranked; the fix is the kind.
const OURS = {};
for (const id of ['ATL-001b', 'ATL-002b', 'ATL-006b', 'ATL-010b', 'ATL-017b', 'ATL-023b', 'GRV-010b', 'LNB-001b', 'LNB-005b', 'LNB-014f', 'LNB-015g', 'LNB-023f', 'LNB-023k',
  'LNB-024b', 'LNB-053f', 'LNB-055c', 'LNB-056c', 'LNB-057c', 'LNS-010e', 'LNS-012e', 'LNS-017f', 'LNS-019d', 'LNS-019g', 'LNS-022e', 'LNS-031b', 'MAP-001b', 'PAG-002b',
  'PRJ-001b', 'RSN-028c']) OURS[id] = s('retag');
OURS['GRV-001b'] = s('retag', 'the row says "(our reading)"; the plane-pair classes it reads (12 edges, 3 antipodes of the octahedron at n = 4) are counted by gravity_selfcheck.py and bridge_check.py bridge.D1');
OURS['LNB-010b'] = s('retag', 'the identification of the two lattices is called ours; the lattices themselves are checked by baez.T1a, baez.T1b and baez.E3a');
OURS['LNB-016g'] = s('retag', 'the split of each rung is a computation that baez.E1a-E2d checked (a passing run); what is called ours is the reading of the ladder as a generation built rung by rung');
OURS['LNB-017e'] = s('retag', 'the tie to the triangulation note is called ours; the enumeration for the stated embedding is checked (baez.E3a-E3d), other embeddings are the open row LNB-045');
OURS['LNB-026'] = s('retag', 'a dead end (shared numbers are no evidence without a mechanism); nothing to compute beyond the matches baez.O3b, O3e and O3i already list');
OURS['LNB-026c'] = s('retag', 'the open example of the same dead end; the question behind it (real 10 against complex 10) is the research row LNB-022f');
OURS['LNB-058'] = s('retag', 'the learner line of LNB-026; no formula, no check');
OURS['LNB-058b'] = s('retag', 'the learner line of LNB-026c; no formula, no check');
OURS['LNS-011d'] = s('retag', 'a statement about what the lecture notes contain (no Clifford algebra between chapters 12 and 15) and a suggestion; the notes are not in the package');
OURS['LNS-014d'] = s('retag', 'a statement about what his equations (48)-(50) are, and a reading of the signs; the frozen 1+1 model is checked, the rest is source and reading');
OURS['LNS-015e'] = s('retag', 'the naming of base and fibre is called ours; the commutant statements it leans on are checked by fibre.G2 and G3 and by check_T2.py and check_T4.py');
OURS['LNS-016c'] = s('retag', 'the row says the reading "is not tested"; the isomorphism of the commutant is checked by fibre.G3a and G3e');
OURS['RSN-018b'] = s('retag', 'the row says "a reading, not a theorem"; the theorem half (B^B = b(B.B), dimensions) is CAND-087 on this list');
OURS['SPR-002'] = s('mislabel', 'a list of checked statements (Hooke, the Walsh spectrum of the cube, strain compatibility, circle-hyperbola-line, D^2 = n I) with passing evidence in spring_selfcheck.py, check_T17.py and check_T19.py, carried by ptype reading; changing the ptype lets the status compute');
// the four with a checkable core
OURS['LNB-029c'] = n('S', 'extend', true, 'CATW',
  'on the 3 and the 3bar of su(3) the symmetrised cubic Casimir d_abc T_a T_b T_c takes opposite values, an unsymmetrised cubic cannot tell them apart, and the Dynkin labels (1,0) and (0,1) do: exact on the Gell-Mann matrices',
  'baez_check.py H3: the generators a_i^+ a_j on the colour bits of the 32 labels; H3f already builds the Dynkin labels and the Casimirs per label',
  'numpy Gell-Mann matrices, d_abc from the anticommutators; Dynkin labels from the weights');
OURS['LNB-029d'] = n('S', 'wire', true, 'CATW',
  'on the 27 the stabiliser algebra of the gauge-group paper and the su(3)+su(2) of the E7 paper have different Casimir tables, so they are not conjugate: the statement of LNB-111, which baez.S2 and bzw.P2 check; name them',
  'baez_check.py S2: exact weight branching of the 27 under both subalgebras', 'lens_baez_check.py P2: the 27 by Casimir class from the explicit action of the gauge-group paper\'s Lemma 4',
  { via: ['selfcheck/reports/baez_check.py', 'selfcheck/reports/lens_baez_check.py'] });
OURS['LNS-013e'] = n('S', 'new', true, 'CATW',
  'a rotation of the coordinate frame in SO(1,3) takes a tensor supported on the 6 vertex cells (a plane paired with itself) to one with support on edge cells and antipodal cells: the split 6 + 12 + 3 is not invariant; exact at rational boosts',
  '@forms engine curvature tables (g2_weyl.py duality on the six plane labels) or @br on bivector pairs',
  'numpy: the 21 x 21 matrix of Sym^2 of the Lorentz transformation on Lambda^2, support read off after the change of frame');
OURS['SRC-003b'] = n('S', 'wire', true, 'CATW',
  'B_(k+1) = B_k x B_1: the label cube of the next level is the product with the 2-chain (the exponent doubles); mjc_comma.py counts the iterated arrow categories on six base categories; CAND-100 is the same identity for all n',
  'selfcheck/bridges/mjc_comma.py (bd.mjc.30-32: backtracking counts)', 'poset product by enumeration: (k+2)^n chains against the product formula (bd.mjc.3)',
  { via: ['selfcheck/bridges/mjc_comma.py', 'selfcheck/bridges/mjc_labels.py'] });
OURS['SRC-001b'] = s('retag', 'the first sentences are a verdict on a source (a dead end as written) and our quiver-form reading; the v3 correspondence is checked by bd.mjc.1, mjc.2, mjc.12 and bd.mjp.30 (sibling row SRC-001 computes proved)');

// ---------------------------------------------------------------------------------------------------------------------------- C. open (127)
// The 127 open rows, each with a verdict. computable: a finite computation can answer it (ranked). The others are not missing proofs.
const OPEN = {};
const skipAll = (ids, kind, why) => { for (const id of ids) OPEN[id] = why ? s(kind, why) : s(kind); };
// names and readings that the row itself calls ours and open
skipAll(['ATL-003b', 'ATL-005b', 'ATL-007b', 'ATL-008b', 'ATL-011b', 'ATL-013b', 'ATL-014d', 'ATL-015b', 'ATL-016b', 'ATL-018d', 'ATL-021b', 'PAG-006b', 'LNS-028c'],
  'reading');
skipAll(['MAP-034', 'MAP-035'], 'plan');
skipAll(['ATL-022b', 'ATL-024b', 'FUR-005', 'FUR-005b'], 'lab', 'the number 210, the odd primes and the prime names are checks P1-P8 of the prime lab; the rest of the row (the map from irreps to cells, continuous parameters) is research');
// computed or textbook sentences carried by a question row
OPEN['ATL-019'] = s('mislabel', 'the cell Cl(5,3) = M16(R) is a computed type (T4, groups_check.py ran); the row is open only by its ptype');
OPEN['ATL-022'] = s('mislabel', 'Cl(2,6) = M8(H) and the counts 70 and 1120 are computed (shapes_selfcheck.py ran); the row is open only by its ptype');
OPEN['LNB-034b'] = s('mislabel', 'the 4 + 7 + 4 grading of so(4,2) with ad D eigenvalues +1, 0, -1 is exact at n = 4 (h5l_conformal.py ran); the row is a question only by its kind');
OPEN['LNB-046b'] = s('mislabel', 'a note on how the papers are cited (equation numbers, no page numbers); it states nothing a check decides');
OPEN['LNS-028'] = s('mislabel', '"for quadratic P the first condition is the (k,d) map of F2" is computed (bridge.B1, qm.Q10); the row is a question by its kind');
OPEN['LNS-028b'] = s('mislabel', 'the null cone of det on M2(R) has signature (2,2) is textbook and checked (qm.Q10a, Q10b); the row is a question by its kind');
OPEN['PAG-034'] = s('mislabel', 'Gårding hyperbolicity is a textbook theorem (standard); the row is open by its kind pointer');
// stated limits of the Atlas
skipAll(['CPL-006', 'LAB-012', 'LAB-016', 'PAG-032', 'LNB-037', 'LNB-037b', 'LNC-076', 'LNP-004', 'LNS-023', 'LNS-024', 'LNS-025', 'LNS-026', 'LNS-036', 'LNS-036b', 'LNS-050',
  'LNS-057', 'LNS-068', 'LNS-069', 'LNS-076', 'LNS-103', 'MAT-006', 'PAG-016'],
  'scope');
// answers in a text we do not hold
skipAll(['FRQ-005', 'LNB-025e', 'LNB-040', 'LNB-044', 'LNB-046', 'LNC-054', 'LNC-069', 'LNC-077', 'LNC-078', 'LNC-079', 'LNC-082', 'LNC-083', 'LNC-085', 'LNC-088', 'LNC-097', 'LNC-098',
  'LNC-123', 'LNS-033b', 'LNS-045b', 'LNS-106', 'SPN-004', 'SPN-005'],
  'source');
// open mathematics or physics with no finite computation that decides it
skipAll(['ATL-019b', 'LNB-011d', 'LNB-022f', 'LNB-034', 'LNB-034c', 'LNB-036', 'LNB-036b', 'LNB-041', 'LNB-042', 'LNB-051', 'LNB-064', 'LNB-144', 'LNB-152', 'LNB-159', 'LNB-165',
  'LNC-076c', 'LNC-080', 'LNC-081', 'LNC-084', 'LNC-086', 'LNC-096', 'LNS-014e', 'LNS-029', 'LNS-038', 'LNS-039', 'LNS-046', 'LNS-047', 'LNS-049', 'PAG-012', 'SHP-005b'],
  'research');

// the 27 with a computable answer
OPEN['ATL-020b'] = n('S', 'new', true, 'SM16',
  'Tr T3^2 / Tr Q^2 over the 16 as an exact rational (3/8 expected); Tr Y over dim V = 3/8 on Furey\'s V (run_all.py asserts it); the count 4/17 of neutral paths: the three numbers the row sets side by side',
  'charges of the 16 from the five-bit labels (baez_check.py H2: Q = first weak bit - colour bits/3, T3 = (first - second weak bit)/2), Fractions',
  'textbook charge table of one generation, sums by hand; Tr Y on V from run_all.py');
OPEN['CPL-007'] = n('M', 'new', false, 'DIRAC',
  'for n = 5..8: Cl+(1,n-1) as N copies of the irreducible module; the commutant acts on the N-dimensional multiplicity space; follow the grade-5 part of the current psi gamma0 psi~ (CAND-069 supplies the structure)',
  '@cliff regular matrices of the even subalgebra, minimal left ideals by exact rank', 'numpy: the same ideals from explicit gamma matrices; coupling_matrix_check.py (the n = 5 case where X is not a vector)');
OPEN['GOS-003'] = n('M', 'new', false, 'EMB',
  'does End_R(V) = M16(R) with Furey\'s Peirce structure contain an sl(3) that commutes with Delta_SM and acts as the generation sl3 of E8 > E6 x A2: classify the su(3) representations on R^16 and test commutation with the centraliser',
  '@br: the 16-dimensional model of run_all.py as bit-rule matrices; the centraliser of Delta_SM from the Peirce projectors (fur_commutant.py: dimension 22)',
  'numpy: nullspace of the commutation conditions for the Gell-Mann images on R^16 (3 + 3bar + 10 singlets and the real forms)');
OPEN['RSN-004'] = OPEN['GOS-003'];
OPEN['GOS-006'] = n('S', 'derive', false, 'RANGE',
  'for an odd unimodular lattice L with characteristic vector k: k-perp/2k-perp is (L_even/2L, x.x/2 mod 2), which for L = I_(p,q) is the label form of the even part (CAND-101); check I_(p,q) for p + q <= 12 and every characteristic k of small norm',
  '@f2 label forms and mat_En_in_Cl1n.py (bd.mat.18 for E_n, n = 3..10)', 'integer lattice enumeration, Smith normal form (no engine)');
OPEN['INP-033'] = n('M', 'new', true, 'YM',
  'the stationarity of S = -1/4 <F F> - <A J> for so(m) in A gives D^mu F_(mu nu) = J_nu with the structure constants of the bit product; the abelian case is bd.phy.18 and 19',
  '@forms first_variation of b1_first_variation.py on the bivector algebra (Lagrange interpolation in eps), or phy_coupled_action.py widened to so(m)',
  'numpy: f_ab^c from the bit commutators; the Euler-Lagrange expression by the textbook formula, and a numerical variation at points (complex step)');
OPEN['INP-037'] = n('M', 'new', true, 'YM',
  'the Dirac action of Psi with the covariant derivative: its stationarity gives the matter equation E = 0 of matter_selfcheck.py and the Noether current of each generator is j^a, conserved on shell',
  '@forms first_variation on the charged spinor; matter_selfcheck.py E and j^a', 'matter_matrix_check.py (independent); numpy Euler-Lagrange by finite variation');
OPEN['MAT-005'] = n('M', 'new', false, 'YM',
  'the standard action of step 8 ties the kappa of D^mu F_(mu nu) = kappa j_nu to the g of D and fixes the sign of the source, as bd.phy.18 and 19 do for the abelian action; repeat for so(m), m = 3, 4',
  'as INP-033', 'as INP-033');
OPEN['YM-006'] = n('S', 'new', false, 'YM',
  'u(n) is the centraliser of a complex structure J in so(2n): dimension n^2 for n <= 6; su(3) inside g2 = Der(O) (bd.alg.17); so(6) = su(4) contains su(3); so(10) contains su(3)+su(2)+u(1)',
  '@br: bivectors of Cl(0,2n) commuting with a bivector J of square -1, exact rank', 'numpy: the commutant of the standard J in the vector representation; Cartan subalgebra and root counts of so(10)');
OPEN['YM-007'] = n('M', 'new', false, 'YM',
  'the non-abelian stress -1/2 tr(F a F) of an so(m) field on the engine\'s frame and the Einstein form of a coloured Reissner-Nordstrom type solution at rational points: E_a = -kappa T_a',
  '@forms: Grav.einstein with the so(m) Yang-Mills stress built as in b3_matter.py', 'christoffel route of c3_rn.py with the textbook Yang-Mills stress tensor');
OPEN['LNB-016h'] = n('S', 'new', false, 'SM16',
  'the eleven states of the 27 that are not in the 16 are the 10 + 1 of so(10) inside e6: split the 27 grade-1 roots of e7 by the coefficient of the D5 node (16 + 10 + 1)',
  'baez_check.py E1-E3: Bourbaki E8 roots, Levi subsystems, grade-1 spaces', '@roots; Bourbaki branching 27 = 1 + 10 + 16 recalled');
OPEN['LNB-043'] = OPEN['LNB-016h'];
OPEN['LNB-021g'] = n('M', 'new', false, 'EMB',
  'a table of the regular embeddings of su(3)+su(2)+u(1) in F4, E6 and Spin(10), built from the roots, and the relation of the F4 and the E7 copies through Spin(9) in Spin(10) (LNB-035, LNB-038, LNB-045, LNB-117 are the same table)',
  'baez_check.py E1-E3 and S1-S2: root systems, centralisers, the 27 by Casimir class', '@roots: all A2+A1 subsystems of the Dynkin extensions, counted up to Weyl conjugacy');
for (const id of ['LNB-035', 'LNB-035b', 'LNB-038', 'LNB-045', 'LNB-117']) OPEN[id] = OPEN['LNB-021g'];
OPEN['LNB-033'] = n('M', 'new', false, 'EMB',
  'three 32-dimensional label spaces V1, V2, V3 as one space with a generation index: the weight spaces of a Cartan element of the generation sl3 in 90 + 6 of E7 > A2 x A5 (CAND-021), each completed to 32 by two root vectors',
  'baez_check.py E3a-E3e (Prop. 1, Lemma 2-4, Thm. 12): 30 + 6 + 90 roots, V_k = Lambda^even C^6', '@roots: weights of 133 = (8,1) + (1,35) + (3,15) + (3bar,15bar)');
for (const id of ['LNB-033b', 'LNB-039']) OPEN[id] = OPEN['LNB-033'];
OPEN['LNC-076b'] = n('M', 'new', false, 'SOLID',
  'the ten Altland-Zirnbauer classes against the eight clock values and two complex classes: for each choice of (T^2, C^2) the commutant type of the minimal module (R, C or H) and the edge degeneracy, all from the clock',
  'sol_fk_clock.py (bd.sol.1-4: edge invariants depend on the clock) and bd.sol.23 (Frobenius-Schur = type)', 'the tenfold way table of Kitaev (recalled) against the computed commutant types');
OPEN['LNS-013g'] = n('L', 'new', false, 'MEDIA',
  'whether the eleven or more integration constants of the closure of general linear electrodynamics organise along 6 + 12 + 3 or along the invariant pieces of the 21: solve the closure equations on the area-metric background and read the pieces',
  '@forms with h6_area_metric.py (the quartic polynomial P and the 17 canonical variables)', 'the printed closure equations of the paper (not in the package: source needed)');
OPEN['LNS-030'] = OPEN['LNS-013g'];
OPEN['LNS-048'] = OPEN['LNS-013g'];
OPEN['LNS-028d'] = n('L', 'new', false, 'MEDIA',
  'for the quartic area-metric polynomial P: do the second and third conditions (dual polynomial, energy-distinguishing) carve a map of cells like the hyperbolicity map of the quadratic case',
  'h6_area_metric.py (P) and F2\'s (k,d) map', 'the paper\'s definitions of the dual polynomial (source needed)');
OPEN['LNS-045'] = OPEN['LNS-028d'];

// ---------------------------------------------------------------------------------------------------------------------------- the supplement: theorem gaps
const THM = {
  T2: { fix: 'the checks GL and GRA test nothing (tautologies) and LOE does not terminate on a non-nilpotent radical: rewrite the three items so that each can fail; the universal grading group for arbitrary gradings (torsion included) is not determined (LNC-085)', cost: 'S', work: 'extend' },
  T4: { fix: 'the eight pairs are shown distinct, not shown to be the graded Morita classes forming Z8: Wall\'s theorem is recalled (CAND-004); a check of graded Morita equivalence classes for p + q <= 8', cost: 'L', work: 'source' },
  T6: { fix: 'part (d) is reduced to Hurwitz\'s theorem (recalled) and the Albuquerque-Majid framing is recalled: CAND-070 and CAND-094 give the finite parts', cost: 'S', work: 'wire' },
  T8: { fix: 'the TITS loop at n = 3 does not terminate on some false inputs (fix the loop, then it can fail); wild for n >= 4 rests on de la Peña\'s theorem (recalled, over an algebraically closed field)', cost: 'S', work: 'extend' },
  T12: { fix: 'no hand proof of the O+4(2) exception (the exhaustive count is the proof) and no general length formula; generation for general n rests on Dieudonné\'s theorem (recalled): CAND-059 and bd.en.5 (to n = 200)', cost: 'M', work: 'derive' },
  T17: { fix: 'the isoclinic case lambda1 = lambda2 and the invariant decomposition for general n are not proved (Roelfs-De Keninck); CAND-076 states it', cost: 'M', work: 'derive' },
};

// row-specific reasons that add to the class
OPEN['LNC-054'] = s('source', 'the T8 note records the answer in print over an algebraically closed field (Wang, arXiv:2407.11363, Prop. 3.1, read); the row still asks it');
OPEN['LNC-083'] = OPEN['LNC-054'];
OPEN['FRQ-005'] = s('source', 'the full text of the conformal-dynamics talk is absent; the third batch (lead L14) rewords this row, so it is listed again after the apply');
OPEN['LNS-106'] = s('source', 'the closure paper (p. 35) states the energy-distinguishing condition; no number of ours connects the null-energy check to it');
OPEN['SPN-004'] = s('source', 'the printed Theorem 1, the announced real idempotent and the complex lambda need the paper of Roelfs, Eelbode and De Keninck; the Cl(3,0) probability rule is computed (T15)');
// the lines the second proofs pass split off (docs/round7/PROOFS_ROUND2.md): a reading, two pointers, a free parameter, a research question, a stated limit
OPEN['ATL-020c'] = s('reading', 'the ratio 4/17 is an internal count of neutral paths, not a weak mixing angle: the row\'s own reading');
OPEN['INP-033b'] = s('input', 'the pointer to the Yang-Mills action with a source (source unread); the action itself is INP-033, derived by ym_action.py');
OPEN['INP-037b'] = s('input', 'the pointer to the Dirac action with the covariant derivative (source unread); the action itself is INP-037, derived by ym_matter_gravity.py');
OPEN['MAT-005b'] = s('input', 'the size of the coupling is a free parameter of the model: a choice, not a statement a check can prove');
OPEN['YM-006b'] = s('research', 'which gauge algebra, if any, the model uses: so(p,q) is what grade 2 gives; no finite computation decides the choice');
OPEN['YM-007b'] = s('scope', 'a non-abelian source of gravity that is not an embedded abelian field is not built (gravity is drawn in steps 9-10)');
// the lines the third proofs pass split off (docs/round7/PROOFS_ROUND3.md): what stays open after the computations of L7-11 ... L7-17
OPEN['CPL-007c'] = s('research', 'what the copies of the Dirac field from n = 5 stand for (a flavour or taste reading) is a question of physics, not of the labels; the grade-5 part on one copy for n >= 6 is a computation to run: a script over the ideals at n = 6, 7, 8');
OPEN['GOS-006c'] = s('scope', 'an odd unimodular lattice that is not I_(p,q) has no cell in the Atlas: closing it is attaching lattices to cells, a feature, not a check');
OPEN['LNB-033c'] = s('research', 'a construction outside e7 that makes the three label spaces one V x C^3: no finite computation names it');
OPEN['LNB-035c'] = s('source', 'why the E7 paper prefers its embedding, and its non-regular embeddings: the papers\' own choices, not in the package');
OPEN['LNC-076d'] = s('source', 'the direction of the eight real classes round the clock and the table of invariants by dimension are Kitaev\'s table, not in the package; the commutant types are checked (LNC-076b)');
OPEN['LNS-028e'] = s('source', 'the 23 algebraic classes of area metrics of the closure paper are not in the package');
OPEN['LNS-030b'] = s('source', 'the closure constants need the closure paper\'s equations, not in the package; the 17 canonical variables are placed (LNS-030)');
OPEN['LNS-045c'] = s('source', 'the seven of 23 classes that pass the three conditions are the closure paper\'s classification, not in the package');
OPEN['LNS-048b'] = s('source', 'the closure constants are not examined in the package; the invariant split of the 21 is computed (CAND-090)');
OPEN['RSN-004b'] = s('research', 'whether the generation A2 acts on another model of the atlas (three copies of the 16, or the 27): a construction to choose first; the 16-dimensional model gives no su(3) (GOS-003)');
OPEN['YM-007c'] = s('scope', 'a non-abelian source with Lambda = 0 (an asymptotically flat Einstein-Yang-Mills solution, numerical in the literature) is not built: a feature of the gravity engine, not a check');
// the lines the fourth proofs pass split off (L8-03, L8-04, L8-08): what stays open after their computations
OPEN['CPL-007c'] = s('research', 'what the copies of the Dirac field from n = 5 stand for (a flavour or taste reading) is a question of physics, not of the labels; the grade-5 part on one copy is computed at n = 6, 7, 8 (CPL-007d, emd·CUR); whether it vanishes at some psi != 0 of a copy at n = 7, 8, and what it is for n >= 9, is not decided');
OPEN['GOS-006d'] = s('scope', 'an odd unimodular lattice that is neither I_(p,q) nor E8 + Z has no cell in the Atlas (GOS-006c is answered for E8 + Z, lat·9): closing it is attaching lattices to cells, a feature, not a check');
OPEN['LNC-098c'] = s('source', 'the Carroll structure of a null hypersurface as a field with its connection is the literature on Carrollian horizons, not in the package; the pointwise algebra is checked (LNC-098b, kpg·13 to 15)');
// after pass three the three question lines whose answers are their b-lines keep their note as skips (the question stays as the row's lead; its computable part is closed)
OPEN['CPL-007'] = s('mislabel', 'answered at n = 5 by CPL-007b (checked: the extra components are a second Dirac field, the grade-5 part on each half); what stays open is CPL-007c; the question line stays as the lead of the pair');
OPEN['GOS-006'] = s('mislabel', 'answered by GOS-006b (checked for I_(p,q), p + q <= 12, and E_n, n = 3..11); what stays open is GOS-006c (lattices that are not I_(p,q)); the question line stays as the lead of the pair');
OPEN['LNS-013g'] = s('source', 'the integration constants need the closure paper\'s equations, not in the package (L7-15: the package stops at the 17 canonical variables, placed in LNS-030)');
OPEN['LNB-046'] = s('source', 'the printed equation (12) of the Kepler paper, version 5; the Atlas computes [M,M] = eps L (baez.K1b, bd.kep.1) and cannot read the print');
OPEN['LNS-045b'] = s('source', 'the closure paper, Sect. II (pointer, source unread): whether the dual polynomial is defined for a quadratic P with a kernel');
OPEN['LNB-044'] = s('source', 'Loos\'s Jordan theory is not in the package');
OPEN['LNB-040'] = s('source', 'asks whether the authors of the E7 paper would accept the Fock reading');
OPEN['LNS-033b'] = s('source', 'only the lecture video would settle it (optional)');

// ---------------------------------------------------------------------------------------------------------------------------- D. candidates marked checkable "yes" (88)
// The personas wrote the route in the checkNote without the 9,128 check ids in view. Read against checks.json, 29 of the 88 are already checked in the
// bridges, the report scripts or the theorem scripts: the work is a row with that evidence (work "wire"), not a new proof. 30 more are partly covered
// ("extend"); the others need a script ("new" or "derive"). A candidate is not printed, so a wrong one is never false as printed.
const BRG = 'the bridge script (exact Fractions or F2 algebra, its own bit rule)';
const NOIND = 'none in the script (checks.json independentRoute: no); the lead adds a numpy or enumeration route';
const CAND = {
  'CAND-001': n('M', 'extend', false, 'CATLAT',
    'the family of Lie algebras so(p,q) with one extra generator of square s: [B_an, B_bn] = -2s B_ab and its Inonu-Wigner contraction s -> 0 (projective_selfcheck.py ladder); Galilei, Lorentz, Carroll as the invariant forms (bd.mjp.25); the classification of kinematical algebras is the open part',
    'projective_selfcheck.py ladder with s in {-1,0,+1} on the Lorentz base; mjp_time.py bd.mjp.25', 'structure constants of the 10-dimensional kinematical algebras (Bacry and Levy-Leblond, recalled) contracted by explicit rescaling'),
  'CAND-003': n('S', 'extend', false, 'SM16',
    'the SU(3)^3 and the global SU(2) conditions on the 16 (even number of doublets: 4) and the vanishing of the cubic trace tr(T_a {T_b, T_c}) on the spinor of so(10); baez.H2d already sums Y, Q, Y^3 and Y over doublets',
    'baez_check.py H2d weights per label; @cliff Cl(0,10) bivectors on the 32, restricted to one chirality', 'textbook weights of Q_L, u_R, d_R, L, e_R, nu_R and hand sums; numpy gamma matrices of so(10)'),
  'CAND-008': n('S', 'extend', false, 'POLAR',
    'for n <= 4 count the maximal totally isotropic subspaces of the symplectic form on F2^(2n) (n = 2: 15, each with 4 sign choices = 60 stabiliser states = 2^n prod(2^k + 1)), the order of Sp(2n,2), and that the label quadric refines the form; fibre.G7d and bd.alg.12 count the quadric side',
    '@f2 polar form of q and the quadric counts (T11, fibre.G7d); alg_groups.py (extraspecial blade group)', '@enum of commuting Pauli subsets; numpy 2^n x 2^n matrices: stabiliser states as simultaneous eigenspaces'),
  'CAND-011': n('M', 'derive', false, 'YM',
    'for so(m): the Euler-Lagrange equations of the Yang-Mills-Dirac action are D^mu F_(mu nu) = e j_nu and the Dirac equation with -e A psi, with one coupling; flipping the interaction sign flips both (the abelian case is bd.phy.18-19)',
    'as INP-033; matter_selfcheck.py current j^a', 'numpy structure constants; finite variation of the action at points'),
  'CAND-012': n('M', 'new', false, 'DIRAC',
    'expand the minimally coupled Dirac-Hestenes equation to order 1/c on the even part of Cl(1,3): the Pauli equation with mu = g (e/2m) S and g = 2',
    '@br: Cl(1,3) even part, series in 1/c with exact Fractions, projection to the upper components', 'numpy: the Foldy-Wouthuysen expansion of the 4 x 4 Dirac Hamiltonian to order 1/c^2 (Bjorken and Drell, recalled)'),
  'CAND-015': s('b3', 'the Belinfante term and the Hehl-Datta equation are the scripts e2s4_belinfante.py and e2s4_hehl_datta.py (third batch); the ledger decides one merged wording of GRV-011 and applies it'),
  'CAND-020': n('S', 'extend', false, 'SM16',
    'the 27 of E6 under so(10) x u(1) is 16 + 10 + 1 (the 10 = 5 + 5bar of SU(5)): split the 27 grade-1 roots of e7 by the coefficient of the D5 node; also answers LNB-016h and LNB-043',
    'baez_check.py E1-E3 (Bourbaki roots, Levi subsystems, grade-1 spaces 56, 27, 16, 10, 6)', '@roots; Bourbaki branching recalled'),
  'CAND-021': n('S', 'wire', false, 'WIRECAND',
    '133 = (8,1) + (1,35) + (3,15) + (3bar,15bar) under sl3 + sl6 is the 30 + 6 + 90 roots of E7 (baez.E3a, T13 part 5); 133 = 3 + 66 + 2 x 32 under sl2 + so12 is baez.E3d; the three V_k are baez.E3e (Lambda^even C^6)',
    'baez_check.py E3a, E3d, E3e; check_T13.py (D8+ doubled coordinates)', 'check_T13.py is its own engine (clC.py, f2lib.py), nothing from the atlas',
    { via: ['selfcheck/reports/baez_check.py', 'researchers_checks/check_T13.py'] }),
  'CAND-023': n('M', 'extend', false, 'EMB',
    'the 36-dimensional stabiliser of h2(O) in f4 is spin(9) and acts on the 16 of Peirce 1/2 as the real spinor module of Cl(9,0): compare the Casimir or build the intertwiner',
    'baez_check.py O3b (Peirce decomposition of h3(O)), O3e-O3g (stabilisers); @br Cl(9,0) spinor module', 'numpy: nullspace of the intertwining equations between the two 16-dimensional actions'),
  'CAND-024': n('S', 'wire', false, 'WIRECAND',
    'Cl(p,q) with p + q = 2k has a real spinor module that splits into two real half-spin modules exactly when p - q = 0 mod 8: bd.str.6 (even-part types, Majorana-Weyl iff s - t = 0 mod 8)',
    'str_spinors.py bd.str.6', BRG, { via: ['selfcheck/bridges/str_spinors.py'] }),
  'CAND-027': n('M', 'derive', false, 'GRAVEM',
    'one script with the Lie table as a parameter: F = dA + 1/2 [A, A], D_A F = 0 from the Jacobi identity for g = so(1,n-1) x R^n, so(1,n), so(2,n-1) and so(m); replaces the Bianchi checks of steps 7, 9 and 11 and gives a two-line proof for every n',
    '@forms with the Lie table of Lie(...); h5l_bianchi.py already does so(2,4), so(1,5), so(3,3)', 'Jacobi identity on the structure constants in numpy'),
  'CAND-030': n('S', 'extend', false, 'GRAVEM',
    'the projectivised null cone of R^(1,3) is the sphere: P(x) = o + x - x^2 eps/2 is null for every x, P(x).P(y) = -(x - y)^2/2, the restricted Lorentz group acts as Mobius maps generated by inversions; turns the 96-vector check of NUL-008 into a proof',
    'projective_selfcheck.py null-pair block; phy_horizon_little_group.py bd.phy.5-6', 'numpy: SL(2,C) matrices acting on null vectors as Hermitian 2 x 2 matrices'),
  'CAND-035': n('S', 'extend', false, 'GRAVEM',
    'the n-cube framework in R^n has n 2^(n-1) - C(n+1,2) mechanisms and no self-stress (dim mechanisms - dim self-stresses = dV - E - C(d+1,2)): bd.sol.19 gives 1, 6, 22, 65 for n = 2..5; add n = 6, 7 by exact rank and the argument for every n',
    'sol_lattice_springs.py bd.sol.19; @br cube graph, exact rank of the rigidity matrix', 'numpy matrix_rank with integer coordinates; Laman count in the plane'),
  'CAND-036': n('M', 'derive', false, 'CATLAT',
    'the linearised flow at a steady rotation of the free top: unstable iff another eigenvalue of J eta lies between the two of the plane, for every body (three inertia parameters, symbolic in exact rationals) rather than the box bodies of G1',
    'g1_free_top.py charpoly; geo_cartan.py bd.geo.15 (invariants conserved)', 'numpy eigenvalues of the linearisation; Euler equations by hand'),
  'CAND-037': n('M', 'new', false, 'GRAVEM',
    'for pressureless dust D tau_a = 0 (forced by the Noether identity of b2_noether.py once E_a = kappa tau_a) is equivalent to u.grad u = 0: the field equation forces free fall',
    '@forms with b3_matter.py (stress by variation) and the covariant derivative of d1_newtonian_limit.py', 'Christoffel symbols: nabla_a (rho u^a u^b) = 0 with the textbook geodesic equation'),
  'CAND-039': n('S', 'new', false, 'GRAVEM',
    'the field stress T(a) = -1/2 F a F has divergence F.J whenever grad F = J, as a polynomial identity on random exact fields in Cl(1,3); conservation of the total then gives the Lorentz force density',
    '@page maxwell_selfcheck.py polynomial fields with the strong sampler of a2b_strong_sampling.py', 'numpy: T^(mu nu) = F^(mu a) F^nu_a - eta F^2/4 with finite differences'),
  'CAND-044': n('S', 'extend', false, 'SM16',
    'Tr T3^2 / Tr Q^2 over the 16 is 3/8 as an exact rational, and over any complete SU(5) multiplet; the 16 as sums of bit counts',
    'baez_check.py H2 (Y, Q, T3 per label, Fractions)', 'textbook charges of one generation, sums by hand'),
  'CAND-045': n('M', 'new', false, 'DIRAC',
    'C (right multiplication flipping J and the sign of e), P (psi -> gamma0 psi(x-bar) gamma0) and T each map solutions of the Dirac-Hestenes equation to solutions of the transformed equation; CPT is a symmetry; exact on polynomial and plane-wave solutions',
    '@br Cl(1,3) even part; solutions from coupling_selfcheck.py shell', 'numpy: C = i gamma2 K, P = gamma0, T = i gamma1 gamma3 K on the 4 x 4 Dirac equation'),
  'CAND-046': n('S', 'wire', false, 'WIRECAND',
    'half-filled hopping on the cube: the energy is lowest exactly in the all-pi flux sector (bd.sol.27; the Hubbard cube bd.sol.31 agrees); Lieb\'s theorem is for planar bipartite lattices and the check is the cube',
    'sol_kitaev_lieb.py bd.sol.27', BRG + '; the numpy spectra inside the script are the second route', { via: ['selfcheck/bridges/sol_kitaev_lieb.py'] }),
  'CAND-047': n('M', 'extend', false, 'SOLID',
    'the plaquette action sum (1 - Re tr U_p) for SU(2) on the n-cube expands to the Yang-Mills action at small field (the leading term is -1/2 tr F^2 a^4); staggered fermions on the sites are bd.phy.16 (Kogut-Susskind phases, D^2 = n)',
    'phy_staggered.py bd.phy.16; @liealg for the F^2 term', 'numpy: matrix exponentials of small su(2) links; series in the lattice spacing'),
  'CAND-048': n('S', 'new', false, 'POLAR',
    'exp of the degree +-2 bivectors (pair creation and annihilation) preserve the CAR and change the particle number by two, on the 32 labels of five modes',
    'baez_check.py H3a-H3c (Fock labels, a_i + a_i^+, 45 bivectors close)', 'numpy: Jordan-Wigner matrices and matrix exponentials of the pairing terms'),
  'CAND-050': n('M', 'extend', false, 'EMB',
    'the Frenkel-Kac sign epsilon(a,b) is a bit-rule sign on L/2L = F2^8: build e8 = h + sum e_alpha with [e_a, e_b] = epsilon(a,b) e_(a+b) and check the Jacobi identity on all triples (248^3); removes the import INP-016',
    'mjp_clock.py bd.mjp.29 (bimultiplicative cocycle) and mat_En_in_Cl1n.py', 'a Chevalley basis of e8 with integer structure constants (recalled), Jacobi by numpy'),
  'CAND-051': n('S', 'extend', false, 'POLAR',
    'Cl(q + q\') = Cl(q) x Cl(delta q\') as ungraded algebras when q is non-degenerate of even dimension (delta = square of the volume element): verify the relations z\'_j = e_F z_j by products for n <= 6; the representation types of Lambda(R^r) are recalled',
    'core_check.py core.B10 (doubling) and cat_check.py cat.C1', 'numpy: explicit matrix representations of both sides, dimension and relations'),
  'CAND-052': n('S', 'wire', false, 'WIRECAND',
    'deleting node alpha_i grades the algebra with 2 m_i + 1 pieces, m_i the coefficient in the highest root: E8 mark of alpha_8 is 2, marks 1 for the cominuscule nodes (baez.E1a-E1c, E3b; check_T10.py marks (3; 2,4,6,5,4,3,2,1))',
    'baez_check.py E1a, E1b, E3b; check_T10.py', '@roots; Bourbaki tables (recalled)', { via: ['selfcheck/reports/baez_check.py', 'researchers_checks/check_T10.py'] }),
  'CAND-053': n('S', 'wire', false, 'WIRECAND',
    'v.x = v^x + v-contraction x: the left multiplication by a generator is wedge plus contraction and iterating gives the bit rule on every pair (bd.mja.5); the general-n statement is the sign formula of T1 on disjoint labels',
    'mja_exterior.py bd.mja.5', BRG, { via: ['selfcheck/bridges/mja_exterior.py'] }),
  'CAND-054': n('S', 'wire', false, 'WIRECAND',
    'on the even subalgebra reversion and Clifford conjugation coincide, so M M~ = M M-bar for motors and rotors: the cell with its reversion (rev_reversion.py bd.rev.1-5); the necessity of 4 | n is the Gauss-sum count of T4 (iii)',
    'rev_reversion.py bd.rev.1-6', BRG, { via: ['selfcheck/bridges/rev_reversion.py'] }),
  'CAND-055': n('S', 'derive', false, 'POLAR',
    'every real quadratic space is V_an + H^m + rad Q: from the signature (p,q,r) of the bit rule, m = min(p,q), anisotropic part |p - q|, radical r; exhaustive for p + q + r <= 8 including the explicit hyperbolic planes',
    'bd.str.21 and mjg_frames.py bd.mjg.12 (paired null, radical); @br', 'Sylvester\'s law of inertia: numpy eigenvalue signs of the Gram matrix'),
  'CAND-056': n('S', 'extend', false, 'POLAR',
    'for a central simple B in End(V): the commutant C is central simple, C(C) = B, B x C = End(V), [C] = [B]^-1 in Br(R); when the centre is C or R^2 the map B x C(B) -> End(V) is not injective; fibre.G3c has the dimensions of the double commutant',
    'fibre_check.py G3c; fur_commutant.py bd.fur.1-5', 'numpy: nullspace of the commutation equations, ranks'),
  'CAND-057': n('S', 'derive', false, 'RANGE',
    '(i)-(iv) as identities in n: sum_a i^w(a) = prod_j (1 + i^(eps_j)) (the sum over subsets factorises), the Brown invariant is additive on orthogonal sums, pi + 2Q\' refines the dot product iff every k_j is odd; core.B1-B3 check n <= 5, 6, 8',
    'core_check.py core.B1-B3 and mjp_charges.py', 'Gaussian integers in exact arithmetic for n <= 16'),
  'CAND-058': n('S', 'derive', false, 'RANGE',
    'omega^2 = (-1)^(n(n-1)/2 + q) for r = 0 and 0 for r >= 1, the centre R (n even) or R + R omega (n odd): the reordering sign of the top label is a popcount; exhaustive for all (p,q,r) with n <= 10',
    'core_check.py core.B14, core.B20; @br top label product', 'numpy centre of the regular representation'),
  'CAND-059': n('S', 'wire', false, 'WIRECAND',
    'O(Q) over F2 is generated by orthogonal transvections except O+4(2); every non-singular class of E_n/2E_n is a root mod 2, so the image of W(E_n) is all of O(q): bd.en.5 (to n = 200) and check_T12.py (n <= 6, breadth-first)',
    'en_weyl.py bd.en.5; check_T12.py', '@f2 Schreier-Sims (own engine)', { via: ['selfcheck/bridges/en_weyl.py', 'researchers_checks/check_T12.py'] }),
  'CAND-061': n('S', 'wire', false, 'WIRECAND',
    'the Nakayama automorphism of Lambda(V) is (-1)^((n-1) deg) and the form is symmetric iff dim V is odd; a Frobenius algebra is symmetric iff its Nakayama automorphism is inner (cat.F2, cat.F3, T3)',
    'check_T3.py; cat_frobenius.py', 'check_T3.py own engine; exact rank test for n <= 6', { via: ['researchers_checks/check_T3.py', 'selfcheck/bridges/cat_frobenius.py'] }),
  'CAND-062': n('S', 'extend', false, 'SM16',
    'on Lambda C^n the map e_S -> +-e_(S-bar) is the Hodge star; for odd n it exchanges Lambda^ev and Lambda^odd (the 16 and 16bar of so(10)) and negates every weight of the Cartan of sl5, hence Y and Q',
    'baez_check.py H1b (complement, popcount 5 - k) and H2b; str_spinors.py bd.str.8', 'textbook weights of 16 and 16bar'),
  'CAND-063': n('M', 'extend', false, 'POLAR',
    'triality of Spin(8): the outer automorphism of order 3 permutes the vector and the two half-spin weight sets (the three 16-cells of the 24-cell) and the three families of 135 over F2 (singular points and the two families of solids); cat.W3 has the families, bd.str.12 the Hadamard form',
    'cat_check.py W3; str_dualities.py bd.str.12; @f2', 'sign-vector weight sets by enumeration'),
  'CAND-064': n('S', 'extend', false, 'POLAR',
    'on a split space of dimension 2k the maximal isotropic subspaces form two families exchanged by reflections and preserved by Spin; each is the line of a pure spinor in one half-spin space (the two families are cat.W3 for Cl(8,0))',
    'cat_check.py W3; check_T11.py', 'numpy: the pure spinor condition on the 16-dimensional half-spin module'),
  'CAND-069': n('S', 'new', false, 'DIRAC',
    'Cl+(1,n-1) = Cl(n-1,0) as a left module over itself is N copies of the irreducible module; right multiplication by the commutant acts on the multiplicity space; for n = 5..8 the dimensions (answers the first half of CPL-007)',
    '@cliff regular matrices, exact rank of minimal left ideals', 'numpy matrix algebra: commutant by nullspace'),
  'CAND-070': n('S', 'extend', false, 'WIRECAND',
    'unital composition algebras have dimension 1, 2, 4, 8, are alternative, and the split octonions are Zorn\'s vector matrices: exact rational composition N(xy) = N(x)N(y) on all basis pairs instead of random vectors (baez.O2a uses 40 random)',
    'alg_octonion.py bd.alg.14; baez_check.py O2a, O2b', 'numpy: norm form on all 64 basis products'),
  'CAND-075': n('S', 'wire', false, 'WIRECAND',
    'an indecomposable indefinite generalised Cartan matrix is hyperbolic iff every proper connected subdiagram is finite or affine: E10 qualifies, E11 contains E10 (check_T10.py lists all connected subdiagrams of E10 and E11)',
    'check_T10.py', 'check_T10.py own engine, Bareiss elimination', { via: ['researchers_checks/check_T10.py'] }),
  'CAND-076': n('M', 'derive', false, 'CATLAT',
    'every bivector of a non-degenerate Cl(p,q) is a sum of at most floor(n/2) commuting simple bivectors, unique for distinct eigenvalues; the isoclinic case lambda1 = lambda2 and the normal forms of Williamson in indefinite signature (closes the GAP of T17)',
    '@br bivector squares and the skew operator; check_T17.py parts a-c', 'numpy: real normal form of the skew operator (eigen-decomposition), n <= 6'),
  'CAND-078': n('S', 'extend', false, 'POLAR',
    'Spin(3) = SU(2), Spin(1,2) = SL(2,R), Spin+(1,3) = SL(2,C), Spin(2,2) = SL(2,R)^2, Spin(3,3) = SL(4,R), Spin(2,4) = SU(2,2), Spin(1,5) = SL(2,H) at the Lie algebra level: even-part types (cat.C1) and Killing-form signatures of the bivector algebras',
    'cat_check.py C1; equations_selfcheck.py (so(p,q) from the bit product)', 'numpy: dimension and Killing signature of the matrix Lie algebras'),
  'CAND-082': n('S', 'new', false, 'EMB',
    'e6 contains f4 with 27 = 1 + 26, and f4 contains su(3) + su(3) with 26 = (8,1) + (3,3) + (3bar,3bar): weights from the enumerated roots',
    'baez_check.py E1-E3 root machinery and O3f-O3g', '@roots; Bourbaki branching recalled'),
  'CAND-083': n('S', 'wire', false, 'WIRECAND',
    'the largest set of commuting blades of square +1 spans a split algebra R^(2^w), w the Witt index; the 2^w joint projectors are its minimal idempotents (cat.W1-W3; fibre.G9b for the 16 Hamming words)',
    'cat_check.py W1-W3; fibre_check.py G9b', BRG, { via: ['selfcheck/reports/cat_check.py', 'selfcheck/reports/fibre_check.py'] }),
  'CAND-085': n('S', 'extend', false, 'GRAVEM',
    'M(A,J,Q) is homogeneous of weight 1 under (lambda^2 A, lambda^2 J, lambda Q); Euler\'s relation with dM/dA = kappa_H/8 pi, dM/dJ = Omega_H, dM/dQ = Phi_H gives Smarr for every member and the first law is its differential: a derivation, then exact rational checks at points (the constants then no longer come from three fitted cases)',
    'f2_first_law.py (family_closed, horizon_numbers) and f4_komar_kn.py', 'closed Boyer-Lindquist forms, exact partial derivatives by hand-coded formulas'),
  'CAND-087': n('S', 'new', false, 'CATW',
    'Sym^2(Lambda^2 V) = ker b + Lambda^4 V with b(alpha.beta) = alpha ^ beta; dim Weyl = n(n+1)(n+2)(n-3)/12; B ^ B = b(B.B): exact ranks for n = 2..8; the same computation decides the third clause of RSN-018',
    '@forms curvature_space(n) and counts(n) of gravity_selfcheck.py', 'numpy matrix_rank of the Bianchi map'),
  'CAND-089': n('S', 'new', false, 'GRAVEM',
    'a Weyl tensor of Petrov type II and one of type III: choose Q = E + iB with the Jordan forms of II and III, map back to an algebraic curvature tensor, read the type from the engine\'s Q and from numpy; h1_petrov.py has D, N, O, I',
    'h1_petrov.py and g2_weyl.py (Q = E + iB, Jordan type)', 'numpy Jordan decomposition of the 3 x 3 complex matrix; the Penrose-Rindler invariants I, J'),
  'CAND-090': n('S', 'extend', false, 'MEDIA',
    '36 = 20 + 15 + 1 under GL(4) (principal, skewon, axion), the principal part splitting further under the Lorentz group: the frame-independent replacement of 6 + 12 + 3 (bd.sol.14 has 36 = 21 + 15 and the axion)',
    'sol_maxwell_media.py bd.sol.14; h6_area_metric.py', 'numpy projectors of the symmetric and antisymmetric parts on 6 x 6 matrices'),
  'CAND-091': n('S', 'derive', false, 'RANGE',
    'a Z4-valued quadratic refinement takes only the values 0 and 2 on the radical; its Gauss sum is non-zero iff it vanishes there and then the Brown invariant is that of V/rad: all cells with r <= 3 and n <= 9 (core.B3 has r = 1, 2, n <= 6)',
    'core_check.py core.B3; mat_cell_classification.py', 'Gaussian-integer sums by direct enumeration'),
  'CAND-092': n('S', 'wire', false, 'WIRECAND',
    'a category with an initial object has a contractible nerve, so every 2-cocycle on B_n is a coboundary: the bit-rule sign on the composable pairs is the coboundary of c(S -> T) = s(S, T minus S) (bd.mjg.27)',
    'mjg_topology.py bd.mjg.27; mjc_nerve.py', BRG, { via: ['selfcheck/bridges/mjg_topology.py', 'selfcheck/bridges/mjc_nerve.py'] }),
  'CAND-093': n('S', 'wire', false, 'WIRECAND',
    'the order complex of B_n is the Freudenthal triangulation of [0,1]^n, its proper part the sphere S^(n-2), mu(0,[n]) = (-1)^n; H^1 of the cube vanishes (bd.mjg.22-23, T6)',
    'mjg_topology.py bd.mjg.22-23; check_T6.py', BRG, { via: ['selfcheck/bridges/mjg_topology.py', 'researchers_checks/check_T6.py'] }),
  'CAND-094': n('S', 'wire', false, 'WIRECAND',
    'the octonions are the twisted group algebra of Z2^3 with associator (-1)^det: alternative, normed, with the Albuquerque-Majid cochain (bd.alg.14; T6 d)',
    'alg_octonion.py bd.alg.14; check_T6.py', BRG, { via: ['selfcheck/bridges/alg_octonion.py'] }),
  'CAND-095': n('S', 'wire', false, 'WIRECAND',
    'a finite category has a strictly positive additive weight iff it is acyclic (direct): an exact witness or an exact obstruction on 584 categories and a zoo (bd.mjc.12, bd.mjc.15); the proof for every finite category is one line',
    'mjc_sum.py bd.mjc.12; mjc_weight.py bd.mjc.15', 'scipy linear programming agrees with the exact witness', { via: ['selfcheck/bridges/mjc_sum.py', 'selfcheck/bridges/mjc_weight.py'] }),
  'CAND-096': n('S', 'new', false, 'CATLAT',
    'for a finite poset Leinster\'s Euler characteristic is the Moebius sum and equals the Euler characteristic of the order complex: B_n for n <= 6 (links LNC-052, LNC-140, LNC-139)',
    'mjg_topology.py bd.mjg.22-23 (order complex); cat_check.py cat.E1 (Moebius)', 'direct Moebius inversion and simplex counts'),
  'CAND-097': n('S', 'wire', false, 'WIRECAND',
    'Fun(A x B, C) = Fun(A, Fun(B, C)) and B_(k+1) = B_k x B_1 give C_(k+1) = Fun(B_k, C) for finite C: bd.mjc.30-31 counts the iterated arrow categories on six base categories',
    'mjc_comma.py bd.mjc.30-31', BRG, { via: ['selfcheck/bridges/mjc_comma.py'] }),
  'CAND-098': n('S', 'new', false, 'CATLAT',
    'for orthogonal idempotents summing to 1, A = sum e_i A e_j with the off-diagonal pieces as bimodules; for a full idempotent e, A is Morita equivalent to eAe: matrix algebras and the Furey blocks',
    'mja_incidence.py bd.mja.9 (Peirce idempotents of Cl(n,n)); run_all.py', 'numpy: dimensions of e_i A e_j and the Morita functor on M_n(R)'),
  'CAND-100': n('S', 'wire', false, 'WIRECAND',
    'B_n = B_1^n: the incidence algebra is (k A2)^(x n) (Kronecker formulas of T8), the nerve has (k+2)^n k-simplices (bd.mjc.3), the Euler form is the Moebius function (cat.E1)',
    'cat_check.py E1; check_T8.py; mjc_labels.py bd.mjc.3', 'check_T8.py own engine', { via: ['selfcheck/reports/cat_check.py', 'researchers_checks/check_T8.py', 'selfcheck/bridges/mjc_labels.py'] }),
  'CAND-101': n('S', 'derive', false, 'RANGE',
    'for an odd unimodular lattice L with characteristic vector k: k-perp is saturated of rank n - 1, lies in L_even, and k-perp/2 k-perp = (L_even/2L, x.x/2 mod 2) which for I_(p,q) is the label form of the even part (the lemma behind GOS-006)',
    'mat_En_in_Cl1n.py (bd.mat.18, n = 3..10) and str_extra.py bd.str.25; @f2', 'integer lattice enumeration and Smith normal form'),
  'CAND-102': n('S', 'wire', false, 'WIRECAND',
    'the seven Fano-line blades and their products are the 15 non-zero words of RM(1,3), the extended Hamming code [8,4,4] (weights 14 x 4 and 1 x 8), a Lagrangian of the label form of Cl(0,8) (core.B11, bd.sol.10, check_T14.py)',
    'core_check.py core.B11; sol_furey_fk.py bd.sol.10', 'check_T14.py: brute-force |Aut| = 1344 over 8! permutations', { via: ['selfcheck/core_check.py', 'selfcheck/bridges/sol_furey_fk.py', 'researchers_checks/check_T14.py'] }),
  'CAND-103': n('S', 'new', false, 'POLAR',
    'every anticommuting sign on the cube is a gauge transform of the Jordan-Wigner string, and the Bravyi-Kitaev encoding is another gauge: build the Bravyi-Kitaev operators for n <= 8 and show the sign cocycles differ by a coboundary',
    'cat_check.py K1d (128 sign assignments, one gauge orbit, n = 3); mjp_fock.py', 'numpy: both encodings as 2^n x 2^n matrices, relations and the unitary between them'),
  'CAND-104': n('S', 'extend', false, 'CATLAT',
    'the face poset of the n-cube is the poset of intervals of 2^[n]; polar duality onto the cross-polytope; f-vectors 2^(n-k) C(n,k) and 2^(k+1) C(n,k+1); the Moebius function (-1)^(|T - S|)',
    'shapes_selfcheck.py (face counts 3^n, f-vectors); mjg_cube.py bd.mjg.19; cat_check.py cat.K1a', 'direct enumeration of intervals'),
  'CAND-105': n('S', 'extend', false, 'CATLAT',
    'the number of (x,y) with x^2 - xy + y^2 = N is 6 sum_(d|N) chi_(-3)(d), zero for N = 2 mod 3: compare for N up to 10^4 (baez.T1a has N <= 7)',
    'baez_check.py T1a', 'divisor sum with the character mod 3'),
  'CAND-106': n('S', 'extend', false, 'CATLAT',
    'the number of up-sets of B_k is the Dedekind number 2, 3, 6, 20, 168, 7581, 7828354: bd.mjc.31 has the first six; the sixth (k = 6) by enumeration of antichains',
    'mjc_comma.py bd.mjc.31', 'monotone Boolean functions of k variables by recursion on k'),
  'CAND-107': n('S', 'new', false, 'CATLAT',
    'the weight lattice of A2 with the Killing-normalised form scaled by 3/2 is the Eisenstein lattice with norm x^2 - xy + y^2: roots are the norm-3 vectors, the weights +-w_k the norm-1 vectors; the root lattice has index 3',
    'baez_check.py T1b (the 126 roots of e7 projected onto the Eisenstein lattice)', 'integer arithmetic on Z[omega]'),
  'CAND-108': n('S', 'edit', false, 'WIRECAND',
    'state the lemma once and give the scheme an evidence class "identity, randomised, failure at most epsilon": a2_sampling.py and a2b_strong_sampling.py already carry the bound and the calibration; the work is a decision of the vocabulary (status words) and its rows',
    'a2b_strong_sampling.py (strong sampler, calibration on false identities, fault M6)', 'the lemma (Schwartz, Zippel) recalled; b2_strong.py derives the degree per identity'),
  'CAND-109': n('S', 'wire', false, 'WIRECAND',
    'the vertex figures of 4_21, 3_21, 2_21, 1_21, 0_21 have 56, 27, 16, 10, 6 vertices (grade-1 pieces, baez.E1b); the graph of 2_21 is the Schlafli graph, its complement srg(27,10,1,5) (baez.E2d, T13)',
    'baez_check.py E1b, E2d; check_T13.py', 'check_T13.py own engine', { via: ['selfcheck/reports/baez_check.py', 'researchers_checks/check_T13.py'] }),
  'CAND-110': n('S', 'wire', false, 'WIRECAND',
    'the principal symbol of a Dirac-type operator is Clifford multiplication, sigma(xi)^2 = Q(xi), hyperbolic exactly for Lorentzian Q (check_T16.py, every signature and module); linearised gravity: the kernel is gauge off the null cone and n(n-3)/2 more on it, n = 3, 4, 5 (d2_linearised.py)',
    'check_T16.py; d2_linearised.py', 'check_T16.py own engine; d2_linearised.py [std] route', { via: ['researchers_checks/check_T16.py', 'selfcheck/gravity/d2_linearised.py'] }),
  'CAND-111': n('S', 'wire', false, 'WIRECAND',
    'a positive functional vanishes on every nilpotent *-ideal (Cauchy-Schwarz) and a Frobenius form kills no non-zero ideal: Theorem 1, 2 and the corollary of T15 on all 34 signatures n <= 4; cat_frobenius.py',
    'check_T15.py; cat_frobenius.py', 'check_T15.py own engine (Gram matrix positivity as a finite problem)', { via: ['researchers_checks/check_T15.py', 'selfcheck/bridges/cat_frobenius.py'] }),
  'CAND-113': n('S', 'wire', false, 'WIRECAND',
    'the T-invariant real algebra of p T-even and q T-odd Majoranas is the bit rule of Cl(p,q); the generic edge degeneracy is 1 exactly when the clock is 0 mod 8; a Lagrangian of w exists exactly then; stacks of chains give winding p - q (bd.sol.1-8); the dimerised chain with N <= 8 by exact diagonalisation is the one line to add',
    'sol_fk_clock.py bd.sol.1-8; sol_furey_fk.py', BRG + ' (numpy spectra inside)', { via: ['selfcheck/bridges/sol_fk_clock.py'] }),
  'CAND-114': n('S', 'wire', false, 'WIRECAND',
    'grad F = J implies grad.J = 0 (the grade-0 part of grad grad F vanishes for a bivector F), exact on random polynomial fields in every Cl(k,d) with k + d <= 7: the charges block of maxwell_selfcheck.py and RSN-025',
    'maxwell_selfcheck.py', 'sol_maxwell_media.py bd.sol.14-17 (independent bridge)', { via: ['selfcheck/maxwell_selfcheck.py'] }),
  'CAND-116': n('S', 'extend', false, 'SOLID',
    'for each cell: the commutant of the minimal module is R, C or H (Frobenius-Schur, bd.sol.23), the H-structure for clock 4, 5, 6, and every operator commuting with it has doubly degenerate eigenvalues (Kramers); the level-repulsion exponent cannot be checked',
    'sol_point_groups.py bd.sol.23; sol_fk_clock.py bd.sol.3; @cliff', 'numpy eigenvalues of random operators in the commutant'),
  'CAND-119': n('S', 'wire', false, 'WIRECAND',
    'n fermionic modes and n qubits have the same algebra: Cl(n,n) = M_2(R)^(x n) via c_j = (prod_(k<j) Z_k) sigma_j^-: bd.mjp.1 and bd.mjp.3 (the Fock ideal; the CAR; the Jordan-Wigner matrix) and bd.mjc.8 (Cl(n,n) relations with the creators)',
    'mjp_fock.py bd.mjp.1-3; mjc_labels.py bd.mjc.8', BRG, { via: ['selfcheck/bridges/mjp_fock.py', 'selfcheck/bridges/mjc_labels.py'] }),
  'CAND-120': n('S', 'wire', false, 'WIRECAND',
    'global phase invariance gives the conserved current psi gamma0 psi~ and its divergence vanishes on shell: the conservation block of coupling_selfcheck.py and the current of matter_selfcheck.py (adjoint covariance, D.j = 0 at E = 0)',
    'coupling_selfcheck.py; matter_selfcheck.py', 'coupling_matrix_check.py and matter_matrix_check.py (independent)', { via: ['selfcheck/coupling_selfcheck.py', 'selfcheck/matter_selfcheck.py'] }),
  'CAND-122': n('S', 'extend', false, 'DIRAC',
    'with a chosen gamma0 the bivectors sigma_k = gamma_k gamma_0 of Cl(1,3) generate the Pauli algebra; E and B are the relative-vector and relative-bivector parts of F: exact on the basis and on a random field (hest_check.py H-group holds the spacetime algebra)',
    'reports/hestenes/hest_check.py (own spacetime algebra); @br', 'numpy Pauli matrices, E and B from the field tensor'),
  'CAND-123': n('S', 'new', false, 'POLAR',
    'the top-blade form is the Berezin integral: lambda(exp B) on Cl(0,0,n) equals the Pfaffian Pf(A) of the antisymmetric matrix of B, exact for n <= 10; in the other cells use the wedge exponential',
    '@br with null generators (exp as a wedge series)', 'Pfaffian by exact fraction-free elimination'),
  'CAND-124': n('S', 'new', false, 'YM',
    'the BPST instanton (regular gauge, rational in x) is a self-dual so(4) connection with F = *F and D*F = 0 at rational points, with integer topological charge; the Wu-Yang monopole is a static so(3) solution',
    '@forms on Cl(4,0) bivectors; yangmills_selfcheck.py structure constants', 'numpy: textbook eta symbols and finite differences; the second Chern number by quadrature'),
  'CAND-126': n('S', 'extend', false, 'DIRAC',
    'in Spin(1,3) the stabiliser of a timelike momentum is SU(2) (dimension 3) and that of a null momentum is E(2) (bd.phy.5-6): compute the even versors that commute with p for the timelike case; spin at rest from the mass shell',
    'phy_horizon_little_group.py bd.phy.5-6; @br', 'numpy: Lie algebra of the stabiliser in so(1,3)'),
  'CAND-128': n('M', 'new', false, 'GRAVEM',
    'Fermi-Walker transport of a spin bivector along a geodesic: the de Sitter geodetic and Lense-Thirring precessions, as exact series with the engine\'s connection on Schwarzschild and Kerr-Schild frames',
    '@forms connection along a geodesic (g2_forque_observers.py transport)', 'closed-form precession rates (Schiff, recalled) and numpy ODE integration'),
  'CAND-129': n('S', 'extend', false, 'SOLID',
    'a Z-grading with generator N is conserved iff [H, N] = 0: H = -t sum c+c + U sum n n conserves N, pairing terms break it to the parity (-1)^N; compute [H,N] and [H,(-1)^N] on Cl(n,n) for n <= 6 (bd.sol.31 has the Hubbard cube)',
    'sol_hubbard_cube.py bd.sol.31; mjp_fock.py', 'numpy: Jordan-Wigner matrices of H, N'),
  'CAND-130': n('S', 'wire', false, 'WIRECAND',
    'real 4-component spinors exist when the algebra is a real matrix algebra: Cl(3,1) = M4(R) with an explicit real representation and the real Dirac operator with the physical mass shell; Cl(1,3) = M2(H) needs a charge conjugation (check_T16.py)',
    'check_T16.py (Cl(3,1) with real 4 x 4 gammas); phy_dirac.py', 'check_T16.py own engine', { via: ['researchers_checks/check_T16.py'] }),
  'CAND-135': n('S', 'extend', false, 'POLAR',
    'the super-dimension of Lambda(R^n) is str 1 = sum (-1)^|a| = 0 (T20 d) and the Witten index of a small supersymmetric Hamiltonian is stable under deformation, n <= 6',
    'check_T20.py (sdim = 0); cat_check.py cat.B1', 'numpy: spectra of a deformed SUSY Hamiltonian, index by trace'),
  'CAND-136': n('S', 'extend', false, 'SM16',
    'Cl(0,10) gives the compact so(10) acting unitarily on a complex 32 with J chosen; Cl(5,5) gives the split so(5,5) acting on a real 32, non-unitarily: signatures of the Killing form and the invariant Hermitian form',
    'baez_check.py H3c (45 bivectors of Cl(5,5) close); @cliff Cl(0,10)', 'numpy: Killing form signature, positive-definite invariant form by averaging'),
  'CAND-138': n('S', 'new', false, 'GRAVEM',
    'the Kerr-Schild form g = eta + (2M/r) k k of Schwarzschild maps to the Coulomb potential A = (Q/r) k with the same null k: A solves grad F = 0 away from the source and g is vacuum; both sides on the engine',
    'c2_kerr.py, c3_rn.py frames; maxwell_selfcheck.py', 'closed-form Coulomb field and the Schwarzschild metric (textbook)'),
  'CAND-139': n('M', 'new', false, 'GRAVEM',
    'Maxwell, the massless Dirac equation and Yang-Mills in four dimensions are covariant under the special conformal generators K_a of so(2,4): the Lie derivative of exact solutions with the conformal weight',
    'h5l_conformal.py (so(2,4) Cartan connection); maxwell_selfcheck.py', 'the Bateman-Cunningham transformations (recalled) on plane-wave and Coulomb solutions'),
  'CAND-140': n('M', 'new', false, 'EMB',
    'the 120 unit quaternions of the binary icosahedral group in the even part of Cl(3,0): its character table, and the McKay graph of the 2-dimensional representation is the affine E8 diagram with the marks as dimensions',
    '@br Cl(3,0) even part, closure of the generators to 120 elements', 'numpy: Burnside-Dixon character table; marks from check_T10.py'),
  'CAND-141': n('S', 'extend', false, 'POLAR',
    'for H = sum eps_i n_i the Gibbs state is a state in the sense of T15, Z = prod (1 + e^(-beta(eps_i - mu))) (bd.mjp.22) and the occupations are the Fermi-Dirac function: exact on the labels for n <= 8',
    'mjp_action.py bd.mjp.22; check_T15.py', 'closed form per mode; numpy trace of exp(-beta(H - mu N))'),
  'CAND-144': n('S', 'wire', false, 'WIRECAND',
    'the 3 x 3 square of two-qubit Pauli observables: row and column products fixed, product of all signs -1 under all 512 re-signings, no solution among 512 assignments (check_T11.py 4): only the wording of LNS-038 changes',
    'check_T11.py', 'check_T11.py own engine', { via: ['researchers_checks/check_T11.py'] }),
  'CAND-145': n('M', 'extend', false, 'SOLID',
    'the double groups as subgroups of the even part of Cl(3,0) (2.A4, 2.A5, the binary octahedral group): characters and the splittings of j = 1/2 and 3/2 (bd.sol.21-22 give the sign tables and integral traces)',
    'sol_point_groups.py bd.sol.21-22; @br', 'numpy: group closure and character table; the Bethe splitting tables (recalled)'),
  'CAND-147': n('S', 'wire', false, 'WIRECAND',
    'Cl(1,3) = M2(H) and Cl(3,1) = M4(R) have the same even part M2(C); the tangent algebra of a null hypersurface is Cl(0,n-2,1) in one convention and Cl(n-2,0,1) in the other: clock and type of both cells and both even parts exactly (core.B16, B19, B20; bd.str.6)',
    'core_check.py core.B16, B19, B20; str_spinors.py bd.str.6', BRG, { via: ['selfcheck/core_check.py', 'selfcheck/bridges/str_spinors.py'] }),
  'CAND-150': s('source', 'the formula pi Lambda a^3 sqrt(1 - e^2)/(G M) is computed in d5_perihelion.py and GRV-007; the comparison needs the printed formula, which the package does not hold'),
};

// ---------------------------------------------------------------------------------------------------------------------------- the cell of the bit route
// A row names the cells it lives in (content/rows.json, field "cells": Cl(p,q,r) written (p,q,r)); the list prints them in the column "cell". A candidate
// has no such field: the cell in which its check runs is written here, once per candidate (a label space or a structure when no Clifford cell is meant).
const CELL_CAND = {
  'CAND-001': 'Cl(1,3) with one extra generator of square -1, 0, +1',
  'CAND-003': 'the 16 even labels of 5 bits; Cl(5,5) on the Fock space of 5 modes; Cl(0,10)',
  'CAND-008': 'Cl(n,n), n <= 4',
  'CAND-011': 'Cl(0,m) gauge algebra, m = 3, 4; Cl(1,3)',
  'CAND-012': 'Cl(1,3), even part',
  'CAND-015': 'Cl(1,3) with torsion',
  'CAND-020': 'roots of E7 in the D8+ coordinates',
  'CAND-021': 'roots of E7 in the D8+ coordinates',
  'CAND-023': 'Cl(9,0) spinor module; f4 inside h3(O)',
  'CAND-024': 'Cl(p,q), p + q = 2k',
  'CAND-027': 'Lie tables of so(1,n-1) x R^n, so(1,n), so(2,n-1), so(m); forms on n coordinates',
  'CAND-030': 'Cl(1,3) with the null pair (projective ladder)',
  'CAND-035': 'the n-cube graph, n <= 7',
  'CAND-036': 'Cl(3,0,1), free bodies',
  'CAND-037': 'Cl(1,3) frames',
  'CAND-039': 'Cl(1,3)',
  'CAND-044': 'the 16 even labels of 5 bits',
  'CAND-045': 'Cl(1,3), even part',
  'CAND-046': 'the 3-cube hopping model',
  'CAND-047': 'the n-cube lattice, su(2) links',
  'CAND-048': 'Cl(5,5) on the Fock space of 5 modes',
  'CAND-050': 'the E8 lattice mod 2 (F2^8)',
  'CAND-051': 'Cl(p,q,r), p + q + r <= 6',
  'CAND-052': 'roots of E8',
  'CAND-053': 'Cl(p,q,r)',
  'CAND-054': 'Cl(p,q), even part (motors, rotors)',
  'CAND-055': 'Cl(p,q,r), p + q + r <= 8',
  'CAND-056': 'End(V) for Cl(0,2) = H and the Furey fibre Cl(0,8)',
  'CAND-057': 'Cl(p,q), n <= 8 (Z4 form)',
  'CAND-058': 'Cl(p,q,r), n <= 10',
  'CAND-059': 'O(Q) over F2 of E_n/2E_n, n <= 200',
  'CAND-061': 'Lambda(V) = Cl(0,0,n)',
  'CAND-062': 'the 32 labels of 5 bits; Lambda(C^n)',
  'CAND-063': 'Cl(8,0) label quadric over F2; the weights of D4',
  'CAND-064': 'Cl(8,0) label quadric over F2',
  'CAND-069': 'Cl+(1,n-1), n = 5..8',
  'CAND-070': 'octonions: Cayley-Dickson algebras of dimension 1 to 16, split octonions',
  'CAND-075': 'Cartan matrices of E10 and E11',
  'CAND-076': 'Cl(p,q), n <= 6',
  'CAND-078': 'Cl(3,0), Cl(1,2), Cl(1,3), Cl(2,2), Cl(3,3), Cl(2,4), Cl(1,5)',
  'CAND-082': 'roots of E6 and F4',
  'CAND-083': 'Cl(p,q), commuting blades; Cl(0,8) (Hamming words)',
  'CAND-085': 'the Kerr-Newman family in Kerr-Schild frames',
  'CAND-087': 'Sym^2(Lambda^2 V), n = 2..8',
  'CAND-089': 'Cl(1,3), Weyl tensor as Q = E + iB',
  'CAND-090': 'the 36 and 21 cells of the constitutive tensor',
  'CAND-091': 'Cl(p,q,r), r <= 3, n <= 9',
  'CAND-092': 'the cube category B_n',
  'CAND-093': 'the cube B_n',
  'CAND-094': 'Z2^3 twisted group algebra (octonions)',
  'CAND-095': 'finite categories (584 and a zoo)',
  'CAND-096': 'the Boolean lattice B_n, n <= 6',
  'CAND-097': 'finite categories, six base categories',
  'CAND-098': 'Cl(n,n) Peirce idempotents; the Furey model Cl(0,8)',
  'CAND-100': 'the Boolean lattice B_n',
  'CAND-101': 'the lattices I_(p,q)',
  'CAND-102': 'Cl(0,8)',
  'CAND-103': 'Cl(n,n), n <= 8',
  'CAND-104': 'the face poset of the n-cube',
  'CAND-105': 'the Eisenstein lattice',
  'CAND-106': 'the Boolean lattice B_k, k <= 6',
  'CAND-107': 'the A2 lattice (E7 roots projected)',
  'CAND-108': 'identities on the gravity engine (random fields)',
  'CAND-109': 'roots of E8 > E7 > E6 > D5 > A4',
  'CAND-110': 'Cl(p,q) symbols; linearised gravity, n = 3, 4, 5',
  'CAND-111': 'Cl(p,q), n <= 4 (34 signatures)',
  'CAND-113': 'Cl(p,q), p + q <= 8 (T-invariant Majorana algebra)',
  'CAND-114': 'Cl(k,d), k + d <= 7',
  'CAND-116': 'Cl(p,q), every cell',
  'CAND-119': 'Cl(n,n)',
  'CAND-120': 'Cl(1,n-1), even part',
  'CAND-122': 'Cl(1,3)',
  'CAND-123': 'Cl(0,0,n), n <= 10',
  'CAND-124': 'Cl(4,0) bivectors (so(4)) on Euclidean R^4',
  'CAND-126': 'Cl(1,3)',
  'CAND-128': 'Schwarzschild and Kerr in Kerr-Schild frames',
  'CAND-129': 'Cl(n,n), n <= 6',
  'CAND-130': 'Cl(3,1) and Cl(1,3)',
  'CAND-135': 'Lambda(R^n) = Cl(0,0,n)',
  'CAND-136': 'Cl(0,10) and Cl(5,5)',
  'CAND-138': 'Schwarzschild in Kerr-Schild frame',
  'CAND-139': 'Cl(1,3) with so(2,4)',
  'CAND-140': 'Cl(3,0), even part',
  'CAND-141': 'Cl(n,n), n <= 8',
  'CAND-144': 'Cl(2,2) (two qubits)',
  'CAND-145': 'Cl(3,0), even part',
  'CAND-147': 'Cl(1,3) and Cl(3,1)',
  'CAND-150': 'Schwarzschild-de Sitter',
};
// rows whose field "cells" is empty or only names a line of the row
const CELL_ROW = {
  'LNB-016h': 'roots of E7 in the D8+ coordinates', 'LNB-043': 'roots of E7 in the D8+ coordinates',
  'LNB-021g': 'root systems of F4, E6, Spin(10)', 'LNB-035': 'root systems of F4, E6, Spin(10)', 'LNB-035b': 'root systems of F4, E6, Spin(10)',
  'LNB-038': 'root systems of F4, E6, Spin(10)', 'LNB-045': 'root systems of F4, E6, Spin(10)', 'LNB-117': 'root systems of F4, E6, Spin(10)',
};
/** the cell column of an item: the cells the row names (rows.json), or the note of the candidate */
function cellOf(it) {
  if (it.cls === 'cand') return CELL_CAND[it.id] || '';
  const own = ((it.row && it.row.cells) || []).filter(c => !/^row \d+$/.test(c));
  return CELL_ROW[it.id] || own.slice(0, 4).join(', ') || '';
}

// ---------------------------------------------------------------------------------------------------------------------------- the groups of work and the leads
// A group of work (a "pack") collects the ranked statements that one script, or one reading of a few scripts, closes. The eight best-ranked groups are the
// eight leads, numbered in the order of the best rank each holds; validate() fails if the numbering and the ranking part.
const PACKS = {
  FUREY: 'Furey page: re-point the evidence to the asserting script and add the second route',
  STEPS: 'the Logbook lines of the step pages: name the step\'s check',
  CATW: 'the category and report-lens rows: name the check, or write the one missing line',
  SM16: 'the Standard Model labels: anomalies, charges, the 16 of Spin(10), E6 > SO(10)',
  YM: 'the non-abelian action: stationarity, stress, solutions',
  POLAR: 'Pauli groups, polar spaces, Fock and encodings, quadratic forms',
  WIRECAND: 'candidates that a passing check already decides',
  GRAVEM: 'exact identities on the gravity and Maxwell engines',
  RANGE: 'ranges to theorems, symbolic in n',
  EMB: 'root-system embeddings and branchings (the Baez questions)',
  DIRAC: 'the Dirac-Hestenes equation: limits and symmetries',
  SOLID: 'solid-state checks on the cube: Lieb, Hubbard, Kramers, double groups, the tenfold way',
  MEDIA: 'the area metric and the constitutive tensor: decompositions and the closure',
  CATLAT: 'categories and posets, small lattice counts, kinematical algebras, rigid-body stability, T17 (one lead, small scripts each)',
  CAT: 'categories and posets',
  KIN: 'kinematical algebras',
  MECH: 'rigid-body stability',
  THM: 'theorem gaps (T17)',
  LAT: 'small lattice counts',
};
const LEADS = {
  STEPS: { id: 'L7-01', title: 'The step checks behind the Logbook lines', model: 'Sonnet', size: 'S to M', newFiles: ['step_lines.py'] },
  FUREY: { id: 'L7-02', title: 'Furey: the asserting script, its bit-rule second route, the sentences', model: 'Sonnet', size: 'M', newFiles: ['furey_bit_route.py'] },
  CATW: { id: 'L7-03', title: 'The category and report-lens rows', model: 'Sonnet', size: 'S to M', newFiles: ['catw_lines.py'] },
  SM16: { id: 'L7-04', title: 'Standard Model labels: charges, anomalies, the 16 and the 27', model: 'Sonnet', size: 'S to M', newFiles: ['sm16_labels.py', 'e6_so10_branching.py'] },
  YM: { id: 'L7-05', title: 'The non-abelian action: stationarity, stress, classical solutions', model: 'Opus', size: 'M', newFiles: ['ym_action.py', 'ym_solutions.py', 'ym_algebras.py', 'ym_matter_gravity.py'] },
  POLAR: { id: 'L7-06', title: 'Pauli groups, quadrics and Fock encodings', model: 'Sonnet', size: 'M', newFiles: ['polar_spaces.py', 'fock_encodings.py'] },
  WIRECAND: { id: 'L7-07', title: 'Candidates that a passing check already decides', model: 'Sonnet', size: 'M', newFiles: ['composition_basis.py'] },
  GRAVEM: { id: 'L7-08', title: 'Exact identities of the gravity and Maxwell engines', model: 'Opus', size: 'M', newFiles: ['gm_null_sphere.py', 'gm_maxwell_stress.py', 'gm_cube_framework.py', 'gm_smarr_euler.py', 'gm_petrov_ii_iii.py', 'gm_double_copy.py', 'gm_cartan_bianchi.py', 'gm_dust_geodesic.py', 'gm_gyroscope.py', 'gm_conformal.py'] },
  SOLID: { id: 'L7-11', title: 'Solid state on the cube: Lieb, Hubbard, Kramers, double groups, the tenfold way', model: 'Sonnet', size: 'M', newFiles: ['solid_cube.py'] },
  RANGE: { id: 'L7-12', title: 'Ranges to theorems: symbolic in n where a closed form exists', model: 'Sonnet', size: 'S to M', newFiles: ['ranges_n.py'] },
  DIRAC: { id: 'L7-13', title: 'The Dirac–Hestenes equation: limits, symmetries, the massless conformal clause', model: 'Opus', size: 'M', newFiles: ['dirac_limits.py'] },
  EMB: { id: 'L7-14', title: 'The E-series ladder: embeddings and branchings to the top (the Baez questions)', model: 'Opus', size: 'L', newFiles: ['e_ladder.py'] },
  MEDIA: { id: 'L7-15', title: 'The area metric and the constitutive tensor: decompositions and the closure', model: 'Opus', size: 'L', newFiles: ['area_metric.py'] },
  CATLAT: { id: 'L7-16', title: 'Categories, posets, small lattices, kinematical algebras, the rigid body, T17', model: 'Sonnet', size: 'M', newFiles: ['cat_lat.py', 'kin_mech.py'] },
};
const LEAD_ORDER = ['STEPS', 'FUREY', 'CATW', 'SM16', 'YM', 'POLAR', 'WIRECAND', 'GRAVEM', 'SOLID', 'RANGE', 'DIRAC', 'EMB', 'MEDIA', 'CATLAT'];   // L7-09 (defects), L7-10 (the opened statements), L7-17 (the open clauses of the engines) and L7-18 (defects) are closing leads, not packs of this list

// ============================================================================================================================ rendering
const LICENCE_MD = `<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->
`;
const table = (head, rows) => ['| ' + head.join(' | ') + ' |', '|' + head.map(() => '---').join('|') + '|', ...rows.map(r => '| ' + r.map(esc).join(' | ') + ' |')].join('\n');
const leadId = it => (it.note && it.note.lead && LEADS[it.note.lead] ? LEADS[it.note.lead].id : (it.note && it.note.lead === 'PRIME' ? 'prime lab' : '—'));
const costWork = it => (it.note && !it.note.skip ? `${it.note.cost} · ${it.note.work}` : '—');
const yn = b => (b ? 'yes' : 'no');
const mark = it => it.id + (it.b3 ? ' †' : '');

function render(M, T, N, ranked, problems) {
  const c = counts(M, N);
  const out = [];
  const P = (...a) => out.push(...a);
  const notesOf = arr => arr.filter(i => i.note && !i.note.skip);
  const workCount = (arr, w) => notesOf(arr).filter(i => i.note.work === w).length;

  P(LICENCE_MD);
  P('# PROOFS_TODO — the statements that wait for a check', '');
  P('Written by `node tools/proofs_todo.mjs` from the tables of `content/` (rows, texts, derived status, checks, runs, candidates, theorems, pages, leads). Do not edit it by hand: change a table, or the notes at the end of the tool, and run the tool again. `node tools/proofs_todo.mjs --check` fails when this file, the notes or the tables disagree.', '');
  if (problems.length) P('**Problems found while writing this file:**', ...problems.map(p => '- ' + p), '');

  P('## 0. What is listed, and how it is ranked', '');
  P('A statement is **missing its proof** (decision R7-8) when its computed status is `cited` (a script is named, no passing run is recorded), or `ours` with a kind that states something checkable (not `reading`), or `open` as a question or conjecture whose answer a finite computation gives, or when it is a candidate that the personas marked checkable "yes". A fifth class is the story: for every page, the chain lead → key results is complete when every key result is `proved-by-atlas` or `standard`.', '');
  P('**Ranking.** Statements that would be false as printed if wrong come first; then the cost of the check, S before M before L (S: an afternoon\'s script; M: a day; L: more, or a source the package does not hold); then the number of rows that depend on the statement (the `depends` edges into it); then the id. Every statement carries one kind of work: ' + Object.entries(WORK).map(([k, v]) => `**${k}** (${v})`).join('; ') + '.', '');
  P('**Method of a lead** (`$SP/leads3/COMMON_LEADS3.md` §2–§3): the sentence under test and its wording on pass and on fail are written before the script; a `[bit]` route through the bit rule; a `[std]` route that never touches the engine; controls that must fail; the mutation run where the gravity engine applies. A `wire` item needs only the first and last of these: read the sentence against the script, name the script, and show that a changed number in the sentence would make an assert fail.', '');

  P('## 1. The counts', '');
  const sk = c.open.skipped;
  P(table(['class', 'in the class (by status or table)', 'on the ranked list', 'not on it, and why'], [
    ['cited', `${c.cited.total} rows`, `${c.cited.total}`, `none; ${c.cited.fw} would be false as printed if wrong`],
    ['ours', `${c.ours.all} rows (${c.ours.readings} of kind reading, left out by R7-8)`, `${c.ours.core}`, `${c.ours.retag} of the ${c.ours.claims} non-reading rows are not missing proofs: ${Object.entries(c.ours.skipped).map(([k, v]) => `${v} ${k}`).join(', ')}; see section 5`],
    ['open', `${c.open.total} rows`, `${c.open.computable}`, Object.entries(sk).map(([k, v]) => `${v} ${k}`).join(', ') + '; see section 6'],
    ['candidates', `${c.cand.all} (yes ${c.cand.yes}, partly ${c.cand.partly}, no ${c.cand.no}; ${c.cand.rows} more are rows now)`, `${c.cand.yes - c.cand.nSkipped}`, `${Object.entries(c.cand.skipped).map(([k, v]) => `${v} ${k}`).join(', ')}; "partly" and "no" are outside R7-8`],
    ['story chains', `${c.chains.research.pages} pages with key results at research level, ${c.chains.learner.pages} at learner level`, `${c.chains.research.incomplete} + ${c.chains.learner.incomplete} incomplete`, `${c.chains.research.complete} + ${c.chains.learner.complete} complete; see section 8`],
  ]), '');
  P(`In all, **${ranked.length}** statements are ranked. Rows of the other statuses are not on the list: \`proved-by-atlas\` ${Object.values(T.status).filter(x => x.status === 'proved-by-atlas').length} (each has a ran check whose last recorded run passed), \`standard\` ${Object.values(T.status).filter(x => x.status === 'standard').length} (a textbook statement carrying its source), \`input\` ${Object.values(T.status).filter(x => x.status === 'input').length} (a choice of the model), \`meta\` ${Object.values(T.status).filter(x => x.status === 'meta').length} (narration and statements about the Atlas).`, '');
  P('### What the reading of the tables shows', '');
  const wireC = workCount(M.cited, 'wire') + workCount(M.oursClaims, 'wire') + workCount(M.openAll, 'wire') + workCount(M.candYes, 'wire');
  P(`1. **Most of the work is naming a check that already passes.** Of the ${c.cited.total} cited rows, ${workCount(M.cited, 'wire')} are decided by a script of \`checks/\` whose last recorded run passed (${workCount(M.cited, 'extend')} more in part, ${workCount(M.cited, 'edit')} are descriptions); the row's evidence names an exploratory printout that is not shipped (the four Furey tests), a check id without a script, or nothing. Of the ${c.cand.yes} checkable candidates ${workCount(M.candYes, 'wire')} are already checked in the bridges, the report scripts or the theorem scripts, and ${workCount(M.candYes, 'extend')} more in part. In all ${wireC} of the ${ranked.length} ranked statements are \`wire\`; the clauses were matched to the scripts' docstrings and check ids, and the lead re-reads each against the asserts.`);
  P(`2. **The ours class is mostly readings.** ${c.ours.retag} of the ${c.ours.claims} non-reading \`ours\` rows say "ours" or "our reading" in their own words; the v15 line split gave the second line the kind of the first. Only ${c.ours.core} have a check to attach or write.`);
  P(`3. **The open class has ${c.open.computable} computable questions**, in ${uniq(notesOf(M.openAll).map(i => i.note.lead)).length} groups of work (for example the Baez embeddings, the non-abelian action, the Standard Model labels, the closure of the area metric); the other ${c.open.total - c.open.computable} open rows are names, stated limits, questions to print, or questions of meaning.`);
  P(`4. **${M.openWithChecked.length} open rows also state a checked result** (a legacy "checked" line with a passing run on its evidence): the status of the question around the sentence hides the proof of the sentence. Section 6 lists them.`);
  P(`5. **${c.chains.research.incomplete} of ${c.chains.research.pages} page chains are incomplete at research level** (${c.chains.learner.incomplete} of ${c.chains.learner.pages} at learner level). ${chainBreakSummary(M, N)}`, '');

  {
    const rr = ranked.filter(i => i.cls !== 'cand' && !i.note.skip && i.note.work !== 'edit');
    const edited = ranked.filter(i => i.cls !== 'cand' && i.note.work === 'edit').map(i => i.id);
    const grp = (f) => rr.filter(i => f(i.edits)).map(i => i.id);
    const has = (e, k) => e.includes(k);
    const gE = grp(e => e.length === 1), gF = grp(e => has(e, 'flag') && !has(e, 'kind')), gK = grp(e => has(e, 'kind') && !has(e, 'flag')), gFK = grp(e => has(e, 'flag') && has(e, 'kind'));
    P('### What a passing check changes in a row', '');
    P('The status is computed (`tools/build_content.mjs`), never typed. A passing check turns a ranked row into `proved-by-atlas` only through data edits that the check itself does not make: the evidence entry `{ "check", "script", "mode": "ran" }`; the legacy flag `checked` where the row has legacy flags without it; and, for a row of kind question, conjecture or pointer or of ptype open, a split that makes the checked sentence a result line of its own (a row of that kind stays `open` whatever it has run). Candidates are not rows: one becomes a `CAND-` row when the author accepts it, and the script is its evidence.', '');
    P(table(['after a passing check the row needs', 'rows', 'ids'], [
      ['the evidence entry only', gE.length, gE.join(', ')],
      ['the evidence entry and the flag `checked`', gF.length, gF.join(', ')],
      ['the evidence entry and a split of the line (kind, ptype)', gK.length, gK.join(', ')],
      ['all three', gFK.length, gFK.join(', ')],
    ]), '');
    if (edited.length) P(`The ${edited.length} rows of work \`edit\` (${edited.join(', ')}) need no evidence: the row, not the mathematics, is to change.`, '');
  }

  // ---------------------------------------------------------------- 2. top twenty
  P('## 2. The top twenty', '');
  const top = ranked.slice(0, 20);
  P(`One line each: rank, id, class, page, cost · work, the number of rows that rest on it, the lead that takes it, and what a check computes.${top.every(i => i.note.fw) ? ' Each would be false as printed if wrong; the ranking among them is by cost and by how many rows rest on the statement.' : ''}`, '');
  top.forEach(it => P(`${it.rank}. **${mark(it)}** · ${it.cls} · ${it.page} · ${costWork(it)} · ${it.nDep} rest on it · ${leadId(it)} — ${words(expand(it.note.w), 26)}`));
  if (top.some(i => i.b3)) P('', '† a lead of the third batch (R7-6) changes the wording of the row; its evidence changes when the ledger is applied, so run the tool again after the apply.');
  P('');
  const ft = ranked.filter(i => i.note.fw).length;
  P(`The first ${ft} ranked statements would be false as printed if wrong; from rank ${ft + 1} on, a wrong statement would be a missing claim, not a false one.${top.every(i => i.note.cost === 'S') ? ' The first twenty are all of cost S.' : ''}`, '');

  // ---------------------------------------------------------------- 3. the leads
  P('## 3. The leads', '');
  P('A lead groups the statements that one script, or one reading of a few scripts, closes. The eight briefs are in `docs/round7/leads/`, in the order of the best-ranked statement each holds. The prime lab has its own brief (`$SP/v16_briefs/agent_prime_lab.md`) and is listed here, not briefed again.', '');
  const packs = new Map();
  for (const it of ranked) { const k = it.note.lead || '—'; if (!packs.has(k)) packs.set(k, []); packs.get(k).push(it); }
  const leadRows = LEAD_ORDER.map(k => {
    const L = LEADS[k], items = packs.get(k) || [];
    return [L.id, L.title, L.model, `${L.size}`, `${items.length}`, items.slice(0, 14).map(i => i.id).join(', ') + (items.length > 14 ? ` +${items.length - 14}` : ''), items.length ? `${items[0].rank}` : '—'];
  });
  P(table(['lead', 'title', 'model', 'size', 'statements', 'ids', 'best rank'], leadRows), '');
  const others = [...packs.entries()].filter(([k]) => !LEAD_ORDER.includes(k) && k !== '—');
  P('Groups of work without a brief yet: ' + (others.length ? others.map(([k, v]) => `${k} (${v.length}; best rank ${v[0].rank})`).join(', ') : 'none') + '. A lead whose statements are all proved keeps its brief as the record of the closing (its statements are no longer listed).', '');

  // ---------------------------------------------------------------- 4. cited
  P(`## 4. Class A — cited (${M.cited.length})`, '');
  P('Status `cited`: the v15 flag "checked" survived; the evidence names no script that ran and passed. The evidence of the Furey rows names `peirce_test.py`, `witt_test.py`, `z2_test.py` and `family_test.py`; none of the four is in `checks/` (the recorded runs of the first three only print tables, that of `family_test.py` passed). The script that asserts the Peirce structure is `run_all.py`, which imports a `model.py` that is not in `checks/` either (it sits in `checks/reports/furey/`), so it runs from that folder and not from `checks/`.', '');
  const COLS = ['#', 'id', 'page', 'statement (at most 20 words)', 'a check would compute', 'bit route', 'cell', 'standard route', 'cost · work', 'depends on', 'rest on it', 'false if wrong', 'lead'];
  // a note shared by several rows (one computation, several questions) is printed once; the others say "as <id>"
  const firstOf = new Map();
  const classRow = it => {
    const nt = it.note && !it.note.skip ? it.note : null;
    let w = nt ? expand(nt.w) : '', bit = nt ? expand(nt.bit) : '', std = nt ? expand(nt.std) : '';
    if (nt) { if (firstOf.has(nt)) { const f = firstOf.get(nt); w = `the same computation as ${f}`; bit = `as ${f}`; std = `as ${f}`; } else firstOf.set(nt, it.id); }
    return [it.rank ?? '—', mark(it), it.page, it.statement, w, bit, cellOf(it) || '—', std, costWork(it), it.deps, it.nDep, nt ? yn(nt.fw) : '—', leadId(it)];
  };
  const byRank = (a, b) => (a.rank ?? 1e9) - (b.rank ?? 1e9) || (a.id < b.id ? -1 : 1);
  P(table(COLS, [...M.cited].sort(byRank).map(classRow)), '');
  P('Evidence to add (`content/rows.json`, mode `ran`): for a `wire` note the script named in its `via` list, as `{ "check": <file name without extension>, "script": <path under checks/>, "mode": "ran" }`. All the cited rows carry the legacy flag `checked`, so the evidence entry alone turns them into `proved-by-atlas` (rule of `tools/build_content.mjs`): the last recorded run of each of those scripts passed, and the tool refuses a `via` that has no passing recorded run.', '');

  // ---------------------------------------------------------------- 5. ours
  P(`## 5. Class B — ours, kind not reading (${M.oursClaims.length} of ${c.ours.all})`, '');
  P(`R7-8 leaves out the ${c.ours.readings} ours rows of kind reading. Of the ${c.ours.claims} others, ${c.ours.core} have a checkable core and are ranked here:`, '');
  P(table(COLS, M.oursClaims.filter(i => i.note && !i.note.skip).sort(byRank).map(classRow)), '');
  P(`The other ${c.ours.retag} are not missing proofs. ${Object.entries(countBy(M.oursClaims.filter(i => i.note && i.note.skip), i => i.note.skip)).map(([k, v]) => `${v} ${k}`).join(', ')}: the reasons are one line each.`, '');
  P(table(['id', 'page', 'statement (at most 20 words)', 'class', 'why, when the class does not say'], M.oursClaims.filter(i => i.note && i.note.skip).map(i => [mark(i), i.page, i.statement, i.note.skip, i.note.why || ''])), '');
  P('The proposed edit for the `retag` rows is a data decision of the owner (set `kind` to `reading`, which moves the row out of this list and leaves its text unchanged); it is not made here.', '');

  // ---------------------------------------------------------------- 6. open
  P(`## 6. Class C — open (${M.openAll.length})`, '');
  P(`${c.open.computable} open rows have a computable answer and are ranked. Several are one computation (the Baez embeddings: LNB-021g, LNB-035, LNB-035b, LNB-038, LNB-045, LNB-117; the three label spaces: LNB-033, LNB-033b, LNB-039; the closure constants: LNS-013g, LNS-030, LNS-048; the area-metric map: LNS-028d, LNS-045).`, '');
  P(table(COLS, M.openAll.filter(i => i.note && !i.note.skip).sort(byRank).map(classRow)), '');
  P(`The other ${c.open.total - c.open.computable} open rows, each with its reason:`, '');
  const skipOrder = ['mislabel', 'lab', 'reading', 'plan', 'scope', 'source', 'research'];
  P(table(['id', 'page', 'statement (at most 20 words)', 'class', 'why, when the class does not say'], M.openAll.filter(i => i.note && i.note.skip).sort((a, b) => skipOrder.indexOf(a.note.skip) - skipOrder.indexOf(b.note.skip) || (a.id < b.id ? -1 : 1)).map(i => [mark(i), i.page, i.statement, i.note.skip, i.note.why || ''])), '');
  P('Classes: ' + skipOrder.map(k => `**${k}** (${SKIP[k]})`).join('; ') + '.', '');
  P(`**Open rows that also state a checked result** (${M.openWithChecked.length}): ${M.openWithChecked.join(', ')}. Each has the legacy flag "checked" and a ran check whose last run passed. Their status is open because the row\'s kind is a question or its ptype is open; the clause that was checked is part of the same text. Splitting such a row, as the migration split v15 lines into \`a\` and \`b\` rows, lets each part carry its own status. The data edits for the \`mislabel\` rows above are the same kind of change.`, '');

  // ---------------------------------------------------------------- 7. candidates
  P(`## 7. Class D — candidates marked checkable "yes" (${M.candYes.length} of ${c.cand.all})`, '');
  P(`From \`content/candidates.json\` (docs/labelling/CANDIDATES.md). A candidate is a standard result the rows use without stating it; it becomes a \`CAND-\` row when a check decides it (the proofs round, docs/round7/PROOFS_ROUND2.md: ${c.cand.rows} are rows now, with the evidence they earned, and are counted in the classes above by their status) or when the author accepts it. "Rest on it" is the number of rows the personas linked to it. The \`page\` column is the candidate's field.`, '');
  P(table(COLS, M.candYes.filter(i => i.note && !i.note.skip).sort(byRank).map(classRow)), '');
  const skc = M.candYes.filter(i => i.note && i.note.skip);
  if (skc.length) P('Not ranked:', '', table(['id', 'field', 'statement (at most 20 words)', 'class', 'why'], skc.map(i => [i.id, i.page, i.statement, i.note.skip, i.note.why || ''])), '');
  P(`The candidates marked "partly" (${c.cand.partly}) and "no" (${c.cand.no}) are outside R7-8; their checkNote in the table says which part a check can reach.`, '');

  // ---------------------------------------------------------------- 8. chains
  P('## 8. Class E — story chains', '');
  P('The page model of `src/app/queries.js` (`buildPageModel`) selects, for every body section, the section\'s lead and its first N result rows (five at research level, three at learner level, the section\'s own `key` overriding; the learner rows of the section first at learner level; open rows go to the open fold). The top of the page contributes the hero row and the "at a glance" results (its notes, role note, are pointers and are not counted). A page chain is the lead followed by all these key results. It is **complete** when every key result is `proved-by-atlas` or `standard` (a `meta` row is narration and is skipped). The lead of a story row restates only rows that are proved or standard (the test of the story round guarantees it), so a chain breaks at a key result, never at a lead.', '');
  P(`Pages outside the story (not counted): the ${M.chains.skipped.filter(r => /^explore/.test(r)).length} Explore pages (R7-3 folds them into the Atlas pages) and ${M.chains.skipped.filter(r => !/^explore/.test(r)).join(', ')} (they list tables and have no story).`, '');
  const bc = (lv) => M.chains[lv].reduce((a, p) => { for (const b of p.broken) { const k = breakClass(b, M, N); a[k] = (a[k] || 0) + 1; } return a; }, {});
  P(`At research level ${c.chains.research.complete} of ${c.chains.research.pages} pages are complete; ${c.chains.research.broken} of the ${c.chains.research.links} key results break a chain (${Object.entries(bc('research')).map(([k, v]) => `${v} ${k}`).join(', ')}). At learner level ${c.chains.learner.complete} of ${c.chains.learner.pages} are complete; ${c.chains.learner.broken} of ${c.chains.learner.links} (${Object.entries(bc('learner')).map(([k, v]) => `${v} ${k}`).join(', ')}).`, '');
  const lmap = new Map(M.chains.learner.map(p => [p.route, p]));
  const fmtBreak = b => { const k = breakClass(b, M, N); return `${b.id} (${b.status}${k === 'missing proof' || k === 'mislabel' ? ', ' + k : ''}) @${b.sid}`; };
  const chainRows = M.chains.research.filter(p => !p.complete).map(p => {
    const l = lmap.get(p.route);
    return [p.route, p.lead || '—', `${p.links} in ${p.sections} sections`, `${p.sectionsBroken} of ${p.sections}`, p.broken.map(fmtBreak).join('; '), l ? (l.complete ? 'complete' : l.broken.map(b => b.id).join(', ')) : '—'];
  });
  P(table(['page', 'lead', 'key results', 'sections broken', 'the links that break the chain (research level)', 'learner level'], chainRows), '');
  const learnerOnly = M.chains.learner.filter(p => !p.complete && !M.chains.research.some(r => r.route === p.route && !r.complete));
  if (learnerOnly.length) P('Incomplete only at learner level: ' + learnerOnly.map(p => `${p.route} (${p.broken.map(b => b.id).join(', ')})`).join('; ') + '.', '');
  P(`The complete pages at research level: ${M.chains.research.filter(p => p.complete).map(p => p.route).join(', ')}.`, '');
  // rows that break chains, by number of pages
  const brk = new Map();
  for (const lv of ['research', 'learner']) for (const p of M.chains[lv]) for (const b of p.broken) { const k = b.id; if (!brk.has(k)) brk.set(k, { id: k, status: b.status, pages: new Set(), levels: new Set() }); brk.get(k).pages.add(p.route); brk.get(k).levels.add(lv); }
  const CLS_ORDER = ['missing proof', 'mislabel', 'open', 'input', 'reading'];
  const brkList = [...brk.values()].sort((a, b) => CLS_ORDER.indexOf(breakClass(a, M, N)) - CLS_ORDER.indexOf(breakClass(b, M, N)) || b.pages.size - a.pages.size || (a.id < b.id ? -1 : 1));
  P('Rows that break chains, with the pages they break, and whether a check can mend them:', '');
  P(table(['row', 'status', 'class of break', 'pages', 'levels'], brkList.map(b => [b.id, b.status, breakClass({ id: b.id, status: b.status }, M, N), [...b.pages].join(', '), [...b.levels].join(' + ')])), '');
  P('Reading the classes: **missing proof** is a cited row or an ours row with a checkable core (a check can mend it: sections 4 and 5); **mislabel** is an ours row whose sentence already has a passing check (a data edit); **open** is a stated unknown; **input** is a choice of the model; **reading** is an ours row that is a reading (no check decides it; its place among the key results is a layout choice, the owner\'s).', '');

  // ---------------------------------------------------------------- 9. theorem gaps
  P('## 9. Supplement — theorems with a declared gap', '');
  P('Not rows, so outside the five classes; listed because many rows rest on them (`theorems.json`: status other than `proved`, or a verifier note "gaps"). Not ranked.', '');
  P(table(['theorem', 'title', 'status · verifier', 'rows using it', 'what is missing', 'cost · work'], M.thmGaps.map(t => [t.id, t.title, `${t.status} · ${t.verifier}`, t.rowsUsing, t.note ? t.note.fix : '', t.note ? `${t.note.cost} · ${t.note.work}` : ''])), '');

  // ---------------------------------------------------------------- 10. how it is made
  P('## 10. How this file is made', '');
  P('Command: `node tools/proofs_todo.mjs` (write), `--check` (compare), `--selftest` (plant broken inputs), `--json` (the model). The tool reads `content/rows.json`, `texts.json`, `derived/status.json`, `checks.json`, `check_runs.json`, `candidates.json`, `theorems.json`, `pages.json`, `leads.json`, nothing else, and writes nothing else.', '');
  P('What the tool computes: the classes and counts; the page of a row (the placement of lowest order outside the Explore pages); the statement in at most twenty words (the short research text if there is one, else the full text cut at twenty words); the rows that depend on a statement (distinct rows with a `derives`, `equiv`, `instance`, `uses-input` or `restates` edge into it); the chains; the ranking; the column "cell" (the field `cells` of the row, the Clifford cells Cl(p,q,r) written (p,q,r), or for a candidate the cell written in the notes); this file. What a reader decided, once per id, lives in the notes at the end of the tool: what a check would compute, the bit route, the standard route, the cost, whether a wrong statement would leave the printed sentence false, and the lead. The tool checks the notes: every id of every class has one; a note names only files that exist; a `wire` note names a script whose last recorded run passed; every ranked statement has a cell; the first eight leads by rank are the eight briefs, and the list of statements printed inside each brief is written by the tool.', '');
  P('A row that enters a class later (a new status, a new open question, a new candidate) is printed without a note and `--check` fails until a note is written.', '');
  P('### The routes named in the tables', '');
  P(table(['as written in the tables', 'what it is'], Object.entries(ROUTE).map(([k, v]) => [v, ROUTE_LEGEND[k]])), '');
  P('A script name without a folder is found under `checks/`, `checks/selfcheck/`, `checks/selfcheck/gravity/`, `checks/selfcheck/bridges/`, `checks/selfcheck/reports/`, `checks/researchers_checks/` or `checks/reports/*/`; the tool resolves every name it prints. `bd.<field>.<n>` is a bridge check id, `cat.`, `baez.`, `fibre.`, `bridge.`, `qm.` and `bzw.` those of the report scripts, `core.B<n>` those of `core_check.py`.', '');
  return out.join('\n') + '\n';
}

function countBy(arr, f) { const m = {}; for (const x of arr) { const k = f(x); m[k] = (m[k] || 0) + 1; } return m; }
/** the class of a link that breaks a chain: missing proof (a check can mend it), reading, input, open */
function breakClass(b, M, N) {
  const st = b.status;
  if (st === 'cited') return 'missing proof';
  if (st === 'input') return 'input';
  if (st === 'open') return 'open';
  if (st === 'ours') {
    const r = M.byId.get(b.id);
    const note = N.ours[b.id];
    if (!r || r.kind === 'reading') return 'reading';
    if (note && note.skip === 'mislabel') return 'mislabel';
    if (r.ptype === 'reading' && !note) return 'reading';
    if (note && note.skip === 'retag') return 'reading';
    if (note && note.skip === 'mislabel') return 'mislabel';
    return 'missing proof';
  }
  return st;
}
function chainBreakSummary(M, N) {
  const a = {};
  for (const p of M.chains.research) for (const b of p.broken) { const k = breakClass(b, M, N); a[k] = (a[k] || 0) + 1; }
  const parts = Object.entries(a).map(([k, v]) => `${v} ${k}`);
  return `The ${Object.values(a).reduce((x, y) => x + y, 0)} key results that break them: ${parts.join(', ')}. Only the "missing proof" ones can be mended by a check.`;
}

// ============================================================================================================================ lead blocks and row reports
const EDIT_TEXT = {
  evidence: 'the evidence entry',
  flag: 'the flag "checked" in legacyFlags',
  kind: 'a split of the line: the checked sentence as a result line, the question as its own line (kind, ptype)',
};
const BLOCK_BEGIN = k => `<!-- proofs_todo:begin ${LEADS[k].id} -->`;
const BLOCK_END = k => `<!-- proofs_todo:end ${LEADS[k].id} -->`;

/** The statements of one lead, in rank order, as the brief prints them (generated: the brief carries it between two markers). */
function leadBlock(key, ranked) {
  const L = LEADS[key];
  const items = ranked.filter(i => i.note.lead === key);
  const out = [];
  out.push(`${items.length} ranked statements, best rank ${items.length ? items[0].rank : '—'}. This list is written by \`node tools/proofs_todo.mjs\` from the tables and the notes; \`--check\` fails when it differs, and \`--lead ${L.id}\` prints it.`, '');
  items.forEach((it, k) => {
    const nt = it.note;
    out.push(`${k + 1}. **${mark(it)}** · ${it.cls} · ${it.page} · rank ${it.rank} · ${nt.cost} · ${nt.work} · ${nt.fw ? 'false if wrong' : 'a missing claim if wrong'} · ${it.nDep} ${it.cls === 'cand' ? 'rows linked' : 'rows rest on it'}`);
    out.push(`   - sentence: ${it.statement}`);
    out.push(`   - a check computes: ${expand(nt.w)}`);
    out.push(`   - bit route: ${expand(nt.bit)}`);
    if (cellOf(it)) out.push(`   - cell: ${cellOf(it)}`);
    out.push(`   - standard route: ${expand(nt.std)}`);
    if (nt.via && nt.via.length) out.push(`   - check to name (last run passed): ${nt.via.map(v => 'checks/' + v).join(', ')}`);
    out.push(`   - after a pass: ${it.cls === 'cand' ? 'a CAND- row when the author accepts it, with the script as its evidence' : it.edits.map(e => EDIT_TEXT[e]).join('; ')}`);
  });
  return out.join('\n');
}

/** replace the generated block of a brief; null when the brief has no markers */
function withBlock(text, key, block) {
  const a = text.indexOf(BLOCK_BEGIN(key)), b = text.indexOf(BLOCK_END(key));
  if (a < 0 || b < a) return null;
  return text.slice(0, a) + BLOCK_BEGIN(key) + '\n' + block + '\n' + text.slice(b);
}

/** one row or candidate: what the tables say and what the notes say (for a lead that starts from a row id) */
function rowReport(id, M, T, N) {
  const all = [...M.cited, ...M.oursClaims, ...M.openAll, ...M.candYes];
  const it = all.find(x => x.id === id);
  const out = [];
  const r = M.byId.get(id), cand = T.candidates.find(c => c.id === id), thm = M.thmGaps.find(t => t.id === id);
  if (cand) {
    out.push(`== ${id} · candidate · checkable ${cand.checkable} · field ${cand.field}`, `   title: ${cand.title}`, `   statement: ${cand.statement}`, `   source: ${cand.source}`, `   checkNote: ${cand.checkNote}`, `   linked rows: ${cand.linksRows.join(', ')}`);
  } else if (r) {
    out.push(`== ${id} · status ${M.status(id)} · kind ${r.kind} · ptype ${r.ptype} · legacy flags ${JSON.stringify(r.legacyFlags || [])} · page ${M.pageOf(r)}`);
    out.push(`   evidence: ${(r.evidence || []).map(e => `${e.check}${e.script ? ' [' + e.script + ']' : ''} ${e.mode}`).join('; ') || 'none'}`);
    out.push(`   depends on: ${uniq((r.depends || []).map(d => `${d.id} (${d.rel})`)).join(', ') || 'none'}; ${M.nDependents(id)} rows rest on it`);
    for (const t of T.texts.filter(x => x.row === id && x.lens === null && x.lang === 'en' && x.level === 'research')) out.push(`   [research ${t.mode} ${t.register}] ${t.body}`);
  } else if (thm) {
    out.push(`== ${id} · theorem · ${thm.status} · ${thm.verifier}`, `   ${thm.title}`);
  } else { out.push(`== ${id}: no row, candidate or theorem of that id`); return out.join('\n'); }
  const nt = it ? it.note : (thm ? thm.note : null);
  if (!nt) out.push('   note: none (the id is in no class of the list)');
  else if (nt.skip) out.push(`   note: not ranked, class ${nt.skip}${nt.why ? ': ' + nt.why : ''}`);
  else if (thm) out.push(`   note: ${nt.cost} · ${nt.work}; missing: ${nt.fix}`);
  else {
    out.push(`   note: ${nt.cost} · ${nt.work} · ${nt.fw ? 'false if wrong' : 'a missing claim if wrong'} · lead ${nt.lead && LEADS[nt.lead] ? LEADS[nt.lead].id : nt.lead || '—'}${it && it.rank ? ' · rank ' + it.rank : ''}`);
    out.push(`   a check computes: ${expand(nt.w)}`, `   bit route: ${expand(nt.bit)}`, ...(it && cellOf(it) ? [`   cell: ${cellOf(it)}`] : []), `   standard route: ${expand(nt.std)}`);
    if (nt.via && nt.via.length) out.push(`   check to name: ${nt.via.map(v => 'checks/' + v).join(', ')}`);
    if (it && it.edits) out.push(`   after a pass: ${it.edits.map(e => EDIT_TEXT[e]).join('; ')}`);
  }
  return out.join('\n');
}

// ============================================================================================================================ self-test
/** Plant broken inputs; each must be caught by validate(), and the unbroken inputs must pass. Exit code 1 when one is missed. */
function selftest(T, N) {
  let bad = 0, n = 0;
  const say = (ok, m) => { n++; if (!ok) bad++; console.log((ok ? 'ok   ' : 'FAIL ') + m); };
  const clone = x => structuredClone(x);
  const run = (T2, N2) => validate(analyse(T2, N2), T2, N2);
  const base = run(T, N);
  say(base.length === 0, `the unbroken tables and notes give no problem (${base.length} found)`);
  // the ids a plant may use: rows that are in the class now (a note of a row that is proved by now is a record, not a live item)
  const M0 = analyse(T, N);
  const live = { cited: new Set(M0.cited.map(i => i.id)), ours: new Set(M0.oursClaims.map(i => i.id)), open: new Set(M0.openAll.map(i => i.id)), cand: new Set(M0.candYes.map(i => i.id)) };
  const liveKey = (cls, pred = () => true) => Object.keys(N[cls]).find(k => live[cls].has(k) && pred(N[cls][k]));
  const anyClass = (pred = () => true) => ['cited', 'open', 'cand', 'ours'].map(c => [c, liveKey(c, pred)]).find(([, k]) => k) || [null, null];
  // 1. a cited row loses its note
  { const [cls, id] = anyClass(); const N2 = { ...N, [cls]: clone(N[cls]) }; delete N2[cls][id];
    say(run(T, N2).some(p => p.includes(`unannotated ${cls} ` + id)), `a ${cls} row without a note (${id}) is reported`); }
  // 2. a note names a file that does not exist
  { const [cls, id] = anyClass(nt => !nt.skip); const N2 = { ...N, [cls]: clone(N[cls]) }; N2[cls][id].w += ' see no_such_script_zz.py';
    say(run(T, N2).some(p => p.includes('no_such_script_zz.py')), 'a note that names a missing file is reported'); }
  // 3. a wire target whose last run did not pass
  { const [cls, id] = anyClass(nt => (nt.via || []).length > 0);
    if (!cls) say(true, 'no live wire target on the list: the plant is skipped (every wire is closed)');
    else { const via = N[cls][id].via[0]; const T2 = { ...T, runs: clone(T.runs) }; for (const r of T2.runs) if (r.script.endsWith(via) || r.script.endsWith('/' + path.basename(via))) r.passed = false;
      say(run(T2, N).some(p => p.includes(path.basename(via) + ' has no passing recorded run') || p.includes(via + ' has no passing recorded run')), `a wire target without a passing run (${via}) is reported`); } }
  // 4. a note for an id outside its class
  { const N2 = { ...N, open: clone(N.open) }; N2.open['ZZZ-999'] = s('scope', 'a note for a row that is not open');
    say(run(T, N2).some(p => p.includes('orphan note: ZZZ-999')), 'a note for an id outside its class is reported'); }
  // 5. a cost that is not S, M or L
  { const id = liveKey('cand', nt => !nt.skip); if (!id) say(true, 'no live candidate on the list: the cost plant is skipped');
    else { const N2 = { ...N, cand: clone(N.cand) }; N2.cand[id].cost = 'XL'; say(run(T, N2).some(p => p.includes(id + ': cost must be')), 'a bad cost letter is reported'); } }
  // 6. a row that enters a class later has no note
  { const T2 = { ...T, status: clone(T.status) }; const id = T.rows.find(r => T.status[r.id].status === 'proved-by-atlas').id; T2.status[id].status = 'cited';
    say(run(T2, N).some(p => p.includes('unannotated cited ' + id)), `a row that turns cited (${id}) is reported until it has a note`); }
  // 7. a candidate note that says "false if wrong"
  { const id = liveKey('cand', nt => !nt.skip); if (!id) say(true, 'no live candidate on the list: the false-if-wrong plant is skipped');
    else { const N2 = { ...N, cand: clone(N.cand) }; N2.cand[id].fw = true; say(run(T, N2).some(p => p.includes(id + ': a candidate is not printed')), 'a candidate marked false-if-wrong is reported'); } }
  // 8. a wire note with no via
  { const [cls, id] = anyClass(nt => nt.work === 'wire'); if (!cls) say(true, 'no live wire note on the list: the plant is skipped');
    else { const N2 = { ...N, [cls]: clone(N[cls]) }; delete N2[cls][id].via; say(run(T, N2).some(p => p.includes(id + ': a wire note names the script')), `a wire note without its script (${id}) is reported`); } }
  // 9. the order of the leads
  { const M9 = analyse(T, N); validate(M9, T, N); say(Array.isArray(M9.leadsWithoutBrief), `the live leads without a brief are listed (${(M9.leadsWithoutBrief || []).join(', ') || 'none'})`); }
  // 9b. a ranked candidate whose cell is not named
  { const id = Object.keys(CELL_CAND).find(k => live.cand.has(k) && !N.cand[k].skip); if (!id) say(true, 'no live candidate with a cell on the list: the plant is skipped');
    else { const saved = CELL_CAND[id]; delete CELL_CAND[id]; const probs = run(T, N); CELL_CAND[id] = saved;
      say(probs.some(p => p.includes(id + ': the cell of the bit route is not named')), `a candidate without its cell (${id}) is reported`); } }
  // 10. the generated list inside a brief must equal the tables; a brief without markers, or a missing brief, is reported
  { const M = analyse(T, N), ranked = rankItems(M, N);
    const fake = new Map(LEAD_ORDER.map(k => [LEADS[k].id, `# ${LEADS[k].id}\n${BLOCK_BEGIN(k)}\n${leadBlock(k, ranked)}\n${BLOCK_END(k)}\n`]));
    const reader = m => f => { const id = path.basename(f, '.md'); return m.has(id) ? m.get(id) : null; };
    say(briefProblems(ranked, reader(fake)).length === 0, 'briefs that carry the generated lists give no problem');
    const k0 = LEAD_ORDER.find(k => ranked.some(it => it.note && it.note.lead === k)) || LEAD_ORDER[0], id0 = LEADS[k0].id;
    const changed = new Map(fake); changed.set(id0, fake.get(id0).replace(/rank \d+ ·/, 'rank 999 ·'));
    say(briefProblems(ranked, reader(changed)).some(p => p.includes('differs from the tables')), 'a brief whose generated list differs from the tables is reported');
    const bare = new Map(fake); bare.set(id0, `# ${id0}\n`);
    say(briefProblems(ranked, reader(bare)).some(p => p.includes('no block markers')), 'a brief without its block markers is reported');
    const named = new Map(fake); named.set(id0, fake.get(id0) + '\nsee no_such_script_zz.py and ' + (LEADS[k0].newFiles || ['x.py'])[0] + '\n');
    const namedProblems = briefProblems(ranked, reader(named));
    say(namedProblems.some(p => p.includes('no_such_script_zz.py')) && !namedProblems.some(p => p.includes((LEADS[k0].newFiles || ['x.py'])[0])), 'a brief that names a missing file is reported, and one of the lead\'s own new files is not');
    const gone = new Map(fake); gone.delete(id0);
    say(briefProblems(ranked, reader(gone)).some(p => p.includes('missing brief')), 'a missing brief is reported'); }
  console.log(`\nproofs_todo selftest: ${n - bad} of ${n} as expected`);
  process.exit(bad ? 1 : 0);
}

// ============================================================================================================================ main
function buildNotes() {
  // expand the shared routes in place once, so that validation sees the file names the reader sees
  return { cited: CITED, ours: OURS, open: OPEN, cand: CAND, theorems: THM };
}
function attach(M, N) {
  // the notes travel with the items (analyse() read them by id); theorem notes are plain objects
  return M;
}
/** the problems of the eight briefs: present, carrying their id, and with the generated list of statements equal to the tables */
/** a file named in the hand-written part of a brief must be in the repository, or be one the lead writes (LEADS[k].newFiles), or live under $SP */
function briefFileProblems(txt, k, root = ROOT) {
  const a = txt.indexOf(BLOCK_BEGIN(k)), b = txt.indexOf(BLOCK_END(k));
  const body = a >= 0 && b > a ? txt.slice(0, a) + txt.slice(b) : txt;
  const mine = new Set(LEADS[k].newFiles || []);
  const bad = new Set();
  for (const t of body.match(FILE_RE) || []) {
    if (t.startsWith('SP/') || mine.has(path.basename(t))) continue;
    if (!fileExists(t, root) && !fileExists(path.basename(t), root)) bad.add(t);
  }
  return [...bad].map(t => `brief ${LEADS[k].id}.md names ${t}, which is neither in the repository nor a file the lead writes`);
}
function briefProblems(ranked, read = f => (fs.existsSync(f) ? fs.readFileSync(f, 'utf8') : null)) {
  const out = [];
  for (const k of LEAD_ORDER) {
    const f = path.join(ROOT, 'docs', 'round7', 'leads', LEADS[k].id + '.md');
    const txt = read(f);
    if (txt == null) { out.push(`missing brief ${LEADS[k].id}.md`); continue; }
    if (!txt.includes(LEADS[k].id)) out.push(`brief ${LEADS[k].id}.md does not carry its id`);
    const fresh = withBlock(txt, k, leadBlock(k, ranked));
    if (fresh === null) out.push(`brief ${LEADS[k].id}.md has no block markers ${BLOCK_BEGIN(k)} ... ${BLOCK_END(k)}`);
    else if (fresh !== txt) out.push(`brief ${LEADS[k].id}.md: the generated list of statements differs from the tables: run the tool again`);
    out.push(...briefFileProblems(txt, k));
  }
  return out;
}
/** rewrite the generated list in every brief that has its markers (the rest of a brief is the author's and is never touched) */
function refreshBriefs(ranked) {
  const done = [];
  for (const k of LEAD_ORDER) {
    const f = path.join(ROOT, 'docs', 'round7', 'leads', LEADS[k].id + '.md');
    if (!fs.existsSync(f)) continue;
    const txt = fs.readFileSync(f, 'utf8'), fresh = withBlock(txt, k, leadBlock(k, ranked));
    if (fresh !== null && fresh !== txt) { fs.writeFileSync(f, fresh); done.push(LEADS[k].id); }
  }
  return done;
}

function usage() {
  const lines = fs.readFileSync(fileURLToPath(import.meta.url), 'utf8').split('\n');
  const i = lines.findIndex(l => l.startsWith('// Usage:'));
  console.log(lines.slice(i).filter((l, k, a) => a.slice(0, k + 1).every(x => x.startsWith('//'))).map(l => l.replace(/^\/\/ ?/, '')).join('\n'));
}
function main() {
  if (argv.includes('--help') || argv.includes('-h')) return usage();
  const T = loadTables();
  const N = buildNotes();
  if (argv.includes('--selftest')) return selftest(T, N);
  const M = attach(analyse(T, N), N);
  const problems = validate(M, T, N);
  const ranked = rankItems(M, N);
  if (argv.includes('--row')) {
    const i = argv.indexOf('--row'); const ids = argv.slice(i + 1).filter(a => !a.startsWith('--'));
    if (!ids.length) { console.log('usage: node tools/proofs_todo.mjs --row ID [ID ...]'); process.exit(2); }
    console.log(ids.map(id => rowReport(id, M, T, N)).join('\n\n'));
    return;
  }
  if (argv.includes('--lead')) {
    const id = opt('--lead'); const k = LEAD_ORDER.find(x => LEADS[x].id === id);
    if (!k) { console.log(`usage: node tools/proofs_todo.mjs --lead <${LEAD_ORDER.map(x => LEADS[x].id).join('|')}>`); process.exit(2); }
    console.log(leadBlock(k, ranked));
    return;
  }
  if (argv.includes('--json')) {
    const slim = it => ({ rank: it.rank ?? null, id: it.id, cls: it.cls, page: it.page, cost: it.note && it.note.cost, work: it.note && it.note.work, fw: it.note && it.note.fw, lead: it.note && it.note.lead, nDep: it.nDep, skip: it.note && it.note.skip });
    console.log(JSON.stringify({ counts: counts(M, N), problems, ranked: ranked.map(slim), leads: LEAD_ORDER }, null, 1));
    return;
  }
  const out = opt('--out') ? path.resolve(opt('--out')) : path.join(ROOT, 'docs', 'PROOFS_TODO.md');
  const writing = !argv.includes('--check');
  const refreshed = writing && !opt('--out') ? refreshBriefs(ranked) : [];
  const md = render(M, T, N, ranked, problems);
  if (!writing) {
    const have = fs.existsSync(out) ? fs.readFileSync(out, 'utf8') : null;
    const extra = briefProblems(ranked);
    if (have !== md) extra.push(`${path.relative(ROOT, out)} differs from the tables and notes: run the tool again`);
    for (const p of [...problems, ...extra]) console.log('FAIL ' + p);
    console.log(problems.length + extra.length ? `proofs_todo --check: ${problems.length + extra.length} problem(s)` : `proofs_todo --check: ok (${ranked.length} ranked statements, ${LEAD_ORDER.length} briefs)`);
    process.exit(problems.length + extra.length ? 1 : 0);
  }
  fs.writeFileSync(out, md);
  const c = counts(M, N);
  console.log(`wrote ${path.relative(ROOT, out)}: ${ranked.length} ranked statements (cited ${c.cited.total}, ours ${c.ours.core} of ${c.ours.claims}, open ${c.open.computable} of ${c.open.total}, candidates ${c.cand.yes - c.cand.nSkipped} of ${c.cand.yes}); chains incomplete ${c.chains.research.incomplete} of ${c.chains.research.pages} (research), ${c.chains.learner.incomplete} of ${c.chains.learner.pages} (learner)`);
  if (refreshed.length) console.log(`refreshed the generated list in ${refreshed.join(', ')}`);
  for (const p of [...problems, ...briefProblems(ranked)]) console.log('PROBLEM ' + p);
}
main();
