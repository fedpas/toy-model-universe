#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/accept_review.mjs — copies the reviewer's proposals (content/story/review_proposed_*.json, the shape of docs/BUILD_CONTRACTS.md "Round 6,
// wave 2") into the author's choices, content/story/review.json, which tools/merge_story.mjs and tools/migrate/story_from_v15.mjs apply (STORY_PLAN
// §1.4, D45, D50). How to read the digest and accept or change a choice: docs/REVIEW_GUIDE.md.
//
// Usage: node tools/accept_review.mjs <selection> [--rule default] [--dry-run] [--force] [--v15 <v15 root>]
//        node tools/accept_review.mjs --self-test
//   selection       --all, or any of --page <route>, --choice <choice>, --ids <locator or proposed id>; each takes a comma-separated list and may be
//                   repeated; an entry must match every flag given. --choice statement matches every statement:<check id>, --choice same-as every
//                   same-as:<row id>; --page atlas is the page of route '' (the renames of content/story/landing.json). --rule default alone selects all.
//   --rule default  the rule R7-7 (docs/round7/PLAN.md): accept story, same-as:<row id> and drop, whose reasons name their rows (a drop without rows
//                   only when its reason begins "About the app"); send hold, reading and statement:<check id> (the proposals that make a claim) to the
//                   author's list, with the finding titles' same-as:<row id> (A58: the author confirms that a title is the row's statement). An entry
//                   that review.json already decides is not sent.
//                   Without --rule, the selected proposals are the author's own acceptance: each is copied, hold excepted.
//   --dry-run       write nothing; print what would be written.
//   --force         replace an entry of review.json that holds another choice; without it such an entry is kept and named.
//   --v15 <root>    (or ATLAS_V15) also run tools/migrate/story_from_v15.mjs in memory with the resulting choices and count the story choices it would
//                   place: a block chosen as story becomes a story row only where the test of §1.4 clears it in its section (a held block stays held).
//                   Nothing is written.
// Never copied: hold (no choice: the entry waits in pending.json for the author); an invalid proposal (its locator is not a pending entry or is
// proposed twice; a row it cites is not a row of content/rows.json or is not named in its reason; a same-as target is not among its rows; a
// statement's check is not in content/checks.json, is not named in the reason, or its script has no recorded passing run in content/check_runs.json;
// a drop that names no row and is not about the app; a story that names no row; a finding title proposed as anything but same-as, drop or hold);
// and a reading or statement whose pending entry lacks the row's labels (notions, a row kind, a stage), which tools/merge_story.mjs refuses.
// Prints the counts, what it wrote, and the author's list: one line per entry, "page · id · choice · the first twelve words · why".
// review.json is written sorted by locator, as JSON.stringify(…, null, 1); a run is idempotent. Exit 1 when a selected proposal is invalid (the
// valid ones are copied all the same) or the measure fails, 2 on a usage error; --self-test plants broken proposals and exits 1 unless each is caught.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const readJSON = (f, fb) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fb);
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
// the row kinds and stages that tools/build_content.mjs accepts (its KINDS and STAGES); a statement row takes one of these kinds, never story or reading
const KINDS = new Set(['definition', 'construction', 'lemma', 'theorem', 'range', 'classification', 'invariant', 'example', 'counterexample', 'computation', 'reduction', 'reading', 'conjecture', 'question', 'dead-end', 'pointer', 'meta', 'story']);
const STAGES = new Set(['A', 'K', 'F', 'D', 'O', 'M']);
const CHOICE_RE = /^(story|reading|drop|hold|same-as:(\S+)|statement:(\S+))$/;
const FAMILIES = ['story', 'same-as', 'drop', 'statement', 'reading', 'hold'];
const family = c => String(c).split(':')[0];
const reEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** does the reason name this row or check id (as a whole id: LNB-014 is not named by LNB-014b) */
const names = (text, id) => new RegExp(`(?<![\\w-])${reEsc(id)}(?![\\w])`).test(text);
const words12 = t => { const w = String(t || '').replace(/\s+/g, ' ').trim().split(' '); return w.slice(0, 12).join(' ') + (w.length > 12 ? ' …' : ''); };
const clip = (s, n) => { const t = String(s || '').replace(/\s+/g, ' ').trim(); return t.length > n ? t.slice(0, n - 1) + '…' : t; };

// ---------------------------------------------------------------------------------------------------------------------------------- the tables
export function loadTables(root = ROOT) {
  const C = path.join(root, 'content'), S = path.join(C, 'story');
  const proposals = [];
  for (const n of (fs.existsSync(S) ? fs.readdirSync(S) : []).filter(n => /^review_proposed_.+\.json$/.test(n)).sort(cmpStr)) {
    const d = readJSON(path.join(S, n), {});
    for (const [loc, p] of Object.entries(d)) proposals.push({ file: `content/story/${n}`, loc, p });
  }
  return {
    proposals, rows: new Set(readJSON(path.join(C, 'rows.json'), []).map(r => r.id)), pending: readJSON(path.join(S, 'pending.json'), []),
    checks: readJSON(path.join(C, 'checks.json'), []), runs: readJSON(path.join(C, 'check_runs.json'), []), review: readJSON(path.join(S, 'review.json'), {}),
    routes: (readJSON(path.join(S, 'landing.json'), {}) || {}).routes || {},
  };
}

/** check id → { known, passed }: the ids of tools/build_content.mjs (a script's basename, or an id of its list); passed when the last recorded run of
 *  each of its scripts passed */
function checkIndex(checks, runs) {
  const last = new Map();
  for (const r of runs) if (r && r.script && (!last.has(r.script) || String(r.date) >= String(last.get(r.script).date))) last.set(r.script, r);
  const scripts = new Map();
  const add = (id, s) => { if (!scripts.has(id)) scripts.set(id, new Set()); if (s) scripts.get(id).add(s); };
  for (const c of checks) { if (c.script) add(path.basename(c.script).replace(/\.(py|mjs)$/, ''), c.script); for (const i of c.ids || []) add(i.id, c.script); }
  return id => {
    if (!scripts.has(id)) return { known: false, passed: false };
    const rs = [...scripts.get(id)].map(s => last.get(s));
    return { known: true, passed: rs.length > 0 && rs.every(r => r && r.passed === true) };
  };
}

const missingLabels = (e, fam) => {
  const miss = [];
  if (!Array.isArray(e.notions) || !e.notions.length) miss.push('notions');
  if (fam === 'statement' ? !KINDS.has(e.kind) || e.kind === 'story' || e.kind === 'reading' : !e.kind) miss.push('kind');
  if (!STAGES.has(e.stage)) miss.push('stage');
  return miss;
};

/** every proposal with its pending entry, its family, what makes it invalid (why) and the labels it lacks */
export function validate(T) {
  const pend = new Map(T.pending.map(p => [p.locator, p]));
  const run = checkIndex(T.checks, T.runs);
  const where = new Map(), out = [];
  for (const { file, loc } of T.proposals) where.set(loc, [...(where.get(loc) || []), file]);
  for (const { file, loc, p } of T.proposals) {
    const why = [], e = pend.get(loc) || null;
    if (!e) why.push('no pending entry has this locator');
    if (where.get(loc).length > 1) why.push(`proposed twice (${where.get(loc).map(f => path.basename(f)).join(', ')})`);
    const ok = p && typeof p === 'object' && !Array.isArray(p);
    const choice = ok ? p.choice : undefined, reason = ok && typeof p.reason === 'string' ? p.reason : '', rows = ok && Array.isArray(p.rows) ? p.rows : null;
    const m = typeof choice === 'string' ? CHOICE_RE.exec(choice) : null;
    if (!ok) why.push('not an object { choice, reason, rows }');
    else {
      if (!m) why.push(`choice ${JSON.stringify(choice)} is none of story, reading, statement:<check id>, same-as:<row id>, drop, hold`);
      if (!reason.trim()) why.push('no reason');
      if (!rows || rows.some(r => typeof r !== 'string')) why.push('rows is not a list of row ids');
    }
    const rs = (rows || []).filter(r => typeof r === 'string');
    for (const r of rs) { if (!T.rows.has(r)) why.push(`${r} is not a row`); else if (!names(reason, r)) why.push(`the reason does not name ${r}`); }
    const fam = m ? family(choice) : null;
    if (m && m[2]) { if (!T.rows.has(m[2])) why.push(`same-as:${m[2]}: not a row`); else if (!rs.includes(m[2])) why.push(`same-as:${m[2]}: not among its rows`); }
    if (m && m[3]) {
      const k = run(m[3]);
      if (!k.known) why.push(`statement:${m[3]}: not a check of content/checks.json`);
      else if (!k.passed) why.push(`statement:${m[3]}: no recorded passing run in content/check_runs.json`);
      if (!names(reason, m[3])) why.push(`the reason does not name the check ${m[3]}`);
    }
    if (fam === 'drop' && !rs.length && !/^About the app\b/.test(reason)) why.push('a drop names the row it repeats, or its reason begins "About the app"');
    if (fam === 'story' && !rs.length) why.push('a story names the rows it narrates');
    if (m && e && e.pend === 'title' && !['same-as', 'drop', 'hold'].includes(fam)) why.push('a finding title is same-as:<row id>, drop or hold (A58)');
    out.push({ file, loc, p: ok ? p : {}, e, fam, why, labels: e && (fam === 'reading' || fam === 'statement') ? missingLabels(e, fam) : [] });
  }
  return out;
}

/** the selection: an entry matches every flag given */
export function selector(opts, routes = {}) {
  const alias = r => { const s = new Set([r]); for (const [from, to] of Object.entries(routes)) { if (r === to) s.add(from); if (r === from) s.add(to); } return [...s]; };
  const pages = opts.page.length ? new Set(opts.page.flatMap(alias)) : null;
  const choices = opts.choice.length ? opts.choice : null;
  const ids = opts.ids.length ? new Set(opts.ids) : null;
  return v => (!pages || (!!v.e && pages.has(v.e.page)))
    && (!choices || choices.some(c => v.p.choice === c || (!c.includes(':') && v.fam === c)))
    && (!ids || ids.has(v.loc) || (!!v.e && ids.has(v.e.id)));
}

/** what happens to each selected proposal */
export function decide(vals, { select, rule, review, force }) {
  const r = { selected: 0, accepted: [], owner: [], chosen: [], hold: [], invalid: [], unlabelled: [], kept: [], unchanged: [] };
  for (const v of vals) {
    if (!select(v)) continue;
    r.selected++;
    if (v.why.length) { r.invalid.push(v); continue; }
    const cur = review[v.loc];
    const claim = ['hold', 'reading', 'statement'].includes(v.fam) || (v.fam === 'same-as' && v.e.pend === 'title');
    if (rule === 'default' && claim) { (cur === undefined ? r.owner : r.chosen).push(v); continue; }
    if (v.fam === 'hold') { r.hold.push(v); continue; }
    if (v.labels.length) { r.unlabelled.push(v); continue; }
    if (cur === v.p.choice) { r.unchanged.push(v); continue; }
    if (cur !== undefined && !force) { r.kept.push(v); continue; }
    r.accepted.push(v);
  }
  return r;
}

export function applyChoices(review, accepted) {
  const next = { ...review };
  for (const v of accepted) next[v.loc] = v.p.choice;
  return Object.fromEntries(Object.entries(next).sort((a, b) => cmpStr(a[0], b[0])));
}

const byFamily = list => { const n = {}; for (const v of list) n[v.fam] = (n[v.fam] || 0) + 1; return FAMILIES.filter(f => n[f]).map(f => `${f} ${n[f]}`).join(', ') || 'none'; };
const pageOf = v => (v.e ? v.e.page || 'atlas' : '?');
const ownerLine = v => `${pageOf(v)} · ${v.e.id} · ${v.p.choice}${v.labels.length ? ` (needs labels in pending.json: ${v.labels.join(', ')})` : ''} · ${words12(v.e.text)} · ${clip(v.p.reason, 150)}`;
const byPage = (a, b) => cmpStr(pageOf(a), pageOf(b)) || cmpStr(a.e ? a.e.id : a.loc, b.e ? b.e.id : b.loc);

/** run tools/migrate/story_from_v15.mjs in memory with these choices: which story choices would become story rows */
async function measure(v15, next, root = ROOT) {
  const { migrate } = await import(pathToFileURL(path.join(root, 'tools', 'migrate', 'story_from_v15.mjs')).href);
  const res = await migrate(path.resolve(v15), { review: next });
  if (res.errors.length) return { errors: res.errors };
  const blocks = new Map([...res.ctx.cand, ...res.ctx.learnerOnly].map(b => [b.primary.loc, b]));
  const story = Object.keys(next).filter(loc => next[loc] === 'story');
  // why a block chosen as story stays held: it repeats 40 characters of a row; it restates rows of other sections of its page only (the
  // migration's diagnostic clearedByPage); or it holds a formula or number that no row of its section or page states
  const why = { repeats: 0, page: 0, none: 0 };
  const placed = new Set();
  for (const loc of story) {
    const b = blocks.get(loc);
    if (b && b.outcome === 'story') { placed.add(loc); continue; }
    if (b && b.test && b.test.signals.some(s => s.startsWith('repeats'))) why.repeats++; else if (b && b.clearedByPage) why.page++; else why.none++;
  }
  return { story, placed, why };
}

// ---------------------------------------------------------------------------------------------------------------------------------- the self-test
// Planted broken proposals, each of which must be refused for its own reason, and good ones, which must be accepted or sent to the author.
function selfTest() {
  const T = {
    rows: new Set(['R-1', 'R-2', 'R-3']), routes: { '': 'atlas' },
    pending: [['a', 'held'], ['b', 'held'], ['c', 'held'], ['d', 'statement'], ['e', 'statement'], ['f', 'held'], ['g', 'title'], ['i', 'held'], ['j', 'statement'], ['k', 'held'],
      ['l', 'held'], ['m', 'title'], ['n', 'statement'], ['o', 'held'], ['p', 'held']].map(([x, pend], i) => ({ locator: `t.js#${x}`, id: `T-${501 + i}`, page: i < 3 ? '' : 'pg', pend, text: `text ${x}` })),
    checks: [{ script: 'checks/selfcheck/good_check.py', ids: [{ id: 'good·A1' }] }, { script: 'checks/selfcheck/bad_check.py' }],
    runs: [{ script: 'checks/selfcheck/good_check.py', date: 'd2', passed: true }, { script: 'checks/selfcheck/bad_check.py', date: 'd1', passed: true }, { script: 'checks/selfcheck/bad_check.py', date: 'd2', passed: false }],
    review: { 't.js#k': 'drop', 't.js#l': 'story' },
  };
  const labelled = T.pending.find(p => p.locator === 't.js#n'); Object.assign(labelled, { notions: ['lbl'], kind: 'computation', stage: 'K' });
  const P = (loc, choice, reason, rows) => ({ file: 'content/story/review_proposed_t.json', loc: `t.js#${loc}`, p: { choice, reason, rows } });
  T.proposals = [
    P('a', 'story', 'It narrates a row.', ['R-1']),                                  // broken: the reason does not name R-1
    P('b', 'story', 'It narrates R-9.', ['R-9']),                                    // broken: R-9 is not a row
    P('c', 'same-as:R-2', 'It is R-1.', ['R-1']),                                     // broken: the same-as target is not among its rows
    P('d', 'statement:nope_check', 'nope_check computes it, R-1.', ['R-1']),          // broken: not a check
    P('e', 'statement:bad_check', 'bad_check computes it, R-1.', ['R-1']),            // broken: the last run of its script failed
    P('f', 'drop', 'It repeats nothing.', []),                                        // broken: a drop that names no row and is not about the app
    P('g', 'story', 'A title narrating R-1.', ['R-1']),                               // broken: a title is same-as, drop or hold
    P('h', 'drop', 'About the app: a locator no entry has.', []),                     // broken: no pending entry
    P('i', 'story', 'It narrates R-1.', ['R-1']), P('i', 'drop', 'About the app.', []), // broken: proposed twice (the second)
    P('j', 'statement:good·A1', 'good·A1 computes it; R-1 states the rest.', ['R-1']), // unlabelled: never copied (merge_story would refuse it)
    P('k', 'story', 'It narrates R-1.', ['R-1']),                                     // kept: review.json holds drop (replaced only with --force)
    P('l', 'story', 'It narrates R-2.', ['R-2']),                                     // unchanged: review.json holds story already
    P('m', 'same-as:R-3', 'The title is R-3.', ['R-3']),                              // good: a title's same-as goes to the author under --rule default
    P('n', 'statement:good·A1', 'good·A1 computes it (R-1).', ['R-1']),               // good: labelled statement; to the author under --rule default
    P('o', 'hold', 'No row states it; R-1 is near.', ['R-1']),                        // good: hold, never copied
    P('p', 'drop', 'About the app: a widget limit.', []),                             // good: an app drop
  ];
  const vals = validate(T);
  const fails = [];
  const expectInvalid = { a: 'does not name R-1', b: 'R-9 is not a row', c: 'not among its rows', d: 'not a check', e: 'no recorded passing run', f: 'a drop names', g: 'a finding title', h: 'no pending entry', i: 'proposed twice' };
  for (const [x, w] of Object.entries(expectInvalid)) { const v = vals.filter(v => v.loc === `t.js#${x}`).pop(); if (!v || !v.why.some(s => s.includes(w))) fails.push(`planted ${x}: expected "${w}", got ${JSON.stringify(v ? v.why : null)}`); }
  for (const x of ['j', 'k', 'l', 'm', 'n', 'o', 'p']) { const v = vals.find(v => v.loc === `t.js#${x}`); if (!v || v.why.length) fails.push(`${x}: expected valid, got ${JSON.stringify(v ? v.why : null)}`); }
  const all = selector({ page: [], choice: [], ids: [] }, T.routes);
  const ids = (list) => list.map(v => v.loc.slice(5)).sort().join('');
  const d = decide(vals, { select: all, rule: 'default', review: T.review, force: false });
  if (ids(d.accepted) !== 'p') fails.push(`--rule default accepted ${ids(d.accepted)}, expected p`);
  if (ids(d.owner) !== 'jmno') fails.push(`--rule default sent ${ids(d.owner)} to the author, expected jmno`);
  if (ids(d.kept) !== 'k' || ids(d.unchanged) !== 'l') fails.push(`--rule default kept ${ids(d.kept)} and left ${ids(d.unchanged)}, expected k and l`);
  const f = decide(vals, { select: all, rule: null, review: T.review, force: true });
  if (ids(f.accepted) !== 'kmnp') fails.push(`--all --force accepted ${ids(f.accepted)}, expected kmnp`);
  if (ids(f.hold) !== 'o' || ids(f.unlabelled) !== 'j') fails.push(`--all copied hold or an unlabelled statement (${ids(f.hold)}, ${ids(f.unlabelled)})`);
  const next = applyChoices(T.review, f.accepted);
  if (next['t.js#k'] !== 'story' || 't.js#o' in next || 't.js#j' in next || Object.keys(next).join() !== Object.keys(next).sort(cmpStr).join()) fails.push(`--force did not replace k, or copied o or j, or left review.json unsorted: ${JSON.stringify(next)}`);
  const sel = selector({ page: ['atlas'], choice: ['story'], ids: [] }, T.routes);
  if (ids(vals.filter(v => sel(v))) !== 'ab') fails.push(`--page atlas --choice story selected ${ids(vals.filter(v => sel(v)))}, expected ab (route '' renamed atlas)`);
  const byId = selector({ page: [], choice: ['statement'], ids: ['T-513', 't.js#d'] }, T.routes);
  if (ids(vals.filter(v => byId(v))) !== 'dn') fails.push(`--choice statement --ids selected ${ids(vals.filter(v => byId(v)))}, expected dn`);
  for (const m of fails) console.log('FAIL ' + m);
  console.log(`accept_review self-test: ${Object.keys(expectInvalid).length} planted broken proposals, the unlabelled statement, the kept and unchanged entries and hold; ${fails.length ? fails.length + ' failure(s)' : 'all caught'}`);
  return fails.length ? 1 : 0;
}

// ---------------------------------------------------------------------------------------------------------------------------------- CLI
function parse(argv) {
  const o = { all: false, page: [], choice: [], ids: [], rule: null, dry: false, force: false, v15: process.env.ATLAS_V15 || null, selfTest: false, bad: [] };
  const list = s => String(s || '').split(',').map(x => x.trim()).filter(x => x !== '' || false);
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i], val = () => { if (i + 1 >= argv.length) { o.bad.push(`${a} needs a value`); return ''; } return argv[++i]; };
    if (a === '--all') o.all = true;
    else if (a === '--page') { const v = val(); o.page.push(...(v === '' ? [''] : list(v))); }
    else if (a === '--choice') o.choice.push(...list(val()));
    else if (a === '--ids') o.ids.push(...list(val()));
    else if (a === '--rule') { o.rule = val(); if (o.rule !== 'default') o.bad.push(`--rule ${o.rule}: the one rule is "default" (R7-7)`); }
    else if (a === '--dry-run') o.dry = true;
    else if (a === '--force') o.force = true;
    else if (a === '--v15') o.v15 = val();
    else if (a === '--self-test') o.selfTest = true;
    else o.bad.push(`unknown argument ${a}`);
  }
  for (const c of o.choice) if (!FAMILIES.includes(c) && !CHOICE_RE.test(c)) o.bad.push(`--choice ${c}: one of ${FAMILIES.join(', ')}, statement:<check id> or same-as:<row id>`);
  return o;
}

async function main(argv) {
  const o = parse(argv);
  if (o.selfTest) return selfTest();
  const anySel = o.all || o.page.length || o.choice.length || o.ids.length;
  if (o.bad.length || (!anySel && o.rule !== 'default')) {
    for (const b of o.bad) console.log('accept_review: ' + b);
    console.log('usage: node tools/accept_review.mjs (--all | --page <route> | --choice <choice> | --ids <locator or id>,…) [--rule default] [--dry-run] [--force] [--v15 <v15 root>]');
    console.log('       node tools/accept_review.mjs --rule default --dry-run      (docs/REVIEW_GUIDE.md)');
    return 2;
  }
  const T = loadTables();
  const vals = validate(T);
  const files = {}; for (const v of vals) files[v.file] = (files[v.file] || 0) + 1;
  const select = selector(o, T.routes);
  const d = decide(vals, { select, rule: o.rule, review: T.review, force: o.force });
  const next = applyChoices(T.review, d.accepted);
  const say = s => console.log(s);
  say(`accept_review: ${vals.length} proposals (${Object.entries(files).map(([f, n]) => `${path.basename(f)} ${n}`).join(', ') || 'none'}): ${byFamily(vals)}; review.json holds ${Object.keys(T.review).length} choices`);
  say(`  selected ${d.selected}${o.rule ? ` (rule ${o.rule}, R7-7)` : ' (the author\'s acceptance)'}${o.dry ? '; dry run: nothing is written' : ''}`);
  say(`  accepted ${d.accepted.length}: ${byFamily(d.accepted)}`);
  if (d.unchanged.length) say(`  unchanged ${d.unchanged.length}: review.json holds the same choice`);
  if (d.kept.length) { say(`  kept ${d.kept.length}: review.json holds another choice (--force replaces it)`); for (const v of d.kept.slice(0, 20)) say(`     ${v.e.id} ${v.loc}: review.json ${T.review[v.loc]}, proposed ${v.p.choice}`); }
  if (d.hold.length) say(`  never copied, hold ${d.hold.length}: the entries wait in pending.json for the author`);
  if (d.unlabelled.length) { say(`  not copied, ${d.unlabelled.length} without the row's labels in pending.json (tools/merge_story.mjs would refuse them):`); for (const v of d.unlabelled.slice(0, 20)) say(`     ${v.e.id} ${v.p.choice}: needs ${v.labels.join(', ')}`); }
  if (d.invalid.length) { say(`  invalid ${d.invalid.length} (never copied):`); for (const v of d.invalid.slice(0, 40)) say(`     ${v.e ? v.e.id + ' ' : ''}${v.loc} (${path.basename(v.file)}): ${v.why.join('; ')}`); if (d.invalid.length > 40) say(`     … ${d.invalid.length - 40} more`); }
  if (d.chosen.length) say(`  not sent, ${d.chosen.length} that review.json already decides`);
  if (o.rule === 'default') {
    const owner = [...d.owner].sort(byPage);
    say(`  sent to the author's list ${owner.length}: ${byFamily(owner.filter(v => v.e.pend !== 'title'))}${owner.some(v => v.e.pend === 'title') ? `; finding titles same-as ${owner.filter(v => v.e.pend === 'title').length} (A58)` : ''}`);
    for (const v of owner) say(`     ${ownerLine(v)}`);
  }
  const story = d.accepted.filter(v => v.fam === 'story');
  if (story.length) {
    const onHeld = story.filter(v => v.e.pend === 'held').length;
    say(`  story ${story.length} (on held blocks ${onHeld}, on proposed statements ${story.length - onHeld}): a story choice takes effect when tools/migrate/story_from_v15.mjs runs again, and only where the test of §1.4 clears the block in its section; a held block stays held`);
  }
  if (o.v15) {
    const m = await measure(o.v15, next);
    if (m.errors) { say(`  measure: the migration stops with ${m.errors.length} error(s): ${clip(m.errors[0], 200)}`); return 1; }
    const mine = new Set(d.accepted.filter(v => v.fam === 'story').map(v => v.loc));
    const placedMine = [...mine].filter(l => m.placed.has(l)).length;
    say(`  measure (the migration in memory, nothing written): of the ${m.story.length} story choices review.json would hold (${mine.size} copied by this run), ${m.placed.size} become story rows (${placedMine} of this run's); ${m.story.length - m.placed.size} stay in pending.json, held by the test of §1.4: ${m.why.repeats} repeat 40 characters of a row, ${m.why.page} restate only rows of other sections of their page, ${m.why.none} hold a formula or number that no row of their section or page states`);
  }
  if (!o.dry && d.accepted.length) {
    fs.writeFileSync(path.join(ROOT, 'content', 'story', 'review.json'), JSON.stringify(next, null, 1) + '\n');
    say(`  wrote content/story/review.json: ${Object.keys(next).length} choices (${d.accepted.length} copied); then run npm run content`);
  } else if (!o.dry) say('  nothing to write');
  return d.invalid.length ? 1 : 0;   // the valid proposals are copied; an invalid one among the selected makes the run fail
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(await main(process.argv.slice(2)));
