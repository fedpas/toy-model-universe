#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/story/stored_shifted.mjs — the content table content/stored_shifted.json (D62, interface 44; docs/round14/STORY_ROUND.md §3.5; owner B3): the
// stored results the five figures of Calibration 3 (the shifted view) print. The shifted scripts write no json, so their stored output is their logs (D11):
//   qnt  ← shifted_dirac.log    §(6)  [shd·QNT, shd·NUL]  the quantization on the plane waves, the empty points, the second branch, the null frequencies
//   bil  ← shifted_dirac.log    §(9)  [shd·BIL]           the quarter turn: ψJ keeps the current and the spin and reverses γ₁, γ₂ of the frame
//   beat ← shifted_energy.log   §(7)  [en·BEAT]           two quantized modes on four frames: the beat per proper and per coordinate time
//   ser  ← shifted_einstein.log §(4)  [se.SER]            the three shifted Ricci operators as series in D², c₀ … c₃ exact in κ and τ
//   low  ← shifted_einstein.log §(5)  [se.LOW]            the lowest order and the space it selects
//   zero ← shifted_einstein.log §(6)  [se.ZERO]           the roots of the zero-mode reading as series in μ
//   ds5  ← shifted_einstein.log §(10) [se.DS5]            the radius on a de Sitter base: the exponents p of φ = (−η)^p at four stored settings
//   time ← shifted_einstein.log §(11) [se.TIME]           the time scale ħ/kc and the e-folding times, as numbers
// Each block is { check, log, script, header, lines, printed, values, from }: the header line of its section and its "ok" lines verbatim (`printed`: the
// section's printed result lines, verbatim, where its values are printed there, the series and the exponents; timing lines left out); `values` read
// from those lines by one explicit pattern per line, in the log's order (no general parser: a line that its pattern does not match, a missing or an
// extra line, or a line that is not "ok", fails the tool); `from` names, for each value, the line it was read from (l<i>: lines[i], p<i>: printed[i]).
// Nothing is computed here: numbers stay as the log prints them (strings where a precision or a fraction is printed). tests/physics/p12.test.mjs reads
// the logs again and compares (S), and engines/physics/shifted.js recomputes what the kernel or arithmetic gives from these values (E, K). The figures
// load the table on demand (useTable('stored_shifted'), D34), so it is not in the bundle.
// Run after a shifted script is run again:  node tools/story/stored_shifted.mjs          (writes the table)
//                                           node tools/story/stored_shifted.mjs --check  (exit 1 when the table differs from the logs; writes nothing)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const TABLE = 'content/stored_shifted.json';
const LOGS = 'checks/selfcheck/proofs/logs';

// ---------------------------------------------------------------------------------------------------------------------- patterns
// A pattern is the line as the log prints it after "  ok   " (or the printed line, trimmed), with ⟨name⟩ where a value is read: ⟨name⟩ a number as
// printed (an integer, a decimal, a power of ten or a fraction, with its sign), ⟨name:list⟩ a list of tuples "(a,b,…), (c,d,…)", ⟨name:text⟩ any text.
const ESC = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const KIND = { num: '(-?\\d+(?:\\.\\d+)?(?:e[-+]?\\d+)?(?:/\\d+)?)', list: '(\\([^()]*\\)(?:, \\([^()]*\\))*)', text: '(.+?)' };
function compile(tpl) {
  const names = []; let re = '', last = 0;
  for (const m of tpl.matchAll(/⟨(\w+)(?::(\w+))?⟩/g)) { re += ESC(tpl.slice(last, m.index)) + KIND[m[2] || 'num']; names.push([m[1], m[2] || 'num']); last = m.index + m[0].length; }
  return { re: new RegExp('^' + re + ESC(tpl.slice(last)) + '$'), names };
}
/** "(5,0,0,0), (13,12,0,0)" → [[5, 0, 0, 0], [13, 12, 0, 0]] (numbers; a fraction stays a string) */
export const tuples = s => [...s.matchAll(/\(([^()]*)\)/g)].map(m => m[1].split(',').map(x => x.trim()).map(x => (/^-?\d+$/.test(x) ? Number(x) : x)));
/** a value as printed: an integer as a number, anything else (a decimal with its precision, a power of ten, a fraction) as the printed string */
const val = (s, kind) => (kind === 'list' ? tuples(s) : kind === 'text' ? s : /^-?\d+$/.test(s) ? Number(s) : s);

/** the patterns of each block, in the log's order: [template, (v) → the values it gives] for the ok lines, and the same for the printed lines */
export const PLAN = {
  qnt: {
    check: 'shd·QNT', log: 'shifted_dirac.log', script: 'shifted_dirac.py', section: 'shd·QNT',
    lines: [
      ['[bit] n = ⟨gens⟩, m = ⟨m⟩, kappa = ⟨kappa⟩: at E tau = pi/2, E = ⟨E0⟩ (k = ⟨k0:list⟩) and at E tau = 3 pi/2, E = ⟨E1⟩ (k = ⟨k1:list⟩) the solutions are exactly the ordinary solutions of mass E, ⟨dims⟩ per sector: E = m + (-1)^n kappa',
        v => ({ case32: { m: v.m, kappa: v.kappa, rungs: [{ n: 0, phase: '1/2', E: v.E0, k: v.k0 }, { n: 1, phase: '3/2', E: v.E1, k: v.k1 }] }, perSector: { [v.gens]: v.dims } })],
      ['[std] Dirac matrices with scipy expm: (K - m + i kappa expm(i tau K)) u = 0 has ⟨dims⟩ real dimensions at the ⟨points⟩ (k, sector) points', v => ({ std: { dims: v.dims, points: v.points } })],
      ['[bit==std] the ⟨points⟩ dimensions agree', v => ({ agree: v.points })],
      ['[bit] no plane wave at: tau = lambda_C (E tau = 2 pi); tau = lambda_C/2; tau = 0 (E = m); tau = 0 (E = m - kappa); (⟨c⟩, ⟨s⟩) with E = m + kappa sin; the same, moving; pi/2 with E = ⟨Eoff⟩ != m + kappa (both sectors)',
        v => ({ empty: [{ tau: '1', phase: '2', at: 'lambda_C' }, { tau: '1/2', at: 'lambda_C/2' }, { tau: '0', E: 'm' }, { tau: '0', E: 'm - kappa' }, { cs: [v.c, v.s], E: 'm + kappa sin', moving: true }, { phase: '1/2', E: v.Eoff, off: 'm + kappa' }] })],
      ['[bit==std] Dirac matrices give 0 at the same ⟨points⟩ points', v => ({ emptyStd: v.points })],
      ['[bit] m = ⟨m⟩, kappa = ⟨kappa⟩, E tau = pi/2: besides E = m + kappa = ⟨Eo⟩ (the ordinary half) a second branch E = kappa - m = ⟨Es⟩ lies on the other half (the solutions of mass ⟨mass⟩); for kappa < m (m = ⟨m2⟩, kappa = ⟨kappa2⟩) the second branch E = kappa - m is negative and E = ⟨E2⟩ at pi/2 has none',
        v => ({ case14: { m: v.m, kappa: v.kappa, phase: '1/2', ordinary: v.Eo, second: v.Es, secondMass: v.mass }, noSecond: { m: v.m2, kappa: v.kappa2, phase: '1/2', E: v.E2 } })],
      ['[bit] n -> n - 1 is kappa -> -kappa: the solutions at (E tau = 3 pi/2, kappa = ⟨ka⟩) and at (pi/2, kappa = ⟨kb⟩) are the same ⟨dims⟩ dimensions (E = ⟨E⟩)',
        v => ({ flip: { a: { phase: '3/2', kappa: v.ka }, b: { phase: '1/2', kappa: v.kb }, dims: v.dims, E: v.E } })],
      ['[ctl] without the factor i (kappa exp(-tau D) in place of i kappa exp(-tau D)): none at (E tau = pi/2, E = ⟨Enone⟩), and ⟨dims⟩ dimensions at tau = 0 with E = m - kappa = ⟨E⟩: the i moves the lattice by a quarter turn and excludes tau = 0',
        v => ({ withoutI: { none: { phase: '1/2', E: v.Enone }, dims: v.dims, tau: '0', E: v.E } })],
      ['[bit] n = ⟨gens⟩: at (E tau = pi/2, E = ⟨E0⟩) and (3 pi/2, E = ⟨E1⟩) the solutions are the ordinary ones of mass E, ⟨dims⟩ per sector; none at E tau = 2 pi', v => ({ perSector: { [v.gens]: v.dims } })],
      ['[bit] n = ⟨gens⟩: at (E tau = pi/2, E = ⟨E0⟩) and (3 pi/2, E = ⟨E1⟩) the solutions are the ordinary ones of mass E, ⟨dims⟩ per sector; none at E tau = 2 pi', v => ({ perSector: { [v.gens]: v.dims } })],
      ['[bit] null k = ⟨k:list⟩: no plane wave for (m, kappa, tau) = ⟨set:list⟩ (kappa tau = 1 included), both sectors: a massless fermion cannot be shifted', v => ({ nullK: v.k, nullSettings: v.set })],
      ['[bit] at the same null k with m = kappa = 0 the massless solutions (⟨dims⟩ per sector) are fixed by exp(-tau bD): no retardation at the speed of light', v => ({ massless: v.dims })],
      ['[bit] and exp(-tau bD) = 1 - tau bD is not the identity on the whole sector there (a Jordan block): it is the identity only on the solutions', () => ({ jordan: true })],
      ['[bit==std] Dirac matrices with expm(i tau K) at the null k give the same dimensions (⟨dims⟩)', v => ({ nullStd: v.dims })],
    ],
  },
  bil: {
    check: 'shd·BIL', log: 'shifted_dirac.log', script: 'shifted_dirac.py', section: 'shd·BIL',
    lines: [
      ['[bit] m = ⟨m⟩, kappa = ⟨kappa⟩, E = ⟨E⟩, k = ⟨k:list⟩, E tau = pi/2: exp(-tau bD) psi = psi J on a solution; psi gamma_⟨a⟩ psi~ and psi gamma_⟨b⟩ psi~ are unchanged, psi gamma_⟨c⟩ psi~ and psi gamma_⟨d⟩ psi~ change sign',
        v => ({ example: { m: v.m, kappa: v.kappa, E: v.E, k: v.k[0], phase: '1/2' }, kept: [v.a, v.b], reversed: [v.c, v.d] })],
      ['[bit] at (cos, sin) = (⟨c⟩, ⟨s⟩) on the rest solutions of mass ⟨E⟩: the current and the spin are unchanged, (e_1, e_2) turn by ⟨turn⟩ theta (cos 2 theta = ⟨cos2⟩)',
        v => ({ rational: { cs: [v.c, v.s], E: v.E, turn: v.turn, cos2: v.cos2 } })],
      ['[std] Dirac matrices as the image of the even algebra (products of Gamma_mu): psi J gives the same current and spin and the reversed gamma_1, gamma_2 frame vectors', () => ({ std: true })],
      ['[bit==std] the four bilinears of psi J computed on the labels equal the matrix products (max deviation ⟨dev⟩): the quantized shift is right multiplication by J, a quarter turn of psi and a half turn of its frame', v => ({ dev: v.dev })],
    ],
  },
  beat: {
    check: 'en·BEAT', log: 'shifted_energy.log', script: 'shifted_energy.py', section: 'en·BEAT',
    lines: [
      ['[bit] en.BEAT: for n_1 = 0, 2, ..., ⟨n1⟩ and n_2 = 1, 3, ..., ⟨n2⟩ (⟨pairs⟩ pairs, E_j = (2 n_j + 1)/3, tau = 3 pi/2): two quantized rest energies m + kappa and m - kappa of one species at one shift force kappa tau = (n_1 - n_2) pi/2, an odd multiple of pi/2 (both kernels checked on the labels for ⟨kernels⟩ pairs): so |mu| >= pi/2, and in the paper\'s range |mu| < ⟨range⟩ a species has one quantized rest energy on the branch E = m +- kappa at a given shift (the second branch E = kappa - m needs kappa > m)',
        v => ({ pairs: { n1: v.n1, n2: v.n2, count: v.pairs, kernels: v.kernels, muAtLeast: '1/2', range: v.range } })],
      ['[bit] en.BEAT: on the frame of four constant potentials (a = ⟨a1⟩, ⟨a2⟩, ⟨a3⟩, ⟨a4⟩) the sum A e^{-J (⟨E1⟩/a) t} + B e^{-J (⟨E2⟩/a) t} (m = ⟨m⟩, kappa = ⟨kappa⟩, proper shift pi/2, coordinate shift a pi/2; n = ⟨n1⟩ and n = ⟨n2⟩) solves the paper\'s operator at the frame factor a and its adjoint, exactly',
        v => ({ frames: [v.a1, v.a2, v.a3, v.a4].map(String), m: v.m, kappa: v.kappa, shift: '1/2', modes: [{ E: v.E1, n: v.n1 }, { E: v.E2, n: v.n2 }] })],
      ['[bit] en.BEAT: the same amplitudes at the flat coordinate frequencies ⟨f1⟩ and ⟨f2⟩ do not solve it on any of the four frames', v => ({ flat: [v.f1, v.f2] })],
      ['[bit] en.BEAT: the density <P~ P>_S has frequencies 0 and +-2/a only (a = ⟨a1⟩: beat ⟨b1⟩ per unit coordinate time; a = ⟨a2⟩: beat ⟨b2⟩ per unit coordinate time; a = ⟨a3⟩: beat ⟨b3⟩ per unit coordinate time; a = ⟨a4⟩: beat ⟨b4⟩ per unit coordinate time), the beat coefficient <A~ B>_S; per unit proper time the beat is E_1 - E_2 = 2 kappa = ⟨proper⟩, and over one shift (a tau in coordinate time, tau in proper time) the beat term changes sign: (E_1 - E_2) tau = (n_1 - n_2) pi, the shift is an odd number of half beat periods in every frame',
        v => ({ coordinate: [1, 2, 3, 4].map(i => ({ a: String(v['a' + i]), beat: String(v['b' + i]) })), proper: v.proper })],
      ['[bit] en.BEAT: with the volume factor N = 1/a of vol = N dt d^3x in the action, the Noether energy in coordinate time is constant, (⟨eA⟩/a) rho_A (1 - (pi/2) J) + (⟨eB⟩/a) rho_B (1 + (pi/2) J): both modes redshifted by the same 1/a = sqrt(1 - 2 Phi), the beat absent from it',
        v => ({ energy: { modes: [v.eA, v.eB], factorJ: '1/2', redshift: '1/a' } })],
      ['[std] en.BEAT: Dirac matrices on the four frames: the symbol K_a - m + i kappa expm(i tau K_a) annihilates both modes (frame frequency E, proper shift pi/2); the sampled density psi-bar psi (⟨periods⟩ beat periods) has its Fourier peak at 2/a within one bin; the Noether energy by quad with the frame factor and the volume factor is constant at three times and equals (5/a) r1 (1 - i pi/2) + (3/a) r2 (1 + i pi/2) (max relative deviation ⟨dev⟩)',
        v => ({ std: { periods: v.periods, dev: v.dev } })],
      ['[bit==std] en.BEAT: the beat frequency 2/a (exact on the labels; the Fourier peak of the matrices, within one bin) and the sign change of the beat over the coordinate shift a tau (e^{J (2/a)(a pi/2)} = ⟨labels⟩ exactly; e^{i (2/a)(a pi/2)} + 1 = ⟨floats⟩ in floats) on the four frames',
        v => ({ signChange: { labels: v.labels, floats: v.floats } })],
    ],
  },
  ser: {
    check: 'se.SER', log: 'shifted_einstein.log', script: 'shifted_einstein.py', section: 'se.SER',
    printed: [
      ['Ricci_⟨op:text⟩ = ⟨def:text⟩ = Ricci + [⟨c0:text⟩] + [⟨c1:text⟩] D^2 + [⟨c2:text⟩] D^4 + [⟨c3:text⟩] D^6 + ...', v => ({ series: [{ op: v.op, def: v.def, c: [v.c0, v.c1, v.c2, v.c3] }] })],
      ['Ricci_⟨op:text⟩ = ⟨def:text⟩ = Ricci + [⟨c0:text⟩] + [⟨c1:text⟩] D^2 + [⟨c2:text⟩] D^4 + [⟨c3:text⟩] D^6 + ...', v => ({ series: [{ op: v.op, def: v.def, c: [v.c0, v.c1, v.c2, v.c3] }] })],
      ['Ricci_⟨op:text⟩ = ⟨def:text⟩ = Ricci + [⟨c0:text⟩] + [⟨c1:text⟩] D^2 + [⟨c2:text⟩] D^4 + [⟨c3:text⟩] D^6 + ...', v => ({ series: [{ op: v.op, def: v.def, c: [v.c0, v.c1, v.c2, v.c3] }] })],
    ],
    lines: [
      ['[bit] se.SER: with D^2 + nabla^2 = Ricci (checked above), Ricci_xx = Ricci + sum_j c_j D^2j exactly as polynomials in (kappa, tau) to order D^⟨order⟩: c_0 = ⟨c0:text⟩; c_1 = ⟨c1:text⟩; c_2 = ⟨c2:text⟩; every c_j the closed form of ATY-010 (from D sinh(tau D), cosh(2 tau D), sinh^2(tau D)); no odd powers',
        v => ({ exact: { order: v.order, c: [v.c0, v.c1, v.c2] } })],
      ['[bit] se.SER: on the labels D maps 1-forms to grades 0 and 2 and D^2 keeps grade 1 (the ⟨frames⟩ frames of (1)), so P D^(2j+1) I = 0 and P D^2j I = D^2j on 1-forms: the compression (3.4) c(D_+^2) = P (D_+)^2 I is exactly the even part of the series', v => ({ compression: { frames: v.frames } })],
      ['[std] se.SER: numpy closed forms at three (kappa, tau, D) against the series truncated at D^⟨order⟩: max deviation ⟨dev⟩', v => ({ std: { order: v.order, dev: v.dev } })],
    ],
  },
  low: {
    check: 'se.LOW', log: 'shifted_einstein.log', script: 'shifted_einstein.py', section: 'se.LOW',
    lines: [
      ['[bit] se.LOW: on the labels, exactly in the chart: de Sitter e^a = -dx^a/(H eta) has R_ab = -3 H^2 eta_ab (the Ricci endomorphism -Lambda, Lambda = 3 H^2), anti-de Sitter e^a = dx^a/(H z) has R_ab = +3 H^2 eta_ab (H = ⟨H⟩); in the paper\'s signature the endomorphisms are +Lambda and -3 H^2',
        v => ({ chart: { H: v.H, deSitter: 'R_ab = -3 H^2 eta_ab', antiDeSitter: 'R_ab = +3 H^2 eta_ab' } })],
      ['[bit] se.LOW: at order D^0 the three operators on every 1-form are Ricci + c_0 with c_0 = ⟨c0:text⟩: (3.6a) Ricci = ⟨ra:text⟩ holds on ⟨sa:text⟩ (Lambda = ⟨la:text⟩), (3.6b) Ricci = ⟨rb:text⟩ on ⟨sb:text⟩ (Lambda = ⟨lb:text⟩), (3.6c) Ricci = ⟨rc:text⟩ on ⟨sc:text⟩, and no other pairing of the three: in the Atlas\'s signature Ric = ⟨atlas:text⟩, the same three spaces',
        v => ({ c0: v.c0.split(', '), pairs: [{ eq: '3.6a', ricci: v.ra, space: v.sa, Lambda: v.la }, { eq: '3.6b', ricci: v.rb, space: v.sb, Lambda: v.lb }, { eq: '3.6c', ricci: v.rc, space: v.sc }], atlas: v.atlas.split(', ') })],
    ],
  },
  zero: {
    check: 'se.ZERO', log: 'shifted_einstein.log', script: 'shifted_einstein.py', section: 'se.ZERO',
    printed: [
      ['lambda_a/kappa^2 = ⟨a0⟩ + (⟨a1⟩) mu^1 + (⟨a2⟩) mu^2 + (⟨a3⟩) mu^3 + (⟨a4⟩) mu^4 + ...', v => ({ roots: { a: [v.a0, v.a1, v.a2, v.a3, v.a4].map(String) } })],
      ['lambda_b/kappa^2 = ⟨b0⟩ + (⟨b1⟩) mu^1 + (⟨b2⟩) mu^2 + (⟨b3⟩) mu^3 + (⟨b4⟩) mu^4 + ...', v => ({ roots: { b: [v.b0, v.b1, v.b2, v.b3, v.b4].map(String) } })],
      ['lambda_c = ⟨c⟩ to every order computed: True', v => ({ roots: { c: String(v.c), everyOrder: true } })],
    ],
    lines: [
      ['[bit] se.ZERO: on an Einstein metric (Ricci = lambda, which commutes with everything) the leading equation of the paper, D^2 -> Ricci, is lambda + sum_j c_j lambda^j = 0; its roots near the lowest order, exactly to mu^⟨order⟩ (mu = kappa tau): lambda_a = -kappa^2 (1 + 2 mu + 2 mu^2 - mu^3/3 + ...), lambda_b = kappa^2 (1 + 2 mu + 4 mu^2 + 25 mu^3/3 + ...), lambda_c = 0 exactly: the corrections to (3.6a), (3.6b) start at first order in mu, (3.6c) has none',
        v => ({ order: v.order })],
      ['[std] se.ZERO: numpy brentq on the closed forms (kappa = 1): the roots agree with the series truncated at mu^⟨order⟩ to ⟨dev⟩ at mu = ⟨m1⟩, ⟨m2⟩, ⟨m3⟩ and to ⟨dev2⟩ (relative) at mu = ⟨m4⟩, the size of the next terms',
        v => ({ std: { order: v.order, dev: v.dev, mu: [v.m1, v.m2, v.m3], dev2: v.dev2, mu2: v.m4 } })],
    ],
  },
  ds5: {
    check: 'se.DS5', log: 'shifted_einstein.log', script: 'shifted_einstein.py', section: 'se.DS5',
    printed: [
      [[1, 2, 3, 4, 5, 6, 7, 8].map(i => `H = ⟨H${i}⟩, eps kappa^2 = ⟨k${i}⟩: p = ⟨p${i}⟩ ⟨w${i}:text⟩`).join('; '),
        v => ({ exponents: [1, 2, 3, 4, 5, 6, 7, 8].map(i => ({ H: String(v['H' + i]), ek2: v['k' + i], p: v['p' + i], einstein: einsteinWord(v['w' + i]) })) })],
      ['on the base with 3 H^2 = kappa^2 (eps = 1) the growth rate is r_+ = kappa (sqrt 7 - sqrt 3)/2 = ⟨rp⟩ kappa; on the five-dimensional de Sitter solution r = H = kappa/⟨q⟩',
        v => ({ base3H2: { rPlus: v.rp, closed: '(sqrt 7 - sqrt 3)/2' }, deSitter5: { r: `1/${v.q}` } })],
    ],
    lines: [
      ['[bit] se.DS5: on de Sitter e^a = -dx^a/(H eta), phi = (-eta)^p solves (4.3), box phi = eps kappa^2 phi, exactly in the chart iff p^2 - 3p - eps kappa^2/H^2 = 0, at (H, eps kappa^2) = ⟨set:list⟩ with both roots, and then Ric5_44 = eps kappa^2: in cosmic time (-H eta = e^{-H t}) phi = e^{r t} with r^2 + 3 H r = eps kappa^2, the base\'s friction 3 H r included',
        v => ({ settings: v.set.map(([H, k]) => ({ H: String(H), ek2: k })) })],
      ['[bit] se.DS5: a negative result against the printed (4.4), kept: on the base with H = ⟨H⟩, eps kappa^2 = ⟨ek2⟩ the paper\'s e^{+-sqrt(eps) kappa t} = (-eta)^{-+⟨pp⟩} does not solve (4.3) (box phi != eps kappa^2 phi), and the homogeneous solutions are e^{t} and e^{⟨r2⟩ t}; (4.4) is the case H = 0 (no friction), approached when H << kappa',
        v => ({ printed44: { H: String(v.H), ek2: v.ek2, p: v.pp, rates: [1, v.r2] } })],
      ['[bit] se.DS5: the five-dimensional equation Ric5 = -eps kappa^2 eta (all ⟨comps⟩ components) holds on a de Sitter base only for phi ~ e^{H t} (p = ⟨p⟩) with eps kappa^2 = 4 H^2 (H = ⟨H1⟩ and ⟨H2⟩): five-dimensional de Sitter in flat slicing, eps = +1 (D_+ D_-); there the four-dimensional constant is 3 H^2 = (3/4) kappa^2; the other root, and both roots at eps kappa^2 = ⟨e1⟩ and ⟨e2⟩, satisfy the 44 component only',
        v => ({ fiveD: { components: v.comps, p: v.p, H: [String(v.H1), String(v.H2)], only44: [v.e1, v.e2] } })],
      ['[std] se.DS5: scipy solve_ivp (rtol 1e-12) on f\'\' + 3 H f\' = eps kappa^2 f, f(0) = 1, f\'(0) = 0.3, four (H, eps kappa^2) including H = 1/sqrt 3 (the base with 3 H^2 = kappa^2): the closed form a_+ e^{r_+ t} + a_- e^{r_- t} agrees to ⟨dev⟩; the paper\'s (4.4) with the same data differs by up to ⟨off⟩% at t = 0.5 ... 2',
        v => ({ std: { dev: v.dev, paperOff: v.off } })],
    ],
  },
  time: {
    check: 'se.TIME', log: 'shifted_einstein.log', script: 'shifted_einstein.py', section: 'se.TIME',
    lines: [
      ['[std] se.TIME: hbar/kc = 1/(c x ⟨k⟩ cm^-1) = ⟨s⟩ s = ⟨y⟩ years (Julian year, c = ⟨c⟩ cm/s); the paper\'s (3 pi)^-1 x 10^11 years = ⟨py⟩ years (c = 3e10 cm/s and pi x 10^7 s per year), ratio ⟨ratio⟩; the e-folding times of the solutions of (10) at these constants: 2 hbar/kc = ⟨y2⟩ years for r = kappa/2, hbar/(⟨rp⟩ kc) = ⟨y3⟩ years for r_+ on the base with 3 H^2 = kappa^2 (numbers only; the coincidence with the age of the universe is the paper\'s remark)',
        v => ({ k: v.k, seconds: v.s, years: v.y, c: v.c, paper: { years: v.py, ratio: v.ratio }, efold: [{ r: '1/2', years: v.y2 }, { r: v.rp, years: v.y3 }] })],
    ],
  },
};
/** the two words of the exponents line: the 44 component only, or the whole five-dimensional Einstein equation */
function einsteinWord(w) {
  if (w === '44 component only') return false;
  if (w === 'Einstein (Ric5 = -eps kappa^2 eta)') return true;
  throw new Error(`ds5: unknown word "${w}" after an exponent`);
}

// ---------------------------------------------------------------------------------------------------------------------- reading
const HEADER = /^\(\d+\)(?:-\(\d+\))? \[([^\]]+)\] /;
const TIMING = /^\s+\((?:total )?[\d.]+ s\)$/;
/** the section of a log whose header names the check id: { header, ok: [verbatim lines], printed: [verbatim lines] } */
export function sectionOf(text, id, where) {
  const L = text.split('\n'), i = L.findIndex(l => { const m = HEADER.exec(l); return m && m[1].split(', ').includes(id); });
  if (i < 0) throw new Error(`${where}: no section [${id}]`);
  const out = { header: L[i], ok: [], printed: [] };
  for (let j = i + 1; j < L.length; j++) {
    const l = L[j];
    if (!l.trim() || HEADER.test(l) || /^\s*\[time\]/.test(l) || /^(checks|FAILS|\d+ checks)/.test(l)) break;
    if (TIMING.test(l)) continue;
    if (/^ {2}ok {3}\[/.test(l)) out.ok.push(l);
    else if (/^ {2}(FAIL|fail)/.test(l)) throw new Error(`${where}: a failed line in [${id}]: ${l.trim()}`);
    else out.printed.push(l);
  }
  return out;
}
/** a value read twice is an error; lists add up (the series of three printed lines), records merge */
function merge(into, part, tag, from, where) {
  for (const [k, v] of Object.entries(part)) {
    if (!(k in into)) { into[k] = v; from[k] = tag; continue; }
    if (Array.isArray(into[k]) && Array.isArray(v)) { into[k] = [...into[k], ...v]; from[k] += `,${tag}`; continue; }
    if (into[k] && typeof into[k] === 'object' && v && typeof v === 'object' && !Array.isArray(v)) {
      const sub = {}; merge(into[k], v, tag, sub, `${where}.${k}`); from[k] += `,${tag}`; continue;
    }
    throw new Error(`${where}: the value ${k} is read twice`);
  }
}
function readLines(list, pats, kind, values, from, where) {
  if (list.length !== pats.length) throw new Error(`${where}: ${list.length} ${kind} lines, the plan reads ${pats.length}`);
  list.forEach((line, i) => {
    const body = kind === 'ok' ? line.replace(/^ {2}ok {3}/, '') : line.trim();
    const { re, names } = compile(pats[i][0]);
    const m = re.exec(body);
    if (!m) throw new Error(`${where}: ${kind} line ${i + 1} does not read: ${body.slice(0, 120)}`);
    const v = Object.fromEntries(names.map(([n, k], j) => [n, val(m[j + 1], k)]));
    merge(values, pats[i][1](v), `${kind === 'ok' ? 'l' : 'p'}${i}`, from, where);
  });
}
/** one block of the table from the logs under root */
export function readBlock(name, root = ROOT) {
  const P = PLAN[name], file = `${LOGS}/${P.log}`, where = `${name} (${file})`;
  const s = sectionOf(fs.readFileSync(path.join(root, file), 'utf8'), P.section, where);
  const values = {}, from = {};
  readLines(s.printed, P.printed || [], 'printed', values, from, where);
  readLines(s.ok, P.lines, 'ok', values, from, where);
  return { check: P.check, log: file, script: `checks/selfcheck/proofs/${P.script}`, header: s.header, lines: s.ok, printed: s.printed, values, from };
}
/** the whole table */
export function build(root = ROOT) {
  return Object.fromEntries(Object.keys(PLAN).map(name => [name, readBlock(name, root)]));
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const file = path.join(ROOT, TABLE);
  let t;
  try { t = build(); } catch (e) { console.log(`stored_shifted: ${e.message}`); process.exit(1); }
  const text = JSON.stringify(t, null, 1) + '\n';
  if (process.argv.includes('--check')) {
    const same = fs.existsSync(file) && fs.readFileSync(file, 'utf8') === text;
    console.log(same ? `stored_shifted --check: ${TABLE} equals the logs (${Object.keys(PLAN).length} blocks)` : `stored_shifted --check: ${TABLE} differs from the logs; run node tools/story/stored_shifted.mjs`);
    process.exit(same ? 0 : 1);
  }
  fs.writeFileSync(file, text);
  console.log(`stored_shifted: ${Object.entries(t).map(([b, x]) => `${b} (${x.lines.length} lines${x.printed.length ? ` + ${x.printed.length} printed` : ''})`).join(', ')} → ${TABLE}, ${fs.statSync(file).size} bytes`);
}
