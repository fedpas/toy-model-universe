#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/story/split_edges.mjs — the `depends` edges of the split lines (docs/round15/PLAN.md §2.4, the labelling pass A62; owner L3, judge J2, applied by
// R8). A row with `splitFrom` is a line split from a longer v15 row (docs/02_CONTENT_MODEL.md §1: GRV-012 keeps the first line, GRV-012b, GRV-012c … are
// the further lines) and should carry an edge to its first line, which the migration never wrote (docs/round14/SPINE.md §5.5; the extraction reads the
// pair as `continues`, rule E2b). This tool proposes that edge for every split line, by one rule:
//   equiv    by default: a line of a split row restates part of its first line
//   derives  where the line's research text opens with a consequence word (CONSEQUENCE: so, hence, therefore, it follows): it follows from its first line
// A line that has an edge to its first line already keeps it and gets none (none had one in 2.15.0). The rule decides nothing else; beside each edge
// the tool prints flags for the judge's sample (they change no relation):
//   twin      the line is the mathematics twin of its first line (V5: a b-row visible in the other mode only)
//   question  the line's text ends with a question mark (the physicist's questions of `steps/baez` · bz-persp)
//   reading   the line opens with a reading or a naming ("reading", "our reading", "calling", "the name", …): the house relates a reading to what it
//             reads by `derives`, which the rule cannot see
//   near      the line opens with a word of the storyteller's derives set (tools/check_learner_texts.mjs C4) that is no consequence word of the rule
//             ("thus", "then", "from the", "as a result", …), or with a consequence word used as a name ("so(4,2)")
//   before    a derives case with a sibling line before it: the consequence word may point at that line rather than at the first line
// Read-only on the tables (content/rows.json, content/texts.json). It prints the edges (the derives cases first, then the flags, the counts by group and
// every edge); with --write it writes them into the overlay content/story/depends_a62.json, entries { row, id, rel, from: "a62", task: 4, note,
// verdict: null }: the entries of task 4 are replaced, a verdict the judge has filled in for the same row and id is kept, the entry of a line that has
// its edge already stays as it was (so a --write after the overlay is applied changes nothing), and the entries of tasks 1–3 (the labeller's other
// proposals, docs/round15/LABELLING_A62.md) stay as they are. The overlay is read by no tool yet: the release owner applies the
// entries the judge accepts (PLAN §2.4: a step 0 of tools/merge_story.mjs, idempotent, booked). Deterministic: the same tables give the same bytes.
// Usage (from the repository root):
//   node tools/story/split_edges.mjs                the edges, printed (nothing is written)
//   node tools/story/split_edges.mjs --json         the same, as JSON
//   node tools/story/split_edges.mjs --write        writes the task-4 entries into content/story/depends_a62.json
//   --root <dir>                                    reads (and with --write writes) <dir>/content instead of the repository's: a scratch copy
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
export const OVERLAY = 'content/story/depends_a62.json';
export const FROM = 'a62';
export const TASK = 4;
const readJSON = (f, fallback) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback);
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

/** the consequence words of the rule (PLAN §2.4) and the rest of the storyteller's derives set (C4), which only flags a line */
export const CONSEQUENCE = ['so', 'hence', 'therefore', 'it follows'];
export const NEAR = ['thus', 'then', 'this means', 'from this', 'from the', 'because of this', 'as a result', 'which gives', 'which is why', 'consequently'];
const READING = /^(reading|our reading|genesis reading|calling|the name|naming)\b/i;
const opening = body => String(body).replace(/^[\s"“‘'([]+/, '').toLowerCase();
/** the word w opens the text, followed by a space, a comma, a colon or the end: "So the …", "Hence," — not "so(4,2)" nor "sonic" */
const opensWord = (body, w) => { const b = opening(body); return b.startsWith(w) && /^([\s,;:]|$)/.test(b.slice(w.length)); };
/** the word w opens the text in any other way (a name such as "so(4,2)"; not a longer word such as "sonic") */
const opensAsName = (body, w) => { const b = opening(body); return b.startsWith(w) && !opensWord(body, w) && !/^[\p{L}\p{N}]/u.test(b.slice(w.length)); };

// ------------------------------------------------------------------------------------------------------------------------------- the tables
/** { rows, byId, research: Map row → its research text (register full, no chain; the mode both first, then phys, then math) } */
export function loadTables(root = ROOT) {
  const C = path.join(root, 'content');
  const rows = readJSON(path.join(C, 'rows.json'), []), texts = readJSON(path.join(C, 'texts.json'), []);
  const rank = t => ({ both: 0, phys: 1, math: 2 }[t.mode || 'both'] ?? 3);
  const research = new Map();
  for (const t of [...texts].filter(t => t && t.level === 'research' && t.chain == null && (t.register || 'full') === 'full' && !t.lens).sort((a, b) => rank(a) - rank(b)))
    if (!research.has(t.row)) research.set(t.row, t.body || '');
  return { rows, byId: new Map(rows.map(r => [r.id, r])), research };
}
/** V5's rule (tools/story/extract_chains.mjs isTwin): b is split from p, visible in one mode only, a mode p is not shown in */
function isTwin(T, p, b) {
  const r = T.byId.get(b), q = T.byId.get(p);
  if (!r || !q || r.splitFrom !== p) return false;
  const vb = r.visibleTo || ['phys', 'math'], vp = q.visibleTo || ['phys', 'math'];
  return vb.length === 1 && !vp.includes(vb[0]);
}
const groupOf = id => String(id).split('-')[0];
const homeOf = r => { const so = [...(r.shownOn || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0]; return so ? `${so.page} · ${so.section}` : '(not placed)'; };

// ------------------------------------------------------------------------------------------------------------------------------- the rule
/**
 * The proposed edge of every split line: [{ row, id, rel, word, flags: { twin, question, reading, near, before }, home, opens }], sorted by row; and
 * { kept: [rows that have an edge to their first line already], deep: [rows whose first line is split itself], missing: [rows whose first line is no row] }.
 */
export function splitEdges(T) {
  const split = T.rows.filter(r => r.splitFrom).sort((a, b) => cmpStr(a.id, b.id));
  const siblings = new Map();
  for (const r of split) { if (!siblings.has(r.splitFrom)) siblings.set(r.splitFrom, []); siblings.get(r.splitFrom).push(r.id); }
  const edges = [], kept = [], deep = [], missing = [];
  for (const r of split) {
    const p = T.byId.get(r.splitFrom);
    if (!p) { missing.push(r.id); continue; }
    if (p.splitFrom) deep.push(r.id);
    if ((r.depends || []).some(d => d.id === r.splitFrom)) { kept.push(r.id); continue; }
    const body = T.research.get(r.id) || '';
    const word = CONSEQUENCE.find(w => opensWord(body, w)) || null;
    const sib = siblings.get(r.splitFrom), at = sib.indexOf(r.id);
    const asName = CONSEQUENCE.some(w => opensAsName(body, w)) ? `${opening(body).split(/\s/)[0]} (a name)` : null;
    const nearWord = word ? null : (NEAR.find(w => opensWord(body, w)) || asName);
    const flags = {
      twin: isTwin(T, r.splitFrom, r.id),
      question: /\?\s*$/.test(body.trim()),
      reading: READING.test(body.trim()),
      near: nearWord,
      before: word && at > 0 ? sib[at - 1] : null,
    };
    edges.push({ row: r.id, id: r.splitFrom, rel: word ? 'derives' : 'equiv', word, flags, home: homeOf(r), opens: body.slice(0, 90) });
  }
  return { edges, kept, deep, missing };
}
/** the note of an overlay entry: the rule's reason, then the flags */
export function noteOf(e) {
  const f = e.flags, bits = [e.rel === 'derives' ? `derives: opens with “${e.opens.split(/\s+/).slice(0, e.word.split(' ').length).join(' ')}”` : 'equiv by default (a line restates part of its first line)'];
  if (f.twin) bits.push('twin'); if (f.question) bits.push('question'); if (f.reading) bits.push('reading');
  if (f.near) bits.push(`near: opens with “${f.near}”`); if (f.before) bits.push(`before: the line before is ${f.before}`);
  return `split line of ${e.id} (${e.home}); ${bits.join('; ')}`;
}

// ------------------------------------------------------------------------------------------------------------------------------- the overlay
export const ABOUT = 'The labelling pass A62 (docs/round15/PLAN.md §2; the proposals with their clauses: docs/round15/LABELLING_A62.md; the verdicts: ' +
  'docs/round15/JUDGE_A62.md). Each entry is a proposed change to the `depends` of `row` (docs/LABELLING_SCHEME.md §4): without `op`, add { id, rel } ' +
  '(nothing when the row has that edge already); op "drop": remove { id, rel } from the row; op "turn": remove it and add { id: row, rel } to the row ' +
  '`id`; op "set-cycle": the row\'s { id, rel } becomes { id, rel: "cycle" }. task: 1 the genesis ladder, 2 the seven sections that are not lists, ' +
  '3 the seven directed cycles, 4 the split lines (written by tools/story/split_edges.mjs --write, which replaces the task-4 entries and keeps the others ' +
  'and every verdict). verdict: null until the judge writes "accept", "reject", "turn" or { "rel": <the relation> }; the release owner applies the ' +
  'accepted entries (a turned one turned, a changed one with its relation) in a step 0 of tools/merge_story.mjs. Nothing here is applied yet.';
const ENTRY_KEYS = ['row', 'id', 'rel', 'op', 'from', 'task', 'note', 'verdict'];
/** the overlay's format: the about line, then one entry per line (diffs read per entry), sorted by task, row, id, op */
export function formatOverlay(edges, about = ABOUT) {
  const one = e => '  {' + [...ENTRY_KEYS.filter(k => k in e), ...Object.keys(e).filter(k => !ENTRY_KEYS.includes(k)).sort(cmpStr)].map(k => `${JSON.stringify(k)}: ${JSON.stringify(e[k])}`).join(', ') + '}';
  const list = [...edges].sort((a, b) => a.task - b.task || cmpStr(a.row, b.row) || cmpStr(a.id, b.id) || cmpStr(a.op || '', b.op || ''));
  return `{\n "_about": ${JSON.stringify(about)},\n "edges": [\n${list.map(one).join(',\n')}\n ]\n}\n`;
}
/**
 * The overlay after a --write: the entries of the other tasks kept, the task-4 entries replaced, a verdict of the same row and id kept; the old task-4
 * entry of a line that has its edge already (`kept`: the overlay applied to the tables, or an edge written by hand) stays as it was, so a --write after
 * the release owner has applied the overlay changes nothing.
 */
export function mergeOverlay(old, edges, kept = []) {
  const prev = Array.isArray(old && old.edges) ? old.edges : [];
  const verdict = new Map(prev.filter(e => e.task === TASK && e.verdict != null).map(e => [`${e.row}|${e.id}`, e.verdict]));
  const mine = edges.map(e => ({ row: e.row, id: e.id, rel: e.rel, from: FROM, task: TASK, note: noteOf(e), verdict: verdict.get(`${e.row}|${e.id}`) ?? null }));
  const stays = new Set(kept);
  return [...prev.filter(e => e.task !== TASK || stays.has(e.row)), ...mine];
}

// ------------------------------------------------------------------------------------------------------------------------------- printing
export function printEdges({ edges, kept, deep, missing }) {
  const out = [], der = edges.filter(e => e.rel === 'derives'), F = k => edges.filter(e => e.flags[k]);
  out.push(`split_edges: ${edges.length} edge(s) to write (equiv ${edges.length - der.length}, derives ${der.length}); ${kept.length} line(s) keep an edge they have; ${edges.length + kept.length + missing.length} split line(s) in all`);
  if (deep.length) out.push(`warning: ${deep.length} line(s) split from a line that is split itself: ${deep.join(', ')}`);
  if (missing.length) out.push(`warning: ${missing.length} line(s) whose first line is no row: ${missing.join(', ')}`);
  out.push('', `derives cases (${der.length}), for the judge to read:`);
  for (const e of der) out.push(`- ${e.row} —derives→ ${e.id} (${e.home}): “${e.opens}…”${e.flags.before ? `; before: the line before is ${e.flags.before}` : ''}`);
  out.push('', 'flags (for the sample; no relation changes):');
  for (const k of ['twin', 'question', 'reading', 'near']) out.push(`- ${k} (${F(k).length}): ${F(k).map(e => e.row + (k === 'near' ? ` “${e.flags.near}”` : '')).join(', ') || '—'}`);
  const byGroup = {};
  for (const e of edges) { const g = groupOf(e.row); byGroup[g] ||= { equiv: 0, derives: 0 }; byGroup[g][e.rel]++; }
  out.push('', 'by group: ' + Object.keys(byGroup).sort(cmpStr).map(g => `${g} ${byGroup[g].equiv + byGroup[g].derives}${byGroup[g].derives ? ` (derives ${byGroup[g].derives})` : ''}`).join(', '));
  out.push('', 'the edges (row → first line, relation, home, flags):');
  for (const e of edges) {
    const fl = ['twin', 'question', 'reading'].filter(k => e.flags[k]).concat(e.flags.near ? [`near “${e.flags.near}”`] : [], e.flags.before ? [`before ${e.flags.before}`] : []);
    out.push(`${e.row} → ${e.id} ${e.rel} · ${e.home}${fl.length ? ` · ${fl.join(', ')}` : ''}`);
  }
  return out.join('\n');
}

// ------------------------------------------------------------------------------------------------------------------------------- CLI
function main(argv) {
  const arg = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  const root = arg('--root') ? path.resolve(arg('--root')) : ROOT;
  const T = loadTables(root);
  if (!T.rows.length) { console.log(`split_edges: no rows in ${path.join(root, 'content', 'rows.json')}`); return 1; }
  const res = splitEdges(T);
  if (argv.includes('--write')) {
    const f = path.join(root, OVERLAY), all = mergeOverlay(readJSON(f, null), res.edges, res.kept);
    const stayed = all.filter(e => e.task === TASK).length - res.edges.length;
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, formatOverlay(all));
    console.log(`split_edges: ${res.edges.length} task-4 entries written to ${path.relative(root, f)}${stayed ? `, ${stayed} kept for lines that have their edge already` : ''} (${all.length - res.edges.length - stayed} entries of the other tasks kept)`);
    return 0;
  }
  console.log(argv.includes('--json') ? JSON.stringify(res, null, 1) : printEdges(res));
  return 0;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(main(process.argv.slice(2)));
