#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/story/extract_chains.mjs — the mechanical extraction of the chains of a page section (docs/round14/STORY_ROUND.md §3.1, rules E1–E9; the spine
// it drew is docs/round14/SPINE.md; owner B1). A chain is the unit of story (D52): an ordered set of positions of one section, each consecutive pair
// joined by a relation of `depends` (docs/LABELLING_SCHEME.md §4), by `continues` (a split line and its first line), or by `order` (adjacent only).
// This tool draws the mechanical draft the composers start from; it never decides a story. Read-only on the tables (content/rows.json, pages.json,
// check_runs.json, derived/status.json), except --into, which adds draft chains to an owner's file. It works in this order:
//   E1 the rows of a section: its shownOn entries of role result or detail (story rows, the other roles, the sections intro and top-notes, the inputs
//      sections and the lines of the translation matrices left out, D35), in shownOn order, then by id; a mathematics twin (a b-row split from a row
//      of the section, visible in the other mode only) rides with its parent as one position; --groups restricts the rows to some id groups
//   E2 the induced subgraph of depends: d → r when r rests on d by derives, instance or uses-input; equiv and cycle undirected; E2b: a split line
//      continues its first line (splitFrom, undirected); contradicts never joins two rows (A6: it is to be resolved), so such a pair is kept apart
//   E3 weakly connected components; a directed cycle is broken at its earliest row (the edges into that row from its cycle leave) and reported; then
//      the transitive reduction H of the directed edges
//   E4 a greedy path cover of H: the longest path (ties: the earliest start in shownOn order, then the earlier rows) is a chain, its rows leave,
//      repeat; a path longer than MAX is cut into ⌈length / MAX⌉ nearly equal pieces; a remainder of one or two rows joins the chain it hangs from,
//      as a branch, while that chain stays within MAX + 2
//   E5 the link between consecutive positions: the relation of the edge between them (dir fwd: the later rests on the earlier; back: the reverse),
//      else the relation to the nearest earlier position the later one rests on (from), else order
//   E6 the shape: cycle (a cycle edge joins two positions), ladder (three positions or more, each row with a cell (p,q,r), the largest n = p + q + r
//      of each row climbing or descending strictly), fork (a link has from), line
//   E7 the status: the weakest computed status of the positions and their twins (open > cited > ours > input > standard and proved-by-atlas)
//   E8 a singleton is attached to a chain of the section that shares a dependency outside the section with it (never an input, never a hub: a row
//      the section's rows rest on more than three times), else to a chain holding a labelling neighbour (status.json), else it is a side note;
//      attached rows follow the last position of their chain
//   E9 the joins: the edges between two chains (printed "hangs from"); in a chain record, the depends edges from a row told in an earlier chain of
//      the same page to a position (joinsOf, shared with tools/merge_chains.mjs)
// The output is deterministic: the same tables give the same bytes.
// Usage (from the repository root):
//   node tools/story/extract_chains.mjs --page <route> [--section <id>] [--groups A,B] [--max 8] [--json]   the draft chains, printed (or as JSON)
//   node tools/story/extract_chains.mjs --page <route> [--section <id>] [--groups A,B] --into content/chains/<owner>/chains.json
//        adds the draft chains of the sections that have none in that file yet (a composed chain is never overwritten); titles stay empty for the
//        composer (tools/merge_chains.mjs refuses an untitled chain)
//   node tools/story/extract_chains.mjs --diff content/chains/<owner>/chains.json [--groups A,B] [--json]
//        every departure of the composed chains from the mechanical draft of their section (a position added, removed or moved, a mention, a
//        contrasts link, a title): what the composer records in extracted.departures (the groups are those of the rows the file tells there)
//   node tools/story/extract_chains.mjs --counts                       the tables of SPINE.md §6: per page (§6.1, with the chains and singletons
//                                                                      without E2b) and per wave (§6.2, the pilot rows cut out of their sections)
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const readJSON = (f, fallback) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback);
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

export const MAX = 8;
export const DIRECTED = new Set(['derives', 'instance', 'uses-input']);
export const UNDIRECTED = new Set(['equiv', 'cycle', 'continues']);       // continues: E2b, a split line and its first line
export const CHAIN_RELS = new Set([...DIRECTED, 'equiv', 'cycle', 'continues', 'order', 'contrasts']);
const KEEP_ROLES = new Set(['result', 'detail']);                          // E1: the roles of a statement told in a section
const RESERVED = new Set(['intro', 'top-notes']);
export const MATRIX_LINE = /^[A-Z]{2,4}-M\d{2}$/;                          // the lines of the translation matrices (D35): a table is not a story
const SKIP_PAGES = new Set(['logbook', 'ask', 'glossary']);               // the Logbook, Ask and the glossary are no story pages (SPINE.md §6.1)
export const WEAK = { open: 5, cited: 4, ours: 3, input: 2, candidate: 2, standard: 1, 'proved-by-atlas': 0, meta: -1 };

// ------------------------------------------------------------------------------------------------------------------------------- the tables
/** the tables the extraction reads: { rows, pages, runs, status, byId } */
export function loadTables(root = ROOT) {
  const C = path.join(root, 'content');
  const rows = readJSON(path.join(C, 'rows.json'), []), pages = readJSON(path.join(C, 'pages.json'), []);
  const runs = readJSON(path.join(C, 'check_runs.json'), []), status = readJSON(path.join(C, 'derived', 'status.json'), {});
  return makeTables({ rows, pages, runs, status });
}
/** the same from tables in memory (the tests and tools/merge_chains.mjs build them from the merged rows) */
export function makeTables({ rows = [], pages = [], runs = [], status = {} }) {
  return { rows, pages, runs, status, byId: new Map(rows.map(r => [r.id, r])), lastRun: lastRuns(runs) };
}
function lastRuns(runs) { const last = {}; for (const r of runs) if (r && r.script && (!last[r.script] || r.date >= last[r.script].date)) last[r.script] = r; return last; }

/** a row's computed status: content/derived/status.json, else the rule of tools/build_content.mjs for a row without v15 flags (D22) */
export function statusOf(T, id) {
  if (T.status[id] && T.status[id].status) return T.status[id].status;
  const r = T.byId.get(id); if (!r) return null;
  if (r.kind === 'story' || r.kind === 'meta') return 'meta';
  const runOf = s => { const k = s && (s.startsWith('checks/') ? s : 'checks/' + s); return T.lastRun[k] || Object.values(T.lastRun).find(x => x.script.endsWith('/' + path.basename(s || ''))) || null; };
  const passed = s => { const x = runOf(s); return !!x && x.passed !== false && !(Number(x.fail) > 0); };
  const ev = r.evidence || [], ran = ev.filter(e => e.mode === 'ran');
  if (['question', 'conjecture', 'pointer'].includes(r.kind) || r.ptype === 'open') return 'open';
  if (r.id.startsWith('CAND-')) return ran.some(e => passed(e.script || e.check)) ? 'proved-by-atlas' : 'candidate';
  if (ran.some(e => passed(e.script || e.check))) return 'proved-by-atlas';
  if (ran.length || (ev.length && ev.every(e => e.mode === 'read'))) return 'cited';
  if (r.kind === 'reading' || r.ptype === 'reading') return 'ours';
  if (r.group === 'INP') return 'input';
  return 'ours';
}
/** the weakest status of a list of rows (meta and unknown rows left out) */
export function weakest(T, ids) {
  let w = null;
  for (const id of ids) { const s = statusOf(T, id); if (!s || s === 'meta') continue; if (w === null || (WEAK[s] ?? 0) > (WEAK[w] ?? 0)) w = s; }
  return w || 'meta';
}

// ------------------------------------------------------------------------------------------------------------------------------- E1 the rows
export const pageKey = route => String(route).replace(/\//g, '-');
const pageOf = (T, route) => T.pages.find(p => p.route === route) || null;
/** is a section of a page an inputs section (the fold "Inputs": the section needs, or a section marked inputs) */
export function isInputsSection(T, route, section) {
  const p = pageOf(T, route); const s = p && (p.sections || []).find(x => x.id === section);
  return section === 'needs' || !!(s && s.inputs === true);
}
const groupOf = id => String(id).split('-')[0];
/**
 * E1: the positions of a section, in shownOn order then by id, and its twins ({ parent → b-row }); `groups` (a Set or null) restricts the rows,
 * `given` (a list of ids) replaces the section's rows (the waves of SPINE.md §6.2 cut the pilot rows out of their sections).
 */
export function sectionRows(T, route, section, { groups = null, given = null } = {}) {
  let list;
  if (given) list = given.filter(id => T.byId.has(id));
  else {
    const ents = [];
    for (const r of T.rows) for (const so of r.shownOn || []) {
      if (so.page !== route || so.section !== section || r.kind === 'story' || !KEEP_ROLES.has(so.role || 'result') || MATRIX_LINE.test(r.id)) continue;
      if (groups && !groups.has(groupOf(r.id))) continue;
      ents.push({ id: r.id, order: so.order ?? 0 });
    }
    const seen = new Set();
    list = ents.sort((a, b) => a.order - b.order || cmpStr(a.id, b.id)).filter(e => !seen.has(e.id) && seen.add(e.id)).map(e => e.id);
  }
  const twins = {};
  const vis = id => JSON.stringify((T.byId.get(id) || {}).visibleTo || ['phys', 'math']);
  for (const id of [...list]) {
    const r = T.byId.get(id), p = r && r.splitFrom;
    if (!p || !list.includes(p) || twins[p]) continue;
    if (isTwin(T, p, id)) { twins[p] = id; list = list.filter(x => x !== id); }
  }
  return { list, twins };
}
/** V5's rule: b is the b-row split from p, visible in one mode only, a mode p is not shown in */
export function isTwin(T, p, b) {
  const r = T.byId.get(b), q = T.byId.get(p);
  if (!r || !q || r.splitFrom !== p) return false;
  const vb = r.visibleTo || ['phys', 'math'], vp = q.visibleTo || ['phys', 'math'];
  return vb.length === 1 && !vp.includes(vb[0]);
}

// ------------------------------------------------------------------------------------------------------------------------------- E2 the graph
/**
 * The dependencies of a position as the extraction reads them: its row's depends, its twin's (a dependency on a twin names its parent), and, with
 * E2b, `continues` to the row it is split from. contradicts and restates are kept for the caller to read, never as an edge of a component.
 */
export function depsOf(T, id, twins = {}, { split = true } = {}) {
  const parentOf = new Map(Object.entries(twins).map(([p, b]) => [b, p]));
  const r = T.byId.get(id); if (!r) return [];
  const own = [...(r.depends || []), ...(twins[id] ? (T.byId.get(twins[id]) || {}).depends || [] : [])];
  if (split && r.splitFrom) own.push({ id: r.splitFrom, rel: 'continues' });
  return own.map(d => ({ id: parentOf.get(d.id) || d.id, rel: d.rel })).filter(d => d.id !== id);
}
/** the relation of the edge between two positions: { rel, dir } (fwd: b rests on a; back: a rests on b), or null; never contradicts */
export function relBetween(T, a, b, twins = {}, opts = {}) {
  for (const d of depsOf(T, b, twins, opts)) if (d.id === a && CHAIN_RELS.has(d.rel)) return { rel: d.rel, dir: 'fwd' };
  for (const d of depsOf(T, a, twins, opts)) if (d.id === b && CHAIN_RELS.has(d.rel)) return { rel: d.rel, dir: 'back' };
  return null;
}
/** E5: the links of an ordered list of positions: rows.length − 1 records { rel[, dir: "back"][, from] } */
export function linksOf(T, ord, twins = {}, opts = {}) {
  const links = [];
  for (let i = 1; i < ord.length; i++) {
    const e = relBetween(T, ord[i - 1], ord[i], twins, opts);
    if (e) { links.push(e.dir === 'back' ? { rel: e.rel, dir: 'back' } : { rel: e.rel }); continue; }
    let via = null;
    for (let j = i - 2; j >= 0 && !via; j--) { const e2 = relBetween(T, ord[j], ord[i], twins, opts); if (e2) via = e2.dir === 'back' ? { rel: e2.rel, dir: 'back', from: ord[j] } : { rel: e2.rel, from: ord[j] }; }
    links.push(via || { rel: 'order' });
  }
  return links;
}
/** the largest n = p + q + r among a row's cells written (p,q,r), or null */
export function maxN(T, id) {
  const ns = ((T.byId.get(id) || {}).cells || []).map(c => /^\((\d+),(\d+),(\d+)\)$/.exec(String(c).trim())).filter(Boolean).map(m => +m[1] + +m[2] + +m[3]);
  return ns.length ? Math.max(...ns) : null;
}
/** E6 (STORY_ROUND.md §2.1): cycle, then ladder, then fork, then line */
export function shapeOf(T, ord, links, twins = {}) {
  const set = new Set(ord);
  const hasCycle = ord.some(b => depsOf(T, b, twins, { split: false }).some(d => d.rel === 'cycle' && set.has(d.id)));
  if (hasCycle) return 'cycle';
  const ns = ord.map(id => maxN(T, id));
  if (ord.length >= 3 && ns.every(x => x != null) && (ns.every((x, i) => !i || x > ns[i - 1]) || ns.every((x, i) => !i || x < ns[i - 1]))) return 'ladder';
  return links.some(l => l.from) ? 'fork' : 'line';
}
/** the contradicts pairs among a set of rows (either side records it): a set of "a|b" keys, both orders */
function contradictions(T, ids, twins) {
  const set = new Set(ids), out = new Set();
  for (const id of ids) for (const d of depsOf(T, id, twins, { split: false })) if (d.rel === 'contradicts' && set.has(d.id)) { out.add(`${id}|${d.id}`); out.add(`${d.id}|${id}`); }
  return out;
}

// ------------------------------------------------------------------------------------------------------------------------------- E3–E9
/**
 * The mechanical draft of one section. Returns { route, section, rows (placements: positions and twins), list, twins, chains: [{ k, rows, links,
 * shape, weakest, twins, joins, attached, component }], side, singles, cycles: [[ids of a broken directed cycle]], kept: [contradicts pairs kept
 * apart] }. Options: groups (a Set), given (ids), max (MAX), split (E2b, default true).
 */
export function extractSection(T, route, section, { groups = null, given = null, max = MAX, split = true } = {}) {
  const { list, twins } = sectionRows(T, route, section, { groups, given });
  const V = new Set(list), pos = new Map(list.map((id, i) => [id, i]));
  const byPos = (a, b) => pos.get(a) - pos.get(b);
  const out = new Map(list.map(v => [v, new Set()])), inn = new Map(list.map(v => [v, new Set()])), und = new Map(list.map(v => [v, new Set()]));
  const contra = contradictions(T, list, twins);
  for (const id of list) for (const d of depsOf(T, id, twins, { split })) {
    if (!V.has(d.id)) continue;
    if (DIRECTED.has(d.rel)) { out.get(d.id).add(id); inn.get(id).add(d.id); }
    else if (UNDIRECTED.has(d.rel)) { und.get(id).add(d.id); und.get(d.id).add(id); }
  }
  // E3 components (contradicts is no edge), in the order of their first row
  const compOf = new Map(); const comps = [];
  for (const v of list) {
    if (compOf.has(v)) continue;
    const c = [v], st = [v]; compOf.set(v, comps.length);
    while (st.length) { const x = st.pop(); for (const y of [...out.get(x), ...inn.get(x), ...und.get(x)]) if (!compOf.has(y)) { compOf.set(y, comps.length); c.push(y); st.push(y); } }
    comps.push(c.sort(byPos));
  }
  // the directed edges, a directed cycle broken at its earliest row: the edges into that row from its strongly connected set leave
  const fwd = new Map(list.map(v => [v, new Set(out.get(v))])), back = new Map(list.map(v => [v, new Set(inn.get(v))]));
  const cycles = [];
  for (;;) {
    const scc = stronglyConnected(list, fwd).filter(s => s.length > 1);
    if (!scc.length) break;
    for (const s of scc) {
      const e = [...s].sort(byPos)[0];
      for (const x of s) if (fwd.get(x).has(e)) { fwd.get(x).delete(e); back.get(e).delete(x); }
      cycles.push([...s].sort(byPos));
    }
  }
  const topo = nodes => {   // Kahn's order of a node set on the acyclic edges, ties by shownOn order
    const ns = new Set(nodes), indeg = new Map(nodes.map(v => [v, [...back.get(v)].filter(x => ns.has(x)).length]));
    const ready = nodes.filter(v => indeg.get(v) === 0).sort(byPos), done = [];
    while (ready.length) { const v = ready.shift(); done.push(v); for (const w of fwd.get(v)) if (ns.has(w)) { indeg.set(w, indeg.get(w) - 1); if (indeg.get(w) === 0) { ready.push(w); ready.sort(byPos); } } }
    return done;
  };
  const chains = [], singles = [];
  for (const [ci, c] of comps.entries()) {
    if (c.length === 1) { singles.push(c[0]); continue; }
    const ns = new Set(c);
    const reach = (a, b) => { const st = [...fwd.get(a)].filter(x => ns.has(x) && x !== b), vis = new Set(st); while (st.length) { const x = st.pop(); if (x === b) return true; for (const y of fwd.get(x)) if (ns.has(y) && !vis.has(y)) { vis.add(y); st.push(y); } } return false; };
    const H = new Map(c.map(v => [v, [...fwd.get(v)].filter(w => ns.has(w) && !reach(v, w)).sort(byPos)]));
    const order = topo(c);
    // E4 the greedy path cover of H: the longest path, ties by the earliest start, then by the earlier rows
    const better = (p, q) => (p.length !== q.length ? p.length > q.length : lexLess(p.map(x => pos.get(x)), q.map(x => pos.get(x))));
    const left = new Set(order), paths = [];
    while (left.size) {
      const best = new Map();
      for (const v of [...order].reverse()) {
        if (!left.has(v)) continue;
        let b = [v];
        for (const w of H.get(v)) if (left.has(w)) { const cand = [v, ...best.get(w)]; if (better(cand, b)) b = cand; }
        best.set(v, b);
      }
      let top = null;
      for (const v of order) if (left.has(v) && (!top || better(best.get(v), top))) top = best.get(v);
      paths.push(top); for (const v of top) left.delete(v);
    }
    const pieces = [];
    for (const p of paths) { const k = Math.ceil(p.length / max), size = Math.ceil(p.length / k); for (let i = 0; i < p.length; i += size) pieces.push({ rows: p.slice(i, i + size), cut: k > 1 }); }
    const merged = [];
    for (const pc of pieces) {
      const p = pc.rows;
      if (!pc.cut && p.length <= 2 && merged.length) {
        const hangs = m => p.some(v => [...inn.get(v), ...und.get(v)].some(x => m.includes(x)));
        const apart = m => p.some(v => m.some(x => contra.has(`${v}|${x}`)));
        const host = merged.find(m => hangs(m) && !apart(m) && m.length + p.length <= max + 2);
        if (host) { host.push(...p); continue; }
      }
      merged.push([...p]);
    }
    for (const m of merged) {
      const ord = topo(m);
      const links = linksOf(T, ord, twins, { split });
      const tw = Object.fromEntries(ord.filter(id => twins[id]).map(id => [id, twins[id]]));
      const joins = [];
      for (const v of ord) for (const x of [...inn.get(v)].sort(byPos)) if (!m.includes(x) && ns.has(x)) joins.push({ from: x, to: v, rel: (relBetween(T, x, v, twins, { split }) || { rel: 'derives' }).rel });
      chains.push({ rows: ord, links, shape: shapeOf(T, ord, links, twins), weakest: weakest(T, ord.flatMap(id => (twins[id] ? [id, twins[id]] : [id]))), twins: tw, joins, attached: [], component: ci + 1 });
    }
  }
  chains.forEach((ch, i) => { ch.k = i + 1; });
  // E8 singletons: a shared dependency outside the section (no input, no hub), else a labelling neighbour, else a side note
  const sectionIds = [...list, ...Object.values(twins)];
  const fan = x => sectionIds.filter(id => ((T.byId.get(id) || {}).depends || []).some(d => d.id === x)).length;
  const isInput = (d) => d.rel === 'uses-input' || /^INP-/.test(d.id) || statusOf(T, d.id) === 'input';
  const side = [];
  for (const s of singles) {
    const apart = ch => [...ch.rows, ...ch.attached.map(a => a.id)].some(x => contra.has(`${s}|${x}`));
    const shared = new Set(depsOf(T, s, twins, { split }).filter(d => (DIRECTED.has(d.rel) || UNDIRECTED.has(d.rel)) && !V.has(d.id) && !isInput(d) && fan(d.id) <= 3).map(d => d.id));
    let host = null, how = null;
    for (const ch of chains) {
      if (apart(ch)) continue;
      for (const id of ch.rows) { const sh = depsOf(T, id, twins, { split }).find(d => (DIRECTED.has(d.rel) || UNDIRECTED.has(d.rel)) && !isInput(d) && shared.has(d.id)); if (sh) { host = ch; how = { via: sh.id, after: id }; break; } }
      if (host) break;
    }
    if (!host) {
      const nb = new Set(((T.status[s] || {}).neighbours) || []);
      for (const ch of chains) { if (apart(ch)) continue; const id = ch.rows.find(x => nb.has(x)); if (id) { host = ch; how = { neighbour: id, after: id }; break; } }
    }
    if (host) host.attached.push({ id: s, ...how, ...(twins[s] ? { twin: twins[s] } : {}) }); else side.push(s);
  }
  const kept = [...contra].filter(k => k.split('|')[0] < k.split('|')[1]);
  return { route, section, rows: list.length + Object.keys(twins).length, list, twins, chains, side, singles: singles.length, cycles, kept };
}
function lexLess(a, b) { for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] < b[i]; return a.length < b.length; }
/** Tarjan's strongly connected sets of a directed graph (node list, Map node → Set of successors), iteratively */
function stronglyConnected(nodes, succ) {
  let index = 0; const idx = new Map(), low = new Map(), on = new Set(), stack = [], out = [];
  for (const root of nodes) {
    if (idx.has(root)) continue;
    const work = [[root, [...succ.get(root)].values()]]; idx.set(root, index); low.set(root, index); index++; stack.push(root); on.add(root);
    while (work.length) {
      const [v, it] = work[work.length - 1]; const n = it.next();
      if (!n.done) {
        const w = n.value; if (!succ.has(w)) continue;
        if (!idx.has(w)) { idx.set(w, index); low.set(w, index); index++; stack.push(w); on.add(w); work.push([w, [...succ.get(w)].values()]); }
        else if (on.has(w)) low.set(v, Math.min(low.get(v), idx.get(w)));
        continue;
      }
      work.pop();
      if (work.length) { const u = work[work.length - 1][0]; low.set(u, Math.min(low.get(u), low.get(v))); }
      if (low.get(v) === idx.get(v)) { const c = []; let w; do { w = stack.pop(); on.delete(w); c.push(w); } while (w !== v); out.push(c); }
    }
  }
  return out;
}

// ------------------------------------------------------------------------------------------------------------------------------- records
/** the told rows of a chain record: its positions that are not mentions */
export const toldOf = c => (c.rows || []).filter(id => !(c.mention || []).includes(id));
/** a page's chain records in reading order: the sections in the page's order (pages.json after the merge), then each section's order */
export function pageOrder(T, chains) {
  const secIndex = route => { const p = pageOf(T, route); return new Map(((p && p.sections) || []).map((s, i) => [s.id, i])); };
  const idx = new Map();
  const at = c => { if (!idx.has(c.page)) idx.set(c.page, secIndex(c.page)); const m = idx.get(c.page); return m.has(c.section) ? m.get(c.section) : 1e6; };
  return [...chains].sort((a, b) => cmpStr(a.page, b.page) || at(a) - at(b) || cmpStr(a.section, b.section) || (a.order ?? 0) - (b.order ?? 0) || cmpStr(a.id, b.id));
}
/**
 * E9 for records (STORY_ROUND.md §2.1 joins): for each chain, the depends edges (derives, instance, uses-input, equiv, cycle) from a row told in an
 * earlier chain of the same page (another section included) to one of its told positions; an undirected edge counts from either side. Returns
 * Map chain id → [{ from, to, rel }], in the order of the positions, then of the earlier rows.
 */
export function joinsOf(T, chains) {
  const out = new Map();
  const byPage = new Map(); for (const c of pageOrder(T, chains)) { if (!byPage.has(c.page)) byPage.set(c.page, []); byPage.get(c.page).push(c); }
  const JOIN = new Set([...DIRECTED, 'equiv', 'cycle']);
  for (const list of byPage.values()) {
    const told = [];                       // [row, the chain that tells it], in reading order
    for (const c of list) {
      const twins = c.twins || {}, mine = new Set([...(c.rows || []), ...Object.values(twins)]);
      const before = new Map(told.map(([id, k], i) => [id, i]));
      const js = [], seen = new Set();
      for (const p of toldOf(c)) {                // a mention's edges are joined where it is told
        const found = [];
        for (const d of depsOf(T, p, twins, { split: false })) if (JOIN.has(d.rel) && before.has(d.id) && !mine.has(d.id)) found.push({ from: d.id, to: p, rel: d.rel });
        for (const [x] of told) if (!mine.has(x)) for (const d of ((T.byId.get(x) || {}).depends || [])) if ((d.rel === 'equiv' || d.rel === 'cycle') && (d.id === p || d.id === twins[p])) found.push({ from: x, to: p, rel: d.rel });
        found.sort((a, b) => before.get(a.from) - before.get(b.from));
        for (const j of found) { const k = `${j.from}|${j.to}`; if (!seen.has(k)) { seen.add(k); js.push(j); } }
      }
      out.set(c.id, js);
      for (const id of toldOf(c)) { told.push([id, c.id]); if (twins[id]) told.push([twins[id], c.id]); }
    }
  }
  return out;
}
/** a chain record computed from its positions (the composer's choice: the ordered rows, the mentions, the twins), every derived field from the tables */
export function chainRecord(T, { id, page, section, order, title, lead = null, rows, mention = [], twins = {}, joins = [], contrasts = {}, extracted, story = 'none' }) {
  const links = linksOf(T, rows, twins).map((l, i) => (l.rel === 'order' && contrasts[rows[i + 1]] ? { rel: 'contrasts', note: contrasts[rows[i + 1]] } : l));
  return { id, page, section, order, title, lead, rows, mention, twins, joins, links, shape: shapeOf(T, rows, links, twins), extracted, story };
}
/** the draft records of one section's extraction (--into): attached rows follow the last position of their chain; titles left to the composer */
export function draftRecords(T, res, { startOrder = 1 } = {}) {
  return res.chains.map((ch, i) => {
    const rows = [...ch.rows, ...ch.attached.map(a => a.id)];
    const twins = { ...ch.twins }; for (const a of ch.attached) if (a.twin) twins[a.id] = a.twin;
    return chainRecord(T, { id: `${pageKey(res.route)}.${res.section}.${rows[0].toLowerCase()}`, page: res.route, section: res.section, order: startOrder + i,
      title: { phys: '', math: '', learner: '' }, rows, twins, extracted: { tool: 'extract_chains', component: ch.k, departures: [] } });
  });
}
const RECORD_KEYS = ['id', 'page', 'section', 'order', 'title', 'lead', 'rows', 'mention', 'twins', 'joins', 'links', 'shape', 'extracted', 'story'];
/** the owners' file format: one key per line, each value on its line (diffs read per field) */
export function formatChains(list) {
  if (!list.length) return '[]\n';
  const rec = c => ' {\n' + [...RECORD_KEYS.filter(k => k in c), ...Object.keys(c).filter(k => !RECORD_KEYS.includes(k))].map(k => `  ${JSON.stringify(k)}: ${JSON.stringify(c[k])}`).join(',\n') + '\n }';
  return '[\n' + list.map(rec).join(',\n') + '\n]\n';
}

// ------------------------------------------------------------------------------------------------------------------------------- --diff
/** the groups a file's chains tell in a section: every group of the section when they cover them all, else those groups only */
export function groupsTold(T, chains, route, section) {
  const told = new Set(chains.filter(c => c.page === route && c.section === section).flatMap(c => [...(c.rows || []), ...Object.values(c.twins || {})]).map(groupOf));
  const all = new Set(sectionRows(T, route, section).list.map(groupOf));
  return [...all].every(g => told.has(g)) ? null : told;
}
/** the departures of each composed chain from the mechanical draft of its section: Map chain id → { component (the number k of the draft chain Ck
 *  it shares most told rows with, or null), departures: [strings] } */
export function diffChains(T, chains, { groups = null } = {}) {
  const out = new Map(), drafts = new Map();
  for (const c of chains) {
    const key = `${c.page}|${c.section}`;
    if (!drafts.has(key)) drafts.set(key, extractSection(T, c.page, c.section, { groups: groups || groupsTold(T, chains, c.page, c.section) }));
    const res = drafts.get(key);
    const draftRows = res.chains.map(ch => [...ch.rows, ...ch.attached.map(a => a.id)]);
    const told = toldOf(c);
    let best = -1, bestN = 0;
    draftRows.forEach((d, i) => { const n = told.filter(id => d.includes(id)).length; if (n > bestN) { best = i; bestN = n; } });
    const base = best >= 0 ? draftRows[best] : [];
    const where = id => { const i = draftRows.findIndex(d => d.includes(id)); return i >= 0 ? `C${i + 1}` : res.side.includes(id) ? 'the side notes' : null; };
    const tellers = id => chains.filter(x => x !== c && x.page === c.page && toldOf(x).includes(id)).map(x => x.id);
    const dep = [];
    for (const id of told) if (!base.includes(id)) { const w = where(id); dep.push(w ? `${id} added from ${w}` : `${id} added (not in the draft of the section)`); }
    for (const id of base) if (!(c.rows || []).includes(id)) { const t = tellers(id); dep.push(t.length ? `${id} left (told in ${t.join(', ')})` : `${id} left (a side note)`); }
    const common = (c.rows || []).filter(id => base.includes(id) && told.includes(id)), inBase = base.filter(id => common.includes(id));
    const keep = lcs(common, inBase);
    for (const id of common) if (!keep.includes(id)) dep.push(`${id} moved`);
    for (const id of c.mention || []) { const t = tellers(id); dep.push(`mention ${id}${t.length ? ` (told in ${t.join(', ')})` : ''}`); }
    (c.links || []).forEach((l, i) => { if (l.rel === 'contrasts') dep.push(`link before ${c.rows[i + 1]}: contrasts (order in the draft)`); });
    if (c.title && c.title.phys) dep.push(`title "${c.title.phys}"`);
    out.set(c.id, { component: best >= 0 ? best + 1 : null, departures: dep });
  }
  return out;
}
function lcs(a, b) {
  const m = a.length, n = b.length, L = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) for (let j = n - 1; j >= 0; j--) L[i][j] = a[i] === b[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const out = []; let i = 0, j = 0;
  while (i < m && j < n) { if (a[i] === b[j]) { out.push(a[i]); i++; j++; } else if (L[i + 1][j] >= L[i][j + 1]) i++; else j++; }
  return out;
}

// ------------------------------------------------------------------------------------------------------------------------------- the story pages and --counts
/** the sections of a page the extraction reads: those that hold a placement (any row, any role), the page's own order first; intro, top-notes and
 *  the inputs sections left out */
export function storySections(T, route) {
  const p = pageOf(T, route); if (!p) return [];
  const used = new Set(); for (const r of T.rows) for (const so of r.shownOn || []) if (so.page === route) used.add(so.section);
  const declared = (p.sections || []).map(s => (s.query && s.query['shownOn.section']) || s.id);
  return [...new Set([...declared, ...[...used].sort(cmpStr)])].filter(s => used.has(s) && !RESERVED.has(s) && !isInputsSection(T, route, s));
}
/** the story pages: every page of pages.json but the Logbook, Ask and the glossary, with the sections it holds rows in */
export const storyPages = T => T.pages.filter(p => !SKIP_PAGES.has(p.route)).map(p => ({ route: p.route, stepNo: p.stepNo ?? null, sections: storySections(T, p.route) })).filter(p => p.sections.length);
const matrixLines = (T, route, section) => new Set(T.rows.filter(r => MATRIX_LINE.test(r.id) && (r.shownOn || []).some(so => so.page === route && so.section === section)).map(r => r.id)).size;
/** SPINE.md §6.1: per story page, the extraction with E2b and the chains and singletons without it */
export function countsTable(T, { max = MAX } = {}) {
  const lines = [], total = { pages: 0, sections: 0, rows: 0, chains: 0, inChains: 0, attached: 0, side: 0, singles: 0, thin: 0, matrix: 0, chainsNoSplit: 0, singlesNoSplit: 0, twinsBeside: 0, shapes: {} };
  for (const p of storyPages(T)) {
    const b = { route: p.route, stepNo: p.stepNo, sections: p.sections.length, rows: 0, chains: 0, inChains: 0, attached: 0, side: 0, singles: 0, thin: 0, matrix: 0, chainsNoSplit: 0, singlesNoSplit: 0, twinsBeside: 0 };
    for (const s of p.sections) {
      const r = extractSection(T, p.route, s, { max }), r0 = extractSection(T, p.route, s, { max, split: false });
      b.rows += r.rows; b.chains += r.chains.length; b.side += r.side.length; b.singles += r.singles; b.matrix += matrixLines(T, p.route, s);
      for (const c of r.chains) { b.inChains += c.rows.length + Object.keys(c.twins).length; b.attached += c.attached.length; total.shapes[c.shape] = (total.shapes[c.shape] || 0) + 1; }
      b.twinsBeside += r.side.filter(id => r.twins[id]).length + r.chains.reduce((n, c) => n + c.attached.filter(a => a.twin).length, 0);
      if (r.rows >= 3 && !r.chains.length) b.thin++;
      b.chainsNoSplit += r0.chains.length; b.singlesNoSplit += r0.singles;
    }
    lines.push(b); total.pages++;
    for (const k of ['sections', 'rows', 'chains', 'inChains', 'attached', 'side', 'singles', 'thin', 'matrix', 'chainsNoSplit', 'singlesNoSplit', 'twinsBeside']) total[k] += b[k];
  }
  return { lines, total };
}
export function printCounts({ lines, total }) {
  const fmt = n => n.toLocaleString('en-US');
  const out = ['| page | step | sections | rows | chains | rows in chains (+ attached) | side notes | singletons | sections of ≥ 3 rows without a chain | matrix lines apart | chains without E2b | singletons without E2b |',
    '|---|---:|---:|---:|---:|---|---:|---:|---:|---:|---:|---:|'];
  for (const b of lines) out.push(`| \`${b.route}\` | ${b.stepNo ?? '—'} | ${b.sections} | ${b.rows} | ${b.chains} | ${b.inChains}${b.attached ? ` (+ ${b.attached})` : ''} | ${b.side} | ${b.singles} | ${b.thin} | ${b.matrix} | ${b.chainsNoSplit} | ${b.singlesNoSplit} |`);
  out.push(`| **${total.pages} pages** | | **${total.sections}** | **${fmt(total.rows)}** | **${total.chains}** | **${total.inChains} (+ ${total.attached})** | **${total.side}** | **${total.singles}** | **${total.thin}** | **${total.matrix}** | **${total.chainsNoSplit}** | **${total.singlesNoSplit}** |`);
  out.push('', `${fmt(total.rows)} = ${total.inChains} rows in chains (the twins with their positions) + ${total.attached} attached + ${total.side} side notes + ${total.twinsBeside} mathematics twins beside their side notes or attached rows; shapes: ${Object.entries(total.shapes).sort((a, b) => cmpStr(a[0], b[0])).map(([k, v]) => `${k} ${v}`).join(', ')}`);
  return out.join('\n');
}

/** the waves of STORY_ROUND.md §8 (SPINE.md §6.2): the release that converts each page; the pilot sections of wave 1 and their groups */
export const WAVES = { rule: 2, cells: 2, clock: 2, light: 2, 'steps/comm': 2, 'steps/mirrors': 2, 'steps/dirac': 2, 'steps/spin': 3, 'steps/coupling': 3, 'steps/ym': 3, 'steps/matter': 3,
  'matter/dictionary': 3, 'matter/papers': 3, 'matter/model': 3, 'matter/generations': 3, 'matter/help': 3, 'steps/grav1': 4, 'steps/grav2': 4, 'steps/projective': 4, 'steps/gauge': 4,
  'steps/nullsurf': 4, 'steps/forque': 5, 'steps/spring': 5, 'steps/rigid': 5, 'steps/groups': 5, shapes: 5, 'steps/category': 6, 'steps/baez': 6, 'steps/schuller': 6, matter: 1, shifted: 1 };
export const PILOT = { 'rule|ideas': ['GEN'], 'cells|cards': ['GEN'], 'steps/coupling|eq-coupling': ['ATY', 'FUR'], 'steps/baez|bz-generation': ['ATY', 'FUR', 'CAND'] };
/** SPINE.md §6.2: per wave the mechanical sizes (the pilot rows cut out of their four sections, each remainder extracted on its own), with and without E2b */
export function wavesTable(T, { max = MAX } = {}) {
  const W = {};
  const add = (w, r, r0, matrix) => {
    const b = (W[w] ||= { wave: w, sections: 0, rows: 0, chains: 0, inChains: 0, attached: 0, side: 0, thin: 0, matrix: 0, chainsNoSplit: 0, inChainsNoSplit: 0, attachedNoSplit: 0, sideNoSplit: 0, thinNoSplit: 0 });
    b.sections++; b.matrix += matrix;
    if (!r) return;
    b.rows += r.rows; b.chains += r.chains.length; b.side += r.side.length; if (r.rows >= 3 && !r.chains.length) b.thin++;
    for (const c of r.chains) { b.inChains += c.rows.length + Object.keys(c.twins).length; b.attached += c.attached.length; }
    b.chainsNoSplit += r0.chains.length; b.sideNoSplit += r0.side.length; if (r0.rows >= 3 && !r0.chains.length) b.thinNoSplit++;
    for (const c of r0.chains) { b.inChainsNoSplit += c.rows.length + Object.keys(c.twins).length; b.attachedNoSplit += c.attached.length; }
  };
  for (const p of storyPages(T)) {
    const w = WAVES[p.route]; if (!w) continue;
    for (const s of p.sections) {
      const matrix = matrixLines(T, p.route, s), all = sectionRows(T, p.route, s);
      const ids = [...all.list, ...Object.values(all.twins)], groups = PILOT[`${p.route}|${s}`];
      const run = given => (given.length ? [extractSection(T, p.route, s, { given, max }), extractSection(T, p.route, s, { given, max, split: false })] : [null, null]);
      if (!groups) { const [r, r0] = run(ids); add(w, r, r0, matrix); continue; }
      const pil = ids.filter(id => groups.includes(groupOf(id))), rest = ids.filter(id => !groups.includes(groupOf(id)));
      const [a, a0] = run(pil); add(1, a, a0, 0);
      const [b, b0] = run(rest); add(w, b, b0, matrix);
    }
  }
  return Object.values(W).sort((a, b) => a.wave - b.wave);
}
export function printWaves(list) {
  const out = ['| wave | sections | rows | chains | rows in chains (+ attached) | side notes | sections of ≥ 3 rows without a chain | matrix lines apart |', '|---|---:|---:|---|---|---|---|---:|'];
  const sum = list.filter(b => b.wave >= 2).reduce((t, b) => { for (const k of Object.keys(b)) if (k !== 'wave') t[k] = (t[k] || 0) + b[k]; return t; }, {});
  for (const b of [...list, { ...sum, wave: '2–6' }]) out.push(`| ${b.wave === 1 ? '1 (mechanical; the composition is SPINE.md §2–§4)' : b.wave} | ${b.sections} | ${b.rows} | ${b.chains} [${b.chainsNoSplit}] | ${b.inChains} (+ ${b.attached}) [${b.inChainsNoSplit} (+ ${b.attachedNoSplit})] | ${b.side} [${b.sideNoSplit}] | ${b.thin} [${b.thinNoSplit}] | ${b.matrix} |`);
  out.push('', 'brackets: without E2b');
  return out.join('\n');
}

// ------------------------------------------------------------------------------------------------------------------------------- printing
const fmtLink = l => (l.rel === 'order' ? 'order' : `${l.rel}${l.dir === 'back' ? '←' : ''}${l.from ? `·${l.from}` : ''}`);
export const fmtSeq = (rows, links, twins = {}, mention = []) => rows.map((id, j) => (j ? ` —${fmtLink(links[j - 1])}→ ` : '') + (mention.includes(id) ? `(${id})` : id) + (twins[id] ? `/${twins[id]}` : '')).join('');
export function printSection(res) {
  const lines = [`**${res.route} · ${res.section}** — ${res.rows} rows: ${res.chains.length} chain(s), ${res.side.length} side note(s) (${res.singles} singleton(s) before attachment)`, ''];
  for (const ch of res.chains) {
    const hang = [...new Set(ch.joins.map(j => j.from))];
    lines.push(`- C${ch.k} · ${ch.shape} · weakest ${ch.weakest}: ${fmtSeq(ch.rows, ch.links, ch.twins)}${ch.attached.length ? `; attached ${ch.attached.map(a => `${a.id}${a.twin ? '/' + a.twin : ''} (${a.via ? 'shares ' + a.via : 'neighbour of ' + a.neighbour})`).join(', ')}` : ''}${hang.length ? `; hangs from ${hang.join(', ')}` : ''}`);
  }
  if (res.side.length) lines.push(`- side notes: ${res.side.map(id => id + (res.twins[id] ? '/' + res.twins[id] : '')).join(', ')}`);
  for (const c of res.cycles) lines.push(`- a directed cycle broken at ${c[0]}: ${c.join(', ')}`);
  for (const k of res.kept) lines.push(`- kept apart (contradicts): ${k.replace('|', ' and ')}`);
  return lines.join('\n');
}

// ------------------------------------------------------------------------------------------------------------------------------- CLI
function main(argv) {
  const arg = k => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  const T = loadTables();
  const max = Number(arg('--max') || MAX);
  const groups = arg('--groups') ? new Set(arg('--groups').split(',').map(s => s.trim()).filter(Boolean)) : null;
  if (argv.includes('--counts')) { const t = countsTable(T, { max }), w = wavesTable(T, { max }); console.log(argv.includes('--json') ? JSON.stringify({ pages: t, waves: w }) : `${printCounts(t)}\n\n${printWaves(w)}`); return 0; }
  if (arg('--diff')) {
    const f = path.resolve(arg('--diff')), chains = readJSON(f, null);
    if (!Array.isArray(chains)) { console.log(`extract_chains: ${arg('--diff')} is not a list of chains`); return 1; }
    const d = diffChains(T, chains, { groups });
    if (argv.includes('--json')) { console.log(JSON.stringify(Object.fromEntries(d), null, 1)); return 0; }
    for (const c of chains) {
      const rec = c.extracted || {}, now = d.get(c.id), same = rec.component === now.component && JSON.stringify(rec.departures || []) === JSON.stringify(now.departures);
      console.log(`${c.id}: ${fmtSeq(c.rows, c.links || [], c.twins || {}, c.mention || [])}\n  from ${now.component ? 'C' + now.component : 'no chain of the draft'}; departures: ${now.departures.join('; ') || '(none)'}${same ? '' : `\n  recorded:   from ${rec.component ? 'C' + rec.component : 'no chain'}; ${(rec.departures || []).join('; ') || '(none)'}`}`);
    }
    return 0;
  }
  const route = arg('--page');
  if (route == null) { console.log('extract_chains: --page <route>, --diff <file> or --counts (see the header)'); return 1; }
  if (!pageOf(T, route)) { console.log(`extract_chains: ${route} is not a route of content/pages.json`); return 1; }
  const secs = arg('--section') ? [arg('--section')] : storySections(T, route);
  const res = secs.map(s => extractSection(T, route, s, { groups, max }));
  if (arg('--into')) {
    const f = path.resolve(arg('--into')), have = readJSON(f, []);
    if (!Array.isArray(have)) { console.log(`extract_chains: ${arg('--into')} is not a list of chains`); return 1; }
    const added = [];
    for (const r of res) { if (have.some(c => c.page === route && c.section === r.section) || !r.chains.length) continue; added.push(...draftRecords(T, r)); }
    const all = [...have, ...added], js = joinsOf(T, all);
    for (const c of added) c.joins = js.get(c.id) || [];
    fs.mkdirSync(path.dirname(f), { recursive: true });
    fs.writeFileSync(f, formatChains(all));
    console.log(`extract_chains: ${added.length} draft chain(s) added to ${path.relative(ROOT, f)} (${res.length} section(s) read; a section with chains in the file keeps them)`);
    return 0;
  }
  if (argv.includes('--json')) { console.log(JSON.stringify(res, null, 1)); return 0; }
  console.log(res.map(printSection).join('\n\n'));
  return 0;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(main(process.argv.slice(2)));
