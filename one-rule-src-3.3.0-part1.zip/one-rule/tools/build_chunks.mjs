#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/build_chunks.mjs — the static files next to the bundle (called by build.sh):
//   content/*.json → dist/content/<name>.json, content/derived/*.json → dist/content/derived_<name>.json (the same data, minified),
//   each also as dist/content/<name>.js (sets window.__ONE_RULE_CONTENT__[name]) so the site works from file://, where fetch cannot;
//   dist/content/version.json — { contentVersion, appVersion }: CONTENT_VERSION, else the date of the newest content file; and the
//   version of package.json, read at every build (BUILD_CONTRACTS interface 10; the footer shows both);
//   dist/content/persona_rules.json — content/persona_rules.md parsed by src/app/personaRules.js (the guide's rules; the Ask page reads it);
//   KaTeX's script, stylesheet and fonts → dist/katex/; public/ (reports, analyses) → dist/; the check scripts → dist/checks/;
//   the record of every page (round 7, interface 38: tools/page_records.mjs) → dist/content/records/<route>.json and dist/content/records.json (+ .js).
// Usage: node tools/build_chunks.mjs [outDir=dist]
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';
import { parsePersonaRules } from '../src/app/personaRules.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUT = path.resolve(ROOT, process.argv[2] || 'dist');
const NM = process.env.NODE_MODULES || '/opt/npm-tools/node_modules';
const GLOBAL = '__ONE_RULE_CONTENT__';

// ---- 1. the content tables
const C = path.join(ROOT, 'content');
const DOUT = path.join(OUT, 'content');
fs.mkdirSync(DOUT, { recursive: true });
const tables = [];
for (const f of fs.readdirSync(C).filter(f => f.endsWith('.json')).sort()) tables.push([f.slice(0, -5), path.join(C, f)]);
const DER = path.join(C, 'derived');
if (fs.existsSync(DER)) for (const f of fs.readdirSync(DER).filter(f => f.endsWith('.json')).sort()) tables.push(['derived_' + f.slice(0, -5), path.join(DER, f)]);
let newest = 0;
const writeTable = (name, data) => {
  const json = JSON.stringify(data);
  fs.writeFileSync(path.join(DOUT, `${name}.json`), json);
  fs.writeFileSync(path.join(DOUT, `${name}.js`), `(window.${GLOBAL}=window.${GLOBAL}||{})[${JSON.stringify(name)}]=${json};\n`);
};
for (const [name, file] of tables) {
  let data;
  try { data = JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { console.error(`build_chunks: ${path.relative(ROOT, file)} is not valid JSON: ${e.message}`); process.exit(1); }
  newest = Math.max(newest, fs.statSync(file).mtimeMs);
  writeTable(name, data);
}
// the guide's rules: a markdown file of content/, served as a parsed table (the same parser runs in the coverage test)
const PERSONA = path.join(C, 'persona_rules.md');
if (fs.existsSync(PERSONA)) {
  const md = fs.readFileSync(PERSONA, 'utf8');
  const rules = parsePersonaRules(md);
  if (!rules.statusWords.length) { console.error('build_chunks: content/persona_rules.md has no status words'); process.exit(1); }
  newest = Math.max(newest, fs.statSync(PERSONA).mtimeMs);
  writeTable('persona_rules', rules);
  tables.push(['persona_rules', PERSONA]);
}
const contentVersion = process.env.CONTENT_VERSION || new Date(newest || Date.now()).toISOString().slice(0, 10);
let appVersion = null;
try { appVersion = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version || null; }
catch (e) { console.error(`build_chunks: package.json could not be read (${e.message})`); process.exit(1); }
if (!appVersion) { console.error('build_chunks: package.json has no version'); process.exit(1); }
writeTable('version', { contentVersion, appVersion, tables: tables.map(t => t[0]) });

// ---- 2. KaTeX (loaded by the app only when a research text on screen holds a formula)
const KX = path.join(NM, 'katex', 'dist');
if (fs.existsSync(KX)) {
  const KOUT = path.join(OUT, 'katex');
  fs.mkdirSync(KOUT, { recursive: true });
  for (const f of ['katex.min.css', 'katex.min.js']) fs.copyFileSync(path.join(KX, f), path.join(KOUT, f));
  fs.cpSync(path.join(KX, 'fonts'), path.join(KOUT, 'fonts'), { recursive: true });
} else console.warn(`build_chunks: KaTeX not found under ${NM}; formulas will show as typed`);

// ---- 3. the reports and analyses (served next to the app)
const PUB = path.join(ROOT, 'public');
if (fs.existsSync(PUB)) fs.cpSync(PUB, OUT, { recursive: true });

// ---- 4. the check scripts, for download from the drawers (the scripts only; logs and stored results stay in the repository)
const CHK = path.join(ROOT, 'checks');
if (fs.existsSync(CHK)) {
  fs.cpSync(CHK, path.join(OUT, 'checks'), {
    recursive: true,
    filter: src => { const st = fs.statSync(src); if (st.isDirectory()) return !/__pycache__$/.test(src); return /\.(py|sh)$/.test(src); },
  });
}

// ---- 5. the record of every page (round 7, interface 38): dist/content/records/<route>.json and their index, by tools/page_records.mjs
const { writeRecords } = await import('./page_records.mjs');
const rec = await writeRecords(OUT);
console.log(`build_chunks: ${rec.files} page records (${rec.rows} placed rows, ${rec.scripts} scripts) in ${path.relative(ROOT, path.join(OUT, 'content', 'records'))}/`);

// ---- 6. sizes
const walk = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
const files = walk(OUT);
const size = f => fs.statSync(f).size;
const sum = list => list.reduce((k, f) => k + size(f), 0);
const mb = n => (n / 1048576).toFixed(2) + ' MB';
const kb = n => (n / 1024).toFixed(1) + ' kB';
const app = path.join(OUT, 'app.js');
const appGz = fs.existsSync(app) ? zlib.gzipSync(fs.readFileSync(app)).length : 0;
const group = pre => sum(files.filter(f => path.relative(OUT, f).startsWith(pre)));
console.log(`build_chunks: ${tables.length} tables + version (app ${appVersion}, content ${contentVersion}) in ${path.relative(ROOT, DOUT)}/`);
console.log(`dist: ${files.length} files, ${mb(sum(files))} — app.js ${kb(fs.existsSync(app) ? size(app) : 0)} (${kb(appGz)} gzipped), app.css ${kb(fs.existsSync(path.join(OUT, 'app.css')) ? size(path.join(OUT, 'app.css')) : 0)}, content ${mb(group('content'))}, katex ${mb(group('katex'))}, reports ${mb(group('reports'))}, checks ${mb(group('checks'))}`);
