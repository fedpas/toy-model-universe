#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/merge_story.mjs — merges the story overlay content/story/ (docs/STORY_PLAN.md §3.2–3.3; BUILD_CONTRACTS "Round 6", owner S1) into
// content/rows.json, texts.json and pages.json:
//
//   rows.json       the story rows (kind story, plan §1.2)                          → rows.json, by id (sorted by id, as the other merges sort)
//   texts.json      their texts, and the v15 learner words of existing rows         → texts.json, by (row, lang, level, mode, lens, register); a text of
//                   (the page strips' tags and the card strips, A56; the chapter      status human of an existing row is never replaced; a paired v15
//                   learner lines, A51)                                               learner text replaces a draft or reviewed text of the same key
//   layout.json     [{ row, page, section, order, role, add? }] for existing rows    → the row's shownOn entry on that page (the same page; order < 1000;
//                                                                                     add: a new entry, order ≥ 1000, for a sub-page)
//   sections.json   per page (generated): { route, page?, intro, parts, sections }  → pages.json
//   chapters.json   the three chapters (S2), then furey.json (S3): over sections.json (plan §3.2 precedence: later files win)
//   landing.json    { routes } (S4): the route renames, on pages, on every shownOn entry, on needs and parent (its titles, home and chapters
//                   are applied at run time by src/app/router.js)
//   pending.json    held blocks and proposed statements: never merged (D45), except as content/story/review.json decides: story (a story row,
//                   checked as any), reading (a row of kind reading), statement:<check id> (a statement row with that evidence: mode ran), the
//                   last two only with the labels the author adds to the entry (notions, kind, stage); same-as:<row id> (a finding title
//                   becomes that row's short research text, A58); drop
//   content/chains/ the chains overlay of round 14 (tools/merge_chains.mjs, docs/round14/STORY_ROUND.md §3.3, D59: merged here, in the same book):
//                   its round-14 rows after the story rows (step 1), their research texts and the storyteller's spans and learner texts after the
//                   texts (step 2; a span keys with its chain), its placements after the layout (step 3), its page entries as the last precedence
//                   (step 4; an added page takes `after`, `needs`, `learnerFrame` and `connective`), then, after the homes (step 5), the chains validated (V1–V10)
//                   and each section's `chains` written; the merged chains are content/chains.json
//
//   depends_<pass>.json  the labelling overlays of `depends` (round 15: depends_a62.json, docs/round15/PLAN.md §2, the verdicts docs/round15/JUDGE_A62.md):
//                   step 0, before everything else, applies each entry the judge accepted to the depends of its row (add, drop, set-cycle, turn), so a
//                   re-migration that rebuilds rows.json keeps the pass; the rows carry no provenance per edge, so the book records it (book.depends)
//
// A page entry (the reference is S2's tests/story/fixture/overlay.mjs, the same semantics):
//   page        a page to add when the route is not in pages.json (a sub-page: { title, tab, parent, tabV15? }; a top-level page of round 14: { title,
//               after, needs, learnerFrame, connective }); on a page that exists, a later file's title, tab, parent and learnerFrame replace its own
//   connective  { <section or top-notes>: line | { research, learner } }: merged line by line over the page's try lines
//   hero        merged over pages.json's hero · parts: replace the page's parts (the part ids open and drawer are reserved)
//   intro       { lead | leadFrom, next, captionRowsOf, storyDetails, absorbs }: the page's lead (role lead, order 0, in the reserved section
//               intro); captionRowsOf moves the rows a section held in the tables before the story round into the intro as captions; storyDetails
//               (v15 locators, through content/story/ids.json) place story rows there as details; absorbs: sections whose rows moved here
//   sections    in display order: { id, title, part, figure, key, pairs, group, lead | leadFrom, captionRowsOf, detailRowsOf, storyDetails, absorbs,
//               tryLearner }: the fields replace the page section's (title false: no heading; null leaves it); a section the page lacks is added;
//               captionRowsOf / detailRowsOf move the rows the named sections held (order 500 + their order; a row the layout places with role
//               learner, a chapter learner line of A51, keeps that role) and those sections leave the page,
//               as the sections in absorbs do; tryLearner becomes the section's learner connective; the listed sections come first, in their
//               order, then the page's other sections in theirs. A section of a composed page that no entry names and no row uses leaves the page.
//   A lead named by a later file demotes the lead an earlier file put in that section to a detail (precedence); two leads from one file are an error.
//
// Idempotent and deterministic: what the merge replaced is kept in content/story/merged.json (the original of each entry, text and page it
// changed, and of each row's depends the labelling overlays changed, with a digest of what it wrote); the next run first restores every item that
// still holds what it wrote (an item another merge rewrote since is left as it is), removes its rows, then merges again, so a second run writes the
// same bytes. Texts of rows that no longer exist are dropped.
// Refused (nothing written, exit 1): a story row of the v15 overlay that fails plan §1.6 (kind story, notions ["i-meta"], no evidence, since v2.2,
// an id 501–999 of its group, its research text the record of its locator, T4/T5 of the test against the rows of its section, no 40 characters of
// another row's research text; a round-14 story row has D60's rules instead, V9 of tools/merge_chains.mjs); a second lead in a section; a caption in
// a section without a figure; a section figure neither in figures.json nor in pending_figures.json; a layout entry for a page the row is not on, or
// at an order of 1000 or more without add; a moved home; an unlabelled reading or statement choice; a chain that fails V1–V10; an accepted entry of a
// labelling overlay on a row or target that is not a row, or with a relation, op or verdict outside its record. A banned history word in a story
// text is reported (the author's text), never edited.
// Run after tools/merge_explore.mjs and tools/merge_physics.mjs, before tools/build_content.mjs (npm run content; tools/migrate/run_all.sh).
// Usage: node tools/merge_story.mjs            merge and write (content/rows.json, texts.json, pages.json, chains.json, story/merged.json)
//        node tools/merge_story.mjs --check    check the overlay against the tables and print what a merge would do; write nothing
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { testBlock, testRow, windows40 } from './migrate/story_from_v15.mjs';
import { readChainOverlay, chainOverlayOf, mergeChains, textRecord, isSpan } from './merge_chains.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content'), S = path.join(C, 'story');
const readJSON = (f, fallback) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fallback);
const W = (f, d) => fs.writeFileSync(f, JSON.stringify(d, null, 1));       // the format the other merges write
const clone = x => (x === undefined ? undefined : JSON.parse(JSON.stringify(x)));
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
/** the bookkeeping keeps what the merge wrote as a digest (the originals in full): an item still holds what the merge wrote when its digest matches */
const digest = x => crypto.createHash('sha1').update(JSON.stringify(x)).digest('hex').slice(0, 20);
const holds = (cur, wrote) => (typeof wrote === 'string' ? digest(cur) === wrote : same(cur, wrote));
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
/** the key of a text record (02 §2): (row, lang, level, mode, lens, register), and the chain of a span (§2.2 of round 14: a record without one keys as before) */
export const textKey = t => [t.row, t.lang || 'en', t.level, t.mode || 'both', t.lens || '', t.register || 'full'].join('|') + (t.chain != null ? `|${t.chain}` : '');
const byText = (a, b) => a.row.localeCompare(b.row, 'en') || a.level.localeCompare(b.level) || String(a.lens || '').localeCompare(String(b.lens || '')); // merge_learner_texts' order
const DRAWER = ['evidence', 'needs', 'depends', 'readings', 'numbers', 'address'];
export const ROLES = new Set(['lead', 'caption', 'result', 'detail', 'learner', 'next', 'evidence', 'note', 'chain']); // note: a page top's notes (round 7, interface 37); chain: a story row that leads a chain (round 14, §2.3)
const INTRO = 'intro';
const BOOK = path.join(S, 'merged.json');
const STORY_FIELDS = ['id', 'group', 'kind', 'stage', 'ptype', 'notions', 'fields', 'phenomena', 'cells', 'homePhys', 'homeMath', 'standardRef', 'evidence', 'depends', 'links',
  'lensTags', 'legacyFlags', 'legacyLines', 'legacyLabel', 'legacyKnown', 'since', 'tabV15', 'anchorV15', 'source', 'shownOn', 'visibleTo', 'review', 'notesPersona', 'theorems',
  'readingRefs', 'v16', 'splitFrom', 'labelFrom'];
const HISTORY = /\b(corrected|withdrawn|superseded|formerly|previously|re-?worded|now proved|historically|used to|no longer)\b/i; // BUILD_CONTRACTS' banned words
/** the relations of depends (docs/LABELLING_SCHEME.md §4; tools/build_content.mjs RELS) and the ops of a labelling overlay's entry (its _about) */
const DEP_RELS = new Set(['derives', 'equiv', 'instance', 'uses-input', 'cycle', 'contradicts', 'restates']);
const DEP_OPS = new Set(['add', 'drop', 'set-cycle', 'turn']);
const DEPENDS_FILE = /^depends_([a-z0-9]+)\.json$/;
const homeOf = r => { const s = [...(r.shownOn || [])].map((so, i) => ({ so, i })).sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0) || a.i - b.i)[0]; return s ? s.so.page : null; };
const research = (texts, id) => texts.find(t => t.row === id && t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full');

// ------------------------------------------------------------------------------------------------------------------------------- the base
/**
 * The tables as the other merges leave them, without what this merge added: its rows removed, every entry, text and page it changed restored
 * where it still holds what the merge wrote, the route renames undone. Also read by tools/migrate/story_from_v15.mjs, so a re-migration sees the
 * base. Returns { rows, texts, pages, book, restored }.
 */
/** the keys of the translator drafts that wait in the content/texts_learner*.json files (learner level) */
export function draftKeysOf() {
  const keys = new Set();
  for (const n of fs.readdirSync(C).filter(n => /^texts_learner.*\.json$/.test(n)).sort()) for (const d of readJSON(path.join(C, n), [])) if (d && d.row && d.level === 'learner') keys.add(textKey({ ...d, lens: d.lens || null }));
  return keys;
}

// A text the merge replaced is restored to its original, except an original that was a translator draft which no texts_learner*.json file holds
// any longer (a draft deleted because a v15 learner text replaces it, A56): it is dropped, not brought back.
export function baseTables({ rows = readJSON(path.join(C, 'rows.json'), []), texts = readJSON(path.join(C, 'texts.json'), []), pages = readJSON(path.join(C, 'pages.json'), []), book = readJSON(BOOK, {}), drafts = draftKeysOf() } = {}) {
  const restored = { rows: 0, entries: 0, texts: 0, pages: 0, depends: 0 };
  const renames = book.renames || {};
  const back = new Map(Object.entries(renames).map(([from, to]) => [to, from]));
  const un = r => (back.has(r) ? back.get(r) : r);
  const added = new Set(book.rows || []);
  let rs = rows.filter(r => { const drop = r.kind === 'story' || added.has(r.id); if (drop) restored.rows++; return !drop; }).map(r => ({ ...r, shownOn: (r.shownOn || []).map(so => ({ ...so, page: un(so.page) })) }));
  const byId = new Map(rs.map(r => [r.id, r]));
  for (const [key, e] of Object.entries(book.entries || {})) {
    const id = key.slice(0, key.indexOf('|')); const r = byId.get(id); if (!r) continue;
    const i = r.shownOn.findIndex(so => holds(so, e.wrote));
    if (i < 0) continue;
    if (e.orig) r.shownOn[i] = clone(e.orig); else r.shownOn.splice(i, 1);
    restored.entries++;
  }
  // the depends of a row a labelling overlay changed (step 0), back to their original where they still hold what the merge wrote
  for (const [id, e] of Object.entries(book.depends || {})) {
    const r = byId.get(id); if (!r || !holds(r.depends || [], e.wrote)) continue;
    r.depends = clone(e.orig); restored.depends++;
  }
  let ps = pages.map(p => (back.has(p.route) || (p.needs || []).some(n => back.has(n)) || back.has(p.parent) ? { ...p, route: un(p.route), ...(p.needs ? { needs: p.needs.map(un) } : {}), ...(p.parent != null ? { parent: un(p.parent) } : {}) } : p));
  const out = [];
  for (const p of ps) {
    const e = (book.pages || {})[p.route];
    if (e && holds(p, e.wrote)) { restored.pages++; if (e.orig) out.push(clone(e.orig)); continue; }
    out.push(p);
  }
  ps = out;
  const tmap = new Map(texts.map(t => [textKey(t), t]));
  for (const [key, e] of Object.entries(book.texts || {})) {
    const cur = tmap.get(key);
    if (!cur || !holds(cur, e.wrote)) continue;
    const deletedDraft = e.orig && e.orig.status !== 'human' && /^translator:/.test(e.orig.source || '') && !drafts.has(key);
    if (e.orig && !deletedDraft) tmap.set(key, clone(e.orig)); else tmap.delete(key);
    restored.texts++;
  }
  return { rows: rs, texts: [...tmap.values()], pages: ps, book, restored };
}

/**
 * The labelling overlays of depends: content/story/depends_<pass>.json, files sorted (round 15: depends_a62.json), each { _about, edges: [entries] }.
 * Returns { entries: [{ e, at, pass }], errors }; an entry's pass is its `from`, else the file's.
 */
export function readDependsOverlays(dir = S) {
  const out = { entries: [], errors: [] };
  if (!fs.existsSync(dir)) return out;
  for (const n of fs.readdirSync(dir).filter(x => DEPENDS_FILE.test(x)).sort()) {
    const j = readJSON(path.join(dir, n), null), list = j && Array.isArray(j.edges) ? j.edges : null;
    if (!list) { out.errors.push(`content/story/${n}: not { edges: [ … ] }`); continue; }
    list.forEach((e, i) => out.entries.push({ e, at: `content/story/${n} #${i} (${e && e.row} on ${e && e.id})`, pass: (e && typeof e.from === 'string' && e.from) || DEPENDS_FILE.exec(n)[1] }));
  }
  return out;
}

// ------------------------------------------------------------------------------------------------------------------------------- the merge
export function mergeStory(opts = {}) {
  const errors = [], warnings = [], notes = [];
  const E = (where, msg) => errors.push(`${where}: ${msg}`), Wn = (where, msg) => warnings.push(`${where}: ${msg}`);
  const base = baseTables(opts.tables || {});
  const figures = readJSON(path.join(C, 'figures.json'), []);
  const figIds = new Set(figures.map(f => f.id));
  const pendingFigs = new Set(readJSON(path.join(S, 'pending_figures.json'), []).map(x => (typeof x === 'string' ? x : x && x.id)));
  const status = readJSON(path.join(C, 'derived', 'status.json'), {});
  const ov = {
    rows: readJSON(path.join(S, 'rows.json'), []), texts: readJSON(path.join(S, 'texts.json'), []), layout: readJSON(path.join(S, 'layout.json'), []),
    sections: readJSON(path.join(S, 'sections.json'), []), chapters: readJSON(path.join(S, 'chapters.json'), []), furey: readJSON(path.join(S, 'furey.json'), []),
    landing: readJSON(path.join(S, 'landing.json'), {}), ids: readJSON(path.join(S, 'ids.json'), {}), review: readJSON(path.join(S, 'review.json'), {}), pending: readJSON(path.join(S, 'pending.json'), []),
    ...(opts.overlay || {}),   // a test may replace an overlay file in memory
  };
  for (const k of ['rows', 'texts', 'layout', 'sections', 'chapters', 'pending']) if (!Array.isArray(ov[k])) E(`content/story/${k}.json`, 'not an array');
  // the chains overlay of round 14 (tools/merge_chains.mjs); a test may give it in memory
  const chOv = opts.chains ? chainOverlayOf(opts.chains) : readChainOverlay();
  for (const e of chOv.errors) errors.push(e);
  if (errors.length) return { errors, warnings, notes };
  // furey.json: an array of page entries, or { pages, sections, layout } (S3 chooses; both are read)
  const fy = Array.isArray(ov.furey) ? { entries: ov.furey, layout: [] } : { entries: [...(ov.furey.pages || []), ...(ov.furey.sections || [])], layout: ov.furey.layout || [] };
  // the rows a layout file places with role learner on a page (the chapter learner lines, A51): a section move of chapters.json keeps their role
  const learnerLine = new Set([...ov.layout, ...fy.layout].filter(l => l && l.role === 'learner').map(l => `${l.row}|${l.page}`));
  // drafts of the translator files: a v15 learner text of an existing row is written `human` only where no draft of the same key waits in a
  // content/texts_learner*.json file (tools/check_learner_texts.mjs R2 refuses a draft for a row with a human text); else `reviewed`, the same words
  const draftKeys = draftKeysOf();

  const rows = base.rows.map(r => ({ ...r, shownOn: r.shownOn.map(so => ({ ...so })) }));
  const baseRowById = new Map(base.rows.map(r => [r.id, r]));
  const rowById = new Map(rows.map(r => [r.id, r]));
  const pages = base.pages.map(p => clone(p));
  const pageOf = route => pages.find(p => p.route === route);
  const tmap = new Map(base.texts.map(t => [textKey(t), t]));
  const book = { rows: [], entries: {}, texts: {}, pages: {}, renames: {}, depends: {} };
  const origEntry = new Map();            // `${id}|${page}` → the base entry (null: added)
  const origPage = new Map();             // route → the base page (null: added)
  const origText = new Map();             // key → the base record (null: added)
  const touchPage = route => { if (!origPage.has(route)) { const p = pageOf(route); origPage.set(route, p ? clone(p) : null); } };
  const sum = { storyRows: 0, promoted: { reading: 0, statement: 0, story: 0, sameAs: 0, drop: 0 }, texts: { story: 0, existing: 0, reviewed: 0, keptHuman: 0 }, layout: 0, pagesAdded: 0, pagesComposed: 0, leadsDemoted: 0, sectionsAdded: 0, sectionsRemoved: 0, renamed: 0 };

  // ---- 0. the labelling overlays of depends (round 15, A62: docs/round15/PLAN.md §2; the verdicts docs/round15/JUDGE_A62.md), before everything else,
  //      so that the chains (step 5b) and every later step read the labelled graph. An entry with verdict "accept" is applied by its op: add (the edge
  //      { id, rel } added to the row's depends when it lacks it), drop (removed), set-cycle (the edge's relation becomes cycle, in its place), turn
  //      (removed, and { id: row, rel } added to the row id); a verdict "turn" adds an added edge the other way round, a verdict { rel } adds it with
  //      that relation; "reject" and null apply nothing. An entry whose edge is already as the op leaves it changes nothing (a warning). The rows record
  //      no provenance per edge (an edge is { id, rel }; labelFrom names the first line a split line took its labels from, review is a note on the row),
  //      so the pass is recorded in the book: book.depends[row] = { orig, wrote, ops }, restored by baseTables like the merge's other writes.
  sum.depends = { entries: 0, accepted: 0, applied: 0, unchanged: 0, rows: 0, ops: {} };
  const origDeps = new Map(), depOps = new Map();
  const dov = opts.depends ? { entries: opts.depends.map((e, i) => ({ e, at: `(memory) depends #${i}`, pass: (e && e.from) || 'memory' })), errors: [] } : readDependsOverlays();
  for (const x of dov.errors) errors.push(x);
  const hasEdge = (r, id, rel) => (r.depends || []).some(d => d.id === id && d.rel === rel);
  const setDeps = (r, list, op) => { if (!origDeps.has(r.id)) origDeps.set(r.id, clone(r.depends || [])); r.depends = list; (depOps.get(r.id) || depOps.set(r.id, []).get(r.id)).push(op); };
  for (const { e, at, pass } of dov.entries) {
    sum.depends.entries++;
    if (!e || typeof e !== 'object' || typeof e.row !== 'string' || typeof e.id !== 'string' || typeof e.rel !== 'string') { E(at, 'an entry is { row, id, rel, op?, verdict, … }'); continue; }
    const v = e.verdict;
    if (v == null || v === 'reject') continue;
    let op = e.op || 'add', rel = e.rel;
    if (!DEP_OPS.has(op)) { E(at, `op ${JSON.stringify(op)}: add (none), drop, set-cycle or turn`); continue; }
    if (v === 'turn') { if (op !== 'add') { E(at, `verdict turn on an entry of op ${op} (a turn applies to an added edge)`); continue; } op = 'add-turned'; }
    else if (v && typeof v === 'object' && !Array.isArray(v)) { if (op !== 'add' || typeof v.rel !== 'string') { E(at, 'a verdict { rel } changes the relation of an added edge'); continue; } rel = v.rel; }
    else if (v !== 'accept') { E(at, `verdict ${JSON.stringify(v)}: accept, reject, turn, { rel } or null`); continue; }
    if (!DEP_RELS.has(rel)) { E(at, `rel ${JSON.stringify(rel)} is not a relation of depends`); continue; }
    const r = rowById.get(e.row), t = rowById.get(e.id);
    if (!r || !t) { E(at, `${!r ? e.row : e.id} is not a row of the tables`); continue; }
    if (r.id === t.id) { E(at, 'an edge from a row to itself'); continue; }
    sum.depends.accepted++;
    const word = `${pass}: ${op} ${e.id} ${rel}`;
    let did = false;
    if (op === 'add') { if (!hasEdge(r, e.id, rel)) { setDeps(r, [...(r.depends || []), { id: e.id, rel }], word); did = true; } }
    else if (op === 'add-turned') { if (!hasEdge(t, r.id, rel)) { setDeps(t, [...(t.depends || []), { id: r.id, rel }], `${pass}: add ${r.id} ${rel} (turned)`); did = true; } }
    else if (op === 'drop') { if (hasEdge(r, e.id, rel)) { setDeps(r, r.depends.filter(d => !(d.id === e.id && d.rel === rel)), word); did = true; } }
    else if (op === 'set-cycle') {
      if (hasEdge(r, e.id, rel) && rel !== 'cycle') {
        setDeps(r, hasEdge(r, e.id, 'cycle') ? r.depends.filter(d => !(d.id === e.id && d.rel === rel)) : r.depends.map(d => (d.id === e.id && d.rel === rel ? { id: e.id, rel: 'cycle' } : d)), word);
        did = true;
      }
    } else if (op === 'turn') {
      if (hasEdge(r, e.id, rel)) { setDeps(r, r.depends.filter(d => !(d.id === e.id && d.rel === rel)), word); did = true; }
      if (!hasEdge(t, r.id, rel)) { setDeps(t, [...(t.depends || []), { id: r.id, rel }], `${pass}: add ${r.id} ${rel} (turned from ${r.id})`); did = true; }
    }
    if (did) { sum.depends.applied++; sum.depends.ops[op] = (sum.depends.ops[op] || 0) + 1; }
    else { sum.depends.unchanged++; Wn(at, `${op} ${e.row} on ${e.id} (${rel}): the edge is already as the entry leaves it; nothing changed`); }
  }
  sum.depends.rows = [...origDeps].filter(([id, orig]) => !same(orig, rowById.get(id).depends || [])).length;

  // ---- 1. story rows (and the rows the review promotes)
  const storyIds = new Set();
  const mine = new Set();                 // the rows this merge adds (story rows and the rows the review promotes)
  const addRow = (r, where) => {
    if (rowById.has(r.id)) { E(where, `id ${r.id} is a row of the tables: a story row never replaces one`); return false; }
    const rec = clone(r); rows.push(rec); rowById.set(rec.id, rec); book.rows.push(rec.id); mine.add(rec.id); return true;
  };
  for (const [i, r] of ov.rows.entries()) {
    const at = `content/story/rows.json #${i} ${r && r.id}`;
    if (!r || typeof r.id !== 'string') { E(at, 'no id'); continue; }
    if (storyIds.has(r.id)) { E(at, 'duplicate id'); continue; }
    if (addRow(r, at)) { storyIds.add(r.id); sum.storyRows++; }
  }
  // 1b. the round-14 rows of the chains overlay (story rows of D60 and new statement rows of D61; checked by merge_chains, V9)
  const r14 = new Set();
  for (const { rec: r, file } of chOv.rows) {
    const at = `${file} ${r && r.id}`;
    if (!r || typeof r.id !== 'string') { E(at, 'no id'); continue; }
    if (r14.has(r.id) || storyIds.has(r.id)) { E(at, 'duplicate id'); continue; }
    if (addRow(r, at)) r14.add(r.id);
  }
  // the review: choices on pending entries
  const pendingByLoc = new Map(ov.pending.map(p => [p.locator, p]));
  for (const [loc, choice] of Object.entries(ov.review).sort((a, b) => cmpStr(a[0], b[0]))) {
    const p = pendingByLoc.get(loc), at = `content/story/review.json ${loc}`;
    if (!p) { if (!ov.rows.some(r => r.source === loc)) Wn(at, 'no pending entry and no story row with this locator'); continue; }
    if (choice === 'drop') { sum.promoted.drop++; continue; }
    if (choice === 'story') { if (!storyIds.has(p.id)) notes.push(`${loc}: chosen as story; re-run tools/migrate/story_from_v15.mjs to place it`); continue; }
    if (/^same-as:/.test(choice)) {
      const target = choice.slice(8);
      if (!rowById.has(target)) { E(at, `same-as ${target}: no such row`); continue; }
      if (p.pend === 'title') { const rec = { row: target, lang: 'en', mode: 'both', level: 'research', lens: null, register: 'short', body: p.text, status: 'human', source: loc }; const k = textKey(rec); if (tmap.has(k) && tmap.get(k).status === 'human') Wn(at, `${target} has a short research text already; kept`); else { if (!origText.has(k)) origText.set(k, tmap.has(k) ? clone(tmap.get(k)) : null); tmap.set(k, rec); sum.promoted.sameAs++; } }
      else sum.promoted.sameAs++;
      continue;
    }
    const m = /^(reading|statement:(.+))$/.exec(choice);
    if (!m) { E(at, `unknown choice ${JSON.stringify(choice)} (story, reading, statement:<check id>, same-as:<row id>, drop)`); continue; }
    if (!Array.isArray(p.notions) || !p.notions.length || !p.kind || !p.stage) { E(at, `${choice} needs the row's labels in its pending entry (notions, kind, stage)`); continue; }
    const isReading = m[1] === 'reading';
    const ev = isReading ? [] : [{ check: m[2], ...(p.evidence || []).find(e => e.check === m[2]) ? { script: (p.evidence || []).find(e => e.check === m[2]).script } : {}, mode: 'ran' }];
    const r = { id: p.id, group: p.id.split('-')[0], kind: isReading ? 'reading' : p.kind, stage: p.stage, ptype: p.ptype || null, notions: p.notions, fields: p.fields || [], phenomena: p.phenomena || [],
      cells: p.cells || [], homePhys: '', homeMath: '', standardRef: null, evidence: ev, depends: (p.restates || []).map(id => ({ id, rel: 'restates' })), links: [], lensTags: [],
      legacyFlags: isReading ? [] : p.legacyFlags || [], legacyLines: 0, legacyLabel: isReading ? 'reading' : null, legacyKnown: false, since: 'v15', tabV15: null, anchorV15: p.section,
      source: loc, shownOn: [{ page: p.page, section: p.section, order: 999, role: p.role === 'lead' || p.role === 'next' ? 'result' : p.role === 'learner' ? 'learner' : p.role || 'result' }],
      visibleTo: ['phys', 'math'], review: null, notesPersona: [], theorems: [], readingRefs: 0, v16: [], splitFrom: null, labelFrom: null };
    if (addRow(r, at)) {
      const rec = { row: r.id, lang: 'en', mode: 'both', level: 'research', lens: null, register: 'full', body: p.text, status: 'human', source: loc };
      tmap.set(textKey(rec), rec); origText.set(textKey(rec), null);
      for (const x of p.learner || []) { const l = { row: r.id, lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: x.text, status: 'human', source: x.locator }; tmap.set(textKey(l), l); origText.set(textKey(l), null); }
      sum.promoted[isReading ? 'reading' : 'statement']++;
    }
  }

  // ---- 2. texts
  const okKey = new Set();
  for (const [i, t] of ov.texts.entries()) {
    const at = `content/story/texts.json #${i} ${t && t.row}`;
    if (!t || !rowById.has(t.row)) { E(at, 'a text for an unknown row'); continue; }
    if (!['research', 'learner'].includes(t.level) || typeof t.body !== 'string' || !t.body.trim()) { E(at, 'level research or learner, and a body'); continue; }
    const rec = { row: t.row, lang: t.lang || 'en', mode: t.mode || 'both', level: t.level, lens: t.lens || null, register: t.register || 'full', body: t.body, status: 'human', source: t.source };
    const k = textKey(rec);
    if (okKey.has(k)) { E(at, 'two texts with the same key'); continue; }
    okKey.add(k);
    const cur = tmap.get(k);
    if (storyIds.has(t.row)) { if (!origText.has(k)) origText.set(k, cur ? clone(cur) : null); tmap.set(k, rec); sum.texts.story++; continue; }
    if (t.level !== 'learner') { E(at, 'the overlay gives an existing row learner texts only'); continue; }
    if (cur && cur.status === 'human') { sum.texts.keptHuman++; continue; }
    if (draftKeys.has(k)) { rec.status = 'reviewed'; sum.texts.reviewed++; }
    if (!origText.has(k)) origText.set(k, cur ? clone(cur) : null);
    tmap.set(k, rec); sum.texts.existing++;
  }
  // 2b. the chains overlay's texts: the research texts of its round-14 rows (content/chains/<owner>/texts.json), then the storyteller's words
  //     (content/chains/learner/*.json): spans of any row (keyed with their chain), learner texts of round-14 rows and of side notes; a human learner
  //     text of an existing row is never replaced
  const chainKeys = new Set();
  sum.chainTexts = { research: 0, spans: 0, learner: 0, keptHuman: 0 };
  const putChainText = (t, file, kind) => {
    const at = `${file} ${t && t.row}`;
    if (!t || !rowById.has(t.row)) { E(at, 'a text for an unknown row'); return; }
    if (!['research', 'learner'].includes(t.level) || typeof t.body !== 'string' || !t.body.trim()) { E(at, 'level research or learner, and a body'); return; }
    if (kind === 'research' && (t.level !== 'research' || !r14.has(t.row))) { E(at, 'content/chains/<owner>/texts.json holds the research texts of the round-14 rows of the overlay'); return; }
    if (kind === 'learner' && t.level !== 'learner') { E(at, 'content/chains/learner/ holds learner texts and spans'); return; }
    const rec = textRecord(t), k = textKey(rec);
    if (chainKeys.has(k) || (kind === 'research' && okKey.has(k))) { E(at, 'two texts with the same key'); return; }
    chainKeys.add(k);
    const cur = tmap.get(k);
    if (!isSpan(rec) && !r14.has(t.row) && cur && cur.status === 'human') { sum.chainTexts.keptHuman++; Wn(at, 'the row has a human learner text; kept'); return; }
    if (!origText.has(k)) origText.set(k, cur ? clone(cur) : null);
    tmap.set(k, rec);
    sum.chainTexts[kind === 'research' ? 'research' : isSpan(rec) ? 'spans' : 'learner']++;
  };
  for (const { rec, file } of chOv.texts) putChainText(rec, file, 'research');
  for (const { rec, file } of chOv.learner) putChainText(rec, file, 'learner');

  // ---- 3. entries of existing rows: the layout, then the page entries
  const baseSectionOf = new Map(); // `${id}|${page}` → the section of the row's base entry on that page (the entry below 1000, not an overlay one)
  for (const r of base.rows) for (const so of r.shownOn) if (!so.overlay && (so.order ?? 0) < 1000 && !baseSectionOf.has(`${r.id}|${so.page}`)) baseSectionOf.set(`${r.id}|${so.page}`, { section: so.section, order: so.order ?? 0 });
  const entryIndex = (r, page) => { let i = r.shownOn.findIndex(so => so.page === page && !so.overlay && (so.order ?? 0) < 1000); if (i < 0) i = r.shownOn.findIndex(so => so.page === page && !so.overlay); return i; };
  /** set the row's entry on a page (a story row: its own entry; an existing row: its entry on that page, recorded for the next run) */
  const setEntry = (id, page, section, order, role, { add = false, where = '' } = {}) => {
    const r = rowById.get(id);
    if (!r) return false;
    const so = { page, section, order, role };
    if (mine.has(id)) { const i = r.shownOn.findIndex(x => x.page === page); if (i >= 0) r.shownOn[i] = so; else r.shownOn.push(so); return true; }
    if (add) { r.shownOn.push(so); origEntry.set(`${id}|${page}|add|${r.shownOn.length - 1}`, null); return true; }
    const i = entryIndex(r, page);
    if (i < 0) { E(where || `${id}`, `${id} is not on ${page || '(zero)'}: an entry moves a row inside its page only (add: a new entry of order ≥ 1000)`); return false; }
    const key = `${id}|${page}`;
    if (!origEntry.has(key)) origEntry.set(key, clone(r.shownOn[i]));
    r.shownOn[i] = { ...r.shownOn[i], ...so };
    return true;
  };
  // the story overlay's layout, then the placements of the chains overlay (content/chains/<owner>/page.json: a told row placed on a page that is
  // not its home, add and order ≥ 2000; a row moved into a chain's section on its own page, its order unchanged), counted apart
  sum.chainLayout = 0;
  const layouts = [...[...ov.layout, ...fy.layout].map(l => [l, null]), ...chOv.layout.map(({ rec, file }) => [rec, file])];
  for (const [i, [l, file]] of layouts.entries()) {
    const at = `${file ? `${file} ` : ''}layout #${i} (${l && l.row} · ${l && l.page})`;
    if (!l || !rowById.has(l.row)) { E(at, 'a layout entry for an unknown row'); continue; }
    if (storyIds.has(l.row) || r14.has(l.row)) { E(at, 'a story row or a round-14 row carries its own place (shownOn); the layout is for existing rows'); continue; }
    if (!ROLES.has(l.role) || l.role === 'chain') { E(at, `role ${JSON.stringify(l.role)}${l.role === 'chain' ? ' (only a story row leads a chain)' : ''}`); continue; }
    if (!Number.isInteger(l.order) || l.order < 0 || (!l.add && l.order >= 1000) || (l.add && l.order < 1000)) { E(at, `order ${l.order}: below 1000 on the row's own page, 1000 or more for an added entry`); continue; }
    if (file) {
      // D51 and §2.7 of round 14, refused rather than repaired by step 5: an added placement sits above the order of the row's home (2000 or more on
      // a calibration page), so the home never moves; a move into a chain's section on the row's own page keeps its order
      const own = rowById.get(l.row).shownOn, home = Math.min(...own.map(so => so.order ?? 0)), cur = own.find(so => so.page === l.page && !so.overlay);
      if (l.add && own.length && l.order <= home) { E(at, `an added placement of order ${l.order}, at or below the order ${home} of the home of ${l.row}: its home would move (D51)`); continue; }
      if (!l.add && cur && (cur.order ?? 0) !== l.order) { E(at, `a move on the row's own page keeps its order ${cur.order ?? 0}, not ${l.order} (§2.7: no row is renumbered)`); continue; }
    }
    if (setEntry(l.row, l.page, l.section, l.order, l.role, { add: !!l.add, where: at })) { if (file) sum.chainLayout++; else sum.layout++; }
  }

  // ---- 4. pages: sections.json, then chapters.json, then furey.json (later files win)
  const leadSource = new Map(); // `${page}|${section}` → index of the file that placed the lead
  const leadsIn = (page, section) => rows.filter(r => r.shownOn.some(so => so.page === page && so.section === section && so.role === 'lead')).map(r => r.id);
  const resolve = (lead, loc) => lead || (loc && ov.ids[loc]) || null;
  const composed = new Set(), declared = new Map(); // route → Set of section ids an entry names
  // … then the page entries of the chains overlay, folder by folder (content/chains/<owner>/page.json, folders sorted): the last precedence
  const chainFiles = [];
  for (const { rec, file } of chOv.entries) { let f = chainFiles.find(x => x[0] === file); if (!f) chainFiles.push(f = [file, []]); f[1].push(rec); }
  const files = [['content/story/sections.json', ov.sections], ['content/story/chapters.json', ov.chapters], ['content/story/furey.json', fy.entries], ...chainFiles];
  for (const [fi, [fname, list]] of files.entries()) {
    for (const entry of list) {
      const at = `${fname} ${entry && entry.route}`;
      if (!entry || typeof entry.route !== 'string') { E(at, 'an entry needs a route'); continue; }
      const route = entry.route;
      touchPage(route);
      let page = pageOf(route);
      if (!page) {
        if (!entry.page) { E(at, 'not a route of pages.json, and no page to add'); continue; }
        const d = entry.page;
        if (d.parent && !pageOf(d.parent)) { E(at, `parent ${d.parent} is not a route`); continue; }
        if (d.after != null && !pageOf(d.after)) { E(at, `after ${d.after} is not a route`); continue; }
        // an added top-level page (round 14, §2.3) names the route it follows in the reading order (after: it comes after that page and its tabs),
        // what it needs and its learner frame; without after, a page without a parent lands at the end
        page = { route, title: d.title || { phys: route, math: route }, ...(d.parent != null ? { parent: d.parent, tab: d.tab || d.title || null } : {}), ...(d.tabV15 ? { tabV15: d.tabV15 } : {}),
          ...(d.after != null ? { after: d.after } : {}), stepNo: null, needs: Array.isArray(d.needs) ? clone(d.needs) : d.parent ? [d.parent] : [], hero: { row: null, figure: null }, sections: [],
          connective: d.connective ? clone(d.connective) : {}, learnerFrame: d.learnerFrame ? clone(d.learnerFrame) : null };
        let at2;
        if (d.after != null) { at2 = pages.findIndex(p => p.route === d.after) + 1; while (at2 < pages.length && pages[at2].parent === d.after) at2++; }
        else { const pi = d.parent ? pages.findIndex(p => p.route === d.parent) : -1; at2 = pi < 0 ? pages.length : pi + 1; while (pi >= 0 && at2 < pages.length && pages[at2].parent === d.parent) at2++; }
        pages.splice(at2, 0, page); sum.pagesAdded++;
      } else if (entry.page && fi > 0) { for (const k of ['title', 'tab', 'parent', 'learnerFrame']) if (entry.page[k] != null) page[k] = clone(entry.page[k]); }
      // the entry's connective (the try lines of the top, "top-notes", and of its sections, research and learner): merged line by line into the
      // page's, on an added page and on a recomposed one (round 14: furey.json's matter); a section's tryLearner below sets its learner line
      if (entry.connective && typeof entry.connective === 'object') {
        const cn = { ...(page.connective || {}) };
        for (const [k, v] of Object.entries(entry.connective)) { const c = cn[k]; cn[k] = typeof v === 'string' ? v : { ...(typeof c === 'string' ? { research: c } : c || {}), ...clone(v) }; }
        page.connective = cn;
      }
      composed.add(route);
      if (!declared.has(route)) declared.set(route, new Set());
      if (entry.hero) page.hero = { ...(page.hero || {}), ...clone(entry.hero) };
      if (Array.isArray(entry.parts)) page.parts = clone(entry.parts);
      page.sections = (page.sections || []).map(s => ({ ...s }));
      const absorbed = new Set();
      const placeLead = (id, section, where) => {
        if (!rowById.has(id)) { notes.push(`${where}: the lead ${id} is not a row (held or proposed: it waits in pending.json); no lead placed`); return false; }
        const r = rowById.get(id);
        if (!storyIds.has(id) && entryIndex(r, route) < 0) { E(where, `the lead ${id} is not on ${route || '(zero)'}`); return false; }
        const k = `${route}|${section}`;
        for (const other of leadsIn(route, section)) {
          if (other === id) continue;
          if (leadSource.get(k) === fi) { E(where, `a second lead in ${section}: ${other} and ${id}`); return false; }
          const so = rowById.get(other).shownOn.find(x => x.page === route && x.section === section && x.role === 'lead');
          setEntry(other, route, section, so.order, 'detail'); sum.leadsDemoted++; notes.push(`${where}: ${id} is the lead of ${section}; ${other} becomes a detail (precedence)`);
        }
        setEntry(id, route, section, 0, 'lead', { where }); leadSource.set(k, fi);
        return true;
      };
      // captions need a drawn figure (D46): rows named as captions of a section without one are its details until a figure is drawn
      const figureOf = to => (to === INTRO ? (page.hero && page.hero.figure) || ((figures.find(f => page.hero && f.captionRow === page.hero.row) || {}).id) || null : (page.sections.find(x => x.id === to) || {}).figure);
      // a chapter learner line (A51: layout role learner, shown at learner level only) moves with its section and keeps its role
      const moveRows = (from, to, role, where) => {
        const fig = figureOf(to), r2 = role === 'caption' && !(Array.isArray(fig) ? fig.length : fig) ? 'detail' : role;
        if (r2 !== role) notes.push(`${where}: captionRowsOf ${from}, but ${to} has no figure: its rows are details (D46)`);
        for (const r of rows) {
          if (mine.has(r.id)) continue;
          const b = baseSectionOf.get(`${r.id}|${route}`);
          if (b && b.section === from) setEntry(r.id, route, to, Math.min(999, 500 + b.order), learnerLine.has(`${r.id}|${route}`) ? 'learner' : r2, { where });
        }
        absorbed.add(from);
      };
      const storyDetail = (loc, to, where) => { const id = resolve(null, loc); if (id && storyIds.has(id)) setEntry(id, route, to, 800, 'detail', { where }); else notes.push(`${where}: ${loc} is not a story row; not placed`); };
      if (entry.intro) {
        const i = entry.intro, w = `${at} intro`;
        const lead = resolve(i.lead, i.leadFrom);
        page.intro = { ...(page.intro || {}) };
        if (lead && placeLead(lead, INTRO, w)) page.intro.lead = lead;
        if (i.next !== undefined && i.next !== null) page.intro.next = i.next;
        for (const from of i.captionRowsOf || []) moveRows(from, INTRO, 'caption', w);
        for (const loc of i.storyDetails || []) storyDetail(loc, INTRO, w);
        for (const s of i.absorbs || []) absorbed.add(s);
      }
      const listed = [];
      for (const se of entry.sections || []) {
        if (!se || typeof se.id !== 'string' || se.id === INTRO) { if (se && se.id === INTRO) continue; E(at, 'a section needs an id'); continue; }
        const w = `${at} ${se.id}`;
        let s = page.sections.find(x => x.id === se.id);
        if (!s) { s = { id: se.id, title: { phys: se.id, math: se.id }, query: { 'shownOn.section': se.id }, drawer: [...DRAWER] }; page.sections.push(s); sum.sectionsAdded++; }
        if (se.title !== undefined && se.title !== null) s.title = clone(se.title);
        for (const k of ['part', 'figure', 'key', 'pairs', 'group']) if (se[k] != null) s[k] = clone(se[k]);
        const lead = resolve(se.lead, se.leadFrom);
        if (lead && placeLead(lead, se.id, w)) s.lead = lead;
        for (const from of se.captionRowsOf || []) moveRows(from, se.id, 'caption', w);
        for (const from of se.detailRowsOf || []) moveRows(from, se.id, 'detail', w);
        for (const loc of se.storyDetails || []) storyDetail(loc, se.id, w);
        for (const x of se.absorbs || []) absorbed.add(x);
        if (se.tryLearner && se.tryLearner.text) {
          const c = page.connective && page.connective[se.id];
          page.connective = { ...(page.connective || {}), [se.id]: typeof c === 'string' ? { research: c, learner: se.tryLearner.text } : { ...(c || {}), learner: se.tryLearner.text } };
        }
        listed.push(se.id); declared.get(route).add(se.id);
      }
      for (const x of listed) absorbed.delete(x);
      const first = listed.map(id => page.sections.find(s => s.id === id)).filter(Boolean);
      const rest = page.sections.filter(s => !listed.includes(s.id) && !absorbed.has(s.id));
      sum.sectionsRemoved += page.sections.length - first.length - rest.length;
      page.sections = [...first, ...rest];
    }
  }
  // a section of a composed page that no entry names and no row uses leaves the page (the "(figure)" sections whose rows moved, the frames)
  for (const route of composed) {
    const page = pageOf(route); if (!page) continue;
    const used = new Set(); for (const r of rows) for (const so of r.shownOn) if (so.page === route) used.add(so.section);
    const keep = page.sections.filter(s => declared.get(route).has(s.id) || used.has((s.query && s.query['shownOn.section']) || s.id) || used.has(s.id) || s.figure);
    sum.sectionsRemoved += page.sections.length - keep.length;
    page.sections = keep;
    if (Array.isArray(page.parts)) page.parts = page.parts.map(p => ({ ...p, sections: (p.sections || []).filter(id => keep.some(s => s.id === id)) }));
  }
  sum.pagesComposed = composed.size;

  // ---- 5. homes never move (an order 500+ or a lead at 0 may lower or raise a row's entry): the home page's entry takes the lowest order
  for (const r of rows) {
    if (mine.has(r.id)) continue;
    const b = baseRowById.get(r.id); if (!b) continue;
    const before = homeOf(b); if (before === homeOf(r)) continue;
    const i = entryIndex(r, before);
    const others = r.shownOn.filter((so, j) => j !== i).map(so => so.order ?? 0);
    if (i >= 0) { const key = `${r.id}|${before}`; if (!origEntry.has(key)) origEntry.set(key, clone(r.shownOn[i])); r.shownOn[i] = { ...r.shownOn[i], order: Math.max(0, Math.min(r.shownOn[i].order ?? 0, ...others.map(o => o - 1))) }; }
    if (homeOf(r) !== before) E(r.id, `its home would move from ${before || '(zero)'} to ${homeOf(r) || '(zero)'}`);
  }

  // ---- 5b. the chains (tools/merge_chains.mjs, D59): validated on the merged tables (V1–V10), each section's chains written; the pages it changes
  //      enter the book like any page this merge composes
  const reserved = new Set([...Object.values(ov.ids || {}), ...ov.pending.map(p => p && p.id).filter(Boolean)]);
  const ch = mergeChains({ rows, texts: [...tmap.values()], pages, status, runs: readJSON(path.join(C, 'check_runs.json'), []), reserved, r14 }, chOv);
  for (const e of ch.errors) errors.push(e);
  for (const w of ch.warnings) warnings.push(w);
  for (const route of ch.touched) { touchPage(route); const i = pages.findIndex(p => p.route === route); const np = ch.pages.find(p => p.route === route); if (i >= 0 && np) pages[i] = np; }

  // ---- 6. landing: the route renames (plan §3.3: pages and shownOn; applied after the bookkeeping, below). The titles of landing.json are applied
  //      at run time by src/app/router.js (S4), with the rest of landing.json
  const routes = (ov.landing && ov.landing.routes) || {};
  const renames = Object.entries(routes).filter(([from, to]) => from !== to);
  for (const [from, to] of renames) {
    if (!pageOf(from)) { E('content/story/landing.json', `routes: ${JSON.stringify(from)} is not a route`); continue; }
    if (pageOf(to)) { E('content/story/landing.json', `routes: ${JSON.stringify(to)} is already a route`); continue; }
  }

  // ---- 7. checks
  const allText = [...tmap.values()];
  const researchOf = new Map(); for (const t of allText) if (t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full') researchOf.set(t.row, t);
  const owner = new Map(); for (const [id, t] of researchOf) if (!storyIds.has(id)) for (const w of windows40(t.body)) if (!owner.has(w)) owner.set(w, id);
  const overlap = (text, self) => { const n = String(text).replace(/\s+/g, ' ').trim(); for (let i = 0; i + 40 <= n.length; i++) { const o = owner.get(n.slice(i, i + 40)); if (o && o !== self) return o; } return null; };
  // the rows of a section for the test: its rows (the intro: the page's), the page's hero; on a sub-page also every row of its parent page, where the
  // tab's rows sit until content/story/furey.json places them (the migration read them from v15's tab, a subset of the parent's rows)
  const sectionRowsOf = (route, section) => { const parent = (pageOf(route) || {}).parent;
    return rows.filter(r => !storyIds.has(r.id) && researchOf.has(r.id) && r.shownOn.some(so => (so.page === route && (section === INTRO || so.section === section)) || (parent != null && so.page === parent)))
      .map(r => testRow(r.id, researchOf.get(r.id).body, (status[r.id] || {}).status)); };
  // a later file (chapters.json, furey.json) may move a story row; where the move would make it fail the test in its new section (T4/T5 there), the
  // row keeps the place the overlay gave it, and the move is reported: §1.6 holds over precedence
  const testIn = (id, so) => testBlock(researchOf.get(id).body, { rows: [...sectionRowsOf(so.page, so.section), ...heroRows(so.page)] }).outcome === 'story';
  for (const r0 of ov.rows) {
    const r = rowById.get(r0.id); if (!r || !researchOf.has(r.id)) continue;
    const want = (r0.shownOn || [])[0], now = r.shownOn[0];
    if (!want || !now || (now.page === want.page && now.section === want.section)) continue;
    if (!testIn(r.id, now) && testIn(r.id, want)) { r.shownOn[0] = { ...want }; Wn(`${r.id} (${r0.source})`, `moved to ${now.page || '(zero)'} · ${now.section} by a later file, where it fails the test of §1.4; it stays in ${want.section}`); sum.movesRefused = (sum.movesRefused || 0) + 1; }
  }
  const historyHits = [];
  for (const id of storyIds) {
    const r = rowById.get(id), at = `story row ${id}`;
    const so = r.shownOn || [];
    if (r.kind !== 'story') E(at, `kind ${r.kind}, not story`);
    if (!same(r.notions, ['i-meta'])) E(at, 'notions must be ["i-meta"]');
    if ((r.evidence || []).length) E(at, 'a story row cites no evidence');
    if (r.since !== 'v2.2') E(at, `since ${r.since}, not v2.2`);
    const m = /^([A-Z]{2,4})-(\d{3})$/.exec(id);
    if (!m || m[1] !== r.group || Number(m[2]) < 501 || Number(m[2]) > 999) E(at, 'an id <GROUP>-501 … 999 of its group');
    if (so.length !== 1) E(at, `${so.length} shownOn entries (one)`);
    for (const x of so) { if (!pageOf(x.page)) E(at, `page ${x.page} is not a route`); if (!ROLES.has(x.role) || x.role === 'evidence') E(at, `role ${x.role}`); }
    for (const d of r.depends || []) if (d.rel !== 'restates' || !rowById.has(d.id)) E(at, `depends ${d.id} ${d.rel}: restates, a row`);
    const t = researchOf.get(id);
    if (!t) { E(at, 'no research text'); continue; }
    if (t.source !== r.source || t.status !== 'human') E(at, `its research text is the human record of its locator ${r.source}`);
    const x = so[0];
    if (x) {
      const res = testBlock(t.body, { rows: [...sectionRowsOf(x.page, x.section), ...heroRows(x.page)] });
      if (res.outcome !== 'story') E(at, `fails the test of §1.4 in ${x.page || '(zero)'} · ${x.section}: ${[...res.uncovered.map(u => `uncovered ${u}`), ...res.missingStatus.map(s => `status word missing for ${s}`)].join('; ') || res.signals.join(', ')}`);
    }
    const o = overlap(t.body, id); if (o) E(at, `holds 40 characters of ${o}'s research text`);
    for (const tx of allText) if (tx.row === id && HISTORY.test(tx.body)) historyHits.push(`${id} ${tx.level}: "${tx.body.match(HISTORY)[0]}" (author's text)`);
  }
  function heroRows(route) { const p = pageOf(route); const h = p && p.hero && p.hero.row; return h && researchOf.has(h) && !storyIds.has(h) ? [testRow(h, researchOf.get(h).body, (status[h] || {}).status)] : []; }
  // leads, captions, figures
  const leadCount = new Map();
  for (const r of rows) for (const so of r.shownOn) {
    if (so.role === 'lead') { const k = `${so.page}|${so.section}`; leadCount.set(k, [...(leadCount.get(k) || []), r.id]); }
    if (so.role && !ROLES.has(so.role)) E(r.id, `role ${so.role}`);
  }
  for (const [k, ids] of leadCount) if (ids.length > 1) E(k.replace('|', ' · '), `two leads: ${ids.join(', ')}`);
  const figureList = f => (Array.isArray(f) ? f : f ? [f] : []);
  for (const p of pages) for (const s of p.sections || []) for (const f of figureList(s.figure)) if (!figIds.has(f) && !pendingFigs.has(f)) E(`${p.route || '(zero)'} · ${s.id}`, `figure ${f} is neither in figures.json nor in pending_figures.json`);
  const heroFigure = p => (p.hero && p.hero.figure) || ((figures.find(f => p.hero && f.captionRow === p.hero.row) || {}).id) || null;
  for (const r of rows) for (const so of r.shownOn) {
    if (so.role !== 'caption') continue;
    const p = pageOf(so.page); if (!p) continue;
    const s = (p.sections || []).find(x => x.id === so.section || (x.query && x.query['shownOn.section'] === so.section));
    const sectionIds = new Set(rows.filter(x => x.shownOn.some(y => y.page === so.page && y.section === so.section)).map(x => x.id));
    const has = so.section === INTRO ? !!heroFigure(p) : (s && figureList(s.figure).length > 0) || figures.some(f => f.captionRow && sectionIds.has(f.captionRow));
    if (!has) E(`${r.id} on ${so.page || '(zero)'} · ${so.section}`, 'a caption in a section without a figure');
  }
  for (const r of rows) for (const so of r.shownOn) if (!pageOf(so.page)) E(r.id, `shownOn page ${so.page} is not a route`);

  // ---- 8. the bookkeeping (in the routes before the rename), then the renames
  for (const [key, orig] of origEntry) {
    const [id, page] = key.split('|'); const r = rowById.get(id); if (!r) continue;
    if (key.includes('|add|')) { const idx = Number(key.split('|')[3]); book.entries[key] = { orig: null, wrote: digest(r.shownOn[idx]) }; continue; }
    const i = entryIndex(r, page); if (i < 0) continue;
    if (!same(orig, r.shownOn[i])) book.entries[key] = { orig, wrote: digest(r.shownOn[i]) };
  }
  for (const [k, orig] of origText) { const cur = tmap.get(k); if (cur && !same(orig, cur)) book.texts[k] = { orig, wrote: digest(cur) }; }
  for (const [route, orig] of origPage) { const cur = pageOf(route); if (cur && !same(orig, cur)) book.pages[route] = { orig, wrote: digest(cur) }; }
  for (const [id, orig] of origDeps) { const r = rowById.get(id); if (r && !same(orig, r.depends || [])) book.depends[id] = { orig, wrote: digest(r.depends || []), ops: depOps.get(id) }; }
  for (const [from, to] of renames) {
    if (!pageOf(from) || pageOf(to)) continue;
    book.renames[from] = to; sum.renamed++;
    for (const p of pages) { if (p.route === from) p.route = to; if (Array.isArray(p.needs)) p.needs = p.needs.map(n => (n === from ? to : n)); if (p.parent === from) p.parent = to; }
    for (const r of rows) for (const so of r.shownOn) if (so.page === from) so.page = to;
  }
  // (a book entry is kept in the routes before the rename: baseTables un-renames first)

  // ---- texts of rows that no longer exist (a story row the overlay dropped) go with them
  const ids = new Set(rows.map(r => r.id));
  let droppedTexts = 0;
  for (const [k, t] of [...tmap]) if (!ids.has(t.row)) { tmap.delete(k); droppedTexts++; }
  rows.sort((a, b) => cmpStr(a.id, b.id));
  const texts = [...tmap.values()].sort(byText);
  book.rows.sort(cmpStr);
  const ordered = o => Object.fromEntries(Object.entries(o).sort((a, b) => cmpStr(a[0], b[0])));
  book.entries = ordered(book.entries); book.texts = ordered(book.texts); book.pages = ordered(book.pages); book.depends = ordered(book.depends);
  // the pending entries are never rows (D45): only a choice of review.json makes one
  for (const p of ov.pending) if (rowById.has(p.id) && !ov.review[p.locator] && !storyIds.has(p.id)) E(`pending ${p.id}`, 'a pending entry is a row without a choice in review.json');
  Object.assign(sum, { droppedTexts, entriesChanged: Object.keys(book.entries).length, textsChanged: Object.keys(book.texts).length, pagesChanged: Object.keys(book.pages).length, history: historyHits.length,
    restored: base.restored, allRows: rows.length, allTexts: texts.length, chains: ch.summary, chainRows: r14.size });
  if (historyHits.length) notes.push(...historyHits.map(h => `history word in ${h}`));
  return { errors, warnings, notes, rows, texts, pages, book, summary: sum, chains: ch.chains, chainSummary: ch.summary, chainWarnings: ch.warnings };
}

// ------------------------------------------------------------------------------------------------------------------------------- CLI
async function main(argv) {
  const check = argv.includes('--check');
  const res = mergeStory();
  if (res.warnings.length) console.log(res.warnings.slice(0, 40).map(w => 'warning ' + w).join('\n'));
  if (res.notes.length) console.log(res.notes.slice(0, 30).map(n => 'note ' + n).join('\n') + (res.notes.length > 30 ? `\nnote … ${res.notes.length - 30} more` : ''));
  if (res.errors.length) { console.log(res.errors.slice(0, 80).map(e => 'ERROR ' + e).join('\n') + (res.errors.length > 80 ? `\n… ${res.errors.length - 80} more` : '')); console.log(`merge_story: ${res.errors.length} error(s); nothing written`); return 1; }
  const s = res.summary, cs = s.chains || {}, ct = s.chainTexts || {}, dp = s.depends || {};
  const line = `depends overlays: ${dp.accepted || 0} accepted entries, ${dp.applied || 0} applied (${Object.entries(dp.ops || {}).map(([k, v]) => `${v} ${k}`).join(', ') || 'none'}) on ${dp.rows || 0} rows${dp.unchanged ? `, ${dp.unchanged} already as they leave them` : ''}; story rows ${s.storyRows}; texts: ${s.texts.story} of story rows, ${s.texts.existing} learner texts of existing rows (${s.texts.reviewed} written "reviewed": a draft of the same key waits in a content/texts_learner*.json file; ${s.texts.keptHuman} human kept); layout ${s.layout} entries; pages composed ${s.pagesComposed}, added ${s.pagesAdded}; sections added ${s.sectionsAdded}, removed ${s.sectionsRemoved}; leads demoted ${s.leadsDemoted}; renames ${s.renamed}; review: ${JSON.stringify(s.promoted)}; chains ${cs.chains || 0} (${cs.storied || 0} storied, ${cs.spans || 0} spans; round-14 rows ${s.chainRows || 0}, their research texts ${ct.research || 0}, learner texts ${ct.learner || 0}; placements ${s.chainLayout || 0}); rows ${s.allRows}, texts ${s.allTexts}${s.movesRefused ? `; moves kept back ${s.movesRefused}` : ''}`;
  if (check) { console.log(`merge_story --check: ${line}`); return 0; }
  W(path.join(C, 'rows.json'), res.rows);
  W(path.join(C, 'texts.json'), res.texts);
  W(path.join(C, 'pages.json'), res.pages);
  W(path.join(C, 'chains.json'), res.chains);   // the merged chains (round 14, interface 40), shipped as a table
  fs.writeFileSync(BOOK, JSON.stringify(res.book, null, 1) + '\n');
  const cf = path.join(C, 'MIGRATION_COUNTS.json'); const counts = readJSON(cf, {});
  counts.storyMerge = { storyRows: s.storyRows, textsOfStoryRows: s.texts.story, learnerTextsOfExistingRows: s.texts.existing, reviewedForDrafts: s.texts.reviewed, layout: s.layout, pagesComposed: s.pagesComposed, pagesAdded: s.pagesAdded, entriesChanged: s.entriesChanged, renames: s.renamed, review: s.promoted,
    dependsOverlays: { accepted: dp.accepted || 0, applied: dp.applied || 0, ops: dp.ops || {}, rows: dp.rows || 0 } };
  counts.chainMerge = { chains: cs.chains || 0, storied: cs.storied || 0, reviewed: cs.reviewed || 0, spans: cs.spans || 0, pages: cs.pages || 0, rows: s.chainRows || 0, storyRows: cs.storyRows || 0, newRows: cs.newRows || 0,
    researchTexts: ct.research || 0, learnerTexts: ct.learner || 0, keptHuman: ct.keptHuman || 0, layout: s.chainLayout || 0 };
  W(cf, counts);
  console.log(`merge_story: ${line}`);
  return 0;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(await main(process.argv.slice(2)));
