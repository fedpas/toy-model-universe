#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/make_analysis.mjs — one analysis page of public/reports/analyses/ from its markdown source, in the shape of the pages of that folder
// (one self-contained HTML page: inline style, the formulas as MathML, no script, no request of any kind).
//   node tools/make_analysis.mjs <id>          renders the entry <id> of content/analyses.json: its first source (public/<sources[0]>) → public/<html>
//   node tools/make_analysis.mjs <id> --check  writes nothing; exit 1 if the shipped page differs from what the source gives
// The source is shown as it is: CommonMark and pipe tables (markdown-it), formulas between $ … $ and $$ … $$ rendered by katex to MathML; a formula katex
// cannot read is printed as its own source in <code class="tex"> and counted. The style is tools/analyses/analysis_style.css. Needs markdown-it and katex
// (from NODE_PATH, default /opt/npm-tools/node_modules). Deterministic: the same source gives the same bytes.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NM = process.env.NODE_PATH || '/opt/npm-tools/node_modules';
const req = createRequire(path.join(NM, 'noop.js'));
const MarkdownIt = req('markdown-it'), katex = req('katex');
const versions = { 'markdown-it': JSON.parse(fs.readFileSync(path.join(NM, 'markdown-it/package.json'), 'utf8')).version, katex: JSON.parse(fs.readFileSync(path.join(NM, 'katex/package.json'), 'utf8')).version };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---- formulas: $…$ inline (pandoc's rule: a non-space on the right of the opening $, a non-space on the left of the closing one, no digit after it), $$…$$ display
const isSp = c => c === 0x20 || c === 0x09 || c === 0x0a || c === 0x0d || Number.isNaN(c);
function inlineClose(src, pos, max) {
  if (pos + 1 >= max || isSp(src.charCodeAt(pos + 1)) || src.charCodeAt(pos + 1) === 0x24) return -1;
  for (let i = pos + 1; i < max; i++) {
    const c = src.charCodeAt(i);
    if (c === 0x5c) { i++; continue; }
    if (c !== 0x24) continue;
    const after = src.charCodeAt(i + 1); if (after >= 0x30 && after <= 0x39) continue;
    if (!isSp(src.charCodeAt(i - 1))) return i;
  }
  return -1;
}
function mathPlugin(md, renderMath) {
  md.inline.ruler.before('escape', 'math', (state, silent) => {
    const src = state.src, pos = state.pos, max = state.posMax;
    if (src.charCodeAt(pos) !== 0x24) return false;
    if (src.charCodeAt(pos + 1) === 0x24) {
      const end = src.indexOf('$$', pos + 2);
      if (end < 0 || end + 2 > max || !src.slice(pos + 2, end).trim()) return false;
      if (!silent) { const t = state.push('math_display', 'math', 0); t.content = src.slice(pos + 2, end); }
      state.pos = end + 2; return true;
    }
    const end = inlineClose(src, pos, max);
    if (end < 0) return false;
    if (!silent) { const t = state.push('math_inline', 'math', 0); t.content = src.slice(pos + 1, end); }
    state.pos = end + 1; return true;
  });
  md.renderer.rules.math_inline = (tokens, idx) => renderMath(tokens[idx].content, false);
  md.renderer.rules.math_display = (tokens, idx) => renderMath(tokens[idx].content, true);
}
const DOUBLE = { 'ℕ': 'N', 'ℤ': 'Z', 'ℚ': 'Q', 'ℝ': 'R', 'ℂ': 'C', 'ℍ': 'H', 'ℙ': 'P' };
const KATEX = { output: 'mathml', throwOnError: true, strict: 'ignore', trust: false };
const slug = s => String(s).normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\$[^$]*\$|`[^`]*`/g, m => m.replace(/[\\{}^_$`]/g, ' ')).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48).replace(/-+$/, '') || 'section';

export function render(entry, source) {
  const fallbacks = [];
  const renderMath = (tex, display) => {
    try {
      const out = katex.renderToString(tex.replace(/[ℕℤℚℝℂℍℙ]/g, c => '\\mathbb{' + DOUBLE[c] + '}'), { ...KATEX, displayMode: display });
      const m = out.replace(/^<span class="katex(?:-display)?">(?:<span class="katex">)?/, '').replace(/(?:<\/span>)+$/, '').replace(' xmlns="http://www.w3.org/1998/Math/MathML"', '')
        .replace(/<semantics>|<\/semantics>/g, '').replace(/<annotation encoding="application\/x-tex">[\s\S]*?<\/annotation>/, '');
      return !display && tex.length >= 24 ? `<span class="mx">${m}</span>` : m;
    } catch (e) {
      fallbacks.push({ tex, why: String(e.message).split('\n')[0].slice(0, 160) });
      const d = display ? '$$' : '$';
      return `<code class="tex">${esc(d + tex + d)}</code>`;
    }
  };
  const md = new MarkdownIt({ html: false, linkify: false, typographer: false, breaks: false });
  mathPlugin(md, renderMath);
  md.renderer.rules.table_open = () => '<div class="tw"><table>\n';
  md.renderer.rules.table_close = () => '</table></div>\n';
  const env = {}, tokens = md.parse(source, env), used = new Set(['top', 'sections', 'main']), heads = [];
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i]; if (t.type !== 'heading_open') continue;
    let id = slug(tokens[i + 1].content), k = 2; const base = id; while (used.has(id)) id = base + '-' + k++;
    used.add(id); t.attrSet('id', id); heads.push({ id, level: +t.tag.slice(1), html: md.renderer.renderInline(tokens[i + 1].children, md.options, env) });
  }
  const body = md.renderer.render(tokens, md.options, env);
  const toc = heads.filter(h => h.level === 2).map(h => `<a href="#${h.id}">${h.html}</a>`);
  const gen = `make_analysis.mjs (markdown-it ${versions['markdown-it']}, katex ${versions.katex})`;
  const style = fs.readFileSync(path.join(ROOT, 'tools/analyses/analysis_style.css'), 'utf8').replace(/^(\/\*[^*]*\*\/\s*)+/, '');   // the licence header of the stylesheet stays in the source file; the page carries its own notice in the footer
  const src = entry.sources && entry.sources[0] ? `<a href="${esc(path.relative(path.dirname(entry.html), entry.sources[0]))}" download="${esc(path.basename(entry.sources[0]))}">The markdown source</a>` : '';
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="generator" content="${esc(gen)}">
<title>${esc(entry.title)}</title>
<style>
${style.trim()}
</style>
</head>
<body id="top">
<header class="hero"><div class="wrap">
<p class="kick">Cascade Atlas · ${esc(entry.kind)}</p>
<p class="an-t">${esc(entry.title)}</p>
<p class="sub">${esc(entry.line)}</p>
${src ? `<p class="dl">${src}</p>\n` : ''}</div></header>
${toc.length ? `<nav class="toc" id="sections" aria-label="Sections"><div class="wrap">${toc.join('\n')}</div></nav>\n` : ''}<main class="wrap md" id="main">
${body}</main>
<footer class="wrap"><p>The text above is the markdown source as it is, rendered by ${esc(gen)}; the formulas are MathML. Part of the Cascade Atlas package, PolyForm Noncommercial 1.0.0 (see LICENSE). <a href="#top">Back to the top</a></p></footer>
</body>
</html>
`;
  return { html, fallbacks };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const id = process.argv[2], check = process.argv.includes('--check');
  const entries = JSON.parse(fs.readFileSync(path.join(ROOT, 'content/analyses.json'), 'utf8'));
  const entry = entries.find(a => a.id === id);
  if (!entry) { console.error(`make_analysis: no entry "${id}" in content/analyses.json`); process.exit(1); }
  const srcFile = path.join(ROOT, 'public', entry.sources[0]), outFile = path.join(ROOT, 'public', entry.html);
  const { html, fallbacks } = render(entry, fs.readFileSync(srcFile, 'utf8'));
  for (const f of fallbacks) console.log(`   as text: $${f.tex}$  (${f.why})`);
  if (check) { const same = fs.existsSync(outFile) && fs.readFileSync(outFile, 'utf8') === html; console.log(`${same ? 'current' : 'OUT OF DATE'}  ${entry.html}`); process.exit(same ? 0 : 1); }
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, html);
  console.log(`wrote ${path.relative(ROOT, outFile)}: ${Buffer.byteLength(html)} bytes, ${fallbacks.length} formula(s) as text`);
}
