#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""Generates tests/fixtures/bitrule_reference.json from the author's reference engine researchers_checks/bitrule_A.py:
the full sign table of every sign vector eps in {+1,-1,0}^n for n <= 4 (121 cells), and 60 random multivector products in Cl(2,1,1) and Cl(3,1)."""
import sys, json, itertools, random
sys.path.insert(0, 'checks/researchers_checks')
from bitrule_A import BR
out = {'cells': [], 'products': []}
for n in range(0, 5):
    for eps in itertools.product([1, -1, 0], repeat=n):
        A = BR(eps); N = 1 << n
        out['cells'].append({'eps': list(eps), 'S': [[A.s(a, b) for b in range(N)] for a in range(N)]})
rng = random.Random(7)
for eps in ([1, 1, -1, 0], [1, 1, 1, -1]):
    A = BR(eps); N = 1 << len(eps)
    for _ in range(30):
        x = {a: rng.randint(-5, 5) for a in range(N) if rng.random() < 0.6}; y = {a: rng.randint(-5, 5) for a in range(N) if rng.random() < 0.6}
        z = A.mul(x, y)
        out['products'].append({'eps': eps, 'x': x, 'y': y, 'z': z})
json.dump(out, open('tests/fixtures/bitrule_reference.json', 'w'))
print(len(out['cells']), 'cells,', len(out['products']), 'products')
