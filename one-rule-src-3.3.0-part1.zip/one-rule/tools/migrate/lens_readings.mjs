#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/migrate/lens_readings.mjs — the lens readings of the rows (BUILD_CONTRACTS, interface 7) → content/lens_readings.json,
// an array sorted by (lens, row, atlas) of { lens, row, atlas, term, match, evidence: [check ids], via: "evidence"|"text",
// source: "lenses.dictionary"|"readings" }, and the counts under `lensReadings` in content/MIGRATION_COUNTS.json.
// A reading is attached to a row only by a mechanical link, never by hand:
//   via "evidence" — a check id named by the entry and cited in the row's evidence (rows.json evidence[].check);
//   via "text"     — the entry's atlas phrase (formulas and markup taken out, at least 12 characters) occurs verbatim,
//                    case-insensitively and as whole words, in the row's research text (texts.json, research level, no lens).
// Two sources: each dictionary entry of lenses.json (its `evidence` ids), and each reading of readings.json whose `field`
// maps to a lens in FIELD_LENS below (the check ids its note and its atlas element name). docs/LENS_READINGS.md has the rules and counts.
// The narration rows (kind story) get no reading.
// Usage (from the repository root): node tools/migrate/lens_readings.mjs     — deterministic: the same tables give the same file.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const CONTENT = path.join(ROOT, 'content');

// ------------------------------------------------------------------ the field of a reading → the lens that reads in its words
// One line per field of readings.json. A field maps to the lens of the registry that is its obvious counterpart; the fields with
// null have none and are left out (printed by the script, listed in the counts). The registry files the readings of
// "theoretical physics (all)" under fld and those of "whole mathematics" under alg; their entries there carry no evidence ids.
export const FIELD_LENS = {
  'mathematics: algebra': 'alg',
  'mathematics: geometry and topology': 'geo',
  'mathematics: category theory': 'cat',
  'category lens (KTH notes, Tenfold Way, Tian, Majkic v2)': 'cat',
  'physics: string theory': 'str',
  'physics: solid state': 'sol',
  'physics: field theory': 'fld',
  'Schuller lectures (mathematics for physics)': 'schuller',
  'Baez: octonions, Jordan algebras, Standard Model': 'baez',
  'Hestenes / Lasenby-Doran-Gull (spacetime algebra, gauge theory gravity)': 'hestenes',
  'Furey (octonions, Cl(0,10), one generation)': 'furey',
  'Pumplun (graded algebras, skew polynomial rings, cocycles)': 'pumplun',
  'Majkic paper (merged, four lanes)': 'majkic',
  'algebra (Majkic reading)': 'majkic',
  'category theory (Majkic reading)': 'majkic',
  'geometry (Majkic reading)': 'majkic',
  'physics (Majkic reading)': 'majkic',
  'physics: theoretical physics (all)': null,
  'mathematics: whole mathematics': null,
  'merge agreement (physics x mathematics)': null,
};

// ------------------------------------------------------------------ check ids
const SCRIPT_EXT = /\.(py|mjs|js|sh)$/;
/** a check id as compared: trimmed, without backticks; a script path or file name becomes its base name without extension */
export function normId(s) {
  let t = String(s ?? '').trim().replace(/^`+|`+$/g, '').trim();
  if (SCRIPT_EXT.test(t)) t = t.split('/').pop().replace(SCRIPT_EXT, '');
  return t;
}
const isScriptId = id => !id.includes('·');

const SEG = /^([A-Za-z_]*?)(\d+)([a-z]?)$/; // the last segment of an id: letters, a number, an optional letter (B10b, K1a, 3)
const splitSeg = s => { const m = SEG.exec(s); return m ? { L: m[1], D: Number(m[2]), S: m[3] } : null; };
const END = '(?![A-Za-z0-9_·])';
const CONT_SUFFIX = new RegExp(`^/([a-z])${END}`);                                  // core·B10b/c
const CONT_SUFFIX_RANGE = new RegExp(`^\\s*[–-]\\s*([a-z])${END}`);                  // cat·K1a–e
const CONT_RANGE = new RegExp(`^\\s*[–-]\\s*·?([A-Za-z_]*?)(\\d+)${END}`);           // bd·mja·9–14, core·B7–B9, bd·mjg·22–·25
const CONT_LIST = new RegExp(`^(?:/|,\\s*·?)([A-Za-z_]*?)(\\d+)([a-z]?)${END}`);     // core·B7/B8, bd·mja·3, 19, core·B8, B9, bd·mjg·1, ·7

/**
 * The individual check ids written in a text, the author's shorthand expanded: "bd·mja·3, 19, 21" → bd·mja·3, bd·mja·19, bd·mja·21;
 * "core·B7–B9" → core·B7, core·B8, core·B9; "core·B10b/c" → core·B10b, core·B10c; "cat·K1a–e" → cat·K1a … cat·K1e;
 * "bd·mjg·1, ·7" → bd·mjg·1, bd·mjg·7. A continuation is taken only in the same letter class (", T6" after cat·K2a is not cat·T6).
 */
export function dottedIds(text) {
  const s = String(text ?? '');
  const out = new Set();
  const re = /(?<![A-Za-z0-9_·])([A-Za-z][A-Za-z0-9_]*(?:·[A-Za-z0-9_]+)+)/g;
  let m;
  while ((m = re.exec(s))) {
    const full = m[1];
    out.add(full);
    const cut = full.lastIndexOf('·');
    const prefix = full.slice(0, cut + 1);
    let last = splitSeg(full.slice(cut + 1));
    let pos = re.lastIndex;
    while (last) {
      const rest = s.slice(pos);
      let c;
      if (last.S && (c = CONT_SUFFIX.exec(rest))) {
        out.add(prefix + last.L + last.D + c[1]);
      } else if (last.S && (c = CONT_SUFFIX_RANGE.exec(rest))) {
        const a = last.S.charCodeAt(0), b = c[1].charCodeAt(0);
        for (let k = a + 1; k <= b; k++) out.add(prefix + last.L + last.D + String.fromCharCode(k));
        last = { ...last, S: c[1] };
      } else if (!last.S && (c = CONT_RANGE.exec(rest)) && c[1] === last.L) {
        const hi = Number(c[2]);
        if (hi > last.D && hi - last.D <= 40) for (let k = last.D + 1; k <= hi; k++) out.add(prefix + last.L + k);
        last = { L: last.L, D: hi, S: '' };
      } else if ((c = CONT_LIST.exec(rest)) && c[1] === last.L) {
        out.add(prefix + c[1] + c[2] + c[3]);
        last = { L: c[1], D: Number(c[2]), S: c[3] };
      } else break;
      pos += c[0].length;
    }
    re.lastIndex = pos;
  }
  return out;
}

const TOKEN = '(?:[A-Za-z]{0,3}\\d+[a-z]?|[A-Z])';
const TOKEN_LIST = new RegExp(`^\`?\\s*(${TOKEN}(?:\\s*(?:,|/|–|-)\\s*${TOKEN})*)(?![A-Za-z0-9_·.])`);
/** the checks listed right after a script name: "T4", "K1–K4", "G1/G7", "S10, G8", "A, E", "1, 4" (ranges expanded) */
function tokenList(text) {
  const out = [];
  const m = TOKEN_LIST.exec(text);
  if (!m) return out;
  const parts = m[1].split(/\s*(,|\/|–|-)\s*/);
  for (let i = 0; i < parts.length; i += 2) {
    const sep = parts[i - 1], a = out.length ? splitSeg(out[out.length - 1]) : null, b = splitSeg(parts[i]);
    if ((sep === '–' || sep === '-') && a && b && a.L === b.L && !a.S && !b.S && b.D > a.D && b.D - a.D <= 40) {
      for (let k = a.D + 1; k <= b.D; k++) out.push(a.L + k);
    } else out.push(parts[i]);
  }
  return out;
}

const SCRIPT_NAME = /(?<![\w·.-])`?([A-Za-z][\w-]*?)(\.py|\.mjs)?`?(?![\w·-])/g;
const CLAUSE = /\b(?:evidence|checks|where checked)\s*:/gi;
const CLAUSE_END = /;\s*flag\b|\[table at line/;

/**
 * The check ids a reading's note names: { ids, scripts }.
 *   ids     — single checks: written out (dottedIds), or a script name followed by checks of that script ("`baez_check.py` T4 ok"
 *             → baez·T4, through the ids checks.json lists for the script); a group name stands for its members (fibre·G5 →
 *             fibre·G5a … when only those exist);
 *   scripts — whole scripts named in the note's evidence clause ("evidence: …", "checks: …", up to "; flag"), when no single check
 *             of that script is named with them. A script mentioned in running prose ("… is not in baez_check.py") is not evidence.
 */
export function noteIds(note, vocab) {
  const s = String(note ?? '');
  const ids = new Set();
  for (const id of dottedIds(s)) {
    const grp = vocab.known.has(id) ? null : vocab.groups.get(id);
    if (grp) for (const g of grp) ids.add(g); else ids.add(id);
  }
  const named = new Set(); // scripts named together with one of their checks
  const found = [];
  SCRIPT_NAME.lastIndex = 0;
  let m;
  while ((m = SCRIPT_NAME.exec(s))) {
    const base = m[1];
    if (!m[2] && !vocab.scripts.has(base)) continue;
    found.push({ base, start: m.index, end: SCRIPT_NAME.lastIndex });
    const own = vocab.scriptChecks.get(base);
    if (!own) continue;
    for (const t of tokenList(s.slice(SCRIPT_NAME.lastIndex).replace(/^\s+/, ''))) {
      const hit = own.get(t);
      if (hit) { for (const h of hit) ids.add(h); named.add(base); }
    }
  }
  const clauses = [];
  CLAUSE.lastIndex = 0;
  while ((m = CLAUSE.exec(s))) {
    const from = CLAUSE.lastIndex, stop = s.slice(from).search(CLAUSE_END);
    clauses.push([from, stop < 0 ? s.length : from + stop]);
  }
  const scripts = new Set();
  for (const x of found) if (!named.has(x.base) && clauses.some(([a, b]) => x.start >= a && x.end <= b)) scripts.add(x.base);
  return { ids, scripts };
}

// ------------------------------------------------------------------ the text route
/** the words of a phrase or a text: `$…$` formulas, backticks and bold/underline marks taken out, white space collapsed */
export function plainWords(s) {
  return String(s ?? '')
    .replace(/\$\$[\s\S]*?\$\$|\$[^$]*\$/g, ' ')
    .replace(/`+/g, '')
    .replace(/\*\*|__/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}
/** the atlas phrase compared with the texts: its plain words without the punctuation that starts or ends it */
export function atlasPhrase(atlas) {
  return plainWords(atlas).replace(/^[\s,;:.]+|[\s,;:.]+$/g, '');
}
export const PHRASE_MIN = 12;
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
/** a test of a phrase against plain words (verbatim up to case, as whole words); null when the phrase is under PHRASE_MIN characters */
export function phraseTest(phrase) {
  if ([...phrase].length < PHRASE_MIN) return null;
  const re = new RegExp(`(?<![\\p{L}\\p{N}])${escRe(phrase)}(?![\\p{L}\\p{N}])`, 'iu');
  return plain => re.test(plain);
}
/** does the atlas phrase of an entry occur in a research text, by the rule above? */
export function phraseIn(atlas, text) {
  const test = phraseTest(atlasPhrase(atlas));
  return !!test && test(plainWords(text));
}

// ------------------------------------------------------------------ the derivation
const cmp = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

export function deriveLensReadings({ rows, texts, lenses, readings, checks }) {
  rows = rows.filter(r => r.kind !== 'story');   // a narration row states nothing a reading could name (D7; docs/STORY_PLAN.md §1.6)
  const lensKeys = new Set(lenses.map(l => l.key));
  for (const [f, k] of Object.entries(FIELD_LENS)) if (k && !lensKeys.has(k)) throw new Error(`FIELD_LENS maps "${f}" to an unknown lens ${k}`);

  // the rows' evidence: check id → the rows citing it
  const byCheck = new Map();
  for (const r of rows) for (const e of r.evidence || []) {
    const k = normId(e.check);
    if (!k) continue;
    if (!byCheck.has(k)) byCheck.set(k, new Set());
    byCheck.get(k).add(r.id);
  }
  // the vocabulary of check ids (the rows' and checks.json's); scripts by base name with the ids each lists ("baez·T4" under "T4",
  // "cat·K1a" under "K1a" and under the group "K1")
  const known = new Set(byCheck.keys());
  const scripts = new Set([...byCheck.keys()].filter(isScriptId));
  const scriptChecks = new Map();
  for (const c of checks || []) {
    if (!c.script) continue;
    const base = normId(c.script);
    scripts.add(base);
    for (const x of c.ids || []) {
      const id = typeof x === 'string' ? x : x && x.id;
      if (typeof id !== 'string' || !id.includes('·')) continue;
      known.add(id);
      const last = id.slice(id.lastIndexOf('·') + 1);
      if (!scriptChecks.has(base)) scriptChecks.set(base, new Map());
      const own = scriptChecks.get(base);
      for (const key of new Set([last, last.replace(/(\d)[a-z]$/, '$1')])) { if (!own.has(key)) own.set(key, new Set()); own.get(key).add(id); }
    }
  }
  for (const own of scriptChecks.values()) for (const [k, v] of own) {
    const exact = [...v].filter(x => x.endsWith('·' + k));
    if (exact.length && exact.length < v.size) own.set(k, new Set(exact));
  }
  const groups = new Map(); // "fibre·G5" → [fibre·G5a, …] when the group name is not itself a check id
  for (const id of known) {
    const g = /^(.*·[A-Za-z_]*\d+)[a-z]$/.exec(id);
    if (g && !known.has(g[1])) { if (!groups.has(g[1])) groups.set(g[1], []); groups.get(g[1]).push(id); }
  }
  for (const v of groups.values()) v.sort();
  const vocab = { known, scripts, scriptChecks, groups };

  // the research text of each row (research level, the Atlas's own words), in plain words
  const research = new Map();
  for (const t of texts) {
    if (t.level !== 'research' || t.lens != null || typeof t.body !== 'string' || !t.body) continue;
    research.set(t.row, research.has(t.row) ? `${research.get(t.row)}\n${t.body}` : t.body);
  }
  const plainResearch = rows.filter(r => research.has(r.id)).map(r => [r.id, plainWords(research.get(r.id))]);

  const out = [];
  const shared = idSet => {
    const hit = new Map();
    for (const id of idSet) for (const r of byCheck.get(id) || []) { if (!hit.has(r)) hit.set(r, new Set()); hit.get(r).add(id); }
    return hit;
  };
  const textMemo = new Map();
  const textRows = atlas => {
    const p = atlasPhrase(atlas);
    if (!textMemo.has(p)) {
      const test = phraseTest(p);
      textMemo.set(p, test ? plainResearch.filter(([, plain]) => test(plain)).map(([id]) => id) : []);
    }
    return textMemo.get(p);
  };
  const push = (lens, row, e, evidence, via, source) => out.push({ lens, row, atlas: String(e.atlas ?? ''), term: String(e.term ?? ''), match: String(e.match ?? ''), evidence: [...evidence].sort(), via, source });

  // 1. the dictionaries of the registry: their evidence ids, else their atlas phrase
  let dictEntries = 0, dictLinked = 0;
  for (const l of lenses) for (const d of l.dictionary || []) {
    dictEntries++;
    if (!String(d.term ?? '').trim()) continue;
    const own = new Set((d.evidence || []).map(normId).filter(Boolean));
    const hit = shared(own);
    for (const [row, ids] of hit) push(l.key, row, d, ids, 'evidence', 'lenses.dictionary');
    const cited = [...own].filter(id => byCheck.has(id));
    const tr = textRows(d.atlas);
    for (const row of tr) if (!hit.has(row)) push(l.key, row, d, cited, 'text', 'lenses.dictionary');
    if (hit.size || tr.length) dictLinked++;
  }

  // 2. the specialist readings whose field has a lens: the checks their note and atlas element name (single checks first, whole
  //    scripts only when no single check links a row), else their atlas phrase
  const unmapped = new Map();
  let readingsMapped = 0, readingsLinked = 0;
  for (const x of readings) {
    const lens = FIELD_LENS[x.field];
    if (!lens) { unmapped.set(x.field, (unmapped.get(x.field) || 0) + 1); continue; }
    readingsMapped++;
    if (!String(x.field_term ?? '').trim()) continue;
    const e = { atlas: x.atlas_element, term: x.field_term, match: x.grade_or_status };
    const { ids, scripts } = noteIds(x.note, vocab);
    for (const id of noteIds(x.atlas_element, vocab).ids) ids.add(id); // the single checks the atlas element names: "top-blade square (core·B14)"
    let hit = shared(ids);
    if (!hit.size) hit = shared(scripts);
    for (const [row, sh] of hit) push(lens, row, e, sh, 'evidence', 'readings');
    const cited = [...ids, ...scripts].filter(id => byCheck.has(id));
    const tr = textRows(x.atlas_element);
    for (const row of tr) if (!hit.has(row)) push(lens, row, e, cited, 'text', 'readings');
    if (hit.size || tr.length) readingsLinked++;
  }

  // 3. one record per (lens, row, term): a link by evidence before one by text, the registry's entry before the reading;
  //    the kept record carries the check ids of every link of its kind to that (lens, row, term)
  const rank = r => (r.via === 'evidence' ? 0 : 2) + (r.source === 'lenses.dictionary' ? 0 : 1);
  const byKey = new Map();
  for (const r of out) {
    const k = `${r.lens}\u0001${r.row}\u0001${r.term}`;
    if (!byKey.has(k)) byKey.set(k, []);
    byKey.get(k).push(r);
  }
  const records = [];
  for (const g of byKey.values()) {
    const b = g.reduce((x, y) => (rank(y) < rank(x) ? y : x));
    records.push({ ...b, evidence: [...new Set(g.filter(r => r.via === b.via).flatMap(r => r.evidence))].sort() });
  }
  records.sort((a, b) => cmp(a.lens, b.lens) || cmp(a.row, b.row) || cmp(a.atlas, b.atlas) || cmp(a.term, b.term) || cmp(a.via, b.via) || cmp(a.source, b.source));

  const byLens = {};
  for (const l of lenses) byLens[l.key] = 0;
  for (const r of records) byLens[r.lens] += 1;
  const counts = {
    records: records.length,
    byLens,
    rowsWithReadings: new Set(records.map(r => r.row)).size,
    viaEvidence: records.filter(r => r.via === 'evidence').length,
    viaText: records.filter(r => r.via === 'text').length,
    unmappedFields: [...unmapped.keys()].sort(cmp),
  };
  const detail = {
    dictEntries, dictLinked, readings: readings.length, readingsMapped, readingsLinked,
    unmapped: [...unmapped.entries()].sort((a, b) => cmp(a[0], b[0])),
    bySource: { 'lenses.dictionary': records.filter(r => r.source === 'lenses.dictionary').length, readings: records.filter(r => r.source === 'readings').length },
  };
  return { records, counts, detail };
}

// ------------------------------------------------------------------ the command
function main() {
  const J = n => JSON.parse(fs.readFileSync(path.join(CONTENT, n), 'utf8'));
  const { records, counts, detail } = deriveLensReadings({ rows: J('rows.json'), texts: J('texts.json'), lenses: J('lenses.json'), readings: J('readings.json'), checks: J('checks.json') });
  fs.writeFileSync(path.join(CONTENT, 'lens_readings.json'), JSON.stringify(records, null, 1));
  const cf = path.join(CONTENT, 'MIGRATION_COUNTS.json');
  const prev = fs.existsSync(cf) ? JSON.parse(fs.readFileSync(cf, 'utf8')) : {};
  prev.lensReadings = counts;
  fs.writeFileSync(cf, JSON.stringify(prev, null, 1));
  const lensList = Object.entries(counts.byLens).filter(([, n]) => n).map(([k, n]) => `${k} ${n}`).join(', ');
  console.log(`lens_readings: ${counts.records} records on ${counts.rowsWithReadings} rows (via evidence ${counts.viaEvidence}, via text ${counts.viaText}); from the dictionaries ${detail.bySource['lenses.dictionary']}, from the readings ${detail.bySource.readings}`);
  console.log(`  by lens: ${lensList}`);
  console.log(`  dictionary entries linked ${detail.dictLinked} of ${detail.dictEntries}; readings linked ${detail.readingsLinked} of ${detail.readingsMapped} mapped (${detail.readings} in all)`);
  for (const [f, n] of detail.unmapped) console.log(`  unmapped field, left out: "${f}" (${n} readings)`);
  console.log('  wrote content/lens_readings.json and the lensReadings counts in content/MIGRATION_COUNTS.json');
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main();
