#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// figures_from_v15.mjs — content/figures.json seeds (07_ENGINES_FIGURES.md §3) with their interactive entries (interface 13), engines/storedParts.js (the stored
// blocks the figures read, engines/storedPaths.js) and engines/MANIFEST.json (written only when missing). Run from the repository root.
import fs from 'node:fs'; import path from 'node:path';
const OUT = path.resolve('content'); const W = (n, d) => fs.writeFileSync(path.join(OUT, n), JSON.stringify(d, null, 1));
// interface 13: the interactive entries — each is the port of a control the v15 widget had (never a new one): the param the figure reads (FigureFrame passes figures.json
// params; the figure's control carries data-param = param), the kind of control, its values or range, the default, the levels where it is shown (a figure that is
// not drawn at learner level lists research only; no slider at learner level), and the v15 control it ports. Animation controls (play, step, reset, speed) are not
// entries: they are the paused-start control of 07 §3 (f), marked data-play. tests/figures.render.test.mjs checks every figure's controls against this list.
const RL = ['research', 'learner'], R = ['research'];
const I = (param, control, valuesOrRange, def, levels, from) => ({ param, control, ...(Array.isArray(valuesOrRange) && valuesOrRange.length === 3 && valuesOrRange.every(x => typeof x === 'number') && control === 'slider' ? { range: valuesOrRange } : { values: valuesOrRange }), default: def, levels, from });
const INTERACTIVE = {
  'lattice': [I('cell', 'pick', 'Cl(p,q), p + q <= 8 (sets p and q)', [1, 3], RL, 'LabelsWidgets.jsx CellLattice: click a cell, or choose it in the list')],
  'clock-wheel': [I('p', 'stepper', '0 … nMax − q', 1, R, 'LabelsWidgets.jsx CellLattice (wheel): p'), I('q', 'stepper', '0 … nMax − p', 3, R, 'LabelsWidgets.jsx CellLattice (wheel): q')],
  'four-views': [I('p', 'stepper', 'p + q + r = 1 … 5', 3, R, 'MaxwellSection.jsx views (genesis_audit_v3): the cell'), I('q', 'stepper', 'p + q + r = 1 … 5', 0, R, 'the cell'), I('r', 'stepper', 'p + q + r = 1 … 5', 0, R, 'the cell'),
    I('a', 'toggle', 'the generators of the label a', 3, R, 'the first label'), I('b', 'toggle', 'the generators of the label b', 5, R, 'the second label')],
  'gauss-sum': [I('p', 'stepper', '0 … 8 − q', 3, R, 'labelsEngine.js Gauss sum: p'), I('q', 'stepper', '0 … 8 − p', 1, R, 'labelsEngine.js Gauss sum: q')],
  'trinity': [I('k', 'slider', [-2, 2, 0.1], 1, R, 'LabelsWidgets.jsx Trinity: the slider k')],
  'bivector-lab': [I('signature', 'chips', ['Cl(4,0)', 'Cl(3,1)', 'Cl(2,2)', 'Cl(1,3)', 'Cl(0,4)'], 2, R, 'LabelsWidgets.jsx BivectorLab: the cell'), I('coef', 'stepper', 'six coefficients −3 … 3, and four presets', [1, 1, 0, 0, 1, 0], R, 'LabelsWidgets.jsx BivectorLab: presets and steppers')],
  'petrie-orthoplex': [I('n', 'chips', [0, 1, 2, 3, 4, 5, 6, 7, 8], 4, R, 'ShapesSection.jsx Petrie: chips n')],
  'comm-graph': [I('p', 'chips', [0, 1, 2, 3, 4], 1, R, 'EquationsSection.jsx Octa: the cell Cl(p, 4 − p)')],
  'dirac-pic': [I('hot', 'pick', 'one of the 8 odd blades (an equation)', null, RL, 'EquationsSection.jsx DiracPic: click an equation')],
  'four-views-maxwell': [I('k', 'chips', [1, 2, 3, 4], 1, RL, 'MaxwellSection.jsx: time chips (here k + d <= 5)'), I('d', 'chips', [1, 2, 3, 4], 3, RL, 'MaxwellSection.jsx: space chips (here k + d <= 5)'),
    I('eq', 'select', 'all, or one equation of the cell as maxwell.json names it', 'all', RL, 'MaxwellSection.jsx: the equation picker'), I('mirror', 'button', '(k, d) → (d, k), when k ≠ d', null, RL, 'MaxwellSection.jsx: go to the mirror')],
  // round 5 (D29): the physics of Calibration 1, per stored cell (engines/maxwellPhysics.js); both drawn at both levels
  'maxwell-equations': [I('k', 'chips', [1, 2, 3, 4], 1, RL, 'MaxwellSection.jsx: time chips (the 15 stored cells, k + d <= 7)'), I('d', 'chips', [1, 2, 3, 4], 3, RL, 'MaxwellSection.jsx: space chips (the 15 stored cells, k + d <= 7)'),
    I('eq', 'pick', 'one equation of the cell, as maxwell.json names it', 'the first of the cell (gauss)', RL, 'MaxwellSection.jsx: the equation chips (Pick an equation)'), I('mirror', 'button', '(k, d) → (d, k), when k ≠ d', null, RL, 'MaxwellSection.jsx: go to the mirror')],
  'maxwell-components': [I('k', 'chips', [1, 2, 3, 4], 1, RL, 'MaxwellSection.jsx: time chips (the 15 stored cells, k + d <= 7)'), I('d', 'chips', [1, 2, 3, 4], 3, RL, 'MaxwellSection.jsx: space chips (the 15 stored cells, k + d <= 7)'),
    I('pick', 'pick', 'a component of F or a source of J of the cell', 'the first component of F (Ex)', RL, 'octavo/leaves/steps.jsx: the piece chips E_x … B_z, here a tap on the grid of F')],
  'mirrors-cube': [I('n', 'chips', [2, 3, 4, 5, 6, 7, 8], 4, RL, 'MirrorsSection.jsx: chips n'), I('corner', 'pick', 'a corner of the n-cube, n <= 5', '2^n − 1', RL, 'MirrorsSection.jsx CubePic: pick a corner'),
    I('evenOnly', 'toggle', [false, true], false, RL, 'MirrorsSection.jsx: demicube only')],
  'spin-four-i': [I('a', 'chips', [-1, 0, 1], 1, RL, 'SpinWidgets.jsx ThreeI: chips a'), I('b', 'chips', [-1, 0, 1], 1, RL, 'SpinWidgets.jsx ThreeI: chips b')],
  'cube-category': [I('p', 'stepper', 'p + q + r = 1 … 5', 3, R, 'CategoryWidgets.jsx CW1 (SigPicker): p'), I('q', 'stepper', 'p + q + r = 1 … 5', 0, R, 'CW1: q'), I('r', 'stepper', 'p + q + r = 1 … 5', 1, R, 'CW1: r'),
    I('preset', 'chips', ['3,0,1', '3,0,0', '1,1,0', '0,0,2'], '3,0,1', R, 'CW1: presets')],
  'sign-flux': [I('signs', 'toggle', 'the 12 edge signs: flip one, the rule\'s signs, all +1, flip the edges at a corner', 'the rule\'s signs', R, 'CategoryWidgets.jsx CW6: edges and buttons'), I('corner', 'pick', 'a corner of the 3-cube', null, R, 'CategoryWidgets.jsx CW6: pick a corner')],
  'five-bits': [I('flipped', 'toggle', [false, true], false, RL, 'BaezWidgets.jsx BW1: flip all five'), I('picks', 'pick', 'labels 0 … 31; all; clear', [], RL, 'BaezWidgets.jsx BW1: the label dots, all, clear')],
  'tennis-racket': [I('I', 'slider', [1, 10, 0.5], [5, 3, 1], R, 'ForqueSection.jsx Racket: the three inertia sliders')],
  'spring-cube': [I('n', 'chips', [2, 3, 4], 3, RL, 'SpringWidgets.jsx CubeSprings: chips n'), I('view', 'chips', ['mode', 'pluck'], 'mode', RL, 'CubeSprings: mode or pluck'),
    I('s', 'toggle', 'the bits of the mode (never all 0)', 1, RL, 'CubeSprings: the bits'), I('v', 'pick', 'the mass let go', 0, RL, 'CubeSprings: click a vertex (pluck)'), I('t', 'slider', [0, 100, 1], 0, R, 'CubeSprings: the time slider (t = value / 10)')],
  'gosset-plane': [I('n', 'chips', [6, 7, 8], 8, RL, 'GossetSection.jsx Plane: chips E6, E7, E8')],
  'zonogon': [I('n', 'chips', [3, 4, 5, 6, 7, 8], 5, RL, 'ShapesSection.jsx Zonogon: chips n')],
  'e8-ladder': [I('step', 'chips', [8, 7, 6, 5, 4], 7, RL, 'BaezWidgets.jsx BW3: the steps of the ladder'), I('links', 'toggle', [false, true], false, R, 'BaezWidgets.jsx BW3: the links')],
  'kepler-trio': [I('E', 'slider', [-0.4, 0.4, 0.1], -0.3, R, 'BaezWidgets.jsx BW4: the energy slider'), I('preset', 'chips', [1, 0, -1], 1, RL, 'BaezWidgets.jsx BW4: the three orbits')],
  // release 2.2 (the physics wave): extra-generator (PR2), riemann-split (GG3) and ladders (FU6) are drawn at learner level too, in words, with their chips
  'extra-generator': [I('kind', 'chips', ['space', 'lorentz'], 'lorentz', RL, 'ProjectiveSection.jsx LadderPic: the base'), I('s', 'chips', [0, -1, 1], -1, RL, 'LadderPic: e² = s'), I('n', 'chips', [2, 3, 4, 5, 6], 4, RL, 'LadderPic: n')],
  'rain': [I('rho', 'slider', [0.3, 3, 0.05], 0.6, R, 'LabelsWidgets.jsx Horizon: the radius slider'), I('rev', 'toggle', [false, true], false, RL, 'LabelsWidgets.jsx Horizon: reverse')],
  'riemann-split': [I('n', 'chips', [2, 3, 4, 5, 6, 7, 8], 4, RL, 'LabelsWidgets.jsx Curvature: chips n')],
  'golay-ring': [I('points', 'pick', 'up to 5 of the 24 points; clear; show an octad', [], R, 'LabelsWidgets.jsx GolayCard: the points')],
  'o-q-f2': [I('n', 'chips', [2, 3, 4, 5, 6, 7, 8], 8, R, 'LabelsWidgets.jsx Rails: chips n')],
  'ladders': [I('k', 'chips', [0, 1, 2, 3, 4], 0, RL, 'FureyWidgets.jsx Cascade: the reflections switched on (v15\'s slider, as chips at both levels)')],
  'furey-board': [I('doubled', 'chips', [false, true], false, RL, 'FureyWidgets2.jsx Board: one or both labels'), I('view', 'chips', ['type', 'first'], 'type', RL, 'Board: the shading'), I('cell', 'select', 'a cell of the 5 × 5 board', '1,2', R, 'Board: a cell')],
  'dictionary-boards': [I('entry', 'select', 'a state, a root or a diagonal element of dictionary.json', 'uL1', RL, 'DictionarySection.jsx: the entry')],
  'null-figures': [I('case', 'chips', ['schw', 'rn_out', 'rn_in', 'extremal', 'areal'], 'schw', RL, 'NullWidgets.jsx Cone: the horizon'), I('probe', 'slider', 'the distance to the horizon, |probe| <= PROBE; "on the horizon"', 0, R, 'NullWidgets.jsx Cone: the probe'),
    I('n', 'chips', 'nullEngine.js NS', 4, R, 'NullWidgets.jsx Ladder: chips n'),
    // D37 (the Atlas method): the switch from the top of the ladder of the stored rungs (n = 6 first, then one rung down a press); a control v15 did not have
    I('top', 'button', 'from the top: n = 6, then one rung down a press', false, R, 'D37')],
  'pga-orbits': [I('which', 'chips', ['moon', 'planets'], 'moon', RL, 'RigidWidgets2.jsx Orbits: the bodies'), I('integ', 'chips', ['rk4', 'euler'], 'rk4', R, 'Orbits: the method'),
    I('dt', 'slider', 'Moon: 1000 … 120000 s, step 1000 (default 5000); planets: 1 … 120 h (default 4 h)', 5000, R, 'Orbits: the time step'), I('vf', 'slider', [60, 140, 1], 100, R, 'Orbits: the starting speed of the Moon, % of the circular one'),
    I('rad', 'chips', ['sqrt', 'lin'], 'sqrt', R, 'Orbits: the radius scale of the planets')],
  'hang-it': [I('n', 'chips', [1, 2, 3, 4], 3, RL, 'RigidWidgets2.jsx HangIt: the body'), I('nb', 'chips', [1, 2, 3], 1, RL, 'HangIt: the chain'), I('top', 'toggle', 'the bits of the top corner', 7, R, 'HangIt: the corner hung'),
    I('k', 'slider', [2, 30, 1], 8, R, 'HangIt: stiffness'), I('g', 'slider', [0, 60, 1], 30, R, 'HangIt: gravity (g = value / 10)'), I('alpha', 'slider', [0, 20, 1], 0, R, 'HangIt: damping (α = value / 20)'),
    I('tilt', 'slider', [0, 85, 1], 35, R, 'HangIt: tilt'), I('view', 'slider', [-60, 60, 1], 25, R, 'HangIt: view (n >= 3)')],
  'free-top': [I('preset', 'chips', ['paper', 'repo', 'sym'], 'paper', RL, 'RigidWidgets2.jsx FreeTop: the box'), I('I', 'slider', [5, 100, 1], 'the box', R, 'FreeTop: the three inertias'),
    I('axis', 'chips', [0, 1, 2], 2, RL, 'FreeTop: spin about'), I('eps', 'slider', [1, 80, 1], 15, R, 'FreeTop: push (value / 100)'), I('az', 'slider', [0, 359, 1], 30, R, 'FreeTop: turn')],
  'one-table': [I('n', 'chips', [2, 3], 2, R, 'SchullerWidgets.jsx SW2: the number of generators'), I('sq', 'chips', 'the square of each generator, +1, −1 or 0; presets all 0, all +1, all −1', [0, 0], R, 'SW2: the squares and the presets')],
  'bands': [I('mode', 'chips', ['comb', 'g5'], 'comb', R, 'SchullerWidgets.jsx SW5: the mode (the exact SL(2,Z) mode is not drawn)'), I('g', 'slider', [-4, 4, 0.5], 2, R, 'SW5: the kick'), I('l', 'slider', [0.5, 2, 0.25], 1, R, 'SW5: the spacing'),
    I('E', 'slider', 'the energy window of the mode, step 0.25', 8, R, 'SW5: the energy')],
  'signed-network': [I('n', 'chips', [2, 3, 4, 5], 3, R, 'SpringWidgets.jsx Spectra: chips n')],
  'charges': [I('preset', 'chips', ['circle', 'hyper', 'crossed', 'spiral', 'orbit', 'wave'], 'circle', RL, 'ChargesWidget.jsx: the six situations'),
    ...['B', 'E', 'rho', 'qm', 'v0', 'kappa', 'a'].map(q => I(q, 'slider', 'per situation, as engines/chargeEngine.js SPEC', 'chargeEngine.js defaults', R, `ChargesWidget.jsx: the slider ${q}`)),
    I('frame', 'chips', ['lab', 'avg'], 'lab', R, 'ChargesWidget.jsx: the frame of the wave'),
    // D37 (the Atlas method; author question A42, D49): the switch from the top of the ladder of the stored worlds Cl(1,2), Cl(1,3), Cl(1,4), each lower world
    // drawn as the restriction of Cl(1,4); a control v15 did not have
    I('top', 'toggle', [false, true], false, RL, 'D37')],
  'matrix-heatmap': [I('column', 'select', 'all, or one of the 22 columns', '', R, 'LensMatrix.jsx: the column select'), I('grades', 'chips', 'any of E, S, A', [], R, 'LensMatrix.jsx: the grade chips'), I('row', 'pick', 'a row of the matrix (its cells and notes)', null, R, 'LensMatrix.jsx: a row')],
  'schuller-chain': [I('stone', 'pick', [1, 2, 3, 4, 5, 6, 7], null, RL, 'SchullerWidgets.jsx SW1: the stones'), I('grid', 'toggle', [false, true], false, RL, 'SchullerWidgets.jsx SW1: the grid of stone 3')],
};
// D31 (round 5, wave 2): the seeds that say size "wide": as the hero's figure, on screens of 1100 px and more, the figure takes the full content width under the
// hero statement, its controls under the drawing (src/components/Hero.jsx); every other hero keeps the narrow right column. A seed without the field is narrow.
const WIDE = new Set(['maxwell-equations', 'maxwell-components', 'four-views-maxwell', 'four-views', 'lattice', 'dirac-pic', 'einstein-form-identity', 'kerr-schild-f', 'matrix-heatmap',
  'cube-category', 'spring-cube', 'schuller-chain', 'e8-ladder', 'gosset-plane']);
const F = (id, engine, captionRow, lenses, learner, src, order) => ({ id, engine, params: {}, inputs: [], captionRow, statesRows: captionRow ? [captionRow] : [], lenses, learner, ...(WIDE.has(id) ? { size: 'wide' } : {}), interactive: INTERACTIVE[id] || [], portFrom: src, portOrder: order });
const SH = ['clifford', 'simplex', 'cube', 'prime'];
const figures = [
  F('four-views', 'engines/labels.js#views', 'PAG-002', SH, true, 'MaxwellSection.jsx (ViewClifford/Simplex/CubeBig/PrimeGrid) + genesis_audit_v3.js', 1),
  // round 5 (D29): maxwell-equations is listed before four-views-maxwell, so that it is the hero's figure of light (the first figure captioned by the hero row
  // EQN-006); four-views-maxwell then draws in the section that holds EQN-006. maxwell-components is captioned by PAG-010 (Maxwell in geometric algebra),
  // a row of the light page: ATL-017, the row it states, has no place on light (its pages are cells and two Explore pages), and a figure is placed by its caption row.
  F('maxwell-equations', 'engines/maxwellPhysics.js#cellPhysics', 'EQN-006', [], true, 'MaxwellSection.jsx (the equation picker, the ladders, the conventions, the checks, the mirror)', 1),
  { ...F('maxwell-components', 'engines/maxwellPhysics.js#equationsOf', 'PAG-010', ['clifford', 'simplex', 'cube', 'prime', 'bits', 'primes'], true, 'MaxwellSection.jsx (the components by role) + octavo/leaves/steps.jsx (the pieces)', 1), statesRows: ['PAG-010', 'ATL-017', 'EQN-006'] },
  F('four-views-maxwell', 'engines/labels.js#maxwellViews', 'EQN-006', SH, true, 'MaxwellSection.jsx', 1),
  F('lattice', 'engines/labels.js#cellLattice', 'LAB-001', [...SH, 'cat', 'sol', 'alg'], true, 'LabelsWidgets.jsx CellLattice', 2),
  F('clock-wheel', 'engines/labels.js#clockWheel', 'LAB-017', ['alg', 'geo', 'top', 'cat', 'sol'], true, 'LabelsWidgets.jsx CellLattice (wheel)', 2),
  F('gauss-sum', 'engines/labels.js#gaussSum', 'LAB-017', ['alg', 'cat'], false, 'labelsEngine.js', 2),
  // A42 (D49): the lens picker of D37 (Clifford, simplex, cube, demicube, prime labels) redraws F of every stored world; the v15 tags hestenes and fld stay
  F('charges', 'engines/charges.js#simulate', 'PAG-009', ['clifford', 'simplex', 'cube', 'demicube', 'prime', 'hestenes', 'fld'], true, 'ChargesWidget.jsx', 3),
  F('pga-orbits', 'engines/pga.js#orbits', 'RIG-001', ['pga'], true, 'RigidWidgets2.jsx Orbits', 4),
  F('hang-it', 'engines/pga.js#hangIt', 'RIG-002', ['pga'], true, 'RigidWidgets2.jsx HangIt', 4),
  F('free-top', 'engines/pga.js#freeTop', 'RIG-001', ['pga'], true, 'RigidWidgets2.jsx FreeTop', 4),
  F('furey-board', 'engines/furey.js#board', 'FUR-001', ['furey', 'str', 'alg'], true, 'DictionarySection.jsx + FureyWidgets2.jsx Board', 5),
  F('dictionary-boards', 'engines/furey.js#dictionary', 'FUR-001', ['furey', ...SH], true, 'DictionarySection.jsx Cube/Simplex/PrimeGrid/PeirceGraph/Fano/Ladder', 5),
  F('null-figures', 'engines/null.js#figures', 'NUL-001', [...SH, 'hbhl', 'hestenes'], true, 'NullWidgets.jsx Cone/Neck/Criterion/Kerr/Ladder (LensChips)', 6),
  F('e8-ladder', 'engines/baez.js#e8Ladder', 'LNB-003', ['baez', 'comb', 'alg'], true, 'BaezWidgets.jsx BW3', 7),
  F('gosset-plane', 'engines/labels.js#gossetPlane', 'GOS-001', ['gosset', 'comb'], true, 'GossetSection.jsx Plane', 7),
  F('petrie-orthoplex', 'engines/labels.js#petrie', 'SHP-001', ['orthoplex'], true, 'ShapesSection.jsx Petrie', 7),
  F('zonogon', 'engines/labels.js#zonogon', 'SHP-002', ['demicube', 'cube'], true, 'ShapesSection.jsx Zonogon', 7),
  F('dirac-pic', 'engines/spin.js#diracPic', 'EQN-008', ['hestenes', 'cube'], true, 'EquationsSection.jsx DiracPic', 8),
  F('comm-graph', 'engines/labels.js#commGraph', 'EQN-003', [...SH], true, 'EquationsSection.jsx Octa', 8),
  F('cube-category', 'engines/category.js#cube', 'LNC-001', ['cat', 'cube', 'alg'], false, 'CategoryWidgets.jsx CW1/CW6', 9),
  F('sign-flux', 'engines/category.js#signGauges', 'LNC-001', ['cat', 'alg'], false, 'CategoryWidgets.jsx CW6', 9),
  F('matrix-heatmap', null, null, [], false, 'LensMatrix.jsx (prototype in atlas_work/viewer)', 10),
  F('trinity', 'engines/labels.js#trinity', 'LAB-003', ['geo', 'fld'], true, 'LabelsWidgets.jsx Trinity', 11),
  F('bivector-lab', 'engines/labels.js#bivectorLab', 'LAB-004', ['geo'], false, 'LabelsWidgets.jsx BivectorLab', 11),
  F('spin-four-i', 'engines/spin.js#threeI', 'SPN-001', ['roelfs', 'hestenes'], true, 'SpinWidgets.jsx ThreeI', 11),
  F('spring-cube', 'engines/spring.js#modes', 'SPR-001', ['sol', 'cube'], true, 'SpringWidgets.jsx CubeSprings/Spectra', 11),
  F('signed-network', 'engines/spring.js#signed', 'SPR-002', ['sol'], false, 'SpringWidgets.jsx LabelsAsModes', 11),
  F('schuller-chain', 'engines/schuller.js#chain', 'LNS-001', ['schuller'], true, 'SchullerWidgets.jsx SW1', 11),
  F('one-table', 'engines/schuller.js#oneTable', 'LNS-001', ['schuller', 'alg'], false, 'SchullerWidgets.jsx SW2', 11),
  F('bands', 'engines/schuller.js#floquet', 'SPR-003', ['schuller', 'sol'], true, 'SchullerWidgets.jsx SW5', 11),
  F('five-bits', 'engines/baez.js#fiveBits', 'LNB-001', ['baez', 'str'], true, 'BaezWidgets.jsx BW1', 11),
  F('kepler-trio', 'engines/baez.js#kepler', 'LNB-009', ['baez', 'geo'], true, 'BaezWidgets.jsx BW4', 11),
  F('mirrors-cube', 'engines/labels.js#mirrors', 'MIR-001', ['cube', 'geo'], true, 'MirrorsSection.jsx CubePic/TwoMirrors', 11),
  F('extra-generator', 'engines/labels.js#extraGenerator', 'PRJ-002', ['geo', 'fld'], true, 'ProjectiveSection.jsx LadderPic/NullPic', 11),
  F('rain', 'engines/labels.js#rain', 'LAB-005', ['hestenes', 'fld'], true, 'LabelsWidgets.jsx Horizon', 11),
  F('riemann-split', 'engines/labels.js#curvature', 'LAB-006', ['geo', 'fld'], true, 'LabelsWidgets.jsx Curvature', 11),
  F('tennis-racket', 'engines/forque.js#racket', 'FRQ-001', ['pga'], true, 'ForqueSection.jsx', 11),
  F('ladders', 'engines/furey.js#ladders', 'FUR-002', ['furey', 'alg'], true, 'FureyWidgets.jsx Cascade', 11),
  F('golay-ring', 'engines/labels.js#golay', 'LAB-013', ['comb', 'alg'], false, 'LabelsWidgets.jsx GolayCard', 11),
  F('o-q-f2', 'engines/labels.js#orders', 'LAB-009', ['comb', 'alg'], false, 'LabelsWidgets.jsx Rails', 11),
  F('einstein-form-identity', null, 'GRV-010', ['fld', 'geo'], false, 'new: from selfcheck/gravity.json', 12),
  F('kerr-schild-f', null, 'GRV-012', ['fld', 'geo'], true, 'new: from c1_birkhoff results', 12),
  F('horizon-first-law', null, 'LAB-008', ['fld'], false, 'new: from f2_first_law / f4_komar_kn results', 12),
  F('connection-forms', null, 'GRV-003', ['fld', 'geo'], false, 'new: the engine tables of gravity_selfcheck.py', 12),
  F('bianchi-check', null, 'GRV-001', ['fld'], false, 'new: residual degrees and bounds from gravity.json', 12),
];
W('figures.json', figures);
const ENG = [['labelsEngine.js', 'labels.js'], ['categoryEngine.js', 'category.js'], ['baezEngine.js', 'baez.js'], ['schullerEngine.js', 'schuller.js'], ['fureyPapersEngine.js', 'furey.js'], ['pgaEngine.js', 'pga.js'], ['chargeEngine.js', 'charges.js'], ['spinEngine.js', 'spin.js'], ['springEngine.js', 'spring.js'], ['nullEngine.js', 'null.js'], ['forquePhysics.js', 'forque.js'], ['productKernels.js', 'bench/productKernels.js'], ['benchKernels.js', 'bench/benchKernels.js'], ['mathTextCore.js', '(dropped: KaTeX)'], ['ganjaFixtureData.js', 'content/data/ganja_fixture.json']];
if (!fs.existsSync(path.resolve('engines/MANIFEST.json'))) fs.writeFileSync(path.resolve('engines/MANIFEST.json'), JSON.stringify(ENG.map(([from, to]) => ({ from: 'v15/' + from, to, kernel: 'engines/bitrule.js (to write; T3.1)', pythonTwin: null, storedJson: null, status: 'copied, not yet re-pointed' })), null, 1));
// engines/storedParts.js: the blocks of the stored results that the figures read (engines/storedPaths.js PARTS), copied as they are; tests/engines.test.mjs compares
{
  const { SOURCES, PARTS, fileOf, partsOf } = await import(new URL('../../engines/storedPaths.js', import.meta.url).href);
  const parts = Object.fromEntries(Object.keys(PARTS).map(name => [name, partsOf(name, JSON.parse(fs.readFileSync(path.resolve(fileOf(name)), 'utf8')))]));
  const head = ['// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', '// Required Notice: Copyright (c) 2026 the Cascade Atlas authors',
    '// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)',
    '// engines/storedParts.js — written by tools/migrate/figures_from_v15.mjs, not by hand: the blocks of engines/storedPaths.js PARTS, copied as they are from',
    `// ${Object.values(SOURCES).map(s => s.split(' ')[0].replace('checks/selfcheck/', '')).join(', ')} (checks/selfcheck/). tests/engines.test.mjs compares each block with its file.`];
  fs.writeFileSync(path.resolve('engines/storedParts.js'), head.join('\n') + '\nexport default ' + JSON.stringify(parts) + ';\n');
}
const cf = path.join(OUT, 'MIGRATION_COUNTS.json'); const prev = JSON.parse(fs.readFileSync(cf, 'utf8')); prev.figures = { figures: figures.length, engines: ENG.length }; fs.writeFileSync(cf, JSON.stringify(prev, null, 1));
console.log(JSON.stringify(prev.figures));
