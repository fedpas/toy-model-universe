#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// pages_from_v15.mjs — content/pages.json from the V2 site map and the v15 page/tab/anchor structure; re-points every row's shownOn.
// Usage: node tools/migrate/pages_from_v15.mjs   (after rows_from_v15, tables_from_v15, inputs_from_v15)
import fs from 'node:fs'; import path from 'node:path';
const OUT = path.resolve('content'); const J = n => JSON.parse(fs.readFileSync(path.join(OUT, n), 'utf8')); const W = (n, d) => fs.writeFileSync(path.join(OUT, n), JSON.stringify(d, null, 1));
const rows = J('rows.json'), steps = J('steps.json'), needs = J('needs.json'), frames = J('story_frames.json');
const stepById = Object.fromEntries(steps.map(s => [s.id, s]));

// ---- the re-pointing table: v15 (page, tab) → V2 route. Explicit; nothing is guessed per row. --------------------------
const ROUTE = (page, tab, group) => {
  if (page === 'rule') return 'rule';
  if (page === 'atlas') return 'cells';
  if (page === 'conventions') return tab === 'clock' ? 'clock' : 'rule';
  if (page === 'maxwell') return 'light';
  if (page === 'shapes') return 'shapes';
  if (page === 'equations') return tab === 'tally' ? 'logbook' : tab === 'equations' ? 'steps' : 'steps/' + tab;
  if (page === 'lenses') return (tab && tab !== 'lenses') ? 'steps/' + tab : 'lenses';
  if (page === 'furey') return 'matter';
  if (page === 'map') return 'logbook';
  if (page === 'researchers') return 'logbook';
  if (page === 'ask') return 'ask';
  if (group === 'GEN') return 'rule';
  return 'logbook';
};
// section names inside a route: the v15 anchor when it has one, else the tab; a few renames for readability
const SECTION = (route, r) => {
  const s = r.shownOn[0].section;
  if (route === 'logbook') return r.shownOn[0].page === 'map' ? 'map' : r.shownOn[0].page === 'researchers' ? 'researchers' : r.shownOn[0].page === 'equations' ? 'tally' : 'unplaced';
  if (r.group === 'INP') return 'needs';
  if (r.group === 'GEN') return 'ideas';
  if (route === 'rule' && r.shownOn[0].page === 'conventions') return 'conventions';
  if (route === 'cells') return r.group === 'ATL' ? 'cards' : 'type-and-clock';
  if (route === 'clock') return s === 'clock' ? 'clock' : s;
  if (route === 'light') return s.replace(/^maxwell\//, '').replace(/^ns-maxwell-/, '') || 'views';
  return s;
};
const pages = {}; const byRoute = {};
const texts = J('texts.json'); const body = {}; for (const t of texts) if (t.level === 'research' && t.lens === null) body[t.row] = t.body;
const stepByNo = Object.fromEntries(steps.filter(s => s.route.startsWith('steps/')).map(s => [String(s.no), s.route]));
for (const r of rows) {
  const so = r.shownOn[0];
  let finalRoute = ROUTE(so.page, r.tabV15, r.group);
  let section = SECTION(finalRoute, r);
  // the tally rows name their step: "· step 4" → that step's summary; "Calibration 1" → light
  if (r.group === 'EQN' && section === 'tally') {
    const m = /·\s*step (\d+)/.exec(body[r.id] || ''); const cal = /Calibration 1/.test(body[r.id] || '');
    if (m && stepByNo[m[1]]) { finalRoute = stepByNo[m[1]]; section = 'summary'; }
    else if (cal) { finalRoute = 'light'; section = 'summary'; }
    else if (/Majki/.test(body[r.id] || '')) { finalRoute = 'steps/category'; section = 'summary'; }
  }
  if (r.group === 'RSN') { finalRoute = 'logbook'; section = 'notes'; }
  r.shownOn = [{ page: finalRoute, section, order: so.order, role: r.group === 'EQN' && section === 'summary' ? 'result' : so.role }];
  if (r.id === 'PAG-001' || r.id === 'PAG-002') r.shownOn.push({ page: '', section: 'one-rule', order: r.id === 'PAG-001' ? 0 : 1, role: 'result' });
  (byRoute[finalRoute] ||= []).push(r);
  if (r.shownOn.length > 1) (byRoute[''] ||= []).push(r);
}
// pages.json: one entry per route with its sections in order of first appearance; titles from steps.json / story frames
const titleOf = route => {
  if (route.startsWith('steps/')) { const s = stepById[route.slice(6)]; return s ? { phys: s.name, math: s.name, learner: s.nameLearner, stepNo: s.no } : { phys: route, math: route, learner: route }; }
  const T = { '': 'Zero', rule: 'The rule', cells: 'The cells', clock: 'Step 1: the clock and the trinity', light: 'Calibration 1: light (Maxwell)', shapes: 'Shapes', matter: 'Calibration 2: matter (Furey)', lenses: 'Lenses', logbook: 'Logbook', ask: 'Ask', steps: 'The twenty steps', glossary: 'Glossary' };
  const L = { rule: 'One switch rule, drawn four ways', cells: 'The atlas: 25 cards built from the same rule', clock: 'One clock, three kinds of move', light: 'Warm-up 1: do the boxes give back what we know about light?', shapes: 'More shapes: two poles, half a cube, and a famous big shape', matter: 'Warm-up 2: Furey and the families of particles', lenses: 'Ways of looking', logbook: 'The logbook', ask: 'Ask', steps: 'Twenty steps', glossary: 'Our words' };
  return { phys: T[route] || route, math: T[route] || route, learner: L[route] || T[route] || route, stepNo: route === 'clock' ? 1 : null };
};
const NEEDS_ROUTE = tab => tab === 'clock' ? 'clock' : tab === 'conventions' ? 'rule' : tab.startsWith('maxwell') ? 'light' : ['orth', 'demi', 'gosset'].includes(tab) ? 'shapes' : ['dictionary', 'earlier', 'findings', 'threegen', 'help'].includes(tab) ? 'matter' : 'steps/' + tab;
const pageNeeds = {}; for (const [tab, n] of Object.entries(needs)) { const r = NEEDS_ROUTE(tab); (pageNeeds[r] ||= new Set()); for (const x of n.needs) pageNeeds[r].add(NEEDS_ROUTE(x)); }
const HERO = { rule: 'PAG-002', cells: 'LAB-001', clock: 'LAB-017', light: null, shapes: null, matter: 'FUR-001', 'steps/comm': 'EQN-003', 'steps/dirac': 'EQN-008', '': 'PAG-001', 'steps/grav1': 'GRV-003', 'steps/grav2': 'GRV-010', 'steps/projective': 'PRJ-002', 'steps/gauge': 'LAB-005', 'steps/nullsurf': 'NUL-001', 'steps/spring': 'SPR-001', 'steps/rigid': 'RIG-001', 'steps/groups': 'LAB-009', 'steps/baez': 'LNB-001' };
const routes = ['', 'rule', 'cells', 'clock', 'light', 'steps', ...steps.filter(s => s.route.startsWith('steps/')).map(s => s.route), 'shapes', 'matter', 'lenses', 'logbook', 'ask', 'glossary'];
const out = [];
for (const route of routes) {
  const rs = (byRoute[route] || []).sort((a, b) => a.shownOn[0].order - b.shownOn[0].order);
  const secs = []; for (const r of rs) if (!secs.includes(r.shownOn[0].section)) secs.push(r.shownOn[0].section);
  const t = titleOf(route);
  out.push({ route, title: { phys: t.phys, math: t.math, learner: t.learner }, stepNo: t.stepNo || null, needs: [...(pageNeeds[route] || [])].filter(x => x !== route).sort(),
    hero: { row: HERO[route] && rs.some(r => r.id === HERO[route]) ? HERO[route] : (rs.find(r => r.shownOn[0].role === 'result') || {}).id || null, figure: null },
    sections: secs.map(id => ({ id, title: { phys: id, math: id }, query: { 'shownOn.section': id }, rows: rs.filter(r => r.shownOn[0].section === id).length, drawer: ['evidence', 'needs', 'depends', 'readings', 'numbers', 'address'] })),
    connective: {}, learnerFrame: frames.storyLearner && frames.storyLearner.en && frames.storyLearner.en.pages ? (frames.storyLearner.en.pages[{ rule: 'rule', cells: 'atlas', light: 'maxwell', shapes: 'shapes', matter: 'furey', steps: 'equations', lenses: 'lenses', logbook: 'map' }[route]] || null) : null });
}
W('pages.json', out); W('rows.json', rows);
const unplaced = rows.filter(r => r.shownOn[0].section === 'unplaced').map(r => r.id);
const counts = { pages: out.length, routesWithRows: Object.keys(byRoute).length, sections: out.reduce((a, p) => a + p.sections.length, 0), heroes: out.filter(p => p.hero.row).length, unplaced: unplaced.length, unplacedIds: unplaced.slice(0, 20) };
const cf = path.join(OUT, 'MIGRATION_COUNTS.json'); const prev = JSON.parse(fs.readFileSync(cf, 'utf8')); prev.pages = counts; fs.writeFileSync(cf, JSON.stringify(prev, null, 1));
console.log(JSON.stringify(counts, null, 1)); console.log(out.map(p => `${p.route || '/'}: ${p.sections.length} sections, ${p.sections.reduce((a, s) => a + s.rows, 0)} rows, hero ${p.hero.row}, needs ${p.needs.join(',')}`).join('\n'));
