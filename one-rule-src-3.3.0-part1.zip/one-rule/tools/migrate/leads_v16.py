#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""leads_v16.py — the wave-3 leads (v15 → v16 delta): content/leads.json (status, scripts, proposed edits per row), evidence entries on the rows
named by the new scripts, `since: v16` on the rows whose wording changes, and the merge flags the coordinator still owes.
Usage: python3 tools/migrate/leads_v16.py <leads3 root>   (after rows_from_v15 and checks_from_v15)"""
import json, re, sys
from pathlib import Path
LEADS = Path(sys.argv[1]); OUT = Path('content')
rows = json.load(open(OUT / 'rows.json')); byid = {r['id']: r for r in rows}
ship = json.load(open(OUT / 'wave3_ship_notes.json'))
ROW = re.compile(r'\b([A-Z]{2,3}-\d{3})\b')
OUTCOME = {  # from each lead's RESULT.md status lines, read 10 Oct 2026
 'H5LK': 'pass', 'L10b': 'pass with narrower scope; a negative part (no observer reproduces Newton beyond the first covariant derivative)', 'L14': 'pass (force law as input)',
 'L5c': 'pass (both scripts)', 'L7': 'pass (harness only: 13 patches and two probes; no claim row changes)', 'L9bA': 'pass (both scripts)',
 'L9bB': 'pass; a negative part against the brief (the dust and stiff parts are separately conserved only on the rest class or for m = 0)', 'S6': 'pass (both scripts)'}

def proposed_section(text):
    m = re.search(r'^## .*[Pp]roposed wording.*$', text, flags=re.M)
    if not m: return ''
    rest = text[m.end():]
    n = re.search(r'^## ', rest, flags=re.M)
    return rest[:n.start()] if n else rest

def parse_edits(sec, lead):
    items, cur = [], None
    for line in sec.split('\n'):
        head = line.startswith('### ') or line.startswith('**')
        ids = ROW.findall(line) if head else []
        if head and ids:
            if cur: items.append(cur)
            flags = re.search(r'\[([a-z, ]+)\]\s*(?:->|→)\s*\[([a-z, ]+)\]', line)
            cur = {'lead': lead, 'rows': list(dict.fromkeys(ids)), 'heading': line.strip('# ').strip(), 'instruction': '', 'quotes': [], 'flagChange': ({'from': flags.group(1), 'to': flags.group(2)} if flags else None)}
            continue
        if cur is None: continue
        if line.startswith('>'):
            q = line[1:].strip()
            if cur['quotes'] and cur.get('_open'): cur['quotes'][-1] += ' ' + q
            else: cur['quotes'].append(q)
            cur['_open'] = True
        else:
            cur['_open'] = False
            if line.strip(): cur['instruction'] += (' ' if cur['instruction'] else '') + line.strip()
    if cur: items.append(cur)
    for it in items:
        it.pop('_open', None)
        it['today'] = it['quotes'][0] if len(it['quotes']) > 1 else None
        it['proposed'] = it['quotes'][-1] if it['quotes'] else None
        if it['proposed'] and re.match(r'^[A-Z]{2,3}-\d{3}:', it['proposed']): it['proposed'] = None; it['note'] = 'checkedBy texts only (see wave3_ship_notes.json)'
        ins = (it['instruction'] + ' ' + it['heading']).lower()
        it['kind'] = 'append' if 'append' in ins else 'insert' if 'insert' in ins else 'replace-clause' if 'clause' in ins or 'replace that' in ins or 'parenthesis' in ins else 'replace-line' if it['today'] else 'edit'
        it['note'] = 'proposed by a wave-3 lead; a draft until the author accepts it'
    return items

leads, edits = [], []
for d in sorted(p for p in LEADS.iterdir() if p.is_dir() and p.name in OUTCOME):
    text = open(d / 'RESULT.md', errors='replace').read()
    sec = proposed_section(text)
    its = parse_edits(sec, d.name)
    edits += its
    scripts = [n for n, b in ship.items() if b.get('lead') == d.name]
    leads.append({'id': d.name, 'outcome': OUTCOME[d.name], 'scripts': scripts, 'rowsReworded': sorted({r for it in its for r in it['rows']}), 'resultFile': f'leads3/{d.name}/RESULT.md', 'shipNotes': f'leads3/{d.name}/SHIP_NOTES.md'})

# evidence from SHIP_NOTES checkedBy texts; since v16 for rows with an edit
touched = set()
for name, b in ship.items():
    for cb in b.get('checkedBy', []):
        r = byid.get(cb['row'])
        if not r: continue
        ev = {'check': b.get('step') or name.replace('.py', ''), 'script': f'checks/selfcheck/gravity/{name}', 'mode': 'ran', 'text': cb['text'], 'since': 'v16'}
        if not any(e.get('script') == ev['script'] for e in r['evidence']): r['evidence'].append(ev)
        touched.add(r['id'])
reworded = sorted({r for it in edits if it['proposed'] for r in it['rows']})
for rid in reworded:
    if rid in byid: byid[rid]['since'] = 'v16'
merge_needed = [rid for rid in reworded if sum(1 for it in edits if rid in it['rows'] and it['proposed']) > 1 and len({it['lead'] for it in edits if rid in it['rows']}) > 1]
for rid in merge_needed: byid[rid]['mergeNeeded'] = True
json.dump(rows, open(OUT / 'rows.json', 'w'), ensure_ascii=False, indent=1)
json.dump({'leads': leads, 'edits': edits, 'mergeNeeded': merge_needed, 'coordinatorNotes': ['the 13 L7 patches (d_sign_probe) and the README section "Engine faults M1 to M8" are to be applied by the author to checks/selfcheck/gravity/', 'RIG-002 and GRV-011 receive text from two leads each and need one wording']}, open(OUT / 'leads.json', 'w'), ensure_ascii=False, indent=1)
counts = {'leads': len(leads), 'edits': len(edits), 'editsWithProposedText': sum(1 for e in edits if e['proposed']), 'rowsReworded': len(reworded), 'rowsSinceV16': sum(1 for r in rows if r['since'] == 'v16'), 'rowsGainingEvidence': len(touched), 'mergeNeeded': merge_needed}
cf = OUT / 'MIGRATION_COUNTS.json'; prev = json.load(open(cf)); prev['leads'] = counts; json.dump(prev, open(cf, 'w'), indent=1)
print(json.dumps(counts, indent=1))
