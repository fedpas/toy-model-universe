#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""checks_from_v15.py — content/checks.json (every check script, with ids and statements) and content/check_runs.json (the shipped runs).
Usage: python3 tools/migrate/checks_from_v15.py <v15 root> <atlas_work root> <leads3 root>
Sources: atlas_work/matrix/checks.json (the 236-entry inventory), checks/selfcheck/gravity/logs/SUMMARY.txt (the gravity run),
the 14 wave-3 scripts' logs and SHIP_NOTES.md blocks. Scripts are referenced by their path under checks/."""
import json, re, sys, os
from pathlib import Path
V15, WORK, LEADS = map(Path, sys.argv[1:4])
OUT = Path('content'); CK = Path('checks')
inv = json.load(open(WORK / 'matrix' / 'checks.json'))

def script_path(p):
    p = (p or '').split()[0].split('(')[0]
    if not p: return None
    if p.startswith(('selfcheck/', 'researchers_checks/', 'orthoplex/', 'reports/', 'replication/', 'label_bench')): return 'checks/' + p
    return 'checks/' + p

checks, runs = [], []
for e in inv:
    sp = script_path(e.get('script_path'))
    raw = e.get('check_id_prefix_or_ids') or []
    ids = e.get('checks') or ([{'id': i, 'statement': ''} for i in raw] if isinstance(raw, list) else [])   # a string here is a note (a prefix or a sentence), not a list of ids
    ids_note = raw if isinstance(raw, str) else None
    checks.append({'id': (sp or e.get('family')).replace('checks/', ''), 'family': e.get('family'), 'script': sp, 'ids': ids, 'idsNote': ids_note,
                   'what': e.get('what_it_computes'), 'method': e.get('method'), 'independentRoute': e.get('independent_route'), 'controls': e.get('controls'),
                   'deps': e.get('dependencies'), 'storedResult': e.get('stored_result_file'), 'log': e.get('log_file'), 'rowsNaming': e.get('claims_referencing_it') or [], 'notes': e.get('notes'), 'since': 'v15'})
    st = str(e.get('status_in_shipped_log') or '')
    runs.append({'script': sp, 'date': '2026-10-07', 'machine': 'the author\'s shipped run', 'passed': bool(re.search(r'pass', st, re.I)) and not re.search(r'fail', st, re.I), 'status': st, 'seconds': e.get('runtime_s'), 'ok': None, 'fail': None, 'lastLine': None, 'source': 'shipped log / inventory'})

# gravity SUMMARY.txt: exact ok/FAIL/seconds/last line per row
summ = CK / 'selfcheck' / 'gravity' / 'logs' / 'SUMMARY.txt'
if summ.exists():
    for line in open(summ):
        m = re.match(r'^(\S+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(.*)$', line.rstrip())
        if not m: continue
        name, rc, sec, ok, fail, last = m.groups()
        sp = f'checks/selfcheck/gravity/{name}.py'
        runs.append({'script': sp, 'date': '2026-10-07', 'machine': 'the author\'s shipped run (SUMMARY.txt)', 'passed': rc == '0' and fail == '0', 'status': 'pass' if rc == '0' and fail == '0' else 'fail', 'seconds': int(sec), 'ok': int(ok), 'fail': int(fail), 'lastLine': last.strip(), 'source': 'selfcheck/gravity/logs/SUMMARY.txt'})

# wave-3 scripts: SHIP_NOTES blocks + logs
def parse_ship_notes(text):
    blocks = re.split(r'^## (?:\d+\. |Script \d+: )?`?(?:selfcheck/gravity/)?([a-z0-9_]+\.py)`?\s*$', text, flags=re.M)
    out = {}
    for i in range(1, len(blocks), 2):
        name, body = blocks[i], blocks[i + 1]
        g = lambda k: (re.search(r'\*\*' + k + r':?\*\*:?\s*(.+)', body) or [None, ''])[1].strip()
        step = (re.search(r'\*\*Step id:\*\*\s*`([^`]+)`', body) or [None, ''])[1]
        okm = re.search(r'\*\*(\d+) ok, (\d+) FAIL\*\*', body)
        rows = re.findall(r'\b([A-Z]{2,3}-\d{3})\b', g('Rows that should name it'))
        cb = re.findall(r'^\s*-\s*([A-Z]{2,3}-\d{3}):\s*`([^`]+)`', body, flags=re.M)
        out[name] = {'step': step, 'what': g('What it checks'), 'standardRoute': g(r'Standard route \(second source\)') or g('Standard route'), 'rows': rows, 'ok': int(okm.group(1)) if okm else None, 'fail': int(okm.group(2)) if okm else None, 'checkedBy': [{'row': r, 'text': t} for r, t in cb], 'standardRef': g('standardRef')}
    return out
wave = {}
for lead in sorted(p for p in LEADS.iterdir() if p.is_dir() and not p.name.startswith('_') and p.name not in ('briefs', 'tools')):
    sn = lead / 'SHIP_NOTES.md'
    if sn.exists():
        for name, b in parse_ship_notes(open(sn).read()).items():
            b['lead'] = lead.name; wave[name] = b
for name, b in wave.items():
    sp = f'checks/selfcheck/gravity/{name}'
    log = CK / 'selfcheck' / 'gravity' / 'logs' / (name.replace('.py', '.log'))
    ok = fail = None; last = None
    if log.exists():
        L = [l.rstrip() for l in open(log, errors='replace')]
        ok = sum(1 for l in L if re.match(r'^\s*ok\b', l)); fail = sum(1 for l in L if re.match(r'^\s*FAIL\b', l) and not re.match(r'^\s*FAILS\b', l))
        last = L[-1] if L else None
    checks.append({'id': f'selfcheck/gravity/{name}', 'family': 'gravity/wave3', 'script': sp, 'ids': [{'id': b['step'], 'statement': b['what']}] if b['step'] else [], 'what': b['what'], 'method': 'exact fractions on the engine; numpy/scipy standard route', 'independentRoute': b['standardRoute'], 'controls': 'yes (the [ctl] lines of the log)', 'deps': 'numpy, scipy', 'storedResult': None, 'log': f'selfcheck/gravity/logs/{name.replace(".py", ".log")}', 'rowsNaming': b['rows'], 'notes': f"wave-3 lead {b['lead']}; checkedBy texts in content/leads.json", 'since': 'v16'})
    runs.append({'script': sp, 'date': '2026-10-10', 'machine': "the lead's shipped log, re-run identically by the coordinator (_review)", 'passed': (fail == 0) if fail is not None else None, 'status': 'pass' if fail == 0 else 'unknown', 'seconds': None, 'ok': ok if ok is not None else b['ok'], 'fail': fail if fail is not None else b['fail'], 'lastLine': last, 'source': f'leads3/{b["lead"]}/selfcheck/gravity/logs'})
json.dump(checks, open(OUT / 'checks.json', 'w'), ensure_ascii=False, indent=1)
json.dump(runs, open(OUT / 'check_runs.json', 'w'), ensure_ascii=False, indent=1)
json.dump(wave, open(OUT / 'wave3_ship_notes.json', 'w'), ensure_ascii=False, indent=1)
counts = {'checks': len(checks), 'v15Scripts': len(inv), 'wave3Scripts': len(wave), 'runs': len(runs), 'gravityRows': sum(1 for r in runs if r['source'].endswith('SUMMARY.txt')), 'gravityOk': sum(r['ok'] or 0 for r in runs if r['source'].endswith('SUMMARY.txt')), 'gravityFail': sum(r['fail'] or 0 for r in runs if r['source'].endswith('SUMMARY.txt')), 'wave3Ok': sum(r['ok'] or 0 for r in runs if r['source'].startswith('leads3')), 'wave3Fail': sum(r['fail'] or 0 for r in runs if r['source'].startswith('leads3')), 'bridgeIds': sum(len(c['ids']) for c in checks if (c['family'] or '').startswith('bridges'))}
cf = OUT / 'MIGRATION_COUNTS.json'; prev = json.load(open(cf)) if cf.exists() else {}; prev['checks'] = counts; json.dump(prev, open(cf, 'w'), indent=1)
print(json.dumps(counts, indent=1))
