#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// verify_counts.mjs — the numbers of 03_MIGRATION.md §2.9, of the story round (STORY_PLAN §3.5) and of the chains merge of round 14 (docs/round14/STORY_ROUND.md
// §3.3: MIGRATION_COUNTS.json "chainMerge" is the merged table content/chains.json and the spans of texts.json); exit 1 when one differs.
import fs from 'node:fs';
const c = JSON.parse(fs.readFileSync('content/MIGRATION_COUNTS.json', 'utf8'));
const readOr = (f, fb) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fb);
const fy = readOr('content/story/furey.json', []), fureyLayout = Array.isArray(fy) ? 0 : (fy.layout || []).length;
const chains = readOr('content/chains.json', []), spans = readOr('content/texts.json', []).filter(t => t.chain != null).length;
const expect = { 'rows.v15Rows': 789, 'rows.v15Lines': 1045, 'rows.researchTexts': c.rows.rows, 'tables.theorems': 20, 'tables.questions': 34, 'tables.answered': 15, 'tables.sources': 26, 'tables.matrixRows': 131, 'tables.matrixColumns': 22, 'tables.matrixCells': 246, 'tables.lensRows': 80, 'tables.readings': 982, 'tables.mapNodes': 63, 'tables.steps': 23, 'tables.glossary': 16, 'tables.reports': 6, 'tables.analyses': 16, 'inputs.inputs': 94, 'inputs.tabs': 31, 'inputs.kinds': 11, 'inputs.unjoined': 0, 'checks.v15Scripts': 236, 'checks.wave3Scripts': 14, 'checks.checks': 250, 'checks.gravityRows': 69, 'checks.gravityOk': 5569, 'checks.gravityFail': 0, 'checks.wave3Ok': 1342, 'checks.wave3Fail': 0, 'checks.bridgeIds': 348, 'leads.leads': 8, 'leads.rowsReworded': 26, 'pages.unplaced': 1,
  // the story round (docs/STORY_PLAN.md §3.5; tools/migrate/story_from_v15.mjs, tools/merge_story.mjs): the v15 strings and blocks, the layout, the
  // learner texts (pins after the 386 review choices of round 7: same-as and drop move blocks between the classes); the outcomes of the test as sums that a choice of content/story/review.json moves between story, held and proposed but never changes
  'story.stringsWalked': 11625, 'story.proseBlocks': 3169, 'story.uniqueBlocks': 3136, 'story.blocks.rows': 1124, 'story.blocks.tables': 426, 'story.blocks.frames': 114,
  'story.blocks.missing': 1586, 'story.blocks.leftOut': 573, 'story.blocks.labels': 39, 'story.blocks.learnerStrips': 348, 'story.blocks.research': 610, 'story.blocks.findingTitles': 16,
  'story.blocks.story': 571 - ((c.story || {}).blocks || {}).held - ((c.story || {}).blocks || {}).statements, 'story.storyRows': ((c.story || {}).blocks || {}).story + (c.story || {}).learnerOnlyRows + ((c.story || {}).shortLeads || {}).story + ((c.story || {}).tableLeads || {}).story,
  'story.layout': 931, 'story.layoutByRole.learner': 81, 'story.humanLearnerTexts.chapterLearnerLines': 81, 'story.humanLearnerTexts.existingRowsPaired': 63, 'story.ids': 858,   // 12 learner lines are details (readings and questions that stood as key results at learner level; docs/round8/PROOFS_ROUND4.md): their learner texts pair with their rows
  'storyMerge.storyRows': (c.story || {}).storyRows, 'storyMerge.layout': 931 + fureyLayout,   // 931 of layout.json + the layout of content/story/furey.json (56 until 2.14.0: round 7, FUREY; + FUR-006 and CAND-102 of the proofs round, + CAND-049, + FUR-007 to FUR-014 of pass 9a, + FUR-015 to FUR-019 of pass 10a and FUR-020 to FUR-026 of pass 10b, + FUR-027 to FUR-032 of pass 11a and FUR-033 to FUR-037 of pass 11b; round 14 recomposes matter there, B4; + the moves of FUR-041 and FUR-042 to fur-sixteen and fur-labels and their entries on matter/model, pass 12a of round 15)
  // the chains of round 14 (tools/merge_chains.mjs inside tools/merge_story.mjs): the merge's counts are the merged table's
  'chainMerge.chains': chains.length, 'chainMerge.storied': chains.filter(x => x.story && x.story !== 'none').length, 'chainMerge.spans': spans };
let bad = 0;
for (const [k, v] of Object.entries(expect)) { const got = k.split('.').reduce((o, p) => (o || {})[p], c); const ok = got === v; if (!ok) bad++; console.log(`${ok ? 'ok  ' : 'FAIL'} ${k} = ${got} (expected ${v})`); }
console.log(bad ? `${bad} counts differ` : 'all counts as expected'); process.exit(bad ? 1 : 0);
