#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tables_from_v15.mjs — theorems, questions, sources, matrix, lenses (registry + dictionaries), readings, map, steps, analyses, reports, glossary, conventions, ideas
// Usage: node tools/migrate/tables_from_v15.mjs <v15 root> <atlas_work root>
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const [V15, WORK] = process.argv.slice(2); const OUT = path.resolve('content');
const J = f => JSON.parse(fs.readFileSync(f, 'utf8')); const W = (n, d) => fs.writeFileSync(path.join(OUT, n), JSON.stringify(d, null, 1));
const imp = f => import(pathToFileURL(path.join(V15, f)).href);
const M = J(path.join(WORK, 'matrix/atlas_matrix_v1.json'));
const DICT = J(path.join(WORK, 'matrix/analyses_dictionaries.json'));
const steps = await imp('steps.js'); const story = await imp('storyCopy.js'); const conv = await imp('conventionsCopy.js'); const reports = await imp('reportsData.js'); const analyses = await imp('analysesData.js');

// theorems, questions, sources, run
const usedBy = {}; for (const t of M.theorems) for (const r of t.usedFor) (usedBy[t.id] ||= []).push(r);
W('theorems.json', M.theorems.map(t => ({ id: t.id, title: t.title, statement: t.statement, status: t.status, statusNote: t.statusNote, verifier: t.verifier, verifierNote: t.verifierNote, script: 'checks/researchers_checks/' + t.script, checks: t.checks, rowsUsing: t.usedFor, limits: t.limits, remarks: t.remarks.map(r => ({ tags: r.tags, text: r.text })) })));
W('questions.json', M.questions.map(q => ({ id: q.id, topic: q.topic, ask: q.ask, whom: q.whom, checked: q.checked, notChecked: q.notChecked, answer: q.answer, answerTags: q.answerTags, answered: q.answered })));
W('sources.json', M.sources.map(s => ({ ...s, read: !/pointer, source unread|not read|unread/i.test(JSON.stringify(s)) })));
W('runbook.json', M.run);

// translation matrix
W('matrix.json', { meta: M.matrix.meta, columns: M.matrix.columns, sources: M.matrix.sources, rows: M.matrix.rows });

// steps: 20 story steps + 3 shape steps
const G = steps.STEP_GROUPS, stage = { clock: 'A', comm: 'K', mirrors: 'K', dirac: 'F', spin: 'K', coupling: 'F', ym: 'F', matter: 'F', grav1: 'D', grav2: 'D', projective: 'D', gauge: 'D', nullsurf: 'D', forque: 'D', spring: 'D', rigid: 'D', groups: 'K', category: 'A', baez: 'O', schuller: 'O', orth: 'K', demi: 'K', gosset: 'K' };
const stepList = [];
for (const g of ['core', 'eq', 'lens', 'shapes']) for (const id of G[g]) stepList.push({ id, group: g, no: steps.stepNo(g, id), total: steps.stepTotal(g), stage: stage[id], name: steps.STEP_NAMES.en[id], nameLearner: steps.STEP_NAMES_YL.en[id], nav: steps.NAV_NAMES.en[id], navLearner: steps.NAV_NAMES_YL.en[id], route: g === 'shapes' ? 'shapes/' + id : (id === 'clock' ? 'clock' : 'steps/' + id) });
W('steps.json', stepList);

// pages' story frames (titles, before/after, learner frames) — consumed by pages_from_v15
W('story_frames.json', { pages: story.PAGES, story: story.STORY, storyLearner: story.STORY_YL });

// map tree (63 nodes), reports, analyses
const flat = (nodes, parent = null) => nodes.flatMap(x => [{ ...x, kids: undefined, parent }, ...flat(x.kids || [], x.id)]); const MAP = flat(M.map ? M.map.value : []); W('map.json', MAP);
W('reports.json', reports.REPORTS);
W('analyses.json', analyses.ANALYSES);

// glossary, conventions, ideas (conventionsCopy.js)
W('glossary.json', (conv.GLOSSARY || []).map((g, i) => ({ id: 'G' + String(i + 1).padStart(2, '0'), term: Array.isArray(g) ? g[0] : g.term, definition: Array.isArray(g) ? g[1] : g.text, learner: Array.isArray(g) ? (g[2] || null) : (g.yl || null) })));
const grav = (conv.GRAVITY_CONV && conv.GRAVITY_CONV.en) || {}; W('conventions.json', { rows: conv.ROWS || [], gravity: (grav.lines || []).map((l, i) => ({ id: 'GC' + String(i + 1).padStart(2, '0'), flags: l[0], text: l[1] })), ideas: conv.IDEAS || [] });

// lenses: registry + dictionaries
const LD = M.lensDict; const lensRows = LD.LENS_ROWS || [];
const REG = [
  ['alg', 'Algebra', 'branch', 'quadratic forms, twisted group algebras, Brauer–Wall theory, lattices, codes, division algebras', 'category'],
  ['geo', 'Geometry', 'branch', 'spin and Pin structures, Cartan geometry, Lorentzian geometry, projective and conformal models', 'kind'],
  ['top', 'Topology', 'branch', 'bordism, cohomology, Arf–Brown–Kervaire, simplicial complexes, finite spaces', 'kind'],
  ['cat', 'Category theory', 'branch', 'monoidal and super categories, Frobenius algebras, Morita theory, nerves, functors', 'kind'],
  ['comb', 'Combinatorics', 'branch', 'counting, codes, lattices, finite groups, polytopes', 'kind'],
  ['str', 'String theory', 'language', 'spin structures, supersymmetry, K-theory, lattices and dualities', 'stage'],
  ['sol', 'Solid state', 'language', 'Majorana chains, bands, media, lattices, point groups, the tenfold way', 'stage'],
  ['fld', 'Field theory', 'language', 'quantum field theory and general relativity', 'stage'],
  ['clifford', 'Clifford view', 'shape', 'labels as products of generators e₁e₃e₄', 'none'], ['simplex', 'Simplex view', 'shape', 'labels as faces of the simplex', 'none'], ['cube', 'Cube view', 'shape', 'labels as corners of the n-cube', 'none'], ['prime', 'Prime view', 'shape', 'labels as products of primes', 'none'],
  ['orthoplex', 'Orthoplex', 'shape', 'two poles on every line', 'none'], ['demicube', 'Demicube', 'shape', 'half of the cube: the even labels', 'none'], ['gosset', 'Gosset series', 'shape', 'E₃ … E₈ and the 240', 'none'],
  ['furey', 'Furey', 'researcher', 'division algebras and one generation; Cl(0,10) on 32ℂ', 'none'], ['baez', 'Baez', 'researcher', 'the exceptional Jordan algebra, the Standard Model group, Kepler, triangulations, cospans', 'none'], ['schuller', 'Schuller', 'researcher', 'the geometry and quantum lectures and gravitational closure', 'none'], ['hestenes', 'Hestenes and Lasenby–Doran–Gull', 'researcher', 'space-time algebra and gauge-theory gravity', 'none'], ['pga', 'Dorst, De Keninck, Gunn (PGA)', 'researcher', 'plane-based geometric algebra and its dynamics', 'none'], ['roelfs', 'Roelfs and Eelbode', 'researcher', 'the invariant decomposition and pointors', 'none'], ['tian', 'Tian', 'researcher', 'diagrammatic categorification of Clifford algebras', 'none'], ['majkic', 'Majkić', 'researcher', 'categorial geometry and algebraic topology on the labels', 'none'], ['pumplun', 'Pumplün', 'researcher', 'crossed products, Petit algebras, skew polynomial rings', 'none'], ['hbhl', 'Hsu, Barker, Hobson, Lasenby', 'researcher', 'horizons and null surfaces in gauge-theory gravity', 'none'],
  ['bits', 'Bits (base 2)', 'labels', 'labels printed as bit strings', 'grade'], ['primes', 'Primes', 'labels', 'labels printed as square-free products of primes', 'grade'], ['sigword', 'Signature word (base 3)', 'labels', 'the cell as a word in +, −, 0', 'grade'], ['bitsq', 'Bit × square (base 6)', 'labels', 'presence and square in one digit per generator', 'grade'],
  ['space-plus', 'Space squares +1', 'convention', 'the Spatial reading: the plus generators are space', 'none'], ['time-plus', 'Time squares +1', 'convention', 'the Temporal reading: the mirror, names swapped', 'none'], ['cl13', 'Cl(1,3)', 'convention', 'time first, square +1', 'none'], ['cl31', 'Cl(3,1)', 'convention', 'space first, square +1', 'none'], ['role-names', 'Card role names', 'convention', 'the older names of the 25 cards (off by default)', 'none'],
];
const srcToLens = { 'report:furey': 'furey', 'report:hestenes': 'hestenes', 'report:pumplun': 'pumplun', 'translation_matrix:schuller': 'schuller', 'translation_matrix:baez': 'baez', 'translation_matrix:category': 'cat', P_str: 'str', P_ss: 'sol', P_all: 'fld', M_geo: 'geo', M_alg: 'alg', M_cat: 'cat', M_all: 'alg', MJ_cat: 'majkic', MJ_alg: 'majkic', MJ_geo: 'majkic', MJ_phys: 'majkic', MJ_merged: 'majkic' };
const matrixSrc = { schuller: 'schuller', baez: 'baez', cat: 'category' };
const lenses = REG.map(([key, name, kind, describes, ordering]) => {
  const dictionary = [];
  for (const r of lensRows) if (r.terms && r.terms[key]) dictionary.push({ atlas: r.atlas, term: r.terms[key], match: r.match, flags: r.flags, evidence: r.checks, matrixRows: r.matrix, rows: [], from: 'lens_dictionary:' + r.id });
  for (const d of DICT) if (srcToLens[d.source] === key) dictionary.push({ atlas: d.atlas_element, term: d.field_term, match: d.grade_or_status, flags: [], evidence: [], matrixRows: [], rows: [], from: d.source + (d.note ? ' · ' + d.note.slice(0, 120) : '') });
  return { key, name, kind, describes, ordering, dictionary, matrixColumn: matrixSrc[key] || null, figures: [], translator: kind === 'labels' || kind === 'convention' || kind === 'shape' ? null : 'persona:' + key, conventions: key === 'space-plus' ? { spaceSquare: '+1' } : key === 'time-plus' ? { spaceSquare: '-1' } : key === 'cl13' ? { signature: '(1,3)' } : key === 'cl31' ? { signature: '(3,1)' } : {} };
});
W('lenses.json', lenses);
W('readings.json', DICT);

const counts = { theorems: M.theorems.length, questions: M.questions.length, answered: M.questions.filter(q => q.answered).length, sources: M.sources.length, runbook: M.run.length, matrixRows: M.matrix.rows.length, matrixColumns: M.matrix.columns.length, matrixCells: M.matrix.rows.reduce((a, r) => a + Object.keys(r.cells).length, 0), lensRows: lensRows.length, lenses: lenses.length, dictionaryEntries: lenses.reduce((a, l) => a + l.dictionary.length, 0), readings: DICT.length, mapNodes: MAP.length, steps: stepList.length, glossary: (conv.GLOSSARY || []).length, conventionRows: (conv.ROWS || []).length, gravityConventions: (grav.lines || []).length, ideas: (conv.IDEAS || []).length, reports: reports.REPORTS.length, analyses: analyses.ANALYSES.length };
const cf = path.join(OUT, 'MIGRATION_COUNTS.json'); const prev = fs.existsSync(cf) ? J(cf) : {}; fs.writeFileSync(cf, JSON.stringify({ ...prev, tables: counts }, null, 1));
console.log(JSON.stringify(counts, null, 1));
