#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# Runs the whole migration in order (03_MIGRATION.md §2), then the validator. Usage: sh tools/migrate/run_all.sh <v15 root> <atlas_work root> <leads3 root>
set -e
V15="$1"; WORK="$2"; LEADS="$3"
node tools/migrate/rows_from_v15.mjs "$V15" "$WORK"
node tools/migrate/tables_from_v15.mjs "$V15" "$WORK"
node tools/migrate/inputs_from_v15.mjs "$V15"
python3 -I tools/migrate/checks_from_v15.py "$V15" "$WORK" "$LEADS"
python3 -I tools/migrate/leads_v16.py "$LEADS"
node tools/migrate/pages_from_v15.mjs > /dev/null
node tools/migrate/figures_from_v15.mjs
node tools/merge_explore.mjs
node tools/merge_physics.mjs
# the translator drafts first, then the story overlay (as npm run content): a v15 learner text of an existing row (A56) replaces the draft of its key
node tools/merge_learner_texts.mjs
node tools/merge_story.mjs
node tools/migrate/lens_readings.mjs
node tools/migrate/verify_counts.mjs
node tools/build_content.mjs
