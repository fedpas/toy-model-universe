#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// inputs_from_v15.mjs — the needs strips: content/inputs.json (94 input lines with kinds, joined to the INP rows) and content/needs.json (tab → tabs it needs)
// Usage: node tools/migrate/inputs_from_v15.mjs <v15 root>
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const [V15] = process.argv.slice(2); const OUT = path.resolve('content');
const J = f => JSON.parse(fs.readFileSync(f, 'utf8')); const W = (n, d) => fs.writeFileSync(path.join(OUT, n), JSON.stringify(d, null, 1));
const m = await import(pathToFileURL(path.join(V15, 'inputsData.js')).href);
const rows = J(path.join(OUT, 'rows.json')), texts = J(path.join(OUT, 'texts.json'));
const inpText = {}; for (const t of texts) if (t.level === 'research' && t.row.startsWith('INP-')) inpText[t.body.trim()] = t.row;
const norm = s => s.replace(/\s+/g, ' ').trim();
const byNorm = {}; for (const [b, id] of Object.entries(inpText)) byNorm[norm(b)] = id;
const inputs = [], needs = {}; let unjoined = 0;
for (const [tab, spec] of Object.entries(m.NEEDS)) {
  needs[tab] = { needs: spec.needs || [], none: !!spec.none, learner: spec.yl || null };
  for (const [kind, text] of (spec.inputs || [])) {
    const id = byNorm[norm(text)] || null; if (!id) unjoined++;
    inputs.push({ id, tab, kind, kindName: m.KINDS[kind] || kind, text });
  }
}
// mark the INP rows with their kind
const kindOf = {}; for (const i of inputs) if (i.id) kindOf[i.id] = i.kind;
for (const r of rows) if (r.id.startsWith('INP-')) { r.inputKind = kindOf[r.id] || null; r.inputKindName = r.inputKind ? m.KINDS[r.inputKind] : null; }
W('rows.json', rows); W('inputs.json', inputs); W('needs.json', needs);
const counts = { inputs: inputs.length, tabs: Object.keys(needs).length, kinds: new Set(inputs.map(i => i.kind)).size, unjoined, inpRows: rows.filter(r => r.id.startsWith('INP-')).length };
const cf = path.join(OUT, 'MIGRATION_COUNTS.json'); const prev = fs.existsSync(cf) ? J(cf) : {}; fs.writeFileSync(cf, JSON.stringify({ ...prev, inputs: counts }, null, 1));
console.log(JSON.stringify(counts, null, 1));
