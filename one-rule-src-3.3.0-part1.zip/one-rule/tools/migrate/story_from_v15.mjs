#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/migrate/story_from_v15.mjs — the narration rows of the story round (docs/STORY_PLAN.md §1 and §3.1; BUILD_CONTRACTS "Round 6", owner S1).
//
// Usage: node tools/migrate/story_from_v15.mjs <v15 root>
//
// What it does, step by step (§3.1):
//   1. Read. The v15 copy modules are copied into a temporary folder outside the repository and imported from there (read-only); the three copy blocks
//      inside JSX (DictionarySection.jsx UI/STAGE/TAIL/CARTAN_INFO/YL_NAME/YL, MaxwellSection.jsx T/VL/TX/BIG/YLM, ChargesWidget.jsx T/YLC) are bundled with
//      esbuild with those constants exported, as tests/coverage.test.mjs bundles its entry. Every English string is walked (keys "it" and Italian exports
//      skipped; an object reached twice is walked once, at its first locator); fureyCopy.js is read as fc('en'). A locator is "file#path" (fc. for
//      fc('en'), CONST.en.… for the JSX blocks). A prose block is a string of at least 60 characters and 8 words.
//   2. Map. Every string path is mapped by the explicit table MAP below (file → [path pattern, target]); a prose string that no pattern names fails the
//      run. Each file ends with a pattern for the labels of the interface (strings shorter than a prose block), which a prose string never reaches.
//   3. Dedupe against content/texts.json (locator, exact text, containment either way, or ≥ 88 % of the block's words in one text): a block that is a
//      row adds nothing and gives that row its v15 place (same page only). Then against the other tables (glossary, conventions, theorems, …) and the
//      frames stored and never rendered (content/story_frames.json, pages.json learnerFrame), which still become story rows. A section's lead
//      that only a table repeats stays a candidate (the table is not printed in the section; counted apart, story.tableLeads), as do the leads
//      shorter than a prose block (story.shortLeads).
//   4. Test each candidate research block (§1.4: T0–T5, with the R4, R6 and R8 sets of tools/check_learner_texts.mjs — R6 and R8 are imported, R4 is
//      read through the module's own check(), on a synthetic record, the way its self-test plants records) and apply content/story/review.json.
//      The intro's rows for T4 are the rows of its whole page; a block a choice of review.json calls story becomes one only where T1–T5 clear it.
//   5. Pair the Young Learner strips (§1.5) by v15's own structure (the same key under the learner object: …yl…, …Y, YLM/YLC/YL, STORY_YL, SHORT[tab][0]),
//      to a story row or to the existing row whose research text was migrated from the partner string (A56: the PAG and LNP strips; the card strips);
//      a prose strip whose partner is not a row becomes a learner-only story row (role learner), tested as any story row; the chapter learner lines
//      (research rows whose locator is a learner string, A51) take role learner and their own words as their learner text, except the four
//      learner caption lines of the Baez hero figure (BW1_CAPY), whose words are the learner texts of the caption rows they put in plain words.
//      The try lines of PLAIN become the section's learner connective where they are at most 240 characters and repeat no row.
//   6. Ids from content/story/ids.json (locator → id), new ones appended in page and v15 order, <GROUP>-501 … 999.
//   7. Lay out each page from the ORDER tables (PAGES below, transcribed once per page from the v15 components): sections, titles (v15 menu labels and
//      learner menu labels; a section without a name has no heading), figures, parts, the lead, and the order of story rows and of the existing rows
//      on their home page; Furey's tabs are the sub-pages matter/dictionary, matter/papers, matter/model, matter/generations, matter/help (A49), which
//      sections.json adds until content/story/furey.json (S3) takes over.
//   8. Write content/story/{rows,texts,layout,sections,ids,pending}.json, docs/STORY_REVIEW.md (with the reviewer's proposals of
//      content/story/review_proposed_*.json in its column "proposed") and the counts under "story" in MIGRATION_COUNTS.json.
// Deterministic: two runs on the same inputs write the same bytes. It reads content/*.json as `npm run content` leaves them, without what
// tools/merge_story.mjs added (its baseTables(), from its bookkeeping content/story/merged.json), so a re-run sees the base.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { IDENTIFIERS, requiredNumbers, numbersIn, STATUS, check as learnerCheck, SOURCE as LEARNER_SOURCE } from '../check_learner_texts.mjs';
import { baseTables as storyBase } from '../merge_story.mjs';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', '..');
const C = path.join(ROOT, 'content'), STORY = path.join(C, 'story');
const NM = process.env.NODE_MODULES || '/opt/npm-tools/node_modules';
const readJSON = (f, fb) => (fs.existsSync(f) ? JSON.parse(fs.readFileSync(f, 'utf8')) : fb);
const writeJSON = (f, d) => fs.writeFileSync(f, JSON.stringify(d, null, 1) + '\n');
export const isProse = s => typeof s === 'string' && s.length >= 60 && s.trim().split(/\s+/).length >= 8;

// ------------------------------------------------------------------------------------------------------------------------------------ 1. read
export const MODULES = ['storyCopy.js', 'audienceCopy.js', 'conventionsCopy.js', 'labelsCopy.js', 'MaxwellSection.jsx', 'ChargesWidget.jsx', 'shapesCopy.js', 'gossetCopy.js',
  'equationsCopy.js', 'mirrorsCopy.js', 'spinCopy.js', 'couplingCopy.js', 'yangmillsCopy.js', 'matterCopy.js', 'gravityCopy.js', 'projectiveCopy.js', 'nullCopy.js', 'forqueCopy.js',
  'springCopy.js', 'rigidCopy.js', 'plainStepsCopy.js', 'fureyCopy.js', 'findingsData.js', 'DictionarySection.jsx', 'categoryCopy.js', 'categoryWidgetsCopy.js', 'categoryIntegration.js',
  'baezCopy.js', 'baezWidgetsCopy.js', 'baezIntegration.js', 'schullerCopy.js', 'schullerWidgetsCopy.js', 'schullerIntegration.js', 'lensesCopy.js', 'inputsData.js', 'atlasLines.js',
  'ylAtlas.js', 'cellStatusCopy.js', 'proofs.js', 'storyOverrides.js', 'mapCopy.js', 'researchersCopy.js', 'researchersData.js', 'researcherNotes.js', 'steps.js'];
const JSX_BLOCKS = { 'DictionarySection.jsx': ['UI', 'STAGE', 'TAIL', 'CARTAN_INFO', 'YL_NAME', 'YL'], 'MaxwellSection.jsx': ['T', 'VL', 'TX', 'BIG', 'YLM'], 'ChargesWidget.jsx': ['T', 'YLC'] };
const TAGWORDS = new Set(['checked', 'standard', 'ours', 'open', 'input']);
const isTags = v => (typeof v === 'string' && v.trim() !== '' && v.trim().split(/\s+/).every(w => TAGWORDS.has(w))) || (Array.isArray(v) && v.length > 0 && v.every(x => typeof x === 'string' && TAGWORDS.has(x)));
const tagsOf = v => (Array.isArray(v) ? [...v] : String(v).trim().split(/\s+/));
const ITALIAN_EXPORT = k => /(^|_)IT$/.test(k);

/** walk the English strings of the v15 copy modules: [{ i, file, path, loc, text, tags? }] and the number of functions met (templated copy, not read) */
export async function readV15(v15) {
  const req = createRequire(path.join(NM, 'noop.js'));
  const esbuild = req('esbuild');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'one-rule-story-'));
  try {
    for (const n of fs.readdirSync(v15).sort()) { const p = path.join(v15, n); if (fs.statSync(p).isFile() && /\.(js|jsx|json|mjs)$/.test(n)) fs.copyFileSync(p, path.join(tmp, n)); }
    if (fs.existsSync(path.join(v15, 'lib'))) fs.cpSync(path.join(v15, 'lib'), path.join(tmp, 'lib'), { recursive: true });
    const out = []; const seen = new Set(); let functions = 0;
    const push = (file, p, text, parent, idx) => {
      const rec = { i: out.length, file, path: p.join('.'), loc: `${file}#${p.join('.')}`, text };
      if (Array.isArray(parent) && idx === 1 && parent.length <= 3 && isTags(parent[0])) rec.tags = tagsOf(parent[0]);
      out.push(rec);
    };
    const walk = (v, p, file, parent, idx) => {
      if (typeof v === 'string') { push(file, p, v, parent, idx); return; }
      if (typeof v === 'function') { functions++; return; }
      if (!v || typeof v !== 'object' || seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) { v.forEach((x, i) => walk(x, [...p, i], file, v, i)); return; }
      for (const [k, x] of Object.entries(v)) { if (k === 'it') continue; walk(x, [...p, k], file, v, k); }
    };
    for (const file of MODULES) {
      if (!fs.existsSync(path.join(tmp, file))) throw new Error(`${file} is not in the v15 package`);
      if (JSX_BLOCKS[file]) {
        const entry = path.join(tmp, file.replace(/\.jsx$/, '.story-entry.jsx'));
        fs.writeFileSync(entry, fs.readFileSync(path.join(tmp, file), 'utf8') + `\nexport { ${JSX_BLOCKS[file].join(', ')} };\n`);
        const outfile = path.join(tmp, file.replace(/\.jsx$/, '.story-bundle.mjs'));
        await esbuild.build({ entryPoints: [entry], absWorkingDir: tmp, outfile, bundle: true, platform: 'node', format: 'esm', target: 'node20', jsx: 'automatic',
          loader: { '.js': 'jsx', '.css': 'empty', '.png': 'empty' }, nodePaths: [NM], logLevel: 'error', define: { 'process.env.NODE_ENV': '"production"' },
          banner: { js: "import { createRequire as __storyRequire } from 'node:module'; const require = __storyRequire(import.meta.url);" } });
        const m = await import(pathToFileURL(outfile).href);
        for (const k of JSX_BLOCKS[file]) walk(m[k], [k], file, null, null);
        continue;
      }
      const m = await import(pathToFileURL(path.join(tmp, file)).href);
      const named = Object.entries(m).filter(([k]) => k !== 'default');
      for (const [k, v] of Object.entries(m)) {
        if (ITALIAN_EXPORT(k)) continue;
        if (file === 'fureyCopy.js' && k === 'fc') { walk(v('en'), ['fc'], file, null, null); continue; }
        if (file === 'fureyCopy.js' && k === 'FC') continue;
        if (typeof v === 'function') { functions++; continue; }
        if (k === 'default') { if (named.some(([, x]) => x === v)) continue; walk(v, [], file, null, null); continue; }
        walk(v, [k], file, null, null);
      }
    }
    return { strings: out, functions };
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

// ------------------------------------------------------------------------------------------------------------------------------------ helpers
const norm = s => String(s).replace(/\s+/g, ' ').trim();
const words = s => (String(s).toLowerCase().match(/[\p{L}\p{N}]+/gu) || []);
const escRe = s => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const cmpStr = (a, b) => (a < b ? -1 : a > b ? 1 : 0);

// ------------------------------------------------------------------------------------------------------------------------------------ 2. map
// MAP: file → [[path pattern, target], …]; the first pattern that matches the whole path wins. A target is an object or a function of the match
// (and of `val`, which reads another string of the walk by locator). Fields of a target:
//   k   kind: lead (the formal lead of section s) · leadM (its mathematics-mode variant; t = the lead's locator) · short (its research short; t) ·
//       next (the page's next line) · body (narration or a law-like paragraph; tested) · stmt (v15 printed it as a statement: T0) · cap (the copy of the
//       widget whose V2 figure is f, or of an undrawn widget when f is null) · yl (a Young Learner strip; t = the locator of the formal text it pairs
//       with, or null) · try (PLAIN.<step>.try: the section's connective at learner level, not a row) · ftitle (a finding title, A58) · out (left out,
//       why = the reason, A55) · chrome (a label of the interface; only strings shorter than a prose block may be chrome, CS)
//   p   V2 route · s section id · f figure id · r role when it is not the kind's default (detail) · tags (the status tags v15 printed in JSX beside a note)
const CS = { k: 'chrome', shortOnly: true };
const CH = { k: 'chrome' };
const OUT = (why, p) => ({ k: 'out', why, p: p ?? null });
const L = (file, p) => `${file}#${p}`;
const PAGE_OF = { rule: 'rule', atlas: 'cells', maxwell: 'light', furey: 'matter', shapes: 'shapes', equations: 'steps', conventions: 'rule', lenses: 'lenses' };
const SEC_OF = p => (p === 'conventions' ? 'conventions' : 'intro');
const FRAME_PAGES = 'rule|atlas|maxwell|furey|shapes|equations|conventions|lenses';
const SHORT_LEAD = {
  comm: L('equationsCopy.js', 'en.c.lede'), dirac: L('equationsCopy.js', 'en.d.lede'), coupling: L('couplingCopy.js', 'en.lede'), ym: L('yangmillsCopy.js', 'en.lede'),
  matter: L('matterCopy.js', 'en.lede'), grav1: L('gravityCopy.js', 'en.g1.lede'), grav2: L('gravityCopy.js', 'en.g2.lede'), mirrors: L('mirrorsCopy.js', 'en.m1.lede'),
  projective: L('projectiveCopy.js', 'en.p1.lede'), maxwell: L('MaxwellSection.jsx', 'T.en.lede'), dictionary: L('DictionarySection.jsx', 'UI.en.lede'),
  earlier: L('fureyCopy.js', 'fc.earlier.lede'), findings: L('fureyCopy.js', 'fc.findings.lede'), threegen: L('fureyCopy.js', 'fc.threegen.lede'), help: L('fureyCopy.js', 'fc.help.lede'),
  orth: L('shapesCopy.js', 'en.o.lede'), demi: L('shapesCopy.js', 'en.d.lede'), gosset: L('gossetCopy.js', 'en.lede'), forque: L('forqueCopy.js', 'en.f.lede'),
  spin: L('spinCopy.js', 'en.s.lede'), spring: L('springCopy.js', 'en.s.lede'), rigid: L('rigidCopy.js', 'en.s.lede'), nullsurf: L('nullCopy.js', 'en.lede'),
  page_rule: L('storyCopy.js', 'STORY.en.pages.rule.does'), page_atlas: L('storyCopy.js', 'STORY.en.pages.atlas.does'), page_conventions: L('storyCopy.js', 'STORY.en.pages.conventions.does'),
  page_maxwell: L('storyCopy.js', 'STORY.en.pages.maxwell.does'), page_shapes: L('storyCopy.js', 'STORY.en.pages.shapes.does'), page_equations: L('storyCopy.js', 'STORY.en.pages.equations.does'),
  page_furey: L('storyCopy.js', 'STORY.en.pages.furey.does'), page_lenses: L('storyCopy.js', 'STORY.en.pages.lenses.does'),
};
const LAB_PAGE = { clock: 'clock', gauge: 'steps/gauge', groups: 'steps/groups' }, LAB_SEC = { clock: 'clock', gauge: 'eq-gauge', groups: 'ln-groups' };
const DIRAC_TAGS = { cube: ['checked', 'ours'], maxwell: ['checked'], comm: ['checked'], disp: ['checked'], mat: ['checked', 'standard'] };
const FUREY_PAGE = { earlier: 'matter/papers', findings: 'matter/model', threegen: 'matter/generations', help: 'matter/help' };
const CARD_SEC = { blocks: 'blocks', edges: 'edges', witt: 'axes', z2: 'axes', open: 'open' };
const FIND_SEC = ['blocks', 'edges', 'axes', 'axes', 'open'];
const TRY_SEC = { projective: 'intro', forque: 'intro', spin: 'sp-reflect', spring: 'intro', rigid: 'rg-hang', nullsurf: 'intro' };
const HEDGE_SEC = { projective: 'pj-checks', forque: 'eq-forque', spin: 'sp-num', spring: 'eq-spring', rigid: 'eq-rigid', nullsurf: 'eq-nullsurf' };
const NEEDS_PAGE = tab => (/^maxwell\//.test(tab) ? 'light' : ['orth', 'demi', 'gosset'].includes(tab) ? 'shapes' : tab === 'clock' ? 'clock' : tab === 'conventions' ? 'rule'
  : ['dictionary', 'earlier', 'findings', 'threegen', 'help'].includes(tab) ? 'matter' : `steps/${tab}`);
// the chapters: findings → sections (Baez J-ids), widgets → sections and figures (the V2 port of the v15 widget, null when V2 does not draw it)
const BZ_FIND = { J1: ['bz-generation'], J2: ['bz-generation'], J3: ['bz-ladder'], J6: ['bz-which'], J7: ['bz-ten'], J8: ['bz-kepler'], J9: ['bz-periodic', 'detail'],
  J4: ['bz-ring', 'detail'], J5: ['bz-more', 'detail'], J10: ['bz-more', 'detail'] };
const BW = { 1: ['intro', 'five-bits'], 2: ['bz-top', null], 3: ['bz-ladder', 'e8-ladder'], 4: ['bz-kepler', 'kepler-trio'], 5: ['bz-papers', null], 6: ['bz-ring', null], 7: ['bz-periodic', null] };
// The four learner caption lines of BW1 (the hero figure five-bits; rows of their own in the tables, LNB-107–110) are the learner texts of the
// caption rows they put in plain words (A51 (b) for these four; A19): capY index → cap index, by v15's tag and subject — capY.0 (checked: one
// family, six groups of 1, 3, 6, 2, 1, 3) → cap.0 (LNB-101, the six classes); capY.1 (checked: charge a count, the flip reverses it) → cap.3
// (LNB-104, XOR with 11111 flips Y and Q); capY.2 (standard: the six groups as in the paper) → cap.5 (LNB-106, the pieces of the paper's eq. 69);
// capY.3 (ours: the reading is ours) → cap.4 (LNB-105, the reading as charge conjugation is ours). The lines keep role learner without a text of
// their own, so they show at neither level; their words show at learner level under the figure, as v15 showed them.
const BW1_CAPY = { 0: 0, 1: 3, 2: 5, 3: 4 };
const CW = { 1: ['intro', 'cube-category'], 2: ['cat-frobenius', null], 3: ['cat-moves', null], 4: ['cat-top', null], 5: ['cat-twozeros', null], 6: ['cat-cube', 'sign-flux'] };
const SW = { 1: ['intro', 'schuller-chain'], 2: ['sc-table', 'one-table'], 3: ['sc-fibre', null], 4: ['sc-hyper', null], 5: ['sc-bands', 'bands'], 6: ['sc-fock', null], 7: ['sc-total', null] };
const SC_FOLDED = new Set(['area', 'deform', 'spin']);
// the "ladder" steps share one copy shape: lede, numbers, stNote, idNote (tagged checked in JSX), mat (checked standard), xr, open, yl.points, dl
function ladderStep(base, route, eqSec, checksSec, checksFig, extra = []) {
  const b = base ? base.replace(/\./g, '\\.') + '\\.' : '';
  return [
    ...extra,
    [new RegExp(`^en\\.${b}(title|yl\\.(title|name|pick|picH|pickH|graphH|evenH|oddH))$`), CH],
    [new RegExp(`^en\\.${b}lede$`), { k: 'lead', p: route, s: 'intro' }],
    [new RegExp(`^en\\.${b}(numbers|stNote)$`), { k: 'cap', p: route, s: checksSec, f: checksFig }],
    [new RegExp(`^en\\.${b}idNote$`), { k: 'stmt', p: route, s: checksSec, tags: ['checked'] }],
    [new RegExp(`^en\\.${b}mat$`), { k: 'stmt', p: route, s: checksSec, tags: ['checked', 'standard'] }],
    [new RegExp(`^en\\.${b}(xr|open)\\.\\d+\\.1$`), { k: 'stmt', p: route, s: eqSec }],
    [new RegExp(`^en\\.${b}yl\\.points\\.\\d+\\.1$`), { k: 'yl', t: null, p: route, s: eqSec }],
    [new RegExp(`^en\\.${b}dl\\..*$`), OUT('script', route)],
    [/./, CS],
  ];
}
export function buildMap(val) {
  const bzFinding = i => val(L('baezCopy.js', `COPY.en.findings.${i}.id`));
  return {
    'storyCopy.js': [
      [/^PAGES\.\d+$/, CH],
      [new RegExp(`^STORY\\.en\\.pages\\.(${FRAME_PAGES})\\.does$`), m => ({ k: 'lead', p: PAGE_OF[m[1]], s: SEC_OF(m[1]) })],
      [new RegExp(`^STORY\\.en\\.pages\\.(${FRAME_PAGES})\\.after$`), m => ({ k: 'next', p: m[1] === 'conventions' ? 'clock' : PAGE_OF[m[1]], s: 'intro' })],
      [new RegExp(`^STORY\\.en\\.pages\\.(${FRAME_PAGES})\\.tags\\.(\\d+)\\.1$`), m => ({ k: 'stmt', p: PAGE_OF[m[1]], s: SEC_OF(m[1]) })],
      [/^STORY\.en\.pages\.(map|researchers|ask)\.(does|after|h|tags\.\d+\.1)$/, m => OUT('logbook', m[1] === 'ask' ? 'ask' : 'logbook')],
      [/^STORY(_YL)?\.en\.pages\.\w+\.before$/, OUT('before')],
      [/^STORY(_YL)?\.en\.pages\.\w+\.h$/, CH],
      [/^STORY\.en\.hero\.Physicist\.1$/, { k: 'lead', p: '', s: 'intro' }],
      [/^STORY\.en\.hero\.Mathematician\.1$/, { k: 'leadM', t: L('storyCopy.js', 'STORY.en.hero.Physicist.1') }],
      [/^STORY\.en\.hero\.Young Learner\.1$/, { k: 'yl', t: L('storyCopy.js', 'STORY.en.hero.Physicist.1'), p: '', s: 'intro' }],
      [/^STORY\.en\.genesisScope\.(Physicist|Mathematician)\.1$/, { k: 'lead', p: 'rule', s: 'ideas' }],
      [/^STORY\.en\.genesisScope\.Young Learner\.1$/, { k: 'yl', t: L('storyCopy.js', 'STORY.en.genesisScope.Physicist.1'), p: 'rule', s: 'ideas' }],
      [/^STORY\.en\.note$/, { k: 'body', p: '', s: 'intro', r: 'detail' }],
      [/^STORY_YL\.en\.note$/, { k: 'yl', t: L('storyCopy.js', 'STORY.en.note'), p: '', s: 'intro' }],
      [/^STORY(_YL)?\.en\.(tagHelp|metric)\..*$/, m => (m[2] === 'tagHelp' ? OUT('persona') : OUT('controls'))],
      [new RegExp(`^STORY_YL\\.en\\.pages\\.(${FRAME_PAGES})\\.after$`), m => ({ k: 'yl', t: L('storyCopy.js', `STORY.en.pages.${m[1]}.after`), p: m[1] === 'conventions' ? 'clock' : PAGE_OF[m[1]], s: 'intro' })],
      [/^STORY_YL\.en\.pages\.(conventions|lenses)\.does$/, m => ({ k: 'yl', t: null, p: PAGE_OF[m[1]], s: SEC_OF(m[1]) })],
      [new RegExp(`^STORY_YL\\.en\\.pages\\.(${FRAME_PAGES})\\.tags\\.(\\d+)\\.1$`), m => ({ k: 'yl', t: L('storyCopy.js', `STORY.en.pages.${m[1]}.tags.${m[2]}.1`), p: PAGE_OF[m[1]], s: SEC_OF(m[1]) })],
      // the Logbook pages' strip tags: learner texts of their PAG rows (A56), never rows of their own (A55)
      [/^STORY_YL\.en\.pages\.(map|researchers|ask)\.tags\.(\d+)\.1$/, m => ({ k: 'yl', t: L('storyCopy.js', `STORY.en.pages.${m[1]}.tags.${m[2]}.1`), p: null, s: null, pairOnly: true })],
      [/^STORY_YL\.en\.pages\.(map|researchers|ask)\.(does|after)$/, m => OUT('logbook', m[1] === 'ask' ? 'ask' : 'logbook')],
      [/^STORY\.en\.tabsLbl\..*$/, CH],
      [/./, CS],
    ],
    'audienceCopy.js': [
      [/^PIC_YL\.en\.comm$/, { k: 'yl', t: null, p: 'steps/comm', s: 'intro' }],
      [/^PIC_YL\.en\.dirac$/, { k: 'yl', t: null, p: 'steps/dirac', s: 'intro' }],
      [/^PIC_YL\.en\.demi$/, { k: 'yl', t: null, p: 'shapes', s: 'sh-demi' }],
      [/^PIC_YL\.en\.findingsGrids$/, { k: 'yl', t: null, p: 'matter/model', s: 'blocks' }],
      [/^SHORT\.en\.(tally|page_map|page_researchers|page_ask)\.[01]$/, m => OUT(m[1] === 'tally' ? 'tally' : 'logbook', m[1] === 'page_ask' ? 'ask' : 'logbook')],
      [/^SHORT\.en\.(\w+)\.0$/, m => { if (!SHORT_LEAD[m[1]]) throw new Error(`SHORT.en.${m[1]}: no lead named in SHORT_LEAD`); return { k: 'yl', t: SHORT_LEAD[m[1]] }; }],
      [/^SHORT\.en\.(\w+)\.1$/, m => { if (!SHORT_LEAD[m[1]]) throw new Error(`SHORT.en.${m[1]}: no lead named in SHORT_LEAD`); return { k: 'short', t: SHORT_LEAD[m[1]] }; }],
      [/./, CS],
    ],
    'conventionsCopy.js': [
      [/^CONV\.en\.lede\.\d+$/, { k: 'lead', p: 'rule', s: 'conventions' }],
      [/^CONV\.en\.ledeM\.0$/, { k: 'leadM', t: L('conventionsCopy.js', 'CONV.en.lede.0') }],
      [/^CONV\.en\.ledeY\.(\d+)$/, m => ({ k: 'yl', t: L('conventionsCopy.js', `CONV.en.lede.${m[1]}`), p: 'rule', s: 'conventions' })],
      [/^CONV\.en\.rows\.\d+\.(text|note|where\.\d+)$/, { k: 'stmt', p: 'rule', s: 'conventions' }],
      [/^CONV\.en\.(ideasLede|ideasFurther)$/, { k: 'body', p: 'rule', s: 'ideas', r: 'detail' }],
      [/^CONV\.en\.ideas\.\d+\.\w+$/, { k: 'stmt', p: 'rule', s: 'ideas' }],
      [/^CONV\.en\.glossLede$/, OUT('table-frame', 'glossary')],
      [/^CONV\.en\.gloss\.\d+\.\d+(\.\d+)?$/, { k: 'stmt', p: 'glossary', s: 'glossary' }],
      [/^CONV\.en\.glance\.tags\.\d+\.1$/, { k: 'stmt', p: 'rule', s: 'conventions' }],
      [/^CONV\.en\.glance\.est$/, { k: 'body', p: 'rule', s: 'conventions' }],
      [/^CONV\.en\.glance\.script$/, OUT('script', 'rule')],
      [/^GRAVITY_CONV\.en\.lede$/, OUT('table-frame', 'rule')],
      [/^GRAVITY_CONV\.en\.lines\.\d+\.\d+$/, { k: 'stmt', p: 'rule', s: 'conventions' }],
      [/./, CS],
    ],
    'labelsCopy.js': [
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.lede\.\d+$/, m => ({ k: 'lead', p: LAB_PAGE[m[1]], s: 'intro' })],
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.ledeM\.0$/, m => ({ k: 'leadM', t: L('labelsCopy.js', `COPY.en.tabs.${m[1]}.lede.0`) })],
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.ledeY\.(\d+)$/, m => ({ k: 'yl', t: L('labelsCopy.js', `COPY.en.tabs.${m[1]}.lede.${m[2]}`), p: LAB_PAGE[m[1]], s: 'intro' })],
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.glance\.tags\.\d+\.1$/, m => ({ k: 'stmt', p: LAB_PAGE[m[1]], s: LAB_SEC[m[1]] })],
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.glance\.est$/, m => ({ k: 'body', p: LAB_PAGE[m[1]], s: 'intro' })],
      [/^COPY\.en\.tabs\.(clock|gauge|groups)\.glance\.script$/, m => OUT('script', LAB_PAGE[m[1]])],
      [/^COPY\.en\.lattice\.(cap|wheel|embedOk|rotor\.\w+)$/, { k: 'cap', p: 'clock', s: 'clock', f: 'lattice' }],
      [/^COPY\.en\.lattice\.(cap|wheel)Y$/, m => ({ k: 'yl', t: L('labelsCopy.js', `COPY.en.lattice.${m[1]}`), p: 'clock', s: 'clock' })],
      [/^COPY\.en\.trinity\.(cone|phase|note)$/, { k: 'cap', p: 'clock', s: 'clock-trinity', f: 'trinity' }],
      [/^COPY\.en\.trinity\.coneY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.trinity.cone'), p: 'clock', s: 'clock-trinity' }],
      [/^COPY\.en\.biv\.(cap|read\.lam|verdict\.complex)$/, { k: 'cap', p: 'clock', s: 'clock-biv', f: 'bivector-lab' }],
      [/^COPY\.en\.biv\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.biv.cap'), p: 'clock', s: 'clock-biv' }],
      [/^COPY\.en\.pg\.(cap|shear|names\.-1)$/, { k: 'cap', p: 'steps/gauge', s: 'intro', f: 'rain' }],
      [/^COPY\.en\.pg\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.pg.cap'), p: 'steps/gauge', s: 'intro' }],
      [/^COPY\.en\.curv\.cap$/, { k: 'cap', p: 'steps/gauge', s: 'gg-curv', f: 'riemann-split' }],
      [/^COPY\.en\.curv\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.curv.cap'), p: 'steps/gauge', s: 'gg-curv' }],
      [/^COPY\.en\.rails\.(cap|pin)$/, { k: 'cap', p: 'steps/groups', s: 'intro', f: 'o-q-f2' }],
      [/^COPY\.en\.rails\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.rails.cap'), p: 'steps/groups', s: 'intro' }],
      [/^COPY\.en\.golay\.(cap|link)$/, { k: 'cap', p: 'steps/groups', s: 'gr-golay', f: 'golay-ring' }],
      [/^COPY\.en\.golay\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.golay.cap'), p: 'steps/groups', s: 'gr-golay' }],
      [/^COPY\.en\.primes\.cap$/, { k: 'cap', p: 'steps/groups', s: 'gr-primes', f: null }],
      [/^COPY\.en\.primes\.capY$/, { k: 'yl', t: L('labelsCopy.js', 'COPY.en.primes.cap'), p: 'steps/groups', s: 'gr-primes' }],
      [/^COPY\.en\.checkedNoteY?$/, OUT('script', 'clock')],
      [/./, CS],
    ],
    'MaxwellSection.jsx': [
      [/^T\.en\.lede$/, { k: 'lead', p: 'light', s: 'views' }],
      [/^T\.en\.calib$/, { k: 'body', p: 'light', s: 'intro', r: 'detail' }],
      [/^YLM\.en\.calib$/, { k: 'yl', t: L('MaxwellSection.jsx', 'T.en.calib'), p: 'light', s: 'intro' }],
      [/^T\.en\.key\.\d+$/, { k: 'cap', p: 'light', s: 'views', f: 'four-views-maxwell' }],
      [/^YLM\.en\.key\.(\d+)$/, m => ({ k: 'yl', t: L('MaxwellSection.jsx', `T.en.key.${m[1]}`), p: 'light', s: 'views' })],
      [/^T\.en\.(conv|note|cons)$/, { k: 'cap', p: 'light', s: 'views', f: 'four-views-maxwell' }],
      [/^TX\.en\.limit$/, { k: 'cap', p: 'light', s: 'views', f: 'four-views-maxwell' }],
      [/^YLM\.en\.note$/, { k: 'yl', t: L('MaxwellSection.jsx', 'T.en.note'), p: 'light', s: 'views' }],
      [/^YLM\.en\.(contract|wedge)$/, { k: 'yl', t: null, p: 'light', s: 'views' }],
      [/^T\.en\.(ladNote|n0)$/, { k: 'cap', p: 'light', s: 'ladders', f: 'maxwell-ladders' }],
      [/^TX\.en\.(start|classNote|ladTimeNote|cls\.\w+|along\.\w+)$/, { k: 'cap', p: 'light', s: 'ladders', f: 'maxwell-ladders' }],
      [/^BIG\.en\.(c33|c34|nonew)$/, { k: 'cap', p: 'light', s: 'ladders', f: 'maxwell-ladders' }],
      [/^YLM\.en\.start$/, { k: 'yl', t: L('MaxwellSection.jsx', 'TX.en.start'), p: 'light', s: 'ladders' }],
      [/^YLM\.en\.(big|lad|ladKind)$/, { k: 'yl', t: null, p: 'light', s: 'ladders' }],
      [/^T\.en\.dlText$/, OUT('script', 'light')],
      [/./, CS],
    ],
    'ChargesWidget.jsx': [
      [/^T\.en\.lede$/, { k: 'lead', p: 'light', s: 'charges' }],
      [/^YLC\.en\.lede$/, { k: 'yl', t: L('ChargesWidget.jsx', 'T.en.lede'), p: 'light', s: 'charges' }],
      [/^T\.en\.(what\.\w+|forceText|listNote|frameNote|scope)$/, { k: 'cap', p: 'light', s: 'charges', f: 'charges' }],
      [/^YLC\.en\.(what\.\w+|scope)$/, m => ({ k: 'yl', t: L('ChargesWidget.jsx', `T.en.${m[1]}`), p: 'light', s: 'charges' })],
      [/^YLC\.en\.force$/, { k: 'yl', t: L('ChargesWidget.jsx', 'T.en.forceText'), p: 'light', s: 'charges' }],
      [/^(T|YLC)\.en\.(ctlNote|chk\.\w+)$/, OUT('controls', 'light')],
      [/./, CS],
    ],
    'shapesCopy.js': [
      [/^en\.o\.lede$/, { k: 'lead', p: 'shapes', s: 'sh-orth' }],
      [/^en\.o\.note$/, { k: 'body', p: 'shapes', s: 'sh-orth' }],
      [/^en\.o\.points\.\d+\.1$/, { k: 'stmt', p: 'shapes', s: 'sh-orth' }],
      [/^en\.o\.yl\.points\.\d+\.1$/, { k: 'yl', t: null, p: 'shapes', s: 'sh-orth' }],
      [/^en\.d\.lede$/, { k: 'lead', p: 'shapes', s: 'sh-demi' }],
      [/^en\.d\.(facets|limits)$/, { k: 'body', p: 'shapes', s: 'sh-demi' }],
      [/^en\.d\.cliff\.note$/, { k: 'stmt', p: 'shapes', s: 'sh-demi', tags: ['standard', 'checked'] }],
      [/^en\.d\.orth\.t$/, { k: 'stmt', p: 'shapes', s: 'sh-demi', tags: ['checked', 'standard'] }],
      [/^en\.d\.fur\.t$/, { k: 'stmt', p: 'shapes', s: 'sh-demi', tags: ['checked', 'ours', 'open'] }],
      [/^en\.d\.mx\.(note|cap7)$/, { k: 'cap', p: 'shapes', s: 'sh-demi', f: null }],
      [/^en\.d\.yl\.(facets|orth\.t|fur\.t|mx\.note|mx\.cap7)$/, m => ({ k: 'yl', t: L('shapesCopy.js', `en.d.${m[1]}`), p: 'shapes', s: 'sh-demi' })],
      [/^en\.d\.yl\.mx\.t$/, { k: 'yl', t: null, p: 'shapes', s: 'sh-demi' }],
      [/^en\.d\.dlText$/, OUT('script', 'shapes')],
      [/./, CS],
    ],
    'gossetCopy.js': [
      [/^en\.lede$/, { k: 'lead', p: 'shapes', s: 'sh-gosset' }],
      [/^en\.yl\.intro$/, { k: 'yl', t: L('gossetCopy.js', 'en.lede'), p: 'shapes', s: 'sh-gosset' }],
      [/^en\.(tableNote|arms|nest|split\.\d+|glue|glueNote\.\d+|glueTail|br|bd|limits)$/, { k: 'body', p: 'shapes', s: 'sh-gosset' }],
      [/^en\.yl\.(arms|nest|glue|br|bd|limits)$/, m => ({ k: 'yl', t: L('gossetCopy.js', `en.${m[1]}`), p: 'shapes', s: 'sh-gosset' })],
      [/^en\.(cell|gb)\.\d+\.1$/, { k: 'stmt', p: 'shapes', s: 'sh-gosset' }],
      [/^en\.yl\.gb\.(\d+)\.1$/, m => ({ k: 'yl', t: L('gossetCopy.js', `en.gb.${m[1]}.1`), p: 'shapes', s: 'sh-gosset' })],
      [/^en\.dlText$/, OUT('script', 'shapes')],
      [/./, CS],
    ],
    'equationsCopy.js': [
      [/^en\.c\.lede$/, { k: 'lead', p: 'steps/comm', s: 'intro' }],
      [/^en\.c\.lorentz$/, { k: 'cap', p: 'steps/comm', s: 'intro', f: 'comm-graph' }],
      [/^en\.c\.yl\.lorentz$/, { k: 'yl', t: L('equationsCopy.js', 'en.c.lorentz'), p: 'steps/comm', s: 'intro' }],
      [/^en\.c\.yl\.pick$/, OUT('controls', 'steps/comm')],
      [/^en\.c\.note$/, { k: 'stmt', p: 'steps/comm', s: 'summary', tags: ['checked'] }],
      [/^en\.c\.points\.\d+\.1$/, { k: 'stmt', p: 'steps/comm', s: 'eq-comm' }],
      [/^en\.c\.yl\.points\.\d+\.1$/, { k: 'yl', t: null, p: 'steps/comm', s: 'eq-comm' }],
      [/^en\.d\.lede$/, { k: 'lead', p: 'steps/dirac', s: 'intro' }],
      [/^en\.d\.numbers$/, { k: 'stmt', p: 'steps/dirac', s: 'intro', tags: ['checked'] }],
      [/^en\.d\.cap$/, { k: 'cap', p: 'steps/dirac', s: 'intro', f: 'dirac-pic' }],
      [/^en\.d\.yl\.(numbers|cap|limits)$/, m => ({ k: 'yl', t: L('equationsCopy.js', `en.d.${m[1]}`), p: 'steps/dirac', s: m[1] === 'limits' ? 'dirac-xref' : 'intro' })],
      [/^en\.d\.(cube|maxwell|comm|disp|mat)\.t$/, m => ({ k: 'stmt', p: 'steps/dirac', s: 'dirac-xref', tags: DIRAC_TAGS[m[1]] })],
      [/^en\.d\.limits$/, { k: 'stmt', p: 'steps/dirac', s: 'dirac-xref', tags: ['open'] }],
      [/^en\.d\.yl\.points\.\d+\.1$/, { k: 'yl', t: null, p: 'steps/dirac', s: 'dirac-xref' }],
      [/^en\.t\..*$/, OUT('tally', 'logbook')],
      [/^en\.dl\..*$/, OUT('script', 'steps/comm')],
      [/./, CS],
    ],
    'mirrorsCopy.js': [
      [/^en\.m1\.lede$/, { k: 'lead', p: 'steps/mirrors', s: 'intro' }],
      [/^en\.m1\.twoCap$/, { k: 'cap', p: 'steps/mirrors', s: 'intro', f: 'mirrors-cube' }],
      [/^en\.m1\.yl\.twoCap$/, { k: 'yl', t: L('mirrorsCopy.js', 'en.m1.twoCap'), p: 'steps/mirrors', s: 'intro' }],
      [/^en\.m1\.picAria$/, OUT('controls', 'steps/mirrors')],
      [/^en\.m1\.idNote$/, { k: 'stmt', p: 'steps/mirrors', s: 'mr-notes', tags: ['checked'] }],
      [/^en\.m1\.(e8|mat)$/, { k: 'stmt', p: 'steps/mirrors', s: 'mr-notes', tags: ['checked', 'standard'] }],
      [/^en\.m1\.(xr|open)\.\d+\.1$/, { k: 'stmt', p: 'steps/mirrors', s: 'eq-mirrors' }],
      [/^en\.m1\.yl\.points\.\d+\.1$/, { k: 'yl', t: null, p: 'steps/mirrors', s: 'eq-mirrors' }],
      [/^en\.m1\.dl\..*$/, OUT('script', 'steps/mirrors')],
      [/./, CS],
    ],
    'spinCopy.js': [
      [/^(PAPER_CITE|LECTURE_CITE)$/, OUT('script', 'steps/spin')],
      [/^en\.s\.title$/, CH],
      [/^en\.s\.lede$/, { k: 'lead', p: 'steps/spin', s: 'intro' }],
      [/^en\.s\.(srcPaperText|srcLectureText)$/, { k: 'body', p: 'steps/spin', s: 'sp-sources' }],
      [/^en\.s\.weave$/, { k: 'body', p: 'steps/spin', s: 'sp-weave' }],
      [/^en\.s\.(ladder\.\d+\.say|ladderCap)$/, { k: 'body', p: 'steps/spin', s: 'sp-ladder' }],
      [/^en\.s\.threads\.(\w+)\.q$/, m => ({ k: 'lead', p: 'steps/spin', s: `sp-${m[1]}` })],
      [/^en\.s\.threads\.(\w+)\.(which|paper|lecture|ours)$/, m => ({ k: 'body', p: 'steps/spin', s: `sp-${m[1]}` })],
      [/^en\.s\.mxLede$/, { k: 'cap', p: 'steps/spin', s: 'eq-spin', f: 'spin-matrix' }],
      [/^en\.s\.labels\.callNote$/, OUT('controls', 'steps/spin')],
      [/^en\.s\.(convLede|conv\.\d+\.note)$/, { k: 'body', p: 'steps/spin', s: 'sp-conv' }],
      [/^en\.s\.authLede$/, { k: 'body', p: 'steps/spin', s: 'sp-auth' }],
      [/^en\.s\.num$/, { k: 'body', p: 'steps/spin', s: 'sp-num' }],
      [/^en\.s\.open\.\d+\.1$/, { k: 'stmt', p: 'steps/spin', s: 'eq-spin' }],
      [/^en\.s\.(dl\..*|notesHead|notesIntro)$/, OUT('script', 'steps/spin')],
      [/^en\.s\.w\.reflect\.(lede|cap|double)$/, { k: 'cap', p: 'steps/spin', s: 'sp-reflect', f: 'spin-rotor' }],
      [/^en\.s\.w\.(labels|lr)\.(lede|verdict|cap)$/, { k: 'cap', p: 'steps/spin', s: 'sp-labels', f: null }],
      [/^en\.s\.w\.three\.(lede|cap|fourth)$/, { k: 'cap', p: 'steps/spin', s: 'intro', f: 'spin-four-i' }],
      [/^en\.s\.w\.mix\.(lede|cap)$/, { k: 'cap', p: 'steps/spin', s: 'sp-spaces', f: 'spin-halves' }],
      [/^en\.s\.w\.phase\.(lede|cap)$/, { k: 'cap', p: 'steps/spin', s: 'sp-states', f: null }],
      [/^en\.s\.w\.pointor\.(lede|cap)$/, { k: 'cap', p: 'steps/spin', s: 'sp-pointor', f: 'spin-pointor' }],
      [/^en\.s\.w\.hest\.(lede|chiCap)$/, { k: 'cap', p: 'steps/spin', s: 'sp-hest', f: 'spin-hestenes' }],
      [/./, CS],
    ],
    'couplingCopy.js': ladderStep('', 'steps/coupling', 'eq-coupling', 'cp-checks', 'coupling-ladder'),
    'yangmillsCopy.js': ladderStep('', 'steps/ym', 'eq-ym', 'ym-checks', 'ym-ladder'),
    'matterCopy.js': ladderStep('', 'steps/matter', 'eq-matter', 'mt-checks', 'matter-ladder'),
    'gravityCopy.js': [
      [/^en\.g2\.dsNote$/, { k: 'cap', p: 'steps/grav2', s: 'g2-ds', f: 'cosmological-generator' }],
      ...ladderStep('g1', 'steps/grav1', 'eq-grav1', 'g1-checks', 'bianchi-check').slice(0, -1),
      ...ladderStep('g2', 'steps/grav2', 'eq-grav2', 'g2-checks', null),
    ],
    'projectiveCopy.js': ladderStep('p1', 'steps/projective', 'eq-projective', 'pj-checks', null, [
      [/^en\.p1\.(nullCap|motionsNote|dblNote)$/, { k: 'cap', p: 'steps/projective', s: 'pj-null', f: 'null-pair-moves' }],
    ]),
    'nullCopy.js': [
      [/^en\.title$/, CH],
      [/^en\.lede$/, { k: 'lead', p: 'steps/nullsurf', s: 'intro' }],
      [/^en\.summary$/, { k: 'body', p: 'steps/nullsurf', s: 'intro' }],
      [/^en\.cards\.\d+\.h$/, CH],
      [/^en\.cards\.(\d+)\.text\.\d+(\.text\.\d+)?$/, m => ({ k: 'stmt', p: 'steps/nullsurf', s: `nl-res-${Number(m[1]) + 1}` })],
      [/^en\.(critText|kerrText)$/, { k: 'body', p: 'steps/nullsurf', s: 'nl-res-3' }],
      [/^en\.(cone\.aria|neck\.r?[aA]ria|crit\.aria|ladder\.aria)$/, OUT('controls', 'steps/nullsurf')],
      [/^en\.(cone\.caps\.\w+|ladder\.caps\.\w+|ladder\.lab\.\w+)$/, { k: 'cap', p: 'steps/nullsurf', s: 'intro', f: 'null-figures' }],
      [/^en\.neck\.caps\.\w+$/, { k: 'cap', p: 'steps/nullsurf', s: 'nl-res-2', f: 'null-neck' }],
      [/^en\.(crit\.caps\.\w+|kerr\.cap)$/, { k: 'cap', p: 'steps/nullsurf', s: 'nl-res-3', f: 'null-criterion' }],
      [/^en\.(limits|links)\.\d+\.\d+$/, { k: 'stmt', p: 'steps/nullsurf', s: 'eq-nullsurf' }],
      [/^en\.dl\..*$/, OUT('script', 'steps/nullsurf')],
      [/./, CS],
    ],
    'forqueCopy.js': [
      [/^(PAPER_CITE)$/, OUT('script', 'steps/forque')],
      [/^en\.f\.title$/, CH],
      [/^en\.f\.lede$/, { k: 'lead', p: 'steps/forque', s: 'intro' }],
      [/^en\.f\.(racketLede|racketCap)$/, { k: 'cap', p: 'steps/forque', s: 'intro', f: 'tennis-racket' }],
      [/^en\.f\.linesCap$/, { k: 'cap', p: 'steps/forque', s: 'fq-lines', f: 'forque-lines' }],
      [/^en\.f\.lines\.\d+\.(say|tex)$/, { k: 'body', p: 'steps/forque', s: 'fq-lines' }],
      [/^en\.f\.mxLede$/, { k: 'cap', p: 'steps/forque', s: 'eq-forque', f: 'forque-matrix' }],
      [/^en\.f\.labels\.(callNote|noInst)$/, OUT('controls', 'steps/forque')],
      [/^en\.f\.(convLede|authLede|num|atlas)$/, { k: 'body', p: 'steps/forque', s: 'eq-forque', r: 'detail' }],
      [/^en\.f\.open\.\d+\.1$/, { k: 'stmt', p: 'steps/forque', s: 'eq-forque' }],
      [/^en\.f\.(dl\..*|notesIntro|notesHead)$/, OUT('script', 'steps/forque')],
      [/./, CS],
    ],
    'springCopy.js': [
      [/^en\.s\.title$/, CH],
      [/^en\.s\.lede$/, { k: 'lead', p: 'steps/spring', s: 'intro' }],
      [/^en\.s\.(ladder\.\d+\.say|ladderCap)$/, { k: 'body', p: 'steps/spring', s: 'sr-ladder' }],
      [/^en\.s\.threads\.\w+\.h$/, CH],
      [/^en\.s\.threads\.(\w+)\.q$/, m => ({ k: 'lead', p: 'steps/spring', s: `sr-${m[1]}` })],
      [/^en\.s\.threads\.(\w+)\.(which|mech|cube|alg)$/, m => ({ k: 'body', p: 'steps/spring', s: `sr-${m[1]}` })],
      [/^en\.s\.w\.osc\.\w+$/, { k: 'cap', p: 'steps/spring', s: 'sr-oscillator', f: 'spring-oscillator' }],
      [/^en\.s\.w\.(cube|spec)\.\w+$/, { k: 'cap', p: 'steps/spring', s: 'intro', f: 'spring-cube' }],
      [/^en\.s\.w\.face\.\w+$/, { k: 'cap', p: 'steps/spring', s: 'sr-faces', f: 'spring-faces' }],
      [/^en\.s\.w\.lab\.\w+$/, { k: 'cap', p: 'steps/spring', s: 'sr-labels', f: 'signed-network' }],
      [/^en\.s\.(tabNote|mxLede|num)$/, { k: 'cap', p: 'steps/spring', s: 'eq-spring', f: 'spring-table' }],
      [/^en\.s\.next$/, { k: 'next', p: 'steps/spring', s: 'intro' }],
      [/^en\.s\.open\.\d+\.1$/, { k: 'stmt', p: 'steps/spring', s: 'eq-spring' }],
      [/^en\.s\.dl\..*$/, OUT('script', 'steps/spring')],
      [/./, CS],
    ],
    'rigidCopy.js': [
      [/^(PROD_FACTS|BENCH_FACTS|BENCH_NOISE|NOISY|PROD_NS)\b.*$/, OUT('script', 'steps/rigid')],
      [/^en\.s\.title$/, CH],
      [/^en\.s\.lede$/, { k: 'lead', p: 'steps/rigid', s: 'intro' }],
      [/^en\.s\.(ladder\.\d+\.say|ladderCap)$/, { k: 'body', p: 'steps/rigid', s: 'rg-ladder' }],
      [/^en\.s\.threads\.\w+\.h$/, CH],
      [/^en\.s\.threads\.(\w+)\.q$/, m => ({ k: 'lead', p: 'steps/rigid', s: `rg-${m[1]}` })],
      [/^en\.s\.threads\.(\w+)\.(which|mech|cube|alg)$/, m => ({ k: 'body', p: 'steps/rigid', s: `rg-${m[1]}` })],
      [/^en\.s\.w\.seg\.\w+$/, { k: 'cap', p: 'steps/rigid', s: 'rg-segment', f: 'rigid-segment' }],
      [/^en\.s\.w\.sq\.\w+$/, { k: 'cap', p: 'steps/rigid', s: 'rg-square', f: 'rigid-square' }],
      [/^en\.s\.w\.lab\.\w+$/, { k: 'cap', p: 'steps/rigid', s: 'rg-cube', f: null }],
      [/^en\.s\.w\.table\.\w+$/, { k: 'cap', p: 'steps/rigid', s: 'rg-frame', f: 'rigid-frame-table' }],
      [/^en\.s\.w\.hang\.\w+$/, { k: 'cap', p: 'steps/rigid', s: 'rg-hang', f: 'hang-it' }],
      [/^en\.s\.w\.top\.(\w+|kinds\.\w+)$/, { k: 'cap', p: 'steps/rigid', s: 'rg-top', f: 'free-top' }],
      [/^en\.s\.w\.orb\.(\w+|cap\.\w+)$/, { k: 'cap', p: 'steps/rigid', s: 'intro', f: 'pga-orbits' }],
      [/^en\.s\.(mxLede|num)$/, { k: 'cap', p: 'steps/rigid', s: 'eq-rigid', f: 'rigid-matrix' }],
      [/^en\.s\.next$/, { k: 'next', p: 'steps/rigid', s: 'intro' }],
      [/^en\.s\.open\.\d+\.1$/, { k: 'stmt', p: 'steps/rigid', s: 'eq-rigid' }],
      [/^en\.s\.dl\..*$/, OUT('script', 'steps/rigid')],
      [/./, CS],
    ],
    'plainStepsCopy.js': [
      [/^PLAIN\.en\.(\w+)\.story\.\d+$/, m => ({ k: 'yl', t: null, p: `steps/${m[1]}`, s: 'intro' })],
      [/^PLAIN\.en\.(\w+)\.try$/, m => ({ k: 'try', p: `steps/${m[1]}`, s: TRY_SEC[m[1]] })],
      [/^PLAIN\.en\.projective\.nullCap$/, { k: 'yl', t: L('projectiveCopy.js', 'en.p1.nullCap'), p: 'steps/projective', s: 'pj-null' }],
      [/^PLAIN\.en\.forque\.cap$/, { k: 'yl', t: L('forqueCopy.js', 'en.f.racketCap'), p: 'steps/forque', s: 'intro' }],
      [/^PLAIN\.en\.spin\.dial\.(cap|double)$/, m => ({ k: 'yl', t: L('spinCopy.js', `en.s.w.reflect.${m[1]}`), p: 'steps/spin', s: 'sp-reflect' })],
      [/^PLAIN\.en\.spring\.cube\.(cap|capMode|capPluck)$/, m => ({ k: 'yl', t: L('springCopy.js', `en.s.w.cube.${m[1]}`), p: 'steps/spring', s: 'intro' })],
      [/^PLAIN\.en\.rigid\.hang\.cap$/, { k: 'yl', t: L('rigidCopy.js', 'en.s.w.hang.cap'), p: 'steps/rigid', s: 'rg-hang' }],
      [/^PLAIN\.en\.nullsurf\.cone\.cap$/, { k: 'yl', t: null, p: 'steps/nullsurf', s: 'intro' }],
      [/^PLAIN\.en\.nullsurf\.cone\.aria$/, OUT('controls', 'steps/nullsurf')],
      [/^PLAIN\.en\.(\w+)\.hedges\.\d+\.1$/, m => ({ k: 'yl', t: null, p: `steps/${m[1]}`, s: HEDGE_SEC[m[1]] })],
      [/^PLAIN\.en\.\w+\.title$/, CH],
      [/^PLAIN\.en\.tally\..*$/, OUT('tally', 'logbook')],
      [/./, CS],
    ],
    'fureyCopy.js': [
      [/^fc\.ui\.calib$/, { k: 'body', p: 'matter', s: 'intro', r: 'detail' }],
      [/^fc\.ui\.calibY$/, { k: 'yl', t: L('fureyCopy.js', 'fc.ui.calib'), p: 'matter', s: 'intro' }],
      [/^fc\.ui\.report$/, OUT('script', 'matter')],
      [/^fc\.(earlier|findings|threegen|help)\.lede$/, m => ({ k: 'lead', p: FUREY_PAGE[m[1]], s: 'intro' })],
      [/^fc\.(earlier|findings|threegen|help)\.short\.0$/, m => ({ k: 'yl', t: L('fureyCopy.js', `fc.${m[1]}.lede`), p: FUREY_PAGE[m[1]], s: 'intro' })],
      [/^fc\.(earlier|findings|threegen|help)\.short\.1$/, m => ({ k: 'short', t: L('fureyCopy.js', `fc.${m[1]}.lede`) })],
      [/^fc\.(earlier|findings|threegen|help)\.(eyebrow|title|titleY)$/, CH],
      [/^fc\.help\.secs\.take\..*$/, OUT('script', 'matter/help')],
      [/^fc\.(earlier|findings|threegen|help)\.secs\.(\w+)\.yl\.\d+$/, m => ({ k: 'yl', t: null, p: FUREY_PAGE[m[1]], s: m[2] })],
      [/^fc\.(earlier|findings|threegen|help)\.secs\.(\w+)\.(p|m)\.\d+\.1$/, m => ({ k: 'stmt', p: FUREY_PAGE[m[1]], s: m[2] })],
      [/^fc\.earlier\.papers\.\w+\.t$/, CH],
      [/^fc\.earlier\.papers\.\w+\.(builds|repro)$/, { k: 'body', p: 'matter/papers', s: 'timeline' }],
      [/^fc\.earlier\.papers\.(\w+)\.yb$/, m => ({ k: 'yl', t: L('fureyCopy.js', `fc.earlier.papers.${m[1]}.builds`), p: 'matter/papers', s: 'timeline' })],
      [/^fc\.earlier\.papers\.(\w+)\.yr$/, m => ({ k: 'yl', t: L('fureyCopy.js', `fc.earlier.papers.${m[1]}.repro`), p: 'matter/papers', s: 'timeline' })],
      [/^fc\.earlier\.cpDetail\.\d+\.(she|ours)$/, { k: 'body', p: 'matter/papers', s: 'checkpoints' }],
      [/^fc\.earlier\.cpDetailY\.(\d+)\.(she|ours)$/, m => ({ k: 'yl', t: L('fureyCopy.js', `fc.earlier.cpDetail.${m[1]}.${m[2]}`), p: 'matter/papers', s: 'checkpoints' })],
      [/^fc\.findings\.cards\.(\w+)\.(p|m)$/, m => ({ k: 'stmt', p: 'matter/model', s: CARD_SEC[m[1]] })],
      [/^fc\.findings\.cards\.(\w+)\.yl$/, m => ({ k: 'yl', t: L('fureyCopy.js', `fc.findings.cards.${m[1]}.p`), p: 'matter/model', s: CARD_SEC[m[1]] })],
      [/^fc\.findings\.w\.peirce\.glue$/, { k: 'cap', p: 'matter/model', s: 'blocks', f: null }],
      [/^fc\.threegen\.w\.comp\.note$/, { k: 'cap', p: 'matter/generations', s: 'composite', f: 'furey-composites' }],
      [/^fc\.threegen\.ylw\.comp\.note$/, { k: 'yl', t: L('fureyCopy.js', 'fc.threegen.w.comp.note'), p: 'matter/generations', s: 'composite' }],
      [/^fc\.help\.qy\.\d+$/, { k: 'yl', t: null, p: 'matter/help', s: 'questions' }],
      [/^fc\.help\.eyebrow$/, CH],
      [/./, CS],
    ],
    'findingsData.js': [
      [/^FINDINGS\.(\d+)\.en\.(Physicist|Mathematician)\.1$/, m => ({ k: 'stmt', p: 'matter/model', s: FIND_SEC[Number(m[1])] })],
      [/^FINDINGS\.(\d+)\.en\.Young Learner\.1$/, m => ({ k: 'yl', t: L('findingsData.js', `FINDINGS.${m[1]}.en.Physicist.1`), p: 'matter/model', s: FIND_SEC[Number(m[1])] })],
      [/^FINDINGS_UI\.en\.repro$/, OUT('script', 'matter/model')],
      [/./, CS],
    ],
    'DictionarySection.jsx': [
      [/^UI\.en\.lede$/, { k: 'lead', p: 'matter/dictionary', s: 'intro' }],
      [/^UI\.en\.dlText$/, OUT('script', 'matter/dictionary')],
      [/^UI\.en\.(priCap|simCap|priGrid|antiNote)$/, { k: 'cap', p: 'matter/dictionary', s: 'fy-dict', f: 'dictionary-boards' }],
      [/^UI\.en\.open$/, { k: 'stmt', p: 'matter/dictionary', s: 'fy-dict', tags: ['open'] }],
      [/^STAGE\.en\.\d+\.1$/, { k: 'body', p: 'matter/dictionary', s: 'fy-stages' }],
      [/^STAGE\.en\.(\d+)\.0$/, m => ({ k: 'yl', t: L('DictionarySection.jsx', `STAGE.en.${m[1]}.1`), p: 'matter/dictionary', s: 'fy-stages' })],
      [/^TAIL\.en\.1$/, { k: 'body', p: 'matter/dictionary', s: 'fy-stages' }],
      [/^TAIL\.en\.0$/, { k: 'yl', t: L('DictionarySection.jsx', 'TAIL.en.1'), p: 'matter/dictionary', s: 'fy-stages' }],
      [/^CARTAN_INFO\.\w+\.en$/, { k: 'body', p: 'matter/dictionary', s: 'fy-cartan' }],
      [/^YL\.en\.priCap$/, { k: 'yl', t: L('DictionarySection.jsx', 'UI.en.priCap'), p: 'matter/dictionary', s: 'fy-dict' }],
      [/^YL\.en\.prime8$/, { k: 'yl', t: L('DictionarySection.jsx', 'UI.en.priGrid'), p: 'matter/dictionary', s: 'fy-dict' }],
      [/^YL\.en\.anti$/, { k: 'yl', t: L('DictionarySection.jsx', 'UI.en.antiNote'), p: 'matter/dictionary', s: 'fy-dict' }],
      [/^YL\.en\.open$/, { k: 'yl', t: L('DictionarySection.jsx', 'UI.en.open'), p: 'matter/dictionary', s: 'fy-dict' }],
      [/^YL\.en\.(boxesIntro|numsH)$/, { k: 'yl', t: null, p: 'matter/dictionary', s: 'fy-dict' }],
      [/^YL\.en\.cart$/, { k: 'yl', t: null, p: 'matter/dictionary', s: 'fy-cartan' }],
      [/^YL\.en\.fano\.\d+$/, { k: 'yl', t: null, p: 'matter/dictionary', s: 'fy-fano' }],
      [/./, CS],
    ],
    'categoryCopy.js': [
      [/^COPY\.(yl\.)?en\.title$/, CH],
      [/^COPY\.en\.first\.ledeP$/, { k: 'lead', p: 'steps/category', s: 'intro' }],
      [/^COPY\.en\.first\.ledeM$/, { k: 'leadM', t: L('categoryCopy.js', 'COPY.en.first.ledeP') }],
      [/^COPY\.yl\.en\.sentence$/, { k: 'yl', t: L('categoryCopy.js', 'COPY.en.first.ledeP'), p: 'steps/category', s: 'intro' }],
      [/^COPY\.yl\.en\.define$/, { k: 'yl', t: null, p: 'steps/category', s: 'intro' }],
      [/^COPY\.en\.first\.scope\.\d+\.t$/, { k: 'stmt', p: 'steps/category', s: 'cat-first' }],
      [/^COPY\.en\.first\.stm\.\d+\.t$/, { k: 'stmt', p: 'steps/category', s: 'cat-first', r: 'detail' }],
      [/^COPY\.en\.(zero|arrows|more|questions)\.intro$/, m => ({ k: 'lead', p: 'steps/category', s: `cat-${m[1]}` })],
      [/^COPY\.en\.defs\.items\.\d+\.\d+$/, { k: 'stmt', p: 'steps/category', s: 'cat-defs' }],
      [/^COPY\.en\.(\w+)\.ftitle$/, m => ({ k: 'ftitle', p: 'steps/category', s: `cat-${m[1]}` })],
      [/^COPY\.en\.(\w+)\.h$/, CH],
      [/^COPY\.en\.(zero|label0|twozeros|frobenius|moves|top|cube|bottom|arrows|deadends|refine|honest)\.pts\.\d+\.t$/, m => ({ k: 'stmt', p: 'steps/category', s: `cat-${m[1]}` })],
      [/^COPY\.en\.bottom\.(intro\.t|rows\.\d+\.\d+)$/, { k: 'stmt', p: 'steps/category', s: 'cat-bottom' }],
      [/^COPY\.en\.moves\.tab\.\d+\.\d+$/, { k: 'stmt', p: 'steps/category', s: 'cat-moves' }],
      [/^COPY\.en\.(frobenius\.links|top\.gosset|refine\.note)$/, m => ({ k: 'body', p: 'steps/category', s: `cat-${m[1].split('.')[0]}` })],
      [/^COPY\.en\.more\.items\.\d+\.title$/, { k: 'ftitle', p: 'steps/category', s: 'cat-more' }],
      [/^COPY\.en\.more\.items\.\d+\.text$/, { k: 'stmt', p: 'steps/category', s: 'cat-more' }],
      [/^COPY\.en\.papers\.items\.\d+\.h$/, CH],
      [/^COPY\.en\.papers\.items\.\d+\.t$/, { k: 'stmt', p: 'steps/category', s: 'cat-papers' }],
      [/^COPY\.en\.persp\.items\.(\d+)\.pts\.\d+\.t$/, m => ({ k: 'stmt', p: 'steps/category', s: `cat-p${Number(m[1]) + 1}` })],
      [/^COPY\.en\.questions\.items\.\d+\.t$/, { k: 'stmt', p: 'steps/category', s: 'cat-questions' }],
      [/^COPY\.en\.questions\.items\.\d+\.(chk|not)$/, { k: 'body', p: 'steps/category', s: 'cat-questions', r: 'detail' }],
      [/^COPY\.en\.bar\.note$/, OUT('lens-room', 'steps/category')],
      [/^COPY\.en\.script\.note$/, OUT('script', 'steps/category')],
      [/^COPY\.yl\.en\.(zero|label0|twozeros|frobenius|moves|top|cube|deadends|honest)\.pts\.\d+\.t$/, m => ({ k: 'yl', t: null, p: 'steps/category', s: `cat-${m[1]}` })],
      [/^COPY\.yl\.en\.(bar|older)$/, m => (m[1] === 'bar' ? OUT('lens-room', 'steps/category') : CH)],
      [/^THM\.\d+\.en\.\d+$/, { k: 'stmt', p: 'steps/category', s: 'cat-defs' }],
      [/^THM_WORDS\..*$/, CH],
      [/./, CS],
    ],
    'categoryWidgetsCopy.js': [
      [/^CWC\.en\.cw(\d)\.pm\.(caps|capsM)\.\d+\.1$/, m => ({ k: 'cap', p: 'steps/category', s: CW[m[1]][0], f: CW[m[1]][1] })],
      [/^CWC\.en\.cw(\d)\.yl\.caps\.\d+\.1$/, m => ({ k: 'yl', t: null, p: 'steps/category', s: CW[m[1]][0] })],
      [/^CWC\.en\.cw(\d)\.pm\.prov$/, m => OUT('script', 'steps/category')],
      [/^CWC\.en\.cw(\d)\.pm\.([\w.]+)$/, m => ({ k: 'cap', p: 'steps/category', s: CW[m[1]][0], f: CW[m[1]][1] })],
      [/^CWC\.en\.cw(\d)\.yl\.([\w.]+)$/, (m, v) => ({ k: 'yl', t: v(L('categoryWidgetsCopy.js', `CWC.en.cw${m[1]}.pm.${m[2]}`)) != null ? L('categoryWidgetsCopy.js', `CWC.en.cw${m[1]}.pm.${m[2]}`) : null, p: 'steps/category', s: CW[m[1]][0] })],
      [/^CWC\.en\.(badge|script)\..*$/, m => (m[1] === 'script' ? OUT('script', 'steps/category') : OUT('controls', 'steps/category'))],
      [/./, CS],
    ],
    'categoryIntegration.js': [
      [/^MAP_TEXT\.en\.category\.1$/, { k: 'body', p: 'steps/category', s: 'intro', r: 'detail' }],
      [/^MAP_TEXT\.en\.cat_(\w+)\.1$/, m => ({ k: 'lead', p: 'steps/category', s: `cat-${m[1]}` })],
      [/^MAP_TEXT\.yl\.en\.(\w+)\.1$/, m => ({ k: 'yl', t: L('categoryIntegration.js', `MAP_TEXT.en.${m[1]}.1`), p: 'steps/category', s: m[1] === 'category' ? 'intro' : `cat-${m[1].replace(/^cat_/, '')}` })],
      [/^PERSONA$/, OUT('persona', 'ask')],
      [/./, CS],
    ],
    'baezCopy.js': [
      [/^COPY\.(yl\.)?en\.(title|older)$/, CH],
      [/^COPY\.en\.lede$/, { k: 'lead', p: 'steps/baez', s: 'intro' }],
      [/^COPY\.en\.ledeMath$/, { k: 'leadM', t: L('baezCopy.js', 'COPY.en.lede') }],
      [/^COPY\.yl\.en\.sentence$/, { k: 'yl', t: L('baezCopy.js', 'COPY.en.lede'), p: 'steps/baez', s: 'intro' }],
      [/^COPY\.en\.scope$/, { k: 'lead', p: 'steps/baez', s: 'bz-top' }],
      [/^COPY\.en\.ledePts\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-top' }],
      [/^COPY\.en\.(words|mIntro)$/, { k: 'body', p: 'steps/baez', s: 'bz-top', r: 'detail' }],
      [/^COPY\.en\.ledeM\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-top', r: 'detail' }],
      [/^COPY\.en\.(thmH|thmLangNote|papersLangNote|catLink|step9Link|step13Link|sec\.\w+)$/, CH],
      [/^COPY\.en\.papersIntro$/, { k: 'lead', p: 'steps/baez', s: 'bz-papers' }],
      [/^COPY\.en\.papers\.\w+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-papers' }],
      [/^COPY\.en\.papersPts\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-papers', r: 'detail' }],
      [/^COPY\.en\.findings\.(\d+)\.title$/, m => { const f = BZ_FIND[bzFinding(m[1])]; if (!f) throw new Error(`Baez finding ${bzFinding(m[1])} has no section`); return { k: 'ftitle', p: 'steps/baez', s: f[0] }; }],
      [/^COPY\.en\.findings\.(\d+)\.lines\.\d+\.1$/, m => { const f = BZ_FIND[bzFinding(m[1])]; if (!f) throw new Error(`Baez finding ${bzFinding(m[1])} has no section`); return { k: 'stmt', p: 'steps/baez', s: f[0], ...(f[1] ? { r: f[1] } : {}) }; }],
      [/^COPY\.en\.tenCap\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-ten' }],
      [/^COPY\.en\.whichHook$/, { k: 'body', p: 'steps/baez', s: 'bz-which' }],
      [/^COPY\.en\.numbers\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-numbers' }],
      [/^COPY\.en\.gapsIntro\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-gaps' }],
      [/^COPY\.en\.gaps\.\w+\.\d+$/, { k: 'body', p: 'steps/baez', s: 'bz-gaps' }],
      [/^COPY\.en\.(limits|dead)\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-gaps' }],
      // the intros BaezSection.jsx prints first in a section (questionsIntro is shorter than a prose block: a short lead, step 3)
      [/^COPY\.en\.(perspIntro|notesIntro|questionsIntro)$/, m => ({ k: 'lead', p: 'steps/baez', s: { perspIntro: 'bz-persp', notesIntro: 'bz-notes', questionsIntro: 'bz-questions' }[m[1]] })],
      [/^COPY\.en\.persp\.\d+\.(q|text|more\.\d+\.1)$/, { k: 'stmt', p: 'steps/baez', s: 'bz-persp' }],
      [/^COPY\.en\.questions\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-questions' }],
      [/^COPY\.en\.notes\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-notes' }],
      [/^COPY\.en\.honest\.\d+\.1$/, { k: 'stmt', p: 'steps/baez', s: 'bz-honest' }],
      [/^COPY\.en\.barNote$/, OUT('lens-room', 'steps/baez')],
      [/^COPY\.(yl\.)?en\.(scriptText|widgetsScript)$/, OUT('script', 'steps/baez')],
      [/^COPY\.yl\.en\.(generation|papers|kepler|ring|periodic|numbers|honest)\.\d+\.1$/, m => ({ k: 'yl', t: null, p: 'steps/baez', s: `bz-${m[1]}` })],
      [/^COPY\.yl\.en\.keplerWord$/, { k: 'yl', t: null, p: 'steps/baez', s: 'bz-kepler' }],
      [/^COPY\.yl\.en\.gapsIntro\.1$/, { k: 'yl', t: null, p: 'steps/baez', s: 'bz-gaps' }],
      [/^PAPERS\.\d+\.title$/, CH],
      [/./, CS],
    ],
    'baezWidgetsCopy.js': [
      [/^BWC\.en\.prov\..*$/, OUT('script', 'steps/baez')],
      [/^BWC\.en\.script\..*$/, OUT('script', 'steps/baez')],
      [/^BWC\.en\.bw(\d)\.(cap|edges\.\w)\.\d+\.1$/, m => ({ k: 'cap', p: 'steps/baez', s: BW[m[1]][0], f: BW[m[1]][1] })],
      [/^BWC\.en\.bw1\.capY\.([0-3])\.1$/, m => ({ k: 'yl', t: L('baezWidgetsCopy.js', `BWC.en.bw1.cap.${BW1_CAPY[m[1]]}.1`), toFormal: true, p: 'steps/baez', s: BW[1][0] })],
      [/^BWC\.en\.bw(\d)\.(capY|edgesY\.\w)\.\d+\.1$/, m => ({ k: 'yl', t: null, p: 'steps/baez', s: BW[m[1]][0] })],
      [/^BWC\.en\.bw(\d)\.(intro|note16|none56|picture)$/, m => ({ k: 'cap', p: 'steps/baez', s: BW[m[1]][0], f: BW[m[1]][1] })],
      [/^BWC\.en\.bw(\d)\.(intro|picture)Y$/, m => ({ k: 'yl', t: L('baezWidgetsCopy.js', `BWC.en.bw${m[1]}.${m[2]}`), p: 'steps/baez', s: BW[m[1]][0] })],
      [/./, CS],
    ],
    'baezIntegration.js': [
      [/^MAP_TEXT\.en\.baez\.1$/, { k: 'body', p: 'steps/baez', s: 'intro', r: 'detail' }],
      [/^MAP_TEXT\.en\.bz_(\w+)\.1$/, m => ({ k: 'lead', p: 'steps/baez', s: `bz-${m[1]}` })],
      [/^MAP_TEXT\.yl\.en\.bz_papers\.1$/, { k: 'yl', t: L('baezCopy.js', 'COPY.en.papersIntro'), p: 'steps/baez', s: 'bz-papers' }],
      [/^MAP_TEXT\.yl\.en\.(\w+)\.1$/, m => ({ k: 'yl', t: L('baezIntegration.js', `MAP_TEXT.en.${m[1]}.1`), p: 'steps/baez', s: m[1] === 'baez' ? 'intro' : `bz-${m[1].replace(/^bz_/, '')}` })],
      [/^PERSONA$/, OUT('persona', 'ask')],
      [/./, CS],
    ],
    'schullerCopy.js': [
      [/^COPY\.(yl\.)?en\.title$/, CH],
      [/^COPY\.en\.first\.lede$/, { k: 'lead', p: 'steps/schuller', s: 'intro' }],
      [/^COPY\.en\.first\.ledeM$/, { k: 'leadM', t: L('schullerCopy.js', 'COPY.en.first.lede') }],
      [/^COPY\.yl\.en\.lede$/, { k: 'yl', t: L('schullerCopy.js', 'COPY.en.first.lede'), p: 'steps/schuller', s: 'intro' }],
      [/^COPY\.yl\.en\.intro\.\d+$/, { k: 'yl', t: null, p: 'steps/schuller', s: 'intro' }],
      [/^COPY\.en\.first\.(disclaimer|full\.\d+|scope)$/, { k: 'body', p: 'steps/schuller', s: 'intro', r: 'detail' }],
      [/^COPY\.en\.first\.statements\.\d+\.lines\.\d+\.1$/, { k: 'stmt', p: 'steps/schuller', s: 'sc-first', r: 'detail' }],
      [/^COPY\.en\.(chain|table|hyper|persp|notes|thm)\.intro$/, m => ({ k: 'lead', p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.en\.quantum\.read$/, { k: 'lead', p: 'steps/schuller', s: 'sc-quantum' }],
      [/^COPY\.en\.(\w+)\.findings\.\d+\.title$/, m => ({ k: 'ftitle', p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.en\.(\w+)\.findings\.\d+\.lines\.\d+\.1$/, m => ({ k: 'stmt', p: 'steps/schuller', s: `sc-${m[1]}`, ...(SC_FOLDED.has(m[1]) ? { r: 'detail' } : {}) })],
      [/^COPY\.en\.fibre\.(mass\.lines\.\d+\.1|ladder\.1)$/, { k: 'stmt', p: 'steps/schuller', s: 'sc-fibre' }],
      [/^COPY\.en\.(fibre\.convention|fock\.tableCap)$/, m => ({ k: 'body', p: 'steps/schuller', s: `sc-${m[1].split('.')[0]}` })],
      [/^COPY\.en\.(stops|quantum|notes|questions|honest)\.items\.\d+\.1$/, m => ({ k: 'stmt', p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.en\.persp\.items\.\d+\.lines\.\d+\.1$/, { k: 'stmt', p: 'steps/schuller', s: 'sc-persp' }],
      [/^COPY\.en\.thm\.items\.\d+\.line\.1$/, { k: 'stmt', p: 'steps/schuller', s: 'sc-thm' }],
      [/^COPY\.en\.bar\.note$/, OUT('lens-room', 'steps/schuller')],
      [/^COPY\.en\.scripts\..*$/, OUT('script', 'steps/schuller')],
      [/^COPY\.en\.sources\..*$/, OUT('logbook', 'steps/schuller')],
      [/^COPY\.yl\.en\.(chain|table|hyper)\.text\.0$/, m => ({ k: 'yl', t: L('schullerCopy.js', `COPY.en.${m[1]}.intro`), p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.yl\.en\.(\w+)\.text\.\d+$/, m => ({ k: 'yl', t: null, p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.yl\.en\.(\w+)\.lines\.\d+\.1$/, m => ({ k: 'yl', t: null, p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^COPY\.yl\.en\.bar\.text$/, OUT('lens-room', 'steps/schuller')],
      [/^COPY\.yl\.en\.scripts\.text$/, OUT('script', 'steps/schuller')],
      [/./, CS],
    ],
    'schullerWidgetsCopy.js': [
      [/^SWC\.en\.sw(\d)\.pm\.caps\.\d+\.1$/, m => ({ k: 'cap', p: 'steps/schuller', s: SW[m[1]][0], f: SW[m[1]][1] })],
      [/^SWC\.en\.sw(\d)\.yl\.caps\.\d+\.1$/, m => ({ k: 'yl', t: null, p: 'steps/schuller', s: SW[m[1]][0] })],
      [/^SWC\.en\.sw(\d)\.pm\.prov$/, OUT('script', 'steps/schuller')],
      [/^SWC\.en\.sw(\d)\.pm\.([\w.]+)$/, m => ({ k: 'cap', p: 'steps/schuller', s: SW[m[1]][0], f: SW[m[1]][1] })],
      [/^SWC\.en\.sw(\d)\.yl\.([\w.]+)$/, (m, v) => ({ k: 'yl', t: v(L('schullerWidgetsCopy.js', `SWC.en.sw${m[1]}.pm.${m[2]}`)) != null ? L('schullerWidgetsCopy.js', `SWC.en.sw${m[1]}.pm.${m[2]}`) : null, p: 'steps/schuller', s: SW[m[1]][0] })],
      [/^SWC\.en\.script\..*$/, OUT('script', 'steps/schuller')],
      [/./, CS],
    ],
    'schullerIntegration.js': [
      [/^MAP_TEXT\.en\.schuller\.1$/, { k: 'body', p: 'steps/schuller', s: 'intro', r: 'detail' }],
      [/^MAP_TEXT\.en\.sc_(\w+)\.1$/, m => ({ k: 'lead', p: 'steps/schuller', s: `sc-${m[1]}` })],
      [/^MAP_TEXT\.yl\.en\.(\w+)\.1$/, m => ({ k: 'yl', t: L('schullerIntegration.js', `MAP_TEXT.en.${m[1]}.1`), p: 'steps/schuller', s: m[1] === 'schuller' ? 'intro' : `sc-${m[1].replace(/^sc_/, '')}` })],
      [/^PERSONA$/, OUT('persona', 'ask')],
      [/./, CS],
    ],
    'lensesCopy.js': [[/^TABS_LBL\.en$/, CH], [/./, CS]],
    'inputsData.js': [
      [/^NEEDS\.([\w/]+)\.inputs\.\d+\.1$/, m => ({ k: 'stmt', p: NEEDS_PAGE(m[1]), s: 'needs' })],
      [/^NEEDS\.([\w/]+)\.inputs\.\d+\.2$/, m => OUT('input-long', NEEDS_PAGE(m[1]))],   // the whole statement behind v15's "more"; the INP row holds the short form
      [/^NEEDS\.([\w/]+)\.yl$/, m => ({ k: 'yl', t: null, p: NEEDS_PAGE(m[1]), s: 'needs' })],
      [/^NEEDS_COPY\.(yl\.)?help$/, OUT('controls')],
      [/./, CS],
    ],
    'atlasLines.js': [[/^ATLAS_LINES\.\w+\.lines\.\d+\.en$/, { k: 'stmt', p: 'cells', s: 'cards' }], [/./, CS]],
    'ylAtlas.js': [[/^YL_STATUS\.en\.(\w+)$/, m => ({ k: 'yl', t: L('cellStatusCopy.js', `CELL_STATUS.en.${m[1]}`), p: 'cells', s: 'cards' })], [/./, CS]],
    'cellStatusCopy.js': [[/^CELL_STATUS\.en\.\w+$/, { k: 'body', p: 'cells', s: 'cards' }], [/./, CS]],
    'proofs.js': [[/.*/, OUT('proofs', 'cells')]],
    'storyOverrides.js': [[/.*/, OUT('overrides', 'cells')]],
    'mapCopy.js': [[/.*/, OUT('logbook', 'logbook')]],
    'researchersCopy.js': [[/.*/, OUT('logbook', 'logbook')]],
    'researchersData.js': [[/.*/, OUT('logbook', 'logbook')]],
    'researcherNotes.js': [[/.*/, OUT('logbook', 'logbook')]],
    'steps.js': [[/^(STEP_NAMES|STEP_NAMES_YL|NAV_NAMES|NAV_NAMES_YL)\.en\.\w+$/, CH], [/./, CS]],
  };
}

// ------------------------------------------------------------------------------------------------------------------------------------ 7. the ORDER tables
// One table per V2 page, transcribed once from the v15 component that drew it (App.jsx rule page, LabelsTabs.jsx, ConventionsPage.jsx, MaxwellSection.jsx,
// ChargesWidget.jsx, ShapesSection.jsx, GossetSection.jsx, EquationsSection.jsx and the step sections, FureyPage.jsx and its tabs, DictionarySection.jsx,
// BaezSection.jsx FormalBody, SchullerSection.jsx, CategorySection.jsx, LensesSection.jsx). Per page: g, the group of the page's narration ids (§1.3);
// sec, the sections in v15's render order — id, t and ty the locators of the title (v15's menu label or heading) and of the learner title, f the figure
// (the V2 port of the v15 widget that sat there; the intro's figure is the hero's), part, g (a group of its own, shapes), from (sections of pages.json whose
// rows move here: the "(figure)" sections and the frames of the page strips) — and place (rows placed by hand where v15 drew them beside a widget).
// sub: a page that is a tab of another (route, parent, tab, title locators).
const T = L;
const NAV = (k, y) => T('steps.js', `${y ? 'NAV_NAMES_YL' : 'NAV_NAMES'}.en.${k}`);
const NODE = (k, y) => T('mapCopy.js', `${y ? 'NODES_YL' : 'NODES'}.en.${k}.0`);
const NEEDS_SEC = { id: 'needs', t: T('inputsData.js', 'NEEDS_COPY.inputs'), ty: T('inputsData.js', 'NEEDS_COPY.yl.aria') };
const TALLY_SEC = { id: 'summary', t: NAV('tally'), ty: NAV('tally', 1) };
const BZ = (k, y) => T('baezCopy.js', `COPY.${y ? 'yl.' : ''}en.menu.${k}`);
const SC = (k, y) => T('schullerCopy.js', `COPY.${y ? 'yl.' : ''}en.menu.${k}`);
const CAT = (k, y) => T('categoryCopy.js', `COPY.${y ? 'yl.' : ''}en.menu.${k}`);
const FY = (tab, s, y) => T('fureyCopy.js', `fc.${tab}.secs.${s}.${y ? 'hy' : 'h'}`);
const LAB = (w, y) => T('labelsCopy.js', `COPY.en.${w}.${y ? 'titleY' : 'title'}`);
const ladderPage = (g, base, file, eq, checks, fig, extra = []) => ({ g, sec: [
  { id: 'intro' },
  { id: eq, t: T(file, `en.${base}xrH`) },
  ...extra,
  { id: checks, t: T(file, `en.${base}idH`), f: fig },
  TALLY_SEC, NEEDS_SEC] });
export const PAGES = {
  '': { g: 'PAG', sec: [{ id: 'intro', from: ['one-rule', 'rule'] }] },
  rule: { g: 'GEN', sec: [
    { id: 'intro', from: ['rule'] },
    { id: 'conventions', t: NAV('conventions'), ty: NAV('conventions', 1) },
    { id: 'ideas', t: T('conventionsCopy.js', 'CONV.en.ideasH'), ty: NODE('rule', 1) }] },
  cells: { g: 'ATL', sec: [
    { id: 'intro', from: ['type-and-clock'] },
    { id: 'cards', t: NODE('atlas'), ty: NODE('atlas', 1) }] },
  clock: { g: 'LAB', place: { 'LAB-003': 'clock-trinity', 'LAB-004': 'clock-biv' }, sec: [
    { id: 'intro' },
    { id: 'clock', t: LAB('lattice'), ty: LAB('lattice', 1), f: 'lattice' },
    { id: 'clock-trinity', t: LAB('trinity'), ty: LAB('trinity', 1), f: 'trinity' },
    { id: 'clock-biv', t: LAB('biv'), ty: LAB('biv', 1), f: 'bivector-lab' },
    NEEDS_SEC] },
  light: { g: 'PAG', sec: [
    { id: 'intro', from: ['maxwell'] },
    { id: 'views', t: NAV('views'), ty: NAV('views', 1), f: 'four-views-maxwell' },
    { id: 'charges', t: NAV('charges'), ty: NAV('charges', 1), f: 'charges' },
    { id: 'ladders', t: NAV('ladders'), ty: NAV('ladders', 1), f: 'maxwell-ladders' },
    TALLY_SEC, NEEDS_SEC] },
  steps: { g: 'EQN', sec: [{ id: 'intro', from: ['equations'] }] },
  'steps/comm': { g: 'EQN', sec: [{ id: 'intro' }, { id: 'eq-comm' }, { ...TALLY_SEC, f: 'comm-ladder' }] },
  'steps/mirrors': { g: 'MIR', sec: [
    { id: 'intro' },
    { id: 'eq-mirrors', t: T('mirrorsCopy.js', 'en.m1.xrH') },
    { id: 'mr-notes', t: T('mirrorsCopy.js', 'en.m1.idH') },
    TALLY_SEC, NEEDS_SEC] },
  'steps/dirac': { g: 'EQN', sec: [{ id: 'intro' }, { id: 'dirac-xref', t: T('equationsCopy.js', 'en.d.xrefH') }, TALLY_SEC, NEEDS_SEC] },
  'steps/spin': { g: 'SPN', sec: [
    { id: 'intro' },
    { id: 'sp-sources', t: T('spinCopy.js', 'en.s.srcH') },
    { id: 'sp-weave', t: T('spinCopy.js', 'en.s.weaveH') },
    { id: 'sp-ladder', t: T('spinCopy.js', 'en.s.ladderH') },
    { id: 'sp-reflect', t: T('spinCopy.js', 'en.s.threads.reflect.h'), f: 'spin-rotor' },
    { id: 'sp-labels', t: T('spinCopy.js', 'en.s.threads.labels.h') },
    { id: 'sp-unit', t: T('spinCopy.js', 'en.s.threads.unit.h') },
    { id: 'sp-spaces', t: T('spinCopy.js', 'en.s.threads.spaces.h'), f: 'spin-halves' },
    { id: 'sp-pointor', t: T('spinCopy.js', 'en.s.threads.pointor.h'), f: 'spin-pointor' },
    { id: 'sp-hest', t: T('spinCopy.js', 'en.s.w.hest.h'), f: 'spin-hestenes' },
    { id: 'sp-states', t: T('spinCopy.js', 'en.s.threads.states.h') },
    { id: 'eq-spin', t: T('spinCopy.js', 'en.s.mxH'), f: 'spin-matrix' },
    { id: 'sp-conv', t: T('spinCopy.js', 'en.s.convH') },
    { id: 'sp-auth', t: T('spinCopy.js', 'en.s.authH') },
    { id: 'sp-num', t: T('spinCopy.js', 'en.s.numH') },
    TALLY_SEC, NEEDS_SEC] },
  'steps/coupling': ladderPage('CPL', '', 'couplingCopy.js', 'eq-coupling', 'cp-checks', 'coupling-ladder'),
  'steps/ym': ladderPage('YM', '', 'yangmillsCopy.js', 'eq-ym', 'ym-checks', 'ym-ladder'),
  'steps/matter': ladderPage('MAT', '', 'matterCopy.js', 'eq-matter', 'mt-checks', 'matter-ladder'),
  'steps/grav1': ladderPage('GRV', 'g1.', 'gravityCopy.js', 'eq-grav1', 'g1-checks', 'bianchi-check', [{ id: 'g1-pic', t: T('gravityCopy.js', 'en.g1.picH'), ty: T('gravityCopy.js', 'en.g1.yl.picH'), f: 'curvature-pairs' }]),
  'steps/grav2': ladderPage('GRV', 'g2.', 'gravityCopy.js', 'eq-grav2', 'g2-checks', null, [
    { id: 'g2-pic', t: T('gravityCopy.js', 'en.g2.picH'), ty: T('gravityCopy.js', 'en.g2.yl.picH'), f: 'einstein-terms' },
    { id: 'g2-ds', t: T('gravityCopy.js', 'en.g2.dsH'), f: 'cosmological-generator' }]),
  'steps/projective': ladderPage('PRJ', 'p1.', 'projectiveCopy.js', 'eq-projective', 'pj-checks', null, [{ id: 'pj-null', t: T('projectiveCopy.js', 'en.p1.nullH'), f: 'null-pair-moves' }]),
  'steps/gauge': { g: 'LAB', sec: [{ id: 'intro' }, { id: 'eq-gauge' }, { id: 'gg-curv', t: LAB('curv'), ty: LAB('curv', 1), f: 'riemann-split' }, NEEDS_SEC] },
  'steps/nullsurf': { g: 'NUL', sec: [
    { id: 'intro' },
    { id: 'nl-res-1', t: T('nullCopy.js', 'en.cards.0.h') },
    { id: 'nl-res-2', t: T('nullCopy.js', 'en.cards.1.h'), f: 'null-neck' },
    { id: 'nl-res-3', t: T('nullCopy.js', 'en.cards.2.h'), f: 'null-criterion' },
    { id: 'nl-res-4', t: T('nullCopy.js', 'en.cards.3.h') },
    { id: 'eq-nullsurf', t: T('nullCopy.js', 'en.limitsH') },
    TALLY_SEC, NEEDS_SEC] },
  'steps/forque': { g: 'FRQ', sec: [
    { id: 'intro' },
    { id: 'fq-lines', t: T('forqueCopy.js', 'en.f.linesH'), f: 'forque-lines' },
    { id: 'eq-forque', t: T('forqueCopy.js', 'en.f.mxH'), f: 'forque-matrix' },
    TALLY_SEC, NEEDS_SEC] },
  'steps/spring': { g: 'SPR', sec: [
    { id: 'intro' },
    { id: 'sr-ladder', t: T('springCopy.js', 'en.s.ladderH') },
    { id: 'sr-oscillator', t: T('springCopy.js', 'en.s.threads.oscillator.h'), f: 'spring-oscillator' },
    { id: 'sr-vertices', t: T('springCopy.js', 'en.s.threads.vertices.h') },
    { id: 'sr-edges', t: T('springCopy.js', 'en.s.threads.edges.h') },
    { id: 'sr-faces', t: T('springCopy.js', 'en.s.threads.faces.h'), f: 'spring-faces' },
    { id: 'sr-sign', t: T('springCopy.js', 'en.s.threads.sign.h') },
    { id: 'sr-labels', t: T('springCopy.js', 'en.s.threads.labels.h'), f: 'signed-network' },
    { id: 'eq-spring', t: T('springCopy.js', 'en.s.mxH'), f: 'spring-table' },
    TALLY_SEC, NEEDS_SEC] },
  'steps/rigid': { g: 'RIG', sec: [
    { id: 'intro' },
    { id: 'rg-ladder', t: T('rigidCopy.js', 'en.s.ladderH') },
    { id: 'rg-segment', t: T('rigidCopy.js', 'en.s.threads.segment.h'), f: 'rigid-segment' },
    { id: 'rg-square', t: T('rigidCopy.js', 'en.s.threads.square.h'), f: 'rigid-square' },
    { id: 'rg-cube', t: T('rigidCopy.js', 'en.s.threads.cube.h') },
    { id: 'rg-hang', t: T('rigidCopy.js', 'en.s.threads.hang.h'), f: 'hang-it' },
    { id: 'rg-frame', t: T('rigidCopy.js', 'en.s.threads.frame.h'), f: 'rigid-frame-table' },
    { id: 'rg-top', t: T('rigidCopy.js', 'en.s.threads.top.h'), f: 'free-top' },
    { id: 'rg-orbits', t: T('rigidCopy.js', 'en.s.threads.orbits.h') },
    { id: 'eq-rigid', t: T('rigidCopy.js', 'en.s.mxH'), f: 'rigid-matrix' },
    TALLY_SEC, NEEDS_SEC] },
  'steps/groups': { g: 'LAB', sec: [
    { id: 'intro' },
    { id: 'ln-groups' },
    { id: 'gr-golay', t: LAB('golay'), ty: LAB('golay', 1), f: 'golay-ring' },
    { id: 'gr-primes', t: LAB('primes'), ty: LAB('primes', 1) },
    NEEDS_SEC] },
  'steps/category': { g: 'LNC', parts: [{ id: 'persp', t: CAT('persp'), sections: ['cat-p1', 'cat-p2', 'cat-p3', 'cat-p4', 'cat-p5', 'cat-p6'] }], sec: [
    { id: 'intro', from: ['cat-w-label0'] },
    { id: 'cat-first', t: T('categoryCopy.js', 'COPY.en.first.stmH') },
    { id: 'cat-zero', t: CAT('zero'), ty: CAT('zero', 1) },
    { id: 'cat-defs', t: CAT('defs') },
    { id: 'cat-label0', t: CAT('label0'), ty: CAT('label0', 1) },
    { id: 'cat-twozeros', t: CAT('twozeros'), ty: CAT('twozeros', 1), from: ['cat-w-twozeros'] },
    { id: 'cat-frobenius', t: CAT('frobenius'), ty: CAT('frobenius', 1), from: ['cat-w-frobenius'] },
    { id: 'cat-moves', t: CAT('moves'), ty: CAT('moves', 1), from: ['cat-w-moves'] },
    { id: 'cat-top', t: CAT('top'), ty: CAT('top', 1), from: ['cat-w-top'] },
    { id: 'cat-cube', t: CAT('cube'), ty: CAT('cube', 1), f: 'sign-flux' },
    { id: 'cat-bottom', t: CAT('bottom') },
    { id: 'cat-arrows', t: CAT('arrows') },
    { id: 'cat-more', t: CAT('more') },
    { id: 'cat-papers', t: CAT('papers') },
    { id: 'cat-deadends', t: CAT('deadends'), ty: CAT('deadends', 1) },
    { id: 'cat-refine', t: CAT('refine') },
    ...[0, 1, 2, 3, 4, 5].map(i => ({ id: `cat-p${i + 1}`, t: T('categoryCopy.js', `COPY.en.persp.items.${i}.h`), part: 'persp' })),
    { id: 'cat-questions', t: CAT('questions') },
    { id: 'cat-honest', t: CAT('honest'), ty: CAT('honest', 1) },
    TALLY_SEC, NEEDS_SEC] },
  'steps/baez': { g: 'LNB', parts: [{ id: 'limits', t: T('baezCopy.js', 'COPY.en.limitsH'), sections: ['bz-gaps', 'bz-honest'] }], sec: [
    { id: 'intro', from: ['bz-w-family'] },
    { id: 'bz-top', from: ['bz-w-which'] },
    { id: 'bz-papers', t: BZ('papers'), ty: BZ('papers', 1), from: ['bz-w-papers'] },
    { id: 'bz-generation', t: BZ('generation'), ty: BZ('generation', 1) },
    { id: 'bz-ladder', t: BZ('ladder'), f: 'e8-ladder', from: ['bz-w-ladder'] },
    { id: 'bz-which', t: BZ('which') },
    { id: 'bz-ten', t: BZ('ten') },
    { id: 'bz-kepler', t: BZ('kepler'), ty: BZ('kepler', 1), f: 'kepler-trio', from: ['bz-w-kepler'] },
    { id: 'bz-periodic', t: BZ('periodic'), ty: BZ('periodic', 1), from: ['bz-w-madelung'] },
    { id: 'bz-ring', t: BZ('ring'), ty: BZ('ring', 1), from: ['bz-w-ring'] },
    { id: 'bz-more', t: BZ('more') },
    { id: 'bz-numbers', t: BZ('numbers'), ty: BZ('numbers', 1) },
    { id: 'bz-gaps', t: BZ('gaps'), ty: BZ('gaps', 1), part: 'limits' },
    { id: 'bz-persp', t: BZ('persp') },
    { id: 'bz-questions', t: BZ('questions') },
    { id: 'bz-notes', t: BZ('notes') },
    { id: 'bz-honest', t: BZ('honest'), ty: BZ('honest', 1), part: 'limits' },
    NEEDS_SEC] },
  'steps/schuller': { g: 'LNS', parts: [
    { id: 'chain', t: T('schullerCopy.js', 'COPY.en.chain.h'), sections: ['sc-chain', 'sc-table', 'sc-hyper', 'sc-area', 'sc-deform'] },
    { id: 'fibre', t: SC('fibre'), sections: ['sc-fibre', 'sc-fock', 'sc-spin', 'sc-total', 'sc-bands'] },
    { id: 'stops', t: T('schullerCopy.js', 'COPY.en.stops.h'), sections: ['sc-stops', 'sc-quantum', 'sc-honest'] }], sec: [
    { id: 'intro', from: ['sc-w-chain'] },
    { id: 'sc-first', t: T('schullerCopy.js', 'COPY.en.first.statementsH') },
    { id: 'sc-chain', t: SC('chain'), ty: SC('chain', 1), part: 'chain' },
    { id: 'sc-table', t: SC('table'), ty: SC('table', 1), f: 'one-table', part: 'chain', from: ['sc-w-table'] },
    { id: 'sc-hyper', t: SC('hyper'), ty: SC('hyper', 1), part: 'chain', from: ['sc-w-bench'] },
    { id: 'sc-area', t: SC('area'), part: 'chain' },
    { id: 'sc-deform', t: SC('deform'), part: 'chain' },
    { id: 'sc-fibre', t: SC('fibre'), ty: SC('fibre', 1), part: 'fibre', from: ['sc-w-fibre'] },
    { id: 'sc-fock', t: SC('fock'), ty: SC('fock', 1), part: 'fibre', from: ['sc-w-seats'] },
    { id: 'sc-spin', t: SC('spin'), part: 'fibre' },
    { id: 'sc-total', t: SC('total'), ty: SC('total', 1), part: 'fibre', from: ['sc-w-magnets'] },
    { id: 'sc-bands', t: SC('bands'), ty: SC('bands', 1), f: 'bands', part: 'fibre', from: ['sc-w-bands'] },
    { id: 'sc-stops', t: SC('stops'), ty: SC('stops', 1), part: 'stops' },
    { id: 'sc-persp', t: SC('persp') },
    { id: 'sc-quantum', t: SC('quantum'), part: 'stops' },
    { id: 'sc-notes', t: SC('notes') },
    { id: 'sc-questions', t: SC('questions') },
    { id: 'sc-honest', t: SC('honest'), ty: SC('honest', 1), part: 'stops' },
    { id: 'sc-thm', t: SC('thm') },
    NEEDS_SEC] },
  shapes: { g: 'SHP', sec: [
    { id: 'intro', from: ['shapes'] },
    { id: 'sh-orth', t: NAV('orth'), ty: NAV('orth', 1), f: 'petrie-orthoplex' },
    { id: 'sh-demi', t: NAV('demi'), ty: NAV('demi', 1), f: 'zonogon' },
    { id: 'sh-gosset', t: NAV('gosset'), ty: NAV('gosset', 1), g: 'GOS' },
    NEEDS_SEC] },
  matter: { g: 'FUR', sec: [{ id: 'intro' }, { id: 'furey', t: NODE('findings'), ty: NODE('findings', 1) }, NEEDS_SEC] },
  'matter/dictionary': { g: 'FUR', sub: { parent: 'matter', tab: 'dictionary', t: NODE('dictionary'), ty: NODE('dictionary', 1) }, sec: [
    { id: 'intro' },
    { id: 'fy-stages', t: T('DictionarySection.jsx', 'UI.en.ladderH'), ty: T('DictionarySection.jsx', 'YL.en.ladderH') },
    { id: 'fy-dict', t: T('DictionarySection.jsx', 'UI.en.dictH'), f: 'dictionary-boards' },
    { id: 'fy-fano', t: T('DictionarySection.jsx', 'UI.en.fanoH'), ty: T('DictionarySection.jsx', 'YL.en.fanoH') },
    { id: 'fy-cartan', t: T('DictionarySection.jsx', 'UI.en.cartH'), ty: T('DictionarySection.jsx', 'YL.en.cartH') }] },
  'matter/papers': { g: 'FUR', sub: { parent: 'matter', tab: 'earlier', t: NODE('earlier'), ty: T('fureyCopy.js', 'fc.earlier.titleY') }, sec: [
    { id: 'intro' },
    ...['timeline', 'checkpoints', 'cascade', 'spectra', 'triality', 'fit'].map(s => ({ id: s, t: FY('earlier', s), ty: FY('earlier', s, 1),
      ...(s === 'cascade' ? { f: 'ladders' } : s === 'triality' ? { f: 'furey-trialities' } : {}) }))] },
  'matter/model': { g: 'FUR', sub: { parent: 'matter', tab: 'findings', t: NODE('findings'), ty: T('fureyCopy.js', 'fc.findings.titleY') }, sec: [
    { id: 'intro' },
    ...['blocks', 'charges', 'edges', 'axes', 'open'].map(s => ({ id: s, t: FY('findings', s), ty: FY('findings', s, 1), ...(s === 'charges' ? { f: 'furey-charges' } : {}) }))] },
  'matter/generations': { g: 'FUR', sub: { parent: 'matter', tab: 'threegen', t: NODE('threegen'), ty: NODE('threegen', 1) }, sec: [
    { id: 'intro' },
    ...['board', 'count', 'composite', 'room', 'whole'].map(s => ({ id: s, t: FY('threegen', s), ty: FY('threegen', s, 1),
      ...(s === 'board' ? { f: 'furey-board' } : s === 'composite' ? { f: 'furey-composites' } : s === 'room' ? { f: 'furey-room' } : {}) }))] },
  'matter/help': { g: 'FUR', sub: { parent: 'matter', tab: 'help', t: NODE('help'), ty: NODE('help', 1) }, sec: [
    { id: 'intro' },
    ...['results', 'questions', 'score'].map(s => ({ id: s, t: FY('help', s), ty: FY('help', s, 1) }))] },
  lenses: { g: 'LNP', sec: [{ id: 'intro', from: ['lenses'] }] },
};

// ------------------------------------------------------------------------------------------------------------------------------------ 4. the test (§1.4)
// T0 v15 printed it as a statement (a [tags, text] pair, a statement list, or a note v15 drew with tags: MAP kind stmt) · T1 a formula: the marks of R4
// (read through check_learner_texts.mjs check() on a synthetic record, the way its self-test plants records) expanded to their words, and Cl(p,q)-style
// names (R6's "cell name" identifier) · T2 a claim word (the plan's list) · T3 a free number (R6: requiredNumbers, numbers outside identifiers) ·
// T4 it restates: every T1 token and T3 number occurs in the research text of a row of the same section or of the page's hero (the reserved section
// intro introduces the whole page: its rows are the rows of the page, as the plan measured the leads); the rows it restates are a smallest cover of its
// tokens (a block with claim words only restates the row of its section that holds most of them) · T5 statuses kept: each restated row whose status is
// ours, open, cited or input has its status word in the block (R8's words, STATUS of the checker). The spans R6 names as identifiers that are not
// formulas (file and script names, arXiv numbers, dates, years of a citation, row ids, check ids such as baez·S2, step and figure numbers) are not
// read for T1. T1 is the plan's R4 mark set (marks, operators and arrows, scripts, Greek, ℝ ℂ ℍ 𝕆, ½) and the Cl(p,q)-style names: R4's lone-letter
// rule (a learner-text rule) is not a mark, and a word that is an operator alone (an "=" between spaces) names nothing, so neither is a token; the
// words around such an operator are.
const CLAIM_RE = /\b(prove|proves|proved|proof|theorem|lemma|equals|equivalent|iff|implies|unique|uniquely|exactly|always|never|isomorphic|reduces to|is given by|holds|fails|vanishes|commutes|anticommutes|squares to|must|cannot)\b/gi;
const CELL_RE = (IDENTIFIERS.find(([name]) => name === 'cell name') || [])[1];
const SYN_ROW = 'STORY-TEST';
const SYN_TABLES = { rowById: new Map([[SYN_ROW, { id: SYN_ROW, splitFrom: null }]]), research: new Map([[SYN_ROW, 'x']]), humanLearner: new Set(), glossary: [] };
const r4Messages = body => learnerCheck([{ row: SYN_ROW, lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body, status: 'draft', source: LEARNER_SOURCE, termsUsed: [], keptNumbers: [] }], SYN_TABLES)
  .filter(f => f.rule === 'R4').map(f => f.msg);
const stripEdges = w => {
  let s = w.replace(/^[,.;:!?"“”‘’'—–]+|[,.;:!?"“”‘’'—–]+$/gu, '');
  const bal = (o, c) => (s.split(o).length - 1) - (s.split(c).length - 1);
  while (s.startsWith('(') && bal('(', ')') > 0) s = s.slice(1);
  while (s.endsWith(')') && bal('(', ')') < 0) s = s.slice(0, -1);
  return s.replace(/[,.;:!?]+$/u, '');
};
/** the R6 identifiers that are names, not formulas: masked (same length, spaces) before T1 is read; a check id needs a first part of two characters */
const NOT_FORMULA = new Set(['script or file name', 'arXiv number', 'date', 'year of a citation', 'row id', 'check id', 'step, figure, equation or section number', 'step number']);
const ID_MASKS = IDENTIFIERS.filter(([name]) => NOT_FORMULA.has(name)).map(([name, re]) => [name, new RegExp(re.source, re.flags.includes('g') ? re.flags : re.flags + 'g')]);
const maskIds = t => { let s = t; for (const [name, re] of ID_MASKS) s = s.replace(re, m => (name === 'check id' && m.split('·')[0].length < 2 ? m : ' '.repeat(m.length))); return s; };
/** the formula tokens of a text (T1): the words that hold an R4 mark (with a letter or a digit), the Cl(p,q)-style names */
export function formulaTokens(text) {
  const t = maskIds(norm(text));
  let body = t; const marks = [];
  for (let guard = 0; guard < 600; guard++) {
    const hits = r4Messages(body).filter(m => !m.startsWith('single-letter variable')).map(m => (m.match(/“(.*)”$/u) || [])[1]).filter(Boolean);
    let progressed = false;
    for (const tok of hits) { const i = body.indexOf(tok); if (i < 0) continue; marks.push([i, tok.length]); body = body.slice(0, i) + '0'.repeat(tok.length) + body.slice(i + tok.length); progressed = true; }
    if (!progressed) break;
  }
  const toks = new Set();
  for (const [i, n] of marks) {
    let a = i, b = i + n;
    while (a > 0 && !/\s/.test(t[a - 1])) a--;
    while (b < t.length && !/\s/.test(t[b])) b++;
    const w = stripEdges(t.slice(a, b));
    if (w) toks.add(w);
  }
  if (CELL_RE) for (const m of t.matchAll(new RegExp(CELL_RE.source, 'g'))) toks.add(m[0].replace(/\s+/g, ''));
  return [...toks].filter(w => /[\p{L}\p{N}]/u.test(w)).sort(cmpStr);
}
/** a formula mark of R4 (or a cell name) outside the identifiers: the T1 signal, also where every mark is an operator alone */
export const hasFormulaMark = text => { const t = maskIds(norm(text)); return r4Messages(t).some(m => !m.startsWith('single-letter variable')) || (!!CELL_RE && new RegExp(CELL_RE.source).test(t)); };
export const claimWords = text => [...new Set((norm(text).match(CLAIM_RE) || []).map(w => w.toLowerCase()))].sort(cmpStr);
const tokenIn = (text, tok) => (/^\p{L}$/u.test(tok) ? new RegExp(`(?<![\\p{L}\\p{N}])${escRe(tok)}(?![\\p{L}\\p{N}])`, 'u').test(text) : text.includes(tok) || text.replace(/\s+/g, '').includes(tok.replace(/\s+/g, '')));
const claimIn = (text, w) => new RegExp(`\\b${escRe(w)}\\b`, 'i').test(text);
const STATUS_RE = Object.fromEntries(STATUS.map(([name, , inL]) => [name, inL]));
const STATUS_WORDS = { ours: ['ours'], open: ['open'], cited: ['cited', 'not proved'], input: ['input'] };
const keepsStatus = (text, status) => !STATUS_WORDS[status] || STATUS_WORDS[status].some(n => STATUS_RE[n].test(text));
/** a row of a section as the test reads it */
export const testRow = (id, text, status) => ({ id, text: norm(text || ''), numbers: numbersIn(text || ''), status: status || null });
/**
 * The test of §1.4 on one block. rows: the rows of the block's section and the page's hero (testRow records), in section order.
 * Returns { signals, t1, t2, t3, uncovered, restates, missingStatus, outcome } with outcome story | held | statement.
 */
export function testBlock(text, { t0 = false, rows = [] } = {}) {
  const t1 = formulaTokens(text), t2 = claimWords(text), t3 = requiredNumbers(text), t1mark = t1.length > 0 || hasFormulaMark(text);
  const signals = [...(t0 ? ['T0'] : []), ...(t1mark ? ['T1'] : []), ...(t2.length ? ['T2'] : []), ...(t3.length ? ['T3'] : [])];
  const res = { signals, t1, t2, t3, uncovered: [], restates: [], missingStatus: [], outcome: 'story' };
  if (!t1mark && !t2.length && !t3.length) { res.outcome = t0 ? 'statement' : 'story'; return res; }
  const items = [...t1.map(x => ['t1', x]), ...t3.map(x => ['t3', x])];
  const holds = (r, [k, x]) => (k === 't1' ? tokenIn(r.text, x) : r.numbers.has(x));
  res.uncovered = items.filter(it => !rows.some(r => holds(r, it))).map(([, x]) => x);
  let left = items.filter(it => rows.some(r => holds(r, it)));
  const chosen = [];
  while (left.length) {
    let best = null, bestN = 0;
    for (const r of rows) { if (chosen.includes(r)) continue; const n = left.filter(it => holds(r, it)).length; if (n > bestN) { best = r; bestN = n; } }
    if (!best) break;
    chosen.push(best); left = left.filter(it => !holds(best, it));
  }
  if (!items.length && t2.length) { let best = null, bestN = 0; for (const r of rows) { const n = t2.filter(w => claimIn(r.text, w)).length; if (n > bestN) { best = r; bestN = n; } } if (best) chosen.push(best); }
  res.restates = chosen.map(r => r.id);
  res.missingStatus = chosen.filter(r => !keepsStatus(text, r.status)).map(r => `${r.id} ${r.status}`);
  // T4: every token and number is covered, and a block that holds any (or a claim word) names at least one row; an operator alone names nothing
  const t4 = res.uncovered.length === 0 && (chosen.length > 0 || (!items.length && !t2.length)), t5 = res.missingStatus.length === 0;
  res.outcome = t0 ? 'statement' : t4 && t5 ? 'story' : 'held';
  return res;
}
/** windows of 40 characters every 40 of a text (the coverage test's method) */
export const windows40 = text => { const t = norm(text), out = []; for (let i = 0; i + 40 <= t.length; i += 40) out.push(t.slice(i, i + 40)); return out; };

// ------------------------------------------------------------------------------------------------------------------------------------ 3. dedupe
function makeMatcher(records) {
  // records: [{ key, body, source }]; returns (block text, locators) → [record keys]
  const bySource = new Map(), byNorm = new Map(), index = new Map();
  records.forEach((r, i) => {
    if (r.source) (bySource.get(r.source) || bySource.set(r.source, []).get(r.source)).push(i);
    const n = norm(r.body); r.n = n; r.w = new Set(words(n));
    (byNorm.get(n) || byNorm.set(n, []).get(n)).push(i);
    for (const w of r.w) (index.get(w) || index.set(w, []).get(w)).push(i);
  });
  return (text, locs = []) => {
    const n = norm(text), hit = new Set();
    for (const l of locs) for (const i of bySource.get(l) || []) hit.add(i);
    if (hit.size) return { how: 'locator', ids: [...hit] };
    for (const i of byNorm.get(n) || []) hit.add(i);
    if (hit.size) return { how: 'exact', ids: [...hit] };
    const bw = words(n), bset = new Set(bw), cand = new Map();
    for (const w of bset) for (const i of index.get(w) || []) cand.set(i, (cand.get(i) || 0) + 1);
    const contain = [], near = [];
    for (const [i] of cand) {
      const r = records[i];
      if (r.n.length >= 40 && n.length >= 40 && (r.n.includes(n) || n.includes(r.n))) { contain.push(i); continue; }
      const inText = bw.filter(w => r.w.has(w)).length;
      if (bw.length >= 8 && inText / bw.length >= 0.88 && r.w.size >= 0.5 * bset.size) near.push(i);
    }
    if (contain.length) return { how: 'containment', ids: contain };
    if (near.length) return { how: 'words88', ids: near };
    return null;
  };
}
const deepStrings = (v, out = []) => { if (typeof v === 'string') { if (v.length >= 40) out.push(v); } else if (Array.isArray(v)) v.forEach(x => deepStrings(x, out)); else if (v && typeof v === 'object') Object.values(v).forEach(x => deepStrings(x, out)); return out; };

// ------------------------------------------------------------------------------------------------------------------------------------ the base tables
// The tables as the migration and the other overlays leave them, without what tools/merge_story.mjs added (its bookkeeping content/story/merged.json:
// its rows, and every entry, text and page it changed, restored where they still hold what it wrote): tools/merge_story.mjs baseTables().
const homeOf = r => { const s = [...(r.shownOn || [])].map((so, i) => ({ so, i })).sort((a, b) => (a.so.order ?? 0) - (b.so.order ?? 0) || a.i - b.i)[0]; return s ? s.so.page : null; };

// ------------------------------------------------------------------------------------------------------------------------------------ main
// opts.review: the choices to apply in place of content/story/review.json (tools/accept_review.mjs --dry-run measures what a set of choices would place;
// nothing is written)
export async function migrate(v15, opts = {}) {
  const errors = [], warnings = [];
  const E = m => errors.push(m), Wn = m => warnings.push(m);
  const { strings, functions } = await readV15(v15);
  const byLoc = new Map(strings.map(s => [s.loc, s]));
  const val = loc => (byLoc.has(loc) ? byLoc.get(loc).text : null);
  const MAP = buildMap(val);

  // ---- 2. map every string
  for (const s of strings) {
    const rules = MAP[s.file];
    if (!rules) { E(`${s.loc}: no table for ${s.file}`); continue; }
    let spec = null;
    for (const [re, tgt] of rules) { const m = re.exec(s.path); if (!m) continue; if (re.source.startsWith('^') && m[0] !== s.path) continue; spec = typeof tgt === 'function' ? tgt(m, val) : tgt; break; }
    if (!spec) { E(`${s.loc}: no pattern of the table names this path`); continue; }
    if (spec.shortOnly && isProse(s.text)) E(`${s.loc}: a prose string that no pattern of the table names (it would be a label): ${s.text.slice(0, 80)}`);
    s.map = spec;
  }
  if (errors.length) return { errors, warnings };

  // ---- the tables
  const { rows: baseRows, pages: basePages, texts: baseTexts } = storyBase();
  const counts = readJSON(path.join(C, 'MIGRATION_COUNTS.json'), {});
  const status = readJSON(path.join(C, 'derived', 'status.json'), {});
  const figures = readJSON(path.join(C, 'figures.json'), []);
  const figIds = new Set(figures.map(f => f.id));
  const pendingFigs = new Set(readJSON(path.join(STORY, 'pending_figures.json'), []).map(x => (typeof x === 'string' ? x : x.id)));
  const review = opts.review || readJSON(path.join(STORY, 'review.json'), {});
  const idsIn = readJSON(path.join(STORY, 'ids.json'), {});
  const prevPending = new Map(readJSON(path.join(STORY, 'pending.json'), []).map(p => [p.locator, p]));
  const checks = readJSON(path.join(C, 'checks.json'), []), runs = readJSON(path.join(C, 'check_runs.json'), []);
  const rowById = new Map(baseRows.map(r => [r.id, r]));
  const pageByRoute = new Map(basePages.map(p => [p.route, p]));
  const research = new Map(), learnerHuman = new Map();
  for (const t of baseTexts) {
    if (t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full') research.set(t.row, t);
    if (t.level === 'learner' && t.lens == null && t.status === 'human' && (t.register || 'full') === 'full') learnerHuman.set(t.row, t);
  }
  // hero figure of a page: pages.json hero.figure, else the first figure whose caption row is the hero row (the rule of src/app/queries.js heroFigure)
  const heroFig = route => { const p = pageByRoute.get(route); if (!p || !p.hero) return null; if (p.hero.figure) return p.hero.figure; const f = figures.find(x => x.captionRow === p.hero.row); return f ? f.id : null; };

  // ---- prose blocks: unique by text, first locator whose kind is not out or chrome is primary
  const blockByText = new Map();
  for (const s of strings) {
    if (!isProse(s.text)) continue;
    const n = norm(s.text);
    if (!blockByText.has(n)) blockByText.set(n, { text: s.text, n, locs: [] });
    blockByText.get(n).locs.push(s);
  }
  const blocks = [...blockByText.values()];
  for (const b of blocks) b.primary = b.locs.find(s => !['out', 'chrome'].includes(s.map.k)) || b.locs[0];
  // short leads: a string the table names as the lead of a section (kind lead) is that section's intro whatever its length, so one shorter than a
  // prose block (v15's "Physics first. All open; none is claimed." above the Baez questions, the four short thread questions of spin and spring)
  // is a candidate too, deduped and tested like every block; it is counted apart (story.shortLeads), so the block counts of §3.5 stay those of the
  // prose blocks
  const shortLeads = [], seenShort0 = new Set();
  for (const s of strings) {
    if (s.map.k !== 'lead' || isProse(s.text) || !s.text.trim()) continue;
    const n = norm(s.text);
    if (blockByText.has(n) || seenShort0.has(n)) continue;
    seenShort0.add(n);
    shortLeads.push({ text: s.text, n, locs: [s], primary: s, shortLead: true });
  }

  // ---- 3. dedupe: texts.json (research of any row, human learner texts), the other tables, the frames
  const textRecs = baseTexts.filter(t => t.lens == null && (t.level === 'research' || t.status === 'human')).map(t => ({ key: t.row, level: t.level, body: t.body, source: t.source }));
  const matchText = makeMatcher(textRecs);
  const tableRecs = [];
  for (const n of ['glossary', 'conventions', 'theorems', 'questions', 'sources', 'inputs', 'matrix', 'map', 'analyses', 'reports', 'readings', 'needs', 'figures', 'lenses'])
    for (const s of deepStrings(readJSON(path.join(C, `${n}.json`), []))) tableRecs.push({ key: n, body: s });
  const matchTable = makeMatcher(tableRecs);
  const frameRecs = [...deepStrings(readJSON(path.join(C, 'story_frames.json'), {})), ...deepStrings(basePages.map(p => p.learnerFrame || null))].map(s => ({ key: 'frame', body: s }));
  const matchFrame = makeMatcher(frameRecs);
  for (const b of [...blocks, ...shortLeads]) {
    const m = matchText(b.text, b.locs.map(s => s.loc));
    if (m) {
      const cands = [...new Set(m.ids.map(i => textRecs[i]))];
      const page = b.primary.map.p;
      const score = r => [rowById.get(r.key) && homeOf(rowById.get(r.key)) === page ? 0 : 1, b.locs.some(s => s.loc === r.source) ? 0 : 1, r.level === 'research' ? 0 : 1];
      cands.sort((x, y) => { const a = score(x), c = score(y); for (let i = 0; i < a.length; i++) if (a[i] !== c[i]) return a[i] - c[i]; return cmpStr(x.key, y.key); });
      b.row = { id: cands[0].key, level: cands[0].level, how: m.how };
      continue;
    }
    if (matchTable(b.text)) { b.table = tableRecs[matchTable(b.text).ids[0]].key; continue; }
    if (matchFrame(b.text)) b.frame = true;
  }
  const blockOfLoc = new Map(); for (const b of [...blocks, ...shortLeads]) for (const s of b.locs) blockOfLoc.set(s.loc, b);

  // ---- the page skeleton: sections of every ORDER page, the current sections of the existing rows
  const ROUTES = Object.keys(PAGES);
  const secDefs = new Map();     // route → [section def]
  const titleOf = loc => { if (!loc) return null; const t = val(loc); if (t == null) { E(`title ${loc}: no such string in v15`); return null; } const s = t.trim(); return s && s.length <= 60 && !/[.]$/.test(s) && !claimWords(s).length ? s : null; };
  for (const route of ROUTES) {
    const P = PAGES[route];
    if (!P.sub && !pageByRoute.has(route)) E(`PAGES ${route}: not a route of pages.json`);
    if (P.sub && !pageByRoute.has(P.sub.parent)) E(`PAGES ${route}: parent ${P.sub.parent} is not a route`);
    const defs = P.sec.map(s => ({ ...s, f: s.id === 'intro' && s.f === undefined ? heroFig(route) : (s.f ?? null) }));
    for (const d of defs) if (d.f && !figIds.has(d.f) && !pendingFigs.has(d.f)) E(`PAGES ${route} ${d.id}: figure ${d.f} is neither in figures.json nor in pending_figures.json`);
    secDefs.set(route, defs);
  }
  const secOf = (route, id) => (secDefs.get(route) || []).find(d => d.id === id) || null;

  // ---- 7a. existing rows on the ORDER pages: their section and role
  const placed = new Map();    // `${row}|${route}` → { section, role, pos }
  const v15PosOfRow = new Map(); // row → walk index of the block that is that row (on the row's page)
  // the block that is the row: the one its research text was migrated from (locator match) first, else the first in v15 order
  for (const b of [...blocks, ...shortLeads]) if (b.row) { const prev = v15PosOfRow.get(b.row.id); const loc = b.row.how === 'locator'; if (prev == null || (loc && !prev.loc) || (loc === prev.loc && b.primary.i < prev.i)) v15PosOfRow.set(b.row.id, { i: b.primary.i, b, loc }); }
  for (const route of ROUTES) {
    const P = PAGES[route];
    for (const r of baseRows) for (const so of r.shownOn) {
      if (so.page !== route || so.overlay || (so.order ?? 0) >= 1000) continue;
      // where v15 printed the row: the string its research text was migrated from (any length), else the prose block that is the row
      const ownStr = research.has(r.id) ? byLoc.get(research.get(r.id).source) : null;
      const own = ownStr && ownStr.map && ownStr.map.p === route && ownStr.map.s && !['out', 'chrome'].includes(ownStr.map.k) ? ownStr : null;
      const blk = v15PosOfRow.get(r.id);
      const hit = own ? { i: own.i, b: { primary: own } } : blk;
      const spec = hit && hit.b.primary.map;
      let section = null, role = so.role || 'result', why = '';
      if (P.place && P.place[r.id]) { section = P.place[r.id]; why = 'place'; }
      else if (spec && spec.p === route && spec.s && secOf(route, spec.s)) { section = spec.s; why = 'v15'; }
      else if (secOf(route, so.section)) { section = so.section; why = 'kept'; }
      else { const d = (secDefs.get(route) || []).find(x => (x.from || []).includes(so.section)); if (d) { section = d.id; why = 'from'; } }
      if (!section) { E(`${r.id} on ${route || '(home)'}: section ${so.section} has no place in the ORDER table`); continue; }
      const def = secOf(route, section);
      if (spec && spec.p === route) {
        if (spec.k === 'cap') role = spec.f && def.f === spec.f && figIds.has(spec.f) ? 'caption' : 'detail';
        else if (spec.k === 'yl') role = 'learner';
        else if (spec.r === 'detail') role = 'detail';
      }
      if (section === 'summary') role = 'detail';
      if (section === 'needs') role = so.role || 'detail';
      if (section === 'intro' && r.id.startsWith('PAG-') && role !== 'result') role = 'result';
      placed.set(`${r.id}|${route}`, { section, role, pos: hit && spec && spec.p === route ? hit.i : null, order0: so.order ?? 0, why });
    }
  }

  // ---- rows of a section for the test (after the layout of the existing rows), with the page's hero; the intro reads every row of its page; a row
  //      that v15 printed in a section of a sub-page (Furey's tabs, whose rows still sit on the overview until furey.json places them) counts there
  const sectionRows = new Map(), pageRows = new Map();
  const addTestRow = (page, sec, id) => {
    if (!research.has(id)) return;
    const tr = testRow(id, research.get(id).body, (status[id] || {}).status);
    const k = `${page}|${sec}`;
    if (!sectionRows.has(k)) sectionRows.set(k, []);
    if (!sectionRows.get(k).some(x => x.id === id)) sectionRows.get(k).push(tr);
    if (!pageRows.has(page)) pageRows.set(page, []);
    if (!pageRows.get(page).some(x => x.id === id)) pageRows.get(page).push(tr);
  };
  for (const r of baseRows) for (const so of r.shownOn) {
    const pl = placed.get(`${r.id}|${so.page}`);
    addTestRow(so.page, pl && !so.overlay && (so.order ?? 0) < 1000 ? pl.section : so.section, r.id);
  }
  for (const [id, { b }] of [...v15PosOfRow].sort((x, y) => x[1].i - y[1].i)) { const m = b.primary.map; if (m.p && PAGES[m.p] && PAGES[m.p].sub && m.s) addTestRow(m.p, m.s, id); }
  const rowsForTest = (route, sec) => {
    const out = [...((sec === 'intro' ? pageRows.get(route) : sectionRows.get(`${route}|${sec}`)) || [])];
    const hero = (pageByRoute.get(route) || {}).hero;
    if (hero && hero.row && research.has(hero.row) && !out.some(x => x.id === hero.row)) out.push(testRow(hero.row, research.get(hero.row).body, (status[hero.row] || {}).status));
    return out;
  };

  // ---- 40-character windows of every row's research text (the §1.6 rule "no 40 characters of another row")
  const winOwner = new Map();
  for (const [id, t] of research) for (const w of windows40(t.body)) if (!winOwner.has(w)) winOwner.set(w, id);
  const overlapOf = (text, self) => { const n = norm(text); for (let i = 0; i + 40 <= n.length; i++) { const o = winOwner.get(n.slice(i, i + 40)); if (o && o !== self) return o; } return null; };

  // ---- classify the blocks
  const RESEARCH_KINDS = new Set(['lead', 'next', 'body', 'stmt', 'cap']);
  const cand = [];     // research candidates (primary blocks that become story rows or wait)
  const secondary = []; // leadM, short (attached to a twin)
  const strips = [];   // learner strips
  const titles = [];   // finding titles (A58)
  const tries = [];    // PLAIN try lines
  const outBy = {}; let chrome = 0;
  for (const b of [...blocks, ...shortLeads]) {
    const s = b.primary, m = s.map;
    b.page = m.p ?? null;
    if (b.row || (b.table && !tableLead(b))) continue;
    if (m.k === 'out') { outBy[m.why] = (outBy[m.why] || 0) + 1; b.out = m.why; continue; }
    if (m.k === 'chrome') { chrome++; b.chrome = true; continue; }
    if (m.k === 'yl') { strips.push(b); continue; }
    if (m.k === 'leadM' || m.k === 'short') { secondary.push(b); continue; }
    if (m.k === 'ftitle') { titles.push(b); continue; }
    if (m.k === 'try') { tries.push(b); continue; }
    if (RESEARCH_KINDS.has(m.k)) { if (!secOf(m.p, m.s)) E(`${s.loc}: section ${m.s} is not in the ORDER table of ${m.p}`); cand.push(b); continue; }
    E(`${s.loc}: kind ${m.k}`);
  }
  if (errors.length) return { errors, warnings };

  // ---- 4. test the research candidates, apply review.json
  const pending = [];
  const storyAllowed = (text, route, sec) => testBlock(text, { t0: false, rows: rowsForTest(route, sec) }).outcome === 'story' && !overlapOf(text, null);
  for (const b of cand) {
    const s = b.primary, m = s.map;
    const t = testBlock(b.text, { t0: m.k === 'stmt' || !!s.tags, rows: rowsForTest(m.p, m.s) });
    b.test = t;
    let outcome = t.outcome;
    if (outcome === 'story') { const o = overlapOf(b.text, null); if (o) { outcome = 'held'; t.signals.push(`repeats ${o}`); } }
    b.outcome = outcome; b.default = outcome;
    const choice = review[s.loc];
    // the author's choice (review.json): story makes it a story row where T1–T5 clear it (a v15 statement, T0, may be declared narration; a block that
    // states what no row of its section states stays held, §1.6); reading, statement:<check>, same-as:<row> and drop keep it in pending.json with the
    // choice, which tools/merge_story.mjs applies (a reading or statement row, a short text, nothing)
    if (choice === 'story') { if (storyAllowed(b.text, m.p, m.s)) b.outcome = 'story'; else Wn(`${s.loc}: review.json chooses story, but the test of §1.4 holds it (it states what no row of its section states); kept in pending.json`); }
    b.choice = choice || null;
    // diagnostic for the report (not used for the outcome): would the block restate rows of its whole page (the plan's measure, §1.4)?
    if (outcome === 'held' && !t.signals.some(x => x.startsWith('repeats')) && m.s !== 'intro') b.clearedByPage = testBlock(b.text, { t0: false, rows: rowsForTest(m.p, 'intro') }).outcome === 'story';
  }

  // ---- learner strips: their twin (§1.5)
  const storyByLoc = new Map();  // locator of a primary block → the block (story rows only)
  for (const b of cand) if (b.outcome === 'story') storyByLoc.set(b.primary.loc, b);
  // the twin of a strip: the story row or the existing row made from the formal string it translates (by its locator: a row whose research text
  // was migrated from that string, whatever its length), else the prose block it names
  const rowBySource = new Map(); for (const [id, t] of [...research].sort((a, c) => cmpStr(a[0], c[0]))) if (t.source && !rowBySource.has(t.source)) rowBySource.set(t.source, id);
  const twinOf = loc => {
    const b = blockOfLoc.get(loc);
    if (b && b.row && b.row.level === 'research') return { row: b.row.id, block: b };
    if (b && storyByLoc.has(b.primary.loc)) return { story: b };
    if (rowBySource.has(loc)) return { row: rowBySource.get(loc) };
    return b ? { other: b } : null;
  };
  // the strips shorter than a prose block pair the same way (the page strips' tags of the PAG rows are one line each, A56); unpaired, they are left out
  const shortStrips = []; const seenShort = new Set();
  for (const s of strings) if (s.map && s.map.k === 'yl' && s.map.t && !isProse(s.text) && s.text.trim() && !seenShort.has(norm(s.text) + '|' + s.map.t)) { seenShort.add(norm(s.text) + '|' + s.map.t); shortStrips.push({ text: s.text, n: norm(s.text), locs: [s], primary: s, short: true }); }
  const learnerOnly = [];
  const pairedExisting = new Map(); // row id → strip block
  let shortUnpaired = 0;
  for (const b of [...strips, ...shortStrips]) {
    const m = b.primary.map;
    const tw = m.t ? twinOf(m.t) : null;
    if (tw && tw.story && !tw.story.learner) { tw.story.learner = [b]; b.pairedTo = 'story'; continue; }
    if (tw && tw.row) {
      if (learnerHuman.has(tw.row)) { b.pairedTo = 'existing-human'; continue; }
      if (pairedExisting.has(tw.row)) { b.pairedTo = 'existing-second'; if (!b.short && !m.pairOnly) Wn(`${b.primary.loc}: a second learner strip for ${tw.row}; kept as a learner-only row`); }
      else { pairedExisting.set(tw.row, b); b.pairedTo = 'existing'; continue; }
    }
    if (b.short || m.pairOnly) { b.pairedTo = 'none'; shortUnpaired++; continue; }
    // a learner-only story row: needs a page and a section; tested T1–T5 like any story row
    const route = m.p ?? (tw && tw.other ? tw.other.primary.map.p : null), sec = m.s ?? (tw && tw.other ? tw.other.primary.map.s : null);
    if (route == null || !sec || !secOf(route, sec)) { b.pairedTo = 'none'; Wn(`${b.primary.loc}: learner strip with no partner and no section; left out`); continue; }
    b.lp = route; b.ls = sec;
    const t = testBlock(b.text, { t0: false, rows: rowsForTest(route, sec) });
    b.test = t; let outcome = t.outcome; const o = outcome === 'story' ? overlapOf(b.text, null) : null; if (o) { outcome = 'held'; t.signals.push(`repeats ${o}`); }
    b.outcome = outcome; b.default = outcome;
    const choice = review[b.primary.loc]; b.choice = choice || null;
    if (choice === 'story') { if (storyAllowed(b.text, route, sec)) b.outcome = 'story'; else Wn(`${b.primary.loc}: review.json chooses story, but the test of §1.4 holds it; kept in pending.json`); }
    learnerOnly.push(b);
  }
  // secondary research texts (mathematics-mode variants, research shorts) follow their twin
  for (const b of secondary) {
    const m = b.primary.map; const tb = blockOfLoc.get(m.t);
    if (tb && storyByLoc.has(tb.primary.loc)) { (tb[m.k === 'leadM' ? 'mathText' : 'shortText'] ||= []).push(b); b.attached = 'story'; }
    else if (tb && tb.outcome && ['held', 'statement'].includes(tb.outcome)) { (tb[m.k === 'leadM' ? 'mathText' : 'shortText'] ||= []).push(b); b.attached = 'pending'; }
    else { b.attached = 'none'; Wn(`${b.primary.loc}: its partner ${m.t} is not a story row; left out`); }
  }

  // ---- story rows: placement and roles
  const leadOf = new Map(); // `${route}|${sec}` → block
  const storyRows = [];
  const isStory = b => b.outcome === 'story';
  for (const b of [...cand.filter(isStory), ...learnerOnly.filter(isStory)]) {
    const learnerRow = b.lp != null;   // the Zero page's route is the empty string
    const route = learnerRow ? b.lp : b.primary.map.p, sec = learnerRow ? b.ls : b.primary.map.s, m = b.primary.map, def = secOf(route, sec);
    let role;
    if (learnerRow) role = 'learner';
    else if (b.outcome !== 'story') role = 'result';
    else if (m.k === 'lead') { const k = `${route}|${sec}`; if (!leadOf.has(k)) { leadOf.set(k, b); role = 'lead'; } else role = 'detail'; }
    else if (m.k === 'next') role = sec === 'intro' ? 'next' : 'detail';
    else if (m.k === 'cap') role = m.f && def.f === m.f && figIds.has(m.f) ? 'caption' : 'detail';
    else role = m.r === 'detail' ? 'detail' : 'result';
    if (role === 'next' && storyRows.some(x => x.route === route && x.role === 'next')) role = 'detail';
    storyRows.push({ b, route, sec, role, learnerRow });
  }
  // a lead strip whose formal lead is held: none; a section's lead must be a story row
  // ---- 6. ids
  const used = new Set([...baseRows.map(r => r.id), ...Object.values(idsIn)]);
  const ids = { ...idsIn };
  const groupOf = (route, sec) => { const d = secOf(route, sec); return (d && d.g) || PAGES[route].g; };
  const nextId = g => { for (let n = 501; n <= 999; n++) { const id = `${g}-${n}`; if (!used.has(id)) { used.add(id); return id; } } E(`group ${g}: no narration id left (501–999)`); return null; };
  const posOf = b => b.primary.i;
  // allocation order: page (PAGES order), section (ORDER), v15 order — story rows and pending blocks and finding titles together
  const allocList = [];
  for (const x of storyRows) allocList.push({ b: x.b, route: x.route, sec: x.sec });
  for (const b of cand) if (!isStory(b)) allocList.push({ b, route: b.primary.map.p, sec: b.primary.map.s });
  for (const b of learnerOnly) if (!isStory(b)) allocList.push({ b, route: b.lp, sec: b.ls });
  for (const b of titles) allocList.push({ b, route: b.primary.map.p, sec: b.primary.map.s, title: true });
  const routeRank = new Map(ROUTES.map((r, i) => [r, i]));
  const secRank = (route, sec) => (secDefs.get(route) || []).findIndex(d => d.id === sec);
  allocList.sort((a, b) => routeRank.get(a.route) - routeRank.get(b.route) || secRank(a.route, a.sec) - secRank(b.route, b.sec) || posOf(a.b) - posOf(b.b));
  for (const a of allocList) { const loc = a.b.primary.loc; if (!ids[loc]) ids[loc] = nextId(groupOf(a.route, a.sec)); a.b.id = ids[loc]; }

  // ---- 7b. orders: per page, sections in ORDER order; in a section the lead, the captions, then results, details and learner rows in v15 order
  //          (existing rows without a v15 block after them, by their order of before); the next line last
  const layout = [];
  const storyRecs = [];
  const roleRank = { lead: 0, caption: 1, result: 2, detail: 2, learner: 2, evidence: 2, next: 9 };
  for (const route of ROUTES) {
    const entries = [];
    for (const [key, pl] of placed) { const [id, rt] = key.split('|'); if (rt !== route) continue; entries.push({ kind: 'row', id, ...pl }); }
    for (const x of storyRows) if (x.route === route) entries.push({ kind: 'story', id: x.b.id, section: x.sec, role: x.role, pos: posOf(x.b), x });
    const bySec = new Map();
    for (const e of entries) { if (!bySec.has(e.section)) bySec.set(e.section, []); bySec.get(e.section).push(e); }
    let order = 0;
    for (const d of secDefs.get(route)) {
      const es = bySec.get(d.id) || [];
      es.sort((a, b) => roleRank[a.role] - roleRank[b.role] || (a.pos != null && b.pos != null ? a.pos - b.pos : a.pos != null ? -1 : b.pos != null ? 1 : a.order0 - b.order0) || cmpStr(a.id, b.id));
      for (const e of es) { e.order = order++; }
    }
    if (order > 999) E(`${route}: ${order} entries, more than the 1000 orders below the overlays`);
    for (const e of entries) {
      if (e.kind === 'row') layout.push({ row: e.id, page: route, section: e.section, order: e.order, role: e.role });
      else e.x.order = e.order;
    }
  }
  // homes never move: a row's entry on its home page keeps the lowest order of its entries (PAG-001, PAG-002 sit on two pages below 1000)
  const layoutByKey = new Map(layout.map(l => [`${l.row}|${l.page}`, l]));
  for (const r of baseRows) {
    const before = homeOf(r);
    const after = homeOf({ shownOn: r.shownOn.map(so => { const l = !so.overlay && (so.order ?? 0) < 1000 ? layoutByKey.get(`${r.id}|${so.page}`) : null; return l ? { ...so, order: l.order } : so; }) });
    if (before !== after) {
      const l = layoutByKey.get(`${r.id}|${before}`);
      const others = r.shownOn.filter(so => so.page !== before).map(so => { const lo = layoutByKey.get(`${r.id}|${so.page}`); return lo && !so.overlay ? lo.order : so.order ?? 0; });
      if (l) l.order = Math.min(l.order, ...others);
      const again = homeOf({ shownOn: r.shownOn.map(so => { const lo = !so.overlay && (so.order ?? 0) < 1000 ? layoutByKey.get(`${r.id}|${so.page}`) : null; return lo ? { ...so, order: lo.order } : so; }) });
      if (again !== before) E(`${r.id}: its home would move from ${before} to ${again}`);
    }
  }
  layout.sort((a, b) => cmpStr(a.row, b.row) || cmpStr(a.page, b.page));
  return { errors, warnings, ctx: { shortUnpaired, strings, functions, blocks, shortLeads, cand, strips, learnerOnly, secondary, titles, tries, storyRows, pairedExisting, layout, ids, outBy, chrome, secDefs, review, prevPending, checks, runs, rowById, baseRows, basePages, baseTexts, research, pageByRoute, figIds, counts, val, status } };
}

// ------------------------------------------------------------------------------------------------------------------------------------ 8. write
// the check a page's own words lean on (a proposed statement's evidence when its words name no check), as the v15 tab's download named it
const TAB_CHECK = {
  rule: ['core_check.py'], cells: ['core_check.py'], clock: ['labels_check.py', 'core_check.py'], light: ['maxwell_selfcheck.py'], shapes: ['shapes_selfcheck.py', 'gosset_selfcheck.py'],
  'steps/comm': ['equations_selfcheck.py'], 'steps/dirac': ['equations_selfcheck.py', 'dirac_matrix_check.py'], 'steps/mirrors': ['mirrors_selfcheck.py'], 'steps/spin': ['spin_selfcheck.py'],
  'steps/coupling': ['coupling_selfcheck.py'], 'steps/ym': ['yangmills_selfcheck.py'], 'steps/matter': ['matter_selfcheck.py'], 'steps/grav1': ['gravity_selfcheck.py'],
  'steps/grav2': ['gravity_selfcheck.py'], 'steps/projective': ['projective_selfcheck.py'], 'steps/gauge': ['gtg_check.py'], 'steps/nullsurf': ['null_selfcheck.py'],
  'steps/forque': ['forque_selfcheck.py'], 'steps/spring': ['spring_selfcheck.py'], 'steps/rigid': ['pgadyn_selfcheck.py'], 'steps/groups': ['groups_check.py'],
  'steps/category': ['cat_check.py', 'lens_cat_check.py'], 'steps/baez': ['baez_check.py', 'lens_baez_check.py'], 'steps/schuller': ['fibre_check.py', 'lens_sch_check.py'],
  matter: ['furey_papers_check.py'], 'matter/dictionary': ['dictionary_selfcheck.py'], 'matter/papers': ['furey_papers_check.py'], 'matter/model': ['furey_papers_check.py'],
  'matter/generations': ['threegen_selfcheck.py'], 'matter/help': ['furey_papers_check.py'],
};
const V15_TAB = { '': 'rule', rule: 'rule', cells: 'atlas', clock: 'clock', light: 'maxwell', steps: 'equations', shapes: 'shapes', matter: 'furey', lenses: 'lenses',
  'matter/dictionary': 'dictionary', 'matter/papers': 'earlier', 'matter/model': 'findings', 'matter/generations': 'threegen', 'matter/help': 'help' };
const tabV15Of = route => V15_TAB[route] ?? (route.startsWith('steps/') ? route.slice(6) : route);
const ID_RX = [/core·B\d+[a-z]?/g, /bd·[a-z]+·\d+[a-z]?/g, /(?:cat|baez|fibre|bridge|qm|catw|bzw|scw)·[A-Za-z0-9_]+/g];
const SCRIPT_RX = /\b[a-z0-9_]+\.(?:py|mjs)\b/g;
function proposeEvidence(text, route, checks, runs) {
  const passed = s => runs.some(r => r.script && (r.script === s || r.script.endsWith('/' + path.basename(s))) && r.passed !== false && !(Number(r.fail) > 0));
  const out = [], seen = new Set();
  const add = (check, script) => { const k = `${check}|${script}`; if (seen.has(k)) return; seen.add(k); out.push({ check, script, mode: 'ran' }); };
  for (const rx of ID_RX) for (const m of text.matchAll(rx)) { const c = checks.find(x => (x.ids || []).some(i => i.id === m[0])); if (c && passed(c.script)) add(m[0], c.script); }
  const named = [...new Set([...text.matchAll(SCRIPT_RX)].map(m => m[0]))];
  for (const s of [...named, ...(named.length ? [] : TAB_CHECK[route] || [])]) { const c = checks.find(x => x.script && path.basename(x.script) === s); if (c && passed(c.script)) add(path.basename(s).replace(/\.(py|mjs)$/, ''), c.script); }
  return out;
}
const textRec = (row, level, mode, register, body, source) => ({ row, lang: 'en', mode, level, lens: null, register, body, status: 'human', source });
// the row a finding title would shorten (A58): the first line of its finding
const FIRST_LINE = loc => loc.replace(/\.findings\.(\d+)\.title$/, '.findings.$1.lines.0.1').replace(/\.(\w+)\.ftitle$/, '.$1.pts.0.t').replace(/\.more\.items\.(\d+)\.title$/, '.more.items.$1.text');
const KEEP_PENDING = ['notions', 'kind', 'stage', 'ptype', 'fields', 'cells', 'phenomena', 'evidence', 'legacyFlags', 'note', 'labelledBy'];

export function build(ctx) {
  const { strings, functions, blocks, cand, learnerOnly, secondary, titles, tries, storyRows, pairedExisting, layout, ids, outBy, chrome, secDefs, review, prevPending, checks, runs, rowById, baseRows, research, pageByRoute, figIds, val } = ctx;
  const errors = [], warnings = [];
  const isStory = b => b.outcome === 'story';
  // ---- rows and texts of the overlay
  const rowsOut = [], textsOut = [];
  const byRoute = new Map();
  for (const x of storyRows) {
    const b = x.b, s = b.primary, id = b.id;
    const rec = {
      id, group: id.split('-')[0], kind: 'story', stage: 'M', ptype: null, notions: ['i-meta'], fields: [], phenomena: [], cells: [], homePhys: '', homeMath: '', standardRef: null,
      evidence: [], depends: (b.test ? b.test.restates : []).map(r => ({ id: r, rel: 'restates' })), links: [], lensTags: [], legacyFlags: [], legacyLines: 0, legacyLabel: 'story', legacyKnown: false,
      since: 'v2.2', tabV15: tabV15Of(x.route), anchorV15: x.sec, source: s.loc, shownOn: [{ page: x.route, section: x.sec, order: x.order, role: x.role }], visibleTo: ['phys', 'math'],
      review: null, notesPersona: [], theorems: [], readingRefs: 0, v16: [], splitFrom: null, labelFrom: null,
    };
    rowsOut.push(rec);
    textsOut.push(textRec(id, 'research', 'both', 'full', b.text, s.loc));
    for (const m of b.mathText || []) textsOut.push(textRec(id, 'research', 'math', 'full', m.text, m.primary.loc));
    for (const m of (b.shortText || []).slice(0, 1)) textsOut.push(textRec(id, 'research', 'both', 'short', m.text, m.primary.loc));
    if (x.learnerRow) textsOut.push(textRec(id, 'learner', 'both', 'full', b.text, s.loc));
    else if (b.learner && b.learner.length) textsOut.push(textRec(id, 'learner', 'both', 'full', b.learner[0].text, b.learner[0].primary.loc));
    if (!byRoute.has(x.route)) byRoute.set(x.route, []);
    byRoute.get(x.route).push(rec);
  }
  // learner texts of existing rows: the paired v15 strips (A56) and the chapters' learner lines, whose own words are their learner text (A51)
  const learnerOfExisting = [];
  for (const [rowId, b] of [...pairedExisting].sort((a, c) => cmpStr(a[0], c[0]))) learnerOfExisting.push(textRec(rowId, 'learner', 'both', 'full', b.text, b.primary.loc));
  const learnerLines = layout.filter(l => l.role === 'learner').map(l => l.row);
  // a line whose string names the caption string it puts in plain words (toFormal, BW1_CAPY) gives its words to that caption row instead (A51 (b))
  const specOfLoc = new Map(strings.map(s => [s.loc, s.map]));
  const rowOfSource = new Map(); for (const [id, t] of [...research].sort((a, c) => cmpStr(a[0], c[0]))) if (t.source && !rowOfSource.has(t.source)) rowOfSource.set(t.source, id);
  const linesToFormal = [];
  for (const rowId of [...new Set(learnerLines)].sort(cmpStr)) {
    if (pairedExisting.has(rowId)) continue;
    const t = research.get(rowId); if (!t) continue;
    const spec = specOfLoc.get(t.source);
    if (spec && spec.toFormal) {
      const formal = spec.t ? rowOfSource.get(spec.t) : null;
      const humanThere = formal && (ctx.baseTexts || []).some(x => x.row === formal && x.level === 'learner' && x.lens == null && x.status === 'human' && (x.register || 'full') === 'full');
      if (!formal || formal === rowId || humanThere || pairedExisting.has(formal) || learnerLines.includes(formal) || linesToFormal.some(x => x.formal === formal)) { errors.push(`${rowId}: its caption row ${spec.t} is not a row with no other learner text`); continue; }
      learnerOfExisting.push(textRec(formal, 'learner', 'both', 'full', t.body, t.source)); linesToFormal.push({ line: rowId, formal });
      continue;
    }
    learnerOfExisting.push(textRec(rowId, 'learner', 'both', 'full', t.body, t.source));
  }
  textsOut.push(...learnerOfExisting);
  rowsOut.sort((a, c) => cmpStr(a.id, c.id));
  textsOut.sort((a, c) => cmpStr(a.row, c.row) || cmpStr(a.level, c.level) || cmpStr(a.mode, c.mode) || cmpStr(a.register, c.register));

  // ---- sections.json
  const tryBy = new Map();
  // a try line is a connective (no row): left out when longer than 240 characters, or when a row already says its words (a connective never
  // repeats a row's text: the coverage invariant)
  const rowWindows = new Set([...textsOut.map(t => t.body), ...[...research.values()].map(t => t.body)].flatMap(x => windows40(x)));
  for (const b of tries) {
    const m = b.primary.map;
    if (b.text.length > 240) { warnings.push(`${b.primary.loc}: a try line of ${b.text.length} characters (more than 240); left out`); continue; }
    const n = norm(b.text); let said = false;
    for (let i = 0; i + 40 <= n.length && !said; i++) said = rowWindows.has(n.slice(i, i + 40));
    if (said) { warnings.push(`${b.primary.loc}: a try line that holds 40 characters of a row; left out`); continue; }
    tryBy.set(`${m.p}|${m.s}`, b);
  }
  const occupied = new Set([...layout.map(l => `${l.page}|${l.section}`), ...rowsOut.map(r => `${r.shownOn[0].page}|${r.shownOn[0].section}`)]);
  for (const r of baseRows) for (const so of r.shownOn) if (so.overlay || (so.order ?? 0) >= 1000) occupied.add(`${so.page}|${so.section}`);
  // a title is a name (A53): v15's menu label or heading when it is at most 60 characters, has no claim word and no final period; the learner title is
  // the learner menu label (else the same name); a section with no such name gets title false (no heading), never its slug
  const title = (loc, ylLoc) => {
    const t = loc ? clean(val(loc)) : null, y = ylLoc ? clean(val(ylLoc)) : null;
    return t ? { phys: t, math: t, learner: y || t } : null;
  };
  const sectionsOut = [];
  for (const [route, defs] of secDefs) {
    const P = PAGES[route];
    const keep = defs.filter(d => d.id !== 'intro' && (occupied.has(`${route}|${d.id}`) || d.f));
    const introDef = defs.find(d => d.id === 'intro') || {};
    const lead = (byRoute.get(route) || []).find(r => r.shownOn[0].section === 'intro' && r.shownOn[0].role === 'lead');
    const next = (byRoute.get(route) || []).find(r => r.shownOn[0].role === 'next');
    const entry = { route };
    if (P.sub) { const t = title(P.sub.t, P.sub.ty); entry.page = { title: t, tab: t, parent: P.sub.parent, tabV15: P.sub.tab }; }
    entry.intro = { lead: lead ? lead.id : null, next: next ? next.id : null, ...(introDef.from && introDef.from.length ? { absorbs: [...introDef.from] } : {}) };
    entry.parts = (P.parts || []).map(p => ({ id: p.id, title: title(p.t, null), sections: p.sections.filter(id => keep.some(d => d.id === id)) })).filter(p => p.sections.length);
    entry.sections = keep.map(d => {
      const out = { id: d.id, title: title(d.t, d.ty) || false, part: d.part || null, figure: d.f || null, key: null };
      if (d.from && d.from.length) out.absorbs = [...d.from];
      const tr = tryBy.get(`${route}|${d.id}`); if (tr) out.tryLearner = { text: tr.text, source: tr.primary.loc };
      return out;
    });
    sectionsOut.push(entry);
  }

  // ---- pending.json: held blocks, proposed statements, finding titles (never merged until a choice is recorded)
  const pendingOut = [];
  const pushPending = (b, route, sec, kind, extra = {}) => {
    const s = b.primary, prev = prevPending.get(s.loc) || {};
    const e = {
      locator: s.loc, id: b.id, page: route, section: sec, pend: kind, role: extra.role || 'result', text: b.text,
      signals: b.test ? b.test.signals : [], restates: b.test ? b.test.restates : [], uncovered: b.test ? b.test.uncovered : [], missingStatus: b.test ? b.test.missingStatus : [],
      legacyFlags: s.tags || s.map.tags || [], evidence: extra.evidence || [], default: extra.default, choice: review[s.loc] || null,
      learner: (b.learner || []).map(x => ({ text: x.text, locator: x.primary.loc })), math: (b.mathText || []).map(x => ({ text: x.text, locator: x.primary.loc })),
      short: (b.shortText || []).slice(0, 1).map(x => ({ text: x.text, locator: x.primary.loc })), ...(extra.sameAs ? { sameAs: extra.sameAs } : {}),
    };
    for (const k of KEEP_PENDING) if (prev[k] !== undefined && JSON.stringify(prev[k]) !== JSON.stringify(e[k])) e[k] = prev[k];
    pendingOut.push(e);
  };
  for (const b of cand) {
    if (isStory(b)) continue;
    const m = b.primary.map;
    const role = m.k === 'lead' ? 'lead' : m.k === 'cap' ? (m.f && figIds.has(m.f) && (secDefs.get(m.p).find(d => d.id === m.s) || {}).f === m.f ? 'caption' : 'detail') : m.r === 'detail' ? 'detail' : m.k === 'next' ? 'next' : 'result';
    pushPending(b, m.p, m.s, b.outcome === 'statement' ? 'statement' : 'held', { role, default: b.outcome === 'statement' ? 'proposed as a statement; not shown' : 'held; not shown',
      evidence: b.outcome === 'statement' ? proposeEvidence(b.text, m.p, checks, runs) : [] });
  }
  for (const b of learnerOnly) if (!isStory(b)) pushPending(b, b.lp, b.ls, 'held', { role: 'learner', default: 'held; not shown' });
  for (const b of titles) {
    const first = blocks.find(x => x.locs.some(s => s.loc === FIRST_LINE(b.primary.loc)));
    pushPending(b, b.primary.map.p, b.primary.map.s, 'title', { default: 'left out until confirmed (A58)', sameAs: first && first.row ? first.row.id : null });
  }
  pendingOut.sort((a, c) => cmpStr(a.id, c.id));

  // ---- counts (§3.5), by page
  const PAGE_LIST = ['', 'rule', 'cells', 'clock', 'light', 'steps', 'steps/comm', 'steps/mirrors', 'steps/dirac', 'steps/spin', 'steps/coupling', 'steps/ym', 'steps/matter', 'steps/grav1', 'steps/grav2',
    'steps/projective', 'steps/gauge', 'steps/nullsurf', 'steps/forque', 'steps/spring', 'steps/rigid', 'steps/groups', 'steps/category', 'steps/baez', 'steps/schuller', 'shapes', 'matter',
    'matter/dictionary', 'matter/papers', 'matter/model', 'matter/generations', 'matter/help', 'lenses'];
  const pageKey = b => { const p = b.page; if (p == null || p === 'logbook' || p === 'ask' || p === 'glossary') return '(logbook, tally, ask, chrome)'; return p; };
  const per = {};
  const bump = (k, f, n = 1) => { (per[k] ||= { blocks: 0, rows: 0, tables: 0, frames: 0, missing: 0, leftOut: 0, labels: 0, learner: 0, research: 0, story: 0, held: 0, statements: 0, titles: 0 })[f] += n; };
  for (const b of blocks) {
    const k = pageKey(b); bump(k, 'blocks');
    if (b.row) { bump(k, 'rows'); continue; }
    if (b.table) { bump(k, 'tables'); continue; }
    if (b.frame) bump(k, 'frames');
    bump(k, 'missing');
    if (b.out) { bump(k, 'leftOut'); continue; }
    if (b.chrome) { bump(k, 'labels'); continue; }
    const kind = b.primary.map.k;
    if (kind === 'yl' || kind === 'try') { bump(k, 'learner'); continue; }
    if (kind === 'ftitle') { bump(k, 'titles'); continue; }
    if (kind === 'leadM' || kind === 'short') { bump(k, 'research'); continue; }
    bump(k, 'research');
    if (isStory(b)) bump(k, 'story'); else if (b.outcome === 'statement') bump(k, 'statements'); else if (b.outcome === 'held') bump(k, 'held');
  }
  const total = {}; for (const v of Object.values(per)) for (const [f, n] of Object.entries(v)) total[f] = (total[f] || 0) + n;
  const pagesCount = {}; for (const p of [...PAGE_LIST, '(logbook, tally, ask, chrome)']) if (per[p]) pagesCount[p || '(zero)'] = per[p];
  const roleCount = (rs, role) => rs.filter(r => r.shownOn[0].role === role).length;
  const sectionStats = {};
  for (const e of sectionsOut) {
    const leads = new Set(rowsOut.filter(r => r.shownOn[0].page === e.route && r.shownOn[0].role === 'lead').map(r => r.shownOn[0].section));
    const secs = e.sections;
    sectionStats[e.route || '(zero)'] = { sections: secs.length, withLead: secs.filter(s => leads.has(s.id)).length, withoutLead: secs.filter(s => !leads.has(s.id)).length, intro: !!e.intro.lead, untitled: secs.filter(s => s.title === false).length };
  }
  const storyCounts = {
    stringsWalked: strings.length, functionsNotRead: functions, proseBlocks: strings.filter(s => isProse(s.text)).length, uniqueBlocks: blocks.length,
    blocks: { total: blocks.length, rows: total.rows || 0, tables: total.tables || 0, frames: total.frames || 0, missing: total.missing || 0, leftOut: total.leftOut || 0, labels: total.labels || 0,
      learnerStrips: total.learner || 0, research: total.research || 0, story: total.story || 0, held: total.held || 0, statements: total.statements || 0, findingTitles: total.titles || 0 },
    leftOutBy: Object.fromEntries(Object.entries(outBy).sort((a, c) => cmpStr(a[0], c[0]))),
    storyRows: rowsOut.length, storyRowsByRole: Object.fromEntries(['lead', 'caption', 'result', 'detail', 'learner', 'next'].map(r => [r, roleCount(rowsOut, r)])),
    storyRowsByPage: Object.fromEntries(PAGE_LIST.filter(p => byRoute.has(p)).map(p => [p || '(zero)', byRoute.get(p).length])),
    learnerOnlyRows: rowsOut.filter(r => r.shownOn[0].role === 'learner').length, shortStripsUnpaired: ctx.shortUnpaired,
    humanLearnerTexts: { storyRows: textsOut.filter(t => t.level === 'learner' && t.row && rowsOut.some(r => r.id === t.row)).length, existingRowsPaired: pairedExisting.size,
      chapterLearnerLines: learnerOfExisting.length - pairedExisting.size, linesToCaptionRows: linesToFormal.length },
    // the leads counted apart from the prose blocks of §3.5: the short leads (a section's v15 intro shorter than a prose block) and the leads
    // that a table repeats (counted among the tables above)
    shortLeads: leadTally(ctx.shortLeads || []), tableLeads: leadTally(blocks.filter(tableLead)),
    layout: layout.length, layoutByRole: Object.fromEntries(['result', 'detail', 'caption', 'learner', 'evidence'].map(r => [r, layout.filter(l => l.role === r).length])),
    held: pendingOut.filter(p => p.pend === 'held').length, statements: pendingOut.filter(p => p.pend === 'statement').length, findingTitles: pendingOut.filter(p => p.pend === 'title').length,
    pendingByPage: Object.fromEntries(PAGE_LIST.map(p => [p || '(zero)', { held: pendingOut.filter(x => x.page === p && x.pend === 'held').length, statements: pendingOut.filter(x => x.page === p && x.pend === 'statement').length }]).filter(([, v]) => v.held || v.statements)),
    heldClearedAgainstWholePage: cand.filter(b => b.outcome === 'held' && b.clearedByPage).length,
    sections: sectionStats, figureSections: sectionsOut.reduce((a, e) => a + e.sections.filter(s => s.figure).length, 0), tryLines: tryBy.size,
    pages: pagesCount, ids: Object.keys(ids).length,
  };
  return { errors, warnings, out: { rowsOut, textsOut, layout, sectionsOut, ids, pendingOut }, counts: storyCounts, blocks };
}
const clean = s => (s == null ? null : (s => (s && s.length <= 60 && !/[.]$/.test(s) && !claimWords(s).length ? s : null))(String(s).trim()));
// a section's lead that a table repeats (v15's intro of the category section "The complement mask" states theorem T3 of theorems.json) is still the
// section's lead: the table is not printed in the section, so the block is a candidate, tested as any block; it stays counted among the tables
const tableLead = b => !!b.table && !b.row && !!b.primary && !!b.primary.map && b.primary.map.k === 'lead';
const leadTally = list => ({ blocks: list.length, story: list.filter(b => b.outcome === 'story').length, held: list.filter(b => b.outcome === 'held').length,
  statements: list.filter(b => b.outcome === 'statement').length });

// ------------------------------------------------------------------------------------------------------------------------------------ the review table
export function reviewDoc(out, ctx) {
  const esc = s => String(s).replace(/\|/g, '\\|').replace(/\s+/g, ' ');
  const lines = [];
  lines.push('<!-- SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0', 'Required Notice: Copyright (c) 2026 the Cascade Atlas authors',
    'Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE) -->', '');
  lines.push('# Story review: the v15 paragraphs that wait for the author', '');
  lines.push('To record a choice, add `"<locator>": "<choice>"` to `content/story/review.json`; the choices are `story` (narration: a proposed statement whose words the test clears; a held block stays held), `reading` (a row of kind reading, badge "our reading"), `statement:<check id>` (a statement row with that evidence), `same-as:<row id>` (the block is that row; a finding title becomes its short research text) and `drop`.');
  lines.push('A `reading` or `statement:` choice needs the row\'s labels (`notions`, `kind`, `stage`) in its entry of `content/story/pending.json`; `node tools/merge_story.mjs` refuses an unlabelled one.');
  lines.push('Then run `npm run content`: `tools/merge_story.mjs` applies `reading`, `statement:`, `same-as:` and `drop` to the entries of `content/story/pending.json`; a `story` choice takes effect when `tools/migrate/story_from_v15.mjs <v15 root>` runs again.');
  // the reviewer's proposals (content/story/review_proposed_*.json, BUILD_CONTRACTS "Round 6, wave 2"): never merged; tools/accept_review.mjs copies them
  const proposed = {};
  for (const n of (fs.existsSync(STORY) ? fs.readdirSync(STORY) : []).filter(n => /^review_proposed_.+\.json$/.test(n)).sort(cmpStr)) Object.assign(proposed, readJSON(path.join(STORY, n), {}));
  const nProposed = out.pendingOut.filter(p => proposed[p.locator]).length;
  lines.push(`The column "proposed" is the reviewer's proposal for the entry (${nProposed} of ${out.pendingOut.length}; their reasons, with the rows and checks they name, are in \`content/story/review_proposed_a.json\` and \`_b.json\`); \`node tools/accept_review.mjs\` copies the ones you accept into \`review.json\` (\`docs/REVIEW_GUIDE.md\`). A proposal is never merged by itself.`, '');
  lines.push(`Generated by \`tools/migrate/story_from_v15.mjs\` from the v15 package: ${out.pendingOut.filter(p => p.pend === 'held').length} held blocks, ${out.pendingOut.filter(p => p.pend === 'statement').length} proposed statements, ${out.pendingOut.filter(p => p.pend === 'title').length} finding titles (A58), and ${ctx.cleared.length} story rows the test cleared (T4 and T5 held). Held, proposed and title blocks are on no page until a choice is recorded (D45).`, '');
  lines.push('Signals: T0 v15 printed it as a statement · T1 a formula · T2 a claim word · T3 a free number · "repeats" it holds 40 characters of another row. Restates: the rows of its section whose numbers and formulas it repeats (T4); "missing" names a restated row whose status word the block lacks (T5).', '');
  lines.push('| proposed id | page · section | locator | text (first 160 characters) | signals | restates | default | proposed | choice |', '|---|---|---|---|---|---|---|---|---|');
  const row = (id, page, sec, loc, text, signals, restates, def, choice) => lines.push(`| ${id} | ${esc(page || '(zero)')} · ${esc(sec)} | \`${esc(loc)}\` | ${esc(text.slice(0, 160))}${text.length > 160 ? '…' : ''} | ${esc(signals)} | ${esc(restates)} | ${esc(def)} | ${esc((proposed[loc] && proposed[loc].choice) || '')} | ${esc(choice || '')} |`);
  const KORD = { held: 0, statement: 1, title: 2 };
  for (const p of [...out.pendingOut].sort((a, c) => KORD[a.pend] - KORD[c.pend] || cmpStr(a.id, c.id)))
    row(p.id, p.page, p.section, p.locator, p.text, [...p.signals, ...(p.uncovered.length ? [`uncovered: ${p.uncovered.slice(0, 6).join(', ')}`] : []), ...(p.missingStatus.length ? [`missing: ${p.missingStatus.join(', ')}`] : [])].join(' · '),
      p.pend === 'title' ? (p.sameAs ? `same as ${p.sameAs}?` : '') : p.restates.join(', '), p.default, p.choice);
  for (const c of ctx.cleared) row(c.id, c.page, c.section, c.locator, c.text, c.signals.join(' · '), c.restates.join(', '), 'story (cleared by T4 and T5)', c.choice);
  return lines.join('\n') + '\n';
}

// ------------------------------------------------------------------------------------------------------------------------------------ CLI
async function main(argv) {
  const v15 = argv[0];
  if (!v15 || !fs.existsSync(v15)) { console.log('usage: node tools/migrate/story_from_v15.mjs <v15 root>'); return 2; }
  const res = await migrate(path.resolve(v15));
  if (res.errors.length) { console.log(res.errors.slice(0, 60).map(e => 'ERROR ' + e).join('\n')); console.log(`story_from_v15: ${res.errors.length} error(s); nothing written`); return 1; }
  const b = build(res.ctx);
  const warnings = [...res.warnings, ...b.warnings];
  if (b.errors.length) { console.log(b.errors.slice(0, 60).map(e => 'ERROR ' + e).join('\n')); console.log(`story_from_v15: ${b.errors.length} error(s); nothing written`); return 1; }
  const cleared = b.out.rowsOut.map(r => { const blk = res.ctx.blocks.find(x => x.id === r.id && x.test && x.test.signals.length); return blk ? { id: r.id, page: r.shownOn[0].page, section: r.shownOn[0].section, locator: r.source, text: blk.text, signals: blk.test.signals, restates: blk.test.restates, choice: res.ctx.review[r.source] || null } : null; }).filter(Boolean);
  fs.mkdirSync(STORY, { recursive: true });
  writeJSON(path.join(STORY, 'rows.json'), b.out.rowsOut);
  writeJSON(path.join(STORY, 'texts.json'), b.out.textsOut);
  writeJSON(path.join(STORY, 'layout.json'), b.out.layout);
  writeJSON(path.join(STORY, 'sections.json'), b.out.sectionsOut);
  writeJSON(path.join(STORY, 'ids.json'), Object.fromEntries(Object.entries(b.out.ids).sort((x, y) => cmpStr(x[0], y[0]))));
  writeJSON(path.join(STORY, 'pending.json'), b.out.pendingOut);
  fs.writeFileSync(path.join(ROOT, 'docs', 'STORY_REVIEW.md'), reviewDoc(b.out, { cleared }));
  const cf = path.join(C, 'MIGRATION_COUNTS.json'); const counts = readJSON(cf, {});
  counts.story = b.counts; fs.writeFileSync(cf, JSON.stringify(counts, null, 1));   // the format the merges write this file in
  if (warnings.length) console.log(warnings.slice(0, 40).map(w => 'warning ' + w).join('\n') + (warnings.length > 40 ? `\n… ${warnings.length - 40} more warnings` : ''));
  const k = b.counts;
  console.log(`story_from_v15: ${k.stringsWalked} strings, ${k.proseBlocks} prose blocks (${k.uniqueBlocks} unique): rows ${k.blocks.rows}, tables ${k.blocks.tables}, frames ${k.blocks.frames}, missing ${k.blocks.missing}`);
  console.log(`  story rows ${k.storyRows} (${Object.entries(k.storyRowsByRole).map(([r, n]) => `${r} ${n}`).join(', ')}); held ${k.held}; proposed statements ${k.statements}; finding titles ${k.findingTitles}; layout ${k.layout}`);
  return 0;
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) process.exit(await main(process.argv.slice(2)));
