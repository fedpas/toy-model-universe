#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// rows_from_v15.mjs — the 789 statements of v15 → content/rows.json, content/texts.json, content/learner_backlog.json
// Usage: node tools/migrate/rows_from_v15.mjs <v15 root> <atlas_work root>
// Sources: atlas_work/matrix/atlas_matrix_v1.json (rows resolved from claimsData.js with evidence, links, readings, v16 list),
//          <v15>/claimsLocators*.json (per-line provenance file#path and audience), atlas_work/labelling/labels_merged.json (partial labelling).
// Deterministic: same inputs → same bytes. Writes nothing else.
import fs from 'node:fs'; import path from 'node:path';
const [V15, WORK] = process.argv.slice(2); if (!V15 || !WORK) { console.error('usage: rows_from_v15.mjs <v15 root> <atlas_work root>'); process.exit(2); }
const OUT = path.resolve('content'); fs.mkdirSync(OUT, { recursive: true });
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const M = J(path.join(WORK, 'matrix/atlas_matrix_v1.json'));
const LAB = fs.existsSync(path.join(WORK, 'labelling/labels_merged.json')) ? J(path.join(WORK, 'labelling/labels_merged.json')).rows : {};

// ---- locators: per row, per line → {file#path, audience} -------------------------------------------
const loc = {};
for (const f of fs.readdirSync(V15).filter(n => /^claimsLocators.*\.json$/.test(n)).sort()) {
  for (const c of J(path.join(V15, f))) {
    loc[c.id] = { frozen: !!c.frozen, lines: c.lines.map(l => ({ label: l.label, audience: l.audience ? [].concat(l.audience) : null, source: l.en && l.en.text_loc ? `${l.en.text_loc.file}#${l.en.text_loc.path.join('.')}` : (c.frozenText ? `claimsLocators:frozenText` : null) })) };
  }
}

// ---- helpers ------------------------------------------------------------------------------------------
const ID_RX = [/core·B\d+[a-z]?/g, /bd·[a-z]+·\d+[a-z]?/g, /(?:cat|baez|fibre|bridge|qm|catw|bzw|scw)·[A-Za-z0-9_]+/g];
const SCRIPT_RX = /\b[a-z0-9_]+\.(?:py|mjs)\b/g;
const idsIn = s => { const o = new Set(); for (const rx of ID_RX) for (const m of String(s || '').matchAll(rx)) o.add(m[0]); return [...o]; };
const scriptsIn = s => [...new Set([...String(s || '').matchAll(SCRIPT_RX)].map(m => m[0]))];
const modeMap = a => a.map(x => ({ Physicist: 'phys', Mathematician: 'math', 'Young Learner': 'learner' })[x] || x);
const letters = 'bcdefghijklmnopqrstuvwxyz';
const sectionOf = r => r.anchor || (r.tab && r.tab !== r.page ? r.tab : null) || r.page || 'unplaced';

const rows = [], texts = [], backlog = {}; let nSplit = 0, nLearnerLines = 0, nMathOnly = 0, nPhysOnly = 0;
const orderCounter = {};
for (const r of M.rows) {
  const L = loc[r.id] || { lines: [] };
  const lab = LAB[r.id] && LAB[r.id].status !== 'unlabelled' ? LAB[r.id] : null;
  // evidence from checkedBy and from the texts; mode from the author's wording and from the gravity README (citedByChecks)
  const allText = r.en.map(l => l.text).join(' ');
  const evidence = [];
  const seen = new Set();
  const push = (check, script, mode) => { const k = check + '|' + (script || ''); if (seen.has(k)) return; seen.add(k); evidence.push({ check, script: script || null, mode }); };
  const mode = r.checkedByMode === 'ran' ? 'ran' : r.checkedByMode === 'read' ? 'read' : (r.checkedBy ? 'unspecified' : null);
  for (const c of idsIn(r.checkedBy)) push(c, null, mode || 'unspecified');
  for (const s of scriptsIn(r.checkedBy)) push(s.replace(/\.(py|mjs)$/, ''), s, mode || 'unspecified');
  for (const c of idsIn(allText)) push(c, null, mode || 'unspecified');
  for (const c of (r.citedByChecks || [])) { const sp = String(c.script || '').split(/\s|\(/)[0]; if (sp) push(path.basename(sp).replace(/\.(py|mjs)$/, ''), sp, 'ran'); }
  const base = {
    group: r.group, standardRef: r.standardRef || null, links: r.links || [], lensTags: r.lens || [],
    evidence, depends: lab ? lab.depends.map(d => ({ id: d.id, rel: d.rel })) : [],
    notions: lab ? lab.notions : null, kind: lab ? lab.kind : null, stage: lab ? lab.stage : null, ptype: lab ? lab.type : null,
    review: lab && lab.review ? lab.review : null, notesPersona: lab ? lab.notes : [], phenomena: lab ? lab.phenomena : [], fields: lab ? lab.fields : [], cells: lab ? lab.cells : [], homePhys: lab ? lab.homePhys : '', homeMath: lab ? lab.homeMath : '',
    tabV15: r.tab || null, anchorV15: r.anchor || null, theorems: r.theorems || [], readingRefs: (r.readingRefs || []).length, v16: r.v16 || [], since: 'v15',
  };
  const page = r.page || 'unplaced', section = sectionOf(r);
  const key = page + '|' + section; orderCounter[key] = (orderCounter[key] || 0);
  let current = null; // the research row the next learner line belongs to
  let k = 0; // index among non-learner lines
  r.en.forEach((line, i) => {
    const li = L.lines[i] || { label: line.label, audience: null, source: null };
    const aud = li.audience;
    const isLearner = aud && aud.length === 1 && aud[0] === 'Young Learner';
    if (isLearner) {
      nLearnerLines++;
      const target = current || r.id;
      texts.push({ row: target, lang: 'en', mode: 'both', level: 'learner', lens: null, register: 'full', body: line.text, status: 'human', source: li.source });
      return;
    }
    const id = k === 0 ? r.id : r.id + letters[k - 1]; if (k > 0) nSplit++;
    const visibleTo = aud ? modeMap(aud).filter(m => m !== 'learner') : modeMap(r.visibleTo || ['Physicist', 'Mathematician']).filter(m => m !== 'learner');
    if (visibleTo.length === 1) (visibleTo[0] === 'math' ? nMathOnly++ : nPhysOnly++);
    const order = orderCounter[key]++;
    rows.push({
      id, ...base, legacyLabel: line.label, legacyFlags: line.flags, legacyKnown: !!line.known, legacyLines: r.en.length, splitFrom: k === 0 ? null : r.id,
      visibleTo: visibleTo.length ? visibleTo : ['phys', 'math'],
      shownOn: [{ page, section, order, role: r.group === 'INP' ? 'detail' : (r.page === 'map' || r.page === 'researchers' ? 'detail' : 'result') }],
      labelFrom: lab && k > 0 ? r.id : null,
    });
    texts.push({ row: id, lang: 'en', mode: 'both', level: 'research', lens: null, register: 'full', body: line.text, status: 'human', source: li.source });
    current = id; k++;
  });
}
// learner backlog: rows (research) without a learner text, by page/section
const hasLearner = new Set(texts.filter(t => t.level === 'learner').map(t => t.row));
for (const row of rows) { if (!hasLearner.has(row.id) && row.shownOn[0].role === 'result') { const s = row.shownOn[0]; ((backlog[s.page] ||= {})[s.section] ||= []).push(row.id); } }

rows.sort((a, b) => a.id.localeCompare(b.id, 'en')); texts.sort((a, b) => a.row.localeCompare(b.row, 'en') || a.level.localeCompare(b.level));
fs.writeFileSync(path.join(OUT, 'rows.json'), JSON.stringify(rows, null, 1));
fs.writeFileSync(path.join(OUT, 'texts.json'), JSON.stringify(texts, null, 1));
fs.writeFileSync(path.join(OUT, 'learner_backlog.json'), JSON.stringify(backlog, null, 1));
const counts = { v15Rows: M.rows.length, v15Lines: M.rows.reduce((a, r) => a + r.en.length, 0), rows: rows.length, splitRows: nSplit, researchTexts: texts.filter(t => t.level === 'research').length, learnerTextsFromLines: nLearnerLines, rowsLabelled: rows.filter(r => r.notions).length, mathOnlyRows: nMathOnly, physOnlyRows: nPhysOnly, rowsWithEvidence: rows.filter(r => r.evidence.length).length, rowsCitedRead: rows.filter(r => r.evidence.length && r.evidence.every(e => e.mode === 'read')).length, rowsV16: rows.filter(r => r.v16.length).length, backlogRows: Object.values(backlog).reduce((a, p) => a + Object.values(p).reduce((b, s) => b + s.length, 0), 0) };
const cf = path.join(OUT, 'MIGRATION_COUNTS.json'); const prev = fs.existsSync(cf) ? J(cf) : {}; fs.writeFileSync(cf, JSON.stringify({ ...prev, rows: counts }, null, 1));
console.log(JSON.stringify(counts, null, 1));
