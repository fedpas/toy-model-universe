#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/merge_physics.mjs — merges the physics overlay content/physics/ (decisions D33 and D35) into the content tables:
//
//   figures.p<k>.json   figure seeds of owner P<k>, each marked overlay: "physics"           → content/figures.json (after the others, by id)
//   placements.json     [{ row, page, section, order ≥ 1000, role }] for existing rows      → the rows' shownOn, each entry marked overlay: "physics"
//   rows.p<k>.json      the rows of the translation matrices (D35: spin SPN-M01 …, forque  → content/rows.json with since "v2.2", sorted by id as
//                       FRQ-M00 …, spring SPR-M01 …, rigid RIG-M01 …; one row per line of     tools/merge_explore.mjs sorts; each shownOn entry the row
//                       v15's "paper ↔ Atlas" tables), kind reading                          carries is its own (P6: role detail; P9: role evidence, the
//                                                                                            drawer's numbers; P11: none) and is marked overlay: "physics";
//                                                                                            a row is completed to the shape of 02 §1 (SHAPE below)
//   texts.p<k>.json     the research text of each such row (the line's two columns joined   → content/texts.json with status "draft" and source
//                       by " ↔ ")                                                            "physics:P<k>"; a text with status "human" is never replaced
//
// Idempotent and deterministic: the overlay's previous part (the seeds marked overlay: "physics", the shownOn entries so marked, the rows listed in
// MIGRATION_COUNTS.json under physics.rows or held by the overlay, the texts whose source starts with "physics:") is removed before the overlay is
// added again, so a second run writes the same bytes. The overlay is checked first (ids, since, notions, evidence, pages and sections, orders, one
// research text per row, the source of each text); on an error nothing is written and the exit code is 1. A row of the migration is never replaced.
// The status of an overlay row is computed by tools/build_content.mjs like that of any row without v15 flags (D22): proved by the Atlas when a check
// it cites ran and passed, else ours for a reading; a draft text never changes it.
// Run after tools/merge_explore.mjs and before tools/build_content.mjs (npm run content; tools/migrate/run_all.sh).
// Usage: node tools/merge_physics.mjs            merge and write
//        node tools/merge_physics.mjs --check    check the overlay against the tables and print what a merge would do; write nothing
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const C = path.join(ROOT, 'content'), P = path.join(C, 'physics');
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const W = (f, d) => fs.writeFileSync(f, JSON.stringify(d, null, 1));
const clone = x => JSON.parse(JSON.stringify(x));
const CHECK = process.argv.includes('--check');

const SINCE = 'v2.2';
const ROW_ID = /^[A-Z]{2,4}-(M\d{2}|\d{3}[a-z]?)$/;           // a matrix line M00 … M99, or a new row of the group's numbering
// the shape of a row of rows.json (02 §1, in the key order the migration writes): an overlay row keeps every field it carries and is completed with the
// empty value of each field it does not (no claim is added: empty lists, null, 0); a row without a stage takes the stage of the step whose page holds
// its home (steps.json: the physicist's stage of the step), so that the Logbook's register can file it; the type (ptype) stays as given, or null.
const SHAPE = ['id', 'group', 'standardRef', 'links', 'lensTags', 'review', 'notesPersona', 'phenomena', 'tabV15', 'anchorV15', 'theorems', 'readingRefs', 'v16', 'since',
  'legacyLabel', 'legacyFlags', 'legacyKnown', 'legacyLines', 'splitFrom', 'visibleTo', 'labelFrom', 'evidence', 'depends', 'notions', 'kind', 'stage', 'ptype', 'fields',
  'cells', 'homePhys', 'homeMath', 'shownOn'];
const EMPTY = { standardRef: null, links: [], lensTags: [], review: null, notesPersona: [], phenomena: [], tabV15: null, anchorV15: null, theorems: [], readingRefs: 0, v16: [],
  legacyLabel: null, legacyFlags: [], legacyKnown: false, legacyLines: 0, splitFrom: null, visibleTo: ['phys', 'math'], labelFrom: null, evidence: [], depends: [], ptype: null,
  fields: [], cells: [], homePhys: null, homeMath: null };
const ROLES = new Set(['result', 'detail', 'evidence']);
const ORDER_MIN = 1000;                                          // an overlay entry never moves a row's home
const isPhysicsText = t => String(t.source || '').startsWith('physics:');
const textKey = t => [t.row, t.level, t.mode || 'both', t.lens || '', t.register || 'full'].join('|') + (t.chain != null ? '|' + t.chain : '');   // a span keys with its chain (round 14, §2.2)
const byText = (a, b) => a.row.localeCompare(b.row, 'en') || a.level.localeCompare(b.level) || String(a.lens || '').localeCompare(String(b.lens || ''));
const byId = (a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
const ownerFiles = re => fs.readdirSync(P).map(n => [n, re.exec(n)]).filter(([, m]) => m).sort((a, b) => Number(a[1][1]) - Number(b[1][1])).map(([n, m]) => ({ file: path.join(P, n), name: n, owner: `P${m[1]}` }));

const errors = [], warnings = [];
const E = (where, msg) => errors.push(`${where}: ${msg}`);
const Wn = (where, msg) => warnings.push(`${where}: ${msg}`);

// ---------------------------------------------------------------------------------------------------------------- the tables
const figures0 = J(path.join(C, 'figures.json'));
const rows0 = J(path.join(C, 'rows.json'));
const texts0 = J(path.join(C, 'texts.json'));
const pages = J(path.join(C, 'pages.json'));
const countsFile = path.join(C, 'MIGRATION_COUNTS.json');
const counts = fs.existsSync(countsFile) ? J(countsFile) : {};
const sectionsOf = new Map(pages.map(p => [p.route, new Set((p.sections || []).flatMap(s => [s.id, s.query && s.query['shownOn.section']].filter(Boolean)))]));
const stepStage = new Map(J(path.join(C, 'steps.json')).filter(s => s.route && s.stage).map(s => [s.route, s.stage]));
const STAGES = new Set('AKFDOM');

// ---------------------------------------------------------------------------------------------------------------- seeds (D33)
const seeds = ownerFiles(/^figures\.p(\d+)\.json$/).flatMap(({ file, name }) => {
  const a = J(file);
  if (!Array.isArray(a)) { E(`content/physics/${name}`, 'not an array'); return []; }
  return a.map(s => ({ ...s, overlay: 'physics' }));
});
const seedIds = new Set();
for (const s of seeds) {
  if (!s.id || !s.captionRow) { E(`seed ${JSON.stringify(s).slice(0, 80)}`, 'a seed needs id and captionRow'); continue; }
  if (seedIds.has(s.id)) E(`seed ${s.id}`, 'duplicate seed id');
  seedIds.add(s.id);
}
const figuresBase = figures0.filter(f => f.overlay !== 'physics');
for (const f of figuresBase) if (seedIds.has(f.id)) E(`seed ${f.id}`, 'already exists outside the overlay');
const figures = [...figuresBase, ...seeds.sort((a, b) => a.id.localeCompare(b.id, 'en'))];

// ---------------------------------------------------------------------------------------------------------------- rows (D35)
const xRows = ownerFiles(/^rows\.p(\d+)\.json$/).flatMap(({ file, name, owner }) => {
  const a = J(file);
  if (!Array.isArray(a)) { E(`content/physics/${name}`, 'not an array'); return []; }
  return a.map(r => ({ r, name, owner }));
});
const xTexts = ownerFiles(/^texts\.p(\d+)\.json$/).flatMap(({ file, name, owner }) => {
  const a = J(file);
  if (!Array.isArray(a)) { E(`content/physics/${name}`, 'not an array'); return []; }
  return a.map(t => ({ t, name, owner }));
});
const prevAdded = new Set((counts.physics && counts.physics.rows) || []);
const xRowIds = new Set(), ownerOfRow = new Map();
for (const { r, name, owner } of xRows) {
  const at = `content/physics/${name} ${r && r.id}`;
  if (!r || typeof r.id !== 'string' || !ROW_ID.test(r.id)) { E(at, 'a row of the overlay needs an id <GROUP>-M<2 digits> (a matrix line) or <GROUP>-<3 digits>'); continue; }
  if (xRowIds.has(r.id)) E(at, 'duplicate id in the overlay');
  xRowIds.add(r.id); ownerOfRow.set(r.id, owner);
  if (r.since != null && r.since !== SINCE) E(at, `since is ${JSON.stringify(r.since)}, not "${SINCE}"`);
  if (typeof r.group !== 'string' || !r.id.startsWith(`${r.group}-`)) E(at, `group ${JSON.stringify(r.group)} does not match the id`);
  if (typeof r.kind !== 'string' || !r.kind) E(at, 'no kind');
  if (!Array.isArray(r.notions) || !r.notions.length) E(at, 'notions must be a non-empty list');
  if (!Array.isArray(r.evidence)) E(at, 'evidence must be a list (empty when the row has none)');
  if ((r.legacyFlags || []).length) E(at, 'a row of the overlay carries no v15 flags (its status is computed, D22)');
  for (const [i, so] of (r.shownOn || []).entries()) {
    const w = `${at} shownOn[${i}]`;
    if (!sectionsOf.has(so.page)) { E(w, `page ${so.page} is not a route of pages.json`); continue; }
    if (!sectionsOf.get(so.page).has(so.section)) E(w, `section ${so.section} is not declared on ${so.page}`);
    if (!Number.isInteger(so.order) || so.order < ORDER_MIN) E(w, `order ${so.order}: at least ${ORDER_MIN}, so that no row's home moves`);
    if (!ROLES.has(so.role)) E(w, `role ${JSON.stringify(so.role)} (result, detail or evidence)`);
  }
  if (r.stage != null && !STAGES.has(r.stage)) E(at, `stage ${JSON.stringify(r.stage)} (one of A K F D O M)`);
  if (r.stage == null) { const home = [...(r.shownOn || [])].sort((a, b) => a.order - b.order)[0]; if (!home || !stepStage.has(home.page)) E(at, 'no stage, and no home on a step page to take it from'); }
  const old = rows0.find(x => x.id === r.id);
  if (old && !prevAdded.has(r.id) && old.since !== SINCE) E(at, 'the id is a row of the migration: an overlay row never replaces it');
}
// a story row (kind story, D40) carries since "v2.2" too: it is the story overlay's (tools/merge_story.mjs, run after this merge), not a stray row of this one
for (const r of rows0) if (r.since === SINCE && r.kind !== 'story' && !xRowIds.has(r.id) && !prevAdded.has(r.id)) Wn(r.id, `a row with since "${SINCE}" that the overlay does not hold; kept`);
const stale = rows0.filter(r => prevAdded.has(r.id) && !xRowIds.has(r.id)).map(r => r.id), staleSet = new Set(stale);
const rows = rows0.filter(r => !staleSet.has(r.id) && !xRowIds.has(r.id)).map(r => ({ ...r, shownOn: (r.shownOn || []).filter(s => s.overlay !== 'physics') }));
let rowPlacements = 0, completed = 0, stageFromStep = 0;
for (const { r } of xRows) {
  if (!r || !xRowIds.has(r.id) || rows.some(x => x.id === r.id)) continue;
  const shownOn = (r.shownOn || []).map(so => ({ page: so.page, section: so.section, order: so.order, role: so.role || 'detail', overlay: 'physics' }));
  rowPlacements += shownOn.length;
  const home = [...shownOn].sort((a, b) => a.order - b.order)[0], given = clone(r);
  if (SHAPE.some(k => !(k in given))) completed++;
  if (given.stage == null && home) stageFromStep++;
  // the places the Explore overlay gave the row (a note of a page top, a row beside a leaf: tools/merge_explore.mjs runs before this merge) stay with it
  const explorePlaces = ((rows0.find(x => x.id === r.id) || {}).shownOn || []).filter(so => so.overlay === 'explore');
  const full = { ...given, ...Object.fromEntries(SHAPE.filter(k => !(k in given) && k in EMPTY).map(k => [k, clone(EMPTY[k])])), since: SINCE, stage: given.stage ?? (home ? stepStage.get(home.page) : null), shownOn: [...shownOn, ...explorePlaces] };
  rows.push(Object.fromEntries([...SHAPE.map(k => [k, full[k]]), ...Object.keys(full).filter(k => !SHAPE.includes(k)).map(k => [k, full[k]])]));
}
rows.sort(byId);
const rowById = new Map(rows.map(r => [r.id, r]));

// ---------------------------------------------------------------------------------------------------------------- placements of existing rows (D33)
const placements = fs.existsSync(path.join(P, 'placements.json')) ? J(path.join(P, 'placements.json')) : [];
if (!Array.isArray(placements)) E('content/physics/placements.json', 'not an array');
let placed = 0;
for (const [i, pl] of (Array.isArray(placements) ? placements : []).entries()) {
  const at = `content/physics/placements.json #${i} (${pl && pl.row} · ${pl && pl.page})`;
  const r = pl && rowById.get(pl.row);
  if (!r) { E(at, 'placement of an unknown row'); continue; }
  if (!sectionsOf.has(pl.page)) { E(at, 'not a route of pages.json'); continue; }
  if (!sectionsOf.get(pl.page).has(pl.section)) E(at, `section ${pl.section} is not declared on the page`);
  if (!Number.isInteger(pl.order) || pl.order < ORDER_MIN) E(at, `order ${pl.order}: at least ${ORDER_MIN}, so that no row's home moves`);
  if (pl.role != null && !ROLES.has(pl.role)) E(at, `role ${JSON.stringify(pl.role)} (result, detail or evidence)`);
  r.shownOn.push({ page: pl.page, section: pl.section, order: pl.order, role: pl.role || 'result', overlay: 'physics' });
  placed++;
}

// ---------------------------------------------------------------------------------------------------------------- texts (D35)
const xKeys = new Set();
for (const { t, name, owner } of xTexts) {
  const at = `content/physics/${name} ${t && t.row}`;
  if (!t || !xRowIds.has(t.row)) { E(at, 'a text of the overlay belongs to a row of the overlay'); continue; }
  if (ownerOfRow.get(t.row) !== owner) E(at, `the row belongs to ${ownerOfRow.get(t.row)}, the text to ${owner}`);
  if (t.level !== 'research' && t.level !== 'learner') E(at, `level ${JSON.stringify(t.level)}`);
  if (t.source !== `physics:${owner}`) E(at, `source ${JSON.stringify(t.source)}, not "physics:${owner}"`);
  if (t.status !== 'draft') E(at, `status ${JSON.stringify(t.status)}, not "draft"`);
  if (typeof t.body !== 'string' || !t.body.trim()) E(at, 'empty body');
  if (xKeys.has(textKey(t))) E(at, 'two texts with the same key');
  xKeys.add(textKey(t));
}
for (const id of xRowIds) if (!xTexts.some(({ t }) => t && t.row === id && t.level === 'research' && t.lens == null && (t.mode || 'both') === 'both' && (t.register || 'full') === 'full')) E(id, 'no research text in the overlay');
let keptHuman = 0, droppedStale = 0;
const map = new Map();
for (const t of texts0) {
  if (staleSet.has(t.row)) { droppedStale++; continue; }
  if (isPhysicsText(t) && !xKeys.has(textKey(t))) continue;
  map.set(textKey(t), t);
}
for (const { t } of xTexts) {
  if (!t || !xRowIds.has(t.row)) continue;
  const rec = { row: t.row, lang: t.lang || 'en', mode: t.mode || 'both', level: t.level, lens: t.lens || null, register: t.register || 'full', body: String(t.body).trim(), status: 'draft', source: t.source };
  const old = map.get(textKey(rec));
  if (old && old.status === 'human') { keptHuman++; continue; }
  map.set(textKey(rec), rec);
}
const texts = [...map.values()].sort(byText);

// ---------------------------------------------------------------------------------------------------------------- write
const summary = { seeds: seeds.length, placements: placed, rows: xRowIds.size, rowPlacements, rowsCompleted: completed, stageFromStep, removedRows: stale.length, texts: xKeys.size, keptHuman, textsOfRemovedRows: droppedStale, allRows: rows.length, allTexts: texts.length, warnings: warnings.length };
if (warnings.length) console.log(warnings.map(w => 'warning ' + w).join('\n'));
if (errors.length) { console.log(errors.map(e => 'ERROR ' + e).join('\n')); console.log(`merge_physics: ${errors.length} error(s); nothing written`); process.exit(1); }
if (CHECK) { console.log(`merge_physics --check: ${JSON.stringify(summary)}`); process.exit(0); }
W(path.join(C, 'figures.json'), figures);
W(path.join(C, 'rows.json'), rows);
W(path.join(C, 'texts.json'), texts);
counts.physics = { seeds: seeds.length, placements: placed, rows: [...xRowIds].sort(), rowPlacements, rowsCompleted: completed, stageFromStep, texts: xKeys.size };
W(countsFile, counts);
console.log(`merge_physics: ${JSON.stringify(summary)}`);
