#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/page_records.mjs — the record of every page (docs/round7/PLAN.md R7-4, interface 38), written at build: for every route of content/pages.json,
// dist/content/records/<route with / as _>.json, the same record the page's closed fold "The record of this page" shows — computed by the same function,
// pageRecord of src/app/queries.js, bundled here for node (esbuild, from the offline modules) and run on the content tables as the app loads them
// (content/*.json, content/derived/*.json as derived_<name>, landing.json applied, the content version of dist/content/version.json); and the index
// dist/content/records.json (+ records.js for file://): { generated, routes: { <route>: { file, rows, scripts } } }, the counts the closed fold shows.
//   { route, title, rows: [{ id, kind, stage, ptype, status, badge, notions, address, evidence: [{ check, script, mode, lastRun: { ok, fail, passed } }],
//     depends, readingsCount, texts: { research, learner } }], scripts: [ids of checks.json], generated }
// Deterministic: the records are a function of the tables and the content version; no machine path in any file.
// tools/build_chunks.mjs runs it after the tables are written (build.sh), so a build always carries the records of its content.
// Usage: node tools/page_records.mjs [outDir=dist]
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NM = process.env.NODE_MODULES || '/opt/npm-tools/node_modules';
const GLOBAL = '__ONE_RULE_CONTENT__';
const readJSON = f => JSON.parse(fs.readFileSync(f, 'utf8'));

/** the content tables as the app loads them: content/*.json by name, content/derived/*.json as derived_<name>, version from the build when it has one */
export function contentTables(outDir) {
  const C = path.join(ROOT, 'content'), tables = {};
  for (const f of fs.readdirSync(C).filter(f => f.endsWith('.json')).sort()) tables[f.slice(0, -5)] = readJSON(path.join(C, f));
  const D = path.join(C, 'derived');
  if (fs.existsSync(D)) for (const f of fs.readdirSync(D).filter(f => f.endsWith('.json')).sort()) tables['derived_' + f.slice(0, -5)] = readJSON(path.join(D, f));
  const v = outDir ? path.join(outDir, 'content', 'version.json') : null;
  tables.version = v && fs.existsSync(v) ? readJSON(v) : { contentVersion: null, appVersion: null };
  return tables;
}

/** the app's record function, bundled for node: { pageRecord, recordFile, placedRows, primeTable, applyLanding, peekTable } */
export async function recordModule() {
  const esbuild = createRequire(path.join(NM, 'noop.js'))('esbuild');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'one-rule-records-'));
  const outfile = path.join(tmp, 'records.mjs');
  try {
    await esbuild.build({
      stdin: { contents: "export { pageRecord, recordFile, placedRows } from './src/app/queries.js';\nexport { primeTable, peekTable } from './src/app/store.js';\nexport { applyLanding } from './src/app/router.js';\n", resolveDir: ROOT, sourcefile: 'page-records-entry.js', loader: 'js' },
      absWorkingDir: ROOT, outfile, bundle: true, platform: 'node', format: 'esm', target: 'node20', jsx: 'automatic', loader: { '.js': 'jsx', '.css': 'empty' },
      nodePaths: [NM], define: { 'process.env.NODE_ENV': '"production"' }, logLevel: 'error',
      banner: { js: "import { createRequire as __oneRuleCreateRequire } from 'node:module'; const require = __oneRuleCreateRequire(import.meta.url);" },
    });
    return await import(pathToFileURL(outfile).href);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
}

/** the records of every page of the tables: [{ route, file, record }] (primes the module's tables) */
export function recordsOf(mod, tables) {
  for (const [name, data] of Object.entries(tables)) mod.primeTable(name, data);
  mod.applyLanding();
  return (mod.peekTable('pages') || []).map(p => ({ route: p.route, file: mod.recordFile(p.route), record: mod.pageRecord(p.route) }));
}

/** write the records and their index into <outDir>/content/; → { files, rows, scripts } */
export async function writeRecords(outDir) {
  const mod = await recordModule();
  const tables = contentTables(outDir);
  const list = recordsOf(mod, tables);
  const dir = path.join(outDir, 'content', 'records');
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const index = { generated: tables.version.contentVersion || null, routes: {} };
  let rows = 0;
  const scripts = new Set();
  for (const { route, file, record } of list) {
    if (!record) continue;
    fs.writeFileSync(path.join(outDir, file), JSON.stringify(record, null, 1) + '\n');
    index.routes[route] = { file, rows: record.rows.length, scripts: record.scripts.length };
    rows += record.rows.length;
    record.scripts.forEach(x => scripts.add(x));
  }
  const json = JSON.stringify(index);
  fs.writeFileSync(path.join(outDir, 'content', 'records.json'), json);
  fs.writeFileSync(path.join(outDir, 'content', 'records.js'), `(window.${GLOBAL}=window.${GLOBAL}||{})[${JSON.stringify('records')}]=${json};\n`);
  return { files: Object.keys(index.routes).length, rows, scripts: scripts.size };
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const out = path.resolve(ROOT, process.argv[2] || 'dist');
  const r = await writeRecords(out);
  console.log(`page_records: ${r.files} records (${r.rows} placed rows, ${r.scripts} scripts) in ${path.relative(ROOT, path.join(out, 'content', 'records'))}/`);
}
