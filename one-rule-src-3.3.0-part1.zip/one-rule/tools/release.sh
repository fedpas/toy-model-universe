#!/bin/sh
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
# tools/release.sh — the release of ONE RULE, in this order, stopping at the first step that fails (and naming it):
#   1 npm run content                        check the learner texts and spans → merge_chains --check → merge the drafts → merge Explore, physics,
#                                            the story and the chains → validate → status → docs/COVERAGE.md (the retire of a wave, merge_chains
#                                            --retire "<version>", comes before: docs/02_CONTENT_MODEL.md §11.6)
#   2 node tools/migrate/verify_counts.mjs   the migration counts (as npm test)
#   3 sh build.sh                            → dist/
#   4 the counts of the release notes        written from the tables (and the size of the build) between the two counts markers of
#                                            docs/RELEASE_NOTES_v<version>.md when the release has its own notes (a patch release), else of
#                                            docs/RELEASE_NOTES_v<major.minor>.md; no date: the content version is the build's (content/version.json)
#   5 every test suite                       kernel, engines, figures.render, logbook, maxwell, physics (tests/physics/: the wave P4–P11, round 14's
#                                            p12 and p13, round 17's p14 and p15, and the manifest of engines/physics/), story (tests/story/: the overlay, the composition,
#                                            the calibrations shifted and matter), chains (round 14: the extraction, V1–V10, the fixture through the
#                                            pipeline, the checker, the renders), tutorials (the registry, sources, figures and widgets of the
#                                            tutorials), coverage, shipped, chunk (the figures chunk, D47), door, record, ui/smoke,
#                                            ui/tutorials.smoke (the tutorial pages and #/tutorials in Chromium), explore (tests/explore/, the physics
#                                            and the motion of the explorers among them, and the Explore smoke test), ui/story.smoke, ui/chains.smoke
#                                            (the chains at both levels in Chromium), ui/look, export (the tuning export and #/agents): the suites of
#                                            npm test
#   6 release/one-rule-v<version>.zip        the site (dist/, index.html at the top, the figures chunk figures-extra.js and its manifest
#                                            content/figures_extra_ids.json beside app.js, checked to be in), README.md, LICENSE, CHANGELOG.md,
#                                            docs/HANDOVER.md, docs/DECISIONS.md and the release notes of every minor version and of a patch
#                                            release with its own (docs/RELEASE_NOTES_v*.md: 2.0, 2.1, 2.1.1, 2.2), and the records of the round named
#                                            in RECORDS below (at their paths under docs/); its size and sha256
# Offline: every module comes from /opt/npm-tools/node_modules (or NODE_MODULES=...); no npm install. Run from anywhere.
#   sh tools/release.sh          the whole release (npm run release does the same)
#   sh tools/release.sh notes    step 4 only: write the counts of the release notes from the current tables
#   sh tools/release.sh pack     step 6 only: the archive from the current dist/ and documents (only after steps 1 to 5 have passed on them)
set -e
cd "$(dirname "$0")/.."
NM="${NODE_MODULES:-/opt/npm-tools/node_modules}"
export NODE_PATH="$NM"
export NODE_MODULES="$NM"
VERSION=$(node -p "require('./package.json').version")
MAJMIN=$(node -p "require('./package.json').version.split('.').slice(0, 2).join('.')")
NOTES="docs/RELEASE_NOTES_v$MAJMIN.md"
[ -f "docs/RELEASE_NOTES_v$VERSION.md" ] && NOTES="docs/RELEASE_NOTES_v$VERSION.md"
ZIP="release/one-rule-v$VERSION.zip"
# the records of the rounds that ship in the archive beside the release notes, at their paths under docs/ (each must exist): round 16 (the story
# round's close) and round 17 (proofs passes 13a, 13b and 13c)
RECORDS="docs/round16/PLAN.md docs/round16/INTEGRATION_NOTES.md docs/round16/SPINE_wave3.md docs/round16/SPINE_wave4.md docs/round16/SPINE_wave5.md docs/round16/LEARNER_TEXTS_wave3_a.md docs/round16/LEARNER_TEXTS_wave3_b.md docs/round16/LEARNER_TEXTS_wave4_a.md docs/round16/LEARNER_TEXTS_wave4_b.md docs/round16/LEARNER_TEXTS_wave5_a.md docs/round16/LEARNER_TEXTS_wave5_b.md docs/round16/SPINE_wave6_category.md docs/round16/SPINE_wave6_baez.md docs/round16/SPINE_wave6_schuller.md docs/round16/LEARNER_TEXTS_wave6_t8a.md docs/round16/LEARNER_TEXTS_wave6_t8b.md docs/round16/LEARNER_TEXTS_wave6_t8c.md docs/round16/LEARNER_TEXTS_wave6_t8d.md docs/round16/LEARNER_TEXTS_wave6_t8e.md docs/round16/LEARNER_TEXTS_wave6_t9a.md docs/round16/LEARNER_TEXTS_wave6_t9b.md docs/round16/LEARNER_TEXTS_sweep_T10a.md docs/round16/LEARNER_TEXTS_sweep_T10b.md docs/round16/LEARNER_TEXTS_sweep_T10c.md docs/round16/LEARNER_TEXTS_close.md docs/round16/MATRIX_LINES_REVIEW.md docs/round17/PROOFS_ROUND13A.md docs/round17/pass13a/BEFORE.md docs/round17/pass13a/RESULT.md docs/round17/PROOFS_ROUND13B.md docs/round17/pass13b/BEFORE.md docs/round17/pass13b/RESULT.md docs/round17/PROOFS_ROUND13C.md docs/round17/pass13c/BEFORE.md docs/round17/pass13c/RESULT.md"

run() {
  echo
  echo "== release $VERSION: $*"
  "$@" || { echo "release: STOPPED — this step failed: $*" >&2; exit 1; }
}

# ---- step 4: the counts of the release notes, from the tables (the lines between the two markers are replaced; nothing else is touched)
notes() {
  [ -f "$NOTES" ] || { echo "release: $NOTES is missing" >&2; return 1; }
  NOTES="$NOTES" VERSION="$VERSION" node --input-type=module - <<'EOF'
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
const J = f => JSON.parse(fs.readFileSync(f, 'utf8'));
const n = x => Number(x).toLocaleString('en-US');
const C = 'content/';
const rows = J(C + 'rows.json'), texts = J(C + 'texts.json'), status = J(C + 'derived/status.json'), M = J(C + 'MIGRATION_COUNTS.json');
const lenses = J(C + 'lenses.json'), readings = J(C + 'readings.json'), lensReadings = J(C + 'lens_readings.json');
const checks = J(C + 'checks.json'), runs = J(C + 'check_runs.json'), seeds = J(C + 'figures.json'), candidates = J(C + 'candidates.json');
const pages = J(C + 'pages.json'), theorems = J(C + 'theorems.json'), questions = J(C + 'questions.json'), sources = J(C + 'sources.json'), glossary = J(C + 'glossary.json'), leads = J(C + 'leads.json');
// the content version: the build's (dist/content/version.json), else CONTENT_VERSION, else the date build_chunks.mjs would give
let version = null; try { version = J('dist/content/version.json').contentVersion; } catch { /* no build yet */ }
if (!/^\d{4}-\d{2}-\d{2}$/.test(version || '')) version = /^\d{4}-\d{2}-\d{2}$/.test(process.env.CONTENT_VERSION || '') ? process.env.CONTENT_VERSION
  : new Date(Math.max(...fs.readdirSync(C).filter(f => f.endsWith('.json')).map(f => fs.statSync(C + f).mtimeMs), fs.statSync(C + 'derived/status.json').mtimeMs)).toISOString().slice(0, 10);
// texts by level and status; drafts by the file they come from
const t = k => texts.filter(x => `${x.level} ${x.status}` === k).length;
const draftFiles = fs.readdirSync(C).filter(f => /^texts_learner.*\.json$/.test(f)).sort().map(f => [f, J(C + f)]).filter(([, a]) => Array.isArray(a) && a.length);
// statuses, computed (tools/build_content.mjs)
const st = {}; for (const r of Object.values(status)) st[r.status] = (st[r.status] || 0) + 1;
const WORD = { 'proved-by-atlas': 'proved by the Atlas', standard: 'standard', cited: 'not yet proved here (cited)', ours: 'our reading', input: 'needs an input', open: 'open', meta: 'about the Atlas itself' };
const statusLine = Object.keys(WORD).filter(k => st[k]).map(k => `${WORD[k]} ${n(st[k])}`).join(' · ');
// figures: the components registered in src/figures/ (FIGURES of index.js and the registries it spreads, as the Explore figures of
// src/figures/explore/leaf/index.js and lens/index.js) against the seeds of figures.json
// (and the registries of the physics wave, src/figures/physics/p<k>.js, which src/figures/physics/index.js spreads; the core registry src/figures/core.js,
// which index.js spreads with them: D47 splits the figures between app.js (core) and the chunk figures-extra.js (the ids of its manifest))
const indexFiles = d => fs.readdirSync(d, { withFileTypes: true }).flatMap(e => (e.isDirectory() ? indexFiles(path.join(d, e.name)) : /^(index|core|p\d+)\.js$/.test(e.name) ? [path.join(d, e.name)] : []));
const drawn = new Set(indexFiles('src/figures').flatMap(f => [...fs.readFileSync(f, 'utf8').matchAll(/export const \w*FIGURES\s*=\s*\{([\s\S]*?)\};/g)]
  .flatMap(b => [...b[1].matchAll(/(?:^|[,{\s])['"]?([\w-]+)['"]?\s*:\s*[A-Z]\w*/g)].map(m => m[1]))));
const seedIds = seeds.map(f => f.id), placeholders = seedIds.filter(id => !drawn.has(id));
let chunkIds = null; try { chunkIds = J('dist/content/figures_extra_ids.json').ids; } catch { /* no build, or a build without the chunk */ }
const lensesWithReadings = new Set(lensReadings.map(r => r.lens)).size, rowsWithReadings = new Set(lensReadings.map(r => r.row)).size;
const dictionary = lenses.reduce((k, l) => k + (l.dictionary || []).length, 0);
const answered = questions.filter(q => q.answered === true).length;   // the live table (a question answered by a lead counts)
const cov = fs.existsSync('docs/COVERAGE.md') ? fs.readFileSync('docs/COVERAGE.md', 'utf8') : '';
const valErrors = (cov.match(/validation errors (\d+)/) || [])[1];
const edits = M.leads?.editsWithProposedText, editRows = M.leads?.rowsReworded;
const leadCount = Array.isArray(leads) ? leads.length : Array.isArray(leads.leads) ? leads.leads.length : 0;
// v2.2 holds the lines of the translation matrices (the physics overlay, D35) and the author's narration of the story round (kind story, D40), counted apart;
// v2.15 the readings and questions of the two calibrations (D61) and the story rows of the chains (D60)
// v2.16 the four rows of pass 12a (D67) and the five story rows that lead the sections of wave 2 (D60)
// v2.17 the eighteen story rows that lead the sections of waves 3–5 (round 16, D60; no statement row)
// v2.18 the twenty story rows that lead the sections of wave 6 (round 16, D60; no statement row)
// v3.1 the two rows of pass 13a (round 17, D71: the path of the clock sum, the boundary of the Lévy dragon on the labels; group LAB)
// v3.2 the row of pass 13b (round 17, D72: the clock's phase as Weil's index; group LAB)
// v3.3 the two rows of pass 13c (round 17, D73: the labels as Weil's Heisenberg group, his Theorem 1 on the labels; group LAB)
const isStoryRow = r => r.kind === 'story';
const acStmtN = rows.filter(r => r.since === 'v2.18' && !isStoryRow(r)).length, acStoryN = rows.filter(r => r.since === 'v2.18' && isStoryRow(r)).length, acRowsN = acStmtN + acStoryN;
const adRowsN = rows.filter(r => r.since === 'v3.1').length, aeRowsN = rows.filter(r => r.since === 'v3.2').length, afRowsN = rows.filter(r => r.since === 'v3.3').length;
const vStoryN = rows.filter(r => r.since === 'v2.2' && isStoryRow(r)).length, zStmtN = rows.filter(r => r.since === 'v2.15' && !isStoryRow(r)).length, zStoryN = rows.filter(r => r.since === 'v2.15' && isStoryRow(r)).length, zRowsN = zStmtN + zStoryN;
const aaStmtN = rows.filter(r => r.since === 'v2.16' && !isStoryRow(r)).length, aaStoryN = rows.filter(r => r.since === 'v2.16' && isStoryRow(r)).length, aaRowsN = aaStmtN + aaStoryN;
const abStmtN = rows.filter(r => r.since === 'v2.17' && !isStoryRow(r)).length, abStoryN = rows.filter(r => r.since === 'v2.17' && isStoryRow(r)).length, abRowsN = abStmtN + abStoryN;
const xRowsN = rows.filter(r => r.since === 'v2.1').length, pRowsN = rows.filter(r => r.since === 'v2.2' && !isStoryRow(r)).length, lRowsN = rows.filter(r => r.since === 'v2.4').length, qRowsN = rows.filter(r => r.since === 'v2.4.2' || r.since === 'v2.4.3').length, aRowsN = rows.filter(r => r.since === 'v2.5').length, rRowsN = rows.filter(r => r.since === 'v2.6').length, mRowsN = rows.filter(r => r.since === 'v2.7' || r.since === 'v2.8').length, sRowsN = rows.filter(r => r.since === 'v2.9').length, tRowsN = rows.filter(r => r.since === 'v2.10').length, uRowsN = rows.filter(r => r.since === 'v2.11').length, vRowsN = rows.filter(r => r.since === 'v2.12').length, wRowsN = rows.filter(r => r.since === 'v2.13').length, yRowsN = rows.filter(r => r.since === 'v2.14').length;
const lines = [
  // no date in the notes (tests/shipped.test.mjs, rule 1): the content version is the one the build carries and the footer prints
  `- **Release** ${process.env.VERSION} · content: the version the build carries (\`content/version.json\`, printed in the footer).`,
  `- **Statements**: ${n(rows.length)} rows (the ${n(M.rows.v15Rows)} rows of the author's package, with ${n(M.rows.splitRows)} more where a row held several lines${xRowsN ? `, ${n(xRowsN)} rows the Explore overlay adds` : ''}${pRowsN ? `, ${n(pRowsN)} rows of the translation matrices the physics overlay adds (D35)` : ''}${vStoryN ? `, ${n(vStoryN)} story rows, the author's narration placed on the pages (D40)` : ''}${lRowsN ? `, ${n(lRowsN)} rows of the leaves` : ''}${qRowsN ? `, ${n(qRowsN)} rows the proofs round adds (a candidate becomes a row when a check decides it)` : ''}${aRowsN ? `, ${n(aRowsN)} rows of the Atiyah readings (group ATY)` : ''}${rRowsN ? `, ${n(rRowsN)} rows of the partly checkable candidates and the lines split from open questions (a candidate becomes a row when a check decides it)` : ''}${mRowsN ? `${sRowsN || tRowsN || uRowsN || vRowsN || wRowsN || yRowsN ? ',' : ' and'} ${n(mRowsN)} rows of the Atiyah map round (group ATY, the checks the lens's map asked for, themes 15 to 17 included)` : ''}${sRowsN ? `${tRowsN || uRowsN || vRowsN || wRowsN || yRowsN ? ',' : ' and'} ${n(sRowsN)} rows of the energy of the shifted theory (group ATY, the shifted view round)` : ''}${tRowsN ? `${uRowsN || vRowsN || wRowsN || yRowsN ? ',' : ' and'} ${n(tRowsN)} rows of the shifted view computed further (group ATY: the energy-momentum tensor of the shifted theory, the shifted Einstein equations and the fifth generator)` : ''}${uRowsN ? `${vRowsN || wRowsN || yRowsN ? ',' : ' and'} ${n(uRowsN)} rows of the chain of Cl(8)'s (group GEN: the bit rule as the graded tensor product, the null cells, Cl(n+8) = Cl(n) ⊗ M₁₆(ℝ) as a map, the chain as prefixes of the label, the CAR algebra)` : ''}${vRowsN ? `${wRowsN || yRowsN ? ',' : ' and'} ${n(vRowsN)} rows of fibre and base and of the periodicity map (groups FUR and GEN, the owner's pages of round 10 computed further)` : ''}${wRowsN ? `${yRowsN ? ',' : ' and'} ${n(wRowsN)} rows of Furey's construction, the branching of the 16 and the null cells' stages and the limit as an ordered group (groups FUR and GEN)` : ''}${yRowsN ? `${zRowsN || aaRowsN ? ',' : ' and'} ${n(yRowsN)} rows of the open arguments of 2.13.0 computed (Furey's roadmap, the spinors of the total cell, the chain closed; groups FUR and GEN)` : ''}${zRowsN ? `${aaRowsN ? ',' : ' and'} ${n(zStmtN)} rows of readings and questions of the two calibrations and ${n(zStoryN)} story rows of the chains (round 14: groups ATY and FUR)` : ''}${aaRowsN ? `${abRowsN ? ',' : ', and'} ${n(aaStmtN)} rows of the open computations of 2.14.0 (pass 12a, round 15: the pairings in ten generators, Furey and Hughes's three copies, the chains with D = ℍ; groups FUR and GEN) and ${n(aaStoryN)} story rows that lead the sections of wave 2 (round 15: groups ATL, LAB, PAG and MIR)` : ''}${abRowsN ? `${acRowsN ? ',' : ', and'} ${abStmtN ? `${n(abStmtN)} rows and ` : ''}${n(abStoryN)} story rows that lead the sections of waves 3 to 5 (round 16: groups SPN, CPL, YM, MAT, FUR, GRV, PRJ, LAB, NUL, FRQ and SPR; no statement row)` : ''}${acRowsN ? `${adRowsN ? ',' : ', and'} ${acStmtN ? `${n(acStmtN)} rows and ` : ''}${n(acStoryN)} story rows that lead the sections of wave 6 (round 16: groups LNC, LNB and LNS; no statement row)` : ''}${adRowsN ? `${aeRowsN || afRowsN ? ',' : ', and'} ${n(adRowsN)} rows of the path of the clock sum and the boundary of the Lévy dragon on the labels (pass 13a, round 17: group LAB)` : ''}${aeRowsN ? `${afRowsN ? ',' : ', and'} ${n(aeRowsN)} row${aeRowsN === 1 ? '' : 's'} of the clock's phase as Weil's index (pass 13b, round 17: group LAB)` : ''}${afRowsN ? `, and ${n(afRowsN)} row${afRowsN === 1 ? '' : 's'} of the labels as Weil's Heisenberg group and his Theorem 1 on them (pass 13c, round 17: group LAB)` : ''}), each with a research text${t('research draft') ? ` (the author's words, or a draft for review for a row an overlay or a proofs pass adds)` : ' in the author\'s words'}.`,
  `- **Texts**: ${n(texts.length)} in all — ${n(t('research human'))} research texts and ${n(t('learner human'))} learner texts by the author, ${t('research draft') ? `${n(t('research draft'))} research drafts and ` : ''}${n(t('learner draft'))} learner drafts waiting for review${t('learner reviewed') ? `, ${n(t('learner reviewed'))} reviewed learner texts` : ''}${draftFiles.length ? ` (drafts by file: ${draftFiles.map(([f, a]) => `${f} ${n(a.length)}`).join(', ')})` : ''}.`,
  `- **Status**, computed from the evidence and the labelling: ${statusLine}.`,
  `- **Lenses**: ${n(lenses.length)}, with ${n(dictionary)} dictionary entries; ${n(lensReadings.length)} lens readings on ${n(rowsWithReadings)} rows in ${n(lensesWithReadings)} lenses; ${n(readings.length)} readings in the readings table.`,
  `- **Checks**: ${n(checks.length)} scripts with ${n(runs.length)} recorded runs${M.checks ? `; the gravity checks: ${n(M.checks.gravityOk)} pass, ${n(M.checks.gravityFail)} fail` : ''}.`,
  `- **Figures**: ${n(drawn.size)} drawn${chunkIds ? ` (${n(drawn.size - chunkIds.filter(id => drawn.has(id)).length)} in \`app.js\`, ${n(chunkIds.length)} in the chunk \`figures-extra.js\`, loaded when a page needs one, D47)` : ''}${seedIds.length ? `, ${n(placeholders.length)} of the ${n(seedIds.length)} seeds shown as labelled placeholders` : ''}.`,
  `- **Candidates**: ${n(candidates.length)} missing pieces named by the labelling passes; ${n(candidates.filter(c => c.status === 'row').length)} of them are rows now, proved by the check that decided them; the rest are kept in the Logbook until a check decides them or the author accepts them as rows.`,
  `- **Pages and tables**: ${n(pages.length)} routes; ${n(theorems.length)} theorems; ${n(questions.length)} questions${answered != null ? ` (${n(answered)} answered)` : ''}; ${n(sources.length)} sources; ${n(glossary.length)} glossary terms; ${n(leadCount)} wave-3 leads${edits != null ? ` with ${n(edits)} proposed edits on ${n(editRows)} rows` : ''}.`,
];
// the notes to researchers (content/notes.json, docs/02_CONTENT_MODEL.md §8): the notes, and the rows they cite as cards (a row counted once per note)
if (fs.existsSync(C + 'notes.json')) {
  const nn = (J(C + 'notes.json').notes || []), cites = nn.flatMap(x => [...new Set(x.rows || [])]), nst = {};
  for (const id of cites) { const k = status[id] && status[id].status; nst[k] = (nst[k] || 0) + 1; }
  if (nn.length) lines.push(`- **Notes to researchers** (\`content/notes.json\`): ${n(nn.length)} notes; ${n(cites.length)} row citations over ${n(new Set(cites).size)} rows: ${Object.keys(WORD).filter(k => nst[k]).map(k => `${WORD[k]} ${n(nst[k])}`).join(' · ')}.`);
}
// Explore: its pages, the path drawn and not drawn, the shelf, the explorers, the placements, the figures, the learner drafts, the new rows
const xPages = pages.filter(p => ['explore-home', 'leaf', 'explorer'].includes(p.kind));
if (xPages.length) {
  const home = xPages.find(p => p.kind === 'explore-home'), map = (home && home.explore && home.explore.map) || { path: [], shelf: [], lenses: [] };
  const hasPage = slug => pages.some(p => p.route === `explore/${slug}`);
  const leaves = xPages.filter(p => p.kind === 'leaf'), explorers = xPages.filter(p => p.kind === 'explorer');
  const onPath = (map.path || []).filter(e => hasPage(e.slug)), notDrawn = (map.path || []).filter(e => !hasPage(e.slug));
  const placed = rows.reduce((k, r) => k + (r.shownOn || []).filter(s => s.page === 'explore' || String(s.page).startsWith('explore/')).length, 0);
  const xDrafts = fs.existsSync(C + 'texts_learner_explore.json') ? J(C + 'texts_learner_explore.json') : [], short = xDrafts.filter(t => t.register === 'short').length;
  const xFigures = seeds.filter(f => /^(leaf|lens)-/.test(f.id)), newRows = rows.filter(r => r.since === 'v2.1').length;
  lines.push(`- **Explore**: ${n(xPages.length)} pages — the home, ${n(leaves.length)} leaves (${n(onPath.length)} of the ${n((map.path || []).length)} on the path, ${n(leaves.length - onPath.length)} on the shelf) and ${n(explorers.length)} lens explorers${notDrawn.length ? `; not drawn yet: ${notDrawn.map(e => e.name).join(', ')}` : ''}; ${n(placed)} placements of rows of the Atlas; ${n(xFigures.length)} figures; ${n(xDrafts.length)} learner drafts (${n(xDrafts.length - short)} in the full register, ${n(short)} in the short one); ${n(newRows)} new rows.`);
}
// the physics overlay (content/physics/, D33–D37): the seeds of the wave P4–P11, the rows of the translation matrices (D35) by group and computed status,
// where they are placed, the stored tables (D34)
{
  const pSeeds = seeds.filter(f => f.overlay === 'physics'), pRows = rows.filter(r => r.since === 'v2.2' && r.kind !== 'story');   // the matrix lines (the story rows of v2.2 are the narration, D40)
  // the seeds by the owner's file: content/physics/figures.p4.json … p11.json the wave, p12 and after round 14 (D62)
  const seedWave = new Map(); for (const f of fs.existsSync(C + 'physics') ? fs.readdirSync(C + 'physics').filter(x => /^figures\.p\d+\.json$/.test(x)) : []) { const k = Number(f.match(/p(\d+)/)[1]); for (const sd of J(C + 'physics/' + f)) if (sd && sd.id) seedWave.set(sd.id, k); }
  const r14Seeds = pSeeds.filter(f => [12, 13].includes(seedWave.get(f.id) || 0)).length, r17Seeds = pSeeds.filter(f => (seedWave.get(f.id) || 0) >= 14).length;
  if (pSeeds.length || pRows.length) {
    const GROUP = { SPN: 'spin', FRQ: 'forque', SPR: 'spring', RIG: 'the rigid body' }, rank = g => (Object.keys(GROUP).indexOf(g) + 1) || 99;
    const groups = [...new Set(pRows.map(r => r.group))].sort((a, b) => rank(a) - rank(b) || a.localeCompare(b));
    const st2 = {}; for (const r of pRows) { const k = status[r.id] && status[r.id].status; st2[k] = (st2[k] || 0) + 1; }
    const roles = {}; for (const r of pRows) for (const s of r.shownOn || []) roles[s.role] = (roles[s.role] || 0) + 1;
    const unplaced = pRows.filter(r => !(r.shownOn || []).length).length;
    const stored = fs.readdirSync(C).filter(f => /^stored_p\d+\.json$/.test(f)), storedKB = stored.reduce((k, f) => k + fs.statSync(C + f).size, 0) / 1024;
    const shiftedKB = fs.existsSync(C + 'stored_shifted.json') ? fs.statSync(C + 'stored_shifted.json').size / 1024 : 0;
    lines.push(`- **Physics** (the overlay \`content/physics/\`, D33): ${n(pSeeds.length)} figures (${r14Seeds ? `${n(pSeeds.length - r14Seeds - r17Seeds)} of the wave P4–P11${r17Seeds ? ',' : ' and'} ${n(r14Seeds)} of the two calibrations of round 14${r17Seeds ? ` and ${n(r17Seeds)} of the clock sum's path, the dragon's boundary and Weil's index beside the walk (round 17)` : ''}; ` : 'of the wave P4–P11, '}${n(pSeeds.filter(f => f.learner).length)} of them at learner level too, ${n(pSeeds.filter(f => f.size === 'wide').length)} wide); ${n(pRows.length)} rows of the translation matrices (${groups.map(g => `${GROUP[g] || g} ${n(pRows.filter(r => r.group === g).length)}`).join(', ')}), computed: ${Object.keys(WORD).filter(k => st2[k]).map(k => `${WORD[k]} ${n(st2[k])}`).join(' · ')}; placed on their step pages${roles.detail ? ` as details (${n(roles.detail)})` : ''}${roles.evidence ? `${roles.detail ? ' and' : ''} as numbers (${n(roles.evidence)})` : ''}${roles.note ? `, ${n(roles.note)} as notes of a page top` : ''}${unplaced ? `, ${n(unplaced)} shown in their figure only` : ''}; ${n(stored.length)} stored tables loaded on demand (\`content/stored_p<k>.json\`, ${storedKB.toFixed(1)} kB, D34)${shiftedKB ? `, and the stored table of the shifted figures (\`content/stored_shifted.json\`, ${shiftedKB.toFixed(1)} kB, D62)` : ''}.`);
  }
}
// the chains of round 14 (content/chains.json, docs/02_CONTENT_MODEL.md §11): per page, storied, shapes, weakest links (the computed status, never
// stored), the spans, the storyteller's records, the retire book (content/chains/, D54)
if (fs.existsSync(C + 'chains.json') && J(C + 'chains.json').length) {
  const chains = J(C + 'chains.json'), ORDER = ['open', 'cited', 'ours', 'input', 'standard', 'proved-by-atlas'];
  const weakest = c => { let k = ORDER.length - 1; for (const id of [...(c.rows || []), ...Object.values(c.twins || {})]) { const i = ORDER.indexOf((status[id] || {}).status); if (i >= 0 && i < k) k = i; } return ORDER[k]; };
  const tally = (xs, f) => xs.reduce((m, x) => { const k = f(x); m[k] = (m[k] || 0) + 1; return m; }, {});
  const byPage = tally(chains, c => c.page), shapes = tally(chains, c => c.shape), weak = tally(chains, weakest);
  const spans = texts.filter(t => t.chain != null), told = chains.reduce((k, c) => k + c.rows.length - (c.mention || []).length, 0);
  const mentions = chains.reduce((k, c) => k + (c.mention || []).length, 0), twins = chains.reduce((k, c) => k + Object.keys(c.twins || {}).length, 0);
  const LD = C + 'chains/learner/', lfiles = fs.existsSync(LD) ? fs.readdirSync(LD).filter(f => f.endsWith('.json')) : [], lrecs = lfiles.reduce((k, f) => k + J(LD + f).length, 0);
  const book = fs.existsSync(C + 'chains/retired.json') ? J(C + 'chains/retired.json') : [], waves = [...new Set(book.map(r => r.wave))];
  const SHAPE = { fork: 'forks', line: 'lines', cycle: 'cycles', ladder: 'ladders' }, WEAK = { ...WORD, 'proved-by-atlas': 'proved throughout', standard: 'standard throughout' };
  const SPAN = { draft: 'drafts', human: 'human texts', reviewed: 'reviewed' };
  lines.push(`- **Chains** (round 14, \`content/chains.json\`, D52–D54): ${n(chains.length)} on ${n(Object.keys(byPage).length)} pages (${Object.entries(byPage).map(([p, k]) => `${p} ${n(k)}`).join(', ')}), ${n(chains.filter(c => c.story !== 'none').length)} storied (${n(chains.filter(c => c.story === 'reviewed').length)} reviewed); ${Object.keys(SHAPE).filter(k => shapes[k]).map(k => `${n(shapes[k])} ${shapes[k] === 1 ? k : SHAPE[k]}`).join(', ')}; weakest links: ${ORDER.slice().reverse().filter(k => weak[k]).map(k => `${WEAK[k]} ${n(weak[k])}`).join(' · ')}; ${n(spans.length)} spans (${n(told)} told positions, ${n(twins)} twins, ${n(mentions)} mentions; ${Object.entries(tally(spans, t => t.status)).map(([k, v]) => `${n(v)} ${SPAN[k] || k}`).join(', ')}) among ${n(lrecs)} records of the storyteller in ${n(lfiles.length)} files of \`content/chains/learner/\`; the retire book holds ${n(book.length)} translator drafts${waves.length ? ` (${waves.map(w => `wave ${w}`).join(', ')})` : ''}.`);
}
// the build: the size of the bundle against the budget of tests/shipped.test.mjs
if (fs.existsSync('dist/app.js')) {
  const kB = b => `${(b / 1024).toFixed(1)} kB`, js = fs.readFileSync('dist/app.js'), css = fs.existsSync('dist/app.css') ? fs.statSync('dist/app.css').size : 0;
  const shipped = fs.readFileSync('tests/shipped.test.mjs', 'utf8');
  const budget = (shipped.match(/appJsGz:\s*(\d+)\s*\*\s*1024/) || [])[1], cssBudget = (shipped.match(/appCss:\s*(\d+)\s*\*\s*1024/) || [])[1];
  const extraBudget = (shipped.match(/extraJsGz:\s*(\d+)\s*\*\s*1024/) || [])[1], extra = fs.existsSync('dist/figures-extra.js') ? fs.readFileSync('dist/figures-extra.js') : null;
  const jsWhy = extra ? 'D47' : Number(budget) > 340 ? 'D38' : 'D20';
  lines.push(`- **Build**: \`dist/app.js\` ${kB(js.length)}, ${kB(zlib.gzipSync(js).length)} gzipped${budget ? ` (budget ${budget} kB, ${jsWhy})` : ''}${extra ? `; the figures chunk \`dist/figures-extra.js\` ${kB(extra.length)}, ${kB(zlib.gzipSync(extra).length)} gzipped${extraBudget ? ` (budget ${extraBudget} kB, ${Number(extraBudget) > 260 ? 'D63' : 'D47'})` : ''}` : ''}; \`dist/app.css\` ${kB(css)}${cssBudget ? ` (budget ${cssBudget} kB${Number(cssBudget) > 96 ? ', D38' : ''})` : ''}.`);
}
if (valErrors != null) lines.push(`- **Validation** (docs/COVERAGE.md): ${n(valErrors)} errors.`);
const file = process.env.NOTES, text = fs.readFileSync(file, 'utf8');
const BEGIN = '<!-- counts: written by tools/release.sh from the tables (sh tools/release.sh notes); edit the tables, not these lines -->', END = '<!-- end of the counts -->';
const i = text.indexOf('<!-- counts:'), j = text.indexOf(END);
if (i < 0 || j < i) { console.error(`release: ${file} has no counts markers (${BEGIN} … ${END})`); process.exit(1); }
fs.writeFileSync(file, text.slice(0, i) + BEGIN + '\n' + lines.join('\n') + '\n' + text.slice(j));
console.log(`release: the counts of ${file} written from the tables (content ${version})`);
EOF
}

if [ "${1:-}" = "notes" ]; then notes; exit 0; fi

if [ "${1:-}" != "pack" ]; then
run npm run content
run node tools/migrate/verify_counts.mjs
run sh build.sh
run notes
run node tests/kernel.test.mjs
run node tests/engines.test.mjs
run node tests/figures.render.test.mjs
run node tests/logbook.test.mjs
run node tests/maxwell.test.mjs
run node tests/physics.test.mjs
run node tests/story.test.mjs
run node tests/chains.test.mjs
run node tests/tutorials.test.mjs
run node tests/coverage.test.mjs
run node tests/shipped.test.mjs
run node tests/chunk.test.mjs
run node tests/door.test.mjs
run node tests/record.test.mjs
run node tests/ui/smoke.test.mjs
run node tests/ui/tutorials.smoke.test.mjs
run node tests/explore.test.mjs
run node tests/ui/story.smoke.test.mjs
run node tests/ui/chains.smoke.test.mjs
run node tests/ui/look.test.mjs
run node tests/export.test.mjs --ui
fi

# ---- step 6: the archive — the site at the top, the documents beside it
# (each command is checked by hand: sh ignores set -e inside a function that run() calls on the left of ||)
pack() {
  STAGE="release/.stage-$VERSION"
  rm -rf "$STAGE" "$ZIP" || return 1
  mkdir -p "$STAGE/docs" || return 1
  cp -R dist/. "$STAGE/" || return 1
  cp README.md LICENSE CHANGELOG.md "$STAGE/" || return 1
  cp docs/HANDOVER.md docs/DECISIONS.md docs/RELEASE_NOTES_v*.md "$STAGE/docs/" || return 1
  for f in $RECORDS; do mkdir -p "$STAGE/$(dirname "$f")" && cp "$f" "$STAGE/$f" || return 1; done
  if command -v zip >/dev/null 2>&1; then
    (cd "$STAGE" && zip -q -r -X "../$(basename "$ZIP")" .) || return 1
  else
    python3 -c "import shutil, sys; shutil.make_archive(sys.argv[1], 'zip', sys.argv[2])" "${ZIP%.zip}" "$STAGE" || return 1
  fi
  rm -rf "$STAGE"
  [ -f "$ZIP" ] || { echo "release: $ZIP was not written" >&2; return 1; }
  node -e "
    const fs = require('fs'), zlib = require('zlib'), b = fs.readFileSync(process.argv[1]);
    // the central directory of the archive: every name, to check that index.html stands at the top
    const names = []; for (let i = b.length - 22; i >= 0; i--) if (b.readUInt32LE(i) === 0x06054b50) { let p = b.readUInt32LE(i + 16); const n = b.readUInt16LE(i + 10);
      for (let k = 0; k < n; k++) { const len = b.readUInt16LE(p + 28), extra = b.readUInt16LE(p + 30), com = b.readUInt16LE(p + 32); names.push(b.toString('utf8', p + 46, p + 46 + len)); p += 46 + len + extra + com; } break; }
    const want = ['index.html', 'app.js', 'app.css', 'figures-extra.js', 'content/figures_extra_ids.json', 'content/version.json', 'README.md', 'LICENSE', 'CHANGELOG.md', 'docs/HANDOVER.md', 'docs/DECISIONS.md', ...process.argv.slice(2)];
    const missing = want.filter(w => !names.includes(w));
    if (missing.length) { console.error('release: the archive lacks ' + missing.join(', ')); process.exit(1); }
    console.log('release: ' + names.filter(x => !x.endsWith('/')).length + ' files in the archive, index.html at the top; release notes: ' + names.filter(x => /^docs\/RELEASE_NOTES_v/.test(x)).join(', '));
  " "$ZIP" "$NOTES" docs/RELEASE_NOTES_v*.md $RECORDS
}
run pack

SIZE=$(wc -c < "$ZIP" | tr -d ' ')
SHA=$(node -e "process.stdout.write(require('crypto').createHash('sha256').update(require('fs').readFileSync(process.argv[1])).digest('hex'))" "$ZIP")
echo
echo "release: $ZIP"
echo "  size   $SIZE bytes ($(node -p "($SIZE / 1048576).toFixed(2)") MB)"
echo "  sha256 $SHA"
