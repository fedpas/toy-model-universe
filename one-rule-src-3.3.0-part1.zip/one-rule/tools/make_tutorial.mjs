#!/usr/bin/env node
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// tools/make_tutorial.mjs — one tutorial page of public/reports/tutorials/ (the source and its figs/ and widgets/ under public/reports/tutorials/src/<name>/) from its markdown source: a self-contained page (inline style, the
// formulas as MathML, the figures inlined as SVG, the widgets inlined as scripts), in the shape of the analyses (tools/make_analysis.mjs) with three
// additions the tutorials need:
//   figures   an image line `![caption](figs/<file>.svg)` becomes an inline <figure> holding the SVG file (read from figs/ beside the source,
//             its XML prolog, comments and any <script> element removed) and the caption; only .svg files under figs/ are inlined;
//   widgets   a line `@@widget <name>` becomes <div class="widget" id="w-<name>"> and the file widgets/<name>.js beside the source is inlined at the
//             end of the page as a classic script that receives the container's id (the file is an IIFE `(function (id) { … })` applied to the id);
//   row ids   an id of a statement of the Atlas (ATL-001, CAND-124, LNS-013d …) outside code and formulas becomes a link to the page that holds it,
//             with its status (content/derived/status.json) as a class and a title, so that a reader sees how far the Atlas has checked the claim.
//   try boxes a blockquote whose text starts with **Try it.** gets the class try (tutorial_style.css draws it as a try box).
//   node tools/make_tutorial.mjs <id>            renders the entry <id> of content/tutorials.json: public/<sources[0]> → public/<html>
//   node tools/make_tutorial.mjs <id> --check    writes nothing; exit 1 if the shipped page differs from what the source gives
//   node tools/make_tutorial.mjs --src <file.md> --out <file.html> [--title T] [--line L]   renders one source outside the registry (a draft)
// Deterministic: the same source and files give the same bytes. Needs markdown-it and katex from NODE_PATH (default /opt/npm-tools/node_modules).
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const NM = process.env.NODE_PATH || '/opt/npm-tools/node_modules';
const req = createRequire(path.join(NM, 'noop.js'));
const MarkdownIt = req('markdown-it'), katex = req('katex');
const versions = { 'markdown-it': JSON.parse(fs.readFileSync(path.join(NM, 'markdown-it/package.json'), 'utf8')).version, katex: JSON.parse(fs.readFileSync(path.join(NM, 'katex/package.json'), 'utf8')).version };
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---- the Atlas's rows: id → { page, status }, from content/ (optional: a draft outside the repository renders without links)
function loadRows() {
  try {
    const rows = JSON.parse(fs.readFileSync(path.join(ROOT, 'content/rows.json'), 'utf8'));
    const status = JSON.parse(fs.readFileSync(path.join(ROOT, 'content/derived/status.json'), 'utf8'));
    const m = new Map();
    for (const r of rows) {
      const so = [...(r.shownOn || [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0))[0];
      m.set(r.id, { page: so ? so.page : 'logbook/register', status: (status[r.id] || {}).status || 'unknown' });
    }
    return m;
  } catch { return new Map(); }
}
const STATUS_WORD = { 'proved-by-atlas': 'proved by the Atlas', standard: 'a standard result', ours: 'our reading', open: 'open', input: 'an input', meta: 'about the Atlas', cited: 'not yet proved here', candidate: 'a candidate', unknown: 'a statement' };

// ---- formulas (as make_analysis.mjs)
const isSp = c => c === 0x20 || c === 0x09 || c === 0x0a || c === 0x0d || Number.isNaN(c);
function inlineClose(src, pos, max) {
  if (pos + 1 >= max || isSp(src.charCodeAt(pos + 1)) || src.charCodeAt(pos + 1) === 0x24) return -1;
  for (let i = pos + 1; i < max; i++) {
    const c = src.charCodeAt(i);
    if (c === 0x5c) { i++; continue; }
    if (c !== 0x24) continue;
    const after = src.charCodeAt(i + 1); if (after >= 0x30 && after <= 0x39) continue;
    if (!isSp(src.charCodeAt(i - 1))) return i;
  }
  return -1;
}
function mathPlugin(md, renderMath) {
  md.inline.ruler.before('escape', 'math', (state, silent) => {
    const src = state.src, pos = state.pos, max = state.posMax;
    if (src.charCodeAt(pos) !== 0x24) return false;
    if (src.charCodeAt(pos + 1) === 0x24) {
      const end = src.indexOf('$$', pos + 2);
      if (end < 0 || end + 2 > max || !src.slice(pos + 2, end).trim()) return false;
      if (!silent) { const t = state.push('math_display', 'math', 0); t.content = src.slice(pos + 2, end); }
      state.pos = end + 2; return true;
    }
    const end = inlineClose(src, pos, max);
    if (end < 0) return false;
    if (!silent) { const t = state.push('math_inline', 'math', 0); t.content = src.slice(pos + 1, end); }
    state.pos = end + 1; return true;
  });
  md.renderer.rules.math_inline = (tokens, idx) => renderMath(tokens[idx].content, false);
  md.renderer.rules.math_display = (tokens, idx) => renderMath(tokens[idx].content, true);
}
const DOUBLE = { 'ℕ': 'N', 'ℤ': 'Z', 'ℚ': 'Q', 'ℝ': 'R', 'ℂ': 'C', 'ℍ': 'H', 'ℙ': 'P' };
const KATEX = { output: 'mathml', throwOnError: true, strict: 'ignore', trust: false };
// a double-struck letter as its own character (ℝ, ℂ, ℍ, 𝔽 …): MathML Core, as Chromium draws it, ignores mathvariant="double-struck"
const DS = { C: 'ℂ', H: 'ℍ', N: 'ℕ', P: 'ℙ', Q: 'ℚ', R: 'ℝ', Z: 'ℤ' };
const dsChar = c => DS[c] || (/[A-Z]/.test(c) ? String.fromCodePoint(0x1D538 + c.charCodeAt(0) - 65) : /[a-z]/.test(c) ? String.fromCodePoint(0x1D552 + c.charCodeAt(0) - 97) : String.fromCodePoint(0x1D7D8 + Number(c)));
const doubleStruck = m => m.replace(/<mi mathvariant="double-struck">([A-Za-z0-9])<\/mi>/g, (_, c) => `<mi>${dsChar(c)}</mi>`);
const slug = s => String(s).normalize('NFKD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\$[^$]*\$|`[^`]*`/g, m => m.replace(/[\\{}^_$`]/g, ' ')).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48).replace(/-+$/, '') || 'section';

// ---- the row-id links: a plugin that splits text tokens on ids (code and formulas are separate tokens and stay as they are); ROW_RE is also the
//      pattern by which tools/tutorials/registry.mjs lists the rows a source cites
export const ROW_RE = /(?<![A-Za-z0-9_-])((?:ATL|CAND|CPL|EQN|FRQ|FUR|GEN|GOS|GRV|INP|LAB|LNB|LNC|LNP|LNS|MAP|MAT|MIR|NUL|PAG|PRJ|RIG|RSN|SHP|SPN|SPR|SRC|THM|YM|ATY)-\d{3}[a-z]?)(?![A-Za-z0-9_-])/g;
function rowLinkPlugin(md, rows, appHref) {
  md.core.ruler.push('row_links', state => {
    for (const blk of state.tokens) {
      if (blk.type !== 'inline' || !blk.children) continue;
      const out = [];
      for (const t of blk.children) {
        if (t.type !== 'text' || !ROW_RE.test(t.content)) { out.push(t); continue; }
        ROW_RE.lastIndex = 0;
        let last = 0, m;
        while ((m = ROW_RE.exec(t.content))) {
          if (m.index > last) { const x = new state.Token('text', '', 0); x.content = t.content.slice(last, m.index); out.push(x); }
          const id = m[1], info = rows.get(id) || rows.get(id.replace(/[a-z]$/, ''));
          const x = new state.Token('html_inline', '', 0);
          x.content = info
            ? `<a class="row row--${esc(info.status)}" href="${esc(appHref)}#/${esc(info.page)}?at=${esc(id)}" title="${esc(id)}: ${esc(STATUS_WORD[info.status] || info.status)}">${esc(id)}</a>`
            : `<span class="row row--unknown">${esc(id)}</span>`;
          out.push(x); last = m.index + m[0].length;
        }
        if (last < t.content.length) { const x = new state.Token('text', '', 0); x.content = t.content.slice(last); out.push(x); }
      }
      blk.children = out;
    }
  });
}

// ---- figures and widgets: the source lines are rewritten before markdown-it sees them
function sanitizeSvg(s) {
  return String(s).replace(/<\?xml[^>]*\?>/g, '').replace(/<!DOCTYPE[^>]*>/gi, '').replace(/<!--[\s\S]*?-->/g, '').replace(/<script[\s\S]*?<\/script>/gi, '').trim();
}
export function render(entry, source, srcDir, { rows = new Map(), appHref = '../../index.html' } = {}) {
  const fallbacks = [], widgets = [], missing = [];
  const lines = String(source).split('\n').map(line => {
    let m = /^!\[([^\]]*)\]\((figs\/[A-Za-z0-9_./-]+\.svg)\)\s*$/.exec(line);
    if (m) {
      const f = path.join(srcDir, m[2]);
      if (!fs.existsSync(f)) { missing.push(m[2]); return `*[figure missing: ${m[2]}]*`; }
      const svg = sanitizeSvg(fs.readFileSync(f, 'utf8'));
      return `\n@@FIG${widgets.length + missing.length}@@${Buffer.from(`<figure class="fig">${svg}<figcaption>${esc(m[1])}</figcaption></figure>`).toString('base64')}@@\n`;
    }
    m = /^@@widget\s+([a-z][a-z0-9_-]*)\s*$/.exec(line);
    if (m) {
      const f = path.join(srcDir, 'widgets', m[1] + '.js');
      if (!fs.existsSync(f)) { missing.push('widgets/' + m[1] + '.js'); return `*[widget missing: ${m[1]}]*`; }
      widgets.push({ id: 'w-' + m[1], js: fs.readFileSync(f, 'utf8') });
      return `\n@@FIG${widgets.length + missing.length}@@${Buffer.from(`<div class="widget" id="w-${m[1]}" data-widget="${m[1]}"><p class="widget__fallback">This widget needs JavaScript.</p></div>`).toString('base64')}@@\n`;
    }
    return line;
  });
  const renderMath = (tex, display) => {
    try {
      const out = katex.renderToString(tex.replace(/[ℕℤℚℝℂℍℙ]/g, c => '\\mathbb{' + DOUBLE[c] + '}'), { ...KATEX, displayMode: display });
      let m = out.replace(/^<span class="katex(?:-display)?">(?:<span class="katex">)?/, '').replace(/(?:<\/span>)+$/, '').replace(' xmlns="http://www.w3.org/1998/Math/MathML"', '')
        .replace(/<semantics>|<\/semantics>/g, '').replace(/<annotation encoding="application\/x-tex">[\s\S]*?<\/annotation>/, '');
      m = doubleStruck(m);
      return !display && tex.length >= 24 ? `<span class="mx">${m}</span>` : m;
    } catch (e) {
      fallbacks.push({ tex, why: String(e.message).split('\n')[0].slice(0, 160) });
      return `<code class="tex">${esc((display ? '$$' : '$') + tex + (display ? '$$' : '$'))}</code>`;
    }
  };
  const md = new MarkdownIt({ html: false, linkify: false, typographer: false, breaks: false });
  mathPlugin(md, renderMath);
  rowLinkPlugin(md, rows, appHref);
  md.renderer.rules.table_open = () => '<div class="tw"><table>\n';
  md.renderer.rules.table_close = () => '</table></div>\n';
  const env = {}, tokens = md.parse(lines.join('\n'), env), used = new Set(['top', 'sections', 'main']), heads = [];
  for (let i = 0; i + 2 < tokens.length; i++) if (tokens[i].type === 'blockquote_open' && tokens[i + 1].type === 'paragraph_open' && /^\*\*Try it\.\*\*/.test(tokens[i + 2].content || '')) tokens[i].attrJoin('class', 'try');
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i]; if (t.type !== 'heading_open') continue;
    let id = slug(tokens[i + 1].content), k = 2; const base = id; while (used.has(id)) id = base + '-' + k++;
    used.add(id); t.attrSet('id', id); heads.push({ id, level: +t.tag.slice(1), html: md.renderer.renderInline(tokens[i + 1].children, md.options, env) });
  }
  let body = md.renderer.render(tokens, md.options, env);
  body = body.replace(/<p>@@FIG\d+@@([A-Za-z0-9+/=]+)@@<\/p>/g, (_, b64) => Buffer.from(b64, 'base64').toString('utf8'));
  const toc = heads.filter(h => h.level === 2).map(h => `<a href="#${h.id}">${h.html}</a>`);
  const gen = `make_tutorial.mjs (markdown-it ${versions['markdown-it']}, katex ${versions.katex})`;
  const style = fs.readFileSync(path.join(ROOT, 'tools/analyses/analysis_style.css'), 'utf8').replace(/^(\/\*[^*]*\*\/\s*)+/, '') + '\n' + fs.readFileSync(path.join(ROOT, 'tools/analyses/tutorial_style.css'), 'utf8').replace(/^(\/\*[^*]*\*\/\s*)+/, '');
  const src = entry.sources && entry.sources[0] ? `<a href="${esc(path.relative(path.dirname(entry.html), entry.sources[0]))}" download="${esc(path.basename(entry.sources[0]))}">The markdown source</a>` : '';
  const scripts = widgets.map(w => `<script>\n(${w.js.trim().replace(/;\s*$/, '')})(${JSON.stringify(w.id)});\n</script>`).join('\n');
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta name="generator" content="${esc(gen)}">
<title>${esc(entry.title)}</title>
<style>
${style.trim()}
</style>
</head>
<body id="top">
<header class="hero"><div class="wrap">
<p class="kick">Cascade Atlas · ${esc(entry.kind || 'tutorial')}</p>
<p class="an-t">${esc(entry.title)}</p>
<p class="sub">${esc(entry.line || '')}</p>
<p class="dl"><a href="${esc(appHref)}#/tutorials">All tutorials</a>${src ? ' · ' + src : ''}</p>
</div></header>
${toc.length ? `<nav class="toc" id="sections" aria-label="Sections"><div class="wrap">${toc.join('\n')}</div></nav>\n` : ''}<main class="wrap md" id="main">
${body}</main>
<footer class="wrap"><p>The text above is the markdown source as it is, rendered by ${esc(gen)}; the formulas are MathML, the figures inline SVG drawn by the scripts named beside them, the widgets scripts of this page. A statement id links to its page in the Atlas, where its check and its last run are recorded. Part of the Cascade Atlas package, PolyForm Noncommercial 1.0.0 (see LICENSE). <a href="#top">Back to the top</a></p></footer>
${scripts}
</body>
</html>
`;
  return { html, fallbacks, missing, widgets: widgets.map(w => w.id), heads };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2), opt = f => { const i = args.indexOf(f); return i >= 0 ? args[i + 1] : null; };
  const rows = loadRows();
  if (opt('--src')) {
    const srcFile = path.resolve(opt('--src')), outFile = path.resolve(opt('--out') || srcFile.replace(/\.md$/, '.html'));
    const entry = { title: opt('--title') || path.basename(srcFile, '.md'), line: opt('--line') || '', kind: 'tutorial (draft)', html: 'reports/tutorials/' + path.basename(outFile), sources: [] };
    const { html, fallbacks, missing } = render(entry, fs.readFileSync(srcFile, 'utf8'), path.dirname(srcFile), { rows, appHref: '../../index.html' });
    fs.writeFileSync(outFile, html);
    console.log(`wrote ${outFile}: ${Buffer.byteLength(html)} bytes, ${fallbacks.length} formula(s) as text, ${missing.length} missing file(s)${missing.length ? ': ' + missing.join(', ') : ''}`);
    for (const f of fallbacks) console.log(`   as text: $${f.tex}$  (${f.why})`);
    process.exit(0);
  }
  const id = args[0], check = args.includes('--check');
  const entries = JSON.parse(fs.readFileSync(path.join(ROOT, 'content/tutorials.json'), 'utf8'));
  const entry = entries.find(a => a.id === id);
  if (!entry) { console.error(`make_tutorial: no entry "${id}" in content/tutorials.json`); process.exit(1); }
  const srcFile = path.join(ROOT, 'public', entry.sources[0]), outFile = path.join(ROOT, 'public', entry.html);
  const { html, fallbacks, missing } = render(entry, fs.readFileSync(srcFile, 'utf8'), path.dirname(srcFile), { rows });
  for (const f of fallbacks) console.log(`   as text: $${f.tex}$  (${f.why})`);
  if (missing.length) { console.error(`make_tutorial: missing file(s): ${missing.join(', ')}`); process.exit(1); }
  if (check) { const same = fs.existsSync(outFile) && fs.readFileSync(outFile, 'utf8') === html; console.log(`${same ? 'current' : 'OUT OF DATE'}  ${entry.html}`); process.exit(same ? 0 : 1); }
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, html);
  console.log(`wrote ${path.relative(ROOT, outFile)}: ${Buffer.byteLength(html)} bytes, ${fallbacks.length} formula(s) as text`);
}
