// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/labels.js — the port of v15 labelsEngine.js (steps 1, 12 and 17: the clock, gauge gravity, finite groups) onto the one kernel engines/bitrule.js (07 §1–2, task T3.2).
// Nothing here multiplies two blades by itself: every sign and every product comes from the kernel (sign, mul, signTable); this file keeps the v15 API that
// LabelsWidgets.jsx used (same names, same return shapes) and adds the data the V2 figures draw (lattice, clock wheel, Gauss-sum path, four views).
// References: checks/selfcheck/core_check.py (core·B1–B3, the clock), checks/selfcheck/steps15_17/{labels,gtg,groups}_check.py (their logs), and the
// type table of genesis_audit_v3.cliffordCell; tests/engines.test.mjs compares this file with all of them.
import { sign, mul as kmul, signTable, popcount, cell, label, reorderSign, nPairs, PRIMES } from './bitrule.js';
// the stored result the figure gosset-plane draws (gosset_selfcheck.py): read, never recomputed here
import { GOSSET } from './stored.js';

export { popcount, signTable, label, PRIMES };
const pc = popcount;
const bitsOf = m => { const out = []; for (let i = 0; m >> i; i++) if ((m >> i) & 1) out.push(i); return out; };
export { bitsOf };

// ---------------------------------------------------------------- the bit rule, as v15 named it (all through the kernel)
/** sign from putting the generators of a b into increasing order: (−1)^{N(a,b)} (kernel reorderSign) */
export const reorder = (a, b) => reorderSign(a, b);
/** signature: p generators squaring to +1, then q to −1, then r to 0 (kernel cell) */
export const sigVec = (p, q, r = 0) => cell(p, q, r);
/** product of two blades: [blade, sign] — the sign is the kernel's s(a, b) */
export const bladeMul = (a, b, sq) => [a ^ b, sign(a, b, sq)];
export const mvZero = n => new Float64Array(1 << n);
const toMap = x => { const m = new Map(); for (let a = 0; a < x.length; a++) if (x[a]) m.set(a, x[a]); return m; };
/** product of two dense multivectors (Float64Array of length 2^n): the kernel's mul on Maps, written back densely */
export const mul = (x, y, sq) => { const o = new Float64Array(x.length); for (const [k, v] of kmul(toMap(x), toMap(y), sq)) o[k] = v; return o; };

// ---------------------------------------------------------------- the clock (Step 1)
// c = p − q mod 8 names the graded class; the ungraded type follows (the five types R, R2 = R+R, C, H, H2 = H+H)
export const TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C'];
export const FIELD_DIM = { R: 1, R2: 1, C: 2, H: 4, H2: 4 };
/** the type as it is printed: ℝ, ℝ² (= ℝ⊕ℝ), ℂ, ℍ, ℍ² (= ℍ⊕ℍ) */
export const TYPE_SYMBOL = { R: 'ℝ', R2: 'ℝ²', C: 'ℂ', H: 'ℍ', H2: 'ℍ²' };
export const clockOf = (p, q) => (((p - q) % 8) + 8) % 8;
export const typeOf = (p, q) => TYPES[clockOf(p, q)];
// Cl(p,q) = M_k(type) (twice for R2 and H2); k from the number of generators n
export function wedderburn(p, q) {
  const n = p + q, t = typeOf(p, q);
  const k = t === 'R' ? 2 ** (n / 2) : t === 'R2' || t === 'C' ? 2 ** ((n - 1) / 2) : t === 'H' ? 2 ** ((n - 2) / 2) : 2 ** ((n - 3) / 2);
  const copies = t === 'R2' || t === 'H2' ? 2 : 1;
  return { n, c: clockOf(p, q), type: t, k, copies, dim: copies * k * k * FIELD_DIM[t] };
}
const SUBD = '₀₁₂₃₄₅₆₇₈₉';
const subNum = k => String(k).replace(/\d/g, d => SUBD[d]);
/** the algebra written as genesis_audit_v3.cliffordCell writes it: ℝ, M₂(ℍ), M₈(ℝ)⊕M₈(ℝ) … */
export function algebraName(p, q) {
  const w = wedderburn(p, q), base = { R: 'ℝ', R2: 'ℝ', C: 'ℂ', H: 'ℍ', H2: 'ℍ' }[w.type];
  const one = w.k === 1 ? base : `M${subNum(w.k)}(${base})`;
  return w.copies === 2 ? `${one}⊕${one}` : one;
}
// Gauss sum over all 2^n blade addresses: sum_a i^(pos(a) - neg(a)), exact in Z[i]; its phase, the Brown invariant of the Z4-form w = pi + 2Q (core·B1 to B3), is the clock.
// r null generators (placed last) get weight 0 in the exponent: the sum is 2^r times that of Cl(p,q) (core·B3, r ≥ 1).
export function gaussSum(p, q, r = 0) {
  const n = p + q + r, posMask = (1 << p) - 1, negMask = ((1 << q) - 1) << p; let re = 0, im = 0;
  for (let a = 0; a < (1 << n); a++) { const e = (((pc(a & posMask) - pc(a & negMask)) % 4) + 4) % 4; if (e === 0) re++; else if (e === 1) im++; else if (e === 2) re--; else im--; }
  const ang = Math.atan2(im, re), c = (((Math.round(ang / (Math.PI / 4))) % 8) + 8) % 8;
  return { re, im, norm2: re * re + im * im, c };
}
/** Q(a) = [e_a² = −1] and the Z4 form w(a) = π(a) + 2Q(a) mod 4, π(a) = |a| mod 2 — the square read from the kernel's sign(a, a) (core_check.py, Q / pi / w4) */
export const Qform = (a, eps) => (sign(a, a, eps) === -1 ? 1 : 0);
export const w4 = (a, eps) => (pc(a) % 2 + 2 * Qform(a, eps)) % 4;
const I_POW = [[1, 0], [0, 1], [-1, 0], [0, -1]];
/** the Gauss sum of i^w over the blades of Cl(p,q), w from the kernel's squares (core·B3's sum); its phase in units of π/4 is the clock computed from the kernel */
export function gaussSumW(p, q) {
  const eps = cell(p, q), n = p + q; let re = 0, im = 0;
  for (let a = 0; a < (1 << n); a++) { const z = I_POW[w4(a, eps)]; re += z[0]; im += z[1]; }
  const c = (((Math.round(Math.atan2(im, re) / (Math.PI / 4))) % 8) + 8) % 8;
  return { re, im, norm2: re * re + im * im, c };
}
/** the clock read off the kernel (the phase of Σ i^w), to be compared with clockOf and with core.json */
export const clockByKernel = (p, q) => gaussSumW(p, q).c;
/** (1+i)^p (1−i)^q exactly, as [re, im] — the right-hand side of core·B3 */
export function brownTarget(p, q) {
  const m = (x, y) => [x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0]]; let z = [1, 0];
  for (let i = 0; i < p; i++) z = m(z, [1, 1]); for (let i = 0; i < q; i++) z = m(z, [1, -1]); return z;
}
/** the partial sums of Σ i^w(a), blades in counting order a = 0, 1, …, 2^n − 1: at a = 2^k the sum is the Gauss sum of the first k generators (Π_{j<k} (1 + i^{w(e_j)})) */
export function gaussPath(p, q) {
  const eps = cell(p, q), n = p + q, steps = []; let x = 0, y = 0;
  for (let a = 0; a < (1 << n); a++) { const w = w4(a, eps), [dx, dy] = I_POW[w]; steps.push({ a, w, x0: x, y0: y, x: x + dx, y: y + dy }); x += dx; y += dy; }
  const milestones = []; for (let k = 0; k <= n; k++) { const st = steps[(1 << k) - 1]; milestones.push({ k, x: st.x, y: st.y }); }
  return { p, q, n, eps, steps, sum: [x, y], milestones, c: clockOf(p, q) };
}
// Every Cl(p,q) sits inside the all-positive cell Cl(n+2,0) as an algebra with its grading (the reversion is not carried over): a positive generator stays e_j, a negative one becomes e_j P with P = e_{n+1} e_{n+2} (P^2 = -1, P commutes with every e_j)
export function embedCheck(p, q) {
  const n = p + q, host = Array(n + 2).fill(1), P = (1 << n) | (1 << (n + 1));
  const img = []; for (let j = 0; j < n; j++) img.push(j < p ? [1 << j, 1] : [(1 << j) ^ P, 1]);
  const mulS = (u, v) => { const [m, s] = bladeMul(u[0], v[0], host); return [m, s * u[1] * v[1]]; };
  let squaresOk = true, anticommOk = true, oddOk = true;
  for (let j = 0; j < n; j++) { const s = mulS(img[j], img[j]); if (s[0] !== 0 || s[1] !== (j < p ? 1 : -1)) squaresOk = false; if (!(pc(img[j][0]) & 1)) oddOk = false; }
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const a = mulS(img[i], img[j]), b = mulS(img[j], img[i]); if (a[0] !== b[0] || a[1] !== -b[1]) anticommOk = false; }
  // distinct subsets give distinct blades (the low n bits are the subset itself), so the map is one-to-one
  return { n, host: n + 2, squaresOk, anticommOk, oddOk, ok: squaresOk && anticommOk && oddOk, images: img.map(([m]) => m) };
}
export const bladeName = (m, off = 0) => (m === 0 ? '1' : 'e' + Array.from({ length: 12 }, (_, i) => (m >> i & 1 ? String(i + 1 + off) : '')).join(''));

// ---------------------------------------------------------------- the lattice of cells and the 25 cards (Step 1, /cells)
// The 25 cards of v15 in their audited order (genesis_audit_v3.AUDITED_ATLAS: sector id, cell p, q; null = no cell); row = the V2 row id ATL-001 … ATL-025.
// Only the id and the cell are carried over; the audit tier and status are not drawn (the status of a row is computed by the build, 02 §4).
const AUDITED = [
  ['Sector_Vacuum_Origin', 0, 0], ['Sector_Inject_Base_Real', 1, 0], ['Sector_Inject_Fiber_Clock', 0, 1], ['Sector_Quaternionic_Base', 2, 0], ['Sector_Quaternionic_Fiber', 0, 2],
  ['Sector_Trivector_Base', 3, 0], ['Sector_Trivector_Quark', 2, 1], ['Sector_Trivector_Lepton', 1, 2], ['Sector_STA_Euclidean_Base', 4, 0], ['Sector_STA_Minkowski', 3, 1],
  ['Sector_STA_Symmetric_Core', 2, 2], ['Sector_STA_Fiber_Frame', 1, 3], ['Sector_Row5_Base', 4, 1], ['Sector_Row6_Confinement', 4, 2], ['Sector_Row7_Mirror', 4, 3],
  ['Sector_Chiral_Parity', 2, 3], ['Sector_EM_Maxwell', 3, 1], ['Sector_Gravity_Strain', 3, 1], ['Sector_Baryon_Conservation', 5, 3], ['Sector_Electroweak_Unified', 4, 4],
  ['Sector_Vacuum_Mass_Generation', 0, 0], ['Sector_GUT_Junction', 2, 6], ['Sector_Cosmic_Horizon', 0, 8], ['Sector_Open_Questions', null, null], ['Sector_Furey_Ledger', 0, 8],
];
export const CARDS = AUDITED.map(([sector, p, q], i) => ({ row: 'ATL-' + String(i + 1).padStart(3, '0'), sector, p, q }));
export const cardsAt = (p, q) => CARDS.filter(x => x.p === p && x.q === q).map(x => x.row);
/** the cell printed in a labels lens (nothing changes but the string): 'sigword' the cell as a word over +, −, 0; 'bitsq' presence × square of the top blade;
 *  'bits' / 'primes' / 'set' the label of the generators that square to −1 (the form Q on the generators); otherwise "p,q" */
export function cellLabel(p, q, lens = null, r = 0) {
  const eps = cell(p, q, r), n = eps.length, neg = ((1 << q) - 1) << p, top = (1 << n) - 1;
  switch (lens) {
    case 'sigword': return n ? label(0, 'sigword', eps) : '·';
    case 'bitsq': return n ? label(top, 'bitsq', eps) : '·';
    case 'bits': case 'cube': return n ? label(neg, 'bits', eps) : '·';
    case 'primes': case 'prime': return label(neg, 'primes', eps);
    case 'set': case 'simplex': return label(neg, 'set', eps);
    default: return r ? `${p},${q},${r}` : `${p},${q}`;
  }
}
/** the 45 cells with n ≤ nMax (default 8), each with its clock, type, algebra and cards; slots group the cells by (n, c) — one slot is one algebra */
export function cellLattice(nMax = 8) {
  const cells = [];
  for (let n = 0; n <= nMax; n++) for (let q = 0; q <= n; q++) {
    const p = n - q, w = wedderburn(p, q);
    cells.push({ p, q, n, c: w.c, type: w.type, k: w.k, copies: w.copies, dim: w.dim, algebra: algebraName(p, q), token: `--c${w.c}`, cards: cardsAt(p, q) });
  }
  const slots = new Map();
  for (const x of cells) { const key = x.n + ',' + x.c; if (!slots.has(key)) slots.set(key, { n: x.n, c: x.c, type: x.type, k: x.k, copies: x.copies, algebra: x.algebra, token: x.token, cells: [] }); slots.get(key).cells.push(x); }
  return { nMax, cells, slots: [...slots.values()], cards: CARDS };
}
/** the clock wheel of a cell: its sector, the eight sectors with their types, and the phase of its Gauss sum (radians, counter-clockwise) */
export function clockWheel(p, q) {
  const g = gaussSum(p, q), w = wedderburn(p, q);
  return { p, q, n: p + q, c: w.c, type: w.type, algebra: algebraName(p, q), gauss: g, angle: Math.atan2(g.im, g.re), sectors: TYPES.map((t, c) => ({ c, type: t, token: `--c${c}` })) };
}

// ---------------------------------------------------------------- one product in four notations (the Zero page; figure four-views)
const LENSES = ['clifford', 'set', 'bits', 'primes', 'sigword', 'bitsq'];
/** e_a e_b = s(a,b) e_{a xor b} in Cl(p,q,r), with what each notation needs: the reordering count, the squares of the shared generators (Clifford);
 *  the faces (simplex); the walk on the cube from a, flipping the bits of b one at a time; the square-free products of primes, A·B = G²·K with K = lcm/gcd (prime) */
export function views(p, q, r = 0, a = 3, b = 5) {
  const eps = cell(p, q, r), n = eps.length, N = 1 << n; a &= N - 1; b &= N - 1;
  const s = sign(a, b, eps), k = a ^ b, shared = a & b, pairs = nPairs(a, b);
  const P = m => bitsOf(m).reduce((x, i) => x * PRIMES[i], 1);
  const path = [a]; let cur = a; for (const i of bitsOf(b)) { cur ^= 1 << i; path.push(cur); }
  const lab = m => Object.fromEntries(LENSES.map(L => [L, label(m, L, eps)]));
  return {
    p, q, r, n, eps, a, b, k, s, shared, pairs, reorder: pairs & 1 ? -1 : 1,
    sharedIdx: bitsOf(shared), squares: bitsOf(shared).map(i => eps[i]),
    word: { a: bitsOf(a), b: bitsOf(b), sorted: [...bitsOf(a), ...bitsOf(b)].sort((x, y) => x - y), k: bitsOf(k) },
    labels: { a: lab(a), b: lab(b), k: lab(k) },
    prime: { A: P(a), B: P(b), G: P(shared), K: P(k) },
    path,
  };
}

// ---------------------------------------------------------------- the orthoplex on its Petrie polygon (Shapes, figure petrie-orthoplex)
/** the n-orthoplex: vertices ±e_i on the Petrie circle (the two poles of a line opposite), edges between poles of different lines with the product of the two
 *  vectors from the kernel, (s e_i)(t e_j) = s t s(i,j) e_ie_j; its faces counted as the words over {0, +, −} with at least one letter (a face with k vertices picks
 *  k generators and a sign for each: 2^k C(n,k); 3^n with the empty face) — the base-3 labels of the generators */
export function petrie(n, eps = cell(n, 0)) {
  const vertices = [];
  for (let i = 0; i < n; i++) for (const s of [1, -1]) vertices.push({ i, s, angle: 2 * Math.PI * (i + (s === 1 ? 0 : n)) / (2 * n) + Math.PI / 2 });
  const edges = [];
  for (let u = 0; u < vertices.length; u++) for (let v = u + 1; v < vertices.length; v++) {
    const A = vertices[u], B = vertices[v]; if (A.i === B.i) continue;
    edges.push({ u, v, blade: (1 << A.i) | (1 << B.i), coef: A.s * B.s * sign(1 << A.i, 1 << B.i, eps) });
  }
  const faces = Array(n).fill(0); let total = 0;
  for (let w = 0; w < 3 ** n; w++) { let k = 0; for (let t = w; t; t = Math.floor(t / 3)) if (t % 3) k++; total++; if (k) faces[k - 1]++; }
  return { n, eps, vertices, edges, diameters: n, faces, facets: n ? faces[n - 1] : 1, total, antipodes: [...Array(n).keys()].map(i => ({ i, product: -sign(1 << i, 1 << i, eps) })) };
}

// ---------------------------------------------------------------- the commutation graph of the bivectors (step 2, figure comm-graph)
/** the bivectors e_a (|a| = 2) of Cl(p,q) with their roles (the first p generators, square +1, are the time directions: E one time index, B none, T two) and squares;
 *  edges join two bivectors that share one generator: [e_a, e_b] = (s(a,b) − s(b,a)) e_{a xor b} = ±2 e_{a xor b} (kernel); disjoint ones commute; for n = 4 the graph is
 *  the octahedron, complementary bivectors opposite. Roles of the edges counted as equations_selfcheck.py stores them ("B+E via s": the shared generator is space). */
export function commGraph(p, q) {
  const eps = cell(p, q), n = p + q, time = (1 << p) - 1, role = m => ['B', 'E', 'T'][pc(m & time)];
  const biv = []; for (let m = 0; m < 1 << n; m++) if (pc(m) === 2) biv.push(m);
  const edges = [], commuting = [];
  for (let i = 0; i < biv.length; i++) for (let j = i + 1; j < biv.length; j++) {
    const a = biv[i], b = biv[j], sh = a & b, coef = sign(a, b, eps) - sign(b, a, eps);
    if (pc(sh) === 1) edges.push({ a, b, k: a ^ b, coef, via: sh & time ? 't' : 's', pair: [role(a), role(b)].sort().join('+'), result: role(a ^ b) });
    else commuting.push({ a, b, coef });
  }
  let triangles = 0; for (let m = 0; m < 1 << n; m++) if (pc(m) === 3) triangles++;   // the triples of bivectors on three generators
  const roles = {}; for (const e of edges) { const key = `${e.pair} via ${e.via}`; if (!roles[key]) roles[key] = { edges: 0, result: e.result }; roles[key].edges++; }
  return { p, q, n, eps, bivectors: biv.map(m => ({ m, role: role(m), square: sign(m, m, eps) })), edges, commuting, triangles, roles };
}

// ---------------------------------------------------------------- the trinity (Step 1, n = 2): the square of an element X (not of a generator of the cell)
// X = a e1 + b e2 + c e12 in Cl(2,0) = M_2(R):  X^2 = (a^2 + b^2 - c^2) * 1
export const traceless = (a, b, c) => a * a + b * b - c * c;
export const trinityClass = (s, eps = 1e-9) => (s < -eps ? -1 : s > eps ? 1 : 0);   // -1: rotation, +1: boost, 0: translation
export const matrixOf = (a, b, c) => [[a, b + c], [b - c, -a]];
// the same square rebuilt with the bit rule of Cl(2,0), for integer a, b, c (e1 = 1, e2 = 2, e12 = 3)
export function squareByBitRule(a, b, c) { const sq = [1, 1], X = mvZero(2); X[1] = a; X[2] = b; X[3] = c; const Y = mul(X, X, sq); return { scalar: Y[0], rest: Math.abs(Y[1]) + Math.abs(Y[2]) + Math.abs(Y[3]) }; }
// exp(tX) as a 2x2 matrix, by the three closed forms
export function expTX(a, b, c, t) {
  const s = traceless(a, b, c), M = matrixOf(a, b, c); let f, g;
  if (s < -1e-12) { const w = Math.sqrt(-s); f = Math.cos(w * t); g = Math.sin(w * t) / w; } else if (s > 1e-12) { const w = Math.sqrt(s); f = Math.cosh(w * t); g = Math.sinh(w * t) / w; } else { f = 1; g = t; }
  return [[f + g * M[0][0], g * M[0][1]], [g * M[1][0], f + g * M[1][1]]];
}
export const apply = (E, v) => [E[0][0] * v[0] + E[0][1] * v[1], E[1][0] * v[0] + E[1][1] * v[1]];
// the spring x'' = -k x as an element: a = 0, b = (1-k)/2, c = (1+k)/2, so X^2 = -k
export const springX = k => [0, (1 - k) / 2, (1 + k) / 2];
export function gridCounts(R = 6) { let ell = 0, hyp = 0, par = 0; for (let a = -R; a <= R; a++) for (let b = -R; b <= R; b++) for (let c = -R; c <= R; c++) { const s = traceless(a, b, c); if (s < 0) ell++; else if (s > 0) hyp++; else if (a || b || c) par++; } return { ell, hyp, par, total: (2 * R + 1) ** 3 }; }
/** the element X = a e1 + b e2 + c e12 with its square, class and matrix (figure trinity) */
export function trinity(a, b, c) { const s = traceless(a, b, c); return { a, b, c, s, cls: trinityClass(s), M: matrixOf(a, b, c), byBitRule: squareByBitRule(a, b, c) }; }
/** one orbit t ↦ exp(tX) v0 in the phase plane, cut where |x| or |y| exceeds `clip`: a list of polylines [[x, y], …] (the v15 widget's orbit, moved into the engine) */
export function trinityOrbit(a, b, c, v0, { steps = 140, clip = 3.1 } = {}) {
  const s = traceless(a, b, c), cls = trinityClass(s), M = matrixOf(a, b, c), Mv = apply(M, v0), nMv = Math.hypot(Mv[0], Mv[1]); let T0, T1;
  if (cls < 0) { const w = Math.sqrt(-s); T0 = 0; T1 = 2 * Math.PI / w; } else if (cls > 0) { const w = Math.sqrt(s); T0 = -2.6 / w; T1 = 2.6 / w; } else { if (nMv < 1e-9) return []; T0 = -4 / nMv; T1 = 4 / nMv; }
  const lines = []; let cur = null;
  for (let i = 0; i <= steps; i++) { const t = T0 + (T1 - T0) * i / steps, v = apply(expTX(a, b, c, t), v0); if (!Number.isFinite(v[0]) || !Number.isFinite(v[1]) || Math.abs(v[0]) > clip || Math.abs(v[1]) > clip) { cur = null; continue; } if (!cur) { cur = []; lines.push(cur); } cur.push(v); }
  return lines;
}

// ---------------------------------------------------------------- bivectors at n = 4 (Step 1)
export const BIV_MASKS = [3, 5, 9, 6, 10, 12];   // e12 e13 e14 e23 e24 e34
export const BIV_NAMES = ['e12', 'e13', 'e14', 'e23', 'e24', 'e34'];
export const SIGS4 = [[4, 0], [3, 1], [2, 2], [1, 3], [0, 4]];
// B^2 = S + W e1234; the two squares lambda of the commuting simple parts solve  l^2 - S l + W^2 I^2/4 = 0  with I^2 = (-1)^q
export function bivector4(p, q, coef) {
  const sq = sigVec(p, q), B = mvZero(4); BIV_MASKS.forEach((m, i) => { B[m] = coef[i]; });
  const B2 = mul(B, B, sq), S = B2[0], W = B2[15]; let other = 0; for (let m = 1; m < 15; m++) other += Math.abs(B2[m]);
  const I2 = q % 2 ? -1 : 1, disc = S * S - W * W * I2, eps = 1e-9, zero = coef.every(x => x === 0);
  let kind, lam;
  if (disc < -eps) { kind = 'complex'; lam = [[S / 2, Math.sqrt(-disc) / 2], [S / 2, -Math.sqrt(-disc) / 2]]; } else { const r = Math.sqrt(Math.max(0, disc)); lam = [[(S + r) / 2, 0], [(S - r) / 2, 0]]; kind = 'real'; }
  const sg = x => (x < -eps ? -1 : x > eps ? 1 : 0);
  let label;
  if (zero) label = 'zero';
  else if (kind === 'complex') label = 'complex';
  else if (Math.abs(W) < eps) label = S < -eps ? 'rotation' : S > eps ? 'boost' : 'null';
  else { const a = sg(lam[0][0]), b = sg(lam[1][0]); label = a === -1 && b === -1 ? 'double-rotation' : a === 1 && b === 1 ? 'double-boost' : a === 0 && b === 0 ? 'null' : a * b === -1 ? 'rotation-boost' : 'null-mixed'; }
  return { S, W, I2, disc, kind, lam, label, other };
}
/** figure bivector-lab: the same as bivector4 */
export const bivectorLab = (p, q, coef) => bivector4(p, q, coef);
// a deterministic generator, so that "random" counts are the same on every machine
export function lcg(seed) { let s = seed >>> 0; return () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; }; }
export function sampleBivectors(p, q, N = 400, seed = 12345) {
  const r = lcg(seed + 7 * p + q); let real = 0, complex = 0, skipped = 0;
  for (let i = 0; i < N; i++) { const c = Array.from({ length: 6 }, () => Math.round(r() * 6 - 3)); const v = bivector4(p, q, c); if (v.label === 'zero' || Math.abs(v.disc) < 1e-9) { skipped++; continue; } if (v.kind === 'complex') complex++; else real++; }
  return { real, complex, skipped, N };
}

// ---------------------------------------------------------------- gauge gravity (Step 12)
// Painleve-Gullstrand: g = sqrt(2M/r); the radial gradient hbar(e_r) = e_r + g e_t in Cl(1,1) (e_t^2 = +1, e_r^2 = -1) squares to g^2 - 1 = -T, T = 1 - 2M/r
export const pgG = (r, M = 0.5) => Math.sqrt(2 * M / r);       // r in units where 2M = 1 when M = 1/2
export const pgSquare = g => g * g - 1;
export function pgSquareByBitRule(g) { const sq = [1, -1], X = mvZero(2); X[1] = g; X[2] = 1; return mul(X, X, sq)[0]; }   // e_t = bit 1 (index 0), e_r = bit 2
export const pgClass = (g, eps = 1e-9) => { const s = pgSquare(g); return s < -eps ? -1 : s > eps ? 1 : 0; };   // -1 spacelike outside, 0 null on the horizon, +1 timelike inside
// light rays in (r, t): ds^2 = dt^2 - (dr + g dt)^2 gives dr/dt = -g +- 1 ; rain falls with dr/dt = -g ; reversing time sends g to -g
export const pgRays = (g, sign = 1) => ({ out: 1 - sign * g, inn: -1 - sign * g, rain: -sign * g });
export const curvature = n => ({ n, riemann: n * n * (n * n - 1) / 12, ricci: n * (n + 1) / 2, weyl: n >= 3 ? n * (n + 1) * (n + 2) * (n - 3) / 12 : 0, scalarOnly: n <= 3 });

// ---------------------------------------------------------------- finite groups (Step 17)
// from groups_check.py part A and B (exact orders, Schreier-Sims there; the numbers are copied from groups_check.log and compared by tests/engines.test.mjs)
export const RAILS = {
  // n: [E_n type, class of Cl(n,0), |W(E_n)|, image mod 2 = |O(Q)|, kernel]
  E: { 3: ['A2+A1', 'C', 12, 6, 2], 4: ['A4', 'H', 120, 120, 1], 5: ['D5', 'H2', 1920, 1920, 1], 6: ['E6', 'H', 51840, 51840, 1], 7: ['E7', 'C', 2903040, 1451520, 2], 8: ['E8', 'R', 696729600, 348364800, 2] },
  // n: [class of Cl(0,n), |S_{n+1}| = image, |O(Q)|]
  A: { 2: ['H', 6, 6], 3: ['H2', 24, 24], 4: ['H', 120, 120], 5: ['C', 720, 720], 6: ['R', 5040, 40320], 7: ['R2', 40320, 2580480], 8: ['R', 362880, 348364800] },
};
export const factorial = n => { let f = 1; for (let i = 2; i <= n; i++) f *= i; return f; };
// [24,12,8] Golay code: the cyclic [23,12,7] code with generator x^11+x^10+x^6+x^5+x^4+x^2+1, plus an overall parity bit
export function golay() {
  const G = 0xC75, words = new Int32Array(4096);
  for (let m = 0; m < 4096; m++) { let w = 0; for (let i = 0; i < 12; i++) if (m >> i & 1) w ^= G << i; if (pc(w) & 1) w |= 1 << 23; words[m] = w; }
  const hist = {}; for (const w of words) { const k = pc(w); hist[k] = (hist[k] || 0) + 1; }
  const octads = Array.from(words).filter(w => pc(w) === 8);
  return { words, hist, octads };
}
// the unique octad through five points (a 24-bit mask with five bits), or null
export const octadThrough = (octads, mask) => { const hit = octads.filter(o => (o & mask) === mask); return hit.length === 1 ? hit[0] : hit.length ? 'many' : null; };
// primes: a prime p first divides 2^n - 1 at n = ord_p(2)
export const ordTwo = p => { let x = 2 % p, n = 1; while (x !== 1) { x = (x * 2) % p; n++; } return n; };
export function factorize(m) { const f = []; for (let d = 2; d * d <= m; d++) while (m % d === 0) { f.push(d); m = m / d; } if (m > 1) f.push(m); return f; }
export const newPrimes = n => [...new Set(factorize(2 ** n - 1))].filter(p => ordTwo(p) === n);
export const MONSTER_PRIMES = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 41, 47, 59, 71];

// ---------------------------------------------------------------- Maxwell ∇F = J in four notations (the light calibration; figure four-views-maxwell)
/** the field equation ∇F = J of a bivector F in Cl(k, d) (k time generators squaring to +1 first, then d space generators squaring to −1; ∇ = Σ γ_a ∂_a): every term is
 *  one move e_a e_S = s e_{S xor a} of a field piece e_S (grade 2) along an axis a, a contraction to a vector when a is in S (δF = J) and a wedge to a trivector when it is
 *  not (dF = 0); s is the kernel's sign. Roles from the labels alone: a vector is ρ (time) or J (space); a bivector E (one time index), T (two) or B (none); a trivector
 *  is a Faraday equation (with a time index) or ∇·B (without). checks/selfcheck/maxwell.json (maxwell_selfcheck.py) stores the same
 *  incidences for the 15 cells k, d <= 4, k + d <= 7, with the textbook sign of each field component on top (conventions.signs); tests/engines.test.mjs compares. */
export function maxwellViews(k = 1, d = 3) {
  const n = k + d, eps = cell(k, d), time = (1 << k) - 1, N = 1 << n;
  const role = m => { const g = pc(m), t = pc(m & time); if (g === 0) return 'scalar'; if (g === 1) return t ? 'rho' : 'J'; if (g === 2) return t === 1 ? 'E' : t === 2 ? 'T' : t === 0 ? 'B' : 'other'; if (g === 3) return t ? 'Faraday' : 'divB'; return g === n ? 'pseudo' : 'other'; };
  const axes = (k === 1 ? ['t'] : [...Array(k).keys()].map(i => 't' + (i + 1))).concat(['x', 'y', 'z', 'w'].slice(0, d));
  const blades = Array.from({ length: N }, (_, m) => ({ m, grade: pc(m), square: sign(m, m, eps), role: role(m) }));
  const field = blades.filter(b => b.grade === 2).map(b => b.m);
  const incidences = [];
  for (const S of field) for (let a = 0; a < n; a++) incidences.push({ source: S, axis: a, target: S ^ (1 << a), op: (S >> a) & 1 ? 'contract' : 'wedge', sign: sign(1 << a, S, eps) });
  const targets = blades.filter(b => b.grade === 1 || b.grade === 3).map(b => b.m);
  const equations = targets.map(T => ({ target: T, op: pc(T) === 1 ? 'contract' : 'wedge', terms: incidences.filter(i => i.target === T) }));
  const counts = { E: field.filter(m => role(m) === 'E').length, T: field.filter(m => role(m) === 'T').length, B: field.filter(m => role(m) === 'B').length };
  const layers = Array.from({ length: n + 1 }, (_, g) => blades.filter(b => b.grade === g).length);
  return { k, d, n, eps, axes, blades, field, incidences, targets, equations, counts, layers };
}

// ---------------------------------------------------------------- the cube as mirrors (step 3; figure mirrors-cube)
/** the n-cube read as mirrors in Cl(p, q) (default Cl(n, 0)): the corner S is the product of the coordinate mirrors of its axes and, as the twisted sandwich
 *  x ↦ (−1)^{|S|} e_S x e_S⁻¹ (the kernel's products), it flips exactly the axes in S; its number of mirrors is its weight. The corners by weight (the binomial
 *  layers), the even half (the rotors: the demicube), the counts of the ladder (corners, rotors, reflections, edges, |B_n| = 2^n n!, |D_n| = 2^{n−1} n!).
 *  checks/selfcheck/mirrors.json (mirrors_selfcheck.py) stores the ladder n = 2..8 and the corners of both signatures; tests/engines.test.mjs compares. */
export function mirrors(n = 4, q = 0) {
  const eps = cell(n - q, q), N = 1 << n, fact = m => { let f = 1; for (let i = 2; i <= m; i++) f *= i; return f; };
  const twisted = (S, x) => { const inv = kmul(new Map([[S, 1]]), new Map([[0, 1 / sign(S, S, eps)]]), eps); return [...kmul(kmul(new Map([[S, pc(S) % 2 ? -1 : 1]]), x, eps), inv, eps)]; };
  const corners = [];
  for (let S = 0; S < N; S++) {
    let flips = 0, exact = true;
    for (let i = 0; i < n; i++) { const img = twisted(S, new Map([[1 << i, 1]])); if (img.length !== 1 || img[0][0] !== (1 << i) || Math.abs(img[0][1]) !== 1) exact = false; else if (img[0][1] === -1) flips |= 1 << i; }
    corners.push({ S, weight: pc(S), even: pc(S) % 2 === 0, flips, exact });
  }
  const layers = Array.from({ length: n + 1 }, (_, w) => corners.filter(c => c.weight === w).map(c => c.S));
  return {
    n, q, eps, corners, layers, allFlip: corners.every(c => c.exact && c.flips === c.S),
    counts: { corners: N, layers: layers.map(l => l.length), rotors: N / 2, reflections: N / 2, rotor_layers: layers.filter((_, w) => w % 2 === 0).map(l => l.length), max_mirrors: n, edges_of_cube: n * N / 2, B_order: N * fact(n), D_order: (N / 2) * fact(n) },
  };
}
/** the two examples of mirrors.json (mirrors_selfcheck.py), as stored: the normals of two mirrors and the matrix of their product (rotation in Cl(2,0), boost in Cl(1,1));
 *  copied so that the figure can draw them, and compared with the stored file by tests/engines.test.mjs */
export const MIRROR_EXAMPLES = {
  rotation_3_4_5: { q: 0, normals: [['2', '0'], ['8/5', '-4/5']], matrix: [['3/5', '-4/5'], ['4/5', '3/5']] },
  boost_5_4_3_4: { q: 1, normals: [['1/4', '-5/4'], ['-2', '4']], matrix: [['5/4', '3/4'], ['3/4', '5/4']] },
};
/** two mirrors make a rotation (a boost in Cl(1,1)): the reflections x ↦ −a x a⁻¹ in the lines normal to a2, then a1 (the kernel's products in Cl(2,0) or Cl(1,1)),
 *  applied to x = e1; the stored examples of mirrors.json (rotation 3/5, 4/5 and boost 5/4, 3/4) give their mirror normals as fractions */
export function twoMirrors(a1, a2, q = 0, x = [1, 0]) {
  const eps = cell(2 - q, q), vec = v => new Map([[1, v[0]], [2, v[1]]].filter(([, c]) => c !== 0));
  const reflect = (a, p) => { const A = vec(a), aa = (kmul(A, A, eps).get(0) || 0), r = kmul(kmul(A, vec(p), eps), A, eps); return [-(r.get(1) || 0) / aa, -(r.get(2) || 0) / aa]; };
  const y = reflect(a2, x), z = reflect(a1, y);
  return { eps, x, y, z, normals: [a1, a2] };
}

// ---------------------------------------------------------------- the shapes (figures gosset-plane, zonogon) and one more generator (figure extra-generator)
/** the roots of E6, E7, E8 projected onto the Coxeter plane, as gosset_selfcheck.py stores them (checks/selfcheck/gosset.json coxeter): each point (x, y) on a ring,
 *  of kind 'e' (an edge of the orthoplex, ±e_i ± e_j) or 'd' (a corner of the demicube, ½(±1, …, ±1)); h points on each ring, h the Coxeter number. The stored
 *  points are read, not recomputed; tests/engines.test.mjs compares the counts with gosset.json rank and coordinates. Port of v15 GossetSection.Plane. */
export function gossetPlane(n = 8) {
  const c = GOSSET.coxeter[String(n)]; if (!c) return null;
  const points = c.points.map(([x, y, ring, kind]) => ({ x, y, ring, kind }));
  const rings = c.ring_radii.map((r, ring) => ({ ring, r, count: points.filter(p => p.ring === ring).length }));
  const kinds = { e: points.filter(p => p.kind === 'e').length, d: points.filter(p => p.kind === 'd').length };
  return { n, h: c.h, roots: GOSSET.rank[String(n)].roots, points, rings, kinds };
}
/** the n-cube projected with the edge vectors v_i = (cos πi/n, sin πi/n), whose shadow is the 2n-gon (the zonogon), split into its even corners (the n-demicube:
 *  the even blades, by grade) and its odd corners; an edge of the demicube joins two even corners that differ in two bits. Port of v15 ShapesSection.Zonogon (the same
 *  projection and edges). shapes_selfcheck.py stores the demicube of every n = 3..8 (shapes.json demicube.rows: even labels, edges, edges by grade pair, even blades
 *  by grade); tests/engines.test.mjs compares. */
export function zonogon(n = 5) {
  const v = Array.from({ length: n }, (_, i) => [Math.cos(Math.PI * i / n), Math.sin(Math.PI * i / n)]), N = 1 << n;
  const corners = Array.from({ length: N }, (_, m) => { let x = 0, y = 0; for (let i = 0; i < n; i++) if ((m >> i) & 1) { x += v[i][0]; y += v[i][1]; } return { m, x, y, grade: pc(m), even: pc(m) % 2 === 0 }; });
  const edges = []; for (let m = 0; m < N; m++) if (pc(m) % 2 === 0) for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) { const y = m ^ (1 << i) ^ (1 << j); if (y > m) edges.push([m, y]); }
  const cubeEdges = []; for (let m = 0; m < N; m++) for (let i = 0; i < n; i++) if (!((m >> i) & 1)) cubeEdges.push([m, m | (1 << i)]);
  const byGrade = {}; for (const c of corners) if (c.even) byGrade[c.grade] = (byGrade[c.grade] || 0) + 1;
  const byPair = {}; for (const [a, b] of edges) { const k = [pc(a), pc(b)].sort((s, t) => s - t).join('-'); byPair[k] = (byPair[k] || 0) + 1; }
  return { n, vectors: v, corners, edges, cubeEdges, evenLabels: corners.filter(c => c.even).map(c => c.m), byGrade, byPair };
}
/** step 11: n base axes ('space': every axis squares to −1; 'lorentz': the first squares to +1, the others to −1) and one more generator e with e² = s ∈ {0, −1, +1}.
 *  The plane B_a = e_a e of each base axis squares to −e_a² e² (the kernel's sign of the blade with bits a and n). Port of v15 ProjectiveSection.LadderPic;
 *  projective_selfcheck.py stores the same squares (projective.json ladder["kind,n,s"].extra_squares), compared by tests/engines.test.mjs. */
export function extraGenerator(kind = 'lorentz', n = 4, s = -1) {
  const base = kind === 'space' ? Array(n).fill(-1) : [1, ...Array(n - 1).fill(-1)], eps = [...base, s];
  const planes = base.map((q, a) => { const m = (1 << a) | (1 << n); return { a, mask: m, axisSquare: q, square: sign(m, m, eps) + 0 }; });
  return { kind, n, s, base, eps, planes };
}

// ---------------------------------------------------------------- gravity on the bit rule (figure connection-forms)
const binom = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); };
const bitIndex = m => 31 - Math.clz32(m);
/** the engine tables of gravity_selfcheck.py (its class Lie, and its class Forms) for the frame algebra Cl(1, n−1) of n space-time directions (γ₀ squares to +1,
 *  the others to −1), every product from the kernel: the bivectors B_A = γ_a γ_b (a < b, in the script's order); f, the commutator [B_A, B_B] = f B_C (f = ±2, and
 *  only when the two share exactly one index: disjoint planes commute); h, the commutator ½[B_A, γ_b] = h γ_c (h = ±1, only when b is an index of B_A); and the
 *  forms, the same rule with every square 0: dx^μ dx^ν = ±dx^μν off the diagonal, 0 on it. With the counts of the ladder the script stores (gravity.json ladder:
 *  bivectors, boosts, rotations, the pair classes, the components of ω, e, R and T), compared by tests/engines.test.mjs. */
export function frameAlgebra(n = 4) {
  const eps = [1, ...Array(n - 1).fill(-1)], nul = Array(n).fill(0), gens = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) gens.push((1 << i) | (1 << j));
  const idx = new Map(gens.map((g, k) => [g, k]));
  const f = gens.map(ga => gens.map(gb => { const s1 = sign(ga, gb, eps), s2 = sign(gb, ga, eps); return s1 !== s2 ? { C: idx.get(ga ^ gb), coef: s1 - s2 } : null; }));
  const h = gens.map(ga => Array.from({ length: n }, (_, b) => { const m = 1 << b, s1 = sign(ga, m, eps), s2 = sign(m, ga, eps); return s1 !== s2 ? { c: bitIndex(ga ^ m), coef: (s1 - s2) / 2 } : null; }));
  const forms = Array.from({ length: n }, (_, mu) => Array.from({ length: n }, (_, nu) => ({ mask: (1 << mu) ^ (1 << nu), sign: sign(1 << mu, 1 << nu, nul) + 0 })));
  const squares = gens.map(g => sign(g, g, eps) + 0), G = gens.length;
  let shareOne = 0, disjoint = 0;
  gens.forEach((ga, A) => gens.forEach((gb, B) => { if (B > A) { if (f[A][B]) shareOne++; else disjoint++; } }));
  const counts = {
    bivectors: G, boosts: squares.filter(s => s === 1).length, rotations: squares.filter(s => s === -1).length,
    pair_classes: { diagonal: G, share_one_index: shareOne, disjoint },
    omega_components: n * G, tetrad_components: n * n, curvature_components: G * binom(n, 2), torsion_components: n * binom(n, 2), poincare_generators: G + n,
  };
  return { n, eps, gens, names: gens.map(g => bitsOf(g).join('')), squares, f, h, forms, counts };
}
