// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/labelsEngine.js — the v15 module of steps 1, 12 and 17 (the clock, gauge gravity, finite groups), kept under its v15 name with its v15 API (the 42
// exports below) as a re-export of engines/labels.js, the port onto the one kernel engines/bitrule.js (07 §1–2, task T3.2). Nothing here multiplies two blades:
// bladeMul, mul, reorder, squareByBitRule, bivector4, pgSquareByBitRule and embedCheck take every sign from the kernel. engines/stored/labelsEngine_v15.json
// holds what the v15 module returned on a fixed set of inputs before this change, and tests/engines.test.mjs (section H) compares the two: bit for bit, except
// that a blade product that squares a null generator is now +0 where v15 could give −0 (the same number).
export {
  popcount, reorder, sigVec, bladeMul, mvZero, mul,
  TYPES, FIELD_DIM, clockOf, typeOf, wedderburn, gaussSum, embedCheck, bladeName,
  traceless, trinityClass, matrixOf, squareByBitRule, expTX, apply, springX, gridCounts,
  BIV_MASKS, BIV_NAMES, SIGS4, bivector4, lcg, sampleBivectors,
  pgG, pgSquare, pgSquareByBitRule, pgClass, pgRays, curvature,
  RAILS, factorial, golay, octadThrough, ordTwo, factorize, newPrimes, MONSTER_PRIMES,
} from './labels.js';
