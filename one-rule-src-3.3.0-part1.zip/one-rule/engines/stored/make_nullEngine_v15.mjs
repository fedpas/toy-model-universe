// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/nullEngine_v15.json: the exports of v15 nullEngine.js (step 13, null surfaces) on a fixed set of inputs — the bit product and the
// brackets of every pair of labels < 16 in several sign vectors of length 8 (squares +1, −1, 0 and a non-unit T), the tube algebra, the five horizons, the Kerr
// numbers, the ladder names — recorded before the module was re-pointed onto engines/bitrule.js (T3.2). tests/engines.test.mjs imports CASES and runs them.
//   node engines/stored/make_nullEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir } from './fixture_codec.mjs';

const SQS = [[1, -1, -1, 0, 0, 0, 0, 0], [0, -1, -1, 0, 0, 0, 0, 0], [-1, -1, -1, 0, 0, 0, 0, 0], [0.3, -1, -1, 0, 0, 0, 0, 0], [-2.5, -1, -1, 0, 0, 0, 0, 0], [1, 1, 1, 1, 1, 1, 1, 1], [1, -1, 0, 1, -1, 0, 1, -1], [0, 0, 0, 0, 0, 0, 0, 0], [0.5, 2, -3, 1, -1, 0.25, 1, 1]];
export const CASES = ({ M }) => {
  const C = [];
  C.push(['popc, frac', () => [[0, 1, 6, 255, 1023].map(M.popc), ['3', '-2/5', '7/2', '0', '1/3'].map(M.frac)]]);
  for (const [i, sq] of SQS.entries()) C.push([`bitMul and bracket, labels < 16, sign vector ${i}`, () => { const o = []; for (let a = 0; a < 16; a++) for (let b = 0; b < 16; b++) o.push(M.bitMul(a, b, sq), M.bracket(a, b, sq)); return o; }]);
  C.push(['bitMul, labels < 256, sign vector 6', () => { const o = []; for (let a = 0; a < 256; a += 3) for (let b = 0; b < 256; b += 5) o.push(M.bitMul(a, b, SQS[6]).c); return o; }]);
  C.push(['KJ, tube', () => [M.KJ, ...[1, 0, -1, 0.5, -2.5, 1e-13, -0.25].map(M.tube)]]);
  C.push(['HORIZONS, PROBE, kappaNum, tMax', () => [M.PROBE, M.HORIZONS.map(h => [h.id, h.xh, [0.5, 0.9, 1.5, 2.2, 3.7].map(x => h.T(h.xh + x - 1)), M.kappaNum(h), M.tMax(h)])]]);
  C.push(['surfaceKind, gramTortoise, gramEF, mirrorImage', () => [[-1, -1e-13, 0, 1e-13, 0.4].map(M.surfaceKind), [2, -0.5].map(M.gramTortoise), M.gramEF(), [[[1, 0], 0.5], [[0.3, -0.7], -2], [[1, 1], 0], [[2, 3], 1e-13]].map(([w, T]) => M.mirrorImage(w, T))]]);
  C.push(['schwT, kruskalX, ellisL, invariants, rates', () => [1.01, 1.5, 2, 3, 7.5].map(r => [M.schwT(r), M.kruskalX(r, 0.3), M.ellisL(r), M.invariants.schw(r), M.invariants.ellis(r), M.rates.schw.dr(r), M.rates.schw.dl(r), M.rates.ellis.dr(r), M.rates.ellis.dl(r)])]);
  C.push(['EQ1, Ffac', () => M.EQ1.map(c => [c.id, [0.2, 0.5, 1, 2].map(x => [c.T(x), c.dT(x), c.eq1(x), M.Ffac(c, x)])])]);
  C.push(['KERR, kerrErgo, kerrGtt, kerrNN, kerrXZ', () => [M.KERR, [0, 0.1, 0.25, 0.5, 0.75, 0.9, 1].map(w => [M.kerrErgo(w), M.kerrGtt(9.5, w), M.kerrNN(w)]), [[9, 0], [9, 0.7], [12, Math.PI / 2], [10, 2.5]].map(([r, th]) => M.kerrXZ(r, th))]]);
  C.push(['NS, QUOT, CELL, bitName, blade, inJ, choose, isPow2', () => [M.NS, M.QUOT, M.CELL, M.NS.map(n => Array.from({ length: n - 1 }, (_, i) => M.bitName(n, i))), M.NS.map(n => Array.from({ length: 1 << (n - 1) }, (_, S) => [M.blade(n, S), M.inJ(n, S)])), [[5, 2], [6, 3], [4, 0], [3, 4]].map(([n, k]) => M.choose(n, k)), [0, 1, 2, 3, 4, 6, 8, 1024].map(M.isPow2)]]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'nullEngine.js', dir: v15Dir('engines/stored/make_nullEngine_v15.mjs'), files: { M: 'nullEngine.js' }, cases: CASES, outUrl: new URL('./nullEngine_v15.json', import.meta.url) }));
}
