// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/spinEngine_v15.json: the exports of v15 spinEngine.js (step 5) on a fixed set of inputs — the algebra mk(sq) of every sign vector n <= 3
// (every blade pair, seeded multivector products, sums, reverses, inverses, names), the rotor, the kinds of i, the pseudoscalars d <= 8, the labellings d = 2..8,
// the spinors k = 1, 3, the pointor and Hestenes samples, the chirality — and of v15 springEngine.js, which builds on mk (step 15), recorded before spinEngine.js
// was re-pointed onto engines/bitrule.js (T3.2). tests/engines.test.mjs imports CASES and runs the same inputs through the re-pointed modules.
//   node engines/stored/make_spinEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir, prng, pint, signVectors } from './fixture_codec.mjs';

const pick = (o, keys) => Object.fromEntries(keys.map(k => [k, o[k]]));
export const CASES = ({ M, S }) => {
  const C = [];
  C.push(['pc, EPS', () => [[0, 1, 6, 255, 1023, 65535].map(M.pc), M.EPS]]);
  for (let m = 0; m <= 3; m++) C.push([`mk: bm of every pair, n = ${m}, every sign vector`, () => signVectors(m).map(sq => { const A = M.mk(sq), o = []; for (let a = 0; a < 1 << m; a++) for (let b = 0; b < 1 << m; b++) o.push(...A.bm(a, b)); return o; })]);
  C.push(['mk(1,1,1,1) and mk(1,-1,-1,-1): bm of every pair', () => [[1, 1, 1, 1], [1, -1, -1, -1], [1, 1, 0, -1]].map(sq => { const A = M.mk(sq), o = []; for (let a = 0; a < 16; a++) for (let b = 0; b < 16; b++) o.push(...A.bm(a, b)); return o; })]);
  C.push(['mk: seeded products, sums, scales, reverses, inverses, eq, get, part, name, show (n = 1..5)', () => { const r = prng(55), o = []; for (let i = 0; i < 60; i++) { const n = 1 + (i % 5), sq = Array.from({ length: n }, () => [1, -1, 0, 1][pint(r, 0, 3)]), A = M.mk(sq), mv = () => { const x = new Map(); for (let a = 0; a < 1 << n; a++) if (r() < 0.45) x.set(a, r() < 0.5 ? pint(r, -3, 3) : r() * 2 - 1); return x; }, X = mv(), Y = mv(), Z = mv();
    o.push([sq, A.n, A.mul(X, Y), A.mul(A.mul(X, Y), Z), A.add(X, Y), A.add(X, Y, -0.5), A.scale(X, 1.75), A.rev(X), A.eq(A.mul(X, Y), A.mul(Y, X)), A.get(A.mul(X, X), 0), A.part(X, k => k % 2 === 1), A.prod(X, Y, Z), A.inv(A.g(n - 1)), A.inv(A.add(A.one, A.g(0))), A.show(X), A.show(A.mul(X, Y)), A.name((1 << n) - 1), A.I, A.zero, A.one]); } return o; }]);
  C.push(['mk: inverses of versors', () => { const r = prng(56), o = []; for (const sq of [[1, 1, 1], [1, -1, -1, -1], [-1, -1], [1, 1, 1, 1, 1]]) { const A = M.mk(sq); for (let t = 0; t < 6; t++) { let v = A.one; for (let d = 0; d < 1 + (t % 3); d++) { const w = new Map(); for (let j = 0; j < A.n; j++) { const c = pint(r, -2, 2); if (c) w.set(1 << j, c); } if (!w.size) w.set(1, 1); v = A.mul(v, w); } o.push([v, A.inv(v), A.mul(v, A.inv(v) || A.one)]); } } return o; }]);
  C.push(['rng, ri', () => [1, 2, 99].map(s => { const g = M.rng(s); return [Array.from({ length: 6 }, g), Array.from({ length: 6 }, () => M.ri(g)), Array.from({ length: 6 }, () => M.ri(g, 1, 3))]; })]);
  C.push(['planar', () => Array.from({ length: 25 }, (_, k) => pick(M.planar(k * Math.PI / 12), ['R', 'vec', 'ok']))]);
  C.push(['kinds (a, b) in {-1, 0, 1}^2 and two non-units', () => [-1, 0, 1, 2, -0.5].flatMap(a => [-1, 0, 1].map(b => M.kinds(a, b)))]);
  C.push(['pseudoscalar d = 1..8', () => [1, 2, 3, 4, 5, 6, 7, 8].map(M.pseudoscalar)]);
  C.push(['labelling d = 2, 4, 6, 8', () => [2, 4, 6, 8].map(d => pick(M.labelling(d), ['k', 'ms', 'cls', 'H', 'sameAsPlus', 'ok', 'selfDual']))]);
  C.push(['spinors k = 1, 3: phi, B, u, v, w, cx', () => [1, 3].map(k => { const P = M.spinors(k), sg = Array.from({ length: 1 << k }, (_, t) => Array.from({ length: k }, (_, j) => (t >> j & 1 ? -1 : 1))); return [P.k, P.d, P.I, sg.map(s => P.phi(s)), Array.from({ length: k }, (_, j) => [P.B(j), P.u(j), P.v(j)]), P.w, P.cx(0.5, -2)]; })]);
  C.push(['pointorTest, versor', () => { const E = M.mk([1, 1, 1, 1]), r = M.rng(7), o = []; for (let i = 0; i < 6; i++) { const R = M.versor(E, r, 2), V = M.versor(E, r, 1, 2); o.push([R, V, M.pointorTest(E, R, E.I), M.pointorTest(E, E.add(R, V), E.I)]); } return o; }]);
  C.push(['pointorSample: 4 kinds x 12 seeds', () => M.PKINDS.flatMap(kd => Array.from({ length: 12 }, (_, i) => pick(M.pointorSample(kd, i + 1), ['ok', 'lam', 'txt', 'psi'])))]);
  C.push(['PKINDS, EVEN, cl13', () => [M.PKINDS, M.EVEN, M.cl13().sq, M.cl13().I]]);
  C.push(['hestenes: generic x 24, versor x 12', () => [...Array.from({ length: 24 }, (_, i) => pick(M.hestenes('generic', i + 1), ['a', 'b', 'other', 'ok'])), ...Array.from({ length: 12 }, (_, i) => pick(M.hestenes('versor', i + 1), ['a', 'b', 'other', 'ok']))]]);
  C.push(['chirality', () => M.chirality()]);
  // springEngine.js builds on mk: its outputs ride on the same products
  C.push(['spring: oscillator, orbit, oscillator0', () => [...Object.keys(S.KINDS).flatMap(k => [[0.7, 0, 1, 0], [1.3, 0.9, 0.5, -0.25], [2, 2.5, -1, 1]].map(([w, t, x0, q0]) => S.oscillator(k, w, t, x0, q0))), S.orbit('harmonic', 1, 1, 0, 6, 12), S.orbit('inverted', 0.5, 1, 0.2, 2, 8), S.oscillator0('free', 1, 2, 0.5, 1)]]);
  C.push(['spring: walsh, cube counts, modes, pluck, energies, levels', () => [1, 2, 3, 4].map(n => [S.counts(n), S.edges(n), S.faces(n), S.mode(n, (1 << n) - 1, 0.4), S.pluck(n, 0, 0.7), S.pluckVel(n, 1, 0.3), S.springEnergy(n, S.randomDisp(n, 3)), S.kinetic(S.randomDisp(n, 4)), Array.from({ length: n + 1 }, (_, j) => S.levelShare(n, j)), S.plainLevels(n), S.signedLevels(n), S.faceSums(n, S.stretch(n, S.randomDisp(n, 5))), S.faceSums(n, S.randomField(n, 9, true))])]);
  C.push(['spring: signedD, fluxes, signedChecks, signedEnergy, labelRow', () => [1, 2, 3, 4].map(n => [S.signedD(n), S.fluxes(n), S.signedChecks(n), S.signedEnergy(n, S.randomDisp(n, 6)), Array.from({ length: 1 << n }, (_, m) => S.labelRow(n, m))])]);
  C.push(['spring: binom, omega2, project, bits, PROJ', () => [[[5, 2], [8, 4]].map(([n, k]) => S.binom(n, k)), [0, 1, 7, 15].map(S.omega2), [0, 5, 31].map(x => [S.project(5, x), S.bits(5, x)]), S.PROJ]]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'spinEngine.js (+ springEngine.js)', dir: v15Dir('engines/stored/make_spinEngine_v15.mjs'), files: { M: 'spinEngine.js', S: 'springEngine.js' }, cases: CASES, outUrl: new URL('./spinEngine_v15.json', import.meta.url) }));
}
