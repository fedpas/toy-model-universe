// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/schullerEngine_v15.json: the exports of v15 schullerEngine.js (SW1–SW7, step 20) on a fixed set of inputs — hyperbolicity n <= 7,
// symbol determinants, the product tables of every eps with n <= 3 (statistics n <= 4), the eight gammas and the fibres k = 0..8, left and right actions n <= 3,
// SL(2,Z) words, the Floquet curves, Fock seats, magnets and the Pauli table — recorded before the module was re-pointed onto engines/bitrule.js (T3.2).
//   node engines/stored/make_schullerEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir, prng, pint, signVectors } from './fixture_codec.mjs';

const upTo = N => { const o = []; for (let m = 0; m <= N; m++) o.push(...signVectors(m)); return o; };
export const CASES = ({ M }) => {
  const C = [];
  C.push(['pc, sigVec, TYPES, sigOf, STONES', () => [[0, 3, 255, -1].map(M.pc), M.sigVec(1, 3), M.sigOf(2, 1, 1), M.TYPES, M.STONES]]);
  C.push(['lorentzian, waveKind', () => { const o = []; for (let k = 0; k <= 5; k++) for (let d = 0; d <= 5; d++) o.push([M.lorentzian(k, d), M.waveKind(k, d)]); return o; }]);
  C.push(['hypMatrix, witness', () => [[[1, -1, -1, -1], [1, 0, 0, 0]], [[1, -1, -1, -1], [0, 1, 1, 0]], [[1, 1, -1, -1], [1, 1, 0, 0]], [[1, 1, -1, -1], [1, 0, 1, 0]], [[-1, -1, -1], [1, 2, 0]]].map(([S, h]) => { const H = M.hypMatrix(S, h); return [H, H.Ph ? M.witness(S, h, H.Ph) : null]; })]);
  C.push(['hypMap(2, 7)', () => M.hypMap(2, 7)]);
  C.push(['leftMatrix, bareissDet', () => [[{ 0: 1, 1: 2, 2: -1 }, [1, -1]], [{ 3: 1, 0: -2 }, [1, 1]], [{ 1: 1, 2: 1, 4: 1, 0: -3 }, [1, -1, 0]], [{ 7: 2, 1: 1 }, [-1, -1, -1]]].map(([x, sq]) => { const L = M.leftMatrix(x, sq); return [L, M.bareissDet(L)]; })]);
  C.push(['squareVec, quadQ, symbolDet', () => [[[1, -1, -1, -1], [2, 1, 0, 0], 1], [[1, -1, -1, -1], [1, 2, 3, 4], 2], [[1, 1, -1, -1], [1, 1, 1, 1], 0], [[1, -1, 0], [3, 1, 5], 2], [[-1, -1, -1], [1, 0, 2], 1]].map(([S, mom, m]) => [M.squareVec(S, mom), M.quadQ(S, mom), M.symbolDet(S, mom, m)])]);
  C.push(['extraGen', () => [[[1, -1, -1, -1], [2, 1, 0, 0], 1, -1], [[1, -1, -1, -1], [2, 1, 0, 0], 1, 1], [[1, -1, -1], [1, 1, 0], 2, 0], [[1, -1], [3, 1], 0, -1]].map(([S, mom, mf, e]) => [M.extraGen(S, mom, mf, e), M.extraGen(S, mom, mf, e, false)])]);
  C.push(['productTable, every eps n <= 3', () => upTo(3).map(sq => M.productTable(sq))]);
  C.push(['tableStats, every eps n <= 4', () => upTo(4).map(sq => M.tableStats(sq))]);
  C.push(['bladeLabel, bitString', () => [0, 1, 6, 11, 31].map(a => [M.bladeLabel(a, 5), M.bitString(a, 5)])]);
  C.push(['monomial matrices: mono, mmul, mid, mneg, meq, mprod, dense', () => { const A = M.mono([[0, 1, 0], [1, 0, 0], [0, 0, -1]]), B = M.mono([[0, 0, 1], [0, -1, 0], [1, 0, 0]]); return [A, B, M.mmul(A, B), M.mid(3), M.mid(3, -1), M.mid(3, 0), M.mneg(A), M.meq(A, A), M.meq(A, B), M.mprod([A, B, A], 3), M.dense(A)]; }]);
  C.push(['rankInt, monoRank, commutantDim', () => [M.rankInt([[1, 2, 3], [2, 4, 6], [1, 0, 1]]), M.rankInt([[0, 0], [0, 0]]), M.monoRank([M.mid(4), M.mneg(M.mid(4)), M.mono([[0, 1, 0, 0], [1, 0, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]])]), M.commutantDim([M.mono([[0, 1], [1, 0]])], 2), M.commutantDim([M.mono([[0, -1], [1, 0]])], 2)]]);
  C.push(['gammas', () => M.gammas()]);
  C.push(['outsideInside k = 0..8', () => Array.from({ length: 9 }, (_, k) => M.outsideInside(k))]);
  C.push(['leftRight, every cell n <= 3', () => { const o = []; for (let n = 0; n <= 3; n++) for (let p = 0; p <= n; p++) for (let q = 0; p + q <= n; q++) { const x = M.leftRight(p, q, n - p - q); o.push({ ...x }); } return o; }]);
  C.push(['sl2Class, mat2, traceSeq, wordMatrix, SL2_GENS', () => { const W = [[], ['T'], ['S'], ['T', 'U'], ['T', 'T', 'U'], ['S', 'T'], ['T', 'Ui'], ['U', 'Ti', 'S', 'S'], ['T', 'U', 'T', 'U', 'Ti']]; return [M.SL2_GENS, W.map(w => { const X = M.wordMatrix(w); return [X, M.sl2Class(X), M.traceSeq(X), M.traceSeq(X, 3)]; }), M.mat2([[1, 2], [3, 4]], [[0, 1], [-1, 0]]), M.sl2Class([[2, 0], [0, 2]]), M.sl2Class([[1, 1], [0, 1]])]; }]);
  C.push(['halfTraceComb, pieceMatrix, halfTraceSteps (floating point)', () => { const o = []; for (const E of [-3, -0.5, 0, 1e-13, 0.7, 2, 9.5, 30]) o.push([M.halfTraceComb(E, 1.5, 1), M.halfTraceComb(E, -2, 0.7), M.pieceMatrix(E, 0.8, 0), M.pieceMatrix(E, 0.5, 5), M.pieceMatrix(E, 0.5, E), M.halfTraceSteps(E, M.G5_CELL)]); return o; }]);
  C.push(['bandEdges, G5_CELL', () => [M.G5_CELL, M.bandEdges(E => M.halfTraceComb(E, 1.5, 1), -2, 40, 400), M.bandEdges(E => M.halfTraceSteps(E, M.G5_CELL), -1, 30, 300)]]);
  C.push(['toMv, mvMul2, xSquare, combCell, floquetClass', () => { const o = []; for (const E of [-1, 0, 0.5, 3, 12]) o.push(M.combCell(E, 1.5, 1)); const A = M.toMv([[1, 2], [3, 4]]), B = M.toMv([[0, 1], [-1, 0]]); o.push([A, B, M.mvMul2(A, B), M.xSquare(A), [0.2, 0.999999999999, 1, 1.0000000001, -1.5, 3].map(h => [M.floquetClass(h), M.floquetClass(h, 1e-3)])]); return o; }]);
  C.push(['putParticle, takeParticle, byNumber, fockMatrices', () => { const o = []; for (let a = 0; a < 8; a++) for (let k = 0; k < 3; k++) o.push([M.putParticle(a, k), M.takeParticle(a, k)]); return [o, M.byNumber(), M.byNumber(5), M.fockMatrices(3), M.fockMatrices(2)]; }]);
  C.push(['DIRS, projector, passProb, probValue, magnets, zxCommute', () => [M.DIRS, M.DIRS.map(M.projector), M.DIRS.flatMap(u => M.DIRS.map(v => M.passProb(u, v))), ['1', '1/2', '0'].map(M.probValue), M.magnets(['z', 'x', 'z']), M.magnets(['z', 'x', '-z', 'y', '-y']), M.zxCommute()]]);
  C.push(['pauliTable', () => M.pauliTable()]);
  C.push(['seeded symbol determinants', () => { const r = prng(20); const o = []; for (let i = 0; i < 12; i++) { const n = 2 + (i % 3), S = Array.from({ length: n }, () => [1, -1][pint(r, 0, 1)]), mom = Array.from({ length: n }, () => pint(r, -3, 3)); o.push(M.symbolDet(S, mom, pint(r, 0, 3))); } return o; }]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'schullerEngine.js', dir: v15Dir('engines/stored/make_schullerEngine_v15.mjs'), files: { M: 'schullerEngine.js', L: 'labelsEngine.js' }, cases: CASES, outUrl: new URL('./schullerEngine_v15.json', import.meta.url) }));
}
