// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/productKernels_v15.json: the exports of v15 productKernels.js (the product benchmark of step 16, Cl(k,k)) on a fixed set of inputs —
// the sign of every pair of labels < 128, the dense product and the sign tables for n = 2..8, the matrix representation (n = 2..10, base N = 0 and the period-8
// blocks), the routes with and without buffers, the set-up, the timed variants' return values and productCheck n = 2..10 — recorded before the module was
// re-pointed onto engines/bitrule.js (T3.2). Integer inputs: every double is exact.
//   node engines/stored/make_productKernels_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir } from './fixture_codec.mjs';

export const CASES = ({ M }) => {
  const C = [];
  C.push(['productSign, labels < 128 (as a word over +, −)', () => { let s = ''; for (let a = 0; a < 128; a++) for (let b = 0; b < 128; b++) s += M.productSign(a, b) > 0 ? '+' : '-'; return s; }]);
  C.push(['productSign, large labels', () => [[0xFFFF, 0xFFFF], [0xAAAA, 0x5555], [12345, 54321], [0x8000, 0x7FFF], [65535, 1]].map(([a, b]) => M.productSign(a, b))]);
  C.push(['productInputs n = 2, 4, 6, 8 (seeds 1, 7 + n)', () => [2, 4, 6, 8].map(n => [M.productInputs(n), M.productInputs(n, 7 + n)])]);
  C.push(['productBitRule n = 2, 4, 6, 8', () => [2, 4, 6, 8].map(n => { const { x, y } = M.productInputs(n, 3); return M.productBitRule(x, y, n); })]);
  C.push(['productSignTable n = 2, 4, 6 (as words over +, −)', () => [2, 4, 6].map(n => Array.from(M.productSignTable(n), v => (v > 0 ? '+' : '-')).join(''))]);
  C.push(['productWithTable n = 2, 4, 6, with and without a buffer', () => [2, 4, 6].map(n => { const { x, y } = M.productInputs(n, 5), T = M.productSignTable(n), buf = new Float64Array(1 << n).fill(7); return [M.productWithTable(x, y, n, T), M.productWithTable(x, y, n, T, buf)]; })]);
  C.push(['productRep: slot, sg, rc, baseSign', () => [[2, 0], [4, 0], [6, 0], [4, 2], [6, 2], [10, 2], [8, 0]].map(([n, N]) => { const R = M.productRep(n, N); return [R.n, R.N, R.k, R.m, R.B, R.NB, R.size, R.slot, R.sg, R.rc, R.baseSign]; })]);
  C.push(['productRep errors', () => [[3, 0], [2, 2], [18, 0]].map(([n, N]) => { try { M.productRep(n, N); return 'no error'; } catch (e) { return e.message; } })]);
  C.push(['toMatrices, fromMatrices, matrixProduct, routes', () => [[2, 0], [4, 0], [6, 0], [10, 2], [6, 2]].map(([n, N]) => { const R = M.productRep(n, N), { x, y } = M.productInputs(n, 11), Mx = M.toMatrices(R, x), My = M.toMatrices(R, y), b = M.productRouteBuffers(R); return [Mx, M.fromMatrices(R, Mx), M.matrixProduct(R, Mx, My), M.productMatrixRoute(R, x, y), M.productMatrixRouteReuse(R, x, y, b), M.productMatrixRouteReuse(R, y, x, b), Object.keys(b), M.productRouteAllocs(R, 5), M.productRouteAllocs(R, 1234)]; })]);
  C.push(['PRODUCT_NS, productHasTable, productPeriodN, productCounts', () => [M.PRODUCT_NS, M.PRODUCT_NS.map(n => [M.productHasTable(n), M.productPeriodN(n), M.productCounts(n)])]]);
  C.push(['productSetup and productVariants n = 2, 4, 6, 8, 10', () => [2, 4, 6, 8, 10].map(n => { const ctx = M.productSetup(n), V = M.productVariants(ctx); return [ctx.n, ctx.x, ctx.y, ctx.table ? ctx.table.length : null, ctx.rep8 ? ctx.rep8.N : null, Object.keys(V), Object.entries(V).map(([k, f]) => [k, f(3)])]; })]);
  C.push(['productCheck n = 2, 4, 6, 8, 10', () => [2, 4, 6, 8, 10].map(M.productCheck)]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'productKernels.js', dir: v15Dir('engines/stored/make_productKernels_v15.mjs'), files: { M: 'productKernels.js' }, cases: CASES, outUrl: new URL('./productKernels_v15.json', import.meta.url) }));
}
