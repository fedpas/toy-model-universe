// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/baezEngine_v15.json: the exports of v15 baezEngine.js (BW1–BW7, step 19) on a fixed set of inputs — the 32 five-bit labels, the Fock
// operators, the 240 roots of E8 and their coefficients, the Kepler brackets for eps = +1, 0, −1, the Madelung order — recorded before the module was re-pointed
// onto engines/bitrule.js (T3.2). tests/engines.test.mjs imports CASES and runs the same inputs.
//   node engines/stored/make_baezEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir } from './fixture_codec.mjs';

export const CASES = ({ M }) => {
  const C = [];
  C.push(['fractions', () => { const xs = [M.fr(1, 2), M.fr(-2, 6), M.fr(3, -9), M.fr(0, 5), M.fr(7)]; return [xs, xs.flatMap(x => xs.map(y => [M.fadd(x, y), M.fsub(x, y), M.fmul(x, y), y.n ? M.fdiv(x, y) : null, M.feq(x, y)])), xs.map(x => [M.fneg(x), M.fsign(x), M.fstr(x)]), M.ZERO, M.ONE]; }]);
  C.push(['pc', () => [0, 1, 7, 31, 255, 1023, -1].map(M.pc)]);
  C.push(['labels: weak, colour, Y, Q, T3, Peirce, labelInfo', () => M.LABELS.map(x => [M.weakOf(x), M.colourOf(x), M.hyper(x), M.charge(x), M.isospin(x), M.peirce(x, 0), M.peirce(x, M.S_WEAK), M.flipAll(x), M.labelInfo(x)])]);
  C.push(['LABELS, EVEN, grading, family, PAPER_PIECES, S_WEAK', () => [M.LABELS, M.EVEN, M.grading(), M.family(false), M.family(true), M.PAPER_PIECES, M.S_WEAK]]);
  C.push(['classesOf, anomalySums, chargeSum', () => [false, true].map(f => { const xs = M.family(f); return [M.classesOf(xs), M.anomalySums(xs), M.chargeSum(xs)]; }).concat([[M.anomalySums(M.LABELS), M.chargeSum([1, 2, 3])]])]);
  C.push(['adNDegrees', () => M.adNDegrees()]);
  C.push(['E8: SIMPLE, ip, roots, cartan, inverse', () => { const R = M.e8Roots(); return [M.SIMPLE, R, M.cartan(), M.inverseExact(M.cartan()), M.ip(R[0], R[1]), M.ip(R[3], R[200])]; }]);
  C.push(['coefficients', () => { const Cf = M.coefficients(); return M.e8Roots().map(r => Cf.get(r)); }]);
  C.push(['levi, gradeOne, ladder, linkChain', () => [[8, 7, 6, 5, 4, 3].map(n => M.levi(n).length), [8, 7, 6, 5, 4].map(n => M.gradeOne(n)), M.ladder(), M.linkChain()]]);
  C.push(['shadows, Eisenstein', () => [M.shadows(), M.eisensteinRings(), M.eisensteinRings(4), M.eisensteinPoints(), M.eisensteinPoints(3)]]);
  C.push(['MOVES, moveSquare', () => [M.MOVES, [1, 0, -1].map(e => M.MOVES.map(m => M.moveSquare(m, e))), [1, 0, -1].map(e => Array.from({ length: 16 }, (_, m) => M.moveSquare(m, e)))]]);
  C.push(['charpoly, inertia', () => [[[2, -1], [-1, 2]], [[0, 1], [1, 0]], [[1, 0, 0], [0, -1, 0], [0, 0, 0]], [[2, 1, 0], [1, 2, 1], [0, 1, 2]]].map(Mx => [M.charpoly(Mx.map(r => r.map(v => M.fr(v)))), M.inertia(Mx)])]);
  C.push(['kepler eps = +1, 0, −1', () => [1, 0, -1].map(M.kepler)]);
  C.push(['epsOfEnergy, shells, shellsSpin', () => [[-2, -0.5, 0, 0.3, 4].map(M.epsOfEnergy), M.shells(), M.shells(3), M.shellsSpin(), M.shellsSpin(4)]]);
  C.push(['keplerOrbit (floating point)', () => [-0.5, -0.3, 0, 0.4].map(E => M.keplerOrbit(E, 60)).concat([M.keplerOrbit(-0.2)])]);
  C.push(['madelung, SUBSHELL, fillTo', () => [M.madelung(), [0, 1, 2, 3, 4, 5, 6].map(M.SUBSHELL), Array.from({ length: 118 }, (_, i) => M.fillTo(i + 1))]]);
  C.push(['PAPERS, CLUSTER, EDGES, edgeCounts', () => [M.PAPERS, M.CLUSTER, M.EDGES, M.edgeCounts()]]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'baezEngine.js', dir: v15Dir('engines/stored/make_baezEngine_v15.mjs'), files: { M: 'baezEngine.js', L: 'labelsEngine.js' }, cases: CASES, outUrl: new URL('./baezEngine_v15.json', import.meta.url) }));
}
