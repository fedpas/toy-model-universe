// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/labelsEngine_v15.json: every export of v15 labelsEngine.js on a fixed set of inputs (all sign vectors over {+1, −1, 0} with n <= 4 for the
// blade product, seeded float multivectors n <= 5, the cells n <= 10, …), recorded before the module became a re-export of engines/labels.js (T3.2).
// tests/engines.test.mjs imports CASES and runs the same inputs through the re-pointed module.
//   node engines/stored/make_labelsEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir, prng, pint, signVectors } from './fixture_codec.mjs';

const cells = N => { const o = []; for (let n = 0; n <= N; n++) for (let q = 0; q <= n; q++) o.push([n - q, q]); return o; };
export const CASES = ({ M }) => {
  const C = [];
  C.push(['popcount', () => [...Array(1100).keys(), 2 ** 20 - 1, 2 ** 30, 2 ** 31 - 1, -1, -2].map(M.popcount)]);
  C.push(['reorder a,b < 64', () => { const o = []; for (let a = 0; a < 64; a++) for (let b = 0; b < 64; b++) o.push(M.reorder(a, b)); return o; }]);
  C.push(['sigVec', () => [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 3, 0], [3, 1, 0], [2, 2, 1], [4, 4, 0], [0, 8, 2]].map(([p, q, r]) => M.sigVec(p, q, r))]);
  for (let m = 0; m <= 4; m++) C.push([`bladeMul n = ${m}, every sign vector, every pair`, () => signVectors(m).map(eps => { const o = []; for (let a = 0; a < 1 << m; a++) for (let b = 0; b < 1 << m; b++) o.push(...M.bladeMul(a, b, eps)); return o; })]);
  C.push(['mvZero', () => [0, 1, 2, 3, 4].map(M.mvZero)]);
  C.push(['mul: 80 seeded float multivectors, n = 1..5, squares +1/−1/0', () => { const r = prng(15); const o = []; for (let i = 0; i < 80; i++) { const m = 1 + (i % 5), sq = Array.from({ length: m }, () => [1, -1, 0][pint(r, 0, 2)]), x = M.mvZero(m), y = M.mvZero(m); for (let a = 0; a < 1 << m; a++) { x[a] = r() < 0.2 ? 0 : r() * 4 - 2; y[a] = r() < 0.2 ? 0 : r() * 4 - 2; } o.push(M.mul(x, y, sq)); } return o; }]);
  C.push(['mul: 40 seeded integer multivectors, n = 1..4', () => { const r = prng(16); const o = []; for (let i = 0; i < 40; i++) { const m = 1 + (i % 4), sq = Array.from({ length: m }, () => [1, -1, 0][pint(r, 0, 2)]), x = M.mvZero(m), y = M.mvZero(m); for (let a = 0; a < 1 << m; a++) { x[a] = pint(r, -4, 4); y[a] = pint(r, -4, 4); } o.push(M.mul(x, y, sq)); } return o; }]);
  C.push(['TYPES, FIELD_DIM', () => [M.TYPES, M.FIELD_DIM]]);
  C.push(['clockOf, typeOf, wedderburn, gaussSum, n <= 10', () => cells(10).map(([p, q]) => [M.clockOf(p, q), M.typeOf(p, q), M.wedderburn(p, q), M.gaussSum(p, q)])]);
  C.push(['clockOf negative and large', () => [[-3, 2], [9, 0], [0, 13], [100, 3]].map(([p, q]) => [M.clockOf(p, q), M.typeOf(p, q)])]);
  C.push(['embedCheck n <= 6', () => cells(6).map(([p, q]) => M.embedCheck(p, q))]);
  C.push(['bladeName', () => [0, 1, 2, 3, 5, 6, 7, 15, 255, 1023, 4095].map(m => [M.bladeName(m), M.bladeName(m, 1)])]);
  C.push(['traceless, trinityClass, matrixOf, squareByBitRule on [-3,3]^3', () => { const o = []; for (let a = -3; a <= 3; a++) for (let b = -3; b <= 3; b++) for (let c = -3; c <= 3; c++) o.push([M.traceless(a, b, c), M.trinityClass(M.traceless(a, b, c)), M.matrixOf(a, b, c), M.squareByBitRule(a, b, c)]); return o; }]);
  C.push(['trinityClass with eps', () => [[-1e-10, 1e-9], [2e-9, 1e-9], [-0.5, 0.6], [0.5, 0.4]].map(([s, e]) => M.trinityClass(s, e))]);
  C.push(['expTX and apply', () => { const o = []; for (const [a, b, c] of [[0, 0.5, 0.5], [0, 0, 1], [0, 1, 0], [0.3, -0.7, 0.2], [1, 0.4, 0.1], [0, 0, 0], [0.2, 0.2, 0.2 * Math.SQRT2]]) for (const t of [0, 0.37, 1.1, -2.5]) { const E = M.expTX(a, b, c, t); o.push([E, M.apply(E, [1.5, -0.25])]); } return o; }]);
  C.push(['springX', () => [1, 0, -1, 0.7, 4, -2.5].map(M.springX)]);
  C.push(['gridCounts', () => [1, 2, 3, 6].map(M.gridCounts)]);
  C.push(['BIV_MASKS, BIV_NAMES, SIGS4', () => [M.BIV_MASKS, M.BIV_NAMES, M.SIGS4]]);
  C.push(['bivector4: presets and 250 seeded integer bivectors', () => { const r = prng(4); const o = []; for (const [p, q] of M.SIGS4) { o.push(M.bivector4(p, q, [1, 0, 0, 0, 0, 1]), M.bivector4(p, q, [1, 1, 0, 0, 1, 0]), M.bivector4(p, q, [1, 0, 0, 0, -1, 0]), M.bivector4(p, q, [0, 0, 0, 0, 0, 0])); for (let i = 0; i < 50; i++) o.push(M.bivector4(p, q, Array.from({ length: 6 }, () => pint(r, -3, 3)))); } return o; }]);
  C.push(['bivector4: 50 seeded float bivectors', () => { const r = prng(5); const o = []; for (let i = 0; i < 50; i++) { const [p, q] = M.SIGS4[i % 5]; o.push(M.bivector4(p, q, Array.from({ length: 6 }, () => r() * 2 - 1))); } return o; }]);
  C.push(['lcg', () => [1, 7, 12345, 2026].map(s => { const g = M.lcg(s); return Array.from({ length: 8 }, g); })]);
  C.push(['sampleBivectors', () => M.SIGS4.map(([p, q]) => [M.sampleBivectors(p, q, 400), M.sampleBivectors(p, q, 50, 99)])]);
  C.push(['pgG, pgSquare, pgSquareByBitRule, pgClass, pgRays', () => [0, 0.6, 1, 5 / 3, 3, -2, 0.25].map(g => [M.pgSquare(g), M.pgSquareByBitRule(g), M.pgClass(g), M.pgRays(g), M.pgRays(g, -1)]).concat([[0.5, 1, 2, 3, 10].map(r => [M.pgG(r), M.pgG(r, 0.3)])])]);
  C.push(['curvature', () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(M.curvature)]);
  C.push(['RAILS, factorial', () => [M.RAILS, [0, 1, 2, 5, 9, 12].map(M.factorial)]]);
  C.push(['golay: hist, octads, octadThrough', () => { const G = M.golay(); return [G.hist, G.octads.length, G.octads.slice(0, 12), Array.from(G.words.slice(0, 64)), [0b11111, 0b1011100000000000000001, (1 << 23) | 0b1111].map(m => M.octadThrough(G.octads, m))]; }]);
  C.push(['ordTwo, factorize, newPrimes, MONSTER_PRIMES', () => [[3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 41, 47, 59, 71].map(M.ordTwo), [1, 2, 12, 97, 360, 1023, 65535, 2 ** 20 - 1].map(M.factorize), Array.from({ length: 23 }, (_, i) => M.newPrimes(i + 2)), M.MONSTER_PRIMES]]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'labelsEngine.js', dir: v15Dir('engines/stored/make_labelsEngine_v15.mjs'), files: { M: 'labelsEngine.js' }, cases: CASES, outUrl: new URL('./labelsEngine_v15.json', import.meta.url) }));
}
