// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/labels_v15.json: the type table of v15 genesis_audit_v3.cliffordCell for the 45 cells n <= 8 and the cells of the 25 cards
// (AUDITED_ATLAS: id, p, q), so that tests/engines.test.mjs can compare engines/labels.js with them when the author's package is not on the machine.
//   node engines/stored/make_labels_v15.mjs [path to the v15 package]   (or set $ATLAS_V15)
import fs from 'node:fs'; import path from 'node:path'; import { pathToFileURL } from 'node:url';
const root = process.argv[2] || process.env.ATLAS_V15; if (!root) { console.error('usage: make_labels_v15.mjs <path to the v15 package>  (or set ATLAS_V15)'); process.exit(2); }
const G = await import(pathToFileURL(path.join(root, 'genesis_audit_v3.js')).href);
const cells = {};
for (let n = 0; n <= 8; n++) for (let q = 0; q <= n; q++) { const p = n - q, c = G.cliffordCell(p, q); cells[`${p},${q}`] = { s: c.s, kind: c.kind, N: c.N, dim: c.dim, algebra: c.algebra }; }
const out = { source: 'genesis_audit_v3.js (v15): cliffordCell(p, q) for n <= 8, AUDITED_ATLAS [id, p, q]', cells, cards: G.AUDITED_ATLAS.map(([id, , , p, q]) => [id, p, q]) };
fs.writeFileSync(new URL('./labels_v15.json', import.meta.url), JSON.stringify(out, null, 1) + '\n');
console.log(`labels_v15.json: ${Object.keys(cells).length} cells, ${out.cards.length} cards`);
