// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// Writes engines/stored/categoryEngine_v15.json: the exports of v15 categoryEngine.js (the engine of CW1–CW6, step 18) on a fixed set of inputs — every choice of
// squares over {+1, −1, 0} with n <= 4 for the label card, the Frobenius pairing and halving, n <= 3 for the faces, the E_n ladder n = 3..14, the signed cube —
// recorded before the module was re-pointed onto engines/bitrule.js (T3.2). tests/engines.test.mjs imports CASES and runs the same inputs.
//   node engines/stored/make_categoryEngine_v15.mjs <folder of the v15 package>
import { pathToFileURL } from 'node:url';
import { makeFixture, v15Dir, prng, pint, signVectors } from './fixture_codec.mjs';

const upTo = N => { const o = []; for (let m = 0; m <= N; m++) o.push(...signVectors(m)); return o; };
export const CASES = ({ M }) => {
  const C = [];
  C.push(['pc, binom, labelName, bits', () => [[0, 1, 5, 255, 1023, -1].map(M.pc), [[5, 2], [8, 4], [3, 5], [10, 0], [12, 7]].map(([n, k]) => M.binom(n, k)), [0, 1, 6, 13, 31].map(m => [M.labelName(m, 5), M.bits(m, 5)])]]);
  C.push(['sigOf, pqrOf, nullMask, triples, clockPlace', () => [[[3, 0, 1], [1, 3, 0], [0, 0, 2], [2, 2, 2]].map(([p, q, r]) => { const e = M.sigOf(p, q, r); return [e, M.pqrOf(e), M.nullMask(e), M.clockPlace(e)]; }), [0, 1, 2, 3, 4].map(M.triples)]]);
  C.push(['rankQ, bareiss, inertia', () => [M.rankQ([[[0, 1], [2, 3]], [[0, 2], [2, 6]], [[1, 5]], [[0, 1n], [1, -1n]]]), [[[2, -1], [-1, 2]], [[0, 1], [1, 0]], [[1, 2, 3], [4, 5, 6], [7, 8, 10]], [[2, -1, 0, 0], [-1, 2, -1, 0], [0, -1, 2, -1], [0, 0, -1, 2]]].map(m => [M.bareiss(m), M.inertia(m)]), M.bareiss([])]]);
  C.push(['labelCard, every eps n <= 4', () => upTo(4).map(e => M.labelCard(e))]);
  C.push(['powers', () => [[[1, 0], [1, 2, 3]], [[0, 0, 1], [1, 2, 3, 5, 7]], [[0, 0, 0], [1, 2, 4, 3, 5, 6, 7]]].map(([e, rad]) => M.powers(e, rad).map(s => [...s]))]);
  C.push(['trayProduct, trayAllZero', () => { const r = prng(18); const o = []; for (const e of [[1, 1, 0], [1, -1, 0, 0], [0, 0, 0], [3, 0].map(() => 0).concat([1])]) { for (let t = 0; t < 12; t++) { const k = pint(r, 1, 4), L = Array.from({ length: k }, () => pint(r, 0, (1 << e.length) - 1)); o.push([L, M.trayProduct(L, e)]); } o.push(M.trayAllZero(e, 2), M.trayAllZero(e, 3, 50)); } return o; }]);
  C.push(['frobenius, every eps n <= 4', () => upTo(4).map(e => M.frobenius(e))]);
  C.push(['join, pairs of eps with n1 + n2 <= 4', () => { const o = []; for (const e1 of upTo(2)) for (const e2 of upTo(2)) o.push(M.join(e1, e2)); return o; }]);
  C.push(['halveVia and halve, every eps n <= 4', () => upTo(4).map(e => [M.halve(e), e.length ? M.halve(e, e.length - 1) : null, ...e.map((x, t) => (x !== 0 ? M.halveVia(e, t) : null))])]);
  C.push(['lamEven', () => [0, 1, 2, 3, 4, 5].map(M.lamEven)]);
  C.push(['restrict, every eps n <= 3 and every face', () => upTo(3).map(e => Array.from({ length: 1 << e.length }, (_, T) => M.restrict(e, T)))]);
  C.push(['restrictSurvey', () => [M.restrictSurvey(2), M.restrictSurvey(3)]]);
  C.push(['complementReverses', () => [0, 1, 2, 3, 4, 5].map(M.complementReverses)]);
  C.push(['enGraph, cartanOf, nullRoot', () => [3, 4, 5, 8, 9, 10].map(n => { const g = M.enGraph(n), Cm = M.cartanOf(g.nodes, g.edges); return [g, Cm, M.nullRoot(Cm), M.cartanOf(g.nodes, g.edges, [0, 2, 3])]; })]);
  C.push(['mod2Counts, clCounts', () => [3, 4, 5, 6, 7, 8, 9, 10, 12].map(n => [M.mod2Counts(n), M.clCounts(n)])]);
  C.push(['ladderRung n = 3..14', () => Array.from({ length: 12 }, (_, i) => M.ladderRung(i + 3))]);
  C.push(['e9mod2', () => M.e9mod2()]);
  C.push(['asObj, mixSquare, pairedZero, loneZero', () => [M.asObj(new Map([[3, 1], [0, 2], [1, -1]])), [[1, 0], [0, 1], [2, 3], [3, 2], [-1.5, 0.5]].map(([a, b]) => M.mixSquare(a, b)), M.pairedZero(), [[1, 0], [1, -1, 0], [-1, 1, 1, 0], [0, 0]].map(M.loneZero)]]);
  C.push(['STORED_SCRIPT', () => M.STORED_SCRIPT]);
  C.push(['cubeEdges, jwSign, cubeSquares, ruleSigns, squaresOdd', () => [M.cubeEdges(), M.cubeEdges(2), M.cubeSquares(), M.ruleSigns(), M.squaresOdd(M.ruleSigns()), (() => { const o = []; for (let a = 0; a < 16; a++) for (let i = 0; i < 4; i++) o.push(M.jwSign(a, i)); return o; })()]]);
  C.push(['gaugeOf, flipCorner, edgeKey', () => { const R = M.ruleSigns(), o = [M.gaugeOf(R)]; for (let c = 0; c < 8; c++) { const F = M.flipCorner(R, c); o.push([F, M.gaugeOf(F), M.squaresOdd(F)]); } const plus = Object.fromEntries(M.cubeEdges().map(([a, i]) => [M.edgeKey(a, i), 1])); o.push(M.gaugeOf(plus), M.squaresOdd(plus), M.edgeKey(5, 1)); return o; }]);
  C.push(['countAnticommuting', () => [M.countAnticommuting(), M.countAnticommuting(2)]]);
  C.push(['bladeMulSign', () => { const o = []; for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) o.push(M.bladeMulSign(a, b), M.bladeMulSign(a, b, 4)); return o; }]);
  return C;
};

if (import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(await makeFixture({ name: 'categoryEngine.js', dir: v15Dir('engines/stored/make_categoryEngine_v15.mjs'), files: { M: 'categoryEngine.js', L: 'labelsEngine.js' }, cases: CASES, outUrl: new URL('./categoryEngine_v15.json', import.meta.url) }));
}
