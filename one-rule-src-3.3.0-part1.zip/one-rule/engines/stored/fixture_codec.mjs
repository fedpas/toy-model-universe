// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/stored/fixture_codec.mjs — what the v15 fixtures of task T3.2 share: the generators (make_<module>_v15.mjs) record the outputs of a v15 engine on a
// fixed set of inputs before the engine is re-pointed onto engines/bitrule.js, and tests/engines.test.mjs runs the same inputs through the re-pointed engine.
// encode() writes a value as JSON without losing a bit: −0, NaN and ±Infinity as {"$n": "-0"} …, BigInt as {"$big": "…"}, Map / Set / typed arrays with their
// order and type, functions as {"$fn": name} (never compared by value). compare() walks the stored and the live value together and counts, leaf by leaf:
// exact (Object.is, i.e. to the last bit), signedZero (stored −0, live +0 or the reverse: the same number, another sign bit), close (floating, within 1e-12
// relative), and failures. A fixture holds for a case when it has no failure.

const isTyped = x => ArrayBuffer.isView(x) && !(x instanceof DataView);

export function encode(x) {
  if (typeof x === 'number') {
    if (Object.is(x, -0)) return { $n: '-0' };
    if (Number.isNaN(x)) return { $n: 'NaN' };
    if (x === Infinity) return { $n: 'Infinity' };
    if (x === -Infinity) return { $n: '-Infinity' };
    return x;
  }
  if (typeof x === 'bigint') return { $big: String(x) };
  if (x === undefined) return { $undef: 1 };
  if (x === null || typeof x === 'string' || typeof x === 'boolean') return x;
  if (typeof x === 'function') return { $fn: x.name || 'anonymous' };
  if (Array.isArray(x)) return x.map(encode);
  if (isTyped(x)) return { $ta: x.constructor.name, v: Array.from(x, encode) };
  if (x instanceof Map) return { $map: [...x].map(([k, v]) => [encode(k), encode(v)]) };
  if (x instanceof Set) return { $set: [...x].map(encode) };
  const keys = Object.keys(x);
  if (keys.some(k => k.startsWith('$'))) return { $obj: keys.map(k => [k, encode(x[k])]) };
  const o = {}; for (const k of keys) o[k] = encode(x[k]); return o;
}

const NUM = { '-0': -0, NaN: NaN, Infinity: Infinity, '-Infinity': -Infinity };
const TAGS = ['$n', '$big', '$undef', '$fn', '$ta', '$map', '$set', '$obj'];
const kindOf = s => { if (!s || typeof s !== 'object' || Array.isArray(s)) return null; const ks = Object.keys(s); return TAGS.find(k => ks.includes(k)) || null; };

/** compare a live value with its stored encoding; returns { leaves, exact, signedZero, close, fails: [{ path, stored, live }] } */
export function compare(live, stored, path = '', acc = { leaves: 0, exact: 0, signedZero: 0, close: 0, fails: [] }) {
  const fail = why => { if (acc.fails.length < 12) acc.fails.push({ path: path || '(root)', why, stored: JSON.stringify(stored).slice(0, 120), live: (() => { try { return JSON.stringify(encode(live)).slice(0, 120); } catch (e) { return String(live).slice(0, 120); } })() }); };
  const kind = kindOf(stored);
  // numbers (plain, or the four special values)
  if (typeof stored === 'number' || kind === '$n') {
    acc.leaves++;
    const s = typeof stored === 'number' ? stored : NUM[stored.$n];
    if (typeof live !== 'number') { fail('not a number'); return acc; }
    if (Object.is(live, s)) { acc.exact++; return acc; }
    if (live === 0 && s === 0) { acc.signedZero++; return acc; }
    if (Number.isFinite(live) && Number.isFinite(s) && Math.abs(live - s) <= 1e-12 * Math.max(1, Math.abs(live), Math.abs(s))) { acc.close++; return acc; }
    fail('number differs'); return acc;
  }
  if (kind === '$big') { acc.leaves++; if (typeof live === 'bigint' && String(live) === stored.$big) acc.exact++; else fail('bigint differs'); return acc; }
  if (kind === '$undef') { acc.leaves++; if (live === undefined) acc.exact++; else fail('not undefined'); return acc; }
  if (kind === '$fn') { acc.leaves++; if (typeof live === 'function') acc.exact++; else fail('not a function'); return acc; }
  if (stored === null || typeof stored === 'string' || typeof stored === 'boolean') { acc.leaves++; if (live === stored) acc.exact++; else fail('value differs'); return acc; }
  if (Array.isArray(stored)) {
    if (!Array.isArray(live)) { fail('not an array'); return acc; }
    if (live.length !== stored.length) { fail(`length ${live.length} ≠ ${stored.length}`); return acc; }
    stored.forEach((s, i) => compare(live[i], s, `${path}[${i}]`, acc)); return acc;
  }
  if (kind === '$ta') {
    if (!isTyped(live) || live.constructor.name !== stored.$ta) { fail(`not a ${stored.$ta}`); return acc; }
    if (live.length !== stored.v.length) { fail(`length ${live.length} ≠ ${stored.v.length}`); return acc; }
    stored.v.forEach((s, i) => compare(live[i], s, `${path}[${i}]`, acc)); return acc;
  }
  if (kind === '$map') {
    if (!(live instanceof Map)) { fail('not a Map'); return acc; }
    const L = [...live]; if (L.length !== stored.$map.length) { fail(`size ${L.length} ≠ ${stored.$map.length}`); return acc; }
    stored.$map.forEach(([k, v], i) => { compare(L[i][0], k, `${path}<key ${i}>`, acc); compare(L[i][1], v, `${path}<${JSON.stringify(k)}>`, acc); }); return acc;
  }
  if (kind === '$set') {
    if (!(live instanceof Set)) { fail('not a Set'); return acc; }
    const L = [...live]; if (L.length !== stored.$set.length) { fail(`size ${L.length} ≠ ${stored.$set.length}`); return acc; }
    stored.$set.forEach((s, i) => compare(L[i], s, `${path}{${i}}`, acc)); return acc;
  }
  const entries = kind === '$obj' ? stored.$obj : Object.entries(stored);
  if (!live || typeof live !== 'object' || Array.isArray(live) || live instanceof Map || isTyped(live)) { fail('not an object'); return acc; }
  const lk = Object.keys(live).sort().join(','), sk = entries.map(([k]) => k).sort().join(',');
  if (lk !== sk) { fail(`keys {${lk}} ≠ {${sk}}`); return acc; }
  for (const [k, v] of entries) compare(live[k], v, path ? `${path}.${k}` : k, acc);
  return acc;
}

/** a small deterministic generator for the inputs of the fixtures (xorshift32), independent of every engine */
export function prng(seed) { let s = (seed >>> 0) || 0x9e3779b9; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; }
export const pint = (r, a, b) => a + Math.floor(r() * (b - a + 1));
/** every sign vector over {+1, −1, 0} of length m (base-3 digits, generator 0 first) */
export const signVectors = m => Array.from({ length: 3 ** m }, (_, t) => Array.from({ length: m }, (_, i) => [1, -1, 0][Math.floor(t / 3 ** i) % 3]));

/** run a generator: import the v15 module from `dir`, run its cases, write engines/stored/<name>_v15.json. Returns the summary line. */
export async function makeFixture({ name, dir, files, cases, outUrl }) {
  const fs = await import('node:fs'), path = await import('node:path'), crypto = await import('node:crypto'), { pathToFileURL } = await import('node:url');
  const mods = {}; for (const [key, file] of Object.entries(files)) mods[key] = await import(pathToFileURL(path.join(dir, file)).href);
  const sha256 = Object.fromEntries(Object.values(files).map(f => [f, crypto.createHash('sha256').update(fs.readFileSync(path.join(dir, f))).digest('hex')]));
  let negZeros = 0; const countNeg = v => { if (Object.is(v, -0)) negZeros++; else if (v && typeof v === 'object') for (const w of (v instanceof Map ? [...v].flat() : ArrayBuffer.isView(v) ? Array.from(v) : Object.values(v))) countNeg(w); };
  const list = cases(mods), out = [];
  for (const [id, f] of list) { const v = f(); countNeg(v); out.push({ id, out: encode(v) }); }
  const doc = { module: name, source: 'the v15 package, before the module was re-pointed onto engines/bitrule.js (task T3.2)', sha256, negativeZeros: negZeros, cases: out };
  const text = JSON.stringify(doc) + '\n';
  fs.writeFileSync(outUrl, text);
  return `${path.basename(outUrl.pathname)}: ${out.length} cases, ${(text.length / 1024).toFixed(1)} KB, ${negZeros} negative zeros in the v15 outputs`;
}

/** the command-line part of every generator: the folder of the v15 package from argv[2] or $ATLAS_V15 */
export function v15Dir(script) {
  const dir = process.argv[2] || process.env.ATLAS_V15;
  if (!dir) { console.error(`usage: node ${script} <folder of the v15 package>   (or set ATLAS_V15)`); process.exit(2); }
  return dir;
}
