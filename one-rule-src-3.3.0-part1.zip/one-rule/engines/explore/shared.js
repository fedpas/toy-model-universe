// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/shared.js — the pure helpers the Explore leaves share (port of Octavo's octavo/shared.js; no React): the letters and plain names of the three
// kinds of number, the table that a Clifford box is, the position of an hour on the clock, the small formatters. Every number comes from engines/labels.js (the
// v15 API on the one kernel engines/bitrule.js). Not carried over (docs/EXPLORE_PORT.md): tableAlt (a sentence for a screen reader) and the hex colour of the fade
// mask of tableLayout, which now says only whether the table fades (`fade`).
import { wedderburn } from '../labels.js';

// type of a box -> [letter, plain name]; the kinds are told apart by a letter, never by colour
export const KIND = { R: ['ℝ', 'ordinary numbers'], R2: ['ℝ', 'ordinary numbers'], C: ['ℂ', 'turning numbers'], H: ['ℍ', 'spinning numbers'], H2: ['ℍ', 'spinning numbers'] };
export const DOUBLED = t => t === 'R2' || t === 'H2';
// a pair of tables is named as a pair
const PAIR = { R2: 'pairs of ordinary numbers', H2: 'pairs of spinning numbers' };
export const kindLine = t => (PAIR[t] || KIND[t][1]) + ' (' + KIND[t][0] + ')';
// a doubled box (two tables side by side) wears a double ring; the two colours are passed in (design tokens), none is written here
export const ringShadow = (t, gap, ring) => (DOUBLED(t) ? '0 0 0 3px ' + gap + ', 0 0 0 5px ' + ring : 'none');
export const fmt = k => (k >= 10000 ? k.toExponential(1).replace('e+', ' × 10^') : String(k));
const SUB = '₀₁₂₃₄₅₆₇₈₉';
export const sub = n => String(n).split('').map(d => SUB[+d]).join('');
// the algebra of a box in letters: M₂(ℂ), ℍ ⊕ ℍ, M₄(ℝ) ...
export const algebra = w => { const L = KIND[w.type][0], one = w.k === 1 ? L : 'M' + sub(w.k) + '(' + L + ')'; return w.copies === 2 ? one + ' ⊕ ' + one : one; };
// the smallest box at an hour: the (plus, minus) with the fewest switches
export const smallest = h => (h <= 4 ? [h, 0] : [0, 8 - h]);
// the position of hour h on a dial of radius r (percent of the dial), hour 0 to the right, counting anticlockwise
export const hourPos = (h, r = 35) => { const a = h * Math.PI / 4; return { left: 50 + r * Math.cos(a), top: 50 - r * Math.sin(a) }; };
// the box drawn as k x k cells (at most 6 x 6 drawn, faded when the table is bigger: `fade`), once or twice; sizes in container-query units
export function tableLayout(w) {
  const k = w.k, n = k <= 4 ? k : 6, copies = w.copies, letter = KIND[w.type][0];
  const gap1 = 1.3, cellMax = copies === 2 ? 17 : 21, room = copies === 2 ? 37 : 80;
  const total = Math.min(room, n * cellMax + gap1 * (n - 1)), side = (total - gap1 * (n - 1)) / n;
  const fs = side >= 8.7 ? Math.round(side * 4.4) / 10 : 0;
  const grids = [];
  for (let g = 0; g < copies; g++) grids.push({ n, w: total, fs, plus: copies === 2 && g === 0, fade: k > 4, cells: Array.from({ length: n * n }, () => (fs ? letter : '')) });
  return grids;
}
// the shortest way round the clock from hour a to hour b, in steps of 45 degrees (-4 .. 3)
export const hourStep = (a, b) => ((((b - a + 4) % 8) + 8) % 8) - 4;
export const box = (p, q) => wedderburn(p, q);
// a number with a true minus sign and a fixed number of decimals
export const num = (x, d = 1) => (x < -1e-9 ? '−' : '') + Math.abs(x).toFixed(d);
// the track of a stepped control coloured by the sign it decides: left colour up to the zero, a thin band of the middle colour at zero, right colour after it
// (zeroPct: where zero sits on the track, in percent; the three colours are passed in as design tokens)
export const track = (left, mid, right, zeroPct = 50) => { const a = (zeroPct - 1.5).toFixed(1), b = (zeroPct + 1.5).toFixed(1); return 'linear-gradient(90deg, ' + left + ' 0, ' + left + ' ' + a + '%, ' + mid + ' ' + a + '%, ' + mid + ' ' + b + '%, ' + right + ' ' + b + '%, ' + right + ' 100%)'; };
