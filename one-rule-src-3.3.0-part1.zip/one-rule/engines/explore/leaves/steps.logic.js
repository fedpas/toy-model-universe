// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/steps.logic.js — shelf leaf "steps", under leaf 6 (port of Octavo's octavo/leaves/steps.logic.js; plain functions, no React). Every
// product and sign comes from engines/labels.js (bladeMul, sigVec, maxwellViews: the kernel's); the names from engines/explore/names.js; tests/explore/
// leaves.steps.test.mjs recomputes every number by standard routes and holds them bit-identical to the Octavo output.
// The field F of ∇F = J in Cl(1,3) lives on the six edges of a tetrahedron whose corners are the directions t, x, y, z (the axes of maxwellViews(1, 3)). A step
// multiplies a piece of F by one direction e_a: it drops a direction the piece holds and lands on a corner (grade 1), or adds one it lacks and lands on a
// triangle (grade 3). The same step is drawn three ways (the tetrahedron, the 4-cube of labels where one bit flips, the labels 0 to 15 where it is an XOR with
// 2^a) and read under three names (names.js: bits, numbers, primes; under primes a drop divides by the prime of its direction and an add multiplies). Two steps
// of one kind reach one end by two roads of opposite sign. Back: the mathematician's four ways in (geometry, algebra, topology, category) and the physicist's
// line of charge in one space direction (ρ = ∂ₓE, J = −∂ₜE).
// Not carried over (docs/EXPLORE_PORT.md §3): COPY, keyLine, status, CHIP_TEXT, ZERO_TABLE, PHYS_TEXT; the sentences of front (status, key, tetraAlt, cubeAlt,
// gridAlt), geometry (line, counter, alt), algebra (line), topology (line, alt), category (counter, alt) and phys (charge, ends, change, alt). Their facts are
// returned as data: keyOf, termOf, eqOf, front (term, eq), geometry (pieces, per, cancel), algebra (formula), category (good, flips), phys (balance, qText),
// ZERO_D1D2. The formula readouts ruleLine and roadsRule keep their numbers; their few words became symbols (AND, ∤, gcd). The stored data of maxwell.json
// that the kernel does not give (the textbook sign of each piece of F, the names of the eight equations) is copied below and compared with
// checks/selfcheck/maxwell.json cells["1,3"] by the test.
import { bladeMul, popcount, sigVec, maxwellViews } from '../../labels.js';
import { bitsOf, combineNames, isEven, nameOf, primeName, primeOf, stepName } from '../names.js';
import { num } from '../shared.js';

// ---- the algebra of the Maxwell page: four directions, switch a is bit a of a label
const VIEWS = maxwellViews(1, 3);
export const AXES = VIEWS.axes;                                       // t x y z
export const SQ = sigVec(1, 3);                                       // t squares to +1, x, y, z to −1
export const ALL = (1 << AXES.length) - 1;                            // 15: every direction, the whole tetrahedron
const IDX = AXES.map((_, a) => a);
const bit = c => 1 << AXES.indexOf(c);
export const holds = (v, a) => (v >> a & 1) === 1;
export const flip = (v, a) => v ^ (1 << a);                           // the label with switch a flipped
// the letters of a label ('t x'), '1' for the empty one
export const letters = v => (v === 0 ? '1' : AXES.filter((_, a) => holds(v, a)).join(' '));
export const word = v => (v === 0 ? '1' : AXES.filter((_, a) => holds(v, a)).join(''));
// the sign each piece carries in F, as the Atlas writes it (F = Ex e_tx + Ey e_ty + Ez e_tz − Bx e_yz + By e_xz − Bz e_xy): maxwell.json cells["1,3"].conventions
export const FIELD_ORDER = ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z'];
export const FIELD_SIGNS = [1, 1, 1, -1, 1, -1];
const SIGN_IN_F = Object.fromEntries(FIELD_ORDER.map((f, i) => [f, FIELD_SIGNS[i]]));
// the six pieces: E along a space direction sits on the edge from t to it, B along a space direction on the edge of the two others; the move by the square of the plane
export const PIECES = [['E', 'x'], ['E', 'y'], ['E', 'z'], ['B', 'x'], ['B', 'y'], ['B', 'z']].map(([kind, c]) => {
  const mask = kind === 'E' ? bit('t') | bit(c) : ['x', 'y', 'z'].filter(o => o !== c).reduce((m, o) => m | bit(o), 0);
  const square = bladeMul(mask, mask, SQ)[1];
  return { id: kind + '_' + c, kind, axis: c, mask, sign: SIGN_IN_F[kind + '_' + c], square, move: square > 0 ? 'boost' : 'turn' };
});
export const pieceOfMask = m => PIECES.findIndex(p => p.mask === m);

// one step from any label v along direction a: e_a e_v = sign · e_(v with a flipped); a drop when v holds a, an add when it does not
export function stepOf(v, a) { const [to, sign] = bladeMul(1 << a, v, SQ); return { from: v, a, to, sign, op: holds(v, a) ? 'drop' : 'add' }; }
// the front's choice: piece pi, direction a, 'drop' or 'add'. It is a step when the piece holds a (drop) or lacks it (add); otherwise it gives nothing.
export function choice(pi, a, op) {
  const P = PIECES[pi], ok = op === 'drop' ? holds(P.mask, a) : !holds(P.mask, a);
  if (!ok) return { pi, a, op, ok, from: P.mask, to: null, sign: 0, kind: null, atlasOp: null };
  const s = stepOf(P.mask, a);
  return { pi, a, op, ok, from: P.mask, to: s.to, sign: P.sign * s.sign, kind: s.op === 'drop' ? 'corner' : 'triangle', atlasOp: s.op === 'drop' ? 'contract' : 'wedge' };
}
export const CHOICES = PIECES.flatMap((_, pi) => IDX.flatMap(a => ['drop', 'add'].map(op => choice(pi, a, op))));
export const STEPS = CHOICES.filter(c => c.ok);
// the second step of the same kind from piece pi: two roads, through each of its two corners (drops) or its two triangles (adds); the + road first
export function roads(pi, op) {
  const P = PIECES[pi], dirs = IDX.filter(a => holds(P.mask, a) === (op === 'drop'));
  const road = (a, b) => { const s1 = stepOf(P.mask, a), s2 = stepOf(s1.to, b); return { first: a, second: b, mid: s1.to, end: s2.to, sign: P.sign * s1.sign * s2.sign }; };
  const list = [road(dirs[0], dirs[1]), road(dirs[1], dirs[0])].sort((u, v) => v.sign - u.sign);
  return { pi, op, list, end: list[0].end, total: list[0].sign + list[1].sign };
}
export const sgn = s => (s > 0 ? '+' : '−') + Math.abs(s);
// the term of ∇F = J a step is (the sign, the derivative and the piece, as maxwell.json writes it: "+∂xEx"), and the equation it belongs to, named by the
// label it lands on: a corner t is Gauss, a corner x, y or z an Ampère row, a triangle with t a Faraday row (named by the space direction it lacks), the
// triangle x y z no monopole (maxwell.json cells["1,3"].equations: id, name, target)
export function termOf(c) { return c.ok ? (c.sign > 0 ? '+' : '−') + '∂' + AXES[c.a] + PIECES[c.pi].kind + PIECES[c.pi].axis : null; }
export function eqOf(v) {
  const g = popcount(v), t = holds(v, 0), space = AXES.slice(1);
  if (g === 1) return t ? { id: 'gauss', name: 'Gauss' } : { id: 'amp_' + letters(v), name: 'Ampère ' + letters(v) };
  if (g === 3) { if (!t) return { id: 'divB', name: 'no monopole' }; const lack = space.find(c => !holds(v, AXES.indexOf(c))); return { id: 'far_' + lack, name: 'Faraday ' + lack }; }
  return null;
}

// ---- the names (names.js): the same label as bits, a number, or a product of primes
export const MODES = ['bits', 'numbers', 'primes'];
export const labelName = (v, mode) => nameOf(v, mode, AXES.length);
export const PRIMES = IDX.map(a => primeOf(a));                       // t x y z -> 2 3 5 7
export const inEvenHalf = v => isEven(v);                            // an even number of switches on: the corners of the half-cube
export const EVEN = Array.from({ length: ALL + 1 }, (_, v) => v).filter(inEvenHalf);
// the key of a naming: the name of each direction alone (bits: its place in the bits name; numbers: 2^a; primes: the a-th prime)
export const keyOf = mode => AXES.map((c, a) => ({ axis: c, name: labelName(1 << a, mode) }));
export const keyText = mode => keyOf(mode).map(k => k.axis + ' = ' + k.name).join(' · ');
const gcd = (a, b) => (b ? gcd(b, a % b) : a);
// the rule under the pictures for one step, in the chosen names; a choice that gives nothing shows why (the bit is off, or already on; the prime does not
// divide the name, or already does)
export function ruleLine(c, mode) {
  const from = c.from, a = c.a, p = PRIMES[a], n = primeName(from);
  if (c.ok) {
    if (mode === 'bits') return bitsOf(from, AXES.length) + ' → ' + bitsOf(flip(from, a), AXES.length);
    if (mode === 'numbers') return from + ' XOR ' + (1 << a) + ' = ' + flip(from, a);
    return n + (c.op === 'drop' ? ' ÷ ' : ' × ') + p + ' = ' + stepName(n, a, c.op);
  }
  if (mode === 'bits') return bitsOf(from, AXES.length) + ' AND ' + bitsOf(1 << a, AXES.length) + ' = ' + bitsOf(from & (1 << a), AXES.length);
  if (mode === 'numbers') return from + ' AND ' + (1 << a) + ' = ' + (from & (1 << a));
  return c.op === 'drop' ? p + ' ∤ ' + n : 'gcd(' + p + ', ' + n + ') = ' + gcd(p, n);
}
// the rule for the two roads of a second step
export function roadsRule(R, mode) {
  const P = PIECES[R.pi], from = P.mask, [r1, r2] = R.list;
  if (mode === 'bits') return R.list.map(r => [from, r.mid, r.end].map(v => bitsOf(v, AXES.length)).join(' → ')).join(' · ');
  if (mode === 'numbers') return R.list.map(r => from + ' XOR ' + (1 << r.first) + ' XOR ' + (1 << r.second)).join(' = ') + ' = ' + flip(flip(from, r1.first), r1.second);
  const n = primeName(from), op = R.op === 'drop' ? ' ÷ ' : ' × ';
  const both = combineNames(n, PRIMES[r2.first] * PRIMES[r2.second]);
  return [r1, r2].map(r => n + op + PRIMES[r.first] + op + PRIMES[r.second]).join(' = ') + ' = ' + both;
}

// ---- the front
export const START = { pi: 0, a: 2, op: 'add', two: false };          // add y to E_x
export const setPiece = (s, pi) => ({ ...s, pi, two: false });
export const setDir = (s, a) => ({ ...s, a, two: false });
export const setOp = (s, op) => ({ ...s, op, two: false });
export const canStepAgain = s => choice(s.pi, s.a, s.op).ok;
export const stepAgain = s => (canStepAgain(s) ? { ...s, two: !s.two } : s);

// the tetrahedron: corners t, x, y, z in the picture (t on top, y in front, the edge x–z behind the solid)
export const TETRA = { w: 240, h: 228, corners: [[120, 22], [22, 150], [128, 206], [222, 142]], back: bit('x') | bit('z') };
const avg = ps => [ps.reduce((s, p) => s + p[0], 0) / ps.length, ps.reduce((s, p) => s + p[1], 0) / ps.length];
// where a label sits on the tetrahedron: a corner, the middle of an edge, the centre of a triangle or of the solid
export const placeOf = v => avg(IDX.filter(a => holds(v, a)).map(a => TETRA.corners[a]));
export const CENTRE = placeOf(ALL);
// the unit vector across edge m, pointing away from the centre of the solid (where the arrow of a drop runs beside the edge)
export function outward(m) {
  const [a, b] = IDX.filter(i => holds(m, i)).map(i => TETRA.corners[i]), dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), mid = placeOf(m);
  let nx = -dy / L, ny = dx / L; if (nx * (mid[0] - CENTRE[0]) + ny * (mid[1] - CENTRE[1]) < 0) { nx = -nx; ny = -ny; }
  return [nx, ny];
}
export const triangleOf = v => IDX.filter(a => holds(v, a)).map(a => TETRA.corners[a]);
// the drawing of the tetrahedron for piece pi with arrows to the given targets (each { to, sign }), drop or add
export function tetraDrawing(pi, op, targets) {
  const P = PIECES[pi], from = placeOf(P.mask), drop = op === 'drop';
  return {
    edges: PIECES.map((p, i) => ({ i, id: p.id, move: p.move, a: TETRA.corners[IDX.filter(j => holds(p.mask, j))[0]], b: TETRA.corners[IDX.filter(j => holds(p.mask, j))[1]], on: i === pi, back: p.mask === TETRA.back })),
    corners: IDX.map(a => ({ a, name: AXES[a], at: TETRA.corners[a], lit: drop && targets.some(t => t.to === 1 << a), out: cornerOut(a) })),
    shaded: drop ? [] : targets.map(t => ({ to: t.to, pts: triangleOf(t.to) })),
    arrows: targets.map(t => ({ from, to: placeOf(t.to), drop, along: drop ? outward(P.mask) : null, tag: t.sign ? sgn(t.sign) : '', target: t.to })),
    edge: { name: P.id, at: from, out: outward(P.mask) }
  };
}
// a corner's direction away from the centre (where its letter sits)
export function cornerOut(a) { const p = TETRA.corners[a], dx = p[0] - CENTRE[0], dy = p[1] - CENTRE[1], L = Math.hypot(dx, dy); return [dx / L, dy / L]; }

// the 4-cube of the sixteen labels: one direction of the page per switch
export const CUBE = { w: 236, h: 150, base: [18, 82], vec: [[70, 0], [0, -42], [34, -24], [98, 40]] };
export const cubeAt = v => IDX.reduce(([x, y], a) => (holds(v, a) ? [x + CUBE.vec[a][0], y + CUBE.vec[a][1]] : [x, y]), CUBE.base.slice());
export const CUBE_EDGES = Array.from({ length: ALL + 1 }, (_, v) => v).flatMap(v => IDX.filter(a => !holds(v, a)).map(a => [v, flip(v, a), a]));
// the grid of the labels 0 to 15, four to a row
export const GRID = Array.from({ length: ALL + 1 }, (_, v) => ({ v, row: Math.floor(v / 4), col: v % 4 }));

export function front(s, mode) {
  const c = choice(s.pi, s.a, s.op), P = PIECES[s.pi], two = s.two && c.ok, R = two ? roads(s.pi, s.op) : null;
  const targets = !c.ok ? [] : two ? R.list.map(r => ({ to: r.mid, sign: r.sign })) : [{ to: c.to, sign: 0 }];
  // the labels lit on the cube and the grid: source, target (or the two middles and the end)
  const lit = !c.ok ? [P.mask] : two ? [P.mask, R.list[0].mid, R.list[1].mid, R.end] : [P.mask, c.to];
  const path = !c.ok ? [] : two ? R.list.flatMap(r => [[P.mask, r.mid, r.first], [r.mid, r.end, r.second]]) : [[P.mask, c.to, s.a]];
  const boxAt = !c.ok || two ? -1 : AXES.length - 1 - s.a;           // the character of the flipped bit in the bits name (the first switch on the right)
  const labels = lit.map(v => ({ v, text: labelName(v, mode), at: cubeAt(v), box: mode === 'bits' && v === P.mask ? boxAt : -1, role: v === P.mask ? 'from' : two && v === R.end ? 'end' : 'to' }));
  const names = GRID.map(g => ({ ...g, text: labelName(g.v, mode), lit: lit.includes(g.v), from: g.v === P.mask, even: inEvenHalf(g.v) }));
  const rule = !c.ok ? ruleLine(c, mode) : two ? roadsRule(R, mode) : ruleLine(c, mode);
  const tetra = tetraDrawing(s.pi, s.op, targets);
  return {
    c, two, R, tetra, rule, againOff: !c.ok, term: termOf(c), eq: c.ok ? eqOf(c.to) : null,
    cube: { dots: Array.from({ length: ALL + 1 }, (_, v) => ({ v, at: cubeAt(v), even: inEvenHalf(v), lit: lit.includes(v) })), path, labels },
    grid: names
  };
}

// ---- back, the mathematician: geometry (the tetrahedron alone, the two roads of an edge)
export const WAYS = [{ id: 'down', label: 'Down to 1' }, { id: 'up', label: 'Up to the whole' }];
export function geometry(pi, way) {
  const op = way === 'down' ? 'drop' : 'add', R = roads(pi, op), all = PIECES.map((_, i) => roads(i, op));
  const cancel = all.filter(r => r.total === 0).length, per = R.list.length;
  return { R, drawing: tetraDrawing(pi, op, R.list.map(r => ({ to: r.mid, sign: r.sign }))), pieces: PIECES.length, per, cancel };
}

// ---- back, the mathematician: algebra (the sixteen terms e_a e_b ∂_a ∂_b of ∇∇)
export const EPS = IDX.map(a => bladeMul(1 << a, 1 << a, SQ)[1]);    // the square of each direction: what stays on the diagonal
export const blade = m => (m === 0 ? '1' : 'e_' + word(m));
export const ALGEBRA = IDX.flatMap(a => IDX.map(b => { const [m, s] = bladeMul(1 << a, 1 << b, SQ); return { a, b, m, sign: s, text: (s > 0 ? '+' : '−') + blade(m) }; }));
export const cellAt = (a, b) => ALGEBRA[a * AXES.length + b];
export const WAVE = '∇∇ = Σ ε_a ∂_a² = ' + IDX.map(a => (a === 0 ? (EPS[a] > 0 ? '' : '−') : EPS[a] > 0 ? ' + ' : ' − ') + '∂_' + AXES[a] + '²').join('');
export function algebra(a, b) {
  const c = cellAt(a, b), t = cellAt(b, a), A = AXES[a], B = AXES[b];
  // the readout: the square of a direction on the diagonal, else the twin pair and its sum
  const formula = a === b ? 'e_' + A + ' e_' + A + ' = ' + (c.sign > 0 ? '+1' : '−1') : 'e_' + A + ' e_' + B + ' + e_' + B + ' e_' + A + ' = ' + (c.sign + t.sign === 0 ? '0' : sgn(c.sign + t.sign) + blade(c.m));
  return { a, b, twin: a === b ? null : [b, a], cells: ALGEBRA.map(x => ({ ...x, on: (x.a === a && x.b === b) || (x.a === b && x.b === a), diag: x.a === x.b })), formula, sum: c.sign + (a === b ? 0 : t.sign) };
}

// ---- back, the mathematician: topology (the surface of the tetrahedron; the boundary is the drop with every square +1)
const PLAIN = sigVec(AXES.length, 0);
export const FACES = [1, 2, 3, 4].map(g => Array.from({ length: ALL + 1 }, (_, v) => v).filter(v => popcount(v) === g));   // corners, edges, triangles, the solid
export const boundaryOf = u => IDX.filter(i => holds(u, i)).map(i => ({ v: flip(u, i), sign: bladeMul(1 << i, u, PLAIN)[1] }));
// the boundary matrix from faces of grade g + 1 to faces of grade g (rows: the smaller faces)
export function boundaryMatrix(g) { const rows = FACES[g - 1], cols = FACES[g]; return rows.map(r => cols.map(c => { const t = boundaryOf(c).find(x => x.v === r); return t ? t.sign : 0; })); }
export const D1 = boundaryMatrix(1), D2 = boundaryMatrix(2), D3 = boundaryMatrix(3);
const matMul = (A, B) => A.map(r => B[0].map((_, j) => r.reduce((s, x, k) => s + x * B[k][j], 0)));
export const D1D2 = matMul(D1, D2), D2D3 = matMul(D2, D3);
export const ZERO_D1D2 = D1D2.every(r => r.every(x => x === 0));      // the table of ∂∂, corners by triangles, holds only zeros
export const EULER = { V: FACES[0].length, E: FACES[1].length, F: FACES[2].length, chi: FACES[0].length - FACES[1].length + FACES[2].length };
export const eulerLine = EULER.V + ' − ' + EULER.E + ' + ' + EULER.F + ' = ' + EULER.chi;
// the walk of each triangle as part of the boundary of the solid: + goes round in the order of its letters, − the other way
export const ORIENT = FACES[2].map((tri, j) => ({ tri, sign: D3[j][0] }));
export function walkOf(tri) { const o = ORIENT.find(x => x.tri === tri).sign, v = IDX.filter(a => holds(tri, a)); return o > 0 ? [v[0], v[1], v[2]] : [v[0], v[2], v[1]]; }
// the direction in which triangle tri walks edge m: +1 from its first letter to its second, −1 back
export function dirAlong(tri, m) { const w = walkOf(tri), [p, q] = IDX.filter(a => holds(m, a)); for (let k = 0; k < 3; k++) { if (w[k] === p && w[(k + 1) % 3] === q) return 1; if (w[k] === q && w[(k + 1) % 3] === p) return -1; } return 0; }
export function topology(pi) {
  const m = PIECES[pi].mask, tris = FACES[2].filter(t => (t & m) === m);
  const walks = tris.map(t => { const w = walkOf(t), c = placeOf(t); return { tri: t, name: letters(t), dir: dirAlong(t, m), legs: [0, 1, 2].map(k => { const A = TETRA.corners[w[k]], B = TETRA.corners[w[(k + 1) % 3]], f = 0.7; return { from: [c[0] + (A[0] - c[0]) * f, c[1] + (A[1] - c[1]) * f], to: [c[0] + (B[0] - c[0]) * f, c[1] + (B[1] - c[1]) * f], shared: (holds(m, w[k]) && holds(m, w[(k + 1) % 3])) }; }) }; });
  return {
    m, walks, opposite: walks[0].dir + walks[1].dir === 0,
    drawing: { ...tetraDrawing(pi, 'add', []), shaded: tris.map(t => ({ to: t, pts: triangleOf(t) })) },
    table: { rows: FACES[0].map(letters), cols: FACES[2].map(word), cells: D1D2 }
  };
}

// ---- back, the mathematician: category (a cube of arrows, each adding one of the switches t, x, y and carrying the sign of the kernel's product)
export const CAT_N = 3;
const CAT_V = Array.from({ length: 1 << CAT_N }, (_, v) => v), CAT_I = [0, 1, 2];
export const ARROWS = CAT_V.flatMap(v => CAT_I.filter(i => !holds(v, i)).map(i => ({ from: v, to: flip(v, i), i, sign: bladeMul(1 << i, v, SQ)[1] })));
export const SQUARES = CAT_V.flatMap(v => CAT_I.flatMap(i => CAT_I.filter(j => j > i && !holds(v, i) && !holds(v, j)).map(j => ({ v, i, j }))));
const AT = new Map(ARROWS.map((r, e) => [r.from * 8 + r.i, e]));
const arrowIndex = (from, i) => AT.get(from * 8 + i);
// the two roads round a square under the arrow signs s (one sign per arrow): first i then j, and first j then i
export const squareRoads = (q, s) => [s[arrowIndex(q.v, q.i)] * s[arrowIndex(flip(q.v, q.i), q.j)], s[arrowIndex(q.v, q.j)] * s[arrowIndex(flip(q.v, q.j), q.i)]];
export const cancels = s => SQUARES.every(q => { const [r1, r2] = squareRoads(q, s); return r1 + r2 === 0; });
// renaming: flipping the sign of the corners in the set f (a bitmask of corners) flips every arrow that has exactly one end there
export const renamed = f => ARROWS.map(r => r.sign * ((f >> r.from & 1) ? -1 : 1) * ((f >> r.to & 1) ? -1 : 1));
// every way to sign the arrows, by brute force: those whose squares all cancel, and those that a renaming of this one gives
const SIGNINGS = Array.from({ length: 1 << ARROWS.length }, (_, k) => ARROWS.map((_, e) => (k >> e & 1 ? -1 : 1)));
const CANCELLING = new Set(SIGNINGS.filter(cancels).map(x => x.join()));
const REACHED = new Set(Array.from({ length: 1 << CAT_V.length }, (_, f) => renamed(f).join()));
export const CAT_COUNT = {
  arrows: ARROWS.length, squares: SQUARES.length, corners: CAT_V.length, signings: SIGNINGS.length, cancelling: CANCELLING.size,
  renamings: 1 << CAT_V.length, reached: REACHED.size, same: CANCELLING.size === REACHED.size && [...REACHED].every(x => CANCELLING.has(x))
};
export const CAT = { w: 260, h: 236, base: [42, 196], vec: [[126, 0], [0, -122], [58, -50]] };
export const catAt = v => CAT_I.reduce(([x, y], i) => (holds(v, i) ? [x + CAT.vec[i][0], y + CAT.vec[i][1]] : [x, y]), CAT.base.slice());
export const CAT_SHOWN = SQUARES[0];                                 // the square drawn with its two roads: from 1 through t and through x to t x
export function category(f) {
  const s = renamed(f), [r1, r2] = squareRoads(CAT_SHOWN, s), q = CAT_SHOWN;
  const good = SQUARES.filter(x => { const [u, w] = squareRoads(x, s); return u + w === 0; }).length, flips = popcount(f);
  // the arrows of the drawn square: 1 for the road that adds q.i first, 2 for the road that adds q.j first
  const road = r => (r.from === q.v && r.i === q.i) || (r.from === flip(q.v, q.i) && r.i === q.j) ? 1 : (r.from === q.v && r.i === q.j) || (r.from === flip(q.v, q.j) && r.i === q.i) ? 2 : 0;
  return {
    arrows: ARROWS.map((r, e) => ({ ...r, s: s[e], tag: s[e] > 0 ? '+' : '−', a: catAt(r.from), b: catAt(r.to), road: road(r) })),
    corners: CAT_V.map(v => ({ v, name: letters(v), at: catAt(v), flipped: (f >> v & 1) === 1 })),
    roads: [r1, r2], roadTags: [{ at: catAt(flip(q.v, q.i)), tag: sgn(r1), via: letters(flip(q.v, q.i)) }, { at: catAt(flip(q.v, q.j)), tag: sgn(r2), via: letters(flip(q.v, q.j)) }],
    good, flips
  };
}
export const toggleCorner = (f, v) => f ^ (1 << v);

// ---- back, the physicist: one space direction; a hump of the field E moves along the line, the charge is how much E climbs, the current minus how fast it changes
export const LINE = { L: 8, cells: 16, w: 1.6, v: 1, x0: 2, T: 8 };
export const CELL_W = LINE.L / LINE.cells;
const wrap = s => s - LINE.L * Math.floor((s + LINE.L / 2) / LINE.L);    // into [−L/2, L/2): the line closes on itself
export const hump = s => { const u = s / LINE.w; return Math.abs(u) < 1 ? (1 - u * u) ** 2 : 0; };
export const humpSlope = s => { const u = s / LINE.w; return Math.abs(u) < 1 ? -4 * u * (1 - u * u) / LINE.w : 0; };
export const fieldE = (x, t) => hump(wrap(x - LINE.x0 - LINE.v * t));
export const current = (x, t) => LINE.v * humpSlope(wrap(x - LINE.x0 - LINE.v * t));   // J = −∂t E
export const cellCharge = (i, t) => fieldE((i + 1) * CELL_W, t) - fieldE(i * CELL_W, t);   // ρ = ∂x E, summed over cell i
// the box from boundary b0 to boundary b0 + bw: its charge now and at the start, and what crossed each end since the start
export function box(t, b0, bw) {
  const xa = b0 * CELL_W, xb = (b0 + bw) * CELL_W;
  let Q = 0; for (let i = b0; i < b0 + bw; i++) Q += cellCharge(i, t);
  let Q0 = 0; for (let i = b0; i < b0 + bw; i++) Q0 += cellCharge(i, 0);
  const inL = fieldE(xa, 0) - fieldE(xa, t), outR = fieldE(xb, 0) - fieldE(xb, t);   // ∫ J dt at each end
  return { xa, xb, Q, Q0, inL, outR, change: Q - Q0, jL: current(xa, t), jR: current(xb, t) };
}
export const PHYS = { w: 480, h: 290, X: x => 24 + 54 * x, eY: 26, eH: 70, qY: 172, qK: 90, jY: 260, jK: 25 };
export const START_PHYS = { t: 1, b0: 3, bw: 2 };
export const TIME_STEPS = 20;                                       // the clock of the line counts twentieths
export const setBoxPos = (s, b0) => ({ ...s, b0: Math.max(0, Math.min(LINE.cells - s.bw, b0)) });
export const setBoxWidth = (s, bw) => ({ ...s, bw: Math.max(1, Math.min(LINE.cells - s.b0, bw)) });
export const advanceTime = (s, dt) => ({ ...s, t: (s.t + dt) % LINE.T });
export function phys(s) {
  const B = box(s.t, s.b0, s.bw), X = PHYS.X, n = 240;
  const curve = Array.from({ length: n + 1 }, (_, k) => { const x = LINE.L * k / n; return (k ? 'L' : 'M') + X(x).toFixed(1) + ' ' + (PHYS.eY + PHYS.eH * (1 - fieldE(x, s.t))).toFixed(1); }).join(' ');
  const bars = Array.from({ length: LINE.cells }, (_, i) => { const q = cellCharge(i, s.t), x0 = X(i * CELL_W), x1 = X((i + 1) * CELL_W); return { i, q, x: x0 + 3, w: x1 - x0 - 6, y: q >= 0 ? PHYS.qY - PHYS.qK * q : PHYS.qY, h: Math.abs(PHYS.qK * q), inBox: i >= s.b0 && i < s.b0 + s.bw }; });
  const arrows = Array.from({ length: LINE.cells + 1 }, (_, k) => { const x = k * CELL_W, j = current(x, s.t); return { k, j, x: X(x), len: PHYS.jK * j, end: k === s.b0 || k === s.b0 + s.bw }; });
  const cents = v => Math.round(100 * v), show = c => (c < 0 ? '−' : '') + (Math.abs(c) / 100).toFixed(2), a = cents(B.inL), b = cents(B.outR);
  return {
    B, curve, bars, arrows, box: { x: X(B.xa), w: X(B.xb) - X(B.xa) }, tText: num(s.t, 2), cents: { inL: a, outR: b, change: a - b, Q: cents(B.Q) },
    // the readouts: the charge in the box, and its change since t = 0 as what came in at the left end minus what went out at the right end
    qText: 'Q = ' + show(cents(B.Q)), balance: 'ΔQ = ' + show(a) + ' − ' + (b < 0 ? '(' + show(b) + ')' : show(b)) + ' = ' + show(a - b)
  };
}

// ---- the numbers of the back
export const ENDS_PER_EDGE = [...new Set(PIECES.map(p => popcount(p.mask)))];
export const TRIANGLES_PER_EDGE = [...new Set(PIECES.map(p => FACES[2].filter(t => (t & p.mask) === p.mask).length))];
