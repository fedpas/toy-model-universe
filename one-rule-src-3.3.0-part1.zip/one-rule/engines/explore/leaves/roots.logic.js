// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/roots.logic.js — leaf 8, roots (port of Octavo's octavo/leaves/roots.logic.js; plain functions, no React). Every product of Cl(8,0) is the
// kernel's mul (engines/bitrule.js), the determinants are engines/schullerEngine.js's bareissDet; tests/explore/leaves.roots.test.mjs recomputes every number by
// standard routes (the lattice D8+, the closure of the simple roots, reflection matrices, the stored Coxeter plane of checks/selfcheck/gosset.json) and holds them
// bit-identical to the Octavo output.
// Front: eight switches give 240 arrows, the roots of E8, each a list of eight numbers: 112 put two switches at ±1 and the rest at 0, 128 put all eight at ±½ with
// an even number of minus signs (the even corners of the cube of switches, the half-cube). The picture is their shadow on the Coxeter plane of E8: eight rings of
// 30. Back, the mathematician: 112 = 4 · C(8,2) and 128 = 2⁷, and det Eₙ = 9 − n, which reaches 0 at n = 9. Back, the physicist: a ball rolled along an arrow into
// the wall of another arrow leaves along an arrow again (the mirror of r is the sandwich x → −r x r / r·r in Cl(8,0)).
// Coordinates are doubled everywhere (±½ is stored as ±1, ±1 as ±2), so that every number is an integer; true lengths and dot products divide by 4.
// Not carried over (docs/EXPLORE_PORT.md): COPY (its chip ids, labels and marks are FAMS), arrowLine, statusOf, formulaDet, stopWords, PICK_HINT, PHYS_INTRO,
// physCap; the sentences of seeView (line, status, alt), countView (alt, capTwo, capHalf), stopView (line, alt, stripAlt) and billiardView (say, alt).
import { mul as kmul } from '../../bitrule.js';
import { popcount, sigVec } from '../../labels.js';
import { bareissDet } from '../../schullerEngine.js';

export const N = 8;                                            // the switches
const SQ = sigVec(N, 0);                                        // Cl(8,0): every switch squares to +1
export const MINUS = '−';

// ---- the arrows, built from switch patterns: kind 'two' (switches i < j at ±1) and kind 'half' (all eight at ±½, minus where the label m has its bit set, m even)
function build() {
  const out = [];
  for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) for (let sgn = 0; sgn < 4; sgn++) {
    const v = new Array(N).fill(0); v[i] = sgn & 1 ? -2 : 2; v[j] = sgn & 2 ? -2 : 2;
    out.push({ kind: 'two', v, on: [i, j] });
  }
  for (let m = 0; m < 1 << N; m++) if (popcount(m) % 2 === 0) out.push({ kind: 'half', v: Array.from({ length: N }, (_, k) => (m >> k & 1 ? -1 : 1)), m, minus: popcount(m) });
  return out.map((r, id) => ({ ...r, id }));
}
export const ROOTS = build();
export const COUNT = { two: ROOTS.filter(r => r.kind === 'two').length, half: ROOTS.filter(r => r.kind === 'half').length, all: ROOTS.length };
const BY_KEY = new Map(ROOTS.map(r => [r.v.join(','), r.id]));
export const idOf = v => (BY_KEY.has(v.join(',')) ? BY_KEY.get(v.join(',')) : -1);

// ---- vectors in Cl(8,0): a dot product is the scalar part of the product, a mirror is a sandwich. A multivector is the list of its nonzero parts
// [[blade, coefficient], …]; every product is the kernel's mul
const vecOf = x => { const out = []; x.forEach((c, k) => { if (c) out.push([1 << k, c]); }); return out; };
export const product = (X, Y) => [...kmul(new Map(X), new Map(Y), SQ)];
const partOf = (X, blade) => { const p = X.find(([b]) => b === blade); return p ? p[1] : 0; };
// r · s in true units (the doubled coordinates carry a factor 4)
export const dotTrue = (r, s) => partOf(product(vecOf(r), vecOf(s)), 0) / 4;
// the mirror of the root r applied to the vector x: −r x r / (r r); returns the vector part, the size of whatever else the product holds (0 for a reflection) and
// r · x in true units (the scalar part of the first product r x)
export function mirrorFull(r, x) {
  const R = vecOf(r), RX = product(R, vecOf(x)), Y = product(RX, R), rr = partOf(product(R, R), 0);
  let rest = 0; for (const [b, c] of Y) if (popcount(b) !== 1) rest += Math.abs(c);
  return { v: Array.from({ length: N }, (_, k) => -partOf(Y, 1 << k) / rr), rest: rest / rr, dot: partOf(RX, 0) / 4 };
}
export const mirror = (r, x) => mirrorFull(r, x).v;

// ---- the shadow on the Coxeter plane: C = s1 s2 … s8, the product of the mirrors of the simple roots (Bourbaki: a1 = ½(1, −1, …, −1, 1), a2 = e1 + e2, a(k) = e(k−1) − e(k−2));
// the plane is spanned by the real and imaginary parts of the eigenvector of C for exp(2πi/h), h the order of C
export const SIMPLE = (() => { const s = [[1, -1, -1, -1, -1, -1, -1, 1], [2, 2, 0, 0, 0, 0, 0, 0]]; for (let k = 2; k < N; k++) { const v = new Array(N).fill(0); v[k - 1] = 2; v[k - 2] = -2; s.push(v); } return s; })();
export const coxeter = x => SIMPLE.reduceRight((y, a) => mirror(a, y), x);                        // s8 acts first, s1 last
const U0 = Array.from({ length: N }, (_, i) => 1 + 0.37 * i);                                      // a start vector with no special position
export const TURN_TO = -18;                                                                         // degrees: where the all-plus corner points (the picture is then mirror-symmetric)
export const CX = 200, CY = 200, RO = 184, MARK = 3.3;                                              // the picture: centre, radius of the outer ring, radius of a mark (viewBox 400)
let SH = null;
export function shadow() {
  if (SH) return SH;
  let h = 1, y = coxeter(U0);
  while (h < 200 && y.some((c, k) => Math.abs(c - U0[k]) > 1e-9)) { y = coxeter(y); h++; }
  const wr = new Array(N).fill(0), wi = new Array(N).fill(0); let cur = U0.slice();
  for (let k = 0; k < h; k++) { const a = -2 * Math.PI * k / h; for (let t = 0; t < N; t++) { wr[t] += Math.cos(a) * cur[t]; wi[t] += Math.sin(a) * cur[t]; } cur = coxeter(cur); }
  const raw = ROOTS.map(r => [r.v.reduce((s, c, k) => s + c * wr[k], 0), r.v.reduce((s, c, k) => s + c * wi[k], 0)]);
  const allPlus = ROOTS.findIndex(r => r.kind === 'half' && r.m === 0), turn = TURN_TO * Math.PI / 180 - Math.atan2(raw[allPlus][1], raw[allPlus][0]);
  const big = Math.max(...raw.map(p => Math.hypot(p[0], p[1]))), c = Math.cos(turn), s = Math.sin(turn);
  const pts = raw.map(p => [(c * p[0] - s * p[1]) / big, (s * p[0] + c * p[1]) / big]);
  const groups = new Map(); for (const p of pts) { const k = Math.hypot(p[0], p[1]).toFixed(6); if (!groups.has(k)) groups.set(k, Math.hypot(p[0], p[1])); }
  const radii = [...groups.values()].sort((a, b) => a - b);                                         // one radius per ring (the first mark met on it)
  const cw = p => { const d = 90 - Math.atan2(p[1], p[0]) * 180 / Math.PI; return ((d % 360) + 360) % 360; };   // clockwise from the top, in degrees
  const marks = pts.map((p, id) => ({ id, px: p[0], py: p[1], ring: radii.findIndex(q => Math.abs(q - Math.hypot(p[0], p[1])) < 2e-6), cw: cw(p), x: CX + RO * p[0], y: CY - RO * p[1] }));
  const order = marks.slice().sort((a, b) => a.ring - b.ring || a.cw - b.cw).map(m => m.id);   // the order of counting: ring by ring from the inside, clockwise from the top
  const rank = {}; for (const f of ['two', 'half', 'all']) { rank[f] = new Array(ROOTS.length).fill(-1); let k = 0; for (const id of order) if (f === 'all' || ROOTS[id].kind === f) rank[f][id] = k++; }
  SH = { h, wr, wi, marks, radii, rings: radii.map(r => RO * r), order, rank };
  return SH;
}

// ---- the eight numbers of an arrow
export const cellText = c => (c === 0 ? '0' : (c < 0 ? MINUS : '+') + (Math.abs(c) === 1 ? '½' : '1'));   // c doubled: ±1 is ±½, ±2 is ±1
export const cellsOf = v => v.map(c => ({ t: cellText(c), zero: c === 0, neg: c < 0 }));
export const listOf = v => '(' + v.map(cellText).join(', ') + ')';

// ---- the three chips of the front: the arrows shown (ids, labels and marks; the families are told apart by a mark, never by colour alone)
export const FAMS = [{ id: 'two', label: 'Two switches', mark: 'dot' }, { id: 'half', label: 'Half-cube corners', mark: 'ring' }, { id: 'all', label: 'All', mark: 'both' }];

// ---- front: a chip picks the arrows shown and counts them again; a tap or an arrow key picks one arrow
export const COUNT_TIME = 1.6;                                                     // seconds for one count, whatever the family
export const inFam = (id, fam) => fam === 'all' || ROOTS[id].kind === fam;
export const START_SEL = idOf([0, 2, 0, 0, 0, -2, 0, 0]);                          // the arrow that points straight up at the start
export const START = { fam: 'all', shown: COUNT.all, t: COUNT_TIME, sel: START_SEL };
// the arrow of the family closest to the point (x, y) of the picture
export function nearest(fam, x, y) {
  const { marks } = shadow(); let best = -1, bd = Infinity;
  for (const m of marks) { if (!inFam(m.id, fam)) continue; const d = (m.x - x) ** 2 + (m.y - y) ** 2; if (d < bd) { bd = d; best = m.id; } }
  return best;
}
export function pick(s, fam, instant = false) {
  const m = shadow().marks[s.sel], sel = inFam(s.sel, fam) ? s.sel : nearest(fam, m.x, m.y);
  return { fam, sel, t: instant ? COUNT_TIME : 0, shown: instant ? COUNT[fam] : 0 };
}
export function tick(s, dt) {
  if (s.shown >= COUNT[s.fam]) return s;
  const t = Math.min(COUNT_TIME, s.t + dt);
  return { ...s, t, shown: t >= COUNT_TIME ? COUNT[s.fam] : Math.floor(COUNT[s.fam] * t / COUNT_TIME) };
}
export const tapAt = (s, x, y) => ({ ...s, sel: nearest(s.fam, x, y) });
// the arrow keys: left and right go round the ring, up goes out one ring and down in one ring (to the mark of the family at the nearest angle)
const angGap = (a, b) => { const d = Math.abs(a - b) % 360; return Math.min(d, 360 - d); };
export function stepSel(s, key) {
  const { marks, radii } = shadow(), m = marks[s.sel];
  if (key === 'ArrowLeft' || key === 'ArrowRight') {
    const ring = marks.filter(x => x.ring === m.ring && inFam(x.id, s.fam)).sort((a, b) => a.cw - b.cw), k = ring.findIndex(x => x.id === m.id);
    if (k < 0 || ring.length < 2) return s;
    return { ...s, sel: ring[(k + (key === 'ArrowRight' ? 1 : ring.length - 1)) % ring.length].id };
  }
  if (key === 'ArrowUp' || key === 'ArrowDown') {
    for (let r = m.ring + (key === 'ArrowUp' ? 1 : -1); r >= 0 && r < radii.length; r += key === 'ArrowUp' ? 1 : -1) {
      const cand = marks.filter(x => x.ring === r && inFam(x.id, s.fam));
      if (cand.length) { cand.sort((a, b) => angGap(a.cw, m.cw) - angGap(b.cw, m.cw) || a.cw - b.cw); return { ...s, sel: cand[0].id }; }
    }
  }
  return s;
}
const FAM_WORD = { two: 'dots', half: 'rings', all: 'arrows' };
export function seeView(s) {
  const sh = shadow(), r = ROOTS[s.sel], m = sh.marks[s.sel], rk = sh.rank[s.fam];
  const marks = sh.marks.map(k => ({ id: k.id, x: k.x, y: k.y, kind: ROOTS[k.id].kind, show: inFam(k.id, s.fam), lit: inFam(k.id, s.fam) && rk[k.id] < s.shown, sel: k.id === s.sel }));
  const len = Math.hypot(m.x - CX, m.y - CY), ux = (m.x - CX) / len, uy = (m.y - CY) / len;
  return {
    marks, rings: sh.rings, counter: s.shown, counterWord: FAM_WORD[s.fam], done: s.shown >= COUNT[s.fam],
    arrow: { x1: CX, y1: CY, x2: m.x - 7.5 * ux, y2: m.y - 7.5 * uy },                     // from the centre to the edge of the picked mark
    sel: { x: m.x, y: m.y }, cells: cellsOf(r.v), list: listOf(r.v), kind: r.kind
  };
}

// ---- back, the mathematician: the two counts
export const choose = (n, k) => { let c = 1; for (let i = 1; i <= k; i++) c = c * (n - k + i) / i; return Math.round(c); };
export function countView(pair = ROOTS[START_SEL].on) {
  const nodes = Array.from({ length: N }, (_, k) => { const a = Math.PI / 2 - 2 * Math.PI * k / N; return { k, x: 76 + 56 * Math.cos(a), y: 82 - 56 * Math.sin(a), on: pair.includes(k) }; });
  const chords = []; for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) chords.push({ i, j, on: i === pair[0] && j === pair[1] });
  const signs = [[1, 1], [1, -1], [-1, 1], [-1, -1]], pairs = chords.length, free = N - 1, corners = 2 ** free;
  return { nodes, chords, signs, pair, pairs, perPair: signs.length, two: pairs * signs.length, free, corners, power: '2' + '⁰¹²³⁴⁵⁶⁷⁸⁹'[free] };
}

// ---- back, the mathematician: the E-series and its determinant. Eₙ is the tree T(2,3,n−3): a chain 1–3–4–…–n with node 2 on node 4 (Bourbaki's numbering)
export const DET_TOP = 9;                                                          // det Eₙ = 9 − n
export const E_MIN = 3, E_MAX = 9, ROOT_CAP = 1000;
export function cartanE(n) {
  const A = Array.from({ length: n }, (_, i) => Array.from({ length: n }, (_, j) => (i === j ? 2 : 0)));
  const edges = [[1, 3], [2, 4]]; for (let k = 3; k < n; k++) edges.push([k, k + 1]);
  for (const [a, b] of edges) if (a <= n && b <= n) { A[a - 1][b - 1] = -1; A[b - 1][a - 1] = -1; }
  return A;
}
export const detE = n => Number(bareissDet(cartanE(n).map(r => r.map(BigInt))));
// the roots of Eₙ: the simple roots closed under their mirrors (in the coordinates of the simple roots); Infinity once the closure passes ROOT_CAP
export function rootCount(n) {
  const A = cartanE(n), seen = new Set(), st = [];
  for (let i = 0; i < n; i++) { const v = Array.from({ length: n }, (_, j) => +(j === i)); seen.add(v.join()); st.push(v); }
  while (st.length) {
    const v = st.pop();
    for (let i = 0; i < n; i++) {
      let t = 0; for (let j = 0; j < n; j++) t += v[j] * A[j][i];
      if (!t) continue;
      const w = v.slice(); w[i] -= t; const key = w.join();
      if (!seen.has(key)) { if (seen.size >= ROOT_CAP) return Infinity; seen.add(key); st.push(w); }
    }
  }
  return seen.size;
}
let ES = null;
export const eSeries = () => ES || (ES = Array.from({ length: E_MAX - E_MIN + 1 }, (_, k) => { const n = E_MIN + k; return { n, det: detE(n), roots: rootCount(n) }; }));
export const START_N = 8;
export const canN = n => Number.isInteger(n) && n >= E_MIN && n <= E_MAX;
export function stopView(n) {
  const row = eSeries().find(e => e.n === n), chain = [1, ...Array.from({ length: Math.max(0, n - 2) }, (_, k) => k + 3)];   // 1, 3, 4, …, n
  const dx = 34, x0 = 160 - dx * (Math.max(chain.length, 3) - 1) / 2;
  const pos = {}; chain.forEach((id, k) => { pos[id] = { x: x0 + dx * k, y: 66 }; }); pos[2] = { x: x0 + dx * 2, y: 24 };
  const nodes = Object.entries(pos).map(([id, p]) => ({ id: +id, ...p, last: +id === n })), edges = [];
  const A = cartanE(n); for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) if (A[i][j]) edges.push({ a: pos[i + 1], b: pos[j + 1] });
  const endless = !Number.isFinite(row.roots);
  return {
    n, det: row.det, roots: row.roots, endless, nodes, edges,
    strip: eSeries().map(e => ({ n: e.n, name: 'E' + '₀₁₂₃₄₅₆₇₈₉'[e.n], det: e.det, roots: Number.isFinite(e.roots) ? String(e.roots) : '∞', on: e.n === n, zero: e.det === 0 }))
  };
}

// ---- back, the physicist: a ball rolled along an arrow s into the wall (the mirror) of the arrow r leaves along mirror(r, s)
export const BALLS = [{ id: 'along', label: 'Along the wall' }, { id: 'angle', label: 'At an angle' }, { id: 'head', label: 'Head-on' }];
const kindOfDot = d => (d === 0 ? 'along' : Math.abs(d) === 1 ? 'angle' : 'head');
// how the 240 arrows meet the wall of r: the dot product decides, the mirror sends each to an arrow
const TALLY = new Map();
export function wallTally(w) {
  if (TALLY.has(w)) return TALLY.get(w);
  const r = ROOTS[w].v, rows = ROOTS.map(s => { const f = mirrorFull(r, s.v), d = f.dot; return { id: s.id, d, kind: kindOfDot(d), out: idOf(f.v) }; });
  const counts = { along: 0, angle: 0, head: 0 }; for (const x of rows) counts[x.kind]++;
  const t = { rows, counts, pairs: counts.angle / 2 };
  TALLY.set(w, t);
  return t;
}
export const WALL_STEP = 97;                                                       // "another wall" jumps 97 arrows on (97 and 240 share no factor: every wall comes round)
export const PERIOD = 2.8, LEG = 1.0;                                              // seconds: one roll in, one roll out, then a pause
export const START_BALL = { w: 0, kind: 'angle', t: 0.8 };
export const nextWall = s => ({ ...s, w: (s.w + WALL_STEP) % ROOTS.length, t: 0 });
export const setBall = (s, kind) => ({ ...s, kind, t: 0 });
export const rollOn = (s, dt) => ({ ...s, t: (s.t + dt) % PERIOD });
// the ball of a kind for the wall w: the first arrow of that kind after w (head-on: the arrow −r, which comes back as r)
export function ballOf(w, kind) {
  const { rows } = wallTally(w), n = ROOTS.length;
  if (kind === 'head') return rows.find(x => x.d === -2).id;
  for (let k = 1; k <= n; k++) { const x = rows[(w + k) % n]; if (x.kind === kind && x.d <= 0) return x.id; }
  return -1;
}
const deg = x => x * 180 / Math.PI;
// the picture is the plane of the ball's path and the wall's arrow; the wall stands upright at x = WX, its arrow points left into the table
export const WX = 236, WY = 132, PATH = 112;
export function billiardView(s) {
  const r = ROOTS[s.w], b = ROOTS[ballOf(s.w, s.kind)], out = ROOTS[idOf(mirror(r.v, b.v))];
  const d = dotTrue(r.v, b.v), rr = dotTrue(r.v, r.v), bb = dotTrue(b.v, b.v), lenR = Math.sqrt(rr), lenB = Math.sqrt(bb);
  const along = d / lenR, across = Math.sqrt(Math.max(0, bb - d * d / rr));              // the parts of the ball's arrow along the wall's arrow and along the wall (exact squares)
  const ux = -along / lenB, uy = -across / lenB;                                            // its direction in the picture: towards the wall is +x, along the wall is up (−y)
  const angle = Math.round(deg(Math.acos(Math.min(1, Math.abs(d) / (lenR * lenB)))));      // between the path and the wall's arrow
  let legs, at;
  if (s.kind === 'along') {
    const x = WX - 46; legs = [{ x1: x, y1: WY + PATH, x2: x, y2: WY - PATH }];
    at = u => ({ x, y: WY + PATH - 2 * PATH * Math.min(1, u / 2) });
  } else {
    const off = s.kind === 'head' ? 6 : 0, vx = -ux, vy = uy;                                // the way out: the part towards the wall turns round, the part along the wall stays
    legs = [{ x1: WX - PATH * ux, y1: WY - PATH * uy + off, x2: WX, y2: WY + off }, { x1: WX, y1: WY - off, x2: WX + PATH * vx, y2: WY + PATH * vy - off }];
    at = u => (u <= 1 ? { x: WX - PATH * ux * (1 - u), y: WY - PATH * uy * (1 - u) + off } : { x: WX + PATH * vx * Math.min(1, u - 1), y: WY + PATH * vy * Math.min(1, u - 1) - off });
  }
  const u = s.t / LEG, pos = at(Math.min(2, u)), fade = s.t > 2 * LEG ? Math.max(0, 1 - (s.t - 2 * LEG) / (PERIOD - 2 * LEG)) : 1;
  const first = legs[0], last = legs[legs.length - 1], away = (x, y, ox, oy, k) => { const l = Math.hypot(x - ox, y - oy) || 1; return { x: x + k * (x - ox) / l, y: y + k * (y - oy) / l }; };
  const tags = [{ t: 'in', ...away(first.x1, first.y1, first.x2, first.y2, 16) }, { t: 'out', ...away(last.x2, last.y2, last.x1, last.y1, 16) }];   // beyond the two free ends of the path
  const tally = wallTally(s.w).counts;
  // the angle marks at the point of the bounce: from the wall's arrow (pointing left) to each leg
  const arc = (a0, a1, rr) => { const p = a => [WX + rr * Math.cos(a), WY - rr * Math.sin(a)], [x0, y0] = p(a0), [x1, y1] = p(a1); return 'M' + x0.toFixed(1) + ' ' + y0.toFixed(1) + ' A' + rr + ' ' + rr + ' 0 0 ' + (a1 > a0 ? 0 : 1) + ' ' + x1.toFixed(1) + ' ' + y1.toFixed(1); };
  const t60 = Math.PI - Math.acos(Math.min(1, Math.abs(d) / (lenR * lenB)));
  return {
    kind: s.kind, wall: r, ball: b, out, d, angle, legs, tags, pos, fade, tally,
    arcs: s.kind === 'angle' ? [arc(Math.PI, Math.PI + (Math.PI - t60), 30), arc(Math.PI, t60, 30)] : [],
    arcLabel: s.kind === 'angle' ? { x: WX - 46, y: WY + 4, t: angle + '°' } : null,
    cellsIn: cellsOf(b.v), cellsOut: cellsOf(out.v), cellsWall: cellsOf(r.v),
    chips: BALLS.map(k => ({ ...k, n: tally[k.id], on: k.id === s.kind }))
  };
}
