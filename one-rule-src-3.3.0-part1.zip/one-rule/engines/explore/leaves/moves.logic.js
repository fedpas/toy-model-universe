// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/moves.logic.js — leaf 2, three moves (port of Octavo's octavo/leaves/moves.logic.js; plain functions, no React). Every number comes from
// engines/labels.js (springX, squareByBitRule, trinityClass, expTX, apply: the v15 API, every sign the kernel's); tests/explore/leaves.moves.test.mjs (new: Octavo
// never wrote this leaf's test) recomputes them by standard routes and holds them bit-identical to the Octavo output.
// A move X = a e1 + b e2 + c e12 of the plane (the algebra of two plus switches) squares to a² + b² − c² by the bit rule: below zero it turns, at zero it slides,
// above zero it boosts. The spring of strength k is the move X = ½(1 − k) e2 + ½(1 + k) e12, whose square is −k, and the path of a ball on it is exp(tX) applied to
// the start. Back: the map of all such moves (mathematician) and a planet whose energy picks ellipse, parabola or hyperbola (physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY; the screen-reader sentences (ballAlt, phaseAlt, alt); the planet's line (one fixed sentence per conic; the conic is
// data: `conic`). The front's status is a readout: k, X² and the move.
import { apply, expTX, springX, squareByBitRule, trinityClass } from '../../labels.js';
import { num } from '../shared.js';

export const MOVES = ['turn', 'slide', 'boost'];            // by class −1, 0, +1 (the sign of the square)
export const X0 = 1, V0 = 0.6;                              // where the ball starts: position and speed
export const LIM = 3.1, SPEED = 1.4;                        // the picture holds |position| and |speed| below LIM; the clock runs SPEED times faster than the screen
export const KV_MIN = -20, KV_MAX = 20;                     // tenths of k, from −2 to +2

// ---- front: a ball on a spring
export function spring(kv) {
  const k = kv / 10, [a, b, c] = springX(k), X2 = squareByBitRule(a, b, c).scalar, cls = trinityClass(X2);
  return { k, a, b, c, X2, cls, name: MOVES[cls + 1] };
}
// position and speed at time t of the ball started at (X0, V0)
export const stateAt = (kv, t) => { const { a, b, c } = spring(kv); return apply(expTX(a, b, c, t), [X0, V0]); };
// the path of the start state under exp(tX): an ellipse (turn), a line (slide) or one branch of a hyperbola (boost)
export function orbitPts(k) {
  const [a, b, c] = springX(k), pts = [];
  if (k > 0) { const T = 2 * Math.PI / Math.sqrt(k); for (let i = 0; i <= 160; i++) pts.push(apply(expTX(a, b, c, T * i / 160), [X0, V0])); }
  else for (let i = -100; i <= 100; i++) pts.push(apply(expTX(a, b, c, i * 0.04), [X0, V0]));
  return pts;
}
export const toPath = pts => pts.map((p, i) => (i ? 'L' : 'M') + (150 + 50 * p[0]).toFixed(1) + ' ' + (150 - 50 * p[1]).toFixed(1)).join(' ');
export const GHOST = [1, 0, -1].map(k => toPath(orbitPts(k)));   // the turn, the slide and the boost that the strength passes through, drawn faintly
const zig = (x0, x1, y, amp, n) => { const out = []; for (let i = 0; i <= n; i++) out.push((x0 + (x1 - x0) * i / n).toFixed(1) + ',' + (i === 0 || i === n ? y : y + (i % 2 ? -amp : amp)).toFixed(1)); return out.join(' '); };
export const START = { kv: 10, t: 0.9, out: false, hold: 0 };
// one step of the animation by dt (already scaled): the ball runs along its path; when it leaves the picture it fades, waits, and starts again
export function advance(s, dt) {
  if (s.out) { const hold = s.hold + dt; return hold > 1.3 ? { ...s, t: 0, out: false, hold: 0 } : { ...s, hold }; }
  const t = s.t + dt, [x, v] = stateAt(s.kv, t);
  return Math.abs(x) > LIM || Math.abs(v) > LIM ? { ...s, out: true, hold: 0 } : { ...s, t };
}
export const setStrength = (s, kv) => ({ ...s, kv, t: 0, out: false, hold: 0 });
export function frontView(s) {
  const sp = spring(s.kv), [x, v] = stateAt(s.kv, s.t), bx = 250 + 64 * x;
  return {
    ...sp, x, v, op: s.out ? 0.3 : 1, bx, hasSpring: sp.cls !== 0, spring: zig(28, bx - 19, 112, 14, 10), dash: sp.cls > 0 ? '6 5' : 'none',
    dot: { x: 150 + 50 * x, y: 150 - 50 * v },
    kText: num(sp.k), status: 'k = ' + num(sp.k) + ' · X² = ' + num(sp.X2) + ' · ' + sp.name
  };
}

// ---- back, the mathematician: the map of the moves b e2 + c e12 (a = 0)
export const MAP_ORIGIN = { x: 130, y: 230, unit: 100 };
export function mapView(kv) {
  const sp = spring(kv), { b, c, X2, cls, k } = sp;
  return {
    ...sp, x: MAP_ORIGIN.x + MAP_ORIGIN.unit * b, y: MAP_ORIGIN.y - MAP_ORIGIN.unit * c, kText: num(k),
    line: 'b = ' + num(b, 2) + ', c = ' + num(c, 2) + ', X² = ' + num(X2, 2) + ' · ' + MOVES[cls + 1]
  };
}

// ---- back, the physicist: a planet with the mass and the pull set to 1: r = p / (1 + e cos φ), e² = 1 + 2 p E; the sign of E picks ellipse, parabola or hyperbola
export const SUN = { x: 278, y: 170 }, SC = 52, WINX = [-5.4, 1.5], WINY = 3.2, PARAM = 1;
export const EV_MIN = -8, EV_MAX = 16;                      // twentieths of E, from −0.4 to +0.8
export const PLANET_SPEED = 2.2;
export const CONICS = ['ellipse', 'parabola', 'hyperbola'];  // by kind 0, 1, 2 (the sign of E: below, at, above zero)
export const conic = E => { const e = Math.sqrt(Math.max(0, 1 + 2 * PARAM * E)); return { e, kind: E < -1e-9 ? 0 : Math.abs(E) <= 1e-9 ? 1 : 2 }; };
export const rOf = (e, phi) => PARAM / (1 + e * Math.cos(phi));
const inWin = (e, phi) => { const r = rOf(e, phi), x = r * Math.cos(phi), y = r * Math.sin(phi); return r > 0 && x > WINX[0] && x < WINX[1] && Math.abs(y) < WINY; };
export function conicPath(E) {
  const { e, kind } = conic(E), pts = [];
  if (kind === 0) for (let i = 0; i <= 240; i++) { const phi = 2 * Math.PI * i / 240, r = rOf(e, phi); pts.push([r * Math.cos(phi), r * Math.sin(phi)]); }
  else { const cap = Math.acos(Math.max(-1, Math.min(1, (PARAM / 40 - 1) / e))); for (let i = 0; i <= 240; i++) { const phi = -cap + 2 * cap * i / 240, r = rOf(e, phi); pts.push([r * Math.cos(phi), r * Math.sin(phi)]); } }
  return pts.map((p, i) => (i ? 'L' : 'M') + (SUN.x + SC * p[0]).toFixed(1) + ' ' + (SUN.y - SC * p[1]).toFixed(1)).join(' ');
}
// where the planet starts: the nearest point for a bound orbit, the point where an open orbit comes into the picture otherwise
export function startPhi(E) { const { e, kind } = conic(E); if (kind === 0) return 0; let phi = 0; while (phi > -3.1 && inWin(e, phi - 0.01)) phi -= 0.01; return phi; }
export const PLANET_GHOST = [-0.25, 0, 0.4].map(conicPath);
export const START_PLANET = { pev: -5, phi: 0, out: false, hold: 0 };
export const setEnergy = pev => ({ pev, phi: startPhi(pev / 20), out: false, hold: 0 });
// equal areas in equal times (r² dφ/dt = √p); an open orbit that leaves the picture fades, waits, and comes in again
export function advancePlanet(s, dt) {
  const E = s.pev / 20, { e } = conic(E);
  if (s.out) { const hold = s.hold + dt; return hold > 1.1 ? { ...s, phi: startPhi(E), out: false, hold: 0 } : { ...s, hold }; }
  const r = rOf(e, s.phi), phi = s.phi + dt * Math.sqrt(PARAM) / (r * r);
  return !inWin(e, phi) && e >= 1 ? { ...s, out: true, hold: 0 } : { ...s, phi };
}
export const SYMMETRY = ['so(4)', 'e(3)', 'so(3,1)'];     // the symmetry algebra of the Kepler problem for E below, at and above zero (names; no row prints them)
export function planetView(s) {
  const E = s.pev / 20, { e, kind } = conic(E), r = rOf(e, s.phi);
  return {
    E, e, kind, name: MOVES[[0, 1, 2][kind]], conic: CONICS[kind], op: s.out ? 0.3 : 1, x: SUN.x + SC * r * Math.cos(s.phi), y: SUN.y - SC * r * Math.sin(s.phi), eText: num(E, 2)
  };
}
