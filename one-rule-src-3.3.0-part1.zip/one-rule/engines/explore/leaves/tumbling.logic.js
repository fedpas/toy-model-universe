// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/tumbling.logic.js — loose leaf Tumbling under leaf 2 (port of Octavo's octavo/leaves/tumbling.logic.js; plain functions, no React).
// A free body spins about one of its three axes. Its motor M and its body bivector B move by engines/pgaEngine.js (M′ = −½MB and the Euler term of B, with the
// signs of R(3,0,1) from the kernel's signTable); the angular momentum L and the energy E are read from B. The plane of each axis and its orientation (e₃₁ = −e₁₃)
// are the kernel's (reorderSign of engines/bitrule.js). A small push about axis a obeys a 2 × 2 matrix J, read off the engine's Euler term, whose square is μ
// times the identity, μ = b²(I_c − I_a)(I_a − I_b)/(I_b I_c); J is the element x e₁ + y e₂ + z e₁₂ of Cl(2,0), squared by the bit rule (engines/labels.js
// squareByBitRule) and sorted by the kernel's trinityClass: below zero the push swings (a turn), at zero it drifts (a slide), above zero it grows (a boost).
// Front: a book in perspective and the path of L on the sphere of the body. Back: the sphere with its curves of constant energy (mathematician); the book with L
// and E (physicist). tests/explore/leaves.tumbling.test.mjs recomputes every number by standard routes (Euler's equations by RK4, the textbook linearisation and
// a finite-difference Jacobian, the box integrated by the midpoint rule, the elliptic period 4K(k), explicit 2 × 2 matrices, the rotation matrix integrated
// from the angular velocity) and holds every output bit-identical to Octavo's.
// Not carried over (docs/EXPLORE_PORT.md): COPY, FLIP_WORDS, frontStatus, pointsWord and the sentences of frontView (status, bookAlt, sphereAlt), mathView
// (line, alt) and physView (flipLine, alt). Their facts are returned as data: frontView flips, count, ring, at, pointing, mu, cls; mathView saddle, tied;
// physView count, pointing. Added for the V2 picture: PUSH_CHIPS (the slider of the first push as chips), pointing, BOOK_MATH, mathTrack.
import { alg, alignRotor, frame, kinetic, stepRK4 } from '../../pgaEngine.js';
import { reorderSign } from '../../bitrule.js';
import { squareByBitRule, trinityClass } from '../../labels.js';
import { num } from '../shared.js';

export const MOVES = ['turn', 'slide', 'boost'];            // by the sign of μ: −1, 0, +1
export const others = a => [0, 1, 2].filter(i => i !== a);

// ---- the book: a uniform box with its sides along the body axes 1, 2, 3
export const SIDES = [1.0, 0.7, 0.2];
export const SIDE_NAMES = ['long', 'middle', 'short'];
// the moment of inertia of a uniform box of mass 1 about the axis along side i: the squares of the two other sides, summed, over 12
export const boxMoments = s => [0, 1, 2].map(i => [0, 1, 2].reduce((t, j) => (j === i ? t : t + s[j] * s[j]), 0) / 12);
export const I_BOOK = boxMoments(SIDES);
// a spin about axis a at rate b: a small push grows or swings by the sign of μ (topMu of the free top of the Atlas, times b²)
export const muOf = (I, a, b = 1) => { const [p, q] = others(a); return b * b * (I[q] - I[a]) * (I[a] - I[p]) / (I[p] * I[q]); };
export const kindOf = mu => trinityClass(mu);               // −1 turn, 0 slide, +1 boost

// ---- the engine: R(3,0,1), the bit rule with one null generator; the body bivector B carries the rotation about axis i on the plane PLANES[i]
const A = alg(3);
// the rotation about axis i turns the plane of the two axes after it in cyclic order, e_j e_k; generator m + 1 of the engine is the body axis m (bit 0 is e₀),
// and the engine stores the plane as the blade of its sorted generators, so ω_i = SGN[i] B[PLANES[i]] with SGN[i] the kernel's sign of the reordering of e_j e_k
const CYC = i => [(i + 1) % 3, (i + 2) % 3];
export const PLANES = [0, 1, 2].map(i => CYC(i).reduce((m, j) => m | 2 << j, 0));      // e23, e13, e12: the rotations about the axes 1, 2, 3
const SGN = [0, 1, 2].map(i => reorderSign(2 << CYC(i)[0], 2 << CYC(i)[1]));          // +1, −1 (e31 = −e13), +1
// the inertia map of the engine: mass 1 on the translations, the moments I on the rotations
export function inertia(I) { const c = A.z(); for (const m of A.BIV) c[m] = m & 1 ? 1 : 0; PLANES.forEach((m, i) => { c[m] = I[i]; }); return c; }
export const omegaOf = B => PLANES.map((m, i) => SGN[i] * B[m]);
export const momentumOf = (B, I) => omegaOf(B).map((w, i) => I[i] * w);                       // L in the body: L_i = I_i ω_i
export function bivectorOf(L, I) { const B = A.z(); PLANES.forEach((m, i) => { B[m] = SGN[i] * L[i] / I[i]; }); return B; }
export const energyOf = (B, c) => kinetic(A, B, c);                                           // E = ½ Σ I_i ω_i²
export const norm = v => Math.hypot(v[0], v[1], v[2]);
// the rotation of a motor: column i is the world image of the body axis i (the frame of the engine, with unit sides)
export const rotationOf = M => frame(A, M, [1, 1, 1]).f;
export const apply3 = (R, v) => [0, 1, 2].map(k => R[0][k] * v[0] + R[1][k] * v[1] + R[2][k] * v[2]);
// the push about a spin b e_a, read off the Euler term of the engine: dB is quadratic in B, so its linear part at B0 in the direction X is dB(B0 + X) − dB(B0) − dB(X), exactly.
// J acts on (ω_p, ω_q), p and q the two other axes.
export function pushMatrix(I, a, b = 1) {
  const c = inertia(I), pq = others(a), B0 = A.z(); B0[PLANES[a]] = SGN[a] * b;
  const d0 = A.dB(B0, c), J = [[0, 0], [0, 0]];
  pq.forEach((o, col) => {
    const X = A.z(); X[PLANES[o]] = SGN[o];
    const d = A.dB(A.add(B0, X), c), dx = A.dB(X, c);
    pq.forEach((o2, row) => { J[row][col] = SGN[o2] * (d[PLANES[o2]] - d0[PLANES[o2]] - dx[PLANES[o2]]); });
  });
  return J;
}
// J as a move of leaf 2: the matrix [[x, y + z], [y − z, −x]] is x e1 + y e2 + z e12 of Cl(2,0), and the bit rule squares it to x² + y² − z²
export function pushMove(I, a, b = 1) {
  const J = pushMatrix(I, a, b), x = (J[0][0] - J[1][1]) / 2, y = (J[0][1] + J[1][0]) / 2, z = (J[0][1] - J[1][0]) / 2;
  return { J, X: [x, y, z], X2: squareByBitRule(x, y, z).scalar };
}

// ---- a run: the book spun about axis a with a first push of deg degrees
export const PUSH_TO = [[1, 2], [0, 2], [1, 0]];           // the push tips the spin toward these two axes, 2 : 1
export const PUSH_MIN = 1, PUSH_MAX = 30, PUSH_START = 5;  // the slider, in degrees
export const PUSH_CHIPS = [1, 2, 5, 10, 20, 30];           // the V2 control: the slider as chips (D24), in degrees
export const H = 0.01, SPEED = 3;                           // the step of the engine; the clock of the picture runs SPEED times faster than the screen (the spin is about 1 radian a unit)
export const TRAIL_EVERY = 5, TRAIL_LEN = 80;
// the moments of a run, in units of the one of its spin axis: then |L| = 1 and the spin rate is about 1
export const runMoments = a => I_BOOK.map(x => x / I_BOOK[a]);
export function startL(a, deg) {
  const th = deg * Math.PI / 180, [p, q] = PUSH_TO[a], L = [0, 0, 0];
  L[a] = Math.cos(th); L[p] = 2 * Math.sin(th) / Math.sqrt(5); L[q] = Math.sin(th) / Math.sqrt(5);
  return L;
}
// the start: L is the unit vector startL, and the motor turns L to the world's up (the vertical of the picture), so that the book starts with its spin axis nearly upright
export function newRun(a, deg) {
  const I = runMoments(a), c = inertia(I), L = startL(a, deg), B = bivectorOf(L, I), M = alignRotor(A, L, 2), E0 = energyOf(B, c), L0 = norm(momentumOf(B, I));
  return { a, deg, I, c, M, B, t: 0, acc: 0, k: 0, flips: 0, sign: 1, trail: [L], E0, L0 };
}
// one step of the animation by dt seconds: whole steps of the engine (the rest of the time is carried), a flip is a change of sign of L along the spin axis
export function advance(s, dt) {
  let acc = s.acc + dt * SPEED, st = { M: s.M, B: s.B }, t = s.t, k = s.k, flips = s.flips, sign = s.sign;
  const trail = s.trail.slice();
  while (acc >= H) {
    acc -= H; st = stepRK4(A, st, s.c, null, H); t += H; k++;
    const L = momentumOf(st.B, s.I), sg = Math.sign(L[s.a]);
    if (sg !== 0 && sg !== sign) { flips++; sign = sg; }
    if (k % TRAIL_EVERY === 0) { trail.push(L); if (trail.length > TRAIL_LEN) trail.shift(); }
  }
  return { ...s, M: st.M, B: st.B, t, acc, k, flips, sign, trail };
}
// the whole path of L in the body from the start, once round: it rings the pole of the smallest moment when 2E > |L|²/I_middle, the pole of the largest otherwise.
// The angle round that pole grows steadily; the path is closed when it has grown by 2π. Returns the points, the period, the pole it rings and whether L changes sign along a.
export const ORBIT_H = 0.02;
const rk4B = (B, c, h) => {
  const k1 = A.dB(B, c), k2 = A.dB(A.add(B, k1, h / 2), c), k3 = A.dB(A.add(B, k2, h / 2), c), k4 = A.dB(A.add(B, k3, h), c), o = A.z();
  for (let i = 0; i < A.N; i++) o[i] = B[i] + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]);
  return o;
};
export function ringPole(I, L) {
  const order = [0, 1, 2].sort((x, y) => I[x] - I[y]), twoE = L.reduce((t, x, i) => t + x * x / I[i], 0), L2 = L.reduce((t, x) => t + x * x, 0);
  return twoE * I[order[1]] > L2 ? order[0] : order[2];
}
export function orbit(a, deg, h = ORBIT_H) {
  const I = runMoments(a), c = inertia(I), L0 = startL(a, deg), ring = ringPole(I, L0), [u, v] = others(ring);
  let B = bivectorOf(L0, I), t = 0, turned = 0, prev = Math.atan2(L0[v], L0[u]), changes = 0, sign = Math.sign(L0[a]);
  const pts = [L0];
  for (let n = 0; n < 100000; n++) {
    const B2 = rk4B(B, c, h), L = momentumOf(B2, I), now = Math.atan2(L[v], L[u]);
    let d = now - prev; d = Math.atan2(Math.sin(d), Math.cos(d));
    if (Math.abs(turned + d) >= 2 * Math.PI) { t += h * (2 * Math.PI - Math.abs(turned)) / Math.abs(d); pts.push(L0); break; }
    turned += d; prev = now; t += h; B = B2; pts.push(L);
    if (Math.sign(L[a]) !== sign) { changes++; sign = Math.sign(L[a]); }
  }
  return { pts, period: t, ring, flips: changes > 0, changes };
}
export const sideKinds = () => [0, 1, 2].map(a => kindOf(muOf(I_BOOK, a)));

// ---- the camera of the book: turn the world about its vertical by AZ, look down by EL, perspective from the distance D
export const AZ = -0.5, EL = 0.32, D = 5;
const ca = Math.cos(AZ), sa = Math.sin(AZ), ce = Math.cos(EL), se = Math.sin(EL);
export const CAMROT = [[ca, 0, sa], [sa * se, ce, -ca * se], [-sa * ce, se, ca * ce]];      // rows: the screen's right, up and toward the viewer, in world coordinates
export const dot3 = (r, v) => r[0] * v[0] + r[1] * v[1] + r[2] * v[2];
export const camOf = p => [dot3(CAMROT[0], p), dot3(CAMROT[1], p), dot3(CAMROT[2], p)];
export const BOOK_BOX = { w: 360, h: 320, cx: 180, cy: 160, f: 180 };
export function toScreen(p, box = BOOK_BOX) { const q = camOf(p), k = D / (D - q[2]); return [box.cx + box.f * k * q[0], box.cy - box.f * k * q[1], q[2]]; }
// the six faces of the box: axis i, side s (0 the minus side, 1 the plus side), the four corners (bit i of a corner is its side along axis i) in order round the outward normal
export const FACES = [];
for (let i = 0; i < 3; i++) { const j = (i + 1) % 3, k = (i + 2) % 3; for (const s of [0, 1]) { const b = s << i, q = [b, b | 1 << j, b | 1 << j | 1 << k, b | 1 << k]; FACES.push({ i, s, v: s ? q : q.slice().reverse() }); } }
// the two big faces are the covers, the long thin face on the minus side of the middle axis is the spine, the other three are the edges of the pages
export const faceKind = (i, s) => (i === 2 ? 'cover' : i === 1 && s === 0 ? 'spine' : 'pages');
export const PAGE_LINES = [-0.06, -0.02, 0.02, 0.06];      // lines of the pages, at these heights across the thickness
export const corner = v => [0, 1, 2].map(i => ((v >> i & 1) - 0.5) * SIDES[i]);
const pt = p => p[0].toFixed(1) + ',' + p[1].toFixed(1);
export const TIP = 0.22;                                    // how far the arrow of the spin axis sticks out of the book
// the picture of the book for the rotation R (body to world): the faces that face the camera, the lines of the pages on them, the arrow of the spin axis a in two
// halves (the far one is drawn under the faces, the near one over them), and where the arrow points
export function bookView(R, a, box = BOOK_BOX) {
  const W = p => apply3(R, p), eye = [0, 0, D];
  const faces = [], lines = [];
  for (const F of FACES) {
    const n = [0, 1, 2].map(k => (2 * F.s - 1) * R[F.i][k]), cb = [0, 1, 2].map(k => (k === F.i ? (F.s - 0.5) * SIDES[k] : 0)), cw = camOf(W(cb)), nc = camOf(n);
    if (dot3(nc, [eye[0] - cw[0], eye[1] - cw[1], eye[2] - cw[2]]) <= 0) continue;
    const kind = faceKind(F.i, F.s);
    faces.push({ key: F.i + '' + F.s, kind, pts: F.v.map(v => pt(toScreen(W(corner(v)), box))).join(' ') });
    if (kind === 'pages') {
      const j = F.i === 0 ? 1 : 0, half = SIDES[j] / 2, x = (F.s - 0.5) * SIDES[F.i];
      for (const z of PAGE_LINES) {
        const p0 = [0, 0, z], p1 = [0, 0, z]; p0[F.i] = x; p1[F.i] = x; p0[j] = -half; p1[j] = half;
        lines.push('M' + pt(toScreen(W(p0), box)) + ' L' + pt(toScreen(W(p1), box)));
      }
    }
  }
  const out = SIDES[a] / 2, tip = out + TIP, at = d => { const p = [0, 0, 0]; p[a] = d; return toScreen(W(p), box); };
  const plus = [at(out), at(tip)], minus = [at(-out), at(-tip)], seg = q => ({ x1: q[0][0], y1: q[0][1], x2: q[1][0], y2: q[1][1] });
  const nearPlus = plus[1][2] >= minus[1][2];
  // the arrowhead at the plus end, along the drawn direction of the axis
  const dx = plus[1][0] - plus[0][0], dy = plus[1][1] - plus[0][1], len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len, hl = 15, hw = 8;
  const end = [plus[1][0] + ux * hl * 0.6, plus[1][1] + uy * hl * 0.6];
  const head = pt(end) + ' ' + pt([end[0] - ux * hl - uy * hw, end[1] - uy * hl + ux * hw]) + ' ' + pt([end[0] - ux * hl + uy * hw, end[1] - uy * hl - ux * hw]);
  const up = R[a][1];                                       // the vertical part of the spin axis in the world
  return { faces, lines, far: seg(nearPlus ? minus : plus), near: seg(nearPlus ? plus : minus), headNear: nearPlus, head, up };
}
// where the arrow of the spin axis points: up (+1), down (−1: the book has turned over) or tipping (0), by the vertical part of the axis in the world
export const pointing = up => (up > 0.7 ? 1 : up < -0.7 ? -1 : 0);
// the arrow of L, fixed in space: the world's up, which the camera draws upright; it stands beside the book at x = box.lx
export function lArrow(box) {
  const lo = toScreen([0, -0.55, 0], box), hi = toScreen([0, 0.6, 0], box), x = box.lx, hl = 15, hw = 8, tip = hi[1] - hl * 0.6;
  return { x1: x, y1: lo[1], x2: x, y2: hi[1], head: pt([x, tip]) + ' ' + pt([x - hw, tip + hl]) + ' ' + pt([x + hw, tip + hl]), label: { x: x + 12, y: hi[1] + 6 } };
}

// ---- the sphere of L in the body, seen through a view V (rows: the screen's right, up and toward the viewer, in body coordinates); orthographic
// The ball of the front: the spun side up; facing the viewer the pole that the path rings (or, when that is the spun side itself, the next side the push tips toward);
// then turned by AZ_S about the vertical, so that the third pole comes forward, and tipped by EL_S, so that the top pole leans toward the viewer
export const AZ_S = 0.35, EL_S = 0.32;
export function sphereView(a, ring) {
  const e = i => [0, 1, 2].map(k => (k === i ? 1 : 0)), cross = (x, y) => [x[1] * y[2] - x[2] * y[1], x[2] * y[0] - x[0] * y[2], x[0] * y[1] - x[1] * y[0]];
  const w = ring !== a ? ring : PUSH_TO[a][0], third = 3 - a - w, u0 = e(a), w0 = e(w), r0 = cross(u0, w0), phi = -AZ_S * Math.sign(r0[third]);
  const r1 = [0, 1, 2].map(k => Math.cos(phi) * r0[k] + Math.sin(phi) * w0[k]), w1 = [0, 1, 2].map(k => Math.cos(phi) * w0[k] - Math.sin(phi) * r0[k]);
  const up = [0, 1, 2].map(k => Math.cos(EL_S) * u0[k] - Math.sin(EL_S) * w1[k]), to = [0, 1, 2].map(k => Math.sin(EL_S) * u0[k] + Math.cos(EL_S) * w1[k]);
  return [r1, up, to];
}
export const onSphere = (d, V, g) => { const n = norm(d) || 1, x = dot3(V[0], d) / n, y = dot3(V[1], d) / n, z = dot3(V[2], d) / n; return [g.cx + g.r * x, g.cy - g.r * y, z]; };
// a path of directions as two SVG paths, the near half (toward the viewer) and the far half; where the path goes round the rim, both halves end on the rim
export function spherePaths(pts, V, g) {
  let near = '', far = '', side = null, prev = null;
  const P = q => q[0].toFixed(1) + ' ' + q[1].toFixed(1);
  for (const p of pts) {
    const n = norm(p) || 1, d = p.map(x => x / n), q = onSphere(d, V, g), s = q[2] >= 0;
    if (side === null) { if (s) near += 'M' + P(q) + ' '; else far += 'M' + P(q) + ' '; }
    else if (s !== side) {
      const ze = dot3(V[2], prev), zd = dot3(V[2], d), f = ze / (ze - zd), rim = P(onSphere([0, 1, 2].map(k => prev[k] + f * (d[k] - prev[k])), V, g));
      if (side) { near += 'L' + rim + ' '; far += 'M' + rim + ' L' + P(q) + ' '; } else { far += 'L' + rim + ' '; near += 'M' + rim + ' L' + P(q) + ' '; }
    } else if (s) near += 'L' + P(q) + ' '; else far += 'L' + P(q) + ' ';
    side = s; prev = d;
  }
  return { near: near.trim(), far: far.trim() };
}
// at most n points of a long path, the last one kept
export const thin = (pts, n) => { const k = Math.max(1, Math.ceil(pts.length / n)); return pts.filter((_, i) => i % k === 0 || i === pts.length - 1); };
// the six poles of a sphere: axis, sign, where it is drawn and whether it faces the viewer
export const polesOf = (V, g) => [0, 1, 2].flatMap(i => [1, -1].map(sg => { const d = [0, 0, 0]; d[i] = sg; const q = onSphere(d, V, g); return { i, sg, x: q[0], y: q[1], front: q[2] >= 0 }; }));
// where the name of a pole is written: a little outside the pole, away from the centre of the ball, and kept inside the picture (fs: the size of the letters)
export function poleLabels(poles, g, fs = 13, off = 14) {
  return poles.filter(p => p.label).map(p => {
    const dx = p.x - g.cx, dy = p.y - g.cy, len = Math.hypot(dx, dy), wide = 0.62 * fs * [...p.label].length;
    let x, y, anchor;
    if (len < 24) { x = p.x + 11; y = p.y - 9; anchor = 'start'; } else { const ux = dx / len, uy = dy / len; x = p.x + ux * off; y = p.y + uy * off + 0.38 * fs; anchor = ux > 0.35 ? 'start' : ux < -0.35 ? 'end' : 'middle'; }
    const left = anchor === 'start' ? x : anchor === 'end' ? x - wide : x - wide / 2, shift = Math.max(0, 3 - left) - Math.max(0, left + wide - (g.w - 3));
    return { i: p.i, text: p.label, x: x + shift, y: Math.max(fs, Math.min(g.h - 4, y)), anchor };
  });
}
export const FRONT_SPHERE = { w: 240, h: 240, cx: 120, cy: 120, r: 92 };
// the front: everything the card shows
export function frontView(s, orb, V) {
  const R = rotationOf(s.M), book = bookView(R, s.a), L = momentumOf(s.B, s.I), g = FRONT_SPHERE, dot = onSphere(L, V, g);
  const kinds = sideKinds(), c = L[s.a] / norm(L);
  return {
    book, kinds,
    path: spherePaths(thin(orb.pts, 240), V, g), trail: spherePaths(s.trail.concat([L]), V, g),
    dot: { x: dot[0], y: dot[1], front: dot[2] >= 0 }, poles: polesOf(V, g).map(p => ({ ...p, kind: kinds[p.i], label: p.sg > 0 ? SIDE_NAMES[p.i] : '' })),
    // the facts of Octavo's status line and screen-reader texts, as data: whether the path flips, the flips so far, the pole the path rings, where the dot is
    // (near the start pole +1, near the opposite pole −1, between 0), where the spin arrow points, μ of the spun side and its move (cls: −1, 0, +1)
    flips: orb.flips, count: s.flips, ring: orb.ring, at: c > 0.9 ? 1 : c < -0.9 ? -1 : 0, pointing: pointing(book.up), mu: muOf(I_BOOK, s.a), cls: kinds[s.a]
  };
}

// ---- back, the mathematician: the sphere of a body with moments (I1, 1, I3), its curves of constant energy, μ for each axis
export const MATH_MIN = 50, MATH_MAX = 150, MATH_STEP = 5;   // the two sliders, in hundredths of I2
export const START_MATH = { i1: 60, i3: 140 };
export const mathMoments = (i1, i3) => [i1 / 100, 1, i3 / 100];
export const LOOPS = 6, LOOP_PTS = 96;
// the curves of constant energy on the unit sphere |L| = 1: 2E = Σ L_i²/I_i. Round an axis p of the smallest or the largest moment the curves are loops:
// (1/I_p − 2E) = Σ_{j ≠ p} L_j² (1/I_p − 1/I_j), an ellipse in the two other components; the loop of size σ reaches σ along the middle axis.
// Between the two families lie the curves through the middle poles: two great circles that cross there (L_l = ±κ L_s). With two moments equal the loops are circles and the
// great circle between the two equal axes is made of steady spins; with all three equal every spin is steady.
export function levelCurves(I, n = LOOPS, N = LOOP_PTS) {
  const order = [0, 1, 2].sort((x, y) => I[x] - I[y]), [s, m, l] = order, inv = I.map(x => 1 / x), loops = [], cross = [], rest = [];
  const circle = (u, w) => Array.from({ length: N + 1 }, (_, k) => { const f = 2 * Math.PI * k / N; return [0, 1, 2].map(i => Math.cos(f) * u[i] + Math.sin(f) * w[i]); });
  const unit = i => { const e = [0, 0, 0]; e[i] = 1; return e; };
  const ringAbout = (p, mid) => {
    const [q, r] = others(p), o = q === mid ? r : q, am = inv[p] - inv[mid], ao = inv[p] - inv[o];
    for (let k = 1; k <= n; k++) {
      const sg = k / (n + 1), em = sg, eo = sg * Math.sqrt(am / ao);
      for (const pole of [1, -1]) {
        loops.push({ p, pole, pts: Array.from({ length: N + 1 }, (_, j) => { const f = 2 * Math.PI * j / N, v = [0, 0, 0]; v[mid] = em * Math.cos(f); v[o] = eo * Math.sin(f); v[p] = pole * Math.sqrt(Math.max(0, 1 - v[mid] * v[mid] - v[o] * v[o])); return v; }) });
      }
    }
  };
  if (I[s] === I[l]) return { order, loops, cross, rest, all: true };
  if (I[s] === I[m]) { ringAbout(l, m); rest.push(circle(unit(s), unit(m))); return { order, loops, cross, rest, all: false }; }
  if (I[m] === I[l]) { ringAbout(s, m); rest.push(circle(unit(m), unit(l))); return { order, loops, cross, rest, all: false }; }
  ringAbout(s, m); ringAbout(l, m);
  const kappa = Math.sqrt((inv[s] - inv[m]) / (inv[m] - inv[l]));
  for (const sg of [1, -1]) { const u = [0, 0, 0], h = Math.hypot(1, kappa); u[s] = 1 / h; u[l] = sg * kappa / h; cross.push(circle(u, unit(m))); }
  return { order, loops, cross, rest, all: false };
}
// the view of the mathematician's sphere: e3 up, turned AZ_M about it and seen from EL_M above, so that the three plus poles face the viewer, e2 the most
export const AZ_M = 0.95, EL_M = 0.42;
export const MATH_VIEW = (() => { const c1 = Math.cos(AZ_M), s1 = Math.sin(AZ_M), c2 = Math.cos(EL_M), s2 = Math.sin(EL_M); return [[-s1, c1, 0], [-s2 * c1, -s2 * s1, c2], [c2 * c1, c2 * s1, s2]]; })();
export const MATH_SPHERE = { w: 360, h: 360, cx: 180, cy: 180, r: 150 };
const SUBS = ['₁', '₂', '₃'];
// the track of a moment slider, coloured by what a spin about that axis does as the moment slides (the other two fixed): a turn outside the other two moments, a boost
// between them, a slide where it equals one of them
export function momentTrack(other1, other2) {
  const pct = v => ((v - MATH_MIN / 100) / ((MATH_MAX - MATH_MIN) / 100) * 100), lo = Math.min(other1, other2), hi = Math.max(other1, other2), c = k => 'var(--' + k + ')';
  const stops = [], band = (from, to, k) => { stops.push(c(k) + ' ' + from.toFixed(1) + '%', c(k) + ' ' + to.toFixed(1) + '%'); };
  const a = Math.max(0, Math.min(100, pct(lo))), b = Math.max(0, Math.min(100, pct(hi)));
  band(0, Math.max(0, a - 1.2), 'turn'); band(Math.max(0, a - 1.2), Math.min(100, a + 1.2), 'slide');
  if (b - a > 2.4) { band(a + 1.2, b - 1.2, 'boost'); band(b - 1.2, Math.min(100, b + 1.2), 'slide'); }
  band(Math.min(100, Math.max(a, b) + 1.2), 100, 'turn');
  return 'linear-gradient(90deg, ' + stops.join(', ') + ')';
}
export function mathView(i1, i3) {
  const I = mathMoments(i1, i3), V = MATH_VIEW, g = MATH_SPHERE, cv = levelCurves(I);
  const rows = [0, 1, 2].map(a => { const mu = muOf(I, a), k = kindOf(mu); return { a, mu, kind: k, name: MOVES[k + 1], axis: 'e' + SUBS[a], moment: 'I' + SUBS[a] + ' = ' + num(I[a], 2), muText: 'μ = ' + (mu > 1e-9 ? '+' : '') + num(mu, 2) + ' b²' }; });
  const saddle = rows.filter(r => r.kind === 1).map(r => r.a), steadyAll = cv.all, tied = rows.filter(r => r.kind === 0).map(r => r.a);
  return {
    I, rows, all: steadyAll,
    loops: cv.loops.map(L => ({ p: L.p, ...spherePaths(L.pts, V, g) })), cross: cv.cross.map(c => spherePaths(c, V, g)), rest: cv.rest.map(c => spherePaths(c, V, g)),
    poles: polesOf(V, g).map(P => ({ ...P, kind: rows[P.i].kind, label: P.sg > 0 ? 'e' + SUBS[P.i] : '' })),
    track1: momentTrack(1, I[2]), track3: momentTrack(I[0], 1),
    // the facts of Octavo's line, as data: the axes whose poles carry the saddle (μ > 0) and the axes whose spin is free (μ = 0)
    saddle, tied
  };
}
// the moments of the book in hundredths of the middle one (the mathematician's sphere of the front's body), and the path of a run on that sphere
export const BOOK_MATH = [100 * I_BOOK[0] / I_BOOK[1], 100 * I_BOOK[2] / I_BOOK[1]];
export function mathTrack(s, orb) {
  const V = MATH_VIEW, g = MATH_SPHERE, L = momentumOf(s.B, s.I), dot = onSphere(L, V, g);
  return { path: spherePaths(thin(orb.pts, 240), V, g), trail: spherePaths(s.trail.concat([L]), V, g), dot: { x: dot[0], y: dot[1], front: dot[2] >= 0 } };
}

// ---- back, the physicist: the book spun about its middle side, with L fixed in space and the energy; the flips and the time between them
export const PHYS = { a: 1, deg: PUSH_START };
export const PHYS_BOX = { w: 400, h: 320, cx: 226, cy: 160, f: 180, lx: 46 };
export function physView(s, orb) {
  const R = rotationOf(s.M), book = bookView(R, s.a, PHYS_BOX), L = momentumOf(s.B, s.I), Ln = norm(L), E = energyOf(s.B, s.c), Lw = apply3(R, L);
  return {
    book, arrow: lArrow(PHYS_BOX), Lw,
    meters: [
      { name: 'Length of L', now: num(Ln, 6), start: num(s.L0, 6), moved: num(Math.abs(Ln - s.L0), 6) },
      { name: 'Energy', now: num(E, 6), start: num(s.E0, 6), moved: num(Math.abs(E - s.E0), 6) }
    ],
    beat: (orb.period / 2) / SPEED,
    // the facts of Octavo's flip line and screen-reader text, as data: the flips so far and where the spin arrow points
    count: s.flips, pointing: pointing(book.up)
  };
}
