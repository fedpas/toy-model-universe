// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.tumbling.mjs — the fixed inputs of the loose leaf Tumbling, in the form of cases.mjs: [id, fn, { drop, add }], run once
// through Octavo's octavo/leaves/tumbling.logic.js (make_octavo.mjs → tumbling_octavo.json) and once through the port (tests/explore/leaves.tumbling.test.mjs).
// The whole state space the controls reach: the three sides × every push of Octavo's slider (1° to 30°), runs played frame by frame, and the 21 × 21 states of
// the mathematician's two sliders; seeded boxes, moments and bodies from prng (round 2). cases.mjs adds them as CASES.tumbling.
import { prng } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };
const SIDES3 = [0, 1, 2];

export function cases(M) {
  const C = [], pushes = range(M.PUSH_MIN, M.PUSH_MAX), grid = range(M.MATH_MIN, M.MATH_MAX, M.MATH_STEP);
  const play = (s, frames, every) => { const out = []; for (let f = 1; f <= frames; f++) { s = M.advance(s, 1 / 60); if (f % every === 0) out.push(s); } return out; };
  C.push(['constants', () => [M.MOVES, M.SIDES, M.SIDE_NAMES, M.I_BOOK, M.PLANES, M.PUSH_TO, M.PUSH_MIN, M.PUSH_MAX, M.PUSH_START, M.H, M.SPEED, M.TRAIL_EVERY, M.TRAIL_LEN,
    M.ORBIT_H, M.AZ, M.EL, M.D, M.CAMROT, M.BOOK_BOX, M.FACES, M.PAGE_LINES, M.TIP, M.AZ_S, M.EL_S, M.FRONT_SPHERE, M.MATH_MIN, M.MATH_MAX, M.MATH_STEP, M.START_MATH,
    M.LOOPS, M.LOOP_PTS, M.AZ_M, M.EL_M, M.MATH_VIEW, M.MATH_SPHERE, M.PHYS, M.PHYS_BOX]]);
  C.push(['others, boxMoments, muOf, kindOf, sideKinds on seeded boxes (sides 0.1 … 1.5, ties included)', () => {
    const r = prng(4401), boxes = [[1, 0.7, 0.2], [1, 1, 1], [1, 1, 0.2], [0.3, 1.5, 0.3], [1.5, 0.1, 0.7]];
    for (let k = 0; k < 40; k++) boxes.push([0, 1, 2].map(() => Math.round((0.1 + 1.4 * r()) * 20) / 20));
    return [SIDES3.map(M.others), boxes.map(b => { const I = M.boxMoments(b); return [I, SIDES3.map(a => [0.5, 1, 2].map(w => { const mu = M.muOf(I, a, w); return [mu, M.kindOf(mu)]; }))]; }), M.sideKinds()];
  }]);
  C.push(['inertia, omegaOf, momentumOf, bivectorOf, energyOf, norm on seeded bodies', () => {
    const r = prng(4402), out = [];
    for (let k = 0; k < 30; k++) { const I = [0, 1, 2].map(() => 0.2 + r()), L = [0, 1, 2].map(() => 2 * r() - 1), c = M.inertia(I), B = M.bivectorOf(L, I); out.push([c, B, M.omegaOf(B), M.momentumOf(B, I), M.energyOf(B, c), M.norm(L)]); }
    return out;
  }]);
  C.push(['pushMatrix and pushMove: the book, every state of the sliders, seeded moments and rates', () => {
    const r = prng(4403), out = [SIDES3.map(a => [M.pushMatrix(M.I_BOOK, a), M.pushMove(M.I_BOOK, a)])];
    for (const i1 of grid) for (const i3 of grid) { const I = M.mathMoments(i1, i3); out.push(SIDES3.map(a => M.pushMove(I, a))); }
    for (let k = 0; k < 20; k++) { const I = [0, 1, 2].map(() => 0.2 + r()), w = 0.25 + 2 * r(); out.push(SIDES3.map(a => [M.pushMatrix(I, a, w), M.pushMove(I, a, w)])); }
    return out;
  }]);
  C.push(['startL, runMoments, newRun at every side and every push', () => SIDES3.map(a => [M.runMoments(a), pushes.map(d => [M.startL(a, d), M.newRun(a, d)])])]);
  C.push(['advance: every side at pushes 1, 5 and 30, 300 frames, every 30th state', () => SIDES3.map(a => [1, 5, 30].map(d => play(M.newRun(a, d), 300, 30)))]);
  C.push(['advance with uneven frames (dt 0 … 0.05)', () => { const r = prng(4404); let s = M.newRun(1, 7); const out = []; for (let f = 0; f < 200; f++) { s = M.advance(s, 0.05 * r()); if (f % 20 === 0) out.push(s); } return out; }]);
  C.push(['ringPole and orbit at every side and every push (summary)', () => SIDES3.map(a => pushes.map(d => { const o = M.orbit(a, d), n = o.pts.length; return [M.ringPole(M.runMoments(a), M.startL(a, d)), o.period, o.ring, o.flips, o.changes, n, o.pts[1], o.pts[n >> 1], o.pts[n - 2], o.pts[n - 1]]; }))]);
  C.push(['orbit, whole, at pushes 1, 5 and 30', () => SIDES3.map(a => [1, 5, 30].map(d => M.orbit(a, d)))]);
  C.push(['rotationOf and apply3 along runs', () => SIDES3.map(a => play(M.newRun(a, 10), 240, 40).map(s => { const R = M.rotationOf(s.M); return [R, M.apply3(R, M.momentumOf(s.B, s.I))]; }))]);
  C.push(['camOf, toScreen, corner, faceKind, dot3', () => [range(0, 7).map(v => [M.corner(v), M.camOf(M.corner(v)), M.toScreen(M.corner(v)), M.toScreen(M.corner(v), M.PHYS_BOX)]), SIDES3.map(i => [0, 1].map(s => M.faceKind(i, s))), M.dot3([1, 2, 3], [4, -5, 6])]]);
  C.push(['bookView along runs, in the front box and in the physicist box', () => SIDES3.map(a => play(M.newRun(a, 20), 240, 24).map(s => { const R = M.rotationOf(s.M); return [M.bookView(R, a), M.bookView(R, a, M.PHYS_BOX)]; }))]);
  C.push(['lArrow', () => [M.lArrow(M.PHYS_BOX), M.lArrow({ ...M.PHYS_BOX, lx: 80 })]]);
  C.push(['sphereView, onSphere, polesOf, poleLabels, thin', () => SIDES3.map(a => SIDES3.map(ring => { const V = M.sphereView(a, ring), g = M.FRONT_SPHERE, P = M.polesOf(V, g).map(p => ({ ...p, label: p.sg > 0 ? M.SIDE_NAMES[p.i] : '' })); return [V, M.onSphere([0.3, -0.5, 0.8], V, g), P, M.poleLabels(P, g), M.poleLabels(P, g, 18, 20)]; })).concat([[M.thin(range(0, 99), 7), M.thin(range(0, 5), 10)]])]);
  C.push(['spherePaths of the orbits of every side at push 5', () => SIDES3.map(a => { const o = M.orbit(a, 5), V = M.sphereView(a, o.ring); return [M.spherePaths(M.thin(o.pts, 240), V, M.FRONT_SPHERE), M.spherePaths(o.pts, M.MATH_VIEW, M.MATH_SPHERE)]; })]);
  C.push(['frontView at the start and along a played run, every side at pushes 1, 5 and 30', () => SIDES3.map(a => [1, 5, 30].map(d => { const o = M.orbit(a, d), V = M.sphereView(a, o.ring); return [M.newRun(a, d), ...play(M.newRun(a, d), 360, 60)].map(s => M.frontView(s, o, V)); })),
    { drop: ['status', 'bookAlt', 'sphereAlt'], add: ['flips', 'count', 'ring', 'at', 'pointing', 'mu', 'cls'] }]);
  C.push(['levelCurves at every state of the sliders (summary) and at ties', () => [...grid.flatMap(i1 => grid.map(i3 => [i1, i3])), [100, 100], [60, 60], [140, 140]].map(([i1, i3]) => { const c = M.levelCurves(M.mathMoments(i1, i3)); return [c.order, c.all, c.loops.length, c.cross.length, c.rest.length, c.loops.map(l => [l.p, l.pole, l.pts[17]]), c.cross.map(x => x[13]), c.rest.map(x => x[29])]; })]);
  C.push(['levelCurves whole, mathMoments, momentTrack', () => [M.levelCurves(M.mathMoments(60, 140)), M.levelCurves(M.mathMoments(100, 140)), M.levelCurves([1, 1, 1]), grid.map(v => [M.mathMoments(v, 150 - v + 50), M.momentTrack(v / 100, 1), M.momentTrack(1, v / 100)])]]);
  C.push(['mathView at every state of the two sliders', () => grid.map(i1 => grid.map(i3 => M.mathView(i1, i3))), { drop: ['line', 'alt'], add: ['saddle', 'tied'] }]);
  C.push(['mathView at the start and at the ties', () => [M.mathView(M.START_MATH.i1, M.START_MATH.i3), M.mathView(100, 140), M.mathView(60, 100), M.mathView(100, 100)], { drop: ['line', 'alt'], add: ['saddle', 'tied'] }]);
  C.push(['physView along the played run of the physicist', () => { const o = M.orbit(M.PHYS.a, M.PHYS.deg); return [M.newRun(M.PHYS.a, M.PHYS.deg), ...play(M.newRun(M.PHYS.a, M.PHYS.deg), 1200, 60)].map(s => M.physView(s, o)); }, { drop: ['flipLine', 'alt'], add: ['count', 'pointing'] }]);
  return C;
}
