// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.mjs — the fixed inputs on which each leaf logic is run twice: once as Octavo wrote it (make_octavo.mjs stores the outputs in
// <slug>_octavo.json) and once as ported (tests/explore/leaves.<slug>.test.mjs). CASES[slug](M) lists [id, fn, { drop, add }]: fn(M) calls only exports that both
// modules have, over the whole state space the controls reach (a long output is stored as a digest, codec.mjs); drop names the keys of Octavo's output the port
// does not carry (sentences), add the keys the port returns instead (data); a key in both is a readout whose words changed. Seeded inputs come from prng (round 2).
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };
const pick = (o, keys) => Object.fromEntries(keys.map(k => [k, o[k]]));

export const CASES = {
  // ------------------------------------------------------------------------------------------------ leaf 1, the clock
  clock(M) {
    const C = [], reach = [];
    for (let p = 0; p <= 16; p++) for (let q = 0; q <= 16; q++) if (M.canMove(p, q)) reach.push([p, q]);
    const back = []; for (let p = 0; p <= 10; p++) for (let q = 0; q <= 10; q++) if (M.canVote(p, q)) back.push([p, q]);
    C.push(['constants', () => [M.MAX_EACH, M.MAX_TOTAL, M.BACK_EACH, M.BACK_TOTAL, M.START, M.START_VOTES, M.START_FRIEND], { drop: ['note'], add: ['kind'] }]);
    C.push(['canMove and canVote on −1 … 17', () => range(-1, 17).map(p => range(-1, 17).map(q => [M.canMove(p, q), M.canVote(p, q)]))]);
    C.push(['front at every count the steppers reach', () => reach.map(([p, q]) => M.front({ p, q, ang: 0, note: '' })), { drop: ['aria', 'alt'] }]);
    C.push(['a seeded walk of 400 presses (steppers, swap, eight, hours)', () => {
      const r = prng(1010), out = []; let s = M.START;
      for (let t = 0; t < 400; t++) {
        const x = r(); let next;
        if (x < 0.2) next = M.move(s, s.p + 1, s.q); else if (x < 0.4) next = M.move(s, s.p, s.q + 1); else if (x < 0.55) next = M.move(s, s.p - 1, s.q); else if (x < 0.7) next = M.move(s, s.p, s.q - 1);
        else if (x < 0.8) next = M.swapSigns(s); else if (x < 0.9) { const e = M.eight(s); next = e ? e.next : s; } else next = M.tapHour(s, pint(r, 0, 7));
        out.push(next); s = next;
      }
      return out;
    }, { drop: ['note'], add: ['kind'] }]);
    C.push(['eight at every count the steppers reach', () => reach.map(([p, q]) => M.eight({ p, q, ang: 90, note: '' })), { drop: ['label', 'note'], add: ['op', 'kind'] }]);
    C.push(['tapHour, swapSigns', () => [range(0, 7).map(h => M.tapHour(M.START, h)), reach.filter((_, i) => i % 7 === 0).map(([p, q]) => M.swapSigns({ p, q, ang: 45, note: '' }))], { drop: ['note'], add: ['kind'] }]);
    C.push(['votes and voteView at every count the back reaches', () => back.map(([p, q]) => [M.votes(p, q), M.voteView(p, q)]), { drop: ['alt'] }]);
    C.push(['FRIENDS', () => M.FRIENDS, { drop: ['say'] }]);
    C.push(['friendView and pickFriend', () => M.FRIENDS.map((_, i) => [M.friendView({ f: i, angF: 0 }), M.FRIENDS.map((_, j) => M.pickFriend({ f: i, angF: 90 }, j))]), { drop: ['dialAlt', 'alt', 'say', 'flip'], add: ['mirror'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ leaf 2, three moves
  moves(M) {
    const C = [], kvs = range(M.KV_MIN, M.KV_MAX), pevs = range(M.EV_MIN, M.EV_MAX), ks = range(-2, 2, 0.5);
    C.push(['constants', () => [M.MOVES, M.X0, M.V0, M.LIM, M.SPEED, M.KV_MIN, M.KV_MAX, M.START, M.MAP_ORIGIN, M.SUN, M.SC, M.WINX, M.WINY, M.PARAM, M.EV_MIN, M.EV_MAX, M.PLANET_SPEED, M.START_PLANET, M.SYMMETRY]]);
    C.push(['spring at every strength', () => kvs.map(M.spring)]);
    C.push(['stateAt', () => kvs.map(kv => [0, 0.37, 1.1, 2.5, -0.8].map(t => M.stateAt(kv, t)))]);
    C.push(['orbitPts at k = −2 … 2 by ½', () => ks.map(M.orbitPts)]);
    C.push(['toPath of the orbits, GHOST', () => [ks.map(k => M.toPath(M.orbitPts(k))), M.GHOST]]);
    C.push(['the front, played: frontView every 10th frame of 120', () => range(-20, 20, 5).map(kv => {
      let s = M.setStrength(M.START, kv); const out = [];
      for (let f = 0; f <= 120; f++) { if (f % 10 === 0) out.push([s, M.frontView(s)]); s = M.advance(s, M.SPEED / 60); }
      return out;
    }), { drop: ['ballAlt', 'phaseAlt', 'status'], add: ['status'] }]);
    C.push(['frontView at every strength and t = 0.9', () => kvs.map(kv => M.frontView({ kv, t: 0.9, out: false, hold: 0 })), { drop: ['ballAlt', 'phaseAlt', 'status'], add: ['status'] }]);
    C.push(['advance leaves, waits and starts again', () => { let s = { kv: -20, t: 0, out: false, hold: 0 }; const out = []; for (let f = 0; f < 400; f++) { s = M.advance(s, 0.05); out.push(s); } return out; }]);
    C.push(['mapView at every strength', () => kvs.map(M.mapView), { drop: ['alt'] }]);
    C.push(['conic, startPhi at every energy', () => pevs.map(p => [M.conic(p / 20), M.startPhi(p / 20), M.setEnergy(p)])]);
    C.push(['rOf', () => [0, 0.5, 1, 1.4].map(e => range(-3, 3, 0.5).map(phi => M.rOf(e, phi)))]);
    C.push(['conicPath at seven energies, PLANET_GHOST', () => [[-8, -5, -1, 0, 1, 5, 16].map(p => M.conicPath(p / 20)), M.PLANET_GHOST]]);
    C.push(['the planet, played: planetView every 20th frame of 400', () => [-8, -5, 0, 5, 16].map(pev => {
      let s = M.setEnergy(pev); const out = [];
      for (let f = 0; f <= 400; f++) { if (f % 20 === 0) out.push([s, M.planetView(s)]); s = M.advancePlanet(s, M.PLANET_SPEED / 60); }
      return out;
    }), { drop: ['line', 'alt'], add: ['conic'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ leaf 5, zero
  zero(M) {
    const C = [], ALL = [];
    for (const a of [1, -1, 0]) for (const b of [1, -1, 0]) for (const c of [1, -1, 0]) ALL.push([a, b, c]);
    const PAIRS = []; for (let a = 0; a < 8; a++) for (let b = 0; b < 8; b++) PAIRS.push([a, b]);
    const PQR = []; for (let p = 0; p <= 5; p++) for (let q = 0; q <= 5; q++) for (let r = 0; r <= 5; r++) if (p + q + r <= 5) PQR.push([p, q, r]);
    const dropFront = { drop: ['aria', 'alt', 'key', 'why'], add: ['zeros', 'shared'] };
    C.push(['constants', () => [M.N, M.START, M.BOX, M.MAX_N, M.START_LAYERS, M.TOWER, M.DUAL_MIN, M.DUAL_MAX, M.START_DUAL, M.PLANE, M.PGA, M.SLIDE_MIN, M.SLIDE_MAX, M.START_SLIDES, M.HALF, M.TRACK, M.E0, M.E01]]);
    C.push(['helpers', () => [[1, -1, 0].map(M.nextSign), ALL.map(M.zeroMask), range(0, 31).map(a => [M.nameOf(a), M.spoken(a)]), range(0, 7).map(M.cornerAt),
      [[0, 0], [1.5, 0], [0, 1], [0, -1], [0.25, -2], [-0.75, 0.5], [2, 1], [1 / 3, -1 / 7]].map(([c0, c1]) => [M.lin(c0, c1, 'e₀'), M.exact2(c0), M.exact2(c1)]), M.nb('a b c')]]);
    C.push(['times: 27 settings × 64 pairs', () => ALL.map(eps => PAIRS.map(([a, b]) => M.times(a, b, eps)))]);
    C.push(['front with e₁₃ × e₃ in the tray, every setting', () => ALL.map(eps => M.front({ eps, tray: [5, 4] })), dropFront]);
    C.push(['front with an empty and a half tray, every setting', () => ALL.map(eps => [M.front({ eps, tray: [] }), M.front({ eps, tray: [3] })]), dropFront]);
    C.push(['front, every setting and every pair: the product, the marks', () => ALL.map(eps => PAIRS.map(([a, b]) => { const v = M.front({ eps, tray: [a, b] }); return [v.eq, v.product, v.held, v.r, v.corners.map(c => (c.zero ? 1 : 0) + (c.picked ? 2 : 0) + (c.result ? 4 : 0))]; }))]);
    C.push(['tapSwitch and tapCorner', () => { let s = M.START; const out = []; for (let k = 0; k < 12; k++) { s = k % 3 === 2 ? M.tapCorner(s, (k * 5) % 8) : M.tapSwitch(s, k % 3); out.push(s); } return out; }]);
    C.push(['canLayers', () => range(0, 6).map(p => range(0, 6).map(q => range(0, 6).map(r => M.canLayers(p, q, r))))]);
    C.push(['layersOf and powersOf', () => PQR.map(([p, q, r]) => [M.zeroBits(p, q, r), M.layersOf(p, q, r), M.powersOf(p, q, r)])]);
    C.push(['layerView at every signature the steppers reach', () => PQR.map(([p, q, r]) => M.layerView(p, q, r)), { drop: ['line', 'alt'] }]);
    C.push(['undo: seeded integer elements', () => {
      const r = prng(55), out = [];
      for (const [p, q, rr] of [[0, 0, 1], [1, 0, 1], [0, 1, 1], [1, 1, 1], [2, 0, 1], [0, 2, 1], [2, 1, 1], [3, 0, 1], [0, 0, 2], [1, 0, 2], [0, 1, 2], [1, 1, 2], [2, 0, 2], [0, 2, 2], [2, 1, 2]]) {
        const N = 1 << (p + q + rr);
        for (let t = 0; t < 4; t++) { const x = {}; for (let a = 0; a < N; a++) if (r() < 0.55) x[a] = pint(r, -3, 3); out.push(M.undo(p, q, rr, x)); }
      }
      return out;
    }]);
    C.push(['dualView at every position', () => range(M.DUAL_MIN, M.DUAL_MAX).map(av => range(M.DUAL_MIN, M.DUAL_MAX).map(bv => M.dualView(av, bv))), { drop: ['line', 'alt'], add: ['readout'] }]);
    C.push(['translator, reverse, point, placeOf, sandwich', () => [range(-2, 2, 0.5).map(M.translator), [Float64Array.of(1, 2, 3, 4), Float64Array.of(-1, 0.5, 0, 2)].map(M.reverse),
      range(-2, 2, 0.7).map(x => [M.point(x), M.placeOf(M.point(x))]), range(-2, 2, 0.5).map(a => M.sandwich(M.translator(a), M.point(0.7))), range(-5, 5).map(M.toX)]]);
    C.push(['slideView at every position', () => range(M.SLIDE_MIN, M.SLIDE_MAX).map(av => range(M.SLIDE_MIN, M.SLIDE_MAX).map(bv => M.slideView(av, bv))), { drop: ['line', 'alt'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ leaf 6, light
  light(M) {
    const C = [], reach = [];
    for (let p = 0; p <= 5; p++) for (let q = 0; q <= 5; q++) if (M.canSet(p, q)) reach.push([p, q]);
    const noShape = w => Object.fromEntries(Object.entries(w).filter(([k]) => k !== 'shape'));
    const dropWorld = { drop: ['status', 'alt', 'switchAlt', 'tag'] };
    C.push(['constants', () => [M.EPS, M.MIN_N, M.MAX_N, M.MAX_EACH, M.HEADINGS, M.SPEED, M.T_END, M.HOLD, M.START, M.POND, M.SIGS3, M.TILTS, M.LINES, M.RHO, M.CONE, M.START_CONE, M.PLUCK, M.T10_MAX, M.STRING, M.ST, M.TICKS, M.START_T10, M.C]]);
    C.push(['KINDS, MARK_PATH', () => [M.KINDS, M.MARK_PATH], { drop: ['tag'] }]);
    C.push(['canSet on −1 … 6, count', () => [range(-1, 6).map(p => range(-1, 6).map(q => M.canSet(p, q))), reach.map(([p, q]) => M.count(p, q))]]);
    C.push(['square and dot: seeded vectors in every cell', () => reach.map(([p, q]) => { const r = prng(100 + 7 * p + q), S = M.world(p, q).S, n = p + q, v = () => Array.from({ length: n }, () => Math.round((r() * 2 - 1) * 8) / 4); return Array.from({ length: 6 }, () => { const u = v(), w = v(); return [M.square(S, u), M.dot(S, u, w)]; }); })]);
    C.push(['world in every cell (without the shape)', () => reach.map(([p, q]) => noShape(M.world(p, q))), dropWorld]);
    C.push(['the shape of four cells', () => [[1, 3], [2, 3], [0, 4], [3, 1], [1, 1]].map(([p, q]) => M.world(p, q).shape)]);
    C.push(['CELLS', () => M.CELLS, { drop: ['aria', 'tag'] }]);
    C.push(['setCounts, advance', () => { const s0 = M.START, out = [M.setCounts(s0, 0, 3), M.setCounts(s0, 3, 3), M.setCounts(s0, 2, 3), M.setCounts(s0, -1, 3)]; let s = { ...s0, t: 0, hold: 0 }; for (let k = 0; k < 600; k++) { s = M.advance(s, 1 / 60); if (k % 5 === 0) out.push(s); } return out; }]);
    C.push(['frontView in every cell at four times (the moving parts)', () => reach.map(([p, q]) => [0, 0.25, 0.7, 1].map(t => pick(M.frontView({ p, q, t, hold: 0 }), ['t', 'dots', 'stuck', 'op', 'tText', 'pMinusOff', 'pPlusOff', 'qMinusOff', 'qPlusOff'])))]);
    C.push(['frontView: the guide and the fade', () => [[1, 3], [2, 3], [0, 4], [1, 1], [3, 2]].map(([p, q]) => [M.frontView({ p, q, t: 0.7, hold: 0 }).guide, M.frontView({ p, q, t: 1, hold: 0.4 }).op])]);
    C.push(['roots of the quadratic', () => [[1, 0.5, -1], [1, 2, 1], [1, 0, 1], [0, 0, 1], [0, 1, 2], [-1, 0.3, 0.2], [2, -1, 0.5]].map(([a, b, c]) => M.roots(a, b, c))]);
    C.push(['proj, sigLabel', () => [range(-1, 1, 0.5).map(x => M.proj(x, 0.3, -x)), M.SIGS3.map(M.sigLabel)]]);
    for (let si = 0; si < 4; si++) C.push([`coneView of ${['Cl(1,2)', 'Cl(2,1)', 'Cl(3,0)', 'Cl(0,3)'][si]} at six tilts`, () => range(0, 5).map(ki => M.coneView(si, ki)), { drop: ['line', 'alt', 'status', 'switchAlt', 'tag'] }]);
    C.push(['pluck and height', () => [range(-1, 1, 0.125).map(M.pluck), range(-3, 3, 0.25).map(x => range(0, 2.4, 0.6).map(t => M.height(x, t)))]]);
    C.push(['GHOST, BANDS, LIGHT', () => [M.GHOST, M.BANDS, M.LIGHT]]);
    C.push(['stringView at every time (without the path)', () => range(0, M.T10_MAX).map(t10 => Object.fromEntries(Object.entries(M.stringView(t10)).filter(([k]) => k !== 'path'))), { drop: ['line', 'alt', 'stAlt'] }]);
    C.push(['stringView: the path at four times', () => [0, 6, 12, 24].map(t10 => M.stringView(t10).path)]);
    C.push(['tickX, stX, stY', () => [range(-3, 3).map(M.tickX), range(-3, 3).map(M.stX), range(0, 2.4, 0.4).map(M.stY)]]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ leaf 7, fall
  fall(M) {
    const C = [], vs = range(M.V_MIN, M.V_MAX), dropFront = { drop: ['status', 'alt', 'dialAlt', 'dialSmall', 'say'] };
    C.push(['constants', () => [M.M_FRONT, M.V_MIN, M.V_MAX, M.V_HORIZON, M.R_MIN, M.R_MAX, M.H_FRAC, M.THUMB, M.FIG, M.R_AX, M.T_TOP, M.T_LOW, M.R_START, M.DT_RAY, M.R_STOP, M.CONE_H, M.PROBE_H, M.DIAL, M.ZONE_ANG,
      M.START, M.FALL_SPEED, M.HOLD, M.DT_FALL, M.GV_MIN, M.GV_MAX, M.MP, M.SPACE_WEDGE, M.TIME_WEDGE, M.LIGHT_END, M.MV_MIN, M.MV_MAX, M.PH, M.PHYS_TICKS]]);
    C.push(['STATES, stateOf', () => [M.STATES, [0, 0.5, 1, 1.5].map(M.stateOf)], { drop: ['say'] }]);
    C.push(['gOf, slope, rOfV, vOfR', () => vs.map(v => { const r = M.rOfV(v); return [M.gOf(r), M.slope(r, 'out'), M.slope(r, 'inn'), M.slope(r, 'rain'), M.vOfR(r), M.gOf(r, 0.3)]; })]);
    C.push(['hAt, frontTrack', () => [[-5, 0, 5].map(M.hAt), M.frontTrack('A', 'B', 'C')]]);
    C.push(['px, py, toPath', () => [range(0, 3, 0.5).map(M.px), range(0, 3, 0.5).map(M.py), M.toPath([[0.5, 0.1], [1, 0.2], [2, 3]])]]);
    C.push(['rainT, RAIN_PTS, RAIN_PATH', () => [vs.map(v => M.rainT(M.rOfV(v))), M.RAIN_PTS, M.RAIN_PATH]]);
    C.push(['rk4 steps', () => vs.map(v => ['out', 'inn', 'rain'].map(k => M.rk4(M.rOfV(v), 0.01, k)))]);
    C.push(['traceRay from the drop at every distance', () => vs.map(v => { const r = M.rOfV(v), t = M.rainT(r); return [M.traceRay(r, t, 'out'), M.traceRay(r, t, 'inn')]; })]);
    C.push(['cone, conePts, CONES', () => [vs.map(v => M.cone(M.rOfV(v), 0.5, 0.3)), M.CONES, M.CONES.map(M.conePts)]]);
    C.push(['arrowTip', () => [[[0, 0], [10, 10]], [[5, 5], [5, 30]], [[3, 4], [3, 4]]].map(([p, q]) => [M.arrowTip(p, q), M.arrowTip(p, q, 10, 4.5)])]);
    C.push(['dial', () => [range(0, 1.2, 0.1).map(M.dialAng), range(0, Math.PI, 0.5).map(a => M.dialPt(a)), M.dialArc(Math.PI, 0.7), M.DIAL_TICKS]]);
    C.push(['advance: a whole fall, the wait and the new start', () => { let s = { ...M.START }; const out = []; for (let k = 0; k < 400; k++) { s = M.advance(s, 1 / 60); if (k % 4 === 0) out.push(s); } return out; }]);
    C.push(['setDistance and frontView at every distance', () => vs.map(v => { const s = M.setDistance(v); return [s, M.frontView(s)]; }), dropFront]);
    C.push(['frontView while falling', () => { let s = { ...M.START }; const out = []; for (let k = 0; k < 300; k += 1) { s = M.advance(s, 1 / 60); if (k % 25 === 0) out.push(M.frontView(s)); } return out; }, dropFront]);
    C.push(['holdSquare, pairXT', () => range(0, 2, 0.05).map(g => [M.holdSquare(g), M.pairXT(g)])]);
    C.push(['mx, my, sqX', () => [range(0, 3, 0.5).map(M.mx), range(0, 3, 0.5).map(M.my), range(-1, 3, 0.5).map(M.sqX)]]);
    C.push(['mathView at every g', () => range(M.GV_MIN, M.GV_MAX).map(M.mathView), { drop: ['line', 'alt'], add: ['readout'] }]);
    C.push(['qx, qy, newtonSpeed', () => [range(0, 10, 2).map(M.qx), range(0, 1.6, 0.4).map(M.qy), range(0.2, 10, 0.4).map(r => M.newtonSpeed(0.75, r))]]);
    C.push(['physView at every pull', () => range(M.MV_MIN, M.MV_MAX).map(M.physView), { drop: ['line', 'alt'], add: ['readout'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ leaf 8, roots
  roots(M) {
    const C = [], FAMS = ['two', 'half', 'all'], ids = range(0, 239);
    C.push(['constants', () => [M.N, M.MINUS, M.COUNT, M.START_SEL, M.START, M.TURN_TO, M.CX, M.CY, M.RO, M.MARK, M.COUNT_TIME, M.DET_TOP, M.E_MIN, M.E_MAX, M.ROOT_CAP, M.START_N, M.BALLS, M.WALL_STEP, M.PERIOD, M.LEG, M.START_BALL, M.WX, M.WY, M.PATH, M.SIMPLE]]);
    C.push(['ROOTS', () => M.ROOTS]);
    C.push(['idOf', () => [...M.ROOTS.map(r => M.idOf(r.v)), M.idOf([1, 1, 1, 1, 1, 1, 1, 1]), M.idOf([0, 0, 0, 0, 0, 0, 0, 0])]]);
    C.push(['dotTrue, mirrorFull on seeded pairs', () => { const r = prng(240), out = []; for (let k = 0; k < 300; k++) { const a = M.ROOTS[pint(r, 0, 239)].v, b = M.ROOTS[pint(r, 0, 239)].v; out.push([M.dotTrue(a, b), M.mirrorFull(a, b)]); } return out; }]);
    C.push(['product on seeded pairs', () => { const r = prng(241), sp = x => x.map((c, k) => [1 << k, c]).filter(([, c]) => c), out = []; for (let k = 0; k < 60; k++) { const a = sp(M.ROOTS[pint(r, 0, 239)].v), b = sp(M.ROOTS[pint(r, 0, 239)].v), P = M.product(a, b); out.push([P, M.product(P, a)]); } return out; }]);
    C.push(['coxeter', () => [M.coxeter([1, 1.37, 1.74, 2.11, 2.48, 2.85, 3.22, 3.59]), M.coxeter([2, 0, 0, 0, 0, 0, 0, 0]), M.coxeter(M.ROOTS[17].v)]]);
    C.push(['shadow', () => M.shadow()]);
    C.push(['cellText, cellsOf, listOf', () => [[-2, -1, 0, 1, 2].map(M.cellText), M.ROOTS.filter((_, i) => i % 9 === 0).map(r => [M.cellsOf(r.v), M.listOf(r.v)])]]);
    C.push(['inFam', () => FAMS.map(f => ids.map(id => M.inFam(id, f)))]);
    C.push(['nearest: seeded taps', () => { const r = prng(242); return Array.from({ length: 300 }, (_, k) => { const f = FAMS[k % 3], x = r() * 400, y = r() * 400; return [M.nearest(f, x, y), M.tapAt({ ...M.START, fam: f }, x, y)]; }); }]);
    C.push(['pick and tick', () => FAMS.map(f => { let s = M.pick(M.START, f); const out = [s, M.pick(M.START, f, true)]; for (let k = 0; k < 40; k++) { s = M.tick(s, 0.05); out.push(s); } return [out, [0, 57, 111, 112, 200, 239].map(id => M.pick({ ...M.START, sel: id }, f))]; })]);
    C.push(['stepSel from every arrow, every family, every key', () => FAMS.map(f => ids.filter(id => M.inFam(id, f)).map(id => ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter'].map(k => M.stepSel({ ...M.START, fam: f, sel: id }, k).sel)))]);
    C.push(['seeView, every family', () => FAMS.map(f => [M.seeView({ ...M.START, fam: f, shown: M.COUNT[f] }), M.seeView({ ...M.START, fam: f, shown: 17 })]), { drop: ['line', 'status', 'alt'] }]);
    C.push(['seeView of every arrow (its readouts)', () => ids.map(id => { const v = M.seeView({ ...M.START, sel: id }); return [v.cells, v.list, v.kind, v.arrow, v.sel, v.counter, v.counterWord, v.done]; })]);
    C.push(['choose, countView', () => [range(0, 8).map(k => M.choose(8, k)), M.countView(), M.countView([2, 5])], { drop: ['alt', 'capTwo', 'capHalf'] }]);
    C.push(['cartanE, detE, rootCount, eSeries', () => [range(3, 9).map(n => [M.cartanE(n), M.detE(n), M.rootCount(n)]), M.eSeries()]]);
    C.push(['canN, stopView', () => [range(2, 10).map(M.canN), range(3, 9).map(M.stopView)], { drop: ['line', 'alt', 'stripAlt'] }]);
    C.push(['wallTally of every wall', () => ids.map(w => M.wallTally(w))]);
    C.push(['ballOf, nextWall, setBall, rollOn', () => [ids.map(w => ['along', 'angle', 'head'].map(k => M.ballOf(w, k))), M.nextWall(M.START_BALL), M.setBall(M.START_BALL, 'head'), [0.1, 0.5, 2.9].map(dt => M.rollOn(M.START_BALL, dt))]]);
    C.push(['billiardView for every wall and every ball', () => ids.map(w => ['along', 'angle', 'head'].map(kind => M.billiardView({ w, kind, t: 0.5 }))), { drop: ['say', 'alt'] }]);
    C.push(['billiardView, rolling', () => { let s = { ...M.START_BALL }; const out = []; for (let k = 0; k < 80; k++) { s = M.rollOn(s, 0.037); out.push(M.billiardView(s)); } return out; }, { drop: ['say', 'alt'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ loose leaf: seats
  seats(M) {
    const C = [], pats = range(0, 7), MODES = ['bits', 'numbers', 'primes'];
    C.push(['constants', () => [M.SEATS, M.PATTERNS, M.PLACES, M.SEAT_PRIMES, M.MODES, M.START, M.LAYER_Y, M.NODE, M.START_MATH, M.SEAT_OPTIONS, M.SIZES, M.START_TRACE, M.SIZE_OPTIONS, M.ENERGY, M.LEVEL_Y, M.START_ATOM]]);
    C.push(['UP, DOWN, EMPTY, STATES', () => [M.UP, M.DOWN, M.EMPTY, M.STATES]]);
    C.push(['times of the generators', () => [...M.UP, ...M.DOWN].map(x => [...M.UP, ...M.DOWN].map(y => M.times(x, y)))]);
    C.push(['patternOfBlade, coords, matrixOf', () => [range(0, 63).map(M.patternOfBlade), M.STATES.map(M.coords), range(0, 63).map(L => { const x = new Float64Array(64); x[L] = 1; return M.matrixOf(x); })]]);
    C.push(['ADD, TAKE, SQUARES, NUMBER, COUNTS, EDGES, CORNERS', () => [M.ADD, M.TAKE, M.SQUARES, M.NUMBER, M.COUNTS, M.EDGES, M.CORNERS]]);
    C.push(['moveOn, particles, isFull', () => pats.map(a => [M.particles(a), range(0, 2).map(k => [M.moveOn(a, k, 'add'), M.moveOn(a, k, 'take'), M.isFull(a, k)])])]);
    C.push(['the names: stepByName, signByName, nameIn, longName', () => pats.map(a => { const name = [2, 3, 5].reduce((t, p, k) => (a >> k & 1 ? t * p : t), 1); return [MODES.map(m => [M.nameIn(a, m), M.longName(a, m)]), range(0, 2).map(k => [M.stepByName(name, k, 'add'), M.stepByName(name, k, 'take'), M.moveOn(a, k, 'add') ? M.signByName(name, k) : null])]; })]);
    C.push(['press from every pattern, every seat, both ways, every naming', () => pats.map(a => MODES.map(mode => range(0, 2).map(k => ['add', 'take'].map(op => { const s = M.press({ ...M.START, a, mode, shake: 5 }, k, op); return [s, M.readout(s)]; })))), { drop: ['note'] }]);
    C.push(['readout before a press', () => pats.map(a => MODES.map(mode => M.readout({ ...M.START, a, mode }))), { drop: ['note'] }]);
    C.push(['rename', () => [M.rename(M.START, 'letters'), M.rename(M.START, 'primes')]]);
    C.push(['cornerOf, stopShort', () => [pats.map(M.cornerOf), [[100, 52, 170, 116], [170, 244, 100, 180], [240, 180, 240, 116]].map(a => M.stopShort(...a))]]);
    C.push(['frontView after every press (one naming each)', () => pats.map(a => range(0, 2).map(k => ['add', 'take'].map(op => M.frontView(M.press({ ...M.START, a, mode: MODES[(a + k) % 3], shake: 5 }, k, op))))), { drop: ['addLabel', 'takeLabel', 'caption', 'alt', 'note'] }]);
    C.push(['a seeded walk of 300 presses and renames', () => { const r = prng(99); let s = M.START; const out = []; for (let t = 0; t < 300; t++) { const x = r(); if (x < 0.12) s = M.rename(s, MODES[pint(r, 0, 2)]); else s = M.press(s, pint(r, 0, 2), x < 0.6 ? 'add' : 'take'); out.push(s); } return out; }]);
    C.push(['mathView of every seat in every naming', () => range(0, 2).map(k => MODES.map(mode => M.mathView({ k, mode }))), { drop: ['land', 'rule', 'alt', 'sqAlt'] }]);
    C.push(['commutatorDiag, table01, nextTable, traceView', () => M.SIZES.map(n => range(1, 25).map(seed => [M.table01(n, seed), M.nextTable({ n, seed }), M.traceView({ n, seed })])), { drop: ['alt'] }]);
    C.push(['lowestFor: seeded energies', () => { const r = prng(4242); return Array.from({ length: 60 }, () => { const E = [r(), r(), r()].map(x => 0.1 + 10 * x).sort((x, y) => x - y); return range(0, 3).map(k => M.lowestFor(k, E)); }); }]);
    C.push(['canAddAny, atomMore, atomLess, atomView', () => [pats.map(M.canAddAny), range(0, 3).map(k => [M.atomMore({ k, over: false }), M.atomLess({ k, over: false }), M.atomView({ k, over: false }), M.atomView({ k, over: true })])], { drop: ['line', 'alt', 'countsLine'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ loose leaf: magnets
  magnets(M) {
    const C = [], D = ['up', 'right', 'down', 'left'];
    C.push(['constants', () => [M.SQ, M.R_MAX, M.DIRS, M.ARROW, M.DEG, M.IN_DIR, M.LANES, M.SPEED, M.START, M.TH_MAX, M.TH_STEP, M.RV_STEPS, M.RV_MAX, M.START_BALL, M.BALL, M.PAIR, M.AXIS, M.START_IN, M.IN_CHOICES]]);
    C.push(['vec, isState, state, projector, passPart, through, arrowOf: seeded beams', () => {
      const r = prng(303), unit = () => { const z = 2 * r() - 1, ph = 2 * Math.PI * r(), s = Math.sqrt(1 - z * z); return [s * Math.cos(ph), s * Math.sin(ph), z]; }, out = [];
      for (let k = 0; k < 120; k++) { const u = unit(), w = unit(), rr = r() * 1.6, v = w.map(x => x * rr), st = M.state(v); out.push([M.vec(v), M.isState(v), st, M.projector(u), st && M.passPart(st, u), st && M.through(st, u), st && M.arrowOf(st)]); }
      return out;
    }]);
    C.push(['passPart between the four directions', () => D.map(a => D.map(b => M.passPart(M.state(M.ARROW[a]), M.ARROW[b])))]);
    C.push(['dirOf, pct', () => [[[0, 0, 1], [1, 0, 0], [0, 0, -1], [-1, 0, 0], [0, 1, 0], [0.5, 0, 0.5]].map(M.dirOf), [1, 0.5, 0.25, 0.125, 0, 1 / 3].map(M.pct)]]);
    C.push(['chain of every row of three magnets', () => D.map(a => D.map(b => D.map(c => M.chain([a, b, c]))))]);
    C.push(['setDir, turn: a seeded run of 400 turns', () => { const r = prng(404); let s = M.START; const out = []; for (let t = 0; t < 400; t++) { const i = pint(r, 0, 2), x = r(); s = x < 0.4 ? M.turn(s, i, 1) : x < 0.7 ? M.turn(s, i, -1) : M.setDir(s, i, D[pint(r, 0, 3)]); out.push(s); } return [out, M.setDir(M.START, 3, 'up'), M.setDir(M.START, 0, 'sideways')]; }]);
    C.push(['advance', () => [0, 0.3, 0.99].map(p => M.advance(p, 0.02))]);
    C.push(['frontView of every row of three magnets', () => D.map(a => D.map(b => D.map(c => { let s = M.START; [a, b, c].forEach((d, i) => { s = M.setDir(s, i, d); }); return M.frontView(s); }))), { drop: ['line', 'alt', 'aria'], add: ['words', 'stop'] }]);
    C.push(['canBall, ballView at every position of the two controls', () => range(0, 180, 5).map(th => range(0, 20).map(rv => M.ballView({ th, rv }))), { drop: ['alt', 'rEnds'], add: ['rEnds'] }]);
    C.push(['ballView outside the ball', () => [[30, 21], [30, 40], [185, 10], [-5, 10], [30, -1]].map(([th, rv]) => [M.canBall({ th, rv }), M.ballView({ th, rv })])]);
    C.push(['bladeText, mvText', () => [range(0, 7).map(M.bladeText), [Float64Array.of(0.25, 0.25, 0, 0.25, 0, 0.25, 0, 0), Float64Array.of(0.25, 0.25, 0, 0.25, 0, -0.25, 0, 0), Float64Array.of(1, 0, 0, 0, 0, 0, 0, 0), Float64Array.of(0.3, -0.7, 0, 0, 0.1, 0, 0, 0), new Float64Array(8)].map(M.mvText)]]);
    C.push(['ordersView for every beam', () => D.map(M.ordersView), { drop: ['line', 'alt'], add: ['sign31'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ loose leaf: springs
  springs(M) {
    const C = [], TIMES = [0, 0.37, 1.1, 2.5, 4.2, 6];
    C.push(['constants', () => [M.N, M.SIZES, M.AMP, M.SPEED, M.GEO, M.VIEW, M.START, M.MATH, M.PLUCKED, M.PHYS, M.PITCH_START]]);
    C.push(['bits, onesText, sign, pattern, omega2', () => range(1, 5).map(n => range(0, (1 << n) - 1).map(s => [M.bits(s, n), M.onesText(s % 6), M.pattern(n, s), M.omega2(s), range(0, (1 << n) - 1).map(x => M.sign(s, x))]))]);
    C.push(['springs, laplacian, stretched, levels, pascal', () => range(0, 5).map(n => [M.springs(n), n <= 4 ? M.laplacian(n) : null, range(0, (1 << n) - 1).map(s => M.stretched(n, s)), M.levels(n), M.pascal(n)])]);
    C.push(['eigenvalues', () => [2, 3, 4].map(M.eigenvalues)]);
    C.push(['coeffs and motion from labels, plucks and seeded starts', () => { const r = prng(707), out = []; for (const n of [2, 3, 4]) { const starts = [...range(0, (1 << n) - 1).map(s => M.labelStart(n, s)), ...range(0, (1 << n) - 1).map(c => M.pluckStart(n, c)), ...Array.from({ length: 3 }, () => ({ x0: Array.from({ length: 1 << n }, () => 2 * r() - 1), v0: Array.from({ length: 1 << n }, () => 2 * r() - 1) }))]; for (const st of starts) out.push([M.coeffs(n, st.x0, st.v0), TIMES.map(t => M.motion(n, st.x0, st.v0, t))]); } return out; }]);
    C.push(['potential, kinetic', () => { const r = prng(708); return Array.from({ length: 20 }, () => { const x = Array.from({ length: 8 }, () => r() - 0.5), v = Array.from({ length: 8 }, () => r() - 0.5); return [M.potential(3, x), M.kinetic(v)]; }); }]);
    C.push(['speedText, speedShort, speedSym, fracOf', () => [range(0, 12).map(w2 => [M.speedText(w2), M.speedShort(w2), M.speedSym(w2)]), [0, 1 / 8, 3 / 8, 0.25, 1 / 3, 0.123456, 1, 2.5].map(M.fracOf)]]);
    C.push(['restOf, cornerName, coil', () => [range(0, 7).map(c => [M.restOf(c), M.cornerName(c)]), M.coil(10, 20, 160, 20), M.coil(42, 278, 117, 221, 4, 3, 0.2)]]);
    C.push(['pickLabel, pluckAt, advance, startOf', () => [range(0, 7).map(s => M.pickLabel(M.START, s)), range(0, 7).map(c => M.pluckAt(M.START, c)), M.advance({ ...M.START, t: 1.25 }, 0.5), M.startOf(M.START), M.startOf(M.pluckAt(M.START, 3))]]);
    C.push(['groups', () => [M.START, M.pluckAt(M.START, 3), M.pickLabel(M.START, 7)].map(M.groups), { drop: ['aria'] }]);
    C.push(['frontView of every label and every pluck at six times', () => [...range(0, 7).map(s => M.pickLabel(M.START, s)), ...range(0, 7).map(c => M.pluckAt(M.START, c))].map(st => TIMES.map(t => M.frontView({ ...st, t }))), { drop: ['aria', 'status', 'alt'] }]);
    C.push(['PASCAL, mathView', () => [M.PASCAL, M.SIZES.map(M.mathView)], { drop: ['aria', 'alt'] }]);
    C.push(['traceY, pitches, physView', () => [range(-1, 1, 0.25).map(M.traceY), M.pitches(), range(0, 3).map(M.physView)], { drop: ['caption', 'alt'] }]);
    return C;
  },

  // ------------------------------------------------------------------------------------------------ loose leaf: charge
  charge(M) {
    const C = [], ks = range(0, 20), kv = range(M.KV[0], M.KV[1]), kr = range(0, M.KR_MAX);
    C.push(['constants', () => [M.MOVES, M.SQ, M.CLIFF, M.NAMES, M.BLADE, M.SIGN, M.LIGHT, M.K_MAX, M.START_AT, M.V0, M.DIR0, M.W, M.H, M.K0, M.H_TAU, M.MAX_STEPS, M.T_RUN, M.DT_SHOW, M.RATE, M.PRESETS, M.START, M.MAP, M.MAP_START, M.OBSERVERS, M.MAP_LABELS, M.CIRCLE_B, M.KV, M.KV_START, M.KR_MAX, M.KR_START, M.trackR, M.LIMIT]]);
    C.push(['classOf', () => [-1, -1e-10, 0, 1e-10, 2e-9, 1].map(M.classOf)]);
    C.push(['fieldMV, readField, vecMV, readVec, force, forceMatrix, square, reverse: seeded fields', () => { const r = prng(909), r6 = () => Array.from({ length: 6 }, () => Math.round(r() * 40 - 20) / 8), r4 = () => Array.from({ length: 4 }, () => Math.round(r() * 40 - 20) / 8), out = []; for (let k = 0; k < 60; k++) { const f = r6(), u = r4(), F = M.fieldMV(f); out.push([F, M.readField(F), M.vecMV(u), M.readVec(M.vecMV(u)), M.force(f, u), M.forceMatrix(f), M.square(f), M.reverse(F)]); } return out; }]);
    C.push(['crossed, square, forceMatrix at every field the controls reach', () => ks.map(kE => ks.map(kB => { const f = M.crossed(kE / 10, kB / 10); return [f, M.square(f), M.forceMatrix(f)]; }))]);
    C.push(['gammaOf, speedOf, startState, byTau, byT, step, turnAngle', () => { const M1 = M.forceMatrix(M.crossed(0.6, 1)), s = M.startState(-1, -0.75, 0.6, [-1, 0]); return [[0, 0.3, 0.6, 0.95].map(M.gammaOf), M.speedOf(s), s, M.byTau(M1)(s), M.byT(M1)(s), M.step(s, 0.01, M.byTau(M1)), M.turnAngle(s, M.step(s, 0.5, M.byTau(M1)))]; }]);
    C.push(['presetOf, LEGEND classes, trackE, trackB', () => [ks.map(kE => [0, 10].map(kB => M.presetOf(kE, kB))), M.LEGEND.map(l => l.cls), ks.map(M.trackE), ks.map(M.trackB)]]);
    C.push(['loopOf where B wins (seven fields)', () => [[0, 10], [5, 10], [9, 10], [6, 20], [10, 15], [3, 4], [12, 13]].map(([kE, kB]) => M.loopOf(kE, kB))]);
    C.push(['viewOf at every field', () => ks.map(kE => ks.map(kB => M.viewOf(kE, kB)))]);
    // the runs of the picture: the summary of every field, the whole run of some
    C.push(['frontRun at every field (summary)', () => ks.map(kE => ks.map(kB => { const r = M.frontRun(kE, kB); return [r.kE, r.kB, r.E, r.B, r.cls, r.view, r.zoom, r.pts.length, r.pts[r.pts.length - 1], r.pts[Math.floor(r.pts.length / 2)], r.last, r.steps, r.turns, r.top, r.low, r.dt, r.tEnd, r.periodic, r.left]; }))]);
    C.push(['frontRun of ten fields (whole)', () => [[0, 10], [5, 10], [10, 10], [12, 10], [10, 0], [0, 0], [20, 20], [3, 17], [19, 2], [0, 20]].map(([kE, kB]) => M.frontRun(kE, kB))]);
    C.push(['toPx, pathOf', () => { const r = M.frontRun(6, 10); return [M.toPx(r.view, 1, 2), M.pathOf(r)]; }]);
    C.push(['advance: a run played', () => { const r = M.frontRun(5, 10); let s = { ...M.START, kE: 5, kB: 10 }; const out = []; for (let k = 0; k < 2000; k++) { s = M.advance(s, r, 1 / 60); if (k % 10 === 0) out.push(s); } return out; }]);
    C.push(['setField, speedText, glyphs', () => [M.setField(M.START, 6, 10), [0, 0.5, 0.994, 0.996, 0.9999, 1].map(M.speedText), ks.map(kE => M.glyphs(kE, 20 - kE))]]);
    C.push(['sayField at every field', () => ks.map(kE => ks.map(kB => M.sayField(kE, kB))), { drop: ['say', 'lead'], add: ['lead'] }]);
    C.push(['frontView at three times of every fifth field', () => ks.filter(k => k % 5 === 0).map(kE => ks.filter(k => k % 5 === 0).map(kB => { const r = M.frontRun(kE, kB), p = M.pathOf(r); return [0, r.tEnd / 3, r.tEnd / 2].map(t => M.frontView({ ...M.START, kE, kB, t }, r, p)); })), { drop: ['say', 'lead', 'alt', 'gaugeAlt'], add: ['lead'] }]);
    C.push(['observerRotor, seenBy', () => { const r = prng(910), out = []; for (const w of [-0.9, -0.6, -0.3, 0, 0.25, 0.3, 0.6, 0.8, 0.95]) { const f = Array.from({ length: 6 }, () => Math.round(r() * 40 - 20) / 8); out.push([M.observerRotor(w), M.seenBy(f, w)]); } return out; }]);
    C.push(['mapView at every field', () => ks.map(kE => ks.map(kB => M.mapView(kE, kB))), { drop: ['cap', 'alt'] }]);
    C.push(['circleRun at every speed', () => kv.map(k => { const c = M.circleRun(k); return { ...c, states: [c.states.length, c.states[c.states.length - 1]] }; }), { drop: ['line', 'alt'] }]);
    C.push(['driftRun at every ratio', () => kr.map(k => { const d = M.driftRun(k); return { ...d, states: [d.states.length, d.states[d.states.length - 1]] }; }), { drop: ['line', 'alt'] }]);
    C.push(['limitRun', () => { const l = M.limitRun(); return { ...l, states: [l.states.length, l.states[l.states.length - 1]] }; }, { drop: ['line', 'alt'] }]);
    return C;
  }
};
import { cases as mirrors } from './cases.mirrors.mjs'; CASES['mirrors'] = mirrors;
import { cases as halfTurns } from './cases.half-turns.mjs';
CASES['half-turns'] = halfTurns;
import { cases as bands } from './cases.bands.mjs';
CASES['bands'] = bands;
import { cases as field } from './cases.field.mjs';
CASES['field'] = field;
import { cases as steps } from './cases.steps.mjs';
CASES['steps'] = steps;
import { cases as cube } from './cases.cube.mjs';
CASES['cube'] = cube;
import { cases as electron } from './cases.electron.mjs';
CASES['electron'] = electron;
import { cases as tumbling } from './cases.tumbling.mjs';
CASES['tumbling'] = tumbling;
import { cases as hung } from './cases.hung.mjs';
CASES['hung'] = hung;
