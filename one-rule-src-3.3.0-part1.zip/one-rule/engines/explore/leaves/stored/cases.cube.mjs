// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.cube.mjs — the fixed inputs of the loose leaf Cube (the form of cases.mjs, which appends them as CASES.cube): every rung, plane,
// amount of the range and mirror choice the front reaches, every pair of corners and naming of the mathematician, every speed of the physicist, and seeded walks
// of the controls (prng of round 2). drop names the keys of Octavo's output that the port does not carry (its sentences), add the keys the port returns instead.
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const FRONT = { drop: ['status', 'alt', 'weightCap', 'weightAlt', 'aria', 'label'], add: ['interval', 'tspan', 'amountText', 'planeName', 'others', 'counts'] };
const states = (M, n, every = 1) => {
  const out = [];
  for (const m of M.planesOf(n)) {
    const turn = M.kindOf(n, m) === 'turn', vals = M.stepsOf(turn ? M.ANGLE : M.SPEED).filter((_, k) => k % every === 0);
    for (const v of vals) for (const once of [false, true]) out.push({ ...M.START, n, plane: { ...M.START.plane, [n]: m }, deg: turn ? v : M.START.deg, sv: turn ? M.START.sv : v, once });
  }
  return out;
};

export function cases(M) {
  const C = [];
  C.push(['constants', () => [M.AXES, M.RUNG_NS, M.ANGLE, M.SPEED, M.START, M.OBJECTS, M.CAMERA, M.VIEW, M.WMAX, M.CHOOSER, M.CHOOSER_ASPECT, M.BACK_N, M.START_PICK, M.PASS, M.START_PASS, M.PASS_VIEW, M.CUBE_EDGES, M.MIRROR_CHOICE]]);
  C.push(['RUNG_CHIPS', () => M.RUNG_CHIPS, { drop: ['label'] }]);
  C.push(['letters, axesIn, sqOf, halfCube, opposite, planesOf, squareOf, kindOf, colorOf', () => [2, 3, 4].map(n => [M.sqOf(n), M.halfCube(n), M.planesOf(n), Array.from({ length: 1 << n }, (_, m) => [M.letters(m), M.axesIn(m), M.opposite(n, m), M.squareOf(n, m), M.kindOf(n, m), M.colorOf(M.kindOf(n, m))])])]);
  C.push(['vecOf, coordsOf, interval: seeded points', () => { const r = prng(1212), out = []; for (const n of [2, 3, 4]) for (let k = 0; k < 40; k++) { const p = Array.from({ length: n }, () => Math.round(r() * 64 - 32) / 16), q = Array.from({ length: n }, () => Math.round(r() * 64 - 32) / 16); out.push([M.vecOf(n, p), M.coordsOf(n, M.vecOf(n, p)), M.interval(n, p, q)]); } return out; }]);
  C.push(['rapidity, stepsOf', () => [M.stepsOf(M.ANGLE), M.stepsOf(M.SPEED), M.stepsOf(M.PASS), M.stepsOf(M.SPEED).map(v => M.rapidity(v / 100))]]);
  C.push(['mirrorsOf and moveOf at every plane and amount of the range', () => [2, 3, 4].map(n => M.planesOf(n).map(m => (M.kindOf(n, m) === 'turn' ? M.stepsOf(M.ANGLE).map(d => d * Math.PI / 180) : M.stepsOf(M.SPEED).map(v => v / 100)).map(a => [M.mirrorsOf(n, m, a), M.moveOf(n, m, a)])))]);
  C.push(['reflect, sandwich, imageOf on the points of each rung', () => [2, 3, 4].map(n => M.planesOf(n).map(m => [-0.6, 0.35, 0.8, 1.9].map(x => { const a = M.kindOf(n, m) === 'turn' ? x : x / 2.4, mir = M.mirrorsOf(n, m, a), mv = M.moveOf(n, m, a); return M.OBJECTS[n].pts.map(p => [M.reflect(n, mir.a, p), M.reflect(n, mir.b, p), M.sandwich(n, mv, p), M.imageOf(n, m, a, true, p), M.imageOf(n, m, a, false, p)]); })))]);
  C.push(['project, pathOf', () => [2, 3, 4].map(n => { const pts = M.OBJECTS[n].pts.map(p => p.map((c, i) => c + 0.25 * i - 0.4)); return [pts.map(p => M.project(n, p)), M.pathOf(pts.map(p => M.project(n, p)))]; })]);
  C.push(['chooserOf at every rung and plane', () => [2, 3, 4].map(n => M.planesOf(n).map(m => M.chooserOf(n, m))), { drop: ['aria', 'alt'], add: ['counts'] }]);
  C.push(['frontView: 2D at every speed, once and twice', () => states(M, 2).map(M.frontView), FRONT]);
  C.push(['frontView: 3D at every plane and amount, once and twice', () => states(M, 3).map(M.frontView), FRONT]);
  C.push(['frontView: 4D at every plane and every third amount, once and twice', () => states(M, 4, 3).map(M.frontView), FRONT]);
  C.push(['frontView: the start', () => M.frontView(M.START), FRONT]);
  C.push(['setRung, pickPlane, setAmount, setOnce, planeOf, amountOf: a seeded walk of 300 presses', () => {
    const r = prng(1313), out = []; let s = M.START;
    for (let t = 0; t < 300; t++) {
      const x = r(); let next;
      if (x < 0.2) next = M.setRung(s, pint(r, 1, 5)); else if (x < 0.45) next = M.pickPlane(s, pint(r, 0, 15)); else if (x < 0.8) next = M.setAmount(s, pint(r, -200, 200)); else next = M.setOnce(s, r() < 0.5);
      out.push([next, M.planeOf(next), M.amountOf(next.n, M.planeOf(next), next)]); s = next;
    }
    return out;
  }]);
  C.push(['nameLine at every pair of corners and naming', () => ['bits', 'numbers', 'primes'].map(mode => M.halfCube(4).corners.map(a => M.halfCube(4).corners.map(b => M.nameLine(a, b, mode))))]);
  C.push(['productView at every pair of corners and naming', () => ['bits', 'numbers', 'primes'].map(names => M.halfCube(4).corners.map(a => M.halfCube(4).corners.map(b => M.productView({ a, b, names })))), { drop: ['kindLine', 'evenLine', 'alt', 'aria'], add: ['kinds', 'counts'] }]);
  C.push(['tapCorner, setNames', () => [M.halfCube(4).corners.concat([1, 7, 16]).map(m => M.tapCorner(M.START_PICK, m)), ['bits', 'numbers', 'primes'].map(x => M.setNames(M.START_PICK, x))]]);
  C.push(['passCoords at seeded events', () => { const r = prng(1414), out = []; for (const sp of M.stepsOf(M.PASS)) out.push(Array.from({ length: 4 }, () => { const p = Array.from({ length: 4 }, () => Math.round(r() * 32 - 16) / 8); return [p, M.passCoords(sp / 100, p)]; })); return out; }]);
  C.push(['passView at every speed', () => M.stepsOf(M.PASS).map(M.passView), { drop: ['cellsAlt', 'line', 'keep', 'alt'] }]);
  C.push(['passProject', () => [M.PASS_VIEW.left, M.PASS_VIEW.right].map(o => [[0, 0, 0], [1, 0, 0], [0.6, 1, 1], [0.25, 0.5, 0.75]].map(p => M.passProject(o, p)))]);
  return C;
}
