// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/make_octavo.mjs — writes engines/explore/leaves/stored/<slug>_octavo.json: what Octavo's leaf logic returned on the cases of
// cases.mjs, recorded from the Octavo files before the port (the method of round 2, engines/stored/make_<module>_v15.mjs). The folder is a copy of the Octavo
// base (base/v16 of the hand-off) with the unfinished leaves laid over it (wip/HANDOFF_OCTAVO/wip/<slug>/octavo/leaves/<slug>.logic.js and their tests), the
// state in which the plan re-ran the Octavo tests; the ported modules are never read here.
//   node engines/explore/leaves/stored/make_octavo.mjs <folder> [slug …]        (or OCTAVO_DIR=<folder>)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { CASES } from './cases.mjs';
import { project, record } from './codec.mjs';

const dir = process.argv[2] || process.env.OCTAVO_DIR;
if (!dir) { console.error('usage: node engines/explore/leaves/stored/make_octavo.mjs <folder: the Octavo base with the unfinished leaves laid over it> [slug …]   (or set OCTAVO_DIR)'); process.exit(2); }
const slugs = process.argv.slice(3).length ? process.argv.slice(3) : Object.keys(CASES);
const sha = f => crypto.createHash('sha256').update(fs.readFileSync(path.join(dir, f))).digest('hex');
for (const slug of slugs) {
  const rel = `octavo/leaves/${slug}.logic.js`, M = await import(pathToFileURL(path.join(dir, rel)).href);
  const out = [];
  let negativeZeros = 0, stored = 0, digests = 0;
  for (const [id, fn, opt = {}] of CASES[slug](M)) {
    const r = record(project(fn(), opt.drop));
    negativeZeros += r.negativeZeros; if ('out' in r) stored++; else digests++;
    out.push({ id, ...(opt.drop ? { drop: opt.drop } : {}), ...(opt.add ? { add: opt.add } : {}), ...r });
  }
  const doc = { module: rel, source: 'Octavo V0: the hand-off\'s base (v16) with the unfinished leaves laid over it, before the port to engines/explore/leaves/', sha256: { [rel]: sha(rel), 'labelsEngine.js': sha('labelsEngine.js') }, negativeZeros, cases: out };
  const text = JSON.stringify(doc) + '\n', file = new URL(`./${slug}_octavo.json`, import.meta.url);
  fs.writeFileSync(file, text);
  console.log(`${slug}_octavo.json: ${out.length} cases (${stored} stored whole, ${digests} as digests), ${(text.length / 1024).toFixed(1)} KB, ${negativeZeros} negative zeros in the Octavo outputs`);
}
