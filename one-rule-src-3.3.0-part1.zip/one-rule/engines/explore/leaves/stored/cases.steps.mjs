// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.steps.mjs — the fixed inputs of the shelf leaf "steps", in the form of cases.mjs (which appends them as CASES.steps): run
// once through Octavo's octavo/leaves/steps.logic.js (make_octavo.mjs stores the outputs in steps_octavo.json) and once through the port
// (tests/explore/leaves.steps.test.mjs). The whole state space the controls reach: every piece, direction, drop or add, one step or two, under the three
// names; every back state (12 geometry states, 16 algebra cells, 6 topology edges, the 256 corner flips of the category cube) and a grid of the physicist's
// line. drop names Octavo's sentences that the port does not carry, add the data the port returns instead; `rule` is in both: the formula readout whose words
// became symbols for the bits naming and for a choice that gives nothing, compared by the leaf's own test (its numbers under numbers and primes are held
// here by the cases of ruleLine and roadsRule). The same holds for `change` in phys: Octavo's sentence of that name is dropped at every depth, so the numbers
// box().change and cents.change are compared by the cases of box and by the leaf's own test.
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], pis = range(0, 5), dirs = range(0, 3), ops = ['drop', 'add'], labels = range(0, 15);
  C.push(['constants', () => [M.AXES, M.SQ, M.ALL, M.PIECES, M.PRIMES, M.EVEN, M.MODES, M.START, M.START_PHYS, M.TIME_STEPS, M.WAYS, M.CELL_W, M.LINE, M.PHYS, M.ENDS_PER_EDGE, M.TRIANGLES_PER_EDGE]]);
  C.push(['the 48 choices and the 24 steps', () => [M.CHOICES, M.STEPS]]);
  C.push(['stepOf, holds, flip, letters, word, inEvenHalf, pieceOfMask, labelName on the 16 labels', () => labels.map(v => [dirs.map(a => [M.stepOf(v, a), M.holds(v, a), M.flip(v, a)]), M.letters(v), M.word(v), M.inEvenHalf(v), M.pieceOfMask(v), M.MODES.map(m => M.labelName(v, m))])]);
  C.push(['roads of every piece, both kinds', () => pis.map(pi => ops.map(op => M.roads(pi, op)))]);
  C.push(['sgn', () => [-2, -1, 1, 2].map(M.sgn)]);
  C.push(['ruleLine of the 24 steps under numbers and primes', () => M.STEPS.map(c => ['numbers', 'primes'].map(m => M.ruleLine(c, m)))]);
  C.push(['roadsRule of every piece, both kinds, under numbers and primes', () => pis.map(pi => ops.map(op => ['numbers', 'primes'].map(m => M.roadsRule(M.roads(pi, op), m))))]);
  C.push(['setPiece, setDir, setOp, canStepAgain, stepAgain: a seeded walk of 300 taps', () => {
    const r = prng(6060), out = []; let s = M.START;
    for (let t = 0; t < 300; t++) {
      const x = r(); let next;
      if (x < 0.25) next = M.setPiece(s, pint(r, 0, 5)); else if (x < 0.5) next = M.setDir(s, pint(r, 0, 3)); else if (x < 0.7) next = M.setOp(s, r() < 0.5 ? 'drop' : 'add'); else next = M.stepAgain(s);
      out.push([next, M.canStepAgain(next)]); s = next;
    }
    return out;
  }]);
  // the pictures of the front: the tetrahedron, the cube and the grid
  C.push(['TETRA, CENTRE, placeOf, outward, cornerOut, triangleOf', () => [M.TETRA, M.CENTRE, labels.map(v => (v ? M.placeOf(v) : null)), M.PIECES.map(p => M.outward(p.mask)), dirs.map(M.cornerOut), labels.filter(v => v && v !== M.ALL).map(M.triangleOf)]]);
  C.push(['tetraDrawing of every piece, both kinds, one and two targets', () => pis.map(pi => ops.map(op => { const R = M.roads(pi, op); return [M.tetraDrawing(pi, op, []), M.tetraDrawing(pi, op, R.list.map(x => ({ to: x.mid, sign: x.sign })))]; }))]);
  C.push(['CUBE, cubeAt, CUBE_EDGES, GRID', () => [M.CUBE, labels.map(M.cubeAt), M.CUBE_EDGES, M.GRID]]);
  for (const mode of ['bits', 'numbers', 'primes']) for (const two of [false, true]) {
    C.push([`front under ${mode}, ${two ? 'after Step again' : 'one step'}, at every piece, direction, drop and add`, () => pis.map(pi => dirs.map(a => ops.map(op => M.front({ pi, a, op, two }, mode)))), { drop: ['status', 'key', 'tetraAlt', 'cubeAlt', 'gridAlt', 'rule'], add: ['term', 'eq', 'rule'] }]);
  }
  // the back, the mathematician
  C.push(['geometry of every piece, down and up', () => pis.map(pi => ['down', 'up'].map(w => M.geometry(pi, w))), { drop: ['line', 'counter', 'alt'], add: ['pieces', 'per', 'cancel'] }]);
  C.push(['EPS, blade, ALGEBRA, cellAt, WAVE', () => [M.EPS, labels.map(M.blade), M.ALGEBRA, dirs.map(a => dirs.map(b => M.cellAt(a, b))), M.WAVE]]);
  C.push(['algebra of the 16 cells', () => dirs.map(a => dirs.map(b => M.algebra(a, b))), { drop: ['line'], add: ['formula'] }]);
  C.push(['FACES, boundaryOf, boundaryMatrix, D1, D2, D3, D1D2, D2D3, EULER, eulerLine', () => [M.FACES, labels.map(M.boundaryOf), [1, 2, 3].map(M.boundaryMatrix), M.D1, M.D2, M.D3, M.D1D2, M.D2D3, M.EULER, M.eulerLine]]);
  C.push(['ORIENT, walkOf, dirAlong', () => [M.ORIENT, M.FACES[2].map(M.walkOf), M.FACES[2].map(t => M.PIECES.map(p => M.dirAlong(t, p.mask)))]]);
  C.push(['topology of every piece', () => pis.map(M.topology), { drop: ['line', 'alt'], add: ['opposite'] }]);
  C.push(['CAT_N, ARROWS, SQUARES, CAT_COUNT, CAT, catAt, CAT_SHOWN', () => [M.CAT_N, M.ARROWS, M.SQUARES, M.CAT_COUNT, M.CAT, range(0, 7).map(M.catAt), M.CAT_SHOWN]]);
  C.push(['renamed, squareRoads, cancels, toggleCorner over the 256 corner flips', () => range(0, 255).map(f => { const s = M.renamed(f); return [s, M.SQUARES.map(q => M.squareRoads(q, s)), M.cancels(s), M.toggleCorner(f, f % 8)]; })]);
  C.push(['category of the 256 corner flips', () => range(0, 255).map(M.category), { drop: ['counter', 'alt'], add: ['good', 'flips'] }]);
  // the back, the physicist
  C.push(['hump, humpSlope, fieldE, current, cellCharge on a grid', () => [range(-2, 2, 0.125).map(s => [M.hump(s), M.humpSlope(s)]), range(0, 8, 0.25).map(x => range(0, 8, 0.5).map(t => [M.fieldE(x, t), M.current(x, t)])), range(0, 15).map(i => range(0, 8, 0.5).map(t => M.cellCharge(i, t)))]]);
  C.push(['box over positions, widths and times', () => range(0, 15).map(b0 => range(1, 16 - b0, 3).map(bw => range(0, 8, 1.25).map(t => M.box(t, b0, bw))))]);
  C.push(['setBoxPos, setBoxWidth, advanceTime', () => [range(-2, 18).map(b => M.setBoxPos(M.START_PHYS, b)), range(-1, 18).map(w => M.setBoxWidth(M.START_PHYS, w)), range(0, 30).map(k => M.advanceTime({ ...M.START_PHYS, t: k * 0.37 }, 0.8))]]);
  C.push(['phys at times 0 … 8 by 0.4 in three boxes', () => [[3, 2], [0, 16], [7, 5]].map(([b0, bw]) => range(0, 8, 0.4).map(t => M.phys({ t, b0, bw }))), { drop: ['charge', 'ends', 'change', 'alt'], add: ['qText', 'balance', 'change'] }]);
  return C;
}
