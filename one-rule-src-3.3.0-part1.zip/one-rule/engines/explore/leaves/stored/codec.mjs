// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/codec.mjs — what the Octavo fixtures of the Explore port share (the method of round 2, engines/stored/fixture_codec.mjs, whose
// encode and compare this file uses). make_octavo.mjs runs the cases of cases.mjs through Octavo's leaf logics (a copy of the Octavo base with the unfinished
// leaves laid over it) and stores what they returned; tests/explore/leaves.<slug>.test.mjs runs the same cases through the ported module and compares.
//   project(x, keys)   a deep copy of x without the object keys in `keys` (at any depth). A case names the keys Octavo returned that the port does not carry
//                      (`drop`: its sentences, removed before the output is stored) and the keys the port adds (`add`: data that replaced a sentence, removed
//                      from the live output before it is compared); a key in both is a readout whose words changed (compared by the leaf's own test)
//   record(value)      the stored form of a case: the encoded value itself when it is short, else its sha256 and size (the long outputs of the pictures)
//   check(live, rec)   the live value against the stored form: every number bit-identical (Object.is) or a zero with the other sign bit (counted; the kernel's
//                      products give +0 where the v15 route could give −0), every string and every key the same
import { createHash } from 'node:crypto';
import { encode, compare } from '../../../stored/fixture_codec.mjs';

export function project(x, keys) {
  const K = new Set(keys || []);
  const walk = v => {
    if (v === null || typeof v !== 'object') return v;
    if (Array.isArray(v)) return v.map(walk);
    if (ArrayBuffer.isView(v)) return v;
    if (v instanceof Map) return new Map([...v].map(([k, w]) => [k, walk(w)]));
    if (v instanceof Set) return new Set([...v].map(walk));
    const o = {}; for (const k of Object.keys(v)) if (!K.has(k)) o[k] = walk(v[k]); return o;
  };
  return walk(x);
}
// the encoded value with every −0 written as 0 (for the digest: a zero's sign bit is counted, not compared), and the number of leaves it holds
const unsign = e => (Array.isArray(e) ? e.map(unsign) : e && typeof e === 'object' ? (e.$n === '-0' && Object.keys(e).length === 1 ? 0 : Object.fromEntries(Object.entries(e).map(([k, v]) => [k, unsign(v)]))) : e);
const leavesOf = e => (Array.isArray(e) ? e.reduce((s, x) => s + leavesOf(x), 0) : e && typeof e === 'object' ? (['$n', '$big', '$undef', '$fn'].some(k => k in e) ? 1 : Object.values(e).reduce((s, x) => s + leavesOf(x), 0)) : 1);
const negZeros = e => (Array.isArray(e) ? e.reduce((s, x) => s + negZeros(x), 0) : e && typeof e === 'object' ? (e.$n === '-0' ? 1 : Object.values(e).reduce((s, x) => s + negZeros(x), 0)) : 0);
export const FULL_LIMIT = 4000;                                     // characters of encoded JSON up to which a case is stored as it is
export function record(value) {
  const e = encode(value), text = JSON.stringify(e);
  if (text.length <= FULL_LIMIT) return { out: e, negativeZeros: negZeros(e) };
  const u = JSON.stringify(unsign(e));
  return { sha256: createHash('sha256').update(u).digest('hex'), bytes: u.length, leaves: leavesOf(e), negativeZeros: negZeros(e) };
}
export function check(live, rec) {
  if ('out' in rec) {
    let r; try { r = compare(live, rec.out); } catch (err) { return { ok: false, how: 'full', leaves: 0, exact: 0, signedZero: 0, close: 0, why: 'threw: ' + err.message }; }
    const why = r.fails.length ? r.fails.slice(0, 3).map(f => `${f.path}: ${f.why} (stored ${f.stored}, live ${f.live})`).join('; ') : r.close ? `${r.close} values only within 1e-12` : '';
    return { ok: r.fails.length === 0 && r.close === 0 && r.leaves > 0, how: 'full', leaves: r.leaves, exact: r.exact, signedZero: r.signedZero, close: r.close, why };
  }
  let e; try { e = encode(live); } catch (err) { return { ok: false, how: 'digest', leaves: 0, why: 'threw: ' + err.message }; }
  const u = JSON.stringify(unsign(e)), sha = createHash('sha256').update(u).digest('hex'), n = leavesOf(e), z = negZeros(e);
  const ok = sha === rec.sha256 && u.length === rec.bytes && n === rec.leaves;
  return { ok, how: 'digest', leaves: n, exact: ok ? n : 0, signedZero: Math.abs(rec.negativeZeros - z), close: 0, why: ok ? '' : `sha256 ${sha.slice(0, 12)}… ≠ ${String(rec.sha256).slice(0, 12)}… (${u.length} / ${rec.bytes} characters, ${n} / ${rec.leaves} values)` };
}
