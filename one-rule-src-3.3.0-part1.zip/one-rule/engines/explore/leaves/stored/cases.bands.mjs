// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.bands.mjs — the fixed inputs of the loose leaf "Bands" in the form of cases.mjs (appended to CASES there): cases(M) lists
// [id, fn, { drop, add }], fn calling only exports that Octavo's octavo/leaves/bands.logic.js and the port engines/explore/leaves/bands.logic.js both have, over
// the whole state space Octavo's two sliders reach (energy 0 … 30 and height 0 … 8, in tenths: 24,381 positions) and seeded samples from prng. drop names the
// sentences of Octavo's output the port does not carry (status, alt, line), add the data the port returns instead (the readout and the pieces of mapView).
// Octavo's physCap (one sentence) and trackOf (the track of its slider) have no counterpart in the port and no case here.
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const tenths = n => Array.from({ length: n + 1 }, (_, i) => i / 10);

export function cases(M) {
  const C = [], ES = tenths(300), HS = tenths(80), FEW = [0, 0.1, 1, 2.5, 5, 7.9, 8];
  C.push(['constants', () => [M.L_LOW, M.V_LOW, M.L_HIGH, M.H_CELL, M.PERIOD, M.E_MAX, M.H_MAX, M.E_TENTHS, M.H_TENTHS, M.SNAP, M.SCAN, M.ROW, M.ROW_PHYS, M.START, M.START_BACK, M.SPEED,
    M.MOVE_OF, M.COLOR_OF, M.TICKS, M.FRONT, M.CHIPS, M.MAP, M.TRAIL_STEP, M.FORMULA, M.BAND]]);
  C.push(['cellOf at every height, fromMv', () => [HS.map(M.cellOf), [[1, 0, 0, 0], [0.5, 0.25, -2, 3], [-1, 0, 1, 1], [2, 1, 1.5, -0.5]].map(M.fromMv)]]);
  C.push(['period at every energy and every height of the sliders', () => HS.map(h => ES.map(E => M.period(E, h)))]);
  C.push(['periodMv at seven heights', () => FEW.map(h => ES.filter((_, i) => i % 7 === 0).map(E => M.periodMv(E, h)))]);
  C.push(['verdict on the three cases and M = ±1', () => [[1, { s: 0, Xnorm: 0 }], [1, { s: 0, Xnorm: 0.5 }], [-1 - 1e-12, { s: 1e-12, Xnorm: 2 }], [0.3, { s: -0.91, Xnorm: 1 }], [1.7, { s: 1.89, Xnorm: 2 }], [-1.2, { s: 0.44, Xnorm: 1 }], [-1, { s: 0, Xnorm: 0 }]].map(([g, xs]) => M.verdict(g, xs))]);
  C.push(['edgesOf at every height', () => HS.map(h => M.edgesOf(h))]);
  C.push(['stretchesOf and stripView at every height', () => HS.map(h => { const e = M.edgesOf(h); return [M.stretchesOf(h, e), M.stripView(h, e)]; })]);
  C.push(['energyAt at every position of every height', () => HS.map(h => { const e = M.edgesOf(h); return Array.from({ length: M.E_TENTHS + 1 }, (_, v) => M.energyAt(v, e)); })]);
  C.push(['eText', () => [0, 0.05, 1.733111405, 7.5, 30, -0.04, -2.25].map(E => [M.eText(E, false), M.eText(E, true)])]);
  C.push(['waveOf: a seeded sample, the edges of the cell, no step', () => {
    const r = prng(2610), out = [];
    for (let k = 0; k < 40; k++) { const E = pint(r, 0, 300) / 10, h = pint(r, 0, 80) / 10; out.push(M.waveOf(E, h)); }
    for (const e of M.edgesOf(5)) out.push(M.waveOf(e, 5));
    out.push(M.waveOf(0, 0), M.waveOf(3, 5, M.ROW_PHYS), M.waveOf(7.5, 5, M.ROW_PHYS, 20));
    return out;
  }]);
  C.push(['waveY, wavePath, envPath', () => [[3, 5], [7.5, 5], [25.3, 5], [12, 2.5], [0, 0]].map(([E, h]) => { const w = M.waveOf(E, h); return [[0, 0.7, 2, 4.4].map(phi => M.waveY(w, 17, phi)), M.wavePath(w, 0.7, 20, 57.7, 74, 54), M.envPath(w, 20, 57.7, 74, 54)]; })]);
  C.push(['stepRects', () => FEW.map(h => [M.stepRects(h, M.ROW, 20, 57.7, 218, 7), M.stepRects(h, M.ROW_PHYS, 58, 55.8, 318, 9.87)])]);
  C.push(['frontView at every position of seven heights', () => FEW.map(h => { const e = M.edgesOf(h); return Array.from({ length: M.E_TENTHS + 1 }, (_, v) => { const { E, snapped } = M.energyAt(v, e); return M.frontView(E, snapped, h, e); }); }), { drop: ['status', 'alt'] }]);
  C.push(['squash on a grid of moves', () => [-3, -1, -0.25, 0, 0.5, 2, 40].map(b => [-3, -1, 0, 0.75, 9].map(c => M.squash(b, c)))]);
  C.push(['trail at four heights', () => [0, 1, 5, 8].map(h => M.trail(h))]);
  C.push(['travelled at five energies', () => { const t = M.trail(5); return [0, 1.7, 6.25, 15, 30].map(E => M.travelled(t, E)); }]);
  C.push(['mapView at every position of the cell, and of two more heights', () => [5, 1, 8].map(h => { const e = M.edgesOf(h); return Array.from({ length: M.E_TENTHS + 1 }, (_, v) => { const { E, snapped } = M.energyAt(v, e); return M.mapView(E, snapped, e, h); }); }), { drop: ['line', 'alt'], add: ['readout', 'pieces'] }]);
  C.push(['twoTurns at every height', () => HS.map(h => M.twoTurns(h, M.edgesOf(h))), { drop: ['line'] }]);
  C.push(['yOfE', () => ES.filter((_, i) => i % 5 === 0).map(M.yOfE)]);
  C.push(['physView at every position of the cell, and of two more heights', () => [5, 0, 2.5].map(h => { const e = M.edgesOf(h); return Array.from({ length: M.E_TENTHS + 1 }, (_, v) => { const { E, snapped } = M.energyAt(v, e); return M.physView(E, snapped, e, h); }); }), { drop: ['line', 'alt'] }]);
  return C;
}
