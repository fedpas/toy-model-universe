// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.hung.mjs — the fixed inputs of the loose leaf Hung, in the form of cases.mjs: cases(M) lists [id, fn, { drop, add }] over the
// whole state space Octavo's controls reach (the three spaces, every weight from 0 to 2k in twentieths of k, every distance of the mathematician's slider, every
// nudge of the physicist's) and a few strengths k besides; fn calls only exports that Octavo's module and the port both have. drop names the sentences of
// Octavo's output the port does not carry (alt, status, the parts' text, the marks' label words, mathView's and physView's line, curvLine), add the data the
// port returns instead (parts[].at and .edge, physView floor). cases.mjs appends these to CASES under the key "hung".
const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], W = range(0, M.W_MAX), D = range(0, M.D_MAX), NV = range(-M.NUDGE_MAX, M.NUDGE_MAX), G = [0, 0.05, 0.3, 0.5, 0.8, 1, 1.4, 2.2, 3, 3.1, Math.PI / 2, Math.PI - 0.2];
  C.push(['constants', () => [M.SPACES, M.NAMES, M.SQ, M.SPACES.map(M.kappa), M.FORM, M.UP, M.TOP, M.SPACES.map(M.FAR), M.MOVES, M.EPS, M.MEET, M.K, M.W_MAX, M.START, M.FR, M.AXIS,
    M.CUBE_DIAG, M.CUBE_TURN, M.FACE_SHADE, M.D_MAX, M.MATH_START, M.MA, M.CURVE_NAME, M.SLICE_LABEL, M.PH_W, M.NUDGE_MAX, M.PH_START, M.PE, M.VY, M.PHYS_FORM, M.BALL_R, M.PH_AXIS]]);
  C.push(['points, joins, sizes and the reverse on a grid of distances', () => M.SPACES.map(s => G.map(d => {
    const P = M.pointAt(s, d), L = M.join(s, M.ORIGIN, P);
    return [M.cosK(s, d), M.sinK(s, d), Array.from(P), Array.from(L), Array.from(M.rev(L)), M.sizeOf(s, L), M.span(s, d)];
  })).concat([[Array.from(M.ORIGIN), Array.from(M.vectorOf(0.6, [0.1, -0.2, 0.3])), Array.from(M.point(0.6, [0.1, -0.2, 0.3]))]])]);
  C.push(['the size of the join at every distance of the slider', () => M.SPACES.map(s => D.map(dv => M.span(s, M.distOf(dv))))]);
  C.push(['pull, rest, curvature and balances at every weight the slider reaches', () => M.SPACES.map(s => W.map(wv => { const mg = M.weightOf(wv), r = M.rest(s, M.K, mg); return [M.pull(s, M.K, 0.7), r, r === null ? null : M.curvature(s, M.K, r), M.balances(s, M.K, mg)]; }))]);
  C.push(['rest and balances for other strengths of the spring', () => [0.5, 2, 3.5].map(k => M.SPACES.map(s => [0, 0.2, 0.5, 1, 1.7, 3, 4].map(mg => [M.rest(s, k, mg), M.balances(s, k, mg)])))]);
  C.push(['sway of the curvatures', () => [-2, -1, -0.5, -1e-5, -1e-7, 0, 1e-7, 1e-5, 0.6, 1, 1.28, 3].map(M.sway)]);
  C.push(['energy on a grid of stretches and weights', () => M.SPACES.map(s => [0, 0.4, 0.8, 1, 1.6].map(mg => G.map(d => M.energy(s, M.K, mg, d))))]);
  C.push(['the paths of the pictures', () => [M.PULL_PATHS, M.SLICE_PATHS, M.ENERGY_PATHS, M.SPACES.map(M.pullPath), M.SPACES.map(M.slicePath), M.SPACES.map(s => M.energyPath(s)), M.SPACES.map(s => [0, 0.4, 1.3, 3.1].map(d => M.arcPath(s, d)))]]);
  C.push(['zigzag, the cube and its faces', () => [M.zigzag(304, 46, 46.5), M.zigzag(304, 46, 120), M.zigzag(10, 0, 300, 4, 5), M.cubeShape(), M.CUBE, [0, 0.8, 0.93, 1.57, 2.35].map(M.cubeAt)]]);
  C.push(['seeView at every space and weight', () => M.SPACES.map(s => W.map(wv => M.seeView(s, wv))), { drop: ['alt', 'status', 'text', 'label'], add: ['at', 'edge'] }]);
  C.push(['seeView at the start', () => M.seeView(M.START.space, M.START.wv), { drop: ['alt', 'status', 'text', 'label'], add: ['at', 'edge'] }]);
  C.push(['mathView at every distance', () => D.map(M.mathView), { drop: ['line', 'alt'] }]);
  C.push(['physView at every space and nudge', () => M.SPACES.map(s => NV.map(nv => M.physView(s, nv))), { drop: ['line', 'curvLine', 'alt'], add: ['floor'] }]);
  C.push(['fate and signed', () => [[{ back: true }, { away: true }, {}, { back: false, away: false }].map(M.fate), [-3, -0.5, 0, 0.25, 1].map(M.signed), [0, 7, 40].map(M.weightOf), [-10, 0, 6].map(M.nudgeOf), [0, 31, 62].map(M.distOf)]]);
  C.push(['the picture scales', () => [[-1, 0, 1, 2.12].map(M.fx), [0, 1, Math.PI].map(M.fy), [-1.25, 0, 2.75].map(M.mx), [-1, 0, 2.6].map(M.my), [0, 1, Math.PI].map(M.ex), [-0.55, 0, 0.45].map(M.ey)]]);
  return C;
}
