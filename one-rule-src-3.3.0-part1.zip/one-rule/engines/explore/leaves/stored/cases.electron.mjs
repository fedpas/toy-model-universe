// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.electron.mjs — the fixed inputs of the loose leaf Electron, in the form of cases.mjs (which adds them as CASES.electron):
// cases(M) lists [id, fn, { drop, add }], where fn calls only exports that Octavo's module and the port both have, over the whole state space the controls
// reach (every mass, momentum and zero-switch momentum in tenths) and seeded inputs from prng (round 2). drop names the keys of Octavo's output the port does
// not carry (sentences), add the keys the port returns instead (data); a key in both is a readout whose words changed (compared by the leaf's own test).
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], mv = range(M.MV[0], M.MV[1]), kv = range(M.KV[0], M.KV[1]), wv = range(M.WV[0], M.WV[1]), pv = range(M.PV[0], M.PV[1]);
  C.push(['constants', () => [M.NAMES, M.SQUARES, M.MOMS, M.MV, M.KV, M.WV, M.START, M.VIEW, M.O, M.U, M.K_LIM, M.LIGHT_SPEED, M.LIGHT_PATH, M.K_TICKS, M.LABELS, M.BOX_HALF, M.BOX_TICKS, M.PHYS_M, M.PV, M.PHYS_START, M.PVIEW, M.PO, M.PU, M.P_LIM, M.PHYS_PATHS, M.PHYS_LABELS, M.P_TICKS]]);
  C.push(['momentum and twin: seeded parts and masses', () => { const r = prng(4401), out = []; for (let i = 0; i < 80; i++) { const c = Array.from({ length: 5 }, () => Math.round(r() * 60 - 30) / 10), m = pint(r, 0, 20) / 10; out.push([M.momentum(c), M.twin(c, m)]); } return out; }]);
  C.push(['twin at small integer parts', () => { const out = []; for (let E = -2; E <= 2; E++) for (let k = -2; k <= 2; k++) for (let k0 = -1; k0 <= 1; k0++) for (let m = 0; m <= 2; m++) out.push(M.twin([E, k, 1 - Math.abs(k), 0, k0], m)); return out; }]);
  C.push(['energy at every state the controls reach', () => mv.map(m => kv.map(k => wv.filter(w => w % 5 === 0).map(w => M.energy(k / 10, w / 10, m / 10))))]);
  C.push(['energy at every momentum and zero-switch momentum, mass 0.5', () => kv.map(k => wv.map(w => M.energy(k / 10, w / 10, 0.5)))]);
  C.push(['canSet on and around the edges', () => [-1, 0, 20, 21].map(a => [-31, -30, 30, 31].map(b => [-31, 0, 30, 31, 0.5].map(c => M.canSet({ mv: a, kv: b, wv: c }))))]);
  C.push(['toX, toY, boxLeft, boxTop, nb', () => [range(-3.5, 3.5, 0.5).map(k => [M.toX(k), M.toY(Math.abs(k)), M.boxLeft(k), M.boxTop(Math.abs(k))]), ['a − b', 'x = y + z', '(P − m)(P + m) = P^{2} − m^{2}', '2 × 3 · 4'].map(M.nb)]]);
  C.push(['curvePath at every mass', () => mv.map(M.curvePath)]);
  C.push(['front at every mass and momentum, five zero-switch momenta', () => mv.map(m => kv.map(k => [-30, -15, 0, 15, 30].map(w => M.front({ mv: m, kv: k, wv: w })))), { drop: ['note', 'status', 'alt', 'boxAlt', 'sum'], add: ['sum', 'zeroAddsNothing', 'massless'] }]);
  C.push(['front on a seeded walk of the three controls', () => { const r = prng(4402), out = []; let s = M.START; for (let t = 0; t < 300; t++) { const n = { ...s }; const key = ['mv', 'kv', 'wv'][pint(r, 0, 2)]; n[key] += pint(r, -6, 6); if (M.canSet(n)) s = n; out.push(M.front(s)); } return out; }, { drop: ['note', 'status', 'alt', 'boxAlt', 'sum'], add: ['sum', 'zeroAddsNothing', 'massless'] }]);
  C.push(['cell, TABLE, partnerOf, cancelPairs, diagonal, litOf, detPower', () => [M.TABLE, [0, 1, 2, 3, 4].map(a => [0, 1, 2, 3, 4].map(b => [M.cell(a, b), M.partnerOf(a, b), M.litOf([a, b])])), M.cancelPairs(), M.diagonal(), M.litOf(null), [1, 2, 4, 8, 16, 32].map(M.detPower)]]);
  C.push(['MATH', () => M.MATH, { drop: ['forces', 'det', 'sizes'], add: ['forces', 'det'] }]);
  C.push(['speed, slowGuess, fastGuess on a grid', () => range(0, 3, 0.25).map(k => [0.5, 1, 2].map(m => { const E = Math.sqrt(k * k + m * m); return [M.speed(k, E), M.slowGuess(k, m), M.fastGuess(k), M.fastGuess(-k)]; }))]);
  C.push(['physView at every momentum', () => pv.map(M.physView), { drop: ['line2', 'line3', 'alt'], add: ['slowMiss', 'fastMiss'] }]);
  return C;
}
