// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.field.mjs — the fixed inputs of the loose leaf "Field" (the form of cases.mjs, which appends them as CASES.field): every
// field and every speed the controls reach (the three fields, the speeds −0.95 … 0.95 by 0.01 of the logic, which hold the picture's steps by 0.1), every edge
// of the mathematician's flat drawing, every speed 0 … 0.8 of the physicist's back, and seeded fields and speeds for the algebra. fn(M) calls only exports that
// Octavo's module and the port both have; drop names the keys of Octavo's output the port does not carry (sentences), add the keys the port returns instead.
import { prng } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], ids = M.PRESETS.map(p => p.id), speeds = range(M.V_MIN, M.V_MAX), edges = M.EDGES.map(e => e.id);
  const seededFields = (seed, n) => { const r = prng(seed), u = () => Math.round((r() * 4 - 2) * 64) / 64; return Array.from({ length: n }, () => ({ E: [u(), u(), u()], B: [u(), u(), u()], v: Math.round((r() * 1.9 - 0.95) * 100) / 100 })); };
  C.push(['constants', () => [M.SQ, M.AXES, M.FIELDS, M.TOP, M.R_SIGN, M.X_HAT, M.PRESETS, M.V_MIN, M.V_MAX, M.START, M.SPEED_ENDS, M.MAX_ABS, M.START_EDGE, M.PV_MIN, M.PV_MAX, M.START_PHYS, M.PHYS_ENDS, M.PHYS, M.PHYS_SCALE]]);
  C.push(['the edges and the front drawing', () => [M.EDGES, M.CAM, M.SPACE, M.CORNER_R, M.CORNERS, M.VIEW, M.HIDDEN, M.W0, M.W_PER, M.PILL_AT, M.PILL_FS, M.PILL_H, M.PILL_PAD, M.EDGE_GEO]]);
  C.push(['the flat drawing and the physicist\'s picture', () => [M.FLAT, M.FLAT_AT, M.OUTSIDE_SPOT, M.AH, M.OUT_LEN, M.ADD_GAP, M.PHYS_VIEW]]);
  C.push(['canSet over the fields and the speeds −100 … 100 (and two that are not whole)', () => [...ids, 'none'].map(f => [...range(-100, 100), 0.5, -12.25].map(v => M.canSet(f, v)))]);
  C.push(['presetOf, lettersOf, spaced, ruleName', () => [[...ids, 'none'].map(M.presetOf), range(0, 15).map(m => [M.lettersOf(m), M.spaced(m), M.ruleName(m) === undefined ? null : M.ruleName(m)])]]);
  C.push(['the numbers: f2, vText, speedText, gammaOf, widthOf, textWidth', () => [range(-3, 3, 0.005).map(x => [M.f2(x), M.widthOf(x)]), range(-1, 1, 0.005).map(v => [M.vText(v), M.speedText(v)]), range(-0.95, 0.95, 0.01).map(M.gammaOf), ['0.00', '−2.56', '1.15', 'at rest', '0.95 c'].map(s => [M.textWidth(s, 16), M.textWidth(s, 13)])]]);
  C.push(['toF, partsOf and the reverse on seeded fields', () => seededFields(7, 80).map(({ E, B }) => { const F = M.toF(E, B); return [F, M.partsOf(F), M.reverse(F), M.reverse(M.rotor(0.5))]; })]);
  C.push(['rotor and boost of seeded fields at seeded speeds', () => seededFields(11, 120).map(({ E, B, v }) => [M.rotor(v), M.boost(M.toF(E, B), v)])]);
  C.push(['strengths and invariants of seeded fields at seeded speeds', () => seededFields(13, 120).map(({ E, B, v }) => { const F = M.boost(M.toF(E, B), v); return [M.strengths(F), M.invariants(F)]; })]);
  for (const f of ids) C.push([`frontView: ${f}, every speed −0.95 … 0.95 by 0.01`, () => speeds.map(v => M.frontView({ field: f, v })), { drop: ['status', 'alt'], add: ['moving'] }]);
  C.push(['frontView at the picture\'s steps (every field, −0.9 … 0.9 by 0.1)', () => ids.map(f => range(-90, 90, 10).map(v => M.frontView({ field: f, v }))), { drop: ['status', 'alt'], add: ['moving'] }]);
  C.push(['pillBox of every edge for some texts', () => M.EDGE_GEO.map(g => ['0.00', '−0.35', '1.15', '−2.56'].map(s => M.pillBox(g, s)))]);
  C.push(['steps and stepArrows of every edge', () => M.EDGES.map(e => [M.steps(e), M.stepArrows(e)])]);
  C.push(['gathered', () => M.gathered()]);
  C.push(['mathView of every edge', () => edges.map(M.mathView), { drop: ['headTail', 'count', 'alt'], add: ['counts'] }]);
  C.push(['facePoints, incentre, arrow', () => [[1, 2, 4, 8, 7, 11, 13, 14].map(m => [M.facePoints(m), [7, 11, 13, 14].includes(m) ? M.incentre(m) : null]), [[{ x: 0, y: 0 }, { x: 30, y: 40 }], [{ x: 190, y: 196 }, { x: 70, y: 100 }], [{ x: 5, y: 5 }, { x: -20, y: 5 }]].map(([p, q]) => M.arrow(p, q))]]);
  C.push(['physFields and physView at every speed 0 … 0.8 by 0.01', () => range(M.PV_MIN, M.PV_MAX).map(pv => [M.physFields(pv), M.physView(pv)]), { drop: ['along', 'invLine', 'alt'], add: ['alongText', 'invText'] }]);
  C.push(['tipOf and vec', () => [[[0, 0, 0], [0.6, 0.8, 0], [0.7, -0.3, 0.4], [0, -1.2, 0.5]].map(a => [M.tipOf(a), M.vec(a)])]]);
  C.push(['project', () => [[0, 0, 0], [1, 0, 0], [0, 1, 0], [0, 0, 1], [0.5, -0.25, 2]].map(M.project)]);
  return C;
}
