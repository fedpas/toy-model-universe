// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.mirrors.mjs — the fixed inputs of leaf 3, mirrors, in the form of cases.mjs (which imports this file at its end): cases(M)
// lists [id, fn, { drop, add }] over the whole state space the controls reach (every angle 0° … 90° by 5° in both orders, the eight corners of the cube, one,
// two or three mirrors with every slope 20° … 50° by 5°) and seeded vectors. fn(M) calls only exports that Octavo's module and the port both have; functions
// returned inside a state (pair's once and twice) are applied to points here, so the fixture holds what they compute.
import { prng, pint } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], degs = range(M.SPREAD.min, M.SPREAD.max, M.SPREAD.step), states = degs.flatMap(deg => [false, true].map(swap => ({ deg, swap })));
  const aims = range(M.AIM.min, M.AIM.max, M.AIM.step), beams = M.CHIPS.flatMap(c => aims.map(aim => ({ n: c.id, aim })));
  const PROBES = [[1, 0], [0, 1], [0.6, -0.8], [-2.5, 1.25], [3, 4]];
  C.push(['constants', () => [M.SPREAD, M.START, M.FLAG_AT, M.C, M.LINE, M.LABEL_R, M.ARC_R, M.WEDGE_R, M.FLAG, M.N, M.CUBE, M.CORNERS, M.LAYERS, M.EDGES, M.COLUMN_HEADS, M.MOST, M.START_CORNER, M.ROOM, M.WALLS, M.PARTS, M.CHIPS, M.AIM, M.START_BEAM, M.HEADING, M.FLOOR_HIT, M.L_MAX, M.VIEW, M.SHADE]]);
  C.push(['sandwich, mirror, offVector: seeded vectors in 2 and 3 dimensions', () => {
    const r = prng(303), out = [];
    for (let k = 0; k < 80; k++) {
      const n = k % 2 ? 3 : 2, a = Array.from({ length: n }, () => pint(r, -4, 4) / 2), x = Array.from({ length: n }, () => pint(r, -6, 6) / 3);
      if (a.every(c => c === 0)) a[0] = 1;
      out.push([M.sandwich(x, a), M.mirror(x, a), M.offVector(x, a)]);
    }
    return out;
  }]);
  C.push(['across, scr, arcPath', () => [degs.map(M.across), PROBES.map(M.scr), degs.map(d => [M.arcPath(M.WEDGE_R, 0, d), M.arcPath(M.ARC_R, M.FLAG_AT, 2 * d - 5), M.arcPath(M.ARC_R, M.FLAG_AT, -2 * d + 5)])]]);
  C.push(['pair and turnOf at every angle in both orders (once and twice applied to five points)', () => states.map(s => {
    const p = M.pair(s), t = M.turnOf(s);
    return [p.first, p.second, p.M, p.angle, PROBES.map(p.once), PROBES.map(p.twice), t.size, t.dir, t.sweep, t.M, t.angle];
  })]);
  C.push(['frontView at every angle in both orders', () => states.map(M.frontView), { drop: ['status', 'alt'], add: ['apart', 'turnText'] }]);
  C.push(['swapped, setSpread on −5 … 95, a fraction and a string', () => [states.map(M.swapped), [...range(-5, 95), 2.5, '30', null].map(d => M.setSpread(M.START, d))]]);
  C.push(['axesOf, cornerName, productName, cornerAct at every corner', () => range(0, 7).map(S => {
    const a = M.cornerAct(S);
    return [M.axesOf(S), M.cornerName(S), M.productName(S), Array.from(a.V), Array.from(a.Vi), a.k, a.cols.map(c => Array.from(c)), a.M, M.det3(a.M)];
  })]);
  C.push(['cornerView at every corner', () => range(0, 7).map(M.cornerView), { drop: ['what', 'kind', 'line1', 'line2', 'aria'], add: ['even'] }]);
  C.push(['dirIn, setBeam, proj', () => [aims.map(M.dirIn), [[{ n: 2 }], [{ aim: 45 }], [{ n: 4 }], [{ aim: 52 }], [{ aim: 33 }], [{ n: 1, aim: 20 }]].map(([k]) => M.setBeam(M.START_BEAM, k)), [[0, 0, 0], [3.4, 3.2, 2.8], [1.6, 0, 1.05]].map(M.proj)]]);
  C.push(['trace at every number of mirrors and every slope', () => beams.map(b => M.trace(b.n, b.aim))]);
  C.push(['beamView at every number of mirrors and every slope', () => beams.map(M.beamView), { drop: ['status', 'alt'] }]);
  return C;
}
