// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/stored/cases.half-turns.mjs — the fixed inputs of leaf 4, half-turns, in the form of cases.mjs (which takes them as CASES['half-turns']):
// [id, fn, { drop, add }] over the whole state space the controls reach — every step of 5° of Octavo's slider from 0° to 720° (the nine chips of the port are
// among them), every whole degree for the values the words followed, the play button over forty seconds, a grid of taps on the square, and seeded turns.
// fn calls only exports that Octavo's module and the port both have; drop names Octavo's sentence keys, add the data keys the port returns in their place.
import { prng } from '../../../stored/fixture_codec.mjs';

const range = (a, b, step = 1) => { const o = []; for (let x = a; x <= b + 1e-9; x += step) o.push(+x.toFixed(10)); return o; };

export function cases(M) {
  const C = [], grid = range(0, M.MAX, M.STEP), degs = range(0, M.MAX), edges = [1e-3, 0.5, 2.5, 179.999, 180.001, 357.5, 359.999, 360.001, 362.5, 539.999, 540.001, 717.5, 719.999];
  const r = prng(20261012), seeded = Array.from({ length: 200 }, () => r() * M.MAX);
  C.push(['constants', () => [M.ONE, M.E1, M.E2, M.B, M.EPS, M.MAX, M.STEP, M.DIAL, M.SPEED, M.HOLD, M.HOLD_END, M.STOPS, M.START, M.STILL, M.ENDS, M.LAP_ENDS, M.ACROSS_TICKS, M.SQUARE, M.LIFT_STEP, M.PH, M.PLOT]]);
  C.push(['rotor, bPart, arrow, rev, inverse at every step and at the edges', () => [...grid, ...edges].map(phi => { const R = M.rotor(phi); return [R, M.bPart(R), M.arrow(phi), M.rev(R), M.inverse(R)]; })]);
  C.push(['sandwich of e1 and e2 by R and by −R at every step', () => grid.map(phi => { const R = M.rotor(phi), mR = M.scale(R, -1); return [M.sandwich(R, M.E1), M.sandwich(R, M.E2), M.sandwich(mR, M.E1), M.sandwich(mR, M.E2)]; })]);
  C.push(['add, scale, inverse of B', () => [M.add(M.ONE, M.B), M.add(M.ONE, M.B, -2), M.scale(M.B, 0.5), M.inverse(M.B), M.rev(M.B)]]);
  C.push(['norm, dirOf, rotorAngle, isHome, saysOf, sideOf at every whole degree', () => degs.map(d => { const R = M.rotor(d); return [M.norm(d), M.norm(-d), M.dirOf(M.arrow(d)), M.rotorAngle(R), M.isHome(d), M.saysOf(d), M.sideOf(R)]; })]);
  C.push(['isHome, saysOf, sideOf at the edges', () => edges.map(phi => [M.isHome(phi), M.saysOf(phi), M.sideOf(M.rotor(phi))])]);
  C.push(['degText', () => [...range(0, 360, 0.25), 1e-8, 359.96, 0.04].map(M.degText)]);
  C.push(['snap and setTurn on −50 … 800', () => range(-50, 800, 0.5).map(x => [M.snap(x), M.setTurn(x)])]);
  C.push(['advance: the play button over forty seconds at 60 frames a second', () => { let s = M.START; const out = []; for (let i = 0; i < 2400; i++) { s = M.advance(s, 1 / 60); out.push(s); } return out; }]);
  C.push(['advance from the stops, from the end and from a rest', () => [M.advance({ phi: 720, hold: 0 }, 1 / 60), M.advance({ phi: 360, hold: 0 }, 1 / 60), M.advance({ phi: 359, hold: 0 }, 0.1), M.advance({ phi: 719, hold: 0 }, 0.1), M.advance({ phi: 360, hold: 0.01 }, 0.1), M.advance({ phi: 720, hold: 0.01 }, 0.1), M.advance(M.STILL, 0.5)]]);
  C.push(['lapsText, markText', () => [range(0, 2, 0.05).map(M.lapsText), range(0, 360, 15).map(M.markText)]]);
  C.push(['arrowHead', () => [[{ x: 0, y: 0 }, { x: 30, y: 40 }, 24, 11], [{ x: 0, y: 0 }, { x: 10, y: 0 }, 24, 11], [{ x: 5, y: 5 }, { x: 5, y: 60 }, 14, 7], [{ x: 0, y: 0 }, { x: 26, y: 0 }, 24, 11]].map(a => M.arrowHead(...a))]);
  C.push(['trailPts, arcPts at every step', () => grid.map(phi => [M.trailPts(phi), M.arcPts(phi)])]);
  C.push(['frontView at every step', () => grid.map(M.frontView), { drop: ['status', 'alt'], add: ['home', 'says', 'arrowDeg', 'rotorDeg'] }]);
  C.push(['frontView at every whole degree and at the edges', () => [...degs, ...edges].map(M.frontView), { drop: ['status', 'alt'], add: ['home', 'says', 'arrowDeg', 'rotorDeg'] }]);
  C.push(['toXY, torusPoint, partnerPoint at every step', () => grid.map(phi => { const p = M.torusPoint(phi), o = M.partnerPoint(phi); return [p, o, M.toXY(p), M.toXY(o)]; })]);
  C.push(['lift at every step', () => grid.map(M.lift)]);
  C.push(['liftPath, GRAPH, GLOW_PATH', () => [grid.filter(p => p % 90 === 0).map(phi => M.liftPath(M.lift(phi).segs)), M.GRAPH, M.GLOW_PATH]]);
  C.push(['pickOnTorus on a grid of taps', () => range(-20, 380, 10).map(a => range(-20, 380, 10).map(u => M.pickOnTorus(a, u)))]);
  C.push(['torusView at every step', () => grid.map(M.torusView), { drop: ['pTag', 'oTag', 'line', 'alt'], add: ['tp', 'op', 'arrowLaps', 'rotorLaps', 'home', 'says'] }]);
  C.push(['glow, glowText, plotXY at every whole degree', () => degs.map(d => { const g = M.glow(d); return [g, M.glowText(g), M.plotXY(d, g)]; })]);
  C.push(['glowView at every step', () => grid.map(M.glowView), { drop: ['line', 'alt', 'rLabel', 'oneLabel', 'sumLabel'], add: ['rotor'] }]);
  C.push(['seeded turns: rotor, arrow, frontView, torusView, glowView', () => seeded.map(phi => [M.rotor(phi), M.arrow(phi), M.frontView(phi), M.torusView(phi), M.glowView(phi)]), { drop: ['status', 'alt', 'pTag', 'oTag', 'line', 'rLabel', 'oneLabel', 'sumLabel'], add: ['home', 'says', 'arrowDeg', 'rotorDeg', 'tp', 'op', 'arrowLaps', 'rotorLaps', 'rotor'] }]);
  return C;
}
