// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/half-turns.logic.js — leaf 4, half-turns (port of Octavo's octavo/leaves/half-turns.logic.js; plain functions, no React). Every product
// is engines/labels.js's mul (the kernel's), the reverse the kernel's reorderSign(m, m); tests/explore/leaves.half-turns.test.mjs recomputes every number by
// standard routes (complex numbers, the rotation matrix, Hamilton's quaternions, real 2 × 2 matrices, path lifting) and holds it bit-identical to Octavo's output.
// A turn of the plane by φ is the sandwich v ↦ R v R⁻¹ with the rotor R = cos(φ/2) + sin(φ/2) B of Cl(2,0), B = e2 e1 (B² = −1). This B turns e1 towards e2,
// so a positive φ turns anticlockwise, as the rotation matrix and Hamilton's cos(φ/2) + sin(φ/2) k do (the test ties the sign to both). The rotor moves at half
// the speed of the arrow: after 360° it is −1, after 720° it is +1 again; R and −R give the same turn.
// Front: two dials, the arrow and the spinor. Back, the mathematician: the square of pairs (where the arrow points, where the rotor is) with opposite edges
// glued, on which the rotors of all turns form one line that goes round twice before it closes. Back, the physicist: the rotor model of a wave split in two
// halves, one turned by φ, whose sum 1 + R has |1 + R|² = 2 + 2 cos(φ/2).
// Not carried over (docs/EXPLORE_PORT.md §3): COPY and every fixed sentence (MATH_CAP, FORMULAS, PHYS_CAP, PHYS_FORMULA, SIDE_WORDS, SLIDER_LABEL, HALF_LABEL);
// the sentences of the views (statusOf, frontAlt, lapsLine, glowLine: their facts are data — home, says, arrowDeg, rotorDeg, arrowLaps, rotorLaps); the slider's
// track TURN_TRACK (the turn is set by chips); where the names of points go (tagAt, rLabel, oneLabel, sumLabel): the labels are the picture's
// (src/figures/explore/leaf/halfTurnsLabels.js).
import { mul, mvZero, sigVec } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';
import { num } from '../shared.js';

// ---- the algebra: Cl(2,0) of the kernel, blades as bit masks (1 = e1, 2 = e2, 3 = e1 e2)
const SQ = sigVec(2, 0);
const blade = m => { const x = mvZero(2); x[m] = 1; return x; };
export const ONE = blade(0), E1 = blade(1), E2 = blade(2);
export const B = mul(E2, E1, SQ);                                     // the plane element of the turn, e2 e1
export const EPS = 1e-9;
const rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
export const add = (x, y, s = 1) => x.map((v, i) => v + s * y[i]);
export const scale = (x, s) => x.map(v => v * s);
// the reverse: each blade e_m reversed carries the kernel's reordering sign of e_m with itself (the plane part changes sign)
export const rev = x => x.map((v, m) => (reorderSign(m, m) < 0 ? -v : v));
export const inverse = X => scale(rev(X), 1 / mul(X, rev(X), SQ)[0]);  // for a rotor or a plane element, X X̃ is a number
export const sandwich = (R, v) => mul(mul(R, v, SQ), inverse(R), SQ);
// the rotor of a turn by φ degrees: R = cos(φ/2) + sin(φ/2) B
export function rotor(phi) { const h = rad(phi) / 2; return add(scale(ONE, Math.cos(h)), scale(B, Math.sin(h))); }
// how much B a rotor holds: the number part of R B⁻¹
export const bPart = R => mul(R, inverse(B), SQ)[0];
// the arrow e1 after a turn by φ: R e1 R⁻¹, as [x, y]
export function arrow(phi) { const w = sandwich(rotor(phi), E1); return [w[1], w[2]]; }
// an angle in degrees in [0, 360), with a hair either side of 0 read as 0
export const norm = a => { const n = ((a % 360) + 360) % 360; return n > 360 - 1e-7 || n < 1e-7 ? 0 : n; };
export const dirOf = ([x, y]) => norm(deg(Math.atan2(y, x)));         // where an arrow points
export const rotorAngle = R => norm(deg(Math.atan2(bPart(R), R[0])));  // where a rotor sits on its circle: +1 at 0°, −1 at 180°
export const isHome = phi => { const [x, y] = arrow(phi); return Math.abs(x - 1) < EPS && Math.abs(y) < EPS; };
// when the arrow is home the rotor is a number, +1 or −1 (0 when the arrow is not home)
export function saysOf(phi) { if (!isHome(phi)) return 0; const R = rotor(phi); return R[0] > 0 ? 1 : -1; }
// which mark the spinor is nearer: +1, −1, or 0 when it is exactly halfway between them
export const sideOf = R => (R[0] > EPS ? 1 : R[0] < -EPS ? -1 : 0);
// an angle in degrees as a value: whole degrees, or one decimal when the half of an odd angle needs it
export const degText = a => { const r = Math.round(a * 10) / 10; return Number.isInteger(r) ? String(r) : r.toFixed(1); };

// ---- front: the arrow and the spinor, side by side
export const MAX = 720, STEP = 5;
export const DIAL = { ax: 110, sx: 379, cy: 156, r: 106, tip: 97, trail0: 66, trail1: 32 };   // the two dials (picture units, viewBox 500 × 278); the arrow's trail stays inside radius 66
export const snap = phi => Math.max(0, Math.min(MAX, Math.round(phi / STEP) * STEP));
// the turns the chips set: every quarter turn of the arrow from 0° to 720° (nine values; Octavo's slider ran from 0 to 720 by 5)
export const CHIPS = [0, 90, 180, 270, 360, 450, 540, 630, 720];
// the play button: the turn runs at SPEED degrees a second, rests at 360° and at 720°, then starts again from 0
export const SPEED = 60, HOLD = 1.6, HOLD_END = 2.2, STOPS = [360, 720];
export const START = { phi: 0, hold: 0 };
export const STILL = { phi: 360, hold: 0 };                          // the first picture: one full turn (the figure starts paused)
export function advance(s, dt) {
  if (s.hold > 0) { const hold = s.hold - dt; return hold > 0 ? { ...s, hold } : s.phi >= MAX ? { phi: 0, hold: 0 } : { ...s, hold: 0 }; }
  if (s.phi >= MAX) return { phi: 0, hold: 0 };
  const next = s.phi + SPEED * dt;
  for (const stop of STOPS) if (s.phi < stop && next >= stop) return { phi: stop, hold: stop === MAX ? HOLD_END : HOLD };
  return { phi: next, hold: 0 };
}
export const setTurn = phi => ({ phi: snap(phi), hold: 0 });
// a step under reduced motion: on to the next chip (from 720° back to 0°)
export const stepOn = s => { const next = CHIPS.find(c => c > s.phi + 1e-9); return { phi: next === undefined ? 0 : next, hold: 0 }; };
// the values under the sliders and on the axes: the ends and the middle of the turn, in degrees and in laps; the two marks of the spinor's circle are the rotor there
const sg = s => (s > 0 ? '+1' : '−1');
export const ENDS = [0, MAX / 2, MAX].map(a => a + '°');
export const lapsText = x => { const r = Math.round(x * 100) / 100; return String(r) + (r === 1 ? ' lap' : ' laps'); };
export const LAP_ENDS = ['0', lapsText(MAX / 720), lapsText(MAX / 360)];
export const markText = t => sg(rotor(2 * t)[0]);                   // the rotor at angle t of its circle: +1 at 0°, −1 at 180°
export const ACROSS_TICKS = [0, 180, 360].map(a => a + '°');
const pathOf = pts => pts.map((p, i) => (i ? 'L' : 'M') + p.x.toFixed(1) + ' ' + p.y.toFixed(1)).join(' ');
// an arrowhead: the triangle with its point at `to`, and where the shaft stops under it (null for an arrow too short to carry one)
export function arrowHead(from, to, len, half) {
  const dx = to.x - from.x, dy = to.y - from.y, L = Math.hypot(dx, dy);
  if (L < len + 2) return null;
  const ux = dx / L, uy = dy / L, bx = to.x - len * ux, by = to.y - len * uy;
  return { pts: [to.x, to.y, bx - half * uy, by + half * ux, bx + half * uy, by - half * ux].map(v => v.toFixed(1)).join(' '), stop: { x: bx + 2 * ux, y: by + 2 * uy } };
}
const samples = (phi, step) => { const out = []; for (let a = 0; a < phi; a += step) out.push(a); out.push(phi); return out; };
// the trail of the arrow: a coil that tightens as the turn grows, so that a second lap lies inside the first
export function trailPts(phi) {
  return samples(phi, 4).map(a => { const [x, y] = arrow(a), rr = DIAL.trail0 - (DIAL.trail0 - DIAL.trail1) * a / MAX; return { x: DIAL.ax + rr * x, y: DIAL.cy - rr * y }; });
}
// the trail of the spinor along its circle, from +1
export function arcPts(phi) {
  return samples(phi, 4).map(a => { const R = rotor(a); return { x: DIAL.sx + DIAL.r * R[0], y: DIAL.cy - DIAL.r * bPart(R) }; });
}
// what the front draws for a turn by φ; the values follow the turn in whole degrees (d): whether the arrow is home, the rotor's sign then (says), where the
// arrow points and where the spinor sits on its circle
export function frontView(phi) {
  const R = rotor(phi), [x, y] = arrow(phi), d = Math.round(phi), tip = { x: DIAL.ax + DIAL.tip * x, y: DIAL.cy - DIAL.tip * y };
  return {
    phi, d, side: sideOf(R), tip, head: arrowHead({ x: DIAL.ax, y: DIAL.cy }, tip, 24, 11),
    spot: { x: DIAL.sx + DIAL.r * R[0], y: DIAL.cy - DIAL.r * bPart(R) },
    trail: pathOf(trailPts(phi)), arc: pathOf(arcPts(phi)), valueText: d + '°',
    home: isHome(d), says: saysOf(d), arrowDeg: dirOf(arrow(d)), rotorDeg: rotorAngle(rotor(d))
  };
}

// ---- back, the mathematician: the torus of pairs (where the arrow points, where the rotor is), both in degrees
export const SQUARE = { x: 74, y: 40, s: 260 };                      // picture units, viewBox 380 × 350 (room on the right for the names of points on the right edge)
export const toXY = p => ({ x: SQUARE.x + SQUARE.s * p.across / 360, y: SQUARE.y + SQUARE.s - SQUARE.s * p.up / 360 });
// the pair of a turn by φ (0 ≤ φ ≤ 720): a lap of the arrow that ends home ends on the right edge, and a rotor that is back at +1 after a whole lap of its own stands on
// the top edge (the arrow is home only at multiples of 360°, the rotor at +1 only at multiples of 720°)
export function torusPoint(phi) {
  const a = dirOf(arrow(phi)), t = rotorAngle(rotor(phi));
  return { across: a === 0 && phi >= 180 ? 360 : a, up: t === 0 && phi >= 360 ? 360 : t };
}
// the other rotor of the same turn, −R: the same place across, the opposite point of the rotor circle
export function partnerPoint(phi) { const p = torusPoint(phi); return { across: p.across, up: rotorAngle(scale(rotor(phi), -1)) }; }
const turnBetween = ([x0, y0], [x1, y1]) => deg(Math.atan2(x0 * y1 - y0 * x1, x0 * x1 + y0 * y1));   // the small angle from one direction to the next
export const LIFT_STEP = 5;
// the lift of the turn from 0 to φ: the pairs met on the way, in pieces that stop at the glued right edge and go on from the left one; and how far the arrow and the
// rotor have gone, in laps, by adding up their small steps
export function lift(phi) {
  let prev = torusPoint(0), pR = rotor(0), pA = arrow(0), rot = 0, arr = 0;
  const segs = [[prev]], n = Math.max(1, Math.ceil(phi / LIFT_STEP - 1e-9));
  for (let i = 1; i <= n; i++) {
    const f = Math.min(phi, i * LIFT_STEP), R = rotor(f), A = arrow(f), p = torusPoint(f);
    rot += turnBetween([pR[0], bPart(pR)], [R[0], bPart(R)]); arr += turnBetween(pA, A);
    if (p.across < prev.across - 180) segs.push([{ across: prev.across - 360, up: prev.up }]);
    segs[segs.length - 1].push(p); prev = p; pR = R; pA = A;
  }
  return { segs, arrowLaps: arr / 360, rotorLaps: rot / 360 };
}
export const liftPath = segs => segs.map(seg => pathOf(seg.map(toXY))).join(' ');
export const GRAPH = liftPath(lift(MAX).segs);                         // every pair (turn, rotor): one line that crosses the square twice
// a tap on the square at (across, up): the point of the line under it (of the two laps, the one whose rotor is nearer, round the glued edges)
export function pickOnTorus(across, up) {
  const a = Math.max(0, Math.min(360, across)), gap = (u, v) => { const g = Math.abs(u - v) % 360; return Math.min(g, 360 - g); };
  const c = [a, a + 360].map(p => ({ p, g: gap(torusPoint(p).up, up) }));
  return snap(c[0].g <= c[1].g ? c[0].p : c[1].p);
}
// what the square draws for a turn by φ: the lifted path, R and −R (as pairs, tp and op, and as points), the laps of the arrow and of the rotor; when the arrow is
// home, the rotor's sign there (says: −1, the path is open; +1, it closes)
export function torusView(phi) {
  const L = lift(phi), tp = torusPoint(phi), op = partnerPoint(phi);
  return {
    path: liftPath(L.segs), p: toXY(tp), o: toXY(op), tp, op, valueText: Math.round(phi) + '°',
    arrowLaps: L.arrowLaps, rotorLaps: L.rotorLaps, home: phi > 0 && isHome(phi), says: phi > 0 ? saysOf(phi) : 0
  };
}

// ---- back, the physicist: the rotor model of two halves of a wave; one half is turned by φ, the sum is 1 + R
export const glow = phi => { const S = add(ONE, rotor(phi)); return mul(S, rev(S), SQ)[0]; };   // |1 + R|² = (1 + R)(1 + R)~
export const PH = { ox: 30, oy: 118, u: 72 };                          // the two arrows of the halves (viewBox 420 × 236)
export const PLOT = { x0: 216, x1: 408, y0: 196, y1: 44, top: 4 };     // |1 + R|² from 0 (y0) to 4 (y1) against the turn from 0° (x0) to 720° (x1)
export const plotXY = (phi, g) => ({ x: PLOT.x0 + (PLOT.x1 - PLOT.x0) * phi / MAX, y: PLOT.y0 - (PLOT.y0 - PLOT.y1) * g / PLOT.top });
export const GLOW_PATH = pathOf(samples(MAX, STEP).map(f => plotXY(f, glow(f))));
// |1 + R|² as a value: a whole number when it is one; otherwise two decimals, three near 0 and 4 so that no rounding reads as 0 or 4
export const glowText = g => { const r = Math.round(g); return Math.abs(g - r) < EPS ? String(r) : num(g, g < 0.1 || g > PLOT.top - 0.1 ? 3 : 2); };
// what the physicist's picture draws for a turn by φ: the half that is not turned (p0 → p1), the turned half (p1 → p2, the rotor's direction), their sum
// (p0 → p2), the mark on the curve, and the rotor itself (number part, B part) for the names the picture places
export function glowView(phi) {
  const R = rotor(phi), g = glow(phi), d = Math.round(phi), p1 = { x: PH.ox + PH.u, y: PH.oy }, p2 = { x: p1.x + PH.u * R[0], y: p1.y - PH.u * bPart(R) };
  const p0 = { x: PH.ox, y: PH.oy };
  return {
    g, p0, p1, p2, h1: arrowHead(p0, p1, 14, 7), h2: arrowHead(p1, p2, 14, 7), dot: plotXY(phi, g), valueText: d + '°', rotor: [R[0], bPart(R)]
  };
}
