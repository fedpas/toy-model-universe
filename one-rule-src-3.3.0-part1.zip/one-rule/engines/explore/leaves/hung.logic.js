// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/hung.logic.js — loose leaf Hung under leaf 2 (port of Octavo's octavo/leaves/hung.logic.js; plain functions, no React). A body hangs
// from a spring under a constant weight m g. The law of the spring is an input: it pulls toward its anchor with k times the size of the join of the hooked
// corner and the anchor. The three spaces are the plane-based algebras of four generators e1 e2 e3 e4 with e4² = 0, +1, −1 (the kernel's cells sigVec(3,0,1),
// sigVec(4,0), sigVec(3,1)); a point is the complement of w e4 + x1 e1 + x2 e2 + x3 e3 with w² + e4² |x|² = 1 (the sphere S³ of signed points, one sheet of
// the hyperboloid). Every product and every sign comes from the kernel (engines/labels.js bladeMul and mul, engines/bitrule.js reorderSign for the reverse);
// the join of two points at distance d then has size d, sin d, sinh d, and the body rests where k × size = m g. tests/explore/leaves.hung.test.mjs recomputes
// every number by standard routes (the closed forms, the potentials and their derivatives, arccos and arccosh of the textbook products, the linearised motion).
// Front: the pull of the spring against its stretch, drawn going down beside the hung cube on one scale, and the weight as a line. Backs: the join of two
// points on a line, a circle and a hyperbola (the mathematician; lawView puts each point at its space's rest); the energy valley of spring and weight with a
// nudged ball (the physicist; valley gives the curve for any weight).
// Not carried over (docs/EXPLORE_PORT.md §3): COPY, KEY, UI, MATH_LINES, MATH_CAP and the labels of KIND_LABEL; the sentences of seeView (parts[].text,
// status, alt), mathView (line, alt) and physView (line, curvLine, alt). Their facts are data: parts[].at and .edge, the balances and their kinds, floor.
import { bladeMul, mul, sigVec, springX, squareByBitRule, trinityClass } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';
import { num } from '../shared.js';

// ---- the three spaces: the squares of e1 e2 e3 e4 (e4 is the mask 8)
export const SPACES = ['flat', 'round', 'saddle'];
export const NAMES = { flat: 'Flat', round: 'Round', saddle: 'Saddle' };
export const SQ = { flat: sigVec(3, 0, 1), round: sigVec(4, 0), saddle: sigVec(3, 1) };
export const kappa = s => SQ[s][3];
const NB = 16, FULL = 15, E4 = 8, DIR_MASKS = [1, 2, 4];
// e_m ∧ e_~m = csign(m) e1234: the blades are disjoint, so no square enters and any signature gives the same sign
const csign = m => bladeMul(m, FULL ^ m, SQ.round)[1];
// the complement (a vector goes to a trivector) and its inverse; both are the same in the three spaces
const comp = X => { const o = new Float64Array(NB); for (let m = 0; m < NB; m++) if (X[m]) o[FULL ^ m] += csign(m) * X[m]; return o; };
const uncomp = X => { const o = new Float64Array(NB); for (let m = 0; m < NB; m++) if (X[m]) o[FULL ^ m] += csign(FULL ^ m) * X[m]; return o; };
// the outer product by the bit rule: only disjoint blades meet, each product and its sign from the kernel
const wedge = (sq, X, Y) => { const o = new Float64Array(NB); for (let a = 0; a < NB; a++) if (X[a]) for (let b = 0; b < NB; b++) if (Y[b] && !(a & b)) { const [c, sg] = bladeMul(a, b, sq); o[c] += sg * X[a] * Y[b]; } return o; };
// the reverse: each blade times the kernel's sign of putting its own generators in the reverse order
export const rev = X => X.map((x, m) => (reorderSign(m, m) < 0 ? -x : x));
export const vectorOf = (w, x) => { const V = new Float64Array(NB); V[E4] = w; DIR_MASKS.forEach((m, i) => { V[m] = x[i]; }); return V; };
// a point of the space: the complement of w e4 + x (a trivector)
export const point = (w, x) => comp(vectorOf(w, x));
// the join of two points: the line through them (a bivector)
export const join = (s, P, Q) => uncomp(wedge(SQ[s], comp(P), comp(Q)));
// the size of a line L: the square root of the scalar part of L L~, by the bit rule of the space
export const sizeOf = (s, L) => Math.sqrt(Math.max(0, mul(L, rev(L), SQ[s])[0]));
// the point at distance d from the origin along the unit direction UP: (cos d, sin d), (1, d) or (cosh d, sinh d) for (w, |x|)
export const cosK = (s, d) => (s === 'round' ? Math.cos(d) : s === 'saddle' ? Math.cosh(d) : 1);
export const sinK = (s, d) => (s === 'round' ? Math.sin(d) : s === 'saddle' ? Math.sinh(d) : d);
export const UP = [2 / 7, 3 / 7, 6 / 7];
export const ORIGIN = point(1, [0, 0, 0]);
export const pointAt = (s, d) => point(cosK(s, d), UP.map(c => c * sinK(s, d)));
// the size of the join of two points at distance d (the origin and the point d along UP)
export const span = (s, d) => sizeOf(s, join(s, ORIGIN, pointAt(s, d)));
// how the size is written for each space (the mathematician's panel)
export const FORM = { flat: 'd', round: 'sin d', saddle: 'sinh d' };

// ---- the balance: the pull k × span(d) of the spring against the weight m g
export const pull = (s, k, d) => k * span(s, d);
export const TOP = Math.PI / 2;                       // the pull on the round space rises up to π/2 and falls after it
export const FAR = s => (s === 'round' ? Math.PI : Infinity);   // the largest stretch: on S³ the farthest point is at π
const bisect = (f, lo, hi) => { for (let i = 0; i < 90; i++) { const m = (lo + hi) / 2; if (f(m) < 0) lo = m; else hi = m; } return (lo + hi) / 2; };
// the rest: the stretch where the pull equals the weight, on the part where the pull rises; null when the weight is more than the pull can ever be
export function rest(s, k, mg) {
  const f = d => pull(s, k, d) - mg;
  if (s === 'round') {
    const top = pull(s, k, TOP);
    if (mg > top * (1 + 1e-12)) return null;
    if (mg >= top) return TOP;
    return bisect(f, 0, TOP);
  }
  let hi = 1; while (f(hi) < 0) hi *= 2;
  return bisect(f, 0, hi);
}
// the curvature of the energy at a stretch: the slope of the pull (central difference of the size of the join, one-sided at the ends of the stretch)
const H = 1e-4;
export function curvature(s, k, d) { const a = Math.max(0, d - H), b = Math.min(FAR(s), d + H); return (pull(s, k, b) - pull(s, k, a)) / (b - a); }
// the small motion near a balance is the move of leaf 2 for a spring of strength V″ (the body's mass is the unit): X = ½(1 − V″) e2 + ½(1 + V″) e12, whose square
// is −V″ by the kernel; below zero it is a turn, at zero a slide, above zero a boost
export const MOVES = ['turn', 'slide', 'boost'];
export const EPS = 1e-6;
export const sway = c => { const [a, b, cc] = springX(c / K); return MOVES[trinityClass(squareByBitRule(a, b, cc).scalar, EPS) + 1]; };
export const MEET = 1e-6;
// every balance on the vertical line: the rest, and on the round space the second balance on the falling side of the pull
export function balances(s, k, mg) {
  const d1 = rest(s, k, mg);
  if (d1 === null) return [];
  const c1 = curvature(s, k, d1), out = [{ d: d1, curv: c1, kind: sway(c1) }];
  if (s === 'round') {
    const d2 = d1 >= TOP ? TOP : bisect(d => mg - pull(s, k, d), TOP, Math.PI);
    if (d2 - d1 > MEET) { const c2 = curvature(s, k, d2); out.push({ d: d2, curv: c2, kind: sway(c2) }); } else out[0] = { d: d1, curv: c1, kind: 'slide' };
  }
  return out;
}
// the energy of spring and weight against the stretch, zero at no stretch: the work of stretching against the pull, less what the weight gives back (Simpson's rule)
export function energy(s, k, mg, d) {
  if (d <= 0) return 0;
  const n = 2 * Math.max(4, Math.ceil(d / 0.04)), h = d / n, f = t => pull(s, k, t) - mg;
  let acc = f(0) + f(d);
  for (let i = 1; i < n; i++) acc += (i % 2 ? 4 : 2) * f(i * h);
  return acc * h / 3;
}

// ---- front: the pull against the stretch (drawn going down from the ceiling) beside the hung cube, one scale for both
export const K = 1;                                    // the strength of the spring (the unit of force)
export const W_MAX = 40;                               // the weight counts twentieths of k, from 0 to 2k
export const W_STEP = 2;                               // the stepper of the picture moves the weight by two twentieths: tenths of k
export const weightOf = wv => wv / 20 * K;
export const START = { space: 'flat', wv: 16 };
export const FR = { x0: 46, y0: 46, u: 92, pmax: 2.12, xc: 304, w: 360, h: 362, drop: 2.35, ceil: 40 };
export const fx = p => FR.x0 + FR.u * p;
export const fy = d => FR.y0 + FR.u * d;
// how many lines the label of a balance takes beside its mark (the picture's words for a rest, a balance that tips, one that only just holds)
const LABEL_LINES = { turn: 1, boost: 1, slide: 2 };
export const AXIS = { pull: 'pull of the spring', stretch: 'stretch', weight: 'weight', ticks: [['0', 0], ['k', 1], ['2k', 2]], depth: [1, 2, 3], fall: 'no rest' };
const P2 = (x, y) => x.toFixed(1) + ' ' + y.toFixed(1);
// the path of the pull of one space: from no stretch down to the farthest point of the space, or until it leaves the picture
export function pullPath(s) {
  const pts = [], n = 180, end = Math.PI;
  for (let i = 0; i <= n; i++) { const d = end * i / n, p = pull(s, K, d) / K; pts.push([fx(p), fy(d)]); if (p > FR.pmax) break; }
  return pts.map((q, i) => (i ? 'L' : 'M') + P2(q[0], q[1])).join(' ');
}
export const PULL_PATHS = Object.fromEntries(SPACES.map(s => [s, pullPath(s)]));
// a zigzag spring from (x, y0) down to (x, y1)
export function zigzag(x, y0, y1, turns = 9, amp = 8) {
  if (y1 - y0 < 1) return '';
  const pts = [[x, y0]], lead = Math.min(6, (y1 - y0) / 6), a = y0 + lead, b = y1 - lead;
  pts.push([x, a]);
  for (let i = 1; i < 2 * turns; i++) pts.push([x + (i % 2 ? amp : -amp), a + (b - a) * i / (2 * turns)]);
  pts.push([x, b], [x, y1]);
  return pts.map((q, i) => (i ? 'L' : 'M') + P2(q[0], q[1])).join(' ');
}
// the cube, hung by one corner with its long diagonal vertical, turned a little about the vertical so that three faces show: corners and faces relative to the
// hooked corner, in units of the stretch (x across, y down, z toward the reader)
export const CUBE_DIAG = 0.85, CUBE_TURN = 0.35;
export function cubeShape() {
  const e = CUBE_DIAG / Math.sqrt(3), n = [1, 1, 1].map(c => c / Math.sqrt(3));
  const a1 = [Math.SQRT1_2, -Math.SQRT1_2, 0], a2 = [1, 1, -2].map(c => c / Math.sqrt(6));
  const ax = a1.map((c, i) => Math.cos(CUBE_TURN) * c + Math.sin(CUBE_TURN) * a2[i]), az = a1.map((c, i) => -Math.sin(CUBE_TURN) * c + Math.cos(CUBE_TURN) * a2[i]);
  const dot = (p, q) => p[0] * q[0] + p[1] * q[1] + p[2] * q[2];
  const corners = Array.from({ length: 8 }, (_, b) => { const r = [0, 1, 2].map(i => e * (((b >> i) & 1) - 1)); return { b, x: dot(r, ax), y: -dot(r, n), z: dot(r, az) }; });
  const faces = [];
  for (let i = 0; i < 3; i++) for (const c of [0, 1]) {
    if ((2 * c - 1) * az[i] <= 0) continue;
    const [j, l] = [0, 1, 2].filter(t => t !== i), base = c << i;
    faces.push({ axis: i, idx: [0, 1 << j, (1 << j) | (1 << l), 1 << l].map(m => base | m) });
  }
  return { corners, faces, centre: { x: 0, y: CUBE_DIAG / 2 } };
}
export const CUBE = cubeShape();
export const FACE_SHADE = [0.07, 0.15, 0.24];
// the cube hung with its corner at the stretch d: polygons of the visible faces in picture units
export function cubeAt(d) {
  const y0 = fy(d), X = c => FR.xc + FR.u * c.x, Y = c => y0 + FR.u * c.y;
  return CUBE.faces.map(f => ({ axis: f.axis, pts: f.idx.map(b => P2(X(CUBE.corners[b]), Y(CUBE.corners[b]))).join(' ') }));
}
// the front: the balances of the chosen space on the weight line, the hook, the spring and the cube; parts holds the rest of each space (at: the stretch, or
// null when the weight is more than the pull can be; edge: the two balances of the round space meet at the top of the hump)
export function seeView(space, wv) {
  const mg = weightOf(wv), w = mg / K, all = SPACES.map(s => ({ s, bal: balances(s, K, mg) }));
  const bal = all.find(a => a.s === space).bal, falls = bal.length === 0;
  // the label of a balance: above and right of the rest; right of the one that tips (below it the pull has turned back, away from the weight line); above and
  // right of the one where the two meet
  const marks = bal.map((b, i) => { const x = fx(w), y = fy(b.d), lines = LABEL_LINES[b.kind]; return { ...b, x, y, first: i === 0, lx: x + 13, ly: b.kind === 'boost' ? y + 5 : y - 11 - 16 * (lines - 1) }; });
  const hookD = falls ? FR.drop : bal[0].d, hookY = fy(hookD);
  const parts = all.map(a => ({ s: a.s, on: a.s === space, at: a.bal.length ? a.bal[0].d : null, edge: a.bal.length > 0 && a.bal[0].kind === 'slide' }));
  return {
    space, mg, w, wx: fx(w), all, bal, falls, marks, hookD, hookY, spring: zigzag(FR.xc, FR.y0, hookY), cube: cubeAt(hookD), centreY: hookY + FR.u * CUBE.centre.y,
    guide: falls ? null : { x1: fx(w), x2: FR.xc, y: hookY }, topLine: space === 'round' ? { x: fx(1), y: fy(TOP) } : null,
    parts, wText: 'm g = ' + num(w, 2) + ' k'
  };
}

// ---- back, the mathematician: P and Q at distance d on the line w = 1, the circle w² + x² = 1 and the hyperbola w² − x² = 1 (a slice of each space through the
// origin O, the point P = e4 and the direction UP); the size of the join of P and Q is how far Q stands from the line OP
export const D_MAX = 62;                               // the distance counts twentieths: d from 0 to 3.10
export const distOf = dv => dv / 20;
export const MATH_START = 16;
export const MA = { ox: 112, oy: 238, u: 88, w: 360, h: 344, xmin: -1.25, xmax: 2.75, wmax: 2.6 };
export const mx = x => MA.ox + MA.u * x;
export const my = w => MA.oy - MA.u * w;
export const CURVE_NAME = { flat: 'flat', round: 'round', saddle: 'saddle' };
// the curve of each space in the slice, as a path
export function slicePath(s) {
  const pts = [];
  if (s === 'flat') { pts.push([mx(MA.xmin), my(1)], [mx(MA.xmax), my(1)]); }
  else if (s === 'round') for (let i = 0; i <= 160; i++) { const t = 2 * Math.PI * i / 160; pts.push([mx(Math.sin(t)), my(Math.cos(t))]); }
  else { const xl = Math.sqrt(MA.wmax ** 2 - 1); for (let i = 0; i <= 120; i++) { const x = -xl + 2 * xl * i / 120; pts.push([mx(x), my(Math.sqrt(1 + x * x))]); } }
  return pts.map((q, i) => (i ? 'L' : 'M') + P2(q[0], q[1])).join(' ');
}
export const SLICE_PATHS = Object.fromEntries(SPACES.map(s => [s, slicePath(s)]));
// the arc from P to Q along the curve of a space
export function arcPath(s, d) {
  const n = Math.max(2, Math.ceil(40 * d)), pts = [];
  for (let i = 0; i <= n; i++) { const t = d * i / n; pts.push([mx(sinK(s, t)), my(cosK(s, t))]); }
  return pts.map((q, i) => (i ? 'L' : 'M') + P2(q[0], q[1])).join(' ');
}
export const SLICE_LABEL = { flat: [mx(-1.18), my(1) - 8], round: [mx(0.78), my(-0.86)], saddle: [mx(-1.18), my(1.66)] };
export function mathView(dv) {
  const d = distOf(dv);
  const pts = SPACES.map(s => { const sz = span(s, d), w = cosK(s, d), x = sinK(s, d); return { s, d, w, x, size: sz, X: mx(x), Y: my(w), arc: arcPath(s, d), form: FORM[s], inside: x <= MA.xmax && w <= MA.wmax }; });
  // the names of the three sizes sit to the right of their points, at least 15 apart (saddle above flat above round)
  const order = ['saddle', 'flat', 'round'], tag = {};
  let last = -Infinity;
  for (const s of order) { const p = pts.find(q => q.s === s), y = Math.max(p.Y + 4, last + 15); tag[s] = { x: Math.min(p.X + 9, MA.w - 4), y, anchor: p.X + 9 > MA.w - 40 ? 'end' : 'start' }; last = y; }
  return { d, dText: 'd = ' + num(d, 2), pts, tag, items: pts.map(p => ({ s: p.s, name: CURVE_NAME[p.s], value: p.form + ' = ' + num(p.size, 2) })) };
}
// the one law in the slice: for the weight wv, the point Q of each space at its rest d_s, where the size of the join of P and Q is m g / k (the vertical line
// x = m g / k of the slice); a space whose pull never reaches the weight has no Q (null)
export function lawView(wv) {
  const mg = weightOf(wv), size = mg / K;
  const pts = SPACES.map(s => {
    const d = rest(s, K, mg);
    if (d === null) return { s, d: null, size: null, w: null, x: null, X: null, Y: null, arc: '', inside: false };
    const w = cosK(s, d), x = sinK(s, d);
    return { s, d, size: span(s, d), w, x, X: mx(x), Y: my(w), arc: arcPath(s, d), inside: x <= MA.xmax && w <= MA.wmax };
  });
  return { mg, size, lineX: mx(size), lineIn: mx(size) <= MA.w, pts };
}
export const signed = x => (x > 0 ? '+' : x < 0 ? '−' : '') + Math.abs(x);

// ---- back, the physicist: the energy of spring and weight against the stretch (Octavo's picture: the weight m g = 0.8 k); a ball nudged away from each balance
export const PH_W = 16;                                 // the weight of Octavo's physicist's picture, in twentieths of k
export const NUDGE_MAX = 10;                            // the nudge counts twentieths of the stretch, from −0.5 to +0.5
export const nudgeOf = nv => nv / 20;
export const PH_START = { space: 'round', nv: 6 };
export const PE = { x0: 40, u: 100, top: 30, h: 272, w: 360, vmax: 0.45, vmin: -0.55 };
export const ex = d => PE.x0 + PE.u * d;
export const ey = v => PE.top + (PE.vmax - v) * (PE.h - 42 - PE.top) / (PE.vmax - PE.vmin);
export const VY = (PE.h - 42 - PE.top) / (PE.vmax - PE.vmin);
// the energy curve of one space for the weight wv (twentieths of k)
export function energyPath(s, wv = PH_W) {
  const mg = weightOf(wv), pts = [], n = 160;
  let acc = 0, prev = pull(s, K, 0) - mg;
  pts.push([ex(0), ey(0)]);
  for (let i = 1; i <= n; i++) {
    const a = Math.PI * (i - 1) / n, b = Math.PI * i / n, m = (a + b) / 2, fm = pull(s, K, m) - mg, fb = pull(s, K, b) - mg;
    acc += (b - a) / 6 * (prev + 4 * fm + fb); prev = fb;
    pts.push([ex(b), ey(acc / K)]);
    if (acc / K > PE.vmax + 0.3) break;
  }
  return pts.map((q, i) => (i ? 'L' : 'M') + P2(q[0], q[1])).join(' ');
}
export const ENERGY_PATHS = Object.fromEntries(SPACES.map(s => [s, energyPath(s)]));
// the energy of one space for any weight on the stretches 0 … π, as values [d, V(d)] (Simpson's rule on each of the 160 steps) with its lowest value and the
// balances: the picture fits its frame to them
export function valley(space, wv) {
  const mg = weightOf(wv), n = 160, pts = [[0, 0]];
  let acc = 0, prev = pull(space, K, 0) - mg;
  for (let i = 1; i <= n; i++) {
    const a = Math.PI * (i - 1) / n, b = Math.PI * i / n, fm = pull(space, K, (a + b) / 2) - mg, fb = pull(space, K, b) - mg;
    acc += (b - a) / 6 * (prev + 4 * fm + fb); prev = fb;
    pts.push([b, acc / K]);
  }
  return { space, mg, pts, lo: Math.min(...pts.map(q => q[1])), bal: balances(space, K, mg) };
}
export const PHYS_FORM = { flat: 'V = ½ k d² − m g d', round: 'V = k (1 − cos d) − m g d', saddle: 'V = k (cosh d − 1) − m g d' };
export const BALL_R = 9;
// a ball resting on the curve at the stretch d (screen slope a: the curve rises to the right when a < 0), with the arrow of the push of the slope along the curve,
// downhill; push is the sign of −V′ (−1 toward less stretch, +1 toward more, 0 on level ground)
function ballAt(s, mg, d) {
  const v = energy(s, K, mg, d) / K, slope = (pull(s, K, d) - mg) / K, a = -VY * slope / PE.u, nn = Math.hypot(1, a);
  const cx = ex(d), cy = ey(v), push = Math.abs(slope) < 1e-12 ? 0 : -Math.sign(slope);
  const bx = cx + BALL_R * a / nn, by = cy - BALL_R / nn;
  const len = push ? Math.min(46, 16 + 120 * Math.abs(slope)) : 0, tx = push / nn, ty = push * a / nn, r0 = BALL_R + 3;
  return { d, v, slope, push, x: bx, y: by, lx: Math.min(PE.w - 46, Math.max(PE.x0 + 46, bx)), arrow: push ? { x1: bx + tx * r0, y1: by + ty * r0, x2: bx + tx * (r0 + len), y2: by + ty * (r0 + len) } : null };
}
// what a nudged ball does: pushed back toward its balance it swings back; pushed on, away from it, it runs off
export const fate = b => (b.back ? 'swings back' : b.away ? 'runs off' : 'stays');
// the physicist's picture for a space, a nudge nv and a weight wv (Octavo's picture holds the weight at PH_W); floor: the curvature V″ at the rest of each space
export function physView(space, nv, wv = PH_W) {
  const mg = weightOf(wv), dn = nudgeOf(nv), bal = balances(space, K, mg);
  const balls = bal.map(b => { const q = ballAt(space, mg, b.d + dn); return { ...q, kind: b.kind, at: b.d, mark: { x: ex(b.d), y: ey(energy(space, K, mg, b.d) / K) }, back: q.push !== 0 && q.push === -Math.sign(dn), away: q.push !== 0 && q.push === Math.sign(dn) }; });
  const valley = balls[0] || null, hill = balls[1] || null;
  const floor = SPACES.map(s => { const b = balances(s, K, mg); return { s, c: b.length ? b[0].curv / K : null }; });
  return { space, mg, dn, nText: (dn > 0 ? '+' : '') + num(dn, 2), balls, valley, hill, form: PHYS_FORM[space], floor };
}
export const PH_AXIS = { energy: 'energy', stretch: 'stretch', ticks: [0, 1, 2, 3], named: [0, 1, 2] };
