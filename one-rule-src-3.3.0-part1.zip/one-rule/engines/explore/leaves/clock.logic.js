// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/clock.logic.js — leaf 1, the clock (port of Octavo's octavo/leaves/clock.logic.js; plain functions, no React). Every number comes from
// engines/labels.js (wedderburn, gaussSum, TYPES: the v15 API, every sign the kernel's); tests/explore/leaves.clock.test.mjs recomputes them by standard routes and
// holds them bit-identical to the Octavo output (engines/explore/leaves/stored/clock_octavo.json).
// Front: p plus switches and q minus switches; the hand stands at the hour p − q (mod 8), and the hour names the kind of number of the table. Back, the
// mathematician: every corner of the cube of switches casts a vote i^(plus lit − minus lit), and the sum of the votes points at the same hour (a Gauss sum).
// Back, the physicist: five boxes known from physics, each at its hour.
// Not carried over (docs/EXPLORE_PORT.md): COPY; the notes of move() (the state keeps the button as `kind`), the chip labels of eight() (`op`), the screen-reader
// sentences (hours[].aria, alt, dialAlt), the FRIENDS sentences (say) and the flip sentence (data: `mirror`).
import { gaussSum, popcount, TYPES, wedderburn } from '../../labels.js';
import { KIND, algebra, fmt, hourStep, hourPos, smallest } from '../shared.js';

// ---- front
export const MAX_EACH = 16, MAX_TOTAL = 20;
export const START = { p: 2, q: 0, ang: 90, kind: '' };   // ang: where the hand points, in degrees, summed over every move so that it never jumps back
export const canMove = (p, q) => Number.isInteger(p) && Number.isInteger(q) && p >= 0 && q >= 0 && p <= MAX_EACH && q <= MAX_EACH && p + q <= MAX_TOTAL;
const sg = x => (x < 0 ? '−' : '') + Math.abs(x);
// the state after setting the switches to p plus and q minus; kind names the button that was used ('add' | 'drop' | 'swap' | 'tap' | '')
export function move(s, p, q, kind = '') {
  if (!canMove(p, q)) return s;
  const w0 = wedderburn(s.p, s.q), w1 = wedderburn(p, q), d = hourStep(w0.c, w1.c);
  return { p, q, ang: s.ang + 45 * d, kind };
}
export const tapHour = (s, h) => { const [p, q] = smallest(h); return move(s, p, q, 'tap'); };
export const swapSigns = s => move(s, s.q, s.p, 'swap');
// eight more plus switches when there is room ('add'), else eight fewer ('drop'); with neither possible there is no such move
export function eight(s) {
  if (canMove(s.p + 8, s.q)) return { op: 'add', next: move(s, s.p + 8, s.q, 'add') };
  if (canMove(s.p - 8, s.q)) return { op: 'drop', next: move(s, s.p - 8, s.q, 'drop') };
  return null;
}
export function front(s) {
  const w = wedderburn(s.p, s.q), c = w.c, d = s.p - s.q;
  const hours = TYPES.map((t, h) => ({ h, type: t, letter: KIND[t][0], on: h === c, pos: hourPos(h, 35), num: hourPos(h, 46.5) }));
  const kk = KIND[w.type];
  return {
    w, hour: c, hours, handDeg: -s.ang,
    sumLine: s.p + ' − ' + s.q + ' = ' + sg(d) + (d !== c ? ' ≡ ' + c + ' (mod 8)' : '') + ' → hour ' + c + '.',
    line1: w.copies === 2 ? 'Two ' + fmt(w.k) + ' × ' + fmt(w.k) + ' tables' : fmt(w.k) + ' × ' + fmt(w.k) + ' table',
    line2: (w.copies === 2 ? 'side by side, ' : '') + 'of ' + kk[1] + ' (' + kk[0] + ')',
    pMinusOff: s.p <= 0, qMinusOff: s.q <= 0, pPlusOff: !canMove(s.p + 1, s.q), qPlusOff: !canMove(s.p, s.q + 1)
  };
}
// ---- back, the mathematician
export const BACK_EACH = 10, BACK_TOTAL = 12;
export const canVote = (p, q) => Number.isInteger(p) && Number.isInteger(q) && p >= 0 && q >= 0 && p <= BACK_EACH && q <= BACK_EACH && p + q <= BACK_TOTAL;
// how many corners vote 1, i, −1, −i: a corner with u plus switches and v minus switches lit votes i^(u − v)
export function votes(p, q) {
  const n = p + q, pm = (1 << p) - 1, nm = ((1 << n) - 1) ^ pm, cnt = [0, 0, 0, 0];
  for (let a = 0; a < (1 << n); a++) cnt[(((popcount(a & pm) - popcount(a & nm)) % 4) + 4) % 4]++;
  return cnt;
}
export function voteView(p, q) {
  const g = gaussSum(p, q), cnt = votes(p, q), n = p + q, L = Math.sqrt(2 ** n), mx = Math.max(...cnt);
  const bars = cnt.map((N, j) => { const h = N === 0 ? 1.5 : Math.max(3, 150 * N / mx), x = 12 + j * 50; return { x, y: 205 - h, h, n: N, lp: (x + 17) / 4.8, tp: (205 - h - 13) / 2.6 }; });
  const ux = g.re / L, uy = g.im / L, cx = 348, cy = 130, R = 92;
  const net = sg(g.re) + (g.im < 0 ? ' − ' : ' + ') + Math.abs(g.im) + 'i';
  return {
    g, cnt, n, bars, hour: g.c, tip: { x: cx + R * ux, y: cy - R * uy }, end: { x: cx + (R - 5) * ux, y: cy - (R - 5) * uy },
    line: (1 << n) + ' votes. Net: ' + net + (Math.abs(L - Math.round(L)) < 1e-9 ? ', length ' + Math.round(L) : ', length ' + L.toFixed(2)) + ', pointing at hour ' + g.c + '.'
  };
}
export const START_VOTES = { p: 3, q: 1 };

// ---- back, the physicist: five boxes, each named by the system it describes
export const FRIENDS = [
  { name: 'A phase', p: 0, q: 1 },
  { name: '3-D rotations', p: 0, q: 2 },
  { name: 'Electron spin', p: 3, q: 0 },
  { name: 'Spacetime, + − − −', p: 1, q: 3 },
  { name: 'Spacetime, + + + −', p: 3, q: 1 }
];
export const START_FRIEND = { f: 2, angF: 135 };
export const pickFriend = (s, i) => ({ f: i, angF: s.angF + 45 * hourStep(wedderburn(FRIENDS[s.f].p, FRIENDS[s.f].q).c, wedderburn(FRIENDS[i].p, FRIENDS[i].q).c) });
// mirror: every sign flipped (+ ↔ −), Cl(q,p), at hour (8 − c) mod 8
export function friendView(s) {
  const fr = FRIENDS[s.f], w = wedderburn(fr.p, fr.q), c = w.c, mir = (8 - c) % 8, wm = wedderburn(fr.q, fr.p);
  const list = FRIENDS.map((x, i) => { const wx = wedderburn(x.p, x.q); return { i, name: x.name, p: x.p, q: x.q, algebra: algebra(wx), hour: wx.c, type: wx.type, on: i === s.f }; });
  const dots = TYPES.map((t, h) => ({ h, ...hourPos(h, 40), on: h === c }));
  return {
    list, dots, w, hour: c, handDeg: -s.angF, head: 'Cl(' + fr.p + ',' + fr.q + ') = ' + algebra(w),
    mirror: { p: fr.q, q: fr.p, hour: mir, algebra: algebra(wm), self: mir === c }
  };
}
