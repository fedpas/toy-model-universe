// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/fall.logic.js — leaf 7, fall (port of Octavo's octavo/leaves/fall.logic.js; plain functions, no React). Every number comes from
// engines/labels.js (pgG, pgRays, pgClass, pgSquareByBitRule, mul in Cl(1,1): the v15 API, every sign the kernel's); tests/explore/leaves.fall.test.mjs recomputes
// them by standard routes (the metric's light cone, geodesics, Newton, matrices, closed forms) and holds them bit-identical to the Octavo output.
// Around a mass M, space and time in the form ds² = dt² − (dr + g dt)² with g = √(2M/r): rain let go far away falls with dr/dt = −g, light runs with
// dr/dt = −g ± 1, and X = e_r + g e_t of Cl(1,1) squares to g² − 1: below zero outside r = 2M, zero on it, above zero inside (pgClass). T = e_t + g e_r points along a
// sphere r = const; its square is 1 − g². Front: a drop of rain falling through the light cones, its speed for someone holding still, the paths of light sent from
// the drop. Back: X tipping over the light line (mathematician); Newton's stone let go far away, whose speed is the same function √(2M/r) (physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY, MATH_CAP, PHYS_CAP, the `say` words of STATES; the sentences of frontView (status, alt, dialAlt, dialSmall),
// mathView (line, alt) and physView (line, alt). Their facts are the data already returned (cls, g, edge, end, speedText, dialBig); mathView and physView carry
// a readout of their numbers instead (`readout`: g and X², M and 2M).
import { mul, mvZero, pgClass, pgG, pgRays, pgSquareByBitRule } from '../../labels.js';
import { num } from '../shared.js';

// ---- units of the front: the mass is M = 1/2, so that the horizon r = 2M sits at r = 1; time is counted on the rain's own clock, and light covers 1 per tick
export const M_FRONT = 0.5;
export const gOf = (r, M = M_FRONT) => pgG(r, M);
// dr/dt of light sent outward ('out'), of light sent inward ('inn') and of the rain ('rain') at the distance r
export const slope = (r, kind, M = M_FRONT) => pgRays(pgG(r, M))[kind];
// the three places, by the sign of X² (pgClass: −1, 0, +1); mark: the way light sent outward goes in the picture (up and out, straight up, up and in)
export const STATES = [
  { cls: -1, where: 'Outside', mark: 'out' },
  { cls: 0, where: 'On the horizon', mark: 'still' },
  { cls: 1, where: 'Inside', mark: 'in' }
];
export const stateOf = g => STATES[pgClass(g) + 1];

// ---- the distance control of the front: twentieths of r, from 0.3 to 3; the horizon r = 1 is at 20
export const V_MIN = 6, V_MAX = 60, V_HORIZON = 20;
export const rOfV = v => v / 20;
export const vOfR = r => Math.min(V_MAX, Math.max(V_MIN, Math.round(r * 20)));
export const R_MIN = rOfV(V_MIN), R_MAX = rOfV(V_MAX);
// where the horizon sits on the control (a fraction of the thumb's travel) and its track coloured by the sign of X² there: inside (left), on it, outside;
// the stops sit at the centre of the thumb (30 px wide) when it stands on the horizon (the three colours are passed in as design tokens)
export const H_FRAC = (V_HORIZON - V_MIN) / (V_MAX - V_MIN);
export const THUMB = 30;
export const hAt = (dpx = 0) => 'calc(' + (THUMB / 2) + 'px + (100% - ' + THUMB + 'px) * ' + H_FRAC.toFixed(4) + (dpx ? (dpx > 0 ? ' + ' : ' - ') + Math.abs(dpx) + 'px' : '') + ')';
export const frontTrack = (inside, on, outside) => 'linear-gradient(90deg, ' + inside + ' 0, ' + inside + ' ' + hAt(-5) + ', ' + on + ' ' + hAt(-5) + ', ' + on + ' ' + hAt(5) + ', ' + outside + ' ' + hAt(5) + ', ' + outside + ' 100%)';

// ---- the picture of the front: distance r to the right (the centre at the left edge), time t up, one unit the same length both ways
export const FIG = { w: 400, h: 494, x0: 30, u: 112, y0: 440, top: 14, right: 390, axis: 452 };
export const px = r => FIG.x0 + FIG.u * r;
export const py = t => FIG.y0 - FIG.u * t;
export const R_AX = (FIG.right - FIG.x0) / FIG.u;          // the largest distance in the picture
export const T_TOP = (FIG.y0 - FIG.top) / FIG.u;           // the latest time in the picture
export const T_LOW = (FIG.y0 - FIG.axis) / FIG.u;          // the earliest (below zero: the axis sits a little under t = 0)
const f1 = x => x.toFixed(1);
export const toPath = pts => pts.map((p, i) => (i ? 'L' : 'M') + f1(px(p[0])) + ' ' + f1(py(p[1]))).join(' ');

// the rain's clock at the distance r: t(r) = ∫ dr / (dr/dt) from R_START, where the drop is at t = 0; Simpson's rule in u = √r, which keeps the integrand smooth down to r = 0
export const R_START = 3;
export function rainT(r) {
  const a = Math.sqrt(R_START), b = Math.sqrt(r), N = 32, h = (b - a) / N;
  const f = u => (u <= 0 ? 0 : 2 * u / slope(u * u, 'rain'));
  let s = f(a) + f(b);
  for (let i = 1; i < N; i++) s += (i % 2 ? 4 : 2) * f(a + i * h);
  return s * h / 3;
}
// the path of the rain in the picture, from beyond the right edge down to the centre (points dense near the centre, where it bends most)
export const RAIN_PTS = Array.from({ length: 121 }, (_, i) => { const r = 3.3 * (1 - i / 120) ** 2; return [r, rainT(r)]; });
export const RAIN_PATH = toPath(RAIN_PTS);

// one step of dr/dt = slope(r, kind) by the classical Runge–Kutta rule
export function rk4(r, h, kind) {
  const k1 = slope(r, kind), k2 = slope(r + h * k1 / 2, kind), k3 = slope(r + h * k2 / 2, kind), k4 = slope(r + h * k3, kind);
  return r + h * (k1 + 2 * k2 + 2 * k3 + k4) / 6;
}
// the path of light sent from (r0, t0), outward or inward, until it leaves the picture (top or right) or reaches the centre; near the centre the slope grows
// without bound, so the steps shrink with r (the last 0.001 of distance takes a time of order 0.001^1.5 and is closed at r = 0)
export const DT_RAY = 0.01, R_STOP = 1e-3;
export function traceRay(r0, t0, kind) {
  const pts = [[r0, t0]]; let r = r0, t = t0;
  while (t < T_TOP - 1e-12 && pts.length < 5000) {
    const f = slope(r, kind); let h = Math.min(DT_RAY, T_TOP - t);
    if (f < 0) h = Math.min(h, 0.2 * r / -f);
    const rn = rk4(r, h, kind);
    if (rn > R_AX) { const k = (R_AX - r) / (rn - r); pts.push([R_AX, t + k * h]); break; }
    r = rn; t += h;
    if (r < R_STOP) { pts.push([0, t]); break; }
    pts.push([r, t]);
  }
  return pts;
}
// a light cone of height h at (r0, t0): its tip and the ends of its two edges (light outward, light inward), and the sign of X² there
export function cone(r0, t0, h) {
  const g = gOf(r0), ray = pgRays(g);
  return { o: [r0, t0], out: [r0 + ray.out * h, t0 + h], inn: [r0 + ray.inn * h, t0 + h], cls: pgClass(g) };
}
export const conePts = c => [c.o, c.out, c.inn].map(p => f1(px(p[0])) + ',' + f1(py(p[1]))).join(' ');
// the small cones of the picture: a band near the bottom and one near the top, clear of the rain's path
export const CONE_H = 0.3, PROBE_H = 0.4;
export const CONES = [[0.45, 0.22], [0.75, 0.22], [1, 0.22], [1.4, 0.22], [1.9, 0.22], [2.4, 0.22], [1.35, 3.25], [1.85, 3.25], [2.4, 3.25], [2.95, 3.25]].map(([r, t]) => cone(r, t, CONE_H));
// a filled triangle at the end q of a line coming from p (picture units), for the arrows
export function arrowTip(p, q, L = 12, W = 5.5) {
  const dx = q[0] - p[0], dy = q[1] - p[1], n = Math.hypot(dx, dy) || 1, ux = dx / n, uy = dy / n, bx = q[0] - ux * L, by = q[1] - uy * L;
  return [[q[0], q[1]], [bx - uy * W, by + ux * W], [bx + uy * W, by - ux * W]].map(p2 => f1(p2[0]) + ',' + f1(p2[1])).join(' ');
}
const lastDir = pts => { const q = pts[pts.length - 1]; let j = pts.length - 2; while (j > 0 && Math.hypot(px(q[0]) - px(pts[j][0]), py(q[1]) - py(pts[j][1])) < 8) j--; return [[px(pts[j][0]), py(pts[j][1])], [px(q[0]), py(q[1])]]; };

// ---- the dial: the rain's speed for someone holding still, 0 at the left, light's speed at 30°; past it, a zone where no reading is given
export const DIAL = { w: 270, h: 158, cx: 135, cy: 132, R: 104 };
export const dialAng = s => Math.PI - (5 * Math.PI / 6) * Math.min(1, Math.max(0, s));
export const ZONE_ANG = Math.PI / 12;
export const dialPt = (a, R = DIAL.R) => [DIAL.cx + R * Math.cos(a), DIAL.cy - R * Math.sin(a)];
export function dialArc(a0, a1, R = DIAL.R) { const p = dialPt(a0, R), q = dialPt(a1, R); return 'M' + f1(p[0]) + ' ' + f1(p[1]) + ' A' + R + ' ' + R + ' 0 0 1 ' + f1(q[0]) + ' ' + f1(q[1]); }
export const DIAL_TICKS = [0, 0.25, 0.5, 0.75, 1].map(s => { const a = dialAng(s); return { s, a, p: dialPt(a, DIAL.R + 9), q: dialPt(a, DIAL.R + 17) }; });

// ---- the animation of the front: the drop falls on its own clock (dr/dt = −g), from r = 3 down to 0.3; there it fades, waits, and falls again
export const START = { r: R_MAX, out: false, hold: 0 };
export const FALL_SPEED = 0.8, HOLD = 1.2, DT_FALL = 0.005;   // ticks of the rain's clock per second of the screen; the wait in seconds; the step
export function advance(s, dt) {
  if (s.out) { const hold = s.hold + dt; return hold > HOLD ? { ...START } : { ...s, hold }; }
  let r = s.r, left = dt * FALL_SPEED;
  while (left > 1e-12) { const h = Math.min(DT_FALL, left); r = rk4(r, h, 'rain'); left -= h; }
  return r <= R_MIN ? { r: R_MIN, out: true, hold: 0 } : { r, out: false, hold: 0 };
}
export const setDistance = v => ({ r: rOfV(v), out: false, hold: 0 });

export function frontView(s) {
  const r = s.r, g = gOf(r), cls = pgClass(g), st = STATES[cls + 1], t = rainT(r), rT = num(r, 2), sp = num(g, 2);
  const probe = cone(r, t, PROBE_H), out = traceRay(r, t, 'out'), inn = traceRay(r, t, 'inn');
  const needle = cls > 0 ? ZONE_ANG : dialAng(g);
  return {
    r, g, cls, t, st, v: vOfR(r), op: s.out ? 0.35 : 1,
    drop: [px(r), py(t)], probe, probePts: conePts(probe), outPath: toPath(out), innPath: toPath(inn), out, inn,
    outTip: out.length > 1 && out[out.length - 1][0] > 0 ? arrowTip(...lastDir(out)) : null,
    innTip: inn.length > 1 && inn[inn.length - 1][0] > 0 ? arrowTip(...lastDir(inn)) : null,
    needle, needleEnd: dialPt(needle, DIAL.R - 20), fillArc: cls > 0 ? dialArc(Math.PI, 0) : dialArc(Math.PI, dialAng(g)),
    rText: rT, speedText: sp,
    dialBig: cls < 0 ? sp : cls === 0 ? '1' : ''
  };
}

// ---- the vectors of the back: X = e_r + g e_t, the normal of a sphere r = const (pgSquareByBitRule squares it), and T = e_t + g e_r, along the sphere.
// Cl(1,1): e_t is bit 1 (squares to +1), e_r is bit 2 (squares to −1), e_t e_r is blade 3.
const SQ11 = [1, -1];
const vec = (et, er) => { const X = mvZero(2); X[1] = et; X[2] = er; return X; };
export const holdSquare = g => mul(vec(1, g), vec(1, g), SQ11)[0];                       // T² = 1 − g²
export function pairXT(g) { const P = mul(vec(g, 1), vec(1, g), SQ11); return { dot: P[0], wedge: P[3], vec: Math.abs(P[1]) + Math.abs(P[2]) }; }   // X·T and X∧T

// ---- back, the mathematician: the plane of e_r (right) and e_t (up), X tipping over the light line, and a number line of X² under it
export const GV_MIN = 0, GV_MAX = 40;                     // twentieths of g, from 0 to 2
export const MP = { w: 360, h: 322, ox: 54, oy: 236, u: 92, right: 348, top: 14, ly: 290, lx0: 40, lx1: 340, sqMin: -1, sqMax: 3 };
export const mx = r => MP.ox + MP.u * r, my = t => MP.oy - MP.u * t;
export const sqX = s => MP.lx0 + (s - MP.sqMin) / (MP.sqMax - MP.sqMin) * (MP.lx1 - MP.lx0);
const RW = (MP.right - MP.ox) / MP.u, TW = (MP.oy - MP.top) / MP.u;
const pp = pts => pts.map(([r, t]) => f1(mx(r)) + ',' + f1(my(t))).join(' ');
export const SPACE_WEDGE = pp([[0, 0], [RW, 0], [RW, TW], [TW, TW]]);   // below the light line: X² < 0
export const TIME_WEDGE = pp([[0, 0], [TW, TW], [0, TW]]);               // above it: X² > 0
export const LIGHT_END = [mx(TW), my(TW)];
export function mathView(gv) {
  const g = gv / 20, X2 = pgSquareByBitRule(g), T2 = holdSquare(g), cls = pgClass(g), xt = pairXT(g);
  const tip = [mx(1), my(g)], ttip = [mx(g), my(1)], o = [mx(0), my(0)];
  return { g, X2, T2, cls, xt, tip, ttip, xTip: arrowTip(o, tip), tTip: arrowTip(o, ttip, 10, 4.5), dot: sqX(X2), readout: 'g = ' + num(g, 2) + ' · X² = ' + num(X2, 2) };
}

// ---- back, the physicist: the speed of a falling thing against the distance r, for a pull M
export const MV_MIN = 1, MV_MAX = 10;                      // quarters of M, from 0.25 to 2.5
export const PH = { w: 360, h: 300, x0: 48, u: 29, y0: 256, v: 140, rMax: 10, sMax: 1.6, top: 26 };
export const qx = r => PH.x0 + PH.u * r, qy = s => PH.y0 - PH.v * s;
export const newtonSpeed = (M, r) => Math.sqrt(2 * M / r); // Newton, for a stone let go far away: ½v² − M/r = 0
const toQ = pts => pts.map((p, i) => (i ? 'L' : 'M') + f1(qx(p[0])) + ' ' + f1(qy(p[1]))).join(' ');
export function physView(mv) {
  const M = mv / 4, edge = 2 * M, N = 120;
  // the rain, for someone holding still at r: only where holding still is possible, T² ≥ 0 (the end point is the horizon, where T² = 0)
  const rain = []; for (let i = 0; i <= N; i++) { const r = edge + (PH.rMax - edge) * i / N, g = pgG(r, M); if (holdSquare(g) >= 0) rain.push([r, g]); }
  const r0 = edge / (PH.sMax * PH.sMax), newton = []; for (let i = 0; i <= N; i++) { const r = r0 + (PH.rMax - r0) * i / N; newton.push([r, newtonSpeed(M, r)]); }
  const end = [edge, pgG(edge, M)];
  return { M, edge, rain, newton, end, rainPath: toQ(rain), newtonPath: toQ(newton), endXY: [qx(end[0]), qy(end[1])], edgeX: qx(edge), readout: 'M = ' + num(M, 2) + ' · 2M = ' + num(edge, 2) };
}
export const PHYS_TICKS = [0, 2, 4, 6, 8, 10];
