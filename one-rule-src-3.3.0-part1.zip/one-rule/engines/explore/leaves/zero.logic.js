// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/zero.logic.js — leaf 5, zero (port of Octavo's octavo/leaves/zero.logic.js; plain functions, no React). Every product comes from
// engines/labels.js (bladeMul, mul: the kernel's), the reverse from the kernel's reorderSign(m, m), the exact determinants from engines/schullerEngine.js;
// tests/explore/leaves.zero.test.mjs recomputes them by standard routes and holds them bit-identical to the Octavo output.
// Front: three switches, each squaring to +1, −1 or 0, and the cube of their eight corners. A corner that holds a zero switch is drawn dashed; the product of two
// tapped corners (e_a e_b = s(a,b) e_(a xor b)) is nothing exactly when the two share a zero switch. Back, the mathematician: the corners of Cl(p,q,r) stacked by how
// many zero switches they hold (the layers of the radical J), and x = a + b e₀ with one zero switch alone. Back, the physicist: a rod on a line in R(1,0,1).
// Not carried over (docs/EXPLORE_PORT.md): COPY, DUAL_INTRO, SLIDE_INTRO, SLIDE_NOTE; the sentences of front() (key, why, alt, the aria of corners and switches:
// the zero switches and the shared ones are data, `zeros` and `shared`), of layerView (line, alt), dualView (line, alt: a readout of its formulas instead,
// `readout`) and slideView (line, alt).
import { bladeMul, bladeName, mul, popcount, sigVec } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';
import { bareissDet, leftMatrix } from '../../schullerEngine.js';
import { sub } from '../shared.js';

// ---- small formatters: a number with at most two decimals (true minus sign), a + b u, and a formula that a line never breaks (no-break spaces)
const trim = x => { const t = Math.abs(x).toFixed(2).replace(/\.?0+$/, ''); return (x < 0 && t !== '0' ? '−' : '') + t; };
export const exact2 = x => Math.abs(Math.round(x * 100) - x * 100) < 1e-6;      // shown exactly with two decimals
export const nb = t => t.replace(/ /g, ' ');
export const lin = (c0, c1, unit) => {
  const z0 = Math.abs(c0) < 1e-12, z1 = Math.abs(c1) < 1e-12, times1 = Math.abs(Math.abs(c1) - 1) < 1e-12 ? unit : trim(Math.abs(c1)) + ' ' + unit;
  if (z0 && z1) return '0';
  if (z1) return trim(c0);
  if (z0) return nb((c1 < 0 ? '−' : '') + times1);
  return nb(trim(c0) + (c1 < 0 ? ' − ' : ' + ') + times1);
};

// ---- front: three switches and the cube of their corners
export const N = 3;
export const START = { eps: [1, -1, 0], tray: [5, 4] };                 // switches + − 0; in the tray e₁₃ × e₃
export const nextSign = e => (e === 1 ? -1 : e === -1 ? 0 : 1);          // a tap turns + into −, − into 0, 0 into +
export const zeroMask = eps => eps.reduce((m, e, i) => (e === 0 ? m | (1 << i) : m), 0);
export const nameOf = a => (a === 0 ? '1' : 'e' + sub(bladeName(a).slice(1)));       // e₁₃
export const spoken = a => (a === 0 ? '1' : bladeName(a));                          // e13, for a control's accessible name
export const E0 = 'e' + sub(bladeName(1, -1).slice(1)), E01 = 'e' + sub(bladeName(3, -1).slice(1));      // e₀ and e₀₁ of the back (bit 0 named 0)
// the product of two corners: e_a e_b = s e_c, and s = 0 means nothing
export function times(a, b, eps) { const [c, s] = bladeMul(a, b, eps); return { c, s: s === 0 ? 0 : s }; }
export const tapSwitch = (s, i) => ({ ...s, eps: s.eps.map((e, j) => (j === i ? nextSign(e) : e)) });
// a tap puts a corner in the tray: the second of a pair, or the first of a new pair
export const tapCorner = (s, a) => ({ ...s, tray: s.tray.length === 1 ? [s.tray[0], a] : [a] });
// where the corners sit in the picture, a box of 400 × 330: switch 1 to the right, switch 2 up, switch 3 into the page
export const BOX = { w: 400, h: 330 };
const ORIGIN = [40, 294], AXES = [[190, 0], [0, -170], [110, -90]];
export const cornerAt = a => AXES.reduce(([x, y], [dx, dy], i) => (a >> i & 1 ? [x + dx, y + dy] : [x, y]), ORIGIN);
// zeros: the names of the zero switches; shared: the zero switches the two tapped corners both hold (the product is nothing exactly when there is one)
export function front(s) {
  const eps = s.eps, Z = zeroMask(eps), zs = eps.map((e, i) => i).filter(i => Z >> i & 1).map(i => nameOf(1 << i));
  const [a, b] = s.tray, pr = s.tray.length === 2 ? times(a, b, eps) : null;
  const corners = Array.from({ length: 1 << N }, (_, c) => {
    const [x, y] = cornerAt(c), zero = (c & Z) !== 0, picked = s.tray.includes(c), result = !!pr && pr.s !== 0 && pr.c === c;
    return { c, name: nameOf(c), x, y, left: 100 * x / BOX.w, top: 100 * y / BOX.h, zero, picked, result };
  });
  const edges = [];
  for (let c = 0; c < 1 << N; c++) for (let i = 0; i < N; i++) if (!(c >> i & 1)) { const [x1, y1] = cornerAt(c), [x2, y2] = cornerAt(c | 1 << i); edges.push({ x1, y1, x2, y2, i, zero: eps[i] === 0 }); }
  const switches = eps.map((e, i) => ({ i, e, name: nameOf(1 << i), sq: e === 1 ? '+1' : e === -1 ? '−1' : '0' }));
  const held = corners.filter(c => c.zero).length, r = zs.length;
  let eq = '', shared = [];
  if (s.tray.length === 1) eq = nameOf(a) + ' × …';
  if (pr) {
    shared = eps.map((e, i) => i).filter(i => (a & b & Z) >> i & 1).map(i => nameOf(1 << i));
    eq = nameOf(a) + ' × ' + nameOf(b) + ' = ' + (pr.s === 0 ? 'nothing' : (pr.s < 0 ? '−' : '') + nameOf(pr.c));
  }
  return { corners, edges, switches, r, held, zeros: zs, shared, eq, product: pr };
}

// ---- back, the mathematician: the layers of Cl(p,q,r) (sigVec puts the r zero switches last)
export const MAX_N = 5;                                                   // at most 32 corners in the picture
export const START_LAYERS = { p: 1, q: 1, r: 2 };
export const canLayers = (p, q, r) => [p, q, r].every(v => Number.isInteger(v) && v >= 0) && p + q + r <= MAX_N;
export const zeroBits = (p, q, r) => ((1 << r) - 1) << (p + q);
// the corners sorted by how many zero switches they hold: rows[k] is layer k
export function layersOf(p, q, r) {
  const n = p + q + r, Z = zeroBits(p, q, r), rows = Array.from({ length: r + 1 }, () => []);
  for (let a = 0; a < 1 << n; a++) rows[popcount(a & Z)].push(a);
  return rows;
}
// J, J², J³ …: the corners that products of k dashed corners reach (out[k − 1]); the list ends with the first empty power, J^(r+1)
export function powersOf(p, q, r) {
  const sq = sigVec(p, q, r), n = p + q + r, Z = zeroBits(p, q, r), J = [];
  for (let a = 0; a < 1 << n; a++) if (a & Z) J.push(a);
  const out = [new Set(J)];
  while (out[out.length - 1].size) {
    const next = new Set();
    for (const a of out[out.length - 1]) for (const b of J) { const [c, s] = bladeMul(a, b, sq); if (s !== 0) next.add(c); }
    out.push(next);
  }
  return out;
}
// the picture: each layer a band of dots (16 a line), the bottom layer at the bottom; labels k = … on the left, the count on the right
export const TOWER = { w: 360, per: 16, gap: 15, lineH: 17, rowGap: 14, dot: 5.5, cx: 191, pad: 12, band: 11 };
export function layerView(p, q, r) {
  const rows = layersOf(p, q, r), pw = powersOf(p, q, r), loewy = pw.length, counts = rows.map(x => x.length), total = counts.reduce((x, y) => x + y, 0);
  const T = TOWER, hs = rows.map(cs => Math.ceil(cs.length / T.per) * T.lineH), h = hs.reduce((x, y) => x + y, 0) + T.rowGap * r + 2 * T.pad;
  let y = h - T.pad;
  const drawn = rows.map((cs, k) => {
    const dots = cs.map((c, i) => { const ln = Math.floor(i / T.per), inLine = Math.min(T.per, cs.length - ln * T.per), j = i - ln * T.per; return { c, x: T.cx + (j - (inLine - 1) / 2) * T.gap, y: y - hs[k] + T.lineH * (ln + 0.5) }; });
    const xs = dots.map(d => d.x), band = { x: Math.min(...xs) - T.band, y: y - hs[k] - 2, w: Math.max(...xs) - Math.min(...xs) + 2 * T.band, h: hs[k] + 4 };
    const row = { k, count: cs.length, dots, band, mid: y - hs[k] / 2, zero: k > 0 };
    y -= hs[k] + T.rowGap;
    return row;
  });
  return { rows: drawn, counts, total, loewy, h };
}
// det L_x on Cl(p,q,r) against det L_x̄ on Cl(p,q), where x̄ is the part of x on the solid corners (x: { label: integer coefficient }, exact)
export function undo(p, q, r, x) {
  const Z = zeroBits(p, q, r), bar = {};
  for (const [a, v] of Object.entries(x)) if (!(+a & Z)) bar[a] = v;
  const det = bareissDet(leftMatrix(x, sigVec(p, q, r))), detBar = bareissDet(leftMatrix(bar, sigVec(p, q))), want = detBar ** BigInt(2 ** r);
  return { det, detBar, want, ok: det === want };
}

// ---- back, the mathematician: one zero switch alone, x = a + b e₀ (the algebra Cl(0,0,1))
export const DUAL_MIN = -8, DUAL_MAX = 8;                                 // quarters: a and b from −2 to 2
export const START_DUAL = { av: 6, bv: 8 };                               // a = 1.5, b = 2
export const PLANE = { w: 200, h: 140, x0: 100, y0: 70, ua: 40, ub: 28 };
export function dualView(av, bv) {
  const a = av / 4, b = bv / 4, x = Float64Array.of(a, b), x2 = mul(x, x, [0]);
  // L_x is 2 × 2, so det L_x = det L_(4x) / 16; 4x has integer coefficients
  const det = Number(undo(0, 0, 1, { 0: av, 1: bv }).det) / 16, can = det !== 0;
  const inv = can ? [1 / a, -b / (a * a)] : null;
  const near = can && !(exact2(inv[0]) && exact2(inv[1]));
  const P = PLANE, dot = { x: P.x0 + P.ua * a, y: P.y0 - P.ub * b };
  const readout = [nb('det Lₓ = ' + trim(det)), can ? nb('1/x ' + (near ? '≈ ' : '= ') + lin(inv[0], inv[1], E0)) : null, nb('x² = ' + lin(x2[0], x2[1], E0))].filter(Boolean).join(' · ');
  return { a, b, x2: Array.from(x2), det, can, inv, near, dot, readout, aText: 'a = ' + trim(a), bText: 'b = ' + trim(b) };
}

// ---- back, the physicist: a rod on a line, in R(1,0,1): bit 0 is the zero switch e₀ (square 0), bit 1 the switch e₁ of the line (square +1)
export const PGA = [0, 1];
export const SLIDE_MIN = -4, SLIDE_MAX = 4;                               // halves: each slide from −2 to 2
export const START_SLIDES = { av: 3, bv: -1 };                            // a = 1.5, b = −0.5
export const HALF = 1;                                                    // the rod has length 2: its ends start at −1 and +1
export const translator = a => { const T = new Float64Array(4); T[0] = 1; T[3] = -a / 2; return T; };        // 1 − (a/2) e₀₁
// the reverse: the sign of each blade e_m reversed is the kernel's reordering sign of e_m with itself, (−1)^(k(k−1)/2) for grade k
export const reverse = X => X.map((v, m) => (reorderSign(m, m) < 0 ? -v : v));
// a point of the line: the right complement of e₀ + x e₁ (e_m times its complement is +e₀₁, as in step 16), and where a point is
export function point(x) { const V = Float64Array.of(0, 1, x, 0), P = new Float64Array(4); for (let m = 0; m < 4; m++) if (V[m]) { const s = bladeMul(m, 3 ^ m, PGA)[1]; P[3 ^ m] += s * V[m]; } return P; }
export const placeOf = P => -P[1] / P[2];
export const sandwich = (M, X) => mul(mul(M, X, PGA), reverse(M), PGA);
export const TRACK = { w: 360, h: 170, x0: 180, unit: 32, y: 132 };      // the line from −5.4 to 5.4
export const toX = x => TRACK.x0 + TRACK.unit * x;
export function slideView(av, bv) {
  const a = av / 2, b = bv / 2, Ta = translator(a), Tb = translator(b), M = mul(Ta, Tb, PGA);
  const from = [-HALF, HALF], to = from.map(x => placeOf(sandwich(M, point(x)))), d = to[0] - from[0];
  const motorParts = ['(' + lin(Ta[0], Ta[3], E01) + ')(' + lin(Tb[0], Tb[3], E01) + ')', nb('= ' + lin(M[0], M[3], E01))], motor = motorParts.join(' ');
  const arrows = [{ k: 'a', x1: toX(0), x2: toX(a), y: 86, len: a }, { k: 'b', x1: toX(a), x2: toX(a + b), y: 48, len: b }].filter(w => Math.abs(w.len) > 1e-9);
  const ticks = Array.from({ length: 11 }, (_, i) => ({ v: i - 5, x: toX(i - 5), label: (i - 5) % 2 === 0 ? trim(i - 5) : '' }));
  return { a, b, Ta, Tb, M, from, to, d, motor, motorParts, arrows, ticks, aText: 'a = ' + trim(a), bText: 'b = ' + trim(b),
    rod0: { x: toX(from[0]), w: toX(from[1]) - toX(from[0]) }, rod: { x: toX(to[0]), w: toX(to[1]) - toX(to[0]) }, ends: to.map(toX) };
}
