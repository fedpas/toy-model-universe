// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/seats.logic.js — loose leaf "Seats" under leaf 5 (port of Octavo's octavo/leaves/seats.logic.js; plain functions, no React). Every product
// of Cl(3,3) is engines/labels.js's mul (the kernel's), the sign read from a name is the kernel's reorderSign; tests/explore/leaves.seats.test.mjs recomputes them by
// standard routes (Jordan–Wigner matrices, exact ranks, direct counts, integer arithmetic on the names) and holds them bit-identical to the Octavo output.
// Three seats, each empty or full, make eight patterns. The moves live in Cl(3,3): e1 e2 e3 (bits 0, 1, 2) square to +1 and f1 f2 f3 (bits 3, 4, 5) to −1;
// "add one to seat k" is c⁺k = ½(ek + fk), "take one away" is ck = ½(ek − fk). The empty pattern is the product of the ck c⁺k, and the pattern with the seats
// s1 < s2 < … full is c⁺s1 c⁺s2 … applied to it. A blade of Cl(3,3) belongs to the pattern of the seats where its e bit and its f bit differ, so each pattern owns
// eight of the 64 blades. Front: the seats, the eight patterns as the corners of a cube, three names for a pattern (bits, numbers, primes: ../names.js). Back: the
// table of c⁺k and its square, the trace of aa⁺ − a⁺a (mathematician); an atom with three states (physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY, namesCaption, ruleLine, TRACE_LINE, EXCLUSION_LINE; the sentences of readout (note: the event is in the state,
// s.ev), frontView (caption, alt, the labels of the seat buttons), mathView (land, rule, alt, sqAlt), traceView (alt) and atomView (line, alt, countsLine).
import { lcg, mul, sigVec } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';
import { SWITCH_PRIMES, bitsOf, labelOfName, nameLong, nameOf, primeName } from '../names.js';
import { num } from '../shared.js';

// ---- the algebra: Cl(3,3), the moves, the eight patterns
export const SEATS = 3, PATTERNS = 1 << SEATS;
const SQ = sigVec(SEATS, SEATS), DIM = 1 << (2 * SEATS);
const blade = i => { const x = new Float64Array(DIM); x[1 << i] = 1; return x; };
const plus = (x, y, s = 1) => x.map((v, i) => v + s * y[i]);
const scale = (x, c) => x.map(v => v * c);
const ONE = (() => { const x = new Float64Array(DIM); x[0] = 1; return x; })();
export const UP = Array.from({ length: SEATS }, (_, k) => scale(plus(blade(k), blade(k + SEATS)), 0.5));        // c⁺k: add one to seat k
export const DOWN = Array.from({ length: SEATS }, (_, k) => scale(plus(blade(k), blade(k + SEATS), -1), 0.5));  // ck: take one away from seat k
export const times = (x, y) => mul(x, y, SQ);
export const EMPTY = DOWN.reduce((P, d, k) => times(P, times(d, UP[k])), ONE);
// the pattern a (bit k = seat k + 1 full): c⁺ of its full seats, the lowest seat leftmost, applied to the empty pattern
export const STATES = Array.from({ length: PATTERNS }, (_, a) => { let x = EMPTY; for (let k = SEATS - 1; k >= 0; k--) if (a >> k & 1) x = times(UP[k], x); return x; });
// the pattern a blade belongs to: the seats whose e bit and f bit differ
export const patternOfBlade = L => (L ^ (L >> SEATS)) & (PATTERNS - 1);
const NORM = STATES.map(x => x.reduce((s, v) => s + v * v, 0));
// the coordinates of an element in the basis of the eight patterns; null when it is not a combination of them
export function coords(x) {
  const c = new Array(PATTERNS).fill(0);
  for (let L = 0; L < DIM; L++) if (x[L]) c[patternOfBlade(L)] += x[L] * STATES[patternOfBlade(L)][L];
  for (let a = 0; a < PATTERNS; a++) c[a] = c[a] / NORM[a] + 0;
  for (let L = 0; L < DIM; L++) if (x[L] !== c[patternOfBlade(L)] * STATES[patternOfBlade(L)][L]) return null;
  return c;
}
// the 8 x 8 table of an element acting on the patterns by the product: column a holds the coordinates of x · pattern a
export function matrixOf(x) {
  const M = Array.from({ length: PATTERNS }, () => new Array(PATTERNS).fill(0));
  for (let a = 0; a < PATTERNS; a++) { const c = coords(times(x, STATES[a])); if (!c) throw new Error('the patterns do not hold this product'); for (let b = 0; b < PATTERNS; b++) M[b][a] = c[b]; }
  return M;
}
export const ADD = UP.map(matrixOf), TAKE = DOWN.map(matrixOf);
export const SQUARES = UP.map(u => matrixOf(times(u, u)));                        // the table of c⁺k c⁺k
export const NUMBER = matrixOf(UP.reduce((s, u, k) => plus(s, times(u, DOWN[k])), new Float64Array(DIM)));
// one move on a pattern: { to, sign }, or null when it gives nothing
export function moveOn(a, k, op) { const M = (op === 'add' ? ADD : TAKE)[k]; for (let b = 0; b < PATTERNS; b++) if (M[b][a]) return { to: b, sign: M[b][a] }; return null; }
export const particles = a => NUMBER[a][a];
export const isFull = (a, k) => moveOn(a, k, 'add') === null;
// how many patterns have 0, 1, 2, 3 particles
export const COUNTS = Array.from({ length: SEATS + 1 }, (_, j) => STATES.filter((_, a) => particles(a) === j).length);
// the edges of the cube: one particle added to one seat
export const EDGES = [];
for (let a = 0; a < PATTERNS; a++) for (let k = 0; k < SEATS; k++) { const r = moveOn(a, k, 'add'); if (r) EDGES.push({ from: a, to: r.to, k }); }

// ---- the three names of a pattern (../names.js), and the moves said in primes from the names alone
export const PLACES = Array.from({ length: SEATS }, (_, k) => 1 << k);           // what a full seat counts in the numbers naming
export const SEAT_PRIMES = SWITCH_PRIMES.slice(0, SEATS);                         // the prime of each seat in the primes naming
// adding multiplies by the seat's prime and is allowed when the prime does not divide the name (no prime comes twice); taking away divides and is allowed when it does
export function stepByName(name, k, op) { const p = SEAT_PRIMES[k], has = name % p === 0; return op === 'add' ? (has ? null : name * p) : has ? name / p : null; }
// the sign of "add one to seat k" on a name: the kernel's reordering sign of e_k past the label of the name, (−1) to the number of lower seats that are full
export const signByName = (name, k) => reorderSign(1 << k, labelOfName(name));
export const nameIn = (a, mode) => nameOf(a, mode, SEATS);
// the name with what it is made of: 6 = 2 + 4 (numbers), 15 = 3·5 (primes)
export function longName(a, mode) {
  if (mode === 'numbers') { const parts = PLACES.filter((_, k) => a >> k & 1); return parts.length > 1 ? a + ' = ' + parts.join(' + ') : String(a); }
  return nameLong(a, mode, SEATS);
}
const particleText = n => (n === 0 ? 'no particles' : n + (n === 1 ? ' particle' : ' particles'));

// ---- front: three seats, the eight corners, the names
export const MODES = ['bits', 'numbers', 'primes'];
export const START = { a: 0, ev: null, mode: 'bits', shake: 0 };
// press "add one" or "take one away" at seat k: the pattern changes when the move gives a pattern; when it gives nothing the pattern stays and the seat shakes
export function press(s, k, op) {
  const r = moveOn(s.a, k, op);
  return { ...s, a: r ? r.to : s.a, ev: { k, op, from: s.a, to: r ? r.to : null }, shake: r ? s.shake : s.shake + 1 };
}
export const rename = (s, mode) => (MODES.includes(mode) ? { ...s, mode } : s);
// the formula under the picture: the move in the naming of the moment, or the pattern's name with what it is made of when the move gave nothing
export function readout(s) {
  const { a, ev, mode } = s;
  if (!ev) return { math: longName(a, mode) };
  const k = ev.k, n = k + 1, p = SEAT_PRIMES[k], v = PLACES[k], from = ev.from, name = primeName(from);
  if (ev.to !== null) {
    const to = ev.to, add = ev.op === 'add';
    const math = mode === 'bits' ? bitsOf(from, SEATS) + ' → seat ' + n + ' → ' + bitsOf(to, SEATS)
      : mode === 'numbers' ? from + (add ? ' + ' : ' − ') + v + ' = ' + to
      : name + (add ? ' × ' : ' ÷ ') + p + ' = ' + stepByName(name, k, ev.op);
    return { math };
  }
  return { math: longName(from, mode) };
}
// the corners of the cube in layers by particles, at the heights LAYER_Y; inside a layer the larger number stands on the left, as seat 3 does
export const LAYER_Y = [244, 180, 116, 52];
const LAYER_X = { 1: [170], 3: [100, 170, 240] };
export const CORNERS = [];
for (let j = 0; j <= SEATS; j++) {
  const layer = STATES.map((_, a) => a).filter(a => particles(a) === j).sort((x, y) => y - x);
  layer.forEach((a, i) => CORNERS.push({ a, j, x: (LAYER_X[layer.length] || [])[i], y: LAYER_Y[j] }));
}
export const cornerOf = a => CORNERS.find(c => c.a === a);
export const NODE = { w: 62, h: 32 };
// the end of a line from (x1, y1) that stops short of the box of the corner at (x2, y2), so that an arrowhead shows
export function stopShort(x1, y1, x2, y2, gap = 4) {
  const dx = x1 - x2, dy = y1 - y2, s = Math.min(dx ? (NODE.w / 2 + gap) / Math.abs(dx) : Infinity, dy ? (NODE.h / 2 + gap) / Math.abs(dy) : Infinity);
  return { x: x2 + s * dx, y: y2 + s * dy };
}
export function frontView(s) {
  const { a, ev, mode } = s, n = particles(a), last = ev && ev.to !== null ? ev : null;
  const seats = PLACES.map((_, k) => k).reverse().map(k => {
    const full = isFull(a, k);
    return { k, n: k + 1, full, unit: mode === 'bits' ? (full ? '1' : '0') : mode === 'numbers' ? String(PLACES[k]) : String(SEAT_PRIMES[k]), shake: !!ev && ev.to === null && ev.k === k };
  });
  const corners = CORNERS.map(c => ({ ...c, name: nameIn(c.a, mode), on: c.a === a }));
  const edges = EDGES.map(e => { const f = cornerOf(e.from), t = cornerOf(e.to), on = !!last && ((last.from === e.from && last.to === e.to) || (last.from === e.to && last.to === e.from)); return { ...e, x1: f.x, y1: f.y, x2: t.x, y2: t.y, on }; });
  let arrow = null;
  if (last) { const f = cornerOf(last.from), t = cornerOf(last.to), end = stopShort(f.x, f.y, t.x, t.y); arrow = { x1: f.x, y1: f.y, x2: end.x, y2: end.y }; }
  const layers = COUNTS.map((c, j) => ({ j, count: c, y: LAYER_Y[j], dots: Array.from({ length: j }, (_, i) => 26 + 14 * (i - (j - 1) / 2)) }));   // j dots for j particles; none: an empty ring
  return {
    seats, corners, edges, arrow, layers, total: COUNTS.reduce((x, y) => x + y, 0), shakeKey: s.shake,
    pattern: { long: longName(a, mode), n, text: particleText(n) }, readout: readout(s)
  };
}

// ---- back, the mathematician: the table of c⁺k on the eight patterns, its square, and the trace of aa⁺ − a⁺a
export const START_MATH = { k: 0, mode: 'bits' };
export const SEAT_OPTIONS = PLACES.map((_, k) => ({ id: k, label: 'seat ' + (k + 1) }));
export function mathView(s) {
  const k = s.k, n = k + 1, M = ADD[k], cells = [];
  for (let b = 0; b < PATTERNS; b++) for (let a = 0; a < PATTERNS; a++) if (M[b][a]) cells.push({ to: b, from: a, v: M[b][a], text: num(M[b][a], 0) });
  const sq = SQUARES[k], sqCells = [];
  for (let b = 0; b < PATTERNS; b++) for (let a = 0; a < PATTERNS; a++) if (sq[b][a]) sqCells.push({ to: b, from: a, v: sq[b][a] });
  return { k, n, names: STATES.map((_, a) => nameIn(a, s.mode)), cells, sqCells, fullCols: STATES.map((_, a) => a).filter(a => isFull(a, k)) };
}
// the trace: for a square table a of 0s and 1s, the diagonal of aa⁺ − a⁺a (a⁺ is a turned over its diagonal) adds up to 0, the diagonal of 1 to N
export const SIZES = [2, 4, 8];
export const START_TRACE = { n: 8, seed: 1 };
export const SIZE_OPTIONS = SIZES.map(n => ({ id: n, label: 'N = ' + n }));
const mm = (A, B) => A.map(r => B[0].map((_, j) => r.reduce((t, v, i) => t + v * B[i][j], 0)));
const turn = A => A[0].map((_, j) => A.map(r => r[j]));
export const commutatorDiag = a => { const L = mm(a, turn(a)), R = mm(turn(a), a); return L.map((r, i) => r[i] - R[i][i]); };
// a table drawn by a seeded generator; a table whose diagonal is all 0 is passed over, so that the picture shows something to add up
export function table01(n, seed) {
  let a = null;
  for (let t = 0; t < 40; t++) {
    const r = lcg(1009 * seed + 31 * n + t);
    a = Array.from({ length: n }, () => Array.from({ length: n }, () => (r() < 0.4 ? 1 : 0)));
    if (commutatorDiag(a).some(x => x !== 0)) break;
  }
  return a;
}
// "another table": the next seed whose diagonal differs from the one shown (at N = 2 only two diagonals exist), so that the control always changes the picture
export function nextTable(s) {
  const shown = commutatorDiag(table01(s.n, s.seed)).join();
  let seed = s.seed + 1;
  while (seed < s.seed + 50 && commutatorDiag(table01(s.n, seed)).join() === shown) seed++;
  return { ...s, seed };
}
export function traceView(s) {
  const a = table01(s.n, s.seed), d = commutatorDiag(a), sum = d.reduce((x, y) => x + y, 0), ones = a.map(() => 1), tr1 = ones.reduce((x, y) => x + y, 0);
  return {
    n: s.n, a, d, sum, tr1,
    lines: [{ id: 'c', label: 'aa⁺ − a⁺a', cells: d.map(x => num(x, 0)), total: 'tr = ' + num(sum, 0) }, { id: 'i', label: '1', cells: ones.map(x => num(x, 0)), total: 'tr = ' + tr1 }]
  };
}

// ---- back, the physicist: an atom with three states, one electron at most in each
export const ENERGY = [1, 2, 3];                              // the states from the lowest up (only their order matters)
export const LEVEL_Y = [178, 120, 62];                        // where the states are drawn, the lowest at the bottom
const energyOf = (a, E) => E.reduce((t, e, j) => (a >> j & 1 ? t + e : t), 0);
// the arrangement of k electrons with the least energy, found by trying every arrangement
export function lowestFor(k, E = ENERGY) { let best = null; for (let a = 0; a < PATTERNS; a++) if (particles(a) === k && (best === null || energyOf(a, E) < energyOf(best, E))) best = a; return best; }
export const canAddAny = a => PLACES.some((_, k) => moveOn(a, k, 'add') !== null);
export const START_ATOM = { k: 2, over: false };
export const atomMore = s => (canAddAny(lowestFor(s.k)) ? { k: s.k + 1, over: false } : { k: s.k, over: true });
export const atomLess = s => (s.k > 0 ? { k: s.k - 1, over: false } : { k: 0, over: false });
const THUMB_X = { 1: [266], 3: [214, 266, 318] };
export function atomView(s) {
  const k = s.k, low = lowestFor(k), ways = STATES.map((_, a) => a).filter(a => particles(a) === k), c = COUNTS[k];
  const thumbs = ways.slice().sort((x, y) => energyOf(x, ENERGY) - energyOf(y, ENERGY) || x - y).map((a, i) => ({ a, x: (THUMB_X[ways.length] || [])[i], low: a === low, dots: LEVEL_Y.filter((_, j) => a >> j & 1) }));
  return { k, ways: c, thumbs, dots: LEVEL_Y.filter((_, j) => low >> j & 1), minusOff: k === 0 };
}
