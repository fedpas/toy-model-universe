// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/magnets.logic.js — loose leaf Magnets under leaf 4 (port of Octavo's octavo/leaves/magnets.logic.js; plain functions, no React). Only
// Cl(3,0) is used, three plus switches: e1 points right, e3 points up (e2, front to back, is not drawn). Every product is engines/labels.js's mul (the kernel's);
// tests/explore/leaves.magnets.test.mjs recomputes every number by standard routes (Pauli matrices, plain dot products, the widget engine of the Schuller chapter)
// and holds them bit-identical to the Octavo output.
// A beam is a state ρ = ½(1 + v), a positive element exactly when |v| ≤ 1 (the ball); a magnet along the unit arrow u is the projector P = ½(1 + u); the part of
// the beam that passes is 2⟨ρP⟩₀ = ½(1 + v·u), and the beam that passes is PρP divided by that part. Front: a beam pointing up goes through three magnets that
// point up, right, down or left. Back: the part that passes as the shadow of v on the axis of the magnet (mathematician); a beam through two magnets in the two
// orders and the product of their projectors (physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY, HINT, BALL_CAP, MODEL_LINE, ORDER_CAP; the sentences of frontView (line, alt, the labels of the magnet buttons:
// the parts as words are data, `words`, and the magnet that stops the beam is `stop`), ballView (alt; thEnds and rEnds keep only their numbers), ordersView
// (line: the sign of e₃e₁ against e₁e₃ is data, `sign31`) and of its rows (alt).
import { bladeMul, mul, sigVec } from '../../labels.js';
import { num, sub } from '../shared.js';

// ---- the algebra: vectors, states, magnets
export const SQ = sigVec(3, 0);                                   // three switches that square to +1
const E1 = 1, E2 = 2, E3 = 4;                                     // the labels of e1, e2, e3
export const vec = ([x, y, z]) => { const m = new Float64Array(8); m[E1] = x; m[E2] = y; m[E3] = z; return m; };
// ½(1 + w) for a vector w
const halfPlus = w => { const m = vec(w); m[0] = 1; for (let a = 0; a < 8; a++) m[a] /= 2; return m; };
export const R_MAX = 1;                                           // the radius of the ball of states
export const isState = v => Math.hypot(v[0], v[1], v[2]) <= R_MAX + 1e-12;
export const state = v => (isState(v) ? halfPlus(v) : null);
export const projector = u => halfPlus(u);
// the part of a beam in the state rho that passes the magnet along u: twice the scalar part of ρP
export function passPart(rho, u) {
  return 2 * mul(rho, projector(u), SQ)[0];
}
// the beam that passes: PρP divided by the part that passes (no beam when no part passes)
export function through(rho, u) {
  const P = projector(u), p = passPart(rho, u);
  if (p < 1e-12) return { p: 0, rho: null };
  const out = mul(mul(P, rho, SQ), P, SQ);
  for (let a = 0; a < 8; a++) out[a] /= p;
  return { p, rho: out };
}
// the arrow v of a state ½(1 + v)
export const arrowOf = rho => [2 * rho[E1], 2 * rho[E2], 2 * rho[E3]];

// ---- front: three magnets, each pointing up, right, down or left (in the order of a quarter turn clockwise), and a beam that comes in pointing up
export const DIRS = ['up', 'right', 'down', 'left'];
export const ARROW = { up: [0, 0, 1], right: [1, 0, 0], down: [0, 0, -1], left: [-1, 0, 0] };
export const DEG = { up: 0, right: 90, down: 180, left: 270 };   // the angle of the arrow on the page, clockwise from up
export const IN_DIR = 'up';
export const LANES = 8;                                           // the whole beam is drawn as eight lanes of dots
export const SPEED = 1.5;                                         // lanes of dots per second
export const dirOf = w => DIRS.find(d => ARROW[d].every((x, k) => Math.abs(x - w[k]) < 1e-9)) || null;
export const pct = x => Math.round(x * 1000) / 10 + '%';
// the part a magnet passes as a word when it is all, half or none of what reaches it (else the number)
const word = p => (Math.abs(p - 1) < 1e-12 ? 'all' : Math.abs(p - 0.5) < 1e-12 ? 'half' : Math.abs(p) < 1e-12 ? 'none' : num(p, 2));
// the beam along a row of magnets: the part each one passes, how much of the beam is left after it, and where the beam then points
export function chain(dirs, inDir = IN_DIR) {
  let rho = state(ARROW[inDir]), left = 1;
  const steps = [];
  for (let i = 0; i < dirs.length; i++) {
    if (!rho) { steps.push({ i, d: dirs[i], reached: false, part: 0, left: 0, out: null }); continue; }
    const t = through(rho, ARROW[dirs[i]]);
    left *= t.p; rho = t.rho;
    steps.push({ i, d: dirs[i], reached: true, part: t.p, left, out: rho ? dirOf(arrowOf(rho)) : null });
  }
  return { steps, total: left };
}
// the pieces of the beam: the one that comes in and the one after each magnet, as wide as the part that is left
const piecesOf = (c, inDir) => [{ amount: 1, dir: inDir }, ...c.steps.map(t => ({ amount: t.left, dir: t.left > 0 ? t.out : null }))]
  .map((g, j) => ({ ...g, j, lanes: g.amount * LANES, pct: pct(g.amount) }));

export const START = { dirs: ['up', 'right', 'up'], angs: [0, 90, 0] };   // angs add up the turns of each arrow, so that an arrow never jumps back
// magnet i set to point d: its arrow turns the short way round
export function setDir(s, i, d) {
  if (!DIRS.includes(d) || !(i >= 0 && i < s.dirs.length)) return s;
  const k = ((((DEG[d] - DEG[s.dirs[i]]) / 90) % 4) + 4) % 4, step = k === 3 ? -90 : 90 * k;
  return { dirs: s.dirs.map((x, j) => (j === i ? d : x)), angs: s.angs.map((a, j) => (j === i ? a + step : a)) };
}
// magnet i turned a quarter turn: clockwise (by = 1) or anticlockwise (by = −1)
export const turn = (s, i, by = 1) => setDir(s, i, DIRS[(DIRS.indexOf(s.dirs[i]) + by + 4) % 4]);
// the dots run to the right: the phase is the shift of the dots, in lanes (0 to 1)
export const advance = (phase, dt) => (phase + dt * SPEED) % 1;
// words: the part each magnet passes, as a word; stop: the magnet that a beam reaches and that passes none of it (−1 when the beam gets through)
export function frontView(s) {
  const c = chain(s.dirs), segs = piecesOf(c, IN_DIR), words = c.steps.map(t => word(t.part)), stop = c.steps.findIndex(t => t.reached && t.part === 0);
  return {
    segs, total: c.total, steps: c.steps, words, stop,
    magnets: s.dirs.map((d, i) => ({ i, d, deg: s.angs[i] }))
  };
}

// ---- back, the mathematician: the arrow v at the angle θ from the axis u of a magnet that points up, of length |v| = rv / RV_STEPS; the part that passes is
// the shadow of v on u, read up from the bottom of the ball
export const TH_MAX = 180, TH_STEP = 5, RV_STEPS = 20, RV_MAX = RV_STEPS * R_MAX;
export const START_BALL = { th: 60, rv: 20 };
export const BALL = { cx: 202, cy: 160, R: 120, rulerX: 44 };   // the picture: 350 × 320
export const canBall = ({ th, rv }) => Number.isInteger(th) && Number.isInteger(rv) && th >= 0 && th <= TH_MAX && rv >= 0 && isState([rv / RV_STEPS, 0, 0]);
const NB = ' ';                                             // a space where a line must not break (inside a formula)
const eq = x => (Math.abs(x * 100 - Math.round(x * 100)) < 1e-9 ? '=' : '≈');
export function ballView(b) {
  if (!canBall(b)) return null;
  const { th, rv } = b, r = rv / RV_STEPS, t = th * Math.PI / 180, v = [r * Math.sin(t), 0, r * Math.cos(t)], u = ARROW.up;
  const p = passPart(state(v), u), dot = v[0] * u[0] + v[1] * u[1] + v[2] * u[2], sphere = rv === RV_MAX;
  const { cx, cy, R, rulerX } = BALL, tip = { x: cx + R * v[0], y: cy - R * v[2] }, len = R * r, ra = 34;
  const arc = th > 0 && len > ra + 10 ? 'M' + cx + ' ' + (cy - ra) + ' A' + ra + ' ' + ra + ' 0 0 1 ' + (cx + ra * Math.sin(t)).toFixed(2) + ' ' + (cy - ra * Math.cos(t)).toFixed(2) : null;
  const vLab = len > 24 ? { x: cx + (len + 17) * Math.sin(t), y: cy - (len + 17) * Math.cos(t) } : { x: cx + 18, y: cy + 20 };
  // the head of an arrow whose tip is at (x, y), pointing along the page direction (dx, dy), 14 long and 12 wide
  const head = (x, y, dx, dy) => { const bx = x - 14 * dx, by = y - 14 * dy; return { end: { x: bx + 2 * dx, y: by + 2 * dy }, pts: [[x, y], [bx - 6 * dy, by + 6 * dx], [bx + 6 * dy, by - 6 * dx]].map(q => q[0].toFixed(2) + ',' + q[1].toFixed(2)).join(' ') }; };
  const hv = len >= 22 ? head(tip.x, tip.y, Math.sin(t), -Math.cos(t)) : null;
  return {
    th, rv, r, v, p, dot, tip, len, arc, vLab, vHead: hv && hv.pts, vEnd: hv ? hv.end : tip, uHead: head(cx, cy - R, 0, -1).pts,
    thLab: arc && th >= 25 ? { x: cx + (ra + 13) * Math.sin(t / 2), y: cy - (ra + 13) * Math.cos(t / 2) } : null,
    ruler: { x: rulerX, top: cy - R, bottom: cy + R, mid: cy, at: tip.y },
    thText: 'θ = ' + th + '°', rText: '|v| = ' + num(r, 2),
    thEnds: ['0°', TH_MAX / 2 + '°', TH_MAX + '°'], rEnds: ['0', String(R_MAX)],
    line: 'v·u' + NB + eq(dot) + NB + num(dot, 2) + ', so p' + NB + '=' + NB + '½(1' + NB + '+' + NB + 'v·u)' + (sphere ? ' =' + NB + 'cos²(' + th / 2 + '°)' : '') + ' ' + eq(p) + NB + num(p, 2) + '.'
  };
}

// ---- back, the physicist: a beam through two magnets in the two orders, and the product of the two projectors with the first magnet on the right
export const PAIR = ['up', 'right'];
export const AXIS = { up: 'z', right: 'x' };
export const START_IN = 'up';
export const IN_CHOICES = DIRS.map(d => ({ id: d, label: d }));
const BLADES = [0, 1, 2, 4, 3, 5, 6, 7];                          // 1, e1, e2, e3, e1e2, e1e3, e2e3, e1e2e3
export const bladeText = a => (a === 0 ? '1' : [0, 1, 2].filter(k => (a >> k) & 1).map(k => 'e' + sub(k + 1)).join(''));
const FRAC = { 1: '', 0.5: '½', 0.25: '¼' };
// a multivector as text: ¼(1 + e₁ + e₃ + e₁e₃) when every coefficient has the same size, else coefficient by coefficient
export function mvText(m) {
  const nz = BLADES.filter(a => Math.abs(m[a]) > 1e-12);
  if (!nz.length) return '0';
  const c = Math.abs(m[nz[0]]), sign = (x, first) => (first ? (x < 0 ? '−' : '') : x < 0 ? ' − ' : ' + ');
  if (FRAC[c] !== undefined && nz.every(a => Math.abs(Math.abs(m[a]) - c) < 1e-12)) {
    const inner = nz.map((a, j) => sign(m[a], j === 0) + bladeText(a)).join('');
    return c === 1 ? inner : FRAC[c] + '(' + inner + ')';
  }
  return nz.map((a, j) => sign(m[a], j === 0) + num(Math.abs(m[a]), 2) + (a ? ' ' + bladeText(a) : '')).join('');
}
// rows: the two orders; diff: the blades where the two products differ; sign31: e₃e₁ = sign31 · e₁e₃ (the kernel's signs)
export function ordersView(inDir) {
  const rows = [PAIR, [PAIR[1], PAIR[0]]].map(([a, b]) => {
    const c = chain([a, b], inDir), K = mul(projector(ARROW[b]), projector(ARROW[a]), SQ), segs = piecesOf(c, inDir);
    const label = a[0].toUpperCase() + a.slice(1) + ', then ' + b;
    return {
      a, b, label, segs, total: c.total, pct: pct(c.total), K, names: [AXIS[b], AXIS[a]], expr: mvText(K),
      magnets: [a, b].map((d, i) => ({ i, d, deg: DEG[d] }))
    };
  });
  const diff = BLADES.filter(x => Math.abs(rows[0].K[x] - rows[1].K[x]) > 1e-12);
  const sign31 = bladeMul(E3, E1, SQ)[1] * bladeMul(E1, E3, SQ)[1];   // e3e1 = s e1e3
  return { rows, diff, sign31 };
}
