// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/light.logic.js — leaf 6, light (port of Octavo's octavo/leaves/light.logic.js; plain functions, no React). The squares of switches and
// vectors come from engines/labels.js (sigVec, bladeMul, mul: the kernel's), the kind of a cell from engines/schullerEngine.js (waveKind); tests/explore/
// leaves.light.test.mjs recomputes them by standard routes and holds them bit-identical to the Octavo output.
// Front: p plus switches and q minus switches. One switch is called time, the others space. A ripple heading along a unit space vector ξ obeys (λ e_t + ξ)² = 0, so
// λ² = −ξ² / e_t²: λ real means the ripple travels at speed λ, otherwise it stays where it is and grows or fades. With exactly one switch of its sign that switch is
// time. Back, the mathematician: the cone v² = 0 of three switches and a direction θ, with twelve lines along θ. Back, the physicist: a pluck on a string,
// u = ½ f(x − t) + ½ f(x + t), whose two halves follow the cone of Cl(1,1).
// Not carried over (docs/EXPLORE_PORT.md): COPY, LABELS, the tags of KINDS; the sentences of world() (status, alt, switchAlt), of CELLS (aria), coneView (line, alt)
// and stringView (line, alt, stAlt). Their facts are the data already returned (kind, alone, time, sameSpeed, side, miss, twice, c, centres).
import { bladeMul, mul, mvZero, sigVec } from '../../labels.js';
import { waveKind } from '../../schullerEngine.js';
import { num } from '../shared.js';

export const EPS = 1e-9;
// a vector Σ v_i e_i as a multivector, its square and the symmetric product ½(uv + vu) of two vectors: scalars, by the kernel's product
const asVec = (n, v) => { const X = mvZero(n); v.forEach((x, i) => { if (x) X[1 << i] = x; }); return X; };
export const square = (S, v) => mul(asVec(S.length, v), asVec(S.length, v), S)[0];
export const dot = (S, u, v) => { const U = asVec(S.length, u), V = asVec(S.length, v); return (mul(U, V, S)[0] + mul(V, U, S)[0]) / 2; };

// ---- the three kinds of wave (schullerEngine.waveKind), each with a mark that is not a colour
export const KINDS = {
  hyperbolic: { id: 'light', mark: 'ring' },
  elliptic: { id: 'still', mark: 'dot' },
  ultrahyperbolic: { id: 'mixed', mark: 'lobes' }
};
// the mark of a kind as an SVG path in a 24 x 24 box: a ring, a dot, two lobes (a lemniscate)
export const MARK_PATH = {
  ring: 'M12 3.5 A8.5 8.5 0 1 1 11.99 3.5 Z',
  dot: 'M12 7.5 A4.5 4.5 0 1 1 11.99 7.5 Z',
  lobes: Array.from({ length: 73 }, (_, i) => { const a = i * Math.PI / 36, d = 1 + Math.sin(a) ** 2, r = 10; return (i ? 'L' : 'M') + (12 + r * Math.cos(a) / d).toFixed(2) + ' ' + (12 - r * Math.sin(a) * Math.cos(a) / d).toFixed(2); }).join(' ') + ' Z'
};

// ---- front: the switches, which one is time, and the ripples
export const MIN_N = 2, MAX_N = 5, MAX_EACH = 5, HEADINGS = 36;
export const canSet = (p, q) => Number.isInteger(p) && Number.isInteger(q) && p >= 0 && q >= 0 && p + q >= MIN_N && p + q <= MAX_N;
export const count = (p, q) => p + ' plus, ' + q + ' minus';
const SIGN = s => (s > 0 ? '+' : '−');
const memo = new Map();
// everything about (p, q) that does not move: the squares of the switches, the switch called time, the space switches drawn across and up, the speed of the ripple
// heading each way (null: it does not travel), the kind
export function world(p, q) {
  const key = p + ',' + q;
  if (memo.has(key)) return memo.get(key);
  const S = sigVec(p, q), n = S.length, sq = S.map((_, i) => bladeMul(1 << i, 1 << i, S)[1]);
  const plus = sq.filter(s => s > 0).length, minus = n - plus;
  let time = 0, alone = false;
  if (plus === 1) { time = sq.indexOf(1); alone = true; } else if (minus === 1) { time = sq.indexOf(-1); alone = true; }
  const rest = sq.map((_, i) => i).filter(i => i !== time), other = rest.filter(i => sq[i] !== sq[time]), same = rest.filter(i => sq[i] === sq[time]);
  // across: a switch of the other sign when there is one (its ripples travel), up: one of the same sign when there is one
  const axes = n === 2 ? [rest[0]] : other.length && same.length ? [other[0], same[0]] : [rest[0], rest[1]];
  const tt = square(S, sq.map((_, i) => (i === time ? 1 : 0)));          // e_time squared
  const speedAt = deg => {
    const a = deg * Math.PI / 180, v = Array(n).fill(0); v[axes[0]] = Math.cos(a); if (n > 2) v[axes[1]] = Math.sin(a);
    const l2 = -square(S, v) / tt;
    return { l2, speed: l2 > EPS ? Math.sqrt(l2) : null };
  };
  const degs = n === 2 ? [0, 180] : Array.from({ length: HEADINGS }, (_, k) => k * 360 / HEADINGS);
  const headings = degs.map(deg => { const a = deg * Math.PI / 180; return { deg, c: Math.cos(a), s: n > 2 ? Math.sin(a) : 0, ...speedAt(deg) }; });
  const kind = waveKind(p, q), K = KINDS[kind];
  // the shape the crests reach at t = 1, sampled every degree (a ring, two lobes, or nothing)
  const shape = n === 2 ? null : Array.from({ length: 361 }, (_, d) => { const r = speedAt(d).speed || 0, a = d * Math.PI / 180; return [r * Math.cos(a), r * Math.sin(a)]; });
  const travel = headings.filter(h => h.speed !== null), sameSpeed = travel.length > 0 && travel.every(h => Math.abs(h.speed - travel[0].speed) < 1e-9);
  const switches = sq.map((s, i) => ({ i, sign: SIGN(s), role: i === time ? 'time' : i === axes[0] ? 'across' : i === axes[1] ? 'up' : '', alone: alone && i === time }));
  const w = { p, q, n, S, sq, plus, minus, time, alone, axes, tt, headings, shape, kind, K, switches, sameSpeed, axisSigns: axes.map(i => SIGN(sq[i])) };
  memo.set(key, w);
  return w;
}

// the map of every (p, q) with 2 to 5 switches: plus counts across, minus counts down
export const CELLS = (() => {
  const out = [];
  for (let q = 0; q <= MAX_EACH; q++) for (let p = 0; p <= MAX_EACH; p++) {
    if (!canSet(p, q)) continue;
    const K = KINDS[waveKind(p, q)];
    out.push({ p, q, K, light: K.id === 'light' });
  }
  return out;
})();

// the animation: t runs from 0 to 1 (the crests of speed 1 reach the edge of the pond), holds, and starts again
export const SPEED = 0.3, T_END = 1, HOLD = 0.9;
export const START = { p: 1, q: 3, t: 0.7, hold: 0 };
export const setCounts = (s, p, q) => (canSet(p, q) ? { ...s, p, q } : s);
export function advance(s, dt) {
  if (s.hold > 0 || s.t >= T_END) { const hold = s.hold + dt; return hold > HOLD ? { ...s, t: 0, hold: 0 } : { ...s, t: T_END, hold }; }
  return { ...s, t: Math.min(T_END, s.t + dt * SPEED) };
}
export const POND = { cx: 200, cy: 200, U: 150 };
const P2 = (x, y) => (POND.cx + POND.U * x).toFixed(1) + ' ' + (POND.cy - POND.U * y).toFixed(1);
export function frontView(s) {
  const w = world(s.p, s.q), t = Math.min(s.t, T_END), { cx, cy, U } = POND;
  // a crest of speed 1 is on the cone: the arrow from the start, t e_time + t ξ, squares to zero
  const dots = w.headings.filter(h => h.speed !== null).map(h => ({ deg: h.deg, x: cx + U * h.speed * t * h.c, y: cy - U * h.speed * t * h.s, onCone: Math.abs(h.speed - 1) < 1e-9 }));
  const stuck = w.headings.some(h => h.speed === null);
  const guide = w.shape && w.K.id !== 'still' ? w.shape.map((pt, i) => (i ? 'L' : 'M') + P2(pt[0], pt[1])).join(' ') + ' Z' : null;
  return {
    ...w, t, dots, stuck, guide, op: s.hold > 0 ? Math.max(0.25, 1 - s.hold / HOLD) : 1, tText: 't = ' + num(t, 2),
    pMinusOff: !canSet(s.p - 1, s.q), pPlusOff: !canSet(s.p + 1, s.q), qMinusOff: !canSet(s.p, s.q - 1), qPlusOff: !canSet(s.p, s.q + 1)
  };
}

// ---- back, the mathematician: three switches, the cone v² = 0, a direction θ tilted from the time axis, twelve lines along θ
export const SIGS3 = [[1, 2], [2, 1], [3, 0], [0, 3]];
export const TILTS = [0, 15, 30, 45, 60, 75];                  // degrees from the time axis toward the first space axis
export const LINES = 12, RHO = 0.4;                             // the lines pass through twelve points of a circle of radius RHO around the time axis, at time 0
export const CONE = { cx: 200, cy: 196, S: 118, el: 16 * Math.PI / 180, H: 1, TB: 1.18, XB: 1.48 };
export const START_CONE = { si: 0, ki: 1 };
// world coordinates (x across, y into the page, t up) to the picture, seen from a little above
export const proj = (x, y, t) => ({ X: CONE.cx + CONE.S * x, Y: CONE.cy - CONE.S * (t * Math.cos(CONE.el) + y * Math.sin(CONE.el)) });
const sub = i => '₁₂₃'[i];
// the real roots λ of Q(θ) λ² + 2 B λ + Q(ξ) = 0: the places where the line ξ + λθ meets the cone
export function roots(Qt, B, Qx) {
  if (Math.abs(Qt) <= EPS) return Math.abs(B) <= EPS ? [] : [-Qx / (2 * B)];
  const disc = B * B - Qt * Qx;
  if (disc < -EPS) return [];
  if (disc <= EPS) return [-B / Qt];
  const r = Math.sqrt(disc);
  return [(-B - r) / Qt, (-B + r) / Qt].sort((a, b) => a - b);
}
export function coneView(si, ki) {
  const [p, q] = SIGS3[si], w = world(p, q), { S, time, axes, alone, tt } = w, [ax, ay] = axes, beta = TILTS[ki] * Math.PI / 180;
  const vec = (t, x, y) => { const v = [0, 0, 0]; v[time] = t; v[ax] = x; v[ay] = y; return v; };
  const theta = vec(Math.cos(beta), Math.sin(beta), 0), Qt = square(S, theta);
  const side = !alone ? 'none' : Qt * tt > EPS ? 'inside' : Qt * tt < -EPS ? 'outside' : 'on';
  const at = (xi, lam) => ({ t: xi[time] + lam * theta[time], x: xi[ax] + lam * theta[ax], y: xi[ay] + lam * theta[ay] });
  const lines = Array.from({ length: LINES }, (_, k) => {
    const a = k * 2 * Math.PI / LINES, xi = vec(0, RHO * Math.cos(a), RHO * Math.sin(a));
    const B = dot(S, xi, theta), lam = roots(Qt, B, square(S, xi));
    // the drawn part of the line: |t| <= TB and |x| <= XB
    let lo = -CONE.TB / Math.cos(beta), hi = CONE.TB / Math.cos(beta);
    if (Math.sin(beta) > EPS) { const l1 = (-CONE.XB - xi[ax]) / Math.sin(beta), l2 = (CONE.XB - xi[ax]) / Math.sin(beta); lo = Math.max(lo, l1); hi = Math.min(hi, l2); }
    const A = at(xi, lo), Z = at(xi, hi), pa = proj(A.x, A.y, A.t), pz = proj(Z.x, Z.y, Z.t);
    const hits = lam.map(l => { const P = at(xi, l); return { lam: l, ...P, ...proj(P.x, P.y, P.t) }; });
    return { k, a, xi, B, lam, lo, hi, x1: pa.X, y1: pa.Y, x2: pz.X, y2: pz.Y, back: xi[ay] > EPS, hits, miss: hits.length === 0 };
  });
  // the cone (one switch alone only): its slope from the squares of the time and the space switches, the rims at t = ±H, the outline seen from above
  let cone = null;
  if (alone) {
    const k = Math.sqrt(-tt / square(S, vec(0, 1, 0))), H = CONE.H, r = k * H, te = Math.tan(CONE.el), sx = k * H * Math.sqrt(1 - k * k * te * te), sy = k * k * H * te;
    const rim = h => { const c = proj(0, 0, h); return { cx: c.X, cy: c.Y, rx: CONE.S * r, ry: CONE.S * r * Math.sin(CONE.el) }; };
    const v0 = proj(0, 0, 0), uL = proj(-sx, -sy, H), uR = proj(sx, -sy, H), dL = proj(-sx, sy, -H), dR = proj(sx, sy, -H), top = rim(H), bot = rim(-H);
    const f = z => z.toFixed(1);
    cone = {
      k, r, top, bot,
      upper: 'M' + f(v0.X) + ' ' + f(v0.Y) + ' L' + f(uL.X) + ' ' + f(uL.Y) + ' A' + f(top.rx) + ' ' + f(top.ry) + ' 0 1 1 ' + f(uR.X) + ' ' + f(uR.Y) + ' Z',
      lower: 'M' + f(v0.X) + ' ' + f(v0.Y) + ' L' + f(dL.X) + ' ' + f(dL.Y) + ' A' + f(bot.rx) + ' ' + f(bot.ry) + ' 0 1 0 ' + f(dR.X) + ' ' + f(dR.Y) + ' Z',
      sil: [[v0, uL], [v0, uR], [v0, dL], [v0, dR]].map(([a, b]) => ({ x1: a.X, y1: a.Y, x2: b.X, y2: b.Y })),
      backArc: 'M' + f(dL.X) + ' ' + f(dL.Y) + ' A' + f(bot.rx) + ' ' + f(bot.ry) + ' 0 0 1 ' + f(dR.X) + ' ' + f(dR.Y),
      frontArc: 'M' + f(dL.X) + ' ' + f(dL.Y) + ' A' + f(bot.rx) + ' ' + f(bot.ry) + ' 0 1 0 ' + f(dR.X) + ' ' + f(dR.Y),
      rimPts: Array.from({ length: 24 }, (_, j) => { const a = j * Math.PI / 12; return [vec(H, r * Math.cos(a), r * Math.sin(a)), vec(-H, r * Math.cos(a), r * Math.sin(a))]; }).flat()
    };
  }
  const tip = proj(1.12 * Math.sin(beta), 0, 1.12 * Math.cos(beta)), tail = proj(-1.12 * Math.sin(beta), 0, -1.12 * Math.cos(beta)), o = proj(0, 0, 0);
  const miss = lines.filter(l => l.miss).length, twice = lines.filter(l => l.hits.length === 2).length;
  const name = 'Cl(' + p + ',' + q + ')', eT = 'e' + sub(time), deg = TILTS[ki] + '°';
  return {
    p, q, name, w, S, time, axes, alone, beta, deg, theta, Qt, side, lines, cone, miss, twice,
    tip: { x: tip.X, y: tip.Y }, tail: { x: tail.X, y: tail.Y }, o: { x: o.X, y: o.Y },
    labels: { t: eT, x: 'e' + sub(ax), y: 'e' + sub(ay) }, axisEnds: { t: proj(0, 0, CONE.TB + 0.12), x: proj(CONE.XB, 0, 0), y: proj(0, 1.25, 0) }
  };
}
export const sigLabel = ([p, q]) => 'Cl(' + p + ',' + q + ')';

// ---- back, the physicist: a pluck of half-width PLUCK at the middle of a long string; t counted in tenths, from 0 to 2.4
export const PLUCK = 0.5, T10_MAX = 24;
const S11 = sigVec(1, 1);
// the speed of the two halves: the slope of the cone of one plus and one minus switch, (t e1 + x e2)² = t² − x² = 0 at x = ±t
export const C = Math.sqrt(-square(S11, [1, 0]) / square(S11, [0, 1]));
export const pluck = x => (Math.abs(x) < PLUCK ? (1 + Math.cos(Math.PI * x / PLUCK)) / 2 : 0);
export const height = (x, t) => 0.5 * pluck(x - C * t) + 0.5 * pluck(x + C * t);
// the two pictures of the physicist, 400 units wide: the string (x from −3.2 to 3.2, height from 0 to 1) and the plane of x and t (one unit of x as long as one unit of t)
export const STRING = { x0: 200, ux: 58, y0: 150, uy: 112 };
export const ST = { x0: 200, ux: 58, y0: 176, ut: 58 };
export const TICKS = [-3, -2, -1, 0, 1, 2, 3].map(x => ({ x, label: (x < 0 ? '−' : '') + Math.abs(x) }));
const sx = x => STRING.x0 + STRING.ux * x, sy = u => STRING.y0 - STRING.uy * u, stx = x => ST.x0 + ST.ux * x, sty = t => ST.y0 - ST.ut * t;
const pathOf = fn => Array.from({ length: 481 }, (_, i) => { const x = -3.2 + 6.4 * i / 480; return (i ? 'L' : 'M') + sx(x).toFixed(1) + ' ' + sy(fn(x)).toFixed(1); }).join(' ');
export const GHOST = pathOf(pluck);
const T_TOP = T10_MAX / 10;
// the two strips of the plane of x and t that the halves sweep, and the two lines x = ±C t (the cone)
export const BANDS = [1, -1].map(sgn => [[-PLUCK, 0], [PLUCK, 0], [PLUCK + sgn * C * T_TOP, T_TOP], [-PLUCK + sgn * C * T_TOP, T_TOP]].map(([x, t]) => stx(x).toFixed(1) + ',' + sty(t).toFixed(1)).join(' '));
export const LIGHT = [1, -1].map(sgn => ({ x1: stx(0), y1: sty(0), x2: stx(sgn * C * T_TOP), y2: sty(T_TOP) }));
export const START_T10 = 12;
export function stringView(t10) {
  const t = t10 / 10, c = C * t;
  return {
    t, c, tText: 't = ' + num(t, 1), path: pathOf(x => height(x, t)), centres: [-c, c].map(x => ({ x: sx(x), y: sy(0), sx: stx(x), sy: sty(t), ay: sy(height(x, t)) - 16 })), now: sty(t)
  };
}
export const tickX = x => sx(x);
export const stX = stx, stY = sty;
