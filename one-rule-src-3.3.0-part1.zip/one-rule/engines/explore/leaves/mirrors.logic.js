// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/mirrors.logic.js — leaf 3, mirrors (port of Octavo's octavo/leaves/mirrors.logic.js, the hand-off's work in progress; plain functions,
// no React). Every product goes through engines/labels.js (mul, mvZero, popcount, sigVec: the v15 API on the kernel); tests/explore/leaves.mirrors.test.mjs
// recomputes every number by standard routes (Householder reflections, the rotation matrix of twice the angle, determinants, the law of reflection traced by
// plane intersections, the corners counted by weight) and holds the outputs bit-identical to Octavo's.
// A mirror across the vector a sends x to −a x a⁻¹, the sandwich of the bit rule (a⁻¹ = a / a², and a² is a number). Front: two mirror lines through one point;
// a flag is flipped by the first and then by the second, and what is left is the turn by twice the angle between the mirrors. Back, the mathematician: the
// eight corners of the cube of three plus switches, each the product of the mirrors of its axes, in columns by the number of mirrors. Back, the physicist:
// light in a corner lined with mirrors; each mirror reverses the part of the beam's direction that points into it.
// Not carried over (docs/EXPLORE_PORT.md §3): COPY; the front's status line and screen-reader text (status, alt); the corner's sentences (what, kind, line1,
// line2, aria), cubeCaption and CUBE_ALT; the beam's status line and screen-reader text (status, alt). Added as data: the front's readouts apart and turnText
// (degrees), the corner's flag even, PARITY (the even and the odd corners, counted).
import { mul, mvZero, popcount, sigVec } from '../../labels.js';

// ---- the mirror of the bit rule, in the algebra of n plus switches (vectors are the blades 1, 2, 4 ...)
const vec = v => { const X = mvZero(v.length); v.forEach((c, i) => { X[1 << i] = c; }); return X; };
// −a x a⁻¹ as a whole multivector (a mirror sends a vector to a vector: every other part is zero)
export function sandwich(x, a) {
  const sq = sigVec(x.length, 0), A = vec(a), aa = mul(A, A, sq)[0], Y = mul(mul(A, vec(x), sq), A, sq);
  return Array.from(Y, c => -c / aa);
}
export const mirror = (x, a) => { const Y = sandwich(x, a); return x.map((_, i) => Y[1 << i]); };
// the size of the parts of −a x a⁻¹ that are not a vector
export const offVector = (x, a) => sandwich(x, a).reduce((s, c, m) => s + (popcount(m) === 1 ? 0 : Math.abs(c)), 0);

// ---- front: two mirror lines through the point C of the picture (viewBox 0 0 400 400), a flag, its image in the first mirror and in both
export const SPREAD = { min: 0, max: 90, step: 5 };          // the control: the angle between the mirrors, in degrees
export const START = { deg: 30, swap: false };
export const FLAG_AT = 75;                                    // the flag points 75° anticlockwise from the mirror that lies along 0°
export const C = 200, LINE = 186, LABEL_R = 181, ARC_R = 170, WEDGE_R = 34;
const POLE = [46, 148], PENNANT = [[148, 0], [106, 0], [127, 36]];   // the flag in its own frame: the pole along the first axis, the pennant on its anticlockwise side
const rad = d => d * Math.PI / 180, DEG = 180 / Math.PI;
const polar = (r, d) => [r * Math.cos(rad(d)), r * Math.sin(rad(d))];
const place = (p, d) => { const c = Math.cos(rad(d)), s = Math.sin(rad(d)); return [c * p[0] - s * p[1], s * p[0] + c * p[1]]; };
// the line of a mirror at d degrees and the vector across it
export const across = d => [-Math.sin(rad(d)), Math.cos(rad(d))];
export const FLAG = { pole: POLE.map(r => place([r, 0], FLAG_AT)), pennant: PENNANT.map(p => place(p, FLAG_AT)) };
const mapFlag = (f, g) => ({ pole: f.pole.map(g), pennant: f.pennant.map(g) });
// picture coordinates (y down) of a point given with y up
export const scr = p => [C + p[0], C - p[1]];
const f1 = x => (Math.abs(x) < 5e-10 ? 0 : x).toFixed(1);
const pathOf = pts => pts.map((p, i) => (i ? 'L' : 'M') + f1(scr(p)[0]) + ' ' + f1(scr(p)[1])).join(' ') + ' Z';
const lineOf = pts => ({ x1: f1(scr(pts[0])[0]), y1: f1(scr(pts[0])[1]), x2: f1(scr(pts[1])[0]), y2: f1(scr(pts[1])[1]) });
const flagDraw = f => ({ pole: lineOf(f.pole), pennant: pathOf(f.pennant) });
// an arc of radius r from d0 to d0 + sweep degrees (anticlockwise for a positive sweep), drawn in picture coordinates
export function arcPath(r, d0, sweep) {
  const [x0, y0] = scr(polar(r, d0)), [x1, y1] = scr(polar(r, d0 + sweep));
  return 'M' + f1(x0) + ' ' + f1(y0) + ' A' + r + ' ' + r + ' 0 ' + (Math.abs(sweep) > 180 ? 1 : 0) + ' ' + (sweep > 0 ? 0 : 1) + ' ' + f1(x1) + ' ' + f1(y1);
}
// the head of the arrow at the end of an arc: a triangle whose tip is at d0 + sweep, pointing along the way round
function arrowHead(r, d, dir, len = 15, half = 8) {
  const tip = polar(r, d), t = [-Math.sin(rad(d)) * dir, Math.cos(rad(d)) * dir], o = [Math.cos(rad(d)), Math.sin(rad(d))];
  const back = [tip[0] - len * t[0], tip[1] - len * t[1]];
  return pathOf([tip, [back[0] + half * o[0], back[1] + half * o[1]], [back[0] - half * o[0], back[1] - half * o[1]]]);
}

// the two mirrors of the state s = { deg, swap }: one lies along 0°, the other along deg; first acts the one along 0°, or (swapped) the one along deg
export function pair(s) {
  const first = s.swap ? s.deg : 0, second = s.swap ? 0 : s.deg;
  const once = p => mirror(p, across(first)), twice = p => mirror(once(p), across(second));
  const c1 = twice([1, 0]), c2 = twice([0, 1]);
  return { first, second, once, twice, M: [[c1[0], c2[0]], [c1[1], c2[1]]], angle: Math.atan2(c1[1], c1[0]) * DEG };
}
// how far and which way the two mirrors turn the plane: size in whole degrees, dir +1 anticlockwise, −1 clockwise, 0 for no turn (a half-turn takes the way the
// turn goes as the mirrors open, which is the order of the mirrors)
export function turnOf(s) {
  const p = pair(s), size = Math.round(Math.abs(p.angle) * 1e6) / 1e6;
  const dir = size === 0 ? 0 : size === 180 ? Math.sign(p.second - p.first) : Math.sign(p.angle);
  return { ...p, size, dir, sweep: dir * size };
}
export function frontView(s) {
  const t = turnOf(s), lab = s.swap ? ['2', '1'] : ['1', '2'];
  const ends = d => ({ ...lineOf([polar(-LINE, d), polar(LINE, d)]) });
  const mirrors = [{ d: 0, label: lab[0], at: scr(polar(LABEL_R, 180)), line: ends(0) }, { d: s.deg, label: lab[1], at: scr(polar(LABEL_R, s.deg)), line: ends(s.deg) }];
  return {
    t, mirrors,
    flag: flagDraw(FLAG), ghost: flagDraw(mapFlag(FLAG, t.once)), last: flagDraw(mapFlag(FLAG, t.twice)),
    wedge: s.deg > 0 ? arcPath(WEDGE_R, 0, s.deg) : null,
    arc: t.size > 0 ? arcPath(ARC_R, FLAG_AT, t.sweep - t.dir * 5) : null, head: t.size > 0 ? arrowHead(ARC_R, FLAG_AT + t.sweep, t.dir) : null,
    apart: s.deg + '°', turnText: t.size + '°'
  };
}
export const swapped = s => ({ ...s, swap: !s.swap });
export const setSpread = (s, deg) => (Number.isInteger(deg) && deg >= SPREAD.min && deg <= SPREAD.max && deg % SPREAD.step === 0 ? { ...s, deg } : s);

// ---- back, the mathematician: the corners of the cube of three plus switches, Cl(3,0)
export const N = 3;
const SUB = '₀₁₂₃₄₅₆₇₈₉';
export const axesOf = S => Array.from({ length: N }, (_, i) => i).filter(i => S >> i & 1);
export const cornerName = S => (S === 0 ? '1' : 'e' + axesOf(S).map(i => SUB[i + 1]).join(''));
export const productName = S => (S === 0 ? '1' : axesOf(S).map(i => 'e' + SUB[i + 1]).join(''));
const unit = i => { const u = Array(N).fill(0); u[i] = 1; return u; };
const one = () => { const X = mvZero(N); X[0] = 1; return X; };
// the corner S as k mirrors, V = e_i e_j … (the vectors of its axes, multiplied by the bit rule), acting by (−1)^k V x V⁻¹; returns V, V⁻¹ and the matrix (columns: where each axis goes)
export function cornerAct(S) {
  const sq = sigVec(N, 0), ax = axesOf(S), k = ax.length;
  let V = one(), Vi = one();
  for (const i of ax) V = mul(V, vec(unit(i)), sq);
  for (const i of [...ax].reverse()) { const E = vec(unit(i)), ee = mul(E, E, sq)[0]; Vi = mul(Vi, E.map(c => c / ee), sq); }
  const twist = k % 2 ? -1 : 1, cols = Array.from({ length: N }, (_, j) => mul(mul(V, vec(unit(j)), sq), Vi, sq).map(c => twist * c));
  return { V, Vi, k, cols, M: Array.from({ length: N }, (_, i) => cols.map(c => c[1 << i])) };
}
export const det3 = M => M[0][0] * (M[1][1] * M[2][2] - M[1][2] * M[2][1]) - M[0][1] * (M[1][0] * M[2][2] - M[1][2] * M[2][0]) + M[0][2] * (M[1][0] * M[2][1] - M[1][1] * M[2][0]);
// the picture: columns by the number of mirrors (viewBox 0 0 400 260), each corner a mark
export const CUBE = { w: 400, h: 260, cols: [52, 152, 252, 352], rows: [86, 156, 226], head: 30 };
export const CORNERS = (() => {
  const byK = Array.from({ length: N + 1 }, () => []);
  for (let S = 0; S < 1 << N; S++) byK[popcount(S)].push(S);
  return byK.flatMap((list, k) => list.map((S, j) => {
    const row = list.length === 1 ? 1 : j;
    return { S, k, even: k % 2 === 0, name: cornerName(S), x: CUBE.cols[k], y: CUBE.rows[row], left: 100 * CUBE.cols[k] / CUBE.w, top: 100 * CUBE.rows[row] / CUBE.h };
  }));
})();
export const LAYERS = Array.from({ length: N + 1 }, (_, k) => CORNERS.filter(c => c.k === k).length);
// the edges of the cube: two corners one mirror apart
export const EDGES = CORNERS.flatMap(a => CORNERS.filter(b => b.S > a.S && popcount(a.S ^ b.S) === 1).map(b => ({ a: a.S, b: b.S, x1: a.x, y1: a.y, x2: b.x, y2: b.y })));
export const COLUMN_HEADS = LAYERS.map((_, k) => k + (k === 1 ? ' mirror' : ' mirrors'));
// the even and the odd corners, counted (the numbers of Octavo's caption of the cube)
export const PARITY = { even: CORNERS.filter(c => c.even).length, odd: CORNERS.filter(c => !c.even).length };
// the line of Cartan–Dieudonné for the space of the cube: in ℝ³ at most 3 mirrors, and the far corner needs all of them
const SUP = '⁰¹²³⁴⁵⁶⁷⁸⁹';
export const MOST = { space: 'ℝ' + SUP[N], n: N, far: (1 << N) - 1 };
export const START_CORNER = 5;
export function cornerView(S) {
  const { M, k } = cornerAct(S), d = M.map((r, i) => r[i]), flips = d.map((v, i) => (v < 0 ? i : -1)).filter(i => i >= 0), det = det3(M);
  const diag = 'diag(' + d.map(v => (v > 0 ? '+1' : '−1')).join(', ') + ')';
  const title = S === 0 ? '1 (no mirror)' : cornerName(S) + ' = ' + productName(S), count = k + (k === 1 ? ' mirror' : ' mirrors'), detText = 'det = ' + (det > 0 ? '+1' : '−1');
  return { M, k, det, flips, d, diag, title, count, detText, even: det > 0 };
}

// ---- back, the physicist: a corner of a room lined with up to three mirrors (x to the right, y up, z out of the back wall towards you; the corner at 0)
export const ROOM = { W: 3.4, H: 3.2, D: 2.8 };
export const WALLS = [
  { id: 'floor', axis: 1, name: 'floor' },
  { id: 'back', axis: 2, name: 'back wall' },
  { id: 'left', axis: 0, name: 'left wall' }
];
export const PARTS = ['left-right', 'up-down', 'front-back'];
export const CHIPS = [{ id: 1, label: '1 mirror' }, { id: 2, label: '2 mirrors' }, { id: 3, label: '3 mirrors' }];
export const AIM = { min: 20, max: 50, step: 5 };            // the angle of the beam below level, in degrees
export const START_BEAM = { n: 3, aim: 35 };
export const HEADING = 45;                                    // seen from above, the beam heads 45° to the left of straight at the back wall
export const FLOOR_HIT = [1.6, 0, 1.05];                      // where the beam meets the floor
export const L_MAX = 9;
// the direction of the beam that comes in: aim degrees below level, heading into the corner
export const dirIn = aim => [-Math.cos(rad(aim)) * Math.sin(rad(HEADING)), -Math.sin(rad(aim)), -Math.cos(rad(aim)) * Math.cos(rad(HEADING))];
export const setBeam = (b, k) => { const n = k.n ?? b.n, aim = k.aim ?? b.aim; return CHIPS.some(c => c.id === n) && Number.isInteger(aim) && aim >= AIM.min && aim <= AIM.max && aim % AIM.step === 0 ? { n, aim } : b; };
const SIZE = [ROOM.W, ROOM.H, ROOM.D];
const onWall = (q, ax) => q.every((c, j) => j === ax || (c >= -1e-9 && c <= SIZE[j] + 1e-9));
// the drawing: an oblique view, the depth z drawn down and to the left (viewBox 0 0 400 330)
export const VIEW = { w: 400, h: 330, ox: 122, oy: 236, s: 52, k: 0.55, b: 38, m: 14 };
export const proj = ([x, y, z]) => [VIEW.ox + VIEW.s * (x - VIEW.k * z * Math.cos(rad(VIEW.b))), VIEW.oy - VIEW.s * (y - VIEW.k * z * Math.sin(rad(VIEW.b)))];
// how far from p along d the drawing goes before it reaches the margin of the picture (at most L_MAX)
function reach(p, d) {
  const a = proj(p), b = proj(p.map((c, i) => c + d[i])), lo = VIEW.m, hi = [VIEW.w - VIEW.m, VIEW.h - VIEW.m];
  let t = L_MAX;
  for (let j = 0; j < 2; j++) { const v = b[j] - a[j]; if (v > 1e-12) t = Math.min(t, (hi[j] - a[j]) / v); else if (v < -1e-12) t = Math.min(t, (lo - a[j]) / v); }
  return Math.max(0, t);
}
// the path of the beam: in to the floor, then straight to the nearest mirror it meets inside that mirror's edges, bounce (the mirror of the bit rule turns the
// direction), on again; the two ends stop at the margin of the picture
export function trace(n, aim) {
  const d0 = dirIn(aim), walls = WALLS.slice(0, n), back = d0.map(c => -c);
  let p = FLOOR_HIT.map((c, i) => c + reach(FLOOR_HIT, back) * back[i]), d = d0;
  const pts = [p], hits = [];
  for (let guard = 0; guard < 6; guard++) {
    let best = null;
    for (const w of walls) {
      if (d[w.axis] >= 0) continue;
      const t = -p[w.axis] / d[w.axis], q = p.map((c, i) => (i === w.axis ? 0 : c + t * d[i]));
      if (t > 1e-9 && onWall(q, w.axis) && (!best || t < best.t)) best = { t, q, w };
    }
    if (!best) break;
    p = best.q; pts.push(p); hits.push(best.w.id); d = mirror(d, unit(best.w.axis));
  }
  pts.push(p.map((c, i) => c + reach(p, d) * d[i]));
  return { pts, hits, dIn: d0, dOut: d };
}
const wallCorners = ax => { const [u, v] = [0, 1, 2].filter(j => j !== ax), c = (a, b) => { const q = [0, 0, 0]; q[u] = a; q[v] = b; return q; }; return [c(0, 0), c(SIZE[u], 0), c(SIZE[u], SIZE[v]), c(0, SIZE[v])]; };
const pt = p => p.map(f1).join(',');
// how dark each mirror is drawn, in the picture and in its key, so that the three faces of the corner read as three faces
export const SHADE = { floor: 0.12, back: 0.24, left: 0.36 };
// a small arrow head in the middle of a drawn segment, pointing along it
function arrowAt(a, c, f) {
  const m = [a[0] + f * (c[0] - a[0]), a[1] + f * (c[1] - a[1])], L = Math.hypot(c[0] - a[0], c[1] - a[1]), u = [(c[0] - a[0]) / L, (c[1] - a[1]) / L], len = 16, half = 8;
  return [[m[0] + len * u[0] / 2, m[1] + len * u[1] / 2], [m[0] - len * u[0] / 2 - half * u[1], m[1] - len * u[1] / 2 + half * u[0]], [m[0] - len * u[0] / 2 + half * u[1], m[1] - len * u[1] / 2 - half * u[0]]].map(pt).join(' ');
}
export function beamView(b) {
  const tr = trace(b.n, b.aim), flipped = [0, 1, 2].filter(i => Math.sign(tr.dOut[i]) !== Math.sign(tr.dIn[i])), kept = [0, 1, 2].filter(i => !flipped.includes(i));
  const back = flipped.length === 3, sp = tr.pts.map(proj), n = sp.length;
  return {
    tr, flipped, kept, back, screen: sp,
    walls: WALLS.map((w, i) => ({ ...w, on: i < b.n, pts: wallCorners(w.axis).map(proj).map(pt).join(' '), shade: SHADE[w.id] })),
    beam: sp.map(pt).join(' '), bounces: sp.slice(1, -1).map(p => p.map(f1)),
    arrowIn: arrowAt(sp[0], sp[1], 0.5), arrowOut: arrowAt(sp[n - 2], sp[n - 1], 0.55)
  };
}
