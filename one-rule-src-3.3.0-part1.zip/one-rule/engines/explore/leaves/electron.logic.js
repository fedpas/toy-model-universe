// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/electron.logic.js — loose leaf Electron under leaf 6 (port of Octavo's octavo/leaves/electron.logic.js; plain functions, no React).
// Five switches, the kernel's cell(1, 3, 1): time e_t squares to +1, space e_x, e_y, e_z to −1, and one zero switch e_0 to 0. The momentum is
// P = E e_t + k_x e_x + k_y e_y + k_z e_z + k_0 e_0. Every product is engines/labels.js's mul (the kernel's), every sign of the table of P × P the kernel's
// bladeMul, the determinant of P − m on the regular module the kernel's left-regular matrix and an exact Bareiss determinant (engines/schullerEngine.js).
// (P − m)(P + m) is the plain number E² − k² − m²: the energy on the curve is read from that product, and k_0 never enters.
// tests/explore/leaves.electron.test.mjs recomputes every number by standard routes (4 × 4 complex Dirac matrices, √(k² + m²), a numerical derivative, an
// independent rewriting of the products of generators) and holds them bit-identical to the Octavo output.
// Front: the curve E = √(k² + m²) over the light lines E = |k|, and the flat line of E along the zero switch. Back: the mathematician's table of P × P, whose mixed
// cells cancel in pairs; the physicist's curve, whose slope k/E is the speed, with the slow guess m + k²/2m and the fast guess |k|.
// Not carried over (docs/EXPLORE_PORT.md §3): COPY; the sentences of front (note, status, alt, boxAlt), tableNote, cellAria, the sentences of MATH (forces, det,
// sizes), miss and the lines line2, line3 and alt of physView, PHYS_CAP. Kept as data instead: front's sum as a readout and its flags zeroAddsNothing and massless;
// pairView; MATH.forces and MATH.det as formulas, SIZES; missOf and physView's slowMiss and fastMiss; physAt and physPaths (the physicist's picture at any mass).
import { bladeMul, mul } from '../../labels.js';
import { cell as cellOf } from '../../bitrule.js';
import { leftMatrix, bareissDet } from '../../schullerEngine.js';
import { num } from '../shared.js';

// ---- the five switches: time squares to +1 and space to −1 (the signs of the Dirac matrices, γ⁰γ⁰ = +1, γⁱγⁱ = −1), the zero switch to 0
export const NAMES = ['t', 'x', 'y', 'z', '0'];
export const SQUARES = cellOf(1, 3, 1);
export const MOMS = ['E', 'k_{x}', 'k_{y}', 'k_{z}', 'k_{0}'];      // the momentum along each switch
const NS = NAMES.length, DIM = 1 << NS;

// P from its five parts c = [E, k_x, k_y, k_z, k_0], as an element of the algebra of the five switches (switch i is label 2^i)
export function momentum(c) { const P = new Float64Array(DIM); c.forEach((v, i) => { P[1 << i] = v; }); return P; }
// (P − m)(P + m) by the kernel's product: its number part, and the size of everything else (0: the product is a plain number)
export function twin(c, m) {
  const A = momentum(c), B = momentum(c); A[0] = -m; B[0] = m;
  const Y = mul(A, B, SQUARES); let rest = 0;
  for (let i = 1; i < DIM; i++) rest += Math.abs(Y[i]);
  return { scalar: Y[0], rest };
}
// the energy on the curve for momentum k along e_x and k0 along the zero switch: the number part of (P − m)(P + m) is a quadratic a E² + b E + c in E, whose three
// coefficients are read from the product at E = −1, 0 and 1; E is its root E ≥ 0 (null when there is none)
export function energy(k, k0, m) {
  const f = E => twin([E, k, 0, 0, k0], m).scalar, c = f(0), p = f(1), q = f(-1), a = (p + q) / 2 - c, b = (p - q) / 2, d = b * b - 4 * a * c;
  if (Math.abs(a) < 1e-12 || d < 0) return null;
  const E = Math.max((-b + Math.sqrt(d)) / (2 * a), (-b - Math.sqrt(d)) / (2 * a));
  return E < 0 ? null : { E, E2: E * E };
}
// det(P − m) on the regular module (the algebra acting on itself by the kernel's products, N = 32 for the five switches), exact, for integer parts c and m
export function regularDet(c, m) {
  const x = { 0: -m }; c.forEach((v, i) => { if (v) x[1 << i] = v; });
  return bareissDet(leftMatrix(x, SQUARES));
}

// ---- front: three controls, counted in tenths
export const MV = [0, 20], KV = [-30, 30], WV = [-30, 30];                // mass m from 0 to 2; momentum k and k0 from −3 to 3
export const START = { mv: 5, kv: 10, wv: 0 };
export const canSet = s => [[s.mv, MV], [s.kv, KV], [s.wv, WV]].every(([v, [lo, hi]]) => Number.isInteger(v) && v >= lo && v <= hi);
// the picture: momentum k across, energy E up, one unit is U in a 600 × 400 view, the origin at O; light travels 1
export const VIEW = { w: 600, h: 400 }, O = { x: 300, y: 360 }, U = 80, K_LIM = 3.5, LIGHT_SPEED = 1;
export const toX = k => O.x + U * k, toY = E => O.y - U * E;
const pc = (x, y, V = VIEW) => ({ left: 100 * x / V.w, top: 100 * y / V.h });
const f1 = x => x.toFixed(1);
// a formula that breaks only before an equals sign: the spaces around + − · × and the space after = do not break
export const nb = t => t.replace(/ ([−+·×]) /g, ' $1 ').replace(/ = /g, ' = ');
// the curve E(k) of one mass, 141 points from k = −3.5 to 3.5
export function curvePath(mv) {
  const m = mv / 10, pts = [];
  for (let i = -70; i <= 70; i++) { const k = i / 20; pts.push((i === -70 ? 'M' : 'L') + f1(toX(k)) + ' ' + f1(toY(energy(k, 0, m).E))); }
  return pts.join(' ');
}
// the light lines E = |k|
export const LIGHT_PATH = 'M' + f1(toX(-K_LIM)) + ' ' + f1(toY(LIGHT_SPEED * K_LIM)) + ' L' + f1(toX(0)) + ' ' + f1(toY(0)) + ' L' + f1(toX(K_LIM)) + ' ' + f1(toY(LIGHT_SPEED * K_LIM));
// the numbers under the k axis, and where the words of the picture sit (percent of the picture)
export const K_TICKS = [-3, -2, -1, 1, 2, 3].map(t => ({ t, text: num(t, 0), x: toX(t), ...pc(toX(t), O.y + 19) }));
export const LABELS = { energy: pc(O.x + 10, 20), k: pc(toX(3.38), O.y + 19), lightL: pc(toX(-K_LIM), toY(2.35)), lightR: pc(toX(K_LIM), toY(2.35)) };
// the box beside the picture: momentum k0 along the zero switch across (percent of its width), the same E up (percent of its height, as in the picture)
export const BOX_HALF = 45;
export const boxLeft = w => 50 + BOX_HALF * w / K_LIM;
export const boxTop = E => 100 * toY(E) / VIEW.h;
export const BOX_TICKS = [-3, 3].map(t => ({ t, text: num(t, 0), left: boxLeft(t) }));
// a number under the axis of the box is left out while the dot sits on it (the line low, the dot near it)
const tickFree = (t, w, E) => !(E < 0.45 && Math.abs(w - t) < 0.7);

export function front(s) {
  const m = s.mv / 10, k = s.kv / 10, w = s.wv / 10, on = energy(k, w, m), off = energy(k, 0, m), E = on.E;
  // the zero switch changes nothing: the same energy, bit for bit, and the product (P − m)(P + m) is still a plain number
  const same = on.E === off.E && twin([E, k, 0, 0, w], m).rest === 0;
  // the readout: the sum, set as a formula, and the energy it gives
  const sq = x => num(x * x, 2);
  const sum = 'E² = k² + m² = ' + sq(k) + ' + ' + sq(m) + ' = ' + num(on.E2, 2) + ' → E = ' + num(E, 2);
  const top = boxTop(E), dotLeft = boxLeft(w);
  return {
    m, k, w, E, E2: on.E2, same, sum, zeroAddsNothing: s.wv !== 0 && same, massless: s.mv === 0,
    mText: num(m, 1), kText: num(k, 1), wText: num(w, 1), eText: num(E, 2),
    dot: { x: toX(k), y: toY(E) },
    // the letter E beside the drop line, on its outer side; the height m of the bottom of the curve, carried by a dotted level line out of the light lines
    // to the left, where nothing else is drawn
    // (the letter only when the drop line is long enough to carry it, the level line only when the curve is high enough to leave room under it)
    eLab: E >= 0.35 ? { ...pc(toX(k) + (k >= 0 ? 10 : -10), toY(E / 2)), side: k >= 0 ? 'start' : 'end' } : null,
    mMark: s.mv >= 3 ? { y: toY(m), x2: toX(-m - 0.12), ...pc(toX(-m - 0.2), toY(m)) } : null,
    box: { top, left: dotLeft, lab: { side: w >= 0 ? 'left' : 'right', below: top < 15 }, ticks: BOX_TICKS.filter(t => tickFree(t.t, w, E)) }
  };
}

// ---- back, the mathematician: the table of P × P. Cell (a, b) is the product of the parts of P along switches a and b; off the diagonal the two cells (a, b) and
// (b, a) carry the same two numbers and opposite signs, so they cancel; on the diagonal the square of the switch is left
const markup = mask => 'e_{' + NAMES.filter((_, i) => mask >> i & 1).join('') + '}';
const sgn = s => (s > 0 ? '+' : s < 0 ? '−' : '');
export function cell(a, b) {
  const [mask, s] = bladeMul(1 << a, 1 << b, SQUARES);
  if (a === b) return { a, b, diag: true, sign: s, mask, text: s === 0 ? '0' : sgn(s) + MOMS[a] + '^{2}' };
  return { a, b, diag: false, sign: s, mask, text: sgn(s) + markup(mask) };
}
export const TABLE = NAMES.map((_, a) => NAMES.map((__, b) => cell(a, b)));
export const partnerOf = (a, b) => [b, a];
// the pairs of cells off the diagonal that cancel: the same label, opposite signs
export function cancelPairs() {
  let n = 0;
  for (let a = 0; a < NS; a++) for (let b = a + 1; b < NS; b++) { const x = cell(a, b), y = cell(b, a); if (x.mask === y.mask && x.sign !== 0 && x.sign === -y.sign) n++; }
  return n;
}
// what the diagonal leaves: E^{2} − k_{x}^{2} − k_{y}^{2} − k_{z}^{2} + 0·k_{0}^{2}
export const diagonal = () => nb(NAMES.map((_, a) => { const s = cell(a, a).sign; return (s > 0 ? ' + ' : s < 0 ? ' − ' : ' + 0·') + MOMS[a] + '^{2}'; }).join('').replace(/^ \+ /, '').replace(/^ − /, '−'));
// a cell and its partner as data: both cells, whether they cancel (the same label, opposite signs), and the products as a formula; null: the whole table
export function pairView(sel) {
  if (!sel) return { pairs: cancelPairs(), diagonal: diagonal() };
  const [a, b] = sel, x = cell(a, b), ea = 'e_{' + NAMES[a] + '}', eb = 'e_{' + NAMES[b] + '}';
  if (x.diag) return { a, b, diag: true, square: x.sign, cells: [x], cancel: false, formula: nb(ea + ea + ' = ' + (x.sign === 0 ? '0' : sgn(x.sign) + '1')) };
  const [pa, pb] = partnerOf(a, b), y = cell(pa, pb);
  return { a, b, diag: false, square: null, cells: [x, y], cancel: x.mask === y.mask && x.sign !== 0 && x.sign === -y.sign, formula: nb(ea + eb + ' = ' + x.text + ' · ' + eb + ea + ' = ' + y.text) };
}
// the cells that are lit when (a, b) is chosen: the cell and its partner
export const litOf = sel => (sel ? [sel, partnerOf(sel[0], sel[1])].map(([a, b]) => a + ',' + b) : []);
// the size of a module and the power of the one factor in det(P − m)
export const detPower = N => N / 2;
const SIG = [1, -1, 0].map(v => SQUARES.filter(x => x === v).length);
const SQ_LINE = [1, -1, 0].map(v => NAMES.filter((_, i) => bladeMul(1 << i, 1 << i, SQUARES)[1] === v).map(n => 'e_{' + n + '}^{2}').join(' = ') + ' = ' + (v > 0 ? '+1' : v < 0 ? '−1' : '0')).join(', ');
// E² read from the diagonal: ε_t E² + Σ ε_i k_i² − m² = 0, so E² = Σ (−ε_i/ε_t) k_i² + m²/ε_t (the parts with ε_i = 0 drop out)
const ET = cell(0, 0).sign, SPACE = MOMS.slice(1).map((p, i) => ({ p, s: -cell(i + 1, i + 1).sign / ET })).filter(r => r.s !== 0);
const K2 = 'k^{2} = ' + SPACE.map((r, i) => (i ? (r.s > 0 ? ' + ' : ' − ') : r.s > 0 ? '' : '−') + r.p + '^{2}').join('');
export const MATH = {
  P: 'P = ' + MOMS.map((p, i) => p + ' e_{' + NAMES[i] + '}').join(' + ') + ' in Cl(' + SIG.join(',') + ')',
  squares: SQ_LINE,
  twin: nb('(P − m)(P + m) = P^{2} − m^{2} = ' + diagonal().replace(' + 0·k_{0}^{2}', '') + ' − m^{2}'),
  forces: nb('E^{2} = k^{2} ' + (ET > 0 ? '+' : '−') + ' m^{2}, ' + K2),
  det: nb('det(P − m) = (m^{2} + k^{2} − E^{2})^{N/2}')
};
// two modules and the power of det(P − m) on each: the 4 × 4 Dirac matrices (N = 4) and the algebra of the five switches on itself (N = 32)
export const SIZES = [{ of: 'dirac', N: 4, power: detPower(4) }, { of: 'regular', N: DIM, power: detPower(DIM) }];

// ---- back, the physicist: in units where light travels 1; physView is the picture of one mass, m = 1, its control counting twentieths of k from 0 to 3
export const PHYS_M = 1, PV = [0, 60], PHYS_START = 30;
export const PVIEW = { w: 440, h: 420 }, PO = { x: 52, y: 384 }, PU = 100, P_LIM = 3.45;
export const pX = k => PO.x + PU * k, pY = E => PO.y - PU * E;
export const speed = (k, E) => k / E;
export const slowGuess = (k, m) => m + k * k / (2 * m);
export const fastGuess = k => Math.abs(k);
const ppath = pts => pts.map(([k, E], i) => (i ? 'L' : 'M') + f1(pX(k)) + ' ' + f1(pY(E))).join(' ');
// the energy on the curve as a number (NaN where the product has no root)
const eOf = (k, m) => (energy(k, 0, m) || { E: NaN }).E;
export const PHYS_PATHS = {
  curve: ppath(Array.from({ length: 70 }, (_, i) => { const k = i / 20; return [k, eOf(k, PHYS_M)]; })),
  slow: ppath(Array.from({ length: 47 }, (_, i) => { const k = i / 20; return [k, slowGuess(k, PHYS_M)]; })),
  light: ppath([[0, 0], [P_LIM, LIGHT_SPEED * P_LIM]])
};
export const PHYS_LABELS = {
  energy: pc(PO.x + 10, 18, PVIEW), momentum: pc(pX(P_LIM), PO.y - 16, PVIEW), light: pc(pX(1.25), pY(0.55), PVIEW),
  slow: pc(pX(1.62), pY(2.55), PVIEW), rest: pc(pX(0.08), pY(1.3), PVIEW)
};
export const P_TICKS = [1, 2, 3].map(t => ({ t, text: num(t, 0), x: pX(t), y: pY(t), k: pc(pX(t), PO.y + 19, PVIEW), e: pc(PO.x - 12, pY(t), PVIEW) }));
// how far a guess g is from E, in percent of E (two figures at most, two decimals at most), and on which side: +1 above E, −1 below, 0 exact
export function missOf(g, E) {
  if (g === E) return { pct: 0, side: 0, text: '0%' };
  const q = 100 * Math.abs(g - E) / E, side = g > E ? 1 : -1;
  return { pct: q, side, text: (side > 0 ? '+' : '−') + (q >= 10 ? q.toFixed(0) : q >= 1 ? q.toFixed(1) : q.toFixed(2)) + '%' };
}
// the physicist's picture at momentum k ≥ 0 and mass m ≥ 0: the dot, the tangent and its slope k/E (none at the corner k = 0 of the massless curve), the slope
// triangle, the two guesses (the slow one only when m > 0)
export function physAt(k, m) {
  const E = energy(k, 0, m).E, v = E > 0 ? speed(k, E) : null, slow = m > 0 ? slowGuess(k, m) : null, fast = fastGuess(k);
  // the tangent: 1.2 across each way from the dot, never left of the energy axis; the slope triangle: 1 across along the tangent and v up, to the right of the dot
  // or, near the right edge, to its left
  const k1 = Math.max(0, k - 1.2), k2 = k + 1.2, right = k <= 2.2;
  const a = right ? [k, E] : [k - 1, E - v], c = [a[0] + 1, a[1]], b = [a[0] + 1, a[1] + v];
  return {
    k, E, v, slow, fast, kText: num(k, 2),
    dot: { x: pX(k), y: pY(E) },
    tangent: v === null ? null : { x1: pX(k1), y1: pY(E + (k1 - k) * v), x2: pX(k2), y2: pY(E + (k2 - k) * v) },
    triangle: v === null ? null : { pts: [a, c, b].map(([x, y]) => f1(pX(x)) + ',' + f1(pY(y))).join(' '), run: pc(pX(a[0] + 0.5), pY(a[1] - 0.14), PVIEW), rise: pc(pX(c[0] + 0.07), pY(a[1] + v / 2), PVIEW), vText: num(v, 2), show: v > 0.05 },
    line1: 'E = ' + num(E, 2) + ' · speed k/E = ' + (v === null ? '—' : num(v, 2)),
    slowMiss: slow === null ? null : missOf(slow, E), fastMiss: missOf(fast, E)
  };
}
export const physView = pv => physAt(pv / 20, PHYS_M);
// the curve, the slow guess and the light line of the physicist's picture at mass m, cut where they leave the picture (E up to 3.8)
export function physPaths(m) {
  const inside = ([, E]) => E <= 3.8;
  return {
    curve: ppath(Array.from({ length: 70 }, (_, i) => { const k = i / 20; return [k, energy(k, 0, m).E]; }).filter(inside)),
    slow: m > 0 ? ppath(Array.from({ length: 70 }, (_, i) => { const k = i / 20; return [k, slowGuess(k, m)]; }).filter(inside)) : null,
    light: PHYS_PATHS.light
  };
}
