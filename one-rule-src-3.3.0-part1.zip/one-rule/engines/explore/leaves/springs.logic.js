// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/springs.logic.js — loose leaf Springs under leaf 2 (port of Octavo's octavo/leaves/springs.logic.js; plain functions, no React). The sign
// of a corner in a label is engines/springEngine.js's walsh, the springs are its edges; tests/explore/leaves.springs.test.mjs recomputes every number by standard
// routes (Sylvester's Hadamard matrix, the matrix nI − A, RK4, the energy, spectral projectors) and holds them bit-identical to the Octavo output.
// Unit masses sit on the 2ⁿ corners of the cube of n switches and unit springs on its edges; each mass moves up and down along its own line, and the springs pull
// with the matrix L = nI − A of the cube. Label s marks corner x with + when x and s share an even number of 1s and with − otherwise; that pattern is a way to
// wobble, with speed² = 2 × (the number of 1s of s). Front: one label at a time, or one plucked corner. Back: the labels counted by their 1s (the mathematician,
// Pascal's triangle) and the four pitches in the motion of a plucked corner (the physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY, INTRO, UNITS, statusOf, altOf; the screen-reader texts (groups()[].aria, corners[].aria, PASCAL[].aria) and the
// sentences of frontView (status, alt), mathView (alt) and physView (caption, alt). Their facts are the data already returned (levels, coeffs, pitches, energy).
import { popcount } from '../../labels.js';
import { edges, walsh } from '../../springEngine.js';
import { bitsOf } from '../names.js';
import { num } from '../shared.js';

export const N = 3;                  // the cube of the front and of the physicist: three switches, eight corners, twelve springs
export const SIZES = [2, 3, 4];      // the cubes the mathematician can pick: a square, the cube, the cube of four switches
export const AMP = 0.5;              // a label starts with each corner at height +AMP or −AMP (its sign), at rest: a spring between a + and a − corner is stretched by 1
export const SPEED = 1.5;            // the motion runs SPEED times faster than the clock of the screen

// ---- labels, patterns, springs
export const bits = (v, n) => bitsOf(v, n);                                   // the bits naming of ../names.js: the first switch on the right
const WORD = ['no', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten'];
const word = k => WORD[k] ?? String(k);
export const onesText = k => (k === 1 ? 'one 1' : word(k) + ' 1s');
// the sign of corner x in the pattern of label s: + when x and s share an even number of 1s (the Walsh sign of springEngine.js)
export const sign = walsh;
export const pattern = (n, s) => Array.from({ length: 1 << n }, (_, x) => sign(s, x));
export const omega2 = s => 2 * popcount(s);                                    // speed² of the wobble of label s (springs and masses of strength 1)
// the springs: one along each edge of the cube, between two corners that differ in one switch
export const springs = n => edges(n).map(([a, b]) => [a, b]);
export function laplacian(n) {
  const M = 1 << n, L = Array.from({ length: M }, () => new Array(M).fill(0));
  for (const [a, b] of springs(n)) { L[a][a] += 1; L[b][b] += 1; L[a][b] -= 1; L[b][a] -= 1; }
  return L;
}
// the springs that a label stretches: those between a + corner and a − corner
export const stretched = (n, s) => springs(n).filter(([a, b]) => sign(s, a) !== sign(s, b)).length;
// the labels of n switches by their number of 1s: level j holds the labels with j ones, all with speed² 2j
export function levels(n) {
  const out = Array.from({ length: n + 1 }, (_, j) => ({ j, labels: [] }));
  for (let s = 0; s < 1 << n; s++) out[popcount(s)].labels.push(s);
  return out.map(l => ({ ...l, count: l.labels.length, w2: omega2(l.labels[0]) }));
}
// the eigenvalues of L, from the matrix itself (Jacobi rotations), smallest first
export function eigenvalues(n) {
  const A = laplacian(n), M = A.length;
  for (let sweep = 0; sweep < 60; sweep++) {
    let off = 0; for (let i = 0; i < M; i++) for (let j = i + 1; j < M; j++) off += A[i][j] * A[i][j];
    if (off < 1e-26) break;
    for (let p = 0; p < M; p++) for (let q = p + 1; q < M; q++) {
      if (Math.abs(A[p][q]) < 1e-300) continue;
      const th = (A[q][q] - A[p][p]) / (2 * A[p][q]), t = (th >= 0 ? 1 : -1) / (Math.abs(th) + Math.sqrt(th * th + 1)), c = 1 / Math.sqrt(t * t + 1), sn = t * c;
      for (let k = 0; k < M; k++) { const kp = A[k][p], kq = A[k][q]; A[k][p] = c * kp - sn * kq; A[k][q] = sn * kp + c * kq; }
      for (let k = 0; k < M; k++) { const pk = A[p][k], qk = A[q][k]; A[p][k] = c * pk - sn * qk; A[q][k] = sn * pk + c * qk; }
    }
  }
  return A.map((r, i) => r[i]).sort((a, b) => a - b);
}

// ---- the motion: x'' = −L x, solved through the labels
// the parts of a start along each label: c_s = (w_s · x0) / 2ⁿ, d_s = (w_s · v0) / 2ⁿ, and the speed of the label
export function coeffs(n, x0, v0) {
  const M = 1 << n;
  return Array.from({ length: M }, (_, s) => {
    let c = 0, d = 0;
    for (let x = 0; x < M; x++) { const w = sign(s, x); c += w * x0[x]; d += w * v0[x]; }
    return { s, c: c / M, d: d / M, w: Math.sqrt(omega2(s)) };
  });
}
// heights x and speeds v of the corners at time t: x(t) = Σ_s (c_s cos ωt + d_s sin ωt / ω) w_s; a label with ω = 0 drifts (c_s + d_s t)
export function motion(n, x0, v0, t) {
  const M = 1 << n, x = new Array(M).fill(0), v = new Array(M).fill(0);
  for (const { s, c, d, w } of coeffs(n, x0, v0)) {
    const a = w > 0 ? c * Math.cos(w * t) + d * Math.sin(w * t) / w : c + d * t;
    const b = w > 0 ? -c * w * Math.sin(w * t) + d * Math.cos(w * t) : d;
    for (let y = 0; y < M; y++) { const g = sign(s, y); x[y] += a * g; v[y] += b * g; }
  }
  return { x, v };
}
// the energy in the springs (½ stretch² each) and in the motion (½ speed² each)
export const potential = (n, x) => springs(n).reduce((e, [a, b]) => e + (x[a] - x[b]) ** 2 / 2, 0);
export const kinetic = v => v.reduce((e, c) => e + c * c / 2, 0);
const zeros = n => new Array(1 << n).fill(0);
export const labelStart = (n, s) => ({ x0: pattern(n, s).map(w => AMP * w), v0: zeros(n) });
export const pluckStart = (n, c) => ({ x0: Array.from({ length: 1 << n }, (_, y) => (y === c ? 1 : 0)), v0: zeros(n) });

// ---- speeds for print
const whole = r => Math.abs(r - Math.round(r)) < 1e-12;
export const speedText = w2 => { const r = Math.sqrt(w2); return w2 === 0 ? '0' : whole(r) ? '√' + w2 + ' = ' + Math.round(r) : '√' + w2 + ' ≈ ' + r.toFixed(1); };   // √4 = 2, √2 ≈ 1.4
export const speedShort = w2 => { const r = Math.sqrt(w2); return whole(r) ? String(Math.round(r)) : '≈ ' + r.toFixed(1); };                               // 2, ≈ 1.4
export const speedSym = w2 => { const r = Math.sqrt(w2); return whole(r) ? String(Math.round(r)) : '√' + w2; };                                               // 2, √2
// a share as the smallest fraction that gives it: 3/8, 1/4, 0 (a decimal when no denominator up to 64 does)
export function fracOf(x) {
  for (let d = 1; d <= 64; d++) { const k = Math.round(x * d); if (Math.abs(x * d - k) < 1e-9) return k === 0 ? '0' : d === 1 ? String(k) : k + '/' + d; }
  return num(x, 3);
}

// ---- front: the cube of springs
// geometry of the picture: corner x at rest, in the units of the viewBox (switch 1 to the right, switch 2 up, switch 3 into the page)
export const GEO = { edge: 150, dx: 0.5, dy: -0.38, scale: 36, ox: 42, oy: 278, r: 17, rBack: 14, hitW: 48, hitH: 97, hitUp: 4.5 };
export const VIEW = { w: 310, h: 336 };
export const restOf = c => ({ x: GEO.ox + GEO.edge * ((c & 1) + GEO.dx * (c >> 2 & 1)), y: GEO.oy - GEO.edge * (c >> 1 & 1) + GEO.edge * GEO.dy * (c >> 2 & 1) });
export const cornerName = c => (c >> 2 & 1 ? 'back' : 'front') + ' ' + (c >> 1 & 1 ? 'top' : 'bottom') + ' ' + (c & 1 ? 'right' : 'left');
// a spring drawn from (ax, ay) to (bx, by): straight ends and a zig-zag of `turns` coils in the middle, so that the coils spread as the spring stretches
export function coil(ax, ay, bx, by, turns = 6, amp = 5.5, lead = 0.24) {
  const dx = bx - ax, dy = by - ay, L = Math.hypot(dx, dy) || 1, px = -dy / L, py = dx / L, pts = [[ax, ay], [ax + dx * lead, ay + dy * lead]];
  for (let i = 1; i < 2 * turns; i++) { const f = lead + (1 - 2 * lead) * i / (2 * turns), side = i % 2 ? 1 : -1; pts.push([ax + dx * f + px * amp * side, ay + dy * f + py * amp * side]); }
  pts.push([ax + dx * (1 - lead), ay + dy * (1 - lead)], [bx, by]);
  return pts.map(p => p[0].toFixed(1) + ',' + p[1].toFixed(1)).join(' ');
}
export const START = { view: 'label', s: 5, v: 2, t: 0 };                  // label 101; the corner the pluck uses first is the front top left one
export const pickLabel = (st, s) => ({ ...st, view: 'label', s, t: 0 });
export const pluckAt = (st, c) => ({ ...st, view: 'pluck', v: c, t: 0 });
export const advance = (st, dt) => ({ ...st, t: st.t + dt });
export const startOf = st => (st.view === 'pluck' ? pluckStart(N, st.v) : labelStart(N, st.s));
// the chips: the labels of the cube grouped by their number of 1s, each group with its speed
export const groups = st => levels(N).map(l => ({
  j: l.j, caption: l.w2 === 0 ? 'still' : 'speed ' + speedShort(l.w2),
  chips: l.labels.map(s => ({ s, text: bits(s, N), on: st.view === 'label' && st.s === s }))
}));
// everything the front draws at the time st.t
export function frontView(st) {
  const { x0, v0 } = startOf(st), { x, v } = motion(N, x0, v0, st.t), pe = potential(N, x), ke = kinetic(v), tot = pe + ke;
  const signs = st.view === 'label' ? pattern(N, st.s) : null;
  const corners = Array.from({ length: 1 << N }, (_, c) => {
    const r = restOf(c), back = (c >> 2 & 1) === 1;
    return {
      c, rx: r.x, ry: r.y, cx: r.x, cy: r.y - GEO.scale * x[c], r: back ? GEO.rBack : GEO.r, back, mark: signs ? (signs[c] > 0 ? '+' : '−') : '', plus: !!signs && signs[c] > 0,
      plucked: st.view === 'pluck' && st.v === c,
      hit: { left: r.x / VIEW.w * 100, top: (r.y - GEO.hitUp) / VIEW.h * 100, width: GEO.hitW / VIEW.w * 100, height: GEO.hitH / VIEW.h * 100 }
    };
  });
  const lines = springs(N).map(([a, b]) => {
    const A = corners[a], B = corners[b], depth = (a >> 2 & 1) + (b >> 2 & 1);
    return { a, b, depth, pts: coil(A.cx, A.cy, B.cx, B.cy) };
  }).sort((p, q) => q.depth - p.depth);
  return {
    corners, order: [...corners].sort((p, q) => Number(q.back) - Number(p.back)), lines,
    energy: tot > 1e-12 ? { springs: pe / tot, motion: ke / tot, total: tot } : { springs: 0, motion: 0, total: 0 },
    groups: groups(st), plucking: st.view === 'pluck'
  };
}

// ---- back, the mathematician: the labels stacked by their number of 1s on an axis of speed²
export const MATH = { w: 360, h: 236, x0: 50, x1: 316, base: 190, bh: 22, gap: 4 };
export const pascal = k => levels(k).map(l => l.count);
export const PASCAL = [0, 1, 2, 3, 4].map(k => ({ k, nums: pascal(k), pick: SIZES.includes(k) }));
const eig = x => (whole(x) ? String(Math.round(x) + 0) : num(x, 2));
export function mathView(n) {
  const L = levels(n), wTop = L[L.length - 1].w2, bw = 14 + 9 * n;
  const cols = L.map(l => {
    const x = MATH.x0 + (MATH.x1 - MATH.x0) * l.w2 / wTop;
    return {
      j: l.j, x, w2: l.w2, count: l.count, countY: MATH.base - l.count * (MATH.bh + MATH.gap) - 10,
      boxes: l.labels.map((s, i) => ({ s, text: bits(s, n), x: x - bw / 2, y: MATH.base - (i + 1) * (MATH.bh + MATH.gap), w: bw, h: MATH.bh }))
    };
  });
  const ev = eigenvalues(n);
  return {
    n, cols, ev, top: Math.min(...cols.map(c => c.countY)) - 22,               // the picture starts just above the tallest stack's count
    eigenLine: 'Eigenvalues of ' + n + 'I − A: ' + ev.map(eig).join(', ') + '.'
  };
}

// ---- back, the physicist: the pitches of a plucked corner
export const PLUCKED = 0;                                                 // the corner the physicist plucks (each corner's own height moves the same way)
export const PHYS = { w: 360, h: 300, axis: 118, sx0: 36, sk: 112, bw: 22, bh: 16, bgap: 3, tx0: 36, tx1: 314, t1: 20, top: 184, unit: 60, samples: 400 };
export const traceY = h => PHYS.top + PHYS.unit * (1 - h);
const traceX = t => PHYS.tx0 + (PHYS.tx1 - PHYS.tx0) * t / PHYS.t1;
// each level of the cube as a pitch: its speed, its labels, its part of the plucked corner's height (amp) and its energy
export function pitches() {
  const M = 1 << N, { x0, v0 } = pluckStart(N, PLUCKED), cs = coeffs(N, x0, v0);
  return levels(N).map(l => ({
    j: l.j, w2: l.w2, w: Math.sqrt(l.w2), count: l.count, labels: l.labels,
    amp: l.labels.reduce((a, s) => a + cs[s].c * sign(s, PLUCKED), 0),
    energy: l.labels.reduce((a, s) => a + 0.5 * (omega2(s) * cs[s].c ** 2 + cs[s].d ** 2) * M, 0)
  }));
}
export const PITCH_START = 1;
const path = pts => pts.map((p, i) => (i ? 'L' : 'M') + p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' ');
export function physView(j) {
  const P = pitches(), E = P.reduce((a, p) => a + p.energy, 0), p = P[j], { x0, v0 } = pluckStart(N, PLUCKED);
  const lines = P.map(q => ({
    j: q.j, x: PHYS.sx0 + PHYS.sk * q.w, sym: speedSym(q.w2), share: fracOf(q.amp), on: q.j === j,
    blocks: q.labels.map((s, k) => ({ s, y: PHYS.axis - PHYS.bgap - PHYS.bh - k * (PHYS.bh + PHYS.bgap) })),
    topY: PHYS.axis - q.count * (PHYS.bh + PHYS.bgap) - 8
  }));
  const ts = Array.from({ length: PHYS.samples + 1 }, (_, i) => PHYS.t1 * i / PHYS.samples);
  const trace = path(ts.map(t => [traceX(t), traceY(motion(N, x0, v0, t).x[PLUCKED])]));
  const part = path(ts.map(t => [traceX(t), traceY(p.amp * Math.cos(p.w * t))]));
  return {
    P, lines, trace, part, total: E,
    formula: 'x(t) = ' + P.map(q => fracOf(q.amp) + (q.w2 === 0 ? '' : ' cos ' + speedSym(q.w2) + 't')).join(' + '),
    options: P.map(q => ({ id: q.j, label: speedSym(q.w2) }))
  };
}
