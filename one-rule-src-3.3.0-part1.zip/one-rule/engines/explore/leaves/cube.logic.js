// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/cube.logic.js — loose leaf Cube under leaf 6 (port of Octavo's octavo/leaves/cube.logic.js; plain functions, no React). Every product is the
// kernel's (engines/labels.js bladeMul and mul on engines/bitrule.js), the sign of the reverse is the kernel's reorderSign(m, m); tests/explore/leaves.cube.test.mjs
// recomputes every number by standard routes (Householder reflections composed as matrices, the textbook Lorentz boost and rotation matrices, the Dirac matrices,
// direct enumeration of bit strings, integer arithmetic) and holds them bit-identical to the Octavo output.
// Labels are bit masks over the axes t = 1, x = 2, y = 4, z = 8; time squares to +1 and space to −1 (sigVec(1, n − 1)), as on the Dirac and Maxwell pages.
// Front: a ladder of three spacetimes (points in 2D, a square in 3D, a cube in 4D). The even labels of each are the corners of its half-cube (the demicube): the
// corner 1 and, one edge away, the planes. A plane whose element squares to +1 is a boost plane, to −1 a turn plane; it is the chooser of the move. Two mirrors
// x ↦ −a x a⁻¹ and x ↦ −b x b⁻¹ make the move x ↦ (ba) x (ba)⁻¹, and the product ba has weight only on the corner 1 and on the plane. Back: the mathematician
// multiplies the corners of the half-cube of 4D spacetime (the sign from bladeMul, the name of the product by XOR or by the primes of names.js); the physicist
// looks at a cube from someone passing (its length along the motion, its clocks, the interval of two corners).
// Not carried over (docs/EXPLORE_PORT.md §3): COPY and LABELS, and every sentence: frontView status, alt, weightCap, weightAlt and the slider's label; chooserOf
// alt and the corners' aria; productView kindLine, evenLine, alt and the corners' aria; passView cellsAlt, line, keep and alt; the label of RUNG_CHIPS. Their facts
// are returned as data (interval, tspan, amountText, planeName, others, counts, kinds, cells, Icube, Ipass, clocks). Added for the V2 picture, whose controls are
// chips (D24): ANGLE_CHIPS, SPEED_CHIPS, PASS_SHOW, cornerKind, nameIn.
import { bladeMul, mul, mvZero, popcount, sigVec } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';
import { bitsOf, combineNames, isEven, nameOf, primeName } from '../names.js';
import { num, track } from '../shared.js';

// ---- the algebra of n-dimensional spacetime with the switches
export const AXES = ['t', 'x', 'y', 'z'];
export const sqOf = n => sigVec(1, n - 1);
// the letters of a label: 3 -> tx, 6 -> xy, 15 -> txyz, 0 -> 1
export const letters = m => (m === 0 ? '1' : AXES.filter((_, i) => m >> i & 1).join(''));
export const axesIn = m => AXES.map((_, i) => i).filter(i => m >> i & 1);
// a point (t, x, y, z) as a vector of the algebra and back
export const vecOf = (n, p) => { const v = mvZero(n); p.forEach((c, i) => { v[1 << i] = c; }); return v; };
export const coordsOf = (n, v) => Array.from({ length: n }, (_, i) => v[1 << i]);
// the reverse of a multivector: each blade times the kernel's sign of putting its own generators back in order
const reverse = M => M.map((c, m) => (reorderSign(m, m) < 0 ? -c : c));
// the interval t² − x² − y² − z² between two points: the square of their difference
export function interval(n, p, q) { const d = vecOf(n, p.map((c, i) => c - q[i])); return mul(d, d, sqOf(n))[0]; }

// ---- the half-cube: the even labels of n switches, joined when they differ in two switches
export function halfCube(n) {
  const corners = [], edges = [];
  for (let m = 0; m < 1 << n; m++) if (isEven(m)) corners.push(m);
  for (const a of corners) for (const b of corners) if (a < b && popcount(a ^ b) === 2) edges.push([a, b]);
  return { corners, edges };
}
export const opposite = (n, m) => m ^ ((1 << n) - 1);
export const planesOf = n => halfCube(n).corners.filter(m => popcount(m) === 2);
export const squareOf = (n, m) => bladeMul(m, m, sqOf(n))[1];
export const kindOf = (n, m) => (squareOf(n, m) > 0 ? 'boost' : 'turn');
export const colorOf = kind => 'var(--' + kind + ')';
// what a corner of the half-cube is: the corner 1, a boost or a turn plane, the volume of all n switches, or (n = 4 has none other) null
export const cornerKind = (n, m) => (m === 0 ? 'one' : popcount(m) === n ? 'volume' : popcount(m) === 2 ? kindOf(n, m) : null);
// the name of a corner of the half-cube of n switches in the naming mode ('bits' with n digits | 'numbers' | 'primes'): names.js nameOf
export const nameIn = (m, mode, n) => nameOf(m, mode, n);

// ---- two mirrors and the move they make
// The amount is an angle θ (a turn) or a speed v, a fraction of the speed of light (a boost; its rapidity is atanh v). Mirror 1 flips one space axis of the plane;
// mirror 2 sits at half the angle, or moves at the speed whose rapidity is half (tanh of half the rapidity). The normals are taken so that ba has weight +cos or +cosh on 1.
export const rapidity = v => Math.atanh(v);
export function mirrorsOf(n, m, amt) {
  const [i, j] = axesIn(m), a = new Array(n).fill(0), b = new Array(n).fill(0);
  if (kindOf(n, m) === 'turn') { a[i] = 1; b[i] = -Math.cos(amt / 2); b[j] = -Math.sin(amt / 2); return { a, b, flip: i, half: amt / 2, u: null }; }
  const h = rapidity(amt) / 2;
  a[j] = 1; b[j] = -Math.cosh(h); b[i] = -Math.sinh(h);
  return { a, b, flip: j, half: h, u: Math.tanh(h) };
}
// the move: the product ba of the two mirrors, a multivector of the algebra
export function moveOf(n, m, amt) { const { a, b } = mirrorsOf(n, m, amt); return mul(vecOf(n, b), vecOf(n, a), sqOf(n)); }
// one mirror: p ↦ −a p a⁻¹ (a⁻¹ = a / a²)
export function reflect(n, a, p) { const sq = sqOf(n), A = vecOf(n, a), a2 = mul(A, A, sq)[0], r = mul(mul(A, vecOf(n, p), sq), A, sq); return coordsOf(n, r).map(c => -c / a2); }
// the move applied by its sandwich: p ↦ M p M⁻¹ (M⁻¹ = reverse(M) / M reverse(M))
export function sandwich(n, M, p) { const sq = sqOf(n), R = reverse(M), norm = mul(M, R, sq)[0], r = mul(mul(M, vecOf(n, p), sq), R, sq); return coordsOf(n, r).map(c => c / norm); }
// a point after one mirror (once) or after both
export function imageOf(n, m, amt, once, p) { const { a, b } = mirrorsOf(n, m, amt), p1 = reflect(n, a, p); return once ? p1 : reflect(n, b, p1); }

// ---- the controls of the front
export const RUNG_NS = [2, 3, 4];
export const RUNG_CHIPS = [{ id: 2, big: '2D', small: 'points' }, { id: 3, big: '3D', small: 'a square' }, { id: 4, big: '4D', small: 'a cube' }];
export const ANGLE = { min: -180, max: 180, step: 5 };     // degrees
export const SPEED = { min: -80, max: 80, step: 5 };       // hundredths of the speed of light
export const stepsOf = R => Array.from({ length: (R.max - R.min) / R.step + 1 }, (_, k) => R.min + k * R.step);
const clamp = (v, R) => Math.min(R.max, Math.max(R.min, Math.round(v / R.step) * R.step));
// the amounts the chips of the V2 picture offer (D24: chips, never a slider): nine angles and nine speeds of the range above
export const ANGLE_CHIPS = [-120, -90, -60, -30, 0, 30, 60, 90, 120];
export const SPEED_CHIPS = [-80, -60, -40, -20, 0, 20, 40, 60, 80];
export const START = { n: 2, plane: { 2: 3, 3: 3, 4: 3 }, deg: 60, sv: 60, once: false };
export const planeOf = s => s.plane[s.n];
export const amountOf = (n, m, s) => (kindOf(n, m) === 'turn' ? s.deg * Math.PI / 180 : s.sv / 100);
export const setRung = (s, n) => (RUNG_NS.includes(n) ? { ...s, n } : s);
export const pickPlane = (s, m) => (planesOf(s.n).includes(m) ? { ...s, plane: { ...s.plane, [s.n]: m } } : s);
export const setAmount = (s, v) => (kindOf(s.n, planeOf(s)) === 'turn' ? { ...s, deg: clamp(v, ANGLE) } : { ...s, sv: clamp(v, SPEED) });
export const setOnce = (s, once) => ({ ...s, once: !!once });
export const MIRROR_CHOICE = [{ id: 'once', label: 'Mirror once' }, { id: 'twice', label: 'Mirror twice' }];

// ---- what each rung moves, at time 0: the two ends and the middle of a ruler, the corners of a square, the corners of a cube (off the centre, so that the move shows)
const CUBE_AT = [0.25, 1.05];
export const OBJECTS = {
  2: { pts: [[0, 0.5], [0, 1], [0, 1.5]], segs: [[0, 2]], pair: [0, 2] },
  3: { pts: [[0, 0.3, 0.2], [0, 1.1, 0.2], [0, 1.1, 1], [0, 0.3, 1]], segs: [[0, 1], [1, 2], [2, 3], [3, 0]], pair: [0, 2] },
  4: { pts: Array.from({ length: 8 }, (_, c) => [0, CUBE_AT[c & 1], CUBE_AT[c >> 1 & 1], CUBE_AT[c >> 2 & 1]]), segs: [], pair: [0, 7] }
};
for (let c = 0; c < 8; c++) for (let d = 0; d < 3; d++) if (!(c >> d & 1)) OBJECTS[4].segs.push([c, c | 1 << d]);

// ---- the pictures: a fixed window for each rung (it holds every position the controls reach; the test checks that), K units of the picture per unit of length,
// the origin at (OX, OY). 2D: space across, time up. 3D and 4D: a camera above the floor (azimuth −60°, elevation 50°) that sees x going right, y going back and the
// upright axis going up: time in 3D, z in 4D (time is then written at the corners). From this camera no boosted square of the 3D picture is seen edge-on.
const AZ = -60 * Math.PI / 180, EL = 50 * Math.PI / 180;
export const CAMERA = { x: [-Math.sin(AZ), -Math.sin(EL) * Math.cos(AZ)], y: [Math.cos(AZ), -Math.sin(EL) * Math.sin(AZ)], up: Math.cos(EL) };
export const VIEW = {
  2: { w: 400, h: 380, K: 80, OX: 186, OY: 190 },
  3: { w: 400, h: 400, K: 100, OX: 175, OY: 200 },
  4: { w: 400, h: 380, K: 82, OX: 176, OY: 208 }
};
export function project(n, p) {
  const V = VIEW[n], C = CAMERA;
  if (n === 2) return [V.OX + V.K * p[1], V.OY - V.K * p[0]];
  const up = n === 3 ? p[0] : p[3];
  return [V.OX + V.K * (p[1] * C.x[0] + p[2] * C.y[0]), V.OY - V.K * (p[1] * C.x[1] + p[2] * C.y[1] + up * C.up)];
}
const f1 = x => x.toFixed(1);
export const pathOf = pts => pts.map((q, i) => (i ? 'L' : 'M') + f1(q[0]) + ' ' + f1(q[1])).join(' ');
// a point of the plane of the move: c_i along the first axis of the plane, c_j along the second
const inPlane = (n, m, ci, cj) => { const [i, j] = axesIn(m), p = new Array(n).fill(0); p[i] = ci; p[j] = cj; return p; };
// the axes that a picture draws (from, to, the letter at the end)
const AXIS_ENDS = { 2: [[[0, -2], [0, 2.25], 'x'], [[-2.2, 0], [2.25, 0], 't']], 3: [[[0, -1.7, 0], [0, 2.05, 0], 'x'], [[0, 0, -1.6], [0, 0, 1.85], 'y'], [[-1.65, 0, 0], [1.7, 0, 0], 't']], 4: [[[0, -1.6, 0, 0], [0, 2.0, 0, 0], 'x'], [[0, 0, -1.6, 0], [0, 0, 1.8, 0], 'y'], [[0, 0, 0, -1.55], [0, 0, 0, 1.75], 'z']] };
// the light lines of a boost plane: t = ±(the space axis of the plane), out to R
const LIGHT_R = { 2: 2.2, 3: 1.4 };
// how far the mirror lines reach from the origin
const MIRROR_R = { 2: 2.05, 3: 1.4 };
// the bars of the weights reach ±WMAX
export const WMAX = 1.2;

// the corners of the chooser, in percent of its square
const OCT = { 0: 90, 6: 45, 10: 0, 12: -45, 15: -90, 9: -135, 5: 180, 3: 135 };
export const CHOOSER = {
  2: { 0: [20, 50], 3: [80, 50] },
  3: { 0: [50, 15], 3: [17, 64], 5: [50, 86], 6: [83, 64] },
  4: Object.fromEntries(Object.entries(OCT).map(([m, d]) => [m, [50 + 37 * Math.cos(d * Math.PI / 180), 50 - 37 * Math.sin(d * Math.PI / 180)]]))
};
export const CHOOSER_ASPECT = { 2: 2.4, 3: 1.1, 4: 1 };
export function chooserOf(n, plane) {
  const P = CHOOSER[n], hc = halfCube(n);
  const corners = hc.corners.map(m => {
    const isPlane = popcount(m) === 2, kind = isPlane ? kindOf(n, m) : null;
    return { m, name: letters(m), x: P[m][0], y: P[m][1], isPlane, kind, on: m === plane };
  });
  const edges = hc.edges.map(([a, b]) => ({ a, b, x1: P[a][0], y1: P[a][1], x2: P[b][0], y2: P[b][1], bold: a === 0 || b === 0, on: a === 0 && b === plane }));
  const nb = corners.filter(c => c.kind === 'boost').length, nt = corners.filter(c => c.kind === 'turn').length;
  return { corners, edges, counts: { corners: corners.length, edges: edges.length, boosts: nb, turns: nt } };
}

// ---- the front: everything the picture, the chooser, the weights and the readout show
export function frontView(s) {
  const n = s.n, m = planeOf(s), kind = kindOf(n, m), amt = amountOf(n, m, s), once = s.once, V = VIEW[n], obj = OBJECTS[n];
  const mir = mirrorsOf(n, m, amt), M = moveOf(n, m, amt);
  const imgs = obj.pts.map(p => imageOf(n, m, amt, once, p));
  const P0 = obj.pts.map(p => project(n, p)), P1 = imgs.map(p => project(n, p));
  // the path of every point while the amount runs over its range
  const range = kind === 'turn' ? stepsOf(ANGLE).map(d => d * Math.PI / 180) : stepsOf(SPEED).map(v => v / 100);
  const curves = obj.pts.map(p => pathOf(range.map(x => project(n, imageOf(n, m, x, false, p)))));
  const axes = AXIS_ENDS[n].map(([p, q, name]) => { const a = project(n, p), b = project(n, q); return { x1: a[0], y1: a[1], x2: b[0], y2: b[1], name, lx: b[0], ly: b[1] }; });
  const [i, j] = axesIn(m);
  // light lines and mirror lines, drawn in the plane of the move (2D and 3D)
  const light = n <= 3 && kind === 'boost' ? [1, -1].map(sg => { const R = LIGHT_R[n], a = project(n, inPlane(n, m, -R, -sg * R)), b = project(n, inPlane(n, m, R, sg * R)); return { x1: a[0], y1: a[1], x2: b[0], y2: b[1] }; }) : [];
  const lightLabel = light.length ? (() => { const q = project(n, inPlane(n, m, 0.86 * LIGHT_R[n], -0.86 * LIGHT_R[n])); return { x: q[0] + 10, y: q[1] + 5 }; })() : null;
  let mirrors = [];
  if (n <= 3) {
    const R = MIRROR_R[n], sq = sqOf(n);
    // a line of the plane {i, j} through 0 is the set of points d with d·normal = 0: d = (sq_j n_j, −sq_i n_i), drawn from −R to R
    mirrors = [mir.a, mir.b].map((nv, k) => {
      let di = sq[j] * nv[j], dj = -sq[i] * nv[i]; const L = Math.hypot(di, dj); di /= L; dj /= L;
      if (dj < 0 || (dj === 0 && di < 0)) { di = -di; dj = -dj; }
      const a = project(n, inPlane(n, m, -R * di, -R * dj)), b = project(n, inPlane(n, m, R * di, R * dj));
      return { x1: a[0], y1: a[1], x2: b[0], y2: b[1], name: k ? 'mirror 2' : 'mirror 1', anchor: k ? 'start' : 'end' };
    });
  }
  // the times of the cube's corners (4D): time is not drawn, it is written
  const times = n === 4 ? imgs.map((p, k) => { const q = P1[k], cx = P1.reduce((s2, r) => s2 + r[0], 0) / 8, cy = P1.reduce((s2, r) => s2 + r[1], 0) / 8, dx = q[0] - cx, dy = q[1] - cy, L = Math.hypot(dx, dy) || 1; return { x: q[0] + 22 * dx / L, y: q[1] + 22 * dy / L + 5, text: num(p[0], 2) }; }) : [];
  // drop lines from the moved square down to time 0 (3D), so that its height in time reads
  const drops = n === 3 ? imgs.map((p, k) => { const q = project(n, [0, p[1], p[2]]); return { x1: P1[k][0], y1: P1[k][1], x2: q[0], y2: q[1] }; }).filter(d => Math.abs(d.y1 - d.y2) > 0.5) : [];
  // the weights of the move on the corners of the half-cube
  let rest = 0; for (let c = 0; c < M.length; c++) if (c !== 0 && c !== m) rest += Math.abs(M[c]);
  const weights = [0, m].map(c => ({ m: c, name: letters(c), w: M[c], text: num(M[c], 2), left: 50 + Math.min(0, M[c]) / WMAX * 50, width: Math.abs(M[c]) / WMAX * 50, kind: c ? kind : null }));
  const others = halfCube(n).corners.length - 2;
  // the readout's numbers: the interval of a pair of points before and after, the new times, the amount
  const [p0, p1] = obj.pair, I0 = interval(n, obj.pts[p0], obj.pts[p1]), I1 = interval(n, imgs[p0], imgs[p1]);
  const ts = imgs.map(p => p[0]), tmin = Math.min(...ts), tmax = Math.max(...ts);
  const amtText = kind === 'turn' ? num(s.deg, 0) + '°' : num(s.sv / 100, 2);
  const slider = kind === 'turn'
    ? { name: 'Angle', valueText: amtText, value: s.deg, ...ANGLE, ends: ['−180°', '0°', '180°'], track: track('var(--turn)', 'var(--line2)', 'var(--turn)', 50) }
    : { name: 'Speed', valueText: amtText, value: s.sv, ...SPEED, ends: ['−0.8', '0', '0.8'], track: track('var(--boost)', 'var(--line2)', 'var(--boost)', 50) };
  return {
    n, m, kind, color: colorOf(kind), once, amt, M, rest, mir, imgs, P0, P1, segs: obj.segs, curves, axes, light, lightLabel, mirrors, times, drops, weights, slider,
    vb: '0 0 ' + V.w + ' ' + V.h, chooser: chooserOf(n, m), u: mir.u,
    interval: { pair: obj.pair, before: I0, after: I1 }, tspan: { min: tmin, max: tmax }, amountText: amtText, planeName: letters(m), others
  };
}

// ---- back, the mathematician: the corners of the half-cube of 4D spacetime multiplied
export const BACK_N = 4;
export const START_PICK = { a: 3, b: 5, names: 'bits' };
export const tapCorner = (s, m) => (halfCube(BACK_N).corners.includes(m) ? { ...s, a: s.b, b: m } : s);
export const setNames = (s, names) => ({ ...s, names });
const gcd = (x, y) => (y ? gcd(y, x % y) : x);
// the name of the product from the names of the factors: XOR of the bits or numbers; a·b ÷ gcd(a, b)² of the primes
export function nameLine(a, b, mode) {
  const c = a ^ b;
  if (mode === 'bits') return bitsOf(a, BACK_N) + ' XOR ' + bitsOf(b, BACK_N) + ' = ' + bitsOf(c, BACK_N);
  if (mode === 'numbers') return a + ' XOR ' + b + ' = ' + c;
  const pa = primeName(a), pb = primeName(b), g = gcd(pa, pb);
  return pa + ' × ' + pb + (g > 1 ? ' ÷ ' + g + '²' : '') + ' = ' + combineNames(pa, pb);
}
export function productView(s) {
  const n = BACK_N, sq = sqOf(n), [c, sign] = bladeMul(s.a, s.b, sq), hc = halfCube(n);
  const corners = hc.corners.map(m => ({ m, name: letters(m), label: nameOf(m, s.names, n), kind: popcount(m) === 2 ? kindOf(n, m) : null, first: m === s.a, second: m === s.b, product: m === c,
    x: CHOOSER[n][m][0], y: CHOOSER[n][m][1] }));
  // the edges that join the two factors to the product (a triangle of the half-cube, or two edges through the 4-volume)
  const lit = new Set([[s.a, c], [s.b, c], [s.a, s.b]].filter(([x, y]) => popcount(x ^ y) === 2).map(([x, y]) => Math.min(x, y) + '-' + Math.max(x, y)));
  const edges = hc.edges.map(([x, y]) => ({ a: x, b: y, x1: CHOOSER[n][x][0], y1: CHOOSER[n][x][1], x2: CHOOSER[n][y][0], y2: CHOOSER[n][y][1], lit: lit.has(x + '-' + y) }));
  const odd = (1 << n) - hc.corners.length;
  return {
    a: s.a, b: s.b, c, sign, corners, edges, names: s.names,
    left: [letters(s.a), letters(s.b)], right: letters(c), signText: sign < 0 ? '−' : '',
    nameLine: nameLine(s.a, s.b, s.names), kinds: [cornerKind(n, s.a), cornerKind(n, s.b), cornerKind(n, c)], counts: { even: hc.corners.length, odd }
  };
}

// ---- back, the physicist: a cube of side 1 at rest, seen at one moment by someone passing along x at speed v (c = 1)
export const PASS = { min: 0, max: 90, step: 5 };          // hundredths of the speed of light
export const START_PASS = 60;
// the speeds the V2 picture draws side by side (the passer-by at rest, then three speeds)
export const PASS_SHOW = [0, 30, 60, 90];
const UNIT = Array.from({ length: 8 }, (_, c) => [c & 1, c >> 1 & 1, c >> 2 & 1]);
// the coordinates of the passer-by: the sandwich by the move of speed −v along x (their own place, x′ = 0, moves with +v in the cube's frame)
export function passCoords(v, p) { return sandwich(4, moveOf(4, 3, -v), p); }
// each corner of the cube at the moment t′ = 0 of the passer-by: the event on its world line with t′ = 0 (t′ is linear in t along it), its clock reading t and its place x′
export function passView(sp) {
  const v = sp / 100, gamma = passCoords(v, [1, 0, 0, 0])[0];
  const corners = UNIT.map(([x, y, z]) => {
    const e0 = passCoords(v, [0, x, y, z]), e1 = passCoords(v, [1, x, y, z]), t = -e0[0] / (e1[0] - e0[0]), e = passCoords(v, [t, x, y, z]);
    return { rest: [x, y, z], clock: t, at: [e[1], e[2], e[3]], tp: e[0] };
  });
  const xs = corners.map(c => c.at[0]), clocks = corners.map(c => c.clock), len = Math.max(...xs) - Math.min(...xs), gap = Math.max(...clocks) - Math.min(...clocks);
  // one edge along the motion, its two ends at this moment: the interval in the cube's coordinates and in the passer-by's
  const A = corners[0], B = corners[1], Icube = interval(4, [A.clock, ...A.rest], [B.clock, ...B.rest]), Ipass = interval(4, [A.tp, ...A.at], [B.tp, ...B.at]);
  const vt = num(v, 2);
  return {
    v, gamma, corners, len, gap, Icube, Ipass,
    cells: [['γ', num(gamma, 2)], ['length', num(len, 2)], ['clock gap', num(gap, 2)]],
    // the cube at rest is drawn at its own moment t = 0, when every clock on it reads 0; the passing cube at the moment t′ = 0 of the passer-by
    restClock: num(0, 2), frontClock: num(Math.min(...clocks), 2), rearClock: num(Math.max(...clocks), 2),
    valueText: vt
  };
}
// the picture of the physicist: the cube at rest on the left and the passing cube on the right, x across, y going back, z up
export const PASS_VIEW = { w: 360, h: 240, K: 80, A: 0.42, B: 0.3, left: [30, 190], right: [206, 190] };
export function passProject(origin, p) { return [origin[0] + PASS_VIEW.K * (p[0] + PASS_VIEW.A * p[1]), origin[1] - PASS_VIEW.K * (p[2] + PASS_VIEW.B * p[1])]; }
export const CUBE_EDGES = OBJECTS[4].segs;
