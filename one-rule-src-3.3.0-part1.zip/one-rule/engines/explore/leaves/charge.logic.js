// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/charge.logic.js — loose leaf Charge under leaf 6 (port of Octavo's octavo/leaves/charge.logic.js; plain functions, no React). The field is
// the plane element F of Cl(1,3) written with the table of the cell 1,3 of checks/selfcheck/maxwell.json (CELL13 below); the force on the charge is the grade-1
// part of F u, and F² is E² − B² when E is at right angles to B: every product is engines/labels.js's mul (the kernel's), the reverse the kernel's reorderSign(m, m).
// tests/explore/leaves.charge.test.mjs recomputes every number by standard routes (the textbook Lorentz force, Dirac matrices, closed forms, Lorentz matrices, the
// numeric rows of maxwell.json) and holds them bit-identical to the Octavo output. Units: light speed 1, charge 1, mass 1.
// Front: a charge in E (up the page) and B (out of the page), its path and its speed. Back: the plane of (E, B) and the curve along which observers moving along
// E × B see the field (mathematician); a radius, a drift and a speed from a run each (physicist).
// Not carried over (docs/EXPLORE_PORT.md): COPY, LABELS, MATH_LINES, the words of LEGEND (it keeps the move of each class); the sentences of sayField (say; lead keeps
// its formula), frontView (alt, gaugeAlt), mapView (cap, alt), circleRun, driftRun and limitRun (line, alt); FIELD_LINE keeps the field, not the sentence after it.
import { mul, mvZero } from '../../labels.js';
import { cell, reorderSign, square as bladeSquare } from '../../bitrule.js';
import { num } from '../shared.js';

export const MOVES = ['turn', 'slide', 'boost'];          // by the sign of F²: −1, 0, +1
const EPS = 1e-9;
export const classOf = s => (s < -EPS ? -1 : s > EPS ? 1 : 0);
const sqText = s => (Math.abs(s) < EPS ? '0' : num(s, 2));
const f1 = x => num(x, 1), f2 = x => num(x, 2);

// ---- the table of the cell Cl(1,3) that this leaf reads, as checks/selfcheck/maxwell.json (maxwell_selfcheck.py) stores it in cells["1,3"]: the order and the
// signs of the components (conventions.field_order, conventions.signs) and the blade that carries each field component (incidences: field → source); copied as
// they are, and compared with the stored file by tests/explore/leaves.charge.test.mjs
export const CELL13 = {
  field_order: ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z', 'rho', 'J_x', 'J_y', 'J_z'],
  signs: [1, 1, 1, -1, 1, -1, 1, -1, -1, -1],
  source: { E_x: 3, E_y: 5, E_z: 9, B_x: 12, B_y: 10, B_z: 6 }
};
// ---- the field and the force: the squares of γ0..γ3 (the kernel's), the blade that carries each component, and its sign
export const SQ = [0, 1, 2, 3].map(i => bladeSquare(1 << i, cell(1, 3)));       // [1, −1, −1, −1]: one plus switch (time) and three minus switches
export const CLIFF = 'Cl(' + SQ.filter(x => x > 0).length + ',' + SQ.filter(x => x < 0).length + ')';
export const NAMES = ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z'];
export const BLADE = Object.fromEntries(NAMES.map(n => [n, CELL13.source[n]]));    // E_x -> γ0γ1 (the mask 3), ..., B_z -> γ1γ2 (the mask 6)
export const SIGN = Object.fromEntries(CELL13.field_order.map((n, i) => [n, CELL13.signs[i]]));
export function fieldMV(f6) { const F = mvZero(4); NAMES.forEach((n, i) => { F[BLADE[n]] += SIGN[n] * f6[i]; }); return F; }
export const readField = F => NAMES.map(n => SIGN[n] * F[BLADE[n]]);
// a velocity is written the way the gradient is, with the components (u_t, −u_x, −u_y, −u_z) on γ0..γ3 (maxwell.json, charges.frame)
export function vecMV(u) { const U = mvZero(4); U[1] = u[0]; U[2] = -u[1]; U[4] = -u[2]; U[8] = -u[3]; return U; }
export const readVec = U => [U[1], -U[2], -U[4], -U[8]];
// the force per unit charge and mass: the grade-1 part of F u, read back as (f_t, f_x, f_y, f_z)
export const force = (f6, u) => readVec(mul(fieldMV(f6), vecMV(u), SQ));
// the force is linear in u: column b of this table is the force on the unit velocity along b
export function forceMatrix(f6) {
  const M = [0, 1, 2, 3].map(() => [0, 0, 0, 0]);
  for (let b = 0; b < 4; b++) { const u = [0, 0, 0, 0]; u[b] = 1; force(f6, u).forEach((v, a) => { M[a][b] = v; }); }
  return M;
}
// F² by the same product: its number part (E² − B²), its four-blade part (along γ0γ1γ2γ3, of size 2|E·B|) and whatever else it holds (nothing)
export function square(f6) {
  const F = fieldMV(f6), F2 = mul(F, F, SQ); let rest = 0;
  for (let m = 1; m < 15; m++) rest += Math.abs(F2[m]);
  return { scalar: F2[0], four: F2[15], rest };
}
// the reverse of a multivector: each blade e_m takes the kernel's reordering sign of e_m with itself (grades 2 and 3 change sign)
export const reverse = X => X.map((v, m) => (reorderSign(m, m) < 0 ? -v : v));
// E up the page (along y) and B out of the page (along z): the fields of this leaf are at right angles
export const crossed = (E, B) => [0, E, 0, 0, 0, B];

// ---- the motion: the state [t, x, y, z, u_t, u_x, u_y, u_z], integrated by fourth-order Runge-Kutta with the table of the force
export const LIGHT = 1;                                    // the speed of light
export const gammaOf = v => 1 / Math.sqrt(1 - (v / LIGHT) ** 2);
export const speedOf = s => Math.hypot(s[5], s[6], s[7]) / s[4];
export const startState = (x, y, v, dir) => { const g = gammaOf(v); return [0, x, y, 0, g, g * v * dir[0], g * v * dir[1], 0]; };
const rk4 = (y, h, d) => {
  const k1 = d(y), k2 = d(y.map((v, i) => v + h / 2 * k1[i])), k3 = d(y.map((v, i) => v + h / 2 * k2[i])), k4 = d(y.map((v, i) => v + h * k3[i]));
  return y.map((v, i) => v + h / 6 * (k1[i] + 2 * k2[i] + 2 * k3[i] + k4[i]));
};
// per unit of proper time: dx/dτ = u, du/dτ = M u
export const byTau = M => s => { const u = [s[4], s[5], s[6], s[7]], f = M.map(r => r[0] * u[0] + r[1] * u[1] + r[2] * u[2] + r[3] * u[3]); return [u[0], u[1], u[2], u[3], f[0], f[1], f[2], f[3]]; };
// per unit of time on the page's clock: the same divided by u_t
export const byT = M => { const d = byTau(M); return s => d(s).map(v => v / s[4]); };
export const step = rk4;
// the angle by which the direction of motion turns from state a to state b, clockwise counted as positive (the way a positive charge turns in B out of the page)
export const turnAngle = (a, b) => { let da = Math.atan2(b[6], b[5]) - Math.atan2(a[6], a[5]); while (da > Math.PI) da -= 2 * Math.PI; while (da < -Math.PI) da += 2 * Math.PI; return -da; };

// ---- front: the charge in E and B
export const K_MAX = 20;                                   // tenths of E and of B, from 0 to 2
export const START_AT = [-1, -0.75], V0 = 0.6, DIR0 = [-1, 0];   // the charge starts here, at 0.6 of the speed of light, moving left
export const W = 558, H = 347.2, K0 = 62;                  // the picture: 558 x 347.2 px; at the base zoom 62 px per unit, 9 x 5.6 units with the origin in the middle
export const H_TAU = 0.01, MAX_STEPS = 40000;             // the step in proper time, and the most steps a run takes
export const T_RUN = 120, DT_SHOW = 0.04, RATE = 2.2;      // at the base zoom: the longest run, the time between two samples of the picture, time per second of screen time
export const PRESETS = [{ id: 'b', label: 'B only', kE: 0, kB: 10 }, { id: 'tie', label: 'E = B', kE: 10, kB: 10 }, { id: 'e', label: 'E only', kE: 10, kB: 0 }];
export const presetOf = (kE, kB) => (PRESETS.find(p => p.kE === kE && p.kB === kB) || { id: '' }).id;
export const LEGEND = MOVES.map((name, i) => ({ cls: i - 1, name }));
export const START = { kE: 0, kB: 10, t: 0, out: false, hold: 0 };
const boxOf = v => ({ x0: v.cx - W / 2 / v.k, x1: v.cx + W / 2 / v.k, y0: v.cy - H / 2 / v.k, y1: v.cy + H / 2 / v.k });
// one turn of the charge in the frame that moves with the drift (proper time 2π m/(qB′), B′ = √(B² − E²)); only for a field where B wins
export function loopOf(kE, kB, n = 1200) {
  const E = kE / 10, B = kB / 10, d = byTau(forceMatrix(crossed(E, B))), tau = 2 * Math.PI / Math.sqrt(B * B - E * E), h = tau / n;
  let s = startState(START_AT[0], START_AT[1], V0, DIR0); const states = [s];
  for (let i = 0; i < n; i++) { s = step(s, h, d); states.push(s); }
  return { tau, states };
}
// where the picture looks: the base zoom when one turn (or the whole path) fits, otherwise zoomed out just enough to hold one turn and the start
export function viewOf(kE, kB) {
  const base = { k: K0, cx: 0, cy: 0 };
  if (classOf(square(crossed(kE / 10, kB / 10)).scalar) >= 0) return base;
  const xs = [START_AT[0]], ys = [START_AT[1]];
  for (const s of loopOf(kE, kB, 600).states) { xs.push(s[1]); ys.push(s[2]); }
  const pad = 0.35, x0 = Math.min(...xs) - pad, x1 = Math.max(...xs) + pad, y0 = Math.min(...ys) - pad, y1 = Math.max(...ys) + pad, b = boxOf(base);
  if (x0 >= b.x0 && x1 <= b.x1 && y0 >= b.y0 && y1 <= b.y1) return base;
  return { k: Math.min(K0, W / (x1 - x0), H / (y1 - y0)), cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
}
// the run the picture shows: integrated in proper time until the charge leaves the picture (B alone: exactly one turn, proper time 2π m/(qB), which repeats),
// then sampled [t, x, y, speed] at even steps of time for the animation
export function frontRun(kE, kB) {
  const E = kE / 10, B = kB / 10, cls = classOf(square(crossed(E, B)).scalar), view = viewOf(kE, kB), zoom = K0 / view.k, box = boxOf(view), m = 20 / view.k;
  const d = byTau(forceMatrix(crossed(E, B))), circle = kE === 0 && kB > 0;
  let n = MAX_STEPS, h = H_TAU;
  if (circle) { n = Math.ceil(2 * Math.PI / B / H_TAU); h = 2 * Math.PI / B / n; }
  let s = startState(START_AT[0], START_AT[1], V0, DIR0), left = false, ang = 0, top = speedOf(s), low = top;
  const raw = [[0, s[1], s[2], top]];
  for (let i = 1; i <= n; i++) {
    const s0 = s; s = step(s, h, d); ang += turnAngle(s0, s);
    const v = speedOf(s), out = s[1] < box.x0 - m || s[1] > box.x1 + m || s[2] < box.y0 - m || s[2] > box.y1 + m;
    top = Math.max(top, v); low = Math.min(low, v); raw.push([s[0], s[1], s[2], v]);
    if (out) { left = true; break; }
    if (s[0] > T_RUN * zoom) break;
  }
  const tEnd = raw[raw.length - 1][0], dt = DT_SHOW * zoom, pts = [];
  for (let k = 0, j = 0; k * dt < tEnd; k++) {
    const t = k * dt; while (raw[j + 1][0] < t) j++;
    const a = raw[j], b = raw[j + 1], f = (t - a[0]) / (b[0] - a[0]);
    pts.push([t, a[1] + f * (b[1] - a[1]), a[2] + f * (b[2] - a[2]), a[3] + f * (b[3] - a[3])]);
  }
  pts.push(raw[raw.length - 1]);
  return { kE, kB, E, B, cls, view, zoom, pts, last: s, steps: raw.length - 1, turns: ang / (2 * Math.PI), top, low, dt, tEnd, periodic: circle && !left, left };
}
// page coordinates of a point of the plane
export const toPx = (view, x, y) => [W / 2 + (x - view.cx) * view.k, H / 2 - (y - view.cy) * view.k];
export function pathOf(run) {
  let d = ''; const off = [];
  run.pts.forEach((p, i) => { const [X, Y] = toPx(run.view, p[1], p[2]); d += (i ? 'L' : 'M') + X.toFixed(1) + ' ' + Y.toFixed(1); off.push(d.length); });
  return { d, off };
}
// one step of the animation by dt seconds of screen time: the charge runs along its path; when it leaves the picture it fades, waits, and starts again
export function advance(s, run, dt) {
  if (s.out) { const hold = s.hold + dt; return hold > 1.2 ? { ...s, t: 0, out: false, hold: 0 } : { ...s, hold }; }
  const t = s.t + dt * RATE * run.zoom;
  if (t < run.tEnd) return { ...s, t };
  return run.periodic ? { ...s, t: t - run.tEnd } : { ...s, t: run.tEnd, out: true, hold: 0 };
}
export const setField = (s, kE, kB) => ({ ...s, kE, kB, t: 0, out: false, hold: 0 });
// the speed, never printed as 1: a value that rounds up to 1.00 is shown as 0.99, which it is not below
export const speedText = v => { const r = Math.round(v * 100) / 100; return (r >= LIGHT ? 0.99 : r).toFixed(2); };
// the field as a readout: the class of F² and the formula of its number part
export function sayField(kE, kB) {
  const sq = square(crossed(kE / 10, kB / 10)), cls = classOf(sq.scalar);
  return { cls, lead: 'E² − B² = ' + sqText(sq.scalar) };
}
// the tracks of the two controls, coloured by the move each value gives with the other field held: [left, middle, right, where the tie is in percent]
export const trackE = kB => ['turn', 'slide', 'boost', 100 * kB / K_MAX];
export const trackB = kE => ['boost', 'slide', 'turn', 100 * kE / K_MAX];
// the glyphs of the two fields, on a fixed grid of the picture: rings with a dot for B out of the page, arrows for E up the page; their strength sets how dark they are
export function glyphs(kE, kB) {
  const at = []; for (let i = 0; i < 9; i++) for (let j = 0; j < 5; j++) at.push([31 + 62 * i, 49.6 + 62 * j]);
  return { at, b: kB > 0 ? 0.18 + 0.22 * kB / 10 : 0, e: kE > 0 ? 0.18 + 0.22 * kE / 10 : 0, len: 10 + 7 * kE / 10 };
}
export function frontView(s, run, path) {
  const f = sayField(run.kE, run.kB), P = run.pts, i = Math.min(P.length - 1, Math.max(0, Math.floor(s.t / run.dt)));
  const a = P[i], b = P[Math.min(P.length - 1, i + 1)], fr = b[0] > a[0] ? Math.min(1, Math.max(0, (s.t - a[0]) / (b[0] - a[0]))) : 0;
  const x = a[1] + fr * (b[1] - a[1]), y = a[2] + fr * (b[2] - a[2]), v = a[3] + fr * (b[3] - a[3]), [X, Y] = toPx(run.view, x, y), [SX, SY] = toPx(run.view, START_AT[0], START_AT[1]);
  const E = f1(run.E), B = f1(run.B);
  return {
    ...f, name: MOVES[f.cls + 1], x, y, X, Y, SX, SY, op: s.out ? 0.3 : 1, speed: v, speedText: speedText(v), gauge: 100 * v / LIGHT,
    trail: path.d.slice(0, path.off[i]) + 'L' + X.toFixed(1) + ' ' + Y.toFixed(1),
    zoomText: run.zoom > 1.05 ? 'zoomed out ×' + f1(run.zoom) : '',
    eText: 'E = ' + E, bText: 'B = ' + B
  };
}

// ---- back, the mathematician: the plane of (E, B); the field as observers moving along E × B (the x direction) see it
export const MAP = { S: 360, O: 180, U: 50 };              // a 360 x 360 picture, the origin in the middle, 50 px per unit
export const MAP_START = { kE: 6, kB: 10 };
export const OBSERVERS = [-0.6, -0.3, 0.3, 0.6];          // the speeds of the observers whose view is drawn as dots
// the rotor that takes the velocity of an observer moving at speed w along x to γ0 (R̃ u R = γ0; the test checks it): R = cosh(φ/2) + sinh(φ/2) γ0γ1, tanh φ = w
export function observerRotor(w) { const phi = Math.atanh(w), R = mvZero(4); R[0] = Math.cosh(phi / 2); R[3] = Math.sinh(phi / 2); return R; }
// the field that this observer measures: F′ = R̃ F R
export const seenBy = (f6, w) => { const R = observerRotor(w); return readField(mul(mul(reverse(R), fieldMV(f6), SQ), R, SQ)); };
const mx = e => MAP.O + MAP.U * e, my = b => MAP.O - MAP.U * b;
const inMap = (e, b) => Math.abs(mx(e) - MAP.O) <= MAP.O - 8 && Math.abs(my(b) - MAP.O) <= MAP.O - 8;
const gname = m => [0, 1, 2, 3].filter(i => m >> i & 1).map(i => 'γ' + '₀₁₂₃'[i]).join('');
// the field of this leaf written with the blades and signs of the table: F = E γ₀γ₂ − B γ₁γ₂ in Cl(1,3)
export const FIELD_LINE = 'F = E ' + gname(BLADE.E_y) + (SIGN.B_z < 0 ? ' − ' : ' + ') + 'B ' + gname(BLADE.B_z) + ' in ' + CLIFF;
export const MAP_LABELS = { turn: 'turn', slide: 'slide', boost: 'boost' };
export function mapView(kE, kB) {
  const E = kE / 10, B = kB / 10, f6 = crossed(E, B), sq = square(f6), cls = classOf(sq.scalar);
  const curve = []; for (let j = -120; j <= 120; j++) { const g = seenBy(f6, Math.tanh(j / 40)); curve.push([g[1], g[5]]); }
  const path = curve.map((p, i) => (i ? 'L' : 'M') + mx(p[0]).toFixed(1) + ' ' + my(p[1]).toFixed(1)).join('');
  const dots = OBSERVERS.map(w => { const g = seenBy(f6, w); return { w, e: g[1], b: g[5], x: mx(g[1]), y: my(g[5]), shown: inMap(g[1], g[5]) }; });
  // the observer who sees one part alone: moving at E/B when B wins (no E), at B/E when E wins (no B); none for a tie
  let alone = null;
  if (cls !== 0) { const w = cls < 0 ? E / B : B / E, g = seenBy(f6, w); alone = { w, e: g[1], b: g[5], x: mx(g[1]), y: my(g[5]), part: cls < 0 ? 'B' : 'E' }; }
  const EB = Math.abs(sq.four) / 2;
  return {
    E, B, cls, name: MOVES[cls + 1], x: mx(E), y: my(B), path, dots, alone, EB, eText: 'E = ' + f1(E), bText: 'B = ' + f1(B),
    line: 'E = ' + f1(E) + ', B = ' + f1(B) + ' · E² − B² = ' + sqText(sq.scalar) + ' · E·B = ' + sqText(EB)
  };
}

// ---- back, the physicist: three runs, each with the number its formula gives
// (1) B alone, a start at speed v: the radius from the run (half the largest distance from the start over one turn) and from γ m v/(qB); dashed, Newton's m v/(qB)
export const CIRCLE_B = 1, KV = [6, 19], KV_START = 16;   // twentieths of v, from 0.30 to 0.95
export function circleRun(kv, n = 2000) {
  const v = kv / 20, d = byTau(forceMatrix(crossed(0, CIRCLE_B))), tau = 2 * Math.PI / CIRCLE_B, h = tau / n;
  let s = startState(0, 0, v, [1, 0]), far = 0; const pts = [[0, 0]], states = [s];
  for (let i = 1; i <= n; i++) { s = step(s, h, d); states.push(s); far = Math.max(far, Math.hypot(s[1], s[2])); if (i % 20 === 0) pts.push([s[1], s[2]]); }
  const measured = far / 2, formula = gammaOf(v) * v / CIRCLE_B, newton = v / CIRCLE_B, k = 46 / measured;
  return {
    v, measured, formula, newton, states, back: Math.hypot(s[1], s[2]),
    path: pts.map((p, i) => (i ? 'L' : 'M') + (75 + k * p[0]).toFixed(1) + ' ' + (14 - k * p[1]).toFixed(1)).join('') + 'Z',
    start: [75, 14], nr: k * newton, nc: [75, 14 + k * newton],
    title: 'Circle, B only', vText: 'v = ' + f2(v)
  };
}
// (2) B = 1 and E = r B, from rest: where B wins, the average speed over one turn of the drift frame (proper time 2π m/(qB′)) from the run, and E/B
export const KR_MAX = 30, KR_START = 12;                   // twentieths of E/B, from 0 to 1.5
export const trackR = ['turn', 'slide', 'boost', 100 * 20 / KR_MAX];   // the track of that control: the tie E = B sits at two thirds
export function driftRun(kr, n = 1500) {
  const r = kr / 20, B = 1, E = r * B, f6 = crossed(E, B), cls = classOf(square(f6).scalar), M = forceMatrix(f6);
  let s = startState(0, 0, 0, [1, 0]); const states = [s], pts = [[0, 0]];
  let measured = null, tau = null;
  if (cls < 0) {
    tau = 2 * Math.PI / Math.sqrt(B * B - E * E); const d = byTau(M), h = tau / n;
    for (let i = 1; i <= 2 * n; i++) { s = step(s, h, d); states.push(s); if (i === n) measured = s[1] / s[0]; if (i % 10 === 0) pts.push([s[1], s[2]]); }
  } else {
    const d = byT(M), h = 0.01;
    for (let i = 1; i <= 1200; i++) { s = step(s, h, d); states.push(s); if (i % 10 === 0) pts.push([s[1], s[2]]); }
  }
  const xs = pts.map(p => p[0]), ys = pts.map(p => p[1]), x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
  const k = Math.min(126 / Math.max(x1 - x0, 1e-6), 96 / Math.max(y1 - y0, 1e-6), 60), ox = 75 - k * (x0 + x1) / 2, oy = 60 + k * (y0 + y1) / 2;
  return {
    r, E, B, cls, name: MOVES[cls + 1], tau, measured, formula: E / B, states, top: Math.max(...states.map(speedOf)),
    path: pts.map((p, i) => (i ? 'L' : 'M') + (ox + k * p[0]).toFixed(1) + ' ' + (oy - k * p[1]).toFixed(1)).join(''), start: [ox, oy],
    title: 'Drift, from rest', rText: f2(r)
  };
}
// (3) E alone, from rest: the speed from the run against tanh(qEτ/m) at proper time 3, and what Newton's rule would give, qEt/m
export const LIMIT = { E: 1, tau: 3 };
export function limitRun(n = 3000) {
  const d = byTau(forceMatrix(crossed(LIMIT.E, 0))), h = LIMIT.tau / n;
  let s = startState(0, 0, 0, [0, 1]); const states = [s], curve = [[0, 0]];
  for (let i = 1; i <= n; i++) { s = step(s, h, d); states.push(s); if (i % 30 === 0) curve.push([s[0], speedOf(s)]); }
  const t = s[0], measured = speedOf(s), formula = Math.tanh(LIMIT.E * LIMIT.tau), newton = LIMIT.E * t;
  const X = tt => 14 + 128 * tt / t, Y = v => 104 - 76 * v;
  return {
    t, measured, formula, newton, states,
    path: curve.map((p, i) => (i ? 'L' : 'M') + X(p[0]).toFixed(1) + ' ' + Y(p[1]).toFixed(1)).join(''),
    light: [X(0), Y(1), X(t), Y(1)], newtonLine: [X(0), Y(0), X(1.25 / LIMIT.E), Y(1.25)], axis: [X(0), Y(0), X(t), Y(0)],
    title: 'Speed limit, E only'
  };
}
