// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/bands.logic.js — loose leaf "Bands" under leaf 2, three moves (port of Octavo's octavo/leaves/bands.logic.js; plain functions, no React).
// A wave ψ″ = (V − E)ψ runs along a row of repeated cells, each a low piece and a raised piece (the cell G5_CELL of engines/schullerEngine.js, its height free).
// A piece moves the pair (ψ, ψ′) by a 2 × 2 matrix of determinant 1 (schullerEngine pieceMatrix); read in Cl(2,0) with toMv, one period M = ½ tr M + X is the
// product of its pieces by the kernel (mvMul2: the mul of engines/labels.js), X² is the kernel's square (xSquare), and one sign decides: X² < 0, the period
// turns (a band); X² > 0, it boosts (a gap); X² = 0 with X ≠ 0, it slides (an edge). The band edges of the strip are found numerically (bandEdges on ½ tr M).
// Only one period is computed: nothing here says anything about the whole row beyond what one period gives.
// tests/explore/leaves.bands.test.mjs recomputes every number by standard routes (the Kronig–Penney closed form, RK4 integration of the equation, explicit
// 2 × 2 matrices and the eigenvalues of M, a finer scan with bisection) and holds the outputs bit-identical to the Octavo module (stored/bands_octavo.json).
// Not carried over (docs/EXPLORE_PORT.md §3, D28): COPY; the sentences STATUS and SAYS (frontView status, alt), the line and alt of mapView and physView,
// MAP_NOTE, the line of twoTurns, the caption physCap (its facts are data: physFacts); trackOf (the track of Octavo's slider: V2 has no slider, D24).
// Added for the V2 picture, whose controls are steppers and picks: the stops of the energy (stopsOf: halves of a unit, each band edge, the middle of a
// stretch that holds no half), stepEnergy, pickStretch, setHeight, view; the moves of the three pieces in mapView (pieces) and its readout.
import { bandEdges, floquetClass, G5_CELL, halfTraceSteps, mvMul2, pieceMatrix, toMv, xSquare } from '../../schullerEngine.js';
import { trinityClass } from '../../labels.js';
import { num, sub } from '../shared.js';

// ---- the cell and the ranges of the controls
export const MOVES = ['turn', 'slide', 'boost'];                // by class −1, 0, +1 (the sign of a square), as in moves.logic.js
const [[L_LOW, V_LOW], [L_HIGH, H_CELL]] = G5_CELL;            // a low piece 0.8 long at height 0, then a raised piece 0.5 long at height 5
export { L_LOW, V_LOW, L_HIGH, H_CELL };
export const PERIOD = L_LOW + L_HIGH;
export const E_MAX = 30, H_MAX = 8;                             // the energy strip runs from 0 to 30, the height of the step from 0 to 8
export const E_TENTHS = 10 * E_MAX, H_TENTHS = 10 * H_MAX;      // Octavo's sliders counted tenths
export const SNAP = 0.05;                                       // an energy within SNAP of a band edge stands for the edge itself
export const SCAN = 6000;                                       // bandEdges scans the strip in steps of 0.005, then bisects
export const ROW = 8, ROW_PHYS = 4;                             // repeats drawn on the front and in the physicist's band diagram
export const START = { v: 30, hv: 10 * H_CELL };                // Octavo's start: energy 3.0, the step of the cell
export const START_BACK = { math: 30, phys: 75 };               // Octavo's backs: the mathematician in a band, the physicist in a gap
export const SPEED = 2.4;                                       // radians of the wave's clock per second of the page
// one period cut at the middle of a low piece: the row of G5_CELL started 0.4 further on, so that M has equal diagonal entries and X = b e2 + c e12 has no e1 part
export const cellOf = h => [[L_LOW / 2, V_LOW], [L_HIGH, h], [L_LOW / 2, V_LOW]];
const piece = (E, l, V) => pieceMatrix(E, l, V);
const act = (P, s) => [[P[0][0] * s[0][0] + P[0][1] * s[1][0], P[0][0] * s[0][1] + P[0][1] * s[1][1]], [P[1][0] * s[0][0] + P[1][1] * s[1][0], P[1][0] * s[0][1] + P[1][1] * s[1][1]]];

// ---- one period
// the multivector g + x1 e1 + x2 e2 + x12 e12 of Cl(2,0) as the matrix [[g + x1, x2 + x12], [x2 − x12, g − x1]] (the inverse of toMv)
export const fromMv = X => [[X[0] + X[1], X[2] + X[3]], [X[2] - X[3], X[0] - X[1]]];
// the period as a multivector: each piece read with toMv, multiplied by the kernel's product in Cl(2,0) (a later piece multiplies from the left)
export function periodMv(E, h) { let P = null; for (const [l, V] of cellOf(h)) { const Q = toMv(piece(E, l, V)); P = P ? mvMul2(Q, P) : Q; } return P; }
// the verdict: floquetClass marks an edge (|½ tr M| = 1 within its tolerance; X = 0 there means M = ±1, where every wave passes); elsewhere the sign of X² decides
export function verdict(g, xs) { if (floquetClass(g) === 'edge') return xs.Xnorm < 1e-9 ? 'band' : 'edge'; return xs.s < 0 ? 'band' : 'gap'; }
export const MOVE_OF = { band: MOVES[0], edge: MOVES[1], gap: MOVES[2] };      // turn, slide, boost
export const COLOR_OF = { band: 'var(--turn)', edge: 'var(--slide)', gap: 'var(--boost)' };
export function period(E, h) {
  const mv = periodMv(E, h), g = mv[0], xs = xSquare(mv), cls = verdict(g, xs);
  return { E, h, mv, g, X2: xs.s, Xnorm: xs.Xnorm, b: mv[2], c: mv[3], M: fromMv(mv), cls, move: MOVE_OF[cls] };
}

// ---- the band edges and the stretches of the strip
// the band edges in the strip: bandEdges finds where |½ tr M| crosses 1; the end E = 0 is an edge too when the period there is one (with no step).
// The edges of a height are kept once found (the same numbers every time; each caller gets its own copy)
const EDGES = new Map();
function edgesFound(h) { const ed = bandEdges(E => halfTraceSteps(E, cellOf(h)), 0, E_MAX, SCAN); return period(0, h).cls === 'edge' ? [0, ...ed] : ed; }
export function edgesOf(h) { if (!EDGES.has(h)) EDGES.set(h, edgesFound(h)); return EDGES.get(h).slice(); }
export function stretchesOf(h, edges = edgesOf(h)) {
  const cuts = [...new Set([0, ...edges, E_MAX])], out = [];
  for (let i = 0; i + 1 < cuts.length; i++) { const lo = cuts[i], hi = cuts[i + 1]; out.push({ lo, hi, cls: period((lo + hi) / 2, h).cls === 'band' ? 'band' : 'gap' }); }
  return out;
}
// the energy a position of Octavo's slider stood for: tenths, or the band edge within SNAP of it
export function energyAt(v, edges) {
  const E = v / 10; let best = null;
  for (const e of edges) if (Math.abs(e - E) < SNAP && (best === null || Math.abs(e - E) < Math.abs(best - E))) best = e;
  return best === null ? { E, snapped: false } : { E: best, snapped: true };
}
export const eText = (E, snapped) => num(E, snapped ? 2 : 1);
// a number of a readout: two decimals, or two significant digits where two decimals would hide a small number that is not 0 (inside a narrow gap X² is
// small and positive); below 1e−6 it prints 0.00 (at an edge X² vanishes up to rounding)
export const fx = x => (Math.abs(x) >= 1e-6 && Math.abs(x) < 0.005 ? (x < 0 ? '−' : '') + Math.abs(x).toPrecision(2) : num(x, 2));
const pct = E => 100 * E / E_MAX;
export const TICKS = Array.from({ length: E_MAX / 5 + 1 }, (_, i) => 5 * i);
// the strip under the picture: bands and gaps as stretches (percent of the strip), the edges as ticks
export function stripView(h, edges) {
  return {
    stretches: stretchesOf(h, edges).map(s => ({ ...s, left: pct(s.lo), width: pct(s.hi) - pct(s.lo), color: COLOR_OF[s.cls] })),
    edges: edges.map(e => ({ e, left: pct(e) })), ticks: TICKS.map(t => ({ t, left: pct(t) }))
  };
}

// ---- the wave along the row
// the solution that matters at energy E, sampled along n repeats (x in units of length) as real and imaginary parts, with the envelope |ψ|, the largest |ψ| set to 1:
//   band  the solution with ψ(x + period) = e^(iθ) ψ(x) whose current Im(ψ̄ ψ′) is positive: it travels to the right, and |ψ| repeats with the row
//   gap   the decaying solution, the eigenvector of M with |λ| < 1: ψ(x + period) = λ ψ(x)
//   edge  the eigenvector of M for its double eigenvalue ±1: it repeats, or repeats with its sign changed
export function waveOf(E, h, n = ROW, per = 40) {
  const p = period(E, h), [[a, b], [c, d]] = p.M, g = p.g;
  let v, lam;                                                    // v = [[Re ψ, Im ψ], [Re ψ′, Im ψ′]] at the start of the row; lam = [Re λ, Im λ]
  if (p.cls === 'band') { const w = Math.sqrt(Math.max(0, 1 - g * g)), sg = b > 0 ? 1 : -1; lam = [g, sg * w]; v = [[b, 0], [g - a, sg * w]]; }
  else {
    const s = p.cls === 'edge' ? Math.sign(g) : g - Math.sign(g) * Math.sqrt(g * g - 1);
    const u1 = [b, s - a], u2 = [s - d, c], u = Math.abs(u1[0]) + Math.abs(u1[1]) >= Math.abs(u2[0]) + Math.abs(u2[1]) ? u1 : u2;
    lam = [s, 0]; v = [[u[0], 0], [u[1], 0]];
  }
  // one period, piece by piece (a piece of length l sampled at l j / m)
  const one = [[0, v[0][0], v[0][1]]]; let st = v, x0 = 0;
  for (const [l, V] of cellOf(h)) {
    const m = Math.max(2, Math.round(per * l / PERIOD));
    for (let j = 1; j <= m; j++) { const s = act(piece(E, l * j / m, V), st); one.push([x0 + l * j / m, s[0][0], s[0][1]]); }
    st = act(piece(E, l, V), st); x0 += l;
  }
  // the row: repeat k is the first period times λ^k
  const xs = [], re = [], im = []; let lk = [1, 0];
  for (let k = 0; k < n; k++) {
    for (let i = k ? 1 : 0; i < one.length; i++) { const [x, r, q] = one[i]; xs.push(k * PERIOD + x); re.push(lk[0] * r - lk[1] * q); im.push(lk[0] * q + lk[1] * r); }
    lk = [lk[0] * lam[0] - lk[1] * lam[1], lk[0] * lam[1] + lk[1] * lam[0]];
  }
  const env0 = re.map((r, i) => Math.hypot(r, im[i])), top = Math.max(...env0) || 1;
  return { cls: p.cls, g, lam, v, end: st, xs, re: re.map(r => r / top), im: im.map(q => q / top), env: env0.map(e => e / top), keep: Math.hypot(lam[0], lam[1]), n };
}
// the wave at the phase φ of its clock: Re(ψ e^(−iφ)); the curve and its envelope as SVG paths (x0, unit: where x = 0 sits and how many units a length takes; y0, amp: the midline and the height of 1)
export const waveY = (w, i, phi) => w.re[i] * Math.cos(phi) + w.im[i] * Math.sin(phi);
export function wavePath(w, phi, x0, unit, y0, amp) { let d = ''; for (let i = 0; i < w.xs.length; i++) d += (i ? 'L' : 'M') + (x0 + unit * w.xs[i]).toFixed(1) + ' ' + (y0 - amp * waveY(w, i, phi)).toFixed(1); return d; }
export function envPath(w, x0, unit, y0, amp) {
  let d = ''; for (let i = 0; i < w.xs.length; i++) d += (i ? 'L' : 'M') + (x0 + unit * w.xs[i]).toFixed(1) + ' ' + (y0 - amp * w.env[i]).toFixed(1);
  for (let i = w.xs.length - 1; i >= 0; i--) d += 'L' + (x0 + unit * w.xs[i]).toFixed(1) + ' ' + (y0 + amp * w.env[i]).toFixed(1);
  return d + 'Z';
}
// the raised pieces of n repeats, as rectangles from the ground y0 up by unit per unit of height
export function stepRects(h, n, x0, unit, y0, hunit) {
  const out = []; for (let k = 0; k < n; k++) { const x = x0 + unit * (k * PERIOD + L_LOW / 2); out.push({ x, w: unit * L_HIGH, y: y0 - hunit * h, hh: hunit * h }); } return out;
}

// ---- front
export const FRONT = { w: 640, h: 236, x0: 20, mid: 74, amp: 54, ground: 218, hunit: 7 };
FRONT.unit = (FRONT.w - 2 * FRONT.x0) / (ROW * PERIOD);
export const CHIPS = [{ cls: 'band', label: 'passes', sub: 'band' }, { cls: 'edge', label: 'edge', sub: '' }, { cls: 'gap', label: 'fades', sub: 'gap' }];
export function frontView(E, snapped, h, edges) {
  const p = period(E, h), F = FRONT;
  return { ...p, color: COLOR_OF[p.cls], eText: eText(E, snapped), hText: num(h, 1), rects: stepRects(h, ROW, F.x0, F.unit, F.ground, F.hunit), strip: stripView(h, edges) };
}

// ---- back, the mathematician: the map of moves of leaf 2 (the plane of b e2 + c e12), the period as its point
// the map squeezes lengths toward the middle (radius r is drawn at R r / (r + 1)); a squeeze along the rays keeps every point in its wedge
export const MAP = { w: 360, h: 340, cx: 180, cy: 170, R: 150 };
export function squash(b, c) { const r = Math.hypot(b, c), s = MAP.R / (r + 1); return { x: MAP.cx + s * b, y: MAP.cy - s * c }; }
export const TRAIL_STEP = 0.02;
// the path of the point as the energy runs from 0 to E_MAX, cut where the class changes (each part drawn in the colour of its move)
export function trail(h = H_CELL) {
  const parts = []; let cur = null;
  for (let i = 0; i <= Math.round(E_MAX / TRAIL_STEP); i++) {
    const E = i * TRAIL_STEP, p = period(E, h), q = squash(p.b, p.c), cls = p.cls === 'edge' ? (cur ? cur.cls : 'gap') : p.cls;
    if (!cur || cur.cls !== cls) { cur = { cls, color: COLOR_OF[cls], pts: cur ? [cur.pts[cur.pts.length - 1]] : [], lo: E }; parts.push(cur); }
    cur.pts.push([q.x, q.y, E]);
  }
  return parts.map(t => ({ ...t, d: t.pts.map((q, i) => (i ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join(' ') }));
}
// the travelled part of the trail: the points with energy up to E
export const travelled = (parts, E) => parts.map(t => ({ ...t, d: t.pts.filter(q => q[2] <= E + 1e-9).map((q, i) => (i ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1)).join(' ') })).filter(t => t.d);
// the three pieces of one period at energy E, each read with toMv and squared by the kernel: its own move (a piece above its height turns, below it boosts)
export function piecesOf(E, h) {
  return cellOf(h).map(([l, V]) => { const X2 = xSquare(toMv(piece(E, l, V))).s, k = trinityClass(X2); return { l, V, X2, cls: k, move: MOVES[k + 1] }; });
}
export function mapView(E, snapped, edges, h = H_CELL) {
  const p = period(E, h), pt = squash(p.b, p.c), t = eText(E, snapped);
  return {
    ...p, pt, color: COLOR_OF[p.cls], eText: t, dots: edges.map(e => { const q = period(e, h); return squash(q.b, q.c); }),
    readout: 'E = ' + t + ' · ½ tr M = ' + fx(p.g) + ' · X² = ' + fx(p.X2), pieces: piecesOf(E, h)
  };
}
// the formulas: the lengths and the height of the cell, from G5_CELL
export const FORMULA = { half: String(L_LOW / 2), high: String(L_HIGH), hsub: sub(H_CELL), vsub: sub(V_LOW) };
// above the step both pieces turn, yet a gap lies there: the first gap whose lower edge is above the height (null when there is none)
export function twoTurns(h = H_CELL, edges = edgesOf(h)) {
  const g = stretchesOf(h, edges).find(s => s.cls === 'gap' && s.lo > h);
  return g ? { lo: g.lo, hi: g.hi } : null;
}

// ---- back, the physicist: energy upright over a row of layers; allowed stretches shaded, the chosen energy a line with its wave on it
export const BAND = { w: 360, h: 340, ax: 50, x0: 58, x1: 348, y0: 318, y1: 22, amp: 22 };
BAND.unit = (BAND.x1 - BAND.x0) / (ROW_PHYS * PERIOD);
export const yOfE = E => BAND.y0 - (BAND.y0 - BAND.y1) * E / E_MAX;
export function physView(E, snapped, edges, h = H_CELL) {
  const p = period(E, h), w = waveOf(E, h, ROW_PHYS), keep = Math.round(100 * w.keep);
  const allowed = stretchesOf(h, edges).filter(s => s.cls === 'band');
  return {
    ...p, w, keep, color: COLOR_OF[p.cls], eText: eText(E, snapped), y: yOfE(E),
    bands: allowed.map(s => ({ ...s, y: yOfE(s.hi), hh: yOfE(s.lo) - yOfE(s.hi) })), edgeYs: edges.map(yOfE),
    rects: stepRects(h, ROW_PHYS, BAND.x0, BAND.unit, BAND.y0, (BAND.y0 - BAND.y1) / E_MAX), ticks: TICKS.map(t => ({ t, y: yOfE(t) }))
  };
}
// what Octavo's caption said, as data: some allowed energies lie below the top of the raised pieces, and some forbidden ones above it
export function physFacts(h = H_CELL, edges = edgesOf(h)) {
  const st = stretchesOf(h, edges);
  return { below: st.some(s => s.cls === 'band' && s.lo < h), above: st.some(s => s.cls === 'gap' && s.lo > h) };
}

// ---- the controls of the V2 picture (D24: steppers and picks, never a slider)
// the height of the step by whole numbers 0 … 8; the energy by halves of a unit with a stop at each band edge (a half within SNAP of an edge gives way to
// it) and at the middle of a stretch that holds no half, so that every band, every gap and every edge of the strip can be reached
export const H_STEPS = Array.from({ length: H_MAX + 1 }, (_, i) => i);
export const E_STEP = 0.5;
export const START2 = { E: 5.5, h: H_CELL };                    // in the first band of the Atlas's cell, two stops below its upper edge
const insideOf = (st, E) => st.findIndex(s => E > s.lo && E < s.hi);
export function stopsOf(h, edges = edgesOf(h)) {
  const st = stretchesOf(h, edges), pts = [];
  for (let i = 0; i <= Math.round(E_MAX / E_STEP); i++) { const E = i * E_STEP; if (!edges.some(e => Math.abs(e - E) < SNAP)) pts.push({ E, kind: 'half' }); }
  for (const e of edges) pts.push({ E: e, kind: 'edge' });
  for (const s of st) if (!pts.some(q => q.kind === 'half' && q.E > s.lo && q.E < s.hi)) pts.push({ E: (s.lo + s.hi) / 2, kind: 'middle' });
  pts.sort((a, b) => a.E - b.E);
  // the stretch a stop lies in: inside it, or at an end of the strip; an edge lies between two stretches (null)
  return pts.map((q, i) => ({ ...q, i, stretch: q.kind === 'edge' ? null : q.E <= 0 ? 0 : q.E >= E_MAX ? st.length - 1 : insideOf(st, q.E) }));
}
// the stop of a list nearest to E (the lower of two at the same distance)
export function nearestStop(stops, E) { let best = stops[0]; for (const q of stops) if (Math.abs(q.E - E) < Math.abs(best.E - E)) best = q; return best; }
export const isStop = (stops, E) => stops.some(q => q.E === E);
// the start of the picture from its params: a height of H_STEPS, an energy (to the nearest stop), or a stretch to stand in
export function startOf(params = {}) {
  const h = H_STEPS.includes(params.h) ? params.h : START2.h;
  let s = { E: nearestStop(stopsOf(h), Number.isFinite(params.E) ? params.E : START2.E).E, h };
  if (Number.isInteger(params.stretch)) s = pickStretch(s, params.stretch);
  return s;
}
// the stepper of the energy: the next stop up (dir = 1) or down (dir = −1), staying in the strip
export function stepEnergy(s, dir) {
  const stops = stopsOf(s.h), i = nearestStop(stops, s.E).i, j = Math.max(0, Math.min(stops.length - 1, i + Math.sign(dir)));
  return { ...s, E: stops[j].E };
}
// a tap on stretch k of the strip: the energy goes to the stop inside it nearest its middle
export function pickStretch(s, k) {
  const edges = edgesOf(s.h), st = stretchesOf(s.h, edges)[k];
  if (!st) return s;
  const mid = (st.lo + st.hi) / 2, inside = stopsOf(s.h, edges).filter(q => q.kind !== 'edge' && q.E > st.lo && q.E < st.hi);
  return inside.length ? { ...s, E: nearestStop(inside, mid).E } : s;
}
// the stepper of the height: an energy at an edge stays at the same edge of the new height (the k-th edge), one in the middle of a stretch stays in the
// middle of that stretch; a half stays where it is when it is still a stop; anything else goes to the nearest stop
export function setHeight(s, h) {
  if (!H_STEPS.includes(h)) return s;
  const old = stopsOf(s.h), at = nearestStop(old, s.E), now = stopsOf(h);
  if (at.kind === 'edge') { const k = old.filter(q => q.kind === 'edge').indexOf(at), ed = now.filter(q => q.kind === 'edge'); if (k < ed.length) return { E: ed[k].E, h }; }
  if (at.kind === 'middle' && at.stretch !== null && at.stretch < stretchesOf(h).length) return pickStretch({ E: s.E, h }, at.stretch);
  return { E: nearestStop(now, s.E).E, h };
}
// everything the front draws for a state { E, h }: the period and its verdict, the steps and the strip, the stop and what the steppers can still do
export function view(s) {
  const edges = edgesOf(s.h), stops = stopsOf(s.h, edges), at = nearestStop(stops, s.E), fine = at.kind !== 'half';
  return { ...frontView(at.E, fine, s.h, edges), fine, stop: at, stops: stops.length, canDown: at.i > 0, canUp: at.i < stops.length - 1, canLower: s.h > H_STEPS[0], canRaise: s.h < H_STEPS[H_STEPS.length - 1] };
}
