// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/leaves/field.logic.js — loose leaf "Field" under leaf 6 (port of Octavo's octavo/leaves/field.logic.js; plain functions, no React). The field of
// electricity and magnetism is one plane element F of Cl(1,3), the algebra of the four switches t, x, y, z (t squares to +1, x, y, z to −1: the kernel's cell 1,3,
// the axes of engines/labels.js maxwellViews(1, 3)), written with the table of the cell 1,3 of checks/selfcheck/maxwell.json (CELL13 below, the convention of the
// Atlas's Maxwell page): F = Ex e_tx + Ey e_ty + Ez e_tz − Bx e_yz + By e_xz − Bz e_xy. The four switches are the corners of a tetrahedron and the six planes its
// edges; the square of each plane (the kernel's bladeMul) sorts it: the three edges at t carry E and square to +1, the three round the base carry B and square
// to −1. An observer moving at speed v along x sees R F R̃, R the rotor of rapidity atanh v in the plane t x; every product is engines/labels.js's mul (the
// kernel's), the reverse the kernel's reorderSign(m, m). tests/explore/leaves.field.test.mjs recomputes every number by standard routes (the textbook law of
// E and B for a moving observer, explicit Lorentz matrices on the field tensor, explicit Dirac matrices, the drift frame of crossed fields, direct counts of
// the incidences of maxwell.json) and holds them bit-identical to the Octavo output.
// Front: the tetrahedron, each edge as thick as its part and numbered, three fields and the observer's speed, the two numbers of F². Back: the steps of
// ∇F = J from each edge to two corners and two triangles, on the tetrahedron drawn flat (mathematician); the arrows of E and B across the motion before and
// after the boost (physicist).
// Not carried over (docs/EXPLORE_PORT.md §3): COPY and WORDS (the words of the faces); the sentences of frontView (status, alt; moving is the state the status
// told), mathView (headTail, count, alt; counts holds the numbers of count) and physView (along, invLine, alt; alongText and invText keep their formulas).
import { bladeMul, maxwellViews, mul, popcount, sigVec } from '../../labels.js';
import { reorderSign } from '../../bitrule.js';

// ---- the table of the cell 1,3 that this leaf reads, as checks/selfcheck/maxwell.json (maxwell_selfcheck.py) stores it in cells["1,3"]: the order and the signs of
// the components (conventions.field_order, conventions.signs), the blade that carries each field component (incidences: field → source) and the names of the
// eight equations by their target blade (equations: target → name); copied as they are, and compared with the stored file by tests/explore/leaves.field.test.mjs
export const CELL13 = {
  field_order: ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z', 'rho', 'J_x', 'J_y', 'J_z'],
  signs: [1, 1, 1, -1, 1, -1, 1, -1, -1, -1],
  source: { E_x: 3, E_y: 5, E_z: 9, B_x: 12, B_y: 10, B_z: 6 },
  equations: { 1: 'Gauss', 2: 'Ampère x', 4: 'Ampère y', 7: 'Faraday z', 8: 'Ampère z', 11: 'Faraday y', 13: 'Faraday x', 14: 'no monopole' }
};

// ---- the algebra, the corners and the edges (the kernel's cell 1,3 and the table above)
const CELL = maxwellViews(1, 3);
export const SQ = sigVec(CELL.k, CELL.d);                                       // the squares of t, x, y, z: +1, −1, −1, −1
export const AXES = CELL.axes;                                                  // ['t', 'x', 'y', 'z']
export const FIELDS = ['E_x', 'E_y', 'E_z', 'B_x', 'B_y', 'B_z'];
const ORDER = CELL13.field_order, SIGNS = CELL13.signs;
const bitsOf = m => [0, 1, 2, 3].filter(a => m >> a & 1);
export const lettersOf = m => bitsOf(m).map(a => AXES[a]).join('');
export const spaced = m => lettersOf(m).split('').join(' ');
export const TOP = (1 << 4) - 1;                                                // the blade e_txyz
// the six edges: the plane that carries one part of F, the sign of that part in F, the two corners it joins, its square (+1 boost, −1 turn)
export const EDGES = FIELDS.map(f => {
  const mask = CELL13.source[f], sq = bladeMul(mask, mask, SQ)[1];
  return { id: f, kind: f[0], comp: f[2], mask, sign: SIGNS[ORDER.indexOf(f)], ends: bitsOf(mask), letters: lettersOf(mask), sq, move: sq > 0 ? 'boost' : 'turn' };
});
export const toF = (E, B) => { const F = new Float64Array(16); EDGES.forEach((e, i) => { F[e.mask] += e.sign * (i < 3 ? E[i] : B[i - 3]); }); return F; };
export const partsOf = F => EDGES.map(e => e.sign * F[e.mask]);                // [Ex, Ey, Ez, Bx, By, Bz]
// the reverse of a multivector: each blade e_m takes the kernel's reordering sign of e_m with itself (grades 2 and 3 change sign)
export const reverse = M => M.map((c, m) => (reorderSign(m, m) < 0 ? -c : c));

// ---- the moving observer: the boost of rapidity η = atanh v in the plane t x; an observer at +v along x sees R F R̃ with R = cosh(η/2) − sinh(η/2) e_tx
// (in the components above; tests/explore/leaves.field.test.mjs ties the sign to the textbook law, to Lorentz matrices and to a charge drifting at E/B through
// crossed fields, which feels no force)
export const R_SIGN = -1;
const TX = (1 << AXES.indexOf('t')) | (1 << AXES.indexOf('x'));
export function rotor(v) { const eta = Math.atanh(v), R = new Float64Array(16); R[0] = Math.cosh(eta / 2); R[TX] = R_SIGN * Math.sinh(eta / 2); return R; }
export const boost = (F, v) => { const R = rotor(v); return mul(mul(R, F, SQ), reverse(R), SQ); };
// the strength of each kind from the square of its part (the electric part squares to +E², the magnetic part to −B²), and the two numbers of F² = (E² − B²) − 2 (E·B) e_txyz
const partOf = (F, kind) => { const P = new Float64Array(16); EDGES.forEach(e => { if (e.kind === kind) P[e.mask] = F[e.mask]; }); return P; };
export function strengths(F) { const e2 = mul(partOf(F, 'E'), partOf(F, 'E'), SQ)[0], b2 = -mul(partOf(F, 'B'), partOf(F, 'B'), SQ)[0]; return { e: Math.sqrt(Math.max(0, e2)), b: Math.sqrt(Math.max(0, b2)), e2, b2 }; }
export function invariants(F) { const F2 = mul(F, F, SQ); return { s: F2[0], p: -F2[TOP] / 2, F2 }; }
export const gammaOf = v => 1 / Math.sqrt(1 - v * v);

// ---- numbers as the picture prints them: two decimals, halves rounded up (the boost lands a hair below 0.375 where the exact value is 0.375), a true minus sign,
// and 0.00 for a value that rounds to zero
const hundredths = x => Math.round(Math.abs(x) * 100 + 1e-6);
export const f2 = x => { const h = hundredths(x); return (h === 0 ? '' : x < 0 ? '−' : '') + (h / 100).toFixed(2); };
export const vText = v => (hundredths(v) === 0 ? '0' : f2(v)) + ' c';
export const speedText = v => (hundredths(v) === 0 ? 'at rest' : f2(v) + ' c');
// the width of a text in a picture's units (about 0.6 of the size for a letter, a digit or a minus sign, 0.3 for a space or a point)
export const textWidth = (s, fs) => [...s].reduce((w, ch) => w + (ch === ' ' || ch === '.' ? 0.3 : 0.6) * fs, 0);

// ---- the three fields of the front, at rest, and the observer's speed
const cross = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
export const X_HAT = [1, 0, 0];
const WAVE_E = [0, 0.3, 0.4];
// the field of a light wave that runs along +x: B = x̂ × E, the same size as E and at right angles to it
export const PRESETS = [
  { id: 'electric', label: 'an electric field', E: [0, 0.6, 0.8], B: [0, 0, 0] },
  { id: 'magnetic', label: 'a magnetic field', E: [0, 0, 0], B: [0, 0.6, 0.8] },
  { id: 'light', label: 'a light wave', E: WAVE_E, B: cross(X_HAT, WAVE_E) }
];
export const V_MIN = -95, V_MAX = 95;                                            // the speed counts hundredths of the speed of light
export const START = { field: 'electric', v: 0 };
export const SPEED_ENDS = [vText(V_MIN / 100), '0', vText(V_MAX / 100)];
export const canSet = (field, v) => PRESETS.some(p => p.id === field) && Number.isInteger(v) && v >= V_MIN && v <= V_MAX;
export const presetOf = id => PRESETS.find(p => p.id === id);
// the largest part that the speeds reach, over the three fields (the thickest edge)
export const MAX_ABS = (() => { let mx = 0; for (const p of PRESETS) for (let v = V_MIN; v <= V_MAX; v++) for (const x of partsOf(boost(toF(p.E, p.B), v / 100))) mx = Math.max(mx, Math.abs(x)); return mx; })();

// ---- the front picture: the tetrahedron in simple perspective, t on top, x in front, y back left, z back right, seen from a little above the front
const deg = Math.PI / 180, AZIMUTH = { x: 0, y: -120, z: 120 };
export const CAM = { cx: 230, cy: 196, scale: 168, tilt: 18, dist: 5 };
// the corners of a regular tetrahedron of circumradius 1 (t at the top, the base at height −1/3), tilted towards the eye by CAM.tilt
export const SPACE = (() => {
  const r = Math.sqrt(8) / 3, P = [[0, 1, 0]];
  for (const k of ['x', 'y', 'z']) { const a = AZIMUTH[k] * deg; P.push([r * Math.sin(a), -1 / 3, r * Math.cos(a)]); }
  const c = Math.cos(CAM.tilt * deg), s = Math.sin(CAM.tilt * deg);
  return P.map(([X, Y, Z]) => [X, Y * c - Z * s, Y * s + Z * c]);
})();
// seen from the distance CAM.dist: depth is the coordinate towards the eye
export const project = ([X, Y, Z]) => { const k = CAM.dist / (CAM.dist - Z); return { x: CAM.cx + CAM.scale * X * k, y: CAM.cy - CAM.scale * Y * k, depth: Z }; };
export const CORNER_R = 16;
export const CORNERS = AXES.map((name, a) => ({ a, name, mask: 1 << a, ...project(SPACE[a]) }));
// the frame of the picture: the corners and a margin round them
export const VIEW = (() => { const m = CORNER_R + 10, xs = CORNERS.map(c => c.x), ys = CORNERS.map(c => c.y), x = Math.floor(Math.min(...xs) - m), y = Math.floor(Math.min(...ys) - m); return { x, y, w: Math.ceil(Math.max(...xs) + m) - x, h: Math.ceil(Math.max(...ys) + m) - y }; })();
const at = (p, q, t) => ({ x: p.x + (q.x - p.x) * t, y: p.y + (q.y - p.y) * t });
// two segments cross (each strictly inside the other): where, as fractions of each
const crossAt = (p1, p2, q1, q2) => {
  const d = (p2.x - p1.x) * (q2.y - q1.y) - (p2.y - p1.y) * (q2.x - q1.x); if (Math.abs(d) < 1e-12) return null;
  const s = ((q1.x - p1.x) * (q2.y - q1.y) - (q1.y - p1.y) * (q2.x - q1.x)) / d, u = ((q1.x - p1.x) * (p2.y - p1.y) - (q1.y - p1.y) * (p2.x - p1.x)) / d;
  return s > 0 && s < 1 && u > 0 && u < 1 ? { s, u } : null;
};
// the hidden edge: of two edges whose drawings cross, the one farther from the eye where they cross (it is drawn dashed)
export const HIDDEN = (() => {
  for (const e of EDGES) for (const f of EDGES) {
    if (e.mask & f.mask) continue;
    const [a, b] = e.ends.map(i => CORNERS[i]), [c, d] = f.ends.map(i => CORNERS[i]), x = crossAt(a, b, c, d);
    if (x && a.depth + (b.depth - a.depth) * x.s < c.depth + (d.depth - c.depth) * x.u) return e.mask;
  }
  return -1;
})();
// the width of an edge: a hairline for a zero part, thicker by W_PER for each unit of strength
export const W0 = 2.5, W_PER = 5;
export const widthOf = x => W0 + W_PER * Math.abs(x);
// the number of each edge stands on the edge in a small pill: half way along an edge of the outline; on the two edges that cross in the middle, away from the crossing
export const PILL_AT = { E_x: 0.45, E_y: 0.5, E_z: 0.5, B_x: 0.25, B_y: 0.5, B_z: 0.5 };
export const PILL_FS = 16, PILL_H = 24, PILL_PAD = 8;
export const EDGE_GEO = EDGES.map(e => {
  const [p, q] = e.ends.map(i => CORNERS[i]), c = at(p, q, PILL_AT[e.id]);
  return { id: e.id, x1: p.x, y1: p.y, x2: q.x, y2: q.y, hidden: e.mask === HIDDEN, px: c.x, py: c.y };
});
// the pill of an edge whose number reads s: its box (x0, y0, x1, y1) and width
export const pillBox = (g, s) => { const w = textWidth(s, PILL_FS) + 2 * PILL_PAD; return { x0: g.px - w / 2, y0: g.py - PILL_H / 2, x1: g.px + w / 2, y1: g.py + PILL_H / 2, w }; };

// ---- front: the field that an observer moving along x sees, on the six edges
export function frontView(s) {
  const pr = presetOf(s.field), v = s.v / 100, F = boost(toF(pr.E, pr.B), v), parts = partsOf(F), st = strengths(F), inv = invariants(F);
  const edges = EDGES.map((e, i) => { const text = f2(parts[i]); return { ...e, ...EDGE_GEO[i], value: parts[i], width: widthOf(parts[i]), text, pill: pillBox(EDGE_GEO[i], text) }; });
  const moving = hundredths(v) !== 0;
  return { preset: pr, v, parts, edges, st, inv, speed: speedText(v), sText: f2(inv.s), pText: f2(inv.p), moving };
}

// ---- back, the mathematician: one step multiplies an edge by one direction; a direction it holds is dropped (a corner), one it lacks is added (a triangle)
export const ruleName = m => CELL13.equations[m];
export function steps(e) {
  const all = [0, 1, 2, 3].map(a => {
    const [target, sign] = bladeMul(1 << a, e.mask, SQ), drop = popcount(target) === 1;
    return { axis: a, dir: AXES[a], target, sign, op: drop ? 'drop' : 'add', where: (drop ? 'corner ' : 'triangle ') + lettersOf(target), rule: ruleName(target) };
  });
  return [...all.filter(s => s.op === 'drop'), ...all.filter(s => s.op === 'add')];
}
// which edges each corner and each triangle gathers
export function gathered() {
  const by = {};
  for (const e of EDGES) for (const s of steps(e)) (by[s.target] = by[s.target] || []).push(e.id);
  const keys = Object.keys(by).map(Number), corners = keys.filter(m => popcount(m) === 1), triangles = keys.filter(m => popcount(m) === 3);
  return { by, corners, triangles, perCorner: [...new Set(corners.map(m => by[m].length))], perTriangle: [...new Set(triangles.map(m => by[m].length))], total: keys.reduce((n, m) => n + by[m].length, 0) };
}
export const START_EDGE = 'E_y';
// the tetrahedron drawn flat (seen from above t, through the base): t in the middle, x below, y up left, z up right; the triangle x y z is everything outside
export const FLAT = { w: 380, h: 372, cx: 190, cy: 196, R: 150, r: 16 };
export const FLAT_AT = (() => {
  const P = { t: { x: FLAT.cx, y: FLAT.cy } }, ang = { x: 90, y: 210, z: 330 };
  for (const k of ['x', 'y', 'z']) P[k] = { x: FLAT.cx + FLAT.R * Math.cos(ang[k] * deg), y: FLAT.cy + FLAT.R * Math.sin(ang[k] * deg) };
  return AXES.map(n => P[n]);
})();
const RIM = TOP ^ 1;                                                              // the triangle x y z (the outside)
// the name of the outside triangle x y z stands in the top left corner of the drawing
export const OUTSIDE_SPOT = { x: 34, y: 30 };
export const facePoints = m => bitsOf(m).map(a => FLAT_AT[a].x.toFixed(1) + ',' + FLAT_AT[a].y.toFixed(1)).join(' ');
export const AH = 10;                                                             // the length of an arrow head
// an arrow from p to q, its head a triangle
export function arrow(p, q) {
  const L = Math.hypot(q.x - p.x, q.y - p.y), ux = (q.x - p.x) / L, uy = (q.y - p.y) / L, bx = q.x - ux * AH, by = q.y - uy * AH;
  return { x1: p.x, y1: p.y, x2: bx, y2: by, tipX: q.x, tipY: q.y, head: [q.x, q.y, bx - uy * AH * 0.55, by + ux * AH * 0.55, bx + uy * AH * 0.55, by - ux * AH * 0.55].map(n => n.toFixed(1)).join(' ') };
}
// the centre of the circle inside a triangle of the drawing (its widest spot): the corners weighed by the lengths of the sides facing them
export const incentre = m => {
  const [A, B, C] = bitsOf(m).map(a => FLAT_AT[a]), a = Math.hypot(B.x - C.x, B.y - C.y), b = Math.hypot(A.x - C.x, A.y - C.y), c = Math.hypot(A.x - B.x, A.y - B.y), s = a + b + c;
  return { x: (a * A.x + b * B.x + c * C.x) / s, y: (a * A.y + b * B.y + c * C.y) / s };
};
export const OUT_LEN = 40, ADD_GAP = 8;
// the four arrows of the steps of edge e on the flat drawing: the two drops run along the edge from its middle to its two ends; the two adds leave its middle for the
// triangles on either side (an inner triangle: towards its widest spot; the outside: straight out of the rim)
export function stepArrows(e) {
  const [i, j] = e.ends, p = FLAT_AT[i], q = FLAT_AT[j], L = Math.hypot(q.x - p.x, q.y - p.y), u = { x: (q.x - p.x) / L, y: (q.y - p.y) / L }, m = at(p, q, 0.5);
  const n0 = { x: -u.y, y: u.x }, tSide = Math.sign(n0.x * (FLAT_AT[0].x - m.x) + n0.y * (FLAT_AT[0].y - m.y));
  return steps(e).map(s => {
    if (s.op === 'drop') {
      const end = FLAT_AT[Math.log2(s.target)], dir = end === p ? -1 : 1;
      return { ...s, ...arrow(m, { x: end.x - u.x * dir * (FLAT.r + 4), y: end.y - u.y * dir * (FLAT.r + 4) }), dashed: false };
    }
    if (s.target === RIM) return { ...s, ...arrow(m, { x: m.x - n0.x * tSide * OUT_LEN, y: m.y - n0.y * tSide * OUT_LEN }), dashed: true };
    const c = incentre(s.target), d = Math.hypot(c.x - m.x, c.y - m.y);
    return { ...s, ...arrow(m, { x: m.x + (c.x - m.x) * (d - ADD_GAP) / d, y: m.y + (c.y - m.y) * (d - ADD_GAP) / d }), dashed: true };
  });
}
export function mathView(id) {
  const e = EDGES.find(x => x.id === id), list = steps(e), G = gathered(), k = G.perCorner[0], kt = G.perTriangle[0];
  return {
    e, arrows: stepArrows(e), lit: new Set(list.map(s => s.target)), rim: RIM,
    faces: G.triangles.map(t => ({ mask: t, name: spaced(t), outside: t === RIM, points: facePoints(t) })), outsideName: spaced(RIM),
    lines: list.map(s => (s.op === 'drop' ? 'drop ' : 'add ') + s.dir + ' → ' + s.where + ' · ' + s.rule),
    counts: { perCorner: k, perTriangle: kt, corners: G.corners.length, triangles: G.triangles.length, total: G.total, perEdge: G.total / EDGES.length, edges: EDGES.length }
  };
}

// ---- back, the physicist: one field with parts along and across the motion, an observer at speed v along x; the picture looks along x (y to the right, z up)
export const PHYS = { E: [0.6, 0.8, 0], B: [0.7, -0.3, 0.4] };
export const PV_MIN = 0, PV_MAX = 80, START_PHYS = 60;
export const PHYS_ENDS = ['at rest', vText(PV_MAX / 100)];
export const PHYS_VIEW = { w: 320, h: 300, cx: 160, cy: 150, r: 124 };
const across = a => [a[1], a[2]];                                                 // the part across the motion, as (y, z)
export function physFields(pv) {
  const v = pv / 100, F = boost(toF(PHYS.E, PHYS.B), v), p = partsOf(F);
  return { v, g: gammaOf(v), E: p.slice(0, 3), B: p.slice(3), inv: invariants(F), inv0: invariants(toF(PHYS.E, PHYS.B)) };
}
// the scale of the picture: the longest arrow across the motion, over the whole range of speeds, reaches PHYS_VIEW.r
export const PHYS_SCALE = (() => { let mx = 0; for (let pv = PV_MIN; pv <= PV_MAX; pv++) { const f = physFields(pv); for (const a of [f.E, f.B]) mx = Math.max(mx, Math.hypot(...across(a))); } return PHYS_VIEW.r / mx; })();
const C0 = { x: PHYS_VIEW.cx, y: PHYS_VIEW.cy };
export const tipOf = a => { const [y, z] = across(a); return { x: C0.x + PHYS_SCALE * y, y: C0.y - PHYS_SCALE * z }; };
// the name of an arrow stands beyond its tip
const labelAt = (a, k = 15) => { const t = tipOf(a), L = Math.hypot(t.x - C0.x, t.y - C0.y) || 1; return { x: t.x + (t.x - C0.x) / L * k, y: t.y + (t.y - C0.y) / L * k + 6 }; };
export const vec = a => '(' + a.map(f2).join(', ') + ')';
export function physView(pv) {
  const f = physFields(pv), moving = hundredths(f.v) !== 0;
  return {
    ...f, moving,
    eNow: arrow(C0, tipOf(f.E)), bNow: arrow(C0, tipOf(f.B)), eRest: arrow(C0, tipOf(PHYS.E)), bRest: arrow(C0, tipOf(PHYS.B)),
    eLab: labelAt(f.E), bLab: labelAt(f.B),
    speed: speedText(f.v) + (moving ? ' · γ = ' + f2(f.g) : ''),
    alongText: 'Eₓ = ' + f2(f.E[0]) + ' · Bₓ = ' + f2(f.B[0]),
    eLine: 'E′ = ' + vec(f.E), bLine: 'B′ = ' + vec(f.B),
    invText: 'E′² − B′² = ' + f2(f.inv.s) + ' · E′·B′ = ' + f2(f.inv.p)
  };
}
