// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/index.js — the ported Octavo leaf logics, by slug (interface 16 of docs/BUILD_CONTRACTS.md; the API is docs/EXPLORE_PORT.md); every product and
// sign goes through engines/bitrule.js (directly, or through engines/labels.js and the engines that import it). The order is the order of the path and the shelf.
import * as clock from './leaves/clock.logic.js';
import * as moves from './leaves/moves.logic.js';
import * as mirrors from './leaves/mirrors.logic.js';
import * as zero from './leaves/zero.logic.js';
import * as light from './leaves/light.logic.js';
import * as fall from './leaves/fall.logic.js';
import * as roots from './leaves/roots.logic.js';
import * as seats from './leaves/seats.logic.js';
import * as magnets from './leaves/magnets.logic.js';
import * as springs from './leaves/springs.logic.js';
import * as charge from './leaves/charge.logic.js';
import * as halfTurns from './leaves/half-turns.logic.js';
import * as bands from './leaves/bands.logic.js';
import * as field from './leaves/field.logic.js';
import * as steps from './leaves/steps.logic.js';
import * as cube from './leaves/cube.logic.js';
import * as electron from './leaves/electron.logic.js';
import * as tumbling from './leaves/tumbling.logic.js';
import * as hung from './leaves/hung.logic.js';

export const LEAF_LOGIC = { clock, moves, zero, light, fall, roots, seats, magnets, springs, charge, mirrors, 'half-turns': halfTurns, bands, field, steps, cube, electron, tumbling, hung };
