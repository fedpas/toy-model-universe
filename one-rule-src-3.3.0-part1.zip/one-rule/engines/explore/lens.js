// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/lens.js — the numbers of the three lens explorers of Explore (docs/EXPLORE_PLAN.md §2.6, interface 17), on maxwellViews (engines/labels.js) and the
// kernel engines/bitrule.js: every sign is the kernel's sign(), every product the kernel's mul(); nothing here multiplies two blades by itself.
//   A  simplexMaxwell(n, mirrored)  the n-simplex of Cl(1,n), n = 1…4 (or its mirror Cl(n,1)): the generators are its n + 1 vertices, the field pieces (grade 2) its
//      edges, the grade-3 labels its triangles; a move e_b e_a = s e_{a xor b} of a piece a along an axis b is a contraction (to a vertex) or a wedge (into a triangle).
//   B  demicubeMoves(n), moveOf(n, plane, k)  the even labels of Cl(1, n−1), n = 2, 3, 4 (the corners of the n-demicube), the squares of the plane corners, and two
//      mirrors x ↦ −a x a⁻¹ in one coordinate plane composed into a move (a turn or a boost), applied to points; productOf for two plane corners.
//   B′ motionBy(n, plane, amount), composeBy (round 5, wave 2)  what the move does as the sandwich R x R̃ by its even element R = a₂a₁ (the reverse through the
//      kernel, reverseOf): an event, a rod with a clock at its middle, a square, a cube; two moves composed (R_b R_a: its boost and the rotation left);
//      moveNameOf names a move by the plane it acts in (tests/explore/motion.test.mjs).
//   C  cubeMaxwell(k, d)  the n-cube of the labels of Cl(k, d), n = k + d = 2…7 with k, d <= 4: layers by grade, the n·C(n,2) moves leaving the layer of F (grade 2),
//      and the edges m → m ∪ {i} with the kernel's sign (the Jordan–Wigner string of LNC-056).
// The lens views share cubeOf, demicubeOf, orthoplexOf / facetOf / ridgeOf (the shapes of the labels) and the printers nameOf / primeName / primeProduct (notation only).
// tests/explore/lens.test.mjs ties every number to checks/selfcheck/maxwell.json, mirrors.json, shapes.json, dictionary.json and to standard routes (matrices).
// The physics of the cells (BUILD_CONTRACTS interface 23, D29): cellsAvailable, cellPhysics, equationsOf, roleName of engines/maxwellPhysics.js (owner P1) —
// the names v15 gave the blades and the equations of ∇F = J, read from checks/selfcheck/maxwell.json and recomputed through the kernel (tests/maxwell.test.mjs),
// passed on here so that the explorers read everything through this module; tests/explore/physics.test.mjs ties every printed name, equation and sign to the
// stored file and recomputes every printed term through the kernel.
import { sign, cell, label, PRIMES, popcount, mul as kmul, add as kadd } from '../bitrule.js';
import { maxwellViews, bitsOf } from '../labels.js';
export { cellsAvailable, cellPhysics, equationsOf, roleName } from '../maxwellPhysics.js';

const range = n => Array.from({ length: n }, (_, i) => i);
export const binom = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); };

// ---------------------------------------------------------------- shared: parity, one move, the printers
/** an even label: an even number of generators (the even half of the cube, the demicube) */
export const isEven = m => popcount(m) % 2 === 0;
/** the move of label a along axis b: e_b e_a = s e_{a xor b} (left multiplication by the axis), a contraction when a holds b, a wedge when it does not */
export function stepOf(eps, a, b) {
  const g = 1 << b;
  return { from: a, axis: b, to: a ^ g, op: a & g ? 'contract' : 'wedge', s: sign(g, a, eps) };
}
const SUB = '₀₁₂₃₄₅₆₇₈₉';
export const subscript = s => String(s).replace(/\d/g, d => SUB[+d]);
/** the prime name of a label: the product of the primes of its generators (the k-th generator is the k-th prime, 1 for the empty label) — notation only (PAG-003) */
export const primeName = m => bitsOf(m).reduce((x, i) => x * PRIMES[i], 1);
const gcd = (x, y) => (y ? gcd(y, x % y) : x);
/** two prime names multiplied with the shared squares taken out: K = A·B / gcd(A, B)², the name of a xor b (dictionary_selfcheck.py checks the rule on every pair) */
export function primeProduct(a, b) { const A = primeName(a), B = primeName(b), g = gcd(A, B); return { A, B, g, K: (A * B) / (g * g) }; }
/** the name of a label in one printing: 'letters' (the cell's axis names joined: tx, t₁t₂x; 1 for the empty label), 'digits' (the generators counted from 1: 12; ∅ for the
 *  empty label, so that it is not read as generator 1), 'bits', 'primes', 'clifford' (e₁e₂) */
export function nameOf(m, how, axes, eps) {
  if (how === 'bits') return label(m, 'bits', eps);
  if (how === 'primes') return String(primeName(m));
  if (how === 'clifford') return label(m, 'clifford', eps);
  if (m === 0) return how === 'digits' ? '∅' : '1';
  if (how === 'digits') return bitsOf(m).map(i => i + 1).join('');
  return bitsOf(m).map(i => subscript(axes[i])).join('');
}
/** the printing a page lens, the mode and the level ask for: bits and primes are label lenses (the shape lens 'prime' prints primes too), 'clifford' prints e-words;
 *  otherwise the axis letters in physics and the generator numbers in mathematics (as e-words at research level) */
export function printingOf(lens, mode = 'phys', level = 'research') {
  if (lens === 'bits') return 'bits';
  if (lens === 'primes' || lens === 'prime') return 'primes';
  if (lens === 'clifford') return 'clifford';
  if (mode === 'math') return level === 'learner' ? 'digits' : 'clifford';
  return 'letters';
}

// ---------------------------------------------------------------- the shapes of the labels of N generators
/** the N-cube of labels: corners with grade and parity, the layers by grade, and the edges m → m ∪ {i}, each with the kernel's sign of e_i e_m — the
 *  Jordan–Wigner string (−1)^(bits of m below i) of LNC-056, since i is not in m */
export function cubeOf(N, eps = cell(N, 0)) {
  const corners = range(1 << N).map(m => ({ m, grade: popcount(m), even: isEven(m) }));
  const layers = range(N + 1).map(g => corners.filter(c => c.grade === g).map(c => c.m));
  const edges = [];
  for (const c of corners) for (let i = 0; i < N; i++) { const g = 1 << i; if (!(c.m & g)) edges.push({ from: c.m, to: c.m | g, axis: i, s: sign(g, c.m, eps) }); }
  return { N, eps, corners, layers, counts: layers.map(l => l.length), edges };
}
/** the edges of a demicube: two even corners are joined when they differ in two generators */
export function demicubeEdges(corners) {
  const out = [];
  for (const a of corners) for (const b of corners) if (a < b && popcount(a ^ b) === 2) out.push([a, b]);
  return out;
}
/** the N-demicube: the 2^(N−1) even labels, its edges, its corners by grade and the degree of a corner */
export function demicubeOf(N) {
  const corners = range(1 << N).filter(isEven), edges = demicubeEdges(corners);
  const byGrade = {}; for (const m of corners) byGrade[popcount(m)] = (byGrade[popcount(m)] || 0) + 1;
  return { N, corners, edges, byGrade, degree: edges.filter(([a, b]) => a === 0 || b === 0).length };
}
/** the N-orthoplex: the poles ±e_i (pole 2i is +e_i, pole 2i + 1 is −e_i) and its edges, two poles of different axes; the facets match the cube's corners (SHP-001) */
export function orthoplexOf(N) {
  const poles = range(2 * N).map(v => ({ v, axis: v >> 1, plus: v % 2 === 0 }));
  const edges = []; for (const p of poles) for (const q of poles) if (p.v < q.v && p.axis !== q.axis) edges.push([p.v, q.v]);
  return { N, poles, edges, facets: 1 << N };
}
/** the facet of the label m: the + pole of every axis in m and the − pole of every other axis */
export const facetOf = (m, N) => range(N).map(i => (bitsOf(m).includes(i) ? 2 * i : 2 * i + 1));
/** the poles two facets share: N − 1 of them (a ridge) exactly when the labels differ in one generator */
export function ridgeOf(a, b, N) { const fb = facetOf(b, N); return facetOf(a, N).filter(v => fb.includes(v)); }

// ---------------------------------------------------------------- A. the n-simplex as the picture of Maxwell in n + 1 dimensions
export const SIMPLEX_NS = [1, 2, 3, 4];
/** the n-simplex of Cl(1, n) (one generator squaring to +1, called time, first; n = 1…4), or with `mirrored` its mirror Cl(n, 1) as maxwell.json stores it
 *  (generators squaring to +1 first). Vertices: the generators, the lone one (the time generator of Cl(1,n), the space generator of the mirror) on top; edges: the
 *  pieces of F (roles E, B, T from the labels); triangles: the grade-3 labels; incidences: every piece along every axis (the kernel's sign of e_b e_a). */
export function simplexMaxwell(n = 3, mirrored = false) {
  const nn = SIMPLEX_NS.includes(n) ? n : 3, flip = !!mirrored && nn > 1;
  const k = flip ? nn : 1, d = flip ? 1 : nn, V = maxwellViews(k, d), N = k + d, eps = V.eps;
  const lone = k === 1 ? 0 : N - 1;
  const slots = [lone, ...range(N).filter(i => i !== lone)];
  const vertices = slots.map((g, slot) => ({ slot, g, m: 1 << g, axis: V.axes[g], square: eps[g], role: V.blades[1 << g].role }));
  const pieces = V.blades.filter(b => b.grade === 2).map(b => ({ m: b.m, ends: bitsOf(b.m), role: b.role, square: b.square }));
  const triangles = V.blades.filter(b => b.grade === 3).map(b => ({ m: b.m, corners: bitsOf(b.m), role: b.role }));
  const incidences = pieces.flatMap(p => range(N).map(b => stepOf(eps, p.m, b)));
  const counts = { pieces: binom(N, 2), sources: N, triangles: binom(N, 3), incidences: N * binom(N, 2) };
  return { n: nn, k, d, N, eps, axes: V.axes, mirrored: flip, lone, vertices, pieces, triangles, incidences, counts, roles: V.blades.map(b => b.role) };
}

// ---------------------------------------------------------------- C. the n-cube as the picture of Maxwell with n generators
export const CUBE_NS = [2, 3, 4, 5, 6, 7];
/** the stored splits of maxwell.json: k time and d space generators, 1 <= k, d <= 4, k + d <= 7 */
export const splitOk = (k, d) => Number.isInteger(k) && Number.isInteger(d) && k >= 1 && d >= 1 && k <= 4 && d <= 4 && k + d <= 7;
/** the n-cube of the labels of Cl(k, d): corners (grade, parity, role), layers, the cube's edges with their signs, and the moves that leave layer 2 (the field F):
 *  down to layer 1 (a contraction) or up to layer 3 (a wedge), each with the kernel's sign */
export function cubeMaxwell(k = 1, d = 3) {
  const [kk, dd] = splitOk(k, d) ? [k, d] : [1, 3];
  const V = maxwellViews(kk, dd), N = kk + dd, eps = V.eps, C = cubeOf(N, eps);
  const corners = C.corners.map(c => ({ ...c, role: V.blades[c.m].role }));
  const F = corners.filter(c => c.grade === 2).map(c => c.m);
  const leaving = F.flatMap(S => range(N).map(b => { const st = stepOf(eps, S, b); return { ...st, dir: popcount(st.to) < 2 ? 'down' : 'up' }; }));
  const counts = { corners: 1 << N, layers: C.counts, F: F.length, E: V.counts.E, B: V.counts.B, T: V.counts.T, incidences: leaving.length,
    down: leaving.filter(x => x.dir === 'down').length, up: leaving.filter(x => x.dir === 'up').length };
  return { k: kk, d: dd, n: N, N, eps, axes: V.axes, corners, layers: C.layers, edges: C.edges, F, leaving, counts };
}

// ---------------------------------------------------------------- B. the demicube of the moves
export const MOVE_NS = [2, 3, 4];
/** the amounts of the chips: angles of a turn (degrees) and speeds of a boost (fractions of the speed of light; 0.6 is the stored boost_5_4_3_4, γ = 5/4) */
export const AMOUNTS = { turn: [0, 30, 60, 90, 120], boost: [0, 0.2, 0.5, 0.6, 0.8] };
/** the even labels of Cl(1, n−1) (t squares to +1, x, y, z to −1), n = 2, 3, 4: the corners of the n-demicube, its edges, and the plane corners (grade 2) with the
 *  kernel's square of each: +1 a boost plane, −1 a turn plane */
export function demicubeMoves(n = 4) {
  const nn = MOVE_NS.includes(n) ? n : 4, eps = cell(1, nn - 1), V = maxwellViews(1, nn - 1), D = demicubeOf(nn);
  const planes = D.corners.filter(m => popcount(m) === 2).map(m => { const sq = sign(m, m, eps); return { m, square: sq, kind: sq > 0 ? 'boost' : 'turn' }; });
  const counts = { corners: D.corners.length, edges: D.edges.length, degree: D.degree, boosts: planes.filter(p => p.kind === 'boost').length, turns: planes.filter(p => p.kind === 'turn').length };
  return { n: nn, eps, axes: V.axes, corners: D.corners, edges: D.edges, byGrade: D.byGrade, planes, top: (1 << nn) - 1, counts };
}
const vecOf = comps => new Map(comps.filter(([, c]) => c !== 0).map(([i, c]) => [1 << i, c]));
const coordsOf = (v, n) => range(n).map(i => v.get(1 << i) || 0);
/** one mirror: p ↦ −a p a⁻¹ with a⁻¹ = a / a² (the kernel's products; a and p are vectors as Maps) */
export function reflect(eps, a, p) {
  const aa = kmul(a, a, eps).get(0) || 0, r = kmul(kmul(a, p, eps), a, eps);
  return new Map([...r].map(([key, c]) => [key, -c / aa]));
}
/** the square of the difference of two points (t, x, y, z) by the kernel: t² − x² − y² − z² in Cl(1, n−1) */
export function interval(n, p, q) { const dv = vecOf(p.map((c, i) => [i, c - q[i]])); return kmul(dv, dv, cell(1, n - 1)).get(0) || 0; }
/** the amount of a chip k for a plane of the given kind: an angle in radians (turn) or the rapidity atanh(v) of the speed v (boost) */
export function amountOf(kind, k) { return kind === 'turn' ? AMOUNTS.turn[k] * Math.PI / 180 : Math.atanh(AMOUNTS.boost[k]); }
/** two mirrors in the coordinate plane m of Cl(1, n−1), half the amount apart, and the move they make (mirror 1 first, then mirror 2): the normals, the versor
 *  a₂a₁ printed with its scalar part >= 0 (both signs make the same move), its weights on the corner 1 and on the plane, the matrix of the move (columns: the images of
 *  the axes), its determinant and that of one mirror. A turn plane holds two space axes i < j; a boost plane holds t and one space axis j. */
export function moveBy(n, m, amount) {
  const nn = MOVE_NS.includes(n) ? n : 4, eps = cell(1, nn - 1), sq = sign(m, m, eps), kind = sq > 0 ? 'boost' : 'turn', [i, j] = bitsOf(m);
  const half = amount / 2;
  const n1 = kind === 'turn' ? [[i, 1]] : [[j, 1]];
  const n2 = kind === 'turn' ? [[i, Math.cos(half)], [j, Math.sin(half)]] : [[j, Math.cosh(half)], [i, Math.sinh(half)]];
  const a1 = vecOf(n1), a2 = vecOf(n2), V = kmul(a2, a1, eps), flipV = (V.get(0) || 0) < 0;
  const weights = { one: flipV ? -(V.get(0) || 0) : V.get(0) || 0, plane: flipV ? -(V.get(m) || 0) : V.get(m) || 0 };
  const other = [...V].filter(([key, c]) => key !== 0 && key !== m && Math.abs(c) > 1e-12).length;
  const image = p => coordsOf(reflect(eps, a2, reflect(eps, a1, vecOf(p.map((c, x) => [x, c])))), nn);
  const once = p => coordsOf(reflect(eps, a1, vecOf(p.map((c, x) => [x, c]))), nn);
  const unit = c => range(nn).map(x => (x === c ? 1 : 0));
  const cols = range(nn).map(c => image(unit(c))), onceCols = range(nn).map(c => once(unit(c)));
  const matrix = range(nn).map(r => range(nn).map(c => cols[c][r])), onceMatrix = range(nn).map(r => range(nn).map(c => onceCols[c][r]));
  const line = nrm => { const c = Object.fromEntries(nrm), u = [eps[j] * (c[j] || 0), -eps[i] * (c[i] || 0)], L = Math.hypot(u[0], u[1]) || 1; return [u[0] / L + 0, u[1] / L + 0]; };
  const rotor = new Map([...V].map(([key, c]) => [key, flipV ? -c : c]));   // the even element R = ±a₂a₁ of the move (motionBy applies it as R x R̃)
  return { n: nn, m, kind, square: sq, axes: [i, j], amount, half, normals: [n1, n2], mirrorLines: [line(n1), line(n2)], weights, other, matrix, det: det(matrix), onceDet: det(onceMatrix), image, once, rotor };
}
/** the move of the chip k (0…4) in the plane m */
export function moveOf(n, m, k = 3) {
  const nn = MOVE_NS.includes(n) ? n : 4, kind = sign(m, m, cell(1, nn - 1)) > 0 ? 'boost' : 'turn', kk = Number.isInteger(k) && k >= 0 && k < 5 ? k : 3;
  return { ...moveBy(nn, m, amountOf(kind, kk)), k: kk, value: AMOUNTS[kind][kk] };
}
/** the determinant of a small square matrix (Laplace expansion along the first row) */
export function det(M) {
  if (M.length === 1) return M[0][0];
  return M[0].reduce((acc, x, c) => acc + (c % 2 ? -1 : 1) * x * det(M.slice(1).map(row => row.filter((_, k) => k !== c))), 0);
}
/** points of each rung at time 0: the ends and the middle of a ruler (t, x), the corners of a square (t, x, y), the corners of a cube (t, x, y, z) — the points the
 *  interval checks of tests/explore/lens.test.mjs move (the drawing moves the bodies of motionBy since round 5, wave 2) */
export const OBJECTS = (() => {
  const cube = range(8).map(c => [0, c & 1 ? 1.05 : 0.25, c & 2 ? 1.05 : 0.25, c & 4 ? 1.05 : 0.25]), segs = [];
  for (let c = 0; c < 8; c++) for (const g of [1, 2, 4]) if (!(c & g)) segs.push([c, c | g]);
  return {
    2: { pts: [[0, 0.5], [0, 1], [0, 1.5]], segs: [[0, 1], [1, 2]] },
    3: { pts: [[0, 0.3, 0.2], [0, 1.1, 0.2], [0, 1.1, 1], [0, 0.3, 1]], segs: [[0, 1], [1, 2], [2, 3], [3, 0]] },
    4: { pts: cube, segs },
  };
})();
/** what the spacetime picture of explorer B draws moved (round 5, wave 2: motionPoints): the move of chip k in plane m applied to its events — the event E and, for a
 *  boost, the first tick of the clock, for a turn the two ends of the rod — and each event's path while the amount grows from 0 (24 steps); the mirror lines of
 *  moveBy are the directions, in the plane of the move, orthogonal to the two normals */
export function moveView(n, m, k = 3) {
  const mv = moveOf(n, m, k), pts = motionPoints(mv.n, m);
  const steps = range(25).map(s => (s === 24 ? mv : moveBy(mv.n, m, mv.amount * s / 24)));
  return { ...mv, pts, images: pts.map(mv.image), paths: pts.map(p => steps.map(x => x.image(p))) };
}
/** the product of two labels in Cl(1, n−1): e_a e_b = s e_{a xor b} (the kernel's sign) */
export function productOf(n, a, b) { const eps = cell(1, (MOVE_NS.includes(n) ? n : 4) - 1); return { a, b, to: a ^ b, s: sign(a, b, eps) }; }

// ---------------------------------------------------------------- B′. what the even element does to things: motion (round 5, wave 2, owner P2b; D30)
// The move of a plane m by an amount (moveBy: two mirrors half the amount apart) is the sandwich x ↦ R x R̃ by its even element R = a₂a₁, the product of the two
// mirrors, whose weights sit on the corner 1 and on the plane only. Every image below is that sandwich through the kernel (mul), and the reverse R̃ is taken through
// the kernel too: the generators of each blade multiplied in the opposite order, no sign of its own. The things it moves: an event E = (1, ½, ½, ½) (t = 1, every
// space coordinate ½); a rod of length 1 on the space axis of the move (a boost: its space axis; a turn: its first axis), from −½ to ½; a clock at the middle of
// the rod (the origin) ticking at t = 1; a square of side 1 in (x, y) (n = 3) and a cube of side 1 (n = 4), both centred at the origin. A body at rest at the
// place c is measured after the move at one moment, t = MOMENT, on its moved world line s ↦ s·u + R (0, c) R̃, where u = R e_t R̃ is the image of the time axis.
// Two moves compose as R_b R_a (a first); the composed move splits into its boost B = (1 + u e_t)/√(2(1 + u_t)), the one move without a turn that takes e_t
// to u, and the rest W = B̃ R_b R_a, which fixes e_t: the rotation left, in the plane its bivector part names (for two boosts along two axes, the corner a xor b).
// tests/explore/motion.test.mjs ties every number to the textbook Lorentz boost and rotation matrices, to the textbook formulas (v = tanh φ, γ = cosh φ, a length
// times √(1 − v²), γ₁γ₂ and tan(ω/2) = tanh(φ₁/2)·tanh(φ₂/2) for two boosts at right angles, the polar decomposition of the product of the two matrices) and to
// the stored examples of mirrors.json (boost_5_4_3_4, rotation_3_4_5).
/** the moment at which the moved bodies are measured, and the event E of n generators */
export const MOMENT = 2;
export const eventOf = n => [1, ...Array(n - 1).fill(0.5)];
const unitOf = (n, c, v = 1) => range(n).map(x => (x === c ? v : 0));
const distOf = (P, Q) => Math.hypot(...P.map((x, q) => x - Q[q]));
/** the reverse x̃ of a multivector (a Map mask → coefficient), through the kernel: the generators of each blade multiplied in the opposite order */
export function reverseOf(x, eps) {
  let out = new Map();
  for (const [m, c] of x) {
    let w = new Map([[0, c]]);
    for (const g of bitsOf(m).reverse()) w = kmul(w, new Map([[1 << g, 1]]), eps);
    out = kadd(out, w);
  }
  return out;
}
/** the move x ↦ R x R̃ / (R R̃)₀ of an even element (or any versor) R, through the kernel: act(p) gives the image's coordinates; norm = (R R̃)₀, normRest the size of
 *  the rest of R R̃ and rest(p) the size of the image's parts that are not a vector (both 0 for a versor) */
export function sandwichOf(eps, R) {
  const n = eps.length, Rt = reverseOf(R, eps), RR = kmul(R, Rt, eps), norm = RR.get(0) || 0;
  const raw = p => kmul(kmul(R, vecOf(p.map((c, i) => [i, c])), eps), Rt, eps);
  const size = (x, keep) => [...x].filter(([key]) => keep(key)).reduce((s, [, c]) => s + Math.abs(c), 0);
  return { Rt, norm, normRest: size(RR, key => key !== 0), act: p => coordsOf(raw(p), n).map(c => c / norm), rest: p => size(raw(p), key => popcount(key) !== 1) };
}
/** the matrix of a move (columns: the images of the axes) */
const matrixOf = (n, act) => { const cols = range(n).map(c => act(unitOf(n, c))); return range(n).map(r => range(n).map(c => cols[c][r])); };
/** a move named as the plane it acts in, from the kernel's square of the plane: +1 "boost along x" (along its space axis), −1 "rotation in the xy plane", 0 — a plane
 *  that holds a null generator, so only in a cell that has one — "translation along x" (along its other axis; two null axes: a null plane) */
export function moveNameOf(eps, m, axes) {
  const sq = sign(m, m, eps), [i, j] = bitsOf(m), isTime = g => /^t/.test(String(axes[g]));
  if (sq > 0) { const along = isTime(i) ? j : isTime(j) ? i : eps[i] < 0 ? i : j; return { kind: 'boost', square: 1, along, name: `boost along ${axes[along]}` }; }
  if (sq < 0) return { kind: 'turn', square: -1, plane: [i, j], name: `rotation in the ${axes[i]}${axes[j]} plane` };
  if (eps[i] === 0 && eps[j] === 0) return { kind: 'null', square: 0, plane: [i, j], name: `null plane ${axes[i]}${axes[j]}` };
  const along = eps[i] === 0 ? j : i;
  return { kind: 'translation', square: 0, along, name: `translation along ${axes[along]}` };
}
/** the events the spacetime picture draws moved: the event E; for a boost the first tick of the clock, (1, 0, …); for a turn the two ends of the rod */
export function motionPoints(n, m) {
  const nn = MOVE_NS.includes(n) ? n : 4, [i] = bitsOf(m), E = eventOf(nn);
  return sign(m, m, cell(1, nn - 1)) > 0 ? [E, unitOf(nn, 0)] : [E, unitOf(nn, i, -0.5), unitOf(nn, i, 0.5)];
}
/** the corners of the bodies at rest: the square of side 1 in (x, y) and the cube of side 1, centred at the origin (space coordinates; corner c holds its bits) */
export const SQUARE = [[-0.5, -0.5], [0.5, -0.5], [0.5, 0.5], [-0.5, 0.5]];
export const CUBE = range(8).map(c => [c & 1 ? 0.5 : -0.5, c & 2 ? 0.5 : -0.5, c & 4 ? 0.5 : -0.5]);
export const CUBE_EDGES = range(8).flatMap(c => [1, 2, 4].filter(g => !(c & g)).map(g => [c, c | g]));
/** what the move of plane m by `amount` (an angle, or a rapidity) does, every image the sandwich R x R̃ by its even element R = a₂a₁ (moveBy):
 *  { ...moveBy, name, R (entries), norm, normRest, act, matrix (of the sandwich), u (the image of e_t), gamma = u_t, velocity, speed, rapidity = atanh(speed),
 *    angle (a turn: the angle its first axis turns towards its second), event { at, to }, rod { axis, ends, to, before, after, at }, tick { at, to, time },
 *    squareBody / cubeBody { rest, at, sides } (n = 3 / 4), placeAt(c, T) } — the moved bodies at the moment MOMENT (square keeps moveBy's: the plane's square) */
export function motionBy(n, m, amount) {
  const mv = moveBy(n, m, amount), nn = mv.n, eps = cell(1, nn - 1), axes = ['t', 'x', 'y', 'z'].slice(0, nn), S = sandwichOf(eps, mv.rotor), act = S.act;
  const matrix = matrixOf(nn, act), u = act(unitOf(nn, 0)), gamma = u[0], velocity = u.slice(1).map(c => c / gamma), speed = Math.hypot(...velocity);
  const [i, j] = mv.axes, boost = mv.kind === 'boost', axis = boost ? j : i, img = act(unitOf(nn, i));
  // a body at rest at the place c (space coordinates): where its moved world line s ↦ s·u + R (0, c) R̃ is at the moment T
  const placeAt = (c, T = MOMENT) => { const p0 = act([0, ...c]), s = (T - p0[0]) / u[0]; return p0.slice(1).map((x, q) => x + s * u[q + 1]); };
  const ends = [-0.5, 0.5].map(v => unitOf(nn - 1, axis - 1, v)), E = eventOf(nn), at = ends.map(c => placeAt(c));
  const body = rest => { const now = rest.map(c => placeAt(c)); return { rest, at: now }; };
  const squareBody = nn === 3 ? body(SQUARE) : null, cubeBody = nn === 4 ? body(CUBE) : null;
  if (squareBody) squareBody.sides = [distOf(squareBody.at[0], squareBody.at[1]), distOf(squareBody.at[1], squareBody.at[2])];
  if (cubeBody) cubeBody.sides = [1, 2, 4].map(g => distOf(cubeBody.at[0], cubeBody.at[g]));
  return {
    ...mv, ...moveNameOf(eps, m, axes), kind: mv.kind, axisNames: axes, R: [...mv.rotor], norm: S.norm, normRest: S.normRest, act, rest: S.rest, matrix, u, gamma, velocity, speed,
    rapidity: Math.atanh(speed), angle: boost ? 0 : Math.atan2(img[j], img[i]),
    event: { at: E, to: act(E) }, rod: { axis, ends, to: ends.map(c => act([0, ...c])), before: distOf(ends[0], ends[1]), after: distOf(at[0], at[1]), at },
    tick: { at: unitOf(nn, 0), to: u, time: u[0] }, squareBody, cubeBody, placeAt,
  };
}
/** the motion of the chip k (0…4) in the plane m */
export function motionOf(n, m, k = 3) {
  const nn = MOVE_NS.includes(n) ? n : 4, kind = sign(m, m, cell(1, nn - 1)) > 0 ? 'boost' : 'turn', kk = Number.isInteger(k) && k >= 0 && k < 5 ? k : 3;
  return { ...motionBy(nn, m, amountOf(kind, kk)), k: kk, value: AMOUNTS[kind][kk] };
}
/** two moves composed, the plane a by amountA first, then the plane b by amountB: R = R_b R_a through the kernel, its weights on the corners, the matrix of the
 *  composed move, its boost part (u = R e_t R̃: γ, speed, direction; B = (1 + u e_t)/√(2(1 + u_t))) and the rotation left W = B̃ R (±W: W₀ ≥ 0): its angle, the
 *  corners its bivector part sits on, and the signed angle in that plane when it is one coordinate plane (positive from its first axis towards its second: with space
 *  generators squaring to −1, cos(θ/2) + sin(θ/2) e_ij turns e_i towards e_j by θ, as the turns of moveBy do) */
export function composeBy(n, a, b, amountA, amountB) {
  const A = motionBy(n, a, amountA), B = motionBy(n, b, amountB), nn = A.n, eps = cell(1, nn - 1), axes = A.axisNames;
  const R = kmul(new Map(B.R), new Map(A.R), eps), S = sandwichOf(eps, R), act = S.act, matrix = matrixOf(nn, act);
  const u = act(unitOf(nn, 0)), gamma = u[0], velocity = u.slice(1).map(c => c / gamma), speed = Math.hypot(...velocity);
  // the boost part: B = (1 + u e_t)/√(2(1 + u_t)) takes e_t to u; the rest W = B̃ R / √(R R̃)₀ fixes e_t (taken with W₀ ≥ 0: ±W make the same move)
  const Bst = new Map([...kadd(new Map([[0, 1]]), kmul(vecOf(u.map((c, q) => [q, c])), new Map([[1, 1]]), eps))].map(([key, c]) => [key, c / Math.sqrt(2 * (1 + u[0]))]));
  const W0 = kmul(reverseOf(Bst, eps), R, eps), scale = ((W0.get(0) || 0) < 0 ? -1 : 1) / Math.sqrt(S.norm), W = new Map([...W0].map(([key, c]) => [key, c * scale]));
  const planes = [...W].filter(([key, c]) => popcount(key) === 2 && Math.abs(c) > 1e-12).map(([key, c]) => ({ m: key, w: c }));
  const size = Math.hypot(...planes.map(p => p.w)), angle = 2 * Math.atan2(size, W.get(0) || 0);
  const one = planes.length === 1 ? planes[0] : null, [pi, pj] = one ? bitsOf(one.m) : [];
  return {
    a, b, n: nn, first: A, second: B, R: [...R], norm: S.norm, act, matrix, u, gamma, velocity, speed, rapidity: Math.atanh(speed), direction: speed > 1e-12 ? velocity.map(c => c / speed) : null,
    boost: [...Bst], rest: [...W], planes, angle, plane: one ? one.m : null, planeName: one ? `${axes[pi]}${axes[pj]}` : null, signedAngle: one ? 2 * Math.atan2(one.w, W.get(0) || 0) : null,
    restOff: [...W].filter(([key]) => key !== 0 && !(popcount(key) === 2 && !(key & 1))).reduce((s, [, c]) => s + Math.abs(c), 0),
  };
}
/** the composition of the chip k in the plane a, then the same chip in the plane b (each plane reads the chip as its own amount: an angle or a speed) */
export function composeOf(n, a, b, k = 3) {
  const nn = MOVE_NS.includes(n) ? n : 4, eps = cell(1, nn - 1), kk = Number.isInteger(k) && k >= 0 && k < 5 ? k : 3, amt = m => amountOf(sign(m, m, eps) > 0 ? 'boost' : 'turn', kk);
  return { ...composeBy(nn, a, b, amt(a), amt(b)), k: kk };
}
