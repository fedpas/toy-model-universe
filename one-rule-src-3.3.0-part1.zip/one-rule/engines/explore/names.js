// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/explore/names.js — three names for one label (port of Octavo's octavo/names.js onto the kernel; no React). Labels are lenses (D8): the same mask printed
// in another base, nothing here touches the algebra.
//   bits     which switches are on, the first switch on the right: label(v, 'bits', cell(n, 0)) = 0011
//   numbers  the number those bits make: String(v) = 3
//   primes   switch a is named by the (a+1)-th prime of the kernel's PRIMES, a label by the product of the primes of its switches: 6 = 2·3 (label(v, 'primes') is
//            the factor string). Combining two names, a·b/gcd(a, b)², gives the name of the XOR of the two labels (the product without its sign); a switch that is
//            on is a prime that divides the name, so dropping it divides and adding it multiplies.
// SWITCH_PRIMES = PRIMES.slice(0, 8): tests/explore/names.test.mjs ties it to checks/selfcheck/dictionary.json (ladder[8].prime_names.switch_primes) and checks
// the gcd rule for all 65,536 pairs of 8-switch labels with plain integers. Domain: labels of at most 8 switches (v < 256), n >= 1 switches for the bits naming.
import { PRIMES, label, cell, popcount, maskFromPrimes } from '../bitrule.js';

export const SWITCH_PRIMES = PRIMES.slice(0, 8);
export const NAME_MODES = [{ id: 'bits', label: 'bits' }, { id: 'numbers', label: 'numbers' }, { id: 'primes', label: 'primes' }];

const gcd = (a, b) => (b ? gcd(b, a % b) : a);

// the name of label v in the primes naming: 1 for the empty label
export const primeName = v => SWITCH_PRIMES.reduce((p, q, a) => (v >> a & 1 ? p * q : p), 1);
// the primes of its switches, written as a product: 2·3 (1 for the empty label) — the kernel's prime label of v
export const primeFactors = v => label(v & 0xff, 'primes');
// the prime that names switch a
export const primeOf = a => SWITCH_PRIMES[a];
// the label of a name of the primes naming (the inverse of primeName): the kernel's maskFromPrimes
export const labelOfName = name => maskFromPrimes(name);
// the name of the XOR of two labels from their names alone
export const combineNames = (a, b) => (a * b) / gcd(a, b) ** 2;
// the label with n switches in the naming `mode` ('bits' | 'numbers' | 'primes')
export const bitsOf = (v, n) => label(v, 'bits', cell(n, 0));
export const nameOf = (v, mode, n) => (mode === 'bits' ? bitsOf(v, n) : mode === 'primes' ? String(primeName(v)) : String(v));
// the longer form for a readout: "6 = 2·3" under primes when the label has two or more switches on, else the same as nameOf
export const nameLong = (v, mode, n) => (mode === 'primes' && popcount(v) > 1 ? primeName(v) + ' = ' + primeFactors(v) : nameOf(v, mode, n));
// can switch a be dropped from label v (it is on: its prime divides the name) / added to it (it is off: its prime and the name share no factor)
export const canDrop = (v, a) => (v >> a & 1) === 1;
export const canAdd = (v, a) => (v >> a & 1) === 0;
// one step: drop or add switch a (a flip of one bit, an XOR with 2^a, a division or a multiplication by the prime of a); null when it gives nothing
export const stepLabel = (v, a, op) => (op === 'drop' ? (canDrop(v, a) ? v ^ (1 << a) : null) : canAdd(v, a) ? v ^ (1 << a) : null);
// the same step in the primes naming, from the names alone; null when the prime does not divide (a drop) or already divides (an add)
export const stepName = (name, a, op) => (op === 'drop' ? (name % SWITCH_PRIMES[a] === 0 ? name / SWITCH_PRIMES[a] : null) : name % SWITCH_PRIMES[a] !== 0 ? name * SWITCH_PRIMES[a] : null);
// the number of switches that are on (the grade): the number of prime factors of the name
export const grade = popcount;
// the two halves of the cube of n switches: even labels (the corners of the half-cube, the demicube) and odd labels
export const isEven = v => (popcount(v) & 1) === 0;
// the divisors of the product of the first n switch primes, in the order of the labels: the names of the 2^n labels
export const namesOf = n => Array.from({ length: 1 << n }, (_, v) => primeName(v));
