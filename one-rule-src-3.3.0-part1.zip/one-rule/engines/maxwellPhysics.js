// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/maxwellPhysics.js — the physics of Maxwell's ∇F = J in the 15 cells Cl(k, d) that maxwell_selfcheck.py stores (k, d <= 4, k + d <= 7): interface 23
// of docs/BUILD_CONTRACTS.md round 5, decision D29 (the stored, checked physics is printed as fact and named as v15 named it).
// Read from checks/selfcheck/maxwell.json, through the stored block MAXWELL (engines/storedPaths.js → engines/storedParts.js): per cell its kind, axes, the sign
// convention (F, J, field_order, signs, grad), the counts, the checks, the mirror, the algebra and the symbol; and the two ladders. Everything else is recomputed:
//   blades       every label e_S of Cl(k, d) (k time generators squaring to +1 first, then d space generators squaring to −1): its square (the kernel's sign of
//                e_S e_S), its role from its bits (a vector is ρ with a time index or J without; a bivector E with one time index, T with two, B with none; a
//                trivector a Faraday equation with a time index or ∇·B without), and its name as v15 named it (ρ, Jx, Ex, Bz, T12, E1x, Bxy, Farz, ∇·B, F12x …);
//   incidences   every term of ∇F = J, with ∇ = Σ γa ∂a: the move e_a e_S = s e_{S xor a} of a field component e_S along an axis a, with s the kernel's sign
//                (engines/bitrule.js sign) times the stored sign of that component in F; a contraction to a vector (δF = J) or a wedge to a trivector (dF = 0);
//   equations    one per vector and trivector target: its terms (in the order of the field components), the equation as the script prints it (terms in the
//                textbook order — by axis, Faraday's law in one time and three space dimensions with its curl in cyclic order; a homogeneous equation written
//                with its first term positive; the source with its stored sign), its id and name (Gauss, Ampère x, Faraday z, no monopole, Bianchi 123, dF t1 t2 x …).
// tests/maxwell.test.mjs asserts that the recomputation equals the whole stored file for all 15 cells (blades, incidences, equations, counts) and that mutants
// of the convention, the signature and the kernel are caught. No sign is computed here: every sign is the kernel's (tests/shipped.test.mjs rule 4).
import { sign as kernelSign, cell, popcount } from './bitrule.js';
import { MAXWELL } from './stored.js';
import { MAXWELL_CELLS } from './storedPaths.js';

const SPACE = ['x', 'y', 'z', 'w'];
const keyOf = (k, d) => `${k},${d}`;
/** the generators of a label, in increasing order */
const indicesOf = (m, n) => Array.from({ length: n }, (_, i) => i).filter(i => (m >> i) & 1);
/** the axis names of a cell: t (or t1 … tk), then x, y, z, w */
export const axesOf = (k, d) => (k === 1 ? ['t'] : Array.from({ length: k }, (_, i) => `t${i + 1}`)).concat(SPACE.slice(0, d));
/** the role of a label from its bits (k time generators first) */
export function roleOf(m, k, n) {
  const g = popcount(m), t = popcount(m & ((1 << k) - 1));
  if (g === 0) return 'scalar';
  if (g === 1) return t ? 'rho' : 'J';
  if (g === 2) return t === 1 ? 'E' : t === 2 ? 'T' : 'B';
  if (g === 3) return t ? 'Faraday' : 'divB';
  return g === n ? 'pseudo' : 'other';
}

/** the terms of a stored expression "Ex γ0γ1 + Ey γ0γ2 − Bz γ1γ2" (conventions.F or .J): [{ sign, label, mask }] */
export function parseTerms(expr) {
  const out = [];
  const chunks = String(expr).trim().split(/\s+([+−])\s+/);
  let sg = 1;
  chunks.forEach((c, i) => {
    if (i % 2 === 1) { sg = c === '−' ? -1 : 1; return; }
    let s = sg, body = c;
    if (i === 0 && body.startsWith('− ')) { s = -1; body = body.slice(2); }
    const [label, word] = body.split(/\s+/);
    const mask = [...String(word).matchAll(/γ(\d)/g)].reduce((m, x) => m | (1 << Number(x[1])), 0);
    out.push({ sign: s, label, mask });
  });
  return out;
}

/** the names of the equation whose target is the label m, as maxwell_selfcheck.py names it (phys_standard for one time, cov_spec otherwise): [id, name] */
function equationName(m, ctx) {
  const { k, d, n, axes, kind, fieldName } = ctx, idx = indicesOf(m, n), nt = idx.filter(x => x < k).length;
  if (idx.length === 1) {
    const b = idx[0];
    if (b < k) return k === 1 ? ['gauss', 'Gauss'] : [`gauss_${b + 1}`, `Gauss ${axes[b]}`];
    return [`amp_${axes[b]}`, `Ampère ${axes[b]}`];
  }
  if (kind === 'physical') {
    if (nt) { const key = fieldName.get(m & ~1).slice(2); return [`far_${key}`, `Faraday ${key}`]; }
    return d === 3 ? ['divB', 'no monopole'] : [`bian_${idx.join('')}`, `Bianchi ${idx.join('')}`];
  }
  const word = idx.map(x => axes[x]);
  return [`d_${word.join('')}`, `${nt === 0 ? 'no monopole' : nt === 1 ? 'Faraday' : 'dF'} ${word.join(' ')}`];
}
/** the order in which the script prints the terms of a trivector equation (the axes of its terms): by axis, except Faraday's law in one time and three space
 *  dimensions, printed as ∂t B_k + ∂_i E_j − ∂_j E_i with (i, j, k) cyclic (phys_standard: B_x lives on (y, z), B_y on (z, x), B_z on (x, y)); a vector
 *  equation is always printed by axis */
function wedgeOrder(m, ctx) {
  const { k, d, n, kind, fieldName } = ctx, idx = indicesOf(m, n);
  if (kind !== 'physical' || d !== 3 || idx[0] >= k) return idx;
  const c = SPACE.indexOf(fieldName.get(m & ~1).slice(2));
  return [0, 1 + ((c + 1) % 3), 1 + ((c + 2) % 3)];
}
/** the label of a trivector, as the script labels it: I (n = 3, one time), Farz, Far12, ∇·B, ∇B123 (one time); F123, F12x, Fxyz (more times) */
function trivectorLabel(m, ctx, id) {
  const { k, d, n, kind } = ctx, idx = indicesOf(m, n), nt = idx.filter(x => x < k).length;
  if (kind === 'physical') return nt ? (n === 3 ? 'I' : 'Far' + id.slice(4)) : (d === 3 ? '∇·B' : '∇B' + id.slice(5));
  return nt === 0 && k === 1 && d === 3 ? '∇·B' : 'F' + idx.map(x => (x < k ? String(x + 1) : SPACE[x - k])).join('');
}

/**
 * The recomputation of one cell from its generators and its stored convention.
 * input = { k, d, kind, conventions: { F, J, field_order, signs, grad, found } }; opts.sign is the kernel's sign (a mutant may pass another), opts.eps the cell.
 * Returns { k, d, n, kind, eps, axes, blades, incidences, equations, counts, components } (the shapes of maxwell.json, plus the parts the figures draw).
 */
export function recomputeCell(input, opts = {}) {
  const { k, d, kind, conventions } = input, n = k + d, N = 1 << n;
  const sgn = opts.sign || kernelSign, eps = opts.eps || cell(k, d), axes = axesOf(k, d);
  const F = parseTerms(conventions.F), J = parseTerms(conventions.J), order = conventions.field_order, signs = conventions.signs;
  const fieldName = new Map(F.map((t, i) => [t.mask, order[i]]));
  const ctx = { k, d, n, axes, kind, fieldName };
  // the moves: each field component along each axis (the kernel's sign of e_a e_S times the component's stored sign)
  const incidences = [];
  F.forEach((t, i) => {
    for (let a = 0; a < n; a++) {
      const s = sgn(1 << a, t.mask, eps) * signs[i], target = t.mask ^ (1 << a);
      incidences.push({ axis: a, axis_name: axes[a], field: order[i], op: popcount(target) === 1 ? 'contract' : 'wedge', sign: s, source: t.mask, target, term: (s > 0 ? '+' : '−') + '∂' + axes[a] + t.label });
    }
  });
  const labelOf = new Map([[0, '1'], ...F.map(t => [t.mask, t.label]), ...J.map(t => [t.mask, t.label])]);
  const sourceOf = new Map(J.map((t, i) => [t.mask, { ...t, sign: signs[F.length + i], field: order[F.length + i] }]));
  // the equations: one per vector and trivector target, in the order of the targets
  const equations = [];
  for (let m = 0; m < N; m++) {
    const g = popcount(m); if (g !== 1 && g !== 3) continue;
    const ins = incidences.filter(x => x.target === m), op = g === 1 ? 'contract' : 'wedge';
    const printed = op === 'contract' ? [...ins].sort((x, y) => x.axis - y.axis) : wedgeOrder(m, ctx).map(a => ins.find(x => x.axis === a));
    const lead = op === 'contract' ? 1 : printed[0].sign;   // δF = J as the algebra gives it; dF = 0 written with its first term positive
    const lhs = printed.map(x => ({ axis: x.axis, axisName: x.axis_name, source: x.source, field: x.field, label: labelOf.get(x.source), role: roleOf(x.source, k, n), sign: x.sign, coef: x.sign * lead, term: x.term }));
    const src = op === 'contract' ? sourceOf.get(m) : null;
    const rhs = src ? { N: m, label: src.label, role: roleOf(m, k, n), sign: src.sign, field: src.field, text: (src.sign > 0 ? '' : '−') + src.label } : null;
    const eq = lhs.map((x, i) => (i ? (x.coef > 0 ? ' + ' : ' − ') : (x.coef > 0 ? '' : '−')) + '∂' + x.axisName + ' ' + x.label).join('') + ' = ' + (rhs ? rhs.text : '0');
    const [id, name] = equationName(m, ctx);
    if (g === 3) labelOf.set(m, trivectorLabel(m, ctx, id));
    equations.push({ id, name, eq, op, target: m, terms: ins.map(x => x.term), lhs, rhs });
  }
  const blades = Array.from({ length: N }, (_, m) => {
    const role = roleOf(m, k, n), S = indicesOf(m, n);
    return { N: m, S, grade: S.length, name: m ? 'γ' + S.join('γ') : '1', role, label: labelOf.has(m) ? labelOf.get(m) : role === 'pseudo' ? 'I' : '·', square: sgn(m, m, eps) };
  });
  const field = F.map(t => t.mask), sources = J.map(t => t.mask);
  const counts = { E: field.filter(m => blades[m].role === 'E').length, T: field.filter(m => blades[m].role === 'T').length, B: field.filter(m => blades[m].role === 'B').length };
  return { k, d, n, kind, eps, axes, blades, incidences, equations, counts, components: { field, sources } };
}

// ---------------------------------------------------------------- interface 23
const MEMO = new Map();
/** the 15 stored cells, as "k,d" keys in the stored order */
export const cellsAvailable = () => MAXWELL_CELLS.filter(key => MAXWELL && MAXWELL.cells && MAXWELL.cells[key]);
/**
 * cellPhysics(k, d) → { k, d, n, kind, eps, axes, blades: [{ N, S, grade, name, role, label, square }], equations: [{ id, name, eq, op, target, terms, lhs, rhs }],
 * incidences, conventions, counts, components: { field: [N] (F's components in the stored order), sources: [N] (J's) }, checks, mirror, algebra, symbol,
 * covariantAgrees (one time only) } — or null for a cell that is not stored. The stored blocks are returned as they are; the rest is recomputeCell's.
 */
export function cellPhysics(k, d) {
  const key = keyOf(k, d);
  if (MEMO.has(key)) return MEMO.get(key);
  const S = MAXWELL && MAXWELL.cells ? MAXWELL.cells[key] : null;
  if (!S) return null;
  const R = recomputeCell({ k, d, kind: S.kind, conventions: S.conventions });
  const out = { ...R, conventions: S.conventions, checks: S.checks, mirror: S.mirror, algebra: S.algebra, symbol: S.symbol, storedCounts: S.counts, covariantAgrees: S.covariant_agrees === undefined ? null : S.covariant_agrees };
  out.byTarget = new Map(out.equations.map(e => [e.target, e]));
  MEMO.set(key, out);
  return out;
}

/**
 * equationsOf(k, d, N) → the equations the label N takes part in, in the stored order of the equations, each { id, name, eq, op, target, terms, as, sign, coef,
 * term, axis, axisName }: a field component (grade 2): the n equations its moves feed (as 'term'; sign = the stored sign of its term, coef = the sign the
 * printed equation gives it); a source (grade 1, ρ or J): the equation whose right side it is (as 'source'; sign = its stored sign in J); a trivector: its
 * own equation (as 'target'); [] for any other label.
 */
export function equationsOf(k, d, N) {
  const C = cellPhysics(k, d), b = C && C.blades[N];
  if (!b) return [];
  const base = e => ({ id: e.id, name: e.name, eq: e.eq, op: e.op, target: e.target, terms: [...e.terms] });
  if (b.grade === 2) return C.incidences.filter(x => x.source === N).sort((x, y) => x.target - y.target).map(x => { const e = C.byTarget.get(x.target), t = e.lhs.find(y => y.source === N); return { ...base(e), as: 'term', sign: x.sign, coef: t.coef, term: x.term, axis: x.axis, axisName: x.axis_name }; });
  const e = C.byTarget.get(N);
  if (!e) return [];
  if (b.grade === 1) return [{ ...base(e), as: 'source', sign: e.rhs.sign, coef: e.rhs.sign, term: e.rhs.text, axis: null, axisName: null }];
  return [{ ...base(e), as: 'target', sign: 1, coef: 1, term: null, axis: null, axisName: null }];
}

/** the words of a role, as v15 named them (MaxwellSection: "electric E", "magnetic B", "time–time T", "charge densities ρ", "currents J", "Faraday’s law",
 *  "no magnetic monopoles"; to the learner "time–time" pieces and "Faraday-like" rules): research or learner; '' for the scalar, the pseudoscalar and the rest */
const ROLE_WORDS = {
  research: { E: 'electric field', B: 'magnetic field', T: 'time–time component', rho: 'charge density', J: 'current', Faraday: 'Faraday’s law', divB: 'no magnetic monopoles' },
  learner: { E: 'electric field', B: 'magnetic field', T: 'time–time piece', rho: 'charge', J: 'current', Faraday: 'Faraday-like rule', divB: 'no magnetic monopoles' },
};
export const roleName = (role, level = 'research') => ROLE_WORDS[level === 'learner' ? 'learner' : 'research'][role] || '';
/** the name of an equation at a level: as stored; at learner level "dF" reads "Faraday-like", as v15 read it to the learner */
export const nameAt = (e, level = 'research') => (level === 'learner' ? e.name.replace(/^dF /, 'Faraday-like ') : e.name);

/**
 * The stored equation as tokens, to be typeset term by term: { lhs: [{ sign: '' | '+' | '−', axis, label, text }], rhs: { sign: '' | '−', label, text } }.
 * eqText(eqTokens(e.eq)) === e.eq for every stored equation (tests/maxwell.test.mjs).
 */
export function eqTokens(eq) {
  const [l, r] = String(eq).split(' = ');
  const lhs = [];
  const parts = l.split(/ ([+−]) /);
  parts.forEach((p, i) => {
    if (i % 2 === 1) return;
    let sg = i === 0 ? '' : parts[i - 1], body = p;
    if (i === 0 && body.startsWith('−')) { sg = '−'; body = body.slice(1); }
    const [d, label] = body.split(' ');
    lhs.push({ sign: sg, axis: d.slice(1), label, text: body });
  });
  const rs = r.startsWith('−') ? '−' : '';
  return { lhs, rhs: { sign: rs, label: rs ? r.slice(1) : r, text: r } };
}
export const eqText = T => T.lhs.map((x, i) => (i ? ` ${x.sign} ` : x.sign) + x.text).join('') + ' = ' + T.rhs.text;
/** TeX of a label or an axis: Ex → E_{x}, E1x → E_{1x}, T12 → T_{12}, ρ1 → \rho_{1}, t2 → t_{2}; B, ρ, 0 stay */
export function texName(s) {
  const m = /^(ρ|[A-Za-z0-9])(.*)$/.exec(String(s));
  if (!m) return String(s);
  const head = m[1] === 'ρ' ? '\\rho' : m[1];
  return m[2] ? `${head}_{${m[2]}}` : head;
}
/** TeX of one token of eqTokens: a term ∂a X, or the right side */
export const texTerm = x => `\\partial_{${texName(x.axis)}} ${texName(x.label)}`;
export const texRhs = r => (r.sign ? '-' : '') + texName(r.label);

/**
 * The words of an equation at learner level, read term by term from the stored equation (no other claim): "the change of the electric field Ex along x, plus
 * the change of Ey along y, … equals the charge ρ" — a role's words are said once for a run of terms of that role; signs read plus / minus; the right side is
 * the source with its sign, or zero. equationWordParts gives the pieces [{ sep, role, source, text }] (a figure marks each with its role); equationWords the
 * sentence they make.
 */
export function equationWordParts(e, level = 'learner') {
  let prev = null;
  const parts = e.lhs.map((x, i) => {
    const sep = i ? (x.coef > 0 ? ', plus ' : ', minus ') : (x.coef > 0 ? '' : 'minus ');
    const who = x.role === prev ? x.label : `the ${roleName(x.role, level)} ${x.label}`;
    prev = x.role;
    return { sep, role: x.role, source: x.source, text: `the change of ${who} along ${x.axisName}` };
  });
  parts.push(e.rhs ? { sep: `, equals ${e.rhs.sign > 0 ? '' : 'minus '}`, role: e.rhs.role, source: e.rhs.N, text: `the ${roleName(e.rhs.role, level)} ${e.rhs.label}` } : { sep: ', equals ', role: null, source: null, text: 'zero' });
  return parts;
}
export const equationWords = (e, level = 'learner') => equationWordParts(e, level).map(p => p.sep + p.text).join('');

/** the algebra of a cell as v15 printed it: M2(ℍ), M4(ℝ) ⊕ M4(ℝ) */
export function algebraText(al) {
  const f = { R: 'ℝ', R2: 'ℝ', C: 'ℂ', H: 'ℍ', H2: 'ℍ' }[al.type] || al.type, one = `M${al.matrix_size}(${f})`;
  return /2$/.test(al.type) ? `${one} ⊕ ${one}` : one;
}

/** the two stored ladders (space: Cl(1, d), d = 0 … 8; time: Cl(k, 1), k = 1 … 9) and the equation counts of the 15 cells (vectors + trivectors) */
export function ladders() {
  const cells = cellsAvailable().map(key => { const [k, d] = key.split(',').map(Number), C = cellPhysics(k, d), v = C.equations.filter(e => e.op === 'contract').length; return { k, d, n: C.n, vector: v, trivector: C.equations.length - v, total: C.equations.length, F: C.components.field.length }; });
  return { space: MAXWELL ? MAXWELL.ladder : [], time: MAXWELL ? MAXWELL.time_ladder : [], cells };
}
