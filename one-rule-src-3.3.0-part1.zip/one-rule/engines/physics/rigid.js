// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/rigid.js — the exact side of step 16, the rigid body (owner P11; docs/PHYSICS_AUDIT.md §2.16 RB1–RB5). The numbers the figures rigid-segment,
// rigid-square and rigid-frame-table print are recomputed here on the kernel: every product and every sign is engines/bitrule.js (mul, sign, reorderSign,
// popcount). What this module adds is only arithmetic: exact rationals (BigInt), truncated power series in t over them (the coefficient ring handed to the
// kernel's mul through its num adapter), and counts of masks. The authority is checks/selfcheck/pgadyn_selfcheck.py (exact rationals); its stored results are
// shipped as content/stored_p11.json (D34) and tests/physics/p11.test.mjs ties each number printed to them.
//   exactPGA(n)                     R(n,0,1) with series coefficients: generator 0 is the null e₀, generators 1 … n square to +1 (the cell of pgaEngine.js)
//   segmentSeries({ k, a, x0, g, pb }) the exact series through t¹⁰ of the hooked vertex of a segment (row B3: k = 4, anchor 1/2, released at rest from 2)
//   closedSeries({ k, a, x0, g })   the Taylor series of the closed form a − g/k + (x0 − a + g/k)·cos(√k t) (cosh for k < 0, the parabola for k = 0)
//   kindOfI(k)                      the matrix [[0, 1], [−k, 0]] of the pair (x, b), its square −k·I and the kind of i it is (row B4)
//   squareSeries({ b01, b02, b12 }) the free square in R(2,0,1): the series of the body velocity and of the world momentum M A(B) M̃ (row C1)
//   frameCounts(n), frameClosed(n)  the counts of the frame table enumerated from the masks of R(n,0,1), and their closed forms (rows A7, G5)
//   normSupport(n)                  the components of X X̃ for a generic even X, by kernel products (rows A4, A7)
//   vertexBlade(v), vertexLabel(n, v, lens)   the motor coefficient on vertex v of the n-cube and its name in a lens (row A1)
//   BODY, labelledBody(n)           (A39, owner Q1) v15's LabelledBody on engines/pgaEngine.js (its sign table is the kernel's): the posed n-cube, n = 1 … 4,
//                                   its frame (n + 1 sandwiches, 2ⁿ − 1 additions) against the direct vertices, the deepest vertex under the contact plane read from
//                                   n sign bits (deepestBits) and by the scan (deepestScan), the outline as the zonogon of the n projected edges against the hull of
//                                   the 2ⁿ projected vertices (rows G1, G3, G4; the arrangement is our reading, RIG-003)
import { mul, sign, reorderSign, popcount, label } from '../bitrule.js';
import { alg, frame, verticesFrame, verticesDirect, deepestScan, deepestBits, project, zonogon, hull } from '../pgaEngine.js';

// ---------------------------------------------------------------- exact rationals
const absB = x => (x < 0n ? -x : x);
function gcd(a, b) { a = absB(a); b = absB(b); while (b) { const t = a % b; a = b; b = t; } return a; }
/** the rational n/d in lowest terms, the denominator positive */
export function Q(n, d = 1n) {
  let N = BigInt(n), D = BigInt(d);
  if (D === 0n) throw new Error('Q: a zero denominator');
  const s = D < 0n ? -1n : 1n; N *= s; D *= s;
  const g = gcd(N, D) || 1n;
  return { n: N / g, d: D / g };
}
export const Q0 = Q(0), Q1 = Q(1);
/** "a/b" (or "a") as a rational */
export const qParse = s => { if (s && typeof s === 'object' && 'n' in s) return s; const [a, b] = String(s).trim().split('/'); return Q(BigInt(a), BigInt(b ?? 1)); };
export const qAdd = (x, y) => Q(x.n * y.d + y.n * x.d, x.d * y.d);
export const qSub = (x, y) => Q(x.n * y.d - y.n * x.d, x.d * y.d);
export const qMul = (x, y) => Q(x.n * y.n, x.d * y.d);
export const qDiv = (x, y) => Q(x.n * y.d, x.d * y.n);
export const qIsZero = x => x.n === 0n;
export const qEq = (x, y) => x.n === y.n && x.d === y.d;
export const qStr = x => (x.d === 1n ? String(x.n) : `${x.n}/${x.d}`);
export const qNum = x => Number(x.n) / Number(x.d);
/** a control value in tenths (the sliders of v15: x₀ = value / 10, g = value / 10) as an exact rational */
export const qTenths = v => Q(BigInt(Math.round(Number(v) || 0)), 10n);

// ---------------------------------------------------------------- truncated power series in t: the coefficient ring of the exact time integration
export const K = 10;                                   // the order of the series, as pgadyn_selfcheck.py (K = 10)
const zeros = () => Array.from({ length: K + 1 }, () => Q0);
/** the constant series c */
export const ser = c => { const s = zeros(); s[0] = qParse(c); return s; };
/** the num adapter of engines/bitrule.js mul for series coefficients (the kernel passes its sign, ±1, to scale) */
export const SER = {
  add: (a, b) => a.map((x, i) => qAdd(x, b[i])),
  mul: (a, b) => {
    const r = zeros();
    for (let i = 0; i <= K; i++) { if (qIsZero(a[i])) continue; for (let j = 0; i + j <= K; j++) if (!qIsZero(b[j])) r[i + j] = qAdd(r[i + j], qMul(a[i], b[j])); }
    return r;
  },
  scale: (s, a) => (s === 1 ? a : a.map(x => qMul(Q(s), x))),
  zero: null,
  isZero: a => a.every(qIsZero),
};
const sScale = (a, q) => a.map(x => qMul(x, q));
const sInteg = a => [Q0, ...a.slice(0, K).map((x, i) => qDiv(x, Q(i + 1)))];
/** a series as the strings pgadyn.json stores ("2", "-2/15") */
export const serStr = a => a.map(qStr);

// ---------------------------------------------------------------- multivectors with series coefficients (Maps mask → series), every product by the kernel
function mvAdd(x, y) {
  const out = new Map(x);
  for (const [k, v] of y) { const w = out.has(k) ? SER.add(out.get(k), v) : v; if (SER.isZero(w)) out.delete(k); else out.set(k, w); }
  return out;
}
function mvScale(x, q) { const out = new Map(); if (qIsZero(q)) return out; for (const [k, v] of x) out.set(k, sScale(v, q)); return out; }
/** the cell of R(n,0,1) as a sign vector for the kernel: the null e₀, then n generators of square +1 */
export const pgaEps = n => [0, ...Array(n).fill(1)];

/** R(n,0,1) over the series: the operations of pgadyn_selfcheck.py (Alg, dM, dB, gravity, hooke, picard), with the kernel's products and signs */
export function exactPGA(n) {
  const eps = pgaEps(n), full = (1 << (n + 1)) - 1;
  const gp = (x, y) => mul(x, y, eps, SER);
  const sgn = m => sign(m, full ^ m, eps);                                     // e_m e_{~m} = sgn(m)·I: two disjoint blades, no square enters
  const rev = x => { const out = new Map(); for (const [m, v] of x) out.set(m, SER.scale(reorderSign(m, m), v)); return out; };   // (−1)^{k(k−1)/2}: the kernel's reordering of a blade against itself
  const dual = x => { const out = new Map(); for (const [m, v] of x) out.set(full ^ m, SER.scale(sgn(m), v)); return out; };
  const undual = x => { const out = new Map(); for (const [k, v] of x) out.set(full ^ k, SER.scale(sgn(full ^ k), v)); return out; };
  const wedge = (x, y) => {
    let out = new Map();
    for (const [a, va] of x) for (const [b, vb] of y) { if (a & b) continue; out = mvAdd(out, new Map([[a ^ b, SER.scale(sign(a, b, eps), SER.mul(va, vb))]])); }
    return out;
  };
  const join = (a, b) => undual(wedge(dual(a), dual(b)));
  const blade = (m, c) => new Map([[m, Array.isArray(c) ? c : ser(c)]]);
  const point = x => { let v = blade(1, Q1); x.forEach((c, i) => { const q = qParse(c); if (!qIsZero(q)) v = mvAdd(v, blade(2 << i, q)); }); return dual(v); };   // the dual of e₀ + x·e
  const coord = (P, i) => { const v = P.get(full ^ (1 << i)); return v ? SER.scale(sgn(1 << i), v) : zeros(); };
  const trans = t => { let T = blade(0, Q1); t.forEach((c, i) => { const q = qParse(c); if (!qIsZero(q)) T = mvAdd(T, blade(1 | (2 << i), qMul(q, Q(-1, 2)))); }); return T; };   // 1 − t·e₀ᵢ/2
  const sand = (M, X) => gp(gp(M, X), rev(M));
  const Amap = (B, c) => { const out = new Map(); for (const [m, v] of B) out.set(full ^ m, SER.scale(sgn(m), sScale(v, c[m]))); return out; };
  const Ainv = (X, c) => { const out = new Map(); for (const [k, v] of X) { const m = full ^ k; out.set(m, SER.scale(sgn(m), sScale(v, qDiv(Q1, c[m])))); } return out; };
  const dM = (M, B) => mvScale(gp(M, B), Q(-1, 2));
  const dB = (B, c, F = null) => { const AB = Amap(B, c); let X = mvScale(mvAdd(gp(B, AB), mvScale(gp(AB, B), Q(-1))), Q(1, 2)); if (F) X = mvAdd(X, F); return Ainv(X, c); };
  const gravity = (M, g, j, m = Q1) => mvScale(dual(gp(gp(rev(M), blade(1 | (1 << j), qMul(qParse(g), Q(-1)))), M)), qParse(m));   // m (M̃ (−g e₀ⱼ) M)^dual
  const hooke = (M, k, pb, aw) => mvScale(join(pb, gp(gp(rev(M), aw), M)), qParse(k));                                                  // k ((M̃ a_w M) ∧ p_b)
  /** the exact Taylor series of S′ = field(S) through t^K: K Picard iterations (pgadyn_selfcheck.py picard) */
  const picard = (S0, field) => {
    let S = S0;
    for (let it = 0; it < K; it++) {
      const d = field(S);
      S = S0.map((x, i) => { let out = new Map(x); for (const [m, v] of d[i]) { const w = out.has(m) ? SER.add(out.get(m), sInteg(v)) : sInteg(v); if (SER.isZero(w)) out.delete(m); else out.set(m, w); } return out; });
    }
    return S;
  };
  return { n, eps, full, gp, sgn, rev, dual, undual, wedge, join, blade, point, coord, trans, sand, Amap, Ainv, dM, dB, gravity, hooke, picard, add: mvAdd, scale: mvScale };
}

// ---------------------------------------------------------------- rung 1: the segment (rows B2–B4)
/**
 * The exact series of the hooked vertex of a segment in R(1,0,1), released at rest: the vertex at body coordinate pb starts at x0, a Hooke spring of stiffness k
 * pulls it toward the anchor a (k < 0: the reversed spring, k = 0: none), gravity g acts along −e₁ on the unit mass at the body origin, unit inertia.
 * Row B3 is { k: 4, a: '1/2', x0: '2', g: '0', pb: '1/2' }; the figure hooks the body origin (pb = 0), the same motion of the hooked point.
 * Returns { series, weight } (the coordinate and the weight of the world point; the weight is the constant 1 exactly).
 */
export function segmentSeries({ k = 4, a = '1/2', x0 = '2', g = '0', pb = '0' } = {}) {
  const A = exactPGA(1), kq = qParse(String(k)), aq = qParse(a), gq = qParse(g), pbq = qParse(pb), c = { 3: Q1 };
  const P = A.point([pbq]), W = A.point([aq]);
  const M0 = A.trans([qSub(qParse(x0), pbq)]), B0 = new Map();
  const force = M => { let F = new Map(); if (!qIsZero(gq)) F = A.add(F, A.gravity(M, gq, 1)); if (!qIsZero(kq)) F = A.add(F, A.hooke(M, kq, P, W)); return F.size ? F : null; };
  const S = A.picard([M0, B0], ([M, B]) => [A.dM(M, B), A.dB(B, c, force(M))]);
  const X = A.sand(S[0], P);
  return { series: A.coord(X, 1), weight: A.coord(X, 0), motor: S[0] };
}
const isqrt = v => { if (v < 0) return null; const r = Math.round(Math.sqrt(v)); return r * r === v ? r : null; };
const fact = j => { let f = 1n; for (let i = 2n; i <= BigInt(j); i++) f *= i; return f; };
/** the Taylor series of the closed form of the same motion (the standard route): x = e + (x0 − e) C(t), e = a − g/k, C = cos(√k t) for k > 0 and cosh(√−k t)
 *  for k < 0 (√|k| an integer, as the controls give: k = ±4); x = x0 − g t²/2 with no spring. null when √|k| is not an integer. */
export function closedSeries({ k = 4, a = '1/2', x0 = '2', g = '0' } = {}) {
  const x = qParse(x0), gq = qParse(g), aq = qParse(a), out = zeros();
  if (Number(k) === 0) { out[0] = x; out[2] = qMul(gq, Q(-1, 2)); return out; }
  const w = isqrt(Math.abs(Number(k)));
  if (w == null) return null;
  const e = qSub(aq, qDiv(gq, Q(k))), amp = qSub(x, e);
  for (let j = 0; j <= K; j += 2) { const alt = Number(k) > 0 && (j / 2) % 2 === 1 ? -1n : 1n; out[j] = qMul(amp, Q(alt * BigInt(w) ** BigInt(j), fact(j))); }
  out[0] = qAdd(out[0], e);
  return out;
}
/** the pair (x, b) of the segment with a spring k: its matrix [[0, 1], [−k, 0]], the square of it and the kind of i (row B4): −k·I with k > 0 is a rotation
 *  (the oscillator, cos), with k < 0 a boost (cosh), and 0 with no spring the null i (free motion) */
export function kindOfI(k) {
  const m = [[0, 1], [-k, 0]];
  const sq = [0, 1].map(i => [0, 1].map(j => m[i][0] * m[0][j] + m[i][1] * m[1][j]));
  return { matrix: m, square: sq, scalar: sq[0][0], kind: k > 0 ? 'rotation' : k < 0 ? 'boost' : 'null' };
}

// ---------------------------------------------------------------- rung 2: the square (row C1)
/** the free square in R(2,0,1) from the motor of row C1 (T(1/3, −1/2) times the rotor 3/5 + 4/5 e₁₂) with unit inertia: the exact series of the velocity
 *  components b₀₁, b₀₂, b₁₂ and of the world momentum M A(B) M̃. turns: (b₀₁ + i b₀₂)(t) = (b₀₁ + i b₀₂)(0)·e^(−i b₁₂ t), term by term. */
export function squareSeries({ b01 = '1', b02 = '2', b12 = '2', t = ['1/3', '-1/2'] } = {}) {
  const A = exactPGA(2), c = { 3: Q1, 5: Q1, 6: Q1 }, w = qParse(b12), z0 = qParse(b01), z1 = qParse(b02);
  const R = A.add(A.blade(0, Q(3, 5)), A.blade(6, Q(4, 5)));
  const M0 = A.gp(A.trans(t), R);
  let B0 = new Map(); for (const [m, v] of [[3, z0], [5, z1], [6, w]]) if (!qIsZero(v)) B0 = A.add(B0, A.blade(m, v));
  const S = A.picard([M0, B0], ([M, B]) => [A.dM(M, B), A.dB(B, c)]);
  const get = (X, m) => X.get(m) || zeros();
  const B = S[1], W = A.sand(S[0], A.Amap(B, c));
  const cs = zeros(), sn = zeros();
  for (let j = 0; j <= K; j++) { const term = qDiv(Q(BigInt(w.n) ** BigInt(j), BigInt(w.d) ** BigInt(j)), Q(fact(j))); const alt = Math.floor(j / 2) % 2 === 1 ? Q(-1) : Q1; if (j % 2 === 0) cs[j] = qMul(alt, term); else sn[j] = qMul(alt, term); }
  const want01 = cs.map((x, j) => qAdd(qMul(z0, x), qMul(z1, sn[j]))), want02 = cs.map((x, j) => qSub(qMul(z1, x), qMul(z0, sn[j])));
  const same = (a, b) => a.every((x, j) => qEq(x, b[j]));
  const constant = [...W.values()].every(s => s.slice(1).every(qIsZero));
  return { b01: get(B, 3), b02: get(B, 5), b12: get(B, 6), momentum: W, turns: same(get(B, 3), want01) && same(get(B, 5), want02), constant, rate: w, rateConstant: same(get(B, 6), ser(w)) };
}

// ---------------------------------------------------------------- the frame table (rows A7, G5): the counts enumerated from the masks, and their closed forms
const binom = (a, b) => { if (b < 0 || b > a) return 0; let r = 1; for (let i = 1; i <= b; i++) r = r * (a - b + i) / i; return r; };
/** every count of the frame table of rung n, enumerated from the 2^(n+1) masks of R(n,0,1) by the kernel's popcount (the grades), as frame_table() of
 *  pgadyn_selfcheck.py: the equations of M M̃ = 1 are its components, of grade 0 mod 4 (an even element times its reverse) */
export function frameCounts(n) {
  const N = 1 << (n + 1), V = 1 << n, grades = Array.from({ length: N }, (_, m) => popcount(m));
  let edges = 0; for (let u = 0; u < V; u++) for (let v = u + 1; v < V; v++) if (popcount(u ^ v) === 1) edges++;
  const motor = grades.filter(g => g % 2 === 0).length, biv = grades.filter(g => g === 2).length, force = grades.filter(g => g === n - 1).length;
  const norm = grades.filter(g => g % 4 === 0).length, group = n * (n + 1) / 2;
  return {
    vertices: V, edges, motor_coefficients: motor, bivector_components: biv, group_dimension: group, force_components: force, moments: biv,
    sandwiches_direct: V, sandwiches_frame: n + 1, additions: V - 1, integration_numbers: motor + biv, solution_numbers: n * (n + 1),
    outline_vertices: n >= 2 ? 2 * n : 2, norm_equations: norm, norm_ok: norm === V - group, needed: V - group,
  };
}
/** the closed forms of the same counts (the standard route: the formulas the rows of v15's table name) */
export function frameClosed(n) {
  const V = 2 ** n, G = n * (n + 1) / 2;
  let norm = 0; for (let k = 0; k <= n + 1; k += 4) norm += binom(n + 1, k);
  return {
    vertices: V, edges: n * 2 ** (n - 1), motor_coefficients: V, bivector_components: binom(n + 1, 2), group_dimension: G, force_components: binom(n + 1, n - 1),
    moments: binom(n + 1, 2), sandwiches_direct: V, sandwiches_frame: n + 1, additions: V - 1, integration_numbers: V + G, solution_numbers: n * (n + 1),
    outline_vertices: n >= 2 ? 2 * n : 2, norm_equations: norm, norm_ok: norm === V - G, needed: V - G,
  };
}
/** the components of X X̃ for a generic even X of R(n,0,1) (fixed integer coefficients, exact in doubles), by the kernel's mul: { grades, components } —
 *  grade 0 and grade 4 (8 …) only, 1 + C(n+1, 4) of them for n ≤ 6 (rows A4, A7) */
export function normSupport(n) {
  const eps = pgaEps(n), X = new Map();
  let s = 12345;
  for (let m = 0; m < 1 << (n + 1); m++) if (popcount(m) % 2 === 0) { s = (s * 1103515245 + 12345) % 2147483648; X.set(m, (s % 97) - 48 || 49); }
  const Xr = new Map([...X].map(([m, v]) => [m, reorderSign(m, m) * v]));
  const P = mul(X, Xr, eps);
  const grades = [...new Set([...P.keys()].map(popcount))].sort((a, b) => a - b);
  return { grades, components: P.size };
}

// ---------------------------------------------------------------- the labels (row A1): the motor coefficient on a vertex, and its name in a lens
/** the even blade on vertex v of the n-cube: its unit bits are the bits of v (shifted past e₀), and it carries e₀ exactly when v has odd weight */
export const vertexBlade = v => (v << 1) | (popcount(v) & 1);
const SUBS = '₀₁₂₃₄₅₆₇₈₉';
const gensOf = (m, n) => Array.from({ length: n + 1 }, (_, i) => i).filter(i => (m >> i) % 2 === 1);
/** the name of the coefficient on vertex v in a lens: the blade, generator 0 the null e₀ (null, 'clifford', 'pga'); the vertex bits ('cube', 'bits'); the blade's
 *  generators as a set ('simplex', 'set'); the even mask of n + 1 bits, a corner of the (n + 1)-demicube ('demicube'); the product of primes, the k-th generator
 *  the k-th prime ('prime', 'primes'). The printing changes, the coefficient does not. */
export function vertexLabel(n, v, lens = null) {
  const m = vertexBlade(v), gens = gensOf(m, n);
  switch (lens) {
    case 'cube': case 'bits': return label(v, 'bits', Array(n).fill(1));
    case 'simplex': case 'set': return `{${gens.join(',')}}`;
    case 'demicube': return label(m, 'bits', pgaEps(n));
    case 'prime': case 'primes': return label(m, 'primes');
    default: return gens.length ? 'e' + gens.map(i => SUBS[i]).join('') : '1';
  }
}

// ---------------------------------------------------------------- the labelled body (A39: RB4, rows G1, G3, G4; the arrangement is our reading, RIG-003)
/** the body v15's LabelledBody opens with (RigidWidgets.jsx): the turns 25°, 35°, 30° in the planes e₁e₂, e₂e₃, e₃e₄ (as many as the rung has), the edge
 *  lengths 1.3, 1, 0.8, 0.6, the contact plane ν·x + d = 0 with ν = (cos 40°, sin 40°, 0.35, −0.25) cut to the rung (along e₁ for the segment) and d = 0.05;
 *  the rungs of the body are those pgadyn_selfcheck.py stores labels for (bit_labels, n = 1 … 4) */
export const BODY = { turns: [25, 35, 30], sizes: [1.3, 1.0, 0.8, 0.6], plane: 40, d: 0.05, rungs: [1, 2, 3, 4] };
/**
 * labelledBody(n) → the labelled body of rung n (1 … 4) on engines/pgaEngine.js, every product with the kernel's signs: { n, sizes, frame: { c, f } (the centre and
 * the n transported edges), vertices (by the frame: n + 1 sandwiches and 2ⁿ − 1 additions), direct (2ⁿ sandwiches), err (the largest difference), counts
 * { sandwichesFrame, additions, sandwichesDirect, edges }, nu, d, dist (ν·x + d per vertex), deepBits (the label read from the n sign bits), deepScan (the vertex
 * found by the scan of the 2ⁿ), projected (the vertices on the screen of pgaEngine.project), outline (the zonogon of the n projected edges: its vertex labels,
 * counterclockwise; [] for the segment), hull (the convex hull of the projected vertices), flips (the bit that changes at each step of the outline) } —
 * null for a rung the body is not stored at.
 */
export function labelledBody(n) {
  if (!BODY.rungs.includes(n)) return null;
  const A = alg(n), s = BODY.sizes.slice(0, n), deg = Math.PI / 180, planes = [];
  for (let i = 1; i < n; i++) planes.push([i, i + 1, BODY.turns[i - 1] * deg]);
  const M = A.motor(new Array(n).fill(0), planes), fr = frame(A, M, s), V = verticesFrame(A, M, s, fr), D = verticesDirect(A, M, s);
  const err = Math.max(...V.map((p, i) => Math.max(...p.map((x, k) => Math.abs(x - D[i][k])))));
  const a = BODY.plane * deg, nu = n === 1 ? [1] : [Math.cos(a), Math.sin(a), 0.35, -0.25].slice(0, n);
  const dist = V.map(p => BODY.d + p.reduce((q, x, k) => q + nu[k] * x, 0));
  const P = V.map(p => project(n, p));
  const outline = n >= 2 ? zonogon(fr.f.map(f => project(n, f))) : [], H = n >= 2 ? hull(P.map((p, i) => [p[0], p[1], i])) : [];
  const flips = outline.map((v, i) => { const x = v ^ outline[(i + 1) % outline.length]; return popcount(x) === 1 ? 31 - Math.clz32(x) : null; });
  let edges = 0; for (let u = 0; u < 1 << n; u++) for (let w = u + 1; w < 1 << n; w++) if (popcount(u ^ w) === 1) edges++;
  return { n, sizes: s, motor: M, frame: fr, vertices: V, direct: D, err, counts: { sandwichesFrame: n + 1, additions: (1 << n) - 1, sandwichesDirect: 1 << n, edges },
    nu, d: BODY.d, dist, deepBits: deepestBits(fr, nu), deepScan: deepestScan(V, nu, BODY.d), projected: P, outline, hull: H, flips };
}
