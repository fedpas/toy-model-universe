// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/furey.js — Calibration 2 (Furey) as the figures of owner P10 print it (docs/PHYSICS_AUDIT.md §2.17, FU1–FU6; D29, D34, D36, D37).
// Every number is either a block of the stored results of the three scripts that ran (furey_papers_check.py, threegen_selfcheck.py, dictionary_selfcheck.py,
// shipped as content/stored_p10.json by tools/physics/stored_p10.mjs and read with useTable('stored_p10')), or computed here: exact integer bookkeeping of
// charges and irreps (engines/fureyPapersEngine.js), and labels, squares and commutation through the kernel (engines/bitrule.js: popcount, sign, square, cell,
// label). No sign is computed here (rule 4); nothing here is a sentence. tests/physics/p10.test.mjs ties every function to the stored files.
import { popcount, sign, square, cell, label } from '../bitrule.js';
import * as E from '../fureyPapersEngine.js';
import { DICTIONARY, FUREY_PAPERS } from '../stored.js';

// ---------------------------------------------------------------- the stored blocks (D34): key paths into each file, copied as they are
export const SOURCES = {
  fp: 'checks/selfcheck/furey_papers.json (furey_papers_check.py)',
  tg: 'checks/selfcheck/threegen.json (threegen_selfcheck.py)',
  dic: 'checks/selfcheck/dictionary.json (dictionary_selfcheck.py)',
};
export const STORED_PATHS = {
  fp: [['composites'], ['composites_note'], ['counting'], ['room'], ['trialities'], ['fig1', 'blocks'], ['fig1', 'matched'], ['fig1', 'of']],
  tg: [['blocks'], ['dimensions'], ['exotic'], ['generations'], ['search_all'], ['bottleneck'], ['sm_rows'], ['max_copies_of_each_irrep'], ['linear_beyond_one_generation']],
  dic: [['code'], ['omega'], ['cartan_ledger'], ['counts']],
};
export const at = (o, p) => p.reduce((x, k) => (x == null ? undefined : x[k]), o);
/** a copy of `whole` holding only the blocks at `paths`, each as it is */
export function partsOf(whole, paths) {
  const out = {};
  for (const p of paths) { let to = out; p.forEach((k, i) => { if (i === p.length - 1) to[k] = at(whole, p); else to = to[k] = to[k] || {}; }); }
  return out;
}
/** is T the table content/stored_p10.json (as loaded)? */
export const okStored = T => !!(T && T.fp && T.tg && T.dic && T.fp.room && T.fp.trialities && T.fp.counting && T.tg.dimensions && T.tg.search_all && T.dic.code && T.dic.omega);

// ---------------------------------------------------------------- exact fractions as the figures print them
const gcd = (a, b) => (b ? gcd(b, a % b) : Math.abs(a));
/** n/d reduced, with a true minus sign: "−3/8", "0", "1", "+1/6" when plus is asked */
export function frac(n, d = 1, plus = false) {
  if (n === 0) return '0';
  const g = gcd(Math.abs(n), d), a = Math.abs(n) / g, b = d / g;
  return (n < 0 ? '−' : plus ? '+' : '') + (b === 1 ? String(a) : `${a}/${b}`);
}
/** "−2/3" or "-2/3" or "1" → the integer count of 1/den */
export const units = (s, den) => { const [n, d = '1'] = String(s).replace('−', '-').split('/'); return Math.round((den * Number(n)) / Number(d)); };
export const range = k => Array.from({ length: k }, (_, i) => i);
/** 5582 → "5,582" */
export const thousands = n => String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');

// ---------------------------------------------------------------- FU1: Y and Q on the eight complex dimensions, the blocks
/** the eight complex dimensions of V as the dictionary names them (the vertices of the Peirce simplex) */
export const VERTS = ['o', 'O1', 'O2', 'O3', 'H1', 'H2', 'c', 'r'];
const BLOCK_KEYS = ['C_O', 'C3_O', 'C2_H', 'C_C', 'C_last'];
/** [{ v, block, k, y6, q3 }]: the block of each dimension (dictionary.json channels.vertex_blocks), its hypercharge in sixths and its charge in thirds
 *  (the k-th charge of its block, engines/fureyPapersEngine.js BLOCKS) */
export function lanes(vb = DICTIONARY.channels.vertex_blocks) {
  const seen = [0, 0, 0, 0, 0];
  return VERTS.map(v => { const b = BLOCK_KEYS.indexOf(vb[v]), B = E.BLOCKS[b], k = seen[b]++; return { v, block: b, k, y6: B.y, q3: B.q[k] }; });
}
/** the value of a dimension in 24ths: Y comes in sixths (× 4), Q in thirds (× 8) */
export const in24 = (l, which) => (which === 'Q' ? l.q3 * 8 : l.y6 * 4);
/** the bars of one charge: values in 24ths (shifted by the mean when asked), the trace and the mean (Tr / 8) in 24ths */
export function chargeBars(which = 'Y', shift = false) {
  const ls = lanes(), raw = ls.map(l => in24(l, which)), trace = raw.reduce((a, b) => a + b, 0), mean = trace / ls.length;
  const vals = raw.map(v => v - (shift ? mean : 0));
  return { which, shift, lanes: ls, raw, vals, trace, mean, sum: vals.reduce((a, b) => a + b, 0) };
}
export const fmt24 = v => frac(v, 24);
/** the five complex blocks: name, size n, irrep, the charges of its states (thirds); the complex board's diagonal Σn² and off-diagonal (Σn)² − Σn² */
export function blockTable() {
  const rows = E.BLOCKS.map((B, b) => ({ b, name: B.name, n: B.n, irrep: E.blockIrrep(B), q3: B.q }));
  const N = rows.reduce((a, r) => a + r.n, 0), diag = rows.reduce((a, r) => a + r.n * r.n, 0);
  return { rows, N, diag, off: N * N - diag };
}
/** Y = Σ y_b P_b and Q = Σ q_v P_v as TeX, from the stored block names and hypercharges (fig1.blocks) and the charges per dimension: her eqs. 44, 45 (INP-092) */
const TEXP = { O1: '\\mathbb{O}_1', O2: '\\mathbb{O}_2', H: '\\mathbb{H}', C: '\\mathbb{C}', last: '\\mathrm{last}' };
const texCoef = (n, d) => { const g = gcd(n, d), a = n / g, b = d / g; return b === 1 ? (a === 1 ? '' : String(a)) : `\\tfrac{${a}}{${b}}`; };
export function chargeTex(fig1Blocks) {
  const ls = lanes(), name = b => TEXP[fig1Blocks[b].name] || fig1Blocks[b].name;
  const Y = fig1Blocks.map((B, b) => [units(B.y, 6), b]).filter(([y]) => y).map(([y, b]) => `${texCoef(y, 6)}P_{${name(b)}}`);
  const Q = [];
  for (let b = 0; b < fig1Blocks.length; b++) {
    const own = ls.filter(l => l.block === b), q = own.map(l => l.q3);
    if (q.every(x => x === q[0])) { if (q[0]) Q.push(`${texCoef(q[0], 3)}P_{${name(b)}}`); }
    else own.forEach(l => { if (l.q3) Q.push(`${texCoef(l.q3, 3)}P_{${name(b)}_{${l.k + 1}}}`); });
  }
  return { Y: `Y = ${Y.join(' + ')}`, Q: `Q = ${Q.join(' + ')}` };
}

// ---------------------------------------------------------------- FU1 (FUR-003): the sixteen axes — the seven Fano-line blades and their products, through the kernel
/** the lens of the figure → the kernel's printer (label of engines/bitrule.js); demicube prints bits and marks the even labels */
export function lensKey(lens, level = 'research') {
  switch (lens) {
    case 'cube': case 'bits': return 'bits';
    case 'prime': case 'primes': return 'primes';
    case 'simplex': return 'set';
    case 'demicube': return 'demicube';
    case 'clifford': return 'clifford';
    default: return level === 'learner' ? 'bits' : 'clifford';
  }
}
/** a label printed in a lens of the kernel, in the cell of n generators (n = 0: the scalar) */
export function labelIn(mask, key, n) {
  const eps = cell(0, n), k = key === 'demicube' ? 'bits' : key;
  if (n === 0) return k === 'clifford' || k === 'primes' ? '1' : '∅';
  const s = label(mask, k, eps);
  return k === 'set' && s === '{}' ? '∅' : s;
}
/** the stored code of the axes (dictionary.json code, omega) recomputed through the kernel in Cl(0,8) */
export function torus(code, omega) {
  const eps = cell(0, 8), lines = code.fano_line_tetrahedra;
  const span = new Set([0]); for (const l of lines) for (const x of [...span]) span.add(x ^ l);
  const basis = []; for (const l of lines) { let x = l; for (const b of basis) if ((x ^ b) < x) x ^= b; if (x) { basis.push(x); basis.sort((a, b) => b - a); } }
  const faces = [...code.faces].sort((a, b) => popcount(a) - popcount(b) || a - b);
  const lineSet = new Set(lines);
  let withOmega = 0; for (let a = 0; a < 256; a++) if (sign(a, omega.N, eps) === sign(omega.N, a, eps)) withOmega++;
  return {
    faces: faces.map(N => ({ N, grade: popcount(N), line: lineSet.has(N), even: popcount(N) % 2 === 0 })),
    lines, span: [...span].sort((a, b) => a - b), rank: basis.length, axes: 1 << basis.length,
    commute: lines.every(a => lines.every(b => sign(a, b, eps) === sign(b, a, eps))), squares: lines.map(a => square(a, eps)),
    omega: omega.N, omegaGrade: popcount(omega.N), omegaSquare: square(omega.N, eps), withOmega,
  };
}

// ---------------------------------------------------------------- FU2: the missing irreps as products (quantum numbers only)
/** the stored pairs (fp composites: label names, the stored result, the target) read through the engine's Fig. 1 names; without the table, the engine's presets */
export function compositePairs(T) {
  if (okStored(T)) return T.fp.composites.map(c => ({ a: E.labelIrrep(c.a), b: E.labelIrrep(c.b), names: [E.labelText(c.a), E.labelText(c.b)], target: c.target, stored: c.result }));
  return E.PRESETS.map(p => ({ a: p.a, b: p.b, names: p.names, target: p.target, stored: null }));
}
/** the product of two irreps, term by term: the colours and isospins it holds, the hypercharges added (sixths); the irreps; the target found or not */
export function composite(a, b, target = null) {
  const prod = E.product(a, b);
  return {
    a, b, prod, colours: [...new Set(prod.map(r => r.c))], isospins: [...new Set(prod.map(r => r.i))], y6: [a.y, b.y, a.y + b.y],
    dim: E.dimOf(a) * E.dimOf(b), dims: prod.reduce((s, r) => s + E.dimOf(r), 0), target, found: target ? E.containsType(prod, target) : null,
  };
}
/** a name of an irrep: "(3,2,+1/6) = Q_L" (with † for a conjugate), or the irrep alone */
export const irrepName = r => { const k = E.kindOf(r); return k ? `${k.type.replace('nu_', 'ν_')}${k.conj ? '†' : ''}` : null; };

// ---------------------------------------------------------------- FU3, FU4, FU6: the room, the search over W, the 128 dimensions, the ledger
/** the rungs of the room by complex dimension (fp room by_dimension), lowest first; complete sets = S / 2 (the stored rule) */
export function roomLadder(room) {
  return Object.keys(room.by_dimension).map(Number).sort((a, b) => a - b).map(n => {
    const R = room.by_dimension[n];
    const hist = Object.entries(R.histogram_of_S).map(([S, count]) => ({ S: +S, sets: +S / 2, count })).sort((a, b) => a.S - b.S);
    return { n, structures: R.structures, maxS: R.max_S, best: R.max_S / 2, hist, example: R.example_with_max, total: hist.reduce((s, h) => s + h.count, 0) };
  });
}
/** the exhaustive search over the admissible W of dimension 8 (tg search_all): generations 0 … max + 1, the last with no W (the histogram covers every W) */
export function wSearch(tg) {
  const S = tg.search_all, max = S.max_generations, gens = range(max + 2).map(g => ({ g, count: S.histogram[String(g)] || 0 }));
  return { admissible: S.admissible_W, max, gens, total: gens.reduce((s, x) => s + x.count, 0), copies: E.TYPES.map(t => ({ t, max: tg.max_copies_of_each_irrep[t] })) };
}
/** the labels of the 8-bit cell: 2^8 = 256, the real dimension of End(V) = Cl(0,8) */
export const realDim = () => 1 << cell(0, 8).length;
/** where the 128 complex dimensions of End(V) go (tg dimensions, exotic): gauge blocks, linear off-diagonal, antilinear of Standard Model type, antilinear exotic */
export function whole(tg) {
  const d = tg.dimensions, x = tg.exotic;
  const parts = [{ key: 'diag', dim: d.diagonal_complex }, { key: 'lin', dim: d.linear_off_diagonal_complex }, { key: 'anti', dim: d.antilinear_complex - x.antilinear }, { key: 'exotic', dim: x.antilinear }];
  return { parts, total: parts.reduce((s, p) => s + p.dim, 0), real: realDim(), linear: d.linear_complex, antilinear: d.antilinear_complex };
}
/** the ledger of complete sets for k sets wanted (engines/fureyPapersEngine.js: sets by type, what is missing, what is left over) */
export function ledger(k, doubled) {
  const sets = E.setsByType(doubled), miss = E.missingFor(k, doubled), sur = E.surplus(doubled);
  return {
    k, doubled, types: E.TYPES.map(t => ({ t, have: sets[t], short: Math.max(0, k - sets[t]) })), missing: miss, surplus: sur,
    surplusDim: E.TYPES.reduce((a, t) => a + E.SM_DIM[t] * sur[t], 0), complete: E.completeSets(doubled),
  };
}
/** the capacity of every edge between two blocks, both directions, in complex dimensions (2 n_a n_b) and their sum */
export function capacities() {
  const out = []; for (let a = 0; a < 5; a++) for (let b = a + 1; b < 5; b++) out.push({ a, b, cap: E.capacity(a, b) });
  return { edges: out, total: out.reduce((s, e) => s + e.cap, 0) };
}
/** "Q_L 1, u_R 1, ν_R 1" style lists: [[type, n]] of a { type: n } map, in the order of the six types */
export const typeList = m => E.TYPES.filter(t => m[t] > 0).map(t => [t, m[t]]);

// ---------------------------------------------------------------- FU5: one generation as numbers, the trialities, the ladder of the division algebras
/** a spectrum { value: count } (values as stored: "-1/3", "1/6" …), sorted by value: bars, the total, the sum in sixths and the sum of cubes in 216ths */
export function spectrum(map) {
  const bars = Object.keys(map).map(k => ({ k, y6: units(k, 6), count: map[k] })).sort((a, b) => a.y6 - b.y6);
  return { bars, total: bars.reduce((s, b) => s + b.count, 0), sum6: bars.reduce((s, b) => s + b.count * b.y6, 0), cubes216: bars.reduce((s, b) => s + b.count * b.y6 ** 3, 0) };
}
/** the spectra on Ψ_L (fp roadmap spectra_on_PsiL, bundled through engines/stored.js) */
export const PSI_L = { Y: 'Y', Q: 'Q', BL: 'B-L' };
export const psiL = (charge = 'Y', roadmap = FUREY_PAPERS.roadmap) => spectrum(roadmap.spectra_on_PsiL[PSI_L[charge] || 'Y']);
/** the left-handed generation of the Standard Model by hypercharge, from the engine's six types: Q_L and L as they are, the right-handed ones conjugated */
export function leftHanded() {
  const c = t => ({ ...E.SM[t], y: -E.SM[t].y });
  return [['Q_L', E.SM.Q_L], ['uᶜ', c('u_R')], ['dᶜ', c('d_R')], ['L', E.SM.L], ['eᶜ', c('e_R')], ['νᶜ', c('nu_R')]].map(([name, r]) => ({ name, y6: r.y, dim: E.dimOf(r) }));
}
/** the dimension arithmetic of the Freudenthal–Tits forms: dim ℍ = 4 and dim 𝕆 = 8 are the label counts of 2 and 3 bits */
export function freudenthal(tri) {
  const H = 1 << cell(0, 2).length, O = 1 << 3, t = tri.tri_dims;
  return { H, O, e7: [t.H, t.O, 3 * H * O], e8: [t.O, t.O, 3 * O * O], sum39: [t.C, t.H, t.O], g2: [tri.g2.derivations, tri.g2.fix_e7, tri.g2.move_e7] };
}
const sum = a => a.reduce((s, x) => s + x, 0);
export { sum };
/** the ladder ℝ ⊂ ℂ ⊂ ℍ ⊂ 𝕆 (one more bit a rung): the labels of each rung, tri(𝕂) as stored; ℝ, ℂ, ℍ are the cells Cl(0,0), Cl(0,1), Cl(0,2); 𝕆 has 8 labels
 *  and its sign is imported (INP-087), not the rule's */
export const DIV = [{ key: 'R', bits: 0 }, { key: 'C', bits: 1 }, { key: 'H', bits: 2 }, { key: 'O', bits: 3, imported: true }];
export function divLadder(tri) {
  return DIV.map(d => ({ ...d, labels: 1 << d.bits, masks: range(1 << d.bits), tri: tri ? tri.tri_dims[d.key] : null, cell: d.imported ? null : `Cl(0,${d.bits})`, squares: d.imported ? null : range(d.bits).map(i => square(1 << i, cell(0, d.bits))) }));
}

// ---------------------------------------------------------------- the papers' ladder (fp roadmap): each rung the one above restricted by the reflections it adds
export function papersLadder(line, roadmap = FUREY_PAPERS.roadmap) {
  const L = roadmap[line + '_line'];
  return L.map((s, j) => ({ j, dim: s.dim, name: s.name, refl: s.reflections, added: j ? s.reflections.filter(r => !L[j - 1].reflections.includes(r)) : [], nested: j ? L[j - 1].reflections.every(r => s.reflections.includes(r)) : true }));
}
