// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/shifted.js — Calibration 3, the shifted view of Atiyah and Moore, owner B3 (docs/round14/STORY_ROUND.md §6.3, D62; the rows ATY-005,
// ATY-009, ATY-040, ATY-052, ATY-054, ATY-055). Pure functions, data only, no sentence; two sources and nothing else:
//   the kernel (engines/bitrule.js mul, gen, reorderSign) on the labels of Cl(1,3), with exact fractions over BigInt —
//     J = γ₂γ₁ (the paper's i, MAP-018) and its powers; the reverse ψ̃ (each blade by the kernel's reordering sign of the blade with itself); the frame
//     ψγ_kψ̃; the boost of a stored wave vector; the right factor e^{JEτ} at the quarter turns, which is J^{2n+1} (e^{Jπ/2} = J because J² = −1, the
//     kernel's), and at a rational point of the circle, c + sJ; the sign (−1)ⁿ of every shell and of the beat is read off those products;
//   the stored table content/stored_shifted.json (tools/story/stored_shifted.mjs, from the logs of the shifted scripts) — the shells of shd·QNT, the
//     example of shd·BIL, the beat of en·BEAT, the series of se.SER with se.LOW and se.ZERO, the radius of se.DS5 and the numbers of se.TIME; where
//     arithmetic or the kernel gives a stored number again (E = m + (−1)ⁿκ, the beat 2κ and 2κ/a, the first-order correction 2μ, the rates r with
//     r² + 3Hr = εκ²), it is computed here and tests/physics/p12.test.mjs holds it equal to the stored value.
// API: Q, toQ, qadd, qsub, qmul, qdiv, qneg, qeq, qnum, qstr; SQ13, gamma, J, MASK_J, bladeLabel, jPower, quarterTurn, reverse, sandwich, vectorPart, frameOf,
// boostOf, heroData; okStored, shellCases, shellRungs, emptyMarks, beatData, poly, polyStr, ricciData, radiusData, timeData.
// No sign is computed here: every sign is the kernel's (tests/shipped.test.mjs rule 4).
import { mul, gen, reorderSign, label } from '../bitrule.js';

// ---------------------------------------------------------------- exact fractions over BigInt (reduced, denominator > 0)
const gcd = (a, b) => { let x = a < 0n ? -a : a, y = b < 0n ? -b : b; while (y) [x, y] = [y, x % y]; return x; };
/** the fraction n/d (numbers, BigInts or digit strings) */
export function Q(n, d = 1) {
  const N = BigInt(n), D = BigInt(d);
  if (D === 0n) throw new Error('a fraction with denominator 0');
  if (D < 0n) return Q(-N, -D);
  const g = gcd(N, D) || 1n;
  return { n: N / g, d: D / g };
}
/** a fraction from "3/4", "-2", 5, or a fraction */
export const toQ = v => (v && typeof v === 'object' ? v : typeof v === 'string' && v.includes('/') ? Q(...v.split('/').map(s => s.trim())) : Q(v));
export const qadd = (x, y) => Q(x.n * y.d + y.n * x.d, x.d * y.d);
export const qneg = x => Q(-x.n, x.d);
export const qsub = (x, y) => qadd(x, qneg(y));
export const qmul = (x, y) => Q(x.n * y.n, x.d * y.d);
export const qdiv = (x, y) => Q(x.n * y.d, x.d * y.n);
export const qeq = (x, y) => x.n === y.n && x.d === y.d;
export const qnum = x => Number(x.n) / Number(x.d);
export const qstr = x => (x.d === 1n ? String(x.n) : `${x.n}/${x.d}`);
/** the kernel's numeric adapter over these fractions */
const QN = { add: qadd, mul: qmul, scale: (s, x) => qmul(Q(s), x), zero: Q(0), isZero: x => x.n === 0n };
const mv = entries => new Map(entries.map(([a, c]) => [a, toQ(c)]));
const mulQ = (x, y) => mul(x, y, SQ13, QN);

// ---------------------------------------------------------------- the kernel's part: Cl(1,3), γ₀ … γ₃ on bits 0 … 3
/** the cell Cl(1,3): γ₀ squares to +1, γ₁ γ₂ γ₃ to −1 */
export const SQ13 = [1, -1, -1, -1];
/** γ_k with a fraction coefficient */
export const gamma = k => mv([...gen(k)]);
/** J = γ₂γ₁, the kernel's product (MAP-018: the complex structure of the labels, the paper's i) */
export const J = mulQ(gamma(2), gamma(1));
export const MASK_J = [...J.keys()][0];
/** the name of a blade of Cl(1,3) by the kernel's printer in a label lens (clifford, bits, primes, …: D8), for the figures, which print no label themselves */
export const bladeLabel = (mask, lens) => label(mask, lens, SQ13);
/** J^m by the kernel (m ≥ 0) */
export function jPower(m) { let x = mv([[0, 1]]); for (let i = 0; i < m; i++) x = mulQ(x, J); return x; }
/** the coefficient of a blade in a multivector (a fraction, 0 when absent) */
const coef = (x, a) => (x.has(a) ? x.get(a) : Q(0));
/**
 * The right factor e^{JEτ} at the quarter turn Eτ = (n + ½)π: J^{2n+1} (the kernel's powers; e^{Jπ/2} = J since J² = −1). sign: its coefficient on J
 * over J's own, (−1)ⁿ, read off the kernel's product; scalar: its scalar part (0: cos Eτ = 0 there).
 */
export function quarterTurn(n) {
  const x = jPower(2 * n + 1), s = qdiv(coef(x, MASK_J), coef(J, MASK_J));
  return { mv: x, sign: qnum(s), scalar: qnum(coef(x, 0)), onlyJ: [...x.keys()].every(a => a === MASK_J) };
}
/** ψ̃: each blade by the kernel's reordering sign of the blade with itself (the sign of writing its generators in the reverse order) */
export const reverse = x => new Map([...x].map(([a, c]) => [a, qmul(Q(reorderSign(a, a)), c)]));
/** ψ v ψ̃ */
export const sandwich = (psi, v) => mulQ(mulQ(psi, v), reverse(psi));
/** the four coefficients on γ₀ … γ₃ of a multivector, and whether nothing else is there */
export const vectorPart = x => ({ v: [0, 1, 2, 3].map(k => coef(x, 1 << k)), pure: [...x.keys()].every(a => [1, 2, 4, 8].includes(a)) });
/** the frame ψγ_kψ̃ (k = 0 … 3) over ψψ̃ (a scalar for the ψ drawn here): each vector as fractions, with its numbers */
export function frameOf(psi) {
  const nn = mulQ(psi, reverse(psi)), norm = coef(nn, 0), scalarNorm = [...nn.keys()].every(a => a === 0);
  const vectors = [0, 1, 2, 3].map(k => { const { v, pure } = vectorPart(sandwich(psi, gamma(k))); return { k, q: v.map(c => qdiv(c, norm)), pure }; });
  return { norm, scalarNorm, vectors: vectors.map(x => ({ k: x.k, q: x.q, num: x.q.map(qnum), pure: x.pure })) };
}
/**
 * The boost that takes γ₀ to k/E for a stored wave vector k = (k₀, k₁, k₂, k₃) on the shell E² = k₀² − k₁² − k₂² − k₃²: ψ = (k₀ + E) + Σᵢ kᵢBᵢ with Bᵢ the
 * bivector of the plane (γ₀, γᵢ) in the order whose sandwich turns γ₀ to +k/E (both orders are tried; the kernel decides). At rest ψ = 2E, a scalar.
 */
export function boostOf(k, E) {
  const kq = k.map(x => toQ(x)), e = toQ(E);
  for (const order of [[1, 0], [0, 1]]) {
    const psi = new Map([[0, qadd(kq[0], e)]]);
    for (const i of [1, 2, 3]) if (kq[i].n !== 0n) for (const [a, c] of mulQ(gamma(order[0] ? i : 0), gamma(order[0] ? 0 : i))) psi.set(a, qmul(c, kq[i]));
    const f = frameOf(psi), u = f.vectors[0].q;
    if (u.every((c, j) => qeq(qmul(c, e), kq[j]))) return { psi, frame: f };
  }
  throw new Error(`boostOf: no boost of the labels takes γ₀ to k/E for k = (${k.join(', ')}), E = ${E}`);
}
/** which frame vectors a right factor keeps (+), reverses (−), or turns (neither), comparing two frames vector by vector */
function compare(before, after) {
  return before.vectors.map((b, i) => { const a = after.vectors[i].q; return b.q.every((c, j) => qeq(c, a[j])) ? 'kept' : b.q.every((c, j) => qeq(qneg(c), a[j])) ? 'reversed' : 'turned'; });
}
/**
 * The hero's data (shifted-quarter-turn) at the rung n and on a sheet. The right factor is the kernel's J^{2n+1} at every rung; the wave whose frame is
 * drawn is a stored one of that rung: n = 0 the example of shd·BIL (m, κ, E, k), n = 1 the first moving wave shd·QNT stores on the shell of that rung;
 * a rung the table does not store (n ≥ 2), or no table, draws the frame at rest (ψ = 1: the identity holds for any even ψ, the kernel's) and no wave;
 * a stored wave that is not on its stored shell (a broken table) is flagged offShell and its frame is not drawn either.
 * sheet "retarded" (the waves e^{−Jk·x}: the factor is the translation by +τ along k/E) or "advanced" (e^{+Jk·x}: by −τ), as shd·OWN states it. The
 * rational point of shd·BIL at rest: the frame after c + sJ, with cos 2θ = c² − s² and the turn of (γ₁, γ₂) read off the kernel's product.
 */
export function heroData(T, { n = 0, sheet = 'retarded' } = {}) {
  const qt = quarterTurn(n), rung = T ? shellRungs(T, 0)[n] : null;
  let wave = null;
  if (T && n === 0) { const ex = T.bil.values.example; wave = { m: ex.m, kappa: ex.kappa, E: ex.E, k: ex.k, from: 'shd·BIL' }; }
  else if (T && rung && rung.stored) { const c = T.qnt.values.case32, k = rung.stored.k.find(x => x.slice(1).some(y => y !== 0) && x[0] > 0); if (k) wave = { m: c.m, kappa: c.kappa, E: rung.stored.E, k, from: 'shd·QNT' }; }
  let psi = mv([[0, 1]]);
  if (wave) { try { psi = boostOf(wave.k, wave.E).psi; } catch (e) { wave = { ...wave, offShell: true }; } }   // a stored wave off its shell is not drawn: the frame at rest
  const before = frameOf(psi), after = frameOf(mulQ(psi, qt.mv)), status = compare(before, after);
  let rational = null;
  if (T) {
    const rat = T.bil.values.rational, [c, s] = rat.cs.map(toQ), turned = frameOf(new Map([[0, c], ...[...J].map(([a, x]) => [a, qmul(x, s)])]));
    const cos2 = qsub(qmul(c, c), qmul(s, s)), sin2 = qmul(Q(2), qmul(c, s)), e1 = turned.vectors[1].q;   // γ₁ after the factor: cos 2θ γ₁ ∓ sin 2θ γ₂
    const turn = qeq(e1[1], cos2) && qeq(e1[2], qneg(sin2)) ? -2 : qeq(e1[1], cos2) && qeq(e1[2], sin2) ? 2 : null;
    rational = { cs: rat.cs, E: rat.E, cos2: qstr(cos2), storedCos2: rat.cos2, turn, storedTurn: rat.turn, frame: turned.vectors.map(v => v.num) };
  }
  return {
    n, sheet, dir: sheet === 'advanced' ? -1 : 1, wave, factor: { power: 2 * n + 1, sign: qt.sign, scalar: qt.scalar, onlyJ: qt.onlyJ },
    before: before.vectors.map(v => v.q.map(qstr)), after: after.vectors.map(v => v.q.map(qstr)), status, pure: [...before.vectors, ...after.vectors].every(v => v.pure),
    kept: status.map((x, k) => (x === 'kept' ? k : -1)).filter(k => k >= 0), reversed: status.map((x, k) => (x === 'reversed' ? k : -1)).filter(k => k >= 0),
    rung: rung ? { n, phase: rung.phase, tau: rung.tau, E: rung.E, stored: rung.stored ? rung.stored.E : null } : { n, phase: qstr(Q(2 * n + 1, 2)), tau: qstr(Q(2 * n + 1, 4)), E: null, stored: null },
    rational,
  };
}

// ---------------------------------------------------------------- the stored table (D62): what each block holds, and what is computed again from it
const BLOCKS = ['qnt', 'bil', 'beat', 'ser', 'low', 'zero', 'ds5', 'time'];
/** a table of the shape tools/story/stored_shifted.mjs writes (every block with its lines and values) */
export const okStored = T => !!T && typeof T === 'object' && BLOCKS.every(b => T[b] && Array.isArray(T[b].lines) && T[b].lines.length > 0 && T[b].values && typeof T[b].values === 'object');
/** a point of the circle of the right factor e^{Jφπ} for φ a multiple of ½: (cos, sin) read off the kernel's J^{2φ} */
function circlePoint(phase) {
  const k = qmul(toQ(phase), Q(2));
  if (k.d !== 1n || k.n < 0n) return null;
  const x = jPower(Number(k.n));
  return [qnum(coef(x, 0)), qnum(qdiv(coef(x, MASK_J), coef(J, MASK_J)))];
}
/** the two stored cases of shd·QNT: (m, κ) = (3, 2) with its stored rungs and wave vectors, and (1, 4) with its second branch */
export function shellCases(T) {
  const v = T.qnt.values, a = v.case32, b = v.case14;
  return [
    { key: `${a.m},${a.kappa}`, m: a.m, kappa: a.kappa, stored: Object.fromEntries(a.rungs.map(r => [r.n, { E: r.E, second: null, k: r.k, phase: r.phase }])) },
    { key: `${b.m},${b.kappa}`, m: b.m, kappa: b.kappa, stored: { 0: { E: b.ordinary, second: b.second, k: [], phase: b.phase } } },
  ];
}
/**
 * The rungs n = 0 … 3 of one stored case: the phase Eτ = (n + ½)π and the shift τ = (2n + 1)λ_C/4 (in π and in λ_C), the kernel's sign (−1)ⁿ, the
 * ordinary shell E = m + (−1)ⁿκ and the second branch E = (−1)ⁿκ − m where it is positive (computed), beside what the table stores for that rung
 * (null: the rung is not stored, D37 — drawn empty, never extrapolated).
 */
export function shellRungs(T, ci = 0, top = 3) {
  const c = shellCases(T)[ci];
  return Array.from({ length: top + 1 }, (_, n) => {
    const s = quarterTurn(n).sign, E = c.m + s * c.kappa, second = s * c.kappa - c.m;
    return { n, phase: qstr(Q(2 * n + 1, 2)), tau: qstr(Q(2 * n + 1, 4)), sign: s, E: E > 0 ? E : null, second: second > 0 ? second : null, point: circlePoint(qstr(Q(2 * n + 1, 2))), stored: c.stored[n] || null };
  });
}
/** the points where shd·QNT finds no plane wave, on the circle of e^{JEτ}: τ = 0, λ_C/2, λ_C (phase 2τ/λ_C in π, through the kernel's J powers), the
 *  rational point (c, s) as stored, and the quarter turn with an energy off the shell */
export function emptyMarks(T) {
  return T.qnt.values.empty.map(e => {
    if (e.cs) return { kind: 'rational', cs: e.cs, point: e.cs.map(x => qnum(toQ(x))), moving: !!e.moving };
    const phase = e.phase != null ? e.phase : qstr(qmul(toQ(e.tau), Q(2)));
    return { kind: e.off ? 'off-shell' : 'tau', tau: e.tau != null ? e.tau : null, phase, E: e.E, point: circlePoint(phase) };
  });
}
/**
 * The beat of en·BEAT on the frame a (one of the stored four): the two modes' energies E = m + (−1)ⁿκ again (the kernel's signs), the beat E₁ − E₂ per
 * unit proper time and (E₁ − E₂)/a per unit coordinate time beside the stored ones, the shift (π/2 proper, aπ/2 coordinate), the sign of the beat term
 * over one shift (e^{J(E₁ − E₂)τ}, the kernel's J power), and samples of the density's beat term over a window of `window`·π (proper or coordinate
 * time, the same window for every frame), for the drawing: the cosine of the beat at the computed frequency, which equals the stored one.
 */
export function beatData(T, { frame = 0, time = 'proper', window = 4 } = {}) {
  const v = T.beat.values, a = toQ(v.frames[frame]), shift = toQ(v.shift);
  const E = v.modes.map(md => v.m + quarterTurn(md.n).sign * v.kappa), dE = Q(E[0] - E[1]);
  const coord = v.coordinate.find(x => qeq(toQ(x.a), a)) || null;
  const beat = time === 'coordinate' ? qdiv(dE, a) : dE, sh = time === 'coordinate' ? qmul(a, shift) : shift;
  const turnK = qmul(dE, qmul(shift, Q(2))), flip = turnK.d === 1n ? qnum(coef(jPower(Number(turnK.n)), 0)) : null;
  const span = window * Math.PI, N = 240;   // one window for every frame and both times (in units of π), so that the frames differ where they differ
  const samples = Array.from({ length: N + 1 }, (_, i) => { const t = (span * i) / N; return [t, Math.cos(qnum(beat) * t)]; });
  return {
    frames: v.frames, a: v.frames[frame], frame, time, modes: v.modes.map((md, i) => ({ ...md, Ecomputed: E[i] })), proper: { computed: qstr(dE), stored: String(v.proper) },
    coordinate: { computed: qstr(qdiv(dE, a)), stored: coord ? coord.beat : null }, beat: qstr(beat), shift: qstr(sh), flip, storedFlip: v.signChange.labels,
    shifts: Array.from({ length: Math.floor(span / (qnum(sh) * Math.PI) + 1e-9) + 1 }, (_, i) => qnum(sh) * Math.PI * i), samples, span,
  };
}

// ---------------------------------------------------------------- the series of se.SER, the lowest order of se.LOW, the roots of se.ZERO
/** a polynomial in κ and τ as the log prints it ("- 2 kappa tau + 2 kappa^2 tau^2", "-kappa tau^3/3 + 2 kappa^2 tau^4/3", "0"): [{ q, k, t }] */
export function poly(s) {
  const t = String(s).trim();
  if (t === '0') return [];
  return (/^[+-]/.test(t) ? t : `+ ${t}`).split(/\s+(?=[+-]\s)/).map(term => {
    const m = /^([+-])\s*(\d+(?:\/\d+)?)?\s*(kappa(?:\^(\d+))?)?\s*(tau(?:\^(\d+))?)?(?:\/(\d+))?$/.exec(term.trim());
    if (!m || (!m[2] && !m[3] && !m[5])) throw new Error(`poly: "${term}" in "${s}" is not a term in kappa and tau`);
    let q = toQ(m[2] || '1'); if (m[7]) q = qdiv(q, Q(m[7])); if (m[1] === '-') q = qneg(q);
    return { q, k: m[3] ? Number(m[4] || 1) : 0, t: m[5] ? Number(m[6] || 1) : 0 };
  });
}
const polyKey = p => p.map(x => `${qstr(x.q)}k${x.k}t${x.t}`).sort().join(' ');
/** the formula of a polynomial for a figure's research level (κ, τ; ^{…} for the superscripts that kit.tx draws), "0" when it is empty */
export function polyStr(p) {
  if (!p.length) return '0';
  return p.map((x, i) => {
    const neg = x.q.n < 0n, a = neg ? qneg(x.q) : x.q, vars = `${x.k ? 'κ' + (x.k > 1 ? `^{${x.k}}` : '') : ''}${x.t ? 'τ' + (x.t > 1 ? `^{${x.t}}` : '') : ''}`;
    const top = a.n === 1n && vars ? '' : String(a.n), body = a.d === 1n ? `${top}${vars}` : `${top}${vars}/${a.d}`;   // as the log writes it: κτ^3/3, 2κ^2τ^4/3
    return i === 0 ? (neg ? '−' : '') + body : `${neg ? ' − ' : ' + '}${body}`;
  }).join('');
}
const OPS = { '++': { name: 'Ricci₊₊', of: 'c(D₊²)' }, '+-': { name: 'Ricci₊₋', of: 'D₊D₋' }, ss: { name: 'Ricciₛₛ', of: 'Dₛ²' } };
/**
 * The three operators of (3.3a–c) as stored by se.SER (c₀ … c₃), each with its lowest order Ricci = −c₀ (computed) and the pairing of se.LOW that
 * holds it (the equation, the space, Λ), its root of the zero-mode reading (se.ZERO: the root whose leading coefficient is −c₀/κ²) and the first-order
 * correction of that root computed from c₁ (minus its coefficient of κτ, μ = κτ) beside the stored ratio of the root's first two coefficients.
 */
export function ricciData(T) {
  const S = T.ser.values.series, pairs = T.low.values.pairs, R = T.zero.values.roots;
  return S.map((s, i) => {
    const c = s.c.map(poly), ricci = c[0].map(x => ({ ...x, q: qneg(x.q) }));
    const pair = pairs.find(p => polyKey(poly(p.ricci)) === polyKey(ricci)) || null;
    const lead = qneg((c[0].find(x => x.k === 2 && x.t === 0) || { q: Q(0) }).q);
    const key = lead.n === 0n ? 'c' : ['a', 'b'].find(x => qeq(toQ(R[x][0]), lead)) || null;
    const muCoef = (c[1].find(x => x.k === 1 && x.t === 1) || { q: Q(0) }).q;
    const root = key === 'c' ? { key, coefficients: [R.c], everyOrder: !!R.everyOrder, correction: null, storedCorrection: null }
      : key ? { key, coefficients: R[key], correction: qstr(qneg(muCoef)), storedCorrection: qstr(qdiv(toQ(R[key][1]), toQ(R[key][0]))) } : null;
    return { i, op: s.op, ...(OPS[s.op] || { name: `Ricci_${s.op}`, of: s.def }), def: s.def, c: s.c, terms: c.map(polyStr), ricci: polyStr(ricci), pair, root };
  });
}

// ---------------------------------------------------------------- the radius of se.DS5 and the numbers of se.TIME
/**
 * The four stored settings (H, εκ²) of se.DS5, each with its two stored exponents p of φ = (−η)^p, the rates r = −pH of e^{rt} in cosmic time
 * (−Hη = e^{−Ht}) and the check r² + 3Hr = εκ² on each (exact), which root solves the whole five-dimensional equation, and the rates of the printed
 * (4.4), e^{±√ε κt}, where they are real (the case H = 0 of the same equation); printed44: the setting where the log states the printed exponents.
 */
export function radiusData(T) {
  const v = T.ds5.values;
  return v.settings.map((st, i) => {
    const H = toQ(st.H), k2 = toQ(st.ek2);
    const roots = v.exponents.filter(e => e.H === st.H && e.ek2 === st.ek2).map(e => {
      const r = qneg(qmul(toQ(e.p), H));
      return { p: e.p, r: qstr(r), rNum: qnum(r), solves: qeq(qadd(qmul(r, r), qmul(Q(3), qmul(H, r))), k2), einstein: e.einstein };
    }).sort((x, y) => y.rNum - x.rNum);
    const real = k2.n > 0n, root = real ? Math.sqrt(qnum(k2)) : null;
    const p44 = v.printed44 && v.printed44.H === st.H && v.printed44.ek2 === st.ek2 ? v.printed44 : null;
    return { i, H: st.H, ek2: st.ek2, roots, printed: { real, rates: real ? [root, -root] : null, stored: p44 ? [p44.p, -p44.p] : null, storedRates: p44 ? p44.rates : null } };
  });
}
/** the numbers of se.TIME as stored, with the arithmetic that ties them: 1/(c k) in seconds, a Julian year, the ratio to the paper's value and the
 *  e-folding times 2ħ/kc and ħ/(r₊ kc) (to the printed precision) */
export function timeData(T) {
  const v = T.time.values, sec = 1 / (Number(v.c) * Number(v.k)), yr = sec / (365.25 * 86400);
  const fix = (x, d) => Number(x).toExponential(d).replace(/e\+?/, 'e+').replace('e+-', 'e-');
  return {
    stored: v, computed: { seconds: fix(sec, 4), years: fix(yr, 4), ratio: (Number(v.years) / Number(v.paper.years)).toFixed(4),
      efold: v.efold.map(e => ({ r: e.r, years: fix(Number(v.years) / (e.r.includes('/') ? qnum(toQ(e.r)) : Number(e.r)), 2) })) },
  };
}
