// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/fibreBase.js — round 14, owner B4 (docs/round14/STORY_ROUND.md §6.3, D62): the kernel of the figure fibre-base. Spacetime Cl(1,3)
// beside Furey's fibre Cl(0,6) on the concatenated labels (bits 0–3 the base, bit 0 the time; bits 4–9 the fibre): the graded product Cl(1,3) ⊗̂ Cl(0,6)
// is the bit rule on the concatenated label, Cl(1,9); the ungraded product is the bit rule on each block with no cross sign. Then the volume element
// Γ = e₀ ⋯ e₉, the pseudoscalars I = e₀e₁e₂e₃ and ω₆ = e₄ ⋯ e₉ with Γ = +I·ω₆, the minimal left ideal cut by Γ into two halves, and the sign of I
// against ω₆ on each half (I = −ω₆ on Γ = +1, I = +ω₆ on Γ = −1): the statements of the fb.CHI lines of checks/selfcheck/proofs/logs/fibre_base.log,
// recomputed here from engines/bitrule.js alone and tied to those lines by tests/physics/p13.test.mjs (FUR-011). Beside them, what the figure's switch
// shows: the types of the product cells from their labels (centre, squares, count: the fb.TY lines, FUR-009) and the cross pairs of the two products
// (base and fibre vectors anticommute in the graded product, commute in the ungraded one; the 6 + 15 bivectors commute in both: fb.DIR, FUR-013).
// Pure: no stored table, no sentence, no sign of its own; every sign is the kernel's sign(a, b, eps), every label printed by the kernel's label().
// The signatures: the base Cl(1,3), time of square +1, or its mirror Cl(3,1), every square flipped (time first in both: fb.LR's order); the fibre
// Cl(0,6) or its mirror Cl(6,0): the four graded and four ungraded products of fb.TY, the stored cases the figure's chips offer.
import { sign, popcount, label } from '../bitrule.js';

export const NB = 4, NF = 6, N = NB + NF;                                   // base bits 0–3, fibre bits 4–9
export const BASES = { '1,3': [1, -1, -1, -1], '3,1': [-1, 1, 1, 1] };      // Cl(1,3) and its mirror, bit 0 the time in both
export const FIBRES = { '0,6': [-1, -1, -1, -1, -1, -1], '6,0': [1, 1, 1, 1, 1, 1] };
export const PRODUCTS = ['graded', 'ungraded'];
export const BASE_MASK = (1 << NB) - 1, FIBRE_MASK = ((1 << N) - 1) ^ BASE_MASK;
export const I_MASK = BASE_MASK, W_MASK = FIBRE_MASK, G_MASK = (1 << N) - 1;   // I = e₀e₁e₂e₃, ω₆ = e₄ ⋯ e₉, Γ = e₀ ⋯ e₉
const bitsOf = m => { const out = []; for (let i = 0; m >> i; i++) if ((m >> i) & 1) out.push(i); return out; };
/** the 6 bivectors of the base and the 15 of the fibre, and all 45 products of two generators, as masks */
export const BIV_BASE = [], BIV_FIBRE = [], BIV_ALL = [];
for (let i = 0; i < N; i++) for (let j = i + 1; j < N; j++) { const m = (1 << i) | (1 << j); BIV_ALL.push(m); if (j < NB) BIV_BASE.push(m); else if (i >= NB) BIV_FIBRE.push(m); }

/** a configuration of the figure's chips, read safely: { base, fibre, product } (defaults Cl(1,3), Cl(0,6), graded) */
export function config(p = {}) {
  return { base: p.base in BASES ? p.base : '1,3', fibre: p.fibre in FIBRES ? p.fibre : '0,6', product: PRODUCTS.includes(p.product) ? p.product : 'graded' };
}
/** the concatenated label: the squares of the ten generators, base first */
export const concatEps = (base = '1,3', fibre = '0,6') => [...BASES[base], ...FIBRES[fibre]];
/** the (p, q) of a list of squares */
export const pq = eps => [eps.filter(e => e > 0).length, eps.filter(e => e < 0).length];
/**
 * The sign of the product of two labels a, b of the ten bits: the graded product is the kernel on the concatenated label (the reordering sign counts
 * the cross pairs, a fibre bit of a before a base bit of b); the ungraded product is the kernel on each block, the cross sign left out (fb.TY: "the tables
 * s1 s2 without the cross sign").
 */
export function signOf(product, eps) {
  if (product === 'ungraded') { const eB = eps.slice(0, NB), eF = eps.slice(NB); return (a, b) => sign(a & BASE_MASK, b & BASE_MASK, eB) * sign(a >> NB, b >> NB, eF); }
  return (a, b) => sign(a, b, eps);
}
export const commutes = (s, a, b) => s(a, b) === s(b, a);

// ------------------------------------------------------------------------------------------------------------------------ the label type (fb.TY)
const DD = { R: 1, C: 2, H: 4 };
const isqrt = x => { let r = Math.floor(Math.sqrt(x)); while (r * r > x) r--; while ((r + 1) * (r + 1) <= x) r++; return r; };
/** c copies of M_m(D) from the dimension, the number c of simple summands, a complex centre and the count fs (c m for ℝ, 0 for ℂ, −2 c m for ℍ) */
export function typeFromInv(dim, c, cplx, fs) {
  if (c < 1) return null;
  const D = cplx ? 'C' : fs > 0 ? 'R' : 'H', q = dim / (c * DD[D]), m = Number.isInteger(q) ? isqrt(q) : 0;
  if (m < 1 || m * m !== q) return null;
  return ({ R: c * m, C: 0, H: -2 * c * m })[D] === fs ? { D, m, c } : null;
}
/**
 * The type of the algebra of n bits with the sign s (every square ±1), from its labels: the central labels (those commuting with the n generators),
 * whether one of them squares to −1, and the count Σ s(a, a) (fibre_base.py table_type and ltype_eps: "centre, squares, count")
 */
export function labelType(s, n = N) {
  const M = 1 << n; let count = 0; const Z = [];
  for (let a = 0; a < M; a++) {
    count += s(a, a);
    let central = true; for (let i = 0; i < n && central; i++) if (!commutes(s, a, 1 << i)) central = false;
    if (central) Z.push(a);
  }
  const cplx = Z.some(a => s(a, a) === -1);
  return typeFromInv(M, cplx ? Z.length / 2 : Z.length, cplx, count);
}
const SUBS = '₀₁₂₃₄₅₆₇₈₉', subs = k => String(k).replace(/\d/g, d => SUBS[+d]);
const FIELD = { R: 'ℝ', C: 'ℂ', H: 'ℍ' };
/** M₃₂(ℝ), M₁₆(ℍ), ℂ ⊕ ℂ …: a type as the rows print it */
export function typeName(t) {
  if (!t) return '?';
  const one = t.m === 1 ? FIELD[t.D] : `M${subs(t.m)}(${FIELD[t.D]})`;
  return Array(t.c).fill(one).join(' ⊕ ');
}
/** the real dimension of a minimal left ideal of the type: m times the dimension of its division algebra */
export const minimalIdealDim = t => (t ? t.m * DD[t.D] : null);

// ------------------------------------------------------------------------------------------------------------------------ the minimal ideal and its halves (fb.CHI)
/**
 * A maximal set of pairwise commuting labels of square +1, none in the span of the others, starting with `first`; even = true keeps to labels of even
 * weight. Greedy in ascending order of the masks, and in descending order where that gives more (fibre_base.py comm_labels takes the largest of random
 * greedy orders; the order here is fixed, so that the figure and the test draw one ideal).
 */
export function commutingLabels(s, n = N, first = [], even = true) {
  const up = Array.from({ length: (1 << n) - 1 }, (_, i) => i + 1);
  let best = null;
  for (const order of [up, [...up].reverse()]) {
    const G = [...first], span = new Set([0]);
    for (const g of G) for (const x of [...span]) span.add(x ^ g);
    for (const u of order) {
      if (span.has(u) || s(u, u) !== 1 || (even && popcount(u) % 2) || !G.every(g => commutes(s, u, g))) continue;
      G.push(u); for (const x of [...span]) span.add(x ^ u);
    }
    if (!best || G.length > best.length) best = G;
  }
  return best;
}
/**
 * The left ideal A f, f = Π (1 + e_g)/2 over the commuting labels G, on the basis e_r f, r the least label of each coset of the span H of G: e_h f = τ(h) f
 * for h in H, and a label b acts as a signed permutation, b · e_r f = s(b, r) s(r′, h) τ(h) e_r′ f where b xor r = r′ xor h (fibre_base.py Ideal.act).
 * act(b) = { perm, sgn }: the basis vector i goes to sgn[i] times the basis vector perm[i].
 */
export function idealOf(s, n, G) {
  const tau = new Map([[0, 1]]);
  for (const g of G) for (const [h, t] of [...tau]) tau.set(h ^ g, s(h, g) * t);     // e_(h xor g) = s(h, g) e_h e_g, and e_g f = f
  const H = [...tau.keys()], rep = new Map(), reps = [];
  for (let a = 0; a < (1 << n); a++) if (!rep.has(a)) { reps.push(a); for (const h of H) rep.set(a ^ h, [a, h]); }
  const idx = new Map(reps.map((r, i) => [r, i]));
  const act = b => {
    const perm = new Array(reps.length), sgn = new Array(reps.length);
    reps.forEach((r, i) => { const [r2, h] = rep.get(b ^ r); perm[i] = idx.get(r2); sgn[i] = s(b, r) * s(r2, h) * tau.get(h); });
    return { perm, sgn };
  };
  return { G, H, tau, reps, idx, m: reps.length, act };
}
/** the halves of the ideal under Γ, diagonal on it when Γ is one of the labels of G: the basis indices where Γ = +1 and where Γ = −1 */
export function halvesOf(ideal, gMask = G_MASK) {
  const A = ideal.act(gMask), plus = [], minus = [];
  A.perm.forEach((j, i) => { if (j === i) (A.sgn[i] === 1 ? plus : minus).push(i); });
  return { diagonal: A.perm.every((j, i) => j === i), plus, minus };
}
/** the sign rel with X = rel · Y on the basis vectors P (X, Y signed permutations of the ideal), or null where neither sign holds on all of P */
export function relOn(X, Y, P) {
  for (const rel of [-1, 1]) if (P.every(i => X.perm[i] === Y.perm[i] && X.sgn[i] === rel * Y.sgn[i])) return rel;
  return null;
}
/** a signed permutation restricted to the basis vectors P it keeps (an even label on a half): renumbered 0 … |P| − 1, or null where it leaves P */
export function restrict(X, P) {
  const at = new Map(P.map((i, k) => [i, k]));
  if (!P.every(i => at.has(X.perm[i]))) return null;
  return { perm: P.map(i => at.get(X.perm[i])), sgn: P.map(i => X.sgn[i]) };
}
/**
 * The real dimension of the commutant of signed permutations ops of an m-dimensional space: X commutes with each when X[π(b), π(c)] = s(b) s(c) X[b, c],
 * so the commutant has one basis matrix per sign-consistent class of the m² entries (fibre_base.py commutant_basis, by union-find)
 */
export function commutantDim(ops, m) {
  const M = m * m, parent = new Int32Array(M), psign = new Int8Array(M).fill(1);
  for (let x = 0; x < M; x++) parent[x] = x;
  const find = x => { let s = 1, r = x; while (parent[r] !== r) { s *= psign[r]; r = parent[r]; } return [r, s]; };   // X[x] = s · X[root]
  const eqs = [];
  for (const { perm, sgn } of ops) for (let b = 0; b < m; b++) for (let c = 0; c < m; c++) eqs.push([perm[b] * m + perm[c], b * m + c, sgn[b] * sgn[c]]);
  for (const [u, v, s] of eqs) { const [ru, su] = find(u), [rv, sv] = find(v); if (ru !== rv) { parent[ru] = rv; psign[ru] = su * s * sv; } }
  const bad = new Set();
  for (const [u, v, s] of eqs) { const [ru, su] = find(u), [rv, sv] = find(v); if (ru !== rv || su !== s * sv) bad.add(rv); }
  const roots = new Set(); for (let x = 0; x < M; x++) { const [r] = find(x); if (!bad.has(r)) roots.add(r); }
  return roots.size;
}

// ------------------------------------------------------------------------------------------------------------------------ one configuration of the figure
/** e₀e_k = σ · I R_k for the three boosts and their rotations R_k = e₂e₃, e₃e₁, e₁e₂ (fb.CHI): the common sign σ from the kernel, or null */
export function baseRelation(s) {
  const dual = [[3, 12, 1], [5, 10, -1], [9, 6, 1]];                         // e₀e₁ ↔ e₂e₃, e₀e₂ ↔ e₃e₁ = −e₁e₃, e₀e₃ ↔ e₁e₂
  const signs = dual.map(([k, v, sv]) => ((I_MASK ^ v) === k ? sv * s(I_MASK, v) : 0));
  return signs.every(x => x === signs[0]) && signs[0] !== 0 ? signs[0] : null;
}
const MEMO = new Map();
/**
 * Everything the figure draws for one configuration { base, fibre, product }, from the kernel: the ten generators with their squares, the squares of
 * I, ω₆ and Γ, the sign sIW of Γ = sIW · I ω₆, what commutes with what, the 24 cross pairs of a base and a fibre vector and the 90 of a base and a fibre
 * bivector, the types of the graded and the ungraded product, the minimal ideal and on each half its dimension, the sign rel of I = rel · ω₆ there and
 * the pairs of states that I (and ω₆) exchange. Memoised by configuration.
 */
export function fibreBase(params = {}) {
  const c = config(params), key = `${c.base}|${c.fibre}|${c.product}`;
  if (MEMO.has(key)) return MEMO.get(key);
  const eps = concatEps(c.base, c.fibre), s = signOf(c.product, eps), [p, q] = pq(eps);
  const gens = Array.from({ length: N }, (_, i) => ({ bit: i, block: i < NB ? 'base' : 'fibre', mask: 1 << i, square: s(1 << i, 1 << i) }));
  const bivs = [...BIV_BASE, ...BIV_FIBRE];
  const cross = []; for (let i = 0; i < NB; i++) for (let a = NB; a < N; a++) cross.push({ i, a, anti: !commutes(s, 1 << i, 1 << a) });
  let bivCross = 0; for (const x of BIV_BASE) for (const y of BIV_FIBRE) if (commutes(s, x, y)) bivCross++;
  const typeGraded = labelType(signOf('graded', eps)), typeUngraded = labelType(signOf('ungraded', eps)), type = c.product === 'graded' ? typeGraded : typeUngraded;
  const G = commutingLabels(s, N, [G_MASK], true), ideal = idealOf(s, N, G), H = halvesOf(ideal), I = ideal.act(I_MASK), W = ideal.act(W_MASK);
  const half = (gamma, P) => ({
    gamma, dim: P.length, rel: relOn(I, W, P), states: P.map(i => ideal.reps[i]),
    pairs: P.filter(i => I.perm[i] > i).map(i => ({ from: ideal.reps[i], to: ideal.reps[I.perm[i]], sI: I.sgn[i], sW: W.perm[i] === I.perm[i] ? W.sgn[i] : 0 })),
  });
  const out = {
    ...c, eps, p, q, n: N,
    gens, squares: { I: s(I_MASK, I_MASK), w6: s(W_MASK, W_MASK), G: s(G_MASK, G_MASK) }, sIW: s(I_MASK, W_MASK),
    Iw: commutes(s, I_MASK, W_MASK), Ibiv: bivs.filter(b => commutes(s, I_MASK, b)).length, wbiv: bivs.filter(b => commutes(s, W_MASK, b)).length, nbiv: bivs.length,
    Ganti: gens.filter(g => !commutes(s, G_MASK, g.mask)).length, Gbiv: BIV_ALL.filter(b => commutes(s, G_MASK, b)).length,
    cross, crossAnti: cross.filter(x => x.anti).length, bivCross, bivPairs: BIV_BASE.length * BIV_FIBRE.length,
    type, typeGraded, typeUngraded, baseRel: baseRelation(s),
    ideal: { m: ideal.m, k: G.length, labels: G, minimal: ideal.m === minimalIdealDim(type), diagonal: H.diagonal },
    halves: [half(1, H.plus), half(-1, H.minus)],
  };
  MEMO.set(key, out);
  return out;
}
/** a label of the ten bits in a lens of the kernel's printer (clifford, bits, primes, set …), or in the rows' own names e₀ … e₉ when no lens is given */
export function nameOf(mask, lens = null, eps = null) {
  if (lens) return label(mask, lens, eps || concatEps());
  const b = bitsOf(mask); return b.length ? b.map(i => 'e' + subs(i)).join('') : '1';
}

// ------------------------------------------------------------------------------------------------------------------------ the fb.CHI lines (Cl(1,9), graded)
/**
 * The facts of the [bit] and [ctl] fb.CHI lines of fibre_base.log for Cl(1,3) ⊗̂ Cl(0,6) = Cl(1,9), recomputed on the kernel (tests/physics/p13.test.mjs
 * reads them against the lines): (1) Γ² = +1, Γ anticommutes with the ten generators and commutes with the 45 bivectors; with Γ among five commuting
 * even labels of square +1 the minimal ideal has dimension 32 and Γ is diagonal on it, 16 + 16; (2) the commutant of the even part (generated by the
 * e₀e_k) on each half and on the 32; (3) Γ = +I ω₆, I² = ω₆² = −1, I and ω₆ commuting with each other and with the 6 + 15 bivectors; (4) I = −ω₆ on
 * Γ = +1, I = +ω₆ on Γ = −1; (5) the commutants of so(1,3), so(6) and both on a half, and of both on the 32; (6) e₀e_k = σ I R_k with one σ for the
 * three, and the commutant of the fibre's so(6) on the minimal ideal of Cl(0,6) (8 = 𝕆 by fb.OCT); (7) the other sign: s(I, ω₆) is not −1, and
 * I = +ω₆ fails on the half Γ = +1. Commutant dimensions are real dimensions (ℝ 1, ℂ 2, ℝ ⊕ ℝ 2, ℂ ⊕ ℂ 4, M₂(ℂ) 8, M₄(ℂ) 32).
 */
export function chiFacts() {
  const eps = concatEps('1,3', '0,6'), s = signOf('graded', eps);
  const G = commutingLabels(s, N, [G_MASK], true), ideal = idealOf(s, N, G), Hv = halvesOf(ideal), P = Hv.plus, Q = Hv.minus;
  const I = ideal.act(I_MASK), W = ideal.act(W_MASK);
  const even = Array.from({ length: N - 1 }, (_, k) => ideal.act(1 | (1 << (k + 1))));   // e₀e_k, k = 1 … 9, up to sign: they generate the even part
  const dimOn = (ops, idx) => { const r = ops.map(X => restrict(X, idx)); return r.every(Boolean) ? commutantDim(r, idx.length) : null; };
  const acts = masks => masks.map(m => ideal.act(m));
  // the fibre alone: Cl(0,6) on its 64 labels, three commuting labels of square +1, its 15 bivectors on that ideal
  const e6 = FIBRES['0,6'], s6 = (a, b) => sign(a, b, e6), G6 = commutingLabels(s6, NF, [], false), id6 = idealOf(s6, NF, G6);
  const biv6 = []; for (let i = 0; i < NF; i++) for (let j = i + 1; j < NF; j++) biv6.push((1 << i) | (1 << j));
  const W6 = id6.act((1 << NF) - 1);
  return {
    line1: { G2: s(G_MASK, G_MASK), anti: Array.from({ length: N }, (_, i) => !commutes(s, G_MASK, 1 << i)).filter(Boolean).length,
      biv: BIV_ALL.filter(b => commutes(s, G_MASK, b)).length, k: G.length, gammaFirst: G[0] === G_MASK, evenLabels: G.every(g => popcount(g) % 2 === 0 && s(g, g) === 1),
      m: ideal.m, diagonal: Hv.diagonal, plus: P.length, minus: Q.length },
    line2: { plus: dimOn(even, P), minus: dimOn(even, Q), all: commutantDim(even, ideal.m) },
    line3: { sIW: s(I_MASK, W_MASK), I2: s(I_MASK, I_MASK), w2: s(W_MASK, W_MASK), Iw: commutes(s, I_MASK, W_MASK),
      Ibiv: [...BIV_BASE, ...BIV_FIBRE].filter(b => commutes(s, I_MASK, b)).length, wbiv: [...BIV_BASE, ...BIV_FIBRE].filter(b => commutes(s, W_MASK, b)).length,
      nbiv: BIV_BASE.length + BIV_FIBRE.length },
    line4: { plus: relOn(I, W, P), minus: relOn(I, W, Q) },
    line5: { base: dimOn(acts(BIV_BASE), P), fibre: dimOn(acts(BIV_FIBRE), P), both: dimOn(acts([...BIV_BASE, ...BIV_FIBRE]), P),
      both32: commutantDim(acts([...BIV_BASE, ...BIV_FIBRE]), ideal.m),
      I2onHalf: P.every(i => I.perm[I.perm[i]] === i && I.sgn[i] * I.sgn[I.perm[i]] === -1) },
    line6: { sigma: baseRelation(s), fibreIdeal: id6.m, fibreLabels: G6.length, so6: commutantDim(biv6.map(m => id6.act(m)), id6.m),
      w6Squares: W6.perm.every((j, i) => W6.perm[j] === i && W6.sgn[i] * W6.sgn[j] === -1) },
    line7: { sIW: s(I_MASK, W_MASK), plusFails: !P.every(i => I.perm[i] === W.perm[i] && I.sgn[i] === W.sgn[i]) },
  };
}
