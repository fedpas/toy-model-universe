// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/spinPhysics.js — the physics of step 5 (spin) that P6's figures print (docs/PHYSICS_AUDIT.md §2.5, SP1–SP4), recomputed through the one
// kernel (engines/bitrule.js sign, mul, square, label) and through engines/spinEngine.js (v15's widget routines, which take every sign from the kernel):
//   rotorAt(n)          SP1  the rotor R = cos t + B sin t of Cl(2,0) at t = n·15° and the vector R v R̃ (the kernel's mul), with the names of its states
//   chiralityXor()      SP2  ψ ↦ IψJ on the 8 even blades of Cl(1,3) (J = γ₂γ₁): the kernel's sign and the target mask x ⊕ 9
//   hestenesSample(kind, seed), hestenesAgreement(n)   SP2  ψψ̃ = a + bI and the pointor test of an even element (spinEngine.hestenes)
//   pointorSampleOf(kind, seed), pointorTally(n)        SP3  ψOψ̃ = λO in Cl(4,0) for the four kinds of v15's widget (spinEngine.pointorSample)
//   pointorLadder(stored, { top })                       SP3 + D37  the cells the check stores (spin.json pointors, theorem3), rung by rung from the
//                       lowest stored dimension up (or from the top, each lower cell as the restriction of the top one), the b_j and O of each rung,
//                       their squares in each stored signature (the kernel's square; = spin.json torus_algebra where it is stored); a rung with no
//                       stored cell is "not stored"
//   halvesAt(kind, n)   SP4  the weights of the all-plus spinor Φ₊ = B + I of Cl(3,0) in S⁺ and S⁻ after a rotor (MixHalves), at t = n·15°
// Pure functions, no randomness without a seed, no sentences: values, names of states and labels only (D26, D28).
import { mul, square, label, popcount } from '../bitrule.js';
import { planar, spinors, pointorSample, PKINDS, hestenes, chirality, EVEN } from '../spinEngine.js';

export const STEP_DEG = 15;
export const ROTOR_STEPS = 48;            // t = 0°, 15°, …, 720° (v15's dial: 48 steps of 15°, two full turns)
const E2 = [1, 1];
const near = (x, y, tol = 1e-9) => Math.abs(x - y) < tol;
const clean = x => (Math.abs(x) < 1e-12 ? 0 : x);

// ---------------------------------------------------------------- SP1: the rotor and the double cover, Cl(2,0) with u = e₁ (bit 0), v = e₂ (bit 1), B = uv = e₁₂
/** R = cos t + B sin t, its reverse cos t − B sin t (reversion flips the grade-2 part), and R v R̃ by the kernel's product, t = n·15° */
export function rotorAt(n) {
  const deg = n * STEP_DEG, t = (deg * Math.PI) / 180, a = clean(Math.cos(t)), b = clean(Math.sin(t));
  const R = new Map([[0, a], [3, b]]), Rrev = new Map([[0, a], [3, -b]]), v = new Map([[2, 1]]);
  const w = mul(mul(R, v, E2), Rrev, E2);
  const vec = [clean(w.get(1) || 0), clean(w.get(2) || 0)];          // R v R̃ = x·u + y·v
  const state = near(a, 1) ? '+1' : near(a, -1) ? '-1' : near(b, 1) ? 'B' : near(b, -1) ? '-B' : null;
  const back = near(vec[0], 0) && near(vec[1], 1);                    // the vector is back at v
  return { n, deg, vecDeg: (2 * deg) % 360, R: [a, b], vec, state, back, doubleCover: back && state === '-1' };
}
/** the 49 steps 0 … 48 */
export const rotorSteps = () => Array.from({ length: ROTOR_STEPS + 1 }, (_, n) => rotorAt(n));
/** v15's own route for the same step (spinEngine.planar, the kernel through mk), for the comparison of the test */
export const rotorV15 = n => planar((n * STEP_DEG * Math.PI) / 180);
/** the vector R v R̃ by name when it is ±u or ±v, else null */
export function vecName([x, y]) {
  if (near(x, 0) && near(y, 1)) return 'v';
  if (near(x, 0) && near(y, -1)) return '-v';
  if (near(x, 1) && near(y, 0)) return 'u';
  if (near(x, -1) && near(y, 0)) return '-u';
  return null;
}

// ---------------------------------------------------------------- SP2: Hestenes spinors in Cl(1,3) (bit 0 = γ₀ = t, bits 1–3 = γ₁ γ₂ γ₃; squares +1, −1, −1, −1)
export const CL13 = [1, -1, -1, -1];
export const I13 = 15;                                   // the pseudoscalar γ₀γ₁γ₂γ₃
export const J13 = { mask: 6, factors: [4, 2] };         // J = γ₂γ₁ (bit 2 then bit 1), the complex structure (an input: INP-067)
/** ψ ↦ I ψ J on each even blade e_x: the product I · e_x · J by the kernel, its mask and sign, and whether the mask is x ⊕ 9 */
export function chiralityXor() {
  const J = mul(new Map([[J13.factors[0], 1]]), new Map([[J13.factors[1], 1]]), CL13);
  return EVEN.map(x => {
    const y = mul(mul(new Map([[I13, 1]]), new Map([[x, 1]]), CL13), J, CL13), [m, s] = [...y][0];
    return { x, m, s, xor: x ^ m, ok: y.size === 1 && m === (x ^ 9) };
  });
}
/** the pairs {x, x ⊕ 9} of the even blades and the two eigenspaces of the involution (each pair gives one vector to each: dimension 4 each) */
export function chiralityPairs() {
  const T = chiralityXor(), seen = new Set(), pairs = [];
  for (const r of T) if (!seen.has(r.x)) { seen.add(r.x); seen.add(r.m); pairs.push([r.x, r.m, r.s]); }
  return { pairs, plus: pairs.length, minus: pairs.length };
}
/** v15's route (spinEngine.chirality), for the comparison of the test */
export const chiralityV15 = () => chirality();
/** one sample: ψψ̃ = a + bI, any other grade left over, and the pointor test ψIψ̃ ∝ I (spinEngine.hestenes, seeded) */
export function hestenesSample(kind, seed) {
  const h = hestenes(kind === 'versor' ? 'versor' : 'generic', seed);
  return { kind: kind === 'versor' ? 'versor' : 'generic', seed, a: clean(h.a), b: clean(h.b), other: h.other, pointor: h.ok, agrees: h.ok === near(h.b, 0) && !h.other };
}
/** over n random even elements (seeds 1 … n): in how many "pointor" and "b = 0" agree (v15's widget: 24) */
export function hestenesAgreement(n = 24) {
  let agree = 0; for (let s = 1; s <= n; s++) { const h = hestenes('generic', s); if (h.ok === near(h.b, 0)) agree++; }
  return { agree, of: n };
}

// ---------------------------------------------------------------- SP3: pointors, ψOψ̃ = λO in Cl(4,0), O = e₁₂₃₄
export const POINTOR_KINDS = PKINDS;                  // flatland, vR, unrelated, versor (v15's order)
/** one sample of a kind (spinEngine.pointorSample: the kernel through mk) */
export function pointorSampleOf(kind, seed) {
  const k = PKINDS.includes(kind) ? kind : 'vR', r = pointorSample(k, seed);
  return { kind: k, seed, text: r.txt, pointor: r.ok, lambda: r.ok ? clean(r.lam) : null };
}
/** the pointors among n samples of each kind (seeds 1 … n; v15's table: 12) */
export function pointorTally(n = 12) {
  return Object.fromEntries(PKINDS.map(k => [k, Array.from({ length: n }, (_, i) => pointorSample(k, i + 1).ok).filter(Boolean).length]));
}

// ---------------------------------------------------------------- D37: the ladder of the stored pointor cells
/** "4,[1, -1, -1, -1]" → { d: 4, sig: [1, -1, -1, -1], p, q } */
export function parseCellKey(key) {
  const m = /^(\d+),\s*\[([^\]]*)\]$/.exec(String(key));
  if (!m) return null;
  const sig = m[2].split(',').map(s => Number(s.trim())).filter(x => Number.isFinite(x));
  return { d: Number(m[1]), sig, p: sig.filter(x => x === 1).length, q: sig.filter(x => x === -1).length };
}
/** the pair bivectors b_j = mask 3·4^(j−1) of a dimension d (k = ⌊d/2⌋ of them) and the point O = mask 2^d − 1 */
export function pairMasks(d) { const k = Math.floor(d / 2); return { k, b: Array.from({ length: k }, (_, j) => 3 << (2 * j)), O: (1 << d) - 1 }; }
/** a mask in the label of a D37 lens: clifford (e-words), simplex (sets), cube (bits), demicube (bits of an even corner), prime (products of primes) */
export function lensLabel(mask, lens, d) {
  const eps = Array(Math.max(1, d)).fill(1);
  switch (lens) {
    case 'simplex': return label(mask, 'set', eps);
    case 'cube': return label(mask, 'bits', eps);
    case 'demicube': return `${label(mask, 'bits', eps)}${popcount(mask) % 2 === 0 ? ' even' : ' odd'}`;
    case 'prime': return label(mask, 'primes', eps);
    default: return label(mask, 'clifford', eps);
  }
}
export const D37_LENSES = ['clifford', 'simplex', 'cube', 'demicube', 'prime'];
/**
 * The rungs of the stored pointor cells: d from the lowest stored dimension to the highest (each d once; a d with no stored cell is "not stored");
 * at each rung its b_j and O, and for each stored signature the squares b_j² and O² (the kernel's square) and the stored tallies of spin.json
 * (pointors: sum_is_pointor, even_part_is_versor_like; theorem3: the three tallies). top: the rungs from the highest down, each with the masks of
 * the top cell restricted to its first d bits (the restriction of O_top is O_d, of the b_j of the top the first k).
 */
export function pointorLadder(stored, { top = false } = {}) {
  const P = (stored && stored.pointors) || {}, T = (stored && stored.theorem3) || {}, TA = (stored && stored.torus_algebra) || {};
  const cells = new Map();
  const at = (key, kind, val) => { const c = parseCellKey(key); if (!c) return; const k = `${c.d}|${c.sig.join(',')}`; if (!cells.has(k)) cells.set(k, { ...c, key: `${c.d},[${c.sig.join(', ')}]` }); cells.get(k)[kind] = val; };
  for (const [k, v] of Object.entries(P)) at(k, 'pointors', v);
  for (const [k, v] of Object.entries(T)) at(k, 'theorem3', v);
  const all = [...cells.values()];
  if (!all.length) return { rungs: [], dMin: null, dMax: null, top };
  const dMin = Math.min(...all.map(c => c.d)), dMax = Math.max(...all.map(c => c.d)), topMasks = pairMasks(dMax);
  const rungs = [];
  for (let d = dMin; d <= dMax; d++) {
    const own = pairMasks(d), restricted = { b: topMasks.b.slice(0, own.k), O: topMasks.O & ((1 << d) - 1) };
    const here = all.filter(c => c.d === d).sort((x, y) => y.p - x.p || x.q - y.q).map(c => {
      const sq = { b: own.b.map(m => square(m, c.sig)), O: square(own.O, c.sig) };
      const ta = TA[`[${c.sig.join(', ')}]`] || null;
      return { ...c, squares: sq, torus: ta, pointors: c.pointors || null, theorem3: c.theorem3 || null };
    });
    rungs.push({ d, k: own.k, b: own.b, O: own.O, restricted, sameAsTop: restricted.O === own.O && restricted.b.every((m, j) => m === own.b[j]), cells: here, stored: here.length > 0 });
  }
  return { rungs: top ? rungs.slice().reverse() : rungs, dMin, dMax, top };
}

// ---------------------------------------------------------------- SP4: the halves of Cl(3,0), Spin(2) keeps S⁺, Spin(3) mixes S⁺ and S⁻ (v15's MixHalves)
let SP3 = null; const sp3 = () => SP3 || (SP3 = spinors(1));
/** kind 'B': the plane rotor cos t + B sin t; kind 'w': cos t + sin t · w v (with the extra reflection w). Returns the weights |even part| / |Φ₊| and
 *  |odd part| / |Φ₊| of R Φ₊ (the split by w X w⁻¹), and whether R Φ₊ = ±Φ₊ */
export function halvesAt(kind, n) {
  const P = sp3(), E = P.E, deg = n * STEP_DEG, t = (deg * Math.PI) / 180, a = Math.cos(t), s = Math.sin(t);
  const Pl = P.phi([1]), G = kind === 'w' ? E.mul(P.w, P.v(0)) : P.B(0), R = E.add(E.scale(E.one, a), E.scale(G, s)), X = E.mul(R, Pl), wi = E.inv(P.w);
  const sw = E.mul(E.mul(P.w, X), wi), ev = E.scale(E.add(X, sw), 0.5), od = E.scale(E.add(X, sw, -1), 0.5);
  const nr = M => Math.sqrt([...M.values()].reduce((q, x) => q + x * x, 0)), n0 = nr(Pl);
  return { kind: kind === 'w' ? 'w' : 'B', n, deg, even: clean(nr(ev) / n0), odd: clean(nr(od) / n0), mixes: nr(od) / n0 > 1e-9, plus: E.eq(X, Pl), minus: E.eq(X, E.scale(Pl, -1)) };
}
