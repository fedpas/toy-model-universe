// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/gauge.js — steps 6–8 of the equations (owner P7, docs/PHYSICS_AUDIT.md §2.6–2.8): the coupled Dirac–Maxwell system on Cl(1, n−1), n = 1 … 8,
// the gauge algebra so(m) of the bivectors of Cl(0, m), m = 2 … 8, and matter charged under it (the internal blades of Cl(0, m) under left multiplication).
// Every product and sign comes from the kernel (engines/bitrule.js: sign, mul, cell, label, popcount); the algebra names from the clock the kernel's squares give
// (engines/labels.js clockByKernel). Nothing here multiplies two blades by itself (tests/shipped.test.mjs rule 4). The functions rebuild, field by field, what
// checks/selfcheck/coupling_selfcheck.py, yangmills_selfcheck.py and matter_selfcheck.py store (coupling.json, yangmills.json, matter.json, shipped to the app as
// content/stored_p7.json); tests/physics/p7.test.mjs compares every rung with the stored one. The identities and the numpy matrix checks are not re-run here
// (D11): the figures print them from the stored table. Data only, no sentence (D28): names, numbers, signs and blades.
import { sign, mul, cell, label, popcount } from '../bitrule.js';
import { clockByKernel, TYPES, FIELD_DIM } from '../labels.js';

const range = n => Array.from({ length: n }, (_, i) => i);
export const comb = (a, b) => { if (b < 0 || b > a) return 0; let r = 1; for (let i = 1; i <= b; i++) r = (r * (a - b + i)) / i; return Math.round(r); };
const one = () => new Map([[0, 1]]);
const bl = (m, c = 1) => new Map([[m, c]]);
/** the blade and sign of a product of blades in the given order, by the kernel (mul of single blades) */
export function bladeProduct(masks, eps) {
  let x = one();
  for (const m of masks) x = mul(x, bl(m), eps);
  const [[k, s]] = [...x];
  return { mask: k, sign: s };
}
/** the sign that reversion puts on a blade of grade k: the square of e_T among generators that square to +1 (the kernel's sign in Cl(n, 0)) */
const revSign = (T, n) => sign(T, T, cell(n, 0));

// ---------------------------------------------------------------- the stored ranges (the cells the scripts ran)
export const COUPLING_NS = [1, 2, 3, 4, 5, 6, 7, 8];
export const GAUGE_MS = [2, 3, 4, 5, 6, 7, 8];
/** the standard names of so(m) (D29: standard), as v15 listed them */
export const YM_STANDARD = { 2: 'u(1)', 3: 'su(2)', 4: 'su(2) + su(2)', 5: 'sp(2)', 6: 'su(4)', 7: 'so(7)', 8: 'so(8)' };
/** the standard names of the matter modules (standard), as v15 listed them; '—' where v15 gave none */
export const MATTER_KNOWN = { 2: 'u(1) on one quaternion module', 3: 'su(2): two doublets', 4: 'su(2) + su(2) doublets', 5: '—', 6: '—', 7: '—', 8: '—' };

// ---------------------------------------------------------------- names (v15's printing: couplingCopy axname, yangmillsCopy gname, matterCopy nodeName / bitRow)
export const AXES = ['t', 'x', 'y', 'z', 'u', 'v', 'w', 's'];
const bitsOf = m => range(12).filter(i => Math.floor(m / 2 ** i) % 2 === 1);
/** a space-time blade by its axes: 1 → t, 6 → xy, 0 → 1 */
export const axName = m => bitsOf(m).map(i => AXES[i]).join('') || '1';
/** an internal blade or a generator by its indices, 1-based: 3 → 12, 7 → 123 */
export const genName = m => bitsOf(m).map(i => i + 1).join('');
export const nodeName = m => (m === 0 ? '1' : genName(m));
/** a label as its row of switches, switch 1 first (the learner's picture of an internal blade) */
export const switchRow = (x, m) => range(m).map(i => Math.floor(x / 2 ** i) % 2).join('');
/** the label of a blade in a lens (the lens changes the printing, never the blade): clifford e-words, simplex the set, cube and demicube the bits, prime
 *  the product of primes — all by the kernel's printer (bitrule.label); with no lens the v15 names (axes for space-time, indices for the internal cell) */
export function labelIn(lens, mask, { n, kind = 'st' }) {
  const eps = kind === 'st' ? cell(1, n - 1) : cell(0, n);
  switch (lens) {
    case 'clifford': return label(mask, 'clifford', eps);
    case 'simplex': return label(mask, 'set', eps);
    case 'cube': case 'demicube': return label(mask, 'bits', eps);
    case 'prime': return label(mask, 'primes', eps);
    default: return kind === 'st' ? axName(mask) : nodeName(mask);
  }
}

// ---------------------------------------------------------------- algebra names from the kernel's clock
/** Cl(p, q) = M_N(base), twice for the types R2 and H2: the type from the clock the kernel's squares give */
export function algebraParts(p, q) {
  const n = p + q;
  if (n === 0) return { N: 1, base: 'R', copies: 1 };
  const t = TYPES[clockByKernel(p, q)], copies = t === 'R2' || t === 'H2' ? 2 : 1, base = t[0];
  const N = Math.round(Math.sqrt(2 ** n / (copies * FIELD_DIM[base])));
  return { N, base, copies };
}
/** Cl(p, q) printed as the selfcheck scripts print it: 'R' for n = 0, 'M2(C)', 'M1(R) + M1(R)' */
export function algebraOf(p, q) {
  if (p + q === 0) return 'R';
  const { N, base, copies } = algebraParts(p, q), a = `M${N}(${base})`;
  return copies === 2 ? `${a} + ${a}` : a;
}

// ================================================================ step 6: Maxwell meets Dirac on Cl(1, n−1)
/** J: the bivectors of Cl(1, n−1) that square to −1 and commute with γ₀ (the kernel's square and the two orders of the product), and J = γ₂γ₁ (mask 6) */
export function complexStructure(n) {
  const eps = cell(1, n - 1), biv = range(1 << n).filter(m => popcount(m) === 2);
  const candidates = biv.filter(m => sign(m, m, eps) === -1 && sign(m, 1, eps) === sign(1, m, eps));
  const exists = candidates.length > 0;
  return { exists, count: candidates.length, candidates, mask: exists ? 6 : null, sign: exists ? bladeProduct([1 << 2, 1 << 1], eps).sign : null, square: exists ? sign(6, 6, eps) : null };
}

/** The coupled Dirac equation D = ∇ψJ − eAψ − mψγ₀ as incidences (the generalisation of spinEngine.diracPic with the A terms): for every even blade S
 *  (a component of ψ) and axis k, the derivative term γ_k ∂_k ψ_S J lands on (k ⊕ S) ⊕ J, the coupling term γ_k A_k ψ_S on k ⊕ S, and the mass term ψ_S γ₀ on
 *  S ⊕ t; the sign of each is the kernel's (the coefficient −e or −m stays outside). Without J (n = 1, 2) there is no derivative term of this form. */
export function couplingCell(n) {
  const eps = cell(1, n - 1), N = 1 << n, J = complexStructure(n);
  const even = range(N).filter(m => popcount(m) % 2 === 0), odd = range(N).filter(m => popcount(m) % 2 === 1);
  const incidences = [];
  for (const S of even) {
    for (let k = 0; k < n; k++) {
      if (J.exists) { const p = bladeProduct([1 << k, S, J.mask], eps); incidences.push({ kind: 'd', axis: k, from: S, to: p.mask, sign: p.sign * J.sign }); }
      const a = bladeProduct([1 << k, S], eps); incidences.push({ kind: 'A', axis: k, from: S, to: a.mask, sign: a.sign });
    }
    const m = bladeProduct([S, 1], eps); incidences.push({ kind: 'm', axis: 0, from: S, to: m.mask, sign: m.sign });
  }
  const count = kd => incidences.filter(i => i.kind === kd).length;
  const equations = odd.map(T => ({ to: T, terms: incidences.filter(i => i.to === T) }));
  // the coupling terms of the equation at T sit on its n even neighbours (pairwise two bits apart: a simplex, the corner simplex); the mass term is one of them;
  // the derivative terms sit on the same neighbours moved by J (coupling_selfcheck.py ladder_row)
  let simplex = null;
  if (J.exists) {
    simplex = odd.every(T => {
      const nb = range(n).map(k => T ^ (1 << k));
      return nb.every(x => popcount(x) % 2 === 0) && new Set(nb).size === n && nb.includes(T ^ 1)
        && nb.every((x, i) => nb.every((y, j) => i === j || popcount(x ^ y) === 2));
    });
  }
  // the coupling uses the cube edges (S, k) that the derivative's left factor γ_k already uses: the edges it adds
  const cubeEdges = kd => new Set(incidences.filter(i => i.kind === kd).map(i => `${i.from},${i.axis}`));
  const dEdges = cubeEdges('d'), newEdges = J.exists ? [...cubeEdges('A')].filter(e => !dEdges.has(e)).length : null;
  return {
    n, eps, J, even, odd, incidences, equations, simplex, newEdges,
    counts: { derivative_edges: J.exists ? count('d') : null, coupling_edges: count('A'), mass_edges: count('m'), incidences_total: J.exists ? incidences.length : null, terms_per_equation: J.exists ? 2 * n + 1 : null },
  };
}

/** The equation at the odd blade t (the γ₀ component), as the ring draws it: inner ring the coupling terms A_k ψ on its n even neighbours (the time one also
 *  carries the mass term), outer ring the derivative terms ∂_k ψ on the same neighbours moved by J; each with its blade and the kernel's sign. */
export function couplingRing(n) {
  const C = couplingCell(n), at = C.incidences.filter(i => i.to === 1);
  const inner = range(n).map(k => { const i = at.find(x => x.kind === 'A' && x.axis === k); return { k, axis: AXES[k], blade: i.from, sign: i.sign }; });
  const outer = C.J.exists ? range(n).map(k => { const i = at.find(x => x.kind === 'd' && x.axis === k); return { k, axis: AXES[k], blade: i.from, sign: i.sign }; }) : [];
  const m = at.find(x => x.kind === 'm');
  return { n, J: { exists: C.J.exists, mask: C.J.mask, sign: C.J.sign, count: C.J.count }, inner, outer, mass: { blade: m.from, sign: m.sign }, terms: at.length, simplex: C.simplex };
}

/** The current X = ψγ₀ψ̃ term by term: for every pair of even blades (S, T) the blade S·γ₀·T with the kernel's signs and the reversion sign of T, the pairs
 *  {S, T} gathered; returns blade → Map(pair key → coefficient) without the zeros (coupling_selfcheck.py current_structure). p: generators that square to +1. */
export function currentStructure(n, p = 1) {
  const eps = cell(p, n - p), N = 1 << n, even = range(N).filter(m => popcount(m) % 2 === 0), out = new Map();
  for (const S of even) for (const T of even) {
    const b = bladeProduct([S, 1, T], eps), c = b.sign * revSign(T, n), key = Math.min(S, T) * N + Math.max(S, T);
    if (!out.has(b.mask)) out.set(b.mask, new Map());
    const row = out.get(b.mask); row.set(key, (row.get(key) || 0) + c);
  }
  for (const [m, row] of out) { for (const [k, v] of row) if (v === 0) row.delete(k); if (!row.size) out.delete(m); }
  return { n, N, even, blades: out };
}

const frac = (a, b) => { let x = a, y = b; while (y) [x, y] = [y, x % y]; return b / x === 1 ? String(a / x) : `${a / x}/${b / x}`; };
/** one rung of the coupling ladder, every field as coupling_selfcheck.py ladder_row stores it, recomputed here (structure through the kernel; the spinor
 *  dimensions 2^⌊n/2⌋ complex by the standard formula, Lawson–Michelsohn) */
export function couplingRow(n) {
  const C = couplingCell(n), X = currentStructure(n), N = 1 << n;
  const grades = [...new Set([...X.blades.keys()].map(popcount))].sort((a, b) => a - b);
  const byGrade = g => [...X.blades].filter(([m]) => popcount(m) === g);
  const dist = {}; for (const [m, row] of X.blades) for (const key of row.keys()) { const S = Math.floor(key / N), T = key % N, g = popcount(m); (dist[g] = dist[g] || new Set()).add(popcount(S ^ T)); }
  const rho = X.blades.get(1);
  const comp = {}; for (let k = 1; k < n; k++) comp[String(k)] = (X.blades.get(1 << k) || new Map()).size;
  let posFor = null;
  if (n <= 6) { posFor = []; for (let p = 0; p <= n; p++) { const r = currentStructure(n, p).blades.get(1); if (r && [...r.values()].every(c => c > 0)) posFor.push(p); } }
  const dirac = 2 ** (Math.floor(n / 2) + 1);
  return {
    n, signature: `1+${n - 1}`, algebra: algebraOf(1, n - 1), even_half: n === 1 ? algebraOf(0, 0) : algebraOf(1, n - 2),
    psi_components: C.even.length, dirac_real_dim: dirac, psi_over_dirac: frac(C.even.length, dirac),
    F_components: range(N).filter(m => popcount(m) === 2).length, maxwell_incidences: range(N).filter(m => popcount(m) === 2).length * n,
    J_exists: C.J.exists, J_count: C.J.count,
    current_grades: grades,
    current_blades: Object.fromEntries(grades.map(g => [String(g), byGrade(g).length])),
    current_monomials: Object.fromEntries(grades.map(g => [String(g), byGrade(g).reduce((s, [, row]) => s + row.size, 0)])),
    pair_distance: Object.fromEntries(Object.keys(dist).sort((a, b) => a - b).map(g => [String(g), [...dist[g]].sort((a, b) => a - b)])),
    rho_terms: rho.size, rho_positive_definite: [...rho.values()].every(c => c > 0), rho_positive_definite_for_p: posFor,
    edge_terms_per_spatial_component: comp,
    demicube_edges_of_type_0k: n >= 2 ? C.even.filter(S => S < (S ^ 3)).length : 0,
    even_corners: C.even.length, odd_corners: C.odd.length,
    coupling_edges: C.counts.coupling_edges, mass_edges: C.counts.mass_edges, derivative_edges: C.counts.derivative_edges, incidences_total: C.counts.incidences_total,
    coupling_terms_are_corner_simplex: C.simplex,
    even_labels: n <= 5 ? C.even : null, gamma0_label: 1, J_label: C.J.exists ? C.J.mask : null,
  };
}

/** the solutions of the free Dirac symbol on the mass shell, p = (m, 0, …, 0): the column of ψ_S is (γ₀ e_S + e_S γ₀) on the blade S ⊕ t, so the real kernel is
 *  the number of even S whose two kernel signs cancel (coupling_selfcheck.py kernel_dim); half of ψ and one Dirac spinor (2^⌊n/2⌋) beside it */
export function shellRow(n) {
  const eps = cell(1, n - 1), even = range(1 << n).filter(m => popcount(m) % 2 === 0);
  const kernel = even.filter(S => bladeProduct([1, S], eps).sign + bladeProduct([S, 1], eps).sign === 0).length;
  return { kernel_real_dim: kernel, half_of_psi: 2 ** (n - 2), one_dirac_spinor: 2 ** Math.floor(n / 2) };
}

// ================================================================ step 7: Yang–Mills with the gauge algebra so(m) of the bivectors of Cl(0, m)
const MODELS = new Map();
/** the generators B_ab (masks of two indices, a < b, in v15's order), the structure constants [B_a, B_b] = (s(a,b) − s(b,a)) B_{a⊕b} from the kernel's two orders,
 *  the pairs that do not commute (sharing one index), those that commute, the index triples (each a closed so(3)) and the neighbours of each generator */
export function soAlgebra(m) {
  if (MODELS.has(m)) return MODELS.get(m);
  const eps = cell(0, m), gens = [];
  for (let i = 0; i < m; i++) for (let j = i + 1; j < m; j++) gens.push((1 << i) | (1 << j));
  const idx = new Map(gens.map((g, k) => [g, k])), f = [];
  for (let a = 0; a < gens.length; a++) for (let b = 0; b < gens.length; b++) {
    const s1 = bladeProduct([gens[a], gens[b]], eps), s2 = bladeProduct([gens[b], gens[a]], eps);
    if (s1.sign !== s2.sign) f.push({ a, b, c: idx.get(s1.mask), coef: s1.sign - s2.sign });
  }
  const edges = f.filter(x => x.a < x.b).map(x => [gens[x.a], gens[x.b]]);
  const neighbours = new Map(gens.map(g => [g, edges.filter(([x, y]) => x === g || y === g).map(([x, y]) => (x === g ? y : x))]));
  const triples = []; for (let x = 0; x < 1 << m; x++) if (popcount(x) === 3) triples.push(x);
  const fOf = (a, b) => f.find(x => x.a === idx.get(a) && x.b === idx.get(b));
  const closed = triples.every(t => { const [i, j, k] = bitsOf(t), A = (1 << i) | (1 << j), B = (1 << j) | (1 << k), Cg = (1 << i) | (1 << k);
    const ab = fOf(A, B), bc = fOf(B, Cg), ac = fOf(A, Cg); return !!(ab && bc && ac) && gens[ab.c] === Cg && gens[bc.c] === A && gens[ac.c] === B; });
  const degrees = [...new Set([...neighbours.values()].map(x => x.length))];
  const model = { m, eps, gens, idx, f, edges, neighbours, triples, closed, degrees, commuting: comb(gens.length, 2) - edges.length };
  MODELS.set(m, model);
  return model;
}
/** [B_a, B_b] = coef · B_{a⊕b} (coef ±2) or 0, from the kernel */
export function commutator(m, a, b) {
  const eps = cell(0, m), x = bladeProduct([a, b], eps), y = bladeProduct([b, a], eps);
  return { mask: x.mask, coef: x.sign - y.sign };
}
/** the terms of the Yang–Mills system for gauge dimension m in ns space-time dimensions, counted on the structure constants (yangmills_selfcheck.py term_counts) */
export function ymTermCounts(m, ns) {
  const A = soAlgebra(m), G = A.gens.length;
  const quadOf = a => A.f.filter(x => x.c === a).length;   // the ordered pairs (b, c) whose commutator lands on a
  const quads = [...new Set(range(G).map(quadOf))], quad = quads.length === 1 ? quads[0] : null, tri = comb(ns, 3);
  const deriv = G * ns * (ns - 1), gauge = range(G).reduce((s, a) => s + ns * (ns - 1) * quadOf(a), 0);
  const biD = 3 * G * tri, biG = range(G).reduce((s, a) => s + 3 * tri * quadOf(a), 0);
  return { F_components: G * comb(ns, 2), quadratic_terms_per_F_component: quad, equations: G * ns, equation_derivative_terms: deriv, equation_gauge_terms: gauge,
    equation_terms: deriv + gauge, bianchi_equations: G * tri, bianchi_derivative_terms: biD, bianchi_gauge_terms: biG, bianchi_terms: biD + biG };
}
/** one rung of the gauge ladder at space-time 1 + 3 (yangmills.json ladder) */
export function ymRow(m) {
  const A = soAlgebra(m);
  return { gens: A.gens.length, noncommuting_pairs: A.edges.length, commuting_pairs: A.commuting, triangles: A.triples.length,
    neighbours_of_each_generator: A.degrees.length === 1 ? A.degrees[0] : null, algebra_cell: algebraOf(0, m), even_half: algebraOf(0, m - 1),
    labels: m <= 5 ? A.gens : null, ...ymTermCounts(m, 4) };
}
export const ymSpacetimeRow = ns => ({ m: 3, ...ymTermCounts(3, ns) });
/** m = 2: one generator, no commutator: the vector terms and the Bianchi terms add up to the Maxwell incidences n·C(n, 2) */
export function maxwellReductionRow(ns) {
  const t = ymTermCounts(2, ns), total = t.equation_terms + t.bianchi_terms;
  return { vector_terms: t.equation_terms, bianchi_terms: t.bianchi_terms, total, equals_n_times_C_n_2: total === ns * comb(ns, 2) };
}
/** the commutator of two multivectors of Cl(0, m), xy − yx, by the kernel's mul */
export function mvCommutator(x, y, m) {
  const eps = cell(0, m), a = mul(x, y, eps), b = mul(y, x, eps), out = new Map(a);
  for (const [k, v] of b) out.set(k, (out.get(k) || 0) - v);
  for (const [k, v] of out) if (v === 0) out.delete(k);
  return out;
}
const sameMv = (x, y) => x.size === y.size && [...x].every(([k, v]) => y.get(k) === v);
const scaleMv = (x, t) => new Map([...x].map(([k, v]) => [k, t * v]));
/** so(4) = two commuting triples B₁₂ + s₁B₃₄, B₁₃ + s₂B₂₄, B₁₄ + s₃B₂₃ and the same with −: the first signs (in yangmills_selfcheck.py's order of search) for
 *  which every cross commutator vanishes and each triple closes, from the kernel's commutators */
export function so4Split() {
  const B = (i, j) => (1 << i) | (1 << j), pairs = [[B(0, 1), B(2, 3)], [B(0, 2), B(1, 3)], [B(0, 3), B(1, 2)]];
  const order = [[1, 1, 1], [1, 1, -1], [1, -1, 1], [1, -1, -1], [-1, 1, 1], [-1, 1, -1], [-1, -1, 1], [-1, -1, -1]];
  const closed = S => S.every((x, i) => S.every((y, j) => i >= j || (() => { const r = mvCommutator(x, y, 4); return S.some(z => [2, -2, 4, -4].some(t => sameMv(r, scaleMv(z, t)))); })()));
  for (const sg of order) {
    const mk = s => pairs.map(([p, q], i) => new Map([[p, 1], [q, s * sg[i]]]));
    const X = mk(1), Y = mk(-1);
    if (X.every(x => Y.every(y => mvCommutator(x, y, 4).size === 0)) && closed(X) && closed(Y)) {
      return { found: true, self_dual_signs: sg, ideals_commute: true, each_ideal_closed: true, dimension_each: 3, triples: [X, Y].map(S => S.map(x => [...x])) };
    }
  }
  return { found: false };
}

// ================================================================ step 8: matter with an internal blade of Cl(0, m)
/** the even and the odd internal blades of Cl(0, m) */
export function internalHalves(m) { const all = range(1 << m); return [all.filter(x => popcount(x) % 2 === 0), all.filter(x => popcount(x) % 2 === 1)]; }
/** the left action of the generator g (a mask of two indices) on every internal blade: B_g e_T = s e_{g⊕T}, s the kernel's sign */
export function leftAction(m, g) {
  const eps = cell(0, m);
  return range(1 << m).map(T => { const p = bladeProduct([g, T], eps); return { from: T, to: p.mask, sign: p.sign }; });
}
/** the lines of the generator g in each half: the unordered pairs {T, g⊕T} (a perfect matching of the half: 2^{m−2} pairs) */
export function matching(m, g) {
  const act = leftAction(m, g);
  return internalHalves(m).map(half => half.filter(T => T < act[T].to).map(T => ({ a: T, b: act[T].to, sign: act[T].sign, back: act[act[T].to].sign })));
}
/** the lines of a half: two blades that differ in two bits (a demicube edge), each joined by exactly one generator (their XOR) */
export function halfEdges(m, h) {
  const nodes = internalHalves(m)[h], out = [];
  for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) if (popcount(nodes[i] ^ nodes[j]) === 2) out.push([nodes[i], nodes[j]]);
  return out;
}
/** the module data of Cl(0, m) under left multiplication (matter_selfcheck.py module_data): the cell, the summands, the real dimension of one module, its copies */
export function moduleOf(m) {
  const { N, base, copies } = algebraParts(0, m);
  return { internal_dim: 2 ** m, internal_cell: algebraOf(0, m), summands: copies, minimal_module_real_dim: N * FIELD_DIM[base], copies_of_each_module: N };
}
/** the terms of the matter equation E = Σ γ^μ (D_μ Ψ) J − mΨγ₀ in n space-time dimensions with the gauge algebra so(m), counted target by target (matter_selfcheck.py
 *  counts): every equation (an odd space-time blade and an internal blade) gets n derivative terms, n·G gauge terms and 1 mass term; and the current of the first
 *  generator, component by component: the pairs of components it multiplies (the corners S, S′ two masks apart) with the kernel's signs, the zeros dropped */
export function matterCounts(n, m) {
  const eps = cell(1, n - 1), epsI = cell(0, m), A = soAlgebra(m), G = A.gens.length, J = 6;
  const even = range(1 << n).filter(x => popcount(x) % 2 === 0), Ts = range(1 << m), targets = new Map();
  const hit = (o, T, kd) => { const key = o * (1 << m) + T; if (!targets.has(key)) targets.set(key, { d: 0, g: 0, m: 0, odd: popcount(o) % 2 === 1 }); targets.get(key)[kd]++; };
  const left = A.gens.map(g => Ts.map(T => bladeProduct([g, T], epsI)));
  for (const S of even) for (const T of Ts) {
    for (let mu = 0; mu < n; mu++) {
      const o = bladeProduct([1 << mu, S, J], eps).mask;
      hit(o, T, 'd');
      for (let a = 0; a < G; a++) hit(o, left[a][T].mask, 'g');
    }
    hit(bladeProduct([S, 1], eps).mask, T, 'm');
  }
  const per = [...new Set([...targets.values()].map(v => v.d + v.g + v.m))];
  const uniform = [...targets.values()].every(v => v.d === n && v.g === n * G && v.m === 1 && v.odd);
  const masks = {}, distance = {}, monomials = {};
  for (let nu = 0; nu < n; nu++) {
    const mask = bladeProduct([1 << nu, 1, J], eps).mask, coef = new Map();
    masks[String(nu)] = mask; distance[String(nu)] = popcount(mask);
    const sq = sign(1 << nu, 1 << nu, eps);
    for (const S of even) {
      const S2 = S ^ mask;
      if (popcount(S2) % 2) continue;
      for (const T of Ts) {
        const t = left[0][T], pr = bladeProduct([S, 1 << nu, S2, 1, J], eps);
        if (pr.mask !== 0) continue;
        const c = pr.sign * -1 * revSign(S, n) * sq * t.sign, A1 = [S, T], A2 = [S2, t.mask];
        const [x, y] = A1[0] < A2[0] || (A1[0] === A2[0] && A1[1] <= A2[1]) ? [A1, A2] : [A2, A1], key = `${x}|${y}`;
        coef.set(key, (coef.get(key) || 0) + c);
      }
    }
    monomials[String(nu)] = [...coef.values()].filter(c => c !== 0).length;
  }
  const comps = 2 ** (n - 1) * 2 ** m;
  return { targets: targets.size, uniform, components: comps, equations: comps, derivative_terms_per_equation: n, gauge_terms_per_equation: n * G, mass_terms_per_equation: 1,
    terms_per_equation: per.length === 1 ? per[0] : null, terms_total: comps * (n * (G + 1) + 1), gauge_terms_total: comps * n * G,
    current_monomials_per_component: monomials, current_corner_masks: masks, current_corner_distance: distance };
}
/** one rung of the matter ladder at space-time 1 + 3 (matter.json ladder) */
export function matterRow(m) { const { targets, uniform, ...c } = matterCounts(4, m); return { ...c, ...moduleOf(m), gens: comb(m, 2) }; }
export function matterSpacetimeRow(n) { const { targets, uniform, ...c } = matterCounts(n, 3); return { m: 3, ...c }; }

// ================================================================ D37: a lower cell as the restriction of the top one
/** true when every product of two blades of the first `low` generators has the same sign in the cell of `low` generators and in that of `top` (the kernel's
 *  sign), so that the lower cell is the restriction of the top one: kind 'coupling' for Cl(1, n−1), 'internal' for Cl(0, m) (so(m) ⊂ so(top) with it) */
export function restricts(kind, low, top) {
  const epsOf = k => (kind === 'coupling' ? cell(1, k - 1) : cell(0, k)), a = epsOf(low), b = epsOf(top);
  for (let x = 0; x < 1 << low; x++) for (let y = 0; y < 1 << low; y++) if (sign(x, y, a) !== sign(x, y, b)) return false;
  return true;
}
