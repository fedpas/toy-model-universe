// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/forquePhysics2.js — the physics of step 14 (forque) that P6's figures print (docs/PHYSICS_AUDIT.md §2.14, FQ1–FQ5), read from the stored
// checks (forque.json: the 41 rows with their dimensions and statuses; forque_matrix.json: the numerical cross-check) and recomputed where a route exists:
//   FORQUE_LINES               FQ1  the four lines of the dynamics (Table 2.1 of the paper) and the matrix rows that check each, as v15 listed them
//   linesLadder(rows, { top })  FQ1 + D37  the cells Cl(d,0,1) the rows were checked in (their stored dims), rung by rung from the lowest stored d up
//                              (or from the top down), with the rows of each line checked at each rung; the pseudoscalar I = ε·O of the rung and its
//                              square in the paper's signature (bit 0 null, bits 1 … d square +1: the stored conventions) by the kernel
//   matrixCheck(fqm)           FQ5  the numerical cross-check: what passes (errors of the equation as printed) and what must fail (three wrong versions)
//   racketRate(fqm)            FQ5  the tennis-racket rate: the stored prediction and measurement, and the prediction recomputed by forquePhysics.predictedRate
// Pure functions; values and the names v15 gave them, no sentences (D26, D28).
import { square } from '../bitrule.js';
import { predictedRate } from '../forquePhysics.js';

/** the four lines of Table 2.1 and the rows that check them (v15 ForqueSection: the line names and their row buttons) */
export const FORQUE_LINES = [
  { key: 'motion', name: 'Motion', rows: ['F11', 'F12', 'F13'] },
  { key: 'momentum', name: 'Momentum', rows: ['F16', 'F18', 'F19', 'F20'] },
  { key: 'forque', name: 'Forque', rows: ['F24'] },
  { key: 'dynamics', name: 'Dynamics', rows: ['F25', 'F26', 'F27'] },
];
/** the inertias of the tennis-racket run of forque_matrix_check.py (i1, i2, i3 = 5, 3, 1; also the start of the tennis-racket figure) */
export const RACKET_INERTIAS = [5, 3, 1];

/** the paper's signature in d dimensions: bit 0 = ε (square 0), bits 1 … d square +1 (forque.json conventions) */
export const pgaSquares = d => [0, ...Array(d).fill(1)];
/** I = ε·O of Cl(d,0,1): the mask of bits 0 … d */
export const pseudoMask = d => (1 << (d + 1)) - 1;
/** O = e₁ … e_d: the mask of bits 1 … d */
export const pointMask = d => ((1 << (d + 1)) - 1) & ~1;
/** a PGA mask by the paper's names (bit i → index i: e0, e1, …): e0123 for I in d = 3 */
export const pgaName = m => { let s = ''; for (let i = 0; i < 31; i++) if ((m >>> i) % 2) s += String(i); return s ? 'e' + s : '1'; };

/**
 * The rungs d (lowest stored dimension up, or from the top) of the rows' stored dims; for each the four lines with the rows checked at d, and the
 * squares of O and I = ε·O by the kernel. A line none of whose rows ran at d is "not stored" at that rung; a d inside the range that no row
 * reached is a rung marked not stored. The rows are forque.json rows ({ id, status, dims }).
 */
export function linesLadder(rows, { top = false } = {}) {
  const byId = new Map((rows || []).map(r => [r.id, r]));
  const dims = [...new Set((rows || []).flatMap(r => (Array.isArray(r.dims) ? r.dims : [])))].sort((a, b) => a - b);
  if (!dims.length) return { rungs: [], dMin: null, dMax: null, top };
  const dMin = dims[0], dMax = dims[dims.length - 1], rungs = [];
  for (let d = dMin; d <= dMax; d++) {
    const eps = pgaSquares(d), I = pseudoMask(d), O = pointMask(d);
    const lines = FORQUE_LINES.map(L => {
      const at = L.rows.filter(id => { const r = byId.get(id); return r && Array.isArray(r.dims) && r.dims.includes(d); });
      return { key: L.key, name: L.name, rows: L.rows, at, stored: at.length > 0, all: at.length === L.rows.length };
    });
    const any = (rows || []).filter(r => Array.isArray(r.dims) && r.dims.includes(d)).map(r => r.id);
    rungs.push({ d, I, O, squareI: square(I, eps), squareO: square(O, eps), lines, rows: any, stored: any.length > 0 });
  }
  return { rungs: top ? rungs.slice().reverse() : rungs, dMin, dMax, top };
}
/** the stored status of each line's rows: [{ id, status }] in the order of FORQUE_LINES (every one of them agrees exactly: FQ1's test) */
export function linesStatus(rows) {
  const byId = new Map((rows || []).map(r => [r.id, r]));
  return FORQUE_LINES.map(L => ({ ...L, status: L.rows.map(id => ({ id, status: byId.get(id) ? byId.get(id).status : null })) }));
}

/** the numerical cross-check of forque_matrix.json, as named numbers: the errors of the equation as printed (pass) and the three wrong versions (fail) */
export function matrixCheck(fqm) {
  const F = fqm || {};
  const pass = [
    { key: 'free_top', name: 'free top', what: 'position error', value: F.free_top && F.free_top.position_error, ok: !!(F.free_top && F.free_top.ok) },
    { key: 'gravity_top', name: 'heavy top', what: 'position error', value: F.gravity_top && F.gravity_top.position_error, ok: !!(F.gravity_top && F.gravity_top.ok) },
    { key: 'conservation', name: 'momentum', what: 'drift', value: F.conservation && F.conservation.momentum_drift, ok: !!(F.conservation && F.conservation.ok) },
    { key: 'spherical_top', name: 'spherical top', what: 'motor error', value: F.spherical_top && F.spherical_top.motor_error, ok: !!(F.spherical_top && F.spherical_top.ok) },
    { key: 'symmetric_top', name: 'symmetric top', what: 'motor error', value: F.symmetric_top && F.symmetric_top.motor_error, ok: !!(F.symmetric_top && F.symmetric_top.ok) },
    { key: 'initial_pose', name: 'initial pose', what: 'error', value: F.initial_pose_error, ok: Number.isFinite(F.initial_pose_error) },
    { key: 'motor_manifold', name: 'motor manifold', what: 'residual', value: F.motor_manifold_residual, ok: Number.isFinite(F.motor_manifold_residual) },
  ].filter(x => Number.isFinite(x.value));
  const N = F.negative_controls || {};
  const NAMES = { no_coriolis_term: 'no Coriolis term', wrong_sign_coriolis: 'wrong sign', wrong_kinematic_factor: 'wrong factor' };
  const fail = Object.keys(NAMES).filter(k => N[k]).map(k => ({ key: k, name: NAMES[k], what: 'position error', value: N[k].position_error, failsAsExpected: !!N[k].fails_as_expected }));
  const worst = pass.length ? Math.max(...pass.map(x => x.value)) : null;
  const leastWrong = fail.length ? Math.min(...fail.map(x => x.value)) : null;
  return { pass, fail, worst, leastWrong, representation: F.representation || null, body: F.body || null };
}
/** the tennis-racket rate: stored prediction and measurement of the numpy run, and the prediction recomputed for the run's inertias (5, 3, 1) */
export function racketRate(fqm) {
  const T = (fqm && fqm.tennis_racket) || {};
  return { inertias: RACKET_INERTIAS, predicted: predictedRate(RACKET_INERTIAS), storedPredicted: T.predicted_rate, measured: T.measured_rate_middle_axis, ok: !!T.ok,
    axis1: T.max_perturbation_over_initial_axis1, axis3: T.max_perturbation_over_initial_axis3 };
}
