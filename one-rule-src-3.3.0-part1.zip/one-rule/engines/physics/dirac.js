// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/dirac.js — step 4, the Dirac equation ∇ψJ = mψγ₀ in the even subalgebra of Cl(1,3), owner P5 (docs/PHYSICS_AUDIT.md DI1–DI6). Built on the
// 40 incidences of engines/spinEngine.js diracPic (read only) and the kernel's products (engines/bitrule.js mul, add, blade), with exact fractions (BigInt):
//   counts()          the numbers of the incidence picture: components, equations, incidences, derivative and mass terms, terms per equation;
//   cubeReading()     the cube's view of the same incidences: the cube edges the derivative terms run along (even corner → odd corner, then the shift by J),
//                     the time edges of the mass terms (the reading equations.json lists as ours);
//   maxwellLink()     the six bivector components of ψ by the names Calibration 1 gives them (engines/maxwellPhysics.js cellPhysics(1, 3), interface 23) and the
//                     incidence counts of the two equations;
//   momentumMatrix()  the 8 × 8 matrix of a plane wave ψ e^{−J p·x}: ∂_μ acts as −p_μ J on the right and J J = −1, so a derivative incidence e_S → γ_μ e_S J becomes
//                     p_μ γ_μ e_S = p_μ (γ_μ e_S J) J⁻¹, the product with J⁻¹ the kernel's; a mass incidence e_S → e_S γ₀ keeps its coefficient m: the symbol
//                     ψ ↦ p ψ + m ψ γ₀ of equations_selfcheck.py, rows the odd blades and columns the even blades (increasing masks);
//   momentumMatrixDirect()  the same symbol from the kernel's products alone (the script's construction), to compare;
//   rankDet()         rank and determinant over the fractions; dispersion(), solutionSpace(), freeWaves() at the stored points;
//   covariance()      D_p(Bψ) = B D_p(ψ) − D'_{[B,p]}(ψ) (D' without the mass term) for a bivector B, exact; COV_POINTS three rational points;
//   jFacts()          J² and the commutator [J, γ₀], by the kernel.
// No sign is computed here: every sign is the kernel's (tests/shipped.test.mjs rule 4). tests/physics/p5.test.mjs ties every number to the stored json.
import { mul, add, blade, popcount } from '../bitrule.js';
import { diracPic } from '../spinEngine.js';
import { cellPhysics } from '../maxwellPhysics.js';

const SQ = [1, -1, -1, -1];
let PIC = null;
const pic = () => PIC || (PIC = diracPic());
const byMask = (a, b) => a - b;

// ---------------------------------------------------------------- exact fractions over BigInt (always reduced, denominator > 0)
const gcd = (a, b) => { let x = a < 0n ? -a : a, y = b < 0n ? -b : b; while (y) [x, y] = [y, x % y]; return x; };
/** the fraction n/d (numbers, BigInts or strings) */
export function Q(n, d = 1) {
  const N = BigInt(n), D = BigInt(d);
  if (D === 0n) throw new Error('a fraction with denominator 0');
  if (D < 0n) return Q(-N, -D);
  const g = gcd(N, D) || 1n;
  return { n: N / g, d: D / g };
}
/** a fraction from "3/4", "2", 5, or a fraction */
export const toQ = v => (v && typeof v === 'object' ? v : typeof v === 'string' && v.includes('/') ? Q(...v.split('/')) : Q(v));
export const qadd = (x, y) => Q(x.n * y.d + y.n * x.d, x.d * y.d);
export const qmul = (x, y) => Q(x.n * y.n, x.d * y.d);
export const qdiv = (x, y) => Q(x.n * y.d, x.d * y.n);
export const qneg = x => Q(-x.n, x.d);
export const qabs = x => Q(x.n < 0n ? -x.n : x.n, x.d);
export const qeq = (x, y) => x.n === y.n && x.d === y.d;
export const qstr = x => (x.d === 1n ? String(x.n) : `${x.n}/${x.d}`);
const ZERO = Q(0), ONE = Q(1), isZero = x => x.n === 0n;
/** the kernel's numeric adapter for these fractions (mul passes a sign ±1, add a number or a fraction) */
export const QN = { add: qadd, mul: qmul, scale: (s, x) => qmul(toQ(s), x), zero: ZERO, isZero };
/** a multivector with fraction coefficients from { mask: value } */
export const mvQ = o => new Map(Object.entries(o).map(([k, v]) => [Number(k), toQ(v)]).filter(([, v]) => !isZero(v)));
/** the vector p = p0 γ0 + p1 γ1 + p2 γ2 + p3 γ3 */
export const vecQ = p => mvQ(Object.fromEntries(p.map((x, i) => [1 << i, x])));
const sameMV = (A, B) => [...new Set([...A.keys(), ...B.keys()])].every(k => qeq(A.get(k) || ZERO, B.get(k) || ZERO));

// ---------------------------------------------------------------- the numbers of the picture (DI1), the cube (DI6), the link to Maxwell (DI2)
/** { components, equations, incidences, derivative, mass, perEquation: { derivative, mass } (null where the equations differ) } */
export function counts(D = pic()) {
  const per = D.equations.map(e => [e.terms.filter(t => t.kind !== 'm').length, e.terms.filter(t => t.kind === 'm').length]);
  const same = per.every(x => x[0] === per[0][0] && x[1] === per[0][1]);
  return { components: D.even.length, equations: D.equations.length, incidences: D.incidences.length, derivative: D.incidences.filter(e => e.kind !== 'm').length, mass: D.incidences.filter(e => e.kind === 'm').length, perEquation: same ? { derivative: per[0][0], mass: per[0][1] } : null };
}
/** the cube's view: { derivative (terms), cubeEdges (the distinct cube edges they run along), allCubeEdges (of the 4-cube), evenToOdd, shiftByJ (each target is the cube
 *  neighbour moved by the bits of J), mass (terms), timeEdges (the distinct edges along t they run along) } */
export function cubeReading(D = pic()) {
  const der = D.incidences.filter(e => e.kind !== 'm'), mass = D.incidences.filter(e => e.kind === 'm');
  const edgeKey = (a, b) => `${Math.min(a, b)}-${Math.max(a, b)}`;
  const along = e => e.from ^ (1 << D.axes.indexOf(e.kind.slice(1)));
  const all = new Set(); for (let m = 0; m < 16; m++) for (let i = 0; i < 4; i++) all.add(edgeKey(m, m ^ (1 << i)));
  return {
    derivative: der.length, cubeEdges: new Set(der.map(e => edgeKey(e.from, along(e)))).size, allCubeEdges: all.size,
    evenToOdd: der.every(e => popcount(e.from) % 2 === 0 && popcount(along(e)) % 2 === 1), shiftByJ: der.every(e => e.to === (along(e) ^ D.J.mask)),
    mass: mass.length, timeEdges: new Set(mass.filter(e => (e.from ^ e.to) === 1).map(e => edgeKey(e.from, e.to))).size,
  };
}
/** { names: { mask: label } of the six bivectors in Calibration 1's cell Cl(1,3) (Ex … Bz), maxwell: its incidences, dirac: the Dirac incidences } */
export function maxwellLink(D = pic()) {
  const C = cellPhysics(1, 3);
  return { names: Object.fromEntries(D.even.filter(m => popcount(m) === 2).map(m => [m, C.blades[m].label])), maxwell: C.incidences.length, dirac: D.incidences.length };
}

// ---------------------------------------------------------------- momentum space (DI4)
/** J = γ₂γ₁, the kernel's product (INP-024: the complex structure chosen in the algebra) */
export const kernelJ = () => mul(blade(1 << 2), blade(1 << 1), SQ);
/** the plane-wave matrix at (p, m) from the incidences (J removed with the kernel's J⁻¹): { rows: odd masks, cols: even masks, A: rows × cols fractions } */
export function momentumMatrix(p, m, D = pic(), J = kernelJ()) {
  const cols = [...D.even].sort(byMask), rows = [...D.odd].sort(byMask), ci = new Map(cols.map((S, j) => [S, j])), ri = new Map(rows.map((T, i) => [T, i]));
  const P = p.map(toQ), M = toQ(m), A = rows.map(() => cols.map(() => ZERO)), j2 = mul(J, J, SQ);
  if (j2.size !== 1 || !j2.has(0)) throw new Error('J does not square to a number');
  const Jinv = new Map([...J].map(([k, v]) => [k, v / j2.get(0)]));
  const put = (T, S, v) => { const i = ri.get(T), j = ci.get(S); if (i === undefined || j === undefined) throw new Error(`an incidence off the even → odd map: ${S} → ${T}`); A[i][j] = qadd(A[i][j], v); };
  for (const e of D.incidences) {
    if (e.kind === 'm') { put(e.to, e.from, qmul(M, Q(e.sign))); continue; }
    const mu = D.axes.indexOf(e.kind.slice(1));
    for (const [T, c] of mul(blade(e.to, e.sign), Jinv, SQ)) put(T, e.from, qmul(P[mu], Q(c)));
  }
  return { rows, cols, A };
}
/** the same symbol ψ ↦ p ψ + m ψ γ₀ from the kernel's products (equations_selfcheck.py dirac().symbol) */
export function momentumMatrixDirect(p, m) {
  const cols = range16().filter(x => popcount(x) % 2 === 0), rows = range16().filter(x => popcount(x) % 2 === 1), P = vecQ(p), M = toQ(m), g0 = blade(1, ONE);
  const A = rows.map(() => cols.map(() => ZERO));
  cols.forEach((S, j) => { const e = blade(S, ONE), out = add(mul(P, e, SQ, QN), mul(e, g0, SQ, QN), M, QN); for (const [T, v] of out) A[rows.indexOf(T)][j] = v; });
  return { rows, cols, A };
}
const range16 = () => Array.from({ length: 16 }, (_, i) => i);
/** rank and determinant of a matrix of fractions (Gaussian elimination, exact): { rank, det } (det 0 unless square and of full rank) */
export function rankDet(A0) {
  const A = A0.map(r => r.slice()), n = A.length, w = n ? A[0].length : 0;
  let det = ONE, rank = 0;
  for (let c = 0; c < w && rank < n; c++) {
    let pv = -1; for (let i = rank; i < n; i++) if (!isZero(A[i][c])) { pv = i; break; }
    if (pv < 0) { det = ZERO; continue; }
    if (pv !== rank) { [A[pv], A[rank]] = [A[rank], A[pv]]; det = qneg(det); }
    det = qmul(det, A[rank][c]);
    for (let i = 0; i < n; i++) if (i !== rank && !isZero(A[i][c])) { const f = qdiv(A[i][c], A[rank][c]); A[i] = A[i].map((x, k) => qadd(x, qneg(qmul(f, A[rank][k])))); }
    rank++;
  }
  return { rank, det: rank === n && n === w ? det : ZERO };
}
/** p² = p p by the kernel (the scalar part; the rest vanishes for a vector) */
export const minkowski = p => mul(vecQ(p), vecQ(p), SQ, QN).get(0) || ZERO;
/** the determinant at the stored points (equations.json dirac.dispersion: { p: [4 strings], m }): [{ p, m, p2, det, det_abs, expected }] as strings */
export function dispersion(points, D = pic()) {
  return points.map(({ p, m }) => {
    const p2 = minkowski(p.map(toQ)), mm = toQ(m), d = rankDet(momentumMatrix(p, m, D).A).det, gap = qadd(p2, qneg(qmul(mm, mm)));
    return { p: p.map(String), m: String(m), p2: qstr(p2), det: qstr(d), det_abs: qstr(qabs(d)), expected: qstr(qmul(qmul(gap, gap), qmul(gap, gap))) };
  });
}
/** the points of equations_selfcheck.py's solution spaces (the script's inputs; the json stores the dimensions): on the massive shell, the massless shell, off */
export const SHELL_POINTS = { massive_shell_real_dim: [[5, 0, 0, 0], 5], massless_shell_real_dim: [[5, 3, 4, 0], 0], off_shell_real_dim: [[2, 1, 0, 0], 1] };
/** the real dimension of the solutions at a momentum: 8 − the rank of the matrix */
export const kernelDim = (p, m, D = pic()) => momentumMatrix(p, m, D).cols.length - rankDet(momentumMatrix(p, m, D).A).rank;
export const solutionSpace = (D = pic()) => Object.fromEntries(Object.entries(SHELL_POINTS).map(([k, [p, m]]) => [k, kernelDim(p, m, D)]));
/** the free waves of spin.json (keys "m=3 p=(0, 0, 4) E=5", "off shell (E=2, p=(0,0,1), m=1)"): the kernel of (E γ₀ + p·γ) ψ − m ψ γ₀, i.e. the matrix at (E, p) with
 *  mass −m: { key: kernel_dim } */
export function freeWaves(keys, D = pic()) {
  return Object.fromEntries(keys.map(key => {
    const m = /m=(-?\d+)/.exec(key)[1], E = /E=(-?\d+)/.exec(key)[1], p = /p=\(([^)]*)\)/.exec(key)[1].split(',').map(s => s.trim());
    return [key, kernelDim([E, ...p], qneg(toQ(m)), D)];
  }));
}

// ---------------------------------------------------------------- covariance (DI3) and J (DI5)
/** D_p(ψ) = p ψ + m ψ γ₀, and without the mass term (D') */
const Dp = (psi, P, M) => { const r = mul(P, psi, SQ, QN); return M ? add(r, mul(psi, blade(1, ONE), SQ, QN), M, QN) : r; };
/** D_p(Bψ) = B D_p(ψ) − D'_{[B,p]}(ψ) for the bivector B at (ψ, p, m), exact: { holds, rotation: [B, p] is a vector } */
export function covariance(B, psi, p, m) {
  const Bm = blade(B, ONE), P = vecQ(p.map(toQ)), M = toQ(m), ps = psi instanceof Map ? psi : mvQ(psi);
  const rot = add(mul(Bm, P, SQ, QN), mul(P, Bm, SQ, QN), -1, QN);
  const lhs = Dp(mul(Bm, ps, SQ, QN), P, M), rhs = add(mul(Bm, Dp(ps, P, M), SQ, QN), Dp(ps, rot, null), -1, QN);
  return { holds: sameMV(lhs, rhs), rotation: [...rot.keys()].every(k => popcount(k) === 1) };
}
/** three rational points (ψ even, p, m) for the identity */
export const COV_POINTS = [
  { psi: { 0: '1', 3: '-2', 5: '1/2', 6: '3', 9: '-1', 10: '2/3', 12: '1', 15: '-3/2' }, p: ['1/2', '1/3', '-1/5', '2'], m: '3/4' },
  { psi: { 0: '-3', 3: '1', 5: '4', 6: '-1/7', 9: '5/2', 10: '-2', 12: '1/3', 15: '2' }, p: ['3', '1', '4', '-1'], m: '2' },
  { psi: { 0: '2/5', 3: '7', 5: '-1', 6: '1', 9: '0', 10: '-5/3', 12: '-4', 15: '1/2' }, p: ['-2/7', '5', '1/3', '1/2'], m: '1/5' },
];
/** the identity for every bivector of ψ at every point: { bivectors, points, holds (the count of pairs where it holds) } */
export function covarianceCheck(points = COV_POINTS, D = pic()) {
  const biv = D.even.filter(m => popcount(m) === 2);
  let holds = 0; for (const B of biv) for (const x of points) if (covariance(B, x.psi, x.p, x.m).holds) holds++;
  return { bivectors: biv.length, points: points.length, holds };
}
/** J = γ₂γ₁ by the kernel: its mask, J² (a number when J squares to one), whether J commutes with γ₀, and whether the picture's J (diracPic) is this one */
export function jFacts(D = pic()) {
  const J = kernelJ(), g0 = blade(1), j2 = mul(J, J, SQ), c = add(mul(J, g0, SQ), mul(g0, J, SQ), -1), [[mask, coef]] = J;
  return { mask, coef, square: j2.size === 1 && j2.has(0) ? j2.get(0) : null, commutesWithG0: c.size === 0, pictureAgrees: D.J.mask === mask && D.J.sign === coef };
}
