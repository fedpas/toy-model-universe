// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/springPhysics.js — the numbers of the spring figures of step 15 (owner P9; docs/PHYSICS_AUDIT.md §2.15, SR1–SR6): one spring as one rotor, the
// faces that close the stretches, the lens ladder (vertices, edges, faces, the rotor) with its matrices, the rungs n = 2 … 5 of the stored table read from the
// lowest up and from the top down (decision D37), the conjugation table of a label (labels are normal modes), and the 22 lines of the claim matrix (decision D35:
// the rows SPR-M01 … SPR-M22). Pure functions, data only (no sentence): the motions and the networks are engines/springEngine.js's, every blade product the
// kernel's (engines/bitrule.js, through spinEngine.mk); the stored numbers (spring.json, content/stored_p9.json) are read as they are, never recomputed here
// (the Betti numbers and the exact series are the script's: D11). tests/physics/p9.test.mjs ties every value to spring.json and recomputes it.
import { oscillator, orbit, KINDS, verts, edges, faces, counts, stretch, faceSums, randomField, randomDisp, fluxes, plainLevels, signedLevels, labelRow, binom } from '../springEngine.js';
import { mk } from '../spinEngine.js';
import { popcount } from '../bitrule.js';

// ---------------------------------------------------------------- 1. one spring, one rotor (v15 SpringWidgets.OscillatorI)
/** v15's widget: ω = 1, x₀ = 3, q₀ = 2; the time slider 0 … 63 (t = value / 10), start 8; the orbit drawn over 6.3 (1.8 for the inverted spring) */
export const OSC = { kinds: ['harmonic', 'inverted', 'free'], w: 1, x0: 3, q0: 2, tMax: 63, tStart: 8, span: { harmonic: 6.3, inverted: 1.8, free: 6.3 } };
/** the squares (u², v²) of the two generators of each kind, B = uv, and its square through the kernel (mk: the product of the bit rule) */
export function rotorOf(kind) {
  const [a, b] = KINDS[kind] || KINDS.harmonic, A = mk([a, b]), B = A.mul(A.g(0), A.g(1));
  return { kind, a, b, B: A.show(B), Bsq: A.get(A.mul(B, B), 0) };
}
/** the state at t = tt / 10: x, q, the half-angle sandwich (it reproduces the motion) and the full angle (it does not), s² = x² + q² (the spring's invariant) */
export function oscillatorAt(kind, tt) {
  const k = OSC.kinds.includes(kind) ? kind : 'harmonic', t = tt / 10, o = oscillator(k, OSC.w, t, OSC.x0, OSC.q0);
  return { kind: k, tt, t, ...o, law: o.Bsq * OSC.w * OSC.w, path: orbit(k, OSC.w, OSC.x0, OSC.q0, OSC.span[k]) };
}

// ---------------------------------------------------------------- 2. faces close the stretches (v15 SpringWidgets.FaceCloser)
/** v15's chips: n = 2, 3, 4; the edge field: the stretch of a displacement, or an arbitrary field; "new sample" moves the seed */
export const FACE_NS = [2, 3, 4];
export const FACE_KINDS = ['disp', 'field'];
/** the edge field of the sample, the sum around every face (face (x, i, j): x → x+i → x+i+j → x+j → x), the verdict, and the flux of the signed network
 *  (the product of the four kernel signs around each face) */
export function facesAt(n, kind, seed) {
  const nn = FACE_NS.includes(n) ? n : 3, k = FACE_KINDS.includes(kind) ? kind : 'disp', s = Number.isInteger(seed) && seed > 0 ? seed : 1;
  const u = randomDisp(nn, s), f = k === 'disp' ? stretch(nn, u) : randomField(nn, s, true), sums = faceSums(nn, f), fx = fluxes(nn);
  return { n: nn, kind: k, seed: s, u, field: edges(nn).map(([a, b, i]) => ({ a, b, i, v: f.get(a + ',' + b) })), faces: faces(nn).map(([x, i, j], q) => ({ x, i, j, sum: sums[q], flux: fx[q] })), counts: counts(nn), closed: sums.every(v => v === 0), fluxMinus: fx.filter(v => v === -1).length };
}

// ---------------------------------------------------------------- 3. the lens ladder: vertices, edges, faces and the rotor, with their matrices
/** the incidence matrices of the n-cube: ∂₁ (vertices × edges: −1 at the start, +1 at the end of each edge) and ∂₂ (edges × faces: the boundary of each face,
 *  oriented as faceSums walks it), the spring matrix L = ∂₁∂₁ᵀ, the graph Laplacian n·I − adjacency, and ∂₁∂₂ */
export function ladderMatrices(n) {
  const V = 1 << n, E = edges(n), F = faces(n), at = new Map(E.map(([a, b], e) => [a + ',' + b, e]));
  const d1 = Array.from({ length: V }, () => Array(E.length).fill(0));
  E.forEach(([a, b], e) => { d1[a][e] -= 1; d1[b][e] += 1; });
  const d2 = Array.from({ length: E.length }, () => Array(F.length).fill(0));
  F.forEach(([x, i, j], q) => { const xi = x + (1 << i), xj = x + (1 << j), xij = xi + (1 << j); d2[at.get(x + ',' + xi)][q] += 1; d2[at.get(xi + ',' + xij)][q] += 1; d2[at.get(xj + ',' + xij)][q] -= 1; d2[at.get(x + ',' + xj)][q] -= 1; });
  const L = d1.map(r => d1.map(s => r.reduce((t, v, e) => t + v * s[e], 0)));
  const nbr = new Set(E.flatMap(([a, b]) => [a + ',' + b, b + ',' + a]));
  const lap = Array.from({ length: V }, (_, x) => Array.from({ length: V }, (_, y) => (x === y ? n : 0) - (nbr.has(x + ',' + y) ? 1 : 0)));
  const d1d2 = d1.map(r => F.map((_, q) => r.reduce((t, v, e) => t + v * d2[e][q], 0)));
  return { n, V, E: E.length, F: F.length, d1, d2, L, lap, LisLap: L.every((r, x) => r.every((v, y) => v === lap[x][y])), d1d2zero: d1d2.every(r => r.every(v => v === 0)) };
}
/** the four steps of the lens ladder (v15 SpringSection: vertices, edges, faces, the rotor), as names and formulas, with what the engine checks for each at n */
export function lensLadder(n) {
  const M = ladderMatrices(n), R = OSC.kinds.map(rotorOf);
  return [
    { key: 'vertices', name: 'Vertices', g: 'x_i', formula: 'L = n·I − adjacency', count: M.V, ok: M.LisLap },
    { key: 'edges', name: 'Edges', g: 'x_a − x_b', formula: 'energy ½ Σ stretch², L = ∂₁∂₁ᵀ', count: M.E, ok: M.LisLap },
    { key: 'faces', name: 'Faces', g: 'Σ around = 0', formula: '∂₁∂₂ = 0', count: M.F, ok: M.d1d2zero },
    { key: 'rotor', name: 'The rotor', g: 's′ = ωBs', formula: `B² = ${R.map(r => fmtInt(r.Bsq)).join(', ')}`, count: R.length, ok: R.map(r => r.Bsq).join() === '-1,1,0' },
  ];
}
const fmtInt = v => (v < 0 ? '−' + Math.abs(v) : v > 0 ? '+' + v : '0');

// ---------------------------------------------------------------- 4. the rungs of the stored table, n = 2 … 5 (decision D37)
/** the n of spring.json's cube and Clifford blocks, lowest first */
export const rungsOf = sr => Object.keys((sr && sr.cube) || {}).map(Number).filter(Number.isInteger).sort((a, b) => a - b);
/** one rung: the stored numbers (V, E, F, Betti numbers, Euler characteristic, the modes by level, the Clifford levels) beside what the engine recomputes
 *  (counts, binomial multiplicities, the signed levels n ± √n with 2ⁿ⁻¹ each); a block the script did not store for this n is null ("not stored") */
export function rungOf(sr, n) {
  const c = sr && sr.cube && sr.cube[n], cl = sr && sr.clifford && sr.clifford[n];
  const k = counts(n), pl = plainLevels(n), sl = signedLevels(n);
  return {
    n, engine: { V: k.V, E: k.E, F: k.F, modes: pl.map(l => ({ w2: l.w2, mult: l.mult })), signed: sl.map(l => ({ w2: l.w2, mult: l.mult })) },
    stored: c ? { V: c.V, E: c.E, F: c.F, betti: c.betti, euler: c.euler, modes: Object.entries(c.modes).map(([j, m]) => ({ w2: 2 * Number(j), mult: m })) } : null,
    clifford: cl ? { faces: cl.faces, levels: cl.frequencies_squared, each: cl.multiplicity_each, plain: cl.plain_levels } : null,
    labels: sr && sr.labels && sr.labels.n === n ? { pairs: sr.labels.pairs, law: sr.labels.omega_squared_of_label_m } : null,
    dynamics: sr && sr.dynamics && sr.dynamics.n === n ? { order: sr.dynamics.order, E0: sr.dynamics.E0 } : null,
  };
}
/** the facet of the n-cube that is the (n − 1)-cube (D37, "from the top": the lower rung as the restriction of the one above): the vertices with the top bit 0 */
export const facetOf = n => verts(n).filter(x => x < 1 << (n - 1));

// ---------------------------------------------------------------- 5. labels are normal modes: the conjugation table (v15 SpringWidgets.LabelsAsModes)
/** the sign of e_m e_x e_m⁻¹ on every blade e_x of Cl(n, 0) (springEngine.labelRow: the kernel's product), the predicted sign (the Walsh character of m, times
 *  (−1)^{|x|} when m is odd), and the mode whose pattern it is: m when m is even, its complement when m is odd, with ω² = 2 × its number of ones */
export function conjugationTable(n, m) {
  const rows = labelRow(n, m), odd = popcount(m) % 2 === 1, all = (1 << n) - 1, star = odd ? all - m : m;
  return { n, m, grade: popcount(m), odd, star, w2: 2 * popcount(star), rows, ok: rows.every(r => r.ok) };
}

// ---------------------------------------------------------------- 6. the 22 lines of the claim matrix (decision D35)
/** v15 springCopy.js: the threads of step 15 in their order, each line's thread, and the three negative controls; each line is the row SPR-Mxx (01 … 22 in the
 *  order of spring.json rows) whose research text is the line's two columns, the claim and how it is checked, joined by " ↔ " */
export const SPRING_THREADS = ['oscillator', 'vertices', 'edges', 'faces', 'sign', 'labels'];
const THREAD_OF = { A1: 'oscillator', A2: 'oscillator', A3: 'oscillator', A4: 'oscillator', B1: 'edges', B4: 'edges', B5: 'vertices', B6: 'vertices', C1: 'vertices', C2: 'vertices', C3: 'vertices', C4: 'vertices', B2: 'faces', B3: 'faces', B7: 'faces', B8: 'faces', D1: 'sign', D2: 'sign', D3: 'sign', D4: 'sign', D5: 'sign', E1: 'labels' };
export const SPRING_CONTROLS = ['A4', 'B8', 'C3'];
/** the 22 lines in the order of spring.json rows (v15 springCopy.js rowIds) */
export const SPRING_LINE_IDS = ['A1', 'A2', 'A3', 'A4', 'B1', 'B2', 'B3', 'B4', 'B5', 'B6', 'B7', 'B8', 'C1', 'C2', 'C3', 'C4', 'D1', 'D2', 'D3', 'D4', 'D5', 'E1'];
export const SEP = ' ↔ ';
/** the lines: { id, row, thread, control, checks, ok }, checks and ok as spring.json stores them (null before the stored table is read) */
export const springLines = sr => { const st = new Map(((sr && sr.rows) || []).map(r => [r.id, r])); return SPRING_LINE_IDS.map((id, i) => { const r = st.get(id); return { id, row: 'SPR-M' + String(i + 1).padStart(2, '0'), thread: THREAD_OF[id], control: SPRING_CONTROLS.includes(id), checks: r ? r.checks : null, ok: r ? r.ok : null }; }); };
/** a line's two columns from its research text (null when the text record is not loaded) */
export const splitLine = text => { if (typeof text !== 'string') return null; const i = text.indexOf(SEP); return i < 0 ? null : { left: text.slice(0, i), right: text.slice(i + SEP.length) }; };
export { binom, verts, edges, faces };
