// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/projective.js — step 11 (one more generator, and a null pair) recomputed through the kernel for the figures extra-generator and null-pair-moves
// (docs/PHYSICS_AUDIT.md PR1, PR3–PR6). Every product is engines/bitrule.js mul on multivectors (Maps mask → coefficient); nothing here multiplies two blades by
// itself. What projective_selfcheck.py stored (projective.json) is never recomputed by a search here: the figures read it from content/stored_p8.json and
// tests/physics/p8.test.mjs ties each printed number to it and to these routes.
//   extraAlgebra(kind, n, s)  one more generator e (e² = s) beside n base axes: the squares of the planes B_a = e_a e, the constant of [B_a, B_b] = c B_ab (c = −2s),
//                             half of it k = −s (the coefficient of e∧e in the curvature of step 10), the number of generators C(n+1, 2)
//   nullPair(kind, n)         ε = e_p + e_m, o = (e_m − e_p)/2: their squares, ε·o, the points P(x) = o + x − ½x²ε on the first space axis, P(x)·P(y) for x, y = 0…3
//   moves(kind, n)            translation 1 + ½tε, rotation ab, dilation 1 + u e_p e_m, inversion in the sphere P(c) − ½r²ε, reflection in the plane m + δε, and
//                             the products of two parallel planes and of two concentric spheres, each applied to a rational point by the (twisted) sandwich
//   conformal(kind, n)        D = e_p e_m, T_i = e_i ε, K_i = e_i o: the eigenvalues of [D, ·] on T and K, and the counts J + P + K + D = C(n+2, 2)
//   countsRow(n), doubling(k) the counts table (C(n+1,2), C(n+2,2), 2^(n+1), 2^(n+2), n + 1) and Cl(k,k) from the kernel clock
import { mul, add, blade, popcount } from '../bitrule.js';
import { algebraName } from '../labels.js';

export const binom = (n, k) => { if (k < 0 || k > n) return 0; let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); };
/** the squares of the base: 'space' every axis −1, 'lorentz' the first +1 and the others −1 (the convention of this page) */
export const baseOf = (kind, n) => (kind === 'space' ? Array(n).fill(-1) : [1, ...Array(n - 1).fill(-1)]);

// ---------------------------------------------------------------- multivectors as Maps, every product the kernel's
const scale = (x, c) => { const o = new Map(); for (const [k, v] of x) if (v * c !== 0) o.set(k, v * c); return o; };
const sum = (...xs) => xs.reduce((a, b) => add(a, b), new Map());
const sub = (x, y) => add(x, y, -1);
const scalarOf = x => x.get(0) || 0;
const vec = co => { const o = new Map(); co.forEach((v, i) => { if (v) o.set(1 << i, v); }); return o; };
export const close = (a, b) => Math.abs(a - b) < 1e-9;
/** the reverse: a blade of grade g changes by (−1)^(g(g−1)/2) (the definition of reversion, not a product) */
const rev = x => { const o = new Map(); for (const [k, v] of x) { const g = popcount(k); o.set(k, (g * (g - 1) / 2) % 2 ? -v : v); } return o; };
/** the commutator [x, y] = xy − yx in the cell eps */
export const commutator = (x, y, eps) => sub(mul(x, y, eps), mul(y, x, eps));
/** x = c·y for one number c (null when not proportional) */
export function ratioOf(x, y) {
  let c = null;
  for (const k of new Set([...x.keys(), ...y.keys()])) {
    const a = x.get(k) || 0, b = y.get(k) || 0;
    if (b === 0) { if (!close(a, 0)) return null; continue; }
    const r = a / b; if (c === null) c = r; else if (!close(c, r)) return null;
  }
  return c;
}

// ---------------------------------------------------------------- one more generator
/** extraAlgebra(kind, n, s): e at index n with e² = s; B_a = e_a e. squares: the kernel square of each B_a (= −e_a² s); coef: the c of [B_a, B_b] = c e_a e_b, the
 *  same for every pair (null if not); k = c / 2; dimension C(n+1, 2) (the bivectors of n + 1 axes) */
export function extraAlgebra(kind = 'lorentz', n = 4, s = -1) {
  const base = baseOf(kind, n), eps = [...base, s], B = base.map((_, a) => blade((1 << a) | (1 << n)));
  const squares = B.map(b => scalarOf(mul(b, b, eps)) + 0);
  let coef = null, consistent = true;
  for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) {
    const c = ratioOf(commutator(B[a], B[b], eps), blade((1 << a) | (1 << b)));
    if (c === null) consistent = false; else if (coef === null) coef = c + 0; else if (!close(coef, c)) consistent = false;
  }
  if (!consistent) coef = null;
  return { kind, n, s, base, eps, squares, coef, k: coef === null ? null : coef / 2 + 0, dimension: binom(n + 1, 2), pairs: binom(n, 2) };
}

// ---------------------------------------------------------------- the null pair and the points
/** the cell of a base with the null pair: the n base axes, then e_m (square +1) at index n and e_p (square −1) at index n + 1; ε = e_p + e_m, o = (e_m − e_p)/2 */
export function nullCell(kind = 'space', n = 3) {
  const base = baseOf(kind, n), eps = [...base, 1, -1], em = blade(1 << n), ep = blade(1 << (n + 1));
  const E = add(ep, em), O = scale(sub(em, ep), 0.5);
  const space = base.map((q, i) => (q < 0 ? i : -1)).filter(i => i >= 0);   // the axes of square −1: the first is "x"
  return { kind, n, base, eps, E, O, em, ep, space, dim: n + 2 };
}
const dotIn = C => (u, v) => scalarOf(mul(u, v, C.eps));
/** P(x) = o + x − ½(x·x)ε for a vector x of the base (x·x the kernel's square) */
const pointIn = C => x => sum(C.O, x, scale(C.E, -0.5 * dotIn(C)(x, x)));
/** the base vector of a normalised point (X·ε = 1): its components on the n base axes */
function coordsIn(C, X) {
  const w = dotIn(C)(X, C.E); if (close(w, 0)) return null;
  return C.base.map((_, i) => (X.get(1 << i) || 0) / w);
}
export function nullPair(kind = 'space', n = 3) {
  const C = nullCell(kind, n), dot = dotIn(C), P = pointIn(C), ax = C.space[0];
  const at = x => P(vec(C.base.map((_, i) => (i === ax ? x : 0))));
  const xs = [0, 1, 2, 3], pts = xs.map(at), m = Q => Q.get(1 << n) || 0, p = Q => Q.get(1 << (n + 1)) || 0;
  return {
    kind, n, axis: ax,
    epsSquare: scalarOf(mul(C.E, C.E, C.eps)) + 0, oSquare: scalarOf(mul(C.O, C.O, C.eps)) + 0, epsDotO: dot(C.E, C.O) + 0,
    // P(x) read back on o, the x axis and ε (o carries ½ e_m − ½ e_p, ε carries e_p + e_m)
    points: pts.map((Q, i) => ({ x: xs[i], square: dot(Q, Q) + 0, o: m(Q) - p(Q) + 0, x1: Q.get(1 << ax) || 0, eps: (m(Q) + p(Q)) / 2 + 0 })),
    table: pts.map(Q => pts.map(R => dot(Q, R) + 0)),
  };
}

// ---------------------------------------------------------------- the moves as sandwiches, at a rational point
/** V X V⁻¹ (even V) or −V X V⁻¹ (a vector V): V⁻¹ = Ṽ/(VṼ), VṼ a scalar */
function sandwich(C, V, X) {
  const R = rev(V), vv = mul(V, R, C.eps), n0 = scalarOf(vv);
  if (close(n0, 0) || [...vv.keys()].some(k => k !== 0 && !close(vv.get(k), 0))) return null;
  return scale(mul(mul(V, X, C.eps), R, C.eps), 1 / n0);
}
const sameVec = (a, b) => !!a && !!b && a.length === b.length && a.every((v, i) => close(v, b[i]));
/** moves(kind, n): each move with its versor applied to the point x0 = (1, 2, 0, …) on the space axes (a rational point), the image read back from the
 *  normalised result and compared with the map it should be (the standard formula, here evaluated with the kernel's dot) */
export function moves(kind = 'space', n = 3) {
  const C = nullCell(kind, n), dot = dotIn(C), P = pointIn(C), ax = C.space[0], ay = C.space[1] ?? 0;
  const v = co => vec(C.base.map((_, i) => co[i] || 0)), onAxes = (a, b) => { const c = Array(n).fill(0); c[ax] = a; if (C.space.length > 1) c[ay] += b; return c; };
  const x0 = onAxes(1, 2), X0 = P(v(x0)), img = V => coordsIn(C, sandwich(C, V, X0));
  const plus = (a, b) => a.map((q, i) => q + b[i]), times = (a, c) => a.map(q => q * c), dotv = (a, b) => dot(v(a), v(b));
  const out = [];
  // translation by t: T = 1 + ½ t ε
  const t = onAxes(3, -1), T = add(blade(0), scale(mul(v(t), C.E, C.eps), 0.5));
  out.push({ id: 'translation', versor: 'T = 1 + ½tε', mirrors: 2, image: img(T), expect: plus(x0, t) });
  // rotation by two mirrors of the base: R = a b with a = the x axis, b a rational unit vector of square −1 (with y, or with t on a Lorentz base of two axes)
  const bco = Array(n).fill(0); if (C.space.length > 1) { bco[ax] = 3 / 5; bco[ay] = 4 / 5; } else { bco[ax] = 5 / 4; bco[0] = 3 / 4; }
  const a = v(onAxes(1, 0)), b = v(bco), R = mul(a, b, C.eps), Rx = coordsIn(C, sandwich(C, R, P(v(x0)))), fixO = ratioOf(sandwich(C, R, C.O), C.O), fixE = ratioOf(sandwich(C, R, C.E), C.E);
  out.push({ id: 'rotation', versor: 'R = ab', mirrors: 2, image: Rx, expect: Rx && close(dotv(Rx, Rx), dotv(x0, x0)) ? Rx : null, fixes: close(fixO ?? 0, 1) && close(fixE ?? 0, 1), squares: [dot(a, a), dot(b, b)] });
  // dilation: V = 1 + u e_p e_m, u = 1/3: x → λx with λ = (1 − u)/(1 + u) = 1/2 or its inverse
  const u = 1 / 3, V = add(blade(0), scale(mul(C.ep, C.em, C.eps), u)), dimg = img(V), lam = (1 - u) / (1 + u);
  out.push({ id: 'dilation', versor: 'V = 1 + u e_p e_m', mirrors: 2, image: dimg, expect: sameVec(dimg, times(x0, lam)) ? times(x0, lam) : times(x0, 1 / lam), u, lambda: lam });
  // inversion in the sphere S = P(c) − ½r²ε: x → c − r² (x − c)/(x − c)²
  const c = onAxes(0, 1), r2 = 4, S = sub(P(v(c)), scale(C.E, 0.5 * r2)), d = plus(x0, times(c, -1)), dd = dotv(d, d);
  out.push({ id: 'inversion', versor: 'S = P(c) − ½r²ε', mirrors: 1, image: img(S), expect: plus(c, times(d, -r2 / dd)), sphereSquare: dot(S, S) });
  // reflection in the plane m + δε (m the x axis, δ = 3): x → x − 2 (x·m + δ)/(m·m) m
  const m = onAxes(1, 0), dl = 3, PL = add(v(m), scale(C.E, dl)), mm = dotv(m, m);
  out.push({ id: 'plane', versor: 'm + δε', mirrors: 1, image: img(PL), expect: plus(x0, times(m, -2 * (dotv(x0, m) + dl) / mm)) });
  // two parallel planes m + δ₁ε, m + δ₂ε: a translation (the reflection in the first, then in the second)
  const d1 = 3, d2 = 1 / 2, P1 = add(v(m), scale(C.E, d1)), P2 = add(v(m), scale(C.E, d2)), refl = (dl0, y) => plus(y, times(m, -2 * (dotv(y, m) + dl0) / mm));
  out.push({ id: 'two-planes', versor: '(m + δ₂ε)(m + δ₁ε)', mirrors: 2, image: img(mul(P2, P1, C.eps)), expect: refl(d2, refl(d1, x0)), translation: plus(refl(d2, refl(d1, x0)), times(x0, -1)) });
  // two concentric spheres of radii² r₁², r₂²: a dilation about c by r₂²/r₁²
  const q1 = 1, q2 = 9 / 4, S1 = sub(P(v(c)), scale(C.E, 0.5 * q1)), S2 = sub(P(v(c)), scale(C.E, 0.5 * q2));
  out.push({ id: 'two-spheres', versor: 'S₂S₁', mirrors: 2, image: img(mul(S2, S1, C.eps)), expect: plus(c, times(d, q2 / q1)), factor: q2 / q1 });
  for (const mv of out) mv.ok = sameVec(mv.image, mv.expect) && (mv.id !== 'rotation' || (mv.fixes && mv.expect !== null));
  return { kind, n, point: x0, moves: out };
}

// ---------------------------------------------------------------- the conformal generators
/** conformal(kind, n): D = e_p e_m, T_i = e_i ε, K_i = e_i o; [D, T_i] = λ_T T_i and [D, K_i] = λ_K K_i for every i (null if not one number); the counts */
export function conformal(kind = 'space', n = 3) {
  const C = nullCell(kind, n), D = mul(C.ep, C.em, C.eps);
  const one = gen => { let c = null; for (let i = 0; i < n; i++) { const X = mul(blade(1 << i), gen, C.eps), r = ratioOf(commutator(D, X, C.eps), X); if (r === null || (c !== null && !close(c, r))) return null; c = r + 0; } return c; };
  return { kind, n, onT: one(C.E), onK: one(C.O), generators: binom(n + 2, 2), rotations: binom(n, 2), translations: n, special: n, dilation: 1, euclid: binom(n + 1, 2) };
}
/** the counts table of step 11 for n axes */
export const countsRow = n => ({ ladder_generators: binom(n + 1, 2), euclid_generators: binom(n + 1, 2), conformal_generators: binom(n + 2, 2), pga_dimension: 2 ** (n + 1), cga_dimension: 2 ** (n + 2), planes_to_move_a_point: n + 1, rotations: binom(n, 2) });
/** Cl(k, k) from the kernel clock: M_{2^k}(ℝ), its matrix size and dimension */
export const doubling = k => ({ k, algebra: algebraName(k, k), matrix_size: 2 ** k, algebra_dimension: 4 ** k });
