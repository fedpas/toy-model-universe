// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/clockWalk.js — round 17 (proofs pass 13a, docs/round17/PROOFS_ROUND13A.md; rows LAB-026 and LAB-027): the path of the clock sum and
// Duvall and Keesling's count of the boundary of the Lévy dragon on the labels, for the figures clock-walk and dragon-blades.
//   the walk     the partial sums of Σ_a i^w(a) over the labels of Cl(p,q) in counting order a = 0, 1, …, 2ⁿ − 1 or in Gray-code order m xor (m >> 1),
//                every step i^w(a) with w = engines/labels.js w4 (|a| mod 2 + 2 [e_a² = −1], the square from the kernel's sign); points as integers
//   the blades   each step z → z + d of the walk of Cl(0,n) as the triangle with long side [z, z + d] and third vertex z + d(1 + i)/2 (their F^n(T₀)),
//                a label interior when the 15 triangles of its star (the triangles of the unit squares cut by their diagonals that meet it) are all
//                triangles of the walk; n ≤ 16
//   the rule     their Proposition 5.1 as printed (the two maps of the 15-bit neighbourhood types), run from the 15 types 2⁰ … 2¹⁴ of N₀ with exact
//                counts (BigInt): the boundary labels |B_n| for n ≤ 120 and the number of types present
//   λ            the largest real root of P(x) = x⁹ − 3x⁸ + 3x⁷ − 3x⁶ + 2x⁵ + 4x⁴ − 8x³ + 8x² − 16x + 8 (bisection)
// The Python twin is checks/selfcheck/proofs/clock_walk.py (cw.PATH, cw.GRAY, cw.ORD, cw.DK, cw.LAM; log checks/selfcheck/proofs/logs/clock_walk.log),
// which tests/physics/p14.test.mjs reads line by line. Data only, no sentence.
import { w4, sigVec, clockOf } from '../labels.js';

export const N_WALK = 12;        // the walks drawn: n = p + q ≤ 12 (cw.PATH and cw.GRAY are exact there)
export const N_BLADES = 16;      // the labels counted as triangles: n ≤ 16 (cw.DK)
export const N_SHARE = 120;      // the counts of Proposition 5.1 drawn: n ≤ 120 (cw.DK runs them to 420)
export const ORDERS = ['counting', 'gray-code'];
export const FRAMES = ['plane', 'chord'];
export const I_POW = [[1, 0], [0, 1], [-1, 0], [0, -1]];            // i⁰ … i³ as pairs of integers
const gmul = (u, v) => [u[0] * v[0] - u[1] * v[1], u[0] * v[1] + u[1] * v[0]];

export const grayOf = m => m ^ (m >> 1);
/** the labels in the order the walk reads them */
export function labelsInOrder(n, order = 'counting') {
  const N = 1 << n, out = new Array(N);
  for (let m = 0; m < N; m++) out[m] = order === 'gray-code' ? grayOf(m) : m;
  return out;
}
/** w(a) for every label of Cl(p,q) (the generators of square +1 first, as engines/labels.js sigVec), from the kernel */
export function formOf(p, q) {
  const eps = sigVec(p, q), N = 1 << (p + q), w = new Uint8Array(N);
  for (let a = 0; a < N; a++) w[a] = w4(a, eps);
  return w;
}
/** (1 + i)^p (1 − i)^q as a pair of integers: the end of every walk of Cl(p,q) (LAB-017) */
export function gaussEnd(p, q) {
  let z = [1, 0];
  for (let k = 0; k < p; k++) z = gmul(z, [1, 1]);
  for (let k = 0; k < q; k++) z = gmul(z, [1, -1]);
  return z;
}

const WALKS = new Map();
/**
 * The walk of Cl(p,q) in the given order: dirs[m] = w of the m-th label read (the step i^dirs[m]), the points xs, ys (2ⁿ + 1 of them, from 0), the end,
 * the milestones after 2^k labels (k = 0 … n), the clock c and the step of the newest generator's label (+i or −i: the quarter turn of the second half).
 */
export function clockWalk(p, q, order = 'counting') {
  const key = `${p},${q},${order}`;
  if (WALKS.has(key)) return WALKS.get(key);
  const n = p + q, N = 1 << n, w = formOf(p, q), labels = labelsInOrder(n, order);
  const dirs = new Uint8Array(N), xs = new Int32Array(N + 1), ys = new Int32Array(N + 1);
  for (let m = 0; m < N; m++) {
    const d = w[labels[m]]; dirs[m] = d;
    xs[m + 1] = xs[m] + I_POW[d][0]; ys[m + 1] = ys[m] + I_POW[d][1];
  }
  const milestones = [];
  for (let k = 0; k <= n; k++) milestones.push({ k, x: xs[1 << k], y: ys[1 << k] });
  const turn = n ? I_POW[w[1 << (n - 1)]] : null;
  const out = { p, q, n, order, c: clockOf(p, q), dirs, xs, ys, end: [xs[N], ys[N]], milestones, turn, labels };
  WALKS.set(key, out);
  return out;
}
/** the point (1 + s i)^t of the logarithmic spiral through the milestones of a cell of one sign (s = +1 for Cl(n,0), −1 for Cl(0,n)) */
export const spiralPoint = (t, s) => { const r = Math.pow(2, t / 2), a = (s * Math.PI * t) / 4; return [r * Math.cos(a), r * Math.sin(a)]; };

// ---------------------------------------------------------------------------------------------------- the blades as triangles (cw.DK)
const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]];
/** the triangle with doubled centre (cx, cy) (the centre of its unit square) and long side on the side u of that square: its three vertices, doubled */
const vertsOf = (cx, cy, ux, uy) => [[cx, cy], [cx + ux - uy, cy + uy + ux], [cx + ux + uy, cy + uy - ux]];
const vkey = v => `${v[0]},${v[1]}`;
/** the star of the triangle with centre 0 and side u = 1: the 15 triangles (offset of the centre, side) that meet it, itself among them */
export const STAR = (() => {
  const own = new Set(vertsOf(0, 0, 1, 0).map(vkey)), out = [];
  for (let dx = -4; dx <= 4; dx += 2) for (let dy = -4; dy <= 4; dy += 2) for (const [ux, uy] of DIRS) if (vertsOf(dx, dy, ux, uy).some(v => own.has(vkey(v)))) out.push([dx, dy, ux, uy]);
  return out;
})();
const tkey = (cx, cy, ux, uy) => ((cx + 4096) * 8192 + (cy + 4096)) * 4 + (ux === 1 ? 0 : uy === 1 ? 1 : ux === -1 ? 2 : 3);
const BLADES = new Map();
/** the 2ⁿ triangles of the walk of Cl(0,n) (counting order: the m-th triangle is the label m) and its interior labels */
export function dragonBlades(n) {
  if (BLADES.has(n)) return BLADES.get(n);
  const W = clockWalk(0, n, 'counting'), N = 1 << n, tri = new Int32Array(4 * N), set = new Set();
  for (let m = 0; m < N; m++) {
    const [dx, dy] = I_POW[W.dirs[m]], x = W.xs[m], y = W.ys[m];
    const cx = 2 * x + dx - dy, cy = 2 * y + dy + dx, ux = dy, uy = -dx;   // the third vertex z + d(1 + i)/2 is the centre; u = −i d points to the long side
    tri[4 * m] = cx; tri[4 * m + 1] = cy; tri[4 * m + 2] = ux; tri[4 * m + 3] = uy;
    set.add(tkey(cx, cy, ux, uy));
  }
  const interior = [];
  for (let m = 0; m < N; m++) {
    const cx = tri[4 * m], cy = tri[4 * m + 1], ux = tri[4 * m + 2], uy = tri[4 * m + 3];
    let all = true;
    for (const [ox, oy, rx, ry] of STAR) {   // the star turned by u
      if (!set.has(tkey(cx + ox * ux - oy * uy, cy + ox * uy + oy * ux, rx * ux - ry * uy, rx * uy + ry * ux))) { all = false; break; }
    }
    if (all) interior.push(m);
  }
  const out = { n, N, walk: W, tri, distinct: set.size === N, interior, boundary: N - interior.length };
  BLADES.set(n, out);
  return out;
}
/** the triangle of a label as three points (not doubled): z, z + d and z + d(1 + i)/2 */
export function triangleOf(B, m) {
  const cx = B.tri[4 * m], cy = B.tri[4 * m + 1], ux = B.tri[4 * m + 2], uy = B.tri[4 * m + 3];
  return vertsOf(cx, cy, ux, uy).map(([x, y]) => [x / 2, y / 2]);
}

// ---------------------------------------------------------------------------------------------------- Proposition 5.1 (the paper's rule)
export const RHO_T1 = [8, 1, 9, 8, 10, 9, 1, 10, 15, 3, 2, 5, 4, 7, 6];
export const RHO_T2 = [10, 1, 12, 11, 14, 13, 2, 15, 3, 8, 1, 9, 8, 10, 9];
const FULL = (1 << 15) - 1;
const child = (t, R) => { let c = 0; for (let i = 0; i < 15; i++) if ((t >> (R[i] - 1)) & 1) c |= 1 << i; return c; };
let RULE = null;
/** |B_n| (exact, BigInt) for n = 0 … N_SHARE, the number of types present at each n, the first n from which the set of types stays the same, the shares */
export function boundaryRule() {
  if (RULE) return RULE;
  let V = new Map(); for (let j = 0; j < 15; j++) V.set(1 << j, 1n);
  const B = [], types = [], sets = [];
  for (let k = 0; k <= N_SHARE + 1; k++) {
    let b = 0n; for (const [t, c] of V) if ((t & 1) && t !== FULL) b += c;
    B.push(b); types.push(V.size); sets.push([...V.keys()].sort((x, y) => x - y).join());
    const W = new Map();
    for (const [t, c] of V) for (const R of [RHO_T1, RHO_T2]) { const ch = child(t, R); W.set(ch, (W.get(ch) || 0n) + c); }
    V = W;
  }
  let stableFrom = null; for (let k = 1; k <= N_SHARE; k++) if (sets[k] === sets[k + 1] && sets.slice(k, N_SHARE + 2).every(s => s === sets[k])) { stableFrom = k; break; }
  const share = B.slice(0, N_SHARE + 1).map((b, k) => Number((b * 10n ** 12n) / (1n << BigInt(k))) / 1e12);
  RULE = { B: B.slice(0, N_SHARE + 1), types: types.slice(0, N_SHARE + 1), stableFrom, share };
  return RULE;
}

// ---------------------------------------------------------------------------------------------------- λ
export const P_COEFFS = [1, -3, 3, -3, 2, 4, -8, 8, -16, 8];
const Pof = x => P_COEFFS.reduce((v, c) => v * x + c, 0);
/** the largest real root of P, by bisection in [1.95, 1.96] (P changes sign there; the check shows no root above 1.96) */
export function lambda() {
  let lo = 1.95, hi = 1.96;
  for (let i = 0; i < 60; i++) { const mid = (lo + hi) / 2; if (Pof(lo) * Pof(mid) <= 0) hi = mid; else lo = mid; }
  return (lo + hi) / 2;
}
/** 2 log₂ λ = ln λ / ln √2: the dimension their Theorem 4.5 gives the boundary (read, not re-proved) */
export const dimOf = lam => 2 * Math.log2(lam);
/** the ratio of successive counts of the rule at n (a Number) */
export function ratioAt(n) { const { B } = boundaryRule(); return Number((B[n] * 10n ** 15n) / B[n - 1]) / 1e15; }
