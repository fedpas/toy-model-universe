// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/commutators.js — step 2, the commutators of bivectors (so(p,q); the Lorentz algebra at p = 1, q = 3), owner P5 (docs/PHYSICS_AUDIT.md CM1–CM3).
// Every commutator is the kernel's: [e_a, e_b] = e_a e_b − e_b e_a with engines/bitrule.js mul and add, never a sign of its own. From them:
//   commutatorsOf(p, q)  the bivectors of Cl(p, q) with their role (the first p generators are time: E one time index, B none, T two) and square, the pairs that do
//                        not commute (the commutator's blade and coefficient, the generator the two share, a time or a space axis) and the pairs that commute;
//   rolesOf(p, q)        the role table of a cell as equations_selfcheck.py writes it (commutators.roles: "B+E via s" → { edges, result });
//   countsOf(n)          the counts by n as it writes them (commutators.by_n: bivectors, edges, commuting_pairs, triangles, signatures_checked), recomputed for
//                        every signature p + q = n; a signature counts as checked when each non-zero commutator is ±2 e_{a xor b} for two bivectors that share
//                        one generator, every other pair commutes, every edge lies in one closed triangle of three, and its counts agree with p = 0;
//   graphOf(n)           the commutator graph of n generators, the same for every signature (countsOf checks it), as the comm-ladder figure draws it.
// tests/physics/p5.test.mjs ties every table to checks/selfcheck/equations.json and catches broken copies.
import { mul, add, blade, cell, square, popcount } from '../bitrule.js';

const range = k => Array.from({ length: k }, (_, i) => i);
/** the range of n that equations_selfcheck.py runs (commutators: n = 2 … 8); a figure draws a rung only where the stored table holds it (D37) */
export const LADDER = range(7).map(i => i + 2);
/** [e_a, e_b] in the cell eps, by the kernel: a Map mask → coefficient, empty when the two commute */
export const commutator = (a, b, eps) => add(mul(blade(a), blade(b), eps), mul(blade(b), blade(a), eps), -1);
/** the role of a bivector m when the first p generators are time: E (one time index), B (none), T (two) */
export const roleOf = (m, p) => ['B', 'E', 'T'][popcount(m & ((1 << p) - 1))];
/** the bivectors of n generators, by increasing mask (those of the first k generators come first) */
export const bivectorsOf = n => range(1 << n).filter(m => popcount(m) === 2);

const MEMO = new Map();
/** the commutator graph of Cl(p, q): { p, q, n, eps, bivectors: [{ m, role, square }], edges: [{ a, b, k, coef, terms, shared, via, pair, result }], commuting: [{ a, b }] } */
export function commutatorsOf(p, q) {
  const key = `${p},${q}`;
  if (MEMO.has(key)) return MEMO.get(key);
  const n = p + q, eps = cell(p, q), biv = bivectorsOf(n), time = (1 << p) - 1, edges = [], commuting = [];
  biv.forEach((a, i) => biv.slice(i + 1).forEach(b => {
    const C = commutator(a, b, eps);
    if (!C.size) { commuting.push({ a, b }); return; }
    const [[k, coef]] = C, shared = a & b;
    edges.push({ a, b, k, coef, terms: C.size, shared, via: shared & time ? 't' : 's', pair: [roleOf(a, p), roleOf(b, p)].sort().join('+'), result: roleOf(k, p) });
  }));
  const out = { p, q, n, eps, bivectors: biv.map(m => ({ m, role: roleOf(m, p), square: square(m, eps) })), edges, commuting };
  MEMO.set(key, out);
  return out;
}

/** the role table of Cl(p, q): { "<pair> via <t|s>": { edges, result } } in the stored order (sorted keys); result null where one key gives two roles */
export function rolesOf(p, q) {
  const tab = {};
  for (const e of commutatorsOf(p, q).edges) {
    const key = `${e.pair} via ${e.via}`, t = tab[key] || (tab[key] = { edges: 0, result: e.result });
    if (t.result !== e.result) t.result = null;
    t.edges++;
  }
  return Object.fromEntries(Object.keys(tab).sort().map(k => [k, tab[k]]));
}

/** the closed triangles of a set of edges: the index triples a | b, when each holds exactly three edges (else null) */
export function trianglesOf(edges) {
  const tri = new Map();
  for (const e of edges) tri.set(e.a | e.b, (tri.get(e.a | e.b) || 0) + 1);
  return [...tri.values()].every(v => v === 3) ? tri.size : null;
}

const COUNTS = new Map();
/** the counts of n generators, recomputed for every signature p + q = n: { n, bivectors, edges, commuting_pairs, triangles, signatures_checked } */
export function countsOf(n) {
  if (COUNTS.has(n)) return COUNTS.get(n);
  let ref = null, checked = 0;
  for (let p = 0; p <= n; p++) {
    const G = commutatorsOf(p, n - p);
    const rule = G.edges.every(e => e.terms === 1 && popcount(e.shared) === 1 && e.k === (e.a ^ e.b) && Math.abs(e.coef) === 2) && G.commuting.every(c => popcount(c.a & c.b) !== 1);
    const c = { bivectors: G.bivectors.length, edges: G.edges.length, commuting_pairs: G.commuting.length, triangles: trianglesOf(G.edges) };
    if (!ref) ref = c;
    if (rule && c.triangles !== null && ['bivectors', 'edges', 'commuting_pairs', 'triangles'].every(f => c[f] === ref[f])) checked++;
  }
  const out = { n, ...ref, signatures_checked: checked };
  COUNTS.set(n, out);
  return out;
}

/** the graph a rung draws: the bivectors of n generators and the pairs that do not commute (signature (0, n); countsOf checks that every signature gives the same) */
export function graphOf(n) {
  const G = commutatorsOf(0, n);
  return { n, nodes: G.bivectors.map(b => b.m), edges: G.edges.map(e => [e.a, e.b]) };
}
