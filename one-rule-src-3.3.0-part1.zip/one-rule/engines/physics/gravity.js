// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/gravity.js — steps 9, 10 and 12 recomputed through the kernel for the figures curvature-pairs, einstein-terms, cosmological-generator, rain and
// riemann-split (docs/PHYSICS_AUDIT.md G1–G3, E1–E3, GG1–GG2). The frame algebra is Cl(1, n−1): γ₀ squares to +1, the others to −1 (the convention of the step
// pages). Every sign is engines/bitrule.js's (sign, mul); the counts are the standard formulas; what gravity_selfcheck.py and gravity_matrix_check.py stored
// (gravity.json, gravity_matrix.json) is read by the figures from content/stored_p8.json and compared with these routes in tests/physics/p8.test.mjs.
//   pairGrid(n)            the table of curvature components: the unordered pairs of planes (a b | c d), each in its class — the same plane, one axis shared (their
//                          bivectors do not commute: a kernel commutator), no axis shared (they commute) — with the distance of the two labels (0, 2, 4)
//   bianchiTriple(quad)    the three cells that one first-Bianchi relation R(ab|cd) + R(ac|db) + R(ad|bc) = 0 ties, for four axes a < b < c < d
//   ladderRow(n)           the columns of the two ladders of steps 9 and 10 (frame algebra, boosts + rotations from the kernel squares, ω, e, R, T, relations,
//                          independent curvature, Ricci + Weyl; E, its terms, tetrads, torsion terms in D E_a, the generators with a cosmological term)
//   restriction(n, top)    the cells of the top table whose planes lie in the first n axes: the table of n as the restriction of the table of top
//   einsteinTerms(n, a)    the terms of E_a: each pair {b, c} of the other axes with ε_{a b c …} from the all-null rule (every square 0), the rest carrying tetrads
//   cosmological(n, s)     one more generator of square s on the frame: [P_a, P_b] = c B_ab with c = −2s, k = c/2 = −s, and μ (the torsion coefficient) = 1
//   pgShear(g)             the Painlevé–Gullstrand shear h̄ = 1 + N on (e_t, e_r): N, N², its rank, det h̄, and time reversal T h̄_g T = h̄_{−g} (2 × 2 products)
//   bivectorSquare(n)      the grades of B² for a bivector with every component non-zero (the first primes as coefficients)
import { mul, blade, square, popcount, cell, PRIMES } from '../bitrule.js';
import { algebraName, curvature, bitsOf } from '../labels.js';
import { extraAlgebra, commutator, ratioOf, close, binom } from './projective.js';

export const AX = ['t', 'x', 'y', 'z', 'u', 'v', 'w', 's'];
export const NS = [2, 3, 4, 5, 6, 7, 8];
export const frameEps = n => cell(1, n - 1);
/** the planes γ_a γ_b (a < b), in the scripts' order */
export const planesOf = n => { const g = []; for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) g.push((1 << i) | (1 << j)); return g; };
/** a label written with the axis letters (t, x, y, z, u, v, w, s) */
export const axisWord = m => bitsOf(m).map(i => AX[i]).join('');
/** the class of a pair of planes: the same plane, one axis shared (the kernel commutator is not 0), or none (it is 0) */
export function pairClass(A, B, eps) {
  if (A === B) return 'diagonal';
  return commutator(blade(A), blade(B), eps).size ? 'one' : 'disjoint';
}
/** the table of curvature components of Cl(1, n−1) */
export function pairGrid(n) {
  const eps = frameEps(n), P = planesOf(n), cells = [], counts = { diagonal: 0, one: 0, disjoint: 0 };
  for (let i = 0; i < P.length; i++) for (let j = i; j < P.length; j++) {
    const cls = pairClass(P[i], P[j], eps);
    counts[cls]++;
    cells.push({ i, j, A: P[i], B: P[j], cls, dist: popcount(P[i] ^ P[j]) });
  }
  return { n, eps, planes: P, squares: P.map(m => square(m, eps) + 0), cells, counts };
}
/** the sets of four axes a < b < c < d */
export function quadsOf(n) {
  const o = [];
  for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) for (let c = b + 1; c < n; c++) for (let d = c + 1; d < n; d++) o.push([a, b, c, d]);
  return o;
}
/** the three cells (pairs of planes) one first-Bianchi relation ties: (ab | cd), (ac | bd), (ad | bc) */
export function bianchiTriple([a, b, c, d]) {
  const k = (x, y) => (1 << x) | (1 << y);
  return [[k(a, b), k(c, d)], [k(a, c), k(b, d)], [k(a, d), k(b, c)]];
}
/** the table of `top` restricted to the first n axes: its cells whose two planes use only those axes, counted by class */
export function restriction(n, top = 8) {
  const G = pairGrid(top), lim = 1 << n, cells = G.cells.filter(c => c.A < lim && c.B < lim), counts = { diagonal: 0, one: 0, disjoint: 0 };
  for (const c of cells) counts[c.cls]++;
  return { n, top, cells: cells.length, counts };
}
/** the columns of the ladders of steps 9 and 10 at n */
export function ladderRow(n) {
  const G = pairGrid(n), C2 = binom(n, 2), rel = binom(n, 4), cells = G.cells.length, cs = curvature(n);
  return {
    n, frame_algebra: algebraName(1, n - 1), even_half: algebraName(1, n - 2),
    bivectors: C2, boosts: G.squares.filter(q => q === 1).length, rotations: G.squares.filter(q => q === -1).length,
    omega_components: n * C2, tetrad_components: n * n, curvature_components: C2 * C2, torsion_components: n * C2,
    pair_classes: { diagonal: G.counts.diagonal, share_one_index: G.counts.one, disjoint: G.counts.disjoint },
    first_bianchi_constraints: rel, riemann_from_classes: cells - rel, riemann_independent: n * n * (n * n - 1) / 12,
    ricci: n === 2 ? 1 : cs.ricci, weyl: cs.weyl, poincare_generators: C2 + n,
    einstein_components: n >= 3 ? n * n : 0, einstein_terms_per_component: n >= 3 ? binom(n - 1, 2) : 0, tetrads_per_term: Math.max(0, n - 3),
    divergence_torsion_terms_per_component: n >= 3 ? binom(n - 1, 2) * (n - 3) : 0,
    desitter_generators: binom(n + 1, 2), desitter_curvature_components: binom(n + 1, 2) * C2,
  };
}
/** a stored algebra ("M2(H) + M2(H)", "M1(R) + M1(R)") written as the kernel clock writes it ("M₂(ℍ)⊕M₂(ℍ)", "ℝ⊕ℝ") */
export const storedAlgebra = s => String(s).replace(/M1\(([RCH])\)/g, '$1').replace(/M(\d+)/g, (_, d) => 'M' + d.replace(/\d/g, x => '₀₁₂₃₄₅₆₇₈₉'[x]))
  .replace(/R/g, 'ℝ').replace(/C/g, 'ℂ').replace(/H/g, 'ℍ').replace(/\s*\+\s*/g, '⊕');

/** the terms of E_a = Σ_{b<c} ε_{a b c d…} F^{bc} ∧ e^d ∧ …: the pairs of the other axes, ε the coefficient of the ordered product e_a e_b e_c e_d … with every
 *  square 0 (the all-null rule, the sign of the wedge), the rest of the axes in increasing order carrying the tetrads */
export function einsteinTerms(n, a) {
  const nul = Array(n).fill(0), others = [...Array(n).keys()].filter(x => x !== a), out = [];
  for (let i = 0; i < others.length; i++) for (let j = i + 1; j < others.length; j++) {
    const b = others[i], c = others[j], rest = others.filter(x => x !== b && x !== c);
    let p = blade(1 << a);
    for (const g of [b, c, ...rest]) p = mul(p, blade(1 << g), nul);
    out.push({ b, c, rest, eps: p.get((1 << n) - 1) || 0 });
  }
  return out;
}

/** one more generator of square s beside the frame of n axes (de Sitter for s = −1, anti-de Sitter for s = +1): P_a = γ_a e, [P_a, P_b] = c γ_a γ_b with
 *  c = −2s (kernel), k = c/2 the coefficient of e∧e in the curvature R + k e∧e; μ the coefficient of the torsion: ½[B_ab, P_b] on P_a over ½[B_ab, γ_b] on γ_a,
 *  the same for every pair (null if not) */
export function cosmological(n = 4, s = -1) {
  const X = extraAlgebra('lorentz', n, s), eps = X.eps;
  let mu = null, same = true;
  for (let a = 0; a < n; a++) for (let b = 0; b < n; b++) if (a !== b) {
    const Bab = blade((1 << a) | (1 << b)), hP = ratioOf(commutator(Bab, blade((1 << b) | (1 << n)), eps), blade((1 << a) | (1 << n))), hG = ratioOf(commutator(Bab, blade(1 << b), eps), blade(1 << a));
    if (hP === null || !hG) { same = false; continue; }
    const r = hP / hG; if (mu === null) mu = r; else if (!close(mu, r)) same = false;
  }
  return { n, s, coef: X.coef, k: X.k, mu: same && mu !== null ? mu + 0 : null, group: s < 0 ? 'de Sitter' : s > 0 ? 'anti-de Sitter' : 'Poincare', generators: X.dimension, curvature_components: X.dimension * binom(n, 2), squares: X.squares };
}

/** the shear of the Painlevé–Gullstrand frame, h̄(e_r) = e_r + g e_t, h̄(e_t) = e_t, as a 2 × 2 matrix on (e_t, e_r): h̄ = 1 + N */
export function pgShear(g) {
  const mm = (A, B) => [[A[0][0] * B[0][0] + A[0][1] * B[1][0], A[0][0] * B[0][1] + A[0][1] * B[1][1]], [A[1][0] * B[0][0] + A[1][1] * B[1][0], A[1][0] * B[0][1] + A[1][1] * B[1][1]]];
  const N = [[0, g], [0, 0]], H = [[1, g], [0, 1]], N2 = mm(N, N), T = [[-1, 0], [0, 1]], THT = mm(mm(T, H), T);
  const zero = M => M.every(r => r.every(v => v === 0));
  return { g, N, H, N2, nilpotent: zero(N2), rank: zero(N) ? 0 : 1, det: H[0][0] * H[1][1] - H[0][1] * H[1][0], reversed: THT, reversedIsMinusG: THT[0][1] === -g && THT[0][0] === 1 && THT[1][1] === 1 && THT[1][0] === 0 };
}

/** B² for B = Σ p_k γ_{P_k} (p_k the k-th prime, every plane of Cl(1, n−1)): the grades it has, by the kernel product */
export function bivectorSquare(n) {
  const eps = frameEps(n), B = new Map(planesOf(n).map((m, k) => [m, PRIMES[k]])), B2 = mul(B, B, eps);
  return { n, grades: [...new Set([...B2.keys()].map(popcount))].sort((x, y) => x - y), scalar: B2.get(0) || 0 };
}
