// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/nullPhysics.js — the numbers of the null-surface figures of step 13 (owner P9; docs/PHYSICS_AUDIT.md §2.13, NS1–NS4): the neck (Schwarzschild
// against the Ellis wormhole), the criterion of Eq. (1) on three null surfaces, Kerr's ergosurface, the mirror in the normal covector, the Gram determinants of the
// null pair, and the ladder of horizon algebras Cl(0, n−2, 1) read from the lowest stored rung up and from the top down (decision D37). Pure functions, data only
// (no sentence): every formula is engines/nullEngine.js's (the formulas null_selfcheck.py checks), every blade product the kernel's (engines/bitrule.js sign);
// the stored numbers (null.json portal, bundled; figs f1–f4, content/stored_p9.json) are read as they are. tests/physics/p9.test.mjs ties every value to the
// stored json and recomputes the algebra through the kernel.
import { schwT, kruskalX, ellisL, invariants, rates, EQ1, Ffac, KERR, kerrErgo, kerrGtt, kerrNN, kerrXZ, mirrorImage, gramTortoise, gramEF, surfaceKind, NS, QUOT, CELL, inJ, blade, popc, frac } from '../nullEngine.js';
import { sign } from '../bitrule.js';
import { NULL } from '../stored.js';

const grid = (a, b, N) => Array.from({ length: N + 1 }, (_, i) => a + (b - a) * i / N);

// ---------------------------------------------------------------- 1. the neck: horizon or throat (v15 NullWidgets.NeckWidget)
/** the slider of v15: r from 1.02 to 2 (Schwarzschild r_S = 1; the Ellis throat has radius 1), start 1.3 */
export const NECK = { min: 1.02, max: 2, step: 0.01, start: 1.3 };
/** v15's three lens chips of the neck */
export const NECK_VIEWS = ['clifford', 'null', 'flow'];
/** the readouts at r, signed as v15 printed them: T, n·n = −T and g^rr for Schwarzschild; T = 1, n·n = −1 and g^rr for Ellis; the rates along an ingoing photon */
export function neckAt(r) {
  const iS = invariants.schw(r), iE = invariants.ellis(r);
  return {
    r,
    schw: { T: schwT(r), nn: -iS.n2, grr: -iS.grr, dr: rates.schw.dr(r), dl: rates.schw.dl(r), X0: kruskalX(r, 0) },
    ellis: { T: 1, nn: -iE.n2, grr: -iE.grr, dr: rates.ellis.dr(r), dl: rates.ellis.dl(r), l: r > 1 ? ellisL(r) : 0 },
  };
}
/** the curves of the clifford lens (|n·n| and |g^rr| against r = 1 … 2) and of the flow lens (dr/dv and dℓ/dv), as v15 drew them from the engine */
export function neckCurves(N = 40) {
  const rs = grid(1, 2, N);
  return {
    schw: { nn: rs.map(r => [r, invariants.schw(r).n2]), grr: rs.map(r => [r, invariants.schw(r).grr]), dr: rs.map(r => [r, rates.schw.dr(r)]), dl: rs.map(r => [r, rates.schw.dl(r)]) },
    ellis: { nn: rs.map(r => [r, invariants.ellis(r).n2]), grr: rs.map(r => [r, invariants.ellis(r).grr]), dr: rs.map(r => [r, rates.ellis.dr(r)]), dl: rs.map(r => [r, rates.ellis.dl(r)]) },
  };
}
/** the live slice of the null lens at r: the Kruskal branches X = ±√((r − 1)eʳ + T²) for T in [−3, 3], and ℓ = ±√(r² − 1) for Ellis */
export function neckSlice(r, N = 30) {
  return { kruskal: grid(-3, 3, N).map(T => [kruskalX(r, T), T]), ellisL: r > 1 ? ellisL(r) : 0 };
}
/** the stored rows of f1 (null.json figs.f1: the script's segments of the two charts), checked against the engine's formulas: a Kruskal static row has
 *  X = √((r − 1)eʳ + T²) at both ends, an interior row T = √((1 − r)eʳ + X²), the horizon rows X = ±T, the photon X + T = constant; an Ellis static row ℓ = √(r² − 1) */
export function f1Residual(q) {
  const ends = [[q.a1, q.b1], [q.a2, q.b2]];
  if (q.p === 'k' && q.kind === 'static') return Math.max(...ends.map(([X, T]) => Math.abs(X - kruskalX(q.rv, T))));
  if (q.p === 'k' && q.kind === 'interior') return Math.max(...ends.map(([X, T]) => Math.abs(T - Math.sqrt((1 - q.rv) * Math.exp(q.rv) + X * X))));
  if (q.p === 'k' && q.kind === 'surface') return Math.max(...ends.map(([X, T]) => Math.abs(Math.abs(X) - Math.abs(T))));
  if (q.p === 'k' && q.kind === 'photon') return Math.abs((q.a1 + q.b1) - (q.a2 + q.b2));
  if (q.p === 'e' && q.kind === 'static') return Math.max(Math.abs(q.a1 - ellisL(q.rv)), Math.abs(q.a2 - ellisL(q.rv)));
  if (q.p === 'e' && q.kind === 'surface') return Math.max(Math.abs(q.a1), Math.abs(q.a2));          // the throat: ℓ = 0
  if (q.p === 'e' && q.kind === 'photon') return Math.max(...ends.map(([l, t]) => Math.abs(Math.abs(l) - Math.abs(t))));   // ℓ = ±t
  if (q.kind === 'neck') return Math.max(...ends.flat().map(Math.abs));                                // the neck: the origin
  return Infinity;                                                                                      // a row of another kind: not drawn
}
/** the stored f2 rows (null.json figs.f2): each is a segment of dr/dv or dℓ/dv against r; the engine's rate at both ends */
export const f2Rate = q => { const sp = q.cs === 'Schwarzschild' ? rates.schw : rates.ellis, f = q.q === 'dr/dv' ? sp.dr : sp.dl; return [f(q.r1), f(q.r2)]; };

// ---------------------------------------------------------------- 2. the criterion: Eq. (1) on three null surfaces (v15 NullWidgets.CriterionWidget)
/** v15's slider: log₁₀ of the distance x from the surface, −3 … −0.3, start −2; the three cases of the chips */
export const CRIT = { min: -3, max: -0.3, step: 0.05, start: -2 };
export const CRIT_CASES = EQ1.map(c => c.id);
/** the names the stored f3 rows give the three cases */
export const F3_CASE = { 'simple zero': 'simple', extremal: 'extremal', 'Eq. (18)': 'eq18' };
/** T, dT/dx, |Eq. (1)| = T (dT/dx)², F = −(dT/dx)²/2 and n·n = −T at x = 10^lx */
export function criterionAt(id, lx) {
  const c = EQ1.find(e => e.id === id) || EQ1[0], x = 10 ** lx;
  return { id: c.id, lx, x, T: c.T(x), dT: c.dT(x), eq1: c.eq1(x), F: Ffac(c, x), nn: -c.T(x) };
}
/** the engine's curve of |Eq. (1)| against x on the window 10⁻³ … 1 (a straight line on the log-log plot: slopes 1, 4 and −1) */
export const criterionCurve = (id, N = 24) => { const c = EQ1.find(e => e.id === id) || EQ1[0]; return grid(-3, 0, N).map(l => [10 ** l, c.eq1(10 ** l)]); };
/** the log-log slope of |Eq. (1)| for a case, from the engine */
export const criterionSlope = id => { const c = EQ1.find(e => e.id === id) || EQ1[0]; return Math.log(c.eq1(8e-3) / c.eq1(1e-3)) / Math.log(8); };

// ---------------------------------------------------------------- 3. Kerr: the ergosurface is not the horizon (v15 NullWidgets.KerrWidget)
/** v15's slider: the polar angle θ in degrees, 0 … 90, start 60; M = 5, a = 3, r₊ = 9 */
export const KERR_THETA = { min: 0, max: 90, step: 1, start: 60 };
export { KERR };
/** at θ: cos²θ, r_E(θ) = M + √(M² − a² cos²θ), g_tt there (0), n·n of the normal to g_tt = const, the pole (n·n = 0), and the point in the meridian plane */
export function kerrAt(deg) {
  const th = deg * Math.PI / 180, w = Math.cos(th) ** 2, rE = kerrErgo(w), nn = kerrNN(w);
  return { deg, th, w, rE, gtt: kerrGtt(rE, w), nn, pole: Math.abs(w - 1) < 1e-9, xz: kerrXZ(rE, th) };
}
/** the horizon r₊ and the ergosurface in the meridian plane (oblate coordinates x = √(r² + a²) sin θ, z = r cos θ), θ from 0 to π */
export const kerrCurves = (N = 60) => ({ horizon: grid(0, Math.PI, N).map(a => kerrXZ(KERR.rh, a)), ergo: grid(0, Math.PI, N).map(a => kerrXZ(kerrErgo(Math.cos(a) ** 2), a)) });
/** the stored f4 rows (the script's segments, θ in degrees at the first end): the horizon or the ergosurface at both ends, from the engine */
export const f4Engine = q => { const at = deg => { const a = deg * Math.PI / 180; return kerrXZ(q.kind === 'horizon' ? KERR.rh : kerrErgo(Math.cos(a) ** 2), a); }; return [at(q.th), at(q.th + 6)]; };
/** the seven exact points of null_selfcheck.py on the ergosurface (null.json portal.kerr, bundled): cos²θ, r_E and n·n as stored, their values, and θ */
export const kerrExact = () => NULL.portal.kerr.map(p => { const w = frac(p.w); return { w: p.w, r: p.r, n2: p.n2, wv: w, rv: frac(p.r), nv: frac(p.n2), deg: Math.acos(Math.sqrt(w)) * 180 / Math.PI }; });

// ---------------------------------------------------------------- 4. figure 1: the mirror in the normal covector and the Gram determinants (v15 Cone, lenses mirror and clifford)
/** v15's vector w = (w^v, w^x) */
export const MIRROR_W = [0.4, 0.8];
/** the mirror in n = dx: w′ = w − 2 (n·w)/(n·n) n♯ with n·n = −T, so w′^v = w^v + 2 w^x / T and w′^x = −w^x; none on a null surface (T = 0) */
export function mirrorAt(T, w = MIRROR_W) { const img = mirrorImage(w, T); return { T, w, img, kind: surfaceKind(T), nn: -T, grows: img ? Math.abs(img[0]) : Infinity }; }
/** the Gram determinants of the null pair: −T² in the tortoise chart, −1 in the Eddington–Finkelstein chart (a Witt pair even at T = 0) */
export const gramAt = T => ({ tortoise: gramTortoise(T).det, ef: gramEF().det });
/** the summary of null_selfcheck.py (null.json portal.summary): computed, passed, readings */
export const nullSummary = () => ({ ...NULL.portal.summary });

// ---------------------------------------------------------------- 5. the ladder of horizon algebras (decision D37), n = 2 … 6 as stored
/** the sign vector of the tangent algebra Cl(0, n−2, 1): bits 0 … n−3 square to −1 (the sphere), bit n−2 squares to 0 (the null bit) */
export const horizonEps = n => [...Array(n - 2).fill(-1), 0];
/** the stored rungs (null.json portal.ladder), lowest first; NS = the n of the chips */
export const RUNGS = NS;
/** one rung, recomputed through the kernel: the blades, those through the null bit (the ideal J), the zero products J·J (all of them), the quotient's
 *  products (every product of two blades off J lies off J and carries the sign of Cl(0, n−2)); with the stored dim and dim J beside them */
export function horizonRung(n) {
  const rec = NULL.portal.ladder.find(r => r.n === n) || null, m = n - 1, N = 1 << m, eps = horizonEps(n), quotEps = Array(n - 2).fill(-1);
  const blades = Array.from({ length: N }, (_, S) => S), J = blades.filter(S => inJ(n, S));
  let jj = true, ideal = true, quot = true;
  for (const a of blades) for (const b of blades) {
    const s = sign(a, b, eps), aJ = inJ(n, a), bJ = inJ(n, b), cJ = inJ(n, a ^ b);
    if (aJ && bJ && s !== 0) jj = false;
    if ((aJ || bJ) && s !== 0 && !cJ) ideal = false;
    if (!aJ && !bJ && (cJ || s !== sign(a, b, quotEps))) quot = false;
  }
  return { n, m, cell: CELL[n], quotient: QUOT[n], stored: rec, dim: N, J: J.length, quotDim: N - J.length, jj, ideal, quot, blades, inJ: S => inJ(n, S), name: S => blade(n, S), grade: popc };
}
/** the blades of rung n − 1 inside rung n (D37, "from the top": a lower rung as the restriction of the one above): the blades of rung n without the last sphere
 *  generator e_{n−2} (bit n − 3), a subalgebra; with the map from the labels of rung n − 1 (its null bit moved up one place) */
export function restrictionOf(n) {
  if (n <= RUNGS[0]) return null;
  const drop = n - 3, low = (1 << drop) - 1, up = S => (S & low) | (((S >> drop) & 1) << (n - 2));
  const lower = Array.from({ length: 1 << (n - 2) }, (_, S) => S), image = lower.map(up), eps = horizonEps(n), eps1 = horizonEps(n - 1);
  // the restriction is a subalgebra: the product of two blades of the image stays in the image, with the sign rung n − 1 gives the same pair
  const set = new Set(image);
  let closed = true; for (const a of lower) for (const b of lower) { const x = up(a), y = up(b); if (!set.has(x ^ y) || up(a ^ b) !== (x ^ y) || sign(x, y, eps) !== sign(a, b, eps1)) closed = false; }
  return { n, lower: n - 1, image, closed, up };
}
