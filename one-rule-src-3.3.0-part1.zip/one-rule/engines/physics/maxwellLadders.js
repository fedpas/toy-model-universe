// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/maxwellLadders.js — the ladders of Calibration 1 (owner P4; docs/PHYSICS_AUDIT.md §2.1 MX6–MX10 and MX13; decisions D29 and D37).
// Read: the stored cells and ladders of checks/selfcheck/maxwell.json through interface 23 (engines/maxwellPhysics.js: cellPhysics, ladders, the 15 cells
// k, d <= 4, k + d <= 7, the space ladder Cl(1, d), d = 0 … 8, the time ladder Cl(k, 1), k = 1 … 9). Recomputed through the kernel (engines/bitrule.js sign, mul,
// popcount, PRIMES; the clock of engines/labels.js clockByKernel, the phase of the Gauss sum of the kernel's squares):
//   kernelAlgebra  the algebra of a cell: its type and matrix size from the kernel's clock, I² = the kernel's square of the top blade, I central when it
//                  commutes with every generator (the kernel's signs both ways), split in two when central with I² = +1; the wave operator's class from the
//                  squares of the generators (elliptic: one sign only; hyperbolic: one sign once; ultrahyperbolic: both signs at least twice), well posed
//                  along time when the plus sign is the lone one, along space when the minus sign is;
//   chainOf        D37, the ladder through a cell: from the lowest stored cell Cl(1,0) up the space line to Cl(1, d), then along time to Cl(k, d), then on in
//                  the direction of the last step, to ten generators; each rung the cell the store holds there (a full cell, a row of a ladder), or none;
//   keptOf         D37, "from the top": a lower rung read inside the top rung — the top's labels whose generators all belong to the lower cell (time generators
//                  first, then space generators, each kept in its order), counted by role and by grade; tests/physics/p4.test.mjs checks that this equals
//                  the lower cell as stored, and that the roles, the moves and the kernel's signs of every stored pair agree;
//   stepTo         MX7, what the step that leads to a cell adds (the counts of both cells as stored), and ★: the equations whose target holds the new generator;
//   lensCounts     the elements of a rung in each lens: the layers of the n-cube (labels by number of generators, the kernel's popcount), the simplex's
//                  vertices, edges and triangles, the even and odd halves, the first n primes, the blades by square (the kernel's sign of e_S e_S);
//   forceTerms     MX13, the terms of the force on a charge in the physical cell Cl(1, d): the grade-1 part of e_S e_in through the kernel's mul, times the
//                  convention's sign of the component (an input, INP-011) and the frame's lowering of the space indices (the stored frame u~ = (γ, −γ v)).
// No sign is computed here: every sign is the kernel's (tests/shipped.test.mjs rule 4).
import { sign, cell, popcount, mul, blade, PRIMES } from '../bitrule.js';
import { TYPES, clockByKernel, bitsOf } from '../labels.js';
import { cellPhysics, cellsAvailable, ladders, algebraText, axesOf, parseTerms, roleOf } from '../maxwellPhysics.js';

/** the rungs of the ladders: one to ten generators (the stored time ladder reaches Cl(9, 1)) */
export const RUNGS = 10;
const range = n => Array.from({ length: n }, (_, i) => i);
const keyOf = (k, d) => `${k},${d}`;
/** the field's dimension over ℝ as a power of two: M_N(type) has N = 2^((n − rank) / 2) */
const RANK = { R: 0, R2: 1, C: 1, H: 2, H2: 3 };
const FIELD = { R: 'ℝ', R2: 'ℝ', C: 'ℂ', H: 'ℍ', H2: 'ℍ' };
/** the algebra written out: M2(ℍ), M4(ℝ) ⊕ M4(ℝ) as interface 23 writes it (algebraText), and a 1 × 1 matrix as its field: ℝ ⊕ ℝ for Cl(1, 0) */
export const algebraLabel = al => (al.matrix_size === 1 ? (/2$/.test(al.type) ? `${FIELD[al.type]} ⊕ ${FIELD[al.type]}` : FIELD[al.type]) : algebraText(al));

// ---------------------------------------------------------------- the algebra of a cell, read off the kernel
const ALG = new Map();
/**
 * kernelAlgebra(k, d) → { k, d, n, blades, type, matrixSize, text, I2, central, splits, plus, minus, class, wellPosedAlong } for Cl(k, d): k generators of
 * square +1 (time) and d of square −1 (space), every value from the kernel (see the head of the file).
 */
export function kernelAlgebra(k, d) {
  const key = keyOf(k, d);
  if (ALG.has(key)) return ALG.get(key);
  const n = k + d, eps = cell(k, d), top = (1 << n) - 1;
  const squares = range(n).map(a => sign(1 << a, 1 << a, eps));
  const plus = squares.filter(s => s > 0).length, minus = squares.filter(s => s < 0).length;
  const I2 = sign(top, top, eps);
  const central = range(n).every(a => sign(1 << a, top, eps) === sign(top, 1 << a, eps));
  const type = TYPES[clockByKernel(k, d)], matrixSize = 2 ** ((n - RANK[type]) / 2);
  const cls = plus === 0 || minus === 0 ? 'elliptic' : plus === 1 || minus === 1 ? 'hyperbolic' : 'ultrahyperbolic';
  const out = { k, d, n, blades: 2 ** n, type, matrixSize, text: algebraLabel({ type, matrix_size: matrixSize }), I2, central, splits: central && I2 > 0, plus, minus, class: cls, wellPosedAlong: cls === 'hyperbolic' ? (plus === 1 ? 'time' : 'space') : null };
  ALG.set(key, out);
  return out;
}

// ---------------------------------------------------------------- what the store holds at a cell
const STORE = (() => {
  const L = ladders();
  return { time: new Map(L.time.map(r => [r.k, r])), space: new Map(L.space.map(r => [r.d, r])), cells: new Set(cellsAvailable()) };
})();
const algebraOf = r => ({ type: r.type, matrix_size: r.matrix_size, pseudoscalar_square: r.pseudoscalar_square, pseudoscalar_central: r.pseudoscalar_central, splits_in_two: r.splits_in_two });
const SC = new Map();
/**
 * storedCell(k, d) → the cell as the store holds it, or null: { k, d, n, from: 'cell' | 'time' | 'space', F, E, T, B, vector, trivector, total, algebra,
 * symbol (null when the row stores none), mirror (the time ladder's mirror Cl(1, k)), sameAsCl08 (the space ladder), stepNew (the time ladder's step_new_*) }.
 * A full cell of maxwell.json first (its counts from interface 23), else a row of the time ladder (d = 1), else a row of the space ladder (k = 1).
 */
export function storedCell(k, d) {
  const key = keyOf(k, d);
  if (SC.has(key)) return SC.get(key);
  let out = null;
  if (STORE.cells.has(key)) {
    const C = cellPhysics(k, d), v = C.equations.filter(e => e.op === 'contract').length, mir = cellPhysics(d, k);
    out = { k, d, n: k + d, from: 'cell', F: C.components.field.length, E: C.counts.E, T: C.counts.T, B: C.counts.B, vector: v, trivector: C.equations.length - v, total: C.equations.length, incidences: C.incidences.length, algebra: C.algebra, symbol: C.symbol, mirror: mir ? mir.algebra : null };
  } else if (d === 1 && STORE.time.has(k)) {
    const r = STORE.time.get(k);
    out = { k, d, n: r.n, from: 'time', F: r.F_components, E: r.E_components, T: r.T_components, B: r.B_components, vector: r.equations_vector, trivector: r.equations_trivector, total: r.equations_total, algebra: algebraOf(r), symbol: r.symbol, mirror: { type: r.mirror_type, matrix_size: r.mirror_matrix_size }, stepNew: { generator: r.step_new_generator, blades: r.step_new_blades, F: r.step_new_F, E: r.step_new_E, T: r.step_new_T, equations: r.step_new_equations } };
  } else if (k === 1 && STORE.space.has(d)) {
    const r = STORE.space.get(d);
    out = { k, d, n: r.n, from: 'space', F: r.F_components, E: r.E_components, T: 0, B: r.B_components, vector: r.equations_vector, trivector: r.equations_trivector, total: r.equations_total, algebra: algebraOf(r), symbol: null, mirror: null, sameAsCl08: r.same_algebra_as_Cl08 };
  }
  SC.set(key, out);
  return out;
}

// ---------------------------------------------------------------- D37: the ladder through a cell, and the rungs read from the top
/** the name of the generator a step adds: t (one time), t1 … t9, x, y, z, w; null beyond the four space names the store uses */
const genName = (k, d, axis) => axesOf(k, d)[axis] || null;
/**
 * chainOf(k, d) → the ten rungs n = 1 … 10 of the ladder through Cl(k, d): [{ n, k, d, kind ('time' | 'space', the step from the rung below; null at n = 1),
 * axis (the index of the generator that step adds, in the rung's own cell), gen (its name), S (storedCell, or null: "not stored") }]. The rungs go from the
 * lowest stored cell Cl(1, 0) up the space line to Cl(1, d), then along time to Cl(k, d), then on along space when k = 1, along time otherwise.
 */
export function chainOf(k = 1, d = 3) {
  const path = [];
  for (let s = 0; s <= d; s++) path.push([1, s]);
  for (let t = 2; t <= k; t++) path.push([t, d]);
  while (path.length < RUNGS) { const [a, b] = path[path.length - 1]; path.push(k === 1 ? [a, b + 1] : [a + 1, b]); }
  return path.map(([a, b], i) => {
    const kind = i === 0 ? null : a > path[i - 1][0] ? 'time' : 'space', axis = kind === 'time' ? a - 1 : kind === 'space' ? a + b - 1 : null;
    return { n: a + b, k: a, d: b, kind, axis, gen: axis === null ? null : genName(a, b, axis), S: storedCell(a, b) };
  });
}
/** the index of the highest stored rung of a chain (the stored rungs of a chain run unbroken from n = 1 up to it) */
export const topOf = chain => chain.reduce((t, r, i) => (r.S ? i : t), 0);
/** the label map of Cl(kL, dL) into Cl(kU, dU) (kL <= kU, dL <= dU): a time generator keeps its index, the j-th space generator goes to kU + j */
export const embedOf = (kL, kU) => m => bitsOf(m).reduce((x, i) => x | (1 << (i < kL ? i : kU + i - kL)), 0);
/**
 * keptOf(top, rung) → what the top rung keeps of itself on the generators of a lower rung: { F, E, T, B (the top's bivectors on those generators, by their
 * role in the top), vector, trivector, total (the top's targets of grade 1 and 3 on them), dropped (the indices of the top's generators not kept),
 * droppedNames (their names: t, t1 … t9, x, y, z, w; null for a space generator beyond w, which the store does not name) }.
 */
export function keptOf(top, rung) {
  const N = top.k + top.d, phi = embedOf(rung.k, top.k), keep = range(rung.k + rung.d).reduce((x, i) => x | phi(1 << i), 0);
  const on = range(1 << N).filter(m => (m | keep) === keep), byGrade = g => on.filter(m => popcount(m) === g);
  const biv = byGrade(2), role = r => biv.filter(m => roleOf(m, top.k, N) === r).length, axes = axesOf(top.k, top.d);
  const dropped = range(N).filter(a => !bitsOf(keep).includes(a));
  return { F: biv.length, E: role('E'), T: role('T'), B: role('B'), vector: byGrade(1).length, trivector: byGrade(3).length, total: byGrade(1).length + byGrade(3).length, dropped, droppedNames: dropped.map(a => axes[a] || null) };
}

// ---------------------------------------------------------------- MX7: what a step adds, with ★
/**
 * stepTo(k, d) → the step of the ladder that leads to Cl(k, d), read from the two cells as stored: { k, d, n, from: [k0, d0], kind, axis, gen, square (the
 * kernel's square of the new generator), blades, F, eqs ([before, after]), add: { E, T, B }, addEq: { vector, trivector }, algebra, I2, cls ([before, after];
 * cls null where the store holds no symbol), star: [{ id, name, op }] (the equations of the cell whose target holds the new generator) }; null at n = 1.
 */
export function stepTo(k, d) {
  const chain = chainOf(k, d), i = k + d - 1, r = chain[i], p = chain[i - 1];
  if (!p || !r.S || !p.S) return null;
  const A = p.S, B = r.S, C = cellPhysics(k, d), bit = 1 << r.axis;
  return {
    k, d, n: r.n, from: [p.k, p.d], kind: r.kind, axis: r.axis, gen: r.gen, square: sign(bit, bit, cell(k, d)),
    blades: [2 ** p.n, 2 ** r.n], F: [A.F, B.F], eqs: [A.total, B.total], add: { E: B.E - A.E, T: B.T - A.T, B: B.B - A.B }, addEq: { vector: B.vector - A.vector, trivector: B.trivector - A.trivector },
    algebra: [algebraLabel(A.algebra), algebraLabel(B.algebra)], I2: [A.algebra.pseudoscalar_square, B.algebra.pseudoscalar_square], cls: [A.symbol ? A.symbol.class : null, B.symbol ? B.symbol.class : null],
    star: C ? C.equations.filter(e => (e.target | bit) === e.target).map(e => ({ id: e.id, name: e.name, op: e.op })) : [],
  };
}

// ---------------------------------------------------------------- the elements of a rung in each lens
/** lensCounts(k, d) → { n, layers (labels by number of generators), corners, even, odd, vertices, edges, triangles, primes, product, plus, minus (blades by
 *  square in Cl(k, d)) } — popcount, PRIMES and sign of the kernel; the shape lenses see n only, the Clifford lens the split */
export function lensCounts(k, d) {
  const n = k + d, eps = cell(k, d), labels = range(1 << n), layers = range(n + 1).map(g => labels.filter(m => popcount(m) === g).length);
  const sq = labels.map(m => sign(m, m, eps)), primes = PRIMES.slice(0, n);
  return { n, layers, corners: labels.length, even: labels.filter(m => popcount(m) % 2 === 0).length, odd: labels.filter(m => popcount(m) % 2 === 1).length,
    vertices: layers[1] || 0, edges: layers[2] || 0, triangles: layers[3] || 0, primes, product: primes.reduce((x, q) => x * q, 1), plus: sq.filter(s => s > 0).length, minus: sq.filter(s => s < 0).length };
}

// ---------------------------------------------------------------- MX9: the two ladders, as stored, and the period
/** the rows of a stored ladder ('time': Cl(k, 1), k = 1 … 9; 'space': Cl(1, d), d = 0 … 8), each with its algebra written out (algebraText) */
export function ladderRows(which) {
  return which === 'time'
    ? [...STORE.time.values()].map(r => ({ k: r.k, d: 1, n: r.n, algebra: algebraLabel(r), mirror: algebraLabel({ type: r.mirror_type, matrix_size: r.mirror_matrix_size }), I2: r.pseudoscalar_square, central: r.pseudoscalar_central, splits: r.splits_in_two, F: r.F_components, E: r.E_components, T: r.T_components, vector: r.equations_vector, trivector: r.equations_trivector, total: r.equations_total, stepF: r.step_new_F, stepEq: r.step_new_equations, cls: r.symbol.class, along: r.symbol.well_posed_along }))
    : [...STORE.space.values()].map(r => ({ k: 1, d: r.d, n: r.n, algebra: algebraLabel(r), I2: r.pseudoscalar_square, central: r.pseudoscalar_central, splits: r.splits_in_two, F: r.F_components, E: r.E_components, B: r.B_components, vector: r.equations_vector, trivector: r.equations_trivector, total: r.equations_total, cl08: r.same_algebra_as_Cl08 }));
}
/** the period along time, from the stored ladder: Cl(1, 1) and Cl(9, 1), eight steps apart — their types and matrix sizes, and the ratio of the sizes */
export function periodOf() {
  const a = STORE.time.get(1), b = STORE.time.get(9);
  return a && b ? { from: 1, to: 9, steps: 8, type: [a.type, b.type], size: [a.matrix_size, b.matrix_size], ratio: b.matrix_size / a.matrix_size, algebra: [algebraLabel(a), algebraLabel(b)] } : null;
}

// ---------------------------------------------------------------- MX13: the force on a charge, term by term, recomputed through the kernel
/** the frame of the stored force table (u~ = (γ, −γ v)): the time index kept, a space index lowered */
export const lowered = a => (a === 0 ? 1 : -1);
/**
 * forceTerms(d) → the terms of the force in Cl(1, d) (d = 2, 3, 4: the worlds maxwell_selfcheck.py stores): for each component of F (the convention of the
 * stored cell: its blade e_S and its sign) and each velocity component u_in, the grade-1 part of (sign · e_S)(lowered(in) · e_in) through the kernel's mul,
 * read back with the out index lowered: [{ field, in, out, sign }], in the stored order (component, then in).
 */
export function forceTerms(d) {
  const C = cellPhysics(1, d);
  if (!C) return [];
  const eps = cell(1, d), F = parseTerms(C.conventions.F), order = C.conventions.field_order, out = [];
  F.forEach((t, i) => {
    for (let b = 0; b <= d; b++) {
      for (const [m, v] of mul(blade(t.mask, t.sign), blade(1 << b, lowered(b)), eps)) if (popcount(m) === 1) { const o = bitsOf(m)[0]; out.push({ field: order[i], in: b, out: o, sign: lowered(o) * v }); }
    }
  });
  return out;
}
/** the edges of the simplex of Cl(1, d) that carry the components of F: [{ field, a, b }] (a < b, the two indices of the component's blade) */
export function forceEdges(d) {
  const C = cellPhysics(1, d);
  if (!C) return [];
  return parseTerms(C.conventions.F).map((t, i) => { const [a, b] = bitsOf(t.mask); return { field: C.conventions.field_order[i], a, b }; });
}
