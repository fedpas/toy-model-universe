// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
// Required Notice: Copyright (c) 2026 the Cascade Atlas authors
// Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
// engines/physics/weilIndex.js — round 17 (proofs pass 13c, docs/round17/PROOFS_ROUND13C.md; caption row LAB-028): Weil's index of the cell's real
// quadratic form beside the clock walk, for the figure weil-index.
//   the real side   Q(x) = Σ_j ε_j x_j², the form v ↦ v² of Cl(p,q) (inertia type (p, q)), χ(t) = e^{2πiλt}, σ the sign of λ. The integral of
//                   e^{2πiλQ(x)} damped by e^{−πs|x|²} (s > 0), times |ρ|^{1/2} = (2|λ|)^{n/2}, splits into one Gaussian integral per generator:
//                   I(u) = Π_j (u − iσε_j)^{−1/2}, u = s / (2|λ|), principal square roots. With u = cot φ, I = (sin φ)^{n/2} e^{iσ(p−q)φ/2}: from 0
//                   (u = ∞) to e^{iσπ(p−q)/4} as u → 0+, Weil's index γ of the form for that λ (n° 26; his Corollary 2 with a Gaussian gives the same
//                   number with no limit). Its argument runs through σ(p − q)π/4, the whole signature; its end keeps p − q mod 8. Only the sign of λ enters.
//   the labels      the walk of engines/physics/clockWalk.js (counting order) divided by 2^{n/2}: from 0 to (1 + i)^p (1 − i)^q / 2^{n/2} = e^{iπ(p−q)/4},
//                   the scalar of Weil's relation (9) on the labels (LAB-028)
// The Python twin of the numbers is checks/selfcheck/proofs/weil_index.py (wi.DEF, wi.REAL; log checks/selfcheck/proofs/logs/weil_index.log), which
// tests/physics/p15.test.mjs reads line by line. Data only, no sentence.
import { clockWalk, gaussEnd, N_WALK } from './clockWalk.js';
import { clockOf } from '../labels.js';

export const N_INDEX = N_WALK;                    // the cells drawn: n = p + q ≤ 12, as the clock walk
export const SIGNS = ['positive', 'negative'];    // the sign of λ in χ(t) = e^{2πiλt}
export const K_CURVE = 192;                       // the samples of the damped integral: φ = (π/2) k / K_CURVE, k = 0 … K_CURVE
const sgnOf = sign => (sign === 'negative' ? -1 : 1);

/** Weil's index of the real form of Cl(p,q) for the sign of λ: e^{iσπ(p−q)/4} as its exponent k (the eighth root ζ^k, ζ = e^{iπ/4}), its point,
 *  and the turns σ(p − q)/8 the argument of the damped integral runs through on the way */
export function realIndex(p, q, sign = 'positive') {
  const s = sgnOf(sign), k = (((s * (p - q)) % 8) + 8) % 8, a = (Math.PI * k) / 4;
  return { k, z: [Math.cos(a), Math.sin(a)], turn: (s * (p - q)) / 8 };
}
/** the labels' index: the clock sum (Gaussian integers) divided by 2^{n/2}, with the clock c = p − q mod 8 */
export function labelsIndex(p, q) {
  const g = gaussEnd(p, q), m = Math.pow(2, (p + q) / 2);
  return { c: clockOf(p, q), sum: g, z: [g[0] / m, g[1] / m] };
}
/** I(u) by its product form: Π_j (u − iσε_j)^{−1/2}, principal square roots, complex arithmetic factor by factor (generators of square +1 first) */
export function dampedAt(p, q, sign, u) {
  const s = sgnOf(sign);
  let re = 1, im = 0;
  for (let j = 0; j < p + q; j++) {
    const e = j < p ? 1 : -1, a = u, b = -s * e;                       // the factor u − iσε_j = a + ib, a > 0
    const fr = Math.pow(Math.hypot(a, b), -0.5), ft = -Math.atan2(b, a) / 2;
    const fx = fr * Math.cos(ft), fy = fr * Math.sin(ft);
    [re, im] = [re * fx - im * fy, re * fy + im * fx];
  }
  return [re, im];
}
/** the closed form at φ (u = cot φ): (sin φ)^{n/2} e^{iσ(p−q)φ/2} */
export function dampedPhi(p, q, sign, phi) {
  const s = sgnOf(sign), r = Math.pow(Math.sin(phi), (p + q) / 2), a = (s * (p - q) * phi) / 2;
  return [r * Math.cos(a), r * Math.sin(a)];
}
/** the curve drawn: the closed form at φ = (π/2) k / K, k = 0 … K */
export function dampedCurve(p, q, sign = 'positive', K = K_CURVE) {
  return Array.from({ length: K + 1 }, (_, k) => dampedPhi(p, q, sign, (Math.PI / 2) * (k / K)));
}
/** everything the figure draws for a cell and a sign: the curve, the walk of the labels and its scale 2^{−n/2}, the two ends, the box of both */
export function weilIndex(p, q, sign = 'positive') {
  const R = realIndex(p, q, sign), L = labelsIndex(p, q), W = clockWalk(p, q, 'counting'), scale = Math.pow(2, -(p + q) / 2);
  let minX = -1, maxX = 1, minY = -1, maxY = 1;
  for (let k = 0; k < W.xs.length; k++) {
    const x = W.xs[k] * scale, y = W.ys[k] * scale;
    if (x < minX) minX = x; if (x > maxX) maxX = x; if (y < minY) minY = y; if (y > maxY) maxY = y;
  }
  return { p, q, n: p + q, sign, real: R, labels: L, curve: dampedCurve(p, q, sign), walk: W, scale, box: [minX, minY, maxX, maxY], agree: R.k === L.c };
}
