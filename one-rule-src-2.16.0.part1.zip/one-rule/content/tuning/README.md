<!--
SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
Required Notice: Copyright (c) 2026 the Cascade Atlas authors
Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
content/tuning/README.md: the template of the README that tools/export_tuning.mjs writes next to the export (dist/content/tuning/README.md).
A line "{{name}}" is a block the tool writes from the tables: the versions, the counts, the files, the fields (from schema.json), the 29
notions, the status words and the guide's rules (from persona_rules.md), the limits, one example record. Everything else is this file as
written. The tool stops when a block is unknown or a block is left in the output.
-->

# ONE RULE: the Atlas as a tuning set

{{version}}

Every statement of the Atlas is one record in `rows.jsonl`: its words, its label, the known law it states, the checks that ran on it and what it rests on. The files are written at every build from the Atlas's own tables; nothing in them is typed by hand. They are the only files a program needs to read the Atlas. A page of the Atlas prints a statement from the same tables.

## The loop

The sketch behind these files has an input IN₀ go into a model, which gives OUT₁. Read as the input IN₁ of nature, OUT₁ gives OUT₀. The aim is IN₀ → OUT₀. The Atlas takes OUT₁ and gives back OUT₂, which feeds the model again. By labelling IN₁ correctly one should be able to predict OUT₀; that is the aim of the tuning, not a result. Nothing in these files says that the Atlas predicts nature.

In the Atlas's terms a record is one example of the loop.

- **OUT₁**, a statement in the words of one field: `texts`, with its mode, level and register.
- **IN₁**, its label: `notions`, `bits`, `mask`, `signature`, `grade`, `prime`, `address`, with `cells`, `stage`, `kind`, `ptype`, `fields` and `phenomena`.
- **OUT₀**, the known law the statement states: `standardRef`, `homePhys`, `homeMath`, `theorems`. The check that ran on it is the probe: `evidence` with the last recorded run, and `status`.
- **The lenses** are the fields a model must translate between: `readings` in each record and `lenses.json`.
- **The dependencies** are the chains: `depends`. An `equiv` edge links two wordings of one statement, so both leave the same result unchanged; a `contradicts` edge links two statements that cannot both stand as worded.
- **OUT₂**, what the Atlas gives back: the whole record, with its status word.

## Three uses

- **Words to label** (OUT₁ → IN₁): from `texts[].body`, predict `bits`. Grade by exact match, or by the number of bits that differ.
- **Label to law** (IN₁ → OUT₀): from `bits` with `kind`, `stage` and `cells`, predict `homePhys`, `homeMath`, `theorems` and `status`. The recorded run in `evidence[].lastRun` is what a predicted `status` is graded against.
- **Field to field**: from a statement and a lens, predict the lens's term for each Atlas element in `readings`; or `homePhys` from `homeMath` and back.

Hold out whole groups (`group`) or pages (`shownOn`), not random records: an `equiv` edge or a `splitFrom` line repeats a statement in other words, and so do the research and learner texts of one record.

## Files

{{files}}

Read a line-by-line file with any JSON reader, for example:

```python
import json
rows = [json.loads(line) for line in open("rows.jsonl", encoding="utf-8")]
statements = [r for r in rows if r["kind"] != "story"]
```

## One record of rows.jsonl

The keys come in this order in every record. Every key is present in every record; a field with nothing to say is an empty list, an empty string or null.

{{fields}}

{{nested}}

An example record, cut short where a value is long (a cut value ends in …):

```json
{{example}}
```

## The label: 29 notions

A statement is labelled by the set of primitive notions it uses. Each notion is a bit of a mask of 29 bits; its square is +1 when the rule supplies the notion, −1 when it is imported from the literature, 0 when it is an input that the algebra does not supply. `bits` writes the mask with bit 0 first; `prime` is the product of the primes of the notions used. Two statements one notion apart (the masks differ in one bit) are neighbours.

{{notions}}

## Status values

`status` is computed from the label and the evidence, never typed. A statement carries at most one badge; `badge` holds its words.

{{statuses}}

`new` is true while a statement is new in the release.

## The guide's rules

The Atlas's guide quotes a result only with its status word. These are its words and its rules, as the Ask page of the Atlas shows them.

{{status_words}}

### What the guide never says

{{never}}

### Open

{{open}}

## Cite a statement

Cite a statement by its id in square brackets, with its status word: [GRV-012] is quoted with the word its `status` gives. The id never changes and is never reused. A line split from a longer statement ends in a letter (GRV-012b) and shares the label of the first line (`splitFrom`). A page of the Atlas shows a statement at `#/<page>?at=<id>` for each `page` of `shownOn`. Cite the build by the versions of the "Built from" line at the top of this file, which `manifest.json` repeats.

## Limits

{{limits}}

## Licence

PolyForm Noncommercial 1.0.0. Free for noncommercial use only, not for commercial use. Required Notice: Copyright (c) 2026 the Cascade Atlas authors. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0
