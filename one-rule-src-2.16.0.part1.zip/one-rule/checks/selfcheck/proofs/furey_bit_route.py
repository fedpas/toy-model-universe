#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""furey_bit_route.py -- the Peirce blocks of End(V) = M16(R), V = O + O', and the Standard Model content of their ten
edges, computed by the bit rule of Cl(0,8) and, separately, by the octonion matrices of the explicit model.

Statement. The seven Fano-line blades e_a e_b e_c e_8 of Cl(0,8) commute, square to +1 and generate a group of 32
elements: the 16 blades of the Witt torus L (a self-dual code: 1, 14 blades of grade 4, the volume element) with both
signs, -1 being the product of the four line blades that miss a point (for four of the seven points). The sixteen axes
of V are the sixteen sign assignments on L that respect its signed products (the characters of the group that send -1
to -1). The six real blocks O1, O2, H, C, e7R, R have ranks (2, 6, 4, 2, 1, 1),
so End(V) has 62 + 194 real dimensions. omega = L_e7 is a single blade of grade 6 with square -1; it commutes with P_O1,
P_O2, P_H, P_C and with P_e7R + P_R, and exchanges the axes of e7R and R. The 128 blades that commute with omega span
End_C(V) = M8(C), with complex blocks (1, 3, 2, 1, 1) and 16 + 48 complex dimensions; the centraliser dimensions are
(32, 20, 8, 2, 1) and Delta_SM has real dimension 31. Y = P_O2/3 + P_H/2 + P_C has Tr_C Y = 3 over complex dimension 8
and acts on every Peirce piece of End_C(V) by y_i - y_j; the Clifford conjugation (the transpose) maps one direction of
an edge onto the other, antilinearly. The ten edges hold Q_L once, u_R once, the doublet three times, the triplet
(3,1,-1/3) twice, the charged singlet twice and (1,1,0) once: 24 = 16 + 8 complex dimensions in one direction, 48 in
both, the largest edge 12 (the O2-H pair alone). omega' = -R_e7 equals omega D with D = -1 on exactly the axes
{0, 3, 8, 11} (the blocks O1, e7R, R); each of the 15 blades of L other than 1 has eight -1 signs, so every element of
the group other than +1 and -1 has eight; D has four, so D is none of the 32, and no element relates omega and omega' by
a product or by a conjugation.

[bit] BR((-1,)*8) of researchers_checks/bitrule_A.py: blades are masks, products exact (mul, comm, anticomm, rank_fr).
      The octonion model enters once, as data: the Fano lines, the sign of each line blade on each axis, the axis sets
      of the six blocks and the blade expansions of omega and omega'. Peirce dimensions by cosets: the 256 blades are
      16 cosets of L, a product P_a e_m P_b lies in the coset of m, and its rank is taken coset by coset (16 columns).
[std] numpy on reports/furey/model.py, never the bit rule: the computation of run_all.py (ranks, cdim, the Peirce table
      by matrix_rank, D = solve(omega, omega')), the centraliser dimensions of the C block and of the 1 x 1 R block, ad_Y
      on all 128 basis elements of End_C(V), the traces of the 16 torus matrices, and the stored furey_results.json.
      [bit==std]: every number, the signed product table of the 256 blade matrices, the transpose as the conjugation.
[ctl] Y with P_e7R in place of P_C (Tr_C Y = 5/2, not 3); Y with the coefficients (1/2, 1/3, 1) (the tally and the
      eigenvalue test fail); a non-line triple in place of a Fano line (it does not commute); a blade of grade 4 or 3
      in place of omega (square +1); a line blade in place of D (omega D != omega'); one line sign flipped in an axis
      sign vector (a signed product fails); an axis moved from O2 to H (ranks and omega-commutation fail).
Scope. The 16-dimensional model V = O + O' with omega = L_e7 (N. Furey, Standard Model Symmetries and the Nested
      Embeddings of R, C, H, O), one generation, the ten edges. Nothing here decides three generations or the Z2 gauge
      parallel. The script builds no Forms, Lie or Grav object.
Run:  python3 selfcheck/proofs/furey_bit_route.py   (from the package root; also from its own folder, and under -I -B)"""
import os, sys, json, itertools, importlib.util
from fractions import Fraction as F
from collections import Counter, defaultdict
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'FUREY-BIT'
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))                      # the package root
def load(name, *rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, *rel))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
bitrule = load('bitrule_A', 'researchers_checks', 'bitrule_A.py')
OM = load('furey_model', 'reports', 'furey', 'model.py')
BR, comm, anticomm, rank_fr, popcount = bitrule.BR, bitrule.comm, bitrule.anticomm, bitrule.rank_fr, bitrule.popcount

BLOCKS = ['O1', 'O2', 'H', 'C', 'e7R', 'R']                        # the six real blocks
CBLK = ['O1', 'O2', 'H', 'C', 'last']                              # the five complex blocks, last = e7R + R

# ====================================================================================== A. the model, once, as data
head('A. The octonion model (reports/furey/model.py) enters once, as data')
E, omul, Lmat, Rmat, diag2, blk = OM.E, OM.omul, OM.Lmat, OM.Rmat, OM.diag2, OM.blk
I8, I16, Z8 = OM.I8, OM.I16, OM.Z
kk = E[3]; Lk, Rk = Lmat(kk), Rmat(kk); LR = Lk @ Rk
units = [E[m] for m in range(1, 8)]
gm = [blk(Z8, Lmat(u), Lmat(u), Z8) for u in units] + [blk(Z8, I8, -I8, Z8)]
lines = []
for a in range(7):
    for b in range(a + 1, 7):
        pr = omul(units[a], units[b]); c = int(np.argmax(abs(pr))) - 1
        if c > b: lines.append((a, b, c))
def mblade(S):
    M = I16.copy()
    for a in S: M = M @ gm[a]
    return M
MB = {}
for r in range(9):
    for S in itertools.combinations(range(8), r): MB[sum(1 << a for a in S)] = mblade(S)
def mexpand(X):
    """exact blade coefficients trace(B_m^T X) / 16 of a 16 x 16 matrix (the blade matrices are orthonormal for this form)"""
    out = {}
    for m in range(256):
        c = float(np.trace(MB[m].T @ X)) / 16; fr = F(int(np.rint(c * 16)), 16)
        if abs(c - float(fr)) > 1e-12: raise ValueError('coefficient not a multiple of 1/16')
        if fr: out[m] = fr
    return out
def proj(P8, second):
    P = np.zeros((16, 16)); P[:8, :8] = P8
    for m in second: P[8 + m, 8 + m] = 1
    return P
MP = {'O1': proj((I8 - LR) / 2, ()), 'O2': proj((I8 + LR) / 2, ()), 'H': proj(0 * I8, (4, 5, 6, 7)),
      'C': proj(0 * I8, (1, 2)), 'e7R': proj(0 * I8, (3,)), 'R': proj(0 * I8, (0,))}
chk('std', all(np.allclose(P, np.diag(np.diag(P))) for P in MP.values()), 'the six block projectors of the model are diagonal on the 16 axes')
AX = {n: [i for i in range(16) if int(np.rint(MP[n][i, i])) == 1] for n in BLOCKS}
chk('std', AX == {'O1': [0, 3], 'O2': [1, 2, 4, 5, 6, 7], 'H': [12, 13, 14, 15], 'C': [9, 10], 'e7R': [11], 'R': [8]},
    'axis sets: O1 = {0,3}, O2 = {1,2,4,5,6,7}, H = {12,...,15}, C = {9,10}, e7R = {11}, R = {8}')
LM = [(1 << a) | (1 << b) | (1 << c) | (1 << 7) for (a, b, c) in lines]
chk('std', len(lines) == 7 and all(np.allclose(MB[m], np.diag(np.diag(MB[m]))) for m in LM),
    'seven Fano lines from omul %s; their blade matrices are diagonal' % (lines,))
LS = {m: [int(np.rint(x)) for x in np.diag(MB[m])] for m in LM}        # sign of each line blade on each axis
OMEGA_M, OMEGAP_M = diag2(Lk), diag2(-Rk)
OMEGA, OMEGAP = mexpand(OMEGA_M), mexpand(OMEGAP_M)
chk('std', np.allclose(sum(float(c) * MB[m] for m, c in OMEGA.items()), OMEGA_M) and np.allclose(sum(float(c) * MB[m] for m, c in OMEGAP.items()), OMEGAP_M),
    "the blade expansions of omega = L_e7 (%d term) and omega' = -R_e7 (%d terms) rebuild the matrices" % (len(OMEGA), len(OMEGAP)))

# ====================================================================================== B. the Witt torus in the bit rule
head('B. [bit] the seven line blades and the group L they generate, BR((-1,)*8)')
A = BR((-1,) * 8)
ONE = A.one()
def mv(m, c=1): return {m: c}
def eq(x, y): return A.add(x, y, -1) == {}
def S0(x): return x.get(0, 0)                                      # scalar part
def msum(xs):
    out = {}
    for x in xs: out = A.add(out, x)
    return out
chk('bit', all(A.sq(m) == 1 for m in LM), 'the seven line blades e_a e_b e_c e_8 square to +1')
chk('bit', all(comm(A, mv(m), mv(n)) == {} for m in LM for n in LM), 'they commute pairwise')
GRP = {(0, 1)}; frontier = [(0, 1)]                               # signed elements (mask, sign) = sign * e_mask
while frontier:
    nxt = []
    for m, s in frontier:
        for l in LM:
            (mm, ss), = A.mul(mv(m, s), mv(l)).items()
            if (mm, ss) not in GRP: GRP.add((mm, ss)); nxt.append((mm, ss))
    frontier = nxt
SL = sorted({m for m, s in GRP})                                    # the 16 blades of the Witt torus L
chk('bit', len(GRP) == 32 and len(SL) == 16 and all((m, s) in GRP for m in SL for s in (1, -1)),
    'the line blades generate a group of 32 elements: 16 blades, each with both signs, so -1 is in it')
MISS = []
for pt in range(7):
    w = A.one()
    for l, ln in zip(LM, lines):
        if pt not in ln: w = A.mul(w, mv(l))
    MISS.append(w)
chk('bit', all(set(w) == {0} for w in MISS) and [w[0] for w in MISS].count(-1) == 4,
    'the product of the four line blades that miss a point is +-1: %s for the points 0..6' % [w[0] for w in MISS])
chk('bit', Counter(popcount(m) for m in SL) == Counter({0: 1, 4: 14, 8: 1}), 'the 16 blades of L: 1, 14 blades of grade 4 and the volume element')
chk('bit', [x for x in range(256) if all(popcount(x & m) % 2 == 0 for m in SL)] == SL,
    'the 16 masks of L are a self-dual code: they meet each other in even numbers of bits, and no other mask does')
basis = []; span = {0}
for l in LM:
    if l not in span: basis.append(l); span |= {x ^ l for x in span}
chk('bit', len(basis) == 4 and span == set(SL), 'four of the line blades form a basis of L')
def character(signs):
    """the eigenvalue of every unsigned blade e_m, m in L, for the signs given to the four basis blades"""
    chi = {}
    for T in itertools.product((0, 1), repeat=4):
        w = A.one(); val = 1
        for i, t in enumerate(T):
            if t: w = A.mul(w, mv(basis[i])); val *= signs[i]
        (m, s), = w.items(); chi[m] = s * val
    return chi
CHARS = [character(sg) for sg in itertools.product((1, -1), repeat=4)]
def respects(chi): return all(chi[m1] * chi[m2] == A.s(m1, m2) * chi[m1 ^ m2] for m1 in SL for m2 in SL)
chk('bit', len(CHARS) == 16 and all(respects(ch) for ch in CHARS) and len({tuple(ch[m] for m in SL) for ch in CHARS}) == 16,
    'the 16 sign assignments to the basis extend by mul to 16 distinct sign assignments on L, each respecting all 256 signed products (the characters with -1 -> -1)')
model_vec = {k: tuple(LS[m][k] for m in LM) for k in range(16)}
bit_vec = [tuple(ch[m] for m in LM) for ch in CHARS]
match = {k: [i for i, v in enumerate(bit_vec) if v == model_vec[k]] for k in range(16)}
ok_match = all(len(v) == 1 for v in match.values()) and len({v[0] for v in match.values()}) == 16
chk('bit==std', ok_match, 'the 16 axes of the model are the 16 characters of L, one to one (signs of the seven line blades)')
if not ok_match: finish(STEP)
CHI = {k: CHARS[match[k][0]] for k in range(16)}
chk('bit==std', all(CHI[k][m] == int(np.rint(MB[m][k, k])) for k in range(16) for m in SL),
    "on every axis the character equals the diagonal of the model's matrix, for all 16 elements of L")
chk('bit', all(any(anticomm(A, mv(1 << i), mv(m)) == {} for i in range(8)) for m in range(1, 256)),
    'every blade other than 1 anticommutes with a generator, so it is traceless in any representation: trace = 16 x scalar part in M16(R)')

# ====================================================================================== C. projectors as blade sums
head('C. [bit] axis idempotents and block projectors as blade sums')
p = {k: {m: F(CHI[k][m], 16) for m in SL} for k in range(16)}
chk('bit', all(eq(A.mul(p[i], p[j]), p[i] if i == j else {}) for i in range(16) for j in range(16)) and eq(msum(p.values()), ONE),
    'p_k = (1/16) sum_w chi_k(w) w: 16 orthogonal idempotents with sum 1 (by mul)')
P = {n: msum([p[k] for k in AX[n]]) for n in BLOCKS}
chk('bit', all({popcount(m) for m in P[n]} <= {0, 4, 8} for n in BLOCKS), 'the six block projectors are blade sums of grades 0, 4, 8 only')
chk('bit', all(eq(A.mul(P[a], P[b]), P[a] if a == b else {}) for a in BLOCKS for b in BLOCKS) and eq(msum(P.values()), ONE),
    'they are orthogonal idempotents with sum 1 (by mul)')
ranks_bit = [16 * S0(P[n]) for n in BLOCKS]
chk('bit', ranks_bit == [2, 6, 4, 2, 1, 1], 'ranks = 16 x scalar part = (2, 6, 4, 2, 1, 1)')
chk('bit==std', all(mexpand(MP[n]) == P[n] for n in BLOCKS), "the model's six projectors, expanded in blades, are these multivectors")

# ====================================================================================== D. omega
head('D. [bit] omega = L_e7 as a blade, and its centraliser')
chk('bit', len(OMEGA) == 1 and popcount(next(iter(OMEGA))) == 6 and eq(A.mul(OMEGA, OMEGA), {0: -1}),
    'omega is a single blade of grade 6 (mask %s, sign %s) with omega^2 = -1' % (next(iter(OMEGA)), next(iter(OMEGA.values()))))
comw_bit = {n: comm(A, OMEGA, P[n]) == {} for n in BLOCKS}
chk('bit', [comw_bit[n] for n in BLOCKS] == [True, True, True, True, False, False],
    'omega commutes with P_O1, P_O2, P_H, P_C (four of the six) and with neither P_e7R nor P_R')
Q = {'O1': P['O1'], 'O2': P['O2'], 'H': P['H'], 'C': P['C'], 'last': A.add(P['e7R'], P['R'])}
chk('bit', all(comm(A, OMEGA, Q[n]) == {} for n in CBLK), 'omega commutes with P_e7R + P_R: five complex blocks')
WINV = A.scal(OMEGA, -1)
chk('bit', eq(A.mul(A.mul(OMEGA, p[8]), WINV), p[11]) and eq(A.mul(A.mul(OMEGA, p[11]), WINV), p[8]),
    'omega p_8 omega^-1 = p_11 and omega p_11 omega^-1 = p_8: omega exchanges the axes of R and e7R')
CB = [m for m in range(256) if comm(A, mv(m), OMEGA) == {}]
chk('bit', len(CB) == 128, 'the blades commuting with omega: 128; End_C(V) is their span (real dimension 128 = dim M8(C))')
cr_bit = [8 * S0(Q[n]) for n in CBLK]
chk('bit', cr_bit == [1, 3, 2, 1, 1], 'complex ranks (real rank / 2) of the five blocks: (1, 3, 2, 1, 1)')
NC = dict(zip(CBLK, [int(x) for x in cr_bit]))
RR = dict(zip(BLOCKS, [int(x) for x in ranks_bit]))

# ====================================================================================== E. Peirce pieces by cosets
head('E. [bit] Peirce pieces, the rank taken coset by coset')
REP = {m: min(m ^ s for s in SL) for m in range(256)}
COS = defaultdict(list)
for m in range(256): COS[REP[m]].append(m)
chk('bit', len(COS) == 16 and all(len(v) == 16 for v in COS.values()), 'the 256 blades fall into 16 cosets of L, 16 blades each')
OUTSIDE = [0]
def piece_dim(rows):
    """real dimension of the span of the products (m, X): X lies in the coset of m; rank_fr per coset on its 16 blades"""
    byc = defaultdict(list)
    for m, X in rows:
        if not X: continue
        if any(REP[x] != REP[m] for x in X): OUTSIDE[0] += 1
        byc[REP[m]].append(X)
    tot = 0
    for r, Xs in byc.items():
        idx = {c: i for i, c in enumerate(COS[r])}
        tot += rank_fr([{idx[c]: v for c, v in X.items() if c in idx} for X in Xs], 16)
    return tot
P16 = {n: {m: int(16 * c) for m, c in P[n].items()} for n in BLOCKS}          # 16 P: integer coefficients, same spans
Q16 = {n: {m: int(16 * c) for m, c in Q[n].items()} for n in CBLK}
REAL = {}
for b in BLOCKS:
    right = {m: A.mul(mv(m), P16[b]) for m in range(256)}
    for a in BLOCKS: REAL[a, b] = piece_dim([(m, A.mul(P16[a], right[m])) for m in range(256)])
chk('bit', all(REAL[a, b] == RR[a] * RR[b] for a in BLOCKS for b in BLOCKS), 'real table over all 256 blades: dim P_a End(V) P_b = r_a r_b for all 36 pairs')
real_diag = sum(REAL[a, a] for a in BLOCKS); real_off = sum(REAL[a, b] for a in BLOCKS for b in BLOCKS if a != b)
chk('bit', (real_diag, real_off) == (62, 194), 'diagonal 62 and off-diagonal 194, as sums of the computed pieces')
Y = A.add(A.add(A.scal(P['O2'], F(1, 3)), A.scal(P['H'], F(1, 2))), P['C'])
YV = {}
for n in CBLK:
    YQ = A.mul(Y, Q[n]); m0 = next(iter(Q[n])); YV[n] = F(YQ.get(m0, 0)) / Q[n][m0]
chk('bit', all(eq(A.mul(Y, Q[n]), A.scal(Q[n], YV[n])) for n in CBLK) and [YV[n] for n in CBLK] == [0, F(1, 3), F(1, 2), 1, 0],
    'Y = P_O2/3 + P_H/2 + P_C acts on the five blocks as y = (0, 1/3, 1/2, 1, 0): Y Q_a = y_a Q_a')
Y48 = {m: int(48 * c) for m, c in Y.items()}
chk('bit', all(48 * c == int(48 * c) for c in Y.values()), '48 Y has integer coefficients (used in the eigenvalue test)')
CPLX = {}; ady_bad = 0; ady_n = 0
for b in CBLK:
    right = {m: A.mul(mv(m), Q16[b]) for m in CB}
    for a in CBLK:
        rows = []
        for m in CB:
            X = A.mul(Q16[a], right[m]); rows.append((m, X)); ady_n += 1
            if X and not eq(A.add(A.mul(Y48, X), A.mul(X, Y48), -1), A.scal(X, 48 * (YV[a] - YV[b]))): ady_bad += 1
        CPLX[a, b] = piece_dim(rows)
chk('bit', all(CPLX[a, b] == 2 * NC[a] * NC[b] for a in CBLK for b in CBLK),
    'complex table over the 128 omega-commuting blades: dim_R Q_a End_C(V) Q_b = 2 n_a n_b for all 25 pairs')
cdiag = sum(CPLX[a, a] for a in CBLK) // 2; coff = sum(CPLX[a, b] for a in CBLK for b in CBLK if a != b) // 2
chk('bit', (cdiag, coff) == (16, 48), 'complex diagonal 16 and off-diagonal 48, as sums of the computed pieces')
chk('bit', OUTSIDE[0] == 0, 'every product P_a e_m P_b lies in the coset of m, so the rank by cosets is the whole rank')
chk('bit', ady_bad == 0 and ady_n == 128 * 25,
    '[Y, Q_a X Q_b] = (y_a - y_b) Q_a X Q_b for X each of the 128 omega-commuting blades and all 25 ordered pairs: all of End_C(V)')
chk('bit', S0(Y) == F(3, 8) and 16 * S0(Y) == 6 and comm(A, Y, OMEGA) == {},
    'Y: scalar part 3/8, Tr Y = 6; Y commutes with omega, so Tr_C Y = Tr Y / 2 = 3 over complex dimension 16 / 2 = 8')
CENT = {'O_L': sum(CPLX[a, b] for a in ('O1', 'O2') for b in ('O1', 'O2')), 'O_L_and_R': CPLX['O1', 'O1'] + CPLX['O2', 'O2'],
        'H': CPLX['H', 'H'], 'C': CPLX['C', 'C'], 'R': REAL['R', 'R']}
chk('bit', CENT == {'O_L': 32, 'O_L_and_R': 20, 'H': 8, 'C': 2, 'R': 1},
    'centraliser dimensions as Peirce sums: 32 (End_C of O), 20 (its O1 and O2 pieces), 8 (H), 2 (C), 1 (R, real)')
DSM = CENT['O_L_and_R'] + CENT['H'] + CENT['C'] + CENT['R']
chk('bit', DSM == 31, 'dim Delta_SM = 20 + 8 + 2 + 1 = 31, every term computed')

# ====================================================================================== F. the two directions of an edge
head('F. [bit] the two directions of an edge: the Clifford conjugation')
def cconj(x): return {m: A.s(m, m) * c for m, c in x.items()}       # e_m -> e_m^-1 = s(m, m) e_m
chk('bit', all(cconj(A.mul(mv(a), mv(b))) == A.mul(cconj(mv(b)), cconj(mv(a))) for a in range(256) for b in range(256)),
    'x -> x^ (e_m -> e_m^-1) is an anti-automorphism: (e_a e_b)^ = e_b^ e_a^ for all 65,536 blade pairs')
chk('bit', all(cconj(Q[n]) == Q[n] for n in CBLK) and cconj(Y) == Y and eq(cconj(OMEGA), WINV),
    'it fixes the five complex blocks and Y, and sends omega to -omega')
chk('bit', all(eq(cconj(A.mul(OMEGA, mv(m))), A.scal(A.mul(OMEGA, cconj(mv(m))), -1)) for m in CB),
    '(omega X)^ = -omega X^ on End_C(V): the conjugation maps Q_a End_C Q_b onto Q_b End_C Q_a antilinearly, y_a - y_b to y_b - y_a')
chk('bit', all(CPLX[a, b] == CPLX[b, a] for a in CBLK for b in CBLK), 'dim Q_a End_C Q_b = dim Q_b End_C Q_a for all pairs: the factor 2 of the capacity')

# ====================================================================================== G. the ten edges
head('G. [bit] the ten edges with (colour, isospin, Y)')
EDGES = [(a, b) for i, a in enumerate(CBLK) for b in CBLK[i + 1:]]
KIND = {(3, 2, F(1, 6)): 'Q_L', (3, 1, F(2, 3)): 'u_R', (3, 1, F(-1, 3)): 'triplet', (1, 2, F(1, 2)): 'doublet', (1, 1, F(1)): 'charged', (1, 1, F(0)): 'neutral'}
def edge_irrep(a, b, yv):
    col = 3 if 3 in (NC[a], NC[b]) else 1; iso = 2 if 2 in (NC[a], NC[b]) else 1
    if col == 3:
        s, t = (a, b) if NC[a] == 3 else (b, a); return (col, iso, yv[t] - yv[s])   # the coloured block as source
    return (col, iso, abs(yv[b] - yv[a]))                                            # up to conjugation
def tally_of(yv): return Counter(KIND.get(edge_irrep(a, b, yv), 'other') for a, b in EDGES)
IRR = {e: edge_irrep(*e, YV) for e in EDGES}
ONEWAY = {e: CPLX[e] // 2 for e in EDGES}
CAP = {(a, b): (CPLX[a, b] + CPLX[b, a]) // 2 for a, b in EDGES}
for e in EDGES: print('    edge %-4s - %-4s  one way %d C  both ways %2d C  irrep (%s, %s, %s)  %s' % (e[0], e[1], ONEWAY[e], CAP[e], IRR[e][0], IRR[e][1], IRR[e][2], KIND.get(IRR[e], 'other')))
chk('bit', len(EDGES) == 10 and all(ONEWAY[e] == NC[e[0]] * NC[e[1]] == IRR[e][0] * IRR[e][1] for e in EDGES),
    'ten edges; the one-way complex dimension of each (from the table) is n_a n_b = colour x isospin')
TALLY = tally_of(YV)
chk('bit', TALLY == Counter({'Q_L': 1, 'u_R': 1, 'doublet': 3, 'triplet': 2, 'charged': 2, 'neutral': 1}),
    'tally: Q_L (3,2,+1/6) 1, u_R (3,1,+2/3) 1, doublet (1,2,-+1/2) 3, triplet (3,1,-1/3) 2, charged singlet (1,1,-1) 2, (1,1,0) 1')
DIM = {'Q_L': 6, 'u_R': 3, 'triplet': 3, 'doublet': 2, 'charged': 1, 'neutral': 1}
REST = TALLY - Counter({k: 1 for k in DIM})
chk('bit', sum(DIM.values()) == 16 and REST == Counter({'triplet': 1, 'doublet': 2, 'charged': 1}) and sum(DIM[k] * v for k, v in REST.items()) == 8 and sum(ONEWAY.values()) == 24,
    '24 = 16 (one complete set: Q_L, u_R, d_R, L, e_R, nu_R) + 8 (a d_R-type triplet, two doublets, a charged singlet)')
chk('bit', sum(CAP.values()) == 48 and max(CAP.values()) == 12 and [e for e in EDGES if CAP[e] == 12] == [('O2', 'H')] and KIND[IRR['O2', 'H']] == 'Q_L',
    'both directions: sum of 2 n_a n_b = 48; the largest edge, 12, is the O2-H pair alone, Q_L and its conjugate')
YSW = dict(YV, C=YV['last'], last=YV['C'])
YS = A.add(A.add(A.scal(P['O2'], F(1, 3)), A.scal(P['H'], F(1, 2))), Q['last'])
chk('bit', 8 * S0(YS) == 3 and tally_of(YSW) == TALLY,
    'a relabelling of the two complex rank-1 blocks (y = 1 on e7R + R instead of C) keeps Tr_C Y = 3 and the tally: the counting does not tell them apart')

# ====================================================================================== H. omega' = omega D and the torus
head("H. [bit] omega' = omega D, and the Witt torus")
chk('bit', eq(A.mul(OMEGAP, OMEGAP), {0: -1}) and all(comm(A, OMEGAP, Q[n]) == {} for n in CBLK),
    "omega' = -R_e7: square -1, commutes with the five complex blocks")
DM = A.mul(WINV, OMEGAP)
in_L = set(DM) <= set(SL)
SGND = [sum(c * CHI[k][m] for m, c in DM.items()) for k in range(16)] if in_L else [0] * 16
chk('bit', in_L and eq(A.mul(DM, DM), ONE), "D = omega^-1 omega' lies in the span of L (it is diagonal) and D^2 = 1")
MINUS_BIT = [k for k in range(16) if SGND[k] == -1]
chk('bit', all(s in (1, -1) for s in SGND) and MINUS_BIT == [0, 3, 8, 11], 'D = -1 on exactly the axes {0, 3, 8, 11}')
chk('bit', eq(DM, A.add(ONE, A.scal(msum([P['O1'], P['e7R'], P['R']]), -2))) and eq(A.mul(OMEGA, DM), OMEGAP),
    "D = 1 - 2 (P_O1 + P_e7R + P_R): -1 on O1, e7R, R and +1 on O2, H, C; and omega D = omega'")
NEG = {m: sum(1 for k in range(16) if CHI[k][m] == -1) for m in SL}
chk('bit', NEG[0] == 0 and all(NEG[m] == 8 for m in SL if m),
    'each of the 15 blades of L other than 1 has eight -1 signs on the 16 axes (from the characters): every element of the group other than +-1 has eight, -1 has sixteen')
chk('bit', all(sum(CHI[k][m] for k in range(16)) == 16 * S0(mv(m)) == 0 for m in SL if m),
    'the same from the trace: a non-scalar blade has trace 16 x 0 = 0, so as many -1 as +1 signs')
chk('bit', sum(1 for s in SGND if s == -1) == 4 and not any(eq(DM, mv(m, s)) for m, s in GRP),
    'D has four -1 signs, so D is none of the 32 elements of the group')
chk('bit', not any(eq(A.mul(OMEGA, mv(m, s)), OMEGAP) for m, s in GRP), "no element w of the group gives omega w = omega'")
chk('bit', all(any(eq(A.mul(A.mul(mv(m), OMEGA), mv(m, A.s(m, m))), A.scal(OMEGA, s)) for s in (1, -1)) for m in SL) and not eq(OMEGAP, OMEGA) and not eq(OMEGAP, WINV),
    "w omega w^-1 = +-omega for every w in the group, never omega': no element relates omega and omega' by a conjugation")

# ====================================================================================== I. the standard route
head('I. [std] numpy on the model: the computation of run_all.py, completed')
tr = lambda M: int(np.rint(np.trace(M)))
com = lambda X, Y_: X @ Y_ - Y_ @ X
chk('std', np.allclose(LR @ LR, I8), '(L_e7 R_e7)^2 = +1')
ranks_std = [tr(MP[n]) for n in BLOCKS]
chk('std', ranks_std == [2, 6, 4, 2, 1, 1] and all(np.allclose(MP[a] @ MP[b], MP[a] if a == b else 0 * I16) for a in BLOCKS for b in BLOCKS) and np.allclose(sum(MP.values()), I16),
    'six orthogonal idempotents with sum I, ranks (2, 6, 4, 2, 1, 1)')
MBA = np.array([MB[m] for m in range(256)])
chk('std', int(np.linalg.matrix_rank(MBA.reshape(256, -1))) == 256, 'the 256 blade matrices are a basis of M16(R)')
REAL_std = {(a, b): int(np.linalg.matrix_rank(np.array([(MP[a] @ MB[m] @ MP[b]).ravel() for m in range(256)]), tol=1e-9)) for a in BLOCKS for b in BLOCKS}
comw_std = {n: bool(np.allclose(com(OMEGA_M, MP[n]), 0)) for n in BLOCKS}
QM = {'O1': MP['O1'], 'O2': MP['O2'], 'H': MP['H'], 'C': MP['C'], 'last': MP['e7R'] + MP['R']}
cr_std = [tr(QM[n]) // 2 for n in CBLK]
def cdim(gens, n=16):
    Mx = np.vstack([np.kron(np.eye(n), g) - np.kron(g.T, np.eye(n)) for g in gens]); s = np.linalg.svd(Mx, compute_uv=False); return int(n * n - np.sum(s > 1e-9))
def cbasis(gens, n=16):
    Mx = np.vstack([np.kron(np.eye(n), g) - np.kron(g.T, np.eye(n)) for g in gens]); u, s, vt = np.linalg.svd(Mx); r = int(np.sum(s > 1e-9))
    return [vt[r + c].reshape(n, n, order='F') for c in range(n * n - r)]
BM = cbasis([OMEGA_M])
chk('std', np.allclose(OMEGA_M @ OMEGA_M, -I16) and all(np.allclose(com(OMEGA_M, q), 0) for q in QM.values()) and cdim([OMEGA_M]) == 128 and len(BM) == 128,
    'omega = L_e7 on both copies: omega^2 = -1, commutes with the five complex blocks, centraliser of dimension 128')
CPLX_std = {(a, b): int(np.linalg.matrix_rank(np.array([(QM[a] @ X @ QM[b]).ravel() for X in BM]), tol=1e-9)) for a in CBLK for b in CBLK}
YM = MP['O2'] / 3 + MP['H'] / 2 + MP['C']; yf = [0, 1 / 3, 1 / 2, 1, 0]
chk('std', abs(np.trace(YM) / 2 - 3) < 1e-12 and np.allclose(com(YM, OMEGA_M), 0), 'Tr Y / 2 = 3 and [Y, omega] = 0')
ady_std = all(np.allclose(YM @ (QM[a] @ X @ QM[b]) - (QM[a] @ X @ QM[b]) @ YM, (yf[i] - yf[j]) * (QM[a] @ X @ QM[b]))
              for i, a in enumerate(CBLK) for j, b in enumerate(CBLK) for X in BM)
chk('std', ady_std, 'ad_Y = y_a - y_b on Q_a X Q_b for all 128 basis elements of the centraliser and all 25 ordered pairs')
H2 = Lk[4:8, 4:8]; C2 = Lk[1:3, 1:3]
chk('std', np.allclose(Lk[1:3, [0, 3, 4, 5, 6, 7]], 0) and np.allclose(Lk[[0, 3, 4, 5, 6, 7]][:, [1, 2]], 0) and np.allclose(C2 @ C2, -np.eye(2)) and np.allclose(Lk[4:8, :4], 0) and np.allclose(H2 @ H2, -np.eye(4)),
    'L_e7 preserves the C block {i, j} and the H block {l, li, lj, lk} of the second copy, a complex structure on each')
CENT_std = {'O_L': cdim([Lk], 8), 'O_L_and_R': cdim([Lk, Rk], 8), 'H': cdim([Lk[:4, :4]], 4), 'C': cdim([C2], 2), 'R': cdim([Lk[:1, :1]], 1)}
chk('std', CENT_std == {'O_L': 32, 'O_L_and_R': 20, 'H': 8, 'C': 2, 'R': 1} and cdim([H2], 4) == 8,
    'cdim: 32 (L_e7 on O), 20 (L_e7 and R_e7 on O), 8 (the 4 x 4 block, also on the H block of the second copy), 2 (the C block), 1 (the 1 x 1 R block)')
DSTD = np.linalg.solve(OMEGA_M, OMEGAP_M); dd = np.diag(DSTD)
MINUS_STD = [int(i) for i in np.nonzero(dd < 0)[0]]
chk('std', np.allclose(DSTD, np.diag(dd)) and np.allclose(abs(dd), 1) and MINUS_STD == [0, 3, 8, 11], "D = solve(omega, omega') is diagonal, -1 exactly on {0, 3, 8, 11}")
TOR = {tuple([1] * 16)}; fr_ = [tuple([1] * 16)]
while fr_:
    nx = []
    for v in fr_:
        for m in LM:
            w = tuple(int(x * y) for x, y in zip(v, np.rint(np.diag(MB[m])).astype(int)))
            if w not in TOR: TOR.add(w); nx.append(w)
    fr_ = nx
chk('std', len(TOR) == 32 and tuple([-1] * 16) in TOR and all(tuple(-x for x in v) in TOR for v in TOR),
    'the line-blade matrices generate 32 diagonal sign matrices, closed under v -> -v; -I is among them')
TRACES = Counter(sum(v) for v in TOR)
chk('std', TRACES == Counter({0: 30, 16: 1, -16: 1}) and all(sum(1 for x in v if x == -1) == 8 for v in TOR if sum(v) == 0),
    'traces computed: 0 for 30 of them, 16 for I, -16 for -I; an involution of trace 0 on 16 axes has eight -1 signs')
DV = tuple(int(x) for x in np.rint(dd))
chk('std', sum(1 for x in DV if x == -1) == 4 and DV not in TOR, 'D has four -1 signs and is none of the 32 torus matrices')

# ====================================================================================== bit == std
head('I2. [bit==std] the two routes, and the stored result of run_all.py')
SG = np.array([[A.s(a, b) for b in range(256)] for a in range(256)], dtype=float); IDX = np.arange(256)
chk('bit==std', all(np.array_equal(np.rint(MBA[a] @ MBA), SG[a][:, None, None] * MBA[a ^ IDX]) for a in range(256)),
    "the model's 256 blade matrices multiply by the bit rule: B_a B_b = s(a, b) B_(a xor b) for all 65,536 pairs")
chk('bit==std', all(np.array_equal(MB[m].T, A.s(m, m) * MB[m]) for m in range(256)), 'the conjugation x^ is the transpose of the matrices (all 256 blades)')
chk('bit==std', ranks_bit == ranks_std and REAL == REAL_std, 'real ranks and the 36 real Peirce dimensions agree')
chk('bit==std', comw_bit == comw_std and cr_bit == cr_std and CPLX == CPLX_std, 'omega-commuting blocks, complex ranks and the 25 complex Peirce dimensions agree')
chk('bit==std', CENT == CENT_std and DSM == CENT_std['O_L_and_R'] + CENT_std['H'] + CENT_std['C'] + CENT_std['R'], 'centraliser dimensions (32, 20, 8, 2, 1) and 31 agree')
chk('bit==std', MINUS_BIT == MINUS_STD and SGND == list(DV), 'D: the same signs on all 16 axes')
chk('bit==std', {tuple(s * CHI[k][m] for k in range(16)) for m, s in GRP} == TOR, 'the 32 elements of the group on the 16 axes are the 32 torus matrices')
STORED = os.path.join(ROOT, 'furey_results.json')
st = json.load(open(STORED, encoding='utf-8')) if os.path.exists(STORED) else None
chk('std', st is not None, 'the stored result of run_all.py (furey_results.json at the package root) is present')
if st is not None:
    chk('bit==std', st['real_blocks'] == ranks_bit and (st['real_diag'], st['real_off']) == (real_diag, real_off), 'stored: real blocks and 62 + 194')
    chk('bit==std', st['blocks_commuting_with_omega'] == comw_bit and st['complex_blocks'] == cr_bit and (st['complex_diag'], st['complex_off']) == (cdiag, coff),
        'stored: the blocks commuting with omega, the complex blocks and 16 + 48')
    chk('bit==std', st['centralizers'] == CENT and st['delta_SM_real_dim'] == DSM, 'stored: centralisers (32, 20, 8, 2, 1) and 31 (the stored 2 and 1 are written in run_all.py; here they are computed)')
    mine = [(NC[a], NC[b], CAP[a, b], ONEWAY[a, b], str(YV[a] - YV[b])) for a, b in EDGES]
    theirs = [(e['n_a'], e['n_b'], e['capacity_C'], e['one_way_C'], e['y_a_minus_y_b']) for e in st['edges']]
    chk('bit==std', mine == theirs and st['sm_generation_dim'] == 16 and st['extras_dim'] == 8 and st['maxEdge']['capacity_C'] == max(CAP.values()),
        'stored: the ten edges (dimensions, capacities, y_a - y_b), 16 + 8 and the largest edge')
    chk('bit==std', st['omega_prime_over_omega_minus_axes'] == MINUS_BIT, 'stored: the minus axes of D')
    w = st['witt']
    chk('bit==std', w['fano_lines'] == len(LM) and w['axes'] == len(CHARS) and w['omega_is_single_grade_blade'] == popcount(next(iter(OMEGA))) and w['projector_grades'] == sorted({popcount(m) for n in BLOCKS for m in P[n]}),
        'stored: 7 lines, 16 axes, omega of grade 6, projector grades [0, 4, 8]')

# ====================================================================================== J. controls
head('J. [ctl] wrong versions that must fail')
YC1 = A.add(A.add(A.scal(P['O2'], F(1, 3)), A.scal(P['H'], F(1, 2))), P['e7R'])
chk('ctl', 8 * S0(YC1) != 3 and comm(A, YC1, OMEGA) != {}, 'Y with P_e7R in place of P_C: Tr_C Y = %s, not 3, and it no longer commutes with omega' % (8 * S0(YC1)))
YC2 = A.add(A.add(A.scal(P['O2'], F(1, 2)), A.scal(P['H'], F(1, 3))), P['C'])
YV2 = {n: F(A.mul(YC2, Q[n]).get(next(iter(Q[n])), 0)) / Q[n][next(iter(Q[n]))] for n in CBLK}
chk('ctl', tally_of(YV2) != TALLY and 8 * S0(YC2) != 3, 'Y with the coefficients (1/2, 1/3, 1): the tally fails (%s), and Tr_C Y = %s' % (dict(tally_of(YV2)), 8 * S0(YC2)))
YC2_48 = {m: int(48 * c) for m, c in YC2.items()}; bad = 0
for m in CB:
    X = A.mul(A.mul(Q16['O2'], mv(m)), Q16['H'])
    if X and not eq(A.add(A.mul(YC2_48, X), A.mul(X, YC2_48), -1), A.scal(X, 48 * (YV['O2'] - YV['H']))): bad += 1
chk('ctl', bad > 0, 'the eigenvalue test with that wrong Y fails on the O2-H piece (%d blades)' % bad)
NONLINE = next(t for t in itertools.combinations(range(7), 3) if t not in lines)
MT = sum(1 << a for a in NONLINE) | (1 << 7)
chk('ctl', A.sq(MT) != 1 or any(comm(A, mv(MT), mv(l)) != {} for l in LM), 'a non-line triple %s with e_8 in place of a line: its blade does not commute with all line blades' % (NONLINE,))
chk('ctl', not eq(A.mul(mv(0b1111), mv(0b1111)), {0: -1}) and not eq(A.mul(mv(0b111), mv(0b111)), {0: -1}), 'a blade of grade 4 or of grade 3 in place of omega: its square is +1, not -1')
chk('ctl', all(not eq(A.mul(OMEGA, mv(l)), OMEGAP) for l in LM), "a line blade (eight -1 signs) in place of D: omega D != omega'")
REL = [(l1, l2, l3, l4) for (l1, l2), (l3, l4) in itertools.combinations(list(itertools.combinations(LM, 2)), 2) if l1 ^ l2 == l3 ^ l4]
def consistent(v): return all(v[a] * v[b] * A.s(a, b) == v[c] * v[d] * A.s(c, d) for a, b, c, d in REL)
true_ok = all(consistent({l: LS[l][k] for l in LM}) for k in range(16))
flip = [{l: (-LS[l][k] if l == lf else LS[l][k]) for l in LM} for k in range(16) for lf in LM]
chk('ctl', len(REL) == 21 and true_ok and not any(consistent(v) for v in flip) and not any(tuple(v[l] for l in LM) in set(model_vec.values()) for v in flip),
    'one line sign flipped in an axis sign vector (all 16 x 7): a signed product l1 l2 = l3 l4 of mul fails (the 16 true axes pass all 21), and it is no axis of the model')
AXW = dict(AX, O2=[1, 2, 4, 5, 6], H=[7, 12, 13, 14, 15])
PW = {n: msum([p[k] for k in AXW[n]]) for n in BLOCKS}
chk('ctl', [16 * S0(PW[n]) for n in BLOCKS] != [2, 6, 4, 2, 1, 1] and comm(A, OMEGA, PW['O2']) != {}, 'axis 7 moved from O2 to H: the ranks change and omega no longer commutes with the O2 projector')

finish(STEP)
