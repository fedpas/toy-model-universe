#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""lat_unimodular.py: unimodular lattices read through the Gauss sum over L/2L, Construction A, the even indefinite lattices II_{r,s},
and the odd lattice E8 + Z against the cells.   python3 lat_unimodular.py [--fault NONUNIMOD|F2SUM|NODOUBLE|LEECHSTEP|ODDU|SHIFT|NOTNULL|MINUS3|NONCHAR|NOISO]

lat·5  The Gauss sum G(L) = sum over x in L/2L of i^(x.x) (well defined: (x + 2y)^2 = x^2 mod 4), exact Gaussian integers, equals
       2^(n/2) zeta8^sigma, sigma the signature by exact Sylvester inertia, for the unimodular lattices Z, I_{1,1}, I_{9,0}, I_{1,9}, U,
       E8, E8 + E8, E8 + Z, II_{1,9}, II_{9,1}, II_{2,10}, II_{10,2}, II_{2,18}, the two Construction A lattices and the Leech lattice
       below (rank 24 by splitting L/2L in two halves of 2^12 and a Walsh-Hadamard sum).  For the even ones G = +2^(n/2): sigma = 0 mod 8
       is read from the sum.  [bit] for I_{p,q} the clock sum over the labels of Cl(p,q), sum_a i^(|a & P| - |a & Q|), is G(I_{p,q}).
       Recalled: Milgram's formula for every unimodular lattice and that an even unimodular lattice has sigma = 0 mod 8 (van der Blij;
       Milnor and Husemoller, Symmetric Bilinear Forms; Serre, A Course in Arithmetic).
lat·6  Construction A, L = (C + 2Z^n)/sqrt2.  The extended Hamming code [8,4,4] from the cyclic generator 1 + x + x^3 and a parity bit
       (weights 1 + 14 x^4 + x^8): the lattice has an integral even Gram matrix of determinant 1, 240 vectors of norm 2 and 2160 of
       norm 4 (theta coefficients by a count over the code), and its roots have the E8 diagram T_{2,3,5} (simple roots of a generic
       functional).  The Golay code [24,12,8] from the cyclic generator x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1 of length 23 and a parity
       bit (weights 1 + 759 x^8 + 2576 x^12 + 759 x^16 + x^24): the lattice is even, unimodular, of rank 24, with 48 vectors of norm 2,
       the +-sqrt2 e_i, orthogonal in pairs (root system A1^24, the Niemeier lattice of that name: recalled), and 195408 of norm 4: it is
       not the Leech lattice.  The Leech lattice needs a further step: the lattice M spanned by 8 e_i, 4 e_i + 4 e_j, 2c (c in the Golay
       code) and (-3, 1^23), with the form x.y/8 (Conway and Sloane's coordinates), is even and unimodular of rank 24 and has no vector
       of norm 2: every integer vector with x.x = 16 and coordinates of one parity (the 170064 even ones; odd ones have x.x >= 24) fails
       x.b/8 in Z against the basis, the test of M* = M.  Its 196560 minimal vectors: check_T14.py (RSN-031).
lat·7  The hypotheses of the classification: II_{r,s} = U^min(r,s) + E8(+-1)^(|r-s|/8) for (r,s) = (1,1), (1,9), (9,1), (2,10), (10,2),
       (2,18) is integral, even, of determinant +-1 and signature (r,s) (exact); r - s = 0 mod 8.
lat·8  One instance of uniqueness: the lattice of the E10 diagram T_{2,3,7} is even, unimodular, of signature (9,1) and splits as
       U + E8 explicitly: the null vector delta of its affine E8 subdiagram (exact null space) and f = alpha_10 + delta span a plane with
       Gram [[0,-1],[-1,0]]; the eight finite E8 nodes span its orthogonal complement; the change of basis (delta, -f, alpha_1..alpha_8)
       is an integer matrix of determinant +-1 carrying the Gram matrix to U + E8 exactly.  Recalled: existence iff r = s mod 8 and
       uniqueness for r, s >= 1 (Serre; Milnor and Husemoller).
lat·9  E8 + Z (n = 9, sigma = 9) against the cells.  It is odd and unimodular with 2 vectors of norm 1 (I_{9,0} has 18), so it is not
       I_{9,0}; k = (0; 1) is characteristic (k.x = x.x mod 2 on a basis; both sides are linear mod 2), k.k = 1 = sigma mod 8,
       k-perp = E8; (k-perp/2k-perp, x.x/2 mod 2) is non-degenerate with 135 singular and 120 non-singular non-zero classes.  [bit] the
       label form Q(a) = [e_a^2 = -1] on the 256 even labels of Cl(9,0) (bit-rule squares) has the same counts, and an explicit linear
       isometry (symplectic bases with matched values, built here) carries one onto the other, checked on all 256 classes; the same for the
       cells (5,4), (1,8) (p - q = 1 mod 8) and (8,1), (4,5), (0,9) (p - q = -1: the form does not see the sign); the cells with
       p - q = +-3 mod 8 have 119 singular classes and do not match.  For all 484 characteristic vectors of norm k.k <= 9, (0; +-1),
       (0; +-3) and (2u; +-1) with u one of the 240 roots: k-perp has rank 8 and determinant k.k/g^2 (g the gcd of k), and
       k-perp/2k-perp is isometric to the same label form (explicit isometry each); the norm-2 vectors of E8 + Z are the 240 roots of E8
       (E8 is even), and k-perp is the root lattice E8 for the four k = (0; +-1), (0; +-3), and for the 480 others its 126 roots span a rank-7 sublattice
       (E7) of the rank-8 lattice, so it is not a root lattice.
[ctl]  NONUNIMOD (E7, even of determinant 2, in the unimodular list: G = 0), F2SUM ((-1)^(x.x) in place of i^(x.x)), NODOUBLE (Construction A
       on the self-dual code {00,11}^2, not doubly even, asserted even), LEECHSTEP (Construction A on the Golay code asserted root-free),
       ODDU (I_{1,1} in place of U in II_{1,1}), SHIFT (one diagonal entry of E8 changed to 4), NOTNULL (f = alpha_10 in place of
       alpha_10 + delta), MINUS3 (the cell (7,2) asserted to match), NONCHAR (k = (0; 2) asserted characteristic), NOISO (the coordinate
       map in place of the built isometry).
No Forms, Lie or Grav object of the gravity engine is built: its eight engine faults do not apply; the controls are the faults above.
Scope: the lattices named; exact integers and fractions; numpy int64 only for the integrality test of the 170064 Leech candidates.
Command: python3 lat_unimodular.py   (from this folder, or python3 selfcheck/proofs/lat_unimodular.py from the root of the checks)."""
import sys, time, itertools
from fractions import Fraction as Fr
from math import gcd
import numpy as np

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NONUNIMOD', 'F2SUM', 'NODOUBLE', 'LEECHSTEP', 'ODDU', 'SHIFT', 'NOTNULL', 'MINUS3', 'NONCHAR', 'NOISO')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
STEP = 'LAT-UNIMOD' + ('-' + FAULT if FAULT else '')
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact integer lattice tools
def pc(a): return bin(a).count('1')
def det(M):
    A = [[Fr(x) for x in r] for r in M]; n = len(A); d = Fr(1)
    for c in range(n):
        p = next((i for i in range(c, n) if A[i][c] != 0), None)
        if p is None: return Fr(0)
        if p != c: A[c], A[p] = A[p], A[c]; d = -d
        d *= A[c][c]
        for i in range(c + 1, n):
            f = A[i][c] / A[c][c]
            if f: A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return d
def inertia(M):
    """exact signature (pos, neg, zero) by congruence diagonalisation"""
    n = len(M); A = [[Fr(x) for x in r] for r in M]; act = list(range(n)); pos = neg = 0
    while act:
        pv = next((i for i in act if A[i][i] != 0), None)
        if pv is None:
            pr = next(((i, j) for i in act for j in act if i < j and A[i][j] != 0), None)
            if pr is None: break
            i, j = pr
            for k in range(n): A[i][k] += A[j][k]
            for k in range(n): A[k][i] += A[k][j]
            pv = i
        d = A[pv][pv]
        if d > 0: pos += 1
        else: neg += 1
        for i in act:
            if i != pv and A[i][pv] != 0:
                f = A[i][pv] / d
                for k in range(n): A[i][k] -= f * A[pv][k]
                for k in range(n): A[k][i] -= f * A[k][pv]
        act.remove(pv)
    return pos, neg, len(act)
def dsum(*Ms):
    n = sum(len(M) for M in Ms); out = [[0] * n for _ in range(n)]; o = 0
    for M in Ms:
        for i in range(len(M)):
            for j in range(len(M)): out[o + i][o + j] = M[i][j]
        o += len(M)
    return out
def neg(M): return [[-x for x in r] for r in M]
def tree(arms):
    """Cartan matrix of the tree T with a centre and arms of the given numbers of nodes; order: centre, arm 1, arm 2, ..."""
    n = 1 + sum(arms); A = [[2 if i == j else 0 for j in range(n)] for i in range(n)]; k = 1
    for L in arms:
        prev = 0
        for t in range(L):
            A[prev][k] = A[k][prev] = -1; prev = k; k += 1
    return A
E8 = tree([1, 2, 4]); E7 = tree([1, 2, 3]); E10 = tree([1, 2, 6])
U = [[0, 1], [1, 0]]
def diag(*d): return [[d[i] if i == j else 0 for j in range(len(d))] for i in range(len(d))]
def mat_mul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def tr(A): return [list(r) for r in zip(*A)]
def gram(B, scale=1):
    G = [[Fr(sum(x * y for x, y in zip(u, v)), scale) for v in B] for u in B]
    return G
def hnf_basis(gens, n):
    """a basis of the Z-span of integer vectors of length n (full rank assumed): integer row echelon form by gcd steps"""
    rows = [list(g) for g in gens]; basis = []
    for c in range(n):
        piv = [r for r in rows if r[c] != 0]; rest = [r for r in rows if r[c] == 0]
        while len(piv) > 1:
            piv.sort(key=lambda r: abs(r[c])); p0 = piv[0]; new = [p0]
            for r in piv[1:]:
                q = r[c] // p0[c]; r2 = [x - q * y for x, y in zip(r, p0)]
                (new if r2[c] != 0 else rest).append(r2)
            piv = new
        if piv: basis.append(piv[0])
        rows = [r for r in rest if any(r)]
    return basis

# ------------------------------------------------------------------------------------------------ the Gauss sum over L/2L
def gsum_direct(G):
    """sum over x in {0,1}^n of i^(x^T G x), by a Gray-code walk; returns (re, im)"""
    n = len(G); Gx = [0] * n; Q = 0; x = [0] * n; cnt = [0, 0, 0, 0]
    cnt[0] += 1
    for t in range(1, 1 << n):
        j = (t & -t).bit_length() - 1
        if x[j] == 0: Q += 2 * Gx[j] + G[j][j]; s = 1
        else: Q += -2 * Gx[j] + G[j][j]; s = -1
        x[j] ^= 1
        for i in range(n): Gx[i] += s * G[i][j]
        cnt[Q % 4] += 1
    if FAULT == 'F2SUM': return (cnt[0] + cnt[2] - cnt[1] - cnt[3], 0)
    return (cnt[0] - cnt[2], cnt[1] - cnt[3])
IPOW = [(1, 0), (0, 1), (-1, 0), (0, -1)]
def gsum_split(G):
    """rank 24: x = (a, b), i^(Q) = i^(QA(a)) i^(QB(b)) (-1)^(a^T G_AB b); the b-sum is a Walsh-Hadamard transform"""
    n = len(G); h = n // 2
    GA = [r[:h] for r in G[:h]]; GB = [r[h:] for r in G[h:]]
    def qvals(M):
        m = len(M); out = [0] * (1 << m)
        for x in range(1 << m):
            s = 0
            for i in range(m):
                if x >> i & 1:
                    s += M[i][i]
                    for j in range(i + 1, m):
                        if x >> j & 1: s += 2 * M[i][j]
            out[x] = s % 4
        return out
    qa, qb = qvals(GA), qvals(GB)
    if FAULT == 'F2SUM': qa = [2 * (v % 2) for v in qa]; qb = [2 * (v % 2) for v in qb]
    re = [IPOW[v][0] for v in qb]; im = [IPOW[v][1] for v in qb]; m = n - h; L = 1 << m; step = 1
    while step < L:
        for s0 in range(0, L, 2 * step):
            for k in range(s0, s0 + step):
                a1, b1, a2, b2 = re[k], im[k], re[k + step], im[k + step]
                re[k], im[k], re[k + step], im[k + step] = a1 + a2, b1 + b2, a1 - a2, b1 - b2
        step *= 2
    cols = [sum((G[i][h + j] % 2) << j for j in range(m)) for i in range(h)]   # row i of G_AB mod 2 as a mask over b
    totr = toti = 0
    for a in range(1 << h):
        t = 0
        for i in range(h):
            if a >> i & 1: t ^= cols[i]
        ur, ui = IPOW[qa[a]]
        totr += ur * re[t] - ui * im[t]; toti += ur * im[t] + ui * re[t]
    return (totr, toti)
def gsum(G): return gsum_split(G) if len(G) > 18 else gsum_direct(G)
def target(n, s):
    """2^(n/2) zeta8^s = (1+i)^((n+s)/2) (1-i)^((n-s)/2)"""
    z = (1, 0)
    for _ in range((n + s) // 2): z = (z[0] - z[1], z[0] + z[1])
    for _ in range((n - s) // 2): z = (z[0] + z[1], z[1] - z[0])
    return z
def int_mat(G):
    if any(Fr(x).denominator != 1 for r in G for x in r): return None
    return [[int(x) for x in r] for r in G]

# ------------------------------------------------------------------------------------------------ codes and Construction A
def cyclic_code(gpoly, n):
    k = n - max(gpoly)
    rows = []
    for s in range(k):
        v = [0] * n
        for e in gpoly: v[(e + s) % n] = 1
        rows.append(v)
    return rows
def extend(rows): return [r + [sum(r) % 2] for r in rows]
def span(rows):
    words = {0}; n = len(rows[0])
    for r in rows:
        m = sum(b << i for i, b in enumerate(r)); words |= {w ^ m for w in words}
    return words
def theta_A(words, n, mmax):
    """coefficients N(m), m = x.x <= mmax, of C + 2Z^n: per codeword of weight w, [t^m] th_odd^w th_even^(n-w)"""
    def mul(a, b):
        out = [0] * (mmax + 1)
        for i, x in enumerate(a):
            if x:
                for j, y in enumerate(b[:mmax + 1 - i]): out[i + j] += x * y
        return out
    tho = [0] * (mmax + 1); the = [0] * (mmax + 1)
    for k in range(-6, 7):
        if k * k <= mmax: (tho if k % 2 else the)[k * k] += 1
    def pw(a, e):
        out = [1] + [0] * mmax
        for _ in range(e): out = mul(out, a)
        return out
    byw = {}
    for w in words: byw[pc(w)] = byw.get(pc(w), 0) + 1
    tot = [0] * (mmax + 1)
    for w, c in byw.items():
        t = mul(pw(tho, w), pw(the, n - w))
        for m in range(mmax + 1): tot[m] += c * t[m]
    return tot, dict(sorted(byw.items()))
def conA(rows):
    n = len(rows[0]); gens = [list(r) for r in rows] + [[2 if i == j else 0 for i in range(n)] for j in range(n)]
    B = hnf_basis(gens, n); return B, gram(B, 2)

head('lat·5  the Gauss sum over L/2L and the signature')
LATS = [('Z', [[1]]), ('I_{1,1}', diag(1, -1)), ('I_{9,0}', diag(*[1] * 9)), ('I_{1,9}', diag(1, *[-1] * 9)), ('U', U), ('E8', E8),
        ('E8+E8', dsum(E8, E8)), ('E8+Z', dsum(E8, [[1]])), ('II_{1,9}', dsum(U, neg(E8))), ('II_{9,1}', dsum(U, E8)),
        ('II_{2,10}', dsum(U, U, neg(E8))), ('II_{10,2}', dsum(U, U, E8)), ('II_{2,18}', dsum(U, U, neg(E8), neg(E8)))]
if FAULT == 'NONUNIMOD': LATS.append(('E7', E7))
res = []; okall = True
for name, G in LATS:
    d = det(G); p, q, z = inertia(G); n = len(G); g = gsum(G); want = target(n, p - q)
    even = all(G[i][i] % 2 == 0 for i in range(n))
    ok = abs(d) == 1 and z == 0 and g == want and (not even or (g[1] == 0 and g[0] > 0 and (p - q) % 8 == 0))
    okall &= ok; res.append('%s: det %s, sigma %d, G = %s%s' % (name, d, p - q, '%d%+di' % g, ' (even)' if even else ''))
chk('std', okall, 'lat·5: G = 2^(n/2) zeta8^sigma for ' + '; '.join(res))
cl_ok = True
for (p, q) in [(1, 1), (9, 0), (1, 9), (3, 2), (0, 5)]:
    s = [0, 0]
    for a in range(1 << (p + q)):
        e = (pc(a & ((1 << p) - 1)) - pc(a >> p)) % 4; s[0] += IPOW[e][0]; s[1] += IPOW[e][1]
    cl_ok &= tuple(s) == gsum(diag(*([1] * p + [-1] * q)))
chk('bit==std', cl_ok, 'lat·5: the clock sum over the labels of Cl(p,q) equals the Gauss sum of I_{p,q} for (p,q) = (1,1), (9,0), (1,9), (3,2), (0,5)')
g7 = gsum_direct(E7)
chk('ctl', det(E7) == 2 and g7 == (0, 0) and g7 != target(7, 7), 'lat·5: E7 is even of determinant 2: G(E7) = %d%+di, not 2^(7/2) zeta8^7: the formula needs a unimodular lattice (NONUNIMOD)' % g7)
f2 = sum((-1) ** ((x0 * x0 - x1 * x1) % 2) for x0 in (0, 1) for x1 in (0, 1))
chk('ctl', f2 == 0, 'lat·5: the sum of (-1)^(x.x) over I_{1,1}/2I_{1,1} is %d, not 2: the Z4-valued x.x is needed (F2SUM)' % f2)

head('lat·6  Construction A: Hamming gives E8, Golay gives the Niemeier lattice A1^24, the Leech lattice needs a further step')
H = extend(cyclic_code([0, 1, 3], 7)); Hw = span(H)
BH, GH = conA(H); thH, wH = theta_A(Hw, 8, 8)
GHi = int_mat(GH)
evenH = GHi is not None and all(GHi[i][i] % 2 == 0 for i in range(8))
# the roots: integer vectors x = c + 2y of norm x.x = 4, as coordinates; simple roots of a generic functional; their diagram
Rx = [x for x in itertools.product(range(-2, 3), repeat=8) if sum(t * t for t in x) == 4 and sum((t % 2) << i for i, t in enumerate(x)) in Hw]
wt = [10 ** i for i in range(8)]                                         # lexicographic: no root is orthogonal to it
pos = [x for x in Rx if sum(a * b for a, b in zip(x, wt)) > 0]
posset = set(pos)
simple = [x for x in pos if not any(tuple(a - b for a, b in zip(x, y)) in posset for y in pos if y != x)]
C = [[sum(a * b for a, b in zip(u, v)) // 2 for v in simple] for u in simple]
deg = sorted(sum(1 for j in range(len(C)) if j != i and C[i][j] == -1) for i in range(len(C)))
def arms_of(C):
    n = len(C); adj = {i: [j for j in range(n) if j != i and C[i][j] != 0] for i in range(n)}
    cen = [i for i in range(n) if len(adj[i]) == 3]
    if len(cen) != 1 or any(C[i][j] not in (0, -1) for i in range(n) for j in range(n) if i != j): return None
    out = []
    for s in adj[cen[0]]:
        L, prev, cur = 1, cen[0], s
        while True:
            nxt = [t for t in adj[cur] if t != prev]
            if not nxt: break
            prev, cur = cur, nxt[0]; L += 1
        out.append(L)
    return sorted(out)
okH = (sorted(wH.items()) == [(0, 1), (4, 14), (8, 1)] and evenH and det(GH) == 1 and thH[4] == 240 and thH[8] == 2160 and len(Rx) == 240
       and len(simple) == 8 and arms_of(C) == [1, 2, 4] and det(C) == 1)
chk('std', okH, 'lat·6: Hamming [8,4,4] from 1 + x + x^3 (weights %s): (C + 2Z^8)/sqrt2 has an integral even Gram matrix of determinant %s, %d vectors of norm 2 and %d of norm 4; '
    'the 8 simple roots of a generic functional have the diagram with arms %s (T_{2,3,5}, E8), determinant %s' % (wH, det(GH), thH[4], thH[8], arms_of(C), det(C)))
Gol = extend(cyclic_code([0, 2, 4, 5, 6, 10, 11], 23)); Gw = span(Gol)
BG, GG = conA(Gol); thG, wG = theta_A(Gw, 24, 8); GGi = int_mat(GG)
evenG = GGi is not None and all(GGi[i][i] % 2 == 0 for i in range(24))
okG = (sorted(wG.items()) == [(0, 1), (8, 759), (12, 2576), (16, 759), (24, 1)] and evenG and det(GG) == 1 and thG[4] == 48 and thG[8] == 195408)
# the 48 roots are +-2 e_i (x coordinates), orthogonal in pairs
roots24 = [tuple(2 * s if i == j else 0 for i in range(24)) for j in range(24) for s in (1, -1)]
orth = all(sum(a * b for a, b in zip(u, v)) == 0 for u in roots24 for v in roots24 if u != v and tuple(-t for t in u) != v)
okG = okG and orth and len(roots24) == thG[4]
chk('std', okG, 'lat·6: Golay [24,12,8] from x^11 + x^10 + x^6 + x^5 + x^4 + x^2 + 1 (weights %s): (C + 2Z^24)/sqrt2 is even, of determinant %s, rank 24, with %d vectors of norm 2 '
    '(the +-sqrt2 e_i, orthogonal in pairs: root system A1^24) and %d of norm 4 = 759 * 2^8 + 4 * C(24,2): Construction A gives the Niemeier lattice A1^24, not the Leech lattice' % (wG, det(GG), thG[4], thG[8]))
chk('std', gsum(int_mat(GH)) == (16, 0) and gsum(GGi) == (4096, 0), 'lat·5: the Gauss sums of the two Construction A lattices are +2^4 and +2^12 (sigma = 0 mod 8)')
if FAULT == 'LEECHSTEP': chk('std', thG[4] == 0, 'lat·6: Construction A on the Golay code has no vector of norm 2 (LEECHSTEP)')
# the Leech lattice by the further step
gbasis = [r for r in Gol]
gens = [[8 if i == j else 0 for i in range(24)] for j in range(24)]
gens += [[4 if t in (i, j) else 0 for t in range(24)] for i in range(24) for j in range(i + 1, 24)]
gens += [[2 * b for b in r] for r in gbasis] + [[-3] + [1] * 23]
BL = hnf_basis(gens, 24); GL = gram(BL, 8); GLi = int_mat(GL)
evenL = GLi is not None and all(GLi[i][i] % 2 == 0 for i in range(24)); dL = det(GL)
cand = []
for i in range(24):
    for s in (4, -4): v = [0] * 24; v[i] = s; cand.append(v)
for S in itertools.combinations(range(24), 4):
    for sg in itertools.product((2, -2), repeat=4):
        v = [0] * 24
        for t, x in zip(S, sg): v[t] = x
        cand.append(v)
X = np.array(cand, dtype=np.int64); Bn = np.array(BL, dtype=np.int64)
inM = int(np.all((X @ Bn.T) % 8 == 0, axis=1).sum())
chk('std', evenL and dL == 1 and len(cand) == 170064 and inM == 0 and gsum(GLi) == (4096, 0),
    'lat·6: the Leech lattice M (8e_i, 4e_i + 4e_j, 2c, (-3, 1^23); form x.y/8): integral, even, determinant %s, rank 24, Gauss sum +2^12; of the %d integer vectors with x.x = 16 and even coordinates, '
    '%d pass x.b/8 in Z for every basis vector b (M* = M as det = 1); odd vectors have x.x >= 24: M has no vector of norm 2' % (dL, len(cand), inM))
Ctrl = [[1, 1, 0, 0], [0, 0, 1, 1]]; BC, GC = conA(Ctrl); GCi = int_mat(GC)
evenC = all(GCi[i][i] % 2 == 0 for i in range(4))
if FAULT == 'NODOUBLE': chk('std', evenC, 'lat·6: Construction A on {00,11}^2 is even (NODOUBLE)')
chk('ctl', det(GC) == 1 and not evenC, 'lat·6: Construction A on the self-dual code {00,11}^2 (weight 2, not doubly even) is unimodular (det %s) but odd: doubly even is needed (NODOUBLE)' % det(GC))
chk('ctl', thG[4] == 48, 'lat·6: asserting that Construction A on the Golay code is root-free fails: 48 roots (LEECHSTEP)')

head('lat·7  II_{r,s} = U^min(r,s) + E8(+-1)^(|r-s|/8)')
Uu = diag(1, -1) if FAULT == 'ODDU' else U
E8s = [r[:] for r in E8]
if FAULT == 'SHIFT': E8s[0][0] = 4
II = {(1, 1): Uu, (1, 9): dsum(Uu, neg(E8s)), (9, 1): dsum(Uu, E8s), (2, 10): dsum(Uu, Uu, neg(E8s)), (10, 2): dsum(Uu, Uu, E8s), (2, 18): dsum(Uu, Uu, neg(E8s), neg(E8s))}
rows7 = []; ok7 = True
for (r, s), G in II.items():
    p, q, z = inertia(G); d = det(G); ev = all(G[i][i] % 2 == 0 for i in range(len(G)))
    ok7 &= ev and abs(d) == 1 and (p, q, z) == (r, s, 0) and (r - s) % 8 == 0
    rows7.append('(%d,%d): even %s, det %s, inertia (%d,%d,%d)' % (r, s, ev, d, p, q, z))
chk('std', ok7, 'lat·7: ' + '; '.join(rows7))
chk('ctl', inertia(diag(1, -1)) == (1, 1, 0) and abs(det(diag(1, -1))) == 1, 'lat·7: I_{1,1} is unimodular of signature (1,1) but odd (diagonal 1, -1): x.x/2 is not integral on it, so it is not II_{1,1} (ODDU)')
bad = [r[:] for r in E8]; bad[0][0] = 4
chk('ctl', abs(det(dsum(U, bad))) != 1, 'lat·7: U + E8 with one diagonal entry 4 has determinant %s, not +-1 (SHIFT)' % det(dsum(U, bad)))

head('lat·8  the E10 lattice is U + E8')
pE, qE, zE = inertia(E10); dE = det(E10)
aff = [r[:9] for r in E10[:9]]                                      # centre, arm 1 (1), arm 2 (2), arm 3 nodes 4..8 (5): T_{2,3,6}
# null vector of the affine E8 Cartan matrix, exact
A = [[Fr(x) for x in r] for r in aff]; n = 9; piv = []; R = 0
for c in range(n):
    p = next((i for i in range(R, n) if A[i][c] != 0), None)
    if p is None: continue
    A[R], A[p] = A[p], A[R]; A[R] = [x / A[R][c] for x in A[R]]
    for i in range(n):
        if i != R and A[i][c] != 0:
            f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[R])]
    piv.append(c); R += 1
free = [c for c in range(n) if c not in piv]
delta = [Fr(0)] * n
if len(free) == 1:
    delta[free[0]] = Fr(1)
    for i, c in enumerate(piv): delta[c] = -A[i][free[0]]
    den = 1
    for x in delta: den = den * x.denominator // gcd(den, x.denominator)
    delta = [int(x * den) for x in delta]; gg = 0
    for x in delta: gg = gcd(gg, abs(x))
    delta = [x // gg for x in delta]
    if delta[0] < 0: delta = [-x for x in delta]
marks = delta
dvec = marks + [0]; e10 = [0] * 9 + [1]
fvec = [a + b for a, b in zip(e10, dvec)] if FAULT != 'NOTNULL' else e10
def ip(u, v): return sum(u[i] * E10[i][j] * v[j] for i in range(10) for j in range(10))
plane = [[ip(dvec, dvec), ip(dvec, fvec)], [ip(fvec, dvec), ip(fvec, fvec)]]
finite = [i for i in range(10) if i not in (8, 9)]                  # the affine node is the last node of arm 3 inside T_{2,3,6}
Bnew = [dvec, [-x for x in fvec]] + [[1 if t == i else 0 for t in range(10)] for i in finite]
Gnew = mat_mul(mat_mul(Bnew, E10), tr(Bnew))
E8part = [r[2:] for r in Gnew[2:]]
ok8 = ((pE, qE, zE) == (9, 1, 0) and dE == -1 and all(E10[i][i] == 2 for i in range(10)) and len(free) == 1 and sum(marks) == 30 and
       plane == [[0, -1], [-1, 0]] and abs(det(Bnew)) == 1 and Gnew == dsum(U, E8part) and arms_of(E8part) == [1, 2, 4] and det(E8part) == 1)
chk('std', ok8, 'lat·8: E10 (T_{2,3,7}) is even, det %s, inertia (%d,%d,%d); the affine E8 null vector has marks %s (sum %d); delta and f = alpha_10 + delta have Gram %s; '
    'the basis (delta, -f, eight finite E8 nodes) has determinant %s and carries the Gram matrix to U + E8 exactly (the E8 block has arms %s): II_{9,1} = E10 = U + E8' % (dE, pE, qE, zE, marks, sum(marks), plane, det(Bnew), arms_of(E8part)))
chk('ctl', [[ip(dvec, dvec), ip(dvec, e10)], [ip(e10, dvec), ip(e10, e10)]] == [[0, -1], [-1, 2]], 'lat·8: with f = alpha_10 alone the plane has Gram [[0,-1],[-1,2]]: not U, a null partner is needed (NOTNULL)')

head('lat·9  E8 + Z against the cells (GOS-006c)')
L9 = dsum(E8, [[1]])
def vnorm(G, x): return sum(x[i] * G[i][j] * x[j] for i in range(len(G)) for j in range(len(G)))
even8 = all(E8[i][i] % 2 == 0 for i in range(8))                      # E8 even: its vectors have even norm, so no norm 1
n1_E8Z = 0 + 2 if even8 else None                                     # (e, m) with e.e + m^2 = 1: e = 0 (E8 even, e.e = 0 only for e = 0, positive definite), m = +-1
n1_I9 = sum(1 for i in range(9) for s in (1, -1))
pd8 = inertia(E8) == (8, 0, 0)
k = [0] * 8 + ([2] if FAULT == 'NONCHAR' else [1])
def is_char(G, k): return all((sum(G[i][j] * k[j] for j in range(len(G))) - G[i][i]) % 2 == 0 for i in range(len(G)))
p9, q9, z9 = inertia(L9)
chk('std', abs(det(L9)) == 1 and (p9, q9) == (9, 0) and not all(L9[i][i] % 2 == 0 for i in range(9)) and pd8 and n1_E8Z == 2 and n1_I9 == 18,
    'lat·9: E8 + Z is odd, unimodular, of signature %d; E8 is even and positive definite, so the vectors of norm 1 are (0; +-1): 2 of them, where I_{9,0} has %d: E8 + Z is not I_{9,0}' % (p9 - q9, n1_I9))
chk('std', is_char(L9, k) and vnorm(L9, k) % 8 == (p9 - q9) % 8, 'lat·9: k = (0; 1) is characteristic (k.x = x.x mod 2 on every basis vector), k.k = %d = sigma mod 8 (van der Blij)' % vnorm(L9, k))
# F_2 quadratic spaces: q given as a table on coordinate vectors 0..2^m-1
def qtab_from_gram(G):
    m = len(G); return [ (vnorm(G, [(x >> i) & 1 for i in range(m)]) // 2) % 2 for x in range(1 << m)]
def bpol(qt, x, y): return (qt[x ^ y] ^ qt[x] ^ qt[y]) & 1
def nondeg(qt, m): return all(any(bpol(qt, x, y) for y in range(1 << m)) for x in range(1, 1 << m))
def counts(qt): return (sum(1 for x in range(1, len(qt)) if qt[x] == 0), sum(1 for x in range(1, len(qt)) if qt[x] == 1))
def hyp_basis(qt, m):
    """a symplectic basis u1, v1, ..., with q(u) = q(v) = 0 (Arf 0) or the last pair of type (1,1); returns the list of pairs, or None"""
    W = list(range(1, 1 << m)); pairs = []
    while W:
        Wset = set(W) | {0}
        u = next((x for x in W if qt[x] == 0 and any(bpol(qt, x, y) for y in W)), None)
        if u is None:
            u = W[0]
        v = next((y for y in W if bpol(qt, u, y)), None)
        if v is None: return None
        if qt[u] == 0 and qt[v] == 1: v ^= u
        pairs.append((u, v))
        W = [w for w in W if bpol(qt, w, u) == 0 and bpol(qt, w, v) == 0]
    return pairs
def isometry(qa, qb, m):
    """a linear map F_2^m -> F_2^m (as images of the vectors) with qb(phi(x)) = qa(x) for all x, from matched symplectic bases"""
    Pa, Pb = hyp_basis(qa, m), hyp_basis(qb, m)
    if Pa is None or Pb is None or len(Pa) != len(Pb) or [(qa[u], qa[v]) for u, v in Pa] != [(qb[u], qb[v]) for u, v in Pb]: return None
    ba = [x for p in Pa for x in p]; bb = [x for p in Pb for x in p]
    # express every x in the basis ba (Gaussian elimination over F_2 by brute force on 2^m combinations)
    img = {}
    for c in range(1 << m):
        x = 0; y = 0
        for i in range(m):
            if c >> i & 1: x ^= ba[i]; y ^= bb[i]
        img[x] = y
    if len(img) != 1 << m: return None
    return img
def verify(qa, qb, img): return img is not None and all(qb[img[x]] == qa[x] for x in range(len(qa))) and len(set(img.values())) == len(qa)
def sgn(a, b, eps):
    s = 1
    for i in range(len(eps)):
        if a >> i & 1:
            if pc(b & ((1 << i) - 1)) & 1: s = -s
            if b >> i & 1: s *= eps[i]
    return s
def label_form_even(p, q):
    """Q(a) = [e_a^2 = -1] on the even labels of Cl(p,q), in the basis f_i = e_i + e_n (i < n)"""
    n = p + q; eps = [1] * p + [-1] * q; out = []
    for y in range(1 << (n - 1)):
        a = 0
        for i in range(n - 1):
            if y >> i & 1: a ^= (1 << i) | (1 << (n - 1))
        out.append(1 if sgn(a, a, eps) == -1 else 0)
    return out
qE8 = qtab_from_gram(E8)
qcell = label_form_even(9, 0)
iso = isometry(qE8, qcell, 8)
if FAULT == 'NOISO': iso = {x: x for x in range(256)}
chk('std', nondeg(qE8, 8) and counts(qE8) == (135, 120), 'lat·9: k-perp = E8, (k-perp/2k-perp, x.x/2 mod 2): polar form non-degenerate, %d singular and %d non-singular non-zero classes' % counts(qE8))
chk('bit', counts(qcell) == (135, 120), 'lat·9: the label form [e_a^2 = -1] on the 256 even labels of Cl(9,0) (bit-rule squares): %d singular, %d non-singular non-zero labels' % counts(qcell))
chk('bit==std', verify(qE8, qcell, iso), 'lat·9: an explicit linear isometry (matched symplectic bases) carries (E8/2E8, x.x/2) onto the even labels of Cl(9,0) with Q, checked on all 256 classes')
rows9 = []; ok9 = True
for (p, q) in [(9, 0), (5, 4), (1, 8), (8, 1), (4, 5), (0, 9), (7, 2), (3, 6), (6, 3), (2, 7)]:
    qc = label_form_even(p, q); cn = counts(qc); im = isometry(qE8, qc, 8); match = verify(qE8, qc, im)
    want = (p - q) % 8 in (1, 7)
    if FAULT == 'MINUS3' and (p, q) == (7, 2): want = True
    ok9 &= (match == want) and (cn == ((135, 120) if want else (119, 136)) or FAULT == 'MINUS3')
    rows9.append('(%d,%d) %s %s' % (p, q, cn, 'iso' if match else 'no'))
chk('bit==std', ok9, 'lat·9: the even-part label forms of the cells with p + q = 9 against E8/2E8: ' + '; '.join(rows9) + ': they match exactly when p - q = +-1 mod 8')
chk('ctl', counts(label_form_even(7, 2)) == (119, 136), 'lat·9: the cell (7,2) (p - q = 5 = -3 mod 8) has 119 singular even labels, not 135: the comparison can fail (MINUS3)')
chk('ctl', not is_char(L9, [0] * 8 + [2]), 'lat·9: k = (0; 2) is not characteristic: k.z = 2 is even, z.z = 1 is odd (NONCHAR)')
coord = {x: x for x in range(256)}
chk('ctl', not verify(qE8, qcell, coord), 'lat·9: the coordinate map (simple root alpha_i -> e_i + e_9) is not an isometry: the polar forms differ off the diagram edges (NOISO)')
# all characteristic vectors of norm <= 9
def e8_roots():
    simple = [tuple(1 if t == i else 0 for t in range(8)) for i in range(8)]
    seen = set(simple); frontier = list(simple)
    while frontier:
        new = []
        for x in frontier:
            for i in range(8):
                c = sum(x[a] * E8[a][i] for a in range(8))
                y = tuple(x[t] - (c if t == i else 0) for t in range(8))
                if y not in seen: seen.add(y); new.append(y)
        frontier = new
    return sorted(seen)
R240 = e8_roots()
def kernel_basis(l):
    """a basis of {x in Z^m : l.x = 0}, by unimodular column operations"""
    m = len(l); T = [[1 if i == j else 0 for j in range(m)] for i in range(m)]; v = list(l)
    while sum(1 for x in v if x != 0) > 1:
        nz = [i for i in range(m) if v[i] != 0]; i0 = min(nz, key=lambda i: abs(v[i]))
        for j in nz:
            if j != i0:
                qq = v[j] // v[i0]; v[j] -= qq * v[i0]
                for r in range(m): T[r][j] -= qq * T[r][i0]
    i0 = next(i for i in range(m) if v[i] != 0)
    return [[T[r][j] for r in range(m)] for j in range(m) if j != i0], abs(v[i0])
KS = [[0] * 8 + [s] for s in (1, -1, 3, -3)] + [[2 * x for x in u] + [s] for u in R240 for s in (1, -1)]
nK = 0; okK = True; rootlat = 0; e7like = 0
for kv in KS:
    if not is_char(L9, kv) or vnorm(L9, kv) > 9: okK = False; continue
    lf = [sum(L9[i][j] * kv[j] for j in range(9)) for i in range(9)]
    Kb, g0 = kernel_basis(lf)
    GK = [[(sum(u[i] * L9[i][j] * v[j] for i in range(9) for j in range(9))) for v in Kb] for u in Kb]
    qk = qtab_from_gram(GK)
    okK &= len(Kb) == 8 and abs(det(GK)) * g0 * g0 == vnorm(L9, kv) and nondeg(qk, 8) and verify(qk, qcell, isometry(qk, qcell, 8))
    rts = [r + (0,) for r in R240 if sum(r[i] * E8[i][j] * kv[j] for i in range(8) for j in range(8)) == 0]
    rk = 0; rowsr = [list(r) for r in rts]; M = [[Fr(x) for x in r] for r in rowsr]
    for c in range(9):
        pr = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if pr is None: continue
        M[rk], M[pr] = M[pr], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        rk += 1
    if len(rts) == 240 and rk == 8: rootlat += 1
    elif len(rts) == 126 and rk == 7: e7like += 1
    nK += 1
chk('std', okK and nK == 484 and rootlat == 4 and e7like == 480,
    'lat·9: all %d characteristic vectors with k.k <= 9 ((0; +-1), (0; +-3), (2u; +-1), u a root): k-perp has rank 8, determinant k.k/g^2 (g the gcd of k: 3 for (0; +-3)), and k-perp/2k-perp is isometric to the even-part label form of Cl(9,0) '
    '(explicit isometry each); k-perp is the root lattice E8 for %d of them and has 126 roots spanning rank 7 (E7) for %d: those are not root lattices' % (nK, rootlat, e7like))
print('  (total %.1f s)' % (time.time() - T0))
finish(STEP)
