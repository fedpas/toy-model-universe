#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_tensor.py -- the energy of the shifted theory of Atiyah and Moore ("A shifted view of fundamental physics", section 2 with the
remarks 2.1-2.2, read), completed: the four translation currents T^mu_nu of the nonlocal action for fields of space and time, packets of plane
waves, the Lorentz currents and the Belinfante tensor, the complex equation off its modes, and a potential with a gradient (remark 2.2.4).

Read.  The paper writes the shifted Dirac equation (i hbar D - m c + i k exp(-r D)) psi = 0 (2.2), its plane waves with
E_0/c - m c + i k exp(i r E_0/hbar c) = 0 (2.5) and the quantization r E_0/hbar c = (n + 1/2) pi (2.6), the action int vol psi-bar (i hbar D_+ - m c) psi
(2.10), "from which one can derive the energy-momentum tensor T_mu.nu" (not written), the weak field (2.11) with S = Phi gamma^0 d_0 +
(1/2) gamma_i d_i Phi; remark 2.2.3: roots with non-zero real parts, "unacceptable behavior in the past or future"; remark 2.2.4: "mathematical
difficulties ... arise from the mixing of the positive and negative frequencies in the presence of external forces".
Conventions of coupling_selfcheck.py, shifted_dirac.py, shifted_weakfield.py and shifted_energy.py: labels of Cl(1,3), bit 0 = time (square +1);
J = gamma_2 gamma_1; a plane wave of sector s is P exp(s J k.x), k.x = k_0 x^0 - k_i x^i, P even; nabla = gamma^mu d_mu with gamma^mu =
(gamma_0, -gamma_1, -gamma_2, -gamma_3), so that nabla acts on it as s khat P J; bD(P) = (nabla P) gamma_0, bD^2 = box; on L-fields (the phase on the
left, Q = P~ on the solutions) bD'(Q) = gamma_0 (d_mu Q) gamma^mu; O[P] = bD(P) J - m P + kappa (exp(-tau bD) P) J (hbar = c = 1, kappa = k, tau = r,
mu = kappa tau); L = <Q O[P]>_S, <a>_S = <a>_0 - <a J>_0 J.  On a plane wave of mass E = sqrt Q(k), exp(-s bD) is the right factor e^{+-J E s} on
the two halves (the ordinary solutions of mass E and of mass -E), exact when E s is on the quarter turns; numbers are exact in Q[pi].
The tensor (derived here).  Integrating by parts in the power series of exp(-tau bD) and summing with the Beta integral:
   <Q O[V]>_S - <Y[Q] V>_S = d_mu W^mu[Q, V],   Y[Q] = -J bD'(Q) - m Q + kappa J exp(tau bD')(Q),
   W^mu[Q, V] = <Q gamma^mu V gamma_0 J>_S - kappa int_0^tau ds <exp(s bD')(Q) gamma^mu exp(-(tau - s) bD)(V) gamma_0 J>_S,
and T^mu_nu = W^mu[Q, d_nu P] - delta^mu_nu L: the local part plus the bilocal (generating-function) term; on fields of time alone and nu = 0 it
is the delay formula of shifted_energy.py.  The Lorentz generator delta P = B P/2 - xi^nu d_nu P (xi = B x x) commutes with bD, and its current is
M^mu = -xi^nu T^mu_nu + S^mu[B], S^mu[B] = (1/2) W^mu with B put between gamma^mu and the shifted field.

Statements.
(1) [st.OFF] Off shell, exactly, on pairs of sums of three plane waves (rest and moving, both signs of the frequency), for O, H, A, D_s, D_c:
    d_mu T^mu_nu = -<Y[Q] d_nu P>_S - <d_nu Q O[P]>_S, nu = 0 ... 3.  [st.ONE] On one quantized shell (any number of waves) T = (1 - (-1)^n mu J) T_loc,
    conserved, and the local part alone is conserved too; on one wave T^mu_nu = (1 - (-1)^n mu J) X^mu k_nu, X = P gamma_0 P~ (the factor of en.GRAV),
    at rest the energy of en.NOETHER.  [st.TWO] On two shells at one shift the cross terms of the bilocal part are exactly minus those of the local
    part; the local part alone is not conserved.  [st.STD] Dirac matrices with quad_vec and finite differences agree.
(2) [st.PACK] On a packet of five waves of one mass exp(-s bD) translates each wave along its own time direction k/E (forward or backward with the
    sign of the frequency), and exp(-tau bD) P = P e^{J E tau} for the packet; no wave's own direction serves the packet; the bilocal integrand at
    an interior s pairs two segments; conservation on packets of five waves on one and on two shells.
(3) [st.COV] exp(-s bD) and the whole tensor are covariant under a rational rotor (boost and rotation), off shell.  [st.SPIN] Off shell
    d_mu S^mu[gamma_rho gamma_sigma] = T_sigma.rho - T_rho.sigma + <Q B O[P]>_S/2 - <Y[Q] B P>_S/2.  [st.BEL] The Belinfante tensor T + d_lambda G^lambda,
    G_lambda.mu.nu = (S_lambda.mu.nu - S_mu.lambda.nu - S_nu.lambda.mu)/2, is conserved and symmetric on the solutions; on one mode it equals T (the energy
    E_0 (1 - (-1)^n mu J) per unit density unchanged, the density too); on superpositions it changes the density at the cross frequencies only.
(4) [st.SYMB] On every plane wave the operator is the right factor f_J(+-E) = +-E - m + kappa J e^{+-J E tau} on the two halves (quarter turns and
    rational points of the circle).  [st.ROOT] The roots for complex frequency are E_k = m + i W_k(-mu e^{i m tau})/tau (scipy lambertw, k = -8 ... 8),
    with a two-dimensional kernel of the 4 x 4 symbol at rest and moving; real roots exactly at the quantized shifts; growth on one half, decay on the
    other.  [st.HERMC] H and D_s: real roots and complex roots in conjugate pairs.  [st.OFFM] Off the modes the Noether energy is conserved with the
    adjoint's own solutions and complex, not with the Dirac conjugate.
(5) [st.GRAD] For A_0 = g x_3 and Phi = g x_3 the first-order operator on a quantized rest mode, exactly: the shift adds a mixing into the advanced
    half; a constant potential does not mix.  [st.SOL] The first-order solution of the ordinary equation of mass E solves the shifted one exactly:
    the quantized mode survives with its frequency, and the two signs of frequency mix in the solutions as for the ordinary equation.
[bit]  Exact Q[pi] on the labels (bmul of coupling_selfcheck.py); st.ROOT's label line in floats.
[std]  numpy and scipy, never the labels: complex 4 x 4 Dirac matrices (Dirac representation), scipy expm, quad_vec, lambertw, numpy lstsq, SVD
       kernels, complex Newton from a grid, five-point and central differences; the labels hand their fields over through the dictionary
       Z -> M(Z) u0 (u0 = (1, 0, 0, 0), M(J) u0 = i u0) only, so that the two routes compute on the same fields.
[ctl]  Each wrong version is also a --fault option that puts it into the main lines (the run must then end with FAILS):
       NOBILOCAL  the bilocal term dropped from the currents;          SAMEPOINT  the bilocal integrand with both fields at x, no shift;
       ADJSIGN    exp(-tau bD') in the adjoint;                         ONEDIR     every wave of a packet shifted along the first wave's direction;
       NOSPINBIL  the spin current without its bilocal part;            EXPSIGN    the dispersion relation E - m + kappa e^{-i E tau} (no factor i);
       FREESHIFT  the shift built with the free bD in a potential;      NOCOMM     x_3 treated as a constant inside the shift.
Scope.  Finite sums of plane waves on rational shells with E tau on the quarter turns (exact); the canonical tensor of the delay formula and its
       Belinfante improvement; complex roots on 17 branches at five (m, kappa, tau); a linear potential to first order in g, x_3-polynomials of
       degree <= 3 on the labels at rest (<= 6 on Dirac matrices, rest and moving); no quantized field, no experiment, no claim about nature.
Run:   python3 shifted_tensor.py [--fault NOBILOCAL|SAMEPOINT|ADJSIGN|ONEDIR|NOSPINBIL|EXPSIGN|FREESHIFT|NOCOMM]
       (from the package root as selfcheck/proofs/shifted_tensor.py; also from its own folder, and under -I -B)"""
import os, sys, time, math, random
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad, quad_vec
from scipy.special import lambertw
import warnings
from scipy.integrate import IntegrationWarning
warnings.filterwarnings('ignore', category=IntegrationWarning)

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
if not os.path.isfile(os.path.join(_selfcheck, 'coupling_selfcheck.py')):
    raise SystemExit('coupling_selfcheck.py not found in ' + _selfcheck + ': this file belongs in selfcheck/proofs/ of the package')
if _selfcheck not in sys.path: sys.path.insert(0, _selfcheck)
import coupling_selfcheck as cs

# ------------------------------------------------------------------------------------------------ check lines and faults
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('NOBILOCAL', 'SAMEPOINT', 'ADJSIGN', 'ONEDIR', 'NOSPINBIL', 'EXPSIGN', 'FREESHIFT', 'NOCOMM')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact numbers: Q[pi] (as in shifted_energy.py)
class QP:
    """a_0 + a_1 pi + a_2 pi^2 + ... with rational a_k (pi is transcendental: an identity in Q[pi] is an identity of real numbers)"""
    __slots__ = ('c',)
    def __init__(self, c=0):
        if isinstance(c, QP): self.c = dict(c.c)
        elif isinstance(c, dict): self.c = {k: Fr(v) for k, v in c.items() if v != 0}
        else:
            v = Fr(c); self.c = {0: v} if v else {}
    @staticmethod
    def of(x): return x if isinstance(x, QP) else QP(x)
    def __add__(self, o):
        o = QP.of(o); d = dict(self.c)
        for k, v in o.c.items():
            w = d.get(k, 0) + v
            if w: d[k] = w
            else: d.pop(k, None)
        r = QP(); r.c = d; return r
    __radd__ = __add__
    def __neg__(self): r = QP(); r.c = {k: -v for k, v in self.c.items()}; return r
    def __sub__(self, o): return self + (-QP.of(o))
    def __rsub__(self, o): return QP.of(o) + (-self)
    def __mul__(self, o):
        o = QP.of(o); d = {}
        for i, a in self.c.items():
            for j, b in o.c.items():
                w = d.get(i + j, 0) + a * b
                if w: d[i + j] = w
                else: d.pop(i + j, None)
        r = QP(); r.c = d; return r
    __rmul__ = __mul__
    def __truediv__(self, o):
        o = QP.of(o); assert set(o.c) == {0}, 'division by a non-zero rational only'
        r = QP(); r.c = {k: v / o.c[0] for k, v in self.c.items()}; return r
    def __eq__(self, o): return self.c == QP.of(o).c
    def __ne__(self, o): return not self.__eq__(o)
    def __hash__(self): return hash(tuple(sorted(self.c.items())))
    def __bool__(self): return bool(self.c)
    def __float__(self): return float(sum(float(v) * math.pi ** k for k, v in self.c.items()))
    def rational(self): return set(self.c) <= {0}
    def __repr__(self):
        if not self.c: return '0'
        return ' + '.join(str(v) if k == 0 else ('%s pi' % v if k == 1 else '%s pi^%d' % (v, k)) for k, v in sorted(self.c.items())).replace('+ -', '- ')
PI = QP({1: 1}); ZERO = QP(0); UNIT = QP(1)
def fsqrt(q):
    """the exact square root of a non-negative rational square, else None"""
    q = Fr(q)
    if q < 0: return None
    a, b = math.isqrt(q.numerator), math.isqrt(q.denominator)
    return Fr(a, b) if a * a == q.numerator and b * b == q.denominator else None

# ------------------------------------------------------------------------------------------------ the labels of Cl(1,3): bmul of coupling_selfcheck.py
SQ = cs.sqs(4)                                                                  # bit 0 = time, square +1; bits 1-3 square -1
def pc(x): return bin(x).count('1')
def mmul(a, b):
    out = {}
    for x, cx in a.items():
        for y, cy in b.items():
            m, s = cs.bmul(x, y, SQ); p = cx * cy
            v = out.get(m, ZERO) + (p if s > 0 else -p)
            if v: out[m] = v
            else: out.pop(m, None)
    return out
def mlin(*terms):
    out = {}
    for c, a in terms:
        c = QP.of(c)
        for m, v in a.items():
            w = out.get(m, ZERO) + c * v
            if w: out[m] = w
            else: out.pop(m, None)
    return out
def mrev(a): return {m: (v if cs.rsign(pc(m)) > 0 else -v) for m, v in a.items()}
def blade(m, c=1): return {m: QP.of(c)}
ONE = blade(0); GAM = [blade(1 << mu) for mu in range(4)]; G0 = GAM[0]
_Jm, _Js = cs.bmul(1 << 2, 1 << 1, SQ); J = blade(_Jm, _Js)                       # J = gamma_2 gamma_1, as in coupling_selfcheck.py
GUP = [G0] + [mlin((-1, GAM[i])) for i in (1, 2, 3)]                            # gamma^mu: nabla = gamma^mu d_mu acts on P e^{s J k.x} as s khat P J
G0J = mmul(G0, J); EVEN = [m for m in range(16) if pc(m) % 2 == 0]
ETA = (1, -1, -1, -1)
assert mmul(J, J) == mlin((-1, ONE)) and mmul(J, G0) == mmul(G0, J)
def scal(a): return a.get(0, ZERO)
def Sproj(a):
    """<a>_S = <a>_0 - <a J>_0 J: the J-complex part (span{1, J}), the image of the Dirac pairing's complex value"""
    return mlin((scal(a), ONE), (-scal(mmul(a, J)), J))
def zre(z): return scal(z)
def zim(z): return -scal(mmul(z, J))                                            # z = zre + zim J
def zc(a, b=0): return mlin((a, ONE), (b, J))                                   # the J-complex number a + b J
def phase(beta, c):
    """exact e^{J beta c} for a rational frequency beta and a shift c in Q[pi]: beta c must be 0 or a multiple of pi/2"""
    th = QP.of(c) * beta
    if not th: return ONE
    if set(th.c) == {1} and (2 * th.c[1]).denominator == 1:
        return [ONE, J, mlin((-1, ONE)), mlin((-1, J))][int(2 * th.c[1]) % 4]
    raise ValueError('inexact phase: beta c = %r' % th)
def vec(b):
    """b-check = sum_mu b_mu gamma^mu for a frequency b (the Euclidean pairing e^{J b.x}, b.x = sum b_mu x^mu)"""
    return mlin(*[(b[mu], GUP[mu]) for mu in range(4) if b[mu]])
def Qf(b): return b[0] * b[0] - b[1] * b[1] - b[2] * b[2] - b[3] * b[3]
def Emass(b):
    E = fsqrt(Qf(b))
    if not E: raise ValueError('frequency %r is not on a rational timelike shell' % (b,))
    return E
def kvec(k, s):
    """the frequency b of the plane wave P exp(s J k.x), k.x = k_0 x^0 - k_i x^i: b = s (k_0, -k_1, -k_2, -k_3)"""
    return tuple(Fr(s) * Fr(k[0]) if mu == 0 else -Fr(s) * Fr(k[mu]) for mu in range(4))
def fadd(*terms):
    """sum of fields (dicts key -> multivector) with Q[pi] coefficients"""
    out = {}
    for c, F in terms:
        for k, v in F.items():
            w = mlin((1, out.get(k, {})), (c, v))
            if w: out[k] = w
            else: out.pop(k, None)
    return out
def zmul(z, w): return mmul(z, w)                                               # J-complex numbers commute
def fmt_q(x):
    if not x.c: return '0'
    out = ''
    for k in sorted(x.c):
        v = x.c[k]; a = abs(v); sgn = '-' if v < 0 else '+'
        if k == 1: body = ('pi' if a.numerator == 1 else '%d pi' % a.numerator) + ('' if a.denominator == 1 else '/%d' % a.denominator)
        else: body = str(a) if k == 0 else '%s pi^%d' % (a, k)
        out += (('-' if sgn == '-' else '') + body) if not out else (' %s %s' % (sgn, body))
    return out
def fmt_z(z):
    a, b = zre(z), zim(z)
    if not b: return fmt_q(a)
    bs = fmt_q(b); neg = bs.startswith('-'); bs = bs.lstrip('-')
    if ' ' in bs and ('+' in bs or ' - ' in bs): bs = '(' + bs + ')'
    if not a: return ('-' if neg else '') + bs + ' J'
    return '%s %s %s J' % (fmt_q(a), '-' if neg else '+', bs)

# ------------------------------------------------------------------------------------------------ fields of space and time: finite sums of plane waves
# an R-field is {b: Z}: the sum of Z e^{J b.x} (the phase on the right, as P exp(s J k.x) in shifted_dirac.py; b.x = sum_mu b_mu x^mu);
# an L-field is {a: Y}: the sum of e^{J a.x} Y (the phase on the left: the reverse of an R-field is one);
# a C-field is {nu: z} with z in span{1, J}: the values of the pairing <Q P>_S, a J-complex trigonometric polynomial in x.
def rf_rmul(F, R): return {b: w for b, Z in F.items() for w in [mmul(Z, R)] if w}
def lf_lmul(R, Q): return {a: w for a, Y in Q.items() for w in [mmul(R, Y)] if w}
def rf_deriv(F, mu): return {b: w for b, Z in F.items() if b[mu] for w in [mlin((b[mu], mmul(Z, J)))] if w}
def lf_deriv(Q, mu): return {a: w for a, Y in Q.items() if a[mu] for w in [mlin((a[mu], mmul(J, Y)))] if w}
def rf_D(F):
    """bD(F) = (nabla F) gamma_0 = sum_mu gamma^mu (d_mu F) gamma_0: on Z e^{J b.x} it is b-check Z J gamma_0"""
    return {b: w for b, Z in F.items() for w in [mmul(mmul(vec(b), Z), G0J)] if w}
def lf_Dp(Q):
    """bD'(Q) = sum_mu gamma_0 (d_mu Q) gamma^mu: on e^{J a.x} Y it is gamma_0 J Y a-check (the reverse of bD on the reverse)"""
    return {a: w for a, Y in Q.items() for w in [mmul(mmul(G0J, Y), vec(a))] if w}
def rf_parts(b, Z):
    """Z = Z_+ + Z_-: bD acts as -E Z_+ J and +E Z_- J (E = sqrt Q(b)); exp(-s bD) is the right factor e^{+-J E s} on them"""
    E = Emass(b); t = mlin((Fr(-1) / (2 * E), mmul(mmul(vec(b), Z), G0)))
    return E, mlin((Fr(1, 2), Z), (1, t)), mlin((Fr(1, 2), Z), (-1, t))
def lf_parts(a, Y):
    """Y = Y_+ + Y_-: exp(s bD') is the left factor e^{+-J E s} on them"""
    E = Emass(a); t = mlin((Fr(1) / (2 * E), mmul(mmul(G0, Y), vec(a))))
    return E, mlin((Fr(1, 2), Y), (1, t)), mlin((Fr(1, 2), Y), (-1, t))
def rf_shift(F, s):
    """exp(-s bD) F, exact for E s on the quarter turns"""
    out = {}
    for b, Z in F.items():
        E, Zp, Zm = rf_parts(b, Z)
        out = fadd((1, out), (1, {b: mlin((1, mmul(Zp, phase(E, s))), (1, mmul(Zm, phase(-E, s))))}))
    return out
def lf_shift(Q, s):
    """exp(+s bD') Q"""
    out = {}
    for a, Y in Q.items():
        E, Yp, Ym = lf_parts(a, Y)
        out = fadd((1, out), (1, {a: mlin((1, mmul(phase(E, s), Yp)), (1, mmul(phase(-E, s), Ym)))}))
    return out
def rf_rev(F): return {tuple(-x for x in b): mrev(Z) for b, Z in F.items()}
def fsum_key(a, b): return tuple(x + y for x, y in zip(a, b))
def pair(Q, F):
    """<Q(x) F(x)>_S for an L-field Q and an R-field F: a C-field; <e^{J a.x} Y Z e^{J b.x}>_S = <Y Z>_S e^{J (a + b).x}"""
    out = {}
    for a, Y in Q.items():
        for b, Z in F.items():
            z = Sproj(mmul(Y, Z))
            if z: out = fadd((1, out), (1, {fsum_key(a, b): z}))
    return out
def cdiv(cur):
    """sum_mu d_mu of a current given as four C-fields"""
    out = {}
    for mu in range(4):
        for nu, z in cur[mu].items():
            if nu[mu]: out = fadd((1, out), (nu[mu], {nu: mmul(z, J)}))
    return out
def ceval(C, x):
    """a C-field at a point, as a complex number (J -> i)"""
    v = 0j
    for nu, z in C.items():
        th = sum(float(nu[mu]) * x[mu] for mu in range(4))
        v += complex(float(zre(z)), float(zim(z))) * complex(math.cos(th), math.sin(th))
    return v
def cconst(C): return C.get((0, 0, 0, 0), {})

# ------------------------------------------------------------------------------------------------ the shifted operators as term lists; apply, adjoint, concomitant
# ('kin', c, R): c bD(V) R;   ('mass', c): c V;   ('shift', c, R, t): c exp(-t bD)(V) R  (R in {1, J} commutes with J and with gamma_0).
# L = <Q O[P]>_S.  Integrating by parts in the power series (and summing with the Beta integral) gives, for every V,
#   <Q O[V]>_S - <Y[Q] V>_S = d_mu W^mu[Q, V],
#   Y[Q] = sum -c R bD'(Q) (kin) + c Q (mass) + c R exp(t bD')(Q) (shift),
#   W^mu = sum c <Q gamma^mu V gamma_0 R>_S (kin)  -  sum c int_0^t ds <exp(s bD')(Q) gamma^mu exp(-(t - s) bD)(V) gamma_0 R>_S (shift):
# the bilocal (generating-function) term.  On plane waves exp(s bD') and exp(-(t - s) bD) are left and right phases on the parts, and the
# s-integral of e^{J w s} is t (w = 0) or -J (e^{J w t} - 1)/w: exact when every E t is on the quarter turns.
def ops(m, kap, tau):
    m, kap, tau = QP.of(m), QP.of(kap), QP.of(tau); kin = [('kin', UNIT, J)]; mass = [('mass', -m)]
    return {'O': kin + mass + [('shift', kap, J, tau)],
            'H': kin + mass + [('shift', -kap / 2, J, -tau), ('shift', kap / 2, J, tau)],                 # bD J - m - kappa sinh(tau bD) J
            'A': [('shift', kap / 2, J, -tau), ('shift', kap / 2, J, tau)],                              # kappa cosh(tau bD) J
            'Ds': kin + mass + [('shift', kap / 2, J, -tau), ('shift', -kap / 2, J, tau)],                # D_s: + kappa sinh(tau bD) J
            'Dc': kin + mass + [('shift', -kap / 2, ONE, -tau), ('shift', -kap / 2, ONE, tau)],           # D_c as printed: - kappa cosh(tau bD)
            'ORD': kin + [('mass', -m)]}
def apply_op(T, V):
    out = {}
    for term in T:
        if term[0] == 'kin': out = fadd((1, out), (term[1], rf_rmul(rf_D(V), term[2])))
        elif term[0] == 'mass': out = fadd((1, out), (term[1], V))
        else: out = fadd((1, out), (term[1], rf_rmul(rf_shift(V, term[3]), term[2])))
    return out
def adjoint_op(T, Q):
    out = {}
    for term in T:
        if term[0] == 'kin': out = fadd((1, out), (-term[1], lf_lmul(term[2], lf_Dp(Q))))
        elif term[0] == 'mass': out = fadd((1, out), (term[1], Q))
        else:
            t = -term[3] if fault('ADJSIGN') else term[3]                         # ADJSIGN: exp(-t bD') in the adjoint
            out = fadd((1, out), (term[1], lf_lmul(term[2], lf_shift(Q, t))))
    return out
def Iint(w, t):
    """int_0^t e^{J w s} ds as a J-complex number"""
    if w == 0: return zc(t)
    return mlin((Fr(-1) / w, mmul(J, mlin((1, phase(w, t)), (-1, ONE)))))
def conc(T, Q, V, ins=None, parts=False):
    """the concomitant W^mu[Q, V] (four C-fields); ins: a multivector put between gamma^mu and the V factor (the spin current);
    parts: also return the local and the bilocal pieces"""
    loc = [dict() for _ in range(4)]; bil = [dict() for _ in range(4)]
    for term in T:
        if term[0] == 'mass': continue
        if term[0] == 'kin':
            c, R = term[1], term[2]; G0R = mmul(G0, R)
            for a, Y in Q.items():
                for b, Z in V.items():
                    Zi = mmul(ins, Z) if ins else Z; key = fsum_key(a, b)
                    for mu in range(4):
                        z = Sproj(mmul(mmul(mmul(Y, GUP[mu]), Zi), G0R))
                        if z: loc[mu] = fadd((1, loc[mu]), (c, {key: z}))
            continue
        c, R, t = term[1], term[2], term[3]; G0R = mmul(G0, R)
        if fault('NOBILOCAL'): continue
        for a, Y in Q.items():
            Ea, Yp, Ym = lf_parts(a, Y)
            for b, Z in V.items():
                Eb, Zp, Zm = rf_parts(b, Z); key = fsum_key(a, b)
                if fault('SAMEPOINT'): combos = [(Y, Z, zc(t))]                   # SAMEPOINT: both factors at x, no shift
                else:
                    combos = [(Y1, Z2, mmul(phase(e2 * Eb, t), Iint(e1 * Ea - e2 * Eb, t)))
                              for e1, Y1 in ((1, Yp), (-1, Ym)) for e2, Z2 in ((1, Zp), (-1, Zm)) if Y1 and Z2]
                for Y1, Z2, fac in combos:
                    Zi = mmul(ins, Z2) if ins else Z2
                    for mu in range(4):
                        z = Sproj(mmul(mmul(mmul(Y1, GUP[mu]), Zi), G0R))
                        if z: bil[mu] = fadd((1, bil[mu]), (-c, {key: mmul(z, fac)}))
    tot = [fadd((1, loc[mu]), (1, bil[mu])) for mu in range(4)]
    return (tot, loc, bil) if parts else tot
def tensor(T, Q, P, parts=False):
    """T^mu_nu = W^mu[Q, d_nu P] - delta^mu_nu L, as tt[mu][nu] (C-fields); parts: also the local and bilocal pieces"""
    L = pair(Q, apply_op(T, P)); tt = [[None] * 4 for _ in range(4)]; tl = [[None] * 4 for _ in range(4)]; tb = [[None] * 4 for _ in range(4)]
    for nu in range(4):
        tot, loc, bil = conc(T, Q, rf_deriv(P, nu), parts=True)
        for mu in range(4):
            tt[mu][nu] = fadd((1, tot[mu]), (-1, L)) if mu == nu else tot[mu]
            tl[mu][nu] = fadd((1, loc[mu]), (-1, L)) if mu == nu else loc[mu]
            tb[mu][nu] = bil[mu]
    return (tt, tl, tb) if parts else tt
def tdiv(tt, nu): return cdiv([tt[mu][nu] for mu in range(4)])

# ================================================================================================ (1) the tensor of the nonlocal action
head('(1) [st·OFF, st·ONE, st·TWO] the four translation currents T^mu_nu of the shifted action: local part plus the bilocal term; conservation off and on shell')
def rand_mv(rg, blades=EVEN, lo=-2, hi=2):
    while True:
        Z = {m_: QP(rg.randint(lo, hi)) for m_ in blades}; Z = {m_: v for m_, v in Z.items() if v}
        if Z: return Z
def wave(k, s, Z): return {kvec(k, s): Z}
def mode_amp(k, s, rg):
    """an amplitude in the half that solves the ordinary equation of mass E = sqrt Q(k) in sector s (the kernel of the paper's operator on its shell)"""
    E, Zp, Zm = rf_parts(kvec(k, s), rand_mv(rg))
    return Zp if Zp else mode_amp(k, s, rg)
SH_OFF = [((4, 1, PI / 2), [((5, 0, 0, 0), -1), ((13, 12, 0, 0), -1), ((5, 0, 0, 4), 1)], [((3, 0, 0, 0), 1), ((7, 6, 2, 0), -1), ((5, 4, 0, 0), -1)]),
          ((3, 2, PI / 10), [((13, 0, 0, 12), -1), ((7, 2, 4, 2), 1), ((17, 8, 0, 0), -1)], [((5, 0, 0, 0), 1), ((10, 0, 0, 0), -1), ((13, 12, 0, 0), 1)])]
ok_off = True; noff = 0
for (m_, kap, tau), Pw, Qw in SH_OFF:
    OP = ops(m_, kap, tau)
    for iname, name in enumerate(('O', 'H', 'A', 'Ds', 'Dc')):
        rg = random.Random(800 + 31 * iname + m_)
        P = fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Pw]); Q = rf_rev(fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Qw])); noff += 1
        T = OP[name]; tt = tensor(T, Q, P); Y = adjoint_op(T, Q); OPP = apply_op(T, P)
        for nu in range(4):
            ok_off &= tdiv(tt, nu) == fadd((-1, pair(Y, rf_deriv(P, nu))), (-1, pair(lf_deriv(Q, nu), OPP)))
chk('bit', ok_off, 'st.OFF: off shell, exactly in Q[pi], on %d pairs of independent fields (P, Q), each a sum of three plane waves with random integer amplitudes on the 8 even blades, at rest and moving (k = (13,12,0,0), (5,0,0,4), (7,6,2,0), (7,2,4,2), (17,8,0,0), ...; both signs of the frequency), for the operators O, H, A, D_s and D_c at (m, kappa, tau) = (4, 1, pi/2) and (3, 2, pi/10): T^mu_nu = W^mu[Q, d_nu P] - delta^mu_nu L, W the local part <Q gamma^mu V gamma_0 J>_S minus kappa int_0^tau ds <exp(s bD\')(Q) gamma^mu exp(-(tau - s) bD)(V) gamma_0 J>_S, satisfies d_mu T^mu_nu = -<Y[Q] d_nu P>_S - <d_nu Q O[P]>_S for nu = 0 ... 3: the four currents are conserved wherever the equation and its adjoint hold' % noff)
def onshell(T, P): return not apply_op(T, P) and not adjoint_op(T, rf_rev(P))
def cmulz(C, z): return {k: w for k, v in C.items() for w in [mmul(v, z)] if w}
def tt_map(f, *tts): return [[f(*[t[mu][nu] for t in tts]) for nu in range(4)] for mu in range(4)]
def tt_eq(A, B): return all(A[mu][nu] == B[mu][nu] for mu in range(4) for nu in range(4))
def tt_zero(A): return all(not A[mu][nu] for mu in range(4) for nu in range(4))
def tt_sub(A, B): return tt_map(lambda a, b: fadd((1, a), (-1, b)), A, B)
def cons(tt): return all(not tdiv(tt, nu) for nu in range(4))
def nkeys(tt): return len({k for mu in range(4) for nu in range(4) for k in tt[mu][nu] if any(k)})
def factor(kap, tau, n): return zc(1, -(-1) ** n * QP.of(kap) * tau)          # 1 - (-1)^n mu J
ONE_SH = [((3, 2, PI / 10), 5, 0, [((5, 0, 0, 0), -1), ((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)]),
          ((4, 1, PI / 2), 5, 2, [((13, 0, 0, 12), -1), ((5, 0, 0, 0), 1), ((Fr(25, 4), 0, 0, Fr(15, 4)), -1)]),
          ((4, 1, PI / 2), 3, 1, [((5, 4, 0, 0), -1), ((7, 6, 2, 0), -1), ((3, 0, 0, 0), 1)]),
          ((3, 2, 3 * PI / 2), 1, 1, [((Fr(5, 4), Fr(3, 4), 0, 0), -1), ((Fr(5, 3), 0, Fr(4, 3), 0), 1)])]
ok_sh = True; ok_fac = True; ok_c1 = True; ok_cl = True; ncross = 0; desc1 = []
for (m_, kap, tau), E_, n, waves in ONE_SH:
    OP = ops(m_, kap, tau); rg = random.Random(9000 + m_ + n); F = factor(kap, tau, n)
    assert E_ == m_ + (-1) ** n * kap and E_ * tau == (n + Fr(1, 2)) * PI
    P = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s in waves]); ok_sh &= onshell(OP['O'], P)
    tt, tl, tb = tensor(OP['O'], rf_rev(P), P, parts=True); ncross += nkeys(tt)
    ok_fac &= tt_eq(tt, tt_map(lambda c: cmulz(c, F), tl)) and nkeys(tt) > 0
    ok_c1 &= cons(tt); ok_cl &= cons(tl)
    desc1.append('E = %s at (%s, %s, %s): factor %s' % (E_, m_, kap, fmt_q(QP.of(tau)), fmt_z(F)))
chk('bit', ok_sh, 'st.ONE: on one quantized shell (E tau = (n + 1/2) pi, E = m + (-1)^n kappa) superpositions of two or three plane waves with different k, both signs of the frequency (k = (5,0,0,0), (13,12,0,0), (7,2,4,2) at E = 5; (13,0,0,12), (25/4,0,0,15/4) at E = 5; (5,4,0,0), (7,6,2,0), (3,0,0,0) at E = 3; (5/4,3/4,0,0), (5/3,0,4/3,0) at E = 1), amplitudes in the half of mass E: O[P] = 0 and the adjoint Y[P~] = 0 exactly')
chk('bit', ok_fac and ok_c1, 'st.ONE: on the same superpositions T^mu_nu = (1 - (-1)^n mu J) T_loc^mu_nu exactly, all sixteen components, cross terms included (%d frequencies other than zero): the bilocal term is -(-1)^n mu J times the local part, because on one shell the s-dependence of its integrand cancels; d_mu T^mu_nu = 0 for nu = 0 ... 3 (%s)' % (ncross, '; '.join(desc1)))
chk('bit', ok_cl, 'st.ONE: on one shell the local part alone is conserved as well (it is the canonical tensor of the ordinary equation of mass E): dropping the bilocal term changes the value by the factor 1 - (-1)^n mu J, not the conservation')
# the values: a rest wave (pass seven's energy) and a moving wave (the factor of en.GRAV), sector -1
ok_rest = True; ok_mov = True; vdesc = []
for (m_, kap, tau), E_, n, k in (((3, 2, PI / 10), 5, 0, (5, 0, 0, 0)), ((3, 2, 3 * PI / 2), 1, 1, (1, 0, 0, 0)), ((3, 2, PI / 10), 5, 0, (13, 12, 0, 0)), ((4, 1, PI / 2), 3, 1, (7, 6, 2, 0))):
    OP = ops(m_, kap, tau); rg = random.Random(77 + E_); Z = mode_amp(k, -1, rg); P = wave(k, -1, Z); F = factor(kap, tau, n)
    tt = tensor(OP['O'], rf_rev(P), P); X = mmul(mmul(Z, G0), mrev(Z)); rho = scal(mmul(mrev(Z), Z))
    Xu = [scal(mmul(GUP[mu], X)) for mu in range(4)]; kl = [Fr(k[0])] + [-Fr(k[i]) for i in (1, 2, 3)]
    ok_mov &= all(tt[mu][nu] == ({(0, 0, 0, 0): mlin((Xu[mu] * kl[nu], F))} if Xu[mu] * kl[nu] else {}) for mu in range(4) for nu in range(4))
    ok_mov &= all(Xu[mu] * Fr(k[0]) == Xu[0] * Fr(k[mu]) for mu in range(4))            # the current is parallel to k: T^{mu nu} symmetric
    if not any(k[1:]):
        ok_rest &= cconst(tt[0][0]) == mlin((rho * E_, F)); vdesc.append('E = %s at rest: T^0_0 = (%s) rho' % (E_, fmt_z(mlin((E_, F)))))
chk('bit', ok_rest and ok_mov, 'st.ONE: on one wave of sector -1 T^mu_nu = (1 - (-1)^n mu J) X^mu k_nu exactly, X = P gamma_0 P~ the current (parallel to k, so T^{mu nu} is symmetric), k_nu = (k_0, -k_i): the factor of a moving wave that en.GRAV found on the k-derivative of the symbol (k = (13,12,0,0) at E = 5, (7,6,2,0) at E = 3); at rest the energy of pass seven, %s' % '; '.join(vdesc))
# two quantized shells at one shift: E_1 = m + kappa, E_2 = m - kappa with kappa tau an odd multiple of pi/2 (ATY-040), moving waves
TWO_SH = [((4, 1, PI / 2), [((13, 12, 0, 0), -1, 5), ((5, 0, 0, 0), -1, 5)], [((5, 0, 0, 4), -1, 3)]),
          ((4, 1, PI / 2), [((13, 0, 12, 0), -1, 5)], [((7, 6, 2, 0), 1, 3), ((5, 4, 0, 0), -1, 3)]),
          ((2, -1, PI / 2), [((Fr(5, 4), Fr(3, 4), 0, 0), -1, 1)], [((5, 0, 4, 0), -1, 3), ((3, 0, 0, 0), 1, 3)]),
          ((2, 1, 3 * PI / 2), [((5, 4, 0, 0), -1, 3)], [((Fr(5, 3), 0, 0, Fr(4, 3)), -1, 1)])]
ok_2sh = True; ok_2c = True; ok_2x = True; ok_2loc = True; ok_2bx = True; n2x = 0
for (m_, kap, tau), wa, wb in TWO_SH:
    OP = ops(m_, kap, tau); rg = random.Random(4242 + m_)
    PA = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s, E_ in wa]); PB = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s, E_ in wb])
    P = fadd((1, PA), (1, PB)); ok_2sh &= onshell(OP['O'], P) and wa[0][2] != wb[0][2]
    tt, tl, tb = tensor(OP['O'], rf_rev(P), P, parts=True)
    tA, lA, _ = tensor(OP['O'], rf_rev(PA), PA, parts=True); tB, lB, _ = tensor(OP['O'], rf_rev(PB), PB, parts=True)
    ok_2c &= cons(tt)
    ok_2x &= tt_zero(tt_sub(tt_sub(tt, tA), tB))                                   # no cross term between the shells survives
    lx = tt_sub(tt_sub(tl, lA), lB); n2x += nkeys(lx)
    ok_2loc &= not cons(tl) and not tt_zero(lx)
    ok_2bx &= tt_eq(tt_sub(tt_sub(tb, tt_sub(tA, lA)), tt_sub(tB, lB)), tt_map(lambda c: cmulz(c, mlin((-1, ONE))), lx))
chk('bit', ok_2sh and ok_2c, 'st.TWO: two quantized shells at one shift ((m, kappa, tau) = (4, 1, pi/2) with E = 5 and 3, (2, -1, pi/2) with E = 1 and 3, (2, 1, 3 pi/2) with E = 3 and 1; two or three moving waves, both signs of the frequency): O[P] = 0, Y[P~] = 0, and d_mu T^mu_nu = 0 for nu = 0 ... 3 exactly')
chk('bit', ok_2x and ok_2bx, 'st.TWO: on the same sums the cross terms between the two shells cancel identically: the bilocal cross term is exactly minus the local one in all sixteen components (its s-integral is (e^{J (E_1 - E_2) tau} - 1)/(J (E_1 - E_2)) = 2J/(E_1 - E_2), which with e^{J E tau} = (-1)^n J gives -1), so T of the sum is the sum of the two shells\' tensors')
chk('ctl', ok_2loc, 'st.TWO: the local part alone carries cross terms between the shells (%d frequencies) and is not conserved on any of the four sums: on two shells the bilocal term is what makes the currents conserved' % n2x)
# ------------------------------------------------------------------------------------------------ the standard route: Dirac matrices, never the labels
# Dirac representation (Gamma_0^2 = 1, Gamma_k^2 = -1); D = G^mu d_mu with G^mu = (Gamma_0, -Gamma_1, -Gamma_2, -Gamma_3), so that D acts on
# u e^{i b.x} as i b-check, b-check = b_mu G^mu.  The action psi-bar (i D - m + i kappa exp(-tau D)) psi; the tensor
# T^mu_nu = i phi-bar G^mu d_nu psi - i kappa int_0^tau ds (phi-bar e^{s D<-}) G^mu (e^{-(tau - s) D} d_nu psi) - delta^mu_nu L with scipy expm,
# the s-integral by scipy quad_vec, the divergence by five-point finite differences in x.  The labels enter only through the dictionary below,
# used to hand both routes the same fields: an even multivector Z is the matrix M(Z) (products of Gamma's) applied to u0 = (1, 0, 0, 0), for
# which Gamma_0 u0 = u0 and M(J) u0 = i u0, so that right multiplication by J is multiplication by i and <A>_S is u0^dagger M(A) u0.
S1 = np.array([[0, 1], [1, 0]], complex); S2 = np.array([[0, -1j], [1j, 0]]); S3 = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
GM = [np.block([[I2, 0 * I2], [0 * I2, -I2]])] + [np.block([[0 * I2, s_], [-s_, 0 * I2]]) for s_ in (S1, S2, S3)]; I4 = np.eye(4)
GU = [GM[0], -GM[1], -GM[2], -GM[3]]
BLM = {}
for m_ in range(16):
    Mx = I4.copy()
    for i in range(4):
        if m_ >> i & 1: Mx = Mx @ GM[i]
    BLM[m_] = Mx
for x_ in range(16):
    for y_ in range(16):
        mm, sg = cs.bmul(x_, y_, SQ); assert np.allclose(BLM[x_] @ BLM[y_], sg * BLM[mm]), 'the dictionary is not a representation'
U0 = np.array([1, 0, 0, 0], complex)
def Mof(Z): return sum(float(v) * BLM[m_] for m_, v in Z.items()) if Z else 0 * I4
assert np.allclose(GM[0] @ U0, U0) and np.allclose(Mof(J) @ U0, 1j * U0)
assert all(abs(U0.conj() @ BLM[m_] @ U0) < 1e-15 for m_ in EVEN if m_ not in (0, _Jm))
def colwaves(P): return [(Mof(Z) @ U0, np.array([float(x) for x in b])) for b, Z in P.items()]
def rowwaves(Q): return [(U0.conj() @ Mof(Y), np.array([float(x) for x in a])) for a, Y in Q.items()]
def cmat(b): return sum(b[mu] * GU[mu] for mu in range(4))
def cquadm(f, a, b):
    g = lambda s_: np.concatenate([f(s_).real.ravel(), f(s_).imag.ravel()])
    v = quad_vec(g, a, b, epsabs=1e-13, epsrel=1e-12)[0]; n_ = len(v) // 2
    return (v[:n_] + 1j * v[n_:]).reshape(4, 4)
class ColTensor:
    """T^mu_nu(x) of the column action for rows phi-bar = sum r_j e^{i a_j.x} and columns psi = sum c_l e^{i b_l.x}"""
    def __init__(self, rows, cols, m, kap, tau, local_only=False):
        self.rows, self.cols = rows, cols; tf = float(tau); self.A = {}; self.L = {}
        for j, (r, a) in enumerate(rows):
            for l, (c, b) in enumerate(cols):
                Bl = cmat(b)
                for mu in range(4):
                    Ml = 0 * I4 if (local_only or fault('NOBILOCAL')) else cquadm(lambda s_: expm(1j * s_ * cmat(a)) @ GU[mu] @ expm(-1j * (tf - s_) * Bl), 0.0, tf)
                    self.A[(j, l, mu)] = 1j * GU[mu] - 1j * kap * Ml
                self.L[(j, l)] = r @ (-Bl - m * I4 + 1j * kap * expm(-1j * tf * Bl)) @ c
    def __call__(self, x):
        T = np.zeros((4, 4), complex)
        for j, (r, a) in enumerate(self.rows):
            for l, (c, b) in enumerate(self.cols):
                ph = np.exp(1j * ((a + b) @ x))
                for mu in range(4):
                    v = r @ self.A[(j, l, mu)] @ c
                    for nu in range(4): T[mu, nu] += ph * v * 1j * b[nu]
                for mu in range(4): T[mu, mu] -= ph * self.L[(j, l)]
        return T
    def div(self, x, h=4e-4):
        out = np.zeros(4, complex)
        for mu in range(4):
            e = np.zeros(4); e[mu] = h
            d = (-self(x + 2 * e) + 8 * self(x + e) - 8 * self(x - e) + self(x - 2 * e)) / (12 * h)
            out += d[mu, :]
        return out
XPTS = [np.array([0.3, -0.2, 0.5, 0.1]), np.array([-0.7, 0.4, -0.1, 0.9]), np.array([1.1, 0.6, -0.8, -0.3])]
def tt_at(tt, x): return np.array([[ceval(tt[mu][nu], x) for nu in range(4)] for mu in range(4)])
def bar_rows(cols): return [(c.conj() @ GM[0], -np.conj(b)) for c, b in cols]                 # psi-bar = psi^dagger Gamma_0, on the column side
def std_case(P, m_, kap, tau, Q=None):
    cols = colwaves(P); rows = bar_rows(cols) if Q is None else rowwaves(Q)
    return cols, rows, ColTensor(rows, cols, m_, kap, tau)
def col_rhs(rows, cols, m_, kap, tau, x):
    """-Y[phi-bar] d_nu psi - d_nu phi-bar (O psi) at x, on the column side"""
    tf = float(tau); out = np.zeros(4, complex)
    Yx = sum(np.exp(1j * (a @ x)) * (r @ (cmat(a) - m_ * I4 + 1j * kap * expm(1j * tf * cmat(a)))) for r, a in rows)
    Ox = sum(np.exp(1j * (b @ x)) * ((-cmat(b) - m_ * I4 + 1j * kap * expm(-1j * tf * cmat(b))) @ c) for c, b in cols)
    for nu in range(4):
        dpsi = sum(1j * b[nu] * np.exp(1j * (b @ x)) * c for c, b in cols); dbar = sum(1j * a[nu] * np.exp(1j * (a @ x)) * r for r, a in rows)
        out[nu] = -Yx @ dpsi - dbar @ Ox
    return out
cases1 = []
(mA, kA, tA_), EA, nA, wA = ONE_SH[0]; rg = random.Random(9000 + mA + nA); PA1 = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s in wA])
cases1.append(('one shell', PA1, mA, kA, tA_, None))
(mB, kB, tB_), waB, wbB = TWO_SH[0]; rg = random.Random(4242 + mB)
PB1 = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s, E_ in waB], *[(1, wave(k, s, mode_amp(k, s, rg))) for k, s, E_ in wbB])
cases1.append(('two shells', PB1, mB, kB, tB_, None))
(mC, kC, tC_), PwC, QwC = SH_OFF[0]; rg = random.Random(800 + mC)
PC1 = fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in PwC]); QC1 = rf_rev(fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in QwC]))
cases1.append(('off shell', PC1, mC, kC, tC_, QC1))
dev_div = 0.0; dev_cmp = 0.0; loc_div = 0.0; scale1 = 0.0
for name, P, m_, kap, tau, Q in cases1:
    cols, rows, CT = std_case(P, m_, float(kap), tau, Q)
    tt = tensor(ops(m_, kap, tau)['O'], rf_rev(P) if Q is None else Q, P)
    for x in XPTS:
        Tx = CT(x); sc = np.abs(Tx).max(); scale1 = max(scale1, sc)
        rhs = col_rhs(rows, cols, m_, float(kap), tau, x) if Q is not None else np.zeros(4)
        dev_div = max(dev_div, np.abs(CT.div(x) - rhs).max() / sc)
        dev_cmp = max(dev_cmp, np.abs(tt_at(tt, x) - Tx).max() / sc)
    if name == 'two shells':
        CL = ColTensor(rows, cols, m_, float(kap), tau, local_only=True)
        loc_div = min(np.abs(CL.div(x)).max() / np.abs(CL(x)).max() for x in XPTS)
chk('std', dev_div < 1e-8, 'st.STD: Dirac matrices with scipy expm and quad_vec (the s-integral of e^{s D<-} G^mu e^{-(tau - s) D}), the divergence by five-point differences (h = 4e-4) at three points: on the one-shell sum of three waves at (3, 2, pi/10) and the two-shell sum at (4, 1, pi/2) d_mu T^mu_nu = 0, and on the off-shell pair it equals -Y d_nu psi - d_nu phi-bar O psi, for nu = 0 ... 3 (max deviation %.1e relative to |T| up to %.0f)' % (dev_div, scale1))
chk('ctl', loc_div > 1e-3, 'st.STD: on the two-shell sum the local part alone has a divergence of relative size >= %.2f at the three points (Dirac matrices)' % loc_div)
chk('bit==std', dev_cmp < 1e-10, 'st.STD: the sixteen components of T^mu_nu exact on the labels (J -> i) equal the Dirac-matrix values at the three points, for the three fields (max deviation %.1e relative)' % dev_cmp)

# ================================================================================================ (2) packets of plane waves; the shift direction varies from wave to wave
head('(2) [st·PACK] packets of finitely many plane waves of space and time: each wave shifted along its own time direction, the same conservation')
def translate_r(F, a):
    """F(x - a) for an R-field and a vector a (contravariant components in Q[pi]): the right factor e^{-J b.a}"""
    out = {}
    for b, Z in F.items():
        th = sum((QP.of(a[mu]) * b[mu] for mu in range(4)), ZERO)
        out = fadd((1, out), (1, {b: mmul(Z, phase(Fr(-1), th))}))
    return out
def translate_l(Q, a):
    out = {}
    for a_, Y in Q.items():
        th = sum((QP.of(a[mu]) * a_[mu] for mu in range(4)), ZERO)
        out = fadd((1, out), (1, {a_: mmul(phase(Fr(-1), th), Y)}))
    return out
def own_dir(k, E): return [Fr(k[mu]) / E for mu in range(4)]                     # v = k/E, the wave's own time direction
def mink(k, l): return Fr(k[0]) * Fr(l[0]) - sum(Fr(k[i]) * Fr(l[i]) for i in (1, 2, 3))
PACK1 = ((7, 2, 3 * PI / 10), 5, 1, [((5, 0, 0, 0), -1), ((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1), ((13, 0, 0, 12), -1), ((Fr(25, 4), 0, Fr(15, 4), 0), 1)])
(mP, kP, tP), EP, nP, wP = PACK1; OPp = ops(mP, kP, tP); rg = random.Random(31337)
assert EP == mP + (-1) ** nP * kP and EP * tP == (nP + Fr(1, 2)) * PI
amps = [mode_amp(k, s, rg) for k, s in wP]; PW = [wave(k, s, Z) for (k, s), Z in zip(wP, amps)]; PK = fadd(*[(1, w) for w in PW])
ok_own = True; ok_one = True; ok_seg = True
for sv in (tP, PI / 10, PI / 5):                                                # E s = 3 pi/2, pi/2, pi: exact phases
    vk = [own_dir(wP[0][0] if fault('ONEDIR') else k, EP) for k, s in wP]       # ONEDIR: the first wave's direction for every wave
    try: tr = fadd(*[(1, translate_r(w, [-s * QP.of(sv) * x for x in v])) for (k, s), w, v in zip(wP, PW, vk)])
    except ValueError: tr = None                                                # a phase off the quarter turns: it cannot equal the exact shift
    ok_own &= tr is not None and rf_shift(PK, sv) == tr
ok_one = rf_shift(PK, tP) == rf_rmul(PK, phase(EP, tP))
bad_dirs = 0
for kl, sl in wP:                                                               # the translation by tau along wave l's own direction, applied to the whole packet
    for kj, sj in wP:
        need = (Fr(sj * sl) * mink(kj, kl) / EP - EP) * tP.c[1] / 2              # the phase it gives minus the phase exp(-tau bD) gives, in turns
        if need.denominator != 1: bad_dirs += 1; break
for sv in (PI / 10, PI / 5):                                                    # the bilocal integrand at an interior s: two segments
    lhs_l = lf_shift(rf_rev(PK), sv); rhs_l = fadd(*[(1, translate_l(rf_rev(w), [s * QP.of(sv) * x for x in own_dir(k, EP)])) for (k, s), w in zip(wP, PW)])
    lhs_r = rf_shift(rf_deriv(PK, 0), tP - sv); rhs_r = fadd(*[(1, translate_r(rf_deriv(w, 0), [-s * QP.of(tP - sv) * x for x in own_dir(k, EP)])) for (k, s), w in zip(wP, PW)])
    ok_seg &= lhs_l == rhs_l and lhs_r == rhs_r
chk('bit', ok_own and ok_one and onshell(OPp['O'], PK), 'st.PACK: a packet of five quantized plane waves of one mass (E = 5 at (m, kappa, tau) = (7, 2, 3 pi/10), n = 1; k = (5,0,0,0), (13,12,0,0), (13,0,0,12) and (7,2,4,2), (25/4,0,15/4,0) with the other sign of the frequency): exp(-s bD) P is exactly the sum of the waves each translated by s along its own time direction k/E, forward for one sign of the frequency and backward for the other (s = tau, pi/10, pi/5); and exp(-tau bD) P = P e^{J E tau} = -P J: one right factor for the whole packet')
chk('ctl', bad_dirs == len(wP), 'st.PACK: no wave\'s own direction serves the packet: the translation by tau along k_l/E gives a wrong phase on at least one other wave for each of the %d waves (exact, in turns of the circle)' % len(wP))
chk('bit', ok_seg, 'st.PACK: at the interior points s = pi/10, pi/5 of the shift interval the bilocal integrand pairs exp(s bD\')P~, which is exactly each conjugate wave translated by s along its own direction, with exp(-(tau - s) bD) d_0 P, each wave translated by tau - s along its own: two segments per pair of waves, which meet only when the directions agree')
# conservation on packets: one shell (the five waves) and two shells (five waves at (4, 1, pi/2))
PACK2 = ((4, 1, PI / 2), [((5, 0, 0, 0), -1, 5, 2), ((13, 12, 0, 0), -1, 5, 2), ((7, 2, 4, 2), 1, 5, 2), ((5, 0, 0, 4), -1, 3, 1), ((7, 6, 2, 0), 1, 3, 1)])
ttK, tlK, tbK = tensor(OPp['O'], rf_rev(PK), PK, parts=True); FK = factor(kP, tP, nP)
ok_pk1 = cons(ttK) and tt_eq(tbK, tt_map(lambda c: cmulz(c, mlin((-1, ONE), (1, FK))), tlK))
(m2, k2, t2), w2 = PACK2; OP2 = ops(m2, k2, t2); rg = random.Random(2718)
P2W = {E_: fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s, EE, n in w2 if EE == E_]) for E_ in (5, 3)}
PK2 = fadd((1, P2W[5]), (1, P2W[3])); ttK2 = tensor(OP2['O'], rf_rev(PK2), PK2)
want2 = tt_map(lambda a, b: fadd((1, a), (1, b)), *[tt_map(lambda c, F=factor(k2, t2, n): cmulz(c, F), tensor(OP2['ORD'][:1] + [('mass', -QP.of(E_))], rf_rev(P2W[E_]), P2W[E_])) for E_, n in ((5, 2), (3, 1))])
ok_pk2 = onshell(OP2['O'], PK2) and cons(ttK2) and tt_eq(ttK2, want2)
chk('bit', ok_pk1 and ok_pk2, 'st.PACK: on the packet of five waves of one mass d_mu T^mu_nu = 0 exactly (nu = 0 ... 3, %d cross frequencies) and the bilocal part is -(-1)^n mu J times the local part: on the solutions the bilocal term is a local density; on a packet of five waves on two shells at (4, 1, pi/2) (E = 5: three waves, E = 3: two, both signs of the frequency) T is conserved and equals the sum over the shells of (1 - (-1)^n mu J) times the canonical tensor of the ordinary equation of mass E: the currents of two free fields of masses 5 and 3, each with its factor' % nkeys(ttK))
cols, rows, CT = std_case(PK2, m2, float(k2), t2); dev_pk = 0.0; cmp_pk = 0.0
for x in XPTS:
    Tx = CT(x); sc = np.abs(Tx).max(); dev_pk = max(dev_pk, np.abs(CT.div(x)).max() / sc); cmp_pk = max(cmp_pk, np.abs(tt_at(ttK2, x) - Tx).max() / sc)
colsK = colwaves(PK); dev_sh = 0.0
for x in XPTS:
    psi = sum(np.exp(1j * (b @ x)) * c for c, b in colsK); sh = sum(np.exp(1j * (b @ x)) * (expm(-1j * float(tP) * cmat(b)) @ c) for c, b in colsK)
    dev_sh = max(dev_sh, np.abs(sh - np.exp(1j * float(EP * tP)) * psi).max() / np.abs(psi).max())
chk('std', dev_pk < 1e-8 and dev_sh < 1e-12, 'st.PACK: Dirac matrices: on the two-shell packet of five waves the divergence of T by finite differences vanishes at three points (%.1e relative); on the one-shell packet scipy expm(-tau D) wave by wave gives e^{i E tau} psi (%.1e)' % (dev_pk, dev_sh))
chk('bit==std', cmp_pk < 1e-10, 'st.PACK: the sixteen components on the labels equal the Dirac-matrix values on the two-shell packet at three points (%.1e)' % cmp_pk)

# ================================================================================================ (3) Lorentz currents, the spin part, Belinfante
head('(3) [st·COV, st·SPIN, st·BEL] the Lorentz symmetry of the shifted action: the spin current with its bilocal part, the Belinfante tensor')
def rotor_vec(R, v):
    """R v R~ for a vector given by its components v_mu in the gamma^mu basis; returns the components in the same basis"""
    w = mmul(mmul(R, vec(v)), mrev(R))
    return tuple(scal(mmul(w, GAM[mu])).c.get(0, Fr(0)) if scal(mmul(w, GAM[mu])) else Fr(0) for mu in range(4))
def boost_r(F, R):
    """P'(x) = R P(Lambda^{-1} x): e^{J b.x} -> e^{J b'.x} with b'-check = R b-check R~"""
    return {rotor_vec(R, b): mmul(R, Z) for b, Z in F.items()}
def boost_l(Q, R):
    """Q'(x) = Q(Lambda^{-1} x) R~"""
    return {rotor_vec(R, a): mmul(Y, mrev(R)) for a, Y in Q.items()}
RB = mlin((Fr(5, 4), ONE), (Fr(3, 4), mmul(GAM[1], G0))); RR = mlin((Fr(3, 5), ONE), (Fr(4, 5), mmul(GAM[1], GAM[2]))); RL = mmul(RB, RR)
assert mmul(RL, mrev(RL)) == ONE
LAM = [[scal(mmul(mmul(mmul(RL, GAM[al]), mrev(RL)), GUP[mu])).c.get(0, Fr(0)) for al in range(4)] for mu in range(4)]   # Lambda^mu_alpha
LAMI = [[scal(mmul(mmul(mmul(mrev(RL), GAM[nu]), RL), GUP[be])).c.get(0, Fr(0)) for nu in range(4)] for be in range(4)]  # (Lambda^{-1})^beta_nu as [beta][nu]
ok_cov = True; ncv = 0
for (m_, kap, tau), Pw, Qw in SH_OFF:
    rg = random.Random(55 + m_)
    for _ in range(2):
        P = fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Pw]); ncv += 1
        for tv in (tau, -tau, 3 * tau):
            ok_cov &= rf_shift(boost_r(P, RL), tv) == boost_r(rf_shift(P, tv), RL)
        Q = rf_rev(fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Qw]))
        if _ == 0:                                                              # the whole tensor, off shell: T[P', Q'](x) = Lambda T[P, Q](Lambda^{-1} x) Lambda^{-1}
            OP = ops(m_, kap, tau)['O']; t1 = tensor(OP, boost_l(Q, RL), boost_r(P, RL)); t0 = tensor(OP, Q, P)
            for mu in range(4):
                for nu in range(4):
                    acc = {}
                    for al in range(4):
                        for be in range(4):
                            c_ = LAM[mu][al] * LAMI[be][nu]
                            if c_: acc = fadd((1, acc), (c_, {rotor_vec(RL, key): z for key, z in t0[al][be].items()}))
                    ok_cov &= acc == t1[mu][nu]
chk('bit', ok_cov, 'st.COV: the rotor R = (5/4 + 3/4 gamma_1 gamma_0)(3/5 + 4/5 gamma_1 gamma_2) (a boost and a rotation, rational): exp(-s bD)(R P(Lambda^{-1}x)) = R (exp(-s bD) P)(Lambda^{-1}x) exactly for s = tau, -tau, 3 tau on %d sums of three plane waves with random amplitudes (off shell), and the whole tensor of an off-shell pair transforms as a tensor, T[P\', Q\'](x) = Lambda T[P, Q](Lambda^{-1}x) Lambda^{-1}, bilocal part included: the bilocal current is Lorentz covariant' % ncv)
PAIRS_B = [(r, s_) for r in range(4) for s_ in range(r + 1, 4)]
def spin(T, Q, P, B):
    """S^lambda[B] = (1/2) W^lambda with B between gamma^lambda and the field (after the shifts); NOSPINBIL: its local part only"""
    tot, loc, bil = conc(T, Q, P, ins=B, parts=True)
    return [cmulz(loc[l] if fault('NOSPINBIL') else tot[l], zc(Fr(1, 2))) for l in range(4)]
def lowfirst(tt): return [[cmulz(tt[mu][nu], zc(ETA[mu])) for nu in range(4)] for mu in range(4)]   # T_{mu nu} = eta_{mu mu} T^mu_nu
ok_sp_off = True; nsp = 0
for (m_, kap, tau), Pw, Qw in SH_OFF:
    rg = random.Random(66 + m_); OP = ops(m_, kap, tau)['O']
    for _ in range(2):
        P = fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Pw]); Q = rf_rev(fadd(*[(1, wave(k, s, rand_mv(rg))) for k, s in Qw])); nsp += 1
        TL = lowfirst(tensor(OP, Q, P)); Y = adjoint_op(OP, Q); OPP = apply_op(OP, P)
        for r, s_ in PAIRS_B:
            B = mmul(GAM[r], GAM[s_]); S = spin(OP, Q, P, B)
            rhs = fadd((1, TL[s_][r]), (-1, TL[r][s_]), (Fr(1, 2), pair(Q, {b: mmul(B, Z) for b, Z in OPP.items()})), (Fr(-1, 2), pair(Y, {b: mmul(B, Z) for b, Z in P.items()})))
            ok_sp_off &= cdiv(S) == rhs
chk('bit', ok_sp_off, 'st.SPIN: the Noether current of the Lorentz symmetry is M^mu = -xi^nu T^mu_nu + S^mu[B] (xi = B x x, the generator delta P = B P/2 - xi.d P), with the spin current S^mu[B] = (1/2)<Q gamma^mu B P gamma_0 J>_S - (kappa/2) int_0^tau ds <exp(s bD\')(Q) gamma^mu B exp(-(tau - s) bD)(P) gamma_0 J>_S, B between the two shifted factors; off shell, exactly, on %d pairs and the six B = gamma_rho gamma_sigma: d_mu S^mu[B] = T_sigma.rho - T_rho.sigma + <Q B O[P]>_S/2 - <Y[Q] B P>_S/2, which is the conservation of M where the equation and its adjoint hold' % nsp)
def cder(C, l): return {k: w for k, z in C.items() if k[l] for w in [mlin((k[l], mmul(z, J)))] if w}
def belinfante(OP, Q, P):
    """T_{mu nu} (first index lowered) and the Belinfante tensor T_B = T + d_lambda G^lambda, G_{l a b} = (S_lab - S_alb - S_bla)/2, S_{l a b} = eta_ll S^l[gamma_a gamma_b]"""
    TL = lowfirst(tensor(OP, Q, P)); Sd = {}
    for r, s_ in PAIRS_B:
        S = spin(OP, Q, P, mmul(GAM[r], GAM[s_]))
        for l in range(4): Sd[(l, r, s_)] = cmulz(S[l], zc(ETA[l])); Sd[(l, s_, r)] = cmulz(S[l], zc(-ETA[l]))
    Sg = lambda l, a, b: Sd.get((l, a, b), {})
    TB = [[fadd((1, TL[a][b]), *[(Fr(ETA[l], 2), cder(fadd((1, Sg(l, a, b)), (-1, Sg(a, l, b)), (-1, Sg(b, l, a))), l)) for l in range(4)]) for b in range(4)] for a in range(4)]
    return TL, TB
def sym(TB): return all(TB[a][b] == TB[b][a] for a in range(4) for b in range(4))
def cons_low(TB): return all(not cdiv([cmulz(TB[a][b], zc(ETA[a])) for a in range(4)]) for b in range(4))
ok_bsym = True; ok_bcons = True; ok_bconst = True; ok_bdens = True; ok_cansym = True; ok_bfac = True; nbc = 0
for (m_, kap, tau), E_, n, waves in ONE_SH[:2]:                                # one shell: three waves; and a single mode of each
    OP = ops(m_, kap, tau)['O']; rg = random.Random(9000 + m_ + n); F = factor(kap, tau, n)
    P = fadd(*[(1, wave(k, s, mode_amp(k, s, rg))) for k, s in waves]); TL, TB = belinfante(OP, rf_rev(P), P); nbc += 1
    ok_bsym &= sym(TB); ok_bcons &= cons_low(TB); ok_cansym &= not sym(TL)
    ok_bconst &= all(cconst(TB[a][b]) == cconst(TL[a][b]) for a in range(4) for b in range(4)); ok_bdens &= TB[0][0] != TL[0][0]
    TLo, TBo = belinfante([('kin', UNIT, J), ('mass', -QP.of(E_))], rf_rev(P), P)
    ok_bfac &= tt_eq(TB, tt_map(lambda c: cmulz(c, F), TBo))
    for k, s in waves[:2]:
        Pm = wave(k, s, mode_amp(k, s, rg)); TLm, TBm = belinfante(OP, rf_rev(Pm), Pm); nbc += 1
        ok_bconst &= tt_eq(TBm, TLm) and sym(TBm)
(mB, kB, tB_), waB, wbB = TWO_SH[0]; OP = ops(mB, kB, tB_)['O']
TL2, TB2 = belinfante(OP, rf_rev(PB1), PB1); nbc += 1
ok_bsym &= sym(TB2); ok_bcons &= cons_low(TB2); ok_cansym &= not sym(TL2)
ok_bconst &= all(cconst(TB2[a][b]) == cconst(TL2[a][b]) for a in range(4) for b in range(4)); ok_bdens &= TB2[0][0] != TL2[0][0]
chk('bit', ok_bsym and ok_bcons, 'st.BEL: on the solutions (three waves on one shell at (3, 2, pi/10) and at (4, 1, pi/2); three waves on two shells at (4, 1, pi/2)) the Belinfante tensor T_B = T + d_lambda G^lambda, G_{lambda mu nu} = (S_lambda.mu.nu - S_mu.lambda.nu - S_nu.lambda.mu)/2 built from the spin current with its bilocal part, is conserved and symmetric, T_B{mu nu} = T_B{nu mu}, exactly')
chk('ctl', ok_cansym, 'st.BEL: the canonical T_{mu nu} is not symmetric on any of these superpositions')
chk('bit', ok_bconst and ok_bdens, 'st.BEL: on a single quantized mode (four modes, rest and moving) T_B = T exactly, the density included, so the energy per unit density E_0 (1 - (-1)^n mu J) is unchanged; on the superpositions T_B - T has no constant part in any component (the energy and momentum per unit volume unchanged) but T_B^00 differs from T^00 at the cross frequencies: the improvement redistributes the density')
chk('bit', ok_bfac, 'st.BEL: on one shell T_B = (1 - (-1)^n mu J) times the Belinfante tensor of the ordinary equation of mass E, exactly: on the solutions of one mass the symmetric tensor of the shifted theory is the ordinary one with the factor of the Noether number')
# the standard route: the spin current on Dirac matrices (M(B) between G^lambda and the shifted field), G and T_B by finite differences
class ColSpin:
    def __init__(self, rows, cols, kap, tau, MB):
        self.rows, self.cols = rows, cols; tf = float(tau); self.A = {}
        for j, (r, a) in enumerate(rows):
            for l, (c, b) in enumerate(cols):
                for lam in range(4):
                    Ml = 0 * I4 if (fault('NOBILOCAL') or fault('NOSPINBIL')) else cquadm(lambda s_: expm(1j * s_ * cmat(a)) @ GU[lam] @ MB @ expm(-1j * (tf - s_) * cmat(b)), 0.0, tf)
                    self.A[(j, l, lam)] = 0.5 * (1j * GU[lam] @ MB - 1j * kap * Ml)
    def __call__(self, x):
        return np.array([sum(np.exp(1j * ((a + b) @ x)) * (r @ self.A[(j, l, lam)] @ c) for j, (r, a) in enumerate(self.rows) for l, (c, b) in enumerate(self.cols)) for lam in range(4)])
def col_belinfante(P, m_, kap, tau, x, h=4e-4):
    cols = colwaves(P); rows = bar_rows(cols); CT = ColTensor(rows, cols, m_, kap, tau)
    SP = {(r, s_): ColSpin(rows, cols, kap, tau, BLM[(1 << r) | (1 << s_)]) for r, s_ in PAIRS_B}
    def Sd(y):
        out = np.zeros((4, 4, 4), complex)
        for (r, s_), sp in SP.items():
            v = sp(y)
            for l in range(4): out[l, r, s_] = ETA[l] * v[l]; out[l, s_, r] = -ETA[l] * v[l]
        return out
    def G(y):
        S = Sd(y); return 0.5 * (S - np.transpose(S, (1, 0, 2)) - np.transpose(S, (1, 2, 0)))     # [l,a,b]: S_lab - S_alb - S_bla
    TL = np.diag(ETA) @ CT(x); TB = TL.copy()
    for l in range(4):
        e = np.zeros(4); e[l] = h
        dG = (-G(x + 2 * e) + 8 * G(x + e) - 8 * G(x - e) + G(x - 2 * e)) / (12 * h)
        TB += ETA[l] * dG[l]
    return TL, TB
xb = XPTS[0]; TLc, TBc = col_belinfante(PB1, mB, float(kB), tB_, xb)
symdev = np.abs(TBc - TBc.T).max() / np.abs(TBc).max(); cansym = np.abs(TLc - TLc.T).max() / np.abs(TLc).max()
cmpb = np.abs(np.array([[ceval(TB2[a][b], xb) for b in range(4)] for a in range(4)]) - TBc).max() / np.abs(TBc).max()
chk('std', symdev < 1e-8 and cansym > 1e-3, 'st.BEL: Dirac matrices on the two-shell sum: the spin current by quad_vec (M(gamma_rho gamma_sigma) between G^lambda and e^{-(tau - s) D}), G and its derivatives by five-point differences: T_B is symmetric to %.1e at x = (0.3, -0.2, 0.5, 0.1), where the canonical T is not (%.2f), relative to |T_B|' % (symdev, cansym))
chk('bit==std', cmpb < 1e-8, 'st.BEL: the sixteen components of T_B on the labels equal the Dirac-matrix values at that point (%.1e relative)' % cmpb)

# ================================================================================================ (4) the paper's complex equation off its modes
head('(4) [st·SYMB, st·ROOT, st·HERMC, st·OFFM] the dispersion relation of D_+ for complex frequency: Lambert W carried to the spinor equation; the Hermitian half; the energy off the modes')
def fJ(E, m_, kap, tau): return mlin((QP.of(E) - m_, ONE), (kap, mmul(J, phase(E, tau))))   # f_J(E) = E - m + kappa J e^{J E tau}
def fJcs(E, m_, kap, c, s):                                                     # the same at a rational point (c, s) = (cos E tau, sin E tau)
    return mlin((QP.of(E) - m_, ONE), (kap, mmul(J, zc(c, s))))
ok_symb = True; nsy = 0
KALL = ((5, 0, 0, 0), (13, 12, 0, 0), (7, 2, 4, 2), (5, 0, 0, 4), (3, 0, 0, 0), (7, 6, 2, 0))
for m_, kap, tau, cs_ in ((3, 2, PI / 10, None), (4, 1, PI / 2, None), (5, Fr(1, 3), None, (Fr(3, 5), Fr(4, 5))), (2, 7, None, (Fr(5, 13), Fr(-12, 13)))):
    rg = random.Random(1234 + m_)
    for k in KALL:
        if cs_ is None and (2 * Emass(kvec(k, 1)) * tau.c[1]).denominator != 1: continue      # quarter turns only
        for s in (-1, 1):
            b = kvec(k, s); Z = rand_mv(rg); E, Zp, Zm = rf_parts(b, Z); nsy += 1
            if cs_ is None:
                lhs = apply_op(ops(m_, kap, tau)['O'], {b: Z}).get(b, {}); fp, fm = fJ(E, m_, kap, tau), fJ(-E, m_, kap, tau)
            else:
                c, s_ = cs_                                                     # exp(-tau bD) = c - (s/E) bD (the closed form of shifted_dirac.py)
                DZ = rf_D({b: Z}).get(b, {}); sh = mlin((c, Z), (-s_ / E, DZ))
                lhs = mlin((1, mmul(DZ, J)), (-m_, Z), (kap, mmul(sh, J))); fp, fm = fJcs(E, m_, kap, c, s_), fJcs(-E, m_, kap, c, -s_)
            ok_symb &= lhs == mlin((1, mmul(Zp, fp)), (1, mmul(Zm, fm)))
chk('bit', ok_symb, 'st.SYMB: on %d plane waves (rest and moving, both signs of the frequency, random amplitudes) the paper\'s operator acts exactly as the right factor f_J(E) = E - m + kappa J e^{J E tau} on the half of mass E and f_J(-E) on the other half, E = sqrt Q(k), at quarter-turn shifts and at the rational points (cos E tau, sin E tau) = (3/5, 4/5), (5/13, -12/13) of the circle: the spinor equation is the scalar equation f_J(+-E) = 0 on each half, in every frame' % nsy)
# floats on the labels: a J-complex frequency a + J lam on the right is the real field e^{lam t} Z e^{-J a t} (no unit beside J is needed)
def fl(a): return {m_: float(v) for m_, v in a.items()}
def flmul(a, b):
    out = {}
    for x, cx in a.items():
        for y, cy in b.items():
            m_, s = cs.bmul(x, y, SQ); out[m_] = out.get(m_, 0.0) + s * cx * cy
    return out
def fllin(*terms):
    out = {}
    for c, a in terms:
        for m_, v in a.items(): out[m_] = out.get(m_, 0.0) + c * v
    return out
def flnorm(a): return math.sqrt(sum(v * v for v in a.values()))
fJ_ = fl(J); fG0 = fl(G0); fONE = fl(ONE)
def jexp(z): return fllin((z.real, fONE), (z.imag, fJ_))                        # the J-complex number z.real + z.imag J
def label_residual(Ec, m_, kap, tau, half, t):
    """the label operator at rest on P(t) = Z e^{-J E t} (half +, Z in P_+) or Z e^{+J E t} (half -, Z in P_-), E = a + J lam, in floats:
    bD(P) = gamma_0 P' gamma_0, exp(-tau bD) P = P_+(t - tau) + P_-(t + tau) (ATY-041); returns |O[P](t)| / |P(t)|"""
    Z = fl(blade(PPLUS[1]) if half > 0 else blade(PMINUS[1])); sg = -1 if half > 0 else 1
    P = lambda tt: flmul(Z, jexp(np.exp(1j * sg * Ec * tt)))                     # J <-> i: e^{-J E t} with E complex
    dP = lambda tt: flmul(Z, jexp(1j * sg * Ec * np.exp(1j * sg * Ec * tt)))
    sh = P(t - tau) if half > 0 else P(t + tau)
    O = fllin((1, flmul(flmul(flmul(fG0, dP(t)), fG0), fJ_)), (-m_, P(t)), (kap, flmul(sh, fJ_)))
    return flnorm(O) / flnorm(P(t))
PPLUS = [m_ for m_ in EVEN if mmul(mmul(G0, blade(m_)), G0) == blade(m_)]; PMINUS = [m_ for m_ in EVEN if m_ not in PPLUS]
def lam_roots(m_, kap, tf, ks):
    """E_k = m + i W_k(-mu e^{i m tau})/tau (the roots of E - m + i kappa e^{i E tau} = 0); EXPSIGN: the roots of E - m + kappa e^{-i E tau}"""
    mu = kap * tf
    if fault('EXPSIGN'): return [m_ - 1j * complex(lambertw(-1j * mu * np.exp(-1j * m_ * tf), k)) / tf for k in ks]
    return [m_ + 1j * complex(lambertw(-mu * np.exp(1j * m_ * tf), k)) / tf for k in ks]
def dsym(K, m_, kap, tf, key='O'):
    if key == 'O': return K - m_ * I4 + 1j * kap * expm(1j * tf * K)
    if key == 'H': return K - m_ * I4 - 1j * kap * (expm(-1j * tf * K) - expm(1j * tf * K)) / 2
    return K - m_ * I4 + 1j * kap * (expm(-1j * tf * K) - expm(1j * tf * K)) / 2      # D_s
def kerdim(M, tol=1e-9):
    sv = np.linalg.svd(M, compute_uv=False); return int(np.sum(sv < tol * max(1.0, sv[0])))
MU13 = 1e-13; KAP13 = MU13 / (np.pi / 2)
ROOTSETS = [('(3, 2, pi/10)', 3.0, 2.0, np.pi / 10, [5.0]), ('(4, 1, pi/2)', 4.0, 1.0, np.pi / 2, [3.0, 5.0]),
            ('(3, 2, 0.37)', 3.0, 2.0, 0.37, []), ('(4, 1, 1.3)', 4.0, 1.0, 1.3, []), ('mu = 1e-13 at E = 1', 1.0 - KAP13, KAP13, np.pi / 2, [1.0])]
KS = list(range(-8, 9)); ok_res = True; ok_ker = True; ok_real = True; ok_lab = True; ok_asym = True; rdesc = []; worst_res = 0.0; worst_lab = 0.0; asy = 0.0
for name, m_, kap, tf, want in ROOTSETS:
    Es = lam_roots(m_, kap, tf, KS); mu = kap * tf
    f = lambda E: E - m_ + 1j * kap * np.exp(1j * E * tf)
    for E in Es:
        r_ = abs(f(E)) / max(1.0, abs(E)); worst_res = max(worst_res, r_); ok_res &= r_ < 1e-10
        ok_ker &= kerdim(dsym(E * GM[0], m_, kap, tf)) == 2
        w = np.sqrt(E * E + 144.0); ok_ker &= kerdim(dsym(w * GM[0] + 12.0 * GM[1], m_, kap, tf)) == 2
    reals = sorted(E.real for E in Es if abs(E.imag) < 1e-9 * max(1.0, abs(E)))
    ok_real &= len(reals) == len(want) and all(abs(a - b) < 1e-9 for a, b in zip(reals, want))
    nonreal = [E for E in Es if abs(E.imag) >= 1e-9 * max(1.0, abs(E))]
    npos = sum(1 for E in nonreal if E.imag > 0); nneg = len(nonreal) - npos
    for kk, E in zip(KS, Es):
        if abs(kk) == 8: asy = max(asy, abs(tf * E.imag + math.log(2 * math.pi * abs(kk) / mu)) / math.log(2 * math.pi * abs(kk) / mu))
    rdesc.append('%s: %s real, %d with Im E < 0, %d with Im E > 0, max Im E %.3g' % (name, ', '.join('%g' % x for x in reals) if reals else 'none', nneg, npos, max(E.imag for E in nonreal)))
    for E in Es[7:10]:                                                          # floats on the labels at three roots, both halves
        for half in (1, -1):
            for t in (0.3, 1.7):
                lr = label_residual(E, m_, kap, tf, half, t); worst_lab = max(worst_lab, lr); ok_lab &= lr < 1e-9
ok_asym = asy < 0.1
chk('std', ok_res and ok_ker, 'st.ROOT: scipy lambertw, E_k = m + i W_k(-mu e^{i m tau})/tau on the branches k = -8 ... 8, at five (m, kappa, tau): every E_k solves E - m + i kappa e^{i E tau} = 0 (the paper\'s (2.5) for complex E; residual %.1e), and at each the 4 x 4 symbol K - m + i kappa expm(i tau K) has a two-dimensional kernel at rest (K = E Gamma_0) and for a moving wave (K = omega Gamma_0 + 12 Gamma_1, omega^2 = E^2 + 144): all the roots of the spinor equation, in every frame, are the Lambert roots of the scalar one' % worst_res)
chk('std', ok_real and ok_asym, 'st.ROOT: the roots on the real axis are exactly the quantized modes, and a generic shift has none: %s; for large |k| tau Im E_k = -log(2 pi |k|/mu) to %.0f%% at |k| = 8. A root with Im E < 0 decays in the future and grows in the past on the P_+ half (e^{-i E t}) and the reverse on the P_- half (e^{+i E t}): every root off the real axis grows in the far past or the far future on one half, the paper\'s remark 2.2.3 on the spinor equation' % ('; '.join(rdesc), 100 * asy))
chk('bit', ok_lab, 'st.ROOT: in floats on the labels, at three roots of each set and on both halves at rest: the real field e^{lam t} Z e^{-J a t} (Z in P_+) and e^{-lam t} Z e^{J a t} (Z in P_-), E = a + J lam on the right, solve O[P] = 0 with exp(-tau bD) P = P_+(t - tau) + P_-(t + tau) (residual %.1e): one root gives growth on one half and decay on the other; no unit beside J is needed' % worst_lab)
ok_m0 = all(abs(z - 0.7 * np.exp(z)) < 1e-10 * max(1, abs(z)) for z in [1j * E * 1.0 for E in lam_roots(0.0, 0.7, 1.0, KS)])
chk('bit==std', ok_m0, 'st.ROOT: at m = 0 the spinor roots are those of (2.1): z = i E tau solves z = mu e^z (mu = 0.7, the 17 branches), the Lambert picture of ATY-041 (en.OSC); for m != 0 it is z - i m tau = mu e^z')
def newton_roots(f, fp, re_lo, re_hi, im_hi, nre=161, nim=41):
    """complex Newton from a grid over the box [re_lo, re_hi] x [-im_hi, im_hi]; roots inside the box, deduplicated"""
    out = []
    for xr in np.linspace(re_lo, re_hi, nre):
        for yi in np.linspace(-im_hi, im_hi, nim):
            z = complex(xr, yi)
            for _ in range(80):
                try: d_ = f(z) / fp(z)
                except (ZeroDivisionError, OverflowError): break
                z -= d_
                if abs(d_) < 1e-14 * max(1, abs(z)) or abs(z) > 1e6: break
            if abs(z) < 1e6 and abs(f(z)) < 1e-10 * max(1, abs(z)) and re_lo <= z.real <= re_hi and abs(z.imag) <= im_hi and all(abs(z - w) > 1e-7 for w in out): out.append(z)
    return out
ok_hpair = True; ok_hreal = True; ok_hker = True; ok_dnp = True; hdesc = []
for key, sg, nrs in (('H', -1, (1, 3, 1)), ('Ds', 1, (1, 1, 1))):
    for (name, m_, kap, tf), nreal in zip((('(3, 2, pi/10)', 3.0, 2.0, np.pi / 10), ('(4, 1, pi/2)', 4.0, 1.0, np.pi / 2), ('(8, 1, 0.37)', 8.0, 1.0, 0.37)), nrs):
        f = lambda E: E - m_ + sg * kap * np.sin(E * tf); fp = lambda E: 1 + sg * kap * tf * np.cos(E * tf)   # H: E - m - kappa sin E tau; D_s: + kappa sin
        R = 30.0; imh = math.log(4 * R / kap) / tf + 2
        rts = newton_roots(f, fp, m_ - R, m_ + R, imh)
        inner = [z for z in rts if abs(z.real - m_) < R - 3 and abs(z.imag) < imh - 1]
        ok_hpair &= all(any(abs(w - z.conjugate()) < 1e-7 * max(1, abs(z)) for w in rts) for z in inner)
        nr = sum(1 for z in rts if abs(z.imag) < 1e-9); ok_hreal &= nr == nreal and len(inner) > nr
        ok_hker &= all(kerdim(dsym(z * GM[0], m_, kap, tf, key)) == 2 for z in inner[:12])
        hdesc.append('%s %s: %d real, %d complex in conjugate pairs' % ({'H': 'H', 'Ds': 'D_s'}[key], name, nr, len(inner) - nr))
for name, m_, kap, tf, want in ROOTSETS[:4]:                                    # D_+: a nonreal root's conjugate is not a root
    f = lambda E: E - m_ + 1j * kap * np.exp(1j * E * tf)
    ok_dnp &= all(abs(f(E.conjugate())) > 1e-3 for E in lam_roots(m_, kap, tf, KS) if abs(E.imag) > 1e-9)
chk('std', ok_hpair and ok_hreal and ok_hker, 'st.HERMC: the Hermitian half H (E - m - kappa sin E tau = 0 at rest) and D_s (E - m + kappa sin E tau): complex Newton from a grid (|Re E - m| <= 30): real roots (H: one where |mu| < 1, three at mu = pi/2, as in en.HERM; D_s: one at each setting), and complex roots in conjugate pairs E, E-bar, each with a two-dimensional kernel of the 4 x 4 symbol (scipy expm): %s: for these operators a growing mode comes with a decaying one at the conjugate frequency' % '; '.join(hdesc))
chk('ctl', ok_dnp, 'st.HERMC: for the paper\'s D_+ the conjugate of a nonreal Lambert root is never a root (|f(E-bar)| > 1e-3 on the four sets): its complex roots are not paired')
# the energy off the modes: two complex roots; pair the solution with the adjoint's own solutions (same roots) or with its Dirac conjugate
m_, kap, tf = 3.0, 2.0, np.pi / 10; E1, E2 = lam_roots(m_, kap, tf, [1, 2]); u1 = np.array([1.0, 0.4 - 0.7j, 0, 0], complex); u2 = np.array([0.3 + 0.5j, -1.0, 0, 0], complex)
cols = [(u1, np.array([-E1, 0, 0, 0])), (u2, np.array([-E2, 0, 0, 0]))]; rows_adj = [(u1.conj(), np.array([E1, 0, 0, 0])), (u2.conj(), np.array([E2, 0, 0, 0]))]
adj_res = max(np.abs(r @ (cmat(a) - m_ * I4 + 1j * kap * expm(1j * tf * cmat(a)))).max() for r, a in rows_adj)
CT_adj = ColTensor(rows_adj, cols, m_, kap, tf); CT_loc = ColTensor(rows_adj, cols, m_, kap, tf, local_only=True); CT_bar = ColTensor(bar_rows(cols), cols, m_, kap, tf)
ts = (0.0, 0.7, 1.9); ea = [CT_adj(np.array([t, 0, 0, 0]))[0, 0] for t in ts]; el = [CT_loc(np.array([t, 0, 0, 0]))[0, 0] for t in ts]; eb = [CT_bar(np.array([t, 0, 0, 0]))[0, 0] for t in ts]
e_sep = sum(ColTensor([rows_adj[j]], [cols[j]], m_, kap, tf)(np.zeros(4))[0, 0] for j in range(2))
spread_a = max(abs(e - ea[0]) for e in ea) / abs(ea[0]); spread_l = max(abs(e - el[0]) for e in el) / abs(el[0]); spread_b = max(abs(e - eb[0]) for e in eb) / abs(eb[0])
adj_def = abs(np.conj(E1) - m_ + 1j * kap * np.exp(1j * np.conj(E1) * tf)); want_def = 2 * kap * abs(np.cos(E1 * tf))
chk('std', adj_res < 1e-10 and spread_a < 1e-9 and abs(ea[0] - e_sep) < 1e-9 * abs(e_sep) and spread_b > 1e-2 and abs(adj_def - want_def) < 1e-9 * want_def and want_def > 1e-3, 'st.OFFM: two complex roots of (3, 2, pi/10) on the P_+ half at rest, E_1 = %.4f %+.4fi and E_2 = %.4f %+.4fi (branches 1, 2), Dirac matrices with quad_vec: paired with the adjoint\'s own solutions u_j^dagger e^{+i E_j t} (residual %.1e) the Noether energy T^0_0 is constant at t = 0, 0.7, 1.9 (spread %.1e), complex, %.4f %+.4fi, the sum of the two roots\' values with no cross term; paired with the Dirac conjugate psi-bar it is not conserved (spread %.2f), because psi-bar does not solve the adjoint off the modes: its defect is 2 kappa |cos E tau| = %.4f at E_1, zero only on the quantized modes' % (E1.real, E1.imag, E2.real, E2.imag, adj_res, spread_a, ea[0].real, ea[0].imag, spread_b, want_def))
chk('ctl', spread_l > 1e-2, 'st.OFFM: on the same pair the local part alone is not constant (spread %.2f): off the modes too the bilocal term is what is conserved with it' % spread_l)

# ================================================================================================ (5) a potential with a gradient (remark 2.2.4)
head('(5) [st·GRAD, st·SOL] a potential with a gradient, A_0 = g x_3 or Phi = g x_3: the mixing of the two halves to first order, and the quantization')
# Fields at rest of one frequency, polynomial in x_3: {d: W} is sum_d x_3^d W e^{J b0 t}.  On them bD = gamma_0 (d_t .) gamma_0 + gamma^3 (d_3 .) gamma_0,
# bD^2 = box = -E^2 + L with L = -d_3^2 (E = |b0|), and on degree <= 3, where L^2 = 0, the power series give exactly
#   exp(-s bD) = cos(E s) + (s sin(E s)/(2E)) L - [sin(E s)/E + (sin(E s)/E - s cos(E s)) L/(2E^2)] bD.
# The coupled operator: bD_g = bD + g V with V = e x_3 gamma_0 (.) J gamma_0 (A_0 = g x_3: A = g x_3 gamma_0, bD_A(P) = (nabla P + e A P J) gamma_0) or
# V = x_3 gamma_0 (d_t .) gamma_0 - (1/2) gamma^3 (.) gamma_0 (the frame of Phi = g x_3 to first order, connection term included, ATY-037);
# O_g[P] = bD_g(P) J - m P + kappa exp(-tau bD_g)(P) J, and d/dg exp(-tau bD_g) at g = 0 is -int_0^tau ds exp(-(tau - s) bD) V exp(-s bD) (Duhamel).
def pf_add(*terms):
    out = {}
    for c, F in terms:
        for d, W in F.items():
            w = mlin((1, out.get(d, {})), (c, W))
            if w: out[d] = w
            else: out.pop(d, None)
    return out
def pf_map(F, f): return {d: w for d, W in F.items() for w in [f(W)] if w}
def pD(F, b0, withN=True):
    out = pf_map(F, lambda W: mmul(mmul(G0, mlin((b0, mmul(W, J)))), G0))
    if withN: out = pf_add((1, out), (1, {d - 1: mlin((d, mmul(mmul(GUP[3], W), G0))) for d, W in F.items() if d}))
    return out
def pL(F, withN=True):
    if not withN: return {}
    return {d - 2: mlin((-d * (d - 1), W)) for d, W in F.items() if d >= 2}
def px3(F): return {d + 1: W for d, W in F.items()}
def prm(F, z): return pf_map(F, lambda W: mmul(W, z))
def trig(E, s):
    """(cos E s, sin E s) exactly for E s on the quarter turns"""
    ph = phase(E, s); return zre(ph), zim(ph)
def pexp(F, s, b0, withN=True):
    """exp(-s bD) F exactly (degree <= 3, E s on the quarter turns); NOCOMM: x_3 treated as a constant inside the shift"""
    E = abs(Fr(b0)); c, sn = trig(E, s); sq = QP.of(s); withN = withN and not fault('NOCOMM')
    DF = pD(F, b0, withN); LF = pL(F, withN); LDF = pL(DF, withN)
    return pf_add((c, F), (sq * sn / (2 * E), LF), (-sn / E, DF), (-(sn / E - sq * c) / (2 * E * E), LDF))
# scalar functions of s on the right: {(w, p): z} is sum z s^p e^{J w s} (z J-complex)
def sf_mul(A, B):
    out = {}
    for (w1, p1), z1 in A.items():
        for (w2, p2), z2 in B.items():
            k = (w1 + w2, p1 + p2); v = mlin((1, out.get(k, {})), (1, mmul(z1, z2)))
            if v: out[k] = v
            else: out.pop(k, None)
    return out
def sf_trig(E, var_tau=None):
    """cos(E s), sin(E s), s cos(E s), s sin(E s) as functions of sigma, for s = sigma (var_tau None) or s = tau - sigma"""
    half = Fr(1, 2); hj = mlin((half, J))
    if var_tau is None:
        C = {(E, 0): zc(half), (-E, 0): zc(half)}; S = {(E, 0): mlin((-1, hj)), (-E, 0): hj}
        return C, S, {(w, 1): z for (w, p), z in C.items()}, {(w, 1): z for (w, p), z in S.items()}
    t = var_tau; ep, em = phase(E, t), phase(-E, t)                              # e^{J E (t - s)} = e^{J E t} e^{-J E s}
    C = {(-E, 0): mlin((half, ep)), (E, 0): mlin((half, em))}; S = {(-E, 0): mmul(mlin((-1, hj)), ep), (E, 0): mmul(hj, em)}
    sC = {}; sS = {}
    for D_, src in ((sC, C), (sS, S)):                                           # (t - s) f = t f - s f
        for (w, p), z in src.items():
            D_[(w, 0)] = mlin((1, D_.get((w, 0), {})), (QP.of(t), z)); D_[(w, 1)] = mlin((1, D_.get((w, 1), {})), (-1, z))
    return C, S, sC, sS
def sf_int(A, t):
    """int_0^t of sum z s^p e^{J w s} ds, a J-complex number, exact for w t on the quarter turns"""
    tot = {}
    for (w, p), z in A.items():
        if w == 0: val = zc(Fr(1, p + 1) * _qpow(t, p + 1))
        else:                                                                   # I_p = [s^p e^{J w s}/(J w)]_0^t - (p/(J w)) I_{p-1}, 1/(J w) = -J/w
            inv = mlin((Fr(-1) / w, J)); ph = phase(w, t); val = mmul(mlin((1, ph), (-1, ONE)), inv); tp = UNIT
            for q in range(1, p + 1):
                tp = tp * QP.of(t); val = mlin((1, mmul(mlin((tp, ph)), inv)), (-q, mmul(val, inv)))
        tot = mlin((1, tot), (1, mmul(z, val)))
    return tot
def _qpow(t, n):
    r = UNIT
    for _ in range(n): r = r * QP.of(t)
    return r
def sf_scale(A, c): return {k: w for k, z in A.items() for w in [mlin((c, z))] if w}
def sf_add(*terms):
    out = {}
    for c, A in terms:
        for k, z in A.items():
            v = mlin((1, out.get(k, {})), (c, z))
            if v: out[k] = v
            else: out.pop(k, None)
    return out
def duhamel(F, b0, tau, V):
    """int_0^tau ds exp(-(tau - s) bD) V exp(-s bD) F for a rest wave F (degree 0); NOCOMM: x_3 treated as a constant inside the outer shift"""
    E = abs(Fr(b0)); C, S, sC, sS = sf_trig(E); Co, So, sCo, sSo = sf_trig(E, tau); wN = not fault('NOCOMM')
    inner = [(C, F), (sf_scale(S, Fr(-1) / E), pD(F, b0))]                       # exp(-s bD) F on degree 0
    outer = [(Co, lambda H: H), (sf_scale(sSo, Fr(1) / (2 * E)), lambda H: pL(H, wN)), (sf_scale(So, Fr(-1) / E), lambda H: pD(H, b0, wN)),
             (sf_add((Fr(-1) / (2 * E ** 3), So), (Fr(1) / (2 * E * E), sCo)), lambda H: pL(pD(H, b0, wN), wN))]
    out = {}
    for A, Fi in inner:
        H = V(Fi, b0)
        for B, op in outer:
            z = sf_int(sf_mul(A, B), tau)
            if z: out = pf_add((1, out), (1, prm(op(H), z)))
    return out
def V_el(F, b0, e=1): return px3(pf_map(F, lambda W: mlin((e, mmul(mmul(G0, mmul(W, J)), G0)))))
def V_gr(F, b0): return pf_add((1, px3(pf_map(F, lambda W: mmul(mmul(G0, mlin((b0, mmul(W, J)))), G0)))), (Fr(-1, 2), pf_map(F, lambda W: mmul(mmul(GUP[3], W), G0))))
def V_const(F, b0, e=1): return pf_map(F, lambda W: mlin((e, mmul(mmul(G0, mmul(W, J)), G0))))
def O1_sh(F, b0, m_, kap, tau, V):
    out = prm(V(F, b0), J)
    if not fault('FREESHIFT'): out = pf_add((1, out), (-QP.of(kap), prm(duhamel(F, b0, tau, V), J)))   # FREESHIFT: the shift built with the free bD
    return out
def O0_sh(F, b0, m_, kap, tau): return pf_add((1, prm(pD(F, b0), J)), (-m_, F), (kap, prm(pexp(F, tau, b0), J)))
def O0_ord(F, b0, M): return pf_add((1, prm(pD(F, b0), J)), (-M, F))
def O1_ord(F, b0, V): return prm(V(F, b0), J)
def solve_q(op, rhs, dmax=3):
    """a particular rational solution P of op(P) = rhs over fields of degree <= dmax (free variables set to zero), or None"""
    basis = [(d, e_) for d in range(dmax + 1) for e_ in EVEN]
    cols = []
    for d, e_ in basis:
        F = op({d: blade(e_)}); cols.append({(dd, mm): v.c.get(0, Fr(0)) for dd, W in F.items() for mm, v in W.items() if v})
    keys = sorted({k for c_ in cols for k in c_} | {(dd, mm) for dd, W in rhs.items() for mm in W})
    M = [[c_.get(k, Fr(0)) for c_ in cols] + [rhs.get(k[0], {}).get(k[1], ZERO).c.get(0, Fr(0))] for k in keys]
    n = len(cols); piv = []; r = 0
    for j in range(n):
        pr = next((i for i in range(r, len(M)) if M[i][j] != 0), None)
        if pr is None: continue
        M[r], M[pr] = M[pr], M[r]; inv = 1 / M[r][j]; M[r] = [x * inv for x in M[r]]
        for i in range(len(M)):
            if i != r and M[i][j] != 0: f_ = M[i][j]; M[i] = [x - f_ * y for x, y in zip(M[i], M[r])]
        piv.append(j); r += 1
    if any(M[i][n] != 0 for i in range(r, len(M))): return None
    sol = {}
    for i, j in enumerate(piv):
        if M[i][n] != 0:
            d, e_ = basis[j]; sol = pf_add((1, sol), (M[i][n], {d: blade(e_)}))
    return sol
def halves(F, Z_in_plus):
    """the parts of a rest field in the half of the mode and in the other half (P_+ / P_- at rest)"""
    def sp(W):
        c = mmul(mmul(G0, W), G0); return mlin((Fr(1, 2), W), (Fr(1, 2), c)), mlin((Fr(1, 2), W), (Fr(-1, 2), c))
    same = {d: w for d, W in F.items() for w in [sp(W)[0 if Z_in_plus else 1]] if w}; other = {d: w for d, W in F.items() for w in [sp(W)[1 if Z_in_plus else 0]] if w}
    return same, other
GRADS = [((3, 2, PI / 10), 5, 0), ((4, 1, PI / 2), 3, 1), ((4, 1, PI / 2), 5, 2), ((3, 2, 3 * PI / 2), 1, 1)]
ok_on = True; ok_pred_el = True; ok_pred_gr = True; ok_sol = True; ok_solmix = True; ok_const = True; ok_inv = True; nsol = 0; mixdesc = []
for (m_, kap, tau), E_, n in GRADS:
    sgn = (-1) ** n; mu = QP.of(kap) * tau; rg = random.Random(6000 + E_ + n)
    for sec in (-1, 1):
        b0 = Fr(sec * E_); inplus = sec == -1
        Zr = rand_mv(rg); Z = halves({0: Zr}, True)[0 if inplus else 1].get(0) or blade(PPLUS[1] if inplus else PMINUS[1])
        P0 = {0: Z}; ok_on &= not O0_sh(P0, b0, m_, kap, tau) and not O0_ord(P0, b0, E_)
        W_o = halves({0: rand_mv(rg)}, inplus)[1].get(0)                          # the other half at the same frequency: O_0 = -2m there
        ok_inv &= O0_sh({0: W_o}, b0, m_, kap, tau) == {0: mlin((-2 * m_, W_o))}
        g3 = mmul(mmul(GUP[3], Z), G0)
        for vname, V in (('A_0 = g x_3', V_el), ('Phi = g x_3', V_gr)):
            O1s = O1_sh(P0, b0, m_, kap, tau, V); O1o = O1_ord(P0, b0, V)
            P1 = solve_q(lambda F: O0_ord(F, b0, E_), pf_add((-1, O1o))); nsol += 1
            ok_sol &= P1 is not None and not pf_add((1, O0_sh(P1, b0, m_, kap, tau)), (1, O1s))
            if inplus and V is V_el:
                ok_pred_el &= O1o == {1: mlin((-1, Z))} and O1s == pf_add((1, {1: mmul(Z, zc(-1, sgn * mu))}), (1, {0: mmul(g3, zc(-sgn * mu / (2 * E_), -sgn * QP.of(kap) / (2 * E_ * E_)))}))
                ok_solmix &= P1 is not None and halves(P1, True)[1] == {2: mlin((Fr(1, 2), mmul(g3, J)))}
                if E_ == 5 and n == 0: mixdesc.append('A_0: gamma^3 Z gamma_0 (%s)' % fmt_z(zc(-sgn * mu / (2 * E_), -sgn * QP.of(kap) / (2 * E_ * E_))))
            if inplus and V is V_gr:
                want = pf_add((1, {1: mmul(Z, zc(E_, -sgn * E_ * mu))}), (1, {0: mmul(g3, zc(sgn * mu / 2, Fr(-1, 2) + sgn * QP.of(kap) / E_))}))
                ok_pred_gr &= O1o == {1: mlin((E_, Z)), 0: mlin((Fr(-1, 2), mmul(g3, J)))} and O1s == want
                if E_ == 5 and n == 0: mixdesc.append('Phi: gamma^3 Z gamma_0 (%s), of which -J/2 is the ordinary operator\'s' % fmt_z(zc(sgn * mu / 2, Fr(-1, 2) + sgn * QP.of(kap) / E_)))
        O1c = O1_sh(P0, b0, m_, kap, tau, V_const)
        ok_const &= not halves(O1c, inplus)[1] and (not inplus or O1c == {0: mmul(Z, zc(-1, sgn * mu))})
chk('bit', ok_on and ok_pred_el and ok_pred_gr, 'st.GRAD: the first-order operator on a quantized rest mode P_0 = Z e^{-J E t} (Z in P_+; (m, kappa, tau) = (3, 2, pi/10), (4, 1, pi/2) at E = 3 and 5, (3, 2, 3 pi/2)), exactly in Q[pi], J-complex factors acting on the right: for A_0 = g x_3 (charge 1) the ordinary operator gives -x_3 P_0 (no part in the other half), the shifted one -x_3 P_0 (1 - (-1)^n mu J) plus gamma^3 Z gamma_0 e^{-J E t} times -(-1)^n (mu + kappa J/E)/(2E), a mixing into the advanced half that only the shift makes (from the commutator [exp(-s bD), x_3] = -(sin(E s)/E) gamma^3 (.) gamma_0); for Phi = g x_3 the ordinary operator mixes already through the connection term, gamma^3 Z gamma_0 times -J/2, the shift adds (-1)^n (mu + 2 kappa J/E)/2, and the part in the half of the mode is E x_3 P_0 (1 - (-1)^n mu J), the Phi-coefficient of ATY-037 (%s, at E = 5, n = 0)' % '; '.join(mixdesc))
chk('ctl', ok_const and ok_inv, 'st.GRAD: without a gradient (a constant A_0) the first-order operator has no part in the other half, for both signs of the frequency: it is -(1 - (-1)^n mu J) P_0, a shift of the frequency; and on the other half at the quantized frequency the shifted operator is -2m exactly, so the mixing of the operator is removed by the constant redefinition P -> P + g W_-/(2m), as Foldy and Wouthuysen remove the odd terms of the ordinary equation (recalled)')
chk('bit', ok_sol, 'st.SOL: on the %d cases (four settings, both signs of the frequency, both potentials) the first-order solution of the ordinary equation of mass E, P_1 = sum_{d <= 3} x_3^d W_d e^{-+J E t} found by exact rational elimination from bD_g(P) J = E P, solves the shifted equation at first order exactly in Q[pi]: O_0[P_1] + O_1[P_0] = 0. The quantized mode survives the gradient at first order with its frequency, cos E tau = 0 unchanged; the reason, derived and not run: exp(-tau bD_g) is a power series in bD_g, which acts as -E (.) J on a solution of the ordinary equation of mass E with the same bD_g, so the shifted operator is f_J(E) = 0 there, in any potential and to every order' % nsol)
chk('bit', ok_solmix, 'st.SOL: for A_0 = g x_3 the part of P_1 in the advanced half is x_3^2 gamma^3 Z gamma_0 J/2, the same for the shifted and the ordinary equation (the solutions coincide): the two signs of frequency mix in the solutions exactly as for the ordinary Dirac equation of mass E; the mixing that the shift adds to the operator is compensated by the shift\'s own terms in O_0 on the x_3-dependent part')
# the standard route: Dirac matrices on the space of x_3-polynomials of degree <= DM times one wave; the potential exactly (A_0 = g x_3), the
# frame by its vierbein form D_g = N^{-1/2} (N^{-1} G^0 d_t + G^i d_i) N^{1/2} with N = sqrt(1 - 2 g x_3) as truncated series; scipy expm of the
# whole operator matrix, d/dg by central differences, the ordinary first-order solution by numpy lstsq
DM = 6
def binom_series(a, c, n):
    """coefficients of (1 + c x)^a to x^n"""
    out = [1.0]
    for j in range(1, n + 1): out.append(out[-1] * (a - j + 1) / j * c)
    return out
def pmul_mat(coef, n):
    M = np.zeros((n + 1, n + 1))
    for d in range(n + 1):
        for j, cj in enumerate(coef):
            if d + j <= n: M[d + j, d] += cj
    return M
DER = np.zeros((DM + 1, DM + 1))
for d in range(1, DM + 1): DER[d - 1, d] = d
X3 = pmul_mat([0.0, 1.0], DM); IP = np.eye(DM + 1)
def Dmat(beta, g, kind):
    parts = [1j * beta[0] * IP, 1j * beta[1] * IP, 1j * beta[2] * IP, 1j * beta[3] * IP + DER]
    if kind == 'el':
        return sum(np.kron(parts[mu], GU[mu]) for mu in range(4)) + 1j * g * np.kron(X3, GM[0])
    Ninv = pmul_mat(binom_series(-0.5, -2 * g, DM), DM); Nmh = pmul_mat(binom_series(-0.25, -2 * g, DM), DM); Nph = pmul_mat(binom_series(0.25, -2 * g, DM), DM)
    Dp = np.kron(Ninv @ parts[0], GU[0]) + sum(np.kron(parts[mu], GU[mu]) for mu in (1, 2, 3))
    return np.kron(Nmh, I4) @ Dp @ np.kron(Nph, I4)
def Omat(beta, g, kind, m_, kap, tf, M=None):
    Dg = Dmat(beta, g, kind); n4 = Dg.shape[0]
    if M is not None: return 1j * Dg - M * np.eye(n4)
    return 1j * Dg - m_ * np.eye(n4) + 1j * kap * expm(-tf * Dg)
def std_grad(beta, u, E_, m_, kap, tf, kind, h=1e-5):
    psi0 = np.zeros(4 * (DM + 1), complex); psi0[:4] = u
    O1o = (Omat(beta, h, kind, m_, kap, tf, M=E_) - Omat(beta, -h, kind, m_, kap, tf, M=E_)) / (2 * h)
    O1s = (Omat(beta, h, kind, m_, kap, tf) - Omat(beta, -h, kind, m_, kap, tf)) / (2 * h)
    A0o = Omat(beta, 0.0, kind, m_, kap, tf, M=E_); A0s = Omat(beta, 0.0, kind, m_, kap, tf)
    psi1 = np.linalg.lstsq(A0o, -O1o @ psi0, rcond=None)[0]
    cons_res = np.abs(A0o @ psi1 + O1o @ psi0).max() / np.abs(O1o @ psi0).max()
    sh_res = np.abs(A0s @ psi1 + O1s @ psi0).max() / np.abs(O1s @ psi0).max()
    return psi0, psi1, O1s @ psi0, cons_res, sh_res, np.abs(A0s @ psi0).max()
worst_g = 0.0; worst_c = 0.0; cmp_g = 0.0; cmp_mix = 0.0; ok_free = True
m_, kap, tau, E_, n = 3, 2, PI / 10, 5, 0; tf = float(tau)
for k, s in (((5, 0, 0, 0), -1), ((5, 0, 0, 0), 1), ((13, 0, 0, 12), -1), ((13, 12, 0, 0), -1), ((7, 2, 4, 2), 1)):
    b = kvec(k, s); beta = np.array([float(x) for x in b])
    u = np.linalg.svd(-cmat(beta) - E_ * I4)[2][-1].conj()                      # an ordinary solution of mass E (column side)
    for kind in ('el', 'gr'):
        psi0, psi1, o1s, cres, sres, free = std_grad(beta, u, E_, m_, kap, tf, kind)
        worst_c = max(worst_c, cres); worst_g = max(worst_g, sres); ok_free &= free < 1e-10
# bit == std at rest, sector -1: the label first-order operator and the advanced-half part of P_1 against the matrices (dictionary: M(W) u0)
rg = random.Random(6000 + E_ + n); Z = halves({0: rand_mv(rg)}, True)[0][0]; uZ = Mof(Z) @ U0; b0 = Fr(-E_)
for kind, V in (('el', V_el), ('gr', V_gr)):
    psi0, psi1, o1s, cres, sres, free = std_grad(np.array([-5.0, 0, 0, 0]), uZ, E_, m_, kap, tf, kind)
    lab = O1_sh({0: Z}, b0, m_, kap, tau, V); labv = np.zeros(4 * (DM + 1), complex)
    for d, W in lab.items(): labv[4 * d:4 * d + 4] = Mof(W) @ U0
    cmp_g = max(cmp_g, np.abs(labv - o1s).max() / np.abs(o1s).max())
    P1 = solve_q(lambda F: O0_ord(F, b0, E_), pf_add((-1, O1_ord({0: Z}, b0, V))))
    lowl = np.zeros(4 * (DM + 1), complex)
    for d, W in (halves(P1, True)[1].items() if P1 is not None else []): lowl[4 * d:4 * d + 4] = Mof(W) @ U0
    lows = psi1.copy(); lows[0::4] = 0; lows[1::4] = 0                        # the lower components: the advanced half at rest
    lowl[:4] = 0; lows[:4] = 0                                                  # degree 0 is not fixed: the free solution x_3 U + i gamma^3 U/(2E) has a lower part there
    cmp_mix = max(cmp_mix, np.abs(lowl - lows).max() / max(1e-300, np.abs(lows).max()))
chk('std', worst_c < 1e-8 and worst_g < 1e-7 and ok_free, 'st.SOL: Dirac matrices on x_3-polynomials of degree <= %d times a wave (rest, both signs of the frequency, and moving: k = (13,0,0,12), (13,12,0,0), (7,2,4,2); (m, kappa, tau) = (3, 2, pi/10), E = 5), the operator exp(-tau D_g) by scipy expm of the whole matrix, A_0 = g x_3 exactly and the frame by N^{-1/2} D\' N^{1/2} with N = sqrt(1 - 2 g x_3), d/dg by central differences: the first-order solution of the ordinary equation (numpy lstsq, residual %.1e) solves the shifted first-order equation (relative residual %.1e)' % (DM, worst_c, worst_g))
chk('bit==std', cmp_g < 1e-8 and cmp_mix < 1e-8, 'st.GRAD: at rest the exact first-order operators of the labels, the mixing term included, equal the matrix ones, the frame\'s connection term coming from the vierbein form (%.1e), and the advanced-half part of P_1 at degrees 1 to 3 equals the lower components of the lstsq solution (%.1e; at degree 0 the two solutions may differ by the free solution x_3 U + i gamma^3 U/(2E), the p_3-derivative of the rest wave)' % (cmp_g, cmp_mix))

print('\n  [time] %.1f s' % (time.time() - T0), flush=True)
finish('SHIFTED-TENSOR')
