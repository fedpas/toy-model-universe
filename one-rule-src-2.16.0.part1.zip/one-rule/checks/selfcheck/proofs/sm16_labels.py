#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""sm16_labels.py -- the sixteen states of one generation as the even labels of five bits: the six anomalies of
S(U(3) x U(2)), the cubic trace of so(n,n) on its half-spinors, the ratio Tr T3^2 / Tr Q^2, the complement mask as the
Hodge star, and the compact and the split real form of so(10).

Statement. Labels: weak bits 0, 1 and colour bits 2, 3, 4; a, b = the numbers of weak and colour bits set;
Y = a/2 - b/3, Q = (x & 1) - b/3, T3 = ((x & 1) - ((x >> 1) & 1))/2.
(A) The 16 even labels are free of the six anomalies: SU(3)^3, SU(2)^2 U(1), SU(3)^2 U(1), U(1)^3, the gravitational
    U(1) (the sum of Y) and Witten's SU(2) (an even number of doublets: four). The cubic trace tr(T_a {T_b, T_c})
    vanishes on both half-spinors of so(n,n) for n = 2, 4, 5, 6 and not for n = 3 (so(3,3) = sl(4,R) on its 4).
(B) Tr T3^2 = 2 and Tr Q^2 = 16/3 over the 16: the ratio 3/8, also over the 5, 10, 10-bar and 5-bar (the labels of
    popcount 1, 2, 3, 4), the 16-bar and the adjoint 24. Furey's 3/8 = Tr_C Y / dim_C V on V = C^8 has the pair (3, 8):
    the same number from a different trace over a different space; Y - 3/8 is traceless on V, while on the 16 Y is
    traceless already.
(C) x -> x ^ 31 is the Hodge star of Lambda(R^5) (u ^ *v = <u, v> vol) up to the sign sigma(S) of the permutation
    (S, S-bar), sigma(S) = (-1)^(sum of S - k(k-1)/2); it exchanges the even and the odd labels (the two eigenspaces of
    the volume element), and negates every weight of the Cartan of sl(5), the weights of so(10), Y and Q. The star
    identity, the sign formula, the parity rule (exchange exactly for odd n) and the negated sl(n) weights hold for
    n = 1..8.
(D) The bivectors of Cl(0,10) form the compact so(10), Killing signature (0,45,0), acting on a complex 32 whose invariant
    Hermitian forms are a P_even + b P_odd (positive definite for a, b > 0); those of Cl(5,5) form so(5,5), Killing
    signature (25,20,0), acting on a real 32 whose only invariant symmetric form, up to a factor, pairs x with x ^ 31
    and has signature (16,16,0): no invariant positive-definite form, real or Hermitian.
[bit] The labels and Fractions; the Fock matrices of five modes (a_i flips bit i with the Jordan-Wigner sign, integer
      matrices), whose products follow the bit rule of bitcliff.Alg (selfcheck/steps15_17/bitcliff.py) for Cl(n,n),
      n = 2..6, and for Cl(0,10); anomaly traces over the even block; cubic traces as exact integers; the star from
      bitcliff.reorder_sign; the Killing signatures from the engine's structure constants (b1lib.killing_signature on
      gravity_selfcheck.Lie); invariant forms as the exact solution space of X rho(B) + rho(B)^+ X = 0 over the 45
      bivectors (each rho(B) is a monomial matrix: a signed graph on the 1024 unknowns).
[std] The textbook table of one generation written by hand (Q_L, u_R^c, d_R^c, L, e_R^c, nu_R^c with Dynkin indices
      1/2 and anomaly coefficients A(3) = +1, A(3-bar) = -1); gamma matrices as Kronecker products of Pauli matrices
      (numpy), Sigma_ab = [g_a, g_b]/4, the chirality projector, the cubic trace over all triples; the Hodge star as
      the inverse of the determinant pairing; reports/furey/model.py (numpy) and the stored furey_results.json; the
      Killing form 8 tr(XY) of the vector representation; invariant forms as the numpy nullspace of the same equations
      (Kronecker Gram matrix) and, for the compact form, the average over the finite group of the even gamma products.
[ctl] The 10 alone and the 5-bar alone (sum Y^3 = +-5/36, A = +-1); the 16 without L (3 doublets); Y = a/3 - b/2; the
      ratio over the labels with a = 1 (3/4) and over Q_L alone; so(3,3) on its 4 (non-zero, so the cubic check can
      fail) and on its full spinor (zero); the complement without the sign; Cl(0,10) without the factor i; the split
      signature (4,6); the finite-group average in the split case (not invariant under so(5,5)). Each wrong version is
      also a --fault option that puts it into the main lines (the run must then end with FAILS).
Scope. One generation, the 32 labels of five bits; so(n,n) for n = 2..6; the star for n = 1..8. The ratio 3/8 is a
      ratio of traces (the unification value), nothing more; nothing here decides a gauge group, three generations or
      anything about nature. The count 4/17 is not computed: no definition of it is in the package. Of the engine only
      Lie and killing_signature are used (section E).
Run:  python3 selfcheck/proofs/sm16_labels.py [--fault TEN|FIVEBAR|NOL|YSWAP|FULLSPIN|A1|NOSIGN|REALC|SPLIT46]
      (from the package root; also from its own folder, and under -I -B)"""
import os, sys, json, itertools, importlib.util
from fractions import Fraction as F
from collections import Counter
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'SM16'
HERE = os.path.dirname(os.path.abspath(__file__))
SELF = os.path.dirname(HERE)                                        # selfcheck/
ROOT = os.path.dirname(SELF)                                        # the package root
def load(name, *rel):
    spec = importlib.util.spec_from_file_location(name, os.path.join(ROOT, *rel))
    mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
bc = load('bitcliff', 'selfcheck', 'steps15_17', 'bitcliff.py')
Alg, sig, pc, reorder_sign = bc.Alg, bc.sig, bc.pc, bc.reorder_sign

FAULT_NAMES = ('TEN', 'FIVEBAR', 'NOL', 'YSWAP', 'FULLSPIN', 'A1', 'NOSIGN', 'REALC', 'SPLIT46')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)

def fr(v): return str(F(v))
def rank_exact(rows):
    """rank over Q of a list of integer or Fraction rows"""
    M = [[F(v) for v in r] for r in rows]; rk = 0
    ncol = len(M[0]) if M else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [u - f * w for u, w in zip(M[i], M[rk])]
        rk += 1
        if rk == len(M): break
    return rk
def dtensor(R):
    """d_abc = tr(R_a {R_b, R_c}) for a stack R of k square matrices (integer stacks stay integer)"""
    P = np.einsum('aij,bjk->abik', R, R)
    T = np.einsum('abik,cki->abc', P, R)
    return T + T.transpose(0, 2, 1)

# ===================================================================================== A. the six anomalies of the 16
head('A. The 16 even labels: the six anomalies of S(U(3) x U(2)) from the labels, from the Fock matrices and from the textbook table')
a_of = lambda x: pc(x & 3)                                           # weak bits set
b_of = lambda x: pc(x >> 2)                                          # colour bits set
LAB = list(range(32))
EVEN = [x for x in LAB if pc(x) % 2 == 0]; ODD = [x for x in LAB if pc(x) % 2 == 1]
Y_true = lambda x: F(a_of(x), 2) - F(b_of(x), 3)
Y_swap = lambda x: F(a_of(x), 3) - F(b_of(x), 2)                     # wrong version: weak and colour coefficients exchanged
Yf = Y_swap if FAULT == 'YSWAP' else Y_true
Qf = lambda x: (x & 1) - F(b_of(x), 3)
T3f = lambda x: F((x & 1) - ((x >> 1) & 1), 2)
TEN = [x for x in LAB if pc(x) == 2]; FIVEBAR = [x for x in LAB if pc(x) == 4]
NO_L = [x for x in EVEN if (a_of(x), b_of(x)) != (1, 3)]
GEN = {'TEN': TEN, 'FIVEBAR': FIVEBAR, 'NOL': NO_L}.get(FAULT, EVEN)  # the generation under test
ANAMES = ('SU(3)^3', 'SU(2)^2 U(1)', 'SU(3)^2 U(1)', 'U(1)^3', 'grav U(1)', 'doublets')
def show(v): return ', '.join('%s %s' % (n_, fr(c)) for n_, c in zip(ANAMES, v))
def doublet_pairs(S):
    """the labels with a = 1 grouped in pairs {x, x ^ 3} (the two weak states of one doublet); None if a pair is broken"""
    pairs = {frozenset((x, x ^ 3)) for x in S if a_of(x) == 1}
    return len(pairs) if all(p <= set(S) for p in pairs) else None
def anom_labels(S, Y):
    """the six numbers in the normalisation of the textbook table: sum of A(R3) dim(R2); sum of T(2) dim(R3) Y over doublets;
    sum of T(3) dim(R2) Y over colour multiplets; sum of Y^3; sum of Y; the number of doublets"""
    nd = doublet_pairs(S)
    return (F(sum(1 for x in S if b_of(x) == 1) - sum(1 for x in S if b_of(x) == 2), 3),
            F(1, 4) * sum((Y(x) for x in S if a_of(x) == 1), F(0)),
            F(1, 6) * sum((Y(x) for x in S if b_of(x) in (1, 2)), F(0)),
            sum((Y(x) ** 3 for x in S), F(0)), sum((Y(x) for x in S), F(0)), F(nd if nd is not None else -1))
def anomaly_free(v): return all(c == 0 for c in v[:5]) and v[5] >= 0 and v[5].denominator == 1 and v[5] % 2 == 0
lab = anom_labels(GEN, Yf)
chk('bit', anomaly_free(lab) and lab[5] == 4, 'labels (sums over the 16 even labels; triplets b = 1, antitriplets b = 2, doublets a = 1 in pairs {x, x^3}): ' + show(lab))

# the Fock space of five modes: a_i flips bit i with the Jordan-Wigner sign (integer matrices)
def a_op(i, n):
    N = 1 << n; M = np.zeros((N, N), dtype=np.int64)
    for x in range(N):
        if (x >> i) & 1: M[x ^ (1 << i), x] = (-1) ** pc(x & ((1 << i) - 1))
    return M
A5 = [a_op(i, 5) for i in range(5)]
I32 = np.eye(32, dtype=np.int64)
car = all(np.array_equal(A5[i] @ A5[j].T + A5[j].T @ A5[i], I32 * int(i == j)) and not (A5[i] @ A5[j] + A5[j] @ A5[i]).any() for i in range(5) for j in range(5))
Nn = [A.T @ A for A in A5]
chk('bit', car and all(np.array_equal(Nn[i], np.diag([(x >> i) & 1 for x in LAB])) for i in range(5)),
    'five fermionic modes on the 32 labels: canonical anticommutation relations, number operator N_i = bit i of the label (integer matrices)')
Y6_true = 3 * (Nn[0] + Nn[1]) - 2 * (Nn[2] + Nn[3] + Nn[4])        # 6 Y = 3 (N_0 + N_1) - 2 (N_2 + N_3 + N_4)
Y6 = 2 * (Nn[0] + Nn[1]) - 3 * (Nn[2] + Nn[3] + Nn[4]) if FAULT == 'YSWAP' else Y6_true
Tp, Tm = A5[0].T @ A5[1], A5[1].T @ A5[0]                           # su(2) on the weak bits: a_0^+ a_1, a_1^+ a_0
C4 = (Nn[0] - Nn[1]) @ (Nn[0] - Nn[1]) + 2 * (Tp @ Tm + Tm @ Tp)    # 4 x the su(2) Casimir
COL = (2, 3, 4)
SL3 = [A5[i].T @ A5[j] for i in COL for j in COL if i != j] + [Nn[2] - Nn[3], Nn[3] - Nn[4]]   # a basis of sl(3) on the colour bits
L3 = [x for x in LAB if a_of(x) == 0 and b_of(x) == 1]; L3b = [x for x in LAB if a_of(x) == 0 and b_of(x) == 2]
Tc = Nn[2] + Nn[3] - 2 * Nn[4]                                       # a colour generator with tr_3(T^3) = -6
def blk(M, S): return M[np.ix_(S, S)]
def tr(M): return int(np.trace(M))
def anom_fock(S, Y6m):
    Yb, T3b, Hc, Tb, Cb = blk(Y6m, S), blk(Nn[0] - Nn[1], S), blk(Nn[2] - Nn[3], S), blk(Tc, S), blk(C4, S)
    t3 = tr(blk(Tc, L3) @ blk(Tc, L3) @ blk(Tc, L3))
    return (F(tr(Tb @ Tb @ Tb), t3),                                  # A = tr_S(T^3) / tr_3(T^3)
            F(tr(T3b @ T3b @ Yb), 24),                                # tr(T3^2 Y), T3 = (N_0 - N_1)/2, Y = (6Y)/6
            F(tr(Hc @ Hc @ Yb), 24),                                  # tr(T^2 Y), T = (N_2 - N_3)/2 (index 1/2)
            F(tr(Yb @ Yb @ Yb), 216), F(tr(Yb), 6),
            F(int(np.sum(np.diag(Cb) == 3)), 2) if np.array_equal(Cb, np.diag(np.diag(Cb))) else F(-1))
fock = anom_fock(GEN, Y6)
D16 = dtensor(np.array([blk(g, GEN) for g in SL3])); D3 = dtensor(np.array([blk(g, L3) for g in SL3])); D3b = dtensor(np.array([blk(g, L3b) for g in SL3]))
t3, t3b = tr(blk(Tc, L3) @ blk(Tc, L3) @ blk(Tc, L3)), tr(blk(Tc, L3b) @ blk(Tc, L3b) @ blk(Tc, L3b))
chk('bit', anomaly_free(fock) and fock[5] == 4 and not D16.any() and D3.any() and np.array_equal(D3b, -D3) and (t3, t3b) == (-6, 6),
    'Fock traces over the block of the 16 (Y = (N_0+N_1)/2 - (N_2+N_3+N_4)/3, su(3) from the traceless a_i^+ a_j on the colour bits, su(2) on the weak bits): ' + show(fock)
    + '; the full cubic tensor tr(T_a {T_b, T_c}) of the 8 colour generators is 0 in all 512 entries on the 16 (integers), non-zero on the 3 (b = 1) and its negative on the 3-bar (b = 2); tr T^3 = -6 and +6 there, so A(3) = +1, A(3-bar) = -1')
# [std] the textbook table, by hand
SM = [('Q_L', 3, 2, F(1, 6), 1), ('u_R^c', 3, 1, F(-2, 3), -1), ('d_R^c', 3, 1, F(1, 3), -1), ('L', 1, 2, F(-1, 2), 0), ('e_R^c', 1, 1, F(1), 0), ('nu_R^c', 1, 1, F(0), 0)]
def anom_table(T):
    T2 = lambda d2: F(1, 2) if d2 == 2 else F(0); T3_ = lambda d3: F(1, 2) if d3 == 3 else F(0)
    return (sum((F(A * d2) for _, d3, d2, Y, A in T), F(0)), sum((T2(d2) * d3 * Y for _, d3, d2, Y, A in T), F(0)),
            sum((T3_(d3) * d2 * Y for _, d3, d2, Y, A in T), F(0)), sum((d3 * d2 * Y ** 3 for _, d3, d2, Y, A in T), F(0)),
            sum((d3 * d2 * Y for _, d3, d2, Y, A in T), F(0)), F(sum(d3 for _, d3, d2, Y, A in T if d2 == 2)))
std = anom_table(SM)
chk('std', anomaly_free(std) and std[5] == 4, 'textbook table Q_L (3,2,1/6), u_R^c (3-bar,1,-2/3), d_R^c (3-bar,1,1/3), L (1,2,-1/2), e_R^c (1,1,1), nu_R^c (1,1,0) with T(3) = T(2) = 1/2, A(3) = +1, A(3-bar) = -1: ' + show(std))
def label_table(S, Y):
    out = []
    for (a, b), m in sorted(Counter((a_of(x), b_of(x)) for x in S).items()):
        ys = {Y(x) for x in S if (a_of(x), b_of(x)) == (a, b)}
        out.append((3 if b in (1, 2) else 1, 2 if a == 1 else 1, ys.pop() if len(ys) == 1 else None, 1 if b == 1 else (-1 if b == 2 else 0), m))
    return sorted(out, key=str)
tab_std = sorted([(d3, d2, Y, A, d3 * d2) for _, d3, d2, Y, A in SM], key=str)
chk('bit==std', lab == fock == std and label_table(GEN, Yf) == tab_std,
    'the six numbers agree on the three routes (labels, Fock traces, textbook), and the label classes (a, b) are the six multiplets of the table one to one (colour dimension from b, weak dimension from a, Y, A, size = dim(R3) dim(R2))')
# controls
a10, a5b, a1 = anom_labels(TEN, Y_true), anom_labels(FIVEBAR, Y_true), anom_labels([0], Y_true)
f10, f5b = anom_fock(TEN, Y6_true), anom_fock(FIVEBAR, Y6_true)
chk('ctl', a10[0] == 1 and a10[3] == F(5, 36) and a5b[0] == -1 and a5b[3] == F(-5, 36) and f10[:5] == a10[:5] and f5b[:5] == a5b[:5]
    and all(p + q + r == 0 for p, q, r in zip(a10[:5], a5b[:5], a1[:5])),
    'the 10 alone (popcount 2): ' + show(a10)[:-12] + '; the 5-bar alone (popcount 4): ' + show(a5b)[:-12] + ' (labels = Fock traces); they cancel together, with the singlet')
anl = anom_labels(NO_L, Y_true)
chk('ctl', anl[5] == 3 and anl[5] % 2 == 1, 'the 16 without the doublet L: %s doublets, an odd number (Witten anomaly)' % fr(anl[5]))
asw = anom_labels(EVEN, Y_swap)
chk('ctl', asw[3] != 0 and asw[4] != 0, 'Y with the weak and colour coefficients exchanged (a/3 - b/2): sum Y^3 = %s, sum Y = %s, not 0' % (fr(asw[3]), fr(asw[4])))

# ===================================================================================== B. the cubic trace on so(n,n)
head('B. The cubic trace tr(T_a {T_b, T_c}) on the half-spinors of so(n,n), n = 2..6 (Fock matrices, exact integers) and of so(2n) (Kronecker gamma matrices, numpy)')
def fock_cl(n):
    A = [a_op(i, n) for i in range(n)]
    return [X + X.T for X in A] + [X - X.T for X in A]                # generators 0..n-1 square +1, n..2n-1 square -1: sig(n, n)
def rho_cache(gens, N):
    cache = {}
    def rho(mask):
        if mask not in cache:
            M = np.eye(N, dtype=gens[0].dtype)
            for k in range(len(gens)):
                if (mask >> k) & 1: M = M @ gens[k]
            cache[mask] = M
        return cache[mask]
    return rho
sweep_bit = {}
for n in range(2, 7):
    N = 1 << n; gens = fock_cl(n); alg = Alg(sig(n, n)); I = np.eye(N, dtype=np.int64)
    rel = all(np.array_equal(gens[i] @ gens[j] + gens[j] @ gens[i], 2 * alg.eps[i] * I * int(i == j)) for i in range(2 * n) for j in range(2 * n))
    biv = [m for m in range(1 << (2 * n)) if pc(m) == 2]; rho = rho_cache(gens, N)
    prod = True
    for a in biv:
        for b in biv:
            s, c = alg.blade_mul(a, b)
            if not np.array_equal(rho(a) @ rho(b), s * rho(c)): prod = False
    ev = [x for x in range(N) if pc(x) % 2 == 0]; od = [x for x in range(N) if pc(x) % 2 == 1]
    parity = all(not rho(m)[np.ix_(od, ev)].any() and not rho(m)[np.ix_(ev, od)].any() for m in biv)
    blocks = {'even': ev, 'odd': od} if FAULT != 'FULLSPIN' else {'even': list(range(N)), 'odd': list(range(N))}
    D = {k_: dtensor(np.array([rho(m)[np.ix_(ix, ix)] for m in biv])) for k_, ix in blocks.items()}
    rk = {k_: (rank_exact(d.reshape(len(biv), -1).tolist()) if d.any() else 0) for k_, d in D.items()}
    sweep_bit[n] = dict(rel=rel, prod=prod, parity=parity, nb=len(biv), maxd={k_: int(np.abs(d).max()) for k_, d in D.items()}, rank=rk,
                        opposite=bool(np.array_equal(D['odd'], -D['even'])), full=int(np.abs(dtensor(np.array([rho(m) for m in biv]))).max()) if n == 3 else None)
chk('bit', all(v['rel'] and v['prod'] and v['parity'] for v in sweep_bit.values()),
    'for n = 2..6 the 2n Fock generators E_i = a_i + a_i^+ (square +1), F_i = a_i - a_i^+ (square -1) anticommute, and the n(2n-1) bivectors multiply by the bit rule of bitcliff.Alg(sig(n, n)) on all pairs ('
    + ', '.join('%d^2' % v['nb'] for v in sweep_bit.values()) + ' products); every bivector keeps the even and the odd labels apart')
zero_bit = [n for n, v in sweep_bit.items() if v['maxd']['even'] == 0 and v['maxd']['odd'] == 0]
chk('bit', zero_bit == [2, 4, 5, 6], 'the cubic trace, exact in integers over all n(2n-1)^3 triples on each half-spinor block: zero for n = %s; ' % zero_bit
    + '; '.join('n = %d: max |d| %d / %d, rank %d / %d' % (n, v['maxd']['even'], v['maxd']['odd'], v['rank']['even'], v['rank']['odd']) for n, v in sweep_bit.items()))
v3 = sweep_bit[3]
chk('ctl', v3['maxd']['even'] > 0 and v3['rank']['even'] == 15 and v3['opposite'] and v3['full'] == 0,
    'so(3,3) = sl(4,R) on its 4 (the even block): the cubic trace is not zero (max |d| = %d, rank %d as a map g -> Sym^2 g*), the odd block (the 4-bar) gives exactly its negative, and the full spinor 4 + 4-bar gives 0: the check can fail, and one block is needed' % (v3['maxd']['even'], v3['rank']['even']))
chk('bit', sweep_bit[5]['maxd'] == {'even': 0, 'odd': 0}, 'so(5,5) on the 16 (even labels) and on the 16-bar (odd labels): all 45^3 = 91125 cubic traces are the integer 0')
# [std] Kronecker gamma matrices of so(2n), complex
X2 = np.array([[0, 1], [1, 0]], dtype=complex); Y2 = np.array([[0, -1j], [1j, 0]]); Z2 = np.diag([1.0, -1.0]).astype(complex); I2 = np.eye(2, dtype=complex)
def kron_all(ms):
    out = np.ones((1, 1), dtype=complex)
    for m in ms: out = np.kron(out, m)
    return out
def gammas(n):
    g = []
    for j in range(n):
        g.append(kron_all([Z2] * j + [X2] + [I2] * (n - j - 1))); g.append(kron_all([Z2] * j + [Y2] + [I2] * (n - j - 1)))
    return g
sweep_std = {}
for n in range(2, 7):
    g = gammas(n); N = 1 << n
    cliff = all(np.allclose(g[i] @ g[j] + g[j] @ g[i], 2 * np.eye(N) * (i == j)) for i in range(2 * n) for j in range(2 * n))
    S = np.array([(g[a] @ g[b] - g[b] @ g[a]) / 4 for a in range(2 * n) for b in range(a + 1, 2 * n)])
    G0 = np.eye(N, dtype=complex)
    for m in g: G0 = G0 @ m
    Gam = G0 if np.allclose(G0 @ G0, np.eye(N)) else 1j * G0
    plus = [i for i in range(N) if Gam[i, i].real > 0.5]; minus = [i for i in range(N) if Gam[i, i].real < -0.5]
    ok = np.allclose(Gam, np.diag(np.diag(Gam))) and len(plus) == len(minus) == N // 2 and all(np.allclose(Gam @ s, s @ Gam) for s in S)
    D = {k_: dtensor(S[:, ix][:, :, ix]) for k_, ix in (('plus', plus), ('minus', minus))}
    sweep_std[n] = dict(ok=cliff and ok, maxd={k_: float(np.abs(d).max()) for k_, d in D.items()},
                        rank={k_: int(np.linalg.matrix_rank(d.reshape(len(S), -1), tol=1e-9)) for k_, d in D.items()}, opposite=bool(np.allclose(D['minus'], -D['plus'])))
zero_std = [n for n, v in sweep_std.items() if max(v['maxd'].values()) < 1e-12]
chk('std', all(v['ok'] for v in sweep_std.values()) and zero_std == [2, 4, 5, 6] and sweep_std[3]['rank'] == {'plus': 15, 'minus': 15} and sweep_std[3]['opposite'],
    'Kronecker gamma matrices g_1..g_2n (Hermitian, square 1), Sigma_ab = [g_a, g_b]/4, chirality i^k g_1...g_2n: cubic trace below 1e-12 on both chiralities for n = %s; n = 3: max |d| %.4g, rank 15 on each chirality, opposite signs' % (zero_std, sweep_std[3]['maxd']['plus']))
chk('std', sweep_std[5]['maxd']['plus'] < 1e-12 and sweep_std[5]['maxd']['minus'] < 1e-12,
    'so(10): tr_16(Sigma_a {Sigma_b, Sigma_c}) over all 45^3 = 91125 triples on the chirality +1 block: max |d| = %.1e (and %.1e on the other block)' % (sweep_std[5]['maxd']['plus'], sweep_std[5]['maxd']['minus']))
chk('bit==std', zero_bit == zero_std and all(sweep_bit[n]['rank']['even'] == sweep_std[n]['rank']['plus'] for n in range(2, 7)),
    'the split form (Fock, integers) and the compact form (Kronecker, floats) give the same list of n with no cubic invariant on a half-spinor, %s, and the same rank of the cubic tensor for every n (15 at n = 3, 0 otherwise); the cubic tensor is polynomial on the complexified algebra, so the real form does not change whether it vanishes' % zero_bit)

# ===================================================================================== C. the ratio
head('C. Tr T3^2 / Tr Q^2 over the 16 and over the SU(5) multiplets; Furey\'s Tr_C Y / dim_C V')
def ratio(S):
    t = sum((T3f(x) ** 2 for x in S), F(0)); q = sum((Qf(x) ** 2 for x in S), F(0))
    return t, q, (t / q if q else None)
MAIN = [x for x in EVEN if a_of(x) == 1] if FAULT == 'A1' else EVEN
r16 = ratio(MAIN)
chk('bit', r16 == (F(2), F(16, 3), F(3, 8)), 'over the 16 even labels: Tr T3^2 = %s, Tr Q^2 = %s, ratio %s (exact)' % tuple(fr(v) for v in r16))
CLS = [('5 (popcount 1)', [x for x in LAB if pc(x) == 1]), ('10 (popcount 2)', TEN), ('10-bar (popcount 3)', [x for x in LAB if pc(x) == 3]), ('5-bar (popcount 4)', FIVEBAR), ('16-bar (odd labels)', ODD)]
rc = {nm: ratio(S) for nm, S in CLS}
r0 = [ratio([0]), ratio([31])]
chk('bit', all(v[2] == F(3, 8) for v in rc.values()) and all(v[:2] == (0, 0) for v in r0),
    'each complete SU(5) multiplet among the labels: ' + '; '.join('%s %s / %s = %s' % (nm, fr(v[0]), fr(v[1]), fr(v[2])) for nm, v in rc.items()) + '; the singlets (popcount 0 and 5) give 0 / 0, no ratio')
t5 = [T3f(1 << i) for i in range(5)]; q5 = [Qf(1 << i) for i in range(5)]       # the weights of the 5 (one bit set)
t24 = sum(((t5[i] - t5[j]) ** 2 for i in range(5) for j in range(5) if i != j), F(0)); q24 = sum(((q5[i] - q5[j]) ** 2 for i in range(5) for j in range(5) if i != j), F(0))
chk('bit', (t24, q24, t24 / q24) == (F(5), F(40, 3), F(3, 8)) and sum(t5) == 0 and sum(q5) == 0,
    'the adjoint 24 of su(5) (weights q_i - q_j of the five one-bit labels, four zero weights): Tr T3^2 = %s, Tr Q^2 = %s, ratio %s; T3 and Q are traceless on the 5' % (fr(t24), fr(q24), fr(t24 / q24)))
STATES = [('u_L', F(2, 3), F(1, 2), 3), ('d_L', F(-1, 3), F(-1, 2), 3), ('u_R^c', F(-2, 3), F(0), 3), ('d_R^c', F(1, 3), F(0), 3),
          ('nu_L', F(0), F(1, 2), 1), ('e_L', F(-1), F(-1, 2), 1), ('e_R^c', F(1), F(0), 1), ('nu_R^c', F(0), F(0), 1)]
def ratio_std(names):
    t = sum((m * T3 ** 2 for nm, Q, T3, m in STATES if nm in names), F(0)); q = sum((m * Q ** 2 for nm, Q, T3, m in STATES if nm in names), F(0))
    return t, q, (t / q if q else None)
s16 = ratio_std({s[0] for s in STATES}); s10 = ratio_std({'u_L', 'd_L', 'u_R^c', 'e_R^c'}); s5b = ratio_std({'d_R^c', 'nu_L', 'e_L'})
chk('std', s16 == (F(2), F(16, 3), F(3, 8)) and s10[2] == s5b[2] == F(3, 8),
    'textbook charges (Q, T3) of one generation by hand: Tr T3^2 = %s, Tr Q^2 = %s, ratio %s; the 10 (Q_L, u_R^c, e_R^c) %s / %s and the 5-bar (d_R^c, L) %s / %s, both 3/8' % (fr(s16[0]), fr(s16[1]), fr(s16[2]), fr(s10[0]), fr(s10[1]), fr(s5b[0]), fr(s5b[1])))
chk('bit==std', r16 == s16 and rc['10 (popcount 2)'] == s10 and rc['5-bar (popcount 4)'] == s5b, 'the label sums equal the textbook sums: (2, 16/3) over the 16, (3/2, 4) over the 10, (1/2, 4/3) over the 5-bar')
ra1 = ratio([x for x in EVEN if a_of(x) == 1]); rq = ratio([x for x in EVEN if (a_of(x), b_of(x)) == (1, 1)])
chk('ctl', ra1[2] == F(3, 4) and rq[2] == F(9, 10), 'not a complete SU(5) multiplet: the labels with a = 1 only give %s / %s = %s, Q_L alone %s / %s = %s, not 3/8' % (fr(ra1[0]), fr(ra1[1]), fr(ra1[2]), fr(rq[0]), fr(rq[1]), fr(rq[2])))
# Furey's V: the model and the stored result
OM = load('furey_model', 'reports', 'furey', 'model.py')
Lk, Rk = OM.Lmat(OM.E[3]), OM.Rmat(OM.E[3]); LR = Lk @ Rk; I8 = OM.I8
def proj(P8, second):
    P = np.zeros((16, 16)); P[:8, :8] = P8
    for m in second: P[8 + m, 8 + m] = 1
    return P
PB = {'O1': proj((I8 - LR) / 2, ()), 'O2': proj((I8 + LR) / 2, ()), 'H': proj(0 * I8, (4, 5, 6, 7)), 'C': proj(0 * I8, (1, 2)), 'last': proj(0 * I8, (3, 0))}
omega = OM.diag2(Lk)
Yv = PB['O2'] / 3 + PB['H'] / 2 + PB['C']
cbl = [int(round(np.trace(P))) // 2 for P in PB.values()]
okm = np.allclose(omega @ omega, -np.eye(16)) and all(np.allclose(omega @ P, P @ omega) for P in PB.values()) and np.allclose(sum(PB.values()), np.eye(16)) and cbl == [1, 3, 2, 1, 1]
trCY = F(round(float(np.trace(Yv)) * 6), 6) / 2; dimC = F(16, 2)
chk('std', okm and (trCY, dimC, trCY / dimC) == (F(3), F(8), F(3, 8)) and abs(np.trace(Yv - 3 / 8 * np.eye(16))) < 1e-12,
    'reports/furey/model.py: the five complex projectors (omega = L_e7 with omega^2 = -1 commutes with each; complex ranks %s), Y = P_O2/3 + P_H/2 + P_C: Tr_C Y = %s over dim_C V = %s, ratio %s; Y - (3/8) 1 has trace 0 on V' % (cbl, fr(trCY), fr(dimC), fr(trCY / dimC)))
FR = json.load(open(os.path.join(ROOT, 'furey_results.json')))
FR_KEYS = ['real_blocks', 'real_diag', 'real_off', 'blocks_commuting_with_omega', 'complex_blocks', 'complex_diag', 'complex_off', 'omega_alt_minus_R_works', 'omega_prime_over_omega_minus_axes',
           'centralizers', 'delta_SM_real_dim', 'edges', 'sm_matches', 'sm_generation_dim', 'extras', 'extras_dim', 'maxEdge', 'witt']   # the stored keys: none is a trace of Y
cn = ['C_O(1)', 'C3_O(3)', 'C2_H(2)', 'C_C(1)', 'C_last(1)']
yrel = {e['b']: -F(e['y_a_minus_y_b']) for e in FR['edges'] if e['a'] == cn[0]}; yrel[cn[0]] = F(0)
cons = all(yrel[e['a']] - yrel[e['b']] == F(e['y_a_minus_y_b']) for e in FR['edges'])
trJ = sum((n_ * yrel[c] for n_, c in zip(FR['complex_blocks'], cn)), F(0))
chk('std', FR['complex_blocks'] == [1, 3, 2, 1, 1] and sum(FR['complex_blocks']) == 8 and cons and [yrel[c] for c in cn] == [0, F(1, 3), F(1, 2), 1, 0] and trJ == 3 and sorted(FR) == sorted(FR_KEYS),
    'stored furey_results.json: complex blocks %s, dim_C V = 8; the ten stored differences y_a - y_b fit y = (0, 1/3, 1/2, 1, 0) on the five blocks, and with y = 0 on O1 (Y has no P_O1 term) Tr_C Y = %s; none of its 18 keys is a trace of Y' % (FR['complex_blocks'], fr(trJ)))
chk('bit==std', r16[2] == trCY / dimC and (r16[0], r16[1]) != (trCY, dimC) and sum((Yf(x) for x in EVEN), F(0)) == 0,
    'side by side: (Tr T3^2, Tr Q^2) = (%s, %s) over the 16 labels and (Tr_C Y, dim_C V) = (%s, %s) over Furey\'s V: the same number 3/8 from different traces over different spaces; on the 16 Tr Y = 0, so Tr Y / 16 = 0 there' % (fr(r16[0]), fr(r16[1]), fr(trCY), fr(dimC)))

# ===================================================================================== D. the complement and the Hodge star
head('D. The complement mask x -> x ^ 31 and the Hodge star of Lambda(R^n) (u ^ *v = <u, v> vol), n = 1..8; weights, Y and Q for n = 5')
def sigma(S, n): return reorder_sign(S, ((1 << n) - 1) ^ S)          # the sign of the permutation (S, S-bar)
def star_sign(S, n): return 1 if FAULT == 'NOSIGN' else sigma(S, n)
okst, okform, okpar, okw = True, True, True, True
for n in range(1, 9):
    top = (1 << n) - 1; A_ = Alg(sig(n, 0))
    for k in range(n + 1):
        Sk = [S for S in range(1 << n) if pc(S) == k]
        for S in Sk:
            for T in Sk:                                              # e_S ^ *e_T = star_sign(T) e_S ^ e_(T-bar): the engine product of disjoint blades, 0 when they meet
                Tb = top ^ T
                val = 0 if S & Tb else star_sign(T, n) * A_.blade_mul(S, Tb)[0]
                if (S | Tb) != top and val != 0: okst = False
                if val != (1 if S == T else 0): okst = False
            e = sum(i for i in range(n) if (S >> i) & 1) - k * (k - 1) // 2
            if sigma(S, n) != (-1) ** e: okform = False
            if ((pc(top ^ S) % 2) != (pc(S) % 2)) != (n % 2 == 1): okpar = False
            w = [F((S >> i) & 1) - F(k, n) for i in range(n)]; wb = [F(((top ^ S) >> i) & 1) - F(n - k, n) for i in range(n)]
            if wb != [-c for c in w]: okw = False
chk('bit', okst, 'n = 1..8: with *e_S = sigma(S) e_(S-bar), sigma(S) = bitcliff.reorder_sign(S, S-bar), e_S ^ *e_T = <e_S, e_T> vol for all S, T of the same grade (the wedge as the engine product of disjoint blades): the complement mask is the Hodge star after the sign sigma')
chk('bit', okform and okpar and okw, 'n = 1..8: sigma(S) = (-1)^(sum of S - k(k-1)/2) (bits counted from 0); the complement exchanges even and odd grades exactly for odd n; it negates every weight e_S - |S|/n of the Cartan of sl(n)')
tab = {k: ''.join('+' if sigma(S, 5) == 1 else '-' for S in range(32) if pc(S) == k) for k in range(6)}
sym_ok = all(sigma(S, 5) * (-1) ** (pc(S) * (5 - pc(S))) == sigma(S, 5) for S in range(32))
chk('bit', all(pc(x ^ 31) == 5 - pc(x) and (pc(x ^ 31) % 2) != (pc(x) % 2) for x in LAB) and sym_ok,
    'n = 5, the sign table of the star by grade, labels in increasing order: ' + ' | '.join('k=%d %s' % (k, tab[k]) for k in range(6))
    + '; k(5-k) is even for every k, so u ^ *v and *v ^ u give the same table')
h = lambda x: tuple(F((x >> i) & 1) - F(1, 2) for i in range(5))   # weights of so(10): N_i - 1/2
okh = all(h(x ^ 31) == tuple(-c for c in h(x)) for x in LAB) and Counter(h(x) for x in ODD) == Counter(tuple(-c for c in h(x)) for x in EVEN)
okyq = all(Y_true(x ^ 31) == -Y_true(x) and Qf(x ^ 31) == -Qf(x) for x in LAB)
gens55 = fock_cl(5); vol = np.eye(32, dtype=np.int64)
for gm in gens55: vol = vol @ gm
chir = np.array_equal(vol, np.diag([(-1) ** pc(x) for x in LAB])) or np.array_equal(vol, -np.diag([(-1) ** pc(x) for x in LAB]))
chk('bit', okh and okyq and chir,
    'n = 5: the volume element of Cl(5,5) on the Fock space is +-(-1)^popcount, so the even and the odd labels are its two eigenspaces (the 16 and the 16-bar); the complement negates the so(10) weights N_i - 1/2 (the odd weights are the negatives of the even ones), and Y and Q on all 32 labels')
# [std] the star from determinants
def subsets(n, k): return [c for c in itertools.combinations(range(n), k)]
okd, tabs = True, None
for n in range(1, 9):
    for k in range(n + 1):
        Ak, Bk = subsets(n, k), subsets(n, n - k)
        W = np.array([[np.linalg.det(np.eye(n)[list(s) + list(t)]) if not set(s) & set(t) else 0.0 for t in Bk] for s in Ak])
        X = np.linalg.inv(W)                                           # e_S' ^ (sum_T X[T, S] e_T) = delta vol
        Xr = np.rint(X).astype(int)
        if not np.allclose(X, Xr): okd = False; continue
        for j, s in enumerate(Ak):
            comp = tuple(i for i in range(n) if i not in s); S = sum(1 << i for i in s)
            col = Xr[:, j]
            if sorted(col.tolist()) != sorted([0] * (len(Bk) - 1) + [sigma(S, n)]) or col[Bk.index(comp)] != sigma(S, n): okd = False
        if n == 5: tabs = (tabs or {}); tabs[k] = ''.join('+' if Xr[Bk.index(tuple(i for i in range(5) if i not in s)), j] == 1 else '-' for j, s in sorted(enumerate(Ak), key=lambda js: sum(1 << i for i in js[1])))
chk('std', okd, 'n = 1..8: the matrix of the star defined by u ^ *v = <u, v> vol, built as the inverse of the determinant pairing W[S, T] = det(e_S, e_T) (numpy), sends e_S to sigma(S) e_(S-bar), with integer entries')
chk('bit==std', tabs == tab and okst and okd, 'the sign table of the determinant route equals the bit route for n = 5, grade by grade (and the matrices agree for n = 1..8): the sign convention that makes the complement the star is sigma(S) = sign of the permutation (S, S-bar)')
okns = True
for n in range(2, 9):
    top = (1 << n) - 1; A_ = Alg(sig(n, 0))
    if all((0 if S & (top ^ S) else A_.blade_mul(S, top ^ S)[0]) == 1 for S in range(1 << n)): okns = False
chk('ctl', okns, 'the complement without the sign (e_S -> e_(S-bar)) fails u ^ *v = <u, v> vol for every n = 2..8: the sign is needed')

# ===================================================================================== E. compact and split
head('E. Compact and split: the Killing form of the bivectors of Cl(0,10) and Cl(5,5) (engine structure constants) and the invariant forms on the 32')
sys.path.insert(0, os.path.join(SELF, 'gravity'))
import b1lib                                                        # the engine of selfcheck/gravity_selfcheck.py, found by b1lib from its own folder
sq_c = (-1,) * 10; sq_s = (1,) * 4 + (-1,) * 6 if FAULT == 'SPLIT46' else (1,) * 5 + (-1,) * 5
kc, dc = b1lib.killing_signature(b1lib.Lie(sq_c)); ks, ds = b1lib.killing_signature(b1lib.Lie(sq_s))
chk('bit', kc == (0, 45, 0) and ks == (25, 20, 0) and dc and ds, 'the engine (gravity_selfcheck.Lie, b1lib.killing_signature): the Killing form tr(ad X ad Y) of the 45 bivectors is diagonal in the bivector basis, so its signs are exact: Cl(0,10) %s, Cl(5,5) %s (positive, negative, zero)' % (kc, ks))
ks46, _ = b1lib.killing_signature(b1lib.Lie((1,) * 4 + (-1,) * 6))
chk('ctl', ks46 == (24, 21, 0) and ks46 != (25, 20, 0), 'the signature (4,6) in place of (5,5) gives %s: the check sees the signature' % (ks46,))
def so_basis(eta):
    n = len(eta); out = []
    for a in range(n):
        for b in range(a + 1, n):
            X = np.zeros((n, n)); X[a, b] = eta[b]; X[b, a] = -eta[a]; out.append(X)
    return out
def kill_std(eta):
    B = so_basis(eta); eta_m = np.diag(eta)
    ok = all(np.allclose(X.T @ eta_m + eta_m @ X, 0) for X in B)
    K = np.array([[8 * np.trace(X @ Y) for Y in B] for X in B]); ev = np.linalg.eigvalsh(K)
    return (int((ev > 1e-9).sum()), int((ev < -1e-9).sum()), int((abs(ev) <= 1e-9).sum())), ok
kcs, okc = kill_std((1.0,) * 10); kss, oks = kill_std((1.0,) * 5 + (-1.0,) * 5)
chk('std', okc and oks and kcs == (0, 45, 0) and kss == (25, 20, 0), 'vector representation (numpy): so(10) and so(5,5) as X^T eta + eta X = 0, Killing form 8 tr(XY): eigenvalue signs %s and %s' % (kcs, kss))
chk('bit==std', (kc, ks) == (kcs, kss), 'the Killing signatures of the engine equal those of the vector representation: compact (0,45,0), split (25,20,0)')
# the Fock modules
A5f = [A.astype(float) for A in A5]
gens_c = [(A + A.T) * (1 if FAULT == 'REALC' else 1j) for A in A5f] + [(A - A.T) + 0j for A in A5f]     # Cl(0,10): i E_i and F_i
gens_r = fock_cl(5)                                                                                   # Cl(5,5): E_i and F_i (integers)
BIV10 = [m for m in range(1024) if pc(m) == 2]
rc_, rr_ = rho_cache(gens_c, 32), rho_cache(gens_r, 32)
alg_c, alg_r = Alg(sig(0, 10)), Alg(sig(5, 5))
okg = all(np.allclose(g.conj().T, -g) and np.allclose(g @ g, -np.eye(32)) for g in gens_c)
okp = all(np.allclose(rc_(a) @ rc_(b), alg_c.blade_mul(a, b)[0] * rc_(a ^ b)) for a in BIV10 for b in BIV10)
okr = all(np.array_equal(rr_(a) @ rr_(b), alg_r.blade_mul(a, b)[0] * rr_(a ^ b)) for a in BIV10 for b in BIV10)
chk('bit', okg and okp and okr, 'Cl(0,10) on C^32: i E_i (E_i = a_i + a_i^+) and F_i = a_i - a_i^+ are all anti-Hermitian with square -1, and the 45 bivectors multiply by the bit rule of Alg(sig(0, 10)) (45^2 pairs); the real Fock matrices do the same for Alg(sig(5, 5))')
def monomial(M):
    """M e_y = ph[y] e_p[y] with ph in {1, i, -1, -i} written as a power of i; None if M is not monomial"""
    p, k = [], []
    for y in range(M.shape[1]):
        nz = np.nonzero(np.abs(M[:, y]) > 1e-9)[0]
        if len(nz) != 1: return None
        v = complex(M[nz[0], y]); kk = {1: 0, 1j: 1, -1: 2, -1j: 3}.get(complex(round(v.real), round(v.imag)))
        if kk is None: return None
        p.append(int(nz[0])); k.append(kk)
    return p, k
def invariant_space(rhos, N=32):
    """exact solutions X of X rho + rho^+ X = 0 for all rho: per equation X[p(x), y] = -ph(x) ph(y) X[x, p(y)]; a signed graph on the N^2 unknowns
    (phases as powers of i, union-find); returns the basis matrices (one per consistent component, entries powers of i) as complex arrays"""
    parent = list(range(N * N)); ph = [0] * (N * N); zero = set()
    def find(u):
        if parent[u] == u: return u, 0
        r, k = find(parent[u]); parent[u] = r; ph[u] = (ph[u] + k) % 4; return r, ph[u]
    for M in rhos:
        mono = monomial(M)
        if mono is None: raise SystemExit('a bivector matrix is not monomial')
        p, k = mono
        for x in range(N):
            for y in range(N):
                u1, u2 = x * N + p[y], p[x] * N + y
                phi = (2 + k[x] + k[y]) % 4                              # X[u2] = i^phi X[u1]   (-ph(y) / conj(ph(x)) = -ph(x) ph(y))
                r1, k1 = find(u1); r2, k2 = find(u2)
                if r1 == r2:
                    if (k1 + phi - k2) % 4: zero.add(r1)
                else:
                    parent[r2] = r1; ph[r2] = (k1 + phi - k2) % 4
                    if r2 in zero: zero.add(r1)
    comps = {}
    for u in range(N * N):
        r, k = find(u); comps.setdefault(r, []).append((u, k))
    basis = []
    for r, mem in sorted(comps.items()):
        if r in zero: continue
        B = np.zeros((N, N), dtype=complex)
        for u, k in mem: B[u // N, u % N] = 1j ** k
        basis.append(B)
    return basis
basis_c = invariant_space([rc_(m) for m in BIV10])
basis_r = invariant_space([rr_(m).astype(float) for m in BIV10])
Pev = np.diag([1.0 if pc(x) % 2 == 0 else 0.0 for x in LAB]); Pod = np.eye(32) - Pev
def realvec(Ms): return [np.concatenate([M.real.ravel(), M.imag.ravel()]) for M in Ms]
def rank_real(Ms): return int(np.linalg.matrix_rank(np.array(realvec(Ms)), tol=1e-9)) if Ms else 0
herm_c = [(B + B.conj().T) / 2 for B in basis_c] + [(B - B.conj().T) / 2j for B in basis_c]
dim_hc = rank_real(herm_c)
inv = lambda X, rhos: max(np.abs(X @ R + R.conj().T @ X).max() for R in rhos)
span_c = rank_real(herm_c + [Pev, Pod]) == dim_hc
chk('bit', len(basis_c) == 2 and dim_hc == 2 and span_c and inv(np.eye(32), [rc_(m) for m in BIV10]) == 0,
    'Cl(0,10): the invariant Hermitian forms on C^32 (exact solution space over the 45 bivectors) have real dimension %d and are a P_even + b P_odd; the identity is one of them: positive definite, and on each chirality block (the 16) the invariant form is unique up to a real factor' % dim_hc)
sym_r = [(B + B.T).real for B in basis_r]; ant_r = [(B - B.T).real for B in basis_r]
dsym = rank_exact([np.rint(M).astype(int).ravel().tolist() for M in sym_r]) if sym_r else 0
dant = rank_exact([np.rint(M).astype(int).ravel().tolist() for M in ant_r]) if ant_r else 0
X0 = next((M for M in sym_r if np.abs(M).max() > 0), np.zeros((32, 32)))
ev0 = np.linalg.eigvalsh(X0); sig0 = (int((ev0 > 1e-9).sum()), int((ev0 < -1e-9).sum()), int((abs(ev0) <= 1e-9).sum()))
supp = all((abs(X0[x, y]) > 0) == (y == x ^ 31) for x in LAB for y in LAB)
herm_r = [(B + B.conj().T) / 2 for B in basis_r] + [(B - B.conj().T) / 2j for B in basis_r]
dim_hr = rank_real(herm_r); traceless = all(abs(np.trace(H)) < 1e-12 for H in herm_r)
chk('bit', len(basis_r) == 2 and dsym == 1 and dant == 1 and sig0 == (16, 16, 0) and supp and dim_hr == 2 and traceless,
    'Cl(5,5): the invariant bilinear forms of the real 32 (exact) are one symmetric and one antisymmetric form; the symmetric one pairs x only with x ^ 31 (the complement) and has signature %s; the invariant Hermitian forms of the complexified 32 have real dimension %d and trace 0: no invariant positive-definite form, real or Hermitian' % (sig0, dim_hr))
sgnX0 = [int(np.sign(X0[x ^ 31, x])) for x in LAB]
rev = lambda x: (-1) ** (pc(x) * (pc(x) - 1) // 2)                    # the reversion sign of a blade of grade k
rel_star = Counter(sgnX0[x] * sigma(x, 5) for x in LAB); rel_rev = Counter(sgnX0[x] * sigma(x, 5) * rev(x) for x in LAB)
chk('bit', len(rel_star) == 2 and len(rel_rev) == 1,
    'Cl(5,5): the invariant symmetric form is X0[x ^ 31, x] = c sigma(x) (-1)^(k(k-1)/2) for one constant c on all 32 labels: the Hodge star of the reversed blade, not the star itself (X0 sign / star sign = %s over the labels)' % dict(rel_star))
# [std] Kronecker matrices and the numpy nullspace
gk = gammas(5); gc = [1j * m for m in gk]                                            # compact: anti-Hermitian, square -1
XR = np.array([[0, 1], [1, 0]], dtype=float); ZR = np.diag([1.0, -1.0]); ER = np.array([[0, 1], [-1, 0]], dtype=float); IR = np.eye(2)
def kron_r(ms):
    out = np.ones((1, 1))
    for m in ms: out = np.kron(out, m)
    return out
gs_ = [kron_r([ZR] * j + [XR] + [IR] * (4 - j)) for j in range(5)] + [kron_r([ZR] * j + [ER] + [IR] * (4 - j)) for j in range(5)]
okk = all(np.allclose(gs_[i] @ gs_[j] + gs_[j] @ gs_[i], 2 * np.eye(32) * (i == j) * (1 if i < 5 else -1)) for i in range(10) for j in range(10))
bc_ = [gc[a] @ gc[b] for a in range(10) for b in range(a + 1, 10)]; bs_ = [gs_[a] @ gs_[b] for a in range(10) for b in range(a + 1, 10)]
def null_std(rhos):
    N = rhos[0].shape[0]; I_ = np.eye(N); G = np.zeros((N * N, N * N), dtype=complex)
    for r in rhos:                                                      # L = I (x) r^T + r^+ (x) I on row-major vec(X); G = sum L^+ L
        G += np.kron(I_, r.conj() @ r.T) + np.kron(r.conj().T, r.conj()) + np.kron(r, r.T) + np.kron(r @ r.conj().T, I_)
    ev, V = np.linalg.eigh(G)
    return [V[:, i].reshape(N, N) for i in range(len(ev)) if ev[i] < 1e-9]
nc, ns = null_std(bc_), null_std(bs_)
hc = [(X + X.conj().T) / 2 for X in nc] + [(X - X.conj().T) / 2j for X in nc]
hs = [(X + X.conj().T) / 2 for X in ns] + [(X - X.conj().T) / 2j for X in ns]
Gam5 = np.eye(32, dtype=complex)
for m in gk: Gam5 = Gam5 @ m
Gam5 = Gam5 if np.allclose(Gam5 @ Gam5, np.eye(32)) else 1j * Gam5
Pp = (np.eye(32) + Gam5) / 2; Pm = (np.eye(32) - Gam5) / 2
chk('std', okk and len(nc) == 2 and rank_real(hc) == 2 and rank_real(hc + [Pp, Pm]) == 2 and inv(np.eye(32), bc_) < 1e-12,
    'Kronecker gamma matrices (numpy): compact so(10) on C^32: the nullspace of the 45 equations (Kronecker Gram matrix, eigenvalues below 1e-9) has complex dimension %d, spanned by the two chirality projectors; the identity is invariant: positive definite' % len(nc))
syms = [np.real(X + X.T) for X in ns] + [np.imag(X + X.T) for X in ns]
syms = [M for M in syms if np.abs(M - M.T).max() < 1e-9 and np.abs(M).max() > 1e-6]
dsym_s = int(np.linalg.matrix_rank(np.array([M.ravel() for M in syms]), tol=1e-6)) if syms else 0
evs = np.linalg.eigvalsh(syms[0] / np.abs(syms[0]).max()) if syms else np.zeros(32)
sig_s = (int((evs > 1e-6).sum()), int((evs < -1e-6).sum()), int((abs(evs) <= 1e-6).sum()))
chk('std', len(ns) == 2 and rank_real(hs) == 2 and all(abs(np.trace(H)) < 1e-9 for H in hs) and dsym_s == 1 and sig_s == (16, 16, 0) and inv(np.eye(32), bs_) > 0.5,
    'real Kronecker matrices for Cl(5,5) (five symmetric, five antisymmetric): the invariant Hermitian forms have real dimension %d and trace 0 (a positive-definite matrix has positive trace), the real symmetric ones dimension %d with signature %s; the identity is not invariant' % (rank_real(hs), dsym_s, sig_s))
evens = [S for S in range(1024) if pc(S) % 2 == 0]
def gprod(gl, S):
    M = np.eye(32, dtype=complex)
    for k in range(10):
        if (S >> k) & 1: M = M @ gl[k]
    return M
H0 = np.diag(np.arange(1.0, 33.0))
Hc = sum(gprod(gc, S).conj().T @ H0 @ gprod(gc, S) for S in evens) / len(evens)
Hs = sum(gprod(gs_, S).conj().T @ H0 @ gprod(gs_, S) for S in evens) / len(evens)
chk('std', inv(Hc, bc_) < 1e-9 and np.linalg.eigvalsh(Hc).min() > 0.5, 'compact: the average of a positive form diag(1..32) over the 1024 elements +-g_S (S even) is invariant under the 45 bivectors and positive definite')
chk('ctl', inv(Hs, bs_) > 0.5 and np.linalg.eigvalsh(Hs).min() > 0.5, 'split: the same average over the finite group of the even products of the real matrices is positive definite but NOT invariant under so(5,5) (residual %.3g): the finite group lies in a compact subgroup, so averaging decides nothing for the split form' % inv(Hs, bs_))
pd_bit = (inv(np.eye(32), [rc_(m) for m in BIV10]) == 0, inv(np.eye(32), [rr_(m).astype(float) for m in BIV10]) == 0); pd_std = (inv(np.eye(32), bc_) < 1e-12, inv(np.eye(32), bs_) < 1e-12)
chk('bit==std', (len(basis_c), dim_hc) == (len(nc), rank_real(hc)) and (len(basis_r), dim_hr, dsym, sig0) == (len(ns), rank_real(hs), dsym_s, sig_s) and pd_bit == pd_std == (True, False),
    'the bit route (Fock matrices, exact signed graph) and the standard route (Kronecker matrices, numpy) agree: compact 2 Hermitian forms, the identity invariant; split 1 symmetric form of signature (16,16,0), 2 Hermitian forms, the identity not invariant')

finish(STEP)
