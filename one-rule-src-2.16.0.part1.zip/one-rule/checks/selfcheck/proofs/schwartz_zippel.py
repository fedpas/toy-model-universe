#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""schwartz_zippel.py: the Schwartz-Zippel bound behind every identity the Atlas checks on random polynomial fields, checked exhaustively at
small sizes, its textbook induction run as a finite recursion, and the bounds printed by ten rows recomputed from what the scripts compute.
      python3 schwartz_zippel.py [--fault TIGHT|NOREJ|SEEDS2|DEGLOW]

The lemma (Schwartz; Zippel; recalled for every n, d, S): a non-zero polynomial of total degree d vanishes at a uniformly random point of
S^n with probability at most d/|S|, and N independent points multiply the bound.  The evidence class it gives: a randomised identity is a
statement checked on random polynomial fields whose failure probability is bounded by the lemma; the Atlas prints the bound and lists the
rows that rest on one.
szl·1  The bound, exhaustively.  Over F_p with S = F_p: every non-zero polynomial of total degree <= d in n variables has at most deg(P) p^(n-1)
       zeros, for (p, n, d) = (3,1,1..2), (3,2,1..2), (3,3,1..2), (3,4,1), (5,1,1..4), (5,2,1..2), (5,3,1), (7,2,1..2) (every coefficient
       vector; numpy integer arithmetic mod p); the maximum deg(P) p^(n-1) is reached at every size (the bound is sharp).  Over Q with
       S = {0..s-1}, s = 3, 4: every non-zero polynomial with coefficients in {-1, 0, 1} of degree <= 3 (n = 1, 2) or <= 2 (n = 3); every
       product of d linear forms with integer coefficients in -2..2 (d <= 3 for n = 1, 2; d <= 2 for n = 3); 200 random polynomials with
       coefficients uniform in -50..50 per (n, d, s), n, d = 1..3, s = 3..5 (seed 1000 n + 100 d + s): zeros on S^n <= deg(P) s^(n-1), with
       equality for prod_{i<d} (x_1 - i).  Independence: for N = 2, 3 points the all-zero N-tuples of S^n number Z^N <= (d s^(n-1))^N
       (enumerated, n = 1, 2, s = 4).
szl·2  The textbook induction as a finite recursion: P = sum_{i<=k} x_1^i P_i(y), P_k != 0.  For every polynomial of szl·1 with n >= 2 (over
       F_p and the {-1,0,1} family over Q): each fibre P(., y) has at most k zeros where P_k(y) != 0 and at most s where P_k(y) = 0, so
       Z(P) <= s Z(P_k) + k (s^(n-1) - Z(P_k)); Z(P_k) <= deg(P_k) s^(n-2) with deg(P_k) <= deg(P) - k; hence Z(P) <= deg(P) s^(n-1).  Every
       inequality is checked on every polynomial; on prod_{i<d} (x_1 - i) the whole chain is an equality.
szl·3  The ten rows.  Every bound printed by EQN-012, EQN-013, GRV-001, GRV-002, GRV-005, GRV-006, GRV-008, GRV-010, INP-044, INP-048 is
       recomputed exactly as max over its n of (D p / (1 - r p))^N, p = 1/(2R + 1), and compared with the printed decimal (<, <= or the
       printed rounding).  [bit] D, R, r, N as the package computes them: gravity_selfcheck.sampling_bounds() (imported; no engine object is
       built) and the bound tables printed by a2b_strong_sampling.py (its two shipped logs, n <= 4 and n = 5), b2_strong.py and a6_strong.py
       (their shipped logs under selfcheck/gravity/logs/, read, not re-run); [std] the same numbers from the row's printed formula;
       [bit==std] one line per row.
szl·4  The tables themselves: every printed combined bound of the four tables is the exact (D p/(1 - r p))^N to the printed digits, every
       per-run bound is below 1, and the engine's sampling_bounds() agrees with the a2b table on the identities they share.
[ctl]  TIGHT (the bound (deg - 1) s^(n-1)), NOREJ (the rejection factor 1/(1 - r p) dropped), SEEDS2 (N = 2 in place of 3), DEGLOW (the
       degree 8n - 4 in place of 8n - 3 for the Einstein-tensor identity).
No Forms, Lie or Grav object of the gravity engine is built: its eight engine faults do not apply; the controls are the faults above.
Command: python3 schwartz_zippel.py   (from this folder, or python3 selfcheck/proofs/schwartz_zippel.py from the root of the checks; numpy)."""
import os, sys, re, time, random, itertools
from fractions import Fraction as Fr
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); SELF = os.path.dirname(HERE); LOGS = os.path.join(SELF, 'gravity', 'logs')
sys.path.insert(0, SELF)
# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('TIGHT', 'NOREJ', 'SEEDS2', 'DEGLOW')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
STEP = 'SZL' + ('-' + FAULT if FAULT else '')
T0 = time.time()
def bound(deg, s, n): return max(deg - 1, 0) * s ** (n - 1) if FAULT == 'TIGHT' else deg * s ** (n - 1)

# ------------------------------------------------------------------------------------------------ szl·1, szl·2
def monomials(n, d): return [e for e in itertools.product(range(d + 1), repeat=n) if sum(e) <= d]
def setup(n, d, pts):
    mons = monomials(n, d); E = np.array([[int(np.prod([x ** a for x, a in zip(pt, e)])) for e in mons] for pt in pts], dtype=np.int64)
    return mons, E
def family_check(C, mons, E, n, s, mod=None):
    """C: coefficient vectors (rows), E: evaluation matrix on S^n (x_1 slowest).  Returns (ok1, max ratio info, ok2, nrec)"""
    V = C @ E.T
    if mod: V %= mod
    Z = (V == 0).sum(axis=1)
    nz = (C % mod != 0) if mod else (C != 0)
    degs = np.array([sum(e) for e in mons]); deg = np.where(nz, degs[None, :], -1).max(axis=1)
    ok1 = bool(np.all(Z <= np.array([bound(int(g), s, n) for g in deg])))
    reach = {}
    for g in set(int(x) for x in deg):
        reach[g] = int(Z[deg == g].max())
    if n < 2: return ok1, reach, True, 0
    # the recursion on x_1
    e1 = np.array([e[0] for e in mons]); k = np.where(nz, e1[None, :], -1).max(axis=1)
    sub_pts = list(itertools.product(range(s), repeat=n - 1))
    ok2 = True; sn1 = s ** (n - 1)
    fib = (V == 0).reshape(len(C), s, sn1).sum(axis=1)                       # zeros of each fibre P(., y)
    for kk in set(int(x) for x in k):
        rows = np.where(k == kk)[0]
        if len(rows) == 0: continue
        cols = [j for j, e in enumerate(mons) if e[0] == kk]
        Ek = np.array([[int(np.prod([x ** a for x, a in zip(pt, mons[j][1:])])) for j in cols] for pt in sub_pts], dtype=np.int64)
        Pk = C[np.ix_(rows, cols)] @ Ek.T
        if mod: Pk %= mod
        Zk = (Pk == 0).sum(axis=1)
        nzk = (C[np.ix_(rows, cols)] % mod != 0) if mod else (C[np.ix_(rows, cols)] != 0)
        degk = np.where(nzk, np.array([sum(mons[j][1:]) for j in cols])[None, :], -1).max(axis=1)
        fr = fib[rows]
        okf = bool(np.all(np.where(Pk != 0, fr <= kk, fr <= s)))                # each fibre: <= k zeros where P_k(y) != 0
        B1 = s * Zk + min(kk, s) * (sn1 - Zk)
        ok2 &= okf and bool(np.all(Z[rows] <= B1)) and bool(np.all(Zk <= degk * s ** (n - 2))) and bool(np.all(degk + kk <= deg[rows])) \
               and bool(np.all(B1 <= deg[rows] * sn1))
    return ok1, reach, ok2, len(C)
head('szl·1, szl·2  the bound over F_p, exhaustively, and the recursion')
FP = [(3, 1, 2), (3, 2, 2), (3, 3, 2), (3, 4, 1), (5, 1, 4), (5, 2, 2), (5, 3, 1), (7, 2, 2)]
rows1 = []; ok1all = True; ok2all = True; npoly = 0; sharp = True; nrec = 0
for (p, n, d) in FP:
    pts = list(itertools.product(range(p), repeat=n)); mons, E = setup(n, d, pts); m = len(mons)
    C = np.array(list(itertools.product(range(p), repeat=m))[1:], dtype=np.int64)
    ok1, reach, ok2, nr = family_check(C, mons, E, n, p, mod=p)
    ok1all &= ok1; ok2all &= ok2; npoly += len(C); nrec += nr
    sharp &= all(reach.get(g, -1) == g * p ** (n - 1) for g in range(1, d + 1))
    rows1.append('(%d,%d,%d) %d polys' % (p, n, d, len(C)))
chk('std', ok1all, 'szl·1: over F_p every non-zero polynomial of degree <= d has at most deg(P) p^(n-1) zeros on F_p^n: ' + ', '.join(rows1) + ' (%d polynomials, every coefficient vector)' % npoly)
chk('std', sharp, 'szl·1: at every size and every degree g <= d some polynomial has exactly g p^(n-1) zeros: the bound is sharp')
chk('std', ok2all, 'szl·2: the recursion on x_1 holds on all %d polynomials with n >= 2 over F_p: fibre counts, Z(P) <= s Z(P_k) + k (s^(n-1) - Z(P_k)) <= deg(P) s^(n-1), Z(P_k) <= deg(P_k) s^(n-2)' % nrec)
head('szl·1, szl·2  over Q with S = {0..s-1}')
QF = [(1, 3), (2, 3), (3, 2)]; rowsq = []; okq = True; okq2 = True; nq = 0; nqr = 0
for (n, d) in QF:
    for s in (3, 4):
        pts = list(itertools.product(range(s), repeat=n)); mons, E = setup(n, d, pts)
        C = np.array([c for c in itertools.product((-1, 0, 1), repeat=len(mons)) if any(c)], dtype=np.int64)
        ok1, reach, ok2, nr = family_check(C, mons, E, n, s)
        okq &= ok1; okq2 &= ok2; nq += len(C); nqr += nr
        rowsq.append('n=%d d<=%d s=%d: %d' % (n, d, s, len(C)))
chk('std', okq, 'szl·1: every non-zero polynomial with coefficients in {-1,0,1}: zeros on S^n <= deg(P) s^(n-1) (' + '; '.join(rowsq) + ')')
chk('std', okq2, 'szl·2: the recursion on x_1 holds on the %d polynomials with n >= 2 of the {-1,0,1} family' % nqr)
# products of linear forms, as zero masks
okl = True; nl = 0
for n, dmax in ((1, 3), (2, 3), (3, 2)):
    for s in (3, 4):
        pts = list(itertools.product(range(s), repeat=n))
        forms = [f for f in itertools.product(range(-2, 3), repeat=n + 1) if any(f[:n])]
        masks = [sum(1 << i for i, pt in enumerate(pts) if sum(a * x for a, x in zip(f, pt)) + f[n] == 0) for f in forms]
        for d in range(1, dmax + 1):
            for comb in itertools.combinations_with_replacement(range(len(masks)), d):
                mk = 0
                for c in comb: mk |= masks[c]
                nl += 1
                if bin(mk).count('1') > bound(d, s, n): okl = False
chk('std', okl, 'szl·1: every product of d linear forms with integer coefficients in -2..2 (n = 1, 2: d <= 3; n = 3: d <= 2; s = 3, 4): zeros <= d s^(n-1) (%d products)' % nl)
okr = True; nr_ = 0
for n in (1, 2, 3):
    for d in (1, 2, 3):
        for s in (3, 4, 5):
            rng = random.Random(1000 * n + 100 * d + s); pts = list(itertools.product(range(s), repeat=n)); mons, E = setup(n, d, pts)
            C = np.array([[rng.randint(-50, 50) for _ in mons] for _ in range(200)], dtype=np.int64)
            C = C[np.any(C != 0, axis=1)]
            ok1, reach, ok2, _ = family_check(C, mons, E, n, s); okr &= ok1; nr_ += len(C)
chk('std', okr, 'szl·1: %d random polynomials (200 per (n, d, s), n, d = 1..3, s = 3..5, coefficients uniform in -50..50, seed 1000 n + 100 d + s): zeros <= deg(P) s^(n-1)' % nr_)
okx = True; eq = []
for n in (1, 2, 3):
    for s in (3, 4, 5):
        pts = list(itertools.product(range(s), repeat=n))
        for d in range(1, min(3, s) + 1):
            Z = sum(1 for pt in pts if np.prod([pt[0] - i for i in range(d)]) == 0)
            Zk = 0                                                       # P_k = 1 (k = d): no y with P_k(y) = 0
            B1 = s * Zk + min(d, s) * (s ** (n - 1) - Zk)
            okx &= Z == d * s ** (n - 1) and Z <= bound(d, s, n) and (n == 1 or Z == B1 == d * s ** (n - 1))
chk('std', okx, 'szl·1, szl·2: prod_{i<d} (x_1 - i) has exactly d s^(n-1) zeros on S^n (n = 1..3, s = 3..5, d <= 3): the extremal case reaches the bound, and for n >= 2 the recursion bound s Z(P_k) + k (s^(n-1) - Z(P_k)) equals it')
chk('ctl', all(sum(1 for pt in itertools.product(range(4), repeat=2) if np.prod([pt[0] - i for i in range(d)]) == 0) > (d - 1) * 4 for d in (1, 2, 3)),
    'szl·1: the bound (d - 1) s^(n-1) fails on prod_{i<d} (x_1 - i) (n = 2, s = 4, d = 1..3) (TIGHT)')
oki = True
for n in (1, 2):
    s = 4; pts = list(itertools.product(range(s), repeat=n))
    for d in (1, 2, 3):
        zs = [pt for pt in pts if np.prod([pt[0] - i for i in range(d)]) == 0]; Z = len(zs); zset = set(zs)
        for N in (2, 3):
            cnt = sum(1 for tup in itertools.product(pts, repeat=N) if all(t in zset for t in tup))
            oki &= cnt == Z ** N and Fr(cnt, s ** (n * N)) <= Fr(d, s) ** N
chk('std', oki, 'szl·1: independence: the all-zero N-tuples of S^n number Z^N, so the probability is (Z/s^n)^N <= (d/s)^N (N = 2, 3; n = 1, 2; s = 4; enumerated)')

# ------------------------------------------------------------------------------------------------ szl·3, szl·4 the ten rows
head('szl·3  the bounds printed by the ten rows, recomputed')
def read_table(fname, kind):
    out = {}
    path = os.path.join(LOGS, fname)
    with open(path, encoding='utf-8') as fh:
        lines = fh.read().splitlines()
    if kind == 'a2b':
        pat = re.compile(r'^  (\S.*?)\s+(\d+) (\d+) \(([^)]*)\)\s+(\d+)\s+1/(\d+)\s+(\d+)\s+([0-9.e+-]+)\s+(\S+)\s+N = (\d+)$')
        for L in lines:
            m = pat.match(L)
            if m:
                name, n, D, src, R, den, r, per, comb, N = m.groups()
                out[(name.strip(), int(n), int(R))] = dict(D=int(D), r=int(r), N=int(N), comb=comb, per=per)
    else:
        pat = re.compile(r'^  (\S.*?)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+([0-9.e+-]+)\s+([0-9.e+-]+)$')
        for L in lines:
            m = pat.match(L)
            if m:
                name, n, D, R, r, N, per, comb = m.groups()
                out[(name.strip(), int(n), int(R))] = dict(D=int(D), r=int(r), N=int(N), comb=comb, per=per)
    return out
TAB = {'a2b': read_table('a2b_strong_sampling.log', 'a2b'), 'a2b5': read_table('a2b_strong_sampling_n5.log', 'a2b'),
       'b2': read_table('b2_strong.log', 'b'), 'a6': read_table('a6_strong.log', 'b')}
import gravity_selfcheck as GS
SB = GS.sampling_bounds()
def entry(name, n, R):
    for key in ('a2b', 'a2b5', 'b2', 'a6'):
        e = TAB[key].get((name, n, R))
        if e is not None: return key, e
    return None, None
def exact(D, R, r, N):
    p = Fr(1, 2 * R + 1); return (D * p / (1 - r * p)) ** N
BIANCHI = ['I1', 'I2', 'I3a', 'I3b', 'I4']
A6FORMS = ['Euler: k(R,R) = d CS, fit (1, 1/6), k(Q,Q) = 0; x-degree 1', 'Pontryagin: k(R,R) = d CS, fit (1, 1/6), k(Q,Q) = 0; x-degree 1',
           'Nieh-Yan d(e^a T_a) = T^a T_a - e^a e^b R_ab, fit (1, -1); x-degree 1', 'Holst e^a e^b R_ab = e_a D T^a; x-degree 1']
A6MM = ['MM: eps R R = d CS_E; eps F F expansion; eps F F - d CS_E = 8c L_R + 24 c^2 vol']
DEG8 = (lambda n: 8 * n - 4) if FAULT == 'DEGLOW' else (lambda n: 8 * n - 3)
RJ = (lambda n: 0) if FAULT == 'NOREJ' else (lambda n: n)
NS = 2 if FAULT == 'SEEDS2' else 3
# (label, names, ns, R, D(n), r(n), comparator, printed decimal, also check sampling_bounds names)
B3 = ('(3/101)^3', BIANCHI, (3, 4, 5), 50, lambda n: 3, lambda n: 0)
BN = ('(n/101)^3', ['I5 c=0', 'I5 c=1'], (3, 4, 5), 50, lambda n: n, lambda n: 0)
ROWS = {
 'EQN-012': [B3 + ('=', None)],
 'EQN-013': [BN + ('=', None)],
 'GRV-001': [B3 + ('<', '3e-5')],
 'GRV-002': [B3 + ('<', '3e-5')],
 'GRV-005': [('(n/101)^3', ['B1 EC'], (3, 4, 5), 50, lambda n: n, lambda n: 0, '<', '1.3e-4'),
             ('(4/101)^3', ['B1 MM'], (4,), 50, lambda n: 4, lambda n: 0, '=', None),
             ('(4/101)^3', ['B1 MM'], (4,), 50, lambda n: 4, lambda n: 0, '~', '6.2e-5')],
 'GRV-006': [('((2n+1)/(101-n))^3', ['A3 T=0'], (2, 3, 4, 5, 6), 50, lambda n: 2 * n + 1, RJ, '<=', '2.6e-3'),
             ('the same at R = 500', ['A3 T=0'], (5, 6), 500, lambda n: 2 * n + 1, RJ, '<=', '2.3e-6'),
             ('degree 3n', ['A3 omega=LC'], (3, 4, 5), 50, lambda n: 3 * n, RJ, '<', '3.9e-3')],
 'GRV-008': [BN + ('<', '1.3e-4'),
             ('((n+2)/101)^3', ['N, N = xi^a einstein_rhs_a, the chain'], (3, 4), 50, lambda n: n + 2, lambda n: 0, '<=', '2.1e-4')],
 'GRV-010': [('((8n-3)/(1001-n))^3', ['A4'], (3, 4, 5), 500, DEG8, RJ, '<=', '5.2e-5'),
             ('(4/101)^3', A6MM, (4,), 50, lambda n: 4, lambda n: 0, '<', '6.3e-5')],
 'INP-044': [B3 + ('<', '3e-5'),
             ('(4/101)^3', A6FORMS, (4,), 50, lambda n: 4, lambda n: 0, '<', '6.3e-5'),
             ('(18/(1001-4))^3', ['T = 0: Holst = 0 at the point'], (4,), 500, lambda n: 18, RJ, '<', '5.9e-6')],
 'INP-048': [BN + ('<', '1.3e-4'),
             ('((8n-3)/(1001-n))^3', ['A4'], (3, 4, 5), 500, DEG8, RJ, '<=', '5.2e-5'),
             ('(4/101)^3', A6MM, (4,), 50, lambda n: 4, lambda n: 0, '<', '6.3e-5')],
}
for row, specs in ROWS.items():
    okb = True; oks = True; parts = []
    for (label, names, ns, R, Df, rf, cmp, dec) in specs:
        mx = Fr(0); found = 0
        for n in ns:
            want = exact(Df(n), R, rf(n), NS); mx = max(mx, want)
            for nm in names:
                key, e = entry(nm, n, R)
                if e is None: okb = False; continue
                found += 1
                if (e['D'], e['r'], e['N']) != (Df(n), rf(n), NS): okb = False
        if names is BIANCHI:
            sb = SB['bounds'].get('bianchi, covariance, spinor commutator (n = 3, 4, 5)')
            okb &= sb is not None and sb['degree'] == 3 and SB['coefficient_range'] == R and SB['fields_per_case'] == NS
        if names == BN[1]:
            for n in ns:
                sb = SB['bounds'].get('D E_a = torsion terms, n = %d' % n)
                okb &= sb is not None and sb['degree'] == n and SB['fields_per_case'] == NS
        if cmp == '<': oks &= mx < Fr(dec)
        elif cmp == '<=': oks &= mx <= Fr(dec)
        elif cmp == '~':
            exp = Fr(10) ** (int(dec.split('e')[1]) - 1); oks &= abs(mx - Fr(dec)) <= exp / 2
        parts.append('%s %s %s (max %.3e over n = %s; %d table entries)' % (label, cmp if dec else '', dec or '', float(mx), ','.join(map(str, ns)), found))
    chk('bit==std', okb and oks, 'szl·3: %s: %s; D, R, r, N of the tables = the printed formula%s' % (row, '; '.join(parts), '' if oks else ' (a printed decimal is not met)'))
p_ = Fr(1, 101)
chk('ctl', Fr(13, 101) ** 3 != Fr(13, 95) ** 3 and TAB['a2b'][('A3 T=0', 6, 50)]['r'] == 6, 'szl·3: without the rejection factor GRV-006 would read (13/101)^3 = %.3e at n = 6, not the computed (13/95)^3 = %.3e: the table has r = 6 (NOREJ)' % (float(Fr(13, 101) ** 3), float(Fr(13, 95) ** 3)))
chk('ctl', (Fr(3, 101)) ** 2 > Fr(3, 10 ** 5), 'szl·3: with two fields the Bianchi bound is (3/101)^2 = %.2e, above the printed 3e-5: the three seeds are needed (SEEDS2)' % float(Fr(3, 101) ** 2))
chk('ctl', TAB['a2b'][('A4', 4, 500)]['D'] == 29 != 8 * 4 - 4, 'szl·3: the A4 table has D = 29 = 8n - 3 at n = 4; the degree 8n - 4 = 28 is not what the script counts (DEGLOW)')
head('szl·4  the tables are self-consistent')
okt = True; nt = 0; worst = 0.0
for key, T in TAB.items():
    for (name, n, R), e in T.items():
        ex = exact(e['D'], R, e['r'], e['N']); per = e['D'] * Fr(1, 2 * R + 1) / (1 - e['r'] * Fr(1, 2 * R + 1))
        if e['comb'] == '-': continue
        pr = float(e['comb']); digits = len(e['comb'].split('e')[0].split('.')[1]) if '.' in e['comb'] else 0
        tol = 10 ** (int(e['comb'].split('e')[1]) - digits); err = abs(pr - float(ex)); worst = max(worst, err / tol)
        okt &= err <= tol and per < 1; nt += 1
chk('bit', okt and nt >= 60, 'szl·4: the %d rows of the four tables (a2b n <= 4 and n = 5, b2_strong, a6_strong): printed combined bound = exact (D p/(1 - r p))^N to the printed digits (worst %.2f of a unit), every per-run bound < 1' % (nt, worst))
oksb = all(TAB['a2b'][('I1', n, 50)]['D'] == SB['bounds']['bianchi, covariance, spinor commutator (n = 3, 4, 5)']['degree'] for n in (3, 4)) and \
       all(entry('I5 c=0', n, 50)[1]['D'] == SB['bounds']['D E_a = torsion terms, n = %d' % n]['degree'] for n in (3, 4, 5)) and \
       SB['point_mass'] == '1/101' and SB['fields_per_case'] == 3
chk('bit', oksb, 'szl·4: gravity_selfcheck.sampling_bounds() (R = %d, point mass %s, %d fields) has the degrees of the a2b table for the Bianchi identities (3) and D E_a (n)' % (SB['coefficient_range'], SB['point_mass'], SB['fields_per_case']))
print('  (total %.1f s)' % (time.time() - T0))
finish(STEP)
