#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""emd_maxwell.py: the Lienard-Wiechert field on the labels, the Larmor flux, and the duality rotation with its degenerate limits.
      python3 emd_maxwell.py [--fault NOACC|ACCSIGN|POWER|PRESENT|NOBEAM|NRLARMOR|BIVROT|DUALSIGN|SOURCE|NONDEG]

Cl(1,3) by the bit masks and the bmul of coupling_selfcheck.py (bit 0 = time, square +1); upper coordinates x^mu = (t, x, y, z);
nabla = sum_mu gamma^mu d/dx^mu (gamma^0 = gamma_0, gamma^k = -gamma_k), the package's nabla; sigma_k = gamma_k gamma_0, I = gamma_0123;
the frame split E = (F - gamma_0 F gamma_0)/2, I B = (F + gamma_0 F gamma_0)/2 (as dirac_limits.py dlim·SPLIT), F = E + I B.  Units: c = 1,
Heaviside-Lorentz, q/(4 pi) = 1 on the labels (the Coulomb field E = x/r^3 of maxwell_selfcheck.py), q = 4 pi on the floats.
1. emd·LW.  Worldlines rationally parametrised: uniform motion z = s v (v = (5/4, 0, 0, 3/4), (13/12, 5/12, 0, 0)); the hyperbolic motion
   z(s) = ((s - 1/s)/(2a), ((s + 1/s)/2 - 1)/a, 0, 0), s = exp(a tau), a = 1, 2 (x(t) = sqrt(1 + t^2) - 1 at a = 1, the hyperbola of
   maxwell_selfcheck.py).  At six rational points per worldline, chosen by a fixed search where the retarded root of (x - z(s))^2 = 0 is
   rational, s is carried as an exact jet (value and first derivatives, Fractions) with d s/d x^mu = X_mu / (X . z'(s)), X = x - z(s).
   [bit] the closed form F = (X ^ v + (1/2) X Omega X)/(X . v)^3, Omega = vdot ^ v (recalled form, Doran and Lasenby) equals nabla ^ A of the
   potential A = v/(X . v), nabla . A = 0, and nabla F = 0 exactly; for uniform motion F also equals the present-position form
   x ^ v/((x . v)^2 - x^2)^(3/2); the advanced root gives nabla F = 0 as well; at v = gamma_0 F = sum_k x^k sigma_k / r^3, the Coulomb field of
   INP-010 at the five points of maxwell_selfcheck.py.
   [std] numpy/scipy: Jackson's velocity and acceleration fields with the retarded time by brentq; Maxwell's four equations by central
   differences; the Gauss flux of E through spheres around the charge at fixed lab time (Gauss-Legendre, 56 x 56) is q, and 0 for a sphere
   that does not contain it.
2. emd·LARM.  [bit] hyperbolic motion, retarded event s = 1 (v = gamma_0, vdot = a gamma_1), a = 1/2, 1, 2: on the light-cone sphere
   x = R(gamma_0 + n) (12 rational directions n, R = 1, 10, 1000) the retarded root is exactly s = 1, B = n x E and R^2 (E x B) . n =
   a^2 (1 - (n . x^)^2) exactly; the polynomial integral 2 pi int_{-1}^{1} (1 - c^2) dc = 8 pi/3 gives (2/3) q^2 a^2/(4 pi).  [std] scipy
   quad of int R^2 (S . n)(1 - n . beta) dOmega at R = 10^6/a for retarded events with beta = 0, 3/5, -4/5.  The Abraham-Lorentz-Dirac
   four-force (2/3)(q^2/4 pi)(vddot + vdot^2 v) (recalled) evaluated on the hyperbolic worldline is 0 exactly at five s.
3. emd·DUAL.  [bit] I^2 over Cl(p,q,r), p + q + r = 4; I commutes with bivectors and anticommutes with vectors, so
   nabla(exp(I theta) F) = exp(-I theta) nabla F; three random polynomial vacuum solutions (degree <= 2, the exact null space of nabla) stay
   solutions under exp(I theta) at (cos, sin) = (3/5, 4/5), (5/13, 12/13), (8/17, -15/17); with a source (F = nabla ^ A, three random A) the
   rotated field has the grade-3 source -sin theta I J; (E, B) -> (E cos - B sin, E sin + B cos); plane waves (E + I B) f(t - k.x),
   B = k x E, k in {(1,2,2)/3, (2,3,6)/7, (0,3,4)/5}: the rotated wave is the plane wave with E turned about k; in Cl(1,2,1) and Cl(0,3,1)
   I^2 = 0, F -> I F has rank 3 and square 0 on the bivectors and exp(I theta) = 1 + theta I.  [std] the Hodge star from the Levi-Civita
   symbol (integers): star = c I on the six bivectors with one sign c, star^2 = -1; the textbook duality formula; Rodrigues rotations.
Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL):
   NOACC  the velocity field only;  ACCSIGN  -(1/2) X Omega X;  POWER  (X . v)^2;  PRESENT  the parameter at the same lab time (uniform
   motion) in place of the retarded root;  NOBEAM  the flux without (1 - n . beta);  NRLARMOR  (2/3) q^2 (a/gamma^3)^2/(4 pi);  BIVROT
   exp(gamma_12 theta) in place of exp(I theta);  DUALSIGN  E cos + B sin;  SOURCE  the sourced fields in the source-free line;  NONDEG
   Cl(1,3) in the nilpotency line.
Scope: the points, worldlines, radii, angles and samples named above; exact Fractions on [bit], floats with the tolerances printed on [std].
The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults M1-M8 do not reach it; its controls are its own.
Command: python3 emd_maxwell.py   (from this folder, or python3 selfcheck/proofs/emd_maxwell.py from the package root; numpy, scipy)."""
import os, sys, math, random, itertools
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import quad

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
for _p, _f in ((_selfcheck, 'coupling_selfcheck.py'),):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
import coupling_selfcheck as cs

FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOACC', 'ACCSIGN', 'POWER', 'PRESENT', 'NOBEAM', 'NRLARMOR', 'BIVROT', 'DUALSIGN', 'SOURCE', 'NONDEG')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ exact jets and multivectors
class Jet:
    __slots__ = ('v', 'd')
    def __init__(s, v, d): s.v = Fr(v); s.d = tuple(Fr(x) for x in d)
    def _l(s, o): return o if isinstance(o, Jet) else Jet(o, (0,) * len(s.d))
    def __add__(s, o): o = s._l(o); return Jet(s.v + o.v, [a + b for a, b in zip(s.d, o.d)])
    __radd__ = __add__
    def __neg__(s): return Jet(-s.v, [-a for a in s.d])
    def __sub__(s, o): return s + (-s._l(o))
    def __rsub__(s, o): return s._l(o) + (-s)
    def __mul__(s, o):
        if isinstance(o, Jet): return Jet(s.v * o.v, [s.v * b + o.v * a for a, b in zip(s.d, o.d)])
        return Jet(s.v * o, [a * o for a in s.d])
    __rmul__ = __mul__
    def __truediv__(s, o):
        if isinstance(o, Jet): return s * Jet(1 / o.v, [-a / o.v ** 2 for a in o.d])
        return Jet(s.v / o, [a / o for a in s.d])
    def __rtruediv__(s, o): return s._l(o) / s
Z4 = (0, 0, 0, 0)
def isz(v): return (v.v == 0 and all(a == 0 for a in v.d)) if isinstance(v, Jet) else v == 0
SQ = cs.sqs(4)
def mul(a, b, sq=SQ):
    r = {}
    for x, cx in a.items():
        for y, cy in b.items():
            m, s = cs.bmul(x, y, sq)
            if s: r[m] = r.get(m, 0) + s * cx * cy
    return {k: v for k, v in r.items() if not isz(v)}
def add(*ts):
    r = {}
    for t in ts:
        for k, v in t.items(): r[k] = r.get(k, 0) + v
    return {k: v for k, v in r.items() if not isz(v)}
def sc(a, c): return {k: v * c for k, v in a.items() if not isz(v * c)}
def grade(a, k): return {m: v for m, v in a.items() if pc(m) == k}
def val(a): return {k: (v.v if isinstance(v, Jet) else v) for k, v in a.items() if (v.v if isinstance(v, Jet) else v) != 0}
def der(a, mu): return {k: v.d[mu] for k, v in a.items() if isinstance(v, Jet) and v.d[mu] != 0}
def fsqrt(q):
    q = Fr(q); a, b = math.isqrt(q.numerator) if q >= 0 else -1, math.isqrt(q.denominator)
    return Fr(a, b) if q >= 0 and a * a == q.numerator and b * b == q.denominator else None
G0 = {1: Fr(1)}; I4 = {15: Fr(1)}; ONE = {0: Fr(1)}; half = Fr(1, 2)
GUP = [{1: Fr(1)}, {2: Fr(-1)}, {4: Fr(-1)}, {8: Fr(-1)}]
SIG = [None] + [mul({1 << k: Fr(1)}, G0) for k in (1, 2, 3)]
def vec(c): return {1 << mu: c[mu] for mu in range(4) if not isz(c[mu])}
def mdot(a, b): return a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3]
def lower(a): return [a[0], -a[1], -a[2], -a[3]]
def nabla_jet(F): return add(*[mul(GUP[mu], der(F, mu)) for mu in range(4)])
def scal(a): return a.get(0, 0)
def split(F):
    gFg = mul(mul(G0, F), G0); E = sc(add(F, sc(gFg, -1)), half); IB = sc(add(F, gFg), half); B = sc(mul(I4, IB), -1)
    return [scal(mul(E, SIG[k])) for k in (1, 2, 3)], [scal(mul(B, SIG[k])) for k in (1, 2, 3)]
def cross(a, b): return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
def dot3(a, b): return sum(x * y for x, y in zip(a, b))

# ------------------------------------------------------------------------------------------------ worldlines (rational in s)
class Uniform:
    def __init__(s, v): s.v = [Fr(x) for x in v]; s.name = 'uniform v = (%s)' % ', '.join(str(x) for x in s.v)
    def z(s, p): return [p * c for c in s.v]
    def zp(s, p): return list(s.v)
    def vel(s, p): return [Fr(c) + 0 * p for c in s.v]
    def acc(s, p): return [0 * p for _ in range(4)]
    def quad_coef(s, x):                                    # (x - s v)^2 = s^2 - 2 (x.v) s + x^2
        return Fr(1), -2 * mdot(x, s.v), mdot(x, x)
    def ok_root(s, p): return True
class Hyperbolic:
    def __init__(s, a): s.a = Fr(a); s.name = 'hyperbolic a = %s' % s.a
    def z(s, p): a = s.a; return [(p - 1 / p) / (2 * a), ((p + 1 / p) / 2 - 1) / a, 0 * p, 0 * p]
    def zp(s, p): a = s.a; return [(1 + 1 / (p * p)) / (2 * a), (1 - 1 / (p * p)) / (2 * a), 0 * p, 0 * p]
    def vel(s, p): return [(p + 1 / p) / 2, (p - 1 / p) / 2, 0 * p, 0 * p]
    def acc(s, p): a = s.a; return [a * (p - 1 / p) / 2, a * (p + 1 / p) / 2, 0 * p, 0 * p]
    def quad_coef(s, x):                                    # a s (x - z(s))^2 = 0 as A s^2 + B s + C = 0
        a = s.a; t, x1, y, zz = x; x1p = x1 + 1 / a; rho2 = t * t - x1p * x1p - y * y - zz * zz
        return t - x1p, -(a * rho2 - 1 / a), -(t + x1p)
    def ok_root(s, p): return p > 0
def roots(W, x):
    A, B, C = W.quad_coef(x)
    if A == 0: rs = [-C / B] if B != 0 else []
    else:
        d = fsqrt(B * B - 4 * A * C)
        if d is None: return None
        rs = sorted({(-B + d) / (2 * A), (-B - d) / (2 * A)})
    out = {}
    for p in rs:
        if not W.ok_root(p): continue
        X = [xi - zi for xi, zi in zip(x, W.z(p))]
        if mdot(X, X) != 0 or all(c == 0 for c in X): continue
        out['ret' if X[0] > 0 else 'adv'] = p
    return out
def field_at(W, x, which='ret', present=False, variant=None):
    """closed-form F (jets), the potential A (jets), and data at the exact point x"""
    rr = roots(W, x); p0 = rr[which]
    X0 = [xi - zi for xi, zi in zip(x, W.z(p0))]; zp0 = W.zp(p0)
    if present:                                             # the parameter at the same lab time (uniform motion): s = t / v^0
        p0 = x[0] / W.v[0]; ds = [1 / W.v[0], 0, 0, 0]
    else:
        den = mdot(X0, zp0); ds = [c / den for c in lower(X0)]
    s = Jet(p0, ds)
    xs = [Jet(x[mu], [1 if i == mu else 0 for i in range(4)]) for mu in range(4)]
    X = [xs[mu] - zc for mu, zc in enumerate(W.z(s))]
    v = W.vel(s); vd = W.acc(s)
    Xm, vm, vdm = vec(X), vec(v), vec(vd)
    Xv = mdot(X, v)
    if Xv.v == 0: return None
    Xwv = grade(mul(Xm, vm), 2)
    Om = grade(mul(vdm, vm), 2)
    XOX = mul(mul(Xm, Om), Xm)
    acc_c = Fr(0) if variant == 'NOACC' else (-half if variant == 'ACCSIGN' else half)
    powr = Xv * Xv if variant == 'POWER' else Xv * Xv * Xv
    num = add(Xwv, sc(grade(XOX, 2), acc_c))
    F = {k: c / powr for k, c in num.items()}
    Apot = {k: c / Xv for k, c in vm.items()}
    return dict(F=F, A=Apot, XOX_other=val(add(grade(XOX, 0), grade(XOX, 4))), s=p0, X=X0, Xv=Xv.v)

head('1. emd·LW: the Lienard-Wiechert field on the labels, off the worldline [bit]; Jackson fields, Maxwell by differences, Gauss flux [std]')
WORLDS = [Uniform((Fr(5, 4), 0, 0, Fr(3, 4))), Uniform((Fr(13, 12), Fr(5, 12), 0, 0)), Hyperbolic(1), Hyperbolic(2)]
DIRS = [(1, 2, 2, 3), (-2, 1, 2, 3), (2, -2, 1, 3), (2, 3, 6, 7), (-6, 2, 3, 7), (3, -6, 2, 7), (0, 3, 4, 5), (4, 0, -3, 5), (-3, 4, 0, 5), (2, 6, 9, 11), (-9, 2, 6, 11), (6, -9, 2, 11)]
SEEDS = [(Fr(1), Fr(1), 0), (Fr(2), Fr(3, 2), 3), (Fr(1, 2), Fr(2), 6), (Fr(3), Fr(1, 2), 9), (Fr(2, 3), Fr(3), 1), (Fr(5, 2), Fr(5, 4), 4)]
def make_points(W):
    """x = z(s0) + lam (1, n): the retarded parameter is s0 by construction; the solver must find it"""
    out = []
    for s0, lam, di in SEEDS:
        d_ = DIRS[di]; n = [Fr(c, d_[3]) for c in d_[:3]]; z0 = W.z(s0)
        out.append(([z0[0] + lam, z0[1] + lam * n[0], z0[2] + lam * n[1], z0[3] + lam * n[2]], s0))
    return out
PTS = {}; okRoot = True
for W in WORLDS:
    P_ = make_points(W); PTS[W.name] = [x for x, _ in P_]
    okRoot &= all((roots(W, x) or {}).get('ret') == s0 and (x[2], x[3]) != (0, 0) for x, s0 in P_)
chk('bit', okRoot and all(len(p) == 6 for p in PTS.values()), 'six rational points per worldline, x = z(s0) + lam (1, n) with s0 = 1, 2, 1/2, 3, 2/3, 5/2 and rational unit n off the axis: the exact quadratic solver returns the retarded root s0 at each (24 points)')
okF = okA = okL = okO = True; nF = 0; std_pts = []
variant = FAULT if FAULT in ('NOACC', 'ACCSIGN', 'POWER') else None
for W in WORLDS:
    for x in PTS[W.name]:
        present = FAULT == 'PRESENT' and isinstance(W, Uniform)
        d = field_at(W, x, present=present, variant=variant)
        nF += 1
        if d is None: okF = False; continue
        okF &= nabla_jet(d['F']) == {}
        nA = nabla_jet(d['A'])
        okA &= val(grade(nA, 2)) == val(d['F']) or variant is not None or present
        okL &= val(grade(nA, 0)) == {}
        okO &= d['XOX_other'] == {}
        std_pts.append((W, x, d))
chk('bit', okF, 'nabla F = 0 exactly at the %d points (4 worldlines x 6), F = (X ^ v + (1/2) X Omega X)/(X . v)^3, first derivatives by exact jets' % nF)
chk('bit', okA and okL and okO, 'the closed form equals nabla ^ A of the potential A = v/(X . v) at every point; nabla . A = 0 (Lorenz); X Omega X has no grade 0 or 4 part')
okP = True
for W in WORLDS[:2]:
    for x in PTS[W.name]:
        xs = [Jet(x[mu], [1 if i == mu else 0 for i in range(4)]) for mu in range(4)]
        xv = mdot(xs, W.v); Dj = xv * xv - mdot(xs, xs); r0 = fsqrt(Dj.v)
        if r0 is None: continue
        sq_ = Jet(r0, [c / (2 * r0) for c in Dj.d])
        Fpp = {k: c / (Dj * sq_) for k, c in grade(mul(vec(xs), vec(W.v)), 2).items()}
        okP &= val(Fpp) == val(field_at(W, x)['F'])
nPP = sum(1 for W in WORLDS[:2] for x in PTS[W.name] if fsqrt(mdot(x, W.v) ** 2 - mdot(x, x)) is not None)
chk('bit', okP and nPP >= 6, 'uniform motion: the retarded form equals the present-position form x ^ v/((x . v)^2 - x^2)^(3/2) at the %d points where its root is rational' % nPP)
ADV = [(W, x) for W in WORLDS for x in PTS[W.name] if 'adv' in (roots(W, x) or {})]
okAdv = len(ADV) >= 12 and all(nabla_jet(field_at(W, x, which='adv')['F']) == {} for W, x in ADV)
chk('bit', okAdv, 'the advanced root gives nabla F = 0 at the %d of the 24 points where it exists (%d uniform, %d hyperbolic):' % (len(ADV), sum(1 for W, _ in ADV if isinstance(W, Uniform)), sum(1 for W, _ in ADV if isinstance(W, Hyperbolic))) + ' the equation off the worldline does not choose the retarded field (that is the boundary condition, recalled)')
ctl_noacc = all(nabla_jet(field_at(W, x, variant='NOACC')['F']) != {} for W in WORLDS[2:] for x in PTS[W.name])
ctl_sign = all(nabla_jet(field_at(W, x, variant='ACCSIGN')['F']) != {} for W in WORLDS[2:] for x in PTS[W.name])
ctl_pow = all(nabla_jet(field_at(W, x, variant='POWER')['F']) != {} for W in WORLDS for x in PTS[W.name])
PRES = [field_at(W, x, present=True) for W in WORLDS[:2] for x in PTS[W.name]]
ctl_pres = all(d_ is None or nabla_jet(d_['F']) != {} for d_ in PRES) and sum(1 for d_ in PRES if d_ is not None) >= 6
chk('ctl', ctl_noacc and ctl_sign and ctl_pow and ctl_pres, 'nabla F != 0 at every point for: the velocity field alone and the sign -(1/2) X Omega X (hyperbolic, 12 points), (X . v)^2 (24 points), the present parameter in place of the retarded root (uniform, %d points where X . v != 0)' % sum(1 for d_ in PRES if d_ is not None))
COUL_PTS = [(1, 2, 2), (2, 3, 6), (1, 4, 8), (4, 4, 7), (2, 6, 9)]
okC = True
Wst = Uniform((1, 0, 0, 0))
for p_ in COUL_PTS:
    r0 = fsqrt(sum(c * c for c in p_)); x = [r0 + 1, Fr(p_[0]), Fr(p_[1]), Fr(p_[2])]
    d = field_at(Wst, x); E, B = split(val(d['F']))
    okC &= E == [Fr(c) / r0 ** 3 for c in p_] and B == [0, 0, 0] and nabla_jet(d['F']) == {}
chk('bit', okC, 'static limit v = gamma_0: F = sum_k x^k sigma_k / r^3, i.e. E = x/r^3, B = 0, the Coulomb field of INP-010 at the five points of maxwell_selfcheck.py, and nabla F = 0 there')
# std: Jackson's fields
def W_float(W):
    if isinstance(W, Uniform):
        v = np.array([float(c) for c in W.v]); return (lambda tau: v * tau), (lambda tau: v[1:] / v[0]), (lambda tau: np.zeros(3))
    a = float(W.a)
    return (lambda tau: np.array([np.sinh(a * tau) / a, (np.cosh(a * tau) - 1) / a, 0.0, 0.0])), (lambda tau: np.array([np.tanh(a * tau), 0.0, 0.0])), (lambda tau: np.array([a / np.cosh(a * tau) ** 3, 0.0, 0.0]))
def jackson(W, x, accel=True, q=4 * np.pi):
    zf, bf, bdf = W_float(W); x = np.asarray(x, float)
    f = lambda tau: x[0] - zf(tau)[0] - np.linalg.norm(x[1:] - zf(tau)[1:])
    hi = (np.arcsinh(float(W.a) * x[0]) / float(W.a)) if isinstance(W, Hyperbolic) else x[0] / float(W.v[0])
    lo = hi - 1.0
    for _ in range(60):
        if f(lo) > 0: break
        lo -= 2 * (hi - lo)
    else: raise SystemExit('no retarded time: the point lies behind the past horizon of the worldline')
    tr = brentq(f, lo, hi, xtol=1e-15, rtol=1e-15, maxiter=500)
    zz = zf(tr); Rv = x[1:] - zz[1:]; R = np.linalg.norm(Rv); n = Rv / R; b = bf(tr); bd = bdf(tr); g2 = 1.0 / (1.0 - b @ b); k = 1.0 - n @ b
    E = q / (4 * np.pi) * ((n - b) / (g2 * k ** 3 * R ** 2) + (np.cross(n, np.cross(n - b, bd)) / (k ** 3 * R) if accel else 0.0))
    return E, np.cross(n, E)
okJ = True; worst = 0.0
for W, x, d in std_pts:
    E, B = split(val(d['F'])); Ej, Bj = jackson(W, [float(c) for c in x])
    e = max(np.max(np.abs(np.array([float(c) for c in E]) - Ej)), np.max(np.abs(np.array([float(c) for c in B]) - Bj))) / max(np.max(np.abs(Ej)), 1e-300)
    worst = max(worst, e); okJ &= e < 1e-12
chk('bit==std', okJ, "E and B read off the label field (frame split) equal Jackson's velocity plus acceleration fields, retarded time by brentq, at the 24 points: largest relative difference %.1e < 1e-12" % worst)
okMx = True; worstM = 0.0
for W, x, d in std_pts:
    xf = np.array([float(c) for c in x]); h = 1e-4
    def EB(y): return jackson(W, y)
    dE = []; dB = []
    for mu in range(4):
        e_ = np.zeros(4); e_[mu] = h; Ep, Bp = EB(xf + e_); Em, Bm = EB(xf - e_); dE.append((Ep - Em) / (2 * h)); dB.append((Bp - Bm) / (2 * h))
    divE = dE[1][0] + dE[2][1] + dE[3][2]; divB = dB[1][0] + dB[2][1] + dB[3][2]
    curlE = np.array([dE[2][2] - dE[3][1], dE[3][0] - dE[1][2], dE[1][1] - dE[2][0]]); curlB = np.array([dB[2][2] - dB[3][1], dB[3][0] - dB[1][2], dB[1][1] - dB[2][0]])
    scale = max(np.max(np.abs(np.array(dE))), np.max(np.abs(np.array(dB))))
    e = max(abs(divE), abs(divB), np.max(np.abs(curlE + dB[0])), np.max(np.abs(curlB - dE[0]))) / scale
    worstM = max(worstM, e); okMx &= e < 1e-6
chk('std', okMx, "Jackson's field at the 24 points: div E = 0, div B = 0, curl E + dB/dt = 0, curl B - dE/dt = 0 by central differences (h = 1e-4): largest relative residual %.1e < 1e-6" % worstM)
NGL = 56
gl, gw = np.polynomial.legendre.leggauss(NGL)
def gauss_flux(W, t0, centre, rho):
    tot = 0.0
    for c, wc in zip(gl, gw):
        st = np.sqrt(1 - c * c)
        for k_ in range(NGL):
            ph = 2 * np.pi * k_ / NGL; n = np.array([st * np.cos(ph), st * np.sin(ph), c])
            E, _ = jackson(W, [t0, *(centre + rho * n)]); tot += wc * (2 * np.pi / NGL) * rho * rho * (E @ n)
    return tot / (4 * np.pi)
fl = []
for W, t0 in ((WORLDS[2], 0.75), (WORLDS[2], 2.0), (WORLDS[0], 1.0)):
    zf = W_float(W)[0]; tau0 = np.arcsinh(float(W.a) * t0) / float(W.a) if isinstance(W, Hyperbolic) else t0 / float(W.v[0]); c0 = zf(tau0)[1:]
    for rho in (0.5, 1.0): fl.append(('%s t = %s rho = %s' % (W.name, t0, rho), gauss_flux(W, t0, c0, rho), 1.0))
    fl.append(('%s t = %s outside' % (W.name, t0), gauss_flux(W, t0, c0 + np.array([1.5, 0, 0]), 0.5), 0.0))
chk('std', all(abs(f_ - w_) < 1e-8 for _, f_, w_ in fl), 'Gauss: the flux of E through spheres around the present position at fixed lab time is q (hyperbolic a = 1 at t = 3/4 and 2, uniform at t = 1; radii 1/2 and 1, clear of the past horizon t + x + 1/a = 0) and 0 for a sphere beside the charge (56 x 56 Gauss-Legendre, tolerance 1e-8): %s'
    % ', '.join('%.10f' % f_ for _, f_, _ in fl))

head('2. emd·LARM: the Larmor flux of the hyperbolic motion [bit] exact on the light-cone sphere; scipy quad [std]')
okLx = True; nL = 0
for a in (Fr(1, 2), Fr(1), Fr(2)):
    W = Hyperbolic(a)
    for R in (Fr(1), Fr(10), Fr(1000)):
        for d_ in DIRS:
            n = [Fr(c, d_[3]) for c in d_[:3]]; x = [R, R * n[0], R * n[1], R * n[2]]
            rr = roots(W, x)
            if not rr or rr.get('ret') != 1: okLx = False; continue
            dd = field_at(W, x, variant=variant); E, B = split(val(dd['F']))
            S = cross(E, B)
            okLx &= B == cross(n, E) and R * R * dot3(S, n) == a * a * (1 - n[0] * n[0]); nL += 1
integral = 2 * (Fr(1) - Fr(1, 3))                                       # int_{-1}^{1} (1 - c^2) dc
chk('bit', okLx and nL == 108, 'hyperbolic motion, a = 1/2, 1, 2, retarded event s = 1: at R = 1, 10, 1000 and 12 rational directions (108 points) the retarded root is exactly 1, B = n x E and R^2 (E x B) . n = a^2 (1 - (n . x^)^2), exactly, independent of R')
chk('bit', integral == Fr(4, 3) and 2 * integral == Fr(2, 3) * 4, 'int over the sphere: 2 pi int_{-1}^{1} (1 - c^2) dc = (8/3) pi, so P = (q/4 pi)^2 (8 pi/3) a^2 = (2/3) q^2 a^2/(4 pi) (exact polynomial integral; pi as a symbol)')
def larmor_quad(a, beta, R, beam=True, accel=True):
    q = 4 * np.pi; tau0 = np.arctanh(beta) / a; b = np.array([np.tanh(a * tau0), 0, 0]); bd = np.array([a / np.cosh(a * tau0) ** 3, 0, 0])
    def integrand(th):
        n = np.array([np.cos(th), np.sin(th), 0.0]); g2 = 1.0 / (1.0 - b @ b); k = 1.0 - n @ b
        E = q / (4 * np.pi) * ((n - b) / (g2 * k ** 3 * R ** 2) + (np.cross(n, np.cross(n - b, bd)) / (k ** 3 * R) if accel else 0.0))
        Bf = np.cross(n, E); S = np.cross(E, Bf)
        return R * R * (S @ n) * (k if beam else 1.0) * 2 * np.pi * np.sin(th)
    return quad(integrand, 0, np.pi, epsabs=0, epsrel=1e-12, limit=400, points=[0.05, 0.2, 0.5])[0]
res = []; okQ = True
for a in (0.5, 1.0, 2.0):
    for beta in (0.0, 0.6, -0.8):
        P = larmor_quad(a, beta, 1e6 / a, beam=(FAULT != 'NOBEAM')); want = (8 * np.pi / 3) * a * a
        if FAULT == 'NRLARMOR': want = (8 * np.pi / 3) * (a * (1 - beta * beta) ** 1.5) ** 2
        res.append((a, beta, P / want)); okQ &= abs(P / want - 1) < 1e-5
chk('std', okQ, 'scipy quad of int R^2 (S . n)(1 - n . beta) dOmega, Jackson field at R = 10^6/a, a = 1/2, 1, 2, beta = 0, 3/5, -4/5 at the retarded event: ratio to (2/3) q^2 a^2/(4 pi) = %s (tolerance 1e-5)' % ', '.join('%.8f' % r_ for *_, r_ in res))
P0 = [larmor_quad(a, 0.0, 1.0 / a) / ((8 * np.pi / 3) * a * a) for a in (0.5, 1.0, 2.0)]
chk('bit==std', all(abs(p - 1) < 1e-9 for p in P0), 'at beta = 0 the quad value equals the exact (8 pi/3) a^2 already at R = 1/a (the integrand does not depend on R there): ratios %s' % ', '.join('%.12f' % p for p in P0))
nb = [larmor_quad(1.0, b_, 1e6, beam=False) / (8 * np.pi / 3) for b_ in (0.6, -0.8)]
nr = [(8 * np.pi / 3) * (1.0 * (1 - b_ * b_) ** 1.5) ** 2 / larmor_quad(1.0, b_, 1e6) for b_ in (0.6, -0.8)]
va = larmor_quad(1.0, 0.6, 1e6, accel=False) / (8 * np.pi / 3)
chk('ctl', all(abs(x_ - 1) > 1e-2 for x_ in nb + nr) and abs(va) < 1e-10, 'wrong versions differ: the flux per unit lab time, no factor (1 - n . beta): ratio %s; the non-relativistic formula with the lab acceleration a/gamma^3: ratio %s; the velocity field alone carries %.1e of it' % (', '.join('%.4f' % x_ for x_ in nb), ', '.join('%.6f' % x_ for x_ in nr), va))
okALD = True
for a in (Fr(1, 2), Fr(1), Fr(2)):
    W = Hyperbolic(a)
    for p0 in (Fr(1), Fr(2), Fr(1, 3), Fr(5), Fr(3, 7)):
        s = Jet(p0, (1, 0, 0, 0)); vd = W.acc(s); v = W.vel(p0)
        vdd = [a * p0 * c.d[0] for c in vd]                                  # d/dtau = a s d/ds
        vd0 = [c.v for c in vd]; vd2 = mdot(vd0, vd0)
        ald = [x_ + vd2 * y_ for x_, y_ in zip(vdd, v)]
        okALD &= all(c == 0 for c in ald) and vd2 == -a * a and any(c != 0 for c in [-vd2 * y_ for y_ in v])
chk('bit', okALD, 'the Abraham-Lorentz-Dirac four-force (2/3)(q^2/4 pi)(vddot + vdot^2 v) (recalled) is 0 on the hyperbolic worldline (a = 1/2, 1, 2, five s each, exact): vddot = a^2 v and vdot^2 = -a^2; its Larmor part -vdot^2 v = a^2 v is not 0 and the Schott term vddot balances it')

head('3. emd·DUAL: I^2, the duality rotation, the Hodge star, plane waves, the degenerate limits [bit]; Levi-Civita and textbook formulas [std]')
tab = {}
for p in range(5):
    for q_ in range(5 - p):
        r_ = 4 - p - q_; sq = [1] * p + [-1] * q_ + [0] * r_; m_, s_ = cs.bmul(15, 15, sq); tab[(p, q_, r_)] = s_
chk('bit', tab[(1, 3, 0)] == -1 and all((v == 0) == (k[2] > 0) for k, v in tab.items()) and all(v == (-1) ** (6 + k[1]) for k, v in tab.items() if k[2] == 0),
    'I^2 over the 15 signatures Cl(p,q,r), p + q + r = 4: -1 in Cl(1,3); 0 exactly when r >= 1; (-1)^(n(n-1)/2) (-1)^q otherwise, the formula maxwell_selfcheck.py asserts on its ladders: %s' % {'%d%d%d' % k: v for k, v in sorted(tab.items())})
BIV = [m for m in range(16) if pc(m) == 2]; VEC = [1 << k for k in range(4)]
ROT = {6: Fr(1)} if FAULT == 'BIVROT' else I4                                # gamma_1 gamma_2 (mask 6) in place of I
chk('bit', all(mul(I4, {b: Fr(1)}) == mul({b: Fr(1)}, I4) for b in BIV) and all(mul(I4, {v_: Fr(1)}) == sc(mul({v_: Fr(1)}, I4), -1) for v_ in VEC),
    'I commutes with the six bivectors and anticommutes with the four vectors: gamma^mu exp(I theta) = exp(-I theta) gamma^mu, so nabla(exp(I theta) F) = exp(-I theta) nabla F')
# polynomial vacuum solutions of nabla F = 0 (package variables x_mu), degree <= 2
MONS = [e for e in itertools.product(range(3), repeat=4) if sum(e) <= 2]
cols = []; keys = set()
for b in BIV:
    for e in MONS:
        img = cs.nabla({b: {e: Fr(1)}}, SQ); cols.append(img); keys |= {(bb, ee) for bb, pp in img.items() for ee in pp}
keys = sorted(keys)
rows = [[c.get(bb, {}).get(ee, Fr(0)) for c in cols] for bb, ee in keys]
def nullspace(rows, ncols):
    M = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncols):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][c]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    out = []
    for fc in [c for c in range(ncols) if c not in piv]:
        v = [Fr(0)] * ncols; v[fc] = Fr(1)
        for i, p in enumerate(piv): v[p] = -M[i][fc]
        out.append(v)
    return out
NS = nullspace(rows, len(cols))
UNK = [(b, e) for b in BIV for e in MONS]
def from_vec(v):
    F = {}
    for (b, e), c in zip(UNK, v):
        if c: F.setdefault(b, {})[e] = c
    return F
sols = []
for sd in range(3):
    rg = random.Random(4100 + sd); cf = [Fr(rg.randint(-3, 3)) for _ in NS]; v = [sum(c * w[i] for c, w in zip(cf, NS)) for i in range(len(UNK))]; sols.append(from_vec(v))
srcs = []
for sd in range(3):
    rg = random.Random(4200 + sd); A_ = {1 << k: cs.rpoly(rg, 4, 2, .6) for k in range(4)}; srcs.append(cs.fgrade(cs.nabla(A_, SQ), 2))
def lmul_const(c, F): return cs.fmul({m: {(0,) * 4: v} for m, v in c.items()}, F, SQ)
ANG = [(Fr(3, 5), Fr(4, 5)), (Fr(5, 13), Fr(12, 13)), (Fr(8, 17), Fr(-15, 17))]
okV = all(cs.nabla(F, SQ) == {} and F for F in sols)
main = srcs if FAULT == 'SOURCE' else sols
def fscale(F, c): return {m: cs.pscale(p_, c) for m, p_ in F.items()}
okR = all(cs.nabla(cs.fadd(fscale(F, cth), lmul_const(sc(ROT, sth), F)), SQ) == {} for F in main for cth, sth in ANG)
chk('bit', okV and len(NS) > 0, 'the polynomial bivector fields of degree <= 2 with nabla F = 0 form a space of dimension %d (exact null space of the %d x %d system); three random elements (seeds 4100..4102) are solutions' % (len(NS), len(rows), len(cols)))
chk('bit', okR, 'exp(I theta) F = cos theta F + sin theta I F solves nabla F = 0 for the three solutions at (cos, sin) = (3/5, 4/5), (5/13, 12/13), (8/17, -15/17): exact polynomial identities')
okS = True; ctlB = True
for F in srcs:
    NF = cs.nabla(F, SQ); Jv = cs.fgrade(NF, 1)
    okS &= cs.fgrade(NF, 3) == {} and Jv != {}
    for cth, sth in ANG:
        Fr_ = cs.fadd({m: {e: c * cth for e, c in p.items()} for m, p in F.items()}, lmul_const(sc(I4, sth), F))
        okS &= cs.fgrade(cs.nabla(Fr_, SQ), 3) == lmul_const(sc(I4, -sth), Jv) != {}
for F in sols:
    for cth, sth in ANG:
        Fb = cs.fadd({m: {e: c * cth for e, c in p.items()} for m, p in F.items()}, lmul_const({6: sth}, F))
        ctlB &= cs.nabla(Fb, SQ) != {}
chk('ctl', okS, 'with an electric source (F = nabla ^ A, three random A of degree 2: grade-3 part of nabla F zero, J = grade-1 part non-zero) the rotated field has the grade-3 source -sin theta I J != 0: the duality belongs to the source-free equations')
chk('ctl', ctlB, 'exp(gamma_12 theta) in place of exp(I theta) (a bivector that is not central) does not keep the three solutions')
# Hodge star from the Levi-Civita symbol
eps = np.zeros((4, 4, 4, 4), int)
for perm in itertools.permutations(range(4)):
    inv = sum(1 for i in range(4) for j in range(i + 1, 4) if perm[i] > perm[j]); eps[perm] = -1 if inv % 2 else 1
eta = np.diag([1, -1, -1, -1])
def to_mat(Bv):
    M = np.zeros((4, 4), int)
    for m_, c in Bv.items():
        i, j = [k for k in range(4) if m_ >> k & 1]; M[i, j] = int(c); M[j, i] = -int(c)
    return M
def hodge(Mup):
    low = np.einsum('mnrs,rs->mn', eps, Mup) // 2; return eta @ low @ eta
signs = set(); star_mat = np.zeros((6, 6), int); I_mat = np.zeros((6, 6), int)
for j, b in enumerate(BIV):
    IB_ = mul(I4, {b: Fr(1)}); Hs = hodge(to_mat({b: 1})); Mi = to_mat(IB_)
    for c_ in (1, -1):
        if np.array_equal(Hs, c_ * Mi): signs.add(c_)
    for i, b2 in enumerate(BIV):
        i1, i2 = [k for k in range(4) if b2 >> k & 1]; star_mat[i, j] = Hs[i1, i2]; I_mat[i, j] = int(IB_.get(b2, 0))
chk('std', np.array_equal(star_mat @ star_mat, -np.eye(6, dtype=int)), 'the Hodge star (star F)_mn = (1/2) eps_mnrs F^rs (eps_0123 = +1, eta = diag(1,-1,-1,-1)) on 2-forms: star^2 = -1 (integer 6 x 6 matrix)')
chk('bit==std', len(signs) == 1 and np.array_equal(star_mat, list(signs)[0] * I_mat) and np.array_equal(I_mat @ I_mat, -np.eye(6, dtype=int)), 'on the six basis bivectors star = %+d I (one sign), and I^2 = -1 on bivectors: the Hodge star on F is multiplication by the pseudoscalar' % (list(signs)[0] if len(signs) == 1 else 0))
# duality on (E, B)
okEB = True; okEBs = True
rgF = random.Random(4300)
FS = [{b: Fr(1)} for b in BIV] + [{b: Fr(rgF.randint(-5, 5), rgF.randint(1, 4)) for b in BIV} for _ in range(3)]
for F in FS:
    E, B = split(F)
    for cth, sth in ANG:
        E2, B2 = split(add(sc(F, cth), sc(mul(ROT, F), sth)))
        Ew = [cth * e + (1 if FAULT == 'DUALSIGN' else -1) * sth * b_ for e, b_ in zip(E, B)]; Bw = [sth * e + cth * b_ for e, b_ in zip(E, B)]
        okEB &= E2 == Ew and B2 == Bw
        En = np.array([float(x_) for x_ in E]); Bn = np.array([float(x_) for x_ in B]); th = math.atan2(float(sth), float(cth))
        okEBs &= np.allclose(np.array([float(x_) for x_ in E2]), En * np.cos(th) - Bn * np.sin(th), atol=1e-12) and np.allclose(np.array([float(x_) for x_ in B2]), En * np.sin(th) + Bn * np.cos(th), atol=1e-12)
chk('bit', okEB, 'exp(I theta)(E + I B) = (E cos theta - B sin theta) + I (E sin theta + B cos theta), exact on the six basis bivectors and three random F at the three angles')
chk('bit==std', okEB and okEBs, 'the textbook duality rotation (E, B) -> (E cos - B sin, E sin + B cos) in floats agrees (tolerance 1e-12)')
# plane waves
KS = [(Fr(1, 3), Fr(2, 3), Fr(2, 3)), (Fr(2, 7), Fr(3, 7), Fr(6, 7)), (Fr(0), Fr(3, 5), Fr(4, 5))]
ES = [(2, -1, 0), (3, -2, 0), (1, 0, 0)]
okW = True; okRod = True
for kh, E0 in zip(KS, ES):
    E0 = [Fr(c) for c in E0]; assert dot3(E0, kh) == 0
    B0 = cross(kh, E0); Fc = add(*[sc(SIG[k + 1], E0[k]) for k in range(3)], mul(I4, add(*[sc(SIG[k + 1], B0[k]) for k in range(3)])))
    phi = {(1, 0, 0, 0): Fr(1)}
    for k in range(3): phi[tuple(1 if i == k + 1 else 0 for i in range(4))] = kh[k]          # t - k.x with x^k = -x_k
    def ppow(p, n_):
        r = {(0,) * 4: Fr(1)}
        for _ in range(n_): r = cs.pmul(r, p)
        return r
    fpol = cs.padd(cs.padd(cs.padd(ppow(phi, 3), cs.pscale(ppow(phi, 2), -2)), cs.pscale(phi, 3)), {(0,) * 4: Fr(5)})
    Fw = {m: cs.pscale(fpol, c) for m, c in Fc.items()}
    okW &= cs.nabla(Fw, SQ) == {}
    for cth, sth in ANG:
        Frot = cs.fadd({m: cs.pscale(p, cth) for m, p in Fw.items()}, lmul_const(sc(ROT, sth), Fw))
        okW &= cs.nabla(Frot, SQ) == {}
        E2, B2 = split(add(sc(Fc, cth), sc(mul(ROT, Fc), sth)))
        okW &= dot3(E2, kh) == 0 and dot3(E2, E2) == dot3(E0, E0) and B2 == cross(kh, E2)
        k_ = np.array([float(c) for c in kh]); th = -math.atan2(float(sth), float(cth)); Kx = np.array([[0, -k_[2], k_[1]], [k_[2], 0, -k_[0]], [-k_[1], k_[0], 0]])
        Rm = np.cos(th) * np.eye(3) + np.sin(th) * Kx + (1 - np.cos(th)) * np.outer(k_, k_)
        okRod &= np.allclose(Rm @ np.array([float(c) for c in E0]), np.array([float(c) for c in E2]), atol=1e-12)
chk('bit', okW, 'plane waves F = (E + I B) f(t - k.x), f = phi^3 - 2 phi^2 + 3 phi + 5, B = k x E, k = (1,2,2)/3, (2,3,6)/7, (0,3,4)/5: nabla F = 0, and exp(I theta) F is again a vacuum plane wave with E . k = 0, |E| kept, B = k x E (exact)')
chk('bit==std', okRod, 'the rotated E is the Rodrigues rotation of E about k by the angle -theta (floats, tolerance 1e-12): the duality turns the polarisation')
# degenerate limits
def bivector_map(sq):
    M = [[Fr(0)] * 6 for _ in range(6)]
    for j, b in enumerate(BIV):
        img = mul({15: Fr(1)}, {b: Fr(1)}, sq)
        for i, b2 in enumerate(BIV): M[i][j] = img.get(b2, Fr(0))
    return M
def mm(A_, B_): return [[sum(A_[i][k] * B_[k][j] for k in range(6)) for j in range(6)] for i in range(6)]
def rank6(M): return int(np.linalg.matrix_rank(np.array([[float(x) for x in r] for r in M])))
okN = True; info = []
for nm, sq in (('Cl(1,2,1)', [1, -1, -1, 0]), ('Cl(0,3,1)', [0, -1, -1, -1])):
    sq_use = SQ if FAULT == 'NONDEG' else sq
    M = bivector_map(sq_use); I2 = mul({15: Fr(1)}, {15: Fr(1)}, sq_use)
    th = Fr(3, 7); ex = add(ONE, sc({15: Fr(1)}, th)); sq_th = mul(sc({15: Fr(1)}, th), sc({15: Fr(1)}, th), sq_use)
    nil = all(x == 0 for r in mm(M, M) for x in r)
    okN &= I2 == {} and nil and rank6(M) == 3 and sq_th == {}
    info.append('%s: I^2 = %s, rank %d, square zero %s' % (nm, I2 or 0, rank6(M), nil))
chk('bit', okN, 'one null generator: %s; (theta I)^2 = 0 so exp(I theta) = 1 + theta I (theta = 3/7): a shear, not a rotation (wires cat·F4, bridge·A6: the top blade squares to 0)' % '; '.join(info))
M4 = bivector_map(SQ)
chk('ctl', mm(M4, M4) == [[Fr(-1) if i == j else Fr(0) for j in range(6)] for i in range(6)] and rank6(M4) == 6, 'in Cl(1,3) the same map has rank 6 and square -1: not nilpotent')

finish('EMD-MAXWELL')
