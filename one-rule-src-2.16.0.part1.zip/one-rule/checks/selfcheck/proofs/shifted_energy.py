#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_energy.py -- the energy of the shifted theory of Atiyah and Moore ("A shifted view of fundamental physics", section 2 with the
remarks 2.1-2.2, read): an energy defined by Noether's procedure on the nonlocal action (the paper defines none), its conservation on fields of
two frequencies, its value on the quantized solutions beside the gravitational coupling, the two-frequency packet on the frame of a constant
potential, and the mixed equation (2.17).

Read.  The paper writes the retarded equation x'(t) + k x(t - r) = 0 (2.1), the shifted Dirac equation (i hbar D - m c + i k exp(-r D)) psi = 0
(2.2), the variants D_-, D_s, D_c (2.3), the action int vol psi-bar (i hbar D_+ - m c) psi (2.10), "from which one can derive the energy-momentum
tensor", and states T_00 = E_0 (1 - mu (-1)^n) (2.12) from the coefficient of Phi in the weak field (2.11); remark 2.2.2 gives the mixed equation
x'(t) + k (x(t - r) + x(t + r)) = 0 (2.17) with x = e^{-z t/r}, z = mu (e^z + e^{-z}) (2.18); remark 2.2.3 says the roots have non-zero real parts,
which tend to zero as mu -> infinity, where the solutions become anti-periodic with period 2r, and recalls a conserved energy of Feynman's for a
similar equation: his thesis, section II.3, the mirror action, where (as the literature pass reports it; the thesis is not read here) the
conserved energy needs the motion over a whole window from t - T_0 to t + T_0, the template of the bilocal term below.  No T_mu.nu is written
on the page.
Conventions of coupling_selfcheck.py, shifted_dirac.py and shifted_weakfield.py: labels of Cl(1,3), bit 0 = time (square +1); J = gamma_2 gamma_1;
a field of the frame time alone is P(t), P even; bD(P) = fr gamma_0 P' gamma_0 (fr = 1, or the frame factor a = 1/N of a constant potential); the
even form of the paper's operator is O[P] = bD(P) J - m P + kappa (exp(-tau bD) P) J (hbar = c = 1, kappa = k, tau = r).  P_+ (P_-) is the part of
P that commutes (anticommutes) with gamma_0; at rest P_+ e^{-J E t} is sector -1 and P_- e^{+J E t} sector +1.  <a>_S = <a>_0 - <a J>_0 J is the
J-complex part of a (span{1, J}: the image of the complex value of the Dirac pairing psi-bar phi, J <-> i).  Fields are quasi-polynomials
sum Z t^d e^{J beta t} with coefficients in Q[pi], exact (pi is transcendental: an identity in Q[pi] is an identity of real numbers); a shift that
is a rational multiple of pi enters through exact quarter-turn phases.
The action and its energy.  L = <Q O[P]>_S with an independent conjugate field Q (on the solutions Q = P~, the reverse: the Dirac conjugate);
varying Q gives O[P] = 0, varying P the adjoint Y = 0.  At rest the shift is a delay (2), and for a Lagrangian with arguments q(t - delta_j) the
Noether energy of t -> t + epsilon is h - sum_j int_{t - delta_j}^{t} (dL/dq_j)(s + delta_j) q'(s) ds, h the canonical part, delta_j < 0 an advance:
the bilocal ("Wronskian") term pairs the conjugate field at one end of the delay interval with the derivative of the shifted field at the other.
The Noether number of the phase P -> P e^{J alpha} likewise.  A Noether energy is defined up to improvement terms; the symmetric (Belinfante) form
is not attempted.

Statements.
(1) [en.DELAY] (2.1) from L = y (x' + k x(t - r)), y obeying the advanced adjoint y' = k y(t + r): E = -k y(t) x(t - r) - k int_{t-r}^{t} y(s + r) x'(s) ds
    is constant exactly on piecewise polynomial solutions by the method of steps (12 runs, mu = 1/2, 3/2, -2/3, 3/2); on exponential solutions
    (lambertw, 20 roots) it is (z/r)(z - 1) per root with zero cross terms between two roots; on generic smooth data by solve_ivp constant to 1e-12.
    [en.OSC] (2.1) oscillates without growth exactly when the delay is an odd number of quarter periods, cos(omega r) = 0, mu = (-1)^n (n + 1/2) pi:
    exact in the J-plane, and by lambertw at mu = pi/2, -3 pi/2, 5 pi/2 (control: five other mu, every root off the imaginary axis); with a mass
    term the toys (the halves at rest of (2)) sort as the operators do (ATY-007): D_+ and D_c read uniformly oscillate only on the lattice
    cos E tau = 0 (and not at all at tau = 1.3), H, D_s and D_c as printed off it too.
(2) [en.REST] On fields of t alone exp(-tau bD) P = P_+(t - fr tau) + P_-(t + fr tau) exactly (the power series on polynomial fields); cosh(tau bD)
    is the symmetric shift, sinh(tau bD) the antisymmetric one with a gamma_0 twist; O = H + A, H = bD J - m - kappa (sinh tau bD) J (the Hermitian
    half: D_s with kappa -> -kappa), A = kappa (cosh tau bD) J; the P_+ half of O at rest is (2.1) with k = kappa e^{J m tau} for X = P_+ e^{J m t},
    the P_- half its advanced adjoint; D_c read uniformly is (2.17) with k = kappa/2, as printed with k = (kappa/2) J; D_s gives the difference equation.
(3) [en.NOETHER] dE/dt = -<Q' O[P]>_S - <Y P'>_S and dN/dt = <Y P J>_S - <J Q O[P]>_S exactly off shell (30 pairs of polynomial fields; O, H, A, D_c,
    D_s); on the quantized rest modes ((m, kappa) = (3, 2): E = 5 at tau = pi/10, E = 1 at tau = 3 pi/2; both sectors) Q = P~ solves the adjoint,
    E = rho E_0 (1 - (-1)^n mu J) and N = |P|^2 (1 - (-1)^n mu J) with rho = <P~ P>_0, mu = kappa tau; the J part is the anti-Hermitian half's, all
    of it bilocal; H alone gives rho E_0.
(4) [en.CONS2] Two quantized modes at one tau ((m, kappa, tau) = (4, 1, pi/2), (2, -1, pi/2), (2, 1, 3 pi/2); both sectors): E is exactly constant,
    the sum of the two modes' values; the local part beats at E_1 - E_2 and the bilocal part cancels the beat exactly.
(5) [en.HERM] H at (m, kappa, tau) = (4, 1, pi/2), (8, 1, pi/2): rest modes at E = m - 1, m, m + 1 (the paper's O only at the outer two); on each
    the Noether energy is real, rho E (1 - mu cos E tau), and the number |P|^2 (1 - mu cos E tau) is negative at E = m (1 - pi/2 < 0); a numpy scan
    finds one root at mu = 0.1, 0.5, 0.9, -0.9.
(6) [en.GRAV] The Phi-coefficient of the action (fr = 1 + Phi + ... in bD and inside the shift) equals the Noether energy on every mode tried, for O,
    H and A separately: rho E_0 (1 - (-1)^n mu J) for O; per unit local density it is E_0 times the Noether number per unit density, and the paper's
    (2.12) is that with J read as a real number; on a two-mode sum the coupling density beats and its constant part is the energy; for a moving wave
    the k-derivative of the symbol carries the factor of the rest frame (Dirac matrices).
(7) [en.BEAT] Two quantized rest energies of one species at one tau force kappa tau = (n_1 - n_2) pi/2 (441 pairs); on four frames of a constant
    potential the two-mode sum solves the frame equation, its density beats at 2 kappa per unit proper time (2 kappa/a per unit coordinate time),
    the beat changes sign over one shift, and the Noether energy (with the volume factor) is constant and redshifted by 1/a.
(8) [en.MIXED] The symmetric shift vanishes on rest modes exactly at cos E tau = 0; (2.17) has no oscillating solution on the quarter turns; the
    roots of (2.18) (Newton's method from a grid, mu = 0.05 ... 500) stay off the imaginary axis, approach i (j + 1/2) pi as mu grows (deviations
    O(1/mu^2) at mu = 50, 500, 5000), and the solutions become anti-periodic; the doubled Lagrangian of (2.17) has a conserved energy.
[bit]  Exact Fractions and Q[pi] on the labels (bmul of coupling_selfcheck.py); en.DELAY in (1) is the scalar model in exact Fractions (no
       generator enters), en.OSC works in the J-plane and on the halves at rest of the labels.
[std]  numpy and scipy, never the labels: complex 4 x 4 Dirac matrices (Dirac representation), scipy expm, quad, solve_ivp, lambertw, SVD kernels,
       central differences, FFT; complex Newton's method for (2.18) and for the real frequencies of the toys.
[ctl]  Each wrong version is also a --fault option that puts it into the main lines (the run must then end with FAILS):
       NOBILOCAL   the bilocal term dropped from the energy;               SAMETIME  the bilocal integrand pairs Q(s) with P'(s), no shift;
       NOTWIST     exp(-tau bD) at rest as the plain shift of both halves; READREAL  the J part of the Phi-coefficient read as a real number;
       SINHSIGN    the Hermitian half built with + kappa sinh (D_s itself); COORDSHIFT the shift tau taken in coordinate time on the frame;
       MIXSIGN     (2.18) with e^z - e^{-z}.
Scope.  Fields of the frame time alone (zero momentum): polynomial fields for the identities, rest waves at quarter-turn shifts for the values;
       a moving wave only through the k-derivative of the symbol (Dirac matrices); a constant potential; the energy of the delay formula, up to
       improvement terms; no energy-momentum tensor for fields that depend on space; no packets of more than two frequencies (three for H).
Run:   python3 shifted_energy.py [--fault NOBILOCAL|SAMETIME|NOTWIST|READREAL|SINHSIGN|COORDSHIFT|MIXSIGN]
       (from the package root as selfcheck/proofs/shifted_energy.py; also from its own folder, and under -I -B)"""
import os, sys, time, math
from fractions import Fraction as Fr
from math import comb
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm
from scipy.integrate import quad, solve_ivp
from scipy.special import lambertw
import warnings
from scipy.integrate import IntegrationWarning
warnings.filterwarnings('ignore', category=IntegrationWarning)

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
if not os.path.isfile(os.path.join(_selfcheck, 'coupling_selfcheck.py')):
    raise SystemExit('coupling_selfcheck.py not found in ' + _selfcheck + ': this file belongs in selfcheck/proofs/ of the package')
if _selfcheck not in sys.path: sys.path.insert(0, _selfcheck)
import coupling_selfcheck as cs

# ------------------------------------------------------------------------------------------------ check lines and faults
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('NOBILOCAL', 'SAMETIME', 'NOTWIST', 'READREAL', 'SINHSIGN', 'COORDSHIFT', 'MIXSIGN')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact numbers: Q[pi]
class QP:
    """a_0 + a_1 pi + a_2 pi^2 + ... with rational a_k: exact numbers for shifts that are rational multiples of pi (pi is transcendental, so an
    identity in Q[pi] is an identity of real numbers, and a failure in Q[pi] is never a rounding)"""
    __slots__ = ('c',)
    def __init__(self, c=0):
        if isinstance(c, QP): self.c = dict(c.c)
        elif isinstance(c, dict): self.c = {k: Fr(v) for k, v in c.items() if v != 0}
        else:
            v = Fr(c); self.c = {0: v} if v else {}
    @staticmethod
    def of(x): return x if isinstance(x, QP) else QP(x)
    def __add__(self, o):
        o = QP.of(o); d = dict(self.c)
        for k, v in o.c.items(): d[k] = d.get(k, 0) + v
        return QP(d)
    __radd__ = __add__
    def __neg__(self): return QP({k: -v for k, v in self.c.items()})
    def __sub__(self, o): return self + (-QP.of(o))
    def __rsub__(self, o): return QP.of(o) + (-self)
    def __mul__(self, o):
        o = QP.of(o); d = {}
        for i, a in self.c.items():
            for j, b in o.c.items(): d[i + j] = d.get(i + j, 0) + a * b
        return QP(d)
    __rmul__ = __mul__
    def __truediv__(self, o):
        o = QP.of(o); assert set(o.c) == {0}, 'division by a non-zero rational only'
        return QP({k: v / o.c[0] for k, v in self.c.items()})
    def __eq__(self, o): return self.c == QP.of(o).c
    def __ne__(self, o): return not self.__eq__(o)
    def __hash__(self): return hash(tuple(sorted(self.c.items())))
    def __bool__(self): return bool(self.c)
    def __float__(self): return float(sum(float(v) * math.pi ** k for k, v in self.c.items()))
    def rational(self): return set(self.c) <= {0}
    def __repr__(self):
        if not self.c: return '0'
        out = []
        for k in sorted(self.c):
            v = self.c[k]; out.append(str(v) if k == 0 else ('%s pi' % v if k == 1 else '%s pi^%d' % (v, k)))
        return ' + '.join(out).replace('+ -', '- ')
PI = QP({1: 1}); ZERO = QP(0); UNIT = QP(1)

# ------------------------------------------------------------------------------------------------ the labels of Cl(1,3): bmul of coupling_selfcheck.py
SQ = cs.sqs(4)                                                                  # bit 0 = time, square +1; bits 1-3 square -1
def pc(x): return bin(x).count('1')
def mmul(a, b):
    out = {}
    for x, cx in a.items():
        for y, cy in b.items():
            m, s = cs.bmul(x, y, SQ); p = cx * cy
            v = out.get(m, ZERO) + (p if s > 0 else -p)
            if v: out[m] = v
            else: out.pop(m, None)
    return out
def mlin(*terms):
    out = {}
    for c, a in terms:
        c = QP.of(c)
        for m, v in a.items():
            w = out.get(m, ZERO) + c * v
            if w: out[m] = w
            else: out.pop(m, None)
    return out
def mrev(a): return {m: (v if cs.rsign(pc(m)) > 0 else -v) for m, v in a.items()}
def blade(m, c=1): return {m: QP.of(c)}
ONE = blade(0); GAM = [blade(1 << mu) for mu in range(4)]; G0 = GAM[0]
_Jm, _Js = cs.bmul(1 << 2, 1 << 1, SQ); J = blade(_Jm, _Js)                       # J = gamma_2 gamma_1, as in coupling_selfcheck.py
G0J = mmul(G0, J); EVEN = [m for m in range(16) if pc(m) % 2 == 0]
assert mmul(J, J) == mlin((-1, ONE)) and mmul(J, G0) == mmul(G0, J)
def commutes_J(a): return mmul(a, J) == mmul(J, a)
def scal(a): return a.get(0, ZERO)
def Sproj(a):
    """<a>_S = <a>_0 - <a J>_0 J: the J-complex part (span{1, J}); the image of the Dirac pairing's complex value"""
    return mlin((scal(a), ONE), (-scal(mmul(a, J)), J))
def zre(z): return scal(z)
def zim(z): return -scal(mmul(z, J))                                            # z = zre + zim J
def gsplit(a):
    """(a_+, a_-) with gamma_0 a_+ gamma_0 = a_+, gamma_0 a_- gamma_0 = -a_-"""
    c = mmul(mmul(G0, a), G0)
    return mlin((Fr(1, 2), a), (Fr(1, 2), c)), mlin((Fr(1, 2), a), (Fr(-1, 2), c))
def phase(beta, c):
    """exact e^{J beta c} for a rational frequency beta and a shift c in Q[pi]: beta c must be 0 or a multiple of pi/2"""
    th = QP.of(c) * beta
    if not th: return ONE
    if set(th.c) == {1} and (2 * th.c[1]).denominator == 1:
        j = int(2 * th.c[1]) % 4
        return [ONE, J, mlin((-1, ONE)), mlin((-1, J))][j]
    raise ValueError('inexact phase: beta c = %r' % th)

# ------------------------------------------------------------------------------------------------ fields of the frame time: quasi-polynomials
# an R-field is {(beta, d): Z}: the sum of Z t^d e^{J beta t} (the phase on the right, as P exp(s J k.x) in shifted_dirac.py);
# an L-field is {(alpha, d): Y}: the sum of e^{J alpha t} t^d Y (the phase on the left: the reverse of an R-field);
# a C-field is {(nu, d): z} with z in span{1, J}: a J-complex quasi-polynomial (the values of the pairing <Q P>_S).
def fadd(*terms):
    out = {}
    for c, F in terms:
        for k, v in F.items():
            w = mlin((1, out.get(k, {})), (c, v))
            if w: out[k] = w
            else: out.pop(k, None)
    return out
def f_lmul(L, F): return {k: w for k, v in F.items() for w in [mmul(L, v)] if w}
def f_rmul(F, R): return {k: w for k, v in F.items() for w in [mmul(v, R)] if w}
def rf_rmul(F, R):
    assert commutes_J(R), 'a right factor must commute with J to pass the phase'
    return f_rmul(F, R)
def lf_lmul(L, F):
    assert commutes_J(L), 'a left factor must commute with J to pass the phase'
    return f_lmul(L, F)
def rf_deriv(F):
    out = {}
    for (b, d), Z in F.items():
        if d: out = fadd((1, out), (d, {(b, d - 1): Z}))
        if b: out = fadd((1, out), (1, {(b, d): mmul(Z, mlin((b, J)))}))
    return out
def lf_deriv(F):
    out = {}
    for (a, d), Y in F.items():
        if d: out = fadd((1, out), (d, {(a, d - 1): Y}))
        if a: out = fadd((1, out), (1, {(a, d): mmul(mlin((a, J)), Y)}))
    return out
def cf_deriv(F): return rf_deriv(F)                                             # z commutes with J
def _poly_shift(d, c):
    """(t + c)^d = sum_k C(d, k) c^(d-k) t^k"""
    out = {}; c = QP.of(c); p = UNIT
    pw = [UNIT]
    for _ in range(d): pw.append(pw[-1] * c)
    for k in range(d + 1): out[k] = pw[d - k] * comb(d, k)
    return out
def rf_shift(F, c):
    """F(t + c)"""
    out = {}
    for (b, d), Z in F.items():
        Zp = mmul(Z, phase(b, c))
        for k, w in _poly_shift(d, c).items():
            if w: out = fadd((1, out), (w, {(b, k): Zp}))
    return out
def lf_shift(F, c):
    out = {}
    for (a, d), Y in F.items():
        Yp = mmul(phase(a, c), Y)
        for k, w in _poly_shift(d, c).items():
            if w: out = fadd((1, out), (w, {(a, k): Yp}))
    return out
cf_shift = rf_shift
def rf_split(F):
    Fp, Fm = {}, {}
    for k, Z in F.items():
        a, b = gsplit(Z)
        if a: Fp[k] = a
        if b: Fm[k] = b
    return Fp, Fm
def rf_rev(F): return {(-b, d): mrev(Z) for (b, d), Z in F.items()}
def pair(Q, F):
    """<Q(t) F(t)>_S for an L-field Q and an R-field F: a C-field; <e^{J a t} Y Z e^{J b t}>_S = <Y Z>_S e^{J (a + b) t}"""
    out = {}
    for (a, d1), Y in Q.items():
        for (b, d2), Z in F.items():
            z = Sproj(mmul(Y, Z))
            if z: out = fadd((1, out), (1, {(a + b, d1 + d2): z}))
    return out
def cf_antideriv(F):
    out = {}
    for (nu, d), z in F.items():
        if nu == 0:
            out = fadd((1, out), (Fr(1, d + 1), {(nu, d + 1): z})); continue
        inv = mlin((Fr(-1) / nu, J))                                           # 1/(J nu) = -J/nu
        fac = mmul(z, inv); out = fadd((1, out), (1, {(nu, d): fac}))         # I_d = t^d e^{J nu t}/(J nu) - (d/(J nu)) I_{d-1}
        for j in range(d, 0, -1):
            fac = mlin((-j, mmul(fac, inv)))
            out = fadd((1, out), (1, {(nu, j - 1): fac}))
    return out
def cf_int(F, c):
    """int_{t-c}^{t} F(s) ds (oriented: c < 0 gives -int_t^{t-c})"""
    A = cf_antideriv(F)
    return fadd((1, A), (-1, cf_shift(A, -QP.of(c))))
def cf_const(F):
    """the constant of a C-field that has no t-dependence, else None"""
    if any(k != (0, 0) for k in F): return None
    return F.get((0, 0), {})

# ------------------------------------------------------------------------------------------------ the shifted operators at rest, as term lists
# A term (L, R, e, delta, c) stands for c L P^(e)(t - delta) R (R commutes with J); an operator is a list of terms.  On fields of t alone
# bD(P) = fr gamma_0 P' gamma_0 (fr = 1, or the frame factor a = 1/N of a constant potential) squares to fr^2 d_t^2, so the power series give
# exp(-tau bD) P = P_+(t - fr tau) + P_-(t + fr tau), cosh(tau bD) P = (P(t + fr tau) + P(t - fr tau))/2,
# sinh(tau bD) P = gamma_0 (P(t + fr tau) - P(t - fr tau)) gamma_0 / 2   (checked in (2) against the series on polynomial fields).
def ops(m, kap, tau, fr=1):
    """the paper's operator O (2.2), its Hermitian half H = i(D - kappa sinh tau D) - m and its anti-Hermitian half A = i kappa cosh tau D, in
    the even form (O[P] = bD(P) J - m P + kappa (exp(-tau bD) P) J); each with the list of its fr-derivative at fr = 1 (the Phi-coefficient)"""
    m, kap, fr = QP.of(m), QP.of(kap), QP.of(fr); d = QP.of(tau) * (UNIT if fault('COORDSHIFT') else fr); tq = QP.of(tau)   # COORDSHIFT: the shift tau in coordinate time
    kin = [(G0, G0J, 1, ZERO, fr)]; mass = [(ONE, ONE, 0, ZERO, -m)]
    if fault('NOTWIST'): sh_O = [(ONE, J, 0, d, kap)]                           # the plain time shift on both halves
    else: sh_O = [(ONE, J, 0, d, kap / 2), (G0, G0J, 0, d, kap / 2), (ONE, J, 0, -d, kap / 2), (G0, G0J, 0, -d, -kap / 2)]
    sg = -1 if fault('SINHSIGN') else 1                                          # SINHSIGN: D + kappa sinh (D_s itself) for the Hermitian half
    sh_H = [(G0, G0J, 0, -d, -sg * kap / 2), (G0, G0J, 0, d, sg * kap / 2)]
    sh_A = [(ONE, J, 0, -d, kap / 2), (ONE, J, 0, d, kap / 2)]
    def dphi(T):
        out = []
        for (L, R, e, de, c) in T:
            if e == 1 and not de: out.append((L, R, 1, ZERO, c / fr))           # d/dfr of fr gamma_0 P' gamma_0 J
            elif e == 0 and de:
                sig = 1 if de == d else -1                                       # delta = sig fr tau
                out.append((L, R, 1, sig * tq, -sig * tq * c))                  # d/dfr P(t - sig fr tau) = -sig tau P'(t - sig fr tau) at fr = 1
        return out
    O = kin + mass + sh_O; H = kin + mass + sh_H; A = sh_A
    variants = {'Dc_u': kin + mass + sh_A,                                       # D_c read as D + kappa cosh(tau D): + kappa (cosh P) J
                'Dc_p': kin + mass + [(ONE, ONE, 0, -d, -kap / 2), (ONE, ONE, 0, d, -kap / 2)],   # D + i kappa cosh: - kappa cosh P
                'Ds': kin + mass + [(G0, G0J, 0, -d, kap / 2), (G0, G0J, 0, d, -kap / 2)]}         # D + kappa sinh: + kappa (sinh P) J
    return dict(variants, O=O, H=H, A=A, dO=dphi(O), dH=dphi(H), dA=dphi(A))
def apply_op(T, P):
    out = {}
    for (L, R, e, de, c) in T:
        F = rf_deriv(P) if e else P
        if de: F = rf_shift(F, -de)
        out = fadd((1, out), (c, rf_rmul(f_lmul(L, F), R)))
    return out
def adjoint_op(T, Q):
    """Y with int <Q O[V]>_S dt = int <Y V>_S dt for every V: Y = sum c (-1)^e (d/dt)^e [R Q(t + delta) L]"""
    out = {}
    for (L, R, e, de, c) in T:
        G = lf_shift(Q, de) if de else Q
        G = f_rmul(lf_lmul(R, G), L)
        if e: G = lf_deriv(G); c = -c
        out = fadd((1, out), (c, G))
    return out
def noether(T, P, Q, gen=None):
    """the Noether charge of L = <Q O[P]>_S for the time translation (gen None: the energy) or for the phase P -> P e^{J alpha}
    (gen 'phase': the number, sign chosen so that E = omega N on a mode e^{-J omega t}):
    h = sum_{e=1, delta=0} c <Q L K R>_S - L  minus, for each shifted term, int_{t-delta}^{t} c <Q(s + delta) L K(s) R>_S ds,  K = P' or P J"""
    K = rf_deriv(P) if gen is None else rf_rmul(P, J)
    loc = {}; bil = {}
    for (L, R, e, de, c) in T:
        if e and de: raise ValueError('a shifted derivative term: not in the rest-frame operators')
        if e: loc = fadd((1, loc), (c, pair(Q, rf_rmul(f_lmul(L, K), R))))
        elif de:
            G = pair(Q if fault('SAMETIME') else lf_shift(Q, de), rf_rmul(f_lmul(L, K), R))   # SAMETIME: <Q(s) ... K(s)>, no shift
            bil = fadd((1, bil), (c, cf_int(G, de)))
    if gen is None: loc = fadd((1, loc), (-1, pair(Q, apply_op(T, P))))
    if fault('NOBILOCAL'): bil = {}
    tot = fadd((1, loc), (-1, bil))
    if gen is not None: tot = fadd((-1, tot)); loc = fadd((-1, loc)); bil = fadd((-1, bil))
    return tot, loc, bil
def mode(E, Z, sector=-1):
    """the rest wave Z e^{sector J E t} as an R-field"""
    return {(Fr(sector) * Fr(E), 0): Z}
def ratv(F):
    """the rational coefficients of an R-field whose values are rational (quarter-turn phases)"""
    out = {}
    for k, Z in F.items():
        for m_, v in Z.items():
            assert v.rational(), 'irrational coefficient'
            out[(k, m_)] = v.c.get(0, Fr(0))
    return out

PPLUS = [m_ for m_ in EVEN if mmul(mmul(G0, blade(m_)), G0) == blade(m_)]; PMINUS = [m_ for m_ in EVEN if m_ not in PPLUS]
def fmt_q(x):
    """a Q[pi] number as text: 5, -1/5 pi, 3 - 2 pi"""
    if not x.c: return '0'
    out = ''
    for k in sorted(x.c):
        v = x.c[k]; a = abs(v); sgn = '-' if v < 0 else '+'
        if k == 1: body = ('pi' if a.numerator == 1 else '%d pi' % a.numerator) + ('' if a.denominator == 1 else '/%d' % a.denominator)
        else: body = str(a) if k == 0 else '%s pi^%d' % (a, k)
        out += (('-' if sgn == '-' else '') + body) if not out else (' %s %s' % (sgn, body))
    return out
def fmt_z(z):
    """a J-complex number a + b J as text"""
    if z is None: return 'not constant'
    a, b = zre(z), zim(z)
    if not b: return fmt_q(a)
    bs = fmt_q(b); neg = bs.startswith('-'); bs = bs.lstrip('-')
    if ' ' in bs and ('+' in bs or ' - ' in bs): bs = '(' + bs + ')'
    if not a: return ('-' if neg else '') + bs + ' J'
    return '%s %s %s J' % (fmt_q(a), '-' if neg else '+', bs)

# the standard route's Dirac matrices (Dirac representation: Gamma_0^2 = 1, Gamma_k^2 = -1), as in shifted_dirac.py
s1 = np.array([[0, 1], [1, 0]], complex); s2 = np.array([[0, -1j], [1j, 0]]); s3 = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
GM = [np.block([[I2, 0 * I2], [0 * I2, -I2]])] + [np.block([[0 * I2, s_], [-s_, 0 * I2]]) for s_ in (s1, s2, s3)]; I4 = np.eye(4)
PIp = (I4 + GM[0]) / 2; PIm = (I4 - GM[0]) / 2
# ------------------------------------------------------------------------------------------------ polynomials in one variable (the scalar model)
def p_add(*terms):
    n = max((len(p) for _, p in terms), default=0); out = [Fr(0)] * n
    for c, p in terms:
        for i, x in enumerate(p): out[i] += c * x
    while out and out[-1] == 0: out.pop()
    return out
def p_mul(a, b):
    if not a or not b: return []
    out = [Fr(0)] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b): out[i + j] += x * y
    return p_add((1, out))
def p_shift(p, c):
    """p(t + c)"""
    out = []
    for d, x in enumerate(p):
        out = p_add((1, out), (x, [Fr(comb(d, k)) * Fr(c) ** (d - k) for k in range(d + 1)]))
    return out
def p_der(p): return p_add((1, [Fr(i) * x for i, x in enumerate(p)][1:]))
def p_int(p): return p_add((1, [Fr(0)] + [x / (i + 1) for i, x in enumerate(p)]))
def p_val(p, t): return sum(x * Fr(t) ** i for i, x in enumerate(p))
def p_defint(p, a, b):
    """int_a^b p(s) ds with a, b polynomials in t (the result a polynomial in t)"""
    P = p_int(p)
    def comp(P, q):
        out = []; pw = [Fr(1)]
        for i, x in enumerate(P):
            if i: pw = p_mul(pw, q)
            out = p_add((1, out), (x, pw))
        return out
    return p_add((1, comp(P, b)), (-1, comp(P, a)))

head('(1) [en·DELAY, en·OSC] the one-dimensional model (2.1): the Noether energy of a delay Lagrangian, exact on piecewise polynomial solutions; when it oscillates, and its toys with a mass term')
# L = y(t) (x'(t) + k x(t - r)): x obeys (2.1), y the advanced adjoint y'(t) = k y(t + r).  The Noether energy of the time translation:
# E = h - int_{t-r}^{t} (dL/dx_r)(s + r) x'(s) ds = -k y(t) x(t - r) - k int_{t-r}^{t} y(s + r) x'(s) ds.
import random
rng = random.Random(20261016)
def delay_run(k, r, N, gx, gy):
    """method of steps, exact: x on [j r, (j+1) r] for j = -1 (history gx) ... N-1; y on [j r, (j+1) r] for j = N (data gy) down to 0"""
    X = {-1: gx}; Y = {N: gy}
    for j in range(0, N):                                                       # x(t) = x(j r) - k int_{j r}^{t} x(s - r) ds
        prev = p_shift(X[j - 1], -r); xj = p_val(X[j - 1], j * r)
        X[j] = p_add((1, [xj]), (-k, p_defint(prev, [Fr(j * r)], [Fr(0), Fr(1)])))
    for j in range(N - 1, -1, -1):                                              # y(t) = y((j+1) r) - k int_t^{(j+1) r} y(s + r) ds
        nxt = p_shift(Y[j + 1], r); yj = p_val(Y[j + 1], (j + 1) * r)
        Y[j] = p_add((1, [yj]), (-k, p_defint(nxt, [Fr(0), Fr(1)], [Fr((j + 1) * r)])))
    E = {}; Eloc = {}
    for j in range(0, N):                                                       # t in [j r, (j+1) r]
        loc = p_mul(p_add((-k, Y[j])), p_shift(X[j - 1], -r))
        if fault('SAMETIME'):                                                   # y(s) x'(s): the pairing at one instant
            f1 = p_mul(Y[j - 1] if j >= 1 else Y[0], p_der(X[j - 1]))
            f2 = p_mul(Y[j], p_der(X[j]))
        else:
            f1 = p_mul(p_shift(Y[j], r), p_der(X[j - 1]))                       # s in [t - r, j r]: x piece j-1, y(s + r) piece j
            f2 = p_mul(p_shift(Y[j + 1], r), p_der(X[j]))                       # s in [j r, t]: x piece j, y(s + r) piece j+1
        bil = p_add((1, p_defint(f1, [Fr(-r), Fr(1)], [Fr(j * r)])), (1, p_defint(f2, [Fr(j * r)], [Fr(0), Fr(1)])))
        Eloc[j] = loc
        E[j] = loc if fault('NOBILOCAL') else p_add((1, loc), (-k, bil))
    return X, Y, E, Eloc
okE = True; okL = True; consts = []; runs = 0
for k, r in ((Fr(1, 2), Fr(1)), (Fr(3, 2), Fr(1)), (Fr(-2, 3), Fr(1)), (Fr(9, 4), Fr(2, 3))):
    for seed in range(3):
        gx = [Fr(rng.randint(-5, 5)) for _ in range(4)]; gy = [Fr(rng.randint(-5, 5)) for _ in range(4)]
        X, Y, E, Eloc = delay_run(k, r, 4, gx, gy); runs += 1
        vals = [E[j] for j in range(4)]
        okE &= all(len(v) <= 1 for v in vals) and all(v == vals[0] for v in vals)
        okL &= any(len(v) > 1 for v in Eloc.values())
        consts.append((k, r, gx, gy, (vals[0][0] if vals[0] else Fr(0))))
chk('bit', okE, 'en.DELAY: (2.1) with k r = mu in {1/2, 3/2, -2/3, 3/2} (r = 1, 1, 1, 2/3), %d runs of polynomial history data (degree 3, integer coefficients) for x on [-r, 0] and for y on [4r, 5r]: the method of steps gives x and y exactly on [0, 4r], and E(t) = -k y(t) x(t - r) - k int_{t-r}^{t} y(s + r) x\'(s) ds is one constant on all four intervals, as a polynomial identity in t' % runs)
chk('ctl', okL, 'en.DELAY: the local part -k y(t) x(t - r) alone is not constant in any of the %d runs: the bilocal term is what is conserved with it' % runs)
# the standard route: roots of z = mu e^z by the Lambert W function, exponential solutions, scipy quad; generic data by solve_ivp
def cquad(f, a, b):
    re = quad(lambda s_: f(s_).real, a, b, epsabs=1e-14, epsrel=1e-13, limit=200)[0]
    im = quad(lambda s_: f(s_).imag, a, b, epsabs=1e-14, epsrel=1e-13, limit=200)[0]
    return re + 1j * im
def delay_energy_num(k, r, x, dx, y, t):
    """E(t) = -k y(t) x(t - r) - k int_{t-r}^{t} y(s + r) x'(s) ds, numerically; NOBILOCAL and SAMETIME as in the exact route"""
    loc = -k * y(t) * x(t - r)
    if fault('NOBILOCAL'): return loc
    if fault('SAMETIME'): return loc - k * cquad(lambda s_: y(s_) * dx(s_), t - r, t)
    return loc - k * cquad(lambda s_: y(s_ + r) * dx(s_), t - r, t)
worst = 0.0; worst_x = 0.0; nroots = 0; okloc = True
for mu, r in ((0.3, 1.0), (1.5, 1.0), (-0.8, 0.5), (4.0, 2.0)):
    k = mu / r
    zs = [complex(-lambertw(-mu, b)) for b in range(-2, 3)]
    zs = [z for z in zs if abs(z - mu * np.exp(z)) < 1e-12 * max(1, abs(z))]; nroots += len(zs)
    for i, z1 in enumerate(zs):
        for z2 in zs[i + 1:]:
            a1, a2, b1, b2 = 1.0, -0.7 + 0.4j, 0.6, 1.3 - 0.2j
            x = lambda t, z1=z1, z2=z2: a1 * np.exp(-z1 * t / r) + a2 * np.exp(-z2 * t / r)
            dx = lambda t, z1=z1, z2=z2: -(z1 / r) * a1 * np.exp(-z1 * t / r) - (z2 / r) * a2 * np.exp(-z2 * t / r)
            y = lambda t, z1=z1, z2=z2: b1 * np.exp(z1 * t / r) + b2 * np.exp(z2 * t / r)
            want = a1 * b1 * (z1 / r) * (z1 - 1) + a2 * b2 * (z2 / r) * (z2 - 1)
            for t in (0.0, 0.37 * r, 1.9 * r):
                worst = max(worst, abs(delay_energy_num(k, r, x, dx, y, t) - want) / max(1.0, abs(want)))
            okloc &= abs(-k * y(0.37 * r) * x(-0.63 * r) - (-k * y(1.9 * r) * x(0.9 * r))) > 1e-6
            xc = lambda t, z1=z1: np.exp(-z1 * t / r); dxc = lambda t, z1=z1: -(z1 / r) * np.exp(-z1 * t / r); yc = lambda t, z2=z2: np.exp(z2 * t / r)
            worst_x = max(worst_x, max(abs(delay_energy_num(k, r, xc, dxc, yc, t)) for t in (0.2, 1.3)))
chk('std', worst < 1e-10 and worst_x < 1e-10, 'en.DELAY: scipy lambertw, %d roots of z = mu e^z (mu = 0.3, 1.5, -0.8, 4; branches -2..2), sums of two roots x = a1 e^{-z1 t/r} + a2 e^{-z2 t/r}, y = b1 e^{z1 t/r} + b2 e^{z2 t/r}: E(t) by quad at three times equals a1 b1 (z1/r)(z1 - 1) + a2 b2 (z2/r)(z2 - 1) (relative %.1e), and the cross pairing x = e^{-z1 t/r}, y = e^{z2 t/r} has E = 0 (%.1e)' % (nroots, worst, worst_x))
chk('ctl', okloc, 'en.DELAY: on the same sums the local part alone changes between t = 0.37 r and t = 1.9 r')
# generic smooth data, numerically: history x = cos 2t + t/3 on [-1, 0], data y = sin t + 1/5 on [3, 4], k = 0.7, r = 1
kk, rr = 0.7, 1.0
hist = lambda t: np.cos(2 * t) + t / 3; dhist = lambda t: -2 * np.sin(2 * t) + 1 / 3
ydat = lambda t: np.sin(t) + 0.2
xs = {-1: (hist, dhist)}; ysol = {3: ydat}
for j in range(0, 3):
    f_prev = xs[j - 1][0]; x0 = f_prev(j * rr) if j else hist(0.0)
    sol = solve_ivp(lambda t, u, f_prev=f_prev: [-kk * f_prev(t - rr)], (j * rr, (j + 1) * rr), [x0], rtol=1e-12, atol=1e-14, dense_output=True)
    xs[j] = (lambda t, sol=sol: sol.sol(t)[0], lambda t, f_prev=f_prev: -kk * f_prev(t - rr))
for j in range(2, -1, -1):
    g_next = ysol[j + 1]
    sol = solve_ivp(lambda t, u, g_next=g_next: [kk * g_next(t + rr)], ((j + 1) * rr, j * rr), [g_next((j + 1) * rr)], rtol=1e-12, atol=1e-14, dense_output=True)
    ysol[j] = lambda t, sol=sol: sol.sol(t)[0]
def xpw(t): return xs[min(2, max(-1, int(np.floor(t / rr))))][0](t)
def dxpw(t): return xs[min(2, max(-1, int(np.floor(t / rr))))][1](t)
def ypw(t): return ysol[min(3, max(0, int(np.floor(t / rr))))](t)
def E_generic(t):
    loc = -kk * ypw(t) * xpw(t - rr)
    if fault('NOBILOCAL'): return loc
    g = (lambda s_: ypw(s_) * dxpw(s_)) if fault('SAMETIME') else (lambda s_: ypw(s_ + rr) * dxpw(s_))
    pts = [p_ for p_ in np.arange(-1.0, 4.0, 1.0) if t - rr < p_ < t]
    return loc - kk * quad(g, t - rr, t, points=pts or None, epsabs=1e-13, epsrel=1e-12, limit=200)[0]
Eg = [E_generic(t) for t in (0.25, 1.1, 1.9, 2.75)]
chk('std', max(Eg) - min(Eg) < 1e-8, 'en.DELAY: generic smooth data (x = cos 2t + t/3 on [-1, 0], y = sin t + 1/5 on [3, 4], k = 0.7, r = 1), the method of steps by scipy solve_ivp (rtol 1e-12): E(t) at t = 0.25, 1.1, 1.9, 2.75 by quad is %.10f, spread %.1e' % (Eg[0], max(Eg) - min(Eg)))
# bit == std: the exact constant of one polynomial run against the same formula in floats with quad on the exact pieces
k0, r0, gx0, gy0, c0 = consts[0]
X0, Y0, _, _ = delay_run(k0, r0, 4, gx0, gy0)
fx = lambda t: float(p_val(X0[min(3, max(-1, int(np.floor(t))))], Fr(t)))
fdx = lambda t: float(p_val(p_der(X0[min(3, max(-1, int(np.floor(t))))]), Fr(t)))
fy = lambda t: float(p_val(Y0[min(4, max(0, int(np.floor(t))))], Fr(t)))
Ef = [-float(k0) * fy(t) * fx(t - 1) - float(k0) * quad(lambda s_: fy(s_ + 1) * fdx(s_), t - 1, t, points=[p_ for p_ in (0.0, 1.0, 2.0, 3.0) if t - 1 < p_ < t], epsabs=1e-13, limit=200)[0] for t in (0.4, 2.3)]
chk('bit==std', max(abs(e_ - float(c0)) for e_ in Ef) < 1e-9 * max(1.0, abs(float(c0))), 'en.DELAY: the exact constant %s of the first polynomial run equals the float formula with quad at t = 0.4, 2.3 (%.1e)' % (c0, max(abs(e_ - float(c0)) for e_ in Ef)))

# en.OSC: when (2.1) oscillates without growth, and the one-dimensional toys with a mass term (the halves at rest of (2): x' + i m x + shift terms)
ok_q = True; qdesc = []
for j in range(1, 9):
    om = PI * Fr(j, 2); ph = phase(Fr(j, 2), PI)                                 # omega r = j pi/2 with r = 1; e^{J omega r} exactly
    res = lambda k_, om=om, ph=ph: mlin((-1, mlin((om, J))), (k_, ph))            # x = e^{-J omega t}: x' + k x(t - r) = (-J omega + k e^{J omega r}) x
    if j % 2:
        s_ = zim(ph); ok_q &= not res(om * s_)                                     # k = s omega, mu = k r = (-1)^n (n + 1/2) pi
        if j <= 5: qdesc.append(fmt_q(om * s_))
    else:
        ok_q &= zim(res(UNIT)) == -om and zim(res(-UNIT)) == -om and bool(om)    # the J part -omega stays for every real k
chk('bit', ok_q, 'en.OSC: in the J-plane of the labels, exactly in Q[pi]: x = e^{-J omega t} solves (2.1) with omega r = j pi/2 (j = 1 ... 8) exactly when j is odd, cos(omega r) = 0, with k = (-1)^n omega at omega r = (n + 1/2) pi (mu = k r = %s, ...): the delay is an odd number of quarter periods, the condition cos E tau = 0 of the quantization (2.6); at even j the J part -omega remains for every real k' % ', '.join(qdesc))
TOYS = [('O', 4, 1, [3, 5]), ('H', 4, 1, [3, 4, 5]), ('Ds', 4, 1, [4]), ('Dc_u', 3, 1, [3]), ('Dc_p', 3, 1, [2, 3, 4])]
ok_toy = True; toy_exact = {}
for key, m_, kap, want in TOYS:
    OP = ops(m_, kap, PI / 2)
    for sec, Z in ((-1, blade(PPLUS[1])), (1, blade(PMINUS[1]))):
        zs = [E_ for E_ in range(0, 10) if not apply_op(OP[key], mode(E_, Z, sec))]
        ok_toy &= zs == want and all(zre(phase(E_, PI / 2)) == 0 for E_ in zs) == (key in ('O', 'Dc_u'))
        toy_exact[key] = zs
chk('bit', ok_toy, 'en.OSC: the toys with a mass term are the halves at rest of (2); on E = 0 ... 9 at tau = pi/2, both halves, exactly: the paper\'s D_+ at (m, kappa) = (4, 1) oscillates at E = 3, 5 and D_c read uniformly at (3, 1) at E = 3, all on the lattice cos E tau = 0; the Hermitian half H at (4, 1) at E = 3, 4, 5, D_s at (4, 1) at E = 4 and D_c as printed at (3, 1) at E = 2, 3, 4, with roots off the lattice: the sorting of ATY-007 (shd.VAR) on the one-dimensional equations')
def toy_fn(key, m_, kap, tf):
    """the toy x = e^{-i E t} on the upper half at rest: f(E) and f'(E) (complex; numpy, no label)"""
    if key == 'O': return (lambda E: E - m_ + 1j * kap * np.exp(1j * E * tf)), (lambda E: 1 - kap * tf * np.exp(1j * E * tf))
    if key == 'H':
        sg = -1 if fault('SINHSIGN') else 1
        return (lambda E: E - m_ - sg * kap * np.sin(E * tf)), (lambda E: 1 - sg * kap * tf * np.cos(E * tf))
    if key == 'Ds': return (lambda E: E - m_ + kap * np.sin(E * tf)), (lambda E: 1 + kap * tf * np.cos(E * tf))
    if key == 'Dc_u': return (lambda E: E - m_ + 1j * kap * np.cos(E * tf)), (lambda E: 1 - 1j * kap * tf * np.sin(E * tf))
    return (lambda E: E - m_ - kap * np.cos(E * tf)), (lambda E: 1 + kap * tf * np.sin(E * tf))
def toy_real_roots(key, m_, kap, tf, lo=0.0, hi=10.0):
    """real frequencies of the toy: complex Newton from the minima of |f| on a grid; a root is real when its imaginary part vanishes"""
    f, fp = toy_fn(key, m_, kap, tf); Eg = np.linspace(lo, hi, 20001); g = np.abs(f(Eg + 0j)); out = []
    for i in range(1, len(Eg) - 1):
        if g[i] <= g[i - 1] and g[i] <= g[i + 1] and g[i] < 5e-2:
            z = complex(Eg[i])
            for _ in range(60):
                d_ = f(z) / fp(z); z -= d_
                if abs(d_) < 1e-15: break
            if abs(f(z)) < 1e-12 and abs(z.imag) < 1e-9 and lo <= z.real <= hi and all(abs(z.real - w) > 1e-7 for w in out): out.append(z.real)
    return sorted(out)
def toy_sym(key, E, m_, kap, tf):
    """the 4 x 4 symbol of the operator on rest waves u e^{-i E t} (Dirac matrices, scipy expm), the variants as in shifted_dirac.py"""
    K = E * GM[0]; Ex = expm(1j * tf * K); Exi = expm(-1j * tf * K)
    return {'O': K - m_ * I4 + 1j * kap * Ex, 'H': K - m_ * I4 - 1j * kap * (Exi - Ex) / 2, 'Ds': K - m_ * I4 + 1j * kap * (Exi - Ex) / 2,
            'Dc_u': K - m_ * I4 + 1j * kap * (Exi + Ex) / 2, 'Dc_p': K - m_ * I4 - kap * (Exi + Ex) / 2}[key]
toy_std = {}; ok_tk = True
for key, m_, kap, want in TOYS:
    rq, rg_ = toy_real_roots(key, m_, kap, np.pi / 2), toy_real_roots(key, m_, kap, 1.3); toy_std[key] = (rq, rg_)
    for E_, tf in [(x, np.pi / 2) for x in rq] + [(x, 1.3) for x in rg_]:
        sv = np.linalg.svd(toy_sym(key, E_, m_, kap, tf), compute_uv=False); ok_tk &= int(np.sum(sv < 1e-8)) == 2
ok_ts = not toy_std['O'][1] and not toy_std['Dc_u'][1] and all(len(toy_std[k_][1]) >= 1 for k_ in ('H', 'Ds', 'Dc_p'))
chk('std', ok_ts and ok_tk, 'en.OSC: numpy, the same toys as complex functions of a real frequency (complex Newton from a grid on [0, 10]): at the generic shift tau = 1.3 D_+ and D_c read uniformly have no oscillating solution, while H, D_s and D_c as printed have one each (E = %s); at every real root found, at tau = pi/2 and 1.3, the 4 x 4 symbol (Dirac matrices, scipy expm) has a 2-dimensional kernel' % ', '.join('%.6f' % toy_std[k_][1][0] for k_ in ('H', 'Ds', 'Dc_p') if toy_std[k_][1]))
ok_im = True; ok_off = True; offmin = 9.0
for n_ in range(3):
    mu = (-1) ** n_ * (n_ + 0.5) * np.pi
    zs = [complex(-lambertw(-mu, b)) for b in range(-3, 4)]; zs = [z for z in zs if abs(z - mu * np.exp(z)) < 1e-9 * max(1, abs(z))]
    zi = [z for z in zs if abs(z.real) < 1e-12]
    ok_im &= len(zi) == 2 and all(abs(abs(z.imag) - (n_ + 0.5) * np.pi) < 1e-12 for z in zi)
for mu in (1.0, 2.0, np.pi / 2 + 0.05, np.pi / 2 - 0.05, -1.0):
    zs = [complex(-lambertw(-mu, b)) for b in range(-3, 4)]; zs = [z for z in zs if abs(z - mu * np.exp(z)) < 1e-9 * max(1, abs(z))]
    offmin = min(offmin, min(abs(z.real) for z in zs)); ok_off &= len(zs) == 7
chk('std', ok_im, 'en.OSC: scipy lambertw, the roots of z = mu e^z on the branches -3 ... 3: at mu = pi/2, -3 pi/2, 5 pi/2 exactly one pair z = +-i (n + 1/2) pi has |Re z| < 1e-12: x = e^{-z t/r} oscillates without growth, the delay r an odd number of quarter periods of it')
chk('ctl', ok_off and offmin > 1e-3, 'en.OSC: at mu = 1, 2, pi/2 + 0.05, pi/2 - 0.05, -1, where the delay is not an odd quarter period, all seven roots on the same branches have |Re z| >= %.3f: growth or decay' % offmin)
ok_eq = all(len(toy_std[key][0]) == len(want) and all(abs(a - b) < 1e-9 for a, b in zip(toy_std[key][0], want)) and toy_exact[key] == want for key, m_, kap, want in TOYS)
chk('bit==std', ok_eq, 'en.OSC: at tau = pi/2 the real frequencies of the five toys found by numpy agree (1e-9) with the exact ones on the labels: ' + '; '.join('%s %s' % ({'O': 'D_+', 'H': 'H', 'Ds': 'D_s', 'Dc_u': 'D_c (uniform)', 'Dc_p': 'D_c (printed)'}[k_], toy_exact.get(k_)) for k_, _, _, _ in TOYS))

head('(2) [en·REST] the shifted operators on fields of the frame time alone: exp(-tau bD) retards P_+ and advances P_-; Atiyah\'s one-dimensional equations as halves')
def rf_bD(F, fr): return fadd((QP.of(fr), f_lmul(G0, rf_rmul(rf_deriv(F), G0))))
def rf_series(F, tau, fr, parity=None):
    """sum_n (-tau)^n bD^n F / n! over the n of the given parity (None: all, exp(-tau bD); 'even': cosh(tau bD); 'odd': -sinh(tau bD));
    exact on polynomial fields, where bD^n F = 0 beyond the degree"""
    out = {}; cur = F; n = 0; tq = QP.of(tau); tn = UNIT
    while cur:
        if parity is None or (parity == 'even') == (n % 2 == 0):
            out = fadd((1, out), (tn * Fr((-1) ** n, math.factorial(n)), cur))
        cur = rf_bD(cur, fr); n += 1; tn = tn * tq
    return out
def rand_poly_field(rg, deg, blades=EVEN, lo=-3, hi=3):
    F = {}
    for d in range(deg + 1):
        Z = {m_: QP(rg.randint(lo, hi)) for m_ in blades}; Z = {m_: v for m_, v in Z.items() if v}
        if Z: F[(Fr(0), d)] = Z
    return F
ok_ser = True; ok_ops = True; ok_split = True; nf = 0
for tau, fr in ((Fr(1, 2), 1), (Fr(-2, 3), 1), (Fr(3, 4), Fr(5, 3))):
    for seed in range(3):
        rg = random.Random(1000 + seed); P = rand_poly_field(rg, 5); nf += 1
        Pp, Pm = rf_split(P); d = QP.of(tau) * fr
        ret = fadd((1, rf_shift(Pp, -d)), (1, rf_shift(Pm, d)))
        ok_ser &= rf_series(P, tau, fr) == ret
        ok_ser &= rf_series(P, tau, fr, 'even') == fadd((Fr(1, 2), rf_shift(P, d)), (Fr(1, 2), rf_shift(P, -d)))
        ok_ser &= rf_series(P, tau, fr, 'odd') == fadd((Fr(-1, 2), f_lmul(G0, rf_rmul(fadd((1, rf_shift(P, d)), (-1, rf_shift(P, -d))), G0))))
        m_, kap = Fr(3), Fr(2); OP = ops(m_, kap, tau, fr)
        base = fadd((1, rf_rmul(rf_bD(P, fr), J)), (-m_, P))
        ok_ops &= apply_op(OP['O'], P) == fadd((1, base), (kap, rf_rmul(rf_series(P, tau, fr), J)))
        ok_ops &= apply_op(OP['A'], P) == fadd((kap, rf_rmul(rf_series(P, tau, fr, 'even'), J)))
        ok_ops &= apply_op(OP['H'], P) == fadd((1, base), (kap, rf_rmul(rf_series(P, tau, fr, 'odd'), J)))      # - kappa sinh = kappa (odd part)
        ok_split &= apply_op(OP['O'], P) == fadd((1, apply_op(OP['H'], P)), (1, apply_op(OP['A'], P)))
chk('bit', ok_ser, 'en.REST: on %d polynomial fields P(t) (8 even blades, degree 5, integer coefficients; tau = 1/2, -2/3 with fr = 1 and tau = 3/4 with the frame factor 5/3), the power series of bD(P) = fr gamma_0 P\' gamma_0 give exactly exp(-tau bD) P = P_+(t - fr tau) + P_-(t + fr tau), cosh(tau bD) P = (P(t + fr tau) + P(t - fr tau))/2 and sinh(tau bD) P = gamma_0 (P(t + fr tau) - P(t - fr tau)) gamma_0 / 2' % nf)
chk('bit', ok_ops, 'en.REST: the shift-term forms of the paper\'s operator O = bD J - m + kappa exp(-tau bD) J, of H = bD J - m - kappa (sinh tau bD) J and of A = kappa (cosh tau bD) J equal their series on the same fields (m = 3, kappa = 2)')
chk('bit', ok_split, 'en.REST: O = H + A on the same fields: the Hermitian half is the sinh variant with kappa -> -kappa (D_s of ATY-007 with the sign turned), the anti-Hermitian half the cosh variant')
# the halves: X(t) polynomial in P_+ (resp. P_-), m tau in (pi/2) Z
def at_freq(F, beta): return {(Fr(beta), d): Z for (b, d), Z in F.items()}
ok_red = True; ok_adv = True; ok_var = True; cases = []
for m_, tau, kap in ((4, PI / 2, Fr(1)), (3, PI / 2, Fr(2)), (4, 3 * PI / 2, Fr(-1, 2))):
    OP = ops(m_, kap, tau)
    ph = phase(m_, tau)                                                         # e^{J m tau}
    for seed in range(2):
        rg = random.Random(77 + seed)
        X = rand_poly_field(rg, 3, PPLUS); Xm = rand_poly_field(rg, 3, PMINUS)
        lhs = apply_op(OP['O'], at_freq(X, -m_))
        rhs = rf_rmul(at_freq(fadd((1, rf_deriv(X)), (kap, f_rmul(rf_shift(X, -tau), ph))), -m_), J)
        ok_red &= lhs == rhs                                                    # O[X e^{-J m t}] = [X' + kappa X(t - tau) e^{J m tau}] e^{-J m t} J
        lhs = apply_op(OP['O'], at_freq(Xm, m_))
        rhs = rf_rmul(at_freq(fadd((-1, rf_deriv(Xm)), (kap, f_rmul(rf_shift(Xm, tau), ph))), m_), J)
        ok_adv &= lhs == rhs                                                    # O[X e^{+J m t}] = [-X' + kappa X(t + tau) e^{J m tau}] e^{J m t} J
        phc = phase(-m_, tau)                                                   # e^{-J m tau}
        sym = fadd((1, f_rmul(rf_shift(X, -tau), ph)), (1, f_rmul(rf_shift(X, tau), phc)))
        anti = fadd((1, f_rmul(rf_shift(X, tau), phc)), (-1, f_rmul(rf_shift(X, -tau), ph)))
        ok_var &= apply_op(OP['Dc_u'], at_freq(X, -m_)) == rf_rmul(at_freq(fadd((1, rf_deriv(X)), (kap / 2, sym)), -m_), J)
        ok_var &= apply_op(OP['Dc_p'], at_freq(X, -m_)) == rf_rmul(at_freq(fadd((1, rf_deriv(X)), (kap / 2, f_rmul(sym, J))), -m_), J)
        ok_var &= apply_op(OP['Ds'], at_freq(X, -m_)) == rf_rmul(at_freq(fadd((1, rf_deriv(X)), (kap / 2, anti)), -m_), J)
chk('bit', ok_red, 'en.REST: for X(t) in the half P_+ (polynomial, degree 3, two fields each), O[X e^{-J m t}] = [X\' + kappa X(t - tau) e^{J m tau}] e^{-J m t} J exactly in Q[pi] at (m, tau, kappa) = (4, pi/2, 1), (3, pi/2, 2), (4, 3pi/2, -1/2): the P_+ half of the paper\'s equation at rest is (2.1) with k = kappa e^{J m tau}, the equation (2.1) itself when m tau is in 2 pi Z')
chk('bit', ok_adv, 'en.REST: for X(t) in the half P_-, O[X e^{+J m t}] = [-X\' + kappa X(t + tau) e^{J m tau}] e^{J m t} J: the P_- half is the advanced equation X\' = kappa e^{J m tau} X(t + tau), the adjoint of (2.1) (the y-equation of (1)) when m tau is in 2 pi Z')
chk('bit', ok_var, 'en.REST: on the P_+ half at rest, D_c read as D + kappa cosh(tau D) gives X\' + (kappa/2)(X(t - tau) e^{J m tau} + X(t + tau) e^{-J m tau}) = 0, which is (2.17) with k = kappa/2 when m tau is in 2 pi Z; D_c as printed (D + i kappa cosh) gives the same with k = (kappa/2) J; D_s gives the difference equation X\' + (kappa/2)(X(t + tau) e^{-J m tau} - X(t - tau) e^{J m tau}) = 0')
# the standard route: column spinors in the Dirac representation, exp(-tau gamma^0 d_t) on Fourier modes by scipy expm
rgn = np.random.default_rng(5)
omegas = [-3.1, 0.7, 2.2]; cvec = [rgn.normal(size=4) + 1j * rgn.normal(size=4) for _ in omegas]
psi_n = lambda t: sum(c_ * np.exp(-1j * w * t) for c_, w in zip(cvec, omegas))
dev = 0.0
for tau_f in (0.5, 1.3, -0.8):
    for t in (0.0, 0.9, 2.4):
        Ex = sum(expm(1j * tau_f * w * GM[0]) @ c_ * np.exp(-1j * w * t) for c_, w in zip(cvec, omegas))   # exp(-tau gamma^0 d_t) on e^{-i w t}
        Ch = sum((expm(1j * tau_f * w * GM[0]) + expm(-1j * tau_f * w * GM[0])) / 2 @ c_ * np.exp(-1j * w * t) for c_, w in zip(cvec, omegas))
        dev = max(dev, np.abs(Ex - (PIp @ psi_n(t - tau_f) + PIm @ psi_n(t + tau_f))).max(), np.abs(Ch - (psi_n(t + tau_f) + psi_n(t - tau_f)) / 2).max())
chk('std', dev < 1e-12, 'en.REST: Dirac matrices, a three-frequency spinor field of t: exp(-tau gamma^0 d_t) by scipy expm on each Fourier mode equals Pi_+ psi(t - tau) + Pi_- psi(t + tau), Pi_+- = (1 +- gamma^0)/2 (upper components retarded, lower advanced), and cosh(tau gamma^0 d_t) the symmetric shift, at tau = 0.5, 1.3, -0.8 and three times (max deviation %.1e)' % dev)
# bit == std: the factor of the shift on a rest mode, e^{J E tau} on the labels and e^{i E tau} from expm, both halves
cmp_ = []
for E_, tau in ((5, PI / 10), (3, PI / 2), (1, 3 * PI / 2), (Fr(5, 3), 3 * PI / 10)):
    for sec, blades_ in ((-1, PPLUS), (1, PMINUS)):
        Z = {m_: QP(i + 1) for i, m_ in enumerate(blades_)}; P = mode(E_, Z, sec); Q = rf_rev(P)
        z = cf_const(pair(Q, fadd((1, rf_shift(rf_split(P)[0], -QP.of(tau))), (1, rf_shift(rf_split(P)[1], QP.of(tau))))))
        rho = scal(mmul(mrev(Z), Z)); zz = complex(float(zre(z)) / float(rho), float(zim(z)) / float(rho))
        u = np.array([1, 0.5 - 1j, 0, 0], complex) if sec == -1 else np.array([0, 0, 1, 0.5 - 1j], complex)
        w = -sec * float(E_)                                                    # e^{-i w t} with w = E (upper), -E (lower)
        uu = u.conj() @ GM[0] @ expm(1j * float(tau) * w * GM[0]) @ u / (u.conj() @ GM[0] @ u)
        cmp_.append(abs(zz - uu))
chk('bit==std', max(cmp_) < 1e-12, 'en.REST: on rest modes of both halves (E tau = pi/2, 3pi/2, 3pi/2, pi/2) the factor <P~ exp(-tau bD) P>_S / <P~ P>_0 = e^{J E tau} on the labels equals u-bar exp(-tau D) u / u-bar u = e^{i E tau} from expm (J <-> i), max deviation %.1e' % max(cmp_))

def qrank(vecs):
    keys = sorted({m_ for v in vecs for m_ in v}); M = [[v.get(k, ZERO) for v in vecs] for k in keys]
    for row in M:
        for x in row: assert x.rational()
    M = [[x.c.get(0, Fr(0)) for x in row] for row in M]; rank = 0
    for j in range(len(vecs)):
        pr = next((i for i in range(rank, len(M)) if M[i][j] != 0), None)
        if pr is None: continue
        M[rank], M[pr] = M[pr], M[rank]; inv = 1 / M[rank][j]; M[rank] = [x * inv for x in M[rank]]
        for i in range(len(M)):
            if i != rank and M[i][j] != 0: f = M[i][j]; M[i] = [x - f * y for x, y in zip(M[i], M[rank])]
        rank += 1
    return rank
def span_eq(U, V): return len(U) == len(V) and qrank(U) == len(U) and qrank(U + V) == len(U)
head('(3) [en·NOETHER] the Noether energy of the shifted Dirac action on fields of the frame time: the canonical part and the bilocal (Wronskian) part')
# L = <Q O[P]>_S with Q an independent conjugate field (on solutions Q = P~, the reverse: the Dirac conjugate psi-bar); its Euler-Lagrange
# equations are O[P] = 0 (varying Q) and Y = 0 (varying P, the adjoint: R Q(t + delta) L summed, minus the derivative of the kinetic part).
# The Noether energy of t -> t + epsilon: E = h - sum over shifted terms of int_{t-delta}^{t} c <Q(s + delta) L P'(s) R>_S ds, h = <Q fr gamma_0 P' gamma_0 J>_S - L;
# the Noether number of P -> P e^{J alpha}, Q -> e^{-J alpha} Q the same with P' replaced by P J (sign: E = omega N on e^{-J omega t}).
# Off shell: dE/dt = -<Q' O[P]>_S - <Y P'>_S and dN/dt = <Y P J>_S - <J Q O[P]>_S, exactly; so both are conserved where both equations hold.
def rand_poly_lfield(rg, deg):
    return {(Fr(0), d): Z for (b, d), Z in rand_poly_field(rg, deg).items()}
ok_idE = True; ok_idN = True; nid = 0
for tau, fr in ((Fr(1, 2), 1), (Fr(-2, 3), 1), (Fr(3, 4), Fr(5, 3))):
    OP = ops(3, 2, tau, fr)
    for iname, name in enumerate(('O', 'H', 'A', 'Dc_u', 'Ds')):
        for seed in range(2):
            rg = random.Random(4000 + 17 * seed + 101 * iname + int(10 * float(tau))); P = rand_poly_field(rg, 3); Q = rand_poly_lfield(rg, 3); nid += 1
            T = OP[name]; E, _, _ = noether(T, P, Q); N, _, _ = noether(T, P, Q, 'phase')
            Y = adjoint_op(T, Q); OPP = apply_op(T, P)
            ok_idE &= cf_deriv(E) == fadd((-1, pair(lf_deriv(Q), OPP)), (-1, pair(Y, rf_deriv(P))))
            ok_idN &= cf_deriv(N) == fadd((1, pair(Y, rf_rmul(P, J))), (-1, pair(lf_lmul(J, Q), OPP)))
chk('bit', ok_idE, 'en.NOETHER: off shell, on %d pairs of independent polynomial fields (P, Q) of degree 3 (tau = 1/2, -2/3 at fr = 1; tau = 3/4 at fr = 5/3; m = 3, kappa = 2), for the operators O, H, A, D_c (uniform) and D_s: dE/dt = -<Q\' O[P]>_S - <Y P\'>_S exactly, E the canonical part minus the bilocal integrals over the delay intervals: E is conserved wherever O[P] = 0 and Y = 0' % nid)
chk('bit', ok_idN, 'en.NOETHER: on the same pairs the Noether number of the phase P -> P e^{J alpha} satisfies dN/dt = <Y P J>_S - <J Q O[P]>_S exactly')
# the quantized rest modes: the kernel of O on e^{-+J E t}, the adjoint on P~, the values
def kernel_rest(T, E_, sec):
    """the even Z with T[Z e^{sec J E t}] = 0, by exact elimination (the operator is rational on a quarter-turn mode)"""
    cols = []
    for m_ in EVEN:
        F = apply_op(T, mode(E_, blade(m_), sec)); cols.append(ratv(F))
    keys = sorted({k for c_ in cols for k in c_}, key=str)
    M = [[c_.get(k, Fr(0)) for c_ in cols] for k in keys]; piv = []; rank = 0
    for j in range(len(cols)):
        pr = next((i for i in range(rank, len(M)) if M[i][j] != 0), None)
        if pr is None: continue
        M[rank], M[pr] = M[pr], M[rank]; inv = 1 / M[rank][j]; M[rank] = [x * inv for x in M[rank]]
        for i in range(len(M)):
            if i != rank and M[i][j] != 0: f = M[i][j]; M[i] = [x - f * y for x, y in zip(M[i], M[rank])]
        piv.append(j); rank += 1
    basis = []
    for f in [j for j in range(len(cols)) if j not in piv]:
        x = [Fr(0)] * len(cols); x[f] = Fr(1)
        for r_, j in enumerate(piv): x[j] = -M[r_][f]
        basis.append({EVEN[j]: QP(x[j]) for j in range(len(cols)) if x[j] != 0})
    return basis
def zval(z): return complex(float(zre(z)), float(zim(z)))
def cval(z): return complex('nan') if z is None else zval(z)                     # a constant J-complex value, NaN when it is not constant
MODES = [(3, 2, 5, PI / 10, 0), (3, 2, 1, 3 * PI / 2, 1)]                         # (m, kappa, E, tau, n): E tau = (n + 1/2) pi, E = m + (-1)^n kappa
ok_ker = True; ok_adj = True; ok_val = True; ok_HA = True; nb = 0; table = []
for m_, kap, E_, tau, n in MODES:
    OP = ops(m_, kap, tau); mu = QP.of(kap) * tau; sgn = (-1) ** n
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        K = kernel_rest(OP['O'], E_, sec)
        ok_ker &= len(K) == 4 and span_eq(K, [blade(b) for b in half])
        for Z in K + ([mlin(*[(i + 2, z_) for i, z_ in enumerate(K)])] if K else []):
            P = mode(E_, Z, sec); Q = rf_rev(P); nb += 1
            ok_adj &= not adjoint_op(OP['O'], Q) and not apply_op(OP['O'], P)
            rho = scal(mmul(mrev(Z), Z)); E, loc, bil = noether(OP['O'], P, Q); N, _, _ = noether(OP['O'], P, Q, 'phase')
            Ec, Nc = cf_const(E), cf_const(N); om = -sec * E_                   # the wave is e^{-J om t}
            want = mlin((rho * E_, ONE), (-sgn * rho * E_ * mu, J))             # rho E (1 - (-1)^n mu J)
            ok_val &= Ec is not None and Ec == want and Nc is not None and mlin((om, Nc)) == Ec
            EH = cf_const(noether(OP['H'], P, Q)[0]); EA, locA, bilA = noether(OP['A'], P, Q)
            ok_HA &= EH == mlin((rho * E_, ONE)) and cf_const(EA) == mlin((-sgn * rho * E_ * mu, J)) and not locA
            if Z is K[0] and Ec is not None and Nc is not None: table.append('E = %s (n = %d, sector %+d): E_N = %s, N = %s' % (E_, n, sec, fmt_z(Ec), fmt_z(Nc)))
chk('bit', ok_ker, 'en.NOETHER: the kernel of the paper\'s operator on rest waves e^{-+J E t} at (m, kappa) = (3, 2), E = 5 with tau = pi/10 (n = 0) and E = 1 with tau = 3 pi/2 (n = 1): 4 real dimensions per sector, exactly the half P_+ (sector -1) or P_- (sector +1), the ordinary rest solutions')
chk('bit', ok_adj, 'en.NOETHER: on the %d mode fields (16 basis solutions and 4 sums) both Euler-Lagrange equations hold with Q = P~: O[P] = 0 and the adjoint Y = 0' % nb)
chk('bit', ok_val, 'en.NOETHER: on the same fields E(t) is constant and equals rho E_0 (1 - (-1)^n mu J), rho = <P~ P>_0, mu = kappa tau; the Noether number is N = |P|^2 (1 - (-1)^n mu J) and E = omega N for the wave e^{-J omega t}: ' + '; '.join(table))
chk('bit', ok_HA, 'en.NOETHER: split by halves, the Noether energy of H (Hermitian) is rho E_0 with no J part, and that of A (anti-Hermitian) is -(-1)^n mu rho E_0 J, all of it from the bilocal term (its local part kappa cos(E_0 tau) rho vanishes on the quantized modes)')
# the standard route: column spinors (Dirac representation), the same Lagrangian with psi-bar = psi^dagger gamma^0, scipy quad for the integrals
def col_ops(m, kap, tau, fr=1.0):
    """the rest-frame operators on column spinors: terms (M, e, delta, c) = c M psi^(e)(t - delta)"""
    d = tau * fr; kin = [(1j * fr * GM[0], 1, 0.0, 1.0)]; mass = [(I4, 0, 0.0, -float(m))]
    O = kin + mass + [(1j * kap * PIp, 0, d, 1.0), (1j * kap * PIm, 0, -d, 1.0)]
    sg = -1 if fault('SINHSIGN') else 1
    H = kin + mass + [(-0.5j * sg * kap * GM[0], 0, -d, 1.0), (0.5j * sg * kap * GM[0], 0, d, 1.0)]
    A = [(0.5j * kap * I4, 0, -d, 1.0), (0.5j * kap * I4, 0, d, 1.0)]
    return {'O': O, 'H': H, 'A': A}
class ColField:
    """psi(t) = sum u e^{-i w t}"""
    def __init__(self, comps): self.c = [(np.asarray(u, complex), float(w)) for u, w in comps]
    def __call__(self, t, e=0): return sum(((-1j * w) ** e) * u * np.exp(-1j * w * t) for u, w in self.c)
    def bar(self, t): return self(t).conj() @ GM[0]
def col_apply(T, psi, t): return sum(c * (M @ psi(t - de, e)) for M, e, de, c in T)
def col_noether(T, psi, t, gen=None, parts=False):
    K = (lambda s_: psi(s_, 1)) if gen is None else (lambda s_: 1j * psi(s_))
    loc = sum(c * (psi.bar(t) @ M @ K(t)) for M, e, de, c in T if e == 1)
    if gen is None: loc -= psi.bar(t) @ col_apply(T, psi, t)
    bil = 0j
    if not fault('NOBILOCAL'):
        for M, e, de, c in T:
            if e == 0 and de != 0:
                f = (lambda s_, M=M: psi.bar(s_) @ M @ K(s_)) if fault('SAMETIME') else (lambda s_, M=M, de=de: psi.bar(s_ + de) @ M @ K(s_))
                bil += c * cquad(f, t - de, t)
    out = loc - bil
    if parts: return (out, loc, bil) if gen is None else (-out, -loc, -bil)
    return -out if gen is not None else out
worst = 0.0; vals_std = {}
for m_, kap, E_, tau, n in MODES:
    tf = float(tau); mu_f = kap * tf; sgn = (-1) ** n; T = col_ops(m_, kap, tf)
    for sec in (-1, 1):
        u = np.array([1.0, 0.4 - 0.7j, 0, 0], complex) if sec == -1 else np.array([0, 0, 1.0, 0.4 - 0.7j], complex)
        w = -sec * E_; psi = ColField([(u, w)]); rho_f = (u.conj() @ GM[0] @ u).real; dens = (u.conj() @ u).real
        res = max(np.abs(col_apply(T['O'], psi, t)).max() for t in (0.0, 0.8))
        Es = [col_noether(T['O'], psi, t) for t in (0.0, 0.45, 1.7)]; Ns = col_noether(T['O'], psi, 0.3, 'phase')
        want = rho_f * E_ * (1 - 1j * sgn * mu_f)
        dev = max(max(abs(e_ - want) for e_ in Es) / abs(want), abs(Ns - dens * (1 - 1j * sgn * mu_f)) / dens, res)
        EH = col_noether(T['H'], psi, 0.2); EA = col_noether(T['A'], psi, 0.2)
        dev = max(dev, abs(EH - rho_f * E_) / abs(want), abs(EA - rho_f * E_ * (-1j * sgn * mu_f)) / abs(want))
        worst = max(worst, dev); vals_std[(E_, sec)] = Es[0] / rho_f
chk('std', worst < 1e-10, 'en.NOETHER: Dirac matrices with psi-bar = psi^dagger gamma^0 and scipy quad for the bilocal integrals, on the rest modes of the same (m, kappa, E, tau), both sectors: the residual of the paper\'s operator vanishes, E(t) = psi-bar psi E_0 (1 - i (-1)^n mu) at three times, N = psi^dagger psi (1 - i (-1)^n mu), the H part psi-bar psi E_0 and the A part -i (-1)^n mu psi-bar psi E_0 (max relative deviation %.1e)' % worst)
cmpv = []
for m_, kap, E_, tau, n in MODES:
    OP = ops(m_, kap, tau)
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        Z = blade(half[1]); P = mode(E_, Z, sec); Ec = cf_const(noether(OP['O'], P, rf_rev(P))[0]); rho = scal(mmul(mrev(Z), Z))
        cmpv.append(abs(cval(Ec) / float(rho) - vals_std[(E_, sec)]))
chk('bit==std', max(cmpv) < 1e-10, 'en.NOETHER: E/rho on the labels (exact in Q[pi], J <-> i) equals E/(psi-bar psi) from quad on the four (E, sector) pairs (max deviation %.1e)' % max(cmpv))

head('(4) [en·CONS2] two quantized modes at one shift: the Noether energy is conserved with its cross terms, the local part alone beats')
# two rest energies of one species at one tau: E_1 = m + kappa (n_1 even), E_2 = m - kappa (n_2 odd), E_j tau = (n_j + 1/2) pi, so kappa tau = (n_1 - n_2) pi/2
PAIRS = [(4, 1, PI / 2, (5, 2), (3, 1)), (2, -1, PI / 2, (1, 0), (3, 1)), (2, 1, 3 * PI / 2, (3, 4), (1, 1))]
ok_two = True; ok_cross = True; ok_bilx = True; ok_mixed = True; desc = []; lab_ratio = {}
for m_, kap, tau, (E1, n1), (E2, n2) in PAIRS:
    OP = ops(m_, kap, tau); mu = QP.of(kap) * tau
    assert all(E_ * tau == (nn + Fr(1, 2)) * PI and E_ == m_ + (-1) ** nn * kap for E_, nn in ((E1, n1), (E2, n2)))
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        A_ = mlin((1, blade(half[0])), (2, blade(half[1])), (-1, blade(half[3]))); B_ = mlin((3, blade(half[0])), (-1, blade(half[1])), (1, blade(half[2])))
        P = fadd((1, mode(E1, A_, sec)), (1, mode(E2, B_, sec))); Q = rf_rev(P)
        ok_two &= not apply_op(OP['O'], P) and not adjoint_op(OP['O'], Q)
        E, loc, bil = noether(OP['O'], P, Q)
        rA, rB = scal(mmul(mrev(A_), A_)), scal(mmul(mrev(B_), B_))
        want = mlin((rA * E1, ONE), (-(-1) ** n1 * rA * E1 * mu, J), (rB * E2, ONE), (-(-1) ** n2 * rB * E2 * mu, J))
        ok_two &= cf_const(E) == want
        xk = [k for k in loc if k != (0, 0)]
        ok_cross &= len(xk) == 2 and {k[0] for k in xk} == {Fr(sec * (E2 - E1)), Fr(sec * (E1 - E2))}
        ok_bilx &= all(fadd((1, {k: loc[k]}), (-1, {k: bil.get(k, {})})) == {} for k in xk)
        if sec == -1:
            ov = Sproj(mmul(mrev(A_), B_)); kx = (Fr(E1 - E2), 0)
            lab_ratio[(m_, kap)] = (loc.get(kx, {}), ov)                                 # the local cross term at +(E_1 - E_2) and the overlap <A~ B>_S
            desc.append('(%s, %s, %s): E = %s (n = %d) and %s (n = %d), E_N = %s' % (m_, kap, fmt_q(QP.of(tau)), E1, n1, E2, n2, fmt_z(cf_const(E))))
    Pm = fadd((1, mode(E1, blade(PPLUS[1]), -1)), (1, mode(E2, blade(PMINUS[2]), 1)))
    Em, locm, _ = noether(OP['O'], Pm, rf_rev(Pm)); ok_mixed &= cf_const(Em) is not None and all(k == (0, 0) for k in locm)
chk('bit', ok_two, 'en.CONS2: three (m, kappa, tau), both sectors, A e^{-+J E_1 t} + B e^{-+J E_2 t} with non-orthogonal amplitudes A, B in the half (rho_A = 6, rho_B = 11 in sector -1): both Euler-Lagrange equations hold with Q = P~, and E(t) is exactly constant, the sum of the two modes\' values rho_A E_1 (1 - (-1)^{n_1} mu J) + rho_B E_2 (1 - (-1)^{n_2} mu J): ' + '; '.join(desc))
chk('ctl', ok_cross, 'en.CONS2: the local part h(t) alone carries cross terms at the frequencies +-(E_1 - E_2) in all six cases: it beats and is not conserved')
chk('bit', ok_bilx and ok_mixed, 'en.CONS2: the bilocal part carries the same cross terms exactly, so they cancel in E; a sum with one mode in each sector (the three settings) has no cross terms at all, local or bilocal')
# the standard route: column spinors with quad
worst = 0.0; amp = 1.0; std_ratio = {}
for m_, kap, tau, (E1, n1), (E2, n2) in PAIRS:
    tf = float(tau); mu_f = kap * tf; T = col_ops(m_, kap, tf)
    u1 = np.array([1.0, 0.5 + 0.5j, 0, 0]); u2 = np.array([0.8 - 0.3j, 1.0, 0, 0])
    psi = ColField([(u1, E1), (u2, E2)])
    r1, r2 = (u1.conj() @ GM[0] @ u1).real, (u2.conj() @ GM[0] @ u2).real
    want = r1 * E1 * (1 - 1j * (-1) ** n1 * mu_f) + r2 * E2 * (1 - 1j * (-1) ** n2 * mu_f)
    ts = np.linspace(0.0, 2 * np.pi / abs(E1 - E2), 7)
    Es = [col_noether(T['O'], psi, t) for t in ts]
    worst = max(worst, max(abs(e_ - want) for e_ in Es) / abs(want))
    hs = np.array([col_noether(T['O'], psi, t, parts=True)[1] for t in ts])
    amp = min(amp, np.abs(hs - hs.mean()).max() / abs(want))
    # the cross coefficient at +(E_1 - E_2) by least squares on the samples, over the overlap u1-bar u2
    tt = np.linspace(0, 6, 40); Dl = float(E1 - E2)
    hv = np.array([col_noether(T['O'], psi, t, parts=True)[1] for t in tt])
    Mfit = np.stack([np.ones_like(tt), np.exp(1j * Dl * tt), np.exp(-1j * Dl * tt)], axis=1)
    coef = np.linalg.lstsq(Mfit, hv, rcond=None)[0]
    std_ratio[(m_, kap)] = coef[1] / (u1.conj() @ GM[0] @ u2)
chk('std', worst < 1e-10 and amp > 0.05, 'en.CONS2: Dirac matrices with quad, upper-component modes u1 e^{-i E_1 t} + u2 e^{-i E_2 t} (u1-bar u2 != 0) in the three cases: E(t) at seven times over one beat period equals r1 E_1 (1 - i (-1)^{n_1} mu) + r2 E_2 (1 - i (-1)^{n_2} mu) (max relative deviation %.1e), while the local part h(t) varies by at least %.2f of |E|' % (worst, amp))
cr = []
for key, (lc, ov) in lab_ratio.items():
    lab = zval(lc) / zval(ov); cr.append(abs(lab - std_ratio[key]))
chk('bit==std', max(cr) < 1e-9, 'en.CONS2: the local cross term at +(E_1 - E_2) divided by the overlap is E_2 on both routes: <A~ B>_S E_2 on the labels, exactly, against the least-squares coefficient over u1-bar u2 (max deviation %.1e)' % max(cr))

head('(5) [en·HERM] the Hermitian half H = i(D - kappa sinh tau D) - m: a real Noether energy on every mode, and its sign')
ok_hk = True; ok_ok = True; ok_hE = True; ok_h3 = True; hdesc = []; Hvals = {}
for m_, kap, tau, Es in ((4, 1, PI / 2, (3, 4, 5)), (8, 1, PI / 2, (7, 8, 9))):
    OP = ops(m_, kap, tau); mu = QP.of(kap) * tau
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        hk = [E_ for E_ in range(1, 2 * m_ + 1) if kernel_rest(OP['H'], E_, sec)]
        ok_k = [E_ for E_ in range(1, 2 * m_ + 1) if kernel_rest(OP['O'], E_, sec)]
        ok_hk &= tuple(hk) == Es and all(span_eq(kernel_rest(OP['H'], E_, sec), [blade(b) for b in half]) for E_ in Es)
        ok_ok &= tuple(ok_k) == (Es[0], Es[2])
        Z = mlin((1, blade(half[0])), (1, blade(half[2])), (-2, blade(half[3]))); rho = scal(mmul(mrev(Z), Z)); dens = abs(rho.c[0])
        for E_ in Es:
            P = mode(E_, Z, sec); Q = rf_rev(P); cosv = zre(phase(E_, tau))
            EH = cf_const(noether(OP['H'], P, Q)[0]); NH = cf_const(noether(OP['H'], P, Q, 'phase')[0])
            ok_hE &= not adjoint_op(OP['H'], Q) and EH == mlin((rho * E_ * (1 - mu * cosv), ONE)) and NH == mlin((dens * (1 - mu * cosv), ONE))
            ok_hE &= (float(zre(NH)) < 0) == (E_ == m_)                         # the middle root: 1 - pi/2 < 0
            Hvals[(m_, E_, sec)] = (EH, NH, rho)
        P3 = fadd(*[(1, mode(E_, mlin((i + 1, blade(half[0])), (1, blade(half[i + 1]))), sec)) for i, E_ in enumerate(Es)]); Q3 = rf_rev(P3)
        E3, loc3, _ = noether(OP['H'], P3, Q3)
        ok_h3 &= not apply_op(OP['H'], P3) and not adjoint_op(OP['H'], Q3) and cf_const(E3) is not None and not zim(cf_const(E3)) and len(loc3) > 1
    hdesc.append('(m, kappa, tau) = (%d, %d, pi/2): H-modes at E = %s, the paper\'s at E = %s and %s' % (m_, kap, ', '.join(map(str, Es)), Es[0], Es[2]))
chk('bit', ok_hk, 'en.HERM: rest waves e^{-+J E t}, E = 1 ... 2m: ' + '; '.join(hdesc) + '; each H kernel is the whole half (4 real dimensions per sector): the integer roots of E = m + kappa sin(E tau) at mu = kappa tau = pi/2 are m - 1, m, m + 1 (the numpy scan below finds no other root at (4, 1, pi/2))')
chk('bit', ok_ok, 'en.HERM: at the middle root E = m the anti-Hermitian half does not vanish (kappa cos(m tau) = kappa): the paper\'s equation has only the two outer roots, H has the third')
chk('bit', ok_hE, 'en.HERM: on every H-mode the adjoint holds with Q = P~ and the Noether energy is real, rho E (1 - mu cos E tau), with the Noether number |P|^2 (1 - mu cos E tau): at (4, 1, pi/2) the values are 3 rho, 4 (1 - pi/2) rho, 5 rho; the middle mode has a negative number (1 - pi/2) |P|^2 at a positive frequency')
chk('bit', ok_h3, 'en.HERM: the three-mode sums (both sectors, both settings) solve H and its adjoint, and their Noether energy is constant with no J part while the local part beats')
# the standard route
ok_herm = True; dev = 0.0
for kv in ((5.0, 0, 0, 0), (13.0, 12.0, 0, 0), (7.0, 2.0, 4.0, 2.0)):
    K = -sum(-float(kv[i]) * GM[i] for i in range(4))                          # i D on u e^{-i k.x}: the matrix k.Gamma
    for tf, kap_f in ((0.3, 1.0), (1.1, -0.7)):
        Ex = expm(1j * tf * K); Exi = expm(-1j * tf * K)
        Hs = K - 4.0 * I4 - 1j * kap_f * (Exi - Ex) / 2 * (-1 if fault('SINHSIGN') else 1); As = 1j * kap_f * (Exi + Ex) / 2
        dev = max(dev, np.abs(GM[0] @ Hs.conj().T @ GM[0] - Hs).max(), np.abs(GM[0] @ As.conj().T @ GM[0] + As).max(), np.abs(Hs + As - (K - 4.0 * I4 + 1j * kap_f * Ex)).max())
chk('std', dev < 1e-12, 'en.HERM: Dirac matrices with scipy expm, three wave vectors (rest and moving), two (tau, kappa): gamma^0 H^dagger gamma^0 = H and gamma^0 A^dagger gamma^0 = -A for H = K - m - i kappa sinh(tau D), A = i kappa cosh(tau D), and H + A is the paper\'s symbol K - m + i kappa expm(i tau K) (max deviation %.1e)' % dev)
def nroots(m_, kap_, tf):
    Eg = np.linspace(1e-3, m_ + abs(kap_) + 2, 200001); f = Eg - m_ - kap_ * np.sin(Eg * tf)
    idx = np.nonzero(np.sign(f[:-1]) != np.sign(f[1:]))[0]; roots = Eg[idx]
    return len(roots), [1 - kap_ * tf * np.cos(r_ * tf) for r_ in roots]
counts = {mu_: nroots(4.0, mu_ / 0.7, 0.7)[0] for mu_ in (0.1, 0.5, 0.9, -0.9)}
n3, slopes = nroots(4.0, 1.0, np.pi / 2)
chk('std', all(c_ == 1 for c_ in counts.values()) and n3 == 3 and [np.sign(x) for x in slopes] == [1, -1, 1], 'en.HERM: numpy scan of E - m - kappa sin(E tau) on (0, m + |kappa| + 2] (m = 4, tau = 0.7): one root for mu = kappa tau = 0.1, 0.5, 0.9, -0.9 (the slope 1 - mu cos E tau >= 1 - |mu| > 0); at (4, 1, pi/2) three roots with slopes of signs +, -, +: the Noether number of the middle one is negative')
dev = 0.0; cmph = []
for (m_, E_, sec), (EH, NH, rho) in Hvals.items():
    if m_ != 4 or sec != -1: continue
    T = col_ops(4, 1.0, np.pi / 2); u = np.array([1.0, 0.3 - 0.6j, 0, 0], complex); psi = ColField([(u, E_)]); r_ = (u.conj() @ GM[0] @ u).real
    Es_ = col_noether(T['H'], psi, 0.37); Ns_ = col_noether(T['H'], psi, 1.2, 'phase')
    wantE = r_ * E_ * (1 - (np.pi / 2) * np.cos(E_ * np.pi / 2)); dev = max(dev, abs(Es_ - wantE) / abs(wantE), abs(Ns_ - r_ * (1 - (np.pi / 2) * np.cos(E_ * np.pi / 2))) / r_)
    cmph.append(abs(Es_ / r_ - cval(EH).real / float(rho)) + abs(cval(EH).imag))
chk('std', dev < 1e-10, 'en.HERM: Dirac matrices with quad on the three H-modes of (4, 1, pi/2): E = r E (1 - mu cos E tau) and N = r (1 - mu cos E tau), real (max relative deviation %.1e)' % dev)
chk('bit==std', max(cmph) < 1e-12, 'en.HERM: E/rho exact on the labels against quad on the three modes (max deviation %.1e)' % max(cmph))

head('(6) [en·GRAV] the gravitational coupling: the Phi-coefficient of the action against the Noether energy, mode by mode')
# On the frame of a constant potential the operator is the one at the frame factor fr = a = 1/N = 1 + Phi + ... (shifted_weakfield.py, wf.FRAME):
# bD -> fr bD, also inside exp(-tau bD).  The Phi-coefficient of the action on a solution is <P~ d/dfr O_fr[P]>_S at fr = 1 (the volume factor
# multiplies L, which vanishes on solutions).  READREAL: its J part read as a real number, as in (2.12).
def phi_coef(OP, key, P, Q):
    z = pair(Q, apply_op(OP['d' + key], P))
    if fault('READREAL') and key == 'O': z = {k: mlin((zre(v) + zim(v), ONE)) for k, v in z.items()}
    return z
ok_g = True; ok_gH = True; ok_g2 = True; ok_paper = True; gdesc = []
for m_, kap, E_, tau, n in MODES:
    OP = ops(m_, kap, tau); mu = QP.of(kap) * tau; sgn = (-1) ** n
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        for Z in kernel_rest(OP['O'], E_, sec):
            P = mode(E_, Z, sec); Q = rf_rev(P); rho = scal(mmul(mrev(Z), Z))
            for key in ('O', 'H', 'A'):
                ok_g &= cf_const(phi_coef(OP, key, P, Q)) == cf_const(noether(OP[key], P, Q)[0])
            g = cf_const(phi_coef(OP, 'O', P, Q))
            ok_paper &= g is not None and g == mlin((rho * E_, ONE), (-sgn * rho * E_ * mu, J)) and g != mlin((rho * E_, ONE)) and zre(g) + zim(g) == rho * E_ * (1 - sgn * mu)
    gdesc.append('E = %s (n = %d): %s per unit rho' % (E_, n, fmt_z(mlin((E_, ONE), (-sgn * E_ * mu, J)))))
for (m_, E_, sec), (EH, NH, rho) in Hvals.items():
    OP = ops(m_, 1, PI / 2); half = PPLUS if sec == -1 else PMINUS
    Z = mlin((1, blade(half[0])), (1, blade(half[2])), (-2, blade(half[3]))); P = mode(E_, Z, sec)
    ok_gH &= cf_const(phi_coef(OP, 'H', P, rf_rev(P))) == EH
for m_, kap, tau, (E1, n1), (E2, n2) in PAIRS:
    OP = ops(m_, kap, tau)
    A_ = mlin((1, blade(PPLUS[0])), (2, blade(PPLUS[1])), (-1, blade(PPLUS[3]))); B_ = mlin((3, blade(PPLUS[0])), (-1, blade(PPLUS[1])), (1, blade(PPLUS[2])))
    P = fadd((1, mode(E1, A_, -1)), (1, mode(E2, B_, -1))); Q = rf_rev(P)
    g = phi_coef(OP, 'O', P, Q); E = cf_const(noether(OP['O'], P, Q)[0])
    ok_g2 &= g.get((0, 0)) == E and len(g) == 3                                 # the constant part is the energy; the coupling density beats
chk('bit', ok_g, 'en.GRAV: on the 16 basis solutions of (3) the Phi-coefficient of the action equals the Noether energy, exactly in Q[pi], for the paper\'s operator O and for each half H and A separately')
chk('bit', ok_gH, 'en.GRAV: on the H-modes of (5) (both settings, both sectors) the Phi-coefficient of the H action equals its Noether energy rho E (1 - mu cos E tau), the negative one included: in the Hermitian theory the coupling to a uniform potential is the conserved energy, real, mode by mode')
chk('ctl', ok_paper, 'en.GRAV: per unit local density rho the Phi-coefficient of O is not E_0 but E_0 (1 - (-1)^n mu J), the Noether number per unit density times E_0 (' + '; '.join(gdesc) + '); read with J as a real number it is E_0 (1 - mu (-1)^n), the paper\'s (2.12): the paper\'s deviation compares the coupling with E_0 rho, not with the Noether energy')
chk('bit', ok_g2, 'en.GRAV: on the two-mode sums of (4) (sector -1) the Phi-coefficient density has the Noether energy as its constant part and two terms at +-(E_1 - E_2): the coupling density beats, its time average is the conserved energy')
# the standard route: the Phi-derivative by finite differences (shifted_weakfield.py, wf.STD) against quad; the k-derivative of the symbol for a moving wave
def col_sym(K, m_, kap_, tf, key):
    Ex = expm(1j * tf * K); Exi = expm(-1j * tf * K)
    if key == 'O': return K - m_ * I4 + 1j * kap_ * Ex
    if key == 'H': return K - m_ * I4 - 1j * kap_ * (Exi - Ex) / 2
    return 1j * kap_ * (Exi + Ex) / 2
dev = 0.0; rows_std = {}
for m_, kap, E_, tau, n in MODES:
    tf = float(tau); T = col_ops(m_, kap, tf); K0 = float(E_) * GM[0]
    for sec in (-1, 1):
        u = np.array([1.0, 0.4 - 0.7j, 0, 0], complex) if sec == -1 else np.array([0, 0, 1.0, 0.4 - 0.7j], complex)
        Kw = K0 if sec == -1 else -K0                                           # i D on u e^{-+i E t}
        psi = ColField([(u, -sec * E_)]); h = 1e-6; rr_ = (u.conj() @ GM[0] @ u).real
        for key in ('O', 'H', 'A'):
            dM = (col_sym((1 + h) * Kw, m_, kap, tf, key) - col_sym((1 - h) * Kw, m_, kap, tf, key)) / (2 * h)
            gstd = u.conj() @ GM[0] @ dM @ u
            if fault('READREAL') and key == 'O': gstd = gstd.real + gstd.imag
            En = col_noether(T[key], psi, 0.3)
            dev = max(dev, abs(gstd - En) / abs(float(E_) * rr_))
            rows_std[(E_, sec, key)] = gstd / rr_
chk('std', dev < 1e-7, 'en.GRAV: Dirac matrices: the Phi-derivative of the symbols of O, H, A (K -> (1 + Phi) K, central differences, scipy expm) sandwiched in u-bar ... u equals the Noether energy by quad on the rest modes of (3), both sectors (max relative deviation %.1e)' % dev)
# a moving wave: the k-derivative of the symbol on the wave carries the factor (1 - mu e^{i E tau}) in every component
m_, kap, tf = 3.0, 2.0, np.pi / 10; kv = np.array([13.0, 12.0, 0.0, 0.0]); Ew = 5.0
Kk = lambda k_: sum(k_[i] * GM[i] for i in range(4))
def nullcols(M, tol=1e-9):
    u_, sv, vh = np.linalg.svd(M); r_ = int(np.sum(sv > tol * max(1.0, sv[0]))); return vh[r_:].conj().T
from scipy.optimize import brentq
devm = 0.0; facs = []
for key, tf_, Ew_ in (('O', np.pi / 10, 5.0), ('H', 0.37, None)):
    if Ew_ is None: Ew_ = brentq(lambda E__: E__ - m_ - kap * np.sin(E__ * tf_), m_ - kap - 1e-9, m_ + kap + 1e-9)   # an H-mode off the quarter turns
    pz = 12.0 if key == 'O' else 2.0; kvv = np.array([np.sqrt(Ew_ ** 2 + pz ** 2), pz, 0.0, 0.0])
    U = nullcols(Kk(kvv) - Ew_ * I4); assert U.shape[1] == 2
    fac = (1 - kap * tf_ * np.exp(1j * Ew_ * tf_)) if key == 'O' else (1 - kap * tf_ * np.cos(Ew_ * tf_)); facs.append(fac)
    for u in (U[:, 0], U[:, 1], U[:, 0] + (0.3 - 0.8j) * U[:, 1]):
        assert np.abs(col_sym(Kk(kvv), m_, kap, tf_, key) @ u).max() < 1e-9
        for mu_i in range(4):
            h = 1e-6; e_ = np.zeros(4); e_[mu_i] = h
            dS = (col_sym(Kk(kvv + e_), m_, kap, tf_, key) - col_sym(Kk(kvv - e_), m_, kap, tf_, key)) / (2 * h)
            lhs = u.conj() @ GM[0] @ dS @ u; rhs = fac * (u.conj() @ GM[0] @ GM[mu_i] @ u)
            devm = max(devm, abs(lhs - rhs) / max(1.0, abs(rhs)))
chk('std', devm < 1e-7, 'en.GRAV: a moving wave (Dirac matrices, central differences in k_mu): on the solutions of the paper\'s symbol at k = (13, 12, 0, 0), E = 5, tau = pi/10 (m = 3, kappa = 2) the k-derivative of the symbol is u-bar dO/dk_mu u = (1 - mu e^{i E tau}) u-bar gamma_mu u for mu = 0 ... 3, factor %.4f %+.4fi; on an H-mode off the quarter turns (tau = 0.37, E = %.6f from E = m + kappa sin E tau, k = (sqrt(E^2 + 4), 2, 0, 0)) the factor is real, 1 - mu cos E tau = %.6f (max relative deviation %.1e): the factor of the rest frame, in every component' % (facs[0].real, facs[0].imag, Ew_, facs[1].real, devm))
cmpg = []
for m_, kap, E_, tau, n in MODES:
    OP = ops(m_, kap, tau)
    for sec, half in ((-1, PPLUS), (1, PMINUS)):
        Z = blade(half[1]); P = mode(E_, Z, sec); rho = scal(mmul(mrev(Z), Z))
        for key in ('O', 'H', 'A'):
            g = cf_const(phi_coef(OP, key, P, rf_rev(P))); cmpg.append(abs(cval(g) / float(rho) - rows_std[(E_, sec, key)]))
chk('bit==std', max(cmpg) < 1e-7, 'en.GRAV: the exact Phi-coefficients per unit rho on the labels equal the finite-difference ones from Dirac matrices, O, H, A, four (E, sector) pairs (max deviation %.1e)' % max(cmpg))

head('(7) [en·BEAT] two quantized modes on the frame of a constant potential: a beat at E_1 - E_2 in proper time, and what it measures')
# (i) the arithmetic of a two-frequency packet of one species: E_1 = m + kappa (n_1 even), E_2 = m - kappa (n_2 odd), E_j tau = (n_j + 1/2) pi
ok_ar = True; npairs = 0; nker = 0
for n1 in range(0, 41, 2):
    for n2 in range(1, 42, 2):
        c = Fr(1, 3); E1, E2 = (2 * n1 + 1) * c, (2 * n2 + 1) * c; tau = PI / (2 * c)
        m_, kap = (E1 + E2) / 2, (E1 - E2) / 2; npairs += 1
        ok_ar &= E1 * tau == (n1 + Fr(1, 2)) * PI and E2 * tau == (n2 + Fr(1, 2)) * PI and E1 == m_ + kap and E2 == m_ - kap
        ok_ar &= (QP.of(kap) * tau).c == {1: Fr(n1 - n2, 2)} and (n1 - n2) % 2 == 1
        if n1 <= 4 and n2 <= 5:
            OP = ops(m_, kap, tau); nker += 1
            ok_ar &= len(kernel_rest(OP['O'], E1, -1)) == 4 and len(kernel_rest(OP['O'], E2, -1)) == 4
chk('bit', ok_ar, 'en.BEAT: for n_1 = 0, 2, ..., 40 and n_2 = 1, 3, ..., 41 (%d pairs, E_j = (2 n_j + 1)/3, tau = 3 pi/2): two quantized rest energies m + kappa and m - kappa of one species at one shift force kappa tau = (n_1 - n_2) pi/2, an odd multiple of pi/2 (both kernels checked on the labels for %d pairs): so |mu| >= pi/2, and in the paper\'s range |mu| < 1e-13 a species has one quantized rest energy on the branch E = m +- kappa at a given shift (the second branch E = kappa - m needs kappa > m)' % (npairs, nker))
# (ii) on the frame: fr = a = (1 - 2 Phi)^(-1/2), coordinate frequencies E_j/a, shift a tau in coordinate time (tau proper), (m, kappa, tau) = (4, 1, pi/2)
ok_fr = True; ok_flat = True; ok_beat = True; ok_en = True; bdesc = []; lab_beat = {}
for Phi, a in ((Fr(8, 25), Fr(5, 3)), (Fr(9, 50), Fr(5, 4)), (Fr(3, 8), Fr(2)), (Fr(-9, 32), Fr(4, 5))):
    assert (1 - 2 * Phi) * a * a == 1
    try:
        OP = ops(4, 1, PI / 2, a); mu = PI / 2
        A_ = mlin((1, blade(PPLUS[0])), (2, blade(PPLUS[1])), (-1, blade(PPLUS[3]))); B_ = mlin((3, blade(PPLUS[0])), (-1, blade(PPLUS[1])), (1, blade(PPLUS[2])))
        P = fadd((1, mode(Fr(5) / a, A_, -1)), (1, mode(Fr(3) / a, B_, -1))); Q = rf_rev(P)
        ok_fr &= not apply_op(OP['O'], P) and not adjoint_op(OP['O'], Q)
        Pf = fadd((1, mode(5, A_, -1)), (1, mode(3, B_, -1)))
        try: ok_flat &= bool(apply_op(OP['O'], Pf))
        except ValueError: pass                                                 # an inexact phase: certainly no solution there
        dens = pair(Q, P); D = Fr(2) / a
        ok_beat &= set(k[0] for k in dens) == {Fr(0), D, -D} and dens[(D, 0)] == Sproj(mmul(mrev(A_), B_))
        ok_beat &= phase(D, a * PI / 2) == mlin((-1, ONE))                       # over one coordinate shift a tau the beat term changes sign
        E0_ = cf_const(noether(OP['O'], P, Q)[0]); E = None if E0_ is None else mlin((Fr(1) / a, E0_))   # the action on the frame is int N dt <P~ O_a[P]>_S: vol = N dt d^3x, N = 1/a
        rA, rB = scal(mmul(mrev(A_), A_)), scal(mmul(mrev(B_), B_))
        ok_en &= E == mlin((rA * Fr(5) / a, ONE), (-rA * Fr(5) / a * mu, J), (rB * Fr(3) / a, ONE), (rB * Fr(3) / a * mu, J))
        lab_beat[a] = (D, dens[(D, 0)], Sproj(mmul(mrev(A_), A_)))
        bdesc.append('a = %s: beat %s per unit coordinate time' % (a, D))
    except ValueError:
        ok_fr = False
chk('bit', ok_fr, 'en.BEAT: on the frame of four constant potentials (a = 5/3, 5/4, 2, 4/5) the sum A e^{-J (5/a) t} + B e^{-J (3/a) t} (m = 4, kappa = 1, proper shift pi/2, coordinate shift a pi/2; n = 2 and n = 1) solves the paper\'s operator at the frame factor a and its adjoint, exactly')
chk('bit', ok_flat, 'en.BEAT: the same amplitudes at the flat coordinate frequencies 5 and 3 do not solve it on any of the four frames')
chk('bit', ok_beat, 'en.BEAT: the density <P~ P>_S has frequencies 0 and +-2/a only (' + '; '.join(bdesc) + '), the beat coefficient <A~ B>_S; per unit proper time the beat is E_1 - E_2 = 2 kappa = 2, and over one shift (a tau in coordinate time, tau in proper time) the beat term changes sign: (E_1 - E_2) tau = (n_1 - n_2) pi, the shift is an odd number of half beat periods in every frame')
chk('bit', ok_en, 'en.BEAT: with the volume factor N = 1/a of vol = N dt d^3x in the action, the Noether energy in coordinate time is constant, (5/a) rho_A (1 - (pi/2) J) + (3/a) rho_B (1 + (pi/2) J): both modes redshifted by the same 1/a = sqrt(1 - 2 Phi), the beat absent from it')
# the standard route: Dirac matrices on the frame, the density sampled and Fourier analysed
worst = 0.0; ok_fft = True; std_beat = {}
for a in (Fr(5, 3), Fr(5, 4), Fr(2), Fr(4, 5)):
    af = float(a); tf = np.pi / 2; m_, kap = 4.0, 1.0
    u1 = np.array([1.0, 0.5 + 0.5j, 0, 0]); u2 = np.array([0.8 - 0.3j, 1.0, 0, 0])
    res = 0.0
    for E_, u in ((5.0, u1), (3.0, u2)):
        Kf = af * (E_ / af) * GM[0]                                             # the frame frequency a k_0 = E
        shift = tf if not fault('COORDSHIFT') else tf / af
        res = max(res, np.abs((Kf - m_ * I4 + 1j * kap * expm(1j * shift * Kf)) @ u).max())
    psi = ColField([(u1, 5.0 / af), (u2, 3.0 / af)])
    Tb = 2 * np.pi * af / 2.0; tt = np.arange(0, 64 * Tb, Tb / 64)
    dens = np.array([psi.bar(t) @ psi(t) for t in tt]).real
    sp = np.abs(np.fft.rfft(dens - dens.mean())); fq = np.fft.rfftfreq(len(tt), tt[1] - tt[0]) * 2 * np.pi
    fpk = fq[np.argmax(sp)]; ok_fft &= abs(fpk - 2.0 / af) < (fq[1] - fq[0]) and res < 1e-12
    T = col_ops(m_, kap, tf, af); Es = [col_noether(T['O'], psi, t) / af for t in (0.0, 0.4 * Tb, 1.3 * Tb)]   # with the volume factor N = 1/a
    r1, r2 = (u1.conj() @ GM[0] @ u1).real, (u2.conj() @ GM[0] @ u2).real
    want = (5.0 / af) * r1 * (1 - 1j * np.pi / 2) + (3.0 / af) * r2 * (1 + 1j * np.pi / 2)
    worst = max(worst, max(abs(e_ - want) for e_ in Es) / abs(want))
    ov = u1.conj() @ GM[0] @ u2; std_beat[a] = (fpk, ov, np.exp(1j * (2.0 / af) * (af * tf)))
chk('std', ok_fft and worst < 1e-10, 'en.BEAT: Dirac matrices on the four frames: the symbol K_a - m + i kappa expm(i tau K_a) annihilates both modes (frame frequency E, proper shift pi/2); the sampled density psi-bar psi (64 beat periods) has its Fourier peak at 2/a within one bin; the Noether energy by quad with the frame factor and the volume factor is constant at three times and equals (5/a) r1 (1 - i pi/2) + (3/a) r2 (1 + i pi/2) (max relative deviation %.1e)' % worst)
cb = []
for a, (D, z, _) in lab_beat.items():
    fpk, ov, ph_std = std_beat[a]
    cb.append(abs(ph_std - (-1)))
chk('bit==std', max(cb, default=1.0) < 1e-12 and len(cb) == 4 and all(abs(float(lab_beat[a][0]) - std_beat[a][0]) < 0.02 for a in lab_beat), 'en.BEAT: the beat frequency 2/a (exact on the labels; the Fourier peak of the matrices, within one bin) and the sign change of the beat over the coordinate shift a tau (e^{J (2/a)(a pi/2)} = -1 exactly; e^{i (2/a)(a pi/2)} + 1 = %.1e in floats) on the four frames' % max(cb, default=1.0))

head('(8) [en·MIXED] the mixed equation (2.17): its roots, its limit, its energy, and its place in the shifted operators')
# on the labels: the symmetric shift (P(t - tau) + P(t + tau))/2 = cosh(tau bD) P at rest (2) annihilates a rest mode exactly on the lattice cos(E tau) = 0
ok_lat = True; lat = []
for tau, kap in ((PI / 2, Fr(1)), (3 * PI / 2, Fr(-2)), (5 * PI / 2, Fr(1, 2))):
    OP = ops(3, kap, tau)
    for E_ in range(0, 13):
        P = mode(E_, mlin((1, ONE), (2, blade(PPLUS[2]))), -1)
        zero = not apply_op(OP['A'], P)
        ok_lat &= zero == (zre(phase(E_, tau)) == 0)
        if tau == PI / 2 and zero: lat.append(E_)
chk('bit', ok_lat, 'en.MIXED: on rest modes e^{-J E t}, E = 0 ... 12, the symmetric shift kappa cosh(tau bD) (the term of (2.17) at rest) vanishes exactly when cos(E tau) = 0, at tau = pi/2, 3 pi/2, 5 pi/2: the lattice E tau = (j + 1/2) pi of the quantization (2.6) (E = %s at tau = pi/2) is the kernel of the symmetric shift' % ', '.join(map(str, lat)))
ok_nor = True; ok_dif = False
for tau, kap in ((PI / 2, Fr(1)), (PI / 2, Fr(-1)), (3 * PI / 2, Fr(2))):
    for nu in range(-8, 9):
        ph1, ph2 = phase(nu, tau), phase(-nu, tau)                              # e^{J nu tau}, e^{-J nu tau}
        sym = mlin((-nu, J), (kap / 2, ph1), (kap / 2, ph2))                     # (2.17) on X0 e^{-J nu t}: -J nu + (kappa/2)(e^{J nu tau} + e^{-J nu tau})
        dif = mlin((-nu, J), (kap / 2, ph2), (-kap / 2, ph1))                    # the difference equation (D_s at rest)
        ok_nor &= bool(sym) or (nu == 0 and kap == 0)
        ok_dif |= (not dif) and nu != 0
chk('bit', ok_nor and ok_dif, 'en.MIXED: on the labels, (2.17) with k = kappa/2 has no oscillating solution X0 e^{-J nu t} with nu tau on the quarter turns (nu = -8 ... 8; (tau, kappa) = (pi/2, 1), (pi/2, -1), (3 pi/2, 2)): its residual -J nu + kappa cos(nu tau) never vanishes; the difference equation of D_s has one (nu = 1 at (pi/2, -1): nu = -kappa sin(nu tau))')
# the standard route: the roots of (2.18) z = mu (e^z + e^{-z}) by Newton's method from a grid, their limit, the energy
def mixed_roots(mu, box_re=8.0, box_im=40.0):
    sgn = -1.0 if fault('MIXSIGN') else 1.0
    f = lambda z: z - mu * (np.exp(z) + sgn * np.exp(-z)); fp = lambda z: 1 - mu * (np.exp(z) - sgn * np.exp(-z))
    found = []
    with np.errstate(all='ignore'):
        found = _newton_grid(f, fp, box_re, box_im)
    return found
def _newton_grid(f, fp, box_re, box_im):
    found = []
    for x0 in np.linspace(-box_re, box_re, 33):
        for y0 in np.linspace(-box_im, box_im, 161):
            z = complex(x0, y0)
            for _ in range(80):
                d_ = f(z) / fp(z); z -= d_
                if abs(d_) < 1e-14 * max(1, abs(z)) or abs(z) > 1e6: break
            if abs(z) < 1e6 and abs(z.real) <= box_re + 1 and abs(z.imag) <= box_im and abs(f(z)) < 1e-10 * max(1, abs(z)):
                if all(abs(z - w) > 1e-7 for w in found): found.append(z)
    return found
ok_off = True; nrt = {}; minre = {}
for mu in (0.05, 0.3, 1.0, 5.0, 50.0, 500.0):
    zs = mixed_roots(mu); nrt[mu] = len(zs); minre[mu] = min(abs(z.real) for z in zs)
    ok_off &= len(zs) > 0 and minre[mu] > 1e-6
chk('std', ok_off, 'en.MIXED: Newton\'s method from a grid (Re z in [-8, 8], Im z in [-40, 40]) finds %s roots of z = mu (e^z + e^{-z}) at mu = 0.05, 0.3, 1, 5, 50, 500, residual < 1e-10, none on the imaginary axis: min |Re z| = %s (the paper\'s remark 3)' % (', '.join(str(nrt[m_]) for m_ in sorted(nrt)), ', '.join('%.1e' % minre[m_] for m_ in sorted(minre))))
ok_lim = True; lim_rows = []; antiper = {}
for mu in (50.0, 500.0, 5000.0):
    zs = mixed_roots(mu, 2.0, 18.0); worst_r = 0.0; worst_i = 0.0; ap = 0.0
    for j in range(0, 5):
        target = 1j * (j + 0.5) * np.pi; z = min(zs, key=lambda w: abs(w - target))
        worst_r = max(worst_r, abs(2 * mu * z.real / ((j + 0.5) * np.pi) - (-1) ** j)); worst_i = max(worst_i, abs(z.imag - (j + 0.5) * np.pi))
        ap = max(ap, abs(np.exp(-2 * z) + 1))
    antiper[mu] = ap; lim_rows.append((mu, worst_r, worst_i, ap))
    ok_lim &= worst_r < 20.0 / mu ** 2 and worst_i < 10.0 / mu ** 2
ok_lim &= antiper[500.0] < antiper[50.0] / 5 and antiper[5000.0] < antiper[500.0] / 5
chk('std', ok_lim, 'en.MIXED: as mu grows the roots nearest i (j + 1/2) pi (j = 0 ... 4) approach it: |2 mu Re z / ((j + 1/2) pi) - (-1)^j| = %s and |Im z - (j + 1/2) pi| = %s at mu = 50, 500, 5000, falling by 100 per decade of mu: Re z = (-1)^j (j + 1/2) pi / (2 mu) (1 + O(1/mu^2)) -> 0; the solutions' % (', '.join('%.1e' % r_[1] for r_ in lim_rows), ', '.join('%.1e' % r_[2] for r_ in lim_rows)) + ' e^{-z t/r} become anti-periodic, |e^{-2z} + 1| = %s at mu = 50, 500, 5000: in the limit x(t + 2r) = -x(t), with the frequencies (j + 1/2) pi / r of the quantization lattice' % ', '.join('%.1e' % antiper[m_] for m_ in (50.0, 500.0, 5000.0)))
# the energy of (2.17): L = y (x' + k (x(t - r) + x(t + r))), the adjoint -y' + k (y(t + r) + y(t - r)) = 0 has y = e^{z t/r} with the same z
def mixed_energy(k, r, x, dx, y, t):
    loc = -k * y(t) * (x(t - r) + x(t + r))
    if fault('NOBILOCAL'): return loc
    if fault('SAMETIME'): return loc - k * cquad(lambda s_: y(s_) * dx(s_), t - r, t) + k * cquad(lambda s_: y(s_) * dx(s_), t, t + r)
    return loc - k * cquad(lambda s_: y(s_ + r) * dx(s_), t - r, t) + k * cquad(lambda s_: y(s_ - r) * dx(s_), t, t + r)
worstm = 0.0; worstx = 0.0
for mu, r in ((0.3, 1.0), (2.0, 0.5)):
    k = mu / r; zs = sorted(mixed_roots(mu, 3.0, 12.0), key=abs)[:4]
    for i, z1 in enumerate(zs):
        for z2 in zs[i + 1:]:
            a1, a2, b1, b2 = 1.0, 0.6 - 0.2j, -0.4 + 0.9j, 1.1
            x = lambda t, z1=z1, z2=z2: a1 * np.exp(-z1 * t / r) + a2 * np.exp(-z2 * t / r)
            dx = lambda t, z1=z1, z2=z2: -(z1 / r) * a1 * np.exp(-z1 * t / r) - (z2 / r) * a2 * np.exp(-z2 * t / r)
            y = lambda t, z1=z1, z2=z2: b1 * np.exp(z1 * t / r) + b2 * np.exp(z2 * t / r)
            want = sum(aa * bb * (zz / r) * (mu * (np.exp(zz) - np.exp(-zz)) - 1) for aa, bb, zz in ((a1, b1, z1), (a2, b2, z2)))
            for t in (0.0, 0.7 * r, 2.2 * r):
                worstm = max(worstm, abs(mixed_energy(k, r, x, dx, y, t) - want) / max(1.0, abs(want)))
            xc = lambda t, z1=z1: np.exp(-z1 * t / r); dxc = lambda t, z1=z1: -(z1 / r) * np.exp(-z1 * t / r); yc = lambda t, z2=z2: np.exp(z2 * t / r)
            worstx = max(worstx, max(abs(mixed_energy(k, r, xc, dxc, yc, t)) for t in (0.1, 1.4)))
chk('std', worstm < 1e-9 and worstx < 1e-9, 'en.MIXED: the doubled Lagrangian of (2.17) has the Noether energy -k y(t)(x(t - r) + x(t + r)) - k int_{t-r}^{t} y(s + r) x\'(s) ds + k int_t^{t+r} y(s - r) x\'(s) ds; on sums of two roots (mu = 0.3, 2; four roots each) it is constant at three times and equals the sum of (z/r)(mu (e^z - e^{-z}) - 1) a b (relative %.1e), and the cross pairing of two roots gives 0 (%.1e): a conserved energy for the mixed equation' % (worstm, worstx))
def has_imag_root_antisym(mu):
    g = lambda y_: y_ - 2 * mu * np.sin(y_)
    ys = np.linspace(0.1, 4 * mu + 1, 20001); v = g(ys); return bool(np.any(np.sign(v[:-1]) != np.sign(v[1:])))
chk('ctl', has_imag_root_antisym(5.0) and not fault('MIXSIGN'), 'en.MIXED: the antisymmetric equation z = mu (e^z - e^{-z}) (the shift of D_s at rest) has roots on the imaginary axis at mu = 5 (z = i y with y = 2 mu sin y): the test above can fail, and it does with the sign turned (MIXSIGN)')
cmpm = max(abs(lim_rows[-1][2]), 0.0)
chk('bit==std', cmpm < 1e-2, 'en.MIXED: the limit of the roots of (2.18) at mu = 5000 is the lattice the labels give exactly for the kernel of the symmetric shift: |Im z_j - (j + 1/2) pi| <= %.1e for j = 0 ... 4' % cmpm)

print('\n  [time] %.1f s' % (time.time() - T0), flush=True)
finish('SHIFTED-ENERGY')
