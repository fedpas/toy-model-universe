#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""The numbers of twelve Logbook lines against the page scripts that decide them.

Statement.  Every number, name and range that the Logbook lines MAP-005, MAP-016, MAP-018, MAP-019, MAP-020, MAP-021, MAP-024, MAP-025,
MAP-027, RSN-005, RSN-008 and RSN-025 print is the stored result of the page script that decides it (maxwell, equations, yangmills,
coupling, matter, spin, projective, forque, pgadyn, gravity, matrixrep), or a count that the page script's own product gives again here.
The table SENTENCE holds the numbers as the lines print them; a changed number in a line makes a check here fail.
[bit]  reads the stored JSON beside the page scripts (../<page>.json; each page script rebuilds it and asserts equality with --compare)
       and recounts from the stored tables (rows, statuses); where a number is not stored it calls the page script's own product:
       the terms of the coupled Dirac equation through coupling_selfcheck.bmul, the pseudoscalar of Cl(3,0) and Cl(7,0) through spin_selfcheck.MV.
[std]  closed forms that never touch the bit rule: C(n-1,2) complex structures, (2n+1) times the number of even subsets, n C(n-1,2) pairs
       of index pairs sharing one index, C(n,2), C(n,3), the role of a symmetric difference of index sets, p q, n C(n,2), (-1)^(d(d-1)/2),
       2^(n+1), k = -s, 27 + 9 + 5 and 22 + 2 + 6; and, where a second engine computes the same number, its stored result
       (gravity_matrix.json, projective_matrix.json, forque_matrix.json, the E3 row of spin.json, the doubling of projective.json).
       A number with no second route says "one route" in its check line.
[ctl]  every expectation is compared again with the expected value changed by one (a name changed for a name): the mismatch must be
       reported; a stored table with one row removed must fail its count.
Scope.  The n, m, k, d, signatures and orders the page scripts print.  Nothing about nature; the readings of the lines and the timings
are not numbers to check.  The script builds no Forms, Lie or Grav object of the gravity engine and writes nothing.
  python3 step_lines.py           (from checks/selfcheck/proofs/, from checks/, or as python3 -I -B checks/selfcheck/proofs/step_lines.py)
"""
import copy, json, os, sys
from fractions import Fraction as Fr
from math import comb, sqrt
sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__)); PAGE = os.path.dirname(HERE)
if PAGE not in sys.path: sys.path.insert(0, PAGE)

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

PAGES = ['maxwell', 'equations', 'yangmills', 'coupling', 'matter', 'spin', 'projective', 'forque', 'pgadyn', 'gravity', 'matrixrep',
         'gravity_matrix', 'projective_matrix', 'forque_matrix']
def load_all():
    D = {}
    for p in PAGES:
        with open(os.path.join(PAGE, p + '.json'), encoding='utf8') as f: D[p] = json.load(f)
    return D

# ------------------------------------------------------------------------------------------------ helpers on the stored tables
def rows_of(D, page):                     # the row table of a translation matrix or a block of exact rows
    return {'maxwell': lambda: D['maxwell']['charges']['rows'], 'forque': lambda: D['forque']['rows'],
            'spin': lambda: D['spin']['matrix']['rows'], 'pgadyn': lambda: D['pgadyn']['rows']}[page]()
def by_id(rows, i): return next(r for r in rows if r['id'] == i)
def count(rows, key, val): return sum(1 for r in rows if r.get(key) == val)
def drop_row(page, pick):                 # a copy of the stored data with one row removed (the first row that pick accepts)
    def f(D):
        E = copy.deepcopy(D); rows = rows_of(E, page); k = next(i for i, r in enumerate(rows) if pick(r)); del rows[k]; return E
    return f
def drop_ladder(n):
    def f(D):
        E = copy.deepcopy(D); del E['coupling']['ladder'][str(n)]; return E
    return f
def bump(x):                              # the expected value changed by one; a name changed for a name
    if isinstance(x, bool): return not x
    if isinstance(x, int): return x + 1
    if isinstance(x, Fr): return x + 1
    if isinstance(x, str):
        try: return str(Fr(x) + 1)
        except (ValueError, ZeroDivisionError): return x + ' (another)'
    if isinstance(x, list): return [bump(x[0])] + x[1:] if x else [0]
    if isinstance(x, tuple): return (bump(x[0]),) + x[1:]
    if isinstance(x, dict): k = sorted(x)[0]; y = dict(x); y[k] = bump(y[k]); return y
    raise TypeError(type(x))
def eq(a, b): return a == b
def contains_each(markers, texts): return len(markers) == len(texts) and all(m in t for m, t in zip(markers, texts))

# ------------------------------------------------------------------------------------------------ recounts through the page scripts' own products
def coupled_terms(n):
    """D = grad(psi) J - e A psi - m psi gamma_0 on symbolic components (d_mu psi_S, A_k psi_S, psi_S) through coupling_selfcheck.bmul:
    the number of (target blade, monomial) pairs with a non-zero coefficient, and the number of terms of each odd target"""
    import coupling_selfcheck as cpl
    sq = cpl.sqs(n); ev = [m for m in range(1 << n) if cpl.popc(m) % 2 == 0]; Jm, Js = cpl.bmul(1 << 2, 1 << 1, sq); T = {}
    def add(t, mono, s): T[(t, mono)] = T.get((t, mono), 0) + s
    for S in ev:
        for mu in range(n):
            m1, s1 = cpl.bmul(1 << mu, S, sq); m2, s2 = cpl.bmul(m1, Jm, sq); add(m2, ('d', mu, S), s1 * s2 * Js)
        for k in range(n):
            m1, s1 = cpl.bmul(1 << k, S, sq); add(m1, ('A', k, S), -s1)
        m1, s1 = cpl.bmul(S, 1, sq); add(m1, ('m', S), -s1)
    live = [k for k, v in T.items() if v]; per = {}
    for t, _ in live: per[t] = per.get(t, 0) + 1
    return len(live), sorted(set(per.values())), all(cpl.popc(t) % 2 == 1 for t in per)
def pseudoscalar(d):
    """[I^2, I central] for the pseudoscalar of Cl(d,0) through spin_selfcheck.MV"""
    import spin_selfcheck as spn
    sq = [1] * d; I = spn.E(sq, (1 << d) - 1); II = I * I
    return [int(II.scalar()) if II.is_scalar() else None, all(I * spn.E(sq, 1 << t) == spn.E(sq, 1 << t) * I for t in range(d))]
def even_subsets(n): return sum(comb(n, k) for k in range(0, n + 1, 2))
def role_by_sets(a, b, p):                # the role (E: one time index, B: none, T: two) of the symmetric difference of two index pairs
    c = set(a) ^ set(b); t = sum(1 for i in c if i < p); return 'EBT'[0 if t == 1 else 1 if t == 0 else 2]

# ------------------------------------------------------------------------------------------------ the numbers of the lines
NOT_EXACT_PGADYN = ['N9', 'R7', 'R8', 'R9']    # N9 a plausibility test against tabulated semi-major axes; R7, R8, R9 floats to 1e-11 / 1e-13
SPACE_TIME_PAIRS_YM = ['2,3', '2,4', '3,3', '3,4', '3,5', '4,4', '5,4']
def L(row, clause, expected, get, std=None, std_note='', drop=None, cmp=eq, route='stored'):
    return dict(row=row, clause=clause, expected=expected, get=get, std=std, std_note=std_note, drop=drop, cmp=cmp, route=route)
def SENTENCE():
    S = []
    # ---- MAP-005: the charges block of maxwell_selfcheck.py
    S += [L('MAP-005', '9 exact rows', 9, lambda D: D['maxwell']['charges']['counts']['exact'], route='stored, one route'),
          L('MAP-005', '9 exact rows (the stored row table)', 9, lambda D: count(rows_of(D, 'maxwell'), 'kind', 'exact'),
            drop=drop_row('maxwell', lambda r: r['kind'] == 'exact'), route='recount, one route'),
          L('MAP-005', '5 numerical rows', 5, lambda D: D['maxwell']['charges']['counts']['numeric'], route='stored, one route'),
          L('MAP-005', '5 numerical rows (the stored row table)', 5, lambda D: count(rows_of(D, 'maxwell'), 'kind', 'numeric'),
            drop=drop_row('maxwell', lambda r: r['kind'] == 'numeric'), route='recount, one route'),
          L('MAP-005', 'the force in 2, 3 and 4 space dimensions', [2, 3, 4], lambda D: by_id(rows_of(D, 'maxwell'), 'force_is_grade1')['worlds']),
          L('MAP-005', 'the named exact rows: contraction, circle and hyperbola, drift frame, invariants, E parallel B, point charge, light wave',
            ['force_is_contraction', 'circle_and_hyperbola', 'drift_frame', 'invariants', 'parallel', 'point_charge', 'light_wave'],
            lambda D: [r['id'] for r in rows_of(D, 'maxwell') if r['kind'] == 'exact' and r['id'] not in ('force_is_grade1', 'speed_limit')])]
    # ---- RSN-025: maxwell_selfcheck.py, the field equations and the force
    cells = sorted('%d,%d' % (k, d) for k in range(1, 5) for d in range(1, 5) if k + d <= 7)
    S += [L('RSN-025', 'n = k + d with 1 <= k, d <= 4 and k + d <= 7', cells, lambda D: sorted(D['maxwell']['cells'])),
          L('RSN-025', 'grade 1 and grade 3 equations: n + C(n,3) in each cell', [k + d + comb(k + d, 3) for k, d in (map(int, c.split(',')) for c in cells)],
            lambda D: [len(D['maxwell']['cells'][c]['equations']) for c in cells], std=lambda: [k + d + comb(k + d, 3) for k, d in (map(int, c.split(',')) for c in cells)],
            std_note='closed form n + C(n,3)'),
          L('RSN-025', 'F a bivector: E + T + B = C(n,2) components in each cell', [comb(k + d, 2) for k, d in (map(int, c.split(',')) for c in cells)],
            lambda D: [sum(D['maxwell']['cells'][c]['counts'].values()) for c in cells], std=lambda: [comb(k + d, 2) for k, d in (map(int, c.split(',')) for c in cells)],
            std_note='closed form C(n,2)'),
          L('RSN-025', 'the wave equation, grades 1 and 3 only, charge conservation, two sign conventions: in every cell', True,
            lambda D: all(D['maxwell']['cells'][c]['checks'] == {'charge_conservation': True, 'conventions': 2, 'only_grades_1_and_3': True, 'wave_equation': True} for c in cells)),
          L('RSN-025', 'the Lorentz force: one time, d = 2, 3, 4', [2, 3, 4], lambda D: by_id(rows_of(D, 'maxwell'), 'force_is_grade1')['worlds']),
          L('RSN-025', 'the force terms of F u: 2 C(n,2) in d = 2, 3, 4', [6, 12, 20], lambda D: [by_id(rows_of(D, 'maxwell'), 'force_is_grade1')['terms'][d] for d in '234'],
            std=lambda: [2 * comb(d + 1, 2) for d in (2, 3, 4)], std_note='closed form 2 C(d+1,2)'),
          L('RSN-025', 'the contraction: the force terms are the contract incidences, ratio -1 in d = 2, 3, 4', [-1, -1, -1],
            lambda D: [D['maxwell']['charges']['worlds'][d]['incidence_ratio'] for d in '234'])]
    # ---- MAP-016: equations_selfcheck.py part A
    ns = list(range(2, 9)); B = lambda D: D['equations']['commutators']['by_n']
    S += [L('MAP-016', 'every signature with p + q <= 8: n = 2 to 8', ns, lambda D: sorted(int(n) for n in B(D))),
          L('MAP-016', 'every signature: n + 1 signatures (p = 0..n) for each n', [n + 1 for n in ns], lambda D: [B(D)[str(n)]['signatures_checked'] for n in ns],
            std=lambda: [n + 1 for n in ns], std_note='closed form n + 1'),
          L('MAP-016', 'anticommute exactly when they share one index: the pairs that share one index', [n * comb(n - 1, 2) for n in ns],
            lambda D: [B(D)[str(n)]['edges'] for n in ns], std=lambda: [n * comb(n - 1, 2) for n in ns], std_note='closed form n C(n-1,2), pairs of index pairs with one common index'),
          L('MAP-016', 'the other pairs (share 0 or 2 indices) commute', [comb(comb(n, 2), 2) - n * comb(n - 1, 2) for n in ns], lambda D: [B(D)[str(n)]['commuting_pairs'] for n in ns],
            std=lambda: [comb(comb(n, 2), 2) - n * comb(n - 1, 2) for n in ns], std_note='closed form C(C(n,2),2) - n C(n-1,2)'),
          L('MAP-016', 'so(p,q): C(n,2) bivectors, faithful on vectors', [comb(n, 2) for n in ns], lambda D: [B(D)[str(n)]['bivectors'] for n in ns],
            std=lambda: [comb(n, 2) for n in ns], std_note='closed form C(n,2)'),
          L('MAP-016', 'the Lorentz algebra from boosts (E) and rotations (B): E+E -> B, B+E -> E, B+B -> B in Cl(1,3)',
            {'B+B via s': 'B', 'B+E via s': 'E', 'E+E via t': 'B'}, lambda D: {k: v['result'] for k, v in D['equations']['commutators']['roles']['1,3'].items()},
            std=lambda: {'B+B via s': role_by_sets((1, 2), (2, 3), 1), 'B+E via s': role_by_sets((1, 2), (0, 2), 1), 'E+E via t': role_by_sets((0, 1), (0, 2), 1)},
            std_note='the symmetric difference of the index sets, time index 0')]
    # ---- MAP-019: yangmills_selfcheck.py
    ms = list(range(2, 9)); Y = lambda D: D['yangmills']
    S += [L('MAP-019', 'the bivectors of Cl(0,m), m = 2 to 8', ms, lambda D: sorted(int(m) for m in Y(D)['ladder'])),
          L('MAP-019', 'every index triple a closed so(3): 3 C(m,3) non-commuting pairs', [3 * comb(m, 3) for m in ms], lambda D: [Y(D)['ladder'][str(m)]['noncommuting_pairs'] for m in ms],
            std=lambda: [3 * comb(m, 3) for m in ms], std_note='closed form 3 C(m,3)'),
          L('MAP-019', 'Bianchi, first-order covariance, covariant conservation: seven pairs (m, space-time dimension)', SPACE_TIME_PAIRS_YM, lambda D: sorted(Y(D)['identities'])),
          L('MAP-019', 'the three identities hold at every pair', True,
            lambda D: all(v == {'bianchi': True, 'covariant_conservation': True, 'gauge_covariance_first_order': True} for v in Y(D)['identities'].values())),
          L('MAP-019', 'm = 2: one generator and no bracket', [1, 0], lambda D: [Y(D)['ladder']['2']['gens'], Y(D)['ladder']['2']['noncommuting_pairs']],
            std=lambda: [comb(2, 2), 3 * comb(2, 3)], std_note='closed forms C(2,2), 3 C(2,3)'),
          L('MAP-019', 'm = 2 is Maxwell: n C(n,2) terms for n = 2 to 7', [n * comb(n, 2) for n in range(2, 8)], lambda D: [Y(D)['maxwell_reduction'][str(n)]['total'] for n in range(2, 8)],
            std=lambda: [n * comb(n, 2) for n in range(2, 8)], std_note='closed form n C(n,2), the Maxwell incidences')]
    # ---- RSN-005 and MAP-024: forque_selfcheck.py, forque_matrix_check.py
    FQ = lambda D: D['forque']; NC = lambda D: [r for r in rows_of(D, 'forque') if r['status'] == 'not checked']
    for row in ('RSN-005', 'MAP-024'):
        S += [L(row, '41 rows', 41, lambda D: FQ(D)['counts']['rows'], route='stored, one route'),
              L(row, '27 agree', 27, lambda D: FQ(D)['counts']['ok'], route='stored, one route'),
              L(row, '9 after a small adjustment', 9, lambda D: FQ(D)['counts']['note'], route='stored, one route'),
              L(row, '5 not checked', 5, lambda D: FQ(D)['counts']['not_checked'], route='stored, one route'),
              L(row, '41 rows (the stored row table)', 41, lambda D: len(rows_of(D, 'forque')), drop=drop_row('forque', lambda r: True), route='recount, one route'),
              L(row, '27 + 9 + 5 (the statuses of the stored rows)', [27, 9, 5], lambda D: [count(rows_of(D, 'forque'), 'status', s) for s in ('ok', 'note', 'not checked')],
                std=lambda: [41 - 9 - 5, 41 - 27 - 5, 41 - 27 - 9], std_note='the arithmetic 27 + 9 + 5 = 41', drop=drop_row('forque', lambda r: r['status'] == 'ok'), route='recount')]
    S += [L('RSN-005', 'the five not checked: Lagrangian form 2.38, constrained motion 2.9, code figures, exp/log closed forms, exercises',
            ['(2.38)', '2.9,', 'code', 'exp and log', 'exercises'], lambda D: [r['ref'] + ' ' + r['paper'] for r in sorted(NC(D), key=lambda r: r['id'])], cmp=contains_each),
          L('RSN-005', 'F = f.Q in d = 2, 3, 4', [2, 3, 4], lambda D: by_id(rows_of(D, 'forque'), 'F24')['dims']),
          L('RSN-005', 'the equations of motion as exact power series in d = 2, 3 (free, gravity, spring)', [2, 3], lambda D: by_id(rows_of(D, 'forque'), 'F25')['dims']),
          L('RSN-005', 'three wrong right-hand sides do not give Pdot = F', 3, lambda D: sum(1 for v in by_id(rows_of(D, 'forque'), 'F25')['extra']['negative_controls_fail'].values() if v is True)),
          L('RSN-005', 'numpy 4 x 4 matrices against Newton-Euler agree: free top and gravity top, positions to 1e-8', [True, True],
            lambda D: [D['forque_matrix'][k]['ok'] and D['forque_matrix'][k]['position_error'] < 1e-8 for k in ('free_top', 'gravity_top')], route='second engine (numpy, no bit product)'),
          L('MAP-024', 'the tennis-racket rate: the middle axis grows, rate^2 = omega_1 omega_3 Omega^2 > 0 for the four bodies', True,
            lambda D: all(Fr(t['middle_axis_growth_rate_sq_per_Omega_sq']) == Fr(t['inertias'][1] - t['inertias'][2], t['inertias'][0]) * Fr(t['inertias'][0] - t['inertias'][1], t['inertias'][2]) > 0
                          for t in by_id(rows_of(D, 'forque'), 'F34')['extra']['tennis_racket']),
            std=lambda: True, std_note='closed form (i2 - i3)(i1 - i2)/(i1 i3) from the inertias'),
          L('MAP-024', 'the tennis-racket rate measured by numpy for (5, 3, 1): Omega sqrt(omega_1 omega_3) to 1e-3', True,
            lambda D: D['forque_matrix']['tennis_racket']['ok'] and abs(D['forque_matrix']['tennis_racket']['measured_rate_middle_axis'] - sqrt(Fr(2, 5) * 2)) < 1e-3,
            route='second engine (numpy RK4)'),
          L('MAP-024', 'with space squares -1 the law of motion holds: five cases', ['d=2 free', 'd=2 gravity', 'd=3 free', 'd=3 gravity', 'd=3 spring'],
            lambda D: FQ(D)['atlas_signature']['cases'] if FQ(D)['atlas_signature']['law_of_motion_holds'] is True else None)]
    # ---- MAP-018: coupling_selfcheck.py
    C = lambda D: D['coupling']['ladder']
    S += [L('MAP-018', 'J exists from n = 3 (n = 1 to 8)', [False, False, True, True, True, True, True, True], lambda D: [C(D)[str(n)]['J_exists'] for n in range(1, 9)],
            std=lambda: [comb(n - 1, 2) > 0 for n in range(1, 9)], std_note='closed form: C(n-1,2) > 0'),
          L('MAP-018', 'counts 0, 0, 1, 3, 6 (n = 1 to 5)', [0, 0, 1, 3, 6], lambda D: [C(D)[k]['J_count'] for k in sorted(C(D), key=int) if int(k) <= 5],
            std=lambda: [comb(n - 1, 2) for n in range(1, 6)], std_note='closed form C(n-1,2), the bivectors of two space axes', drop=drop_ladder(3)),
          L('MAP-018', 'counts 0, 0, 1, 3, 6 (the E3 row of spin_selfcheck.py)', [0, 0, 1, 3, 6], lambda D: [D['spin']['J'][str(n)]['type2_units_commuting_with_gamma0'] for n in range(1, 6)],
            route='second bit-rule product (spin_selfcheck.py)'),
          L('MAP-018', '(2n+1) 2^(n-1) terms for n = 3 to 8 (stored)', [(2 * n + 1) * 2 ** (n - 1) for n in range(3, 9)], lambda D: [C(D)[str(n)]['incidences_total'] for n in range(3, 9)],
            std=lambda: [(2 * n + 1) * even_subsets(n) for n in range(3, 9)], std_note='(2n+1) times the number of even subsets, by binomial sums'),
          L('MAP-018', '(2n+1) 2^(n-1) terms for n = 3 to 8 (recounted through coupling_selfcheck.bmul)', [(2 * n + 1) * 2 ** (n - 1) for n in range(3, 9)],
            lambda D: [coupled_terms(n)[0] for n in range(3, 9)], route='recount through the page script\'s product'),
          L('MAP-018', 'each of the 2^(n-1) odd equations has 2n+1 terms (n = 3 to 8)', [[2 * n + 1] for n in range(3, 9)], lambda D: [coupled_terms(n)[1] if coupled_terms(n)[2] else None for n in range(3, 9)],
            route='recount through the page script\'s product'),
          L('MAP-018', 'the current is a vector for n = 3, 4 and has a grade-5 part from n = 5', [[1], [1], [1, 5], [1, 5], [1, 5], [1, 5]], lambda D: [C(D)[str(n)]['current_grades'] for n in range(3, 9)]),
          L('MAP-018', 'its conservation on solutions: n = 3, 4, 5', ['3', '4', '5'], lambda D: sorted(k for k, v in D['coupling']['identities'].items() if v['conservation_identity'] is True))]
    # ---- MAP-020: matter_selfcheck.py
    S += [L('MAP-020', 'six pairs (n, m) from (3, 2) to (5, 3)', ['3,2', '3,3', '4,2', '4,3', '4,4', '5,3'], lambda D: sorted(D['matter']['identities'])),
          L('MAP-020', 'covariantly conserved on shell, current not zero, [D,D] Psi = g F Psi, first-order covariance: at every pair', True,
            lambda D: all(v['conserved_on_shell'] is True and v['current_is_not_zero'] is True and v['commutator_identity'] is True and v['gauge_covariance_of_E_first_order'] is True
                          for v in D['matter']['identities'].values()))]
    # ---- MAP-021: gravity_selfcheck.py and the ladder of projective_selfcheck.py
    G = lambda D: D['gravity']; P = lambda D: D['projective']['ladder']
    S += [L('MAP-021', 'three random polynomial fields per case', 3, lambda D: G(D)['sampling']['fields_per_case']),
          L('MAP-021', 'Bianchi, covariance, [D,D] psi: n = 2 to 5', ['2', '3', '4', '5'], lambda D: sorted(G(D)['identities'])),
          L('MAP-021', '0 = 0 at n = 2 for both Bianchi identities', [False, False], lambda D: [G(D)['identities']['2']['terms_nonzero'][k] for k in ('second_bianchi', 'first_bianchi')]),
          L('MAP-021', 'no identity reads 0 = 0 at n = 3, 4, 5', True, lambda D: all(all(G(D)['identities'][n]['terms_nonzero'].values()) for n in '345')),
          L('MAP-021', 'the Einstein form at n = 3 to 5 (with and without the cosmological term)', ['3,0', '3,1', '4,0', '4,1', '5,0', '5,1'], lambda D: sorted(G(D)['einstein_identities'])),
          L('MAP-021', 'the Einstein form equals the Einstein tensor at e = dx: n = 3 to 5', ['3', '4', '5'], lambda D: sorted(G(D)['einstein_tensor_ratio'])),
          L('MAP-021', 'the extra generator at n = 3, 4: curvature R + k e^e with k = -s, torsion coefficient 1',
            {'3,AdS': ['-1', '1'], '3,dS': ['1', '1'], '4,AdS': ['-1', '1'], '4,dS': ['1', '1']},
            lambda D: {k: [v['coefficient_of_e_wedge_e'], v['coefficient_of_torsion']] for k, v in G(D)['desitter'].items()},
            std=lambda: {'%d,%s' % (n, nm): [str(-s), '1'] for n in (3, 4) for s, nm in ((-1, 'dS'), (1, 'AdS'))}, std_note='closed form k = -s'),
          L('MAP-021', 'the extra generator: the same k and mu by numpy matrices (gravity_matrix_check.py)', {'3,AdS': ['-1', '1'], '3,dS': ['1', '1'], '4,AdS': ['-1', '1'], '4,dS': ['1', '1']},
            lambda D: {k: [v['k'], v['mu']] for k, v in D['gravity_matrix']['desitter'].items() if k[0] in '34'}, route='second engine (numpy, no bit product)'),
          L('MAP-021', 'so(1,n): the extra square -1 gives the signature (1, n), n = 2 to 6', [[1, n] for n in range(2, 7)], lambda D: [P(D)['lorentz,%d,-1' % n]['signature_plus_minus'] for n in range(2, 7)],
            std=lambda: [[1, n] for n in range(2, 7)], std_note='count of the squares [+1] + [-1]*(n-1) + [-1]'),
          L('MAP-021', 'so(2,n-1): the extra square +1 gives the signature (2, n-1), n = 2 to 6', [[2, n - 1] for n in range(2, 7)], lambda D: [P(D)['lorentz,%d,1' % n]['signature_plus_minus'] for n in range(2, 7)],
            std=lambda: [[2, n - 1] for n in range(2, 7)], std_note='count of the squares [+1] + [-1]*(n-1) + [+1]'),
          L('MAP-021', 'their Killing forms: p q positive directions (n = 2 to 6)', [n for n in range(2, 7)] + [2 * (n - 1) for n in range(2, 7)],
            lambda D: [P(D)['lorentz,%d,-1' % n]['killing']['positive'] for n in range(2, 7)] + [P(D)['lorentz,%d,1' % n]['killing']['positive'] for n in range(2, 7)],
            std=lambda: [1 * n for n in range(2, 7)] + [2 * (n - 1) for n in range(2, 7)], std_note='closed form p q'),
          L('MAP-021', 'the three squares of the extra generator', [-1, 0, 1], lambda D: sorted({int(k.split(',')[2]) for k in P(D)})),
          L('MAP-021', 'the algebra of the extra generator: n = 2 to 6', [2, 3, 4, 5, 6], lambda D: sorted({int(k.split(',')[1]) for k in P(D)})),
          L('MAP-021', '[B_an, B_bn] = -2 s B_ab by numpy gammas, s = -1, 0, +1, n = 2 to 5, both bases', True,
            lambda D: all(v == {'-1': True, '0': True, '1': True} for v in D['projective_matrix']['ladder'].values()) and len(D['projective_matrix']['ladder']) == 8,
            route='second engine (numpy, no bit product)')]
    # ---- MAP-027: pgadyn_selfcheck.py and matrixrep_check.py
    PG = lambda D: D['pgadyn']
    S += [L('MAP-027', '56 rows', 56, lambda D: PG(D)['summary']['rows'], route='stored, one route'),
          L('MAP-027', '110 claims, all hold', [110, 110], lambda D: [PG(D)['summary']['checks'], PG(D)['summary']['ok']], route='stored, one route'),
          L('MAP-027', '56 rows (the stored row table)', 56, lambda D: len(rows_of(D, 'pgadyn')), drop=drop_row('pgadyn', lambda r: True), route='recount, one route'),
          L('MAP-027', '110 claims (the stored row table)', 110, lambda D: sum(r['checks'] for r in rows_of(D, 'pgadyn')), drop=drop_row('pgadyn', lambda r: True), route='recount, one route'),
          L('MAP-027', '106 exact: 110 less the plausibility row N9 and the float comparisons R7, R8, R9', 106,
            lambda D: sum(r['checks'] for r in rows_of(D, 'pgadyn')) - sum(r['checks'] for r in rows_of(D, 'pgadyn') if r['id'] in NOT_EXACT_PGADYN),
            route='recount, one route (which rows are not exact is read in the source)'),
          L('MAP-027', 'three rows compare floating-point numbers (R7, R8, R9), one claim each', 3,
            lambda D: sum(r['checks'] for r in rows_of(D, 'pgadyn') if r['id'] in NOT_EXACT_PGADYN[1:]), route='recount, one route (read in the source)'),
          L('MAP-027', 'the Moon, the Sun and five planets', ['Earth', 'Jupiter', 'Mars', 'Mercury', 'Sun', 'Venus'], lambda D: sorted(PG(D)['planets_data'])),
          L('MAP-027', 'a floating-point engine checked against them: the rows R1 to R9 hold', True,
            lambda D: [r['id'] for r in rows_of(D, 'pgadyn') if r['id'][0] == 'R'] == ['R%d' % i for i in range(1, 10)] and all(r['ok'] for r in rows_of(D, 'pgadyn') if r['id'][0] == 'R')),
          L('MAP-027', 'Cl(k,k) is the 2^k x 2^k real matrices, k = 1 to 5 (n = 2k)', [2, 4, 6, 8, 10], lambda D: D['matrixrep']['counts']['rep_sizes']),
          L('MAP-027', 'Cl(k,k) as full matrix algebras of size 2^k by the doubling of projective_selfcheck.py, k = 1 to 4', [2, 4, 8, 16],
            lambda D: [D['projective']['doubling']['%d,%d' % (k, k)]['matrix_size'] for k in range(1, 5) if D['projective']['doubling']['%d,%d' % (k, k)]['is_full_matrix_algebra_over_R']],
            std=lambda: [2 ** k for k in range(1, 5)], std_note='closed form 2^k', route='second bit-rule route (explicit matrices)'),
          L('MAP-027', 'Cl(N+8) is the 16 x 16 matrices over Cl(N), N = 0 to 3', ['Cl(0,0)', 'Cl(1,0)', 'Cl(1,1)', 'Cl(2,1)'], lambda D: D['matrixrep']['counts']['period8_bases'])]
    # ---- MAP-025: spin_selfcheck.py
    SPM = lambda D: D['spin']['matrix']
    S += [L('MAP-025', '30 rows (22, 2, 6)', [30, 22, 2, 6], lambda D: [SPM(D)['counts'][k] for k in ('rows', 'ok', 'note', 'not_checked')], route='stored, one route'),
          L('MAP-025', '30 rows (22, 2, 6) (the statuses of the stored rows)', [30, 22, 2, 6],
            lambda D: [len(rows_of(D, 'spin'))] + [count(rows_of(D, 'spin'), 'status', s) for s in ('ok', 'note', 'not checked')],
            std=lambda: [22 + 2 + 6, 30 - 2 - 6, 30 - 22 - 6, 30 - 22 - 2], std_note='the arithmetic 22 + 2 + 6 = 30', drop=drop_row('spin', lambda r: r['status'] == 'ok'), route='recount'),
          L('MAP-025', 'Four kinds of i: three carriers of the planar table (grades (0,1), (0,2), (1,1))', ['(0,1)', '(0,2)', '(1,1)'], lambda D: sorted({v['grades'] for v in D['spin']['planar'].values()})),
          L('MAP-025', 'each carrier has a unit of square -1, +1 and 0', [[-1, 0, 1]] * 3,
            lambda D: [sorted({v['unit_square'] for v in D['spin']['planar'].values() if v['grades'] == g and v['unit_square'] is not None}) for g in ('(0,1)', '(0,2)', '(1,1)')]),
          L('MAP-025', 'and a fourth: the central pseudoscalar of square -1 in Cl(3,0) and Cl(7,0)', [[-1, True], [-1, True]], lambda D: [pseudoscalar(3), pseudoscalar(7)],
            std=lambda: [[(-1) ** (d * (d - 1) // 2), d % 2 == 1] for d in (3, 7)], std_note='closed form I^2 = (-1)^(d(d-1)/2), central exactly for odd d',
            route='recount through the page script\'s product'),
          L('MAP-025', 'Four kinds of i (three carriers and the central pseudoscalar)', 4,
            lambda D: len({v['grades'] for v in D['spin']['planar'].values()}) + (1 if pseudoscalar(3) == [-1, True] and pseudoscalar(7) == [-1, True] else 0))]
    # ---- RSN-008: projective_selfcheck.py
    S += [L('RSN-008', 'Euclid, elliptic, hyperbolic for the extra square 0, -1, +1 on the space base (n = 2 to 6)', [['Euclid', 'elliptic', 'hyperbolic']] * 5,
            lambda D: [[P(D)['space,%d,%d' % (n, s)]['group'] for s in (0, -1, 1)] for n in range(2, 7)]),
          L('RSN-008', 'their Killing forms: so(n+1) negative definite, e(n) degenerate on the n translations, so(n,1) with n positive directions',
            [[0, 0, n] for n in range(2, 7)], lambda D: [[P(D)['space,%d,-1' % n]['killing']['positive'], P(D)['space,%d,-1' % n]['killing']['zero'], P(D)['space,%d,1' % n]['killing']['positive']] for n in range(2, 7)],
            std=lambda: [[0 * (n + 1), 0, 1 * n] for n in range(2, 7)], std_note='closed form p q and n translations'),
          L('RSN-008', 'the Lorentz base Cl(1,3) is the base of n = 4 axes: signature (1, 3)', [1, 3], lambda D: P(D)['lorentz,4,0']['signature_plus_minus'],
            std=lambda: [1, 3], std_note='count of the squares [+1, -1, -1, -1] and a null extra generator'),
          L('RSN-008', 'Poincare, de Sitter, anti-de Sitter on the Lorentz base Cl(1,3)', ['Poincare', 'de Sitter', 'anti-de Sitter'], lambda D: [P(D)['lorentz,4,%d' % s]['group'] for s in (0, -1, 1)]),
          L('RSN-008', 'with space +1 the same algebras with the sign of s flipped, n = 2 to 4', True,
            lambda D: sorted(D['projective']['sign_flip']) == ['%d,%d' % (n, s) for n in (2, 3, 4) for s in (-1, 0, 1)] and all(v['structure_constants_change_sign'] is True and v['killing'] == v['killing_of_flipped'] for v in D['projective']['sign_flip'].values())),
          L('RSN-008', 'PGA embeds in CGA as an injective homomorphism for n = 2, 3 (both bases)', ['lorentz,2', 'lorentz,3', 'space,2', 'space,3'],
            lambda D: sorted(k for k, v in D['projective']['pga'].items() if v.get('injective') is True and v.get('homomorphism') is True)),
          L('RSN-008', 'the dimensions 2^(n+1) and 2^(n+2) for n = 2, 3', [[8, 16], [16, 32]], lambda D: [[D['projective']['pga']['space,%d' % n]['pga_dimension'], D['projective']['pga']['space,%d' % n]['cga_dimension']] for n in (2, 3)],
            std=lambda: [[2 ** (n + 1), 2 ** (n + 2)] for n in (2, 3)], std_note='closed form 2^(n+1), 2^(n+2)'),
          L('RSN-008', 'the PGA blades are independent matrices by numpy (rank 2^(n+1), n = 2 to 4, both bases)', [8, 16, 32, 8, 16, 32],
            lambda D: [D['projective_matrix']['checks']['%s,%d' % (b, n)]['pga_rank'] for b in ('lorentz', 'space') for n in (2, 3, 4)], route='second engine (numpy, no bit product)')]
    return S

def run(S):
    D = load_all()
    head('Logbook lines against the stored results of their page scripts (STEP-LINES)')
    print('  stored results read: ' + ', '.join(p + '.json' for p in PAGES), flush=True)
    rows = []
    for e in S:
        if e['row'] not in rows: rows.append(e['row'])
    for row in rows:
        head(row)
        for e in [x for x in S if x['row'] == row]:
            got = e['get'](D)
            tag = 'std' if e['route'].startswith('second engine') else 'bit'      # a numpy engine never touches the bit rule
            chk(tag, e['cmp'](e['expected'], got), '%s: the line prints %s; %s gives %s' % (e['clause'], e['expected'], e['route'], got))
            if e['std'] is not None:
                st = e['std']()
                chk('std', e['cmp'](e['expected'], st), '%s: %s gives %s' % (e['clause'], e['std_note'], st))
                chk('bit==std', st == got, '%s: the two routes agree' % e['clause'])
            wrong = bump(e['expected'])
            chk('ctl', not e['cmp'](wrong, got), '%s: the value changed by one (%s) is reported as a mismatch' % (e['clause'], wrong))
            if e['drop'] is not None:
                chk('ctl', not e['cmp'](e['expected'], e['get'](e['drop'](D))), '%s: the stored table with one row removed fails the count' % e['clause'])
    n_ok = sum(1 for e in S); print('\n  lines: %d, numbers and names compared: %d' % (len(rows), n_ok), flush=True)

if __name__ == '__main__':
    run(SENTENCE())
    finish('STEP-LINES')
