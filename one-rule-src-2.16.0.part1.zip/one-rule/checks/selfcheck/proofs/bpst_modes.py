#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""bpst_modes.py: the conformal zero modes of the BPST instanton, counted exactly: the fifteen conformal Killing fields of R^4 move the
instanton within a five-dimensional family, 8k - 3 at k = 1.      python3 bpst_modes.py [--fault NAME]

The field (CAND-124, ym_solutions.py, regular gauge): A^a_mu = 2 eta^a_mu.nu x^nu/(x^2 + rho^2), F^a_mu.nu = -4 eta^a_mu.nu rho^2/(x^2 + rho^2)^2,
self-dual; the density rho_YM = sum_a sum_(mu<nu) (F^a_mu.nu)^2 = 192 rho^4/(x^2 + rho^2)^4.  The conformal Killing fields: 4 translations P_mu,
6 rotations M_mu.nu, the dilatation D = x.d, 4 special conformal K_mu = 2 x_mu x.d - x^2 d_mu (d.xi = 0, 0, 4, 8 x_mu).
M1. the linearised self-duality: L_xi F = d(i_xi F) (F closed) is self-dual for all 15 fields and the three colours, (L_xi F)^- = 0 exactly,
    checked at 1296 rational points (a 6^4 grid), enough to make the polynomial numerator (degree <= 5) vanish identically; a random
    quadratic field, not conformal Killing, breaks it (the anti-self-dual part is non-zero at most points).
M2. the density: delta_xi(rho_YM d^4x) = (xi.d rho_YM + (d.xi) rho_YM) d^4x; the 15 functions span a space of dimension exactly 5 (rank 5 at
    40 random rational points: a lower bound; the 10 fields below give 0 identically, on the grid: the upper bound): the 4 translations and
    the dilatation.  The 6 rotations and the 4 combinations K_mu + rho^2 P_mu leave the density fixed: the stabiliser of the instanton
    (the so(5) of a point of hyperbolic 5-space, recalled), 15 - 10 = 5 = 8k - 3.  The combinations K_mu - rho^2 P_mu do not (control).
    A deformation that changes the density is not a gauge transformation: the five are genuine zero modes; that the ten are pure gauge is
    recalled (the SO(5) symmetry of the instanton), not shown here.
[bit]  the Hodge star on 2-forms as the bit rule of Cl(4,0): star(e_S) = -e_S I, I = e_1234 (CAND-062), labels of two bits; exact Fractions.
[std]  the star by the epsilon tensor on components (no label); the density variation by numpy central differences at 40 points (rank 5 by SVD,
       the 10 stabiliser fields give at most 1e-7).
[ctl]  NONCONF (the random quadratic field asserted self-dual), WRONGSIGN (K_mu - rho^2 P_mu asserted to fix the density).
Scope: one instanton (rho^2 = 2, centre 0); the 6^4 grid of points x_i in {-5/2, -3/2, ..., 5/2}; 40 random rational points.  Standard library
and numpy.   Command: python3 bpst_modes.py   (from this folder, or python3 selfcheck/proofs/bpst_modes.py from the root of the checks)."""
import os, sys, itertools, random, time
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('NONCONF', 'WRONGSIGN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time(); RHO2 = Fr(2)

# ------------------------------------------------------------------------------------------------ the field, exactly
def eps3(a, b, c): return (a - b) * (b - c) * (c - a) // 2
ETA = [[[Fr(0)] * 4 for _ in range(4)] for _ in range(3)]                   # eta^a_ij = eps_aij, eta^a_i4 = delta_ai
for a in range(3):
    for i in range(3):
        for j in range(3): ETA[a][i][j] = Fr(eps3(a, i, j))
        ETA[a][i][3] = Fr(int(a == i)); ETA[a][3][i] = Fr(-int(a == i))
def x2(x): return sum(v * v for v in x)
def F_at(x):
    """F^a_mu.nu and its first derivatives d_sigma F^a_mu.nu at x (closed forms of the derivatives)"""
    Q = x2(x) + RHO2; c = -4 * RHO2 / Q ** 2; dc = [16 * RHO2 * x[s] / Q ** 3 for s in range(4)]
    F = [[[ETA[a][m][n] * c for n in range(4)] for m in range(4)] for a in range(3)]
    dF = [[[[ETA[a][m][n] * dc[s] for n in range(4)] for m in range(4)] for a in range(3)] for s in range(4)]
    return F, dF
def density(x): return 192 * RHO2 ** 2 / (x2(x) + RHO2) ** 4
def ddensity(x):
    Q = x2(x) + RHO2; return [192 * RHO2 ** 2 * (-4) * 2 * x[s] / Q ** 5 for s in range(4)]
# ------------------------------------------------------------------------------------------------ the conformal Killing fields: value, Jacobian, divergence
def ck_fields(x):
    """list of (name, xi(x), dxi[mu][sigma] = d_sigma xi^mu, div)"""
    out = []; I4 = [[Fr(int(i == j)) for j in range(4)] for i in range(4)]
    for m in range(4): out.append(('P%d' % m, [Fr(int(i == m)) for i in range(4)], [[Fr(0)] * 4 for _ in range(4)], Fr(0)))
    for m in range(4):
        for n in range(m + 1, 4):
            xi = [Fr(0)] * 4; xi[n] = x[m]; xi[m] = -x[n]
            J = [[Fr(0)] * 4 for _ in range(4)]; J[n][m] = Fr(1); J[m][n] = Fr(-1)
            out.append(('M%d%d' % (m, n), xi, J, Fr(0)))
    out.append(('D', list(x), I4, Fr(4)))
    for m in range(4):
        xx = x2(x); xi = [2 * x[m] * x[i] - (xx if i == m else 0) for i in range(4)]
        J = [[2 * int(s == m) * x[i] + 2 * x[m] * int(i == s) - (2 * x[s] if i == m else 0) for s in range(4)] for i in range(4)]   # d_s xi^i = 2 delta_sm x^i + 2 x_m delta^i_s - 2 x_s delta^i_m
        out.append(('K%d' % m, xi, J, Fr(8) * x[m]))
    return out
def rand_quad(x, seed=17):
    rg = random.Random(seed); C = [[Fr(rg.randint(-2, 2)) for _ in range(10)] for _ in range(4)]
    mon = [(i, j) for i in range(4) for j in range(i, 4)]
    xi = [sum(C[k][t] * x[i] * x[j] for t, (i, j) in enumerate(mon)) for k in range(4)]
    J = [[sum(C[k][t] * ((x[j] if i == s else 0) + (x[i] if j == s else 0)) for t, (i, j) in enumerate(mon)) for s in range(4)] for k in range(4)]
    return ('rand', xi, J, sum(J[k][k] for k in range(4)))
def lie_F(x, xi, J):
    """(L_xi F)^a_mu.nu = xi^s d_s F_mu.nu + (d_mu xi^s) F_s.nu + (d_nu xi^s) F_mu.s"""
    F, dF = F_at(x); out = []
    for a in range(3):
        M = [[Fr(0)] * 4 for _ in range(4)]
        for m in range(4):
            for n in range(4):
                M[m][n] = sum(xi[s] * dF[s][a][m][n] + J[s][m] * F[a][s][n] + J[s][n] * F[a][m][s] for s in range(4))
        out.append(M)
    return out
# ------------------------------------------------------------------------------------------------ the star: bit rule and epsilon
ALG4 = Alg(sig(4, 0)); IVOL = 15
def star_bit(two_form):
    """two_form: {label with two bits: coefficient}; star(e_S) = -e_S I by the bit rule"""
    out = {}
    for S, c in two_form.items():
        s, T = ALG4.blade_mul(S, IVOL); out[T] = out.get(T, 0) - s * c
    return out
def eps4(p):
    s = 1; p = list(p)
    for i in range(4):
        for j in range(i + 1, 4):
            if p[i] > p[j]: s = -s
    return s if len(set(p)) == 4 else 0
def star_eps(M):
    """(star M)_mu.nu = (1/2) eps_mu.nu.rho.sigma M_rho.sigma on components"""
    return [[sum(Fr(eps4((m, n, r, s))) * M[r][s] for r in range(4) for s in range(4)) / 2 for n in range(4)] for m in range(4)]
def to_labels(M): return {(1 << m) | (1 << n): M[m][n] for m in range(4) for n in range(m + 1, 4)}
def asd_part_bit(M):
    f = to_labels(M); sf = star_bit(f); return {S: f.get(S, 0) - sf.get(S, 0) for S in set(f) | set(sf)}

head('M1. the linearised self-duality: (L_xi F)^- = 0 for the 15 conformal Killing fields, on the 6^4 grid')
GRID = [Fr(2 * k - 5, 2) for k in range(6)]
ok_sd = True; ok_eps = True; ok_same = True; bad_rand = 0; npts = 0
for x in itertools.product(GRID, repeat=4):
    npts += 1
    F, _ = F_at(x)
    if npts == 1:
        ok_sd &= all(not any(asd_part_bit(F[a]).values()) for a in range(3))
    fields = ck_fields(x) + ([rand_quad(x)] if True else [])
    for name, xi, J, dv in fields:
        LF = lie_F(x, xi, J)
        for a in range(3):
            asd = asd_part_bit(LF[a]); zero_bit = not any(asd.values())
            SE = star_eps(LF[a]); zero_eps = all(LF[a][m][n] == SE[m][n] for m in range(4) for n in range(4))
            if name == 'rand': bad_rand += not zero_bit; continue
            ok_sd &= zero_bit; ok_eps &= zero_eps; ok_same &= zero_bit == zero_eps
chk('bit', ok_sd, 'bps.M1: F is self-dual and (L_xi F)^- = 0 (the star by the bit rule of Cl(4,0): star e_S = -e_S e_1234) for the 15 conformal Killing fields and 3 colours at all %d grid points: L_xi F solves the linearised self-duality equation exactly' % npts)
chk('std', ok_eps, 'bps.M1: the same with the star by the epsilon tensor on components (no label)')
chk('bit==std', ok_same, 'bps.M1: the two stars agree on the anti-self-dual parts at every point and field')
chk('ctl' if FAULT != 'NONCONF' else 'bit', (bad_rand > 0) if FAULT != 'NONCONF' else (bad_rand == 0), 'bps.M1: a random quadratic field (not conformal Killing) gives a non-zero anti-self-dual part at %d of %d (point, colour) pairs%s' % (bad_rand, 3 * npts, ' (NONCONF asserts none)' if FAULT == 'NONCONF' else ''))

head('M2. the density variation: rank 5, the stabiliser of 10 fields')
rg = random.Random(2026)
PTS = [[Fr(rg.randint(-9, 9), rg.randint(1, 4)) for _ in range(4)] for _ in range(40)]
def dvar(x, xi, J, dv): return sum(xi[s] * ddensity(x)[s] for s in range(4)) + dv * density(x)
NAMES = [f[0] for f in ck_fields([Fr(0)] * 4)]
rows = {nm: [] for nm in NAMES}
for x in PTS:
    for name, xi, J, dv in ck_fields(x): rows[name].append(dvar(x, xi, J, dv))
def rank_frac(M):
    M = [list(r) for r in M]; rk = 0; ncol = len(M[0]) if M else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c] / M[rk][c]; M[i] = [u - f * v for u, v in zip(M[i], M[rk])]
        rk += 1
    return rk
rank15 = rank_frac([rows[nm] for nm in NAMES]); rank5 = rank_frac([rows[nm] for nm in ('P0', 'P1', 'P2', 'P3', 'D')])
sgn = -1 if FAULT == 'WRONGSIGN' else 1
stab_zero = True; wrong_nonzero = False
for x in itertools.product(GRID, repeat=4):
    fl = {f[0]: f for f in ck_fields(x)}
    for m in range(4):
        nK, xiK, JK, dK = fl['K%d' % m]; nP, xiP, JP, dP = fl['P%d' % m]
        v = dvar(x, xiK, JK, dK) + sgn * RHO2 * dvar(x, xiP, JP, dP); stab_zero &= v == 0
        w = dvar(x, xiK, JK, dK) - RHO2 * dvar(x, xiP, JP, dP); wrong_nonzero |= w != 0
    for nm in ('M01', 'M02', 'M03', 'M12', 'M13', 'M23'): stab_zero &= dvar(x, *fl[nm][1:]) == 0
chk('bit', rank15 == 5 and rank5 == 5, 'bps.M2: the 15 density variations have rank %d at 40 random rational points, the 4 translations and the dilatation alone rank %d: a five-dimensional family, 8k - 3 at k = 1 (recalled)' % (rank15, rank5))
chk('bit', stab_zero, 'bps.M2: the 6 rotations and the 4 fields K_mu %s rho^2 P_mu leave the density fixed at all 1296 grid points (identically: the numerator polynomial vanishes on a 6^4 grid): the ten-dimensional stabiliser, so(5) (recalled)' % ('-' if sgn < 0 else '+'))
chk('ctl', wrong_nonzero, 'bps.M2: K_mu - rho^2 P_mu does not fix the density (WRONGSIGN asserts it does)')
# std: numpy central differences of the density 4-form variation
ETAN = np.array([[[float(ETA[a][m][n]) for n in range(4)] for m in range(4)] for a in range(3)]); r2 = float(RHO2)
def dens_np(x): return 192 * r2 ** 2 / (x @ x + r2) ** 4
def xi_np(name, x):
    if name[0] == 'P': v = np.zeros(4); v[int(name[1])] = 1; return v
    if name[0] == 'M': m, n = int(name[1]), int(name[2]); v = np.zeros(4); v[n] = x[m]; v[m] = -x[n]; return v
    if name == 'D': return x.copy()
    m = int(name[1]); return 2 * x[m] * x - (x @ x) * np.eye(4)[m]
def dvar_np(name, x, h=1e-4):
    g = np.array([(dens_np(x + h * np.eye(4)[s]) - dens_np(x - h * np.eye(4)[s])) / (2 * h) for s in range(4)])
    div = sum((xi_np(name, x + h * np.eye(4)[s])[s] - xi_np(name, x - h * np.eye(4)[s])[s]) / (2 * h) for s in range(4))
    return xi_np(name, x) @ g + div * dens_np(x)
Xn = np.array([[dvar_np(nm, np.array([float(v) for v in x])) for x in PTS] for nm in NAMES])
sv = np.linalg.svd(Xn, compute_uv=False); rank_np = int(np.sum(sv > 1e-6 * sv[0]))
stab_np = max(abs(dvar_np('K%d' % m, np.array([float(v) for v in x])) + r2 * dvar_np('P%d' % m, np.array([float(v) for v in x]))) for m in range(4) for x in PTS[:10])
chk('std', rank_np == 5 and stab_np < 1e-6, 'bps.M2: numpy central differences: the 15 variations have numerical rank %d (singular values beyond the fifth below 1e-6 of the first) and K_mu + rho^2 P_mu gives at most %.1e' % (rank_np, stab_np))
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('BPST-MODES')
