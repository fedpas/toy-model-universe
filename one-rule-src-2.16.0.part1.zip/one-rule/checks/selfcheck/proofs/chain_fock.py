#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chain_fock.py: the computable cores of two readings of the Schuller page: left and right multiplication overlap through the
pseudoscalar for odd n (the base and the twisted right action, the fibre, do not), and the complement of a label as particle-hole
conjugation of the fermionic Fock space.
     python3 chain_fock.py [--fault TWIST|DEGEN|REVERSE|ONEFLIP]

chn.9 (LNS-015e).  Every signature Cl(p,q), p + q = n, n = 1..7 (r = 0): the pseudoscalar I = e_1...e_n commutes with every generator for odd
   n and anticommutes for even n; the centre (central blades from the bit-rule signs) is span{1, I} for odd n and R for even n; L_I = R_I for
   odd n; and span{L_a} cap span{R_b} = L(centre): dimension 2 for odd n, 1 for even n (an operator T = L_x = R_y has x = y = T(1) central).
   The twisted right action R'_j x = x^ e_j (x^ the grade involution), whose algebra is the fibre of the row, meets the left algebra only in
   the scalars for every n <= 6: the overlap through I is a property of the plain right multiplication; base and fibre stay independent.
   [bit] bitrule_A.py BR signs, exact (centres, L_I = R_I as signed permutations).  [std] numpy: dim(L cap R) = 2^(n+1) - rank of the
   vectorised 2^n x 2^n matrices of all L_a and R_b (every signature n <= 6, and Cl(7,0), Cl(1,6) at n = 7); the same for R'.
chn.10 (LNS-019d).  On the 2^n labels of n modes (n = 1..8): c_k^+ = left multiplication by e_k in the Grassmann cell BR((0,)*n) (wedge),
   c_k its transpose; N = sum c_k^+ c_k is the popcount (LNS-019b); gamma_k = c_k + c_k^+ and C = gamma_1 ... gamma_n.  Then C|a> = +-|a xor
   1...1>, popcount(a xor 1...1) = n - popcount(a) (n <= 10), C N C^-1 = n - N (so C anticommutes with N - n/2), C c_k C^-1 = (-1)^(n-1) c_k^+
   for every k (creation and annihilation exchanged), C^2 = (-1)^(n(n-1)/2): the complement of a label is particle-hole conjugation.
   [bit] integer matrices from the bit-rule signs, exact integer products (numpy int64).  [std] Jordan-Wigner matrices (Kronecker products of
   sigma^- and Z, numpy floats, n <= 6), equal entry by entry to the bit-rule c_k, and the same identities.
Controls ([ctl]; each --fault puts the wrong version in the main lines, which must then FAIL):
   TWIST the twisted right action R' in place of R in the overlap line (L cap R' = R for odd n too); DEGEN the Grassmann cell Cl(0,0,2) taken
   as an even-n cell (its centre contains e_12); REVERSE C replaced by the bit reversal of the label (keeps the popcount: C N C^-1 = N);
   ONEFLIP C = gamma_1 alone (flips one bit only).
Scope: as stated per item.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this script;
its controls are the faults above.
Command: python3 chain_fock.py   (from this folder, or python3 selfcheck/proofs/chain_fock.py from the package root; standard library,
numpy)."""
import os, sys, itertools
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_researchers = os.path.join(os.path.dirname(os.path.dirname(_here)), 'researchers_checks')
if not os.path.isfile(os.path.join(_researchers, 'bitrule_A.py')): raise SystemExit('bitrule_A.py not found in ' + _researchers + ': this file belongs in selfcheck/proofs/ of the package')
if _researchers not in sys.path: sys.path.insert(0, _researchers)
from bitrule_A import BR

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('TWIST', 'DEGEN', 'REVERSE', 'ONEFLIP')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

# ================================================================================================ chn.9  left and right through I
head('chn.9  for odd n the pseudoscalar is central and left and right multiplication overlap through it (LNS-015e)')
def sigs(n): return [tuple([1] * p + [-1] * (n - p)) for p in range(n + 1)]
def lr_mats(A, twisted=False):
    N = 1 << A.n; L = np.zeros((N, N, N)); R = np.zeros((N, N, N))
    for a in range(N):
        for b in range(N):
            L[a, a ^ b, b] = A.s(a, b)                                    # L_a e_b = s(a,b) e_(a xor b)
            sgn = (-1) ** pc(b) if twisted and pc(a) % 2 else 1
            R[a, b ^ a, b] = sgn * A.s(b, a)                              # R_a e_b = e_b e_a (twisted: x^ e_a for odd a)
    return L, R
def twisted_algebra(A):
    """span of all products R'_j1 ... R'_jk (R'_j x = x^ e_j): matrices"""
    N = 1 << A.n; G = []
    for j in range(A.n):
        M = np.zeros((N, N))
        for b in range(N): M[b ^ (1 << j), b] = ((-1) ** pc(b)) * A.s(b, 1 << j)
        G.append(M)
    out = []
    for S in range(N):
        M = np.eye(N)
        for j in range(A.n):
            if S >> j & 1: M = M @ G[j]
        out.append(M)
    return np.array(out)
def inter_dim(X, Y):
    M = np.vstack([X.reshape(len(X), -1), Y.reshape(len(Y), -1)])
    return len(X) + len(Y) - int(np.linalg.matrix_rank(M))
ok_I = ok_Z = ok_LR = ok_std = ok_tw = True; dims = {}; ncell = 0
for n in range(1, 8):
    cl = sigs(n) + ([(0, 0)] if (FAULT == 'DEGEN' and n == 2) else [])
    for eps in cl:
        A = BR(eps); N = 1 << n; I = N - 1; ncell += 1
        comm = [A.s(1 << i, I) == A.s(I, 1 << i) for i in range(n)]
        ok_I &= all(comm) if n % 2 else not any(comm)
        cen = [a for a in range(N) if all(A.s(a, b) == A.s(b, a) for b in range(N))]
        ok_Z &= cen == ([0, I] if n % 2 else [0])
        if n % 2: ok_LR &= all(A.s(I, b) == A.s(b, I) for b in range(N))
        if n <= 6 or eps in ((1,) * 7, (1,) + (-1,) * 6):
            L, R = lr_mats(A, twisted=(FAULT == 'TWIST'))
            dLR = inter_dim(L, R); dims[(n, eps)] = dLR
            ok_std &= dLR == len(cen) == (2 if n % 2 else 1)
            if n <= 6:
                Tw = twisted_algebra(A)
                ok_tw &= inter_dim(L, Tw) == 1 and int(np.linalg.matrix_rank(Tw.reshape(N, -1))) == N
chk('bit', ok_I, 'chn.9a: %d signatures Cl(p,q), n = 1..7: the pseudoscalar commutes with every generator for odd n and anticommutes with every generator for even n' % ncell)
chk('bit', ok_Z and ok_LR, 'chn.9b: the centre is span{1, I} for odd n and R for even n (central blades from the bit-rule signs), and L_I = R_I for odd n (as signed permutations of the labels)')
chk('std', ok_std, 'chn.9c: numpy ranks: dim(span{L_a} cap span{R_b}) = dim(centre) = 2 for odd n, 1 for even n (every signature n <= 6, and Cl(7,0), Cl(1,6)): left and right overlap exactly through the pseudoscalar')
chk('bit==std', ok_std and ok_Z, 'chn.9d: the overlap computed by ranks is the centre computed from the signs (an operator in both spans is L_x with x = T(1) central)')
chk('ctl', ok_tw, 'chn.9e: the twisted right action R\'_j x = x^ e_j (the fibre): its algebra has dimension 2^n and meets span{L_a} only in the scalars for every signature n <= 6, odd n included: the overlap through I belongs to the plain right multiplication; base and fibre stay independent')

# ================================================================================================ chn.10  particle-hole conjugation
head('chn.10  the complement a -> a xor 1...1 is particle-hole conjugation (LNS-019d)')
def fock_ops(n):
    G = BR((0,) * n); N = 1 << n; cd = []
    for k in range(n):
        M = np.zeros((N, N), dtype=np.int64)
        for a in range(N):
            s_ = G.s(1 << k, a)
            if s_: M[a ^ (1 << k), a] = s_
        cd.append(M)
    c = [M.T.copy() for M in cd]
    return cd, c
ok_pop = all(pc(a ^ ((1 << n) - 1)) == n - pc(a) for n in range(1, 11) for a in range(1 << n))
chk('bit', ok_pop, 'chn.10a: popcount(a xor 1...1) = n - popcount(a) for every label, n = 1..10')
ok_N = ok_C = ok_CN = ok_Cc = ok_C2 = True
for n in range(1, 9):
    cd, c = fock_ops(n); Nn = 1 << n; Id = np.eye(Nn, dtype=np.int64)
    Nop = sum(cd[k] @ c[k] for k in range(n))
    ok_N &= np.array_equal(Nop, np.diag([pc(a) for a in range(Nn)]))
    g = [c[k] + cd[k] for k in range(n)]
    if FAULT == 'REVERSE':
        C = np.zeros((Nn, Nn), dtype=np.int64)
        for a in range(Nn): C[int(format(a, '0%db' % n)[::-1], 2), a] = 1
    elif FAULT == 'ONEFLIP': C = g[0].copy()
    else:
        C = Id.copy()
        for k in range(n): C = C @ g[k]
    tgt = [int(np.nonzero(C[:, a])[0][0]) if np.count_nonzero(C[:, a]) == 1 else -1 for a in range(Nn)]
    ok_C &= all(t == a ^ (Nn - 1) for a, t in enumerate(tgt)) and all(abs(C[tgt[a], a]) == 1 for a in range(Nn) if tgt[a] >= 0)
    Cinv = C.T                                                            # a signed permutation: the inverse is the transpose
    ok_CN &= np.array_equal(C @ Nop @ Cinv, n * Id - Nop) and np.array_equal(C @ (2 * Nop - n * Id) + (2 * Nop - n * Id) @ C, np.zeros_like(C))
    ok_Cc &= all(np.array_equal(C @ c[k] @ Cinv, (-1) ** (n - 1) * cd[k]) for k in range(n))
    ok_C2 &= np.array_equal(C @ C, (-1) ** (n * (n - 1) // 2) * Id)
chk('bit', ok_N, 'chn.10b: n = 1..8: c_k^+ = left multiplication by e_k in the Grassmann cell, c_k its transpose: N = sum c_k^+ c_k is diagonal with the popcount (LNS-019b)')
chk('bit', ok_C, 'chn.10c: C = gamma_1 ... gamma_n (gamma_k = c_k + c_k^+) maps |a> to +-|a xor 1...1> for every label (n = 1..8, exact integer matrices)')
chk('bit', ok_CN, 'chn.10d: C N C^-1 = n - N, so C anticommutes with N - n/2: the complement reverses the particle number (n = 1..8)')
chk('bit', ok_Cc and ok_C2, 'chn.10e: C c_k C^-1 = (-1)^(n-1) c_k^+ for every mode k (creation and annihilation exchanged) and C^2 = (-1)^(n(n-1)/2) (n = 1..8): particle-hole conjugation')
def jw(n):
    sm = np.array([[0., 1.], [0., 0.]]); Z = np.diag([1., -1.]); I2 = np.eye(2); out = []
    for k in range(n):
        fs = [I2] * n
        for j in range(k): fs[n - 1 - j] = Z
        fs[n - 1 - k] = sm
        M = fs[0]
        for f in fs[1:]: M = np.kron(M, f)
        out.append(M)
    return out
ok_jw = ok_jw_eq = True
for n in range(1, 7):
    cj = jw(n); cdj = [M.T for M in cj]; Nn = 1 << n; Id = np.eye(Nn)
    car = all(np.allclose(cj[i] @ cdj[j] + cdj[j] @ cj[i], Id if i == j else 0) and np.allclose(cj[i] @ cj[j] + cj[j] @ cj[i], 0) for i in range(n) for j in range(n))
    Nj = sum(cdj[k] @ cj[k] for k in range(n)); Cj = Id.copy()
    for k in range(n): Cj = Cj @ (cj[k] + cdj[k])
    ok_jw &= car and np.allclose(Cj @ Nj @ Cj.T, n * Id - Nj) and all(np.allclose(Cj @ cj[k] @ Cj.T, (-1) ** (n - 1) * cdj[k]) for k in range(n))
    cd, c = fock_ops(n)
    ok_jw_eq &= all(np.array_equal(c[k].astype(float), cj[k]) for k in range(n))
chk('std', ok_jw, 'chn.10f: Jordan-Wigner matrices (sigma^- with Z strings, n = 1..6): the CAR hold, and C = prod (c_k + c_k^+) satisfies C N C^-1 = n - N and C c_k C^-1 = (-1)^(n-1) c_k^+')
chk('bit==std', ok_jw_eq and ok_jw and ok_CN, 'chn.10g: the bit-rule annihilators equal the Jordan-Wigner ones entry by entry (n = 1..6): the two routes are one Fock space')
okc_rev = True
n = 3; Nn = 8; P = np.zeros((Nn, Nn), dtype=np.int64)
for a in range(Nn): P[int(format(a, '03b')[::-1], 2), a] = 1
cd, c = fock_ops(3); Nop = sum(cd[k] @ c[k] for k in range(3))
okc_rev = np.array_equal(P @ Nop @ P.T, Nop) and not np.array_equal(P @ Nop @ P.T, 3 * np.eye(Nn, dtype=np.int64) - Nop)
g0 = c[0] + cd[0]; okc_one = not np.array_equal(g0 @ Nop @ g0.T, 3 * np.eye(Nn, dtype=np.int64) - Nop)
chk('ctl', okc_rev and okc_one, 'chn.10h: wrong versions fail (n = 3): the bit reversal of the label keeps the particle number (P N P^-1 = N); gamma_1 alone flips one seat and does not give n - N')

finish('CHAIN-FOCK')
