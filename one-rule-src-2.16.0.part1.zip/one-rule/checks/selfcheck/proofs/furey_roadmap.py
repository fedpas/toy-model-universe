#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""furey_roadmap.py: Furey's roadmap on the labels: the Lorentz side C (x) H, the algebra C (x) Cl(0,10) of the left and right
multiplications on C (x) H (x) O, her five ladder pairs as the Witt pairs of the five-bit Fock labels, her vacuum, the 32 states, P_L and
the chirality, the 45 quadratic operators, her hypercharge and weak su(2) as the bits, and the four Fano-line blades outside the image of
C (x) Cl(0,6) (round 13, proofs pass 11a; docs/round13/PLAN.md, items 1, 2, 3, 6).
     python3 furey_roadmap.py [--fault NOI|WRONGPAIR|ODDPL|VOLSIGN|BITPERM|INLINE]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q) has its p generators
of square +1 first (core_check.sig); the type table core_check.TYPE.  The complex scalar is a blade of the cell (the volume element of
Cl(3,0), Cl(1,2), Cl(1,6), Cl(1,10)), never a Python complex number; numpy only on the standard route.  The roadmap enters as data: the matrices of
selfcheck/furey_papers_check.py (A1-A5, R1-R5, R11; Roadmap I, arXiv:2312.12377, as the Atlas read it), rebuilt here: Gamma_j = i L_ej L_e7
R_eps1 (j <= 6), Gamma_(6+m) = L_e7 L_epsm R_eps1, Gamma_10 = R_eps2 on C (x) H (x) O = C^32; R1's pairs a_c = (-Gamma_j + i Gamma_k)/2 for
(j,k) = (5,4), (3,1), (6,2), (8,7), (10,9).  On the labels the five pairs are taken in the bit order (8,7), (10,9), (5,4), (3,1), (6,2):
bits 0, 1 weak and 2, 3, 4 colour, as in CAND-003/CAND-019 (jordan_sm.py, sm16_labels.py).
fr.HC   C (x) H: Cl(3,0) and Cl(1,2) are M2(C) with the central i; H inside; Cl+(1,3) = Cl(3,0) with i = I; so(1,3) = sl(2,C); the
        idempotent (1 - i eps3)/2 = (1 - e3)/2; Furey-Hughes's basis of C (x) H (arXiv:2409.17948, eq. 31) as the matrix units of M2(C).
        [std] Pauli matrices; her L_eps on C (x) H = C^4.  [ctl] Cl(0,3) = H + H.
fr.ALG  C (x) Cl(0,10): Cl(1,10) and Cl(11,0) are M32(C); the copy of Cl(0,10) in Cl(1,10); Gamma11 = e1..e10, Gamma11 i = -e0.
        [std] A1-A5 rebuilt, e0 -> i R_eps3: the 2048 words span M32(C).
fr.WITT the five pairs: alpha = (-e_j + i e_k)/2, the CAR; GEN-015's Cl(5,5) mapped by e_b -> i e_k, f_b -> e_j; her vacuum (R2) on the
        labels and its minimal ideal.  [std] R1, R2.  [ctl] NOI, WRONGPAIR.
fr.FOCK the 32 states as the five-bit labels; P_L = (1 + i Gamma11)/2 = (1 - e0)/2 the even labels; the chirality as the parity of the
        label.  [std] R3, A5.  [ctl] ODDPL, VOLSIGN.
fr.BIV  the 45 quadratic operators and the 45 bivectors of the copy (CAND-019, CAND-136).  [std] R4, R5.
fr.HYP  her modes as the bits: Y = a/2 - b/3, Q, B-L, T3 and the weak su(2) as quadratic ladder expressions.  [std] R11 and
        T_m = (i/2) L_epsm s.  [ctl] BITPERM.
fr.LINE the four Fano-line blades outside the image of C (x) Cl(0,6) in the Cl(0,8) of FUR-019 (pass 10a's embedding): the pairs of axes,
        her eight states, the second ideal, the algebra they generate.  [std] the model's 16 x 16 matrices.  [ctl] INLINE.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   NOI the five pairs without the central i; WRONGPAIR the overlapping pairs (8,7), (10,9), (5,4), (3,4), (6,2); ODDPL the odd-label
   projector taken as P_L; VOLSIGN the volume element with the other sign as the chirality (-Gamma11 on the labels, +R_eps3 on the
   matrices); BITPERM the bits permuted, weak and colour exchanged; INLINE a line blade through e7 in place of the four.
Not computed here (stated, not checked): Furey's symmetry breaking (R7-R10), the Lorentz representations beyond the idempotent, the group
Spin(10), the generations of Furey-Hughes (item 4: arXiv:2409.17948, eqs. 32-39, read by L2, docs/round13/SOURCES.md (g2); only the basis
of eq. 31 is computed), any statement that the charges or the names of states are nature's.
Command: python3 -I -B selfcheck/proofs/furey_roadmap.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, time, random, itertools, importlib.util
from collections import Counter
from fractions import Fraction as Fr
from math import isqrt
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (os.path.join(_checks, 'reports', 'furey'), 'model.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
_spec = importlib.util.spec_from_file_location('furey_model', os.path.join(_checks, 'reports', 'furey', 'model.py'))
OM = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(OM)  # the octonion model, data only (as furey_cl6.py)

# ------------------------------------------------------------------------------------------------ check lines (from furey_cl6.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('furey_roadmap: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NOI', 'WRONGPAIR', 'ODDPL', 'VOLSIGN', 'BITPERM', 'INLINE')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261017)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ the kernel's formula and the label types
# copied from furey_cl6.py (which copied them from chain_blocks.py through fibre_base.py; no __main__ guard in any of them)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i"""
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)): par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]
def table(eps):
    a = np.arange(1 << len(eps), dtype=np.int64); return s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from the dimension, the number c of simple summands, a complex centre, and the count fs (c m, 0, -2 c m)"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D]); m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def table_type(S, gens):
    """the type of the algebra with the sign table S (every e_a^2 = +-1) and generator labels gens: centre, its squares, the count"""
    central = np.ones(S.shape[0], dtype=bool)
    for g in gens: central &= (S[:, g] == S[g, :])
    Z = np.nonzero(central)[0]; sq = S[Z, Z]
    cplx = bool(np.any(sq == -1)); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(S.shape[0], c, cplx, int(np.trace(S.astype(np.int64))))
def ltype_eps(eps):
    """the type of a non-degenerate cell from its labels: the count by the kernel formula, the central blades by the reordering counts"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
    return type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
def clock_type(p, q):
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2); assert r == 0 and m * m == m2
    return (D, m, c)

# copied from furey_cl6.py (from chiral_spinors.py through fibre_base.py): an exact rational null space, the rank
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis
def rank_frac(M):
    """exact rank of an integer or Fraction matrix (a list of rows or a numpy array)"""
    rows = [[Fr(x) for x in r] for r in (M.tolist() if hasattr(M, 'tolist') else M)]
    return len(rows[0]) - len(nullspace_frac(rows, len(rows[0]))) if rows else 0

# ------------------------------------------------------------------------------------------------ multivectors on the labels (exact)
# copied from furey_cl6.py (Cell, add, scal, lin, eq, blade, rank_mv; Cell also keeps the numpy table as T, for vectorised checks)
class Cell:
    """the labels of a cell: e_a e_b = s(a,b) e_(a xor b), s read as the table of s_vec (checked against BR below); multivectors are
    dicts label -> Fraction"""
    def __init__(self, eps):
        self.eps = tuple(eps); self.n = len(eps); self.M = 1 << self.n; self.T = table(self.eps); self.S = self.T.tolist()
    def mul(self, x, y):
        S = self.S; out = {}
        for a, ca in x.items():
            Sa = S[a]
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + Sa[b] * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
    def prod(self, *xs):
        out = {0: Fr(1)}
        for x in xs: out = self.mul(out, x)
        return out
    def comm(self, x, y): return add(self.mul(x, y), self.mul(y, x), -1)
    def anti(self, x, y): return add(self.mul(x, y), self.mul(y, x))
    def sq(self, a): return self.S[a][a]
    def commute(self, a, b): return self.S[a][b] == self.S[b][a]
def add(x, y, c=1):
    out = dict(x)
    for k, v in y.items():
        w = out.get(k, 0) + c * v
        if w: out[k] = w
        else: out.pop(k, None)
    return out
def scal(x, c): return {k: c * v for k, v in x.items() if c * v != 0}
def lin(*terms):
    out = {}
    for c, x in terms: out = add(out, x, c)
    return out
def eq(x, y): return add(x, y, -1) == {}
def blade(a, c=1): return {a: Fr(c)}
ONE = blade(0)
def rank_mv(vs):
    """the exact rank of a list of multivectors: the vectors fall into components that share labels (union-find); rank_frac on each"""
    parent = {}
    def find(x):
        while parent.setdefault(x, x) != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for v in vs:
        ks = list(v)
        for k in ks[1:]:
            ra, rb = find(ks[0]), find(k)
            if ra != rb: parent[ra] = rb
    groups = {}
    for v in vs:
        if v: groups.setdefault(find(next(iter(v))), []).append(v)
    tot = 0
    for g in groups.values():
        labs = sorted({k for v in g for k in v}); tot += rank_frac([[v.get(k, 0) for k in labs] for v in g])
    return tot
def words_mv(C, G):
    W = [ONE]
    for a in range(1, 1 << len(G)):
        top = a.bit_length() - 1; W.append(C.mul(W[a ^ (1 << top)], G[top]))
    return W
def centre(C): return [a for a in range(C.M) if all(C.commute(a, 1 << i) for i in range(C.n))]

# copied from furey_cl6.py (Lab, comm_labels, span_tau, Ideal, mv_mat; from fibre_base.py): a minimal left ideal A f, f = prod (1 + e_g)/2
# over commuting labels of square +1, the left multiplications by labels as signed permutation matrices
class Lab:
    def __init__(self, s, N): self.s, self.N, self.M = s, N, 1 << N
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
def comm_labels(L, first=(), even=False, tries=60):
    best = None
    for k in range(tries):
        order = list(range(1, L.M)); RNG.shuffle(order); G = list(first); span = {0}
        for g in G: span |= {x ^ g for x in span}
        for u in order:
            if u in span or L.sq(u) != 1 or (even and pc(u) % 2) or not all(L.commute(u, g) for g in G): continue
            G.append(u); span |= {x ^ u for x in span}
        if best is None or len(G) > len(best): best = G
    return best
def span_tau(L, G):
    tau = {0: 1}
    for g in G:
        for h, t in list(tau.items()): tau[h ^ g] = L.s(h, g) * t
    return tau
class Ideal:
    def __init__(self, L, G):
        self.L, self.G = L, list(G); self.tau = span_tau(L, G); H = list(self.tau)
        self.rep = {}; self.reps = []
        for a in range(L.M):
            if a not in self.rep:
                self.reps.append(a)
                for h in H: self.rep[a ^ h] = (a, h)
        self.m = len(self.reps); self.idx = {r: i for i, r in enumerate(self.reps)}
    def act(self, b):
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[b ^ r]; R[self.idx[r2], self.idx[r]] = self.L.s(b, r) * self.L.s(r2, h) * self.tau[h]
        return R
def mv_mat(I_, x):
    """the left action of a multivector on an Ideal, as a Fraction matrix (a list of rows)"""
    out = [[Fr(0)] * I_.m for _ in range(I_.m)]
    for a, c in x.items():
        R = I_.act(a)
        for i, j in zip(*np.nonzero(R)): out[i][j] += c * int(R[i, j])
    return out

# ------------------------------------------------------------------------------------------------ the octonions and quaternions, as data
# the Roadmap tables in Furey's labelling, copied from furey_papers_check.py through furey_cl6.py (trip, fo, omul, LO, RO; qmul, LH, RH;
# no __main__ guard there: it runs on import)
TRIP = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
FO = np.zeros((8, 8, 8), dtype=np.int64)
for (i_, j_, k_) in TRIP:
    for (a_, b_, c_) in [(i_, j_, k_), (j_, k_, i_), (k_, i_, j_)]:
        FO[a_, b_, c_] = 1; FO[b_, a_, c_] = -1
def omul_f(i_, j_):
    if i_ == 0: return 1, j_
    if j_ == 0: return 1, i_
    if i_ == j_: return -1, 0
    for k_ in range(1, 8):
        if FO[i_, j_, k_] != 0: return int(FO[i_, j_, k_]), k_
LO = np.zeros((8, 8, 8), dtype=np.int64); RO = np.zeros((8, 8, 8), dtype=np.int64)
for a_ in range(8):
    for j_ in range(8):
        s_, k_ = omul_f(a_, j_); LO[a_][k_, j_] = s_
        s_, k_ = omul_f(j_, a_); RO[a_][k_, j_] = s_
def qmul_f(i_, j_):
    if i_ == 0: return 1, j_
    if j_ == 0: return 1, i_
    if i_ == j_: return -1, 0
    k_ = 6 - i_ - j_; return int(round(np.linalg.det(np.eye(3)[[i_ - 1, j_ - 1, k_ - 1]]))), k_
LH = np.zeros((4, 4, 4), dtype=np.int64); RH = np.zeros((4, 4, 4), dtype=np.int64)
for a_ in range(4):
    for j_ in range(4):
        s_, k_ = qmul_f(a_, j_); LH[a_][k_, j_] = s_
        s_, k_ = qmul_f(j_, a_); RH[a_][k_, j_] = s_
F2M = {1: (6, -1), 2: (1, 1), 3: (5, -1), 4: (7, -1), 5: (4, 1), 6: (2, 1), 7: (3, 1)}  # Furey's e_a = sign x the model's unit (furey_cl6.py)

# ------------------------------------------------------------------------------------------------ the standard route's tools (no label)
# fwords, realify, mat_table, frel_ok, prodm copied from furey_cl6.py (from fibre_base.py; mat_table follows chain_blocks.py)
def fwords(G, dtype=np.float64):
    n = len(G); d = G[0].shape[0]; W = np.zeros((1 << n, d, d), dtype=dtype); W[0] = np.eye(d)
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W[a] = W[a ^ (1 << top)] @ G[top].astype(dtype)
    return W
def realify(Zc): return np.block([[Zc.real, -Zc.imag], [Zc.imag, Zc.real]])
def mat_table(W):
    """the sign table read from matrices whose generators obey the relations: W_a W_b = c W_(a xor b), c from the images of a vector"""
    M = W.shape[0]; ar = np.arange(M); V = W[:, :, 0]; nrm = (V * V).sum(1); C = np.zeros((M, M))
    for a in range(M): C[a] = ((W[a] @ V.T) * V[a ^ ar].T).sum(0) / nrm[a ^ ar]
    return np.rint(C).astype(np.int64), bool(np.allclose(C, np.rint(C)))
def frel_ok(G, eps):
    I = np.eye(G[0].shape[0])
    return all(np.allclose(G[i] @ G[j] + G[j] @ G[i], 2 * eps[i] * I if i == j else 0 * I) for i in range(len(G)) for j in range(i, len(G)))
def prodm(ms):
    P_ = np.eye(ms[0].shape[0], dtype=ms[0].dtype)
    for m_ in ms: P_ = P_ @ m_
    return P_
def kernel_ok(C, K):
    """the cell's table against the kernel BR.s on every pair of labels"""
    return all([K.s(a, b) for b in range(C.M)] == C.S[a] for a in range(C.M))

# ================================================================================================ fr.HC  C (x) H, the Lorentz side
head('fr.HC  C (x) H on the labels: Cl(3,0) and Cl(1,2) = M2(C) with the central i; H inside; the even part of Cl(1,3); so(1,3) = sl(2,C)')
t = time.time()
E30, E12, E03, E13, E02 = sig(3, 0), sig(1, 2), sig(0, 3), sig(1, 3), sig(0, 2)
C30, C12, C03, C13, C02 = Cell(E30), Cell(E12), Cell(E03), Cell(E13), Cell(E02)
okK = all(kernel_ok(C, BR(E)) for C, E in ((C30, E30), (C12, E12), (C03, E03), (C13, E13), (C02, E02)))
tys = (ltype_eps(E30), ltype_eps(E12)); cens = (centre(C30), centre(C12))
ok1 = okK and tys == (clock_type(3, 0), clock_type(1, 2)) == (('C', 2, 1), ('C', 2, 1)) and cens == ([0, 7], [0, 7])
ok1 &= C30.sq(7) == -1 == C12.sq(7) and sum(C30.S[a][a] for a in range(8)) == 0 == sum(C12.S[a][a] for a in range(8))
chk('bit', ok1, 'fr.HC: Cl(3,0) (clock 3) and Cl(1,2) (clock 7) on their 8 labels (BR.s on every pair): types %s and %s, centre span{1, i} with i the label 7 (e1e2e3; e0e1e2), i^2 = -1, count 0: C (x) H = M2(C)' % (tstr(tys[0]), tstr(tys[1])))
t03 = ltype_eps(E03)
chk('ctl', t03 == ('H', 1, 2) and centre(C03) == [0, 7] and C03.sq(7) == 1, 'fr.HC: Cl(0,3) is %s (central e1e2e3 of square +1, count -4): not C (x) H' % tstr(t03))
EPS = [scal(C30.mul(blade(2), blade(4)), -1), scal(C30.mul(blade(4), blade(1)), -1), scal(C30.mul(blade(1), blade(2)), -1)]   # -e2e3, -e3e1, -e1e2
okH = all(eq(C30.mul(x, x), scal(ONE, -1)) for x in EPS) and eq(C30.mul(EPS[0], EPS[1]), EPS[2]) and eq(C30.mul(EPS[1], EPS[2]), EPS[0]) and eq(C30.mul(EPS[2], EPS[0]), EPS[1])
okH &= sorted(next(iter(x)) for x in EPS) == [3, 5, 6] and all(C12.S[2 * a][2 * b] == C02.S[a][b] for a in range(4) for b in range(4))
okH &= eq(C02.mul(blade(1), blade(2)), blade(3)) and all(C02.sq(a) == -1 for a in (1, 2, 3)) and all(C12.commute(2 * a, 7) for a in range(4))
chk('bit', okH, 'fr.HC: H inside: in Cl(3,0) the even part, eps1 = -e2e3, eps2 = -e3e1, eps3 = -e1e2 of square -1 with eps1 eps2 = eps3 (cyclic); in Cl(1,2) the two generators of square -1 and their product, Cl(0,2) = H on the nose (labels with bit 0 clear, the same signs), as Cl(0,6) sits in Cl(1,6) (FUR-015)')
SIG3 = [C13.mul(blade(1 << k), blade(1)) for k in (1, 2, 3)]               # sigma_k = e_k e0 in Cl(1,3) (e0 = bit 0, of square +1)
W13 = words_mv(C13, SIG3); EV16 = [a for a in range(16) if pc(a) % 2 == 0]
okE = all(len(w) == 1 for w in W13) and sorted(next(iter(w)) for w in W13) == EV16 and eq(W13[7], blade(15))
okE &= all(eq(C13.mul(W13[a], W13[b]), scal(W13[a ^ b], C30.S[a][b])) for a in range(8) for b in range(8))
okE &= eq(C13.mul(blade(6), scal(blade(15), -1)), blade(9)) and C13.sq(15) == -1                      # e1e2 I^-1 = e0e3 (FUR-020)
chk('bit', okE, 'fr.HC: the even part of the spacetime cell Cl(1,3) is Cl(3,0) on its 8 even labels: sigma_k = e_k e0 square to +1, anticommute, and their words multiply by the table of Cl(3,0) on all 64 pairs; sigma1 sigma2 sigma3 = I = e0e1e2e3: the i of C (x) H is the complex structure I of FUR-011 and FUR-020 (e1e2 I^-1 = e0e3)')
B6 = [3, 5, 9, 6, 10, 12]                                                  # boosts e0e1, e0e2, e0e3; rotations e1e2, e1e3, e2e3 (labels of Cl(1,3))
def bcoef(x): return [Fr(x.get(b, 0)) for b in B6] if all(a in B6 for a in x) else None
AD6 = [[bcoef(C13.comm(blade(p), blade(q))) for q in B6] for p in B6]    # ad(b_p) b_q in the basis B6
okL = all(c is not None for row in AD6 for c in row)
KIL = [[sum(AD6[p][r][s] * AD6[q][s][r] for r in range(6) for s in range(6)) for q in range(6)] for p in range(6)] if okL else None
diagK = okL and all(KIL[p][q] == 0 for p in range(6) for q in range(6) if p != q)
sgnK = (sum(1 for p in range(6) if KIL[p][p] > 0), sum(1 for p in range(6) if KIL[p][p] < 0)) if diagK else None
okB = eq(C30.mul(blade(4), blade(7)), C30.mul(blade(1), blade(2)))                                 # sigma3 i = sigma1 sigma2: sigma3 = -i sigma1 sigma2
okB &= all(C13.sq(b) == (1 if b in (3, 5, 9) else -1) for b in B6)
chk('bit', okL and diagK and sgnK == (3, 3) and okB, 'fr.HC: the Lorentz so(1,3), the six bivectors of Cl(1,3): boosts e0e_k (square +1) and rotations e_ie_j (square -1) close; their Killing form tr(ad ad) is diagonal on the labels with %s positive and negative entries; in Cl(3,0) sigma3 = -i sigma1 sigma2 (cyclic): each boost is i times a rotation, so(1,3) = sl(2,C)' % (sgnK,))
IE3 = C30.mul(blade(7), EPS[2]); PW = scal(add(ONE, IE3, -1), Fr(1, 2))
LW = rank_mv([C30.mul(blade(a), PW) for a in range(8)]); okIE = all(eq(C30.mul(blade(7), EPS[m]), blade(1 << m)) for m in range(3))
chk('bit', okIE and eq(IE3, blade(4)) and eq(C30.mul(PW, PW), PW) and PW.get(0) == Fr(1, 2) and LW == 4, 'fr.HC: in Cl(3,0) i eps_m = e_m (m = 1, 2, 3: the i eps_m <-> sigma_m of Furey 2018, eq. 5), so (1 - i eps3)/2 = (1 - e3)/2: an idempotent of scalar part 1/2 whose left ideal has real dimension %d (complex 2): primitive in M2(C)' % LW)
IE1 = C30.mul(blade(7), EPS[0])
MU = {(0, 0): scal(add(ONE, IE3), Fr(1, 2)), (0, 1): scal(add(scal(EPS[1], -1), IE1), Fr(1, 2)), (1, 0): scal(add(EPS[1], IE1), Fr(1, 2)), (1, 1): PW}
okMU = all(eq(C30.mul(MU[a, b], MU[c, d]), MU[a, d] if b == c else {}) for a in range(2) for b in range(2) for c in range(2) for d in range(2)) and eq(add(MU[0, 0], MU[1, 1]), ONE)
chk('bit', okMU, 'fr.HC: Furey and Hughes\'s basis of C (x) H (arXiv:2409.17948, eq. 31; arXiv:2209.13016, eq. 28), eps_uu = (1 + i eps3)/2, eps_ud = (-eps2 + i eps1)/2, eps_du = (eps2 + i eps1)/2, eps_dd = (1 - i eps3)/2, is on the labels of Cl(3,0) the four matrix units of M2(C): eps_ab eps_cd = delta_bc eps_ad on all 16 products, eps_uu + eps_dd = 1, and eps_dd = (1 - e3)/2')
note('(%.1f s)' % (time.time() - t))
t = time.time()
PAULI = [np.array([[0, 1], [1, 0]], dtype=complex), np.array([[0, -1j], [1j, 0]]), np.array([[1, 0], [0, -1]], dtype=complex)]
GH = [1j * LH[k].astype(complex) for k in (1, 2, 3)]                    # e_k -> i L_epsk on C (x) H = C^4 (her quaternion table)
WP, WH = fwords(PAULI, np.complex128), fwords(GH, np.complex128)
rkw = [int(np.linalg.matrix_rank(np.array([realify(w).ravel() for w in W]))) for W in (WP, WH)]
okS = frel_ok(PAULI, E30) and frel_ok(GH, E30) and np.allclose(WP[7], 1j * np.eye(2)) and np.allclose(WH[7], 1j * np.eye(4)) and rkw == [8, 8]
okS &= np.allclose(-GH[1] @ GH[2], LH[1]) and np.allclose(-GH[2] @ GH[0], LH[2]) and np.allclose(-GH[0] @ GH[1], LH[3])
rkI = [int(np.linalg.matrix_rank((np.eye(4) - 1j * M) / 2)) for M in (LH[3], RH[3])]
chk('std', okS and rkI == [2, 2], 'fr.HC: numpy, no label: the Pauli matrices and her left multiplications e_k -> i L_epsk on C (x) H = C^4 obey Cl(3,0) with volume element i 1, their 8 words have real rank %s (M2(C)), -e_j e_k -> L_eps(m); (1 - i L_eps3)/2 and (1 - i R_eps3)/2 have complex rank %s on C^4' % (rkw, rkI))
TP, okTP = mat_table(np.array([realify(w) for w in WP])); TH, okTH = mat_table(np.array([realify(w) for w in WH]))
def rhoP(x): return sum(float(c) * WP[a] for a, c in x.items())
okMP = all(np.allclose(rhoP(MU[a, b]), np.eye(2)[:, [a]] @ np.eye(2)[[b], :]) for a in range(2) for b in range(2))
chk('bit==std', okTP and okTH and np.array_equal(TP, C30.T.astype(np.int64)) and np.array_equal(TH, C30.T.astype(np.int64)) and okMP, 'fr.HC: the sign tables read from the Pauli words and from her quaternion words equal the label table of Cl(3,0) on all 64 entries; the image of the label 7 is i 1, that of eps_m is L_eps(m); under e_k -> sigma_k the four eps_ab are the matrix units E_ab')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.ALG  the roadmap's algebra C (x) Cl(0,10)
head('fr.ALG  the roadmap\'s algebra C (x) Cl(0,10) on the labels: Cl(1,10) and Cl(11,0) = M32(C); the copy of Cl(0,10); Gamma11 = e1..e10 and e0')
t = time.time()
E110, E011, E010 = sig(1, 10), sig(11, 0), sig(0, 10)
C110 = Cell(E110); S110 = C110.T.astype(np.int64)
TOP, GAM = 2047, 2046                                                     # i = e0 e1 .. e10; Gamma11 = e1 .. e10, the copy's volume element
I_ = blade(TOP)
okK = kernel_ok(C110, BR(E110))
tys = (ltype_eps(E110), ltype_eps(E011)); cen = centre(C110)
ok1 = okK and tys == (clock_type(1, 10), clock_type(11, 0)) == (('C', 32, 1), ('C', 32, 1)) and cen == [0, TOP] and C110.sq(TOP) == -1 and int(np.trace(S110)) == 0
chk('bit', ok1, 'fr.ALG: Cl(1,10) (clock 7) and Cl(11,0) (clock 3) on 2048 labels (the table of Cl(1,10) is BR.s on all 4194304 pairs): types %s and %s, centre span{1, i} with i the label 2047 of square -1, count 0: C (x) Cl(0,10) = M32(C)' % (tstr(tys[0]), tstr(tys[1])))
t010 = ltype_eps(E010)
okC = np.array_equal(S110[0::2, 0::2], table(E010).astype(np.int64)) and all(C110.commute(2 * a, TOP) for a in range(1024)) and t010 == ('H', 16, 1)
chk('bit', okC, 'fr.ALG: in Cl(1,10) the ten generators of square -1 are Cl(0,10) = %s (FUR-021) on the nose: the 1024 labels with bit 0 clear, with the signs of Cl(0,10), commuting with i; the rows use Cl(1,10) = Cl(1,0) (x)^ Cl(0,10), as FUR-015 used Cl(1,6)' % tstr(t010))
com_G = [a for a in range(2048) if C110.commute(a, GAM)]
okG = C110.sq(GAM) == -1 and com_G == [a for a in range(2048) if pc(a >> 1) % 2 == 0] and all(not C110.commute(1 << p, GAM) for p in range(1, 11)) and C110.commute(1, GAM)
GI = C110.mul(blade(GAM), I_); IG = C110.mul(I_, blade(GAM))
PPm, PPp = scal(add(ONE, IG, -1), Fr(1, 2)), scal(add(ONE, IG), Fr(1, 2))   # (1 - i Gamma11)/2, (1 + i Gamma11)/2
L110 = Lab(lambda a, b: C110.S[a][b], 11); G110 = comm_labels(L110, tries=8); I110 = Ideal(L110, G110)
rk_pp = (rank_frac(mv_mat(I110, PPm)), rank_frac(mv_mat(I110, PPp)))
okG &= eq(GI, blade(1, -1)) and eq(PPm, scal(add(ONE, blade(1)), Fr(1, 2))) and eq(PPp, scal(add(ONE, blade(1), -1), Fr(1, 2)))
okG &= eq(C110.mul(PPm, PPm), PPm) and eq(C110.mul(PPm, PPp), {}) and I110.m == 64 and rk_pp == (32, 32)
chk('bit', okG, 'fr.ALG: Gamma11 = e1..e10 (label 2046) squares to -1, commutes with e0 and with the %d labels of even weight in the ten bits, anticommutes with each e_p; Gamma11 i = -e0, so (1 - i Gamma11)/2 = (1 + e0)/2 and (1 + i Gamma11)/2 = (1 - e0)/2 are orthogonal idempotents of real rank %d and %d on the 64-dimensional irreducible module (complex 16 each)' % (len(com_G), rk_pp[0], rk_pp[1]))
DS = np.array([(-1) ** ((pc(a) * (pc(a) + 1) // 2 + (a & 1)) % 2) for a in range(2048)], dtype=np.int64)   # her dagger on the labels
AR = np.arange(2048)
okD = np.array_equal(S110 * DS[AR[:, None] ^ AR[None, :]], DS[:, None] * DS[None, :] * S110.T) and all(DS[1 << p] == -1 for p in range(1, 11)) and DS[1] == 1 and DS[TOP] == -1
chk('bit', okD, 'fr.ALG: her dagger (complex conjugation with reversal) is on Cl(1,10) the anti-automorphism e_a -> (-1)^(|a|(|a|+1)/2 + a0) e_a, as on Cl(1,6) (fc.CPX): on all 4194304 pairs; e_p -> -e_p, e0 -> e0, i -> -i')
def dag(x): return {a: int(DS[a]) * c for a, c in x.items()}
note('(%.1f s)' % (time.time() - t))
t = time.time()
I4n, I8n, I8i = np.eye(4), np.eye(8), np.eye(8, dtype=np.int64)
def Le(a): return np.kron(I4n, LO[a]).astype(complex)
def Re(a): return np.kron(I4n, RO[a]).astype(complex)
def Le_(m): return np.kron(LH[m], I8n).astype(complex)
def Re_(m): return np.kron(RH[m], I8n).astype(complex)
ID32 = np.eye(32, dtype=complex)
GM10 = [1j * Le(j) @ Le(7) @ Re_(1) for j in range(1, 7)] + [Le(7) @ Le_(m) @ Re_(1) for m in range(1, 4)] + [Re_(2)]   # A4's Gamma_1..Gamma_10
CHIR = Re_(3) if FAULT == 'VOLSIGN' else -Re_(3)                           # A5's chirality element (+R_eps3 under VOLSIGN)
G11 = prodm(GM10)
okA = all(np.array_equal(LO[a] @ LO[a], -I8i) for a in range(1, 8)) and np.array_equal(LH[1] @ LH[2], LH[3])
okA &= np.array_equal(2 * RO[7], -LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5]) and np.array_equal(prodm([LO[a] for a in range(1, 7)]), LO[7])
okA &= all(np.allclose(GM10[p] @ GM10[q] + GM10[q] @ GM10[p], -2 * (p == q) * ID32) for p in range(10) for q in range(10))
chk('std', okA and np.allclose(G11, CHIR) and not np.allclose(G11, -Re_(2)), 'fr.ALG: numpy, furey_papers_check.py rebuilt (no label): A1 the units square to -1, A2 2 R_e7 = -L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5, A3 L_e7 = L_e1..L_e6, A4 the ten Gamma\'s anticommute with square -1 (Cl(0,10) on C^32), A5 Gamma1..Gamma10 = %sR_eps3 (not -R_eps2 = -Gamma10)' % ('+' if FAULT == 'VOLSIGN' else '-'))
E0N = 1j * Re_(3)                                                          # e0 -> i R_eps3 = -i Gamma11
GC110 = [E0N] + GM10
W110 = fwords(GC110, np.complex128)
Wg = W110[0::2].reshape(1024, 1024); GR = Wg.conj() @ Wg.T
okW = frel_ok(GC110, E110) and np.allclose(prodm(GC110), 1j * ID32) and np.allclose(GR, 32 * np.eye(1024)) and np.allclose(E0N, -1j * G11)
chk('std', okW, 'fr.ALG: with e0 -> i R_eps3 = -i Gamma11 the eleven matrices obey Cl(1,10) with volume element i 1; the 1024 words of the Gamma\'s are trace-orthogonal (Gram 32 x identity: complex rank 1024), so with i the 2048 words span M32(C), real dimension 2048: the algebra of the roadmap\'s left and right multiplications is C (x) Cl(0,10)')
okT = True
for g in range(11):
    okT &= np.allclose(np.einsum('ij,ajk->aik', GC110[g], W110), S110[1 << g].astype(float)[:, None, None] * W110[AR ^ (1 << g)])
okT &= np.allclose(W110[GAM], -Re_(3)) and np.allclose(W110[TOP], 1j * ID32) and np.allclose(np.conj(np.transpose(W110, (0, 2, 1))), DS[:, None, None] * W110)
chk('bit==std', okT, 'fr.ALG: the matrix table on the 22528 products of a generator with a word equals the label table (which fixes the whole table, the words being ordered products of the generators); the image of the label 2046 is Gamma1..Gamma10 = -R_eps3 (A5), of 2047 i 1, and the matrix adjoint of each of the 2048 images is the image of the label dagger')
def rho(x):
    out = np.zeros((32, 32), dtype=np.complex128)
    for a, c in x.items(): out += float(c) * W110[a]
    return out
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.WITT  the five pairs as Witt pairs
head('fr.WITT  her five ladder pairs with the central i: the CAR; GEN-015\'s Witt pairs of Cl(5,5) mapped onto them; her vacuum and its minimal ideal')
t = time.time()
ROADMAP = [(8, 7), (10, 9), (5, 4), (3, 1), (6, 2)]                        # bits 0, 1 (weak), 2, 3, 4 (colour): R1's pairs (j, k)
PAIRS = {'WRONGPAIR': [(8, 7), (10, 9), (5, 4), (3, 4), (6, 2)], 'BITPERM': [(5, 4), (3, 1), (8, 7), (10, 9), (6, 2)]}.get(FAULT, ROADMAP)
hf = Fr(1, 2)
def gen(p): return blade(1 << p)
def ladder(pairs, with_i=True):
    """alpha_b = (-e_j + i e_k)/2 (R1's a_c) and its adjoint by the label dagger, (e_j + i e_k)/2 (R1's a_c^dagger); with_i = False drops i"""
    iu = I_ if with_i else ONE
    A = [lin((-hf, gen(j)), (hf, C110.mul(iu, gen(k)))) for j, k in pairs]
    return A, [dag(x) for x in A]
def car_fails(A, Ad):
    """the number of failing relations among {a_b, a_c^d} = delta, {a_b, a_c} = 0, {a_b^d, a_c^d} = 0 (55 for five modes)"""
    n = len(A); bad = 0
    for a in range(n):
        for b in range(n):
            bad += not eq(C110.anti(A[a], Ad[b]), ONE if a == b else {})
            if a <= b: bad += (not eq(C110.anti(A[a], A[b]), {})) + (not eq(C110.anti(Ad[a], Ad[b]), {}))
    return bad
AL, AD = ladder(PAIRS, FAULT != 'NOI')
nfail = car_fails(AL, AD)
okA = nfail == 0 and all(eq(AD[b], lin((hf, gen(j)), (hf, C110.mul(I_, gen(k))))) for b, (j, k) in enumerate(PAIRS))
chk('bit', okA, 'fr.WITT: on the labels of Cl(1,10) (bit p = e_p, i = the label 2047) alpha_b = (-e_j + i e_k)/2 for (j, k) = %s (R1\'s pairs; bits 0, 1 weak, 2, 3, 4 colour), the adjoint by the label dagger (e_j + i e_k)/2 (R1\'s a^dagger): %d of the 55 relations of the CAR fail' % (PAIRS, nfail))
E55 = (1, -1) * 5; K55 = BR(E55)                                           # GEN-015's Cl(5,5): e_b = bit 2b (square +1), f_b = bit 2b+1 (square -1)
def phi55_tab(pairs):
    """e_b -> i e_k, f_b -> e_j on the 1024 labels of Cl(5,5): (label of Cl(1,10), sign)"""
    G = []
    for j, k in pairs:
        (m, s), = C110.mul(I_, gen(k)).items(); G += [(m, int(s)), (1 << j, 1)]
    out = []
    for a in range(1024):
        m, s = 0, 1
        for q in range(10):
            if (a >> q) & 1: s *= G[q][1] * C110.S[m][G[q][0]]; m ^= G[q][0]
        out.append((m, s))
    return out
PH55 = phi55_tab(PAIRS)
def phi55(x):
    out = {}
    for a, c in x.items():
        m, s = PH55[a]; out = add(out, {m: c * s})
    return out
def mul55(x, y):
    """products in Cl(5,5) by the kernel itself"""
    out = {}
    for a, ca in x.items():
        for b, cb in y.items():
            k = a ^ b; v = out.get(k, 0) + K55.s(a, b) * ca * cb
            if v: out[k] = v
            else: out.pop(k, None)
    return out
okH = all(PH55[a][0] ^ PH55[b][0] == PH55[a ^ b][0] and PH55[a][1] * PH55[b][1] * C110.S[PH55[a][0]][PH55[b][0]] == K55.s(a, b) * PH55[a ^ b][1] for a in range(1024) for b in range(1024))
IM55 = sorted(m for m, s in PH55); okI = len(set(IM55)) == 1024 and sorted(IM55 + [m ^ TOP for m in IM55]) == list(range(2048))
A55 = [{1 << (2 * b): hf, 1 << (2 * b + 1): hf} for b in range(5)]; AD55 = [{1 << (2 * b): hf, 1 << (2 * b + 1): -hf} for b in range(5)]
PI55 = {0: Fr(1)}
for b in range(5): PI55 = mul55(PI55, mul55(A55[b], AD55[b]))
okP = all(eq(phi55(A55[b]), AD[b]) and eq(phi55(AD55[b]), AL[b]) for b in range(5))
chk('bit', okH and okI and okP, 'fr.WITT: the map phi of GEN-015\'s Cl(5,5) (pairs interleaved, e_b of square +1, f_b of square -1, as branching_16.py builds it) into Cl(1,10), e_b -> i e_k, f_b -> e_j, keeps the table on all 1048576 pairs; its 1024 image labels and i times them are the 2048 labels (C (x) Cl(5,5) = C (x) Cl(0,10)); it sends GEN-015\'s a_b = (e_b + f_b)/2 to alpha_b^d and a*_b = (e_b - f_b)/2 to alpha_b: her pairs are the Witt pairs with creator and annihilator named the other way')
Om = C110.prod(*AL); VAC = C110.mul(dag(Om), Om)                         # R2's vacuum Omega^dagger Omega, Omega = alpha_0 .. alpha_4
HV = [next(iter(C110.mul(I_, C110.mul(gen(j), gen(k))))) for j, k in ROADMAP]   # the labels of i e_j e_k
vac_want = C110.prod(*[scal(add(ONE, C110.mul(I_, C110.mul(gen(j), gen(k)))), hf) for j, k in ROADMAP])
okV = eq(VAC, vac_want) and len(VAC) == 32 and VAC.get(0) == Fr(1, 32) and eq(C110.mul(VAC, VAC), VAC) and eq(dag(VAC), VAC)
okV &= all(eq(C110.mul(x, VAC), {}) for x in AD) and eq(phi55(PI55), VAC)
chk('bit', okV, 'fr.WITT: her vacuum (R2: Omega^dagger Omega, Omega = a_1 .. a_5) is on the labels prod_b (1 + i e_j e_k)/2 = phi(Pi), Pi GEN-015\'s vacuum: %d terms, scalar part %s, vac^2 = vac = vac^dagger, killed by the five alpha_b^d (R1\'s a^dagger); on the colour modes it is conj(nu) of FUR-017, not nu' % (len(VAC), VAC.get(0)))
HS = {0}
for h in HV: HS |= {x ^ h for x in HS}
REPS = sorted({min(a ^ h for h in HS) for a in range(2048)})
IDL = [C110.mul(blade(a), VAC) for a in range(2048)]; REPV = [C110.mul(blade(r), VAC) for r in REPS]
rk_v = rank_frac(mv_mat(I110, VAC)); rk_l = rank_mv(IDL); okL = rk_l == rank_mv(REPV) == rank_mv(IDL + REPV) == len(REPS) == 64
corner = [C110.mul(x, VAC) for x in [C110.mul(VAC, blade(r)) for r in REPS]]
rk_c = rank_mv(corner); in_c = rank_mv(corner + [VAC, C110.mul(I_, VAC)]) == 2; rk_r = rank_mv([C110.mul(VAC, blade(a)) for a in range(2048)])
chk('bit', (rk_v, rk_c, rk_l, rk_r) == (2, 2, 64, 64) and in_c and okL, 'fr.WITT: the ranks of her vacuum: real rank %d on the 64-dimensional module (complex 1); the corner vac A vac is span{vac, i vac} (dimension %d: C, so vac is primitive); the left ideal A vac has real dimension %d = complex 32, spanned by e_r vac over the 64 cosets of the 32 labels of the i e_j e_k: minimal; left multiplication by vac has rank %d on the 2048 labels' % (rk_v, rk_c, rk_l, rk_r))
ALn, ADn = ladder(ROADMAP, with_i=False)
okNI = all(eq(ADn[b], scal(ALn[b], -1)) for b in range(5)) and all(eq(C110.anti(ALn[a], ALn[b]), scal(ONE, -1) if a == b else {}) and eq(C110.anti(ALn[a], ADn[b]), ONE if a == b else {}) for a in range(5) for b in range(5))
okNI &= all(eq(C110.mul(x, x), scal(ONE, -hf)) for x in ALn) and eq(C110.mul(dag(C110.prod(*ALn)), C110.prod(*ALn)), scal(ONE, Fr(1, 32)))
chk('ctl', okNI, 'fr.WITT: the five pairs without the central i (NOI): beta_b = (-e_j + e_k)/2 has beta^d = -beta, {beta_b, beta_c} = -delta, {beta_b, beta_c^d} = +delta, beta^2 = -1/2: Clifford generators again, no CAR, and the product in the vacuum\'s place is the scalar 1/32')
ALw, ADw = ladder([(8, 7), (10, 9), (5, 4), (3, 4), (6, 2)]); nw = car_fails(ALw, ADw)
chk('ctl', nw > 0 and not eq(C110.anti(ALw[2], ADw[3]), {}), 'fr.WITT: a wrong pairing (WRONGPAIR: (8,7), (10,9), (5,4), (3,4), (6,2), e4 twice): %d of the 55 relations fail' % nw)
note('(%.1f s)' % (time.time() - t))
t = time.time()
HER = [(5, 4), (3, 1), (6, 2), (8, 7), (10, 9)]                            # R1's modes 1 .. 5
Gp = {p + 1: GM10[p] for p in range(10)}
alow = {c + 1: 0.5 * (-Gp[j] + 1j * Gp[k]) for c, (j, k) in enumerate(HER)}; adag = {c: 0.5 * (Gp[j] + 1j * Gp[k]) for c, (j, k) in zip(range(1, 6), HER)}
okR1 = all(np.allclose(alow[c].conj().T, adag[c]) for c in alow)
okR1 &= all(np.allclose(alow[c] @ adag[d] + adag[d] @ alow[c], (c == d) * ID32) and np.allclose(alow[c] @ alow[d] + alow[d] @ alow[c], 0) for c in alow for d in alow)
OmN = prodm([alow[c] for c in range(1, 6)]); VN = OmN.conj().T @ OmN
okR2 = np.allclose(VN, VN.conj().T) and np.allclose(VN @ VN, VN) and int(np.linalg.matrix_rank(VN)) == 1 and all(np.allclose(adag[c] @ VN, 0) for c in adag)
chk('std', okR1 and okR2, 'fr.WITT: numpy, R1 and R2 rebuilt (no label): a_c = (-Gamma_j + i Gamma_k)/2 for (j, k) = (5,4), (3,1), (6,2), (8,7), (10,9), a_c^dagger the conjugate transpose: the CAR; Omega^dagger Omega is Hermitian, idempotent, of rank 1 and killed by the five a_c^dagger')
ALB = [alow[HER.index(p) + 1] for p in ROADMAP]                             # R1's a_c in the bit order of the labels
VCOL = C110.prod(*[scal(add(ONE, C110.mul(I_, C110.mul(gen(j), gen(k)))), hf) for j, k in ROADMAP[2:]])   # the colour factor of the vacuum
CNU8 = prodm([(I8n + 1j * (LO[j] @ LO[k])) / 2 for j, k in ROADMAP[2:]])   # FUR-017's conj(nu) on C (x) O under e_j -> L_ej
NU8 = prodm([(I8n - 1j * (LO[j] @ LO[k])) / 2 for j, k in ROADMAP[2:]])    # FUR-016's nu there (fc.CAR's image)
chk('bit==std', all(np.allclose(rho(AL[b]), ALB[b]) and np.allclose(rho(AD[b]), ALB[b].conj().T) for b in range(5)) and np.allclose(rho(VAC), VN) and np.allclose(rho(VCOL), np.kron(I4n, CNU8)) and not np.allclose(rho(VCOL), np.kron(I4n, NU8)),
    'fr.WITT: the images of the label alpha_b, alpha_b^d and of the label vacuum under e0 -> i R_eps3, e_p -> Gamma_p are R1\'s a_c, a_c^dagger (in the bit order) and Omega^dagger Omega; the colour factor of the vacuum goes to 1 (x) prod (1 + i L_ej L_ek)/2, the image of conj(nu) of FUR-017 on C (x) O (Gamma_j Gamma_k = L_ej L_ek), not that of nu')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.FOCK  the 32 states, P_L, the chirality
head('fr.FOCK  the 32 states as the five-bit labels; P_L = (1 + i Gamma11)/2 = (1 - e0)/2 the even labels; the chirality as the parity of the label')
t = time.time()
def state(S, A, v):
    for b in reversed(range(5)):
        if (S >> b) & 1: v = C110.mul(A[b], v)
    return v
ST = [state(S, AL, VAC) for S in range(32)]
def state55(S):
    v = dict(PI55)
    for b in reversed(range(5)):
        if (S >> b) & 1: v = mul55(AD55[b], v)
    return v
okS = all(eq(ST[S], phi55(state55(S))) for S in range(32)) and all(s != {} for s in ST)
BAS = ST + [C110.mul(I_, s) for s in ST]; rkB = rank_mv(BAS); okS &= rkB == 64 and rank_mv(BAS + IDL) == 64
NB = [C110.mul(AL[b], AD[b]) for b in range(5)]                             # the bit number operators alpha_b alpha_b^d
okN = all(eq(NB[b], scal(add(ONE, C110.mul(I_, C110.mul(gen(j), gen(k))), -1), hf)) for b, (j, k) in enumerate(PAIRS))
okN &= all(eq(C110.mul(NB[b], ST[S]), ST[S] if (S >> b) & 1 else {}) for b in range(5) for S in range(32))
chk('bit', okS and okN, 'fr.FOCK: the 32 states s_S = phi(a*_S Pi) (the alpha_b of the bits of S applied to her vacuum) with their i-multiples are %d real-independent elements spanning A vac: the 32 states are the five-bit labels; n_b = alpha_b alpha_b^d = (1 - i e_j e_k)/2 reads bit b of S' % rkB)
VOL = blade(GAM, -1 if FAULT == 'VOLSIGN' else 1)                          # the chirality element taken: the copy's volume element
IV = C110.mul(I_, VOL)
okC = eq(C110.prod(*[C110.mul(gen(j), gen(k)) for j, k in ROADMAP]), blade(GAM)) and eq(phi55(blade(1023)), blade(1))
okC &= all(eq(C110.mul(IV, ST[S]), scal(ST[S], (-1) ** pc(S))) for S in range(32))
chk('bit', okC, 'fr.FOCK: Gamma11 = e1..e10 = prod_b e_j e_k (the order (8,7,10,9,5,4,3,1,6,2) is even), so i Gamma11 = prod_b (1 - 2 n_b) acts on s_S as (-1)^|S|: the chirality element is the volume element of the copy, on the states the parity of the label; phi carries the chirality Gamma = e0 f0 .. e4 f4 of Cl(5,5) (FUR-022) to e0 = -i Gamma11, her chirality operator (Roadmap I: -i Gamma11 = i R_eps3)')
PL = scal(add(ONE, IV), hf)                                                # (1 + i Gamma11)/2 from the chirality taken
PLA = scal(add(ONE, blade(1)), hf) if FAULT == 'ODDPL' else PL             # the projector the main lines take as P_L
rk_pl = rank_frac(mv_mat(I110, PLA))
okP = eq(PLA, scal(add(ONE, blade(1), -1), hf)) and eq(C110.mul(PLA, PLA), PLA) and eq(PLA, phi55(scal(add(ONE, blade(1023), -1), hf)))
okP &= all(eq(C110.mul(PLA, ST[S]), ST[S] if pc(S) % 2 == 0 else {}) for S in range(32)) and eq(C110.mul(PLA, VAC), VAC) and rk_pl == 32
chk('bit', okP, 'fr.FOCK: P_L = (1 + i Gamma11)/2 = (1 - e0)/2 = phi((1 - Gamma)/2), the -1 eigenspace of the chirality operator e0, keeps the 16 states of even label and kills the 16 of odd label: the projector on the even labels, FUR-022\'s 16 on Gamma = -1 (FUR-021\'s half omega = -J with J = i); it contains her vacuum; real rank %d on the module (complex 16)' % rk_pl)
PO = scal(add(ONE, blade(1)), hf)                                          # (1 + e0)/2: the other half
ALh, ADh = ladder(ROADMAP); STh = [state(S, ALh, vac_want) for S in range(32)]   # the construction itself, for the controls
Omh = C110.prod(*ALh); NU5 = C110.mul(Omh, dag(Omh))                       # the vacuum of the alpha_b: prod (1 - i e_j e_k)/2
okO = all(eq(C110.mul(PO, STh[S]), STh[S] if pc(S) % 2 else {}) for S in range(32)) and eq(C110.mul(PO, vac_want), {})
okO &= eq(PO, scal(add(ONE, C110.mul(I_, blade(GAM, -1))), hf))
chk('ctl', okO, 'fr.FOCK: the other half (1 + e0)/2, which is also (1 + i(-Gamma11))/2 (the volume element with the other sign, VOLSIGN), keeps the 16 odd labels and kills her vacuum: taken as P_L it fails (ODDPL)')
okU = eq(NU5, C110.prod(*[scal(add(ONE, C110.mul(I_, C110.mul(gen(j), gen(k))), -1), hf) for j, k in ROADMAP])) and all(eq(C110.mul(x, NU5), {}) for x in ALh)
okU &= all(eq(C110.mul(NU5, STh[S]), STh[S] if S == 31 else {}) for S in range(32)) and eq(C110.mul(scal(add(ONE, blade(1), -1), hf), NU5), {})
chk('ctl', okU, 'fr.FOCK: the vacuum of the alpha_b themselves, Omega Omega^dagger = prod (1 - i e_j e_k)/2 (the convention of FUR-016\'s nu, killed by the alpha_b), is the projector on the top label 31 here, of odd parity: P_L kills it; R2\'s vacuum is the other one')
note('(%.1f s)' % (time.time() - t))
t = time.time()
PLN = 0.5 * (ID32 + 1j * CHIR)                                             # R3: (1 + i Gamma1..Gamma10)/2, with the chirality taken
x0 = VN[:, int(np.argmax(np.abs(VN).sum(0)))]; VEC0 = VN @ x0              # her vacuum vector
STN = []
for S in range(32):
    v = VEC0.copy()
    for b in reversed(range(5)):
        if (S >> b) & 1: v = ALB[b] @ v
    STN.append(v)
okF = np.allclose(PLN @ PLN, PLN) and int(np.linalg.matrix_rank(PLN)) == 16 and np.allclose(PLN @ VEC0, VEC0) and int(np.linalg.matrix_rank(np.array(STN))) == 32
okF &= np.allclose(PLN, np.kron((np.eye(4) - 1j * RH[3]) / 2, I8n)) and all(np.allclose(PLN @ STN[S], STN[S] if pc(S) % 2 == 0 else 0 * STN[S]) for S in range(32))
chk('std', okF, 'fr.FOCK: numpy, R3 and A5 (no label): P_L = (1 + i Gamma1..Gamma10)/2 is a projector of rank 16 containing the vacuum vector; it is (1 - i R_eps3)/2 (x) 1, the right multiplication by the idempotent (1 - i eps3)/2 of C (x) H on the quaternion factor; the 32 vectors of R1\'s a_c applied to the vacuum are independent, and P_L keeps those with an even number of a_c and kills the others')
chk('bit==std', all(np.allclose(rho(ST[S]) @ x0, STN[S]) for S in range(32)) and np.allclose(rho(PLA), PLN) and np.allclose(rho(IV), 1j * CHIR),
    'fr.FOCK: the images of the 32 label states, applied to the vacuum\'s vector, are the numpy states; the image of the label P_L is R3\'s P_L and that of i Gamma11 is i Gamma1..Gamma10')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.BIV  the 45 quadratic operators
head('fr.BIV  the 45 quadratic operators in her ladder operators and the 45 bivectors of the copy of Cl(0,10) (CAND-019, CAND-136)')
t = time.time()
Q45 = [C110.mul(AL[a], AL[b]) for a in range(5) for b in range(a + 1, 5)] + [C110.mul(AD[a], AD[b]) for a in range(5) for b in range(a + 1, 5)]
Q45 += [add(C110.mul(AD[a], AL[b]), scal(ONE, hf) if a == b else {}, -1) for a in range(5) for b in range(5)]
BV45 = [(1 << p) | (1 << q) for p in range(1, 11) for q in range(p + 1, 11)]; BIVS = set(BV45); IBIVS = {m ^ TOP for m in BV45}
okQ = len(Q45) == 45 and all(all(a in BIVS or a in IBIVS for a in x) for x in Q45) and all(C110.commute(1, m) for m in BV45)
QQ = Q45 + [C110.mul(I_, x) for x in Q45]; BB = [blade(m) for m in BV45] + [C110.mul(I_, blade(m)) for m in BV45]
rq, rb, ru = rank_mv(QQ), rank_mv(BB), rank_mv(QQ + BB)
chk('bit', okQ and (rq, rb, ru) == (90, 90, 90), 'fr.BIV: the 45 operators alpha_b alpha_c, alpha_b^d alpha_c^d (b < c), alpha_b^d alpha_c - delta/2 are C-combinations of the 45 bivectors e_p e_q of the copy and span the same complex space (real ranks %d, %d, union %d); every bivector commutes with e0, so the 45 keep P_L and the parity' % (rq, rb, ru))
COS = {}
for r in REPS:
    for h in HS: COS[r ^ h] = r
CMAP = {}
for S, s in enumerate(ST):
    cs = {COS[a] for a in s}; ci = {COS[a] for a in C110.mul(I_, s)}
    if len(cs) == 1 and len(ci) == 1: CMAP[cs.pop()] = S; CMAP[ci.pop()] = S
EV16 = [S for S in range(32) if pc(S) % 2 == 0]; okG = len(CMAP) == 64; parent = {S: S for S in EV16}
def findp(x):
    while parent[x] != x: x = parent[x]
    return x
for x in Q45:
    for S in EV16:
        for T in ({CMAP.get(COS[a]) for a in C110.mul(x, ST[S])} if okG else ()):
            if T is None or pc(T) % 2: okG = False; continue
            ra, rb_ = findp(S), findp(T)
            if ra != rb_: parent[ra] = rb_
ncomp = len({findp(S) for S in EV16})
chk('bit', okG and ncomp == 1, 'fr.BIV: on the 16 even states the five n_b have 16 distinct joint eigenvalues (the bits) and the 45 connect all 16 (one component): the commutant is C, the 16 is irreducible, as CAND-019 found on the Fock matrices')
BV55 = [a for a in range(1024) if pc(a) == 2]; IMG55 = [PH55[a][0] for a in BV55]
nre, nim = sum(1 for m in IMG55 if m in BIVS), sum(1 for m in IMG55 if m in IBIVS)
chk('bit', len(BV55) == 45 and (nre, nim) == (20, 25), 'fr.BIV: phi carries the 45 bivectors of Cl(5,5) (the split so(5,5)) to %d real bivectors of the copy (e_j e_j\', e_k e_k\': so(5) + so(5)) and %d imaginary ones (i e_k e_j\'): the split real form beside the compact span of the e_p e_q, with one complexification; the Killing signature (25,20,0) of CAND-136 as 25 imaginary and 20 real' % (nre, nim))
note('(%.1f s)' % (time.time() - t))
t = time.time()
B45L = [Le(a) @ Le(b) for a in range(1, 8) for b in range(a + 1, 8)] + [Le_(m) @ Le_(n) for m in range(1, 4) for n in range(m + 1, 4)] + [1j * Le_(m) @ Le(a) for m in range(1, 4) for a in range(1, 8)]
DIR = [GM10[p] @ GM10[q] for p in range(10) for q in range(p + 1, 10)]
VL = np.array([(M @ PLN).ravel() for M in B45L]); VD = np.array([(M @ PLN).ravel() for M in DIR])
r4 = [int(np.linalg.matrix_rank(V, tol=1e-9)) for V in (VL, VD, np.vstack([VL, VD]))]
COMMS = np.array([((B45L[a] @ B45L[b] - B45L[b] @ B45L[a]) @ PLN).ravel() for a in range(45) for b in range(a + 1, 45)])
r5 = int(np.linalg.matrix_rank(np.vstack([VL, COMMS]), tol=1e-9))
chk('std', r4 == [45, 45, 45] and r5 == 45, 'fr.BIV: numpy, R4 and R5 rebuilt (no label): the 45 left-multiplication generators (L_a L_b, L_epsm L_epsn, i L_epsm L_a) and the 45 Dirac bivectors Gamma_p Gamma_q act alike on Psi_L (ranks %s) and close under the commutator (rank %d with the 990 brackets)' % (r4, r5))
VQ = np.array([(rho(x) @ PLN).ravel() for x in Q45])
chk('bit==std', all(np.allclose(W110[m], GM10[p - 1] @ GM10[q - 1]) for m, (p, q) in zip(BV45, [(p, q) for p in range(1, 11) for q in range(p + 1, 11)])) and int(np.linalg.matrix_rank(np.vstack([VQ, VL]), tol=1e-9)) == 45,
    'fr.BIV: the image of each label bivector e_p e_q is Gamma_p Gamma_q, and the images of the 45 quadratic operators on P_L span R4\'s space (rank of the union 45)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.HYP  hypercharge and weak sector as the bits
head('fr.HYP  her modes as the five bits (weak 0, 1; colour 2, 3, 4): Y = a/2 - b/3, Q, B-L, T3 and the weak su(2) as ladder expressions, against R11')
t = time.time()
TH3 = Fr(1, 3)
def wsum(ws, base=None): return lin(*([(1, base)] if base else []), *[(w, NB[b]) for b, w in enumerate(ws) if w])
YL = wsum([hf, hf, -TH3, -TH3, -TH3]); QL = wsum([1, 0, -TH3, -TH3, -TH3]); BL = wsum([0, 0, -2 * TH3, -2 * TH3, -2 * TH3], ONE); T3 = wsum([hf, -hf, 0, 0, 0])
def biv(j, k): return C110.mul(gen(j), gen(k))
def ix(x, c): return scal(C110.mul(I_, x), c)                             # c i x
KCOL = lin(*[(1, biv(j, k)) for j, k in ROADMAP[2:]]); KW = lin(*[(1, biv(j, k)) for j, k in ROADMAP[:2]])
okY = eq(YL, add(ix(KCOL, Fr(1, 6)), ix(KW, Fr(-1, 4)))) and eq(QL, add(ix(KCOL, Fr(1, 6)), ix(biv(*ROADMAP[0]), -hf))) and eq(BL, ix(KCOL, TH3))
okY &= eq(T3, ix(add(biv(*ROADMAP[1]), biv(*ROADMAP[0]), -1), Fr(1, 4))) and YL.get(0, 0) == 0
okY &= eq(YL, lin(*[(TH3, C110.mul(AD[b], AL[b])) for b in (2, 3, 4)], *[(-hf, C110.mul(AD[b], AL[b])) for b in (0, 1)]))   # (1/3) sum_colour - (1/2) sum_weak alpha^d alpha
a_of = lambda S: pc(S & 3); b_of = lambda S: pc(S >> 2)
VALS = {S: (Fr(a_of(S), 2) - b_of(S) * TH3, (S & 1) - b_of(S) * TH3, 1 - 2 * b_of(S) * TH3, Fr((S & 1) - ((S >> 1) & 1), 2)) for S in range(32)}
okE = all(all(eq(C110.mul(X, ST[S]), scal(ST[S], v)) for X, v in zip((YL, QL, BL, T3), VALS[S])) for S in range(32))
chk('bit', okY and okE, 'fr.HYP: on the labels Y = (n0 + n1)/2 - (n2 + n3 + n4)/3 = (1/3) sum_colour alpha^d alpha - (1/2) sum_weak alpha^d alpha (the form of Furey 2018, eq. 43) = (i/6)(e5e4 + e3e1 + e6e2) - (i/4)(e8e7 + e10e9) (no scalar term), Q = n0 - (n2 + n3 + n4)/3, B-L = 1 - (2/3)(n2 + n3 + n4) = (i/3)(e5e4 + e3e1 + e6e2), T3 = (n0 - n1)/2; on s_S they read a/2 - b/3, (bit 0) - b/3, 1 - 2b/3, (bit 0 - bit 1)/2 exactly (a, b the weak and colour bits set): her modes 4, 5 are the weak bits 0, 1, her modes 1, 2, 3 the colour bits 2, 3, 4')
PIECES = {'Q': (1, 1), 'u-bar': (0, 2), 'd-bar': (2, 2), 'L': (1, 3), 'e-bar': (2, 0), 'nu-bar': (0, 0)}
PCS = {nm: [S for S in EV16 if (a_of(S), b_of(S)) == ab] for nm, ab in PIECES.items()}
okPc = [len(PCS[nm]) for nm in PIECES] == [6, 3, 3, 2, 1, 1] and [VALS[PCS[nm][0]][0] for nm in PIECES] == [Fr(1, 6), Fr(-2, 3), TH3, -hf, 1, 0]
SPY = Counter(VALS[S][0] for S in EV16); SPQ = Counter(VALS[S][1] for S in EV16); SPB = Counter(VALS[S][2] for S in EV16)
EXPY = {Fr(-2, 3): 3, Fr(-1, 2): 2, Fr(0): 1, Fr(1, 6): 6, Fr(1, 3): 3, Fr(1): 1}; EXPQ = {Fr(-1): 1, Fr(-2, 3): 3, Fr(-1, 3): 3, Fr(0): 2, Fr(1, 3): 3, Fr(2, 3): 3, Fr(1): 1}
EXPB = {Fr(-1): 2, Fr(-1, 3): 6, Fr(1, 3): 6, Fr(1): 2}
chk('bit', okPc and dict(SPY) == EXPY and dict(SPQ) == EXPQ and dict(SPB) == EXPB, 'fr.HYP: on the 16 even labels (a, b) = (1,1), (0,2), (2,2), (1,3), (2,0), (0,0) give 6, 3, 3, 2, 1, 1 states with Y = 1/6, -2/3, 1/3, -1/2, 1, 0 (jordan_sm.py\'s pieces Q, u-bar, d-bar, L, e-bar, nu-bar); the spectra of Y, Q and B-L there are those R11 states on Psi_L')
TP = C110.mul(AL[0], AD[1]); TM = C110.mul(AL[1], AD[0])                   # phi(a*_0 a_1), phi(a*_1 a_0): jordan_sm.py's weak su(2)
COL9 = [C110.mul(AL[b], AD[c]) for b in (2, 3, 4) for c in (2, 3, 4)]
okW = eq(TP, phi55(mul55(AD55[0], A55[1]))) and eq(TM, phi55(mul55(AD55[1], A55[0])))
okW &= eq(C110.comm(TP, TM), scal(T3, 2)) and eq(C110.comm(T3, TP), TP) and eq(C110.comm(T3, TM), scal(TM, -1))
okW &= all(eq(C110.comm(X, T_), {}) for X in [YL, BL] + COL9 for T_ in (TP, TM, T3))
okW &= all(eq(C110.mul(TP, ST[S]), ST[S ^ 3] if (S & 3) == 2 else {}) for S in range(32))
chk('bit', okW, 'fr.HYP: the weak su(2) as quadratic ladder expressions, T+ = alpha_0 alpha_1^d = phi(a*_0 a_1), T- = alpha_1 alpha_0^d, T3: [T+, T-] = 2 T3, [T3, T+-] = +-T+-, exactly; they commute with Y, with B-L and with the nine alpha_b alpha_c^d of the colour bits; T+ takes s_S to s_(S xor 3) when bit 1 is set and bit 0 clear, and kills the others')
note('(%.1f s)' % (time.time() - t))
t = time.time()
L13 = Le(1) @ Le(3) + Le(2) @ Le(6) + Le(4) @ Le(5)
SSTAR, SN = 0.5 * (ID32 - 1j * Le(7)), 0.5 * (ID32 + 1j * Le(7))
YN, QN, BLN = -1j * (L13 / 6 - 0.5 * Le_(3) @ SSTAR), -1j * (L13 / 6 - 0.5 * Le_(3)), -1j * (L13 / 3)   # R11's Y, Q, B-L
def specN(Mx, P):
    u_, s_, vt_ = np.linalg.svd(P); B_ = u_[:, :16]; R_ = B_.conj().T @ Mx @ B_
    if not np.allclose(R_, R_.conj().T): return None
    ev = np.linalg.eigvalsh(R_); fr_ = [Fr(int(round(x * 6)), 6) for x in ev]
    return dict(Counter(fr_)) if np.allclose(ev, [float(f) for f in fr_]) else None
TN = [0.5j * Le_(m) @ SN for m in (1, 2, 3)]
okT = all(np.allclose(T_ @ PLN, PLN @ T_) for T_ in TN) and all(np.allclose(TN[a] @ TN[b] - TN[b] @ TN[a], 1j * TN[c]) for a, b, c in ((0, 1, 2), (1, 2, 0), (2, 0, 1)))
okT &= all(np.allclose((T_ @ YN - YN @ T_) @ PLN, 0) for T_ in TN) and np.allclose((TN[2] - (QN - YN)) @ PLN, 0)
chk('std', specN(YN, PLN) == EXPY and specN(QN, PLN) == EXPQ and specN(BLN, PLN) == EXPB and okT, 'fr.HYP: numpy, R11 rebuilt (no label): on Psi_L Y = -i((L1L3 + L2L6 + L4L5)/6 - L_eps3 s*/2), Q and B-L have the spectra of R11; T_m = (i/2) L_epsm s, s = (1 + i L_e7)/2, close into su(2) ([T1, T2] = i T3), commute with P_L and with Y on Psi_L, and T3 = Q - Y there')
okYB = np.allclose(rho(YL) @ PLN, YN @ PLN) and np.allclose(rho(QL), QN) and np.allclose(rho(BL), BLN) and np.allclose(rho(T3) @ PLN, TN[2] @ PLN)
SGN = next((s for s in (1, -1) if np.allclose(rho(TP) @ PLN, s * (TN[0] + 1j * TN[1]) @ PLN) and np.allclose(rho(TM) @ PLN, s * (TN[0] - 1j * TN[1]) @ PLN)), None)
offY = not np.allclose(rho(YL), YN)
chk('bit==std', okYB and SGN is not None and offY, 'fr.HYP: the image of the label Y is R11\'s Y on P_L (and not off it, where her Y has another form), those of Q and B-L are R11\'s Q and B-L on all of C^32; the label T3 is T3 on P_L and the label T+- are %s(T1 +- i T2) on P_L: the identification of her modes with the bits' % ({1: '+', -1: '-'}.get(SGN, '?')))
ALq, ADq = ladder([(5, 4), (3, 1), (8, 7), (10, 9), (6, 2)])
YQ = lin(*[(w, C110.mul(ALq[b], ADq[b])) for b, w in enumerate([hf, hf, -TH3, -TH3, -TH3])])
PLT = 0.5 * (ID32 + 1j * G11)                                              # R3's P_L with A5's own chirality (for the controls)
chk('ctl', specN(rho(YQ), PLT) == EXPY and not np.allclose(rho(YQ) @ PLT, YN @ PLT), 'fr.HYP: the bits permuted, weak and colour exchanged (BITPERM: (5,4), (3,1) as bits 0, 1 and (8,7), (10,9), (6,2) as 2, 3, 4): a/2 - b/3 read off them has R11\'s spectrum on P_L but is not R11\'s Y: the identification is more than the spectrum')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fr.LINE  the four Fano-line blades
head('fr.LINE  the four Fano-line blades outside the image of C (x) Cl(0,6) in the Cl(0,8) of FUR-019: the pairs of axes, her eight states, what they generate')
t = time.time()
# pass 10a's construction, copied from furey_cl6.py: the cell Cl(1,6) with i the label 127, her dagger and the conjugation e0 -> -e0, the
# ladder operators of the pairs (5,4), (3,1), (6,2), nu, the eight states, the mode projectors and the eight idempotents E_S
E16 = sig(1, 6); C16 = Cell(E16); I16 = blade(127)
DS16 = [(-1) ** ((pc(a) * (pc(a) + 1) // 2 + (a & 1)) % 2) for a in range(128)]
def dag16(x): return {a: DS16[a] * c for a, c in x.items()}
def conj16(x): return {a: (-1) ** (a & 1) * c for a, c in x.items()}
FUREY = [(5, 4), (3, 1), (6, 2)]
AL6 = [lin((-hf, blade(1 << j)), (hf, C16.mul(I16, blade(1 << k)))) for j, k in FUREY]; AD6 = [dag16(x) for x in AL6]
NU = C16.prod(AL6[0], AL6[1], AL6[2], AD6[2], AD6[1], AD6[0])
SUBS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]
ST6 = [C16.prod(*([AD6[a] for a in S] + [NU])) for S in SUBS]
PA6 = [C16.mul(AL6[a], AD6[a]) for a in range(3)]
ES = [C16.prod(*[(add(ONE, PA6[a], -1) if a in S else PA6[a]) for a in range(3)]) for S in SUBS]
# the model's Cl(0,8), copied from furey_cl6.py (from furey_bit_route.py: units, gm, the Fano lines from omul, mblade, the group of the line
# blades and its characters matched with the axes; data only): bit m - 1 = the model's unit m (i, j, k, l, li, lj, lk; k = e7 is bit 2), bit 7 = g8
UNITS7 = [OM.E[m] for m in range(1, 8)]; NAMES8 = ['i', 'j', 'k', 'l', 'li', 'lj', 'lk', 'g8']
GM = [np.rint(OM.blk(OM.Z, OM.Lmat(u), OM.Lmat(u), OM.Z)).astype(np.int64) for u in UNITS7] + [np.rint(OM.blk(OM.Z, OM.I8, -OM.I8, OM.Z)).astype(np.int64)]
LINES = []
for a in range(7):
    for b in range(a + 1, 7):
        pr = OM.omul(UNITS7[a], UNITS7[b]); c = int(np.argmax(abs(pr))) - 1
        if c > b: LINES.append((a, b, c))
LMASK = [(1 << a) | (1 << b) | (1 << c) | (1 << 7) for (a, b, c) in LINES]
def mblade(m):
    M = np.eye(16, dtype=np.int64)
    for a in range(8):
        if (m >> a) & 1: M = M @ GM[a]
    return M
C08 = Cell((-1,) * 8)
GRP = {(0, 1)}; fr_ = [(0, 1)]                                              # the group of the line blades (furey_bit_route.py B)
while fr_:
    nx = []
    for m, s in fr_:
        for l in LMASK:
            mm_, ss_ = m ^ l, s * C08.S[m][l]
            if (mm_, ss_) not in GRP: GRP.add((mm_, ss_)); nx.append((mm_, ss_))
    fr_ = nx
SL = sorted({m for m, s in GRP}); BASL = []; span_ = {0}
for l in LMASK:
    if l not in span_: BASL.append(l); span_ |= {x ^ l for x in span_}
def character(signs):
    chi = {}
    for T_ in itertools.product((0, 1), repeat=4):
        m, sg, val = 0, 1, 1
        for i_, t_ in enumerate(T_):
            if t_: sg *= C08.S[m][BASL[i_]]; m ^= BASL[i_]; val *= signs[i_]
        chi[m] = sg * val
    return chi
CHARS = [character(sg) for sg in itertools.product((1, -1), repeat=4)]
MBD = {m: np.diag(mblade(m)).tolist() for m in SL}
match = {k: [i for i, ch in enumerate(CHARS) if all(ch[l] == MBD[l][k] for l in LMASK)] for k in range(16)}
okMt = len(GRP) == 32 and len(SL) == 16 and all(len(v) == 1 for v in match.values()) and len({v[0] for v in match.values()}) == 16
CHI = {k: CHARS[match[k][0]] for k in range(16)} if okMt else {k: CHARS[0] for k in range(16)}
PAX = {k: {m: Fr(CHI[k][m], 16) for m in SL} for k in range(16)}           # the axis idempotents p_k = (1/16) sum_w chi_k(w) w
okMt &= all(eq(C08.mul(PAX[k], PAX[l]), PAX[k] if k == l else {}) for k in range(16) for l in range(16)) and eq(lin(*[(1, PAX[k]) for k in range(16)]), ONE)
okMt &= kernel_ok(C08, BR((-1,) * 8)) and kernel_ok(C16, BR(E16))
def phi_tab(eps0):
    """the embedding of Cl(1,6) in Cl(0,8) on the 128 labels: e0 -> eps0 g1 .. g8 (label 255), e_j -> sign x g_(model unit - 1)"""
    G = [(255, eps0)] + [(1 << (F2M[j][0] - 1), F2M[j][1]) for j in range(1, 7)]; out = []
    for a in range(128):
        m, s = 0, 1
        for j in range(7):
            if (a >> j) & 1: s *= G[j][1] * C08.S[m][G[j][0]]; m ^= G[j][0]
        out.append((m, s))
    return out
PHI = phi_tab(1)
def phi(x):
    out = {}
    for a, c in x.items():
        m, s = PHI[a]; out = add(out, {m: c * s})
    return out
okPhi = all(PHI[a][0] ^ PHI[b][0] == PHI[a ^ b][0] and PHI[a][1] * PHI[b][1] * C08.S[PHI[a][0]][PHI[b][0]] == C16.S[a][b] * PHI[a ^ b][1] for a in range(128) for b in range(128))
IMG = sorted(m for m, s in PHI); JM = PHI[127]; JJ = blade(JM[0], JM[1])
def axis_split(x):
    if any(m not in CHI[0] for m in x): return None
    return [sum(c * CHI[k][m] for m, c in x.items()) for k in range(16)]
PES = [phi(e) for e in ES]; XS = [axis_split(x) for x in PES]
PAIRS_AX = [tuple(k for k in range(16) if xs[k] == 1) if xs is not None and all(v in (0, 1) for v in xs) else None for xs in XS]
okB = okMt and okPhi and IMG == [m for m in range(256) if ((m >> 2) & 1) == ((m >> 7) & 1)] and JM[0] == 132
okB &= PAIRS_AX == [(8, 11), (4, 7), (5, 6), (1, 2), (9, 10), (13, 14), (12, 15), (0, 3)] and all(eq(C08.mul(C08.mul(JJ, PAX[p[0]]), scal(JJ, -1)), PAX[p[1]]) for p in PAIRS_AX)
chk('bit', okB, 'fr.LINE: pass 10a\'s frame rebuilt (fc.AX; the tables of Cl(1,6) and Cl(0,8) are BR.s on every pair): the 16 axis idempotents from the characters of the 32-element group of the line blades; Cl(1,6) in Cl(0,8) by e_j -> +-g_u, e0 -> g1 .. g8, i -> %sg_k g8; her eight idempotents E_S go to the pairs of axes %s, each pair exchanged by the image of i' % ('' if JM[1] == 1 else '-', PAIRS_AX))
THROUGH_K = sorted(l for l in LMASK if (l >> 2) & 1); OUTER0 = [l for l in LMASK if not (l >> 2) & 1]
OUTER = (THROUGH_K + THROUGH_K[:1]) if FAULT == 'INLINE' else OUTER0       # the four blades of the main lines (lines through e7 under INLINE)
def lname(l): return '{' + ', '.join(NAMES8[b] for b in range(7) if (l >> b) & 1) + '}'
PNU = phi(NU); PMA = [phi(add(PA6[a], C16.mul(AD6[a], AL6[a]), -1)) for a in range(3)]
okL1 = all(l not in IMG and C08.sq(l) == 1 for l in OUTER) and all(eq(C08.mul(blade(l), JJ), scal(C08.mul(JJ, blade(l)), -1)) for l in OUTER)
okL1 &= all(eq(C08.comm(blade(l), x), {}) for l in OUTER for x in PMA + [PNU] + PES)
chk('bit', okL1, 'fr.LINE: the line blades of the four lines not through e7, %s (each with g8), lie outside the image of C (x) Cl(0,6), square to +1, anticommute with the image of i (they share one generator with it, g8), and commute with the three mode operators (the line blades through e7), with nu and with the eight E_S' % ', '.join(lname(l) for l in OUTER))
okS = True; PLUS = []
for l in OUTER:
    okS &= all(CHI[m][l] == -CHI[mp][l] for m, mp in PAIRS_AX)
    okS &= all(eq(C08.mul(pe, scal(add(ONE, blade(l), sg), hf)), PAX[m if CHI[m][l] == sg else mp]) for pe, (m, mp) in zip(PES, PAIRS_AX) for sg in (1, -1))
    PLUS.append([m if CHI[m][l] == 1 else mp for m, mp in PAIRS_AX])
chk('bit', okS, 'fr.LINE: each of the four splits every one of the eight pairs: +1 on one axis of the pair and -1 on the other, so E_S (1 +- L)/2 are the sixteen axis idempotents, exactly; the axes where L = +1 (pairs in the order of the states): %s' % PLUS)
def adL(l, x): return C08.mul(C08.mul(blade(l), x), blade(l))           # L x L^-1 (L^2 = 1)
PST = [phi(s) for s in ST6]; PATS = []; okA = True
for l in OUTER:
    okA &= eq(adL(l, JJ), scal(JJ, -1)) and eq(adL(l, PNU), PNU)
    sg = []
    for a in range(3):
        x = phi(AD6[a]); y = adL(l, x); sg.append(1 if eq(y, x) else (-1 if eq(y, scal(x, -1)) else 0))
    okA &= 0 not in sg and sg[0] * sg[1] * sg[2] == 1
    okA &= all(eq(adL(l, ps), scal(ps, sg[0] ** (0 in S) * sg[1] ** (1 in S) * sg[2] ** (2 in S))) for ps, S in zip(PST, SUBS))
    PATS.append(tuple(sg))
okA &= sorted(PATS) == sorted(p for p in itertools.product((1, -1), repeat=3) if p[0] * p[1] * p[2] == 1)
chk('bit', okA, 'fr.LINE: conjugation by each sends i to -i (antilinear) and fixes nu; it takes alpha_a^d to s_a alpha_a^d (s_a = -1 when the unit e_j of mode a lies on the line) and each of her eight states to plus or minus itself, with (s_1, s_2, s_3) = %s for the four: the four sign patterns of product +1, one each; the line %s fixes all eight states' % (', '.join('(%s)' % ', '.join('+' if s > 0 else '-' for s in p) for p in PATS), lname(OUTER[PATS.index((1, 1, 1))]) if (1, 1, 1) in PATS else 'none'))
G8 = blade(128); IDL6 = [C16.mul(blade(a), NU) for a in range(128)]
SECOND = [C08.mul(phi(blade(a)), C08.mul(G8, PNU)) for a in range(128)]; FIRST = [phi(y) for y in IDL6]
rS = rank_mv(SECOND); okM = rS == 16 and rank_mv(FIRST + SECOND) == 32
for l in OUTER:
    LI = [C08.mul(blade(l), y) for y in FIRST]; okM &= rank_mv(LI) == 16 and rank_mv(LI + SECOND) == 16
chk('bit', okM, 'fr.LINE: left multiplication by each carries the image of nu\'s ideal (16) onto the second ideal (C (x) Cl(0,6)) g8 nu = (C (x) Cl(0,6)) conj(nu) g8 of FUR-019 (rank %d, the union of the two images rank 16): the four exchange her two ideals inside Cl(0,8) nu (32)' % rS)
okG = True; TYS = []
for l in OUTER:
    okG &= sorted(set(IMG) | {m ^ l for m in IMG}) == list(range(256))
    FIX = [m for m in IMG if C08.commute(m, l)]; bas = []; spn = {0}
    for m in FIX:
        if m not in spn: bas.append(m); spn |= {x ^ m for x in spn}
    ty = table_type(C08.T.astype(np.int64)[np.ix_(FIX, FIX)], [FIX.index(g) for g in bas]) if len(FIX) == 64 and spn == set(FIX) else None
    TYS.append(ty); okG &= ty == ('R', 8, 1)
chk('bit', okG, 'fr.LINE: with the image each generates the whole Cl(0,8): the 128 image labels and their products with L are all 256 labels; the 64 image labels commuting with L span a real form of C (x) Cl(0,6) = M8(C) of type %s, the split form' % tstr(TYS[0]))
lk = THROUGH_K[0]
okIn = lk in IMG and eq(adL(lk, JJ), JJ) and all(CHI[m][lk] == CHI[mp][lk] for m, mp in PAIRS_AX) and sorted(set(IMG) | {m ^ lk for m in IMG}) == IMG
chk('ctl', okIn, 'fr.LINE: a line blade through e7 in place of the four (INLINE), %s: it lies in the image, commutes with i, takes one value on both axes of every pair (no splitting) and generates nothing beyond the image' % lname(lk))
note('(%.1f s)' % (time.time() - t))
t = time.time()
PHM = [mblade(255)] + [F2M[j][1] * GM[F2M[j][0] - 1] for j in range(1, 7)]   # the images of e0 .. e6 on V, as 16 x 16 matrices (furey_cl6.py)
Jm = prodm(PHM); I16m = np.eye(16, dtype=np.int64)
Mm = [-Jm @ PHM[j] @ PHM[k] for j, k in FUREY]; PRJ = []; PRS = []
for S in SUBS:
    E_ = prodm([(I16m - Mm[a]) if a in S else (I16m + Mm[a]) for a in range(3)]) // 8
    PRJ.append(E_); PRS.append(tuple(int(k) for k in np.flatnonzero(np.diag(E_))))
okV = np.array_equal(Jm, JM[1] * (GM[2] @ GM[7])) and PRS == PAIRS_AX
for l in OUTER:
    Lm = mblade(l); d = np.diag(Lm)
    okV &= np.array_equal(Lm, np.diag(d)) and np.array_equal(Lm @ Jm, -Jm @ Lm) and all(np.array_equal(Lm @ P_, P_ @ Lm) for P_ in PRJ) and all(d[m] == -d[mp] for m, mp in PRS)
chk('std', okV, 'fr.LINE: numpy, the model\'s 16 x 16 matrices on V = O + O\' (no label): the image of i is %sg_k g8, the eight joint projectors of the mode operators are diagonal on the pairs %s; each of the four outer line blades is diagonal, anticommutes with the image of i, commutes with the eight projectors and has opposite entries on the two axes of every pair' % ('' if JM[1] == 1 else '-', PRS))
chk('bit==std', all(int(np.diag(mblade(l))[k]) == CHI[k][l] for l in OUTER for k in range(16)), 'fr.LINE: the signs of the four on the sixteen axes agree on the labels (the characters of the line-blade group) and on the matrices')
note('not computed: the generations of Furey and Hughes (arXiv:2409.17948, eqs. 32-39, the three triality actions on H (x) O; read by L2, docs/round13/SOURCES.md (g2)), of which only the basis of C (x) H (eq. 31) is computed (fr.HC); her symmetry breaking (R7-R10); any statement that the charges or the names of the states are nature\'s')
note('(%.1f s)' % (time.time() - t))
finish()
