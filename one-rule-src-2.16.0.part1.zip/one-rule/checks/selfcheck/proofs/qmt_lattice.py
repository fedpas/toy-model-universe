#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""qmt_lattice.py: lattice fermions on the bit rule: the doublers of the naive Dirac operator, and exact bosonization on closed
square surfaces.      python3 qmt_lattice.py [--fault NAME]

N. Doublers (qmt·N1 .. N5).  H(k) = sum_mu sin(k_mu) gamma_mu with gamma_mu the left multiplication matrices of Cl(d,0) (integer
   signed permutation matrices, bitcliff.regular_matrix), d = 1..4: gamma_mu gamma_nu + gamma_nu gamma_mu = 2 delta (exact), so
   H(k)^2 = (sum sin^2 k_mu) 1 and the zeros are exactly the 2^d corners k in {0, pi}^d; the chirality of a zero is prod cos(k_mu)
   (the sign of the Jacobian, the orientation of the effective frame cos(k_mu) gamma_mu): 2^(d-1) of each sign.  The Wilson term
   r sum (1 - cos k_mu) (r = 1) leaves one zero, at k = 0, and breaks the chiral symmetry.
   [std] numpy eigenvalues on k grids (64 per axis for d <= 2, 16 for d = 3, 8 for d = 4); numerical Jacobians; ten seeded random
   local chiral operators f_1 sigma_1 + f_2 sigma_2 in d = 2 (f trigonometric polynomials of range <= 2, integer coefficients):
   zeros by Newton from a 120 x 120 grid, as many of each chirality.  Recalled, not computed: the theorem for every local,
   translation-invariant, hermitian chiral operator (Nielsen and Ninomiya).
B. Exact bosonization (qmt·B1 .. B6).  The surface of the 3-cube (6 faces, 12 edges, 8 vertices) and a 3 x 3 square torus (9, 18, 9):
   a complex fermion per face (Majoranas g_f, g'_f of Cl(F,F), bit rule), P_f = g_f g'_f, S_e = g_L(e) g'_R(e); a qubit per edge (real
   Pauli strings X^x Z^z as F2 vectors, never the bit rule), W_f = prod_{e in f} Z_e, U_e = X_e prod_{R(e)} Z with R(e) solved over F2
   among the edges sharing a face with e.  The commutation matrices of the F + E generators agree; the relations among the fermion
   generators (an F2 kernel, products = +-1 with exact signs) map to commuting Pauli strings, the gauge constraints, whose imposed
   values reproduce every fermion sign; the constrained space has dimension 2^(E - rank) = 2^(F - 1), the even sector; the total
   fermion parity maps to the total flux, the identity.  Whether CKR's single Z per edge fits is tested.  Recalled: the construction
   on the infinite lattice and its gauge-theory reading (Chen, Kapustin and Radicevic).
Scope: as stated.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen; the controls are:
Options: --fault NAME (WILSON, CHIR in N; NOZ, FLIP in B) runs only the item that carries the wrong version and must exit 1.
Command: python3 qmt_lattice.py   (from this folder, or python3 selfcheck/proofs/qmt_lattice.py from the package root; numpy, scipy)."""
import os, sys, itertools, random, math
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
for _p in (os.path.join(_selfcheck, 'steps15_17'),):
    if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
from bitcliff import Alg, sig, regular_matrix

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('WILSON', 'CHIR', 'NOZ', 'FLIP')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
FAULT_ITEM = {'WILSON': 'doublers', 'CHIR': 'doublers', 'NOZ': 'boson', 'FLIP': 'boson'}
def pc(x): return bin(x).count('1')

# ================================================================================================ N. doublers
def gammas(d):
    A = Alg(sig(d, 0))
    return [np.array(regular_matrix(A, {1 << mu: 1}), dtype=np.int64) for mu in range(d)], A
def item_doublers():
    head('N. The naive lattice Dirac operator: zeros, chiralities, the Wilson term')
    okc = True; okz = True; lines = []; okstd = True; okjac = True; wil = []; wil_true = []; chiral_ok = True
    for d in range(1, 5):
        G, A = gammas(d); D = G[0].shape[0]; I = np.eye(D, dtype=np.int64)
        okc &= all(np.array_equal(G[a] @ G[b] + G[b] @ G[a], 2 * I * (a == b)) for a in range(d) for b in range(d))
        corners = list(itertools.product((0, 1), repeat=d))                      # k_mu = 0 or pi: sin = 0, cos = +1 or -1 exactly
        chis = []
        for c in corners:
            cosv = [1 - 2 * t for t in c]
            chi = 1
            for v in cosv: chi *= v
            if FAULT == 'CHIR': chi = 1
            frame = I.copy()
            for mu in range(d): frame = frame @ (cosv[mu] * G[mu])
            vol = I.copy()
            for mu in range(d): vol = vol @ G[mu]
            okz &= np.array_equal(frame, chi * vol) or FAULT == 'CHIR'
            chis.append(chi)
        npos, nneg = chis.count(1), chis.count(-1)
        okz &= npos == nneg == 2 ** (d - 1)
        lines.append('d=%d: %d zeros, %d of chirality +1 and %d of -1' % (d, len(corners), npos, nneg))
        # Wilson term (Euclidean): D_W(k) = i sum sin(k) gamma + r sum (1 - cos k); D_W^dagger D_W = sum sin^2 + W^2 (exact: the gammas anticommute)
        Wv = [2 * sum(c) for c in corners]                                         # W = r sum (1 - cos k) = 2r (number of pi entries), r = 1
        wil_true.append(sum(1 for w_ in Wv if w_ == 0))
        wil.append(wil_true[-1] if FAULT != 'WILSON' else len(corners))
        if d % 2 == 0:
            vol = I.copy()
            for mu in range(d): vol = vol @ G[mu]
            chiral_ok &= all(np.array_equal(vol @ G[mu], -G[mu] @ vol) for mu in range(d))
        # [std]
        npts = {1: 64, 2: 64, 3: 16, 4: 8}[d]
        ks = [2 * math.pi * j / npts for j in range(npts)]
        zeros = []
        for k in itertools.product(ks, repeat=d):
            H = sum(math.sin(k[mu]) * G[mu] for mu in range(d))
            if np.min(np.abs(np.linalg.eigvalsh(H.astype(float)))) < 1e-9: zeros.append(k)
        okstd &= sorted(zeros) == sorted(tuple(math.pi * t for t in c) for c in corners)
        for c in corners:
            k0 = np.array([math.pi * t for t in c]); h = 1e-6; Jm = np.zeros((d, d))
            for nu in range(d):
                kp = k0.copy(); km = k0.copy(); kp[nu] += h; km[nu] -= h
                Hp = sum(math.sin(kp[mu]) * G[mu] for mu in range(d)); Hm = sum(math.sin(km[mu]) * G[mu] for mu in range(d))
                for mu in range(d): Jm[mu, nu] = np.trace((Hp - Hm) @ G[mu]) / (2 * h * D)
            okjac &= int(np.sign(np.linalg.det(Jm))) == (1 if FAULT == 'CHIR' else int(np.prod([1 - 2 * t for t in c])))
    chk('bit', okc, 'qmt·N1: the left multiplication matrices of Cl(d,0) satisfy gamma_mu gamma_nu + gamma_nu gamma_mu = 2 delta_mu,nu (integers, d = 1..4), so H(k)^2 = (sum sin^2 k_mu) 1: H(k) = 0 exactly when every sin k_mu = 0, at the 2^d corners of the Brillouin zone')
    chk('bit', okz, 'qmt·N2: at each corner the effective frame cos(k_mu) gamma_mu has volume element prod cos(k_mu) times gamma_1 .. gamma_d: the chirality (the sign of the Jacobian of k -> sin k) is prod cos(k_mu) = +-1, and ' + '; '.join(lines) + ' (exact)')
    chk('std', okstd, 'qmt·N3: numpy eigenvalues of H(k) on grids of 64^d (d <= 2), 16^3, 8^4 points that contain the corners: |E| < 1e-9 exactly at the 2^d corners and nowhere else on the grid')
    chk('bit==std', okjac, 'qmt·N3: the sign of the numerical Jacobian of the components tr(H gamma_mu)/D (central differences, h = 1e-6) at each corner equals the exact chirality prod cos(k_mu), d = 1..4')
    chk('bit', wil == [1, 1, 1, 1] and chiral_ok, 'qmt·N4: with the Wilson term r sum (1 - cos k_mu) (r = 1; D_W^dagger D_W = sum sin^2 + W^2 exactly) the corners other than k = 0 have W = 2r (number of pi entries) != 0: %s zero(s) for d = 1..4, all of one chirality; for d = 2, 4 the volume element anticommutes with every gamma_mu (the chiral symmetry of the naive operator) and commutes with the Wilson term, which breaks it' % wil)
    chk('ctl', all(w != 2 ** d for d, w in zip(range(1, 5), wil_true)), 'qmt·N4: the computed Wilson counts %s differ from 2^d for every d = 1..4: the term removes the doublers and with them the chiral balance (the --fault WILSON run counts 2^d)' % wil_true)
    # random local chiral operators in d = 2
    rg = random.Random(34); nsamp = 0; balanced = 0; tot = []
    from scipy.optimize import fsolve
    for s in range(10):
        co = [[(rg.randint(-2, 2), rg.randint(-2, 2), rg.randint(-3, 3), rg.randint(-3, 3)) for _ in range(6)] for _ in range(2)]
        def f(k):
            return np.array([sum(a * math.cos(n1 * k[0] + n2 * k[1]) + b * math.sin(n1 * k[0] + n2 * k[1]) for (n1, n2, a, b) in co[mu]) for mu in range(2)])
        def jac(k):
            return np.array([[sum(-a * n * math.sin(n1 * k[0] + n2 * k[1]) + b * n * math.cos(n1 * k[0] + n2 * k[1]) for (n1, n2, a, b) in co[mu] for n in [(n1, n2)[nu]]) for nu in range(2)] for mu in range(2)])
        roots = []
        g = 240; kk = 2 * math.pi * np.arange(g) / g; K1, K2 = np.meshgrid(kk, kk, indexing='ij')
        Fv = [sum(a * np.cos(n1 * K1 + n2 * K2) + b * np.sin(n1 * K1 + n2 * K2) for (n1, n2, a, b) in co[mu]) for mu in range(2)]
        cand = []
        for i in range(g):
            for j in range(g):
                ok_ = True
                for mu in range(2):
                    vals = [Fv[mu][i, j], Fv[mu][(i + 1) % g, j], Fv[mu][i, (j + 1) % g], Fv[mu][(i + 1) % g, (j + 1) % g]]
                    ok_ &= min(vals) <= 0 <= max(vals)
                if ok_: cand.append((i, j))
        for (i, j) in cand:
            for (di, dj) in ((.5, .5), (0, 0), (1, 0), (0, 1), (1, 1)):
                k0 = np.array([2 * math.pi * (i + di) / g, 2 * math.pi * (j + dj) / g])
                sol, info, ier, msg = fsolve(f, k0, fprime=jac, full_output=True, xtol=1e-13)
                if ier != 1 or np.max(np.abs(f(sol))) > 1e-10: continue
                sol = np.mod(sol, 2 * math.pi)
                if all(np.max(np.abs(np.mod(sol - r + math.pi, 2 * math.pi) - math.pi)) > 1e-6 for r in roots): roots.append(sol)
        dets = [np.linalg.det(jac(r)) for r in roots]
        ok_nd = all(abs(x) > 1e-6 for x in dets)
        npos = sum(1 for x in dets if x > 0); nneg = sum(1 for x in dets if x < 0)
        nsamp += 1; balanced += int(ok_nd and npos == nneg); tot.append('%d+%d' % (npos, nneg))
    chk('std', balanced == nsamp, 'qmt·N5: ten seeded random local chiral operators f_1(k) sigma_1 + f_2(k) sigma_2 (f trigonometric polynomials of range <= 2, six integer terms each): numerical zeros (Newton from the centre and corners of the cells of a 240 x 240 grid where both components change sign, |f| < 1e-10, all non-degenerate) split by chirality as %s: as many of each sign in every sample' % ', '.join(tot))

# ================================================================================================ B. exact bosonization
def cube_surface():
    V = list(itertools.product((0, 1), repeat=3))
    faces = [(a, v) for a in range(3) for v in (0, 1)]                            # x_a = v
    edges = []
    for u in V:
        for a in range(3):
            if u[a] == 0:
                w = list(u); w[a] = 1; edges.append((u, tuple(w), a))
    def faces_of(e):
        u, w, a = e; return [faces.index((b, u[b])) for b in range(3) if b != a]
    E = [faces_of(e) for e in edges]
    vert_edges = [[i for i, e in enumerate(edges) if v in (e[0], e[1])] for v in V]
    return len(faces), E, vert_edges
def torus(L):
    fid = lambda i, j: (i % L) * L + (j % L)
    E = []; vert_edges = [[] for _ in range(L * L)]
    for i in range(L):
        for j in range(L):
            E.append([fid(i, j), fid(i, j - 1)]); vert_edges[fid(i, j)].append(len(E) - 1); vert_edges[fid(i + 1, j)].append(len(E) - 1)
            E.append([fid(i, j), fid(i - 1, j)]); vert_edges[fid(i, j)].append(len(E) - 1); vert_edges[fid(i, j + 1)].append(len(E) - 1)
    return L * L, E, vert_edges
def f2_rank(vs):
    basis = []
    for v in vs:
        for b in basis: v = min(v, v ^ b)
        if v: basis.append(v)
    return len(basis)
def f2_kernel(cols, nbits):
    """kernel of the F2-linear map e_i -> cols[i] (ints): a basis of the relations, as int masks over the generators"""
    piv = {}; ker = []
    for i, c in enumerate(cols):
        comb = 1 << i
        while c:
            hb = c.bit_length() - 1
            if hb in piv:
                pc_, pm = piv[hb]; c ^= pc_; comb ^= pm
            else:
                piv[hb] = (c, comb); break
        if c == 0: ker.append(comb)
    return ker
def pauli_mul(p1, p2):
    (s1, x1, z1), (s2, x2, z2) = p1, p2
    return (s1 * s2 * (-1) ** pc(z1 & x2), x1 ^ x2, z1 ^ z2)
def pauli_comm(p1, p2): return (pc(p1[1] & p2[2]) + pc(p1[2] & p2[1])) % 2

def bosonize(name, F, E, vert_edges, orient=None, Rover=None):
    nE = len(E); A = Alg(sig(F, F))
    LR = [tuple(e) if (orient is None or not orient[i]) else (e[1], e[0]) for i, e in enumerate(E)]
    gen_f = [(1 << f) | (1 << (F + f)) for f in range(F)]                          # P_f = g_f g'_f
    gen_e = [(1 << L_) | (1 << (F + R_)) for (L_, R_) in LR]                       # S_e = g_L g'_R
    gens = gen_f + gen_e; ng = len(gens)
    beta_F = [[0 if A.comm_sign(a, b) == 1 else 1 for b in gens] for a in gens]
    sq_ok = all(A.sq(m) == 1 for m in gens)
    # bosons
    face_edges = [[i for i, e in enumerate(E) if f in e] for f in range(F)]
    W = [(1, 0, sum(1 << i for i in face_edges[f])) for f in range(F)]
    R = Rover if Rover is not None else [sum(1 << j for j in range(i) if beta_F[F + i][F + j]) for i in range(nE)]    # default: e' < e with S_e, S_e' anticommuting
    local = all(all(set(E[j]) & set(E[i]) for j in range(nE) if R[i] >> j & 1) for i in range(nE))
    U = [(1, 1 << i, 0 if FAULT == 'NOZ' else R[i]) for i in range(nE)]
    imgs = W + U
    beta_B = [[pauli_comm(a, b) for b in imgs] for a in imgs]
    match = beta_F == beta_B and all(pauli_mul(p, p)[0] == 1 for p in imgs)
    # relations: products of generators that are +-1 on the fermion side
    ker = f2_kernel(gens, 2 * F)
    def ferm_prod(kappa):
        s, m = 1, 0
        for i in range(ng):
            if kappa >> i & 1:
                s2, m = A.blade_mul(m, gens[i]); s *= s2
        return s, m
    def bos_prod(kappa):
        p = (1, 0, 0)
        for i in range(ng):
            if kappa >> i & 1: p = pauli_mul(p, imgs[i])
        return p
    rel_ok = all(ferm_prod(k)[1] == 0 for k in ker)
    cons = []
    for idx_, k in enumerate(ker):
        sF, _ = ferm_prod(k); sB, x, z = bos_prod(k)
        c = sF * sB
        if FAULT == 'FLIP' and idx_ == 0: c = -c
        cons.append((c, x, z))
    gauge = all(pauli_comm(cn, g) == 0 for cn in cons for g in imgs) and all(pauli_comm(a, b) == 0 for a in cons for b in cons)
    # every relation of the span: the value forced on the constrained space must be the fermion sign
    signs_ok = True; ident_ok = True
    for comb in range(1, 1 << len(ker)):
        kappa = 0; O = (1, 0, 0)
        for t, k in enumerate(ker):
            if comb >> t & 1: kappa ^= k; O = pauli_mul(O, cons[t])
        sF, _ = ferm_prod(kappa); sB, x, z = bos_prod(kappa)
        if (x, z) != (O[1], O[2]): signs_ok = False
        elif O[0] != sF * sB: signs_ok = False
        if (x, z) == (0, 0) and sF * sB != 1: ident_ok = False
    rc = f2_rank([(x << nE) | z for (c, x, z) in cons])
    code_dim_log = nE - rc
    # the extra boson relation: the total parity
    tot = 0
    for f in range(F): tot |= 1 << f
    sTF, mTF = ferm_prod(tot); sTB, xT, zT = bos_prod(tot)
    rank_F = f2_rank(gens); rank_B = f2_rank([(p[1] << nE) | p[2] for p in imgs])
    return dict(name=name, F=F, E=nE, V=len(vert_edges), sq_ok=sq_ok, match=match, local=local, Rsizes=sorted(pc(r) for r in R), ker=len(ker), rel_ok=rel_ok,
                gauge=gauge, signs_ok=signs_ok and ident_ok, rc=rc, code=code_dim_log, totF=(mTF == (1 << (2 * F)) - 1), totB=(xT, zT) == (0, 0) and sTB == 1,
                rank_F=rank_F, rank_B=rank_B, beta_F=beta_F)

def single_z_R(F, E, orient):
    """if the anticommutation graph of the S_e is a pseudoforest, orient it with out-degree <= 1 (leaves first, then the cycles):
    R(e) = {out(e)}, a single Z per edge; else None"""
    if not single_z_possible(F, E, orient): return None
    LR = [tuple(e) if not orient[i] else (e[1], e[0]) for i, e in enumerate(E)]
    n = len(E); adj = [set(j for j in range(n) if j != i and ((LR[i][0] == LR[j][0]) + (LR[i][1] == LR[j][1])) % 2) for i in range(n)]
    out = [None] * n
    while True:
        leaf = next((u for u in range(n) if len(adj[u]) == 1), None)
        if leaf is None: break
        v = adj[leaf].pop(); adj[v].discard(leaf); out[leaf] = v
    for u0 in range(n):
        while adj[u0]:
            u = u0
            while adj[u]:
                v = min(adj[u]); adj[u].discard(v); adj[v].discard(u); out[u] = v; u = v
    return [(1 << out[i]) if out[i] is not None else 0 for i in range(n)]

def single_z_possible(F, E, orient):
    LR = [tuple(e) if not orient[i] else (e[1], e[0]) for i, e in enumerate(E)]
    n = len(E); adj = [[j for j in range(n) if j != i and ((LR[i][0] == LR[j][0]) + (LR[i][1] == LR[j][1])) % 2] for i in range(n)]
    seen = [False] * n
    for s in range(n):
        if seen[s]: continue
        comp = []; st = [s]; seen[s] = True
        while st:
            u = st.pop(); comp.append(u)
            for v in adj[u]:
                if not seen[v]: seen[v] = True; st.append(v)
        ne = sum(len(adj[u]) for u in comp) // 2
        if ne > len(comp): return False
    return True

def item_boson():
    head('B. Exact bosonization on the surface of the 3-cube and on a 3 x 3 torus')
    for (name, data) in (('cube surface', cube_surface()), ('3 x 3 torus', torus(3))):
        F, E, vert_edges = data
        nE = len(E)
        if name == 'cube surface':
            fits = [o for o in itertools.product((0, 1), repeat=nE) if single_z_possible(F, E, o)]
            print('  info cube surface: a single Z per edge (the form of Chen, Kapustin and Radicevic) is possible for %d of the 4096 choices of which face carries g and which g\' on each edge; the first of them is used' % len(fits), flush=True)
            orient = list(fits[0]) if fits else [0] * nE
        else:
            orient = [0] * nE
            print('  info 3 x 3 torus: g on the face above a horizontal edge and on the face right of a vertical edge; a single Z per edge is %s' % ('possible' if single_z_possible(F, E, orient) else 'not possible'), flush=True)
        Rz = single_z_R(F, E, orient)
        r = bosonize(name, F, E, vert_edges, orient=orient, Rover=Rz)
        rg_ = bosonize(name, F, E, vert_edges)
        chk('bit==std', Rz is not None and max(pc(x) for x in Rz) <= 1 and rg_['match'] and rg_['signs_ok'] and rg_['code'] == F - 1, 'qmt·B1: %s: the single-Z form U_e = X_e Z_r(e) exists for this choice (|R(e)| <= 1 on every edge) and is used below; the general F2 solution with another choice (R(e) = the earlier anticommuting edges, |R(e)| up to %d) passes the same checks' % (name, max(rg_['Rsizes'])))
        chk('bit==std', r['sq_ok'] and r['match'] and r['local'], 'qmt·B1: %s (F = %d faces, E = %d edges, V = %d vertices): P_f = g_f g\'_f and S_e = g_L g\'_R (bit rule of Cl(%d,%d)) square to 1; the real Pauli strings W_f = prod Z around f and U_e = X_e prod_{R(e)} Z square to 1 and have the same %d x %d commutation matrix, with every edge of R(e) sharing a face with e (|R(e)| = %s)' % (name, F, len(E), r['V'], F, F, F + len(E), F + len(E), ', '.join(map(str, r['Rsizes']))))
        chk('bit', r['rel_ok'] and r['ker'] == F + len(E) - r['rank_F'] and r['rank_F'] == 2 * F - 1, 'qmt·B2: %s: the F + E fermion generators span the %d-dimensional F2 space of even masks (all even products of the 2F Majoranas); their relations, products equal to +-1, form a space of dimension %d (exact signs from the bit rule)' % (name, r['rank_F'], r['ker']))
        chk('std', r['gauge'] and r['signs_ok'], 'qmt·B3: %s: each relation maps to a Pauli string that commutes with every W_f and U_e and with the others (a gauge constraint); with the value of each basis constraint set to (fermion sign) x (boson sign), every one of the %d relations of their span holds on the constrained space with its fermion sign, and no relation forces -1 = 1' % (name, 2 ** r['ker'] - 1))
        chk('std', r['code'] == F - 1 and r['rank_B'] == r['rank_F'] - 1 + r['rc'] and r['rank_B'] - r['rc'] == 2 * r['code'], 'qmt·B4: %s: the %d constraints have rank %d, so the constrained space has dimension 2^(%d - %d) = 2^%d = 2^(F - 1), the even sector of %d fermion modes; the images span an F2 space of dimension %d = (%d - 1) + %d, and modulo the constraints %d = 2 x %d: the full matrix algebra of the constrained space' % (name, r['ker'], r['rc'], len(E), r['rc'], r['code'], F, r['rank_B'], r['rank_F'], r['rc'], r['rank_B'] - r['rc'], r['code']))
        chk('bit==std', r['totF'] and r['totB'], 'qmt·B5: %s: the product of the P_f is +-(the product of all 2F Majoranas), the total fermion parity, while the product of the W_f is the identity string (each edge bounds two faces): the total parity maps to the total flux, 1 on a closed surface' % name)
    # controls in the normal run
    saved = globals()['FAULT']
    globals()['FAULT'] = 'NOZ'; rz = bosonize('cube surface', *cube_surface())
    globals()['FAULT'] = 'FLIP'; rf = bosonize('cube surface', *cube_surface())
    globals()['FAULT'] = saved
    chk('ctl', not rz['match'], 'qmt·B6: U_e = X_e alone (no Z string) gives a different commutation matrix on the cube surface')
    chk('ctl', not rf['signs_ok'], 'qmt·B6: one constraint value flipped makes a fermion relation fail on the constrained space (the cube surface)')

ITEMS = [('doublers', item_doublers), ('boson', item_boson)]
if __name__ == '__main__':
    sel = [FAULT_ITEM[FAULT]] if FAULT else None
    for name, it in ITEMS:
        if sel is None or name in sel: it()
    finish('QMT-LATTICE')
