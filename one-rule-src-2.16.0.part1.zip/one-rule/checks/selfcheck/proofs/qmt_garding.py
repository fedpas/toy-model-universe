#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""qmt_garding.py: Garding hyperbolicity for the quadratic form of every cell Cl(p,q,r), n = p + q + r <= 5: the hyperbolic
directions, the cone, its dual, and the dual polynomial of a degenerate form.      python3 qmt_garding.py [--fault NAME]

G1 .. G6 (qmt·G1 .. G6).  P(x) = x x (the square of a vector by the bit rule: sum eps_i x_i^2, eps in {1, -1, 0}).  A direction h is
   hyperbolic when P(h) != 0 and t -> P(q + t h) = P(h) t^2 + 2 B(q,h) t + P(q) has only real roots for every q, that is when the
   discriminant form M_h = (B h)(B h)^T - P(h) B is positive semidefinite (exact, pivoted LDL over Q).  Every cell n <= 5 (55 cells),
   every h in {-1, 0, 1}^n and 20 seeded integer h (entries -3..3) per cell: hyperbolic exactly when the non-degenerate part has one
   + (p = 1) and P(h) > 0, or one - (q = 1) and P(h) < 0; for r >= 1 the roots are double along the kernel (rank of M_h = n - 1 - r).
   The cone C(h) = {x : P(x) P(h) > 0, B(x,h) P(h) > 0} (the component of P != 0 that holds h) is convex and every point of it is a
   hyperbolic direction (200 seeded pairs per cell, exact).  The dual, defined as the convex dual {eta : eta(x) >= 0 on C(h)}: for
   r = 0 the closed cone {P^-1(eta) P(h) >= 0, eta(h) >= 0} of the inverse form (60 seeded eta per cell against 1000 seeded points
   of the cone; every eta outside it gets an exact point of the cone where eta < 0); for r >= 1 every eta with a component on a null
   generator z has the exact witness x = h + t e_z in the cone with eta(x) = -1, so the dual lies in the annihilator of the kernel
   and has no interior.  The dual polynomial of the closure paper (the polynomial of least degree vanishing on the gradients DP(x)
   at the smooth null vectors x, on 40 rational null points per cell): degree 2, one quadric, the inverse form, for r = 0; degree
   1 for r >= 1, the r null coordinates (exact ranks).
   [std] numpy roots of t -> P(q + t h) on 100 seeded q per (cell, h) for the 55 cells and h in {-1, 0, 1}^n: all real (|imaginary
   part| < 1e-7) exactly on the hyperbolic pairs.  [ctl] EUCL, NULLH, DUALZ.  Recalled, not computed: Garding's theorems for a general
   hyperbolic polynomial (convexity of the cone, hyperbolicity in every direction of it).
Scope: as stated.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen; the controls are:
Options: --fault NAME (EUCL, NULLH, DUALZ) makes the check that carries the wrong version fail and exit 1.
Command: python3 qmt_garding.py   (from this folder, or python3 selfcheck/proofs/qmt_garding.py from the package root; numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
for _p in (os.path.join(_selfcheck, 'steps15_17'),):
    if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
from bitcliff import Alg, sig

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('EUCL', 'NULLH', 'DUALZ')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

def psd_exact(G):
    n = len(G); M = [list(r) for r in G]; act = list(range(n))
    while act:
        i = max(act, key=lambda t: M[t][t]); d = M[i][i]
        if d < 0: return False
        if d == 0: return all(M[a][b] == 0 for a in act for b in act)
        act.remove(i)
        for a in act:
            if M[a][i]:
                f = M[a][i] / d
                for b in act: M[a][b] -= f * M[i][b]
    return True
def rank_q(rows):
    M = [[Fr(v) for v in r] for r in rows]; rk = 0; nc = len(M[0]) if M else 0
    for col in range(nc):
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk

class Cell:
    def __init__(self, p, q, r):
        self.p, self.q, self.r = p, q, r; self.n = p + q + r; self.A = Alg(sig(p, q, r))
        n = self.n
        # the form from the bit rule: B(e_i, e_j) = scalar part of (e_i e_j + e_j e_i)/2
        self.B = [[Fr(self.A.mul({1 << i: 1}, {1 << j: 1}).get(0, 0) + self.A.mul({1 << j: 1}, {1 << i: 1}).get(0, 0), 2) for j in range(n)] for i in range(n)]
        self.eps = [self.B[i][i] for i in range(n)]
    def P(self, x): return sum(e * Fr(c) * c for e, c in zip(self.eps, x))
    def Bf(self, x, y): return sum(e * Fr(a) * b for e, a, b in zip(self.eps, x, y))
    def Mh(self, h):
        n = self.n; Bh = [self.eps[i] * h[i] for i in range(n)]; Ph = self.P(h)
        return [[Bh[i] * Bh[j] - Ph * self.B[i][j] for j in range(n)] for i in range(n)]
    def hyperbolic(self, h):
        return self.P(h) != 0 and psd_exact(self.Mh(h))
    def rule(self, h):
        Ph = self.P(h)
        return (self.p == 1 and Ph > 0) or (self.q == 1 and Ph < 0)
    def in_cone(self, x, h):
        s = 1 if self.P(h) > 0 else -1
        return s * self.P(x) > 0 and s * self.Bf(x, h) > 0

def witness(C, h, eta):
    """an exact point x of C(h) with eta(x) < 0 for a covector eta outside {s P^-1(eta) >= 0, eta(h) >= 0} (r = 0): x = h if
    eta(h) < 0; else, with Q = s P and the vector u = s (eps . eta) (so that eta(x) = Q-pairing of u and x), u = a h + w with w
    orthogonal to h, and x = h + t w with a Q(h)/|Q(w)| < t < sqrt(Q(h)/|Q(w)|)"""
    n = C.n; s = 1 if C.P(h) > 0 else -1
    if sum(Fr(a) * b for a, b in zip(eta, h)) < 0: return [Fr(c) for c in h]
    Q = lambda x: s * C.P(x); Bq = lambda x, y: s * C.Bf(x, y)
    u = [s * C.eps[i] * eta[i] for i in range(n)]
    a = Bq(u, h) / Q(h); w = [Fr(u[i]) - a * h[i] for i in range(n)]; Qw = Q(w)
    if Qw >= 0: return None
    lo = a * Q(h) / (-Qw); hi2 = Q(h) / (-Qw)
    for den in (10, 100, 1000, 10 ** 4, 10 ** 6):
        t = Fr((float(lo) + float(hi2) ** 0.5) / 2).limit_denominator(den)
        if t > lo and t * t < hi2: return [Fr(h[i]) + t * w[i] for i in range(n)]
    return None

CELLS = [(p, q, n - p - q) for n in range(1, 6) for p in range(n, -1, -1) for q in range(n - p, -1, -1)]

def main():
    head('Garding hyperbolicity of the quadratic form of the cells Cl(p,q,r), n <= 5')
    rg = random.Random(9)
    ok_rule = True; ok_rank = True; npair = 0; nhyp = 0; hyp_cells = set(); ok_np = True; nnp = 0
    for (p, q, r) in CELLS:
        C = Cell(p, q, r); n = C.n
        hs = [h for h in itertools.product((-1, 0, 1), repeat=n) if any(h)]
        hs += [tuple(rg.randint(-3, 3) for _ in range(n)) for _ in range(20)]
        rgn = np.random.default_rng(100 + 10 * p + q + 1000 * r)
        for k_, h in enumerate(hs):
            if not any(h): continue
            hy = C.hyperbolic(h); npair += 1
            if FAULT == 'EUCL' and (p, q, r) == (2, 0, 0) and h == (1, 0): hy = True
            if FAULT == 'NULLH' and (p, q, r) == (1, 1, 0) and h == (1, 1): hy = True
            ok_rule &= hy == C.rule(h)
            if hy:
                nhyp += 1; hyp_cells.add((p, q, r))
                rk = rank_q(C.Mh(h)); ok_rank &= rk == n - 1 - r
            if k_ < 3 ** n - 1:
                Q_ = rgn.normal(size=(100, n)); ev = np.array([float(e) for e in C.eps]); hv = np.array(h, dtype=float)
                a2 = float(C.P(h)); a1 = 2 * (Q_ * ev) @ hv; a0 = (Q_ * Q_) @ ev
                if a2 == 0: rts_real = False
                else:
                    comp = np.zeros((100, 2, 2)); comp[:, 0, 0] = -a1 / a2; comp[:, 0, 1] = -a0 / a2; comp[:, 1, 0] = 1.0
                    rts = np.linalg.eigvals(comp); rts_real = bool(np.all(np.abs(rts.imag) <= 1e-6 * (1 + np.abs(rts.real))))
                ok_np &= rts_real == C.hyperbolic(h); nnp += 1
    lor = sorted(c for c in CELLS if c[0] == 1 or c[1] == 1)
    chk('bit', ok_rule, 'qmt·G1: on the %d cells n <= 5 and %d directions h (all of {-1,0,1}^n and 20 seeded integer h per cell), h is hyperbolic (P(h) != 0 and the discriminant form M_h positive semidefinite, exact) exactly when p = 1 and P(h) > 0 or q = 1 and P(h) < 0: %d hyperbolic pairs, on the %d cells with p = 1 or q = 1 and no others' % (len(CELLS), npair, nhyp, len(hyp_cells)))
    chk('bit', ok_rank and hyp_cells == set(lor), 'qmt·G1: for every hyperbolic pair the discriminant form has rank n - 1 - r: strictly hyperbolic (two distinct roots off the line of h) for r = 0, double roots along the kernel for r >= 1 (exact)')
    chk('std', ok_np, 'qmt·G2: numpy eigenvalues of the companion matrices of t -> P(q + t h) for 100 seeded normal q per pair, %d pairs (h in {-1,0,1}^n): all roots real (|imaginary part| <= 1e-6 (1 + |real part|)) exactly on the pairs the exact test calls hyperbolic' % nnp)
    # the cone, convexity, hyperbolic in every point
    ok_conv = True; ok_allhyp = True; ncone = 0
    for (p, q, r) in lor:
        C = Cell(p, q, r); n = C.n
        h = [0] * n; h[0 if p == 1 else p] = 1
        pts = []
        while len(pts) < 400:
            x = [rg.randint(-4, 4) for _ in range(n)]
            if C.in_cone(x, h): pts.append(x)
        for i in range(200):
            x, y = pts[2 * i], pts[2 * i + 1]
            lam = Fr(rg.randint(1, 9), rg.randint(1, 9))
            ok_conv &= C.in_cone([a + b for a, b in zip(x, y)], h) and C.in_cone([lam * a for a in x], h)
            ok_allhyp &= C.hyperbolic(x)
        ncone += 1
    chk('bit', ok_conv, 'qmt·G3: on the %d cells with a hyperbolic direction (h the basis vector of the single sign), C(h) = {P(x) P(h) > 0, B(x,h) P(h) > 0} is a convex cone: x + y and lam x (lam a seeded positive rational) stay in it for 200 seeded pairs per cell (exact)' % ncone)
    chk('bit', ok_allhyp, 'qmt·G3: every one of the 200 x %d sampled points of the cones is itself a hyperbolic direction (exact)' % ncone)
    # the dual cone
    ok_d0 = True; ok_wit = True; ok_dz = True; nd0 = 0; ndz = 0; dualz_claim = True
    for (p, q, r) in lor:
        C = Cell(p, q, r); n = C.n
        h = [0] * n; h[0 if p == 1 else p] = 1; s = 1 if C.P(h) > 0 else -1
        pts = []
        while len(pts) < 1000:
            x = [rg.randint(-6, 6) for _ in range(n)]
            if C.in_cone(x, h): pts.append(x)
        if r == 0:
            for _ in range(60):
                eta = [rg.randint(-4, 4) for _ in range(n)]
                inv = sum(e * Fr(c) * c for e, c in zip(C.eps, eta))                    # P^-1(eta): the same signs, eps = +-1
                eh = sum(Fr(a) * b for a, b in zip(eta, h))
                claimed = s * inv >= 0 and eh >= 0
                if claimed:
                    ok_d0 &= min(sum(Fr(eta[i]) * x[i] for i in range(n)) for x in pts) >= 0
                else:
                    x = witness(C, h, eta)
                    ok_wit &= x is not None and C.in_cone(x, h) and sum(Fr(eta[i]) * x[i] for i in range(n)) < 0
                nd0 += 1
        else:
            nulls = [i for i in range(n) if C.eps[i] == 0]
            for _ in range(30):
                eta = [rg.randint(-4, 4) for _ in range(n)]
                z = rg.choice(nulls)
                if eta[z] == 0: eta[z] = rg.choice((-1, 1)) * rg.randint(1, 4)
                eh = sum(Fr(eta[i]) * h[i] for i in range(n))
                t = -(eh + 1) / eta[z]
                x = [Fr(c) for c in h]; x[z] += t
                ok_dz &= C.in_cone(x, h) and sum(Fr(eta[i]) * x[i] for i in range(n)) == -1
                if FAULT == 'DUALZ': dualz_claim &= sum(Fr(eta[i]) * x[i] for i in range(n)) >= 0
                ndz += 1
    chk('bit', ok_d0 and ok_wit, 'qmt·G4: r = 0 (the %d cells with a hyperbolic direction): the convex dual of C(h) (covectors eta >= 0 on the cone) is the closed cone of the inverse form, {P^-1(eta) P(h) >= 0, eta(h) >= 0}: %d seeded covectors, those inside it are >= 0 on 1000 seeded points of the cone, and each one outside is negative at an exact point of the cone constructed for it' % (len([c for c in lor if c[2] == 0]), nd0))
    chk('bit', ok_dz and dualz_claim, 'qmt·G4: r >= 1 (the %d cells): for %d seeded covectors with a component on a null generator z, x = h + t e_z lies in C(h) (P and B do not see e_z) and eta(x) = -1 (exact): the convex dual lies in the annihilator of the kernel, a subspace of dimension n - r, and has no interior' % (len([c for c in lor if c[2] > 0]), ndz))
    chk('ctl', ndz > 0 and ok_dz, 'qmt·G4: a covector with a kernel component accepted as dual fails on the witness x = h + t e_z (the --fault DUALZ run accepts it)')
    # the dual polynomial of the closure paper
    def null_points(C, k):
        pos = [i for i in range(C.n) if C.eps[i] == 1]; neg = [i for i in range(C.n) if C.eps[i] == -1]; nul = [i for i in range(C.n) if C.eps[i] == 0]
        def unit(m):
            if m == 1: return [Fr(rg.choice((-1, 1)))]
            t = [Fr(rg.randint(-5, 5), rg.randint(1, 5)) for _ in range(m - 1)]; s2 = sum(c * c for c in t)
            return [(1 - s2) / (1 + s2)] + [2 * c / (1 + s2) for c in t]
        out = []
        for _ in range(k):
            R = Fr(rg.randint(1, 7), rg.randint(1, 3)); x = [Fr(0)] * C.n
            for i, c in zip(pos, unit(len(pos))): x[i] = R * c
            for i, c in zip(neg, unit(len(neg))): x[i] = R * c
            for i in nul: x[i] = Fr(rg.randint(-5, 5))
            assert C.P(x) == 0
            out.append(x)
        return out
    ok_p0 = True; ok_p1 = True; lines = []
    for (p, q, r) in CELLS:
        if p == 0 or q == 0: continue
        C = Cell(p, q, r); n = C.n
        xs = null_points(C, 40)
        grads = [[2 * C.eps[i] * x[i] for i in range(n)] for x in xs]
        if not all(any(g) for g in grads): ok_p0 = False
        lin_null = n - rank_q(grads)
        mons = [(i, j) for i in range(n) for j in range(i, n)]
        quad_null = len(mons) - rank_q([[g[i] * g[j] for (i, j) in mons] for g in grads])
        if r == 0:
            invq = all(sum(C.eps[i] * g[i] * g[i] for i in range(n)) == 0 for g in grads)
            ok_p0 &= lin_null == 0 and quad_null == 1 and invq
        else:
            kern = all(all(g[i] == 0 for i in range(n) if C.eps[i] == 0) for g in grads)
            ok_p1 &= lin_null == r and kern
        if (p, q) in ((1, 1), (1, 2), (2, 2), (1, 3)) and r <= 1: lines.append('(%d,%d,%d): %d linear, %d quadratic' % (p, q, r, lin_null, quad_null))
    chk('bit', ok_p0, 'qmt·G5: r = 0, p, q >= 1: on 40 rational null points per cell the gradients DP(x) are non-zero, no linear form vanishes on them and exactly one quadric does, the inverse form: the dual polynomial has degree 2 (exact ranks)')
    chk('bit', ok_p1, 'qmt·G5: r >= 1, p, q >= 1: the gradients have no component on the null generators, and the linear forms vanishing on them are exactly the r null coordinates: the dual polynomial of least degree is linear, an r-dimensional family, not a quadric (exact ranks; %s)' % '; '.join(lines))
    # controls
    C = Cell(2, 0, 0); x = [0, 1]
    disc = C.Bf(x, [1, 0]) ** 2 - C.P([1, 0]) * C.P(x)
    chk('ctl', disc < 0 and not C.hyperbolic([1, 0]), 'qmt·G6: the definite cell Cl(2,0,0) in the direction e0: q = e1 has discriminant %s < 0 (complex roots), so e0 is not hyperbolic (the --fault EUCL run calls it hyperbolic)' % disc)
    C = Cell(1, 1, 0)
    chk('ctl', C.P([1, 1]) == 0 and not C.hyperbolic([1, 1]), 'qmt·G6: in Cl(1,1,0) the null direction h = e0 + e1 has P(h) = 0: t -> P(q + t h) is linear, one root, not hyperbolic (the --fault NULLH run calls it hyperbolic)')

if __name__ == '__main__':
    main()
    finish('QMT-GARDING')
