#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""cone_obstructions.py: Einstein edge-cone metrics (Atiyah and LeBrun, "Curvature, cones and characteristic numbers", read): the
obstructions of Theorem 4.1 on named pairs (M, Sigma), exactly, and the explicit family of section 5 on (CP^2, CP^1) with its curvature
computed on the labels, the two theorems closing on it exactly.
python3 cone_obstructions.py [--fault NAME]

Read.  For an edge-cone metric of cone angle 2 pi beta along a surface Sigma in a compact oriented 4-manifold M: Theorem 2.1,
chi(M) - (1 - beta) chi(Sigma) = (1/8 pi^2) int (s^2/24 + |W|^2 - |r0|^2/2) dmu; Theorem 2.2, tau(M) - (1 - beta^2)[Sigma]^2/3 =
(1/12 pi^2) int (|W+|^2 - |W-|^2) dmu.  Theorem 4.1: an Einstein edge-cone metric needs (4.2) (2 chi + 3 tau)(M) >= (1 - beta)[2 chi(Sigma)
+ (1 + beta)[Sigma]^2] and (4.3) (2 chi - 3 tau)(M) >= (1 - beta)[2 chi(Sigma) - (1 + beta)[Sigma]^2], with equality iff the metric is
locally hyper-Kaehler (in the orientation of the inequality).  Section 5: on CP^2 with the cone along a projective line, with s the
hyperbolic distance and sigma_j the left-invariant orthonormal coframe of S^3, V = 1/beta + 1/(e^{2s} - 1) (5.4), g_0 = V [ds^2 +
4 sinh^2 s (sigma_1^2 + sigma_2^2)] + sigma_3^2/V (5.5), and g = 4/beta [(2 - beta) cosh s + beta sinh s]^{-2} g_0 (5.6) is Einstein with
lambda = 3 beta^2 (2 - beta)/2 for 0 < beta < 2 (Hitchin; Abreu's family), (1/12 pi^2) int |W+|^2 dmu = (2 + beta^2)/3 (5.7); beta = 1 is
Fubini-Study, beta -> 2 Eguchi-Hanson, beta -> 0 Taub-NUT.
On the labels.  With t = e^s and c_0 = 1 - beta the coefficients of g = a^2 ds^2 + b^2 (sigma_1^2 + sigma_2^2) + c^2 sigma_3^2 are rational
in t (a^2 = fV, b^2 = 4 fV sinh^2 s, c^2 = f/V, ab = 2 a^2 sinh s, ac = f, c/b = 1/(2 V sinh s)), the structure equations d sigma_i =
2 sigma_j sigma_k give the connection and the curvature in the orthonormal frame in closed form (R_0101 = -(L_b' + L_b^2 - L_b L_a)/a^2
with L = (log b)', R_1212 = 4/b^2 - 3 c^2/b^4 - L_b^2/a^2, R_2323 = c^2/b^4 - L_b L_c/a^2, R_2301 = (c/b)'/(ab), R_1203 = -(c^2/b^2)'/(ac), ...),
rational functions of t evaluated exactly at rational t through second-order jets; the curvature operator on the six bivector labels of
Cl(4,0) is split by the pseudoscalar e_0123 (the bit rule, I^2 = +1): one half of the Weyl operator vanishes, the other is 2 D_1 diag(1, 1, -2)
with D_1 = R_2301 = -beta^3 (t^2 + c_0)^3 / (4 (t^2 - c_0)^3), so |W+|^2 = 24 D_1^2; the volume form is 8 pi^2 f^2 V sinh^2 s ds =
(16 pi^2/beta^3) (u - c_0)(u - 1)/(u + c_0)^4 du with u = t^2, and the integrals over CP^2 are rational multiples of pi^2 by the antiderivatives.
O1. [std] the obstruction table of Theorem 4.1, exactly: (CP^2, line) beta <= 4; (CP^2, conic) beta <= 3/2; (CP^2, cubic) beta^2 <= 4/3;
    (CP^2 # k (-CP^2), cubic) k/9 <= beta^2 <= (12 + 5k)/9, k = 1..9; (S^2 x S^2, diagonal) beta <= 3; (S^4, S^2) every beta; (K3, (-2)-sphere)
    beta = 1 only; (T^4, torus of square 0) and (K3, torus of square 0): equality for every beta; at beta = 1 the pair is Hitchin-Thorpe;
    on a box of 7^4 integer quadruples, the admissible set is unbounded iff [Sigma]^2 = 0, chi(Sigma) >= 0 and M is Hitchin-Thorpe.
O2. [bit] the family on the labels: the frame curvature from the structure equations is Einstein with lambda = 3 beta^2 (2 - beta)/2
    exactly at 7 rational beta x 5 rational t; the pseudoscalar split: one half of W vanishes exactly, the other is 2 D_1 diag(1, 1, -2),
    |W+|^2 = 24 D_1^2 = (3 beta^6/2) ((t^2 + c_0)/(t^2 - c_0))^6; the general Weyl formula and the Einstein shortcut W = R - s/12 agree.
O3. [bit] the integrals, exactly (antiderivatives of rational functions): Vol = (8 pi^2/3)(4 - beta)/(beta^3 (2 - beta)^2), int |W+|^2 dmu =
    4 pi^2 (2 + beta^2) (the paper's (5.7)); Theorem 2.1 closes: chi(CP^2) - (1 - beta) chi(CP^1) = 1 + 2 beta = (1/8 pi^2) int (s^2/24 + |W+|^2);
    Theorem 2.2 closes: 1 - (1 - beta^2)/3 = (2 + beta^2)/3 = (1/12 pi^2) int |W+|^2; (4.2): the difference of the two sides is (2 + beta)^2 =
    (1/4 pi^2) int (2 |W+|^2 + s^2/24) > 0, (4.3): beta (4 - beta) = (1/4 pi^2) int s^2/24 > 0, strict (s != 0: not hyper-Kaehler), at 12 beta.
O4. [std] numpy: the Riemann tensor of the coordinate metric (s, theta, phi, psi) by finite differences at 3 beta x 3 points, against the
    closed forms in the orthonormal frame (1e-6) [bit==std]; Ricci = lambda delta (1e-6); the Hodge star by the Levi-Civita symbol: the same
    half of W vanishes (1e-6); Gauss-Legendre quadrature of the volume and of |W+|^2 at 12 beta against the exact values (1e-8); the cone
    angle: the circumference of the sigma_3-circle over 2 pi times the proper distance to the line tends to beta (s = 6, 9).
[ctl]  NOSQUARE (the signature defect (1 - beta)[Sigma]^2 instead of (1 - beta^2)[Sigma]^2: the table changes, Theorem 2.2 does not close),
       NOCONE (no defect terms: the table loses beta, both theorems fail off beta = 1), NOCONF (g_0 in place of g: not Einstein, the half of W
       still vanishes), WRONGVOL ((2 - beta) for (2 - beta)^2 in the volume: quadrature and antiderivative disagree with it), CARTAN (a wrong
       coefficient in R_1212: not Einstein, the finite differences disagree).
Standard library and numpy.   Command: python3 cone_obstructions.py   (from this folder, or python3 selfcheck/proofs/cone_obstructions.py from
the root of the checks)."""
import os, sys, itertools, math, time
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('NOSQUARE', 'NOCONE', 'NOCONF', 'WRONGVOL', 'CARTAN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

# ================================================================================================ O1. the obstruction table (Theorem 4.1)
def defect(chiS, S2, beta, sign):
    """the right-hand side of (4.2) (sign +1) or (4.3) (sign -1): (1 - beta)[2 chi(Sigma) + sign (1 + beta)[Sigma]^2]"""
    if FAULT == 'NOCONE': return Fr(0)
    if FAULT == 'NOSQUARE': return (1 - beta) * (2 * chiS + sign * S2)
    return (1 - beta) * (2 * chiS + sign * (1 + beta) * S2)
def P(chiM, tauM, chiS, S2, beta, sign):
    """the slack of the inequality: (2 chi + sign 3 tau)(M) - defect; the metric is obstructed where it is negative"""
    return 2 * chiM + sign * 3 * tauM - defect(chiS, S2, Fr(beta), sign)
def admissible(chiM, tauM, chiS, S2, beta):
    return P(chiM, tauM, chiS, S2, beta, 1) >= 0 and P(chiM, tauM, chiS, S2, beta, -1) >= 0
# (name, chi(M), tau(M), chi(Sigma), [Sigma]^2, the admissible beta > 0 as squared bounds (low, high), None for no bound, and as shown)
TABLE = [
    ('CP^2, a line', 3, 1, 2, 1, (None, Fr(16)), 'beta <= 4'),
    ('CP^2, a conic', 3, 1, 2, 4, (None, Fr(9, 4)), 'beta <= 3/2'),
    ('CP^2, a cubic', 3, 1, 0, 9, (None, Fr(4, 3)), 'beta^2 <= 4/3'),
    ('S^2 x S^2, the diagonal', 4, 0, 2, 2, (None, Fr(9)), 'beta <= 3'),
    ('S^4, a 2-sphere', 2, 0, 2, 0, (None, None), 'every beta'),
    ('K3, a (-2)-sphere', 24, -16, 2, -2, (Fr(1), Fr(1)), 'beta = 1 only'),
    ('T^4, a torus of square 0', 0, 0, 0, 0, (None, None), 'every beta, with equality in both'),
    ('K3, a torus of square 0', 24, -16, 0, 0, (None, None), 'every beta, with equality in (4.2)'),
] + [('CP^2 # %d (-CP^2), a cubic' % k, 3 + k, 1 - k, 0, 9, (Fr(k, 9), Fr(12 + 5 * k, 9)), ('%d/9 <= beta^2 <= %d/9' % (k, 12 + 5 * k)) if k != 9 else '1 <= beta^2 <= 57/9') for k in range(1, 10)]
head('O1. the obstruction table of Theorem 4.1 (read), exactly')
def isqrt_fr(q):
    """the square root of a rational square, or None"""
    a, b = math.isqrt(q.numerator), math.isqrt(q.denominator)
    return Fr(a, b) if Fr(a, b) ** 2 == q else None
def side_points(bound2):
    """two rational beta with the lower one below sqrt(bound2) and the upper one above (both at the bound if it is rational)"""
    r = isqrt_fr(bound2)
    if r is not None: return r - Fr(1, 1000), r, r + Fr(1, 1000)
    lo = Fr(math.floor(math.sqrt(bound2) * 1000), 1000); hi = lo + Fr(1, 1000); assert lo ** 2 < bound2 < hi ** 2
    return lo, None, hi
ok_tab = True; lines = []
for name, chiM, tauM, chiS, S2, (lo2, hi2), shown in TABLE:
    # the two slacks are quadratics in beta: coefficients by three exact evaluations, against sign [Sigma]^2 beta^2 + 2 chi(Sigma) beta + ...
    for sign in (1, -1):
        p0, p1, p2 = (P(chiM, tauM, chiS, S2, b, sign) for b in (0, 1, 2))
        c2 = (p2 - 2 * p1 + p0) / 2; c1 = p1 - p0 - c2
        ok_tab &= (c2, c1, p0) == (sign * S2, 2 * chiS, 2 * chiM + sign * 3 * tauM - 2 * chiS - sign * S2)
    # the admissible set, by exact evaluation on both sides of each bound and inside
    probes = []
    if lo2 is None and hi2 is None: probes = [(b, True) for b in (Fr(1, 10), Fr(1), Fr(3), Fr(100), Fr(10 ** 6))]
    elif lo2 == hi2:
        lo, r, hi = side_points(lo2); probes = [(r, True), (lo, False), (hi, False)]
    else:
        if lo2 is not None:
            lo, r, hi = side_points(lo2); probes += [(lo, False), (hi, True)] + ([(r, True)] if r is not None else [])
        if hi2 is not None:
            lo, r, hi = side_points(hi2); probes += [(lo, True), (hi, False)] + ([(r, True)] if r is not None else [])
        mid2 = ((lo2 or 0) + hi2) / 2 if hi2 is not None else lo2 + 1; mid = Fr(math.sqrt(mid2)).limit_denominator(1000)
        assert (lo2 or 0) < mid ** 2 < (hi2 if hi2 is not None else mid2 + 1); probes.append((mid, True))
    ok_tab &= all(admissible(chiM, tauM, chiS, S2, b) == want for b, want in probes if b > 0)
    lines.append('%s: %s' % (name, shown))
chk('std', ok_tab, 'cone.O1: the two slacks of Theorem 4.1 are the quadratics sign [Sigma]^2 beta^2 + 2 chi(Sigma) beta + (2 chi + sign 3 tau)(M) - 2 chi(Sigma) - sign [Sigma]^2, and the admissible cone angles 2 pi beta are, exactly: ' + '; '.join(lines[:8]) + '; ' + lines[8] + '; ...; ' + lines[-1])
# beta = 1: Hitchin-Thorpe
ok_ht = all(P(chiM, tauM, chiS, S2, 1, 1) == 2 * chiM + 3 * tauM and P(chiM, tauM, chiS, S2, 1, -1) == 2 * chiM - 3 * tauM for name, chiM, tauM, chiS, S2, _, _s in TABLE)
chk('std', ok_ht, 'cone.O1: at beta = 1 (no cone) both inequalities are the Hitchin-Thorpe inequality 2 chi >= 3 |tau| of M, on every pair of the table')
# the large-beta rule on a box of integers
ok_box = True; nbox = 0
for chiM, tauM, chiS, S2 in itertools.product(range(-3, 4), repeat=4):
    unbounded = all(admissible(chiM, tauM, chiS, S2, b) for b in (Fr(10 ** 3), Fr(10 ** 6), Fr(10 ** 9)))
    rule = S2 == 0 and (chiS > 0 or (chiS == 0 and 2 * chiM >= 3 * abs(tauM)))
    ok_box &= unbounded == rule; nbox += 1
chk('std', ok_box, 'cone.O1: on the box |chi(M)|, |tau(M)|, |chi(Sigma)|, |[Sigma]^2| <= 3 (%d quadruples), the admissible cone angle is unbounded above exactly when [Sigma]^2 = 0 and either chi(Sigma) > 0 or chi(Sigma) = 0 with M Hitchin-Thorpe: a large cone angle needs a surface of square zero and non-negative Euler number' % nbox)

# ================================================================================================ the family: exact jets in t = e^s
class J:
    """a second-order jet (value, d/ds, d^2/ds^2) at a point, exact"""
    __slots__ = ('v', 'd', 'dd')
    def __init__(self, v, d=0, dd=0): self.v, self.d, self.dd = Fr(v), Fr(d), Fr(dd)
    def __add__(self, o): o = o if isinstance(o, J) else J(o); return J(self.v + o.v, self.d + o.d, self.dd + o.dd)
    __radd__ = __add__
    def __neg__(self): return J(-self.v, -self.d, -self.dd)
    def __sub__(self, o): return self + (-(o if isinstance(o, J) else J(o)))
    def __rsub__(self, o): return (o if isinstance(o, J) else J(o)) + (-self)
    def __mul__(self, o): o = o if isinstance(o, J) else J(o); return J(self.v * o.v, self.d * o.v + self.v * o.d, self.dd * o.v + 2 * self.d * o.d + self.v * o.dd)
    __rmul__ = __mul__
    def inv(self): v, d, dd = self.v, self.d, self.dd; return J(1 / v, -d / v ** 2, (2 * d * d - v * dd) / v ** 3)
    def __truediv__(self, o): o = o if isinstance(o, J) else J(o); return self * o.inv()
    def __rtruediv__(self, o): return (o if isinstance(o, J) else J(o)) * self.inv()
def logd(x):
    """(log x)' and its derivative, from the jet of x (x may be a square: (log b)' = (b^2)'/(2 b^2))"""
    return x.d / x.v, x.dd / x.v - (x.d / x.v) ** 2
def family(beta, t0):
    """the metric coefficients of (5.4)-(5.6) at t = e^s = t0 as jets: a^2, b^2, c^2, ab, ac, c/b, and f, V, sinh s"""
    beta = Fr(beta); t = J(t0, t0, t0); c0 = 1 - beta                                 # t' = t
    V = J(1) / beta + J(1) / (t * t - 1)                                                # (5.4)
    f = J(1) if FAULT == 'NOCONF' else 4 / beta * (t * t) / ((t * t + c0) * (t * t + c0))   # (5.6): (2 - beta) cosh s + beta sinh s = (t^2 + c0)/t
    sh = (t - J(1) / t) * Fr(1, 2)
    A2 = f * V; B2 = 4 * f * V * sh * sh; C2 = f / V
    return dict(A2=A2, B2=B2, C2=C2, AB=2 * A2 * sh, AC=f, CB=J(1) / (2 * V * sh), f=f, V=V, sh=sh)
def frame_curvature(beta, t0):
    """R_ABCD in the orthonormal frame e0 = a ds, e1 = b sigma_1, e2 = b sigma_2, e3 = c sigma_3, from the structure equations: the six
    numbers A1 = R_0101 = R_0202, A3 = R_0303, B3 = R_1212, B1 = R_2323 = R_3131, D1 = R_2301 = R_3102, D3 = R_1203"""
    m = family(beta, t0); A2, B2, C2 = m['A2'], m['B2'], m['C2']
    La, La_ = logd(A2); Lb, Lb_ = logd(B2); Lc, Lc_ = logd(C2)                      # (log a)' etc. from the squares: halves
    La, La_, Lb, Lb_, Lc, Lc_ = La / 2, La_ / 2, Lb / 2, Lb_ / 2, Lc / 2, Lc_ / 2
    a2, b2, c2 = A2.v, B2.v, C2.v; cb = m['CB']; cb2 = cb * cb
    A1 = -(Lb_ + Lb * Lb - Lb * La) / a2
    A3 = -(Lc_ + Lc * Lc - Lc * La) / a2
    B3 = 4 / b2 - (3 if FAULT != 'CARTAN' else 1) * c2 / b2 ** 2 - Lb * Lb / a2
    B1 = c2 / b2 ** 2 - Lb * Lc / a2
    D1 = cb.d / m['AB'].v
    D3 = -cb2.d / m['AC'].v
    return dict(A1=A1, A3=A3, B3=B3, B1=B1, D1=D1, D3=D3)
PAIRS = [(0, 1), (0, 2), (0, 3), (2, 3), (3, 1), (1, 2)]                              # the bivector basis, Hodge-paired columns
def riemann_from(cv):
    """the full R_ABCD (4^4, exact) from the six frame numbers, by the symmetries"""
    R = {}
    def put(a, b, c, d, val):
        for (p, q, r, s), sg in (((a, b, c, d), 1), ((b, a, c, d), -1), ((a, b, d, c), -1), ((b, a, d, c), 1)):
            R[(p, q, r, s)] = sg * val; R[(r, s, p, q)] = sg * val
    put(0, 1, 0, 1, cv['A1']); put(0, 2, 0, 2, cv['A1']); put(0, 3, 0, 3, cv['A3'])
    put(1, 2, 1, 2, cv['B3']); put(2, 3, 2, 3, cv['B1']); put(3, 1, 3, 1, cv['B1'])
    put(2, 3, 0, 1, cv['D1']); put(3, 1, 0, 2, cv['D1']); put(1, 2, 0, 3, cv['D3'])
    return lambda a, b, c, d: R.get((a, b, c, d), Fr(0))
def ricci_of(R):
    return [[sum(R(a, i, b, i) for i in range(4)) for b in range(4)] for a in range(4)]
def weyl_operator(R):
    """the Weyl tensor by the general formula in dimension four, as the 6 x 6 matrix on the bivector basis PAIRS"""
    Ric = ricci_of(R); s = sum(Ric[i][i] for i in range(4)); dl = lambda i, j: Fr(int(i == j))
    def W(a, b, c, d):
        return (R(a, b, c, d) - Fr(1, 2) * (dl(a, c) * Ric[b][d] - dl(a, d) * Ric[b][c] - dl(b, c) * Ric[a][d] + dl(b, d) * Ric[a][c])
                + s / 6 * (dl(a, c) * dl(b, d) - dl(a, d) * dl(b, c)))
    return [[W(*p, *q) for q in PAIRS] for p in PAIRS], Ric, s
# the pseudoscalar split on the labels: generators e_0..e_3 = labels 1, 2, 4, 8; the bivector e_a e_b = label (1<<a)|(1<<b) with a sign
ALG = Alg(sig(4, 0)); PS = {15: Fr(1)}
def blade(p):
    a, b = p; mv = ALG.mul({1 << a: Fr(1)}, {1 << b: Fr(1)}); return mv
def star_matrix_bit():
    """the matrix of left multiplication by e_0123 on the bivector basis, by the bit rule"""
    cols = []
    for p in PAIRS:
        img = ALG.mul(PS, blade(p)); col = []
        for q in PAIRS:
            bq = blade(q); (lab, sg), = bq.items(); col.append(img.get(lab, Fr(0)) / sg)
        cols.append(col)
    return [[cols[j][i] for j in range(6)] for i in range(6)]
def mat_mul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def mat_add(A, B, cb=1): return [[A[i][j] + cb * B[i][j] for j in range(len(A[0]))] for i in range(len(A))]
def mat_scal(A, c): return [[c * A[i][j] for j in range(len(A[0]))] for i in range(len(A))]
def mat_zero(A): return all(v == 0 for r in A for v in r)
ID6 = [[Fr(int(i == j)) for j in range(6)] for i in range(6)]
STAR = star_matrix_bit()
chk('bit', mat_mul(STAR, STAR) == ID6 and all(STAR[i][j] == 0 for i in range(6) for j in range(6) if abs(i - j) != 3) and all(STAR[i][(i + 3) % 6] == STAR[(i + 3) % 6][i] for i in range(6)),
    'cone.O2: on the labels of Cl(4,0) the pseudoscalar e_0123 maps each bivector label to its complement (01 <-> 23, 02 <-> 31, 03 <-> 12), squares to +1 by the bit rule: the Hodge star of Lambda^2, with the two halves P+- = (1 +- e_0123)/2')
PPLUS = mat_scal(mat_add(ID6, STAR), Fr(1, 2)); PMINUS = mat_scal(mat_add(ID6, STAR, -1), Fr(1, 2))

head('O2. the family on the labels: the frame curvature, Einstein, the pseudoscalar split of the Weyl operator')
BETAS = [Fr(1, 2), Fr(1), Fr(3, 2), Fr(1, 3), Fr(7, 4), Fr(1, 10), Fr(19, 10)]
TS = [Fr(11, 10), Fr(3, 2), Fr(2), Fr(3), Fr(7)]
ok_ein = True; ok_half = True; ok_spec = True; ok_wform = True; ok_w2 = True; half_seen = set(); spec_sign = set()
for beta in BETAS:
    lam = Fr(3, 2) * beta ** 2 * (2 - beta)
    for t0 in TS:
        cv = frame_curvature(beta, t0); R = riemann_from(cv); Wm, Ric, s = weyl_operator(R)
        ok_ein &= all(Ric[i][j] == (lam if i == j else 0) for i in range(4) for j in range(4))
        # the Einstein shortcut W = R - (s/12) Id on Lambda^2 agrees with the general formula
        Rop = [[R(*p, *q) for q in PAIRS] for p in PAIRS]
        ok_wform &= Wm == mat_add(Rop, ID6, -s / 12) if FAULT != 'NOCONF' else True
        Wp = mat_mul(mat_mul(PPLUS, Wm), PPLUS); Wmn = mat_mul(mat_mul(PMINUS, Wm), PMINUS); mixed = mat_mul(mat_mul(PPLUS, Wm), PMINUS)
        zp, zm = mat_zero(Wp), mat_zero(Wmn)
        if zp != zm: half_seen.add('P+' if zp else 'P-')
        ok_half &= (zp != zm) and mat_zero(mixed)
        # the surviving half, eigenvalue eps of e_0123, in the paired basis v_i = e_i + eps STAR_i e_{i+3} (i = 01, 02, 03): sigma 2 D1 diag(1, 1, -2)
        D1 = cv['D1']; eps = -1 if zp else 1; Wsurv = Wmn if zp else Wp; kap = [eps * STAR[i + 3][i] for i in range(3)]
        for sg in (1, -1):
            good = True
            for i in range(3):
                for j in range(3):
                    val = (Wsurv[i][j] + kap[j] * Wsurv[i][j + 3] + kap[i] * Wsurv[i + 3][j] + kap[i] * kap[j] * Wsurv[i + 3][j + 3]) / 2
                    want = sg * ((2 * D1 if i < 2 else -4 * D1) if i == j else Fr(0))
                    good &= val == want
            if good: spec_sign.add(sg)
        ok_spec &= len(spec_sign) == 1
        c0 = 1 - beta
        ok_w2 &= sum(Wsurv[i][j] ** 2 for i in range(6) for j in range(6)) == 24 * D1 ** 2 == Fr(3, 2) * beta ** 6 * ((t0 ** 2 + c0) / (t0 ** 2 - c0)) ** 6
chk('bit', ok_ein, 'cone.O2: Ricci = lambda delta with lambda = 3 beta^2 (2 - beta)/2 exactly, at %d rational beta in (0, 2) x %d rational t = e^s > 1: the family is Einstein with the constant the paper gives (read)' % (len(BETAS), len(TS)))
chk('bit', ok_wform, 'cone.O2: the general Weyl formula and the Einstein shortcut W = R - (s/12) on Lambda^2 agree, exactly')
chk('bit', ok_half and len(half_seen) == 1, 'cone.O2: the pseudoscalar split by the bit rule: one half of the Weyl operator vanishes exactly at every point (the half %s of left multiplication by e_0123 in the frame order (ds, sigma_1, sigma_2, sigma_3); the paper\'s orientation of CP^2, tau = +1, calls the surviving half self-dual), the mixed block too' % (''.join(sorted(half_seen)) or '?'))
chk('bit', ok_spec, 'cone.O2: the surviving half is %s2 D_1 diag(1, 1, -2) on the paired bivectors (e01, e02, e03 paired with their complements), D_1 = R_2301 = (c/b)\'/(ab): trace-free, one repeated eigenvalue (the mark of an Einstein metric conformal to a Kaehler one)' % ('' if spec_sign == {1} else '-' if spec_sign == {-1} else '?'))
chk('bit', ok_w2, 'cone.O2: |W+|^2 = 24 D_1^2 = (3 beta^6/2) ((t^2 + c_0)/(t^2 - c_0))^6 exactly, c_0 = 1 - beta (3/2 at beta = 1: Fubini-Study with s = 6)')

# ================================================================================================ O3. the integrals, exactly
def poly_mul(p, q):
    out = [Fr(0)] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q): out[i + j] += a * b
    return out
def poly_shift(p, c):
    """coefficients of p(u - c) in powers of u, i.e. p(s) with s = u - c"""
    out = [Fr(0)]
    for k in range(len(p) - 1, -1, -1): out = poly_mul(out, [-c, Fr(1)]); out[0] += p[k]
    while len(out) > 1 and out[-1] == 0: out.pop()
    return out
def int_rational(p, c, m):
    """int_1^inf p(s) / (s + c)^m ds, exactly, for a polynomial p of degree <= m - 2 (no logarithm): u = s + c"""
    q = poly_shift(p, c); assert len(q) - 1 <= m - 2, 'a logarithm would appear'
    u0 = 1 + c; return sum(q[k] * u0 ** (k - m + 1) / (m - k - 1) for k in range(len(q)))
def exact_integrals(beta):
    """(Vol, int |W+|^2) / pi^2 as rationals: the volume form 8 pi^2 f^2 V sinh^2 s ds = (16 pi^2 / beta^3)(u - c0)(u - 1)/(u + c0)^4 du, u = t^2"""
    beta = Fr(beta); c0 = 1 - beta
    vol = 16 / beta ** 3 * int_rational(poly_mul([-c0, Fr(1)], [Fr(-1), Fr(1)]), c0, 4)
    w2 = 16 / beta ** 3 * Fr(3, 2) * beta ** 6 * int_rational(poly_mul(poly_mul([c0, Fr(1)], [c0, Fr(1)]), [Fr(-1), Fr(1)]), -c0, 5)
    return vol, w2
def vol_closed(beta):
    beta = Fr(beta); return Fr(8, 3) * (4 - beta) / (beta ** 3 * (2 - beta) ** (1 if FAULT == 'WRONGVOL' else 2))
head('O3. the integrals over CP^2, exactly, and the theorems closing on the family')
BETAS12 = [Fr(k, 10) for k in (1, 2, 3, 5, 7, 10, 11, 13, 15, 17, 18, 19)]
ok_vol = True; ok_57 = True; ok_21 = True; ok_22 = True; ok_42 = True; ok_43 = True
for beta in BETAS12:
    vol, w2 = exact_integrals(beta); sc = 6 * beta ** 2 * (2 - beta)
    ok_vol &= vol == vol_closed(beta)
    ok_57 &= w2 == 4 * (2 + beta ** 2)
    # the measure factor against the jets: f^2 V sinh^2 at t: equals (2/beta^3) t (u - c0)(u - 1)/(u + c0)^4 * (du/ds = 2 t^2)/t ... checked as values
    m = family(beta, Fr(3, 2)); c0 = 1 - beta; u = Fr(9, 4)
    ok_vol &= (m['f'] * m['f'] * m['V'] * m['sh'] * m['sh']).v == 2 / beta ** 3 * (u - c0) * (u - 1) / (u + c0) ** 4 * (2 * u)
    chi_defect = (Fr(3) - (1 - beta) * 2) if FAULT != 'NOCONE' else Fr(3)
    tau_defect = (Fr(1) - (1 - beta ** 2) / 3) if FAULT not in ('NOCONE', 'NOSQUARE') else (Fr(1) - (1 - beta) / 3 if FAULT == 'NOSQUARE' else Fr(1))
    ok_21 &= chi_defect == 1 + 2 * beta == Fr(1, 8) * (sc ** 2 / 24 * vol + w2)
    ok_22 &= tau_defect == (2 + beta ** 2) / 3 == Fr(1, 12) * w2
    ok_42 &= P(3, 1, 2, 1, beta, 1) == (2 + beta) ** 2 == Fr(1, 4) * (2 * w2 + sc ** 2 / 24 * vol)
    ok_43 &= P(3, 1, 2, 1, beta, -1) == beta * (4 - beta) == Fr(1, 4) * (sc ** 2 / 24 * vol) > 0
chk('bit', ok_vol, 'cone.O3: Vol(CP^2, g) = (8 pi^2/3)(4 - beta)/(beta^3 (2 - beta)^2) exactly at 12 rational beta (the antiderivative of the volume form, a rational function of u = e^{2s}; the measure factor checked against the jets)')
chk('bit', ok_57, 'cone.O3: int |W+|^2 dmu = 4 pi^2 (2 + beta^2) exactly at the 12 beta: the paper\'s (5.7), (1/12 pi^2) int |W+|^2 = (2 + beta^2)/3, from our curvature')
chk('bit', ok_21, 'cone.O3: Theorem 2.1 closes on the family: chi(CP^2) - (1 - beta) chi(CP^1) = 1 + 2 beta = (1/8 pi^2) int (s^2/24 + |W+|^2) dmu, exactly (s = 6 beta^2 (2 - beta), W- = 0, r0 = 0)')
chk('bit', ok_22, 'cone.O3: Theorem 2.2 closes on the family: tau(CP^2) - (1 - beta^2)[CP^1]^2/3 = (2 + beta^2)/3 = (1/12 pi^2) int |W+|^2 dmu, exactly')
chk('bit', ok_42 and ok_43, 'cone.O3: Theorem 4.1 on the family: the slack of (4.2) is (2 + beta)^2 = (1/4 pi^2) int (2 |W+|^2 + s^2/24), the slack of (4.3) is beta (4 - beta) = (1/4 pi^2) int s^2/24 > 0: both strict for 0 < beta < 2, the metric is not hyper-Kaehler (s != 0), and the (4.3) slack vanishes only in the Taub-NUT limit beta -> 0')
if FAULT is None:
    chk('ctl', True, 'cone: controls: NOSQUARE and NOCONE change the table and open the theorems; NOCONF (g_0) keeps the vanishing half and loses Einstein; WRONGVOL breaks the volume; CARTAN breaks Einstein and the agreement with the finite differences')

# ================================================================================================ O4. the standard route: numpy
head('O4. the standard route: the Riemann tensor of the coordinate metric by finite differences, the Hodge star by epsilon, quadrature')
def metric_np(beta, x):
    """g_mu nu at x = (s, theta, phi, psi), the coordinate form of (5.4)-(5.6): sigma_1^2 + sigma_2^2 = (d theta^2 + sin^2 theta d phi^2)/4,
    sigma_3 = (d psi + cos theta d phi)/2"""
    s, th = x[0], x[1]
    V = 1 / beta + 1 / math.expm1(2 * s)
    f = 1.0 if FAULT == 'NOCONF' else 4 / beta / ((2 - beta) * math.cosh(s) + beta * math.sinh(s)) ** 2
    g = np.zeros((4, 4))
    g[0, 0] = f * V
    g[1, 1] = f * V * math.sinh(s) ** 2
    g[2, 2] = f * V * math.sinh(s) ** 2 * math.sin(th) ** 2 + f / V * math.cos(th) ** 2 / 4
    g[3, 3] = f / V / 4
    g[2, 3] = g[3, 2] = f / V * math.cos(th) / 4
    return g
def d4(fun, x, mu, h):
    e = np.zeros(4); e[mu] = h
    return (-fun(x + 2 * e) + 8 * fun(x + e) - 8 * fun(x - e) + fun(x - 2 * e)) / (12 * h)
def christoffel(beta, x, h=1e-3):
    g = metric_np(beta, x); gi = np.linalg.inv(g); dg = np.array([d4(lambda y: metric_np(beta, y), x, mu, h) for mu in range(4)])   # dg[mu, a, b]
    G = np.zeros((4, 4, 4))
    for l in range(4):
        for m in range(4):
            for n in range(4):
                G[l, m, n] = 0.5 * sum(gi[l, r] * (dg[m, r, n] + dg[n, r, m] - dg[r, m, n]) for r in range(4))
    return G
def riemann_np(beta, x, h=1e-3):
    """R_{rho sigma mu nu} = g_{rho alpha} (d_mu Gamma^alpha_{nu sigma} - d_nu Gamma^alpha_{mu sigma} + Gamma Gamma - Gamma Gamma)"""
    G = christoffel(beta, x); dG = np.array([d4(lambda y: christoffel(beta, y), x, mu, h) for mu in range(4)])   # dG[mu, l, a, b]
    Rup = np.zeros((4, 4, 4, 4))
    for r in range(4):
        for s in range(4):
            for m in range(4):
                for n in range(4):
                    Rup[r, s, m, n] = dG[m, r, n, s] - dG[n, r, m, s] + sum(G[r, m, l] * G[l, n, s] - G[r, n, l] * G[l, m, s] for l in range(4))
    g = metric_np(beta, x)
    return np.einsum('ra,asmn->rsmn', g, Rup)
def coframe_np(beta, x):
    """E^A_mu with e^A = E^A_mu dx^mu: e0 = a ds, e1 = b d theta/2, e2 = -b sin theta d phi/2, e3 = c (d psi + cos theta d phi)/2 (the sign of e2
    makes d sigma_3 = +2 sigma_1 sigma_2, the orientation of the structure equations; sigma_1^2 + sigma_2^2 = (d theta^2 + sin^2 theta d phi^2)/4)"""
    s, th = x[0], x[1]
    V = 1 / beta + 1 / math.expm1(2 * s); f = 1.0 if FAULT == 'NOCONF' else 4 / beta / ((2 - beta) * math.cosh(s) + beta * math.sinh(s)) ** 2
    a = math.sqrt(f * V); b = 2 * a * math.sinh(s); c = math.sqrt(f / V)
    E = np.zeros((4, 4)); E[0, 0] = a; E[1, 1] = b / 2; E[2, 2] = -b * math.sin(th) / 2; E[3, 3] = c / 2; E[3, 2] = c * math.cos(th) / 2
    return E
def frame_riemann_np(beta, x):
    R = riemann_np(beta, x); Ei = np.linalg.inv(coframe_np(beta, x))     # Ei[mu, A]: the frame vectors
    return np.einsum('abcd,ap,bq,cr,ds->pqrs', R, Ei, Ei, Ei, Ei)
def star_np():
    eps = np.zeros((4, 4, 4, 4))
    for perm in itertools.permutations(range(4)):
        sgn = 1
        for i in range(4):
            for j in range(i + 1, 4):
                if perm[i] > perm[j]: sgn = -sgn
        eps[perm] = sgn
    S = np.zeros((6, 6))
    for i, (a, b) in enumerate(PAIRS):
        for j, (c, d) in enumerate(PAIRS): S[i, j] = eps[a, b, c, d]
    return S
STAR_NP = star_np()
ok_fd = True; ok_ric = True; ok_star = True; maxdev = 0.0; maxric = 0.0; maxhalf = 0.0
for beta_q in (Fr(1, 2), Fr(1), Fr(8, 5)):
    beta = float(beta_q); lam = 1.5 * beta ** 2 * (2 - beta)
    for s0 in (0.4, 0.9, 1.7):
        x = np.array([s0, 1.1, 0.3, 0.7]); Rf = frame_riemann_np(beta, x)
        cv = frame_curvature(beta_q, Fr(math.exp(s0)).limit_denominator(10 ** 12))
        # the exact closed forms at the (rounded) rational t: compare the six numbers
        Rex = riemann_from(cv)
        dev = max(abs(Rf[a, b, c, d] - float(Rex(a, b, c, d))) for a in range(4) for b in range(4) for c in range(4) for d in range(4))
        maxdev = max(maxdev, dev); ok_fd &= dev < 1e-6
        Ric = np.einsum('aibi->ab', Rf); r = np.max(np.abs(Ric - lam * np.eye(4))); maxric = max(maxric, r); ok_ric &= r < 1e-6
        s = np.trace(Ric); Rop = np.array([[Rf[a, b, c, d] for (c, d) in PAIRS] for (a, b) in PAIRS])
        Wop = Rop - (s / 12) * np.eye(6)   # the Einstein shortcut (the general formula is checked exactly above)
        if FAULT == 'NOCONF':
            # the general Weyl formula, numerically
            dl = np.eye(4)
            Wt = np.array([[Rf[a, b, c, d] - 0.5 * (dl[a, c] * Ric[b, d] - dl[a, d] * Ric[b, c] - dl[b, c] * Ric[a, d] + dl[b, d] * Ric[a, c]) + s / 6 * (dl[a, c] * dl[b, d] - dl[a, d] * dl[b, c])
                            for (c, d) in PAIRS] for (a, b) in PAIRS]); Wop = Wt
        Pp = (np.eye(6) + STAR_NP) / 2; Pm = (np.eye(6) - STAR_NP) / 2
        hp, hm = np.max(np.abs(Pp @ Wop @ Pp)), np.max(np.abs(Pm @ Wop @ Pm))
        van = min(hp, hm); maxhalf = max(maxhalf, van); ok_star &= van < 1e-6 and max(hp, hm) > 1e-3
chk('bit==std', ok_fd, 'cone.O4: the Riemann tensor of the coordinate metric by finite differences (4-point stencils, h = 1e-3), carried to the orthonormal frame, equals the closed forms from the structure equations at 3 beta x 3 points, all 256 components (max deviation %.1e)' % maxdev)
chk('std', ok_ric, 'cone.O4: numpy: Ricci = lambda delta to %.1e at the 9 points, lambda = 3 beta^2 (2 - beta)/2' % maxric)
chk('std', ok_star, 'cone.O4: numpy: the Hodge star from the Levi-Civita symbol: one half of the Weyl operator vanishes (max %.1e), the other does not' % maxhalf)
# quadrature of the integrals: s in (0, 40) (the integrand decays like e^{-2s}; the tail beyond 40 is below 1e-30), Gauss-Legendre on x in (0, 1)
xg, wg = np.polynomial.legendre.leggauss(400); xg = (xg + 1) / 2; wg = wg / 2; SMAX = 40.0
def quad_vol(beta):
    tot = 0.0; totw = 0.0
    for x, w in zip(xg, wg):
        s = SMAX * x; ds = SMAX
        V = 1 / beta + 1 / math.expm1(2 * s); f = 4 / beta / ((2 - beta) * math.cosh(s) + beta * math.sinh(s)) ** 2
        dens = 8 * math.pi ** 2 * f * f * V * math.sinh(s) ** 2 * ds
        c0 = 1 - beta; u = math.exp(2 * s); w2 = 1.5 * beta ** 6 * ((u + c0) / (u - c0)) ** 6
        tot += w * dens; totw += w * dens * w2
    return tot, totw
ok_q = True; mq = 0.0
for beta in BETAS12:
    b = float(beta); vol, w2 = exact_integrals(beta); qv, qw = quad_vol(b)
    ev = abs(qv / math.pi ** 2 - float(vol)) / float(vol); ew = abs(qw / math.pi ** 2 - float(w2)) / float(w2); mq = max(mq, ev, ew)
    ok_q &= ev < 1e-8 and ew < 1e-8 and abs(qv / math.pi ** 2 - float(vol_closed(beta))) / float(vol) < 1e-8
chk('std', ok_q, 'cone.O4: Gauss-Legendre quadrature (400 nodes) of the volume and of int |W+|^2 at the 12 beta agrees with the exact values and the closed forms to %.1e' % mq)
# the cone angle along the line (s -> infinity): circumference of the sigma_3-circle 2 pi c(s) over 2 pi x the proper distance int_s^inf a
def cone_ratio(beta, s0):
    V = lambda s: 1 / beta + 1 / math.expm1(2 * s); f = lambda s: 4 / beta / ((2 - beta) * math.cosh(s) + beta * math.sinh(s)) ** 2
    c = math.sqrt(f(s0) / V(s0))
    tot = 0.0
    for x, w in zip(xg, wg):
        s = s0 + SMAX * x; ds = SMAX; tot += w * math.sqrt(f(s) * V(s)) * ds
    return c / tot
ok_cone = True; worst = 0.0
for beta in (0.5, 1.0, 1.6):
    r6, r9 = cone_ratio(beta, 6.0), cone_ratio(beta, 9.0)
    ok_cone &= abs(r9 - beta) < 1e-4 and abs(r9 - beta) <= abs(r6 - beta) + 1e-12; worst = max(worst, abs(r9 - beta))
chk('std', ok_cone, 'cone.O4: the cone angle: the circumference of the sigma_3-circle over 2 pi times the proper distance to the line tends to beta (at s = 9 within %.1e, closer than at s = 6): an edge-cone of angle 2 pi beta along the line, as the paper says' % worst)
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('CONE-OBSTRUCTIONS')
