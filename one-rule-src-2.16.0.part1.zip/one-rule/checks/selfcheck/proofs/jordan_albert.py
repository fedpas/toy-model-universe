#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""jordan_albert.py -- the Albert algebra h3(O) over the XOR (Cayley-Dickson) octonions and the matrix Jordan algebras and triples: f4, e6 as
the maps preserving det, e7 by the Kantor-Koecher-Tits construction, the 3-graded algebras of the matrix pairs, and the joint Peirce spaces of
frames of orthogonal minimal tripotents.

Statements (check ids jrd·1 .. jrd·17).
 A. h3(O) (27 coordinates, octonion products e_a e_b = s(a,b) e_(a xor b) from Cayley-Dickson) is a Jordan algebra; its cubic form det
    = d1 d2 d3 - d1|x23|^2 - d2|x31|^2 - d3|x12|^2 + 2 Re(x12 x23 x31) satisfies x^3 - T x^2 + S x - det 1 = 0. Der h3(O) has dimension 52;
    the multiplications L_a by the 26 traceless a add 26; the 78-dimensional span is closed under the commutator and is exactly the Lie algebra
    of all linear maps of the 27 that preserve det (the full stabiliser of the cubic form in gl(27)); 27 = 1 + 26 under f4, the 27 is
    irreducible under the 78; on a Cartan subalgebra the roots of the 78 form E6 (as the 72 roots of E6 built from bit labels) and those of the
    52 form F4; Killing signatures (26, 52) and (0, 52).                                                                    (jrd·1 .. jrd·6)
 B. Kantor-Koecher-Tits: for the Jordan pair (h3(O), h3(O)) the space V+ + instr + V- with [x+, y-] = (D(x,y), -D(y,x)) is a Lie algebra
    (the pair identity and the Jacobi identity on random elements), instr = L_J + Der = 79, dimension 133, graded by E = (1, -1) with
    eigenvalues 1, 0, -1 (27, 79, 27); it is simple, so it is e7 (the only simple Lie algebra of dimension 133: classification recalled), with
    Killing signature (54, 79): e7(-25). The same construction for h_n(R), h_n(C), h_n(H) and the spin factors gives algebras with the
    dimensions and Killing signatures of sp(2n,R), su(n,n), so*(4n) and so(N,2) (the first, second and fourth also from their matrix
    realisations); the skew pair A_m(R) gives so(m,m) with g_0 = gl(m) and the rectangular pair M_(p,q)(R) gives sl(p+q,R) (explicit block
    maps, exact); h2(C) = R + R^3 as Jordan algebras, so the two 15-dimensional algebras (su(2,2) and so(4,2)) are isomorphic.
                                                                                                                             (jrd·7 .. jrd·11)
 C. Peirce: for frames of orthogonal minimal tripotents of M_(p,q)(R), A_n(R), Sym_n(R), h_n(C), h_n(H), the spin factors and h3(O)
    (compact and split), the joint Peirce spaces V_ij have dimensions 1, a, b (V_00 = 0) and dim V = r + a r(r-1)/2 + b r, with (r, a, b) as in
    Loos's table (recalled); on the roots of E8, frames of orthogonal roots in the grade-1 roots of e7, e6, so(10), sl(5) give (3, 8, 0),
    (2, 6, 4), (2, 4, 2), (2, 2, 1) (type V from the roots).                                                                (jrd·12 .. jrd·15)
 D. In f4: the derivations preserving A = h2(O) (36) and those preserving B = h3(C) (16) meet in 12, with a one-dimensional centre and an
    11-dimensional derived algebra.                                                                                           (jrd·16 .. jrd·17)
[bit]  exact integers and Fractions: structure constants of h3(O), exact nullspaces (rank over F_p of the normal matrix as the upper bound of
       the nullity, rational solutions checked in integers as the lower bound), exact identities on all basis pairs, exact random triples,
       Lagrange's diagonalisation over Q for Killing signatures, exact Fraction ranks for the Peirce spaces, exact block maps into gl(n).
[std]  numpy: roots as joint eigenvalues of ad on a Cartan subalgebra, Gram matrices against the E6 roots from bit labels, Cartan matrices up
       to a permutation; Killing signatures of sp(2n,R), su(n,n), so(N,2) from their matrix realisations; the TKK algebras by least squares;
       Peirce counts of frames of orthogonal roots on the E8 roots from bit labels (integers).
[ctl]  an L_a among the derivations; the identity L_1 (a wrong trace) in the e6 basis; det without its term 2 Re(x12 x23 x31); one octonion
       sign flipped; the TKK bracket with the opposite sign on V-, the non-symmetrised triple x y z, V- with the negated product; colinear
       tripotents, a non-minimal tripotent, an incomplete frame, a non-tripotent; the Peirce 1/2 space of E11 in h3(O) with the restricted
       product (its tripotent u has an 8-dimensional V_2; no frame of the type V kind is found there).
       Each wrong version of a main line is a --fault option (the run must then end with FAILS).
Scope. Lie algebras over Q (hence over C by base change of rational linear systems); the octonions are those of the package (Cayley-Dickson
       with mu = -1, the split ones with mu = +1 in the last doubling). The classification theorems (Cartan-Killing, Loos, Tits-Koecher-Kantor,
       Cartan's list of Hermitian symmetric spaces) are recalled, not computed. Nothing here is a statement about nature. The script builds no
       Forms, Lie or Grav object (standard library, numpy, scipy).
Run:   python3 selfcheck/proofs/jordan_albert.py [--fault NONDER|TRACE|DETWRONG|OCTSIGN|TKKSIGN|TKKNOSYM|COLINEAR|NONMIN]
       (from checks/; also from its own folder, and under -I -B)"""
import sys, itertools, math
from fractions import Fraction as F
from collections import Counter
import numpy as np
import scipy.linalg
sys.dont_write_bytecode = True

FAILS = []
NOK = [0]
def chk(tag, cid, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s %s' % ('ok  ' if cond else 'FAIL', tag, cid, msg), flush=True)
    if cond: NOK[0] += 1
    else: FAILS.append('[%s] %s' % (tag, cid))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % (NOK[0], len(FAILS)), flush=True)
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'JRDA'
FAULT_NAMES = ('NONDER', 'TRACE', 'DETWRONG', 'OCTSIGN', 'TKKSIGN', 'TKKNOSYM', 'COLINEAR', 'NONMIN')
FAULT = None
if '--fault' in sys.argv:
    _i = sys.argv.index('--fault')
    FAULT = sys.argv[_i + 1] if _i + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)

# ===================================================================================== exact linear algebra
def rank_mod_p(A, p=2147483647):
    """rank of an integer matrix over F_p (a lower bound for its rank over Q)"""
    A = np.array(A, dtype=np.int64) % p
    m, n = A.shape; r = 0
    for c in range(n):
        if r == m: break
        nz = np.nonzero(A[r:, c])[0]
        if len(nz) == 0: continue
        pv = r + int(nz[0])
        if pv != r: A[[r, pv]] = A[[pv, r]]
        A[r] = (A[r] * pow(int(A[r, c]), p - 2, p)) % p
        below = r + 1 + np.nonzero(A[r + 1:, c])[0]
        if len(below): A[below] = (A[below] - (A[below, c][:, None] * A[r][None, :]) % p) % p
        r += 1
    return r
def null_exact(Mint, dens=(1, 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64, 96, 128)):
    """exact nullspace of an integer matrix M: the upper bound n - rank_p(M^T M) (rank over F_p <= rank over Q = rank M), and a rational basis
    found in floats, rounded, and checked exactly (M B = 0 in integers, B = D x identity on pivot rows)"""
    Mf = np.asarray(Mint, dtype=np.float64); G = Mf.T @ Mf; n = G.shape[0]
    ub = n - rank_mod_p(np.rint(G).astype(np.int64))
    if ub == 0: return np.zeros((n, 0), dtype=np.int64), 1, 0, True, []
    w, V = np.linalg.eigh(G); N = V[:, :ub]
    P = scipy.linalg.qr(N.T, pivoting=True)[2]; pv = sorted(int(x) for x in P[:ub])
    B = N @ np.linalg.inv(N[pv, :])
    for D in dens:
        BD = B * D
        if np.abs(BD - np.rint(BD)).max() < 1e-7:
            Bi = np.rint(BD).astype(np.int64)
            ok = (not np.any(np.asarray(Mint, dtype=np.int64) @ Bi)) and np.array_equal(Bi[pv], D * np.eye(ub, dtype=np.int64))
            return Bi, D, ub, ok, pv
    return None, None, ub, False, pv
def frank(rows):
    """rank over Q of a list of rows (integers or Fractions), exact"""
    M = [[F(v) for v in r] for r in rows]; M = [r for r in M if any(r)]
    if not M: return 0
    rk, nc = 0, len(M[0])
    for c in range(nc):
        piv = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]; pr = M[rk]
        for i in range(rk + 1, len(M)):
            if M[i][c] != 0:
                f = M[i][c] / pr[c]; M[i] = [a - f * b for a, b in zip(M[i], pr)]
        rk += 1
        if rk == len(M): break
    return rk
def fnull(rows, n):
    """an exact basis (Fractions) of {x : r.x = 0}; rows as lists of length n"""
    M = [[F(v) for v in r] for r in rows]; piv = []; rk = 0
    for c in range(n):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; f0 = M[rk][c]; M[rk] = [v / f0 for v in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(n) if c not in piv]; out = []
    for fc in free:
        v = [F(0)] * n; v[fc] = F(1)
        for r_, pc_ in enumerate(piv): v[pc_] = -M[r_][fc]
        out.append(v)
    return out
def inertia_exact(K):
    """(positive, negative, zero) of a rational symmetric matrix by Lagrange's method over Q (congruence, exact)"""
    A = [[F(x) for x in row] for row in K]; n = len(A); act = list(range(n)); pos = neg = 0
    while act:
        pv = next((i for i in act if A[i][i] != 0), None)
        if pv is None:
            pr = next(((i, j) for i in act for j in act if i < j and A[i][j] != 0), None)
            if pr is None: break
            i, j = pr
            for t in range(n): A[i][t] += A[j][t]
            for t in range(n): A[t][i] += A[t][j]
            pv = i
        p = A[pv][pv]; pos += p > 0; neg += p < 0; act.remove(pv); rowp = A[pv]
        for i in act:
            if A[i][pv] != 0:
                f = A[i][pv] / p; Ai = A[i]
                for t in act: Ai[t] -= f * rowp[t]
    return pos, neg, n - pos - neg
def sig_num(K, tol=1e-6):
    ev = np.linalg.eigvalsh((K + K.T) / 2); sc = max(1.0, np.abs(ev).max())
    return int((ev > tol * sc).sum()), int((ev < -tol * sc).sum()), float(np.abs(ev).min() / sc)

# ===================================================================================== composition algebras and Jordan algebras
def cd_conj(x):
    if len(x) == 1: return list(x)
    h = len(x) // 2
    return cd_conj(x[:h]) + [-v for v in x[h:]]
def cd_mul(x, y, mus):
    """(a,b)(c,d) = (a c + mu conj(d) b, d a + b conj(c)), mu the parameter of the last doubling"""
    if len(x) == 1: return [x[0] * y[0]]
    h = len(x) // 2; mu = mus[-1]; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    first = [u + mu * v for u, v in zip(cd_mul(a, c, mus[:-1]), cd_mul(cd_conj(d), b, mus[:-1]))]
    second = [u + v for u, v in zip(cd_mul(d, a, mus[:-1]), cd_mul(b, cd_conj(c), mus[:-1]))]
    return first + second
def cd_table(mus):
    d = 2 ** len(mus); S = np.zeros((d, d), dtype=np.int64)
    for a in range(d):
        for b in range(d):
            r = cd_mul([int(t == a) for t in range(d)], [int(t == b) for t in range(d)], mus); nz = [t for t in range(d) if r[t]]
            assert nz == [a ^ b] and abs(r[a ^ b]) == 1; S[a, b] = r[a ^ b]
    return S
OS_O = cd_table((-1, -1, -1)); OS_S = cd_table((-1, -1, 1)); OS_H = cd_table((-1, -1)); OS_C = cd_table((-1,)); OS_R = np.ones((1, 1), dtype=np.int64)
def herm(n, OS, pairs=None):
    """h_n(K) for the algebra with table OS: integer tensor JT[i,j] = coordinates of e_i e_j + e_j e_i = 2 (e_i o e_j)"""
    d = OS.shape[0]
    if pairs is None: pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    dim = n + d * len(pairs)
    OT = np.zeros((d, d, d), dtype=np.int64)
    for a in range(d):
        for b in range(d): OT[a, b, a ^ b] = OS[a, b]
    cj = np.array([1] + [-1] * (d - 1), dtype=np.int64)
    def mat(v):
        M = np.zeros((n, n, d), dtype=np.int64)
        for i in range(n): M[i, i, 0] = v[i]
        for t, (i, j) in enumerate(pairs):
            x = np.asarray(v[n + t * d: n + (t + 1) * d], dtype=np.int64); M[i, j] = x; M[j, i] = cj * x
        return M
    def mul(X, Y):
        Z = np.zeros((n, n, d), dtype=np.int64)
        for i in range(n):
            for j in range(n):
                for k in range(n): Z[i, j] += np.einsum('a,b,abc->c', X[i, k], Y[k, j], OT)
        return Z
    def coords(M): return np.array([M[i, i, 0] for i in range(n)] + [c for (i, j) in pairs for c in M[i, j]], dtype=np.int64)
    E = np.eye(dim, dtype=np.int64); JT = np.zeros((dim, dim, dim), dtype=np.int64); ok = True
    for i in range(dim):
        for j in range(i, dim):
            X, Y = mat(E[i]), mat(E[j]); Z = mul(X, Y) + mul(Y, X)
            ok &= all(np.array_equal(Z[b, a], cj * Z[a, b]) for a in range(n) for b in range(n)) and not np.any(Z[range(n), range(n), 1:])
            JT[i, j] = JT[j, i] = coords(Z)
    return dict(JT=JT, ok=ok, mat=mat, mul=mul, dim=dim, n=n, d=d, OT=OT, cj=cj, pairs=pairs)
def spin_factor(N):
    """R 1 + R^(N-1) with e_i o e_j = delta_ij 1 (Euclidean); JT = 2 x the product"""
    JT = np.zeros((N, N, N), dtype=np.int64); JT[0, 0, 0] = 2
    for i in range(1, N): JT[0, i, i] = JT[i, 0, i] = 2; JT[i, i, 0] = 2
    return JT
def P2(u, v, JT): return np.einsum('i,j,ijk->k', u, v, JT)
def L2(a, JT): return np.einsum('i,ijk->kj', a, JT)                      # column j = P2(a, e_j)
def D2(x, y, JT):
    """2 D(x, y) with D(x,y) z = {x y z} = 2((x o y) o z + (z o y) o x - (x o z) o y): L2(P2(x,y)) + [L2 x, L2 y]"""
    Lx, Ly = L2(x, JT), L2(y, JT)
    return L2(P2(x, y, JT), JT) + Lx @ Ly - Ly @ Lx
def jordan_ok(JT, rng, k=10, lo=-3, hi=4):
    n = JT.shape[0]; ok = True
    for _ in range(k):
        x, y = rng.integers(lo, hi, n), rng.integers(lo, hi, n)
        ok &= np.array_equal(P2(P2(P2(x, x, JT), y, JT), x, JT), P2(P2(x, x, JT), P2(y, x, JT), JT))
    return ok

# ===================================================================================== A. h3(O), its cubic form, f4 and e6
head('A. [bit] h3(O) on the XOR (Cayley-Dickson) octonions: the cubic form det, Der = f4 (52), e6 = Der + L(traceless) as the stabiliser of det (CAND-060)')
OSA = OS_O.copy()
if FAULT == 'OCTSIGN': OSA[3, 5] = -OSA[3, 5]                               # a wrong version: one sign of the product table flipped
ALB = herm(3, OSA, pairs=[(0, 1), (1, 2), (2, 0)]); JT = ALB['JT']; NJ = 27
E27 = np.eye(NJ, dtype=np.int64); ONE = np.array([1, 1, 1] + [0] * 24, dtype=np.int64)
rngA = np.random.default_rng(60)
jordA = jordan_ok(JT, rngA, 10)
nrm = lambda OS: np.array([1] + [-int(OS[a, a]) for a in range(1, OS.shape[0])], dtype=np.int64)
def det_direct(v, H, OS):
    M = H['mat'](v); s01, s12, s20 = M[0, 1], M[1, 2], M[2, 0]; nr = nrm(OS); q = lambda x: int(np.dot(nr, x * x))
    p = np.einsum('a,b,abc->c', np.einsum('a,b,abc->c', s01, s12, H['OT']), s20, H['OT'])
    return int(v[0]) * int(v[1]) * int(v[2]) - int(v[0]) * q(s12) - int(v[1]) * q(s20) - int(v[2]) * q(s01) + 2 * int(p[0])
def cubic_tensor(OS, with_re=True):
    """6 T, T the symmetric tensor with det(x) = sum T_ijk x_i x_j x_k; coordinates: d0, d1, d2, x01 (3..10), x12 (11..18), x20 (19..26)"""
    T6 = np.zeros((NJ, NJ, NJ), dtype=np.int64); nr = nrm(OS)
    def put(i, j, k, v):
        for p in set(itertools.permutations((i, j, k))): T6[p] += v
    put(0, 1, 2, 1)
    for dg, off in ((0, 11), (1, 19), (2, 3)):
        for b in range(8): put(dg, off + b, off + b, -2 * int(nr[b]))
    if with_re:
        for a in range(8):
            for b in range(8):
                c = a ^ b; put(3 + a, 11 + b, 19 + c, 2 * int(OS[a, b]) * int(OS[c, c]))
    return T6
T6 = cubic_tensor(OSA); T6w = cubic_tensor(OSA, with_re=False)
N6 = lambda x, T: int(np.einsum('i,j,k,ijk->', x, x, x, T))
SQ = lambda v, OS: (int(v[0]) * int(v[1]) + int(v[1]) * int(v[2]) + int(v[2]) * int(v[0])
                    - sum(int(np.dot(nrm(OS), np.asarray(v[s:s + 8]) ** 2)) for s in (3, 11, 19)))
okT = okCH = True
for _ in range(20):
    x = rngA.integers(-3, 4, NJ); N_ = det_direct(x, ALB, OSA)
    okT &= N6(x, T6) == 6 * N_
    x2 = P2(x, x, JT); lhs = P2(x2, x, JT) - 2 * int(x[:3].sum()) * x2 + 4 * SQ(x, OSA) * x - 4 * N_ * ONE
    okCH &= not np.any(lhs)
chk('bit', 'jrd·1', ALB['ok'] and jordA and all(np.array_equal(P2(ONE, E27[i], JT), 2 * E27[i]) for i in range(NJ)) and okT and okCH,
    'h3(O) with the Cayley-Dickson octonions (e_a e_b = s(a,b) e_(a xor b), exact integers): X o Y = (XY + YX)/2 is hermitian, has the unit 1 and satisfies the Jordan identity (x^2 y) x = x^2 (y x) '
    'for 10 random integer pairs (seed 60); det = d1 d2 d3 - d1|x23|^2 - d2|x31|^2 - d3|x12|^2 + 2 Re(x12 x23 x31) equals the symmetric cubic tensor T (6T integer) on 20 random elements and satisfies '
    'x^3 - T(x) x^2 + S(x) x - det(x) 1 = 0 exactly on all 20 (Cayley-Hamilton: det is the generic norm)')
# derivations (the system of e_ladder.py elad·21, rebuilt here)
pairsJ = [(i, j) for i in range(NJ) for j in range(i, NJ)]; ar27 = np.arange(NJ)
Mder = np.zeros((len(pairsJ) * NJ, NJ * NJ), dtype=np.int64)
for t, (i, j) in enumerate(pairsJ):
    for l in range(NJ):
        row = Mder[t * NJ + l]
        row[l * NJ:(l + 1) * NJ] += JT[i, j, :]
        row[ar27 * NJ + i] -= JT[:, j, l]
        row[ar27 * NJ + j] -= JT[i, :, l]
BD, DD, ubD, okD, PVD = null_exact(Mder)
DER = [BD[:, k].reshape(NJ, NJ) for k in range(BD.shape[1])] if okD else []
DERm = DER + ([L2(E27[3], JT)] if FAULT == 'NONDER' else [])                 # a wrong version: L_a put among the derivations
def is_der(X): return not np.any(Mder @ X.reshape(-1))
def dcoords(X):
    """coordinates of X in the derivation basis (pivot rows; dyadic values, exact in float64), and whether X lies in its span (BD X[pv] = DD X)"""
    v = np.asarray(X, dtype=np.float64).reshape(-1); c = v[PVD]
    return c / DD, np.array_equal(BD.astype(np.float64) @ c, DD * v)
L2E = [L2(E27[i], JT) for i in range(NJ)]
innr = [L2E[i] @ L2E[j] - L2E[j] @ L2E[i] for i in range(NJ) for j in range(i + 1, NJ)]
inn_in = all(dcoords(X)[1] for X in innr)
chk('bit', 'jrd·2', okD and ubD == 52 and DD in (1, 2, 4) and len(DERm) == 52 and all(is_der(Xm) for Xm in DERm) and inn_in
    and rank_mod_p(np.array([X.reshape(-1) for X in innr])) == 52,
    'Der h3(O): the %d x 729 integer system D(x o y) = Dx o y + x o Dy has nullity exactly %d (%d rational solutions checked in integers, denominator %s); '
    'the 351 inner derivations [L_x, L_y] of basis pairs lie in their span and span it (rank 52): f4 (as elad·21)' % (Mder.shape[0], ubD, len(DER), DD))
if len(DER) != 52 or not jordA: finish(STEP)                                # a wrong product table: nothing below is meaningful
# e6 = Der + L(traceless)
J0 = [E27[0] - E27[1], E27[1] - E27[2]] + [E27[k] for k in range(3, NJ)]
LJ0 = [L2(a, JT) for a in J0]
E6B = DER + LJ0 + ([L2(ONE, JT)] if FAULT == 'TRACE' else [])            # a wrong version: the identity (L_1, a wrong trace) in the basis
VEC6 = np.array([X.reshape(-1) for X in E6B])
nonder = not any(is_der(X) for X in LJ0)
r78 = rank_mod_p(VEC6)
def e6coords(X):
    """exact coordinates of X in DER + LJ0 (L part from X 1, the rest from the pivot rows); None if X is not in the span"""
    a = (X @ ONE).astype(np.float64)
    if a[:3].sum() != 0: return None
    a = a / 2; beta = np.array([a[0], -a[2]] + list(a[3:]))
    Y = X - sum(b * Lm for b, Lm in zip(beta, LJ0) if b)
    c, ok = dcoords(Y)
    return np.concatenate([c, beta]) if ok else None
cl_DD = all(e6coords(DER[i] @ DER[j] - DER[j] @ DER[i]) is not None for i in range(52) for j in range(i + 1, 52))
cl_DL = all(np.array_equal(DER[i] @ LJ0[m] - LJ0[m] @ DER[i], L2(DER[i] @ J0[m], JT)) for i in range(52) for m in range(26))
cl_LL = all(dcoords(LJ0[m] @ LJ0[q] - LJ0[q] @ LJ0[m])[1] for m in range(26) for q in range(m + 1, 26))
chk('bit', 'jrd·3', nonder and r78 == len(E6B) == 78 and cl_DD and cl_DL and cl_LL,
    'the 26 maps L_a (a traceless: e1 - e2, e2 - e3 and the 24 off-diagonal units) are not derivations; with the 52 derivations they span %d dimensions (rank mod p, exact); '
    'closed under the commutator, exactly on all basis pairs: [D, D\'] in Der (1326 pairs), [D, L_a] = L_(Da) (1352), [L_a, L_b] in Der (325): a 78-dimensional Lie algebra' % r78)
# the full stabiliser of det in gl(27)
def det_system(T):
    monos = list(itertools.combinations_with_replacement(range(NJ), 3)); rows = []
    for mo in monos:
        row = np.zeros(NJ * NJ, dtype=np.int64)
        for (i, j, l) in set(itertools.permutations(mo)): row[ar27 * NJ + l] += T[i, j, :]
        if row.any(): rows.append(row)
    return np.array(rows), len(monos)
TMAIN = T6w if FAULT == 'DETWRONG' else T6                                 # a wrong version: det without 2 Re(x12 x23 x31)
Mdet, nmono = det_system(TMAIN)
Gdet = (Mdet.astype(np.float64).T @ Mdet.astype(np.float64))
rdet = rank_mod_p(np.rint(Gdet).astype(np.int64))
pres = not np.any(Mdet.astype(np.float64) @ VEC6.T.astype(np.float64))
idnot = np.any(Mdet @ np.eye(NJ, dtype=np.int64).reshape(-1))
chk('bit', 'jrd·4', 729 - rdet == 78 and pres and idnot,
    'the Lie algebra of all linear maps X of the 27 with det(x + t Xx) = det(x) + O(t^2): the coefficients of the cubic polynomial det\'(x)[Xx] give %d integer equations on the 729 entries '
    '(one per monomial of degree 3 that occurs, of %d); nullity <= 729 - rank_p(normal matrix) = %d, and the 78 basis maps satisfy every equation exactly: the stabiliser of det is exactly '
    'Der + L(traceless), 78-dimensional (over Q, hence over C); the identity map L_1 is not in it (it scales det by 3)' % (Mdet.shape[0], nmono, 729 - rdet))
# 27 = 1 + 26 under f4; the 27 irreducible under e6 (commutants of two seeded random elements)
rngC = np.random.default_rng(27)
def commutant_dim(gens):
    M = np.vstack([np.kron(g, np.eye(NJ, dtype=np.int64)) - np.kron(np.eye(NJ, dtype=np.int64), g.T) for g in gens])
    _, _, ub, ok, _ = null_exact(M); return ub, ok
rf4 = [sum(int(c) * D for c, D in zip(rngC.integers(-2, 3, 52), DER)) for _ in range(2)]
re6 = [sum(int(c) * X for c, X in zip(rngC.integers(-2, 3, 78), DER + LJ0)) for _ in range(2)]
cf4, okf4 = commutant_dim(rf4); ce6, oke6 = commutant_dim(re6)
kills1 = all(not np.any(D @ ONE) for D in DER) and all(not np.any(np.array([1, 1, 1] + [0] * 24) @ D) for D in DER)
chk('bit', 'jrd·5', kills1 and cf4 == 2 and okf4 and ce6 == 1 and oke6,
    'f4 kills 1 and the trace (it maps the traceless 26 to itself); the commutant of two random elements of f4 (seed 27) on the 27 has dimension %d (the identity and the projection onto 1 lie in it, '
    'so the commutant of f4 is exactly these two): 27 = 1 + 26 with the 26 irreducible over C; the commutant of two random elements of the 78 has dimension %d: the 27 is irreducible under e6' % (cf4, ce6))
# structure constants of the 78 and of the 52 (exact rationals, dyadic: float64 is exact here)
def ad_tensor(basis, coords, n):
    AD = np.zeros((n, n, n))
    for a in range(n):
        for b in range(n):
            c = coords(basis[a] @ basis[b] - basis[b] @ basis[a]); AD[a][:, b] = c
    return AD
AD6 = ad_tensor(DER + LJ0, lambda X: e6coords(X), 78)
AD4 = ad_tensor(DER, lambda X: dcoords(X)[0], 52)
K6 = np.einsum('aij,bji->ab', AD6, AD6); K4 = np.einsum('aij,bji->ab', AD4, AD4)
fracm = lambda K: [[F(float(x)) for x in row] for row in K]               # floats here are dyadic rationals: F(float) is exact
in6 = inertia_exact(fracm(K6)); in4 = inertia_exact(fracm(K4))
def dyadic_int(A, cap=2 ** 20):
    sc = 1
    while sc <= cap and not np.array_equal(A * sc, np.rint(A * sc)): sc *= 2
    return (np.rint(A * sc).astype(np.int64), sc) if sc <= cap else (None, None)
def cartan_of(AD, n, seed):
    """the centraliser of a seeded random integer element: exact Fraction nullspace of ad X0; abelian checked in Python integers"""
    rng = np.random.default_rng(seed); X0 = rng.integers(-3, 4, n).astype(np.float64)
    A = np.tensordot(X0, AD, 1); Hf = fnull(fracm(A), n)
    Hint = []
    for v in Hf:
        den = 1
        for x in v: den = den * x.denominator // math.gcd(den, x.denominator)
        Hint.append(np.array([int(x * den) for x in v], dtype=object))
    ADi, sc = dyadic_int(AD); ab = ADi is not None
    if ab:
        ADo = ADi.astype(object)
        for i, h1 in enumerate(Hint):
            adh1 = np.tensordot(h1, ADo, 1)
            for h2 in Hint[i + 1:]: ab &= not any(adh1.dot(h2))
    H = [np.array([float(x) for x in v]) for v in Hf]
    return H, len(Hf), True, ab
H6, rk6, okh6, ab6 = cartan_of(AD6, 78, 6); H4, rk4, okh4, ab4 = cartan_of(AD4, 52, 4)
chk('bit', 'jrd·6', rk6 == 6 and okh6 and ab6 and rk4 == 4 and okh4 and ab4 and in6 == (26, 52, 0) and in4 == (0, 52, 0),
    'a random integer element of the 78 (seed 6) has a centraliser of dimension %d (exact Fraction elimination on ad), abelian (checked in integers); of the 52 (seed 4): %d: ranks 6 and 4; '
    'Killing forms tr(ad x ad y) exact, inertia by Lagrange\'s method over Q: %s on the 78 (the real form e6(-26), recalled name), %s on the 52 (compact f4)' % (rk6, rk4, in6, in4))
# [std] the roots, numerically
def roots_of(AD, Kfull, H, seed):
    rng = np.random.default_rng(seed); adh = [np.tensordot(h, AD, 1) for h in H]
    Hc = sum(r * A for r, A in zip(rng.normal(size=len(H)), adh)); w, V = np.linalg.eig(Hc); Vi = np.linalg.inv(V)
    diag = [Vi @ A @ V for A in adh]; off = max(np.abs(D - np.diag(np.diag(D))).max() for D in diag)
    lam = np.array([np.diag(D) for D in diag]).T
    Kh = np.array([[h1 @ Kfull @ h2 for h2 in H] for h1 in H])
    nz = [v for v in range(len(w)) if np.abs(lam[v]).max() > 1e-6]
    R = lam[nz]; G = R @ np.linalg.inv(Kh) @ R.T
    return G, off, len(nz), len(w) - len(nz)
def simple_cartan(Gr, r, seed):
    m = len(Gr); idx = []
    for v in range(m):
        if len(idx) < r and np.linalg.matrix_rank(Gr[np.ix_(idx + [v], idx + [v])], tol=1e-6) == len(idx) + 1: idx.append(v)
    C = np.linalg.solve(Gr[np.ix_(idx, idx)], Gr[idx, :]).T
    ell = C @ np.random.default_rng(seed).normal(size=r); pos = [v for v in range(m) if ell[v] > 1e-9]
    def isroot(c): return any(np.abs(C[t] - c).max() < 1e-6 for t in pos)
    simple = [v for v in pos if not any(isroot(C[v] - C[u]) for u in pos if u != v)]
    A = np.array([[2 * Gr[i, j] / Gr[j, j] for j in simple] for i in simple])
    return simple, A, len(pos)
def same_up_to_perm(A, B):
    n = len(B)
    if A.shape != (n, n): return False
    return any(np.abs(A[np.ix_(p, p)] - B).max() < 1e-6 for p in itertools.permutations(range(n)))
CE6 = 2 * np.eye(6)
for a_, b_ in ((0, 2), (2, 3), (3, 4), (4, 5), (1, 3)): CE6[a_, b_] = CE6[b_, a_] = -1
CF4 = np.array([[2, -1, 0, 0], [-1, 2, -2, 0], [0, -1, 2, -1], [0, 0, -1, 2]], dtype=float)
G6, off6, n6, z6 = roots_of(AD6, K6, H6, 66); G6r = G6.real * 2 / np.abs(np.diag(G6.real)).max()
G4, off4, n4, z4 = roots_of(AD4, K4, H4, 44); G4r = G4.real * 2 / np.abs(np.diag(G4.real)).max()
s6, A6, np6 = simple_cartan(G6r, 6, 7); s4, A4, np4 = simple_cartan(G4r, 4, 5)
# the 72 roots of E6 from bit labels (as e_ladder.py: E8 = 112 + 128 doubled vectors, coefficients on the Bourbaki simple roots)
pc = lambda x: bin(x).count('1')
R8 = []
for m in range(256):
    if pc(m) == 2:
        i, j = [t for t in range(8) if (m >> t) & 1]
        for si in (2, -2):
            for sj in (2, -2):
                v = [0] * 8; v[i] = si; v[j] = sj; R8.append(tuple(v))
for x in range(256):
    if pc(x) % 2 == 0: R8.append(tuple(1 - 2 * ((x >> t) & 1) for t in range(8)))
S8 = [(1, -1, -1, -1, -1, -1, -1, 1), (2, 2, 0, 0, 0, 0, 0, 0), (-2, 2, 0, 0, 0, 0, 0, 0), (0, -2, 2, 0, 0, 0, 0, 0), (0, 0, -2, 2, 0, 0, 0, 0),
      (0, 0, 0, -2, 2, 0, 0, 0), (0, 0, 0, 0, -2, 2, 0, 0), (0, 0, 0, 0, 0, -2, 2, 0)]
RA = np.array(R8, dtype=np.int64); COEF = np.rint(RA @ np.linalg.inv(np.array(S8, dtype=float))).astype(np.int64)
E6I = [k for k in range(240) if COEF[k, 6] == 0 and COEF[k, 7] == 0]
GE6 = (RA[E6I] @ RA[E6I].T) / 4.0
gram_ms = lambda G: Counter(tuple(sorted(Counter(int(round(v)) for v in row).items())) for row in G)
chk('std', 'jrd·6', z6 == 6 and n6 == 72 and off6 < 1e-8 and np.abs(G6.imag).max() < 1e-8 * np.abs(G6.real).max() and np.allclose(np.diag(G6r), 2, atol=1e-8)
    and np.abs(G6r - np.rint(G6r)).max() < 1e-8 and gram_ms(G6r) == gram_ms(GE6) and len(E6I) == 72 and len(s6) == 6 and np6 == 36 and same_up_to_perm(A6, CE6),
    'numpy: on that Cartan subalgebra ad is diagonalisable (off-diagonal residual %.1e) with 72 non-zero roots and 6 zero weights; the Killing form gives the roots one length, inner products in '
    '{-2,..,2}, each root with the same profile of inner products as a root of the 72 E6 roots built from bit labels; a generic functional gives 36 positive roots, 6 simple ones, and their Cartan '
    'matrix is that of E6 up to a permutation: the 78 is e6' % off6)
lens4 = Counter(int(round(v)) for v in np.diag(G4r))
chk('std', 'jrd·6', z4 == 4 and n4 == 48 and off4 < 1e-8 and lens4 == Counter({2: 24, 1: 24}) and len(s4) == 4 and np4 == 24 and same_up_to_perm(A4, CF4),
    'numpy: the 52 has 48 roots on its Cartan subalgebra, 24 of squared length 2 and 24 of length 1 (Killing form, normalised), 24 positive, 4 simple with the Cartan matrix of F4 up to a permutation: '
    'the derivations form f4')
chk('bit==std', 'jrd·6', rk6 == z6 and 78 - rk6 == n6 and rk4 == z4 and 52 - rk4 == n4,
    'the exact ranks (6, 4) equal the numbers of zero weights, and 78 - 6 = 72, 52 - 4 = 48 are the root counts')
chk('ctl', 'jrd·5', not is_der(L2(E27[3], JT)) and not is_der(rf4[0] + L2(E27[0] - E27[1], JT)) and np.any(det_system(T6)[0] @ L2(ONE, JT).reshape(-1))
    and np.any(det_system(T6w)[0].astype(np.float64) @ VEC6[:78].T.astype(np.float64)) and not jordan_ok(herm(3, np.where(np.arange(64).reshape(8, 8) == 29, -OS_O, OS_O), pairs=[(0, 1), (1, 2), (2, 0)])['JT'], np.random.default_rng(60), 10),
    'controls: L_a (a = the off-diagonal unit x12 = 1) and a derivation plus L_(e1 - e2) fail the derivation equations; L_1 = the identity (a wrong trace) fails the det equations; '
    'the cubic form without 2 Re(x12 x23 x31) is not preserved by the 78; one sign of the octonion table flipped (e3 e5) breaks the Jordan identity on random pairs')

# ===================================================================================== B. Kantor-Koecher-Tits
head('B. [bit] the Kantor-Koecher-Tits algebra of the pair (h3(O), h3(O)): 27 + 79 + 27 = 133 = e7, and the matrix pairs (CAND-022)')
SGN = 1 if FAULT == 'TKKSIGN' else -1                                      # a wrong version: (D(x,y), +D(y,x)) on V-
def D2j(x, y):
    if FAULT == 'TKKNOSYM': return L2(P2(x, y, JT), JT) + L2(x, JT) @ L2(y, JT)   # a wrong version: not the symmetrised triple
    return D2(x, y, JT)
def tkk_br(A, B):
    """ambient bracket of (x, H+, H-, y) in V+ x gl x gl x V-, with [x+, y-] = (D(x,y), SGN D(y,x)) (scaled by 2: an isomorphic algebra)"""
    x1, P1, M1, y1 = A; x2, P2_, M2, y2 = B
    Pn = P1 @ P2_ - P2_ @ P1; Mn = M1 @ M2 - M2 @ M1
    if x1.any() and y2.any(): Pn = Pn + D2j(x1, y2); Mn = Mn + SGN * D2j(y2, x1)
    if x2.any() and y1.any(): Pn = Pn - D2j(x2, y1); Mn = Mn - SGN * D2j(y1, x2)
    return (P1 @ x2 - P2_ @ x1, Pn, Mn, M1 @ y2 - M2 @ y1)
def tkk_add(*Xs): return tuple(sum(X[k] for X in Xs) for k in range(4))
def tkk_zero(X): return all(not np.any(c) for c in X)
rngB = np.random.default_rng(22)
def rnd_h(rng):
    P = np.zeros((NJ, NJ), dtype=np.int64); M = np.zeros((NJ, NJ), dtype=np.int64)
    for _ in range(2):
        a, b = rng.integers(-1, 2, NJ), rng.integers(-1, 2, NJ); P += D2j(a, b); M += SGN * D2j(b, a)
    return P, M
def rnd_el(rng):
    P, M = rnd_h(rng); return (rng.integers(-2, 3, NJ), P, M, rng.integers(-2, 3, NJ))
jac = True
for _ in range(10):
    a, b, c = rnd_el(rngB), rnd_el(rngB), rnd_el(rngB)
    jac &= tkk_zero(tkk_add(tkk_br(tkk_br(a, b), c), tkk_br(tkk_br(b, c), a), tkk_br(tkk_br(c, a), b)))
pid = True
for _ in range(10):
    u, v, x, y = (rngB.integers(-2, 3, NJ) for _ in range(4))
    Duv = D2j(u, v); lhs = Duv @ D2j(x, y) - D2j(x, y) @ Duv
    pid &= np.array_equal(lhs, D2j(Duv @ x, y) - D2j(x, D2j(v, u) @ y))
A4 = np.einsum('ijm,mkl->ijkl', JT, JT)                                   # P2(P2(e_i, e_j), e_k)
T2t = A4 + A4.transpose(2, 1, 0, 3) - A4.transpose(0, 2, 1, 3)              # 2 {e_i e_j e_k} = 4((x o y) o z + (z o y) o x - (x o z) o y)
ident = all(np.array_equal(D2(E27[i], E27[j], JT), T2t[i, j].T) for i in range(NJ) for j in range(NJ))
INSTR = [(L2E[m], -L2E[m]) for m in range(NJ)] + [(D, D) for D in DER]
r79 = rank_mod_p(np.array([P.reshape(-1) for P, _ in INSTR]))
chk('bit', 'jrd·7', jac and pid and ident and r79 == 79 and len(INSTR) == 79,
    'on 10 random elements (seed 22) of V+ + instr + V- the pair identity [D(u,v), D(x,y)] = D(D(u,v)x, y) - D(x, D(v,u)y) and the Jacobi identity hold exactly (10 triples); '
    'the triple product 2((x o y) o z + (z o y) o x - (x o z) o y) equals 2 (L_(x o y) + [L_x, L_y]) z on all 27^3 basis triples, so instr = L_J + Der (the inner derivations span Der, jrd·2): '
    '%d dimensions (rank mod p of the first components, exact; = str h3(O) = e6 + R)' % r79)
# exact structure constants of the 133 in the basis V+ (27), L_(e_m) (27), Der (52), V- (27)
def g0coords(P, M):
    """coordinates of the pair (P, M) in INSTR: beta from P 1, gamma from the pivot rows (dyadic, exact in float64); None if not in the span"""
    beta = (P @ ONE).astype(np.float64) / 2; Lp = np.zeros((NJ, NJ))
    for m, b in enumerate(beta):
        if b: Lp = Lp + b * L2E[m]
    g, ok = dcoords(P - Lp)
    if not ok: return None
    Dp = np.zeros((NJ, NJ))
    for c, D in zip(g, DER):
        if c: Dp = Dp + c * D
    if not np.array_equal(M.astype(np.float64), -Lp + Dp): return None
    return np.concatenate([beta, g])
NT = 27 + 79 + 27
def tkk_vec(X):
    x, P, M, y = X; c0 = g0coords(P, M)
    return None if c0 is None else np.concatenate([x, c0, y]).astype(np.float64)
BASIS = ([(E27[i], np.zeros((NJ, NJ), dtype=np.int64), np.zeros((NJ, NJ), dtype=np.int64), np.zeros(NJ, dtype=np.int64)) for i in range(NJ)]
         + [(np.zeros(NJ, dtype=np.int64), P, M, np.zeros(NJ, dtype=np.int64)) for P, M in INSTR]
         + [(np.zeros(NJ, dtype=np.int64), np.zeros((NJ, NJ), dtype=np.int64), np.zeros((NJ, NJ), dtype=np.int64), E27[i]) for i in range(NJ)])
SGN_main = SGN; SGN = -1                                                    # the exact table uses the correct sign; the wrong one is tested above
AD7 = np.zeros((NT, NT, NT)); closed7 = True
for a in range(NT):
    for b in range(a, NT):
        v = tkk_vec(tkk_br(BASIS[a], BASIS[b]))
        if v is None: closed7 = False; continue
        AD7[a][:, b] = v; AD7[b][:, a] = -v
SGN = SGN_main
Eel = 0.5 * sum(np.eye(NT)[27 + m] for m in range(3))                    # E = (1, -1) = (L_1, -L_1)/2 as a combination of L_(e_m)
adE = np.tensordot(Eel, AD7, 1)
grade = np.array_equal(np.diag(adE), np.array([1.0] * 27 + [0.0] * 79 + [-1.0] * 27)) and np.array_equal(adE, np.diag(np.diag(adE)))
K7 = np.einsum('aij,bji->ab', AD7, AD7)
blk = not np.any(K7[:27, :106]) and not np.any(K7[106:, 27:]) and frank(fracm(K7[:27, 106:])) == 27
in70 = inertia_exact(fracm(K7[27:106, 27:106]))
sig7 = (27 + in70[0], 27 + in70[1], in70[2]) if (blk and in70) else None
chk('bit', 'jrd·8', closed7 and grade and sig7 == (54, 79, 0),
    'the brackets of all 133 x 133 basis pairs lie in V+ + instr + V- (exact coordinates); ad E = diag(+1 on V+ (27), 0 on instr (79), -1 on V- (27)): the grading; Killing form exact: '
    'zero on V+ x V+, V- x V-, V+- x instr, a non-degenerate pairing V+ x V- (27 + 27) and inertia %s on instr: signature %s, the real form e7(-25) (recalled name; E VII in Cartan\'s list)' % (in70, sig7))
simple7 = ce6 == 1 and r79 == 79 and grade
chk('bit', 'jrd·8', simple7 and NT == 133,
    'simple: an ideal is ad E-stable, so graded; its V+ part is an e6-submodule of the 27, which is irreducible (jrd·5), so 0 or V+, and likewise V-; V+ in the ideal gives [V+, V-] = instr and then V-; '
    'an ideal inside instr acts on V+ by zero, and instr acts faithfully on V+ (rank 79): so the only ideals are 0 and the algebra (the argument uses the exact facts above). '
    'Dimension 133: the only simple Lie algebra of this dimension is e7 (classification recalled)')
# the matrix and spin-factor Jordan algebras and pairs: generic TKK by least squares
def tkk_generic(Dp, Dm, npl, nmi, sgn=-1):
    """Dp(i, j): matrix of {e_i f_j .} on V+; Dm(j, i): matrix of {f_j e_i .} on V-; returns dims, closure residual, Killing signature, E in instr"""
    pairs = [(Dp(i, j), sgn * Dm(j, i)) for i in range(npl) for j in range(nmi)]
    S = np.array([np.concatenate([P.ravel(), M.ravel()]).astype(np.float64) for P, M in pairs])
    U, s, Vt = np.linalg.svd(S, full_matrices=False); r0 = int((s > 1e-9 * s[0]).sum()); B0 = Vt[:r0]
    def c0(P, M):
        v = np.concatenate([P.ravel(), M.ravel()]).astype(np.float64); c = B0 @ v; return c, np.abs(B0.T @ c - v).max()
    hs = [(B0[t, :npl * npl].reshape(npl, npl), B0[t, npl * npl:].reshape(nmi, nmi)) for t in range(r0)]
    n = npl + r0 + nmi; AD = np.zeros((n, n, n)); res = 0.0
    for i in range(npl):
        for j in range(nmi):
            c, e = c0(*pairs[i * nmi + j]); res = max(res, e); AD[i][npl:npl + r0, npl + r0 + j] = c; AD[npl + r0 + j][npl:npl + r0, i] = -c
    for t, (P, M) in enumerate(hs):
        a = npl + t
        for i in range(npl): AD[a][:npl, i] = P[:, i]; AD[i][:npl, a] = -P[:, i]
        for j in range(nmi): AD[a][npl + r0:, npl + r0 + j] = M[:, j]; AD[npl + r0 + j][npl + r0:, a] = -M[:, j]
        for u, (P2h, M2h) in enumerate(hs):
            c, e = c0(P @ P2h - P2h @ P, M @ M2h - M2h @ M); res = max(res, e); AD[a][npl:npl + r0, npl + u] = c
    K = np.einsum('aij,bji->ab', AD, AD); sg = sig_num(K)
    cE, eE = c0(np.eye(npl), -np.eye(nmi))
    return dict(r0=r0, n=n, res=res, sig=sg[:2], gap=sg[2], E_in=eE < 1e-9)
def jordan_pair_ops(JTx):
    n = JTx.shape[0]; E = np.eye(n, dtype=np.int64)
    Dp = lambda i, j: D2(E[i], E[j], JTx).astype(np.float64)
    return Dp, Dp, n
FAM = []
for nn in (1, 2, 3): FAM.append(('h_%d(R)' % nn, herm(nn, OS_R)['JT'], 'sp(%d,R)' % (2 * nn), (nn * (nn + 1), nn * nn)))
for nn in (2, 3): FAM.append(('h_%d(C)' % nn, herm(nn, OS_C)['JT'], 'su(%d,%d)' % (nn, nn), (2 * nn * nn, 2 * nn * nn - 1)))
for nn in (2, 3): FAM.append(('h_%d(H)' % nn, herm(nn, OS_H)['JT'], 'so*(%d)' % (4 * nn), (2 * nn * (2 * nn - 1), 4 * nn * nn)))
for NN in (3, 4, 5, 6): FAM.append(('R+R^%d' % (NN - 1), spin_factor(NN), 'so(%d,2)' % NN, (2 * NN, NN * (NN - 1) // 2 + 1)))
TK = {}
for nm, JTx, gname, want in FAM:
    Dp, Dm, n = jordan_pair_ops(JTx); TK[nm] = (tkk_generic(Dp, Dm, n, n), n, gname, want, JTx)
okF = all(t['res'] < 1e-9 and t['E_in'] and t['sig'] == want and t['gap'] > 1e-6 and t['n'] == sum(want) for t, n, g, want, J in TK.values())
chk('std', 'jrd·9', okF,
    'the same construction (numpy, least squares, closure residual < 1e-9) for the Euclidean Jordan algebras: dimension and Killing signature ' +
    ', '.join('%s %d %s' % (nm, t['n'], t['sig']) for nm, (t, n, g, w, J) in TK.items()) +
    ': (2 dim J, dim str J) in every case, E = (1, -1) in instr; these are the dimensions and signatures of sp(2n,R), su(n,n), so*(4n), so(N,2) (C I, A III, D III, BD I of Cartan\'s list: names recalled)')
# matrix realisations (std): sp(2n,R), su(n,n), so(N,2)
def lie_from_conditions(cond, size, real_dim):
    """basis of {X in R^(size x size) : cond(X) = 0} (cond linear), by SVD"""
    M = np.array([cond(np.eye(size * size)[k].reshape(size, size)).ravel() for k in range(size * size)]).T
    U, s, Vt = np.linalg.svd(M); r = int((s > 1e-9).sum()); N = Vt[r:]
    return [N[t].reshape(size, size) for t in range(len(N))]
def matrix_sig(mats):
    B = np.array([m.ravel() for m in mats]).T; Pi = np.linalg.pinv(B); n = len(mats); AD = np.zeros((n, n, n)); res = 0.0
    for a in range(n):
        for b in range(n):
            Cm = (mats[a] @ mats[b] - mats[b] @ mats[a]).ravel(); c = Pi @ Cm; res = max(res, np.abs(B @ c - Cm).max()); AD[a][:, b] = c
    K = np.einsum('aij,bji->ab', AD, AD); sg = sig_num(K); return n, sg[:2], res
def realify(Z): return np.block([[Z.real, -Z.imag], [Z.imag, Z.real]])
MAT = {}
for nn in (1, 2, 3):
    Om = np.block([[np.zeros((nn, nn)), np.eye(nn)], [-np.eye(nn), np.zeros((nn, nn))]])
    MAT['sp(%d,R)' % (2 * nn)] = matrix_sig(lie_from_conditions(lambda X: X.T @ Om + Om @ X, 2 * nn, None))
for nn in (2, 3):
    m2 = 2 * nn; Hh = np.diag([1.0] * nn + [-1.0] * nn); Jr = realify(1j * np.eye(m2)); HR = realify(Hh.astype(complex))
    def cond(X, Jr=Jr, HR=HR, m2=m2):
        c1 = X @ Jr - Jr @ X; c2 = X.T @ HR + HR @ X; c3 = np.zeros_like(X); c3[0, 0] = np.trace(X[:m2, :m2]); c3[0, 1] = np.trace(X[m2:, :m2])
        return np.concatenate([c1.ravel(), c2.ravel(), c3.ravel()])
    MSU = lie_from_conditions(cond, 2 * m2, None)
    MAT['su(%d,%d)' % (nn, nn)] = matrix_sig(MSU)
for NN in (3, 4, 5, 6):
    Q = np.diag([1.0] * NN + [-1.0, -1.0]); MAT['so(%d,2)' % NN] = matrix_sig(lie_from_conditions(lambda X: X.T @ Q + Q @ X, NN + 2, None))
cmpF = {g: (t['n'], t['sig'], MAT[g][:2]) for nm, (t, n, g, w, J) in TK.items() if g in MAT}
chk('bit==std', 'jrd·9', all(MAT[g][2] < 1e-9 and (t['n'], t['sig']) == MAT[g][:2] for nm, (t, n, g, w, J) in TK.items() if g in MAT) and len(cmpF) == 9,
    'the matrix realisations sp(2n,R) (n = 1, 2, 3), su(n,n) (n = 2, 3, realified), so(N,2) (N = 3..6) have the same dimension and Killing signature as the TKK algebras of h_n(R), h_n(C) and the spin factors: ' +
    ', '.join('%s %s' % (g, v[2]) for g, v in cmpF.items()) + '; for h_n(H): so*(8) and so(6,2) are isomorphic (recalled), and h_2(H) gives what R+R^5 gives; so*(12): dimension 66, signature (30, 36) as recalled')
# exact block maps: the skew pair -> so(m,m), the rectangular pair -> sl(p+q, R); h2(C) = R + R^3
def block_map_check(npl, nmi, embp, embm, trip_p, trip_m, form=None):
    """[[phi x, phi y], phi z] = phi {x y z} and [[phi x, phi y], phi w] = -phi {y x w} on all basis triples; dims of the image algebra; image in so(form)"""
    Ep, Em = np.eye(npl, dtype=np.int64), np.eye(nmi, dtype=np.int64); ok = True; zz = True
    Xs = [embp(Ep[i]) for i in range(npl)]; Ys = [embm(Em[j]) for j in range(nmi)]
    br = lambda A, B: A @ B - B @ A
    for i in range(npl):
        for j in range(nmi):
            H = br(Xs[i], Ys[j])
            for k in range(npl): ok &= np.array_equal(br(H, Xs[k]), embp(trip_p(Ep[i], Em[j], Ep[k])))
            for k in range(nmi): ok &= np.array_equal(br(H, Ys[k]), -embm(trip_m(Em[j], Ep[i], Em[k])))
    for i in range(npl):
        for k in range(npl): zz &= not np.any(br(Xs[i], Xs[k]))
    Hs = [br(Xs[i], Ys[j]) for i in range(npl) for j in range(nmi)]
    dim0 = frank([H.ravel().tolist() for H in Hs]); dimall = frank([M.ravel().tolist() for M in Xs + Ys + Hs])
    inform = form is None or all(not np.any(M.T @ form + form @ M) for M in Xs + Ys + Hs)
    return ok and zz and inform, dim0, dimall
def mat_unit(p, q, k): M = np.zeros((p, q), dtype=np.int64); M.flat[k] = 1; return M
def skew_basis(m): return [(i, j) for i in range(m) for j in range(i + 1, m)]
def skew_of(v, m):
    S = np.zeros((m, m), dtype=np.int64)
    for t, (i, j) in enumerate(skew_basis(m)): S[i, j] = v[t]; S[j, i] = -v[t]
    return S
def skew_vec(S, m): return np.array([S[i, j] for (i, j) in skew_basis(m)], dtype=np.int64)
blk_res = {}
for m in (4, 5):
    ns = m * (m - 1) // 2
    def embp(v, m=m): Z = np.zeros((2 * m, 2 * m), dtype=np.int64); Z[:m, m:] = skew_of(v, m); return Z
    def embm(v, m=m): Z = np.zeros((2 * m, 2 * m), dtype=np.int64); Z[m:, :m] = skew_of(v, m); return Z
    def trip(x, y, z, m=m): X, Y, Z = skew_of(x, m), skew_of(y, m), skew_of(z, m); return skew_vec(X @ Y @ Z + Z @ Y @ X, m)
    Qm = np.block([[np.zeros((m, m), dtype=np.int64), np.eye(m, dtype=np.int64)], [np.eye(m, dtype=np.int64), np.zeros((m, m), dtype=np.int64)]])
    blk_res['A_%d(R) -> so(%d,%d)' % (m, m, m)] = (block_map_check(ns, ns, embp, embm, trip, trip, Qm), (m * m, m * (2 * m - 1)))
for p, q in ((1, 2), (2, 3)):
    def embp(v, p=p, q=q): Z = np.zeros((p + q, p + q), dtype=np.int64); Z[:p, p:] = np.asarray(v).reshape(p, q); return Z
    def embm(v, p=p, q=q): Z = np.zeros((p + q, p + q), dtype=np.int64); Z[p:, :p] = np.asarray(v).reshape(q, p); return Z
    def tp(x, y, z, p=p, q=q): X, Y, Z = x.reshape(p, q), y.reshape(q, p), z.reshape(p, q); return (X @ Y @ Z + Z @ Y @ X).ravel()
    def tm(y, x, w, p=p, q=q): Y, X, W = y.reshape(q, p), x.reshape(p, q), w.reshape(q, p); return (Y @ X @ W + W @ X @ Y).ravel()
    blk_res['M_(%d,%d)(R) -> sl(%d,R)' % (p, q, p + q)] = (block_map_check(p * q, p * q, embp, embm, tp, tm), ((p + q) ** 2 - 1 - 2 * p * q, (p + q) ** 2 - 1))
okblk = all(r[0] and r[1] == w[0] and r[2] == w[1] for r, w in blk_res.values())
# h2(C) = R + R^3: psi(e0) = 1, psi(e1) = sigma1, psi(e2) = sigma2, psi(e3) = sigma3 in the coordinates (d0, d1, Re z, Im z)
JC2 = herm(2, OS_C)['JT']; JS4 = spin_factor(4)
PSI = np.array([[1, 1, 0, 0], [0, 0, 1, 0], [0, 0, 0, -1], [1, -1, 0, 0]], dtype=np.int64).T     # columns: images of e0..e3
E4 = np.eye(4, dtype=np.int64)
iso2 = all(np.array_equal(PSI @ P2(E4[i], E4[j], JS4), P2(PSI[:, i], PSI[:, j], JC2)) for i in range(4) for j in range(4))
trip_iso = all(np.array_equal(PSI @ (D2(E4[i], E4[j], JS4) @ E4[k]), D2(PSI[:, i], PSI[:, j], JC2) @ PSI[:, k]) for i in range(4) for j in range(4) for k in range(4))
t15a, t15b = TK['h_2(C)'][0], TK['R+R^3'][0]
chk('bit', 'jrd·10', okblk and iso2 and trip_iso and t15a['n'] == t15b['n'] == 15 and t15a['sig'] == t15b['sig'] == (8, 7),
    'exact block maps x -> [[0, x], [0, 0]], y -> [[0, 0], [y, 0]] with {x y z} = x y z + z y x: [[x, y], z] = {x y z} and [[x, y], w] = -{y x w} on all basis triples; ' +
    '; '.join('%s: instr %d, total %d (image in the form\'s Lie algebra)' % (k, r[1], r[2]) for k, (r, w) in blk_res.items()) +
    ': the skew pair gives so(m,m) with g_0 = gl(m) (over C: so(2m) = A_m + gl(m) + A_m, the grading of D III, recalled name), the rectangular pair sl(p+q); '
    'psi(e0, e1, e2, e3) = (1, sigma1, sigma2, sigma3) is a Jordan isomorphism R + R^3 -> h2(C) (all 16 products, exact) and carries the triple products (64), so the TKK algebras of h2(C) and of R + R^3 '
    'are isomorphic: both 15-dimensional with signature %s, su(2,2) = so(4,2) (A III(2,2) = BD I(4,2))' % (t15a['sig'],))
# controls of B (the wrong sign and the non-symmetrised triple)
SGN = 1; jacW = True
rngW = np.random.default_rng(23); a, b, c = rnd_el(rngW), rnd_el(rngW), rnd_el(rngW)
jacW = tkk_zero(tkk_add(tkk_br(tkk_br(a, b), c), tkk_br(tkk_br(b, c), a), tkk_br(tkk_br(c, a), b)))
SGN = SGN_main
NOSYM = lambda x, y: L2(P2(x, y, JT), JT) + L2(x, JT) @ L2(y, JT)
u, v, x, y = (rngW.integers(-2, 3, NJ) for _ in range(4))
pidW = np.array_equal(NOSYM(u, v) @ NOSYM(x, y) - NOSYM(x, y) @ NOSYM(u, v), NOSYM(NOSYM(u, v) @ x, y) - NOSYM(x, NOSYM(v, u) @ y))
negM = tkk_generic(lambda i, j: D2(E27[i], E27[j], JT).astype(np.float64), lambda j, i: -D2(E27[j], E27[i], JT).astype(np.float64), 27, 27)
chk('ctl', 'jrd·11', not jacW and not pidW and negM['res'] > 1e-6,
    'controls: [x+, y-] = (D(x,y), +D(y,x)) fails the Jacobi identity on a random triple (seed 23); the non-symmetrised triple L_(x o y) + L_x L_y fails the pair identity; '
    'V- with the negated product: the pairs (D(x,y), D(y,x)) do not close under the commutator (least-squares residual %.2f): no Lie algebra (not another real form)' % negM['res'])

# ===================================================================================== C. Peirce spaces of frames
head('C. [bit] joint Peirce spaces of frames of orthogonal minimal tripotents: dimensions 1, a, b and dim V = r + a r(r-1)/2 + b r (CAND-066)')
def peirce(Dop, dim, frame, triple_e):
    """Dop(e, f): exact Fraction matrix of D(e, f) on V; frame: list of vectors; triple_e(e): {e e e}. Returns a report dict"""
    r = len(frame); Ds = [Dop(e, e) for e in frame]; I = [[F(int(i == j)) for j in range(dim)] for i in range(dim)]
    mm = lambda A, B: [[sum(A[i][k] * B[k][j] for k in range(dim)) for j in range(dim)] for i in range(dim)]
    sub = lambda A, lam: [[A[i][j] - lam * I[i][j] for j in range(dim)] for i in range(dim)]
    tri = all([2 * F(v) for v in e] == [F(v) for v in triple_e(e)] for e in frame)
    orth = all(not any(any(row) for row in Dop(frame[k], frame[l])) for k in range(r) for l in range(r) if k != l)
    comm = all(mm(Ds[k], Ds[l]) == mm(Ds[l], Ds[k]) for k in range(r) for l in range(k + 1, r))
    poly = all(not any(any(row) for row in mm(mm(D, sub(D, 1)), sub(D, 2))) for D in Ds)
    single = [tuple(dim - frank(sub(D, lam)) for lam in (0, 1, 2)) for D in Ds]
    dims = {}
    for i in range(r + 1):
        for j in range(i, r + 1):
            lam = [int(l + 1 == i) + int(l + 1 == j) for l in range(r)] if i > 0 else [int(l + 1 == j) for l in range(r)]
            if i == 0 and j == 0: lam = [0] * r
            rows = [row for D, lm in zip(Ds, lam) for row in sub(D, lm)]
            dims[(i, j)] = dim - frank(rows)
    diag_ = {dims[(i, i)] for i in range(1, r + 1)}; offd = {dims[(i, j)] for i in range(1, r + 1) for j in range(i + 1, r + 1)}; zer = {dims[(0, j)] for j in range(1, r + 1)}
    a = offd.pop() if len(offd) == 1 else (0 if not offd else None); b = zer.pop() if len(zer) == 1 else None
    uni = diag_ == {1} and a is not None and b is not None and dims[(0, 0)] == 0
    formula = uni and r + a * r * (r - 1) // 2 + b * r == dim and sum(dims.values()) == dim
    return dict(r=r, a=a, b=b, tri=tri, orth=orth, comm=comm, poly=poly, single=single, dims=dims, ok=tri and orth and comm and poly and uni and formula, V00=dims[(0, 0)])
def frac_mat(M): return [[F(x) for x in row] for row in np.asarray(M).tolist()]
def mat_triple_ops(p, q):
    """M_(p,q)(R) with {x y z} = x y^T z + z y^T x, basis E_ij (row major)"""
    dim = p * q; basis = [mat_unit(p, q, k) for k in range(dim)]
    def Dop(e, f):
        Em, Fm = np.asarray(e, dtype=object).reshape(p, q), np.asarray(f, dtype=object).reshape(p, q)
        return frac_mat(np.array([(Em.dot(Fm.T).dot(Bz) + Bz.dot(Fm.T).dot(Em)).ravel() for Bz in basis], dtype=object).T)
    def trip(e):
        Em = np.asarray(e, dtype=object).reshape(p, q); return (2 * Em.dot(Em.T).dot(Em)).ravel().tolist()
    return Dop, dim, trip
def skew_triple_ops(m):
    bs = skew_basis(m); dim = len(bs)
    def Dop(e, f):
        Em, Fm = skew_of([int(x) for x in e], m), skew_of([int(x) for x in f], m)
        return frac_mat(np.array([skew_vec(Em @ Fm.T @ skew_of(np.eye(dim, dtype=np.int64)[k], m) + skew_of(np.eye(dim, dtype=np.int64)[k], m) @ Fm.T @ Em, m) for k in range(dim)]).T)
    trip = lambda e: skew_vec(2 * skew_of([int(x) for x in e], m) @ skew_of([int(x) for x in e], m).T @ skew_of([int(x) for x in e], m), m)
    return Dop, dim, trip
def sym_triple_ops(n):
    bs = [(i, i) for i in range(n)] + [(i, j) for i in range(n) for j in range(i + 1, n)]; dim = len(bs)
    def of(v):
        S = np.zeros((n, n), dtype=object)
        for t, (i, j) in enumerate(bs): S[i, j] = S[j, i] = F(v[t])
        return S
    def vec(S): return [S[i, j] for (i, j) in bs]
    def Dop(e, f):
        Em, Fm = of(e), of(f); cols = []
        for k in range(dim):
            Bz = of([int(t == k) for t in range(dim)]); cols.append(vec(Em.dot(Fm).dot(Bz) + Bz.dot(Fm).dot(Em)))
        return [[cols[k][i] for k in range(dim)] for i in range(dim)]
    trip = lambda e: vec(2 * of(e).dot(of(e)).dot(of(e)))
    return Dop, dim, trip
def jordan_triple_ops(JTx, sub=None):
    """{x y z} = 2((x o y) o z + (z o y) o x - (x o z) o y) = D2(x, y) z / 2; optionally restricted to a coordinate subspace sub (closure checked)"""
    n = JTx.shape[0]; S = list(range(n)) if sub is None else list(sub); notS = [k for k in range(n) if k not in S]
    def full(v):
        out = np.zeros(n, dtype=object)
        for t, k in enumerate(S): out[k] = F(v[t])
        return out
    def Dfull(e, f):
        ef, ff = full(e), full(f); sc = 1
        for vv in list(ef) + list(ff): sc = sc * F(vv).denominator // int(np.gcd(sc, F(vv).denominator))
        ei, fi = np.array([int(F(v) * sc) for v in ef], dtype=np.int64), np.array([int(F(v) * sc) for v in ff], dtype=np.int64)
        return D2(ei, fi, JTx), F(1, 2 * sc * sc)
    def Dop(e, f):
        M, s = Dfull(e, f)
        if notS and np.any(M[np.ix_(notS, S)]): raise ValueError('the subspace is not closed under the triple product')
        return [[s * int(M[i, j]) for j in S] for i in S]
    def trip(e):
        M, s = Dfull(e, e); ef = full(e); return [s * sum(int(M[i, j]) * ef[j] for j in range(n)) for i in S]
    return Dop, len(S), trip
PE = {}
def run_family(name, ops, frame, want):
    Dop, dim, trip = ops; rep = peirce(Dop, dim, [[F(x) for x in e] for e in frame], trip); PE[name] = (rep, want, dim)
for p, q in ((2, 2), (2, 3), (3, 3), (2, 4), (3, 5)):
    fr = [mat_unit(p, q, k * q + k).ravel() for k in range(p)]
    if FAULT == 'COLINEAR' and (p, q) == (2, 3): fr = [mat_unit(2, 3, 0).ravel(), mat_unit(2, 3, 1).ravel()]          # a wrong version: E11 and E12 (colinear)
    if FAULT == 'NONMIN' and (p, q) == (3, 3): fr = [(mat_unit(3, 3, 0) + mat_unit(3, 3, 4)).ravel(), mat_unit(3, 3, 8).ravel()]   # E11 + E22 (not minimal)
    run_family('M_(%d,%d)(R)' % (p, q), mat_triple_ops(p, q), fr, (p, 2, q - p))
for m in (4, 5, 6, 7):
    bs = skew_basis(m); fr = [np.array([int((i, j) == (2 * k, 2 * k + 1)) for (i, j) in bs]) for k in range(m // 2)]
    run_family('A_%d(R)' % m, skew_triple_ops(m), fr, (m // 2, 4, 2 * (m % 2)))
for nn in (2, 3, 4):
    fr = [np.array([int(t == k) for t in range(nn * (nn + 1) // 2)]) for k in range(nn)]
    run_family('Sym_%d(R)' % nn, sym_triple_ops(nn), fr, (nn, 1, 0))
for nn, OS_, aa, nm in ((2, OS_C, 2, 'h_2(C)'), (3, OS_C, 2, 'h_3(C)'), (2, OS_H, 4, 'h_2(H)'), (3, OS_H, 4, 'h_3(H)')):
    Hx = herm(nn, OS_); fr = [np.eye(Hx['dim'], dtype=np.int64)[k] for k in range(nn)]
    run_family(nm, jordan_triple_ops(Hx['JT']), fr, (nn, aa, 0))
for NN in range(3, 11):
    e_p = [F(1, 2)] + [F(0)] * (NN - 1); e_p[1] = F(1, 2); e_m = [F(1, 2)] + [F(0)] * (NN - 1); e_m[1] = F(-1, 2)
    run_family('R+R^%d' % (NN - 1), jordan_triple_ops(spin_factor(NN)), [e_p, e_m], (2, NN - 2, 0))
run_family('h_3(O)', jordan_triple_ops(JT), [E27[0], E27[1], E27[2]], (3, 8, 0))
JTS = herm(3, OS_S, pairs=[(0, 1), (1, 2), (2, 0)])
run_family('h_3(O_split)', jordan_triple_ops(JTS['JT']), [E27[0], E27[1], E27[2]], (3, 8, 0))
SUB16 = list(range(3, 11)) + list(range(19, 27))                          # the Peirce 1/2 space of E11: x12 and x31
csq = next(c for c in range(1, 8) if OS_S[c, c] == 1)
u16 = [F(int(k == 3)) for k in SUB16]; w16 = [F(int(k == 3 + csq)) for k in SUB16]
okP = all(rep['ok'] and (rep['r'], rep['a'], rep['b']) == want for rep, want, dim in PE.values())
chk('bit', 'jrd·12', okP and len(PE) == 26,
    'for every family the frame elements are tripotents ({e e e} = 2e), pairwise orthogonal (D(e,f) = 0), minimal (V_2 of dimension 1), D(e,e) satisfies D(D-1)(D-2) = 0 and the D(e,e) commute (exact); '
    'the joint Peirce spaces have dimensions 1 (V_ii), a (V_ij), b (V_0j), V_00 = 0, and dim V = r + a r(r-1)/2 + b r: ' +
    '; '.join('%s %d = (%s, %s, %s)' % (nm, dim, rep['r'], rep['a'], rep['b']) for nm, (rep, want, dim) in PE.items()))
single_ok = all(all(s == (dim - 1 - (rep['a'] * (rep['r'] - 1) + rep['b']), rep['a'] * (rep['r'] - 1) + rep['b'], 1) for s in rep['single']) for rep, want, dim in PE.values())
chk('bit', 'jrd·13', single_ok,
    'one minimal tripotent: V_2, V_1, V_0 of dimensions 1, a(r-1) + b and dim V - 1 - a(r-1) - b in every family (e.g. h_3(O): 1, 16, 10; A_5(R): 1, 6, 3; M_(2,3)(R): 1, 3, 2), '
    'the Peirce counts that baez·E2a reads from roots for the Albert, a_5 and M_(3,2) triples')
LOOS = {'I': lambda p, q: (p, 2, q - p), 'II': lambda n: (n // 2, 4, 2 * (n % 2)), 'III': lambda n: (n, 1, 0), 'IV': lambda N: (2, N - 2, 0), 'V': (2, 6, 4), 'VI': (3, 8, 0)}
tab = {'M_(2,3)(R)': LOOS['I'](2, 3), 'A_5(R)': LOOS['II'](5), 'Sym_3(R)': LOOS['III'](3), 'R+R^5': LOOS['IV'](6), 'h_3(O)': LOOS['VI']}
chk('std', 'jrd·13', all((PE[k][0]['r'], PE[k][0]['a'], PE[k][0]['b']) == v for k, v in tab.items()) and (PE['M_(2,3)(R)'][0]['a'], PE['M_(2,3)(R)'][0]['b']) == (2, 1),
    'Loos\'s table (recalled): I_(p,q) (p, 2, q-p), II_n (n/2, 4, 0 or 2), III_n (n, 1, 0), IV_N (2, N-2, 0), V (2, 6, 4), VI (3, 8, 0); a real form of types I, II, III, IV and VI computed above has these values '
    '(type V on roots, jrd·14); M_(2,3)(R) has (2, 2, 1): 2 + 2 + 2 = 6 (the values (2, 1, 1) would give 5)')
# [std] frames on roots: the grade-1 roots of the 3-gradings of e7, e6, so(10), sl(5) (as baez·E1b), frames of strongly orthogonal roots
G8 = (RA @ RA.T) // 4
def grade1(n): return [k for k in range(240) if not COEF[k, n:].any() and COEF[k, n - 1] == 1]
def root_frame(g1):
    fr = []
    for k in g1:
        if all(G8[k, l] == 0 for l in fr): fr.append(k)
    r = len(fr)
    larger = any(all(G8[a_, b_] == 0 for a_, b_ in itertools.combinations(S_, 2)) for S_ in itertools.combinations(g1, r + 1))
    cls = Counter()
    for g_ in g1:
        v = [int(G8[g_, b_]) for b_ in fr]
        if sorted(v) == [0] * (r - 1) + [2]: cls[(v.index(2) + 1,) * 2] += 1
        elif sorted(v) == [0] * (r - 2) + [1, 1]: cls[tuple(t + 1 for t in range(r) if v[t] == 1)] += 1
        elif sorted(v) == [0] * (r - 1) + [1]: cls[(0, v.index(1) + 1)] += 1
        elif not any(v): cls[(0, 0)] += 1
        else: cls['other'] += 1
    a = {cls[(k, l)] for k in range(1, r + 1) for l in range(k + 1, r + 1)}; b = {cls[(0, k)] for k in range(1, r + 1)}
    ok = (not larger and {cls[(k, k)] for k in range(1, r + 1)} == {1} and len(a) == 1 and len(b) == 1 and cls[(0, 0)] == 0 and cls['other'] == 0
          and r + a_one(a) * r * (r - 1) // 2 + a_one(b) * r == len(g1))
    return r, (a_one(a) if len(a) == 1 else None), (a_one(b) if len(b) == 1 else None), ok
def a_one(sset): return next(iter(sset)) if sset else 0
RF = {nm: (len(grade1(n)),) + root_frame(grade1(n)) for nm, n in (('Albert (e7)', 7), ('bi-Cayley (e6)', 6), ('a_5 (so(10))', 5), ('M_(3,2) (sl(5))', 4))}
chk('std', 'jrd·14', all(v[4] for v in RF.values()) and [v[:4] for v in RF.values()] == [(27, 3, 8, 0), (16, 2, 6, 4), (10, 2, 4, 2), (6, 2, 2, 1)],
    'on the roots of E8 (bit labels): the grade-1 roots of the 3-gradings of e7, e6, so(10), sl(5) (coefficient 1 on the deleted node; 27, 16, 10, 6 roots); a maximal set of mutually orthogonal roots '
    'among them (no larger one exists: all subsets of size r + 1 tested) is a frame; the grade-1 roots split by their inner products with it into 1 (V_ii), a (V_ij), b (V_0j), none outside: ' +
    ', '.join('%s %d = (%d, %d, %d)' % (nm, v[0], v[1], v[2], v[3]) for nm, v in RF.items()) + ': type V (bi-Cayley) has (2, 6, 4) (root vectors as the frame of the complex pair: the standard route, recalled)')
chk('bit==std', 'jrd·14', (PE['h_3(O)'][0]['r'], PE['h_3(O)'][0]['a'], PE['h_3(O)'][0]['b']) == RF['Albert (e7)'][1:4] and (PE['A_5(R)'][0]['r'], PE['A_5(R)'][0]['a'], PE['A_5(R)'][0]['b']) == RF['a_5 (so(10))'][1:4]
    and (PE['M_(2,3)(R)'][0]['r'], PE['M_(2,3)(R)'][0]['a'], PE['M_(2,3)(R)'][0]['b']) == RF['M_(3,2) (sl(5))'][1:4],
    'the explicit frames of h_3(O), A_5(R) and M_(2,3)(R) give the same (r, a, b) as the roots of e7, so(10) and sl(5)')
# controls of C
cA, dA, tA = mat_triple_ops(2, 3); col = peirce(cA, dA, [[F(x) for x in mat_unit(2, 3, 0).ravel()], [F(x) for x in mat_unit(2, 3, 1).ravel()]], tA)
cB, dB, tB = mat_triple_ops(3, 3); nmn = peirce(cB, dB, [[F(x) for x in (mat_unit(3, 3, 0) + mat_unit(3, 3, 4)).ravel()], [F(x) for x in mat_unit(3, 3, 8).ravel()]], tB)
inc = peirce(cB, dB, [[F(x) for x in mat_unit(3, 3, 0).ravel()], [F(x) for x in mat_unit(3, 3, 4).ravel()]], tB)
ntr = peirce(cB, dB, [[F(x) for x in (2 * mat_unit(3, 3, 0)).ravel()]], tB)
DopC, dimC, tripC = jordan_triple_ops(JT, SUB16); Duu = DopC(u16, u16)
v2u = dimC - frank([[Duu[i][j] - 2 * int(i == j) for j in range(dimC)] for i in range(dimC)])
DopS, dimS, tripS = jordan_triple_ops(JTS['JT'], SUB16); DuS = DopS(u16, u16)
v2s = dimS - frank([[DuS[i][j] - 2 * int(i == j) for j in range(dimS)] for i in range(dimS)])
eS = [(a + b) / 2 for a, b in zip(u16, w16)]; nilS = not any(any(row) for row in DopS(eS, eS))
iso_tab = []
for a_ in range(1, 8):
    for b_ in range(1, 8):
        wa = np.zeros(NJ, dtype=np.int64); wa[3 + a_] = 1; wb = np.zeros(NJ, dtype=np.int64); wb[3 + b_] = 1; uu = np.zeros(NJ, dtype=np.int64); uu[3] = 1
        iso_tab.append(np.array_equal(D2(wa, uu, JT) @ wb, -4 * int(a_ == b_) * uu))
chk('ctl', 'jrd·15', not col['orth'] and not col['ok'] and not nmn['ok'] and nmn['dims'][(1, 1)] == 4 and inc['V00'] == 1 and not inc['ok'] and not ntr['tri'] and v2u == 8 and all(iso_tab) and v2s == 8 and nilS,
    'controls: E11, E12 in M_(2,3) are colinear (not orthogonal); E11 + E22 in M_(3,3) is not minimal (V_11 of dimension 4); E11, E22 in M_(3,3) is not a frame (V_00 = 1); 2 E11 is not a tripotent; '
    'in the compact Albert algebra the Peirce 1/2 space of E11 (16) has the maximal tripotent u = (x12 = 1) with V_2(u) of dimension %d, and for the imaginary units w_a of x12, '
    '{w_a u w_b} = -2 delta_ab u: the u-isotope form is negative definite on them, so no idempotent (u + w)/2; in the split Albert algebra the same u has V_2(u) of dimension %d and (u + w)/2 '
    '(w a split unit, w^2 = 1) has D(e,e) = 0, so it is not a tripotent: this Peirce 1/2 space with the restricted product gives no frame of the type V kind (type V is taken from the roots, jrd·14)' % (v2u, v2s))

# ===================================================================================== D. the meet of stab h2(O) and stab h3(C) in f4
head('D. [bit] in f4: the derivations preserving A = h2(O) and those preserving B = h3(C) meet in a 12-dimensional algebra (CAND-133, LNB-111)')
ASET = [0, 1] + list(range(3, 11)); BSET = [0, 1, 2, 3, 4, 11, 12, 19, 20]           # C = span(e0, e1) in each off-diagonal entry
def stab_rows(S):
    notS = [p for p in range(NJ) if p not in S]
    return [[int(BD[p * NJ + q, k]) for k in range(52)] for p in notS for q in S]
nA, nB = fnull(stab_rows(ASET), 52), fnull(stab_rows(BSET), 52); nAB = fnull(stab_rows(ASET) + stab_rows(BSET), 52)
def as_mat(c):
    den = 1
    for x in c: den = den * x.denominator // math.gcd(den, x.denominator)
    return sum(int(x * den) * D for x, D in zip(c, DER))
SM12 = [as_mat(c) for c in nAB]
brk12 = [X @ Y - Y @ X for i, X in enumerate(SM12) for Y in SM12[i + 1:]]
der12 = frank([X.ravel().tolist() for X in brk12]) if brk12 else 0
cen_rows = []
for l_ in range(len(SM12)):
    Cm = np.array([(SM12[k] @ SM12[l_] - SM12[l_] @ SM12[k]).ravel() for k in range(len(SM12))]).T
    cen_rows += [row.tolist() for row in Cm if row.any()]
cen12 = fnull(cen_rows, len(SM12)) if SM12 else []
chk('bit', 'jrd·16', len(nA) == 36 and len(nB) == 16 and len(nAB) == 12 and der12 == 11 and len(cen12) == 1,
    'exact nullspaces on the 52 coefficients: stab A = %d (so(9), as elad·21), stab B = %d (su(3) + su(3)), their meet %d with a centre of dimension %d and a derived algebra of dimension %d: '
    'su(3) + su(2) + u(1) at the level of Lie algebras (numerically baez·O3e-g); the groups and Krasnov\'s characterisation are not computed' % (len(nA), len(nB), len(nAB), len(cen12), der12))
SET2 = [0, 1, 2, 3, 4, 5, 6, 11, 12, 13, 14, 19, 20, 21, 22]                    # h3(H) with H = span(e0..e3): a control
nH = fnull(stab_rows(ASET) + stab_rows(SET2), 52)
chk('ctl', 'jrd·17', len(nH) != 12 and len(fnull(stab_rows(SET2), 52)) != 16,
    'control: with h3(H) in place of h3(C) the stabiliser has dimension %d and the meet with stab A dimension %d (not 16 and 12)' % (len(fnull(stab_rows(SET2), 52)), len(nH)))

finish(STEP)
