#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""composition_basis.py: composition algebras in exact integers, decided on finite sets of elements.

Statement. The Cayley-Dickson algebras of dimension 1, 2, 4, 8 (R, C, H, O) are composition algebras, N(xy) = N(x) N(y) for ALL x, y,
and alternative, x(xy) = (xx)y and (yx)x = y(xx) for ALL x, y; at dimension 16 (the sedenions) both fail. The split octonions written as
Zorn vector-matrices have a multiplicative norm of signature (4,4) and are alternative. Hurwitz's theorem (no composition algebra over R
in any other dimension) and the classification (R, C, H, O or a split form) are recalled, not computed.

Why finitely many elements decide it. Phi(x, y) = N(xy) - N(x) N(y) is a quadratic form in x for fixed y and a quadratic form in y for
fixed x; a quadratic form is fixed by its values at the e_i and the e_i + e_j (polarisation). So Phi = 0 on all pairs from
X = {e_i} + {e_i + e_j} + {e_i - e_j} implies Phi = 0 everywhere. The associator A(x,y,z) = (xy)z - x(yz) is trilinear, so the algebra is
alternative iff A is alternating on the basis: A(e_i,e_i,e_k) = A(e_k,e_i,e_i) = 0 and A changes sign under a swap of its first two or
its last two slots, for all basis triples. Products of two basis elements are +-1 times one basis element, so on basis pairs the norm is
multiplicative in every dimension, the sedenions included: the basis pairs alone cannot fail, the two-term sums can.

  [bit]      the Atlas's octonions: the twisted group algebra of Z_2^3 on the 3-bit labels, e_a e_b = F(a,b) e_(a xor b), with the
             Albuquerque-Majid cochain F(x,y) = (-1)^(sum_(i<=j) x_i y_j + y1 x2 x3 + x1 y2 x3 + x1 x2 y3) (the cochain of bd·alg·14 and
             check_T6 OCT); its associator sign is (-1)^det(a,b,c); composition and alternativity on the finite sets above;
             the split octonions' Zorn table read on the eight labels of Lambda R^3: every non-zero product of two labels is the join
             (disjoint labels) or the meet (labels covering the three bits).
  [std]      the Cayley-Dickson doubling written out, (a,b)(c,d) = (ac + g d* b, da + b c*), conjugation (a,b)* = (a*, -b), norm
             N(a,b) = N(a) - g N(b), with g = -1 at every level (R, C, H, O, sedenions) and g = +1 at the last level (split octonions);
             Zorn's vector-matrix product [[a, v], [w, b]] [[a', v'], [w', b']] = [[a a' + v.w', a v' + b' v - w x w'],
             [a' w + b w' + v x v', b b' + w.v']] with N = a b - v.w.
  [bit==std] the Cayley-Dickson octonions also multiply the labels by xor, have associator sign (-1)^det(a,b,c) and are the twisted
             group algebra above after the signs e_a -> s_a e_a (an explicit isomorphism, found by search over the 128 sign vectors).
  [ctl]      the sedenions: the norm is not multiplicative on two-term sums (zero divisors (e_i + e_j)(e_k + e_l) = 0 are found; for the
             explicit pair x = e_1 + e_10, y = e_4 - e_15 the line asserts N(xy) != N(x)N(y)) and the algebra is not alternative; a doubling
             with the order of one product swapped (da -> ad) or with g = +1 read with the definite norm fails composition at dimension 8;
             a wrong Albuquerque-Majid cochain (one term dropped) is not alternative. A [ctl] line passes only when its wrong version fails:
             the wrong version of the explicit pair is a basis pair, on which the norm is multiplicative in every dimension (see above).

Scope: dimensions 1, 2, 4, 8, 16 and the split octonions; exact integers; random integer vectors as a second witness.
The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults M1-M8 do not reach it; its controls are its own.

  python3 composition_basis.py      one line per check; last line FAILS (COMP): none; exit code 1 on a failure
  python3 composition_basis.py --fault basis-pair   the wrong version of the dimension-16 control (a basis pair in place of the explicit
                                                    pair of two-term sums); exit code 1
"""
import itertools, random, sys

# ---------------------------------------------------------------- the three helpers of selfcheck/gravity/b1lib.py
FAULT = sys.argv[sys.argv.index('--fault') + 1] if '--fault' in sys.argv else None
FAILS = []
def chk(tag, cond, msg):
    print(('  ok   ' if cond else '  FAIL ') + '[' + tag + '] ' + msg)
    if not cond: FAILS.append(msg)
    return bool(cond)
def head(s):
    print('\n' + s)
def finish(STEP):
    print('\nFAILS (%s): %s' % (STEP, '; '.join(FAILS) if FAILS else 'none'))
    sys.exit(1 if FAILS else 0)

# ---------------------------------------------------------------- [std] Cayley-Dickson doubling, exact integers
def cd_conj(x):
    if len(x) == 1: return list(x)
    h = len(x) // 2
    return cd_conj(x[:h]) + [-t for t in x[h:]]
def cd_mul(x, y, gs, swap=False):
    """product in the algebra of dimension len(x) = 2^len(gs); gs[k] is g of the doubling from 2^k to 2^(k+1)"""
    if len(x) == 1: return [x[0] * y[0]]
    h = len(x) // 2; g = gs[-1]; sub = gs[:-1]
    a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    ac = cd_mul(a, c, sub); dsb = cd_mul(cd_conj(d), b, sub)
    da = cd_mul(a, d, sub) if swap else cd_mul(d, a, sub)        # swap: the wrong order a d (a control)
    bcs = cd_mul(b, cd_conj(c), sub)
    return [s + g * t for s, t in zip(ac, dsb)] + [s + t for s, t in zip(da, bcs)]
def cd_norm_signs(gs):
    """N(x) = sum_a n_a x_a^2 with n = (n_lower, -g n_lower) at every doubling"""
    n = [1]
    for g in gs: n = n + [-g * t for t in n]
    return n

def show(v):
    """a sparse vector {index: +-1} as e_i + e_j or e_i - e_j"""
    out = ''
    for i, c in sorted(v.items()):
        out += (('' if c > 0 else '-') if not out else (' + ' if c > 0 else ' - ')) + f'e_{i}'
    return out

def table(mul, dim, zero_ok=False):
    """structure constants on the basis: mul(e_a, e_b) = s e_c, returns {(a, b): (s, c)}; asserts the product of two basis elements is
    +-1 times one basis element (or 0, stored as s = 0, when zero_ok: the Zorn table has zero products)"""
    T = {}
    for a in range(dim):
        for b in range(dim):
            ea = [0] * dim; ea[a] = 1; eb = [0] * dim; eb[b] = 1
            p = mul(ea, eb); nz = [(i, v) for i, v in enumerate(p) if v]
            if zero_ok and not nz: T[(a, b)] = (0, 0); continue
            assert len(nz) == 1 and abs(nz[0][1]) == 1, ('basis product', a, b, p)
            T[(a, b)] = (nz[0][1], nz[0][0])
    return T
def tmul(T, x, y):
    """product of sparse vectors {index: coefficient} through the basis table"""
    out = {}
    for a, xa in x.items():
        for b, yb in y.items():
            s, c = T[(a, b)]
            if s: out[c] = out.get(c, 0) + s * xa * yb
    return {k: v for k, v in out.items() if v}
def norm(ns, x): return sum(ns[a] * v * v for a, v in x.items())
def two_term(dim):
    X = [{i: 1} for i in range(dim)]
    for i in range(dim):
        for j in range(i + 1, dim):
            X.append({i: 1, j: 1}); X.append({i: 1, j: -1})
    return X
def composition_failures(T, ns, dim):
    X = two_term(dim); bad = 0; zd = None
    for x in X:
        nx = norm(ns, x)
        for y in X:
            p = tmul(T, x, y)
            if norm(ns, p) != nx * norm(ns, y):
                bad += 1
                if zd is None and not p: zd = (x, y)
    return len(X), bad, zd
def basis_pair_failures(T, ns, dim):
    return sum(1 for a in range(dim) for b in range(dim) if norm(ns, tmul(T, {a: 1}, {b: 1})) != norm(ns, {a: 1}) * norm(ns, {b: 1}))
def assoc(T, a, b, c):
    l = tmul(T, tmul(T, {a: 1}, {b: 1}), {c: 1}); r = tmul(T, {a: 1}, tmul(T, {b: 1}, {c: 1}))
    out = dict(l)
    for k, v in r.items(): out[k] = out.get(k, 0) - v
    return {k: v for k, v in out.items() if v}
def neg(u): return {k: -v for k, v in u.items()}
def alternating_failures(T, dim):
    bad = 0
    for i, j, k in itertools.product(range(dim), repeat=3):
        A = assoc(T, i, j, k)
        if A != neg(assoc(T, j, i, k)) or A != neg(assoc(T, i, k, j)): bad += 1
    for i, k in itertools.product(range(dim), repeat=2):
        if assoc(T, i, i, k) or assoc(T, k, i, i): bad += 1
    return bad
def random_composition(T, ns, dim, seed, trials=40):
    rng = random.Random(seed); bad = 0
    for _ in range(trials):
        x = {i: rng.randint(-9, 9) for i in range(dim)}; y = {i: rng.randint(-9, 9) for i in range(dim)}
        x = {k: v for k, v in x.items() if v}; y = {k: v for k, v in y.items() if v}
        if norm(ns, tmul(T, x, y)) != norm(ns, x) * norm(ns, y): bad += 1
    return bad

# ---------------------------------------------------------------- [bit] the twisted group algebra of Z_2^3 (Albuquerque-Majid)
def bits3(x): return (x & 1, (x >> 1) & 1, (x >> 2) & 1)
def fAM(x, y, drop=False):
    X, Y = bits3(x), bits3(y)
    s = sum(X[i] * Y[j] for i in range(3) for j in range(i, 3)) + Y[0] * X[1] * X[2] + X[0] * Y[1] * X[2]
    if not drop: s += X[0] * X[1] * Y[2]                         # drop: a wrong cochain, one cubic term missing (a control)
    return s % 2
def am_table(drop=False): return {(a, b): ((-1) ** fAM(a, b, drop), a ^ b) for a in range(8) for b in range(8)}
def det3(a, b, c):
    A = [bits3(a), bits3(b), bits3(c)]
    return (A[0][0] * (A[1][1] * A[2][2] + A[1][2] * A[2][1]) + A[0][1] * (A[1][0] * A[2][2] + A[1][2] * A[2][0])
            + A[0][2] * (A[1][0] * A[2][1] + A[1][1] * A[2][0])) % 2
def assoc_sign(T, a, b, c):
    """(e_a e_b) e_c = phi(a,b,c) e_a (e_b e_c) on basis elements; phi = +-1"""
    l = tmul(T, tmul(T, {a: 1}, {b: 1}), {c: 1}); r = tmul(T, {a: 1}, tmul(T, {b: 1}, {c: 1}))
    (kl, vl), = l.items(); (kr, vr), = r.items()
    assert kl == kr
    return vl * vr

# ---------------------------------------------------------------- [std] Zorn's vector-matrices
def cross(u, v): return [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]]
def dot(u, v): return sum(s * t for s, t in zip(u, v))
def zorn_mul(x, y):
    """x = [a, v1, v2, v3, w1, w2, w3, b] for [[a, v], [w, b]]"""
    a, v, w, b = x[0], x[1:4], x[4:7], x[7]; a2, v2, w2, b2 = y[0], y[1:4], y[4:7], y[7]
    top = a * a2 + dot(v, w2)
    vv = [a * s + b2 * t - u for s, t, u in zip(v2, v, cross(w, w2))]
    ww = [a2 * s + b * t + u for s, t, u in zip(w, w2, cross(v, v2))]
    bot = b * b2 + dot(w, v2)
    return [top] + vv + ww + [bot]
def zorn_norm_signature():
    """N = a b - v.w as a symmetric matrix on R^8 (doubled to stay integral): eigenvalue signs by pivots"""
    M = [[0] * 8 for _ in range(8)]
    M[0][7] = M[7][0] = 1
    for i in range(3): M[1 + i][4 + i] = M[4 + i][1 + i] = -1
    # each 2x2 block [[0, s], [s, 0]] has eigenvalues +s and -s: one positive and one negative each
    blocks = [(0, 7)] + [(1 + i, 4 + i) for i in range(3)]
    covered = sorted(sum(([p, q] for p, q in blocks), []))
    ok = covered == list(range(8)) and all(M[p][q] != 0 and M[p][p] == 0 and M[q][q] == 0 for p, q in blocks) \
        and all(M[i][j] == 0 for i in range(8) for j in range(8) if (i, j) not in blocks and (j, i) not in blocks)
    return (4, 4) if ok else None
ZLAB = [0b000] + [1 << i for i in range(3)] + [0b111 ^ (1 << i) for i in range(3)] + [0b111]    # alpha, a_i = {i}, a'_i = complement, alpha'

def main():
    head('[std] Cayley-Dickson algebras of dimension 1, 2, 4, 8, 16 (g = -1 at every doubling), exact integers')
    tabs = {}
    for k in range(0, 5):
        dim = 1 << k; gs = (-1,) * k
        T = table(lambda x, y: cd_mul(x, y, gs), dim); ns = cd_norm_signs(gs); tabs[dim] = (T, ns)
        nX, bad, zd = composition_failures(T, ns, dim); bp = basis_pair_failures(T, ns, dim)
        alt = alternating_failures(T, dim); rnd = random_composition(T, ns, dim, 100 + k)
        xor = all(c == a ^ b for (a, b), (s, c) in T.items())
        if dim <= 8:
            chk('std', bp == 0 and bad == 0 and rnd == 0,
                f'dim {dim}: N(xy) = N(x)N(y) on all {dim * dim} basis pairs and on all {nX * nX} pairs from the {nX} elements e_i, e_i +- e_j '
                f'(by polarisation: for ALL x, y); 40 random integer pairs agree')
            chk('std', alt == 0, f'dim {dim}: the associator is alternating on all {dim ** 3} basis triples: x(xy) = (xx)y and (yx)x = y(xx) for ALL x, y')
        else:
            x16, y16 = ({1: 1, 10: 1}, {4: 1, 15: -1}) if FAULT != 'basis-pair' else ({1: 1}, {4: 1})    # the explicit pair of two-term sums (fault: a basis pair, on which the norm is multiplicative)
            nx16, ny16, nxy16 = norm(ns, x16), norm(ns, y16), norm(ns, tmul(T, x16, y16))
            chk('ctl', nxy16 != nx16 * ny16, f'dim 16: for x = {show(x16)} and y = {show(y16)} the norm is not multiplicative: N(x) = {nx16}, N(y) = {ny16}, N(xy) = {nxy16} != N(x)N(y) = {nx16 * ny16} (the identity holds on every pair at dimensions 1, 2, 4, 8)')
            chk('ctl', bad > 0 and zd is not None and rnd > 0,
                f'dim 16 (sedenions): N(xy) != N(x)N(y) on {bad} of {nX * nX} pairs of two-term sums, a zero divisor ({zd[0]}) ({zd[1]}) = 0, '
                f'and on {rnd} of 40 random integer pairs: not a composition algebra')
            chk('ctl', alt > 0, f'dim 16: the associator is not alternating ({alt} failing basis conditions): not alternative')
        chk('std', xor, f'dim {dim}: e_a e_b = +-e_(a xor b) on every basis pair (the labels multiply by xor)')
    head('[ctl] wrong doublings at dimension 8 (read with the definite norm)')
    for what, gs, swap in (('the order of one product swapped (d a -> a d)', (-1, -1, -1), True), ('g = +1 at the last doubling, definite norm', (-1, -1, 1), False)):
        T = table(lambda x, y: cd_mul(x, y, gs, swap), 8); ns = [1] * 8
        nX, bad, zd = composition_failures(T, ns, 8)
        chk('ctl', bad > 0, f'{what}: N(xy) != N(x)N(y) on {bad} of {nX * nX} pairs of two-term sums')
    head('[std] split octonions: Cayley-Dickson with g = +1 at the last doubling (norm N(a) - N(b)) and Zorn vector-matrices')
    gs = (-1, -1, 1); T = table(lambda x, y: cd_mul(x, y, gs), 8); ns = cd_norm_signs(gs)
    nX, bad, zd = composition_failures(T, ns, 8); alt = alternating_failures(T, 8)
    chk('std', bad == 0 and alt == 0 and sorted(ns) == [-1] * 4 + [1] * 4,
        f'split Cayley-Dickson octonions: N(xy) = N(x)N(y) on all {nX * nX} pairs (for ALL x, y), alternating associator on all 512 basis triples, norm signature (4,4)')
    Z = table(zorn_mul, 8, zero_ok=True)
    # the Zorn norm a b - v.w is not diagonal in the coordinate basis: use the polarised test with the true norm
    def zn(x): v = [x.get(i, 0) for i in range(8)]; return v[0] * v[7] - dot(v[1:4], v[4:7])
    X = two_term(8); badz = sum(1 for x in X for y in X if zn(tmul(Z, x, y)) != zn(x) * zn(y))
    altz = alternating_failures(Z, 8); unit = {0: 1, 7: 1}
    unit_ok = all(tmul(Z, unit, {i: 1}) == {i: 1} and tmul(Z, {i: 1}, unit) == {i: 1} for i in range(8))
    nil = all(not tmul(Z, {i: 1}, {i: 1}) for i in range(1, 7))
    chk('std', badz == 0 and altz == 0 and unit_ok and nil and zorn_norm_signature() == (4, 4),
        f'Zorn vector-matrices: N = ab - v.w is multiplicative on all {len(X) ** 2} pairs (for ALL x, y), the associator is alternating on all 512 basis triples, '
        'unit 1 = diag(1, 1), the six vector units square to 0 (zero divisors: split), N has signature (4,4)')
    joins = meets = zeros = 0; rule = True
    for i in range(8):
        for j in range(8):
            p = tmul(Z, {i: 1}, {j: 1}); x, y = ZLAB[i], ZLAB[j]
            if not p: zeros += 1; continue
            (c, v), = p.items(); lab = ZLAB[c]
            if x & y == 0 and lab == x | y: joins += 1
            elif x | y == 0b111 and lab == x & y: meets += 1
            else: rule = False
    chk('bit', rule and (joins, meets, zeros) == (16, 16, 32),
        f'the Zorn table on the labels of Lambda R^3 (alpha = 000, a_i = {{i}}, a\'_i = complement of {{i}}, alpha\' = 111): every non-zero product of two labels is +- the join '
        f'(disjoint labels) or the meet (labels covering the three bits): join {joins}, meet {meets}, zero {zeros} of 64')
    head('[bit] the Atlas\'s octonions: twisted group algebra of Z_2^3 with the Albuquerque-Majid cochain')
    A = am_table(); nsA = [1] * 8
    sq = all(A[(a, a)][0] == -1 for a in range(1, 8)) and A[(0, 0)][0] == 1
    phi = all(assoc_sign(A, a, b, c) == (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8))
    nX, bad, zd = composition_failures(A, nsA, 8); alt = alternating_failures(A, 8); rnd = random_composition(A, nsA, 8, 7)
    ndet = sum(det3(a, b, c) for a in range(8) for b in range(8) for c in range(8))
    chk('bit', sq and phi and ndet == 168, f'e_a^2 = -1 for every non-zero label; associator sign (e_a e_b) e_c = (-1)^det(a,b,c) e_a (e_b e_c) on all 512 triples (-1 on {ndet})')
    chk('bit', bad == 0 and rnd == 0, f'N(xy) = N(x)N(y) on all {nX * nX} pairs from e_i, e_i +- e_j (for ALL x, y) and on 40 random integer pairs')
    chk('bit', alt == 0, 'the associator is alternating on all 512 basis triples: alternative')
    Aw = am_table(drop=True)
    chk('ctl', alternating_failures(Aw, 8) > 0, 'a wrong cochain (the term x1 x2 y3 dropped) gives an algebra that is not alternative')
    head('[bit==std] the Cayley-Dickson octonions against the twisted group algebra')
    T8 = tabs[8][0]
    phi_cd = all(assoc_sign(T8, a, b, c) == (-1) ** det3(a, b, c) for a in range(8) for b in range(8) for c in range(8))
    found = None
    for bits_ in range(1 << 7):
        s = [1] + [(-1) ** ((bits_ >> i) & 1) for i in range(7)]
        if all(T8[(a, b)][0] == s[a] * s[b] * s[a ^ b] * A[(a, b)][0] for a in range(8) for b in range(8)): found = s; break
    chk('bit==std', phi_cd, 'the Cayley-Dickson octonions have the same associator sign (-1)^det(a,b,c) on all 512 label triples')
    chk('bit==std', found is not None, f'e_a -> s_a e_a with s = {found} maps the twisted group algebra onto the Cayley-Dickson octonions (all 64 products): one algebra')
    finish('COMP')

if __name__ == '__main__':
    main()
