#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chain_closure.py: the standard routes closed, the commutants of the projective covers, the map of Atiyah, Bott and Shapiro themselves, and
the algebraic direct limit of the chain of blocks on the labels (round 13, proofs pass 11c; docs/round13/PLAN.md, docs/round13/pass11c/BEFORE.md).
     python3 chain_closure.py [--fault COMMD|WRONGINDEX|OMEGA2|COUNTQ|CENTREEVEN]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators
of square +1 first, then q of square -1, then r null (core_check.sig); the type table is core_check.TYPE (by c = p - q mod 8).  The three
clock-0 blocks of row 8 are (8,0,0), (0,8,0), (4,4,0) (GEN-009), placed after the generators they multiply; the inclusions e_i -> e_i Omega.
cc.COV  the 120 cells (p,q,r), r >= 1, n <= 8: B = f A f for the bit rule's idempotent f (the quotient's, abs_ring.py's construction): its
        dimension as the trace of the idempotent map x -> f x f, its part f J f (a nilpotent two-sided ideal, its powers), the residue f Q f
        with its type by the method of chain_blocks.py (centre, squares of central elements, the count: the signature of the trace form);
        End_A(A f) on the module's own matrices (the exact commutant with its basis, the radical of its trace form).  [ctl] the commutant
        taken as D.
cc.LIFT the same cells: the 2^w idempotents of the quotient's commuting set (LNC-059) in the cell, the lift A -> A/J, the other lifts
        e + (1 - e) x e and their conjugating units, the classes of the projective covers, Nakayama on the covers (cyclic submodules, exact
        modular ranks).  [ctl] the generic e + x, an element of J f.
cc.STD  the standard routes where the bit route stood alone, no label: the map's signs for n = 7, 8 on every pair (monomial matrices, the
        mixed-product rule, compared factor by factor; two cases also as full matrices); the 63 third-stage idempotents of GEN-024 as dense
        integer matrices up to 4096 x 4096 (P^2 = P, ranks by numpy); the row-8 start cells' stages 0 and 1 (period_map.py's / null_stages.py's
        matrix route).  [ctl] one anticommuting pair, as a dense matrix.
cc.REF  the vectorised minimal left ideals against abs_ring.py's build_cell (copied, with bitcliff.py's engine and solid_cube.py's exact
        commutant and classify) on a named sample of 12 cells with 12 to 14 generators.
cc.LIM  the algebraic direct limit on the labels: the M256 chain's stage k is the M16 chain's stage 2k (the same eps, the same table), its
        inclusion the composite of two steps; the union of the stages as classes of pairs (k, x), x a multivector (Fractions); the scalar
        part as a trace preserved by every inclusion, its values on the stages' minimal idempotents against GEN-026.  [ctl] the wrong index.
cc.ABS  Lawson-Michelsohn's (ABS's) two-step isomorphisms on the labels, e_i -> e_i omega_2 with a block of two after every cell n <= 8; the
        mirror exactly when omega_2^2 = -1; four steps composed, against the one-step map e_i -> e_i Omega of GEN-017 on every label, for ABS's
        own routes and for all 41 sequences with an even number of mirrors; whether the grade automorphism is inner.  [ctl] an odd number of
        mirrors; a null block.
cc.C24  the count sum e_a^2 = Re[(1 + i)^p (1 - i)^(q+1)] (exact Gaussian integers) against the enumeration of the labels for the 969 cells
        n <= 16 and at 24 generators; the centre by the commutation parity of every label with every generator (popcounts, no product).
Not computed here (stated, not checked): the C*-completion of either chain and the CAR algebra as a C*-algebra; the classifications of
Elliott and Glimm (complex) and of Giordano and Stacey (real) for the completed limits, cited from docs/round13/SOURCES.md; End_A(A f) =
(f A f)^op, idempotent lifting, Nakayama's lemma and the continuity of K_0 in general (recalled; computed here on the finite cells only).
--fault options (each a wrong version in the main lines, which must then FAIL; exit 1): COMMD the commutant of a projective cover taken as D
   (no radical); WRONGINDEX the M256 chain's stage k set beside the M16 chain's stage k; OMEGA2 omega_2^2 taken from the wrong cell (+1 for
   every block of two); COUNTQ the closed form of the count with (1 - i)^q; CENTREEVEN the top label asserted central for even n.
Command: python3 -I -B selfcheck/proofs/chain_closure.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, io, time, random, itertools, contextlib
from fractions import Fraction as Fr
from math import comb, gcd, isqrt
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
_steps = os.path.join(_selfcheck, 'steps15_17')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (_steps, 'bitcliff.py'), (_here, 'solid_cube.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck, _steps, _here):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
from bitcliff import Alg                                                   # abs_ring.py's engine for its build_cell (copied below, cc.REF)
_argv = sys.argv; sys.argv = [_argv[0]]
try:
    with contextlib.redirect_stdout(io.StringIO()):
        from solid_cube import commutant_basis, classify                  # the exact commutant abs_ring.py uses (as period_map.py imports it)
finally:
    sys.argv = _argv

# ------------------------------------------------------------------------------------------------ check lines (as null_stages.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish(name):
    tags = ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT))
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), tags, len(FAILS)))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    print('chain_closure: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('COMMD', 'WRONGINDEX', 'OMEGA2', 'COUNTQ', 'CENTREEVEN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261017); NPR = np.random.default_rng(20261017)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
def cells(n): return [(p, q, n - p - q) for p in range(n + 1) for q in range(n + 1 - p)]
def cstr(c): return '(%s)' % ','.join(str(x) for x in c)
def clock(c): return (c[0] - c[1]) % 8
pc = lambda x: bin(x).count('1')
BLOCKS = [(8, 0, 0), (0, 8, 0), (4, 4, 0)]                                 # the three clock-0 cells of row 8 (GEN-009)
NULLC = [c for n in range(1, 9) for c in cells(n) if c[2] >= 1]           # the 120 cells with null generators, n <= 8
DD = {'R': 1, 'C': 2, 'H': 4}

# ------------------------------------------------------------------------------------------------ the kernel's formula, vectorised (null_stages.py, segmented beyond 16 generators)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    """E[m] = product of eps_i over the bits of m, for every mask m < 2^N"""
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i (null_stages.py: beyond 16 generators the
    product of the eps is read from the masks of 8-bit segments)"""
    eps = tuple(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)):
        par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    if len(eps) <= 16:
        if eps not in _EM: _EM[eps] = emask(eps)
        return (1 - 2 * (par & 1)) * _EM[eps][A & B]
    E = 1 - 2 * (par & 1); AB = A & B
    for o in range(0, len(eps), 8):
        seg = eps[o:o + 8]
        if seg not in _EM: _EM[seg] = emask(seg)
        E = E * _EM[seg][(AB >> o) & ((1 << len(seg)) - 1)]
    return E
_TB = {}
def table(eps):
    """the full sign table of a cell with at most 8 generators (null_stages.py), int64"""
    eps = tuple(eps)
    if eps not in _TB:
        a = np.arange(1 << len(eps), dtype=np.int64); _TB[eps] = s_vec(eps, a[:, None], a[None, :])
    return _TB[eps]

# ------------------------------------------------------------------------------------------------ types from invariants (null_stages.py / period_map.py / chain_blocks.py)
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from the dimension, the number c of simple summands, whether the centre is complex, and the count fs (the
    signature of the trace form: c m for D = R, 0 for C, -2 c m for H)"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D])
    m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def ltype_split(eps, nlow):
    """the type of a non-degenerate cell without enumerating its labels (pass 8c's parity reduction and graded diagonal; period_map.py),
    returned with the number of central labels and the count sum e_a^2 it reads"""
    e1, e2 = tuple(eps[:nlow]), tuple(eps[nlow:]); n1, n2 = len(e1), len(e2)
    a1 = np.arange(1 << n1, dtype=np.int64); a2 = np.arange(1 << n2, dtype=np.int64); d1 = s_vec(e1, a1, a1); d2 = s_vec(e2, a2, a2)
    p1 = popv(a1) & 1; p2 = popv(a2) & 1
    E1, O1, E2, O2 = int(d1[p1 == 0].sum()), int(d1[p1 == 1].sum()), int(d2[p2 == 0].sum()), int(d2[p2 == 1].sum())
    def cen(a, n_, add_above, add_below):
        ok = np.ones(len(a), dtype=bool)
        for i in range(n_): ok &= ((popv(a >> (i + 1)) + add_above - popv(a & ((1 << i) - 1)) - add_below) & 1) == 0
        return ok
    central = []
    for par1 in (0, 1):
        for par2 in (0, 1):
            L = np.flatnonzero(cen(a1, n1, par2, 0) & (p1 == par1)); H = np.flatnonzero(cen(a2, n2, 0, par1) & (p2 == par2))
            central += [int(x) | (int(y) << n1) for x in L for y in H]
    K = BR(eps); cplx = any(K.s(c_, c_) == -1 for c_ in central)
    return type_from_inv(1 << (n1 + n2), len(central) // 2 if cplx else len(central), cplx, E1 * E2 + E1 * O2 + O1 * E2 - O1 * O2), len(central), E1 * E2 + E1 * O2 + O1 * E2 - O1 * O2
def clock_type(p, q):
    """the type of Cl(p,q) from the Atlas's type table core_check.TYPE and the dimension 2^(p+q) (period_map.py)"""
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2)
    assert r == 0 and m * m == m2
    return (D, m, c)

# ------------------------------------------------------------------------------------------------ monomial matrices (period_map.py / null_stages.py): M[rows[c], c] = vals[c]; vals 0 allowed
XM = np.array([[0, 1], [1, 0]], dtype=np.int64); JM = np.array([[0, -1], [1, 0]], dtype=np.int64); ZM = np.diag([1, -1]).astype(np.int64)
I2 = np.eye(2, dtype=np.int64); SMINUS = np.array([[0, 0], [1, 0]], dtype=np.int64)
def kron_all(ms):
    M = np.ones((1, 1), dtype=np.int64)
    for m in ms: M = np.kron(M, m)
    return M
def site_gens(eps, null=None):
    """one generator per site: Z on the sites before it, X (square +1), J (square -1) or a nilpotent (square 0: X + J as chain_blocks.py,
    or sigma^- = [[0,0],[1,0]]) on its own; no label"""
    n = len(eps); N0 = XM + JM if null is None else null
    return [kron_all([ZM] * k + [{1: XM, -1: JM, 0: N0}[e]] + [I2] * (n - k - 1)) for k, e in enumerate(eps)]
def block_mats(c8):
    """the blocks as real 16 x 16 Kronecker matrices, no label (chain_blocks.py): Cl(4,4) from X and J on four sites; Cl(8,0) and Cl(0,8) by
    the four-shift (f_j w with w = f_1 f_2 f_3 f_4, resp. e_i w' with w' = e_1 e_2 e_3 e_4)"""
    E = [kron_all([ZM] * k + [XM] + [I2] * (3 - k)) for k in range(4)]; F = [kron_all([ZM] * k + [JM] + [I2] * (3 - k)) for k in range(4)]
    if c8 == (4, 4, 0): return E + F
    if c8 == (8, 0, 0): w = F[0] @ F[1] @ F[2] @ F[3]; return E + [f @ w for f in F]
    if c8 == (0, 8, 0): w = E[0] @ E[1] @ E[2] @ E[3]; return [e @ w for e in E] + F
    raise ValueError(c8)
def to_mono(M):
    nz = M != 0; assert bool(np.all(nz.sum(0) <= 1))
    r = np.argmax(nz, axis=0).astype(np.int64); return r, M[r, np.arange(M.shape[1])].astype(np.int64)
def m_mul(A, B): return A[0][B[0]], A[1][B[0]] * B[1]
def m_kron(A, B): m = len(B[0]); return (A[0][:, None] * m + B[0][None, :]).ravel(), (A[1][:, None] * B[1][None, :]).ravel()
def m_eye(d): return np.arange(d, dtype=np.int64), np.ones(d, dtype=np.int64)
def m_eq(A, B): return np.array_equal(A[1], B[1]) and bool(np.all((A[0] == B[0]) | (A[1] == 0)))
def m_neg(A): return A[0], -A[1]
def m_prod(mods, m):
    out = m_eye(m)
    for R in mods: out = m_mul(out, R)
    return out
def m_dense(A):
    m = len(A[0]); M = np.zeros((m, m), dtype=np.int64); M[A[0], np.arange(m)] = A[1]; return M
def rel_ok(mods, eps, m):
    """the relations R_i R_j + R_j R_i = 2 eps_i delta_ij on monomial matrices with zero columns allowed (a null generator: R_i^2 = 0)"""
    I = m_eye(m)
    for i in range(len(mods)):
        if not m_eq(m_mul(mods[i], mods[i]), (I[0], I[1] * eps[i])): return False
        for j in range(i + 1, len(mods)):
            P, Q = m_mul(mods[i], mods[j]), m_mul(mods[j], mods[i])
            if not m_eq(P, (Q[0], -Q[1])): return False
    return True
def mmul(A, x, y): return (x[0] * y[0] * A.s(x[1], y[1]), x[1] ^ y[1])     # signed blades (sign, label) with the kernel (chain_blocks.py)
def mono_words_t(G, d):
    """the 2^N words of the monomial matrices G (canonical increasing order): Wr[a, c] the row of column c of word a, Wv its value (int32 /
    int16), by doubling: word a + 2^k = word a times G_k (null_stages.py)"""
    N = len(G); Wr = np.empty((1 << N, d), dtype=np.int32); Wv = np.empty((1 << N, d), dtype=np.int16)
    Wr[0] = np.arange(d); Wv[0] = 1
    for k, g in enumerate(G):
        h = 1 << k
        np.take(Wr[:h], g[0], axis=1, out=Wr[h:2 * h]); np.take(Wv[:h], g[0], axis=1, out=Wv[h:2 * h]); Wv[h:2 * h] *= g[1][None, :].astype(np.int16)
    return Wr, Wv

# ------------------------------------------------------------------------------------------------ minimal left ideals on the labels (period_map.py's vectorised abs_ring.py construction, via null_stages.py)
def comm_set_v(eps):
    """abs_ring.py's comm_set in its first order (increasing labels), vectorised: commuting independent labels of square +1, greedily; a label
    with a null bit has square 0 and never enters (period_map.py)"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); pa = popv(a)
    cand = s_vec(eps, a, a) == 1; cand[0] = False; inspan = np.zeros(1 << n, dtype=bool); inspan[0] = True
    span = np.zeros(1, dtype=np.int64); gens = []
    while True:
        idx = np.flatnonzero(cand & ~inspan)
        if not len(idx): return gens
        u = int(idx[0]); new = span ^ u
        if not np.all(s_vec(eps, new, new) == 1): cand[u] = False; continue
        gens.append(u); cand &= ((pa * pc(u) - popv(a & u)) & 1) == 0; inspan[new] = True; span = np.concatenate([span, new])
def reducer(gens):
    """the span of gens in reduced echelon form over F2: a -> the coset minimum (period_map.py)"""
    basis = []
    for g in gens:
        v = g
        for pb, bv in basis:
            if v >> pb & 1: v ^= bv
        pb = v.bit_length() - 1; basis = [(q_, w ^ v if w >> pb & 1 else w) for q_, w in basis] + [(pb, v)]
    def red(A):
        R = np.array(A, dtype=np.int64, copy=True)
        for pb, bv in basis: R = np.where(((R >> pb) & 1) == 1, R ^ bv, R)
        return R
    return red
def commutant_v(rho, m):
    """solid_cube.py's commutant_basis on signed permutations, vectorised (period_map.py): one signed permutation per surviving component"""
    M = m * m; x = np.arange(M, dtype=np.int64); bb, cc = x // m, x % m
    root = x.copy(); psi = np.ones(M, dtype=np.int64)
    while True:
        changed = False
        for pi, sg in rho:
            y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]
            r0, p0 = root.copy(), psi.copy(); mv = r0 < r0[y]
            if mv.any(): root[y[mv]] = r0[mv]; psi[y[mv]] = tt[mv] * p0[mv]; changed = True
            r1, p1 = root.copy(), psi.copy(); mv = r1[y] < r1
            if mv.any(): root[mv] = r1[y[mv]]; psi[mv] = tt[mv] * p1[y[mv]]; changed = True
        if not changed: break
    bad = np.zeros(M, dtype=bool)
    for pi, sg in rho:
        y = pi[bb] * m + pi[cc]; tt = sg[bb] * sg[cc]; bad[root[(root[y] != root) | (psi[y] != tt * psi)]] = True
    out = []
    for r in np.unique(root):
        if bad[r]: continue
        sel = np.flatnonzero(root == r); rows_, cols_ = sel // m, sel % m
        if len(sel) != m or len(np.unique(cols_)) != m or len(np.unique(rows_)) != m: out.append(None); continue
        o = np.argsort(cols_); out.append((rows_[o], psi[sel][o]))
    return out
def commutant_comp_pm(rho, m):
    """null_stages.py's commutant_dim_pm (the commutant of monomial matrices with zero columns: two-term equations tie two entries with a sign,
    one-term equations force an entry to 0), returning the components themselves: comp[x] the index of the basis element that entry x belongs
    to (-1 for an entry forced to 0) and psi[x] its sign; the basis element k is the {0, +1, -1} matrix with the entries of component k"""
    M = m * m; x = np.arange(M, dtype=np.int64); a_, c_ = x // m, x % m
    EU, EV, ET = [], [], []; zero = np.zeros(M, dtype=bool)
    for pi, sg in rho:
        inv = np.full(m, -1, dtype=np.int64); nzc = np.flatnonzero(sg != 0); inv[pi[nzc]] = nzc
        b0 = inv[a_]; lhs = b0 >= 0; rhs = sg[c_] != 0; both = lhs & rhs
        EU.append(b0[both] * m + c_[both]); EV.append(a_[both] * m + pi[c_[both]]); ET.append(sg[b0[both]] * sg[c_[both]])
        ol = lhs & ~rhs; zero[b0[ol] * m + c_[ol]] = True
        orr = rhs & ~lhs; zero[a_[orr] * m + pi[c_[orr]]] = True
    U = np.concatenate(EU); V = np.concatenate(EV); Tt = np.concatenate(ET)       # X[U] = Tt X[V]
    root = x.copy(); psi = np.ones(M, dtype=np.int64)
    while True:
        changed = False
        r0, p0 = root.copy(), psi.copy(); mv = r0[U] < r0[V]
        if mv.any(): root[V[mv]] = r0[U[mv]]; psi[V[mv]] = Tt[mv] * p0[U[mv]]; changed = True
        r1, p1 = root.copy(), psi.copy(); mv = r1[V] < r1[U]
        if mv.any(): root[U[mv]] = r1[V[mv]]; psi[U[mv]] = Tt[mv] * p1[V[mv]]; changed = True
        if not changed: break
    bad = np.zeros(M, dtype=bool); bad[root[zero]] = True
    bad[root[U[(root[U] != root[V]) | (psi[U] != Tt * psi[V])]]] = True
    good = np.unique(root[~bad[root]]); idx = np.full(M, -1, dtype=np.int64); idx[good] = np.arange(len(good))
    comp = idx[root]; comp[bad[root]] = -1
    return comp, psi, len(good)
def classify_v(basis, m):
    """solid_cube.py's classify on signed-permutation bases (period_map.py): 'R' (d = 1), 'C' (d = 2), 'H' (d = 4); None otherwise"""
    d = len(basis)
    if any(B is None for B in basis): return None
    def coords(P):
        for k, B in enumerate(basis):
            if np.array_equal(P[0], B[0]):
                if np.array_equal(P[1], B[1]): return [int(i == k) for i in range(d)]
                if np.array_equal(P[1], -B[1]): return [-int(i == k) for i in range(d)]
        raise AssertionError('not in the span')
    if d == 1: return 'R'
    kap = [[coords(m_mul(Bc, Bd)) for Bd in basis] for Bc in basis]; e = coords(m_eye(m))
    def mul(x_, y_):
        out = [0] * d
        for c_ in range(d):
            if x_[c_]:
                for dd in range(d):
                    if y_[dd]:
                        for t_ in range(d): out[t_] += x_[c_] * y_[dd] * kap[c_][dd][t_]
        return out
    neg = [-v for v in e]
    if d == 2: return 'C' if any(mul(x_, x_) == neg for x_ in itertools.product(range(-2, 3), repeat=2)) else None
    if d == 4:
        roots = [x_ for x_ in itertools.product(range(-2, 3), repeat=4) if mul(x_, x_) == neg]
        return 'H' if any(all(a_ == -b_ for a_, b_ in zip(mul(x_, y_), mul(y_, x_))) for x_ in roots for y_ in roots) else None
    return None
def left_ideal(eps, gens=None):
    """the bit rule's left ideal A f for any cell (null generators allowed), abs_ring.py's construction vectorised as period_map.py's
    build_ideal (null_stages.py): f = prod (1 + e_a)/2 over the commuting labels gens, the basis e_r f with r the coset minima of their span
    among all labels, e_i e_r f = s(i,r) s(r2,mm) tau(mm) e_r2 f; a null generator gives a zero column where r already has its bit"""
    eps = tuple(eps); n = len(eps); N = 1 << n
    gens = comm_set_v(eps) if gens is None else list(gens); red = reducer(gens)
    a = np.arange(N, dtype=np.int64); reps = np.flatnonzero(red(a) == a).astype(np.int64); m = len(reps)
    tl = np.zeros(1, dtype=np.int64); ts = np.ones(1, dtype=np.int64)
    for g in gens: tl, ts = np.concatenate([tl, tl ^ g]), np.concatenate([ts, ts * s_vec(eps, tl, g)])
    tau = np.zeros(N, dtype=np.int64); tau[tl] = ts
    rho = []
    for i in range(n):
        c_ = reps ^ (1 << i); r2 = red(c_); mm = c_ ^ r2
        rho.append((np.searchsorted(reps, r2).astype(np.int64), (s_vec(eps, 1 << i, reps) * s_vec(eps, r2, mm) * tau[mm]).astype(np.int64)))
    return {'eps': eps, 'n': n, 'm': m, 'reps': reps, 'rho': rho, 'gens': gens, 'tl': tl, 'ts': ts}

# ------------------------------------------------------------------------------------------------ exact linear algebra
PMOD = 2147483647                                                          # a prime below 2^31: ranks mod p are exact lower bounds of ranks over Q
def rank_mod(Mat, p=PMOD):
    """the rank of an integer matrix over F_p (numpy int64, elimination row by row); rank_p <= rank_Q, so rank_p = the number of rows proves
    full row rank over Q"""
    A = np.array(Mat, dtype=np.int64) % p; r = 0; rows, cols = A.shape
    for c_ in range(cols):
        if r == rows: break
        piv = np.flatnonzero(A[r:, c_]); 
        if not len(piv): continue
        i = r + int(piv[0]); A[[r, i]] = A[[i, r]]; inv = pow(int(A[r, c_]), p - 2, p); A[r] = (A[r] * inv) % p
        nz = np.flatnonzero(A[:, c_]); nz = nz[nz != r]
        if len(nz): A[nz] = (A[nz] - (A[nz, c_][:, None] * A[r][None, :]) % p) % p
        r += 1
    return r
def fr_rank(rows):
    """the exact rank over Q of a few rows of Fractions (small matrices only)"""
    M = [list(r) for r in rows]; rk = 0; ncol = len(M[0]) if M else 0
    for c_ in range(ncol):
        piv = next((i for i in range(rk, len(M)) if M[i][c_] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][c_] != 0:
                f = M[i][c_] / M[rk][c_]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk
def fr_signature(G):
    """the signature (positive minus negative) of a small symmetric matrix of Fractions, by symmetric elimination (Sylvester's law of inertia)"""
    A = [list(r) for r in G]; n = len(A); sgn = 0; idx = list(range(n))
    while idx:
        piv = next((i for i in idx if A[i][i] != 0), None)
        if piv is None:
            pair = next(((i, j) for i in idx for j in idx if i < j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair; A[i] = [a + b for a, b in zip(A[i], A[j])]                              # x_i -> x_i + x_j (a congruence)
            for k in range(n): A[k][i] = A[k][i] + A[k][j]
            continue
        d = A[piv][piv]; sgn += 1 if d > 0 else -1; idx.remove(piv)
        for i in idx:
            f = A[i][piv] / d
            if f: A[i] = [a - f * b for a, b in zip(A[i], A[piv])]
        for i in idx: A[i][piv] = Fr(0)
        for k in range(n): A[piv][k] = Fr(0); A[k][piv] = Fr(0)
    return sgn

# ------------------------------------------------------------------------------------------------ multivectors as dense integer vectors of a cell with at most 8 generators (exact, np.add.at)
def mv_mul(S, x, y):
    """x y for dense integer coefficient vectors over the labels, with the cell's sign table S (exact int64)"""
    ix, iy = np.flatnonzero(x), np.flatnonzero(y); out = np.zeros(len(x), dtype=np.int64)
    if len(ix) and len(iy):
        np.add.at(out, (ix[:, None] ^ iy[None, :]).ravel(), (S[np.ix_(ix, iy)] * (x[ix][:, None] * y[iy][None, :])).ravel())
    return out
def blade(N, a, c=1): v = np.zeros(N, dtype=np.int64); v[a] = c; return v
class VecK:
    """the kernel as s_vec on arrays of labels (any length of eps)"""
    def __init__(self, eps): self.eps = tuple(eps)
    def s(self, A, B): return s_vec(self.eps, A, B)
def expand(K, V):
    """the 2^|V| ordered products v_T of the signed blades V (T a bit mask over V): labels L_T and signs sigma_T, by doubling (null_stages.py)"""
    L = np.zeros(1, dtype=np.int64); S = np.ones(1, dtype=np.int64)
    for sv, lv in V: L, S = np.concatenate([L, L ^ lv]), np.concatenate([S, S * sv * K.s(L, lv)])
    return L, S
class SegK:
    """the kernel on concatenated labels as the graded tensor product of its segments (cb.GT; null_stages.py): s(a,b) = prod_k s_k(a_k, b_k)
    times (-1)^(sum_(k<l) |a_l| |b_k|), each s_k the full table of a segment of at most 8 bits"""
    def __init__(self, eps, cuts):
        self.eps = tuple(eps); self.cuts = [c_ for c_ in cuts]; self.off = [sum(cuts[:k]) for k in range(len(cuts))]
        assert sum(cuts) == len(eps) and all(c_ <= 8 for c_ in cuts)
        self.T = [table(self.eps[o:o + c_]) for o, c_ in zip(self.off, self.cuts)]
    def s(self, A, B):
        A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
        sg = np.ones(np.broadcast(A, B).shape, dtype=np.int64); par = np.zeros_like(sg); below = np.zeros_like(sg)
        for T_, o, c_ in zip(self.T, self.off, self.cuts):
            ak, bk = (A >> o) & ((1 << c_) - 1), (B >> o) & ((1 << c_) - 1)
            sg = sg * T_[ak, bk]; par = par + popv(ak) * below; below = below + popv(bk)
        return sg * (1 - 2 * (par & 1))
def phi_blade(K, Nk, sb):
    """e_i -> e_i Omega_(k+1) (i < N_k) on a signed blade, by the kernel (null_stages.py; period_map.py's phi_mv on one blade)"""
    Om = 255 << Nk; s_, lab = sb; out = (s_, 0)
    for i in range(lab.bit_length()):
        if lab >> i & 1: out = mmul(K, out, (K.s(1 << i, Om), (1 << i) ^ Om))
    return out

# ------------------------------------------------------------------------------------------------ small exact algebra over a basis of Fraction rows
def rref_T(rows):
    """reduced row echelon form of independent Fraction rows with the transformation T (R = T rows) and the pivot columns"""
    d = len(rows); R = [list(r) for r in rows]; T = [[Fr(int(i == j)) for j in range(d)] for i in range(d)]; piv = []; r = 0
    for c_ in range(len(R[0])):
        if r == d: break
        i = next((k for k in range(r, d) if R[k][c_] != 0), None)
        if i is None: continue
        R[r], R[i] = R[i], R[r]; T[r], T[i] = T[i], T[r]; f = R[r][c_]
        R[r] = [x / f for x in R[r]]; T[r] = [x / f for x in T[r]]
        for k in range(d):
            if k != r and R[k][c_] != 0:
                g = R[k][c_]; R[k] = [a - g * b for a, b in zip(R[k], R[r])]; T[k] = [a - g * b for a, b in zip(T[k], T[r])]
        piv.append(c_); r += 1
    return R, T, piv
def coords_in(basis_rows, T, piv, v):
    """the coordinates c of v in the basis (c . basis = v), checked exactly; None if v is not in the span"""
    cp = [v[c_] for c_ in piv]; c = [sum(cp[k] * T[k][j] for k in range(len(cp))) for j in range(len(basis_rows))]
    back = [sum(c[j] * basis_rows[j][x] for j in range(len(c))) for x in range(len(v))]
    return c if back == list(v) else None
def null_space(rows, ncol):
    """an exact basis of {x : rows . x = 0} (Fractions, small systems)"""
    M = [list(r) for r in rows]; piv = []; r = 0
    for c_ in range(ncol):
        i = next((k for k in range(r, len(M)) if M[k][c_] != 0), None)
        if i is None: continue
        M[r], M[i] = M[i], M[r]; f = M[r][c_]; M[r] = [x / f for x in M[r]]
        for k in range(len(M)):
            if k != r and M[k][c_] != 0: g = M[k][c_]; M[k] = [a - g * b for a, b in zip(M[k], M[r])]
        piv.append(c_); r += 1
    free = [c_ for c_ in range(ncol) if c_ not in piv]; out = []
    for fc in free:
        x = [Fr(0)] * ncol; x[fc] = Fr(1)
        for k, c_ in enumerate(piv): x[c_] = -M[k][fc]
        out.append(x)
    return out
def alg_type(kap, d):
    """the type of the algebra with structure constants kap[i][j] (coordinates of b_i b_j; b_0 the unit) by the method of chain_blocks.py:
    the centre (the null space of the commutators), the squares of its elements, the count (the signature of the trace form tr L_(b_i b_j))"""
    eqs = [[kap[i][j][k] - kap[j][i][k] for i in range(d)] for j in range(d) for k in range(d)]
    Z = null_space(eqs, d); cplx = False
    if len(Z) == 2:
        z = next(v for v in Z if any(v[1:])); z = [Fr(0)] + list(z[1:]) if z[0] == 0 else [x - (z[0] if i == 0 else 0) for i, x in enumerate(z)]
        z2 = [sum(z[i] * z[j] * kap[i][j][k] for i in range(d) for j in range(d)) for k in range(d)]
        beta = next((z2[k] / z[k] for k in range(1, d) if z[k] != 0), Fr(0)); alpha = z2[0] - beta * z[0]
        cplx = all(z2[k] == alpha * (k == 0) + beta * z[k] for k in range(d)) and beta * beta + 4 * alpha < 0
    trL = [sum(kap[k][j][j] for j in range(d)) for k in range(d)]
    G = [[sum(kap[i][j][k] * trL[k] for k in range(d)) for j in range(d)] for i in range(d)]
    fs = fr_signature(G); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(d, c, cplx, fs), len(Z), fs

# ================================================================================================ cc.COV  the commutant of a projective cover on a null cell
head('cc.COV  the 120 cells with null generators: f A f for the bit rule\'s idempotent f, its radical f J f, its residue f Q f; End_A(A f) on the module\'s matrices')
t = time.time()
def fe_af(S, Lf, Sf, N):
    """the 2^n elements f e_a f (a every label) as the rows of an integer matrix scaled by 4^w (f = 2^-w sum_T sigma_T e_(L_T)), exact"""
    a = np.arange(N, dtype=np.int64); out = np.zeros((N, N), dtype=np.int64)
    for l1, s1 in zip(Lf, Sf):
        x = l1 ^ a; sg1 = s1 * S[l1, a]                                    # sigma_T e_(L_T) e_a: its sign and label, for every a at once
        for l2, s2 in zip(Lf, Sf): out[a, x ^ l2] += sg1 * s2 * S[x, l2]
    return out
def mv_mul_mod(S, x, y, p=PMOD):
    ix, iy = np.flatnonzero(x), np.flatnonzero(y); out = np.zeros(len(x), dtype=np.int64)
    if len(ix) and len(iy):
        np.add.at(out, (ix[:, None] ^ iy[None, :]).ravel(), (S[np.ix_(ix, iy)] * ((x[ix][:, None] * y[iy][None, :]) % p)).ravel())
    return out % p
okDim = okOdd = okNil = okRes = okMod = True; COVD = {}; ndD = {'R': 0, 'C': 0, 'H': 0}; nzero = 0; ctlD = 0; maxB = 0
for c in NULLC:
    p, q, r = c; n = p + q + r; nq = p + q; eps = sig(*c); N = 1 << n; S = table(eps); nb = ((1 << r) - 1) << nq
    D, mq, s = clock_type(p, q); d = DD[D]; ndD[D] += 1
    U = comm_set_v(eps); w = len(U); Lf, Sf = expand(VecK(eps), [(1, u) for u in U])
    Bm = fe_af(S, Lf, Sf, N); a = np.arange(N, dtype=np.int64); nN = popv(a & nb)
    trB, trQ = int(np.trace(Bm)), int(np.trace(Bm[:1 << nq, :1 << nq]))
    pred = d if FAULT == 'COMMD' else ((1 << r) * d if s == 1 else (1 << (r - 1)) * d)
    dimB, dimQ = Fr(trB, 4 ** w), Fr(trQ, 4 ** w); dimJ = dimB - dimQ; maxB = max(maxB, dimB)
    okDim &= dimB == pred and dimQ == d and dimJ == pred - d
    ctlD += dimB != d; nzero += dimJ == 0
    oddz = not np.any(Bm[(nN & 1) == 1]); okOdd &= oddz == (s == 2)
    k_need = r if s == 1 else r // 2                                       # the predicted index: (f J f)^k != 0 for this k
    if k_need >= 1:                                                        # a product of k_need random elements of f J f, mod p
        groups = [[j] for j in range(nq, n)] if s == 1 else [[nq + 2 * i, nq + 2 * i + 1] for i in range(r // 2)]
        prod = None
        for gj in groups:
            an = sum(1 << j for j in gj); rows = np.flatnonzero((a & nb) == an)
            nzr = [int(i) for i in rows if np.any(Bm[int(i)])]; y = Bm[RNG.choice(nzr)] % PMOD if nzr else np.zeros(N, dtype=np.int64)
            prod = y if prod is None else mv_mul_mod(S, prod, y)
        okNil &= bool(np.any(prod))
    cand = [[Fr(int(v)) for v in Bm[i][:1 << nq]] for i in range(1 << nq) if np.any(Bm[i])]  # f e_a f for a in the quotient: span f Q f
    bas = [cand[0]]                                                        # f e_0 f = f, the unit of f Q f, first
    for v in cand[1:]:
        if len(bas) == d: break
        if fr_rank(bas + [v]) > len(bas): bas.append(v)
    R_, T_, piv = rref_T(bas); okR = len(bas) == d
    BI = [np.array([int(x) for x in b_] + [0] * (N - (1 << nq)), dtype=np.int64) for b_ in bas]
    kap = []
    for i in range(d):
        rowk = []
        for j in range(d):
            v = mv_mul(S, BI[i], BI[j]); okR &= not np.any(v[1 << nq:]) and all(int(x) % (4 ** w) == 0 for x in v)
            cj = coords_in(bas, T_, piv, [Fr(int(x), 4 ** w) for x in v[:1 << nq]]); okR &= cj is not None; rowk.append(cj or [Fr(0)] * d)
        kap.append(rowk)
    ty, zc, fs = alg_type(kap, d) if okR else (None, 0, 0)
    okRes &= okR and ty == (D, 1, 1)
    L = left_ideal(eps); comp, psi, kdim = commutant_comp_pm(L['rho'], L['m']); m = L['m']
    xx = np.arange(m * m, dtype=np.int64); xT = (xx % m) * m + xx // m; val = (comp >= 0) & (comp[xT] >= 0)
    G = np.zeros((kdim, kdim), dtype=np.int64); np.add.at(G, (comp[val], comp[xT][val]), psi[val] * psi[xT][val])
    rkp, rkn = rank_mod(G), int(np.linalg.matrix_rank(G.astype(float)))
    okMod &= kdim == pred and rkp == rkn == d and kdim - rkp == pred - d
    COVD[c] = (int(dimB), int(dimJ), D, s, ty, zc, fs, kdim)
chk('bit', okDim and okOdd and okNil, 'cc.COV: for the 120 cells (p,q,r), r >= 1, n <= 8, B = f A f (f = prod (1 + u)/2 over abs_ring.py\'s commuting set, all u in the quotient Q = Cl(p,q)): its dimension, the trace of the idempotent map x -> f x f over the 2^n labels, is 2^r d (s = 1) or 2^(r-1) d (s = 2, 30 cells), up to %d at (0,0,8), the part without a null bit f Q f of dimension d = dim D, the part f J f of dimension (2^r - 1) d or (2^(r-1) - 1) d; f e_a f = 0 for every a with an odd number of null bits exactly when s = 2; f J f is a two-sided ideal of f A f (J is one) with (f J f)^k != 0 for k = r (s = 1) and k = floor(r/2) (s = 2), a product of k elements of f J f (a random non-zero f e_a f from each piece with one null bit, s = 1, or with a pair of them, s = 2) non-zero mod p, and (f J f)^(k+1) = 0 (s = 1: J^(r+1) = 0, ns.NUL; s = 2: only even numbers >= 2 of null bits occur, so k + 1 factors carry more than r); f J f = 0 in %d cells' % (maxB, nzero))
chk('bit', okRes, 'cc.COV: the residue f A f / f J f = f Q f (dropping the labels with a null bit is multiplicative: Q a subalgebra, J an ideal) has a basis among the f e_a f, structure constants exact, and its type by the method of chain_blocks.py (the centre as the null space of the commutators, the squares of its central elements, the count as the signature of the trace form: +1, 0, -2) is the division algebra D of the simple module for all 120 cells (R %d, C %d, H %d): f A f is local with radical f J f and residue D, and so is End_A(A f) = (f A f)^op (recalled; D^op = D)' % (ndD['R'], ndD['C'], ndD['H']))
chk('bit', okMod, 'cc.COV: on the module\'s own matrices (A f as partial signed permutations, null_stages.py\'s construction): the exact commutant, its basis from the components of the two-term equations (commutant_dim_pm extended), has the dimension of f A f in all 120 cells, and the radical of its trace form tr(XY) (a faithful representation in characteristic 0; ranks mod p and by numpy, equal) has the dimension of f J f: End_A(A f) has a nilpotent radical and a residue of dimension d')
chk('ctl', ctlD == 110 and nzero == 10, 'cc.COV: the commutant of a projective cover taken as D (no radical) differs from the computed one in %d of the 120 cells; it is D exactly in the %d cells with s = 2 and r = 1, where the socle J f is the other simple module (no map of the top into it): a negative case of "local with a radical", kept' % (ctlD, nzero))
note('f A f in numbers (dim, dim f J f, residue): ' + '; '.join('%s: %d, %d, %s' % (cstr(c_), COVD[c_][0], COVD[c_][1], COVD[c_][2]) for c_ in [(0, 0, 1), (1, 0, 1), (0, 1, 1), (0, 0, 8), (1, 0, 2), (0, 3, 1), (4, 3, 1)]))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.LIFT  idempotent lifting and Nakayama on the null cells
head('cc.LIFT  the 120 null cells: the quotient\'s idempotents in the cell (the lift is the identity), the other lifts and their units, the classes of the covers, Nakayama')
t = time.time()
okI = okLift = okCls = okNak = True; nidem = nlift = nnaive = nnaive_bad = njf = 0
for c in NULLC:
    p, q, r = c; n = p + q + r; nq = p + q; eps = sig(*c); N = 1 << n; S = table(eps); nb = ((1 << r) - 1) << nq
    D, mq, s = clock_type(p, q); d = DD[D]
    U = comm_set_v(eps); w = len(U); Lf, Sf = expand(VecK(eps), [(1, u) for u in U]); W2 = 1 << w
    chis = [np.array([np.prod([sg[t_] for t_ in range(w) if T >> t_ & 1]) if w else 1 for T in range(W2)], dtype=np.int64) for sg in itertools.product((1, -1), repeat=w)]
    E = []
    for ch in chis: v = np.zeros(N, dtype=np.int64); v[Lf] = Sf * ch; E.append(v)               # E_sigma scaled by 2^w
    okI &= all(not np.any(v[nb & np.arange(N) != 0]) for v in E) and np.array_equal(sum(E), blade(N, 0, W2))
    for i in range(W2):
        for j in range(W2):
            Pij = mv_mul(S, E[i], E[j]); okI &= np.array_equal(Pij, W2 * E[i]) if i == j else not np.any(Pij)
    nidem += W2
    Jlab = np.flatnonzero((np.arange(N) & nb) != 0); one = blade(N, 0, W2)
    for i in RNG.sample(range(W2), min(W2, 3)):                            # other lifts of the class of E_sigma, x in J
        x = np.zeros(N, dtype=np.int64); x[RNG.sample(list(Jlab), min(3, len(Jlab)))] = [RNG.choice([-3, -2, -1, 1, 2, 3]) for _ in range(min(3, len(Jlab)))]
        for side in (0, 1):
            Y = mv_mul(S, mv_mul(S, one - E[i], x), E[i]) if side == 0 else mv_mul(S, mv_mul(S, E[i], x), one - E[i])   # 4^w (1-e) x e or 4^w e x (1-e)
            Ep = W2 * E[i] + Y; F4 = 4 ** w; I4 = blade(N, 0, F4)
            ok_ = np.array_equal(mv_mul(S, Ep, Ep), F4 * Ep) and not np.any(Y[(np.arange(N) & nb) == 0]) and not np.any(mv_mul(S, Y, Y))
            ok_ &= np.array_equal(mv_mul(S, I4 + Y, I4 - Y), blade(N, 0, F4 * F4))
            Uy, Ui = (I4 + Y, I4 - Y) if side == 0 else (I4 - Y, I4 + Y)        # u = 1 + y for y = (1-e) x e, u = 1 - y for y = e x (1-e)
            ok_ &= np.array_equal(mv_mul(S, mv_mul(S, Uy, E[i]), Ui), F4 * W2 * Ep)
            okLift &= ok_; nlift += 1
        Xn = W2 * E[i] + W2 * x                                            # the generic lift e + x (scaled by 2^w): a control
        nnaive += 1; nnaive_bad += not np.array_equal(mv_mul(S, Xn, Xn), W2 * Xn)
    gT = np.array([int((S[l_, np.arange(1 << nq)] * S[l_ ^ np.arange(1 << nq), l_]).sum()) for l_ in Lf], dtype=np.int64)  # sum_a s(L,a) s(L+a,L), a in Q
    dims = [[Fr(int((ci * cj * gT).sum()), 4 ** w) for cj in chis] for ci in chis]           # dim E_s Q E_t: the trace of x -> E_s x E_t on Q
    om = (1 << nq) - 1; Tom = next((T for T in range(W2) if Lf[T] == om), None) if s == 2 else None
    summ = [ch[Tom] if s == 2 else 1 for ch in chis]
    okCls &= all(dims[i][j] == (d if summ[i] == summ[j] else 0) for i in range(W2) for j in range(W2)) and len(set(summ)) == s and all(summ.count(z) == W2 // s for z in set(summ))
    L = left_ideal(eps); m = L['m']; reps = L['reps']; Wr, Wv = mono_words_t(L['rho'], m); Wr = Wr.astype(np.int64); Wv = Wv.astype(np.int64)
    topm = (reps & nb) == 0; wN = (np.arange(N) & nb) != 0
    hit = np.zeros(m, dtype=bool); hit[np.unique(Wr[wN][Wv[wN] != 0])] = True
    okNak &= np.array_equal(hit, ~topm) and int((~topm).sum()) == m - m // (1 << r)                  # J A f = J f, a proper submodule
    x = np.array([RNG.randint(-3, 3) for _ in range(m)], dtype=np.int64); x[np.flatnonzero(topm)[0]] = 1
    Mx = np.zeros((N, m), dtype=np.int64); np.add.at(Mx, (np.repeat(np.arange(N), m), Wr.ravel()), (Wv * x[None, :]).ravel())
    okNak &= rank_mod(Mx) == m                                             # A x = A f: an element with a top component generates
    xj = np.where(topm, 0, np.array([RNG.randint(-3, 3) for _ in range(m)])); Mj = np.zeros((N, m), dtype=np.int64)
    np.add.at(Mj, (np.repeat(np.arange(N), m), Wr.ravel()), (Wv * xj[None, :]).ravel()); njf += not np.any(Mj[:, topm])
chk('bit', okI, 'cc.LIFT: for the 120 cells (p,q,r), r >= 1, n <= 8, the 2^w = s m idempotents E_sigma = prod (1 + sigma_u u)/2 of the quotient\'s maximal commuting set (LNC-059; %d in all), multiplied in the cell: idempotent, pairwise orthogonal, summing to 1, with no null bit, so the projection A -> A/J (dropping the labels with a null bit) fixes each: the lift of a complete set of orthogonal primitive idempotents of A/J = Cl(p,q) is the identity' % nidem)
chk('bit', okLift, 'cc.LIFT: every other lift of the same class: for %d sampled x in J (three null-bit labels with small integer coefficients) and both sides (%d lifts), e\' = e + (1 - e) x e and e\'\' = e + e x (1 - e) are idempotents with the image of e (their difference from e has only null-bit labels and square 0), and u = 1 + y for y = (1 - e) x e (u = 1 - y for y = e x (1 - e); y^2 = 0, so u^-1 = 1 - y, resp. 1 + y) gives u e u^-1 = e\', resp. e\'\': the lifts are conjugate, exactly' % (nnaive, nlift))
chk('bit', okCls, 'cc.LIFT: the classes of the projective covers A E_sigma: dim E_sigma Q E_tau (the trace of the idempotent map x -> E_sigma x E_tau on the quotient) is d when E_sigma and E_tau lie in one summand of Q and 0 otherwise, so E_sigma A E_tau is not inside J exactly within a summand: s classes of m covers each, one for each simple module, K_0(A) -> K_0(A/J) a bijection on the classes of the indecomposable projectives (idempotent lifting, cited in general; here the lift is the identity)')
chk('bit', okNak, 'cc.LIFT: Nakayama on the covers: J A f = J f (the basis vectors with a null bit, exactly those hit by the words with a null bit), a proper submodule of dimension (2^r - 1) m dim D in every cell; a random element of A f with a non-zero top component (one per cell) generates A f (its 2^n images W_a x have rank 2^r m dim D, exact mod p) in all 120 cells; J kills every simple module (ns.NUL)')
chk('ctl', nnaive_bad == nnaive and njf == len(NULLC), 'cc.LIFT: the generic lift e + x (x in J, uncorrected) is not idempotent in %d of %d samples; an element of J f generates a submodule inside J f (every W_a x without a top component) in %d of the 120 cells' % (nnaive_bad, nnaive, njf))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.STD  the standard routes where the bit route stood alone
head('cc.STD  the standard routes, no label: the map\'s signs for n = 7, 8 on every pair, the third-stage idempotents as dense matrices, the row-8 start cells\' stages 0 and 1')
t = time.time()
TT = np.arange(256, dtype=np.int64); BW = {}
for b in BLOCKS:                                                           # the block's 16 x 16 matrices, their 256 words, and Omega times each word
    Gb = [to_mono(g) for g in block_mats(b)]; Ob = m_prod(Gb, 16); Br_, Bv_ = mono_words_t(Gb, 16); Br_, Bv_ = Br_.astype(np.int64), Bv_.astype(np.int64)
    BW[b] = (Gb, Ob, Br_, Bv_, Ob[0][Br_], Ob[1][Br_] * Bv_)
def bit_pairs(ec, eb):
    """the bit route on every pair (S,T): e'_S f_T = sigma e_L, L and sigma from the vectorised kernel (period_map.py's pm.MAP)"""
    n = len(ec); eps = ec + eb; Om = 255 << n
    gi = np.array([1 << i for i in range(n)], dtype=np.int64); el, es = gi ^ Om, s_vec(eps, gi, Om)
    wl = np.zeros(1 << n, dtype=np.int64); ws = np.ones(1 << n, dtype=np.int64)
    for i in range(n):
        lo = np.arange(1 << i); wl[lo | (1 << i)] = wl[lo] ^ el[i]; ws[lo | (1 << i)] = ws[lo] * es[i] * s_vec(eps, wl[lo], el[i])
    return wl[:, None] ^ (TT[None, :] << n), ws[:, None] * s_vec(eps, wl[:, None], (TT << n)[None, :])
CELLS78 = [c for n in (7, 8) for c in cells(n)]                            # the 81 cells with n = 7, 8
okF = okFb = True; ncase = npair = 0
for c in CELLS78:
    n = sum(c); ec = sig(*c); d0 = 1 << n
    gam = [to_mono(g) for g in site_gens(ec)]; okF &= rel_ok(gam, ec, d0)  # the cell's site matrices: the relations of Cl(p,q,r)
    for b in BLOCKS:
        Gb, Ob, Br_, Bv_, OBr, OBv = BW[b]; eb = sig(*b)
        okF &= m_eq(m_mul(Ob, Ob), m_eye(16)) and all(m_eq(m_mul(Ob, g), m_neg(m_mul(g, Ob))) for g in Gb) and rel_ok(Gb, eb, 16)
        L, SG = bit_pairs(ec, eb); Llo, Lhi = L & (d0 - 1), L >> n; S_ = np.arange(d0)
        okFb &= np.array_equal(Llo, np.broadcast_to(S_[:, None], Llo.shape))     # the gamma factor: gamma_S = gamma_(L_lo) exactly when L_lo = S
        par = (popv(Llo) & 1)[..., None] == 1
        Rr = np.where(par, OBr[Lhi], Br_[Lhi]); Rv = np.where(par, OBv[Lhi], Bv_[Lhi]) * SG[..., None]   # sigma Omega^|L_lo| g_(L_hi)
        okFb &= np.array_equal(Rr, np.broadcast_to(Br_[None], Rr.shape)) and np.array_equal(Rv, np.broadcast_to(Bv_[None], Rv.shape))
        ncase += 1; npair += d0 * 256
chk('std', okF, 'cc.STD: monomial Kronecker matrices, no label: for the %d cells with n = 7, 8 (null generators included) the site matrices satisfy the relations of Cl(p,q,r), and for each block (8,0,0), (0,8,0), (4,4,0) the 16 x 16 matrices g_j satisfy theirs, Omega = g_1 ... g_8 squares to 1 and anticommutes with every g_j: gamma_i (x) Omega and 1 (x) g_j represent Cl(n+8) (%d cases, 2^(n+4) up to 4096 dimensions), e\'_S f_T -> (gamma_S (x) 1)(1 (x) g_T) = gamma_S (x) g_T and the word of a label L -> gamma_(L_lo) (x) Omega^|L_lo| g_(L_hi), both by the mixed-product rule' % (len(CELLS78), ncase))
chk('bit==std', okFb, 'cc.STD: on every pair (S,T) of the %d cases (%d pairs; GEN-017\'s standard route sampled 3120 pairs at 5 <= n <= 8): gamma_S (x) g_T = sigma(S,T) gamma_(L_lo) (x) Omega^|L_lo| g_(L_hi) with sigma and L from the kernel, compared factor by factor (a Kronecker product of two non-zero monomial matrices fixes its factors up to one common sign): L_lo = S on every pair and g_T = sigma Omega^[|S| odd] g_(T xor [|S| odd] 255) entry by entry: the signs of the explicit map on every pair for n = 7, 8' % (ncase, npair))
def full_case(c, b):
    """the same comparison as full 2^(n+4)-dimensional monomial matrices on every pair and every column, without the mixed-product rule:
    e'_S f_T as the product of the matrices of e_i Omega and of the f_j, sigma e_L as the ordered product of the generator matrices"""
    n = sum(c); ec = sig(*c); d0 = 1 << n; Gb, Ob, _, _, _, _ = BW[b]; Dm = 16 * d0
    gam = [to_mono(g) for g in site_gens(ec)]; G = [m_kron(g, Ob) for g in gam] + [m_kron(m_eye(d0), g) for g in Gb]
    OmI = m_prod(G[n:], Dm); PH = [m_mul(G[i], OmI) for i in range(n)]       # e_i Omega -> gamma_i (x) Omega times 1 (x) Omega
    Er, Ev = [x.astype(np.int64) for x in mono_words_t(PH, Dm)]; Lr, Lv = [x.astype(np.int64) for x in mono_words_t(G[:n], Dm)]
    Hr, Hv = [x.astype(np.int64) for x in mono_words_t(G[n:], Dm)]; L, SG = bit_pairs(ec, sig(*b)); ok = True
    for S in range(d0):
        T_ = np.arange(256); lr, lv = Er[S][Hr], Ev[S][Hr] * Hv                # e'_S f_T for every T (rows, values: 256 x Dm)
        lo, hi = L[S] & (d0 - 1), L[S] >> n; rr, rv = Lr[lo[:, None], Hr[hi]], Lv[lo[:, None], Hr[hi]] * Hv[hi] * SG[S][:, None]
        ok &= np.array_equal(lv, rv) and bool(np.all((lr == rr) | (lv == 0)))
    return ok
okFull = full_case((7, 0, 0), (8, 0, 0)) and full_case((2, 3, 3), (4, 4, 0))
chk('bit==std', okFull, 'cc.STD: the same as full monomial matrices, every column, without the mixed-product rule (e\'_S f_T as the product of the matrices of e_i Omega and of the f_j, sigma e_L as the ordered product of the generator matrices), on every pair of the cases (7,0,0) with the block (8,0,0) (2048 x 2048, 32768 pairs) and (2,3,3) with (4,4,0) (4096 x 4096, 65536 pairs)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
QB = {b: comm_set_v(sig(*b)) for b in BLOCKS}                              # four commuting labels of square +1 in each block
START = [(p, n - p, 0) for n in range(5) for p in range(n + 1)] + [(8, 0, 0), (0, 8, 0), (4, 4, 0)]
def chain_V(c0, b, K_):
    """null_stages.py's run_chain for the start cells (p,q,0), the idempotents only: a minimal idempotent of each summand at each stage as
    prod (1 + v)/2 over signed blades, V_(k+1) = phi(V_k) + the block's four; the summands named by the coefficient of omega; the units
    tr L_z / tr L_P and the multiplicity matrices from the coefficients of 1 and of omega (exact Fractions)"""
    p, q, r = c0; n = p + q + r; eb = sig(*b)
    EPS = [sig(*c0) + eb * k for k in range(K_ + 1)]; NK = [n + 8 * k for k in range(K_ + 1)]
    D, m0, s_ = clock_type(p, q); KB = [BR(e) for e in EPS]; KS = [SegK(e, ([n] if n else []) + [8] * k) for k, e in enumerate(EPS)]
    U0 = comm_set_v(EPS[0]); V = {'+': [(1, u) for u in U0]}; om = [(1 << NK[k]) - 1 for k in range(K_ + 1)]
    if s_ == 2:                                                             # the other summand by e_i -> -e_i; each named by omega's coefficient
        Va, Vb = V['+'], [((-1) ** pc(u), u) for u in U0]; L0, S0 = expand(KS[0], Va); h0 = np.flatnonzero(L0 == om[0])
        V = {'+': Va, '-': Vb} if len(h0) and S0[h0[0]] == 1 else {'+': Vb, '-': Va}
    Vs = [dict(V)]
    for k in range(K_): Vs.append({g: [phi_blade(KB[k + 1], NK[k], v) for v in Vk] + [(1, u << NK[k]) for u in QB[b]] for g, Vk in Vs[k].items()})
    coef, units, Ms = [], [], []
    for k in range(K_ + 1):
        ck = {}
        for g, Vk in Vs[k].items():
            L, S = expand(KS[k], Vk); hit = np.flatnonzero(L == om[k]); ck[g] = (Fr(1, 1 << len(Vk)), Fr(int(S[hit[0]]), 1 << len(Vk)) if len(hit) else Fr(0))
        coef.append(ck); zc = {'+': Fr(1, 2) if s_ == 2 else Fr(1), '-': Fr(1, 2)}; units.append({g: zc[g] / ck[g][0] for g in ck})
    for k in range(K_):
        Mk = {}
        for j in Vs[k]:
            L, S = expand(KS[k + 1], [phi_blade(KB[k + 1], NK[k], v) for v in Vs[k][j]])
            hit = np.flatnonzero(L == om[k + 1]); c0_, cw = Fr(1, len(L)), (Fr(int(S[hit[0]]), len(L)) if len(hit) else Fr(0))
            for i in Vs[k + 1]:
                zw = {'+': Fr(1, 2), '-': Fr(-1, 2)}[i] if s_ == 2 else Fr(0); z0 = Fr(1, 2) if s_ == 2 else Fr(1)
                Mk[(i, j)] = (c0_ * z0 + cw * zw) / coef[k + 1][i][0]
        Ms.append(Mk)
    return {'EPS': EPS, 'NK': NK, 'V': Vs, 'KS': KS, 'KB': KB, 's': s_, 'm0': m0, 'D': D, 'om': om, 'coef': coef, 'units': units, 'Ms': Ms}
CH = {(c0, b): chain_V(c0, b, 2) for c0 in START for b in BLOCKS}
def stage_gens(c0, b, k):
    """a faithful module of the stage k of the chain, no label: the start cell's site matrices (n <= 4) or the start block's 16 x 16
    matrices (row 8), then gamma (x) Omega, 1 (x) g for each block (null_stages.py's C_1, iterated)"""
    G = [to_mono(g) for g in (site_gens(sig(*c0)) if sum(c0) <= 4 else block_mats(c0))]; d = 1 << sum(c0) if sum(c0) <= 4 else 16
    Gb, Ob = BW[b][0], BW[b][1]
    for _ in range(k): G = [m_kron(g, Ob) for g in G] + [m_kron(m_eye(d), g) for g in Gb]; d *= 16
    return G, d
def label_mat(G, d, sb):
    """the matrix of a signed blade: its sign times the ordered product of the generator matrices over its label"""
    s_, lab = sb; R = m_eye(d)
    for k in range(lab.bit_length()):
        if lab >> k & 1: R = m_mul(R, G[k])
    return R[0], R[1] * s_
def dense_idem(G, d, V):
    """M = prod_v (I + M_v) = sum_T sigma_T M_(v_T) in exact integers (as float64, every entry below 2^53), by doubling the monomial words"""
    Wr = np.arange(d, dtype=np.int64)[None, :]; Wv = np.ones((1, d), dtype=np.int64)
    for v in V:
        r_, v_ = label_mat(G, d, v); Wr, Wv = np.concatenate([Wr, r_[Wr]]), np.concatenate([Wv, v_[Wr] * Wv])   # (I + M_v): word times M_v on the left
    return np.bincount((Wr * d + np.arange(d)[None, :]).ravel(), weights=Wv.ravel().astype(np.float64), minlength=d * d).reshape(d, d)
def antipair(b, k_off):
    """a label of the block, square +1, anticommuting with the first of its four commuting labels and commuting with the second and third,
    outside their span (null_stages.py's ANTIPAIR)"""
    Tb = table(sig(*b)); q1, q2, q3 = QB[b][:3]; span3 = {0, q1, q2, q3, q1 ^ q2, q1 ^ q3, q2 ^ q3, q1 ^ q2 ^ q3}
    x = next(u for u in range(1, 256) if Tb[u, u] == 1 and Tb[u, q1] == -Tb[q1, u] and Tb[u, q2] == Tb[q2, u] and Tb[u, q3] == Tb[q3, u] and u not in span3)
    return (1, x << k_off)
okP2 = okRk = okRel3 = True; nP = 0; n4096 = 0; dmx = 0; nanti = nanti_bad = 0
for (c0, b), X in CH.items():
    G, d = stage_gens(c0, b, 2); okRel3 &= rel_ok(G, X['EPS'][2], d); dmx = max(dmx, d)
    for g, V2 in X['V'][2].items():
        w = len(V2); M = dense_idem(G, d, V2); M2 = M @ M
        okP2 &= np.array_equal(M2, (1 << w) * M)                            # P^2 = P: M^2 = 2^|V| M, exact (entries below 2^36)
        rk_ = int(np.linalg.matrix_rank(M @ NPR.standard_normal((d, 64)))); tr_ = Fr(int(round(np.trace(M))), 1 << w)
        okRk &= rk_ == tr_ == Fr(d, 1 << w) == Fr(d * int(X['units'][2][g]) * DD[X['D']], 1 << X['NK'][2])   # rank = tr P = D tr L_P / 2^N, tr L_P = m_2 dim D
        nP += 1; n4096 += d == 4096
    if d <= 1024 and X['s'] == 1 and nanti < 6:                            # the control: one anticommuting pair, as a dense matrix
        Va = X['V'][2]['+'][:-1] + [antipair(b, X['NK'][1])]; Ma = dense_idem(G, d, Va); nanti += 1; nanti_bad += not np.array_equal(Ma @ Ma, (1 << len(Va)) * Ma)
chk('std', okRel3, 'cc.STD: no label, for the 54 chains of GEN-019 (the 15 cells (p,q,0) with n <= 4 and the row-8 cells, each block repeated) a faithful module of the third stage: the start cell\'s site matrices (n <= 4) or the start block\'s 16 x 16 matrices (row 8), then gamma (x) Omega, 1 (x) g for each block: monomial matrices of %d to %d dimensions satisfying the relations of the stage (up to 24 generators)' % (256, dmx))
chk('bit==std', okP2 and okRk, 'cc.STD: the %d minimal idempotents of the third stages (GEN-024\'s, their signed blades from the kernel) as dense matrices, each blade the ordered product of the generator matrices over its label: M = prod (I + M_v) in exact integers (%d of them 4096 x 4096), M^2 = 2^|V| M through floating-point products whose entries stay below 2^36, so P^2 = P; the rank of P by numpy (of P X, X Gaussian with 64 columns) equals tr P = D 2^-|V| = D tr L_P / 2^N with the labels\' tr L_P = m_2 dim D (m_2 = 256 m_0, GEN-019\'s unit)' % (nP, n4096))
chk('ctl', nanti_bad == nanti and nanti > 0, 'cc.STD: with one anticommuting pair (the last label of the second block\'s four replaced by null_stages.py\'s ANTIPAIR label) the dense product is not idempotent in %d of %d chains tried (dimensions up to 1024)' % (nanti_bad, nanti))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def clusters(ev, tol=1e-6):
    out = []
    for v in sorted(ev):
        if not out or v - out[-1][-1] > tol: out.append([v])
        else: out[-1].append(v)
    return [float(np.mean(c_)) for c_ in out]
def dense_comb(Wr, Wv, coef, d):
    """sum_a coef_a W_a as a dense d x d matrix from monomial words (null_stages.py)"""
    idx = (Wr.astype(np.int64) * d + np.arange(d)[None, :]).ravel()
    return np.bincount(idx, weights=(Wv * coef[:, None]).ravel(), minlength=d * d).reshape(d, d)
rk = lambda A: int(np.linalg.matrix_rank(A, tol=1e-6))
def std_stage_mono(G, d):
    """no label (null_stages.py): the words of the algebra generated by the monomial matrices G; its centre as the centre of the commutant of G
    (the double commutant, recalled), the commutant exact (commutant_v); the minimal central idempotents as spectral projectors of a random
    symmetric central element; a minimal projection of each summand as the top spectral projector of a random symmetric element cut down"""
    Wr, Wv = mono_words_t(G, d); M = len(Wr); C = commutant_v(G, d)
    cen = [B for B in C if B is not None and all(B2 is not None and m_eq(m_mul(B, B2), m_mul(B2, B)) for B2 in C)]
    Zc = sum(NPR.standard_normal() * m_dense(B).astype(float) for B in cen); Zc = (Zc + Zc.T) / 2; lam = clusters(np.linalg.eigvalsh(Zc))
    Zs = []
    for i, l in enumerate(lam):
        Pz = np.eye(d)
        for j, l2 in enumerate(lam):
            if j != i: Pz = Pz @ (Zc - l2 * np.eye(d)) / (l - l2)
        Zs.append(Pz)
    X = dense_comb(Wr, Wv, NPR.standard_normal(M), d); X = X + X.T; Ps = []
    for Pz in Zs:
        w_, V_ = np.linalg.eigh((Pz + Pz.T) / 2); B = V_[:, w_ > 0.5]; w2, V2 = np.linalg.eigh(B.T @ X @ B)
        Vt_ = B @ V2[:, w2 > w2.max() - 1e-6 * max(1.0, np.abs(w2).max())]; Ps.append(Vt_ @ Vt_.T)
    return Wr, Wv, len(cen), len(C), Zs, Ps
okR8s = okR8b = True; nr8 = 0
for c0 in START[15:]:                                                      # the row-8 start cells (8,0,0), (0,8,0), (4,4,0)
    G0, d0 = stage_gens(c0, BLOCKS[0], 0); W0r, W0v, nz0, nc0, Z0, P0s = std_stage_mono(G0, d0)
    A0 = np.zeros((d0 * d0, len(W0r))); A0[(W0r.astype(np.int64) * d0 + np.arange(d0)[None, :]).ravel(), np.repeat(np.arange(len(W0r)), d0)] = W0v.ravel()
    for b in BLOCKS:
        G1, d1 = stage_gens(c0, b, 1); W1r, W1v, nz1, nc1, Z1, P1s = std_stage_mono(G1, d1)
        OmI = m_prod(G1[8:], d1); phiG = [m_mul(G1[i], OmI) for i in range(8)]; Pr, Pv = mono_words_t(phiG, d1)   # the images of e_i Omega
        al = np.linalg.lstsq(A0, P0s[0].ravel(), rcond=None)[0]; okR8s &= np.allclose(A0 @ al, P0s[0].ravel(), atol=1e-8)
        FP = dense_comb(Pr, Pv, al, d1); Mstd = Fr(rk(FP @ Z1[0]), rk(P1s[0]))
        u0, u1 = Fr(rk(Z0[0]), rk(P0s[0])), Fr(rk(Z1[0]), rk(P1s[0])); X = CH[(c0, b)]
        okR8s &= nc0 == nc1 == 1 and nz0 == nz1 == 1 and len(Z0) == len(Z1) == 1                   # the commutant R at both stages, s = 1
        okR8b &= X['s'] == 1 and u0 == X['units'][0]['+'] == 16 and u1 == X['units'][1]['+'] == 256 and Mstd == X['Ms'][0][('+', '+')] == 16
        nr8 += 1
chk('std', okR8s, 'cc.STD: no label, the stages 0 and 1 of the %d chains from the row-8 start cells (8,0,0), (0,8,0), (4,4,0) (the start block\'s 16 x 16 matrices, then gamma (x) Omega, 1 (x) g: 256 x 256, 65536 words as monomials): the exact commutant of the generators (R at both stages), its centre, a minimal projection by numpy, carried by the matrices of e_i Omega (null_stages.py\'s matrix route, there for n <= 4)' % nr8)
chk('bit==std', okR8b, 'cc.STD: for the same %d inclusions the matrix route gives the labels\' numbers: s = 1, the order units 16 and 256 (ratios of numpy ranks), the multiplicity 16; with GEN-025 the signs of the map on every pair for every cell with n <= 8, the stages 0 and 1 of the chains from n <= 4 and from row 8, and the third-stage idempotents have a standard route (the third stage\'s multiplicity matrices and the null chains\' stages beyond the trace form stay on the labels)' % nr8)
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.REF  the vectorised modules against abs_ring.py's build_cell beyond 10 generators
head('cc.REF  the minimal left ideals beyond 10 generators: abs_ring.py\'s build_cell (copied) against the vectorised construction, on a named sample of 12 cells')
t = time.time()
def fmm(A, B):
    """exact integer product of two integer matrices through BLAS floats (entries stay far below 2^53) (abs_ring.py)"""
    C = A.astype(np.float64) @ B.astype(np.float64); Ci = np.rint(C).astype(np.int64)
    assert np.array_equal(Ci.astype(np.float64), C); return Ci
def comm_set_ref(alg, norders):
    """abs_ring.py's comm_set: maximal sets of commuting labels of square +1 met in several orders, the largest kept (period_map.py)"""
    best = []; rg = random.Random(7 + 31 * alg.n + sum(1 for e in alg.eps if e > 0))
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(norders):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s_ ^ a for s_ in span}
                if all(alg.sq(x) == 1 for x in new): gens.append(a); span |= new
        if len(gens) > len(best): best = gens
    return best
def build_cell_ref(eps):
    """abs_ring.py's build_cell for the cell with these eps (period_map.py's copy): f = prod (1 + e_a)/2, the ideal Cl f on the cosets of the
    span, the exact commutant (solid_cube.py), the two irreducibles of a two-summand cell by the sign of the volume element"""
    alg = Alg(eps); n = alg.n; N = alg.N
    gens = comm_set_ref(alg, 12 if n <= 8 else (4 if n <= 12 else 2)); k = len(gens); span = {0}
    for a in gens: span |= {s_ ^ a for s_ in span}
    tau = {}
    for J in range(1 << k):
        prod = {0: 1}
        for j in range(k):
            if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
        (mm, cf), = prod.items(); tau[mm] = cf
    coset = {}; reps = []
    for a in range(N):
        if a not in coset:
            reps.append(a)
            for mm in span: coset[a ^ mm] = (a, mm)
    m = len(reps); idx = {r: i for i, r in enumerate(reps)}; rho = []
    for i in range(n):
        R = np.zeros((m, m), dtype=np.int64)
        for r in reps:
            s, c_ = alg.blade_mul(1 << i, r); r2, mm = coset[c_]; s2, _ = alg.blade_mul(r2, mm)
            R[idx[r2], idx[r]] = s * s2 * tau[mm]
        rho.append(R)
    basis = commutant_basis(rho, m); typ, els = classify(basis, m); d = len(basis)
    om = np.eye(m, dtype=np.int64)
    for R in rho: om = fmm(om, R)
    sgn = 1 if np.array_equal(om, np.eye(m, dtype=np.int64)) else (-1 if np.array_equal(om, -np.eye(m, dtype=np.int64)) else 0)
    return {'gens': gens, 'm': m, 'rho': rho, 'basis': basis, 'type': typ, 'd': d, 'summ': Fr(N * d, m * m), 'om_sign': sgn}
REFS = [((3, 0), (8, 0, 0)), ((2, 1), (0, 8, 0)), ((1, 2), (4, 4, 0)), ((0, 3), (8, 0, 0)), ((4, 0), (0, 8, 0)), ((3, 1), (4, 4, 0)),
        ((2, 2), (8, 0, 0)), ((1, 3), (0, 8, 0)), ((5, 0), (4, 4, 0)), ((4, 1), (8, 0, 0)), ((3, 2), (0, 8, 0)), ((2, 3), (4, 4, 0))]
okRef = True; nref = 0; mmax = 0; clk = set()
for (p, q), b in REFS:
    eps = (1,) + sig(p, q) + sig(*b); N = 1 << len(eps); ref = build_cell_ref(eps)
    L = left_ideal(eps, gens=ref['gens']); m = L['m']; basis = commutant_v(L['rho'], m); typ = classify_v(basis, m); d = len(basis)
    W = m_prod(L['rho'], m); sgn = 1 if m_eq(W, m_eye(m)) else (-1 if m_eq(W, (np.arange(m), -np.ones(m, dtype=np.int64))) else 0)
    okRef &= ref['m'] == m and all(np.array_equal(R, m_dense(v)) for R, v in zip(ref['rho'], L['rho']))
    okRef &= ref['d'] == d and ref['type'] == typ and ref['summ'] == Fr(N * d, m * m) and (ref['summ'] != 2 or ref['om_sign'] == sgn)
    okRef &= len(basis) == len(ref['basis']) and all(any(np.array_equal(a_, m_dense(B)) or np.array_equal(a_, -m_dense(B)) for B in basis) for a_ in ref['basis'])
    okRef &= len(comm_set_v(eps)) == len(ref['gens']); nref += 1; mmax = max(mmax, m); clk.add((1 + p - q) % 8)
chk('bit', okRef, 'cc.REF: on the %d cells (1,) + sig(p,q) + block of pm.ABS beyond 10 generators named %s (12, 13 and 14 generators, the clocks %s, the three blocks): abs_ring.py\'s build_cell (copied: bitcliff.py\'s engine, solid_cube.py\'s exact commutant and classify) and the vectorised construction on signed permutations with the same commuting set give the same matrices (modules up to dimension %d), the same commutant (dimension, basis up to sign, type), the same summands and volume sign; the vectorised greedy finds commuting sets of the same size' % (nref, ', '.join('%s+%s' % (cstr((p, q)), cstr(b)) for (p, q), b in REFS), sorted(clk), mmax))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.LIM  the algebraic direct limit on the labels
head('cc.LIM  the algebraic direct limit of the chain of blocks on the labels: the two chains\' stages equal, the union of the stages, the trace, K_0 on the finite side')
t = time.time()
def phi_imgs(K, Nk, width=8):
    """e_i -> e_i Omega for the next block of `width` generators (8: an M16 step; 16: an M256 step), as signed blades, i < N_k (period_map.py)"""
    Om = ((1 << width) - 1) << Nk; return [(K.s(1 << i, Om), (1 << i) ^ Om) for i in range(Nk)]
def phi_mv(K, imgs, x):
    out = {}
    for lab, cf in x.items():
        sb = (1, 0)
        for i in range(lab.bit_length()):
            if lab >> i & 1: sb = mmul(K, sb, imgs[i])
        if sb[0]: out[sb[1]] = out.get(sb[1], 0) + sb[0] * cf
    return {k_: v for k_, v in out.items() if v != 0}
def rnd_mv(N, k=3): return {RNG.randrange(1 << N): Fr(RNG.choice([-3, -2, -1, 1, 2, 3]), RNG.choice([1, 2, 4])) for _ in range(k)}
okEq = okIn = okLim = okTr = okK0 = okInj = True; nsmp = 0; ctl_wi = 0; ninj = 0
for (c0, b), X in CH.items():
    n = sum(c0); eb = sig(*b); e0 = sig(*c0)
    for k in (0, 1):                                                       # the M256 chain's stage k against the M16 chain's stage 2k
        kk = k if FAULT == 'WRONGINDEX' else 2 * k
        okEq &= e0 + (eb + eb) * k == e0 + eb * kk                          # one eps: the same kernel table on the same labels
        ctl_wi += k == 1 and e0 + (eb + eb) * k != e0 + eb * k
        K2 = BR(e0 + eb * (2 * k + 2)); Nk = n + 16 * k; Ka = BR(e0 + eb * (kk + 1))
        psi = phi_imgs(K2, Nk, 16)                                         # e_i -> e_i Omega_16, the M256 step
        if FAULT == 'WRONGINDEX': two = phi_imgs(Ka, Nk, 8)                # one M16 step only
        else:
            K1 = BR(e0 + eb * (2 * k + 1)); f1 = phi_imgs(K1, Nk); f2 = phi_imgs(K2, Nk + 8)
            two = [next(iter(phi_mv(K2, f2, {sb[1]: sb[0]}).items()))[::-1] for sb in f1]
        okIn &= [tuple(v) for v in psi] == [tuple(v) for v in two]
    K0, K1 = BR(e0), BR(e0 + eb); f1 = phi_imgs(K1, n); f2 = phi_imgs(BR(e0 + eb * 2), n + 8); p16 = phi_imgs(BR(e0 + eb * 2), n, 16)
    if FAULT != 'WRONGINDEX':
        for S in range(1 << n):                                            # every label at k = 0: psi(e_S) = phi phi(e_S) = +e_(S xor [|S| odd] Omega_16)
            a1 = phi_mv(BR(e0 + eb * 2), f2, phi_mv(K1, f1, {S: 1})); a2 = phi_mv(BR(e0 + eb * 2), p16, {S: 1})
            okIn &= a1 == a2 == {S ^ ((((1 << 16) - 1) << n) if pc(S) % 2 else 0): 1}
    KS3 = [BR(e) for e in X['EPS']]; IM = [phi_imgs(KS3[k + 1], X['NK'][k]) for k in range(2)]
    for k in range(2):                                                     # phi_k on every label of the stage k (vectorised doubling, as pm.MAP)
        Nk = X['NK'][k]; ek = X['EPS'][k + 1]; Om = 255 << Nk; gi = np.array([1 << i for i in range(Nk)], dtype=np.int64)
        el, es = gi ^ Om, s_vec(ek, gi, Om); wl = np.zeros(1 << Nk, dtype=np.int64); ws = np.ones(1 << Nk, dtype=np.int64)
        for i in range(Nk):
            lo = np.arange(1 << i); wl[lo | (1 << i)] = wl[lo] ^ el[i]; ws[lo | (1 << i)] = ws[lo] * es[i] * s_vec(ek, wl[lo], el[i])
        S_ = np.arange(1 << Nk, dtype=np.int64); okInj &= len(np.unique(wl)) == 1 << Nk and bool(np.all(np.abs(ws) == 1)) and np.array_equal(wl, S_ ^ ((popv(S_) & 1) * Om)); ninj += 1 << Nk
    for _ in range(6):                                                     # the union of the stages: classes of pairs (k, x), x ~ phi(x)
        k1, k2 = RNG.randrange(2), RNG.randrange(2); x, y, z = rnd_mv(X['NK'][k1]), rnd_mv(X['NK'][k2]), rnd_mv(X['NK'][k1])
        up = lambda v, kf, kt: v if kf == kt else up(phi_mv(KS3[kf + 1], IM[kf], v), kf + 1, kt)
        K_ = max(k1, k2); xy = KS3[K_].mul(up(x, k1, K_), up(y, k2, K_))
        okLim &= phi_mv(KS3[K_ + 1], IM[K_], xy) == KS3[K_ + 1].mul(up(x, k1, K_ + 1), up(y, k2, K_ + 1))          # the stage does not matter
        okLim &= KS3[K_].mul(xy, up(z, k1, K_)) == KS3[K_].mul(up(x, k1, K_), KS3[K_].mul(up(y, k2, K_), up(z, k1, K_)))   # associative
        okLim &= phi_mv(KS3[k1 + 1], IM[k1], {0: Fr(1)}) == {0: Fr(1)} and phi_mv(KS3[k1 + 1], IM[k1], x) != {}         # unital, injective here
        tr = lambda v, om_: (v.get(0, 0) + v.get(om_, 0), v.get(0, 0) - v.get(om_, 0)) if X['s'] == 2 else (v.get(0, 0),)
        okTr &= tr(phi_mv(KS3[k1 + 1], IM[k1], x), X['om'][k1 + 1]) == tr(x, X['om'][k1])                            # the trace is preserved
        okTr &= tr(KS3[K_].mul(up(x, k1, K_), up(y, k2, K_)), X['om'][K_]) == tr(KS3[K_].mul(up(y, k2, K_), up(x, k1, K_)), X['om'][K_])
        nsmp += 1
    if X['s'] == 2: okTr &= all(phi_blade(KS3[k + 1], X['NK'][k], (1, X['om'][k])) == (1, X['om'][k + 1]) for k in range(2))   # omega kept
    for k in range(3):                                                     # tau on the minimal idempotents: (k, e_i) -> e_i / (16^k m_0)
        for g, (c0_, cw) in X['coef'][k].items():
            tv = (c0_ + cw, c0_ - cw) if X['s'] == 2 else (c0_,); want = tuple(Fr(int(i_ == g), 16 ** k * X['m0']) for i_ in (('+', '-') if X['s'] == 2 else ('+',)))
            okK0 &= tv == want and X['units'][k][g] * tv[('+', '-').index(g) if X['s'] == 2 else 0] == 1
chk('bit', okEq and okIn, 'cc.LIM: for the 54 chains of GEN-019: the M256 chain\'s stage k (k = 0, 1; up to 24 generators) has the eps of the M16 chain\'s stage 2k, so the two are one label algebra (the same table on the same labels: an equality, not an isomorphism); its inclusion e_i -> e_i Omega_16 equals the composite of two steps e_i -> e_i Omega on every generator at k = 0 and k = 1 (both homomorphisms, so on every element; images by the kernel up to 40 generators) and on every label at k = 0 (e_S -> +e_(S xor [|S| odd] Omega_16))')
chk('bit', okLim and okInj, 'cc.LIM: the union of the stages as classes of pairs (k, x), x a multivector of the stage k (exact Fractions), (k, x) ~ (k + 1, phi(x)): phi unital and injective (on every label of the stages 0 and 1 of the 54 chains, %d labels, distinct labels to distinct labels, e_S -> +e_(S xor [|S| odd] Omega)), and on %d sampled triples (stages 0..2, up to 24 generators) the product at the common stage does not depend on the stage chosen (phi(xy) = phi(x) phi(y)) and is associative: one algebra, the algebraic direct limit, every element at a finite stage; the M256 chain\'s stages are every second stage, so its limit is the same algebra' % (ninj, nsmp))
chk('bit', okTr and okK0, 'cc.LIM: the scalar part tau(x) = x_0 is preserved by every inclusion (0 -> 0 and no other label to 0) and tau(xy) = tau(yx) on the samples: a trace on the limit, tau(1) = 1; for the 9 two-summand chains the two traces x_0 +- x_omega, omega -> +omega kept; on the minimal idempotents P_(k,i) of the stages 0, 1, 2 tau_j(P_(k,i)) = delta_ij / (16^k m_0), the inverse of the unit: on the classes of the stages\' idempotents tau = iota / m_0 of GEN-026, onto Z[1/2]^s with [1] -> (1, ..., 1); with the continuity of K_0 along algebraic direct limits (cited), the dimension group of pass 10c is the K_0 of this algebra on the finite side')
chk('ctl', ctl_wi == 54, 'cc.LIM: the M256 chain\'s stage 1 set beside the M16 chain\'s stage 1 (the wrong index): the eps differ in %d of the 54 chains (n + 16 against n + 8 generators)' % ctl_wi)
note('not computed: the C*-completion of the limit (the CAR algebra and the chain of blocks as C*-algebras); the classifications of the completed limits are cited (docs/round13/SOURCES.md)')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.ABS  ABS's own two-step maps and their fourfold composite
head('cc.ABS  the two-step isomorphisms of Atiyah, Bott and Shapiro (Lawson-Michelsohn, Ch. I 4) on the labels: e_i -> e_i omega_2, the mirror, four steps against e_i -> e_i Omega')
t = time.time()
B2 = [(1, 1), (-1, -1), (1, -1)]                                           # the blocks of two: Cl(2,0), Cl(0,2), Cl(1,1) (as their eps)
def w2sq(bl, fault=True):
    """omega_2^2 = -eps_1 eps_2 of a block of two; under --fault OMEGA2 the value of the cell Cl(1,1), +1, for every block"""
    return 1 if (fault and FAULT == 'OMEGA2') else -bl[0] * bl[1]
def apply_hom(eps_t, imgs, labs, sgns):
    """the homomorphism with the generator images imgs (signed blades of the cell eps_t) on signed blades: the ordered product of the images
    over the bits of each label, by the kernel (vectorised over the labels)"""
    accL = np.zeros_like(labs); accS = np.array(sgns, dtype=np.int64, copy=True)
    for j, (sj, lj) in enumerate(imgs):
        hj = ((labs >> j) & 1) == 1
        accS = np.where(hj, accS * sj * s_vec(eps_t, accL, lj), accS); accL = np.where(hj, accL ^ lj, accL)
    return accL, accS
def is_hom(eps_t, imgs, eps_s):
    """do the signed blades imgs (in the cell eps_t) satisfy the relations of the cell eps_s: squares eps_s[j], pairwise anticommuting"""
    if not imgs: return True
    L = np.array([l for _, l in imgs], dtype=np.int64); Sg = np.array([s for s, _ in imgs], dtype=np.int64)
    P = s_vec(eps_t, L[:, None], L[None, :]) * Sg[:, None] * Sg[None, :]
    return np.array_equal(np.diag(P), np.array(eps_s, dtype=np.int64)) and bool(np.all((P == -P.T)[~np.eye(len(L), dtype=bool)]))
def twist_imgs(eps_t, nc, om):
    """e_j -> e_j om as signed blades of the cell eps_t, j < nc (one vectorised call of the kernel)"""
    g = np.array([1 << j for j in range(nc)], dtype=np.int64); sg = s_vec(eps_t, g, om) if nc else []
    return [(int(sg[j]), (1 << j) ^ om) for j in range(nc)]
ALLC = [c for n in range(9) for c in cells(n)]                             # the 165 cells with n <= 8
ok2 = okBij = okSgn = True; nmir = 0; ncase2 = 0
for c in ALLC:
    eps = sig(*c); n = len(eps); labs = np.arange(1 << n, dtype=np.int64)
    for bl in B2:
        E = eps + bl; om = 3 << n; true2 = int(s_vec(E, om, om)); pred = tuple(e * w2sq(bl) for e in eps)   # the copy: the mirror when omega_2^2 = -1
        imgs = twist_imgs(E, n, om)
        ok2 &= is_hom(E, imgs, pred) and all(int(s_vec(E, l, 1 << j)) == int(s_vec(E, 1 << j, l)) != 0 for _, l in imgs for j in (n, n + 1))
        Lp, Sp = apply_hom(E, imgs, labs, np.ones(1 << n, dtype=np.int64)); T4 = np.arange(4, dtype=np.int64) << n
        allL = (Lp[:, None] ^ T4[None, :]).ravel(); allS = (Sp[:, None] * s_vec(E, Lp[:, None], T4[None, :])).ravel()
        okBij &= bool(np.all(np.bincount(allL, minlength=1 << (n + 2)) == 1)) and bool(np.all(allS != 0))
        okSgn &= np.array_equal(Lp, labs ^ ((popv(labs) & 1) * om)) and np.array_equal(Sp, np.where((popv(labs) // 2) % 2 == 1, true2, 1))
        nmir += true2 == -1; ncase2 += 1
chk('bit', ok2 and okBij and okSgn, 'cc.ABS: for the 165 cells (p,q,r) with n <= 8 and each block of two placed after them, (2,0,0), (0,2,0), (1,1,0) (%d cases): e\'_i = e_i omega_2 (omega_2 the product of the block\'s generators) commute with the block and satisfy the relations of the mirror Cl(q,p,r) when omega_2^2 = -1 (%d cases, the blocks (2,0,0) and (0,2,0)) and of Cl(p,q,r) when omega_2^2 = +1 (the block (1,1,0)); the 2^n x 4 products e\'_S f_T reach each of the 2^(n+2) labels once, with e\'_S = (omega_2^2)^floor(|S|/2) e_(S xor [|S| odd] omega_2): Cl(n+2,0) = Cl(0,n) (x) Cl(2,0), Cl(0,n+2) = Cl(n,0) (x) Cl(0,2) and Cl(p+1,q+1) = Cl(p,q) (x) Cl(1,1) on the labels (ABS, Prop. 4.2, and the form of Lawson-Michelsohn, Ch. I 4, as docs/round13/SOURCES.md (d) reads them; the block placed after the n generators as there, ABS place it first, a relabelling), the mirror exactly when omega_2^2 = -1' % (ncase2, nmir))
def iterate(eps, bs, fault=True, labels=False):
    """four two-step maps: psi_k from the current cell into T_k = (current eps) omega_k^2 + B_k, e_j -> e_j omega_k; the images of the start
    generators (or of every start label) through the four, by the kernel, the final cell, and whether each psi_k satisfies the relations of
    the cell it starts from"""
    n = len(eps); cur = tuple(eps); okh = True
    if labels: labs = np.arange(1 << n, dtype=np.int64); sg = np.ones(1 << n, dtype=np.int64)
    else: gi = [(1, 1 << i) for i in range(n)]
    for bl in bs:
        nc = len(cur); Tk = tuple(e * w2sq(bl, fault) for e in cur) + tuple(bl); imgs = twist_imgs(Tk, nc, 3 << nc); okh &= is_hom(Tk, imgs, cur)
        if labels: labs, sg = apply_hom(Tk, imgs, labs, sg)
        else:
            K = BR(Tk); new = []
            for s0, l0 in gi:
                out = (s0, 0)
                for j in range(l0.bit_length()):
                    if l0 >> j & 1: out = mmul(K, out, imgs[j])
                new.append(out)
            gi = new
        cur = Tk
    return cur, ((labs, sg) if labels else gi), okh
def onestep(cur, n):
    """GEN-017's map e_i -> e_i Omega (Omega the top blade of the last eight generators of the cell cur): the images of the generators, and
    the images of every label of the first n"""
    imgs = twist_imgs(cur, n, 255 << n); labs = np.arange(1 << n, dtype=np.int64)
    return imgs, apply_hom(cur, imgs, labs, np.ones(1 << n, dtype=np.int64))
SEQS = [bs for bs in itertools.product(B2, repeat=4) if sum(1 for b_ in bs if b_[0] * b_[1] == 1) % 2 == 0]
ABSR = [('(0,8,0)', ((1, 1), (-1, -1), (1, 1), (-1, -1)), sig(0, 8)), ('(8,0,0)', ((-1, -1), (1, 1), (-1, -1), (1, 1)), sig(8, 0)),
        ('(4,4,0)', ((-1, -1), (1, 1), (1, 1), (-1, -1)), sig(4, 4)), ('four (1,1,0)', ((1, -1),) * 4, (1, -1) * 4)]
okR = True; nlabR = 0
for nm, bs, fb in ABSR:                                                    # ABS's own routes: every label of every cell
    for c in ALLC:
        eps = sig(*c); n = len(eps); cur, (L, Sg), okh = iterate(eps, bs, labels=True); _, (Lf, Sf) = onestep(cur, n)
        okR &= okh and cur[:n] == eps and cur[n:] == fb and np.array_equal(L, Lf) and np.array_equal(Sg, Sf); nlabR += 1 << n
okAll = True; lamc = {1: 0, -1: 0}
for bs in SEQS:                                                            # all 41 sequences: the generators (both maps are homomorphisms)
    lam = w2sq(bs[1], False) * w2sq(bs[3], False); lamc[lam] += 1
    for c in ALLC:
        eps = sig(*c); n = len(eps); cur, gi, okh = iterate(eps, bs); fi, _ = onestep(cur, n)
        okAll &= okh and cur[:n] == eps and all(gs == lam * fs and gl == fl for (gs, gl), (fs, fl) in zip(gi, fi))
inner = {}
for c in ALLC:                                                             # is e_i -> -e_i inner: an invertible blade anticommuting with every generator
    eps = sig(*c); n = len(eps); A = np.arange(1 << (c[0] + c[1]), dtype=np.int64); ok_ = np.ones(len(A), dtype=bool)
    for i in range(n): ok_ &= s_vec(eps, A, 1 << i) == -s_vec(eps, 1 << i, A)
    inner[c] = bool(ok_.any())
okIn = all(inner[c] == (sum(c) % 2 == 0 and c[2] == 0) for c in ALLC)
chk('bit', okR, 'cc.ABS: ABS\'s own route, four definite steps in alternation (Lawson-Michelsohn\'s Cl_(n+8) = Cl\'_(n+6) (x) Cl_2 = ..., each step a mirror): for the 165 cells, the blocks of two (2,0,0), (0,2,0), (2,0,0), (0,2,0) as placed reach the cell with the block (0,8,0), the order (0,2,0), (2,0,0), (0,2,0), (2,0,0) the block (8,0,0), and (0,2,0), (2,0,0), (2,0,0), (0,2,0) the block (4,4,0); four steps (1,1,0) (no mirror) the interleaved Cl(4,4) (1,-1,1,-1,1,-1,1,-1); every step a homomorphism, and the composite equals the one-step map e_i -> e_i Omega of GEN-017 for that block on every label of every cell (%d labels): no sign' % nlabR)
chk('bit', okAll and okIn and lamc[1] == 25 and lamc[-1] == 16, 'cc.ABS: all %d sequences of four blocks of two with an even number of mirrors, on the 165 cells: every step a homomorphism, and the composite is e_i -> lam e_i Omega on every generator, with lam = omega_2^2 of the second step times omega_2^2 of the fourth (both maps homomorphisms: Psi(e_S) = lam^|S| e\'_S on every label): lam = +1 for %d sequences, lam = -1 for %d, where Psi = phi o alpha (alpha: e_i -> -e_i); alpha is inner exactly in the %d cells (p,q,0) with n even (an invertible blade anticommuting with every generator, the volume element) and outer in the other %d (no invertible blade anticommutes with every generator, and a unit that did would have one in its support; for n odd the central omega goes to -omega)' % (len(SEQS), lamc[1], lamc[-1], sum(inner.values()), len(ALLC) - sum(inner.values())))
nodd = nnull = nchg = 0
for c in ALLC:                                                             # controls, with the true omega_2^2 in every version
    eps = sig(*c); n = len(eps); cur, gi, okh = iterate(eps, ((1, 1), (1, -1), (1, -1), (1, -1)), fault=False)
    Om = 255 << n; nchg += cur[:n] != eps; nodd += okh and cur[:n] == tuple(-e for e in eps) and (not any(eps) or cur[:n] != eps) and int(s_vec(cur, Om, Om)) == -1 and cur[n:] == (1, 1, 1, -1, 1, -1, 1, -1)
    nnull += all(all(int(s_vec(eps + nb_, l, l)) == 0 for _, l in twist_imgs(eps + nb_, n, 3 << n)) for nb_ in ((1, 0), (-1, 0), (0, 0)))
chk('ctl', nodd == len(ALLC) and nnull == len(ALLC), 'cc.ABS: an odd number of mirrors (one step (2,0,0), three (1,1,0)): the four steps end in the mirror\'s cell, the start generators carrying the squares of Cl(q,p,r) (%d of the 165 cells change, all but the 9 cells (0,0,r)), followed by the block (1,1,1,-1,1,-1,1,-1) with Omega^2 = -1, a relabelling of the clock-2 cell Cl(5,3): not Cl(p,q,r) (x) M16(R) by e_i -> e_i Omega with Omega^2 = +1 (in %d of 165 cells), pass 8c\'s clock-2 finding for blocks of two; with a null block of two, (1,0,1), (0,1,1) or (0,0,2), omega_2^2 = 0 and every twisted generator squares to 0 (%d of 165 cells)' % (nchg, nodd, nnull))
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ cc.C24  the count in closed form and the centre by all labels, to 24 generators
head('cc.C24  the count sum e_a^2 in closed form, Re[(1 + i)^p (1 - i)^(q+1)], and the centre by the commutation parity of every label, to n = 16 and at 24 generators')
t = time.time()
def gmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])   # exact Gaussian integers as pairs (core_check.py)
def gpow(x, k):
    r_ = (1, 0)
    for _ in range(k): r_ = gmul(r_, x)
    return r_
def count_closed(p, q, short=False):
    """Re[(1 + i)^p (1 - i)^(q+1)] = Re((1 - i) S), S the Gauss sum (1 + i)^p (1 - i)^q of LNC-055; with short (and under --fault COUNTQ)
    the factor (1 - i)^q, one short"""
    return gmul(gpow((1, 1), p), gpow((1, -1), q if (short or FAULT == 'COUNTQ') else q + 1))[0]
def central_closed(c, n_labels=None):
    """the central labels by hand: the labels made of an even number of null bits only, and the top label when n is odd (under --fault
    CENTREEVEN the top label for even n too)"""
    p, q, r = c; n = p + q + r; a = np.arange(1 << n, dtype=np.uint32); nq = p + q
    out = ((a & np.uint32((1 << nq) - 1)) == 0) & (np.bitwise_count(a) % 2 == 0)
    if n % 2 == 1 or FAULT == 'CENTREEVEN': out[(1 << n) - 1] = True
    return out
_RP = {}
def reorder_parity(n):
    """the reordering parity of s(a,a) for every label a < 2^n, sum_i [i in a] #(bits of a below i) mod 2, the kernel's formula term by term
    on unsigned 32-bit labels (it reads no eps, so it is computed once for each n)"""
    if n not in _RP:
        a = np.arange(1 << n, dtype=np.uint32); par = np.zeros(1 << n, dtype=np.uint8)
        for i in range(n): par ^= ((a >> np.uint32(i)) & np.uint32(1)).astype(np.uint8) & (np.bitwise_count(a & np.uint32((1 << i) - 1)) & np.uint8(1))
        _RP[n] = (a, par)
    return _RP[n]
def diag_count(eps):
    """sum over all 2^n labels of s(a,a) = (-1)^(the reordering parity) times the product of the eps of a (the kernel's formula on the
    diagonal), enumerated; no reduction, no sample"""
    a, par = reorder_parity(len(eps)); qm = sum(1 << i for i, e in enumerate(eps) if e == -1); nm = sum(1 << i for i, e in enumerate(eps) if e == 0)
    neg = (par ^ (np.bitwise_count(a & np.uint32(qm)) & np.uint8(1))).astype(bool); live = (a & np.uint32(nm)) == 0
    return int(np.count_nonzero(live & ~neg)) - int(np.count_nonzero(live & neg))
def central_enum(eps):
    """the central labels by the commutation parity of each label with each generator (popcounts, no product): e_a e_i = +- e_i e_a with
    the parity of (#bits of a above i) - (#bits of a below i); a null generator inside a gives 0 on both sides"""
    n = len(eps); a = np.arange(1 << n, dtype=np.uint32); cen = np.ones(1 << n, dtype=bool)
    for i, e in enumerate(eps):
        par = ((np.bitwise_count(a >> np.uint32(i + 1)) ^ np.bitwise_count(a & np.uint32((1 << i) - 1))) & np.uint8(1)) == 0
        cen &= (par | (((a >> np.uint32(i)) & np.uint32(1)) == 1)) if e == 0 else par
    return cen
C16 = [c for n in range(17) for c in cells(n)]                             # the 969 cells with n <= 16
okCnt = okCen = True; nshort = 0; ntopeven = 0
for c in C16:
    p, q, r = c; eps = sig(*c); cnt = diag_count(eps)
    okCnt &= cnt == count_closed(p, q); nshort += cnt != count_closed(p, q, short=True)
    ce = central_enum(eps); okCen &= np.array_equal(ce, central_closed(c))
    if sum(c) % 2 == 0 and sum(c) > 0: ntopeven += not ce[(1 << sum(c)) - 1]
chk('bit', okCnt, 'cc.C24: the count sum_a e_a^2 over all 2^n labels (the kernel\'s diagonal, enumerated) equals Re[(1 + i)^p (1 - i)^(q+1)] (exact Gaussian integers) for the %d cells (p,q,r) with n <= 16, independent of r (a null bit gives e_a^2 = 0): Re((1 - i) S) with S = (1 + i)^p (1 - i)^q the Gauss sum of LNC-055 (there for p + q <= 10), 2^((p+q+1)/2) cos(pi (p - q - 1)/4): c m, 0, -2 c m by the type' % len(C16))
chk('bit', okCen, 'cc.C24: the centre by the commutation parity of every label with every generator (popcounts, no multiplication) for the same %d cells: exactly the labels made of an even number of null bits and, for n odd, the top label (1 + [n odd] central labels for r = 0, 2^(r-1) + [n odd] for r >= 1)' % len(C16))
t24 = time.time()
C24 = cells(24); V24 = sorted({count_closed(c[0], c[1]) for c in C24 if c[2] == 0})
ST24 = [(c0, b) for c0 in START[15:] for b in BLOCKS]                      # the nine third-stage cells of the row-8 chains (GEN-019, GEN-024)
cen24 = central_enum(sig(24, 0)); cnull = central_enum(sig(8, 8, 8))       # the parity test reads no eps of a generator of square +-1
okZ24 = np.array_equal(cen24, central_closed((24, 0, 0))) and int(cen24.sum()) == 1 and np.array_equal(cnull, central_closed((8, 8, 8))) and int(cnull.sum()) == 128
okN24 = True; cnts = []
for c0, b in ST24:
    eps = sig(*c0) + sig(*b) * 2; P, Q = c0[0] + 2 * b[0], c0[1] + 2 * b[1]; cnt = diag_count(eps); ty, ncen, dg = ltype_split(eps, 16)
    okN24 &= cnt == count_closed(P, Q) == dg and ncen == int(cen24.sum()) and type_from_inv(1 << 24, int(cen24.sum()), False, cnt) == ty == ('R', 4096, 1); cnts.append(cnt)
X24 = [(13, 11, 0), (12, 9, 3), (8, 8, 8), (0, 0, 24)]                     # four cells of other clocks and with null generators, at 24
okX24 = all(diag_count(sig(*c)) == count_closed(c[0], c[1]) for c in X24)
chk('bit', okZ24 and okN24 and okX24, 'cc.C24: at 24 generators: the closed form for the %d cells with n = 24 (the non-degenerate ones take the values %s); by enumerating all 2^24 labels, no sample: the count of each of the nine third-stage cells of the row-8 chains equals the closed form and the graded diagonal (%s), and that of (13,11,0), (12,9,3), (8,8,8), (0,0,24) the closed form (clocks 2, 3, 0, 0), the commutation parity of every label with every generator finds one central label, the scalars (the same test for every cell without null generators), and for (8,8,8) the 128 labels of an even number of null bits; with the count, the type from the invariants is M4096(R), the parity reduction\'s (GEN-019, GEN-024)' % (len(C24), V24, sorted(set(cnts))))
nev = sum(1 for c in C16 if sum(c) % 2 == 0 and sum(c) > 0); nevq = sum(1 for c in C16 if sum(c) % 2 == 0 and sum(c) > 0 and c[0] + c[1] > 0)
nc04 = sum(1 for c in C16 if clock(c) % 4 != 0)
chk('ctl', nshort == nc04 and ntopeven == nevq, 'cc.C24: the closed form with (1 - i)^q, one factor short, differs from the enumeration in %d of the %d cells, exactly those whose clock is not 0 or 4 (where Im S = 0 the two agree); the top label at even n >= 2 is not central in %d of the %d such cells (all but the null cells (0,0,r), r even, where it is a product of an even number of null bits)' % (nshort, len(C16), ntopeven, nev))
note('(%.1f s; at 24 generators %.1f s)' % (time.time() - t, time.time() - t24))
note('total %.1f s' % (time.time() - T0))
finish('CHAIN-CLOSURE')
