#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""lat_wall.py: the graded tensor product of the cells and the clock as a homomorphism onto Z8 (the computable part of Wall's
theorem BW(R) = Z8).      python3 lat_wall.py [--fault KOSZUL|SUMPQ|UNGRADED|NOTYPE|NOPARITY]

lat·1  Concatenating two generator lists is the graded tensor product: for every ordered pair of cells Cl(p,q), Cl(p',q') with
       p + q <= 4 and p' + q' <= 4 (225 pairs) and every pair of basis elements, (a (x) b)(a' (x) b') = (-1)^{|b||a'|} aa' (x) bb' is the
       bit-rule product of the labels a | b<<n on the concatenated list of squares (2 537 649 products, exact signs).  Derivation, every
       n: the reordering count of a|b<<n against a'|b'<<n is (a against a') + (b against b') + |b||a'|, and the square factor splits.
lat·2  The class of a cell: T(A) = (division algebra, number of simple summands) of A and D(A0) = the division algebra of its even part.
       [bit]  the Frobenius-Schur count nu = sum_a sign(e_a^2) over the labels (its sign is the type), the centre as the labels that
              commute with every generator (resp. the even labels that commute with every even label) and the square of the central
              volume element; for the 45 cells p + q <= 8 the pair (T(A), D(A0)) depends on the clock c = p - q mod 8 alone and takes 8
              distinct values.  Kept with the number of summands of A0 it is a function of the clock only for p + q >= 1: Cl(0,0) has
              even part R, Cl(1,1) has R + R (End(R^{1|1})_0 = R + R), so that number is not a class invariant.
       [std]  numpy Kronecker words (gamma_j = Z (x) .. (x) Z (x) X_j (x) 1 (x) .., X_j = sigma_x or the rotation [[0,-1],[1,0]]), never a label:
              squares, centre and nu from the matrices, the 27 cells 1 <= p + q <= 6; and the recalled table of real Clifford algebras
              (Atiyah, Bott and Shapiro), for comparison only.
lat·3  The class map [Cl(p,q)] -> p - q mod 8 is a homomorphism onto Z8 of the monoid of cells under the graded tensor product: the pair of
       Cl(p,q) (x)^ Cl(p',q'), computed on the product (sign table of lat·1), is the pair of the clock c + c' for all 225 pairs; Cl(k,0),
       k = 0..7, meet the eight classes; Cl(8,0) and Cl(1,1) have the class of R (order 8 of [Cl(1,0)], inverse [Cl(0,1)]).
       [std]  the matrix route of the graded product, gamma_i (x) 1 and P (x) gamma'_j with P = Z^{(x) n} the parity: the same classes for
              the 100 pairs p + q, p' + q' <= 3.
lat·4  The clock-0 cells with p + q <= 8, (0,0), (1,1), (2,2), (3,3), (4,4), (8,0), (0,8), are End of a super vector space: the volume
       element w is even, w^2 = +1, w anticommutes with every generator (the grading is inner, x -> w x w^-1), the cell is simple of type R,
       so A = End(V) with V the minimal module graded by w, and dim V0 = dim V1 (e_1 w e_1^-1 = -w).  Hence Cl(p,q) ~ Cl(p+1,q+1) ~ Cl(p+8,q)
       ~ Cl(p,q+8) (graded Morita, by the graded product with Cl(1,1), Cl(8,0), Cl(0,8)): cells with the same clock are graded Morita
       equivalent.  [std] the Kronecker words: w has eigenvalues +1 and -1 with equal multiplicity and anticommutes with each gamma_j.
Recalled, not computed: that (T(A), D(A0)) is a graded Morita invariant, so cells with different clocks are not equivalent, and that
every graded central simple R-algebra is equivalent to a cell (Wall, "Graded Brauer groups"; Lam, Introduction to Quadratic Forms over
Fields).
[ctl] KOSZUL (the ungraded product, no Koszul sign), SUMPQ (the class map p + q), UNGRADED (the type of A alone), NOTYPE (the Morita
test without the type condition: Cl(4,0)), NOPARITY (the matrix route without the parity P).
No Forms, Lie or Grav object of the gravity engine is built: its eight engine faults do not apply; the controls are the faults above.
Command: python3 lat_wall.py   (from this folder, or python3 selfcheck/proofs/lat_wall.py from the root of the checks; numpy)."""
import sys, time
import numpy as np

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('KOSZUL', 'SUMPQ', 'UNGRADED', 'NOTYPE', 'NOPARITY')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
STEP = 'LAT-WALL' + ('-' + FAULT if FAULT else '')
T0 = time.time()

# ------------------------------------------------------------------------------------------------ the bit rule
def pc(a): return bin(a).count('1')
def sgn(a, b, eps):
    """e_a e_b = sgn(a, b) e_(a^b): (-1)^(pairs i in a, j in b, j < i) times the squares of the common generators"""
    s = 1
    for i in range(len(eps)):
        if a >> i & 1:
            if pc(b & ((1 << i) - 1)) & 1: s = -s
            if b >> i & 1: s *= eps[i]
    return s
def sig(p, q): return [1] * p + [-1] * q
CELLS = [(p, n - p) for n in range(0, 9) for p in range(n, -1, -1)]          # the 45 cells p + q <= 8
def table(eps):
    n = len(eps); N = 1 << n
    return [[sgn(a, b, eps) for b in range(N)] for a in range(N)]

# ------------------------------------------------------------------------------------------------ the class of a sign table
def cls(S, n, keepk0=False):
    """S[a][b]: e_a e_b = S[a][b] e_(a^b) on F_2^n.  Returns (T(A), D(A0)) or (T(A), T(A0)) with keepk0; None if the centre is too big"""
    N = 1 << n; gens = [1 << i for i in range(n)]
    def typ(labels, central):
        nu = sum(S[a][a] for a in labels)
        cen = [a for a in labels if all(S[a][g] == S[g][a] for g in central)]
        if len(cen) == 1: return ('R' if nu > 0 else 'H' if nu < 0 else '?', 1)
        if len(cen) != 2: return ('centre%d' % len(cen), 0)
        w = cen[1]; w2 = S[w][w]
        if w2 == -1: return ('C', 1)
        return ('R' if nu > 0 else 'H' if nu < 0 else '?', 2)
    allA = list(range(N)); even = [a for a in range(N) if pc(a) % 2 == 0]
    tA = typ(allA, gens)
    if FAULT == 'UNGRADED': return (tA,)
    tE = typ(even, even if n >= 1 else [0])
    return (tA, tE if keepk0 else tE[0])
PAIR = {}                                                                    # clock -> class, from the cells Cl(c,0)
for c in range(8):
    PAIR[c] = cls(table(sig(c, 0)), c)
def clock(p, q): return ((p + q) if FAULT == 'SUMPQ' else (p - q)) % 8

head('lat·2  the class (T(A), D(A0)) of the 45 cells p + q <= 8 from the bit rule')
bit_cls = {}; bad = []
for (p, q) in CELLS:
    bit_cls[(p, q)] = cls(table(sig(p, q)), p + q)
    if bit_cls[(p, q)] != PAIR[clock(p, q)]: bad.append((p, q))
chk('bit', not bad, 'lat·2: the class of every cell p + q <= 8 is that of Cl(c,0) with c = p - q mod 8 (45 cells; mismatches %s)' % bad[:6])
vals = sorted(set(PAIR.values()))
chk('bit', len(vals) == 8, 'lat·2: the eight clocks give %d distinct classes: %s' % (len(vals), '; '.join('c=%d %s' % (c, PAIR[c]) for c in range(8))))
k0 = {(p, q): cls(table(sig(p, q)), p + q, keepk0=True) for (p, q) in [(0, 0), (1, 1), (2, 2), (8, 0)]}
if FAULT != 'UNGRADED':
    chk('bit', k0[(0, 0)][1] == ('R', 1) and k0[(1, 1)][1] == ('R', 2) and k0[(2, 2)][1] == ('R', 2) and k0[(8, 0)][1] == ('R', 2),
        'lat·2: with the summands of A0 kept, Cl(0,0) has even part %s and Cl(1,1), Cl(2,2), Cl(8,0) have %s, %s, %s: the number of summands of '
        'A0 is not a class invariant (End(R^{1|1})_0 = R + R); the class is read from (T(A), D(A0))' % (k0[(0, 0)][1], k0[(1, 1)][1], k0[(2, 2)][1], k0[(8, 0)][1]))
REC = {0: (('R', 1), 'R'), 1: (('R', 2), 'R'), 2: (('R', 1), 'C'), 3: (('C', 1), 'H'), 4: (('H', 1), 'H'), 5: (('H', 2), 'H'), 6: (('H', 1), 'C'), 7: (('C', 1), 'R')}
if FAULT != 'UNGRADED':
    chk('std', all(PAIR[c] == REC[c] for c in range(8)), 'lat·2: equal to the recalled table of real Clifford algebras and their even parts (Atiyah, Bott and Shapiro), clock by clock')

# numpy Kronecker words
SX = np.array([[0, 1], [1, 0]]); SZ = np.array([[1, 0], [0, -1]]); EP = np.array([[0, -1], [1, 0]]); I2 = np.eye(2, dtype=int)
def kron_all(ms):
    out = np.array([[1]])
    for m in ms: out = np.kron(out, m)
    return out
def gammas(eps):
    n = len(eps); G = []
    for j in range(n):
        G.append(kron_all([SZ] * j + [SX if eps[j] == 1 else EP] + [I2] * (n - j - 1)))
    return G
def words(G, n):
    dim = G[0].shape[0] if G else 1; W = []
    for a in range(1 << n):
        M = np.eye(dim, dtype=int)
        for j in range(n):
            if a >> j & 1: M = M @ G[j]
        W.append(M)
    return W
def cls_std(G, n):
    W = words(G, n); N = 1 << n; dim = W[0].shape[0]
    sq = [int(round((W[a] @ W[a])[0, 0])) for a in range(N)]
    assert all(np.array_equal(W[a] @ W[a], sq[a] * np.eye(dim, dtype=int)) for a in range(N))
    def typ(labels, central):
        nu = sum(sq[a] for a in labels)
        cen = [a for a in labels if all(np.array_equal(W[a] @ W[g], W[g] @ W[a]) for g in central)]
        if len(cen) == 1: return ('R' if nu > 0 else 'H', 1)
        if len(cen) != 2: return ('centre%d' % len(cen), 0)
        if sq[cen[1]] == -1: return ('C', 1)
        return ('R' if nu > 0 else 'H', 2)
    even = [a for a in range(N) if pc(a) % 2 == 0]
    tA = typ(list(range(N)), [1 << i for i in range(n)])
    if FAULT == 'UNGRADED': return (tA,)
    return (tA, typ(even, even)[0])
bad = []; nstd = 0
for (p, q) in CELLS:
    if p + q > 6 or p + q == 0: continue
    nstd += 1
    if cls_std(gammas(sig(p, q)), p + q) != bit_cls[(p, q)]: bad.append((p, q))
chk('bit==std', not bad, 'lat·2: the Kronecker words give the same class as the bit rule at the %d cells 1 <= p + q <= 6 (mismatches %s)' % (nstd, bad))

# ------------------------------------------------------------------------------------------------ lat·1 and lat·3
head('lat·1  the graded tensor product of two cells is the cell of the concatenated list')
SMALL = [(p, n - p) for n in range(0, 5) for p in range(n, -1, -1)]          # the 15 cells p + q <= 4
TAB = {pq: table(sig(*pq)) for pq in SMALL}
nprod = 0; bad1 = []; bad3 = []; npairs = 0
for X in SMALL:
    n1 = sum(X); S1 = TAB[X]
    for Y in SMALL:
        n2 = sum(Y); S2 = TAB[Y]; eps = sig(*X) + sig(*Y); n = n1 + n2; npairs += 1
        P = {}
        okp = True
        for a in range(1 << n1):
            for b in range(1 << n2):
                x = a | (b << n1); row = {}
                for a2 in range(1 << n1):
                    for b2 in range(1 << n2):
                        s = S1[a][a2] * S2[b][b2] * (1 if FAULT == 'KOSZUL' else (-1) ** (pc(b) * pc(a2)))
                        y = a2 | (b2 << n1); row[y] = s; nprod += 1
                        if s != sgn(x, y, eps): okp = False
                P[x] = row
        if not okp: bad1.append((X, Y))
        S = [[P[x][y] for y in range(1 << n)] for x in range(1 << n)]
        if cls(S, n) != PAIR[clock(X[0] + Y[0], X[1] + Y[1])] or cls(S, n) != PAIR[(clock(*X) + clock(*Y)) % 8]: bad3.append((X, Y))
chk('bit', not bad1, 'lat·1: (a (x) b)(a\' (x) b\') = (-1)^{|b||a\'|} aa\' (x) bb\' equals the bit-rule product on the concatenated list for all %d ordered pairs of cells with p + q, p\' + q\' <= 4: %d products, mismatching pairs %s' % (npairs, nprod, bad1[:4]))
head('lat·3  the class map is a homomorphism onto Z8')
chk('bit', not bad3, 'lat·3: the class of Cl(p,q) (x)^ Cl(p\',q\'), computed on the product, is the class of the clock c + c\' mod 8 for all %d pairs (mismatches %s)' % (npairs, bad3[:4]))
onto = sorted(set(clock(k, 0) for k in range(8))) == list(range(8)) and len(set(bit_cls[(k, 0)] for k in range(8))) == 8
chk('bit', onto and bit_cls[(8, 0)] == bit_cls[(0, 0)] and bit_cls[(1, 1)] == bit_cls[(0, 0)],
    'lat·3: Cl(k,0), k = 0..7, meet the eight classes (onto Z8, generated by [Cl(1,0)]); Cl(8,0) and Cl(1,1) have the class of R: [Cl(1,0)] has order 8 and [Cl(0,1)] is its inverse')
# [std] the matrix route of the graded product
bad = []; npair_std = 0; relbad = []
for X in SMALL:
    for Y in SMALL:
        n1, n2 = sum(X), sum(Y)
        if n1 > 3 or n2 > 3 or n1 == 0 or n2 == 0: continue
        G1, G2 = gammas(sig(*X)), gammas(sig(*Y))
        Pm = kron_all([SZ] * n1) if FAULT != 'NOPARITY' else np.eye(1 << n1, dtype=int)
        G = [np.kron(g, np.eye(1 << n2, dtype=int)) for g in G1] + [np.kron(Pm, g) for g in G2]
        eps = sig(*X) + sig(*Y); dim = G[0].shape[0]
        rel = all(np.array_equal(G[i] @ G[j] + G[j] @ G[i], (2 * eps[i] if i == j else 0) * np.eye(dim, dtype=int)) for i in range(len(G)) for j in range(len(G)))
        if not rel: relbad.append((X, Y)); continue
        npair_std += 1
        if cls_std(G, n1 + n2) != PAIR[(clock(*X) + clock(*Y)) % 8]: bad.append((X, Y))
chk('std', not relbad and not bad and npair_std == 81, 'lat·3: numpy, gamma_i (x) 1 and P (x) gamma\'_j with P = Z^(x)n the parity satisfy the Clifford relations of the concatenated list and give the class of c + c\' for the %d pairs 1 <= p + q, p\' + q\' <= 3 (relation failures %s, class mismatches %s)' % (npair_std, relbad[:3], bad[:3]))

# ------------------------------------------------------------------------------------------------ lat·4
head('lat·4  the clock-0 cells are End of a super vector space')
ZERO = [(p, q) for (p, q) in CELLS if (p - q) % 8 == 0]
rows = []; ok4 = True
for (p, q) in ZERO + ([(4, 0)] if FAULT == 'NOTYPE' else []):
    n = p + q; eps = sig(p, q); top = (1 << n) - 1
    even = pc(top) % 2 == 0; w2 = sgn(top, top, eps)
    anti = all(sgn(top, 1 << j, eps) == -sgn(1 << j, top, eps) for j in range(n))
    typeR = bit_cls[(p, q)][0] == ('R', 1)
    triv = even and w2 == 1 and anti and (typeR or FAULT == 'NOTYPE')
    rows.append('(%d,%d): w^2 = %+d, anticommutes %s, type %s' % (p, q, w2, anti, bit_cls[(p, q)][0]))
    if n == 0: triv = True                                               # R itself
    if (p, q) == (4, 0): ok4 = ok4 and (not triv)                         # clock 4: inner grading but type H
    else: ok4 = ok4 and triv
chk('bit', ok4, 'lat·4: ' + '; '.join(rows) + ': each clock-0 cell is End(V0 + V1), V the minimal module graded by w, dim V0 = dim V1 (e_1 w e_1^-1 = -w)')
ok = True
for (p, q) in [(1, 1), (2, 2), (3, 3)]:
    n = p + q; W = words(gammas(sig(p, q)), n); w = W[-1]; ev = np.linalg.eigvalsh((w + w.T) / 2.0)
    ok &= int((ev > 0.5).sum()) == int((ev < -0.5).sum()) == (1 << (n - 1)) and all(np.array_equal(w @ W[1 << j], -W[1 << j] @ w) for j in range(n))
chk('std', ok, 'lat·4: Kronecker words of Cl(1,1), Cl(2,2), Cl(3,3): the volume matrix has eigenvalues +1 and -1 with equal multiplicity and anticommutes with every gamma_j')
w2_40 = sgn(15, 15, sig(4, 0)); anti40 = all(sgn(15, 1 << j, sig(4, 0)) == -sgn(1 << j, 15, sig(4, 0)) for j in range(4))
chk('ctl', w2_40 == 1 and anti40 and bit_cls[(4, 0)][0] == ('H', 1), 'lat·4: Cl(4,0) has an inner grading too (w^2 = +1, w anticommutes with each generator) but type H, class 4: the type condition is needed (NOTYPE)')

# ------------------------------------------------------------------------------------------------ controls that run in every mode
head('controls')
Sung = [[TAB[(1, 0)][a >> 0 & 1][a2 >> 0 & 1] * TAB[(1, 0)][a >> 1 & 1][a2 >> 1 & 1] for a2 in range(4)] for a in range(4)]
cen = [a for a in range(4) if all(Sung[a][g] == Sung[g][a] for g in (1, 2))]
chk('ctl', len(cen) == 4, 'Cl(1,0) (x) Cl(1,0) without the Koszul sign is commutative (centre of dimension %d), not the cell Cl(2,0) = M2(R) of clock 2 (KOSZUL)' % len(cen))
chk('ctl', bit_cls[(1, 1)] != PAIR[2], 'the class map p + q mod 8 sends Cl(1,1) to 2, but Cl(1,1) has the class of R, not that of clock 2 (SUMPQ)')
tA_only = sorted(set(PAIR[c][0] for c in range(8)))
chk('ctl', len(tA_only) == 5, 'the type of A alone takes %d values on the eight clocks, %s: without the even part the map is not injective (UNGRADED)' % (len(tA_only), tA_only))
G1, G2 = gammas([1]), gammas([1]); Gbad = [np.kron(G1[0], I2), np.kron(I2, G2[0])]
chk('ctl', np.array_equal(Gbad[0] @ Gbad[1], Gbad[1] @ Gbad[0]), 'without the parity P the generators of the two factors commute: the Clifford relations of Cl(2,0) fail (NOPARITY)')
print('  (total %.1f s)' % (time.time() - T0))
finish(STEP)
