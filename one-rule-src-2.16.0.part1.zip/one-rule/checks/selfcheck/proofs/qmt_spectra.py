#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""qmt_spectra.py: two one-dimensional spectra, numerically: the Hill discriminant of a periodic potential, and the levels of the
Thomas-Fermi central field against the Madelung order.      python3 qmt_spectra.py [--fault NAME]

H. The Hill discriminant (qmt·H1 .. H6), numerical.  -psi'' + V psi = E psi, period a = 1; M(E) the one-period matrix of (psi, psi'),
   Delta(E) = psi1(a) + psi2'(a) = tr M.  A Kronig-Penney cell (V = 40 on [0, 0.3), 0 on [0.3, 1)) and V = 4 cos(2 pi x).
   [bit]  M as a product of exact-form pieces C + S A (A^2 = V - E, a scalar) in Cl(2,0), the 2 x 2 real grids, by the bit rule
          in floats (Kronig-Penney: two pieces; the cosine: 2000 midpoint steps); Delta = 2 <M>_0; X = M - <M>_0 and X^2.
   [std]  scipy solve_ivp (DOP853, rtol 1e-11, atol 1e-12); the Kronig-Penney closed form (recalled); plane-wave matrices with
          quasi-momentum theta (41 waves; exact Fourier coefficients of the cosine): periodic (theta = 0), antiperiodic (theta = pi)
          and Bloch (9 theta) eigenvalues.
   200 energies per potential; the band edges (Delta = +-2, brentq) are the periodic and antiperiodic eigenvalues; the Bloch
   eigenvalues satisfy Delta = 2 cos theta; X^2 = <M>_0^2 - 1 = Delta^2/4 - 1, negative in a band, zero at an edge, positive in a
   gap.  Recalled, not computed: that the spectrum on the whole line is {|Delta| <= 2} (Eastham; Reed and Simon).  [ctl] TRACE, SIGN.
T. The Thomas-Fermi field and the Madelung order (qmt·T1 .. T6), numerical.  phi'' = phi^(3/2)/sqrt(x), phi(0) = 1, phi(inf) = 0 by
   shooting (solve_ivp and bisection) and by solve_bvp; V(r) = -max(Z phi(r/b), 1)/r with b = 0.88534 Z^(-1/3) (the -1/r tail of
   Latter, recalled); the levels (n, l), n <= 7, l <= 3, of -u''/2 + (V + l(l+1)/2r^2) u = e u by finite differences on a log grid
   (scipy eigh_tridiagonal, Sturm bisection; 8000 and 16000 points), Z = 19, 20, 24, 29, 30, 50; their order against the Madelung order (n + l, then
   n) and the lowest fillings.  Recalled, not computed: the interactions beyond the central field that real atoms need.  [ctl] NOSCREEN.
Scope: as stated; every line of H and T is numerical, with its tolerance.  No gravity engine object, so its eight engine faults are
not seen; the controls are:
Options: --fault NAME (TRACE, SIGN in H; NOSCREEN in T) runs only the item that carries the wrong version and must exit 1.
Command: python3 qmt_spectra.py   (from this folder, or python3 selfcheck/proofs/qmt_spectra.py from the package root; numpy, scipy)."""
import os, sys, math
import numpy as np
from scipy.integrate import solve_ivp, solve_bvp
from scipy.optimize import brentq
from scipy.linalg import eigh_tridiagonal

_here = os.path.dirname(os.path.abspath(__file__))
_selfcheck = os.path.dirname(_here)
for _p in (os.path.join(_selfcheck, 'steps15_17'),):
    if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
from bitcliff import Alg, sig

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('TRACE', 'SIGN', 'NOSCREEN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
FAULT_ITEM = {'TRACE': 'hill', 'SIGN': 'hill', 'NOSCREEN': 'tf'}

# ================================================================================================ H. the Hill discriminant
CL = Alg(sig(2, 0))                                              # e1 <-> diag(1, -1), e2 <-> [[0, 1], [1, 0]], e12 <-> [[0, 1], [-1, 0]]
TAB = [[CL.blade_mul(a, b) for b in range(4)] for a in range(4)]
def cmul(x, y):
    out = [0.0, 0.0, 0.0, 0.0]
    for a in range(4):
        xa = x[a]
        if xa:
            for b in range(4):
                s, m = TAB[a][b]
                out[m] += s * xa * y[b]
    return out
def gen_A(V, E):
    """A = [[0, 1], [V - E, 0]] = alpha e2 + beta e12 with alpha = (1 + V - E)/2, beta = (1 - (V - E))/2; A^2 = V - E"""
    return [0.0, 0.0, (1 + V - E) / 2, (1 - (V - E)) / 2]
def piece(V, E, L):
    w = V - E
    if w > 0: k = math.sqrt(w); C, S = math.cosh(k * L), math.sinh(k * L) / k
    elif w < 0: k = math.sqrt(-w); C, S = math.cos(k * L), math.sin(k * L) / k
    else: C, S = 1.0, L
    A = gen_A(V, E)
    return [C + S * A[0], S * A[1], S * A[2], S * A[3]]
def to_mat(x):
    s, a, b, c = x
    return np.array([[s + a, b + c], [b - c, s - a]])
V0, BW = 40.0, 0.3
def M_bit_kp(E): return cmul(piece(0.0, E, 1 - BW), piece(V0, E, BW))
QC, NST = 2.0, 2000
def Vcos(x): return 2 * QC * math.cos(2 * math.pi * x)
def M_bit_cos(E, n=NST):
    M = [1.0, 0.0, 0.0, 0.0]; h = 1.0 / n
    for i in range(n): M = cmul(piece(Vcos((i + .5) * h), E, h), M)
    return M
def M_std(Vf, E, breaks=(0.0, 1.0), pieces=None):
    Y = np.eye(2)
    segs = pieces if pieces is not None else [(x0, x1, Vf) for x0, x1 in zip(breaks[:-1], breaks[1:])]
    for x0, x1, Vp in segs:
        def f(x, y, Vp=Vp):
            v = Vp(x) - E; return [y[1], v * y[0], y[3], v * y[2]]
        sol = solve_ivp(f, (x0, x1), [Y[0, 0], Y[1, 0], Y[0, 1], Y[1, 1]], method='DOP853', rtol=1e-11, atol=1e-12)
        y = sol.y[:, -1]; Y = np.array([[y[0], y[2]], [y[1], y[3]]])
    return Y
def kp_std(E): return M_std(None, E, pieces=[(0.0, BW, lambda x: V0), (BW, 1.0, lambda x: 0.0)])
def kp_closed(E):
    k = math.sqrt(E); w = 1 - BW
    if E < V0:
        q = math.sqrt(V0 - E); return 2 * (math.cos(k * w) * math.cosh(q * BW) + (q * q - k * k) / (2 * k * q) * math.sin(k * w) * math.sinh(q * BW))
    q = math.sqrt(E - V0); return 2 * (math.cos(k * w) * math.cos(q * BW) - (k * k + q * q) / (2 * k * q) * math.sin(k * w) * math.sin(q * BW))
def planewave(theta, nw=20):
    ns = np.arange(-nw, nw + 1); H = np.diag(((2 * math.pi * ns + theta)) ** 2)
    for i in range(len(ns) - 1): H[i, i + 1] = H[i + 1, i] = QC
    return np.linalg.eigvalsh(H)
def delta_of(M, wrong=False):
    m = to_mat(M) if isinstance(M, list) else M
    return m[0, 0] + (m[0, 1] if wrong else m[1, 1])

def item_hill():
    head('H. The Hill discriminant and the band edges (numerical)')
    wrong = FAULT == 'TRACE'
    Es_kp = np.linspace(0.5, 150.0, 200); Es_c = np.linspace(-4.0, 150.0, 200)
    d_bit = np.array([2 * M_bit_kp(E)[0] for E in Es_kp]); d_std = np.array([np.trace(kp_std(E)) for E in Es_kp]); d_cl = np.array([kp_closed(E) for E in Es_kp])
    det_ok = all(abs(np.linalg.det(to_mat(M_bit_kp(E))) - 1) < 1e-9 for E in Es_kp)
    e1 = np.max(np.abs(d_bit - d_std) / np.maximum(1, np.abs(d_std))); e2 = np.max(np.abs(d_bit - d_cl) / np.maximum(1, np.abs(d_cl)))
    chk('bit==std', e1 < 1e-7 and e2 < 1e-9 and det_ok, 'qmt·H1: Kronig-Penney (V = 40 on [0, 0.3), 0 on [0.3, 1)): Delta = 2 <M>_0 from two exact-form pieces in Cl(2,0) (bit rule, floats) against solve_ivp (largest relative difference %.1e) and the closed form (%.1e), at 200 energies in [0.5, 150]; det M = 1 within 1e-9 (numerical)' % (e1, e2))
    c_bit = np.array([2 * M_bit_cos(E)[0] for E in Es_c]); c_std = np.array([np.trace(M_std(Vcos, E)) for E in Es_c])
    e3 = np.max(np.abs(c_bit - c_std) / np.maximum(1, np.abs(c_std)))
    chk('bit==std', e3 < 1e-4, 'qmt·H1: V = 4 cos(2 pi x): Delta from 2000 midpoint pieces in Cl(2,0) against solve_ivp at 200 energies in [-4, 150]: largest relative difference %.1e (< 1e-4, the step error; numerical)' % e3)
    # edges of the cosine potential from solve_ivp, against the periodic and antiperiodic plane-wave eigenvalues
    D = lambda E: delta_of(M_std(Vcos, E), wrong)
    grid = np.linspace(-4.0, 150.0, 700)
    per = [e for e in planewave(0.0) if -4 <= e <= 150]; anti = [e for e in planewave(math.pi) if -4 <= e <= 150]
    edges = {2: per, -2: anti}
    res = max([abs(D(e) - 2) for e in per] + [abs(D(e) + 2) for e in anti])
    alle = sorted(per + anti); mids = [alle[0] - 1.0] + [(a_ + b_) / 2 for a_, b_ in zip(alle[:-1], alle[1:])]
    kinds = ['gap' if abs(D(m_)) > 2 else 'band' for m_ in mids]
    alt = all(k_ == ('gap' if i % 2 == 0 else 'band') for i, k_ in enumerate(kinds))
    gaps = [b_ - a_ for i, (a_, b_) in enumerate(zip(alle[:-1], alle[1:])) if i % 2 == 1]
    chk('std', res < 1e-6 and alt, 'qmt·H2: V = 4 cos(2 pi x): the %d periodic and %d antiperiodic eigenvalues of the plane-wave matrix (41 waves) in [-4, 150] are roots of Delta = 2 and Delta = -2 (solve_ivp; largest |Delta -+ 2| = %.1e), and between consecutive ones |Delta| > 2 and < 2 alternate, a gap below the lowest: they are the band edges, with gaps of widths %s (numerical)' % (len(per), len(anti), res, ', '.join('%.2g' % g_ for g_ in gaps)))
    ok_b = True; nb = 0
    for j in range(9):
        th = math.pi * j / 8
        for E in planewave(th)[:6]:
            ok_b &= abs(np.trace(M_std(Vcos, E)) - 2 * math.cos(th)) < 1e-6; nb += 1
    chk('std', ok_b, 'qmt·H3: the lowest 6 Bloch eigenvalues at 9 quasi-momenta theta = 0, pi/8, .., pi (plane waves) satisfy Delta(E) = 2 cos theta within 1e-6 (%d energies; numerical): the Bloch spectrum lies in {|Delta| <= 2}' % nb)
    # Kronig-Penney edges: periodic or antiperiodic solutions
    Dk = lambda E: delta_of(M_bit_kp(E), wrong)
    gk = np.linspace(0.5, 150, 1500); vk = np.array([Dk(E) for E in gk]); ok_k = True; nk = 0
    for sgn in (2, -2):
        g = vk - sgn
        for i in range(len(gk) - 1):
            if g[i] * g[i + 1] < 0:
                E = brentq(lambda E: Dk(E) - sgn, gk[i], gk[i + 1], xtol=1e-13); M = kp_std(E)
                w, V_ = np.linalg.eig(M); j = int(np.argmin(np.abs(w - sgn / 2)))
                v = np.real(V_[:, j]); v = v / np.linalg.norm(v)
                ok_k &= abs(w[j] - sgn / 2) < 1e-4 and np.linalg.norm(M @ v - (sgn / 2) * v) < 1e-4; nk += 1
    chk('std', ok_k and nk >= 5, 'qmt·H4: Kronig-Penney: at each of the %d roots of Delta = +-2 in [0.5, 150] the solve_ivp one-period matrix has the eigenvalue +-1: a periodic or antiperiodic solution (residual < 1e-4, a double eigenvalue; numerical)' % nk)
    # the sign trio
    ok_t = True; cnt = {-1: 0, 0: 0, 1: 0}
    for E in Es_c:
        M = M_bit_cos(E, 600); x0 = M[0]; X = [0.0, M[1], M[2], M[3]]; X2 = cmul(X, X)
        ok_t &= abs(X2[1]) + abs(X2[2]) + abs(X2[3]) < 1e-9 * (1 + abs(X2[0])) and abs(X2[0] - (x0 * x0 - 1)) < 1e-8 * (1 + abs(X2[0]))
        dlt = 2 * x0; band = abs(dlt) < 2
        sg = (1 if x0 > 0 else -1) if FAULT == 'SIGN' else (1 if X2[0] > 0 else -1)
        ok_t &= (sg < 0) == band; cnt[sg] += 1
    edge_x2 = []
    for e in sorted(edges[2])[:3] + sorted(edges[-2])[:3]:
        M = to_mat(M_bit_cos(e)); x0 = (M[0, 0] + M[1, 1]) / 2; edge_x2.append(abs(x0 * x0 - np.linalg.det(M)))
    chk('bit', ok_t and max(edge_x2) < 1e-3, 'qmt·H5: M = <M>_0 + X in Cl(2,0): X^2 is a scalar equal to <M>_0^2 - 1 (numerical, 1e-8): at the 200 energies of the cosine potential (600 midpoint steps) X^2 < 0 exactly in the bands |Delta| < 2 (%d energies) and X^2 > 0 in the gaps (%d); at six edges |X^2| < 1e-3 (2000 steps): the signs -1, 0, +1 of the trio (the grouping is the reading of LNS-022e, ours)' % (cnt[-1], cnt[1]))
    # controls
    Dw = lambda E: delta_of(M_std(Vcos, E), True)
    vw = np.array([Dw(E) for E in grid[:200]]); roots_w = []
    for i in range(199):
        if (vw[i] - 2) * (vw[i + 1] - 2) < 0: roots_w.append(brentq(lambda E: Dw(E) - 2, grid[i], grid[i + 1]))
    dist = max([min(abs(r_ - p_) for p_ in per) for r_ in roots_w] or [0])
    chk('ctl', dist > 1e-2, 'qmt·H6: psi1(a) + psi2(a) in place of psi1(a) + psi2\'(a): its roots of = 2 in [-4, %.0f] miss the periodic eigenvalues (largest distance %.2f; the --fault TRACE run uses it for the edges)' % (grid[199], dist))
    bad = sum(1 for E in Es_c if ((1 if M_bit_cos(E, 600)[0] > 0 else -1) < 0) != (abs(2 * M_bit_cos(E, 600)[0]) < 2))
    chk('ctl', bad > 0, 'qmt·H6: the trio read as the sign of <M>_0 (in place of the sign of X^2) misplaces %d of the 200 energies (the --fault SIGN run uses it)' % bad)

# ================================================================================================ T. Thomas-Fermi and the Madelung order
def tf_shoot():
    def rhs(x, y): return [y[1], max(y[0], 0.0) ** 1.5 / math.sqrt(x)]
    def fate(s):
        x0 = 1e-8; y0 = [1 + s * x0 + 4 / 3 * x0 ** 1.5, s + 2 * x0 ** 0.5]
        ev1 = lambda x, y: y[0]; ev1.terminal = True
        ev2 = lambda x, y: y[1]; ev2.terminal = True
        sol = solve_ivp(rhs, (x0, 60), y0, method='DOP853', rtol=1e-12, atol=1e-14, events=(ev1, ev2))
        if sol.t_events[0].size: return -1
        if sol.t_events[1].size: return 1
        return 0
    lo, hi = -1.6, -1.58
    for _ in range(40):
        mid = (lo + hi) / 2
        if fate(mid) < 0: lo = mid
        else: hi = mid
    return (lo + hi) / 2
def tf_bvp(X=60.0):
    x = np.concatenate([np.geomspace(1e-6, 1, 200), np.linspace(1.05, X, 400)])
    def fun(x, y): return np.vstack([y[1], np.maximum(y[0], 0) ** 1.5 / np.sqrt(x)])
    def bc(ya, yb): return np.array([ya[0] - 1.0, yb[1] + 3 * yb[0] / X])
    y0 = np.vstack([1 / (1 + x) ** 2, -2 / (1 + x) ** 3])
    sol = solve_bvp(fun, bc, x, y0, tol=1e-7, max_nodes=200000)
    return sol
SUB = 'spdf'
def levels(Vr, nmax=7, lmax=3, N=8000, rmin=1e-8, rmax=400.0, Zs=1.0):
    """u = r^(1/2) v(t), r = e^t: -v'' + ((l + 1/2)^2 + 2 r^2 V) v = 2 e r^2 v, symmetrised (a graded tridiagonal matrix); the
    lowest levels by Sturm bisection (LAPACK stebz) with the absolute tolerance 1e-13, which the grading does not spoil"""
    t = np.linspace(math.log(rmin), math.log(rmax), N + 2)[1:-1]; h = t[1] - t[0]; r = np.exp(t)
    out = {}
    for l in range(lmax + 1):
        d = (2 / h ** 2 + (l + .5) ** 2) / (2 * r ** 2) + Vr(r); e = -1 / (2 * h ** 2 * r[:-1] * r[1:])
        w = eigh_tridiagonal(d, e, eigvals_only=True, select='i', select_range=(0, nmax - l - 1), lapack_driver='stebz', tol=1e-13)
        for k, ev in enumerate(w): out[(l + 1 + k, l)] = float(ev)
    return out
def madelung(keys): return sorted(keys, key=lambda nl: (nl[0] + nl[1], nl[0]))
def filling(lv, Z):
    order = sorted(lv, key=lambda k: lv[k]); conf = []; left = Z
    for (n, l) in order:
        if left <= 0: break
        c = min(left, 2 * (2 * l + 1)); conf.append((n, l, c)); left -= c
    return conf
def cstr(conf, last=3): return ' '.join('%d%s%d' % (n, SUB[l], c) for n, l, c in conf[-last:])

def item_tf():
    head('T. The Thomas-Fermi field and the order of its levels (numerical)')
    s_sh = tf_shoot(); sol = tf_bvp(); s_bv = float(sol.sol(1e-6)[1]) - 2 * 1e-3      # phi'(x) = s + 2 sqrt(x) + .. near 0
    chk('std', sol.status == 0 and abs(s_sh - s_bv) < 2e-3 and abs(s_sh + 1.588071) < 1e-3, 'qmt·T1: Thomas-Fermi phi\'\' = phi^(3/2)/sqrt x, phi(0) = 1: the initial slope by shooting with bisection is %.6f, by solve_bvp on [1e-6, 60] with phi\'(X) = -3 phi(X)/X %.6f; the recalled value -1.588071 (numerical, 1e-3)' % (s_sh, s_bv))
    phi = lambda x: np.where(x <= 60, np.maximum(sol.sol(np.minimum(x, 60))[0], 0), 144 / np.maximum(x, 60) ** 3)
    def V_of(Z):
        b = 0.88534 * Z ** (-1 / 3)
        if FAULT == 'NOSCREEN': return lambda r: -Z / r
        return lambda r: -np.maximum(Z * phi(r / b), 1.0) / r
    hyd = levels(lambda r: -1 / r, nmax=4, lmax=2)
    hyd20 = levels(lambda r: -20 / r, nmax=4, lmax=2, Zs=20)
    chk('std', all(abs(e - (-0.5 / n ** 2)) < 1e-4 for (n, l), e in hyd.items()) and all(abs(e + 200 / n ** 2) / (200 / n ** 2) < 1e-4 for (n, l), e in hyd20.items()), 'qmt·T2: the finite-difference solver (log grid, 8000 points, r in [1e-8, 400], Sturm bisection) gives -1/(2n^2) for -1/r within 1e-4 and -200/n^2 for -20/r within 1e-4 relative (n <= 4, l <= 2; numerical)')
    rep = {}; conv = 0.0; okl = True; split = []
    for Z in (19, 20, 24, 29, 30, 50):
        lv = levels(V_of(Z), Zs=Z); lv2 = levels(V_of(Z), N=16000, Zs=Z)
        conv = max(conv, max(abs(lv[k] - lv2[k]) / abs(lv[k]) for k in lv if lv[k] < -1e-3))
        rep[Z] = lv
        for n in (2, 3, 4):
            es = [lv[(n, l)] for l in range(min(n, 3))]
            okl &= all(es[i + 1] - es[i] > 1e-3 for i in range(len(es) - 1))
        split.append('Z=%d: 3s %.3f, 3p %.3f, 3d %.3f, 4s %.3f, 4d - 4f %.1e' % (Z, lv[(3, 0)], lv[(3, 1)], lv[(3, 2)], lv[(4, 0)], lv[(4, 2)] - lv[(4, 3)]))
    chk('std', conv < 1e-4, 'qmt·T3: the levels below -1e-3 change by at most %.1e (relative) between 8000 and 16000 grid points, for Z = 19, 20, 24, 29, 30, 50 (numerical)' % conv)
    chk('std', okl, 'qmt·T4: in the screened field the levels of one n rise with l by more than 1e-3 (2s < 2p; 3s < 3p < 3d; 4s < 4p < 4d: the l degeneracy of -Z/r is lifted; 4d and 4f, outside the core in the -1/r tail, stay close): ' + '; '.join(split) + ' (Hartree, numerical)')
    lines = []; prefixes = []
    for Z in (20, 30, 50):
        lv = rep[Z]; mad = madelung(lv.keys()); en = sorted(lv, key=lambda k: lv[k])
        inv = [(a, b) for i, a in enumerate(mad) for b in mad[i + 1:] if lv[a] > lv[b] and a[0] + a[1] <= 7 and b[0] + b[1] <= 7]
        k = 0
        while k < len(mad) and sorted(mad[:k + 1], key=lambda x: lv[x]) == mad[:k + 1]: k += 1
        prefixes.append(k)
        lines.append('Z=%d: the first %d subshells of the Madelung order (%s) are in energy order; out of order with n + l <= 7: %s' % (Z, k, ' '.join('%d%s' % (n, SUB[l]) for n, l in mad[:k]), ', '.join('%d%s above %d%s' % (a[0], SUB[a[1]], b[0], SUB[b[1]]) for a, b in inv) or 'none'))
    chk('std', all(p_ >= 5 for p_ in prefixes), 'qmt·T5: ' + '; '.join(lines) + ' (numerical; levels from 8000 points)')
    cfg = {Z: filling(rep[Z], Z) for Z in (19, 20, 24, 29)}
    diff = {}
    for Z in range(15, 37):
        lv = levels(V_of(Z), nmax=5, lmax=2, Zs=Z); diff[Z] = lv[(4, 0)] - lv[(3, 2)]
    cross = next((Z for Z in range(15, 37) if diff[Z] > 0), None)
    chk('std', cross is not None and all(diff[Z] > 0 for Z in range(cross, 37)), 'qmt·T6: in the field of Z = 15 .. 36 the 3d level lies above 4s up to Z = %s and below it from Z = %s on (e(4s) - e(3d) = %s Hartree at Z = 18 .. 22); the lowest fillings (last three subshells): K %s, Ca %s, Cr %s, Cu %s (numerical)' % ((cross - 1) if cross else '?', cross, ', '.join('%.3f' % diff[Z] for Z in range(18, 23)), cstr(cfg[19]), cstr(cfg[20]), cstr(cfg[24]), cstr(cfg[29])))
    hz = levels(lambda r: -20.0 / r, nmax=4, lmax=2, Zs=20)
    deg = max(abs(hz[(n, l)] - hz[(n, 0)]) / abs(hz[(n, 0)]) for (n, l) in hz)
    chk('ctl', deg < 1e-3 and hz[(4, 0)] > hz[(3, 2)], 'qmt·T6: without screening (-20/r) the levels of one n agree to %.1e relative and 4s lies above 3d: the n + l order needs the screened field (the --fault NOSCREEN run uses -Z/r for T4)' % deg)

ITEMS = [('hill', item_hill), ('tf', item_tf)]
if __name__ == '__main__':
    sel = [FAULT_ITEM[FAULT]] if FAULT else None
    for name, it in ITEMS:
        if sel is None or name in sel: it()
    finish('QMT-SPECTRA')
