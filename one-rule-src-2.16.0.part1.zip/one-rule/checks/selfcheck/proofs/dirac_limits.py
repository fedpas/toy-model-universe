#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""dirac_limits.py: the Dirac-Hestenes equation of the coupling step, its spinor modules, little groups, spacetime split, Pauli limit and
C, P, T.      python3 dirac_limits.py [--fault CLOCK|NONMIN|QWRONG|SPACELIKE|SIGMAORDER|KG|ESIGN|NOSANDWICH|TNOK|CNOE]

Conventions of coupling_selfcheck.py, imported and used as they stand: blades are bit masks, bit 0 = time (square +1), the other bits
square -1; the product is its bmul; J = gamma_2 gamma_1 (mask 6, sign -1); D(psi; A, e, m) = nabla(psi) J - e A psi - m psi gamma_0 with
nabla = sum_mu gamma_mu d_mu, the vector derivative when the variables are the components x_mu = x . gamma_mu (x_k = -x^k). A plane wave
psi_0 exp(-J k.x), k.x = sum_mu k_mu x_mu, has the momentum p = sum_mu k_mu gamma_mu.

1. Spinor modules (dlim·MOD, dlim·EXTRA).  For n = 4..8 the n-1 bivectors gamma_k gamma_0 square to +1 and anticommute (Cl+(1,n-1) =
   Cl(n-1,0)); the centre of Cl+(1,n-1); a primitive idempotent e = prod (1 + P_i)/2 from commuting, independent label involutions
   (primitive because e Cl+ e is a division algebra); the left ideal Cl+ e and the commutant e Cl+ e by exact rank (bitcliff.Alg, the
   columns of regular_matrix); N = dim ideal / dim commutant; the 2^k idempotents with the signs of the P_i flipped are orthogonal, sum
   to 1 and give N copies per simple factor, carried into one another by right multiplication with labels; the type is compared with the
   clock coupling_selfcheck.cell(n-1, 0) and computed for Cl(n-1,0) by the same routine.  At n = 5, with Q = I_5 gamma_0 =
   gamma_1 gamma_2 gamma_3 gamma_4: right multiplication by Q commutes with D (three random polynomial fields), the halves psi (1 +- Q)/2
   are minimal left ideals, the current psi gamma_0 psi~ is the sum of the currents of the halves, and on each half its grade-5 part is
   +- <psi psi~>_0 I_5 (exact on random rational psi): it vanishes on none of the ideals tried, and e Q e~ = I_5 e e^dagger gamma_0 with
   e^dagger = gamma_0 e~ gamma_0 (exact on random e) shows e Q e~ != 0 for every e != 0.  For n = 5..8 the right multiplications that keep
   D are the even labels on the spatial bits that commute with J (dimension 2^(n-3)); their centre gives the number of Dirac copies.
2. Little groups (dlim·WIG).  In Cl(1,3) by bitrule_A.BR((1,-1,-1,-1)): the bivectors B with [B, p] = 0 for p = gamma_0, gamma_0 + gamma_3,
   gamma_3 (exact null spaces), their brackets and the inertia of their Killing forms (su(2), e(2), so(1,2)); at rest the solutions of
   D = 0 are the even Pauli part, psi_0 = rho^(1/2) R with R in the stabiliser, and S_k psi = (1/2) sigma_k psi sigma_3 close su(2) with
   i = right J and give S^2 = 3/4.
3. Spacetime split (dlim·SPLIT).  sigma_k = gamma_k gamma_0: sigma_i sigma_j = delta_ij + I eps_ijk sigma_k with I = gamma_0 gamma_1 gamma_2
   gamma_3; e_A -> sigma_A is an algebra isomorphism Cl(3,0) -> Cl+(1,3) (64 products); E = (F - gamma_0 F gamma_0)/2 and
   I B = (F + gamma_0 F gamma_0)/2 on the six basis bivectors and three random rational F, with E_k = F^{k0} and F^{ij} = -eps_ijk B_k.
4. Pauli limit (dlim·PAULI).  hbar = 1, u = 1/c a fifth polynomial variable: the D above with c restored (d_0 = u d_t, A^0 = u phi, mass term
   m c psi gamma_0) on psi = psi_s exp(-J m c^2 t), multiplied by u, expanded in u with exact Fractions: order u^0 keeps the even Pauli part,
   order u^1 is solved for the odd part, order u^2 gives d_t psi J = H(psi); H(psi) - (1/2m) pi^2 psi - e phi psi = lambda (e/2m) B psi sigma_3
   with one lambda (pi^k psi = d^k psi J - e A^k psi, B from the split of F = nabla ^ A), g = -2 lambda: three random fields (psi of degree 2
   in x, static A of degree 2).
5. C, P, T (dlim·CPT).  Operator identities on three random polynomial fields (psi of degree 2, A of degree 1): P: psi -> gamma_0 psi(x-bar)
   gamma_0, A -> gamma_0 A(x-bar) gamma_0; T: psi -> gamma_0 psi(-t, x) b, A -> gamma_0 A(-t, x) gamma_0, b found among the eight odd blades;
   C: psi -> psi c, e -> -e, c found among the even blades; CPT closed form and identity; plane waves on the shell (m = 3, k = (5, 4, 0, 0)
   free; k = (7, 4, 0, 0) with A = 2 gamma_0, e = 1) mapped to solutions (fields P(x) exp(J kappa.x) handled exactly).
[std]  numpy: Jordan-Wigner matrices of coupling_matrix_check.py for the ideal and commutant dimensions (n = 4..8) and the halves at n = 5;
       so(1,3) as 4 x 4 matrices; Pauli matrices and the field tensor; the upper block of beta (alpha.pi)^2/2m (the leading Foldy-Wouthuysen
       term, Bjorken and Drell, recalled) on random complex polynomial 2-spinors; Dirac matrices with C = i gamma^2 K, P = gamma^0,
       T = i gamma^1 gamma^3 K on plane waves; Psi = mat(psi) u carries the bit maps to the matrix maps.
Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL):
   CLOCK      Cl(0,n-1) in place of Cl+(1,n-1) (other types at n = 4, 6, 7, 8; the same type at n = 5);  NONMIN  an idempotent of rank two;
   QWRONG     gamma_0 gamma_4 in place of Q;  SPACELIKE  p = gamma_3 in place of gamma_0 for su(2);  SIGMAORDER  sigma_k = gamma_0 gamma_k;
   KG         a Klein-Gordon field in place of the Dirac field (no spin term);  ESIGN  -e in the Dirac equation only;
   NOSANDWICH P without gamma_0 ... gamma_0;  TNOK  T with the right factor gamma_0;  CNOE  C without e -> -e.
Scope: n = 4..8 for 1 (n = 5 for the halves and the current), Cl(1,3) for 2 to 5; random fields with fixed seeds; exact Fractions on [bit],
floats with the tolerances printed on [std].  The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults
M1-M8 do not reach it; its controls are its own.
Command: python3 dirac_limits.py   (from this folder, or python3 selfcheck/proofs/dirac_limits.py from the package root; numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _p, _f in ((_selfcheck, 'coupling_selfcheck.py'), (_selfcheck, 'coupling_matrix_check.py'), (os.path.join(_selfcheck, 'steps15_17'), 'bitcliff.py'),
               (_researchers, 'bitrule_A.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
import coupling_selfcheck as cs
import coupling_matrix_check as cm
import bitcliff as bc
from bitrule_A import BR, rank_fr, comm

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('CLOCK', 'NONMIN', 'QWRONG', 'SPACELIKE', 'SIGMAORDER', 'KG', 'ESIGN', 'NOSANDWICH', 'TNOK', 'CNOE')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

pc = lambda x: bin(x).count('1')
def commutes(a, b): return ((pc(a) * pc(b) - pc(a & b)) & 1) == 0          # two blades of a non-degenerate algebra commute or anticommute
SQ4 = cs.sqs(4)                                                            # [1, -1, -1, -1]
JM = {6: Fr(-1)}                                                           # J = gamma_2 gamma_1 = - e_{12}
G0 = {1: Fr(1)}
def fr(x): return str(Fr(x))

# ------------------------------------------------------------------------------------------------ exact linear algebra
def rref(rows, ncols):
    M = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncols):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][c]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
        if rk == len(M): break
    return M[:rk], piv
def nullspace(rows, ncols):
    R, piv = rref(rows, ncols); basis = []
    for fcol in [c for c in range(ncols) if c not in piv]:
        v = [Fr(0)] * ncols; v[fcol] = Fr(1)
        for i, p in enumerate(piv): v[p] = -R[i][fcol]
        basis.append(v)
    return basis
def solve(cols, target, keys):
    """x with sum_j x_j cols[j] = target (dicts over keys); None if inconsistent"""
    rows = [[c.get(k, 0) for c in cols] + [target.get(k, 0)] for k in keys]
    R, piv = rref(rows, len(cols) + 1)
    if len(cols) in piv: return None
    x = [Fr(0)] * len(cols)
    for i, p in enumerate(piv): x[p] = R[i][-1]
    return x
def inertia(S):
    """(positive, negative, zero) of a symmetric rational matrix by congruence"""
    S = [[Fr(x) for x in r] for r in S]; n = len(S); out = [0, 0, 0]; idx = list(range(n))
    while idx:
        i = next((j for j in idx if S[j][j] != 0), None)
        if i is None:
            pair = next(((a, b) for a in idx for b in idx if a != b and S[a][b] != 0), None)
            if pair is None: out[2] += len(idx); break
            a, b = pair
            for k in range(n): S[a][k] += S[b][k]
            for k in range(n): S[k][a] += S[k][b]
            continue
        out[0 if S[i][i] > 0 else 1] += 1; idx.remove(i)
        for j in idx:
            f = S[j][i] / S[i][i]
            for k in range(n): S[j][k] -= f * S[i][k]
            for k in range(n): S[k][j] -= f * S[k][i]
    return tuple(out)

# ------------------------------------------------------------------------------------------------ constants and fields (the coupling script's helpers)
def lift(a, nv=4): return {m: {(0,) * nv: Fr(c)} for m, c in a.items() if c}
def crev(a): return {m: cs.rsign(pc(m)) * v for m, v in a.items()}
def cgrade(a, k): return {m: v for m, v in a.items() if pc(m) == k}
def cscale(a, c): return {m: v * c for m, v in a.items() if v * c != 0}
def Dfield(psi, A, e, m, n):
    """the line of coupling_selfcheck.identities(): D = nabla(psi) J - e A psi - m psi gamma_0"""
    sq = cs.sqs(n); Jm, Js = cs.bmul(1 << 2, 1 << 1, sq); Jf = {Jm: {(0,) * n: Fr(Js)}}; g0 = cs.const(1, 1, n)
    return cs.fadd(cs.fadd(cs.fmul(cs.nabla(psi, sq), Jf, sq), cs.fmul(A, psi, sq), -e), cs.fmul(psi, g0, sq), -m)
def fcoord(f, M):
    out = {}
    for b, p in f.items():
        q = {}
        for k, v in p.items():
            s = 1
            for i, mi in enumerate(M):
                if mi == -1 and k[i] % 2: s = -s
            q[k] = v * s
        out[b] = q
    return out
# waves: {kappa: field}, the sum of field_kappa(x) exp(J kappa.x), J on the right, kappa.x = sum_mu kappa_mu x_mu
Z4 = (Fr(0),) * 4
def w_add(W1, W2, c=1):
    r = dict(W1)
    for k, f in W2.items():
        x = cs.fadd(r.get(k, {}), f, c)
        if x: r[k] = x
        else: r.pop(k, None)
    return r
def w_scale(W, c): return {k: {b: cs.pscale(p, c) for b, p in f.items()} for k, f in W.items()} if c != 0 else {}
def w_lmul(afield, W): return {k: g for k, f in W.items() for g in [cs.fmul(afield, f, SQ4)] if g}
def w_rmul(W, b):
    bcm = {m: c for m, c in b.items() if commutes(m, 6)}; bam = {m: c for m, c in b.items() if not commutes(m, 6)}; r = {}
    for k, f in W.items():
        if bcm: r = w_add(r, {k: cs.fmul(f, lift(bcm), SQ4)})
        if bam: r = w_add(r, {tuple(-x for x in k): cs.fmul(f, lift(bam), SQ4)})
    return r
def w_der(W, mu):
    r = {}
    for k, f in W.items():
        g = cs.fder(f, mu)
        if k[mu] != 0: g = cs.fadd(g, cs.fmul(f, lift(JM), SQ4), k[mu])
        if g: r = w_add(r, {k: g})
    return r
def w_nabla(W):
    r = {}
    for mu in range(4): r = w_add(r, w_lmul(lift({1 << mu: 1}), w_der(W, mu)))
    return r
def w_D(W, A, e, m): return w_add(w_add(w_rmul(w_nabla(W), JM), w_lmul(A, W), -e), w_rmul(W, G0), -m)
def w_coord(W, M): return {tuple(M[i] * k[i] for i in range(4)): fcoord(f, M) for k, f in W.items()}
def w_eq(W1, W2): return w_add(W1, W2, -1) == {}

# ================================================================================================ 0. the bit-rule products of the package agree
head('0. The three bit-rule products used here (coupling_selfcheck.bmul, bitrule_A.BR, bitcliff.Alg) [bit]')
ok0 = True
for n in range(1, 9):
    sq = cs.sqs(n); B_ = BR(tuple(sq)); A_ = bc.Alg(sq)
    for a in range(1 << n):
        for b in range(1 << n):
            m, s = cs.bmul(a, b, sq); s2, m2 = A_.blade_mul(a, b)
            ok0 &= (m == a ^ b and s == B_.s(a, b) and (s2, m2) == (s, m))
chk('bit', ok0, 'bmul, BR.s and Alg.blade_mul give the same sign on every pair of labels of Cl(1,n-1), n = 1..8')

# ================================================================================================ 1. spinor modules
head('1. dlim·MOD: Cl+(1,n-1) as a sum of minimal left ideals, n = 4..8 [bit]; numpy matrices [std]')
def gf2_rank(ms):
    piv = {}
    for m in ms:
        x = m
        while x:
            h = x.bit_length() - 1
            if h in piv: x ^= piv[h]
            else: piv[h] = x; break
    return len(piv)
def span_masks(Ps):
    H = {0}
    for P in Ps: H |= {h ^ P for h in H}
    return H
def idem(alg, Ps, signs=None):
    e = {0: Fr(1)}
    for i, P in enumerate(Ps): e = alg.mul(e, {0: Fr(1, 2), P: Fr(1 if signs is None else signs[i], 2)})
    return e
def dtype(alg, masks, Ps):
    """the type of e A e for e = prod (1 + P)/2: b e for the labels b commuting with every P, classes modulo the P's"""
    com = [b for b in masks if all(alg.comm_sign(b, P) == 1 for P in Ps)]; H = span_masks(Ps)
    reps = sorted({min(b ^ h for h in H) for b in com}); nt = [b for b in reps if b != 0]
    if len(reps) == 1: return 'R'
    if len(reps) == 2: return 'C' if alg.sq(nt[0]) == -1 else None
    if len(reps) == 4 and all(alg.sq(b) == -1 for b in nt) and alg.comm_sign(nt[0], nt[1]) == -1: return 'H'
    return None
def find_primitive(alg, masks):
    invs = [a for a in masks if a and alg.sq(a) == 1]
    def rec(Ps):
        t = dtype(alg, masks, Ps)
        if t: return Ps, t
        for P in invs:
            if Ps and P <= Ps[-1]: continue
            if all(alg.comm_sign(P, Q) == 1 for Q in Ps) and gf2_rank(Ps + [P]) == len(Ps) + 1:
                r = rec(Ps + [P])
                if r: return r
        return None
    return rec([])
def rank_mv(vecs, nmask): return rank_fr([{m: v for m, v in x.items()} for x in vecs], nmask)
def structure(alg, masks, e_override=None):
    """centre, primitive idempotent, ideal and commutant (exact ranks), copies; e_override: an idempotent put in place of the primitive one"""
    S = {}
    centre = [a for a in masks if all(alg.comm_sign(a, b) == 1 for b in masks)]
    S['centre'] = len(centre); w = [a for a in centre if a]
    S['nf'] = 2 if (w and alg.sq(w[0]) == 1) else 1; S['csq'] = alg.sq(w[0]) if w else None
    Ps, D = find_primitive(alg, masks); S['Ps'] = Ps; S['D'] = D
    e = idem(alg, Ps) if e_override is None else e_override; S['e'] = e
    S['ideal'] = rank_mv([alg.mul({b: 1}, e) for b in masks], alg.N)
    L = bc.regular_matrix(alg, e)                                          # left multiplication by e: its columns on the labels span e A
    S['right_ideal'] = rank_fr([{r: L[r][b] for r in range(alg.N) if L[r][b]} for b in masks], alg.N)
    S['comm'] = rank_mv([alg.mul(alg.mul(e, {b: 1}), e) for b in masks], alg.N)
    S['N'] = S['ideal'] // S['comm'] if S['comm'] else 0
    S['type'] = ('M%d(%s)' % (S['N'], {1: 'R', 2: 'C', 4: 'H'}.get(S['comm'], '?'))) + ((' + M%d(%s)' % (S['N'], {1: 'R', 2: 'C', 4: 'H'}.get(S['comm'], '?'))) if S['nf'] == 2 else '')
    return S
def copies(alg, masks, Ps):
    k = len(Ps); sig = list(itertools.product((1, -1), repeat=k)); es = [idem(alg, Ps, s) for s in sig]
    tot = {}
    for x in es: tot = alg.add(tot, x)
    orth = all(alg.mul(es[i], es[j]) == {} for i in range(len(es)) for j in range(len(es)) if i != j)
    dims = [rank_mv([alg.mul({b: 1}, x) for b in masks], alg.N) for x in es]
    cen = [a for a in masks if a and all(alg.comm_sign(a, b) == 1 for b in masks)]
    if cen and alg.sq(cen[0]) == 1:
        fac = [1 if alg.mul({cen[0]: 1}, x) == x else -1 for x in es]
    else: fac = [1] * len(es)
    moved = True; reach = 0
    for j, s in enumerate(sig):
        if fac[j] != fac[0]: continue
        bl = next((b for b in masks if all((1 if alg.comm_sign(b, P) == 1 else -1) == s[i] for i, P in enumerate(Ps))), None)
        if bl is None: moved = False; continue
        reach += 1; moved &= alg.mul(es[0], {bl: 1}) == alg.mul({bl: 1}, es[j])     # e_0 b = b e_s: right multiplication by b maps A e_0 onto A e_s
    return dict(n_idem=len(es), sum_one=(tot == {0: Fr(1)}), orth=orth, dims=dims, per_factor=sum(1 for f in fac if f == fac[0]), reach=reach, moved=moved)
def mat_dims(n, e, masks):
    g = cm.gammas(n); E = sum(complex(c) * cm.blade_matrix(g, m) for m, c in e.items())
    def rk(ms): return int(np.linalg.matrix_rank(np.array([np.concatenate([M.real.ravel(), M.imag.ravel()]) for M in ms]), tol=1e-9))
    Ms = [cm.blade_matrix(g, b) for b in masks]
    return rk([M @ E for M in Ms]), rk([E @ M @ E for M in Ms])
EXPECT = {4: 'M2(C)', 5: 'M2(H)', 6: 'M2(H) + M2(H)', 7: 'M4(H)', 8: 'M8(C)'}
MODS = {}
for n in range(4, 9):
    sq = cs.sqs(n); alg = bc.Alg(sq); ev = [m for m in range(1 << n) if pc(m) % 2 == 0]
    gens = [alg.mul({1 << k: 1}, {1: 1}) for k in range(1, n)]              # e_k = gamma_k gamma_0
    t5 = all(alg.mul(x, x) == {0: 1} for x in gens) and all(alg.add(alg.mul(x, y), alg.mul(y, x)) == {} for x, y in itertools.combinations(gens, 2))
    prods = []
    for r in range(n):
        for S_ in itertools.combinations(range(n - 1), r):
            x = {0: 1}
            for i in S_: x = alg.mul(x, gens[i])
            prods.append(x)
    t5 &= rank_mv(prods, alg.N) == len(ev)
    chk('bit', t5, 'n=%d: the %d bivectors gamma_k gamma_0 square to +1, anticommute, and their %d products span the %d even labels (Cl+(1,%d) = Cl(%d,0))' % (n, n - 1, len(prods), len(ev), n - 1, n - 1))
    S = structure(alg, ev); MODS[n] = (alg, ev, S)
    Seu = structure(bc.Alg([1] * (n - 1)), list(range(1 << (n - 1))))
    Smi = structure(bc.Alg([-1] * (n - 1)), list(range(1 << (n - 1))))
    clock = cs.cell(n - 1, 0)
    main = Smi if FAULT == 'CLOCK' else S
    if FAULT == 'NONMIN':
        e2 = alg.add(idem(alg, S['Ps'], [1] * len(S['Ps'])), idem(alg, S['Ps'], [-1] + [1] * (len(S['Ps']) - 1)))
        main = structure(alg, ev, e_override=e2)
    chk('bit', S['centre'] == (2 if n % 2 == 0 else 1) and (S['csq'] == (-1 if n % 4 == 0 else 1) if n % 2 == 0 else True),
        'n=%d: the centre of Cl+(1,%d) has dimension %d%s' % (n, n - 1, S['centre'], '' if S['csq'] is None else ', its second label squares to %+d (%s)' % (S['csq'], 'two simple factors' if S['csq'] == 1 else 'complex type')))
    chk('bit', main['type'] == clock and main['ideal'] == main['right_ideal'],
        'n=%d: primitive idempotent from %d label involution(s) %s; e Cl+ e = %s; left ideal dim %d (= right ideal dim %d, regular_matrix), commutant dim %d, N = %d: %s; the clock cell(%d,0) = %s'
        % (n, len(main['Ps']), main['Ps'], main['D'], main['ideal'], main['right_ideal'], main['comm'], main['N'], main['type'], n - 1, clock))
    chk('bit', Seu['type'] == S['type'], 'n=%d: the same routine on Cl(%d,0) itself gives %s (T5 computed on both sides)' % (n, n - 1, Seu['type']))
    C = copies(alg, ev, S['Ps'])
    chk('bit', C['sum_one'] and C['orth'] and len(set(C['dims'])) == 1 and C['dims'][0] * C['n_idem'] == len(ev) and C['per_factor'] == S['N'] and C['reach'] == S['N'] and C['moved'],
        'n=%d: the %d idempotents with flipped signs are orthogonal and sum to 1, each left ideal has dimension %d (%d x %d = %d), %d copies per simple factor = N, each reached from the first by a right multiplication with a label (e_0 b = b e_s)'
        % (n, C['n_idem'], C['dims'][0], C['n_idem'], C['dims'][0], len(ev), C['per_factor']))
    di, dc = mat_dims(n, S['e'], ev)
    chk('std', (di, dc) == (S['ideal'], S['comm']), 'n=%d: Jordan-Wigner matrices (coupling_matrix_check.gammas): real rank of {M_b E} = %d, of {E M_b E} = %d' % (n, di, dc))
    chk('bit==std', (di, dc) == (S['ideal'], S['comm']) and S['type'] == EXPECT[n], 'n=%d: ideal %d and commutant %d agree between the labels and the matrices; type %s' % (n, S['ideal'], S['comm'], S['type']))
    differs = Smi['type'] != S['type']
    chk('ctl', differs == (n != 5), 'n=%d: a wrong clock, Cl(0,%d) by the same routine, gives %s: %s' % (n, n - 1, Smi['type'], 'differs from Cl+(1,%d)' % (n - 1) if differs else 'the same type (Cl(0,4) = Cl(4,0) = M2(H)): this n does not separate the two clocks'))
    e2 = alg.add(idem(alg, S['Ps'], [1] * len(S['Ps'])), idem(alg, S['Ps'], [-1] + [1] * (len(S['Ps']) - 1)))
    same_factor = S['nf'] == 1 or alg.mul({[a for a in ev if a and all(alg.comm_sign(a, b) == 1 for b in ev)][0]: 1}, e2) in (e2, cscale(e2, -1))
    i2 = rank_mv([alg.mul({b: 1}, e2) for b in ev], alg.N); c2 = rank_mv([alg.mul(alg.mul(e2, {b: 1}), e2) for b in ev], alg.N)
    if same_factor:
        chk('ctl', i2 == 2 * S['ideal'] and c2 == 4 * S['comm'], 'n=%d: an idempotent of rank two (two copies) has ideal %d = 2 x %d and commutant %d = 4 x %d (M2 of the division algebra): not minimal' % (n, i2, S['ideal'], c2, S['comm']))
    else:
        chk('ctl', i2 == 2 * S['ideal'] and c2 == 2 * S['comm'], 'n=%d: an idempotent with one part in each simple factor has ideal %d = 2 x %d and commutant %d = 2 x %d (D + D): not minimal' % (n, i2, S['ideal'], c2, S['comm']))

head('1b. dlim·EXTRA: what the extra components do at n = 5, and the grade-5 part of the current [bit]; matrices [std]')
n = 5; sq5 = cs.sqs(5); A5 = BR(tuple(sq5)); Q = {30: Fr(1)}; I5 = {31: Fr(1)}
chk('bit', A5.mul(I5, G0) == Q and A5.mul(Q, Q) == {0: 1} and commutes(30, 6) and commutes(30, 1) and A5.mul(I5, I5) == {0: 1} and all(commutes(31, 1 << i) for i in range(5)),
    'n=5: Q = I5 gamma_0 = gamma_1 gamma_2 gamma_3 gamma_4, Q^2 = 1, Q commutes with J and gamma_0; I5^2 = 1 and I5 is central')
Qm = {17: Fr(1)} if FAULT == 'QWRONG' else Q                                 # gamma_0 gamma_4 (mask 17) in place of Q
rng = random.Random(1305)
okD = True
for sd in range(3):
    r2 = random.Random(5000 + sd)
    psi = {S_: cs.rpoly(r2, 5, 2, .3) for S_ in range(32) if pc(S_) % 2 == 0}; A = {1 << k: cs.rpoly(r2, 5, 1, .6) for k in range(5)}
    for sgn in (1, -1):
        P_ = lift({0: Fr(1, 2), list(Qm)[0]: Fr(sgn, 2)}, 5)
        okD &= Dfield(cs.fmul(psi, P_, sq5), A, Fr(3), Fr(5), 5) == cs.fmul(Dfield(psi, A, Fr(3), Fr(5), 5), P_, sq5)
chk('bit', okD, 'n=5: D(psi (1 +- Q)/2) = D(psi) (1 +- Q)/2 for three random fields (psi of degree 2, A of degree 1, e = 3, m = 5; the D of coupling_selfcheck): the halves obey the same equation without coupling')
P17 = lift({0: Fr(1, 2), 17: Fr(1, 2)}, 5); r2 = random.Random(5000)
psi = {S_: cs.rpoly(r2, 5, 2, .3) for S_ in range(32) if pc(S_) % 2 == 0}; A = {1 << k: cs.rpoly(r2, 5, 1, .6) for k in range(5)}
chk('ctl', Dfield(cs.fmul(psi, P17, sq5), A, Fr(3), Fr(5), 5) != cs.fmul(Dfield(psi, A, Fr(3), Fr(5), 5), P17, sq5), 'n=5: gamma_0 gamma_4 in place of Q (it anticommutes with gamma_0): D(psi (1 + gamma_0 gamma_4)/2) != D(psi) (1 + gamma_0 gamma_4)/2: those halves are mixed by the mass term')
alg5, ev5, S5 = MODS[5]
for sgn in (1, -1):
    eQ = {0: Fr(1, 2), 30: Fr(sgn, 2)}
    ii = rank_mv([alg5.mul({b: 1}, eQ) for b in ev5], alg5.N); cc = rank_mv([alg5.mul(alg5.mul(eQ, {b: 1}), eQ) for b in ev5], alg5.N)
    chk('bit', ii == 8 and cc == 4 and dtype(alg5, ev5, [30]) == 'H', 'n=5: L%s = Cl+(1 %s Q)/2 is a minimal left ideal: dimension %d, commutant dimension %d (H)' % ('+' if sgn == 1 else '-', '+' if sgn == 1 else '-', ii, cc))
def cur(psi, A_): return A_.mul(A_.mul(psi, G0), crev(psi))
okX = ok5 = nz = True; lam = []
for sd in range(3):
    r3 = random.Random(7000 + sd); psi = {S_: Fr(r3.randint(-5, 5)) for S_ in ev5}
    pp = A5.mul(psi, {0: Fr(1, 2), 30: Fr(1, 2)}); pm = A5.mul(psi, {0: Fr(1, 2), 30: Fr(-1, 2)})
    X = cur(psi, A5); Xp = cur(pp, A5); Xm = cur(pm, A5)
    okX &= X == A5.add(Xp, Xm)
    sp = A5.mul(pp, crev(pp)).get(0, 0); sm = A5.mul(pm, crev(pm)).get(0, 0)
    ok5 &= cgrade(Xp, 5) == ({31: sp} if sp else {}) and cgrade(Xm, 5) == ({31: -sm} if sm else {}) and cgrade(X, 5) == ({31: sp - sm} if sp != sm else {})
    nz &= sp != 0 and sm != 0; lam.append((sp, -sm))
chk('bit', okX, 'n=5: X = psi gamma_0 psi~ equals X+ + X- (the currents of the halves) for three random rational psi: no cross term')
chk('bit', ok5, 'n=5: on L+ the grade-5 part of the current is +<psi psi~>_0 I5, on L- it is -<psi psi~>_0 I5, on the whole even algebra the difference of the two')
chk('bit', nz, 'n=5: the answer is no: the grade-5 part does not vanish on L+ or L- (coefficients %s for the three samples)' % ', '.join('(%s, %s)' % (fr(a), fr(b)) for a, b in lam))
oth = True; det = []
for Ps_ in ([3], [17]):
    for sgn in (1, -1):
        e_ = {0: Fr(1, 2), Ps_[0]: Fr(sgn, 2)}; r4 = random.Random(9000 + Ps_[0] + (sgn > 0))
        x = {S_: Fr(r4.randint(-5, 5)) for S_ in ev5}; psi = A5.mul(x, e_); g5 = cgrade(cur(psi, A5), 5).get(31, 0)
        oth &= g5 != 0; det.append(fr(g5))
chk('bit', oth, 'n=5: on the minimal left ideals Cl+(1 +- gamma_0 gamma_1)/2 (the one of the module search) and Cl+(1 +- gamma_0 gamma_4)/2 a random psi has grade-5 part %s I5: not zero either' % ', '.join(det))
okE = True
for sd in range(3):
    r5 = random.Random(9500 + sd); e_ = {S_: Fr(r5.randint(-4, 4)) for S_ in ev5}
    edag = A5.mul(A5.mul(G0, crev(e_)), G0)
    okE &= A5.mul(A5.mul(e_, Q), crev(e_)) == A5.mul(A5.mul(A5.mul(I5, e_), edag), G0) and A5.mul(e_, edag).get(0, 0) == sum(v * v for v in e_.values())
chk('bit', okE, 'n=5: e Q e~ = I5 e e^dagger gamma_0 with e^dagger = gamma_0 e~ gamma_0 and <e e^dagger>_0 = sum of squares, three random even e: so e Q e~ != 0 for every e != 0 (with polarisation, a derivation: no non-zero left ideal kills the grade-5 part)')
copies_n = {}
for n in range(5, 9):
    sq = cs.sqs(n); alg = bc.Alg(sq); ev = [m for m in range(1 << n) if pc(m) % 2 == 0]
    Cp = [a for a in ev if commutes(a, 1) and commutes(a, 6)]
    spatial = all(not (a & 1) for a in Cp)
    cen = [a for a in Cp if all(commutes(a, b) for b in Cp)]; finv = sum(1 for a in cen if alg.sq(a) == 1)
    Ncp = int(round((len(Cp) / (2 * finv)) ** 0.5)); copies_n[n] = (len(Cp), len(cen), finv, Ncp, finv * Ncp)
    dirac = (1 << (n - 1)) // (1 << (n // 2 + 1))
    chk('bit', spatial and len(Cp) == 2 ** (n - 3) and 6 in Cp and Ncp * Ncp * 2 * finv == len(Cp) and finv * Ncp == dirac,
        'n=%d: the even labels commuting with gamma_0 and J are %d = 2^(n-3) spatial labels; their centre has %d labels, %d of square +1: %d factor(s) M%d(C), so D keeps %d Dirac copies = psi_over_dirac %d'
        % (n, len(Cp), len(cen), finv, finv, Ncp, finv * Ncp, dirac))
g = cm.gammas(5); u, Jmat, sJ = cm.find_u(g)
def mat(x): return sum(complex(c) * cm.blade_matrix(g, m) for m, c in x.items())
Lp = [A5.mul({b: 1}, {0: Fr(1, 2), 30: Fr(1, 2)}) for b in ev5]; Lm = [A5.mul({b: 1}, {0: Fr(1, 2), 30: Fr(-1, 2)}) for b in ev5]
def rr(vs): return int(np.linalg.matrix_rank(np.array([np.concatenate([(mat(v) @ u).real, (mat(v) @ u).imag]) for v in vs]), tol=1e-9))
rp, rm = rr(Lp), rr(Lm); cI = np.trace(mat(I5)) / 4
keep = Lp if rp == 8 else Lm; sgn_keep = 1 if rp == 8 else -1; okT = True
for sd in range(3):
    r6 = random.Random(9900 + sd); x = {S_: Fr(r6.randint(-5, 5)) for S_ in ev5}
    psi = A5.mul(x, {0: Fr(1, 2), 30: Fr(sgn_keep, 2)}); X = cur(psi, A5)
    trX = np.trace(mat(psi) @ mat(G0) @ mat(crev(psi))) / 4
    okT &= abs(trX - cI * sgn_keep * float(A5.mul(psi, crev(psi)).get(0, 0))) < 1e-9 and abs(np.trace(mat(X)) / 4 - trX) < 1e-9
chk('std', sorted((rp, rm)) == [0, 8] and abs(abs(cI) - 1) < 1e-12, 'n=5: psi -> psi u (gamma_0 u = u, J u = %+d i u; Jordan-Wigner 4 x 4): real rank %d on L+ and %d on L-: the matrix spinor sees one half, the other half is the kernel; tr(mat I5)/4 = %+.0f' % (sJ, rp, rm, cI.real))
chk('bit==std', okT, 'n=5: on the half that survives, tr(mat(psi) mat(gamma_0) mat(psi~))/4 = (tr I5/4) (+-<psi psi~>_0), three random psi (tolerance 1e-9): the grade-5 part is the scalar density of that copy')

# ================================================================================================ 2. little groups
head('2. dlim·WIG: the stabilisers of p in Spin(1,3), exact on the labels [bit]; so(1,3) matrices [std]')
A4 = BR(tuple(SQ4)); BIV = [m for m in range(16) if pc(m) == 2]
def stab(p):
    cols = [comm(A4, {B: 1}, p) for B in BIV]
    rows = [[c.get(k, 0) for c in cols] for k in range(16)]
    return [{B: v[i] for i, B in enumerate(BIV) if v[i] != 0} for v in nullspace(rows, 6)]
def table(basis):
    keys = list(range(16)); C = []
    for X in basis:
        row = []
        for Y in basis:
            x = solve(basis, comm(A4, X, Y), keys); row.append(x)
        C.append(row)
    return C
def killing(C):
    d = len(C)
    if any(C[i][j] is None for i in range(d) for j in range(d)): return None
    ad = [[[C[i][j][k] for j in range(d)] for k in range(d)] for i in range(d)]      # (ad X_i)_{k j} = c_{i j k}
    return [[sum(ad[a][k][j] * ad[b][j][k] for j in range(d) for k in range(d)) for b in range(d)] for a in range(d)]
def span_eq(basis, cand):
    return rank_mv(basis, 16) == len(basis) and rank_mv(basis + cand, 16) == len(basis) and rank_mv(cand, 16) == len(cand)
e0, e1, e2, e3 = ({1 << i: Fr(1)} for i in range(4))
p_time = e3 if FAULT == 'SPACELIKE' else e0
St = stab(p_time); Ct = table(St); Kt = killing(Ct)
chk('bit', len(St) == 3 and Kt is not None and inertia(Kt) == (0, 3, 0) and span_eq(St, [A4.mul(e1, e2), A4.mul(e1, e3), A4.mul(e2, e3)]),
    'p = gamma_0 (timelike): the bivectors with [B, p] = 0 span %d dimensions, the spatial bivectors; closed under the bracket; Killing form inertia %s (negative definite: su(2))' % (len(St), None if Kt is None else inertia(Kt)))
R3 = [A4.mul(e2, e3), A4.mul(e3, e1), A4.mul(e1, e2)]; okso3 = True
for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)): okso3 &= comm(A4, R3[i], R3[j]) == A4.scal(R3[k], 2)
chk('bit', okso3, 'the spatial bivectors B1 = g2 g3, B2 = g3 g1, B3 = g1 g2 satisfy [B_i, B_j] = 2 eps_ijk B_k: the so(3) = su(2) structure constants')
pn = A4.add(e0, e3); Sn = stab(pn); Cn = table(Sn); Kn = killing(Cn)
Jr = A4.mul(e1, e2); K1 = A4.mul(pn, e1); K2 = A4.mul(pn, e2)
b1 = comm(A4, Jr, K1); b2 = comm(A4, Jr, K2); b3 = comm(A4, K1, K2)
cc = solve([K2], b1, range(16)); cc2 = solve([K1], b2, range(16))
chk('bit', len(Sn) == 3 and span_eq(Sn, [Jr, K1, K2]) and b3 == {} and cc is not None and cc2 is not None and cc[0] == -cc2[0] != 0 and inertia(Kn) == (0, 1, 2),
    'p = gamma_0 + gamma_3 (null): dimension %d, spanned by J = g1 g2, K1 = (g0 + g3) g1, K2 = (g0 + g3) g2; [J, K1] = %s K2, [J, K2] = %s K1, [K1, K2] = 0; Killing inertia %s (rank 1): e(2)'
    % (len(Sn), fr(cc[0]) if cc else '?', fr(cc2[0]) if cc2 else '?', inertia(Kn) if Kn else None))
Ss = stab(e3); Ks = killing(table(Ss))
chk('bit', len(Ss) == 3 and span_eq(Ss, [A4.mul(e0, e1), A4.mul(e0, e2), A4.mul(e1, e2)]) and inertia(Ks) == (2, 1, 0),
    'p = gamma_3 (spacelike): dimension %d, spanned by g0 g1, g0 g2, g1 g2; Killing inertia %s: so(1,2)' % (len(Ss), inertia(Ks) if Ks else None))
chk('ctl', inertia(Ks) != (0, 3, 0) and inertia(Kn) != (0, 3, 0), 'the spacelike and the null p do not give su(2): Killing inertia %s and %s' % (inertia(Ks), inertia(Kn)))
four = [A4.mul(e1, e2), A4.mul(e1, e3), A4.mul(e2, e3), A4.mul(e0, e3)]
chk('ctl', any(comm(A4, X, e0) != {} for X in four), 'a four-dimensional candidate (the rotations and g0 g3) is not a stabiliser of gamma_0: [g0 g3, g0] != 0')
# std: so(1,3) as 4 x 4 matrices
eta = np.diag([1.0, -1.0, -1.0, -1.0])
def gen_mat(mu, nu):
    M = np.zeros((4, 4)); M[mu, :] += eta[nu, :]; M[nu, :] -= eta[mu, :]; return M
GM = [gen_mat(mu, nu) for mu, nu in itertools.combinations(range(4), 2)]
def stab_np(p):
    Mx = np.array([G @ p for G in GM]).T; U_, s_, Vt = np.linalg.svd(Mx); r = int((s_ > 1e-9).sum())
    return [sum(c * G for c, G in zip(v, GM)) for v in Vt[r:]]
def kill_np(B):
    d = len(B); Bm = np.array([b.ravel() for b in B]).T
    co = lambda X: np.linalg.lstsq(Bm, X.ravel(), rcond=None)[0]
    ad = [np.array([co(X @ Y - Y @ X) for Y in B]).T for X in B]
    K = np.array([[np.trace(ad[a] @ ad[b]) for b in range(d)] for a in range(d)]); ev_ = np.linalg.eigvalsh(K)
    return (int((ev_ > 1e-9).sum()), int((ev_ < -1e-9).sum()), int((abs(ev_) <= 1e-9).sum()))
for name, p in (('timelike', np.array([1.0, 0, 0, 0])), ('null', np.array([1.0, 0, 0, 1.0])), ('spacelike', np.array([0, 0, 0, 1.0]))):
    B = stab_np(p); ki = kill_np(B)
    want = {'timelike': (0, 3, 0), 'null': (0, 1, 2), 'spacelike': (2, 1, 0)}[name]
    chk('std', len(B) == 3 and ki == want, 'so(1,3) as 4 x 4 matrices (X^T eta + eta X = 0): the stabiliser of the %s p has dimension %d, Killing inertia %s' % (name, len(B), ki))
chk('bit==std', inertia(Kt) == (0, 3, 0) and inertia(Kn) == (0, 1, 2) and inertia(Ks) == (2, 1, 0), 'the labels and the matrices give the same dimensions and inertias: su(2), e(2), so(1,2)')
head('2b. dlim·WIG: spin at rest from the mass shell [bit]')
m_ = Fr(3); evn = [m for m in range(16) if pc(m) % 2 == 0]; odd = [m for m in range(16) if pc(m) % 2 == 1]
rows = []
for T in odd: rows.append([A4.add(A4.scal(A4.mul(e0, {S_: 1}), m_), A4.scal(A4.mul({S_: 1}, e0), -m_)).get(T, 0) for S_ in evn])
ker = nullspace(rows, 8); kerm = [{S_: v[i] for i, S_ in enumerate(evn) if v[i] != 0} for v in ker]
chk('bit', len(ker) == 4 == cs.kernel_dim(4) and span_eq(kerm, [{0: 1}, A4.mul(e2, e3), A4.mul(e3, e1), A4.mul(e1, e2)]),
    'the symbol of D at rest, psi -> m gamma_0 psi - m psi gamma_0 (plane wave psi_0 exp(-J m t)), has a kernel of dimension %d (kernel_dim(4) = %d for the other sign of the energy): the even Pauli part 1, g2 g3, g3 g1, g1 g2' % (len(ker), cs.kernel_dim(4)))
okw = all(w_D({(-m_, Fr(0), Fr(0), Fr(0)): lift(x)}, {}, Fr(1), m_) == {} for x in kerm)
chk('bit', okw, 'each kernel element psi_0 gives the exact solution psi_0 exp(-J m t) of D = 0 (the wave form of the coupling script\'s D)')
okst = all(rank_mv(kerm + [A4.mul(B, x)], 16) == 4 for B in St for x in kerm)
okrot = True
for sd in range(3):
    r7 = random.Random(1200 + sd); x = {}
    for y in kerm: x = A4.add(x, A4.scal(y, Fr(r7.randint(-6, 6))))
    nn = sum(v * v for v in x.values())
    okrot &= A4.mul(x, crev(x)) == ({0: nn} if nn else {}) and A4.mul(A4.mul(x, e0), crev(x)) == ({1: nn} if nn else {})
chk('bit', okst and okrot, 'the stabiliser algebra maps the kernel to itself (left multiplication); a random kernel element has psi_0 psi_0~ = sum of squares and psi_0 gamma_0 psi_0~ = (sum of squares) gamma_0: psi_0 = rho^(1/2) R with R gamma_0 R~ = gamma_0, three samples')
sig = [A4.mul({1 << k: 1}, e0) for k in (1, 2, 3)]; s3 = sig[2]
def Sop(k, x): return A4.scal(A4.mul(A4.mul(sig[k], x), s3), Fr(1, 2))
oksu2 = okcas = okJ = True; Iq = {15: Fr(1)}
for x in kerm:
    for i, j, k in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
        lhs = A4.add(Sop(i, Sop(j, x)), Sop(j, Sop(i, x)), -1); rhs = A4.mul(Sop(k, x), JM)
        oksu2 &= lhs == rhs
    cas = {}
    for k in range(3): cas = A4.add(cas, Sop(k, Sop(k, x)))
    okcas &= cas == A4.scal(x, Fr(3, 4))
    okJ &= all(Sop(k, A4.mul(x, JM)) == A4.mul(Sop(k, x), JM) for k in range(3))
chk('bit', oksu2 and okcas and okJ, 'S_k psi = (1/2) sigma_k psi sigma_3 on the kernel: [S_i, S_j] psi = eps_ijk S_k psi J (i = right J), S_k commute with right J, sum S_k^2 = 3/4: spin 1/2')

# ================================================================================================ 3. spacetime split
head('3. dlim·SPLIT: sigma_k = gamma_k gamma_0, the Pauli algebra, E and B [bit]; Pauli matrices and the field tensor [std]')
sgk = [A4.mul(e0, {1 << k: 1}) for k in (1, 2, 3)] if FAULT == 'SIGMAORDER' else [A4.mul({1 << k: 1}, e0) for k in (1, 2, 3)]
I4 = {15: Fr(1)}
EPS = {(0, 1, 2): 1, (1, 2, 0): 1, (2, 0, 1): 1, (0, 2, 1): -1, (2, 1, 0): -1, (1, 0, 2): -1}
def pauli_rel(sg, Iel):
    ok = True
    for i in range(3):
        for j in range(3):
            rhs = {0: Fr(1)} if i == j else {}
            for k in range(3):
                if (i, j, k) in EPS: rhs = A4.add(rhs, A4.scal(A4.mul(Iel, sg[k]), EPS[(i, j, k)]))
            ok &= A4.mul(sg[i], sg[j]) == rhs
    return ok
chk('bit', pauli_rel(sgk, I4) and A4.mul(A4.mul(sgk[0], sgk[1]), sgk[2]) == I4, 'sigma_i sigma_j = delta_ij + I eps_ijk sigma_k with I = sigma_1 sigma_2 sigma_3 = gamma_0 gamma_1 gamma_2 gamma_3 (exact, all nine pairs)')
C3 = BR((1, 1, 1))
def phi(x):
    out = {}
    for m, c in x.items():
        y = {0: Fr(1)}
        for i in range(3):
            if m >> i & 1: y = A4.mul(y, sgk[i])
        out = A4.add(out, A4.scal(y, c))
    return out
okiso = all(phi(C3.mul({a: 1}, {b: 1})) == A4.mul(phi({a: 1}), phi({b: 1})) for a in range(8) for b in range(8))
okspan = rank_mv([phi({a: 1}) for a in range(8)], 16) == 8 and all(pc(m) % 2 == 0 for a in range(8) for m in phi({a: 1}))
chk('bit', okiso and okspan, 'e_A -> sigma_A (products in increasing order) is an algebra map Cl(3,0) -> Cl(1,3) on all 64 products, onto the 8 even labels: the Pauli algebra is the even part')
def split(F):
    s = A4.mul(A4.mul(e0, F), e0); return A4.scal(A4.add(F, s, -1), Fr(1, 2)), A4.scal(A4.add(F, s), Fr(1, 2))
def EB_bit(F):
    E, IB = split(F); Bv = A4.mul(A4.scal(I4, -1), IB)
    Ek = [A4.mul(E, sgk[k]).get(0, 0) for k in range(3)]; Bk = [A4.mul(Bv, sgk[k]).get(0, 0) for k in range(3)]
    return E, IB, Ek, Bk
def EB_tensor(F):
    T = np.zeros((4, 4))
    for (a, b) in itertools.combinations(range(4), 2): T[a, b] = float(F.get((1 << a) | (1 << b), 0)); T[b, a] = -T[a, b]
    return [T[k, 0] for k in (1, 2, 3)], [-T[2, 3], T[1, 3], -T[1, 2]]
okE = okB = okpart = True; rs = random.Random(1322)
fields = [{m: Fr(1)} for m in BIV] + [{m: c for m in BIV for c in [Fr(rs.randint(-7, 7), rs.randint(1, 5))] if c} for _ in range(3)]
for F in fields:
    E, IB, Ek, Bk = EB_bit(F)
    okpart &= all(m in (3, 5, 9) for m in E) and all(m in (6, 10, 12) for m in IB) and A4.add(E, IB) == F
    Et, Bt = EB_tensor(F)
    okE &= max(abs(float(a) - b) for a, b in zip(Ek, Et)) < 1e-12; okB &= max(abs(float(a) - b) for a, b in zip(Bk, Bt)) < 1e-12
chk('bit', okpart, 'E = (F - gamma_0 F gamma_0)/2 lies on the sigma_k, I B = (F + gamma_0 F gamma_0)/2 on the I sigma_k, and E + I B = F: the six basis bivectors and three random rational F')
sx = np.array([[0, 1], [1, 0]], complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], complex); PM = [sx, sy, sz]
okp = all(np.allclose(PM[i] @ PM[j], (np.eye(2) if i == j else 0) + 1j * sum(EPS.get((i, j, k), 0) * PM[k] for k in range(3))) for i in range(3) for j in range(3))
prodsp = [np.eye(2, dtype=complex)] + PM + [PM[0] @ PM[1], PM[0] @ PM[2], PM[1] @ PM[2], PM[0] @ PM[1] @ PM[2]]
rk8 = int(np.linalg.matrix_rank(np.array([np.concatenate([M.real.ravel(), M.imag.ravel()]) for M in prodsp]), tol=1e-9))
chk('std', okp and rk8 == 8, 'Pauli matrices: sigma_i sigma_j = delta_ij + i eps_ijk sigma_k, and their products span a real algebra of dimension %d (= Cl(3,0))' % rk8)
chk('bit==std', okE and okB, 'E_k and B_k of the split equal E_k = F^{k0} and F^{ij} = -eps_ijk B_k of the 4 x 4 field tensor (numpy), ten fields')
sgw = [A4.mul(e0, {1 << k: 1}) for k in (1, 2, 3)]
Ew = [A4.mul(split(fields[-1])[0], sgw[k]).get(0, 0) for k in range(3)]
chk('ctl', not pauli_rel(sgw, I4) and pauli_rel(sgw, A4.scal(I4, -1)) and Ew == [-x for x in EB_bit(fields[-1])[2]],
    'sigma\'_k = gamma_0 gamma_k: the relation with i = gamma_0 gamma_1 gamma_2 gamma_3 fails (it holds with -I) and the components of E read along sigma\'_k flip sign')
sgs = [A4.mul({1 << k: 1}, e3) for k in (0, 1, 2)]
chk('ctl', [A4.mul(x, x).get(0, 0) for x in sgs] == [1, -1, -1], 'the split by the spacelike gamma_3: gamma_k gamma_3 (k = 0, 1, 2) square to +1, -1, -1: not Cl(3,0)')

# ================================================================================================ 4. the Pauli limit
head('4. dlim·PAULI: the 1/c expansion of the Dirac-Hestenes equation, g computed [bit]; Foldy-Wouthuysen leading term [std]')
ONE5 = {(0,) * 5: Fr(1)}; Z5 = (0,) * 5
def up(j): return {(0, 0, 0, 0, j): Fr(1)}
J5 = lift(JM, 5); G05 = lift(G0, 5)
def uD(psi, A, e, m):
    """u times the coupling script's D with c restored (d_0 = u d_t, A^0 = u phi, mass term m c) on psi_s exp(-J m c^2 t)"""
    dt = cs.fadd(cs.fder(psi, 0), cs.fpoly(cs.fmul(psi, J5, SQ4), up(-2)), -m)
    nab = cs.fmul({1: up(1)}, dt, SQ4)
    for k in (1, 2, 3): nab = cs.fadd(nab, cs.fmul({1 << k: dict(ONE5)}, cs.fder(psi, k), SQ4))
    Dv = cs.fadd(cs.fadd(cs.fmul(nab, J5, SQ4), cs.fmul(A, psi, SQ4), -e), cs.fpoly(cs.fmul(psi, G05, SQ4), up(-1)), -m)
    return cs.fpoly(Dv, up(1))
def uK(psi, A, e, m):
    """u^2 times the Klein-Gordon operator pi^mu pi_mu - m^2 c^2 on psi_s exp(-J m c^2 t), pi^mu psi = d^mu psi J - e A^mu psi (d^0 = u d_t)"""
    def pi0(x): return cs.fadd(cs.fmul(cs.fpoly(cs.fadd(cs.fder(x, 0), cs.fpoly(cs.fmul(x, J5, SQ4), up(-2)), -m), up(1)), J5, SQ4), cs.fmul({0: A.get(1, {})}, x, SQ4), -e)
    def pik(x, k): return cs.fadd(cs.fmul(cs.fder(x, k), J5, SQ4), cs.fmul({0: A.get(1 << k, {})}, x, SQ4), -e)
    K = pi0(pi0(psi))
    for k in (1, 2, 3): K = cs.fadd(K, pik(pik(psi, k), k), -1)
    K = cs.fadd(K, cs.fpoly(psi, up(-2)), -m * m)
    return cs.fpoly(K, up(2))
def order(F, j): return {b: q for b, p in F.items() for q in [{k[:4] + (0,): v for k, v in p.items() if k[4] == j}] if q}
def minorder(F): return min((k[4] for p in F.values() for k in p), default=0)
def at_u1(F):
    out = {}
    for b, p in F.items():
        q = {}
        for k, v in p.items(): q[k[:4]] = q.get(k[:4], 0) + v
        q = {k: v for k, v in q.items() if v != 0}
        if q: out[b] = q
    return out
def Pplus(X): return {b: p for b, p in cs.fadd(X, cs.fmul(cs.fmul(G05, X, SQ4), G05, SQ4)).items() if p for p in [cs.pscale(p, Fr(1, 2))] if p}
def rpoly_x(rng, deg, dens):
    mons = [(0, a, b, c, 0) for a in range(deg + 1) for b in range(deg + 1) for c in range(deg + 1) if a + b + c <= deg]
    return {k: Fr(rng.randint(-3, 3)) for k in mons if rng.random() < dens} or {(0, 0, 0, 0, 0): Fr(1)}
def pauli_run(sd, e, m, use_kg=False, dirac_e=None):
    rng = random.Random(4000 + sd)
    psi = {b: rpoly_x(rng, 2, .5) for b in (0, 6, 10, 12)}                  # even Pauli part: 1, g1 g2, g1 g3, g2 g3
    phi_ = rpoly_x(rng, 2, .5); Ak = {k: rpoly_x(rng, 2, .5) for k in (1, 2, 3)}
    A = {1: cs.pmul(phi_, up(1))}; A.update({1 << k: Ak[k] for k in (1, 2, 3)})
    de = e if dirac_e is None else dirac_e
    pik = lambda x, k: cs.fadd(cs.fmul(cs.fder(x, k), J5, SQ4), cs.fmul({0: Ak[k]}, x, SQ4), -e)
    pi2 = {}
    for k in (1, 2, 3): pi2 = cs.fadd(pi2, pik(pik(psi, k), k))
    F_ = cs.fgrade(cs.fadd(cs.fmul({1: up(1)}, cs.fder(A, 0), SQ4), cs.fadd(cs.fadd(cs.fmul({2: dict(ONE5)}, cs.fder(A, 1), SQ4), cs.fmul({4: dict(ONE5)}, cs.fder(A, 2), SQ4)), cs.fmul({8: dict(ONE5)}, cs.fder(A, 3), SQ4))), 2)
    IB = {b: q for b, p in cs.fadd(F_, cs.fmul(cs.fmul(G05, F_, SQ4), G05, SQ4)).items() for q in [cs.pscale(p, Fr(1, 2))] if q}
    Bv = cs.fmul(lift({15: Fr(-1)}, 5), IB, SQ4)
    Sterm = {b: cs.pscale(p, e / (2 * m)) for b, p in cs.fmul(cs.fmul(Bv, psi, SQ4), lift({9: Fr(-1)}, 5), SQ4).items()}
    info = {'B_rel': all(b in (3, 5, 9) for b in Bv), 'IB_spatial': all(b in (6, 10, 12) for b in IB), 'Bnz': bool(Bv)}
    if use_kg:
        K0 = uK(psi, A, e, m); info['minord'] = minorder(K0); info['ord0'] = order(K0, 0) == {}
        info['ord1'] = order(K0, 1) == {}
        ta = cs.fpoly(psi, {(1, 0, 0, 0, 0): Fr(1)}); dK = cs.fadd(uK(ta, A, e, m), cs.fpoly(K0, {(1, 0, 0, 0, 0): Fr(1)}), -1)
        info['dt'] = order(dK, 2) == {b: cs.pscale(p, 2 * m) for b, p in cs.fmul(psi, J5, SQ4).items()}
        H = {b: cs.pscale(p, Fr(-1) / (2 * m)) for b, p in order(K0, 2).items()}
    else:
        D0 = uD(psi, A, de, m); info['minord'] = minorder(D0); info['ord0'] = order(D0, 0) == {}
        R1 = order(D0, 1); chi = {b: cs.pscale(p, Fr(-1) / (2 * m)) for b, p in cs.fmul(G05, R1, SQ4).items()}
        info['chi_odd'] = all(b in (3, 5, 9, 15) for b in chi)
        D1 = uD(chi, A, de, m); info['ord1'] = cs.fadd(R1, order(D1, 0)) == {}
        ta = cs.fpoly(psi, {(1, 0, 0, 0, 0): Fr(1)}); dD = cs.fadd(uD(ta, A, de, m), cs.fpoly(D0, {(1, 0, 0, 0, 0): Fr(1)}), -1)
        info['dt'] = order(dD, 2) == cs.fmul(G05, cs.fmul(psi, J5, SQ4), SQ4) and all(order(dD, j) == {} for j in (0, 1))
        R2 = cs.fadd(order(D0, 2), order(D1, 1)); H = {b: cs.pscale(p, Fr(-1)) for b, p in Pplus(cs.fmul(G05, R2, SQ4)).items()}
    Rres = cs.fadd(cs.fadd(H, {b: cs.pscale(p, Fr(1) / (2 * m)) for b, p in pi2.items()}, -1), cs.fmul({0: phi_}, psi, SQ4), -e)
    lam = None; prop = False
    if not Rres: lam, prop = Fr(0), True
    else:
        b0 = next(iter(Sterm), None)
        if b0 is not None:
            k0 = next(iter(Sterm[b0])); lam = Rres.get(b0, {}).get(k0, Fr(0)) / Sterm[b0][k0]
            prop = cs.fadd(Rres, Sterm, -lam) == {}
    info['lam'] = lam; info['prop'] = prop
    return info
e_, m_ = Fr(3), Fr(2)
runs = [pauli_run(sd, e_, m_, use_kg=(FAULT == 'KG'), dirac_e=(-e_ if FAULT == 'ESIGN' else None)) for sd in range(3)]
chk('bit', all(r['minord'] >= 0 and r['ord0'] for r in runs), 'u D(psi_s) has no negative power of u, and its order u^0, m (gamma_0 psi - psi gamma_0), vanishes on the even Pauli part (three random fields, e = 3, m = 2)')
chk('bit', all(r.get('chi_odd', True) and r['ord1'] and r['dt'] for r in runs), 'order u^1 solved by chi = -(1/2m) gamma_0 R1 (odd Pauli part: sigma_k, I) and checked; the time derivative enters only as u^2 gamma_0 d_t psi J')
chk('bit', all(r['B_rel'] and r['IB_spatial'] and r['Bnz'] for r in runs), 'B from the split of F = nabla ^ A (item 3) is a relative vector, I B lies on the spatial bivectors')
gs_ = [(-2 * r['lam']) if r['lam'] is not None else None for r in runs]
chk('bit', all(r['prop'] for r in runs) and len(set(gs_)) == 1 and gs_[0] == 2,
    'H(psi) - (1/2m) pi^2 psi - e phi psi = lambda (e/2m) B psi sigma_3 with one lambda = %s on every component of the three fields: g = -2 lambda = %s' % (', '.join(str(r['lam']) for r in runs), ', '.join(str(g_) for g_ in gs_)))
psi_t = {b: rpoly_x(random.Random(77), 2, .5) for b in (0, 6, 10, 12)}; At = {1: cs.pmul(rpoly_x(random.Random(78), 1, .6), up(1)), 2: rpoly_x(random.Random(79), 1, .6)}
lhs = at_u1(cs.fpoly(uD(psi_t, At, e_, m_), up(-1)))
rhs = w_D({(-m_, Fr(0), Fr(0), Fr(0)): {b: {k[:4]: v for k, v in p.items()} for b, p in psi_t.items()}}, {b: {k[:4]: v for k, v in p.items()} for b, p in At.items()}, e_, m_)
chk('bit', rhs == {(-m_, Fr(0), Fr(0), Fr(0)): lhs}, 'at c = 1 the c-restored operator equals the coupling script\'s D on psi_s exp(-J m t) (the wave form of the same line)')
kg = [pauli_run(sd, e_, m_, use_kg=True) for sd in range(3)]
chk('ctl', all(r['prop'] and r['lam'] == 0 and r['ord0'] and r['ord1'] and r['dt'] for r in kg), 'a Klein-Gordon field, same series: H = (1/2m) pi^2 + e phi exactly, lambda = 0: no spin term (g = 0)')
es = [pauli_run(sd, e_, m_, dirac_e=-e_) for sd in range(3)]
chk('ctl', not any(r['prop'] for r in es), 'the sign of e flipped in the Dirac equation only: the residual is not a multiple of B psi sigma_3 on any of the three fields')
# std: explicit 4 x 4 matrices
def np_der(P, k):
    out = {}
    for mon, v in P.items():
        if mon[k]:
            mm = list(mon); mm[k] -= 1; mm = tuple(mm); out[mm] = out.get(mm, 0) + mon[k] * v
    return out
def np_mul(a, P):
    out = {}
    for m1, c in a.items():
        for m2, v in P.items():
            mm = tuple(x + y for x, y in zip(m1, m2)); out[mm] = out.get(mm, 0) + c * v
    return out
def np_add(P, Q_, c=1.0):
    out = dict(P)
    for k, v in Q_.items(): out[k] = out.get(k, 0) + c * v
    return out
def np_lin(M, P): return {k: M @ v for k, v in P.items()}
def np_max(P): return max((float(np.abs(v).max()) for v in P.values()), default=0.0)
I2 = np.eye(2); Z2 = np.zeros((2, 2))
ALPHA = [np.block([[Z2, s], [s, Z2]]) for s in PM]; BETA = np.diag([1.0, 1.0, -1.0, -1.0]).astype(complex)
rn = np.random.default_rng(1312); gstd = []; resid = []
for sd in range(3):
    mons = [(a, b, c) for a in range(3) for b in range(3) for c in range(3) if a + b + c <= 2]
    phi2 = {mo: rn.normal(size=2) + 1j * rn.normal(size=2) for mo in mons}
    Ak = [{mo: float(rn.integers(-3, 4)) for mo in mons} for _ in range(3)]
    ee, mm_ = 0.7, 1.3
    def pik4(P, k): return np_add({kk: -1j * v for kk, v in np_der(P, k).items()}, np_mul(Ak[k], P), -ee)
    Phi = {k: np.concatenate([v, np.zeros(2)]) for k, v in phi2.items()}
    O1 = {}
    for k in range(3): O1 = np_add(O1, np_lin(ALPHA[k], pik4(Phi, k)))
    O2 = {}
    for k in range(3): O2 = np_add(O2, np_lin(ALPHA[k], pik4(O1, k)))
    up_ = {k: (BETA @ v)[:2] / (2 * mm_) for k, v in O2.items()}
    p2 = {}
    for k in range(3): p2 = np_add(p2, pik4(pik4(phi2, k), k))
    Bk = [np_add(np_der(Ak[2], 1), np_der(Ak[1], 2), -1.0), np_add(np_der(Ak[0], 2), np_der(Ak[2], 0), -1.0), np_add(np_der(Ak[1], 0), np_der(Ak[0], 1), -1.0)]
    Sb = {}
    for k in range(3): Sb = np_add(Sb, np_lin(PM[k], np_mul(Bk[k], phi2)))
    Sb = {k: v * ee / (2 * mm_) for k, v in Sb.items()}
    Rr = np_add(up_, {k: v / (2 * mm_) for k, v in p2.items()}, -1.0)
    keys = sorted(set(Rr) | set(Sb)); rv = np.concatenate([Rr.get(k, np.zeros(2)) for k in keys]); sv = np.concatenate([Sb.get(k, np.zeros(2)) for k in keys])
    lam_s = np.vdot(sv, rv) / np.vdot(sv, sv); gstd.append(float((-2 * lam_s).real)); resid.append(float(np.abs(rv - lam_s * sv).max()))
chk('std', all(abs(g_ - 2) < 1e-9 for g_ in gstd) and max(resid) < 1e-9, 'Dirac matrices: the upper block of beta (alpha.pi)^2 / 2m minus pi^2/2m equals -(g/2)(e/2m) sigma.B with g = %s (three random complex 2-spinor fields of degree 2, A of degree 2; residual %.1e)' % (', '.join('%.12f' % g_ for g_ in gstd), max(resid)))
chk('bit==std', gs_[0] == 2 and all(abs(g_ - float(gs_[0])) < 1e-9 for g_ in gstd), 'g of the exact series = g of the matrix route = 2')

# ================================================================================================ 5. C, P, T
head('5. dlim·CPT: parity, time reversal, charge conjugation and CPT on D [bit]; Dirac matrices [std]')
MB = (1, -1, -1, -1); MT = (-1, 1, 1, 1); MA = (-1, -1, -1, -1)
def Pm(W, sandwich=True): return w_lmul(lift(G0), w_rmul(w_coord(W, MB), G0)) if sandwich else w_coord(W, MB)
def Tm(W, b): return w_lmul(lift(G0), w_rmul(w_coord(W, MT), b))
def Cm(W, c): return w_rmul(W, c)
def Acoord(A, M, sandwich=True):
    Ax = fcoord(A, M); return cs.fmul(cs.fmul(lift(G0), Ax, SQ4), lift(G0), SQ4) if sandwich else Ax
rf = random.Random(1345); samples = []
for sd in range(3):
    psi = {S_: cs.rpoly(rf, 4, 2, .35) for S_ in range(16) if pc(S_) % 2 == 0}; A = {1 << k: cs.rpoly(rf, 4, 1, .6) for k in range(4)}
    samples.append(({Z4: psi}, A))
ee, mm = Fr(3), Fr(5)
chk('bit', all(w_D(W, A, ee, mm) == {Z4: Dfield(W[Z4], A, ee, mm, 4)} for W, A in samples), 'the wave form of D equals the coupling script\'s D on the three random polynomial fields (psi of degree 2, A of degree 1, e = 3, m = 5)')
sandw = FAULT != 'NOSANDWICH'
okP = all(w_eq(w_D(Pm(W, sandw), Acoord(A, MB, sandw), ee, mm), Pm(w_D(W, A, ee, mm), sandw)) for W, A in samples)
chk('bit', okP, 'P: D(gamma_0 psi(x-bar) gamma_0; gamma_0 A(x-bar) gamma_0) = gamma_0 D(psi; A)(x-bar) gamma_0, three random fields')
chk('ctl', not any(w_eq(w_D(Pm(W, False), Acoord(A, MB, False), ee, mm), Pm(w_D(W, A, ee, mm), False)) for W, A in samples), 'P without the gamma_0 sandwich (psi(x-bar), A(x-bar)) does not carry D into the reflected D')
oddb = [m for m in range(16) if pc(m) % 2 == 1]; Tfound = []
for b in oddb:
    for s in (1, -1):
        if all(w_eq(w_D(Tm(W, {b: 1}), Acoord(A, MT), ee, mm), w_scale(Tm(w_D(W, A, ee, mm), {b: 1}), s)) for W, A in samples[:1]): Tfound.append((b, s))
Tfull = [(b, s) for b, s in Tfound if all(w_eq(w_D(Tm(W, {b: 1}), Acoord(A, MT), ee, mm), w_scale(Tm(w_D(W, A, ee, mm), {b: 1}), s)) for W, A in samples)]
bT = {1: Fr(1)} if FAULT == 'TNOK' else {13: Fr(1)}
okT = all(w_eq(w_D(Tm(W, bT), Acoord(A, MT), ee, mm), Tm(w_D(W, A, ee, mm), bT)) for W, A in samples)
chk('bit', okT and sorted(Tfull) == [(11, 1), (13, 1)], 'T: psi -> gamma_0 psi(-t, x) b, A -> gamma_0 A(-t, x) gamma_0: of the eight odd blades exactly b = g0 g1 g3 and g0 g2 g3 work (search: %s), D(T psi) = gamma_0 D(psi)(-t, x) b' % Tfull)
evq = {S_: Fr(random.Random(1350).randint(-5, 5)) for S_ in range(16) if pc(S_) % 2 == 0}
chk('bit', A4.mul(A4.mul(e0, evq), {13: 1}) == A4.mul(A4.mul(A4.mul(I4, e0), evq), e1), 'gamma_0 psi gamma_0 gamma_2 gamma_3 = I gamma_0 psi gamma_1 for even psi (the form recalled from Doran and Lasenby)')
chk('ctl', not any(w_eq(w_D(Tm(W, G0), Acoord(A, MT), ee, mm), w_scale(Tm(w_D(W, A, ee, mm), G0), s)) for W, A in samples[:1] for s in (1, -1)) and (7, 1) not in Tfound and (7, -1) not in Tfound,
    'T with the right factor gamma_0 (no flip of J), or with g0 g1 g2 (commutes with J): not a map of solutions')
evb = [m for m in range(1, 16) if pc(m) % 2 == 0]; Cfound = []
for c in evb:
    for s in (1, -1):
        if all(w_eq(w_D(Cm(W, {c: 1}), A, -ee, mm), w_scale(Cm(w_D(W, A, ee, mm), {c: 1}), s)) for W, A in samples): Cfound.append((c, s))
eC = ee if FAULT == 'CNOE' else -ee; sig1 = {3: Fr(-1)}
okC = all(w_eq(w_D(Cm(W, sig1), A, eC, mm), w_scale(Cm(w_D(W, A, ee, mm), sig1), -1)) for W, A in samples)
chk('bit', okC and sorted(Cfound) == [(3, -1), (5, -1)], 'C: psi -> psi sigma_1 with e -> -e gives D(psi sigma_1; -e) = -D(psi; e) sigma_1; of the even blades exactly g0 g1 and g0 g2 (sigma_1, sigma_2) work (search: %s)' % Cfound)
chk('ctl', not any(w_eq(w_D(Cm(W, sig1), A, ee, mm), w_scale(Cm(w_D(W, A, ee, mm), sig1), s)) for W, A in samples[:1] for s in (1, -1)), 'C without e -> -e: not a map of solutions')
def CPT(W): return Cm(Pm(Tm(W, {13: Fr(1)})), sig1)
okform = []; okCPT = True
for W, A in samples:
    lhs = CPT(W); rhs = w_lmul(lift(I4), w_coord(W, MA))
    okform.append(1 if w_eq(lhs, rhs) else (-1 if w_eq(lhs, w_scale(rhs, -1)) else 0))
    okCPT &= w_eq(w_D(lhs, fcoord(A, MA), -ee, mm), w_scale(CPT(w_D(W, A, ee, mm)), -1))
chk('bit', len(set(okform)) == 1 and okform[0] != 0 and okCPT, 'CPT = C P T: psi(x) -> %+d I psi(-x); D(CPT psi; A(-x), -e) = -CPT(D(psi; A, e)): solutions with (e, A(x)) go to solutions with (-e, A(-x))' % okform[0])
def shell_kernel(k, Ac, e, m):
    ks = {1 << mu: Fr(k[mu]) for mu in range(4) if k[mu]}; L = A4.add(ks, Ac, -e); rows = []
    for T in odd: rows.append([A4.add(A4.mul(L, {S_: 1}), A4.scal(A4.mul({S_: 1}, e0), -m)).get(T, 0) for S_ in evn])
    return [{S_: v[i] for i, S_ in enumerate(evn) if v[i] != 0} for v in nullspace(rows, 8)]
okpw = True; npw = 0; kers = {}
for k, Ac, e in (((5, 4, 0, 0), {}, Fr(1)), ((5, 0, 4, 0), {}, Fr(1)), ((7, 4, 0, 0), {1: Fr(2)}, Fr(1))):
    ker = shell_kernel(k, Ac, e, Fr(3)); kers[k] = ker; Acf = lift(Ac); okpw &= len(ker) == 4
    for x in ker:
        W = {tuple(Fr(-v) for v in k): lift(x)}
        okpw &= w_D(W, Acf, e, Fr(3)) == {}
        okpw &= w_D(Pm(W), Acoord(Acf, MB), e, Fr(3)) == {} and w_D(Tm(W, {13: 1}), Acoord(Acf, MT), e, Fr(3)) == {} and w_D(Tm(W, {11: 1}), Acoord(Acf, MT), e, Fr(3)) == {}
        okpw &= w_D(Cm(W, sig1), Acf, -e, Fr(3)) == {} and w_D(Cm(W, {5: 1}), Acf, -e, Fr(3)) == {} and w_D(CPT(W), fcoord(Acf, MA), -e, Fr(3)) == {}
        npw += 1
chk('bit', okpw, 'plane waves psi_0 exp(-J k.x) on the shell (m = 3; k = (5,4,0,0) and (5,0,4,0), A = 0; k = (7,4,0,0), A = 2 gamma_0, e = 1): kernels of dimension 4, and the images of the %d solutions under P, T (both b), C (both c), CPT solve the transformed equations exactly' % npw)
chk('ctl', w_D({(Fr(-5), Fr(-4), Fr(0), Fr(0)): lift({0: 1})}, {}, Fr(1), Fr(3)) != {}, 'a plane wave with an amplitude outside the kernel (psi_0 = 1 at k = (5,4,0,0)) is not a solution')
# std: Dirac matrices
gD = [np.block([[I2, Z2], [Z2, -I2]]).astype(complex)] + [np.block([[Z2, s], [-s, Z2]]) for s in PM]     # gamma^mu, Dirac representation
GL = [gD[0]] + [-gD[k] for k in (1, 2, 3)]                                                                # gamma_mu = eta_mu nu gamma^nu: the matrices of the blades gamma_mu
def slash(pl): return sum(gD[mu] * pl[mu] for mu in range(4))                                             # gamma^mu p_mu (p_mu lower)
def lower(pu): return np.array([pu[0], -pu[1], -pu[2], -pu[3]], complex)
def null_np(M):
    U_, s_, Vt = np.linalg.svd(M); return [v.conj() for v in Vt[int((s_ > 1e-9).sum()):]]
okstd = True; okctl_std = True; tnok = {}
for k, Ac, e in (((5, 4, 0, 0), np.zeros(4), 1.0), ((5, 0, 4, 0), np.zeros(4), 1.0), ((7, 4, 0, 0), np.array([2.0, 0, 0, 0]), 1.0)):
    pu = np.array(k, float); Au = Ac.astype(complex); m3 = 3.0
    Mop = lambda pu_, Au_, e_: slash(lower(pu_)) - e_ * slash(lower(Au_)) - m3 * np.eye(4)
    us = null_np(Mop(pu, Au, e)); okstd &= len(us) == 2
    for u0 in us:
        Pu, PA = gD[0] @ u0, Au * np.array([1, -1, -1, -1])
        okstd &= np.abs(Mop(pu * np.array([1, -1, -1, -1]), PA, e) @ Pu).max() < 1e-9
        Cu = 1j * gD[2] @ u0.conj(); okstd &= np.abs(Mop(-pu, Au, -e) @ Cu).max() < 1e-9
        Tu = 1j * gD[1] @ gD[3] @ u0.conj(); okstd &= np.abs(Mop(pu * np.array([1, -1, -1, -1]), Au * np.array([1, -1, -1, -1]), e) @ Tu).max() < 1e-9
        okctl_std &= np.abs(Mop(-pu, Au, e) @ Cu).max() > 1e-6 or not Au.any()
        tnok[k] = max(tnok.get(k, 0.0), float(np.abs(Mop(pu * np.array([1, -1, -1, -1]), Au * np.array([1, -1, -1, -1]), e) @ (1j * gD[1] @ gD[3] @ u0)).max()))
chk('std', okstd, 'Dirac matrices (gamma^0 = diag(1,1,-1,-1)): on the plane-wave solutions of (p-slash - e A-slash - m) u = 0 at the three momenta, P = gamma^0 (p -> (E, -p), A -> (A^0, -A)), C = i gamma^2 K (p -> -p, e -> -e), T = i gamma^1 gamma^3 K (p -> (E, -p), A -> (A^0, -A)) give solutions (residual < 1e-9)')
chk('ctl', okctl_std and tnok[(5, 0, 4, 0)] > 1e-6, 'T without K (i gamma^1 gamma^3 u, linear) fails for the momentum along y (residual %.2f; for p in the x-z plane it does not, %.0e: gamma^1 gamma^3 alone flips p_x and p_z); C without e -> -e fails with A != 0' % (tnok[(5, 0, 4, 0)], tnok[(5, 4, 0, 0)]))
def matD(x): return sum(complex(c) * np.linalg.multi_dot([GL[i] for i in range(4) if m >> i & 1] + [np.eye(4)]) if m else complex(c) * np.eye(4) for m, c in x.items())
u0 = np.array([1, 0, 0, 0], complex)
okmap = np.allclose(GL[0] @ u0, u0) and np.allclose(matD(JM) @ u0, 1j * u0)
for x in kers[(5, 4, 0, 0)]:
    Psi = matD(x) @ u0; okmap &= np.abs(Mop(np.array([5.0, 4, 0, 0]), np.zeros(4), 1.0) @ Psi).max() < 1e-9
phases = {'P': [], 'C': [], 'T': []}
for sd in range(3):
    r8 = random.Random(1360 + sd); x = {S_: Fr(r8.randint(-5, 5)) for S_ in evn}; Psi = matD(x) @ u0
    for name, lhs_, rhs_ in (('P', matD(A4.mul(A4.mul(e0, x), e0)) @ u0, gD[0] @ Psi), ('C', matD(A4.mul(x, sig1)) @ u0, 1j * gD[2] @ Psi.conj()),
                             ('T', matD(A4.mul(A4.mul(e0, x), {13: 1})) @ u0, 1j * gD[1] @ gD[3] @ Psi.conj())):
        c_ = np.vdot(rhs_, lhs_) / np.vdot(rhs_, rhs_); phases[name].append((c_, float(np.abs(lhs_ - c_ * rhs_).max())))
okph = okmap and all(abs(abs(c_) - 1) < 1e-9 and r_ < 1e-9 for v in phases.values() for c_, r_ in v) and all(abs(v[0][0] - w[0]) < 1e-9 for v in phases.values() for w in v)
chk('bit==std', okph, 'Psi = mat(psi) u (gamma_mu -> the lower-index Dirac matrices, gamma_0 u = u, J u = i u) turns the bit solutions into matrix solutions and the bit P, C, T into gamma^0, i gamma^2 K, i gamma^1 gamma^3 K with the constant phases %s'
    % ', '.join('%s: %s' % (k_, complex(np.round(v[0][0], 9))) for k_, v in phases.items()))

finish('DIRAC')
