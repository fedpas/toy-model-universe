#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chiral_spinors.py: two of Atiyah's remarks on spinors in their finite form on the labels: the sign of chirality in the one case where
the cubic trace does not vanish, and "Spinors x Spinors = Forms" as a rank.      python3 chiral_spinors.py [--fault NAME]

C. Chirality (chi.C1 .. C3).  In Cl(n,n) the bivectors e_a e_b span so(n,n) and the minimal left ideal (dimension 2^n) splits under the
   central volume element omega (omega^2 = +1, commuting with the even part) into two half-spinors of dimension 2^(n-1).  The symmetric cubic
   trace c_S(X) = tr_S(X^3) on each half-spinor: for n = 3 (so(3,3) = sl(4,R), the half-spinors its 4 and 4-bar) it is not zero and the two
   are opposite, c_+ = -c_- on all 15 bivectors and on 20 random combinations (exact rationals); for n = 2, 4, 5 both vanish (CAND-003: the
   anomaly-free cases).  The reason, computed: for n = 3 an invariant pairing S_+ x S_- -> R exists (a matrix C with X_-^T C + C X_+ = 0 for
   all 15 bivectors, unique up to scale), so S_- is the dual of S_+ and tr(X_-^3) = tr((-X_+^T)^3) = -tr(X_+^3): the sign of chirality is the
   sign of the index (Atiyah: "the index is sensitive to orientation (often just changing sign)").
   [bit]  the ideal of the bit rule (steps15_17/bitcliff.py), bivectors as signed permutation matrices, exact Fractions.
   [std]  numpy Kronecker words (no label) for Cl(3,3) on R^8, the same split and traces; sl(4,R): tr(X^3) on the 4 against the 4-bar (-X^T).
   [ctl]  SAME_SIGN (c_+ = c_- asserted at n = 3), NONZERO4 (a non-zero cubic trace asserted at n = 4).
S. Spinors x Spinors = Forms (chi.S1 .. S2).  For every cell Cl(p,q) with p + q <= 5 (21 cells), S = Cl f the minimal left ideal (the spinors)
   and f Cl the right ideal (their dual under the trace pairing): the span of the products psi chi (psi in Cl f, chi in f Cl) is the
   two-sided ideal Cl f Cl, of dimension 2^n on the simple cells and 2^(n-1) on the cells with two summands (clock 1 and 5), and every grade
   0..n occurs: Atiyah's "Spinors x Spinors = Forms ... all degrees simultaneously".  Identifying the dual with S itself by the reversion
   (psi phi~) or by the Clifford conjugation gives the same span exactly when f f~ (resp. f f-bar) is not 0 and the zero span otherwise:
   the table of ranks by cell is printed.  Without the dual, psi phi stays in the left ideal (rank at most dim S).
   [bit]  products of ideal elements by the bit rule, exact ranks.   [std]  numpy: in the regular representation, the rank of the span of
   the matrices psi phi^T over the ideal is m^2 for a simple cell (End of the ideal over R), and Cl = End_D(S) has dimension m^2 / dim D.
   [ctl]  the products psi phi (no dual) span only the left ideal (rank 2 < 4) on Cl(2,0) (NOINVOL).
Scope: n = 2, 3, 4, 5 (C; so(5,5) on 32-dimensional ideals); the 21 cells p + q <= 5 (S).  Standard library and numpy.
Command: python3 chiral_spinors.py   (from this folder, or python3 selfcheck/proofs/chiral_spinors.py from the root of the checks)."""
import os, sys, io, random, itertools, contextlib, time
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p); sys.path.insert(0, _here)
from bitcliff import Alg, sig, pc
_argv = sys.argv; sys.argv = [_argv[0]]
try:
    with contextlib.redirect_stdout(io.StringIO()):
        from solid_cube import commutant_basis, classify
finally:
    sys.argv = _argv

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('SAME_SIGN', 'NONZERO4', 'NOINVOL')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

# ------------------------------------------------------------------------------------------------ exact linear algebra
def rank_frac(rows):
    rows = [[Fr(x) for x in r] for r in rows]; rk = 0; ncol = len(rows[0]) if rows else 0
    for c in range(ncol):
        piv = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if piv is None: continue
        rows[rk], rows[piv] = rows[piv], rows[rk]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c] / rows[rk][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        rk += 1
    return rk
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis

# ------------------------------------------------------------------------------------------------ the ideal of the bit rule
def comm_set(alg, norders=12):
    best = []; rg = random.Random(7 + 31 * alg.n + sum(1 for e in alg.eps if e > 0))
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(norders):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s ^ a for s in span}
                if all(alg.sq(x) == 1 for x in new): gens.append(a); span |= new
        if len(gens) > len(best): best = gens
    return best
def build_ideal(p, q):
    """the minimal left ideal Cl f, f = prod (1 + e_a)/2: the coset representatives, the action of every blade as a signed permutation, f itself"""
    alg = Alg(sig(p, q)); n = alg.n; N = alg.N
    gens = comm_set(alg) if n else []; k = len(gens); span = {0}
    for a in gens: span |= {s ^ a for s in span}
    tau = {}
    for J in range(1 << k):
        prod = {0: 1}
        for j in range(k):
            if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
        (mm, cf), = prod.items(); tau[mm] = cf
    coset = {}; reps = []
    for a in range(N):
        if a not in coset:
            reps.append(a)
            for mm in span: coset[a ^ mm] = (a, mm)
    m = len(reps); idx = {r: i for i, r in enumerate(reps)}
    def act(blade):
        R = np.zeros((m, m), dtype=np.int64)
        for r in reps:
            s, c = alg.blade_mul(blade, r); r2, mm = coset[c]; s2, _ = alg.blade_mul(r2, mm)
            R[idx[r2], idx[r]] = s * s2 * tau[mm]
        return R
    f = {0: Fr(1)}
    for a in gens: f = alg.mul(f, {0: Fr(1, 2), a: Fr(1, 2)})
    return {'alg': alg, 'n': n, 'N': N, 'm': m, 'reps': reps, 'act': act, 'f': f, 'span': span, 'gens': gens}

# ================================================================================================ C. chirality
head('C. the cubic trace on the two half-spinors of so(n,n), n = 2..5')
def cubic_data(n):
    I_ = build_ideal(n, n); alg = I_['alg']; m = I_['m']
    biv = [(a, b) for a in range(2 * n) for b in range(a + 1, 2 * n)]
    X = [I_['act']((1 << a) | (1 << b)) for a, b in biv]                   # e_a e_b on the ideal (the bivector up to the factor 1/2)
    om = I_['act']((1 << (2 * n)) - 1)
    assert np.array_equal(om @ om, np.eye(m, dtype=np.int64)) and all(np.array_equal(om @ x, x @ om) for x in X)
    P = [np.eye(m, dtype=np.int64) + s * om for s in (1, -1)]             # twice the projectors on the half-spinors (their column spaces)
    # bases of the two halves: the columns of P_s span them (rank m/2 each); restricted matrices through a basis of the column space
    halves = []
    for Ps in P:
        cols = Ps.T.tolist(); basis = []; piv = []
        for v in cols:
            if rank_frac(basis + [v]) > len(basis): basis.append(v)
        B = np.array(basis, dtype=np.int64).T                                 # m x (m/2)
        # the action restricted: X B = B X' ; X' = (B^T B)^-1 B^T X B, exact
        BtB = [[Fr(int(x)) for x in row] for row in (B.T @ B)]
        inv = inv_frac(BtB)
        Xr = []
        for x in X:
            M = [[Fr(int(v)) for v in row] for row in (B.T @ x @ B)]
            Xr.append([[sum(inv[i][k] * M[k][j] for k in range(len(inv))) for j in range(len(M))] for i in range(len(inv))])
        halves.append((B, Xr))
    return I_, X, om, halves
def inv_frac(M):
    m = len(M); A = [[Fr(x) for x in row] + [Fr(int(i == j)) for j in range(m)] for i, row in enumerate(M)]
    for c in range(m):
        piv = next(i for i in range(c, m) if A[i][c] != 0); A[c], A[piv] = A[piv], A[c]
        pv = A[c][c]; A[c] = [x / pv for x in A[c]]
        for i in range(m):
            if i != c and A[i][c]: f = A[i][c]; A[i] = [x - f * y for x, y in zip(A[i], A[c])]
    return [row[m:] for row in A]
def mat_mul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def mat_add(A, B, c=1): return [[a + c * b for a, b in zip(ra, rb)] for ra, rb in zip(A, B)]
def tr(A): return sum(A[i][i] for i in range(len(A)))
def cubic_form(Xr, coeffs):
    Y = [[Fr(0)] * len(Xr[0]) for _ in Xr[0]]
    for c, x in zip(coeffs, Xr): Y = mat_add(Y, x, c)
    return tr(mat_mul(Y, mat_mul(Y, Y)))
rng = random.Random(33)
CUB = {}
for n in (2, 3, 4, 5):
    I_, X, om, halves = cubic_data(n); nb = len(X)
    combos = [[Fr(int(i == j)) for j in range(nb)] for i in range(nb)] + [[Fr(rng.randint(-2, 2)) for _ in range(nb)] for _ in range(20)]
    cp = [cubic_form(halves[0][1], c) for c in combos]; cm = [cubic_form(halves[1][1], c) for c in combos]
    CUB[n] = (cp, cm, I_['m'])
    print('  n = %d: ideal of dimension %d, half-spinors of dimension %d, %d bivectors; cubic traces on S+ (6 random combinations): %s; on S-: %s' % (n, I_['m'], I_['m'] // 2, nb, [str(v) for v in cp[nb:nb + 6]], [str(v) for v in cm[nb:nb + 6]]), flush=True)
cp3, cm3, _ = CUB[3]
want_rel = (lambda a, b: a == b) if FAULT == 'SAME_SIGN' else (lambda a, b: a == -b)
chk('bit', any(v != 0 for v in cp3) and all(want_rel(a, b) for a, b in zip(cp3, cm3)), 'chi.C1: n = 3: the cubic trace is not zero on the half-spinors (dimension 4 each) and c_+ = %sc_- on the 15 bivectors and 20 random combinations (exact)' % ('' if FAULT == 'SAME_SIGN' else '-'))
vanish = {n: all(v == 0 for v in CUB[n][0] + CUB[n][1]) for n in (2, 4, 5)}
chk('bit', all(vanish.values()) if FAULT != 'NONZERO4' else not vanish[4], 'chi.C2: n = 2, 4, 5: the cubic trace vanishes on both half-spinors (dimensions 2, 8, 16): %s (CAND-003)' % vanish)
# the pairing S_+ x S_- -> R: C with X_-^T C + C X_+ = 0 for all bivectors
I3, X3, om3, halves3 = cubic_data(3); Xp = halves3[0][1]; Xm = halves3[1][1]; d = len(Xp[0])
rows = []
for xp, xm in zip(Xp, Xm):
    # (X_-^T C + C X_+)[i][j] = sum_k X_-[k][i] C[k][j] + C[i][k] X_+[k][j]; unknowns C[k][l] at index k*d + l
    for i in range(d):
        for j in range(d):
            row = [Fr(0)] * (d * d)
            for k in range(d): row[k * d + j] += xm[k][i]; row[i * d + k] += xp[k][j]
            rows.append(row)
NS = nullspace_frac(rows, d * d)
chk('bit', len(NS) == 1 and rank_frac([[NS[0][k * d + l] for l in range(d)] for k in range(d)]) == d, 'chi.C3: n = 3: the invariant pairings S_+ x S_- -> R form a space of dimension %d, spanned by an invertible C: S_- is the dual of S_+, so tr(X_-^3) = tr((-X_+^T)^3) = -tr(X_+^3), the sign of chirality' % len(NS))
# std: numpy Kronecker words for Cl(3,3), and sl(4)
_X = np.array([[0., 1.], [1., 0.]]); _Z = np.diag([1., -1.]); _E = np.array([[0., 1.], [-1., 0.]]); _I = np.eye(2)
def kron_gammas(eps):
    G = []
    for k in range(len(eps)):
        A = _X if eps[k] > 0 else _E; M = np.array([[1.]])
        for B in [_Z] * k + [A] + [_I] * (len(eps) - k - 1): M = np.kron(M, B)
        G.append(M)
    return G
G6 = kron_gammas([1, 1, 1, -1, -1, -1]); dim = 64
rng_np = np.random.default_rng(7)
prods = [np.eye(dim)]
for a in range(1, dim):
    i = (a & -a).bit_length() - 1; prods.append(G6[i] @ prods[a ^ (1 << i)])
Xs = rng_np.standard_normal((dim, dim)); Xs = Xs + Xs.T; Y = sum(Pm @ Xs @ Pm.T for Pm in prods) / dim
w, V = np.linalg.eigh(Y); groups = []; start = 0
for i in range(1, dim + 1):
    if i == dim or w[i] - w[i - 1] > 1e-7 * max(1.0, abs(w).max()): groups.append(V[:, start:i]); start = i
S8 = groups[0]; assert S8.shape[1] == 8
Gr = [S8.T @ g @ S8 for g in G6]; om_s = np.eye(8)
for g in Gr: om_s = om_s @ g
assert np.allclose(om_s @ om_s, np.eye(8))
wv, Vv = np.linalg.eigh(om_s); Vp = Vv[:, wv > 0]; Vm = Vv[:, wv < 0]
bivs = [Gr[a] @ Gr[b] for a in range(6) for b in range(a + 1, 6)]
cub = lambda Vh, X: np.trace(np.linalg.matrix_power(Vh.T @ X @ Vh, 3))
cs = [(cub(Vp, X), cub(Vm, X)) for X in bivs] + [(cub(Vp, Y_), cub(Vm, Y_)) for Y_ in [sum(rng_np.integers(-2, 3) * B for B in bivs) for _ in range(20)]]
chk('std', any(abs(a) > 1e-9 for a, b in cs) and all(abs(a + b) < 1e-9 for a, b in cs), 'chi.C1: numpy, no label: Cl(3,3) on R^8 by Kronecker words, the half-spinors as the eigenspaces of the volume element, cubic traces opposite on the 15 bivectors and 20 combinations (max |c_+ + c_-| = %.1e)' % max(abs(a + b) for a, b in cs))
A4 = rng_np.standard_normal((4, 4)); A4 -= np.trace(A4) / 4 * np.eye(4)
chk('std', abs(np.trace(np.linalg.matrix_power(A4, 3)) + np.trace(np.linalg.matrix_power(-A4.T, 3))) < 1e-9 and abs(np.trace(np.linalg.matrix_power(A4, 3))) > 1e-9, 'chi.C3: sl(4,R): on the 4-bar (X -> -X^T) the cubic trace is minus that on the 4 (a random traceless X)')
chk('ctl', not all(a == b for a, b in zip(cp3, cm3)), 'chi.C1: c_+ = c_- fails at n = 3 (SAME_SIGN)')

# ================================================================================================ S. spinors x spinors = forms
head('S. the span of psi phi~ over the minimal left ideal, every cell p + q <= 5')
def invol_sign(alg, a, kind):
    k = pc(a)
    if kind == 'rev': return (-1) ** (k * (k - 1) // 2)
    if kind == 'conj': return (-1) ** (k * (k + 1) // 2)
    return 1
def ideal_basis(I_):
    """the elements e_r f of the ideal as multivectors (dicts), r over the coset representatives"""
    alg = I_['alg']; out = []
    for r in I_['reps']: out.append(alg.mul({r: Fr(1)}, I_['f']))
    return out
def span_rank(alg, vecs):
    rows = [[v.get(a, Fr(0)) for a in range(alg.N)] for v in vecs]; return rank_frac(rows)
def grades_of(alg, vecs):
    g = set()
    for v in vecs:
        for a, c in v.items():
            if c: g.add(pc(a))
    return sorted(g)
table = {}; TWO = {1, 5}                                                   # clocks with two simple summands
for n in range(0, 6):
    for p in range(0, n + 1):
        q = n - p; I_ = build_ideal(p, q); alg = I_['alg']; S = ideal_basis(I_); f = I_['f']
        R = [alg.mul(f, {r: Fr(1)}) for r in I_['reps']]                      # the right ideal f Cl: the dual of S under the trace pairing
        two_sided = [alg.mul(x, y) for x in S for y in R]
        res = {'dual': (span_rank(alg, two_sided), grades_of(alg, two_sided))}
        for kind in ('rev', 'conj', 'none'):
            Sd = [{a: c * invol_sign(alg, a, kind) for a, c in v.items()} for v in S]
            prods_ = [alg.mul(x, y) for x in S for y in Sd]
            res[kind] = (span_rank(alg, prods_), grades_of(alg, prods_))
        ft = {a: c * invol_sign(alg, a, 'rev') for a, c in f.items()}; fc = {a: c * invol_sign(alg, a, 'conj') for a, c in f.items()}
        res['ff~'] = (bool(alg.mul(f, ft)), bool(alg.mul(f, fc)))
        table[(p, q)] = (I_['m'], res, (p - q) % 8 in TWO)
line = lambda kind: {k: v[1][kind][0] for k, v in sorted(table.items())}
want = lambda k, v: (1 << sum(k)) // (2 if v[2] else 1)
dual_ok = all(v[1]['dual'][0] == want(k, v) and v[1]['dual'][1] == list(range(sum(k) + 1)) for k, v in table.items())
chk('bit', dual_ok, 'chi.S1: the span of psi chi, psi in the left ideal Cl f (the spinors) and chi in the right ideal f Cl (their dual under the trace), is the two-sided ideal Cl f Cl: dimension 2^n on the simple cells and 2^(n-1) on the cells with two summands (clock 1 and 5), every grade 0..n occurring, on all 21 cells p + q <= 5: Spinors x Spinors = Forms, all degrees at once')
inv_ok = all((v[1]['rev'][0] == (want(k, v) if v[1]['ff~'][0] else 0)) and (v[1]['conj'][0] == (want(k, v) if v[1]['ff~'][1] else 0)) for k, v in table.items())
zero_rev = [k for k, v in sorted(table.items()) if v[1]['rev'][0] == 0]; zero_conj = [k for k, v in sorted(table.items()) if v[1]['conj'][0] == 0]
chk('bit', inv_ok, 'chi.S1: identifying the dual with S by the reversion (psi phi~) or the Clifford conjugation gives the same span exactly when f f~ != 0 (resp. f f-bar != 0) and 0 otherwise, for the idempotent f built here: 0 with the reversion on %s, with the conjugation on %s' % (zero_rev, zero_conj))
print('  ranks (dual, f Cl): %s' % line('dual'), flush=True)
print('  ranks (reversion): %s' % line('rev'), flush=True)
print('  ranks (conjugation): %s' % line('conj'), flush=True)
print('  ranks (no involution, psi phi): %s' % line('none'), flush=True)
div = [k for k, v in sorted(table.items()) if v[0] == 1 << sum(k)]
chk('bit', all(v[1]['none'][0] <= v[0] for k, v in table.items()) and all(v[1]['none'][0] < 1 << sum(k) for k, v in table.items() if v[0] < 1 << sum(k)),
    'chi.S1: without the dual the products psi phi stay in the left ideal: rank at most dim S = m on every cell, below 2^n except on the division-algebra cells %s where the ideal is the cell' % div)
# std: numpy in the regular representation: the ideal as column space of f, products psi phi^T span the matrices of End(S); Cl = End_D(S)
std_ok = True; std_tab = {}
for n in range(0, 5):
    for p in range(0, n + 1):
        q = n - p; eps = [1] * p + [-1] * q; G = kron_gammas(eps) if n else []; dimr = 2 ** n
        prods_r = [np.eye(dimr)]
        for a in range(1, dimr):
            i = (a & -a).bit_length() - 1; prods_r.append(G[i] @ prods_r[a ^ (1 << i)])
        I_ = build_ideal(p, q); alg = I_['alg']
        fm = sum(float(c) * prods_r[a] for a, c in I_['f'].items())
        U, s_, Vt = np.linalg.svd(fm); r = int(np.sum(s_ > 1e-9)); Bs = U[:, :r]            # a basis of the image of f (the ideal as a space of column vectors)
        # psi phi^T over the basis: rank r^2 = (dim S)^2; the Clifford algebra inside End(S) has dimension 2^n = r^2 / dim D
        mats = [np.outer(Bs[:, i], Bs[:, j]).ravel() for i in range(r) for j in range(r)]
        rk = np.linalg.matrix_rank(np.array(mats)) if mats else 1
        std_tab[(p, q)] = (r, rk); std_ok &= rk == r * r and r == I_['m']
chk('std', std_ok, 'chi.S2: numpy, no label: the ideal as the column space of f in the regular representation (dimension m = %s on the 15 cells p + q <= 4), and the matrices psi phi^T span End(S), rank m^2; the cell itself is End_D(S), of dimension 2^n = m^2 / dim D' % [std_tab[k][0] for k in sorted(std_tab)])
chk('ctl', table[(2, 0)][1]['none'][0] < 4, 'chi.S1: on Cl(2,0) the products psi phi without an involution have rank %d < 4 (NOINVOL)' % table[(2, 0)][1]['none'][0])
if FAULT == 'NOINVOL': chk('ctl', table[(2, 0)][1]['none'][0] == 4, 'chi.S1: rank 4 asserted without an involution (NOINVOL)')
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('CHIRAL-SPINORS')
