#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chain_frames.py: the computable cores of four readings on the step pages: the table of plane pairs read as demicube edges and as the
tetrahedra of the axis simplex (first Bianchi identity), time reversal as one mirror, and the extra generators of the projective and forque
steps as further bits of the same rule.
     python3 chain_frames.py [--fault DROP3|EDGES|NOMINUS|EXTRA|NOREORDER|PAIRPP]

chn.5 (GRV-001b).  n = 4..8.  The planes are the labels of weight 2.  Two distinct planes share one axis (labels at distance 2: an edge of the
   n-demicube) or none (distance 4; at n = 4 the antipodes of the octahedron of weight-2 corners): n(n-1)(n-2)/2 and 3 C(n,4) pairs, 12 and
   3 at n = 4.  The grade-4 part of e_A e_B is nonzero exactly for disjoint planes, and then it is +- e_(A or B).  The first Bianchi map
   b : Sym^2(Lambda^2) -> Lambda^4 sends the symmetric basis element of a plane pair to 0 unless the planes are disjoint; so b has one
   component per set of four axes (a tetrahedron of the axis simplex, C(n,4) of them), fed by exactly its 3 disjoint pairs (the three pairs
   of opposite edges of the tetrahedron) with signs (+, -, +), and b is onto Lambda^4: rank C(n,4), kernel n^2(n^2-1)/12.
   [bit] bitrule_A.py BR in Cl(n,0) and Cl(1,n-1): b(E_AB) = <e_A e_B + e_B e_A>_4, exact, rank by Fractions.  [std] the index formula
   (bR)_abcd = R_abcd + R_acdb + R_adbc on the 4-index tensor of each basis element (antisymmetric in each pair, symmetric under the exchange
   of the pairs), integer numpy arrays, rank by numpy.
chn.6 (MIR-005).  In Cl(1,3) (e_t^2 = +1) the mirror x -> -e_t x e_t sends e_t to -e_t and fixes e_1, e_2, e_3, keeps x^2 for 50 random
   integer vectors, has determinant -1 on vectors, and x -> e_t x^ e_t (x^ the grade involution) is an automorphism of the whole algebra
   (all 256 label pairs) that restricts to it on vectors: time reversal.  In Cl(3,1) (e_t^2 = -1) the same formula fixes e_t and reverses
   space: there the mirror in e_t is x -> -e_t x e_t^-1.
   [bit] BR((1,-1,-1,-1)) and BR((-1,1,1,1)), Fractions.  [std] the reflection I - 2 t t^T eta / (t^T eta t) of the 4x4 metric (numpy).
chn.7 (PRJ-001b) and chn.8 (FRQ-003).  For a base R^d with squares all +1 or all -1 (d = 1..4), one extra bit of square 0, -1 or +1, and
   the null pair (two extra bits of squares -1, +1): the bit-rule product equals the Clifford product of the extended form built by
   Chevalley's construction on the exterior algebra (e_i . x = e_i ^ x + q_i i_(e_i) x, iterated) on every label pair (n <= 5).  The radical
   of the trace form tr(L_x L_y) is spanned by the labels that contain a null bit: with one null bit it is the ideal e_0 Cl of dimension
   2^(n-1), its square is 0 and the quotient is the bit rule of the base; the null pair has none (eps = e_p + e_m and o = (e_m - e_p)/2 null,
   eps o + o eps = 2).  The forque engine (forque_selfcheck.bmul, squares [0, 1, 1, 1]: the null generator at bit 0) and the mirrors and
   projective engine (mirrors_selfcheck.bmul, projective PGA with the null bit last) give the bit rule on all label pairs, and moving the null
   generator from the last bit to bit 0 is an algebra isomorphism (generators mapped, blades as ordered products, all pairs): the forque
   bit 0 is the null generator of step 11.
   [bit] BR.  [std] Chevalley's construction (insertion and contraction signs, no closed sign formula), and numpy ranks of the trace form.
Controls ([ctl]; each --fault puts the wrong version in the main lines, which must then FAIL):
   DROP3 the cyclic sum with its third term dropped (pairs that share an axis then feed b); EDGES the distance-2 class taken as the support of b;
   NOMINUS the mirror x -> e_t x e_t (fixes e_t in Cl(1,3)); EXTRA Chevalley built with the extra square +1 against the bit rule with 0;
   NOREORDER the reorder sign dropped from the bit rule (the tables differ); PAIRPP the null pair given squares (+1, +1) (no null vector).
Scope: as stated per item.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this script;
its controls are the faults above.
Command: python3 chain_frames.py   (from this folder, or python3 selfcheck/proofs/chain_frames.py from the package root; standard library,
numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
from math import comb
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _p, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'forque_selfcheck.py'), (_selfcheck, 'mirrors_selfcheck.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
from bitrule_A import BR, rank_fr
import forque_selfcheck as FQ
import mirrors_selfcheck as MS

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('DROP3', 'EDGES', 'NOMINUS', 'EXTRA', 'NOREORDER', 'PAIRPP')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

class BRx(BR):
    """the bit rule; under NOREORDER the reorder sign is dropped (a wrong rule)"""
    def s(self, a, b):
        if FAULT != 'NOREORDER': return BR.s(self, a, b)
        v = 1; m = a & b; i = 0
        while m:
            if m & 1: v *= self.eps[i]
            m >>= 1; i += 1
        return v

# ================================================================================================ chn.5  plane pairs and the Bianchi map
head('chn.5  the table of plane pairs: demicube distances and the tetrahedra of the axis simplex (GRV-001b)')
ok_cls = ok_g4 = ok_b = ok_std = ok_eq = True; table = []
for n in range(4, 9):
    P = [a for a in range(1 << n) if pc(a) == 2]
    pairs = list(itertools.combinations(P, 2))
    d2 = [(a, b) for a, b in pairs if pc(a ^ b) == 2]; d4 = [(a, b) for a, b in pairs if pc(a ^ b) == 4]
    ok_cls &= len(d2) + len(d4) == len(pairs) and len(d2) == n * (n - 1) * (n - 2) // 2 and len(d4) == 3 * comb(n, 4)
    ok_cls &= all((a & b) == 0 for a, b in d4) and all(pc(a & b) == 1 for a, b in d2)
    if n == 4: ok_cls &= len(d2) == 12 and len(d4) == 3 and all(b == a ^ 0b1111 for a, b in d4)
    T4 = [t for t in range(1 << n) if pc(t) == 4]; tix = {t: i for i, t in enumerate(T4)}
    sym = [(a, b) for i, a in enumerate(P) for b in P[i:]]
    for eps in ((1,) * n, (1,) + (-1,) * (n - 1)):
        A = BRx(eps); rows = []; support = set(); feed = {t: [] for t in T4}
        for a, b in sym:
            prod = A.add(A.mul({a: 1}, {b: 1}), A.mul({b: 1}, {a: 1})) if a != b else A.mul({a: 1}, {a: 1})
            g4 = {k: v for k, v in prod.items() if pc(k) == 4}
            ok_g4 &= (bool(g4) == ((a & b) == 0 and a != b)) and all(k == a | b for k in g4)
            row = [Fr(0)] * len(T4)
            for k, v in g4.items(): row[tix[k]] = Fr(v); feed[k].append((a, b, v))
            if g4: support.add((a, b))
            rows.append(row)
        expect = set(d2) if FAULT == 'EDGES' else set(d4)
        r = rank_fr([{c: v for c, v in enumerate(rw) if v} for rw in rows], len(T4))
        ok_b &= support == expect and r == comb(n, 4) and len(sym) - r == n * n * (n * n - 1) // 12
        for t in T4:
            f = sorted(feed[t]); a_, b_, c_, d_ = [i for i in range(n) if t >> i & 1]
            want = [((1 << a_) | (1 << b_), (1 << c_) | (1 << d_)), ((1 << a_) | (1 << c_), (1 << b_) | (1 << d_)), ((1 << a_) | (1 << d_), (1 << b_) | (1 << c_))]
            sg = {}
            for x, y, v in f: sg[(min(x, y), max(x, y))] = v
            ok_b &= len(f) == 3 and [sg.get((min(x, y), max(x, y))) for x, y in want] == [2, -2, 2]
        if eps == (1,) * n: table.append((n, len(d2), len(d4), comb(n, 4), r))
    # [std] index formula on 4-index tensors
    idx2 = {a: [i for i in range(n) if a >> i & 1] for a in P}
    Mstd = []; supp_std = set()
    for a, b in sym:
        R = np.zeros((n, n, n, n), dtype=np.int64)
        (i, j), (k, l) = idx2[a], idx2[b]
        for (p, q, r_, s_) in ((i, j, k, l), (k, l, i, j)):
            R[p, q, r_, s_] += 1; R[q, p, r_, s_] -= 1; R[p, q, s_, r_] -= 1; R[q, p, s_, r_] += 1
        if a == b: R //= 2
        bR = R + np.transpose(R, (0, 2, 3, 1)) + (0 if FAULT == 'DROP3' else np.transpose(R, (0, 3, 1, 2)))
        comp = [int(bR[tuple(i_ for i_ in range(n) if t >> i_ & 1)]) for t in T4]
        nz = bool(np.any(bR != 0))
        if nz: supp_std.add((a, b))
        Mstd.append(comp)
        if a != b and (a & b) == 0:
            g = BR((1,) * n).mul({a: 1}, {b: 1}); t = a | b; v = list(g.values())[0]
            ok_eq &= comp[tix[t]] * 2 == 2 * v and sum(1 for c in comp if c) == 1
    rstd = int(np.linalg.matrix_rank(np.array(Mstd, dtype=float)))
    ok_std &= supp_std == set(d4) and rstd == comb(n, 4)
chk('bit', ok_cls, 'chn.5a: n = 4..8: pairs of distinct planes share one axis (distance 2: a demicube edge) or none (distance 4): n(n-1)(n-2)/2 and 3 C(n,4) pairs; at n = 4, 12 edges and the 3 antipodal pairs of the octahedron ' + str([(t[0], t[1], t[2]) for t in table]))
chk('bit', ok_g4, 'chn.5b: in Cl(n,0) and Cl(1,n-1), n = 4..8: the grade-4 part of e_A e_B + e_B e_A is nonzero exactly for disjoint planes, and then it is +-2 e_(A or B)')
chk('bit', ok_b, 'chn.5c: the first Bianchi map b(E_AB) = <e_A e_B + e_B e_A>_4 is supported on the disjoint pairs only; each set of four axes (a tetrahedron of the axis simplex) is fed by exactly its 3 disjoint pairs, its pairs of opposite edges, with signs (+, -, +); rank C(n,4), kernel n^2(n^2-1)/12 ' + str([(t[0], t[3], t[4]) for t in table]))
chk('std', ok_std, 'chn.5d: index formula (bR)_abcd = R_abcd + R_acdb + R_adbc on the 4-index tensor of each symmetric plane pair: zero exactly unless the planes are disjoint, rank C(n,4) (numpy), n = 4..8')
chk('bit==std', ok_eq and ok_b and ok_std, 'chn.5e: for every disjoint pair the index component on its tetrahedron equals the bit-rule sign of e_A e_B (one nonzero component each): the two routes give the same map')
okc = True
n = 4; R = np.zeros((4, 4, 4, 4), dtype=np.int64)
for (p, q, r_, s_) in ((0, 1, 0, 2), (0, 2, 0, 1)):
    R[p, q, r_, s_] += 1; R[q, p, r_, s_] -= 1; R[p, q, s_, r_] -= 1; R[q, p, s_, r_] += 1
two = R + np.transpose(R, (0, 2, 3, 1)); three = two + np.transpose(R, (0, 3, 1, 2))
chk('ctl', bool(np.any(two != 0)) and not np.any(three != 0), 'chn.5f: wrong version fails: with the third term of the cyclic sum dropped, the pair {01, 02} (one shared axis) feeds b; with all three terms it does not')

# ================================================================================================ chn.6  time reversal as one mirror
head('chn.6  time reversal is the mirror x -> -e_t x e_t (MIR-005)')
def hat(x): return {a: (-v if pc(a) % 2 else v) for a, v in x.items()}
def mirror(A, x):
    et = {1: Fr(1)}
    y = A.mul(A.mul(et, x), et)
    return y if FAULT == 'NOMINUS' else {a: -v for a, v in y.items()}
rng = random.Random(20261013)
res = {}
for name, eps in (('Cl(1,3)', (1, -1, -1, -1)), ('Cl(3,1)', (-1, 1, 1, 1))):
    A = BR(eps)
    imgs = [mirror(A, {1 << i: Fr(1)}) for i in range(4)]
    M = [[imgs[j].get(1 << i, Fr(0)) for j in range(4)] for i in range(4)]
    diag = [M[i][i] for i in range(4)]; offd = all(M[i][j] == 0 for i in range(4) for j in range(4) if i != j)
    keep = True
    for _ in range(50):
        v = {1 << i: Fr(rng.randint(-9, 9)) for i in range(4)}; v = {k: c for k, c in v.items() if c}
        w = mirror(A, v); keep &= A.mul(v, v) == A.mul(w, w) and all(pc(k) == 1 for k in w)
    res[name] = (diag, offd, keep)
d13, off13, keep13 = res['Cl(1,3)']
ok_tr = off13 and d13 == [-1, 1, 1, 1] and keep13
chk('bit', ok_tr, 'chn.6a: Cl(1,3), e_t^2 = +1: x -> -e_t x e_t sends e_t to -e_t, fixes e_1, e_2, e_3 (matrix diag(-1, 1, 1, 1), determinant -1) and keeps x^2 for 50 random integer vectors: time reversal')
A = BR((1, -1, -1, -1)); et = {1: Fr(1)}
Phi = lambda x: A.mul(A.mul(et, hat(x)), et)
ok_aut = all(Phi(A.mul({a: 1}, {b: 1})) == A.mul(Phi({a: 1}), Phi({b: 1})) for a in range(16) for b in range(16))
ok_ext = all(Phi({1 << i: Fr(1)}) == {1 << i: Fr(-1 if i == 0 else 1)} for i in range(4))
chk('bit', ok_aut and ok_ext and ok_tr, 'chn.6b: x -> e_t x^ e_t is an automorphism of Cl(1,3) (all 256 label pairs) and equals the mirror on vectors')
d31, off31, keep31 = res['Cl(3,1)']
chk('bit', off31 and d31 == [1, -1, -1, -1] and keep31, 'chn.6c: Cl(3,1), e_t^2 = -1: the same formula fixes e_t and reverses e_1, e_2, e_3 (parity): there the mirror in e_t is x -> -e_t x e_t^-1; the formula of the row is time reversal for the convention e_t^2 = +1')
def refl(eta, t):
    E = np.diag(eta).astype(float); t = np.array(t, dtype=float)
    return np.eye(4) - 2 * np.outer(t, t) @ E / (t @ E @ t)
R13 = refl([1, -1, -1, -1], [1, 0, 0, 0]); R31 = refl([-1, 1, 1, 1], [1, 0, 0, 0])
E13 = np.diag([1., -1, -1, -1])
ok_std6 = np.allclose(R13, np.diag([-1., 1, 1, 1])) and np.allclose(R13.T @ E13 @ R13, E13) and abs(np.linalg.det(R13) + 1) < 1e-12 and np.allclose(R31, np.diag([-1., 1, 1, 1]))
chk('std', ok_std6, 'chn.6d: the metric reflection along a unit time vector, I - 2 t t^T eta / (t^T eta t), is diag(-1, 1, 1, 1) in both conventions, preserves eta and has determinant -1')
chk('bit==std', ok_std6 and np.allclose(np.diag([float(x) for x in d13]), R13) and np.allclose(-np.diag([float(x) for x in d31]), R31), 'chn.6e: the bit-rule mirror equals the metric reflection in Cl(1,3) and is minus it (parity) in Cl(3,1)')
chk('ctl', [BR((1, -1, -1, -1)).mul(BR((1, -1, -1, -1)).mul(et, {1 << i: Fr(1)}), et).get(1 << i) for i in range(4)] == [1, -1, -1, -1], 'chn.6f: wrong version fails: without the minus sign, x -> e_t x e_t in Cl(1,3) keeps e_t and reverses space')

# ================================================================================================ chn.7 / chn.8  extra bits
head('chn.7 / chn.8  the extra generators are further bits of the same rule (PRJ-001b, FRQ-003)')
def chevalley(q):
    """the Clifford product of the diagonal form q by Chevalley's construction on the exterior algebra (labels as wedge monomials)"""
    m = len(q)
    def lmul_gen(i, x):
        out = {}
        for A_, c in x.items():
            below = pc(A_ & ((1 << i) - 1)); s_ = -1 if below % 2 else 1
            if not A_ >> i & 1: out[A_ | (1 << i)] = out.get(A_ | (1 << i), 0) + s_ * c        # wedge
            elif q[i] != 0: out[A_ & ~(1 << i)] = out.get(A_ & ~(1 << i), 0) + s_ * q[i] * c   # contraction
        return {k: v for k, v in out.items() if v}
    def mul(x, y):
        out = {}
        for a, ca in x.items():
            z = dict(y)
            for i in reversed([i for i in range(m) if a >> i & 1]): z = lmul_gen(i, z)
            for k, v in z.items(): out[k] = out.get(k, 0) + ca * v
        return {k: v for k, v in out.items() if v}
    return mul
cases = []
for d in range(1, 5):
    for sp in (1, -1):
        for x in (0, -1, 1): cases.append(('one extra bit %+d, base %+d^%d' % (x, sp, d), (x,) + (sp,) * d))
        if d <= 3: cases.append(('null pair (-1, +1), base %+d^%d' % (sp, d), (-1, 1) + (sp,) * d))
ok_tab = True; npairs = 0
for name, q in cases:
    A = BRx(q); qc = list(q)
    if FAULT == 'EXTRA' and q[0] == 0: qc[0] = 1
    cmul = chevalley(qc); N = 1 << len(q)
    for a in range(N):
        for b in range(N):
            ok_tab &= A.mul({a: 1}, {b: 1}) == cmul({a: 1}, {b: 1}); npairs += 1
chk('bit==std', ok_tab, 'chn.7a: %d cells (base R^d with squares all +1 or all -1, d = 1..4; one extra bit of square 0, -1, +1; the null pair (-1, +1) for d <= 3): the bit-rule product equals Chevalley\'s Clifford product of the extended form on all %d label pairs' % (len(cases), npairs))
ok_rad = ok_rad_std = True
for name, q in cases:
    A = BR(q); N = 1 << len(q)
    T = [[(N * A.s(a, a) if a == b else 0) for b in range(N)] for a in range(N)]              # tr(L_a L_b) = N [a = b] s(a, a)
    rad = [a for a in range(N) if T[a][a] == 0]
    want = [a for a in range(N) if any(q[i] == 0 for i in range(len(q)) if a >> i & 1)]
    ok_rad &= rad == want
    if q[0] == 0:
        J = [a for a in range(N) if a & 1]
        ideal = all(not A.mul({b: 1}, {a: 1}) or all(k & 1 for k in A.mul({b: 1}, {a: 1})) for a in J for b in range(N)) and all(not A.mul({a: 1}, {b: 1}) or all(k & 1 for k in A.mul({a: 1}, {b: 1})) for a in J for b in range(N))
        sq0 = all(A.mul({a: 1}, {b: 1}) == {} for a in J for b in J)
        base = BR(q[1:]); quo = all(A.s(a << 1, b << 1) == base.s(a, b) for a in range(N >> 1) for b in range(N >> 1))
        ok_rad &= rad == J and len(J) == N // 2 and ideal and sq0 and quo
    if len(q) <= 4:
        L = []
        for a in range(N):
            M = np.zeros((N, N))
            cm = chevalley(list(q))
            for b in range(N):
                for k, v in cm({a: 1}, {b: 1}).items(): M[k, b] += v
            L.append(M)
        Tn = np.array([[np.trace(L[a] @ L[b]) for b in range(N)] for a in range(N)])
        ok_rad_std &= int(np.linalg.matrix_rank(Tn)) == N - len(want)
pq = (1, 1) if FAULT == 'PAIRPP' else (-1, 1)
Cp = BR(pq + (1, 1)); ep, em = {1: Fr(1)}, {2: Fr(1)}
epsv = Cp.add(ep, em); o = Cp.scal(Cp.add(em, ep, -1), Fr(1, 2))
ok_pair = Cp.mul(epsv, epsv) == {} and Cp.mul(o, o) == {} and Cp.add(Cp.mul(epsv, o), Cp.mul(o, epsv)) == {0: 2}
chk('bit', ok_rad and ok_pair, 'chn.7b: the radical of the trace form tr(L_x L_y) is spanned by the labels with a null bit; with one null bit it is the two-sided ideal e_0 Cl of dimension 2^(n-1), its square is 0 and the quotient is the bit rule of the base; the null pair has no radical: eps = e_p + e_m, o = (e_m - e_p)/2 are null and eps o + o eps = 2')
chk('std', ok_rad_std, 'chn.7c: numpy: the rank of the trace form of the left-regular matrices built by Chevalley\'s construction is 2^n minus the number of labels with a null bit (every cell above with n <= 4)')
ok_fq = all(FQ.bmul(a, b, [0, 1, 1, 1]) == (a ^ b, BRx((0, 1, 1, 1)).s(a, b)) for a in range(16) for b in range(16))
alg = FQ.Alg(3); ok_fq &= list(alg.sq) == [0, 1, 1, 1]
ok_ms = all(MS.bmul(a, b, list(q)) == (a ^ b, BRx(q).s(a, b)) for name, q in cases if len(q) <= 4 for a in range(1 << len(q)) for b in range(1 << len(q)))
chk('bit', ok_fq, 'chn.8a: the forque engine (forque_selfcheck.Alg(3), squares [0, 1, 1, 1], the null generator at bit 0) multiplies every one of the 256 label pairs as the bit rule of Cl(3,0,1)')
chk('bit', ok_ms, 'chn.8b: the mirrors and projective engine (mirrors_selfcheck.bmul) multiplies every label pair of every cell above with n <= 4 as the bit rule')
src = BR((1, 1, 1, 0)); dst = BR((0, 1, 1, 1))                       # step 11 PGA: null bit last; forque: null bit 0
gimg = {0: 1 << 1, 1: 1 << 2, 2: 1 << 3, 3: 1 << 0}
def phi(a):
    x = {0: Fr(1)}
    for i in range(4):
        if a >> i & 1: x = dst.mul(x, {gimg[i]: Fr(1)})
    return x
ok_iso = all(dst.mul(phi(a), phi(b)) == {k2: v * c for k, v in src.mul({a: 1}, {b: 1}).items() for k2, c in phi(k).items()} for a in range(16) for b in range(16))
chk('bit', ok_iso, 'chn.8c: moving the null generator from the last bit (the PGA of step 11, squares (+1, +1, +1, 0)) to bit 0 (the forque algebra) maps generators to generators with the same squares and is an algebra isomorphism on all 256 label pairs: the forque bit 0 is the null generator of step 11')
okc_ex = any(BR((0, 1)).mul({a: 1}, {b: 1}) != chevalley([1, 1])({a: 1}, {b: 1}) for a in range(4) for b in range(4))
Pp = BR((1, 1)); e1, e2 = {1: Fr(1)}, {2: Fr(1)}
okc_pp = all(Pp.mul(Pp.add(Pp.scal(e1, x), Pp.scal(e2, y)), Pp.add(Pp.scal(e1, x), Pp.scal(e2, y))) != {} for x in range(-3, 4) for y in range(-3, 4) if (x, y) != (0, 0))
chk('ctl', okc_ex and okc_pp, 'chn.8d: wrong versions fail: Chevalley with square +1 differs from the bit rule with square 0 on some label pair; a pair of squares (+1, +1) has no null vector in its plane (49 grid points)')

finish('CHAIN-FRAMES')
