#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""bpst_stabiliser.py: the other half of the instanton count: the ten conformal Killing fields that fix the density of the BPST instanton act on
it by gauge transformations, with the gauge parameter written down and checked identically.      python3 bpst_stabiliser.py [--fault NAME]

The field (CAND-124; bpst_modes.py): A^a_mu = 2 eta^a_mu.nu x^nu/(x^2 + rho^2), F = dA + A ^ A = -4 eta^a_mu.nu rho^2/(x^2 + rho^2)^2 with the
structure constants eps^abc (checked here from A).  A vector field xi deforms A by its Lie derivative L_xi A; the deformation is a gauge
transformation when L_xi A = D_A lambda = d lambda + [A, lambda] for some su(2)-valued function lambda.
G1. the six rotations M_mu.nu: L_xi A = D_A lambda with the constant lambda^a = -eta^a_mu.nu (a global gauge rotation: the instanton is
    SO(4)-invariant up to the colour rotation that the self-dual index carries).
G2. the four combinations K_mu + rho^2 P_mu (K_mu = 2 x_mu x.d - x^2 d_mu the special conformal fields, P_mu the translations):
    L_xi A = D_A lambda with lambda^a = -2 eta^a_mu.sigma x^sigma, a linear function of x (the gauge parameter of the special conformal part
    of the stabiliser, as in Jackiw and Rebbi's O(5), recalled).
    Both identities hold at every point of a 6^4 grid of rational points (the numerator polynomials, of degree <= 4, vanish identically).
G3. with the five that move the density (the translations and the dilatation) and the ten above, the fifteen fields split exactly: the
    deformations L_xi A span a space whose quotient by the gauge directions has dimension 5 (8k - 3 at k = 1, recalled): the five change
    a gauge invariant, so no gauge parameter exists for them (a change of the density is not a gauge transformation), and the ten have one.
    The combinations K_mu - rho^2 P_mu have none: the equation L_xi A = D_A lambda has no solution in the space of lambda of the form
    (eta or eta-bar)^a_mu.sigma x^sigma times polynomials in x_mu, x^2 and 1/(x^2 + rho^2) (an exact linear system at 30 points, inconsistent),
    and their density variation is not zero.
[bit]  the field, its derivatives and the gauge parameters exactly (Fractions) at rational points; the commutator through eps^abc; the Hodge
       star of Cl(4,0) by the bit rule is not needed here (bpst_modes.py), the labels enter through the 't Hooft symbols as the self-dual blades.
[std]  the same identities by numpy central differences of A and lambda at 60 random points (residual below 1e-7); the gauge parameters
       found independently by exact linear algebra over an ansatz (the solver that found them, re-run).
[ctl]  WRONGSIGN (lambda^a = +2 eta^a_mu.sigma x^sigma for K + rho^2 P), ETABAR (eta-bar in place of eta in lambda), each wrong version exits 1.
Scope: one instanton (rho^2 = 2, centre 0); the grid x_i in {-5/2, ..., 5/2}; 30 random rational points for the ansatz; 60 for the differences.
Standard library and numpy.   Command: python3 bpst_stabiliser.py   (from this folder, or python3 selfcheck/proofs/bpst_stabiliser.py from
the root of the checks)."""
import os, sys, itertools, random, time
from fractions import Fraction as Fr
import numpy as np

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('WRONGSIGN', 'ETABAR')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time(); RHO2 = Fr(2)

def eps3(a, b, c): return (a - b) * (b - c) * (c - a) // 2
ETA = [[[Fr(0)] * 4 for _ in range(4)] for _ in range(3)]; ETAB = [[[Fr(0)] * 4 for _ in range(4)] for _ in range(3)]
for a in range(3):
    for i in range(3):
        for j in range(3): ETA[a][i][j] = Fr(eps3(a, i, j)); ETAB[a][i][j] = Fr(eps3(a, i, j))
        ETA[a][i][3] = Fr(int(a == i)); ETA[a][3][i] = Fr(-int(a == i)); ETAB[a][i][3] = Fr(-int(a == i)); ETAB[a][3][i] = Fr(int(a == i))
def x2(x): return sum(v * v for v in x)
def A_at(x):
    """A^a_mu and d_sigma A^a_mu, exact"""
    Q = x2(x) + RHO2
    A = [[sum(2 * ETA[a][m][n] * x[n] for n in range(4)) / Q for m in range(4)] for a in range(3)]
    dA = [[[2 * ETA[a][m][s] / Q - sum(2 * ETA[a][m][n] * x[n] for n in range(4)) * 2 * x[s] / Q ** 2 for m in range(4)] for a in range(3)] for s in range(4)]
    return A, dA
def F_from_A(x):
    A, dA = A_at(x)
    return [[[dA[m][a][n] - dA[n][a][m] + sum(eps3(a, b, c) * A[b][m] * A[c][n] for b in range(3) for c in range(3)) for n in range(4)] for m in range(4)] for a in range(3)]
def F_closed(x):
    Q = x2(x) + RHO2; return [[[-4 * ETA[a][m][n] * RHO2 / Q ** 2 for n in range(4)] for m in range(4)] for a in range(3)]
def lieA(x, xi, J):
    """(L_xi A)^a_mu = xi^s d_s A^a_mu + (d_mu xi^s) A^a_s"""
    A, dA = A_at(x)
    return [[sum(xi[s] * dA[s][a][m] + J[s][m] * A[a][s] for s in range(4)) for m in range(4)] for a in range(3)]
def DA(x, lam, dlam):
    """(D_A lambda)^a_mu = d_mu lambda^a + eps^abc A^b_mu lambda^c"""
    A, _ = A_at(x)
    return [[dlam[a][m] + sum(eps3(a, b, c) * A[b][m] * lam[c] for b in range(3) for c in range(3)) for m in range(4)] for a in range(3)]
# the fields: value xi^i and Jacobian J[i][s] = d_s xi^i
def field_M(x, m, n):
    xi = [Fr(0)] * 4; xi[n] = x[m]; xi[m] = -x[n]
    J = [[Fr(0)] * 4 for _ in range(4)]; J[n][m] = Fr(1); J[m][n] = Fr(-1); return xi, J
def field_KP(x, b, sgn):
    xx = x2(x); xi = [2 * x[b] * x[i] - (xx if i == b else 0) + (sgn * RHO2 if i == b else 0) for i in range(4)]
    J = [[2 * int(s == b) * x[i] + 2 * x[b] * int(i == s) - (2 * x[s] if i == b else 0) for s in range(4)] for i in range(4)]
    return xi, J
# the gauge parameters
def lam_M(x, m, n):
    E = ETAB if FAULT == 'ETABAR' else ETA
    return [-E[a][m][n] for a in range(3)], [[Fr(0)] * 4 for _ in range(3)]
def lam_KP(x, b):
    E = ETAB if FAULT == 'ETABAR' else ETA; c = 2 if FAULT == 'WRONGSIGN' else -2
    return [c * sum(E[a][b][s] * x[s] for s in range(4)) for a in range(3)], [[c * E[a][b][mu] for mu in range(4)] for a in range(3)]

head('G0. the field strength from A, exactly')
GRID = [Fr(2 * k - 5, 2) for k in range(6)]
okF = all(F_from_A(x) == F_closed(x) for x in itertools.product(GRID, repeat=4))
chk('bit', okF, 'bps.G0: F = dA + A ^ A with the structure constants eps^abc equals -4 eta rho^2/(x^2 + rho^2)^2 at all 1296 grid points (the convention of the commutator fixed)')

head('G1-G2. the ten gauge parameters, identically on the 6^4 grid')
okM = True; okK = True; npts = 0
for x in itertools.product(GRID, repeat=4):
    npts += 1
    for m in range(4):
        for n in range(m + 1, 4):
            xi, J = field_M(x, m, n); lam, dlam = lam_M(x, m, n)
            okM &= lieA(x, xi, J) == DA(x, lam, dlam)
    for b in range(4):
        xi, J = field_KP(x, b, +1); lam, dlam = lam_KP(x, b)
        okK &= lieA(x, xi, J) == DA(x, lam, dlam)
chk('bit', okM, 'bps.G1: the six rotations M_mu.nu: L_xi A = D_A lambda with the constant lambda^a = -eta^a_mu.nu, at all %d grid points (identically)' % npts)
chk('bit', okK, 'bps.G2: the four fields K_mu + rho^2 P_mu: L_xi A = D_A lambda with lambda^a = -2 eta^a_mu.sigma x^sigma, at all %d grid points (identically)' % npts)

head('G3. no gauge parameter for K_mu - rho^2 P_mu, and the solver that finds the ten')
def basis(x, b, sgn_unused=None):
    """an ansatz for lambda^a(x): (eta or eta-bar)^a_b.sigma x^sigma times x_b^i (x^2)^j (x^2 + rho^2)^-k, i, j <= 2, k <= 3; values and gradients"""
    Q = x2(x) + RHO2; xx = x2(x); scal = []
    for i in range(3):
        for j in range(3):
            for k in range(4):
                v = x[b] ** i * xx ** j / Q ** k
                grad = [(i * x[b] ** (i - 1) * int(mu == b) if i else 0) * xx ** j / Q ** k + x[b] ** i * (j * xx ** (j - 1) * 2 * x[mu] if j else 0) / Q ** k + x[b] ** i * xx ** j * (-k) * 2 * x[mu] / Q ** (k + 1) for mu in range(4)]
                scal.append((v, grad, (i, j, k)))
    out = []
    for E, nameE in ((ETA, 'eta'), (ETAB, 'etabar')):
        val = [sum(E[a][b][s] * x[s] for s in range(4)) for a in range(3)]; gT = [[E[a][b][mu] for mu in range(4)] for a in range(3)]
        for (sv, sg, key) in scal:
            out.append(([val[a] * sv for a in range(3)], [[gT[a][mu] * sv + val[a] * sg[mu] for mu in range(4)] for a in range(3)], (nameE,) + key))
    return out
def solve_ansatz(b, sgn, npts=30, seed=7):
    rg = random.Random(seed); rows = []; rhs = []; keys = None
    for _ in range(npts):
        x = [Fr(rg.randint(-6, 6), rg.randint(1, 4)) for _ in range(4)]
        if x2(x) == 0: continue
        A, _ = A_at(x); xi, J = field_KP(x, b, sgn); L = lieA(x, xi, J); B = basis(x, b); keys = [k for _, _, k in B]
        for a in range(3):
            for mu in range(4):
                rows.append([grad[a][mu] + sum(eps3(a, bb, c) * A[bb][mu] * val[c] for bb in range(3) for c in range(3)) for (val, grad, _) in B]); rhs.append(L[a][mu])
    n = len(rows[0]); M = [r + [v] for r, v in zip(rows, rhs)]; piv = []; rk = 0
    for cidx in range(n):
        p = next((i for i in range(rk, len(M)) if M[i][cidx] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; pv = M[rk][cidx]; M[rk] = [v / pv for v in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][cidx] != 0:
                f = M[i][cidx]; M[i] = [u - f * v for u, v in zip(M[i], M[rk])]
        piv.append(cidx); rk += 1
    inconsistent = any(all(v == 0 for v in r[:-1]) and r[-1] != 0 for r in M)
    sol = {keys[cidx]: M[i][-1] for i, cidx in enumerate(piv) if M[i][-1] != 0}
    return inconsistent, sol, rk, n
res_plus = [solve_ansatz(b, +1) for b in range(4)]; res_minus = [solve_ansatz(b, -1) for b in range(4)]
chk('std', all(not inc and sol == {('eta', 0, 0, 0): Fr(-2)} for inc, sol, rk, n in res_plus), 'bps.G3: the exact solver over the ansatz (72 unknowns, 360 equations at 30 random rational points) finds for K_mu + rho^2 P_mu exactly lambda = -2 eta^a_mu.sigma x^sigma and nothing else (for each mu; rank %s)' % [rk for _, _, rk, _ in res_plus])
chk('ctl', all(inc for inc, sol, rk, n in res_minus), 'bps.G3: for K_mu - rho^2 P_mu the same system is inconsistent for every mu: no gauge parameter in the ansatz (and the density moves, bps.M2)')
# the five: the translations and the dilatation change the density (bps.M2); here: the equation has no solution in the ansatz either (a check of the same kind)
def solve_generic(name, npts=20, seed=11):
    rg = random.Random(seed); rows = []; rhs = []
    for _ in range(npts):
        x = [Fr(rg.randint(-6, 6), rg.randint(1, 4)) for _ in range(4)]
        if x2(x) == 0: continue
        A, _ = A_at(x)
        if name == 'D': xi, J = list(x), [[Fr(int(i == j)) for j in range(4)] for i in range(4)]
        else: xi, J = field_KP(x, int(name[1]), 0)  # sgn 0: pure K (not used) -- replaced below
        if name[0] == 'P': xi = [Fr(int(i == int(name[1]))) for i in range(4)]; J = [[Fr(0)] * 4 for _ in range(4)]
        L = lieA(x, xi, J); B = basis(x, int(name[1])) if name[0] == 'P' else basis(x, 0) + basis(x, 3)
        for a in range(3):
            for mu in range(4):
                rows.append([grad[a][mu] + sum(eps3(a, bb, c) * A[bb][mu] * val[c] for bb in range(3) for c in range(3)) for (val, grad, _) in B]); rhs.append(L[a][mu])
    n = len(rows[0]); M = [r + [v] for r, v in zip(rows, rhs)]; rk = 0
    for cidx in range(n):
        p = next((i for i in range(rk, len(M)) if M[i][cidx] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; pv = M[rk][cidx]; M[rk] = [v / pv for v in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][cidx] != 0:
                f = M[i][cidx]; M[i] = [u - f * v for u, v in zip(M[i], M[rk])]
        rk += 1
    return any(all(v == 0 for v in r[:-1]) and r[-1] != 0 for r in M)
chk('bit', all(solve_generic(nm) for nm in ('P0', 'P1', 'P2', 'P3', 'D')), 'bps.G3: the translations and the dilatation have no gauge parameter in the ansatz either (the five directions that move the density): with G1-G2 the fifteen split 10 + 5, the quotient by the gauge directions of dimension 5')
# std: numpy central differences
ETAN = np.array([[[float(ETA[a][m][n]) for n in range(4)] for m in range(4)] for a in range(3)]); r2 = float(RHO2)
def A_np(x): return 2 * np.einsum('amn,n->am', ETAN, x) / (x @ x + r2)
def xi_np(name, x):
    if name[0] == 'M': m, n = int(name[1]), int(name[2]); v = np.zeros(4); v[n] = x[m]; v[m] = -x[n]; return v
    b = int(name[1]); return 2 * x[b] * x - (x @ x) * np.eye(4)[b] + r2 * np.eye(4)[b]
def lam_np(name, x):
    if name[0] == 'M': m, n = int(name[1]), int(name[2]); return -ETAN[:, m, n]
    b = int(name[1]); return -2 * ETAN[:, b, :] @ x
def lieA_np(name, x, h=1e-4):
    """(L_xi A)^a_mu = xi^s d_s A^a_mu + (d_mu xi^s) A^a_s by central differences"""
    A = A_np(x); L = np.zeros((3, 4)); xi = xi_np(name, x)
    for s in range(4):
        e = np.eye(4)[s]; L += xi[s] * (A_np(x + h * e) - A_np(x - h * e)) / (2 * h)
    for m in range(4):
        e = np.eye(4)[m]; dxi = (xi_np(name, x + h * e) - xi_np(name, x - h * e)) / (2 * h)       # d_mu xi^s
        L[:, m] += np.einsum('s,as->a', dxi, A)
    return L
def DA_np(name, x, h=1e-4):
    A = A_np(x); lam = lam_np(name, x); out = np.zeros((3, 4))
    for m in range(4):
        e = np.eye(4)[m]; dl = (lam_np(name, x + h * e) - lam_np(name, x - h * e)) / (2 * h)
        out[:, m] = dl + np.cross(A[:, m], lam)
    return out
rng = np.random.default_rng(5); worst = 0.0
for _ in range(60):
    x = rng.uniform(-2, 2, 4)
    for name in ['M01', 'M02', 'M03', 'M12', 'M13', 'M23', 'S0', 'S1', 'S2', 'S3']:
        worst = max(worst, float(np.abs(lieA_np(name, x) - DA_np(name, x)).max()))
chk('std', worst < 1e-7, 'bps.G: numpy central differences at 60 random points: L_xi A - D_A lambda below 1e-7 for the ten fields (max %.1e)' % worst)
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('BPST-STABILISER')
