#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""fock_encodings.py: Bogoliubov transformations on five modes, Gibbs states and Fermi-Dirac occupations, the Jordan-Wigner and Bravyi-Kitaev
encodings as gauges of one sign, the top-blade form of the Gaussian as a Pfaffian, and the index of finite graded complexes.
     python3 fock_encodings.py [--fault ORTHO|SYMM|PRODUCT|NEGW|BETA|FLIP|SYMPF|ENTRY|QSQ|NOSIGN]

B (fock.B1..B4).  On the 32 labels of five modes c_i^+ is the left multiplication by e_i in BR((0,0,0,0,0)) and c_i its transpose (the matrices
   a_op(i) of baez.H3a); gamma_i = c_i^+ + c_i, gamma~_i = c_i^+ - c_i generate Cl(5,5).  For each of the ten pairs i < j the pair term
   X = c_i^+ c_j^+ - c_j c_i is the bivector (gamma_i gamma_j + gamma~_i gamma~_j)/2 with parts of degree +2 and -2 under ad N; X^2 = -P (P the
   projector on n_i = n_j) and X^3 = -X, so exp(theta X) = 1 + sin(theta) X + (1 - cos(theta)) X^2; for cos = 3/5, sin = 4/5 the matrix U is
   orthogonal, U c_i U^T = (3/5) c_i - (4/5) c_j^+, U c_j U^T = (3/5) c_j + (4/5) c_i^+, U c_k U^T = c_k otherwise, the new operators satisfy the
   CAR, and <S|U|T> = 0 unless |S| - |T| is 0, 2 or -2 (both signs occur).
   [bit]  BR of researchers_checks/bitrule_A.py, exact integer matrices (5U and 25 U c U^T).   [std]  numpy Jordan-Wigner matrices (Kronecker
          products of sigma_minus and Z) and scipy.linalg.expm of theta X in floats.
G (fock.G1..G3).  For n = 1..8 and rational weights w_i = exp(-beta(eps_i - mu)): in Cl(n,n) by BR, n_i = (1 - e_i e_(n+i))/2 and
   rho = prod (1 + (w_i - 1) n_i) = exp(-beta(H - mu N)); with Tr = 2^n x scalar part (Cl(n,n) = M_(2^n)(R)): Z = prod (1 + w_i), equal to the sum
   over the 2^n labels of prod_(i in S) w_i, <n_i> = w_i/(1 + w_i) = 1/(e^(beta(eps_i - mu)) + 1), <n_i n_j> = <n_i><n_j>; phi(x) = Tr(rho x)/Z
   has phi(1) = 1, phi(x^dagger) = phi(x) (e_a^dagger = e_a^-1) and a positive semi-definite Gram matrix phi(e_a^dagger e_b) over the 4^n blades
   (exact LDL for n <= 3, numpy for n = 4): a state in the sense of check_T15.
   [bit]  BR products, Fractions.   [std]  numpy Jordan-Wigner n_i, scipy expm of -beta(H - mu N), traces.
E (fock.E1..E5).  Pauli strings (i-exponent, x bits, z bits) with their product rule.  Jordan-Wigner Majoranas c_k = Z_(<k) X_k, d_k = Z_(<k) Y_k;
   Bravyi-Kitaev with beta of the Seeley-Richard-Love recursion (beta_1 = [1], beta_2m = [[beta_m, 0], [A, beta_m]], A zero but for a last row
   of ones; the n x n corner), update, parity, flip and remainder sets from beta and beta^-1, c_k = X_U(k) X_k Z_P(k), d_k = X_U(k) Y_k Z_R(k).
   For n <= 8: both sets of 2n Majoranas are hermitian, square to 1 and anticommute pairwise (the CAR), and BK = (t, beta x, beta^-T z) of JW,
   the conjugation by the permutation |x> -> |beta x> of the occupation basis.  For n <= 6, all 4^n x 4^n pairs of Majorana monomials:
   m_a m_b = sigma(a,b) m_(a xor b) with sigma the bit-rule sign of Cl(2n,0) in both encodings; writing m_a = phi_E(a) P(L_E a), P the hermitian
   Pauli string, the Pauli-basis cocycles s_JW and s_BK differ by the coboundary of f(a) = phi_JW(a)/phi_BK(a), a sign.  On the cube of
   occupations (n <= 8) both encodings give the edge sign of the Jordan-Wigner string; the Jordan-Wigner sign for the reversed order of the
   modes differs from it by the coboundary of g(x) = (-1)^(number of pairs in x), and cat.K1d is asserted again (n = 3: the 128 anticommuting
   assignments of the 2^12 are the gauge orbit of the Jordan-Wigner sign).
   [bit]  BR signs (directly for n <= 4, the vectorised BR formula, checked against BR on samples, for n = 5, 6).   [std]  numpy 2^n x 2^n
          matrices for n <= 5 (both encodings, the CAR, the permutation matrix Pi with BK = Pi JW Pi^T); beta from the Fenwick-tree rule.
P (fock.P1..P3).  On the Grassmann cell BR((0,)*n) the top-blade coefficient of exp(B), B = sum_(i<j) A_ij e_i e_j (a finite series), is Pf(A)
   for even n and 0 for odd n, n = 2..10, three random integer skew matrices each; the top coefficient of the wedge exponential (products of
   disjoint blades only) is the same in every cell eps in {-1,0,1}^n for n <= 6 and in sampled cells for n = 8, 10; in Cl(2,0) the Clifford
   exponential of a e_12 has top coefficient sin(a) (partial sums), not a.
   [bit]  BR products.   [std]  Pfaffian by exact elimination (Fractions) and by expansion along the first row; Pf^2 = det (f2lib.det_int).
W (fock.W1..W3).  sum over the 2^n labels of (-1)^|a| = 0, n <= 8.  For n <= 6, Lambda(R^n) graded by degree, L_w the left multiplication by a
   vector w in BR((0,)*n), Q = X^-1 L_w X (X random graded invertible, exact) and its truncations to degrees <= K: Q^2 = 0, dim H^k =
   dim C^k - rank Q_k - rank Q_(k-1) (exact ranks), and sum (-1)^k dim H^k = sum (-1)^k dim C^k = (-1)^K C(n-1,K) for every X, w, K and every
   deformation X + tY tried; Tr (-1)^F e^(-beta H), H = Q Q^T + Q^T Q, equals this Euler number for beta = 0.05, 0.5, 5.
   [bit]  BR, exact Fractions ranks.   [std]  the wedge by its formula (compared with BR), numpy spectra.
Controls ([ctl], each with a --fault that puts the wrong version in the main lines, which must then FAIL):
   ORTHO c_i -> c_i + c_j^+ ({b, b^+} = 2); SYMM the symmetric pair term c_i^+ c_j^+ + c_j c_i (also a bivector of degrees +-2, but its
   exponential is not orthogonal: {b_i, b_i^+} = 17/8); PRODUCT an interaction weight on n_0 n_1 (Z and the factorisation fail); NEGW a
   negative weight (the Gram matrix has a negative eigenvalue); BETA one entry of beta changed in the update sets (the relations fail; a singular
   beta gives no permutation); FLIP one value of s_BK flipped (the cocycle identity fails: no coboundary); SYMPF a symmetric matrix (B = 0 on
   the Grassmann cell, Pf^2 = det fails); ENTRY one entry of the upper triangle negated (another Pfaffian); QSQ Q + E with Q^2 != 0 (the trace
   depends on beta); NOSIGN sum dim in place of sum (-1)^k dim (depends on beta).
Scope: five modes for B, n <= 8 for G (positivity n <= 4), n <= 8 for E (cocycles n <= 6, matrices n <= 5), n <= 10 for P, n <= 6 for the
index and n <= 8 for the super-dimension.  The gravity engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this
script; its controls are the faults above.
Command: python3 fock_encodings.py   (from this folder, or python3 selfcheck/proofs/fock_encodings.py from the package root; standard library,
numpy, scipy)."""
import os, sys, itertools, random, math
from fractions import Fraction as Fr
import numpy as np
from scipy.linalg import expm

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _p, _f in ((_researchers, 'bitrule_A.py'), (_researchers, 'f2lib.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
from bitrule_A import BR
import f2lib

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('ORTHO', 'SYMM', 'PRODUCT', 'NEGW', 'BETA', 'FLIP', 'SYMPF', 'ENTRY', 'QSQ', 'NOSIGN')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')

def inertia_fr(G):
    """exact (positive, negative, zero) of a symmetric rational matrix by congruence"""
    A = [[Fr(x) for x in row] for row in G]; n = len(A); pos = neg = 0; k = 0
    while k < n:
        i = next((i for i in range(k, n) if A[i][i] != 0), None)
        if i is None:
            pair = next(((i, j) for i in range(k, n) for j in range(k, n) if i != j and A[i][j] != 0), None)
            if pair is None: break
            i, j = pair
            for t in range(n): A[i][t] += A[j][t]
            for t in range(n): A[t][i] += A[t][j]
        A[k], A[i] = A[i], A[k]
        for row in A: row[k], row[i] = row[i], row[k]
        d = A[k][k]; pos += d > 0; neg += d < 0
        for r in range(k + 1, n):
            if A[r][k] != 0:
                f = A[r][k] / d
                for t in range(k, n): A[r][t] -= f * A[k][t]
        for r in range(k + 1, n): A[k][r] = A[r][k] = Fr(0)
        k += 1
    return pos, neg, n - pos - neg
def rank_fr(M):
    A = [[Fr(x) for x in r] for r in M]; rk = 0; nr = len(A); nc = len(A[0]) if A else 0
    for c in range(nc):
        p = next((i for i in range(rk, nr) if A[i][c] != 0), None)
        if p is None: continue
        A[rk], A[p] = A[p], A[rk]
        for i in range(rk + 1, nr):
            if A[i][c] != 0:
                f = A[i][c] / A[rk][c]; A[i] = [a - f * b for a, b in zip(A[i], A[rk])]
        rk += 1
    return rk
def inv_fr(M):
    n = len(M); A = [[Fr(x) for x in r] + [Fr(int(i == j)) for j in range(n)] for i, r in enumerate(M)]
    for c in range(n):
        p = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[p] = A[p], A[c]
        iv = 1 / A[c][c]; A[c] = [v * iv for v in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [a - f * b for a, b in zip(A[i], A[c])]
    return [r[n:] for r in A]
def mm(X, Y): return [[sum(a * b for a, b in zip(r, c)) for c in zip(*Y)] for r in X]

# ================================================================================================ B. Bogoliubov transformations
head('B. five modes on the 32 labels: pair terms, their exponentials, the CAR and the particle number (fock.B1..B4)')
def left_matrix(A, x, N):
    M = np.zeros((N, N), dtype=np.int64)
    for b in range(N):
        for a, ca in x.items():
            s = A.s(a, b)
            if s: M[a ^ b, b] += s * ca
    return M
G5 = BR((0,) * 5); I32 = np.eye(32, dtype=np.int64)
Cp = [left_matrix(G5, {1 << i: 1}, 32) for i in range(5)]; Cm = [c.T.copy() for c in Cp]
def a_op(i):
    M = np.zeros((32, 32), dtype=np.int64)
    for x in range(32):
        if (x >> i) & 1: M[x ^ (1 << i), x] = (-1) ** pc(x & ((1 << i) - 1))
    return M
Gm = [Cp[i] + Cm[i] for i in range(5)]; Gt = [Cp[i] - Cm[i] for i in range(5)]
Nop = sum(Cp[i] @ Cm[i] for i in range(5))
def car(ann, s):
    """CAR for annihilators scaled by s: B_k B_l^T + B_l^T B_k = s^2 delta, B_k B_l + B_l B_k = 0"""
    return all(((ann[k] @ ann[l].T + ann[l].T @ ann[k]) == (s * s * I32 if k == l else 0 * I32)).all() and not (ann[k] @ ann[l] + ann[l] @ ann[k]).any() for k in range(len(ann)) for l in range(len(ann)))
ok_base = all((Cm[i] == a_op(i)).all() for i in range(5)) and car(Cm, 1) and (np.diag(Nop) == [pc(x) for x in range(32)]).all()
ok_base &= all(((Gm[i] @ Gm[j] + Gm[j] @ Gm[i]) == 2 * I32 * (i == j)).all() and ((Gt[i] @ Gt[j] + Gt[j] @ Gt[i]) == -2 * I32 * (i == j)).all() and not (Gm[i] @ Gt[j] + Gt[j] @ Gm[i]).any() for i in range(5) for j in range(5))
chk('bit', ok_base, 'fock.B1: c_i^+ = left multiplication by e_i in BR((0,)*5), c_i its transpose: equal to baez.H3a a_op(i), the CAR, N = popcount; gamma_i = c_i^+ + c_i and gamma~_i = c_i^+ - c_i square to +1 and -1 and anticommute (Cl(5,5) on the 32 labels)')
okX = okE = okO = okT = okC = okN = True; dN = set()
for i in range(5):
    for j in range(i + 1, 5):
        Xp = Cp[i] @ Cp[j]; Xm = Cm[j] @ Cm[i]
        X = Xp + Xm if FAULT == 'SYMM' else Xp - Xm
        okX &= (2 * (Xp - Xm) == Gm[i] @ Gm[j] + Gt[i] @ Gt[j]).all() and ((Nop @ Xp - Xp @ Nop) == 2 * Xp).all() and ((Nop @ Xm - Xm @ Nop) == -2 * Xm).all()
        P = np.diag([1 if ((x >> i) & 1) == ((x >> j) & 1) else 0 for x in range(32)]).astype(np.int64)
        okE &= ((X @ X) == -P).all() and ((X @ X @ X) == -X).all()
        U5 = 5 * I32 + 4 * X + 2 * (X @ X)
        okO &= ((U5.T @ U5) == 25 * I32).all()
        new = []
        for k in range(5):
            T = U5 @ Cm[k] @ U5.T
            if k == i: want = 15 * Cm[i] - 20 * Cp[j]
            elif k == j: want = 15 * Cm[j] + 20 * Cp[i]
            else: want = 25 * Cm[k]
            okT &= (T == want).all(); new.append(want // 5)
        if FAULT == 'ORTHO': new = [Cm[k] for k in range(5)]; new[i] = Cm[i] + Cp[j]; okC &= car(new, 1)
        else: okC &= car(new, 5)
        nz = np.argwhere(U5 != 0)
        d = {pc(int(S)) - pc(int(T_)) for S, T_ in nz}; dN |= d
        okN &= d <= {0, 2, -2} and all((pc(int(S)) - pc(int(T_))) % 2 == 0 for S, T_ in nz)
chk('bit', okX, 'fock.B2: for the ten pairs i < j, X = c_i^+ c_j^+ - c_j c_i = (gamma_i gamma_j + gamma~_i gamma~_j)/2, a bivector of Cl(5,5); ad N gives c_i^+ c_j^+ degree +2 and c_j c_i degree -2 (baez.H3c: the 10 + 25 + 10 grading)')
chk('bit', okE and okO, 'fock.B2: X^2 = -P (P the projector on the labels with n_i = n_j) and X^3 = -X, so exp(theta X) = 1 + sin(theta) X + (1 - cos(theta)) X^2; with cos = 3/5, sin = 4/5: (5U)^T (5U) = 25 (U orthogonal), exact integers')
chk('bit', okT and okC, 'fock.B3: 25 U c_i U^T = 15 c_i - 20 c_j^+, 25 U c_j U^T = 15 c_j + 20 c_i^+, U c_k U^T = c_k for the other modes: the Bogoliubov map c_i -> (3/5) c_i - (4/5) c_j^+, c_j -> (3/5) c_j + (4/5) c_i^+, and the new operators satisfy the CAR exactly')
chk('bit', okN and dN == {0, 2, -2}, 'fock.B3: <S|U|T> = 0 unless |S| - |T| is in %s (both +2 and -2 occur; the parity is kept): the pair exponentials change the particle number by 0 or +-2' % sorted(dN))
# controls
b_bad = [Cm[k] for k in range(5)]; b_bad[0] = Cm[0] + Cp[1]
Y = Cp[0] @ Cp[1] + Cm[1] @ Cm[0]; P01 = np.diag([1 if (x & 1) == ((x >> 1) & 1) else 0 for x in range(32)]).astype(np.int64)
V4 = 4 * I32 + 3 * Y + Y @ Y; V4i = 4 * I32 - 3 * Y + Y @ Y
okY = (2 * Y == Gm[0] @ Gt[1] + Gt[0] @ Gm[1]).all() and ((Y @ Y) == P01).all() and ((V4 @ V4i) == 16 * I32).all() and not ((V4.T @ V4) == 16 * I32).all()
bY = V4 @ Cm[0] @ V4i; okY &= (bY == 20 * Cm[0] - 12 * Cp[1]).all()
b4 = 5 * Cm[0] - 3 * Cp[1]; acY = b4 @ b4.T + b4.T @ b4
chk('ctl', not car(b_bad, 1) and ((b_bad[0] @ b_bad[0].T + b_bad[0].T @ b_bad[0]) == 2 * I32).all(), 'fock.B4: c_0 -> c_0 + c_1^+ (not orthogonal) gives {b_0, b_0^+} = 2: the CAR fail')
chk('ctl', okY and (acY == 34 * I32).all(), 'fock.B4: the symmetric term Y = c_0^+ c_1^+ + c_1 c_0 is also a bivector of degrees +-2 ((gamma_0 gamma~_1 + gamma~_0 gamma_1)/2), but Y^2 = +P: exp(theta Y) = 1 + sinh Y + (cosh - 1) Y^2 (cosh 5/4, sinh 3/4) is not orthogonal, V c_0 V^-1 = (5/4) c_0 - (3/4) c_1^+ and {b_0, b_0^+} = 17/8: no Bogoliubov map')
# [std]
sm = np.array([[0., 1.], [0., 0.]]); Zs = np.diag([1., -1.]); I2 = np.eye(2)
def jw_ann(k, n):
    M = np.ones((1, 1))
    for m in range(n - 1, -1, -1): M = np.kron(M, sm if m == k else (Zs if m < k else I2))
    return M
Am = [jw_ann(k, 5) for k in range(5)]
th = math.atan2(4, 3); ok_std = all(np.array_equal(Am[k], Cm[k].astype(float)) for k in range(5)); maxd = 0.0
for i in range(5):
    for j in range(i + 1, 5):
        Xs = Am[i].T @ Am[j].T - Am[j] @ Am[i]; Us = expm(th * Xs)
        X = Cp[i] @ Cp[j] - Cm[j] @ Cm[i]; Ue = (5 * I32 + 4 * X + 2 * (X @ X)) / 5.0
        maxd = max(maxd, float(np.abs(Us - Ue).max()))
        ok_std &= np.allclose(Us @ Am[i] @ Us.T, 0.6 * Am[i] - 0.8 * Am[j].T) and np.allclose(Us @ Am[j] @ Us.T, 0.6 * Am[j] + 0.8 * Am[i].T)
chk('std', ok_std and maxd < 1e-12, 'fock.B3: numpy Jordan-Wigner matrices (Kronecker products of sigma_minus and Z) equal the bit-rule c_i; scipy expm(theta X), theta = atan2(4,3), equals the exact U to < 1e-12 for all ten pairs and maps c_i to 0.6 c_i - 0.8 c_j^+')
chk('bit==std', ok_std and okT, 'fock.B3: the exact and the floating Bogoliubov maps agree on all ten pairs')

# ================================================================================================ G. Gibbs states and Fermi-Dirac occupations
head('G. Gibbs states on the labels: Z = prod (1 + w_i), Fermi-Dirac occupations, positivity (fock.G1..G3)')
WTS = [Fr(1, 2), Fr(3), Fr(2, 5), Fr(7, 3), Fr(1, 7), Fr(5, 4), Fr(9, 2), Fr(1, 3)]
okZ = okL = okO = okP = okH = okProj = True; ZS = []
def gibbs(n, w, interact=False):
    A = BR((1,) * n + (-1,) * n)
    nop = [{0: Fr(1, 2), (1 << i) | (1 << (n + i)): Fr(-1, 2)} for i in range(n)]
    rho = {0: Fr(1)}
    for i in range(n): rho = A.mul(rho, A.add({0: Fr(1)}, A.scal(nop[i], w[i] - 1)))
    if interact: rho = A.mul(rho, A.add({0: Fr(1)}, A.mul(nop[0], nop[1])))
    return A, nop, rho
for n in range(1, 9):
    w = WTS[:n]
    if FAULT == 'NEGW': w = [Fr(-1, 2)] + w[1:]
    A, nop, rho = gibbs(n, w, interact=(FAULT == 'PRODUCT' and n >= 2))
    okProj &= all(A.mul(nop[i], nop[i]) == nop[i] for i in range(n)) and all(A.mul(nop[i], nop[j]) == A.mul(nop[j], nop[i]) for i in range(n) for j in range(i))
    trace = lambda x: (1 << n) * x.get(0, 0)
    Z = trace(rho); ZS.append(Z)
    okZ &= Z == math.prod(1 + wi for wi in w)
    okL &= Z == sum(math.prod((w[i] for i in range(n) if (S >> i) & 1), start=Fr(1)) for S in range(1 << n))
    occ = [trace(A.mul(rho, nop[i])) / Z for i in range(n)]
    okO &= occ == [wi / (1 + wi) for wi in w]
    okP &= all(trace(A.mul(A.mul(rho, nop[i]), nop[j])) / Z == occ[i] * occ[j] for i in range(n) for j in range(i + 1, n))
chk('bit', okZ and okL and okProj, 'fock.G1: Cl(n,n) by BR, n = 1..8, w = %s: n_i = (1 - e_i e_(n+i))/2 are commuting projectors (BR), so rho = prod (1 + (w_i - 1) n_i) = exp(-beta(H - mu N)); Z = 2^n <rho>_0 = %s = prod (1 + w_i) = sum over the 2^n labels of prod_(i in S) w_i' % ([str(x) for x in WTS], [str(z) for z in ZS[:3]] + ['...']))
chk('bit', okO and okP, 'fock.G1: <n_i> = Tr(rho n_i)/Z = w_i/(1 + w_i) = 1/(e^(beta(eps_i - mu)) + 1) (Fermi-Dirac) and <n_i n_j> = <n_i><n_j> for all i < j, n = 1..8, exact')
okG = True; inert = {}
for n in range(1, 5):
    w = WTS[:n]
    if FAULT == 'NEGW': w = [Fr(-1, 2)] + w[1:]
    A, nop, rho = gibbs(n, w, interact=(FAULT == 'PRODUCT' and n >= 2)); Z = (1 << n) * rho.get(0, 0); N = 1 << (2 * n)
    phi = [Fr(0)] * N
    for c, v in rho.items(): phi[c] = (1 << n) * v * A.s(c, c) / Z
    okH &= phi[0] == 1 and all(A.s(a, a) * phi[a] == phi[a] for a in range(N))
    G = [[A.s(a, a) * A.s(a, b) * phi[a ^ b] for b in range(N)] for a in range(N)]
    okH &= all(G[a][b] == G[b][a] for a in range(N) for b in range(N))
    if n <= 3: inert[n] = inertia_fr(G); okG &= inert[n][1] == 0
    else:
        ev = np.linalg.eigvalsh(np.array(G, dtype=float)); inert[n] = (int((ev > 1e-12).sum()), int((ev < -1e-12).sum()), int((np.abs(ev) <= 1e-12).sum())); okG &= inert[n][1] == 0
chk('bit', okH and okG, 'fock.G2: phi(x) = Tr(rho x)/Z has phi(1) = 1, phi(x^dagger) = phi(x) (e_a^dagger = e_a^-1) and a positive semi-definite Gram matrix phi(e_a^dagger e_b) over the 4^n blades, (pos, neg, zero) = ' + ', '.join('n=%d: %s' % (n, inert[n]) for n in sorted(inert)) + ' (exact LDL for n <= 3, numpy for n = 4): a state in the sense of check_T15')
beta_, mu_ = 1.3, 0.4; ok_gs = True
for n in (1, 3, 5, 8):
    w = [float(x) for x in WTS[:n]]; epsl = [mu_ - math.log(x) / beta_ for x in w]
    nn = [jw_ann(k, n).T @ jw_ann(k, n) for k in range(n)]
    Hm = sum((epsl[k] - mu_) * nn[k] for k in range(n)); rh = expm(-beta_ * Hm); Zs_ = np.trace(rh)
    ok_gs &= abs(Zs_ - float(math.prod(1 + x for x in WTS[:n]))) < 1e-9 * Zs_ and all(abs(np.trace(rh @ nn[k]) / Zs_ - 1 / (math.exp(beta_ * (epsl[k] - mu_)) + 1)) < 1e-12 for k in range(n))
chk('std', ok_gs, 'fock.G3: numpy Jordan-Wigner n_i, eps_i = mu - ln(w_i)/beta (beta = 1.3, mu = 0.4), scipy expm(-beta(H - mu N)) on 2^n states, n = 1, 3, 5, 8: trace = prod (1 + w_i) and Tr(rho n_i)/Z = 1/(e^(beta(eps_i - mu)) + 1)')
chk('bit==std', ok_gs and okZ and okO, 'fock.G3: the exact partition functions and occupations of the bit rule equal the floating ones')
A2, nop2, rho2 = gibbs(3, WTS[:3], interact=True); Z2 = 8 * rho2[0]
occ2 = [8 * A2.mul(rho2, nop2[i]).get(0, 0) / Z2 for i in range(3)]; c01 = 8 * A2.mul(A2.mul(rho2, nop2[0]), nop2[1]).get(0, 0) / Z2
chk('ctl', Z2 != math.prod(1 + x for x in WTS[:3]) and c01 != occ2[0] * occ2[1], 'fock.G3: a weight not of product form (an extra factor 2 on n_0 n_1): Z = %s, not prod (1 + w_i) = %s, and <n_0 n_1> = %s, not <n_0><n_1> = %s' % (Z2, math.prod(1 + x for x in WTS[:3]), c01, occ2[0] * occ2[1]))
A3, nop3, rho3 = gibbs(2, [Fr(-1, 2), Fr(3)]); Z3 = 4 * rho3[0]; N3 = 16
phi3 = [Fr(0)] * N3
for c, v in rho3.items(): phi3[c] = 4 * v * A3.s(c, c) / Z3
G3_ = [[A3.s(a, a) * A3.s(a, b) * phi3[a ^ b] for b in range(N3)] for a in range(N3)]
chk('ctl', inertia_fr(G3_)[1] > 0, 'fock.G3: with a negative weight w_0 = -1/2 the Gram matrix has inertia %s: a negative direction, not a state' % (inertia_fr(G3_),))

# ================================================================================================ E. Jordan-Wigner and Bravyi-Kitaev
head('E. fermion-to-qubit encodings: Jordan-Wigner and Bravyi-Kitaev as gauges of one sign (fock.E1..E5)')
def pmul(p, q):
    t1, x1, z1 = p; t2, x2, z2 = q
    return ((t1 + t2 + 2 * (pc(z1 & x2) & 1)) % 4, x1 ^ x2, z1 ^ z2)
def anti(p, q): return ((pc(p[1] & q[2]) + pc(p[2] & q[1])) & 1) == 1
def hermitian(p): return p[0] % 4 == pc(p[1] & p[2]) % 4
def jw_maj(n):
    out = []
    for k in range(n): low = (1 << k) - 1; out += [(0, 1 << k, low), (1, 1 << k, low | (1 << k))]
    return out
def beta_srl(n):
    b = [[1]]; m = 1
    while m < n:
        Aa = [[0] * m for _ in range(m)]; Aa[m - 1] = [1] * m
        b = [r + [0] * m for r in b] + [Aa[r] + b[r] for r in range(m)]; m *= 2
    return [r[:n] for r in b[:n]]
def beta_fenwick(n): return [[1 if (j + 1 - ((j + 1) & -(j + 1))) <= k <= j else 0 for k in range(n)] for j in range(n)]
def cols_of(B): n = len(B); return tuple(sum(B[j][k] << j for j in range(n)) for k in range(n))
def transpose_cols(c, n): return tuple(sum(((c[k] >> j) & 1) << k for k in range(n)) for j in range(n))
def bk_maj(n, B, Bx=None):
    bc = cols_of(B); bxc = cols_of(Bx) if Bx else bc; binvT = transpose_cols(f2lib.inv(bc), n); out = []; sets_ok = True
    for k in range(n):
        Uk = bxc[k] & ~(1 << k); Pk = f2lib.apply(binvT, (1 << k) - 1); Fk = f2lib.apply(binvT, 1 << k) & ~(1 << k); Rk = Pk & ~Fk
        sets_ok &= (Fk & ~Pk) == 0 and not (Pk >> k) and not (Uk & ((1 << (k + 1)) - 1))
        out += [(0, Uk | (1 << k), Pk), (1, Uk | (1 << k), Rk | (1 << k))]
    return out, sets_ok
def car_pauli(M):
    return all(hermitian(m) for m in M) and all(anti(M[a], M[b]) for a in range(len(M)) for b in range(a)) and len({(m[1], m[2]) for m in M}) == len(M)
okSRL = all(beta_srl(n) == beta_fenwick(n) for n in range(1, 9))
okCAR = okConj = okSets = True
for n in range(1, 9):
    Bt = beta_srl(n); J = jw_maj(n)
    if FAULT == 'BETA' and n >= 2:
        Bw = [r[:] for r in Bt]; Bw[n - 1][0] ^= 1; K, so = bk_maj(n, Bt, Bw)
    else: K, so = bk_maj(n, Bt)
    okSets &= so; okCAR &= car_pauli(J) and car_pauli(K)
    bc = cols_of(Bt); binvT = transpose_cols(f2lib.inv(bc), n)
    okConj &= all(K[a] == (J[a][0], f2lib.apply(bc, J[a][1]), f2lib.apply(binvT, J[a][2])) for a in range(2 * n))
chk('std', okSRL, 'fock.E1: beta of the Seeley-Richard-Love recursion equals the Fenwick-tree rule (qubit j stores the occupations j+1-lowbit(j+1) .. j), n = 1..8')
chk('bit', okCAR and okSets, 'fock.E1: Jordan-Wigner c_k = Z_(<k) X_k, d_k = Z_(<k) Y_k and Bravyi-Kitaev c_k = X_U(k) X_k Z_P(k), d_k = X_U(k) Y_k Z_R(k) (sets from beta, beta^-1; F(k) in P(k) < k < U(k)): 2n hermitian strings of square 1, pairwise anticommuting (symplectic arithmetic), n = 1..8: both satisfy the CAR')
chk('bit', okConj, 'fock.E1: every BK Majorana is (t, beta x, beta^-T z) of the JW one: BK is JW conjugated by the permutation |x> -> |beta x> of the occupation basis, n = 1..8')
POP12 = np.array([pc(x) for x in range(1 << 12)], dtype=np.int8)
def br_sign_exp(nb):
    N = 1 << nb; a = np.arange(N, dtype=np.int16)[:, None]; b = np.arange(N, dtype=np.int16)[None, :]; par = np.zeros((N, N), dtype=np.int8)
    for i in range(nb): par ^= (((a >> i) & 1).astype(np.int8) * (POP12[b & ((1 << i) - 1)] & 1)).astype(np.int8)
    return (2 * par).astype(np.int8)
def monomials(M, n):
    N = 1 << (2 * n); t = np.zeros(N, dtype=np.int16); x = np.zeros(N, dtype=np.int16); z = np.zeros(N, dtype=np.int16); mono = {0: (0, 0, 0)}
    for a in range(1, N):
        low = (a & -a).bit_length() - 1; mono[a] = pmul(M[low], mono[a & ~(1 << low)]); t[a], x[a], z[a] = mono[a]
    return t, x, z
okSig = okCob = okF = True; fcount = {}; okBRsample = True
for n in range(1, 7):
    nb = 2 * n; N = 1 << nb; J = jw_maj(n); K, _ = bk_maj(n, beta_srl(n))
    sig = br_sign_exp(nb)
    if n <= 4:
        A = BR((1,) * nb); okBRsample &= all(sig[a, b] == (0 if A.s(a, b) == 1 else 2) for a in range(N) for b in range(N))
    else:
        A = BR((1,) * nb); rs = random.Random(n); okBRsample &= all(sig[a, b] == (0 if A.s(a, b) == 1 else 2) for a, b in ((rs.randrange(N), rs.randrange(N)) for _ in range(20000)))
    ab = np.arange(N, dtype=np.int16)[:, None] ^ np.arange(N, dtype=np.int16)[None, :]
    res = {}
    for name, M in (('JW', J), ('BK', K)):
        t, x, z = monomials(M, n); ph = (t - POP12[x & z]) % 4
        tab = (t[:, None] + t[None, :] + 2 * (POP12[z[:, None] & x[None, :]] & 1)) % 4
        okSig &= ((tab - t[ab]) % 4 == sig).all() and (x[:, None] ^ x[None, :] == x[ab]).all() and (z[:, None] ^ z[None, :] == z[ab]).all()
        hx = POP12[x & z]; s_E = (hx[:, None] + hx[None, :] + 2 * (POP12[z[:, None] & x[None, :]] & 1) - hx[ab]) % 4
        okSig &= ((ph[:, None] + ph[None, :] + s_E - ph[ab]) % 4 == sig).all()
        res[name] = (ph, s_E)
    f = (res['JW'][0] - res['BK'][0]) % 4
    okF &= set(np.unique(f).tolist()) <= {0, 2}; fcount[n] = int((f == 2).sum())
    sBK = res['BK'][1].copy()
    if FAULT == 'FLIP': sBK[1, 2] = (sBK[1, 2] + 2) % 4
    okCob &= ((res['JW'][1] - sBK) % 4 == (f[ab] - f[:, None] - f[None, :]) % 4).all()
chk('bit', okSig and okBRsample, 'fock.E2: for n = 1..6 and all 4^n x 4^n pairs of Majorana monomials, m_a m_b = sigma(a,b) m_(a xor b) in both encodings with sigma the bit-rule sign of Cl(2n,0) (BR on all pairs for n <= 4, the vectorised BR formula checked against BR on 20000 random pairs for n = 5, 6): one CAR algebra, one sign')
chk('bit', okF and okCob, 'fock.E2: with m_a = phi_E(a) P(L_E a) (P the hermitian Pauli string) the Pauli-basis cocycles satisfy s_JW(a,b) = s_BK(a,b) f(a xor b) f(a) f(b) for the explicit sign f = phi_JW/phi_BK, all pairs, n = 1..6 (f = -1 on %s monomials): the two encodings differ by a coboundary' % ', '.join('%d' % fcount[n] for n in range(1, 7)))
def cube_signs(M, n, enc):
    """edge signs of a_k^+ = (c_k - i d_k)/2 on the states enc(x): a_k^+ |enc(x)> = s |enc(x + e_k)>"""
    out = {}; good = True
    for k in range(n):
        c, d = M[2 * k], M[2 * k + 1]
        for xo in range(1 << n):
            bvec = enc(xo); vals = {}
            for coef_t, (t, x, z) in ((0, c), (3, d)):
                tt = (coef_t + t + 2 * (pc(z & bvec) & 1)) % 4; tgt = bvec ^ x
                vals[tgt] = vals.get(tgt, 0) + (1, 1j, -1, -1j)[tt] / 2
            vals = {k_: v for k_, v in vals.items() if abs(v) > 1e-12}
            if (xo >> k) & 1: good &= not vals
            else:
                tgt = enc(xo | (1 << k)); good &= list(vals) == [tgt] and abs(abs(vals[tgt]) - 1) < 1e-12 and abs(vals[tgt].imag) < 1e-12
                if list(vals) == [tgt]: out[(xo, k)] = int(round(vals[tgt].real))
    return out, good
okCube = okGauge = True
for n in range(1, 9):
    Bt = beta_srl(n); bc = cols_of(Bt); K, _ = bk_maj(n, Bt)
    sJ, g1 = cube_signs(jw_maj(n), n, lambda x: x); sK, g2 = cube_signs(K, n, lambda x: f2lib.apply(bc, x))
    jws = {(x, k): (-1) ** pc(x & ((1 << k) - 1)) for x in range(1 << n) for k in range(n) if not (x >> k) & 1}
    okCube &= g1 and g2 and sJ == jws and sK == jws
    rev = {(x, k): (-1) ** pc(x >> (k + 1)) for x in range(1 << n) for k in range(n) if not (x >> k) & 1}
    g = lambda x: (-1) ** (pc(x) * (pc(x) - 1) // 2)
    okGauge &= all(rev[e] == jws[e] * g(e[0]) * g(e[0] | (1 << e[1])) for e in jws)
chk('bit', okCube, 'fock.E3: on the cube of occupations (n = 1..8) a_k^+ = (c_k - i d_k)/2 maps |enc(x)> to s(x,k) |enc(x + e_k)> with s = (-1)^(number of occupied modes below k), the Jordan-Wigner string and the bit-rule edge sign (cat.K1b), for both encodings (enc = identity, enc = beta)')
chk('bit', okGauge, 'fock.E3: the Jordan-Wigner sign for the reversed order of the modes, (-1)^(occupied modes above k), is the Jordan-Wigner sign times the coboundary of g(x) = (-1)^(|x|(|x|-1)/2), on every edge, n = 1..8: another ordering is another gauge')
E3 = [(a, i) for a in range(8) for i in range(3) if not (a >> i) & 1]; sq3 = []
for a in range(8):
    for i in range(3):
        for j in range(i + 1, 3):
            if not (a >> i) & 1 and not (a >> j) & 1: sq3.append(((a, i), (a | (1 << i), j), (a, j), (a | (1 << j), i)))
sols = set()
for assign in itertools.product((1, -1), repeat=12):
    s = dict(zip(E3, assign))
    if all(s[p] * s[q] * s[u] * s[v] == -1 for p, q, u, v in sq3): sols.add(assign)
orbit = set()
for gv in itertools.product((1, -1), repeat=8):
    orbit.add(tuple((-1) ** pc(a & ((1 << i) - 1)) * gv[a] * gv[a | (1 << i)] for a, i in E3))
chk('ctl', len(sols) == 128 and sols == orbit, 'fock.E4: cat.K1d again: of the 2^12 sign assignments on the 3-cube, %d make all six squares anticommute, and they are exactly the %d gauge transforms of the Jordan-Wigner sign' % (len(sols), len(orbit)))
okBad = True
for n in range(2, 9):
    Bt = beta_srl(n); Bw = [r[:] for r in Bt]; Bw[n - 1][0] ^= 1; Kw, _ = bk_maj(n, Bt, Bw); okBad &= not car_pauli(Kw)
chk('ctl', okBad, 'fock.E4: one entry of beta changed (row n-1, column 0) in the update sets: the Majoranas no longer anticommute, n = 2..8')
n3 = 3; N3 = 64; J3 = jw_maj(n3); K3, _ = bk_maj(n3, beta_srl(n3)); ab3 = np.arange(N3, dtype=np.int16)[:, None] ^ np.arange(N3, dtype=np.int16)[None, :]
def cocycle_ok(g):
    a = np.arange(N3)[:, None, None]; b = np.arange(N3)[None, :, None]; c = np.arange(N3)[None, None, :]; g = g.astype(np.int16)
    return ((g[a, b] + g[a ^ b, c] - g[a, b ^ c] - g[b, c]) % 4 == 0).all()
sE = {}
for name, M in (('JW', J3), ('BK', K3)):
    t, x, z = monomials(M, n3); hx = POP12[x & z]; sE[name] = (hx[:, None] + hx[None, :] + 2 * (POP12[z[:, None] & x[None, :]] & 1) - hx[ab3]) % 4
gq = (sE['JW'] - sE['BK']) % 4; gbad = gq.copy(); gbad[1, 2] = (gbad[1, 2] + 2) % 4
chk('ctl', cocycle_ok(gq) and not cocycle_ok(gbad), 'fock.E4: s_JW/s_BK satisfies the cocycle identity on all 64^3 triples (n = 3); with one value flipped (the pair m_0, m_1) it does not, so it is no coboundary')
# [std] matrices
Xs = np.array([[0, 1], [1, 0]], dtype=complex); Zc = np.diag([1, -1]).astype(complex); I2c = np.eye(2, dtype=complex)
def pmat(p, n):
    t, x, z = p; M = np.ones((1, 1), dtype=complex)
    for k in range(n - 1, -1, -1):
        f = I2c
        if (x >> k) & 1: f = Xs
        if (z >> k) & 1: f = f @ Zc
        M = np.kron(M, f)
    return (1, 1j, -1, -1j)[t % 4] * M
okM = True; okPi = True; okBRm = True; okSing = True
for n in range(1, 6):
    d = 1 << n; Bt = beta_srl(n); bc = cols_of(Bt); J = [pmat(p, n) for p in jw_maj(n)]; K = [pmat(p, n) for p in bk_maj(n, Bt)[0]]
    Pi = np.zeros((d, d))
    for x in range(d): Pi[f2lib.apply(bc, x), x] = 1
    okPi &= np.allclose(Pi @ Pi.T, np.eye(d)) and all(np.allclose(K[a], Pi @ J[a] @ Pi.T) for a in range(2 * n))
    for M in (J, K):
        aa = [(M[2 * k] + 1j * M[2 * k + 1]) / 2 for k in range(n)]
        okM &= all(np.allclose(aa[k] @ aa[l].conj().T + aa[l].conj().T @ aa[k], np.eye(d) * (k == l)) and np.allclose(aa[k] @ aa[l] + aa[l] @ aa[k], 0) for k in range(n) for l in range(n))
    if n == 5: okBRm &= all(np.allclose((J[2 * k] + 1j * J[2 * k + 1]) / 2, Cm[k]) for k in range(5))
    if n >= 2:
        Bs = [r[:] for r in Bt]; Bs[n - 1] = Bs[n - 2][:]; bs = cols_of(Bs); Ps = np.zeros((d, d))
        for x in range(d): Ps[f2lib.apply(bs, x), x] = 1
        aS = [Ps @ ((J[2 * k] + 1j * J[2 * k + 1]) / 2) @ Ps.T for k in range(n)]
        okSing &= not np.allclose(Ps @ Ps.T, np.eye(d)) and not all(np.allclose(aS[k] @ aS[k].conj().T + aS[k].conj().T @ aS[k], np.eye(d)) for k in range(n))
chk('std', okM and okPi, 'fock.E5: numpy 2^n x 2^n matrices, n = 1..5: a_k = (c_k + i d_k)/2 satisfy the CAR in both encodings, and BK = Pi JW Pi^T for the permutation matrix Pi |x> = |beta x>')
chk('bit==std', okBRm and okCube, 'fock.E5: at n = 5 the Jordan-Wigner a_k from Pauli matrices equal the bit-rule c_k of fock.B1')
chk('ctl', okSing, 'fock.E5: a singular beta (last row equal to the one before) gives no permutation (Pi Pi^T != 1) and the transported operators fail the CAR, n = 2..5')

# ================================================================================================ P. the Berezin integral and the Pfaffian
head('P. the top-blade form of exp(B) on the Grassmann cell is the Pfaffian (fock.P1..P3)')
def pf_elim(M):
    A = [[Fr(x) for x in r] for r in M]; n = len(A)
    if n % 2: return Fr(0)
    pf = Fr(1)
    for k in range(0, n - 1, 2):
        j = next((j for j in range(k + 1, n) if A[k][j] != 0), None)
        if j is None: return Fr(0)
        if j != k + 1:
            A[k + 1], A[j] = A[j], A[k + 1]
            for r in A: r[k + 1], r[j] = r[j], r[k + 1]
            pf = -pf
        p = A[k][k + 1]; pf *= p
        for i in range(k + 2, n):
            al, ga = A[k][i] / p, A[k + 1][i] / p
            if al == 0 and ga == 0: continue
            for r in range(n): A[r][i] = A[r][i] - al * A[r][k + 1] + ga * A[r][k]
            for c in range(n): A[i][c] = A[i][c] - al * A[k + 1][c] + ga * A[k][c]
    return pf
def pf_expand(M):
    n = len(M)
    if n == 0: return 1
    if n % 2: return 0
    tot = 0
    for j in range(1, n):
        keep = [r for r in range(n) if r not in (0, j)]
        tot += (-1) ** (j - 1) * M[0][j] * pf_expand([[M[r][c] for c in keep] for r in keep])
    return tot
def top_exp(A, B, n, wedge=False):
    tot = {0: Fr(1)}; term = {0: Fr(1)}; k = 0
    while term:
        k += 1
        if wedge:
            new = {}
            for a, ca in term.items():
                for b, cb in B.items():
                    if a & b == 0: new[a | b] = new.get(a | b, 0) + A.s(a, b) * ca * cb
            term = {l: v / k for l, v in new.items() if v != 0}
        else: term = {l: v / k for l, v in A.mul(term, B).items()}
        tot = A.add(tot, term)
        if k > n + 2: break
    return tot.get((1 << n) - 1, Fr(0))
def berezin(G, x, n):
    """the integral d theta_n ... d theta_1: the left derivatives d_1 first, then d_2, ..., d_n"""
    for k in range(n):
        y = {}
        for a, v in x.items():
            if (a >> k) & 1: y[a ^ (1 << k)] = y.get(a ^ (1 << k), 0) + v * (-1) ** pc(a & ((1 << k) - 1))
        x = {l: c for l, c in y.items() if c != 0}
    return x.get(0, Fr(0))
rngP = random.Random(123); okPf = okDet = okOdd = True; nmat = 0; okCell = True; ncell = 0; okBer = True
MATS = {}
for n in range(2, 11):
    G = BR((0,) * n); MATS[n] = []
    for _ in range(3):
        A_ = [[0] * n for _ in range(n)]
        for i in range(n):
            for j in range(i + 1, n): v = rngP.randint(-5, 5); A_[i][j], A_[j][i] = v, -v
        if A_[0][1] == 0: A_[0][1], A_[1][0] = 2, -2
        MATS[n].append(A_)
        if FAULT == 'SYMPF':
            S_ = [[abs(A_[i][j]) + (i == j) for j in range(n)] for i in range(n)]
            B = {}
            for i in range(n):
                for j in range(n):
                    if i != j: B = G.add(B, G.mul({1 << i: 1}, {1 << j: 1}), Fr(S_[i][j], 2))
            top = top_exp(G, B, n); ref = pf_elim(S_); okDet &= top * top == f2lib.det_int(S_)
        else:
            Au = [r[:] for r in A_]
            if FAULT == 'ENTRY': Au[0][1] = -Au[0][1]
            B = {(1 << i) | (1 << j): Fr(Au[i][j]) for i in range(n) for j in range(i + 1, n) if Au[i][j]}
            top = top_exp(G, B, n); ref = pf_elim(A_)
            okDet &= ref * ref == f2lib.det_int(A_) and ref == pf_expand(A_)
            ex = {0: Fr(1)}; term = {0: Fr(1)}; k_ = 0
            while term: k_ += 1; term = {l: v / k_ for l, v in G.mul(term, B).items()}; ex = G.add(ex, term)
            rx = {a: Fr(rngP.randint(-3, 3)) for a in range(1 << n) if rngP.random() < 0.3}
            okBer &= berezin(G, ex, n) == top and berezin(G, rx, n) == rx.get((1 << n) - 1, 0)
        if n % 2 == 0: okPf &= top == ref
        else: okOdd &= top == 0 and ref == 0 and f2lib.det_int(A_) == 0
        nmat += 1
for n in range(2, 7):
    for eps in itertools.product((1, -1, 0), repeat=n):
        G = BR(eps); A_ = MATS[n][0]; B = {(1 << i) | (1 << j): Fr(A_[i][j]) for i in range(n) for j in range(i + 1, n) if A_[i][j]}
        okCell &= top_exp(G, B, n, wedge=True) == pf_elim(A_); ncell += 1
rc = random.Random(7)
for n in (8, 10):
    for _ in range(6):
        eps = tuple(rc.choice((1, -1, 0)) for _ in range(n)); G = BR(eps); A_ = MATS[n][1]
        B = {(1 << i) | (1 << j): Fr(A_[i][j]) for i in range(n) for j in range(i + 1, n) if A_[i][j]}
        okCell &= top_exp(G, B, n, wedge=True) == pf_elim(A_); ncell += 1
chk('bit', okBer, 'fock.P1: lambda (the top-blade coefficient) is the Berezin integral d theta_n ... d theta_1: the iterated left derivatives d_1, then d_2, ..., d_n give the top coefficient, on exp(B) and on random elements of Lambda(R^n), n = 2..10')
chk('bit', okPf and okOdd, 'fock.P1: on the Grassmann cell BR((0,)*n) the top-blade coefficient of exp(sum_(i<j) A_ij e_i e_j) (finite series) equals Pf(A) for n = 2, 4, 6, 8, 10 and vanishes for n = 3, 5, 7, 9 (%d random integer skew matrices, exact)' % nmat)
chk('std', okDet, 'fock.P1: the Pfaffian by exact elimination equals the expansion along the first row, and Pf(A)^2 = det A (Bareiss, f2lib.det_int); det A = 0 for odd n')
chk('bit', okCell, 'fock.P2: the top coefficient of the wedge exponential (products of disjoint blades, signs from BR(eps)) is Pf(A) in every one of the cells eps in {-1,0,1}^n for n = 2..6 and in 12 sampled cells for n = 8, 10 (%d cells): the top-blade form of the wedge exponential does not depend on the cell' % ncell)
A20 = BR((1, 1)); a_ = Fr(1, 2); term = {0: Fr(1)}; tot = {0: Fr(1)}
for k in range(1, 12): term = {l: v / k for l, v in A20.mul(term, {3: a_}).items()}; tot = A20.add(tot, term)
sin_part = sum((-1) ** ((k - 1) // 2) * a_ ** k / math.factorial(k) for k in range(1, 12, 2))
chk('ctl', tot.get(3, 0) == sin_part and tot.get(3, 0) != a_, 'fock.P3: in Cl(2,0) the Clifford exponential of a e_12 (a = 1/2, 11 terms) has top coefficient %s = the partial sum of sin(a), not a: outside the Grassmann cell only the wedge exponential gives the Pfaffian' % tot.get(3, 0))
G4 = BR((0,) * 4); S4 = [[2, 1, 0, 1], [1, 3, 1, 0], [0, 1, 2, 1], [1, 0, 1, 3]]; BS = {}
for i in range(4):
    for j in range(4):
        if i != j: BS = G4.add(BS, G4.mul({1 << i: 1}, {1 << j: 1}), Fr(S4[i][j], 2))
chk('ctl', BS == {} and top_exp(G4, BS, 4) ** 2 != f2lib.det_int(S4), 'fock.P3: a symmetric matrix (det %d) gives B = (1/2) sum S_ij e_i e_j = 0 on the Grassmann cell, top coefficient 0, so Pf^2 = det cannot hold: the identity needs a skew matrix' % f2lib.det_int(S4))
okEn = True; nchg = {}
for n in (2, 4, 6, 8, 10):
    G = BR((0,) * n); nchg[n] = 0
    for A_ in MATS[n]:
        Au = [r[:] for r in A_]; Au[0][1] = -Au[0][1]; minor = [[A_[r][c] for c in range(2, n)] for r in range(2, n)]
        B = {(1 << i) | (1 << j): Fr(Au[i][j]) for i in range(n) for j in range(i + 1, n) if Au[i][j]}
        tf = top_exp(G, B, n); okEn &= tf == pf_elim(A_) - 2 * A_[0][1] * pf_elim(minor); nchg[n] += tf != pf_elim(A_)
    okEn &= nchg[n] >= 1
chk('ctl', okEn, 'fock.P3: the sign of one entry (A_01) changed in the upper triangle only: the top coefficient becomes Pf(A) - 2 A_01 Pf(A without rows and columns 0, 1), different from Pf(A) for %s of the three matrices at n = 2, 4, 6, 8, 10' % '/'.join(str(nchg[n]) for n in (2, 4, 6, 8, 10)))

# ================================================================================================ W. the Witten index
head('W. super-dimension 0 and the index of finite graded complexes Tr (-1)^F e^(-beta H) (fock.W1..W3)')
okSd = all(sum((-1) ** pc(a) for a in range(1 << n)) == 0 for n in range(1, 9))
okSd &= all(all(BR((0,) * n).s(a, a) == (1 if a == 0 else 0) for a in range(1 << n)) for n in range(1, 9))
chk('bit', okSd, 'fock.W1: the super-dimension of Lambda(R^n), the sum over the 2^n labels of BR((0,)*n) (every non-empty label null) of (-1)^|a|, is 0 for n = 1..8 (each mode pairs |0> with |1>; T20 G, cat.B1)')
def wedge_br(n, w):
    G = BR((0,) * n); N = 1 << n; M = [[0] * N for _ in range(N)]
    for b in range(N):
        for i in range(n):
            if w[i]:
                s = G.s(1 << i, b)
                if s: M[b | (1 << i)][b] += s * w[i]
    return M
def wedge_formula(n, w):
    N = 1 << n; M = [[0] * N for _ in range(N)]
    for S in range(N):
        for i in range(n):
            if w[i] and not (S >> i) & 1: M[S | (1 << i)][S] += w[i] * (-1) ** pc(S & ((1 << i) - 1))
    return M
rngW = random.Random(2024); okQ2 = okEu = okDef = okForm = True; okTr = True; okBad = okNos = True; nq = 0; table = {}
for n in range(1, 7):
    deg = [[S for S in range(1 << n) if pc(S) == k] for k in range(n + 1)]
    for wtrial in range(2):
        w = [rngW.randint(-3, 3) for _ in range(n)]
        if not any(w): w[0] = 1
        Lw = wedge_br(n, w); okForm &= Lw == wedge_formula(n, w)
        Lk = [[[Lw[r][c] for c in deg[k]] for r in deg[k + 1]] for k in range(n)]
        def rand_inv(m):
            while True:
                X = [[rngW.randint(-2, 2) for _ in range(m)] for _ in range(m)]
                if f2lib.det_int(X) != 0: return X
        X0 = [rand_inv(len(deg[k])) for k in range(n + 1)]; Y0 = [[[rngW.randint(-1, 1) for _ in range(len(deg[k]))] for _ in range(len(deg[k]))] for k in range(n + 1)]
        for t in (Fr(0), Fr(1, 3), Fr(1), Fr(2)):
            Xt = [[[X0[k][i][j] + t * Y0[k][i][j] for j in range(len(deg[k]))] for i in range(len(deg[k]))] for k in range(n + 1)]
            if any(rank_fr(Xk) < len(Xk) for Xk in Xt): continue
            Xi = [inv_fr(Xk) for Xk in Xt]
            Qk = [mm(mm(Xi[k + 1], Lk[k]), Xt[k]) for k in range(n)]
            okQ2 &= all(not any(v != 0 for r in mm(Qk[k + 1], Qk[k]) for v in r) for k in range(n - 1))
            rk = [rank_fr(q) for q in Qk]
            for K in range(n + 1):
                dims = [len(deg[k]) for k in range(K + 1)]; rkK = rk[:K] + [0]
                h = [dims[k] - rkK[k] - (rkK[k - 1] if k else 0) for k in range(K + 1)]
                sgn = (lambda k: 1) if FAULT == 'NOSIGN' else (lambda k: (-1) ** k)
                eul = sum(sgn(k) * h[k] for k in range(K + 1)); ecc = sum(sgn(k) * dims[k] for k in range(K + 1))
                okEu &= eul == ecc and (FAULT == 'NOSIGN' or eul == (-1) ** K * math.comb(n - 1, K))
                table.setdefault((n, K), set()).add(eul)
                Qf = [np.array(Qk[k], dtype=float) for k in range(K)]
                if FAULT == 'QSQ' and K >= 2: Qf = [q + 0.3 * np.ones_like(q) for q in Qf]
                vals = []
                for beta in (0.05, 0.5, 5.0):
                    T = 0.0
                    for k in range(K + 1):
                        Hk = np.zeros((dims[k], dims[k]))
                        if k > 0: Hk += Qf[k - 1] @ Qf[k - 1].T
                        if k < K: Hk += Qf[k].T @ Qf[k]
                        lam = np.linalg.eigvalsh(Hk); T += sgn(k) * float(np.exp(-beta * lam).sum())
                    vals.append(T)
                okTr &= all(abs(v - float(ecc)) < 1e-7 * max(1, sum(dims)) for v in vals)
                nq += 1
okDef = all(len(v) == 1 for v in table.values())
chk('std', okForm, 'fock.W2: the left multiplication by w in BR((0,)*n) equals the wedge by its formula e_S -> sum_i w_i (-1)^(#S below i) e_(S+i), n = 1..6')
chk('bit', okQ2 and okEu and okDef, 'fock.W2: Q = X^-1 L_w X (X random graded invertible, deformed X + tY for t = 0, 1/3, 1, 2) and its truncations to degrees <= K, n = 1..6 (%d complexes): Q^2 = 0 and, from exact ranks, sum (-1)^k dim H^k = sum (-1)^k dim C^k = (-1)^K C(n-1,K), the same for every X, t and w' % nq)
chk('std', okTr, 'fock.W3: numpy H = Q Q^T + Q^T Q, Tr (-1)^F e^(-beta H) for beta = 0.05, 0.5, 5 equals the exact Euler number in all %d complexes: the index does not depend on beta' % nq)
Qb = [np.array([[1., 2.], [0., 1.]]), np.array([[1., 0.], [1., 1.]])]
def trace_beta(Q, dims, beta, signed=True):
    T = 0.0
    for k in range(len(dims)):
        Hk = np.zeros((dims[k], dims[k]))
        if k > 0: Hk += Q[k - 1] @ Q[k - 1].T
        if k < len(Q): Hk += Q[k].T @ Q[k]
        T += ((-1) ** k if signed else 1) * float(np.exp(-beta * np.linalg.eigvalsh(Hk)).sum())
    return T
v1, v2 = trace_beta(Qb, [2, 2, 2], 0.05), trace_beta(Qb, [2, 2, 2], 5.0)
Lw3 = wedge_br(3, [1, 2, 0]); deg3 = [[S for S in range(8) if pc(S) == k] for k in range(4)]
Q3 = [np.array([[Lw3[r][c] for c in deg3[k]] for r in deg3[k + 1]], dtype=float) for k in range(3)]
u1, u2 = trace_beta(Q3, [1, 3, 3, 1], 0.05, False), trace_beta(Q3, [1, 3, 3, 1], 5.0, False)
chk('ctl', not np.allclose(Qb[1] @ Qb[0], 0) and abs(v1 - v2) > 1e-3, 'fock.W3: a Q with Q^2 != 0 (2 x 2 blocks): Tr (-1)^F e^(-beta H) = %.6f at beta 0.05 and %.6f at beta 5, it depends on beta' % (v1, v2))
chk('ctl', abs(u1 - u2) > 1e-3, 'fock.W3: the weight sum dim in place of sum (-1)^k dim (Q = e_1 + 2 e_2 on Lambda(R^3)): Tr e^(-beta H) = %.6f at beta 0.05 and %.6f at beta 5, it depends on beta (the dimension of the cohomology is 0, of the complex 8)' % (u1, u2))

finish('FOCK' + ('-' + FAULT if FAULT else ''))
