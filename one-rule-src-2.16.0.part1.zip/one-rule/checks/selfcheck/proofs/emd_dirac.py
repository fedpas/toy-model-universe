#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""emd_dirac.py: the Dirac-Hestenes equation of the coupling step in a Coulomb field, and its Weyl halves.
      python3 emd_dirac.py [--fault EXPONENT|ENERGY|REPULSIVE|NODE|NONNULL|SPINOP|GRADEINV|NOI]

Conventions of coupling_selfcheck.py, imported and used as they stand: blades are bit masks of Cl(1,3), bit 0 = time (square +1), bits 1..3
square -1; the product is its bmul; J = gamma_2 gamma_1 (mask 6, sign -1); D(psi; A, e, m) = nabla(psi) J - e A psi - m psi gamma_0.
nabla = sum_mu gamma^mu d/dx^mu (gamma^0 = gamma_0, gamma^k = -gamma_k), which is the package's sum_mu gamma_mu d/dx_mu with x_k = -x^k
(section 0 checks the two agree). sigma_k = gamma_k gamma_0, I = gamma_0 gamma_1 gamma_2 gamma_3, x^ = sum_k (x^k / r) sigma_k. Units hbar = c = 1.

1. emd·COUL.  The Coulomb coupling e A = -(Z alpha / r) gamma_0 (the potential energy e A_0 = -Z alpha / r, attraction).  Closed forms
   psi = R(r) Phi(x) exp(-J E t), R = r^(gamma - 1) exp(-lambda r), gamma = sqrt(1 - Z^2 alpha^2):
     1S1/2  Phi = 1 + ((1 - gamma)/(Z alpha)) x^ J,  lambda = m Z alpha,  E = m gamma (the recalled ground state), at Z alpha = 3/5, 4/5, 5/13
            (gamma = 4/5, 3/5, 12/13);
     2S1/2  Phi = g + f x^ J with g = 1 - (5/4) m r, f = 3/4 - (5/12) m r;   2P1/2  Phi = g x^ I + f sigma_3 with g = 1 + (15/13) m r,
            f = 4/3 - (5/13) m r; both at Z alpha = 24/25 (gamma = 7/25), lambda = 3m/5, E = 4m/5 (the degree-1 radial factors are fixed by the
            radial recursion; the script verifies them).
   m = 3.  [bit] D(psi) = 0 exactly at six rational points with rational r: Phi is carried as exact jets (value and first derivatives,
   Fractions), the factor R by its derivative rule d_k R = R (x^k / r)((gamma - 1)/r - lambda), and exp(-J E t) is a right factor that commutes
   with J and gamma_0, so D(psi) = R [E gamma_0 Phi + nabla(Phi) J + sum_k gamma^k (d_k log R) Phi J - e A Phi - m Phi gamma_0] exp(-J E t).
   The Sommerfeld-Dirac formula E = m [1 + (Z alpha / (n - j - 1/2 + sqrt((j + 1/2)^2 - Z^2 alpha^2)))^2]^(-1/2) (recalled) gives the same
   numbers exactly for (n, j) = (1, 1/2) and (2, 1/2); bound: E < m, lambda^2 = m^2 - E^2, r^(2 gamma) integrable at 0.
   [std] numpy: the textbook radial equations G' = -(kappa/r) G + (E + m - V) F, F' = (kappa/r) F - (E - m - V) G, V = -Z alpha / r, with
   G = r g R, F = -+ r f R (kappa = -+1), derivatives by central differences, at four radii.
2. emd·WEYL.  A = Cl0(1,3) (x) C as pairs a + i b of even multivectors.  omega = i I is central with omega^2 = 1; c+- = (1 +- omega)/2; the
   matrix units c+- E_ij (E_11 = (1 + sigma_3)/2, E_22 = (1 - sigma_3)/2, E_12 = sigma_1 (1 - sigma_3)/2, E_21 = sigma_1 (1 + sigma_3)/2) give
   A = M2(C) + M2(C); the minimal left ideals S+- = A c+- E_11 carry omega = +-1 (inequivalent); parity x -> gamma_0 x gamma_0 is an
   automorphism sending c+ to c- and S+ into the other factor.  On the real Dirac-Hestenes spinor (i = right multiplication by J) the
   chirality of the Atlas, psi -> I psi J (XOR 9), is the action of omega; its eigenspaces W+- are the Weyl halves.  Plane waves
   psi_0 exp(-J k.x) have nabla psi J = p psi, p = sum_mu k_mu gamma_mu (the plane-wave rule of dirac_limits.py): on W+- the Weyl equation
   p psi_0 = 0 has a one-complex-dimensional kernel exactly when p is null, the helicity operator S psi = (1/2) p^ psi sigma_3 (the spin
   operator of dlim·WIG along p^) is -1/2 sign(E) on W+ and +1/2 sign(E) on W-; on the shell p^2 = m^2 != 0 no solution lies in W+ or W-.
   [std] numpy: 2 x 2 Weyl operators sigma.k, sigma-bar.k (det = k^2, kernels, helicity), the 4 x 4 Weyl-basis Dirac operator.
Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL):
   EXPONENT  R = exp(-lambda r) (the Schroedinger exponent);  ENERGY  E = m (1 - Z^2 alpha^2 / 2) (the Bohr energy);  REPULSIVE  e A = +(Z alpha
   / r) gamma_0;  NODE  2S with g = 1 - m r;  NONNULL  a time-like p in the Weyl line;  SPINOP  (1/2) p^ psi without sigma_3;  GRADEINV  the grade
   involution in place of parity;  NOI  (1 + I)/2 in place of (1 + i I)/2.
Scope: Cl(1,3); six rational points per state, three plus two states; Weyl: seven null momenta (one of negative energy), five on-shell
momenta; exact Fractions on [bit], floats with the tolerances printed on [std].  The script builds no object of the gravity engine (Forms,
Lie, Grav): the engine faults M1-M8 do not reach it; its controls are its own.
Command: python3 emd_dirac.py   (from this folder, or python3 selfcheck/proofs/emd_dirac.py from the package root; numpy)."""
import os, sys, math, random
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
for _p, _f in ((_selfcheck, 'coupling_selfcheck.py'),):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    if _p not in sys.path: sys.path.insert(0, _p)
import coupling_selfcheck as cs

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('EXPONENT', 'ENERGY', 'REPULSIVE', 'NODE', 'NONNULL', 'SPINOP', 'GRADEINV', 'NOI')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

# ------------------------------------------------------------------------------------------------ exact jets and multivectors
class Jet:
    """a value and its first derivatives d/dx^mu (mu = 0..3), exact Fractions"""
    __slots__ = ('v', 'd')
    def __init__(s, v, d): s.v = Fr(v); s.d = tuple(Fr(x) for x in d)
    def _l(s, o): return o if isinstance(o, Jet) else Jet(o, (0,) * len(s.d))
    def __add__(s, o): o = s._l(o); return Jet(s.v + o.v, [a + b for a, b in zip(s.d, o.d)])
    __radd__ = __add__
    def __neg__(s): return Jet(-s.v, [-a for a in s.d])
    def __sub__(s, o): return s + (-s._l(o))
    def __rsub__(s, o): return s._l(o) + (-s)
    def __mul__(s, o):
        if isinstance(o, Jet): return Jet(s.v * o.v, [s.v * b + o.v * a for a, b in zip(s.d, o.d)])
        return Jet(s.v * o, [a * o for a in s.d])
    __rmul__ = __mul__
    def __truediv__(s, o):
        if isinstance(o, Jet): return s * Jet(1 / o.v, [-a / o.v ** 2 for a in o.d])
        return Jet(s.v / o, [a / o for a in s.d])
SQ = cs.sqs(4)
def isz(v): return (v.v == 0 and all(a == 0 for a in v.d)) if isinstance(v, Jet) else v == 0
def mul(a, b, sq=SQ):
    r = {}
    for x, cx in a.items():
        for y, cy in b.items():
            m, s = cs.bmul(x, y, sq); r[m] = r.get(m, 0) + s * cx * cy
    return {k: v for k, v in r.items() if not isz(v)}
def add(*ts):
    r = {}
    for t in ts:
        for k, v in t.items(): r[k] = r.get(k, 0) + v
    return {k: v for k, v in r.items() if not isz(v)}
def sc(a, c): return {k: v * c for k, v in a.items() if not isz(v * c)}
def val(a): return {k: (v.v if isinstance(v, Jet) else Fr(v)) for k, v in a.items() if not isz(v.v if isinstance(v, Jet) else v)}
def der(a, mu): return {k: v.d[mu] for k, v in a.items() if isinstance(v, Jet) and v.d[mu] != 0}
def grade(a, k): return {m: v for m, v in a.items() if bin(m).count('1') == k}
def rev(a): return {m: cs.rsign(bin(m).count('1')) * v for m, v in a.items()}
G0 = {1: Fr(1)}; JM = {6: Fr(-1)}; I4 = {15: Fr(1)}; ONE = {0: Fr(1)}
SIG = [None] + [mul({1 << k: Fr(1)}, G0) for k in (1, 2, 3)]               # sigma_k = gamma_k gamma_0
GUP = [{1: Fr(1)}, {2: Fr(-1)}, {4: Fr(-1)}, {8: Fr(-1)}]                 # gamma^mu
def nabla_jet(Phi): return add(*[mul(GUP[mu], der(Phi, mu)) for mu in range(4)])
def fsqrt(q):
    q = Fr(q); a, b = math.isqrt(q.numerator), math.isqrt(q.denominator)
    return Fr(a, b) if q >= 0 and a * a == q.numerator and b * b == q.denominator else None
def rank_rows(vecs, keys):
    M = [[Fr(v.get(k, 0)) for k in keys] for v in vecs]; rk = 0; col = 0
    while rk < len(M) and col < len(keys):
        p = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if p is None: col += 1; continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][col]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        rk += 1; col += 1
    return rk
def det_fr(M):
    M = [[Fr(x) for x in r] for r in M]; n = len(M); d = Fr(1)
    for c in range(n):
        p = next((i for i in range(c, n) if M[i][c] != 0), None)
        if p is None: return Fr(0)
        if p != c: M[c], M[p] = M[p], M[c]; d = -d
        d *= M[c][c]
        for i in range(c + 1, n):
            f = M[i][c] / M[c][c]; M[i] = [x - f * y for x, y in zip(M[i], M[c])]
    return d
EV = [m for m in range(16) if bin(m).count('1') % 2 == 0]; OD = [m for m in range(16) if bin(m).count('1') % 2 == 1]

# ================================================================================================ 0. the derivative of the jets is the package's nabla
head('0. The jet derivative sum_mu gamma^mu d/dx^mu equals coupling_selfcheck.nabla (variables x_mu, x_k = -x^k) [bit]')
ok0 = True
for sd in range(3):
    rg = random.Random(300 + sd); P = {S: cs.rpoly(rg, 4, 2, .5) for S in EV}
    NP = cs.nabla(P, SQ)
    for pt in ((Fr(1, 2), Fr(1), Fr(-2), Fr(3)), (Fr(-1), Fr(2, 3), Fr(1, 5), Fr(-1, 2))):
        low = [Jet(pt[0], (1, 0, 0, 0))] + [-Jet(pt[k], [1 if i == k else 0 for i in range(4)]) for k in (1, 2, 3)]
        def ev(poly, xs):
            s = Jet(0, (0,) * 4)
            for e, c in poly.items():
                t = Jet(c, (0,) * 4)
                for i, k in enumerate(e):
                    for _ in range(k): t = t * xs[i]
                s = s + t
            return s
        Pj = {S: ev(p, low) for S, p in P.items()}
        lowv = [x.v for x in low]
        NPv = {S: sum((c * math.prod(lowv[i] ** k for i, k in enumerate(e)) for e, c in p.items()), Fr(0)) for S, p in NP.items()}
        ok0 &= add(val(nabla_jet(Pj)), sc({k: v for k, v in NPv.items() if v}, -1)) == {}
chk('bit', ok0, 'three random even polynomial fields (degree 2) at two rational points: the jet nabla equals coupling_selfcheck.nabla exactly')

# ================================================================================================ 1. emd·COUL
head('1. emd·COUL: closed bound states of the Coulomb problem on the labels [bit]; textbook radial equations [std]')
m = Fr(3)
PTS = [(1, 2, 2), (2, -3, 6), (Fr(-1, 2), 2, 4), (Fr(4, 3), Fr(4, 3), Fr(-7, 3)), (Fr(2, 5), Fr(6, 5), Fr(9, 5)), (Fr(-6, 7), Fr(-2, 7), Fr(3, 7))]
chk('bit', mul(G0, JM) == mul(JM, G0) and mul(JM, JM) == {0: Fr(-1)}, 'J^2 = -1 and J commutes with gamma_0: exp(-J E t) is a right factor of every term of D, so D(psi) = 0 iff the bracket vanishes')
def residual(phi_of, gam, lam, E, eZa, pt, faultexp=False):
    x, y, z = [Fr(c) for c in pt]; rr = fsqrt(x * x + y * y + z * z)
    X = [None, Jet(x, (0, 1, 0, 0)), Jet(y, (0, 0, 1, 0)), Jet(z, (0, 0, 0, 1))]
    r = Jet(rr, (0, x / rr, y / rr, z / rr))
    xh = add(*[sc(SIG[k], X[k] / r) for k in (1, 2, 3)])
    Phi = phi_of(r, xh); P = val(Phi)
    expo = Fr(0) if faultexp else gam - 1
    L = [Fr(0)] + [(Fr(pt[k - 1]) / rr) * (expo / rr - lam) for k in (1, 2, 3)]
    t_time = sc(mul(G0, P), E)                                               # gamma_0 Phi (-J E) J = E gamma_0 Phi
    t_der = mul(add(nabla_jet(Phi), *[sc(mul(GUP[k], P), L[k]) for k in (1, 2, 3)]), JM)
    t_pot = sc(mul({1: eZa / rr}, P), 1)                                    # - e A Phi with e A = -(Z alpha / r) gamma_0
    t_mass = sc(mul(P, G0), -m)
    return add(t_time, t_der, t_pot, t_mass), rr
def states():
    out = []
    for Za, gam in ((Fr(3, 5), Fr(4, 5)), (Fr(4, 5), Fr(3, 5)), (Fr(5, 13), Fr(12, 13))):
        c = (1 - gam) / Za
        out.append(('1S1/2', Za, gam, m * Za, m * gam, lambda r, xh, c=c: add({0: Jet(1, (0,) * 4)}, sc(mul(xh, JM), c)), -1, (lambda r: 1 + 0 * r, lambda r, c=c: c + 0 * r)))
    Za, gam = Fr(24, 25), Fr(7, 25); E2 = m * Fr(4, 5); l2 = m * Fr(3, 5)
    g2S = (lambda r: 1 - m * r) if FAULT == 'NODE' else (lambda r: 1 - Fr(5, 4) * m * r)
    f2S = lambda r: Fr(3, 4) - Fr(5, 12) * m * r
    out.append(('2S1/2', Za, gam, l2, E2, lambda r, xh: add({0: g2S(r)}, sc(mul(xh, JM), f2S(r))), -1, (g2S, f2S)))
    g2P = lambda r: 1 + Fr(15, 13) * m * r; f2P = lambda r: Fr(4, 3) - Fr(5, 13) * m * r
    out.append(('2P1/2', Za, gam, l2, E2, lambda r, xh: add(sc(mul(xh, I4), g2P(r)), sc(SIG[3], f2P(r))), 1, (g2P, f2P)))
    return out
STATES = states()
for name, Za, gam, lam, E, phi, kappa, gf in STATES:
    chk('bit', gam * gam + Za * Za == 1 and 0 < gam < 1, '%s Z alpha = %s: gamma = %s, gamma^2 + Z^2 alpha^2 = 1 (exact)' % (name, Za, gam))
    Eu = m * (1 - Za * Za / 2) if FAULT == 'ENERGY' else E
    eZa = -Za if FAULT == 'REPULSIVE' else Za
    res = [residual(phi, gam, lam, Eu, eZa, p, FAULT == 'EXPONENT') for p in PTS]
    chk('bit', all(R_ == {} for R_, _ in res), '%s, Z alpha = %s, m = %s: D(psi) = 0 exactly at the 6 rational points (r = %s), E = %s, lambda = %s, exponent gamma - 1 = %s'
        % (name, Za, m, ', '.join(str(r_) for _, r_ in res), Eu, lam, gam - 1))
    chk('bit', E < m and lam * lam == m * m - E * E and 2 * gam > -1 and lam > 0, '%s: bound, E = %s < m, lambda^2 = m^2 - E^2 = %s, |psi|^2 r^2 ~ r^(2 gamma) e^(-2 lambda r) integrable' % (name, E, lam * lam))
    if name == '1S1/2':
        wrongE = [residual(phi, gam, lam, m * (1 - Za * Za / 2), Za, p)[0] for p in PTS]
        wrongX = [residual(phi, gam, lam, E, Za, p, True)[0] for p in PTS]
        wrongS = [residual(phi, gam, lam, E, -Za, p)[0] for p in PTS]
        chk('ctl', all(w != {} for w in wrongE + wrongX + wrongS), '%s Z alpha = %s: the Bohr energy m(1 - Z^2 alpha^2/2) = %s, the exponent 0 and the repulsive sign each leave D(psi) != 0 at all 6 points' % (name, Za, m * (1 - Za * Za / 2)))
r2S = STATES[3]
wrongN = [residual(lambda r, xh: add({0: 1 - m * r}, sc(mul(xh, JM), Fr(3, 4) - Fr(5, 12) * m * r)), r2S[2], r2S[3], r2S[4], r2S[1], p)[0] for p in PTS]
chk('ctl', all(w != {} for w in wrongN), '2S1/2: a wrong node, g = 1 - m r in place of 1 - (5/4) m r, leaves D(psi) != 0 at all 6 points')
def sommerfeld(n, j, Za):
    root = fsqrt((j + Fr(1, 2)) ** 2 - Za * Za); den = n - j - Fr(1, 2) + root
    q = fsqrt(1 + (Za / den) ** 2)
    return m / q if root is not None and q is not None else None
okS = []
for name, Za, gam, lam, E, phi, kappa, gf in STATES:
    n_ = 1 if name.startswith('1') else 2; Es = sommerfeld(n_, Fr(1, 2), Za); okS.append((name, Za, Es, Es == E))
chk('bit', all(o for *_, o in okS), 'the Sommerfeld-Dirac formula (recalled), exact at the rational data: ' + '; '.join('%s Z alpha = %s: E = %s' % (n_, Za, Es) for n_, Za, Es, _ in okS) + ' = the energies of the closed forms')
chk('bit', STATES[3][4] == STATES[4][4] and STATES[3][6] == -STATES[4][6], '2S1/2 (kappa = -1) and 2P1/2 (kappa = +1) have the same E = 4m/5: the energy depends on n and j only')
# std: textbook radial equations
def radial_res(gfun, ffun, kappa, Za, gam, lam, E, rr):
    sgn = -1.0 if kappa == -1 else 1.0
    def G(r): return r * gfun(r) * r ** (gam - 1) * np.exp(-lam * r)
    def F(r): return sgn * r * ffun(r) * r ** (gam - 1) * np.exp(-lam * r)
    h = 1e-6 * rr; Gp = (G(rr + h) - G(rr - h)) / (2 * h); Fp = (F(rr + h) - F(rr - h)) / (2 * h); V = -Za / rr
    e1 = Gp - (-kappa / rr * G(rr) + (E + mf - V) * F(rr))
    e2 = Fp - (kappa / rr * F(rr) - (E - mf - V) * G(rr))
    scale = max(abs(Gp), abs(Fp), abs(G(rr)) / rr, abs(F(rr)) / rr)
    return max(abs(e1), abs(e2)) / scale
mf = float(m); RADII = (0.3, 0.8, 1.7, 4.2)
okR = True; worst = 0.0; badE = []
for name, Za, gam, lam, E, phi, kappa, (gfun, ffun) in STATES:
    gF = lambda r, g_=gfun: float(g_(r)); fF = lambda r, f_=ffun: float(f_(r))
    for rr in RADII:
        e = radial_res(gF, fF, kappa, float(Za), float(gam), float(lam), float(E), rr); worst = max(worst, e); okR &= e < 1e-7
    badE.append(max(radial_res(gF, fF, kappa, float(Za), float(gam), float(lam), float(E) * 1.01, rr) for rr in RADII))
chk('std', okR, 'textbook radial equations (kappa = -1 for 1S, 2S, +1 for 2P; G = r g R, F = -+ r f R), central differences h = 1e-6 r at r = %s: largest relative residual %.1e < 1e-7' % (RADII, worst))
chk('ctl', min(badE) > 1e-4, 'std: the energy 1 percent off leaves a relative residual of at least %.1e in the radial equations' % min(badE))
somf = [float(m) / np.sqrt(1 + (float(Za) / (n_ - 0.5 - 0.5 + np.sqrt(1 - float(Za) ** 2))) ** 2) for n_, Za in ((1, Fr(3, 5)), (1, Fr(4, 5)), (1, Fr(5, 13)), (2, Fr(24, 25)))]
chk('bit==std', all(abs(a - float(s[4])) < 1e-12 for a, s in zip(somf + [somf[-1]], STATES)), 'the same closed forms solve the labels equation exactly and the textbook radial equations numerically; the Sommerfeld formula in floats gives %s' % ', '.join('%.12f' % a for a in somf))

# ================================================================================================ 2. emd·WEYL
head('2. emd·WEYL: Cl0(1,3) (x) C = M2(C) + M2(C), the two Weyl modules, parity, helicity, the mass term [bit]; 2 x 2 Weyl operators [std]')
def cmul(X, Y): return (add(mul(X[0], Y[0]), sc(mul(X[1], Y[1]), -1)), add(mul(X[0], Y[1]), mul(X[1], Y[0])))
def cadd(X, Y, c=1): return (add(X[0], sc(Y[0], c)), add(X[1], sc(Y[1], c)))
def ceq(X, Y): return add(X[0], sc(Y[0], -1)) == {} and add(X[1], sc(Y[1], -1)) == {}
def cflat(X): return {(0, k): v for k, v in X[0].items()} | {(1, k): v for k, v in X[1].items()}
CK = [(i, k) for i in (0, 1) for k in EV]
R1 = lambda a: (a, {}); IM = lambda a: ({}, a)
omega = IM(I4); half = Fr(1, 2)
cp = (sc(ONE, half), sc(I4, half)); cmn = (sc(ONE, half), sc(I4, -half))
if FAULT == 'NOI': cp = (add(sc(ONE, half), sc(I4, half)), {}); cmn = (add(sc(ONE, half), sc(I4, -half)), {})
chk('bit', ceq(cmul(omega, omega), R1(ONE)) and all(ceq(cmul(omega, R1({b: Fr(1)})), cmul(R1({b: Fr(1)}), omega)) for b in EV), 'omega = i I squares to +1 and commutes with the 8 even labels: central')
chk('bit', ceq(cmul(cp, cp), cp) and ceq(cmul(cmn, cmn), cmn) and ceq(cmul(cp, cmn), ({}, {})) and ceq(cadd(cp, cmn), R1(ONE)),
    'c+- = (1 +- i I)/2: idempotent, orthogonal, c+ + c- = 1 (two central idempotents)')
ctl_noi = (add(sc(ONE, half), sc(I4, half)), {})
chk('ctl', not ceq(cmul(ctl_noi, ctl_noi), ctl_noi), '(1 + I)/2 without the i is not idempotent: its square is %s' % cmul(ctl_noi, ctl_noi)[0])
Eu = {(1, 1): add(sc(ONE, half), sc(SIG[3], half)), (2, 2): add(sc(ONE, half), sc(SIG[3], -half)),
      (1, 2): mul(SIG[1], add(sc(ONE, half), sc(SIG[3], -half))), (2, 1): mul(SIG[1], add(sc(ONE, half), sc(SIG[3], half)))}
okU = all(mul(Eu[(i, j)], Eu[(k, l)]) == (Eu[(i, l)] if j == k else {}) for i in (1, 2) for j in (1, 2) for k in (1, 2) for l in (1, 2)) and add(Eu[(1, 1)], Eu[(2, 2)]) == ONE
dims = []
for c_ in (cp, cmn):
    units = [cmul(c_, R1(Eu[ij])) for ij in sorted(Eu)]
    span = units + [cmul(IM(ONE), u) for u in units]
    whole = [cmul(c_, R1({b: Fr(1)})) for b in EV] + [cmul(c_, IM({b: Fr(1)})) for b in EV]
    dims.append((rank_rows([cflat(u) for u in span], CK), rank_rows([cflat(u) for u in whole], CK), rank_rows([cflat(u) for u in span + whole], CK)))
chk('bit', okU and all(d == (8, 8, 8) for d in dims), 'matrix units E_ij of Cl0(1,3): E_ij E_kl = delta_jk E_il (16 products), E_11 + E_22 = 1; c+- E_ij span c+- A (real ranks %s): c+ A = c- A = M2(C), A = M2(C) + M2(C) (complex dimension 4 + 4)' % dims)
ep = cmul(cp, R1(Eu[(1, 1)])); em = cmul(cmn, R1(Eu[(1, 1)]))
def ideal_rank(e_): return rank_rows([cflat(cmul(R1({b: Fr(1)}), e_)) for b in EV] + [cflat(cmul(IM({b: Fr(1)}), e_)) for b in EV], CK)
def corner_rank(e_): return rank_rows([cflat(cmul(cmul(e_, R1({b: Fr(1)})), e_)) for b in EV] + [cflat(cmul(cmul(e_, IM({b: Fr(1)})), e_)) for b in EV], CK)
chk('bit', (ideal_rank(ep), ideal_rank(em), corner_rank(ep), corner_rank(em)) == (4, 4, 2, 2), 'S+- = A c+- E_11: real dimension 4 (complex 2) each; e A e has real dimension 2 (complex 1): primitive, S+- irreducible')
chk('bit', ceq(cmul(omega, ep), ep) and ceq(cmul(omega, em), cadd(({}, {}), em, -1)), 'omega e+ = e+ and omega e- = -e-: the central omega acts as +1 on S+ and -1 on S-, so no module map intertwines them (inequivalent)')
def par(x): return mul(mul(G0, x), G0)
PAR = (lambda x: x) if FAULT == 'GRADEINV' else par
def cpar(X): return (PAR(X[0]), PAR(X[1]))
okA = all(par(mul({a: Fr(1)}, {b: Fr(1)})) == mul(par({a: Fr(1)}), par({b: Fr(1)})) for a in EV for b in EV)
pe = cpar(ep); pe_target = cmul(cmn, R1(Eu[(2, 2)]))
chk('bit', okA and PAR(I4) == sc(I4, -1) and ceq(cpar(cp), cmn) and ceq(pe, pe_target) and ceq(cmul(omega, pe), cadd(({}, {}), pe, -1)),
    'parity x -> gamma_0 x gamma_0: an automorphism of Cl0(1,3) (64 label products), I -> -I, c+ -> c-, e+ -> c- E_22 (primitive in the other factor): S+ goes to a minimal left ideal with omega = -1')
def ghat(x): return {k: v * (1 if bin(k).count('1') % 2 == 0 else -1) for k, v in x.items()}
chk('ctl', ghat(I4) == I4 and not ceq((ghat(cp[0]), ghat(cp[1])), cmn), 'the grade involution in place of parity fixes I and sends c+ to c+, not to c-: it exchanges nothing')
# the real Dirac-Hestenes spinor with i = right J and the chirality of the Atlas
IJ = mul(I4, JM)
def Gam(x): return mul(mul(I4, x), JM)
okG = all(Gam(Gam({b: Fr(1)})) == {b: Fr(1)} and set(Gam({b: Fr(1)})) == {b ^ 9} for b in range(16)) and all(Gam({b: Fr(1)}) == mul({b: Fr(1)}, IJ) for b in EV)
chk('bit', okG and IJ == {9: Fr(1)}, 'psi -> I psi J (the chirality of SPN-003, spin_selfcheck E1) is an involution, XOR 9 on every label, and on even psi it is right multiplication by I J = gamma_0 gamma_3')
def proj(s): return [add(sc({b: Fr(1)}, half), sc(Gam({b: Fr(1)}), s * half)) for b in EV]
def basis(vs, keys):
    out = []
    for v in vs:
        if v and rank_rows(out + [v], keys) > len(out): out.append(v)
    return out
Wp, Wm = basis(proj(1), EV), basis(proj(-1), EV)
okIJ = all(mul(I4, w) == sc(mul(w, JM), -1) for w in Wp) and all(mul(I4, w) == mul(w, JM) for w in Wm) and all(Gam(mul(w, JM)) == mul(Gam(w), JM) for w in Wp + Wm)
chk('bit', len(Wp) == 4 and len(Wm) == 4 and okIJ, 'W+- = the +-1 eigenspaces of psi -> I psi J: real dimension 4 + 4, preserved by i = right J; on W+ left I acts as -i and on W- as +i, so omega = i I acts as I psi J = +-1: W+- are the two modules')
chk('bit', Gam(par(Wp[0])) == sc(par(Wp[0]), -1) and all(Gam(par(w)) == sc(par(w), -1) for w in Wp), 'parity sends W+ onto W- (gamma_0 W+ gamma_0 has chirality -1 on the 4 basis spinors)')
# plane waves
NULL = [(3, 1, 2, 2), (7, 2, 3, 6), (9, 1, 4, 8), (9, 4, 4, 7), (11, 2, 6, 9), (5, 0, 3, 4), (-3, 1, 2, 2)]
TIMELIKE = (5, 0, 0, 3)
def pvec(k): return add({1: Fr(k[0])}, *[{1 << j: Fr(k[j])} for j in (1, 2, 3)])
def kernel(maps_of, B):
    """basis of the kernel of the linear map on span(B) (exact), maps_of(x) a multivector"""
    imgs = [maps_of(b) for b in B]; keys = sorted({k for i in imgs for k in i} | {0})
    n_ = len(B); rows = [[Fr(img.get(k, 0)) for img in imgs] for k in keys]
    R_, piv = [], []
    M = [r[:] for r in rows]; rk = 0
    for c in range(n_):
        p = next((i for i in range(rk, len(M)) if M[i][c] != 0), None)
        if p is None: continue
        M[rk], M[p] = M[p], M[rk]; inv = 1 / M[rk][c]; M[rk] = [x * inv for x in M[rk]]
        for i in range(len(M)):
            if i != rk and M[i][c] != 0:
                f = M[i][c]; M[i] = [x - f * y for x, y in zip(M[i], M[rk])]
        piv.append(c); rk += 1
    out = []
    for fc in [c for c in range(n_) if c not in piv]:
        v = [Fr(0)] * n_; v[fc] = Fr(1)
        for i, p in enumerate(piv): v[p] = -M[i][fc]
        out.append(add(*[sc(B[i], v[i]) for i in range(n_) if v[i]]))
    return out
def Sop(ph, x):
    return sc(mul(ph, x), half) if FAULT == 'SPINOP' else sc(mul(mul(ph, x), SIG[3]), half)
hel = {}; okK = True; dets = []
for k in NULL:
    kk = TIMELIKE if FAULT == 'NONNULL' else k
    p = pvec(kk); pn = fsqrt(sum(Fr(x) ** 2 for x in kk[1:]))
    ph = add(*[sc(SIG[j], Fr(kk[j]) / pn) for j in (1, 2, 3)])
    for nm, W in (('W+', Wp), ('W-', Wm)):
        K = kernel(lambda x: mul(p, x), W)
        okK &= len(K) == 2
        hs = set()
        for v in K:
            Sv = Sop(ph, v)
            hs |= {h for h in (half, -half) if Sv == sc(v, h)}
            if not any(Sv == sc(v, h) for h in (half, -half)): hs.add(None)
        hel[(k, nm)] = hs
chk('bit', okK, 'Weyl equation p psi_0 = 0 on W+ and on W-: a kernel of real dimension 2 (one complex line, i = right J) at the %d null momenta %s' % (len(NULL), NULL))
sgnE = {k: (1 if k[0] > 0 else -1) for k in NULL}
okH = all(hel[(k, 'W+')] == {-half * sgnE[k]} and hel[(k, 'W-')] == {half * sgnE[k]} for k in NULL)
chk('bit', okH, 'helicity: S psi = (1/2) p^ psi sigma_3 on the kernel is -1/2 sign(E) on W+ and +1/2 sign(E) on W- at every null momentum (exact eigenvalues): W+ is left-handed, W- right-handed')
okT = all(len(kernel(lambda x, p=pvec(TIMELIKE): mul(p, x), W)) == 0 for W in (Wp, Wm)) and len(kernel(lambda x, p=pvec((5, 0, 3, 3)): mul(p, x), Wp)) == 0
chk('ctl', okT, 'off the cone (p = (5; 0, 0, 3) time-like, (5; 0, 3, 3) space-like) the Weyl kernel on W+- is zero')
wrongS = all({h for v in kernel(lambda x, p=pvec(k): mul(p, x), W) for h in (half, -half) if sc(mul(add(*[sc(SIG[j], Fr(k[j]) / fsqrt(sum(Fr(x) ** 2 for x in k[1:]))) for j in (1, 2, 3)]), v), half) == sc(v, h)} == {half * sgnE[k]} for k in NULL for W in (Wp, Wm))
chk('ctl', wrongS, 'a wrong spin operator, (1/2) p^ psi without sigma_3 on the right, gives the same +1/2 sign(E) on W+ and W-: it does not see the chirality')
Wodd_m = basis([add(sc({b: Fr(1)}, half), sc(Gam({b: Fr(1)}), -half)) for b in OD], OD)
okIm = True
for k in NULL + [TIMELIKE, (7, 1, 2, 3), (2, 3, 1, 1)]:
    p = pvec(k); q2 = Fr(k[0]) ** 2 - sum(Fr(x) ** 2 for x in k[1:])
    imgs = [mul(p, w) for w in Wp]
    okIm &= all(Gam(i_) == sc(i_, -1) for i_ in imgs)
    coords = []
    for i_ in imgs:
        A_ = [[Fr(b_.get(o, 0)) for b_ in Wodd_m] for o in OD]; rhs = [Fr(i_.get(o, 0)) for o in OD]
        aug = [A_[r_] + [rhs[r_]] for r_ in range(len(OD))]
        rk = 0; piv = []
        for c in range(4):
            pp = next((i for i in range(rk, len(aug)) if aug[i][c] != 0), None)
            if pp is None: continue
            aug[rk], aug[pp] = aug[pp], aug[rk]; inv = 1 / aug[rk][c]; aug[rk] = [x * inv for x in aug[rk]]
            for i in range(len(aug)):
                if i != rk and aug[i][c] != 0:
                    f = aug[i][c]; aug[i] = [x - f * y for x, y in zip(aug[i], aug[rk])]
            piv.append(c); rk += 1
        coords.append([aug[piv.index(c)][4] if c in piv else Fr(0) for c in range(4)])
    dets.append((k, det_fr([[coords[c][r_] for c in range(4)] for r_ in range(4)]), q2 * q2))
cst = {d / q4 for _, d, q4 in dets if q4}
chk('bit', okIm and len(cst) == 1 and abs(list(cst)[0]) == 1 and all(d == 0 for _, d, q4 in dets if q4 == 0),
    'the map W+ -> odd part of chirality -1, psi_0 -> p psi_0, has determinant %s (p^2)^2 at %d momenta (zero exactly on the null ones)' % (list(cst)[0], len(dets)))
SHELL = [(5, 3, 0, 0, 4), (3, 2, 1, 0, 2), (13, 3, 4, 0, 12), (11, 2, 6, 0, 9), (-5, 0, 3, 0, 4)]
okM = True; dimsM = []
for E_, a, b_, c, mm in SHELL:
    p = pvec((E_, a, b_, c)); mm = Fr(mm)
    full = kernel(lambda x: add(mul(p, x), sc(mul(x, G0), -mm)), [{b: Fr(1)} for b in EV])
    kp = kernel(lambda x: add(mul(p, x), sc(mul(x, G0), -mm)), Wp); km = kernel(lambda x: add(mul(p, x), sc(mul(x, G0), -mm)), Wm)
    keep = all(Gam(mul(w, G0)) == mul(w, G0) for w in Wp) and all(Gam(mul(p, w)) == sc(mul(p, w), -1) for w in Wp)
    okM &= len(full) == 4 and len(kp) == 0 and len(km) == 0 and keep; dimsM.append((len(full), len(kp), len(km)))
chk('bit', okM, 'mass term: at the 5 on-shell momenta (E, p, m) %s the solutions of p psi_0 = m psi_0 gamma_0 have real dimension 4 on Cl0(1,3) and 0 on W+ and on W- (%s); psi gamma_0 keeps the chirality and p psi flips it, so the mass couples W+ to W-'
    % (SHELL, dimsM))
# std: 2 x 2 Weyl operators
s0 = np.eye(2, dtype=complex); sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.array([[1, 0], [0, -1]], dtype=complex)
SV = [sx, sy, sz]
def sig_dot(k):  return k[0] * s0 - sum(k[j + 1] * SV[j] for j in range(3))      # sigma^mu k_mu, k_mu = (k0, -k)
def sigb_dot(k): return k[0] * s0 + sum(k[j + 1] * SV[j] for j in range(3))      # sigma-bar^mu k_mu
rs = np.random.default_rng(17); ks = [tuple(int(x) for x in rs.integers(-6, 7, 4)) for _ in range(10)] + NULL
okd = all(abs(np.linalg.det(sig_dot(k)) - (k[0] ** 2 - sum(x * x for x in k[1:]))) < 1e-9 and abs(np.linalg.det(sigb_dot(k)) - (k[0] ** 2 - sum(x * x for x in k[1:]))) < 1e-9 for k in ks)
chk('std', okd, 'det(sigma.k) = det(sigma-bar.k) = k^2 for 10 random integer k (seed 17) and the 7 null momenta (tolerance 1e-9)')
def kern(M_, tol=1e-9):
    u, s, vh = np.linalg.svd(M_); return [vh[i].conj() for i in range(len(s)) if s[i] < tol] + [vh[i].conj() for i in range(len(s), M_.shape[1])]
hstd = {}
for k in NULL:
    n_ = np.array(k[1:], float) / np.linalg.norm(k[1:]); hop = 0.5 * sum(n_[j] * SV[j] for j in range(3))
    for nm, M_ in (('L', sigb_dot(k)), ('R', sig_dot(k))):
        K = kern(M_); hstd[(k, nm)] = (len(K), [float(np.real(np.vdot(v, hop @ v))) for v in K])
okh = all(hstd[(k, 'L')][0] == 1 and hstd[(k, 'R')][0] == 1 and abs(hstd[(k, 'L')][1][0] + 0.5 * sgnE[k]) < 1e-9 and abs(hstd[(k, 'R')][1][0] - 0.5 * sgnE[k]) < 1e-9 for k in NULL)
chk('std', okh, 'sigma-bar.p psi_L = 0 and sigma.p psi_R = 0 at the 7 null momenta: one-dimensional kernels, helicity (1/2) sigma.p^ = -1/2 sign(E) (L) and +1/2 sign(E) (R) (SVD, tolerance 1e-9)')
okm = True
for E_, a, b_, c, mm in SHELL:
    k = (E_, a, b_, c); Dw = np.block([[-mm * s0, sig_dot(k)], [sigb_dot(k), -mm * s0]]); K = kern(Dw)
    okm &= len(K) == 2 and np.linalg.matrix_rank(np.array([v[:2] for v in K]), tol=1e-9) == 2 and np.linalg.matrix_rank(np.array([v[2:] for v in K]), tol=1e-9) == 2
chk('std', okm, 'Weyl-basis Dirac operator [[-m, sigma.p], [sigma-bar.p, -m]] at the 5 on-shell momenta: kernel 2, and both chiral blocks of the kernel have rank 2: no solution with psi_L = 0 or psi_R = 0')
chk('bit==std', okK and okH and okh and okM and okm and okd, 'labels and 2 x 2 matrices agree: one complex line per chirality on the cone, W+ <-> left (helicity -1/2 sign(E)), W- <-> right (+1/2 sign(E)), |det|^2 = (k^2)^2, no chiral solution with m != 0')

finish('EMD-DIRAC')
