#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""solid_cube.py: the solid-state corner of the bit rule: Kramers degeneracy and the three types of commutant, the charge of a grading
and the Hubbard model, the symmetry algebras of the ten Altland-Zirnbauer classes against the clock, Wilson's plaquette, and the
double groups of Bethe.      python3 solid_cube.py [--fault NAME]

K. Kramers and Dyson (solid.K1 .. K6).  For every Cl(p,q) with p + q <= 7 (36 cells) the commutant of the minimal module is R, C or H
   as the clock p - q mod 8 says (R at 0, 1, 2; C at 3, 7; H at 4, 5, 6), and the number of simple summands is 2 exactly at the clock
   values 1 and 5.  On the H cells the commutant holds i, j with i^2 = j^2 = -1, ij = -ji (an antilinear j with j^2 = -1: an antiunitary
   T with T^2 = -1), and for 20 random integer elements of the algebra, symmetrised, every eigenvalue has multiplicity exactly 4 over R
   (2 over C: a Kramers pair; random coefficients in -50..50); on the R and C cells the multiplicity is exactly 1 and 2 over R (one over C: no
   Kramers pair).  The
   level-repulsion exponent and the random-matrix statistics are not checked.
   [bit]  the bit rule (steps15_17/bitcliff.py): a maximal set of commuting blades of square +1, f = prod (1 + e_a)/2, the left ideal
          A f with basis e_r f (signed permutation matrices, checked against the left-multiplication matrices of the regular module),
          the commutant as the exact sign-consistent components of the equations X rho(e_i) = rho(e_i) X, its structure constants,
          i and j found by exact search, multiplicities from the exact rank of a Krylov space.
   [std]  numpy: real Kronecker words of I, sigma_x, sigma_z, i sigma_y for Cl(3,0), Cl(0,3), Cl(2,0), Cl(0,4), commutant by SVD,
          eigvalsh multiplicities; the Frobenius-Schur sum d = 2 - (dim U / 2^n)(N+ - N-) (textbook, recalled) for all 36 cells.
   [ctl]  NONMIN (an ideal from a non-maximal idempotent is not irreducible), CLOCK (the mirror clock disagrees), KRAM (multiplicity
          at least 2 required on every cell fails on the R cells), FS (wrong sign of the Frobenius-Schur sum).
H. The grading and the Hubbard model (solid.H1 .. H6).  In Cl(n,n) = End Lambda (n = 2 .. 6, Witt pairs a_i = (g_i - g_{n+i})/2) the
   operators N = sum a+_i a_i and P = (-1)^N = prod (1 - 2 n_i): H = sum T_ij a+_i a_j + sum V_ij n_i n_j commutes with N and P exactly;
   a pairing term D = sum Delta_ij (a+_i a+_j + a_j a_i) has [D, N] = -2 sum Delta_ij (a+_i a+_j - a_j a_i) exactly and commutes with P;
   a term a+_i a_j a_k anticommutes with P; the kernel of ad_N has the dimension of the charge-0 monomials, binom(2n, n) (n = 2, 3 exact,
   n = 4 numpy); on a ring of 4 sites the occupations of the hopping modes commute with the hopping term and not with the interaction
   while N commutes with both.  bd.sol.31 (the Hubbard model on the 3-cube) is run again.
   [bit] Fractions in the bit rule of Cl(n,n).  [std] numpy Jordan-Wigner matrices.  [ctl] ODD, PAIR, COEF.
T. The ten symmetry classes (solid.T1 .. T6).  The symmetry algebra of an Altland-Zirnbauer class (J, T, C antilinear or complex structure,
   T^2 = t, C^2 = c) is the bit-rule cell of signature (-1, t, c), (-1, t), (-1, c) or (-1) (class A; AIII is C + C from explicit
   matrices); along AI, BDI, D, DIII, AII, CII, C, CI the commutant types are R, R, R, C, H, H, H, C with two summands at BDI and CII,
   the clock table at c = 0 .. 7 (and, the table being symmetric under c -> 2 - c, at c = 2 - s); the exchange of the labels T^2 and C^2
   maps the class s to 2 - s and keeps the list; the list fits the clock table at exactly two of the 16 alignments (forward from c = 0, backward from
   c = 2), so the types fix the alignment up to that reflection and not its direction.  bd.sol.1 .. 3 are run again for the edge.
   [bit] the cells of item K.  [std] numpy real Kronecker words and the label table.  [ctl] SWAP, JSQ.
W. Wilson's plaquette (solid.W1 .. W6).  su(2) = unit quaternions of the even part of Cl(0,3), links exp(a A) on the n-cube (n = 2, 3, 4),
   three seeded polynomial fields of degree 2 with rational coefficients, series in a to order 6 with Fractions: the orders 0 .. 3 of
   1 - (1/2) tr U_p vanish for every plaquette, the order 4 is -(1/4) tr F^2 with F = dA - dA + [A,A] (yangmills_selfcheck.Gauge.Fmn),
   the sum over plaquettes is gauge invariant to order 6; numpy expm (raw ratios at a = 1e-2, 1e-3; Richardson extrapolation over a = 8e-3 .. 1e-3) agrees with the
   exact coefficient; the staggered phases of bd.phy.16 (n = 2 .. 6) are asserted again.  [ctl] LINK, ABEL, WCOEF.
B. Bethe's double groups (solid.B1 .. B6).  The binary tetrahedral (24), octahedral (48) and icosahedral (120) groups as unit rotors of the
   even part of Cl(3,0) (rational representatives up to positive scaling for 2T and 2O, Q(sqrt 5) for 2I), class numbers 7, 8, 9, the
   crystallographic traces, the exact inner products of the restrictions of the SU(2) characters (j = 1/2 .. 9/2): j = 3/2 irreducible
   under 2O and 2I, two pieces under 2T, j = 5/2 = G7 + G8 under 2O, integer j orthogonal to half-integer j; numpy unit quaternions as 2 x 2
   matrices and a Burnside-Dixon character table in floats.  [ctl] OPEN, ANGLE, PARITY.
Scope: p + q <= 7 (K, T); n = 2 .. 6 (H); n = 2, 3, 4 and three fields (W); the three double groups (B).  The gravity engine's Forms, Lie
and Grav are not used, so its eight engine faults are not seen by this script; its controls are the faults above.
Options: --fault NAME runs only the item that carries the wrong version NAME (NONMIN, CLOCK, KRAM, FS in K; ODD, PAIR, COEF in H; SWAP,
JSQ in T; LINK, ABEL, WCOEF in W; OPEN, ANGLE, PARITY in B) and must exit with code 1; --only=kramers,hubbard,tenfold,wilson,bethe selects items.
Command: python3 solid_cube.py   (from this folder, or python3 selfcheck/proofs/solid_cube.py from the package root; standard library,
numpy and scipy)."""
import os, sys, io, itertools, random, contextlib, math, importlib
from fractions import Fraction as Fr
from math import comb, gcd
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                         # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                         # selfcheck/
_root = os.path.dirname(_selfcheck)                                         # package root
for _p in (os.path.join(_selfcheck, 'bridges'), _selfcheck, os.path.join(_root, 'researchers_checks'), os.path.join(_selfcheck, 'steps15_17')):
    if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
from bitcliff import Alg, regular_matrix, sig
from bitrule_A import BR

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('NONMIN', 'CLOCK', 'KRAM', 'FS', 'ODD', 'PAIR', 'COEF', 'SWAP', 'JSQ', 'LINK', 'ABEL', 'WCOEF', 'OPEN', 'ANGLE', 'PARITY')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
ITEMS = []
TYPES = ['R', 'R2', 'R', 'C', 'H', 'H2', 'H', 'C']        # the textbook mod-8 table, used only to compare, never as input
BASE = {'R': 'R', 'R2': 'R', 'C': 'C', 'H': 'H', 'H2': 'H'}
DIMK = {'R': 1, 'C': 2, 'H': 4}

def pc(x): return bin(x).count('1')
def rank_frac(rows):
    """exact rank over Q of a list of integer / Fraction vectors"""
    M = [[Fr(v) for v in r] for r in rows]
    rk = 0; nc = len(M[0]) if M else 0
    for col in range(nc):
        piv = next((i for i in range(rk, len(M)) if M[i][col] != 0), None)
        if piv is None: continue
        M[rk], M[piv] = M[piv], M[rk]
        for i in range(len(M)):
            if i != rk and M[i][col] != 0:
                f = M[i][col] / M[rk][col]; M[i] = [a - f * b for a, b in zip(M[i], M[rk])]
        rk += 1
    return rk

# ------------------------------------------------------------------------------------------------ the minimal module of Cl(p,q) from the bit rule
def best_group(alg):
    """a maximal set of commuting blades of square +1 whose F2-span squares to +1 (best of 26 orders)"""
    best = []; rg = random.Random(7 + alg.n)
    orders = [list(range(1, alg.N)), list(range(alg.N - 1, 0, -1))]
    for _ in range(24):
        o = list(range(1, alg.N)); rg.shuffle(o); orders.append(o)
    for order in orders:
        gens = []; span = {0}
        for a in order:
            if a in span or alg.sq(a) != 1: continue
            if all(alg.comm_sign(a, g) == 1 for g in gens):
                new = {s ^ a for s in span}
                if all(alg.sq(x) == 1 for x in new):
                    gens.append(a); span = span | new
        if len(gens) > len(best): best = gens
    return best

def ideal_module(p, q, drop=0):
    """left ideal A f of Cl(p,q): f = prod (1 + e_a)/2 over the blades of best_group (the last `drop` of them left out).
    Returns the algebra, the signed permutation matrices rho(e_i) on the basis e_r f, the count k of idempotent factors."""
    alg = Alg(sig(p, q)); n = alg.n; N = alg.N
    gens = best_group(alg)
    if drop: gens = gens[:max(0, len(gens) - drop)]
    k = len(gens); span = {0}
    for a in gens: span |= {s ^ a for s in span}
    tau = {}
    for J in range(1 << k):
        prod = {0: 1}
        for j in range(k):
            if J >> j & 1: prod = alg.mul(prod, {gens[j]: 1})
        (mm, cf), = prod.items(); tau[mm] = cf                                     # (product of the chosen blades) = cf e_mm, so e_mm f = cf f
    assert set(tau) == span and len(span) == 1 << k
    coset = {}; reps = []
    for a in range(N):
        if a not in coset:
            reps.append(a)
            for mm in span: coset[a ^ mm] = (a, mm)
    m = len(reps); idx = {r: i for i, r in enumerate(reps)}
    rho = []
    for i in range(n):
        R = np.zeros((m, m), dtype=np.int64)
        for r in reps:
            s, c = alg.blade_mul(1 << i, r); r2, mm = coset[c]; s2, _ = alg.blade_mul(r2, mm)
            R[idx[r2], idx[r]] = s * s2 * tau[mm]
        rho.append(R)
    # the rho are a representation of Cl(p,q) ...
    eps = alg.eps
    ok_rep = all(np.array_equal(rho[i] @ rho[j] + rho[j] @ rho[i], (2 * eps[i] if i == j else 0) * np.eye(m, dtype=np.int64)) for i in range(n) for j in range(n))
    # ... and the restriction of the left-multiplication matrices of the regular module to the ideal
    f = {0: Fr(1)}
    for a in gens: f = alg.mul(f, {0: Fr(1, 2), a: Fr(1, 2)})
    V = np.zeros((N, m), dtype=np.int64)
    for c, r in enumerate(reps):
        for mm, cf in alg.mul({r: 1}, f).items():
            v = Fr(cf) * (1 << k); assert v.denominator == 1; V[mm, c] = int(v)
    ok_reg = all(np.array_equal(np.array(regular_matrix(alg, {1 << i: 1}), dtype=np.int64) @ V, V @ rho[i]) for i in range(n))
    ok_dim = (np.linalg.matrix_rank(V) == m) if n else True
    return {'alg': alg, 'n': n, 'p': p, 'q': q, 'rho': rho, 'm': m, 'k': k, 'ok_rep': ok_rep, 'ok_reg': ok_reg, 'ok_dim': ok_dim}

def blade_mats(mod):
    """rho(e_a) for every blade a (e_a = e_i1 e_i2 ... in increasing order)"""
    m = mod['m']; out = {0: np.eye(m, dtype=np.int64)}
    for a in range(1, mod['alg'].N):
        i = (a & -a).bit_length() - 1
        out[a] = mod['rho'][i] @ out[a ^ (1 << i)]
    return out

# ------------------------------------------------------------------------------------------------ exact commutant of a signed-permutation module
def commutant_basis(rho, m):
    """all X (m x m) with X rho_i = rho_i X; each rho_i a signed permutation matrix.  The equations read X[pi(b),pi(c)] = s(b) s(c) X[b,c],
    so the solutions are the sign-consistent components of a union-find over the m^2 entries; the basis is one {0,+1,-1} matrix per component."""
    if not rho: return [np.eye(m, dtype=np.int64)] if m == 1 else None
    perms = []
    for R in rho:
        pi = [0] * m; sg = [0] * m
        for c in range(m):
            nz = np.nonzero(R[:, c])[0]; assert len(nz) == 1
            pi[c] = int(nz[0]); sg[c] = int(R[nz[0], c])
        perms.append((pi, sg))
    parent = list(range(m * m)); psign = [1] * (m * m)
    def find(x):
        path = []
        while parent[x] != x: path.append(x); x = parent[x]
        s = 1
        for node in reversed(path):
            s *= psign[node]; psign[node] = s; parent[node] = x
        return x
    def sgn_of(x):
        r = find(x); return r, (1 if x == r else psign[x])
    eqs = []
    for pi, sg in perms:
        for b in range(m):
            for c in range(m): eqs.append((pi[b] * m + pi[c], b * m + c, sg[b] * sg[c]))
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv: parent[ru] = rv; psign[ru] = s * sv * su
    bad = set(); comp = {}
    for u, v, s in eqs:
        ru, su = sgn_of(u); rv, sv = sgn_of(v)
        if ru != rv or su != s * sv: bad.add(rv)
    for x in range(m * m):
        r, sx = sgn_of(x); comp.setdefault(r, []).append((x, sx))
    basis = []
    for r in sorted(comp):
        if r in bad or any(rr in bad for rr in [r]): continue
        B = np.zeros((m, m), dtype=np.int64)
        for x, sx in comp[r]: B[x // m, x % m] = sx
        basis.append(B)
    return basis

def classify(basis, m):
    """type of the algebra K spanned by the integer matrices `basis`: 'R' (d = 1), 'C' (d = 2, a J with J^2 = -1), 'H' (d = 4, i and j with
    i^2 = j^2 = -1, ij = -ji); None if K is not seen to be a division algebra.  Also returns the elements."""
    d = len(basis)
    pos = [tuple(np.argwhere(B != 0)[0]) for B in basis]
    def coords(P):
        x = [int(P[p]) * int(B[p]) for B, p in zip(basis, pos)]
        assert np.array_equal(sum(c * B for c, B in zip(x, basis)), P), 'not in the span'
        return x
    kap = [[coords(Bc @ Bd) for Bd in basis] for Bc in basis]
    e = coords(np.eye(m, dtype=np.int64))
    def mul(x, y):
        out = [0] * d
        for c in range(d):
            if x[c]:
                for dd in range(d):
                    if y[dd]:
                        for t in range(d): out[t] += x[c] * y[dd] * kap[c][dd][t]
        return out
    def mat(x): return sum(c * B for c, B in zip(x, basis))
    neg = [-v for v in e]
    if d == 1: return 'R', []
    if d == 2:
        for x in itertools.product(range(-2, 3), repeat=2):
            if mul(x, x) == neg: return 'C', [mat(x)]
        return None, []
    if d == 4:
        roots = [x for x in itertools.product(range(-2, 3), repeat=4) if mul(x, x) == neg]
        for x in roots:
            for y in roots:
                xy, yx = mul(x, y), mul(y, x)
                if all(a == -b for a, b in zip(xy, yx)): return 'H', [mat(x), mat(y)]
        return None, []
    return None, []

def module_type(p, q, drop=0):
    """(type, d, m, summands, structure) of the minimal module of Cl(p,q) built from the bit rule"""
    mod = ideal_module(p, q, drop)
    m = mod['m']; basis = commutant_basis(mod['rho'], m)
    t, elems = classify(basis, m)
    d = len(basis)
    summ = Fr((1 << mod['n']) * d, m * m)
    return {'type': t, 'd': d, 'm': m, 'summands': summ, 'elems': elems, 'mod': mod, 'basis': basis}

# ================================================================================================ K. Kramers and the three types
_LET = {'I': np.eye(2), 'X': np.array([[0., 1.], [1., 0.]]), 'Z': np.array([[1., 0.], [0., -1.]]), 'E': np.array([[0., 1.], [-1., 0.]])}
def find_real_rep(eps):
    """[std] real matrices (Kronecker words of I, sigma_x, sigma_z, i sigma_y) for the generators of Cl with squares eps: the smallest size that works"""
    if len(eps) == 0: return [], 1
    for L in range(1, 5):
        words = list(itertools.product('IXZE', repeat=L)); d = 2 ** L; mats = []
        for w in words:
            M = np.array([[1.]])
            for ch in w: M = np.kron(M, _LET[ch])
            mats.append(M)
        sq = [None] * len(mats)
        for i, M in enumerate(mats):
            S2 = M @ M
            if np.allclose(S2, np.eye(d)): sq[i] = 1
            elif np.allclose(S2, -np.eye(d)): sq[i] = -1
        pos = [i for i in range(len(mats)) if sq[i] == 1 and not np.allclose(mats[i], np.eye(d))]
        neg = [i for i in range(len(mats)) if sq[i] == -1]
        nm = len(mats); anti = np.zeros((nm, nm), dtype=bool)
        for i in range(nm):
            for j in range(i + 1, nm):
                anti[i, j] = anti[j, i] = np.allclose(mats[i] @ mats[j], -(mats[j] @ mats[i]))
        def dfs(chosen, k, last):
            if k == len(eps): return chosen
            pool = pos if eps[k] == 1 else neg
            for i in pool:
                if i in chosen or (k > 0 and eps[k] == eps[k - 1] and i <= last): continue
                if all(anti[i, j] for j in chosen):
                    r = dfs(chosen + [i], k + 1, i)
                    if r: return r
            return None
        res = dfs([], 0, -1)
        if res: return [mats[i] for i in res], d
    return None, None

def np_commutant_dim(gens, m):
    A = np.vstack([np.kron(np.eye(m), G.T) - np.kron(G, np.eye(m)) for G in gens]) if gens else np.zeros((1, m * m))
    s = np.linalg.svd(A, compute_uv=False)
    return int(m * m - np.sum(s > 1e-9))

def np_multiplicities(gens, m, seed):
    """eigenvalue multiplicities of a random symmetric element sum c_a rho(e_a) (floats)"""
    rg = np.random.default_rng(seed); n = len(gens); X = np.zeros((m, m))
    for a in range(1 << n):
        M = np.eye(m)
        for i in range(n):
            if a >> i & 1: M = M @ gens[i]
        X += rg.integers(-3, 4) * M
    w = np.linalg.eigvalsh(X + X.T); out = []; k = 1
    for i in range(1, len(w)):
        if abs(w[i] - w[i - 1]) < 1e-7: k += 1
        else: out.append(k); k = 1
    out.append(k)
    return sorted(set(out))

def item_kramers():
    head('K. Kramers degeneracy and the three types of commutant (every Cl(p,q) with p + q <= 7)')
    drop = 1 if FAULT == 'NONMIN' else 0
    cells = [(n - q, q) for n in range(8) for q in range(n + 1)]
    res = {}; clocks = set(); nbytype = {}
    for (p, q) in cells:
        r = module_type(p, q, drop); res[(p, q)] = r
        c = (p - q) % 8; clocks.add(c)
        want = TYPES[c] if FAULT != 'CLOCK' else TYPES[(q - p) % 8]
        mod = r['mod']; alg = mod['alg']; top = alg.N - 1
        cen = alg.center_blades()
        s_cen = 2 if (len(cen) == 2 and alg.sq(top) == 1) else 1
        s_ok = (r['summands'] == (2 if want.endswith('2') else 1)) and (r['summands'] == s_cen if not drop else True)
        ok = mod['ok_rep'] and mod['ok_reg'] and mod['ok_dim'] and r['type'] == BASE[want] and s_ok
        nbytype[r['type']] = nbytype.get(r['type'], 0) + 1
        chk('bit', ok, 'solid.K1: Cl(%d,%d), clock %d: minimal module of real dimension %d (k = %d idempotent factors), commutant of dimension %d, type %s, '
            'simple summands %s; table says %s' % (p, q, c, r['m'], mod['k'], r['d'], r['type'], r['summands'], want))
    chk('bit', clocks == set(range(8)) and len(cells) == 36, 'solid.K2: 36 cells, every clock value 0 .. 7 occurs; types found %s' % dict(sorted(nbytype.items(), key=lambda kv: str(kv[0]))))
    # K3: Kramers pairs from an exact Krylov rank
    mults = {}
    for (p, q), r in res.items():
        if r['type'] is None: continue
        mod = r['mod']; m = r['m']; d = r['d']; BM = blade_mats(mod); rg = random.Random(1000 + 16 * p + q)
        nsamp = 20 if d == 4 else 8; good = True; seen = set()
        for _ in range(nsamp):
            while True:
                X = sum(rg.randint(-50, 50) * BM[a] for a in range(mod['alg'].N)); S = X + X.T
                if np.any(S): break
            if any(np.any(S @ E != E @ S) for E in r['elems']): good = False
            v = np.array([rg.choice([-1, 1]) * rg.randint(1, 50) for _ in range(m)], dtype=object); Sx = S.astype(object); vecs = [v]
            for _k in range(m - 1): vecs.append(Sx.dot(vecs[-1]))
            cyc = rank_frac([list(x) for x in vecs])
            seen.add(m // cyc if m % cyc == 0 else -1)
            if cyc != m // d: good = False
        if d == 4:
            iM, jM = r['elems']; kM = iM @ jM
            good = good and np.array_equal(iM @ iM, -np.eye(m, dtype=np.int64)) and np.array_equal(jM @ jM, -np.eye(m, dtype=np.int64)) and np.array_equal(iM @ jM, -(jM @ iM)) and np.array_equal(kM @ kM, -np.eye(m, dtype=np.int64))
        mult = (min(seen) if seen else None); mults[(p, q)] = mult
        need = mult is not None and mult >= (2 if FAULT == 'KRAM' else 1)
        chk('bit', good and need and seen == {d}, 'solid.K3: Cl(%d,%d) type %s: %d symmetric random elements (coefficients in -50..50) of the algebra%s commute with the commutant and have every eigenvalue of multiplicity %s over R%s'
            % (p, q, r['type'], nsamp, ', with i, j, ij = quaternion triple (j^2 = -1: antiunitary T, T^2 = -1)' if d == 4 else '', sorted(seen), ' (Kramers pair over C)' if d == 4 else (' (one over C: no Kramers pair)' if d == 2 else ' (simple spectrum)')))
    # K4: numpy real Kronecker words
    for (p, q) in ((3, 0), (0, 3), (2, 0), (0, 4)):
        gens, m = find_real_rep([1] * p + [-1] * q); dstd = np_commutant_dim(gens, m)
        mult = np_multiplicities(gens, m, 40 + 10 * p + q)
        r = res[(p, q)]
        chk('std', dstd == r['d'] and mult == [r['d']] and m == r['m'], 'solid.K4: numpy real matrices of size %d for Cl(%d,%d): commutant dimension %d by SVD, eigenvalue multiplicities of a random symmetric element %s; bit: dimension %d, size %d' % (m, p, q, dstd, mult, r['d'], r['m']))
    # K5: the Frobenius-Schur sum, recalled
    ok5 = True; bad = []
    for (p, q), r in res.items():
        Np, Nm, Nz = r['mod']['alg'].counts()
        fs = Fr(r['m'], 1 << (p + q)) * (Np - Nm)
        dfs = (2 + fs) if FAULT == 'FS' else (2 - fs)
        if r['d'] != dfs: ok5 = False; bad.append((p, q))
    chk('bit==std', ok5, 'solid.K5: for every one of the 36 cells the commutant dimension equals 2 - (dim U / 2^n)(N+ - N-) (Frobenius-Schur sum over the blades, exact)%s' % ('' if ok5 else '; differs at %s' % bad[:6]))
    # controls
    cl_diff = sum(1 for (p, q) in cells if BASE[TYPES[(p - q) % 8]] != BASE[TYPES[(q - p) % 8]])
    chk('ctl', cl_diff > 0, 'solid.K6: the mirror clock -(p - q) disagrees with the computed type on %d of the 36 cells' % cl_diff)
    nm = [(p, q) for (p, q) in cells if module_type(p, q, 0)['mod']['k'] >= 1 and module_type(p, q, 1)['type'] is None]
    nk = [(p, q) for (p, q) in cells if module_type(p, q, 0)['mod']['k'] >= 1]
    chk('ctl', len(nm) > 0 and len(nm) == len(nk), 'solid.K6: an ideal built with one idempotent factor left out is not irreducible: its commutant is not seen to be a division algebra on %d of the %d cells with k >= 1' % (len(nm), len(nk)))
    simple = [pq for pq, mu in mults.items() if mu == 1]
    chk('ctl', len(simple) > 0, 'solid.K6: Kramers is not forced on the R cells: %d cells have a simple spectrum (multiplicity 1), so the demand "multiplicity >= 2" fails there' % len(simple))
    fsw = [pq for pq, r in res.items() if r['d'] == 4 and r['d'] == 2 + Fr(r['m'], 1 << sum(pq)) * (r['mod']['alg'].counts()[0] - r['mod']['alg'].counts()[1])]
    chk('ctl', not fsw, 'solid.K6: with the wrong sign (2 + ...) the Frobenius-Schur sum gives the wrong dimension on every H cell')
ITEMS.append(item_kramers)

# ================================================================================================ H. the grading and the Hubbard model
class Fock:
    """the CAR inside the bit rule of Cl(n,n): g_1..g_n square +1, g_{n+1}..g_{2n} square -1, a+_i = (g_i + g_{n+i})/2, a_i = (g_i - g_{n+i})/2"""
    def __init__(self, n):
        self.n = n; self.A = Alg(tuple([1] * n + [-1] * n)); h = Fr(1, 2)
        self.cd = [{1 << i: h, 1 << (n + i): h} for i in range(n)]
        self.c = [{1 << i: h, 1 << (n + i): -h} for i in range(n)]
        self.one = {0: Fr(1)}
        self.num = [self.mul(self.cd[i], self.c[i]) for i in range(n)]
        self.N = self.zero()
        for x in self.num: self.N = self.add(self.N, x)
        self.P = self.one
        for x in self.num: self.P = self.mul(self.P, self.add(self.one, x, -2))
    def zero(self): return {}
    def mul(self, *xs):
        out = xs[0]
        for x in xs[1:]: out = self.A.mul(out, x)
        return out
    def add(self, x, y, cy=1): return self.A.add(x, y, cy)
    def scal(self, x, c): return self.A.scal(x, Fr(c))
    def comm(self, x, y): return self.add(self.mul(x, y), self.mul(y, x), -1)
    def acomm(self, x, y): return self.add(self.mul(x, y), self.mul(y, x))
    def total(self, terms):
        out = self.zero()
        for c, x in terms: out = self.add(out, self.scal(x, c))
        return out

def jw_ops(n):
    I2 = np.eye(2); Z = np.diag([1., -1.]); sm = np.array([[0., 1.], [0., 0.]])
    def kron(ms):
        o = np.array([[1.]])
        for x in ms: o = np.kron(o, x)
        return o
    return [kron([Z] * i + [sm] + [I2] * (n - i - 1)) for i in range(n)]

def phi(F, x, G):
    """matrix of a multivector of Cl(n,n) in the Jordan-Wigner representation: g_i = c+_i + c_i, g_{n+i} = c+_i - c_i"""
    n = F.n; D = G[0].shape[0]; out = np.zeros((D, D))
    for mask, cf in x.items():
        M = np.eye(D)
        for b in range(2 * n):
            if mask >> b & 1: M = M @ G[b]
        out += float(cf) * M
    return out

def item_hubbard():
    head('H. The grading N is a charge only for a Hamiltonian that commutes with it: Cl(n,n), n = 2 .. 6')
    for n in range(2, 7):
        F = Fock(n); rg = random.Random(129 + n)
        car = all(F.acomm(F.c[i], F.cd[j]) == (F.one if i == j else {}) and F.acomm(F.c[i], F.c[j]) == {} and F.acomm(F.cd[i], F.cd[j]) == {} for i in range(n) for j in range(n))
        # P as a blade: prod_i (g_i g_{n+i})
        Pb = {0: 1}
        for i in range(n): Pb = F.A.mul(Pb, {(1 << i) | (1 << (n + i)): 1})
        pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        T = {pq: rg.randint(-3, 3) for pq in pairs}; V = {pq: rg.randint(-3, 3) for pq in pairs}; mu = [rg.randint(-3, 3) for _ in range(n)]
        Dl = {pq: rg.choice([-3, -2, -1, 1, 2, 3]) for pq in pairs}
        Hhop = F.total([(T[(i, j)], F.add(F.mul(F.cd[i], F.c[j]), F.mul(F.cd[j], F.c[i]))) for (i, j) in pairs])
        HV = F.total([(V[(i, j)], F.mul(F.num[i], F.num[j])) for (i, j) in pairs] + [(mu[i], F.num[i]) for i in range(n)])
        H = F.add(Hhop, HV)
        Hp = F.total([(Dl[(i, j)], F.add(F.mul(F.cd[i], F.cd[j]), F.mul(F.c[j], F.c[i]))) for (i, j) in pairs])
        chk('bit', car and F.comm(F.N, F.N) == {} and F.P == Pb, 'solid.H1: n = %d: the CAR {a_i, a+_j} = delta_ij, {a_i, a_j} = 0 hold as multivector identities in Cl(%d,%d); P = prod (1 - 2 n_i) is the blade prod g_i g_{n+i}' % (n, n, n))
        HN, HP = F.comm(H, F.N), F.comm(H, Pb)
        if FAULT == 'PAIR': HN = F.comm(F.add(H, Hp), F.N)
        chk('bit', HN == {} and HP == {} and len(H) > 0, 'solid.H2: n = %d: H = sum T_ij (a+_i a_j + h.c.) + sum V_ij n_i n_j + sum mu_i n_i (%d terms in the bit rule) has [H, N] = 0 and [H, (-1)^N] = 0 exactly' % (n, len(H)))
        D = F.total([(-2 * Dl[(i, j)], F.add(F.mul(F.cd[i], F.cd[j]), F.mul(F.c[j], F.c[i]), -1)) for (i, j) in pairs])
        exp_coef = 1 if FAULT == 'COEF' else 2
        Dexp = F.total([(-exp_coef * Dl[(i, j)], F.add(F.mul(F.cd[i], F.cd[j]), F.mul(F.c[j], F.c[i]), -1)) for (i, j) in pairs])
        Hall = F.add(H, Hp)
        cN = F.comm(Hp, F.N)
        chk('bit', cN == Dexp and cN != {} and F.comm(Hall, F.N) == cN and F.comm(Hp, Pb) == {} and F.comm(Hall, Pb) == {},
            'solid.H3: n = %d: the pairing term Delta sum (a+_i a+_j + a_j a_i) has [D, N] = -2 sum Delta_ij (a+_i a+_j - a_j a_i) exactly (not zero), [H + D, N] = [D, N], and [H + D, (-1)^N] = 0' % n)
        wrong = F.total([(-1 * Dl[(i, j)], F.add(F.mul(F.cd[i], F.cd[j]), F.mul(F.c[j], F.c[i]), -1)) for (i, j) in pairs])
        chk('ctl', wrong != cN and cN != {} and F.comm(Hall, F.N) != {}, 'solid.H3: n = %d: the coefficient -Delta in place of -2 Delta does not give [D, N], and H + D does not commute with N (the pairing term breaks the charge)' % n)
        X = F.mul(F.cd[0], F.c[1], F.c[2]) if n >= 3 else None
        if X is not None:
            odd_anti = F.mul(Pb, X) == F.scal(F.mul(X, Pb), -1) and F.comm(X, Pb) != {}
            if FAULT == 'ODD': odd_anti = F.comm(X, Pb) == {}
            chk('bit', odd_anti and F.comm(F.num[0], Pb) == {} and F.comm(F.num[0], F.N) == {}, 'solid.H4: n = %d: the odd term a+_0 a_1 a_2 anticommutes with (-1)^N (breaks the parity); a hopping term with a repeated index is n_0 and breaks nothing (commutes with N and (-1)^N)' % n)
        if X is not None:
            chk('ctl', F.comm(X, Pb) != {} and F.comm(F.add(H, X), Pb) != {} and F.comm(H, Pb) == {}, 'solid.H4: n = %d: H plus the odd term a+_0 a_1 a_2 no longer commutes with (-1)^N, while H alone does' % n)
        # the spinful Hubbard model: modes (i, s) = i + L s
        if n % 2 == 0 and n >= 4:
            L = n // 2; ring = [(i, (i + 1) % L) for i in range(L)] if L > 2 else [(0, 1)]
            hop = []
            for s in range(2):
                for (i, j) in ring: hop.append((-1, F.add(F.mul(F.cd[i + L * s], F.c[j + L * s]), F.mul(F.cd[j + L * s], F.c[i + L * s]))))
            Hub = F.total(hop + [(4, F.mul(F.num[i], F.num[i + L])) for i in range(L)])
            Nup = F.zero()
            for i in range(L): Nup = F.add(Nup, F.num[i])
            chk('bit', F.comm(Hub, F.N) == {} and F.comm(Hub, Pb) == {} and F.comm(Hub, Nup) == {} and len(Hub) > 0, 'solid.H4: n = %d: the Hubbard model on a ring of %d sites with spin (hopping -1, U = 4 on n_{i up} n_{i down}) has [H, N] = [H, (-1)^N] = [H, N_up] = 0' % (n, L))
        # [std]: the Jordan-Wigner matrices and the map phi
        c = jw_ops(n); cdm = [x.T for x in c]; G = [cdm[i] + c[i] for i in range(n)] + [cdm[i] - c[i] for i in range(n)]
        Nm = sum(cdm[i] @ c[i] for i in range(n)); Pm = np.eye(2 ** n)
        for i in range(n): Pm = Pm @ (np.eye(2 ** n) - 2 * cdm[i] @ c[i])
        Hm = sum(T[(i, j)] * (cdm[i] @ c[j] + cdm[j] @ c[i]) for (i, j) in pairs) + sum(V[(i, j)] * (cdm[i] @ c[i] @ cdm[j] @ c[j]) for (i, j) in pairs) + sum(mu[i] * cdm[i] @ c[i] for i in range(n))
        Hpm = sum(Dl[(i, j)] * (cdm[i] @ cdm[j] + c[j] @ c[i]) for (i, j) in pairs)
        cm = lambda A, B: A @ B - B @ A
        ok_std = np.allclose(cm(Hm, Nm), 0) and np.allclose(cm(Hm, Pm), 0) and not np.allclose(cm(Hpm, Nm), 0) and np.allclose(cm(Hpm, Pm), 0)
        dm = -2 * sum(Dl[(i, j)] * (cdm[i] @ cdm[j] - c[j] @ c[i]) for (i, j) in pairs)
        chk('std', ok_std and np.allclose(cm(Hpm, Nm), dm), 'solid.H5: n = %d: numpy Jordan-Wigner matrices (%d x %d): [H, N] = 0, [H, (-1)^N] = 0, [D, N] = -2 sum Delta_ij (c+_i c+_j - c_j c_i) != 0, [D, (-1)^N] = 0' % (n, 2 ** n, 2 ** n))
        ok_eq = (np.allclose(phi(F, H, G), Hm) and np.allclose(phi(F, Hp, G), Hpm) and np.allclose(phi(F, F.N, G), Nm) and np.allclose(phi(F, Pb, G), Pm)
                 and np.allclose(phi(F, cN, G), cm(Hpm, Nm)) and np.allclose(phi(F, F.comm(H, F.N), G), 0))
        chk('bit==std', ok_eq, 'solid.H5: n = %d: the Jordan-Wigner image of the bit-rule multivectors H, D, N, (-1)^N and of the commutator [D, N] is the numpy matrix of the same operator' % n)
    # the kernel of ad_N: exact for n = 2, 3 (rank over Q), numpy for n = 2, 3, 4
    for n in (2, 3):
        F = Fock(n); A = F.A; Nb = A.N
        rows = []
        for b in range(Nb):
            col = F.comm(F.N, {b: Fr(1)}); rows.append([col.get(a, 0) for a in range(Nb)])
        nul = Nb - rank_frac(rows)
        chk('bit', nul == comb(2 * n, n), 'solid.H6: n = %d: the operators of Cl(%d,%d) that commute with N form a space of dimension %d = C(%d,%d), the number of monomials a+_S a_T with |S| = |T| (exact rank over Q of ad_N on the %d blades)' % (n, n, n, nul, 2 * n, n, Nb))
        mons_ok = True
        for S in itertools.chain.from_iterable(itertools.combinations(range(n), k) for k in range(n + 1)):
            for Tt in itertools.chain.from_iterable(itertools.combinations(range(n), k) for k in range(n + 1)):
                mono = F.one
                for i in S: mono = F.mul(mono, F.cd[i])
                for j in Tt: mono = F.mul(mono, F.c[j])
                if mono and F.comm(F.N, mono) != F.scal(mono, len(S) - len(Tt)): mons_ok = False
        chk('bit', mons_ok, 'solid.H6: n = %d: [N, a+_S a_T] = (|S| - |T|) a+_S a_T for every pair of subsets S, T' % n)
    for n in (2, 3, 4):
        c = jw_ops(n); cdm = [x.T for x in c]; Nm = sum(cdm[i] @ c[i] for i in range(n)); D = 2 ** n
        ad = np.kron(Nm, np.eye(D)) - np.kron(np.eye(D), Nm.T)
        nul = D * D - np.linalg.matrix_rank(ad)
        chk('std', nul == comb(2 * n, n), 'solid.H6: n = %d: numpy: the matrices that commute with N form a space of dimension %d = C(%d,%d)' % (n, nul, 2 * n, n))
    # a ring of four sites: the occupations of the hopping modes against the interaction
    n = 4; F = Fock(n); ring = [(0, 1), (1, 2), (2, 3), (3, 0)]
    Hh = F.total([(1, F.add(F.mul(F.cd[i], F.c[j]), F.mul(F.cd[j], F.c[i]))) for (i, j) in ring])
    Vi = F.total([(1, F.mul(F.num[i], F.num[j])) for (i, j) in ((0, 1), (1, 2), (2, 3), (3, 0), (0, 2))])
    modes = [(1, 1, 1, 1), (1, -1, 1, -1), (1, 0, -1, 0), (0, 1, 0, -1)]
    def nmode(v):
        bd = F.total([(v[i], F.cd[i]) for i in range(n)]); b = F.total([(v[i], F.c[i]) for i in range(n)])
        return F.scal(F.mul(bd, b), Fr(1, sum(x * x for x in v)))
    nm = [nmode(v) for v in modes]
    free = all(F.comm(Hh, x) == {} for x in nm)
    lost = [F.comm(F.add(Hh, Vi), x) != {} for x in nm]
    chk('bit', free and any(lost) and F.comm(Hh, F.N) == {} and F.comm(F.add(Hh, Vi), F.N) == {},
        'solid.H7: ring of 4 sites: the occupations of the four hopping modes commute with the hopping term, %d of them do not commute with hopping + density interaction, and N commutes with both' % sum(lost))
    # bd.sol.31 again
    import sol_hubbard_cube as shc
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf): shc.main()
    out = buf.getvalue()
    chk('bit', ('ok   bd·sol·31' in out) and not shc.FAILS, 'solid.H8: bd.sol.31 is run again (Hubbard model on the 3-cube, 32 flux sectors, U = 0, 2, 4, 8): the all-pi sector has the lowest ground energy, as asserted there')
ITEMS.append(item_hubbard)

# ================================================================================================ W. Wilson's plaquette
ORD = 6
def _quat_table():
    A = Alg((-1, -1, -1)); masks = [0, 0b011, 0b101, 0b110]           # 1 and the bivectors of Cl(0,3): the unit quaternions
    tab = {}
    for i, a in enumerate(masks):
        for j, b in enumerate(masks):
            s, c = A.blade_mul(a, b); tab[(i, j)] = (s, masks.index(c))
    return tab
QT = _quat_table(); ZQ = (Fr(0),) * 4
def qmul(p, q):
    out = [Fr(0)] * 4
    for i in range(4):
        if p[i] == 0: continue
        for j in range(4):
            if q[j] == 0: continue
            s, k = QT[(i, j)]; out[k] += s * p[i] * q[j]
    return tuple(out)
def s_one(): return [(Fr(1), Fr(0), Fr(0), Fr(0))] + [ZQ] * ORD
def s_mul(a, b):
    out = [[Fr(0)] * 4 for _ in range(ORD + 1)]
    for o1 in range(ORD + 1):
        if not any(a[o1]): continue
        for o2 in range(ORD + 1 - o1):
            if not any(b[o2]): continue
            pr = qmul(a[o1], b[o2]); o = out[o1 + o2]
            for t in range(4): o[t] += pr[t]
    return [tuple(o) for o in out]
def s_add(a, b): return [tuple(x + y for x, y in zip(p, q)) for p, q in zip(a, b)]
def s_scale(a, c): return [tuple(x * c for x in p) for p in a]
def s_conj(a): return [(q[0], -q[1], -q[2], -q[3]) for q in a]
def s_exp(X):
    res = s_one(); term = s_one()
    for m in range(1, ORD + 1):
        term = s_scale(s_mul(term, X), Fr(1, m)); res = s_add(res, term)
    return res
def sc_mul(a, b):
    out = [Fr(0)] * (ORD + 1)
    for i, x in enumerate(a):
        if x == 0: continue
        for j in range(ORD + 1 - i): out[i + j] += x * b[j]
    return out
def eval_poly(poly, args):
    out = [Fr(0)] * (ORD + 1); pw = [[[Fr(1)] + [Fr(0)] * ORD] for _ in args]
    for mono, cf in poly.items():
        term = [Fr(cf)] + [Fr(0)] * ORD
        for i, e in enumerate(mono):
            while len(pw[i]) <= e: pw[i].append(sc_mul(pw[i][-1], args[i]))
            if e: term = sc_mul(term, pw[i][e])
        out = [u + v for u, v in zip(out, term)]
    return out
def rand_field(rg, n, deg=2):
    mons = [e for e in itertools.product(range(deg + 1), repeat=n) if sum(e) <= deg]
    return [[{e: Fr(rg.randint(-6, 6), 4) for e in mons if rg.random() < 0.7} or {(0,) * n: Fr(1, 2)} for a in range(3)] for mu in range(n)]
def pder_(poly, i):
    out = {}
    for k, v in poly.items():
        if k[i]:
            kk = list(k); kk[i] -= 1; out[tuple(kk)] = out.get(tuple(kk), 0) + v * k[i]
    return {k: v for k, v in out.items() if v != 0}
def peval(poly, pt):
    tot = Fr(0)
    for k, v in poly.items():
        t = Fr(v)
        for x, e in zip(pt, k): t *= x ** e
        tot += t
    return tot

def wilson_series(n, A, y0, gt=None, variant=None):
    """exact series (orders 0 .. 6 in a) of the plaquette action on the n-cube: links exp(a A_mu(y0 + a x)); gt: optional gauge field lambda;
    variant LINK: the last link of every plaquette is not inverted.  Returns the list of per-plaquette scalar series and the link table."""
    sites = list(itertools.product((0, 1), repeat=n))
    def args(x): return [[Fr(y0[i]), Fr(x[i])] + [Fr(0)] * (ORD - 1) for i in range(n)]
    U = {}
    for x in sites:
        ar = args(x)
        for mu in range(n):
            if x[mu]: continue
            comps = [eval_poly(A[mu][a], ar) for a in range(3)]
            X = [ZQ] + [(Fr(0), comps[0][o], comps[1][o], comps[2][o]) for o in range(ORD)]
            U[(x, mu)] = s_exp(X)
    if gt is not None:
        g = {}
        for x in sites:
            ar = args(x); comps = [eval_poly(gt[a], ar) for a in range(3)]
            g[x] = s_exp([ZQ] + [(Fr(0), comps[0][o], comps[1][o], comps[2][o]) for o in range(ORD)])
        for (x, mu) in list(U):
            xp = list(x); xp[mu] = 1; xp = tuple(xp)
            U[(x, mu)] = s_mul(s_mul(g[x], U[(x, mu)]), s_conj(g[xp]))
    def nb(x, mu):
        y = list(x); y[mu] = 1; return tuple(y)
    plaq = []
    for mu in range(n):
        for nu in range(mu + 1, n):
            for x in sites:
                if x[mu] or x[nu]: continue
                last = U[(x, nu)] if variant == 'LINK' else s_conj(U[(x, nu)])
                Up = s_mul(s_mul(s_mul(U[(x, mu)], U[(nb(x, mu), nu)]), s_conj(U[(nb(x, nu), mu)])), last)
                one = s_one()
                plaq.append(((mu, nu), x, [one[o][0] - Up[o][0] for o in range(ORD + 1)]))
    return plaq

def np_plaquette_action(n, A, y0, a):
    """[std] numpy / scipy: the same action with 2 x 2 matrix exponentials; S_p = (1/4) |U_p - 1|_F^2"""
    from scipy.linalg import expm
    sx = np.array([[0, 1], [1, 0]], dtype=complex); sy = np.array([[0, -1j], [1j, 0]]); sz = np.diag([1, -1]).astype(complex)
    tau = [-1j * sx, -1j * sy, -1j * sz]
    # the matrices obey the multiplication table of the bit-rule units
    for i in range(1, 4):
        for j in range(1, 4):
            s, k = QT[(i, j)]
            want = (-np.eye(2) if i == j else (s * tau[k - 1] if k else None))
            assert want is not None and np.allclose(tau[i - 1] @ tau[j - 1], want)
    Af = [[{k: float(v) for k, v in A[mu][c].items()} for c in range(3)] for mu in range(n)]
    def evalf(poly, pt): return sum(v * np.prod([x ** e for x, e in zip(pt, k)]) for k, v in poly.items())
    sites = list(itertools.product((0, 1), repeat=n)); U = {}
    for x in sites:
        pt = [float(y0[i]) + a * x[i] for i in range(n)]
        for mu in range(n):
            if x[mu]: continue
            M = sum(evalf(Af[mu][c], pt) * tau[c] for c in range(3)); U[(x, mu)] = expm(a * M)
    def nb(x, mu):
        y = list(x); y[mu] = 1; return tuple(y)
    tot = 0.0
    for mu in range(n):
        for nu in range(mu + 1, n):
            for x in sites:
                if x[mu] or x[nu]: continue
                Up = U[(x, mu)] @ U[(nb(x, mu), nu)] @ U[(nb(x, nu), mu)].conj().T @ U[(x, nu)].conj().T
                tot += 0.25 * np.sum(np.abs(Up - np.eye(2)) ** 2)
    return tot

def item_wilson():
    head("W. Wilson's plaquette action for su(2) on the n-cube (n = 2, 3, 4), exact series in the spacing a to order 6")
    import yangmills_selfcheck as ym
    for n in (2, 3, 4):
        for seed in range(3):
            rg = random.Random(47 + 100 * n + seed); A = rand_field(rg, n); y0 = [Fr(rg.randint(-4, 4), 4) for _ in range(n)]
            plaq = wilson_series(n, A, y0, variant='LINK' if FAULT == 'LINK' else None)
            # F from the package (yangmills_selfcheck.Gauge.Fmn, so(3) = bivectors of Cl(0,3), g = 1) and from the quaternion table
            Y = ym.Gauge(3, n, g=Fr(1)); Fp = {(mu, nu): Y.Fmn(A, mu, nu) for mu in range(n) for nu in range(mu + 1, n)}
            Fv = {k: [peval(c, y0) for c in v] for k, v in Fp.items()}
            own_ok = True
            for (mu, nu), v in Fv.items():
                Am = (Fr(0),) + tuple(peval(A[mu][c], y0) for c in range(3)); An = (Fr(0),) + tuple(peval(A[nu][c], y0) for c in range(3))
                cm = tuple(p - q for p, q in zip(qmul(Am, An), qmul(An, Am)))
                own = [peval(pder_(A[nu][c], mu), y0) - peval(pder_(A[mu][c], nu), y0) + cm[c + 1] for c in range(3)]
                own_ok &= own == v
            c4 = sum(p[2][4] for p in plaq)
            norm2 = {k: sum(c * c for c in v) for k, v in Fv.items()}
            if FAULT == 'ABEL': norm2 = {(mu, nu): sum((peval(pder_(A[nu][c], mu), y0) - peval(pder_(A[mu][c], nu), y0)) ** 2 for c in range(3)) for (mu, nu) in Fv}
            kc = Fr(1, 1) if FAULT == 'WCOEF' else Fr(1, 2)                     # -(1/4) tr F^2 = (1/2) |F|^2 per plaquette (the fault: -(1/2) tr F^2)
            pred = kc * (2 ** (n - 2)) * sum(norm2.values())                    # 2^(n-2) plaquettes per plane
            low = all(p[2][o] == 0 for p in plaq for o in range(4))
            ok_per = all(p[2][4] == kc * norm2[p[0]] for p in plaq)
            # gauge invariance to order 6
            gt = [{e: Fr(rg.randint(-6, 6), 4) for e in itertools.product(range(3), repeat=n) if sum(e) <= 2 and rg.random() < 0.7} or {(0,) * n: Fr(1, 3)} for _ in range(3)]
            plg = wilson_series(n, A, y0, gt=gt, variant='LINK' if FAULT == 'LINK' else None)
            SW = [sum(p[2][o] for p in plaq) for o in range(ORD + 1)]; SG = [sum(p[2][o] for p in plg) for o in range(ORD + 1)]
            chk('bit', own_ok and low and c4 == pred and ok_per and SW == SG and c4 > 0,
                'solid.W1: n = %d, field %d: %d plaquette(s); orders 0 .. 3 of 1 - (1/2) tr U_p vanish for every plaquette; the order-4 coefficient %s equals -(1/4) sum tr F^2 = (1/2) sum |F|^2 with F = dA - dA + [A,A] taken from Gauge.Fmn (and equal to the quaternion-table F); the series is unchanged to order 6 by a gauge transformation exp(a lambda)'
                % (n, seed, len(plaq), c4))
            if seed == 0 or n == 2:
                vals = {}
                for a in (1e-2, 1e-3): vals[a] = np_plaquette_action(n, A, y0, a) / a ** 4
                hs = [8e-3 / 2 ** k for k in range(4)]; T = [np_plaquette_action(n, A, y0, h) / h ** 4 for h in hs]
                for lev in range(1, 4): T = [(2 ** lev * T[k + 1] - T[k]) / (2 ** lev - 1) for k in range(len(T) - 1)]
                rich = T[0]; ex = float(c4); rel = abs(rich - ex) / ex
                chk('bit==std', rel < 1e-6, 'solid.W2: n = %d, field %d: numpy/scipy matrix exponentials: S_W/a^4 = %.5f at a = 1e-2, %.5f at a = 1e-3, Richardson extrapolation over a = 8e-3 .. 1e-3 gives %.5f; the exact order-4 coefficient is %.5f; relative difference below 1e-6'
                    % (n, seed, vals[1e-2], vals[1e-3], rich, ex))
    # controls
    rg = random.Random(47 + 200); n = 3; A = rand_field(rg, n); y0 = [Fr(rg.randint(-4, 4), 4) for _ in range(n)]
    gt = [{e: Fr(rg.randint(-6, 6), 4) for e in itertools.product(range(3), repeat=n) if sum(e) <= 2 and rg.random() < 0.7} or {(0,) * n: Fr(1, 3)} for _ in range(3)]
    pl = wilson_series(n, A, y0, variant='LINK'); plg = wilson_series(n, A, y0, gt=gt, variant='LINK'); good = wilson_series(n, A, y0)
    o2 = [p[2][2] for p in pl]; SWb = [sum(p[2][o] for p in pl) for o in range(ORD + 1)]; SGb = [sum(p[2][o] for p in plg) for o in range(ORD + 1)]
    chk('ctl', any(o2) and all(p[2][2] == 0 for p in good) and SWb != SGb, 'solid.W3: n = 3: with the last link of each plaquette not inverted the a^2 coefficient is nonzero on %d of %d plaquettes (it is 0 for the plaquette) and the action changes under a gauge transformation' % (sum(1 for x in o2 if x), len(o2)))
    Y = ym.Gauge(3, n, g=Fr(1)); ab = Fr(0); tot = Fr(0)
    for mu in range(n):
        for nu in range(mu + 1, n):
            fa = [peval(pder_(A[nu][c], mu), y0) - peval(pder_(A[mu][c], nu), y0) for c in range(3)]
            fn = [peval(c, y0) for c in Y.Fmn(A, mu, nu)]
            ab += sum(v * v for v in fa); tot += sum(v * v for v in fn)
    c4 = sum(p[2][4] for p in good)
    chk('ctl', Fr(1, 2) * 2 ** (n - 2) * ab != c4 and Fr(1, 2) * 2 ** (n - 2) * tot == c4, 'solid.W3: n = 3: F without the commutator [A,A] gives the order-4 coefficient %s, the exact one is %s' % (Fr(1, 2) * 2 ** (n - 2) * ab, c4))
    chk('ctl', 2 * c4 != c4 and c4 != 0, 'solid.W3: n = 3: the coefficient -(1/2) tr F^2 (twice the right one) gives %s, not %s' % (2 * c4, c4))
    # staggered phases (bd.phy.16), own code
    ok16 = True; sq = []
    for nn in range(2, 7):
        alg = Alg(tuple([1] * nn)); D = np.zeros((1 << nn, 1 << nn), dtype=np.int64)
        for i in range(nn):
            ok16 &= all(alg.blade_mul(1 << i, x)[0] == (-1) ** pc(x & ((1 << i) - 1)) for x in range(1 << nn))
            D += np.array(regular_matrix(alg, {1 << i: 1}), dtype=np.int64)
        sq.append(np.array_equal(D @ D, nn * np.eye(1 << nn, dtype=np.int64)))
    chk('bit', ok16 and all(sq), 'solid.W4: the sign of e_i on the label x in Cl(n,0) is the Kogut-Susskind phase (-1)^(x_0 + .. + x_{i-1}) for n = 2 .. 6, every i and x, and D = sum_i L_{e_i} has D^2 = n (the staggered operator on the site labels; bd.phy.16 again)')
    ok16s = True
    for nn in range(2, 7):
        N_ = 1 << nn; Dm = np.zeros((N_, N_))
        for x in range(N_):
            for i in range(nn): Dm[x ^ (1 << i), x] += (-1.0) ** bin(x & ((1 << i) - 1)).count('1')
        ok16s &= np.allclose(Dm @ Dm, nn * np.eye(N_))
    chk('std', ok16s, 'solid.W4: numpy: D = sum_i eta_i(x) T_i on the n-cube with eta_i(x) = (-1)^(x_0 + .. + x_{i-1}) has D^2 = n for n = 2 .. 6')
ITEMS.append(item_wilson)

# ================================================================================================ B. Bethe's double groups
class Q5:
    """a + b sqrt(5) with Fractions a, b (the field of the icosians)"""
    __slots__ = ('a', 'b')
    def __init__(self, a=0, b=0): self.a = Fr(a); self.b = Fr(b)
    def __add__(self, o): o = _q5(o); return Q5(self.a + o.a, self.b + o.b)
    __radd__ = __add__
    def __sub__(self, o): o = _q5(o); return Q5(self.a - o.a, self.b - o.b)
    def __rsub__(self, o): return _q5(o) - self
    def __neg__(self): return Q5(-self.a, -self.b)
    def __mul__(self, o): o = _q5(o); return Q5(self.a * o.a + 5 * self.b * o.b, self.a * o.b + self.b * o.a)
    __rmul__ = __mul__
    def __eq__(self, o): o = _q5(o); return self.a == o.a and self.b == o.b
    def __ne__(self, o): return not self.__eq__(o)
    def __hash__(self): return hash((self.a, self.b))
    def __bool__(self): return bool(self.a) or bool(self.b)
    def __float__(self): return float(self.a) + float(self.b) * 5 ** 0.5
    def __repr__(self): return '%s%s' % (self.a, ('%+d*r5' % self.b if self.b.denominator == 1 else '+(%s)*r5' % self.b) if self.b else '')
def _q5(o): return o if isinstance(o, Q5) else Q5(o, 0)

BRC = BR((1, 1, 1))            # the bit rule of Cl(3,0); the even part is the quaternions: i = e2e3, j = e3e1, k = -e1e2
def q_to_dict(t): return {m: c for m, c in ((0, t[0]), (0b110, t[1]), (0b101, -t[2]), (0b011, -t[3])) if c != 0}
def dict_to_q(d, zero):
    return (d.get(0, zero), d.get(0b110, zero), -d.get(0b101, zero), -d.get(0b011, zero))
def prim(t):
    g = 0
    for c in t: g = gcd(g, abs(int(c)))
    return tuple(int(c) // g for c in t)
def closure_group(gens, one, canon, zero):
    def mul(s, t): return canon(dict_to_q(BRC.mul(q_to_dict(s), q_to_dict(t)), zero))
    els = [one]; seen = {one}; fr = [one]
    while fr:
        new = []
        for a in fr:
            for g in gens:
                b = mul(g, a)
                if b not in seen:
                    seen.add(b); els.append(b); new.append(b)
        fr = new
        if len(els) > 400: raise RuntimeError('the generated set is not finite')
    return els, mul
def classes_from_table(T, inv):
    n = len(T); seen = set(); classes = []
    for h in range(n):
        if h in seen: continue
        c = sorted({T[T[g][h]][inv[g]] for g in range(n)}); classes.append(c); seen |= set(c)
    return classes

def cheb_coeffs(nn):
    """U_nn(x) = x^(nn mod 2) * sum_e coeffs[e] y^e with y = x^2"""
    co = {}
    for k in range(nn // 2 + 1):
        pw = nn - 2 * k; co[pw // 2] = co.get(pw // 2, 0) + (-1) ** k * comb(nn - k, k) * 2 ** pw
    return co
def poly_at(co, y):
    tot = 0
    for e, c in co.items(): tot = tot + c * _pw(y, e)
    return tot
def _pw(y, e):
    r = Fr(1) if not isinstance(y, Q5) else Q5(1)
    for _ in range(e): r = r * y
    return r

def exact_gram(ys, nmax):
    """exact inner products <chi_{n1/2}, chi_{n2/2}> over the group for n1 = n2 mod 2, given the list ys of x^2 of its elements"""
    G = {}
    for n1 in range(nmax + 1):
        for n2 in range(n1 % 2, nmax + 1, 2):
            c1, c2 = cheb_coeffs(n1), cheb_coeffs(n2); tot = 0
            for y in ys:
                v = poly_at(c1, y) * poly_at(c2, y)
                if n1 % 2: v = v * y
                tot = tot + v
            G[(n1, n2)] = tot * Fr(1, len(ys)) if not isinstance(tot, Q5) else Q5(tot.a / len(ys), tot.b / len(ys))
    return G

def su2(t):
    w, x, y, z = t
    return np.array([[w - 1j * z, -y - 1j * x], [y - 1j * x, w + 1j * z]])
def float_group(gens):
    key = lambda M: tuple(np.round(M.flatten(), 6).tolist())
    els = [np.eye(2, dtype=complex)]; seen = {key(els[0])}; fr = [els[0]]
    while fr:
        new = []
        for A in fr:
            for g in gens:
                B = g @ A; k = key(B)
                if k not in seen:
                    seen.add(k); els.append(B); new.append(B)
        fr = new
        if len(els) > 400: return None
    return els
def dixon(els):
    """Burnside-Dixon in floats: classes, sizes, character table (rows = irreps, columns = classes), dimensions"""
    key = lambda M: tuple(np.round(M.flatten(), 6).tolist())
    n = len(els); idx = {key(M): i for i, M in enumerate(els)}
    inv = [idx[key(M.conj().T)] for M in els]
    T = np.zeros((n, n), dtype=int)
    for i in range(n):
        for j in range(n): T[i, j] = idx[key(els[i] @ els[j])]
    classes = classes_from_table(T.tolist(), inv); k = len(classes); cl = np.zeros(n, dtype=int)
    for ci, c in enumerate(classes):
        for g in c: cl[g] = ci
    h = np.array([len(c) for c in classes], dtype=float)
    cnt = np.zeros((k, k, k))
    for x in range(n):
        for y in range(n): cnt[cl[x], cl[y], cl[T[x, y]]] += 1
    a = cnt / h[None, None, :]                                    # a[i,j,l] = number of (x in C_i, y in C_j) with xy = z in C_l
    one = cl[idx[key(np.eye(2, dtype=complex))]]
    rg = np.random.default_rng(5); coef = rg.normal(size=k)
    M = sum(coef[i] * a[i] for i in range(k))                     # M[j,l] = sum_i coef_i a[i,j,l]; omega is a right eigenvector with eigenvalue sum coef_i omega_i
    w, V = np.linalg.eig(M)
    chars = []
    for v in V.T:
        om = v / v[one]
        d2 = n / np.sum(np.abs(om) ** 2 / h); d = np.sqrt(d2)
        chars.append(om * d / h)
    return classes, h, np.array(chars), T, inv, cl

def item_bethe():
    head('B. Bethe: the binary tetrahedral, octahedral and icosahedral groups in the even part of Cl(3,0)')
    ident = (1, 0, 0, 0)
    i_, j_, k_ = (0, 1, 0, 0), (0, 0, 1, 0), (0, 0, 0, 1)
    gT = [i_, j_, (1, 1, 1, 1)]                                    # (1 + i + j + k)/2 as a primitive integer representative
    gO = gT + [(1, 1, 0, 0)]                                       # (1 + i)/sqrt 2
    elsT, mulT = closure_group([prim(g) for g in gT], ident, prim, 0)
    elsO, mulO = closure_group([prim(g) for g in gO], ident, prim, 0)
    ph = Q5(Fr(1, 2), Fr(1, 2)); phi_ = Q5(Fr(-1, 2), Fr(1, 2))      # phi = (1 + sqrt 5)/2, 1/phi = (sqrt 5 - 1)/2
    half = Q5(Fr(1, 2)); zero5 = Q5(0)
    q = lambda *c: tuple(_q5(x) for x in c)
    gI = [q(0, 1, 0, 0), q(0, 0, 1, 0), q(half, half, half, half), q(ph * half, half, phi_ * half, 0)]
    one5 = q(1, 0, 0, 0)
    try:
        elsI, mulI = closure_group(gI, one5, lambda t: t, zero5)
    except RuntimeError:
        elsI, mulI = [], None
    orders = (len(elsT), len(elsO), len(elsI))
    chk('bit', orders == (24, 48, 120), 'solid.B1: closure in the even part of Cl(3,0) (BR((1,1,1)), exact): 2T = <i, j, (1+i+j+k)/2> has %d elements, 2O = 2T + (1+i)/sqrt2 has %d (rational representatives up to positive scaling), 2I = 2T + (phi + i + j/phi)/2 has %d (coefficients in Q(sqrt5))' % orders)
    data = {}
    for name, els, mul in (('2T', elsT, mulT), ('2O', elsO, mulO), ('2I', elsI, mulI)):
        n = len(els)
        if isinstance(els[0][0], Q5): ys = [e[0] * e[0] for e in els]; one = one5; neg = tuple(-c for c in one5)
        else: ys = [Fr(e[0] ** 2, sum(c * c for c in e)) for e in els]; one = ident; neg = (-1, 0, 0, 0)
        idx = {e: i for i, e in enumerate(els)}
        T = [[idx[mul(els[a], els[b])] for b in range(n)] for a in range(n)]
        conj = lambda e: tuple((c if t == 0 else -c) for t, c in enumerate(e))
        inv = [idx[prim(conj(e)) if not isinstance(e[0], Q5) else conj(e)] for e in els]
        classes = classes_from_table(T, inv)
        negi = idx[prim(neg) if not isinstance(neg[0], Q5) else neg]
        # trace of the rotation matrix: 4 x^2 - 1
        tr = [4 * y - 1 for y in ys]
        integral = all((t.b == 0 and t.a.denominator == 1) if isinstance(t, Q5) else t.denominator == 1 for t in tr)
        data[name] = {'els': els, 'ys': ys, 'classes': classes, 'T': T, 'inv': inv, 'negi': negi, 'integral': integral, 'tr': tr}
    want_cls = {'2T': 7, '2O': 8, '2I': 9}
    for name in ('2T', '2O', '2I'):
        d = data[name]; sizes = sorted(len(c) for c in d['classes'])
        chk('bit', len(d['classes']) == want_cls[name], 'solid.B2: %s: order %d, %d conjugacy classes (sizes %s); the central element -1 is element %d' % (name, len(d['els']), len(d['classes']), sizes, d['negi']))
        distinct = sorted({str(t) for t in d['tr']})
        chk('bit', d['integral'] == (name != '2I'), 'solid.B2: %s: the traces 4x^2 - 1 of the rotation matrices are %s: %s' % (name, 'all integers (a crystallographic point group)' if d['integral'] else 'not all integers (they contain sqrt 5: not a lattice point group)', distinct))
    # exact inner products of the restrictions of the SU(2) characters
    NM = 9
    gram = {nm: exact_gram(data[nm]['ys'], NM) for nm in data}
    def gi(nm, n1, n2):
        v = gram[nm][(n1, n2)]
        assert (not isinstance(v, Q5) and v.denominator == 1) or (isinstance(v, Q5) and v.b == 0 and v.a.denominator == 1), (nm, n1, n2, v)
        return int(v.a if isinstance(v, Q5) else v)
    nrm = {nm: [gi(nm, n, n) for n in range(NM + 1)] for nm in data}
    exp32 = {'2T': 2, '2O': 1, '2I': 1}
    for nm in data:
        ok = nrm[nm][3] == exp32[nm] and nrm[nm][1] == 1 and nrm[nm][0] == 1
        chk('bit', ok, 'solid.B3: %s: <chi_j, chi_j> for j = 0, 1/2, .., 9/2 (exact): %s; j = 1/2 irreducible; j = 3/2 has norm %d (%s)' % (nm, nrm[nm], exp32[nm], 'irreducible, dimension 4' if exp32[nm] == 1 else 'two different irreducible pieces'))
    g2O = gi('2O', 5, 3), gi('2O', 5, 1), gi('2O', 5, 5), gi('2O', 3, 1)
    ok = g2O[0] == 1 and g2O[1] == 0 and g2O[2] == 2 and g2O[3] == 0 and (g2O[2] - 2 * g2O[0] + nrm['2O'][3]) == 1
    chk('bit', ok, 'solid.B3: 2O: <chi_5/2, chi_3/2> = %d, <chi_5/2, chi_1/2> = %d, norm of chi_5/2 = %d, so chi_5/2 - chi_3/2 has norm 1: j = 5/2 = G7 + G8 with G8 = j = 3/2 (dimension 4) and G7 new (dimension 2)' % (g2O[0], g2O[1], g2O[2]))
    # single-valued against double-valued: the pairs g, -g
    ok = True
    for nm in data:
        d = data[nm]; ok &= all(d['T'][d['negi']][g] != g for g in range(len(d['els']))) and all(d['T'][d['negi']][d['T'][d['negi']][g]] == g for g in range(len(d['els'])))
    chk('bit', ok, 'solid.B3: in each group g -> -g is a fixed-point-free involution; chi_j(-g) = (-1)^(2j) chi_j(g), so the restrictions of integer j are orthogonal to those of half-integer j (the sum over g and -g cancels)')
    # [std] numpy
    phi = (1 + 5 ** 0.5) / 2
    gs = {'2T': [su2(i_), su2(j_), su2((.5, .5, .5, .5))]}
    gs['2O'] = gs['2T'] + [su2((2 ** -0.5, 2 ** -0.5, 0, 0))]
    gs['2I'] = [su2(i_), su2(j_), su2((.5, .5, .5, .5)), su2((phi / 2, .5, .5 / phi, 0))]
    from scipy.special import eval_chebyu
    for nm in ('2T', '2O', '2I'):
        els = float_group(gs[nm]); n = len(els)
        classes, h, chars, T, inv, cl = dixon(els)
        k = len(classes)
        one = next(i for i, M in enumerate(els) if np.allclose(M, np.eye(2))); neg = next(i for i, M in enumerate(els) if np.allclose(M, -np.eye(2)))
        dims = sorted(int(round(abs(c[cl[one]]))) for c in chars)
        orth = np.allclose((chars * h[None, :]) @ chars.conj().T / n, np.eye(k), atol=1e-8)
        dimsq = sum(d * d for d in dims)
        spin = [bool(np.real(c[cl[neg]]) < 0) for c in chars]
        want_dims = {'2T': [1, 1, 1, 2, 2, 2, 3], '2O': [1, 1, 2, 2, 2, 3, 3, 4], '2I': [1, 2, 2, 3, 3, 4, 4, 5, 6]}[nm]
        chk('std', n == len(data[nm]['els']) and k == want_cls[nm] and orth and dimsq == n and dims == want_dims, 'solid.B4: %s: numpy 2 x 2 unit-quaternion matrices: %d elements, %d classes, Burnside-Dixon character table orthonormal, irrep dimensions %s (sum of squares %d), %d double-valued irreps (chi(-1) = -chi(1))' % (nm, n, k, dims, dimsq, sum(spin)))
        mult = {}
        for nn in range(NM + 1):
            vals = np.array([eval_chebyu(nn, np.real(np.trace(els[g])) / 2) for g in [c[0] for c in classes]])
            if FAULT == 'ANGLE': vals = np.array([eval_chebyu(nn, np.sqrt((1 + np.real(np.trace(els[g])) / 2) / 2)) for g in [c[0] for c in classes]])
            m_ = (chars.conj() * (h * vals)[None, :]).sum(axis=1) / n
            mult[nn] = m_
        integral = all(np.all(np.abs(m_ - np.round(m_.real)) < 1e-8) for m_ in mult.values())
        chk('bit==std', integral and all(gi(nm, a, b) == int(round(float(np.sum(np.round(mult[a].real) * np.round(mult[b].real))))) for a in range(NM + 1) for b in range(a % 2, NM + 1, 2)),
            'solid.B5: %s: the multiplicities of the restricted characters j = 0 .. 9/2 in the irreps of the float table are integers, and sum_a m_a(j) m_a(j\') equals the exact inner product <chi_j, chi_j\'> for every pair of equal parity' % nm)
        dimv = [int(round(abs(chars[a][cl[one]]))) for a in range(k)]
        def pieces(nn):
            return [(a, int(round(mult[nn][a].real))) for a in range(k) if int(round(mult[nn][a].real)) > 0]
        # the irreps in the order of first appearance among the half-integer j
        first = []
        for nn in range(1, NM + 1, 2):
            for a, m_ in pieces(nn):
                if a not in first: first.append(a)
        name_of = {a: 'G%d' % dimv[a] + "'" * sum(1 for b in first[:first.index(a)] if dimv[b] == dimv[a]) for a in first}
        if nm == '2O':
            d2 = [a for a in first if dimv[a] == 2]
            lab = {a: ('G6' if r_ == 0 else 'G7') for r_, a in enumerate(d2[:2])}
            lab.update({a: 'G8' for a in first if dimv[a] == 4}); name_of = lab
        tab = {}
        for nn in range(1, NM + 1, 2):
            tab[nn] = ' + '.join(('%d ' % m_ if m_ > 1 else '') + name_of.get(a, '?') for a, m_ in sorted(pieces(nn), key=lambda am: name_of.get(am[0], '?')))
        chk('std', all(sum(m_ * dimv[a] for a, m_ in pieces(nn)) == nn + 1 for nn in range(NM + 1)), 'solid.B6: %s: splitting of the restriction of j (dimension 2j + 1 = the sum of the dimensions): %s' % (nm, '; '.join('j = %d/2: %s' % (nn, tab[nn]) for nn in range(1, NM + 1, 2))))
        if nm == '2O':
            rec = {1: {'G6': 1}, 3: {'G8': 1}, 5: {'G7': 1, 'G8': 1}, 7: {'G6': 1, 'G7': 1, 'G8': 1}}
            got = {nn: {name_of.get(a, '?'): m_ for a, m_ in pieces(nn)} for nn in rec}
            chk('bit==std', got == rec and sorted(spin) == [False] * 5 + [True] * 3, 'solid.B6: 2O: the splittings j = 1/2 .. 7/2 are G6, G8, G7 + G8, G6 + G7 + G8 (recalled from the tables of Bethe and of Koster, Dimmock, Wheeler and Statz), the double-valued irreps have dimensions 2, 2, 4 and the single-valued ones 1, 1, 2, 3, 3')
        if nm == '2T':
            ok = tab[3].count('+') == 1 and all(dimv[a] == 2 for a, m_ in pieces(3)) and len(pieces(3)) == 2
            chk('bit==std', ok, 'solid.B6: 2T: j = 3/2 splits into two different 2-dimensional irreps (a complex-conjugate pair: together a Kramers-degenerate quartet)')
        data[nm]['float'] = (els, cl, neg, one, chars)
    # controls
    els = data['2I']['float'][0]
    ck = lambda M: tuple(np.round(np.concatenate([M.real.flatten(), M.imag.flatten()]), 6).tolist())
    S60 = [M if ck(M) >= ck(-M) else -M for M in els]; S60 = list({ck(M): M for M in S60}.values()); keyset = {tuple(np.round(M.flatten(), 6).tolist()) for M in S60}
    notclosed = sum(1 for A in S60 for B in S60 if tuple(np.round((A @ B).flatten(), 6).tolist()) not in keyset)
    if FAULT == 'OPEN': chk('bit', notclosed == 0, 'solid.B1: the 60 lifts (one per rotation) are closed under products, so they form a group of order 60')
    chk('ctl', len(S60) == 60 and notclosed > 0, 'solid.B7: one lift per rotation of the icosahedral group gives a set of %d unit quaternions that is not closed (%d of %d products leave it): the 60 rotations have no section into SU(2), so there is no group of order 60 and no character table of it' % (len(S60), notclosed, 60 * 60))
    for nm in ('2T', '2O', '2I'):
        els, cl, neg, one, chars = data[nm]['float']; k = chars.shape[0]
        sp = [a for a in range(k) if np.real(chars[a][cl[neg]]) < 0]
        n = len(els); h = np.bincount(cl)
        vals = np.array([eval_chebyu(2, np.real(np.trace(els[next(g for g in range(n) if cl[g] == c)])) / 2) for c in range(k)])
        msp = [(chars[a].conj() * h * vals).sum() / n for a in sp]
        pv = FAULT == 'PARITY'
        claim = any(abs(m_) > 1e-8 for m_ in msp) if pv else all(abs(m_) < 1e-8 for m_ in msp)
        chk('ctl', claim, 'solid.B7: %s: the restriction of j = 1 (single-valued) contains none of the %d double-valued irreps (multiplicities %s)' % (nm, len(sp), [round(float(abs(m_)), 6) for m_ in msp]))
    # a wrong angle in the characters gives non-integer multiplicities
    els, cl, neg, one, chars = data['2I']['float']; k = chars.shape[0]; n = len(els); h = np.bincount(cl)
    wrong = []
    for nn in range(1, 6):
        vals = np.array([eval_chebyu(nn, np.sqrt((1 + np.real(np.trace(els[next(g for g in range(n) if cl[g] == c)])) / 2) / 2)) for c in range(k)])
        wrong.append(max(abs((chars[a].conj() * h * vals).sum() / n - round(((chars[a].conj() * h * vals).sum() / n).real)) for a in range(k)))
    chk('ctl', max(wrong) > 1e-3, 'solid.B7: characters with the half angle taken twice (sin((2j+1)theta/4)/sin(theta/4) in place of sin((2j+1)theta/2)/sin(theta/2)) give non-integer multiplicities in the table of 2I (largest distance from an integer %.3f)' % max(wrong))
    # bd.sol.21 and 22 again, own code
    o = {}
    for nm_, eps in (('Cl(0,3)', (-1, -1, -1)), ('Cl(3,0)', (1, 1, 1))):
        A = Alg(eps); prof = {}
        for a in range(8):
            for sgn in (1, -1):
                od = 1 if (a == 0 and sgn == 1) else (2 if A.sq(a) == 1 else 4)
                prof[od] = prof.get(od, 0) + 1
        o[nm_] = dict(sorted(prof.items()))
    chk('bit', o['Cl(0,3)'] == {1: 1, 2: 3, 4: 12} and o['Cl(3,0)'] == {1: 1, 2: 7, 4: 8}, 'solid.B8: the 16 elements +-e_a of Cl(0,3) have orders %s (Q8 x Z2: the mirror lifts with inversion +1) and those of Cl(3,0) orders %s (the Pauli group: inversion i); bd.sol.21 again' % (o['Cl(0,3)'], o['Cl(3,0)']))
    perms = [np.eye(3, dtype=int)[list(p)] for p in itertools.permutations(range(3))]
    B3 = [np.diag(s) @ P for s in itertools.product((1, -1), repeat=3) for P in perms]
    rot = [g for g in B3 if round(np.linalg.det(g)) == 1]
    def order_of(M):
        k_, X = 1, M.copy()
        while not np.array_equal(X, np.eye(3, dtype=int)): X = X @ M; k_ += 1
        return k_
    prof = {}
    for g in rot: prof[order_of(g)] = prof.get(order_of(g), 0) + 1
    chk('bit', len(B3) == 48 and any(np.array_equal(g, -np.eye(3, dtype=int)) for g in B3) and len(rot) == 24 and dict(sorted(prof.items())) == {1: 1, 2: 9, 3: 8, 4: 6}, 'solid.B8: the signed permutation matrices of 3 axes: %d elements, containing the inversion; rotations %d with orders %s (O_h and O; bd.sol.22 again)' % (len(B3), len(rot), dict(sorted(prof.items()))))
ITEMS.append(item_bethe)

# ================================================================================================ T. the ten symmetry classes against the clock
AZ = [('AI', 1, 0), ('BDI', 1, 1), ('D', 0, 1), ('DIII', -1, 1), ('AII', -1, 0), ('CII', -1, -1), ('C', 0, -1), ('CI', 1, -1)]     # name, T^2, C^2 (0: absent)
def az_cell(t, c, jsq=-1):
    """squares of the mutually anticommuting generators J, T, C of the symmetry algebra of the class (those that exist)"""
    eps = [jsq] + ([t] if t else []) + ([c] if c else [])
    return sum(1 for e in eps if e == 1), sum(1 for e in eps if e == -1)
def az_types(table, jsq=-1):
    out = []
    for (name, t, c) in table:
        p, q = az_cell(t, c, jsq); r = module_type(p, q)
        out.append((name, p, q, r['type'], int(r['summands']), r['m'], r['d'], (p - q) % 8))
    return out

def item_tenfold():
    head('T. The ten Altland-Zirnbauer classes: the symmetry algebra of a class from (T^2, C^2) against the clock table')
    table = list(AZ)
    if FAULT == 'SWAP': table[3] = ('DIII', 1, 1)
    jsq = 1 if FAULT == 'JSQ' else -1
    got = az_types(table, jsq)
    want = [TYPES[s] for s in range(8)]
    for s, (name, p, q, ty, sm, m, d, cc) in enumerate(got):
        w = want[s]
        ok = ty == BASE[w] and sm == (2 if w.endswith('2') else 1)
        chk('bit', ok, 'solid.T1: %s (T^2, C^2) = (%s, %s): generators (J, T, C as present) anticommuting with squares (-1%s%s) = the cell Cl(%d,%d), clock %d: minimal module of dimension %d, commutant of dimension %d, type %s, %d summand(s); clock table at c = %d: %s'
            % (name, '%+d' % table[s][1] if table[s][1] else '0', '%+d' % table[s][2] if table[s][2] else '0', ', %+d' % table[s][1] if table[s][1] else '', ', %+d' % table[s][2] if table[s][2] else '', p, q, cc, m, d, ty, sm, s, w))
    # T2: the phase of T: T and JT have the same square, and C commutes with one of them and anticommutes with the other
    ok2 = True
    for (name, t, c) in AZ:
        if not (t and c): continue
        eps = [-1, t, c]
        # build the algebra with generators in the order J, T, C: squares (-1, t, c) in this order
        A2 = Alg(tuple(eps)); J, T, C = 1, 2, 4
        jt = A2.mul({J: 1}, {T: 1}); (mjt, cjt), = jt.items()
        ok2 &= A2.comm_sign(J, T) == -1 and A2.comm_sign(J, C) == -1 and A2.comm_sign(T, C) == -1
        ok2 &= A2.sq(mjt) == t and A2.comm_sign(mjt, C) == 1 and A2.comm_sign(mjt, J) == -1
        S = A2.mul(jt, {C: 1}); (ms, cs), = S.items()
        ok2 &= A2.comm_sign(ms, J) == 1 and A2.sq(ms) == t * c
    chk('bit', ok2, 'solid.T2: with both T and C the generators J, T, C anticommute; JT has the square T^2, is antilinear (anticommutes with J) and commutes with C, and S = (JT) C commutes with J and has S^2 = T^2 C^2: the algebra does not depend on the phase of T')
    # T3: the exchange of T^2 and C^2
    idx = {(t, c): s for s, (name, t, c) in enumerate(AZ)}
    swap_ok = all(idx[(c, t)] == (2 - s) % 8 for s, (name, t, c) in enumerate(AZ))
    pal = all(TYPES[s] == TYPES[(2 - s) % 8] for s in range(8))
    same_cell = all(sorted(az_cell(t, c)) == sorted(az_cell(c, t)) for (name, t, c) in AZ)
    seq = [(r[3], r[4]) for r in got]; clk = [(BASE[t], 2 if t.endswith('2') else 1) for t in TYPES]
    fits = [(a, dr) for a in range(8) for dr in (1, -1) if all(clk[(a + dr * s) % 8] == seq[s] for s in range(8))]
    ok3 = swap_ok and pal and same_cell and fits == [(0, 1), (2, -1)]
    chk('bit', ok3, 'solid.T3: exchanging the labels T^2 and C^2 maps the class at position s to the class at 2 - s (mod 8) and gives the same cell; the clock table has TYPES[s] = TYPES[2 - s] for all s; the computed list of (type, summands) along AI .. CI fits the clock table at exactly %d of the 16 alignments c = a + s and c = a - s, namely %s: forward from c = 0 and, by the reflection, backward from c = 2, so the types fix the alignment up to that reflection and not its direction' % (len(fits), ' and '.join('c = %d %s s' % (a, '+' if dr == 1 else '-') for a, dr in fits)))
    # T4: the complex classes
    def cplx(gens, m):
        basis = commutant_basis(gens, m); ty, _ = classify(basis, m)
        alg = np.array([np.eye(m, dtype=np.int64).flatten()] + [g.flatten() for g in gens] + [(a @ b).flatten() for a in gens for b in gens])
        dim = np.linalg.matrix_rank(alg.astype(float))
        return ty, len(basis), Fr(dim * len(basis), m * m)
    Ej = np.array([[0, -1], [1, 0]], dtype=np.int64); I2 = np.eye(2, dtype=np.int64)
    A_ty, A_d, A_s = cplx([Ej], 2)
    S4 = cplx([Ej, I2], 2)
    # AIII: J and S commuting, S^2 = +1, acting on the two eigenspaces of S: the algebra {1, J, S, JS} has dimension 4
    Sfull = np.kron(I2, np.diag([1, -1])).astype(np.int64); Jfull = np.kron(Ej, I2)
    dimAIII = np.linalg.matrix_rank(np.array([np.eye(4).flatten(), Jfull.flatten(), Sfull.flatten(), (Jfull @ Sfull).flatten()], dtype=float))
    ok4 = A_ty == 'C' and A_d == 2 and A_s == 1 and dimAIII == 4 and S4[0] == 'C' and S4[1] == 2 and Fr(dimAIII * 2, 4) == 2
    chk('bit', ok4, 'solid.T4: A (J alone): commutant C, %s summand; AIII (J and a unitary S with S^2 = 1 commuting with it, the algebra {1, J, S, JS} of dimension %d): minimal module R^2 with commutant C, %s summands: the complex classes are C and C + C' % (A_s, dimAIII, Fr(dimAIII * 2, 4)))
    # T5 [std]: numpy real matrices and the label table
    ok5 = True; lines = []
    for s, (name, t, c) in enumerate(AZ):
        eps = [-1] + ([t] if t else []) + ([c] if c else [])
        gens, m = find_real_rep(eps); dstd = np_commutant_dim(gens, m); sm = Fr((1 << len(eps)) * dstd, m * m)
        ok5 &= (dstd == DIMK[BASE[TYPES[s]]]) and sm == (2 if TYPES[s].endswith('2') else 1) and dstd == got[s][6] and int(sm) == got[s][4]
        lines.append('%s %d/%s' % (name, dstd, sm))
    wd = {'AI': 'R', 'A': 'C', 'AII': 'H'}
    ok5 &= BASE[TYPES[0]] == wd['AI'] and BASE[TYPES[4]] == wd['AII'] and A_ty == wd['A']
    chk('std', ok5, 'solid.T5: numpy real Kronecker matrices for the same generators, commutant dimension by SVD and summands: ' + ', '.join(lines) + '; the Wigner-Dyson classes AI, A, AII are R, C, H (the threefold way, recalled)')
    # T6: the edge leg, bd.sol.1 .. 3 run again
    import sol_fk_clock as sfk
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf): sfk.check1(); sfk.check2(); sfk.check3()
    out = buf.getvalue()
    chk('bit', all(('ok   bd·sol·%d' % k) in out for k in (1, 2, 3)) and not sfk.FAILS, 'solid.T6: bd.sol.1 .. 3 are run again: the T-invariant real algebra of p T-even and q T-odd Majoranas is Cl(p,q); (T^2, T against P) = (+1, commute), (+1, anti), (-1, commute), (-1, anti) at c = 0, 2, 4, 6; the generic level degeneracy of T-invariant parity-even Hamiltonians is 1 exactly when c = 0 mod 8 and 2 at every other even clock (n even <= 10)')
    # controls
    bad = [i for i in range(8) if az_types([('DIII', 1, 1) if k == 3 else AZ[k] for k in range(8)])[i][3:5] != (BASE[want[i]], 2 if want[i].endswith('2') else 1)]
    chk('ctl', len(bad) > 0, 'solid.T6: DIII given the labels of BDI breaks the list at position(s) %s' % bad)
    bad2 = [i for i in range(8) if az_types(AZ, 1)[i][3:5] != (BASE[want[i]], 2 if want[i].endswith('2') else 1)]
    chk('ctl', len(bad2) > 0, 'solid.T6: J^2 = +1 in place of -1 breaks the list at %d of the 8 positions' % len(bad2))
ITEMS.append(item_tenfold)

# ================================================================================================ main
FAULT_ITEM = {'NONMIN': 'kramers', 'CLOCK': 'kramers', 'KRAM': 'kramers', 'FS': 'kramers', 'ODD': 'hubbard', 'PAIR': 'hubbard', 'COEF': 'hubbard',
              'SWAP': 'tenfold', 'JSQ': 'tenfold', 'LINK': 'wilson', 'ABEL': 'wilson', 'WCOEF': 'wilson', 'OPEN': 'bethe', 'ANGLE': 'bethe', 'PARITY': 'bethe'}
if __name__ == '__main__':
    only = [a for a in ARGS if a.startswith('--only=')]
    sel = only[0][7:].split(',') if only else None
    if FAULT: sel = [FAULT_ITEM[FAULT]]
    for it in ITEMS:
        if sel is None or it.__name__.replace('item_', '') in sel: it()
    finish('SOLID')
