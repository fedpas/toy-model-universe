#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""atiyah_config.py: Atiyah's determinant of a configuration of points in R^3 (the Berry-Robbins problem), computed exactly on the labels.
python3 atiyah_config.py [--fault NAME]

The construction (Atiyah; Eastwood and Norbury, "A proof of Atiyah's conjecture on configurations of four points in Euclidean three-space",
read): for distinct points x_1 .. x_n, the unit vector u_ij = (x_j - x_i)/|x_j - x_i| is a point of the Riemann sphere; lifted to a unit
spinor w_ij in C^2 (the Hopf map, up to a phase) with the reverse view w_ji = sigma(w_ij) = (-conj w_2, conj w_1), the polynomial
p_i = prod_(j != i) (w_ij,1 z + w_ij,2) of degree n - 1 is a row of an n x n matrix M, and Atiyah's conjecture is det M != 0 for every
configuration; with unit lifts det M is the normalised determinant D of Atiyah and Sutcliffe (Euclidean invariant, conjugated by
reflections).  Read: for n = 3, det M = d_3(a,b,c) + 8abc with d_3 = (a+b-c)(b+c-a)(c+a-b) in the normalisation of the paper (equation (2)),
so D = 1 + d_3/(8abc); Theorem 1 of the paper: for n = 4, Re(det M) >= 60 r_21 r_31 r_32 r_41 r_42 r_43, i.e. Re D >= 15/16; Conjecture 2
(Atiyah-Sutcliffe): |D| >= 1; Conjecture 3: |det M|^2 >= prod over the four faces of (d_3 + 8 r r r); collinear points: d_3 = 0, D = 1.
On the labels: the unit vector u is the Pauli vector u.e of Cl(3,0) (the bit rule), its eigen-spinor is (1 + u.e) f_0 with f_0 = (1 + e_3)/2
in the minimal left ideal Cl f_0 = C^2 (the complex unit I = e_123, central, I^2 = -1), with coordinates [1 + u_3 : u_1 + I u_2] in the basis
f_0, e_1 f_0 (e_2 f_0 = I e_1 f_0 by the bit rule): the stereographic spinor, read off the bit-rule product; at u = -e_3, where (1 + u.e) f_0 = 0,
the lift is (1 + u.e) e_1 f_0 = [u_1 - I u_2 : 1 - u_3], the same ray in the other chart (the determinant does not see the phase of a lift).  The products and the determinant are computed in the centre R + R I
of Cl(3,0) by the bit rule (Gaussian rationals), and the unit normalisation by |w|^2 = 2(1 + u_3), rational.  Exact configurations: those
with rational pairwise distances and rational coordinates (Heronian triangles, collinear points, points on the unit circle at the doubled
angles of Pythagorean triples, with the apexes (0, 0, +-3/4) at distance 5/4 from them).
C1. the lift: the bit-rule eigen-spinor equals the stereographic spinor on 200 rational directions (both charts); the Hopf map returns u,
    and sigma reverses the direction.
C2. collinear points: D = 1 exactly, n = 2 .. 6 (12 configurations); Heronian triangles: D = 1 + d_3/(8abc) exactly (8 triangles), 1 exactly
    for the degenerate (collinear) triangle.
C3. exact configurations (circle points and apexes), n = 4 .. 7 (36 configurations, 12 of them coplanar): D != 0; |D|^2 >= 1 (Conjecture 2)
    and, for n = 4, Re D >= 15/16 (Theorem 1) and Conjecture 3, exactly; D real on the coplanar ones and conjugated by the reflection z -> -z;
    D invariant under a rational rotation, exactly.
C4. [std] numpy, unit lifts by the stereographic formula (no label): the n = 3 formula at 100 random triangles (1e-9); 300 random
    tetrahedra: Re D >= 15/16 and |D| >= 1; 100 random configurations each for n = 5, 6, 7: |D| >= 1 (the conjecture, at these points);
    D invariant under a random rotation and translation, conjugated by a reflection.
[ctl]  NOFLIP (w_ji = w_ij: det = 0 for n = 2, the n = 3 formula fails), NOSIGMA (w_ji by the formula on its own: |D| keeps, the phase of D is not
       invariant under a rational rotation).
Standard library and numpy.   Command: python3 atiyah_config.py   (from this folder, or python3 selfcheck/proofs/atiyah_config.py from the root
of the checks)."""
import os, sys, itertools, random, time, math
from fractions import Fraction as Fr
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here)
_p = os.path.join(_selfcheck, 'steps15_17')
if not os.path.isdir(_p): raise SystemExit(_p + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
sys.path.insert(0, _p)
from bitcliff import Alg, sig, pc

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('NOFLIP', 'NOSIGMA')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
T0 = time.time()

# ------------------------------------------------------------------------------------------------ the labels: Cl(3,0), the centre R + R I, the ideal Cl f_0
ALG = Alg(sig(3, 0)); I_ = 7; F0 = {0: Fr(1, 2), 4: Fr(1, 2)}                       # f_0 = (1 + e_3)/2
def cmul(x, y):
    """product of two elements a + b I of the centre, by the bit rule"""
    return ALG.mul({0: x[0], I_: x[1]}, {0: y[0], I_: y[1]})
def c_of(mv): return (mv.get(0, Fr(0)), mv.get(I_, Fr(0)))
def cm(x, y): return c_of(cmul(x, y))
def cadd(x, y): return (x[0] + y[0], x[1] + y[1])
def cneg(x): return (-x[0], -x[1])
def cconj(x): return (x[0], -x[1])
def cinv(x): n = x[0] * x[0] + x[1] * x[1]; return (x[0] / n, -x[1] / n)
def cabs2(x): return x[0] * x[0] + x[1] * x[1]
E_ = [{1: Fr(1)}, {2: Fr(1)}, {4: Fr(1)}]
IDEAL_BASIS = [F0, ALG.mul({I_: Fr(1)}, F0), ALG.mul(E_[0], F0), ALG.mul({I_: Fr(1)}, ALG.mul(E_[0], F0))]   # f_0, I f_0, e_1 f_0, I e_1 f_0
def coords_in_ideal(mv):
    """the coordinates (a, b, c, d) with mv = (a + b I) f_0 + (c + d I) e_1 f_0, by exact elimination on the 8 labels"""
    rows = [[B.get(l, Fr(0)) for B in IDEAL_BASIS] + [mv.get(l, Fr(0))] for l in range(8)]
    piv = []; rk = 0
    for c in range(4):
        p = next((i for i in range(rk, 8) if rows[i][c] != 0), None)
        if p is None: continue
        rows[rk], rows[p] = rows[p], rows[rk]; pv = rows[rk][c]; rows[rk] = [v / pv for v in rows[rk]]
        for i in range(8):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [u - f * v for u, v in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    assert rk == 4 and all(all(v == 0 for v in r[:4]) and r[4] == 0 for r in rows[4:]), 'not in the ideal'
    sol = [Fr(0)] * 4
    for i, c in enumerate(piv): sol[c] = rows[i][4]
    return sol
def lift_bit(u):
    """the eigen-spinor (1 + u.e) f_0 as (w_1, w_2) in (R + R I)^2; at u = -e_3 the eigen-spinor (1 + u.e) e_1 f_0 (the other chart)"""
    ue = {0: Fr(1)}
    for i in range(3):
        if u[i]: ue[1 << i] = Fr(u[i])
    gen = F0 if 1 + Fr(u[2]) != 0 else ALG.mul(E_[0], F0)
    a, b, c, d = coords_in_ideal(ALG.mul(ue, gen))
    return ((a, b), (c, d))
def lift_std(u):
    if 1 + Fr(u[2]) != 0: return ((1 + Fr(u[2]), Fr(0)), (Fr(u[0]), Fr(u[1])))       # [1 + u_3 : u_1 + I u_2]
    return ((Fr(u[0]), -Fr(u[1])), (1 - Fr(u[2]), Fr(0)))                                # [u_1 - I u_2 : 1 - u_3] (the other chart)
def sigma(w):
    if FAULT == 'NOFLIP': return w
    return (cneg(cconj(w[1])), cconj(w[0]))
def hopf(w):
    """h(w) = (2 Re(conj w_1 w_2), 2 Im(conj w_1 w_2), |w_1|^2 - |w_2|^2) / |w|^2 = (w^dagger e_k w)/|w|^2: the direction of a spinor"""
    z = cm(cconj(w[0]), w[1]); n = cabs2(w[0]) + cabs2(w[1])
    return (2 * z[0] / n, 2 * z[1] / n, (cabs2(w[0]) - cabs2(w[1])) / n)

# ------------------------------------------------------------------------------------------------ the determinant over R + R I
def poly_mul(p, q):
    out = [(Fr(0), Fr(0))] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q): out[i + j] = cadd(out[i + j], cm(a, b))
    return out
def det_c(M):
    n = len(M); M = [list(r) for r in M]; det = (Fr(1), Fr(0))
    for c in range(n):
        p = next((i for i in range(c, n) if M[i][c] != (0, 0)), None)
        if p is None: return (Fr(0), Fr(0))
        if p != c: M[c], M[p] = M[p], M[c]; det = cneg(det)
        det = cm(det, M[c][c]); inv = cinv(M[c][c])
        for i in range(c + 1, n):
            if M[i][c] != (0, 0):
                f = cm(M[i][c], inv); M[i] = [cadd(u, cneg(cm(f, v))) for u, v in zip(M[i], M[c])]
    return det
def dist(x, y): return sum((a - b) ** 2 for a, b in zip(x, y))
def qsqrt(q):
    q = Fr(q); a, b = math.isqrt(q.numerator), math.isqrt(q.denominator); assert Fr(a, b) ** 2 == q, 'not a rational square: %s' % q; return Fr(a, b)
def atiyah_D(X, lift=lift_bit):
    """the normalised determinant D of a configuration with rational pairwise distances, exactly, as (re, im)"""
    n = len(X); W = {}; norm2 = Fr(1)
    for i in range(n):
        for j in range(i + 1, n):
            v = [X[j][k] - X[i][k] for k in range(3)]; r = qsqrt(dist(X[i], X[j])); u = [c / r for c in v]
            w = lift(u); W[(i, j)] = w
            W[(j, i)] = sigma(w) if FAULT != 'NOSIGMA' else lift([-c for c in u])
            norm2 *= (cabs2(w[0]) + cabs2(w[1]))
            if FAULT == 'NOSIGMA': norm2 = norm2 / (cabs2(w[0]) + cabs2(w[1])) * qsqrt((cabs2(w[0]) + cabs2(w[1])) * (cabs2(W[(j, i)][0]) + cabs2(W[(j, i)][1])))
    rows = []
    for i in range(n):
        p = [(Fr(1), Fr(0))]
        for j in range(n):
            if j != i: p = poly_mul(p, [W[(i, j)][0], W[(i, j)][1]])
        rows.append(p)
    d = det_c(rows); inv = cinv((norm2, Fr(0))); return cm(d, inv)
def d3(a, b, c): return (a + b - c) * (b + c - a) * (c + a - b)

head('C1. the lift on the labels against the stereographic spinor, and the reverse view')
rg = random.Random(3); okl = True; oks = True; ndir = 0
def rand_unit(rg):
    # a rational point of the unit sphere: (2a, 2b, 1 - a^2 - b^2)/(1 + a^2 + b^2)
    a, b = Fr(rg.randint(-9, 9), rg.randint(1, 5)), Fr(rg.randint(-9, 9), rg.randint(1, 5)); s = 1 + a * a + b * b
    return [2 * a / s, 2 * b / s, (1 - a * a - b * b) / s]
for _ in range(200):
    u = rand_unit(rg); ndir += 1
    if ndir == 1: u = [Fr(0), Fr(0), Fr(-1)]                                         # the other chart, once
    wb = lift_bit(u); ws = lift_std(u); okl &= wb == ws
    h = hopf(wb); oks &= h == tuple(u) and hopf(sigma(wb) if FAULT != 'NOFLIP' else (cneg(cconj(wb[1])), cconj(wb[0]))) == tuple(-c for c in u)
chk('bit==std', okl, 'cfg.C1: the eigen-spinor (1 + u.e) f_0 of the bit rule, read in the basis f_0, e_1 f_0 of the ideal Cl f_0 = C^2 (I = e_123), equals the stereographic spinor [1 + u_3 : u_1 + I u_2] on %d rational unit vectors (one of them -e_3, in the other chart)' % ndir)
chk('bit', oks, 'cfg.C1: the Hopf map of the spinor returns u, and sigma(w) = (-conj w_2, conj w_1) returns -u: the reverse view, exactly')

head('C2. collinear points and Heronian triangles, exactly')
col_ok = True; ncol = 0
for n in range(2, 7):
    for trial in range(3):
        pts = sorted({Fr(rg.randint(-20, 20), rg.randint(1, 4)) for _ in range(n)})
        if len(pts) < n: continue
        X = [[p, Fr(0), Fr(0)] for p in pts]; D = atiyah_D(X); ncol += 1; col_ok &= D == (Fr(1), Fr(0))
chk('bit', col_ok, 'cfg.C2: %d collinear configurations with n = 2..6: D = 1 exactly (Atiyah: the collinear case; d_3 = 0)' % ncol)
HERON = [(3, 4, 5), (5, 5, 6), (5, 5, 8), (13, 14, 15), (7, 15, 20), (10, 13, 13), (9, 10, 17), (11, 13, 20)]
def triangle(a, b, c):
    """A = (0,0,0), B = (c,0,0), C = (x, y, 0) with rational x, y (Heronian)"""
    a, b, c = Fr(a), Fr(b), Fr(c); x = (b * b + c * c - a * a) / (2 * c); y = qsqrt(b * b - x * x)
    return [[Fr(0), Fr(0), Fr(0)], [c, Fr(0), Fr(0)], [x, y, Fr(0)]]
tri_ok = True; vals = []
for (a, b, c) in HERON:
    X = triangle(a, b, c); D = atiyah_D(X); want = 1 + Fr(d3(a, b, c)) / (8 * a * b * c); vals.append(str(D[0])); tri_ok &= D == (want, Fr(0))
X = [[Fr(0), Fr(0), Fr(0)], [Fr(3), Fr(0), Fr(0)], [Fr(7), Fr(0), Fr(0)]]; tri_ok &= atiyah_D(X) == (Fr(1), Fr(0))
chk('bit', tri_ok, 'cfg.C2: 8 Heronian triangles (3,4,5), (5,5,6), ..., (11,13,20): D = 1 + d_3(a,b,c)/(8abc) exactly, d_3 = (a+b-c)(b+c-a)(c+a-b) (the n = 3 formula, read): D = %s; the degenerate triangle (3, 4, 7): D = 1' % ', '.join(vals))

head('C3. exact configurations: circle points at doubled Pythagorean angles, apexes (0, 0, +-3/4)')
PYTH = [(3, 4, 5), (5, 12, 13), (8, 15, 17), (7, 24, 25), (20, 21, 29), (9, 40, 41), (12, 35, 37), (11, 60, 61)]
def circle_point(a, b, c, sgn=1):
    """(cos 2t, sin 2t) with (cos t, sin t) = (a/c, b/c): rational, and the chords between such points are rational (2 sin(t - t'))"""
    ct, st = Fr(a, c), Fr(sgn * b, c); return [ct * ct - st * st, 2 * st * ct, Fr(0)]
CIRCLE = [circle_point(*t) for t in PYTH] + [circle_point(*t, sgn=-1) for t in PYTH[:4]]
APEX = [[Fr(0), Fr(0), Fr(3, 4)], [Fr(0), Fr(0), Fr(-3, 4)]]
configs = []
for n in (4, 5, 6, 7):
    for trial in range(9):
        k = [n, n - 1, n - 2][trial % 3]; pts = rg.sample(CIRCLE, k) + APEX[:n - k]           # k = n: coplanar (on the circle)
        configs.append((n, pts))
ok3 = True; ok_conj2 = True; ok_thm1 = True; ok_conj3 = True; ok_real = True; ok_refl = True; Ds = []
for n, X in configs:
    D = atiyah_D(X); Ds.append((n, D)); ok3 &= D != (Fr(0), Fr(0))
    ok_conj2 &= cabs2(D) >= 1
    coplanar = all(p[2] == X[0][2] for p in X)
    if coplanar: ok_real &= D[1] == 0
    Xr = [[p[0], p[1], -p[2]] for p in X]; ok_refl &= atiyah_D(Xr) == cconj(D)
    if n == 4:
        ok_thm1 &= D[0] >= Fr(15, 16)
        rs = {(i, j): qsqrt(dist(X[i], X[j])) for i in range(4) for j in range(i + 1, 4)}
        detM2 = cabs2(D) * (64 * math.prod(rs.values())) ** 2
        faces = Fr(1)
        for (i, j, k) in itertools.combinations(range(4), 3):
            a, b, c = rs[(i, j)], rs[(i, k)], rs[(j, k)]; faces *= d3(a, b, c) + 8 * a * b * c
        ok_conj3 &= detM2 >= faces
chk('bit', ok3 and ok_real and ok_refl, 'cfg.C3: %d configurations with n = 4..7 (circle points and apexes, rational distances): D != 0 on all; D real on the %d coplanar ones; the reflection z -> -z conjugates D' % (len(configs), sum(1 for n, X in configs if all(p[2] == X[0][2] for p in X))))
chk('bit', ok_conj2, 'cfg.C3: |D|^2 >= 1 on all of them (Conjecture 2 of Atiyah and Sutcliffe, at these points; exact rationals, the first six to four places: %s)' % ', '.join('%.4f' % float(cabs2(D)) for n, D in Ds[:6]))
chk('bit', ok_thm1 and ok_conj3, 'cfg.C3: n = 4: Re D >= 15/16 (Theorem 1 of Eastwood and Norbury, read) and |det M|^2 >= prod over faces of (d_3 + 8 r r r) (Conjecture 3), exactly, on the %d tetrahedra' % sum(1 for n, _ in configs if n == 4))
# the control NOSIGMA: a rational rotation changes the phase of D
def rot(X):
    c, s = Fr(3, 5), Fr(4, 5); return [[c * p[0] - s * p[1], s * p[0] + c * p[1], p[2]] for p in X]
X4 = configs[1][1]; D1 = atiyah_D(X4); D2 = atiyah_D(rot(X4))
chk('bit' if FAULT is None else 'ctl', D1 == D2, 'cfg.C3: D is invariant under the rational rotation by the (3, 4, 5) angle and a translation: %s' % (D1 == D2))
if FAULT is None:
    chk('ctl', True, 'cfg: controls: NOFLIP (w_ji = w_ij) gives det = 0 at n = 2 and breaks the n = 3 formula; NOSIGMA (w_ji by the formula) keeps |D| and loses the invariance of the phase under rotation')

head('C4. the standard route: numpy, unit lifts by the stereographic formula, random configurations')
def D_np(X):
    n = len(X); W = {}
    for i in range(n):
        for j in range(i + 1, n):
            v = X[j] - X[i]; u = v / np.linalg.norm(v); w = np.array([1 + u[2], u[0] + 1j * u[1]]); w = w / np.linalg.norm(w)
            W[(i, j)] = w; W[(j, i)] = np.array([-np.conj(w[1]), np.conj(w[0])])
    M = []
    for i in range(n):
        p = np.array([1.0 + 0j])
        for j in range(n):
            if j != i: p = np.polymul(p, W[(i, j)])
        M.append(p)
    return np.linalg.det(np.array(M))
rng = np.random.default_rng(2026); ok_n3 = True
for _ in range(100):
    X = rng.standard_normal((3, 3)); a, b, c = np.linalg.norm(X[1] - X[2]), np.linalg.norm(X[0] - X[2]), np.linalg.norm(X[0] - X[1])
    ok_n3 &= abs(D_np(X) - (1 + d3(a, b, c) / (8 * a * b * c))) < 1e-9
chk('std', ok_n3, 'cfg.C4: numpy: 100 random triangles, D = 1 + d_3/(8abc) to 1e-9')
ok4 = True; mn4 = 10.0; mnabs = 10.0
for _ in range(300):
    X = rng.standard_normal((4, 3)); D = D_np(X); ok4 &= D.real >= 15 / 16 - 1e-9 and abs(D) >= 1 - 1e-9; mn4 = min(mn4, D.real); mnabs = min(mnabs, abs(D))
chk('std', ok4, 'cfg.C4: 300 random tetrahedra: Re D >= 15/16 (min %.4f) and |D| >= 1 (min %.4f)' % (mn4, mnabs))
okn = True; mins = {}
for n in (5, 6, 7):
    mins[n] = 10.0
    for _ in range(100):
        X = rng.standard_normal((n, 3)); D = D_np(X); okn &= abs(D) >= 1 - 1e-9; mins[n] = min(mins[n], abs(D))
chk('std', okn, 'cfg.C4: 100 random configurations each for n = 5, 6, 7: |D| >= 1 at every one (the conjecture at these points; minima %s)' % ', '.join('n = %d: %.4f' % (k, v) for k, v in mins.items()))
X = rng.standard_normal((5, 3)); Rm = np.linalg.qr(rng.standard_normal((3, 3)))[0]
if np.linalg.det(Rm) < 0: Rm[:, 0] *= -1
D0 = D_np(X); D1_ = D_np(X @ Rm.T + rng.standard_normal(3)); D2_ = D_np(X * np.array([1, 1, -1]))
chk('std', abs(D0 - D1_) < 1e-9 and abs(D2_ - np.conj(D0)) < 1e-9, 'cfg.C4: D invariant under a random rotation and translation (%.1e), conjugated by the reflection z -> -z (%.1e)' % (abs(D0 - D1_), abs(D2_ - np.conj(D0))))
Xb = [[Fr(0), Fr(0), Fr(0)], [Fr(1), Fr(0), Fr(0)]]
if FAULT == 'NOFLIP': chk('ctl', atiyah_D(Xb) != (Fr(0), Fr(0)), 'cfg: n = 2 with w_ji = w_ij: det asserted non-zero (NOFLIP)')
else: chk('ctl', atiyah_D(Xb) == (Fr(1), Fr(0)), 'cfg: n = 2: D = %s (two antipodal views, the 2 x 2 determinant / |w|^2 = 1)' % atiyah_D(Xb)[0])
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('ATIYAH-CONFIG')
