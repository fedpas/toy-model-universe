#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""chain_numbers.py: the computable core of the dead end of the Baez page, "a shared number is not evidence; we kept only the matches that
came with a computation": the numbers recomputed, the two kept matches with their mechanism computed, and the two tens told apart.
     python3 chain_numbers.py [--fault E1ONLY|V0SQ|BADCD]

chn.11a  The occurrences, recomputed: 10 = dim h2(O) = 2 + 8 = C(5,2) (pairs of five bits); 16 = the even five-bit labels; 27 = dim h3(O) =
   3 + 3 x 8; 32 = 2^5 five-bit labels = 2 x 4^2 (the fourth shell) = the sixth and seventh period lengths of the Madelung filling (2, 8, 8,
   18, 18, 32, 32); 12 = 8 + 3 + 1 (the dimensions of su(3), su(2), u(1)).  Which paper prints which occurrence is the report's data.
chn.11b  The octonions by Cayley-Dickson doubling (exact integers): alternative and normed on 40 random integer triples, not associative;
   the product of two basis units is +- the unit at the xor of their indices (the octonions as signed three-bit labels).
chn.11c  Kept match, 16: in h3(O) (exact, octonion matrices, Jordan product x o y = (xy + yx)/2) the idempotent E = e1 + e2 splits the 27
   dimensions as 10 + 16 + 1 (eigenvalues 1, 1/2, 0 of L_E); the nine traceless directions v of A = h2(O) act on the 16-dimensional Peirce
   space by S_v = 2 v o (.), which preserves it, with S_v^2 = |v|^2 (|v|^2 = t^2 + N(z), 30 random integer v) and S_v S_w + S_w S_v = 0 for
   orthogonal basis directions: a module of Cl(9,0) of dimension 16.  The bit rule of Cl(9,0) has a primitive idempotent
   P = (1 + I)/2 prod_k (1 + f_k)/2 (four commuting 4-blades f_k) whose left ideal has dimension 16: the Peirce 16 is the irreducible module,
   the real spinors of Spin(9).  [bit] BR((1,)*9), exact.  [std] octonion matrices, exact integers.
chn.11d  Kept match, 10: the determinant ab - N(z) of h2(O) is a real quadratic form of signature (1, 9) (exact LDL): h2(O) is R^(1,9).
chn.11e  The two tens are not the same kind: a hermitian form of signature (1, 9) on C^10 (diagonal, and one with integer Gaussian entries)
   is, as a real form, of dimension 20 and signature (2, 18); h2(O) has dimension 10 and signature (1, 9): not isometric.  No computation
   relates the 16 even labels to the Peirce 16, nor the 32 labels to the 32 of a shell: the table records them as matches without a mechanism.
Controls ([ctl]; each --fault puts the wrong version in the main lines, which must then FAIL):
   E1ONLY the Peirce space of e1 alone (blocks 12 and 13) in place of that of e1 + e2 (not preserved by the directions of h2(O)); V0SQ the
   square of S_v compared with t^2 alone; BADCD a doubling without the conjugations (not alternative).
Scope: as stated per item; all arithmetic exact (integers and Fractions).  The gravity engine's Forms, Lie and Grav are not used, so its
eight engine faults are not seen by this script; its controls are the faults above.
Command: python3 chain_numbers.py   (from this folder, or python3 selfcheck/proofs/chain_numbers.py from the package root; standard library)."""
import os, sys, random
from fractions import Fraction as Fr
from math import comb

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_researchers = os.path.join(os.path.dirname(os.path.dirname(_here)), 'researchers_checks')
if not os.path.isfile(os.path.join(_researchers, 'bitrule_A.py')): raise SystemExit('bitrule_A.py not found in ' + _researchers + ': this file belongs in selfcheck/proofs/ of the package')
if _researchers not in sys.path: sys.path.insert(0, _researchers)
from bitrule_A import BR

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('E1ONLY', 'V0SQ', 'BADCD')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
pc = lambda x: bin(x).count('1')
rng = random.Random(20261013)

# ================================================================================================ chn.11a  the occurrences
head('chn.11a  the numbers, recomputed (LNB-026, LNB-058)')
def madelung_periods():
    orb = sorted(((n, l) for n in range(1, 9) for l in range(n)), key=lambda t: (t[0] + t[1], t[0]))
    fill, ends = 0, []
    for n, l in orb:
        fill += 2 * (2 * l + 1)
        if l == 0 and n > 1: ends.append(fill - 2)                      # a period closes just before the next s shell opens
    ends = [e for e in ends if e > 0][:7]
    return ends, [b - a for a, b in zip([0] + ends, ends)]
noble, periods = madelung_periods()
occ = {10: [('h2(O): 2 diagonal + 8 octonion coordinates', 2 + 8), ('pairs of five bits', sum(1 for a in range(32) if pc(a) == 2))],
       12: [('su(3) + su(2) + u(1)', (3 * 3 - 1) + (2 * 2 - 1) + 1)],
       16: [('even five-bit labels', sum(1 for a in range(32) if pc(a) % 2 == 0))],
       27: [('h3(O): 3 diagonal + 3 x 8 octonion coordinates', 3 + 3 * 8)],
       32: [('five-bit labels', 1 << 5), ('the fourth shell, 2 n^2', 2 * 4 * 4), ('the sixth and seventh periods', periods[5] if len(periods) > 5 else None)]}
ok_occ = all(v == k for k, lst in occ.items() for _, v in lst) and noble == [2, 10, 18, 36, 54, 86, 118] and periods == [2, 8, 8, 18, 18, 32, 32]
chk('bit', ok_occ, 'chn.11a: 10 = 2 + 8 = C(5,2); 12 = 8 + 3 + 1; 16 = the even five-bit labels; 27 = 3 + 3 x 8; 32 = 2^5 = 2 x 4^2 = the Madelung period length (periods %s, closing at %s)' % (periods, noble))

# ================================================================================================ chn.11b  octonions
head('chn.11b  the octonions by Cayley-Dickson doubling')
def conj(x):
    if len(x) == 1: return x
    h = len(x) // 2
    return conj(x[:h]) + tuple(-v for v in x[h:])
def add(x, y): return tuple(a + b for a, b in zip(x, y))
def sub(x, y): return tuple(a - b for a, b in zip(x, y))
def mul(x, y):
    if len(x) == 1: return (x[0] * y[0],)
    h = len(x) // 2; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    if FAULT == 'BADCD' and len(x) == 8: return sub(mul(a, c), mul(d, b)) + add(mul(d, a), mul(b, c))
    return sub(mul(a, c), mul(conj(d), b)) + add(mul(d, a), mul(b, conj(c)))
def N(x): return sum(v * v for v in x)
def rand_oct(lo=-3, hi=3): return tuple(rng.randint(lo, hi) for _ in range(8))
ok_alt = ok_norm = True; nonassoc = False
for _ in range(40):
    x, y, z = rand_oct(), rand_oct(), rand_oct()
    ok_alt &= mul(x, mul(x, y)) == mul(mul(x, x), y) and mul(mul(y, x), x) == mul(y, mul(x, x))
    ok_norm &= N(mul(x, y)) == N(x) * N(y)
    nonassoc |= mul(mul(x, y), z) != mul(x, mul(y, z))
unit = lambda i: tuple(1 if j == i else 0 for j in range(8))
ok_lab = True
for a in range(8):
    for b in range(8):
        p = mul(unit(a), unit(b)); nz = [j for j, v in enumerate(p) if v]
        ok_lab &= nz == [a ^ b] and p[a ^ b] in (1, -1)
chk('std', ok_alt and ok_norm and nonassoc, 'chn.11b: Cayley-Dickson octonions (exact integers): x(xy) = (xx)y, (yx)x = y(xx) and N(xy) = N(x)N(y) on 40 random triples; (xy)z != x(yz) for some triple')
chk('bit', ok_lab, 'chn.11b\': the product of two basis units is +- the unit at the xor of their indices: the octonions are signed three-bit labels (a twisted group algebra of Z2^3)')

# ================================================================================================ chn.11c  the kept match 16
head('chn.11c  the 16 of the Peirce space is the irreducible module of Cl(9,0), the real spinors of Spin(9)')
Z8 = (0,) * 8
def herm(al, c):
    """3x3 hermitian octonion matrix from al = (a1, a2, a3), c = (c1, c2, c3): [[a1, c3, c2*], [c3*, a2, c1], [c2, c1*, a3]]"""
    r = lambda t: (t,) + (0,) * 7
    return [[r(al[0]), c[2], conj(c[1])], [conj(c[2]), r(al[1]), c[0]], [c[1], conj(c[0]), r(al[2])]]
def mmul(X, Y): return [[add(add(mul(X[i][0], Y[0][j]), mul(X[i][1], Y[1][j])), mul(X[i][2], Y[2][j])) for j in range(3)] for i in range(3)]
HERM_OK = [True]
def jordan2(X, Y):
    """2 (X o Y) = XY + YX as coordinates (a1, a2, a3, c1, c2, c3): 27 numbers"""
    P, Q = mmul(X, Y), mmul(Y, X); S = [[add(P[i][j], Q[i][j]) for j in range(3)] for i in range(3)]
    ok_h = all(all(v == 0 for v in S[i][i][1:]) for i in range(3)) and S[2][1] == conj(S[1][2]) and S[0][2] == conj(S[2][0]) and S[1][0] == conj(S[0][1])
    HERM_OK[0] = HERM_OK[0] and ok_h                                      # the Jordan product of hermitian matrices is hermitian
    return (S[0][0][0], S[1][1][0], S[2][2][0]) + S[1][2] + S[2][0] + S[0][1]
def from_coords(v): return herm(v[:3], (tuple(v[3:11]), tuple(v[11:19]), tuple(v[19:27])))
basis27 = [tuple(1 if j == i else 0 for j in range(27)) for i in range(27)]
E = from_coords((1, 1, 0) + (0,) * 24)
LE = [jordan2(E, from_coords(b)) for b in basis27]                    # 2 L_E on the basis: columns
eig = []
for i, col in enumerate(LE):
    ok_diag = all(col[j] == 0 for j in range(27) if j != i)
    eig.append(Fr(col[i], 2) if ok_diag else None)
dims = {Fr(1): sum(1 for e in eig if e == 1), Fr(1, 2): sum(1 for e in eig if e == Fr(1, 2)), Fr(0): sum(1 for e in eig if e == 0)}
ok_peirce = None not in eig and dims == {Fr(1): 10, Fr(1, 2): 16, Fr(0): 1} and HERM_OK[0]
chk('std', ok_peirce, 'chn.11c1: h3(O), 27 = 3 + 3 x 8 coordinates: L_E for E = e1 + e2 has eigenvalues 1, 1/2, 0 with dimensions 10 (A = h2(O)), 16 (the off-diagonal blocks 23 and 31), 1; every Jordan product computed is hermitian')
half = [i for i in range(27) if (eig[i] == Fr(1, 2))] if FAULT != 'E1ONLY' else list(range(11, 27))
def S_of(vcoords):
    V = from_coords(vcoords); M = []; inv = True
    for i in half:
        img = jordan2(V, from_coords(basis27[i]))
        inv &= all(img[j] == 0 for j in range(27) if j not in half)
        M.append([img[j] for j in half])
    return [list(r) for r in zip(*M)], inv
def mat_mul(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B))) for j in range(len(B[0]))] for i in range(len(A))]
def eye(n, c=1): return [[c if i == j else 0 for j in range(n)] for i in range(n)]
dirs = []
dirs.append((1, -1, 0) + (0,) * 24)                                     # t = 1, z = 0
for k in range(8): dirs.append((0, 0, 0) + (0,) * 16 + tuple(1 if j == k else 0 for j in range(8)))   # t = 0, z = e_k (block 12)
Ss = []; ok_inv = True
for v in dirs:
    S, inv = S_of(v); Ss.append(S); ok_inv &= inv
m = len(half)
ok_cl = ok_inv and all(mat_mul(Ss[i], Ss[i]) == eye(m) for i in range(9)) and all(mat_mul(Ss[i], Ss[j]) == [[-x for x in r] for r in mat_mul(Ss[j], Ss[i])] for i in range(9) for j in range(i))
ok_rand = True
for _ in range(30):
    t = rng.randint(-3, 3); z = rand_oct()
    v = (t, -t, 0) + (0,) * 16 + z; S, inv = S_of(v)
    target = t * t if FAULT == 'V0SQ' else t * t + N(z)
    ok_rand &= inv and mat_mul(S, S) == eye(m, target)
    Vm = from_coords(v); vv = jordan2(Vm, Vm)
    ok_rand &= vv == (2 * (t * t + N(z)), 2 * (t * t + N(z)), 0) + (0,) * 24          # v o v = |v|^2 1_A
chk('std', ok_cl and ok_rand and HERM_OK[0], 'chn.11c2: the nine traceless directions of h2(O) act on the Peirce 16 by S_v = 2 v o (.), preserving it, with S_v^2 = 1 on the basis directions, S_v S_w = -S_w S_v for distinct ones, and S_v^2 = |v|^2 = t^2 + N(z), v o v = |v|^2 1_A for 30 random integer v: a module of Cl(9,0) of dimension 16')
C9 = BR((1,) * 9); I9 = (1 << 9) - 1
fl = [0b000001111, 0b000111100, 0b011110000, 0b001010101]
one = {0: Fr(1)}
def half_plus(lab): return {0: Fr(1, 2), lab: Fr(1, 2)}
Pm = half_plus(I9)
for f in fl: Pm = C9.mul(Pm, half_plus(f))
comm_ok = all(C9.mul({f: 1}, {g: 1}) == C9.mul({g: 1}, {f: 1}) for f in fl + [I9] for g in fl + [I9]) and all(C9.mul({f: 1}, {f: 1}) == {0: 1} for f in fl + [I9])
def rank_sparse(vecs):
    piv = {}
    for v in vecs:
        v = dict(v)
        while v:
            k = max(v)
            if k not in piv: piv[k] = v; break
            c = v[k] / piv[k][k]
            for kk, vv in piv[k].items():
                v[kk] = v.get(kk, 0) - c * vv
                if v[kk] == 0: del v[kk]
    return len(piv)
ideal = [C9.mul({a: Fr(1)}, Pm) for a in range(1 << 9)]
r16 = rank_sparse(ideal)
ok_bit = comm_ok and C9.mul(Pm, Pm) == Pm and r16 == 16 and all(C9.s(1 << i, I9) == C9.s(I9, 1 << i) for i in range(9))
chk('bit', ok_bit, 'chn.11c3: bit rule of Cl(9,0): I = e_1...9 is central with I^2 = +1; f = e_1234, e_3456, e_5678, e_1357 commute and square to +1; P = (1 + I)/2 prod (1 + f)/2 is idempotent and its left ideal has dimension %d (512 = 2 x 16^2)' % r16)
chk('bit==std', ok_bit and ok_cl and m == r16, 'chn.11c4: the Peirce space (16) carries the Clifford relations of the nine directions and has the dimension of a minimal left ideal of Cl(9,0) (16): it is the irreducible module, the real spinors of Spin(9): the match 16 = 16 comes with a mechanism')

# ================================================================================================ chn.11d / e  the tens
head('chn.11d / e  the ten of h2(O) is R^(1,9); the ten of a hermitian form on C^10 is another kind')
def inertia(G):
    A = [[Fr(x) for x in row] for row in G]; n = len(A); pos = neg = 0; k = 0
    while k < n:
        piv = next((i for i in range(k, n) if A[i][i] != 0), None)
        if piv is None:
            pr = next(((i, j) for i in range(k, n) for j in range(i + 1, n) if A[i][j] != 0), None)
            if pr is None: break
            i, j = pr
            for c in range(n): A[i][c] += A[j][c]
            for r in range(n): A[r][i] += A[r][j]
            continue
        A[k], A[piv] = A[piv], A[k]
        for r in A: r[k], r[piv] = r[piv], r[k]
        d = A[k][k]; (pos := pos + 1) if d > 0 else (neg := neg + 1)
        for i in range(k + 1, n):
            f = A[i][k] / d
            if f:
                for c in range(k, n): A[i][c] -= f * A[k][c]
        for i in range(k + 1, n): A[k][i] = Fr(0)
        for i in range(k + 1, n):
            A[i][k] = Fr(0)
        k += 1
    return pos, neg
def det_form(x): return x[0] * x[1] - N(x[2:10])
G = [[Fr(0)] * 10 for _ in range(10)]
for i in range(10):
    for j in range(10):
        ei = [1 if k == i else 0 for k in range(10)]; ej = [1 if k == j else 0 for k in range(10)]; s = [a + b for a, b in zip(ei, ej)]
        G[i][j] = Fr(det_form(s) - det_form(ei) - det_form(ej), 2)
sig10 = inertia(G)
chk('std', sig10 == (1, 9), 'chn.11d: det(x) = ab - N(z) on h2(O) is a real quadratic form of signature %s (exact): h2(O) with det is R^(1,9), the match of the ten with ten-dimensional Minkowski space comes with a computation' % (sig10,))
def realify(H):
    n = len(H); R = [[Fr(0)] * (2 * n) for _ in range(2 * n)]
    for i in range(n):
        for j in range(n):
            a, b = H[i][j]                                               # H_ij = a + i b, hermitian
            R[i][j] = a; R[n + i][n + j] = a; R[i][n + j] = -b; R[n + i][j] = b
    return R
Hd = [[((1 if i == 0 else -1) if i == j else 0, 0) for j in range(10)] for i in range(10)]
U = [[(1 if i == j else 0, 0) for j in range(10)] for i in range(10)]
U[0][1] = (1, 1); U[2][0] = (0, 2); U[3][4] = (1, -1)
def cmul(x, y): return (x[0] * y[0] - x[1] * y[1], x[0] * y[1] + x[1] * y[0])
def cadd(x, y): return (x[0] + y[0], x[1] + y[1])
def cconj(x): return (x[0], -x[1])
def cmat(A, B): return [[(lambda s: s)(sum_c([cmul(A[i][k], B[k][j]) for k in range(10)])) for j in range(10)] for i in range(10)]
def sum_c(lst):
    s = (0, 0)
    for v in lst: s = cadd(s, v)
    return s
Ustar = [[cconj(U[j][i]) for j in range(10)] for i in range(10)]
Hg = cmat(cmat(Ustar, Hd), U)
ok_h = all(Hg[i][j] == cconj(Hg[j][i]) for i in range(10) for j in range(10))
sigC_d, sigC_g = inertia(realify(Hd)), inertia(realify(Hg))
chk('std', ok_h and sigC_d == sigC_g == (2, 18), 'chn.11e: a hermitian form of signature (1, 9) on C^10 (diagonal, and U* D U with an integer Gaussian U) is a real form of dimension 20 and signature %s: not isometric to h2(O) (10, %s): the two tens are not the same kind of ten' % (sigC_g, sig10))
def bad_mul(x, y):
    h = 4; a, b, c, d = x[:h], x[h:], y[:h], y[h:]
    return sub(mul(a, c), mul(d, b)) + add(mul(d, a), mul(b, c))
xs = [(rand_oct(), rand_oct()) for _ in range(10)]
c_bad = any(bad_mul(x, bad_mul(x, y)) != bad_mul(bad_mul(x, x), y) for x, y in xs)
V1 = from_coords((0, 0, 0) + (0,) * 16 + (0, 1, 0, 0, 0, 0, 0, 0)); e1half = list(range(11, 27))
c_e1 = any(any(jordan2(V1, from_coords(basis27[i]))[j] != 0 for j in range(27) if j not in e1half) for i in e1half)
S1, _ = S_of((1, -1, 0) + (0,) * 16 + (1, 1, 0, 0, 0, 0, 0, 0)); c_v0 = mat_mul(S1, S1) != eye(len(half), 1)
chk('ctl', c_bad and c_e1 and c_v0, 'chn.11g: wrong versions fail: a doubling without conjugations is not alternative (10 random pairs); the Peirce space of e1 alone (blocks 31 and 12) is not preserved by a direction of h2(O); the square of S_v is not t^2 alone (t = 1, z = 1 + e_1: it is 3)')
chk('ctl', inertia([[1, 0], [0, -1]]) == (1, 1) and inertia(realify([[(1, 0)]])) == (2, 0), 'chn.11f: the inertia routine on two known forms: x^2 - y^2 is (1, 1); |z|^2 on C is (2, 0) as a real form')
print('\n  table of matches (number: occurrences | mechanism computed here)')
print('    16: Peirce space of h2(O) in h3(O); real spinors of Spin(9); even five-bit labels | Peirce = spinors: chn.11c (Clifford action, minimal ideal); even labels: none')
print('    10: h2(O); the triangulation form; pairs of five bits | h2(O) = R^(1,9): chn.11d; triangulation 10: complex, (20; 2, 18), chn.11e: none')
print('    32: five-bit labels; the fourth shell; the sixth and seventh periods | none')
print('    27: h3(O) | (one object)')
print('    12: su(3) + su(2) + u(1) in three embeddings | not compared here')

finish('CHAIN-NUMBERS')
