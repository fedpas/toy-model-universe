#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_einstein.py -- the shifted Einstein equations of Atiyah and Moore ("A shifted view of fundamental physics", sections 3 and 4, read) on
the labels: the Weitzenboeck formula as the square of the Dirac operator on the full algebra of a curved frame, the three shifted Ricci operators as
series acting on 1-forms, de Sitter, and the fifth generator (Kaluza-Klein) on the labels of Cl(1,4).

Read.  (3.1) on 1-forms Hodge - Bochner = Ricci; (3.2) with nabla*nabla -> -nabla^2 and D = d + delta read as a Dirac operator, D^2 + nabla^2 = Ricci
("sign conventions have to be carefully checked"); (3.3a-c) Ricci_++ = c(D_+^2) + nabla^2, Ricci_+- = D_+ D_- + nabla^2, Ricci_ss = D_s^2 + nabla^2,
(3.4) c(D_+^2) = P (D_+)^2 I the compression to 1-forms; (3.5a-c) the shifted Einstein equations; (3.6a-c) at leading order Ricci = -k^2/hbar^2, +k^2/hbar^2,
0; (3.10) the restriction to 1-forms with -nabla^2 phi = 0, "unfortunately" not preserved since Delta need not commute with Ricci; (3.11) the pair
(g, phi).  (4.2) ds^2 = e^{2 sigma} Theta^2 + ds-bar^2; (4.3) at F = 0, -nabla-bar^2 e^sigma = eps (k/hbar)^2 e^sigma, eps = +-1; (4.4) on de Sitter the
homogeneous solutions e^sigma = a_+ e^{sqrt(eps) k c t/hbar} + a_- e^{-sqrt(eps) k c t/hbar}, the time scale hbar/kc, about (3 pi)^-1 x 10^11 years.
Conventions.  The gravity engine (selfcheck/gravity_selfcheck.py, through selfcheck/gravity/b1lib.py): frame algebra Cl(p,q) with the squares sq (the
Atlas's Lorentz signature (+,-,-,-), Cl(4,0) for the Riemannian cones, Cl(1,4) and Cl(2,3) in five dimensions), forms = the bit rule with null
generators, omega = the closed form (Cartan-Koszul) on the frame, R = d omega + (1/4)[omega, omega]; frame Ricci R_bd = R^a_bad (MTW), the endomorphism
Ric^b_d = eta^bb R_bd.  A field of the full algebra is X = sum_S X^S(x) gamma_S; nabla X = d X + (1/2) omega^A [B_A, X] (the commutator: the derivation
extension of the spinor rule (1/2) omega^A B_A psi); the Dirac operator on the full algebra D X = gamma^a nabla_a X (gamma^a = eta^aa gamma_a, left
multiplication); the Bochner (rough) Laplacian box X = eta^ab (nabla^2 X)(E_a, E_b).  Forms are read through gamma^a <-> e^a (the coframe), so gamma_S <->
eta_S e^S.  delta X := (d(X I^-1)) I with I = gamma_{0..n-1} and d the null-bit exterior derivative: no connection.  hbar = c = 1, tau for the paper's r,
kappa for k, mu = kappa tau.
Statements.
(1) [se.DIRAC] D X = d X + delta X exactly at the origin of every frame below, every grade (random polynomial fields of all 2^n components): the Dirac
    operator on the full algebra of a curved frame is d + delta on forms, delta the codifferential of the metric -e^T eta e (the paper's signature);
    with the Atlas's metric e^T eta e, D = d - delta_g.  Frames: the weak-field frame e^0 = N dt, e^i = dx^i (ATY-037) with N quadratic (with N = 1 - g x_3,
    the frame of ATY-037's check, the curvature is zero: Rindler); the self-dual Einstein cones (5.4)-(5.6) of ATY-036 at four rational points in
    Cl(4,0) (t = e^s, z = tan(theta/2), beta V(t) a rational square); de Sitter in conformal time (GRV-007's FRW frame a = -1/(H eta)) at two points; two
    random polynomial frames; two Kaluza-Klein frames in Cl(1,4) and Cl(2,3).
(2) [se.WZB] On 1-forms: D^2 X keeps the degree (no 3-vector part), (d + delta)^2 X computed without a connection equals D^2 X, and the exact fit
    D^2 X - box X = c Ric(X) over all frames and fields has the single solution c = -1: D^2 = box - Ric, i.e. with the paper's nabla^2 = -box and Ricci
    = -Ric (the signature flipped) D^2 + nabla^2 = Ricci, the paper's (3.2); on the cones (Cl(4,0), D = d - delta_g) Hodge - Bochner = Ricci = (3/2) beta^2
    (2 - beta), the paper's (3.1); in five dimensions the same.  The fits with c = 0 (no Ricci term) and c = +1 are inconsistent.
(3) [se.STD] numpy, no label: the metric g = e^T eta e of the closed-form frames, Christoffel symbols, Ricci, the rough Laplacian, d and the codifferential
    by the divergence formula, all by finite differences (4-point stencils): Delta_g phi = -nabla^2 phi + Ric(phi) at the same points, and the label
    values of D^2 X, box X, Ric(X), delta X agree with -Delta_g phi, nabla^2 phi, Ric(phi), -delta_g phi.
(4) [se.SER] The three shifted Ricci operators with (3.2): Ricci_xx = Ricci + sum_j c_j D^2j, exactly as polynomials in (kappa, tau) to order D^12;
    c_0 = kappa^2, -kappa^2, 0; c_1 = -2 kappa tau + 2 kappa^2 tau^2, -2 kappa tau, 2 kappa tau + kappa^2 tau^2; ... (the closed forms of ATY-010 at every
    order); on the labels D maps 1-forms to grades 0 and 2 and D^2 keeps grade 1, so P D^(2j+1) I = 0 and c(D_+^2) is the even part (3.4).
(5) [se.LOW] The lowest order (3.6a-c): Ricci = -kappa^2, kappa^2, 0 in the paper's signature, Ric = kappa^2, -kappa^2, 0 in the Atlas's; on the labels de
    Sitter has Ric = -Lambda (Lambda = 3 H^2), anti-de Sitter (Poincare frame a = 1/(H z)) Ric = +3 H^2, exactly in the chart: (3.6b) is de Sitter with
    Lambda = kappa^2, (3.6a) anti-de Sitter with Lambda = -kappa^2, (3.6c) Lambda = 0, in both signatures.
(6) [se.ZERO] Next orders in the zero-mode reading (D^2 -> Ricci on an Einstein metric): the root of lambda + sum_j c_j lambda^j = 0 near the lowest order,
    as a series in mu with exact rational coefficients to mu^8; numpy brentq on the closed forms agrees.
(7) [se.WAVE] De Sitter on the labels, exactly in the chart (Laurent polynomials in eta): D^2 = box + Lambda, D^4 = (box + Lambda)^2, D^6 = (box +
    Lambda)^3 on random polynomial 1-forms (anti-de Sitter: box - 3 H^2), so every series in D^2 is the same series in box + Lambda; on the 1-forms the
    paper restricts to (box X = 0, (3.10)) the shifted operators are the numbers F_x(Lambda); with Lambda = +-kappa^2 the residual divided by kappa^2 as a
    series in mu, exactly: (3.5b) at Lambda = kappa^2: -2 sinh mu (zero at order mu^0, first order mu^1); (3.5a) at Lambda = -kappa^2: 2 sin mu (1 - sin mu);
    (3.5c): (1 + sinh mu)^2 and -(1 + sin mu)^2 (order mu^0), zero to all orders at Lambda = 0; the mismatched pairs fail at order mu^0.  The homogeneous
    solutions of (3.10) on de Sitter have irrational exponents (eta^p gamma_0: p^2 - 3p - 3 = 0; eta^p gamma_i: p^2 - 3p - 1 = 0), numpy checks them.  On a
    general 1-form the order-mu residual is -2 kappa tau D^2 X, a differential operator.  On a frame that is not Einstein (FRW a = eta^2) [box, Ric] != 0,
    exactly: on the solutions of (3.10) the D^4 term of the series is not Ric^2 (the paper's remark), while on de Sitter [box, Ric] = 0.
(8) [se.KK] The fifth generator, Cl(1,4) and Cl(2,3), e^4 = phi dy with F = 0: Ric5_ab = Ric4_ab - (nabla_a nabla_b phi)/phi, Ric5_a4 = 0, Ric5_44 =
    -eta_44 (box phi)/phi, exactly at the origin of random frames; the Christoffel route on the five-dimensional metric agrees exactly.
(9) [se.RADIUS] With Ric5 = eps kappa^2 (the paper's signs; Ric5 = -eps kappa^2 eta in the Atlas's), the 44 component is (4.3), box phi = eps kappa^2 phi
    (the Atlas's box = -nabla^2 of the paper), for both squares of the fibre generator; LNS-017e's box phi = 4 c phi with 4c = eps kappa^2; constant sigma
    over de Sitter: the 4D block is the four-dimensional equation with Lambda but the 44 component reads 0 = eps kappa^2.
(10) [se.DS5] On a de Sitter base (conformal time, Laurent exact): phi = (-eta)^p solves (4.3) iff p^2 - 3p - eps kappa^2/H^2 = 0, i.e. e^{r t} with
    r^2 + 3 H r = eps kappa^2 (the base's friction); the paper's (4.4) exponents do not solve it (H != 0); the five-dimensional equation holds (Ric5 Einstein)
    only for phi ~ e^{H t} with eps kappa^2 = 4 H^2 (five-dimensional de Sitter); scipy solve_ivp on f'' + 3 H f' = eps kappa^2 f agrees.
(11) [se.TIME] the number hbar/kc for k/hbar = 1e-28 cm^-1, and the paper's (3 pi)^-1 x 10^11 years.
[ctl]  Wrong versions in the main run (they must fail) and --fault options (the run must end with FAILS and exit 1):
       NOCONN    nabla without the connection (D = gamma^a E_a);       DUALLEFT  delta X = I d(I^-1 X) (left duality);
       NORIC     the Weitzenboeck formula without the Ricci term;        RICSIGN   D^2 = box + Ric;
       KEEPODD   the compression keeps the odd powers;                   WARPSIGN  Ric5_ab = Ric4_ab + Hess phi/phi;
       NOFRICTION the homogeneous radius from f'' = eps kappa^2 f, the paper's (4.4).
Scope.  Values at the origin of polynomial or Taylor jets of the frames (exact Fractions, jets of order 2) and identities in the chart for the
       conformally flat frames (Laurent polynomials); finitely many frames and fields; the formal series to order D^12 (j <= 6) and mu^8.  The operator
       equations (3.5) are evaluated as series; their meaning, the pair (g, phi) of (3.11) and the shifted Einstein-Maxwell equations with F != 0 are not
       built.  No claim about nature.
Run:   python3 shifted_einstein.py [--fault NAME]   (from the package root as selfcheck/proofs/shifted_einstein.py; also from its own folder, under -I -B)"""
import os, sys, time, math, itertools, random
from fractions import Fraction as Fr
sys.dont_write_bytecode = True
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

_here = os.path.dirname(os.path.abspath(__file__)); _selfcheck = os.path.dirname(_here); _grav = os.path.join(_selfcheck, 'gravity')
if not os.path.isfile(os.path.join(_grav, 'b1lib.py')):
    raise SystemExit('gravity/b1lib.py not found beside this folder: this file belongs in selfcheck/proofs/ of the package')
if _grav not in sys.path: sys.path.insert(0, _grav)
import b1lib as bl                                                          # the engine (gravity_selfcheck.py) and the closed-form connection
from b1lib import padd, bmul, Lie, Grav, Forms, trunc, pm, at0, scale
import e1_lichnerowicz as e1                                                # curv_frame, ricci (frame components of the engine's curvature)
import h4_kaluza_klein as h4                                                # kk_frame, rand_poly4, std4_pieces

FAILS = []; COUNT = {}
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[tag] = COUNT.get(tag, 0) + 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\n%d checks (%s), %d FAIL' % (sum(COUNT.values()), ', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), len(FAILS)), flush=True)
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
FAULTS = ('NOCONN', 'DUALLEFT', 'NORIC', 'RICSIGN', 'KEEPODD', 'WARPSIGN', 'NOFRICTION')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULTS: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULTS)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()

# ================================================================================================ multivector fields with polynomial coefficients
def clean(X): return {k: v for k, v in X.items() if v != 0}
def mv_add(X, Y, c=1):
    r = dict(X)
    for k, v in Y.items(): r[k] = r.get(k, 0) + c * v
    return clean(r)
def mvp_add(X, Y, c=1):
    r = dict(X)
    for k, v in Y.items(): r[k] = padd(r.get(k, {}), v, c)
    return {k: v for k, v in r.items() if v}
def at0_mv(X, n): return clean({S: at0(p, n) for S, p in X.items()})
def grades(X): return sorted({bin(S).count('1') for S, v in X.items() if v})
def rpol(rng, n, deg, coef=3, const_nonzero=True):
    """every monomial of degree <= deg, an integer coefficient in -coef..coef; the constant term non-zero (the field does not vanish at the point)"""
    out = {}
    for ex in itertools.product(range(deg + 1), repeat=n):
        if sum(ex) <= deg:
            c = rng.randint(-coef, coef)
            if sum(ex) == 0 and c == 0 and const_nonzero: c = 1
            if c: out[ex] = Fr(c)
    return out

# ================================================================================================ route A: the connection on the full algebra (labels)
def D_full(Gv, om, X):
    """the covariant exterior derivative of a multivector field of 0-forms: d X + (1/2) omega^A [B_A, X]  ({S: 1-form})"""
    Fm = Gv.Fm; sq = Gv.L.sq
    out = {S: Fm.d({0: p}) for S, p in X.items() if p}
    if not fault('NOCONN'):
        for A, g in enumerate(Gv.L.gens):
            if not om[A]: continue
            for S, p in X.items():
                if not p: continue
                m1, s1 = bmul(g, S, sq); m2, s2 = bmul(S, g, sq)
                c = Fr(s1 - s2, 2)
                if c: out[m1] = Fm.add(out.get(m1, {}), Fm.wedge(om[A], {0: p}), c)
    return {m: x for m, x in out.items() if any(x.values())}
def contract(DX, E, n, b):
    """E_b -| (a multivector of 1-forms)"""
    ob = {}
    for S, form in DX.items():
        t = {}
        for mu in range(n):
            q = form.get(1 << mu); Eb = E[mu][b]
            if q and Eb: t = padd(t, pm(Eb, q))
        if t: ob[S] = t
    return ob
def nabla(Gv, om, E, X, n, deg):
    """nabla_b X = E_b -| D X, list over b; deg = x-degree of the jets kept (None: exact, no truncation)"""
    with trunc(n, xdeg=deg):
        DX = D_full(Gv, om, X); return [contract(DX, E, n, b) for b in range(n)]
def dirac(nab, n, sq):
    """sum_b gamma^b nabla_b X, gamma^b = sq_b gamma_b on the left (bit rule)"""
    out = {}
    for b in range(n):
        for S, p in nab[b].items():
            m, s = bmul(1 << b, S, sq); out[m] = padd(out.get(m, {}), p, s * sq[b])
    return {m: p for m, p in out.items() if p}
def second_cov(Gv, om, E, nab1, n, deg):
    """(nabla^2 X)(E_a, E_b) = E_a -| [ D(nabla_b X) - omega^c_b nabla_c X ] (the frame-index term from the engine's covector rule), jets to deg"""
    Fm = Gv.Fm; out = {}
    with trunc(n, xdeg=deg):
        Dn = [D_full(Gv, om, nab1[b]) for b in range(n)]
        Frm = [{} for _ in range(n)]
        for S in set().union(*[set(x) for x in nab1]):
            Xc = [({0: nab1[b][S]} if S in nab1[b] else {}) for b in range(n)]
            DX = Gv.D_covector(om, Xc)
            for b in range(n):
                f = Fm.add(DX[b], Fm.d(Xc[b]), -1)
                if any(f.values()): Frm[b][S] = f
        for a in range(n):
            for b in range(n):
                acc = {}
                for src in (Dn[b], Frm[b]):
                    c = contract(src, E, n, a)
                    acc = mvp_add(acc, c)
                out[(a, b)] = acc
    return out
def box_of(N2, n, sq):
    acc = {}
    for a in range(n): acc = mvp_add(acc, N2[(a, a)], sq[a])
    return acc

# ================================================================================================ route B: null-bit d and the pseudoscalar (no connection)
def mv_to_form(X, e, n, sq, deg):
    """X = sum X^S gamma_S -> the coordinate form sum X^S eta_S e^S (e^S a wedge of the coframe 1-forms; the null bits)"""
    Fm = Forms(n); out = {}
    with trunc(n, xdeg=deg):
        for S, p in X.items():
            if not p: continue
            f = {0: p}; etaS = 1
            for i in range(n):
                if S >> i & 1: f = Fm.wedge(f, e[i]); etaS *= sq[i]
            out = Fm.add(out, f, etaS)
    return out
def det_minor(E, rows, cols, n, deg):
    k = len(rows); tot = {}
    with trunc(n, xdeg=deg):
        for perm in itertools.permutations(range(k)):
            sgn = 1
            for i in range(k):
                for j in range(i + 1, k):
                    if perm[i] > perm[j]: sgn = -sgn
            t = {(0,) * n: Fr(sgn)}
            for i in range(k):
                q = E[rows[i]][cols[perm[i]]]
                if not q: t = {}; break
                t = pm(t, q)
            if t: tot = padd(tot, t)
    return tot
def form_to_mv(w, E, n, sq, deg):
    """coordinate form -> X^S = eta_S w(E_s1, ..., E_sk)"""
    out = {}
    for M, p in w.items():
        if not p: continue
        mus = [i for i in range(n) if M >> i & 1]; k = len(mus)
        for idx in itertools.combinations(range(n), k):
            dm = det_minor(E, mus, list(idx), n, deg)
            if not dm: continue
            with trunc(n, xdeg=deg): t = pm(p, dm)
            etaS = 1
            for i in idx: etaS *= sq[i]
            S = sum(1 << i for i in idx)
            if t: out[S] = padd(out.get(S, {}), t, etaS)
    return {S: p for S, p in out.items() if p}
def mul_const(X, Y, sq, left=False):
    """X (polynomial coefficients) times the constant multivector Y, on the right (or on the left)"""
    out = {}
    for S, p in X.items():
        for T, c in Y.items():
            m, s = bmul(T, S, sq) if left else bmul(S, T, sq)
            out[m] = padd(out.get(m, {}), p, s * c)
    return {m: p for m, p in out.items() if p}
def pseudo(n, sq):
    full = (1 << n) - 1; m, s = bmul(full, full, sq)
    return {full: Fr(1)}, {full: Fr(s)}                                   # I and I^-1 = (I I) I
def dB(X, e, E, n, sq, deg):
    """[bit] the exterior derivative of a field: the null-bit d of the form, read back in the frame (jets to deg)"""
    w = mv_to_form(X, e, n, sq, None if deg is None else deg + 1)
    with trunc(n, xdeg=deg): dw = Forms(n).d(w)
    return form_to_mv(dw, E, n, sq, deg)
def deltaB(X, e, E, n, sq, deg):
    """[bit] delta X = (d (X I^-1)) I; DUALLEFT: I d(I^-1 X)"""
    I, Ii = pseudo(n, sq)
    if fault('DUALLEFT'): return mul_const(dB(mul_const(X, Ii, sq, left=True), e, E, n, sq, deg), I, sq, left=True)
    return mul_const(dB(mul_const(X, Ii, sq), e, E, n, sq, deg), I, sq)

# ================================================================================================ frames
def engine_setup(e, n, sq, deg=1):
    """[bit] omega (closed form, jets to deg), dual frame jets, curvature at the origin, frame Ricci"""
    Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = bl.koszul_S(n, sq, Lie_)
    Dp = bl.anholonomy(Gv, e, n, deg); om = bl.omega_closed_form(Gv, e, S, n, deg, Dpre=Dp)[0]; E = Dp[1]
    e0, E0, det = bl.E0_of(e, n, n)
    with trunc(n, xdeg=1): T = Gv.torsion(om, e)
    tf = all(at0(p, n) == 0 for t in T for p in t.values())
    with trunc(n, xdeg=0): R0 = Gv.curvature(om)
    Rf = e1.curv_frame(Gv, R0, E0, n); ric = e1.ricci(Rf, n, sq)
    return dict(Gv=Gv, om=om, E=E, E0=E0, e=e, n=n, sq=list(sq), ric=ric, Rf=Rf, torsion_free=tf)
K = 3                                                                      # order of the univariate Taylor series below
class TS:
    """a univariate Taylor series in delta, exact, truncated at order K"""
    def __init__(self, c): c = [Fr(x) for x in c][:K + 1]; self.c = c + [Fr(0)] * (K + 1 - len(c))
    def __add__(s, o): o = o if isinstance(o, TS) else TS([o]); return TS([a + b for a, b in zip(s.c, o.c)])
    __radd__ = __add__
    def __neg__(s): return TS([-a for a in s.c])
    def __sub__(s, o): return s + (-(o if isinstance(o, TS) else TS([o])))
    def __rsub__(s, o): return (o if isinstance(o, TS) else TS([o])) + (-s)
    def __mul__(s, o):
        o = o if isinstance(o, TS) else TS([o]); r = [Fr(0)] * (K + 1)
        for i, a in enumerate(s.c):
            if a:
                for j in range(K + 1 - i): r[i + j] += a * o.c[j]
        return TS(r)
    __rmul__ = __mul__
    def inv(s):
        a0 = s.c[0]; r = [Fr(0)] * (K + 1); r[0] = 1 / a0
        for k in range(1, K + 1): r[k] = -sum(s.c[j] * r[k - j] for j in range(1, k + 1)) / a0
        return TS(r)
    def __truediv__(s, o): o = o if isinstance(o, TS) else TS([o]); return s * o.inv()
    def __rtruediv__(s, o): return (o if isinstance(o, TS) else TS([o])) * s.inv()
    def sqrt(s, r0):
        assert r0 > 0 and r0 * r0 == s.c[0]; r = [Fr(0)] * (K + 1); r[0] = Fr(r0)
        for k in range(1, K + 1): r[k] = (s.c[k] - sum(r[j] * r[k - j] for j in range(1, k))) / (2 * r0)
        return TS(r)
def tsv(x0): return TS([x0, 1])
def ts_poly(ts, slot, n):
    out = {}
    for k, v in enumerate(ts.c):
        if v: ex = [0] * n; ex[slot] = k; out[tuple(ex)] = v
    return out
def prod2(p, q, n=4): return bl.sp_mul(p, q, K, n)
def cone_frame(beta, t0, z0, r0):
    """(5.4)-(5.6) of paper 179 in the coordinates (t = e^s, z = tan(theta/2), phi, psi) around (t0, z0, 0, 0): e0 = a ds, e1 = b dtheta/2,
    e2 = -b sin(theta) dphi/2, e3 = c (dpsi + cos(theta) dphi)/2 with a = (2/beta) t/(t^2 + c0) sqrt(beta V), c = 2 t/(t^2 + c0)/sqrt(beta V), b = 2 a sinh s,
    beta V = (t^2 - c0)/(t^2 - 1) = r0^2 at t0 (so the Taylor coefficients are rational)"""
    beta = Fr(beta); c0 = 1 - beta; n = 4; t = tsv(Fr(t0)); z = tsv(Fr(z0))
    sw = ((t * t - c0) / (t * t - 1)).sqrt(Fr(r0)); pre = t / (t * t + c0)
    a = (2 / beta) * pre * sw; c = 2 * pre / sw; b = a * (t - 1 / t)
    oz = 1 / (1 + z * z); sth = 2 * z * oz; cth = (1 - z * z) * oz
    P = lambda ts, slot: ts_poly(ts, slot, n)
    return [{1 << 0: P(a / t, 0)}, {1 << 1: prod2(P(b, 0), P(oz, 1))}, {1 << 2: prod2(P(-b * Fr(1, 2), 0), P(sth, 1))},
            {1 << 3: P(c * Fr(1, 2), 0), 1 << 2: prod2(P(c * Fr(1, 2), 0), P(cth, 1))}]
def weak_frame(Npoly, pt, n=4):
    """e^0 = N(x) dx^0, e^i = dx^i (the weak static frame of ATY-037), N a polynomial expanded around the point"""
    one = {(0,) * n: Fr(1)}
    return [{1 << 0: bl.shift_poly(Npoly, pt, n)}] + [{1 << i: dict(one)} for i in range(1, n)]
def ds_frame(H, eta0, n=4):
    """de Sitter in conformal time, e^a = -dx^a/(H eta) (GRV-007's FRW frame), Taylor jets around eta0"""
    A = -1 / (Fr(H) * tsv(Fr(eta0))); return [{1 << a: ts_poly(A, 0, n)} for a in range(n)]
# the exact (Laurent) route: diagonal frames e^a = A_a dx^a with A_a a Laurent monomial; identities in the whole chart
def mono(n, exps, c): return {tuple(exps): Fr(c)}
def exact_setup(As, n, sq):
    Lie_ = Lie(sq); Gv = Grav(n, Lie_); S = bl.koszul_S(n, sq, Lie_); Fm = Gv.Fm
    e = [{1 << a: dict(As[a])} for a in range(n)]
    E = [[{} for _ in range(n)] for _ in range(n)]
    for a in range(n):
        (ex, c), = As[a].items(); E[a][a] = {tuple(-x for x in ex): 1 / Fr(c)}
    Om = {}
    for c in range(n):
        de = Fm.d(e[c])
        for mu in range(n):
            for nu in range(n):
                if mu < nu: p = de.get((1 << mu) | (1 << nu), {}); Om[(c, mu, nu)] = p; Om[(c, nu, mu)] = scale(p, -1)
    D = {}
    for c in range(n):
        for d_ in range(n):
            for b in range(d_ + 1, n):
                t = {}
                for mu in range(n):
                    for nu in range(n):
                        if mu != nu and Om[(c, mu, nu)] and E[mu][d_] and E[nu][b]: t = padd(t, pm(pm(E[mu][d_], E[nu][b]), Om[(c, mu, nu)]))
                D[(c, d_, b)] = t
    om = bl.omega_closed_form(Gv, e, S, n, None, Dpre=(D, E, None))[0]
    R = Gv.curvature(om); T = Gv.torsion(om, e)
    tf = all(not p for t in T for p in t.values())
    d = dict(Gv=Gv, e=e, E=E, om=om, R=R, n=n, sq=list(sq), torsion_free=tf)
    d['ric'] = ricci_exact(d); return d
def form2_eval(form, E, n, a, b):
    t = {}
    for mu in range(n):
        for nu in range(mu + 1, n):
            p = form.get((1 << mu) | (1 << nu))
            if not p: continue
            for (x, y, s) in ((mu, nu, 1), (nu, mu, -1)):
                if E[x][a] and E[y][b]: t = padd(t, pm(pm(E[x][a], E[y][b]), p), s)
    return t
def ricci_exact(d):
    """[bit] the frame Ricci R_bd = sum_a sq_b R^{ab}(E_a, E_d) as Laurent polynomials"""
    Gv, E, n, sq, R = d['Gv'], d['E'], d['n'], d['sq'], d['R']; Rf = {}
    for A, (c, dd) in enumerate(bl.pairs_of(Gv.L)):
        for a in range(n):
            for b in range(n):
                if a != b:
                    v = form2_eval(R[A], E, n, a, b)
                    if v: Rf[(c, dd, a, b)] = v; Rf[(dd, c, a, b)] = scale(v, -1)
    return {(b, dd): sum_polys([scale(Rf[(a, b, a, dd)], sq[b]) for a in range(n) if (a, b, a, dd) in Rf]) for b in range(n) for dd in range(n)}
def sum_polys(ps):
    acc = {}
    for p in ps: acc = padd(acc, p)
    return acc
def D_exact(d, X): return dirac(nabla(d['Gv'], d['om'], d['E'], X, d['n'], None), d['n'], d['sq'])
def box_exact(d, X):
    n = d['n']; nab = nabla(d['Gv'], d['om'], d['E'], X, n, None)
    return box_of(second_cov(d['Gv'], d['om'], d['E'], nab, n, None), n, d['sq'])
def ric_on(d, X, ric=None):
    """Ric(X)^b = sq_b R_bd X^d on a 1-form field (polynomial coefficients)"""
    n, sq = d['n'], d['sq']; ric = ric or d['ric']; out = {}
    for b in range(n):
        t = {}
        for dd in range(n):
            r = ric[(b, dd)]
            if r and X.get(1 << dd):
                t = padd(t, pm(r if isinstance(r, dict) else {(0,) * n: r}, X[1 << dd]), sq[b])
        if t: out[1 << b] = t
    return out

# ================================================================================================ (1)-(2) the Dirac operator and its square on the frames
head('(1)-(2) [se.DIRAC, se.WZB] the Dirac operator on the full algebra of a curved frame is d + delta; its square on 1-forms')
FAM = []                                                                  # (family, label, frame, n, sq, closed-form frame for numpy or None)
WEAK_N = {(0, 0, 0, 0): Fr(1), (0, 0, 0, 1): Fr(-1, 5), (0, 2, 0, 0): Fr(1, 7), (0, 0, 1, 1): Fr(-1, 9), (0, 0, 0, 2): Fr(1, 6)}
for pt in ([Fr(1, 3), Fr(1, 2), Fr(-1, 4), Fr(2, 5)], [Fr(0), Fr(-2, 3), Fr(1, 5), Fr(3, 4)]):
    FAM.append(('weak', 'N quadratic at %s' % ','.join(str(x) for x in pt), weak_frame(WEAK_N, pt), 4, [1, -1, -1, -1], ('weak', pt)))
CONES = [(Fr(1), Fr(5, 4), Fr(1, 2), Fr(5, 3)), (Fr(51, 64), Fr(2), Fr(1, 3), Fr(9, 8)), (Fr(27, 16), Fr(2), Fr(1, 2), Fr(5, 4)), (Fr(45, 64), Fr(3, 2), Fr(1, 2), Fr(5, 4))]
for beta, t0, z0, r0 in CONES:
    FAM.append(('cone', 'beta = %s, t = %s, z = %s' % (beta, t0, z0), cone_frame(beta, t0, z0, r0), 4, [1, 1, 1, 1], ('cone', beta, t0, z0)))
for H, eta0 in ((Fr(1), Fr(-1)), (Fr(1, 2), Fr(-3, 2))):
    FAM.append(('dS', 'H = %s, eta = %s' % (H, eta0), ds_frame(H, eta0), 4, [1, -1, -1, -1], ('dS', H, eta0)))
for seed in (8401, 8402):
    FAM.append(('random', 'seed %d' % seed, bl.rand_frame(random.Random(seed), 4, deg=2, coef=2, density=.5), 4, [1, -1, -1, -1], ('poly',)))
for seed, eps5 in ((8501, -1), (8502, 1)):
    rng = random.Random(seed); e4 = bl.rand_frame(rng, 4, deg=2, coef=2, density=.5)
    A = [h4.rand_poly4(rng, deg=2, coef=1, density=.4) for _ in range(4)]; phi = h4.rand_poly4(rng, deg=2, coef=2, density=.6, c0=2)
    FAM.append(('kk5', 'Cl(%d,%d), seed %d' % (((1, 4) if eps5 < 0 else (2, 3)) + (seed,)), h4.kk_frame(e4, A, phi), 5, [1, -1, -1, -1, eps5], None))
ok_tf = True; ok_dirac = True; ok_ctl_left = True; ok_ctl_noconn = True; ndirac = 0; ok_deg = True; ok_hodge = True; ok_odd = True
WZB = []; ok_rindler = None; ok_cone_ein = True; ok_ds_ric = True; famdata = {}
for fam, label, e, n, sq, closed in FAM:
    d = engine_setup(e, n, sq); Gv, om, E, E0 = d['Gv'], d['om'], d['E'], d['E0']; ok_tf &= d['torsion_free']
    famdata[(fam, label)] = d
    rng = random.Random(7 + 31 * len(famdata))
    if fam == 'cone':
        beta = closed[1]; lam = Fr(3, 2) * beta ** 2 * (2 - beta)
        ok_cone_ein &= all(d['ric'][(i, j)] == (lam if i == j else 0) for i in range(4) for j in range(4))
    if fam == 'dS':
        H = closed[1]; ok_ds_ric &= all(d['ric'][(i, j)] == (-3 * H * H * sq[i] if i == j else 0) for i in range(4) for j in range(4))
    # (1) every grade: D X = d X + delta X at the origin
    for k in range(2):
        X = {S: rpol(rng, n, 2) for S in range(1 << n)}
        DX0 = at0_mv(dirac(nabla(Gv, om, E, X, n, 0), n, sq), n)
        dX0 = at0_mv(dB(X, e, E, n, sq, 0), n); de0 = at0_mv(deltaB(X, e, E, n, sq, 0), n)
        ok_dirac &= DX0 == mv_add(dX0, de0); ndirac += 1
        if FAULT is None and n == 4:
            I, Ii = pseudo(n, sq)
            left = at0_mv(mul_const(dB(mul_const(X, Ii, sq, left=True), e, E, n, sq, 0), I, sq, left=True), n)
            ok_ctl_left &= DX0 != mv_add(dX0, left)
            Fm = Gv.Fm
            with trunc(n, xdeg=0): plain = [contract({S: Fm.d({0: p}) for S, p in X.items()}, E, n, b) for b in range(n)]
            ok_ctl_noconn &= at0_mv(dirac(plain, n, sq), n) != DX0
    # (2) 1-forms: D^2, box, Ric, the route-B Hodge Laplacian
    for k in range(2):
        X1 = {1 << a: rpol(rng, n, 2) for a in range(n)}
        nab1 = nabla(Gv, om, E, X1, n, 1); Phi = dirac(nab1, n, sq)
        ok_odd &= set(grades(at0_mv(Phi, n))) <= {0, 2}
        D2 = at0_mv(dirac(nabla(Gv, om, E, Phi, n, 0), n, sq), n)
        ok_deg &= grades(D2) == [1]
        N2 = second_cov(Gv, om, [[{(0,) * n: E0[mu][a]} if E0[mu][a] else {} for a in range(n)] for mu in range(n)], nab1, n, 0)   # the dual frame at the point
        Lap = at0_mv(box_of(N2, n, sq), n)
        X10 = at0_mv(X1, n)
        RicX = clean({1 << b: sum(sq[b] * d['ric'][(b, dd)] * X10.get(1 << dd, 0) for dd in range(n)) for b in range(n)})
        dX1 = dB(X1, e, E, n, sq, 1); deX1 = deltaB(X1, e, E, n, sq, 1)
        HB = mv_add(at0_mv(deltaB(dX1, e, E, n, sq, 0), n), at0_mv(dB(deX1, e, E, n, sq, 0), n))
        ok_hodge &= HB == D2
        WZB.append((fam, label, mv_add(D2, Lap, -1), RicX, D2, Lap, X1, closed, sq, n))
    if fam == 'weak' and ok_rindler is None:
        dr = engine_setup(weak_frame({(0, 0, 0, 0): Fr(1), (0, 0, 0, 1): Fr(-1, 10)}, [Fr(1, 3), Fr(1, 2), Fr(-1, 4), Fr(2, 5)]), 4, sq)
        ok_rindler = all(v == 0 for v in dr['Rf'].values()) and any(at0(p, 4) for f in dr['om'] for p in f.values())
print('    %d frames (weak 2, cone 4, de Sitter 2, random 2, five-dimensional 2), %d full-algebra fields, %d 1-forms (%.1f s)' % (len(FAM), ndirac, len(WZB), time.time() - T0), flush=True)
chk('bit', ok_tf and ok_cone_ein and ok_ds_ric and ok_rindler,
    'se.DIRAC: the frames on the engine: the closed-form omega is torsion-free at each frame point; the cones of ATY-036 have Ricci = (3/2) beta^2 (2 - beta) delta exactly at the four points (beta = 1, 51/64, 27/16, 45/64); de Sitter has R_ab = -3 H^2 eta_ab (H = 1, 1/2); the frame of ATY-037\'s check (N = 1 - x_3/10) has a non-zero connection and zero curvature (Rindler), so the weak-field frame is taken with N quadratic')
chk('bit', ok_dirac, 'se.DIRAC: D X = gamma^a nabla_a X equals d X + (d(X I^-1)) I exactly at the origin of all %d frames, %d random fields with all 2^n components (degree 2): the Dirac operator on the full algebra is d + delta, delta X = (d(X I^-1)) I from the null-bit d and the pseudoscalar alone, no connection' % (len(FAM), ndirac))
if FAULT is None:
    chk('ctl', ok_ctl_left and ok_ctl_noconn, 'se.DIRAC: controls: the left dual I d(I^-1 X) and nabla without the connection (D = gamma^a E_a) both differ from D X on every four-dimensional frame')
chk('bit', ok_odd and ok_deg, 'se.WZB: on 1-forms D X has grades 0 and 2 only and D^2 X grade 1 only (the 3-vector part vanishes: first Bianchi), on all %d frames: (d + delta)^2 keeps the degree' % len(FAM))
chk('bit', ok_hodge, 'se.WZB: (d + delta)^2 X = d delta X + delta d X computed by route B alone (null-bit d and the pseudoscalar, no connection) equals the literal D(D X) of route A (the spin connection) at every point, %d 1-forms' % len(WZB))
rows = []; rhs = []
for fam, label, res, RicX, D2, Lap, X1, closed, sq, n in WZB:
    for S in sorted(set(res) | set(RicX)): rows.append([RicX.get(S, Fr(0))]); rhs.append(res.get(S, Fr(0)))
w, rank, nvar, cons = bl.solve_exact(rows, rhs)
cpred = Fr(0) if fault('NORIC') else (Fr(1) if fault('RICSIGN') else Fr(-1))
ok_pred = all(res == mv_add({}, RicX, cpred) for fam, label, res, RicX, D2, Lap, X1, closed, sq, n in WZB)
nonzero = all(RicX for fam, label, res, RicX, *_ in WZB if fam in ('weak', 'cone', 'dS'))
chk('bit', cons and rank == 1 and w[0] == -1 and nonzero and ok_pred,
    'se.WZB: the exact fit D^2 X - box X = c Ric(X) over all components of %d 1-forms on %d frames (n = 4 and 5) has the single solution c = %s (predicted %s): D^2 = box - Ric in the Atlas\'s signs (Ric^b_d = eta^bb R_bd, R_bd = R^a_bad); with the paper\'s nabla^2 = -box and Ricci = -Ric (its signature (-,+,+,+)) this is D^2 + nabla^2 = Ricci, (3.2) as printed' % (len(WZB), len(FAM), w[0] if w else 'none', cpred))
cone_ok = all(res == mv_add({}, RicX, -1) and RicX == clean({S: Fr(3, 2) * closed[1] ** 2 * (2 - closed[1]) * v for S, v in at0_mv(X1, 4).items()}) for fam, label, res, RicX, D2, Lap, X1, closed, sq, n in WZB if fam == 'cone')
chk('bit', cone_ok and not fault('NORIC') and not fault('RICSIGN'), 'se.WZB: on the cones in Cl(4,0) (D = d - delta_g, so the Hodge Laplacian is -D^2 and the Bochner Laplacian -box): Hodge - Bochner = Ricci = (3/2) beta^2 (2 - beta) on every 1-form, exactly at the four points: the paper\'s (3.1)')
if FAULT is None:
    w0 = bl.solve_exact([[Fr(0)] for _ in rows], rhs)[3]
    wp_fail = all(res != mv_add({}, RicX, 1) for fam, label, res, RicX, *_ in WZB if RicX)
    chk('ctl', (not w0) and wp_fail, 'se.WZB: controls: no Ricci term (D^2 = box) is inconsistent with the data, and D^2 = box + Ric fails on every curved frame')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (3) the standard route
head('(3) [se.STD] numpy: metric, Christoffel symbols, Ricci, the rough Laplacian, d and the codifferential by the divergence formula, finite differences')
def stencil(fun, x, mu, h):
    e_ = np.zeros(len(x)); e_[mu] = h
    return (-fun(x + 2 * e_) + 8 * fun(x + e_) - 8 * fun(x - e_) + fun(x - 2 * e_)) / (12 * h)
def pval(p, x):
    if not p: return 0.0
    return sum(float(c) * np.prod([x[i] ** k[i] for i in range(len(x))]) for k, c in p.items())
class Std:
    """[std] no label: coordinates (shifted, the point at 0), g = e^T eta e from a closed-form frame, a 1-form phi_mu = sum_a eta_aa X^a e^a_mu"""
    def __init__(self, efun, eta, Xfun, h=1e-3):
        self.ef, self.eta, self.h, self.n, self.Xf = efun, np.diag(np.array(eta, float)), h, len(eta), Xfun
    def g(self, x): e_ = self.ef(x); return e_.T @ self.eta @ e_
    def Gam(self, x):
        n = self.n; gi = np.linalg.inv(self.g(x)); dg = np.array([stencil(self.g, x, k, self.h) for k in range(n)])
        return 0.5 * (np.einsum('ls,msn->lmn', gi, dg) + np.einsum('ls,nsm->lmn', gi, dg) - np.einsum('ls,smn->lmn', gi, dg))
    def ricci(self, x):
        n = self.n; G = self.Gam(x); dG = np.array([stencil(self.Gam, x, k, self.h) for k in range(n)])
        R = np.einsum('mrns->rsmn', dG) - np.einsum('nrms->rsmn', dG) + np.einsum('rml,lns->rsmn', G, G) - np.einsum('rnl,lms->rsmn', G, G)
        return np.einsum('rsrn->sn', R)
    def phi(self, x): return np.einsum('a,a,am->m', np.diag(self.eta), self.Xf(x), self.ef(x))
    def nphi(self, x): return np.array([stencil(self.phi, x, k, self.h) for k in range(self.n)]) - np.einsum('lmn,l->mn', self.Gam(x), self.phi(x))
    def rough(self, x):
        n = self.n; gi = np.linalg.inv(self.g(x)); G = self.Gam(x); Np = self.nphi(x); dN = np.array([stencil(self.nphi, x, k, self.h) for k in range(n)])
        return np.einsum('mn,mnr->r', gi, dN - np.einsum('lmn,lr->mnr', G, Np) - np.einsum('lmr,nl->mnr', G, Np))
    def sg(self, x): return math.sqrt(abs(np.linalg.det(self.g(x))))
    def delta1(self, x):
        f = lambda y: self.sg(y) * np.linalg.inv(self.g(y)) @ self.phi(y)
        return -sum(stencil(f, x, k, self.h)[k] for k in range(self.n)) / self.sg(x)
    def dphi(self, x): Dm = np.array([stencil(self.phi, x, k, self.h) for k in range(self.n)]); return Dm - Dm.T
    def hodge(self, x):
        n = self.n; dd = np.array([stencil(self.delta1, x, k, self.h) for k in range(n)])
        W = lambda y: self.sg(y) * np.linalg.inv(self.g(y)) @ self.dphi(y) @ np.linalg.inv(self.g(y)).T
        return dd - self.g(x) @ (sum(stencil(W, x, k, self.h)[k] for k in range(n)) / self.sg(x))
    def frame_vec(self, x, w): return np.diag(self.eta) * (np.linalg.inv(self.ef(x)).T @ w)
def closed_frame(closed):
    if closed[0] == 'weak':
        pt = np.array([float(v) for v in closed[1]])
        def ef(dx):
            x = pt + dx; m = np.eye(4); m[0, 0] = pval(WEAK_N, x); return m
        return ef
    if closed[0] == 'cone':
        beta, t0, z0 = float(closed[1]), float(closed[2]), float(closed[3]); c0 = 1 - beta
        def ef(dx):
            t, z = t0 + dx[0], z0 + dx[1]; w_ = (t * t - c0) / (t * t - 1); pre = t / (t * t + c0)
            a = 2 / beta * pre * math.sqrt(w_); c = 2 * pre / math.sqrt(w_); b = a * (t - 1 / t)
            m = np.zeros((4, 4)); m[0, 0] = a / t; m[1, 1] = b / (1 + z * z); m[2, 2] = -b * z / (1 + z * z); m[3, 3] = c / 2; m[3, 2] = c / 2 * (1 - z * z) / (1 + z * z)
            return m
        return ef
    if closed[0] == 'dS':
        H, eta0 = float(closed[1]), float(closed[2])
        return lambda dx: -1 / (H * (eta0 + dx[0])) * np.eye(4)
    return None
worst_w = 0.0; worst_c = 0.0; nstd = 0; worst_ctl = 1e9
for fam, label, res, RicX, D2, Lap, X1, closed, sq, n in WZB:
    if closed is None: continue
    if closed[0] == 'poly':
        e = [x for x in FAM if x[0] == fam and x[1] == label][0][2]
        ef = (lambda e_: (lambda dx: np.array([[pval(e_[a].get(1 << mu, {}), dx) for mu in range(4)] for a in range(4)])))(e)
    else: ef = closed_frame(closed)
    Xp = [X1.get(1 << a, {}) for a in range(4)]
    s = Std(ef, sq, (lambda Xp_: (lambda x: np.array([pval(p, x) for p in Xp_])))(Xp)); x0 = np.zeros(4)
    Ric = s.ricci(x0); gi = np.linalg.inv(s.g(x0)); ph = s.phi(x0); rp = Ric @ gi @ ph
    ro = s.rough(x0); hd = s.hodge(x0); de = s.delta1(x0)
    cR = 0.0 if fault('NORIC') else (-1.0 if fault('RICSIGN') else 1.0)
    scale_ = max(1.0, float(np.max(np.abs(hd))))
    worst_w = max(worst_w, float(np.max(np.abs(hd - (-ro + cR * rp)))) / scale_)
    worst_ctl = min(worst_ctl, float(np.max(np.abs(hd + ro))) / scale_)
    d = famdata[(fam, label)]
    lab = lambda Y: np.array([float(Y.get(1 << a, 0)) for a in range(4)])
    deB = at0_mv(deltaB(X1, d['e'], d['E'], 4, sq, 0), 4).get(0, Fr(0))
    dev = max(np.max(np.abs(s.frame_vec(x0, -hd) - lab(D2))), np.max(np.abs(s.frame_vec(x0, ro) - lab(Lap))), np.max(np.abs(s.frame_vec(x0, rp) - lab(RicX))), abs(-de - float(deB)))
    worst_c = max(worst_c, dev / scale_); nstd += 1
chk('std', worst_w < 1e-6, 'se.STD: numpy, finite differences (4-point stencils, h = 1e-3) on the closed-form frames (weak field, the cones with sqrt, de Sitter -1/(H eta), the random polynomial frames), %d 1-forms: Delta_g phi = -nabla^2 phi + Ric(phi) with Delta_g = d delta_g + delta_g d, delta_g the codifferential of g = e^T eta e (divergence formula with sqrt|g|): max deviation %.1e' % (nstd, worst_w))
chk('bit==std', worst_c < 1e-6, 'se.STD: the exact label values agree with numpy at the same points: D^2 X = -Delta_g phi, box X = nabla^2 phi, Ric(X) = Ric(phi), and delta X = -delta_g phi (the codifferential of the paper\'s metric -g), %d 1-forms, max deviation %.1e' % (nstd, worst_c))
if FAULT is None: chk('ctl', worst_ctl > 1e-2, 'se.STD: control: without the Ricci term, Delta_g phi + nabla^2 phi is not zero (smallest relative size %.2f over the curved frames)' % worst_ctl)
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (4) the shifted Ricci operators as series
head('(4) [se.SER] the three shifted Ricci operators with (3.2), as series in D^2 with coefficients in Q[kappa, tau]')
NS = 12
def kt_add(a, b, c=1):
    r = dict(a)
    for k, v in b.items():
        x = r.get(k, 0) + c * v
        if x: r[k] = x
        else: r.pop(k, None)
    return r
def kt_mul(a, b):
    r = {}
    for (i, j), v in a.items():
        for (k, l), w_ in b.items():
            key = (i + k, j + l); x = r.get(key, 0) + v * w_
            if x: r[key] = x
            else: r.pop(key, None)
    return r
def s_mul(A, B):
    out = [{} for _ in range(NS + 1)]
    for i, a in enumerate(A):
        if a:
            for j in range(NS + 1 - i):
                if B[j]: out[i + j] = kt_add(out[i + j], kt_mul(a, B[j]))
    return out
def s_lin(*terms):
    out = [{} for _ in range(NS + 1)]
    for c, A in terms:
        for i in range(NS + 1):
            if A[i]: out[i] = kt_add(out[i], kt_mul(c, A[i]) if isinstance(c, dict) else {k: v * c for k, v in A[i].items()})
    return out
KAP = {(1, 0): Fr(1)}; ONE = {(0, 0): Fr(1)}
def s_exp(sgn): return [{(0, k): Fr(sgn) ** k / math.factorial(k)} for k in range(NS + 1)]
Dser = [{}, dict(ONE)] + [{} for _ in range(NS - 1)]
em, ep = s_exp(-1), s_exp(1); sinh_ = s_lin((Fr(1, 2), ep), (Fr(-1, 2), em))
Dp = s_lin((1, Dser), (KAP, em)); Dm = s_lin((1, Dser), ({(1, 0): Fr(-1)}, ep)); Ds = s_lin((1, Dser), (KAP, sinh_))
Fa_full = s_mul(Dp, Dp)
Fa = Fa_full if fault('KEEPODD') else [x if j % 2 == 0 else {} for j, x in enumerate(Fa_full)]
Fb = s_mul(Dp, Dm); Fc = s_mul(Ds, Ds); D2s = s_mul(Dser, Dser)
G = {'a': s_lin((1, Fa), (-1, D2s)), 'b': s_lin((1, Fb), (-1, D2s)), 'c': s_lin((1, Fc), (-1, D2s))}       # Ricci_xx - Ricci, with D^2 + nabla^2 = Ricci
def closed_c(x, j):
    """the closed forms: c_j of the three operators (coefficient of D^2j), from D sinh(tau D), cosh(2 tau D), sinh^2(tau D)"""
    ds = {(1, 2 * j - 1): Fr(2, math.factorial(2 * j - 1))} if j >= 1 else {}
    ch = {(2, 2 * j): Fr(2 ** (2 * j), math.factorial(2 * j))}
    if x == 'a': return kt_add({k: -v for k, v in ds.items()}, ch)
    if x == 'b': return kt_add({k: -v for k, v in ds.items()}, {(2, 0): Fr(-1)} if j == 0 else {})
    return kt_add(ds, {(2, 2 * j): Fr(2 ** (2 * j), 2 * math.factorial(2 * j))} if j >= 1 else {})
okc = all(G[x][2 * j] == closed_c(x, j) for x in 'abc' for j in range(NS // 2 + 1)) and all(not G[x][2 * j + 1] for x in 'abc' for j in range(NS // 2))
def kt_str(p):
    if not p: return '0'
    parts = []
    for (i, j), v in sorted(p.items(), key=lambda t: (t[0][1], t[0][0])):
        mon = ' '.join(([('kappa' if i == 1 else 'kappa^%d' % i)] if i else []) + ([('tau' if j == 1 else 'tau^%d' % j)] if j else []))
        coef = '' if (abs(v) == 1 and mon) else str(abs(v)) + (' ' if mon else '')
        parts.append(('- ' if v < 0 else '+ ') + coef + mon)
    s = ' '.join(parts); return s[2:] if s.startswith('+ ') else '-' + s[1:] if s.startswith('- ') else s
for x, name in (('a', 'c(D_+^2) + nabla^2'), ('b', 'D_+ D_- + nabla^2'), ('c', 'D_s^2 + nabla^2')):
    print('    Ricci_%s = %s = Ricci + [%s] + [%s] D^2 + [%s] D^4 + [%s] D^6 + ...' % ({'a': '++', 'b': '+-', 'c': 'ss'}[x], name, kt_str(G[x][0]), kt_str(G[x][2]), kt_str(G[x][4]), kt_str(G[x][6])))
chk('bit', okc, 'se.SER: with D^2 + nabla^2 = Ricci (checked above), Ricci_xx = Ricci + sum_j c_j D^2j exactly as polynomials in (kappa, tau) to order D^%d: c_0 = kappa^2, -kappa^2, 0; c_1 = -2 kappa tau + 2 kappa^2 tau^2, -2 kappa tau, 2 kappa tau + kappa^2 tau^2; c_2 = -kappa tau^3/3 + 2 kappa^2 tau^4/3, -kappa tau^3/3, kappa tau^3/3 + kappa^2 tau^4/3; every c_j the closed form of ATY-010 (from D sinh(tau D), cosh(2 tau D), sinh^2(tau D)); no odd powers' % NS)
chk('bit', ok_odd and ok_deg and not fault('KEEPODD'), 'se.SER: on the labels D maps 1-forms to grades 0 and 2 and D^2 keeps grade 1 (the %d frames of (1)), so P D^(2j+1) I = 0 and P D^2j I = D^2j on 1-forms: the compression (3.4) c(D_+^2) = P (D_+)^2 I is exactly the even part of the series' % len(FAM))
errs = []
for kap, tau, Dv in ((0.7, 0.3, 0.4), (-1.1, 0.2, 0.9), (0.5, -0.4, 1.3)):
    sh = math.sinh(tau * Dv)
    closed_vals = {'a': Dv * Dv - 2 * kap * Dv * sh + kap * kap * math.cosh(2 * tau * Dv), 'b': Dv * Dv - 2 * kap * Dv * sh - kap * kap, 'c': Dv * Dv + 2 * kap * Dv * sh + kap * kap * sh * sh}
    for x, Fx in (('a', Fa), ('b', Fb), ('c', Fc)):
        val = sum(float(v) * kap ** i * tau ** j * Dv ** k for k, c_ in enumerate(Fx) for (i, j), v in c_.items())
        errs.append(abs(val - closed_vals[x]))
chk('std', max(errs) < 1e-9, 'se.SER: numpy closed forms at three (kappa, tau, D) against the series truncated at D^%d: max deviation %.1e' % (NS, max(errs)))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (5) lowest order
head('(5) [se.LOW] the lowest order (3.6a-c) and the frames it selects, exactly in the chart (Laurent polynomials)')
H1 = Fr(1)
dS = exact_setup([mono(4, (-1, 0, 0, 0), -1 / H1)] * 4, 4, [1, -1, -1, -1])                       # e^a = -dx^a/(H eta)
AdS = exact_setup([mono(4, (0, 0, 0, -1), 1 / H1)] * 4, 4, [1, -1, -1, -1])                       # e^a = dx^a/(H z), Poincare
PL = exact_setup([mono(4, (2, 0, 0, 0), 1)] * 4, 4, [1, -1, -1, -1])                               # e^a = eta^2 dx^a (not Einstein)
const = lambda d, v: all(d['ric'][(i, j)] == ({(0, 0, 0, 0): Fr(v * d['sq'][i])} if i == j and v else {}) for i in range(4) for j in range(4))
ok_ricds = const(dS, -3 * H1 * H1) and const(AdS, 3 * H1 * H1) and dS['torsion_free'] and AdS['torsion_free'] and PL['torsion_free']
LamS = 3 * H1 * H1
# at order tau^0 the operators on any 1-form are (Ricci_paper + c_0): Ricci_paper = -Ric (Atlas) = Lambda on de Sitter, -3H^2 on anti-de Sitter
sel = {}
for frame, lam_p in (('de Sitter', LamS), ('anti-de Sitter', -LamS), ('flat', Fr(0))):
    for x in 'abc':
        c0 = G[x][0].get((2, 0), Fr(0))                                     # c_0 = c0 kappa^2
        # (Lambda + c0 kappa^2) = 0 for some kappa^2 >= 0?
        sel[(frame, x)] = (lam_p == 0 and c0 == 0) or (c0 != 0 and -lam_p / c0 > 0)
ok_sel = sel[('de Sitter', 'b')] and sel[('anti-de Sitter', 'a')] and sel[('flat', 'c')] and not any(sel[(f, x)] for f, x in (('de Sitter', 'a'), ('de Sitter', 'c'), ('anti-de Sitter', 'b'), ('anti-de Sitter', 'c'), ('flat', 'a'), ('flat', 'b')))
chk('bit', ok_ricds, 'se.LOW: on the labels, exactly in the chart: de Sitter e^a = -dx^a/(H eta) has R_ab = -3 H^2 eta_ab (the Ricci endomorphism -Lambda, Lambda = 3 H^2), anti-de Sitter e^a = dx^a/(H z) has R_ab = +3 H^2 eta_ab (H = 1); in the paper\'s signature the endomorphisms are +Lambda and -3 H^2')
chk('bit', ok_sel and okc, 'se.LOW: at order D^0 the three operators on every 1-form are Ricci + c_0 with c_0 = kappa^2, -kappa^2, 0: (3.6a) Ricci = -kappa^2 holds on anti-de Sitter (Lambda = -kappa^2), (3.6b) Ricci = kappa^2 on de Sitter (Lambda = kappa^2), (3.6c) Ricci = 0 on flat space, and no other pairing of the three: in the Atlas\'s signature Ric = kappa^2, -kappa^2, 0, the same three spaces')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (6) zero-mode next orders
head('(6) [se.ZERO] the next orders in the zero-mode reading: D^2 -> Ricci on an Einstein metric, lambda + sum_j c_j lambda^j = 0, roots as series in mu')
M = 8
def ser_mul(a, b): return [sum(a[i] * b[k - i] for i in range(k + 1)) for k in range(M + 1)]
def ser_pow(a, j):
    r = [Fr(1)] + [Fr(0)] * M
    for _ in range(j): r = ser_mul(r, a)
    return r
def ser_inv(a):
    r = [Fr(0)] * (M + 1); r[0] = 1 / a[0]
    for k in range(1, M + 1): r[k] = -sum(a[j] * r[k - j] for j in range(1, k + 1)) / a[0]
    return r
def Cj(x, j):
    """c_j kappa^(2j - 2) as a series in mu = kappa tau (homogeneous: kappa^i tau^k with i + 2j - 2 = k)"""
    out = [Fr(0)] * (M + 1)
    for (i, k), v in G[x][2 * j].items():
        assert i + 2 * j - 2 == k
        if k <= M: out[k] += v
    return out
def root_series(x):
    """y(mu) = lambda/kappa^2 with f(y) = y + sum_j C_j y^j = 0, the root near -C_0"""
    C = [Cj(x, j) for j in range(NS // 2 + 1)]
    lin = ser_inv([Fr(1) + C[1][0]] + [C[1][k] for k in range(1, M + 1)])
    y = [-C[0][0]] + [Fr(0)] * M
    for _ in range(M + 2):
        rest = [C[0][k] for k in range(M + 1)]
        for j in range(2, len(C)): rest = [r + v for r, v in zip(rest, ser_mul(C[j], ser_pow(y, j)))]
        y = [-v for v in ser_mul(rest, lin)]
    f = [y[k] + C[0][k] for k in range(M + 1)]
    for j in range(1, len(C)): f = [r + v for r, v in zip(f, ser_mul(C[j], ser_pow(y, j)))]
    return y, all(v == 0 for v in f)
ya, oka = root_series('a'); yb, okb = root_series('b'); yc, okc0 = root_series('c')
def sstr(y, k=5): return ' + '.join('(%s) mu^%d' % (y[i], i) if i else str(y[0]) for i in range(k) if y[i]) + ' + ...'
print('    lambda_a/kappa^2 = %s' % sstr(ya)); print('    lambda_b/kappa^2 = %s' % sstr(yb)); print('    lambda_c = 0 to every order computed: %s' % all(v == 0 for v in yc))
chk('bit', oka and okb and okc0 and ya[:4] == [Fr(-1), Fr(-2), Fr(-2), Fr(1, 3)] and yb[:4] == [Fr(1), Fr(2), Fr(4), Fr(25, 3)] and all(v == 0 for v in yc),
    'se.ZERO: on an Einstein metric (Ricci = lambda, which commutes with everything) the leading equation of the paper, D^2 -> Ricci, is lambda + sum_j c_j lambda^j = 0; its roots near the lowest order, exactly to mu^%d (mu = kappa tau): lambda_a = -kappa^2 (1 + 2 mu + 2 mu^2 - mu^3/3 + ...), lambda_b = kappa^2 (1 + 2 mu + 4 mu^2 + 25 mu^3/3 + ...), lambda_c = 0 exactly: the corrections to (3.6a), (3.6b) start at first order in mu, (3.6c) has none' % M)
def f_closed(x, lam, kap, tau):
    if lam >= 0: s = math.sqrt(lam); ssh = s * math.sinh(tau * s); ch2 = math.cosh(2 * tau * s); sh2 = math.sinh(tau * s) ** 2
    else: s = math.sqrt(-lam); ssh = -s * math.sin(tau * s); ch2 = math.cos(2 * tau * s); sh2 = -math.sin(tau * s) ** 2
    if x == 'a': return lam - 2 * kap * ssh + kap * kap * ch2
    if x == 'b': return lam - 2 * kap * ssh - kap * kap
    return lam + 2 * kap * ssh + kap * kap * sh2
dev = 0.0; dev1 = 0.0
for mu in (0.003, 0.01, 0.03, 0.1):
    for x, y, guess in (('a', ya, -1.0), ('b', yb, 1.0)):
        r = brentq(lambda l: f_closed(x, l, 1.0, mu), guess - 0.5, guess + 0.5, xtol=1e-15)
        ser = sum(float(y[k]) * mu ** k for k in range(M + 1))
        if mu < 0.05: dev = max(dev, abs(r - ser))
        else: dev1 = max(dev1, abs(r - ser) / abs(r))
chk('std', dev < 1e-10 and dev1 < 1e-5, 'se.ZERO: numpy brentq on the closed forms (kappa = 1): the roots agree with the series truncated at mu^%d to %.1e at mu = 0.003, 0.01, 0.03 and to %.1e (relative) at mu = 0.1, the size of the next terms' % (M, dev, dev1))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (7) de Sitter: which of (3.5) vanishes to which order
head('(7) [se.WAVE] de Sitter on the labels, exactly in the chart; the residuals of (3.5a-c) by order in mu; the paper\'s doubt about (3.10)')
rng = random.Random(77)
cR = 0 if fault('NORIC') else (-1 if fault('RICSIGN') else 1)       # D^2 - box + cR Ric = 0 (cR = 1 is the claim)
def proportional(Y, X):
    """is Y = c X for one rational c (polynomial multivector fields)?"""
    for S, p in X.items():
        for ex, v in p.items():
            c = Y.get(S, {}).get(ex, Fr(0)) / v; return mvp_add(Y, X, -c) == {}
    return Y == {}
ok_ds2 = True; ok_ds46 = True; ok_ads2 = True; ok_gen = True
ok_pl = all(PL['ric'][(i, j)] == ({(-6, 0, 0, 0): Fr(6)} if i == j else {}) for i in range(4) for j in range(4))   # R_ab = 6 eta^-6 delta_ab: not Einstein
for trial in range(2):
    X = {1 << a: rpol(rng, 4, 2) for a in range(4)}
    D2 = D_exact(dS, D_exact(dS, X)); B1 = box_exact(dS, X)
    ok_ds2 &= mvp_add(mvp_add(D2, B1, -1), X, -LamS * cR) == {}
    if trial == 0:
        D4 = D_exact(dS, D_exact(dS, D2)); B2 = box_exact(dS, B1)
        ok_ds46 &= mvp_add(mvp_add(mvp_add(D4, B2, -1), B1, -2 * LamS), X, -LamS ** 2) == {}
        D6 = D_exact(dS, D_exact(dS, D4)); B3 = box_exact(dS, B2)
        ok_ds46 &= mvp_add(mvp_add(mvp_add(mvp_add(D6, B3, -1), B2, -3 * LamS), B1, -3 * LamS ** 2), X, -LamS ** 3) == {}
        # a general 1-form: D^2 X is not a multiple of X (the order-mu residual -2 kappa tau D^2 X is a differential operator)
        ok_gen &= not proportional(D2, X)
    Da = D_exact(AdS, D_exact(AdS, X)); Ba = box_exact(AdS, X)
    ok_ads2 &= mvp_add(mvp_add(Da, Ba, -1), X, 3 * H1 * H1 * cR) == {}
    PLric = PL['ric']
    Dp_ = D_exact(PL, D_exact(PL, X)); Bp = box_exact(PL, X)
    ok_pl &= mvp_add(mvp_add(Dp_, Bp, -1), ric_on(PL, X), cR) == {}
    comm = mvp_add(box_exact(PL, ric_on(PL, X)), ric_on(PL, box_exact(PL, X)), -1)
    commS = mvp_add(box_exact(dS, ric_on(dS, X)), ric_on(dS, box_exact(dS, X)), -1)
    ok_pl &= comm != {} and commS == {}
chk('bit', ok_ds2 and ok_ads2, 'se.WAVE: exactly in the chart (Laurent polynomials in eta, resp. z), on random polynomial 1-forms: D^2 X = box X + Lambda X on de Sitter (Lambda = 3 H^2, H = 1) and D^2 X = box X - 3 H^2 X on anti-de Sitter: the Weitzenboeck formula with a constant Ricci operator')
chk('bit', ok_ds46, 'se.WAVE: on de Sitter D^4 = box^2 + 2 Lambda box + Lambda^2 and D^6 = (box + Lambda)^3 exactly (D applied four and six times): every series in D^2 is the same series in box + Lambda, so on the 1-forms that solve (3.10), box X = 0, each shifted operator acts as the number F_x(Lambda), its series in Lambda')
# the homogeneous 1-forms eta^p gamma_a: the wave operator is a quadratic in p, exactly
quad = {}
for a in (0, 1):
    vals = []
    for p in range(-2, 4):
        L = box_exact(dS, {1 << a: {(p, 0, 0, 0): Fr(1)}})
        vals.append((p, L.get(1 << a, {}).get((p, 0, 0, 0), Fr(0)), len(L) == 1 and len(L.get(1 << a, {})) == 1))
    q = [Fr(0), Fr(0), Fr(0)]
    q[0] = vals[2][1]; q2 = (vals[3][1] - 2 * vals[2][1] + vals[1][1]) / 2; q1 = vals[3][1] - vals[2][1] - q2
    quad[a] = (q2, q1, q[0], all(v[2] for v in vals) and all(v[1] == q2 * v[0] ** 2 + q1 * v[0] + q[0] for v in vals))
ok_quad = quad[0][:3] == (Fr(1), Fr(-3), Fr(-3)) and quad[1][:3] == (Fr(1), Fr(-3), Fr(-1)) and quad[0][3] and quad[1][3]
chk('bit', ok_quad, 'se.WAVE: on de Sitter (H = 1) the wave operator maps eta^p gamma_0 to (p^2 - 3p - 3) eta^p gamma_0 and eta^p gamma_i to (p^2 - 3p - 1) eta^p gamma_i, exactly for p = -2..3: the homogeneous solutions of (3.10) have p = (3 +- sqrt 21)/2 and (3 +- sqrt 13)/2, irrational, so they are not Laurent fields on the labels; numpy checks them below')
# numpy: the irrational solutions satisfy box X = 0 and D^2 X = Lambda X
devw = 0.0
for a, p in ((0, (3 + math.sqrt(21)) / 2), (0, (3 - math.sqrt(21)) / 2), (1, (3 + math.sqrt(13)) / 2), (2, (3 - math.sqrt(13)) / 2)):
    eta0 = -1.3
    sw = Std(lambda dx: -1 / (eta0 + dx[0]) * np.eye(4), [1, -1, -1, -1], (lambda a_, p_: (lambda x: np.array([(-(eta0 + x[0])) ** p_ if b == a_ else 0.0 for b in range(4)])))(a, p))
    x0 = np.zeros(4); ro = sw.rough(x0); hd = sw.hodge(x0); ph = sw.phi(x0)
    devw = max(devw, float(np.max(np.abs(ro))) / max(1, float(np.max(np.abs(ph)))), float(np.max(np.abs(-hd - 3 * ph))) / max(1, float(np.max(np.abs(ph)))))
chk('std', devw < 1e-7, 'se.WAVE: numpy, finite differences on de Sitter (H = 1, eta = -1.3): the four homogeneous 1-forms (-eta)^p gamma_a with the irrational exponents satisfy box X = 0 and D^2 X = -Delta_g X = Lambda X (max deviation %.1e): the 1-forms the paper restricts to exist, and D^2 acts on them as Lambda' % devw)
# residuals F_x(eps kappa^2)/kappa^2 as series in mu, against the closed forms
def taylor(fn):
    """exact Taylor coefficients to mu^M of sin, cos, sinh, cosh"""
    out = []
    for k in range(M + 1):
        f = Fr(1, math.factorial(k))
        if fn == 'sinh': out.append(f if k % 2 else Fr(0))
        elif fn == 'cosh': out.append(Fr(0) if k % 2 else f)
        elif fn == 'sin': out.append(f * (-1) ** ((k - 1) // 2) if k % 2 else Fr(0))
        else: out.append(Fr(0) if k % 2 else f * (-1) ** (k // 2))
    return out
def residual(x, eps):
    """F_x(eps kappa^2)/kappa^2 = eps + sum_j C_j(mu) eps^j, a series in mu"""
    r = [Fr(eps)] + [Fr(0)] * M
    for j in range(NS // 2 + 1): r = [a + b * Fr(eps) ** j for a, b in zip(r, Cj(x, j))]
    return r
one = [Fr(1)] + [Fr(0)] * M; sh, ss, ch, cs = taylor('sinh'), taylor('sin'), taylor('cosh'), taylor('cos')
add = lambda *ts: [sum(c * t[k] for c, t in ts) for k in range(M + 1)]
want = {('b', 1): add((-2, sh)), ('a', -1): ser_mul(add((2, ss)), add((1, one), (-1, ss))), ('c', 1): ser_mul(add((1, one), (1, sh)), add((1, one), (1, sh))),
        ('c', -1): add((-1, ser_mul(add((1, one), (1, ss)), add((1, one), (1, ss))))), ('a', 1): add((2, ser_mul(ch, ch)), (-2, sh)), ('b', -1): add((-2, one), (2, ss)), ('c', 0): [Fr(0)] * (M + 1)}
okr = all(residual(x, eps) == want[(x, eps)] for (x, eps) in want)
first = {k: next((i for i, v in enumerate(residual(*k)) if v), None) for k in want}
print('    first non-zero order in mu of F_x(eps kappa^2)/kappa^2: ' + ', '.join('(3.5%s) at Lambda = %s: %s' % (x, {1: 'kappa^2', -1: '-kappa^2', 0: '0'}[eps], ('mu^%d, coefficient %s' % (first[(x, eps)], residual(x, eps)[first[(x, eps)]])) if first[(x, eps)] is not None else 'none') for (x, eps) in sorted(want)))
ok_orders = first[('b', 1)] == 1 and first[('a', -1)] == 1 and first[('c', 1)] == 0 and first[('c', -1)] == 0 and first[('c', 0)] is None and first[('a', 1)] == 0 and first[('b', -1)] == 0 and residual('b', 1)[1] == -2 and residual('a', -1)[1] == 2
chk('bit', okr and ok_orders, 'se.WAVE: on the 1-forms with box X = 0, exactly to mu^%d: (3.5b) at Lambda = kappa^2 leaves -2 kappa^2 sinh(mu) X (zero at order mu^0, -2 kappa^2 mu at order mu^1); (3.5a) at Lambda = -kappa^2 leaves 2 kappa^2 sin(mu)(1 - sin mu) X (2 kappa^2 mu); (3.5c) leaves kappa^2 (1 + sinh mu)^2 X at Lambda = kappa^2 and -kappa^2 (1 + sin mu)^2 X at -kappa^2 (order mu^0) and nothing at Lambda = 0 (every order); the mismatched pairs (3.5a) at kappa^2 and (3.5b) at -kappa^2 fail at order mu^0' % M)
# the expansion in the wave operator on de Sitter: Ricci_xx = Lambda + sum_j c_j (box + Lambda)^j = F_x(Lambda) + F_x'(Lambda) box + ...; the coefficient of box
def dres(x, eps):
    """sum_{j>=1} j c_j Lambda^(j-1) at Lambda = eps kappa^2, a dimensionless series in mu"""
    r = [Fr(0)] * (M + 1)
    for j in range(1, NS // 2 + 1): r = [a + j * b * Fr(eps) ** (j - 1) for a, b in zip(r, Cj(x, j))]
    return r
shift = lambda t: [Fr(0)] + t[:M]                                          # mu times a series
s2 = [Fr(2) ** k * v for k, v in enumerate(ss)]                             # sin(2 mu)
wantd = {('b', 1): add((-1, sh), (-1, shift(ch))), ('a', -1): add((1, shift(s2)), (-1, ss), (-1, shift(cs))), ('c', 0): add((2, shift(one)), (1, shift(shift(one))))}
okd = all(dres(x, eps) == wantd[(x, eps)] for (x, eps) in wantd)
print('    the coefficient of box (the first term of the low-energy expansion on de Sitter): (3.5b) at Lambda = kappa^2: %s; (3.5a) at Lambda = -kappa^2: %s; (3.5c) at Lambda = 0: %s' % tuple(sstr(dres(x, e_), 4) for x, e_ in (('b', 1), ('a', -1), ('c', 0))))
chk('bit', okd, 'se.WAVE: the expansion in the wave operator ("convert to an expansion in nabla^2"): on de Sitter Ricci_xx = F_x(Lambda) + F_x\'(Lambda) box + ..., exactly to mu^%d: at Lambda = kappa^2 the coefficient of box in (3.5b) is -(sinh mu + mu cosh mu) = -2 mu - 2 mu^3/3 - ..., at Lambda = -kappa^2 in (3.5a) mu sin(2 mu) - sin mu - mu cos mu = -2 mu + 2 mu^2 + ..., in (3.5c) at Lambda = 0 2 mu + mu^2: every correction beyond the constant is of order mu' % M)
chk('bit', ok_gen, 'se.WAVE: on a general polynomial 1-form on de Sitter D^2 X = box X + Lambda X is not a multiple of X: at order mu^1 the residual of (3.5b) at Lambda = kappa^2 is -2 kappa tau D^2 X, a differential operator on X, which vanishes only where D^2 X = 0; on the solutions of (3.10) it is -2 kappa tau Lambda X')
chk('bit', ok_pl, 'se.WAVE: on the FRW frame e^a = eta^2 dx^a (not Einstein: R_ab = 6 eta^-6 delta_ab) the Weitzenboeck formula holds exactly in the chart and [box, Ric] X != 0 on random 1-forms, while on de Sitter [box, Ric] = 0: on a solution of (3.10) D^2 X = -Ric X is tensorial (the D^2 terms, through order mu^2), but D^4 X = Ric^2 X - box(Ric X) is not (the D^4 term, order mu^3): "Delta need not commute with the Ricci operator", computed; on de Sitter the restriction is consistent to every order')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (8)-(9) the fifth generator: Kaluza-Klein on Cl(1,4)
head('(8)-(9) [se.KK, se.RADIUS] the fifth generator: e^4 = phi dy on the labels of Cl(1,4) and Cl(2,3), F = 0')
ok_red = True; ok_red_std = True; ok_box = True; ok_ctl_warp = True; nkk = 0
for seed in (8601, 8602, 8603):
    for eps5 in (-1, 1):
        rng = random.Random(seed); e4 = bl.rand_frame(rng, 4, deg=2, coef=2, density=.5)
        phi = h4.rand_poly4(rng, deg=2, coef=2, density=.6, c0=rng.choice([1, 2, -3])); A0 = [{} for _ in range(4)]
        e5 = h4.kk_frame(e4, A0, phi); sq5 = [1, -1, -1, -1, eps5]
        d5 = engine_setup(e5, 5, sq5); d4 = engine_setup(e4, 4, [1, -1, -1, -1])
        E04 = [[{(0,) * 4: d4['E0'][mu][a]} if d4['E0'][mu][a] else {} for a in range(4)] for mu in range(4)]
        N2 = second_cov(d4['Gv'], d4['om'], E04, nabla(d4['Gv'], d4['om'], d4['E'], {0: phi}, 4, 1), 4, 0)
        Hs = {(a, b): at0(N2[(a, b)].get(0, {}), 4) for a in range(4) for b in range(4)}
        box = sum(d4['sq'][a] * Hs[(a, a)] for a in range(4)); p0 = at0(phi, 4); r5, r4 = d5['ric'], d4['ric']
        sgn = 1 if fault('WARPSIGN') else -1
        ok_red &= all(r5[(a, b)] == r4[(a, b)] + sgn * Hs[(a, b)] / p0 for a in range(4) for b in range(4)) and all(r5[(a, 4)] == 0 == r5[(4, a)] for a in range(4)) and r5[(4, 4)] == -eps5 * box / p0
        ok_ctl_warp &= any(r5[(a, b)] != r4[(a, b)] + Hs[(a, b)] / p0 for a in range(4) for b in range(4))
        g = bl.std_metric(e5, 5, sq5, 5, 2); R1, g0, g0i = bl.std_riemann(g, 5, 5, 1)
        ricc = [[sum(R1[(r, s, r, v)] for r in range(5)) for v in range(5)] for s in range(5)]
        e0, E0s, det = bl.E0_of(e5, 5, 5)
        ok_red_std &= all(sum(E0s[m][a] * E0s[v][b] * ricc[m][v] for m in range(5) for v in range(5)) == r5[(a, b)] for a in range(5) for b in range(5))
        ok_box &= box == h4.std4_pieces(e4, A0, phi)['box']; nkk += 1
chk('bit', ok_red, 'se.KK: on the labels of Cl(1,4) and Cl(2,3) (the fifth generator squaring -1 and +1), e^4 = phi dy, F = 0, exactly at the origin of %d random frames: Ric5_ab = Ric4_ab - (nabla_a nabla_b phi)/phi, Ric5_a4 = 0, Ric5_44 = -eta_44 (box phi)/phi; the Hessian from the four-dimensional engine (the covariant derivative of d phi), the two Ricci tensors from the engine\'s curvature' % nkk)
chk('bit==std', ok_red_std and ok_box, 'se.KK: the Christoffel route on the five-dimensional metric e^T diag(sq) e (exact) gives the same Ric5 in all 25 frame components, and box phi equals h4_kaluza_klein\'s four-dimensional standard route, %d frames' % nkk)
if FAULT is None: chk('ctl', ok_ctl_warp, 'se.KK: control: Ric5_ab = Ric4_ab + Hess phi/phi fails on every frame')
# (9): the 44 component of Ric5 = -eps kappa^2 eta5 (Atlas) is box phi = eps kappa^2 phi for both squares of the fibre; constant sigma over de Sitter
def kk_ds(H, p, eps5=-1):
    sgnp = Fr(-1) ** (p % 2)                                                 # (-eta)^p = (-1)^p eta^p
    return exact_setup([mono(5, (-1, 0, 0, 0, 0), -1 / Fr(H))] * 4 + [mono(5, (p, 0, 0, 0, 0), sgnp)], 5, [1, -1, -1, -1, eps5])
ok_44 = ok_red
for eps5 in (-1, 1):                                                         # phi = eta^4 on the de Sitter base (H = 1) solves box phi = 4 phi (section 10)
    r44 = kk_ds(Fr(1), 4, eps5)['ric'][(4, 4)]; ok_44 &= r44 == {(0,) * 5: Fr(-4 * eps5)}      # = -eps kappa^2 eta_44 with eps kappa^2 = 4
dsc = exact_setup([mono(5, (-1, 0, 0, 0, 0), -1 / H1)] * 4 + [mono(5, (0, 0, 0, 0, 0), 1)], 5, [1, -1, -1, -1, -1])
ric_c = dsc['ric']; blockc = all(ric_c[(i, j)] == ({(0,) * 5: Fr(-3 * H1 * H1 * dsc['sq'][i])} if i == j else {}) for i in range(4) for j in range(4)); r44c = ric_c[(4, 4)]
chk('bit', ok_44 and blockc and r44c == {}, 'se.RADIUS: with the lowest order Ric5 = eps kappa^2 (paper\'s signs; Ric5 = -eps kappa^2 eta in the Atlas\'s, eps = +1 for D_+ D_-, -1 for c(D_+^2), 0 for D_s^2) the 44 component is box phi = eps kappa^2 phi for both squares of the fibre generator, i.e. -nabla-bar^2 e^sigma = eps kappa^2 e^sigma: the paper\'s (4.3) with its constant (LNS-017e\'s box phi = 4 c phi with 4c = eps kappa^2); constant sigma over de Sitter (Laurent, H = 1): the 4D block is R_ab = -3 H^2 eta_ab, the four-dimensional equation with Lambda = 3 H^2, but Ric5_44 = 0, so the 44 component reads 0 = eps kappa^2: constant sigma solves the lowest order only for D_s^2')
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (10) de Sitter base: the homogeneous radius
head('(10) [se.DS5] the radius on a de Sitter base: phi = (-eta)^p, conformal time, Laurent exact; the ODE by scipy')
d4ds = {}
def box4_phi(H, p):
    """[bit] box phi on the four-dimensional de Sitter base for phi = (-eta)^p, as a Laurent polynomial"""
    if H not in d4ds: d4ds[H] = exact_setup([mono(4, (-1, 0, 0, 0), -1 / Fr(H))] * 4, 4, [1, -1, -1, -1])
    sg = Fr(-1) ** (p % 2); return box_exact(d4ds[H], {0: {(p, 0, 0, 0): sg}}).get(0, {}), {(p, 0, 0, 0): sg}
CASES = [(Fr(1), Fr(4)), (Fr(1), Fr(10)), (Fr(1), Fr(-2)), (Fr(1, 2), Fr(1))]          # (H, eps kappa^2): p^2 - 3p - eps kappa^2/H^2 = 0 with integer roots
ok_roots = True; ok_einstein = True; lines = []; ok_paper = True
for H, ek2 in CASES:
    disc = 9 + 4 * ek2 / H ** 2; sd = Fr(math.isqrt(disc.numerator), math.isqrt(disc.denominator)); assert sd * sd == disc
    roots = [int((3 + sd) / 2), int((3 - sd) / 2)]
    if fault('NOFRICTION'):                                                   # the paper's (4.4): e^{+-sqrt(eps) kappa t} = (-H eta)^{-+sqrt(eps kappa^2)/H}
        roots = [r for r in (2, -2)] if ek2 / H ** 2 == 4 else roots
    for p in roots:
        b, ph = box4_phi(H, p); ok_roots &= b == scale(ph, ek2)
        r5 = kk_ds(H, p)['ric']; e44 = r5[(4, 4)] == {(0,) * 5: ek2}
        ein = all(r5[(i, j)] == ({(0,) * 5: -ek2 * [1, -1, -1, -1, -1][i]} if i == j else {}) for i in range(5) for j in range(5))
        lines.append((H, ek2, p, e44, ein)); ok_roots &= e44
    if ek2 / H ** 2 == 4 and not fault('NOFRICTION'):
        for p in (2, -2):
            b, ph = box4_phi(H, p); ok_paper &= b != scale(ph, ek2)
ok_einstein = [(H, ek2, p) for H, ek2, p, e44, ein in lines if ein] == [(Fr(1), Fr(4), -1), (Fr(1, 2), Fr(1), -1)]
print('    ' + '; '.join('H = %s, eps kappa^2 = %s: p = %s %s' % (H, ek2, p, 'Einstein (Ric5 = -eps kappa^2 eta)' if ein else ('44 component only' if e44 else 'fails')) for H, ek2, p, e44, ein in lines))
chk('bit', ok_roots, 'se.DS5: on de Sitter e^a = -dx^a/(H eta), phi = (-eta)^p solves (4.3), box phi = eps kappa^2 phi, exactly in the chart iff p^2 - 3p - eps kappa^2/H^2 = 0, at (H, eps kappa^2) = (1, 4), (1, 10), (1, -2), (1/2, 1) with both roots, and then Ric5_44 = eps kappa^2: in cosmic time (-H eta = e^{-H t}) phi = e^{r t} with r^2 + 3 H r = eps kappa^2, the base\'s friction 3 H r included')
chk('bit', ok_paper, 'se.DS5: a negative result against the printed (4.4), kept: on the base with H = 1, eps kappa^2 = 4 the paper\'s e^{+-sqrt(eps) kappa t} = (-eta)^{-+2} does not solve (4.3) (box phi != eps kappa^2 phi), and the homogeneous solutions are e^{t} and e^{-4 t}; (4.4) is the case H = 0 (no friction), approached when H << kappa')
chk('bit', ok_einstein and not fault('NOFRICTION'), 'se.DS5: the five-dimensional equation Ric5 = -eps kappa^2 eta (all 25 components) holds on a de Sitter base only for phi ~ e^{H t} (p = -1) with eps kappa^2 = 4 H^2 (H = 1 and 1/2): five-dimensional de Sitter in flat slicing, eps = +1 (D_+ D_-); there the four-dimensional constant is 3 H^2 = (3/4) kappa^2; the other root, and both roots at eps kappa^2 = 10 and -2, satisfy the 44 component only')
# scipy: the ODE f'' + 3 H f' - eps kappa^2 f = 0 in cosmic time
devo = 0.0; devp = 0.0
for H, ek2 in ((1.0, 4.0), (1.0, 10.0), (1.0, -2.0), (1.0 / 3 ** 0.5, 1.0)):
    fr = 0.0 if fault('NOFRICTION') else 3 * H
    sol = solve_ivp(lambda t, y: [y[1], ek2 * y[0] - fr * y[1]], (0, 2), [1.0, 0.3], rtol=1e-12, atol=1e-14, dense_output=True)
    dsc_ = 9 * H * H + 4 * ek2; rp_, rm_ = (-3 * H + math.sqrt(dsc_)) / 2, (-3 * H - math.sqrt(dsc_)) / 2
    am = (0.3 - rp_) / (rm_ - rp_); ap = 1 - am
    for t in (0.5, 1.0, 2.0):
        devo = max(devo, abs(sol.sol(t)[0] - (ap * math.exp(rp_ * t) + am * math.exp(rm_ * t))) / abs(sol.sol(t)[0]))
        if ek2 > 0:
            k = math.sqrt(ek2); pap = 0.5 * (1 + 0.3 / k) * math.exp(k * t) + 0.5 * (1 - 0.3 / k) * math.exp(-k * t)
            devp = max(devp, abs(pap - sol.sol(t)[0]) / abs(sol.sol(t)[0]))
chk('std', devo < 1e-9 and devp > 0.1, 'se.DS5: scipy solve_ivp (rtol 1e-12) on f\'\' + 3 H f\' = eps kappa^2 f, f(0) = 1, f\'(0) = 0.3, four (H, eps kappa^2) including H = 1/sqrt 3 (the base with 3 H^2 = kappa^2): the closed form a_+ e^{r_+ t} + a_- e^{r_- t} agrees to %.1e; the paper\'s (4.4) with the same data differs by up to %.0f%% at t = 0.5 ... 2' % (devo, 100 * devp))
print('    on the base with 3 H^2 = kappa^2 (eps = 1) the growth rate is r_+ = kappa (sqrt 7 - sqrt 3)/2 = %.4f kappa; on the five-dimensional de Sitter solution r = H = kappa/2' % ((math.sqrt(7) - math.sqrt(3)) / 2))
print('    (%.1f s)' % (time.time() - T0), flush=True)

# ================================================================================================ (11) the time scale, as a number
head('(11) [se.TIME] the time scale hbar/kc of (4.4), as a number')
c_cm = 2.99792458e10; yr = 365.25 * 86400; k_over_hbar = 1e-28
T = 1 / (c_cm * k_over_hbar); paper = 1e11 / (3 * math.pi)
chk('std', abs(T / yr / paper - 1) < 0.01, 'se.TIME: hbar/kc = 1/(c x 1e-28 cm^-1) = %.4e s = %.4e years (Julian year, c = 2.99792458e10 cm/s); the paper\'s (3 pi)^-1 x 10^11 years = %.4e years (c = 3e10 cm/s and pi x 10^7 s per year), ratio %.4f; the e-folding times of the solutions of (10) at these constants: 2 hbar/kc = %.2e years for r = kappa/2, hbar/(%.4f kc) = %.2e years for r_+ on the base with 3 H^2 = kappa^2 (numbers only; the coincidence with the age of the universe is the paper\'s remark)' % (T, T / yr, paper, T / yr / paper, 2 * T / yr, (math.sqrt(7) - math.sqrt(3)) / 2, T / yr / ((math.sqrt(7) - math.sqrt(3)) / 2)))
print('  (total %.1f s)' % (time.time() - T0), flush=True)
finish('SHIFTED-EINSTEIN')
