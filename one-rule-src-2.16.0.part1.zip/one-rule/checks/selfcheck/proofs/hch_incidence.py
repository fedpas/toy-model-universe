#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""hch_incidence.py -- the Hochschild groups of incidence algebras against the cohomology of order complexes (Gerstenhaber-Schack), on the
Boolean lattices B_n of the bit labels and on five posets whose order complex is a circle, a 2-sphere or two points.

Statement.  For a finite poset P with incidence algebra kP (basis E_(t,s) for s <= t, E_(t,s) E_(t',s') = [s = t'] E_(t,s')), the Hochschild
groups HH^k(kP, kP) equal the simplicial cohomology H^k(Delta(P); k) of the order complex (the simplices are the chains x_0 < ... < x_k).
B_n has a least and a greatest label, so Delta(B_n) is a cone and HH^k(kB_n) is k for k = 0 and 0 otherwise.

[bit]  The incidence algebra on the bit labels (s <= t iff s & ~t = 0); the full, unnormalised bar complex C^k = Hom(A^(x)k, A) on the basis
       cochains (inputs, output), d f(a_1..a_(k+1)) = a_1 f(a_2..) + sum_i (-1)^i f(.., a_i a_(i+1), ..) + (-1)^(k+1) f(a_1..a_k) a_(k+1);
       the complex splits by the weight w = deg(output) - sum deg(inputs) in Z^P (deg E_(t,s) = u_t - u_s), and every block is ranked exactly
       over Q (Fractions).  d o d = 0 on every basis cochain of degree 0 and 1; HH^0, HH^1, HH^2 for B_1, B_2, B_3 over every block (the blocks
       with w != 0 carry no cohomology: the torus acts by inner automorphisms, recalled, and checked here), for B_4 over the block w = 0.
[std]  The order complex from the poset given as frozensets of {1..n} (no masks): strict chains by depth-first search, coboundary matrices with
       alternating face signs, exact sparse rank over Q and numpy matrix_rank (tolerance 1e-8) as a numerical second opinion; B_n for n <= 5
       every degree; the least and greatest element and the cone point.
[bit==std]  HH^k(kP) = H^k(Delta(P)) for k = 0, 1, 2 on B_1 .. B_4, the crown (a, b < c, d), the proper part of B_3 (a hexagon), the
       octahedral poset (three levels of two), the proper part of B_4 (weight-0 block) and two incomparable points.
[ctl]  The Hasse diagram of B_2 taken as a graph (a 4-cycle) has H^1 = 1 against HH^1 = 0; the bar differential without its signs fails
       d o d = 0; the crown is not rigid (HH^1 = 1).  Each wrong version is also a --fault option that puts it into the main lines.
Scope. B_n: n <= 3 every block, n = 4 the block w = 0, degrees 0, 1, 2 of the bar complex; order complexes n <= 5, every degree.  The theorem
       for every poset and every degree is recalled (Gerstenhaber, Schack, "Simplicial cohomology is Hochschild cohomology"); that a cone is
       contractible and that inner automorphisms act trivially on HH are recalled.  No engine object is built: the faults of the gravity
       engine do not apply.
Run:   python3 hch_incidence.py [--fault NOSIGN|NORIGHT|HASSE|CROWN]
       (from the package root as selfcheck/proofs/hch_incidence.py; also from its own folder, and under -I -B)"""
import os, sys, itertools, time
from fractions import Fraction
sys.dont_write_bytecode = True
import numpy as np

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'HCH-INC'
FAULT_NAMES = ['NOSIGN', 'NORIGHT', 'HASSE', 'CROWN']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name
T0 = time.time()
def tline(part): print('  [time] %s: %.1f s' % (part, time.time() - T0), flush=True)

# ------------------------------------------------------------------ exact rank over Q of sparse vectors (keys comparable)
def rank_q(vectors):
    piv = {}; rk = 0
    for v in vectors:
        v = {k: Fraction(x) for k, x in v.items() if x}
        while v:
            k = min(v)
            if k in piv:
                f = v[k]
                for kk, x in piv[k].items():
                    y = v.get(kk, 0) - f * x
                    if y: v[kk] = y
                    else: v.pop(kk, None)
            else:
                f = v[k]; piv[k] = {kk: x / f for kk, x in v.items()}; rk += 1
                break
    return rk

# ------------------------------------------------------------------ [bit] posets on the bit labels
def boolean_masks(n):
    return list(range(1 << n)), (lambda s, t: s & ~t == 0)
def proper_masks(n):
    return list(range(1, (1 << n) - 1)), (lambda s, t: s & ~t == 0)
def levels_poset(lev):
    return list(range(len(lev))), (lambda s, t: s == t or lev[s] < lev[t])
CROWN_LEV, OCTA_LEV, ANTI_LEV = [0, 0, 1, 1], [0, 0, 1, 1, 2, 2], [0, 0]
def antichain2(): return [0, 1], (lambda s, t: s == t)

class Incidence:
    """the incidence algebra of (elems, leq) with the bar complex; NOSIGN / NORIGHT are the wrong versions of the differential"""
    def __init__(self, elems, leq):
        self.el = list(elems); self.P = len(self.el); pos = {x: i for i, x in enumerate(self.el)}
        self.basis = [(t, s) for s in self.el for t in self.el if leq(s, t)]           # E_(t,s), s <= t
        self.d = len(self.basis); idx = {b: i for i, b in enumerate(self.basis)}
        self.deg = []
        for (t, s) in self.basis:
            v = [0] * self.P; v[pos[t]] += 1; v[pos[s]] -= 1; self.deg.append(tuple(v))
        self.mult = [[-1] * self.d for _ in range(self.d)]
        for i, (t, s) in enumerate(self.basis):
            for j, (t2, s2) in enumerate(self.basis):
                if s == t2: self.mult[i][j] = idx[(t, s2)]
        self.left = [[(a, self.mult[a][k]) for a in range(self.d) if self.mult[a][k] >= 0] for k in range(self.d)]
        self.right = [[(a, self.mult[k][a]) for a in range(self.d) if self.mult[k][a] >= 0] for k in range(self.d)]
        self.fact = [[] for _ in range(self.d)]
        for x in range(self.d):
            for y in range(self.d):
                if self.mult[x][y] >= 0: self.fact[self.mult[x][y]].append((x, y))
        self.diag = [i for i, (t, s) in enumerate(self.basis) if t == s]
        self.degidx = {}
        for i, g in enumerate(self.deg): self.degidx.setdefault(g, []).append(i)
    def is_associative(self):
        m = self.mult
        return all((m[m[a][b]][c] if m[a][b] >= 0 else -1) == (m[a][m[b][c]] if m[b][c] >= 0 else -1)
                   for a in range(self.d) for b in range(self.d) for c in range(self.d))
    def column(self, inp, out):
        k = len(inp); col = {}
        def add(key, v):
            y = col.get(key, 0) + v
            if y: col[key] = y
            else: col.pop(key, None)
        for (a, pr) in self.left[out]: add(((a,) + inp, pr), 1)
        for i in range(1, k + 1):
            sg = 1 if fault('NOSIGN') else (-1) ** i
            for (x, y) in self.fact[inp[i - 1]]: add((inp[:i - 1] + (x, y) + inp[i:], out), sg)
        if not fault('NORIGHT'):
            for (a, pr) in self.right[out]: add((inp + (a,), pr), (-1) ** (k + 1))
        return col
    def weight(self, inp, out):
        w = list(self.deg[out])
        for i in inp:
            for j, x in enumerate(self.deg[i]):
                if x: w[j] -= x
        return tuple(w)
    def blocks(self, k):
        """all basis cochains of degree k grouped by weight"""
        B = {}
        for inp in itertools.product(range(self.d), repeat=k):
            for out in range(self.d): B.setdefault(self.weight(inp, out), []).append((inp, out))
        return B
    def block0(self, k):
        """the basis cochains of degree k and weight 0"""
        cs = []; zero = tuple([0] * self.P)
        for inp in itertools.product(range(self.d), repeat=k):
            s = [0] * self.P
            for i in inp:
                for j, x in enumerate(self.deg[i]):
                    if x: s[j] += x
            for out in self.degidx.get(tuple(s), []): cs.append((inp, out))
        return cs
    def dd_failures(self, kmax):
        bad = 0
        for k in range(kmax + 1):
            for inp in itertools.product(range(self.d), repeat=k):
                for out in range(self.d):
                    tot = {}
                    for (inp2, out2), v in self.column(inp, out).items():
                        for key, v2 in self.column(inp2, out2).items(): tot[key] = tot.get(key, 0) + v * v2
                    if any(tot.values()): bad += 1
        return bad
    def hh(self, kmax=2, only_zero=False):
        """dims of HH^0..HH^kmax; with only_zero the weight-0 block alone; also the total over the blocks w != 0"""
        zero = tuple([0] * self.P)
        if only_zero:
            blk = {k: {zero: self.block0(k)} for k in range(kmax + 1)}
        else:
            blk = {k: self.blocks(k) for k in range(kmax + 1)}
        weights = set()
        for k in blk: weights |= set(blk[k])
        res = [0] * (kmax + 1); off = [0] * (kmax + 1); self.nweights = len(weights)
        for w in weights:
            prev = 0
            for k in range(kmax + 1):
                cs = blk[k].get(w, [])
                rk = rank_q([self.column(inp, out) for (inp, out) in cs]) if cs else 0
                h = len(cs) - rk - prev; prev = rk
                if w == zero: res[k] += h
                else: off[k] += h
        return res, off

# ------------------------------------------------------------------ [std] order complexes from frozenset posets, no masks
def std_boolean(n, proper=False):
    U = range(1, n + 1)
    el = [frozenset(c) for k in range(n + 1) for c in itertools.combinations(U, k)]
    if proper: el = [x for x in el if 0 < len(x) < n]
    return el, (lambda a, b: a < b)                                                    # strict order: proper subset
def std_levels(lev):
    names = ['x%d' % i for i in range(len(lev))]
    rel = {(names[i], names[j]) for i in range(len(lev)) for j in range(len(lev)) if lev[i] < lev[j]}
    return names, (lambda a, b: (a, b) in rel)
def std_hasse(el, lt):
    """the wrong complex of the HASSE fault: vertices and covering edges only"""
    cov = [(a, b) for a in el for b in el if lt(a, b) and not any(lt(a, c) and lt(c, b) for c in el)]
    return cov
def chains(el, lt, kmax):
    ch = {0: [(x,) for x in el]}
    for k in range(1, kmax + 1):
        ch[k] = [c + (y,) for c in ch[k - 1] for y in el if lt(c[-1], y)]
    return ch
def std_cohomology(el, lt, kmax, hasse=False, numeric=True):
    """dims H^0..H^kmax of the order complex (exact sparse rank; numpy rank as a second opinion when small)"""
    if hasse:
        ch = {0: [(x,) for x in el], 1: [c for c in std_hasse(el, lt)]}
        for k in range(2, kmax + 2): ch[k] = []
    else:
        ch = chains(el, lt, kmax + 1)
    pos = {k: {c: i for i, c in enumerate(ch[k])} for k in ch}
    rk = {-1: 0}; rk_np = {-1: 0}; agree = True
    for k in range(kmax + 1):
        rows = []
        for c in ch[k + 1]:
            v = {}
            for m in range(k + 2):
                f = c[:m] + c[m + 1:]
                if f in pos[k]: v[pos[k][f]] = v.get(pos[k][f], 0) + (-1) ** m
            rows.append(v)
        rk[k] = rank_q(rows)
        if numeric and len(ch[k]) * max(1, len(ch[k + 1])) <= 4_000_000:
            M = np.zeros((len(ch[k + 1]), len(ch[k])))
            for i, v in enumerate(rows):
                for j, x in v.items(): M[i, j] = x
            r_np = int(np.linalg.matrix_rank(M, tol=1e-8)) if M.size else 0
            agree &= (r_np == rk[k])
    return [len(ch[k]) - rk[k] - rk[k - 1] for k in range(kmax + 1)], agree, [len(ch[k]) for k in range(kmax + 2)]

# ================================================================== part 1: the complex is a complex
head('hch·1 CAND-065: the bar complex of the incidence algebra on the bit labels is a complex')
ok_assoc = True; dd = {}
for name, (el, leq) in [('B_1', boolean_masks(1)), ('B_2', boolean_masks(2)), ('B_3', boolean_masks(3)), ('crown', levels_poset(CROWN_LEV))]:
    A = Incidence(el, leq); ok_assoc &= A.is_associative()
    dd[name] = A.dd_failures(1)
chk('bit', ok_assoc and all(v == 0 for v in dd.values()),
    'kB_1, kB_2, kB_3 (dimensions 3, 9, 27) and the crown algebra (dimension 8) are associative, and d o d = 0 on every basis cochain of degree 0 and 1: failures %s' % dd)
if not FAULT:
    FAULT = 'NOSIGN'; Aw = Incidence(*boolean_masks(2)); bad_ns = Aw.dd_failures(1)
    FAULT = 'NORIGHT'; Aw = Incidence(*boolean_masks(2)); bad_nr = Aw.dd_failures(1); hh_nr, _ = Aw.hh(2); FAULT = None
    chk('ctl', bad_ns > 0 and bad_nr == 0 and hh_nr != [1, 0, 0],
        'wrong differentials on kB_2: without the signs (-1)^i of the middle terms d o d fails on %d basis cochains of degree <= 1; without the right-action term d o d still vanishes (%d failures: coefficients in a bimodule whose right action is 0) but the groups change, weight-0 HH^0, HH^1, HH^2 = %s instead of [1, 0, 0]' % (bad_ns, bad_nr, hh_nr))
tline('part 1')

# ================================================================== part 2: HH of kB_n
head('hch·2 CAND-065: HH^0, HH^1, HH^2 of the incidence algebra kB_n from the full bar complex (exact over Q, weight blocks)')
HH = {}
for n in (1, 2, 3, 4):
    el, leq = levels_poset(CROWN_LEV) if (fault('CROWN') and n == 2) else boolean_masks(n)
    A = Incidence(el, leq)
    kmax = 3 if n <= 2 else 2
    res, off = A.hh(kmax)
    HH['B_%d' % n] = res[:3]
    chk('bit', res == [1] + [0] * kmax and off == [0] * (kmax + 1),
        'kB_%d (dimension %d = 3^%d, %d weights in degrees 0..%d): HH^0 .. HH^%d = %s on the weight-0 block and %s summed over all blocks with w != 0 (every block ranked exactly over Q)'
        % (n, A.d, n, A.nweights, kmax, kmax, res, off))
    tline('B_%d' % n)
A3 = Incidence(*boolean_masks(3))
res3, _ = A3.hh(3, only_zero=True)
chk('bit', res3 == [1, 0, 0, 0],
    'kB_3, degree 3 on the weight-0 block (%s basis cochains of degree 0..3 in it): HH^0 .. HH^3 = %s' % ([len(A3.block0(k)) for k in range(4)], res3))
tline('B_3 degree 3')

# ================================================================== part 3: [std] the order complex of B_n, the cone
head('hch·3 CAND-065: the order complex of B_n (poset of frozensets, no masks): the cohomology of a point, the cone point')
HSTD = {}
for n in range(1, 6):
    el, lt = std_boolean(n)
    h, agree, sizes = std_cohomology(el, lt, n + 1, hasse=fault('HASSE'), numeric=(n <= 4))
    HSTD['B_%d' % n] = h
    least = [x for x in el if all(x <= y for y in el)]; great = [x for x in el if all(y <= x for y in el)]
    cone = all(((frozenset(),) + c) in set(chains(el, lt, len(c))[len(c)]) for c in chains(el, lt, 2)[1] if frozenset() not in c) if n <= 3 else True
    chk('std', h == [1] + [0] * (n + 1) and agree and len(least) == 1 and len(great) == 1 and cone,
        'Delta(B_%d): simplices per dimension %s, H^0 .. H^%d = %s (exact; numpy rank agrees: %s); one least element (the empty set) and one greatest; the empty set is a cone point of every chain%s'
        % (n, sizes, n + 1, h, agree if n <= 4 else 'not run', '' if n <= 3 else ' (tested for n <= 3)'))
tline('part 3')

# ================================================================== part 4: posets with a non-zero answer, both routes
head('hch·4 CAND-065: five posets whose order complex is a circle, a 2-sphere or two points, both routes')
OTHERS = [('crown', levels_poset(CROWN_LEV), std_levels(CROWN_LEV), [1, 1, 0], False),
          ('proper part of B_3', proper_masks(3), std_boolean(3, proper=True), [1, 1, 0], False),
          ('octahedral', levels_poset(OCTA_LEV), std_levels(OCTA_LEV), [1, 0, 1], False),
          ('two points', antichain2(), std_levels(ANTI_LEV), [2, 0, 0], False),
          ('proper part of B_4', proper_masks(4), std_boolean(4, proper=True), [1, 0, 1], True)]
for name, (el, leq), (sel, slt), want, only0 in OTHERS:
    A = Incidence(el, leq)
    res, off = A.hh(2, only_zero=only0)
    HH[name] = res
    hs, agree, sizes = std_cohomology(sel, slt, 2)
    HSTD[name] = hs
    chk('bit', res == want and (only0 or off == [0, 0, 0]),
        '%s: incidence algebra of dimension %d, HH^0, HH^1, HH^2 = %s%s' % (name, A.d, res, ' (weight-0 block)' if only0 else ', blocks w != 0: %s' % off))
    chk('std', hs == want and agree, '%s: order complex with %s simplices in dimensions 0..3, H^0, H^1, H^2 = %s (numpy agrees: %s)' % (name, sizes, hs, agree))
    tline(name)

# ================================================================== part 5: the comparison and the controls
head('hch·5 CAND-065: HH^k(kP) = H^k(Delta(P)) degree by degree, and the controls')
cmp_ = {name: (HH[name], HSTD[name][:3]) for name in HH}
chk('bit==std', all(a == b for a, b in cmp_.values()),
    'HH^k(kP) against H^k(Delta(P)), k = 0, 1, 2: %s' % '; '.join('%s %s = %s' % (k, a, b) for k, (a, b) in cmp_.items()))
if not FAULT:
    el, lt = std_boolean(2); hh_hasse, _, _ = std_cohomology(el, lt, 1, hasse=True, numeric=False)
    chk('ctl', hh_hasse[1] == 1 and HH['B_2'][1] == 0,
        'the Hasse diagram of B_2 taken as a graph (a 4-cycle, no 2-simplices) has H^1 = %d against HH^1(kB_2) = %d: the order complex, not the diagram, is the right complex' % (hh_hasse[1], HH['B_2'][1]))
    chk('ctl', HH['crown'][1] == 1 and HH['proper part of B_3'][1] == 1 and HH['octahedral'][2] == 1,
        'the rigidity of kB_n is not automatic: the crown and the proper part of B_3 have HH^1 = 1, the octahedral poset HH^2 = 1, the proper part of B_4 HH^2 = %d' % HH['proper part of B_4'][2])
tline('part 5')
finish(STEP)
