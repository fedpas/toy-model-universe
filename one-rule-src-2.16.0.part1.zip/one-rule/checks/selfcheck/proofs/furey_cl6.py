#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""furey_cl6.py: Furey's construction on the labels: her complex Cl(6) on C (x) O, the ladder operators from pairs of the six units with a
central i, the minimal left ideal of her idempotent and its eight states, the su(3) + u(1) beside it, and the eight states among the sixteen
axes of FUR-003/FUR-006 (round 12, proofs pass 10a; docs/round12/PLAN.md).
     python3 furey_cl6.py [--fault IMINUS|WRONGPAIR|NOFACTOR|NOI|DAGSIGN|NONFANO]

The kernel is researchers_checks/bitrule_A.py (BR): e_a e_b = s(a,b) e_(a xor b), generator i = bit i; a cell (p,q,r) has its p generators
of square +1 first, then q of square -1 (core_check.sig); the type table core_check.TYPE.  The complex scalar is a blade of the cell (the
volume element of Cl(1,6)), never a Python complex number; numpy only on the standard route.  The octonions enter as data: the Roadmap table
of furey_papers_check.py (Furey's labelling, e_a e_(a+1) = e_(a+3); copied) and the Cayley-Dickson model of reports/furey/model.py (index
1 = i, 2 = j, 3 = k, 4 = l, 5 = li, 6 = lj, 7 = lk; "k = e7, j = e6, i = e2, l = e5 in Furey's labelling", and by products e1 = -lj,
e3 = -li, e4 = -lk).  The pairs (j, k) = (5,4), (3,1), (6,2) are read off furey_papers_check.py R1 (its first three pairs, on the Gamma's);
on the six L_e they are the three pairs of arXiv:1603.04078, recalled.
fc.CPX C (x) Cl(0,6) on the labels: Cl(7,0) and Cl(1,6) are M8(C) with the central volume element i (square -1); the copy of Cl(0,6) is
       the even part of Cl(7,0) (products e_i e7) and the six generators of square -1 of Cl(1,6) (the cell chosen for the rows); i against
       Furey's omega = e1..e6 = L_e7 (what each commutes with), omega i = -e0, the splitting idempotents (1 -+ i omega)/2 = (1 +- e0)/2;
       Furey's dagger and complex conjugation on the labels.  [std] complex 8 x 8 matrices on C (x) O.  [ctl] the literal products e_i e0
       of Cl(1,6) give Cl(6,0) = M4(H).
fc.CAR alpha_a = (-e_j + i e_k)/2, alpha_a^dagger = (e_j + i e_k)/2: the CAR exactly; nu = alpha1 alpha2 alpha3 alpha3^d alpha2^d alpha1^d,
       an idempotent of complex rank 1 (real rank 2), its minimal left ideal; omega nu = -i nu.  [ctl] IMINUS, WRONGPAIR, NOFACTOR, NOI,
       DAGSIGN (the brief's alpha^dagger = (-e_j - i e_k)/2).
fc.FOCK the eight states nu, alpha_a^d nu, alpha_a^d alpha_b^d nu, alpha1^d alpha2^d alpha3^d nu: a complex basis of the ideal; N = sum
       alpha^d alpha with 0, 1, 2, 3 and Q = N/3 (Furey's charges 0, 1/3, 2/3, 1, her reading recalled); the conjugate ideal with 3 - n.
fc.SU3 Lambda_k = sum (lambda_k)_ab alpha_a^d alpha_b: the Gell-Mann structure constants exactly (lambda8' = sqrt3 lambda8 = diag(1,1,-2)),
       [Lambda, N] = 0, 1 + 3 + 3bar + 1 on the ideal; the real forms are bivectors and coincide with the derivations of O fixing e7 (fb.COL,
       FUR-012); N - 3/2 = -(i/2) K generates the u(1).  [ctl] NONFANO (a disjoint pairing off the lines through e7).
fc.AX  the eight states among the sixteen axes: Cl(1,6) inside the Cl(0,8) of furey_bit_route.py (e_j -> +-g_u, e0 -> +-the volume
       element, i -> +-g_k g8); the mode operators are the line blades of the three Fano lines through e7; the eight idempotents are the
       pairs of axes exchanged by g_k g8; the splitting is O against O'; Cl(0,8) nu holds the second ideal; the 4 = 3 + 1 of FUR-012.
Controls ([ctl]) and --fault options, each putting a wrong version in the main lines (which must then FAIL; exit 1):
   IMINUS the pairs with -i; WRONGPAIR the overlapping pairs (5,4), (3,4), (6,2); NOFACTOR nu without alpha1^dagger; NOI the pairs without
   the central i; DAGSIGN the adjoint with the other sign; NONFANO the disjoint pairs (2,1), (4,3), (6,5).
Not computed here (stated, not checked): the second generation, the Lorentz side C (x) H, Furey's symmetry breaking and hypercharge, the
roadmap's five modes on C (x) H (x) O (R1-R5 stand), any statement that the charges or the names of the states are nature's.
Command: python3 -I -B selfcheck/proofs/furey_cl6.py from checks/ (or from this folder); standard library and numpy."""
import os, sys, time, random, itertools, importlib.util
from fractions import Fraction as Fr
from math import isqrt
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                       # selfcheck/
_checks = os.path.dirname(_selfcheck)                                     # checks/
_researchers = os.path.join(_checks, 'researchers_checks')
for _d, _f in ((_researchers, 'bitrule_A.py'), (_selfcheck, 'core_check.py'), (os.path.join(_checks, 'reports', 'furey'), 'model.py')):
    if not os.path.isfile(os.path.join(_d, _f)): raise SystemExit(_f + ' not found: this file belongs in selfcheck/proofs/ of the checks folder')
for _d in (_researchers, _selfcheck):
    if _d not in sys.path: sys.path.insert(0, _d)
from bitrule_A import BR
from core_check import TYPE, sig as _core_sig                              # the type table by c = p - q mod 8, and the cell's eps
_spec = importlib.util.spec_from_file_location('furey_model', os.path.join(_checks, 'reports', 'furey', 'model.py'))
OM = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(OM)  # the octonion model, data only (as furey_bit_route.py)

# ------------------------------------------------------------------------------------------------ check lines (from fibre_base.py)
FAILS = []; COUNT = {}; T0 = time.time()
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[tag] = COUNT.get(tag, 0) + 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def note(s): print('       ' + s, flush=True)                                 # a printed value, not a check
def finish():
    print('\n  tags: %s; %.0f s' % (', '.join('%s %d' % (k, COUNT[k]) for k in sorted(COUNT)), time.time() - T0))
    print('furey_cl6: %d checks, %d fail' % (sum(COUNT.values()), len(FAILS)), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('IMINUS', 'WRONGPAIR', 'NOFACTOR', 'NOI', 'DAGSIGN', 'NONFANO')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
RNG = random.Random(20261017); NPR = np.random.default_rng(20261017)

def sig(p, q, r=0): return tuple(_core_sig(p, q, r))
pc = lambda x: bin(x).count('1')

# ------------------------------------------------------------------------------------------------ the kernel's formula and the label types
# copied from chain_blocks.py through fibre_base.py (popv, emask, s_vec, table, type_from_inv, tstr, table_type, ltype_eps, clock_type,
# ungraded_table; no __main__ guard in either)
def popv(x): return np.bitwise_count(x).astype(np.int64)
def emask(eps):
    E = np.ones(1, dtype=np.int64)
    for e in eps: E = np.concatenate([E, E * int(e)])
    return E
_EM = {}
def s_vec(eps, A, B):
    """BR.s(a, b) for arrays of labels: (-1)^(#(i in a, j in b, j < i)) * prod_(i in a & b) eps_i"""
    eps = tuple(eps)
    if eps not in _EM: _EM[eps] = emask(eps)
    A = np.asarray(A, dtype=np.int64); B = np.asarray(B, dtype=np.int64)
    par = np.zeros(np.broadcast(A, B).shape, dtype=np.int64)
    for i in range(len(eps)): par += ((A >> i) & 1) * popv(B & ((1 << i) - 1))
    return (1 - 2 * (par & 1)) * _EM[eps][A & B]
def table(eps):
    a = np.arange(1 << len(eps), dtype=np.int64); return s_vec(eps, a[:, None], a[None, :]).astype(np.int8)
DD = {'R': 1, 'C': 2, 'H': 4}
def type_from_inv(dim, c, cplx, fs):
    """c copies of M_m(D) from the dimension, the number c of simple summands, a complex centre, and the count fs (c m, 0, -2 c m)"""
    if c < 1: return None
    D = 'C' if cplx else ('R' if fs > 0 else 'H')
    q, r = divmod(dim, c * DD[D]); m = isqrt(q) if r == 0 else 0
    if m < 1 or m * m != q: return None
    return (D, m, c) if {'R': c * m, 'C': 0, 'H': -2 * c * m}[D] == fs else None
def tstr(t):
    if t is None: return 'none'
    D, m, c = t; base = D if m == 1 else 'M%d(%s)' % (m, D)
    return base if c == 1 else ' + '.join([base] * c)
def table_type(S, gens):
    """the type of the algebra with the sign table S (every e_a^2 = +-1) and generator labels gens: centre, its squares, the count"""
    central = np.ones(S.shape[0], dtype=bool)
    for g in gens: central &= (S[:, g] == S[g, :])
    Z = np.nonzero(central)[0]; sq = S[Z, Z]
    cplx = bool(np.any(sq == -1)); c = len(Z) // 2 if cplx else len(Z)
    return type_from_inv(S.shape[0], c, cplx, int(np.trace(S.astype(np.int64))))
def ltype_eps(eps):
    """the type of a non-degenerate cell from its labels: the count by the kernel formula, the central blades by the reordering counts"""
    n = len(eps); a = np.arange(1 << n, dtype=np.int64); d = s_vec(eps, a, a); cen = np.ones(1 << n, dtype=bool)
    for i in range(n): cen &= ((popv(a >> (i + 1)) - popv(a & ((1 << i) - 1))) & 1) == 0
    Z = np.flatnonzero(cen); cplx = bool(np.any(d[Z] == -1))
    return type_from_inv(1 << n, len(Z) // 2 if cplx else len(Z), cplx, int(d.sum()))
def clock_type(p, q):
    t = TYPE[(p - q) % 8]; D = t[0]; c = 2 if t.endswith('2') else 1
    m2, r = divmod(1 << (p + q), c * DD[D]); m = isqrt(m2); assert r == 0 and m * m == m2
    return (D, m, c)
def ungraded_table(e1, e2):
    """the ungraded product of two cells on the concatenated label a = a1 + 2^n1 a2: s1(a1,b1) s2(a2,b2), no cross sign"""
    return np.kron(table(e2).astype(np.int8), table(e1).astype(np.int8))

# copied from chiral_spinors.py through fibre_base.py (nullspace_frac: an exact rational null space; rank_frac)
def nullspace_frac(rows, ncol):
    rows = [[Fr(x) for x in r] for r in rows]; piv = []; rk = 0
    for c in range(ncol):
        p_ = next((i for i in range(rk, len(rows)) if rows[i][c] != 0), None)
        if p_ is None: continue
        rows[rk], rows[p_] = rows[p_], rows[rk]; pv = rows[rk][c]; rows[rk] = [x / pv for x in rows[rk]]
        for i in range(len(rows)):
            if i != rk and rows[i][c] != 0:
                f = rows[i][c]; rows[i] = [a - f * b for a, b in zip(rows[i], rows[rk])]
        piv.append(c); rk += 1
    free = [c for c in range(ncol) if c not in piv]; basis = []
    for f in free:
        v = [Fr(0)] * ncol; v[f] = Fr(1)
        for i, c in enumerate(piv): v[c] = -rows[i][f]
        basis.append(v)
    return basis
def rank_frac(M):
    """exact rank of an integer or Fraction matrix (a list of rows or a numpy array)"""
    rows = [[Fr(x) for x in r] for r in (M.tolist() if hasattr(M, 'tolist') else M)]
    return len(rows[0]) - len(nullspace_frac(rows, len(rows[0]))) if rows else 0
def inv_frac(A):
    """the exact inverse of a square Fraction matrix, or None"""
    n = len(A); M = [[Fr(x) for x in row] + [Fr(int(i == j)) for j in range(n)] for i, row in enumerate(A)]
    for c in range(n):
        p_ = next((i for i in range(c, n) if M[i][c] != 0), None)
        if p_ is None: return None
        M[c], M[p_] = M[p_], M[c]; pv = M[c][c]; M[c] = [x / pv for x in M[c]]
        for i in range(n):
            if i != c and M[i][c] != 0:
                f = M[i][c]; M[i] = [a - f * b for a, b in zip(M[i], M[c])]
    return [row[n:] for row in M]

# ------------------------------------------------------------------------------------------------ multivectors on the labels (exact)
class Cell:
    """the labels of a cell: e_a e_b = s(a,b) e_(a xor b), s = BR.s read as the table of s_vec (checked against BR below); multivectors are
    dicts label -> Fraction"""
    def __init__(self, eps):
        self.eps = tuple(eps); self.n = len(eps); self.M = 1 << self.n; self.S = table(self.eps).tolist()
    def mul(self, x, y):
        S = self.S; out = {}
        for a, ca in x.items():
            Sa = S[a]
            for b, cb in y.items():
                k = a ^ b; v = out.get(k, 0) + Sa[b] * ca * cb
                if v: out[k] = v
                else: out.pop(k, None)
        return out
    def prod(self, *xs):
        out = {0: Fr(1)}
        for x in xs: out = self.mul(out, x)
        return out
    def comm(self, x, y): return add(self.mul(x, y), self.mul(y, x), -1)
    def anti(self, x, y): return add(self.mul(x, y), self.mul(y, x))
    def sq(self, a): return self.S[a][a]
    def commute(self, a, b): return self.S[a][b] == self.S[b][a]
def add(x, y, c=1):
    out = dict(x)
    for k, v in y.items():
        w = out.get(k, 0) + c * v
        if w: out[k] = w
        else: out.pop(k, None)
    return out
def scal(x, c): return {k: c * v for k, v in x.items() if c * v != 0}
def lin(*terms):
    out = {}
    for c, x in terms: out = add(out, x, c)
    return out
def eq(x, y): return add(x, y, -1) == {}
def blade(a, c=1): return {a: Fr(c)}
ONE = blade(0)
def rank_mv(vs):
    """the exact rank of a list of multivectors: the vectors fall into components that share labels (union-find); rank_frac on each"""
    parent = {}
    def find(x):
        while parent.setdefault(x, x) != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for v in vs:
        ks = list(v)
        for k in ks[1:]:
            ra, rb = find(ks[0]), find(k)
            if ra != rb: parent[ra] = rb
    groups = {}
    for v in vs:
        if v: groups.setdefault(find(next(iter(v))), []).append(v)
    tot = 0
    for g in groups.values():
        labs = sorted({k for v in g for k in v}); tot += rank_frac([[v.get(k, 0) for k in labs] for v in g])
    return tot
class Coords:
    """real coordinates of multivectors in the span of an independent list (exact): pivot labels with an invertible restriction, the
    solution checked on every label (None when the list is dependent or the multivector lies outside the span)"""
    def __init__(self, basis):
        self.B = basis; self.r = len(basis); self.ok = False
        labs = sorted({k for v in basis for k in v}); R = [[Fr(v.get(k, 0)) for k in labs] for v in basis]; piv = []; rk = 0
        for c in range(len(labs)):
            p_ = next((i for i in range(rk, self.r) if R[i][c] != 0), None)
            if p_ is None: continue
            R[rk], R[p_] = R[p_], R[rk]; pv = R[rk][c]; R[rk] = [x / pv for x in R[rk]]
            for i in range(self.r):
                if i != rk and R[i][c] != 0:
                    f = R[i][c]; R[i] = [a - f * b for a, b in zip(R[i], R[rk])]
            piv.append(labs[c]); rk += 1
            if rk == self.r: break
        if rk < self.r: return
        self.P = piv; self.Ainv = inv_frac([[Fr(v.get(k, 0)) for v in basis] for k in piv]); self.ok = self.Ainv is not None
    def __call__(self, y):
        if not self.ok: return None
        yP = [Fr(y.get(k, 0)) for k in self.P]
        c = [sum(self.Ainv[i][j] * yP[j] for j in range(self.r)) for i in range(self.r)]
        return c if eq(lin(*[(c[j], self.B[j]) for j in range(self.r) if c[j]]), y) else None

# copied from fibre_base.py (Lab, comm_labels, span_tau, Ideal: a minimal left ideal A f, f = prod (1 + e_g)/2 over commuting labels of square
# +1, with the left multiplications by labels as signed permutation matrices, as abs_ring.py and chiral_spinors.py build them)
class Lab:
    def __init__(self, s, N): self.s, self.N, self.M = s, N, 1 << N
    def sq(self, a): return self.s(a, a)
    def commute(self, a, b): return self.s(a, b) == self.s(b, a)
def comm_labels(L, first=(), even=False, tries=60):
    best = None
    for k in range(tries):
        order = list(range(1, L.M)); RNG.shuffle(order); G = list(first); span = {0}
        for g in G: span |= {x ^ g for x in span}
        for u in order:
            if u in span or L.sq(u) != 1 or (even and pc(u) % 2) or not all(L.commute(u, g) for g in G): continue
            G.append(u); span |= {x ^ u for x in span}
        if best is None or len(G) > len(best): best = G
    return best
def span_tau(L, G):
    tau = {0: 1}
    for g in G:
        for h, t in list(tau.items()): tau[h ^ g] = L.s(h, g) * t
    return tau
class Ideal:
    def __init__(self, L, G):
        self.L, self.G = L, list(G); self.tau = span_tau(L, G); H = list(self.tau)
        self.rep = {}; self.reps = []
        for a in range(L.M):
            if a not in self.rep:
                self.reps.append(a)
                for h in H: self.rep[a ^ h] = (a, h)
        self.m = len(self.reps); self.idx = {r: i for i, r in enumerate(self.reps)}
    def act(self, b):
        R = np.zeros((self.m, self.m), dtype=np.int64)
        for r in self.reps:
            r2, h = self.rep[b ^ r]; R[self.idx[r2], self.idx[r]] = self.L.s(b, r) * self.L.s(r2, h) * self.tau[h]
        return R
def mv_mat(I_, x):
    """the left action of a multivector on an Ideal, as a Fraction matrix (a list of rows)"""
    out = [[Fr(0)] * I_.m for _ in range(I_.m)]
    for a, c in x.items():
        R = I_.act(a)
        for i in range(I_.m):
            for j in range(I_.m):
                if R[i, j]: out[i][j] += c * int(R[i, j])
    return out

# ------------------------------------------------------------------------------------------------ the octonions, as data
# the Roadmap table in Furey's labelling, copied from furey_papers_check.py (trip, fo, omul, LO, RO; no __main__ guard there: it runs on import)
TRIP = [(1, 2, 4), (2, 3, 5), (3, 4, 6), (4, 5, 7), (5, 6, 1), (6, 7, 2), (7, 1, 3)]
FO = np.zeros((8, 8, 8), dtype=np.int64)
for (i_, j_, k_) in TRIP:
    for (a_, b_, c_) in [(i_, j_, k_), (j_, k_, i_), (k_, i_, j_)]:
        FO[a_, b_, c_] = 1; FO[b_, a_, c_] = -1
def omul_f(i_, j_):
    if i_ == 0: return 1, j_
    if j_ == 0: return 1, i_
    if i_ == j_: return -1, 0
    for k_ in range(1, 8):
        if FO[i_, j_, k_] != 0: return int(FO[i_, j_, k_]), k_
LO = np.zeros((8, 8, 8), dtype=np.int64); RO = np.zeros((8, 8, 8), dtype=np.int64)
for a_ in range(8):
    for j_ in range(8):
        s_, k_ = omul_f(a_, j_); LO[a_][k_, j_] = s_
        s_, k_ = omul_f(j_, a_); RO[a_][k_, j_] = s_
F2M = {1: (6, -1), 2: (1, 1), 3: (5, -1), 4: (7, -1), 5: (4, 1), 6: (2, 1), 7: (3, 1)}  # Furey's e_a = sign x the model's unit (index)
FUREY = [(5, 4), (3, 1), (6, 2)]                                                      # R1's first three pairs (j, k), on the six units

# ------------------------------------------------------------------------------------------------ Gaussian rationals (the Gell-Mann side)
def cmul(a, b): return (a[0] * b[0] - a[1] * b[1], a[0] * b[1] + a[1] * b[0])
def cadd(a, b): return (a[0] + b[0], a[1] + b[1])
CZ = (Fr(0), Fr(0))
def mm3(A, B):
    out = [[CZ] * 3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            for k in range(3): out[i][j] = cadd(out[i][j], cmul(A[i][k], B[k][j]))
    return out
def msub3(A, B): return [[(A[i][j][0] - B[i][j][0], A[i][j][1] - B[i][j][1]) for j in range(3)] for i in range(3)]
def tr3(A): return cadd(cadd(A[0][0], A[1][1]), A[2][2])
def cdiv(a, b):
    n = b[0] * b[0] + b[1] * b[1]; return ((a[0] * b[0] + a[1] * b[1]) / n, (a[1] * b[0] - a[0] * b[1]) / n)
def gm3(entries):
    """a 3 x 3 Gaussian-rational matrix from {(i, j): (re, im)}"""
    return [[(Fr(entries.get((i, j), (0, 0))[0]), Fr(entries.get((i, j), (0, 0))[1])) for j in range(3)] for i in range(3)]
GELL = [gm3({(0, 1): (1, 0), (1, 0): (1, 0)}), gm3({(0, 1): (0, -1), (1, 0): (0, 1)}), gm3({(0, 0): (1, 0), (1, 1): (-1, 0)}),
        gm3({(0, 2): (1, 0), (2, 0): (1, 0)}), gm3({(0, 2): (0, -1), (2, 0): (0, 1)}), gm3({(1, 2): (1, 0), (2, 1): (1, 0)}),
        gm3({(1, 2): (0, -1), (2, 1): (0, 1)}), gm3({(0, 0): (1, 0), (1, 1): (1, 0), (2, 2): (-2, 0)})]   # lambda1..7, lambda8' = sqrt3 lambda8

# ------------------------------------------------------------------------------------------------ the standard route's tools (no label)
# fwords, realify and mat_table copied from fibre_base.py (mat_table follows chain_blocks.py)
def fwords(G, dtype=np.float64):
    n = len(G); d = G[0].shape[0]; W = np.zeros((1 << n, d, d), dtype=dtype); W[0] = np.eye(d)
    for a in range(1, 1 << n):
        top = a.bit_length() - 1; W[a] = W[a ^ (1 << top)] @ G[top].astype(dtype)
    return W
def realify(Zc): return np.block([[Zc.real, -Zc.imag], [Zc.imag, Zc.real]])
def mat_table(W):
    """the sign table read from matrices whose generators obey the relations: W_a W_b = c W_(a xor b), c from the images of a vector"""
    M = W.shape[0]; ar = np.arange(M); V = W[:, :, 0]; nrm = (V * V).sum(1); C = np.zeros((M, M))
    for a in range(M): C[a] = ((W[a] @ V.T) * V[a ^ ar].T).sum(0) / nrm[a ^ ar]
    return np.rint(C).astype(np.int64), bool(np.allclose(C, np.rint(C)))
def frel_ok(G, eps):
    I = np.eye(G[0].shape[0])
    return all(np.allclose(G[i] @ G[j] + G[j] @ G[i], 2 * eps[i] * I if i == j else 0 * I) for i in range(len(G)) for j in range(i, len(G)))
def prodm(ms):
    P_ = np.eye(ms[0].shape[0], dtype=ms[0].dtype)
    for m_ in ms: P_ = P_ @ m_
    return P_

# ================================================================================================ fc.CPX  C (x) Cl(0,6) on the labels
head('fc.CPX  C (x) Cl(0,6) on the labels: the cells Cl(7,0) and Cl(1,6), the central i, and Furey\'s omega = L_e7 inside the copy of Cl(0,6)')
t = time.time()
E70, E16, E06 = sig(7, 0), sig(1, 6), sig(0, 6)
C70, C16, C06 = Cell(E70), Cell(E16), Cell(E06)
TOP, OMG = 127, 126                                                       # i = e0 e1 .. e6 (Cl(1,6)); omega = e1 .. e6, Furey's L_e7 (A3)
I_, W_ = blade(TOP), blade(OMG)
def centre(C): return [a for a in range(C.M) if all(C.commute(a, 1 << i) for i in range(C.n))]
okK = all(C.S[a][b] == K.s(a, b) for C, K in ((C70, BR(E70)), (C16, BR(E16))) for a in range(128) for b in range(128))
tys = (ltype_eps(E70), ltype_eps(E16)); cens = (centre(C70), centre(C16))
ok1 = okK and tys == (clock_type(7, 0), clock_type(1, 6)) == (('C', 8, 1), ('C', 8, 1)) and cens == ([0, TOP], [0, TOP])
ok1 &= C70.sq(TOP) == -1 == C16.sq(TOP) and sum(C70.S[a][a] for a in range(128)) == 0 == sum(C16.S[a][a] for a in range(128))
chk('bit', ok1, 'fc.CPX: Cl(7,0) (clock 7) and Cl(1,6) (clock 3) on their 128 labels (the table is BR.s on all 16384 pairs): types %s and %s, centre span{1, i} with i the label 127 (e1..e7 of Cl(7,0); e0..e6 of Cl(1,6), whose e0 has square +1), i^2 = -1, count 0: both are C (x) Cl(0,6) = M8(C) as real algebras' % (tstr(tys[0]), tstr(tys[1])))
F70 = [C70.mul(blade(1 << i), blade(64)) for i in range(6)]                 # f_i = e_i e7 in Cl(7,0)
def words_mv(C, G):
    W = [ONE]
    for a in range(1, 1 << len(G)):
        top = a.bit_length() - 1; W.append(C.mul(W[a ^ (1 << top)], G[top]))
    return W
W70 = words_mv(C70, F70); EVEN128 = [a for a in range(128) if pc(a) % 2 == 0]
okC7 = all(len(w) == 1 for w in W70) and sorted(next(iter(w)) for w in W70) == EVEN128
okC7 &= all(eq(C70.mul(W70[a], W70[b]), scal(W70[a ^ b], C06.S[a][b])) for a in range(64) for b in range(64))
okC7 &= all(C70.commute(next(iter(f)), TOP) for f in F70) and eq(W70[63], blade(63, -1))
okC1 = all(C16.S[2 * a][2 * b] == C06.S[a][b] for a in range(64) for b in range(64)) and all(C16.commute(2 * a, TOP) for a in range(64))
chk('bit', okC7 and okC1, 'fc.CPX: the copy of Cl(0,6): in Cl(7,0) the six products f_i = e_i e7 square to -1, anticommute and commute with i; their 64 words are the 64 even labels and multiply by the table of Cl(0,6) on all 4096 pairs (the even part, after a signed relabelling; f1..f6 = -e1..e6); in Cl(1,6) the six generators of square -1 are Cl(0,6) on the nose: the 64 labels with bit 0 clear, with the signs of Cl(0,6), commuting with i')
G60 = [C16.mul(blade(1 << i), blade(1)) for i in range(1, 7)]               # the literal reading in Cl(1,6): e_i e0
W60 = words_mv(C16, G60); C60 = Cell(sig(6, 0)); S16a = np.array(C16.S, dtype=np.int64); ixe = {a: k for k, a in enumerate(EVEN128)}
okL = all(eq(C16.mul(g, g), ONE) for g in G60) and sorted(next(iter(w)) for w in W60) == EVEN128
okL &= all(eq(C16.mul(W60[a], W60[b]), scal(W60[a ^ b], C60.S[a][b])) for a in range(64) for b in range(64))
tev = table_type(S16a[np.ix_(EVEN128, EVEN128)], [ixe[1 | (1 << k)] for k in range(1, 7)])
chk('ctl', okL and tev == ltype_eps(sig(6, 0)) == ('H', 4, 1), 'fc.CPX: the brief\'s "same reading" taken literally in Cl(1,6): the products e_i e0 with the extra generator square to +1 and their words have the table of Cl(6,0): the even part of Cl(1,6), of type %s, not Cl(0,6) = M8(R); in Cl(1,6) the copy of Cl(0,6) is the six generators themselves' % tstr(tev))
com_i = [a for a in range(128) if C16.commute(a, TOP)]; com_w = [a for a in range(128) if C16.commute(a, OMG)]
okW = len(com_i) == 128 and com_w == [a for a in range(128) if pc(a >> 1) % 2 == 0] and C16.sq(OMG) == -1
okW &= all(not C16.commute(1 << j, OMG) for j in range(1, 7)) and C16.commute(1, OMG) and C16.commute(TOP, OMG) and OMG != TOP
chk('bit', okW, 'fc.CPX: two complex structures in Cl(1,6): i commutes with all 128 labels; omega = e1..e6 (Furey\'s omega = L_e7 under e_j -> L_e_j, A3) squares to -1 and commutes with the %d labels that carry an even number of the six bits, anticommutes with the other 64 (with each of e1..e6) and commutes with e0 and with i: the first central, the second inside the copy of Cl(0,6)' % len(com_w))
WI16 = C16.mul(W_, I_); WI70 = C70.mul(W70[63], I_)
Pm, Pp = scal(add(ONE, C16.mul(I_, W_), -1), Fr(1, 2)), scal(add(ONE, C16.mul(I_, W_)), Fr(1, 2))      # (1 - i omega)/2, (1 + i omega)/2
L16 = Lab(lambda a, b: C16.S[a][b], 7); G16 = comm_labels(L16, tries=20); I16 = Ideal(L16, G16)
rk_pm = (rank_frac(mv_mat(I16, Pm)), rank_frac(mv_mat(I16, Pp)))
okP = eq(WI16, blade(1, -1)) and eq(WI70, blade(64)) and eq(C16.mul(WI16, WI16), ONE) and eq(Pm, scal(add(ONE, blade(1)), Fr(1, 2)))
okP &= eq(C16.mul(Pm, Pm), Pm) and eq(C16.mul(Pm, Pp), {}) and eq(add(Pm, Pp), ONE) and I16.m == 16 and rk_pm == (8, 8)
chk('bit', okP, 'fc.CPX: their product is the extra generator: omega i = -e0 in Cl(1,6) (and f1..f6 i = +e7 in Cl(7,0)), so (i omega)^2 = +1 and the splitting idempotents (1 - i omega)/2 = (1 + e0)/2 and (1 + i omega)/2 = (1 - e0)/2 are orthogonal with sum 1, scalar part 1/2: real rank %d and %d on the 16-dimensional ideal (three commuting labels of square +1), complex rank 4 each on C^8' % rk_pm)
U61 = ungraded_table(E06, sig(0, 1)).astype(np.int64)
def psi(c):
    a, b = c & 63, c >> 6
    if not b: return 2 * a, 1
    (m, s), = C16.mul(I_, blade(2 * a)).items(); return m, int(s)
PSI = [psi(c) for c in range(128)]
okU = len({m for m, s in PSI}) == 128 and all(PSI[c][0] ^ PSI[d][0] == PSI[c ^ d][0] and PSI[c][1] * PSI[d][1] * C16.S[PSI[c][0]][PSI[d][0]] == U61[c, d] * PSI[c ^ d][1] for c in range(128) for d in range(128))
chk('bit', okU, 'fc.CPX: Cl(1,6) is fb.OCT\'s C (x) Cl(0,6), the ungraded product with Cl(0,1): the relabelling (a, 0) -> e_a, (a, 1) -> i e_a carries its table onto that of the cell on all 16384 pairs')
DS = [(-1) ** ((pc(a) * (pc(a) + 1) // 2 + (a & 1)) % 2) for a in range(128)]    # Furey's dagger on the labels of Cl(1,6)
CS = [(-1) ** (a & 1) for a in range(128)]                                      # complex conjugation: the reflection e0 -> -e0
def dag16(x): return {a: DS[a] * c for a, c in x.items()}
def conj16(x): return {a: CS[a] * c for a, c in x.items()}
okD = all(C16.S[a][b] * DS[a ^ b] == DS[a] * DS[b] * C16.S[b][a] for a in range(128) for b in range(128))
okD &= all(DS[1 << j] == -1 for j in range(1, 7)) and DS[TOP] == -1 and DS[1] == 1 and CS[TOP] == -1 and all(CS[2 * a] == 1 for a in range(64))
REV7 = [(-1) ** ((pc(a) * (pc(a) - 1) // 2) % 2) for a in range(128)]; GR7 = [(-1) ** pc(a) for a in range(128)]
okD &= all(REV7[next(iter(f))] == -1 and GR7[next(iter(f))] == 1 for f in F70) and REV7[TOP] == -1 == GR7[TOP]
chk('bit', okD, 'fc.CPX: Furey\'s dagger (complex conjugation with reversal, L_u^dagger = -L_u) is on Cl(1,6) the anti-automorphism e_a -> (-1)^(|a|(|a|+1)/2 + a0) e_a (on all 16384 pairs): e_j -> -e_j, i -> -i, e0 -> e0; complex conjugation is the reflection e0 -> -e0 (an automorphism fixing the copy, i -> -i); on Cl(7,0) the dagger is the reversion and the conjugation the grade involution (f_i -> -f_i and f_i, i -> -i under both)')
note('the cell used below is Cl(1,6) = Cl(1,0) (x)^ Cl(0,6): its copy of Cl(0,6) is FUR-008\'s cell itself (a set of its labels), Furey\'s six L_e_j are generators of the cell, and the splitting is by its generator e0; Cl(7,0) has the standard involutions')
note('(%.1f s)' % (time.time() - t))
t = time.time()
I8i = np.eye(8, dtype=np.int64)
okA = all(np.array_equal(LO[a] @ LO[a], -I8i) for a in range(1, 8)) and np.array_equal(prodm([LO[a] for a in range(1, 7)]), LO[7])
okA &= np.array_equal(2 * RO[7], -LO[7] + LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5])
SM = np.zeros((8, 8), dtype=np.int64); SM[0, 0] = 1
for a_ in range(1, 8): SM[F2M[a_][0], a_] = F2M[a_][1]
LMOD = [np.rint(OM.Lmat(OM.E[m])).astype(np.int64) for m in range(8)]
okM = all(np.array_equal(SM @ LO[a] @ SM.T, F2M[a][1] * LMOD[F2M[a][0]]) for a in range(1, 8))
chk('std', okA and okM, 'fc.CPX: numpy, the octonions as data: the Roadmap table of furey_papers_check.py rebuilt (A1-A3: e_a^2 = -1, L_e7 = L_e1 .. L_e6, 2 R_e7 = -L_e7 + L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5) and the model of reports/furey/model.py under e1 = -lj, e2 = i, e3 = -li, e4 = -lk, e5 = l, e6 = j, e7 = k (its note "k = e7, j = e6, i = e2, l = e5" extended by products): the seven left multiplications agree entry by entry')
GC16 = [-1j * LO[7]] + [LO[j].astype(complex) for j in range(1, 7)]          # Cl(1,6) on C (x) O: e0 -> -i L_e7, e_j -> L_e_j
GC70 = [1j * (LO[j] @ LO[7]) for j in range(1, 7)] + [1j * LO[7].astype(complex)]   # Cl(7,0): e_j -> i L_e_j L_e7, e7 -> i L_e7
RHO = fwords(GC16, np.complex128); W7c = fwords(GC70, np.complex128)
vol16, vol70 = prodm(GC16), prodm(GC70); Ic8 = np.eye(8)
rkw = [int(np.linalg.matrix_rank(np.array([realify(w).ravel() for w in W]))) for W in (RHO, W7c)]
rkP = [int(np.linalg.matrix_rank((Ic8 - s * 1j * LO[7]) / 2)) for s in (1, -1)]
okS = frel_ok(GC16, E16) and frel_ok(GC70, E70) and np.allclose(vol16, 1j * Ic8) and rkw == [128, 128] and rkP == [4, 4]
W6c = fwords([LO[j].astype(complex) for j in range(1, 7)], np.complex128)
okS &= all(np.allclose(RHO[2 * a], W6c[a]) for a in range(64)) and all(np.allclose(GC70[j] @ GC70[6], LO[j + 1]) for j in range(6))
chk('std', okS, 'fc.CPX: numpy on C (x) O = C^8, no label: e0 -> -i L_e7, e_j -> L_e_j satisfy the relations of Cl(1,6) with volume element i 1 (central); e_j -> i L_e_j L_e7 (the octonionic factor of A4\'s Gamma_j), e7 -> i L_e7 those of Cl(7,0), volume element %s 1, and f_j = e_j e7 -> L_e_j; the 128 words of each have real rank 128 (M8(C)); (1 -+ i L_e7)/2 have rank %d and %d' % ('i' if np.allclose(vol70, 1j * Ic8) else ('-i' if np.allclose(vol70, -1j * Ic8) else '?'), rkP[0], rkP[1]))
T16, okt16 = mat_table(np.array([realify(w) for w in RHO])); T70, okt70 = mat_table(np.array([realify(w) for w in W7c]))
okAd = all(np.allclose(RHO[a].conj().T, DS[a] * RHO[a]) for a in range(128)) and np.allclose(RHO[OMG], LO[7]) and np.allclose(RHO[TOP], 1j * Ic8)
chk('bit==std', okt16 and okt70 and np.array_equal(T16, S16a) and np.array_equal(T70, np.array(C70.S, dtype=np.int64)) and okAd, 'fc.CPX: the sign tables read from the matrices equal the label tables of Cl(1,6) and Cl(7,0) on all 16384 entries; the image of omega = e1..e6 is L_e7 and that of the label 127 is i 1; the matrix adjoint of each of the 128 images is the image of the label dagger')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fc.CAR  the ladder operators and the vacuum
head('fc.CAR  the ladder operators alpha_a = (-e_j + i e_k)/2 from R1\'s pairs (5,4), (3,1), (6,2) with the central i; the CAR; the vacuum nu')
t = time.time()
def gen(j): return blade(1 << j)
def ladder(pairs, isign=1, with_i=True, dagsign=1):
    """alpha_a = (-e_j + i e_k)/2 and its adjoint by the label dagger, (e_j + i e_k)/2 (R1's a_c and a_c^dagger, on the six units);
    isign = -1 takes -i, with_i = False drops i, dagsign = -1 takes minus the adjoint (the brief's formula)"""
    iu = scal(I_, isign) if with_i else ONE
    A = [lin((Fr(-1, 2), gen(j)), (Fr(1, 2), C16.mul(iu, gen(k)))) for j, k in pairs]
    return A, [scal(dag16(x), dagsign) for x in A]
def car_fails(A, Ad):
    """the number of failing relations among {a_a, a_b^d} = delta_ab, {a_a, a_b} = 0, {a_a^d, a_b^d} = 0 (21 for three modes)"""
    n = len(A); bad = 0
    for a in range(n):
        for b in range(n):
            bad += not eq(C16.anti(A[a], Ad[b]), ONE if a == b else {})
            if a <= b: bad += (not eq(C16.anti(A[a], A[b]), {})) + (not eq(C16.anti(Ad[a], Ad[b]), {}))
    return bad
def vacuum(A, Ad, drop=()):
    return C16.prod(*[f for k, f in enumerate([A[0], A[1], A[2], Ad[2], Ad[1], Ad[0]]) if k not in drop])
def rho(x):
    out = np.zeros((8, 8), dtype=np.complex128)
    for a, c in x.items(): out += float(c) * RHO[a]
    return out
MAINPAIRS = {'WRONGPAIR': [(5, 4), (3, 4), (6, 2)], 'NONFANO': [(2, 1), (4, 3), (6, 5)]}.get(FAULT, FUREY)
AL, AD = ladder(MAINPAIRS, -1 if FAULT == 'IMINUS' else 1, FAULT != 'NOI', -1 if FAULT == 'DAGSIGN' else 1)
NU = vacuum(AL, AD, drop=(5,) if FAULT == 'NOFACTOR' else ())
ALf, ADf = ladder(FUREY); NUf = vacuum(ALf, ADf)                            # the construction itself, for the controls
def biv(j, k): return C16.mul(gen(j), gen(k))
XP = [C16.mul(I_, biv(j, k)) for j, k in MAINPAIRS]                         # i e_j e_k, with the central i
nfail = car_fails(AL, AD)
okA = nfail == 0 and all(eq(AD[a], lin((Fr(1, 2), gen(j)), (Fr(1, 2), C16.mul(I_, gen(k))))) for a, (j, k) in enumerate(MAINPAIRS))
chk('bit', okA, 'fc.CAR: on the labels of Cl(1,6) (bit j = e_j, i = the label 127) alpha_a = (-e_j + i e_k)/2 for (j, k) = %s and the adjoint by the label dagger is (e_j + i e_k)/2 (R1\'s a_c^dagger); {alpha_a, alpha_b^d} = delta_ab, {alpha_a, alpha_b} = 0 = {alpha_a^d, alpha_b^d} exactly: %d of the 21 relations fail' % (MAINPAIRS, nfail))
PA = [C16.mul(AL[a], AD[a]) for a in range(3)]; PB = [C16.mul(AD[a], AL[a]) for a in range(3)]
okM = all(eq(PA[a], scal(add(ONE, XP[a], -1), Fr(1, 2))) and eq(PB[a], scal(add(ONE, XP[a]), Fr(1, 2))) for a in range(3))
okM &= all(eq(C16.comm(PA[a], PA[b]), {}) for a in range(3) for b in range(3))
chk('bit', okM, 'fc.CAR: alpha_a alpha_a^d = (1 - i e_j e_k)/2 (mode a empty) and alpha_a^d alpha_a = (1 + i e_j e_k)/2 (mode a full), the three commuting')
nu_want = C16.prod(*[scal(add(ONE, x, -1), Fr(1, 2)) for x in [C16.mul(I_, biv(j, k)) for j, k in FUREY]])
okN = eq(NU, nu_want) and len(NU) == 8 and eq(C16.mul(NU, NU), NU) and eq(dag16(NU), NU) and all(eq(C16.mul(a_, NU), {}) for a_ in AL) and NU.get(0) == Fr(1, 8)
chk('bit', okN, 'fc.CAR: nu = alpha1 alpha2 alpha3 alpha3^d alpha2^d alpha1^d = prod_a (1 - i e_j e_k)/2 for Furey\'s pairs: %d terms, scalar part %s, nu^2 = nu = nu^dagger, alpha_a nu = 0 for the three' % (len(NU), NU.get(0)))
rk_nu = rank_frac(mv_mat(I16, NU)); corner = [C16.mul(C16.mul(NU, blade(a)), NU) for a in range(128)]
rk_c = rank_mv(corner); in_c = rank_mv(corner + [NU, C16.mul(I_, NU)]) == 2
IDL = [C16.mul(blade(a), NU) for a in range(128)]; RID = [C16.mul(NU, blade(a)) for a in range(128)]
rk_l, rk_r = rank_mv(IDL), rank_mv(RID)
chk('bit', (rk_nu, rk_c, rk_l, rk_r) == (2, 2, 16, 16) and in_c, 'fc.CAR: the ranks of nu: real rank %d on the 16-dimensional ideal (complex rank 1 = 8 x 1/8 on C^8); the corner nu A nu is span{nu, i nu} (real dimension %d: C, so nu is primitive); the left ideal A nu has real dimension %d = complex 8, the irreducible module of M8(C): minimal; left multiplication by nu on the 128 labels has rank %d' % (rk_nu, rk_c, rk_l, rk_r))
okW = eq(C16.mul(W_, NU), scal(C16.mul(I_, NU), -1)) and eq(C16.mul(Pp, NU), NU) and eq(C16.mul(blade(1), NU), scal(NU, -1))
chk('bit', okW, 'fc.CAR: omega nu = -i nu: the vacuum lies in the -i eigenspace of Furey\'s omega = L_e7, (1 + i omega) nu / 2 = nu, e0 nu = -nu (the product of the three i e_j e_k is -i omega: the permutation (5,4,3,1,6,2) is even)')
note('(%.1f s)' % (time.time() - t))
t = time.time()
ALm, ADm = ladder(FUREY, isign=-1); NUm = vacuum(ALm, ADm)
NNf = lin(*[(1, C16.mul(ADf[a], ALf[a])) for a in range(3)])
okIm = car_fails(ALm, ADm) == 0 and eq(NUm, conj16(NUf)) and not eq(NUm, NUf) and eq(C16.mul(W_, NUm), C16.mul(I_, NUm)) and eq(C16.mul(NNf, NUm), scal(NUm, 3))
chk('ctl', okIm, 'fc.CAR: with the other sign of i (IMINUS) the CAR still hold, but the vacuum moves to its complex conjugate conj(nu) != nu, the vacuum of the conjugate ideal: omega conj(nu) = +i conj(nu), and the number operator of the pairs with +i reads 3 on it')
ALw, ADw = ladder([(5, 4), (3, 4), (6, 2)]); nw = car_fails(ALw, ADw)
chk('ctl', nw > 0 and not eq(C16.anti(ALw[0], ADw[1]), {}), 'fc.CAR: a wrong pairing (WRONGPAIR: (5,4), (3,4), (6,2), e4 twice): %d of the 21 relations fail, {alpha1, alpha2^d} != 0' % nw)
n1 = vacuum(ALf, ADf, drop=(5,)); n2 = vacuum(ALf, ADf, drop=(0, 5))
E1f = C16.prod(add(ONE, C16.mul(ALf[0], ADf[0]), -1), C16.mul(ALf[1], ADf[1]), C16.mul(ALf[2], ADf[2]))     # mode 1 full, modes 2 and 3 empty
okNF1 = eq(n1, C16.mul(ALf[0], E1f)) and all(eq(C16.mul(a_, n1), {}) for a_ in ALf) and eq(C16.mul(NNf, n1), {})
chk('ctl', eq(C16.mul(n1, n1), {}) and n1 != {} and okNF1 and eq(C16.mul(n2, n2), n2) and n2.get(0) == Fr(1, 4), 'fc.CAR: nu without one factor (NOFACTOR: alpha1^d dropped) squares to 0: not an idempotent; it is alpha1 E (E the idempotent of mode 1 full, modes 2 and 3 empty), still killed by the three alpha_a with N = 0: a vacuum vector of another minimal ideal, not a projector; without the pair alpha1, alpha1^d it is an idempotent of scalar part 1/4, complex rank 2: not minimal')
ALn, ADn = ladder(FUREY, with_i=False)
QF = [[C16.anti(gen(j), gen(k)).get(0, Fr(0)) / 2 for k in range(1, 7)] for j in range(1, 7)]
okNI = all(eq(ADn[a], scal(ALn[a], -1)) for a in range(3)) and all(eq(C16.anti(ALn[a], ALn[b]), scal(ONE, -1) if a == b else {}) and eq(C16.anti(ALn[a], ADn[b]), ONE if a == b else {}) for a in range(3) for b in range(3))
okNI &= all(eq(C16.mul(x, x), scal(ONE, Fr(-1, 2))) for x in ALn) and eq(vacuum(ALn, ADn), scal(ONE, Fr(1, 8))) and QF == [[Fr(-int(j == k)) for k in range(6)] for j in range(6)]
chk('ctl', okNI, 'fc.CAR: the pairs without the central i (NOI): beta_a = (-e_j + e_k)/2 has beta_a^d = -beta_a, {beta_a, beta_b} = -delta_ab, {beta_a, beta_b^d} = +delta_ab, beta_a^2 = -1/2: Clifford generators again, no CAR; the quadratic form of the six is -1 (definite: no real isotropic vector in Cl(0,6)), and the product in nu\'s place is the scalar 1/8')
nd = car_fails(ALf, [scal(x, -1) for x in ADf])
chk('ctl', nd > 0 and eq(C16.anti(ALf[0], scal(ADf[0], -1)), scal(ONE, -1)), 'fc.CAR: the brief\'s alpha_a^d = (-e_j - i e_k)/2 (DAGSIGN) is minus the adjoint: {alpha_a, (-e_j - i e_k)/2} = -1, and %d of the 21 relations fail' % nd)
note('(%.1f s)' % (time.time() - t))
t = time.time()
ALc = [0.5 * (-LO[j] + 1j * LO[k]) for j, k in FUREY]; ADc = [x.conj().T for x in ALc]
okc = all(np.allclose(ALc[a] @ ADc[b] + ADc[b] @ ALc[a], (a == b) * Ic8) and np.allclose(ALc[a] @ ALc[b] + ALc[b] @ ALc[a], 0) for a in range(3) for b in range(3))
NUc = ALc[0] @ ALc[1] @ ALc[2] @ ADc[2] @ ADc[1] @ ADc[0]
okc &= np.allclose(NUc, NUc.conj().T) and np.allclose(NUc @ NUc, NUc) and int(np.linalg.matrix_rank(NUc)) == 1 and abs(np.trace(NUc) - 1) < 1e-12
okc &= all(np.allclose(a_ @ NUc, 0) for a_ in ALc) and np.allclose(LO[7] @ NUc, -1j * NUc)
chk('std', okc, 'fc.CAR: numpy on C (x) O (complex 8 x 8, the Roadmap table, no label): alpha_a = (-L_e_j + i L_e_k)/2 with the adjoint by conjugate transpose satisfy the CAR; nu is Hermitian, idempotent, of rank 1 and trace 1, killed by the three alpha_a, and L_e7 nu = -i nu')
chk('bit==std', all(np.allclose(rho(AL[a]), ALc[a]) and np.allclose(rho(AD[a]), ADc[a]) for a in range(3)) and np.allclose(rho(NU), NUc), 'fc.CAR: the images of the label alpha_a, alpha_a^d and nu under e0 -> -i L_e7, e_j -> L_e_j are the numpy alpha_a, alpha_a^d and nu')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fc.FOCK  the eight states, N and Q
head('fc.FOCK  the minimal left ideal A nu: the eight states, the number operator N = sum alpha_a^d alpha_a, Q = N/3, and the conjugate ideal')
t = time.time()
SUBS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]           # the occupied modes of each state
def state(S, Ad, nu): return C16.prod(*([Ad[a] for a in S] + [nu]))
ST = [state(S, AD, NU) for S in SUBS]
BAS = ST + [C16.mul(I_, s) for s in ST]                                    # a real basis of A nu: the states and their i-multiples
CO = Coords(BAS)
okB = CO.ok and all(s != {} for s in ST) and all(CO(x) is not None for x in IDL)
chk('bit', okB, 'fc.FOCK: the eight states nu, alpha_a^d nu, alpha_a^d alpha_b^d nu (a < b), alpha1^d alpha2^d alpha3^d nu with their i-multiples are 16 real-independent elements, and each of the 128 products e_a nu lies in their span: a complex basis of the minimal left ideal A nu (complex dimension 8)')
NN = lin(*[(1, C16.mul(AD[a], AL[a])) for a in range(3)]); K_ = lin(*[(1, biv(j, k)) for j, k in MAINPAIRS])
nvals = []
for S, s in zip(SUBS, ST):
    ns = C16.mul(NN, s); c = CO(ns) if CO.ok else None
    nvals.append(c[SUBS.index(S)] if c is not None and eq(ns, scal(s, c[SUBS.index(S)])) else None)
okNq = eq(NN, add(scal(ONE, Fr(3, 2)), scal(C16.mul(I_, K_), Fr(1, 2)))) and nvals == [len(S) for S in SUBS]
chk('bit', okNq, 'fc.FOCK: N = alpha1^d alpha1 + alpha2^d alpha2 + alpha3^d alpha3 = 3/2 + (i/2) K with K = e5e4 + e3e1 + e6e2; N s = n s on the eight states with n = %s, so Q = N/3 = %s: the charges 0, 1/3, 2/3, 1 with multiplicities 1, 3, 3, 1 (Furey\'s charge quantization from a number operator, arXiv:1603.04078; the names nu, the anti-down quarks, the up quarks, the positron are her reading, recalled)'
    % ([int(n) if n is not None else None for n in nvals], [str(Fr(n, 3)) if n is not None else None for n in nvals]))
okWs = all(eq(C16.mul(W_, s), scal(C16.mul(I_, s), 1 if len(S) % 2 else -1)) for S, s in zip(SUBS, ST)) and all(eq(C16.anti(W_, x), {}) for x in AD)
chk('bit', okWs, 'fc.FOCK: omega = L_e7 acts on the states as -i for N even (nu and the three N = 2 states) and as +i for N odd (the three N = 1 states and the top state): omega anticommutes with every alpha_a^d')
NUc_ = conj16(NU); STc = [conj16(s) for s in ST]
okCj = eq(NUc_, C16.prod(*[scal(add(ONE, x), Fr(1, 2)) for x in [C16.mul(I_, biv(j, k)) for j, k in FUREY]])) and eq(NUc_, C16.prod(AD[0], AD[1], AD[2], AL[2], AL[1], AL[0]))
okCj &= all(eq(conj16(AL[a]), scal(AD[a], -1)) for a in range(3)) and eq(conj16(NN), add(scal(ONE, 3), NN, -1))
okCj &= all(eq(C16.mul(NN, sc), scal(sc, 3 - len(S))) for S, sc in zip(SUBS, STc)) and rank_mv(IDL + [conj16(x) for x in IDL]) == 32
QC = [str(Fr(3 - len(S), 3) - 1) for S in SUBS]
chk('bit', okCj, 'fc.FOCK: the conjugate ideal: conj(nu) = prod_a (1 + i e_j e_k)/2 = alpha1^d alpha2^d alpha3^d alpha3 alpha2 alpha1 (Furey\'s second idempotent, recalled), conj(alpha_a) = -alpha_a^d, conj(N) = 3 - N; on the conjugate states N = 3 - n, and A nu + A conj(nu) has real dimension 32 (they meet in 0); the charge -conj(Q) = N/3 - 1 gives %s on them, the opposite charges (her anti-neutrino, down quarks, anti-up quarks, electron: her reading, recalled)' % QC)
note('(%.1f s)' % (time.time() - t))
t = time.time()
w_, V_ = np.linalg.eigh(NUc); v0 = V_[:, -1]; v0 = v0 / v0[np.argmax(np.abs(v0))]          # the image of nu, scaled
one_ie7 = np.zeros(8, dtype=complex); one_ie7[0] = 1; one_ie7[7] = 1j
NNc = sum(ADc[a] @ ALc[a] for a in range(3)); STn = [prodm([ADc[a] for a in S] + [Ic8.astype(complex)]) @ one_ie7 for S in SUBS]
ev = sorted(np.round(np.linalg.eigvals(NNc).real, 9))
okF = np.allclose(NUc @ one_ie7, one_ie7) and np.allclose(v0, one_ie7 / one_ie7[0]) and int(np.linalg.matrix_rank(np.array(STn))) == 8
okF &= all(np.allclose(NNc @ s, len(S) * s) for S, s in zip(SUBS, STn)) and ev == [0, 1, 1, 1, 2, 2, 2, 3]
top_dir = STn[7] / STn[7][np.argmax(np.abs(STn[7]))]; o2 = [1, 2, 3, 4, 5, 6]
okF &= np.allclose(top_dir[o2], 0) and np.allclose(top_dir[7] / top_dir[0], -1j) and all(np.allclose(s[[0, 7]], 0) for s in STn[1:7])
chk('std', okF, 'fc.FOCK: numpy on C (x) O: the image of nu is the line of 1 + i e7, the top state alpha1^d alpha2^d alpha3^d (1 + i e7) lies on the line of 1 - i e7, and the six others in the span of e1 .. e6 (FUR-001\'s O2): the 8 vectors are independent, N has the eigenvalues %s and N s = n s on them' % [int(x) for x in ev])
chk('bit==std', all(np.allclose(rho(s) @ one_ie7, s_np) for s, s_np in zip(ST, STn)) and np.allclose(rho(NN), NNc), 'fc.FOCK: the images of the eight label states, applied to 1 + i e7, are the numpy states, and the image of the label N is the numpy N')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fc.SU3  the su(3) and the u(1)
head('fc.SU3  Lambda_k = sum (lambda_k)_ab alpha_a^d alpha_b: su(3) on the labels, the u(1) of N, 1 + 3 + 3bar + 1, the derivations of O fixing e7')
t = time.time()
def cplx_mv(z): return lin((z[0], ONE), (z[1], I_))                         # a Gaussian rational as the multivector re + im i
def Lam(lam, Ad, A): return lin(*[(1, C16.mul(cplx_mv(lam[a][b]), C16.mul(Ad[a], A[b]))) for a in range(3) for b in range(3) if lam[a][b] != CZ])
def cscale3(z, A): return [[cmul(z, A[i][j]) for j in range(3)] for i in range(3)]
def cadd3(A, B): return [[cadd(A[i][j], B[i][j]) for j in range(3)] for i in range(3)]
CST = {}; okG3 = True
for k in range(8):
    for l in range(8):
        Cm = msub3(mm3(GELL[k], GELL[l]), mm3(GELL[l], GELL[k]))
        CST[k, l] = [cdiv(tr3(mm3(Cm, GELL[m])), tr3(mm3(GELL[m], GELL[m]))) for m in range(8)]
        acc = [[CZ] * 3 for _ in range(3)]
        for m in range(8): acc = cadd3(acc, cscale3(CST[k, l][m], GELL[m]))
        okG3 &= acc == Cm and all(c[0] == 0 for c in CST[k, l])
okG3 &= [m for m in range(8) if CST[0, 1][m] != CZ] == [2] and CST[0, 1][2] == (0, 2) and [m for m in range(8) if CST[3, 4][m] != CZ] == [2, 7]
okG3 &= CST[3, 4][2] == CST[3, 4][7] == (0, 1) and [m for m in range(8) if CST[3, 7][m] != CZ] == [4] and CST[3, 7][4] == (0, -3)
def su3_closes(LM):
    return all(eq(C16.comm(LM[k], LM[l]), lin(*[(1, C16.mul(cplx_mv(CST[k, l][m]), LM[m])) for m in range(8) if CST[k, l][m] != CZ])) for k in range(8) for l in range(8))
LAM = [Lam(l, AD, AL) for l in GELL]
nz = sum(1 for kl in CST for c in CST[kl] if c != CZ)
chk('bit', okG3 and su3_closes(LAM), 'fc.SU3: the Gell-Mann matrices (lambda8\' = sqrt3 lambda8 = diag(1,1,-2), so that every constant is rational) close exactly, [lambda_k, lambda_l] = sum_m c_klm lambda_m with c_klm purely imaginary (%d non-zero, e.g. [l1, l2] = 2i l3, [l4, l5] = i (l3 + l8\'), [l4, l8\'] = -3i l5), and on the labels the eight Lambda_k satisfy [Lambda_k, Lambda_l] = sum_m c_klm Lambda_m on all 64 pairs, with i the label 127' % nz)
F1 = [ST[1], ST[2], ST[3]]; T2 = [ST[6], scal(ST[5], -1), ST[4]]             # alpha_a^d nu; t_c = eps_cde alpha_d^d alpha_e^d nu / 2
def acts(LM, vecs, mats):
    return all(eq(C16.mul(LM[k], vecs[c]), lin(*[(1, C16.mul(cplx_mv(mats[k][a][c]), vecs[a])) for a in range(3) if mats[k][a][c] != CZ])) for k in range(8) for c in range(3))
GELLbar = [[[(-l[c][a][0], -l[c][a][1]) for c in range(3)] for a in range(3)] for l in GELL]   # -lambda^T
okR = acts(LAM, F1, GELL) and acts(LAM, T2, GELLbar) and all(eq(C16.mul(L_, ST[0]), {}) and eq(C16.mul(L_, ST[7]), {}) for L_ in LAM)
okR &= all(eq(C16.comm(L_, NN), {}) for L_ in LAM)
chk('bit', okR, 'fc.SU3: on the ideal: Lambda_k alpha_c^d nu = sum_a (lambda_k)_ac alpha_a^d nu (the 3), Lambda_k t_c = sum_a (-lambda_k^T)_ac t_a on t_c = eps_cde alpha_d^d alpha_e^d nu / 2 (the 3bar), Lambda_k nu = 0 = Lambda_k alpha1^d alpha2^d alpha3^d nu (two singlets), exactly; every [Lambda_k, N] = 0: su(3) keeps the grading of A nu by N')
def ccommutant(mats):
    rows = []
    for l in mats:
        P = [[l[i][j][0] for j in range(3)] for i in range(3)]; Q = [[l[i][j][1] for j in range(3)] for i in range(3)]
        for i in range(3):
            for j in range(3):                                   # unknowns A (0..8) and B (9..17), X = A + iB; [lambda, X] = 0, real and imaginary parts
                re = [Fr(0)] * 18; im = [Fr(0)] * 18
                for k in range(3):
                    re[3 * k + j] += P[i][k]; re[9 + 3 * k + j] -= Q[i][k]; re[3 * i + k] -= P[k][j]; re[9 + 3 * i + k] += Q[k][j]
                    im[9 + 3 * k + j] += P[i][k]; im[3 * k + j] += Q[i][k]; im[3 * i + k] -= Q[k][j]; im[9 + 3 * i + k] -= P[k][j]
                rows += [re, im]
    return len(nullspace_frac(rows, 18))
cc3, cc3b = ccommutant(GELL), ccommutant(GELLbar)
sp8 = (sorted(GELL[7][i][i][0] for i in range(3)), sorted(GELLbar[7][i][i][0] for i in range(3)))
chk('bit', (cc3, cc3b) == (2, 2) and sp8[0] != sp8[1], 'fc.SU3: the 3 and the 3bar are irreducible (commutant of real dimension %d and %d: C) and inequivalent (Lambda8\' has the eigenvalues %s on the N = 1 states and %s on the N = 2 states): the eight states carry 1 + 3 + 3bar + 1 under su(3), with Q = 0, 1/3, 2/3, 1' % (cc3, cc3b, [int(x) for x in sp8[0]], [int(x) for x in sp8[1]]))
ILAM = [C16.mul(I_, L_) for L_ in LAM]; BIV15 = [biv(u, v) for u in range(1, 7) for v in range(u + 1, 7)]
okRe = all(all(not (a & 1) and pc(a) == 2 for a in x) for x in ILAM)
CK = [C16.comm(b_, K_) for b_ in BIV15]; labsK = sorted({a for x in CK for a in x})
NK = nullspace_frac([[x.get(a, 0) for x in CK] for a in labsK], 15)
BLAB = [next(iter(b_.items())) for b_ in BIV15]                             # (label, sign) of each e_u e_v
def coef(x): return [x.get(m, 0) * s for m, s in BLAB]                    # the coordinates of a combination of bivectors
okRe &= len(NK) == 9 and rank_frac([coef(x) for x in ILAM]) == 8 and rank_frac([coef(x) for x in ILAM] + [coef(K_)] + [[v for v in n] for n in NK]) == 9
(ja, ka), (jb, kb), (jc, kc) = MAINPAIRS
EXPL = [add(biv(MAINPAIRS[a][0], MAINPAIRS[b][0]), biv(MAINPAIRS[a][1], MAINPAIRS[b][1])) for a, b in ((0, 1), (0, 2), (1, 2))]
EXPL += [add(biv(MAINPAIRS[a][0], MAINPAIRS[b][1]), biv(MAINPAIRS[a][1], MAINPAIRS[b][0]), -1) for a, b in ((0, 1), (0, 2), (1, 2))]
EXPL += [add(biv(ja, ka), biv(jb, kb), -1), add(biv(jb, kb), biv(jc, kc), -1)]
okRe &= rank_frac([coef(x) for x in EXPL]) == 8 and rank_frac([coef(x) for x in ILAM + EXPL]) == 8
Y0 = C16.mul(I_, add(NN, scal(ONE, Fr(3, 2)), -1))
okRe &= eq(Y0, scal(K_, Fr(-1, 2))) and all(eq(C16.comm(Y0, x), {}) for x in ILAM)
chk('bit', okRe, 'fc.SU3: the real forms i Lambda_k contain no i: they are eight bivectors of the copy Cl(0,6) (e_ja e_jb + e_ka e_kb, e_ja e_kb - e_ka e_jb, e_ja e_ka - e_jb e_kb); with K they span the 9 bivectors of so(6) that commute with K (u(3)); Y0 = i (N - 3/2) = -K/2 is a real bivector commuting with su(3): the u(1) of N')
note('(%.1f s)' % (time.time() - t))
t = time.time()
R8 = {}
def r8lab(a):
    if a not in R8:
        M = np.eye(8, dtype=np.int64)
        for j in range(1, 7):
            if (a >> j) & 1: M = M @ LO[j]
        R8[a] = M
    return R8[a]
def rho8(x):
    """e_j -> L_e_j on the copy Cl(0,6) (labels with bit 0 clear): the 8 x 8 matrix, row-major, as 64 Fractions"""
    if any(a & 1 for a in x): return None
    out = [Fr(0)] * 64
    for a, c in x.items():
        M = r8lab(a).ravel()
        for u in range(64):
            if M[u]: out[u] += c * int(M[u])
    return out
OMT = [[omul_f(a, b) for b in range(8)] for a in range(8)]
rowsD = set()
for a in range(8):
    for b in range(8):
        s_ab, c_ab = OMT[a][b]
        for k in range(8):                                       # s_ab D[k][c_ab] - sum_(i: c_ib = k) s_ib D[i][a] - sum_(i: c_ai = k) s_ai D[i][b] = 0
            r = [0] * 64; r[8 * k + c_ab] += s_ab
            for i in range(8):
                s1, c1 = OMT[i][b]; s2, c2 = OMT[a][i]
                if c1 == k: r[8 * i + a] -= s1
                if c2 == k: r[8 * i + b] -= s2
            if any(r): rowsD.add(tuple(r))
DER = nullspace_frac([list(r) for r in rowsD], 64); DER7 = nullspace_frac([list(r) for r in rowsD] + [[int(u == 8 * i + 7) for u in range(64)] for i in range(8)], 64)
SU3V = [rho8(x) for x in ILAM]; BIVV = [rho8(b_) for b_ in BIV15]
kill = all(v is not None and all(v[8 * i + 0] == 0 and v[8 * i + 7] == 0 for i in range(8)) for v in SU3V)
okD = (len(DER), len(DER7)) == (14, 8) and kill and rank_frac(BIVV) == 15 and rank_frac(SU3V) == 8 and rank_frac(SU3V + DER7) == 8
chk('bit', okD, 'fc.SU3: the derivations of O (the Roadmap table, the Leibniz equations solved exactly) form g2 of dimension %d, those fixing e7 a space of dimension %d; under e_j -> L_e_j the eight i Lambda_k kill 1 and e7 and span exactly that space (rank of the union 8); e_j -> L_e_j is injective on the 15 bivectors (rank 15), so on the labels the su(3) of the ladder operators is the su(3) of the derivations fixing e7, eight bivectors (fb.COL, FUR-012)' % (len(DER), len(DER7)))
YV = rho8(Y0); want_Y = [Fr(int(RO[7].ravel()[u])) + Fr(int(LO[7].ravel()[u]), 2) for u in range(64)]
R11o = (LO[1] @ LO[3] + LO[2] @ LO[6] + LO[4] @ LO[5]).ravel(); QV = rho8(scal(Y0, Fr(1, 3)))
okY = YV == want_Y and rank_frac(DER + [YV]) == 15 and QV == [Fr(int(R11o[u]), 6) for u in range(64)]
chk('bit', okY, 'fc.SU3: the u(1) on O: Y0 = -K/2 goes to R_e7 + L_e7/2 (A2), not a derivation (rank 15 with g2); i (Q - 1/2) = Y0/3 goes to (L_e1 L_e3 + L_e2 L_e6 + L_e4 L_e5)/6, the octonionic part of furey_papers_check.py\'s iQ (R11)')
NF = [(2, 1), (4, 3), (6, 5)]; ALq, ADq = ladder(NF); NUq = vacuum(ALq, ADq); LAMq = [Lam(l, ADq, ALq) for l in GELL]
SU3q = [rho8(C16.mul(I_, x)) for x in LAMq]; rq = rank_frac(SU3q + DER7)
okNF = car_fails(ALq, ADq) == 0 and eq(C16.mul(NUq, NUq), NUq) and NUq.get(0) == Fr(1, 8) and su3_closes(LAMq) and rq > 8 and eq(C16.mul(W_, NUq), C16.mul(I_, NUq))
chk('ctl', okNF, 'fc.SU3: a disjoint pairing off the lines through e7 (NONFANO: (2,1), (4,3), (6,5)): the CAR hold, nu is an idempotent of scalar part 1/8 and the Lambda_k close into su(3), but this su(3) is not the derivations fixing e7 (rank of the union %d, not 8) and omega nu = +i nu: the CAR alone do not single out her pairing' % rq)
note('(%.1f s)' % (time.time() - t))
t = time.time()
Gc = [np.array([[complex(float(z[0]), float(z[1])) for z in row] for row in l]) for l in GELL]
LAMc = [sum(Gc[k][a, b] * (ADc[a] @ ALc[b]) for a in range(3) for b in range(3)) for k in range(8)]
cnp = {(k, l): [np.trace((Gc[k] @ Gc[l] - Gc[l] @ Gc[k]) @ Gc[m]) / np.trace(Gc[m] @ Gc[m]) for m in range(8)] for k in range(8) for l in range(8)}
okn = all(np.allclose(LAMc[k] @ LAMc[l] - LAMc[l] @ LAMc[k], sum(cnp[k, l][m] * LAMc[m] for m in range(8))) for k in range(8) for l in range(8))
okn &= all(np.allclose(L_ @ NNc, NNc @ L_) for L_ in LAMc) and all(np.allclose((1j * L_).imag, 0) for L_ in LAMc)
CCn = np.array([[OMT[a][b][0] * (np.arange(8) == OMT[a][b][1]) for b in range(8)] for a in range(8)], dtype=float)
rowsN = []
for a in range(8):
    for b in range(8):
        for k in range(8):
            r_ = np.zeros((8, 8)); r_[k, :] += CCn[a, b]
            for i in range(8): r_[i, a] -= CCn[i, b, k]; r_[i, b] -= CCn[a, i, k]
            rowsN.append(r_.ravel())
AD7n = np.vstack(rowsN + [np.eye(64)[8 * i + 7] for i in range(8)]); sv = np.linalg.svd(AD7n, compute_uv=False); n7 = 64 - int((sv > 1e-9).sum())
_, _, Vt = np.linalg.svd(AD7n); DERn = Vt[64 - n7:]
okn &= n7 == 8 and int(np.linalg.matrix_rank(np.vstack([DERn] + [(1j * L_).real.ravel() for L_ in LAMc]), tol=1e-8)) == 8
chk('std', okn, 'fc.SU3: numpy on C (x) O: the Lambda_k built from the numpy alpha_a close with the structure constants read from the 3 x 3 matrices, commute with N, and i Lambda_k is real; the derivations fixing e7 (numpy null space of the Leibniz equations, dimension %d) and the eight real i Lambda_k span one space (rank 8)' % n7)
chk('bit==std', all(np.allclose(rho(LAM[k]), LAMc[k]) for k in range(8)) and all(np.allclose([complex(float(z[0]), float(z[1])) for z in CST[kl]], cnp[kl]) for kl in CST), 'fc.SU3: the images of the eight label Lambda_k are the numpy Lambda_k, and the exact structure constants equal the numpy ones on all 512 entries')
note('(%.1f s)' % (time.time() - t))

# ================================================================================================ fc.AX  the eight states among the sixteen axes
head('fc.AX  the eight states among the sixteen axes of FUR-003/FUR-006: Cl(1,6) inside the Cl(0,8) of furey_bit_route.py; the 4 = 3 + 1 of FUR-012')
t = time.time()
# the model's Cl(0,8), copied from furey_bit_route.py (units, gm, the Fano lines from omul, mblade; data only): bit m - 1 = the model's unit
# m (m = 1 .. 7: i, j, k, l, li, lj, lk; k = e7 is bit 2), bit 7 = the doubling g8; V = O + O' with the axes 0 .. 7 in O and 8 .. 15 in O'
UNITS7 = [OM.E[m] for m in range(1, 8)]
GM = [np.rint(OM.blk(OM.Z, OM.Lmat(u), OM.Lmat(u), OM.Z)).astype(np.int64) for u in UNITS7] + [np.rint(OM.blk(OM.Z, OM.I8, -OM.I8, OM.Z)).astype(np.int64)]
LINES = []
for a in range(7):
    for b in range(a + 1, 7):
        pr = OM.omul(UNITS7[a], UNITS7[b]); c = int(np.argmax(abs(pr))) - 1
        if c > b: LINES.append((a, b, c))
LMASK = [(1 << a) | (1 << b) | (1 << c) | (1 << 7) for (a, b, c) in LINES]
def mblade(m):
    M = np.eye(16, dtype=np.int64)
    for a in range(8):
        if (m >> a) & 1: M = M @ GM[a]
    return M
C08 = Cell((-1,) * 8)
GRP = {(0, 1)}; fr_ = [(0, 1)]                                              # the group of the line blades (furey_bit_route.py B)
while fr_:
    nx = []
    for m, s in fr_:
        for l in LMASK:
            mm_, ss_ = m ^ l, s * C08.S[m][l]
            if (mm_, ss_) not in GRP: GRP.add((mm_, ss_)); nx.append((mm_, ss_))
    fr_ = nx
SL = sorted({m for m, s in GRP}); BASL = []; span_ = {0}
for l in LMASK:
    if l not in span_: BASL.append(l); span_ |= {x ^ l for x in span_}
def character(signs):
    chi = {}
    for T_ in itertools.product((0, 1), repeat=4):
        m, sg, val = 0, 1, 1
        for i_, t_ in enumerate(T_):
            if t_: sg *= C08.S[m][BASL[i_]]; m ^= BASL[i_]; val *= signs[i_]
        chi[m] = sg * val
    return chi
CHARS = [character(sg) for sg in itertools.product((1, -1), repeat=4)]
MBD = {m: np.diag(mblade(m)).tolist() for m in SL}
match = {k: [i for i, ch in enumerate(CHARS) if all(ch[l] == MBD[l][k] for l in LMASK)] for k in range(16)}
okMt = len(GRP) == 32 and len(SL) == 16 and all(len(v) == 1 for v in match.values()) and len({v[0] for v in match.values()}) == 16
CHI = {k: CHARS[match[k][0]] for k in range(16)} if okMt else {k: CHARS[0] for k in range(16)}
PAX = {k: {m: Fr(CHI[k][m], 16) for m in SL} for k in range(16)}           # the axis idempotents p_k = (1/16) sum_w chi_k(w) w
okMt &= all(eq(C08.mul(PAX[k], PAX[l]), PAX[k] if k == l else {}) for k in range(16) for l in range(16)) and eq(lin(*[(1, PAX[k]) for k in range(16)]), ONE)
okMt &= all(CHI[k][m] == MBD[m][k] for k in range(16) for m in SL)
K08 = BR((-1,) * 8); okMt &= all(C08.S[a][b] == K08.s(a, b) for a in range(256) for b in range(256))
def phi_tab(eps0):
    """the embedding of Cl(1,6) in Cl(0,8) on the 128 labels: e0 -> eps0 g1 .. g8 (label 255), e_j -> sign x g_(model unit - 1)"""
    G = [(255, eps0)] + [(1 << (F2M[j][0] - 1), F2M[j][1]) for j in range(1, 7)]; out = []
    for a in range(128):
        m, s = 0, 1
        for j in range(7):
            if (a >> j) & 1: s *= G[j][1] * C08.S[m][G[j][0]]; m ^= G[j][0]
        out.append((m, s))
    return out
EPS0 = 1; PHI = phi_tab(EPS0)
def phi(x, P=None):
    P = PHI if P is None else P; out = {}
    for a, c in x.items():
        m, s = P[a]; out = add(out, {m: c * s})
    return out
okPhi = all(PHI[a][0] ^ PHI[b][0] == PHI[a ^ b][0] and PHI[a][1] * PHI[b][1] * C08.S[PHI[a][0]][PHI[b][0]] == C16.S[a][b] * PHI[a ^ b][1] for a in range(128) for b in range(128))
IMG = sorted(m for m, s in PHI); JM = PHI[TOP]
okPhi &= IMG == [m for m in range(256) if ((m >> 2) & 1) == ((m >> 7) & 1)] and JM[0] == 132
chk('bit', okPhi and okMt, 'fc.AX: the 16 axis idempotents of FUR-003/FUR-006 on the labels of Cl(0,8) (BR.s on all 65536 pairs; the 32-element group of the seven line blades, its 16 characters matched one to one with the model\'s axes by the diagonal signs: orthogonal, sum 1); Cl(1,6) embeds by e_j -> +-g_u (Furey\'s e1 .. e6 = -lj, i, -li, -lk, l, j of the model) and e0 -> the volume element g1 .. g8: the table is kept on all 16384 pairs, the image is the 128 labels in which the bits of k = e7 and of g8 agree, and i -> %sg_k g8, the bivector of the two more generators' % ('' if JM[1] == 1 else '-'))
MA = [add(PA[a], PB[a], -1) for a in range(3)]                              # alpha_a alpha_a^d - alpha_a^d alpha_a = -i e_j e_k
PMA = [phi(x) for x in MA]; THROUGH_K = sorted(l for l in LMASK if (l >> 2) & 1)
okL = all(len(x) == 1 for x in PMA) and sorted(next(iter(x)) for x in PMA) == THROUGH_K and all(l not in IMG for l in LMASK if l not in THROUGH_K)
NAMES8 = ['i', 'j', 'k', 'l', 'li', 'lj', 'lk', 'g8']
chk('bit', okL, 'fc.AX: the mode operators alpha_a alpha_a^d - alpha_a^d alpha_a = -i e_j e_k (+1 on mode a empty, -1 full) go to +- the line blades of the three Fano lines through k = e7: %s; the line blades of the four other lines lie outside the image of C (x) Cl(0,6)'
    % ('; '.join('mode %d -> %s%s' % (a + 1, '+' if next(iter(x.values())) > 0 else '-', ' '.join(NAMES8[b] for b in range(8) if (next(iter(x)) >> b) & 1)) for a, x in enumerate(PMA)) if all(len(x) == 1 for x in PMA) else 'none'))
ES = []
for S in SUBS:
    ES.append(C16.prod(*[(add(ONE, PA[a], -1) if a in S else PA[a]) for a in range(3)]))
HM = [next(iter(C16.mul(I_, biv(j, k)))) for j, k in MAINPAIRS]; HS = {0}
for h in HM: HS |= {x ^ h for x in HS}
okE = all(eq(C16.mul(ES[i], ES[j]), ES[i] if i == j else {}) for i in range(8) for j in range(8)) and eq(lin(*[(1, e) for e in ES]), ONE)
okE &= all(e.get(0) == Fr(1, 8) for e in ES) and all(eq(C16.mul(ES[i], ST[j]), ST[j] if i == j else {}) for i in range(8) for j in range(8))
okE &= all(C16.sq(h) == 1 for h in HM) and len(HS) == 8 and not any(C16.sq(a) == 1 and all(C16.commute(a, h) for h in HM) for a in range(128) if a not in HS)
chk('bit', okE, 'fc.AX: the projectors alpha_a alpha_a^d (mode a empty) and their complements give 2^3 = 8 orthogonal idempotents of scalar part 1/8 (complex rank 1) with sum 1, and E_S s_T = delta_ST s_T: their joint eigenspaces in A nu are the eight states; the three labels i e_j e_k (square +1) with their products are a maximal commuting set of labels of square +1 of Cl(1,6): LNC-059\'s 2^w = 8 for M8(C)')
def axis_split(x):
    """the coefficients of a multivector of span(L) on the 16 axis idempotents: x = sum_k x_k p_k with x_k = chi_k(x)"""
    if any(m not in CHI[0] for m in x): return None
    return [sum(c * CHI[k][m] for m, c in x.items()) for k in range(16)]
def pairs_of(P):
    out = []
    for e in ES:
        xs = axis_split(phi(e, P))
        out.append(tuple(k for k in range(16) if xs[k] == 1) if xs is not None and all(v in (0, 1) for v in xs) else None)
    return out
PAIRS_AX = pairs_of(PHI)
JJ = blade(JM[0], JM[1]); JJi = scal(JJ, -1)
okX = all(p is not None and len(p) == 2 for p in PAIRS_AX) and all(eq(phi(e), add(PAX[p[0]], PAX[p[1]])) for e, p in zip(ES, PAIRS_AX))
okX &= all(eq(C08.mul(C08.mul(JJ, PAX[p[0]]), JJi), PAX[p[1]]) for p in PAIRS_AX) if okX else False
WANT_AX = [(8, 11), (4, 7), (5, 6), (1, 2), (9, 10), (13, 14), (12, 15), (0, 3)]
chk('bit', okX and PAIRS_AX == WANT_AX, 'fc.AX: each of the eight idempotents goes to the sum p_m + p_m\' of two axis idempotents, the two axes exchanged by the image of i: nu -> %s, alpha_a^d nu -> %s, alpha_a^d alpha_b^d nu -> %s, the top state -> %s: the two su(3) singlets on FUR-001\'s O1 = {0, 3} (1, e7) and on {8, 11} (R, e7R), the N = 1 states on O2, the N = 2 states on C = {9, 10} and H = {12 .. 15} of O\''
    % (PAIRS_AX[0], PAIRS_AX[1:4], PAIRS_AX[4:7], PAIRS_AX[7]))
E0P = phi(blade(1)); SPL = [scal(add(ONE, E0P, s), Fr(1, 2)) for s in (1, -1)]
okO = eq(E0P, blade(255, EPS0)) and eq(SPL[0], lin(*[(1, PAX[k]) for k in range(8)])) and eq(SPL[1], lin(*[(1, PAX[k]) for k in range(8, 16)]))
okO &= all((max(p) < 8) == (len(S) % 2 == 1) for p, S in zip(PAIRS_AX, SUBS)) if okX else False
chk('bit', okO, 'fc.AX: e0 = -i omega goes to the volume element g1 .. g8, so the splitting idempotents (1 + e0)/2 = (1 - i omega)/2 and (1 - e0)/2 = (1 + i omega)/2 go to the sums of the axis idempotents of O (0 .. 7) and of O\' (8 .. 15): the doubling O + O\' of FUR-001 is Furey\'s splitting by the eigenvalues of omega, with the N = 1 states and the top state (omega = +i) in O, nu and the N = 2 states (omega = -i) in O\'')
PHIm = phi_tab(-1); PAIRSm = pairs_of(PHIm)
okSw = PHIm[TOP] == (132, -JM[1]) and PAIRSm == WANT_AX[::-1]                # each state goes where the state with the complementary modes went
chk('bit', okSw, 'fc.AX: the embedding with the other sign, e0 -> -g1 .. g8 (i -> %sg_k g8), exchanges the two copies: nu -> %s, the top state -> %s; which singlet pair holds nu is the sign of the image of i, a convention of the embedding (as omega is an input, INP-088)' % ('' if -JM[1] == 1 else '-', PAIRSm[0], PAIRSm[7]))
G8 = blade(128); G8i = scal(G8, -1); PNU = phi(NU)
okI2 = eq(C08.mul(G8, JJ), scal(C08.mul(JJ, G8), -1)) and eq(C08.mul(C08.mul(G8, PNU), G8i), phi(conj16(NU)))
rA = rank_mv([phi(x) for x in IDL]); rB = rank_mv([C08.mul(phi(blade(a)), C08.mul(G8, PNU)) for a in range(128)])
rAll = rank_mv([C08.mul(blade(m), PNU) for m in range(256)]); rSum = rank_mv([phi(x) for x in IDL] + [C08.mul(phi(blade(a)), C08.mul(G8, PNU)) for a in range(128)])
chk('bit', okI2 and (rA, rB, rAll, rSum) == (16, 16, 32, 32), 'fc.AX: the second ideal: g8 anticommutes with the image of i and g8 nu g8^-1 = conj(nu); Cl(0,8) = C (x) Cl(0,6) + (C (x) Cl(0,6)) g8, and the left ideal Cl(0,8) nu (real dimension %d) is the image of A nu (%d) plus (C (x) Cl(0,6)) g8 nu = (C (x) Cl(0,6)) conj(nu) g8 (%d), together %d: the two more generators add the conjugate ideal' % (rAll, rA, rB, rSum))
note('(%.1f s)' % (time.time() - t))
t = time.time()
def zco(y):
    c = CO(y)
    return None if c is None else [(c[T], c[8 + T]) for T in range(8)]    # complex coefficients on the eight states
def ccommutant_n(mats, n):
    """the real dimension of {X : [M, X] = 0} for n x n Gaussian-rational matrices M (X = A + iB, 2 n^2 real unknowns)"""
    N2 = n * n; rows = []
    for l in mats:
        for i in range(n):
            for j in range(n):
                re = [Fr(0)] * (2 * N2); im = [Fr(0)] * (2 * N2)
                for k in range(n):
                    P1, Q1, P2, Q2 = l[i][k][0], l[i][k][1], l[k][j][0], l[k][j][1]
                    re[n * k + j] += P1; re[N2 + n * k + j] -= Q1; re[n * i + k] -= P2; re[N2 + n * i + k] += Q2
                    im[N2 + n * k + j] += P1; im[n * k + j] += Q1; im[n * i + k] -= Q2; im[N2 + n * i + k] -= P2
                rows += [re, im]
    return len(nullspace_frac(rows, 2 * N2))
ODD, EVEN = [1, 2, 3, 7], [0, 4, 5, 6]                                     # the indices in SUBS of the states of odd and even N
BZ = []
for X in BIV15:
    cols = [zco(C16.mul(X, s)) for s in ST]
    BZ.append(None if any(c is None for c in cols) else [[cols[T][T2] for T in range(8)] for T2 in range(8)])
okPar = all(Z is not None for Z in BZ) and all(Z[T2][T] == CZ for Z in BZ for T in range(8) for T2 in range(8) if (T in ODD) != (T2 in ODD))
cO = ccommutant_n([[[Z[r][c] for c in ODD] for r in ODD] for Z in BZ], 4) if okPar else None
cE = ccommutant_n([[[Z[r][c] for c in EVEN] for r in EVEN] for Z in BZ], 4) if okPar else None
opt1 = okPar and any(Z[r][0] != CZ for Z in BZ for r in (4, 5, 6)); opt2 = okPar and any(Z[r][7] != CZ for Z in BZ for r in (1, 2, 3))
chk('bit', okPar and (cO, cE) == (2, 2) and opt1 and opt2 and okWs, 'fc.AX: the 15 bivectors of so(6) change N by 0 or +-2: on A nu they keep the four states of odd N and the four of even N, each an irreducible complex 4 (commutant of real dimension %s and %s: C), with omega = +i on the odd four and -i on the even four; neither of the brief\'s groupings is invariant: a bivector takes nu to N = 2 and the top state to N = 1' % (cO, cE))
L06 = Lab(lambda a, b: C06.S[a][b], 6); I6 = Ideal(L06, comm_labels(L06, tries=20))
def mmf(A, B): return [[sum(A[i][k] * B[k][j] for k in range(len(B)) if A[i][k] and B[k][j]) for j in range(len(B[0]))] for i in range(len(A))]
def mvf(A, v): return [sum(A[i][k] * v[k] for k in range(len(v)) if A[i][k] and v[k]) for i in range(len(A))]
W6m = mv_mat(I6, blade(63)); I8f = [[Fr(int(i == j)) for j in range(8)] for i in range(8)]
def biv6(j, k): return C06.mul(blade(1 << (j - 1)), blade(1 << (k - 1)))  # e_j e_k of the copy, Furey's labels at bits j - 1
MP6 = [[[-x for x in row] for row in mmf(W6m, mv_mat(I6, biv6(j, k)))] for j, k in MAINPAIRS]   # M'_a = -omega6 e_j e_k on the ideal
PATS = []
for w in itertools.product((1, -1), repeat=3):
    Ew = I8f
    for a in range(3): Ew = mmf(Ew, [[(I8f[i][j] + w[a] * MP6[a][i][j]) / 2 for j in range(8)] for i in range(8)])
    rk_w = rank_frac(Ew)
    if rk_w: PATS.append((w, rk_w, next([Ew[i][c] for i in range(8)] for c in range(8) if any(Ew[i][c] for i in range(8)))))
B6 = [v for w, r, v in PATS for v in (v, mvf(W6m, v))]; B6inv = inv_frac([[B6[c][i] for c in range(len(B6))] for i in range(8)]) if len(B6) == 8 else None
def sidx(w): return SUBS.index(tuple(a for a in range(3) if w[a] == -1))
rowsT = []
if B6inv is not None and CO.ok:
    SP = [ST[sidx(w)] for w, r, v in PATS]; ISP = [C16.mul(I_, s) for s in SP]
    for (j, k), X6m in [((j, k), mv_mat(I6, biv6(j, k))) for j in range(1, 7) for k in range(j + 1, 7)]:
        X = biv(j, k)
        for p in range(4):
            for half in (0, 1):                                    # b = v_p (half 0) or omega6 v_p (half 1)
                r = mvf(B6inv, mvf(X6m, B6[2 * p + half]))
                for q in range(8):
                    pq, hq = divmod(q, 2)
                    lhs = lin((r[2 * pq], SP[pq] if hq == 0 else ISP[pq]), (r[2 * pq + 1], ISP[pq] if hq == 0 else scal(SP[pq], -1)))
                    tb = {(0, 0): SP[p], (0, 1): ISP[p], (1, 0): ISP[p], (1, 1): scal(SP[p], -1)}[(half, hq)] if pq == p else {}
                    cq = CO(add(lhs, C16.mul(X, tb), -1)); rowsT.append(cq)
okT = bool(rowsT) and all(c is not None for c in rowsT)
NT = nullspace_frac([[rowsT[8 * e + q][tt] for q in range(8)] for e in range(len(rowsT) // 8) for tt in range(16)], 8) if okT else []
imgT = sorted(sidx(w) for w, r, v in PATS)
okMP = all(mmf(MP6[a], MP6[b]) == mmf(MP6[b], MP6[a]) for a in range(3) for b in range(3)) and all(mmf(M_, M_) == I8f for M_ in MP6)
chk('bit', okT and okMP and [r for w, r, v in PATS] == [2, 2, 2, 2] and all(w[0] * w[1] * w[2] == -1 for w, r, v in PATS) and len(NT) == 2 and imgT == sorted(ODD),
    'fc.AX: the 4 = 3 + 1 of FUR-012: on the ideal of Cl(0,6) (fb.OCT\'s O, with omega6 = L_e7 as complex structure) the commuting -omega6 e_j e_k have the four sign patterns of product -1, those of the odd states; the C-linear maps from it to A nu that commute with so(6) form a real plane (%d), all with image the N = 1 states and the top state: the 4 (su(3): 3 + 1) is alpha_a^d nu with alpha1^d alpha2^d alpha3^d nu, and nu with the N = 2 states is the 4bar' % len(NT))
note('(%.1f s)' % (time.time() - t))
t = time.time()
PHM = [EPS0 * mblade(255)] + [F2M[j][1] * GM[F2M[j][0] - 1] for j in range(1, 7)]   # the images of e0 .. e6 on V, as 16 x 16 matrices
Jm = prodm(PHM); Lk16 = np.rint(OM.diag2(OM.Lmat(OM.E[3]))).astype(np.int64)
okV = frel_ok(PHM, E16) and np.array_equal(Jm, JM[1] * (GM[2] @ GM[7])) and np.array_equal(prodm(PHM[1:]), Lk16)
Mm = [-Jm @ PHM[j] @ PHM[k] for j, k in FUREY]; I16m = np.eye(16, dtype=np.int64)
okV &= all(np.array_equal(M_, np.diag(np.diag(M_))) for M_ in Mm)
PRS = []
for S in SUBS:
    E_ = prodm([(I16m - Mm[a]) if a in S else (I16m + Mm[a]) for a in range(3)]) // 8
    PRS.append(tuple(int(k) for k in np.flatnonzero(np.diag(E_))))
Om8 = mblade(255); okV &= np.array_equal(Om8, np.diag([1] * 8 + [-1] * 8))
LR8 = np.rint(OM.Lmat(OM.E[3]) @ OM.Rmat(OM.E[3])).astype(np.int64); PO1 = (np.eye(8, dtype=np.int64) - LR8) // 2   # FUR-001's P_O1 = (1 - L_e7 R_e7)/2
okV &= np.array_equal(PO1, np.diag(np.diag(PO1))) and np.flatnonzero(np.diag(PO1)).tolist() == [0, 3]
chk('std', okV and all(len(p) == 2 for p in PRS), 'fc.AX: numpy on V = O + O\' (the 16 x 16 matrices of the model, no label): the images of e0 .. e6 satisfy the relations of Cl(1,6), the volume element is %sg_k g8 and e1 .. e6 goes to FUR-001\'s omega = L_e7 on both copies; the three mode operators are diagonal, and the eight joint projectors are diagonal with two ones each: %s; g1 .. g8 = diag(1, -1) (O, O\'); FUR-001\'s P_O1 = (1 - L_e7 R_e7)/2 is the diagonal projector on the axes {0, 3} (the blocks C = {9, 10}, H = {12 .. 15}, R = {8}, e7R = {11} of O\' as furey_bit_route.py defines them)' % ('' if JM[1] == 1 else '-', PRS))
chk('bit==std', PRS == PAIRS_AX and all(CHI[k][255] == (1 if k < 8 else -1) for k in range(16)), 'fc.AX: the eight pairs of axes agree on the labels and on the matrices, and the volume element has the sign +1 on O and -1 on O\' in both')
ev7, V7 = np.linalg.eig(LO[7].astype(complex)); Vp, _ = np.linalg.qr(V7[:, np.isclose(ev7, 1j)]); Vn, _ = np.linalg.qr(V7[:, np.isclose(ev7, -1j)])
specN = [sorted(int(round(x)) for x in np.linalg.eigvals(V_.conj().T @ NNc @ V_).real) for V_ in (Vp, Vn)]
def ccomm_np(Bs):
    A_ = np.vstack([np.kron(B_, np.eye(4)) - np.kron(np.eye(4), B_.T) for B_ in Bs]); return 16 - int(np.linalg.matrix_rank(A_, tol=1e-9))
B6np = [LO[u] @ LO[v] for u in range(1, 7) for v in range(u + 1, 7)]
cnp4 = [ccomm_np([V_.conj().T @ B_ @ V_ for B_ in B6np]) for V_ in (Vp, Vn)]
chk('std', specN == [[1, 1, 1, 3], [0, 2, 2, 2]] and cnp4 == [1, 1], 'fc.AX: numpy on C (x) O: on the +i eigenspace of L_e7 (rank 4) N has the eigenvalues %s, on the -i eigenspace %s; the 15 L_u L_v act on each with complex commutant of dimension %s: two irreducible complex 4' % (specN[0], specN[1], cnp4))
chk('bit==std', (cO, cE) == (2, 2) and None not in nvals and specN[0] == sorted(nvals[T] for T in ODD) and specN[1] == sorted(nvals[T] for T in EVEN), 'fc.AX: the odd states (omega = +i) and the even states (omega = -i) carry the same N on the labels and on the matrices, each an irreducible 4')
note('not computed: the second generation, the Lorentz side C (x) H, Furey\'s symmetry breaking and hypercharge, the roadmap\'s five modes (R1-R5 stand), any statement that the charges are nature\'s')
note('(%.1f s)' % (time.time() - t))
finish()
