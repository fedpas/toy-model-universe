#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""shifted_dirac.py -- shifted Dirac equations on the plane waves of the coupling step, exactly on the shell: a translation psi(x) -> psi(x - a),
the operator exp(-tau D) of Atiyah and Moore ("A shifted view of fundamental physics"), its variants, a constant potential, and the formal
series behind their shifted Ricci operators.

Conventions of coupling_selfcheck.py, imported and used as they stand: blades are bit masks, bit 0 = time (square +1), the other bits square -1;
the product is its bmul; J = gamma_2 gamma_1 (mask 6, sign -1); nabla = sum_mu gamma_mu d_mu; the Dirac-Hestenes equation of the coupling step
is nabla(psi) J - e A psi - m psi gamma_0 = 0.  A plane wave of sector s (s = -1 or +1) is P exp(s J k.x), k.x = sum_mu k_mu x_mu, P a constant
even multivector (the phase on the right); the field space of sector s is the 2^(n-1) real dimensions of P.  On it: nabla acts as P -> s khat P J
(khat = sum_mu k_mu gamma_mu, khat^2 = Q(k) = k_0^2 - sum k_i^2); a translation by a acts as P -> P exp(-s J theta), theta = k.a, entering only
through (cos theta, sin theta), taken exact (quarter turns, rational points of the circle); the even operator bD(P) = (nabla P + e A P J) gamma_0
(the image of the column operator D = gamma^mu d_mu + i e A on even psi, recalled from Hestenes) squares to -Q(s k + e A).  With E^2 = Q > 0 and
(c, s') = (cos E tau, sin E tau), exp(-tau bD) = c - (s'/E) bD and cosh = c, sinh = (s'/E) bD (the power series of cos and sin, recalled); for a
null frequency bD^2 = 0 and exp(-tau bD) = 1 - tau bD.  Every equation below is then an exact linear map on P, and a kernel is a space of
solutions valid for all x.

Statements.
(1) [shd·OP] bD^2 = -Q(s k + e A) on every sector (n = 3, 4, 5; timelike, spacelike, null k; A = 0 and A != 0); for null k, bD != 0, bD^2 = 0.
(2) [shd·ORD] The ordinary equation has a kernel of 2^(n-2) real dimensions per sector exactly on Q(k) = m^2 (half of psi), none off it.
(3) [shd·RET] Retarded alone, a fixed shift of the whole mass term, nabla psi J = m psi(x - a) gamma_0: solutions only for theta = k.a in (pi/2)Z: on
    Q = m^2 for theta in pi Z (theta = 0: the ordinary solutions; theta = pi: those of mass -m, the other half), on Q = -m^2 (spacelike k)
    for theta in pi/2 + pi Z, none at the rational points of the circle.  A time shift by one Compton period 2 pi/m keeps the rest solutions
    and loses the moving wave k = (5, 3, 0, 0), m = 4 (theta = 5 pi/2): a fixed shift vector is frame bound.
(4) [shd·SYM] Advanced plus retarded, (m/2)(psi(x - a) + psi(x + a)): the factor is cos theta, the shell Q = m^2 cos^2 theta is a continuum (kernel
    2^(n-2) per sector at rational points of the circle), where the retarded term alone has no solution.
(5) [shd·OWN, shd·COV] The paper's operator: on the ordinary solutions of mass E (both sectors) exp(-tau bD) is the right multiplication by exp(J E tau); in sector
    -1 this is the translation by tau along v = k/E (the wave's own time direction), in sector +1 the translation by -tau (an advance); the current
    psi gamma_0 psi~ of these solutions is parallel to khat with positive time component.  The covariant shift of the whole mass term,
    i D psi = m exp(-tau D) psi, keeps the solutions of mass m exactly when m tau is in pi Z (whole Compton periods: the ordinary half; odd half
    periods: the other half), in every frame.
(6) [shd·QNT, shd·NUL] The paper's equation (i hbar D - m c + i k exp(-tau D)) psi = 0 (hbar = c = 1; on even psi: bD psi J - m psi + kappa (exp(-tau bD) psi) J):
    plane waves exactly when cos(E tau) = 0 and E = m + kappa sin(E tau) (E tau = (n + 1/2) pi, E = m + (-1)^n kappa, tau = (2n+1) lambda_C/4,
    lambda_C = 2 pi/E), the kernel being the ordinary solutions of mass E; none at tau = 0, none at a whole or half Compton period, none at
    rational points of the circle; for kappa > m a second branch E = kappa sin(E tau) - m on the other half; n -> n - 1 is kappa -> -kappa;
    for a null frequency no solution unless m = kappa = 0 (the massless solutions, which exp(-tau bD) fixes).  Checked at n = 3, 4, 5.
(7) [shd·VAR] Variants (paper's (2.3), uniform reading D_x = D + (kappa) f(tau D)): D_- = D - kappa exp(tau D) has the same plane waves as D_+;
    D_s (sinh): E = m - kappa sin(E tau) for every theta (no quantization), and with m = 0 the massless solutions; D_c read as
    D + kappa cosh(tau D): plane waves only at cos(E tau) = 0 with E = m (a quantization); D_c read as D + i kappa cosh(tau D):
    E = m + kappa cos(E tau) for every theta, none for m = 0 at a null frequency.
(8) [shd·GAU] A constant potential (m = 3, e = 1, k = (7, 4, 0, 0), A = 2 gamma_0; gauge k -> k + lambda, A -> A + lambda/e with lambda.a = pi/2): the
    ordinary coupled solutions are gauge invariant; the fixed shift is not (4 and 0 real dimensions); with the transport factor exp(-J e A.a)
    it is; the paper's coupled operator exp(-tau bD_A) depends on k - e A only (same kernels in both gauges).
(9) [shd·BIL] At the paper's quantized shift (E tau = pi/2) the shifted solution is psi J: the current and psi gamma_3 psi~ are unchanged, psi gamma_1 psi~
    and psi gamma_2 psi~ reverse; at a general theta they turn by -2 theta.
(10) [shd·SER] Formal series in one commuting D (orders <= 12, two rational (tau, kappa)): D_+ D_- = D^2 - 2 kappa D sinh(tau D) - kappa^2;
    the even part of D_+^2 is D^2 - 2 kappa D sinh(tau D) + kappa^2 cosh(2 tau D); D_s^2 = D^2 + 2 kappa D sinh(tau D) + kappa^2 sinh^2(tau D);
    their constant terms -kappa^2, kappa^2, 0, so that with D^2 + nabla^2 = Ricci (the paper's (3.2), recalled) the leading equations are
    Ricci = kappa^2, -kappa^2, 0.
[bit]  Exact Fractions on the labels: products by bmul, kernels and spans by exact elimination, n = 3, 4, 5 for (1), (2), (6); n = 4 elsewhere.
[std]  numpy and scipy, never the labels: complex 4 x 4 Dirac matrices (Dirac representation, Gamma_0^2 = 1, Gamma_k^2 = -1), plane waves
       u exp(s i k.x), D -> s i K, the operator exponentials by scipy.linalg.expm at tau = theta/E in floats, kernels by SVD (tolerance 1e-8);
       the even algebra embedded as products of Gamma matrices for (9); numpy evaluation of the closed forms for (10).
[ctl]  Each wrong version is also a --fault option that puts it into the main lines (the run must then end with FAILS):
       NOI      the shift term without the factor i (J);           SINSIGN  exp(-tau bD) = c + (s'/E) bD;
       FIXEDA   exp(-tau D) replaced by the fixed time shift a = tau gamma_0;   RETONLY  the advanced term dropped;
       NOW      the transport factor dropped;                       SHIFTSIGN  psi(x + a) in place of psi(x - a);
       KGSIGN   D_+ D_- with + kappa^2;                             KEEPODD  the compression keeps the odd powers;
       NULLONE  exp(-tau bD) = 1 at a null frequency.
Scope. Plane waves of one frequency with constant amplitude, and a constant potential; n = 3, 4, 5 on the labels, n = 4 with Dirac matrices; the
       shift enters through exact (cos, sin) pairs, the shift vector itself is not built.  The shifted Ricci operators are not built: only the
       formal series in one commuting variable.  No engine object is built: the faults of the gravity engine do not reach this script.
Run:   python3 shifted_dirac.py [--fault NOI|SINSIGN|FIXEDA|RETONLY|NOW|SHIFTSIGN|KGSIGN|KEEPODD|NULLONE]
       (from the package root as selfcheck/proofs/shifted_dirac.py; also from its own folder, and under -I -B)"""
import os, sys, time
from fractions import Fraction as Fr
from math import factorial
sys.dont_write_bytecode = True
import numpy as np
from scipy.linalg import expm

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
if not os.path.isfile(os.path.join(_selfcheck, 'coupling_selfcheck.py')):
    raise SystemExit('coupling_selfcheck.py not found in ' + _selfcheck + ': this file belongs in selfcheck/proofs/ of the package')
if _selfcheck not in sys.path: sys.path.insert(0, _selfcheck)
import coupling_selfcheck as cs

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond); COUNT[0 if cond else 1] += 1
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'SHIFTED-DIRAC'
FAULT_NAMES = ['NOI', 'SINSIGN', 'FIXEDA', 'RETONLY', 'NOW', 'SHIFTSIGN', 'KGSIGN', 'KEEPODD', 'NULLONE']
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
def fault(name): return FAULT == name

# ------------------------------------------------------------------------------------------------ the labels: constant multivectors
def pc(x): return bin(x).count('1')
class Alg:
    def __init__(self, n):
        self.n = n; self.sq = cs.sqs(n)
        self.EV = [m for m in range(1 << n) if pc(m) % 2 == 0]
        Jm, Js = cs.bmul(1 << 2, 1 << 1, self.sq); self.J = {Jm: Fr(Js)}         # J = gamma_2 gamma_1, as in coupling_selfcheck.py
        self.g = [{1 << mu: Fr(1)} for mu in range(n)]
        assert self.mul(self.J, self.J) == {0: Fr(-1)} and self.mul(self.J, self.g[0]) == self.mul(self.g[0], self.J)
    def mul(self, a, b):
        out = {}
        for x, cx in a.items():
            for y, cy in b.items():
                m, s = cs.bmul(x, y, self.sq); v = out.get(m, 0) + s * cx * cy
                if v: out[m] = v
                else: out.pop(m, None)
        return out
    def lin(self, *terms):                                                      # sum of coefficient * multivector
        out = {}
        for c, a in terms:
            for m, v in a.items():
                w = out.get(m, 0) + Fr(c) * v
                if w: out[m] = w
                else: out.pop(m, None)
        return out
    def vec(self, k): return {1 << mu: Fr(k[mu]) for mu in range(self.n) if k[mu] != 0}
    def rev(self, a): return {m: cs.rsign(pc(m)) * v for m, v in a.items()}
    def rot(self, c, s): return self.lin((c, {0: Fr(1)}), (s, self.J))         # c + s J = exp(J theta)
def Q(k, A=None, e=0, sg=1):
    v = [sg * Fr(k[i]) + (e * Fr(A[i]) if A else 0) for i in range(len(k))]
    return v[0] ** 2 - sum(x * x for x in v[1:])

def rref_rank(cols, keys):
    M = [[c.get(r, Fr(0)) for c in cols] for r in keys]; rank = 0; piv = []
    ncol = len(cols)
    for j in range(ncol):
        p = next((i for i in range(rank, len(M)) if M[i][j] != 0), None)
        if p is None: continue
        M[rank], M[p] = M[p], M[rank]; inv = 1 / M[rank][j]; M[rank] = [x * inv for x in M[rank]]
        for i in range(len(M)):
            if i != rank and M[i][j] != 0:
                f = M[i][j]; M[i] = [x - f * y for x, y in zip(M[i], M[rank])]
        piv.append(j); rank += 1
    return rank, piv, M
def kernel(alg, L):
    """solutions P (even) of L(P) = 0: a basis of multivectors"""
    cols = [L({S: Fr(1)}) for S in alg.EV]
    keys = sorted({m for c in cols for m in c})
    rank, piv, M = rref_rank(cols, keys)
    free = [j for j in range(len(cols)) if j not in piv]; basis = []
    for f in free:
        x = [Fr(0)] * len(cols); x[f] = Fr(1)
        for r, j in enumerate(piv): x[j] = -M[r][f]
        basis.append({alg.EV[j]: x[j] for j in range(len(cols)) if x[j] != 0})
    return basis
def span_rank(vecs):
    keys = sorted({m for v in vecs for m in v})
    return rref_rank(vecs, keys)[0] if vecs else 0
def same_span(U, V): return len(U) == len(V) and span_rank(U) == len(U) and span_rank(U + V) == len(U)

# ------------------------------------------------------------------------------------------------ the operators on one sector
def bD(alg, P, k, sg, A=None, e=0):
    """(nabla P + e A P J) gamma_0 on the amplitude of sector sg: (sg khat + e A) P J gamma_0"""
    v = alg.lin((sg, alg.vec(k)), (e, alg.vec(A) if A else {}))
    return alg.mul(alg.mul(alg.mul(v, P), alg.J), alg.g[0])
def shift_factor(alg, sg, c, s):
    """translation by a (theta = k.a): P -> P exp(-sg J theta); SHIFTSIGN: psi(x + a)"""
    if fault('SHIFTSIGN'): sg = -sg
    return alg.rot(c, -sg * s)
class Expo:
    """exp(-+tau bD), cosh, sinh on one sector, closed form from (E, c, s) with E^2 = Q > 0, or from a rational tau when Q = 0"""
    def __init__(self, alg, k, sg, E=None, c=None, s=None, tau=None, A=None, e=0, sinsign_ok=True):
        self.alg, self.k, self.sg, self.A, self.e = alg, k, sg, A, e
        q = Q(k, A, e, sg)
        if E is not None:
            assert E > 0 and Fr(E) ** 2 == q and c * c + s * s == 1, 'closed form data off the shell'
            self.E, self.c, self.s, self.null = Fr(E), Fr(c), Fr(s), False
        else:
            assert q == 0 and tau is not None; self.tau, self.null = Fr(tau), True
        self.sinsign_ok = sinsign_ok
    def D(self, P): return bD(self.alg, P, self.k, self.sg, self.A, self.e)
    def minus(self, P):                                                         # exp(-tau bD) P
        a = self.alg
        if self.null:
            return dict(P) if fault('NULLONE') else a.lin((1, P), (-self.tau, self.D(P)))
        sgn = +1 if (fault('SINSIGN') and self.sinsign_ok) else -1
        return a.lin((self.c, P), (sgn * self.s / self.E, self.D(P)))
    def plus(self, P):                                                          # exp(+tau bD) P
        a = self.alg
        if self.null: return a.lin((1, P), (self.tau, self.D(P)))
        return a.lin((self.c, P), (self.s / self.E, self.D(P)))
    def cosh(self, P): return dict(P) if self.null else self.alg.lin((self.c, P))
    def sinh(self, P): return self.alg.lin((self.tau if self.null else self.s / self.E, self.D(P)))

def ordinary(alg, k, sg, m, A=None, e=0):
    """even form of the coupling step's equation: bD(P) J - m P (= (nabla psi J - e A psi - m psi gamma_0) gamma_0)"""
    return lambda P: alg.lin((1, alg.mul(bD(alg, P, k, sg, A, e), alg.J)), (-m, P))
def fixed_shift_eq(alg, k, sg, m, f, A=None, e=0):
    """nabla psi J - e A psi - m (psi(x - a) f-dressed) gamma_0, even form: bD(P) J - m P f"""
    return lambda P: alg.lin((1, alg.mul(bD(alg, P, k, sg, A, e), alg.J)), (-m, alg.mul(P, f)))
def paper_eq(alg, X, m, kap, variant='plus'):
    """bD psi J - m psi + [shift term]; X an Expo"""
    def L(P):
        base = alg.lin((1, alg.mul(X.D(P), alg.J)), (-m, P))
        if variant == 'plus':
            t = X.minus(P); term = t if fault('NOI') else alg.mul(t, alg.J)
            return alg.lin((1, base), (kap, term))
        if variant == 'minus': return alg.lin((1, base), (-kap, alg.mul(X.plus(P), alg.J)))
        if variant == 'sinh': return alg.lin((1, base), (kap, alg.mul(X.sinh(P), alg.J)))
        if variant == 'coshA': return alg.lin((1, base), (kap, alg.mul(X.cosh(P), alg.J)))
        if variant == 'coshB': return alg.lin((1, base), (-kap, X.cosh(P)))
        if variant == 'cov': return alg.lin((1, alg.mul(X.D(P), alg.J)), (-m, X.minus(P)))
        if variant == 'noi': return alg.lin((1, base), (kap, X.minus(P)))
        raise ValueError(variant)
    return L
def kdim(alg, L): return len(kernel(alg, L))

QT = {0: (Fr(1), Fr(0)), 1: (Fr(0), Fr(1)), 2: (Fr(-1), Fr(0)), 3: (Fr(0), Fr(-1))}         # quarter turns theta = j pi/2
R1 = (Fr(3, 5), Fr(4, 5)); R2 = (Fr(5, 13), Fr(12, 13))                                     # rational points of the circle
def tname(cs_):
    for j, v in QT.items():
        if v == cs_: return ['0', 'pi/2', 'pi', '3pi/2'][j]
    return 'theta with (cos, sin) = (%s, %s)' % cs_

# ------------------------------------------------------------------------------------------------ the standard route: Dirac matrices
S1 = np.array([[0, 1], [1, 0]], complex); S2 = np.array([[0, -1j], [1j, 0]]); S3 = np.array([[1, 0], [0, -1]], complex); I2 = np.eye(2)
GM = [np.block([[I2, 0 * I2], [0 * I2, -I2]])] + [np.block([[0 * I2, s_], [-s_, 0 * I2]]) for s_ in (S1, S2, S3)]
I4 = np.eye(4)
def Kmat(k, sg, A=None, e=0):
    """i D_A on the column wave u exp(sg i k.x): D -> sg i Pk + i e A, so i D_A -> -(sg Pk + e A)"""
    v = [sg * float(k[i]) + (e * float(A[i]) if A else 0.0) for i in range(4)]
    return -sum(v[i] * GM[i] for i in range(4))
def cker(M, tol=1e-8):
    sv = np.linalg.svd(M, compute_uv=False); return 4 - int(np.sum(sv > tol * max(1.0, sv[0])))
def null_basis(M, tol=1e-8):
    u, sv, vh = np.linalg.svd(M); r = int(np.sum(sv > tol * max(1.0, sv[0]))); return vh[r:].conj().T
def cspan_eq(B1, B2, tol=1e-8):
    if B1.shape[1] != B2.shape[1]: return False
    if B1.shape[1] == 0: return True
    return np.linalg.matrix_rank(np.hstack([B1, B2]), tol=tol) == B1.shape[1]
def ang(c, s): return float(np.arctan2(float(s), float(c)))
def std_phase(sg, c, s):
    """translation factor on u exp(sg i k.x) for theta = k.a: exp(-sg i theta); SHIFTSIGN: psi(x + a)"""
    th = ang(c, s); sg2 = -sg if fault('SHIFTSIGN') else sg
    return np.exp(-sg2 * 1j * th)
def std_expm(K, E, c, s, null_tau=None):
    """exp(-tau D) with D = -i K: expm(i tau K), tau = theta/E with theta the angle of (c, s), or the rational tau at a null frequency"""
    if null_tau is not None: return I4.copy() if fault('NULLONE') else expm(1j * float(null_tau) * K)
    tau = (ang(c, s) % (2 * np.pi)) / float(E)
    if fault('SINSIGN'): return np.cos(float(E) * tau) * I4 - 1j * np.sin(float(E) * tau) / float(E) * K
    return expm(1j * tau * K)
def std_paper(K, m, kap, Ex, variant='plus'):
    """the paper's column equations: i D - m + i kappa f(tau D), with Ex = expm(i tau K) = exp(-tau D)"""
    Exi = np.linalg.inv(Ex)                                                      # exp(+tau D)
    if variant == 'plus':
        return K - m * I4 + (kap * Ex if fault('NOI') else 1j * kap * Ex)
    if variant == 'minus': return K - m * I4 - 1j * kap * Exi
    if variant == 'sinh': return K - m * I4 + 1j * kap * (Exi - Ex) / 2
    if variant == 'coshA': return K - m * I4 + 1j * kap * (Exi + Ex) / 2
    if variant == 'coshB': return K - m * I4 - kap * (Exi + Ex) / 2
    if variant == 'cov': return K - m * Ex
    if variant == 'noi': return K - m * I4 + kap * Ex
    raise ValueError(variant)

T0 = time.time()
A4 = Alg(4)
# ================================================================================================ (1) the operator bD and its square
head('(1) [shd·OP] bD^2 = -Q(s k + e A) on each sector; null frequencies (n = 3, 4, 5)')
for n in (3, 4, 5):
    al = A4 if n == 4 else Alg(n)
    ks = {3: [(5, 4, 0), (2, 3, 1), (1, 1, 0), (5, 3, 4)], 4: [(5, 4, 0, 0), (7, 2, 4, 2), (4, 5, 0, 0), (1, 1, 0, 0), (5, 3, 4, 0), (3, -1, 2, 5)],
          5: [(7, 2, 4, 2, 0), (2, 1, 3, 0, 1), (3, 1, 2, 2, 0)]}[n]
    Avs = [None, tuple([2] + [0] * (n - 1)), tuple([1, -1] + [0] * (n - 3) + [3])]
    ok = True; nnull = 0
    for k in ks:
        for Av in Avs:
            for sg in (-1, 1):
                for S in al.EV:
                    P = {S: Fr(1)}; DD = bD(al, bD(al, P, k, sg, Av, 1), k, sg, Av, 1)
                    ok &= DD == al.lin((-Q(k, Av, 1, sg), P))
        if Q(k) == 0:
            nnull += 1
            ok &= any(bD(al, {S: Fr(1)}, k, -1) for S in al.EV)
    chk('bit', ok, 'n = %d: bD^2 P = -Q(s k + e A) P for every even basis blade P, both sectors, %d frequencies (%d null: there bD != 0 and bD^2 = 0) and three potentials (0, 2 gamma_0, gamma_0 - gamma_1 + 3 gamma_%d)' % (n, len(ks), nnull, n - 1))
# rank of bD at a null frequency
kn = (5, 3, 4, 0)
rk = span_rank([bD(A4, {S: Fr(1)}, kn, -1) for S in A4.EV])
chk('bit', rk == 4, 'n = 4, null k = (5, 3, 4, 0): bD has rank %d on the 8 real dimensions of a sector, a nilpotent of order 2: exp(-tau bD) = 1 - tau bD exactly' % rk)
# std: the closed form against expm
errs = []
for k in [(5, 4, 0, 0), (7, 2, 4, 2), (13, 12, 0, 0)]:
    for sg in (-1, 1):
        K = Kmat(k, sg); E = float(np.sqrt(float(Q(k))))
        for tau in (0.3, 1.7, 2.9):
            cf = np.cos(E * tau) * I4 + 1j * np.sin(E * tau) / E * K
            errs.append(np.abs(expm(1j * tau * K) - cf).max())
for k in [(1, 1, 0, 0), (5, 3, 4, 0)]:
    K = Kmat(k, -1)
    for tau in (0.5, 2.0): errs.append(np.abs(expm(1j * tau * K) - (I4 + 1j * tau * K)).max())
chk('std', max(errs) < 1e-10, 'Dirac matrices: K = i D on u exp(s i k.x) squares to Q(k); scipy expm(i tau K) = cos(E tau) + i sin(E tau) K/E (E = sqrt Q, 3 timelike k, both sectors, 3 tau) and = 1 + i tau K at 2 null k; max deviation %.1e' % max(errs))
srk = 2 * int(np.linalg.matrix_rank(Kmat(kn, -1), tol=1e-9))
chk('bit==std', srk == rk, 'null k = (5,3,4,0): the real rank of K (twice its complex rank %d) equals the rank %d of bD; both closed forms rest on a square that is a scalar (bD^2 = -E^2, K^2 = E^2)' % (srk // 2, rk))

# ================================================================================================ (2) the ordinary equation
head('(2) [shd·ORD] the ordinary equation of the coupling step on plane waves: half of psi on the shell')
m = 3
shell = [(3, 0, 0, 0), (5, 4, 0, 0), (-3, 0, 0, 0), (7, 2, 6, 0)]; off = [(4, 0, 0, 0), (5, 3, 0, 0), (0, 3, 0, 0)]
dims = {(k, sg): kdim(A4, ordinary(A4, k, sg, m)) for k in shell + off for sg in (-1, 1)}
chk('bit', all(dims[(k, sg)] == 4 for k in shell for sg in (-1, 1)) and all(dims[(k, sg)] == 0 for k in off for sg in (-1, 1)),
    'n = 4, m = 3: nabla psi J = m psi gamma_0 has a kernel of 4 real dimensions per sector at k = (3,0,0,0), (5,4,0,0), (-3,0,0,0), (7,2,6,0) (Q = 9) and none at (4,0,0,0), (5,3,0,0), (0,3,0,0)')
sdims = {(k, sg): 2 * cker(Kmat(k, sg) - m * I4) for k in shell + off for sg in (-1, 1)}
chk('std', all(sdims[(k, sg)] == 4 for k in shell for sg in (-1, 1)) and all(sdims[(k, sg)] == 0 for k in off for sg in (-1, 1)), 'Dirac matrices: (i D - m) u exp(s i k.x) = 0 has 2 complex = 4 real dimensions on the shell, 0 off it')
chk('bit==std', dims == sdims, 'the 14 kernel dimensions agree')
for n, kk in ((3, [(5, 4, 0), (3, 0, 0)]), (5, [(3, 0, 0, 0, 0), (7, 2, 6, 0, 0), (5, 2, 2, 2, 2)])):
    al = Alg(n); d = [kdim(al, ordinary(al, k, sg, 3 if Q(k) == 9 else 5)) for k in kk for sg in (-1, 1)]
    chk('bit', all(x == 2 ** (n - 2) for x in d), 'n = %d: the ordinary kernel per sector is %s = 2^(n-2) on the shell (k = %s)' % (n, d, kk))

# ================================================================================================ (3) retarded alone, fixed shift
head('(3) [shd·RET] retarded alone: nabla psi J = m psi(x - a) gamma_0, a fixed shift of the whole mass term (theta = k.a)')
m = 3
tl = [(3, 0, 0, 0), (5, 4, 0, 0), (-3, 0, 0, 0)]; sl = [(0, 3, 0, 0), (4, 5, 0, 0), (4, 4, 3, 0)]
thetas = [QT[0], QT[1], QT[2], QT[3], R1, R2]
res = {}; sres = {}
for th in thetas:
    for k in tl + sl:
        for sg in (-1, 1):
            res[(th, k, sg)] = kdim(A4, fixed_shift_eq(A4, k, sg, m, shift_factor(A4, sg, *th)))
            sres[(th, k, sg)] = 2 * cker(Kmat(k, sg) - m * std_phase(sg, *th) * I4)
def want3(th, k):
    if th in (QT[0], QT[2]): return 4 if Q(k) == m * m else 0
    if th in (QT[1], QT[3]): return 4 if Q(k) == -m * m else 0
    return 0
chk('bit', all(res[(th, k, sg)] == want3(th, k) for th in thetas for k in tl + sl for sg in (-1, 1)),
    'n = 4, m = 3: kernel 4 per sector on Q = 9 for theta = 0, pi; on Q = -9 (spacelike k) for theta = pi/2, 3pi/2; 0 for (3/5, 4/5), (5/13, 12/13) on both shells (72 cases)')
chk('std', all(sres[(th, k, sg)] == want3(th, k) for th in thetas for k in tl + sl for sg in (-1, 1)), 'Dirac matrices: (i D - m T_a) u exp(s i k.x) = 0 gives the same pattern')
chk('bit==std', res == sres, 'the 72 kernel dimensions agree')
k = (5, 4, 0, 0)
for sg in (-1, 1):
    K0 = kernel(A4, fixed_shift_eq(A4, k, sg, m, shift_factor(A4, sg, *QT[0])))
    Kpi = kernel(A4, fixed_shift_eq(A4, k, sg, m, shift_factor(A4, sg, *QT[2])))
    chk('bit', same_span(K0, kernel(A4, ordinary(A4, k, sg, m))) and same_span(Kpi, kernel(A4, ordinary(A4, k, sg, -m))) and span_rank(K0 + Kpi) == 8,
        'sector %+d, k = (5,4,0,0): at theta = 0 (or 2 pi) the solutions are those of the ordinary equation; at theta = pi those of mass -m; the two halves span all 8 dimensions' % sg)
# the Compton period: rest and moving waves, fixed time shift a = tau gamma_0, theta = k_0 tau
m = 4
rest, mov = (4, 0, 0, 0), (5, 3, 0, 0)                                        # both on Q = 16
th_rest = {'2pi/m': QT[0], 'pi/m': QT[2], 'pi/(2m)': QT[1]}                     # theta = m tau for the rest wave
th_mov = {'2pi/m': QT[1]}                                                        # theta = k_0 tau = 5 pi/2 for k_0 = 5, tau = 2 pi/4
r = {name: kdim(A4, fixed_shift_eq(A4, rest, -1, m, shift_factor(A4, -1, *th))) for name, th in th_rest.items()}
rm = kdim(A4, fixed_shift_eq(A4, mov, -1, m, shift_factor(A4, -1, *th_mov['2pi/m'])))
chk('bit', r == {'2pi/m': 4, 'pi/m': 4, 'pi/(2m)': 0} and rm == 0,
    'm = 4, fixed time shift a = tau gamma_0: the rest wave keeps 4 dimensions at tau = 2 pi/m (one Compton period) and at tau = pi/m (the other half), 0 at pi/(2m); the moving wave k = (5,3,0,0) on the same shell has 0 at tau = 2 pi/m (theta = 5 pi/2)')
sr = {name: 2 * cker(Kmat(rest, -1) - m * std_phase(-1, *th) * I4) for name, th in th_rest.items()}
srm = 2 * cker(Kmat(mov, -1) - m * std_phase(-1, *th_mov['2pi/m']) * I4)
chk('bit==std', sr == r and srm == rm, 'Dirac matrices give the same four dimensions (%s, moving %d)' % (sr, srm))

# ================================================================================================ (4) advanced plus retarded
head('(4) [shd·SYM] advanced plus retarded: nabla psi J = (m/2)(psi(x - a) + psi(x + a)) gamma_0')
cases4 = [(5, R1, [(3, 0, 0, 0), (5, 4, 0, 0)]), (13, R2, [(5, 0, 0, 0), (13, 12, 0, 0), (-5, 0, 0, 0)])]
ok = True; okr = True; okstd = True; agree = True
for m_, th, ks in cases4:
    for k in ks:
        assert Q(k) == (m_ * th[0]) ** 2
        for sg in (-1, 1):
            f_sym = A4.lin((Fr(1, 2), shift_factor(A4, sg, *th)), (0 if fault('RETONLY') else Fr(1, 2), shift_factor(A4, -sg, *th)))
            d = kdim(A4, fixed_shift_eq(A4, k, sg, m_, f_sym)); ok &= d == 4
            dr = kdim(A4, fixed_shift_eq(A4, k, sg, m_, shift_factor(A4, sg, *th))); okr &= dr == 0
            ph = 0.5 * std_phase(sg, *th) + (0 if fault('RETONLY') else 0.5) * std_phase(-sg, *th)
            sd = 2 * cker(Kmat(k, sg) - m_ * ph * I4); okstd &= sd == 4; agree &= sd == d
chk('bit', ok, 'n = 4: kernel 4 per sector on the shell Q = m^2 cos^2 theta: m = 5 with (cos, sin) = (3/5, 4/5) at k = (3,0,0,0), (5,4,0,0); m = 13 with (5/13, 12/13) at k = (5,0,0,0), (13,12,0,0), (-5,0,0,0): the factor is cos theta, a real number')
chk('ctl', okr, 'the retarded term alone at the same points has no solution (0 dimensions): the J part sin theta of the factor is what removes the shell')
chk('std', okstd, 'Dirac matrices: (i D - (m/2)(T_a + T_-a)) u = 0 has 4 real dimensions at the same 10 points')
chk('bit==std', agree, 'the 10 dimensions agree')

# ================================================================================================ (5) exp(-tau bD) on the solutions: the wave's own time direction
head('(5) [shd·OWN, shd·COV] exp(-tau D) on the ordinary solutions: the translation by tau along the wave, a retard in one sector and an advance in the other')
ok_dir = True; ok_cur = True; ok_std = True; phase_cmp = []
for E, k in ((5, (5, 0, 0, 0)), (5, (13, 12, 0, 0)), (5, (7, 2, 4, 2)), (3, (5, 4, 0, 0))):
    for th in (QT[1], R1, R2):
        for sg in (-1, 1):
            X = Expo(A4, k, sg, E, *th)
            sol = kernel(A4, ordinary(A4, k, sg, E)); assert len(sol) == 4
            oth = kernel(A4, ordinary(A4, k, sg, -E)); assert len(oth) == 4
            # the translation along v = k/E by +tau has theta' = k.v tau = E tau; in sector sg it is P -> P exp(-sg J theta)
            fwd = shift_factor(A4, sg, *th); bwd = shift_factor(A4, -sg, *th)
            op = X.minus
            want_sol = fwd if sg == -1 else bwd                                  # exp(J theta) on both sectors' ordinary solutions
            ok_dir &= all(op(P) == A4.mul(P, A4.rot(*th)) for P in sol) and all(A4.mul(P, A4.rot(*th)) == A4.mul(P, want_sol) for P in sol)
            ok_dir &= all(op(P) == A4.mul(P, A4.rot(th[0], -th[1])) for P in oth)  # on the other half: exp(-J theta)
            if sg == -1 and th == QT[1] and k[0] > 0:
                P = A4.lin(*[(i + 2, b) for i, b in enumerate(sol)]); Xc = A4.mul(A4.mul(P, A4.g[0]), A4.rev(P))
                kh = A4.vec(k); wedge = A4.lin((1, A4.mul(Xc, kh)), (-1, A4.mul(kh, Xc)))
                ok_cur &= set(Xc) <= {1 << mu for mu in range(4)} and not wedge and Xc.get(1, 0) > 0
            # std: expm(i tau K) restricted to ker(K - E) is exp(i theta), to ker(K + E) is exp(-i theta)
            K = Kmat(k, sg); Ex = std_expm(K, E, *th); t_ = ang(*th)
            B1 = null_basis(K - E * I4); B2 = null_basis(K + E * I4)
            ok_std &= np.abs(Ex @ B1 - np.exp(1j * t_) * B1).max() < 1e-9 and np.abs(Ex @ B2 - np.exp(-1j * t_) * B2).max() < 1e-9
            ok_std &= abs(np.exp(1j * t_) - (std_phase(sg, *th) if sg == -1 else std_phase(-sg, *th))) < 1e-12
            lam1 = (B1.conj().T @ Ex @ B1)[0, 0]; phase_cmp.append(abs(lam1 - complex(float(th[0]), float(th[1]))))
chk('bit', ok_dir, 'n = 4, E = 5 at k = (5,0,0,0), (13,12,0,0), (7,2,4,2), E = 3 at (5,4,0,0); theta = E tau with (cos, sin) = (0,1), (3/5,4/5), (5/13,12/13): on the ordinary solutions of mass E exp(-tau bD) P = P exp(J theta), which is the translation by tau along v = k/E in sector -1 (retard) and by -tau in sector +1 (advance); on the other half it is P exp(-J theta)')
chk('bit', ok_cur, 'the current X = P gamma_0 P~ of a solution (sector -1, future k, a fixed combination of the kernel basis) is a vector parallel to khat with X_0 > 0: the translation along the current by tau is the same as along k/E')
chk('std', ok_std, 'Dirac matrices: scipy expm(i tau K), tau = theta/E, is exp(i theta) on ker(K - E) and exp(-i theta) on ker(K + E), and exp(i theta) is the translation factor of sector -1 by +tau, of sector +1 by -tau')
chk('bit==std', max(phase_cmp) < 1e-9, 'the phase of exp(-tau D) on the ordinary solutions: exact (cos theta, sin theta) on the labels against the eigenvalue of scipy expm on ker(K - E), %d cases, max deviation %.1e: it retards the waves exp(-i k.x) and advances the waves exp(+i k.x) ("also an advanced equation")' % (len(phase_cmp), max(phase_cmp)))
# the covariant shift of the whole mass term, i D psi = m exp(-tau D) psi: frame free Compton condition
m = 4; okc = True; okcs = True
for k in ((4, 0, 0, 0), (5, 3, 0, 0), (-4, 0, 0, 0), (6, 4, 2, 0)):
    for name, j, want in (('2 pi/m', Fr(4), 'ord'), ('pi/m', Fr(2), 'oth'), ('pi/(2m)', Fr(1), None), ('R1', None, None)):   # theta = m tau = j pi/2
        th = R1 if j is None else QT[int(j) % 4]
        X = Expo(A4, k, -1, m, *th); L = paper_eq(A4, X, m, 0, 'cov')
        if fault('FIXEDA') and j is not None:                                     # the fixed time shift: theta_f = k_0 tau = (k_0/m) j pi/2
            jf = j * Fr(k[0]) / m
            if jf.denominator == 1:
                L = fixed_shift_eq(A4, k, -1, m, shift_factor(A4, -1, *QT[int(jf) % 4]))
        Kc = kernel(A4, L)
        if want == 'ord': okc &= same_span(Kc, kernel(A4, ordinary(A4, k, -1, m)))
        elif want == 'oth': okc &= same_span(Kc, kernel(A4, ordinary(A4, k, -1, -m)))
        else: okc &= len(Kc) == 0
        Km = Kmat(k, -1); Ex = std_expm(Km, m, *th)
        okcs &= 2 * cker(Km - m * Ex) == len(Kc)
chk('bit', okc, 'covariant shift, i D psi = m exp(-tau D) psi (even form bD psi J = m exp(-tau bD) psi), m = 4, at k = (4,0,0,0), (5,3,0,0), (-4,0,0,0), (6,4,2,0): tau = 2 pi/m keeps exactly the ordinary solutions, tau = pi/m gives exactly those of mass -m, tau = pi/(2m) and (3/5,4/5) give none: the Compton condition holds in every frame')
chk('std', okcs, 'Dirac matrices: (K - m expm(i tau K)) u = 0 has the same dimensions at the 16 points')
fx = []
for name, th, kf in (('rest', QT[0], 1), ('moving', QT[1], Fr(5, 4))):
    fx.append(kdim(A4, fixed_shift_eq(A4, (4, 0, 0, 0) if kf == 1 else (5, 3, 0, 0), -1, 4, shift_factor(A4, -1, *th))))
chk('ctl', fx == [4, 0], 'the fixed time shift a = tau gamma_0 with tau = 2 pi/m: the rest wave keeps 4 dimensions, the moving wave (5,3,0,0) has 0 (theta = 5 pi/2): replacing exp(-tau D) by a fixed shift loses the frame freedom')

# ================================================================================================ (6) the paper's equation (2.2)
head("(6) [shd·QNT, shd·NUL] the paper's equation (i hbar D - m c + i k exp(-tau D)) psi = 0: the quantization E tau = (n + 1/2) pi, E = m + (-1)^n kappa")
def paper_kernel(al, k, sg, m, kap, E, th, variant='plus', A=None, e=0):
    X = Expo(al, k, sg, E, *th, A=A, e=e); return kernel(al, paper_eq(al, X, m, kap, variant))
m, kap = 3, 2
main = [((5, 0, 0, 0), 5, QT[1]), ((13, 12, 0, 0), 5, QT[1]), ((7, 2, 4, 2), 5, QT[1]), ((-5, 0, 0, 0), 5, QT[1]),
        ((1, 0, 0, 0), 1, QT[3]), ((3, 2, 2, 0), 1, QT[3]), ((5, 4, 2, 2), 1, QT[3])]
ok = True; oks = True; agree = True
for k, E, th in main:
    for sg in (-1, 1):
        Kp = paper_kernel(A4, k, sg, m, kap, E, th)
        ok &= same_span(Kp, kernel(A4, ordinary(A4, k, sg, E)))
        sd = 2 * cker(std_paper(Kmat(k, sg), m, kap, std_expm(Kmat(k, sg), E, *th))); oks &= sd == 4; agree &= sd == len(Kp)
chk('bit', ok, 'n = 4, m = 3, kappa = 2: at E tau = pi/2, E = 5 (k = (5,0,0,0), (13,12,0,0), (7,2,4,2), (-5,0,0,0)) and at E tau = 3 pi/2, E = 1 (k = (1,0,0,0), (3,2,2,0), (5,4,2,2)) the solutions are exactly the ordinary solutions of mass E, 4 per sector: E = m + (-1)^n kappa')
chk('std', oks, 'Dirac matrices with scipy expm: (K - m + i kappa expm(i tau K)) u = 0 has 4 real dimensions at the 14 (k, sector) points')
chk('bit==std', agree, 'the 14 dimensions agree')
offc = [((5, 0, 0, 0), 5, QT[0], 'tau = lambda_C (E tau = 2 pi)'), ((5, 0, 0, 0), 5, QT[2], 'tau = lambda_C/2'),
        ((3, 0, 0, 0), 3, QT[0], 'tau = 0 (E = m)'), ((1, 0, 0, 0), 1, QT[0], 'tau = 0 (E = m - kappa)'),
        ((Fr(23, 5), 0, 0, 0), Fr(23, 5), R1, '(3/5, 4/5) with E = m + kappa sin'), ((Fr(299, 25), Fr(276, 25), 0, 0), Fr(23, 5), R1, 'the same, moving'),
        ((4, 0, 0, 0), 4, QT[1], 'pi/2 with E = 4 != m + kappa')]
d_off = [len(paper_kernel(A4, k, sg, m, kap, E, th)) for k, E, th, _ in offc for sg in (-1, 1)]
s_off = [2 * cker(std_paper(Kmat(k, sg), m, kap, std_expm(Kmat(k, sg), E, *th))) for k, E, th, _ in offc for sg in (-1, 1)]
chk('bit', all(x == 0 for x in d_off), 'no plane wave at: ' + '; '.join(t for *_, t in offc) + ' (both sectors)')
chk('bit==std', d_off == s_off, 'Dirac matrices give 0 at the same 14 points')
# the second branch for kappa > m, and n -> n - 1 as kappa -> -kappa
K2 = paper_kernel(A4, (3, 0, 0, 0), -1, 1, 4, 3, QT[1]); K2b = paper_kernel(A4, (5, 0, 0, 0), -1, 1, 4, 5, QT[1])
chk('bit', same_span(K2, kernel(A4, ordinary(A4, (3, 0, 0, 0), -1, -3))) and same_span(K2b, kernel(A4, ordinary(A4, (5, 0, 0, 0), -1, 5)))
    and len(paper_kernel(A4, (1, 0, 0, 0), -1, 3, 2, 1, QT[1])) == 0,
    'm = 1, kappa = 4, E tau = pi/2: besides E = m + kappa = 5 (the ordinary half) a second branch E = kappa - m = 3 lies on the other half (the solutions of mass -3); for kappa < m (m = 3, kappa = 2) the second branch E = kappa - m is negative and E = 1 at pi/2 has none')
Kn1 = paper_kernel(A4, (1, 0, 0, 0), -1, 3, 2, 1, QT[3]); Kn1b = paper_kernel(A4, (1, 0, 0, 0), -1, 3, -2, 1, QT[1])
chk('bit', same_span(Kn1, Kn1b) and len(Kn1) == 4, 'n -> n - 1 is kappa -> -kappa: the solutions at (E tau = 3 pi/2, kappa = 2) and at (pi/2, kappa = -2) are the same 4 dimensions (E = 1)')
# without the factor i
Knoi1 = kernel(A4, paper_eq(A4, Expo(A4, (5, 0, 0, 0), -1, 5, *QT[1]), m, kap, 'noi'))
Knoi2 = kernel(A4, paper_eq(A4, Expo(A4, (1, 0, 0, 0), -1, 1, *QT[0]), m, kap, 'noi'))
chk('ctl', len(Knoi1) == 0 and len(Knoi2) == 4, 'without the factor i (kappa exp(-tau D) in place of i kappa exp(-tau D)): none at (E tau = pi/2, E = 5), and 4 dimensions at tau = 0 with E = m - kappa = 1: the i moves the lattice by a quarter turn and excludes tau = 0')
# n = 3 and 5
for n, k5, k1 in ((3, (13, 12, 0), (3, 2, 2)), (5, (7, 2, 4, 2, 0), (5, 4, 2, 2, 0))):
    al = Alg(n)
    d5 = [paper_kernel(al, k5, sg, 3, 2, 5, QT[1]) for sg in (-1, 1)]; d1 = [paper_kernel(al, k1, sg, 3, 2, 1, QT[3]) for sg in (-1, 1)]
    o5 = [kernel(al, ordinary(al, k5, sg, 5)) for sg in (-1, 1)]; o1 = [kernel(al, ordinary(al, k1, sg, 1)) for sg in (-1, 1)]
    dz = [len(paper_kernel(al, k5, sg, 3, 2, 5, QT[0])) for sg in (-1, 1)]
    chk('bit', all(same_span(a, b) and len(a) == 2 ** (n - 2) for a, b in zip(d5 + d1, o5 + o1)) and dz == [0, 0],
        'n = %d: at (E tau = pi/2, E = 5) and (3 pi/2, E = 1) the solutions are the ordinary ones of mass E, %d per sector; none at E tau = 2 pi' % (n, 2 ** (n - 2)))
# massless: a null frequency
ok = True; ok0 = True; okfix = True; okj = True; oks = True
for k in ((1, 1, 0, 0), (5, 3, 4, 0), (13, 12, 0, 5)):
    for m_, kap_, tau in ((3, 2, Fr(1, 2)), (0, 1, Fr(1, 3)), (3, 2, Fr(1, 2)), (2, Fr(1, 2), Fr(2))):
        for sg in (-1, 1):
            X = Expo(A4, k, sg, tau=tau); d = kdim(A4, paper_eq(A4, X, m_, kap_)); ok &= d == 0
            sd = 2 * cker(std_paper(Kmat(k, sg), m_, kap_, std_expm(Kmat(k, sg), None, None, None, null_tau=tau))); oks &= sd == d
    for sg in (-1, 1):
        X = Expo(A4, k, sg, tau=Fr(1, 2)); K0 = kernel(A4, paper_eq(A4, X, 0, 0)); ok0 &= len(K0) == 4
        okfix &= all(X.minus(P) == P for P in K0)
        okj &= any(X.minus({S: Fr(1)}) != {S: Fr(1)} for S in A4.EV)
chk('bit', ok, 'null k = (1,1,0,0), (5,3,4,0), (13,12,0,5): no plane wave for (m, kappa, tau) = (3, 2, 1/2), (0, 1, 1/3), (2, 1/2, 2) (kappa tau = 1 included), both sectors: a massless fermion cannot be shifted')
chk('bit', ok0 and okfix, 'at the same null k with m = kappa = 0 the massless solutions (4 per sector) are fixed by exp(-tau bD): no retardation at the speed of light')
chk('bit', okj, 'and exp(-tau bD) = 1 - tau bD is not the identity on the whole sector there (a Jordan block): it is the identity only on the solutions')
chk('bit==std', oks, 'Dirac matrices with expm(i tau K) at the null k give the same dimensions (0)')

# ================================================================================================ (7) the variants (2.3)
head('(7) [shd·VAR] the variants D_-, D_s, D_c of the paper (uniform reading D_x = D + kappa f(tau D); two readings of D_c)')
m, kap = 3, 2
pts = [((5, 0, 0, 0), 5, QT[1]), ((13, 12, 0, 0), 5, QT[1]), ((1, 0, 0, 0), 1, QT[3]), ((Fr(23, 5), 0, 0, 0), Fr(23, 5), R1), ((5, 0, 0, 0), 5, QT[0])]
same_pm = all(same_span(paper_kernel(A4, k, sg, m, kap, E, th, 'plus'), paper_kernel(A4, k, sg, m, kap, E, th, 'minus')) for k, E, th in pts for sg in (-1, 1))
chk('bit', same_pm, 'D_- = D - kappa exp(tau D): the same solutions as D_+ at the 10 test points (quantized, off the lattice, and tau = 0)')
# D_s: E = m - kappa sin(E tau), every theta
ds_pts = [((Fr(7, 5), 0, 0, 0), Fr(7, 5), R1), ((Fr(91, 25), Fr(84, 25), 0, 0), Fr(7, 5), R1), ((Fr(15, 13), 0, 0, 0), Fr(15, 13), R2), ((5, 0, 0, 0), 5, QT[3]), ((3, 0, 0, 0), 3, QT[0])]
okd = True; okds = True
for k, E, th in ds_pts:
    assert E == m - kap * th[1]
    for sg in (-1, 1):
        Kd = paper_kernel(A4, k, sg, m, kap, E, th, 'sinh'); okd &= same_span(Kd, kernel(A4, ordinary(A4, k, sg, E)))
        okds &= 2 * cker(std_paper(Kmat(k, sg), m, kap, std_expm(Kmat(k, sg), E, *th), 'sinh')) == len(Kd)
chk('bit', okd, 'D_s = D + kappa sinh(tau D): solutions of mass E whenever E = m - kappa sin(E tau), at (cos, sin) = (3/5, 4/5), (5/13, 12/13), 3 pi/2 and 0 (rest and moving): no quantization, a transcendental relation')
chk('bit==std', okds, 'Dirac matrices: the same 10 dimensions for D_s')
# D_c two readings
okA = True; okB = True; okAB = True
for k, E, th, wantA, wantB in (((3, 0, 0, 0), 3, QT[1], 4, 4), ((5, 0, 0, 0), 5, QT[1], 0, 0), ((3, 0, 0, 0), 3, R1, 0, 0),
                                ((Fr(21, 5), 0, 0, 0), Fr(21, 5), R1, 0, 4), ((Fr(273, 25), Fr(252, 25), 0, 0), Fr(21, 5), R1, 0, 4)):
    for sg in (-1, 1):
        dA = len(paper_kernel(A4, k, sg, m, kap, E, th, 'coshA')); dB = len(paper_kernel(A4, k, sg, m, kap, E, th, 'coshB'))
        okA &= dA == wantA; okB &= dB == wantB
        sA = 2 * cker(std_paper(Kmat(k, sg), m, kap, std_expm(Kmat(k, sg), E, *th), 'coshA')); sB = 2 * cker(std_paper(Kmat(k, sg), m, kap, std_expm(Kmat(k, sg), E, *th), 'coshB'))
        okAB &= (sA, sB) == (dA, dB)
chk('bit', okA, 'D_c read as D + kappa cosh(tau D): solutions only at cos(E tau) = 0 with E = m (4 dimensions at E tau = pi/2, E = 3; none at E = 5, pi/2, where D_+ has them; none at (3/5, 4/5)): a quantization condition with no mass shift')
chk('bit', okB, 'D_c read as D + i kappa cosh(tau D): solutions exactly at E = m + kappa cos(E tau), for every theta (E = 21/5 at (3/5, 4/5), rest and moving; E = 3 at pi/2); none at E = 3 with (3/5, 4/5) or E = 5 at pi/2: no quantization')
chk('bit==std', okAB, 'Dirac matrices: the same dimensions for both readings')
okm = True
for k in ((1, 1, 0, 0), (5, 3, 4, 0)):
    for sg in (-1, 1):
        X = Expo(A4, k, sg, tau=Fr(1, 2))
        okm &= same_span(kernel(A4, paper_eq(A4, X, 0, kap, 'sinh')), kernel(A4, paper_eq(A4, X, 0, 0)))
        okm &= kdim(A4, paper_eq(A4, X, 0, kap, 'coshA')) == 0 and kdim(A4, paper_eq(A4, X, 0, kap, 'coshB')) == 0
chk('bit', okm, 'm = 0 at null k = (1,1,0,0), (5,3,4,0): D_s keeps the massless solutions (compatible with a massless dispersion relation), D_c in both readings has none')

# ================================================================================================ (8) a constant potential: gauge
head('(8) [shd·GAU] a constant potential: the fixed shift needs the transport factor; exp(-tau D_A) does not')
e = 1; Ap = (2, 0, 0, 0); kb = (7, 4, 0, 0); lam = (1, 2, 0, 0)
kg = tuple(kb[i] + lam[i] for i in range(4)); Ag = tuple(Ap[i] + Fr(lam[i], e) for i in range(4))
assert Q(kb, Ap, e, -1) == 9 and Q(kg, Ag, e, -1) == 9
# angles: theta_k = k.a = 0 (mod 2 pi), theta_A = e A.a = 0, theta_lambda = lambda.a = pi/2 (a vector a with these three products exists: k, A, lambda independent)
gauges = {'base': (QT[0], QT[0]), 'gauged': (QT[1], QT[1])}                   # (theta_k, theta_A) in each gauge
d0 = {g: kdim(A4, ordinary(A4, kk, -1, 3, AA, e)) for g, kk, AA in (('base', kb, Ap), ('gauged', kg, Ag))}
d1 = {}; dW = {}
for g, kk, AA in (('base', kb, Ap), ('gauged', kg, Ag)):
    thk, thA = gauges[g]
    d1[g] = kdim(A4, fixed_shift_eq(A4, kk, -1, 3, shift_factor(A4, -1, *thk), AA, e))
    W = {0: Fr(1)} if fault('NOW') else A4.rot(thA[0], -thA[1])                 # exp(-J e A.a)
    dW[g] = kdim(A4, fixed_shift_eq(A4, kk, -1, 3, A4.mul(shift_factor(A4, -1, *thk), W), AA, e))
chk('bit', d0 == {'base': 4, 'gauged': 4}, 'm = 3, e = 1, k = (7,4,0,0), A = 2 gamma_0 (k - eA = (5,4,0,0) on the shell) and the gauge k + lambda, A + lambda/e, lambda = (1,2,0,0): the coupled ordinary equation has 4 dimensions in both gauges')
chk('ctl', d1 == {'base': 4, 'gauged': 0}, 'the fixed shift of the mass term without transport factor (theta = k.a = 0, lambda.a = pi/2): 4 dimensions in one gauge, 0 in the other: not gauge covariant')
chk('bit', dW['base'] == dW['gauged'] == 4, 'with the transport factor exp(-J e A.a) on psi(x - a): 4 dimensions in both gauges (the phase is (k - eA).a)')
# the paper's coupled operator
okg = True; okgs = True
for g, kk, AA in (('base', kb, Ap), ('gauged', kg, Ag)):
    X = Expo(A4, kk, -1, 3, *QT[1], A=AA, e=e)
    Kc = kernel(A4, paper_eq(A4, X, 2, 1)); okg &= same_span(Kc, kernel(A4, ordinary(A4, kk, -1, 3, AA, e)))
    Km = Kmat(kk, -1, AA, e); okgs &= 2 * cker(std_paper(Km, 2, 1, std_expm(Km, 3, *QT[1]))) == len(Kc)
chk('bit', okg, "the paper's operator with the potential, exp(-tau bD_A), m = 2, kappa = 1, E = 3 = m + kappa at E tau = pi/2: in both gauges the solutions are the coupled ordinary ones of mass 3 (4 dimensions): it depends on k - eA only")
sd0 = {g: 2 * cker(Kmat(kk, -1, AA, e) - 3 * I4) for g, kk, AA in (('base', kb, Ap), ('gauged', kg, Ag))}
sd1 = {}; sdW = {}
for g, kk, AA in (('base', kb, Ap), ('gauged', kg, Ag)):
    thk, thA = gauges[g]; Km = Kmat(kk, -1, AA, e)
    sd1[g] = 2 * cker(Km - 3 * std_phase(-1, *thk) * I4)
    sdW[g] = 2 * cker(Km - 3 * std_phase(-1, *thk) * (1 if fault('NOW') else np.exp(-1j * ang(*thA))) * I4)
chk('std', sd0 == d0 and sd1 == {'base': 4, 'gauged': 0} and sdW == {'base': 4, 'gauged': 4} and okgs, 'Dirac matrices with minimal coupling i D - e A: the same dimensions for the four equations in both gauges')
chk('bit==std', sd0 == d0 and sd1 == d1 and sdW == dW, 'the 6 dimensions of the fixed-shift equations agree')

# ================================================================================================ (9) bilinears
head('(9) [shd·BIL] at the quantized shift the shifted solution is psi J: current and spin unchanged, the frame vectors gamma_1, gamma_2 reverse')
kq = (13, 12, 0, 0); X = Expo(A4, kq, -1, 5, *QT[1]); sol = paper_kernel(A4, kq, -1, 3, 2, 5, QT[1])
P = A4.lin(*[(i + 1, b) for i, b in enumerate(sol)]); Ps = X.minus(P)
def bil(P, mu): return A4.mul(A4.mul(P, A4.g[mu]), A4.rev(P))
okb = Ps == A4.mul(P, A4.J) and bil(Ps, 0) == bil(P, 0) and bil(Ps, 3) == bil(P, 3) and bil(Ps, 1) == A4.lin((-1, bil(P, 1))) and bil(Ps, 2) == A4.lin((-1, bil(P, 2)))
chk('bit', okb, "m = 3, kappa = 2, E = 5, k = (13,12,0,0), E tau = pi/2: exp(-tau bD) psi = psi J on a solution; psi gamma_0 psi~ and psi gamma_3 psi~ are unchanged, psi gamma_1 psi~ and psi gamma_2 psi~ change sign")
c, s = R1; Pg = kernel(A4, ordinary(A4, (5, 0, 0, 0), -1, 5)); P = A4.lin(*[(i + 2, b) for i, b in enumerate(Pg)]); Xg = Expo(A4, (5, 0, 0, 0), -1, 5, c, s); Ps = Xg.minus(P)
c2, s2 = c * c - s * s, 2 * c * s
okr = bil(Ps, 0) == bil(P, 0) and bil(Ps, 3) == bil(P, 3) and bil(Ps, 1) == A4.lin((c2, bil(P, 1)), (-s2, bil(P, 2))) and bil(Ps, 2) == A4.lin((s2, bil(P, 1)), (c2, bil(P, 2)))
chk('bit', okr, 'at (cos, sin) = (3/5, 4/5) on the rest solutions of mass 5: the current and the spin are unchanged, (e_1, e_2) turn by -2 theta (cos 2 theta = -7/25)')
def gm_blade(Sm):
    M = I4.copy()
    for i in range(4):
        if Sm >> i & 1: M = M @ GM[i]
    return M
def mat(a): return sum(float(v) * gm_blade(mm) for mm, v in a.items())
def mrev(a): return mat({mm: cs.rsign(pc(mm)) * v for mm, v in a.items()})
P = A4.lin(*[(i + 1, b) for i, b in enumerate(sol)]); Mp = mat(P); MJ = gm_blade(4) @ gm_blade(2)
Mps = Mp @ MJ
Mb = lambda M, Mr, mu: M @ GM[mu] @ Mr
Mpr = mrev(P); Mpsr = mrev(A4.mul(P, A4.J))
okm = (np.abs(Mb(Mps, Mpsr, 0) - Mb(Mp, Mpr, 0)).max() < 1e-9 and np.abs(Mb(Mps, Mpsr, 3) - Mb(Mp, Mpr, 3)).max() < 1e-9
       and np.abs(Mb(Mps, Mpsr, 1) + Mb(Mp, Mpr, 1)).max() < 1e-9 and np.abs(Mb(Mps, Mpsr, 2) + Mb(Mp, Mpr, 2)).max() < 1e-9)
okm &= np.abs(MJ @ MJ + I4).max() < 1e-12 and np.abs(mat(A4.mul(P, A4.J)) - Mps).max() < 1e-9
chk('std', okm, 'Dirac matrices as the image of the even algebra (products of Gamma_mu): psi J gives the same current and spin and the reversed gamma_1, gamma_2 frame vectors')
cmpb = max(np.abs(mat(bil(A4.mul(P, A4.J), mu)) - Mb(Mps, Mpsr, mu)).max() for mu in range(4))
chk('bit==std', cmpb < 1e-9, 'the four bilinears of psi J computed on the labels equal the matrix products (max deviation %.1e): the quantized shift is right multiplication by J, a quarter turn of psi and a half turn of its frame' % cmpb)

# ================================================================================================ (10) formal series
head('(10) [shd·SER] formal series in one commuting D: D_+ D_-, the compression of D_+^2, D_s^2 and their constant terms')
N = 12
def ser_exp(t): return [t ** j / factorial(j) for j in range(N + 1)]
def smul(a, b):
    out = [Fr(0)] * (N + 1)
    for i, x in enumerate(a):
        if x:
            for j in range(N + 1 - i): out[i + j] += x * b[j]
    return out
def sadd(*terms):
    out = [Fr(0)] * (N + 1)
    for c, a in terms:
        for i in range(N + 1): out[i] += c * a[i]
    return out
Dser = [Fr(0), Fr(1)] + [Fr(0)] * (N - 1); one = [Fr(1)] + [Fr(0)] * N
def even_part(a): return a if fault('KEEPODD') else [x if j % 2 == 0 else Fr(0) for j, x in enumerate(a)]
oks = True; const = []
for tau, kp in ((Fr(2, 3), Fr(5, 7)), (Fr(-3, 4), Fr(11, 2))):
    em, ep = ser_exp(-tau), ser_exp(tau)
    sinh_ = sadd((Fr(1, 2), ep), (Fr(-1, 2), em)); cosh_ = sadd((Fr(1, 2), ep), (Fr(1, 2), em))
    cosh2 = sadd((Fr(1, 2), ser_exp(2 * tau)), (Fr(1, 2), ser_exp(-2 * tau)))
    Dp = sadd((1, Dser), (kp, em)); Dm = sadd((1, Dser), (-kp, ep)); Ds = sadd((1, Dser), (kp, sinh_))
    D2 = smul(Dser, Dser); DS = smul(Dser, sinh_)
    rhs_pm = sadd((1, D2), (-2 * kp, DS), ((1 if fault('KGSIGN') else -1) * kp * kp, one))
    rhs_pp = sadd((1, D2), (-2 * kp, DS), (kp * kp, cosh2)); rhs_ss = sadd((1, D2), (2 * kp, DS), (kp * kp, smul(sinh_, sinh_)))
    oks &= smul(Dp, Dm) == rhs_pm and even_part(smul(Dp, Dp)) == rhs_pp and smul(Ds, Ds) == rhs_ss
    const.append((even_part(smul(Dp, Dp))[0], smul(Dp, Dm)[0], smul(Ds, Ds)[0], kp * kp))
chk('bit', oks, 'orders <= %d, (tau, kappa) = (2/3, 5/7), (-3/4, 11/2): D_+ D_- = D^2 - 2 kappa D sinh(tau D) - kappa^2; even part of D_+^2 = D^2 - 2 kappa D sinh(tau D) + kappa^2 cosh(2 tau D); D_s^2 = D^2 + 2 kappa D sinh(tau D) + kappa^2 sinh^2(tau D)' % N)
chk('bit', all(a == k2 and b == -k2 and c_ == 0 for a, b, c_, k2 in const), 'constant terms: kappa^2 (compressed D_+^2), -kappa^2 (D_+ D_-), 0 (D_s^2); with D^2 + nabla^2 = Ricci the leading equations read Ricci = -kappa^2, +kappa^2, 0: a cosmological term of either sign or none, its size kappa^2 = (k/hbar)^2')
errs = []
for Dv in (0.3, -0.7, 1.1):
    t, kp = 0.4, 0.9
    Dp = Dv + kp * np.exp(-t * Dv); Dm = Dv - kp * np.exp(t * Dv); Ds = Dv + kp * np.sinh(t * Dv)
    errs.append(abs(Dp * Dm - (Dv ** 2 - 2 * kp * Dv * np.sinh(t * Dv) + (kp * kp if fault('KGSIGN') else -kp * kp))))
    Dpn = -Dv + kp * np.exp(t * Dv); comp = (Dp ** 2 + Dpn ** 2) / 2 if not fault('KEEPODD') else Dp ** 2
    errs.append(abs(comp - (Dv ** 2 - 2 * kp * Dv * np.sinh(t * Dv) + kp * kp * np.cosh(2 * t * Dv))))
    errs.append(abs(Ds ** 2 - (Dv ** 2 + 2 * kp * Dv * np.sinh(t * Dv) + kp * kp * np.sinh(t * Dv) ** 2)))
chk('std', max(errs) < 1e-12, 'numpy closed forms at D = 0.3, -0.7, 1.1 (tau = 0.4, kappa = 0.9): the three identities, the compression as (f(D) + f(-D))/2; max deviation %.1e' % max(errs))
chk('bit==std', oks and max(errs) < 1e-12, 'the series and the closed forms agree on the three identities')

print('\n  [time] %.1f s' % (time.time() - T0))
finish(STEP)
