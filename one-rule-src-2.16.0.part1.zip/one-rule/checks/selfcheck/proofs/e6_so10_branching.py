#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""e6_so10_branching.py -- the 27 of e6 under so(10) x u(1): the 27 grade-1 roots of e7 split by the coefficient of alpha_6.

Statement. Bourbaki labelling (chain 1-3-4-5-6-7-8, node 2 on node 4). E7 = the roots of E8 with coefficient 0 on alpha_8,
the 27 = the roots of E7 with coefficient 1 on alpha_7 (no root of E7 has coefficient 2 on alpha_7). Graded by their
coefficient c6 on alpha_6 (the node that leaves D5 = {alpha_1..alpha_5} when deleted from E6), the 27 has 1, 16 and 10
roots at c6 = 0, 1, 2. With respect to D5 the 16 is one Weyl orbit of 16 weights with Dynkin labels in {-1, 0, 1} and
dominant weight omega_2 (a spinor node): the half-spin representation, in the orthonormal basis of D5 the weights
(+-1/2)^5 with an even number of minus signs, i.e. the even labels of five bits (for the numbering alpha_1, alpha_3,
alpha_4, alpha_5, alpha_2 of the D5 chain); the 10 is one orbit with dominant weight omega_1, the weights +-e_t, the
vector; the singlet alpha_7 is fixed by W(D5). The charge q = 4 - 3 c6 takes 4, 1, -2 on the three levels, sums to 0
over the 27, and equals -3 <gamma, omega_6> for the fundamental weight omega_6 of E6: the u(1) is a Cartan element of e6.
The three levels are the Peirce spaces 1, 1/2, 0 of the tripotent at the root alpha_7 (and alpha_7 is the only root of
the 27 whose Peirce 1/2 space is the level c6 = 1); the level c6 = 1 is alpha_7 + (the grade-1 16 of e6), a set of roots
disjoint from that 16 with the same D5 weights. The 10 splits by the coefficient of alpha_5 into 5 + 5 roots, the 5 and
the 5-bar of A4 = {alpha_1..alpha_4}, and each 5 by the coefficient of alpha_4 into 3 + 2: (3,1) + (1,2) under
A2{alpha_1, alpha_3} + A1{alpha_2}.
[bit] The 240 roots of E8 in doubled integer coordinates from bit labels: the 112 vector-type roots from the pairs of
      the 8 bits with two signs, the 128 spinor-type roots from the even labels of 8 bits (coordinate t = -1 where bit t
      is set); the Bourbaki simple roots; coefficients by an exact linear solve (Fractions); inner products dot/4;
      Weyl orbits by simple reflections; the grade-1 pieces 56, 27, 16, 10, 6 of the nodes 8..4 (as baez_check.py E1b).
[std] The Cartan matrix of E7 written by hand; the 63 positive roots by the reflection (root string) algorithm in
      simple-root coordinates, the highest root (2,2,3,4,3,2,1); Dynkin labels, orbits, charges and inner products from
      the Cartan matrix; [bit==std]: the 27 coefficient vectors as sets, the counts, the dominant weights, the charges.
[ctl] The grading by alpha_1 (the other D5 of E6, {alpha_2..alpha_6}): levels 10, 16, 1 for c1 = 0, 1, 2, the singlet on
      the top level; the grading by alpha_2 (Levi A5 of E6): levels 6, 15, 6; in E8 the coefficient of alpha_7 reaches
      2 and 3; q = 4 - 2 c6 does not sum to 0. Each is also a --fault option that puts it into the main lines (the run must
      then end with FAILS).
Scope. The roots of E7 inside E8 (weights of the 27 as roots of e7); one embedding so(10) + u(1) in e6 (the Levi
      subalgebra of the node alpha_6). Which half-spin is called 16 and which 16-bar is a choice of the numbering of the
      two spinor nodes. Nothing here is a statement about nature or about Higgs multiplets. The script builds no Forms,
      Lie or Grav object (standard library only).
Run:  python3 selfcheck/proofs/e6_so10_branching.py [--fault ALPHA1|ALPHA2|E8|Q2]
      (from the package root; also from its own folder, and under -I -B)"""
import sys
from fractions import Fraction as F
from collections import Counter
sys.dont_write_bytecode = True

FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

STEP = 'E6-SO10'
FAULT_NAMES = ('ALPHA1', 'ALPHA2', 'E8', 'Q2')
FAULT = None
if '--fault' in sys.argv:
    FAULT = sys.argv[sys.argv.index('--fault') + 1] if sys.argv.index('--fault') + 1 < len(sys.argv) else ''
    if FAULT not in FAULT_NAMES: raise SystemExit('unknown fault %r; one of %s' % (FAULT, ', '.join(FAULT_NAMES)))
    print('fault: %s (a wrong version in the main lines; the run must end with FAILS)' % FAULT)
GN = {'ALPHA1': 1, 'ALPHA2': 2}.get(FAULT, 6)                       # the grading node of the main lines
QF = (lambda c: 4 - 2 * c) if FAULT == 'Q2' else (lambda c: 4 - 3 * c)
def pc(x): return bin(x).count('1')
def inv_exact(M):
    n = len(M); A = [[F(v) for v in row] + [F(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        piv = next(i for i in range(c, n) if A[i][c] != 0); A[c], A[piv] = A[piv], A[c]
        p = A[c][c]; A[c] = [v / p for v in A[c]]
        for i in range(n):
            if i != c and A[i][c] != 0:
                f = A[i][c]; A[i] = [u - f * w for u, w in zip(A[i], A[c])]
    return [row[n:] for row in A]
def orbit(v, refl):
    seen, todo = {v}, [v]
    while todo:
        u = todo.pop()
        for s in refl:
            w = s(u)
            if w not in seen: seen.add(w); todo.append(w)
    return seen

# ===================================================================================== A. the roots from bit labels
head('A. [bit] The roots of E8 from bit labels (doubled integer coordinates), E7, the 27 and its grading by alpha_6')
R8 = []
for m in range(256):
    if pc(m) == 2:
        i, j = [t for t in range(8) if (m >> t) & 1]
        for si in (2, -2):
            for sj in (2, -2):
                v = [0] * 8; v[i] = si; v[j] = sj; R8.append(tuple(v))
for x in range(256):
    if pc(x) % 2 == 0: R8.append(tuple(1 - 2 * ((x >> t) & 1) for t in range(8)))
S8 = [(1, -1, -1, -1, -1, -1, -1, 1), (2, 2, 0, 0, 0, 0, 0, 0), (-2, 2, 0, 0, 0, 0, 0, 0), (0, -2, 2, 0, 0, 0, 0, 0), (0, 0, -2, 2, 0, 0, 0, 0),
      (0, 0, 0, -2, 2, 0, 0, 0), (0, 0, 0, 0, -2, 2, 0, 0), (0, 0, 0, 0, 0, -2, 2, 0)]            # Bourbaki simple roots alpha_1..alpha_8, doubled
def ip(u, v): return F(sum(a * b for a, b in zip(u, v)), 4)
CART8 = [[ip(u, v) for v in S8] for u in S8]
EDGES8 = sorted((i + 1, j + 1) for i in range(8) for j in range(i + 1, 8) if CART8[i][j] == -1)
SINV = inv_exact(S8)
coef = {r: tuple(sum(F(r[k]) * SINV[k][i] for k in range(8)) for i in range(8)) for r in R8}
okc = all(all(c.denominator == 1 for c in cs) and (all(c >= 0 for c in cs) or all(c <= 0 for c in cs)) for cs in coef.values())
okc &= all(tuple(sum(int(coef[r][i]) * S8[i][t] for i in range(8)) for t in range(8)) == r for r in R8)
chk('bit', len(set(R8)) == 240 and all(ip(r, r) == 2 for r in R8) and okc and sum(1 for cs in coef.values() if sum(cs) > 0) == 120
    and EDGES8 == [(1, 3), (2, 4), (3, 4), (4, 5), (5, 6), (6, 7), (7, 8)] and all(CART8[i][i] == 2 for i in range(8)),
    'E8: 112 roots from the pairs of 8 bits and 128 from the even labels of 8 bits, all of squared length 2; Bourbaki simple roots with diagram edges %s; every root an integer combination of them with coefficients of one sign (exact solve), 120 positive' % EDGES8)
c = lambda r, k: int(coef[r][k - 1])                                  # coefficient of alpha_k
E7 = [r for r in R8 if c(r, 8) == 0]; E6 = [r for r in E7 if c(r, 7) == 0]; D5 = [r for r in E6 if c(r, 6) == 0]
def levi(n): return [r for r in R8 if all(c(r, m) == 0 for m in range(n + 1, 9))]
g1 = {n: [r for r in levi(n) if c(r, n) == 1] for n in (8, 7, 6, 5, 4)}
chk('bit', (len(E7), len(E6), len(D5)) == (126, 72, 40) and [len(g1[n]) for n in (8, 7, 6, 5, 4)] == [56, 27, 16, 10, 6],
    'Levi subsystems: E7 126, E6 72, D5 40 roots; grade-1 pieces (coefficient 1 on the deleted node) for the nodes 8, 7, 6, 5, 4: %s (as baez_check.py E1b)' % [len(g1[n]) for n in (8, 7, 6, 5, 4)])
SRC = R8 if FAULT == 'E8' else E7
G27 = [r for r in SRC if c(r, 7) == 1]
top = max(E7, key=lambda r: sum(coef[r]))
c7vals, c7e8 = sorted({c(r, 7) for r in SRC}), sorted({c(r, 7) for r in R8})
chk('bit', len(G27) == 27 and c7vals == [-1, 0, 1] and tuple(c(top, k) for k in range(1, 8)) == (2, 2, 3, 4, 3, 2, 1),
    'the 27 = the roots of E7 with coefficient 1 on alpha_7: %d roots; the coefficients of alpha_7 on E7 are %s (no 2); the highest root of E7 is %s, coefficient 2 on alpha_6' % (len(G27), c7vals, tuple(c(top, k) for k in range(1, 8))))
chk('ctl', c7e8 == [-3, -2, -1, 0, 1, 2, 3], 'in E8 the coefficient of alpha_7 takes the values %s: the 3-grading by alpha_7 needs E7' % c7e8)
lev = {}
for r in G27: lev.setdefault(c(r, GN), []).append(r)
counts = tuple(len(lev.get(k, [])) for k in range(3))
chk('bit', counts == (1, 16, 10) and sorted(lev) == [0, 1, 2], 'the 27 graded by the coefficient of alpha_%d: %s roots at the values 0, 1, 2 (all values: %s)' % (GN, counts, sorted(lev)))
L0, L1, L2 = lev.get(0, []), lev.get(1, []), lev.get(2, [])
A7r = S8[6]
D5I = [0, 1, 2, 3, 4]                                                # alpha_1..alpha_5
def labels(r, idx=D5I): return tuple(int(ip(r, S8[i])) for i in idx)
def refl(i): return lambda v: tuple(a - int(ip(v, S8[i])) * b for a, b in zip(v, S8[i]))
W5 = [refl(i) for i in D5I]
def describe(L):
    labs = [labels(r) for r in L]; dom = [l for l in labs if all(x >= 0 for x in l)]
    orb = orbit(L[0], W5) if L else set()
    return dict(n=len(L), one_orbit=orb == set(L), labset=sorted({x for l in labs for x in l}), dom=dom)
d0, d1, d2 = describe(L0), describe(L1), describe(L2)
chk('bit', d1['one_orbit'] and d1['labset'] == [-1, 0, 1] and d1['dom'] == [(0, 1, 0, 0, 0)],
    'the 16 (c6 = 1) is one W(D5) orbit (simple reflections in alpha_1..alpha_5), Dynkin labels in %s, one dominant weight with labels %s on (alpha_1..alpha_5): omega_2, a spinor node of D5: the half-spin representation' % (d1['labset'], d1['dom']))
chk('bit', d2['one_orbit'] and d2['labset'] == [-1, 0, 1] and d2['dom'] == [(1, 0, 0, 0, 0)] and d0['n'] == 1 and L0 == [A7r] and d0['dom'] == [(0, 0, 0, 0, 0)] and all(s(L0[0]) == L0[0] for s in W5),
    'the 10 (c6 = 2) is one W(D5) orbit with dominant weight %s = omega_1 (the vector node): the vector representation; the singlet (c6 = 0) is alpha_7 itself, labels (0,0,0,0,0), fixed by all five reflections' % (d2['dom'],))
# orthonormal coordinates of D5: alpha_1, alpha_3, alpha_4, alpha_5, alpha_2 = a1..a5 (a1-a2-a3, fork a4, a5 at a3); omega_4 = (1,1,1,1,-1)/2, omega_5 = (1,1,1,1,1)/2
OMEGA = [(1, 0, 0, 0, 0), (1, 1, 0, 0, 0), (1, 1, 1, 0, 0), (F(1, 2), F(1, 2), F(1, 2), F(1, 2), F(-1, 2)), (F(1, 2),) * 5]
def eps(r):
    l = labels(r); m = (l[0], l[2], l[3], l[4], l[1])                 # labels on a1..a5
    return tuple(sum(F(m[i]) * F(OMEGA[i][t]) for i in range(5)) for t in range(5))
w16 = {eps(r) for r in L1}; w10 = {eps(r) for r in L2}
bits16 = sorted(sum((1 << t) for t in range(5) if w[t] == F(-1, 2)) for w in w16)
even5 = [x for x in range(32) if pc(x) % 2 == 0]
chk('bit', len(w16) == 16 and all(abs(x) == F(1, 2) for w in w16 for x in w) and bits16 == even5
    and w10 == {tuple(F(s) * (t == u) for t in range(5)) for u in range(5) for s in (1, -1)} and eps(A7r) == (0,) * 5,
    'in the orthonormal basis of D5 (numbering alpha_1, alpha_3, alpha_4, alpha_5, alpha_2): the 16 weights are (+-1/2)^5 with an even number of minus signs, i.e. the 16 even labels of five bits (bit t set where the coordinate t is -1/2); the 10 weights are +-e_t; the singlet is 0')
qv = {r: QF(c(r, 6)) for r in G27}
CE6 = [[ip(S8[i], S8[j]) for j in range(6)] for i in range(6)]; IE6 = inv_exact(CE6)
w6 = lambda r: -3 * sum(IE6[j][5] * ip(r, S8[j]) for j in range(6))  # -3 <gamma, omega_6> with omega_6 the fundamental weight of E6
okq = sorted({qv[r] for r in G27}) == [-2, 1, 4] and all(qv[r] == {0: 4, 1: 1, 2: -2}[c(r, 6)] for r in G27)
chk('bit', okq and sum(qv.values()) == 0 and all(qv[r] == w6(r) for r in G27) and IE6[5][5] == F(4, 3),
    'q = 4 - 3 c6: %s on the levels c6 = 0, 1, 2 (equally spaced, step -3), sum over the 27 = %s; q(gamma) = -3 <gamma, omega_6> for all 27 (|omega_6|^2 = %s from the inverse Cartan matrix of E6): q is a Cartan element of e6, so the u(1) lies in e6'
    % ([QF(k) for k in range(3)], sum(qv.values()), IE6[5][5]))
q2 = {r: 4 - 2 * c(r, 6) for r in E7 if c(r, 7) == 1}
chk('ctl', sum(q2.values()) == 36 and not all(q2[r] == w6(r) for r in q2), 'q = 4 - 2 c6: sum over the 27 = %d, not 0, and not of the form k <gamma, omega_6>: the coefficient 3 is forced' % sum(q2.values()))
# Peirce spaces and the grade-1 16 of e6
def peirce(beta, G): return {k: [g for g in G if ip(g, beta) == k] for k in (2, 1, 0)}
P = peirce(A7r, G27)
same = [b for b in G27 if set(peirce(b, G27)[1]) == set(L1)]
shift = {tuple(a - b for a, b in zip(r, A7r)) for r in L1}
chk('bit', set(P[2]) == set(L0) and set(P[1]) == set(L1) and set(P[0]) == set(L2) and same == [A7r] and len({len(peirce(b, G27)[1]) for b in G27}) == 1,
    'the levels c6 = 0, 1, 2 are exactly the Peirce spaces 1, 1/2, 0 of the tripotent at alpha_7 (<gamma, alpha_7> = 2, 1, 0); every root of the 27 has a Peirce 1/2 space of 16 roots, and alpha_7 is the only one whose Peirce 1/2 space is the level c6 = 1')
chk('bit', shift == set(g1[6]) and not set(L1) & set(g1[6]) and {labels(r) for r in g1[6]} == {labels(r) for r in L1},
    'the level c6 = 1 of the 27 is alpha_7 + (the grade-1 16 of e6, coefficient 1 on alpha_6 and 0 on alpha_7, the 16 that baez_check.py E2c matches with the even labels): a different set of roots (disjoint), the same 16 D5 weights')
# the 10 under A4 and A2 + A1
lev10 = {}
for r in L2: lev10.setdefault(c(r, 5), []).append(r)
W4 = [refl(i) for i in (0, 1, 2, 3)]
A4I = [0, 2, 3, 1]                                                   # the A4 chain alpha_1 - alpha_3 - alpha_4 - alpha_2
d10 = {k: (len(v), orbit(v[0], W4) == set(v), [labels(r, A4I) for r in v if all(x >= 0 for x in labels(r, A4I))]) for k, v in sorted(lev10.items())}
ks = sorted(lev10)
okA4 = len(ks) == 2 and ks[1] == ks[0] + 1 and all(n_ == 5 and o for n_, o, _ in d10.values()) and sorted(tuple(d[2]) for d in d10.values()) == [((0, 0, 0, 1),), ((1, 0, 0, 0),)]
sm = {}
for k, v in sorted(lev10.items()):
    sub = {}
    for r in v: sub.setdefault(c(r, 4), []).append(r)
    sm[k] = sorted((len(u), orbit(u[0], [refl(0), refl(2)]) == set(u) and all(int(ip(r, S8[1])) == 0 for r in u) if len(u) == 3
                    else orbit(u[0], [refl(1)]) == set(u) and all(int(ip(r, S8[0])) == 0 and int(ip(r, S8[2])) == 0 for r in u)) for u in sub.values())
chk('bit', okA4 and all(v == [(2, True), (3, True)] for v in sm.values()),
    'the 10 graded by the coefficient of alpha_5: 5 + 5 roots at %s, each one W(A4) orbit with dominant weights %s on the chain (alpha_1, alpha_3, alpha_4, alpha_2): the 5 and the 5-bar; each 5 graded by alpha_4 is 3 + 2: a W(A2) orbit of 3 with su(2) label 0 and a W(A1) orbit of 2 with su(3) labels 0: (3,1) + (1,2)'
    % (ks, [d[2][0] for d in d10.values()]))

# ===================================================================================== B. the standard route
head('B. [std] The Cartan matrix of E7 by hand, the positive roots by the reflection algorithm, the same counts')
EDG7 = [(1, 3), (3, 4), (4, 5), (5, 6), (6, 7), (2, 4)]
C7 = [[2 if i == j else (-1 if (i + 1, j + 1) in EDG7 or (j + 1, i + 1) in EDG7 else 0) for j in range(7)] for i in range(7)]
def lab7(cv, j): return sum(cv[i] * C7[i][j] for i in range(7))      # <beta, alpha_j> (simply laced, C symmetric)
simple = [tuple(int(i == j) for j in range(7)) for i in range(7)]
pos = set(simple); layer = list(simple)
while layer:
    nxt = []
    for b in layer:
        for j in range(7):
            p = 0
            while tuple(b[i] - (p + 1) * (i == j) for i in range(7)) in pos: p += 1
            if p - lab7(b, j) > 0:
                nb = tuple(b[i] + (i == j) for i in range(7))
                if nb not in pos: pos.add(nb); nxt.append(nb)
    layer = nxt
hi = max(pos, key=sum)
roots7 = pos | {tuple(-x for x in b) for b in pos}
chk('std', len(pos) == 63 and len(roots7) == 126 and hi == (2, 2, 3, 4, 3, 2, 1) and max(b[6] for b in pos) == 1,
    'E7 Cartan matrix (chain 1-3-4-5-6-7, node 2 on node 4): %d positive roots by root strings, %d roots, highest root %s, the coefficient of alpha_7 at most 1' % (len(pos), len(roots7), hi))
T27 = [b for b in pos if b[6] == 1]
lv = Counter(b[5] for b in T27)
def refl7(j): return lambda b: tuple(b[i] - lab7(b, j) * (i == j) for i in range(7))
W5s = [refl7(j) for j in range(5)]
def dstd(L):
    labs = [tuple(lab7(b, j) for j in range(5)) for b in L]
    return dict(n=len(L), one_orbit=(orbit(L[0], W5s) == set(L)) if L else False, dom=[l for l in labs if all(x >= 0 for x in l)])
S0, S1, S2 = ([b for b in T27 if b[5] == k] for k in range(3))
ds1, ds2 = dstd(S1), dstd(S2)
IE6s = inv_exact([[C7[i][j] for j in range(6)] for i in range(6)])
qs = {b: 4 - 3 * b[5] for b in T27}
okqs = sum(qs.values()) == 0 and all(qs[b] == -3 * sum(IE6s[j][5] * lab7(b, j) for j in range(6)) for b in T27)
chk('std', (lv[0], lv[1], lv[2]) == (1, 16, 10) and ds1['one_orbit'] and ds1['dom'] == [(0, 1, 0, 0, 0)] and ds2['one_orbit'] and ds2['dom'] == [(1, 0, 0, 0, 0)] and S0 == [simple[6]] and okqs,
    'the 27 positive roots with coefficient 1 on alpha_7, graded by alpha_6: %s; the 16 one W(D5) orbit with dominant labels %s, the 10 one orbit with %s, the singlet alpha_7; q = 4 - 3 c6 sums to 0 and equals -3 <beta, omega_6>' % ((lv[0], lv[1], lv[2]), ds1['dom'], ds2['dom']))
bit27 = {tuple(c(r, k) for k in range(1, 8)) for r in G27}
chk('bit==std', bit27 == set(T27) and counts == (lv[0], lv[1], lv[2]) and (d1['dom'], d2['dom']) == (ds1['dom'], ds2['dom'])
    and all(qv[r] == qs[tuple(c(r, k) for k in range(1, 8))] for r in G27),
    'the 27 coefficient vectors of the bit route (roots from bit labels, exact solve) are the 27 of the Cartan-matrix route as sets; the counts by c6, the dominant weights and the charges agree')
P7 = {k: {b for b in T27 if sum(b[i] * C7[i][j] * simple[6][j] for i in range(7) for j in range(7)) == k} for k in (2, 1, 0)}
chk('bit==std', P7[2] == set(S0) and P7[1] == set(S1) and P7[0] == set(S2), 'Cartan-matrix inner products: <beta, alpha_7> = 2, 1, 0 on the levels c6 = 0, 1, 2, the Peirce spaces of the bit route')

# ===================================================================================== C. controls
head('C. Controls: the other D5 of E6 (alpha_1), the Levi A5 (alpha_2)')
L1g = Counter(b[0] for b in T27); L2g = Counter(b[1] for b in T27)
W5o = [refl7(j) for j in (1, 2, 3, 4, 5)]                            # the other D5 = {alpha_2, ..., alpha_6}
lv1 = {k: [b for b in T27 if b[0] == k] for k in range(3)}
orb1 = {k: (orbit(v[0], W5o) == set(v)) if v else False for k, v in lv1.items()}
q1 = {b: 3 * b[0] - 2 for b in T27}
chk('ctl', (L1g[0], L1g[1], L1g[2]) == (10, 16, 1) and all(orb1.values()) and sum(q1.values()) == 0 and lv1[2] == [hi],
    'graded by alpha_1 the 27 has %s roots at c1 = 0, 1, 2: the same 1 + 16 + 10, one orbit each of the other D5 {alpha_2..alpha_6}, in the opposite order, the singlet (the highest root of the 27) on the top level; the charge 3 c1 - 2 sums to 0 as well; so the counts by c = 0, 1, 2 are not (1, 16, 10): the order of the levels names the D5' % ((L1g[0], L1g[1], L1g[2]),))
chk('ctl', (L2g[0], L2g[1], L2g[2]) == (6, 15, 6), 'graded by alpha_2 (Levi A5 of E6): %s roots at c2 = 0, 1, 2, not 1 + 16 + 10 (15 + 12, the 12 split as 6 + 6 over two levels)' % ((L2g[0], L2g[1], L2g[2]),))

finish(STEP)
