#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""kep_orbits.py: Kepler orbits through Fock's map (one orbit per energy class, numerically) and Rutherford's deflection from the
Laplace-Runge-Lenz vector (exact).      python3 kep_orbits.py [--fault CSIGN|NOREPAR|HALF|NOJAC]

kpg·10 (Fock and Moser, numerically).  [std] scipy solve_ivp (DOP853, rtol = atol = 1e-12) of x'' = -k x/(mu r^3) with mu = k = 1 for one orbit
   each with E < 0 (ellipse), E = 0 (parabola) and E > 0 (hyperbola), in a plane tilted out of every coordinate plane, 400 samples, with the
   extra variable s, ds/dt = 1/(mu r). Fock's map F_c(p) = (c - |p|^2, 2p)/(c + |p|^2), c = -2 mu E: the samples lie on z0^2 + c|z|^2 = 1, in one
   2-plane through the origin of R^4 (the third singular value of the 4 x 400 sample matrix over the first below 1e-9): a great circle of
   S^3, a line of the hyperplane z0 = -1, a plane section of the hyperboloid; and |dF/ds| = 1 in the target metric |dz|^2 + dz0^2/c (|dz|^2 at
   c = 0), dF along the flow by central differences of F (step 1e-6), tolerance 1e-6: unit speed after the time change ds = dt/(mu r).
   [bit] [bit==std] the bit rule (bitcliff.Alg with float coefficients): in u = (z0/sqrt|c|, z) the target is the sphere u.u = 1/c with
   squares (1, 1, 1, 1) for E < 0 and the hyperboloid with squares (-1, 1, 1, 1) for E > 0; the rotor R(s) = exp(-+ s B/(2 rho)) of the unit
   bivector B of u(0) ^ u'(0) (rho = 1/sqrt|c|; cos/sin and cosh/sinh closed forms) carries u(0) to the Fock image at every sample (R u(0) R~,
   tolerance 1e-8): the hodograph is the orbit of one rotation (E < 0) or one boost (E > 0) of the bit rule.
   Wire: bd·kep·3 to bd·kep·6 (selfcheck/bridges/kep_fock.py) decide the same symbolically for every orbit (n = 2, 3, all three signs of E), and
   bd·kep·4 the isometry algebra. The reparametrisation theorem (the flow with collisions, Moser's regularisation) is recalled: V. Fock, Zur
   Theorie des Wasserstoffatoms; J. Moser, Regularization of Kepler's problem and the averaging method on a manifold.
kpg·11 (Rutherford, exact).  Rational data (mu, k, E > 0, b) with 2 mu E a rational square (p_inf rational), attractive and repulsive k:
   incoming p = p_inf (1, 0) at y = b, L_z = -b p_inf; the Runge-Lenz vector of the incoming asymptote A_in = (mu k, p_inf^2 b); the outgoing
   direction e solves A_in = p_inf L_z (e_y, -e_x) - mu k e (a 2 x 2 rational solve) and is the rotation of (1, 0) by theta with
   tan(theta/2) = -k/(2 E b) (|tan(theta/2)| = |k|/(2Eb), towards the centre for k > 0): cos theta = (1 - t^2)/(1 + t^2), sin theta = 2t/(1 + t^2),
   exactly; |e| = 1; e^2 = 1 + 2 E L^2/(mu k^2) = 1 + 1/t^2 and |A|^2 = mu^2 k^2 e^2. The cross section: with u = |tan(theta/2)|,
   b = |k|/(2 E u), b db/d(cos theta) = (k/(4E))^2/sin^4(theta/2) as an identity of rational functions of u (exact polynomial arithmetic).
kpg·12 [std] numerically: orbits from r = 10^7 to r = 10^7 (scipy, rtol 1e-12) give theta within 1e-5 of 2 arctan(k/(2Eb)), and
   b/(sin theta |dtheta/db|) by central differences (step 1e-4 b) within 1e-4 (relative) of the Rutherford formula, three (k, E, b).
   The quantum part of the statement (scattering states as unitary representations of so(3,1), the S-matrix phases) is not computed;
   recalled: M. Bander and C. Itzykson, Group theory and the hydrogen atom. so(3,1) for E > 0 is checked in kep_pauli.py (kpg·1).
Controls ([ctl]; each --fault puts the wrong version into the main line, which must then FAIL): CSIGN Fock's map with c = +2 mu E (E != 0):
   not in a plane; NOREPAR the speed in t: |dF/dt| != 1; HALF tan(theta) = -k/(2Eb) in place of tan(theta/2): the Runge-Lenz vectors differ;
   NOJAC b/sin(theta) without |db/dtheta|: not the cross section.
The script builds no object of the gravity engine (Forms, Lie, Grav): the engine faults M1-M8 do not reach it; its controls are its own.
Command: python3 kep_orbits.py (from this folder, or python3 selfcheck/proofs/kep_orbits.py from the package root; numpy, scipy)."""
import os, sys, math
from fractions import Fraction as Fr
import numpy as np
from scipy.integrate import solve_ivp

_here = os.path.dirname(os.path.abspath(__file__))
_bc = os.path.join(os.path.dirname(_here), 'steps15_17')
if not os.path.isfile(os.path.join(_bc, 'bitcliff.py')): raise SystemExit('bitcliff.py not found in ' + _bc + ': this file belongs in selfcheck/proofs/ of the package')
if _bc not in sys.path: sys.path.insert(0, _bc)
from bitcliff import Alg

FAILS = []; COUNT = [0, 0]
def chk(tag, cond, msg):
    cond = bool(cond)
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    COUNT[0 if cond else 1] += 1
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nchecks: %d ok, %d FAIL' % tuple(COUNT))
    print('FAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)
ARGS = sys.argv[1:]
FAULTS = ('CSIGN', 'NOREPAR', 'HALF', 'NOJAC')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))

# ================================================================================================ kpg·10: one orbit per energy class
def rot_tilt():
    a, b, c = 0.7, -1.1, 0.4                                                 # a fixed rotation: the orbit plane is no coordinate plane
    Rz = lambda t: np.array([[math.cos(t), -math.sin(t), 0], [math.sin(t), math.cos(t), 0], [0, 0, 1]])
    Rx = lambda t: np.array([[1, 0, 0], [0, math.cos(t), -math.sin(t)], [0, math.sin(t), math.cos(t)]])
    return Rz(a) @ Rx(b) @ Rz(c)
def flow(t, y, mu=1.0, k=1.0):
    x, v = y[:3], y[3:6]; r = np.linalg.norm(x)
    return np.concatenate([v, -k * x / (mu * r ** 3), [1.0 / (mu * r)]])
def fock(p, c):
    q = p @ p; return np.concatenate([[c - q], 2 * p]) / (c + q)
def orbit(v0, tspan, n=400):
    Q = rot_tilt(); x0 = Q @ np.array([1.0, 0.0, 0.0]); u0 = Q @ np.array([0.0, v0, 0.0])
    ts = np.linspace(tspan[0], tspan[1], n)
    fw = solve_ivp(flow, (0, tspan[1]), np.concatenate([x0, u0, [0.0]]), method='DOP853', rtol=1e-12, atol=1e-12, dense_output=True)
    bw = solve_ivp(flow, (0, tspan[0]), np.concatenate([x0, u0, [0.0]]), method='DOP853', rtol=1e-12, atol=1e-12, dense_output=True)
    Y = np.array([fw.sol(t) if t >= 0 else bw.sol(t) for t in ts])
    E = 0.5 * u0 @ u0 - 1.0
    return Y, E
def fock_checks(Y, E, csign=1, repar=True):
    c = -2 * E * csign; P = Y[:, 3:6]; Z = np.array([fock(p, c) for p in P])
    quad = float(np.max(np.abs(Z[:, 0] ** 2 + c * np.sum(Z[:, 1:] ** 2, axis=1) - 1)))
    sv = np.linalg.svd(Z.T, compute_uv=False); planar = float(sv[2] / sv[0])
    worst = 0.0; h = 1e-6
    for y in Y:
        x, p = y[:3], y[3:6]; r = np.linalg.norm(x); pdot = -x / r ** 3
        dz = (fock(p + h * pdot, c) - fock(p - h * pdot, c)) / (2 * h)              # dF/dt along the flow
        sp2 = dz[1:] @ dz[1:] + (dz[0] ** 2 / c if abs(c) > 1e-14 else 0.0)
        speed = math.sqrt(sp2) * (r if repar else 1.0)                                  # |dF/ds| = |dF/dt| mu r
        worst = max(worst, abs(speed - 1))
    return quad, planar, worst, Z, c
def rotor_check(Y, Z, c):
    """the bit-rule rotation (c > 0) or boost (c < 0) of the unit bivector of u(0) ^ u'(0) carries u(0) to the Fock image at every sample"""
    sq = (1, 1, 1, 1) if c > 0 else (-1, 1, 1, 1); Al = Alg(sq); rho = 1 / math.sqrt(abs(c))
    U = Z.copy(); U[:, 0] = Z[:, 0] / math.sqrt(abs(c)); S = Y[:, 6]
    i0 = int(np.argmin(np.abs(S))); u0 = U[i0]
    x, p = Y[i0, :3], Y[i0, 3:6]; r = np.linalg.norm(x); pdot = -x / r ** 3; h = 1e-6
    dz = (fock(p + h * pdot, c) - fock(p - h * pdot, c)) / (2 * h) * r                    # dF/ds = dF/dt mu r
    du = dz.copy(); du[0] = dz[0] / math.sqrt(abs(c))
    g = np.array(sq, dtype=float); du = du - (du * g) @ u0 / ((u0 * g) @ u0) * u0              # tangent: orthogonal to u0 in the metric
    vec = lambda w: {1 << i: float(w[i]) for i in range(4) if w[i] != 0}
    a, b = vec(u0), vec(du); Bv = Al.scal(Al.add(Al.mul(a, b), Al.mul(b, a), -1), 0.5)
    B2 = Al.mul(Bv, Bv).get(0, 0.0); Bh = Al.scal(Bv, 1 / math.sqrt(abs(B2)))
    worst = 0.0
    for s_, u in zip(S - S[i0], U):
        ph = s_ / rho
        if c > 0: R = Al.add({0: math.cos(ph / 2)}, Al.scal(Bh, -math.sin(ph / 2)))
        else: R = Al.add({0: math.cosh(ph / 2)}, Al.scal(Bh, math.sinh(ph / 2)))
        Rr = {m: v * (1 if bin(m).count('1') % 4 in (0, 1) else -1) for m, v in R.items()}
        img = Al.mul(Al.mul(R, a), Rr); w = np.array([img.get(1 << i, 0.0) for i in range(4)])
        worst = max(worst, float(np.max(np.abs(w - u))))
    return worst, (B2 < 0) if c > 0 else (B2 > 0)
def part10():
    head('kpg·10: one Kepler orbit per energy class through Fock\'s map, numerically [std]; the hodograph as a bit-rule rotor orbit [bit] [bit==std]')
    cases = [('E < 0 (ellipse)', 0.8, (-2.0, 2.0)), ('E = 0 (parabola)', math.sqrt(2.0), (-3.0, 3.0)), ('E > 0 (hyperbola)', 1.8, (-3.0, 3.0))]
    res = {}
    for name, v0, tsp in cases:
        Y, E = orbit(v0, tsp); cs = -1 if (FAULT == 'CSIGN' and abs(E) > 1e-9) else 1
        quad, planar, worst, Z, c = fock_checks(Y, E, csign=cs, repar=(FAULT != 'NOREPAR')); res[name] = (E, quad, planar, worst, Y, Z, c)
    okq = all(r[1] < 1e-9 for r in res.values()); okp = all(r[2] < 1e-9 for r in res.values()); oks = all(r[3] < 1e-6 for r in res.values())
    txt = '; '.join('%s: E = %.4f, quadric %.1e, plane %.1e, speed %.1e' % (n, r[0], r[1], r[2], r[3]) for n, r in res.items())
    chk('std', okq, 'Fock\'s image of the momentum lies on z0^2 + c|z|^2 = 1, c = -2 mu E, for the three orbits (400 samples each, 1e-9): ' + txt)
    chk('std', okp, 'the image lies in one 2-plane through the origin of R^4 (third singular value / first below 1e-9): a great circle of S^3 (E < 0), a line of z0 = -1 (E = 0), a geodesic of the hyperboloid (E > 0)')
    chk('std', oks, '|dF/ds| = 1 in the target metric |dz|^2 + dz0^2/c with ds = dt/(mu r), at every sample of the three orbits (tolerance 1e-6): unit-speed geodesics after the time change')
    wr = {}; okB = True
    for name in ('E < 0 (ellipse)', 'E > 0 (hyperbola)'):
        E, quad, planar, worst, Y, Z, c = res[name]; w, typ = rotor_check(Y, Z, c); wr[name] = w; okB &= typ
    chk('bit', okB, 'the unit bivector of u(0) ^ u\'(0) squares to -1 on the sphere (squares (1,1,1,1): a rotation) and to +1 on the hyperboloid (squares (-1,1,1,1): a boost)')
    chk('bit==std', all(w < 1e-8 for w in wr.values()), 'R(s) u(0) R(s)~ with R = exp(-+ s B/(2 rho)) reproduces the Fock image of the integrated orbit at all 400 samples: deviation %s (tolerance 1e-8)' % ', '.join('%s %.1e' % (n.split()[0] + n.split()[1] + n.split()[2], w) for n, w in wr.items()))
    Y, E = orbit(0.8, (-2.0, 2.0)); q2, p2, w2, _, _ = fock_checks(Y, E, csign=-1); Y3, E3 = orbit(1.8, (-3.0, 3.0)); q3, p3, w3, _, _ = fock_checks(Y3, E3, csign=-1)
    chk('ctl', p2 > 1e-4 and p3 > 1e-4, 'Fock\'s map with the wrong sign c = +2 mu E: the image leaves every 2-plane through the origin (third / first singular value %.1e for the ellipse, %.1e for the hyperbola)' % (p2, p3))
    _, _, wt, _, _ = fock_checks(Y, E, repar=False)
    chk('ctl', wt > 1e-2, 'the speed in t instead of s (no time change): |dF/dt| deviates from 1 by up to %.2f on the ellipse' % wt)

# ================================================================================================ kpg·11: Rutherford, exact
DATA = [(Fr(1), Fr(1), Fr(1, 2), Fr(1)), (Fr(2), Fr(3), Fr(1), Fr(1, 2)), (Fr(1, 2), Fr(1), Fr(9), Fr(1, 5)), (Fr(3, 2), Fr(2, 3), Fr(3), Fr(2)),
        (Fr(1), Fr(-1), Fr(1, 2), Fr(1)), (Fr(2, 3), Fr(-2), Fr(3, 4), Fr(1, 3))]
def sqrt_fr(q):
    for d in range(1, 200):
        n2 = q * d * d
        if n2.denominator == 1:
            n = int(round(math.sqrt(n2.numerator)))
            if n * n == n2.numerator: return Fr(n, d)
    raise ValueError('not a rational square')
def part11():
    head('kpg·11: Rutherford\'s deflection from the Laplace-Runge-Lenz vector, exact at rational data [std]')
    okA = okE = okU = True; rows = []
    for mu, k, E, b in DATA:
        pinf = sqrt_fr(2 * mu * E); Lz = -b * pinf
        Ain = (mu * k, pinf * pinf * b)
        M = [[-mu * k, pinf * Lz], [-pinf * Lz, -mu * k]]                           # A = p_inf L_z (e_y, -e_x) - mu k e  as M e
        det = M[0][0] * M[1][1] - M[0][1] * M[1][0]
        ex = (Ain[0] * M[1][1] - M[0][1] * Ain[1]) / det; ey = (M[0][0] * Ain[1] - M[1][0] * Ain[0]) / det
        t = -k / (2 * E * b)
        if FAULT == 'HALF':                                                          # the wrong version: tan(theta) = -k/(2Eb) (floats: cos, sin are irrational)
            thw = math.atan(float(t)); okA &= abs(float(ex) - math.cos(thw)) < 1e-12 and abs(float(ey) - math.sin(thw)) < 1e-12
        else:
            cth, sth = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t); okA &= ex == cth and ey == sth
        okU &= ex * ex + ey * ey == 1
        L2 = Lz * Lz; ecc2 = 1 + 2 * E * L2 / (mu * k * k); A2 = Ain[0] ** 2 + Ain[1] ** 2
        tt = -k / (2 * E * b); okE &= ecc2 == 1 + 1 / (tt * tt) and A2 == mu * mu * k * k * ecc2
        rows.append('(mu, k, E, b) = (%s, %s, %s, %s): tan(theta/2) = %s' % (mu, k, E, b, tt))
    chk('std', okU, 'the outgoing direction solved from A_in = A_out (a 2 x 2 rational system) is a unit vector at the six data sets')
    chk('std', okA, 'it is the rotation of the incoming direction by theta with tan(theta/2) = -k/(2Eb): ' + '; '.join(rows) + (' [fault HALF]' if FAULT == 'HALF' else ''))
    chk('std', okE, 'e^2 = 1 + 2E L^2/(mu k^2) = 1 + 1/tan^2(theta/2) and |A|^2 = mu^2 k^2 e^2 at the six data sets (exact)')
    # the cross section as an identity of rational functions of u = |tan(theta/2)|
    def padd(a, b, s=1):
        n = max(len(a), len(b)); return [(a[i] if i < len(a) else 0) + s * (b[i] if i < len(b) else 0) for i in range(n)]
    def pmul(a, b):
        out = [Fr(0)] * (len(a) + len(b) - 1)
        for i, x in enumerate(a):
            for j, y in enumerate(b): out[i + j] += x * y
        return out
    def pder(a): return [i * a[i] for i in range(1, len(a))] or [Fr(0)]
    def peq(a, b): d = padd(a, b, -1); return all(x == 0 for x in d)
    def rder(N, D): return padd(pmul(pder(N), D), pmul(N, pder(D)), -1), pmul(D, D)
    okX = True
    for mu, k, E, b in DATA:
        kap = abs(k) / (2 * E)
        bN, bD = [kap], [Fr(0), Fr(1)]                                               # b = kap/u
        cN, cD = [Fr(1), Fr(0), Fr(-1)], [Fr(1), Fr(0), Fr(1)]                       # cos theta = (1 - u^2)/(1 + u^2)
        dbN, dbD = rder(bN, bD); dcN, dcD = rder(cN, cD)
        # b db/dcos = (bN/bD) (dbN/dbD) / (dcN/dcD)
        lhsN = pmul(pmul(bN, dbN), dcD); lhsD = pmul(pmul(bD, dbD), dcN)
        if FAULT == 'NOJAC':                                                         # b / sin(theta), sin theta = 2u/(1 + u^2)
            lhsN = pmul(bN, [Fr(1), Fr(0), Fr(1)]); lhsD = pmul(bD, [Fr(0), Fr(2)])
        rhsN = pmul([(k / (4 * E)) ** 2], pmul([Fr(1), Fr(0), Fr(1)], [Fr(1), Fr(0), Fr(1)])); rhsD = [Fr(0)] * 4 + [Fr(1)]   # (k/4E)^2 (1+u^2)^2/u^4
        okX &= peq(pmul(lhsN, rhsD), pmul(rhsN, lhsD))
    chk('std', okX, 'b db/d(cos theta) = (k/(4E))^2/sin^4(theta/2) as rational functions of u = |tan(theta/2)| (b = |k|/(2Eu); exact polynomials) at the six (k, E)' + (' [fault NOJAC]' if FAULT == 'NOJAC' else ''))
    mu, k, E, b = DATA[0]; thw = math.atan(float(-k / (2 * E * b))); cth, sth = math.cos(thw), math.sin(thw)
    pinf = sqrt_fr(2 * mu * E); Lz = float(-b * pinf); Aout = (float(pinf) * Lz * sth - float(mu * k) * cth, -float(pinf) * Lz * cth - float(mu * k) * sth)
    dev = max(abs(Aout[0] - float(mu * k)), abs(Aout[1] - float(pinf * pinf * b)))
    chk('ctl', dev > 1e-3, 'tan(theta) = -k/(2Eb) in place of tan(theta/2): the outgoing Runge-Lenz vector (%.4f, %.4f) differs from the incoming (%s, %s) by %.3f' % (Aout[0], Aout[1], mu * k, pinf * pinf * b, dev))

# ================================================================================================ kpg·12: Rutherford numerically
def deflect(k, E, b, mu=1.0, R0=1e7):
    pin = math.sqrt(2 * mu * (E + k / math.hypot(R0, b))); y0 = np.array([-R0, b, 0.0, pin / mu, 0.0, 0.0, 0.0])
    def far(t, y, *a): return np.linalg.norm(y[:3]) - R0 * 1.0000001
    far.terminal = True; far.direction = 1
    sol = solve_ivp(flow, (0, 10 * R0 / (pin / mu)), y0, method='DOP853', rtol=1e-12, atol=1e-9, events=far, args=(mu, k))
    v = sol.y[3:6, -1]; return math.atan2(v[1], v[0])
def part12():
    head('kpg·12: Rutherford numerically: orbits from r = 1e7 to r = 1e7 (scipy) [std]')
    okT = okX = True; info = []
    for k, E, b in ((1.0, 0.5, 1.0), (1.0, 2.0, 0.3), (-1.0, 0.5, 1.0)):
        th = deflect(k, E, b); want = -2 * math.atan(k / (2 * E * b)); okT &= abs(th - want) < 1e-5
        h = 1e-4 * b; dth = (deflect(k, E, b + h) - deflect(k, E, b - h)) / (2 * h)
        num = b / (abs(math.sin(th)) * abs(dth)) if FAULT != 'NOJAC' else b / abs(math.sin(th))
        ruth = (k / (4 * E)) ** 2 / math.sin(th / 2) ** 4; okX &= abs(num / ruth - 1) < 1e-4
        info.append('(k, E, b) = (%g, %g, %g): theta = %.8f (formula %.8f), cross section ratio %.7f' % (k, E, b, th, want, num / ruth))
    chk('std', okT, 'the numerical deflection equals -2 arctan(k/(2Eb)) within 1e-5: ' + '; '.join(i.split(', cross')[0] for i in info))
    chk('std', okX, 'b/(sin theta |dtheta/db|) by central differences equals (k/(4E))^2/sin^4(theta/2) within 1e-4 (relative): ' + '; '.join(i.split('cross section ')[1] for i in info))

def main():
    head('KPG-ORBITS: Kepler orbits through Fock\'s map and Rutherford\'s deflection' + (' [fault %s]' % FAULT if FAULT else ''))
    part10(); part11(); part12()

if __name__ == '__main__':
    main(); finish('KPG-ORBITS' + ('-' + FAULT if FAULT else ''))
