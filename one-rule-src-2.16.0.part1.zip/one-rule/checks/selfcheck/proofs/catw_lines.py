#!/usr/bin/env python3
# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Required Notice: Copyright (c) 2026 the Cascade Atlas authors
# Free for noncommercial use only, not for commercial use. Terms: https://polyformproject.org/licenses/noncommercial/1.0.0 (see LICENSE)
"""catw_lines.py: the Bianchi map on Sym^2(Lambda^2), the cubic Casimir of su(3) on the 3 and the 3-bar, and the 6 + 12 + 3 split of the
21 area-metric cells under a change of frame.      python3 catw_lines.py [--fault SYMB|L3|SIMPLE|TRACE|BAR|PERM|CLASS|MINOR]

B. Statement (catl.B1..B6).  For n = 2..8 the map b: Sym^2(Lambda^2 V) -> Lambda^4 V, b(alpha . beta) = alpha ^ beta, has rank C(n,4), so it is
   onto Lambda^4; its kernel is cut out by the cyclic (first Bianchi) constraints restricted to Sym^2(Lambda^2) (the two have one row space) and has
   dimension n^2(n^2-1)/12, the dimension of the engine's space of curvature tensors; the 4-form part iota(Lambda^4) has b(iota(w)) = 3w, so
   Sym^2(Lambda^2) = ker b + iota(Lambda^4) (direct); on ker b the Ricci contraction has rank n(n+1)/2 for n >= 3 and rank 1 at n = 2 (the scalar
   alone), and its kernel (Weyl) has dimension n(n+1)(n+2)(n-3)/12 for n >= 3 (0 at n = 2 and 3, 10 at n = 4: 21 = 20 + 1, 20 = 10 + 10); for
   bivectors B, B^2 = <B^2>_0 + B ^ B with no grade-2 part, and B ^ B = b(B . B).
   [bit]  gravity_selfcheck.curvature_space(n), counts(n), pair_classes(4) and the engine's exact rank_and_null; the exterior product is the bit rule
          with every generator null, BR((0,...,0)) of researchers_checks/bitrule_A.py, and B^2 is computed with BR(eps) in several signatures.
   [std]  numpy: the Bianchi map of 4-index tensors (total antisymmetrisation by the 24 permutation signs), matrix_rank, the null space by SVD,
          the Ricci contraction, the Kulkarni-Nomizu image of Sym^2 V inside ker b, the closed forms.
C. Statement (catl.C1..C5).  With kappa(X,Y) = 2 tr_3(XY), D(X,Y,Z) = 2 tr_3(X{Y,Z}), F(X,Y,Z) = kappa([X,Y],Z) (for T_a = lambda_a/2: delta_ab,
   the Gell-Mann d_abc and i f_abc) and C_t = sum t(X^a,X^b,X^c) X_a X_b X_c over a kappa-dual pair of bases: on the 3 and the 3-bar of su(3)
   C_D = 10/9 and -10/9, C_F = -2 on both (-3/2 times the quadratic Casimir, 4/3 on both), the unsymmetrised trace tensor 4 tr_3(XYZ) = D + F
   gives -8/9 and -28/9 and the ordered product sum E_ij E_jk E_ki of the traceless generators 56/9 and 16/9 (both tell the two apart through
   their symmetric part); the highest weights are (1,0) and (0,1).
   [bit]  the 32 five-bit labels: a_i flips bit i with the Jordan-Wigner sign (exact integer matrices), E_ij = a_i^+ a_j on the colour bits
          2, 3, 4; the three tensors taken on the one-colour-bit labels; every operator on all 32 labels, read per colour count.
   [std]  3 x 3 rational matrices, the 3-bar as -X^T; numpy Gell-Mann matrices with d_abc = tr(lambda_c {lambda_a, lambda_b})/4 (floats).
S. Statement (catl.S1..S5).  The 21 cells {P, Q} of the six coordinate planes of a 4-space are 6 vertex (P = Q), 12 edge (one shared index) and 3
   antipodal (disjoint); rational rotors of Cl(1,3) (time +1) and Cl(4,0), acting by X -> R X R~ on the planes and G -> M G M^T on the 21, take a
   tensor on one vertex cell, or on one antipodal cell, to one with support on all three classes; every class is left by some generator e_ab;
   the 384 signed permutations of the axes keep every class; a boost in the plane of a cell keeps that cell.
   [bit]  BR((1,-1,-1,-1)) and BR((1,1,1,1)): rotors a + b e_P with a^2 -+ b^2 = 1, their adjoint 6 x 6 matrices, supports and class weights
          (sums of squared coefficients) exactly.
   [std]  4 x 4 Lorentz and rotation matrices (cosh 17/8, sinh 15/8; cos -7/25, sin 24/25), L^T eta L = eta, the 6 x 6 matrix of 2 x 2 minors,
          the 21 x 21 matrix of G -> L G L^T and its blocks between classes.
Controls ([ctl], each with a --fault that puts the wrong version in the main lines, which must then FAIL):
   SYMB   b with the product of the symmetric algebra (x_P x_Q, non-zero on shared indices): rank 19, kernel 2 at n = 4, not 1 and 20;
   L3     the target Lambda^3 instead of Lambda^4: 21 - 4 = 17, not 20, at n = 4;
   SIMPLE only simple bivectors: B ^ B = 0 for all of them, so the identity B ^ B = b(B . B) would be 0 = 0; the run needs non-simple ones;
   TRACE  the trace tensor in place of D: the values are not opposite;
   BAR    the conjugate built as +X^T (a wrong version, not a representation): it repeats the value of the 3;
   PERM   a signed permutation in place of the rotors: no class is left; CLASS  disjoint pairs counted as edges: 6 + 15 + 0;
   MINOR  the minors with a wrong sign: the 6 x 6 matrices of the two routes differ.
   Also: the quadratic Casimir is 4/3 on both (the cubic one is the odd one); D taken on the 3-bar flips the sign of c; a boost in the plane of a cell.
Scope: n = 2..8 for B (engine, own ranks and numpy alike); su(3) only for C; for S, n = 4 and the rotors listed, exact.  The gravity
engine's Forms, Lie and Grav are not used, so its eight engine faults are not seen by this script; its controls are the faults above.
Command: python3 catw_lines.py   (from this folder, or python3 selfcheck/proofs/catw_lines.py from the package root; standard library and numpy)."""
import os, sys, itertools, random
from fractions import Fraction as Fr
from math import comb, lcm
import numpy as np

_here = os.path.dirname(os.path.abspath(__file__))                       # selfcheck/proofs/
_selfcheck = os.path.dirname(_here)                                        # selfcheck/
_researchers = os.path.join(os.path.dirname(_selfcheck), 'researchers_checks')
for _p, _f in ((_selfcheck, 'gravity_selfcheck.py'), (_researchers, 'bitrule_A.py')):
    if not os.path.isfile(os.path.join(_p, _f)): raise SystemExit(_f + ' not found in ' + _p + ': this file belongs in selfcheck/proofs/ of the package')
    sys.path.insert(0, _p)
import gravity_selfcheck as gs
from bitrule_A import BR, comm

# ------------------------------------------------------------------------------------------------ check lines
FAILS = []
def chk(tag, cond, msg):
    print('  %s [%s] %s' % ('ok  ' if cond else 'FAIL', tag, msg), flush=True)
    if not cond: FAILS.append('[%s] %s' % (tag, msg))
    return cond
def head(s): print('\n' + s, flush=True)
def finish(name):
    print('\nFAILS (%s): %s' % (name, FAILS if FAILS else 'none'), flush=True)
    sys.exit(1 if FAILS else 0)

ARGS = sys.argv[1:]
FAULTS = ('SYMB', 'L3', 'SIMPLE', 'TRACE', 'BAR', 'PERM', 'CLASS', 'MINOR')
FAULT = ARGS[ARGS.index('--fault') + 1] if '--fault' in ARGS and ARGS.index('--fault') + 1 < len(ARGS) else None
if '--fault' in ARGS and FAULT not in FAULTS: raise SystemExit('--fault takes one of ' + ', '.join(FAULTS))
NMAX = 8
pc = lambda x: bin(x).count('1')
def fr(x): return str(Fr(x))

# ================================================================================================ B. the Bianchi map
def pairs_of(n): return list(itertools.combinations(range(n), 2))
def cells_of(N): return [(p, q) for p in range(N) for q in range(p, N)]
def mask(t): return sum(1 << i for i in t)

def b_matrix(n, kind='wedge'):
    """rows: the C(n,4) basis 4-forms (or, for kind 'sym', the degree-4 monomials hit); columns: the cells {P <= Q} of Sym^2(Lambda^2);
    b(e_P . e_Q) = e_P ^ e_Q is the bit rule with every generator null (BR((0,...,0))): zero when P and Q share an index"""
    P = pairs_of(n); C = cells_of(len(P)); ext = BR((0,) * n); cols = []
    for (p, q) in C:
        if kind == 'wedge':
            cols.append(ext.mul({mask(P[p]): 1}, {mask(P[q]): 1}))                        # {mask of P u Q: sign} or {} (a shared index)
        else:                                                                            # the symmetric algebra: x_P x_Q, exponents added
            e = [0] * n
            for i in P[p] + P[q]: e[i] += 1
            cols.append({tuple(e): 1})
    keys = sorted({k for c in cols for k in c}, key=str) if kind != 'wedge' else [mask(t) for t in itertools.combinations(range(n), 4)]
    kix = {k: i for i, k in enumerate(keys)}
    rows = [[Fr(0)] * len(C) for _ in keys]
    for j, c in enumerate(cols):
        for k, v in c.items(): rows[kix[k]][j] += v
    return rows, keys, P, C

def cyclic_rows_sym(n):
    """the first Bianchi (cyclic) constraints R_{a b|c d} + R_{a c|d b} + R_{a d|b c} = 0, one row per (a, triple), as in the engine, but on the
    cell variables of Sym^2(Lambda^2) (pair symmetry imposed): rows with a repeated index vanish there"""
    P = pairs_of(n); pidx = {p: i for i, p in enumerate(P)}; C = cells_of(len(P)); cidx = {c: i for i, c in enumerate(C)}
    def var(a, b, c, d):
        if a == b or c == d: return None
        s = 1
        if a > b: a, b, s = b, a, -s
        if c > d: c, d, s = d, c, -s
        p, q = pidx[(a, b)], pidx[(c, d)]
        return s, cidx[(min(p, q), max(p, q))]
    rows = []
    for a in range(n):
        for tri in itertools.combinations(range(n), 3):
            row = [Fr(0)] * len(C)
            for (b, c, d) in ((tri[0], tri[1], tri[2]), (tri[1], tri[2], tri[0]), (tri[2], tri[0], tri[1])):
                v = var(a, b, c, d)
                if v: row[v[1]] += v[0]
            if any(row): rows.append(row)
    return rows

def iota_matrix(n):
    """iota(e_abcd) = sum over the three splittings {P, Q} of e_P . e_Q with the sign of e_P ^ e_Q = sign e_abcd: columns of a K x C(n,4) matrix"""
    P = pairs_of(n); pidx = {p: i for i, p in enumerate(P)}; C = cells_of(len(P)); cidx = {c: i for i, c in enumerate(C)}; ext = BR((0,) * n)
    Q4 = list(itertools.combinations(range(n), 4)); M = [[Fr(0)] * len(Q4) for _ in C]
    for j, (a, b, c, d) in enumerate(Q4):
        for (x, y) in (((a, b), (c, d)), ((a, c), (b, d)), ((a, d), (b, c))):
            s = ext.mul({mask(x): 1}, {mask(y): 1})[mask((a, b, c, d))]
            p, q = pidx[x], pidx[y]; M[cidx[(min(p, q), max(p, q))]][j] += s
    return M

def matmul_fr(A, B):
    return [[sum((A[i][k] * B[k][j] for k in range(len(B))), Fr(0)) for j in range(len(B[0]))] for i in range(len(A))]

def std_bianchi(n):
    """numpy: the cells as 4-index tensors T = E_P (x) E_Q + E_Q (x) E_P (E_P the skew matrix of the plane); the Bianchi map is the total
    antisymmetrisation by the 24 permutation signs, read on a < b < c < d; returns (dims, ricci rank, weyl, KN rank, KN + Weyl rank)"""
    P = pairs_of(n); C = cells_of(len(P))
    def E(p):
        m = np.zeros((n, n)); i, j = P[p]; m[i, j], m[j, i] = 1, -1; return m
    T = np.array([(np.einsum('ab,cd->abcd', E(p), E(q)) + np.einsum('ab,cd->abcd', E(q), E(p))).ravel() for (p, q) in C]).T   # n^4 x K
    perms = list(itertools.permutations(range(4)))
    sgn = lambda s: (-1) ** sum(1 for i in range(4) for j in range(i + 1, 4) if s[i] > s[j])
    Q4 = list(itertools.combinations(range(n), 4)); idx = lambda t: ((t[0] * n + t[1]) * n + t[2]) * n + t[3]
    Bm = np.zeros((max(len(Q4), 1), len(C)))
    for r, q in enumerate(Q4):
        for s in perms: Bm[r] += sgn(s) * T[idx(tuple(q[k] for k in s))]
    rk = np.linalg.matrix_rank(Bm) if Q4 else 0
    u, sv, vt = np.linalg.svd(Bm) if Q4 else (None, np.zeros(0), np.eye(len(C)))
    ker = vt[rk:].T if Q4 else np.eye(len(C))                                          # K x dim ker, in cell coordinates
    Kt = T @ ker                                                                       # the kernel as 4-index tensors
    R4 = Kt.reshape(n, n, n, n, -1)
    ric = np.einsum('abad k->bdk'.replace(' ', ''), R4).reshape(n * n, -1)              # Ric_bd = sum_a R_abad (metric delta)
    rr = np.linalg.matrix_rank(ric) if ric.size else 0
    weyl_basis = None
    if ker.shape[1] > rr:
        u2, s2, v2 = np.linalg.svd(ric); weyl_basis = Kt @ v2[rr:].T
    g = np.eye(n); KN = []
    for i in range(n):
        for j in range(i, n):
            h = np.zeros((n, n)); h[i, j] = h[j, i] = 1
            KN.append((np.einsum('ac,bd->abcd', h, g) + np.einsum('bd,ac->abcd', h, g) - np.einsum('ad,bc->abcd', h, g) - np.einsum('bc,ad->abcd', h, g)).ravel())
    KN = np.array(KN).T
    kn_rank = np.linalg.matrix_rank(KN)
    kn_in_ker = np.linalg.matrix_rank(np.hstack([Kt, KN])) == np.linalg.matrix_rank(Kt)
    span = np.linalg.matrix_rank(np.hstack([KN] + ([weyl_basis] if weyl_basis is not None else [])))
    return dict(K=len(C), L4=len(Q4), rank=int(rk), ker=int(len(C) - rk), ricci=int(rr), weyl=int(len(C) - rk - rr), kn=int(kn_rank), kn_in_ker=bool(kn_in_ker), kn_weyl=int(span))

def ricci_closed(n): return n * (n + 1) // 2 if n >= 3 else 1
def weyl_closed(n): return n * (n + 1) * (n + 2) * (n - 3) // 12

head('B. The Bianchi map b: Sym^2(Lambda^2 V) -> Lambda^4 V, b(alpha . beta) = alpha ^ beta, n = 2..%d' % NMAX)
table = []
for n in range(2, NMAX + 1):
    rows_b, keys, P, C = b_matrix(n, 'sym' if FAULT == 'SYMB' else 'wedge')
    K = len(C); L4 = comb(n, 4); target = comb(n, 3) if FAULT == 'L3' else L4
    rk_b = gs.rank_and_null(rows_b, K)[0] if rows_b else 0
    cyc = cyclic_rows_sym(n)
    rk_c = gs.rank_and_null(cyc, K)[0] if cyc else 0
    rk_cb = gs.rank_and_null(cyc + rows_b, K)[0] if (cyc or rows_b) else 0
    cnt = gs.counts(n)
    cs = gs.curvature_space(n)
    std = std_bianchi(n)
    chk('bit', rk_b == L4 and len(rows_b) == L4, 'catl.B1 n=%d: rank b = %d = C(n,4) = dim Lambda^4: b is onto Lambda^4' % (n, rk_b))
    chk('bit', rk_c == L4 and rk_cb == L4, 'catl.B2 n=%d: the cyclic constraints on Sym^2(Lambda^2) have rank %d, and stacked with b still %d: one row space, so ker(cyclic) = ker b' % (n, rk_c, rk_cb))
    dker = K - rk_b
    ok_e = cs is not None and cs['dimension'] == dker and cs['pair_symmetric']
    chk('bit', dker == cnt['riemann_independent'] == n * n * (n * n - 1) // 12 and K - target == dker and ok_e,
        'catl.B2 n=%d: dim Sym^2 = %d = dim ker b + %d; dim ker b = %d = n^2(n^2-1)/12 = curvature_space(n) of the engine (%s, pair-symmetric solutions of the cyclic identity on Lambda^2 (x) Lambda^2, which lie in ker b: equal dimension, equal space)'
        % (n, K, target, dker, cs['dimension'] if cs else 'not run'))
    if L4:
        Bi = matmul_fr(rows_b if FAULT != 'SYMB' else b_matrix(n)[0], iota_matrix(n))
        chk('bit', all(Bi[i][j] == (3 if i == j else 0) for i in range(L4) for j in range(L4)),
            'catl.B3 n=%d: b(iota(w)) = 3 w on Lambda^4 (iota(e_abcd) = e_ab.e_cd - e_ac.e_bd + e_ad.e_bc): Sym^2(Lambda^2) = ker b + iota(Lambda^4), a direct sum' % n)
    rr = cs['ricci_rank'] if cs else None; wd = cs['weyl_dimension'] if cs else None
    chk('bit', cs is not None and rr == ricci_closed(n) and wd == (weyl_closed(n) if n >= 3 else 0),
        'catl.B4 n=%d: on the curvature tensors the Ricci contraction has rank %s (%s) and Weyl has dimension %s (%s)'
        % (n, rr, 'n(n+1)/2' if n >= 3 else '1, the scalar alone, not n(n+1)/2 = 3', wd, 'n(n+1)(n+2)(n-3)/12' if n >= 3 else 'the formula gives %d' % weyl_closed(n)))
    chk('std', std['K'] == K and std['rank'] == L4 and std['ker'] == n * n * (n * n - 1) // 12 and std['ricci'] == ricci_closed(n) and std['weyl'] == (weyl_closed(n) if n >= 3 else 0),
        'catl.B1-B4 n=%d: numpy, 4-index tensors and the 24 permutation signs: rank %d, kernel %d, Ricci rank %d, Weyl %d' % (n, std['rank'], std['ker'], std['ricci'], std['weyl']))
    chk('std', std['kn_in_ker'] and std['kn'] == ricci_closed(n) and std['kn_weyl'] == std['ker'],
        'catl.B4 n=%d: the Kulkarni-Nomizu products h . g lie in ker b, have rank %d, and with Weyl span ker b (%d): ker b = Ricci part + Weyl' % (n, std['kn'], std['kn_weyl']))
    chk('bit==std', cs is not None and (dker, rr, wd) == (std['ker'], std['ricci'], std['weyl']), 'catl.B1-B4 n=%d: the two routes give the same (kernel, Ricci, Weyl) = (%d, %s, %s)' % (n, dker, rr, wd))
    table.append((n, K, L4, dker, rr, wd))
print('    n   Sym^2(L^2)  L^4   Riemann  Ricci  Weyl     closed forms: n^2(n^2-1)/12, n(n+1)/2, n(n+1)(n+2)(n-3)/12')
for (n, K, L4, dk, rr, wd) in table:
    print('    %d   %5d       %3d   %5d    %4s   %4s     %d, %d, %d' % (n, K, L4, dk, rr, wd, n * n * (n * n - 1) // 12, n * (n + 1) // 2, weyl_closed(n)))
t4 = [r for r in table if r[0] == 4][0]
chk('bit', (t4[1], t4[3], t4[2], t4[4], t4[5]) == (21, 20, 1, 10, 10) and [r[5] for r in table if r[0] in (2, 3)] == [0, 0] and all(r[5] > 0 for r in table if r[0] >= 4),
    'catl.B4: n = 4 reads 21 = 20 + 1 and 20 = 10 + 10; Weyl is 0 at n = 2 and 3 and first non-zero at n = 4; Lambda^4 is 0 below n = 4 and first non-zero at n = 4')

# B ^ B = <B^2>_4 = b(B . B), random integer bivectors, several signatures
rng = random.Random(87)
def rand_biv(n, simple):
    if simple:
        u = [rng.randint(-4, 4) for _ in range(n)]; v = [rng.randint(-4, 4) for _ in range(n)]
        return {mask((i, j)): u[i] * v[j] - u[j] * v[i] for (i, j) in pairs_of(n) if u[i] * v[j] - u[j] * v[i]}
    return {mask(p): c for p in pairs_of(n) for c in [rng.randint(-5, 5)] if c}
SIGS = [(1, -1, -1, -1), (1, 1, 1, 1), (1, 1, -1, -1), (1, -1, -1, 0), (1, -1, -1, -1, -1), (1, 1, 1, 1, 1), (1, -1, -1, -1, 0, 0), (1, 1, 1, -1, -1, -1)]
nonsimple = 0; ok_grades = ok_eq = ok_scal = True; tested = 0
for eps in SIGS:
    n = len(eps); A = BR(eps); ext = BR((0,) * n); rows_b, keys, P, C = b_matrix(n); cidx = {c: i for i, c in enumerate(C)}
    for _ in range(25):
        Bv = rand_biv(n, FAULT == 'SIMPLE')
        B2 = A.mul(Bv, Bv); W = ext.mul(Bv, Bv)                                        # the Clifford square and the exterior square
        ok_grades &= all(pc(m) in (0, 4) for m in B2)
        ok_scal &= B2.get(0, 0) == -sum(eps[i] * eps[j] * Bv.get(mask((i, j)), 0) ** 2 for (i, j) in pairs_of(n))
        sym = [Fr(0)] * len(C)                                                         # B . B in the cell basis: B_P^2 on (P,P), 2 B_P B_Q on (P,Q)
        for p in range(len(P)):
            for q in range(p, len(P)):
                sym[cidx[(p, q)]] = Fr(Bv.get(mask(P[p]), 0) * Bv.get(mask(P[q]), 0) * (1 if p == q else 2))
        bBB = {keys[r]: sum(rows_b[r][j] * sym[j] for j in range(len(C))) for r in range(len(keys))}
        bBB = {k: v for k, v in bBB.items() if v}
        G4 = {m: v for m, v in B2.items() if pc(m) == 4}
        ok_eq &= (G4 == W == bBB)
        nonsimple += bool(W); tested += 1
chk('bit', ok_grades and ok_scal, 'catl.B5: B^2 has grades 0 and 4 only and <B^2>_0 = -sum eps_i eps_j B_ij^2, %d random integer bivectors in %d signatures (n = 4..6, null generators included)' % (tested, len(SIGS)))
chk('bit', ok_eq, 'catl.B5: <B^2>_4 = B ^ B (the bit rule with every generator null) = b(B . B) (the Bianchi matrix on the symmetric square), the same %d bivectors' % tested)
chk('ctl', nonsimple > 0, 'catl.B6: %d of the %d bivectors are not simple (B ^ B != 0): the identity B ^ B = b(B . B) is not 0 = 0' % (nonsimple, tested))
rngn = np.random.default_rng(87); okn = True
for n in (4, 5, 6):
    rows_b, keys, P, C = b_matrix(n); ext = BR((0,) * n)
    for _ in range(10):
        Bm = np.triu(rngn.integers(-5, 6, (n, n)), 1); Bm = Bm - Bm.T
        W = ext.mul({mask((i, j)): int(Bm[i, j]) for (i, j) in pairs_of(n) if Bm[i, j]}, {mask((i, j)): int(Bm[i, j]) for (i, j) in pairs_of(n) if Bm[i, j]})
        for (a, b, c, d) in itertools.combinations(range(n), 4):
            okn &= W.get(mask((a, b, c, d)), 0) == 2 * (Bm[a, b] * Bm[c, d] - Bm[a, c] * Bm[b, d] + Bm[a, d] * Bm[b, c])
chk('bit==std', okn, 'catl.B5: the coefficient of e_abcd in B ^ B is 2 (B_ab B_cd - B_ac B_bd + B_ad B_bc) (numpy skew matrices, n = 4, 5, 6)')
# controls
e = BR((0, 0, 0, 0)); Bns = {mask((0, 1)): 1, mask((2, 3)): 1}; u = {1: 1, 2: 2}; v = {4: 3, 8: -1}; Bs = e.mul(u, v)
chk('ctl', e.mul(Bns, Bns) == {15: 2} and e.mul(Bs, Bs) == {}, 'catl.B6: B = e01 + e23 has B ^ B = 2 e0123 != 0; the simple B = u ^ v has B ^ B = 0')
rs, ks, _, Cs = b_matrix(4, 'sym'); rks = gs.rank_and_null(rs, len(Cs))[0]
chk('ctl', rks == 19 and len(Cs) - rks == 2, 'catl.B6: a wrong version, b with the product of the symmetric algebra (x_P x_Q): rank %d, kernel %d at n = 4, not 1 and 20' % (rks, len(Cs) - rks))
chk('ctl', 21 - comb(4, 3) == 17 != 20, 'catl.B6: a wrong version, the target Lambda^3 in place of Lambda^4: 21 - 4 = 17, not the 20 curvature tensors at n = 4')

# ================================================================================================ C. the cubic Casimir of su(3)
head('C. The cubic Casimir of su(3) on the 3 and the 3-bar: the colour bits of the 32 labels and 3 x 3 matrices')
def a_op(i):
    M = np.zeros((32, 32), dtype=np.int64)
    for x in range(32):
        if (x >> i) & 1: M[x ^ (1 << i), x] = (-1) ** pc(x & ((1 << i) - 1))
    return M
AN = [a_op(i) for i in range(5)]; CR = [m.T.copy() for m in AN]
COL = (2, 3, 4)
num = lambda c: CR[c] @ AN[c]
OFF = [(i, j) for i in range(3) for j in range(3) if i != j]
def basis_ops(E, H):                                                 # the abstract basis E_ij (i != j), H1 = E_00 - E_11, H2 = E_11 - E_22
    return [E(i, j) for (i, j) in OFF] + [H(0) - H(1), H(1) - H(2)]
X32 = basis_ops(lambda i, j: CR[COL[i]] @ AN[COL[j]], lambda i: num(COL[i]))
def unit3(i, j): m = np.zeros((3, 3), dtype=np.int64); m[i, j] = 1; return m
X3 = basis_ops(unit3, lambda i: unit3(i, i))
b_of = lambda x: pc(x >> 2); w_of = lambda x: pc(x & 3)
V3 = [x for x in range(32) if b_of(x) == 1 and w_of(x) == 0]; V3b = [x for x in range(32) if b_of(x) == 2 and w_of(x) == 0]
def block(M, S): return M[np.ix_(S, S)]
def inv_fr(A):
    n = len(A); M = [[Fr(A[i][j]) for j in range(n)] + [Fr(int(i == j)) for j in range(n)] for i in range(n)]
    for c in range(n):
        p = next(r for r in range(c, n) if M[r][c] != 0); M[c], M[p] = M[p], M[c]; iv = 1 / M[c][c]; M[c] = [x * iv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0: f = M[r][c]; M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [row[n:] for row in M]
def tensors(rep):
    """kappa, D, F and the trace tensor 4 tr(XYZ) of the 8 basis elements in the representation rep (a list of 3 x 3 integer matrices)"""
    tr = lambda M: int(np.trace(M)); R = rep; n8 = len(R)
    kap = [[2 * tr(R[a] @ R[b]) for b in range(n8)] for a in range(n8)]
    D = {}; Fm = {}; Tt = {}
    for a, b, c in itertools.product(range(n8), repeat=3):
        D[a, b, c] = 2 * tr(R[a] @ (R[b] @ R[c] + R[c] @ R[b])); Fm[a, b, c] = 2 * tr((R[a] @ R[b] - R[b] @ R[a]) @ R[c]); Tt[a, b, c] = 4 * tr(R[a] @ R[b] @ R[c])
    return kap, D, Fm, Tt
def raise3(t, ki):
    n8 = len(ki); out = dict(t)
    for slot in range(3):
        new = {}
        for k in itertools.product(range(n8), repeat=3):
            new[k] = sum((ki[k[slot]][m] * out[k[:slot] + (m,) + k[slot + 1:]] for m in range(n8) if ki[k[slot]][m]), Fr(0))
        out = new
    return out
def cubic_op(tup, ops):
    """sum t^(abc) op_a op_b op_c with t^(abc) rational: exact, through a common denominator and int64 products"""
    L = lcm(*[v.denominator for v in tup.values()]); P2 = {(a, b): ops[a] @ ops[b] for a in range(len(ops)) for b in range(len(ops))}
    acc = np.zeros_like(ops[0])
    for (a, b, c), v in tup.items():
        if v: acc = acc + int(v * L) * (P2[a, b] @ ops[c])
    return acc, L
def quad_op(ki, ops):
    L = lcm(*[v.denominator for row in ki for v in row]); acc = np.zeros_like(ops[0])
    for a in range(len(ops)):
        for b in range(len(ops)):
            if ki[a][b]: acc = acc + int(ki[a][b] * L) * (ops[a] @ ops[b])
    return acc, L
def per_sector(M, L, scale=1):
    """the value of a diagonal operator on each colour count b = 0..3 (all weak bits), or None when it is not one value there"""
    if not np.array_equal(M, np.diag(np.diag(M))): return None
    vals = {}
    for x in range(32): vals.setdefault(b_of(x), set()).add(Fr(int(M[x, x]), L * scale))
    return {b: (s.pop() if len(s) == 1 else None) for b, s in vals.items()}
def scalar3(M, L):
    return Fr(int(M[0, 0]), L) if np.array_equal(M, M[0, 0] * np.eye(M.shape[0], dtype=np.int64)) else None

# [bit] the tensors on the one-colour-bit labels, the operators on all 32 labels
rep_b = [block(X, V3) for X in X32]
kap, D, Fm, Tt = tensors(rep_b); ki = inv_fr(kap)
Dmain = Tt if FAULT == 'TRACE' else D
CD = per_sector(*cubic_op(raise3({k: Fr(v) for k, v in Dmain.items()}, ki), X32))
CF = per_sector(*cubic_op(raise3({k: Fr(v) for k, v in Fm.items()}, ki), X32))
CT = per_sector(*cubic_op(raise3({k: Fr(v) for k, v in Tt.items()}, ki), X32))
C2 = per_sector(*quad_op(ki, X32))
Ehat = lambda i, j: 3 * (CR[COL[i]] @ AN[COL[j]]) - (int(i == j) * sum(num(c) for c in COL))     # 3 x (E_ij - delta_ij N_col / 3)
GL = np.zeros((32, 32), dtype=np.int64)
for i, j, k in itertools.product(range(3), repeat=3): GL = GL + Ehat(i, j) @ Ehat(j, k) @ Ehat(k, i)
CG = per_sector(GL, 27)
c = CD[1] if CD else None
chk('bit', CD is not None and CD[1] == Fr(10, 9) and CD[2] == -CD[1] and CD[0] == 0 and CD[3] == 0,
    'catl.C1: the symmetrised cubic Casimir C_D on the labels with b = 0, 1, 2, 3 colour bits (any weak bits): %s' % ({b: fr(v) for b, v in CD.items()} if CD else 'not diagonal'))
chk('bit', CF is not None and CF[1] == CF[2] == -2 and C2 is not None and C2[1] == C2[2] == Fr(4, 3) and CF[1] == Fr(-3, 2) * C2[1],
    'catl.C2: the antisymmetric contraction C_F takes %s and %s on b = 1 and b = 2 (one value), -3/2 times the quadratic Casimir %s, %s' % (fr(CF[1]), fr(CF[2]), fr(C2[1]), fr(C2[2])) if CF and C2 else 'catl.C2: not diagonal')
chk('bit', CT is not None and CG is not None and CT[1] == Fr(-8, 9) and CT[2] == Fr(-28, 9) and CG[1] == Fr(56, 9) and CG[2] == Fr(16, 9) and CT[1] - CF[1] == CD[1] and CT[2] - CF[2] == CD[2],
    'catl.C3: unsymmetrised cubics tell the 3 from the 3-bar: the trace tensor 4 tr(XYZ) = D + F gives %s and %s, the ordered product sum E_ij E_jk E_ki of the traceless generators %s and %s (= 2 C_D + 3 C_2)'
    % ((fr(CT[1]), fr(CT[2]), fr(CG[1]), fr(CG[2])) if CT and CG else ('?',) * 4))
def hw(ops3, S):
    """the highest-weight vector of a sector (killed by the raising operators E_01, E_12) and its (H1, H2) eigenvalues, exact"""
    R1, R2, H1, H2 = (block(ops3[OFF.index((0, 1))], S), block(ops3[OFF.index((1, 2))], S), block(ops3[6], S), block(ops3[7], S)) if S else ops3
    rows = [[Fr(int(x)) for x in r] for r in np.vstack([R1, R2])]
    rk, nb = gs.rank_and_null(rows, len(rows[0]))
    if len(nb) != 1: return None
    Lv = lcm(*[Fr(x).denominator for x in nb[0]]); vv = np.array([int(Fr(x) * Lv) for x in nb[0]], dtype=np.int64)
    lam = []
    for H in (H1, H2):
        w = H @ vv; k = next(i for i in range(len(vv)) if vv[i]); lam.append(Fr(int(w[k]), int(vv[k])))
        if not all(Fr(int(w[i])) == lam[-1] * int(vv[i]) for i in range(len(vv))): return None
    return tuple(int(x) for x in lam)
hw_b = (hw(X32, V3), hw(X32, V3b))
chk('bit', hw_b == ((1, 0), (0, 1)), 'catl.C4: highest weights of the one-colour-bit labels %s and of the two-colour-bit labels %s (raising operators a_2^+ a_3 and a_3^+ a_4)' % hw_b)
# [std] 3 x 3 matrices, the 3-bar as -X^T
bar = (lambda X: X.T.copy()) if FAULT == 'BAR' else (lambda X: -X.T)
kap3, D3, F3, T3 = tensors(X3); ki3 = inv_fr(kap3)
s = {}
for name, t in (('D', D3), ('F', F3), ('T', T3)):
    tup = raise3({k: Fr(v) for k, v in t.items()}, ki3)
    s[name] = (scalar3(*cubic_op(tup, X3)), scalar3(*cubic_op(tup, [bar(X) for X in X3])))
s['C2'] = (scalar3(*quad_op(ki3, X3)), scalar3(*quad_op(ki3, [bar(X) for X in X3])))
I3 = np.eye(3, dtype=np.int64)
Eh3 = lambda i, j, rep: rep(3 * unit3(i, j) - int(i == j) * I3)
G3 = lambda rep: sum((Eh3(i, j, rep) @ Eh3(j, k, rep) @ Eh3(k, i, rep) for i, j, k in itertools.product(range(3), repeat=3)), np.zeros((3, 3), dtype=np.int64))
s['G'] = (scalar3(G3(lambda X: X), 27), scalar3(G3(bar), 27))
chk('std', s['D'] == (Fr(10, 9), Fr(-10, 9)) and s['F'] == (-2, -2) and s['C2'] == (Fr(4, 3), Fr(4, 3)) and s['T'] == (Fr(-8, 9), Fr(-28, 9)) and s['G'] == (Fr(56, 9), Fr(16, 9)),
    'catl.C1-C3: 3 x 3 rational matrices, the 3-bar as -X^T: C_D %s / %s, C_F %s / %s, C_2 %s / %s, trace tensor %s / %s, ordered product %s / %s'
    % tuple(fr(x) if x is not None else 'not scalar' for k in ('D', 'F', 'C2', 'T', 'G') for x in s[k]))
hw3 = (hw([X3[OFF.index((0, 1))], X3[OFF.index((1, 2))], X3[6], X3[7]], None), hw([bar(X3[OFF.index((0, 1))]), bar(X3[OFF.index((1, 2))]), bar(X3[6]), bar(X3[7])], None))
chk('std', hw3 == ((1, 0), (0, 1)), 'catl.C4: highest weights of the 3 and of -X^T: %s and %s' % hw3)
lam = np.zeros((8, 3, 3), dtype=complex)
lam[0][0, 1] = lam[0][1, 0] = 1; lam[1][0, 1] = -1j; lam[1][1, 0] = 1j; lam[2][0, 0] = 1; lam[2][1, 1] = -1
lam[3][0, 2] = lam[3][2, 0] = 1; lam[4][0, 2] = -1j; lam[4][2, 0] = 1j; lam[5][1, 2] = lam[5][2, 1] = 1; lam[6][1, 2] = -1j; lam[6][2, 1] = 1j
lam[7] = np.diag([1, 1, -2]) / np.sqrt(3)
T8 = lam / 2
dg = np.array([[[np.trace(lam[cc] @ (lam[a] @ lam[b] + lam[b] @ lam[a])).real / 4 for cc in range(8)] for b in range(8)] for a in range(8)])
fg = np.array([[[(-0.25j * np.trace(lam[cc] @ (lam[a] @ lam[b] - lam[b] @ lam[a]))).real for cc in range(8)] for b in range(8)] for a in range(8)])
def gm(t, Ts): return np.einsum('abc,aij,bjk,ckl->il', t, Ts, Ts, Ts)
Tb = np.array([(-X.T if FAULT != 'BAR' else X.T) for X in T8])
v3, v3b, f3, f3b = gm(dg, T8), gm(dg, Tb), gm(fg, T8), gm(fg, Tb)
chk('std', np.allclose(v3, 10 / 9 * np.eye(3)) and np.allclose(v3b, -10 / 9 * np.eye(3)) and np.allclose(f3, 2j * np.eye(3)) and np.allclose(f3b, 2j * np.eye(3)) and abs(dg[0, 0, 7] - 1 / np.sqrt(3)) < 1e-12 and abs(dg[0, 3, 5] - 0.5) < 1e-12,
    'catl.C1-C2: numpy Gell-Mann matrices, T = lambda/2, d_abc = tr(lambda_c {lambda_a, lambda_b})/4 (d_118 = 1/sqrt 3, d_146 = 1/2): d_abc T_a T_b T_c = %.6f / %.6f, f_abc T_a T_b T_c = %.6fi / %.6fi'
    % (v3[0, 0].real, v3b[0, 0].real, f3[0, 0].imag, f3b[0, 0].imag))
chk('bit==std', CD is not None and (CD[1], CD[2]) == s['D'] and (CF[1], CF[2]) == s['F'] and (CT[1], CT[2]) == s['T'] and (CG[1], CG[2]) == s['G'] and hw_b == hw3 and abs(float(CD[1]) - v3[0, 0].real) < 1e-12,
    'catl.C1-C4: the labels and the matrices give the same values (c = 10/9 for kappa = 2 tr, D = 2 tr(X{Y,Z}), i.e. T = lambda/2 and the Gell-Mann d_abc; C_F = i f_abc T_a T_b T_c = -2) and the same weights')
# controls
chk('ctl', C2 is not None and C2[1] == C2[2] and C2[0] == C2[3] == 0, 'catl.C5: the quadratic Casimir is %s on both the 3 and the 3-bar: it does not tell them apart, the cubic one does' % (fr(C2[1]) if C2 else '?'))
rep_bb = [block(X, V3b) for X in X32]
kb, Db, Fb, Tb_ = tensors(rep_bb); CDs = per_sector(*cubic_op(raise3({k: Fr(v) for k, v in Db.items()}, inv_fr(kb)), X32))
chk('ctl', CDs is not None and CD is not None and CDs[1] == -CD[1] and CDs[2] == -CD[2], 'catl.C5: D taken on the two-colour-bit labels (the 3-bar as the defining representation) flips the sign: %s on b = 1, %s on b = 2' % ((fr(CDs[1]), fr(CDs[2])) if CDs else ('?', '?')))
chk('ctl', CF is not None and CT is not None and CF[1] == CF[2] and CT[1] != CT[2], 'catl.C5: a tensor with no totally symmetric part (F) gives one value on both; a tensor that is only unsymmetrised (the trace tensor) does not: the symmetric part is what tells them apart')

# ================================================================================================ S. the 6 + 12 + 3 split under a change of frame
head('S. The 21 cells of the six coordinate planes of a 4-space under a change of frame')
PL = pairs_of(4); PM = [mask(p) for p in PL]; CELLS = cells_of(6)
def cls(p, q):
    k = len(set(PL[p]) & set(PL[q]))
    if FAULT == 'CLASS': return 'vertex' if p == q else 'edge'
    return 'vertex' if p == q else 'edge' if k == 1 else 'antipodal'
NAMES = ('vertex', 'edge', 'antipodal')
cnt = {k: sum(1 for (p, q) in CELLS if cls(p, q) == k) for k in NAMES}; pcl = gs.pair_classes(4)
chk('bit', (cnt['vertex'], cnt['edge'], cnt['antipodal']) == (6, 12, 3) == (pcl['diagonal'], pcl['share_one_index'], pcl['disjoint']),
    'catl.S1: the 21 cells are %d vertex + %d edge + %d antipodal, as pair_classes(4) of the engine module' % (cnt['vertex'], cnt['edge'], cnt['antipodal']))
def rotor(eps, P, a, b): return {0: Fr(a), mask(P): Fr(b)}
def rev(R): return {m: (v if pc(m) % 4 in (0, 1) else -v) for m, v in R.items()}
def adjoint(A, R):
    Rr = rev(R); M = [[Fr(0)] * 6 for _ in range(6)]; ok = A.mul(R, Rr) == {0: 1}
    for j, m in enumerate(PM):
        Y = A.mul(A.mul(R, {m: 1}), Rr); ok &= all(pc(k) == 2 for k in Y)
        for k, v in Y.items(): M[PM.index(k)][j] = Fr(v)
    return M, ok
def T_(M): return [list(r) for r in zip(*M)]
def act(M, G): return matmul_fr(matmul_fr(M, G), T_(M))
def support(G):
    out = {k: 0 for k in NAMES}; wt = {k: Fr(0) for k in NAMES}
    for (p, q) in CELLS:
        if G[p][q] != 0: out[cls(p, q)] += 1; wt[cls(p, q)] += G[p][q] ** 2
    return out, wt
def cell_tensor(p, q):
    G = [[Fr(0)] * 6 for _ in range(6)]; G[p][q] = G[q][p] = Fr(1); return G
def signed_perm_matrix(perm, signs):
    M = [[Fr(0)] * 6 for _ in range(6)]
    for j, (i1, i2) in enumerate(PL):
        a, b = perm[i1], perm[i2]; sg = signs[i1] * signs[i2]
        if a > b: a, b, sg = b, a, -sg
        M[PL.index((a, b))][j] = Fr(sg)
    return M
L13 = BR((1, -1, -1, -1)); E40 = BR((1, 1, 1, 1))
FRAMES = [('Cl(1,3): boost (5/4, 3/4) in 02, rotation (3/5, 4/5) in 13', L13, [((0, 2), Fr(5, 4), Fr(3, 4)), ((1, 3), Fr(3, 5), Fr(4, 5))]),
          ('Cl(1,3): boost (5/4, 3/4) in 01, rotation (3/5, 4/5) in 12, boost (13/12, 5/12) in 03', L13, [((0, 1), Fr(5, 4), Fr(3, 4)), ((1, 2), Fr(3, 5), Fr(4, 5)), ((0, 3), Fr(13, 12), Fr(5, 12))]),
          ('Cl(4,0): rotations (3/5, 4/5) in 02 and (5/13, 12/13) in 13', E40, [((0, 2), Fr(3, 5), Fr(4, 5)), ((1, 3), Fr(5, 13), Fr(12, 13))])]
v_cell = (PL.index((0, 1)), PL.index((0, 1))); a_cell = (PL.index((0, 1)), PL.index((2, 3)))
mix_ok = True; ok_rot = True; Mbits = {}
for (label, A, rs) in FRAMES:
    R = {0: Fr(1)}
    for (P, a, b) in rs: R = A.mul(R, rotor(A.eps, P, a, b))
    M, okR = adjoint(A, R); ok_rot &= okR; Mbits[label] = M
    if FAULT == 'PERM': M = signed_perm_matrix((1, 0, 3, 2), (1, -1, 1, 1))
    for nm, (p, q) in (('vertex cell {01,01}', v_cell), ('antipodal cell {01,23}', a_cell)):
        sup0, wt0 = support(cell_tensor(p, q)); sup, wt = support(act(M, cell_tensor(p, q)))
        mix_ok &= all(sup[k] > 0 for k in NAMES)
        print('    %s, %s: weights before %s, after: support %s, weights %s' % (label, nm, {k: fr(w) for k, w in wt0.items()}, sup, {k: fr(w) for k, w in wt.items()}))
chk('bit', ok_rot, 'catl.S2: every rotor is exact with R R~ = 1 and maps each plane bivector to a bivector')
chk('bit', mix_ok, 'catl.S3: for each frame change above, the tensor on one vertex cell and the tensor on one antipodal cell both acquire support on all three classes: no class is an invariant subspace')
# the Lie algebra: which generator takes which class out of itself
def ad_matrix(A, P):
    M = [[Fr(0)] * 6 for _ in range(6)]
    for j, m in enumerate(PM):
        for k, v in comm(A, {mask(P): 1}, {m: 1}).items(): M[PM.index(k)][j] = Fr(v)
    return M
leave = {k: [] for k in NAMES}
for P in PL:
    Am = ad_matrix(L13, P) if FAULT != 'PERM' else [[Fr(0)] * 6 for _ in range(6)]
    for (p, q) in CELLS:
        G = cell_tensor(p, q); dG = [[a + b for a, b in zip(r1, r2)] for r1, r2 in zip(matmul_fr(Am, G), T_(matmul_fr(Am, G)))]
        out = sorted({cls(x, y) for (x, y) in CELLS if dG[x][y] != 0} - {cls(p, q)})
        if out: leave[cls(p, q)].append('e%d%d: {%d%d,%d%d} -> %s' % (P + PL[p] + PL[q] + ('/'.join(out),)))
for k in NAMES: print('    %s cells left by: %s' % (k, '; '.join(leave[k][:3]) if leave[k] else 'none'))
chk('bit', all(leave[k] for k in NAMES), 'catl.S4: every class is left by some generator e_ab of so(1,3) acting on Sym^2(Lambda^2) (vertex %d, edge %d, antipodal %d cases)' % tuple(len(leave[k]) for k in NAMES))
# [std] Lorentz matrices, minors, the 21 x 21 matrix
ETA = [1, -1, -1, -1]
def lmat(P, a, b, sig, euclid=False):
    i, j = P; L = [[Fr(int(r == c)) for c in range(4)] for r in range(4)]
    boost = (not euclid) and (i == 0)
    ch, sh = (a * a + b * b, 2 * a * b) if boost else (a * a - b * b, 2 * a * b)
    L[i][i] = L[j][j] = ch
    if boost: L[i][j] = L[j][i] = sig * sh
    else: L[i][j] = -sig * sh; L[j][i] = sig * sh
    return L
def minors(L):
    M = [[Fr(0)] * 6 for _ in range(6)]
    for col, (i, j) in enumerate(PL):
        for row, (k, l) in enumerate(PL):
            M[row][col] = L[k][i] * L[l][j] + (1 if FAULT == 'MINOR' else -1) * L[k][j] * L[l][i]
    return M
def lprod(rs, sb, sr, euclid):
    L = [[Fr(int(r == c)) for c in range(4)] for r in range(4)]
    for (P, a, b) in rs: L = matmul_fr(L, lmat(P, a, b, sb if (not euclid and P[0] == 0) else sr, euclid))
    return L
matches = {}
for (label, A, rs) in FRAMES:
    matches[label] = {(sb, sr) for sb in (1, -1) for sr in (1, -1) if minors(lprod(rs, sb, sr, A is E40)) == Mbits[label]}
CONV = {}
for alg, name in ((L13, 'Cl(1,3)'), (E40, 'Cl(4,0)')):
    sets = [matches[label] for (label, A, rs) in FRAMES if A is alg]
    common = set.intersection(*sets) if sets else set()
    if alg is E40: common = {(1, sr) for (sb, sr) in common}                       # no boost in Cl(4,0): its boost sign is not used
    CONV[name] = min(common) if common else None
conv_of = lambda A: CONV['Cl(4,0)' if A is E40 else 'Cl(1,3)']
LS = {label: lprod(rs, conv_of(A)[0], conv_of(A)[1], A is E40) for (label, A, rs) in FRAMES if conv_of(A)}
def is_iso(L, eta): return all(sum(L[k][i] * eta[k] * L[k][j] for k in range(4)) == (eta[i] if i == j else 0) for i in range(4) for j in range(4))
okL = len(LS) == len(FRAMES) and all(is_iso(LS[label], [1, 1, 1, 1] if A is E40 else ETA) for (label, A, rs) in FRAMES)
pairsL = sorted({(fr(a * a + b * b), fr(2 * a * b)) if (A is not E40 and P[0] == 0) else (fr(a * a - b * b), fr(2 * a * b)) for (label, A, rs) in FRAMES for (P, a, b) in rs})
chk('std', okL, 'catl.S2: the 4 x 4 matrices built from the half-angle pairs, (cosh, sinh) or (cos, sin) = %s, satisfy L^T eta L = eta (eta = diag(1,-1,-1,-1), or 1 for Cl(4,0))' % pairsL)
chk('bit==std', all(CONV.values()) and CONV['Cl(1,3)'][1] == -CONV['Cl(4,0)'][1],
    'catl.S2: the adjoint matrix of X -> R X R~ equals the matrix of 2 x 2 minors of L for every frame, with the same plane order e_ij (i < j); one sign convention per algebra, (boost, rotation) = %s in Cl(1,3) and rotation %s in Cl(4,0): the sense of a + b e_ij flips with the square of the space generators'
    % (CONV['Cl(1,3)'], CONV['Cl(4,0)'][1] if CONV['Cl(4,0)'] else None))
fit = {label: ((conv_of(A)[0], conv_of(A)[1], LS[label]) if label in LS else None) for (label, A, rs) in FRAMES}
def sym21(M):
    S = [[Fr(0)] * 21 for _ in range(21)]
    for j, (p, q) in enumerate(CELLS):
        G2 = act(M, cell_tensor(p, q))
        for i, (x, y) in enumerate(CELLS): S[i][j] = G2[x][y]
    return S
blocks_ok = True; okperm = True; nlor = 0
for (label, A, rs) in FRAMES:
    f = fit[label]
    if f is None: blocks_ok = False; continue
    S = sym21(minors(f[2]) if FAULT != 'PERM' else signed_perm_matrix((1, 0, 3, 2), (1, -1, 1, 1)))
    for c1 in NAMES:
        for c2 in NAMES:
            if c1 != c2: blocks_ok &= any(S[i][j] != 0 for i, (x, y) in enumerate(CELLS) for j, (p, q) in enumerate(CELLS) if cls(x, y) == c1 and cls(p, q) == c2)
chk('std', blocks_ok, 'catl.S3: the 21 x 21 matrix of G -> (Lambda^2 L) G (Lambda^2 L)^T has non-zero blocks between every two of the three classes, for each frame change')
for perm in itertools.permutations(range(4)):
    for signs in itertools.product((1, -1), repeat=4):
        M = signed_perm_matrix(perm, signs); nlor += perm[0] == 0
        for (p, q) in CELLS:
            sup, _ = support(act(M, cell_tensor(p, q))); okperm &= sup[cls(p, q)] == 1 and sum(sup.values()) == 1
chk('ctl', okperm, 'catl.S5: each of the 384 signed permutations of the axes (%d of them fix the time axis and lie in O(1,3)) maps every cell to one cell of the same class: this is why the split looks invariant' % nlor)
Mb, _ = adjoint(L13, rotor(L13.eps, (0, 1), Fr(5, 4), Fr(3, 4)))
fixed = all(act(Mb, cell_tensor(p, q)) == cell_tensor(p, q) for (p, q) in (v_cell, a_cell, (PL.index((2, 3)), PL.index((2, 3)))))
moved = support(act(Mb, cell_tensor(PL.index((0, 2)), PL.index((0, 2)))))[0]
chk('ctl', fixed and moved['edge'] > 0, 'catl.S5: the boost in the plane 01 keeps the cells {01,01}, {23,23}, {01,23}; it moves {02,02} to %s' % moved)
chk('ctl', FAULT == 'CLASS' or sum(1 for (p, q) in CELLS if p != q and len(set(PL[p]) & set(PL[q])) <= 1) == 15, 'catl.S5: a wrong class rule (a disjoint pair counted as an edge) gives 6 + 15 + 0, not 6 + 12 + 3')

finish('CATW' + ('-' + FAULT if FAULT else ''))
